/*
 *  Program ID: ca_ply_jobs
 *
 *      Author: tony96
 *
 * Description:
 *     This program move data of local machine to anywhere you hope.
 *
 *    Function:
 *      1. get_all_system
 *      2. is_ply_period
 *      3. is_accident
 */

#include <stdio.h>
#include <signal.h>
#include "commsgs.h"
#include "cmnmsg.h"
#include "comdata.h"
$include "safeclib.h";

/* *** Macro definition *** */
#define         SUCCESS 	0
#define         FAIL    	-1
#define         TRUE    	1
#define         FALSE   	0
#define		MAX_TIME	480
#define		MIN_TIME	10

/* *** Message Definition *** */
#define		M_OK			1000
#define		M_E_ELAPSEDTIME		1001
#define		M_E_HOSTNAME		1002
#define		M_E_OPENDATABASE	1003
#define		M_E_OUTOFCONTROL	1004
#define		M_E_NODATA		1005
#define		M_E_NDATABASE		1006
#define		M_E_NSYSDB		1007

#define _CODE860514

/* *** Global variables *** */
int	g_iElapsedTime, g_fExit;
char	g_sLogFileName[81], g_sTmpBuf[254], g_sExeFileName[80];
$char   sHostName[81];
DBinfo  *list;

/* *** Function prototype *** */
void sig_proc();
void get_all_system();
void is_ply_period();
void is_accident();

main(argc, argv)
int argc;
char **argv;
{
  if(argc < 2){
    printf("Usage: ca_ply_job <time>\n"); exit(1);
  }

  strcpy(g_sExeFileName, IS_BaseName(argv[0]));
  sprintf_s(g_sLogFileName, sizeof g_sLogFileName, "%s/log/%s.log", getenv("APHOME"), g_sExeFileName);

# ifdef _CODE860514
  printf("&&& g_sLogFile:[%s]\n", g_sLogFileName);
# endif

  g_iElapsedTime = atoi(argv[1]);
  g_fExit = FALSE;
  printf("g_iElapsedTime[%d]\n",g_iElapsedTime);

  /* *** Set alarm *** */
  if(g_iElapsedTime > 0)
    alarm(g_iElapsedTime);
  else{
    sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf, "Error001: Elapsed Time(%d), it must be more than zero", 
            g_iElapsedTime);
    IS_WriteLog(g_sLogFileName, M_E_ELAPSEDTIME, g_sTmpBuf);
    exit(1);
  }
  sigset(SIGALRM, sig_proc);
  get_all_system();  

# ifdef _CODE860514
  printf("&&& elapsed time[%d]\n", g_iElapsedTime);
# endif

  if(g_iElapsedTime-10 < MIN_TIME)
    IS_UpdateConf(g_sExeFileName, MIN_TIME);
  else
    IS_UpdateConf(g_sExeFileName, g_iElapsedTime-10);
} /* main */

/* ********************************************************************* */
void sig_proc()
{
  g_fExit = TRUE;
}

/* ************************************************************************
 * get_all_system:
 *
 *     This function synchronize ca_ply_period of local 
 *   database to headquarters(00) database.
 *
 ************************************************************************ */
void get_all_system()
{
  $char sFullName[80], sTmt[1024], sHeadQuarters[80];
  $char sSysdb[50], sInit_branch[12]; 
  int   i, rc;

  $WHENEVER SQLERROR GOTO errexit;
  $SET LOCK MODE TO WAIT 5;

  /* *** Get hostname *** */
  if(gethostname(sHostName, 80) == FAIL){
    sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf, "Error002: The program can't get host name !");
    IS_WriteLog(g_sLogFileName, M_E_HOSTNAME, g_sTmpBuf);
    exit(1);
  }

  /* *** Get sysdb database name *** */
# ifdef _CODE860514
  rc = iGetProfileString("insurance.conf", "INIT", "sysdb", "sysdb", 
			 sSysdb, 50);

  if(rc < 0){
    sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf, "Error002A: The program can't get sysdb name!");
    IS_WriteLog(g_sLogFileName, M_E_HOSTNAME, g_sTmpBuf);
    exit(1);
  }

  rc = iGetProfileString("insurance.conf", "INIT", "init_branch", "00", 
			 sInit_branch, 50);

  if(rc < 0){
    sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf, "Error002B: The program can't get sysdb name!");
    IS_WriteLog(g_sLogFileName, M_E_HOSTNAME, g_sTmpBuf);
    exit(1);
  }

# endif


# ifdef _CODE860514
  $DATABASE $sSysdb;
# else
  $DATABASE sysdb_ck;
# endif

/* Get all systems database list */
  if( (list=get_sysdb_list(&i, sInit_branch)) == (char*)0 ) {
      sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf, "Error003: The program can't dblist !");
      IS_WriteLog(g_sLogFileName, M_CM_NOT_DBLIST, g_sTmpBuf);
      exit(1);
  }

printf("g_sExeFileName[%s] sHostName[%s] \n",g_sExeFileName,sHostName);
printf("dbname[%s] dbchi[%s] dbbranch[%s]\n",list[0].dbname,list[0].dbchi,
 list[0].dbbranch);
printf("sysdb[%s]\n",sSysdb);
printf("sysdb_count[%d] \n",i);

  is_ply_period(i, sSysdb);  
  is_accident(i, sSysdb);
  return;

errexit:
# ifdef _CODE860514
   printf("get_all_system: SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrd);
# endif
   IS_WriteLog(g_sLogFileName, SQLCODE, sqlca.sqlerrm);
   exit(1);

} /* get_all_system */

/* *********************************************************************
 *    Insert Or Update ca_ply_period Table for all System Database 
 ********************************************************************* */

void is_ply_period(i, sSysdb)
int   i;
$char *sSysdb;
{
$char  sInumber[21],sDply_bgn[11],sDply_end[11];
$char  sIpolicy[19],sFcard_class[2],sFtrans[2];
$char  sTmt[1024];
$int  iCount=0;
$int   j=0;
$char  sBranch[12];

   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT 5;

   sprintf_s(sTmt, sizeof sTmt, "SELECT count(*) FROM %s:ca_ply_period  "
                   "WHERE ftrans = 'A' OR ftrans = 'U' ", sSysdb);

   $PREPARE ply_1 FROM $sTmt;
   $DECLARE ply_a CURSOR FOR ply_1;
   $OPEN    ply_a;
   $FETCH   ply_a INTO $iCount; 
   $CLOSE   ply_a; $FREE ply_a;

# ifdef _CODE860514 
  printf("&&& iCount[%d]\n", iCount);
# endif

  if(iCount == 0){     /* No data, next database */
     sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf, "Error005: Database (%s) has no data", sSysdb);
     IS_WriteLog(g_sLogFileName, M_E_NODATA, g_sTmpBuf);
     return;
  }

   sprintf_s(sTmt, sizeof sTmt, "SELECT inumber, dply_bgn,    dply_end, "
 			     " ipolicy, fcard_class, ftrans "
           " FROM %s:ca_ply_period  "
           " WHERE ftrans = 'A' OR ftrans = 'U' ", sSysdb);


   $PREPARE ply_2 FROM $sTmt;
   $DECLARE ply_b CURSOR WITH HOLD FOR ply_2;
   $OPEN    ply_b;
   while(1) {
      $WHENEVER SQLERROR CONTINUE;
      $FETCH ply_b INTO $sInumber, $sDply_bgn,    $sDply_end,
	       	        $sIpolicy, $sFcard_class, $sFtrans;
      if(SQLCODE == SQLNOTFOUND) break;
      $BEGIN WORK;

      if(sFtrans[0] == 'A')  /* Insert all System */
      {
	  for(j = 0; j < i; j++) 
          {
	     strcpy(sBranch, list[j].dbbranch);
  	     $SELECT count(*) INTO $iCount 
		FROM servertbl
	       WHERE branch = $sBranch
		 AND hostname = $sHostName;
             if (iCount == 1) continue;

             sprintf_s(sTmt, sizeof sTmt, "INSERT INTO %s:ca_ply_period "
		      	          " (inumber, dply_bgn,    dply_end, "
				              " ipolicy, fcard_class, ftrans)  "
                      " VALUES (?,?,?,?,?,'N')", list[j].dbname);   
             $PREPARE ply_3 FROM $sTmt;

	     if(SQLCODE < 0)
	     {
		 sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf,"Error006:inumber(%s) fcard_class(%s) %s",
		   sInumber, sFcard_class, sqlca.sqlerrm);
	         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	         $ROLLBACK WORK;
		 continue; /* next row */
              }   

	      $EXECUTE ply_3 USING $sInumber, $sDply_bgn,    $sDply_end,
	       	                   $sIpolicy, $sFcard_class;
	     if(SQLCODE < 0)
	     {
		 sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf,"Error006A:inumber(%s) fcard_class(%s) %s",
		   sInumber, sFcard_class, sqlca.sqlerrm);
	         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	         $ROLLBACK WORK;
		 continue; /* next row */
              }

/***************************************************************/
/*     This should not be happen, but anything is possible.    */
/*     SQLCODE(-239) imply flag(ftrans) lose control.       */
/***************************************************************/
	     if(SQLCODE == -239)
	     {
		 sprintf_s(sTmt, sizeof sTmt,
	         "UPDATE %s:ca_ply_period  "
           "          SET dply_bgn    = ?,  "
           "              dply_end    = ?,  "
			     "ipolicy     = ?,  "
			     "ftrans      = 'N' "
           "            WHERE inumber = ?  "
		       "  AND fcard_class = ? ", list[j].dbname);

                 $PREPARE ply_4 FROM $sTmt;
	         if(SQLCODE < 0)
		 {
		     sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf, "Error007:inumber(%s) fcard_class(%s) %s",
		     sInumber, sFcard_class, sqlca.sqlerrm);
	             IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	             $ROLLBACK WORK;
		     continue; /* next row */
                  }   
	      
	         $EXECUTE ply_4 USING $sDply_bgn, $sDply_end,
	       	                      $sIpolicy,  $sInumber,   $sFcard_class;
	         if(SQLCODE < 0)
	         {
		     sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf,"Error007A:inumber(%s) fcard_class(%s) %s",
		       sInumber, sFcard_class, sqlca.sqlerrm);
	             IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	             $ROLLBACK WORK;
		     continue; /* next row */
                  }

	     /* *** Log the information that processed record should insert,
	            but target site has this record, this indicate ftransfer
	  	    flag lose control *** */
  	          sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf,"Error008:inumber(%s) fcard_class(%s) %s",
	          sInumber, sFcard_class, sqlca.sqlerrm);
                  IS_WriteLog(g_sLogFileName, M_E_OUTOFCONTROL, g_sTmpBuf);
               }  /* End if for SQLCODE = -239 */
	      else if(SQLCODE < 0) /* another error */
	      {
  	         sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf,"Error009:inumber(%s) fcard_class(%s) %s",
	         sInumber, sFcard_class, sqlca.sqlerrm);
	         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	         $ROLLBACK WORK;
	         continue; /* next row */
	       }
          }
      }
      else if(sFtrans[0] == 'U')   /* Update all System */
      {
         for(j = 0; j < i; j++)
	 {
	     strcpy(sBranch, list[j].dbbranch);

  	     $SELECT count(*) INTO $iCount 
		FROM servertbl
	       WHERE branch = $sBranch
		 AND hostname = $sHostName;
             if (iCount == 1) continue;
  	     sprintf_s(sTmt, sizeof sTmt,
                  "UPDATE %s:ca_ply_period "
                  "   SET dply_bgn    = ?, "
                  "       dply_end    = ?, "
                  "       ipolicy     = ?, "
                  "       ftrans      = 'N' "
                  " WHERE inumber     = ? "
                  "   AND fcard_class = ? ", list[j].dbname);
printf("U stmt[%s] list[%s]\n",sTmt,j,list[j].dbname);
             $PREPARE ply_5 FROM $sTmt;
	     if(SQLCODE < 0)
             {
	        sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf, "Error010:inumber(%s) fcard_class(%s) %s",
		     sInumber, sFcard_class, sqlca.sqlerrm);
	        IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	        $ROLLBACK WORK;
		continue; /* next row */
             }   

	     $EXECUTE ply_5 USING $sDply_bgn, $sDply_end,
         	                  $sIpolicy,  $sInumber,   $sFcard_class;
             if(SQLCODE < 0)
	     {
	        sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf,"Error010A:inumber(%s) fcard_class(%s) %s",
		       sInumber, sFcard_class, sqlca.sqlerrm);
	        IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	        $ROLLBACK WORK;
		continue; /* next row */
             }   

  /***************************************************************/
  /*     1. This should not be happen, but anything is possible. */
  /*                                                             */
  /*     2. If no data has been update, this imply               */
  /*        flag(ftransfer) lose control.                        */
  /***************************************************************/
	    if(sqlca.sqlerrd[2] == 0)
	    {
printf("U.err stmt[%s] list[%s]\n",sTmt,j,list[j].dbname);
printf("sqlca.sqlerrd[%d]\n", sqlca.sqlerrd);
               sprintf_s(sTmt, sizeof sTmt, "INSERT INTO %s:ca_ply_period "
		       	            " (inumber, dply_bgn,    dply_end, "
				                " ipolicy, fcard_class, ftrans)  "
                        " VALUES (?,?,?,?,?,'N')", list[j].dbname);   
               $PREPARE ply_6 FROM $sTmt;

	       if(SQLCODE < 0)
	       {
	      	   sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf,"Error011:inumber(%s) fcard_class(%s) %s",
		     sInumber, sFcard_class, sqlca.sqlerrm);
	           IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	           $ROLLBACK WORK;
		   continue; /* next row */
                }   

	        $EXECUTE ply_6 USING $sInumber, $sDply_bgn,    $sDply_end,
	       	                     $sIpolicy, $sFcard_class;
	        if(SQLCODE < 0)
	        {
	   	    sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf,"Error011A:inumber(%s) fcard_class(%s) %s",
		      sInumber, sFcard_class, sqlca.sqlerrm);
	            IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	            $ROLLBACK WORK;
		    continue; /* next row */
                }
	 /* *** Log the information that processed record should update,
	        but target site has this record, this indicate ftransfer
	        is lose control *** */

             } /* End sqlca.sqlerrd[2] */

	 } /* End For Loop */

      } /* End Update */

      /* Update �����t�� */
      sprintf_s(sTmt, sizeof sTmt,
      "UPDATE %s:ca_ply_period  "
      "    SET ftrans      = 'N' "
      "  WHERE inumber = ?  "
      "    AND fcard_class = ? ", sSysdb); 

      $PREPARE ply_e FROM $sTmt;
      if(SQLCODE < 0)
      {
         sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf, "Error019:inumber(%s) fcard_class(%s) %s",
            sInumber, sFcard_class, sqlca.sqlerrm);
         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
        $ROLLBACK WORK;
	continue; /* next row */
       }   

     $EXECUTE ply_e USING $sInumber,   $sFcard_class;
     if(SQLCODE < 0)
     {
        sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf,"Error019A:inumber(%s) fcard_class(%s) %s",
	       sInumber, sFcard_class, sqlca.sqlerrm);
        IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
        $ROLLBACK WORK;
	continue; /* next row */
      }    
     $COMMIT WORK;

     /* *** Log success record *** */
    sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf, "Success: inumber(%s), fcard_class(%s)", sInumber,sFcard_class);
    IS_WriteLog(g_sLogFileName, M_OK, g_sTmpBuf);

    if(g_fExit){
       $CLOSE fac_b; $FREE fac_b; 
    /* *** Need more time to process next time *** */
       if(g_iElapsedTime*2 > MAX_TIME)
           IS_UpdateConf(g_sExeFileName, MAX_TIME);
	else
	  IS_UpdateConf(g_sExeFileName, g_iElapsedTime*2);
	  exit(1);
       }
   }    /* End While */
   $CLOSE   ply_b; $FREE ply_b;

   return;
errexit:
# ifdef _CODE860514
   printf("is_ply_period: SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrd);
# endif
   IS_WriteLog(g_sLogFileName, SQLCODE, sqlca.sqlerrm);
   printf("is_ply_period: SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrd);
   exit(1);

} /* get_all_system */


/* *********************************************************************
 *    Insert Or Update ca_accident Table for all System Database 
 ********************************************************************* */

void is_accident(i, SSysdb)
int    i;
$char  *SSysdb;
{
$char  sInumber[21],    sDaccident[11], sIclaim[14], sIpolicy[19]; 
$char  sFcard_class[2], sFdmg[2],       sFlia[2],    sFtrans[2];
$int   iMdmg_app,       iMlia_app;
$char  sTmt[1024];
$int   iCount=0;
$int   j=0;
$char  sBranch[12];

   $WHENEVER SQLERROR goto errexit;
   $SET LOCK MODE TO WAIT 5;
   iCount = 0;
   sprintf_s(sTmt, sizeof sTmt, "SELECT COUNT(*) FROM %s:ca_accident  "
                    " WHERE ftrans = 'A' OR ftrans = 'U' ", SSysdb);

   $PREPARE ply_7 FROM $sTmt;
   $DECLARE ply_c CURSOR FOR ply_7;
   $OPEN    ply_c;
   $FETCH   ply_c INTO $iCount; 
   $CLOSE   ply_c; $FREE ply_c;

# ifdef _CODE860515 
  printf("&&& iCount[%d]\n", iCount);
# endif

  if(iCount == 0){     /* No data, next database */
     sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf, "Error013: Database (%s) has no data", SSysdb);
     IS_WriteLog(g_sLogFileName, M_E_NODATA, g_sTmpBuf);
     return;
  }
   sprintf_s(sTmt, sizeof sTmt, "SELECT inumber, daccident, iclaim, ipolicy,  fcard_class, "
 			                          " fdmg,    mdmg_app,  flia,   mlia_app, ftrans "
                                " FROM %s:ca_accident "
                                " WHERE ftrans = 'A' OR ftrans = 'U' ", SSysdb);

   $PREPARE ply_8 FROM $sTmt;
   $DECLARE ply_d CURSOR WITH HOLD FOR ply_8;
   $OPEN    ply_d;
   while(1) {
      $FETCH ply_d INTO $sInumber,     $sDaccident, $sIclaim,   $sIpolicy,
                        $sFcard_class, $sFdmg,      $iMdmg_app, $sFlia,
			$iMlia_app,    $sFtrans;
      if(SQLCODE == SQLNOTFOUND) break;
      $WHENEVER SQLERROR CONTINUE;
      $BEGIN WORK;

      if(sFtrans[0] == 'A')  /* Insert all System */
      {
	  for(j = 0; j < i; j++) 
          {
	     strcpy(sBranch, list[j].dbbranch);
  	     $SELECT count(*) INTO $iCount 
		FROM servertbl
	       WHERE branch = $sBranch
		 AND hostname = $sHostName;

             if (iCount == 1) continue;

             sprintf_s(sTmt, sizeof sTmt, "INSERT INTO %s:ca_accident "
                      " (inumber,     daccident, iclaim, ipolicy, "
				              " fcard_class, fdmg,      mdmg_app,  flia, "
				              " mlia_app, ftrans) "
                      " VALUES (?,?,?,?,?,?,?,?,?,'N')", list[j].dbname);   
             $PREPARE ply_9 FROM $sTmt;

	     if(SQLCODE < 0)
	     {
		 sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf,"Error014:inumber(%s) fcard_class(%s) %s",
		   sInumber, sFcard_class, sqlca.sqlerrm);
	         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	         $ROLLBACK WORK;
		 continue; /* next row */
              }   

	      $EXECUTE ply_9 USING $sInumber,  $sDaccident,   $sIclaim, 
				   $sIpolicy,  $sFcard_class, $sFdmg,
				   $iMdmg_app, $sFlia,        $iMlia_app;
	     if(SQLCODE < 0)
	     {
		 sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf,"Error014A:inumber(%s) fcard_class(%s) %s",
		   sInumber, sFcard_class, sqlca.sqlerrm);
	         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	         $ROLLBACK WORK;
		 continue; /* next row */
              }

/***************************************************************/
/*     This should not be happen, but anything is possible.    */
/*     SQLCODE(-239) imply flag(transfer) lose control.       */
/***************************************************************/
	     if(SQLCODE == -239)
	     {
		 sprintf_s(sTmt, sizeof sTmt,
	         "UPDATE %s:ca_accident  "
           "          SET daccident = ?,  "
           "              iclaim    = ?,  "
			     " ipolicy   = ?,  "
			     " fdmg      = ?,  "
			     " mdmg_app  = ?,  "
			     " flia      = ?,  "
			     " mlia_app  = ?,  "
			     " ftrans    = 'N' "
           "  WHERE inumber = ?  "
		       "  AND fcard_class = ? ", list[j].dbname);

                 $PREPARE ply_10 FROM $sTmt;
	         if(SQLCODE < 0)
		 {
		     sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf, "Error015:inumber(%s) fcard_class(%s) %s",
		     sInumber, sFcard_class, sqlca.sqlerrm);
	             IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	             $ROLLBACK WORK;
		     continue; /* next row */
                  }   
	      
	         $EXECUTE ply_10 USING $sDaccident, $sIclaim,   $sIpolicy,  
				       $sFdmg,      $iMdmg_app, $sFlia,
				       $iMlia_app,  $sInumber,  $sFcard_class;
	         if(SQLCODE < 0)
	         {
		     sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf,"Error015A:inumber(%s) fcard_class(%s) %s",
		       sInumber, sFcard_class, sqlca.sqlerrm);
	             IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	             $ROLLBACK WORK;
		     continue; /* next row */
                  }

	     /* *** Log the information that processed record should insert,
	            but target site has this record, this indicate transfer
	  	    flag lose control *** */
  	          sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf,"Error015:inumber(%s) fcard_class(%s) %s",
	          sInumber, sFcard_class, sqlca.sqlerrm);
                  IS_WriteLog(g_sLogFileName, M_E_OUTOFCONTROL, g_sTmpBuf);
               }  /* End if for SQLCODE = -239 */
	      else if(SQLCODE < 0) /* another error */
	      {
  	         sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf,"Error016:inumber(%s) fcard_class(%s) %s",
	         sInumber, sFcard_class, sqlca.sqlerrm);
	         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	         $ROLLBACK WORK;
	         continue; /* next row */
	       }
          }
      } /* End Insert */
      else if(sFtrans[0] == 'U')   /* Update all System */
      {
         for(j = 0; j < i; j++)
	 {
	     strcpy(sBranch, list[j].dbbranch);
  	     $SELECT count(*) INTO $iCount 
		FROM servertbl
	       WHERE branch = $sBranch
		 AND hostname = $sHostName;
             if (iCount == 1) continue;

  	     sprintf_s(sTmt, sizeof sTmt,
        "UPDATE %s:ca_accident "
        "          SET daccident = ?,  "
        "              iclaim    = ?,  "
        "        ipolicy   = ?,  "
        "  fdmg      = ?,  "
        "    mdmg_app  = ?,  "
        "    flia      = ?,  "
        "  Mlia_app  = ?,  "
        "  ftrans    = 'N' "
        "        WHERE inumber = ?  "
        "    AND fcard_class = ? ", list[j].dbname);

             $PREPARE ply_11 FROM $sTmt;
	     if(SQLCODE < 0)
             {
	        sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf, "Error017:inumber(%s) fcard_class(%s) %s",
		     sInumber, sFcard_class, sqlca.sqlerrm);
	        IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	        $ROLLBACK WORK;
		continue; /* next row */
             }   
printf("2U stmt[%s] list[%s]\n",sTmt,j,list[j].dbname);

	     $EXECUTE ply_11 USING $sDaccident, $sIclaim,   $sIpolicy,  
			           $sFdmg,      $iMdmg_app, $sFlia,
				   $iMlia_app,  $sInumber,  $sFcard_class;
             if(SQLCODE < 0)
	     {
	        sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf,"Error017A:inumber(%s) fcard_class(%s) %s",
		       sInumber, sFcard_class, sqlca.sqlerrm);
	        IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	        $ROLLBACK WORK;
		continue; /* next row */
             }   

  /***************************************************************/
  /*     1. This should not be happen, but anything is possible. */
  /*                                                             */
  /*     2. If no data has been update, this imply               */
  /*        flag(ftransfer) lose control.                        */
  /***************************************************************/
	    if(sqlca.sqlerrd[2] == 0)
	    {
printf("2U.err stmt[%s] list[%s]\n",sTmt,j,list[j].dbname);
printf("sqlca.sqlerrd[%d]\n", sqlca.sqlerrd);
             sprintf_s(sTmt, sizeof sTmt, "INSERT INTO %s:ca_accident "
                              " (inumber,     daccident, iclaim, ipolicy, "
			                        " fcard_class, fdmg,      mdmg_app,  flia, "
				                      " mlia_app, ftrans) "
                              " VALUES (?,?,?,?,?,?,?,?,?,'N')", list[j].dbname);   
             $PREPARE ply_12 FROM $sTmt;

	       if(SQLCODE < 0)
	       {
	      	   sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf,"Error018:inumber(%s) fcard_class(%s) %s",
		     sInumber, sFcard_class, sqlca.sqlerrm);
	           IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	           $ROLLBACK WORK;
		   continue; /* next row */
                }   

	        $EXECUTE ply_12 USING $sInumber,  $sDaccident,   $sIclaim, 
			   	      $sIpolicy,  $sFcard_class, $sFdmg,
				      $iMdmg_app, $sFlia,        $iMlia_app;
	        if(SQLCODE < 0)
	        {
	   	    sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf,"Error018A:inumber(%s) fcard_class(%s) %s",
		      sInumber, sFcard_class, sqlca.sqlerrm);
	            IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	            $ROLLBACK WORK;
		    continue; /* next row */
                }
	 /* *** Log the information that processed record should update,
	        but target site has this record, this indicate ftransfer
	        is lose control *** */

             } /* End sqlca.sqlerrd[2] */

	 } /* End For Loop */
      } /* End Update */

       /* Update �����t�� */
       sprintf_s(sTmt, sizeof sTmt, "UPDATE %s:ca_accident SET ftrans = 'N' "
			                              " WHERE inumber = ? AND fcard_class = ?", SSysdb);

      $PREPARE ply_f FROM $sTmt;
      if(SQLCODE < 0)
      {
         sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf, "Error020:inumber(%s) fcard_class(%s) %s",
	     sInumber, sFcard_class, sqlca.sqlerrm);
         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
        $ROLLBACK WORK;
	continue; /* next row */
      }   

    $EXECUTE ply_f USING $sInumber, $sFcard_class; 
printf("stmt[%s]\n",sTmt);

     if(SQLCODE < 0)
     {
        sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf,"Error020A:inumber(%s) fcard_class(%s) %s",
	       sInumber, sFcard_class, sqlca.sqlerrm);
        IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
        $ROLLBACK WORK;
	continue; /* next row */
      }

    /* *** Log success record *** */
    sprintf_s(g_sTmpBuf, sizeof g_sTmpBuf, "Success: inumber(%s) fcard_class(%s)", sInumber,sFcard_class);
    IS_WriteLog(g_sLogFileName, M_OK, g_sTmpBuf);

    if(g_fExit){
       $CLOSE fac_b; $FREE fac_b; 
    /* *** Need more time to process next time *** */
       if(g_iElapsedTime*2 > MAX_TIME)
           IS_UpdateConf(g_sExeFileName, MAX_TIME);
	else
	  IS_UpdateConf(g_sExeFileName, g_iElapsedTime*2);
        exit(1);
    }
    $COMMIT WORK;
     
   }    /* End While */
   $CLOSE   ply_d; $FREE ply_d;

   return;
errexit:
# ifdef _CODE860514
   printf("is_accident: SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
# endif
   IS_WriteLog(g_sLogFileName, SQLCODE, sqlca.sqlerrm);
   exit(1);
}
