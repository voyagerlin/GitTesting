/************************************************/
/*   PROGRAM : ca547m01s.ec                     */
/************************************************/

#include <stdio.h>
#include <string.h>
#include <decimal.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
$include sqlca;
#include "safeclib.h"

typedef struct{
    long type;
    char oldicode1[21];
	char oldicode2[21];
    char oldncode1[61];
	char oldncode2[61];
	int  oldiorder;
    char icode1[21];
	char icode2[21];
    char ncode1[61];
	char ncode2[61];
	int  iorder;
    } car547_t;

/***************************************************************************/
long car547(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	long rtncode;
	long car547_insert(),car547_single_query(),car547_multiple_query(),car547_update_exec(),select_code_data_itype_name();
	char option;

	cm_buf_init(command);
	cm_buf_get("%c",&option);

	printf("car547 : start\n");
	switch(option)
	{
		case 'A':
			rtncode=car547_insert(reply);
			break;
		case 'Q':
			rtncode=car547_single_query(reply);
			break;
		case 'M':
			rtncode=car547_multiple_query(reply);
			break;
		case 'D':
		case 'U':
			rtncode=car547_update_exec(reply,command,com_len);
			break;
		case 'C':
			rtncode=select_code_data_itype_name(reply);
			break;
		default :
			if(exitsub(reply,M_CM_WRONG_OPTION) == True){
				return M_CM_WRONG_OPTION;
			}
			else{
				return apiRC;
			}
	}
	return(rtncode);
}

/****************************************************************************/
long car547_insert(reply)
serverReply reply;
{
	$char DBName[5];
	$char userid[31],itype[3],icode1[21],icode2[21],ncode1[61],ncode2[61];
	$int  iorder=0;
	int   tmp_len;
	
	long   MsgCode;
	DBinfo *list;
	int    k, j, is_add_fail=0, api_f;
	$char  stmt_buf[300];

	int    rows, i;
	car547_t *alist;

	cm_buf_get("%s",DBName);
	cm_buf_get("%s %s %l",userid,itype,&rows);

	if (db_select(DBName) == False){
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True){
			return M_CM_DB_NOTOPEN;
		}
		else{
			return apiRC;
		}
	}
	
	alist = (car547_t *) malloc (rows * sizeof (car547_t));

	for (k=0;k<rows;k++){
		cm_buf_get("%s %s %s %s %d",icode1,icode2,ncode1,ncode2,&iorder);
		
		strcpy(alist[k].icode1 , icode1);
		strcpy(alist[k].icode2 , icode2);
		strcpy(alist[k].ncode1 , ncode1);
		strcpy(alist[k].ncode2 , ncode2);
		alist[k].iorder = iorder;
	}

	if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
	{
		if(exitsub(reply,M_CM_NOT_DBLIST) == True){
			return M_CM_NOT_DBLIST;
		}
		else{
			return apiRC;
		}
	}

	$WHENEVER SQLERROR CONTINUE;
	$BEGIN WORK;
	for(j=0;j<i;j++)
	{
		sprintf_s(stmt_buf,sizeof stmt_buf," INSERT INTO %s:ca_clm_code "
										   " (itype,icode1,icode2,ncode1,ncode2,iorder,icreate,dcreate,iupdate,dupdate) "
										   " VALUES (?,?,?,?,?,?,?,CURRENT,?,CURRENT) ", list[j].dbname);

		for (k=0; k<rows; k++){
			$PREPARE b_id FROM $stmt_buf;
			if(SQLCODE != 0){
			   is_add_fail = 3;
			   break;
			}
			strcpy(icode1 , alist[k].icode1);
			strcpy(icode2 , alist[k].icode2);
			strcpy(ncode1 , alist[k].ncode1);
			strcpy(ncode2 , alist[k].ncode2);
			iorder = alist[k].iorder;
			printf("itype[%s],icode1[%s],icode2[%s],ncode1[%s],ncode2[%s],iorder[%d]\n",itype,icode1,icode2,ncode1,ncode2,iorder);

			$EXECUTE b_id USING $itype,$icode1,$icode2,$ncode1,$ncode2,$iorder,$userid,$userid;

			if(SQLCODE != 0){
				is_add_fail = 3;
				break;
			}
		}
		if (is_add_fail == 3) {
			is_add_fail = 1;
			break;
		}

		cm_buf_init(ReplyBuf);
		cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
		tmp_len = cm_buf_len(ReplyBuf);
		if( j == i-1 ){
			api_f = api_OKComplete;
		}
		else{
			api_f = api_OK;
		}

		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False){
			is_add_fail = 2;
			break;
		}
	}
	free ( (char *) alist);
	if( is_add_fail == 1 ){
		goto errexit;
	}

	if( is_add_fail == 2 ){
		$ROLLBACK WORK;
		return apiRC;
	}

	$WHENEVER SQLERROR GOTO errexit;
	$COMMIT WORK;
	return api_OKComplete;

errexit:
	MsgCode = SQLCODE;
	$WHENEVER SQLERROR CONTINUE;    
	$ROLLBACK WORK;
	if (SQLCODE != 0){
		MsgCode = SQLCODE;
	}
	if(exitsub(reply,MsgCode) == True){
		return MsgCode;
	}
	else{
		return apiRC;
	}
}

/*************************************************************************/
long car547_single_query(reply)
serverReply reply;
{
	$char DBName[5];
	$char itype[3],icode1[21],icode2[21],ncode1[61],ncode2[61],ntype[61];
	$int  iorder=0;
	int  count=0,tmp_len=0;

	cm_buf_get("%s",DBName);

	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False){
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True){
			return M_CM_DB_NOTOPEN;
		}
		else{
			return apiRC;
		}
	}

	cm_buf_get("%s",itype);
	printf("******** itype[%s] \n",itype);
	   
	$DECLARE q_cur CURSOR FOR
	  SELECT itype, icode1, icode2, ncode1, ncode2, iorder
	    INTO $itype,$icode1,$icode2,$ncode1,$ncode2,$iorder
	    FROM ca_clm_code
	   WHERE itype=$itype
	ORDER BY itype,icode1;
	
	$OPEN q_cur;

	cm_buf_init(ReplyBuf); 
	cm_buf_res_msg();             /* reserve for MsgCode and count */
	cm_buf_res_count();          

	$SELECT ncode1 INTO $ntype
	   FROM ca_clm_code
	  WHERE itype = '00'
	    AND icode1=$itype;
		
	if(SQLCODE==SQLNOTFOUND) 
	{
		strcpy(ntype," ");
	}
	cm_buf_put("%s %s",itype,ntype);

	for(;;)
	{
		$FETCH q_cur;
		if (SQLCODE != 0){
			break;
		}

		cm_buf_put("%s %s %s %s %d",icode1,icode2,ncode1,ncode2,iorder);
		count++;
	}
	$CLOSE q_cur;
	$FREE q_cur;

	if (count > 0)   /* break out, at least one record is selected */
	{
		cm_buf_put_msg(M_CM_OK);
		cm_buf_put_count(count);
		tmp_len = cm_buf_len(ReplyBuf);
		
		if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False){
			return apiRC;
		}
		else{
			return api_OKComplete;
		}
	}
	else            /* break out, not any row is found */
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True){
			return M_CM_NOT_FOUND;
		}                 
		else{
			return apiRC;
		}
	}

errexit:
	return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/****************************************************************************/
long car547_multiple_query(reply)
serverReply reply;
{
	$char DBName[5];

	$char itype_get[3];
	$char itype[3],ncode1[61];
	
	char tmpbuf[4000];
	int  count=0,repbuf_len=0,tmp_len=0,replycnt=0;
	int  i; 


	cm_buf_get("%s",DBName);
	cm_buf_get("%s",itype_get);

	strcat(itype_get,'*');
	printf("itype_get[%s]\n",itype_get);

	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False){
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True){
			return M_CM_DB_NOTOPEN;
		}
		else{
			return apiRC;
		}
	}

	$DECLARE q_cur2 CURSOR FOR
	  SELECT DISTINCT itype
	    FROM ca_clm_code
	   WHERE itype MATCHES $itype_get
    ORDER BY itype; 

	$OPEN q_cur2;
	for(;;)
	{
		strcpy(itype," ");
		strcpy(ncode1," ");

		$FETCH q_cur2 INTO $itype;
		if(SQLCODE != 0) break;

		$SELECT ncode1 INTO $ncode1
		   FROM ca_clm_code
		  WHERE itype = '00'
			AND icode1=$itype;
			
		if(SQLCODE==SQLNOTFOUND) 
		{
			strcpy(ncode1," ");
		}

		printf("itype[%s],ncode1[%s]\n",itype,ncode1);

		cm_buf_init(tmpbuf); 
		if( count == 0 ){
			printf("### in count==0 \n");
			cm_buf_res_msg();             			/* reserve for MsgCode and count */
			cm_buf_res_count();          
		}

		cm_buf_put("%s %s",itype,ncode1);
		tmp_len = cm_buf_len(tmpbuf);
		if(tmp_len + repbuf_len < 3000){  			/* buffer size less than 4K */
			memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
			repbuf_len += tmp_len;
			count++;
		}
		else{                  						/* more than 4K, send to client side */ 
			cm_buf_init(ReplyBuf);
			cm_buf_put_msg(M_CM_OK);
			cm_buf_put_count(count);
			if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False){
				$CLOSE q_cur2;
				return apiRC;
			}else{  								/* clear ReplyBuf and count to start all over again */
				replycnt++;
				if(replycnt == 10){					/* more than 30K, client cannot display,error */
					cm_buf_init(ReplyBuf);
					cm_buf_put("%l",M_CM_OUT_SPACE);
					tmp_len = cm_buf_len(ReplyBuf);
					if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False){
						return apiRC;
					}
					else{
						return api_OKComplete;
					}
				}
				ReplyBuf[0] = '\0';
				count = 0;
				cm_buf_init(ReplyBuf);
				cm_buf_res_msg();           		/* reserve for MsgCode and count */
				cm_buf_res_count();    
				cm_buf_put("%s %s",itype,ncode1);
				repbuf_len = cm_buf_len(ReplyBuf);
				count++;
			}
		} 
	} /* for loop */
	$CLOSE q_cur2;
	$FREE q_cur2;

	if(count > 0){  								/* break out, at least one record is selected */
		cm_buf_init(ReplyBuf);
		cm_buf_put_msg(M_CM_OK);
		cm_buf_put_count(count);
		if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False){
			return apiRC;
		}
		else{
			return api_OKComplete;
		}
	}
	else{           								/* break out, not any row is found */
		if(exitsub(reply,M_CM_NOT_FOUND) == True){
			return M_CM_NOT_FOUND;
		}
		else{
			return apiRC;
		}
	}

errexit:
	return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/****************************************************************************/
long car547_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	$char DBName[5];

	$char olditype[3],oldicode1[21],oldicode2[21],oldncode1[61],oldncode2[61];
	$char userid[31],itype[3],icode1[21],icode2[21],ncode1[61],ncode2[61],ntype[61];
	$int  oldiorder=0, iorder=0;

	/* standard defined data */
	char option,*pos,*raw_ptr,cur_buf[40000],*comm;
	int  tmp_len,raw_len;
	long dummy=0,dum_cnt=0;
	long MsgCode;
	int  count=0, rows,i;
	DBinfo *list;
	int    k, j, is_del_fail=0, is_upd_fail=0;
	$char  stmt_buf[300];
	/* end of standard data */

	/* self defined data */
	char     rflag;
	car547_t *alist;
	/* end of self data */

	comm = (char *) command;
	cm_buf_init(command);
	cm_buf_get("%c %s",&option,DBName);

	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False){
		if (exitsub(reply,M_CM_DB_NOTOPEN) == True){
		   return M_CM_DB_NOTOPEN;
		}
		else{
		   return apiRC;
		}
	}

	if( (list=get_sysdb_list(&i,DBName)) == (char*)0 ){
		if(exitsub(reply,M_CM_NOT_DBLIST) == True){
			return M_CM_NOT_DBLIST;
		}
		else{
			return apiRC;
		}
	}
	/* compare old record and current record, if the record has not been changed  
	since last request, update or delete the record, otherwise return errmsg
	to client side */

	/* get old record info from command buffer */ 

	memcpy(&raw_len,&comm[com_len],sizeof(int));   
	pos = &comm[com_len+sizeof(int)];
	raw_ptr = malloc(raw_len);
	if (raw_ptr != (char*)0){
		memcpy(raw_ptr,pos,raw_len);
	}
	else{
		if(exitsub(reply,M_CM_NOT_MALLOC) == True){   /* malloc fail */ 
			return M_CM_NOT_MALLOC;
		}
		else{
			return apiRC;
		}
	}

	cm_buf_init(raw_ptr);          /* get index key from old record */
	cm_buf_get("%l %l",&dummy,&dum_cnt);
	cm_buf_get("%s",olditype);
	printf(">>>>update: olditype[%s]\n",olditype);

	$BEGIN WORK;

	printf(">>>>1\n");
	$WHENEVER SQLERROR GOTO errexit;

	printf(">>>>42\n");
	$DECLARE q1_cur CURSOR FOR
	 SELECT itype,icode1,icode2,ncode1,ncode2,iorder
	   INTO $itype,$icode1,$icode2,$ncode1,$ncode2,$iorder
	   FROM ca_clm_code
	  WHERE itype=$olditype
	  ORDER BY itype,icode1;

	$OPEN q1_cur;

	$SELECT ncode1 INTO $ntype
	   FROM ca_clm_code
	  WHERE itype = '00'
	    AND icode1=$olditype;
	if(SQLCODE==SQLNOTFOUND)
	{
		strcpy(ntype," ");  					/* maggie 871215 */
	}

	printf(">>>>5\n");
	cm_buf_init(cur_buf);
	cm_buf_res_msg();             				/* reserve for MsgCode and count */
	cm_buf_res_count();          
	cm_buf_put("%s %s",olditype,ntype);
	for(;;)
	{
		$FETCH q1_cur;

		if(SQLCODE != 0){
			break;
		}

		cm_buf_put("%s %s %s %s %d", icode1, icode2, ncode1, ncode2, iorder);
		count++;
	}

	/* if key value has been changed then SQLNOTFOUND,else put current value
	 into cur_buf for comparison */ 

	printf(">>>>6\n");
	if (count == 0)
	{
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		$CLOSE q1_cur;
		if(exitsub(reply,M_CM_NOT_FOUND) == True){
			return M_CM_NOT_FOUND;
		}                 
		else{
			return apiRC;
		}
	}

	printf(">>>>7\n");
	$CLOSE q1_cur;
	$WHENEVER SQLERROR GOTO errexit;

	cm_buf_init(cur_buf);
	cm_buf_put_msg(dummy);
	cm_buf_put_count(count);

	/*------------------------------------------------------------------
	if (memcmp(cur_buf,raw_ptr,raw_len) != 0)  * compare 2 records, not equal * 
	{
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		if(exitsub(reply,M_CM_NOT_EQUAL) == True){
			return M_CM_NOT_EQUAL;
		}                 
		else{
			return apiRC;
		}
	}
	*----------------------------------------------------------------- */
	$WHENEVER SQLERROR GOTO errexit;

	/* equal, then exec DB operation */

	if ( option == 'D' )
	{
		for(j=0;j<i;j++)
		{
			sprintf_s(stmt_buf,sizeof stmt_buf,"DELETE FROM %s:ca_clm_code WHERE itype=? ", list[j].dbname); 
			$PREPARE d_id FROM $stmt_buf;
			if(SQLCODE != 0){
				is_del_fail = 1;
				break;
			}
			$EXECUTE d_id USING $olditype;
			if(SQLCODE != 0){
				is_del_fail = 1; 
				break;
			}
			#ifdef DEBUG 
			printf("Delete %d\n", j+1);
			#endif
		}/* for loop */

		if( is_del_fail ) goto errexit;

		cm_buf_init(ReplyBuf);
		cm_buf_put("%l",M_CM_OK);
		tmp_len = cm_buf_len(ReplyBuf);
		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
		{
			$WHENEVER SQLERROR CONTINUE;
			$ROLLBACK WORK;
			return apiRC;
		}  

		$WHENEVER SQLERROR GOTO errexit;
		$COMMIT WORK;
		return api_OKComplete;
	}
	else if (option == 'U')
	{
		printf(">>>>8\n");
		cm_buf_init(command);
		cm_buf_get("%c %s",&option,DBName);
		cm_buf_get("%s %s %l",userid,itype,&rows);

		alist = (car547_t *) malloc (rows * sizeof (car547_t));
		for (k=0;k<rows;k++) {
			cm_buf_get("%c %s %s %s %s %d %s %s %s %s %d",&rflag,oldicode1,oldicode2,oldncode1,oldncode2,&oldiorder,icode1,icode2,ncode1,ncode2,&iorder);
			alist[k].type = rflag;
			printf(">>>>9 alist[%d].type=%c\n",k,alist[k].type);
			strcpy(alist[k].oldicode1 , oldicode1);
			strcpy(alist[k].oldicode2 , oldicode2);
			strcpy(alist[k].oldncode1 , oldncode1);
			strcpy(alist[k].oldncode2 , oldncode2);
			alist[k].oldiorder = oldiorder;
			strcpy(alist[k].icode1 , icode1);
			strcpy(alist[k].icode2 , icode2);
			strcpy(alist[k].ncode1 , ncode1);
			strcpy(alist[k].ncode2 , ncode2);
			alist[k].iorder = iorder;
		}
		/************/
		$WHENEVER SQLERROR CONTINUE;
		printf("Braek 850 [%d][%d]\n",i,rows);

		for(j=0;j<i;j++)
		{
			for (k = 0; k < rows && is_upd_fail != 3; k++){
				strcpy(oldicode1 , alist[k].oldicode1);
				strcpy(oldicode2 , alist[k].oldicode2);
				strcpy(oldncode1 , alist[k].oldncode1);
				strcpy(oldncode2 , alist[k].oldncode2);
				oldiorder = alist[k].oldiorder;
				strcpy(icode1 , alist[k].icode1);
				strcpy(icode2 , alist[k].icode2);
				strcpy(ncode1 , alist[k].ncode1);
				strcpy(ncode2 , alist[k].ncode2);
				iorder = alist[k].iorder;
				printf(">>>>10 alist[%d].type=%c,list[%d].dbname=[%s],icode1[%s,old->%s],icode2[%s,old->%s]\n",k,alist[k].type,j,list[j].dbname,icode1,oldicode1,icode2,oldicode2);
				switch(alist[k].type){
					case 'A': 
						sprintf_s(stmt_buf,sizeof stmt_buf," INSERT INTO %s:ca_clm_code "
														   " (itype,icode1,icode2,ncode1,ncode2,iorder,icreate,dcreate,iupdate,dupdate) "
														   " VALUES (?,?,?,?,?,?,?,CURRENT,?,CURRENT) ", list[j].dbname);
						$PREPARE u1_id FROM $stmt_buf;
						if(SQLCODE != 0){
							is_upd_fail = 3; 
							break;
						}
						$EXECUTE u1_id USING $itype,$icode1,$icode2,$ncode1,$ncode2,$iorder,$userid,$userid;
						if(SQLCODE != 0){
							is_upd_fail = 3;
						}
						break;
					case 'D':
						sprintf_s(stmt_buf,sizeof stmt_buf," DELETE FROM %s:ca_clm_code WHERE itype=? AND icode1=? AND icode2=? ",list[j].dbname);
						printf("stmt_buf[%s]\n",stmt_buf);
						$PREPARE u2_id FROM $stmt_buf;
						if(SQLCODE != 0){
							is_upd_fail = 3; 
							break;
						}
						$EXECUTE u2_id USING $olditype,$oldicode1,$oldicode2;
						if(SQLCODE != 0){
							is_upd_fail = 3;
						}
						break; 
					case 'U':
						sprintf_s(stmt_buf,sizeof stmt_buf, " UPDATE %s:%s SET (%s)=(%s) %s ",
															  list[j].dbname,"ca_clm_code ",
															" icode1,icode2,ncode1,ncode2,iorder,iupdate,dupdate ",
															" ?,?,?,?,?,?,CURRENT ",
															" WHERE itype=? AND icode1=? AND icode2=? ");
						printf("stmt_buf[%s]\n",stmt_buf);
						$PREPARE u3_id FROM $stmt_buf;
						if(SQLCODE != 0) {
							is_upd_fail = 3; 
							break;
						}
						$EXECUTE u3_id USING $icode1,$icode2,$ncode1,$ncode2,$iorder,$userid,$olditype,$oldicode1,$oldicode2;
						printf("==>SQLCODE %d\n",SQLCODE);
						if(SQLCODE != 0){
							is_upd_fail = 3;
						}
						break;
					default:
						$WHENEVER SQLERROR CONTINUE;
						$ROLLBACK WORK;
						if(exitsub(reply,M_CM_WRONG_OPTION) == True){
							return M_CM_WRONG_OPTION;
						}
						else{
							return apiRC;
						}
				}
			} 	/* end for (k = 0... */
			
			if (is_upd_fail == 3){
				is_upd_fail = 1;
				break;
			}
			sprintf_s(stmt_buf,sizeof stmt_buf, " UPDATE %s:ca_clm_code SET (itype) = (?) WHERE itype= ? ", list[j].dbname);
			$PREPARE u4_id FROM $stmt_buf;
			
			if(SQLCODE != 0){
				is_upd_fail = 1; 
				break;
			}
			$EXECUTE u4_id USING $itype,$olditype;
			if(SQLCODE != 0){
				is_upd_fail = 1; 
				break;
			}
			#ifdef DEBUG 
			printf("Update %d\n", j+1);
			#endif
		} 	/* for loop */

		free((char *) alist);
		if( is_upd_fail ==1) goto errexit;
		/************/

		cm_buf_init(ReplyBuf);
		cm_buf_put("%l",M_CM_OK);
		tmp_len = cm_buf_len(ReplyBuf);
		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False){
			$WHENEVER SQLERROR CONTINUE;
			$ROLLBACK WORK;
			free(raw_ptr);
			return apiRC;
		}

		$WHENEVER SQLERROR GOTO errexit;
		$COMMIT WORK;
		free(raw_ptr);
		return api_OKComplete;
	}
	else
	{
		if(exitsub(reply,M_CM_WRONG_OPTION) == True){
		   free(raw_ptr);
		   return M_CM_WRONG_OPTION;
		}
		else{
			free(raw_ptr);
			return apiRC;
		}
	} 

errexit:
	$WHENEVER SQLERROR CONTINUE;
	MsgCode = SQLCODE;
	$ROLLBACK WORK;
	if (SQLCODE != 0){
		MsgCode = SQLCODE;
	}
	if(exitsub(reply,MsgCode) == True){
		return MsgCode;
	}
	else{
		return apiRC;
	}
}

/***************************************************************************/
long select_code_data_itype_name(reply)
serverReply reply;
{
	$char DBName[5],itype[3],icode1[21],ncode1[61];
	int   tmp_len;

	cm_buf_get("%s %s",DBName,itype);
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False)
	{
		if (exitsub(reply,M_CM_DB_NOTOPEN) == True){
		   return M_CM_DB_NOTOPEN;
		}
		else{
		   return apiRC;
		}
	}

	$SELECT ncode1
	   INTO $ncode1
	   FROM ca_clm_code
	  WHERE itype = '00'
	    AND icode1 = $itype;
	
	if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True){
			return M_CM_NOT_FOUND;
		}                 
		else{
			return apiRC;
		}
	}
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l %s",M_CM_OK,ncode1);

	tmp_len = cm_buf_len(ReplyBuf);
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False){
		return apiRC;
	}
	else{
		return api_OKComplete;
	}

errexit:
	return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

