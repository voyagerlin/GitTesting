/**********************************************************************/
/*   program id   : ca353q01s.ec                                      */
/*   program name : �s�w�F�ʮ��W�����O�I-���I�O��ֹ�q���H�o�@�~     */
/*   date written : 2020/07/01                                        */
/*   shell        : car353_email                                      */
/*   exec time    :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"
#include "safeclib.h"

char  	outputf[ N_FILE+1];
$char  	userid[11],sDdate[11];
char  	ddate[11];

static char *get_car_full_db();
static char *get_car_short_db();
static char *only_comp_email();
static char *only_rand_email();
static char *comp_rand_email();
static char *only_volu_email_IC(); /* �~�ȭ��O��ڶ����Τ��� */
static char *comp_volu_email_IC(); /* �~�ȭ��O��ڶ����Τ��� */
static char *car353_SMS_IC();   /* �~�ȭ��O��ڶ����Τ��� */


$char	DBName[5];
DBinfo  *list;
    
int     count_db,i;
int IC = 0;
FILE    *fp, *sfp;
char    sApHome[30];
$char   fname[60];
$char   filename[121];
$char	ftitle[1024];
$char   fname_SMS_IC[128];
$char   filename_SMS_IC[256];


$char 	mbuf[9000];
$loc_t 	ctxt;

$char	stmt[4096];
char	msgbuf[100];


$int 	mail_count,count=0, count_IC = 0;
int SMS_count = 0;

$char	 itmp_policy[21],ipolicy[21],icard1[21],itag[CA_TAG_NUM],fassured[2],dpolicy[11],iroute[21];
$char    tmp_dpolicy[11];
$varchar nassured[121],sNassured[121];
$char	 iofficer[11],nofficer[11],ileader[11],nleader[11],nmail_type[11];
$int     mpremium;
$char    cdate1[11],cdate2[11];
char     yy_fn[4], mm_fn[3], dd_fn[3];
char     dbgn[11],dend[11];
    
/* asempl */
$char	 email[51],chinese_name[15];
$char    Full_DB[20];
$char    stmt_tmp[1024],stmt_tmp2[1024],stmt_tmp3[1024];
/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int   rc;
    
    
    $char syear[5];
	
	$char smonth[5];
	$int day_chk = 0;
	int tmp_month = 0;
	$int day_control = 0;
    
    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(ddate,   isNULLstr(argv[3])); /* cyy/mm/dd */
    strcpy(outputf, isNULLstr(argv[4]));
    
    
    sfp =  (FILE *)STARTLOG();
    
    
    strcpy(sDdate,cm_to_infdate(ddate));
    printf("-----sDdate : [%s]\n-----",sDdate);
    


    
    mail_count = 0;
    
    rc = car353_get_db();
    if (rc != M_CM_OK) {
        printf("error on car353_get_db\n");
        return rc;
    }
    
    
    memset(fname,0x00,sizeof(fname));
    memset(filename,0x00,sizeof(filename));
    memset(fname_SMS_IC, 0x00, sizeof(fname_SMS_IC));
    memset(filename_SMS_IC, 0x00, sizeof(filename_SMS_IC));
    
    
    /* �P�_�������O�_��1�B4�B7�B10��25��*/
    /* �C�u����@���A1�B4�B7�B10��25��~�H�e*/
    cm_split_ymd(ddate,yy_fn,mm_fn,dd_fn);
    printf("yy_fn[%s]mm_fn[%s]dd_fn[%s]\n",yy_fn,mm_fn,dd_fn);
    
    if ( (strncmp(mm_fn,"01",2)==0 || strncmp(mm_fn,"04",2)==0  || strncmp(mm_fn,"07",2)==0 || strncmp(mm_fn,"10",2)==0 ) && strncmp(dd_fn,"25",2)==0 )
    {
    	printf("1�B4�B7�B10��25��A���H�eEmail\n");
    	
    	if(strncmp(mm_fn,"01",2)==0 )
    	{
    	    strcpy(dbgn,"10/01/");
    	    strcpy(dend,"12/31/");
    	    $SELECT FIRST 1 to_char(YEAR(today)-1) INTO $syear FROM systables ;
    	    strcpy(syear,trim(syear));
    	    strcat(dbgn,syear);
            strcat(dend,syear);
            sprintf_s(fname,sizeof fname,"%s�~�ĥ|�u���I�O��ֹ�q���H�e����",syear);
            printf("dbgn[%s],dend[%s]",dbgn,dend);
    	}
    	else if (strncmp(mm_fn,"04",2)==0 )
    	{
    	    strcpy(dbgn,"01/01/");
    	    strcpy(dend,"03/31/");
    	    $SELECT FIRST 1 to_char(YEAR(today)) INTO $syear FROM systables ;
    	    strcpy(syear,trim(syear));
    	    strcat(dbgn,syear);
    	    strcat(dend,syear);	
    	    sprintf_s(fname,sizeof fname,"%s�~�Ĥ@�u���I�O��ֹ�q���H�e����",syear);
    	    printf("dbgn[%s],dend[%s]",dbgn,dend);
    	}
    	else if (strncmp(mm_fn,"07",2)==0 )
    	{
    	    strcpy(dbgn,"04/01/");
    	    strcpy(dend,"06/30/");	
    	    $SELECT FIRST 1 to_char(YEAR(today)) INTO $syear FROM systables ;
    	    strcpy(syear,trim(syear));
    	    strcat(dbgn,syear);
    	    strcat(dend,syear);
    	    sprintf_s(fname,sizeof fname,"%s�~�ĤG�u���I�O��ֹ�q���H�e����",syear);
    	    printf("dbgn[%s],dend[%s]",dbgn,dend);
    	}	
    	else if (strncmp(mm_fn,"10",2)==0 )
    	{
    	    strcpy(dbgn,"07/01/");
    	    strcpy(dend,"09/30/");	
    	    $SELECT FIRST 1 to_char(YEAR(today)) INTO $syear FROM systables ;
    	    strcpy(syear,trim(syear));
    	    strcat(dbgn,syear);
    	    strcat(dend,syear);
    	    sprintf_s(fname,sizeof fname,"%s�~�ĤT�u���I�O��ֹ�q���H�e����",syear);
    	    printf("dbgn[%s],dend[%s]",dbgn,dend);
    	}
    	

    
    	
    	/* ��temp table (car353) */        
        rc = car353_init_data();
        if (rc != M_CM_OK) {
            printf("error on car353_init_data\n");
            return rc;
        }
        
        /* �d�߱H�e��� */        
        rc = car353_ply_data();
        if (rc != M_CM_OK) {
            printf("error on car353_ply_data\n");
            EWRITE(userid, rc, "�d�߫O���Ʀ��~!");
            return rc;
        }       
        
        /* ���s�n�H���O�᪺EMAIL*/
        rc = car353_send_email_customer(); 
        if (rc != M_CM_OK) {
            printf("error on car353_send_email_customer\n");
            EWRITE(userid, rc, "�H�oE-mail�q���O�ᦳ�~!");
            return rc;
        } 
        
        /* ���s�n�H���ӫO����EMAIL�Ϊ���*/
    	sprintf_s(filename,sizeof filename,"%s/rptftp/%s.csv",sApHome,fname);
        fp=fopen(filename,"w");          
        
        rc = car353_send_email_empl(); 
        if (rc != M_CM_OK) {
            printf("error on car353_send_email_empl\n");
            EWRITE(userid, rc, "�H�oE-mail�q���ӫO�����~!");
            return rc;
        }
        EWRITE(userid, rc, "1�B4�B7�B10��25��A�H�eEmail\n");    
        return M_CM_OK;
    }
	else if(strncmp(dd_fn,"10",2)==0)
	{
		printf("�~�ȭ��O��ڶ����Τ����W�w�A�C�Ӥ�10��A���H�eEmail�P²�T\n");
		IC = 1;
		
		if(strcmp(mm_fn, "01") == 0)
		{
			strcpy(smonth, "12");
			$SELECT FIRST 1 to_char(YEAR(today)-1) INTO $syear FROM systables;
		}
		else
		{
			tmp_month = atoi(mm_fn);
			tmp_month--;
			
			sprintf_s(smonth, sizeof smonth, "%02d", tmp_month);
			
			$SELECT FIRST 1 to_char(YEAR(today)) INTO $syear FROM systables;
		}
		
		sprintf_s(dpolicy, sizeof dpolicy, "%s/15/%s", smonth, syear);
		
		printf("dpolicy = [%s]\n", dpolicy);
		
		day_control = 0;
		
		while(1) /* �T�{ñ���O�_���u�@�� */
		{
			if(day_control <= -15)
			{
				printf("��ƨӷ������묰�D�u�@��A������Ƶ{\n");
				EWRITE(userid, rc, "��ƨӷ������묰�D�u�@��A������Ƶ{\n");
				return M_CM_OK;
			}
			sprintf_s(stmt_tmp, sizeof stmt_tmp, 
			        " SELECT dwork FROM cm_wrktbl"
					"  WHERE (dwork = DATE('%s') + interval(%d) DAY TO DAY) "
					"    AND fwork = 0 ", dpolicy, day_control);
			
			printf("stmt_tmp = [%s]\n", stmt_tmp);
			
			$PREPARE pre_q1 FROM $stmt_tmp;
			$EXECUTE pre_q1 INTO $tmp_dpolicy;
			
			if(SQLCODE == SQLNOTFOUND) 
			{
				if(day_control >= 0)
				{
					day_control++;
				}
				else 
				{
					day_control--;
				}
				
				continue;
			}
			
			$SELECT count(*) INTO $day_chk
			   FROM cm_wrktbl
			  WHERE dwork = today
				AND YEAR(DATE($tmp_dpolicy)) = YEAR(DATE($dpolicy))
				AND MONTH(DATE($tmp_dpolicy)) = MONTH(DATE($dpolicy));
			
			if(day_chk > 0) break;
			else day_control = -1;
		}
		
		$FREE pre_q1;
		$CLOSE pre_c1;
		
		strcpy(dpolicy, tmp_dpolicy);
		printf("final_dpolicy = [%s]\n", dpolicy);
		
		/* ��temp table (car353) */        
        rc = car353_init_data();
        if (rc != M_CM_OK) {
            printf("error on car353_init_data\n");
            return rc;
        }
		
		/* �d�߱H�e��� */        
        rc = car353_ply_data_IC();
        if (rc != M_CM_OK) {
            printf("error on car353_ply_data_IC\n");
            EWRITE(userid, rc, "�d�߫O���Ʀ��~!");
            return rc;
        }
		
		/* ���s�n�H���O�᪺EMAIL*/
        rc = car353_send_email_SMS_customer_IC(); 
        if (rc != M_CM_OK) {
            printf("error on car353_send_email_SMS_customer_IC\n");
            EWRITE(userid, rc, "�H�oE-mail�q���O�ᦳ�~!");
            return rc;
        }
		
		sprintf_s(fname,sizeof fname,"%s�~%s�먮�I�O��ֹ�q���H�e����",syear, smonth);
		sprintf_s(filename,sizeof filename,"%s/rptftp/%s.csv",sApHome,fname);
        fp=fopen(filename,"w");
        
		/* ���s�n�H���ӫO����EMAIL�Ϊ��� */
        rc = car353_send_email_empl_IC(); 
        if (rc != M_CM_OK) {
            printf("error on car353_send_email_empl_IC\n");
            EWRITE(userid, rc, "�H�oE-mail�q���ӫO�����~!");
            return rc;
        }
		
	}
    else
    {
    	
    	EWRITE(userid, rc, "�D1�B4�B7�B10��25��A�B�D�C�Ӥ�10��A���H�eEmail\n");
    	return M_CM_OK;
    }
    
        
    WRITELOG( sfp, "���槹��");
    ENDLOG(sfp);
    return M_CM_OK;


    

    printf("[car353]:process ok!\n"); 
}
/*----------------------------------------------------------------------------*/
long car353_get_db()
{
    int	rc;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
       return M_CM_DB_NOTOPEN;
    }
    
    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }
    
    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
    }

    return M_CM_OK;
}
/*----------------------------------------------------------------------------*/
long car353_init_data()
{
    $whenever sqlerror goto errexit;
	
	if(IC == 1)
	{
		sprintf_s(stmt_tmp,sizeof stmt_tmp,
			"create temp table car353 ( "
			"  ipolicy_1	   char(20), "
			"  ipolicy_2	   char(20), "
			"  itmp_policy     char(20), "
			"  itag            char(%d), "
			"  aemail_appl     varchar(50), "
			"  tmobile_appl    varchar(20), "
			"  iapplicant      char(12), "
			"  napplicant      varchar(120) "
			")with no log;",CA_TAG_NUM-1);
	}
	else
	{
		sprintf_s(stmt_tmp,sizeof stmt_tmp,
                "create temp table car353 ( "
		"  ipolicy_1	   char(20), "
		"  ipolicy_2	   char(20), "
                "  itag            char(%d), "
                "  aemail_appl     varchar(50), "
                "  iapplicant      char(12), "
                "  napplicant      varchar(120) "
                ")with no log;",CA_TAG_NUM-1);
	}
	
     $PREPARE stmp FROM $stmt_tmp;
     $EXECUTE stmp;


     strcpy(stmt_tmp2,
          "create temp table car353_ins (     "
		  " ipolicy	            char(20),     "
		  " row_no              serial,       "
		  " ins_type_print      char(35),     "
		  " ncover_print        varchar(150), "
		  " mcover_print        varchar(150), "
          " mins_premium_print  varchar(150)  "
          "      )with no log;");
     $PREPARE stmp2 FROM $stmt_tmp2;
     $EXECUTE stmp2;
     
	 if(IC == 1)
	 {
		strcpy(stmt_tmp3,
                 "create temp table car353_email_log ( "
                 " ipolicy_c         char(20), "
                 " ipolicy_r         char(20), "
                 " nreceiver         varchar(120), "
                 " aemail_receiver   varchar(50), "
				 " tmobile_receiver  char(20),"
                 " inumber           char(12) "
                 " )with no log;");
	 }
	 else
	 {
       strcpy(stmt_tmp3,
                 "create temp table car353_email_log ( "
                 " ipolicy_c         char(20), "
                 " ipolicy_r         char(20), "
                 " nreceiver         varchar(120), "
                 " aemail_receiver   varchar(50), "
                 " inumber           char(12) "
                 " )with no log;");
	 }
     $PREPARE stmp3 FROM $stmt_tmp3;
     $EXECUTE stmp3;   




	
    return M_CM_OK;

errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car353_init_data_IC()
{
	
	$whenever sqlerror goto errexit;
	
	
	
	return M_CM_OK;

errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car353_ply_data()
{
    int	rc;
    $int  chk1,chk2;
    $char stmt1_1[1024],stmt1_2[1024],stmt2[1024],stmt2_1[1024],stmt3[1024],stmt3_1[1024];
    $char ipolicy_1[21],ipolicy_2[21];

    
    $whenever sqlerror goto errexit;
   
    /*�d�߱H�e���*/
    /*(1) �O�I�~�ȭ��q��(�O�o�q��10)
      (2) �Q�O�I�H���۵M�H
      (3) �n�O�H�d��Email��ƪ�
      (4) �H�o���ɥ��h�O�O��
      (5) �H�o���ɥ�����O��
    */

   
    for(i=0;i<count_db;i++) 
    {    
        
        
        sprintf_s(stmt1_1,sizeof stmt1_1,
                    " INSERT INTO car353 "
                    " SELECT nvl(b.ipolicy,'') ,nvl(b.irelative_ply,'') ,a.itag ,a.aemail_appl, a.iapplicant, a.napplicant  "
                    "   FROM %s:policy a,%s:ply_relation b "
                    "  WHERE b.dpolicy BETWEEN '%s' AND '%s' "
                    "    AND a.ipolicy=b.ipolicy AND b.bzfrom='10' AND a.fassured IN('1','3','5')"
                    "    AND a.aemail_appl<>'' AND b.dply_end>=today "
                    "    AND b.fcard_class='1' "

                    ,list[i].dbname,list[i].dbname,dbgn,dend);
        printf("stmt1_1[%s]\n",stmt1_1);
        $PREPARE pre1_1 FROM $stmt1_1;    
        $EXECUTE pre1_1;

        sprintf_s(stmt1_2,sizeof stmt1_2,  
                    " INSERT INTO car353 "
                    " SELECT nvl(b.irelative_ply,''),nvl(b.ipolicy,''),a.itag,a.aemail_appl, a.iapplicant, a.napplicant "
                    "   FROM %s:policy a,%s:ply_relation b"
                    "  WHERE b.dpolicy BETWEEN '%s' AND '%s' "
                    "    AND a.ipolicy=b.ipolicy AND b.bzfrom='10' AND a.fassured IN('1','3','5')"
                    "    AND a.aemail_appl<>'' AND b.dply_end>=today"
                    "    AND b.fcard_class='2' "
                    ,list[i].dbname,list[i].dbname,dbgn,dend);
        printf("stmt1_2[%s]\n",stmt1_2);
        $PREPARE pre1_2 FROM $stmt1_2;    
        $EXECUTE pre1_2;

    }  
	
    /*�M���w�h�O�O��-�j���I*/
    strcpy(stmt2," SELECT DISTINCT ipolicy_1 "
                  "  FROM car353 "
                  " WHERE ipolicy_1 <> '' ");
                 
    printf("stmt2[%s]\n",stmt2);
    $PREPARE prep2 FROM $stmt2;
    $DECLARE curs2 CURSOR FOR prep2;
    $OPEN curs2;
    for(;;)
    {

        $FETCH curs2 INTO $ipolicy_1;
        
        
        if( SQLCODE == SQLNOTFOUND) break;
        printf("ipolicy_1[%s]\n",ipolicy_1);
        
        strcpy(Full_DB,"");
        strcpy(Full_DB,get_car_full_db(ipolicy_1));
        
        chk1 = 0;
        
        sprintf_s(stmt2_1,sizeof stmt2_1, " SELECT count(*) "
                         "   FROM %s:ply_ins_type "
                         "  WHERE ipolicy='%s' AND mdamage_cover = 0 ",Full_DB,ipolicy_1);
                        
        printf("stmt2_1[%s]\n",stmt2_1);    
        $PREPARE prep2_1 from $stmt2_1;
        $EXECUTE prep2_1 INTO $chk1; 
        
        if(chk1>0)  /*�j��0���ܤw�h�O*/
        {
            $UPDATE car353 SET ipolicy_1='' WHERE ipolicy_1=$ipolicy_1;
        }   

    }
    $FREE prep2;
    $CLOSE curs2;
    
    /*�M���w�h�O�O��-���N�I*/
    strcpy(stmt3," SELECT DISTINCT ipolicy_2 "
                  "  FROM car353 "
                  " WHERE ipolicy_2 <> '' ");
                 
    printf("stmt3[%s]\n",stmt3);
    $PREPARE prep3 FROM $stmt3;
    $DECLARE curs3 CURSOR FOR prep3;
    $OPEN curs3;
    for(;;)
    {

        $FETCH curs3 INTO $ipolicy_2;
        
        
        if( SQLCODE == SQLNOTFOUND) break;
        printf("ipolicy_2[%s]\n",ipolicy_2);
        
        strcpy(Full_DB,"");
        strcpy(Full_DB,get_car_full_db(ipolicy_2));
        
        chk2 = 0;
        
        sprintf_s(stmt3_1,sizeof stmt3_1, " SELECT sum(mdamage_cover) "
                         "   FROM %s:ply_ins_type "
                         "  WHERE ipolicy='%s' ",Full_DB,ipolicy_2);
                         
        $PREPARE prep3_1 from $stmt3_1;
        $EXECUTE prep3_1 INTO $chk2; 
        
        if(chk2==0)  /*����0���ܥ����I�جҤw�h�O*/
        {
            $UPDATE car353 SET ipolicy_2='' WHERE ipolicy_2=$ipolicy_2;
        }   

    }
    $FREE prep3;
    $CLOSE curs3;
    
    /*�R���j���ҧ����h�O�����*/
    $DELETE FROM car353 WHERE ipolicy_1='' AND ipolicy_2='';
	
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car353_ply_data_IC()
{
	int	rc;
    $int  chk1,chk2,chk3;
    $char stmt1_1[2048],stmt2[1024],stmt2_1[1024],stmt2_2[1024],stmt3[1024],stmt3_1[1024];
    $char ipolicy_1[21],ipolicy_2[21], itmp_policy[21];
	
	$whenever sqlerror goto errexit;
	
	/* �d�߱H�e��� */
	/*
	(1) ���q��(�ư�JB)
	(2) �Q�O�I�H���۵M�H�Ϊk�H
	(3) �n�O�H�d��Email�Τ����ƪ�(�G�̬Ҧ��d�̶ȱH�eEMAIL)
	(4) �H�o���ɥ��h�O�O��
	(5) �H�o���ɥ�����O��
	(6) �ư���j
	(7) �ư��q�l�O��P�e�~�ȥ��O��
	(8) �ư��H�Υdú�O��(�t�u�Wú�O���ΤH�u��d)
	*/
	
	for(i=0; i<count_db; i++)
	{
		sprintf_s(stmt1_1, sizeof stmt1_1, 
		          " INSERT INTO car353 "
				  "SELECT nvl(b.ipolicy,''), nvl(b.irelative_ply,''), b.itmp_policy, a.itag, a.aemail_appl, "
				  "       a.tmobile_appl, a.iapplicant, a.napplicant "
				  " FROM %s:policy a, %s:ply_relation b, ao_prercv_pass c, ao_prercv_detail d"
				  " WHERE a.ipolicy = b.ipolicy "
				  " AND b.itmp_policy = c.ipre_rcv "
				  " AND c.ipre_rcv = d.ipre_rcv "
				  " AND c.iins_kind = '2' "
				  " AND c.iins_kind = d.iins_kind "
				  " AND d.ipre_end = '' "
				  " AND d.fstatus = 'Y' "
				  " AND a.ipolicy[6,7] <> 'VW' "
				  " AND a.iroute <> 'JB' "
				  " AND (a.aemail_appl <> '' OR a.tmobile_appl <> '') "
				  " AND ((SELECT sum(mdamage_cover) FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy) > 0) "
				  " AND b.dply_end >= today "
				  " AND b.dply_close IS NOT NULL  "
				  " AND b.fcard_class = '2' "
				  " AND b.feply <> '1' AND b.fout_print <> '1' "
				  " AND d.itype_prem NOT IN ('7', 'I', 'J', 'H', 'P') "
				  " AND b.dpolicy = '%s' ", list[i].dbname, list[i].dbname, list[i].dbname, dpolicy);
		
		printf("stmt1_1 = [%s]\n", stmt1_1);
		$PREPARE pre1_1 FROM $stmt1_1;
		$EXECUTE pre1_1;
	}
	
	/* �ˬd�j���I���A */
	sprintf_s(stmt2, sizeof stmt2,
	          " SELECT DISTINCT ipolicy_2, itmp_policy FROM car353 WHERE ipolicy_2 <> '' ");
			  
	printf("stmt2 = [%s]\n", stmt2);
	$PREPARE pre2 FROM $stmt2;
	$DECLARE cur2 CURSOR FOR pre2;
	$OPEN cur2;
	
	while(1)
	{
		$FETCH cur2 INTO $ipolicy_2, $itmp_policy;
		
		if(SQLCODE == SQLNOTFOUND) break;
		
		printf("ipolicy_2 = [%s]\n", ipolicy_2);
		strcpy(Full_DB, "");
		strcpy(Full_DB, get_car_full_db(ipolicy_2));
		
		chk1 = 0;
		
		sprintf_s(stmt2_1, sizeof stmt2_1, 
		          " SELECT count(*) FROM %s:ply_ins_type a, %s:ply_relation b "
				  "  WHERE a.ipolicy = b.ipolicy "
				  "    AND a.ipolicy = '%s' "
				  "    AND a.mdamage_cover > 0 "
				  "    AND b.dply_end >= today ", Full_DB, Full_DB, ipolicy_2);
		
		printf("stmt2_1 = [%s]\n", stmt2_1);
		$PREPARE pre2_1 FROM $stmt2_1;
		$EXECUTE pre2_1 INTO $chk1;
		
		if(chk1 <= 0) /* �p�󵥩�0���ܤw�h�O�Τw��� */
		{
			$UPDATE car353 SET ipolicy_2 = '' WHERE ipolicy_2 = $ipolicy_2;
			continue;
		}
		
		chk2 = 0;
		
		sprintf_s(stmt2_2, sizeof stmt2_2,
		          " SELECT count(*) FROM %s:ply_relation"
				  "  WHERE ipolicy = '%s' "
				  "    AND itmp_policy = '%s' ", Full_DB, ipolicy_2, itmp_policy);
		
		printf("stmt2_2 = [%s]\n", stmt2_2);
		
		$PREPARE pre2_2 FROM $stmt2_2;
		$EXECUTE pre2_2 INTO $chk2;
		
		if(chk2 <= 0) /* �p�󵥩�0���ܻP���p���N�I�����P������ */
		{
			$UPDATE car353 SET ipolicy_2 = '' WHERE ipolicy_2 = $ipolicy_2;
			continue;
		}
		
		chk3 = 0;
		
		$SELECT count(*) INTO $chk3
		   FROM cm_pre_receive 
		  WHERE ipolicy1 = $ipolicy_2
		    AND ipre_rcv = $itmp_policy
			AND fstatus IN (50, 60);
		
		printf("�ˬd�j���I�O�_���O [%s]\n", ipolicy_2);
			
		if(chk3 <= 0) /* �p�󵥩�0���ܥ����O */
		{
			$UPDATE car353 SET ipolicy_1 = '', ipolicy_2 = '' WHERE ipolicy_2 = $ipolicy_2;
		}
	}
	
	$FREE pre2;
	$CLOSE cur2;
	
	/* �R���j+���O�渹�ҨS���Ȫ���� */
	$DELETE FROM car353 WHERE ipolicy_1 = '' AND ipolicy_2 = '';
	
	return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car353_send_email_customer()
{
    int	rc;
    $char stmtA[1024],stmtA_1[1024],stmtB[1024],stmtB_1[1024],stmtC[1024],stmtC_1[1024],stmtC_2[1024];
    $char ipolicy_1[21],ipolicy_2[21],itag[CA_TAG_NUM],aemail_appl[51];
    $char dply_begin[11],dply_end[11],napplicant[121],iapplicant[13];
    $char dply_begin_c[11],dply_end_c[11],dply_begin_r[11],dply_end_r[11];
    
    $whenever sqlerror goto errexit;
	 
    /*1.���B�z��j*/  
    /*2.�A�B�z���*/
    /*3.�̫�B�z�j+��*/
    
    strcpy(ipolicy_1,"");
    strcpy(ipolicy_2,"");
    strcpy(itag,"");
    strcpy(aemail_appl,"");
    strcpy(dply_begin,"");
    strcpy(dply_end,"");
    strcpy(napplicant,"");
    
    /*****��j******/
    
    strcpy(stmtA," SELECT DISTINCT ipolicy_1,itag,aemail_appl "
                  "  FROM car353 "
                  " WHERE ipolicy_2 = '' AND ipolicy_1 <> '' ");
                 
    printf("stmtA[%s]\n",stmtA);
    $PREPARE prepA FROM $stmtA;
    $DECLARE cursA CURSOR FOR prepA;
    $OPEN cursA;
    for(;;)
    {
        
        $FETCH cursA INTO $ipolicy_1, $itag, $aemail_appl;
        
        
        if( SQLCODE == SQLNOTFOUND) break;
        
        strcpy(ipolicy_1,trim(ipolicy_1));
        strcpy(itag,trim(itag));
        strcpy(aemail_appl,trim(aemail_appl));
        printf("ipolicy_1[%s]\n",ipolicy_1);
        printf("itag[%s]\n",itag);
        printf("aemail_appl[%s]\n",aemail_appl);
        
        strcpy(Full_DB,"");
        strcpy(Full_DB,get_car_full_db(ipolicy_1));
        
        
        /*����O��_�l��B�O������B�n�O�H�W��*/
        sprintf_s(stmtA_1,sizeof stmtA_1, " SELECT a.dply_begin,a.dply_end,b.napplicant "
                         "   FROM %s:ply_relation a,%s:policy b "
                         "  WHERE a.ipolicy='%s'  AND a.ipolicy=b.ipolicy ",Full_DB,Full_DB,ipolicy_1);
                         
        $PREPARE prepA_1 from $stmtA_1;
        $EXECUTE prepA_1 INTO $dply_begin,$dply_end,$napplicant; 
        
        strcpy(dply_begin,trim(dply_begin));
        strcpy(dply_end,trim(dply_end));
        strcpy(napplicant,trim(napplicant));
        printf("dply_begin[%s],dply_end[%s],napplicant[%s]\n",dply_begin,dply_end,napplicant);
        
        mail_count=0;
        only_comp_email(ipolicy_1,itag,aemail_appl,dply_begin,dply_end,napplicant);
        


    }
    $FREE prepA;
    $CLOSE cursA;
    
    strcpy(ipolicy_1,"");
    strcpy(ipolicy_2,"");
    strcpy(itag,"");
    strcpy(aemail_appl,"");
    strcpy(dply_begin,"");
    strcpy(dply_end,"");
    strcpy(napplicant,"");
    
    /******���******/
    
    strcpy(stmtB," SELECT DISTINCT ipolicy_2,itag,aemail_appl "
                  "  FROM car353 "
                  " WHERE ipolicy_1 = '' AND ipolicy_2 <> '' ");
                 
    printf("stmtB[%s]\n",stmtB);
    $PREPARE prepB FROM $stmtB;
    $DECLARE cursB CURSOR FOR prepB;
    $OPEN cursB;
    for(;;)
    {
        
        $FETCH cursB INTO $ipolicy_2, $itag, $aemail_appl;
        
        
        if( SQLCODE == SQLNOTFOUND) break;
        
        strcpy(ipolicy_2,trim(ipolicy_2));
        strcpy(itag,trim(itag));
        strcpy(aemail_appl,trim(aemail_appl));
        printf("ipolicy_2[%s]\n",ipolicy_2);
        printf("itag[%s]\n",itag);
        printf("aemail_appl[%s]\n",aemail_appl);
        
        strcpy(Full_DB,"");
        strcpy(Full_DB,get_car_full_db(ipolicy_2));
        
        
        /*����O��_�l��B�O������B�n�O�H�W��*/
        sprintf_s(stmtB_1,sizeof stmtB_1, " SELECT a.dply_begin,a.dply_end,b.napplicant "
                         "   FROM %s:ply_relation a,%s:policy b "
                         "  WHERE a.ipolicy='%s'  AND a.ipolicy=b.ipolicy ",Full_DB,Full_DB,ipolicy_2);
                         
        $PREPARE prepB_1 from $stmtB_1;
        $EXECUTE prepB_1 INTO $dply_begin,$dply_end,$napplicant; 
        
        strcpy(dply_begin,trim(dply_begin));
        strcpy(dply_end,trim(dply_end));
        strcpy(napplicant,trim(napplicant));
        printf("dply_begin[%s],dply_end[%s],napplicant[%s]\n",dply_begin,dply_end,napplicant);
        
        mail_count=0;
        only_rand_email(ipolicy_2,itag,aemail_appl,dply_begin,dply_end,napplicant);
        


    }
    $FREE prepB;
    $CLOSE cursB;    
    
    strcpy(ipolicy_1,"");
    strcpy(ipolicy_2,"");
    strcpy(itag,"");
    strcpy(aemail_appl,"");
    strcpy(dply_begin_c,"");
    strcpy(dply_end_c,"");
    strcpy(dply_begin_r,"");
    strcpy(dply_end_r,"");
    strcpy(iapplicant,"");
    strcpy(napplicant,"");
    
    /******�j+��******/
    
    strcpy(stmtC," SELECT DISTINCT ipolicy_1,ipolicy_2,itag,aemail_appl, iapplicant, napplicant "
                  "  FROM car353 "
                  " WHERE ipolicy_1 <> '' AND ipolicy_2 <> '' ");
                 
    printf("stmtC[%s]\n",stmtC);
    $PREPARE prepC FROM $stmtC;
    $DECLARE cursC CURSOR FOR prepC;
    $OPEN cursC;
    for(;;)
    {
        
        $FETCH cursC INTO $ipolicy_1, $ipolicy_2, $itag, $aemail_appl, $iapplicant, $napplicant;
        
        
        if( SQLCODE == SQLNOTFOUND) break;
        
        strcpy(ipolicy_1,trim(ipolicy_1));
        strcpy(ipolicy_2,trim(ipolicy_2));
        strcpy(itag,trim(itag));
        strcpy(aemail_appl,trim(aemail_appl));
        strcpy(napplicant,trim(napplicant));
        printf("ipolicy_1[%s]\n",ipolicy_1);
        printf("ipolicy_2[%s]\n",ipolicy_2);
        printf("itag[%s]\n",itag);
        printf("aemail_appl[%s]\n",aemail_appl);
        printf("napplicant[%s]\n",napplicant);
        
        strcpy(Full_DB,"");
        strcpy(Full_DB,get_car_full_db(ipolicy_1));
        
        
        /*����O��_�l��B�O������ -- �j��*/
        sprintf_s(stmtC_1,sizeof stmtC_1, " SELECT a.dply_begin,a.dply_end "
                         "   FROM %s:ply_relation a,%s:policy b "
                         "  WHERE a.ipolicy='%s'  AND a.ipolicy=b.ipolicy ",Full_DB,Full_DB,ipolicy_1);
                         
        $PREPARE prepC_1 from $stmtC_1;
        $EXECUTE prepC_1 INTO $dply_begin_c,$dply_end_c; 
        
        strcpy(dply_begin_c,trim(dply_begin_c));
        strcpy(dply_end_c,trim(dply_end_c));
        printf("dply_begin_c[%s],dply_end_c[%s]\n",dply_begin_c,dply_end_c);
        
        strcpy(Full_DB,"");
        strcpy(Full_DB,get_car_full_db(ipolicy_2));
        
        /*����O��_�l��B�O������ -- ���N*/
        sprintf_s(stmtC_2,sizeof stmtC_2, " SELECT a.dply_begin,a.dply_end "
                         "   FROM %s:ply_relation a,%s:policy b "
                         "  WHERE a.ipolicy='%s'  AND a.ipolicy=b.ipolicy ",Full_DB,Full_DB,ipolicy_2);
                         
        $PREPARE prepC_2 from $stmtC_2;
        $EXECUTE prepC_2 INTO $dply_begin_r,$dply_end_r; 
        
        strcpy(dply_begin_r,trim(dply_begin_r));
        strcpy(dply_end_r,trim(dply_end_r));
        printf("dply_begin_r[%s],dply_end_r[%s]\n",dply_begin_r,dply_end_r);      
        
        mail_count=0;
        comp_rand_email(ipolicy_1,ipolicy_2,itag,aemail_appl,napplicant,dply_begin_c,dply_end_c,dply_begin_r,dply_end_r);
    }
    $FREE prepC;
    $CLOSE cursC;        
    


    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*******************************************************************************/
long car353_send_email_SMS_customer_IC()
{
	
	int	rc;
    $char stmtA[1024],stmtA_1[1024],stmtB[1024],stmtB_1[1024],stmtB_2[1024],stmtC[1024],stmtC_1[1024],stmtC_2[1024];
    $char ipolicy_1[21],ipolicy_2[21],itag[CA_TAG_NUM],aemail_appl[51],tmobile_appl[21];
    $char dply_begin[11],dply_end[11],napplicant[121],iapplicant[13];
    $char dply_begin_c[11],dply_end_c[11],dply_begin_v[11],dply_end_v[11];
	$char fserial[4];
	
	int SMS_count = 0, fserial_num = 1;
	
	/** 1. ���B�z��� **/
	/** 2. �A�B�z�j+�� **/
	
	strcpy(ipolicy_1,"");
    strcpy(ipolicy_2,"");
    strcpy(itag,"");
    strcpy(aemail_appl,"");
	strcpy(tmobile_appl,"");
    strcpy(dply_begin,"");
    strcpy(dply_end,"");
    strcpy(napplicant,"");
	strcpy(fserial, "001");
	
	SMS_count = 0;
	
	/******���******/
	
	strcpy(stmtA, " SELECT DISTINCT ipolicy_1, itag, aemail_appl, tmobile_appl"
	              "   FROM car353 "
				  "  WHERE ipolicy_2 = '' AND ipolicy_1 <> '' ");
	
	printf("stmtA = [%s]\n", stmtA);
	
	$PREPARE preA FROM $stmtA;
	$DECLARE curA CURSOR FOR preA;
	$OPEN curA;
	
	while(1)
	{
		$FETCH curA INTO $ipolicy_1, $itag, $aemail_appl, $tmobile_appl;
		
		if(SQLCODE == SQLNOTFOUND) break;
		
		strcpy(ipolicy_1, trim(ipolicy_1));
        strcpy(itag, trim(itag));
        strcpy(aemail_appl, trim(aemail_appl));
		strcpy(tmobile_appl, trim(tmobile_appl));
        printf("ipolicy_1 = [%s]\n", ipolicy_1);
        printf("itag = [%s]\n", itag);
        printf("aemail_appl = [%s]\n", aemail_appl);
		printf("tmobile_appl = [%s]\n", tmobile_appl);
		
		strcpy(Full_DB,"");
        strcpy(Full_DB,get_car_full_db(ipolicy_1));

		/**����O��_�l��B�O������B�n�O�H�W��**/
		sprintf_s(stmtA_1, sizeof stmtA_1,
						 " SELECT a.dply_begin, a.dply_end, b.napplicant "
                         "   FROM %s:ply_relation a, %s:policy b "
                         "  WHERE a.ipolicy = '%s' "
						 "    AND a.ipolicy = b.ipolicy ", Full_DB, Full_DB, ipolicy_1);
		printf("stmtA_1 = [%s]\n", stmtA_1);
		
		$PREPARE preA_1 FROM $stmtA_1;
		$EXECUTE preA_1 INTO $dply_begin, $dply_end, $napplicant;
		
		strcpy(dply_begin,trim(dply_begin));
        strcpy(dply_end,trim(dply_end));
        strcpy(napplicant,trim(napplicant));
        printf("dply_begin = [%s], dply_end = [%s], napplicant = [%s]\n", dply_begin, dply_end, napplicant);
		
		mail_count = 0;
		if(strcmp(aemail_appl, "") == 0)
		{
			SMS_count++;
			printf("SMS_count = [%d]\n", SMS_count);
			if(SMS_count > 500)
			{
				fserial_num++;
				strcpy(fserial, "");
				if(fserial_num < 10)
				{
					sprintf_s(fserial, sizeof fserial, "00%d", fserial_num);
				}
				else if(fserial_num >= 10 && fserial_num < 100)
				{
					sprintf_s(fserial, sizeof fserial, "0%d", fserial_num);
				}
				else if(fserial_num >= 100 && fserial_num <= 999)
				{
					sprintf_s(fserial, sizeof fserial, "%d", fserial_num);
				}
				
				SMS_count = 1;
			}
			car353_SMS_IC(ipolicy_1, ipolicy_2, itag, tmobile_appl, dply_begin, dply_end, napplicant, 0, fserial, SMS_count);
		}
		else
		{
			only_volu_email_IC(ipolicy_1, itag, aemail_appl, dply_begin, dply_end, napplicant);
		}
	}
	
	$FREE preA;
	$CLOSE curA;
	
	strcpy(ipolicy_1, "");
    strcpy(ipolicy_2, "");
    strcpy(itag, "");
    strcpy(aemail_appl, "");
    strcpy(dply_begin, "");
    strcpy(dply_end, "");
    strcpy(napplicant, "");
	strcpy(tmobile_appl, "");
	
	/******�j+��******/
	
	strcpy(stmtB, " SELECT DISTINCT ipolicy_1, ipolicy_2, itag, aemail_appl, tmobile_appl, iapplicant, napplicant "
                  "   FROM car353 "
                  "  WHERE ipolicy_1 <> '' AND ipolicy_2 <> '' ");
	
	printf("stmtB = [%s]\n", stmtB);
	printf("Test\n");
	
	$PREPARE preB FROM $stmtB;
	$DECLARE curB CURSOR FOR preB;
	$OPEN curB;
	
	while(1)
	{
		$FETCH curB INTO $ipolicy_1, $ipolicy_2, $itag, $aemail_appl, $tmobile_appl, $iapplicant, $napplicant;
		
		if(SQLCODE == SQLNOTFOUND) break;
		
		strcpy(ipolicy_1, trim(ipolicy_1));
        strcpy(ipolicy_2, trim(ipolicy_2));
        strcpy(itag, trim(itag));
        strcpy(aemail_appl, trim(aemail_appl));
		strcpy(tmobile_appl, trim(tmobile_appl));
        strcpy(napplicant, trim(napplicant));
        printf("ipolicy_1 = [%s]\n", ipolicy_1);
        printf("ipolicy_2 = [%s]\n", ipolicy_2);
        printf("itag = [%s]\n", itag);
        printf("aemail_appl = [%s]\n", aemail_appl);
		printf("tmobile_appl = [%s]\n", tmobile_appl);
        printf("napplicant = [%s]\n", napplicant);
		
		strcpy(Full_DB,"");
        strcpy(Full_DB,get_car_full_db(ipolicy_1));
		
		/** ����O��_�l��B�O������ -- ���N **/
       sprintf_s(stmtB_1,sizeof stmtB_1, " SELECT a.dply_begin, a.dply_end "
                         "   FROM %s:ply_relation a, %s:policy b "
                         "  WHERE a.ipolicy = '%s' "
						 "    AND a.ipolicy = b.ipolicy ", Full_DB, Full_DB, ipolicy_1);
		printf("stmtB_1 = [%s]\n", stmtB_1);
		
		$PREPARE preB_1 FROM $stmtB_1;
		$EXECUTE preB_1 INTO $dply_begin_v, $dply_end_v;
		
		strcpy(dply_begin_v, trim(dply_begin_v));
		strcpy(dply_end_v, trim(dply_end_v));
		printf("dply_begin_v = [%s], dply_end_v = [%s]\n", dply_begin_v, dply_end_v);
		
		strcpy(Full_DB, "");
        strcpy(Full_DB, get_car_full_db(ipolicy_2));
		
		/**����O��_�l��B�O������ -- �j�� **/
		sprintf_s(stmtB_2,sizeof stmtB_2, " SELECT a.dply_begin, a.dply_end "
                         "   FROM %s:ply_relation a, %s:policy b "
                         "  WHERE a.ipolicy = '%s' "
						 "    AND a.ipolicy = b.ipolicy ", Full_DB, Full_DB, ipolicy_2);

		printf("stmtB_2 = [%s]\n", stmtB_2);
		$PREPARE preB_2 FROM $stmtB_2;
		$EXECUTE preB_2 INTO $dply_begin_c, $dply_end_c;
		
		strcpy(dply_begin_c, trim(dply_begin_c));
		strcpy(dply_end_c, trim(dply_end_c));
		printf("dply_begin_c = [%s], dply_end_c = [%s]\n", dply_begin_c, dply_end_c);
		
		mail_count = 0;
		if(strcmp(aemail_appl, "") == 0) 
		{
			SMS_count++;
			if(SMS_count > 500)
			{
				fserial_num++;
				strcpy(fserial, "");
				if(fserial_num < 10)
				{
					sprintf_s(fserial, sizeof fserial, "00%d", fserial_num);
				}
				else if(fserial_num >= 10 && fserial_num < 100)
				{
					sprintf_s(fserial, sizeof fserial, "0%d", fserial_num);
				}
				else if(fserial_num >= 100 && fserial_num <= 999)
				{
					sprintf_s(fserial, sizeof fserial, "%d", fserial_num);
				}
				
				SMS_count = 1;
			}
			car353_SMS_IC(ipolicy_1, ipolicy_2, itag, tmobile_appl, dply_begin_v, dply_end_v, napplicant, 1, fserial, SMS_count);
		}
		else
		{
			comp_volu_email_IC(ipolicy_1,ipolicy_2,itag,aemail_appl,napplicant,dply_begin_c,dply_end_c,dply_begin_v,dply_end_v);
		}
	}
	
	$FREE preB;
	$CLOSE curB;
	
	printf("Finish curB!!!!\n");

	return M_CM_OK;
	
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*******************************************************************************/
char *only_comp_email(ipolicy_1,itag,aemail_appl,dply_begin,dply_end,napplicant)
char *ipolicy_1,*itag,*aemail_appl,*dply_begin,*dply_end,*napplicant;
{
	
	$whenever sqlerror goto errexit;
	/*�H�oE-mail�q���O��-��j */
	printf("[IN only_comp_email]\n");
	
	$char content[9000];
	$char stmt5[1024],stmt16[1024];
        
	char  dply_begin_yy[5],dply_begin_mm[3],dply_begin_dd[3],dply_begin_yy2[5];
	char  dply_end_yy[5],dply_end_mm[3],dply_end_dd[3],dply_end_yy2[5];
	char  itag_mask[CA_TAG_NUM],itag_mask_a[2],itag_mask_b[CA_TAG_NUM];
	$char iins_type[7];/*,aemail_appl[51],napplicant[121],ipolicy_1[21],itag[CA_TAG_NUM],dply_begin[11],dply_end[11]*/
	$char receiver_email[51],receiver_name[121];
	$int  minjured_cover=0,mdeath_cover=0,mdamage_cover=0,mins_premium=0;
	$char sminjured_cover[25],smdeath_cover[25],smdamage_cover[25],smins_premium[25];
	$char nsubject[512];
	char  inumber[5];
	
	
	mail_count++;
	count++;
	strcpy(content,"");
	/*�B�z�O����ܤ覡*/
	strcpy(dply_begin_yy,"");strcpy(dply_begin_mm,"");strcpy(dply_begin_dd,"");strcpy(dply_begin_yy2,"");
	strcpy(dply_end_yy,"");strcpy(dply_end_mm,"");strcpy(dply_end_dd,"");strcpy(dply_end_yy2,"");
	
	cm_split_ymd(cm_from_infdate(dply_begin),dply_begin_yy,dply_begin_mm,dply_begin_dd);
        strcpy(dply_begin_yy2,itoa(atoi(dply_begin_yy)+1911));
        printf("dply_begin_yy2[%s]dply_begin_mm[%s]dply_begin_dd[%s]\n",dply_begin_yy2,dply_begin_mm,dply_begin_dd);
        
	cm_split_ymd(cm_from_infdate(dply_end),dply_end_yy,dply_end_mm,dply_end_dd);
        strcpy(dply_end_yy2,itoa(atoi(dply_end_yy)+1911));
        printf("dply_end_yy2[%s]dply_end_mm[%s]dply_end_dd[%s]\n",dply_end_yy2,dply_end_mm,dply_end_dd);  
	
	
	strcpy(Full_DB,"");
        strcpy(Full_DB,get_car_full_db(ipolicy_1));
        
        /*����j��O�B�B�O�O*/
        sprintf_s(stmt5,sizeof stmt5, " SELECT iins_type,minjured_cover,mdeath_cover,mdamage_cover,mins_premium "
                       "   FROM %s:ply_ins_type "
                       "  WHERE ipolicy='%s'  ",Full_DB,ipolicy_1);

        $PREPARE prep5 from $stmt5;
        $EXECUTE prep5 INTO $iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,$mins_premium; 
       
        strcpy(sminjured_cover,"");
        strcpy(smdeath_cover,"");
        strcpy(smdamage_cover,"");
        strcpy(smins_premium,"");
         
        strcpy(sminjured_cover,rtrim(refmtamt(minjured_cover,MILLIONTH)));
        strcpy(smdeath_cover,rtrim(refmtamt(mdeath_cover,MILLIONTH)));
        strcpy(smdamage_cover,rtrim(refmtamt(mdamage_cover,MILLIONTH)));
        strcpy(smins_premium,rtrim(refmtamt(mins_premium,MILLIONTH)));
        
        /*�B�z���P�B�n*/
        printf("itag[%s]\n",itag);
        strcpy(itag_mask,"");
        strcpy(itag_mask_a,"");
        strcpy(itag_mask_b,"");
        strncpy(itag_mask_a,itag,1);
        itag_mask_a[1] = '\0';
        strncpy(itag_mask_b,itag+3,CA_TAG_NUM);
        printf("itag_mask_a[%s]\n",itag_mask_a);
        printf("itag_mask_b[%s]\n",itag_mask_b);
        strcat(itag_mask,itag_mask_a);
        strcat(itag_mask,"**");
        strcat(itag_mask,itag_mask_b);
        strcpy(itag_mask,trim(itag_mask));
        printf("itag_mask[%s]\n",itag_mask);
        


        
        /*email�D��*/
        sprintf_s(nsubject,sizeof nsubject,"�s�w�F�ʮ��W�����O�I-���I�O��ֹ�q��[%s]",ipolicy_1);
        
        /*���semail���*//*1100420013_SC1_��semail��׸̪����qlogo�s��*/
		/*1120928008_C04_�t�X���q��logo�A�վ�t�β��s���*/
        sprintf_s(content ,sizeof content,
        "<html>"
        "<head><meta http-equiv=\"content-type\" content=\"text/html; charset=Big5\" ></head>"
        "<body><br>"
    	"<table style=\"text-align: left; width: 700; background-color: white; height: 545; font-family:�L�n������; font-size:14px;\" border=\"0\" cellpadding=\"1\" cellspacing=\"1\"> "
    	"<tr>"
    	"       <td style=\"vertical-align: top;\">"
      /*"	    <img style=\"border: 0px solid ; width: 385; height: 85;\"  src=\"https://www.tmnewa.com.tw/img/logo.b33522cc.png\"><br> "
    	"	    <img width=\"700\" height=\"22\" alt=\"\" src=\"https://www.tmnewa.com.tw/img/golden_line_up.50896fc4.png\"><br> "*/
		"       &emsp;&emsp;<a href=\"\"><img width=\"563\" height=\"89\" style=\"border: 0 solid;\" alt=\"\" src=\"https://www.tmnewa.com.tw/img/logo.677af7dd.png\"></a><br> "
    	"       </td>"
    	"    </tr>"
    	"    <tr>"
    	"	<td style=\"vertical-align: top;\"><br> "
    	"	&nbsp; &nbsp; �˷R��<font color=\"darkred\"> %s </font>�z�n : <br><br>"
    	"		&nbsp; &nbsp; &nbsp; &nbsp; �̾ڥ����q�����@�~�W�w�A���T�O�ӫO��ƤΫO�O���T�ʡA��C�u������A"
    	"	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�w��W�@�u�d��email��ƪ��Ȥ�|�H�o�ֹ���ӨѫO��T�{�A"
    	"	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�H�U���z���~�󥻤��q��O���T�����O�I�O����Ӥ��e�A�q�Ш�U�ֹ�C<br><br>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; ���P���X : <font color=\"darkred\"> %s </font><br>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; �j���I�O�渹 : <font color=\"darkred\"> %s</font><br>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; �j���I�O�I���� : <font color=\"darkred\"> %s�~%s��%s�� ����12�� ~ %s�~%s��%s�� ����12��</font><br>"
    	"	<div style=\"margin-left:32px;margin-bottom:5px;margin-top:5px;\">"
    	"	<table border=\"1\" style=\"border-collapse:collapse;font-size:14px;\">"

    	"	    <tr><td></td><td>�I�ئW��</td><td colspan=\"2\">�O�I���B</td><td>ñ��O�O</td></tr>"
    		        
    	"	    <tr>"
    	"	        <td align=\"center\">�j���I</td>"
    	"	        <td>21�j��T���d���O�I</td>"
        "                <td style=\"border-color:  black transparent black black ;\">�C�@�ӤH��� <br>�C�@�ӤH���`�Υ��� </td>"
        "                <td align=\"right\">%s<br>%s </td>"
                        
        "                <td align=\"right\">%s��</td>"
    	"	    </tr>"
   
    	"	    <tr>"
    	"	        <td colspan=\"4\">�`�O�O</td><td align=\"right\"> %s��</td>"
    	"	    </tr>"
    	"	</table>"
    	"	</div>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; �p�����D�м��������q�K�O�ȪA�M�u<font color=\"darkred\"> 0800 - 050 - 119 �� (02)8772 - 7777</font> �߰ݡA<br><br>"		
    	"	&nbsp; &nbsp; �A�@���`�`�a�P�±z�A�ï��ֱz�αz���a�H<br><br>"
    	"	&nbsp; &nbsp; ���d �ּ�<br><br>"
    	"	<div style=\" width: 700px; text-align: center;\">�s�w�F�ʮ��W�����O�I &nbsp; �q��</div>"
    	"	<br>"
      /*"	<div style=\"width:700;color:#4a4541;background-color: #FFD700; text-align: center;height:22\">0800 �M�u�G0800 - 050 - 119 &nbsp;�q�ܡG(02)8772 - 7777 &nbsp;�x�_�� 104 �n�ʪF���T�q 130 ��</div>"*/
    	"	</td>"
        "    </tr>"
    	"</table>"
        "</body></html>	"
        ,napplicant,itag_mask,ipolicy_1,dply_begin_yy2,dply_begin_mm,dply_begin_dd,dply_end_yy2,dply_end_mm,dply_end_dd,sminjured_cover,smdeath_cover,smins_premium,smins_premium);
        
        strcpy(mbuf,content);
        ctxt.loc_loctype = LOCMEMORY;
        ctxt.loc_buffer = mbuf;
        ctxt.loc_bufsize = 9000;
        ctxt.loc_size =  strlen(mbuf) + 1;
        
        strcpy(receiver_email,"");
        strcpy(receiver_name,"");
        strcpy(receiver_email,trim(aemail_appl));
        strcpy(receiver_name,trim(napplicant));        
        
        /* ���קK���Ƶo�e */
        $delete from batchemail
          where project_id = 'CAR353'
            and mail_date = today
            and receiver_email = $receiver_email
            and nsubject = $nsubject;
            

          
        $INSERT INTO batchemail
		    (project_id, mail_date, receiver_email, receiver_name, cc,
		     content, key, mail_count, nsubject)
        VALUES
		    ('CAR353', today, $receiver_email, $receiver_name, ' ',
		     $ctxt, ' ', $mail_count, $nsubject);

        strcpy(inumber,"");
        sprintf_s(inumber,sizeof inumber,"%04d",count);
        printf("inumber[%s]\n",inumber);
        sprintf_s(stmt16,sizeof stmt16," INSERT INTO car353_email_log"
                       " (ipolicy_c, ipolicy_r, nreceiver, aemail_receiver, inumber) "
                       "  VALUES "
                       " ('%s', '', '%s', '%s','%s%s%s%s'); ",ipolicy_1,receiver_name,receiver_email,yy_fn,mm_fn,dd_fn, inumber);

        $PREPARE prep16 from $stmt16;
        $EXECUTE prep16 ; 
          

		    
		     
        return M_CM_OK;
errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}
/*******************************************************************************/
char *only_rand_email(ipolicy_2,itag,aemail_appl,dply_begin,dply_end,napplicant)
char *ipolicy_2,*itag,*aemail_appl,*dply_begin,*dply_end,*napplicant;
{
	
	$whenever sqlerror goto errexit;
	/*�H�oE-mail�q���O��-��� */
	printf("[IN only_rand_email]\n");

	
	int rc;
	
	$char content1[9000];
	$char content2[100];
	$char content3[2900];
	$char content4[3000];
	$char stmt6[1024],stmt7[1024],stmt7_1[1024],stmt7_2[1024],stmt8[1024],stmt9[1024],stmt17[1024];
        char  sDBName[5];
	char  dply_begin_yy[5],dply_begin_mm[3],dply_begin_dd[3],dply_begin_yy2[5];
	char  dply_end_yy[5],dply_end_mm[3],dply_end_dd[3],dply_end_yy2[5];
	char  itag_mask[CA_TAG_NUM],itag_mask_a[2],itag_mask_b[CA_TAG_NUM];
	$char iins_type[7];/*,aemail_appl[51],napplicant[121],ipolicy_1[21],itag[CA_TAG_NUM],dply_begin[11],dply_end[11]*/
	$char receiver_email[51],receiver_name[121];
	$int  minjured_cover=0,mdeath_cover=0,mdamage_cover=0,mins_premium=0;
	$char sminjured_cover[25],smdeath_cover[25],smdamage_cover[25],smins_premium[25];
	$char nsubject[512];
	$int  mtotal;
	$char stotal[21];
	$char field1[7],field4[121],field5[121],field7[121];
        $int  line_no=0;
        $char ins_type_print[36];
        $char ncover_print[151],mcover_print[151],mins_premium_print[151];
        $char cntIns[3];
        $char tmp_ipolicy[21];
        $char nleader[11],nleader_tel[15];
        char  inumber[5];
        
	
	mail_count++;
	count++;
	strcpy(content1,"");
	strcpy(content2,"");
	strcpy(content3,"");
	strcpy(content4,"");
	strcpy(tmp_ipolicy,trim(ipolicy_2));
	
	/*�B�z�O����ܤ覡*/
	strcpy(dply_begin_yy,"");strcpy(dply_begin_mm,"");strcpy(dply_begin_dd,"");strcpy(dply_begin_yy2,"");
	strcpy(dply_end_yy,"");strcpy(dply_end_mm,"");strcpy(dply_end_dd,"");strcpy(dply_end_yy2,"");
	
	cm_split_ymd(cm_from_infdate(dply_begin),dply_begin_yy,dply_begin_mm,dply_begin_dd);
        strcpy(dply_begin_yy2,itoa(atoi(dply_begin_yy)+1911));
        printf("dply_begin_yy2[%s]dply_begin_mm[%s]dply_begin_dd[%s]\n",dply_begin_yy2,dply_begin_mm,dply_begin_dd);
        
	cm_split_ymd(cm_from_infdate(dply_end),dply_end_yy,dply_end_mm,dply_end_dd);
        strcpy(dply_end_yy2,itoa(atoi(dply_end_yy)+1911));
        printf("dply_end_yy2[%s]dply_end_mm[%s]dply_end_dd[%s]\n",dply_end_yy2,dply_end_mm,dply_end_dd);  
	
	$DELETE FROM car353_ins WHERE 1=1;
	
	strcpy(Full_DB,"");
        strcpy(Full_DB,get_car_full_db(ipolicy_2));
        
        
        
        /*�`�O�O*/
        strcpy(stotal,"");
        mtotal=0;
        sprintf_s(stmt6,sizeof stmt6, " SELECT sum(mins_premium) "
                       "   FROM %s:ply_ins_type "
                       "  WHERE ipolicy='%s'  ",Full_DB,ipolicy_2);

        $PREPARE prep6 from $stmt6;
        $EXECUTE prep6 INTO $mtotal; 
       
        strcpy(stotal,refmtamt( mtotal,MILLIONTH));
        
        /*�B�z���P�B�n*/
        printf("itag[%s]\n",itag);
        strcpy(itag_mask,"");
        strcpy(itag_mask_a,"");
        strcpy(itag_mask_b,"");
        strncpy(itag_mask_a,itag,1);
        itag_mask_a[1] = '\0';
        strncpy(itag_mask_b,itag+3,CA_TAG_NUM);
        printf("itag_mask_a[%s]\n",itag_mask_a);
        printf("itag_mask_b[%s]\n",itag_mask_b);
        strcat(itag_mask,itag_mask_a);
        strcat(itag_mask,"**");
        strcat(itag_mask,itag_mask_b);
        strcpy(itag_mask,trim(itag_mask));
        printf("itag_mask[%s]\n",itag_mask);
        

        
        
        /*email�D��*/
        sprintf_s(nsubject,sizeof nsubject,"�s�w�F�ʮ��W�����O�I-���I�O��ֹ�q��[%s]",ipolicy_2);
        
        /*���semail���*//*1100420013_SC1_��semail��׸̪����qlogo�s��*/
		/*1120928008_C04_�t�X���q��logo�A�վ�t�β��s���*/
        sprintf_s(content1,sizeof content1 ,
        "<html>"
        "<head><meta http-equiv=\"content-type\" content=\"text/html; charset=Big5\" ></head>"
        "<body><br>"
    	"<table style=\"text-align: left; width: 700; background-color: white; height: 545; font-family:�L�n������; font-size:14px;\" border=\"0\" cellpadding=\"1\" cellspacing=\"1\"> "
    	"    <tr>"
    	"       <td style=\"vertical-align: top;\">"
      /*"	    <img style=\"border: 0px solid ; width: 385; height: 85;\"  src=\"https://www.tmnewa.com.tw/img/logo.b33522cc.png\"><br> "
    	"	    <img width=\"700\" height=\"22\" alt=\"\" src=\"https://www.tmnewa.com.tw/img/golden_line_up.50896fc4.png\"><br> "*/
		"       &emsp;&emsp;<a href=\"\"><img width=\"563\" height=\"89\" style=\"border: 0 solid;\" alt=\"\" src=\"https://www.tmnewa.com.tw/img/logo.677af7dd.png\"></a><br> "
    	"		</td>"
    	"    </tr>"
    	"    <tr>"
    	"	<td style=\"vertical-align: top;\"><br> "
    	"	&nbsp; &nbsp; �˷R��<font color=\"darkred\"> %s </font>�z�n : <br><br>"
    	"		&nbsp; &nbsp; &nbsp; &nbsp; �̾ڥ����q�����@�~�W�w�A���T�O�ӫO��ƤΫO�O���T�ʡA��C�u������A"
    	"	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�w��W�@�u�d��email��ƪ��Ȥ�|�H�o�ֹ���ӨѫO��T�{�A"
    	"	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�H�U���z���~�󥻤��q��O���T�����O�I�O����Ӥ��e�A�q�Ш�U�ֹ�C<br><br>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; ���P���X : <font color=\"darkred\"> %s </font><br>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; ���N�I�O�渹 : <font color=\"darkred\"> %s</font><br>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; ���N�I�O�I���� : <font color=\"darkred\"> %s�~%s��%s�� ����12�� ~ %s�~%s��%s�� ����12��</font><br>"
    	"	<div style=\"margin-left:32px;margin-bottom:5px;margin-top:5px;\">"
    	"	<table border=\"1\" style=\"border-collapse:collapse;font-size:14px;\">"
    	"	    <tr><td></td><td>�I�ئW��</td><td colspan=\"2\">�O�I���B</td><td>ñ��O�O</td></tr>"
        ,napplicant,itag_mask,ipolicy_2,dply_begin_yy2,dply_begin_mm,dply_begin_dd,dply_end_yy2,dply_end_mm,dply_end_dd);
   
   
   
        strcpy(sDBName,"");
        strcpy(sDBName,get_car_short_db(ipolicy_2));
        printf("sDBName[%s]\n",sDBName);
        rc=ca_rpt_policy(ipolicy_2, "", 0, "2", FALSE, 1, " ", "",userid,"0","0",sDBName,"4","","","","0");
        if (rc != M_CM_OK) return rc;
        
        strcpy(field1,"");
        strcpy(field4,"");
        strcpy(field5,"");
        strcpy(field7,"");
            
        /*�ǳ��I�ة��ӦC�L��ơA�s�Jtemp table :car353_ins*/    
        /*tbl_print : ca_rpt_policy�̪�table*/
        /*line_no�Ǹ�,field1�I�إN��,field4�O�B�W��,field5�O�B,field7�O�O*/
        sprintf_s(stmt7,sizeof stmt7," SELECT  line_no,nvl(field1,''),nvl(field4,''),nvl(field5,''),nvl(field7,'') "
                      "  FROM tbl_print WHERE ipolicy='%s' order by line_no",ipolicy_2);
                 
        printf("stmt7[%s]\n",stmt7);
        $PREPARE prep7 FROM $stmt7;
        $DECLARE curs7 CURSOR FOR prep7;
        $OPEN curs7 ;
        for(;;)
        {
        
            $FETCH curs7 INTO $line_no, $field1, $field4, $field5, $field7;
        
        
            if( SQLCODE == SQLNOTFOUND) break;
          
            strcpy(field1,trim(field1));
            strcpy(field4,trim(field4));
            strcpy(field5,trim(field5));
            strcpy(field7,trim(field7));
            
            if (strcmp(trim(field1),"")!=0)
            {
            	$SELECT trim(iins_type)||trim(nins_type)
            	   INTO $ins_type_print
            	   FROM insurance_type
            	  WHERE iins_type=$field1;
            	
                
            
                sprintf_s(stmt7_1,sizeof stmt7_1," INSERT INTO car353_ins(ipolicy,ins_type_print,ncover_print,mcover_print,mins_premium_print) "
                                "  VALUES ('%s','%s','%s','%s','%s��')",ipolicy_2,ins_type_print,field4,field5,field7);
                printf("stmt7_1[%s]\n",stmt7_1);
                $PREPARE prep7_1 FROM $stmt7_1;
                $EXECUTE prep7_1;
                
            }
            else 
            {
                sprintf_s(stmt7_2,sizeof stmt7_2," UPDATE car353_ins SET  ncover_print=trim(ncover_print)||'<br>%s',mcover_print=trim(mcover_print)||'<br>%s' "
                                "  WHERE ipolicy ='%s' AND ins_type_print='%s' ",field4,field5,ipolicy_2,ins_type_print);
                printf("stmt7_2[%s]\n",stmt7_2);
                $PREPARE prep7_2 FROM $stmt7_2;
                $EXECUTE prep7_2;	
            	
            }
            

            strcpy(field1,"");strcpy(field4,"");strcpy(field5,"");strcpy(field7,"");
            
        }
        $FREE prep7;
        $CLOSE curs7;
        
        $DELETE FROM tbl_print WHERE ipolicy = $tmp_ipolicy;
        
        strcpy(cntIns,"1");
        
        
        sprintf_s(stmt8,sizeof stmt8," SELECT count(*) "
                      "   FROM car353_ins WHERE ipolicy='%s' ",ipolicy_2);
                 
        printf("stmt8[%s]\n",stmt8);
        $PREPARE prep8 FROM $stmt8;
        $EXECUTE prep8 INTO $cntIns;
        
        sprintf_s(content2,sizeof content2 ,
        "           <tr>"
        "               <td align=\"center\" rowspan=\"%s\">���N�I</td>",cntIns);
        
        strcat(content1,content2);
        
        strcpy(ins_type_print,"");
        strcpy(ncover_print,"");
        strcpy(mcover_print,"");
        strcpy(mins_premium_print,"");
        
/*******�I�ة��ӦC�L�϶�**********/  
        int i=0;
        sprintf_s(stmt9,sizeof stmt9," SELECT  ins_type_print,ncover_print,mcover_print,mins_premium_print "
                      "  FROM car353_ins WHERE ipolicy='%s' order by row_no",ipolicy_2);
                 
        printf("stmt9[%s]\n",stmt9);
        $PREPARE prep9 FROM $stmt9;
        $DECLARE curs9 CURSOR FOR prep9;
        $OPEN curs9 ;
        for(;;)
        {
            
            $FETCH curs9 INTO $ins_type_print, $ncover_print, $mcover_print, $mins_premium_print;

            if( SQLCODE == SQLNOTFOUND) break;
            
             
            strcpy(ins_type_print,trim(ins_type_print));
            strcpy(ncover_print,trim(ncover_print));
            strcpy(mcover_print,trim(mcover_print));
            strcpy(mins_premium_print,trim(mins_premium_print));
         
            if (i==0)
            {
                sprintf_s(content3,sizeof content3 ,
                "               <td>%s</td>"
                "               <td style=\"border-color:  black transparent black black ;\">%s</td>"
                "               <td align=\"right\">%s</td>"
                "               <td align=\"right\">%s</td>"
                "           </tr>"  
                ,ins_type_print,ncover_print,mcover_print,mins_premium_print);
            }                
            else
            {
                sprintf_s(content3,sizeof content3,
    	        "	    <tr>"
    	        "	        <td>%s</td>"
    	        "	        <td style=\"border-color:  black transparent black black ;\">%s</td>"
    	        "	        <td align=\"right\">%s</td>"
    	        "	        <td align=\"right\">%s</td>"
    	        "	    </tr>"
                ,ins_type_print,ncover_print,mcover_print,mins_premium_print);
            }
            strcat(content1,content3);
            i++;
            strcpy(ins_type_print,"");
            strcpy(ncover_print,"");
            strcpy(mcover_print,"");
            strcpy(mins_premium_print,"");
            
        }
        $FREE prep9;
        $CLOSE curs9;
/*****************/ 	
	
	
	
	sprintf_s(content4,sizeof content4 ,	    
    	"	    <tr>"
    	"	        <td colspan=\"4\">�`�O�O</td><td align=\"right\">%s��</td>"
    	"	    </tr>"
    	"	</table>"
    	"	</div>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; �p�����D�м��������q�K�O�ȪA�M�u<font color=\"darkred\"> 0800 - 050 - 119 �� (02)8772 - 7777</font> �߰ݡA<br><br>"		
    	"	&nbsp; &nbsp; �A�@���`�`�a�P�±z�A�ï��ֱz�αz���a�H<br><br>"
    	"	&nbsp; &nbsp; ���d �ּ�<br><br>"
    	"	<div style=\" width: 700px; text-align: center;\">�s�w�F�ʮ��W�����O�I &nbsp; �q��</div>"
    	"	<br>"
      /*"	<div style=\"width:700;color:#4a4541;background-color: #FFD700; text-align: center;height:22\">0800 �M�u�G0800 - 050 - 119 &nbsp;�q�ܡG(02)8772 - 7777 &nbsp;�x�_�� 104 �n�ʪF���T�q 130 ��</div>"*/
    	"	</td>"
        "    </tr>"
    	"</table>"
        "</body></html>	"
        ,stotal);
        
        
        
        strcat(content1,content4);
        

        
        strcpy(mbuf,content1);
        ctxt.loc_loctype = LOCMEMORY;
        ctxt.loc_buffer = mbuf;
        ctxt.loc_bufsize = 9000;
        ctxt.loc_size =  strlen(mbuf) + 1;
        
        strcpy(receiver_email,"");
        strcpy(receiver_name,"");
        strcpy(receiver_email,trim(aemail_appl));
        strcpy(receiver_name,trim(napplicant));        
        
        /* ���קK���Ƶo�e */
        $delete from batchemail
          where project_id = 'CAR353'
            and mail_date = today
            and receiver_email = $receiver_email
            and nsubject = $nsubject;
            

          
        $INSERT INTO batchemail
		    (project_id, mail_date, receiver_email, receiver_name, cc,
		     content, key, mail_count, nsubject)
        VALUES
		    ('CAR353', today, $receiver_email, $receiver_name, ' ',
		     $ctxt, ' ', $mail_count, $nsubject);
		     
        strcpy(inumber,"");
        sprintf_s(inumber,sizeof inumber,"%04d",count);
        printf("inumber[%s]\n",inumber);
        sprintf_s(stmt17,sizeof stmt17," INSERT INTO car353_email_log"
                       " (ipolicy_c, ipolicy_r, nreceiver, aemail_receiver, inumber) "
                       "  VALUES "
                       " ('', '%s', '%s', '%s','%s%s%s%s'); ",ipolicy_2,receiver_name,receiver_email,yy_fn,mm_fn,dd_fn, inumber);

        $PREPARE prep17 from $stmt17;
        $EXECUTE prep17 ; 
		     
		     
        return M_CM_OK;
errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}
/*******************************************************************************/
char *comp_rand_email(ipolicy_1,ipolicy_2,itag,aemail_appl,napplicant,dply_begin_c,dply_end_c,dply_begin_r,dply_end_r)
char *ipolicy_1,*ipolicy_2,*itag,*aemail_appl,*napplicant,*dply_begin_c,*dply_end_c,*dply_begin_r,*dply_end_r;
{
	
	$whenever sqlerror goto errexit;
	/*�H�oE-mail�q���O��-�j+�� */
	printf("[IN comp_rand_email]\n");
	
	
	int rc;
	
	$char content1[9000];
	$char content2[600];
	$char content3[100];
	$char content4[700];
	$char content5[1000];
	$char stmt10[1024],stmt11[1024],stmt12[1024],stmt13[1024],stmt13_1[1024],stmt13_2[1024],stmt14[1024],stmt15[1024],stmt18[1024];
        char  sDBName[5];
	char  dply_begin_c_yy[5],dply_begin_c_mm[3],dply_begin_c_dd[3],dply_begin_c_yy2[5];
	char  dply_end_c_yy[5],dply_end_c_mm[3],dply_end_c_dd[3],dply_end_c_yy2[5];
	char  dply_begin_r_yy[5],dply_begin_r_mm[3],dply_begin_r_dd[3],dply_begin_r_yy2[5];
	char  dply_end_r_yy[5],dply_end_r_mm[3],dply_end_r_dd[3],dply_end_r_yy2[5];
	char  itag_mask[CA_TAG_NUM],itag_mask_a[2],itag_mask_b[CA_TAG_NUM];
	$char iins_type[7];/*,aemail_appl[51],napplicant[121],ipolicy_1[21],itag[CA_TAG_NUM],dply_begin[11],dply_end[11]*/
	$char receiver_email[51],receiver_name[121];
	$int  minjured_cover=0,mdeath_cover=0,mdamage_cover=0,mins_premium=0;
	$char sminjured_cover[25],smdeath_cover[25],smdamage_cover[25],smins_premium[25];
	$char nsubject[512];
	$int  mtotal,mtotal_c,mtotal_r;
	$char stotal[21],stotal_c[21],stotal_r[21];
	$char field1[7],field4[121],field5[121],field7[121];
        $int  line_no=0;
        $char ins_type_print[36];
        $char ncover_print[151],mcover_print[151],mins_premium_print[151];
        $char cntIns[3];
        $char tmp_ipolicy[21];
        char  inumber[5];
	
	mail_count++;
	count++;
	strcpy(content1,"");
	strcpy(content2,"");
	strcpy(content3,"");
	strcpy(content4,"");
	strcpy(content5,"");
	strcpy(tmp_ipolicy,trim(ipolicy_2));
	
	/*�B�z�O����ܤ覡*/
	strcpy(dply_begin_c_yy,"");strcpy(dply_begin_c_mm,"");strcpy(dply_begin_c_dd,"");strcpy(dply_begin_c_yy2,"");
	strcpy(dply_end_c_yy,"");strcpy(dply_end_c_mm,"");strcpy(dply_end_c_dd,"");strcpy(dply_end_c_yy2,"");
	strcpy(dply_begin_r_yy,"");strcpy(dply_begin_r_mm,"");strcpy(dply_begin_r_dd,"");strcpy(dply_begin_r_yy2,"");
	strcpy(dply_end_r_yy,"");strcpy(dply_end_r_mm,"");strcpy(dply_end_r_dd,"");strcpy(dply_end_r_yy2,"");
	
	cm_split_ymd(cm_from_infdate(dply_begin_c),dply_begin_c_yy,dply_begin_c_mm,dply_begin_c_dd);
        strcpy(dply_begin_c_yy2,itoa(atoi(dply_begin_c_yy)+1911));
        printf("dply_begin_c_yy2[%s]dply_begin_c_mm[%s]dply_begin_c_dd[%s]\n",dply_begin_c_yy2,dply_begin_c_mm,dply_begin_c_dd);
        
	cm_split_ymd(cm_from_infdate(dply_end_c),dply_end_c_yy,dply_end_c_mm,dply_end_c_dd);
        strcpy(dply_end_c_yy2,itoa(atoi(dply_end_c_yy)+1911));
        printf("dply_end_c_yy2[%s]dply_end_c_mm[%s]dply_end_c_dd[%s]\n",dply_end_c_yy2,dply_end_c_mm,dply_end_c_dd);  

	cm_split_ymd(cm_from_infdate(dply_begin_r),dply_begin_r_yy,dply_begin_r_mm,dply_begin_r_dd);
        strcpy(dply_begin_r_yy2,itoa(atoi(dply_begin_r_yy)+1911));
        printf("dply_begin_r_yy2[%s]dply_begin_r_mm[%s]dply_begin_r_dd[%s]\n",dply_begin_r_yy2,dply_begin_r_mm,dply_begin_r_dd);
        
	cm_split_ymd(cm_from_infdate(dply_end_r),dply_end_r_yy,dply_end_r_mm,dply_end_r_dd);
        strcpy(dply_end_r_yy2,itoa(atoi(dply_end_r_yy)+1911));
        printf("dply_end_r_yy2[%s]dply_end_r_mm[%s]dply_end_r_dd[%s]\n",dply_end_r_yy2,dply_end_r_mm,dply_end_r_dd);  
        	
	$DELETE FROM car353_ins WHERE 1=1;
	
	strcpy(Full_DB,"");
        strcpy(Full_DB,get_car_full_db(ipolicy_1));
        
        mtotal = mtotal_c = mtotal_r = 0;

        /*�j��O�O*/
        strcpy(stotal,"");
        strcpy(stotal_c,"");
        strcpy(stotal_r,"");
        
        sprintf_s(stmt10,sizeof stmt10, " SELECT sum(mins_premium) "
                       "   FROM %s:ply_ins_type "
                       "  WHERE ipolicy='%s'  ",Full_DB,ipolicy_1);

        $PREPARE prep10 from $stmt10;
        $EXECUTE prep10 INTO $mtotal_c; 
        
        strcpy(stotal_c,refmtamt( mtotal_c,MILLIONTH));
        
	strcpy(Full_DB,"");
        strcpy(Full_DB,get_car_full_db(ipolicy_2));
        
        /*���N�O�O*/
        strcpy(stotal,"");
        
        sprintf_s(stmt11,sizeof stmt11, " SELECT sum(mins_premium) "
                       "   FROM %s:ply_ins_type "
                       "  WHERE ipolicy='%s'  ",Full_DB,ipolicy_2);

        $PREPARE prep11 from $stmt11;
        $EXECUTE prep11 INTO $mtotal_r; 
        
        strcpy(stotal_r,refmtamt( mtotal_r,MILLIONTH));
        
        /*�j+���O�O*/
        mtotal = mtotal_c + mtotal_r;
        strcpy(stotal,refmtamt( mtotal,MILLIONTH));
        
        /*�B�z���P�B�n*/
        printf("itag[%s]\n",itag);
        strcpy(itag_mask,"");
        strcpy(itag_mask_a,"");
        strcpy(itag_mask_b,"");
        strncpy(itag_mask_a,itag,1);
        itag_mask_a[1] = '\0';
        strncpy(itag_mask_b,itag+3,CA_TAG_NUM);
        printf("itag_mask_a[%s]\n",itag_mask_a);
        printf("itag_mask_b[%s]\n",itag_mask_b);
        strcat(itag_mask,itag_mask_a);
        strcat(itag_mask,"**");
        strcat(itag_mask,itag_mask_b);
        strcpy(itag_mask,trim(itag_mask));
        printf("itag_mask[%s]\n",itag_mask);
        
        /*email�D��*/
        sprintf_s(nsubject,sizeof nsubject,"�s�w�F�ʮ��W�����O�I-���I�O��ֹ�q��[%s/%s]",ipolicy_1,ipolicy_2);
        
        /*���semail���*//*1100420013_SC1_��semail��׸̪����qlogo�s��*/
		/*1120928008_C04_�t�X���q��logo�A�վ�t�β��s���*/
        sprintf_s(content1 ,sizeof content1,
        "<html>"
        "<head><meta http-equiv=\"content-type\" content=\"text/html; charset=Big5\" ></head>"
        "<body><br>"
    	"<table style=\"text-align: left; width: 700; background-color: white; height: 545; font-family:�L�n������; font-size:14px;\" border=\"0\" cellpadding=\"1\" cellspacing=\"1\"> "
    	"    <tr>"
    	"       <td style=\"vertical-align: top;\">"
      /*"	    <img style=\"border: 0px solid ; width: 385; height: 85;\"  src=\"https://www.tmnewa.com.tw/img/logo.b33522cc.png\"><br> "
    	"	    <img width=\"700\" height=\"22\" alt=\"\" src=\"https://www.tmnewa.com.tw/img/golden_line_up.50896fc4.png\"><br> "*/
		"       &emsp;&emsp;<a href=\"\"><img width=\"563\" height=\"89\" style=\"border: 0 solid;\" alt=\"\" src=\"https://www.tmnewa.com.tw/img/logo.677af7dd.png\"></a><br> "
    	"		</td>"
    	"    </tr>"
    	"    <tr>"
    	"	<td style=\"vertical-align: top;\"><br> "
    	"	&nbsp; &nbsp; �˷R��<font color=\"darkred\"> %s </font>�z�n : <br><br>"
    	"		&nbsp; &nbsp; &nbsp; &nbsp; �̾ڥ����q�����@�~�W�w�A���T�O�ӫO��ƤΫO�O���T�ʡA��C�u������A"
    	"	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�w��W�@�u�d��email��ƪ��Ȥ�|�H�o�ֹ���ӨѫO��T�{�A"
    	"	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�H�U���z���~�󥻤��q��O���T�����O�I�O����Ӥ��e�A�q�Ш�U�ֹ�C<br><br>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; ���P���X : <font color=\"darkred\"> %s </font><br>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; �j���I�O�渹 : <font color=\"darkred\"> %s</font><br>"    	
    	"	&nbsp; &nbsp; &nbsp; &nbsp; ���N�I�O�渹 : <font color=\"darkred\"> %s</font><br>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; �j���I�O�I���� : <font color=\"darkred\"> %s�~%s��%s�� ����12�� ~ %s�~%s��%s�� ����12��</font><br>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; ���N�I�O�I���� : <font color=\"darkred\"> %s�~%s��%s�� ����12�� ~ %s�~%s��%s�� ����12��</font><br>"
    	"	<div style=\"margin-left:32px;margin-bottom:5px;margin-top:5px;\">"
    	"	<table border=\"1\" style=\"border-collapse:collapse;font-size:14px;\">"
    	"	    <tr><td></td><td>�I�ئW��</td><td colspan=\"2\">�O�I���B</td><td>ñ��O�O</td></tr>"
        ,napplicant,itag_mask,ipolicy_1,ipolicy_2
        ,dply_begin_c_yy2,dply_begin_c_mm,dply_begin_c_dd,dply_end_c_yy2,dply_end_c_mm,dply_end_c_dd
        ,dply_begin_r_yy2,dply_begin_r_mm,dply_begin_r_dd,dply_end_r_yy2,dply_end_r_mm,dply_end_r_dd);
   
   
        /*�j���I����*/
        mins_premium=0;
	strcpy(Full_DB,"");
        strcpy(Full_DB,get_car_full_db(ipolicy_1));
        /*����j��O�B�B�O�O*/
        sprintf_s(stmt12,sizeof stmt12, " SELECT iins_type,minjured_cover,mdeath_cover,mdamage_cover,mins_premium "
                       "   FROM %s:ply_ins_type "
                       "  WHERE ipolicy='%s'  ",Full_DB,ipolicy_1);

        $PREPARE prep12 from $stmt12;
        $EXECUTE prep12 INTO $iins_type,$minjured_cover,$mdeath_cover,$mdamage_cover,$mins_premium; 
       
        strcpy(sminjured_cover,"");
        strcpy(smdeath_cover,"");
        strcpy(smdamage_cover,"");
        strcpy(smins_premium,"");
         
        strcpy(sminjured_cover,rtrim(refmtamt(minjured_cover,MILLIONTH)));
        strcpy(smdeath_cover,rtrim(refmtamt(mdeath_cover,MILLIONTH)));
        strcpy(smdamage_cover,rtrim(refmtamt(mdamage_cover,MILLIONTH)));
        strcpy(smins_premium,rtrim(refmtamt(mins_premium,MILLIONTH)));
        
        sprintf_s(content2,sizeof content2,
    	"	    <tr>"
    	"	        <td align=\"center\">�j���I</td>"
    	"	        <td>21�j��T���d���O�I</td>"
        "                <td style=\"border-color:  black transparent black black ;\">�C�@�ӤH��� <br>�C�@�ӤH���`�Υ��� </td>"
        "                <td align=\"right\">%s<br>%s </td>"           
        "                <td align=\"right\">%s��</td>"
    	"	    </tr>"
    	"    	    <tr>"
    	"	        <td colspan=\"4\">�j���I�O�O</td><td align=\"right\">%s��</td>"
    	"	    </tr>"
        ,sminjured_cover,smdeath_cover,smins_premium,smins_premium);
        
        strcat(content1,content2);
   
        /*���N�I����*/
        strcpy(sDBName,"");
        strcpy(sDBName,get_car_short_db(ipolicy_2));
        printf("sDBName[%s]\n",sDBName);
        rc=ca_rpt_policy(ipolicy_2, "", 0, "2", FALSE, 1, " ", "",userid,"0","0",sDBName,"4","","","","0");
        if (rc != M_CM_OK) return rc;
        
        strcpy(field1,"");
        strcpy(field4,"");
        strcpy(field5,"");
        strcpy(field7,"");
            
        /*�ǳ��I�ة��ӦC�L��ơA�s�Jtemp table :car353_ins*/    
        /*tbl_print : ca_rpt_policy�̪�table*/
        /*line_no�Ǹ�,field1�I�إN��,field4�O�B�W��,field5�O�B,field7�O�O*/
        sprintf_s(stmt13,sizeof stmt13," SELECT  line_no,nvl(field1,''),nvl(field4,''),nvl(field5,''),nvl(field7,'') "
                      "  FROM tbl_print WHERE ipolicy='%s' order by line_no",ipolicy_2);
                 
        printf("stmt13[%s]\n",stmt13);
        $PREPARE prep13 FROM $stmt13;
        $DECLARE curs13 CURSOR FOR prep13;
        $OPEN curs13 ;
        for(;;)
        {
        
            $FETCH curs13 INTO $line_no, $field1, $field4, $field5, $field7;
        
        
            if( SQLCODE == SQLNOTFOUND) break;
          
            strcpy(field1,trim(field1));
            strcpy(field4,trim(field4));
            strcpy(field5,trim(field5));
            strcpy(field7,trim(field7));
            
            if (strcmp(trim(field1),"")!=0)
            {
            	$SELECT trim(iins_type)||trim(nins_type)
            	   INTO $ins_type_print
            	   FROM insurance_type
            	  WHERE iins_type=$field1;
            	
                
            
                sprintf_s(stmt13_1,sizeof stmt13_1," INSERT INTO car353_ins(ipolicy,ins_type_print,ncover_print,mcover_print,mins_premium_print) "
                                "  VALUES ('%s','%s','%s','%s','%s��')",ipolicy_2,ins_type_print,field4,field5,field7);
                printf("stmt13_1[%s]\n",stmt13_1);
                $PREPARE prep13_1 FROM $stmt13_1;
                $EXECUTE prep13_1;
                
            }
            else 
            {
                sprintf_s(stmt13_2,sizeof stmt13_2," UPDATE car353_ins SET  ncover_print=trim(ncover_print)||'<br>%s',mcover_print=trim(mcover_print)||'<br>%s' "
                                "  WHERE ipolicy ='%s' AND ins_type_print='%s' ",field4,field5,ipolicy_2,ins_type_print);
                printf("stmt13_2[%s]\n",stmt13_2);
                $PREPARE prep13_2 FROM $stmt13_2;
                $EXECUTE prep13_2;	
            	
            }
            

            strcpy(field1,"");strcpy(field4,"");strcpy(field5,"");strcpy(field7,"");
            
        }
        $FREE prep13;
        $CLOSE curs13;
        
        $DELETE FROM tbl_print WHERE ipolicy = $tmp_ipolicy;
        
        /*�ӫO�I�حӼ�*/
        strcpy(cntIns,"1");

        sprintf_s(stmt14,sizeof stmt14," SELECT count(*) "
                      "   FROM car353_ins WHERE ipolicy='%s' ",ipolicy_2);
                 
        printf("stmt14[%s]\n",stmt14);
        $PREPARE prep14 FROM $stmt14;
        $EXECUTE prep14 INTO $cntIns;
        
        sprintf_s(content3,sizeof content3 ,
        "           <tr>"
        "               <td align=\"center\" rowspan=\"%s\">���N�I</td>",cntIns);
        
        strcat(content1,content3);
        
        strcpy(ins_type_print,"");
        strcpy(ncover_print,"");
        strcpy(mcover_print,"");
        strcpy(mins_premium_print,"");
        
/*******�I�ة��ӦC�L�϶�**********/  
        int i=0;
        sprintf_s(stmt15,sizeof stmt15," SELECT  ins_type_print,ncover_print,mcover_print,mins_premium_print "
                      "  FROM car353_ins WHERE ipolicy='%s' order by row_no",ipolicy_2);
                 
        printf("stmt15[%s]\n",stmt15);
        $PREPARE prep15 FROM $stmt15;
        $DECLARE curs15 CURSOR FOR prep15;
        $OPEN curs15 ;
        for(;;)
        {
            
            $FETCH curs15 INTO $ins_type_print, $ncover_print, $mcover_print, $mins_premium_print;

            if( SQLCODE == SQLNOTFOUND) break;
            
             
            strcpy(ins_type_print,trim(ins_type_print));
            strcpy(ncover_print,trim(ncover_print));
            strcpy(mcover_print,trim(mcover_print));
            strcpy(mins_premium_print,trim(mins_premium_print));
         
            if (i==0)
            {
                sprintf_s(content4 ,sizeof content4 ,
                "               <td>%s</td>"
                "               <td style=\"border-color:  black transparent black black ;\">%s</td>"
                "               <td align=\"right\">%s</td>"
                "               <td align=\"right\">%s</td>"
                "           </tr>"  
                ,ins_type_print,ncover_print,mcover_print,mins_premium_print);
            }                
            else
            {
                sprintf_s(content4 ,sizeof content4 ,            
    	        "	    <tr>"
    	        "	        <td>%s</td>"
    	        "	        <td style=\"border-color:  black transparent black black ;\">%s</td>"
    	        "	        <td align=\"right\">%s</td>"
    	        "	        <td align=\"right\">%s</td>"
    	        "	    </tr>"
                ,ins_type_print,ncover_print,mcover_print,mins_premium_print);
            }
            strcat(content1,content4);
            i++;
            strcpy(ins_type_print,"");
            strcpy(ncover_print,"");
            strcpy(mcover_print,"");
            strcpy(mins_premium_print,"");
            
        }
        $FREE prep15;
        $CLOSE curs15;
/*****************/ 	
	

	
	
	sprintf_s(content5 ,sizeof content5,
    	"    	    <tr>"
    	"	        <td colspan=\"4\">���N�I�O�O</td><td align=\"right\">%s��</td>"
    	"	    </tr>"	    
    	"	    <tr>"
    	"	        <td colspan=\"4\">�`�O�O</td><td align=\"right\">%s��</td>"
    	"	    </tr>"
    	"	</table>"
    	"	</div>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; �p�����D�м��������q�K�O�ȪA�M�u<font color=\"darkred\"> 0800 - 050 - 119 �� (02)8772 - 7777</font> �߰ݡA<br> "		
    	"	&nbsp; &nbsp; �A�@���`�`�a�P�±z�A�ï��ֱz�αz���a�H<br><br>"
    	"	&nbsp; &nbsp; ���d �ּ�<br><br>"
    	"	<div style=\" width: 700px; text-align: center;\">�s�w�F�ʮ��W�����O�I &nbsp; �q��</div>"
    	"	<br>"
      /*"	<div style=\"width:700;color:#4a4541;background-color: #FFD700; text-align: center;height:22\">0800 �M�u�G0800 - 050 - 119 &nbsp;�q�ܡG(02)8772 - 7777 &nbsp;�x�_�� 104 �n�ʪF���T�q 130 ��</div>"*/
    	"	</td>"
        "    </tr>"
    	"</table>"
        "</body></html>	"
        ,stotal_r,stotal);
        
        
        
        strcat(content1,content5);
        

        
        strcpy(mbuf,content1);
        ctxt.loc_loctype = LOCMEMORY;
        ctxt.loc_buffer = mbuf;
        ctxt.loc_bufsize = 9000;
        ctxt.loc_size =  strlen(mbuf) + 1;
        
        strcpy(receiver_email,"");
        strcpy(receiver_name,"");
        strcpy(receiver_email,trim(aemail_appl));
        strcpy(receiver_name,trim(napplicant));        
        
        /* ���קK���Ƶo�e */
        $delete from batchemail
          where project_id = 'CAR353'
            and mail_date = today
            and receiver_email = $receiver_email
            and nsubject = $nsubject
            and receiver_name = $receiver_name;
            

          
        $INSERT INTO batchemail
		    (project_id, mail_date, receiver_email, receiver_name, cc,
		     content, key, mail_count, nsubject)
        VALUES
		    ('CAR353', today, $receiver_email, $receiver_name, ' ',
		     $ctxt, ' ', $mail_count, $nsubject);
		     
        strcpy(inumber,"");
        sprintf_s(inumber,sizeof inumber,"%04d",count);
        printf("inumber[%s]\n",inumber);
        sprintf_s(stmt18,sizeof stmt18," INSERT INTO car353_email_log"
                       " (ipolicy_c, ipolicy_r, nreceiver, aemail_receiver, inumber) "
                       "  VALUES "
                       " ('%s', '%s', '%s', '%s','%s%s%s%s'); ",ipolicy_1,ipolicy_2,receiver_name,receiver_email,yy_fn,mm_fn,dd_fn, inumber);

        $PREPARE prep18 from $stmt18;
        $EXECUTE prep18 ; 
        
        return M_CM_OK;
errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}
/*----------------------------------------------------------------------------*/
char *only_volu_email_IC(ipolicy_1, itag, aemail_appl, dply_begin, dply_end, napplicant)
char *ipolicy_1,*itag,*aemail_appl,*dply_begin,*dply_end,*napplicant;
{
	
	$whenever sqlerror goto errexit;
	/*�H�oE-mail�q���O��-��� */
	printf("[IN only_volu_email_IC]\n");

	int rc;
	
	$char content1[9000];
	$char content2[100];
	$char content3[2900];
	$char content4[3000];
	$char stmtIC1[1024],stmtIC2[1024],stmtIC2_1[1024],stmtIC2_2[1024],stmtIC3[1024],stmtIC4[1024],stmtIC5[1024];
    char  sDBName[5];
	char  dply_begin_yy[5],dply_begin_mm[3],dply_begin_dd[3],dply_begin_yy2[5];
	char  dply_end_yy[5],dply_end_mm[3],dply_end_dd[3],dply_end_yy2[5];
	char  itag_mask[CA_TAG_NUM],itag_mask_a[CA_TAG_NUM];
	$char iins_type[7];/*,aemail_appl[51],napplicant[121],ipolicy_1[21],itag[CA_TAG_NUM],dply_begin[11],dply_end[11]*/
	$char receiver_email[51],receiver_name[121];
	$int  minjured_cover=0,mdeath_cover=0,mdamage_cover=0,mins_premium=0;
	$char sminjured_cover[25],smdeath_cover[25],smdamage_cover[25],smins_premium[25];
	$char nsubject[512];
	$int  mtotal;
	$char stotal[21];
	$char field1[7],field4[121],field5[121],field7[121];
    $int  line_no=0;
    $char ins_type_print[36];
    $char ncover_print[151],mcover_print[151],mins_premium_print[151];
    $char cntIns[3];
    $char tmp_ipolicy[21];
    $char nleader[11],nleader_tel[15];
    char  inumber[5];
        
	
	mail_count++;
	count++;
	count_IC++;
	strcpy(content1,"");
	strcpy(content2,"");
	strcpy(content3,"");
	strcpy(content4,"");
	strcpy(tmp_ipolicy,trim(ipolicy_1));
	
	/*�B�z�O����ܤ覡*/
	strcpy(dply_begin_yy,"");strcpy(dply_begin_mm,"");strcpy(dply_begin_dd,"");strcpy(dply_begin_yy2,"");
	strcpy(dply_end_yy,"");strcpy(dply_end_mm,"");strcpy(dply_end_dd,"");strcpy(dply_end_yy2,"");
	
	cm_split_ymd(cm_from_infdate(dply_begin),dply_begin_yy,dply_begin_mm,dply_begin_dd);
        strcpy(dply_begin_yy2,itoa(atoi(dply_begin_yy)+1911));
        printf("dply_begin_yy2[%s]dply_begin_mm[%s]dply_begin_dd[%s]\n",dply_begin_yy2,dply_begin_mm,dply_begin_dd);
        
	cm_split_ymd(cm_from_infdate(dply_end),dply_end_yy,dply_end_mm,dply_end_dd);
        strcpy(dply_end_yy2,itoa(atoi(dply_end_yy)+1911));
        printf("dply_end_yy2[%s]dply_end_mm[%s]dply_end_dd[%s]\n",dply_end_yy2,dply_end_mm,dply_end_dd);  
	
	$DELETE FROM car353_ins WHERE 1=1;
	
	strcpy(Full_DB,"");
    strcpy(Full_DB,get_car_full_db(ipolicy_1));

    /*�`�O�O*/
    strcpy(stotal,"");
    mtotal=0;
    sprintf_s(stmtIC1,sizeof stmtIC1, " SELECT sum(mins_premium) "
                   "   FROM %s:ply_ins_type "
                   "  WHERE ipolicy='%s'  ",Full_DB,ipolicy_1);

    $PREPARE preIC1 from $stmtIC1;
    $EXECUTE preIC1 INTO $mtotal; 
    
    strcpy(stotal, refmtamt(mtotal, MILLIONTH));
    
    /*�B�z���P�B�n*/
    printf("itag = [%s]\n",itag);
    strcpy(itag_mask,"");
    strcpy(itag_mask_a,"");
    strncpy(itag_mask_a,itag+2,CA_TAG_NUM);
    printf("itag_mask_a[%s]\n",itag_mask_a);
    strcat(itag_mask,"**");
    strcat(itag_mask,itag_mask_a);
    strcpy(itag_mask,trim(itag_mask));
    printf("itag_mask[%s]\n",itag_mask);

        
        /*email�D��*/
        sprintf_s(nsubject,sizeof nsubject,"�s�w�F�ʮ��W�����O�I-���I�O��ֹ�q��[%s]",ipolicy_1);
        
		/*1120928008_C04_�t�X���q��logo�A�վ�t�β��s���*/
		/** �P�C�u�O���藍�P�A�������@�~����logo **/
        sprintf_s(content1,sizeof content1 ,
        "<html>"
        "<head><meta http-equiv=\"content-type\" content=\"text/html; charset=Big5\" ></head>"
        "<body><br>"
    	"<table style=\"text-align: left; width: 700; background-color: white; height: 545; font-family:�L�n������; font-size:14px;\" border=\"0\" cellpadding=\"1\" cellspacing=\"1\"> "
    	"    <tr>"
    	"       <td style=\"vertical-align: top;\">"
      /*"	    <img style=\"border: 0px solid ; width: 385; height: 85;\"  src=\"https://www.tmnewa.com.tw/img/logo.b33522cc.png\"><br> "
    	"	    <img width=\"700\" height=\"22\" alt=\"\" src=\"https://www.tmnewa.com.tw/img/golden_line_up.50896fc4.png\"><br> "*/
	  /*"       &emsp;&emsp;<a href=\"\"><img width=\"563\" height=\"89\" style=\"border: 0 solid;\" alt=\"\" src=\"https://www.tmnewa.com.tw/img/logo.677af7dd.png\"></a><br> "*/
    	"		</td>"
    	"    </tr>"
    	"    <tr>"
    	"	<td style=\"vertical-align: top;\"><br> "
    	"	&nbsp; &nbsp; �˷R��<font color=\"darkred\"> %s </font>�z�n : <br><br>"
    	"		&nbsp; &nbsp; &nbsp; &nbsp; �̾ڥ����q�����@�~�W�w�A���T�O�ӫO��ƤΫO�O���T�ʡA��C�뵲����A"
    	"	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�w��W�@�맹�����O�B�d��email��ƪ��Ȥ�|�H�o�ֹ���ӨѫO��T�{�A"
    	"	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�H�U���z���~�󥻤��q��O���T�����O�I�O����Ӥ��e�A�q�Ш�U�ֹ�C<br><br>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; ���P���X : <font color=\"darkred\"> %s </font><br>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; ���N�I�O�渹 : <font color=\"darkred\"> %s</font><br>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; ���N�I�O�I���� : <font color=\"darkred\"> %s�~%s��%s�� ����12�� ~ %s�~%s��%s�� ����12��</font><br>"
    	"	<div style=\"margin-left:32px;margin-bottom:5px;margin-top:5px;\">"
    	"	<table border=\"1\" style=\"border-collapse:collapse;font-size:14px;\">"
    	"	    <tr><td></td><td>�I�ئW��</td><td colspan=\"2\">�O�I���B</td><td>ñ��O�O</td></tr>"
        ,napplicant,itag_mask,ipolicy_1,dply_begin_yy2,dply_begin_mm,dply_begin_dd,dply_end_yy2,dply_end_mm,dply_end_dd);
   
   
   
        strcpy(sDBName,"");
        strcpy(sDBName,get_car_short_db(ipolicy_1));
        printf("sDBName[%s]\n",sDBName);
        rc=ca_rpt_policy(ipolicy_1, "", 0, "2", FALSE, 1, " ", "",userid,"0","0",sDBName,"4","","","","0");
        if (rc != M_CM_OK) return rc;
        
        strcpy(field1,"");
        strcpy(field4,"");
        strcpy(field5,"");
        strcpy(field7,"");
            
        /*�ǳ��I�ة��ӦC�L��ơA�s�Jtemp table :car353_ins*/    
        /*tbl_print : ca_rpt_policy�̪�table*/
        /*line_no�Ǹ�,field1�I�إN��,field4�O�B�W��,field5�O�B,field7�O�O*/
        sprintf_s(stmtIC2,sizeof stmtIC2," SELECT  line_no,nvl(field1,''),nvl(field4,''),nvl(field5,''),nvl(field7,'') "
                      "  FROM tbl_print WHERE ipolicy='%s' order by line_no", ipolicy_1);
                 
        printf("stmtIC2[%s]\n",stmtIC2);
        $PREPARE preIC2 FROM $stmtIC2;
        $DECLARE curIC2 CURSOR FOR preIC2;
        $OPEN curIC2;
        while(1)
        {
        
            $FETCH curIC2 INTO $line_no, $field1, $field4, $field5, $field7;

            if( SQLCODE == SQLNOTFOUND) break;
          
            strcpy(field1,trim(field1));
            strcpy(field4,trim(field4));
            strcpy(field5,trim(field5));
            strcpy(field7,trim(field7));
            
            if (strcmp(trim(field1),"") != 0)
            {
            	$SELECT trim(iins_type)||trim(nins_type)
            	   INTO $ins_type_print
            	   FROM insurance_type
            	  WHERE iins_type=$field1;
            
                sprintf_s(stmtIC2_1,sizeof stmtIC2_1," INSERT INTO car353_ins(ipolicy,ins_type_print,ncover_print,mcover_print,mins_premium_print) "
                                "  VALUES ('%s','%s','%s','%s','%s��')",ipolicy_1,ins_type_print,field4,field5,field7);
                printf("stmtIC2_1[%s]\n",stmtIC2_1);
                $PREPARE preIC2_1 FROM $stmtIC2_1;
                $EXECUTE preIC2_1;
                
            }
            else 
            {
                sprintf_s(stmtIC2_2,sizeof stmtIC2_2," UPDATE car353_ins SET  ncover_print=trim(ncover_print)||'<br>%s',mcover_print=trim(mcover_print)||'<br>%s' "
                                "  WHERE ipolicy ='%s' AND ins_type_print='%s' ",field4,field5,ipolicy_1,ins_type_print);
                printf("stmtIC2_2[%s]\n",stmtIC2_2);
                $PREPARE preIC2_2 FROM $stmtIC2_2;
                $EXECUTE preIC2_2;	
            	
            }

            strcpy(field1,"");strcpy(field4,"");strcpy(field5,"");strcpy(field7,"");
            
        }
		
        $FREE preIC2;
        $CLOSE curIC2;
        
        $DELETE FROM tbl_print WHERE ipolicy = $tmp_ipolicy;
        
        strcpy(cntIns,"1");
        
        sprintf_s(stmtIC3,sizeof stmtIC3," SELECT count(*) "
                      "   FROM car353_ins WHERE ipolicy='%s' ",ipolicy_1);
                 
        printf("stmtIC3[%s]\n",stmtIC3);
        $PREPARE preIC3 FROM $stmtIC3;
        $EXECUTE preIC3 INTO $cntIns;
        
        sprintf_s(content2,sizeof content2 ,
        "           <tr>"
        "               <td align=\"center\" rowspan=\"%s\">���N�I</td>",cntIns);
        
        strcat(content1,content2);
        
        strcpy(ins_type_print,"");
        strcpy(ncover_print,"");
        strcpy(mcover_print,"");
        strcpy(mins_premium_print,"");
        
/*******�I�ة��ӦC�L�϶�**********/  
        int i=0;
        sprintf_s(stmtIC4,sizeof stmtIC4," SELECT  ins_type_print,ncover_print,mcover_print,mins_premium_print "
                      "  FROM car353_ins WHERE ipolicy='%s' order by row_no",ipolicy_1);
                 
        printf("stmtIC4[%s]\n",stmtIC4);
        $PREPARE preIC4 FROM $stmtIC4;
        $DECLARE curIC4 CURSOR FOR preIC4;
        $OPEN curIC4;
        while(1)
        {
            
            $FETCH curIC4 INTO $ins_type_print, $ncover_print, $mcover_print, $mins_premium_print;

            if(SQLCODE == SQLNOTFOUND) break;

            strcpy(ins_type_print,trim(ins_type_print));
            strcpy(ncover_print,trim(ncover_print));
            strcpy(mcover_print,trim(mcover_print));
            strcpy(mins_premium_print,trim(mins_premium_print));
         
            if (i==0)
            {
                sprintf_s(content3,sizeof content3 ,
                "               <td>%s</td>"
                "               <td style=\"border-color:  black transparent black black ;\">%s</td>"
                "               <td align=\"right\">%s</td>"
                "               <td align=\"right\">%s</td>"
                "           </tr>"  
                ,ins_type_print,ncover_print,mcover_print,mins_premium_print);
            }                
            else
            {
                sprintf_s(content3,sizeof content3,
    	        "	    <tr>"
    	        "	        <td>%s</td>"
    	        "	        <td style=\"border-color:  black transparent black black ;\">%s</td>"
    	        "	        <td align=\"right\">%s</td>"
    	        "	        <td align=\"right\">%s</td>"
    	        "	    </tr>"
                ,ins_type_print,ncover_print,mcover_print,mins_premium_print);
            }
            strcat(content1,content3);
            i++;
            strcpy(ins_type_print,"");
            strcpy(ncover_print,"");
            strcpy(mcover_print,"");
            strcpy(mins_premium_print,"");
            
        }
        $FREE preIC4;
        $CLOSE curIC4;
/*****************/ 	

	sprintf_s(content4,sizeof content4 ,	    
    	"	    <tr>"
    	"	        <td colspan=\"4\">�`�O�O</td><td align=\"right\">%s��</td>"
    	"	    </tr>"
    	"	</table>"
    	"	</div>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; �p�����D�м��������q�K�O�ȪA�M�u<font color=\"darkred\"> 0800 - 050 - 119 </font>�߰�<br><br>"		
      /*"	&nbsp; &nbsp; �A�@���`�`�a�P�±z�A�ï��ֱz�αz���a�H<br><br>"
    	"	&nbsp; &nbsp; ���d �ּ�<br><br>" */
    	"	<div style=\" width: 700px; text-align: center;\">�s�w�F�ʮ��W�����O�I &nbsp; �q��</div>"
    	"	<br>"
      /*"	<div style=\"width:700;color:#4a4541;background-color: #FFD700; text-align: center;height:22\">0800 �M�u�G0800 - 050 - 119 &nbsp;�q�ܡG(02)8772 - 7777 &nbsp;�x�_�� 104 �n�ʪF���T�q 130 ��</div>"*/
    	"	</td>"
        "    </tr>"
    	"</table>"
        "</body></html>	"
        ,stotal);
        
        
        
        strcat(content1,content4);
        

        
        strcpy(mbuf,content1);
        ctxt.loc_loctype = LOCMEMORY;
        ctxt.loc_buffer = mbuf;
        ctxt.loc_bufsize = 9000;
        ctxt.loc_size =  strlen(mbuf) + 1;
        
        strcpy(receiver_email,"");
        strcpy(receiver_name,"");
        strcpy(receiver_email,trim(aemail_appl));
        strcpy(receiver_name,trim(napplicant));        
        
        /* ���קK���Ƶo�e */
        $delete from batchemail
          where project_id = 'CAR353'
            and mail_date = today
            and receiver_email = $receiver_email
            and nsubject = $nsubject;
            

          
        $INSERT INTO batchemail
		    (project_id, mail_date, receiver_email, receiver_name, cc,
		     content, key, mail_count, nsubject)
        VALUES
		    ('CAR353', today, $receiver_email, $receiver_name, ' ',
		     $ctxt, ' ', $mail_count, $nsubject);
		     
        strcpy(inumber,"");
        sprintf_s(inumber,sizeof inumber,"%04d",count_IC);
        printf("inumber[%s]\n",inumber);
        sprintf_s(stmtIC5,sizeof stmtIC5," INSERT INTO car353_email_log"
                       " (ipolicy_c, ipolicy_r, nreceiver, aemail_receiver, inumber) "
                       "  VALUES "
                       " ('', '%s', '%s', '%s','%s%s%s%s'); ",ipolicy_1,receiver_name,receiver_email,yy_fn,mm_fn,dd_fn, inumber);

        $PREPARE preIC5 from $stmtIC5;
        $EXECUTE preIC5 ; 

        return M_CM_OK;
errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}
/*----------------------------------------------------------------------------*/
char *comp_volu_email_IC(ipolicy_1,ipolicy_2,itag,aemail_appl,napplicant,dply_begin_c,dply_end_c,dply_begin_v,dply_end_v)
char *ipolicy_1,*ipolicy_2,*itag,*aemail_appl,*napplicant,*dply_begin_c,*dply_end_c,*dply_begin_v,*dply_end_v;
{
	$whenever sqlerror goto errexit;
	/*�H�oE-mail�q���O��-�j+�� */
	printf("[IN comp_volu_email_IC]\n");
	
	int rc;
	
	$char content1[9000];
	$char content2[600];
	$char content3[100];
	$char content4[700];
	$char content5[1000];
	$char stmtIC6[1024],stmtIC7[1024],stmtIC8[1024],stmtIC9[1024],stmtIC9_1[1024],stmtIC9_2[1024],stmtIC10[1024],stmtIC11[1024],stmtIC12[1024];
    char  sDBName[5];
	char  dply_begin_c_yy[5],dply_begin_c_mm[3],dply_begin_c_dd[3],dply_begin_c_yy2[5];
	char  dply_end_c_yy[5],dply_end_c_mm[3],dply_end_c_dd[3],dply_end_c_yy2[5];
	char  dply_begin_v_yy[5],dply_begin_v_mm[3],dply_begin_v_dd[3],dply_begin_v_yy2[5];
	char  dply_end_v_yy[5],dply_end_v_mm[3],dply_end_v_dd[3],dply_end_v_yy2[5];
	char  itag_mask[CA_TAG_NUM],itag_mask_a[CA_TAG_NUM];
	$char iins_type[7];/*,aemail_appl[51],napplicant[121],ipolicy_1[21],itag[CA_TAG_NUM],dply_begin[11],dply_end[11]*/
	$char receiver_email[51],receiver_name[121];
	$int  minjured_cover=0,mdeath_cover=0,mdamage_cover=0,mins_premium=0;
	$char sminjured_cover[25],smdeath_cover[25],smdamage_cover[25],smins_premium[25];
	$char nsubject[512];
	$int  mtotal,mtotal_c,mtotal_v;
	$char stotal[21],stotal_c[21],stotal_v[21];
	$char field1[7],field4[121],field5[121],field7[121];
    $int  line_no=0;
    $char ins_type_print[36];
    $char ncover_print[151],mcover_print[151],mins_premium_print[151];
    $char cntIns[3];
    $char tmp_ipolicy[21];
    char  inumber[5];
	
	mail_count++;
	count++;
	count_IC++;
	strcpy(content1,"");
	strcpy(content2,"");
	strcpy(content3,"");
	strcpy(content4,"");
	strcpy(content5,"");
	strcpy(tmp_ipolicy,trim(ipolicy_1));
	
	/*�B�z�O����ܤ覡*/
	strcpy(dply_begin_c_yy,"");strcpy(dply_begin_c_mm,"");strcpy(dply_begin_c_dd,"");strcpy(dply_begin_c_yy2,"");
	strcpy(dply_end_c_yy,"");strcpy(dply_end_c_mm,"");strcpy(dply_end_c_dd,"");strcpy(dply_end_c_yy2,"");
	strcpy(dply_begin_v_yy,"");strcpy(dply_begin_v_mm,"");strcpy(dply_begin_v_dd,"");strcpy(dply_begin_v_yy2,"");
	strcpy(dply_end_v_yy,"");strcpy(dply_end_v_mm,"");strcpy(dply_end_v_dd,"");strcpy(dply_end_v_yy2,"");
	
	cm_split_ymd(cm_from_infdate(dply_begin_c),dply_begin_c_yy,dply_begin_c_mm,dply_begin_c_dd);
        strcpy(dply_begin_c_yy2,itoa(atoi(dply_begin_c_yy)+1911));
        printf("dply_begin_c_yy2[%s]dply_begin_c_mm[%s]dply_begin_c_dd[%s]\n",dply_begin_c_yy2,dply_begin_c_mm,dply_begin_c_dd);
        
	cm_split_ymd(cm_from_infdate(dply_end_c),dply_end_c_yy,dply_end_c_mm,dply_end_c_dd);
        strcpy(dply_end_c_yy2,itoa(atoi(dply_end_c_yy)+1911));
        printf("dply_end_c_yy2[%s]dply_end_c_mm[%s]dply_end_c_dd[%s]\n",dply_end_c_yy2,dply_end_c_mm,dply_end_c_dd);  

	cm_split_ymd(cm_from_infdate(dply_begin_v),dply_begin_v_yy,dply_begin_v_mm,dply_begin_v_dd);
        strcpy(dply_begin_v_yy2,itoa(atoi(dply_begin_v_yy)+1911));
        printf("dply_begin_v_yy2[%s]dply_begin_v_mm[%s]dply_begin_v_dd[%s]\n",dply_begin_v_yy2,dply_begin_v_mm,dply_begin_v_dd);
        
	cm_split_ymd(cm_from_infdate(dply_end_v),dply_end_v_yy,dply_end_v_mm,dply_end_v_dd);
        strcpy(dply_end_v_yy2,itoa(atoi(dply_end_v_yy)+1911));
        printf("dply_end_v_yy2[%s]dply_end_v_mm[%s]dply_end_v_dd[%s]\n",dply_end_v_yy2,dply_end_v_mm,dply_end_v_dd);
	
	$DELETE FROM car353_ins WHERE 1=1;
	
	strcpy(Full_DB,"");
    strcpy(Full_DB,get_car_full_db(ipolicy_2));
	
	mtotal = mtotal_c = mtotal_v = 0;
	
	/**�j��O�O**/
	strcpy(stotal, "");
	strcpy(stotal_c, "");
	strcpy(stotal_v, "");
	
	sprintf_s(stmtIC6, sizeof stmtIC6, 
	          " SELECT sum(mins_premium)"
			  "   FROM %s:ply_ins_type "
			  "  WHERE ipolicy = '%s' ", Full_DB, ipolicy_2);
	
	$PREPARE preIC6 FROM $stmtIC6;
	$EXECUTE preIC6 INTO $mtotal_c;
	
	strcpy(stotal_c, refmtamt(mtotal_c, MILLIONTH));
	
	strcpy(Full_DB, "");
	strcpy(Full_DB, get_car_full_db(ipolicy_1));
	
	/** ���N�O�O **/
	strcpy(stotal, "");
	sprintf_s(stmtIC7, sizeof stmtIC7,
	          " SELECT sum(mins_premium)"
			  "   FROM %s:ply_ins_type "
			  "  WHERE ipolicy = '%s' ", Full_DB, ipolicy_1);
	$PREPARE preIC7 FROM $stmtIC7;
	$EXECUTE preIC7 INTO $mtotal_v;
	
	strcpy(stotal_v, refmtamt(mtotal_v, MILLIONTH));
	
	/** �j+���O�O**/
	mtotal = mtotal_c + mtotal_v;
	strcpy(stotal, refmtamt(mtotal, MILLIONTH));
	
	/** �B�z���P�B�n **/
	printf("itag = [%s]\n",itag);
    strcpy(itag_mask,"");
    strcpy(itag_mask_a,"");
    strncpy(itag_mask_a,itag+2,CA_TAG_NUM);
    printf("itag_mask_a[%s]\n",itag_mask_a);
    strcat(itag_mask,"**");
    strcat(itag_mask,itag_mask_a);
    strcpy(itag_mask,trim(itag_mask));
    printf("itag_mask[%s]\n",itag_mask);
	
	/*email�D��*/
        sprintf_s(nsubject,sizeof nsubject,"�s�w�F�ʮ��W�����O�I-���I�O��ֹ�q��[%s/%s]",ipolicy_2,ipolicy_1);
        
		/*1120928008_C04_�t�X���q��logo�A�վ�t�β��s���*/
		/** �P�C�u�O���藍�P�A�������@�~����logo **/
        sprintf_s(content1 ,sizeof content1,
        "<html>"
        "<head><meta http-equiv=\"content-type\" content=\"text/html; charset=Big5\" ></head>"
        "<body><br>"
    	"<table style=\"text-align: left; width: 700; background-color: white; height: 545; font-family:�L�n������; font-size:14px;\" border=\"0\" cellpadding=\"1\" cellspacing=\"1\"> "
    	"    <tr>"
    	"       <td style=\"vertical-align: top;\">"
      /*"	    <img style=\"border: 0px solid ; width: 385; height: 85;\"  src=\"https://www.tmnewa.com.tw/img/logo.b33522cc.png\"><br> "
    	"	    <img width=\"700\" height=\"22\" alt=\"\" src=\"https://www.tmnewa.com.tw/img/golden_line_up.50896fc4.png\"><br> "*/
	  /*"       &emsp;&emsp;<a href=\"\"><img width=\"563\" height=\"89\" style=\"border: 0 solid;\" alt=\"\" src=\"https://www.tmnewa.com.tw/img/logo.677af7dd.png\"></a><br> "*/
    	"		</td>"
    	"    </tr>"
    	"    <tr>"
    	"	<td style=\"vertical-align: top;\"><br> "
    	"	&nbsp; &nbsp; �˷R��<font color=\"darkred\"> %s </font>�z�n : <br><br>"
    	"		&nbsp; &nbsp; &nbsp; &nbsp; �̾ڥ����q�����@�~�W�w�A���T�O�ӫO��ƤΫO�O���T�ʡA��C�뵲����A"
    	"	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�w��W�@�맹�����O�B�d��email��ƪ��Ȥ�|�H�o�ֹ���ӨѫO��T�{�A"
    	"	<br>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;�H�U���z���~�󥻤��q��O���T�����O�I�O����Ӥ��e�A�q�Ш�U�ֹ�C<br><br>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; ���P���X : <font color=\"darkred\"> %s </font><br>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; �j���I�O�渹 : <font color=\"darkred\"> %s</font><br>"    	
    	"	&nbsp; &nbsp; &nbsp; &nbsp; ���N�I�O�渹 : <font color=\"darkred\"> %s</font><br>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; �j���I�O�I���� : <font color=\"darkred\"> %s�~%s��%s�� ����12�� ~ %s�~%s��%s�� ����12��</font><br>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; ���N�I�O�I���� : <font color=\"darkred\"> %s�~%s��%s�� ����12�� ~ %s�~%s��%s�� ����12��</font><br>"
    	"	<div style=\"margin-left:32px;margin-bottom:5px;margin-top:5px;\">"
    	"	<table border=\"1\" style=\"border-collapse:collapse;font-size:14px;\">"
    	"	    <tr><td></td><td>�I�ئW��</td><td colspan=\"2\">�O�I���B</td><td>ñ��O�O</td></tr>"
        ,napplicant,itag_mask,ipolicy_2,ipolicy_1
        ,dply_begin_c_yy2,dply_begin_c_mm,dply_begin_c_dd,dply_end_c_yy2,dply_end_c_mm,dply_end_c_dd
        ,dply_begin_v_yy2,dply_begin_v_mm,dply_begin_v_dd,dply_end_v_yy2,dply_end_v_mm,dply_end_v_dd);
   
   
        /*�j���I����*/
        mins_premium=0;
		strcpy(Full_DB,"");
        strcpy(Full_DB,get_car_full_db(ipolicy_2));
        /*����j��O�B�B�O�O*/
        sprintf_s(stmtIC8,sizeof stmtIC8, " SELECT iins_type,minjured_cover,mdeath_cover,mdamage_cover,mins_premium "
                       "   FROM %s:ply_ins_type "
                       "  WHERE ipolicy='%s'  ",Full_DB,ipolicy_2);

        $PREPARE preIC8 from $stmtIC8;
        $EXECUTE preIC8 INTO $iins_type, $minjured_cover, $mdeath_cover, $mdamage_cover, $mins_premium; 
       
        strcpy(sminjured_cover,"");
        strcpy(smdeath_cover,"");
        strcpy(smdamage_cover,"");
        strcpy(smins_premium,"");
         
        strcpy(sminjured_cover,rtrim(refmtamt(minjured_cover,MILLIONTH)));
        strcpy(smdeath_cover,rtrim(refmtamt(mdeath_cover,MILLIONTH)));
        strcpy(smdamage_cover,rtrim(refmtamt(mdamage_cover,MILLIONTH)));
        strcpy(smins_premium,rtrim(refmtamt(mins_premium,MILLIONTH)));
        
        sprintf_s(content2,sizeof content2,
    	"	    <tr>"
    	"	        <td align=\"center\">�j���I</td>"
    	"	        <td>21�j��T���d���O�I</td>"
        "                <td style=\"border-color:  black transparent black black ;\">�C�@�ӤH��� <br>�C�@�ӤH���`�Υ��� </td>"
        "                <td align=\"right\">%s<br>%s </td>"           
        "                <td align=\"right\">%s��</td>"
    	"	    </tr>"
    	"    	    <tr>"
    	"	        <td colspan=\"4\">�j���I�O�O</td><td align=\"right\">%s��</td>"
    	"	    </tr>"
        ,sminjured_cover,smdeath_cover,smins_premium,smins_premium);
        
        strcat(content1,content2);
   
        /*���N�I����*/
        strcpy(sDBName,"");
        strcpy(sDBName,get_car_short_db(ipolicy_1));
        printf("sDBName[%s]\n",sDBName);
        rc=ca_rpt_policy(ipolicy_1, "", 0, "2", FALSE, 1, " ", "",userid,"0","0",sDBName,"4","","","","0");
        if (rc != M_CM_OK) return rc;
        
        strcpy(field1,"");
        strcpy(field4,"");
        strcpy(field5,"");
        strcpy(field7,"");
            
        /*�ǳ��I�ة��ӦC�L��ơA�s�Jtemp table :car353_ins*/    
        /*tbl_print : ca_rpt_policy�̪�table*/
        /*line_no�Ǹ�,field1�I�إN��,field4�O�B�W��,field5�O�B,field7�O�O*/
        sprintf_s(stmtIC9,sizeof stmtIC9," SELECT  line_no,nvl(field1,''),nvl(field4,''),nvl(field5,''),nvl(field7,'') "
                      "  FROM tbl_print WHERE ipolicy='%s' order by line_no",ipolicy_1);
                 
        printf("stmtIC9[%s]\n",stmtIC9);
        $PREPARE preIC9 FROM $stmtIC9;
        $DECLARE curIC9 CURSOR FOR preIC9;
        $OPEN curIC9;
        while(1)
        {
            $FETCH curIC9 INTO $line_no, $field1, $field4, $field5, $field7;
			
            if( SQLCODE == SQLNOTFOUND) break;
          
            strcpy(field1,trim(field1));
            strcpy(field4,trim(field4));
            strcpy(field5,trim(field5));
            strcpy(field7,trim(field7));
            
            if (strcmp(trim(field1),"")!=0)
            {
            	$SELECT trim(iins_type)||trim(nins_type)
            	   INTO $ins_type_print
            	   FROM insurance_type
            	  WHERE iins_type=$field1;
            	
                
            
                sprintf_s(stmtIC9_1,sizeof stmtIC9_1," INSERT INTO car353_ins(ipolicy,ins_type_print,ncover_print,mcover_print,mins_premium_print) "
                                "  VALUES ('%s','%s','%s','%s','%s��')",ipolicy_1,ins_type_print,field4,field5,field7);
                printf("stmtIC9_1[%s]\n",stmtIC9_1);
                $PREPARE preIC9_1 FROM $stmtIC9_1;
                $EXECUTE preIC9_1;
                
            }
            else 
            {
                sprintf_s(stmtIC9_2,sizeof stmtIC9_2," UPDATE car353_ins SET  ncover_print=trim(ncover_print)||'<br>%s',mcover_print=trim(mcover_print)||'<br>%s' "
                                "  WHERE ipolicy ='%s' AND ins_type_print='%s' ",field4,field5,ipolicy_1,ins_type_print);
                printf("stmtIC9_2[%s]\n",stmtIC9_2);
                $PREPARE preIC9_2 FROM $stmtIC9_2;
                $EXECUTE preIC9_2;	
            	
            }

            strcpy(field1,"");strcpy(field4,"");strcpy(field5,"");strcpy(field7,"");
            
        }
        $FREE preIC9;
        $CLOSE curIC9;
        
        $DELETE FROM tbl_print WHERE ipolicy = $tmp_ipolicy;
        
        /*�ӫO�I�حӼ�*/
        strcpy(cntIns,"1");

        sprintf_s(stmtIC10,sizeof stmtIC10," SELECT count(*) "
                      "   FROM car353_ins WHERE ipolicy='%s' ",ipolicy_1);
                 
        printf("stmtIC10[%s]\n",stmtIC10);
        $PREPARE preIC10 FROM $stmtIC10;
        $EXECUTE preIC10 INTO $cntIns;
        
        sprintf_s(content3,sizeof content3 ,
        "           <tr>"
        "               <td align=\"center\" rowspan=\"%s\">���N�I</td>",cntIns);
        
        strcat(content1,content3);
        
        strcpy(ins_type_print,"");
        strcpy(ncover_print,"");
        strcpy(mcover_print,"");
        strcpy(mins_premium_print,"");
        
/*******�I�ة��ӦC�L�϶�**********/  
        int i=0;
        sprintf_s(stmtIC11,sizeof stmtIC11," SELECT  ins_type_print,ncover_print,mcover_print,mins_premium_print "
                      "  FROM car353_ins WHERE ipolicy='%s' order by row_no",ipolicy_1);
                 
        printf("stmtIC11[%s]\n",stmtIC11);
        $PREPARE preIC11 FROM $stmtIC11;
        $DECLARE curIC11 CURSOR FOR preIC11;
        $OPEN curIC11;
		
        while(1)
        {
            
            $FETCH curIC11 INTO $ins_type_print, $ncover_print, $mcover_print, $mins_premium_print;

            if(SQLCODE == SQLNOTFOUND) break;

            strcpy(ins_type_print,trim(ins_type_print));
            strcpy(ncover_print,trim(ncover_print));
            strcpy(mcover_print,trim(mcover_print));
            strcpy(mins_premium_print,trim(mins_premium_print));
         
            if (i==0)
            {
                sprintf_s(content4 ,sizeof content4 ,
                "               <td>%s</td>"
                "               <td style=\"border-color:  black transparent black black ;\">%s</td>"
                "               <td align=\"right\">%s</td>"
                "               <td align=\"right\">%s</td>"
                "           </tr>"  
                ,ins_type_print,ncover_print,mcover_print,mins_premium_print);
            }                
            else
            {
                sprintf_s(content4 ,sizeof content4 ,            
    	        "	    <tr>"
    	        "	        <td>%s</td>"
    	        "	        <td style=\"border-color:  black transparent black black ;\">%s</td>"
    	        "	        <td align=\"right\">%s</td>"
    	        "	        <td align=\"right\">%s</td>"
    	        "	    </tr>"
                ,ins_type_print,ncover_print,mcover_print,mins_premium_print);
            }
            strcat(content1,content4);
            i++;
            strcpy(ins_type_print,"");
            strcpy(ncover_print,"");
            strcpy(mcover_print,"");
            strcpy(mins_premium_print,"");
            
        }
		
        $FREE preIC11;
        $CLOSE curIC11;

/*****************/ 	
	
	sprintf_s(content5 ,sizeof content5,
    	"    	    <tr>"
    	"	        <td colspan=\"4\">���N�I�O�O</td><td align=\"right\">%s��</td>"
    	"	    </tr>"	    
    	"	    <tr>"
    	"	        <td colspan=\"4\">�`�O�O</td><td align=\"right\">%s��</td>"
    	"	    </tr>"
    	"	</table>"
    	"	</div>"
    	"	&nbsp; &nbsp; &nbsp; &nbsp; �p�����D�м��������q�K�O�ȪA�M�u<font color=\"darkred\"> 0800 - 050 - 119</font> �߰�<br><br> "		
      /*"	&nbsp; &nbsp; �A�@���`�`�a�P�±z�A�ï��ֱz�αz���a�H<br><br>"
    	"	&nbsp; &nbsp; ���d �ּ�<br><br>" */
    	"	<div style=\" width: 700px; text-align: center;\">�s�w�F�ʮ��W�����O�I &nbsp; �q��</div>"
    	"	<br>"
      /*"	<div style=\"width:700;color:#4a4541;background-color: #FFD700; text-align: center;height:22\">0800 �M�u�G0800 - 050 - 119 &nbsp;�q�ܡG(02)8772 - 7777 &nbsp;�x�_�� 104 �n�ʪF���T�q 130 ��</div>"*/
    	"	</td>"
        "    </tr>"
    	"</table>"
        "</body></html>	"
        ,stotal_v,stotal);

        strcat(content1,content5);

        strcpy(mbuf,content1);
        ctxt.loc_loctype = LOCMEMORY;
        ctxt.loc_buffer = mbuf;
        ctxt.loc_bufsize = 9000;
        ctxt.loc_size =  strlen(mbuf) + 1;
        
        strcpy(receiver_email,"");
        strcpy(receiver_name,"");
        strcpy(receiver_email,trim(aemail_appl));
        strcpy(receiver_name,trim(napplicant));        
        
        /* ���קK���Ƶo�e */
        $delete from batchemail
          where project_id = 'CAR353'
            and mail_date = today
            and receiver_email = $receiver_email
            and nsubject = $nsubject
            and receiver_name = $receiver_name;
            

          
        $INSERT INTO batchemail
		    (project_id, mail_date, receiver_email, receiver_name, cc,
		     content, key, mail_count, nsubject)
        VALUES
		    ('CAR353', today, $receiver_email, $receiver_name, ' ',
		     $ctxt, ' ', $mail_count, $nsubject);
		     
        strcpy(inumber,"");
        sprintf_s(inumber,sizeof inumber,"%04d",count_IC);
        printf("inumber[%s]\n",inumber);
        sprintf_s(stmtIC12,sizeof stmtIC12," INSERT INTO car353_email_log"
                       " (ipolicy_r, ipolicy_c, nreceiver, aemail_receiver, inumber) "
                       "  VALUES "
                       " ('%s', '%s', '%s', '%s','%s%s%s%s'); ",ipolicy_1,ipolicy_2,receiver_name,receiver_email,yy_fn,mm_fn,dd_fn, inumber);

        $PREPARE preIC12 from $stmtIC12;
        $EXECUTE preIC12; 
        
        return M_CM_OK;


errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}
/*----------------------------------------------------------------------------*/
char *car353_SMS_IC(ipolicy_1, ipolicy_2, itag, tmobile_appl, dply_begin, dply_end, napplicant, isBoth, fserial, SMS_count)
char *ipolicy_1, *ipolicy_2, *itag, *tmobile_appl, *dply_begin, *dply_end, *napplicant, *fserial;
int isBoth, SMS_count;
{
	
	$whenever sqlerror goto errexit;
	/*�s�@²�T�q���O�� */
	printf("[IN car353_SMS_IC]\n");
	int fname_yy;
	char fname_yy2[5];
	char fname_date[15];
	int rc;
	char content_SMS[9000], content_temp[1000], content_temp2[1000];
	$char stmtIC13[1024];
	char inumber[5];
	
	char dply_begin_yy[5], dply_begin_mm[3], dply_begin_dd[3], dply_begin_yy2[5];
	char dply_end_yy[5], dply_end_mm[3], dply_end_dd[3], dply_end_yy2[5];
	char itag_mask[CA_TAG_NUM], itag_mask_a[CA_TAG_NUM];
	$char stotal_c[21], stotal_v[21], stotal[21];
	$int mtotal_c = 0, mtotal_v = 0, mtotal = 0;
	$int has01 = 0, has11 = 0, has31 = 0, has21 = 0;
	$char receiver_name[50], receiver_mobile[20];
	fname_yy = atoi(yy_fn); fname_yy += 1911; strcpy(fname_yy2, itoa(fname_yy));
	
	
	count_IC++;
	
	sprintf_s(fname_SMS_IC, sizeof fname_SMS_IC, "car353SMS%s%s%s%s", fname_yy2, mm_fn, dd_fn, fserial);
	sprintf_s(filename_SMS_IC, sizeof filename_SMS_IC, "%s/rptftp/%s.txt", sApHome, fname_SMS_IC);
	
	strcpy(receiver_name, trim(napplicant));
	strcpy(receiver_mobile, trim(tmobile_appl));
	
	/*�B�z�O����ܤ覡*/
	strcpy(dply_begin_yy,"");strcpy(dply_begin_mm,"");strcpy(dply_begin_dd,"");strcpy(dply_begin_yy2,"");
	strcpy(dply_end_yy,"");strcpy(dply_end_mm,"");strcpy(dply_end_dd,"");strcpy(dply_end_yy2,"");
	
	cm_split_ymd(cm_from_infdate(dply_begin),dply_begin_yy,dply_begin_mm,dply_begin_dd);
        /*strcpy(dply_begin_yy2,itoa(atoi(dply_begin_yy)+1911));
        printf("dply_begin_yy2[%s]dply_begin_mm[%s]dply_begin_dd[%s]\n",dply_begin_yy2,dply_begin_mm,dply_begin_dd);*/
        
	cm_split_ymd(cm_from_infdate(dply_end),dply_end_yy,dply_end_mm,dply_end_dd);
        /*strcpy(dply_end_yy2,itoa(atoi(dply_end_yy)+1911));
        printf("dply_end_yy2[%s]dply_end_mm[%s]dply_end_dd[%s]\n",dply_end_yy2,dply_end_mm,dply_end_dd);*/
	
	/** �B�z���P�B�n **/
	printf("itag = [%s]\n",itag);
    strcpy(itag_mask,"");
    strcpy(itag_mask_a,"");
    strncpy(itag_mask_a,itag+2,CA_TAG_NUM);
    printf("itag_mask_a[%s]\n",itag_mask_a);
    strcat(itag_mask,"**");
    strcat(itag_mask,itag_mask_a);
    strcpy(itag_mask,trim(itag_mask));
    printf("itag_mask[%s]\n",itag_mask);
	
	/** ���N **/
	
	strcpy(Full_DB, "");
	strcpy(Full_DB, get_car_full_db(ipolicy_1));
	
	sprintf_s(content_SMS, sizeof content_SMS,
	          "%s%03d$$%s$$$$$$$$$$�s�w�F�ʮ��W���I�q���G�z�����I�O��%s�wú�O�A����%s�A�O��%s/%s/%s~%s/%s/%s�A��O�I�ءG",
			    tmobile_appl, SMS_count, tmobile_appl, ipolicy_1, itag_mask, dply_begin_yy, dply_begin_mm, dply_begin_dd, dply_end_yy, dply_end_mm, dply_end_dd);
	
	sprintf_s(stmtIC13, sizeof stmtIC13, 
	          " SELECT count(*) "
			  "   FROM insurance_type a, %s:ply_ins_type b "
			  "  WHERE b.ipolicy = '%s' "
			  "    AND a.iins_type = b.iins_type"
			  "    AND a.iri_ins = '01' ", Full_DB, ipolicy_1);
	$PREPARE preIC13 FROM $stmtIC13;
	$EXECUTE preIC13 INTO $has01;
	
	sprintf_s(stmtIC13, sizeof stmtIC13, 
	          " SELECT count(*) "
			  "   FROM insurance_type a, %s:ply_ins_type b "
			  "  WHERE b.ipolicy = '%s' "
			  "    AND a.iins_type = b.iins_type"
			  "    AND a.iri_ins = '11' ", Full_DB, ipolicy_1);
	$PREPARE preIC13 FROM $stmtIC13;
	$EXECUTE preIC13 INTO $has11;
	
	sprintf_s(stmtIC13, sizeof stmtIC13, 
	          " SELECT count(*) "
			  "   FROM insurance_type a, %s:ply_ins_type b "
			  "  WHERE b.ipolicy = '%s' "
			  "    AND a.iins_type = b.iins_type"
			  "    AND a.iri_ins = '31' ", Full_DB, ipolicy_1);
	$PREPARE preIC13 FROM $stmtIC13;
	$EXECUTE preIC13 INTO $has31;
	
	if(has01 >= 1)
	{
		strcat(content_SMS, "�����I");
	}
	
	if(has11 >= 1)
	{
		if(has01 <= 0)
		{
			strcat(content_SMS, "�ѵs�I");
		}
		else
		{
			strcat(content_SMS, "�A�ѵs�I");
		}
	}
	
	if(has31 >= 1)
	{
		if(has01 <= 0 && has11 <= 0)
		{
			strcat(content_SMS, "�ĤT�H�d���I");
		}
		else
		{
			strcat(content_SMS, "�A�ĤT�H�d���I");
		}
	}
	
	sprintf_s(stmtIC13, sizeof stmtIC13,
	          " SELECT sum(mins_premium) "
			  "   FROM %s:ply_ins_type "
			  "  WHERE ipolicy = '%s' ", Full_DB, ipolicy_1);
	$PREPARE preIC13 FROM $stmtIC13;
	$EXECUTE preIC13 INTO $mtotal_v;
	
	strcpy(stotal_v, itoa(mtotal_v));
	
	sprintf_s(content_temp, sizeof content_temp, "�Ψ���[�I�A�O�O%s��", stotal_v);
	
	if(isBoth == 1)
	{
		strcpy(Full_DB, "");
		strcpy(Full_DB, get_car_full_db(ipolicy_2));
		sprintf_s(stmtIC13, sizeof stmtIC13,
	          " SELECT sum(mins_premium) "
			  "   FROM %s:ply_ins_type "
			  "  WHERE ipolicy = '%s' ", Full_DB, ipolicy_2);
		$PREPARE preIC13 FROM $stmtIC13;
		$EXECUTE preIC13 INTO $mtotal_c;
		
		/*mtotal = mtotal_v + mtotal_c;*/ /** �j+���O�O */
		strcpy(stotal_c, itoa(mtotal_c));
		sprintf_s(content_temp2, sizeof content_temp2, "�A�j���I%s��", stotal_c);
		strcat(content_temp, content_temp2);
	}
	
	strcat(content_temp, "�A�p���ðݡA�м��ȪA�M�u0800-050-119");
	strcat(content_SMS, content_temp);
	
	if ((fp = fopen(filename_SMS_IC, "a")) == NULL)
    {
        printf("�}��Log�ɮץ��ѡI \n");
        exit(1);
    }
	
	fprintf(fp, "%s\n", content_SMS);
	
	fclose(fp);
	
	strcpy(inumber,"");
    sprintf_s(inumber,sizeof inumber,"%04d", count_IC);
    printf("inumber[%s]\n",inumber);
	
	if(isBoth == 0)
	{
		sprintf_s(stmtIC13,sizeof stmtIC13," INSERT INTO car353_email_log"
				  " (ipolicy_c, ipolicy_r, nreceiver, tmobile_receiver, inumber) "
				  "  VALUES "
				  " ('', '%s', '%s', '%s','%s%s%s%s'); ",ipolicy_1,receiver_name,receiver_mobile,yy_fn,mm_fn,dd_fn, inumber);
	}
	else
	{
		sprintf_s(stmtIC13,sizeof stmtIC13," INSERT INTO car353_email_log"
				  " (ipolicy_r, ipolicy_c, nreceiver, tmobile_receiver, inumber) "
				  "  VALUES "
				  " ('%s', '%s', '%s', '%s','%s%s%s%s'); ",ipolicy_1, ipolicy_2,receiver_name,receiver_mobile,yy_fn,mm_fn,dd_fn, inumber);
	}
	$PREPARE preIC13 FROM $stmtIC13;
	$EXECUTE preIC13;
	
	return M_CM_OK;

errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car353_send_email_empl()
{
     $whenever sqlerror goto errexit;
     $int  rc;
     char  sMsg[100];
     $char receiver_name[121], receiver_email[51];
     $char stmt22[1024],content1[1000];
     $char nsubject[512];
     
     $char ipolicy_c[21],ipolicy_r[21],iassured[13],nassured[121],iemail[51],itag[CA_TAG_NUM],iengine[26],ibrand[9];
     $char dbegin_c[11],dend_c[11],dbegin_r[11],dend_r[11],icar_type_c[3],icar_type_r[3],iofficer[11],nofficer[11],iroute[21];
     $char iquota[7],nbranch[41],ileader[11],nleader[11],iapplicant[21],napplicant[121],nrelation_appl[41],nrelation_other[2];
     $char aemail_appl[51],nreceiver[121],aemail_receiver[51],dcreate[11],inumber[13];
     $char stmt19[1024],stmt20[1024],stmt21[1024];
     
    /* ���Y */
    strcpy(ftitle,
           "�j���I�O�渹,���N�I�O�渹,�Q�O�I�HID,�Q�O�I�H�W��,�Q�O�I�HEmail,�P�Ӹ��X,�������X,�t�P�����N��,"
           "�j��_��,�j����,���N�_��,���N���,�j���,���N����,�g��N��,�g��W��,�q���N��,"
           "�~�Z���N��,�~�Z���W��,�޲z�H�N��,�޲z�H�W��,�n�O�HID,�n�O�H�W��,�n�O�H�P�Q�O�I�H���Y,��L���Y����,"
           "�n�O�Hemail,����H,�H�eEmail,�H�o���,�Ǹ�\n");
    fprintf(fp,ftitle);
    
    
    for(i=0;i<count_db;i++) 
    {    
        
        /*��j*/
        sprintf_s(stmt19,sizeof stmt19," SELECT f.ipolicy_c ,'',a.iassured,a.nassured,a.iemail,a.itag,a.iengine,b.ibrand, "
                      "        b.dply_begin,b.dply_end,'','',b.icar_type,'',b.iofficer,c.nname,a.iroute,"
                      "        b.iquota,d.nbranch,b.ileader,e.nname,a.iapplicant,a.napplicant,a.nrelation_appl,'', "
                      "        a.aemail_appl,f.nreceiver,f.aemail_receiver,today,f.inumber "
                      "   FROM %s:policy a,%s:ply_relation b,officer c,sa_branch_type d,officer e,car353_email_log f "
                      "  WHERE a.ipolicy=b.ipolicy AND b.iofficer=c.iofficer AND d.ibranch=b.iquota "
                      "    AND a.ipolicy IN (SELECT ipolicy_c FROM car353_email_log WHERE ipolicy_r='') AND b.ileader=e.iofficer "
                      "    AND a.ipolicy=f.ipolicy_c ",list[i].dbname,list[i].dbname);
                 
        printf("stmt19[%s]\n",stmt19);
        $PREPARE prep19 FROM $stmt19;
        $DECLARE curs19 CURSOR FOR prep19;
        $OPEN curs19 ;
        for(;;)
        {
            
            $FETCH curs19 INTO  $ipolicy_c,  $ipolicy_r, $iassured,        $nassured, $iemail,      $itag,        $iengine,        $ibrand,
                                $dbegin_c,   $dend_c,    $dbegin_r,        $dend_r,   $icar_type_c, $icar_type_r, $iofficer,       $nofficer,       $iroute,
                                $iquota,     $nbranch,   $ileader,         $nleader,  $iapplicant,  $napplicant,  $nrelation_appl, $nrelation_other,
                                $aemail_appl,$nreceiver, $aemail_receiver, $dcreate,  $inumber;

            if( SQLCODE == SQLNOTFOUND) break;
            
            
            
             
            fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,"
                       "%s,%s,%s,%s,%s,%s,%s,%s,%s,"
                       "%s,%s,%s,%s,%s,%s,%s,%s,"
                       "%s,%s,%s,%s,%s\n",
                       ipolicy_c,  ipolicy_r, iassured,        nassured, iemail,      itag,        iengine,        ibrand,
                       dbegin_c,   dend_c,    dbegin_r,        dend_r,   icar_type_c, icar_type_r, iofficer,       nofficer,       iroute,
                       iquota,     nbranch,   ileader,         nleader,  iapplicant,  napplicant,  nrelation_appl, nrelation_other,
                       aemail_appl,nreceiver, aemail_receiver, dcreate,  inumber);
         
            
            
        }
        $FREE prep19;
        $CLOSE curs19;  
        
        /*���*/
        sprintf_s(stmt20,sizeof stmt20," SELECT '' ,f.ipolicy_r,a.iassured,a.nassured,a.iemail,a.itag,a.iengine,b.ibrand, "
                      "        '','',b.dply_begin,b.dply_end,'',b.icar_type,b.iofficer,c.nname,a.iroute,"
                      "        b.iquota,d.nbranch,b.ileader,e.nname,a.iapplicant,a.napplicant,a.nrelation_appl,'', "
                      "        a.aemail_appl,f.nreceiver,f.aemail_receiver,today,f.inumber "
                      "   FROM %s:policy a,%s:ply_relation b,officer c,sa_branch_type d,officer e,car353_email_log f "
                      "  WHERE a.ipolicy=b.ipolicy AND b.iofficer=c.iofficer AND d.ibranch=b.iquota "
                      "    AND a.ipolicy IN (SELECT ipolicy_r FROM car353_email_log WHERE ipolicy_c='') AND b.ileader=e.iofficer "
                      "    AND a.ipolicy=f.ipolicy_r ",list[i].dbname,list[i].dbname);
                 
        printf("stmt20[%s]\n",stmt20);
        $PREPARE prep20 FROM $stmt20;
        $DECLARE curs20 CURSOR FOR prep20;
        $OPEN curs20 ;
        for(;;)
        {
            
            $FETCH curs20 INTO  $ipolicy_c,  $ipolicy_r, $iassured,        $nassured, $iemail,      $itag,        $iengine,        $ibrand,
                                $dbegin_c,   $dend_c,    $dbegin_r,        $dend_r,   $icar_type_c, $icar_type_r, $iofficer,       $nofficer,       $iroute,
                                $iquota,     $nbranch,   $ileader,         $nleader,  $iapplicant,  $napplicant,  $nrelation_appl, $nrelation_other,
                                $aemail_appl,$nreceiver, $aemail_receiver, $dcreate,  $inumber;

            if( SQLCODE == SQLNOTFOUND) break;
            
            
            
             
            fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,"
                       "%s,%s,%s,%s,%s,%s,%s,%s,%s,"
                       "%s,%s,%s,%s,%s,%s,%s,%s,"
                       "%s,%s,%s,%s,%s\n",
                       ipolicy_c,  ipolicy_r, iassured,        nassured, iemail,      itag,        iengine,        ibrand,
                       dbegin_c,   dend_c,    dbegin_r,        dend_r,   icar_type_c, icar_type_r, iofficer,       nofficer,       iroute,
                       iquota,     nbranch,   ileader,         nleader,  iapplicant,  napplicant,  nrelation_appl, nrelation_other,
                       aemail_appl,nreceiver, aemail_receiver, dcreate,  inumber);
         
            
            
        }
        $FREE prep20;
        $CLOSE curs20;  
        
        
        /*�j+��*/        
        sprintf_s(stmt21,sizeof stmt21," SELECT h.ipolicy_c ,h.ipolicy_r,g.iassured,g.nassured,g.iemail,g.itag,g.iengine,f.ibrand, "
                       "        b.dply_begin,b.dply_end,f.dply_begin,f.dply_end,b.icar_type,f.icar_type,f.iofficer,c.nname,g.iroute,"
                       "        f.iquota,d.nbranch,f.ileader,e.nname,g.iapplicant,g.napplicant,g.nrelation_appl,'',"
                       "        g.aemail_appl,h.nreceiver,h.aemail_receiver,today,h.inumber"
                       "   FROM %s:policy a,%s:ply_relation b,officer c,sa_branch_type d,officer e,%s:ply_relation f,%s:policy g,car353_email_log h"
                       "  WHERE a.ipolicy=b.ipolicy AND f.iofficer=c.iofficer AND d.ibranch=f.iquota"
                       "    AND a.ipolicy IN (SELECT ipolicy_c FROM car353_email_log WHERE ipolicy_c!='' AND ipolicy_r!='')  AND  f.ileader=e.iofficer"
                       "    AND h.ipolicy_r=f.ipolicy  AND f.ipolicy=g.ipolicy"
                       "    AND a.ipolicy=h.ipolicy_c",list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname);
                 
       
        printf("stmt21[%s]\n",stmt21);
        $PREPARE prep21 FROM $stmt21;
        $DECLARE curs21 CURSOR FOR prep21;
        $OPEN curs21 ;
        for(;;)
        {
            
            $FETCH curs21 INTO  $ipolicy_c,  $ipolicy_r, $iassured,        $nassured, $iemail,      $itag,        $iengine,        $ibrand,
                                $dbegin_c,   $dend_c,    $dbegin_r,        $dend_r,   $icar_type_c, $icar_type_r, $iofficer,       $nofficer,       $iroute,
                                $iquota,     $nbranch,   $ileader,         $nleader,  $iapplicant,  $napplicant,  $nrelation_appl, $nrelation_other,
                                $aemail_appl,$nreceiver, $aemail_receiver, $dcreate,  $inumber;

            if( SQLCODE == SQLNOTFOUND) break;
            
            
            
             
            fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,"
                       "%s,%s,%s,%s,%s,%s,%s,%s,%s,"
                       "%s,%s,%s,%s,%s,%s,%s,%s,"
                       "%s,%s,%s,%s,%s\n",
                       ipolicy_c,  ipolicy_r, iassured,        nassured, iemail,      itag,        iengine,        ibrand,
                       dbegin_c,   dend_c,    dbegin_r,        dend_r,   icar_type_c, icar_type_r, iofficer,       nofficer,       iroute,
                       iquota,     nbranch,   ileader,         nleader,  iapplicant,  napplicant,  nrelation_appl, nrelation_other,
                       aemail_appl,nreceiver, aemail_receiver, dcreate,  inumber);
         
            
            
        }
        $FREE prep21;
        $CLOSE curs21;       
       

    }  

    
    
    fclose(fp);
    
    
    sprintf_s(content1,sizeof content1,"�˷R���P���A�z�n</P>"
                    "�Ц�cmn202�U��%s�~%s��%s��ұH�o���O�᪺�u�s�w�F�ʮ��W�����O�I-���I�O��ֹ�q���v�H��</P>"
                    "�H�e�M��A�ӫH���CAR353�۰ʱH�e�A�w��O�I�~�ȭ��q��(�O�o�q��10)�B�Q�O�I�H����</P>"
                    "�M�H�B�n�O�H�d��Email��Ƥ��O��H�e�ӫO���Ӥ��O��A��C�~1�B4�B7�B10��25��H�o</P>"
                    "�e�T�Ӥ�ñ���ơC</P>"
                    "����!</P>",yy_fn, mm_fn, dd_fn);
    strcpy(nsubject,"�s�w�F�ʮ��W�����O�I-���I�O��ֹ�q��-�H�e����");


    /*�H�o���ӫO�����f*/
    strcpy(mbuf,content1);
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mbuf;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mbuf) + 1;
        
    strcpy(receiver_email,"");
    strcpy(receiver_name,"");
  
    mail_count=0;
        
    strcpy(stmt22,"SELECT chinese_name,trim(email)||'@tmnewa.com.tw' "
                  "  FROM personal:asempl "
                  " WHERE empl_no IN ('000732','881236') ");
                  
    $PREPARE prep22 FROM $stmt22;
    $DECLARE curs22 CURSOR FOR prep22;
    $OPEN curs22 ;
    for(;;)
    {
            
        mail_count++;
            
        $FETCH curs22 INTO  $receiver_name,  $receiver_email;

        if( SQLCODE == SQLNOTFOUND) break;
            
            
        $INSERT INTO batchemail
	    (project_id, mail_date, receiver_email, receiver_name, cc,
	     content, key, mail_count, nsubject)
         VALUES
	    ('CAR353', today, $receiver_email, $receiver_name, ' ',
	    $ctxt, '', $mail_count, $nsubject);            
             

         
            
            
    }
    $FREE prep22;
    $CLOSE curs22; 
        
    strcat(fname,".csv");
               
    rc=rptftpinsert("000732","car353", fname );
    printf("rptftpinsert rc[%d]\n", rc);
    if (rc!=0)
    {
        sprintf_s( sMsg,sizeof sMsg,"�g�Jrptftplist���~\r\n");
        return rc;
    }  
    
    rc=rptftpinsert("881236","car353", fname );
    printf("rptftpinsert rc[%d]\n", rc);
    if (rc!=0)
    {
        sprintf_s( sMsg,sizeof sMsg,"�g�Jrptftplist���~\r\n");
        return rc;
    }   

    /*rc=rptftpinsert("071004","car353", fname );
    printf("rptftpinsert rc[%d]\n", rc);
    if (rc!=0)
    {
        sprintf( sMsg,"�g�Jrptftplist���~\r\n");
        return rc;
    }   */

    /*rc=rptftpinsert("121219","car353", fname );
    printf("rptftpinsert rc[%d]\n", rc);
    if (rc!=0)
    {
        sprintf( sMsg,"�g�Jrptftplist���~\r\n");
        return rc;
    }*/
    
  return M_CM_OK;

errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car353_send_email_empl_IC()
{
	 $whenever sqlerror goto errexit;
     $int  rc;
     char  sMsg[100];
     $char receiver_name[121], receiver_email[51];
     $char stmtIC16[1024],content1[1000];
     $char nsubject[512];
     
     $char ipolicy_c[21],ipolicy_r[21],iassured[13],nassured[121],iemail[51],itag[CA_TAG_NUM],iengine[26],ibrand[9];
     $char dbegin_c[11],dend_c[11],dbegin_r[11],dend_r[11],icar_type_c[3],icar_type_r[3],iofficer[11],nofficer[11],iroute[21];
     $char iquota[7],nbranch[41],ileader[11],nleader[11],iapplicant[21],napplicant[121],nrelation_appl[41],nrelation_other[2];
     $char aemail_appl[51],nreceiver[121],aemail_receiver[51],tmobile_receiver[21],dcreate[11],inumber[13];
     $char stmtIC14[1024],stmtIC15[1024];
     
    /* ���Y */
    strcpy(ftitle,
           "�j���I�O�渹,���N�I�O�渹,�Q�O�I�HID,�Q�O�I�H�W��,�Q�O�I�HEmail,�P�Ӹ��X,�������X,�t�P�����N��,"
           "�j��_��,�j����,���N�_��,���N���,�j���,���N����,�g��N��,�g��W��,�q���N��,"
           "�~�Z���N��,�~�Z���W��,�޲z�H�N��,�޲z�H�W��,�n�O�HID,�n�O�H�W��,�n�O�H�P�Q�O�I�H���Y,��L���Y����,"
           "�n�O�Hemail,����H,�H�eEmail,�H�e���,�H�o���,�Ǹ�\n");
    fprintf(fp,ftitle);
    
    
    for(i=0;i<count_db;i++) 
    {    
        /*���*/
        sprintf_s(stmtIC14,sizeof stmtIC14," SELECT '' ,f.ipolicy_r,a.iassured,a.nassured,a.iemail,a.itag,a.iengine,b.ibrand, "
                      "        '','',b.dply_begin,b.dply_end,'',b.icar_type,b.iofficer,c.nname,a.iroute,"
                      "        b.iquota,d.nbranch,b.ileader,e.nname,a.iapplicant,a.napplicant,a.nrelation_appl,'', "
                      "        a.aemail_appl,f.nreceiver,f.aemail_receiver,f.tmobile_receiver,today,f.inumber "
                      "   FROM %s:policy a,%s:ply_relation b,officer c,sa_branch_type d,officer e,car353_email_log f "
                      "  WHERE a.ipolicy=b.ipolicy AND b.iofficer=c.iofficer AND d.ibranch=b.iquota "
                      "    AND a.ipolicy IN (SELECT ipolicy_r FROM car353_email_log WHERE ipolicy_c='') AND b.ileader=e.iofficer "
                      "    AND a.ipolicy=f.ipolicy_r ",list[i].dbname,list[i].dbname);
                 
        printf("stmtIC14[%s]\n",stmtIC14);
        $PREPARE preIC14 FROM $stmtIC14;
        $DECLARE curIC14 CURSOR FOR preIC14;
        $OPEN curIC14;
        for(;;)
        {
            
            $FETCH curIC14 INTO  $ipolicy_c,  $ipolicy_r, $iassured,        $nassured,         $iemail,      $itag,        $iengine,        $ibrand,
                                $dbegin_c,   $dend_c,    $dbegin_r,        $dend_r,           $icar_type_c, $icar_type_r, $iofficer,       $nofficer,       $iroute,
                                $iquota,     $nbranch,   $ileader,         $nleader,          $iapplicant,  $napplicant,  $nrelation_appl, $nrelation_other,
                                $aemail_appl,$nreceiver, $aemail_receiver, $tmobile_receiver, $dcreate,     $inumber;

            if( SQLCODE == SQLNOTFOUND) break;
            
            
            
             
            fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,"
                       "%s,%s,%s,%s,%s,%s,%s,%s,%s,"
                       "%s,%s,%s,%s,%s,%s,%s,%s,"
                       "%s,%s,%s,%s,%s,%s\n",
                       ipolicy_c,  ipolicy_r, iassured,        nassured,         iemail,      itag,        iengine,        ibrand,
                       dbegin_c,   dend_c,    dbegin_r,        dend_r,           icar_type_c, icar_type_r, iofficer,       nofficer,       iroute,
                       iquota,     nbranch,   ileader,         nleader,          iapplicant,  napplicant,  nrelation_appl, nrelation_other,
                       aemail_appl,nreceiver, aemail_receiver, tmobile_receiver, dcreate,     inumber);
         
            
            
        }
        $FREE preIC14;
        $CLOSE curIC14;  
        
        
        /*�j+��*/        
        sprintf_s(stmtIC15,sizeof stmtIC15," SELECT h.ipolicy_c ,h.ipolicy_r,g.iassured,g.nassured,g.iemail,g.itag,g.iengine,f.ibrand, "
                       "        b.dply_begin,b.dply_end,f.dply_begin,f.dply_end,b.icar_type,f.icar_type,f.iofficer,c.nname,g.iroute,"
                       "        f.iquota,d.nbranch,f.ileader,e.nname,g.iapplicant,g.napplicant,g.nrelation_appl,'',"
                       "        g.aemail_appl,h.nreceiver,h.aemail_receiver,h.tmobile_receiver,today,h.inumber"
                       "   FROM %s:policy a,%s:ply_relation b,officer c,sa_branch_type d,officer e,%s:ply_relation f,%s:policy g,car353_email_log h"
                       "  WHERE a.ipolicy=b.ipolicy AND f.iofficer=c.iofficer AND d.ibranch=f.iquota"
                       "    AND a.ipolicy IN (SELECT ipolicy_c FROM car353_email_log WHERE ipolicy_c!='' AND ipolicy_r!='')  AND  f.ileader=e.iofficer"
                       "    AND h.ipolicy_r=f.ipolicy  AND f.ipolicy=g.ipolicy"
                       "    AND a.ipolicy=h.ipolicy_c",list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname);
                 
       
        printf("stmtIC15[%s]\n",stmtIC15);
        $PREPARE preIC15 FROM $stmtIC15;
        $DECLARE curIC15 CURSOR FOR preIC15;
        $OPEN curIC15;
        for(;;)
        {
            
            $FETCH curIC15 INTO  $ipolicy_c,  $ipolicy_r, $iassured,        $nassured,         $iemail,      $itag,        $iengine,        $ibrand,
                                $dbegin_c,   $dend_c,    $dbegin_r,        $dend_r,           $icar_type_c, $icar_type_r, $iofficer,       $nofficer,       $iroute,
                                $iquota,     $nbranch,   $ileader,         $nleader,          $iapplicant,  $napplicant,  $nrelation_appl, $nrelation_other,
                                $aemail_appl,$nreceiver, $aemail_receiver, $tmobile_receiver, $dcreate,     $inumber;

            if( SQLCODE == SQLNOTFOUND) break;
            
            
            
             
            fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,"
                       "%s,%s,%s,%s,%s,%s,%s,%s,%s,"
                       "%s,%s,%s,%s,%s,%s,%s,%s,"
                       "%s,%s,%s,%s,%s,%s\n",
                       ipolicy_c,  ipolicy_r, iassured,        nassured,         iemail,      itag,        iengine,        ibrand,
                       dbegin_c,   dend_c,    dbegin_r,        dend_r,           icar_type_c, icar_type_r, iofficer,       nofficer,       iroute,
                       iquota,     nbranch,   ileader,         nleader,          iapplicant,  napplicant,  nrelation_appl, nrelation_other,
                       aemail_appl,nreceiver, aemail_receiver, tmobile_receiver, dcreate,     inumber);
         
            
            
        }
        $FREE preIC15;
        $CLOSE curIC15;

    }  

    
    
    fclose(fp);
    
    
    sprintf_s(content1,sizeof content1,"�˷R���P���A�z�n</P>"
                    "�Ц�cmn202�U��%s�~%s��%s��ұH�o���O�᪺�u�s�w�F�ʮ��W�����O�I-���I�O��ֹ�q���v�H��</P>"
                    "�H�e�M��A�ӫH���CAR353�۰ʱH�e�A�w��O�I�~�ȭ����q��(�ư�JB)�B�Q�O�I�H����</P>"
                    "�M�H�Ϊk�H�B�n�O�H�d��Email��ƩΤ�����X���O��H�e�ӫO���Ӥ��O��A��C��10��H�o</P>"
                    "�e�@�Ӥ�ñ���ơC</P>"
                    "����!</P>",yy_fn, mm_fn, dd_fn);
    strcpy(nsubject,"�s�w�F�ʮ��W�����O�I-���I�O��ֹ�q��-�H�e����");


    /*�H�o���ӫO�����f*/
    strcpy(mbuf,content1);
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mbuf;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mbuf) + 1;
        
    strcpy(receiver_email,"");
    strcpy(receiver_name,"");
  
    mail_count=0;
        
    strcpy(stmtIC16,"SELECT chinese_name,trim(email)||'@tmnewa.com.tw' "
                  "  FROM personal:asempl "
                  " WHERE empl_no IN ('000732','881236') ");
                  
    $PREPARE preIC16 FROM $stmtIC16;
    $DECLARE curIC16 CURSOR FOR preIC16;
    $OPEN curIC16;
    for(;;)
    {
            
        mail_count++;
            
        $FETCH curIC16 INTO  $receiver_name,  $receiver_email;

        if( SQLCODE == SQLNOTFOUND) break;
            
            
        $INSERT INTO batchemail
	    (project_id, mail_date, receiver_email, receiver_name, cc,
	     content, key, mail_count, nsubject)
         VALUES
	    ('CAR353', today, $receiver_email, $receiver_name, ' ',
	    $ctxt, '', $mail_count, $nsubject);            
             
    }
    $FREE preIC16;
    $CLOSE curIC16; 
        
    strcat(fname,".csv");
               
    rc=rptftpinsert("000732","car353", fname );
    printf("rptftpinsert rc[%d]\n", rc);
    if (rc!=0)
    {
        sprintf_s( sMsg,sizeof sMsg,"�g�Jrptftplist���~\r\n");
        return rc;
    }  
    
    rc=rptftpinsert("881236","car353", fname );
    printf("rptftpinsert rc[%d]\n", rc);
    if (rc!=0)
    {
        sprintf_s( sMsg,sizeof sMsg,"�g�Jrptftplist���~\r\n");
        return rc;
    }   

    /*rc=rptftpinsert("071004","car353", fname );
    printf("rptftpinsert rc[%d]\n", rc);
    if (rc!=0)
    {
        sprintf( sMsg,"�g�Jrptftplist���~\r\n");
        return rc;
    }   */

    /*rc=rptftpinsert("121219","car353", fname );
    printf("rptftpinsert rc[%d]\n", rc);
    if (rc!=0)
    {
        sprintf( sMsg,"�g�Jrptftplist���~\r\n");
        return rc;
    }*/
    
  return M_CM_OK;

errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}
/*******************************************************************************/
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
        char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
        char static sTmp_db_name[21];

        sTmp_db_name[0]='\0';
        if (*sIpolicy != '\0' && *sIpolicy !=' ')
        {
           sTmp_db_name[0]='\0';
           strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
           strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
                  USE_BRANCH_ID));
           strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
        }
  return sTmp_db_name;
}
/********************************************************************************/
char *get_car_short_db(sIpolicy)
char *sIpolicy;
{
        char sTmpScomp[BRANCH_ID];
        char static sTmpcomp[BRANCH_ID];
        char sTmp_db_name[21];

        sTmp_db_name[0]='\0';
        if (*sIpolicy != '\0' && *sIpolicy !=' ')
        {
           sTmp_db_name[0]='\0';
           strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
           strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
                  USE_BRANCH_ID));
           
        }
  return sTmpcomp;
}
/*********************************************************************************/
/*-------------------------------THE END--------------------------------------*/
