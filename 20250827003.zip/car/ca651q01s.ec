/**********************************************************************/
/*   program id   : ca651q01s.ec                                      */
/*   program name : �ҰϹq�ܤΤ�����X��J�v����                      */
/*   date written : 2017/03/27 by 041090                              */
/*   files        :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"

$char dbgn[11],dbgn2[11];
$char dend[11],dend2[11];
$char fcard_class_in[2];
$char iquota[7];

int   count_db,k; 
char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];

DBinfo *list;

main(argc, argv)
int argc;
char **argv;
{
 int rc;

	batchinit();
	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(dbgn,           isNULLstr(argv[3]));
	strcpy(dend,           isNULLstr(argv[4]));
	strcpy(fcard_class_in, isNULLstr(argv[5]));
	strcpy(iquota,         isNULLstr(argv[6]));
	strcpy(outputf,        isNULLstr(argv[7]));
	
	rc = car651_get_db();
	if (rc != M_CM_OK)
		return rc;

	rc = car651_prepare_data();
	if (rc != M_CM_OK)
		return rc;

	rc = car651_build();
	if (rc != M_CM_OK) 
		return rc;
}

long car651_get_db()
{
	$whenever sqlerror goto errexit;

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car651_prepare_data()
{
 $char igroup[11],ngroup[21],fcard_class[2],imgr[2],iroute[21],iclass[2];
 $int qorder = 0,cnt = 0;
 $char stmt[2048],stmt1[4096],stmt11[4096],stmp[128],stmp2[128],stmp3[128],stmpx[128],tbl[20];
 $char stmt2[2048],stmp_iquota[128],stmp_fcard_class[128];
 $char stmt_tmp1[1024],stmt_tmp2[1024],stmt_tmp3[1024],stmt_tmp4[1024];
 $char stmt_tmp11[1024],stmt_tmp22[1024],stmt_tmp33[1024],stmt_tmp44[1024];
 $char sFullName[21];
 $char sys[20];
 $int sum_cntcA = 0,sum_allcA = 0,sum_cntcB = 0,sum_allcB = 0,sum_cntcC = 0,sum_allcC = 0,
      sum_cntcD = 0,sum_allcD = 0,sum_cntcE = 0,sum_allcE = 0,sum_cntcF = 0,sum_allcF = 0;
 $int sum_cntvA = 0,sum_allvA = 0,sum_cntvB = 0,sum_allvB = 0,sum_cntvC = 0,sum_allvC = 0,
      sum_cntvD = 0,sum_allvD = 0,sum_cntvE = 0,sum_allvE = 0,sum_cntvF = 0,sum_allvF = 0;
 $int sum_cA = 0, sum_cB = 0, sum_cC = 0, sum_cD = 0, sum_cE = 0, sum_cF = 0,
      sum_vA = 0, sum_vB = 0, sum_vC = 0, sum_vD = 0, sum_vE = 0, sum_vF = 0;
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == FALSE)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return FAIL;
	}
	
	strcpy(dbgn2,cm_to_infdate(dbgn));
	strcpy(dend2,cm_to_infdate(dend));
	strcpy(fcard_class_in,trim(fcard_class_in));
	strcpy(iquota,trim(iquota));
	
	if(strncmp(fcard_class_in,"1",1) == 0)
	sprintf(stmp_fcard_class,"AND b.fcard_class = '%s' ",fcard_class_in);
	else if(strncmp(fcard_class_in,"2",1) == 0)
	sprintf(stmp_fcard_class,"AND b.fcard_class = '%s' ",fcard_class_in);
	else
	strcpy(stmp_fcard_class," "); 
	
	if(strlen(iquota) == 0 || strncmp(iquota,"*",1) == 0)
	strcpy(stmp_iquota," ");
	else
	sprintf(stmp_iquota,"AND b.iquota matches '%s' ",iquota);

	$create temp table ply_tmp1
	(
	ipolicy         char(20),
	fcard_class     char(1),
	itel            char(20),
	itel_night      char(20),
	mobil_phone     char(20),
	iroute          char(20),
	igroup          char(5),
	imgr            char(1)
	) with no log;
	
	$create temp table car651_tmp1
	(
	qorder       	int,
	igroup          char(10),
	ngroup          char(20),
	ipolicy         char(20),
	fcard_class     char(1),
	itel            char(20),
	itel_night      char(20),
	mobil_phone     char(20),
	iroute          char(20),
	imgr            char(1)
	) with no log;
	
	$create temp table tmp_sum_policy
	(
	qorder       	int,
	fcard_class     char(1),
	iclass          char(1),
	cnt_ipolicy     int
	) with no log;
	
	$create temp table tmp_sum_itel
	(
	qorder       	int,
	fcard_class     char(1),
	iclass          char(1),
	cnt_itel        int
	) with no log;
	
	$create temp table tmp_sum_itel_night
	(
	qorder       	int,
	fcard_class     char(1),
	iclass          char(1),
	cnt_itel_night  int
	) with no log;
	
	$create temp table tmp_sum_mobil_phone
	(
	qorder       	int,
	fcard_class     char(1),
	iclass          char(1),
	cnt_mobil_phone int
	) with no log;
	
	$create temp table car651_final
	(
	qorder       	    int,
	ngroup              char(20),
	cntv_ipolicyA        int,
	cntv_itelA           int,
	cntv_itel_nightA     int,
	cntv_mobil_phoneA    int,
	cntv_ipolicyB        int,
	cntv_itelB           int,
	cntv_itel_nightB     int,
	cntv_mobil_phoneB    int,
	cntv_ipolicyC        int,
	cntv_itelC           int,
	cntv_itel_nightC     int,
	cntv_mobil_phoneC    int,
	cntv_ipolicyD        int,
	cntv_itelD           int,
	cntv_itel_nightD     int,
	cntv_mobil_phoneD    int,
	cntv_ipolicyE        int,
	cntv_itelE           int,
	cntv_itel_nightE     int,
	cntv_mobil_phoneE    int,
	cntv_ipolicyF        int,
	cntv_itelF           int,
	cntv_itel_nightF     int,
	cntv_mobil_phoneF    int,
	cntc_ipolicyA        int,
	cntc_itelA           int,
	cntc_itel_nightA     int,
	cntc_mobil_phoneA    int,
	cntc_ipolicyB        int,
	cntc_itelB           int,
	cntc_itel_nightB     int,
	cntc_mobil_phoneB    int,
	cntc_ipolicyC        int,
	cntc_itelC           int,
	cntc_itel_nightC     int,
	cntc_mobil_phoneC    int,
	cntc_ipolicyD        int,
	cntc_itelD           int,
	cntc_itel_nightD     int,
	cntc_mobil_phoneD    int,
	cntc_ipolicyE        int,
	cntc_itelE           int,
	cntc_itel_nightE     int,
	cntc_mobil_phoneE    int,
	cntc_ipolicyF        int,
	cntc_itelF           int,
	cntc_itel_nightF     int,
	cntc_mobil_phoneF    int
	) with no log;
		
	for(k=0;k<count_db;k++)
	{ 
		sprintf(stmt1,"INSERT INTO ply_tmp1 \
				SELECT a.ipolicy,b.fcard_class,a.itel,a.itel_night,a.mobil_phone,a.iroute,c.igroup,d.imgr \
  				  FROM %s:policy a,%s:ply_relation b,sa_branch_type c,officer d \
 				 WHERE a.ipolicy = b.ipolicy \
  				   AND b.iquota = c.ibranch \
  				   AND a.iroute NOT matches 'PA*' \
  				   AND b.iofficer = d.iofficer \
  				   AND a.fassured not in ('2','4','6') \
  				   AND d.fprop != 'E' %s %s \
   				   AND b.dpolicy between '%s' AND '%s'",list[k].dbname,list[k].dbname,stmp_fcard_class,stmp_iquota,dbgn2,dend2);
		printf("--stmt1[%s]\n", stmt1);
		$PREPARE ply_tmp FROM $stmt1;
		$EXECUTE ply_tmp;
	}
	
	sprintf(stmt11,"INSERT INTO car651_tmp1 \
			 SELECT a.qorder,a.igroup,a.ngroup,b.ipolicy,b.fcard_class,b.itel,b.itel_night,b.mobil_phone,b.iroute,b.imgr \
			   FROM sa_frm_module a,OUTER ply_tmp1 b \
			  WHERE a.igroup = b.igroup \
			    AND a.ifrm_module = '16' \
			  ORDER BY 1;");
	$PREPARE ca651_tp FROM $stmt11;
	$EXECUTE ca651_tp;		  
	
	for(int j = 1 ; j < 5 ; j++)
	{
		if(j == 1) 
		{
			strcpy(stmp,"ipolicy");
			strcpy(stmp2,"tmp_sum_policy");
			strcpy(stmp3,"cnt_ipolicy");
		}
		else if(j == 2)
		{
			strcpy(stmp,"itel");
			strcpy(stmp2,"tmp_sum_itel");
			strcpy(stmp3,"cnt_itel");
		}
		else if(j == 3)
		{
			strcpy(stmp,"itel_night");
			strcpy(stmp2,"tmp_sum_itel_night");
			strcpy(stmp3,"cnt_itel_night");
		}
		else
		{
			strcpy(stmp,"mobil_phone");
			strcpy(stmp2,"tmp_sum_mobil_phone");
			strcpy(stmp3,"cnt_mobil_phone");
		}
		
		strcpy(stmp,trim(stmp));
		strcpy(stmp2,trim(stmp2));
		strcpy(stmp3,trim(stmp3));
				
		sprintf(stmt2,"SELECT a.qorder,a.igroup,a.ngroup,a.fcard_class,a.imgr,a.iroute, \
		                      nvl((SELECT count(%s) FROM car651_tmp1 WHERE qorder = a.qorder \
		                                                               AND fcard_class = a.fcard_class \
		                                                               AND igroup = a.igroup \
		                                                               AND imgr = a.imgr \
		                                    			       AND iroute = a.iroute \
		                                                               AND %s[1] <> ' ' ),0) \
			  	 FROM car651_tmp1 a  \
			  	 %s \
			        GROUP BY 1,2,3,4,5,6 \
			        ORDER BY 1 ",stmp,stmp,stmpx);

		printf("stmt2[%s]\n", stmt2);	    
		$PREPARE tmp1 FROM $stmt2;
		$DECLARE cur_tmp1 CURSOR for tmp1;
		$OPEN cur_tmp1;
		for(;;)
		{
			$FETCH cur_tmp1 INTO $qorder,$igroup,$ngroup,$fcard_class,$imgr,$iroute,$cnt;
			if(SQLCODE == SQLNOTFOUND) break;
			printf("\n qorder[%d],igroup[%s],ngroup[%s],fcard_class[%s],cnt[%d] \n",qorder,igroup,ngroup,fcard_class,cnt);
			
			strcpy(iclass," ");
			if(strncmp(imgr,"1",1) == 0) /*�j�v*/
				strcpy(iclass,"A");
			else
			{
				if(strncmp(iroute,"BA",2) == 0) /*�O�g*/
					strcpy(iclass,"B");
				else if(strncmp(iroute,"I",1) == 0) /*�Ȧ�*/
					strcpy(iclass,"C");
				else if(strncmp(iroute,"KA",2) == 0) /*���u*/
					strcpy(iclass,"D");
				else if(strncmp(iroute,"KB",2) == 0) /*����~�ȭ�*/
					strcpy(iclass,"F");
				else /*��L*/
					strcpy(iclass,"E");
			}
			
			sprintf(stmt_tmp1,"insert into %s(qorder,fcard_class,iclass,%s) values(%d,'%s','%s',%d)",stmp2,stmp3,qorder,fcard_class,iclass,cnt);
			$PREPARE cur_t1 FROM $stmt_tmp1;
			sprintf(stmt_tmp2,"insert into %s(qorder,fcard_class,iclass,%s) values(%d,'1',?,?)",stmp2,stmp3,qorder);
			sprintf(stmt_tmp22,"insert into %s(qorder,fcard_class,iclass,%s) values(%d,'2',?,?)",stmp2,stmp3,qorder);
			$PREPARE cur_t2c FROM $stmt_tmp2;
			$PREPARE cur_t2v FROM $stmt_tmp22;
			sprintf(stmt_tmp3,"insert into %s(qorder,fcard_class,iclass,%s) values(%d,'1',?,?)",stmp2,stmp3,qorder);
			sprintf(stmt_tmp33,"insert into %s(qorder,fcard_class,iclass,%s) values(%d,'2',?,?)",stmp2,stmp3,qorder);
			$PREPARE cur_t3c FROM $stmt_tmp3;
			$PREPARE cur_t3v FROM $stmt_tmp33;
			/*1061017001 �s�W���p�p*/
			sprintf(stmt_tmp4,"insert into %s(qorder,fcard_class,iclass,%s) values(%d,'1',?,?)",stmp2,stmp3,qorder);
			sprintf(stmt_tmp44,"insert into %s(qorder,fcard_class,iclass,%s) values(%d,'2',?,?)",stmp2,stmp3,qorder);
			$PREPARE cur_t4c FROM $stmt_tmp4;
			$PREPARE cur_t4v FROM $stmt_tmp44;
						
			if (strncmp(fcard_class,"1",1)==0)  /*�j��*/
			{
					printf("stmt_tmp1[%s] cnt[%d]\n", stmt_tmp1,cnt);	
					$EXECUTE cur_t1;
					if(strcmp(iclass,"A") ==0 ) 
						sum_cA = sum_cA + cnt;
					else if(strcmp(iclass,"B") ==0 ) 
						sum_cB = sum_cB + cnt;
					else if(strcmp(iclass,"C") ==0 ) 
						sum_cC = sum_cC + cnt;
					else if(strcmp(iclass,"D") ==0 ) 
						sum_cD = sum_cD + cnt;
					else if(strcmp(iclass,"F") ==0 ) 
						sum_cF = sum_cF + cnt;
					else
						sum_cE = sum_cE + cnt;
					cnt = 0;

			}
			if (strncmp(fcard_class,"2",1)==0)  /*���N*/
			{
					printf("stmt_tmp1[%s] cnt[%d]\n", stmt_tmp1,cnt);
					$EXECUTE cur_t1;
					if(strcmp(iclass,"A") ==0 ) 
						sum_vA = sum_vA + cnt;
					else if(strcmp(iclass,"B") ==0 ) 
						sum_vB = sum_vB + cnt;
					else if(strcmp(iclass,"C") ==0 ) 
						sum_vC = sum_vC + cnt;
					else if(strcmp(iclass,"D") ==0 ) 
						sum_vD = sum_vD + cnt;
					else if(strcmp(iclass,"F") ==0 ) 
						sum_vF = sum_vF + cnt;
					else
						sum_vE = sum_vE + cnt;
					cnt = 0;
			}
			/*1061017001 �s�W���p�p*/
			if(strncmp(igroup,"XXX",3)==0)  /*XXX�����p�p*/
			{
					printf("stmt_tmp4[%s] \n", stmt_tmp4);
					printf("stmt_tmp44[%s]\n", stmt_tmp44);

					$EXECUTE cur_t4c using "A",$sum_cA;
					$EXECUTE cur_t4v using "A",$sum_vA;

					$EXECUTE cur_t4c using "B",$sum_cB;
					$EXECUTE cur_t4v using "B",$sum_vB;

					$EXECUTE cur_t4c using "C",$sum_cC;
					$EXECUTE cur_t4v using "C",$sum_vC;

					$EXECUTE cur_t4c using "D",$sum_cD;
					$EXECUTE cur_t4v using "D",$sum_vD;

					$EXECUTE cur_t4c using "E",$sum_cE;
					$EXECUTE cur_t4v using "E",$sum_vE;
					
					$EXECUTE cur_t4c using "F",$sum_cF;
					$EXECUTE cur_t4v using "F",$sum_vF;
						
					sum_cntcA = sum_cntcA + sum_cA;
					sum_cntcB = sum_cntcB + sum_cB;
					sum_cntcC = sum_cntcC + sum_cC;
					sum_cntcD = sum_cntcD + sum_cD;
					sum_cntcE = sum_cntcE + sum_cE;
					sum_cntcF = sum_cntcF + sum_cF;
		
					
					sum_cntvA = sum_cntvA + sum_vA;
					sum_cntvB = sum_cntvB + sum_vB;
					sum_cntvC = sum_cntvC + sum_vC;
					sum_cntvD = sum_cntvD + sum_vD;
					sum_cntvE = sum_cntvE + sum_vE;
					sum_cntvF = sum_cntvF + sum_vF;
					
					sum_cA = sum_vA = 0;
					sum_cB = sum_vB = 0;
					sum_cC = sum_vC = 0;
					sum_cD = sum_vD = 0;
					sum_cE = sum_vE = 0;
					sum_cF = sum_vF = 0;
			}
			
			if(strncmp(igroup,"YYY",3)==0)  /*YYY���Ұϥ[�`*/
			{
					printf("stmt_tmp2[%s] \n", stmt_tmp2);
					printf("stmt_tmp22[%s]\n", stmt_tmp22);

					$EXECUTE cur_t2c using "A",$sum_cntcA;
					$EXECUTE cur_t2v using "A",$sum_cntvA;

					$EXECUTE cur_t2c using "B",$sum_cntcB;
					$EXECUTE cur_t2v using "B",$sum_cntvB;

					$EXECUTE cur_t2c using "C",$sum_cntcC;
					$EXECUTE cur_t2v using "C",$sum_cntvC;

					$EXECUTE cur_t2c using "D",$sum_cntcD;
					$EXECUTE cur_t2v using "D",$sum_cntvD;

					$EXECUTE cur_t2c using "E",$sum_cntcE;
					$EXECUTE cur_t2v using "E",$sum_cntvE;
					
					$EXECUTE cur_t2c using "F",$sum_cntcF;
					$EXECUTE cur_t2v using "F",$sum_cntvF;
						
					sum_allcA = sum_allcA + sum_cntcA;
					sum_allcB = sum_allcB + sum_cntcB;
					sum_allcC = sum_allcC + sum_cntcC;
					sum_allcD = sum_allcD + sum_cntcD;
					sum_allcE = sum_allcE + sum_cntcE;
					sum_allcF = sum_allcF + sum_cntcF;
		
					sum_allvA = sum_allvA + sum_cntvA;
					sum_allvB = sum_allvB + sum_cntvB;
					sum_allvC = sum_allvC + sum_cntvC;
					sum_allvD = sum_allvD + sum_cntvD;
					sum_allvE = sum_allvE + sum_cntvE;
					sum_allvF = sum_allvF + sum_cntvF;
					
					sum_cntcA = sum_cntvA = 0;
					sum_cntcB = sum_cntvB = 0;
					sum_cntcC = sum_cntvC = 0;
					sum_cntcD = sum_cntvD = 0;
					sum_cntcE = sum_cntvE = 0;
					sum_cntcF = sum_cntvF = 0;
			}
			
			if(strncmp(igroup,"ZZZ",3)==0)  /*ZZZ�������Ұϥ[�`*/
			{
					printf("stmt_tmp3[%s] \n", stmt_tmp3);
					printf("stmt_tmp33[%s]\n", stmt_tmp33);
					
					$EXECUTE cur_t3c using "A",$sum_allcA;
					$EXECUTE cur_t3v using "A",$sum_allvA;

					$EXECUTE cur_t3c using "B",$sum_allcB;
					$EXECUTE cur_t3v using "B",$sum_allvB;

					$EXECUTE cur_t3c using "C",$sum_allcC;
					$EXECUTE cur_t3v using "C",$sum_allvC;

					$EXECUTE cur_t3c using "D",$sum_allcD;
					$EXECUTE cur_t3v using "D",$sum_allvD;

					$EXECUTE cur_t3c using "E",$sum_allcE;
					$EXECUTE cur_t3v using "E",$sum_allvE;
					
					$EXECUTE cur_t3c using "F",$sum_allcF;
					$EXECUTE cur_t3v using "F",$sum_allvF;
				
					sum_allcA = sum_allvA = 0;
					sum_allcB = sum_allvB = 0;
					sum_allcC = sum_allvC = 0;
					sum_allcD = sum_allvD = 0;
					sum_allcE = sum_allvE = 0;
					sum_allcF = sum_allvF = 0;
			}
							
		}
		$CLOSE cur_tmp1;
		$FREE cur_tmp1;	
		strcpy(stmp," ");
		strcpy(stmp2," ");
		strcpy(stmp3," ");
	}
	sprintf(stmt,"insert into car651_final  \
	             select a.qorder,  \
	             	    case when a.igroup = 'YYY' then (nvl(trim(a.ngroup),'')||'�X�p') else a.ngroup end, \
	                    nvl((select sum(cnt_ipolicy)      from tmp_sum_policy       where qorder = a.qorder and fcard_class = '2' and iclass = 'A'),0),  \
	                    nvl((select sum(cnt_itel)         from tmp_sum_itel         where qorder = a.qorder and fcard_class = '2' and iclass = 'A'),0),  \
	                    nvl((select sum(cnt_itel_night)   from tmp_sum_itel_night   where qorder = a.qorder and fcard_class = '2' and iclass = 'A'),0),  \
	                    nvl((select sum(cnt_mobil_phone)  from tmp_sum_mobil_phone  where qorder = a.qorder and fcard_class = '2' and iclass = 'A'),0),  \
	                    nvl((select sum(cnt_ipolicy)      from tmp_sum_policy       where qorder = a.qorder and fcard_class = '2' and iclass = 'B'),0),  \
	                    nvl((select sum(cnt_itel)         from tmp_sum_itel         where qorder = a.qorder and fcard_class = '2' and iclass = 'B'),0),  \
	                    nvl((select sum(cnt_itel_night)   from tmp_sum_itel_night   where qorder = a.qorder and fcard_class = '2' and iclass = 'B'),0),  \
	                    nvl((select sum(cnt_mobil_phone)  from tmp_sum_mobil_phone  where qorder = a.qorder and fcard_class = '2' and iclass = 'B'),0),  \
	                    nvl((select sum(cnt_ipolicy)      from tmp_sum_policy       where qorder = a.qorder and fcard_class = '2' and iclass = 'C'),0),  \
	                    nvl((select sum(cnt_itel)         from tmp_sum_itel         where qorder = a.qorder and fcard_class = '2' and iclass = 'C'),0),  \
	                    nvl((select sum(cnt_itel_night)   from tmp_sum_itel_night   where qorder = a.qorder and fcard_class = '2' and iclass = 'C'),0),  \
	                    nvl((select sum(cnt_mobil_phone)  from tmp_sum_mobil_phone  where qorder = a.qorder and fcard_class = '2' and iclass = 'C'),0),  \
	                    nvl((select sum(cnt_ipolicy)      from tmp_sum_policy       where qorder = a.qorder and fcard_class = '2' and iclass = 'D'),0),  \
	                    nvl((select sum(cnt_itel)         from tmp_sum_itel         where qorder = a.qorder and fcard_class = '2' and iclass = 'D'),0),  \
	                    nvl((select sum(cnt_itel_night)   from tmp_sum_itel_night   where qorder = a.qorder and fcard_class = '2' and iclass = 'D'),0),  \
	                    nvl((select sum(cnt_mobil_phone)  from tmp_sum_mobil_phone  where qorder = a.qorder and fcard_class = '2' and iclass = 'D'),0),  \
	                    nvl((select sum(cnt_ipolicy)      from tmp_sum_policy       where qorder = a.qorder and fcard_class = '2' and iclass = 'E'),0),  \
	                    nvl((select sum(cnt_itel)         from tmp_sum_itel         where qorder = a.qorder and fcard_class = '2' and iclass = 'E'),0),  \
	                    nvl((select sum(cnt_itel_night)   from tmp_sum_itel_night   where qorder = a.qorder and fcard_class = '2' and iclass = 'E'),0),  \
	                    nvl((select sum(cnt_mobil_phone)  from tmp_sum_mobil_phone  where qorder = a.qorder and fcard_class = '2' and iclass = 'E'),0),  \
	                    nvl((select sum(cnt_ipolicy)      from tmp_sum_policy       where qorder = a.qorder and fcard_class = '2' and iclass = 'F'),0),  \
	                    nvl((select sum(cnt_itel)         from tmp_sum_itel         where qorder = a.qorder and fcard_class = '2' and iclass = 'F'),0),  \
	                    nvl((select sum(cnt_itel_night)   from tmp_sum_itel_night   where qorder = a.qorder and fcard_class = '2' and iclass = 'F'),0),  \
	                    nvl((select sum(cnt_mobil_phone)  from tmp_sum_mobil_phone  where qorder = a.qorder and fcard_class = '2' and iclass = 'F'),0),  \
	                    nvl((select sum(cnt_ipolicy)      from tmp_sum_policy       where qorder = a.qorder and fcard_class = '1' and iclass = 'A'),0),  \
	                    nvl((select sum(cnt_itel)         from tmp_sum_itel         where qorder = a.qorder and fcard_class = '1' and iclass = 'A'),0),  \
	                    nvl((select sum(cnt_itel_night)   from tmp_sum_itel_night   where qorder = a.qorder and fcard_class = '1' and iclass = 'A'),0),  \
	                    nvl((select sum(cnt_mobil_phone)  from tmp_sum_mobil_phone  where qorder = a.qorder and fcard_class = '1' and iclass = 'A'),0),  \
	                    nvl((select sum(cnt_ipolicy)      from tmp_sum_policy       where qorder = a.qorder and fcard_class = '1' and iclass = 'B'),0),  \
	                    nvl((select sum(cnt_itel)         from tmp_sum_itel         where qorder = a.qorder and fcard_class = '1' and iclass = 'B'),0),  \
	                    nvl((select sum(cnt_itel_night)   from tmp_sum_itel_night   where qorder = a.qorder and fcard_class = '1' and iclass = 'B'),0),  \
	                    nvl((select sum(cnt_mobil_phone)  from tmp_sum_mobil_phone  where qorder = a.qorder and fcard_class = '1' and iclass = 'B'),0),  \
	                    nvl((select sum(cnt_ipolicy)      from tmp_sum_policy       where qorder = a.qorder and fcard_class = '1' and iclass = 'C'),0),  \
	                    nvl((select sum(cnt_itel)         from tmp_sum_itel         where qorder = a.qorder and fcard_class = '1' and iclass = 'C'),0),  \
	                    nvl((select sum(cnt_itel_night)   from tmp_sum_itel_night   where qorder = a.qorder and fcard_class = '1' and iclass = 'C'),0),  \
	                    nvl((select sum(cnt_mobil_phone)  from tmp_sum_mobil_phone  where qorder = a.qorder and fcard_class = '1' and iclass = 'C'),0),  \
	                    nvl((select sum(cnt_ipolicy)      from tmp_sum_policy       where qorder = a.qorder and fcard_class = '1' and iclass = 'D'),0),  \
	                    nvl((select sum(cnt_itel)         from tmp_sum_itel         where qorder = a.qorder and fcard_class = '1' and iclass = 'D'),0),  \
	                    nvl((select sum(cnt_itel_night)   from tmp_sum_itel_night   where qorder = a.qorder and fcard_class = '1' and iclass = 'D'),0),  \
	                    nvl((select sum(cnt_mobil_phone)  from tmp_sum_mobil_phone  where qorder = a.qorder and fcard_class = '1' and iclass = 'D'),0),  \
	                    nvl((select sum(cnt_ipolicy)      from tmp_sum_policy       where qorder = a.qorder and fcard_class = '1' and iclass = 'E'),0),  \
	                    nvl((select sum(cnt_itel)         from tmp_sum_itel         where qorder = a.qorder and fcard_class = '1' and iclass = 'E'),0),  \
	                    nvl((select sum(cnt_itel_night)   from tmp_sum_itel_night   where qorder = a.qorder and fcard_class = '1' and iclass = 'E'),0),  \
	                    nvl((select sum(cnt_mobil_phone)  from tmp_sum_mobil_phone  where qorder = a.qorder and fcard_class = '1' and iclass = 'E'),0),  \
	                    nvl((select sum(cnt_ipolicy)      from tmp_sum_policy       where qorder = a.qorder and fcard_class = '1' and iclass = 'F'),0),  \
	                    nvl((select sum(cnt_itel)         from tmp_sum_itel         where qorder = a.qorder and fcard_class = '1' and iclass = 'F'),0),  \
	                    nvl((select sum(cnt_itel_night)   from tmp_sum_itel_night   where qorder = a.qorder and fcard_class = '1' and iclass = 'F'),0),  \
	                    nvl((select sum(cnt_mobil_phone)  from tmp_sum_mobil_phone  where qorder = a.qorder and fcard_class = '1' and iclass = 'F'),0)   \
	               from sa_frm_module a  \
	              where a.ifrm_module = '16' \
	              order by 1 ");
	printf("stmt[%s]\n", stmt);
	$PREPARE ca651_fn FROM $stmt;
	$EXECUTE ca651_fn;
		
	return M_CM_OK;
	
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/


long car651_build()
{
 int rc;
 char sfilename[256],stitle[2048],stmt[6000];

	$WHENEVER SQLERROR GOTO errexit;

	strcpy(sfilename,"�ҰϹq�ܤΤ�����X��J�v����[car651]");
	sprintf(stitle,"�C�L�϶�:%s~%s\t",dbgn,dend);
	strcat(stitle,"\n");
	strcpy(fcard_class_in,trim(fcard_class_in));
	if(strncmp(fcard_class_in,"1",1) == 0)
	{
		strcat(stitle,"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t�j���I\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
		strcat(stitle,"\t����\t\t\t\t���ӫO�N\t\t\t\t\t\t\t����O�g�N\t\t\t\t\t\t\t�Ȧ�O�g�N\t\t\t\t\t\t\t���u����\t\t\t\t\t\t\t����~�ȭ�\t\t\t\t\t\t\t��L(�D�ݥ��C��)\t\t\t\n");
		strcat(stitle,"\t���O\t�j��ñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"�j��ñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"�j��ñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"�j��ñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"�j��ñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"�j��ñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcpy(stmt,"select ngroup, \
				    cntc_ipolicyA, \
				    cntc_itelA,  \
				    case when cntc_itelA = 0 then 0 else (ROUND((cntc_itelA/cntc_ipolicyA),4)*100) end , \
				    cntc_itel_nightA,  \
				    case when cntc_itel_nightA = 0 then 0 else (ROUND((cntc_itel_nightA/cntc_ipolicyA),4)*100) end , \
				    cntc_mobil_phoneA,  \
				    case when cntc_mobil_phoneA = 0 then 0 else (ROUND((cntc_mobil_phoneA/cntc_ipolicyA),4)*100) end , \
				    cntc_ipolicyB, \
				    cntc_itelB,  \
				    case when cntc_itelB = 0 then 0 else (ROUND((cntc_itelB/cntc_ipolicyB),4)*100) end , \
				    cntc_itel_nightB,  \
				    case when cntc_itel_nightB = 0 then 0 else (ROUND((cntc_itel_nightB/cntc_ipolicyB),4)*100) end , \
				    cntc_mobil_phoneB,  \
				    case when cntc_mobil_phoneB = 0 then 0 else (ROUND((cntc_mobil_phoneB/cntc_ipolicyB),4)*100) end , \
				    cntc_ipolicyC, \
				    cntc_itelC,  \
				    case when cntc_itelC = 0 then 0 else (ROUND((cntc_itelC/cntc_ipolicyC),4)*100) end , \
				    cntc_itel_nightC,  \
				    case when cntc_itel_nightC = 0 then 0 else (ROUND((cntc_itel_nightC/cntc_ipolicyC),4)*100) end , \
				    cntc_mobil_phoneC,  \
				    case when cntc_mobil_phoneC = 0 then 0 else (ROUND((cntc_mobil_phoneC/cntc_ipolicyC),4)*100) end , \
				    cntc_ipolicyD, \
				    cntc_itelD,  \
				    case when cntc_itelD = 0 then 0 else (ROUND((cntc_itelD/cntc_ipolicyD),4)*100) end , \
				    cntc_itel_nightD,  \
				    case when cntc_itel_nightD = 0 then 0 else (ROUND((cntc_itel_nightD/cntc_ipolicyD),4)*100) end , \
				    cntc_mobil_phoneD,  \
				    case when cntc_mobil_phoneD = 0 then 0 else (ROUND((cntc_mobil_phoneD/cntc_ipolicyD),4)*100) end , \
				    cntc_ipolicyF, \
				    cntc_itelF,  \
				    case when cntc_itelF = 0 then 0 else (ROUND((cntc_itelF/cntc_ipolicyF),4)*100) end , \
				    cntc_itel_nightF,  \
				    case when cntc_itel_nightF = 0 then 0 else (ROUND((cntc_itel_nightF/cntc_ipolicyF),4)*100) end , \
				    cntc_mobil_phoneF,  \
				    case when cntc_mobil_phoneF = 0 then 0 else (ROUND((cntc_mobil_phoneF/cntc_ipolicyF),4)*100) end,  \
				    cntc_ipolicyE, \
				    cntc_itelE,  \
				    case when cntc_itelE = 0 then 0 else (ROUND((cntc_itelE/cntc_ipolicyE),4)*100) end , \
				    cntc_itel_nightE,  \
				    case when cntc_itel_nightE = 0 then 0 else (ROUND((cntc_itel_nightE/cntc_ipolicyE),4)*100) end , \
				    cntc_mobil_phoneE,  \
				    case when cntc_mobil_phoneE = 0 then 0 else (ROUND((cntc_mobil_phoneE/cntc_ipolicyE),4)*100) end  \
		               from car651_final  \
		              where (cntc_ipolicyA <> 0 or cntc_ipolicyB <> 0 or cntc_ipolicyC <> 0 or cntc_ipolicyD <> 0 or cntc_ipolicyE <> 0 or cntc_ipolicyF <> 0)\
		                and qorder not in ('1010','1060','2010','3010','3510','1009','1059','2009','3009','3509', '6179') \
		               order by qorder");
	}
	else if(strncmp(fcard_class_in,"2",1) == 0)
	{
		strcat(stitle,"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t���N�I\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\n");
		strcat(stitle,"\t����\t\t\t\t���ӫO�N\t\t\t\t\t\t\t����O�g�N\t\t\t\t\t\t\t�Ȧ�O�g�N\t\t\t\t\t\t\t���u����\t\t\t\t\t\t\t����~�ȭ�\t\t\t\t\t\t\t��L(�D�ݥ��C��)\t\t\t\n");
		strcat(stitle,"\t���O\t���Nñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"���Nñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"���Nñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"���Nñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"���Nñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"���Nñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcpy(stmt,"select ngroup, \
				    cntv_ipolicyA, \
				    cntv_itelA,  \
				    case when cntv_itelA = 0 then 0 else (ROUND((cntv_itelA/cntv_ipolicyA),4)*100) end ,	\
				    cntv_itel_nightA,  \
				    case when cntv_itel_nightA = 0 then 0 else (ROUND((cntv_itel_nightA/cntv_ipolicyA),4)*100) end , \
				    cntv_mobil_phoneA,  \
				    case when cntv_mobil_phoneA = 0 then 0 else (ROUND((cntv_mobil_phoneA/cntv_ipolicyA),4)*100) end , \
				    cntv_ipolicyB, \
				    cntv_itelB,  \
				    case when cntv_itelB = 0 then 0 else (ROUND((cntv_itelB/cntv_ipolicyB),4)*100) end ,	\
				    cntv_itel_nightB,  \
				    case when cntv_itel_nightB = 0 then 0 else (ROUND((cntv_itel_nightB/cntv_ipolicyB),4)*100) end , \
				    cntv_mobil_phoneB,  \
				    case when cntv_mobil_phoneB = 0 then 0 else (ROUND((cntv_mobil_phoneB/cntv_ipolicyB),4)*100) end , \
				    cntv_ipolicyC, \
				    cntv_itelC,  \
				    case when cntv_itelC = 0 then 0 else (ROUND((cntv_itelC/cntv_ipolicyC),4)*100) end ,	\
				    cntv_itel_nightC,  \
				    case when cntv_itel_nightC = 0 then 0 else (ROUND((cntv_itel_nightC/cntv_ipolicyC),4)*100) end , \
				    cntv_mobil_phoneC,  \
				    case when cntv_mobil_phoneC = 0 then 0 else (ROUND((cntv_mobil_phoneC/cntv_ipolicyC),4)*100) end , \
				    cntv_ipolicyD, \
				    cntv_itelD,  \
				    case when cntv_itelD = 0 then 0 else (ROUND((cntv_itelD/cntv_ipolicyD),4)*100) end ,	\
				    cntv_itel_nightD,  \
				    case when cntv_itel_nightD = 0 then 0 else (ROUND((cntv_itel_nightD/cntv_ipolicyD),4)*100) end , \
				    cntv_mobil_phoneD,  \
				    case when cntv_mobil_phoneD = 0 then 0 else (ROUND((cntv_mobil_phoneD/cntv_ipolicyD),4)*100) end , \
				    cntv_ipolicyF, \
				    cntv_itelF,  \
				    case when cntv_itelF = 0 then 0 else (ROUND((cntv_itelF/cntv_ipolicyF),4)*100) end ,	\
				    cntv_itel_nightF,  \
				    case when cntv_itel_nightF = 0 then 0 else (ROUND((cntv_itel_nightF/cntv_ipolicyF),4)*100) end , \
				    cntv_mobil_phoneF,  \
				    case when cntv_mobil_phoneF = 0 then 0 else (ROUND((cntv_mobil_phoneF/cntv_ipolicyF),4)*100) end,  \
				    cntv_ipolicyE, \
				    cntv_itelE,  \
				    case when cntv_itelE = 0 then 0 else (ROUND((cntv_itelE/cntv_ipolicyE),4)*100) end ,	\
				    cntv_itel_nightE,  \
				    case when cntv_itel_nightE = 0 then 0 else (ROUND((cntv_itel_nightE/cntv_ipolicyE),4)*100) end , \
				    cntv_mobil_phoneE,  \
				    case when cntv_mobil_phoneE = 0 then 0 else (ROUND((cntv_mobil_phoneE/cntv_ipolicyE),4)*100) end  \
		               from car651_final  \
		              where (cntv_ipolicyA <> 0 or cntv_ipolicyB <> 0 or cntv_ipolicyC <> 0 or cntv_ipolicyD <> 0 or cntv_ipolicyE <> 0 or cntv_ipolicyF <> 0)\
		                and qorder not in ('1010','1060','2010','3010','3510','1009','1059','2009','3009','3509', '6179') \
		               order by qorder");
	}
	else
	{
		strcat(stitle,"\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t���N�I\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t\t�j���I\n");
		strcat(stitle,"\t����\t\t\t\t���ӫO�N\t\t\t\t\t\t\t����O�g�N\t\t\t\t\t\t\t�Ȧ�O�g�N\t\t\t\t\t\t\t���u����\t\t\t\t\t\t\t����~�ȭ�\t\t\t\t\t\t\t��L(�D�ݥ��C��)\t\t\t");
		strcat(stitle,"\t\t\t\t���Ӥj�v\t\t\t\t\t\t\t����O�g�N\t\t\t\t\t\t\t�Ȧ�O�g�N\t\t\t\t\t\t\t���u����\t\t\t\t\t\t\t����~�ȭ�\t\t\t\t\t\t\t��L(�D�ݥ��C��)\t\t\t\n");
		strcat(stitle,"\t���O\t���Nñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"���Nñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"���Nñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"���Nñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"���Nñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"���Nñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"�j��ñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"�j��ñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"�j��ñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"�j��ñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"�j��ñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcat(stitle,"�j��ñ����\t�q��(��)���\t�q��(��)����%\t�q��(�])���\t�q��(�])����%\t��ʹq�ܥ��\t��ʹq�ܦ���%\t");
		strcpy(stmt,"select ngroup, \
				    cntv_ipolicyA, \
				    cntv_itelA,  \
				    case when cntv_itelA = 0 then 0 else (ROUND((cntv_itelA/cntv_ipolicyA),4)*100) end ,	\
				    cntv_itel_nightA,  \
				    case when cntv_itel_nightA = 0 then 0 else (ROUND((cntv_itel_nightA/cntv_ipolicyA),4)*100) end , \
				    cntv_mobil_phoneA,  \
				    case when cntv_mobil_phoneA = 0 then 0 else (ROUND((cntv_mobil_phoneA/cntv_ipolicyA),4)*100) end , \
				    cntv_ipolicyB, \
				    cntv_itelB,  \
				    case when cntv_itelB = 0 then 0 else (ROUND((cntv_itelB/cntv_ipolicyB),4)*100) end ,	\
				    cntv_itel_nightB,  \
				    case when cntv_itel_nightB = 0 then 0 else (ROUND((cntv_itel_nightB/cntv_ipolicyB),4)*100) end , \
				    cntv_mobil_phoneB,  \
				    case when cntv_mobil_phoneB = 0 then 0 else (ROUND((cntv_mobil_phoneB/cntv_ipolicyB),4)*100) end , \
				    cntv_ipolicyC, \
				    cntv_itelC,  \
				    case when cntv_itelC = 0 then 0 else (ROUND((cntv_itelC/cntv_ipolicyC),4)*100) end ,	\
				    cntv_itel_nightC,  \
				    case when cntv_itel_nightC = 0 then 0 else (ROUND((cntv_itel_nightC/cntv_ipolicyC),4)*100) end , \
				    cntv_mobil_phoneC,  \
				    case when cntv_mobil_phoneC = 0 then 0 else (ROUND((cntv_mobil_phoneC/cntv_ipolicyC),4)*100) end , \
				    cntv_ipolicyD, \
				    cntv_itelD,  \
				    case when cntv_itelD = 0 then 0 else (ROUND((cntv_itelD/cntv_ipolicyD),4)*100) end ,	\
				    cntv_itel_nightD,  \
				    case when cntv_itel_nightD = 0 then 0 else (ROUND((cntv_itel_nightD/cntv_ipolicyD),4)*100) end , \
				    cntv_mobil_phoneD,  \
				    case when cntv_mobil_phoneD = 0 then 0 else (ROUND((cntv_mobil_phoneD/cntv_ipolicyD),4)*100) end , \
				    cntv_ipolicyF, \
				    cntv_itelF,  \
				    case when cntv_itelF = 0 then 0 else (ROUND((cntv_itelF/cntv_ipolicyF),4)*100) end ,	\
				    cntv_itel_nightF,  \
				    case when cntv_itel_nightF = 0 then 0 else (ROUND((cntv_itel_nightF/cntv_ipolicyF),4)*100) end , \
				    cntv_mobil_phoneF,  \
				    case when cntv_mobil_phoneF = 0 then 0 else (ROUND((cntv_mobil_phoneF/cntv_ipolicyF),4)*100) end , \
				    cntv_ipolicyE, \
				    cntv_itelE,  \
				    case when cntv_itelE = 0 then 0 else (ROUND((cntv_itelE/cntv_ipolicyE),4)*100) end ,	\
				    cntv_itel_nightE,  \
				    case when cntv_itel_nightE = 0 then 0 else (ROUND((cntv_itel_nightE/cntv_ipolicyE),4)*100) end , \
				    cntv_mobil_phoneE,  \
				    case when cntv_mobil_phoneE = 0 then 0 else (ROUND((cntv_mobil_phoneE/cntv_ipolicyE),4)*100) end , \
				    cntc_ipolicyA, \
				    cntc_itelA,  \
				    case when cntc_itelA = 0 then 0 else (ROUND((cntc_itelA/cntc_ipolicyA),4)*100) end , \
				    cntc_itel_nightA,  \
				    case when cntc_itel_nightA = 0 then 0 else (ROUND((cntc_itel_nightA/cntc_ipolicyA),4)*100) end , \
				    cntc_mobil_phoneA,  \
				    case when cntc_mobil_phoneA = 0 then 0 else (ROUND((cntc_mobil_phoneA/cntc_ipolicyA),4)*100) end , \
				    cntc_ipolicyB, \
				    cntc_itelB,  \
				    case when cntc_itelB = 0 then 0 else (ROUND((cntc_itelB/cntc_ipolicyB),4)*100) end , \
				    cntc_itel_nightB,  \
				    case when cntc_itel_nightB = 0 then 0 else (ROUND((cntc_itel_nightB/cntc_ipolicyB),4)*100) end , \
				    cntc_mobil_phoneB,  \
				    case when cntc_mobil_phoneB = 0 then 0 else (ROUND((cntc_mobil_phoneB/cntc_ipolicyB),4)*100) end , \
				    cntc_ipolicyC, \
				    cntc_itelC,  \
				    case when cntc_itelC = 0 then 0 else (ROUND((cntc_itelC/cntc_ipolicyC),4)*100) end , \
				    cntc_itel_nightC,  \
				    case when cntc_itel_nightC = 0 then 0 else (ROUND((cntc_itel_nightC/cntc_ipolicyC),4)*100) end , \
				    cntc_mobil_phoneC,  \
				    case when cntc_mobil_phoneC = 0 then 0 else (ROUND((cntc_mobil_phoneC/cntc_ipolicyC),4)*100) end , \
				    cntc_ipolicyD, \
				    cntc_itelD,  \
				    case when cntc_itelD = 0 then 0 else (ROUND((cntc_itelD/cntc_ipolicyD),4)*100) end , \
				    cntc_itel_nightD,  \
				    case when cntc_itel_nightD = 0 then 0 else (ROUND((cntc_itel_nightD/cntc_ipolicyD),4)*100) end , \
				    cntc_mobil_phoneD,  \
				    case when cntc_mobil_phoneD = 0 then 0 else (ROUND((cntc_mobil_phoneD/cntc_ipolicyD),4)*100) end , \
				    cntc_ipolicyF, \
				    cntc_itelF,  \
				    case when cntc_itelF = 0 then 0 else (ROUND((cntc_itelF/cntc_ipolicyF),4)*100) end , \
				    cntc_itel_nightF,  \
				    case when cntc_itel_nightF = 0 then 0 else (ROUND((cntc_itel_nightF/cntc_ipolicyF),4)*100) end , \
				    cntc_mobil_phoneF,  \
				    case when cntc_mobil_phoneF = 0 then 0 else (ROUND((cntc_mobil_phoneF/cntc_ipolicyF),4)*100) end,  \
				    cntc_ipolicyE, \
				    cntc_itelE,  \
				    case when cntc_itelE = 0 then 0 else (ROUND((cntc_itelE/cntc_ipolicyE),4)*100) end , \
				    cntc_itel_nightE,  \
				    case when cntc_itel_nightE = 0 then 0 else (ROUND((cntc_itel_nightE/cntc_ipolicyE),4)*100) end , \
				    cntc_mobil_phoneE,  \
				    case when cntc_mobil_phoneE = 0 then 0 else (ROUND((cntc_mobil_phoneE/cntc_ipolicyE),4)*100) end  \
		               from car651_final  \
		              where (cntv_ipolicyA <> 0 or cntc_ipolicyA <> 0 or cntv_ipolicyB <> 0 or cntc_ipolicyB <> 0 or cntv_ipolicyC <> 0 or cntc_ipolicyC <> 0 or cntv_ipolicyD <> 0 or cntc_ipolicyD <> 0 or cntv_ipolicyE <> 0 or cntc_ipolicyE <> 0 or cntv_ipolicyF <> 0 or cntc_ipolicyF <> 0) \
		                and qorder not in ('1010','1060','2010','3010','3510','1009','1059','2009','3009','3509', '6179') \
		               order by qorder");
	}
	               
	rc = unload_file(outputf," ",sfilename,stitle,stmt);
	
	if (rc != SUCCESS) 
	{
	    sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}
