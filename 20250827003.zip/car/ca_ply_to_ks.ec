/**********************************************************************/
/*                                                                    */
/*   program id   : ca_ply_to_ks.ec                                   */
/*   program name : �Ϳ��n�O�Ѹ������                                */
/*            �t�X�Ϳ��O�N�O�I�t�Ω�鵲�{���I�s,���ͤ�r�ɩ�T�w�ؿ� */
/*            �C���INSWEB�o��FTP�N�ɮ���J,�A�N�ɮײM��              */
/*            �W�[�ζ��P�ߪA�ȥd�����X--�u�w��j���I                */
/*   date written : 2003/05/30                                        */
/*   date modify  : 2004/02/25                                        */
/*   author       : Jessie                                            */
/*   files        : ori_ply_relation    i                             */
/*                  original_ply        i                             */
/*                  ori_ins_type        i                             */
/**********************************************************************/
#include <stdio.h>
#include <string.h>
#include <time.h>
$include sqlca;
#include "sql.h"
#include "sqlfatal.h"
#include "commsgs.h"
$include "var_length.h";
$include sqltypes;
#include "globdata.h"
#include "safeclib.h"

/*#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <decimal.h>

#include "is_def.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "glsstru.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "comdata.h"
#include "cm_ply_info.h"
#include "cm_plyins_info.h"
#include "ca_data.h"

$include sqlca;
$include datetime;
$include sqltypes;
$include "ply_ins_cover.h";
$include "ply_ins_assured.h";
$include "var_length.h";*/
/*--------------------------------------------------------------------*/
time_t   current_time;
$char   ply1[13],ply2[4];
$char    dbgn[11],dend[11];
$char    ipolicy[21],icard[21],iengine[CA_ENGINE_NUM],dpolicy[11],ibig_sales[11];
$char    ibig_office[10],nassured[31],itel[21],aassured[91];
$char    ibenef[11],dply_begin[11],dply_end[11],icar_flag[2];
$char    icar_type[3],iissue_ym[7],nuser[11],itag[CA_TAG_NUM],nbrand_abbr[13];
$char    ibrand[9],iins_type[7],fcard_class[2],nbenef[43],iass4[5];
$long    mprem=0,mdmg_cover=0,minj_cover=0,mdth_cover=0,mdeduct=0,mins_prem=0;
$char    dply_fmt[11],dbgn_fmt[11],dend_fmt[11],dissue[11];
$char    ioff1[2],nass_all[121],iofficer[11],ilast_ply[21];
 long    rtncode=0;

/*$char    itype_prem0[2],itype_prem1[2],itype_prem2[2];
$long    mnt[3][];*/
$char itype_prem[2];
char itype[10];

$long mnt=0,mnt_b=0;
char   tmp[200];str_mnt[1000],str_mntb[1000];

$char    dbgn_ymd[9],dend_ymd[9],dpolicy_ymd[9],dissue_ym[7];

char     DBName[5];
FILE     *fp,*fp1,*fp2;
char     sApHome[30],filename[50],filename1[50],pathname[31];
char     filename2[50],pathname2[31];
/*--------------------------------------------------------------------*/
ca_ply_to_ks(db,dproc1)
char *db,*dproc1;
{
int      rc=0;
printf("******************************************************************************************************");
   strcpy(DBName,db);
   strcpy(dpolicy,dproc1);
 /*strcpy(dbgn,dproc1);
   strcpy(dend,dproc2);*/
   current_time=time(NULL);

   trans_date(dpolicy,dply_fmt);
   printf("dpolicy[%s]\n",dply_fmt);

   rc = getApHome(sApHome);
   sprintf_s(pathname, sizeof pathname,"%s/rptftp/ks/",sApHome);
   sprintf_s(filename, sizeof filename,"%sply_%s_%ld.txt",pathname,db,current_time);
   sprintf_s(filename1, sizeof filename1,"%sins_%s_%ld.txt",pathname,db,current_time);
   printf("filename[%s][%s]\n",filename,filename1);

   if ((fp=fopen(filename,"w")) == NULL) {
      printf("fopen error[%s]\n",filename);
      return M_CM_FAILED;
   }

   if ((fp1=fopen(filename1,"w")) == NULL) {
      printf("fopen error[%s]\n",filename1);
      return M_CM_FAILED;
   }

   /* �ζ��P�ߪA�ȥd */
   sprintf_s(pathname2, sizeof pathname2,"%s/rptftp/yl/",sApHome);
   sprintf_s(filename2, sizeof filename2,"%sply_%s_%ld.txt",pathname2,db,current_time);

   if ((fp2=fopen(filename2,"w")) == NULL) {
      printf("fopen error[%s]\n",filename2);
      return M_CM_FAILED;
   }
   
   /*----------------*/

   rc = read_ply_data();
   if (rc != M_CM_OK)
      return rc;

   fclose(fp);
   fclose(fp1);
   fclose(fp2);

   return M_CM_OK;
}
/*--------------------------------------------------------------------*/
long read_ply_data()
{
int      dyy=0;
$char    fbenef[2];


   $whenever sqlerror goto errexit;

   if (db_select(DBName) == 0) {
        printf("M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
   }

   $declare cur_ply cursor for
    select a.ipolicy,a.icard,a.fcard_class,case when iengine = ' ' then ibody else iengine end,ibig_sales, 
            ibig_office,nassured[1,30],itel,aassured,ibenef,dply_begin, 
            dply_end,icar_flag,icar_type,
            to_char(dissue,'%Y')||to_char(dissue,'%m'),
            nuser[1,10],nvl(itag,' '), 
            nbrand_abbr,ibrand,mdmg_prem+mlia_prem,nbenef,iofficer[1],
            nassured,nvl(ilast_ply,' '),iofficer,dpolicy,iassured[7,10],
            to_char(dissue,'%Y')||'/'||to_char(dissue,'%m')||'/'||to_char(dissue,'%d')
       into $ipolicy,$icard,$fcard_class,$iengine,$ibig_sales,
            $ibig_office,$nassured,$itel,$aassured,$ibenef,$dply_begin,
            $dply_end,$icar_flag,$icar_type,$dissue_ym,$nuser,$itag,
            $nbrand_abbr,$ibrand,$mprem,$nbenef,$ioff1,$nass_all,
            $ilast_ply,$iofficer,$dpolicy,$iass4, $dissue
       from ori_ply_relation a,original_ply b 
      where dpolicy = $dpolicy
        and a.ipolicy = b.ipolicy;
         
   $open cur_ply;

   while(1) {
   	
   	
        $fetch cur_ply;
        
        if (SQLCODE == SQLNOTFOUND) break;
        

      if (ioff1[0]!='A') continue;

      if (strncmp(fcard_class,"1",1)==0) {
         /*�ζ��P�ߪA�ȥd*/
         trans_date1(dply_begin,dbgn_ymd);
         trans_date1(dply_end,dend_ymd);
         trans_date1(dpolicy,dpolicy_ymd);
         fprintf(fp2,"%s%s%s%s%s%s%s%s%s%s%s%s1%s%s\n",
                 ipolicy,icard,nass_all,iengine,itag,ilast_ply,
                 dbgn_ymd,dend_ymd,dissue_ym,icar_type,iofficer,
                 dpolicy_ymd,ibrand,iass4);
         /* note : ��l�O��Ҭ����īO�� */
      }
      strcpy(ipolicy,trim(ipolicy));
      strcpy(icard,trim(icard));
      strcpy(iengine,trim(iengine));
      strcpy(ibig_sales,trim(ibig_sales));
      strcpy(ibig_office,trim(ibig_office));
      strcpy(nassured,trim(nassured));
      strcpy(itel,trim(itel));
      strcpy(aassured,trim(aassured));
      strcpy(nuser,trim(nuser));
      strcpy(itag,trim(itag));
      strcpy(nbrand_abbr,trim(nbrand_abbr));

      dbgn_fmt[0]='\0';
      dend_fmt[0]='\0';
      trans_date(dply_begin,dbgn_fmt);
      trans_date(dply_end,dend_fmt);
      printf("ipolicy[%s]dbgn_fmt[%s]dend_fmt[%s]dissue[%s]\n",ipolicy,dbgn_fmt,dend_fmt,dissue);
      if (strncmp(ibenef,"1231247",7)==0)
         strcpy(fbenef,"T");
      else if (strlen(trim(nbenef))==0)
              strcpy(fbenef,"N");
      else strcpy(fbenef,"O");
            	
    strcpy(tmp,"");
   /* strcpy(ipolicy_13,substring(ipolicy,1,13));
    strcpy(ipolicy_4,substring(ipolicy,14,4));
    strcpy(ipolicy_4,trim(ipolicy_4));*/
     rtncode = split_policy(ipolicy, ply1, ply2);
    printf("ply1[%s]ply2[%s]\n",ply1,ply2);
    
      
 /*  $declare cur_mnt cursor for
    select  b.itype_prem,sum(b.mnt) 
       into $itype_prem,$mnt
       from cm_pre_receive a,ao_prercv_detail b
       where a.ipolicy1=$ply1
       and a.ipolicy2=$ply2
        and a.ipre_rcv=b.ipre_rcv
        and a.iins_kind =b.iins_kind  
        and a.ipre_end = b.ipre_end group by itype_prem;*/
    
    $declare cur_mnt cursor for
    select  b.itype_prem,sum(b.mnt) 
       into $itype_prem,$mnt
       from cm_pre_receive a,ao_prercv_detail b
       where a.ipolicy1=$ply1
       and a.ipolicy2=$ply2
        and a.ipre_rcv=b.ipre_rcv
        and a.iins_kind =b.iins_kind  
        and a.ipre_end = b.ipre_end 
        group by itype_prem
        order by sum(b.mnt) DESC ;
        
        
        
   
                     
      $open    cur_mnt;
      
      
for(int i=0;i<4;i++)
{ 
	mnt=0;
	/*strcpy(itype,"");*/
	
        $fetch cur_mnt;
        printf("***itype_prem[%s] mnt[%d]\n",itype_prem,mnt);
       
        strcpy(str_mnt,ltoa(mnt));
        printf("itype[%s]str_mnt[%s]\n",itype,str_mnt);
        if(SQLCODE == SQLNOTFOUND)
	{
	   strcpy(itype_prem,"");
	    strcpy(itype,"");
	   strcpy(str_mnt,"");
	   
	  
	}/*ú�ڤ覡*/
	
        else if (strcmp(itype_prem,"A")==0)
        {
            strcpy(itype,"�l��");
        }
        else if (strcmp(itype_prem,"B")==0)
        {
            strcpy(itype,"�q�s");
        }
        else if (strcmp(itype_prem,"C")==0)
        {
            strcpy(itype,"ATM");
        }
        else if (strcmp(itype_prem,"D")==0)
        {
            strcpy(itype,"�K�Q�ө�");
        }
        else if (strcmp(itype_prem,"E")==0)
        {
            strcpy(itype,"�Ȧ�O�N");
        }
        else if (strcmp(itype_prem,"1")==0)
        {
            strcpy(itype,"�{��");
        }
        else if (strcmp(itype_prem,"2")==0)
        {
            strcpy(itype,"�Ȧs");
        }
        else if (strcmp(itype_prem,"3")==0)
        {
            strcpy(itype,"����");
         
        }
        else if (strcmp(itype_prem,"4")==0)
        {
            strcpy(itype,"��ú");
        }
        else if (strcmp(itype_prem,"6")==0)
        {
            strcpy(itype,"�Ȧ���");
        }
        else if (strcmp(itype_prem,"7")==0)
        {
            strcpy(itype,"�H�Υd");
        }
        else if (strcmp(itype_prem,"8")==0)
        {
            strcpy(itype,"�׶O");
        }
        else if (strcmp(itype_prem,"9")==0)
        {
            strcpy(itype,"����");
        }
        if(i==2)
        {  
           mnt_b=0;
           strcat(tmp,itype);
	   strcat(tmp,",");
           mnt_b=mnt;
           printf("mnt_b[%d]\n",mnt_b); 
        }
        else if(i==3)
        {
        	
           mnt=mnt+mnt_b;
           strcpy(str_mnt,ltoa(mnt));
           if(mnt==0) strcpy(str_mnt,"");
           strcat(tmp,str_mnt);
	   strcat(tmp,",");
           
        	}
        else{
        strcat(tmp,itype);
	strcat(tmp,",");
	strcat(tmp,str_mnt);
	strcat(tmp,",");
       }
                	
                               
		
		
}


printf("tmp[%s]\n",tmp);
                  /*  if (SQLCODE==SQLNOTFOUND) break;*/
                  /* $fetch cur_mnt into $itype_prem0,$mnt0,$itype_prem1,$mnt1,$itype_prem2,$mnt2;*/
      	
     
      if (strncmp(fcard_class,"2",1)==0) {
         fprintf(fp,"%s,,17,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,,,,,%d,,,,,,,,,%s\n", 
                 ipolicy,icard,iengine,dply_fmt,ibig_sales,ibig_office,
                 nassured,itel,aassured,fbenef,dbgn_fmt,dend_fmt,
                 icar_flag,icar_type,dissue,nuser,itag,nbrand_abbr,
                ibrand,mprem,tmp);
               /* ibrand,mprem,itype_prem0,mnt0,itype_prem1,mnt1,itype_prem2,mnt2);*/
                          
         
      }
      else {
         fprintf(fp,"%s,,17,,%s,%s,%s,%s,%s,%s,%s,%s,,,%s,%s,%s,%s,%s,%s,%s,,,,,,,,,%s,17,%s,%s,%d,%s\n", 
                 ipolicy,iengine,dply_fmt,ibig_sales,ibig_office,
                 nassured,itel,aassured,fbenef,
                 icar_flag,icar_type,dissue,nuser,itag,nbrand_abbr,
                ibrand,icard,dbgn_fmt,dend_fmt,mprem,tmp);
            /*  ibrand,icard,dbgn_fmt,dend_fmt,mprem,itype_prem0,mnt0,itype_prem1,mnt1,itype_prem2,mnt2);*/
                    }
             
        $close cur_mnt;
      $free  cur_mnt; 

      $declare cur_ins cursor for
        select (select iins_type_ks from insurance_type where iins_type = a.iins_type),
               sum(mdamage_cover),sum(minjured_cover),sum(mdeath_cover),
               max(mdeduct),sum(mins_premium)
          into $iins_type,$mdmg_cover,$minj_cover,$mdth_cover,
               $mdeduct,$mprem
          from ori_ins_type a
         where ipolicy = $ipolicy group by 1;
      $open    cur_ins;
      while(1) {
         $fetch cur_ins;
         if (SQLCODE==SQLNOTFOUND) break;
         strcpy(iins_type,trim(iins_type));

         fprintf(fp1,",%s,%s,%s,%d,%d,%d,%d,%d,\n",
                 ipolicy,icard,iins_type,minj_cover,mdth_cover,
                 mdmg_cover,mdeduct,mprem);
      }
      $close cur_ins;
      $free  cur_ins;
   }
   $close cur_ply;
   $free  cur_ply;

   return M_CM_OK;

errexit:
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
trans_date(dfrom,dtrans)
char *dfrom,*dtrans;
{
   sprintf_s(dtrans, 11,"%s/",substring(dfrom,7,4));
   strncat(dtrans,dfrom,5);
}
/*--------------------------------------------------------------------*/
trans_date1(dfrom,dtrans)
char *dfrom,*dtrans;
{
   strcpy(dtrans,substring(dfrom,7,4));
   strcat(dtrans,substring(dfrom,1,2));
   strcat(dtrans,substring(dfrom,4,2));
}
/*--------------------------------------------------------------------*/
 