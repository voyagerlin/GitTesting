/************************************************/
/*                                              */
/*   PROGRAM : car12601s.ec by Pei-Chow Chen    */
/*   MODIFIER: Johnny Kuo 04/22/1997            */
/*   PURPOSE : server side standard program     */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
$include sqlca;
#include "safeclib.h"

long car126(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    long rtncode;
    long car126_insert(),car126_single_query(),car126_multiple_query(),
         car126_update_exec();
    char option;

    cm_buf_init(command);
    cm_buf_get("%c",&option);
    switch(option)
    {
        case 'A':
                 rtncode=car126_insert(reply);
                 break;
        case 'Q':
                 rtncode=car126_single_query(reply);
                 break;
        case 'M':
                 rtncode=car126_multiple_query(reply);
                 break;
        case 'D':
        case 'U':
                 rtncode=car126_update_exec(reply,command,com_len);
                 break;
        default :
              return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
    }
    return(rtncode);
}

/* �s�W�Ҧ� */
long car126_insert(reply)
serverReply reply;
{
    $char   DBName[5], icar_type[5],ideduct[9],mdeduct[18], prn_deduct[18];
    $long   lMcoverage1, lMcoverage2, lMcoverage3;
    int     tmp_len;
    DBinfo  *list;
    int     i, j, is_add_fail=0, api_f;
    $char   stmt_buf[1024];
    long    MsgCode;

    cm_buf_get("%s %s %s %s %s",DBName,icar_type, ideduct, mdeduct, prn_deduct);
    cm_buf_get("%l %l %l ",&lMcoverage1, &lMcoverage2, &lMcoverage3);

    if (strcmp(trim(icar_type),"I29")!=0)
    {
        lMcoverage1 = 0;
        lMcoverage2 = 0;
        lMcoverage3 = 0;
    }

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
        return exitsub(reply,M_CM_NOT_DBLIST) ? M_CM_NOT_DBLIST : apiRC;

    $BEGIN WORK;
    for(j=0;j<i;j++)
    {
         sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:ca_dmg_mdeduct "
                           " (icar_type, ideduct, mdeduct, prn_deduct, mcoverage1, mcoverage2, mcoverage3) "
                           " VALUES (?,?,?,?,?,?,?)",list[j].dbname);

         $PREPARE a_id FROM $stmt_buf;
         if(SQLCODE != 0)
         {
              is_add_fail = 1;
              break;
         }
         $EXECUTE a_id USING $icar_type, $ideduct, $mdeduct, $prn_deduct, $lMcoverage1, $lMcoverage2, $lMcoverage3;
         if(SQLCODE != 0)
         {
              is_add_fail = 1;
              break;
         }
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
         tmp_len = cm_buf_len(ReplyBuf);
         if( j == i-1 )
              api_f = api_OKComplete;
         else
              api_f = api_OK;

         if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
         {
              is_add_fail = 2;
              break;
         }
    } /* for loop */

    if( is_add_fail == 1 ) goto errexit;

    if( is_add_fail == 2 )
    {
         $ROLLBACK WORK;
         return apiRC;
    }

    $WHENEVER SQLERROR GOTO errexit;

    $COMMIT WORK;
    return api_OKComplete;

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if (SQLCODE != 0) MsgCode = SQLCODE;         /* rollback fail */
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

long car126_single_query(reply)
serverReply reply;
{
     $char  DBName[5], icar_type[5], ideduct[9], mdeduct[19], prn_deduct[19];
     $long  lMcoverage1 = 0, lMcoverage2 = 0, lMcoverage3 = 0;

     int    tmp_len;

     cm_buf_get("%s %s %s",DBName, icar_type, ideduct);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
     {
         if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
              return M_CM_DB_NOTOPEN;
         else
              return apiRC;
     }

     $SELECT mdeduct,  prn_deduct,  mcoverage1,   mcoverage2,   mcoverage3
        INTO $mdeduct, $prn_deduct, $lMcoverage1, $lMcoverage2, $lMcoverage3
        FROM ca_dmg_mdeduct
       WHERE icar_type  = $icar_type
         AND ideduct    = $ideduct;

     if(SQLCODE==SQLNOTFOUND)
     {
         if(exitsub(reply,M_CM_NOT_FOUND) == True)
              return M_CM_NOT_FOUND;
         else
              return apiRC;
     }

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l %s %s %s %s",M_CM_OK,icar_type, ideduct, mdeduct, prn_deduct);
     cm_buf_put("%l %l %l", lMcoverage1, lMcoverage2, lMcoverage3);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     if(exitsub(reply,SQLCODE) == True)
          return SQLCODE;
     else
          return apiRC;
}

long car126_multiple_query(reply)
serverReply reply;
{
     $char DBName[5], icar_type[5], ideduct[9], mdeduct[19], prn_deduct[19];
     $char key_icar_type[5],key_ideduct[9];
     char  tmpbuf[4000];
     int   count=0,repbuf_len=0,tmp_len=0,replycnt=0;
     int   i,total_count=0;

     cm_buf_get("%s %s %s",DBName,key_icar_type, key_ideduct);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
     {
         if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
              return M_CM_DB_NOTOPEN;
         else
              return apiRC;
     }

     $DECLARE q_cur CURSOR FOR
       SELECT icar_type,  ideduct,  mdeduct,  prn_deduct
         INTO $icar_type, $ideduct, $mdeduct, $prn_deduct
         FROM ca_dmg_mdeduct
        WHERE icar_type matches $key_icar_type
          AND ideduct   matches $key_ideduct
        ORDER BY icar_type;

     $OPEN q_cur;

     for(;;)
     {
          $FETCH q_cur;
          if (SQLCODE != 0) break;

          cm_buf_init(tmpbuf);
          if ( count == 0 )
          {
               cm_buf_res_msg();             /* reserve for MsgCode and count */
               cm_buf_res_count();
          }
          cm_buf_put("%s %s %s %s", icar_type, ideduct, mdeduct, prn_deduct);
          tmp_len = cm_buf_len(tmpbuf);
          if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
          {
               memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
               repbuf_len += tmp_len;
               count++;
          }
          else                               /* more than 4K, send to client side */
          {
               cm_buf_init(ReplyBuf);
               cm_buf_put_msg(M_CM_OK);
               cm_buf_put_count(count);
               if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
               {
                    $CLOSE q_cur;
                    return apiRC;
               }
               else               /* clear ReplyBuf and count to start all over again */
               {
                    replycnt++;
                    if (replycnt == 10)   /* more than 30K, client cannot display,error */
                    {
                          cm_buf_init(ReplyBuf);
                          cm_buf_put("%l",M_CM_OUT_SPACE);
                          tmp_len = cm_buf_len(ReplyBuf);
                          if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                               return apiRC;
                          return M_CM_OUT_SPACE;
                    }
                    ReplyBuf[0] = '\0';
                    count = 0;
                    cm_buf_init(ReplyBuf);
                    cm_buf_res_msg();           /* reserve for MsgCode and count */
                    cm_buf_res_count();
                    cm_buf_put("%s %s %s %s", icar_type, ideduct, mdeduct, prn_deduct);
                    repbuf_len = cm_buf_len(ReplyBuf);
                    count++;
               }
          }
     } /* for loop */

     $CLOSE q_cur;
     if (count > 0)   /* break out, at least one record is selected */
     {
          cm_buf_init(ReplyBuf);
          cm_buf_put_msg(M_CM_OK);
          cm_buf_put_count(count);
          if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
               return apiRC;
          return api_OKComplete;
     }
     else            /* break out, not any row is found */
     {
          if(exitsub(reply,M_CM_NOT_FOUND) == True)
               return M_CM_NOT_FOUND;
          else
               return apiRC;
     }

errexit:
   if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
   else
     return apiRC;
}

long car126_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
     $char  DBName[5], icar_type[5], ideduct[9], mdeduct[19], prn_deduct[19];
     $long  lMcoverage1 = 0, lMcoverage2 = 0, lMcoverage3 = 0;

     $char  cur_ncode[11];
     $char  old_icar_type[5], old_ideduct[9];

     char   option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
     int    tmp_len,raw_len;
     long   dummy;
     long   MsgCode;
     DBinfo *list;
     int    i, j, is_del_fail=0, is_upd_fail=0;
     $char  stmt_buf[1024];

     comm = (char *) command;
     cm_buf_init(command);
     cm_buf_get("%c %s",&option,DBName);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
     {
         if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
         else
             return apiRC;
     }

     if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
     {
         if(exitsub(reply,M_CM_NOT_DBLIST) == True)
             return M_CM_NOT_DBLIST;
         return apiRC;
     }
     /* compare old record and current record, if the record has not been changed
        since last request, update or delete the record, otherwise return errmsg
        to client side */

     /* get old record info from command buffer */

     /*
     raw_len = *(int *) &comm[com_len];
     memcpy(&raw_len,(void *)&command[com_len],sizeof(int));
     */

     memcpy(&raw_len,&comm[com_len],sizeof(int));
     pos = &comm[com_len+sizeof(int)];
     raw_ptr = malloc(raw_len);
     if (raw_ptr != (char*)0)
         memcpy(raw_ptr,pos,raw_len);
     else
     {
         if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
             return M_CM_NOT_MALLOC;
         else
             return apiRC;
     }

     cm_buf_init(raw_ptr);          /* get index key from old record */
     cm_buf_get("%l %s %s",&dummy,icar_type, ideduct);

     $BEGIN WORK;

     $SELECT  mdeduct,  prn_deduct, mcoverage1, mcoverage2, mcoverage3
        INTO $mdeduct, $prn_deduct, $lMcoverage1, $lMcoverage2, $lMcoverage3
        FROM ca_dmg_mdeduct
       WHERE icar_type = $icar_type
         AND ideduct = $ideduct;

     /* if key value has been changed then SQLNOTFOUND,else put current value
        into cur_buf for comparison */

     if (SQLCODE == SQLNOTFOUND)
     {
          MsgCode = M_CM_NOT_FOUND;
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          if (SQLCODE != 0) MsgCode = SQLCODE;         /* rollback fail */
          if(exitsub(reply,MsgCode) == True)
            return MsgCode;
          else
            return apiRC;
     }

     cm_buf_init(cur_buf);
     cm_buf_put("%l %s %s %s %s ",dummy, icar_type, ideduct, mdeduct, prn_deduct);
     cm_buf_put("%l %l %l ", lMcoverage1, lMcoverage2, lMcoverage3);

     printf("[%s]\n",cur_buf);
     printf("[%s]\n",raw_ptr);

     if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
     {
          MsgCode = M_CM_NOT_EQUAL;
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          if (SQLCODE != 0) MsgCode = SQLCODE;         /* rollback fail */
          if(exitsub(reply,MsgCode) == True)
            return MsgCode;
          else
            return apiRC;
     }

     /* equal, then exec DB operation */

     if ( option == 'D' )
     {
          for(j=0;j<i;j++)
          {
               sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM %s:ca_dmg_mdeduct "
                                " WHERE icar_type=? AND ideduct=?" ,list[j].dbname);
               $PREPARE d_id FROM $stmt_buf;
               if(SQLCODE != 0)
               {
                   is_del_fail = 1;
                   break;
               }
               $EXECUTE d_id USING $icar_type, $ideduct;
               if(SQLCODE != 0)
               {
                   is_del_fail = 1;
                   break;
               }
          }/* for loop */

          if( is_del_fail ) goto errexit;

          cm_buf_init(ReplyBuf);
          cm_buf_put("%l",M_CM_OK);
          tmp_len = cm_buf_len(ReplyBuf);
          if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return apiRC;
          }

          $WHENEVER SQLERROR GOTO errexit;
          $COMMIT WORK;
          return api_OKComplete;
     }
     else if (option == 'U')
     {
          cm_buf_init(command);
          cm_buf_get("%c %s %s %s %s %s",&option,DBName,icar_type, ideduct, mdeduct, prn_deduct);
          cm_buf_get("%l %l %l ",&lMcoverage1, &lMcoverage2, &lMcoverage3);

          /* grasp old key */
          cm_buf_init(raw_ptr);
          cm_buf_get("%l %s %s",&dummy,old_icar_type, old_ideduct);

          $WHENEVER SQLERROR CONTINUE;
          for(j=0;j<i;j++)
          {
               sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE %s:ca_dmg_mdeduct "
                                " SET (icar_type,ideduct,mdeduct, prn_deduct) "
                                " = (?,?,?,?) WHERE icar_type = ? AND ideduct = ?",list[j].dbname);

               $PREPARE u_id FROM $stmt_buf;
               if(SQLCODE != 0)
               {
                    is_upd_fail = 1;
                    break;
               }
               $EXECUTE u_id USING $icar_type,$ideduct,$mdeduct, $prn_deduct,
                                   $old_icar_type, $old_ideduct;
               if(SQLCODE != 0)
               {
                    is_upd_fail = 1;
                    break;
               }
               if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
               {
                    sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:ca_dmg_mdeduct "
                                      " (icar_type, ideduct, mdeduct, prn_deduct) "
                                      " VALUES (?,?,?,?)",list[j].dbname);

                    $PREPARE ua_id FROM $stmt_buf;
                    if(SQLCODE != 0)
                    {
                        is_upd_fail = 1;
                        break;
                    }
                    $EXECUTE ua_id USING $icar_type, $ideduct, $mdeduct, $prn_deduct;
                    if(SQLCODE != 0)
                    {
                         is_upd_fail = 1;
                         break;
                    }
               }
          } /* for loop */

          if( is_upd_fail ) goto errexit;
		  
		  free(raw_ptr);

          cm_buf_init(ReplyBuf);
          cm_buf_put("%l",M_CM_OK);
          tmp_len = cm_buf_len(ReplyBuf);
          if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          {
              $WHENEVER SQLERROR CONTINUE;
              $ROLLBACK WORK;
              return apiRC;
          }
          $WHENEVER SQLERROR GOTO errexit;
          $COMMIT WORK;
          return api_OKComplete;
     }
     else
     {
          MsgCode = M_CM_WRONG_OPTION;
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          if (SQLCODE != 0) MsgCode = SQLCODE;         /* rollback fail */
          if(exitsub(reply,MsgCode) == True)
            return MsgCode;
          else
            return apiRC;
     }

errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if (SQLCODE != 0) MsgCode = SQLCODE;         /* rollback fail */
   if(exitsub(reply,MsgCode) == True)
     return MsgCode;
   else
     return apiRC;
}
