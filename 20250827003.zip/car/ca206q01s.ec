/**********************************************************************/
/*   program id   : ca206q01s.ec                                      */
/*   program name : ���������d��                                      */
/*   date written : 02/27/2019                                        */
/*   date modify  :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include <math.h>
#include "carmsgs.h" 
#include "cmnmsgs.h" 
#include "gls_array.h" 
#include "gls_const.h"
#include "safeclib.h"



$char stmt[1024];
$char ipolicy[21],icardold[21],icardnew[21];
int   count_db,k,i; 
char  outputf[21];
$char userid[11];
$char DBName[05];
$char FormTp[03];
$char msgbuf[128];
$char sIcard_old[21],sIcard_new[21],sIpolicy[21],sIcreate[12],sNname[12],sDcreate[22],sNreason[60];

int   max_count;

DBinfo *list;

/*********************************************************************/
main(argc, argv)
int argc;
char **argv;
{
 	int rc;

	batchinit();
	strcpy(DBName,    	isNULLstr(argv[1]));
	strcpy(userid,    	isNULLstr(argv[2]));
        strcpy(icardold,        isNULLstr(argv[3])); 
        strcpy(icardnew,     	isNULLstr(argv[4])); 
        strcpy(ipolicy,      	isNULLstr(argv[5]));
        strcpy(outputf,   	isNULLstr(argv[6]));
	
	strcpy(icardold,trim(icardold));
	strcpy(icardnew,trim(icardnew));
	strcpy(ipolicy,trim(ipolicy));

   	printf("icardold[%s]--icardnew[%s]--ipolicy[%s]\n", icardold, icardnew, ipolicy);

	rc = car206_get_db();
	if (rc != M_CM_OK)
		return rc;

		
 	rc = car206_build();
	if (rc != M_CM_OK) 
		return rc;    

        if ((rc=save_form_info(F_FREE,"CA",206,userid,FormTp,max_count,outputf))<0)
        {
            EWRITE(userid,rc,"save_form_info failed");
            exit(FAIL);
        }
}
/*----------------------------------------------------------------------------*/
long car206_get_db()
{
	$whenever sqlerror goto errexit;

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car206_build()
{
  $char FormFile[N_FILE+1];
  char  OutFile[N_FILE];
  long  rtncode;


  $WHENEVER SQLERROR GOTO errexit;


  $SELECT nForm_File, iForm_Tp
     INTO $FormFile, $FormTp
     FROM Form
    WHERE ksys_grp="CA" AND kPgmID = 206
      AND iform_tp = '1';
      


  strcpy(FormFile,rtrim(FormFile));  /* FormFile=car206.fmt */
  sprintf_s(OutFile, sizeof OutFile,"%s.tx",outputf);
  rgu_init_report(FormFile,OutFile);


  rgu_put_body_string(1,icardold,LEFT);
  rgu_put_body(1);
  rgu_put_body_string(2,icardnew,LEFT);
  rgu_put_body(2);
  rgu_put_body_string(3,ipolicy,LEFT);
  rgu_put_body(3);
  rgu_put_body(4);

  max_count+=9;


  sprintf_s(stmt, sizeof stmt, "SELECT  a.icard_old, a.icard_new, a.ipolicy, a.icreate,b.nname, a.dcreate, a.nreason \n"
                 "  FROM  sysdb:ca_icard_change a, sysdb:officer b\n"
                 " WHERE  icard_old MATCHES '%s' AND icard_new MATCHES '%s' AND ipolicy MATCHES '%s' AND a.icreate = b.iofficer",icardold,icardnew,ipolicy);
  printf("stmt[%s]",stmt);
  $PREPARE prep FROM $stmt;
  $DECLARE curs CURSOR FOR prep;
  $OPEN curs;
  for(;;)
  {
      $FETCH curs INTO $sIcard_old,$sIcard_new,$sIpolicy,$sIcreate,$sNname,$sDcreate,$sNreason;
            
      if( SQLCODE == SQLNOTFOUND) break;
      
      rgu_put_body_string(5,sIcard_old,LEFT);
      rgu_put_body_string(5,sIcard_new,LEFT);
      rgu_put_body_string(5,sIpolicy,LEFT);
      rgu_put_body_string(5,sIcreate,LEFT);
      rgu_put_body_string(5,sNname,LEFT);
      rgu_put_body_string(5,sDcreate,LEFT);
      rgu_put_body_string(5,sNreason,LEFT);
      rgu_put_body(5);      	
      	
           
  }
  $FREE prep;
  $CLOSE curs;
  $FREE curs;
  

  
  

  

  
  rgu_finish_report();
  return M_CM_OK;
  
errexit:
  sqlfatal();
  EWRITE(userid,SQLCODE,sqlca.sqlerrm);
  exit (FAIL);
} 

/*--------------------------------------------------------------------*/