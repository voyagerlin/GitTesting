/************************************************/
/*						*/
/*   PROGRAM : ca1007p01s.ec                     */
/*						*/
/************************************************/
#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "ca_field.h"
#include <locator.h>
#include "safeclib.h"

char  outputf[ N_FILE+1];
char  userid[11], aphome[40];

$char stmt[4096], DBName[5], sFullName[20];
char  sMsg[10240];
FILE  *sfp, *fp, *fp_note;
int rc, rc1;
DBinfo  *list;
int i=0, count_db;

/***************************************************************************/
main(argc, argv)
int argc;
char **argv;
{


   batchinit(); 
   strcpy(DBName,    isNULLstr(argv[1]));
   strcpy(userid,    isNULLstr(argv[2]));
   strcpy(outputf,   isNULLstr(argv[3]));

   $WHENEVER SQLERROR GOTO errexit;

   sfp =  (FILE *)STARTLOG();

   if (db_select(DBName) == False)
   {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN"); 
       return M_CM_DB_NOTOPEN;
   }
            
   rc = getApHome(aphome);
   if (rc<0) {
       EWRITE( userid, -1, "In sigalrmcatcher func==>read config file error!!");
       return FAIL;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   rc=car1007_get_data();
   if (rc != M_CM_OK)
   {
       EWRITE(userid, rc, sMsg);
       return rc;
   }

   WRITELOG( sfp, "���槹��");
   ENDLOG(sfp);
   return M_CM_OK;

errexit:
    printf("------car1007: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    exit(1);

}
/***************************************************************************/
long car1007_get_data()
{
    	
    $DELETE FROM ca_isign_note WHERE 1=1;
    
    $CREATE TEMP TABLE tmp_car1007 
    ( 
         ipolicy1     char(20),   /*�j��O�渹*/
         ipolicy2     char(20),   /*���N�O�渹*/
         iofficer1    char(10),   /*�j��g��N��*/
         icar_type1   char(2),    /*�j���*/
         icar_type2   char(2),    /*���N����*/
         mcover1      integer,    /*�j���`�O�B*/
         mcover2      integer     /*���N�`�O�B*/
    ) WITH NO LOG;
    
    for (i=0;i<count_db;i++)
    {
        sprintf_s(stmt, sizeof stmt, " insert into ca_isign_note (isign,iclass,ipolicy,iendorse,inum1,iofficer,nofficer,icreate,ncreate,iupcomp,dcreate,dclose,ddate,nremark,nassured,itag,nleader,dply_begin,iquota) \n"
                       "  select a.iedr_examiner, '1', a.ipolicy, a.iendorse, ' ', a.iofficer, (SELECT nname FROM officer WHERE iofficer = a.iofficer), \n"
                       "     a.iedr_examiner,(SELECT nname FROM officer WHERE iofficer = a.iedr_examiner),(SELECT iupcomp FROM officer WHERE iofficer = a.iedr_examiner), \n"
                       "     date(a.dcreate),a.dedr_close,today,'�L',b.nassured,b.itag,(select nname from officer where iofficer = a.ileader),a.dedr_begin,' ' \n"
                       "   FROM %s:edr_relation a, %s:endorsement b \n"
                       "  WHERE a.iendorse = b.iendorse AND a.fedr_print = '1' AND a.iendorse not like '%%CVP%%' \n", list[i].dbname, list[i].dbname);
        printf("prep1[%s]\n", stmt);
        $PREPARE prep1 FROM $stmt;
        $EXECUTE prep1;

        sprintf_s(stmt, sizeof stmt, " insert into ca_isign_note (isign,iclass,ipolicy,iendorse,inum1,iofficer,nofficer,icreate,ncreate,iupcomp,dcreate,dclose,ddate,nremark,nassured,itag,nleader,dply_begin,iquota) \n"
                       "  select a.iedr_examiner, '2', a.ipolicy, a.iendorse, ' ', a.iofficer, (SELECT nname FROM officer WHERE iofficer = a.iofficer), \n"
                       "     a.iedr_examiner,(SELECT nname FROM officer WHERE iofficer = a.iedr_examiner),(SELECT iupcomp FROM officer WHERE iofficer = a.iedr_examiner), \n"
                       "     date(a.dcreate),a.dedr_close,today,'�L',b.nassured,b.itag,(select nname from officer where iofficer = a.ileader),a.dedr_begin,' ' \n"
                       "   FROM %s:edr_relation a, %s:endorsement b \n"
                       "  WHERE a.iendorse = b.iendorse AND a.fply_print = '1' AND a.iendorse not like '%%CVP%%' \n", list[i].dbname, list[i].dbname);
        printf("prep2[%s]\n", stmt);
        $PREPARE prep2 FROM $stmt;
        $EXECUTE prep2;

        sprintf_s(stmt, sizeof stmt, " insert into ca_isign_note (isign,iclass,ipolicy,iendorse,inum1,iofficer,nofficer,icreate,ncreate,iupcomp,dcreate,dclose,ddate,nremark,nassured,itag,nleader,dply_begin,iquota) \n"
                       "  select a.iedr_examiner, '3', a.ipolicy, a.iendorse, ' ', a.iofficer, (SELECT nname FROM officer WHERE iofficer = a.iofficer), \n"
                       "     a.iedr_examiner,(SELECT nname FROM officer WHERE iofficer = a.iedr_examiner),(SELECT iupcomp FROM officer WHERE iofficer = a.iedr_examiner), \n"
                       "     date(a.dcreate),a.dedr_close,today,'������O:'||a.fedr_class||'�h�O��]:'||a.terminate_rsn||'�O�O:'||a.medrlia_prem+a.medrdmg_prem||'��z�覡:'||a.iedr_return, \n"
                       "     b.nassured,b.itag,(select nname from officer where iofficer = a.ileader),a.dedr_begin,' ' \n"
                       "  FROM %s:edr_relation a, %s:endorsement b, ao_plyedr_prem c \n"
                       " WHERE a.iendorse = b.iendorse \n"
                       "   AND a.ipolicy[1,13] = c.ipolicy1 \n"
                       "   AND a.ipolicy[14,20] = c.ipolicy2 \n"
                       "   AND a.iendorse = c.iendorse \n"
                       "   AND a.iendorse NOT LIKE '%%CVP%%' \n"
                       "   AND a.iedr_return <> '2' AND a.fedr_class NOT IN ('1','2','5','4','A','B') AND a.medrlia_prem+a.medrdmg_prem<0 \n"
                       "   AND a.dedr_close IS NOT NULL \n"
                       "   AND c.dpay IS null \n"
                       "   AND NOT EXISTS (SELECT 1 FROM ao_prem_return WHERE ipolicy1 = a.ipolicy[1,13] AND ipolicy2 = a.ipolicy[14,20] AND iendorse = a.iendorse) \n",
                          list[i].dbname, list[i].dbname);
        printf("prep3[%s]\n", stmt);
        $PREPARE prep3 FROM $stmt;
        $EXECUTE prep3;

        sprintf_s(stmt, sizeof stmt, " insert into ca_isign_note (isign,iclass,ipolicy,iendorse,inum1,iofficer,nofficer,icreate,ncreate,iupcomp,dcreate,dclose,ddate,nremark,nassured,itag,nleader,dply_begin,iquota) \n"
                       "  select a.iedr_examiner, '4', a.ipolicy, a.iendorse, ' ', a.iofficer, (SELECT nname FROM officer WHERE iofficer = a.iofficer), \n"
                       "     a.iedr_examiner,nvl((SELECT nname FROM officer WHERE iofficer = a.iedr_examiner),''), \n"
                       "     nvl((SELECT iupcomp FROM officer WHERE iofficer = a.iedr_examiner),''), \n"
                       "     date(a.dcreate),a.dedr_close,today,'�L',b.nassured,b.itag,(select nname from officer where iofficer = a.ileader),a.dedr_begin,' ' \n"
                       "   FROM %s:edr_relation a, %s:endorsement b \n"
                       "  WHERE a.iendorse = b.iendorse AND a.dedr_close is null AND a.iendorse not like '%%CVP%%' \n", list[i].dbname, list[i].dbname);
        printf("prep4[%s]\n", stmt);
        $PREPARE prep4 FROM $stmt;
        $EXECUTE prep4;
        
        sprintf_s(stmt, sizeof stmt, " insert into ca_isign_note (isign,iclass,ipolicy,iendorse,inum1,iofficer,nofficer,icreate,ncreate,iupcomp,dcreate,dclose,ddate,nremark,nassured,itag,nleader,dply_begin,iquota) \n"
                       "  SELECT a.isign, '5', a.ipolicy, ' ', a.icard, a.iofficer, c.nname, \n"
                       "         a.iexaminer,(SELECT nname FROM officer WHERE iofficer = a.iexaminer),(SELECT iupcomp FROM officer WHERE iofficer = a.iexaminer), \n"
                       "         date(a.dcreate),a.dply_close,today,'�L',b.nassured,b.itag,d.nname,a.dply_begin,' ' \n"
                       "    FROM %s:ply_relation a, %s:policy b,officer c,officer d \n"
                       "   WHERE a.ipolicy = b.ipolicy AND (a.icard[3,4] = 'C2' OR a.icard[3,4] = 'M2') AND a.fprint = '0' AND a.dentry >= '01/01/2017' AND b.iroute matches 'PA05072925*'\n"
                       "     AND fout_print!='1' AND fmail_type='0' AND c.iofficer=a.iofficer AND d.iofficer=a.ileader \n", list[i].dbname, list[i].dbname);
        printf("prep51[%s]\n", stmt);
        $PREPARE prep51 FROM $stmt;
        $EXECUTE prep51;
        
        sprintf_s(stmt, sizeof stmt, " insert into ca_isign_note (isign,iclass,ipolicy,iendorse,inum1,iofficer,nofficer,icreate,ncreate,iupcomp,dcreate,dclose,ddate,nremark,nassured,itag,nleader,dply_begin,iquota) \n"
                       "  SELECT a.isign, '5', a.ipolicy, ' ', a.icard, a.iofficer, d.nname, \n"
                       "         a.iexaminer,nvl((SELECT nname FROM officer WHERE iofficer = a.iexaminer),''),nvl((SELECT iupcomp FROM officer WHERE iofficer = a.iexaminer),''), \n"
                       "         date(a.dcreate),a.dply_close,today,'�L',b.nassured,b.itag,e.nname,a.dply_begin,' ' \n"
                       "    FROM %s:ply_relation a, %s:policy b, compulsory_card c ,officer d,officer e \n"
                       "   WHERE a.ipolicy = b.ipolicy AND a.icard = c.icard AND a.fprint = '0' AND feply = '0' AND c.ireceive = 'system' \n"
                       "     AND fout_print!='1' AND fmail_type='0' AND d.iofficer=a.iofficer AND e.iofficer=a.ileader \n", list[i].dbname, list[i].dbname);
        printf("prep52[%s]\n", stmt);
        $PREPARE prep52 FROM $stmt;
        $EXECUTE prep52;
        
        
        /*���O6-�į�վ�*/

        sprintf_s(stmt, sizeof stmt, " insert into tmp_car1007 \n"
                       " SELECT  a.ipolicy,  b.ipolicy, a.iofficer ,a.icar_type,b.icar_type, \n"
                       "        (SELECT sum(minjured_cover)+sum(mdeath_cover)+sum(mdamage_cover) FROM %s:ply_ins_type WHERE ipolicy=a.ipolicy),\n"
                       "        (SELECT sum(minjured_cover)+sum(mdeath_cover)+sum(mdamage_cover) FROM %s:ply_ins_type WHERE ipolicy=b.ipolicy)\n"
                       "   FROM %s:ply_relation a, %s:ply_relation b \n"
                       "  WHERE a.ipolicy = b.irelative_ply AND a.irelative_ply = b.ipolicy \n"
                       "    AND a.icar_type <> b.icar_type AND a.fcard_class = '1' \n"
                       "    AND a.dpolicy between '11/08/2017' AND today \n", list[i].dbname, list[i].dbname, list[i].dbname, list[i].dbname, list[i].dbname);
        printf("prep6_1[%s]\n", stmt);
        $PREPARE prep6_1 FROM $stmt;
        $EXECUTE prep6_1;   
        
        $DELETE FROM tmp_car1007 WHERE mcover1=0 OR mcover2=0;
        $DELETE FROM tmp_car1007 WHERE icar_type1 = '14' AND icar_type2 = '4A';
        $DELETE FROM tmp_car1007 WHERE icar_type1 = '08' AND icar_type2 IN ('8A','9A');
        $DELETE FROM tmp_car1007 WHERE icar_type1 = '19' AND icar_type2 = '9B';
        $DELETE FROM tmp_car1007 WHERE icar_type1 = '22' AND icar_type2 IN ('2A','2B','2C');
        $DELETE FROM tmp_car1007 WHERE iofficer1 = 'X6203595' AND icar_type1 = '21' AND icar_type2 = '14';
        
        
        sprintf_s(stmt, sizeof stmt, " insert into ca_isign_note (isign,iclass,ipolicy,iendorse,inum1,iofficer,nofficer,icreate,ncreate,iupcomp,dcreate,dclose,ddate,nremark,nassured,itag,nleader,dply_begin,iquota) \n"
                       "  SELECT a.isign, '6', a.ipolicy, ' ', b.ipolicy, a.iofficer, d.nname, \n"
                       "     a.iexaminer, nvl((SELECT nname FROM officer WHERE iofficer = a.iexaminer),''), nvl((SELECT iupcomp FROM officer WHERE iofficer = a.iexaminer),''), \n"
                       "     date(a.dcreate), a.dply_close, today, '�j�G'|| a.icar_type||' ���G'||b.icar_type,  \n"
                       "     c.nassured,c.itag,e.nname,a.dply_begin,' ' \n"
                       "    FROM %s:ply_relation a, %s:ply_relation b, %s:policy c,officer d,officer e ,tmp_car1007 f\n"
                       "   WHERE a.ipolicy = f.ipolicy1 AND b.ipolicy = f.ipolicy2 AND d.iofficer=a.iofficer AND e.iofficer=a.ileader AND a.ipolicy = c.ipolicy \n"
                       ,list[i].dbname, list[i].dbname, list[i].dbname);
        printf("prep6_2[%s]\n", stmt);
        $PREPARE prep6_2 FROM $stmt;
        $EXECUTE prep6_2; 
        
        $DELETE FROM tmp_car1007 WHERE 1=1;
       
        /*
        sprintf_s(stmt, sizeof stmt, " insert into ca_isign_note (isign,iclass,ipolicy,iendorse,inum1,iofficer,nofficer,icreate,ncreate,iupcomp,dcreate,dclose,ddate,nremark,nassured,itag,nleader,dply_begin,iquota) \n"
                       "  SELECT a.isign, '6', a.ipolicy, ' ', b.ipolicy, a.iofficer, d.nname, \n"
                       "     a.iexaminer, nvl((SELECT nname FROM officer WHERE iofficer = a.iexaminer),''), nvl((SELECT iupcomp FROM officer WHERE iofficer = a.iexaminer),''), \n"
                       "     date(a.dcreate), a.dply_close, today, '�j�G'|| a.icar_type||' ���G'||b.icar_type,  \n"
                       "     c.nassured,c.itag,e.nname,a.dply_begin,' ' \n"
                       "    FROM %s:ply_relation a, %s:ply_relation b, %s:policy c,officer d,officer e \n"
                       "   WHERE a.ipolicy = b.irelative_ply AND a.irelative_ply = b.ipolicy AND a.ipolicy = c.ipolicy\n"
                       "     AND a.icar_type <> b.icar_type AND a.fcard_class = '1' \n"
                       "     AND a.dpolicy between '11/08/2017' AND today  \n"
                       "     AND NOT (a.icar_type = '14' AND b.icar_type = '4A') \n"
                       "     AND NOT (a.icar_type = '08' AND b.icar_type IN ('8A','9A')) \n"
                       "     AND NOT (a.icar_type = '19' AND b.icar_type = '9B') \n"
                       "     AND NOT (a.icar_type = '22' AND b.icar_type IN ('2A','2B','2C')) \n" 
                       "     AND NOT (a.iofficer = 'X6203595' AND a.icar_type = '21' AND b.icar_type = '14') \n"
                       "     AND d.iofficer=a.iofficer AND e.iofficer=a.ileader \n"
                       "     AND (SELECT sum(minjured_cover)+sum(mdeath_cover)+sum(mdamage_cover) FROM %s:ply_ins_type WHERE ipolicy=a.ipolicy)>0 \n"
                       "     AND (SELECT sum(minjured_cover)+sum(mdeath_cover)+sum(mdamage_cover) FROM %s:ply_ins_type WHERE ipolicy=b.ipolicy)>0 \n", 
                       list[i].dbname, list[i].dbname, list[i].dbname, list[i].dbname, list[i].dbname);
        printf("prep6[%s]\n", stmt);
        $PREPARE prep6 FROM $stmt;
        $EXECUTE prep6;*/
        
/*******�s�W�u7�G�����O���v(1061228001_SC1_�s�W���sCAR1007�֫O�N��ƶ����O-�����O���A071004������) */
        sprintf_s(stmt, sizeof stmt, " insert into ca_isign_note (isign,iclass,ipolicy,iendorse,inum1,iofficer,nofficer,icreate,ncreate,iupcomp,dcreate,dclose,ddate,nremark,nassured,itag,nleader,dply_begin,iquota) \n"
                       " SELECT  a.iedr_examiner, '7', a.ipolicy, a.iendorse, ' ', a.iofficer, \n" 
                       "         (SELECT nname FROM officer WHERE iofficer = a.iofficer), \n"
                       "         a.iedr_examiner, \n"
                       "         nvl((SELECT nname FROM officer WHERE iofficer = a.iedr_examiner),''), \n"
                       "         nvl((SELECT iupcomp FROM officer WHERE iofficer = a.iedr_examiner),''), \n"
                       "         date(a.dcreate),a.dedr_close,today,'���O�O:'||to_char(a.medrdmg_prem+a.medrlia_prem),b.nassured,b.itag,  \n"
                       "         (SELECT nname FROM officer WHERE iofficer = a.ileader),a.dedr_begin, \n"
                       "         nvl((SELECT iquota FROM officer WHERE iofficer = a.iedr_examiner),'') \n"
                       "   FROM  %s:edr_relation a, %s:endorsement b, %s:ao_plyedr_prem c \n"
                       "  WHERE  a.iendorse = b.iendorse AND a.iendorse not like '%%CVP%%'  \n"
                       "         AND a.medrdmg_prem+a.medrlia_prem > 0 \n"
                       "         AND date(a.dcreate) > '04/01/2018' \n"
                       "         AND c.frcvpay='N' AND c.iendorse = a.iendorse AND c.ftype <> 'P' \n", list[i].dbname, list[i].dbname, list[i].dbname);
        printf("prep7[%s]\n", stmt);
        $PREPARE prep7 FROM $stmt;
        $EXECUTE prep7;       
 /*********************************************************/       
        
        
    }
    $FREE prep1;
    $FREE prep2;
    $FREE prep3;
    
    
    return M_CM_OK;

errexit:
    sprintf_s(sMsg, sizeof sMsg, "car1007_get_data:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    printf("%s", sMsg);
    return SQLCODE;
}
/***************************************************************************/
