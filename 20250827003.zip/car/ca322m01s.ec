/************************************************/
/*                                              */
/*   PROGRAM : car32201s.ec by Pei-Chow Chen    */
/*                                              */
/*   PURPOSE : server side standard program     */
/*                                              */
/************************************************/

#include <stdio.h>
#include <time.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"
$include sqlca;

$char sWhere[1000];
char  sWhereP[1000];
char  sWhereC[1000];	/* �H�̷s�O���ɬd */
char option1;
long rtncode;
$int iCountDeny;

long car322(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car322_print(),car322_multiple_query();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 option1 = option;
 switch(option)
 {
  case 'P':
  case 'Q':
           rtncode=car322_print(reply);
           printf("--- rtncode=[%d]-- \n",rtncode);
           break;
  case 'M':
           rtncode=car322_multiple_query(reply);
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
             return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

long car322_print(reply)
serverReply reply;
{
 $char DBName[5],i_fclass[2],i_icode[3],i_ncode[11];
 $char i_icar_grp[2],i_fcar_class[2];
 $char dentry[11];
 $char ibranch[4];
 $char print_flag[2];
 $char option_flag[2];

 $char arg1[21];
 $char arg2[21];
 $char arg3[21];
 $char arg4[21];
 $char taipei_db[41];
 $char dbname_tp[45];

 $char sWhere0[3000],sWhere1[3000],sWhere4[3000];
 $char estimatei[21], sIofficer2[11];
 $char stmt[8000];
 $char sApHome[31];
  char sTmp0[51],file0[51];
  char extern rptstr322[10000];
 $long rc;
 int   iequip_flag;
 char  sequip_str[500];
 $int  iRows, iply_count = 0,count_a = 0;
 $char sIassured[13], sMsg[512];

 int tmp_len;

 cm_buf_get("%s %s %s %s %s %s %s %s %s",DBName,dentry,ibranch,print_flag,option_flag,arg1,arg2,arg3,arg4);


 printf("INTO main function \n");
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 printf("flag1   taipei_db=[%s]\n",taipei_db);
 
 rc = getHeadBranch(taipei_db);
 printf("rc=[%d]\n",taipei_db);
 if (rc < 0)
 {
      printf("read Config file error!!\n");
      return M_CM_READ_CONFIG_ERR;
 }
 printf("---- 106 ----- \n");
 $select ipolicy, irelative_ply from ply_relation where 1=0 into temp tmp_ply;
 printf("---- 107 ----- \n");
 
 printf("flag2\n");
 strcpy(dbname_tp,get_full_dbname(taipei_db)); /* get TP's full DB name */

 strcpy(arg1,trim(arg1));
 strcpy(arg2,trim(arg2));
 strcpy(arg3,trim(arg3));
 strcpy(arg4,trim(arg4));

 printf("flag3\n");
 strcpy(dentry,cm_to_infdate(dentry));
 printf("option_flag[%s]\n",option_flag);
 switch(option_flag[0])
 {
     case '1':   /* �M�׵��O */
             iequip_flag = (atoi(arg1) - 1) % 30 + 1;
             strcpy(sequip_str,equip_instr(arg1));
             sprintf_s(sWhere0, sizeof sWhere0," AND nequipment[%d] in %s ",iequip_flag,sequip_str);
             sprintf_s(sWhere1, sizeof sWhere1," AND nequipment[%d] in %s ",iequip_flag,sequip_str);
             sprintf_s(sWhere4, sizeof sWhere4," AND b.nequipment[%d] in %s ",iequip_flag,sequip_str);
             break;
     case '2':   /* �g��H�N�� */
             sprintf_s(sWhere0, sizeof sWhere0," AND (iofficer1 MATCHES '%s' OR        "
                                    "iofficer2 MATCHES '%s') ",arg1,arg1);
             sprintf_s(sWhere1, sizeof sWhere1," AND (iofficer1 MATCHES '%s' OR        "
                                    "iofficer2 MATCHES '%s') ",arg1,arg1);
						 sprintf_s(sWhere4, sizeof sWhere4," AND a.iofficer MATCHES '%s' ",arg1);
             break;
     case '3':   /* �����Ҹ��X */
             sprintf_s(sWhere0, sizeof sWhere0," AND iassured MATCHES '%s' ",arg1);
             sprintf_s(sWhere1, sizeof sWhere1," AND iassured MATCHES '%s' ",arg1);
             sprintf_s(sWhere4, sizeof sWhere4," AND b.iassured MATCHES '%s' ",arg1);
             break;
     case '4':   /* �P�Ӹ��X   */
             sprintf_s(sWhere0, sizeof sWhere0," AND itag MATCHES '%s' ",arg1);
             sprintf_s(sWhere1, sizeof sWhere1," AND itag MATCHES '%s' ",arg1);
             sprintf_s(sWhere4, sizeof sWhere4," AND b.itag MATCHES '%s' ",arg1);
             break;
     case '5':   /* �������X   */
             sprintf_s(sWhere0, sizeof sWhere0," AND iengine MATCHES '%s' ",arg1);
             sprintf_s(sWhere1, sizeof sWhere1," AND iengine MATCHES '%s' ",arg1);
             sprintf_s(sWhere4, sizeof sWhere4," AND b.iengine MATCHES '%s' ",arg1);
             break;
     case '6':   /* �պ⸹�X   */
             strcat(arg1,arg2);
             strcat(arg3,arg4);
             sprintf_s(sWhere0, sizeof sWhere0," AND iabnormal BETWEEN '%s' AND '%s' ",arg1,arg3);
             sprintf_s(sWhere1, sizeof sWhere1," AND iestimate BETWEEN '%s' AND '%s' ",arg1,arg3);
             sprintf_s(sWhere4, sizeof sWhere4," AND a.itmp_policy BETWEEN '%s' AND '%s' ",arg1,arg3);
             break;
     case '7':   /* �O�渹�X   */
             strcat(arg1,arg2);
             strcat(arg3,arg4);
             if (arg1[5] == 'V')
             {
                sprintf_s(sWhere0, sizeof sWhere0," AND ipolicy2 BETWEEN '%s' AND '%s' ",arg1,arg3);
                sprintf_s(sWhere1, sizeof sWhere1," AND ipolicy2 BETWEEN '%s' AND '%s' ",arg1,arg3);
             }
             else
             {
                sprintf_s(sWhere0, sizeof sWhere0," AND ipolicy1 BETWEEN '%s' AND '%s' ",arg1,arg3);
                sprintf_s(sWhere1, sizeof sWhere1," AND ipolicy1 BETWEEN '%s' AND '%s' ",arg1,arg3);
             }
             sprintf_s(sWhere4, sizeof sWhere4," AND a.ipolicy BETWEEN '%s' AND '%s' ",arg1,arg3);
             break;

     case '8':   /* �O�I��/�d�� */
             sprintf_s(sWhere0, sizeof sWhere0," AND (icomp_card BETWEEN '%s' AND '%s'    "
                                "OR  iins_card  BETWEEN '%s' AND '%s') ",arg1,arg2,arg1,arg2);
             sprintf_s(sWhere1, sizeof sWhere1," AND (icard1 BETWEEN '%s' AND '%s'        "
                                "OR  icard2 BETWEEN '%s' AND '%s') ",arg1,arg2,arg1,arg2);
						 sprintf_s(sWhere4, sizeof sWhere4," AND a.icard BETWEEN '%s' AND '%s'  ",arg1,arg2);
             break;
 default:
             exit(1);
 }

 rc = getApHome(sApHome);
 if (rc < 0) 
 {
     printf("read Config file error!!\n");
     return M_CM_READ_CONFIG_ERR;
 }
 
 printf("option1[%c]\n", option1);
 if (option1 == 'P')
 {
    puts("P");
    sprintf_s(sWhereP, sizeof sWhereP," AND dentry = '%s' AND ibranch matches '%s' ",dentry,ibranch);
 }
 else
 {
    puts("not P");
    strcpy(sWhereP," ");
 }

	if (strcmp(print_flag,"4") == 0)
	{
		/* �H�̷s�O���ɬd */
		
		sprintf_s(stmt, sizeof stmt,
		" SELECT a.ipolicy, a.iofficer, b.iassured   "
	     " FROM ply_relation a, policy b  "
	     "WHERE a.ipolicy = b.ipolicy   "
	     "  AND a.dpolicy = '%s' AND a.ibranch matches '%s' %s  ",
	      dentry, ibranch, sWhere4);
	}
	else
	{
		/* �H�պ��ɬd */
	 sprintf_s(stmt, sizeof stmt,
	  " SELECT iabnormal, decode(trim(iofficer2),'',iofficer1,iofficer2), iassured  "
	    "  FROM %s:abnormal_ply            "
	    " WHERE 1=1 %s              "
	    "    %s                            "
	    " UNION                            "
	    "SELECT iestimate, decode(trim(iofficer2),'',iofficer1,iofficer2), iassured  "
	    "  FROM estimate                   "
	    " WHERE 1=1 %s              "
	    "    %s ",dbname_tp,sWhereP,sWhere0,sWhereP,sWhere1);
	  }
  printf("stmt[%s]\n",stmt);

  cm_buf_init(ReplyBuf);
  cm_buf_res_msg();           /* reserve for msg_code and count */
  cm_buf_res_count();

  iRows=0;
  $PREPARE main_id FROM $stmt;
  $DECLARE main_cur CURSOR FOR main_id;
  $OPEN main_cur;
  for(;;)
  { printf("before fetch main_cur\n");
    $FETCH main_cur INTO $estimatei, $sIofficer2, $sIassured;
    if (SQLCODE == SQLNOTFOUND) break;

    printf("estimatei[%s]\n",estimatei);
    
      iCountDeny=0;
        $select count(*) into $iCountDeny
            from cm_personal_deny
           where iassured = $sIassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today);
        if(iCountDeny > 0)
        {
         printf("--- M_CA_PERSONAL_DENY ---- \n");
         continue;
        }
		if (strcmp(print_flag,"4") == 0)
		{
			$select count(*) into $count_a  from tmp_ply;
			printf("-- count_a = [%d]\n",count_a);
			
			$select count(*) into $iply_count 
			   from tmp_ply 
			  where irelative_ply = $estimatei;
			    
			
			printf("---estimatei=[%s]iply_count=[%d]\n",estimatei,iply_count);
			if (iply_count == 0)
			{
				$insert into tmp_ply
			  	select ipolicy, irelative_ply from ply_relation
			   	where ipolicy = $estimatei;

					cm_buf_put("%s, %s", estimatei, sIofficer2);
    			iRows++;
			}
		}
		else
		{
    	cm_buf_put("%s, %s", estimatei, sIofficer2);
    	iRows++;
    }
  }
  printf("out for loop \n");
  $CLOSE main_cur;
  $FREE  main_cur;
   
  $drop table tmp_ply;
  cm_buf_put_msg(M_CM_OK); /* remained data */
  cm_buf_put_count(iRows);
  tmp_len = cm_buf_len(ReplyBuf);
  
  
printf("------- 3 tmp_len=[%d]-----------\n",tmp_len);

	if(SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;
printf("------- 4 -----------\n");
	
  errexit:
   if(exitsub(reply,SQLCODE) == True)
    return SQLCODE;
   else
    return apiRC;
}

long car322_multiple_query(reply)
serverReply reply;
{
 $char DBName[5],i_fclass[2],i_icode[3],i_ncode[11];
 $char i_icar_grp[2],i_fcar_class[2];

 $char key_fclass[2],key_icode[3];

 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;

 cm_buf_get("%s %s %s",DBName,key_fclass,key_icode);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $DECLARE q_cur CURSOR FOR
    SELECT ncode, fclass, icode
    INTO $i_ncode, $i_fclass, $i_icode
    FROM car_type
    WHERE fclass matches $key_fclass AND icode matches $key_icode
    ORDER BY fclass;

 $OPEN q_cur;

 for(;;)
  {
    $FETCH q_cur;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    cm_buf_put("%s %s %s",i_fclass,i_icode,i_ncode);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s",i_fclass,i_icode,i_ncode);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

 errexit:
   if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
   else
     return apiRC;
}
