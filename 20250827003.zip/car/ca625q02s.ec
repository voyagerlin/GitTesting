/**********************************************************************/
/*   program id   : ca625q02s.ec                                      */
/*   program name : �ζ�TOBE�M�׸�Ƥ��@�~                          */
/*   date written : 2002/11/01                                        */
/*   date modify  : 2003/09/17 �[�g�P��                               */
/*   files        : ply_relation        i                             */
/*                  ply_ins_type        i                             */
/*                  policy              i                             */
/*   temp table   : car6251             io                            */
/*   Checked for ����100�~�M��                                        */
/**********************************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>

/*--------------------------------------------------------------------*/
$char   icd[2][21], iply[2][21],icard[21],ipolicy[21];
$char   ibig_sales[11],itag[CA_TAG_NUM],ibrand[9],iengine[21],ibig_office[10];
$char   nassured[121],iassured[13],dpolicy[11],iissue_ym[7];
$char   iofficer[11],iins_type[7],nofficer[11],fedr_class[2];
$char   ioff[2][11],noff[2][11],icomp[4],ncomp[9];
$char   nbrand[31],iquota[7],nquota[21],fcard_class[2];
$char   iply1[21],iply2[21],nsales[11],ipro_year[5];
$char   dbgn1[11],dend1[11],remark[2];
$char   dbgn2[11],dend2[11],dply_begin[11];
$long   mprem_dmg,mprem_11,mprem_17,mprem_oth;   
$long   mprem_11_1,mprem_17_1,mprem_oth_1;   
$long   mprem_21,mprem;
$double rSafe_dmg,rSafe_11,rSafe_17,rSafe_oth;
$double rMgmt_dmg,rMgmt_11,rMgmt_17,rMgmt_oth;
$char   napplicant[121],iapplicant[13];
$int    x,flag_11,x_cnt;
int     iins,iclass,fcomp;
$double  tmp_safe=0,tmp_manage=0;

$char   sdata[24][41],dbase[40];
$long   mprice;

int     flen,cnt;
int     cnt_s,cnt_f;
FILE    *fp;
char    sApHome[30];
$char   fname[21];
char    filename[50],fulldb[21];

$char   DBName[05], iForm_Tp[03];
char    BodyFile[ N_FILE+1];
char    TitleFile[ N_FILE+1]; 
char    outputf[N_FILE+1], userid[11];

char    msgbuf[100];
$int    ItemRow, TotColumn;
$int    StartRow,TitleRow;
$int    PgLine, Width;

static int  max_cnt,num;
/*--------------------------------------------------------------------*/
/**
main(argc, argv)
int argc;
char **argv;
**/
car6251(DBName,userid,dbgn1,dend1,checkD,outputf)
$char *DBName,*userid,*dbgn1,*dend1,*checkD,*outputf;
{  
   int rc;

   printf("dbname[%s]userid[%s]dbgn1[%s]dend1[%s]output[%s]checkD[%s]\n",
           DBName,userid,dbgn1,dend1,outputf,checkD);
/**
   strcpy(DBName, isNULLstr(argv[1]));
   strcpy(userid, isNULLstr(argv[2]));
   strcpy(dbgn2,  isNULLstr(argv[3]));
   strcpy(dend2,  isNULLstr(argv[4]));
   strcpy(outputf,isNULLstr(argv[5]));
   strcpy(dbgn1, cm_to_infdate(dbgn2));
   strcpy(dend1, cm_to_infdate(dend2));  
**/
   rc = car6251_get_db();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   rc = car6251_build();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   rc = car6251_build1();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   rc = car6251_build2();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }
   
   if (checkD[0]=='1') {
      rc = car6251_build3();
      if (rc != SUCCESS) {
         EWRITE(userid,rc,msgbuf);
         return rc;
      }
   }
   return rc;
}
/*--------------------------------------------------------------------*/
long car6251_get_db()
{
   int  rc;

   if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   rc = getApHome(sApHome);
   if (rc < 0) {
       strcpy(msgbuf,"read Config file error!!-->getApHome\n");
       EWRITE(userid,rc,msgbuf);
       return rc;
    }
    
   return SUCCESS;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car6251_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;
   
   $whenever sqlerror goto errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 625
       AND iForm_Tp="4";

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf( TitleFile,"%sA.ti",outputf);
   sprintf( BodyFile,"%sA.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car6251_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car6251_read_file();
   if (rc != SUCCESS)
      return rc;
   rgu_finish_report();

   if ((rc=save_form_info(F_BLK0, "CA", 625, userid, iForm_Tp,
        max_cnt, outputf))<0) {
        strcpy(msgbuf,"save_form_info failed");
        return rc;
   }
   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6251_build1()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;
   
   $whenever sqlerror goto errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 625
       AND iForm_Tp="5";

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf( TitleFile,"%sB.ti",outputf);
   sprintf( BodyFile,"%sB.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car6251_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car6251_body1();
   if (rc != SUCCESS)
      return rc;
   rgu_finish_report();

   if ((rc=save_form_info(F_BLK0, "CA", 625, userid, iForm_Tp,
        max_cnt, outputf))<0) {
        strcpy(msgbuf,"save_form_info failed");
        return rc;
   }
   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6251_build2()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;
   
   $whenever sqlerror goto errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 625
       AND iForm_Tp="6";

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf( TitleFile,"%sC.ti",outputf);
   sprintf( BodyFile,"%sC.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car6251_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car6251_body2();
   if (rc != SUCCESS)
      return rc;
   rgu_finish_report();

   if ((rc=save_form_info(F_BLK0, "CA", 625, userid, iForm_Tp,
        max_cnt, outputf))<0) {
        strcpy(msgbuf,"save_form_info failed");
        return rc;
   }
   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}

long car6251_build3()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;
   
   $whenever sqlerror goto errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 625
       AND iForm_Tp="5";

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf( TitleFile,"%sD.ti",outputf);
   sprintf( BodyFile,"%sD.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car6251_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car6251_body3();
   if (rc != SUCCESS)
      return rc;
   rgu_finish_report();

   if ((rc=save_form_info(F_BLK0, "CA", 625, userid, iForm_Tp,
        max_cnt, outputf))<0) {
        strcpy(msgbuf,"save_form_info failed");
        return rc;
   }
   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
car6251_title()
{
  rgu_put_head();
}
/*--------------------------------------------------------------------*/
long car6251_read_ply()
{
int    first,rc,y;
$char  stmt[1024],stmt1[512];
$char  nequipment[31];

   $whenever sqlerror goto errexit;

   $declare cur_vs cursor for
     select ipolicy,icard,iassured,itag,fcard_class,nassured
       into $ipolicy,$icard,$iassured,$itag,$fcard_class,$nassured
       from assured_vs_ply
      where iengine = $iengine;
   $open cur_vs;
   x=0;
   first=1;
   for (y=0;y<2;y++) {
       strcpy(icd[y]," ");
       strcpy(iply[y]," ");
       strcpy(ioff[y]," ");
   }
   while(1) {
      $fetch cur_vs;
      if (SQLCODE==SQLNOTFOUND) {
         if (first) {
            car6251_body();
            break;
         }
         else { 
            if (x==0)
               car6251_body();
            else {
               rc=car6251_write_data();
               if (rc!=SUCCESS)
                  return rc;
            }
            break;
         } 
      }
      printf("ipolicy[%s]\n",ipolicy);
      if (first) {
         mprem_dmg=mprem_11=mprem_17=mprem_oth=0;
         mprem_21=0;
         first=x_cnt=0;
      }  
      strcpy(fulldb,get_car_full_db(ipolicy));
      iclass=atoi(fcard_class);
      if (iclass==1) {
         sprintf(stmt,
                "select mlia_prem from %s:ply_relation \
                  where ipolicy = ? ",fulldb);
         $prepare pre_1 from $stmt;
         $execute pre_1 into $mprem_21 using $ipolicy;
      }
      else {
         mprem_11_1=mprem_17_1=mprem_oth_1=flag_11=0;
         sprintf(stmt,
                "select iquota[1,4] || '00',dpolicy,dply_begin,ibrand, \
                        to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'), \
                        iofficer,ibig_sales,fedr_class, \
                        nequipment,ibig_office, iapplicant, napplicant[1,40] \
                   from %s:ply_relation a,%s:policy b \
                  where a.ipolicy = ? \
                    and a.ipolicy = b.ipolicy ",fulldb,fulldb); 
         $prepare pre_2 from $stmt;
         $execute pre_2 into $iquota,$dpolicy,$dply_begin,$ibrand,
                        $iissue_ym,$iofficer,$ibig_sales,$fedr_class,
                        $nequipment,$ibig_office,$iapplicant,$napplicant
                  using $ipolicy;
         if (strncmp(fedr_class,"1",1)==0) continue;

         if (equip_cmp(nequipment,"11") == TRUE)
	 {
	    strcpy(remark,"1");
	 }
	 else
	 {
	    strcpy(remark,"0");
	 }

         if (x<2) {
            strcpy(iply[x],ipolicy);
            strcpy(icd[x],icard);
            strcpy(ioff[x],iofficer);
         }
         x++;
         
         /* julia */
         sprintf(stmt1,
                "select iins_type,mins_premium,safe_rate,manage_rate \
                   from %s:ply_ins_type \
                  where ipolicy = ? order by iins_type desc",fulldb);
         $prepare pre_2d from $stmt1;
         $declare cur_2d cursor for pre_2d;
         $open    cur_2d using $ipolicy;
         while(1) {
            $fetch cur_2d into $iins_type,$mprem,$tmp_safe,$tmp_manage;
            if (SQLCODE==SQLNOTFOUND) {
               if (flag_11) {
                  if (strncmp(iofficer,"W",1) != 0 ||
                      strncmp(iofficer+6,"BE",2) != 0)
                      break;
                  x_cnt++;
                  rc=car6251_write_data_1();
                  if (rc!=SUCCESS)
                     return rc;
               }
               break;
            }
            iins=atoi(iins_type);
            switch(iins) {
               case 1: case 5: case 8: case 9:
                  mprem_dmg += mprem;
                  mprem_oth_1 += mprem;
                  rSafe_dmg = tmp_safe;
                  rMgmt_dmg = tmp_manage;
                  break;
               case 11:
                  mprem_11 += mprem;
                  mprem_11_1 += mprem;
                  flag_11 = 1;
                  rSafe_11 = tmp_safe;
                  rMgmt_11 = tmp_manage;
                  break;
               case 17:
                  mprem_17 += mprem;
                  mprem_17_1 += mprem;
                  rSafe_17 = tmp_safe;
                  rMgmt_17 = tmp_manage;
                  break;
               default:
                  mprem_oth += mprem;
                  mprem_oth_1 += mprem;
                  rSafe_oth = tmp_safe;
                  rMgmt_oth = tmp_manage;
                  break;
            }
         }
         $close cur_2d;
      }
   }
   $close cur_vs;
   $free  cur_vs;
   return SUCCESS;
errexit:
   sqlfatal();
   strcpy(msgbuf,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
car6251_body()
{
    int  x;
    for(x=0;x<5;x++) {
       rgu_put_body_string(2,sdata[x],1);
    }
    rgu_put_body(2);
    max_cnt++;
}
/*--------------------------------------------------------------------*/
long car6251_body1()
{
    int i;

    rgu_put_body_string(1,"TOBE",1);
    rgu_put_body_string(1,cm_get_sysd(),1);
    rgu_put_body(1);
    max_cnt=5;

    $declare cur_s cursor for
      select iquota,icard1,icard2,ipolicy1,ipolicy2,iassured,
             nassured,iapplicant,napplicant,dpolicy,dply_begin,ibrand,iengine,iofficer1,
             iofficer2,ibig_sales,itag,mprem_dmg,mprem_11,
             mprem_17,mprem_oth,mprem_21,ply_cnt,
             rSafe_dmg,rSafe_11,rSafe_17,rSafe_oth,
             rMgmt_dmg,rMgmt_11,rMgmt_17,rMgmt_oth
        into $iquota,$icd[0],$icd[1],$iply[0],$iply[1],$iassured,
             $nassured,$iapplicant,$napplicant,$dpolicy,$dply_begin,$ibrand,$iengine,$ioff[0],
             $ioff[1],$ibig_sales,$itag,$mprem_dmg,$mprem_11,
             $mprem_17,$mprem_oth,$mprem_21,$x,
             $rSafe_dmg,$rSafe_11,$rSafe_17,$rSafe_oth,
             $rMgmt_dmg,$rMgmt_11,$rMgmt_17,$rMgmt_oth
        from car6251
       order by 1,2;
                                  
    $open cur_s;

    while(1) {
       $fetch cur_s;
       if (SQLCODE==SQLNOTFOUND) break;
            /**** �~�Z��� ***/
       $select nbranch into $nquota
          from sa_branch_type
         where ibranch = $iquota;
       if ( SQLCODE == SQLNOTFOUND )
          nquota[0]='\0';
   
            /**** �g��H����� ***/
       fcomp=0;
       for(i=0;i<2;i++) {
          if ( ioff[i][0] == ' ') {
             noff[i][0]='\0';
             continue;
          }
          $select nname into $noff[i]
             from officer
            where iofficer = $ioff[i];
          if ( SQLCODE == SQLNOTFOUND )
             noff[i][0]='\0';
          if (fcomp==0 && strncmp(ioff[i],"A",1)==0) {
             strncpy(icomp,ioff[i],3);
             $select ncode into $ncomp
                from cu_code_data
               where itype = '23'
                 and icode = $icomp;
             if ( SQLCODE == SQLNOTFOUND )
                ncomp[0]='\0';
             else
                fcomp=1;
          } 
       }

            /*** ��~�ҷ~�N��ƺ��@�� ***/
       $select nname into $nsales
          from ca_big_office
         where ibig_comp = $ibig_sales 
           and fclass='2';
       if ( SQLCODE == SQLNOTFOUND )
          nsales[0]='\0';
            
           /*** �t�P���� ***/   
       $declare cur cursor for
         select nbrand, ipro_year
           into $nbrand,$ipro_year
           from ca_car_model 
          where ibrand= $ibrand
          order by ipro_year DESC ;
       $open cur;
       $fetch cur;
       if ( SQLCODE == SQLNOTFOUND )
          nbrand[0]='\0';
       $close cur;
       $free cur;
           
       car6251_print();
    }
    $close cur_s;
    $free cur_s;
   
    return SUCCESS;

errexit:
   sqlfatal();
   strcpy(msgbuf,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car6251_body2()
{
    rgu_put_body_string(1,"TOBE",1);
    rgu_put_body_string(1,cm_get_sysd(),1);
    rgu_put_body(1);
    max_cnt=5;

    $declare cur_p cursor for
      select iquota,icard,ipolicy,iassured,
             nassured,iapplicant,napplicant,
             dpolicy,dply_begin,ibrand,iengine,iofficer,
             ibig_sales,itag,mprem_11,
             mprem_17,mprem_oth,ply_cnt,remark,
             rSafe_11,rSafe_17,rSafe_oth,
             rMgmt_11,rMgmt_17,rMgmt_oth
        into $iquota,$icard,$ipolicy,$iassured,
             $nassured,$iapplicant,$napplicant,
             $dpolicy,$dply_begin,$ibrand,$iengine,$iofficer,
             $ibig_sales,$itag,$mprem_11,
             $mprem_17,$mprem_oth,$x,$remark,
             $rSafe_11,$rSafe_17,$rSafe_oth,
             $rMgmt_11,$rMgmt_17,$rMgmt_oth
        from car6251_1
       order by 1,2;
                                  
    $open cur_p;

    while(1) {
       $fetch cur_p;
       if (SQLCODE==SQLNOTFOUND) break;
            /**** �~�Z��� ***/
       $select nbranch into $nquota
          from sa_branch_type
         where ibranch = $iquota;
       if ( SQLCODE == SQLNOTFOUND )
          nquota[0]='\0';
   
            /**** �g��H����� ***/
       $select nname into $nofficer
          from officer
         where iofficer = $iofficer;
       if ( SQLCODE == SQLNOTFOUND )
          nofficer[0]='\0';
       strncpy(icomp,iofficer,3);
       $select ncode into $ncomp
          from cu_code_data
         where itype = '23'
           and icode = $icomp;
       if ( SQLCODE == SQLNOTFOUND )
          ncomp[0]='\0';

            /*** ��~�ҷ~�N��ƺ��@�� ***/
       $select nname into $nsales
          from ca_big_office
         where ibig_comp = $ibig_sales 
           and fclass='2';
       if ( SQLCODE == SQLNOTFOUND )
          nsales[0]='\0';
            
           /*** �t�P���� ***/   
       $declare cur_1 cursor for
         select nbrand, ipro_year
           into $nbrand,$ipro_year
           from ca_car_model 
          where ibrand= $ibrand
          order by ipro_year DESC ;
       $open cur_1;
       $fetch cur_1;
       if ( SQLCODE == SQLNOTFOUND )
          nbrand[0]='\0';
       $close cur_1;
       $free cur_1;
           
       car6251_print1();
    }
    $close cur_p;
    $free cur_p;
   
    return SUCCESS;

errexit:
   sqlfatal();
   strcpy(msgbuf,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/

long car6251_body3()
{
    $char   stmt[1024], stmt1[1024];
    $char   sIpolicy[20], sIengine[20];
    int     count_db, k, first, i,y;
    DBinfo  *list;
    $char   nequipment[31];
    
    rgu_put_body_string(1,"TOBE",1);
    rgu_put_body_string(1,cm_get_sysd(),1);
    rgu_put_body(1);
    max_cnt=5;
    
    if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
    {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
    }
    
    for( k=0;k<count_db;k++)
    {
       sprintf(stmt, "SELECT a.ipolicy, b.iengine \
                        FROM %s:ply_relation a , %s:policy b\
                       WHERE a.ipolicy = b.ipolicy \
                         AND a.iofficer[1] = 'W' \
                         AND a.iofficer[7,8] = 'BE' \
                         AND a.dpolicy >= '%s' \
                         AND a.dpolicy <= '%s' \
                         AND a.fedr_class <> '1'",
                      list[k].dbname,   list[k].dbname, dbgn1, dend1 );
       
       $PREPARE cur_3a FROM $stmt;
       $DECLARE cur_3b CURSOR for cur_3a;
       $OPEN cur_3b;
       while(1)
       {
       	  $FETCH cur_3b INTO $sIpolicy, $sIengine;
       	  
       	  if( SQLCODE == SQLNOTFOUND ) break;
       	  
       	  $SELECT iengine
       	     INTO $iengine
       	     FROM CAR6251_2
       	    WHERE iengine = $sIengine;
       	  if( SQLCODE != SQLNOTFOUND ) continue;
       	  
       	  /* �H�U�s�w����ơA�ζ��L */   
       	  printf("newa have data [%s]\n", sIengine );
       	  
       	  $declare cur_vs1 cursor for
            select ipolicy,icard,iassured,itag,fcard_class,nassured
              into $ipolicy,$icard,$iassured,$itag,$fcard_class,$nassured
              from assured_vs_ply
             where iengine = $sIengine;
          $open cur_vs1;
          first=1;
          x=0;
          for (y=0;y<2;y++) {
              strcpy(icd[y]," ");
              strcpy(iply[y]," ");
              strcpy(ioff[y]," ");
          }
          while(1)
          {
              $fetch cur_vs1;
              if( SQLCODE == SQLNOTFOUND ) break;
              
              if (first) {
                 mprem_dmg=mprem_11=mprem_17=mprem_oth=0;
                 mprem_21=0;
                 first=x_cnt=0;
              }  

              iclass=atoi(fcard_class);
              if (iclass==1) {
                  sprintf(stmt,
                     "select mlia_prem from %s:ply_relation \
                       where ipolicy = ? ",list[k].dbname );
                     $prepare pre_31 from $stmt;
                     $execute pre_31 into $mprem_21 using $ipolicy;
              }
              else {

                  mprem_11_1=mprem_17_1=mprem_oth_1=flag_11=0;
                  
                  sprintf(stmt,
                     "select iquota[1,4] || '00',dpolicy,dply_begin,ibrand, \
                             to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'), \
                             iofficer,ibig_sales,fedr_class, \
                             nequipment,ibig_office,iapplicant,napplicant[1,40] \
                        from %s:ply_relation a,%s:policy b \
                       where a.ipolicy = ? \
                         and a.ipolicy = b.ipolicy ",list[k].dbname, list[k].dbname ); 

                  $prepare pre_2 from $stmt;
                  $execute pre_2 into $iquota,$dpolicy,$dply_begin,$ibrand,
                                      $iissue_ym,$iofficer,$ibig_sales,$fedr_class,
                                      $nequipment,$ibig_office,$iapplicant,$napplicant
                                using $ipolicy;
                  if (strncmp(fedr_class,"1",1)==0) continue;

                  if (equip_cmp(nequipment,"11") == TRUE)
	          {
	             strcpy(remark,"1");
	          }
	          else
	          {
	             strcpy(remark,"0");
	          }

                  if (x<2) {
                      strcpy(iply[x],ipolicy);
                      strcpy(icd[x],icard);
                      strcpy(ioff[x],iofficer);
                  }
                  x++;
                  sprintf(stmt1,
                     "select iins_type,mins_premium,safe_rate,manage_rate \
                        from %s:ply_ins_type \
                       where ipolicy = ? order by 1 desc",list[k].dbname);
                  $prepare pre_3d from $stmt1;
                  $declare cur_3d cursor for pre_3d;
                  $open    cur_3d using $ipolicy;
                  while(1) {
                      $fetch cur_3d into $iins_type,$mprem,$tmp_safe,$tmp_manage;
                      if (SQLCODE==SQLNOTFOUND) {
                          break;
                      }
                      iins=atoi(iins_type);
                      switch(iins) {
                         case 1: case 5: case 8: case 9:
                            mprem_dmg += mprem;
                            mprem_oth_1 += mprem;
                            rSafe_dmg = tmp_safe;
                            rMgmt_dmg = tmp_manage;
                            break;
                         case 11:
                            mprem_11 += mprem;
                            mprem_11_1 += mprem;
                            flag_11 = 1;
                            rSafe_11 = tmp_safe;
                            rMgmt_11 = tmp_manage;
                            break;
                         case 17:
                            mprem_17 += mprem;
                            mprem_17_1 += mprem;
                            rSafe_17 = tmp_safe;
                            rMgmt_17 = tmp_manage;
                            break;
                         default:
                            mprem_oth += mprem;
                            mprem_oth_1 += mprem;
                            rSafe_oth = tmp_safe;
                            rMgmt_oth = tmp_manage;
                            break;
                      }
                  }
                  $close cur_2d;
              }
          }
          $close cur_vs1;
          
          printf("iply[0][%s]\n", iply[0]);
          /**** �~�Z��� ***/
          $select nbranch into $nquota
             from sa_branch_type
            where ibranch = $iquota;
          if ( SQLCODE == SQLNOTFOUND )
             nquota[0]='\0';       	  
       	  
          /**** �g��H����� ***/
          $select nname into $nofficer
             from officer
            where iofficer = $iofficer;
          if ( SQLCODE == SQLNOTFOUND )
             nofficer[0]='\0';
          strncpy(icomp,iofficer,3);
          
          $select ncode into $ncomp
             from cu_code_data
            where itype = '23'
              and icode = $icomp;
          if ( SQLCODE == SQLNOTFOUND )
             ncomp[0]='\0';

          /*** ��~�ҷ~�N��ƺ��@�� ***/
          $select nname into $nsales
             from ca_big_office
            where ibig_comp = $ibig_sales 
              and fclass='2';
          if ( SQLCODE == SQLNOTFOUND )
             nsales[0]='\0';
            
          /*** �t�P���� ***/   
          $declare cur_33 cursor for
           select nbrand, ipro_year
             into $nbrand,$ipro_year
             from ca_car_model 
            where ibrand= $ibrand
            order by ipro_year DESC ;
          $open cur_33;
          $fetch cur_33;
          if ( SQLCODE == SQLNOTFOUND )
             nbrand[0]='\0';
          $close cur_33;
          $free cur_33;
          
          car6251_print();
       	  
       }
       $CLOSE cur_3b;
       $FREE  cur_3b;
       
    } /* end for loop*/
   
    return SUCCESS;

errexit:
   sqlfatal();
   strcpy(msgbuf,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/

long car6251_write_data()
{
   $whenever sqlerror goto errexit;

   $insert into car6251 values
    ($iquota,$icd[0],$iply[0],$icd[1],$iply[1],$iassured,$nassured,
     $iapplicant,$napplicant,
     $dpolicy,$dply_begin,$ibrand,$iengine,$iissue_ym,$ioff[0],
     $ioff[1],
     $ibig_sales,$itag,$mprem_dmg,$mprem_11,$mprem_17,
     $mprem_oth,$mprem_21,$x,
     $rSafe_dmg,$rSafe_11,$rSafe_17,$rSafe_oth,
     $rMgmt_dmg,$rMgmt_11,$rMgmt_17,$rMgmt_oth);

   if (x_cnt > 1)
      $update car6251_1
          set ply_cnt = $x_cnt
        where iengine = $iengine;

   return SUCCESS;
errexit:
    sqlfatal();
    strcpy(msgbuf,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6251_write_data_1()
{
   $whenever sqlerror goto errexit;

   $insert into car6251_1 values
    ($iquota,$icard,$ipolicy,$iassured,$nassured,$iapplicant,$napplicant,
     $dpolicy,$dply_begin,$ibrand,$iengine,$iissue_ym,$ibig_office,
     $ibig_sales,$itag,$mprem_11_1,$mprem_17_1,
     $mprem_oth_1,1,$remark,$rSafe_11,$rSafe_17,$rSafe_oth,$rMgmt_11,$rMgmt_17,$rMgmt_oth);

   return SUCCESS;
errexit:
    sqlfatal();
    strcpy(msgbuf,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
car6251_print()
{
  char str[20];
  char brand14[6], noff2[10];
  
  rgu_put_body_string(2,nquota,1);
  rgu_put_body_string(2,ncomp ,1);
  rgu_put_body_string(2,icd[0],1);
  rgu_put_body_string(2,iply[0],1);
  rgu_put_body_string(2,icd[1],1);
  rgu_put_body_string(2,iply[1],1);
  rgu_put_body_string(2,iassured,1);
  rgu_put_body_string(2,nassured,1);
  rgu_put_body_string(2,iapplicant,1);
  rgu_put_body_string(2,napplicant,1);
  rgu_put_body_string(2,dpolicy,1);
  rgu_put_body_string(2,dply_begin,1);
  
  strncpy(brand14, ibrand, 4 );
  brand14[4] = '\0';
  
  rgu_put_body_string(2,brand14,1);
  rgu_put_body_string(2,ibrand,1);
  rgu_put_body_string(2,nbrand,1);
  rgu_put_body_string(2,iengine,1);
  rgu_put_body_string(2,iissue_ym,1);
  
  strncpy(noff2, noff[0], 4 );
  noff2[4] = '\0';
  
  rgu_put_body_string(2,ioff[0] ,1);
  rgu_put_body_string(2,noff2   ,1);
  rgu_put_body_string(2,noff[0] ,1);
  rgu_put_body_string(2,ioff[1] ,1);
  rgu_put_body_string(2,noff[1] ,1);
  rgu_put_body_string(2,ibig_sales,1);
  rgu_put_body_string(2,nsales,1);
  rgu_put_body_string(2,itag,1);
  rfmtlong(mprem_dmg, "---------&", str);
  rgu_put_body_string(2,str,2);
  rfmtlong(mprem_11, "---------&", str);
  rgu_put_body_string(2,str,2);
  rfmtlong(mprem_17, "---------&", str);
  rgu_put_body_string(2,str,2);
  rfmtlong(mprem_oth, "---------&", str);
  rgu_put_body_string(2,str,2);
  rfmtlong(mprem_21, "---------&", str);
  rgu_put_body_string(2,str,2);
  rfmtlong(x       , "-&", str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rSafe_dmg,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2);  
  rfmtdouble(rSafe_11,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rSafe_17,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rSafe_oth,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rMgmt_dmg,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2);  
  rfmtdouble(rMgmt_11,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rMgmt_17,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rMgmt_oth,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2);
  
  rgu_put_body(2);
  max_cnt++;
}   
/*--------------------------------------------------------------------*/
car6251_print1()
{
  char str[20];
  char brand14[6], noff2[10];
  
  rgu_put_body_string(2,nquota,1);
  rgu_put_body_string(2,ncomp ,1);
  rgu_put_body_string(2,icard,1);
  rgu_put_body_string(2,ipolicy,1);
  rgu_put_body_string(2,iassured,1);
  rgu_put_body_string(2,nassured,1);
  rgu_put_body_string(2,iapplicant,1);
  rgu_put_body_string(2,napplicant,1);
  rgu_put_body_string(2,dpolicy,1);
  rgu_put_body_string(2,dply_begin,1);
  
  strncpy(brand14, ibrand, 4 );
  brand14[4] = '\0';
  
  rgu_put_body_string(2,brand14,1);
  rgu_put_body_string(2,ibrand,1);
  rgu_put_body_string(2,nbrand,1);
  rgu_put_body_string(2,iengine,1);
  rgu_put_body_string(2,iissue_ym,1);

  strncpy(noff2, nofficer, 4 );
  noff2[4] = '\0';

  rgu_put_body_string(2,iofficer,1);
  rgu_put_body_string(2,noff2   ,1);  
  rgu_put_body_string(2,nofficer,1);
  rgu_put_body_string(2,ibig_sales,1);
  rgu_put_body_string(2,nsales,1);
  rgu_put_body_string(2,itag,1);
  rfmtlong(mprem_11, "---------&", str);
  rgu_put_body_string(2,str,2);
  rfmtlong(mprem_17, "---------&", str);
  rgu_put_body_string(2,str,2);
  rfmtlong(mprem_oth, "---------&", str);
  rgu_put_body_string(2,str,2);
  rgu_put_body_string(2,remark,1);
  rfmtlong(x       , "-&", str);
  rgu_put_body_string(2,str,2);
  
  rfmtdouble(rSafe_dmg,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2);  
  rfmtdouble(rSafe_11,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rSafe_17,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rSafe_oth,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rMgmt_dmg,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2);  
  rfmtdouble(rMgmt_11,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rMgmt_17,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2);
  rfmtdouble(rMgmt_oth,"-&&.&&&&&&&",str);
  rgu_put_body_string(2,str,2);
  
  rgu_put_body(2);
  max_cnt++;
}   
/*--------------------------------------------------------------------*/
long car6251_read_file()
{
    char   *bp;
    int    rc,i,j,k,m,n;

    $whenever sqlerror goto errexit;

    rc=car6251_create_temp();
    if (rc != SUCCESS)
        return rc;

    sprintf(filename,"%s/dat/car/car625.txt",sApHome);
    flen=1024;
    if ((fp=fopen(filename,"r"))==NULL) {
       sprintf(msgbuf,"%s �ɮ׶}�ҥ���",filename);
       return FALSE;
    }
    if ((bp=malloc(flen))==NULL) {
       sprintf(msgbuf,"System malloc failed !");
       return FALSE;
    }

    rgu_put_body_string(1,"TOBE",1);
    rgu_put_body_string(1,cm_get_sysd(),1);
    rgu_put_body(1);
    max_cnt=5;

    for (i=0;(feof(fp)==0);i++) {
        memset(bp,0x00,flen);
        fgets(bp,flen,fp);
        if (bp[0]==0x00)
           break;
        for(j=0;j<5;j++)
           memset(sdata[j],0x00,41);
        k=m=n=0;
        for (j=0;j<flen;j++) {
            if (bp[j]=='\t' || bp[j]=='\0' || bp[j]=='\n') {
                strncpy(sdata[k],bp+m,j-m);
                sdata[k][j-m]='\0';
                m=j+1;
                k++;
            }
            if (bp[j]=='\n')
                break;
            if (k > 4) break;
        }      
        if (sdata[0][0]=='\0') continue;
        rtrim_alldata1();
        
        printf("iengine[%s]\n",iengine);
        
        $insert into car6251_2 values ( $iengine );
        
        rc=car6251_read_ply();
        if (rc!=SUCCESS)
           return rc;
    }

    return SUCCESS;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6251_create_temp()
{
    $whenever sqlerror goto errexit;
      
    $create temp table car6251
     (iquota         char(6),
      icard1         char(20),
      ipolicy1       char(20),
      icard2         char(20),
      ipolicy2       char(20),
      iassured       char(12),
      nassured       char(40),
      iapplicant     char(12),
      napplicant     char(40),
      dpolicy        date,
      dply_begin     date,
      ibrand         char(8),
      iengine        char(20),
      iissue_ym      char(6),
      iofficer1      char(10),
      iofficer2      char(10),
      ibig_sales     char(10),
      itag           char(12),
      mprem_dmg      integer,
      mprem_11       integer, 
      mprem_17       integer,
      mprem_oth      integer,
      mprem_21       integer,
      ply_cnt        integer,
      rSafe_dmg      decimal(9,7),      
      rSafe_11       decimal(9,7),
      rSafe_17       decimal(9,7),      
      rSafe_oth      decimal(9,7),
      rMgmt_dmg      decimal(9,7),      
      rMgmt_11       decimal(9,7),
      rMgmt_17       decimal(9,7),     
      rMgmt_oth      decimal(9,7)) 
     with no log;

    $create temp table car6251_1
     (iquota         char(6),
      icard          char(20),
      ipolicy        char(20),
      iassured       char(12),
      nassured       char(40),
      dpolicy        date,
      dply_begin     date,
      ibrand         char(8),
      iengine        char(20),
      iissue_ym      char(6),
      iofficer       char(10),
      ibig_sales     char(10),
      itag           char(12),
      mprem_11       integer, 
      mprem_17       integer,
      mprem_oth      integer,
      ply_cnt        integer,
      remark         char(1),
      rSafe_11       decimal(9,7),
      rSafe_17       decimal(9,7),
      rSafe_oth      decimal(9,7),
      rMgmt_11       decimal(9,7),
      rMgmt_17       decimal(9,7),
      rMgmt_oth      decimal(9,7)) 
     with no log;

    $create temp table car6251_2
     (
       iengine        char(20)
     ) 
     with no log;
     
    return SUCCESS;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
rtrim_alldata1()
{
    int  x;
    for(x=0;x<5;x++)
       strcpy(sdata[x],rtrim(sdata[x]));
    strcpy(iengine,sdata[1]);
}
/*--------------------------------------------------------------------*/
