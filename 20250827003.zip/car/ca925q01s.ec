/************************************************/
/*   PROGRAM : ca925q01s.ec                     */
/*   DATE    : 110.03.16                        */
/*   NOTE    : �����r�p�H�ߴڸ���ɮ��s����     */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
$include datetime.h;
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"


$char DBName[05], outputf[N_FILE+1];
$char  userid[11];
DBinfo  *list;
int     count_db;
int   icnt, irpt;
char  chkrpt[6];

$char sFcard_class[2], sIclaim_type[2], sRpt_name[31], sRpt_Type[2];
$char sBgnDate_e[11], sEndDate_e[11], sBgnDate[11], sEndDate[11] ;
$long lBgnDate, lEndDate;

$char nfile[5][200];
$char sTpSQL[5][1000];

long car925_build();
void car925_title();
long car925_body();
long car925_print();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;

    batchinit();
    strcpy(DBName   ,  isNULLstr(argv[1]));
    strcpy(userid   ,  isNULLstr(argv[2]));
    strcpy(sFcard_class , isNULLstr(argv[3]));	/* 1:�j�� 2:���N 3:�j+�� */
    strcpy(sIclaim_type ,   isNULLstr(argv[4]));		/* 1:�w�鵲 2:���M 3:���� */
    strcpy(sBgnDate ,  isNULLstr(argv[5]));		/* �έp�_�� cyy/mm/dd */
    strcpy(sEndDate ,  isNULLstr(argv[6]));  	/* �έp���� cyy/mm/dd */
    strcpy(outputf  ,  isNULLstr(argv[7]));

    strcpy(sBgnDate_e, cm_to_infdate(sBgnDate));
    strcpy(sEndDate_e, cm_to_infdate(sEndDate));
    rstrdate(sBgnDate_e, &lBgnDate);
    rstrdate(sEndDate_e, &lEndDate);



    rc=car925_get_db();
    if (rc!=M_CM_OK)
        return rc;

    rc = car925_build();
    if (rc != M_CM_OK)
        return rc;

    return M_CM_OK;

errexit:
    printf("main :SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

/*--------------------------------------------------------------------*/

long car925_build()
{
    int    rc;

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

		printf("87:sFcard_class=[%s]sIclaim_type=[%s]\n",sFcard_class,sIclaim_type );

		icnt = 0;	/* �����i�� */
		strcpy(chkrpt,"00000");
		if((strcmp(sFcard_class,"1") == 0)||(strcmp(sFcard_class,"3") == 0))
		{
				if((strcmp(sIclaim_type,"1") == 0)||(strcmp(sIclaim_type,"3") == 0))
				{
						icnt++;
						chkrpt[1] = '1';

						rc = car925_1A();		/* �j���I-�w���� */
    				if (rc != M_CM_OK)
        				return rc;
				}

				if((strcmp(sIclaim_type,"2") == 0)||(strcmp(sIclaim_type,"3") == 0))
				{
						icnt++;
						chkrpt[2] = '1';

						rc = car925_1B();		/* �j���I-���M */
    				if (rc != M_CM_OK)
        				return rc;
				}
		}

    if((strcmp(sFcard_class,"2") == 0)||(strcmp(sFcard_class,"3") == 0))
		{
				if((strcmp(sIclaim_type,"1") == 0)||(strcmp(sIclaim_type,"3") == 0))
				{
						icnt++;
						chkrpt[3] = '1';

						rc = car925_2A();		/* ���N�I-�w���� */
    				if (rc != M_CM_OK)
        				return rc;
				}

				if((strcmp(sIclaim_type,"2") == 0)||(strcmp(sIclaim_type,"3") == 0))
				{
						icnt++;
						chkrpt[4] = '1';

						rc = car925_2B();		/* ���N�I-���M */
    				if (rc != M_CM_OK)
        			return rc;

				}
		}

		rc = car925_print();
		if (rc != M_CM_OK)
 					return rc;

   return M_CM_OK;

errexit:
   EWRITE(userid,rc,sqlca.sqlerrm);
   return SQLCODE;
}

/* -------------------------------------------------------------------------- */
long car925_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

	 $create temp table ca925_tb1
	 (
	 		fcard_class		char(1),		-- �j��/���N
	 		iclaim_type		char(1),		-- ���קO		-- 1:�w�鵲 2:���M
	 		iclaim				char(20), 	-- �߮׸�
	 		fstl            char(1),         -- �߰l�O
	 		iclose_type     char(4),         --�߰l����
	 		daccident			date,				-- �X�I��
	 		dclaim				date,				-- ���z��
	 		dclose				date,				-- �鵲��
	 		dgroup				date,				-- �J�p��
	 		nbranch				char(30),		-- �z�߬�O
	 		nadjust				char(10),		-- �z�ߤH��
	 		idriver				char(10),		-- �����r�pID
	 		fnation				char(1),		-- ����/�~��H
	 		year_bth			int,				-- �O�r�X�ͦ~
	 		iage					int					-- �O�r�~�� (�O�r�ͤ�~-�X�I��~)
	 ) with no log;

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/* ------------------------------------------------------------------------ */
/* �j���I-�߮� */
long car925_1A()
{
    long rc;
    int k;

    $char stmt[6000], sTmpSQL1[100], sTmpSQL2[100];

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

	  for (k=0;k<count_db;k++)
    {
    	sprintf_s(stmt,6000,
    			"insert into ca925_tb1 "
			    "SELECT a.fcard_class, '1', trim(a.iclaim), a.fstl, a.iclose_type, "
			    "       date(b.daccident), date(b.dclaim), a.dclose, a.dgroup, "
			    "			  (select nbranch from sysdb:sa_branch_type where ibranch = "
				  "          case when nvl(b.affiliated,' ') = ' ' then "
				  "                (select iquota from officer where iofficer = b.adjustment) "
				  "         else b.affiliated  end ),  "
			    "       (select nname from sysdb:officer where iofficer = b.adjustment), "
			    "       c.iacc_license, c.facc_nation, year(c.dacc_birth), "
	        "       year(c.daccident)-year(c.dacc_birth) "
		      "  FROM %s:settlement a, sysdb:ca_clm_process b, %s:appraisal c "
		      " WHERE a.iclaim = b.iclaim     AND a.iclaim = c.iclaim "
		      "   AND a.fcard_class = '1' "
		      "   AND a.dgroup >= %d  	      AND a.dgroup < %d "
		      "   AND (a.msettle != 0 OR "
		      "       (SELECT NVL(SUM(mins_proc),0) "
		      "          FROM %s:ca_stl_victim "
		      "         WHERE iclaim=a.iclaim "
		      "           AND fstl=a.fstl  "
		      "           AND iclose_type=a.iclose_type) != 0) "
		      "   AND a.dgroup IS NOT NULL "
		      " ORDER BY 3 ",
		  list[k].dbname, list[k].dbname, lBgnDate, lEndDate, list[k].dbname);

			printf("car9251A_p1=[%s]\n",stmt);
		  $PREPARE car9251A_p1 FROM $stmt;
      $EXECUTE car9251A_p1 ;
		}

    return M_CM_OK;

errexit:
   printf("car925_1B ==> SQLCODE:[%ld][%s] \n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   printf("   end EWRITE \n");
   return SQLCODE;
}

/* ------------------------------------------------------------------------ */
/* �j���I-���M */
long car925_1B()
{
    long rc;
    int k;

    $char stmt[6000], sTmpSQL1[100], sTmpSQL2[100];

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;


		for (k=0;k<count_db;k++)
    {
			sprintf_s(stmt,6000,
				"insert into ca925_tb1 "
				"SELECT b.fcard_class, '2', b.iclaim, ' ', ' ', date(b.daccident), date(b.dclaim), '', '', "
				"			  (select nbranch from sysdb:sa_branch_type where ibranch = "
				"          case when nvl(c.affiliated,' ') = ' ' then "
				"                (select iquota from officer where iofficer = c.adjustment) "
				"         else c.affiliated  end ),  "
        "       (select nname from sysdb:officer where iofficer = c.adjustment), "
        "       b.iacc_license, b.facc_nation, year(b.dacc_birth), "
        "       year(b.daccident)-year(b.dacc_birth) "
        "  FROM %s:ca_app_victim_hist a INNER JOIN %s:appraisal b ON a.iclaim = b.iclaim "
        "                               INNER JOIN sysdb:ca_clm_process c on b.iclaim = c.iclaim "
        " WHERE a.dappraisal < %d "
        "   AND a.dappraisal = "
        "       (select max(dappraisal)  from %s:ca_app_victim_hist "
        "         where a.iclaim = iclaim    and a.iins_item = iins_item "
        "           and a.ivictim = ivictim  and dappraisal < %d ) "
        "   AND not exists "
        "       (select * from %s:ca_stl_victim x "
        "         where a.iclaim    = x.iclaim     and a.ivictim   = x.ivictim "
        "           and a.iins_item = x.iins_item  and x.dgroup < %d "
        "           and ((x.iins_item[1] =  'A' and flast = '2') or "
        "                (x.iins_item[1] <> 'A' and flast in('1','2')) or "
        "                (x.iins_item[1] =  'A' and exists "
        "                   (select max(flast), sum(decode(fstl,'1',mins_stl+mins_proc,(-1)*mins_stl+mins_proc)) "
        "                      from %s:ca_stl_victim z "
        "                     where z.iclaim = x.iclaim    and z.iins_item = x.iins_item "
				" 											and z.ivictim = x.ivictim  and z.dgroup < %d "
        "                    having max(flast) in('1','2') "
        "                       and sum(decode(fstl,'1',mins_stl+mins_proc,(-1)*mins_stl+mins_proc)) = 0 )))) "
	      " group by 1,3,4,5,6,7,8,9,10,11,12,13,14,15 ",
	      list[k].dbname, list[k].dbname, lEndDate, list[k].dbname, lEndDate,
	      list[k].dbname, lEndDate, list[k].dbname, lEndDate);

				printf("car9251B_p1=[%s]\n",stmt);

		    $PREPARE car9251B_p1 FROM $stmt;
        $EXECUTE car9251B_p1 ;
		}

    return M_CM_OK;

errexit:
   printf("car925_1A ==> SQLCODE:[%ld][%s] \n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   printf("   end EWRITE \n");
   return SQLCODE;
}

/* ------------------------------------------------------------------------ */
/* ���N�I-�߮� */
long car925_2A()
{
    long rc;
    int k;

    $char stmt[6000], sTmpSQL1[100], sTmpSQL2[100];

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

	  for (k=0;k<count_db;k++)
    {
			sprintf_s(stmt,6000,
    			"insert into ca925_tb1 "
			    "SELECT distinct c.fcard_class, '1', trim(a.iclaim), a.fstl, a.iclose_type, "
			    "       date(b.daccident), date(b.dclaim), a.dclose, a.dgroup, "
			    "			  (select nbranch from sysdb:sa_branch_type where ibranch = "
				  "          case when nvl(b.affiliated,' ') = ' ' then "
				  "                (select iquota from officer where iofficer = b.adjustment) "
				  "         else b.affiliated  end ),  "
			    "       (select nname from sysdb:officer where iofficer = b.adjustment), "
			    "       c.iacc_license, c.facc_nation, year(c.dacc_birth), "
	        "       year(c.daccident)-year(c.dacc_birth) "
		      "  FROM %s:stl_ins_type a, sysdb:ca_clm_process b, %s:appraisal c "
		      " WHERE a.iclaim = b.iclaim      AND a.iclaim = c.iclaim "
		      "   AND b.iclaim = c.iclaim       "
		      "   AND a.dgroup >= %d AND a.dgroup < %d  "
		      " ORDER BY 3 ", list[k].dbname, list[k].dbname,lBgnDate, lEndDate);

			printf("car9252A_p1=[%s]\n",stmt);

			$PREPARE car9252A_p1 FROM $stmt;
      $EXECUTE car9252A_p1 ;
		}

    return M_CM_OK;

errexit:
   printf("car925_1B ==> SQLCODE:[%ld][%s] \n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   printf("   end EWRITE \n");
   return SQLCODE;
}

/* ------------------------------------------------------------------------ */
/* ���N�I-���M */
long car925_2B()
{
    long rc;
    int k;

    $char stmt[6000], sTmpSQL1[100], sTmpSQL2[100];

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

	  for (k=0;k<count_db;k++)
    {
			sprintf_s(stmt,6000,
    		"insert into ca925_tb1 "
				"SELECT distinct a.fcard_class, '2', a.iclaim, ' ', ' ', date(a.daccident), "
				"       date(a.dclaim), '', '', "
				"			 (select nbranch from sysdb:sa_branch_type where ibranch = "
				"         case when nvl(c.affiliated,' ') = ' ' then "
				"              (select iquota from officer where iofficer = c.adjustment) "
				"         else c.affiliated  end ),  "
			  "       (select nname from sysdb:officer where iofficer = c.adjustment), "
			  "       a.iacc_license, a.facc_nation, year(a.dacc_birth), "
	      "       year(a.daccident)-year(a.dacc_birth) "
	      "  FROM %s:appraisal a , %s:app_ins_type_hist b, sysdb:ca_clm_process c "
	      " WHERE a.iclaim = b.iclaim and a.iclaim = c.iclaim "
	      "   AND DATE(a.daccident) < %d  "
	      "   AND date(b.dappraisal) < %d "
	      "   AND b.dappraisal = (select max(dappraisal) "
        "                         from %s:app_ins_type_hist "
        "                        where b.iclaim = iclaim "
        "                          and b.iins_type = iins_type "
        "                          and b.dappraisal < %ld) "
        "   AND not exists (select * from %s:stl_ins_type x  "
        "                    where b.iclaim    = x.iclaim  "
        "                      and b.iins_type = x.iins_type  "
        "                      and x.dgroup < %ld  and (flast = '1'))  "
        " ORDER BY a.iclaim",
	      list[k].dbname, list[k].dbname, lEndDate, lEndDate, list[k].dbname,
	      lEndDate, list[k].dbname,lEndDate );

			printf("car9252A_p2=[%s]\n",stmt);

			$PREPARE car9252A_p2 FROM $stmt;
      $EXECUTE car9252A_p2 ;
		}

    return M_CM_OK;

errexit:
   printf("car925_1B ==> SQLCODE:[%ld][%s] \n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   printf("   end EWRITE \n");
   return SQLCODE;
}

/* ------------------------------------------------------------------------- */
long car925_print()
{
   $char sfilename[200];
   $char stitle[1000];
   $char sTpSQL1[1000], sTpSQL2[1000];

   $char sErrmsg[100];
   $int  rc, irpt, i;

   $WHENEVER ERROR goto errexit;
   $SET LOCK MODE TO WAIT;

	 strcpy(stitle, "�߮׸�\t��/�l\t�߰l����\t�X�I��\t���z��\t�鵲��\t�J�p��\t�z�߬�O\t");
   strcat(stitle, "�z�ߤH��\t�����r�pID\t��/�~��H\t�X�ͦ~��\t�~��\t");
	 sprintf_s(sTpSQL1,1000, "select iclaim, fstl, iclose_type, daccident, dclaim, dclose, dgroup, nbranch, nadjust, idriver, "
	               "decode(fnation,'1','1:����H','2','2:�~��H','7','7:�~��HID���~','8','8:����HID���~',fnation), "
	               "year_bth, iage ");

	 irpt = 64;

	printf("icnt=[%d]\n",icnt);
		for (i=1; i<= 4; i++)
		{
			if(	chkrpt[i] == '1')
			{
				switch(i)
				{
					case 1:
						strcpy(sfilename,"�j���I-�w�鵲�߮�");
        		sprintf_s(sTpSQL2,1000, "%s from ca925_tb1 where fcard_class = '1' and iclaim_type = '1'", sTpSQL1);
        		break;

					case 2:
	 					strcpy(sfilename,"�j���I-���M�߮�");
	 					sprintf_s(sTpSQL2,1000, "%s from ca925_tb1 where fcard_class = '1' and iclaim_type = '2' ", sTpSQL1);
        		break;

					case 3:
      			strcpy(sfilename,"���N�I-�w�鵲�߮�");
      			sprintf_s(sTpSQL2,1000, "%s from ca925_tb1 where fcard_class = '2' and iclaim_type = '1' ", sTpSQL1);
        		break;

					case 4:
 	 					strcpy(sfilename,"���N�I-���M�߮�");
 	 					sprintf_s(sTpSQL2,1000, "%s from ca925_tb1 where fcard_class = '2' and iclaim_type = '2' ", sTpSQL1);
        		break;
        }

        if (icnt == 1)
				{
					strcpy(sRpt_Type, " ");
				}
				else
				{
					irpt= irpt++;
					sRpt_Type[0] = (char)irpt ;
				}
				printf("i=[%d]  sRpt_Type=[%s]\n",i,sRpt_Type);
				printf("sfilename=[%s]\n",sfilename);
				printf("sTpSQL2=[%s]\n",sTpSQL2);

        rc = unload_file(outputf, sRpt_Type, sfilename, stitle, sTpSQL2);
			  if (rc != SUCCESS)
			  {
			       if (rc == 3501)
			       {
			          sprintf_s(sErrmsg,100," %s ��J���^������䤣���� ",sfilename);
			       }
			       else
			       {
			          sprintf_s(sErrmsg,100," %s �ɮ׵L�k���� ",sfilename);
			       }

			       EWRITE(userid, rc , sErrmsg);
			   }
			}
		}

   return M_CM_OK;

errexit:
  printf("SQL=[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(1);

}
