/**********************************************************************/
/*   program id   : ca740p04s.ec                                      */
/*   program name : ���M�������(�߮פU�ڸ��)                        */
/*   date written : 2020/04/15 by sylvia                               */
/*   files        :                                                    */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"


char  outputf[21];
char dbgn[11],dend[11], opt[3], ftype[2];
$char userid[11], sdate1[11], sdate2[11], sYYMM[9];
$char DBName[05];
$char msgbuf[128], msg1[500], msg2[50000];
char   sApHome[50];

int rc, isql2;

main(argc, argv)
int argc;
char **argv;
{

	batchinit();
	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(opt,            isNULLstr(argv[3]));     /* A:�U�ڸ�Ƨ�s B:�U�ڸ�Ƴ��� */
	strcpy(dbgn,           isNULLstr(argv[4]));
	strcpy(dend,           isNULLstr(argv[5]));
	strcpy(outputf,        isNULLstr(argv[6]));

	strcpy(sdate1,cm_to_infdate(dbgn));
	strcpy(sdate2,cm_to_infdate(dend));
	printf("sdate1=[%s]sdate2=[%s]\n",sdate1,sdate2);
	msg1[0]='\0';
	msg2[0]='\0';

	rc=car7404_get_db();
    if ( rc != M_CM_OK) return rc;


	$select to_char(date($sdate1),'%Y%m%d') into $sYYMM
	   from systables where tabid = 1;

    printf("car7404:sdate1=[%s]sdate2=[%s]sYYMM=[%s]\n",sdate1,sdate2,sYYMM);

	/* �d�ߤΧ�s��� */

    if (opt[0] == 'A')
    {
    	$BEGIN WORK;

    	rc = car7404_UpdPayData();
    	if (rc != M_CM_OK)
    		return rc;

    	$INSERT INTO sysdb:ca_rioho_log
            (fsend_type,iyyyymm,dcreate) values ('4',$sYYMM,current);

      $COMMIT WORK;

      sprintf(msg2,"  %s �����U�ڸ�Ʀp�U,���ѰѦ�!! \n\n",sYYMM);

        /* �N���G�C�ܦbcmn201 */
    	rc = car7404_Report();
    	if (rc != M_CM_OK)
    		return rc;


        printf("---------msg2=[%s]\n  ",msg2);
        EWRITE(userid,M_CM_OK,msg2);
    }
    else
    {
        rc = car7404_prepare_data();
        if (rc != M_CM_OK) {
            printf("error on car7405_prepare_data\n");
            return rc;
        }

    	rc = car7404_build();
    	if (rc != M_CM_OK)
    		return rc;
    }

}


/*--------------------------------------------------------------------*/
long car7404_get_db()
{
    int rc;
    $whenever sqlerror goto errexit;

    if (db_select(DBName) == FALSE)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }

    rc = getApHome(sApHome);
    if (rc < 0)
    {
        EWRITE(userid, M_CM_READ_CONFIG_ERR, "read Config file error!!");
        return FAIL;
    }

    /* ��Temp Table */
   	$create temp table car7404m
    (
        dtransdate		date		, 	-- ������ɤ�� (MM/dd/yyyy)
        iinsurcomp		char(2)		, 	-- �O�I���q�N��
        isendqty		int			, 	-- �ǰe��Ƶ���(���M-->�s�w)
        dsenddate		char(14)	,	-- ���M�ǰe���(yyyyMMddhhmmss)
        dreturndate		char(14)	    -- �s�w�^�Ǥ��(yyyyMMddhhmmss)
    )with no log;

    $create temp table car7404d
    (
        dtransdate		date		, 		-- ������ɤ�� (MM/dd/yyyy)
        isignno			varchar(20)	,	 	-- ñ�{�渹
        idlrid			char(8)		, 		-- �g�P�ӪA�ȼt�νs
        icaseno			char(20)	, 		-- �z�߮׸�
        ncustname		varchar(200),	    -- ���D�m�W
        ilicno			char(10)	, 		-- �P�Ӹ��X
        iinvono			char(10)	, 		-- �o�����X
        dinvodate		char(8)		, 		-- �o�����
        iinvoamt		int			, 		-- �o�����B
        irecamt			int	, 				-- �z�ߪ��B(�O�I���q�U�ڪ��B)
        drecdate		char(8)	,		    -- �U�ڤ��(yyyyMMdd)
        irecnum			char(3)	,		    -- �U�ڦ���
        fstatusno 	    char(2)	,			-- �U�ڪ��A(���~�N��)
        nerrmsg 		varchar(50)	,		-- ���~��](�s�w�Ƶ�����)
        dupdate			datetime year to second,		-- ��Ʋ��ʮɶ�
        row_guid        int                 -- �Ǹ�
    )with no log;

    return M_CM_OK;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* -------------------------------------------------------------------------- */
long car7404_UpdPayData()
{

	$char sTmp1[5000], sIclaim[21], sIfpce_id[11], sIsign[21], sDclose[11],
	      sDgroup[11], sItag[13], sIfpce_id2[11], sDinvodate[11], sIdlrid[9],
	      sTmpMsg[51];

	$int  iMpayment, iDclose, iDgroup, iDinvodate, iInvoamt, irow_guid;

	$WHENEVER SQLERROR GOTO errexit;

	/* step1.�ˮ֬O�_�����M�߮�,���O����,�����^���U�ڪ��A=03 */
	/* �קﭭ�����:�������M�O�檺�߮�, ���ˮ֬O�_���s�w�߮� modify by sylvia 109.12.21 (1091203001_SC1) */
	$Update sysdb:ca_rioho_pay_dtl
      Set fstatusno = '03',
          nerrmsg = '�z�߮׸�����_�D�s�w�߮�',
	        dupdate = current
    where dtransdate = today
      and upper(icaseno) not in
      		(select iclaim from ca_clm_process WHERE dclaim >= add_months(today,-36)) ;


	/* step2.�H�e�߮׸�+�g�P�ӪA�ȼt�νs+�P�Ӹ��X�f��� */
	/* step2.�վ�H�e�߮׸�+�P�Ӹ��X�f��� modify by sylvia 110.01.18 (1100114006_SC1) */
	iDclose = iDgroup = iDinvodate = 0;
	sprintf(sTmp1,
	"select unique a.iclaim, a.ifpce_id, a.isign, a.mpayment, \
	        nvl(to_char(a.dclose, '%%Y%%0m%%0d'),0) as dclose, \
	        nvl(to_char(b.dgroup, '%%Y%%0m%%0d'),0) as dgroup, \
	        d.itag, g.dinvodate, g.iinvoamt, g.row_guid, g.idlrid \
       from ca_sign_receipt a, ca_pro_ins c, ca_property d, \
            sysdb:ca_rioho_pay_dtl g, outer ao_stl_close b \
      where a.iclaim = b.iclose       and a.iclaim = c.iclaim \
        and a.isign = c.isign         and c.iverify = d.iverify \
        and c.ipro_no = d.ipro_no     and a.iclose_type = b.iclose_type \
        and b.fstl = '1'              and a.iclaim = upper(g.icaseNo) \
        and d.itag = upper(g.ilicno)         and g.dtransdate =  '%s' \
        and g.fstatusno = ' '  ", sdate1);
	$PREPARE pre_cur1 FROM $sTmp1;
	printf("216:sTmp1=[%s]\n",sTmp1);
	$DECLARE cur1 CURSOR FOR pre_cur1;
	$OPEN	cur1;
    while(1)
    {
    		iDclose = iDgroup = iDinvodate = 0;
        $FETCH cur1 INTO $sIclaim, $sIfpce_id, $sIsign, $iMpayment,
                         $sDclose, $sDgroup,
                         $sItag, $sDinvodate, $iInvoamt, $irow_guid, $sIdlrid;
        if (SQLCODE == SQLNOTFOUND) break;

        iDclose = atoi(sDclose);    /* �鵲�� */
        iDgroup = atoi(sDgroup);    /* �J�p�� */
        iDinvodate = atoi(sDinvodate);  /* �o���� */

        printf("227:iDclose=[%d]iDgroup=[%d]iDinvodate=[%d]irow_guid=[%d]\n",
                iDclose,iDgroup,iDinvodate,irow_guid);


        /* (1)�鵲�� < �o���� */
        if (iDclose == 0)
        {
            printf("230:iDclose=[%d]iDgroup=[%d]iDinvodate=[%d]irow_guid=[%d]\n",iDclose,iDgroup,iDinvodate,irow_guid);
                sprintf(sTmpMsg, "�d�L���--�鵲��[%d] < �o����[%d]",iDclose,iDinvodate);
                $Update sysdb:ca_rioho_pay_dtl
                    Set fstatusno = '06',
                    nerrmsg = '���U��-�߮�ñ�֤�, �|���鵲',
                    dupdate = current
                  where dtransdate = $sdate1
                    and upper(icaseNo) = $sIclaim
                    and idlrid = $sIdlrid
                    and upper(ilicno) = $sItag
                    and row_guid = $irow_guid
                    and fstatusno =  ' ';
             continue;
        }

        if ((iDclose > 0) && (iDclose < iDinvodate))
        {
            printf("230:iDclose=[%d]iDgroup=[%d]iDinvodate=[%d]irow_guid=[%d]\n",iDclose,iDgroup,iDinvodate,irow_guid);
                sprintf(sTmpMsg, "�d�L���--�鵲��[%d] < �o����[%d]",iDclose,iDinvodate);
                $Update sysdb:ca_rioho_pay_dtl
                    Set fstatusno = ' ',
                        nerrmsg = $sTmpMsg,
                        dupdate = current
                  where dtransdate = $sdate1
                    and upper(icaseNo) = $sIclaim
                    and idlrid = $sIdlrid
                    and upper(ilicno) = $sItag
                    and row_guid = $irow_guid
                    and fstatusno =  ' ';
             continue;
        }
        printf("235:iDclose=[%d]iDgroup=[%d]iDinvodate=[%d]irow_guid=[%d]\n",iDclose,iDgroup,iDinvodate,irow_guid);

        /* (2)���J�p�� */
        if (iDgroup > 0)
        {
            /* �z�ߪ��B=�o�����B�^���i�U�ڪ��A=01�j */
            if (iMpayment == iInvoamt)
            {
                printf("238:iDclose=[%d]iDgroup=[%d]irow_guid=[%d]\n",iDclose,iDgroup,irow_guid);
                $Update sysdb:ca_rioho_pay_dtl
                    Set irecamt  = $iMpayment,
                        drecdate = $sDgroup,
                        irecnum = '1',
                        fstatusno = '01',
                        nerrmsg = '�U�ڧ���',
                        dupdate = current
                  where dtransdate = $sdate1
                    and upper(icaseNo) = $sIclaim
                    and idlrid = $sIdlrid
                    and upper(ilicno) = $sItag
                    and row_guid = $irow_guid
                    and fstatusno =  ' ';
                printf("257:iDclose=[%d]iDgroup=[%d]irow_guid=[%d]\n",iDclose,iDgroup,irow_guid);
                continue;
            }
            else
            {
                printf("255:iDclose=[%d]iDgroup=[%d]irow_guid=[%d]\n",iDclose,iDgroup,irow_guid);
                /* �z�ߪ��B<>�o�����B�^���i�U�ڪ��A=05�j */
                sprintf(sTmpMsg, "�z�ߪ��B[%d]�P�o�����B[%d]����",iMpayment,iInvoamt);
                $Update sysdb:ca_rioho_pay_dtl
                    Set fstatusno = '05',
                        nerrmsg = $sTmpMsg,
                        dupdate = current
                  where dtransdate = $sdate1
                    and upper(icaseNo) = $sIclaim
                    and idlrid = $sIdlrid
                    and upper(ilicno) = $sItag
                    and row_guid = $irow_guid
                    and fstatusno =  ' ';
                continue;
            }
        }
        else
        {
            /* (3)�L�J�p��,���ܤw�鵲���J�p�C�G�u��s�i�s�w�Ƶ������j */
            /* �אּ�i06���U�ڡj modify by sylvia 109.06.02 */
            printf("272:iDclose=[%d]iDgroup=[%d]irow_guid=[%d]\n",iDclose,iDgroup,irow_guid);
            $Update sysdb:ca_rioho_pay_dtl
                Set fstatusno = '06',
                    nerrmsg = '���U��-�w�鵲���J�p',
                    dupdate = current
              where dtransdate = $sdate1
                and upper(icaseNo) = $sIclaim
                and idlrid = $sIdlrid
                and upper(ilicno) = $sItag
                and row_guid = $irow_guid
                and fstatusno =  ' ';
            continue;
        }
    }

    /* �ˮָӽ߮׬O�_���o�Ө��P */
    $UPDATE sysdb:ca_rioho_pay_dtl
       SET fstatusno = '06',
           nerrmsg = '���U��--�ɮ֧@�~�|�������I�ؤ��t',
           dupdate = current
     WHERE dtransdate = $sdate1
       and fstatusno = ' '
       and nerrmsg = ' '
       AND upper(ilicno) NOT IN
            (SELECT itag FROM sysdb:ca_pro_ins c, sysdb:ca_property d
              WHERE c.iverify = d.iverify
                AND c.ipro_no = d.ipro_no
                AND c.iclaim = upper(sysdb:ca_rioho_pay_dtl.icaseNo));

    /* �ˮָӽ߮׬O�_���o�ӭר��t */
    /* �����ר��t�νs���ˮ�  modify by sylvia 110.01.18 (1100114006_SC1) */
    /*$UPDATE sysdb:ca_rioho_pay_dtl
       SET fstatusno = '02',
           nerrmsg = '�g�P�ΪA�ȼt�νs����--���߮׵L���ר��t�νs',
           dupdate = current
     WHERE dtransdate = $sdate1
       and fstatusno = ' '
       and nerrmsg = ' '
       AND Idlrid NOT IN
       (SELECT f.ifactory FROM ca_sign_receipt a, ca_factory f
         WHERE a.ifpce_id = f.ifactory
           AND a.ifpce_id_ext = f.ifactory_ext
           AND a.isign_type = '1'
           AND a.iclaim = upper(sysdb:ca_rioho_pay_dtl.icaseNo)
         UNION
        SELECT f.ifpce_id FROM ca_sign_receipt a, ca_factory f
         WHERE a.ifpce_id = f.ifactory
           AND a.ifpce_id_ext = f.ifactory_ext
           AND a.isign_type = '1'
           AND a.iclaim = upper(sysdb:ca_rioho_pay_dtl.icaseNo)
         union
        SELECT f.ifpce_id FROM ca_sign_receipt a, cu_customer f
         WHERE a.ifpce_id = f.ifpce_id
           AND a.ifpce_id_ext = f.ifpce_id_ext
           AND a.isign_type = '2'
           AND a.iclaim = upper(sysdb:ca_rioho_pay_dtl.icaseNo)); */

		/*  ���פw�M add by sylvia 109.06.02 */
		$Update sysdb:ca_rioho_pay_dtl
        Set fstatusno = ' ',
            nerrmsg = '���פw�M',
            dupdate = current
      where dtransdate = $sdate1
        and fstatusno = ' '
        and nerrmsg = ' '
        and (select fclaim_status from ca_clm_process where iclaim = upper(icaseno)) = '501';



    /* �D�W�z���(�t�鵲��<�o����),���ܥi���٦b�B�z��.. */
    /* �אּ�i06���U�ڡj modify by sylvia 109.06.02 */
    printf("287:iDclose=[%d]iDgroup=[%d]irow_guid=[%d]\n",iDclose,iDgroup,irow_guid);
    $Update sysdb:ca_rioho_pay_dtl
        Set fstatusno = '06',
            nerrmsg = '���U��_�߮ש|�b�B�z���Υ��鵲',
            dupdate = current
      where dtransdate = $sdate1
        and fstatusno = ' '
        and nerrmsg = ' ';

	return M_CM_OK;

errexit:
	sqlfatal();
	isql2 = SQLCODE;
	$ROLLBACK WORK;
	EWRITE(userid,isql2,sqlca.sqlerrm);
	return isql2;
}

/*--------------------------------------------------------------------*/

long car7404_Report()
{
    $char sTmp2[500];
    $int iinvoamt, irecamt;
    $char isignNo[21], idlrid[9], icaseNo[21], ncustName[11], ilicno[11],
	      iinvono[11], dinvodate[9], drecdate[9], irecnum[4], fstatusno[5],
          nerrmsg[51];

	$WHENEVER SQLERROR GOTO errexit;

    sprintf(msg1,"ñ�{�渹\t�A�ȼt�νs\t�߮׸�\t���D\t���P\t�o����\t�o����\t�o�����B\t�z�ߪ��B\t�U�ڤ��\t�U�ڦ���\t�U�ڪ��A\t�Ƶ�����\n");
    strcat(msg2, trim(msg1));

    sprintf(sTmp2,
        "select isignNo, idlrid, icaseNo, ncustName[1,10], ilicno, iinvono, \
                dinvodate, 	iinvoamt, irecamt, drecdate, irecnum,  \
                chr(127)||fstatusno, nerrmsg \
           from sysdb:ca_rioho_pay_dtl \
          where dtransdate = '%s' order by row_guid ", sdate1);

    printf("sTmp2=[%s]\n",sTmp2);
	$PREPARE pre_cur2 FROM $sTmp2;
	$DECLARE cur2 CURSOR FOR pre_cur2;
	$OPEN	cur2;
    while(1)
    {
        $FETCH cur2 INTO $isignNo, $idlrid, $icaseNo, $ncustName, $ilicno,
                         $iinvono, $dinvodate, $iinvoamt, $irecamt, $drecdate,
                         $irecnum, $fstatusno, $nerrmsg;
        if (SQLCODE == SQLNOTFOUND) break;

        sprintf(msg1,"%s\t %s\t %s\t %s\t %s\t %s\t %s\t %d\t %d\t %s\t %s\t %s\t %s\t\n",
                     isignNo, idlrid, icaseNo, ncustName, ilicno,
                     iinvono, dinvodate, iinvoamt, irecamt, drecdate,
                     irecnum, fstatusno, nerrmsg);

        strcat(msg2, trim(msg1));
    }

	return M_CM_OK;


errexit:
	sqlfatal();
	isql2 = SQLCODE;

	EWRITE(userid,isql2,sqlca.sqlerrm);
    return isql2;
}

/* -------------------------------------------------------------------------- */

long car7404_prepare_data()
{
    $int iCnt;

	$WHENEVER SQLERROR GOTO errexit;

    /* Ū�����M�U�ڶǰe�D�� */
    $insert into car7404m
     select * from sysdb:ca_rioho_pay_main
      where dtransdate between $sdate1 and $sdate2;

    iCnt = 0;
    $select count(*) into $iCnt from car7404m where 1=1;
    if (iCnt==0)
    {
        /* ��@��������ϥΪ̪��D */
        $insert into car7404m (dsenddate) values ('�d�L���!!') ;
        printf("insert into car7404m (dsenddate) values ('�d�L���!!') ; \n");
    }

    /* Ū�����M�U�ڶǰe�D�� */
    $insert into car7404d
     select * from sysdb:ca_rioho_pay_dtl
      where dtransdate between $sdate1 and $sdate2;

    iCnt = 0;
    $select count(*) into $iCnt from car7404d where 1=1;
    printf("car7404d, icnt[%d]\n",iCnt);
    if (iCnt==0)
    {
        /* ��@��������ϥΪ̪��D */
        $insert into car7404d (isignno) values ('�d�L���!!') ;
        printf("insert into car7404d (isignno) values ('�d�L���!!') ;\n");
    }

    return M_CM_OK;

errexit:
	sqlfatal();
	isql2 = SQLCODE;
	EWRITE(userid,isql2,sqlca.sqlerrm);
	return isql2;
}

/*--------------------------------------------------------------------*/
long car7404_build()
{
    $char    sfilename[51], stitle[1000], stmt[1000];
    $char    sfilename1[51], stitle1[1000], stmt1[1000];

	$WHENEVER SQLERROR GOTO errexit;

	strcpy(sfilename,"���M�߮פU�ڸ�Ƴ���_�D��");

	sprintf(stitle,"���ɤ��:%s~%s\t",dbgn,dend);

	strcat(stitle,"\n");
	strcat(stitle,"\n������ɤ��\t�O�I���q�N��\t�ǰe��Ƶ���\t���M�ǰe���\t�s�w�^�Ǥ��");

    sprintf(stmt,
	    "select * from car7404m where 1=1 order by dtransdate ", sdate1, sdate2);

	rc = unload_file(outputf,"B",sfilename,stitle,stmt);

	if (rc != SUCCESS)
	{
	    sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}


	strcpy(sfilename1,"���M�߮פU�ڸ�Ƴ���_������");
	sprintf(stitle1,"���ɤ��:\t%s~%s\t\n",dbgn,dend);
	strcat(stitle1,"\n");
	strcat(stitle1,"\t������ɤ��\tñ�{�渹\t�A�ȼt�νs\t�z�߮׸�\t���D�m�W\t�P�Ӹ��X");
	strcat(stitle1,"\t�o�����X\t�o�����\t�o�����B\t�z�ߪ��B\t�U�ڤ��");
	strcat(stitle1,"\t�U�ڦ���\t�U�ڪ��A\t�s�w�Ƶ�����\t");

   	sprintf(stmt1,
	    "select dtransdate, isignno, idlrid, icaseno, ncustname, ilicno, \
                iinvono, dinvodate, iinvoamt, irecamt, drecdate, irecnum, \
                 chr(127)||fstatusno, nerrmsg  \
           from car7404d where 1=1 order by dtransdate, row_guid", sdate1, sdate2);

	rc = unload_file(outputf,"A",sfilename1,stitle1,stmt1);

	if (rc != SUCCESS)
	{
	    sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename1);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}

	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}

/*--------------------------------------------------------------------*/
