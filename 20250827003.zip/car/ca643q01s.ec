/**********************************************************************/
/*   program id   : ca643q01s.ec                                      */
/*   program name : �ʲz�����y��Ƥ��ũ���                            */
/*   date written : 2016/11/30                                        */
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>

/****************************************************************************/
$char DBName[05],userid[11],ddate1[11],ddate2[11],dply_begin[11],dply_end[11],
      ipolicy3[4], fstatus[2];
char  msgbuf[2048], sApHome[30], rpt_type[2], getfile[101];
char  v_sMsg[1024], outputf[N_FILE+1];
int   count_db,i;
DBinfo  *list;
FILE    *fp;

/****************************************************************************/
main(argc, argv)
int argc;
char **argv;
{  
	int rc;

	batchinit();
	strcpy(DBName, 		    isNULLstr(argv[1]));
	strcpy(userid, 		    isNULLstr(argv[2]));
	strcpy(ddate1, 	        isNULLstr(argv[3]));    /* ���ɰ_��(CYYMMDD) */
	strcpy(ddate2,          isNULLstr(argv[4]));    /* ���ɨ���(CYYMMDD) */
	strcpy(ipolicy3,        isNULLstr(argv[5]));    /* �~�Z���(�O��e�T�X) */
	strcpy(fstatus,         isNULLstr(argv[6]));    /* �������p */
	strcpy(rpt_type,        isNULLstr(argv[7]));    /* �������O:1���y��Ƥ��ų���(CRJCM) 2:������ưl�ܳ��� */
	strcpy(getfile,         isNULLstr(argv[8]));    /* �ɮצW�� */
	strcpy(outputf,         isNULLstr(argv[9]));
	
	strcpy(dply_begin, cm_to_infdate(ddate1));
	strcpy(dply_end, cm_to_infdate(ddate2));
	
	printf("--1.car643_get_db ------ \n");
	rc = car643_get_db();
	if (rc != M_CM_OK) {
		EWRITE(userid,rc,msgbuf);
		return rc;
	}
 
    /* 1:���y��Ƥ��ų���(CRJCM) */
    if (strcmp(rpt_type,"1") == 0)
    {
        printf("--2.car643_init_data ------ \n");
        rc = car643_init_data();
        if (rc != M_CM_OK) {
            printf("error on car643_init_data\n");
    		EWRITE(userid,rc,"�إ� temp table ���~!");
    		return rc;
        }
    
        printf("--3.car643_query_detail ------ \n");
    	rc = car643_query_detail();
        if (rc != M_CM_OK) {
        printf("error on car643_query_detail\n");
    		EWRITE(userid, rc, "���̷s�O���Ʀ��~");
    		return rc;
    	}
    	 
    	printf("--4.car643_print_detail ------ \n");
        rc = car643_print_detail();
        if (rc != M_CM_OK) {
         printf("error on car643_print_detail\n");
         EWRITE(userid, rc, "���s�������Ӧ��~!");
         return rc;
        }
    }    
    else if (strcmp(rpt_type,"2") == 0)
    {
        /* 2:������ưl�ܳ��� */
        printf("--2.car643_init_data2 ------ \n");
        rc = car643_init_data2();
        if (rc != M_CM_OK) {
            printf("error on car643_init_data\n");
    		EWRITE(userid,rc,"�إ� temp table ���~!");
    		return rc;
        }
        
        printf("--3.car643_read_file ------ \n");
        rc = car643_read_file();
        if (rc != M_CM_OK)
            return rc;
    
        printf("--4.car643_query_detail2 ------ \n");
    	rc = car643_query_detail2();
        if (rc != M_CM_OK) {
            printf("error on car643_query_detail\n");
    		EWRITE(userid, rc, "���̷s�O���Ʀ��~");
    		return rc;
    	}
    	 
    	printf("--4.car643_print_detail2 ------ \n");
        rc = car643_print_detail2();
        if (rc != M_CM_OK) {
         printf("error on car643_print_detail2\n");
         EWRITE(userid, rc, "���s�������Ӧ��~!");
         return rc;
        }
    }    
			
    return rc;
}
/******************************************************************************/
long car643_init_data()
{   
    $WHENEVER SQLERROR GOTO errexit;
    
    /* ���~�N�X�έ�] */
    $select detail as ierrno, trim(chiname)||trim(engname) as err_msg
       from car_code where kind = 'T2'
     union all
     select detail2 as ierrno, trim(chiname)||trim(engname) as err_msg
       from car_code where kind = 'T2'
     into temp err_no with no log;
    
    $create temp table tb_ca6431
    (
        ipolicy         char(20),       -- �O�渹
        icard           char(17),       -- �d��
        irelative_ply   char(20),       -- ���p�O�渹
        itag            char(12),       -- ����(�פJ)
        itag_ply        char(12),       -- ����(�̷s�O��)
        iassured        char(12),       -- �Q�O�Hid(�פJ)
        iassured_ply    char(12),       -- �Q�O�Hid(�̷s�O��)
        iofficer        char(10),       -- �g��N��
        nname           char(10),       -- �g��W��
        nleader         char(10),       -- �޲z�H�W��
        nbranch         char(40),       -- �~�Z���
        err_msg         char(95),       -- ���~�N���ΦW��
        dcreate         date,           -- ���ɤ�, 
        fstatus         char(1),        -- �������p
        iendorse        char(20),       -- ��渹
        nremark         varchar(200),   -- ��L����
        nupdate         char(10),       -- ���ʤH��
        dupdate         date,           -- ���ʤ�
        dpolicy         date
    )with no log;
	  
    return M_CM_OK;

errexit:
    printf("--car643_init_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car643_query_detail_bak()
{
    int	    rc;
    $char   stmt1[1000],stmt2[1000],sFullName[25];
    $char   itag1[13], iassured1[11], icard[18], ipolicy[21], ierr_no[2];
    $char   irelative_ply[21], itag2[13], iassured2[11], iofficer[11], 
	        nofficer[11], nbranch[21], nleader[11];
   
    $WHENEVER SQLERROR GOTO errexit;
   
    sprintf(stmt1,"select distinct a.icard, a.itag, a.iassured, nvl(b.ipolicy,' '), ierror_code \
                     from ca_trade_crjcm a, outer compulsory_card b \
                    where date(a.dcreate) between '%s' and '%s' \
                      and a.icard[3,17] = b.icard ", dply_begin, dply_end);
    $PREPARE pre_bk1 FROM $stmt1;
    $DECLARE cur_bk1 CURSOR for pre_bk1;
    $OPEN cur_A1;
    while(1)
    {
        $FETCH cur_bk1 INTO $icard, $itag1, $iassured1, $ipolicy, $ierr_no;
            
        if(SQLCODE == SQLNOTFOUND) break;
    
        strcpy(sFullName,get_car_full_db(ipolicy));
        
        sprintf(stmt2,
            "select nvl(a.irelative_ply,' '), nvl(b.itag,' '), b.iassured, a.iofficer, \
                    c.nname, e.nbranch, d.nname \
               from %s:ply_relation a, %s:policy b, officer c, officer d, \
                    sa_branch_type e \
              where a.ipolicy = b.ipolicy  and a.iofficer = c.iofficer \
                and c.ileader = d.iofficer and a.iquota = e.ibranch \
                and a.ipolicy = '%s' ",sFullName,sFullName,ipolicy) ;

        $PREPARE pre_bk2 FROM $stmt2;
        $DECLARE cur_bk2 CURSOR for pre_bk2;
        $OPEN cur_bk2;
        
	    $FETCH cur_A2 INTO $irelative_ply, $itag2, $iassured2, $iofficer, 
	                       $nofficer, $nbranch, $nleader;
	    
        $insert into tb_ca6431
         values ($ipolicy, $icard, $irelative_ply, $itag1, $itag2,
                 $iassured1, $iassured2, $iofficer, $nofficer, $nbranch,
                 $nleader, $ierr_no);
    }
    $close cur_bk1;
    $free cur_bk1;
    
    return M_CM_OK;
  
errexit:
    printf("--car643_query_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car643_print_detail()
{
    int     rc;
    char    sfilename[128],stitle[2048],stmt[2048];
    $int    icnt;

    $WHENEVER SQLERROR GOTO errexit;
    
    strcpy(sfilename,"�ʲz�����T�������y��Ƥ��ŲM��");
    strcpy(stitle,"�{���N��:CAR6431\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");

    
    icnt = 0;
    $select count(*) into $icnt
      from tb_ca6431;
      
    if (icnt == 0) 
    {
        sprintf(msgbuf," %s �d�L���, �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return  M_CM_NOT_FOUND;
    }
    
    strcat(stitle,"\t�O�渹�X\t�j���Ҹ�(�פJ)\t���p�O�渹\t����(�פJ)\t����(�̷s�O��)");
    strcat(stitle,"\t�Q�O�I�HID(�פJ)\t�Q�O�I�HID(�̷s�O��)\t�g��N��\t�g��W��");
    strcat(stitle,"\t�޲z�H�W��\t�~�Z���\t���~�N���έ�]\t��J���\t�������p");
    strcat(stitle,"\t��渹�X\t��L����\t���ʤH��\t���ʤ��\tñ����");
    
    strcpy(stmt,"select ipolicy,icard,irelative_ply,''||itag,''||itag_ply, \
                        ''||iassured,''||iassured_ply,''||iofficer,nname, \
                        nleader, nbranch, err_msg, dcreate, fstatus, \
                        iendorse, nremark, nupdate, dupdate, dpolicy \
                   from tb_ca6431 where 1=1   ORDER BY ipolicy ");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }
    
    return M_CM_OK;
    
errexit:
    printf("--car643_print_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car643_get_db()
{
	int return_code;
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False) {
		strcpy(msgbuf,"��Ʈw�L�k�}��");
		return M_CM_DB_NOTOPEN;
	}
	
	return_code = getApHome(sApHome);
	if (return_code < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return return_code;
  }
  
  if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
  }
  
  return M_CM_OK;

errexit:
   printf("--car643_get_db-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
long car643_query_detail()
{
    int	    rc;
    $char   stmt1[2000],stmt2[100];
    
	
	int     istatus;
   
    $WHENEVER SQLERROR GOTO errexit;
   
    
    if (strcmp(fstatus,"*") == 0)
        strcpy(stmt2," ");
    else
        sprintf(stmt2,"and fstatus = '%s' ",fstatus);
        
    
    for (i=0; i<count_db; i++)
    {
        sprintf(stmt1,
            "insert into tb_ca6431 \
             select a.ipolicy, a.icard, b.irelative_ply, a.itag, c.itag as itag_ply, \
                    a.iassured, c.iassured as iassured_ply, b.iofficer, d.nname, \
                    (select nname from officer f where f.iofficer = d.ileader) as nleader, \
                    (select nbranch from sa_branch_type where ibranch = b.iquota) as nbranch, \
                    a.ierror_code||':'||g.err_msg, a.dcreate, a.fstatus, a.iendorse, \
                    a.nremark,  case when a.iupdate = 'sys_upd' then '�t�Φ^��' else \
                    (select nname from officer h where h.iofficer = a.iupdate) end as nupdate, \
                    a.dupdate, b.dpolicy \
               from ca_trade_crjcm a, %s:ply_relation b, %s:policy c, officer d, \
                    err_no g \
              where a.ipolicy = b.ipolicy and a.ipolicy = c.ipolicy \
                and b.iofficer = d.iofficer and a.ierror_code = g.ierrno \
                and date(a.dcreate) between '%s' and '%s' \
                and a.ipolicy[1,3] matches '%s' %s ",
                list[i].dbname, list[i].dbname, dply_begin, dply_end, ipolicy3, stmt2 );
         
        printf("stmt1=[%s]\n",stmt1);
        $PREPARE pre_A1 FROM $stmt1;
        $EXECUTE pre_A1;
    }   
     
    return M_CM_OK;
  
errexit:
    printf("--car643_query_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* ------------------------------------------------------------------------- */
long car643_init_data2()
{   
    $WHENEVER SQLERROR GOTO errexit;

    $create temp table tb_al
    (
        sno         int,            -- �Ǹ�
        icard       char(20),       -- �j���Ҹ�(�O�o)
        itag        char(12),       -- ����(�O�o)
        iassured    char(20),       -- �����Ҹ�(�O�o)
        ibirth      char(10),       -- �ͤ�(�O�o)
        icar_type   char(10),       -- ����(�O�o)
        icar_qpt    char(10),       -- �Ӹ��ƶq�γ��(�O�o)
        dcar_change    char(10),    -- �������A���ʤ�(�O�o)
        fcar_status    char(10),    -- �������A(�O�o)
        dtag_change    char(10),    -- �P�Ӫ��A���ʤ�(�O�o)
        ftag_status    char(10),    -- �P�Ӫ��A(�O�o)
        dtrans      char(10),       -- �ǰe���عq�H���(�O�o)
        serr_no     char(20),       -- �����~�N�X(�O�o)
        stype       char(10)        -- ���Ӻ���(�O�o)
    )with no log;
    
    $create temp table tp_a4
    (
        sno             int,            -- �Ǹ�
        icard           char(20),       -- �j���Ҹ�(�O�o)
        itag            char(12),       -- ����(�O�o)
        iassured        char(20),       -- �����Ҹ�(�O�o)
        ibirth          char(10),       -- �ͤ�(�O�o)
        icar_type       char(10),       -- ����(�O�o)
        icar_qpt        char(10),       -- �Ӹ��ƶq�γ��(�O�o)
        dcar_change     char(10),       -- �������A���ʤ�(�O�o)
        fcar_status     char(10),       -- �������A(�O�o)
        dtag_change     char(10),       -- �P�Ӫ��A���ʤ�(�O�o)
        ftag_status     char(10),       -- �P�Ӫ��A(�O�o)
        dtrans          char(10),       -- �ǰe���عq�H���(�O�o)
        serr_no         char(20),       -- �����~�N�X(�O�o)
        stype           char(10),       -- ���Ӻ���(�O�o) 
        ipolicy         char(20),       -- �O�渹(�d�ɤ����O�渹)
        ilast_card      char(20),       -- �e��d��
        ipolilcy_ply    char(20),       -- �O�渹(�̷s�O����) 
        iassured_ply    char(20),       -- �Q�O�HID (�̷s�O����)
        fsex_ply        char(1),        -- �Q�O�H�ʧO (�̷s�O����)
        dbirth_ply      date,           -- �Q�O�H�ͤ� (�̷s�O����)
        itag_ply        char(12),       -- ���P (�̷s�O����)
        icar_type_ply   char(2),        -- ���إN�� (�̷s�O����)
        dpolicy_ply     date,           -- ñ��� (�̷s�O����)
        dply_begin_ply  date,           -- �_�O�� (�̷s�O����)
        iofficer_ply    char(10),       -- �g��N�� (�̷s�O����)
        nofficer        char(10),       -- �g��W�� (�̷s�O����)
        nleader         char(10),       -- �޲z�H�W�� (�̷s�O����)
        nquota          char(30),       -- �~�Z���W�� (�̷s�O����)
        mdamage_cover   int,            -- �O�� (�̷s�O����)
        qpt_ply         decimal(4,1),   -- �����ƶq (�̷s�O����)
        fpt_ply         char(1)         -- ������� (�̷s�O����)
    )with no log;
	  
    return M_CM_OK;

errexit:
    printf("--car643_init_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* ------------------------------------------------------------------------ */
long car643_read_file()
{
    char    *bp;
    int     rc,i,j,k,m,n,qcount,flen,len1;
    char    filename[200];
    $char   sIpolicy[21];
    char    mmsg[10000], msg1[100];
    $int    icnt;
    $char   sdata[35][21];

    $whenever sqlerror goto errexit;
    
    strcpy(msg1," ");
    
    sprintf(filename,"%s/dat/car/%s",sApHome,getfile);
    if ((fp=fopen(filename,"r"))==NULL)
    {
       sprintf(msgbuf,"%s file open fail ",filename);
       return FALSE;
    }
    flen=1024;
    if ((bp=malloc(flen))==NULL)
    {
       sprintf(msgbuf,"System malloc failed !");
       return FALSE;
    }

    icnt = 0;
    for (i=0;(feof(fp)==0);i++)
    {
        printf("feof[%d]\n",feof(fp));
        memset(bp,0x00,flen);
        fgets(bp,flen,fp);
        if (bp[0]==0x00)
           break;
           
        qcount = 13; /* �`���� */

        for(j=0;j<qcount;j++)
           memset(sdata[j],0x00,21);
        
        k=m=n=0;
        for (j=0;j<flen;j++)
        {
            if (bp[j]=='\t' || bp[j]=='\0' || bp[j]=='\n')
            {
                strncpy(sdata[k],bp+(m+n),j-(m+n));
                sdata[k][j-(m+n)]='\0';
                n=0;
                m=j+1;
                k++;
            }
            if (bp[j]=='\n')
                break;
            if (k > qcount-1) break;
            
        }

        for (k=0;k<qcount;k++)
        {
            strcpy(sdata[k], trim(sdata[k]));
        }
        icnt++;
        
        $insert into tb_al values
            ($icnt,     $sdata[0], $sdata[1], $sdata[2], $sdata[3],
             $sdata[4], $sdata[5], $sdata[6], $sdata[7], $sdata[8],
             $sdata[9], $sdata[10],$sdata[11],$sdata[12]);
    }        
    printf("icnt = [%d]\n",icnt);
    
    EWRITE(userid,M_CM_OK,mmsg);
    return M_CM_OK;
   
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/*  --------------------------------------------------------------------*/
long car643_query_detail2()
{
    int	    rc;
    $char   stmt1[2000],stmt2[100];
    $int    icnt2;
    
	
	int     istatus;
   
    $WHENEVER SQLERROR GOTO errexit;
   
    
    $select a.*, b.ipolicy
       from tb_al a, compulsory_card b
      where a.icard[3,20] = b.icard
        and b.icard in (select icard[3,20] from tb_al)
       into temp tp_a3 with no log;
        
    $select count(*) into $icnt2 from tb_al where 1=1;
    printf("--- 473 tb_al icnt2=[%d]\n",icnt2);
    
    $select count(*) into $icnt2 from tp_a3 where 1=1;
    printf("--- 476 tp_a3 icnt2=[%d]\n",icnt2);
    
    
    for (i=0; i<count_db; i++)
    {
        sprintf(stmt1,
            "insert into tp_a4 \
             select a.*, b.ilast_card, c.ipolicy as ipolilcy_ply, c.iassured as iassured_ply, \
                    c.fsex as fsex_ply, c.dbirth as dbirth_ply, c.itag as itag_ply, \
                    b.icar_type as icar_type_ply, b.dpolicy as dpolicy_ply, \
                    b.dply_begin as dply_begin_ply, b.iofficer as iofficer_ply, \
                    (select nname from officer where iofficer = b.iofficer) as nofficer, \
                    (select nname from officer where iofficer = b.ileader) as nleader, \
                    (select nbranch from sa_branch_type where ibranch = b.iquota) as nquota, \
                    (select mdamage_cover from %s:ply_ins_type \
                      where ipolicy = b.ipolicy and iins_type = '21') as mdamage_cover, \
                    c.qpt as qpt_ply, c.fpt as fpt_ply \
              from tp_a3 a, %s:ply_relation b, %s:policy c \
             where a.ipolicy = b.ipolicy and b.ipolicy = c.ipolicy \
               and b.fcard_class = '1' ",
                list[i].dbname, list[i].dbname, list[i].dbname);
         
        printf("stmt1=[%s]\n",stmt1);
        $PREPARE pre_R1 FROM $stmt1;
        $EXECUTE pre_R1;
    }
    
    $select count(*) into $icnt2 from tp_a4 where 1=1;
    printf("--- 504 tp_a4 icnt2=[%d]\n",icnt2);
     
    return M_CM_OK;
  
errexit:
    printf("--car643_query_detail2-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/* ------------------------------------------------------------------------- */
long car643_print_detail2()
{
    int     rc;
    char    sfilename[128],stitle[2048],stmt[2048];
    $int    icnt,icnt2;

    $WHENEVER SQLERROR GOTO errexit;
    
    strcpy(sfilename,"������ưl�ܳ���");
    strcpy(stitle,"�{���N��:CAR6431\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");

    $select count(*) into $icnt2 from tp_a4 where 1=1;
    printf("--- 530 tp_a4 icnt2=[%d]\n",icnt2);

    
    /* $select a.*, b.icard_1, b.itag_1, b.iassured_1, b.dbirthday_1, b.icar_type_1,
            b.qpt_1,fpt_1, b.dtag_change, b.nassured, b.dtransfer, b.dcar_status, 
            b.icar_status, b.dtag_status, b.itag_status
       from tp_a4 a, outer ca_trade_notify b
      where a.ilast_card = b.icard_1[3,17]
        and b.icard_1 in (select '17'||trim(ilast_card) from tp_a4)
       into temp tp_a5 with no log;
    
    $select count(*) into $icnt2 from tp_a5 where 1=1;
    printf("--- 542 tp_a5 icnt2=[%d]\n",icnt2);
    */
    icnt = 0;
    $select count(*) into $icnt from tp_a4;
    
    printf("icnt = [%d]\n",icnt);  
    if (icnt == 0) 
    {
        sprintf(msgbuf," %s �d�L���, �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return  M_CM_NOT_FOUND;
    } 
    
    strcat(stitle,"\t�O�I�Ҹ�\tñ�樮��\tñ��νs/�����Ҹ�\t�^�ХX�ͦ~���\t�^�Ш���\t");
    strcat(stitle,"�^�ЩӸ����q\t�������A���ʤ�\t�������A\t�P�Ӫ��A���ʤ�\t�P�Ӫ��A\t");
    strcat(stitle,"�ǰe���عq�H���\t�����~�N�X\t���Ӻ���\t(�̷s�O��)�O�渹\t");
    strcat(stitle,"(�̷s�O��)�����Ҹ�\t(�̷s�O��)�ʧO\t(�̷s�O��)�ͤ�\t");
    strcat(stitle,"(�̷s�O��)�P�Ӹ��X\t(�̷s�O��)����\t(�̷s�O��)ñ����\t");
    strcat(stitle,"(�̷s�O��)�ͮĤ��\t(�̷s�O��)�g��N��\t(�̷s�O��)�g��W��\t");
    strcat(stitle,"(�̷s�O��)�޲z�H�W��\t(�̷s�O��)���W��\t(�̷s�O��)�O�B3\t");
    strcat(stitle,"(�̷s�O��)�����ƶq\t(�̷s�O��)�������\t");
    
    
    
    
    sprintf(stmt,"select icard, itag, iassured, ibirth, icar_type, \
                         icar_qpt, dcar_change, fcar_status, dtag_change, ftag_status, \
                         dtrans, serr_no, stype, \
                         ipolicy, iassured_ply, fsex_ply, dbirth_ply, itag_ply, \
                         icar_type_ply, dpolicy_ply, dply_begin_ply, iofficer_ply, nofficer, \
                         nleader, nquota, mdamage_cover, qpt_ply, fpt_ply \
                   from tp_a4 where 1=1 order by sno");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }
    
    return M_CM_OK;
    
errexit:
    printf("--car643_print_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}