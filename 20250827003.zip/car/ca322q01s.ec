/*-------------------------------------------------------------------
 * Program: ca322q01s.ec
 * Date   : 12/13/1994
 *-------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
$include sqlca;
$include sqltypes;
#define BLANK  2
static char    *mark="V", *blank=" ", *none="�L";
char  bigcom_type[2], choice[2], yymm[6];
$char plybgn[POLICY_NUM_1], plyend[POLICY_NUM_1], officer_rec[11];
$char plyyear[4], plymth[3];
$char stm1[25], stm2[25], stm3[25], stm4[25],stm5[25];
$char dprint[12], dprint_ch[12];
char  remark[10];
char  s_today[11];
char  err_buf[150];
int  rec_count, max_count,car_tp,ictype,label1=0;
$int tot_count=0;
int count=0;
char DBName[5];
char userid[11];
$char FormTp[3];
char outputf[20];
char option[2];
char prt_type[2];
$char dentry[11];
$char ibranch[3];
$char print_flag[2];
$char option_flag[2];
$char arg1[21];
$char arg2[21];
$char arg3[21];
$char arg4[21];
$char stmt[4000];

$char dbname_tp[45],taipei_db[41];
$char sWhere0[3000],sWhere1[3000];
$char iofficer2[11];
$char estimatei[21];
$char aassured_zip[6];
$char itel[21];
$char itel_night[21];
$char mobil_phone[21];
$char iemail[51];
$long Today;

/* �ˮ`�I */
$char pa_dply_begin[11],pa_dply_end[11];
$char dply_begin[11],dply_end[11];
$char nchi_full[31],ileader[11],nname[11],aassured[91];
$char ipolicy[21],iinsurant[11],ninsurant[31],dbirth[11],ainsurant[91];
$char iins_scope[2],icareer[2];
$long mins_amt = 0,mins_premium = 0;
$char napplicant[31],relation_appl[2],nbeneficiary[31],relation_bene[2];

long    car322_pa_print();
long    car322_pa_print1();

main(argc,argv)
int argc;
char **argv;
{
   $char FormFile[N_FILE+1], OutFile[20];
   $int  PgLine, iplyyear, iplymth,big_cnt,iplymth_next,iplyyear_next;
   $char DB[3],tmp_ibig_policy[POLICY_NUM_1],tmp_big_comp[2];
   $char stmt_buf[2000],tmp_ply[POLICY_NUM_1],dept[30],office[10];
   int   count, rtncode, rc;
   char  s_cur_yr[3], s_cur_mth[3];
   int   cur_yr, cur_mth;

   batchinit();
   strcpy(DBName,      isNULLstr(argv[1]));
   strcpy(userid,      isNULLstr(argv[2]));
   strcpy(dentry,      isNULLstr(argv[3]));
   strcpy(ibranch,     isNULLstr(argv[4]));
   strcpy(print_flag,  isNULLstr(argv[5]));
   strcpy(option_flag, isNULLstr(argv[6]));
   strcpy(arg1,        isNULLstr(argv[7]));
   strcpy(arg2,        isNULLstr(argv[8]));
   strcpy(arg3,        isNULLstr(argv[9]));
   strcpy(arg4,        isNULLstr(argv[10]));
   strcpy(outputf,     isNULLstr(argv[11]));

   $WHENEVER SQLERROR GOTO car322_err;

   if (db_select(DBName) == False)
   {
       EWRITE(userid, M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   rtoday(&Today);     /* get today's datetime */
   strcpy(s_today,cm_cdate_str_100(Today));

   $SELECT kPgNum_Line, nForm_File,iform_tp
      INTO $PgLine, $FormFile,$FormTp
      FROM Form
     WHERE ksys_grp='CA' AND kPgmID = 322;

    if (SQLCODE == SQLNOTFOUND)
    {
        printf("FormFile not found in Form!!\n");
        goto car322_err;
    }
    strcpy(FormFile,rtrim(FormFile));
    sprintf_s(OutFile, sizeof OutFile,"%s.tx",outputf);
    rgu_init_report(FormFile,OutFile);
    rec_count = 0;

    rc = getHeadBranch(taipei_db);
    if (rc < 0)
    {
         printf("read Config file error!!\n");
         return M_CM_READ_CONFIG_ERR;
    }
    strcpy(dbname_tp,get_full_dbname(taipei_db)); /* get TP's full DB name */

    strcpy(arg1,trim(arg1));
    strcpy(arg2,trim(arg2));
    strcpy(arg3,trim(arg3));
    strcpy(arg4,trim(arg4));

    strcpy(dentry,cm_to_infdate(dentry));

    printf("option_flag[%s]\n",option_flag);
    switch(option_flag[0])
    {
        case '1':   /* �M�׵��O */
                sprintf_s(sWhere0, sizeof sWhere0," AND a.nequipment[%s] = '1' ",arg1);
                sprintf_s(sWhere1, sizeof sWhere1," AND a.nequipment[%s] = '1' ",arg1);
                break;
        case '2':   /* �g��H�N�� */
                sprintf_s(sWhere0, sizeof sWhere0," AND (a.iofficer1 MATCHES '%s' OR        "
                                       "a.iofficer2 MATCHES '%s') ",arg1,arg1);
                sprintf_s(sWhere1, sizeof sWhere1," AND (a.iofficer1 MATCHES '%s' OR        "
                                       "a.iofficer2 MATCHES '%s') ",arg1,arg1);
                break;
        case '3':   /* �����Ҹ��X */
                sprintf_s(sWhere0, sizeof sWhere0," AND a.iassured MATCHES '%s' ",arg1);
                sprintf_s(sWhere1, sizeof sWhere1," AND a.iassured MATCHES '%s' ",arg1);
                break;
        case '4':   /* �P�Ӹ��X   */
                sprintf_s(sWhere0, sizeof sWhere0," AND a.itag MATCHES '%s' ",arg1);
                sprintf_s(sWhere1, sizeof sWhere1," AND a.itag MATCHES '%s' ",arg1);
                break;
        case '5':   /* �������X   */
                sprintf_s(sWhere0, sizeof sWhere0," AND a.iengine MATCHES '%s' ",arg1);
                sprintf_s(sWhere1, sizeof sWhere1," AND a.iengine MATCHES '%s' ",arg1);
                break;
        case '6':   /* �պ⸹�X   */
                strcat(arg1,arg2);
                strcat(arg3,arg4);
                sprintf_s(sWhere0, sizeof sWhere0," AND a.iabnormal BETWEEN '%s' AND '%s' ",arg1,arg3);
                sprintf_s(sWhere1, sizeof sWhere1," AND a.iestimate BETWEEN '%s' AND '%s' ",arg1,arg3);
                break;
        case '7':   /* �O�渹�X   */
                strcat(arg1,arg2);
                strcat(arg3,arg4);
                if (arg1[5] == 'V')
                {
                   sprintf_s(sWhere0, sizeof sWhere0," AND a.ipolicy2 BETWEEN '%s' AND '%s' ",arg1,arg3);
                   sprintf_s(sWhere1, sizeof sWhere1," AND a.ipolicy2 BETWEEN '%s' AND '%s' ",arg1,arg3);
                }
                else
                {
                   sprintf_s(sWhere0, sizeof sWhere0," AND a.ipolicy1 BETWEEN '%s' AND '%s' ",arg1,arg3);
                   sprintf_s(sWhere1, sizeof sWhere1," AND a.ipolicy1 BETWEEN '%s' AND '%s' ",arg1,arg3);
                }
                break;

        case '8':   /* �O�I��/�d�� */
                sprintf_s(sWhere0, sizeof sWhere0," AND (a.icomp_card BETWEEN '%s' AND '%s'    "
                                   "OR  a.iins_card  BETWEEN '%s' AND '%s') ",arg1,arg2,arg1,arg2);
                sprintf_s(sWhere1, sizeof sWhere1," AND (a.icard1 BETWEEN '%s' AND '%s'        "
                                   "OR  a.icard2 BETWEEN '%s' AND '%s') ",arg1,arg2,arg1,arg2);
                break;
    default:
                exit(1);
    }

    sprintf_s(stmt, sizeof stmt,
     " SELECT b.iabnormal,b.iinsurant,b.ninsurant,b.dbirth,b.ainsurant,         "
             "b.iins_scope,b.icareer,b.mins_amt,b.mins_premium,b.napplicant,    "
             "b.relation_appl,b.nbeneficiary,b.relation_bene,                   "
             "a.aassured_zip,a.itel,a.itel_night,a.mobil_phone,a.iemail,        "
             "a.dbegin,a.dend,a.iofficer2                 "
        " FROM %s:abnormal_ply a,%s:abn_ca_pa_ply b        "
        "WHERE a.dentry = '%s'                             "
        "  AND a.ibranch matches '%s'                      "
        "  AND a.iabnormal = b.iabnormal  "
        "   %s                            "
        "UNION                            "
       "SELECT b.iestimate,b.iinsurant,b.ninsurant,b.dbirth,b.ainsurant,          "
              "b.iins_scope, b.icareer, b.mins_amt, b.mins_premium,b.napplicant,  "
              "b.relation_appl,b.nbeneficiary,b.relation_bene,                    "
              "a.aassured_zip,a.itel,a.itel_night,a.mobil_phone,a.iemail,         "
              "a.dply2_begin,a.dply2_end,a.iofficer2                              "
        " FROM estimate a,ca_pa_est b     "
        "WHERE a.dentry = '%s'            "
        "  AND a.ibranch matches '%s'     "
        "  AND a.iestimate = b.iestimate  "
        "   %s ",dbname_tp,dbname_tp,dentry,ibranch,sWhere0,dentry,ibranch,sWhere1);
     printf("stmt[%s]\n",stmt);
     $PREPARE main_id FROM $stmt;
     $DECLARE main_cur CURSOR FOR main_id;
     $OPEN main_cur ;
     for(;;)
     {
     $FETCH main_cur
       INTO $estimatei,$iinsurant,$ninsurant,$dbirth,$ainsurant,
            $iins_scope, $icareer, $mins_amt, $mins_premium, $napplicant,
            $relation_appl,$nbeneficiary,$relation_bene,
            $aassured_zip,$itel,$itel_night,$mobil_phone,$iemail,
            $dply_begin,$dply_end,$iofficer2;
         if (SQLCODE == SQLNOTFOUND) break;

         rec_count++;
         rc = car322_pa_print();
         if (rc != M_CM_OK)
         {
            goto car322_err;
         }
     }
     $CLOSE main_cur;
     $FREE  main_cur;
    if (rec_count==0)
    {
        EWRITE(userid,M_CM_NOT_FOUND,"No record found!");
        return M_CM_NOT_FOUND;
    }

    $WHENEVER SQLERROR GOTO car322_err;
    rgu_finish_report();
    if(rc=(save_form_info(F_FREE,"CA",322,userid,FormTp,max_count,outputf))<0)
       EWRITE(userid,rc,"save_form_info failed");

    return M_CM_OK;
car322_err:
    printf("car322_err:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
$   WHENEVER SQLERROR CONTINUE;     /* reset error handling */
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*    �s��    */
long car322_pa_print()
{
   int rc;
   FILE *sfp;
   char str[100];
   $char stmt[1024];
   char ipolicy_01[4],ipolicy_04[18];
   char tmp_buf[50],tmp_buf1[50],tmp_buf2[50],appl_str[11],bene_str[11];
   int appl,bene,i;
   char iinsurant_02[2];
   char str_dbirth[11],str_dply_begin[11],str_dply_end[11];
   char yy1[4],mm1[3],dd1[3],yy2[4],mm2[3],dd2[3],yy3[4],mm3[3],dd3[3];
   char tot_ipolicy[100];
   char all_str[20];
   char icareer_s[21],skind[7];
   char sTmp[21];
   char aassured_zip_tmp[2];

   rgu_put_body(1);   max_count += 9;
   strcpy(ipolicy_01,substring(estimatei,1,3));
   strcpy(ipolicy_04,substring(estimatei,4,20));

   strcpy(tot_ipolicy,"17");
   strcat(tot_ipolicy,ipolicy_01);
   rgu_put_body_string(2,trim(tot_ipolicy),1);
   rgu_put_body_string(2,trim(ipolicy_04),1);
   rgu_put_body(2);   max_count ++;

   rgu_put_body_string(3,trim(napplicant),1);
   rgu_put_body_string(3," ",1);
   appl = atoi(relation_appl);
   printf(" appl[%d]\n",appl);
   switch(appl)
   {
       case 1:
            strcpy (appl_str,"���H");
            break;
       case 2:
             strcpy (appl_str,"�a��");
             break;
       case 3:
             strcpy (appl_str,"�O�Υ����H");
             break;
       case 4:
            strcpy (appl_str,"�ŰȤH");
             break;
       case 5:
            strcpy (appl_str,"�]���޲z�H");
             break;
       case 6:
            strcpy (appl_str,"�k�w�~�ӤH");
             break;
   }
   printf(" appl_str[%s]\n",appl_str);
   rgu_put_body_string(3,trim(appl_str),1);
   rgu_put_body(3);   max_count ++;
   rgu_put_body(98); max_count ++;
   if (appl == 1)
   {
      sprintf_s(aassured_zip_tmp, sizeof aassured_zip_tmp,"%c %c %c",aassured_zip[0],aassured_zip[1],aassured_zip[2]);
      rgu_put_body_string(4,aassured_zip_tmp,1);
      rgu_put_body_string(4,trim(ainsurant),1);
   }
   else
   {
      rgu_put_body_string(4," ",1);
      rgu_put_body_string(4," ",1);
      rgu_put_body_string(4," ",1);
      rgu_put_body_string(4," ",1);
   }
   rgu_put_body(4);   max_count ++;
   rgu_put_body(98);  max_count ++;

   if (appl == 1)
   {
       rgu_put_body_string(5,trim(itel),1);         /* ��q�� */
       rgu_put_body_string(5," ",1);                /* ����   */
       rgu_put_body_string(5,mobil_phone,1);        /* ��ʹq�� */
       rgu_put_body(5);   max_count ++;
       rgu_put_body_string(6,trim(itel_night),1);   /* �]�q�� */
       rgu_put_body_string(6,trim(iemail),1);       /* E-mail */
       rgu_put_body(6);   max_count ++;
   }
   else
   {
       rgu_put_body(98);  max_count ++;
       rgu_put_body(98);  max_count ++;
   }

   strcpy(str_dbirth,cm_from_infdate_100(dbirth));
   cm_split_ymd_100(str_dbirth,yy1,mm1,dd1);

   if (iinsurant[1] == '1')
   {
       rgu_put_body_string(7,"V",1);
       rgu_put_body(7);   max_count ++;
       rgu_put_body_string(8,trim(ninsurant),1);
       rgu_put_body_string(8," ",1);
   }
   else
   {
       rgu_put_body(98); max_count ++;
       rgu_put_body_string(8,trim(ninsurant),1);
       rgu_put_body_string(8,"V",1);
   }
       rgu_put_body_string(8,trim(yy1),1);
       rgu_put_body_string(8,trim(mm1),1);
       rgu_put_body_string(8,trim(dd1),1);
       rgu_put_body_string(8,trim(iinsurant),1);
       rgu_put_body(8);   max_count ++;

   rgu_put_body(98);  max_count ++;

   if (appl == 1)
   {
      sprintf_s(aassured_zip_tmp, sizeof aassured_zip_tmp,"%c %c %c",aassured_zip[0],aassured_zip[1],aassured_zip[2]);
      rgu_put_body_string(9,aassured_zip_tmp,1);
      rgu_put_body_string(9,trim(ainsurant),1);
   }
   else
   {
      rgu_put_body_string(9," ",1);
      rgu_put_body_string(9," ",1);
      rgu_put_body_string(9," ",1);
      rgu_put_body_string(9," ",1);
   }
   rgu_put_body(9);   max_count ++;

   rgu_put_body(98);  max_count ++;
   if (iins_scope[0] != '1')
   {
       switch(icareer[0])
       {
             case '1' :  strcpy(skind,"�Ĥ@��");
                         break;
             case '2' :  strcpy(skind,"�ĤG��");
                         break;
             case '3' :  strcpy(skind,"�ĤT��");
                         break;
             case '4' :  strcpy(skind,"�ĥ|��");
                         break;
             case '5' :  strcpy(skind,"�Ĥ���");
                         break;
             case '6' :  strcpy(skind,"�Ĥ���");
                         break;
             default  :  break;
       }
     rgu_put_body_string(14,"¾�~���O�G",1);
     rgu_put_body_string(14,skind,1);
     rgu_put_body(14); max_count++; max_count++;
   }
   else
   {
     rgu_put_body(98);  max_count ++;
     rgu_put_body(98);  max_count ++;
   }

   rgu_put_body(98);  max_count ++;
   rgu_put_body(98);  max_count ++;

   /*  �O�I����  */
   printf("dply_begin[%s]\n",dply_begin);
   strcpy(str_dply_begin,cm_from_infdate_100(dply_begin));
   printf("str_dply_begin[%s]\n",str_dply_begin);

   cm_split_ymd_100(str_dply_begin,yy2,mm2,dd2);
   printf("yy2[%s],mm2[%s],dd2[%s]\n",yy2,mm2,dd2);
   rgu_put_body_string(10,trim(yy2),LEFT);
   rgu_put_body_string(10,trim(mm2),LEFT);
   rgu_put_body_string(10,trim(dd2),LEFT);

   strcpy(str_dply_end,cm_from_infdate_100(dply_end));
   cm_split_ymd_100(str_dply_end,yy3,mm3,dd3);
   printf(" yy3[%s],mm3[%s],dd3[%s]\n",yy3,mm3,dd3);

   rgu_put_body_string(10,trim(yy3),LEFT);
   rgu_put_body_string(10,trim(mm3),LEFT);
   rgu_put_body_string(10,trim(dd3),LEFT);

   rgu_put_body(10);     max_count ++;
   for(i=1;i<=15;i++)
   {
      rgu_put_body(98);   max_count ++;
   } 

   printf("iins_scope[%s]\n",iins_scope);

   if (iins_scope[0] == '2')
   {
      rgu_put_body(98);  max_count ++;
   }
   else if (iins_scope[0] == '3')
   {
      rgu_put_body(98);  max_count ++;
      rgu_put_body(98);  max_count ++;
      rgu_put_body(98);  max_count ++;
   }

   rgu_put_body_string(11,"V",1);
   rfmtlong(mins_amt,"---,---,---,--&",sTmp);
   rgu_put_body_string(11,trim(sTmp),2);
   rgu_put_body_string(11,trim(nbeneficiary),1);
   bene=atoi(relation_bene);
   printf(" bene[%d]\n",bene);
   switch(bene)
   {
      case 1:
           strcpy (bene_str,"���H");
           break;
      case 2:
           strcpy (bene_str,"�a��");
            break;
      case 3:
           strcpy (bene_str,"�O�Υ����H");
            break;
      case 4:
           strcpy (bene_str,"�ŰȤH");
            break;
      case 5:
           strcpy (bene_str,"�]���޲z�H");
            break;
   }
   rgu_put_body_string(11,bene_str,1);
   rgu_put_body(11);   max_count ++;

   if (iins_scope[0] == '1')
   {
      rgu_put_body(98); max_count ++;
      rgu_put_body(98); max_count ++;
      rgu_put_body(98); max_count ++;
   }
   else if (iins_scope[0] == '2')
   {
      rgu_put_body(98); max_count ++;
      rgu_put_body(98); max_count ++;
   }
   rgu_put_body(98); max_count ++;
   rgu_put_body(98); max_count ++;
   rgu_put_body(98); max_count ++;
   rfmtlong(mins_premium,"---,---,---,--&",sTmp);
   rgu_put_body_string(12,trim(sTmp),2);
   rgu_put_body(12);   max_count ++;

   for(i=0;i<=15;i++)
   {
   rgu_put_body(98); max_count ++;
   }

   rgu_put_body_string(15,trim(iofficer2),1);
   rgu_put_body(15);   max_count ++;

   rgu_put_body(99); max_count ++;

   /*******************
   for(i=0;i<=18;i++)
   {
   rgu_put_body(98); max_count ++;
   }
   ********************/
   return M_CM_OK;
}

/*   �ª�    */
long car322_pa_print1()
{
   int rc;
   FILE *sfp;
   char str[100];
   $char stmt[1024];
   char ipolicy_01[4],ipolicy_04[18];
   char tmp_buf[50],tmp_buf1[50],tmp_buf2[50],appl_str[11],bene_str[11];
   int appl,bene,i;
   char iinsurant_02[2];
   char str_dbirth[11],str_dply_begin[11],str_dply_end[11];
   char yy1[4],mm1[3],dd1[3],yy2[4],mm2[3],dd2[3],yy3[4],mm3[3],dd3[3];
   char tot_ipolicy[100];
   char all_str[20];
   char icareer_s[21],skind[7];
   char sTmp[21];
   char aassured_zip_tmp[2];

   rgu_put_body(1);   max_count += 9;
   strcpy(ipolicy_01,substring(estimatei,1,3));
   strcpy(ipolicy_04,substring(estimatei,4,20));

   strcpy(tot_ipolicy,"17");
   strcat(tot_ipolicy,ipolicy_01);
   rgu_put_body_string(2,trim(tot_ipolicy),1);
   rgu_put_body_string(2,trim(ipolicy_04),1);
   rgu_put_body(2);   max_count ++;

   rgu_put_body_string(3,trim(napplicant),1);
   rgu_put_body_string(3," ",1);
   appl = atoi(relation_appl);
   printf(" appl[%d]\n",appl);
   switch(appl)
   {
       case 1:
            strcpy (appl_str,"���H");
            break;
       case 2:
             strcpy (appl_str,"�a��");
             break;
       case 3:
             strcpy (appl_str,"�O�Υ����H");
             break;
       case 4:
            strcpy (appl_str,"�ŰȤH");
             break;
       case 5:
            strcpy (appl_str,"�]���޲z�H");
             break;
   }
   printf(" appl_str[%s]\n",appl_str);
   rgu_put_body_string(3,trim(appl_str),1);
   rgu_put_body(3);   max_count ++;
   rgu_put_body(98); max_count ++;
   if (appl == 1)
   {
      sprintf_s(aassured_zip_tmp, sizeof aassured_zip_tmp,"%c %c %c",aassured_zip[0],aassured_zip[1],aassured_zip[2]);
      rgu_put_body_string(4,aassured_zip_tmp,1);
      rgu_put_body_string(4,trim(ainsurant),1);
   }
   else
   {
      rgu_put_body_string(4," ",1);
      rgu_put_body_string(4," ",1);
      rgu_put_body_string(4," ",1);
      rgu_put_body_string(4," ",1);
   }
   rgu_put_body(4);   max_count ++;

   if (appl == 1)
   {
       rgu_put_body_string(5,trim(itel),1);         /* ��q�� */
       rgu_put_body_string(5," ",1);                /* ����   */
       rgu_put_body_string(5,mobil_phone,1);        /* ��ʹq�� */
       rgu_put_body(5);   max_count ++;
       rgu_put_body_string(6,trim(itel_night),1);   /* �]�q�� */
       rgu_put_body_string(6,trim(iemail),1);       /* E-mail */
       rgu_put_body(6);   max_count ++;
   }
   else
   {
       rgu_put_body(98);  max_count ++;
       rgu_put_body(98);  max_count ++;
   }
       rgu_put_body(98);  max_count ++;

   strcpy(str_dbirth,cm_from_infdate_100(dbirth));
   cm_split_ymd_100(str_dbirth,yy1,mm1,dd1);

   if (iinsurant[1] == '1')
   {
       rgu_put_body_string(7,"V",1);
       rgu_put_body(7);   max_count ++;
       rgu_put_body_string(8,trim(ninsurant),1);
       rgu_put_body_string(8," ",1);
   }
   else
   {
       rgu_put_body(98); max_count ++;
       rgu_put_body_string(8,trim(ninsurant),1);
       rgu_put_body_string(8,"V",1);
   }
       rgu_put_body_string(8,trim(yy1),1);
       rgu_put_body_string(8,trim(mm1),1);
       rgu_put_body_string(8,trim(dd1),1);
       rgu_put_body_string(8,trim(iinsurant),1);
       rgu_put_body(8);   max_count ++;

   if (appl == 1)
   {
      sprintf_s(aassured_zip_tmp, sizeof aassured_zip_tmp,"%c %c %c",aassured_zip[0],aassured_zip[1],aassured_zip[2]);
      rgu_put_body_string(9,aassured_zip_tmp,1);
      rgu_put_body_string(9,trim(ainsurant),1);
   }
   else
   {
      rgu_put_body_string(9," ",1);
      rgu_put_body_string(9," ",1);
      rgu_put_body_string(9," ",1);
      rgu_put_body_string(9," ",1);
   }
   rgu_put_body(9);   max_count ++;

   rgu_put_body(98);  max_count ++;

   if (iins_scope[0] != '1')
   {
       switch(icareer[0])
       {
             case '1' :  strcpy(skind,"�Ĥ@��");
                         break;
             case '2' :  strcpy(skind,"�ĤG��");
                         break;
             case '3' :  strcpy(skind,"�ĤT��");
                         break;
             case '4' :  strcpy(skind,"�ĥ|��");
                         break;
             case '5' :  strcpy(skind,"�Ĥ���");
                         break;
             case '6' :  strcpy(skind,"�Ĥ���");
                         break;
             default  :  break;
       }
     rgu_put_body_string(14,"¾�~���O�G",1);
     rgu_put_body_string(14,skind,1);
     rgu_put_body(14); max_count++; max_count++;
   }
   else
   {
     rgu_put_body(98);  max_count ++;
     rgu_put_body(98);  max_count ++;
   }

   rgu_put_body(98);  max_count ++;
   rgu_put_body(98);  max_count ++;
   rgu_put_body(98);  max_count ++;

   /*  �O�I����  */
   printf("dply_begin[%s]\n",dply_begin);
   strcpy(str_dply_begin,cm_from_infdate_100(dply_begin));
   printf("str_dply_begin[%s]\n",str_dply_begin);

   cm_split_ymd_100(str_dply_begin,yy2,mm2,dd2);
   printf("yy2[%s],mm2[%s],dd2[%s]\n",yy2,mm2,dd2);
   rgu_put_body_string(10,trim(yy2),LEFT);
   rgu_put_body_string(10,trim(mm2),LEFT);
   rgu_put_body_string(10,trim(dd2),LEFT);

   strcpy(str_dply_end,cm_from_infdate_100(dply_end));
   cm_split_ymd_100(str_dply_end,yy3,mm3,dd3);
   printf(" yy3[%s],mm3[%s],dd3[%s]\n",yy3,mm3,dd3);

   rgu_put_body_string(10,trim(yy3),LEFT);
   rgu_put_body_string(10,trim(mm3),LEFT);
   rgu_put_body_string(10,trim(dd3),LEFT);

   rgu_put_body(10);     max_count ++;
   for(i=1;i<=17;i++)
   {
      rgu_put_body(98);   max_count ++;
   } 

   printf("iins_scope[%s]\n",iins_scope);

   if (iins_scope[0] == '2')
   {
      rgu_put_body(98);  max_count ++;
   }
   else if (iins_scope[0] == '3')
   {
      rgu_put_body(98);  max_count ++;
      rgu_put_body(98);  max_count ++;
      rgu_put_body(98);  max_count ++;
   }

   rgu_put_body_string(11,"V",1);
   rfmtlong(mins_amt,"---,---,---,--&",sTmp);
   rgu_put_body_string(11,trim(sTmp),2);
   rgu_put_body_string(11,trim(nbeneficiary),1);
   bene=atoi(relation_bene);
   printf(" bene[%d]\n",bene);
   switch(bene)
   {
      case 1:
           strcpy (bene_str,"���H");
           break;
      case 2:
           strcpy (bene_str,"�a��");
            break;
      case 3:
           strcpy (bene_str,"�O�Υ����H");
            break;
      case 4:
           strcpy (bene_str,"�ŰȤH");
            break;
      case 5:
           strcpy (bene_str,"�]���޲z�H");
            break;
   }
   rgu_put_body_string(11,bene_str,1);
   rgu_put_body(11);   max_count ++;

   if (iins_scope[0] == '1')
   {
      rgu_put_body(98); max_count ++;
      rgu_put_body(98); max_count ++;
      rgu_put_body(98); max_count ++;
   }
   else if (iins_scope[0] == '2')
   {
      rgu_put_body(98); max_count ++;
      rgu_put_body(98); max_count ++;
   }
   rgu_put_body(98); max_count ++;
   rgu_put_body(98); max_count ++;
   rgu_put_body(98); max_count ++;
   rfmtlong(mins_premium,"---,---,---,--&",sTmp);
   rgu_put_body_string(12,trim(sTmp),2);
   rgu_put_body(12);   max_count ++;


   rgu_put_body(99); max_count ++;
   /***********************
   for(i=0;i<=16;i++)
   {
   rgu_put_body(98); max_count ++;
   }
   ************************/
   return M_CM_OK;
}
