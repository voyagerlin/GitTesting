#include <stdio.h>
#include <stdlib.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "ca301m01.h"
$include "car_common.h";

#define fmt "---------&"

char *sLastChinese();
char *get_car_full_db();

char         userid[7];
char         errmsg[200];
char         DBName[5];

FILE *errfpt;

DBinfo  *list;
FILE    *fptr, *fptr_err;
time_t  lt;
$char outputf0[50],outputf1[50],outputf2[50],outputf6[50],outputf7[50],outputf[50];
$char lia_ac_cntA[3], FormFile[N_FILE+1], OutFile[20];
$char ipolicy[21],ipolicy_1[21],icard[21],fcard_class[2],irelative_ply[21],
      dply_bgn_comp[11],dply_end_comp[11],last_policy_2[21],last_policy_3[21],
      dply_begin[11],dply_end[11],nassured[121],ilicense[13],ibirth[9],
      fsex[2],fmarriage[2],nuser[19],nbenef[43],aassured[91],itel[21],
      iply_area[11],iissue_ym[7],ipro_year[5],ibrand[9],nbrand_abbr[17],
      icar_type[3],ncar_type[17],iengine[21],ibody[21],itag[9],mcar_price[11],
      fpt[2],idmg_rate[3],ibrg_rate[3],lia_ac_cnt1[3],lia_ac_cnt2[3],
      lia_ac_cnt3[3],dmg_ac_cnt1[3],dmg_ac_cnt2[3],dmg_ac_cnt3[3],plia_acc[5],
      pdmg_acc[5],plia_acc_c[6],dedr_begin[11],iofficer[11],
      nname[11],ibig_office[10],ibig_sales[11],ibig_policy[21],ibig_comp[2],
      ibig_branch[5],fcomp_class[3],fcomp_class_last[3],ileader[11],
      aassured_zip[6],irel_card[18],irel_card_2[18],irel_card_3[18],
      iquota[7],nchi_full[31],fnation[2],ch_ins_grp1[56],ch_ins_grp2[56],
      ch_ins_grp3[56],pre_dply1_bgn[11],pre_dply1_end[11],pre_prem1[7],
      pre_prem2[7],pre_dply2_bgn[11],pre_dply2_end[11],pre_sex_age[6],pre_sex_age_damage[6],
      pre_lia_acc[6],pre_dmg_acc[6],note1[21],nbrand[25],lia_ac_cntc[3],
      remark1[101],remark2[101],remark6[101],remark7[101],LHsIbig_Nname[11],remark3[737], sNequipment[31],
      iquota_fax[21], iquota_tel[21];

$char iins_type[7],ch_deduct[13], lia_class[3], tmp_data[10];
$char nproject[21], remark4[101], remark5[141], nchi_tmp[21];
$long minjured_cover,mdeath_cover,mdamage_cover,mdeduct,mprem,mins_premium,
      qcoverage,pre_inj_cover,pre_dea_cover,pre_dam_cover,pre_deduct,
      pre_minsprem,qserial,t_date_bgn,t_date_end,pre_daily_pay,qserial_tmp;
$long   qday;

$char remark_tmp1[101], remark_tmp2[101];
$int  comp_prem,qply_period,qcylinder,pdmg_align,pbrg_align,plia_align,
      v_prem,v_ori_prem,tot_prem,tot_ori_prem,linnum,t_count, intopt;
$int  linnum_a;
$double qpt,psex_age,mbusiness,psex_age_damage;
$double psex_age_c, psex_age_v;
$char  BodyFile[21],TitleFile[21],BodyFmt[21],FormTp[3];
$char  TitleFmt[21],stmt[1024],prtstr[10000],sSpec[1024];
$int   ItemRow, TotColumn;
$int   StartRow,TitleRow;
$int   PgLine, Width;
$int   iMdiscount,iTot_mpay,iTot_ori_mpay;
$int   d_mdiscount,d_pre_mdiscount;
int    max_count,rt,rc,unt,s;
int    GiCnt= 0, flagE= 0;
$long  lndply_begin;
$char  comp_date_begin[15],comp_date_end[15],sWhereA[300];
$char  icorps[11],ncorps[31];
$char   sTmpMsg[80],sNbrand[25], sTmp[101], fclass[2], sTmp1[21], tmp_ileader[11], sTmpIply[21];
$char  pre_ch_ins_grp1[56],pre_ch_ins_grp2[56],pre_ch_ins_grp3[56];
$double pdiscount;
$char  spdiscount[8];
$char   tphone_con[21],imovephone[21],iemail[51], icar_type_comp[3], ichange_note[129], icar_type_chg[21];
char   c_comp_prem[7],c_qply_period[3],c_qcylinder[6],c_pdmg_align[3],
       c_pbrg_align[3],c_plia_align[3],c_qpt[6],c_psex_age[6],c_mbusiness[9],
       c_v_prem[7],c_tot_prem[7],sApHome[21],file0[50],file1[50],file2[50],file6[50],file7[50],xmp[20], file10[50], file11[50];

$char outputf10[50], outputf11[50];

FILE   *fp0,*fp1,*fp2,*fp6,*fp7, *fp10, *fp11;
char   c_dmg_factor[8], c_brg_factor[8], flag_A09;
$double dmg_factor, brg_factor;

$char  outputf8[50], outputf9[50];
char   file8[50], file9[50];
$char  ctmp_ipolicy[21],ctmp_iins_type[3],ctmp_message[21],fassured[2];
FILE   *fp8,*fp9;
int    i,n,iins_line;
$int  iplyyear, iplymonth, iins_class;
$char   fcar_class[2] ,fcomp_24[2], option[2];
$long   mexpense, mexp_disc;
$long   ori_injured_cover, ori_death_cover, ori_damage_cover, ori_deduct;
$long   ins_premium, premium2, premium1, premium, premium_11, ori_premium;
$long   ori_inj_cover, ori_dea_cover, ori_dam_cover,ldaily_pay,ori_lDaily_pay;
$char   iins_type_i[6];
$int    qserial_i, qserial_j, intopt, iTmp, iYear, iCount;

$char  outputf12[50], outputf13[50],outputf14[50], outputf15[50],outputf16[50], outputf17[50];
char   file12[50], file13[50],file14[50], file15[50],file16[50], file17[50];
FILE   *fp12,*fp13,*fp14,*fp15,*fp16,*fp17;
char   flag_Z,flag_M,flag_T;
$char  ilicense_v[13];
$int   count_51;
$char  nofficer[11];
$int   count_barcode=0;

/* 970822, �s�W�Ĥ@���Q�O�I�H�W�U */
$char  iinsurant_pa[11]=" " , ninsurant_pa[31]=" ", ibirth_pa[11], nbenif_pa[31],irel_pa[14];
$char  mm_pa[3], dd_pa[3], yyyy_pa[5];
$int   cy_pa;

$char  ioff_corps[11],ibroker[11],nbroker[13];
$char  sFullName[20]="";
$char  iresource[2]="";

$char  s_dbirth[11],s_dissue[11];
$char  tmp_yyyy[5],tmp_mm[3],tmp_dd[3];
$char  fBarcode_print[2] = " ";
$int   v_iplymonth;
$char  iupdate[11], dupdate[21];;

main(argc,argv)
int  argc;
char **argv;
{
    long  rc , res, rt;
    char  sel_choice[2];
    char  cyear[5], cmonth[3], sOpt[2];

    $WHENEVER sqlerror goto errexit;

    strcpy(DBName,"00");
    strcpy(userid,"930031");

    strcpy(cyear    , isNULLstr(argv[1]));
    strcpy(cmonth   , isNULLstr(argv[2]));
    strcpy(option   , isNULLstr(argv[3]));  /* 1: 2p, 2:5p */
    strcpy(sOpt     , isNULLstr(argv[4]));  /* 1:�U�b��J�p , 4:�έ�W�b��J�p 0:����  8:���ͥ�ca_tmp_no�J�p��(option=9)  9:���ͦbca_tmp_no������O�� */
     
    intopt = atoi( sOpt);

    printf("cyear[%s],cmonth[%s]\n",cyear,cmonth);
    if  ( (strlen(trim(cyear)) == 0) || (strlen(trim(cmonth))==0) )
    {
        printf("2.�п�J�R����Ʀ~�פΤ�������O Ex. --> ply302 2005 01 1\n");
        exit(1);
    }

    iplyyear = atoi(cyear) ;
    iplymonth = atoi(cmonth) ;

    printf("iyear=[%d] imonth=[%d] option=[%s]\n intopt=[%d]",iplyyear, iplymonth, option,intopt);

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
    }

    rt = getApHome(sApHome);
    if (rt < 0) {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
    }

	/* 970219, �B�z�������~���Ҧ�barcode�q�l�ɤ����s */
	rc = prepare_barcode_ioff(iplyyear,iplymonth);
	printf(" prepare_barcode_ioff rc = [%d]\n " , rc);
	if (rc!=M_CM_OK){
		if (rc!=-1){
			printf(" prepare_barcode_ioff-- rc = [%d]\n " , rc);
			return rc;
		}
	}

    /* 980616 */
	rc = no_barcode_list();	
	printf(" no_barcode_list rc = [%d]\n " , rc);	
	if (rc != M_CM_OK)   return rc;	
 
    /* 980727, �����M�׷~�� */ 		
	rc = Mot_Proj20_list();	
	printf(" Mot_Proj20_list rc = [%d]\n " , rc);	
	if (rc != M_CM_OK)   return rc;		

    printf("before temp table iins_class\n");

    $create temp table iins_class
    (
       iins_type  char(6),
       iins_class integer,
       qserial    integer
    )
    with no log;

    printf("create temp table done\n");

    $DECLARE cur_x1 CURSOR FOR
      SELECT iins_type, qserial
        FROM insurance_type
       WHERE iins_type[1] between '0' and '9'
         AND iins_type[2] between '0' and '9'
         AND qserial > 0;
    $OPEN  cur_x1;
    while(1)
    {
      $FETCH cur_x1 INTO $iins_type_i, $qserial_i;
      if(SQLCODE == SQLNOTFOUND) break;

      qserial_j = (int) qserial_i/10 +1;

      $insert into iins_class values( $iins_type_i, $qserial_j, $qserial_i);
    }
    $CLOSE cur_x1;
    $FREE  cur_x1;

    printf("insert complete \n");

    $CREATE TEMP TABLE NO_NASS
   (
       iofficer  char(10)
   )
   WITH NO LOG;

   $INSERT INTO NO_NASS VALUES ("Y61024YS1");
   $INSERT INTO NO_NASS VALUES ("Y61024YS2");
   $INSERT INTO NO_NASS VALUES ("Y61024YS3");
   $INSERT INTO NO_NASS VALUES ("Y61024YS4");
   $INSERT INTO NO_NASS VALUES ("Y61024YS6");
   $INSERT INTO NO_NASS VALUES ("Y61024YC");
   $INSERT INTO NO_NASS VALUES ("Y61024YC2");
   $INSERT INTO NO_NASS VALUES ("711762Q3");
   $INSERT INTO NO_NASS VALUES ("Z61021");
   $INSERT INTO NO_NASS VALUES ("Z6102101");
   $INSERT INTO NO_NASS VALUES ("Z6102102");
   $INSERT INTO NO_NASS VALUES ("Z6102103");
   $INSERT INTO NO_NASS VALUES ("Z6102104");
   $INSERT INTO NO_NASS VALUES ("Z6102105");
   $INSERT INTO NO_NASS VALUES ("Z61021BC");

   sprintf(stmt,"SELECT iofficer FROM NO_NASS where iofficer = ?");
   $PREPARE get_no_nass FROM $stmt;

printf("--------------------3\n");
    if (option[0] == '2')
    {
      /*sprintf(outputf0,"p32_%d_5p_iquota",iplymonth);*/
      sprintf(outputf1,"p32_%d_5p",iplymonth);
      sprintf(outputf2,"p32_ins_%d_5p",iplymonth);

      /*sprintf(file0,"%s",rtrim(outputf0));*/
      sprintf(file1,"%s",rtrim(outputf1));
      sprintf(file2,"%s",rtrim(outputf2));

      /*fp0=fopen(file0,"w");*/
      fp1=fopen(file1,"w");
      fp2=fopen(file2,"w");
    }
     else
    {
      sprintf(outputf1,"p32_%d_2p",iplymonth);
      sprintf(outputf2,"p32_ins_%d_2p",iplymonth);

      sprintf(file1,"%s",rtrim(outputf1));
      sprintf(file2,"%s",rtrim(outputf2));

      fp1=fopen(file1,"w");
      fp2=fopen(file2,"w");

      /* 950814 , ��W�T��9510��O��}�l,���L��O��,���n�ӧO�q�l�� */
      sprintf(outputf12,"p32_%d_2p_Z",iplymonth);
      sprintf(outputf13,"p32_ins_%d_2p_Z",iplymonth);

      sprintf(file12,"%s",rtrim(outputf12));
      sprintf(file13,"%s",rtrim(outputf13));

      fp12=fopen(file12,"w");
      fp13=fopen(file13,"w");

      /* 970515 , �p���p�Ȩ�����q�l�� */
      sprintf(outputf14,"p32_%d_2p_M",iplymonth);
      sprintf(outputf15,"p32_ins_%d_2p_M",iplymonth);

      sprintf(file14,"%s",rtrim(outputf14));
/*
      rt = rptftpinsert(userid,"car302",outputf14);
      if (rt != 0)
      {
          printf("rptftp error\n");
          goto errexit;
     }
*/
      sprintf(file15,"%s",rtrim(outputf15));
/*
       rt = rptftpinsert(userid,"car302",outputf15);
      if (rt != 0)
      {
          printf("rptftp error\n");
          goto errexit;
      }
*/
      fp14=fopen(file14,"w");
      fp15=fopen(file15,"w");

      /* 970515 , �Τ@�F�ʯ���q�l�� */
      sprintf(outputf16,"p32_%d_2p_T",iplymonth);
      sprintf(outputf17,"p32_ins_%d_2p_T",iplymonth);

      sprintf(file16,"%s",rtrim(outputf16));
/*
      rt = rptftpinsert(userid,"car302",outputf16);
      if (rt != 0)
      {
          printf("rptftp error\n");
          goto errexit;
      }
*/
      sprintf(file17,"%s",rtrim(outputf17));
/*
      rt = rptftpinsert(userid,"car302",outputf17);
      if (rt != 0)
      {
          printf("rptftp error\n");
          goto errexit;
      }
*/
      fp16=fopen(file16,"w");
      fp17=fopen(file17,"w");
    }

    sprintf(outputf10,"p32_%d_A09_%d",iplymonth, intopt);
    sprintf(outputf11,"p32_ins_%d_A09_%d",iplymonth, intopt);

    sprintf(file10,"%s",rtrim(outputf10));
    sprintf(file11,"%s",rtrim(outputf11));

    fp10=fopen(file10,"w");
    fp11=fopen(file11,"w");

    sprintf(stmt,
    " SELECT count(*)               \
        FROM policy_302             \
       WHERE Year(dply_begin) = ?   \
         AND Month(dply_begin) = ?  \
         AND ipolicy = ?            ");
    $PREPARE comp_id FROM $stmt;

 sprintf(stmt,
    " SELECT count(*)               \
        FROM reject_policy          \
       WHERE ipolicy = ?            \
         AND fins_grp = '3' ");
    $PREPARE reject_id FROM $stmt;

/* 950828,�p�G�j��Υ��N��L��,�j��n�L  */
    sprintf(stmt,
    " SELECT ilicense               \
        FROM policy_302             \
       WHERE ipolicy = ?           ");
    $PREPARE idchg FROM $stmt;

 sprintf(stmt, "SELECT first 1 ipolicy "
               "  FROM policy_302 "
               " WHERE Year(dply_begin) = ? "
               "   AND Month(dply_begin) = ? "
               "   AND iengine = ? "
               "   AND ilicense = ? "
               "   AND fcard_class = '1' ");

    $PREPARE prepA FROM $stmt;

 sprintf(stmt, "SELECT first 1 ipolicy "
               "  FROM policy_302 "
               " WHERE Year(dply_begin) = ? "
               "   AND Month(dply_begin) = ? "
               "   AND itag = ? "
               "   AND ilicense = ? "
               "   AND fcard_class = '1' ");

    $PREPARE prepB FROM $stmt;

 sprintf(stmt,
    " SELECT dply_bgn_comp,dply_end_comp,comp_prem, \
             lia_ac_cntc,plia_acc_c,fcomp_class,fcomp_class_last, \
             irel_card,irel_card_2,irel_card_3,pre_dply1_bgn,pre_dply1_end, \
             pre_prem1,psex_age,remark1,remark2, icar_type, ichange_note \
        FROM policy_302             \
       WHERE ipolicy = ?            \
         AND Year(dply_begin) = ?   \
         AND Month(dply_begin) = ? ");
    $PREPARE comdtl FROM $stmt;


/* 950704 ,�s�W left join ca_pa_ply_302 �� daily_pay ��� distinct*/
/* �] ca_pa_ply_302 ipolicy, iins_type ����U�����h�� , �G�[�W DISTINCT*/
 sprintf(stmt,
   "  SELECT DISTINCT a.ipolicy,a.iins_type, \
             a.minjured_cover,a.mdeath_cover,a.mdamage_cover,a.mdeduct,a.mprem,a.mins_premium, \
             a.qcoverage,a.pre_inj_cover,a.pre_dea_cover,a.pre_dam_cover,a.pre_deduct,         \
             a.pre_minsprem,a.qserial,a.ch_deduct,a.linnum,a.mdiscount,a.pre_mdiscount,a.qday, \
             a.mexpense,a.mexp_disc,a.ori_inj_cover , a.ori_dea_cover , a.ori_dam_cover ,      \
             a.ori_premium, b.iins_class, nvl(c.daily_pay,0),nvl(c.pre_daily_pay,0), nvl(c.ori_daily_pay,0), b.qserial  \
        FROM ply_ins_type_302 as a \
        INNER JOIN iins_class as b \
              ON a.iins_type = b.iins_type \
         LEFT JOIN ca_pa_ply_302 as c \
              ON a.ipolicy = c.ipolicy AND a.iins_type=c.iins_type \
       WHERE a.ipolicy = ?  \
       ORDER BY  b.iins_class, b.qserial ");
    printf("stmt[%s]\n", stmt);
    $PREPARE ins_dtl FROM $stmt;
    $DECLARE cv_cur CURSOR FOR ins_dtl;

 sprintf(stmt,
    " SELECT count(*)  \
        FROM policy_302 a, ply_ins_type_302 b \
       WHERE a.ipolicy = b.ipolicy \
         AND Year(a.dply_begin) = ?   \
         AND Month(a.dply_begin) = ?  \
         AND a.ipolicy = ?           \
         AND b.iins_type = '47' ");

    $PREPARE prep1 FROM $stmt;

    sprintf(stmt, " SELECT '�ǯu�G'||ibig_office, '�q�ܡG'||itel \
                      FROM ca_big_office \
                     WHERE fclass = ? \
                       AND ibig_comp = ? ");
    $PREPARE prep2 FROM $stmt;

    sprintf(stmt, " SELECT iquota, ileader  \
                      FROM officer \
                     WHERE iofficer = ?");

    $PREPARE prep3 FROM $stmt;

    sprintf( stmt, "SELECT NVL(SUM(NVL(mins_premium,0)),0)"
                   "  FROM ply_ins_type_302 "
                   " WHERE ipolicy = ? ");

    $PREPARE prep4 FROM $stmt;

    sprintf(stmt, " SELECT nname \
                       FROM officer \
                      WHERE iofficer = ?");

    $PREPARE prep6 FROM $stmt;

    sprintf(stmt, "SELECT fgen302file1 \
                     FROM tmp_barcode_officer \
                    WHERE iofficer =? "); 
    $PREPARE preBarcode_off FROM $stmt;   

    sprintf(stmt, "SELECT count(*) \
                     FROM tmp_Mot_Proj20_list \
                    WHERE tmp_iofficer =? ");
    $PREPARE preMot_Proj20 FROM $stmt;    
        
    sprintf( stmt, "SELECT icar_broker \
                      FROM officer_broker \
                     WHERE iofficer = ? ");
    $PREPARE prep_ibroker FROM $stmt; 
                          
    sprintf( stmt, "SELECT nchi_abv \
                      FROM broker_agent \
                     WHERE ibroker = ?");
    $PREPARE prep_nbroker FROM $stmt;                  
    
    /* 970822,�����ɼW�[�@���Q�O�I�H�W�U */               
    sprintf(stmt, "SELECT first 1 nvl(ninsurant,' '),nvl(iinsurant,' '),to_char(dbirth) ,nvl(nbeneficiary,' '), \
                          CASE \
                             WHEN nvl(relation_bene,' ') = '1' THEN '���H' \
                             WHEN nvl(relation_bene,' ') = '2' THEN '�a��' \
                             WHEN nvl(relation_bene,' ') = '3' THEN '�O�Υ������H' \
                             WHEN nvl(relation_bene,' ') = '4' THEN '�ŰȤH' \
                             WHEN nvl(relation_bene,' ') = '5' THEN '�]���޲z�H' \
                             WHEN nvl(relation_bene,' ') = '6' THEN '�k�w�~�ӤH' \
                          ELSE ' ' END AS relation_bene \
                     FROM ca_pa_ply_302 \
                    WHERE ipolicy =? AND iins_type='56' "); 
    $PREPARE prePa_list FROM $stmt;            
printf(" ------- stmt = [%s]\n " , stmt);
    for(s=1;s<=atoi(option);s++)
    {

     if( intopt == 1)
         sprintf( sTmp, " AND option in ('1','9') ");
     else if( intopt == 3)                     /* 970312 */
         sprintf( sTmp, " AND option in ('1','9') AND iofficer not like 'A09%%' ");
     else if(( intopt == 4)||( intopt == 8))   /* 950704 ,�s�W�u���� option=9 (��ca_tmp_no�J�p)*/
         sprintf( sTmp, " AND option = %d ", intopt);
     else if( intopt == 5)                     /* �u���s �έ�W�b��(�toption=9) */     
         sprintf( sTmp, " AND option in ('4','9') AND iofficer like 'A09%%' AND day(dply_begin) <16");
     else if( intopt == 9)                     /* 950704 ,�s�W�u���ͦb ca_tmp_no�������)*/
         sprintf( sTmp, " AND ipolicy in (select ipolicy from newa00:ca_tmp_no)");
     else if( intopt == 6)                     /* �u���s �έ�U�b��(�toption=9) */     
         sprintf( sTmp, " AND option in ('1','9') AND iofficer like 'A09%%' AND day(dply_begin) >15");       
     else
         strcpy( sTmp, " ");
     
     if (option[0] == '2') /*  �O�N�� 5p */
     {
        if (s==1)
        {
        	/* �N�᭱�s�W��order by���[iofficer��(Year(dply_end)-Year(dply_begin))]����̫e�� */
        	/* �o�˥u�n���O�[�b�̫᭱, �N���ݭn��ORDER BY�Ǹ��F */
            /*strcpy(sWhereA," ORDER BY 123,62,117,59,1");*/
            strcpy(sWhereA," ORDER BY 1,64,119,61,3");
                           /*    order by   iofficer/ibig_office, ibig_sales, nproject , iofficer, ipolicy */
        }
        else
        {
        	/* ���� p32_%d_5p_iquota  */
        	 continue; 
            /*strcpy(sWhereA," ORDER BY 73,58,61,1 "); */       /* �[���ɻݪ`�NORDER BY �O�_�����ק� */
            strcpy(sWhereA," ORDER BY 74,59,62,1 "); 
                           /*    order by   iquota, iofficer, ibig_sales , ipolicy */
        }
        
        /*  ****** �`�N:  �p�G���W���L�O�N(ibig_comp not in (....))�A�����`�Nilicense������óB�z 
                          => �b���ɷj�M "�۵M�HID4~7�X"    ********/
        sprintf(stmt,
           "  SELECT iofficer,(Year(dply_end)-Year(dply_begin)),* \
                FROM policy_302                \
               WHERE Year(dply_begin) = ?      \
                 AND Month(dply_begin) = ?     \
                 AND NVL(ibig_comp,' ') != ' ' \
                 AND ibig_comp not in ('L','P') \
                 %s \
        union SELECT ibig_office,(Year(dply_end)-Year(dply_begin)),* \
                FROM policy_302                \
               WHERE Year(dply_begin) = ?      \
                 AND Month(dply_begin) = ?     \
                 AND (NVL(ibig_comp,' ') = ' ' AND iofficer[1] ='W')  \
                 %s \
                 %s ", sTmp, sTmp, sWhereA);

     }
     else
     {  /* �@���  */
     	/* 970219, �ư��X�w(�g��:R*D*)���Ҧ�barcode�q�l�ɤ����s */
        sprintf(stmt,
          "   SELECT ibig_office,(Year(dply_end)-Year(dply_begin)),* \
                FROM policy_302               \
               WHERE Year(dply_begin) = ?     \
                 AND Month(dply_begin) = ?    \
                 AND NVL(ibig_comp,' ') = ' ' \
                 AND iofficer[1] <> 'W'       \
                 %s \
               ORDER BY iquota, ileader, iofficer, icorps, dply_begin ", sTmp);
     }
     /*            AND Year(dply_end) - Year(dply_begin) = 1 \ */

     printf("prepare pre_stmt[%s]\n", stmt);

     $PREPARE  pre_stmt FROM $stmt;
     $DECLARE  CA302_ply_3021 CURSOR FOR pre_stmt;
     if (option[0] == '2')
     {
        $OPEN  CA302_ply_3021 USING $iplyyear,$iplymonth,$iplyyear,$iplymonth;
     }
     else
        $OPEN  CA302_ply_3021 USING $iplyyear,$iplymonth;
     while (1)
     {
     printf("1---remark4[%s]\n", remark4);
     printf("remark6[%s]\n", remark6);
      	strcpy( remark1, " ");
      	strcpy( remark2, " ");
      	strcpy( remark3, " ");
      	strcpy( remark4, " ");
      	strcpy( remark5, " ");
      	strcpy( remark6, " ");
      	strcpy( remark7, " ");
      	strcpy( nproject, " ");
      	strcpy( iemail, " ");
        strcpy( remark_tmp1, " ");
        strcpy( remark_tmp2, " ");

       $FETCH CA302_ply_3021
         INTO $tmp_data, $iYear, $ipolicy,$ipolicy_1,$icard,$fcard_class,
              $irelative_ply,$dply_bgn_comp,$dply_end_comp,$comp_prem,
              $last_policy_2,$last_policy_3,$qply_period,
              $dply_begin,$dply_end,
              $nassured,$ilicense,$ibirth,$fsex,$fmarriage,$nuser,
              $nbenef,$aassured,$itel,$iply_area,$iissue_ym,$ipro_year,
              $ibrand,$nbrand_abbr,$icar_type,$ichange_note,$ncar_type,
              $qcylinder,$iengine,$ibody,$itag,$mcar_price,$pdmg_align,
              $pbrg_align,$plia_align,$qpt,$fpt,$idmg_rate,$dmg_factor,
              $ibrg_rate,$brg_factor,
              $psex_age,$psex_age_damage,$lia_ac_cnt1,$lia_ac_cnt2,$lia_ac_cnt3,
              $lia_ac_cntc,$dmg_ac_cnt1,$dmg_ac_cnt2,$dmg_ac_cnt3,
              $plia_acc,$pdmg_acc,$plia_acc_c,$fcar_class,$dedr_begin,
              $iofficer,$nname,$ibig_office,$ibig_sales,$ibig_policy,
              $ibig_comp,$ibig_branch,$mbusiness,$fcomp_class,
              $fcomp_class_last,$ileader,$aassured_zip,$irel_card,
              $irel_card_2,$irel_card_3,$iquota,$nchi_full,
              $fnation,$v_prem,$v_ori_prem,$tot_prem,
              $ch_ins_grp1,$ch_ins_grp2,$ch_ins_grp3,$pre_dply1_bgn,
              $pre_dply1_end,$pre_prem1,$pre_prem2,$pre_dply2_bgn,
              $pre_dply2_end,$pre_sex_age,$pre_sex_age_damage,$pre_lia_acc,$pre_dmg_acc,$note1,
              $linnum,$sNbrand,$remark1,$remark2,$remark6,$remark7,$LHsIbig_Nname,$iMdiscount,$iTot_mpay,
              $pre_ch_ins_grp1,$pre_ch_ins_grp2,$pre_ch_ins_grp3,$icorps,$ncorps,$pdiscount,
              $fcomp_24,$remark3,$fassured,$tphone_con,$imovephone,$iemail,$remark4,
              $remark5, $nproject, $lia_class, $sNequipment, $iTmp,$s_dbirth,$s_dissue,$iupdate,$dupdate;
            if (SQLCODE == SQLNOTFOUND) break;
            printf(" ------- SQLCODE = [%d]\n " , SQLCODE);
            printf("ipolicy == [%s]\n",ipolicy);
            strcpy(nbrand,sLastChinese(sNbrand,20));
            strcpy(ipolicy, trim(ipolicy ));
     
        /* strcpy( icar_type_chg, " ");*/
        fBarcode_print[0] = ' '; fBarcode_print[1] = '\0'; /* 980910,����O�_���Ȧ�q��barcode,�B�n�L�q����  */        
        if (option[0] == '1'){ /*  �@��� 2p */
         	 /* 970725, �X�w���ݭn�L�sbarcode�~,�P�ɦA�ݭn��O�q���� */
         	 /* 970725, �_�ݭn�L�sbarcode�~,�A�L��O�q����,��car147�]�w�M�w */

             fBarcode_print[0] = ' '; fBarcode_print[1] = '\0';
		     $EXECUTE preBarcode_off INTO $fBarcode_print using $iofficer;
		     if (SQLCODE != SQLNOTFOUND){	     	
		         if (fBarcode_print[0]!='Y'){ /*car147�Ȧ�q����B�]�w���L��O�q���� */
		         	continue;  
		         }
	         }
	         
	         /* 980727, �����M�׷~�ȥu�Lbarcode */ 
	         count_barcode = 0;
		     $EXECUTE preMot_Proj20 INTO $count_barcode using $iofficer;
	         if (count_barcode>0){
	             continue;
	         }	         		          
         } 
         /* 980727 �R���q������ 
         if( ((strncmp(iofficer, "Z03555A", 7) == 0) &&(iofficer[7]==' '||iofficer[7]=='\0')) ||
	      	 ((strncmp(iofficer, "Z03555B", 7) == 0) &&(iofficer[7]==' '||iofficer[7]=='\0')) )
	     {
	     	 continue; 	 �ЮױM�� ���X��O��  
	     }*/

         /* ��������I�q�ܦ�P */
         if( ( ((strncmp(iofficer, "Z61021BC", 8) == 0)&&(iofficer[8]==' '||iofficer[8]=='\0'))||
        	   ((strncmp(iofficer, "Z61021BC1",9) == 0)&&(iofficer[9]==' '||iofficer[9]=='\0'))||
        	   ((strncmp(iofficer, "Z61021BC2",9) == 0)&&(iofficer[9]==' '||iofficer[9]=='\0'))
        	)&& ISMOT(icar_type) )
          {
            continue; 	/* �����I�g�쬰Z61021BC���X��O��  */
          }

          if (fcard_class[0] == '1')
          {
          	  t_count = 0;
              psex_age_c = psex_age;
              /*
              $EXECUTE comp_id
                  INTO $t_count
                 USING $iplyyear,$iplymonth,$irelative_ply;
              */
              /*980910,�Y�ϥ��N�I�b��L���,�u�n�����p���N�渹,�N�����@��j  */
              if(strlen(trim(irelative_ply))>0){
                    t_count=1;	
              }
              if (t_count != 0)
              {
              	   /*   �p�G���N�I�ګO�A�j��n�L   */
                   $EXECUTE reject_id
                       INTO $t_count
                      USING $irelative_ply;

                   /* 950828, �p�G�j��Υ��N��L��,�j��n�L   */
                   $EXECUTE idchg
                       INTO $ilicense_v
                      USING $irelative_ply;

                      strcpy(ilicense_v,trim(ilicense_v));

                   if(strncmp(ilicense,ilicense_v,strlen(ilicense_v)) == 0 ){
                   	    if (t_count == 0){  /* ���L��B���N�I���ګO���j����> �j��󤣥X */                            
                            
                   	      	/*980910,�p�G�j����N�b�P�@�Ӥ���~����W�L,���P����n��W�L */
                   	      	v_iplymonth = 0;
			                $SELECT  month(dply_begin)
			                   INTO  $v_iplymonth
			                   FROM  policy_302 
			                  WHERE  ipolicy = $irelative_ply;
                   	        if (iplymonth==v_iplymonth){
                   	      		 continue;
                   	        }                   	    
                   	   	}
                   }
              }
              else if (option[0] == '2') /* �O�N��j���I�䤣�����p���N�O�� */
              {
                  iCount = 0;
                  if( strlen(trim(iengine)) != 0 && strlen(trim(ilicense)) != 0)
                  {
                      $SELECT count(*)
                         INTO $iCount
                         FROM policy_302
                        WHERE Year(dply_begin) = $iplyyear
                          AND Month(dply_begin) = $iplymonth
                          AND iengine = $iengine
                          AND ilicense = $ilicense
                          AND iofficer[1] = 'W'
                          AND fcard_class = '2';
                  }
                  else if( strlen(trim(itag)) != 0 && strlen(trim(ilicense)) != 0)
                  {
                      $SELECT count(*)
                         INTO $iCount
                         FROM policy_302
                        WHERE Year(dply_begin) = $iplyyear
                          AND Month(dply_begin) = $iplymonth
                          AND itag = $itag
                          AND ilicense = $ilicense
                          AND iofficer[1] = 'W'
                          AND fcard_class = '2';
                  }

                  if( iCount != 0) continue; /* ���P������ or�������M�ץ�B��,�h���X�j���I��O��,�j���I�O�O�֤JB�� */
              }else if (option[0] == '1'){ /* �@���j���I�䤣�����p���N�O�� */
		            /* 980616 ,�T����O�j�� => ��ĳ50�I�� => ���F���s��barcode*/ 
	               	/*   ����G�Ҧ��@��� �]���~�G �^*/
	        	    /*   ���ءG07�B03�B04�B06�B10�B12�B13�B15�B19�B20�B21�B22�B30  */
			        /*        Z12010C(�T���I������O)��car147�]�w���Ȧ�q�����ǤJ��barcode���s,������q����+�q���� */          	        	
	
	                if((strncmp(icar_type,"07",2) == 0) || (strncmp(icar_type,"03",2) == 0) || (strncmp(icar_type,"04",2) == 0) || 
		 	           (strncmp(icar_type,"06",2) == 0) || (strncmp(icar_type,"10",2) == 0) || (strncmp(icar_type,"12",2) == 0) || 
		 	           (strncmp(icar_type,"13",2) == 0) || (strncmp(icar_type,"15",2) == 0) || (strncmp(icar_type,"19",2) == 0) || 
		               (strncmp(icar_type,"20",2) == 0) || (strncmp(icar_type,"21",2) == 0) || (strncmp(icar_type,"22",2) == 0) || 
		 	           (strncmp(icar_type,"30",2) == 0)){
		 	           	
			            printf("ipolicy[%s]\n", ipolicy);
			            if (iofficer[0]!='W'){
			            	iCount = 0; 
			            	/* �b tmp_no_barcode_list ����,����barcode, �ĭ���O��覡 */
			            	$SELECT count(*) INTO $iCount FROM tmp_no_barcode_list
			            	  WHERE tmp_iofficer = $iofficer;
			            	if( iCount == 0){ 
			            		 /********* �P�_�ܦ�����j���L�q����,���H�U���ҥ~ ********/
			                     
			                     /* �Hcar147�]�w���u�� */  		 			            		 
                                 if (fBarcode_print[0]=='Y'){
                                 	  /* 980910,car147�Ȧ�q���]�w�n�L�q����  */
                                 	  
			            	     }else{ /* �Dcar147�Ȧ�q���� */
					                 if( strncmp( iquota, "67", 2) == 0 || strncmp( iquota, "6603", 4) == 0 || strncmp( iquota, "6102", 4) == 0 )				                 
					                 {
					                     /* ����,�Ÿq�Ұ�,���~����~����O�ݥX��O�� */
					                     
					                 }else{  /* �䥦����BarCode��O,���L�q���� */
					                     continue;
					                     
					                 } 			            	     	
			            	     }
				            }else{
				            	/* �b tmp_no_barcode_list ����,����barcode, �ĭ���O��覡 */
				            }	   	   		            		
			            }
				        /*				            
			            strcpy(sFullName, get_car_full_db(ipolicy));
			            sprintf(stmt,
			            "select iresource from %s:ply_relation where ipolicy = '%s'",sFullName, ipolicy );				            
			            printf("Trace -- stmt = [%s] \n",  stmt);
			            $PREPARE get_resource FROM $stmt;
			            $EXECUTE get_resource INTO $iresource;	                					            
			        	if (iresource[0]=='3' || iresource[0]=='4' || iresource[0]=='6' || iresource[0]=='9'){
			        		 if(strncmp(iofficer, "Z12010C", 7) != 0){
			        		    continue;
			        		 }
			        	}
			        	*/
		 	        }
		        }
          }
          else
          {
              psex_age_c= 0;
              if (strlen(trim(irelative_ply)) != 0)
              {
                  psex_age_v = psex_age;
                  $EXECUTE comdtl
                      INTO $dply_bgn_comp,$dply_end_comp,$comp_prem,$lia_ac_cntc,
                           $plia_acc_c,$fcomp_class,$fcomp_class_last,$irel_card,
                           $irel_card_2,$irel_card_3,$pre_dply1_bgn,$pre_dply1_end,
                           $pre_prem1,$psex_age_c,$remark_tmp1, $remark_tmp2, $icar_type_comp, $ichange_note
                     USING $irelative_ply,$iplyyear,$iplymonth;
                  if (SQLCODE == SQLNOTFOUND)
                  {
                      comp_prem = 0;
                      psex_age_c= 0;
                      strcpy(pre_prem1," ");
                      strcpy(fcomp_class," ");
                      strcpy(plia_acc_c," ");
                      strcpy(lia_ac_cntc," ");
                  }
                  else
                  {
                  	  /*970411
                      if( strcmp( icar_type_comp, icar_type_ori) != 0 && icar_type_ori[0] != ' ')
                          sprintf( icar_type_chg, "(%s->%s)", icar_type_ori, icar_type_comp);
                      else
                          strcpy( icar_type_chg, " ");
                       */
                  }

                  if( strlen(trim(remark_tmp1)) > 0 )
                  {
                      if( strlen(trim(remark1)) == 0 )
                      {
                          strcpy( remark1, remark_tmp1);
                          strcpy( remark2, remark_tmp2);
                      }
                      else
                      {
                      	  strcpy( remark4, remark_tmp1);
                      	  
					      /* 980522,a1 �O�@�ӦC�L�t�ӧP�_�Ϊ���,��N�q�� 2p�����b��]�n�L"�y�K�O�O�I�N�B���A�ȡz..." ,���O�o�Ǥ�r�O�g���b�t�ӵ{����,�ä��O��remark?���"a1"�����[�bremark5���åB��b�r��̫e�� */					     
					      /*        remark5(116���)��"a2"�O�@�ӦC�L�t�ӧP�_�Ϊ���,��N�q���b�I�س̤U��C�L"�s�v�I�w���]�t�j���I�ӫO�d��"*/
					      /*        remark5(116���)��"a3"�O�@�ӦC�L�t�ӧP�_�Ϊ���,��N�q�� a1 + a2 */

                          if (remark5[0]=='a' && (remark5[1]=='1'||remark5[1]=='2'||remark5[1]=='3')){
                          	 strcpy(remark5,trim(remark5));
                          	 strcpy(remark_tmp2,trim(remark_tmp2));                          	
                          	 strcat( remark5, remark_tmp2);
                          }else	{
                             strcpy( remark5, remark_tmp2);
                          }
                      }
                  } /* end remark_tmp1 check */

              }  /* end irelative_ply */
              else if (option[0] == '2' && iofficer[0] == 'W' ) /* �O�N��M�ץ�B��L���p�j��O�� */
              {
                  if( strlen(trim(iengine)) != 0 && strlen(trim(ilicense)) != 0)
                  {
                      $EXECUTE prepA INTO $sTmpIply
                         USING $iplyyear,$iplymonth, $iengine, $ilicense;

                      if (SQLCODE == SQLNOTFOUND) {
                          strcpy( sTmpIply, " ");
	                      comp_prem = 0;
	                      psex_age_c= 0;
	                      strcpy(pre_prem1," ");
	                      strcpy(fcomp_class," ");
	                      strcpy(plia_acc_c," ");
	                      strcpy(lia_ac_cntc," ");
                      }
                  }
                  else if( strlen(trim(itag)) != 0 && strlen(trim(ilicense)) != 0)
                  {
                      $EXECUTE prepB INTO $sTmpIply
                         USING $iplyyear,$iplymonth, $itag, $ilicense;

                      if (SQLCODE == SQLNOTFOUND) {
                          strcpy( sTmpIply, " ");
	                      comp_prem = 0;
	                      psex_age_c= 0;
	                      strcpy(pre_prem1," ");
	                      strcpy(fcomp_class," ");
	                      strcpy(plia_acc_c," ");
	                      strcpy(lia_ac_cntc," ");
                      }
                  }
                  else
                      strcpy( sTmpIply, " ");

                  if (strcmp(trim(sTmpIply),"")!=0) /* ��������p�j��*/
                  {
	                  $EXECUTE comdtl
	                      INTO $dply_bgn_comp,$dply_end_comp,$comp_prem,$lia_ac_cntc,
	                           $plia_acc_c,$fcomp_class,$fcomp_class_last,$irel_card,
	                           $irel_card_2,$irel_card_3,$pre_dply1_bgn,$pre_dply1_end,
	                           $pre_prem1,$psex_age_c,$remark_tmp1, $remark_tmp2, $icar_type_comp, $ichange_note
	                     USING $sTmpIply,$iplyyear,$iplymonth;

	                  if (SQLCODE == SQLNOTFOUND)
	                  {
	                      comp_prem = 0;
	                      psex_age_c= 0;
	                      strcpy(pre_prem1," ");
	                      strcpy(fcomp_class," ");
	                      strcpy(plia_acc_c," ");
	                      strcpy(lia_ac_cntc," ");
	                  }
	                  else
	                  {
	                  	 /* 970411
	                      if( strcmp( icar_type_comp, icar_type_ori) != 0 && icar_type_ori[0] != ' ')
	                          sprintf( icar_type_chg, "(%s->%s)", icar_type_ori, icar_type_comp);
	                      else
	                          strcpy( icar_type_chg, " ");
	                      */
	                  }
                }
              }
          }

          if (option[0] == '1')
          {
              if ( iYear == 2)
              {

                  /* �Hcar147�]�w���u�� */  		 			            		 
                  if (fBarcode_print[0] == 'Y'){
                     	 /* 980910,car147�Ȧ�q���]�w�n�L�q����  */
                     	  
            	  }else{ /* �Dcar147�Ȧ�q���� */
		              if( strncmp( iquota, "67", 2) == 0 || strncmp( iquota, "6603", 4) == 0 || strncmp( iquota, "6102", 4) == 0 )				                 
		              {
		                  /* ����,�Ÿq�Ұ�,���~����~��������O�ݥX��O�� */
		                     
		              }else{  /* �䥦����BarCode��O,���L�q���� */
		                  continue;
		                    
		              } 			            	     	
            	  }
              }
          }

       if (strlen(trim(nproject)) > 0 )
       {
           strcpy(nchi_full, trim(nchi_full));
           sprintf(nchi_tmp, "%s%s%s", "(",trim(nproject),")");
           strcat(nchi_full, trim(nchi_tmp));
       }

       /* �O�N�� �۵M�HID4~7�X�H"*"�����N ( ���M(L*)�Υ���(P*)���~ ) */  
       /* �� "��n�]�u��" ���M(L*)�Υ���(P*)�b ca3025q01s.ec �B�z, �G�L�ݦA�B�~�P�_�O�N���� */
       /*  ******  �p�G���W���L�O�N�A�����`�NID���óB�z    ********/
       if (option[0] == '2'){ /*  �O�N�� 5p */
       	   /*if (ibig_comp[0]!='L' && ibig_comp[0]!='P' && ibig_comp[0]!='C'){*/
       	   if (ibig_comp[0]!='L' && ibig_comp[0]!='P'){
       	      if (fassured[0]=='1'||fassured[0]=='3'||fassured[0]=='5'){
                  strncpy(ilicense+(3),"****",4);
               }
           }    
       }else{
       	
           /* �ثe�@���2p���b�䳡��(��O�q����)��ID4~7�X�B�q�ܥ�4�X�B�����e2�X2���� �H"*"�����N ( �]�k�䳡�����n�O�Ѥ��["*"��, �G�ѦC�L�t�ӳB�z ) */  
	       $EXECUTE get_no_nass USING $iofficer;
	       if(SQLCODE == SQLNOTFOUND){ /** nothing happen**/    }
	       else
	       {
	       	   strcpy( iengine, "********************");
	       	   strcpy( ilicense,"**********");
	       }
       }
       /* 950824 ��W�T�� */
   	   if((strncmp( iofficer, "Z03830A1", 8) == 0)  ||
         (strncmp( iofficer, "Z03830A2", 8) == 0)  ||
         (strncmp( iofficer, "Z03830A19", 9) == 0) ||
         (strncmp( iofficer, "Z03830A20", 9) == 0)){

          flag_Z   = 'Y';
       }else{
      	  flag_Z   = 'N';
       }

      /* 970515  �p���p�Ȩ�����  */
  	  if(((strncmp(iofficer, "X62035H",7) == 0) &&(iofficer[7]==' '||iofficer[7]=='\0')) ||
         ((strncmp(iofficer, "X62035J",7) == 0) &&(iofficer[7]==' '||iofficer[7]=='\0')) ||
         ((strncmp(iofficer, "X62035M",7) == 0) &&(iofficer[7]==' '||iofficer[7]=='\0')) ){

           flag_M   = 'Y';
       }else{
       	   flag_M   = 'N';
       }

      /* 970515  �Τ@�F��(�~�Ȩӷ���:����~��)
         980815  �s�W�g��
         X62035,X6203513,X62035B,X62035P,X2035Z,X6203510,X62035A,X62035C,X62035L,X62035U */
/*         
  	  if(((strncmp(iofficer, "X62035A",7) == 0) &&(iofficer[7]==' '||iofficer[7]=='\0')) ||
         ((strncmp(iofficer, "X62035B",7) == 0) &&(iofficer[7]==' '||iofficer[7]=='\0')) ||
         ((strncmp(iofficer, "X62035C",7) == 0) &&(iofficer[7]==' '||iofficer[7]=='\0')) ||
         ((strncmp(iofficer, "X62035L",7) == 0) &&(iofficer[7]==' '||iofficer[7]=='\0')) ||
         ((strncmp(iofficer, "X62035P",7) == 0) &&(iofficer[7]==' '||iofficer[7]=='\0')) ||
         ((strncmp(iofficer, "X62035U",7) == 0) &&(iofficer[7]==' '||iofficer[7]=='\0')) ||                  
         ((strncmp(iofficer, "X62035Z",7) == 0) &&(iofficer[7]==' '||iofficer[7]=='\0')) ||
         ((strncmp(iofficer, "X6203510",8) == 0) &&(iofficer[8]==' '||iofficer[8]=='\0')) ||
         ((strncmp(iofficer, "X6203513",8) == 0) &&(iofficer[8]==' '||iofficer[8]=='\0')) ||
         ((strncmp(iofficer, "X62035" ,6) == 0) &&(iofficer[6]==' '||iofficer[6]=='\0')) ){
*/         
	   /* 980910*/   
	   if (ISTOKYO(iofficer,ilicense)){
           flag_T   = 'Y';
       }else{
       	   flag_T   = 'N';
       }
       
       /*971126, �s�W�g���W�� */        
       if (icorps[0] != ' ' && icorps[0] != '\0'){  /* ¾�Υ� */
            strcpy(ioff_corps,icorps);
       }else{
       	   strcpy(ioff_corps,iofficer);
       }        	
       /* �g���N��(ibroker) */ 
       ibroker[0]='\0';
       strcpy(nbroker , "            ");       
       
       $EXECUTE prep_ibroker INTO $ibroker using $ioff_corps;       
       if ((ibroker[0]!='\0')&&(ibroker[0]!=' ')){
             $EXECUTE prep_nbroker INTO $nbroker using $ibroker;
       	     if ((nbroker[0]!='\0')&&(nbroker[0]!=' ')){
       	     	  strcpy(nbroker , trim(nbroker));
       	     }else{
       	     	  strcpy(nbroker , "            ");
       	     }
       }
       strcpy(prtstr,"17");
       strcat(prtstr,rtrim(ipolicy));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(ipolicy_1));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(icard));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(fcard_class));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(irelative_ply));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(dply_bgn_comp));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(dply_end_comp));
       strcat(prtstr,"\t");
       rfmtlong(comp_prem,"-----&",c_comp_prem);
       strcat(prtstr,rtrim(c_comp_prem));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(last_policy_2));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(last_policy_3));
       strcat(prtstr,"\t");
       strcpy(c_qply_period,itoa(qply_period));
       strcat(prtstr,rtrim(c_qply_period));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(dply_begin));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(dply_end));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(nassured));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(ilicense));
       strcat(prtstr,"\t");
       
       /* 980815, �]���s�Wdbirth ,dissue*/
       if(strlen(trim(s_dbirth)) > 0 ){
	      cm_split_ymd(s_dbirth, tmp_mm, tmp_dd, tmp_yyyy);
	      sprintf(s_dbirth,"%d/%s/%s", atoi(tmp_yyyy)-1911,tmp_mm,tmp_dd);	   
       }else{
       	  strcpy(s_dbirth,"");
       } 
       strcat(prtstr,rtrim(s_dbirth));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(fsex));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(fmarriage));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(nuser));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(nbenef));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(aassured));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(itel));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(iply_area));
       strcat(prtstr,"\t");
       
       /* 980815, �]���s�Wdbirth ,dissue*/  
	   cm_split_ymd(s_dissue, tmp_mm, tmp_dd, tmp_yyyy);
	   sprintf(s_dissue,"%d/%s", atoi(tmp_yyyy)-1911,tmp_mm);	   
       strcat(prtstr,rtrim(s_dissue));   
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(ipro_year));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(ibrand));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(nbrand_abbr));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(icar_type));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(ncar_type));
       strcat(prtstr,"\t");
       strcpy(c_qcylinder,itoa(qcylinder));
       strcat(prtstr,rtrim(c_qcylinder));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(iengine));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(ibody));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(itag));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(mcar_price));
       strcat(prtstr,"\t");
       strcpy(c_pdmg_align,itoa(pdmg_align));
       strcat(prtstr,rtrim(c_pdmg_align));
       strcat(prtstr,"\t");
       strcpy(c_pbrg_align,itoa(pbrg_align));
       strcat(prtstr,rtrim(c_pbrg_align));
       strcat(prtstr,"\t");
       strcpy(c_plia_align,itoa(plia_align));
       strcat(prtstr,rtrim(c_plia_align));
       strcat(prtstr,"\t");
       rfmtdouble(qpt,"---&.&", c_qpt);
       strcat(prtstr,trim(c_qpt));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(fpt));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(idmg_rate));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(ibrg_rate));
       strcat(prtstr,"\t");
       /* 980310 
       rfmtdouble(psex_age,"--&.&&", c_psex_age); 
       strcat(prtstr,trim(c_psex_age));*/
       strcat(prtstr," ");;
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(lia_ac_cnt1));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(lia_ac_cnt2));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(lia_ac_cnt3));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(lia_ac_cntc));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(dmg_ac_cnt1));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(dmg_ac_cnt2));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(dmg_ac_cnt3));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(plia_acc));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(pdmg_acc));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(plia_acc_c));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(fcar_class));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(dedr_begin));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(iofficer));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(nname));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(ibig_office));
       strcat(prtstr,"\t");
       
       /* 980220 */
       strcpy(ibig_sales , trim(ibig_sales));
       if (option[0] == '2'){
	       if (strlen(ibig_sales)>=10){
	       	  if ((iofficer[0]!='A')&&(iofficer[0]!='B')&&(iofficer[0]!='L')&&(iofficer[0]!='N')){
	              strncpy(ibig_sales+(3),"****",4); 
	          }
	       }
       }
       strcat(prtstr,       ibig_sales);
       
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(ibig_policy));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(ibig_comp));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(ibig_branch));
       strcat(prtstr,"\t");
       rfmtdouble(mbusiness,"-------&.&",c_mbusiness);
       strcat(prtstr,trim(c_mbusiness));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(fcomp_class));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(fcomp_class_last));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(ileader));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(aassured_zip));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(irel_card));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(irel_card_2));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(irel_card_3));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(iquota));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(nchi_full));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(fnation));
       strcat(prtstr,"\t");

       if (fcard_class[0] == '2')
           $EXECUTE prep4 INTO $v_prem USING $ipolicy;

       strcpy(c_v_prem,itoa(v_prem));
       strcat(prtstr,rtrim(c_v_prem));
       strcat(prtstr,"\t");

       if (fcard_class[0] == '2')
       {
           tot_prem += comp_prem;
           iTot_mpay += comp_prem;

       }
       strcpy(c_tot_prem,itoa(tot_prem));
       strcat(prtstr,rtrim(c_tot_prem));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(ch_ins_grp1));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(ch_ins_grp2));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(ch_ins_grp3));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(pre_dply1_bgn));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(pre_dply1_end));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(pre_prem1));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(pre_prem2));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(pre_dply2_bgn));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(pre_dply2_end));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(pre_sex_age));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(pre_lia_acc));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(pre_dmg_acc));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(note1));
       strcat(prtstr,"\t");
       if (( intopt != 4 && (strncmp( iofficer,"A09",3)==0 || (strncmp(ibig_office,"A09",3)==0 && iofficer[0] == 'W')))||
             flag_Z == 'Y'||flag_M == 'Y'||flag_T == 'Y')
           ;
       else
           linnum_a += 1;
       strcat(prtstr,rtrim(itoa(linnum_a)));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(nbrand));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(remark1));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(remark2));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(remark6));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(remark7));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(LHsIbig_Nname));
       strcat(prtstr,"\t");
       strcat(prtstr,itoa(iMdiscount));
       strcat(prtstr,"\t");
       strcat(prtstr,itoa(iTot_mpay));
       strcat(prtstr,"\t");
       strcat(prtstr," ");    /*pre_ch_ins_grp1 ���u�o�L�e���ӫO����A�G���������T*/
       strcat(prtstr,"\t");
       strcat(prtstr," ");    /*pre_ch_ins_grp2  */
       strcat(prtstr,"\t");
       strcat(prtstr," ");    /*pre_ch_ins_grp3  */
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(icorps));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(ncorps));
       strcat(prtstr,"\t");
       rfmtdouble(pdiscount,"--&.&&",spdiscount);
       strcat(prtstr,rtrim(spdiscount));
       strcat(prtstr,"\t");
       strcat(prtstr,fcomp_24);
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(remark3));
       strcat(prtstr,"\t");
       strcat(prtstr,fassured);
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(tphone_con));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(imovephone));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(iemail));
       strcat(prtstr,"\t");

       printf("===>3918\n");
       rfmtdouble(psex_age_c,"-&.&&", c_psex_age);
       strcat(prtstr,trim(c_psex_age));
       strcat(prtstr,"\t");
       rfmtdouble(psex_age_v,"-&.&&", c_psex_age);
       strcat(prtstr,trim(c_psex_age));
       strcat(prtstr,"\t");
       rfmtdouble(dmg_factor,"-&.&&&&", c_dmg_factor);
       strcat(prtstr,trim(c_dmg_factor));
       strcat(prtstr,"\t");
       rfmtdouble(brg_factor,"-&.&&&&", c_brg_factor);
       strcat(prtstr,trim(c_brg_factor));
       strcat(prtstr,"\t");

       strcpy(c_v_prem,itoa(v_ori_prem));
       strcat(prtstr,rtrim(c_v_prem));
       strcat(prtstr,"\t");

       printf("===>3936\n");
       if (fcard_class[0] == '2')
       {
           printf("ipolicy[%s] v_ori_prem[%d] comp_prem[%d]\n",
                   ipolicy, tot_ori_prem, comp_prem );
           tot_ori_prem = v_ori_prem + comp_prem;
           printf("ipolicy[%s] tot_ori_prem[%d]\n", ipolicy, tot_ori_prem);
       }
       else
       {
           tot_ori_prem = comp_prem + v_ori_prem;
       }
       strcpy(c_tot_prem,itoa(tot_ori_prem));	printf("c_tot_prem[%s]\n", c_tot_prem );
       strcat(prtstr,rtrim(c_tot_prem));
       strcat(prtstr,"\t");
printf("6---remark4[%s]\n", remark4);
       strcat(prtstr,rtrim(remark4));
       strcat(prtstr,"\t");
       strcat(prtstr,rtrim(remark5));
       strcat(prtstr,"\t");
       sNequipment[13] = '\0';
       strcat(prtstr, sNequipment);
       strcat(prtstr,"\t");

       if (option[0] == '1')   /* �@�����޲z�H��줧�q�ܤζǯu  */
       {
           strcpy( fclass, "3");

           $EXECUTE prep3 INTO $sTmp, $tmp_ileader USING $ileader;
           sTmp[4] = '0';
           sTmp[5] = '0';

          if( ileader[0] == '6') /* �����޲z�H�����H��޲z�H����쬰��� */
          {
              $EXECUTE prep3 INTO $sTmp, $sTmp1 USING $tmp_ileader;
              sTmp[4] = '0';
              sTmp[5] = '0';
          }

           $EXECUTE prep2 INTO $iquota_fax, $iquota_tel USING $fclass, $sTmp;

           if(SQLCODE == SQLNOTFOUND)
           {
                strcpy( iquota_fax, " ");
                strcpy( iquota_tel, " ");
           }

       }
       else
       {
           strcpy( iquota_fax, " ");
           strcpy( iquota_tel, " ");
       }
       strcat(prtstr, iquota_tel);
       strcat(prtstr,"\t");
       strcat(prtstr, iquota_fax);
       strcat(prtstr,"\t");
       strcpy(ichange_note, trim(ichange_note));
       strcat(prtstr, ichange_note);
       strcat(prtstr,"\t");

       /* 970414 ,�s�W��X���:�g��H�W�� */
       $EXECUTE prep6 INTO $nofficer USING $iofficer;
       if(SQLCODE == SQLNOTFOUND){
      	   strcpy(nofficer, " ");
       }else{
      	   strcpy(nofficer, trim(nofficer));
       }
       strcat(prtstr, nofficer);
       strcat(prtstr,"\t");
       
       strcat(prtstr, nbroker);  /* 971126,�s�W�g���W�� */
       strcat(prtstr,"\t");
       /*
       strcat(prtstr, iupdate);   981001,�s�W�J�p�H��id 
       strcat(prtstr,"\t");
       */
       


       flag_A09 = 'N';

      if (s == 1)
      {
          flagE = 0;
          switch( ibig_comp[0] )
          {
             case 'E':
                fprintf(fp8,"%s\n",prtstr);
                flagE = 1;
             default:

                if ( strncmp( iofficer,"A09",3)==0 || (strncmp(ibig_office,"A09",3)==0 && iofficer[0] == 'W'))
                {
                      flag_A09 = 'Y';
                      flag_Z   = 'N';
                      flag_M   = 'N';
                      flag_T   = 'N';
                      fprintf(fp10,"%s\n",prtstr);

                }else if(flag_Z == 'Y'){
                	  flag_A09 = 'N';
                      flag_M   = 'N';
                      flag_T   = 'N';
                	  fprintf(fp12,"%s\n",prtstr);

                }else if(flag_M == 'Y'){
                	  flag_A09 = 'N';
                      flag_Z   = 'N';
                      flag_T   = 'N';
                	  fprintf(fp14,"%s\n",prtstr);

                }else if(flag_T == 'Y'){
                	  flag_A09 = 'N';
                	  flag_Z   = 'N';
                      flag_M   = 'N';
                	  fprintf(fp16,"%s\n",prtstr);

                }else{
                      flag_A09 = 'N';
                      flag_Z   = 'N';
                      flag_M   = 'N';
                      flag_T   = 'N';
                      fprintf(fp1,"%s\n",prtstr);
                }
                GiCnt ++;
                break;
          }
      }
      else
      {
      	  /*
          if ( strncmp( iofficer,"A09",3)==0 || (strncmp(ibig_office,"A09",3)==0 && iofficer[0] == 'W'))
              ;
          else
             fprintf(fp0,"%s\n",prtstr);*/  /*iquota ��*/
      }

     printf("\n\nstart unload ins data\n");

     if (s == 1)
     {
        $OPEN cv_cur USING $ipolicy;
        for(;;)
        {
           $FETCH cv_cur
             INTO $ipolicy,$iins_type,
                  $minjured_cover,$mdeath_cover,$mdamage_cover,$mdeduct,$mprem,$mins_premium,
                  $qcoverage,$pre_inj_cover,$pre_dea_cover,$pre_dam_cover,$pre_deduct,
                  $pre_minsprem,$qserial,$ch_deduct,$linnum,$d_mdiscount,$d_pre_mdiscount,$qday,
                  $mexpense,$mexp_disc,$ori_inj_cover,$ori_dea_cover, $ori_dam_cover,
                  $ori_premium, $iins_class, $ldaily_pay,$pre_daily_pay,$ori_lDaily_pay,$qserial_tmp;
           if (SQLCODE == SQLNOTFOUND) break;

           if( qcoverage == 1 )
           {
               if (strncmp(iins_type,"56",2) == 0)  /* 950704, 56 �O�B��=1,�����L3�� */
              	 iins_line = 3;
             else
                 iins_line = 1;
           }
           else if( qcoverage == 2 )
           {
              iins_line = 3;
           }
           else if( qcoverage == 3 )
           {
              iins_line = 4;
           }
           if( strcmp(trim(iins_type),"21")==0)
           {
                qserial = 99;
           }

           strcpy(prtstr,"17");
           strcat(prtstr,rtrim(ipolicy));
           strcat(prtstr,"\t");
           strcat(prtstr,rtrim(iins_type));
           strcat(prtstr,"\t");
           rfmtlong(minjured_cover,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           rfmtlong(mdeath_cover,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           rfmtlong(mdamage_cover,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           rfmtlong(mdeduct,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           rfmtlong(mprem,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           rfmtlong(mins_premium,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           rfmtlong(qcoverage,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           rfmtlong(pre_inj_cover,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           rfmtlong(pre_dea_cover,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           rfmtlong(pre_dam_cover,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           rfmtlong(pre_deduct,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           rfmtlong(pre_minsprem,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           rfmtlong(qserial,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           strcat(prtstr,trim(ch_deduct));
           strcat(prtstr,"\t");
           strcat(prtstr,trim(itoa(linnum_a)));
           strcat(prtstr,"\t");
           strcat(prtstr,itoa(d_mdiscount));
           strcat(prtstr,"\t");
           strcat(prtstr,itoa(d_pre_mdiscount));
           strcat(prtstr,"\t");
           rfmtlong(qday,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           rfmtlong(mexpense,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           rfmtlong(mexp_disc,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");

           rfmtlong(ori_inj_cover,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           rfmtlong(ori_dea_cover,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           rfmtlong(ori_dam_cover,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           rfmtlong(ori_premium,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           rfmtlong(iins_line,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");

           /* 950704 ,56�I�� �������B*/
           rfmtlong(ldaily_pay,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           
           /* 970822,�����ɼW�[�@���Q�O�I�H�W�U */ 
      	   strcpy(iinsurant_pa, " ");
      	   strcpy(ninsurant_pa, " ");
      	   strcpy(ibirth_pa, " ");
      	   strcpy(nbenif_pa, " ");
      	   strcpy(irel_pa, " ");                       
           if (strncmp(iins_type,"56",2) == 0){	           
	           $EXECUTE prePa_list INTO $ninsurant_pa, $iinsurant_pa, $ibirth_pa, $nbenif_pa, $irel_pa 
	             USING $ipolicy;
		       if((SQLCODE == SQLNOTFOUND)||(iinsurant_pa[0]==' ')||(iinsurant_pa[0]=='\0')){		      	   
		      	   strcpy(ninsurant_pa, " ");
		      	   strcpy(iinsurant_pa, " ");
		      	   strcpy(ibirth_pa, " ");
		      	   strcpy(nbenif_pa, " ");
		      	   strcpy(irel_pa, " ");
		       }else{
	               cm_split_ymd(ibirth_pa, mm_pa, dd_pa, yyyy_pa);
	               cy_pa = atoi(yyyy_pa)-1911;
	               sprintf(ibirth_pa,"%d%s%s",cy_pa,mm_pa, dd_pa);
	               strcpy(ninsurant_pa,rtrim(ninsurant_pa));
	               strcpy(iinsurant_pa,rtrim(iinsurant_pa));
	               strcpy(ibirth_pa,rtrim(ibirth_pa));
	               strcpy(nbenif_pa,rtrim(nbenif_pa));
	               strcpy(irel_pa,rtrim(irel_pa));
	               strncpy(iinsurant_pa+(3),"****",4);	                 
		       }
		       printf(" ------- iinsurant_pa = [%s]\n " , iinsurant_pa);
		       printf(" ------- ibirth_pa = [%s]\n " , ibirth_pa);
	       }
           strcat(prtstr,rtrim(ninsurant_pa));
           strcat(prtstr,"\t");
           strcat(prtstr,rtrim(iinsurant_pa));
           strcat(prtstr,"\t");
           strcat(prtstr,rtrim(ibirth_pa));
           strcat(prtstr,"\t");
           strcat(prtstr,rtrim(nbenif_pa));
           strcat(prtstr,"\t");
           strcat(prtstr,rtrim(irel_pa));
           strcat(prtstr,"\t");
           
           /* 980416 ,56�I�� �������B���O�զX�B�h�~��O�զX*/
           rfmtlong(ori_lDaily_pay,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");
           rfmtlong(pre_daily_pay,fmt,xmp);
           strcat(prtstr,trim(xmp));
           strcat(prtstr,"\t");           
	       
           if(flagE == 1 )
           {
               fprintf(fp9,"%s\n",prtstr);
           }

           if(flag_A09 == 'Y' ){
               fprintf(fp11,"%s\n",prtstr);
           }else if(flag_Z == 'Y'){
           	   fprintf(fp13,"%s\n",prtstr);
           }else if(flag_M == 'Y'){
           	   fprintf(fp15,"%s\n",prtstr);
           }else if(flag_T == 'Y'){
           	   fprintf(fp17,"%s\n",prtstr);
           }else{
               fprintf(fp2,"%s\n",prtstr);
           }
        }
        $CLOSE cv_cur;


     } /* END fprintf ply_ins_type_302   */

    }
    $CLOSE CA302_ply_3021;
    $FREE CA302_ply_3021;
  }

   if (option[0] == '2')
   {
     /* fclose(fp0);*/
      fclose(fp1);
      fclose(fp2);
      fclose(fp8);
      fclose(fp9);
   }
   else
   {
      fclose(fp1);
      fclose(fp2);
      fclose(fp12);
      fclose(fp13);
   }

   fclose(fp10);
   fclose(fp11);

   $drop table iins_class;
   $drop table NO_NASS;

   exit(0);

errexit:
    printf("SOLCODE=%d sqlca.sqlerrm=%s\n",SQLCODE,sqlca.sqlerrm);
    printf(errmsg,"SOLCODE=%s sqlca.sqlerrm=%s",SQLCODE,sqlca.sqlerrm);
    fprintf(fptr_err,"%s\n",errmsg);
    exit(0);
}

char *sLastChinese(sStrTmp,iStrLen)
char *sStrTmp;
int  iStrLen;
{
int  iTrueLen;
int  i,x;


     iTrueLen = strlen(rtrim(sStrTmp));

     if (iStrLen > iTrueLen) return sStrTmp;
     sStrTmp[iStrLen] = '\0';

     for(i = 0; i< iStrLen; i++){
         if ((int)(sStrTmp[i]) >= 128){
                x = i;
                i++;
         }
     }

     if ((iStrLen - 1) == x) {
          sStrTmp[x] = '\0';
     }

     return sStrTmp;


}

long prepare_barcode_ioff(iplyyear,iplymonth)
int iplyyear,iplymonth;
{

	$char sSQL[1024]=" ";
	$char icode_no[11],officer_type[2],iofficer[21];
	$char s_iofficer[11];
	int i_officer_type;
	$char sWhere[31],s1[20];
     short  plymdy[3];
     long   plydate;
	 int    i,j;
	$int    chk_count = 0;
	char *p1,*p2,*ioff;
	char  ioff_item[3][1][5]={" "," "," "};
	
	$char fgen302file1[2],fgen302file2[2];

	$WHENEVER SQLERROR GOTO errexit;
	$CREATE TEMP TABLE tmp_barcode_officer
	(
	    icode_no       char(10)    NOT NULL,
	    iofficer       char(10)    NOT NULL,
	    fgen302file1   char(1)     NOT NULL,
	    fgen302file2   char(1)     NOT NULL
	) WITH NO LOG;
    $CREATE INDEX idx_barcode_off_0 ON tmp_barcode_officer(icode_no);
    $CREATE INDEX idx_barcode_off_1 ON tmp_barcode_officer(iofficer);
    
	/* ��O�~���(��=01)*/
    plymdy[2] = (short)iplyyear;
    plymdy[0] = (short)iplymonth;
    plymdy[1] = (short)(1);

    rmdyjul(plymdy,&plydate);

    sprintf(sSQL,"SELECT a.icode_no, a.officer_type, a.iofficer, b.fgen302file1, b.fgen302file2 \
                    FROM sysdb:car302_barcode_officer a ,sysdb:car302_barcode_setup b \
                   WHERE a.icode_no = b.icode_no AND b.dbegin <= %ld AND b.dend >= %ld ",
                 plydate,plydate);
    /*
    sprintf(sSQL,"SELECT %s FROM %s WHERE icode_no in (select icode_no from sysdb:car302_barcode_setup where dbegin <= %ld and dend >= %ld)",
                 "icode_no,officer_type,iofficer",
                 "sysdb:car302_barcode_officer ",
                 plydate,
                 plydate);  */
                 
    printf("sSQL[%s]\n" , sSQL);
                 
    $PREPARE PRE_STMT FROM $sSQL;
    $DECLARE CUR_Officer CURSOR for PRE_STMT;
    $OPEN CUR_Officer ;
    while (1)
    {
       $FETCH CUR_Officer INTO $icode_no,$officer_type,$iofficer,$fgen302file1,$fgen302file2;
        
       printf("SQLCODE[%d]\n" , SQLCODE);       
       if (SQLCODE == SQLNOTFOUND) break;
       chk_count++;
       
       printf("icode_no[%s]\n" , icode_no);
       printf("officer_type[%s]\n" , officer_type);
       printf("iofficer[%s]\n" , iofficer);
               

        strcpy(s_iofficer,trim(iofficer));
        printf("s_iofficer[%s]\n" , s_iofficer); 
        
        /* 1:�g��N��, 2:�g���N�� ,3: �g��N��*(1) 4. �g��N��*(2) */
        i_officer_type = atoi(officer_type);
        switch (i_officer_type){
         	 case 1:
                sprintf(sSQL, "INSERT INTO tmp_barcode_officer values('%s','%s','%s','%s')",
                             icode_no,s_iofficer,fgen302file1,fgen302file2);
         	 	break;

         	 case 2:
                sprintf(sSQL, "INSERT INTO tmp_barcode_officer \
                               SELECT '%s',iofficer,'%s','%s' FROM sysdb:officer_broker Where icar_broker = '%s'",
                             icode_no,fgen302file1,fgen302file2,s_iofficer);
         	 	break;

         	 case 3:
                sprintf(sSQL, "INSERT INTO tmp_barcode_officer \
                               SELECT '%s',iofficer,'%s','%s' FROM sysdb:officer Where iofficer matches '%s'",
                             icode_no,fgen302file1,fgen302file2,s_iofficer);

         	 	break;

         	 case 4:
				ioff = strtok(s_iofficer,"|") ;       /* ex. 1-R|7-D */
				printf("ioff[%s]\n" , ioff);
				strcpy(sWhere," ");
				i=0;

				while(ioff != NULL){                  /* => ioff = "1-R" */

					 printf("i[%d]\n" , i);
				     strcpy(ioff_item[i][0] ,ioff);
				     printf("ioff_item[%d][0][%s]\n" ,i, ioff_item[i][0]);
					 i++;
		             ioff = strtok(NULL,"|");         /* ���o�U�@�� ioff => "7-D" */
		             printf("ioff[%s]\n" , ioff);
				}

				for (j=0;j<3;j++){
					if (strncmp(ioff_item[j][0]," ",1)!=0){
						  p1 = strtok(ioff_item[j][0],"-") ;   /* p = 1 */
						  if (p1 != NULL){
						  	  p2 = strtok(NULL,"-");           /* ���o�U�@�� p = R */
						  }else{
						  	  break;
						  }
						  printf("p1[%s],p2[%s]\n" , p1, p2);
					      s1[0]='\0';
					      sprintf(s1," iofficer[%d] = '%c'", atoi(p1), p2[0]);
					      if (j==0){
					      	strcat(sWhere, s1);
					      }else{
					      	strcat(sWhere, " AND ");
					      	strcat(sWhere, s1);
					      }
					}
				}
			    printf("sWhere[%s]\n" , sWhere);

                sprintf(sSQL, "INSERT INTO tmp_barcode_officer \
                                  SELECT '%s',iofficer,'%s','%s' FROM sysdb:officer WHERE %s",
                             icode_no,fgen302file1,fgen302file2, sWhere);
         	 	break;
         	default:
         		continue;
        }

        printf("Insert tmp_barcode_officer sSQL[%s]\n" , sSQL);
        $PREPARE pre_tmp FROM $sSQL;
        $EXECUTE pre_tmp;

    }
    $close CUR_Officer;
    $free  CUR_Officer;
    if (chk_count==0) return -1; /* ������O�~��L���Ĥ��]�w�ɻݮM�� */


    #ifdef PRINTF_FLAG
        i=0 ;
        sprintf(sSQL, "SELECT icode_no,iofficer,fgen302file1,fgen302file2 FROM tmp_barcode_officer");
	    $PREPARE PRE_STMT FROM $sSQL;
	    $DECLARE CUR_tmp1 CURSOR for PRE_STMT;
	    $OPEN CUR_tmp1 ;
	    while (1)
	    {
	       $FETCH CUR_tmp1 INTO $icode_no, $iofficer,$fgen302file1,$fgen302file2;
	       printf("SQLCODE[%d]\n" , SQLCODE);
	       if (SQLCODE != 0) break;
	       i++;
	       printf("[%d]: icode_no[%s] iofficer[%s]\n " ,i, icode_no,iofficer);
	       printf("[%d]: fgen302file1[%s] fgen302file2[%s]\n " ,i, fgen302file1,fgen302file2);

        }
        $CLOSE CUR_tmp1;
        $FREE CUR_tmp1;
    #endif
    chk_count = 0;
    $SELECT count(*) INTO $chk_count FROM tmp_barcode_officer;
    printf("SQLCODE[%d]\n" , SQLCODE);
    printf(" ------- chk_count = [%d]\n " , chk_count);
    if (chk_count>0){
    	return M_CM_OK;
    }else{
    	return -1;
    }


errexit:
   printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   return SQLCODE;

}

/*----------------------------------------------------------------------------*/
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}


long no_barcode_list()
{
	$WHENEVER SQLERROR GOTO errexit;
	$CREATE TEMP TABLE tmp_no_barcode_list
	(
	    tmp_iofficer       char(10)    NOT NULL
	)WITH NO LOG;

    $INSERT INTO tmp_no_barcode_list 
      SELECT iofficer FROM officer 
       WHERE 
          iofficer matches 'Y*WC*'
          OR  iofficer matches 'Y*VH*'
          OR  iofficer matches 'Z*TM'
          OR  iofficer matches 'Y*AN*'
          OR  iofficer matches 'X*' ;

    $insert into tmp_no_barcode_list values('710132');
    $insert into tmp_no_barcode_list values('710132A');
	$insert into tmp_no_barcode_list values('710132QB');
	$insert into tmp_no_barcode_list values('710132QG');
	$insert into tmp_no_barcode_list values('710132QR');
	$insert into tmp_no_barcode_list values('711030QB1');
	$insert into tmp_no_barcode_list values('712127');
	$insert into tmp_no_barcode_list values('712127QC1');
	$insert into tmp_no_barcode_list values('712251QC');
	$insert into tmp_no_barcode_list values('790378');
	$insert into tmp_no_barcode_list values('910507');
	$insert into tmp_no_barcode_list values('910507QF');
	$insert into tmp_no_barcode_list values('97A0697001');
	$insert into tmp_no_barcode_list values('97A1005001');
	$insert into tmp_no_barcode_list values('Y03613YQ');
	$insert into tmp_no_barcode_list values('Y03620YC');
	$insert into tmp_no_barcode_list values('Y03620ZU');
	$insert into tmp_no_barcode_list values('Y61017P');
	$insert into tmp_no_barcode_list values('Y61024EZ');
	$insert into tmp_no_barcode_list values('Y61024F001');
	$insert into tmp_no_barcode_list values('Y61024F002');
	$insert into tmp_no_barcode_list values('Y61024GF');
	$insert into tmp_no_barcode_list values('Y61024HN');
	$insert into tmp_no_barcode_list values('Y61024TF');
	$insert into tmp_no_barcode_list values('Y62025E001');
	$insert into tmp_no_barcode_list values('Y63026E001');
	$insert into tmp_no_barcode_list values('Y63624VZ01');
	$insert into tmp_no_barcode_list values('Y63631E002');
	$insert into tmp_no_barcode_list values('Y64027AS');
	$insert into tmp_no_barcode_list values('Y64027E001');
	$insert into tmp_no_barcode_list values('Y64027F001');
	$insert into tmp_no_barcode_list values('Y66036AU');
	$insert into tmp_no_barcode_list values('Y66036AZ01');
	$insert into tmp_no_barcode_list values('Y66036BU');
	$insert into tmp_no_barcode_list values('Y66036EZ');
	$insert into tmp_no_barcode_list values('Y66036GN');
	$insert into tmp_no_barcode_list values('Y66036HE');
	$insert into tmp_no_barcode_list values('Y66036II');
	$insert into tmp_no_barcode_list values('Z12010C');           
    
  	return M_CM_OK;


errexit:
   printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   return SQLCODE;

}

/* 980727,�����M�׷~�ȸg��N���A���G
   �u�x�_�M�סv���@�~���M�� �P �D�u�x�_�M�סv���G�~���M��
*/
long Mot_Proj20_list()
{
	$WHENEVER SQLERROR GOTO errexit;
	$CREATE TEMP TABLE tmp_Mot_Proj20_list
	(
	    tmp_iofficer       char(10)    NOT NULL,
	    tmp_ProjYear       integer     NOT NULL
	)WITH NO LOG;

    /*�u�x�_�M�סv���@�~���M�� */
    $INSERT INTO tmp_Mot_Proj20_list 
      SELECT iofficer,1 FROM officer 
       WHERE 
          iofficer matches 'Y62025YF*'
          OR  iofficer matches 'Y62032HV*';
     
    $insert into tmp_Mot_Proj20_list values('98A0825001',1);
    $insert into tmp_Mot_Proj20_list values('Y62032EY05',1);
    $insert into tmp_Mot_Proj20_list values('Y62032EY06',1);
    $insert into tmp_Mot_Proj20_list values('Y62032EY07',1);
    $insert into tmp_Mot_Proj20_list values('Y62032EY08',1);
    $insert into tmp_Mot_Proj20_list values('Y67044CY04',1);
    $insert into tmp_Mot_Proj20_list values('Z6202214',1);
    $insert into tmp_Mot_Proj20_list values('Z6202215',1);
    $insert into tmp_Mot_Proj20_list values('Z6202216',1);
    $insert into tmp_Mot_Proj20_list values('Z6202217',1);
    $insert into tmp_Mot_Proj20_list values('Z6202218',1);
    $insert into tmp_Mot_Proj20_list values('Z6202219',1);
    $insert into tmp_Mot_Proj20_list values('Z6202220',1);
    $insert into tmp_Mot_Proj20_list values('Z6202221',1);
    $insert into tmp_Mot_Proj20_list values('Z6202222',1);
    $insert into tmp_Mot_Proj20_list values('Z6202223',1);
    $insert into tmp_Mot_Proj20_list values('Z6202227',1);
    $insert into tmp_Mot_Proj20_list values('Z6202228',1);
    $insert into tmp_Mot_Proj20_list values('Z6202229',1);
    $insert into tmp_Mot_Proj20_list values('Z6202230',1);
    $insert into tmp_Mot_Proj20_list values('Z6202231',1);
    $insert into tmp_Mot_Proj20_list values('Z6202232',1);
    $insert into tmp_Mot_Proj20_list values('Z6202233',1);
    $insert into tmp_Mot_Proj20_list values('Z6202234',1);
    $insert into tmp_Mot_Proj20_list values('Z6202235',1);
    $insert into tmp_Mot_Proj20_list values('Z6202236',1);
    $insert into tmp_Mot_Proj20_list values('Z6202238',1);

    /*�D�u�x�_�M�סv���G�~���M��*/
    $insert into tmp_Mot_Proj20_list values('98A0825002',2);
    $insert into tmp_Mot_Proj20_list values('Y66036BI02',2);
    $insert into tmp_Mot_Proj20_list values('Y66036BI03',2);

  	return M_CM_OK;


errexit:
   printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   return SQLCODE;

}