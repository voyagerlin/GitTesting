/**********************************************************************/
/*                                                                    */
/*   program id   : ca212q01s.ec                                      */
/*   program name : ���ڲ��ʩ��Ӫ�                                    */
/*   date written : 2005/01/25                                        */
/*   date modify  :                                                   */
/*   author       : Neo Chen                                          */
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "safeclib.h"

/*--------------------------------------------------------------------*/
$char  t_data1[13], t_data2[13], option[2];
$char  rcpbgn[11], rcpend[11], dbegin[11], dend[11];
$char  ireceipt[11], ipolicy_begin[21], ipolicy_end[21], iendorse_begin[21], iendorse_end[21];
$char  fstatus[2], iprint[13], dprint[13], ialter[13], dalter[13];
$char  dply_edr_begin[13], dply_edr_end[13], itag[10], iengine[21], nassured[61];
$char  dpol_endorse[13], nbranch[13], smt_status[13], status[2];

$long  mpremium = 0;

$char DBName[05], iForm_Tp[03];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[N_FILE+1]; 
$char userid[11],choice[2];

char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;

static int  max_cnt,num;

long car212_build();
void car212_title();
long car212_body();
void car212_print();
void car212_print_1();
void car212_put_body4();
long car3212_main();
static char *get_car_full_db();  /*   �ǤJ�O�渹��X���O�檺�k�ݸ�Ʈw */
static float MyPower();
double dbl_len8();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;

   batchinit();
   $WHENEVER SQLERROR GOTO errexit;
   strcpy(DBName,  isNULLstr(argv[1]));
   strcpy(userid,  isNULLstr(argv[2]));
   strcpy(option,  isNULLstr(argv[3]));
   strcpy(t_data1, isNULLstr(argv[4]));
   strcpy(t_data2, isNULLstr(argv[5]));
   strcpy(status,  isNULLstr(argv[6]));
   strcpy(outputf, isNULLstr(argv[7]));

   if( option[0] == '1' )
   {
       /** t_data �����ڽs�� **/
       strcpy( rcpbgn, t_data1 );
       strcpy( rcpend, t_data2 );
   }
   else 
   {
   	/** t_data ���C�L��� or ���ʤ��  **/
       strcpy(dbegin, cm_to_infdate(t_data1));
       strcpy(dend,   cm_to_infdate(t_data2));
   }
   
   printf("option [%s] t_data1[%s] t_data2[%s]\n",
           option,  t_data1, t_data2 );
   printf("dbegin [%s] dend [%s] \n", dbegin, dend );
   printf("rcpbgn [%s] rcpend[%s] \n", rcpbgn, rcpend );
   
   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   max_cnt=0;
   rc = car212_build();
   
   if (rc != FAIL)
   {
       if ((rc=save_form_info(F_BLK0, "CA", 212, userid, iForm_Tp, max_cnt, outputf))<0) {
           strcpy(msgbuf,"save_form_info failed");
           return rc;
       }
   }
   
   return ;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
   
}
/*--------------------------------------------------------------------*/

long car212_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc,rtncode;
   $char stmt[500];
   
   
   $WHENEVER SQLERROR GOTO errexit;  
   
   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth ,iform_tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width ,$iForm_Tp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 212;

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
   sprintf_s(BodyFile, sizeof BodyFile,"%s.bd",outputf);

   printf("@@@@@@@@@@@@@@@@@@ titlefmt = [%s]",TitleFile);
   printf(" iForm_Tp [%s] \n",iForm_Tp);

   rgu_init_report(TitleFmt,TitleFile);
   car212_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);

   rtncode = car212_body();
   if( rtncode != M_CM_OK )
       return rtncode;
   
   rgu_finish_report();
   
   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}

void car212_title()
{
   rgu_put_head_string(1," ");
   rgu_put_head_string(1," ");  
   rgu_put_head();
}


long car212_body()
{
  $char stmt[1024], stmt_buf1[1024], stmt_state[200];
  $char fulldbname[20], tmp_buf[14];
  int   ifstatus;
   
  max_cnt = 0;
  
  if( option[0] == '1' )
  {
     rgu_put_body_string(1,"���ڸ��X",1);
     rgu_put_body_string(1,rcpbgn,1);
     rgu_put_body_string(1,rcpend,1);
  }
  else if( option[0] == '2' )
  {
     rgu_put_body_string(1,"�C�L���",1);
     rgu_put_body_string(1,dbegin,1);
     rgu_put_body_string(1,dend,1);
  }
  else
  {
     rgu_put_body_string(1,"���ʤ��",1);
     rgu_put_body_string(1,dbegin,1);
     rgu_put_body_string(1,dend,1);
  }
  
  rgu_put_body_string(1, cm_get_sysd(),1);
  rgu_put_body(1);
   
  max_cnt += 6;
  $WHENEVER SQLERROR GOTO errexit;
  
  if( option[0] == '1' )
  {
      sprintf_s(stmt_buf1, sizeof stmt_buf1,"ireceipt >= '%s' AND ireceipt <= '%s'",rcpbgn, rcpend );
  }
  else if( option[0] == '2' )
  {
      sprintf_s(stmt_buf1, sizeof stmt_buf1," dprint >= '%s' AND dprint <= '%s'",dbegin, dend );
  }
  else
  {
      sprintf_s(stmt_buf1, sizeof stmt_buf1," dalter >= '%s' AND dalter <= '%s'",dbegin, dend );
  }
  
  if( status[0] == 'B' )	/** ���� **/
  {
      sprintf_s(stmt_state, sizeof stmt_state," ");
  }
  else if(status[0] == '0' )	/** ���X **/
  {
      sprintf_s(stmt_state, sizeof stmt_state," AND fstatus = '0' ");
  }
  else if(status[0] == '1' )	/** �C�L�ϥΤH **/
  {
      sprintf_s(stmt_state, sizeof stmt_state," AND fstatus = '1' ");
  }
  else if(status[0] == '2' )	/** �ɵo **/
  {
      sprintf_s(stmt_state, sizeof stmt_state," AND fstatus = '2' ");
  }
  else if(status[0] == '3' )	/** �[�O **/
  {
      sprintf_s(stmt_state, sizeof stmt_state," AND fstatus = '3' ");
  }
  else if(status[0] == '4' )	/** �@�o **/
  {
      sprintf_s(stmt_state, sizeof stmt_state," AND fstatus = '4' ");
  }
  else if(status[0] == '5' )	/** �� **/
  {
      sprintf_s(stmt_state, sizeof stmt_state," AND fstatus = '5' ");
  }
  else if(status[0] == '6' )	/** �@�o�ܥ��X **/
  {
      sprintf_s(stmt_state, sizeof stmt_state," AND fstatus = '6' ");
  }
  else if(status[0] == '7' )	/** ���ܥ��X **/
  {
      sprintf_s(stmt_state, sizeof stmt_state," AND fstatus = '7' ");
  }
  else if(status[0] == '8' )	/** �w�ϥ�(1:�C�L�ϥΤH+2:�ɵo+3:�[�O) **/
  {
      sprintf_s(stmt_state, sizeof stmt_state," AND fstatus in ('1','2','3') ");
  }
  else if(status[0] == '9' )	/** ���ϥ�(0:���X+6:�@�o�ܥ��X+7:���ܥ��X) **/
  {
      sprintf_s(stmt_state, sizeof stmt_state," AND fstatus in ('0','6','7') ");
  }
  else if(status[0] == 'A' )	/** �@�o��(4:�@�o+5��) **/
  {
      sprintf_s(stmt_state, sizeof stmt_state," AND fstatus in ('4','5') ");
  }
  
  
  sprintf_s(stmt, sizeof stmt,"SELECT ireceipt, ipolicy_begin, ipolicy_end, iendorse_begin, iendorse_end,  "
                       "fstatus, mpremium, (select nname from officer where iofficer = iprinter),  "
                       "dprint, (select nname from officer where iofficer = ialter) , dalter  "
                  "FROM receipt WHERE %s %s",stmt_buf1, stmt_state );
                 
  printf("stmt=[%s]\n", stmt );
  $PREPARE p_rece_stmt1 FROM $stmt;
  $DECLARE p_rece_1 CURSOR for p_rece_stmt1;
  $OPEN p_rece_1;
  while(1)
  {
      $FETCH p_rece_1 INTO $ireceipt, $ipolicy_begin, $ipolicy_end, $iendorse_begin, $iendorse_end,
                            $fstatus, $mpremium, $iprint, $dprint, $ialter, $dalter;
      if(SQLCODE == SQLNOTFOUND)
         break;
         
      strcpy(ipolicy_begin,  trim(ipolicy_begin));
      strcpy(ipolicy_end,    trim(ipolicy_end));
      strcpy(iendorse_begin, trim(iendorse_begin));
      strcpy(iendorse_end,   trim(iendorse_end));
      
      strcpy(fulldbname,get_car_full_db(ipolicy_begin));
         
      if( strlen( ipolicy_begin ) == 0 )
      {
	  nbranch[0]  = '\0';
	  nassured[0] = '\0';
	  itag[0]     = '\0';
	  iengine[0]  = '\0';
	  dply_edr_begin[0] = '\0';
	  dply_edr_end[0]   = '\0';
	  dpol_endorse[0]   = '\0';
      }
      else if( (strcmp(ipolicy_begin, ipolicy_end) == 0) && (strcmp(iendorse_begin, iendorse_end)==0 ))
      {
      	  /** �u�C�L�@�i�O��or���~���ݭn���o���y��� **/
          if( strlen(iendorse_begin) == 0 )
          {
          	/** �C�L�O��AGet�O��ͮĤ�� **/
          	sprintf_s(stmt, sizeof stmt,"SELECT a.dply_begin, a.dply_end, b.itag, b.iengine, b.nassured, dpolicy,  "
          	                    "(select nbranch from sa_branch_type where ibranch = a.iquota[1,4] || '00' )  "
          	               " FROM %s:ply_relation a, %s:policy b "
          	               "WHERE a.ipolicy = b.ipolicy AND a.ipolicy = '%s'",
          	               fulldbname, fulldbname, ipolicy_begin );
          	$PREPARE POL_DATA FROM $stmt;
          	$EXECUTE POL_DATA INTO $dply_edr_begin, $dply_edr_end, $itag, $iengine, $nassured, $dpol_endorse, $nbranch;
          	if( SQLCODE == SQLNOTFOUND )
          	{
          	     dply_edr_begin[0]='\0';
          	     dply_edr_end[0]='\0';
          	     dpol_endorse[0]='\0';
          	     itag[0]='\0';
          	     iengine[0]='\0';
          	     nassured[0]='\0';
          	}
          }
          else
          {
          	
          	/** �C�L���AGet���ͮĤ�� **/
          	sprintf_s(stmt, sizeof stmt,"SELECT a.dedr_begin, a.dedr_end, b.itag, b.iengine, b.nassured, dendorse,  "
          	                    "(select nbranch from sa_branch_type where ibranch = a.iquota[1,4] || '00' )  "
          	               " FROM %s:edr_relation a, %s:policy b  "
          	               "WHERE a.ipolicy = b.ipolicy AND a.iendorse = '%s'",
          	               fulldbname, fulldbname, iendorse_begin );
          	$PREPARE EDR_DATA FROM $stmt;
          	$EXECUTE EDR_DATA INTO $dply_edr_begin, $dply_edr_end, $itag, $iengine, $nassured, $dpol_endorse, $nbranch;
          	if(SQLCODE == SQLNOTFOUND)
          	{
          	     dply_edr_begin[0]='\0';
          	     dply_edr_end[0]='\0';
          	     dpol_endorse[0]='\0';
          	     itag[0]='\0';
          	     iengine[0]='\0';
          	     nassured[0]='\0';
          	}
          }
      }
      else
      {
      	  
      	  printf("in EXEC_BRANCH ipolicy = [%s]\n", ipolicy_begin );
      	  /** �h���O���A���o�Ĥ@������~��� **/
      	  sprintf_s(stmt, sizeof stmt,"SELECT (select nbranch from sa_branch_type where ibranch = iquota[1,4] || '00' )  "
      	                " FROM %s:ply_relation  "
      	                "WHERE ipolicy = '%s'",fulldbname,ipolicy_begin );
      	                 
      	  $PREPARE EXC_BRANCH FROM $stmt;
      	  $EXECUTE EXC_BRANCH INTO $nbranch;
      	  if(SQLCODE == SQLNOTFOUND )
      	     nbranch[0] = '\0';
      }
      
      switch (fstatus[0])
      {
      	  case '0':
      		strcpy(smt_status,"���X");
      		break;
          case '1':
      		strcpy(smt_status,"�C�L�ϥΤH");
      		break;
      	  case '2':
      		strcpy(smt_status,"�ɵo");
      		break;
      	  case '3':
      		strcpy(smt_status,"�[�O");
      		break;
      	  case '4':
      		strcpy(smt_status,"�@�o");
      		break;
      	  case '5':
      		strcpy(smt_status,"��");
      		break;
      	  case '6':
      		strcpy(smt_status,"�@�o�ܥ��X");
      		break;
      	  case '7':
      		strcpy(smt_status,"���ܥ��X");
      		break;
      	  default:
 		strcpy(smt_status,"");
		break;
      }
      
      rgu_put_body_string(2, ireceipt, LEFT );
      rgu_put_body_string(2, ipolicy_begin, LEFT );
      rgu_put_body_string(2, ipolicy_end, LEFT );
      rgu_put_body_string(2, iendorse_begin, LEFT );
      rgu_put_body_string(2, iendorse_end, LEFT );
      rgu_put_body_string(2, nbranch, LEFT );
      rgu_put_body_string(2, trim(nassured), LEFT );
      rgu_put_body_string(2, trim(itag), LEFT );
      rgu_put_body_string(2, trim(iengine), LEFT );
      rgu_put_body_string(2, trim(dply_edr_begin), LEFT );
      rgu_put_body_string(2, trim(dply_edr_end), LEFT );
      rgu_put_body_string(2, dprint, LEFT );
      rgu_put_body_string(2, iprint, LEFT );
      rgu_put_body_string(2, dalter, LEFT );
      rgu_put_body_string(2, ialter, LEFT );
      rgu_put_body_string(2, dpol_endorse , LEFT );
      
      rfmtlong(mpremium, "---------&", tmp_buf);
      printf("--mpremium --- tmp_buf[%s]\n", tmp_buf );
      rgu_put_body_string(2,tmp_buf,LEFT);
      
      rgu_put_body_string(2, smt_status, LEFT );
      rgu_put_body(2);
      max_cnt++;
      
  }
  printf("get out of while loop \n");
  
  $CLOSE p_rece_1;
  
  printf("after CLOSE p_rece_1\n");
  
  return M_CM_OK;
  
  
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);
}



char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}
