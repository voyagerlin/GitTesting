/*******************************************************/
/*            �T���I���j�߮׳����]�w���B�w���M���B�^(�s��)    */
/* PROGRAM : ca908q01s.ec by Peter Sun                      */
/*                                                          */
/* DATE    : 88.05.31                                       */
/*                                                          */
/* NOTE    : �H�i�X����j����¦�A                         */
/*           �ھڽ߮ת��i�X�I����j�A                       */
/*           �N�߮סi�w���j���B�Ρi�z��j���B�j��           */
/*           �����J�����d�ߪ��B���߮צC�X�C               */
/*           �w�M�ߴڥHdgroup�i�߱b����j����¦�C           */
/*                                                          */
/* TABLE   : form , appraisal , app_ins_type ,              */
/*           ply_relation , officer , branch ,              */
/*           insurance_type , stl_ins_type                  */
/*                                                          */
/* Modify  : 95.06.25 �N�έp�覡�T�q�֬��@�q Jessie         */
/*           �W�[�ۯd�v                                     */
/* Modify  : 108.12.09 �J��[�c�ظm by sylvia               */
/*           sExecType(����覡)                            */
/*            A:cron�Ƶ{, �@�ߥ��R���¸�ƦA�g�J�s���      */
/*            B:��car908����, ���ˮ�car908_wkm�O�_�����    */
/*              ��:��N��=R, Ūcar908_wkd���s����           */
/*              �L:��N��=C, �����ƨò��s����,���g��Ʈw  */
/*            C:cron�Ƶ{, �@�߭����ƨò��s����,���g��Ʈw */
/************************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
#include "car_common.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
$include "sqlfatal.h"
#include <time.h>
#include <iostream>
#include "safeclib.h"
/*------------------------------------*/
extern char RPTDIR[];

$char Actuarial[2];  /*1.��� 2.�D��� 3.�q�ӥ� */
$char Date_accident[11];
$char ID_route[15];
$char ID_officer[10];
$char dentry[20];
$char sWhere_Daccident[125];
$char sWhere_Iroute[125];
$char sWhere_Iofficer[125];
$long mpart;
$long mplate_and_remove;
$long mvarnish;
$char icar_series[20];
$char temp_icar_series[3];


$char clsdatebgn[11], clsdateend[11];

$char clsdatebasic[11];
$char append[11];
$char ibranch_1[3] , nchi_full[13], ibranch_abbr[2];
$char iissue_ym[7];
$char ibranchbgn[7] , ibranchend[7];
$long loss_amt, minjured_cover, mdeath_cover, mdamage_cover;
$char loss_amt_note[6];

$char DBName[5], sFullName[80], sDataFile[20];
$char FormTp[3];
char  BodyFile[21];
char  TitleFile[21];
char  outputf[21];
char  userid[11];
$char cls_datebgn[15], cls_dateend[15];
$char cls_datebasic[15];
$int iclose_type;
$long lDgroup;
$char stmt[2048],stmt1[1024],stmt2[256];
$char iquota14[5];
$char sIupbranch[3];
$char sFull[21];
$char sFull00[21];
$char iquota_0[10];

static int pagenum=1;

$int  TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;
static int max_count, errCode;
int   tmp_len;

$char iclaim[CLAIM_NUM], ipolicy[POLICY_NUM_1];
$char ipolicy1[3], iresource[2], iassured[21],nassured[21],ncode[13],nbranch[41],naffiliated[41];
$char ibig_comp[2] , iofficer[21], ibig_office[10];
$char iadjuster_tmp[11] , iadjuster[11],ri_year[5];
$char mend_iofficer[21],imodule[2];
$char daccident[15], dclaim[18], dply_begin[11], dacc_hours[3];
$char ncause_adjuster[61];
$char fstl[2] , flast[2];
$char iins_type[7], nins_type[29] , nname[21];
$char iins_item[7];
$char ibrand[9],nbrand[31];
$char fsex[2],ibirth[10],fassured[2],iacc_area[3];
$char iacc_birth[10],facc_sex[2],facc_rel[2],dpolicy[11];
$long lDpolicy;
$char nfsex[3],nfacc_rel[16],nfassured[41],niacc_area[21];
$double plia_acc,pdmg_acc,pshare,pshare1;
$long mins_app,mproc_app;
$long mins_premium;
$long out_mins_app,out_mproc_app;
$long mins_stl;
$long mins_outstl;
/* new add */
$long out_mins_outstl,out_mclose;
$long out_mins_stl ,out_mins_proc,out_mstl_health;
$char out_fstl[2];
$long mproc_outstl;          /* Modified by Julia in 2006/12/08 */

$long mins_proc;
$long mins_salv;
$long mstl_health, msum_health;
char  outputf[N_FILE+1];
$char fcard_class[2];
$char dgroup[12];
$long mclose;
$long mclose1;

$long mins_stl_close,mstl_health_close;         /* peter */
$long mins_proc_close;        /* peter */
$long mins_recovery_close;    /* peter */
$char nbig_comp[11];          /* peter */

$long mdeduct,mdeduct_stl;
$char iquota[7];
$char iquota_b[7];
$char iquota_tmp[4];
$char option[2],sWhere[1024];
$char sWhere_off[1024];
$int  iCnt;
$int  icnt_off;
$char fins_grp[2],factory_1[11],factory32_1[11];
$char factory_tmp[61];
$char fullname1[31];
$char choice[2];
$char car_icode[3],car_ncode[21],icar_type[3];
$char fcomp_class[3];
$char ivictim[11];
$char itag[CA_TAG_NUM],iengine[CA_ENGINE_NUM],ioth_tag[CA_TAG_NUM],stmt_buf[500];
$char iacc_reason[3],nuser[21];
$char dclose[11];
$char frate[4],syymm[6];
$int  iyymm;
$long tmp_dappraisal;
$long out_tmp_dappraisal;
$char maxflast[2];
$int  qply_period;
$char iproduct[13],kreserve[6],fcar_class[2],kclsfyitem[5],iprodcode[2];
$char iins_ply[7];
$char ifpce_id[11], ofacname[61];
$char iply_area[3];
$char iroute[21], nroute[41], bzfrom[3];
$char dedr_begin[11], dendorse[11], fedr_status[3];
$char accident[2],accident_duty[20];     /*�F�d*/
$int qduty_adjuster;
/** �A�O��� **/
$int  ri_cnt_P,ri_cnt_E;
$long ri_mprem_P,ri_mfac_P,ri_msret_P;
$long ri_mprem_E,ri_mfac_E,ri_msret_E;
$long ri_mprem,ri_mfac,ri_msret;
$long ri_msum_P;
$char dpolicy_ri[11];
$int  iexists_cnt;
$long rtnrc;
$char icomm_obj[11],irate_type[2];
char  sApHome[30];
$char  sFrate[4],sProvision[21];

/* ------------------------------------------------------------------ */
$char sExecType[2],sIdataNo[51],dcal_deadline[11],ndriver_sex[3],noutfile[11],
      sPlia_acc[11];
$int  mis_app_chk;

long car908_build();
long car908_title();
long car908_body();
long car908_body_ec();
long car908_build1();
long car908_build4();
char *split_yymm();
double d45();

main(argc, argv)
int argc;
char **argv;
{
   int rc;
	 $char syy[4],smm[3],sdd[3];
   batchinit();
   printf("[car908R] start !!!!!!!!\n");

   /* �Y���s�W�d�߱���A���P�ɭק�H�U���shell�G
      ���|�G/TEST/IPIS/exec/
      �W�١Grun908_policy �� run908_calendar
   */
   strcpy(DBName      , isNULLstr(argv[1]));     /** �Ҧb��Ʈw **/
   strcpy(userid      , isNULLstr(argv[2]));     /** �ϥΪ̥N�� **/

   strcpy(choice      , isNULLstr(argv[3]));     /** �j����N�O **/
   strcpy(option      , isNULLstr(argv[4]));     /** 1.��~�� 2.�O��� 3.�ƬG�� 4.���z�߮ר� **/
   strcpy(clsdatebgn  , isNULLstr(argv[5]));     /** �έp����_�� **/
   strcpy(clsdateend  , isNULLstr(argv[6]));     /** �έp������� **/
   strcpy(clsdatebasic, isNULLstr(argv[7]));     /** �p����     **/
   strcpy(append      , isNULLstr(argv[8]));     /** �����I���  **/
   strcpy(loss_amt_note,isNULLstr(argv[9]));     /** �ߴڪ��B�U��   **/
   strcpy(ibranch_1   , isNULLstr(argv[10]));    /** �X����       **/
   strcpy(Date_accident, isNULLstr(argv[11]));  /**�X�I��**/
   strcpy(ID_route   , isNULLstr(argv[12]));    /**�q���N��**/
   strcpy(ID_officer , isNULLstr(argv[13]));	 /**�g��N��**/
   strcpy(Actuarial  , isNULLstr(argv[14]));     /**1.���� 2.�D���� 3.�q�ӥ� 4.�l����**/
   strcpy(sExecType  , isNULLstr(argv[15]));     /**����覡:A:cron�Ƶ{�B�g��Ʈw;B:��ʰ���car908;C:cron�Ƶ{�B���g��Ʈw **/
   strcpy(outputf     , isNULLstr(argv[16]));


   printf("Data_accident = %s \n",Date_accident);
   printf("ID_route = %s \n",ID_route);
   printf("ID_officer = %s \n",ID_officer);
   printf("Actuarial = %s \n",Actuarial);

	 /* ��sIdataNo ------------------------------------------------------------ */
   sprintf_s(sIdataNo,51,"%s%s",choice,option); /* �j/��+�έp��� */

   cm_split_ymd_100(clsdatebgn, syy, smm, sdd);
   sprintf_s(sIdataNo,51,"%s%s%s%s",sIdataNo,syy,smm,sdd); /* �j/��+�έp���+�έp�_�� */

   cm_split_ymd_100(clsdateend, syy, smm, sdd);
   sprintf_s(sIdataNo,51,"%s%s%s%s",sIdataNo,syy,smm,sdd); /* �j/��+�έp���+�έp�_��+�έp���� */

   cm_split_ymd_100(clsdatebasic, syy, smm, sdd);
   sprintf_s(sIdataNo,51,"%s%s%s%s",sIdataNo,syy,smm,sdd); /* �j/��+�έp���+�έp�_��+�έp����+�p���� */

   cm_split_ymd_100(append, syy, smm, sdd);
   sprintf_s(sIdataNo,51,"%s%s%s%s",sIdataNo,syy,smm,sdd); /* �j/��+�έp���+�έp�_��+�έp����+�p����+�����I��� */

   printf("sIdataNo=[%s][%s]\n\n",sExecType,sIdataNo);

	 /* ----------------------------------------------------------------------- */


/*   printf("loss_amt_note[%s]",loss_amt_note);*/
   loss_amt = atoi(loss_amt_note) * 10000;
/*   printf("loss_amt[%d]\n",loss_amt);*/

   strcpy(cls_datebgn,clsdatebgn);
   strcpy(cls_dateend,clsdateend);
   strcpy(cls_datebasic,clsdatebasic);

   strcpy(clsdatebgn, cm_to_infdate(clsdatebgn));
   strcpy(clsdateend, cm_to_infdate(clsdateend));
   strcpy(clsdatebasic, cm_to_infdate(clsdatebasic));
   strcpy(dcal_deadline	, append);
   strcpy(append,       cm_to_infdate(append));


/*   printf("clsdatebgn[%s]\n",clsdatebgn);
   printf("clsdateend[%s]\n",clsdateend);
   printf("clsdatebasic[%s]\n",clsdatebasic);*/

	 strcpy(sIdataNo, rtrim(sIdataNo));
	 strcpy(noutfile, trim(outputf));
   printf("sExecType=[%s]sIdataNo=[%s]noutfile[%s]\n",sExecType,sIdataNo,noutfile);

   printf("car908_build begin !!\n");
   max_count=0;

   if (strcmp(Actuarial,"3") == 0)
        rc = car908_initial();    /* �q�ӥ� add by sylvia 106.08.22 (1060620001_C1) */


   if (choice[0] == '1')           /* �j���I */
      rc = car908_build4();
   else                            /* ���N�I */
      rc = car908_build1();

    if (strcmp(Actuarial,"3") == 0)
    {
        rc = car908_build_ec();

        rc = car908_print_clm();

        if (rc != M_CM_OK)
            return rc;
        rc = car908_print_ply();

        if (rc != M_CM_OK)
            return rc;
    }
    else
    {
       if(rc == api_OKComplete)
       {
           if((rc=save_form_info(F_FREE,"CA",908,userid,FormTp,max_count,outputf))<0)
              EWRITE(userid,rc,"save_form_info failed");
       }
    }
}

/**********************         ���N       ******************************/
long car908_build1()
{
   $char  TitleFmt[21], BodyFmt[21], FullName[20];
   $char  FormFmt[N_FILE+1];
   char   FormFile[N_FILE+1],fclose,out_fclose;
   $int   rec_no,id1,id2, icnt1;
   $char  iquota_14[7], chk_del[2];
   int    i,rc;

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;


    if (db_select(DBName) == False)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return FAIL;
    }

    icnt1 = 0;
    if(sExecType[0]=='B')
    {
   		$select count(*) into $icnt1
   		   from car908_wkm
   		  where idatano = $sIdataNo
   		    and Dexec_end is not null;

   		if (icnt1 > 0)
   			strcpy(sExecType,"R");	/* ����Ū��car908_wkd ���s���� */
   		else
   			strcpy(sExecType,"C");	/* ���s�p��ò��s���� */
    }

   /* �q�ӥ� add by sylvia 106.08.22 (1060620001_C1) */
   if(Actuarial[0]=='3')
   {
       rc = car908_voluntary();
       if (rc != SUCCESS)
          return rc;
   }
   else
   {
   	   /* sExecType = 'A' �|���R����Ʈw�g�J��Ʈw */
   		 if(sExecType[0]=='A')
   		 {
   		 		chk_del[0]='Y';	/* N:����R  Y:�i�H�R */
   		 		/* �]�ثe����ɶ��̪���1.5HR, �G�ˮְ���_�l�ɶ� > 3HR, ���ܬO�¸��, �i�H�R�����@ */
   		 		$select case when dexec_end is not null then 'Y' else
   		 								 case when dexec_bgn >= current-3 units hour then 'N' else 'Y' end
   		 						end
   		 			 into $chk_del
   		 			 from car908_wkm where idatano = $sIdataNo;

					if (chk_del[0]=='N')
					{
							EWRITE(userid,M_CM_NOT_FOUND,"�w���ۦP������椤.... !!");
      				return FAIL;
					}

   		 		printf("car908_build1: delete from car908_wkm �� car908_wkd begin \n");
   		 		$delete from car908_wkm where idatano = $sIdataNo;
   		 		$delete from car908_wkd where idatano = $sIdataNo;

   		 		printf("car908_build1: insert into car908_wkm  begin \n");
   		 		$insert into car908_wkm
   		 			(fclass, ical_type, dcal_begin, dcal_end, dcal_date,
   		 			 dcal_deadline, idatano, Dexec_bgn, noutfile)
   		 		values
   		 		  ($choice, $option, $cls_datebgn, $cls_dateend, $cls_datebasic,
   		 		   $dcal_deadline, $sIdataNo, current, $noutfile);

   		 		printf("car908_build1: insert into car908_wkm end \n");
   		 }

       if(Actuarial[0]=='1')
       {
       	/*���γ���*/
       	   $SELECT nform_file,ntitle_fmt, nbody_fmt, kstart_row, ktitle_row,
               	   ktot_col, kpgnum_line, kwidth, iform_tp
                  INTO $FormFmt, $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
                       $TotColumn, $PgLine, $Width, $FormTp
                  FROM Form
                 WHERE ksys_grp = "CA" AND kPgmID = 908
                       AND iform_tp = '2';
       }
       else if (Actuarial[0]=='4')
       {
        printf("Actuarial == '4' \n");

       	/*�l���γ���*/
       	   $SELECT nform_file,ntitle_fmt, nbody_fmt, kstart_row, ktitle_row,
               	   ktot_col, kpgnum_line, kwidth, iform_tp
                  INTO $FormFmt, $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
                       $TotColumn, $PgLine, $Width, $FormTp
                  FROM Form
                 WHERE ksys_grp = "CA" AND kPgmID = 908
                       AND iform_tp = '3';
       }
       else
       {
       	   $SELECT nform_file,ntitle_fmt, nbody_fmt, kstart_row, ktitle_row,
               	   ktot_col, kpgnum_line, kwidth, iform_tp
                  INTO $FormFmt, $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
                       $TotColumn, $PgLine, $Width, $FormTp
                  FROM Form
                 WHERE ksys_grp = "CA" AND kPgmID = 908
                       AND iform_tp='1';
       }


       strcpy(FormFmt, rtrim(FormFmt));
       sprintf_s(FormFile,21, "%s.tx", outputf);

       rgu_init_report(FormFmt,FormFile);
       car908_title();

       printf("sExecType[%s]\n",sExecType);

       /* rc = car908_voluntary(); */
       if ((sExecType[0] == 'R') && (Actuarial[0] != '4'))   
       		rc = car908R_compulsory();	/* Ūcar908_wkd���s����,�P�j���I�@�� */
       else
       		rc = car908_voluntary();

       if (rc != SUCCESS)
          return rc;

       rgu_finish_report();
   }
   if (max_count == 0)
   {
      EWRITE(userid,M_CM_NOT_FOUND,"no data found !!");
      return FAIL;
   }

   if(sExecType[0]=='A')
	 {
	 		printf("car908_build1: update car908_wkm   \n");
	 		$update car908_wkm
	 			  set Dexec_end = current
	 		  where idatano = $sIdataNo;

	 		printf("car908_build1: update car908_wkm end \n");
	 }

   return SUCCESS;

errexit:
  sqlfatal();
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(FAIL);
}


/*****************    �j��   *****************/
long car908_build4()
{
   $char  TitleFmt[21], BodyFmt[21], FullName[20];
   $char  FormFmt[N_FILE+1];
   char   FormFile[N_FILE+1],fclose,ffclose,out_fclose,out_ffclose;
   $int   rec_no,id1,id2;
   $char  iquota_14[7],chk_del[2];
   int    i,rc;
   $int    qlia_acc, icnt1;
   $double plia_acc;
   $char   flast_1[2];

   $WHENEVER SQLERROR GOTO errexit;
        $SET LOCK MODE TO WAIT;

   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   }

	 icnt1 = 0;
	 if(sExecType[0]=='B')
   {
   		$select count(*) into $icnt1
   		   from car908_wkm
   		  where idatano = $sIdataNo
   		    and Dexec_end is not null;

   		if (icnt1 > 0)
   			strcpy(sExecType,"R");	/* ����Ū��car908_wkd ���s���� */
   		else
   			strcpy(sExecType,"C");	/* ���s�p��ò��s���� */
   }

   /* �q�ӥ� add by sylvia 106.08.22 (1060620001_C1) */
   if(Actuarial[0]=='3')
   {
        rc = car908_compulsory();   /* �q�� */
        if (rc != SUCCESS)
          return rc;
   }
   else
   {
   	   /* sExecType = 'A' �|���R����Ʈw�g�J��Ʈw */
   		 if(sExecType[0]=='A')
   		 {

   		 		chk_del[0]='Y';	/* N:����R  Y:�i�H�R */
   		 		/* �]�ثe����ɶ��̪���1.5HR, �G�ˮְ���_�l�ɶ� > 3HR, ���ܬO�¸��, �i�H�R�����@ */
   		 		$select case when dexec_end is not null then 'Y' else
   		 								 case when dexec_bgn >= current-3 units hour then 'N' else 'Y' end
   		 						end
   		 			 into $chk_del
   		 			 from car908_wkm where idatano = $sIdataNo;

					if (chk_del[0]=='N')
					{
							EWRITE(userid,M_CM_NOT_FOUND,"�w���ۦP������椤.... !!");
      				return FAIL;
					}
   		 		printf("car908_build4: delete from car908_wkm �� car908_wkd begin \n");
   		 		$delete from car908_wkm where idatano = $sIdataNo;
   		 		$delete from car908_wkd where idatano = $sIdataNo;

   		 		printf("car908_build4: insert into car908_wkm  begin \n");
   		 		$insert into car908_wkm
   		 			(fclass, ical_type, dcal_begin, dcal_end, dcal_date,
   		 			 dcal_deadline, idatano, Dexec_bgn, noutfile)
   		 		values
   		 		  ($choice, $option, $cls_datebgn, $cls_dateend, $cls_datebasic,
   		 		   $dcal_deadline, $sIdataNo, current, $noutfile);

   		 		printf("car908_build4: insert into car908_wkm end!!  sExecType=[%s]\n",sExecType);
   		 }

       if(Actuarial[0]=='1')
       {
       	/*���γ���*/
       	   $SELECT nform_file,ntitle_fmt, nbody_fmt, kstart_row, ktitle_row,
               	   ktot_col, kpgnum_line, kwidth, iform_tp
                  INTO $FormFmt, $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
                       $TotColumn, $PgLine, $Width, $FormTp
                  FROM Form
                 WHERE ksys_grp = "CA" AND kPgmID = 908
                       AND iform_tp='2';

       }
       else if (Actuarial[0]=='4')
       {
        /*�l���γ���*/
           $SELECT nform_file,ntitle_fmt, nbody_fmt, kstart_row, ktitle_row,
                   ktot_col, kpgnum_line, kwidth, iform_tp
                  INTO $FormFmt, $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
                       $TotColumn, $PgLine, $Width, $FormTp
                  FROM Form
                 WHERE ksys_grp = "CA" AND kPgmID = 908
                       AND iform_tp = '3';
       }
       else
       {
       	   $SELECT nform_file,ntitle_fmt, nbody_fmt, kstart_row, ktitle_row,
               	   ktot_col, kpgnum_line, kwidth, iform_tp
                  INTO $FormFmt, $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
                       $TotColumn, $PgLine, $Width, $FormTp
                  FROM Form
                 WHERE ksys_grp = "CA" AND kPgmID = 908
                       AND iform_tp='1';
       }

       strcpy(FormFmt, rtrim(FormFmt));
       sprintf_s(FormFile,21, "%s.tx", outputf);

       rgu_init_report(FormFmt,FormFile);
       car908_title();

       /* rc = car908_compulsory(); */

       printf("519: sExecType=[%s]\n",sExecType);
    	 if ((sExecType[0]=='R') && (Actuarial[0] != '4'))   
       		rc = car908R_compulsory();	/* Ūcar908_wkd���s���� */
       else
       		rc = car908_compulsory();

       if (rc != SUCCESS)
          return rc;
       rgu_finish_report();
   }

   if (max_count == 0)
   {
      EWRITE(userid, M_CM_NOT_FOUND, "no data found !!");
      return FAIL;
   }

   if(sExecType[0]=='A')
	 {
	 		printf("car908_build4: update car908_wkm   \n");
	 		$update car908_wkm
	 			  set Dexec_end = current
	 		  where idatano = $sIdataNo;

	 		printf("car908_build4: update car908_wkm end \n");
	 }


   return SUCCESS;

errexit:
  printf("build:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
  sqlfatal();
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(FAIL);
}



/*--------------------------------------------------------------------*/
long car908_title()
{
   char yy[4], mm[3], dd[3], buf[11];

   printf("printf car908_title !\n");

   rfmtlong(loss_amt, "-,---,--&", buf);
   rgu_put_body_string(3, buf,1 );

   printf("car908_title:option[%s],choice[%s]\n",option,choice);

   /* �έp��� */
   if (strncmp(option,"1",1)==0)
   {
       rgu_put_body_string(4, "���~�ר�",1 );
   }
   else if (strncmp(option,"2",1)==0)
   {
       rgu_put_body_string(4, "�O��~�ר�",1 );
   }
   else if (strncmp(option,"3",1)==0)
   {
       rgu_put_body_string(4, "�ƬG�~�ר�",1 );
   }
   else if (strncmp(option,"4",1)==0)
   {
       rgu_put_body_string(4, "���z�߮ר�",1 );
   }
   else
   {
       rgu_put_body_string(4, " ",1 );
   }

   if (choice[0] == '1'){
       rgu_put_body_string(4,"�j���I",1);
       rgu_put_body_string(7,"�j��",2);
       rgu_put_body_string(7,"�������O�l�v���B",2);
   }else{
       rgu_put_body_string(4,"���N�I",1);
       rgu_put_body_string(7,"���N",2);
       rgu_put_body_string(7," ",2);
   }

   cm_split_ymd_100(cls_datebgn, yy, mm, dd);
   rgu_put_body_string(5,yy,1);
   rgu_put_body_string(5,mm,1);
   rgu_put_body_string(5,dd,1);

   cm_split_ymd_100(cls_dateend, yy, mm, dd);
   rgu_put_body_string(5,yy,1);
   rgu_put_body_string(5,mm,1);
   rgu_put_body_string(5,dd,1);
   rgu_put_body_string(10,loss_amt_note,2);

   rgu_put_body_string(6,clsdatebasic,1); /* �p���� */
   rgu_put_body_string(6,append,1); /* �����I��� */

   rgu_put_body(1);  max_count += 8;
   rgu_put_body(2);
   rgu_put_body(3);
   rgu_put_body(4);
   rgu_put_body(5);
   rgu_put_body(6);
   rgu_put_body(7);
   rgu_put_body(8);

}

/*----------------Start Work LossDef----------------------------------------*/
long car908_body_LossDef()
{
   char  buf[16],buf1[4];
   short i;
   int   rc;
   $char stmt[2048];

   printf("print car908_body !! sExecType=[%s])\n", sExecType);

   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

   sprintf_s(stmt,2048,
   " select iins_ply         \
       from insurance_type   \
      where iins_type = ? ");

   $prepare bdy0 from $stmt;
   $execute bdy0
       into $iins_ply
      using $iins_type;
   if (SQLCODE == SQLNOTFOUND)
   {
      strcpy(iins_ply," ");
   }

   rgu_put_body_string(9,trim(iquota),1);
   strcpy(iquota, trim(iquota));
   printf("iquota[%s]\n",iquota);

   rgu_put_body_string(9,trim(fullname1),1);
   strcpy(fullname1, trim(fullname1));

   /***  mark cyrus
   rgu_put_body_string(9,ibranch,1);
   ***/
   rgu_put_body_string(9,nchi_full,1);
   rgu_put_body_string(9,dply_begin,1);
   rgu_put_body_string(9,dpolicy,1);

   rgu_put_body_string(9,daccident,1);
   rgu_put_body_string(9,dacc_hours,1);
   rgu_put_body_string(9,dclaim,1);

   /***  mark cyrus
   rgu_put_body_string(9,rtrim(sdclose),1);
   ***/
   rgu_put_body_string(9,rtrim(dclose),1);

   /*1051130005_C1_���M���ӳ�����908�����s�W�Ҧb�a���*/
   rgu_put_body_string(9,nbranch,1);     /*�Ҧb�a*/
   rgu_put_body_string(9,naffiliated,1); /*�z�߬�O*/
   rgu_put_body_string(9,iclaim,1);
   rgu_put_body_string(9,ipolicy,1);

   rgu_put_body_string(9,ivictim,1);
   rgu_put_body_string(9,iins_type,1);

   rgu_put_body_string(9,nins_type,1);

   rfmtlong(mins_premium, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   rfmtlong(mins_app, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   rfmtlong(out_mins_outstl, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   rfmtlong(mins_outstl, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   /*****  mark cyrus
   rfmtlong(mins_stl, "---,---,--&", buf);
   *****/
   rfmtlong(mclose, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   rfmtlong(mins_stl_close, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   rfmtlong(mins_recovery_close, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   rfmtlong(mins_proc_close, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   /*****  mark cyrus
   rfmtlong(deduct_tmp, "---,---,--&", buf);
   *****/

   rfmtlong(mdeduct, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   rgu_put_body_string(9,ibig_comp,1);

   rgu_put_body_string(9,nbig_comp,1);

   rgu_put_body_string(9,iofficer,1);

   rgu_put_body_string(9,nname,1);

   rgu_put_body_string(9,iroute,1);

   rgu_put_body_string(9,nroute,1);

   rgu_put_body_string(9,bzfrom,1);

   rgu_put_body_string(9,iadjuster,1);

	 printf("722:sExecType=[%s]\n",sExecType);
	 if(strcmp(sExecType,"R")!=0)
	 {
	   sprintf_s(stmt,2048,
	   " select ncode[1,12]          \
	       from cu_code_data         \
	      where itype = '10'         \
	        and icode = ? ");
	   $prepare bdy1 from $stmt;
	   $execute bdy1
	       into $ncode
	      using $iresource;
	   if (SQLCODE == SQLNOTFOUND)
	   {
	      strcpy(ncode," ");
	   }
	 }
   rgu_put_body_string(9,ncode,1);


   rgu_put_body_string(9,iassured,1);
   rgu_put_body_string(9,nassured,1);
   rgu_put_body_string(9,rtrim(nuser),1);  /* �ϥΤH */
	 strcpy(nuser, rtrim(nuser));

   rgu_put_body_string(9,ibrand,1);

   if(strcmp(sExecType,"R")!=0)
   {
	   rc=read_brand();
	   if (rc<0)
	      strcpy(nbrand,"**********");
	 }
   rgu_put_body_string(9,nbrand,1);

   if(strcmp(sExecType,"R")!=0)
   {
	   rc=read_cartype();
	   if(rc<0)
	     strcpy(car_ncode,"**********");
	 }
   rgu_put_body_string(9,car_ncode,1);

   if(strcmp(sExecType,"R")!=0)
   {
	   if (fsex[0]=='1')
	      strcpy(nfsex,"�k");
	   else if (fsex[0]=='2')
	      strcpy(nfsex,"�k");
	   else
	      strcpy(nfsex," ");
	 }

   rgu_put_body_string(9,nfsex,1);
   rgu_put_body_string(9,ibirth,1);

   if(strcmp(sExecType,"R")!=0)
   {
	   sprintf_s(stmt,2048,
	   " select nvl(ncode,'***')      \
	       from cu_code_data          \
	      where itype = '09'          \
	        and icode = ? ");
	   $prepare bdy2 from $stmt;
	   $execute bdy2
	       into $nfassured
	      using $fassured;
	   if (SQLCODE == SQLNOTFOUND)
	   {
	      strcpy(nfassured," ");
	   }
	 }
   rgu_put_body_string(9,nfassured,1);

printf("824 ----- plia_acc = [%f] sPlia_acc[%s]\n",plia_acc,sPlia_acc);
	 if(strcmp(sExecType,"R")!=0)
   {
   	rfmtdouble(plia_acc, "--&.&&", buf);
   	rgu_put_body_string(9,buf,1);
   }
   else
   {

   	rgu_put_body_string(9,trim(sPlia_acc),1);
   }

   rfmtdouble(pdmg_acc, "--&.&&", buf);
   rgu_put_body_string(9,buf,1);

   if(strcmp(sExecType,"R")!=0)
   {
	   sprintf_s(stmt,2048,
	   " select nvl(dvp_abbr,'***')      \
	       from ca_dvp_ply_area          \
	      where dvp_code = ? ");
	   $prepare bdy3 from $stmt;
	   $execute bdy3
	       into $niacc_area
	      using $iacc_area;
	   if (SQLCODE == SQLNOTFOUND)
	   {
	      strcpy(niacc_area," ");
	   }
	 }
   rgu_put_body_string(9,niacc_area,1);

	 if(strcmp(sExecType,"R")!=0)
   {
	   /* if (facc_sex[0]=='1')
	       strcpy(nfsex,"�k");
	   else if (facc_sex[0]=='2')
	       strcpy(nfsex,"�k");
	   else
	       strcpy(nfsex," ");
	   rgu_put_body_string(9,nfsex,1); */
	   if (facc_sex[0]=='1')
	       strcpy(ndriver_sex,"�k");
	   else if (facc_sex[0]=='2')
	       strcpy(ndriver_sex,"�k");
	   else
	       strcpy(ndriver_sex," ");
   }
   rgu_put_body_string(9,ndriver_sex,1);

   rgu_put_body_string(9,iacc_birth,1);

	 if(strcmp(sExecType,"R")!=0)
   {
	   /* if (facc_rel[0]=='1')
	      strcpy(nfacc_rel,"���H");
	   else if (facc_rel[0]=='2')
	      strcpy(nfacc_rel,"�ˤ�");
	   else if (facc_rel[0]=='3')
	      strcpy(nfacc_rel,"���u");
	   else if (facc_rel[0]=='4')
	      strcpy(nfacc_rel,"����");
	   else if (facc_rel[0]=='5')
	      strcpy(nfacc_rel,"��L");
	   else if (facc_rel[0]=='6')
	      strcpy(nfacc_rel,"�t��");
	   else if (facc_rel[0]=='7')
	      strcpy(nfacc_rel,"�l�k");
	   else strcpy(nfacc_rel,facc_rel); */
	   if (facc_rel[0]=='1')
	      strcpy(nfacc_rel,"���H");
	   else if (facc_rel[0]=='A')
	      strcpy(nfacc_rel,"�۵M�H-�t��");
	   else if (facc_rel[0]=='B')
	      strcpy(nfacc_rel,"�۵M�H-���t����");
	   else if (facc_rel[0]=='C')
	      strcpy(nfacc_rel,"�۵M�H-�S�̩j�f");
	   else if (facc_rel[0]=='D')
	      strcpy(nfacc_rel,"�۵M�H-��L");
	   else if (facc_rel[0]=='E')
	      strcpy(nfacc_rel,"�k�H-�t�d�H");
	   else if (facc_rel[0]=='F')
	      strcpy(nfacc_rel,"�k�H-�t�d�H�a��");
	   else if (facc_rel[0]=='G')
	      strcpy(nfacc_rel,"�k�H-������");
	   else if (facc_rel[0]=='4')
	      strcpy(nfacc_rel,"�k�H-����");
	   else if (facc_rel[0]=='5')
	      strcpy(nfacc_rel,"�k�H-��L");
	   else strcpy(nfacc_rel,facc_rel);
	 }
   rgu_put_body_string(9,nfacc_rel,1);

   rgu_put_body_string(9,factory_tmp,1);

   rgu_put_body_string(9,rtrim(itag),1);
   rgu_put_body_string(9,rtrim(ioth_tag),1);

   rgu_put_body_string(9,rtrim(iengine),1);
   rgu_put_body_string(9,rtrim(iacc_reason),1);

   printf("iclaim = %s , maxflast = %s, ldgroup = %ld \n",iclaim, maxflast, lDgroup);

   rgu_put_body_string(9,rtrim(maxflast),1);

   if(strcmp(sExecType,"R")!=0)
   {
	   rc = read_kreserve();
	   if (rc!= SUCCESS)
	      strcpy(kreserve," ");
	 }
   rgu_put_body_string(9,rtrim(kreserve),1);

   rgu_put_body_string(9,rtrim(dgroup),1);
   if (choice[0] == '1')
   {
      rgu_put_body_string(9," ",2);
   }
   else
   {
      rfmtdouble(pshare, "---&.&&", buf);
      rgu_put_body_string(9,rtrim(buf),2);
   }

   /* For print out [mproc_outstl] */
   rfmtlong(mproc_outstl, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);
   /* End of printing */   
   
   rfmtlong(minjured_cover, "---,---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   rfmtlong(mdeath_cover, "---,---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   rfmtlong(mdamage_cover, "---,---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   /* �o�Ӥ�� */
   rgu_put_body_string(9,rtrim(iissue_ym),1);
   /* �ӫO�a�ϥN�� */
   rgu_put_body_string(9,iply_area,1);

   /* �������O�l�v���B */
   if (choice[0] == '1')
   {
       rfmtlong(msum_health, "---,---,--&", buf);
       rgu_put_body_string(9,buf,1);
   }
   else
   {
       rgu_put_body_string(9," ",1);
   }

   rgu_put_body_string(9,rtrim(accident_duty),1); /*�F�d*/
   strcpy(accident_duty, rtrim(accident_duty));

   rgu_put_body_string(9,itoa(qduty_adjuster),1);

   rgu_put_body_string(9,dentry,1);

   rfmtlong(mpart, "---,---,---,--&", buf);
   rgu_put_body_string(9,ltrim(buf),1);
   printf("mpart = %s \n",buf);


   rfmtlong(mplate_and_remove, "---,---,---,--&", buf);
   rgu_put_body_string(9,ltrim(buf),1);
   printf("mplate_and_remove = %s \n",buf);

   rfmtlong(mvarnish, "---,---,---,--&", buf);
   rgu_put_body_string(9,ltrim(buf),1);
   printf("mvarnish = %s \n",buf);

   rgu_put_body_string(9,icar_series,1);
   rgu_put_body_string(9,ncause_adjuster,1);

   rgu_put_body(9);

   max_count ++;

	 /* �g�J��Ʈw car908_wkd */
   /****
   if(strcmp(sExecType,"A")==0)
   {
   		printf("iclaim=[%s] ipolicy=[%s]\n",iclaim,ipolicy);
   		$insert into sysdb:car908_wkd
   		 	(idatano, fclass, ical_type, iquota, nquota,
	       nchi_full, dply_begin, dpolicy, daccident, dclaim,
	       dclose, nbranch, naffiliated, iclaim, ipolicy,
	       ivictim, iins_type, nins_type, mins_premium, mins_app,
	       mins_outstl_bgn, mins_outstl_end, mclose, mins_stl_close, mins_recovery,
	       mins_proc_close, mdeduct, ibig_comp, nbig_comp, iofficer,
	       nofficer, iroute, nroute, bzfrom, iadjuster,
	       nresource, iassured, nassured, nuser, ibrand,
	       nbrand, car_ncode, nfsex, ibirth, nfassured,
	       plia_acc, pdmg_acc, niacc_area, ndriver_sex, iacc_birth,
	       nfacc_rel, factory_tmp, itag, ioth_tag, iengine,
	       iacc_reason, maxflast, kreserve, dgroup, pshare,
	       mproc_outstl, minjured_cover, mdeath_cover, mdamage_cover, iissue_ym,
	       iply_area, mstl_health, accident_duty, qduty_adjuster, dentry,
	       mpart, mplate, mvarnish, ncar_series, mis_app_chk)
	     values
	     ($sIdataNo, $choice, $option, $iquota, $fullname1,
	      $nchi_full, $dply_begin, $dpolicy, $daccident, $dclaim,
	      $dclose, $nbranch, $naffiliated, $iclaim, $ipolicy,
	      $ivictim, $iins_type, $nins_type, $mins_premium, $mins_app,
	      $out_mins_outstl, $mins_outstl, $mclose, $mins_stl_close, $mins_recovery_close,
	      $mins_proc_close, $mdeduct, $ibig_comp, $nbig_comp, $iofficer,
	      $nname, $iroute, $nroute, $bzfrom, $iadjuster,
	      $ncode, $iassured, $nassured, $nuser, $ibrand,
	      $nbrand, $car_ncode, $nfsex, $ibirth, $nfassured,
	      $plia_acc, $pdmg_acc, $niacc_area, $ndriver_sex, $iacc_birth,
	      $nfacc_rel, $factory_tmp, $itag, $ioth_tag, $iengine,
	      $iacc_reason, $maxflast, $kreserve, $dgroup, $pshare,
	      $mproc_outstl, $minjured_cover, $mdeath_cover, $mdamage_cover, $iissue_ym,
	      $iply_area, $mstl_health, $accident_duty, $qduty_adjuster, $dentry,
	      $mpart, $mplate_and_remove, $mvarnish, $icar_series, $mis_app_chk);
    }
   ****/
   return SUCCESS;

errexit:
   printf("body[908]:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;

}
/*-------------------End Work LossDef-------------------------------------*/

/*----------------Start Work----------------------------------------------*/
long car908_body()
{
   char  buf[16],buf1[4];
   short i;
   int   rc;
   $char stmt[2048];

   printf("print car908_body !! sExecType=[%s])\n", sExecType);

   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

   sprintf_s(stmt,2048,
   " select iins_ply         \
       from insurance_type   \
      where iins_type = ? ");

   $prepare bdy0 from $stmt;
   $execute bdy0
       into $iins_ply
      using $iins_type;
   if (SQLCODE == SQLNOTFOUND)
   {
      strcpy(iins_ply," ");
   }

   rgu_put_body_string(9,trim(iquota),1);
   strcpy(iquota, trim(iquota));
   printf("iquota[%s]\n",iquota);

   rgu_put_body_string(9,trim(fullname1),1);
   strcpy(fullname1, trim(fullname1));

   /***  mark cyrus
   rgu_put_body_string(9,ibranch,1);
   ***/
   rgu_put_body_string(9,nchi_full,1);
   rgu_put_body_string(9,dply_begin,1);
   rgu_put_body_string(9,dpolicy,1);

   rgu_put_body_string(9,daccident,1);
   rgu_put_body_string(9,dclaim,1);

   /***  mark cyrus
   rgu_put_body_string(9,rtrim(sdclose),1);
   ***/
   rgu_put_body_string(9,rtrim(dclose),1);

   /*1051130005_C1_���M���ӳ�����908�����s�W�Ҧb�a���*/
   rgu_put_body_string(9,nbranch,1);     /*�Ҧb�a*/
   rgu_put_body_string(9,naffiliated,1); /*�z�߬�O*/
   rgu_put_body_string(9,iclaim,1);
   rgu_put_body_string(9,ipolicy,1);

   rgu_put_body_string(9,ivictim,1);
   rgu_put_body_string(9,iins_type,1);

   rgu_put_body_string(9,nins_type,1);

   rfmtlong(mins_premium, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   rfmtlong(mins_app, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   rfmtlong(out_mins_outstl, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   rfmtlong(mins_outstl, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   /*****  mark cyrus
   rfmtlong(mins_stl, "---,---,--&", buf);
   *****/
   rfmtlong(mclose, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   rfmtlong(mins_stl_close, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   rfmtlong(mins_recovery_close, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   rfmtlong(mins_proc_close, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   /*****  mark cyrus
   rfmtlong(deduct_tmp, "---,---,--&", buf);
   *****/

   rfmtlong(mdeduct, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   rgu_put_body_string(9,ibig_comp,1);

   rgu_put_body_string(9,nbig_comp,1);

   rgu_put_body_string(9,iofficer,1);

   rgu_put_body_string(9,nname,1);

   rgu_put_body_string(9,iroute,1);

   rgu_put_body_string(9,nroute,1);

   rgu_put_body_string(9,bzfrom,1);

   rgu_put_body_string(9,iadjuster,1);

	 printf("722:sExecType=[%s]\n",sExecType);
	 if(strcmp(sExecType,"R")!=0)
	 {
	   sprintf_s(stmt,2048,
	   " select ncode[1,12]          \
	       from cu_code_data         \
	      where itype = '10'         \
	        and icode = ? ");
	   $prepare bdy1 from $stmt;
	   $execute bdy1
	       into $ncode
	      using $iresource;
	   if (SQLCODE == SQLNOTFOUND)
	   {
	      strcpy(ncode," ");
	   }
	 }
   rgu_put_body_string(9,ncode,1);


   rgu_put_body_string(9,iassured,1);
   rgu_put_body_string(9,nassured,1);
   rgu_put_body_string(9,rtrim(nuser),1);  /* �ϥΤH */
	 strcpy(nuser, rtrim(nuser));

   rgu_put_body_string(9,ibrand,1);

   if(strcmp(sExecType,"R")!=0)
   {
	   rc=read_brand();
	   if (rc<0)
	      strcpy(nbrand,"**********");
	 }
   rgu_put_body_string(9,nbrand,1);

   if(strcmp(sExecType,"R")!=0)
   {
	   rc=read_cartype();
	   if(rc<0)
	     strcpy(car_ncode,"**********");
	 }
   rgu_put_body_string(9,car_ncode,1);

   if(strcmp(sExecType,"R")!=0)
   {
	   if (fsex[0]=='1')
	      strcpy(nfsex,"�k");
	   else if (fsex[0]=='2')
	      strcpy(nfsex,"�k");
	   else
	      strcpy(nfsex," ");
	 }

   rgu_put_body_string(9,nfsex,1);
   rgu_put_body_string(9,ibirth,1);

   if(strcmp(sExecType,"R")!=0)
   {
	   sprintf_s(stmt,2048,
	   " select nvl(ncode,'***')      \
	       from cu_code_data          \
	      where itype = '09'          \
	        and icode = ? ");
	   $prepare bdy2 from $stmt;
	   $execute bdy2
	       into $nfassured
	      using $fassured;
	   if (SQLCODE == SQLNOTFOUND)
	   {
	      strcpy(nfassured," ");
	   }
	 }
   rgu_put_body_string(9,nfassured,1);

printf("824 ----- plia_acc = [%f] sPlia_acc[%s]\n",plia_acc,sPlia_acc);
	 if(strcmp(sExecType,"R")!=0)
   {
   	rfmtdouble(plia_acc, "--&.&&", buf);
   	rgu_put_body_string(9,buf,1);
   }
   else
   {

   	rgu_put_body_string(9,trim(sPlia_acc),1);
   }

   rfmtdouble(pdmg_acc, "--&.&&", buf);
   rgu_put_body_string(9,buf,1);

   if(strcmp(sExecType,"R")!=0)
   {
	   sprintf_s(stmt,2048,
	   " select nvl(dvp_abbr,'***')      \
	       from ca_dvp_ply_area          \
	      where dvp_code = ? ");
	   $prepare bdy3 from $stmt;
	   $execute bdy3
	       into $niacc_area
	      using $iacc_area;
	   if (SQLCODE == SQLNOTFOUND)
	   {
	      strcpy(niacc_area," ");
	   }
	 }
   rgu_put_body_string(9,niacc_area,1);

	 if(strcmp(sExecType,"R")!=0)
   {
	   /* if (facc_sex[0]=='1')
	       strcpy(nfsex,"�k");
	   else if (facc_sex[0]=='2')
	       strcpy(nfsex,"�k");
	   else
	       strcpy(nfsex," ");
	   rgu_put_body_string(9,nfsex,1); */
	   if (facc_sex[0]=='1')
	       strcpy(ndriver_sex,"�k");
	   else if (facc_sex[0]=='2')
	       strcpy(ndriver_sex,"�k");
	   else
	       strcpy(ndriver_sex," ");
   }
   rgu_put_body_string(9,ndriver_sex,1);

   rgu_put_body_string(9,iacc_birth,1);

	 if(strcmp(sExecType,"R")!=0)
   {
	   /* if (facc_rel[0]=='1')
	      strcpy(nfacc_rel,"���H");
	   else if (facc_rel[0]=='2')
	      strcpy(nfacc_rel,"�ˤ�");
	   else if (facc_rel[0]=='3')
	      strcpy(nfacc_rel,"���u");
	   else if (facc_rel[0]=='4')
	      strcpy(nfacc_rel,"����");
	   else if (facc_rel[0]=='5')
	      strcpy(nfacc_rel,"��L");
	   else if (facc_rel[0]=='6')
	      strcpy(nfacc_rel,"�t��");
	   else if (facc_rel[0]=='7')
	      strcpy(nfacc_rel,"�l�k");
	   else strcpy(nfacc_rel,facc_rel); */
	   if (facc_rel[0]=='1')
	      strcpy(nfacc_rel,"���H");
	   else if (facc_rel[0]=='A')
	      strcpy(nfacc_rel,"�۵M�H-�t��");
	   else if (facc_rel[0]=='B')
	      strcpy(nfacc_rel,"�۵M�H-���t����");
	   else if (facc_rel[0]=='C')
	      strcpy(nfacc_rel,"�۵M�H-�S�̩j�f");
	   else if (facc_rel[0]=='D')
	      strcpy(nfacc_rel,"�۵M�H-��L");
	   else if (facc_rel[0]=='E')
	      strcpy(nfacc_rel,"�k�H-�t�d�H");
	   else if (facc_rel[0]=='F')
	      strcpy(nfacc_rel,"�k�H-�t�d�H�a��");
	   else if (facc_rel[0]=='G')
	      strcpy(nfacc_rel,"�k�H-������");
	   else if (facc_rel[0]=='4')
	      strcpy(nfacc_rel,"�k�H-����");
	   else if (facc_rel[0]=='5')
	      strcpy(nfacc_rel,"�k�H-��L");
	   else strcpy(nfacc_rel,facc_rel);
	 }
   rgu_put_body_string(9,nfacc_rel,1);

   rgu_put_body_string(9,factory_tmp,1);

   rgu_put_body_string(9,rtrim(itag),1);
   rgu_put_body_string(9,rtrim(ioth_tag),1);

   rgu_put_body_string(9,rtrim(iengine),1);
   rgu_put_body_string(9,rtrim(iacc_reason),1);

   printf("iclaim = %s , maxflast = %s, ldgroup = %ld \n",iclaim, maxflast, lDgroup);

   rgu_put_body_string(9,rtrim(maxflast),1);

   if(strcmp(sExecType,"R")!=0)
   {
	   rc = read_kreserve();
	   if (rc!= SUCCESS)
	      strcpy(kreserve," ");
	 }
   rgu_put_body_string(9,rtrim(kreserve),1);

   rgu_put_body_string(9,rtrim(dgroup),1);
   if (choice[0] == '1')
   {
      rgu_put_body_string(9," ",2);
   }
   else
   {
      rfmtdouble(pshare, "---&.&&", buf);
      rgu_put_body_string(9,rtrim(buf),2);
   }

   /* For print out [mproc_outstl] */
   rfmtlong(mproc_outstl, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1); /*���M�z�߶O��*/
   /* End of printing */
   
   /* ���[���� */
    if (choice[0] == '2')
    {
    printf("���� ���[���ڤ��e \n");
    printf("���� sFull = %s,ipolicy = %s ,iins_type = %s,provision = %s \n", sFull, ipolicy, iins_type, sProvision);
        sprintf_s(stmt, 2048,
        " select nvl(provision,' ')     \
            from %s:ply_ins_type        \
           where ipolicy = ? AND iins_type = ? ; ", sFull);
        $prepare bdy4 from $stmt;
        $execute bdy4
            into $sProvision
            using $ipolicy, $iins_ply;
        if (SQLCODE == SQLNOTFOUND)
        {
            strcpy(sProvision, " ");
        }
        rgu_put_body_string(9, sProvision, 1);
    }
    else
    {
        rgu_put_body_string(9, " ", 1);
    }	

   rfmtlong(minjured_cover, "---,---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   rfmtlong(mdeath_cover, "---,---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   rfmtlong(mdamage_cover, "---,---,---,--&", buf);
   rgu_put_body_string(9,buf,1);

   /* �o�Ӥ�� */
   rgu_put_body_string(9,rtrim(iissue_ym),1);
   /* �ӫO�a�ϥN�� */
   rgu_put_body_string(9,iply_area,1);

   /* �������O�l�v���B */
   if (choice[0] == '1')
   {
       rfmtlong(msum_health, "---,---,--&", buf);
       rgu_put_body_string(9,buf,1);
   }
   else
   {
       rgu_put_body_string(9," ",1);
   }

   rgu_put_body_string(9,rtrim(accident_duty),1); /*�F�d*/
   strcpy(accident_duty, rtrim(accident_duty));

   rgu_put_body_string(9,itoa(qduty_adjuster),1);

   rgu_put_body_string(9,dentry,1);

   rfmtlong(mpart, "---,---,---,--&", buf);
   rgu_put_body_string(9,ltrim(buf),1);
   printf("mpart = %s \n",buf);


   rfmtlong(mplate_and_remove, "---,---,---,--&", buf);
   rgu_put_body_string(9,ltrim(buf),1);
   printf("mplate_and_remove = %s \n",buf);

   rfmtlong(mvarnish, "---,---,---,--&", buf);
   rgu_put_body_string(9,ltrim(buf),1);
   printf("mvarnish = %s \n",buf);

   rgu_put_body_string(9,icar_series,1);

   rgu_put_body(9);

   max_count ++;

	 /* �g�J��Ʈw car908_wkd */
   if(strcmp(sExecType,"A")==0)
   {
   		printf("iclaim=[%s] ipolicy=[%s]\n",iclaim,ipolicy);
   		$insert into sysdb:car908_wkd
   		 	(idatano, fclass, ical_type, iquota, nquota,
	       nchi_full, dply_begin, dpolicy, daccident, dclaim,
	       dclose, nbranch, naffiliated, iclaim, ipolicy,
	       ivictim, iins_type, nins_type, mins_premium, mins_app,
	       mins_outstl_bgn, mins_outstl_end, mclose, mins_stl_close, mins_recovery,
	       mins_proc_close, mdeduct, ibig_comp, nbig_comp, iofficer,
	       nofficer, iroute, nroute, bzfrom, iadjuster,
	       nresource, iassured, nassured, nuser, ibrand,
	       nbrand, car_ncode, nfsex, ibirth, nfassured,
	       plia_acc, pdmg_acc, niacc_area, ndriver_sex, iacc_birth,
	       nfacc_rel, factory_tmp, itag, ioth_tag, iengine,
	       iacc_reason, maxflast, kreserve, dgroup, pshare,
	       mproc_outstl, minjured_cover, mdeath_cover, mdamage_cover, iissue_ym,
	       iply_area, mstl_health, accident_duty, qduty_adjuster, dentry,
	       mpart, mplate, mvarnish, ncar_series, mis_app_chk)
	     values
	     ($sIdataNo, $choice, $option, $iquota, $fullname1,
	      $nchi_full, $dply_begin, $dpolicy, $daccident, $dclaim,
	      $dclose, $nbranch, $naffiliated, $iclaim, $ipolicy,
	      $ivictim, $iins_type, $nins_type, $mins_premium, $mins_app,
	      $out_mins_outstl, $mins_outstl, $mclose, $mins_stl_close, $mins_recovery_close,
	      $mins_proc_close, $mdeduct, $ibig_comp, $nbig_comp, $iofficer,
	      $nname, $iroute, $nroute, $bzfrom, $iadjuster,
	      $ncode, $iassured, $nassured, $nuser, $ibrand,
	      $nbrand, $car_ncode, $nfsex, $ibirth, $nfassured,
	      $plia_acc, $pdmg_acc, $niacc_area, $ndriver_sex, $iacc_birth,
	      $nfacc_rel, $factory_tmp, $itag, $ioth_tag, $iengine,
	      $iacc_reason, $maxflast, $kreserve, $dgroup, $pshare,
	      $mproc_outstl, $minjured_cover, $mdeath_cover, $mdamage_cover, $iissue_ym,
	      $iply_area, $msum_health, $accident_duty, $qduty_adjuster, $dentry,
	      $mpart, $mplate_and_remove, $mvarnish, $icar_series, $mis_app_chk);
    }

   return SUCCESS;

errexit:
   printf("body[908]:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;

}
/*-------------------End Work--------------------------------------------*/

/******************	FOR ���   ***************/
long car908_body_Actuarial()
{
   char  buf[16],buf1[4];
   short i;
   int   rc;
   $char stmt[2048];

   printf("print car908_body !!\n");

   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

   sprintf_s(stmt,2048,
   " select iins_ply         \
       from insurance_type   \
      where iins_type = ? ");
   $prepare bdy0 from $stmt;
   $execute bdy0
       into $iins_ply
      using $iins_type;
   if (SQLCODE == SQLNOTFOUND)
   {
      strcpy(iins_ply," ");
   }

   rgu_put_body_string(9,trim(iquota),1);/*�~�Z���N��*/
   printf("iquota[%s]\n",iquota);
   rgu_put_body_string(9,trim(fullname1),1);/*�~�Z���W��*/

   /***  mark cyrus
   rgu_put_body_string(9,ibranch,1);
   ***/
   rgu_put_body_string(9,nchi_full,1);/*�X����*/
   rgu_put_body_string(9,dply_begin,1);/*�O��ͮĩl��*/
   rgu_put_body_string(9,dpolicy,1);/*ñ����*/

   rgu_put_body_string(9,daccident,1);/*�X�I��*/
   rgu_put_body_string(9,dclaim,1);/*���z��*/

   /***  mark cyrus
   rgu_put_body_string(9,rtrim(sdclose),1);
   ***/
   rgu_put_body_string(9,rtrim(dclose),1);/*�鵲��*/

   rgu_put_body_string(9,iclaim,1);/*�߮׸��X*/
   rgu_put_body_string(9,ipolicy,1);/*�O�渹�X*/

   rgu_put_body_string(9,ivictim,1);/*���`�H�N��*/
   rgu_put_body_string(9,iins_type,1);/*�I�إN��*/

   rgu_put_body_string(9,nins_type,1);/*�I�ئW��*/

   rfmtlong(mins_premium, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);/*ñ��O�O*/

   rfmtlong(mins_app, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);/*�w���ߴ�*/

   rfmtlong(out_mins_outstl, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);/*���쥼�M*/

   rfmtlong(mins_outstl, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);/*���M�ߴ�*/

   /*****  mark cyrus
   rfmtlong(mins_stl, "---,---,--&", buf);
   *****/
   rfmtlong(mclose, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);/*�w�M�ߴ�*/

   rfmtlong(mins_stl_close, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);/*�ߥI���B*/

   rfmtlong(mins_recovery_close, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);/*�l�v���B*/

   rfmtlong(mins_proc_close, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);/*�z�߶O��*/

   /*****  mark cyrus
   rfmtlong(deduct_tmp, "---,---,--&", buf);
   *****/

   rfmtlong(mdeduct, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);/*�ۭt�B*/

   rgu_put_body_string(9,ibig_comp,1);/*�g�P���q*/

   rgu_put_body_string(9,nbig_comp,1);/*�g�P���q�W��*/

   rgu_put_body_string(9,iofficer,1);/*�g��N��*/

   rgu_put_body_string(9,nname,1);/*�W��*/

   rgu_put_body_string(9,iroute,1);/*�q���O�N��*/

   rgu_put_body_string(9,nroute,1);/*�q���O�W��*/

   rgu_put_body_string(9,bzfrom,1);/*�O�o�q��*/

   rgu_put_body_string(9,iadjuster,1);/*�z�ߤH��*/

	 if(strcmp(sExecType,"R")!=0)
	 {
	   sprintf_s(stmt,2048,
	   " select ncode[1,12]          \
	       from cu_code_data         \
	      where itype = '10'         \
	        and icode = ? ");
	   $prepare bdy1 from $stmt;
	   $execute bdy1
	       into $ncode
	      using $iresource;
	   if (SQLCODE == SQLNOTFOUND)
	   {
	      strcpy(ncode," ");
	   }
	 }
   rgu_put_body_string(9,ncode,1);/*�~�Ȩӷ�*/


   rgu_put_body_string(9,iassured,1);/*�Q�O�I�H�N��*/
   rgu_put_body_string(9,nassured,1);/*�Q�O�I�H*/
   rgu_put_body_string(9,rtrim(nuser),1);  /* �ϥΤH */

   rgu_put_body_string(9,ibrand,1);/*�t�P����*/

   if(strcmp(sExecType,"R")!=0)
	 {
	   rc=read_brand();
	   if (rc<0)
	      strcpy(nbrand,"**********");
	 }
   rgu_put_body_string(9,nbrand,1);/*�t�P��������W��*/

   if(strcmp(sExecType,"R")!=0)
	 {
	   rc=read_cartype();
	   if(rc<0)
	     strcpy(car_ncode,"**********");
	 }
   rgu_put_body_string(9,car_ncode,1);/*����*/

   if(strcmp(sExecType,"R")!=0)
	 {
	   if (fsex[0]=='1')
	      strcpy(nfsex,"�k");
	   else if (fsex[0]=='2')
	      strcpy(nfsex,"�k");
	   else
	      strcpy(nfsex," ");
	 }
   rgu_put_body_string(9,nfsex,1);/*�Q�O�I�H�ʧO*/
   rgu_put_body_string(9,ibirth,1);/*�X�ͤ��*/

   if(strcmp(sExecType,"R")!=0)
	 {
	   sprintf_s(stmt,2048,
	   " select nvl(ncode,'***')      \
	       from cu_code_data          \
	      where itype = '09'          \
	        and icode = ? ");
	   $prepare bdy2 from $stmt;
	   $execute bdy2
	       into $nfassured
	      using $fassured;
	   if (SQLCODE == SQLNOTFOUND)
	   {
	      strcpy(nfassured," ");
	   }
	 }
   rgu_put_body_string(9,nfassured,1);/*�Ȥᨭ��*/

	 if(strcmp(sExecType,"R")!=0)
	 {
	   rfmtdouble(plia_acc, "--&.&&", buf);
	   rgu_put_body_string(9,buf,1);/*�j��ߴګY��*/
	 }
	 else
	 {
	 	 rgu_put_body_string(9,trim(sPlia_acc),1);/*�j��ߴګY��*/
	 }

   rfmtdouble(pdmg_acc, "--&.&&", buf);
   rgu_put_body_string(9,buf,1);/*����ߴګY��*/

   if(strcmp(sExecType,"R")!=0)
	 {
	   sprintf_s(stmt,2048,
	   " select nvl(dvp_abbr,'***')      \
	       from ca_dvp_ply_area          \
	      where dvp_code = ? ");
	   $prepare bdy3 from $stmt;
	   $execute bdy3
	       into $niacc_area
	      using $iacc_area;
	   if (SQLCODE == SQLNOTFOUND)
	   {
	      strcpy(niacc_area," ");
	   }
	 }
	 rgu_put_body_string(9,niacc_area,1);/*�X�I�a*/

	 if(strcmp(sExecType,"R")!=0)
	 {
	   /* if (facc_sex[0]=='1')
	       strcpy(nfsex,"�k");
	   else if (facc_sex[0]=='2')
	       strcpy(nfsex,"�k");
	   else
	       strcpy(nfsex," ");
	   rgu_put_body_string(9,nfsex,1); *//*�F�ƪ̩ʧO*/

	   if (facc_sex[0]=='1')
	       strcpy(ndriver_sex,"�k");
	   else if (facc_sex[0]=='2')
	       strcpy(ndriver_sex,"�k");
	   else
	       strcpy(ndriver_sex," ");

	 }
   rgu_put_body_string(9,ndriver_sex,1);/*�F�ƪ̩ʧO*/

   rgu_put_body_string(9,iacc_birth,1);/*�X�ͤ��*/

   if(strcmp(sExecType,"R")!=0)
	 {
	   /* if (facc_rel[0]=='1')
	      strcpy(nfacc_rel,"���H");
	   else if (facc_rel[0]=='2')
	      strcpy(nfacc_rel,"�ˤ�");
	   else if (facc_rel[0]=='3')
	      strcpy(nfacc_rel,"���u");
	   else if (facc_rel[0]=='4')
	      strcpy(nfacc_rel,"����");
	   else if (facc_rel[0]=='5')
	      strcpy(nfacc_rel,"��L");
	   else if (facc_rel[0]=='6')
	      strcpy(nfacc_rel,"�t��");
	   else if (facc_rel[0]=='7')
	      strcpy(nfacc_rel,"�l�k");
	   else strcpy(nfacc_rel,facc_rel); */
	   if (facc_rel[0]=='1')
	      strcpy(nfacc_rel,"���H");
	   else if (facc_rel[0]=='A')
	      strcpy(nfacc_rel,"�۵M�H-�t��");
	   else if (facc_rel[0]=='B')
	      strcpy(nfacc_rel,"�۵M�H-���t����");
	   else if (facc_rel[0]=='C')
	      strcpy(nfacc_rel,"�۵M�H-�S�̩j�f");
	   else if (facc_rel[0]=='D')
	      strcpy(nfacc_rel,"�۵M�H-��L");
	   else if (facc_rel[0]=='E')
	      strcpy(nfacc_rel,"�k�H-�t�d�H");
	   else if (facc_rel[0]=='F')
	      strcpy(nfacc_rel,"�k�H-�t�d�H�a��");
	   else if (facc_rel[0]=='G')
	      strcpy(nfacc_rel,"�k�H-������");
	   else if (facc_rel[0]=='4')
	      strcpy(nfacc_rel,"�k�H-����");
	   else if (facc_rel[0]=='5')
	      strcpy(nfacc_rel,"�k�H-��L");
	   else strcpy(nfacc_rel,facc_rel);
	 }
   rgu_put_body_string(9,nfacc_rel,1);/*���Y*/

   rgu_put_body_string(9,factory_tmp,1);/*�O�׳�*/

   rgu_put_body_string(9,rtrim(itag),1);/*�P�Ӹ��X*/
   rgu_put_body_string(9,rtrim(ioth_tag),1);/*��y�P�Ӹ��X*/

   rgu_put_body_string(9,rtrim(iengine),1);/*�������X*/
   rgu_put_body_string(9,rtrim(iacc_reason),1);/*�X�I��]*/

   printf("iclaim = %s , maxflast = %s, ldgroup = %ld \n",iclaim, maxflast, lDgroup);

   rgu_put_body_string(9,rtrim(maxflast),1);/*���קO*/

   if(strcmp(sExecType,"R")!=0)
	 {
	   rc = read_kreserve();
	   if (rc!= SUCCESS)
	      strcpy(kreserve," ");
	 }
   rgu_put_body_string(9,rtrim(kreserve),1);/*�ǳƪ��I�O*/
   rgu_put_body_string(9,rtrim(dgroup),1);/*�J�p���*/
   if (choice[0] == '1')
   {
      rgu_put_body_string(9," ",2);/*�ۯd�v*/
   }
   else
   {
      rfmtdouble(pshare, "---&.&&", buf);
      rgu_put_body_string(9,rtrim(buf),2);/*�ۯd�v*/
   }

   /* For print out [mproc_outstl] */
   rfmtlong(mproc_outstl, "---,---,--&", buf);
   rgu_put_body_string(9,buf,1);/*���M�z�߶O��*/
   /* End of printing */

   rfmtlong(minjured_cover, "---,---,---,--&", buf);
   rgu_put_body_string(9,buf,1);/*�O�B1*/

   rfmtlong(mdeath_cover, "---,---,---,--&", buf);
   rgu_put_body_string(9,buf,1);/*�O�B2*/

   rfmtlong(mdamage_cover, "---,---,---,--&", buf);
   rgu_put_body_string(9,buf,1);/*�O�B3*/

   /* �o�Ӥ�� */
   rgu_put_body_string(9,rtrim(iissue_ym),1);/*�o�Ӥ��*/
   /* �ӫO�a�ϥN�� */
   rgu_put_body_string(9,iply_area,1);/*�{�O�a�ϥN��*/

   /* �������O�l�v���B */
   if (choice[0] == '1')
   {
       rfmtlong(msum_health, "---,---,--&", buf);
       rgu_put_body_string(9,buf,1);/*�������O�l�v���B*/
   }
   else
   {
       rgu_put_body_string(9," ",1);/*�������O�l�v���B*/
   }

   rgu_put_body_string(9,rtrim(accident_duty),1); /*�F�d�d���N��*/

   rgu_put_body_string(9,itoa(qduty_adjuster),1); /*�����F�d���*/

   rgu_put_body(9);
   max_count ++;


   return SUCCESS;

errexit:
   printf("body[908]:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;

}

long read_brand()
{
$char  ipro_year[4],drate[11];
$char  stmt[1024];

   $WHENEVER SQLERROR GOTO errexit;
        $SET LOCK MODE TO WAIT;

   $declare cur_brand cursor for
     select replace(nbrand,chr(9),''),ipro_year,drate
       into $nbrand,$ipro_year,$drate
       from ca_car_model
      where ibrand = $ibrand
      order by drate desc,ipro_year desc;
   $open    cur_brand;
   $fetch   cur_brand
     into   $nbrand, $ipro_year,$drate;
   /***
   sprintf_s(stmt,1024,
   " select first 1 ncode[1,30] \
       from sysdb:cm_group      \
      where igroup = '04'       \
        and ilevel = 0          \
        and icode = ? ");
   $prepare brand_id from $stmt;
   $execute brand_id into $nbrand using $ibrand;
   ***/
   if (SQLCODE == SQLNOTFOUND)
   {
       strcpy(nbrand," ");
   }
   $close   cur_brand;
   return SUCCESS;
errexit:
   printf("read_brand[908]:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long read_cartype()
{
    $char icar_type_tmp[20];
    $char icar_type_chg[3];

    $whenever sqlerror goto errexit;
        $SET LOCK MODE TO WAIT;

   /*strcpy( icar_type_tmp, TRANS_CAR_TYPE(icar_type));*/ /* �ഫ���O�o���� */
   strcpy( icar_type_tmp, trim(icar_type));

   /* $select ncode,fcar_class
      into $car_ncode,$fcar_class
      from car_type
     where fclass = '1' and icode = $icar_type_tmp; */
 printf("������ 1146:icar_type=[%s]sFrate=[%s]icar_type_tmp=[%s]\n",icar_type,sFrate,icar_type_tmp);
   /* ���ئW��--(���ഫ��) */
    $select ncode
      into $car_ncode
      from car_type
     where fclass = '1' and icode = $icar_type_tmp;
     strcat(icar_type_tmp,car_ncode);

     printf("������ 1154:icar_type=[%s]sFrate=[%s]icar_type_tmp=[%s]car_ncode=[%s]\n",icar_type,sFrate,icar_type_tmp,car_ncode);

     strcpy(car_ncode,icar_type_tmp);
     if( SQLCODE == SQLNOTFOUND ) strcpy(car_ncode," ");

   printf("������ 1159:icar_type=[%s]sFrate=[%s]\n",icar_type,sFrate);
   strcpy( icar_type_chg, TRANS_CAR_TYPE(icar_type,sFrate)); /* �ഫ���O�o���� modify by sylvia 106.12.18 */
printf("������ 1161:icar_type=[%s]sFrate=[%s]icar_type_tmp=[%s]car_ncode=[%s]icar_type_chg=[%s]\n",icar_type,sFrate,icar_type_tmp,car_ncode,icar_type_chg);
   /* �ۥ�/��~--(�ഫ�᪺) */
    $select fcar_class
       into $fcar_class
       from car_type
      where fclass = '1' and icode = $icar_type_chg;
printf("������ 1164:fcar_class=[%s]icar_type_chg=[%s]\n",fcar_class,icar_type_chg);
   return SUCCESS;
errexit:
   printf("read_area[908]:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long read_kreserve()
{
    $char sProvision_tmp[22];
    $char  icode1[2];
    $whenever sqlerror goto errexit;
    $SET LOCK MODE TO WAIT;

    strcpy(iprodcode," ");

    if (strncmp(iins_ply,"21",2)==0)
    {   /* ���� */
        /* �s�W35����(�L���q�ʤG����)�Φ~���P�_ modify by sylvia 111.08.25  */
        if (strncmp(icar_type,"01",2)==0 || strncmp(icar_type,"02",2)==0 ||
            strncmp(icar_type,"32",2)==0 || strncmp(icar_type,"34",2)==0 ||
            strncmp(icar_type,"35",2)==0 )
        {
            /* icode1 */
            if (atoi(sFrate) >= 63)
            {
                if (strncmp(icar_type,"35",2)==0)
                    strcpy(icode1,"6"); /* �L���q�ʤG�����T�w��6 */
                else
                    strcpy(icode1,"5"); /* �����T�w��5 */
            }
            else
            {
                strcpy(icode1,"3");  /* �����T�w��3 */
            }

            /* icode2 = �~�� */
            if (qply_period > 48)
                strcpy(iprodcode,"5");
            else if (qply_period > 36)
                strcpy(iprodcode,"4");
            else if (qply_period > 24)
                strcpy(iprodcode,"3");
            else if (qply_period > 12)
                strcpy(iprodcode,"2");
            else
                strcpy(iprodcode,"1");
        }
        else
        {
            /* �D���� */
            strcpy(icode1,fcar_class);
            if ((atoi(sFrate) >= 63) && (atoi(fcar_class) == 2))
            {
                strcpy(icode1,"4"); /* �ӥΨT�� */
            }
        }
    }
    else
    {
        /* ���N-���� */
        if (strncmp(icar_type,"01",2)==0 || strncmp(icar_type,"02",2)==0 ||
            strncmp(icar_type,"32",2)==0 || strncmp(icar_type,"34",2)==0 ||
            strncmp(icar_type,"35",2)==0 )
        {
            strcpy(icode1,"3");  /* �����T�w��3 */
        }
        else if (strcmp(trim(iins_ply),"51") == 0)
        {
               strcpy(icode1,"1");
            }
        else
        {
            strcpy(icode1,fcar_class);
        }

        strcpy(sProvision_tmp ,"");
        sprintf_s(sProvision_tmp,22,"%s;",trim(sProvision));
        printf("sProvision_tmp[%s]\n",sProvision_tmp);
        strcpy(sProvision , sProvision_tmp);
        if( strstr(sProvision , "T;") != '\0')
        {
            strcpy( iprodcode, "T");
    	}
    	else
    	{
    	    if ((atoi(sFrate)>=90)&&(ISLEASED_CAR(icar_type)))
    	    {
    	        strcpy( iprodcode, "3");
    	    }
    	}

    	if (strcmp(trim(iins_ply),"58") == 0)
        {
            if (atoi(sFrate)>=94)
                strcpy( iprodcode, "2");
            else
                strcpy( iprodcode, "1");
    	}
    }

    if (strlen(trim(iproduct))>0)
    {
        $select distinct kreserve
               into $kreserve
               from cm_product_code
              where iproduct = $iproduct
                and icode2 = $iprodcode
                and iins_type = $iins_ply;

        if (SQLCODE==SQLNOTFOUND)
        {
            $select distinct kreserve
               into $kreserve
               from cm_product_code
              where iins_class = 'C'
                and iins_type = $iins_ply
                and icode1 = $icode1
                and icode2 = $iprodcode;

            if (SQLCODE==SQLNOTFOUND)
                strcpy(kreserve," ");
        }
    }
    else
    {
        $select distinct kreserve
               into $kreserve
               from cm_product_code
              where iins_class = 'C'
                and iins_type = $iins_ply
                and icode1 = $icode1
                and icode2 = $iprodcode;

            if (SQLCODE==SQLNOTFOUND)
                strcpy(kreserve," ");
    }

   return SUCCESS;

errexit:
   printf("read_kreserve[908]:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long read_ri_share()
{
$int  off_cnt;

   $whenever sqlerror goto errexit;
        $SET LOCK MODE TO WAIT;

   /**/
   $select pret
      into $pshare
      from car908_share
     where iyear = $ri_year
       and imodule = $imodule;
   if (SQLCODE==SQLNOTFOUND)
      return SQLCODE;

   $select count(*)
      into $off_cnt
      from ca_ri_treaty_off
     where iyear = $ri_year
       and imodule = $imodule
       and iofficer = $iofficer;
   if (off_cnt==0) return SUCCESS;

   $select 100 - sum(pshare)
      into $pshare
      from ca_ri_company_info
     where iyear = $ri_year
       and imodule = $imodule;
   if (SQLCODE==SQLNOTFOUND)
      return SQLCODE;

   return SUCCESS;
errexit:
   printf("read_ri_share[908]:SQLCODE[%d],errstr:[%s]\n",SQLCODE,sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
char *split_yymm(edate)
char edate[11];
{
char syymm[6];
int  iyear;
char tmp[5];

     strcpy(tmp,edate+6);
     iyear = atoi(tmp);
     strcpy(syymm,itoa(iyear-1911));
     strncpy(tmp,edate,2);
     tmp[2] = '\0';
     strcat(syymm,tmp);
     return syymm;
}
/*--------------------------------------------------------------------*/

long car908_pre2_create()
{
   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

   $CREATE TEMP TABLE car908_pre2
   (
       iclaim     char(20) default ' ',
       iins_type  char(7)  default ' '
   )WITH NO LOG;

   $CREATE INDEX car908_pre2_ix1 ON car908_pre2(iclaim,iins_type);

   $CREATE TEMP TABLE car908_pre2A
   (
       iclaim     char(20) default ' '
   )WITH NO LOG;

   $CREATE INDEX car908_pre2_ix1A ON car908_pre2A(iclaim);

   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

long car908_pre2_drop()
{
   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

   $DROP TABLE car908_pre2;
   $DROP TABLE car908_pre2A;

   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

long car908_pre2(irule,ddate_bgn,ddate_end,append,sFull)
$char irule[2];
$char ddate_bgn[11];
$char ddate_end[11];
$char append[11];
$char sFull[31];
{
$char stmt[20000];
$char dbname[11];

   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

      sprintf_s(stmt,20000,
      " INSERT INTO car908_pre2     \
          SELECT UNIQUE a.iclaim, a.iins_type                 \
            FROM %s:app_ins_type_hist a, %s:appraisal b       \
           WHERE a.iclaim      = b.iclaim                     \
             AND a.dappraisal <= ?                            \
             AND a.dappraisal  = (SELECT MAX(dappraisal)      \
                                    FROM %s:app_ins_type_hist \
                                   WHERE a.iclaim    = iclaim \
                                     AND a.iins_type = iins_type \
                                     AND dappraisal <= ?)   \
             AND ((a.mins_app+a.mproc_app)-                 \
                  (SELECT NVL(SUM(DECODE(fstl,'2',mins_stl*(-1),mins_stl)+mins_proc),0) \
                     FROM %s:stl_ins_type           \
                    WHERE a.iclaim    = iclaim      \
                      AND a.iins_type = iins_type   \
                      AND dgroup   <= ?) >= 0)      \
             AND NOT EXISTS     \
                    (SELECT *   \
                       FROM %s:stl_ins_type x   \
                      WHERE a.iclaim    = x.iclaim      \
                        AND a.iins_type = x.iins_type   \
                        AND x.flast     = '1'   \
                        AND x.dgroup   <= ?) ",sFull,sFull,sFull,sFull,sFull);
      printf("stmt[%s]\n",stmt);
      $PREPARE asid2 FROM $stmt;
      $EXECUTE asid2 USING $append,$append,$ddate_end,$ddate_end;

      sprintf_s(stmt,20000,
      " INSERT INTO car908_pre2      \
          SELECT UNIQUE iclaim, iins_type   \
            FROM %s:stl_ins_type     \
           WHERE dgroup BETWEEN ? AND ? ",sFull);
      printf("stmt[%s]\n",stmt);
      $PREPARE asid3 FROM $stmt;
      $EXECUTE asid3 USING $ddate_bgn,$ddate_end;

      if (irule[0] == '1')
      {
          sprintf_s(stmt,20000,
          " INSERT INTO car908_pre2     \
              SELECT UNIQUE a.iclaim, a.iins_type                 \
                FROM %s:app_ins_type_hist a, %s:appraisal b       \
               WHERE a.iclaim      = b.iclaim                     \
                 AND a.dappraisal <  ?                            \
                 AND a.dappraisal  = (SELECT MAX(dappraisal)      \
                                        FROM %s:app_ins_type_hist \
                                       WHERE a.iclaim    = iclaim \
                                         AND a.iins_type = iins_type \
                                         AND dappraisal <  ?)   \
                 AND ((a.mins_app+a.mproc_app)-                 \
                  (SELECT NVL(SUM(DECODE(fstl,'2',mins_stl*(-1),mins_stl)+mins_proc),0) \
                     FROM %s:stl_ins_type           \
                    WHERE a.iclaim    = iclaim      \
                      AND a.iins_type = iins_type   \
                      AND dgroup   < ?) >= 0)       \
                 AND NOT EXISTS     \
                        (SELECT *   \
                           FROM %s:stl_ins_type x   \
                          WHERE a.iclaim    = x.iclaim      \
                            AND a.iins_type = x.iins_type   \
                            AND x.flast     = '1'   \
                            AND x.dgroup   < ?) ",sFull,sFull,sFull,sFull,sFull);
          printf("stmt[%s]\n",stmt);
          $PREPARE asid5 FROM $stmt;
          $EXECUTE asid5 USING $ddate_bgn,$ddate_bgn,$ddate_bgn,$ddate_bgn;
      }

      $INSERT INTO car908_pre2A
        SELECT UNIQUE iclaim
          FROM car908_pre2;

 return SUCCESS;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/* -------------------------------------------------------------------------- */
long car908_voluntary()
{
char   fclose,out_fclose;
$int   rec_no,id1,id2;
$char  iquota_14[7];
int    i,rc;
int    rc1;
$char  sWhere_t1[1024];
$char  sWhere_t2[1024];
$char  stmt_vol[5000];

   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

   mins_app=mins_outstl=out_mins_outstl=mins_stl=mstl_health=mclose=mproc_app=0;
   mpart=mplate_and_remove=mvarnish=0;
   out_mins_app = out_mproc_app = 0;
   mins_stl_close=mstl_health_close=mins_recovery_close=mins_proc_close=0;   /* peter */
   mproc_outstl = 0; /* Modified by Julia in 2006/12/08 */
   msum_health = 0;
   mins_proc = 0;
   strcpy(ivictim," ");

/*   printf("ibranch_1 [%s]\n",ibranch_1);*/

   printf("INTO voluntary\n");

   rc = car908_ri_share();
   if (rc != SUCCESS)
      return rc;

      /************************�s�W�X�I��d�߱���**********************************/
      if (strcmp(trim(Date_accident),"*") == 0)
      {
       	  sprintf_s(sWhere_Daccident,125," ");

      }
      else
      {
      	   strcpy(Date_accident , cm_to_infdate(Date_accident) );
           sprintf_s(sWhere_Daccident,125,"AND date(A.daccident) = '%s' ",Date_accident);

      }

      /************************�s�W�q���N���d�߱���**********************************/
      if (strcmp(trim(ID_route),"*") == 0)
      {
      	  sprintf_s(sWhere_Iroute,125," ");

      }
      else
      {
      	   sprintf_s(sWhere_Iroute,125,"AND E.iroute = '%s' ",ID_route);
      }

      /*************************�s�W�g��N���d�߱���**************************************************/
      if (strcmp(trim(ID_officer),"*") == 0)
      {
   	    sprintf_s(sWhere_Iofficer,125," ");

      }
      else
      {
           sprintf_s(sWhere_Iofficer,125,"AND C.iofficer = '%s' ",ID_officer);
      }


      printf("sWhere_Daccident = %s \n",sWhere_Daccident);
      printf("sWhere_Iroute = %s \n",sWhere_Iroute);
      printf("sWhere_Iofficer = %s \n",sWhere_Iofficer);

   /**** �̲έp�覡�����P������� ****/
   switch(option[0]){

   case '1': /* ��~�� */
            sprintf_s(stmt2,256,
            " AND date(A.daccident) <= '%s' ",clsdateend);
            strcpy(dpolicy_ri,clsdateend);
            break;
   case '2': /* �O��� */
            sprintf_s(stmt2,256,
            " AND date(A.daccident) between '%s' and '%s' \
              AND C.dply_begin between '%s' AND '%s' ",
            clsdatebgn,clsdatebasic,clsdatebgn,clsdateend);
            strcpy(dpolicy_ri,clsdatebasic);
            break;
   case '3': /* �ƬG�� */
            sprintf_s(stmt2,256,
            " AND date(A.daccident) between '%s' and '%s' ",
            clsdatebgn,clsdateend);
            strcpy(dpolicy_ri,clsdatebasic);
            break;
   case '4': /* ���z�߮ר� add by sylvia 107.02.09 (1070208003_SC1) */
            sprintf_s(stmt2,256,
            " AND date(A.dclaim) between '%s' and '%s' ",
            clsdatebgn,clsdateend);
            strcpy(dpolicy_ri,clsdatebasic);
            break;
   default :
            break;

   }


   /**** ��ܸ�Ʈw�η~�Z��� ****/

   if (strcmp(trim(ibranch_1),"*") == 0)
   {
/*       printf("cursor2 \n");*/
       strcpy(stmt1,"select branch from servertbl where branch != 'S1' \
                     order by 1 ");
       strcpy(sWhere," ");
   }
   else
   {
/*       printf("cursor3 \n");*/
       $SELECT ibranch_abbr,iquota_grp[1,4]
          INTO $ibranch_abbr,$iquota_b
          FROM branch
         WHERE ibranch = $ibranch_1;
       if (SQLCODE == SQLNOTFOUND)
          return M_CMN_NBRANCH;
/*       printf("&&&&& iquota_b[%s]&&&&&&\n",iquota_b); */
       if (strlen(trim(ibranch_abbr))==0)
          sprintf_s(sWhere,1024," AND D.iquota[1,4] = '%s' ",iquota_b);
       else
          strcpy( sWhere," ");
       sprintf_s(stmt1,1024,"select iupcomp from branch where ibranch = '%s'",
               ibranch_1);
   }

   $PREPARE pre_Acura FROM $stmt1;
   $DECLARE Acur_branch_a CURSOR FOR pre_Acura;
   $OPEN    Acur_branch_a;

   while(1)
   {
      $FETCH Acur_branch_a INTO $sIupbranch;
      if (SQLCODE == SQLNOTFOUND) break;

      strcpy(sFull,get_full_dbname(sIupbranch));
      if (option[0]=='1')  /* ��~�� */
      {
         rc1 = car908_pre2_create();
         if (rc1 != SUCCESS)
         {
            return rc1;
         }

         rc1 = car908_pre2(option,clsdatebgn,clsdateend,append,sFull);
         if (rc1 != SUCCESS)
         {
            return rc1;
         }
         strcpy(sWhere_t1," ,car908_pre2A F");
         strcpy(sWhere_t2," AND A.iclaim = F.iclaim ");
      }
      else
      {
         strcpy(sWhere_t1," ");
         strcpy(sWhere_t2," ");
      }




      printf("[908R] select appraisal begin !!! \n");

      sprintf_s(stmt,2048,
              " SELECT count(*)          \
                  FROM %s:stl_ins_type   \
                 WHERE dgroup >= ?       \
                   AND iclaim = ?        \
                   AND iins_type = ? ",sFull);

      $PREPARE sid2 FROM $stmt;
printf("-- 1929 -- \n");
      sprintf_s(stmt,2048,
              " SELECT count(*) \
                  FROM %s:stl_ins_type \
                 WHERE flast = '1' \
                   AND dgroup < ? \
                   AND iclaim = ? \
                   AND iins_type = ? ",sFull);

      $PREPARE sid3 FROM $stmt;
printf("-- 1939 -- \n");
      sprintf_s(stmt,2048,
             "  SELECT mins_stl , mins_proc , flast , fstl ,dgroup, \
                       mins_dedu \
                  FROM %s:stl_ins_type \
                 WHERE iclaim = ? \
                   AND iins_type = ? \
                   AND dgroup <= ?    ",sFull);

      $PREPARE sid4 FROM $stmt;
      $DECLARE Acursor8a CURSOR FOR sid4;
printf("-- 1950 -- \n");
      sprintf_s(stmt,2048,
             " SELECT nvl(max(dclose),' '),nvl(max(flast),' '), \
                      nvl(max(dgroup),' ')    \
                 FROM %s:stl_ins_type         \
                WHERE iclaim = ?              \
                  AND iins_type = ?           \
                  AND dgroup <= ? ",sFull);

      $PREPARE sid5 FROM $stmt;
printf("-- 1960 -- \n");
      sprintf_s(stmt,2048,
             " SELECT First 1 dappraisal,mins_app,mproc_app,mdeduct   \
                 FROM %s:app_ins_type_hist                  \
                WHERE iclaim = ?                            \
                  AND iins_type = ?                         \
                  AND dappraisal <= ?                       \
                ORDER BY dappraisal Desc ",sFull);
      $PREPARE aphis1 FROM $stmt;
printf("-- 1969 -- \n");
      sprintf_s(stmt,2048,
             " SELECT First 1 dappraisal,mins_app,mproc_app \
                 FROM %s:app_ins_type_hist                  \
                WHERE iclaim = ?                            \
                  AND iins_type = ?                         \
                  AND dappraisal <  ?                       \
                ORDER BY dappraisal Desc ",sFull);
      $PREPARE aphis11 FROM $stmt;
printf("-- 1978 -- \n");
      sprintf_s(stmt,2048,
             " SELECT iproduct,mins_premium,drate_ym,provision \
                 FROM %s:ply_ins_type                       \
                WHERE ipolicy = ?                           \
                  AND iins_type = ? ",sFull);
      $PREPARE iprod1 FROM $stmt;
printf("-- 1985 -- \n");
      sprintf_s(stmt,2048,
             " SELECT dedr_begin, dendorse, fedr_status, minjured_cover, mdeath_cover, mdamage_cover \
                 FROM %s:ply_ins_type_hist \
                WHERE ipolicy = ? \
                  AND iins_type = ? \
                 AND dedr_begin <= ? AND dedr_end >= ? \
                  AND fedr_status < 80 \
                ORDER BY dedr_begin DESC, dendorse DESC, fedr_status DESC;",sFull);
      $PREPARE pr_mcover FROM $stmt;
printf("-- 1995 -- \n");
      sprintf_s(stmt_buf,500,"select nvl(max(ioth_tag),' ') \
                          from %s:stl_oth_dtl         \
                         where iclaim =? ",sFull);
      $prepare  pre12 from $stmt_buf;
printf("-- 2000 -- \n");
      sprintf_s(stmt,2048,
             " SELECT count(*),nvl(sum(mprem),0),nvl(sum(mfac),0), \
                      nvl(sum(msret),0) \
                 FROM %s:ca_ri_ins_dtl \
                WHERE ipolicy = ?      \
                  AND iendorse = ' '   \
                  AND iyear = ?        \
                  AND imodule = ?      \
                  AND iins_type = ?    \
                  AND dpolicy <= ? ", sFull);
      $PREPARE pre_riP from $stmt;
printf("-- 2012 -- \n");
      sprintf_s(stmt,2048,"SELECT first 1 b.qduty_adjuster \
                      FROM ca_ver_relation a ,ca_clm_victim_data b \
                     WHERE a.iverify = b.iclaim  \
                       AND b.fvictim_car = 'F' \
                       AND a.iclaim = ?  \
                       order by 1 desc " );
      $PREPARE qduty_adjuster_1 from $stmt;
printf("-- 2020 -- \n");
      /* ���إN����Ū�̷s�O���� modify by sylvia 106.12.20 (1061130011_C1) */
      sprintf_s(stmt_vol,5000,
             " SELECT  date(A.daccident),date(A.dclaim),  \
                      (SELECT nchi_full FROM branch WHERE ibranch = replace(A.iclaim[1,2],'A','0')), \
                      (SELECT nbranch FROM sa_branch_type WHERE ibranch = a.affiliated),A.iclaim ,  \
                      C.dply_begin,A.ipolicy,B.iins_type,B.mins_app,   \
                      B.mproc_app,C.ibig_comp,C.iofficer,A.iadjuster,  \
                      A.fcard_class,D.iquota,D.iresource,              \
                      C.nassured[1,20],D.ibrand,                       \
                      to_char(A.dacc_birth,'%%Y')::integer-1911||to_char(A.dacc_birth,'%%m%%d'), \
                      A.facc_sex, A.facc_rel, \
                      C.fsex, DECODE(C.dbirth,NULL,' ',to_char(C.dbirth,'%%Y')::integer-1911||'/'||to_char(C.dbirth,'%%m/%%d')), \
                      E.fassured, C.iacc_area, \
                      D.dpolicy, E.plia_acc, E.pdmg_acc ,A.factory_1,  \
                      A.factory32_1,B.mdeduct,H.icar_type,C.itag,      \
                      C.iengine,A.iacc_reason,E.nuser,C.ibig_office,   \
                      D.qply_period,D.itreaty, \
                      to_char(E.dissue,'%%Y')::integer-1911||'/'||to_char(E.dissue,'%%m'), \
                      year(D.dpolicy),         \
                      (SELECT nvl(nchi_full,A.ipolicy[1,2]) FROM branch Z \
                      WHERE Z.ibranch = A.ipolicy[1,2]), A.ofacname[1,60], C.iply_area, E.iroute, E.iassured,   \
                      case WHEN G.fins_grp = '1' THEN A.fdmg_duty ELSE A.facc_duty END,     \
                      B.mins_app, to_char(A.daccident,'%%H') dacc_hours \
                 FROM %s:appraisal A,%s:app_ins_type B,                \
                      %s:adjustment_ply C ,%s:ori_ply_relation D,      \
                      %s:policy E ,insurance_type G, %s:ply_relation H %s                 \
                WHERE A.iclaim = B.iclaim                              \
                  AND C.iclaim = A.iclaim                              \
                  AND A.fcard_class = '2'  and D.ipolicy = H.ipolicy   \
                  AND B.mins_app >= ?  %s %s                           \
                  AND A.ipolicy = D.ipolicy                            \
                  AND A.ipolicy = E.ipolicy                            \
                  AND B.iins_type = G.iins_type                        \
                  %s                                                   \
                  %s                                                   \
                  %s			                               \
                  %s ",sFull,sFull,sFull,sFull,
                sFull,sFull,sWhere_t1,sWhere,stmt2,sWhere_Daccident,sWhere_Iroute,sWhere_Iofficer,sWhere_t2);
printf("-- 2059 -- \n");
      printf("stmt_vol[%s]\n",stmt_vol);
      printf("clsdateend[%s]\n",clsdateend);
printf("-- 2062 -- \n");
      $PREPARE sid1 FROM $stmt_vol;
      $DECLARE Acursora CURSOR FOR sid1 ;
      $OPEN Acursora USING $loss_amt;
      while (1)
      {
          $FETCH Acursora
            INTO $daccident , $dclaim , $nbranch , $naffiliated , $iclaim , $dply_begin ,
                 $ipolicy, $iins_type , $mins_app , $mproc_app,
                 $ibig_comp , $iofficer , $iadjuster_tmp ,
                 $fcard_class , $iquota,
                 $iresource, $nassured, $ibrand,
                 $iacc_birth, $facc_sex, $facc_rel,
                 $fsex, $ibirth, $fassured, $iacc_area,
                 $dpolicy, $plia_acc:id1, $pdmg_acc:id2,
                 $factory_1,$factory32_1,$mdeduct,$icar_type,
                 $itag,$iengine,$iacc_reason,$nuser,$ibig_office,
                 $qply_period,$imodule,$iissue_ym,
                 $ri_year,$nchi_full,$ofacname,$iply_area,$iroute,$iassured,$accident,
                 $mis_app_chk, $dacc_hours;

          if (SQLCODE == SQLNOTFOUND) break;

/*         printf("iclaim[%s]ipolicy[%s]\n",iclaim,ipolicy);*/
          if (id1<0) plia_acc=0;
          if (id2<0) pdmg_acc=0;

				  printf("2107:iclaim=[%s]iins_type[%s]mproc_app=[%d] \n",iclaim,iins_type,mproc_app);

          $EXECUTE aphis1
              INTO $tmp_dappraisal,$mins_app,$mproc_app,$mdeduct
             USING $iclaim,$iins_type,$append;
          if (SQLCODE == SQLNOTFOUND)
          {
             /** ��������v�ɧ䤣����ܩ�I���e�|���w�� **/
             printf("END iclaim[%s]\n",iclaim);
             continue;
          }
printf("2118:iclaim=[%s]iins_type[%s]mproc_app=[%d] \n",iclaim,iins_type,mproc_app);
          $EXECUTE qduty_adjuster_1 INTO $qduty_adjuster USING $iclaim;
          printf("-------iclaim[%s]+++++++++\n",iclaim);
          printf("-------qduty_adjuster[%d]+++++++++\n",qduty_adjuster);

          /*�F�Ƴd��*/
          if(strcmp(trim(accident),"1")==0)
          {
                strcpy(accident_duty,"1:���F�d,�O��");
          }
          else if(strcmp(trim(accident),"2")==0)
          {
                strcpy(accident_duty,"2:�L�F�d,���O��");
          }
          else
          {
                strcpy(accident_duty,"3:���F�d,���O��");
          }

          /* �q���W�� */
          $SELECT nroute INTO $nroute FROM cm_route WHERE iroute = $iroute;
          if (SQLCODE == SQLNOTFOUND) strcpy(nroute, " ");

          if (option[0]=='1')  /* ��~�� */
          {
             $EXECUTE aphis11
                 INTO $out_tmp_dappraisal,$out_mins_app,$out_mproc_app
                USING $iclaim,$iins_type,$clsdatebgn;

             if (SQLCODE == SQLNOTFOUND)
             {
                out_tmp_dappraisal = 0;
                out_mins_app = 0;
                out_mproc_app = 0;
             }

          /***************************************
          printf("flag3\n");
             $EXECUTE sid2
                 INTO $iCnt USING $clsdatebgn ,$iclaim, $iins_type;

             if (iCnt == 0)
             {
                $EXECUTE sid3
                    INTO $iCnt USING $clsdatebgn, $iclaim, $iins_type;
                if (iCnt > 0) continue;
             }
          **************************************/
          }

          $SELECT nins_type,fins_grp,iins_ply
             INTO $nins_type,$fins_grp,$iins_ply
             FROM insurance_type
            WHERE iins_type = $iins_type;
          if (SQLCODE==SQLNOTFOUND) {
              strcpy(nins_type,iins_type);
              strcpy(iins_ply,iins_type);
              strcpy(fins_grp," ");
          }

          $EXECUTE iprod1 INTO $iproduct,$mins_premium, $sFrate, $sProvision
             USING $ipolicy, $iins_ply;
          if (SQLCODE==SQLNOTFOUND)
          {
            strcpy(iproduct," ");
            strcpy(sFrate," ");
            strcpy(sProvision," ");
          }

          $DECLARE cur_mcover CURSOR FOR pr_mcover;
          $OPEN cur_mcover USING $ipolicy, $iins_ply, $daccident, $daccident;
          $FETCH cur_mcover INTO $dedr_begin, $dendorse, $fedr_status, $minjured_cover, $mdeath_cover, $mdamage_cover;
          if (SQLCODE==SQLNOTFOUND) minjured_cover=mdeath_cover=mdamage_cover=0;

          /* �O�B�Ҭ�0�h����l�O�B(���ͮĴ������~) */
          if (minjured_cover==0 && mdeath_cover==0 && mdamage_cover==0)
          {
              sprintf_s(stmt,2048,
                     " SELECT minjured_cover, mdeath_cover, mdamage_cover \
                         FROM %s:ori_ins_type \
                        WHERE ipolicy = ? \
                          AND iins_type = ? ", sFull);
              $PREPARE pr_mcover_ori FROM $stmt;
              $EXECUTE pr_mcover_ori INTO $minjured_cover, $mdeath_cover, $mdamage_cover USING $ipolicy, $iins_ply;
          }

          lDpolicy = cm_ymd_edate(dpolicy);

          /* �M�ץ�^�k�@��O�N�g��N�� */
          if ((strncmp(iofficer,"W",1)   == 0) ||
             (strncmp(iofficer,"G98",3) == 0) ||
             (strncmp(iofficer,"F98",3) == 0))
          {
             $SELECT a.iofficer,b.nname,b.ibigcomp
                INTO $mend_iofficer,$nname,$ibig_comp
                FROM ca_promote_officer a,officer b
               WHERE iofficer_ori = $iofficer
                 AND ibig_office  = $ibig_office
                 AND a.iofficer   = b.iofficer;
             if (SQLCODE == SQLNOTFOUND)
             {
                strcpy(mend_iofficer, trim(iofficer));

                $SELECT nname
                   INTO $nname
                   FROM officer
                  WHERE iofficer = $iofficer;
                if (SQLCODE == SQLNOTFOUND)
                {
                    strcpy(nname," ");
                    strcpy(mend_iofficer," ");
                }
             }
             strcpy(iofficer, trim(mend_iofficer));
          }
          else
          {
             $SELECT nname
                INTO $nname
                FROM officer
               WHERE iofficer = $iofficer;

             if (SQLCODE == SQLNOTFOUND)
             {
                strcpy(nname," ");
                strcpy(iofficer," ");
             }
          }

          /* �O�o�q�� */

          /****
          $SELECT bzfrom
             INTO $bzfrom
             FROM broker_agent
            WHERE ibroker = (SELECT ibroker_top FROM broker_agent
                  WHERE ibroker = (SELECT icar_broker FROM officer_broker WHERE iofficer = $iofficer));
          if (SQLCODE == SQLNOTFOUND) strcpy(bzfrom, " ");
          ****/

          rtnrc = cm_get_bzfrom(iofficer, icomm_obj, irate_type, bzfrom);
          if (rtnrc != M_CM_OK) strcpy(bzfrom," ");


          $SELECT nname
             INTO $iadjuster
             FROM officer
            WHERE iofficer = $iadjuster_tmp;
          if (SQLCODE==SQLNOTFOUND) strcpy(iadjuster,iadjuster_tmp);

          /* peter */
          nbig_comp[0] = '\0';
          if ((ibig_comp[0] != '\0') && (ibig_comp[0] != ' '))
          {
               $SELECT ncode[1,10]
                  INTO $nbig_comp
                  FROM cu_code_data
                 WHERE itype = '22'
                   AND icode = $ibig_comp;
               if (SQLCODE == SQLNOTFOUND)
                   nbig_comp[0] = '\0';
          }

          /* �w���ߴڤιw���O�Υ[�` */
          printf("2282:iclaim=[%s]iins_type[%s]mins_proc=[%d]mproc_app=[%d] \n",iclaim,iins_type,mins_proc,mproc_app);

          mins_app = mins_app + mproc_app;
          out_mins_app = out_mins_app + out_mproc_app;
/*          printf("*******iquota[%s] \n",iquota);*/
printf("2287:iclaim=[%s]iins_type[%s]mins_proc=[%d]mproc_app=[%d] \n",iclaim,mins_proc,mins_app,mproc_app);
           if (fins_grp[0] == '1')
               strcpy(ifpce_id,factory_1);
           else if (fins_grp[0] == '2')
               strcpy(ifpce_id,factory32_1);
           else
               strcpy(ifpce_id," ");
           printf("ifpce_id[%s]\n", ifpce_id);

           sprintf_s(stmt,2048,
             "SELECT FIRST 1 nchi_full[1,60] \
                FROM cu_customer \
               WHERE ifpce_id = ? ");
           $PREPARE kid01 FROM $stmt;
           $EXECUTE kid01 INTO $factory_tmp USING $ifpce_id;
           if (SQLCODE == SQLNOTFOUND)
           {
               $SELECT nfactory
                  INTO $factory_tmp
                  FROM ca_factory
                 WHERE ifactory = $ofacname
                   AND ifactory_ext = ' ';
               if (SQLCODE == SQLNOTFOUND) strcpy(factory_tmp, ofacname);
           }

   /************************************************************/
          printf("[908:]check �w���M���B \n");
          printf("iclaim[%s],iins_type[%s]\n",iclaim,iins_type);

          i = 0;
          out_mclose=0;
          mclose = 0;
          mclose1 = 0;
          fclose = 'N';
          out_fclose = 'N';
          mins_stl_close = mstl_health_close = 0;            /* peter */
          mins_proc_close = 0;           /* peter */
          mins_recovery_close = 0;       /* peter */
          mins_proc = 0;

          if (option[0]=='1')
             $OPEN Acursor8a USING $iclaim,$iins_type,$clsdateend;
          else
             $OPEN Acursor8a USING $iclaim,$iins_type,$clsdatebasic;
          while(1)
          {
             $FETCH Acursor8a
               INTO $mins_stl ,$mins_proc, $flast ,
                    $fstl, $lDgroup, $mdeduct_stl;

             if(SQLCODE == SQLNOTFOUND)
                break;
  printf("2339:iclaim=[%s]iins_type[%s]mins_proc=[%d]mproc_app=[%d] \n",iclaim,iins_type,mins_proc,mproc_app);
/*             printf("[908]:flast[0]===>[%c]\n",flast[0]);*/
             if (option[0]=='1') { /* ��~�� */
                if ((lDgroup) < cm_ymd_edate(cls_datebgn))
                {

                   if (fstl[0] == '1')
                      out_mclose +=  mins_stl + mins_proc;
                   else
                      out_mclose = out_mclose - mins_stl + mins_proc;

                   if (flast[0] == '1')
                       out_fclose = 'Y';
                }

                if (flast[0] == '1')
                    fclose = 'Y' ;

                if (fstl[0] == '1')
                   mclose +=  mins_stl + mins_proc;
                else
                   mclose = mclose - mins_stl + mins_proc;

                if ((lDgroup) >= cm_ymd_edate(cls_datebgn))
                {
                  /* �����w�M */
                   if (fstl[0] == '1')
                   {
                       mclose1 +=  mins_stl + mins_proc;

                       mins_stl_close       +=  mins_stl;      /* peter */
                       mins_proc_close      +=  mins_proc;     /* peter */
                   }
                   else
                   {
                       mclose1 = mclose1 - mins_stl + mins_proc;

                       mins_recovery_close  +=  mins_stl;      /* peter */
                       mins_proc_close      +=  mins_proc;     /* peter */
                   }
                }
             }
             else
             {
                  if (flast[0] == '1')
                      fclose = 'Y' ;

                  if (fstl[0] == '1')
                  {
                     mclose +=  mins_stl + mins_proc;
                     mins_stl_close       +=  mins_stl;      /* peter */
                     mins_proc_close      +=  mins_proc;     /* peter */
                  }
                  else
                  {
                     mclose = mclose - mins_stl + mins_proc;
                     mins_recovery_close  +=  mins_stl;      /* peter */
                     mins_proc_close      +=  mins_proc;     /* peter */
                  }
             }
        }
        $CLOSE Acursor8a;

        /*   ��ӽ߮׸��I�س̤j���鵲�� */
        if (option[0]=='1') {
           $EXECUTE sid5
               INTO $dclose,$maxflast,$dgroup
              USING $iclaim,$iins_type,$clsdateend;
        }
        else {
           $EXECUTE sid5
               INTO $dclose,$maxflast,$dgroup
              USING $iclaim,$iins_type,$clsdatebasic;
        }

        if (option[0]=='1') /* ��~�� begin */
        {
            if((out_tmp_dappraisal != 0) &&
               (out_tmp_dappraisal < cm_ymd_edate(cls_datebgn)))
            {
               if(out_fclose == 'Y')
                  out_mins_outstl = 0;
               else
                  out_mins_outstl = out_mins_app - out_mclose;

               if ( out_mins_outstl < 0)
                    out_mins_outstl = 0;
            }
            else
            {  out_mins_outstl = 0; }
        } /* ��~�� end */

        if (fclose == 'Y')
        {
            mins_outstl = 0;
            mdeduct = mdeduct_stl;
            mproc_outstl = 0;                  /* �L���M�O�� */
        } else {
        		printf("2337:iclaim=[%s]iins_type[%s]mins_proc=[%d]mproc_app=[%d] \n",iclaim,iins_type,mins_proc,mproc_app);
            mins_outstl = mins_app - mclose;
            /* mproc_outstl = mproc_app - mins_proc; */
            mproc_outstl = mproc_app - mins_proc_close; /* ���M�O�� = �w���O�� - �w�M�O�� */
        }
printf("vol-> mpro_outstl[%ld],iclaim[%s],iins_type[%s]\n",mproc_outstl,iclaim,iins_type);

        if ( mins_outstl < 0)
            mins_outstl = 0;

        if ( mproc_outstl < 0)
            mproc_outstl = 0;    /* �p��s�H�s�p�� */

        if (option[0]=='1')
            mclose = mclose1;

        strcpy(iquota_0,substring(iquota,1,4));
        strcat(iquota_0,"00");

        $SELECT nbranch
           INTO $fullname1
           FROM sa_branch_type
          WHERE ibranch  = $iquota_0;
        if (SQLCODE == SQLNOTFOUND) strcpy(fullname1," ");

        $execute pre12 into $ioth_tag using $iclaim;
        if (SQLCODE==SQLNOTFOUND) strcpy(ioth_tag," ");

        /** �A�O�ۯd��v **/

        /** ���ˮ� ca_ri_ins_dtl �O�_����ơA�Y�ӫO�槹���L��ơA�h����Ū�� ca_ri_company_info ��� **/
        iexists_cnt = 1;
        if (atoi(ri_year) <= 2005)
        {
           sprintf_s(stmt,2048,
           " select count(*)                     \
               from %s:ca_ri_ins_dtl             \
              where iyear       =    ?           \
                and ipolicy     =    ?           \
                and iins_type   =    ?           \
                and dpolicy    <=    ?    ",sFull);

           $prepare get_dtl_exists from $stmt;
           $execute get_dtl_exists
               into $iexists_cnt
              using $ri_year, $ipolicy, $iins_ply, $dpolicy_ri;
        }

        if (iexists_cnt == 0)
        {
           /** �A�O�ۯd��v **/
           rc = read_ri_share();
           if (rc != SUCCESS)
               pshare = 100;
        }
        else
        {
           /** �����o�U�~�סB�ҲաB�X�����X���B **/

           sprintf_s(stmt,2048,
           " select nvl(sum(a.mprem * nvl(b.pshare/100.0,0)),0)      \
               from %s:ca_ri_ins_dtl a, ca_ri_company_info b   \
              where a.iyear     =    b.iyear                   \
                and a.imodule   =    b.imodule                 \
                and a.itreaty   =    b.itreaty                 \
                and a.iyear     =    ?          \
                and a.ipolicy   =    ?          \
                and a.iins_type =    ?          \
                and a.dpolicy  <=    ?  %s ", sFull, sWhere_off);
           $prepare get_rin_mprem from $stmt;
           $execute get_rin_mprem
               into $ri_mprem_P
              using $ri_year, $ipolicy, $iins_ply, $dpolicy_ri;

           /** �A���o�O����{}�����B **/

           strcpy(sFull00,get_full_dbname("00"));

           sprintf_s(stmt,2048,
           " SELECT NVL(SUM(c.mprem),0)         \
               FROM %s:ca_fac_status a, %s:ca_fac_reg b, %s:ca_fac_reg_dtl c   \
              WHERE a.ipolicy   = ?             \
                AND a.iestimate = b.iestimate   \
                AND b.icession  = c.icession    \
                AND b.qfac      = c.qfac        \
                AND b.qbillseq  = c.qbillseq    \
                AND b.fplyedr  <> 'C'           \
                AND c.fout      = 'Y'           \
                AND c.iins_type = ? ",sFull00,sFull00,sFull00);

          printf("stmt[%s],ipolicy[%s],iins_type[%s]\n",stmt,ipolicy,iins_ply);
           $prepare get_rin_mfac from $stmt;
           $execute get_rin_mfac
               into $ri_mfac_P
              using $ipolicy, $iins_ply;


           /** �]����{}���줣��A���ca_fac_reg_dtl�� **/
           /********************************************
           sprintf_s(stmt,2048,
           " select nvl(sum(mfac),0) as mfac                          \
               from (                                                 \
             select ipolicy, iendorse, iins_type, nvl(max(mfac),0) as mfac   \
               from %s:ca_ri_ins_dtl                                  \
              where iyear      =     ?                                \
                and itreaty    =     'MQ'                             \
                and ipolicy    =     ?                                \
                and iins_type  =     ?                                \
                and dpolicy   <=     ?                                \
              group by 1,2,3  ) ", sFull);
           $prepare get_rin_mfac from $stmt;
           $execute get_rin_mfac
               into $ri_mfac_P
              using $ri_year, $ipolicy, $iins_ply, $dpolicy_ri;
           ********************************************/

           /** ���o�O��椧�I�ثO�O�X�p **/
           sprintf_s(stmt,2048,
           " select nvl(sum(mprem+mfac+msret),0) as ri_msum_P         \
               from %s:ca_ri_ins_dtl                                  \
              where iyear      =     ?                                \
                and itreaty    =     'MQ'                             \
                and ipolicy    =     ?                                \
                and iins_type  =     ?                                \
                and dpolicy   <=     ? ",sFull);
            $prepare get_rin_msum from $stmt;
            $execute get_rin_msum
                into $ri_msum_P
               using $ri_year, $ipolicy, $iins_ply, $dpolicy_ri;

           if (ri_msum_P == 0)
           {
               pshare = 100.0;
           }
           else
           {
               pshare  = 1.0 - (((double)ri_mprem_P+(double)ri_mfac_P) / (double)ri_msum_P);
               pshare *= 100;
               pshare  = d45(pshare,2);
           }

        }

        /*************  mark cyrus 103.12.05
        rc = read_ri_share();
        if (rc != SUCCESS)
            pshare=0;
        else {
           $EXECUTE pre_riP INTO $ri_cnt_P,$ri_mprem_P,$ri_mfac_P,$ri_msret_P
                      USING $ipolicy,$ri_year,$imodule,$iins_ply,$dpolicy_ri;
           if (ri_cnt_P > 1) {
              ri_mprem_P = ri_mprem_P / ri_cnt_P;
              ri_mfac_P  = ri_mfac_P  / ri_cnt_P;
              ri_msret_P = ri_msret_P / ri_cnt_P;
           }
           $EXECUTE pre_riE INTO $ri_cnt_E,$ri_mprem_E,$ri_mfac_E,$ri_msret_E
                        USING $ipolicy,$ri_year,$imodule,$iins_ply,$dpolicy_ri;
           if (ri_cnt_E > 1) {
              ri_mprem_E = ri_mprem_E / ri_cnt_E;
              ri_mfac_E  = ri_mfac_E  / ri_cnt_E;
              ri_msret_E = ri_msret_E / ri_cnt_E;
           }
           ri_mprem = ri_mprem_P + ri_mprem_E;
           ri_mfac  = ri_mfac_P  + ri_mfac_E;
           ri_msret = ri_msret_P + ri_msret_E;
           if (ri_mfac != 0 || ri_msret != 0) {
              pshare = ((double)(ri_mprem - ri_mfac - ri_msret) * pshare
                       + ri_msret ) / ri_mprem;
           }
        }
        *************/

/*printf("pshare[%f]\n",pshare);*/
      /*****************************************************/


      printf("*************************************ADD NEW*******************************\n");
      printf("*************************************ADD NEW*******************************\n");
      printf("iclaim = %s \n",iclaim);
      printf("sFull = %s \n",sFull);
      /*********************�z���**********************************/
       sprintf_s(stmt ,2048, "SELECT MAX(dentry) "
       		      "FROM %s:settlement "
       		      "WHERE iclaim = '%s' ",sFull,iclaim,iins_type);

       printf("dentry stmt = %s \n",stmt);

       $prepare Dentry from $stmt;
       $execute Dentry
       		into $dentry;


        /*******************��ˡB���ơB�z���u��*******************************************/
        sprintf_s(stmt,2048,
           "SELECT sum(cpi.mpart),sum(cpi.mplate+cpi.mremove),sum(cpi.mvarnish) "
           "FROM ca_pro_ins cpi , ca_sign_receipt csr,%s:stl_ins_type sit "
           "WHERE cpi.iclaim = csr.iclaim "
           "AND cpi.iclaim = sit.iclaim "
           "AND cpi.isign = csr.isign "
           "AND cpi.iins_type = sit.iins_type "
           "AND csr.iclose_type = sit.iclose_type "
           "AND sit.fstl = '1' "
           "AND cpi.iclaim='%s' "
           "AND cpi.iins_type ='%s' "
           "AND cpi.isign <> ' ' ",sFull,iclaim,iins_type);

        $prepare sum_momey from $stmt;
        $execute sum_momey
            into $mpart,$mplate_and_remove,$mvarnish;


        /**********************�i�f �B �겣  ***********************************************/

        sprintf_s(stmt,2048,"SELECT min(ccm.icar_series) "
                     "FROM ca_car_model ccm , %s:adjustment_ply ap "
                     "WHERE ap.ibrand = ccm.ibrand "
                     "AND ap.iclaim = ?  " , sFull);

        $prepare icar_type from $stmt;
        $execute icar_type
            into $temp_icar_series
           using $iclaim;

        int tttt=strncmp(temp_icar_series,"10",2);
        printf("Result = %d \n",tttt);


        if(strncmp(temp_icar_series,"10",2)==0 )
        {
        	strcpy(icar_series,"�겣��");
        }
        else
        {
        	strcpy(icar_series,"�i�f��");
        }

        printf("icar_series = %s \n",icar_series);
        printf("temp_icar_series = %s \n",temp_icar_series);



        /*** 1.����  2.�D���� ***/
        printf("Actuarial = %s \n",Actuarial);
        if(Actuarial[0]=='1')
        {
        	printf("****************���� *********************\n");
        	car908_body_Actuarial();
        }
        else if(Actuarial[0]=='4')
        {
                printf("****************�l���� *********************\n");
                 
                $select first 1 '(' || a.fcause_adjuster || ').' || c.ncode 
                   into $ncause_adjuster
                   from ca_clm_victim_data a, ca_ver_relation b, cu_code_data c
                  where a.iclaim          =  b.iverify
                    and b.iclaim          =  $iclaim
                    and a.fcause_adjuster =  c.icode
                    and c.itype           =  'BE'
                    and a.fvictim_car     =  'F';
  
                if (SQLCODE == SQLNOTFOUND)
                {
                    strcpy(ncause_adjuster," ");
                }

                printf("INTO ncause_adjuster[%s]\n", ncause_adjuster);

        	car908_body_LossDef();
        }
        else
	    {
		    printf("****************�D���� *********************\n");
		    if(Actuarial[0]=='3')
		        car908_body_ec();   /* �q�� */
		    else
        	    car908_body();      /* ��L */
        }



        mins_app=mins_outstl=out_mins_outstl=mins_stl=mstl_health=0;
        mclose=mclose1=mproc_app=mins_proc=0 ;
        mins_stl_close=mstl_health_close=mins_recovery_close=mins_proc_close=0;/* peter */
        msum_health=0;
      }

      $CLOSE Acursora;
      $FREE Acursora;

      if (option[0]=='1')  /* ��~�� */
      {
         rc1 = car908_pre2_drop();
         if (rc1 != SUCCESS)
         {
            return rc1;
         }
      }
   }

   $CLOSE Acur_branch_a;
   $FREE  Acur_branch_a;
   rgu_put_body(10);   max_count ++;

   return SUCCESS;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}


/*--------------------------------------------------------------------*/
long car908_compulsory()
{
   char   fclose,ffclose,out_fclose,out_ffclose;
   $int   rec_no,id1,id2;
   $char  iquota_14[7];
   int    i,rc;
   $int    qlia_acc;
   $double plia_acc;
   $char   flast_1[2];
   $char   stmt_com[5000];

   $WHENEVER SQLERROR GOTO errexit;
        $SET LOCK MODE TO WAIT;

/*   printf("[908]:creating temp table..\n");
   printf("loss_amt[%d]\n",loss_amt); */
   qlia_acc = 0;
   plia_acc = 0;
   mdeduct  = 0;
   pshare   = 0;

   mins_app=mins_outstl=out_mins_outstl=mins_stl=mstl_health=mclose=mproc_app=mins_proc=0;
   out_mins_app=out_mproc_app=0;
   mins_stl_close=mstl_health_close=mins_recovery_close=mins_proc_close=0;   /* peter */
   mproc_outstl = 0; /* Modified by Julia in 2006/12/08 */
   msum_health = 0;

/*   printf("ibranch_1 [%s]\n",ibranch_1); */


       /************************�s�W�X�I��d�߱���**********************************/
      if (strcmp(trim(Date_accident),"*") == 0)
      {
       	  sprintf_s(sWhere_Daccident,125," ");

      }
      else
      {
           strcpy(Date_accident , cm_to_infdate(Date_accident) );
           sprintf_s(sWhere_Daccident,125,"AND date(A.daccident) = '%s' ",Date_accident);
      }

      /************************�s�W�q���N���d�߱���**********************************/
      if (strcmp(trim(ID_route),"*") == 0)
      {
      	  sprintf_s(sWhere_Iroute,125," ");

      }
      else
      {
      	   sprintf_s(sWhere_Iroute,125,"AND E.iroute = '%s' ",ID_route);
      }

      /*************************�s�W�g��N���d�߱���**************************************************/
      if (strcmp(trim(ID_officer),"*") == 0)
      {
   	    sprintf_s(sWhere_Iofficer,125," ");

      }
      else
      {
           sprintf_s(sWhere_Iofficer,125,"AND C.iofficer = '%s' ",ID_officer);
      }

   /**** �̲έp�覡�����P������� ****/
   switch(option[0]){

   case '1': /* ��~�� */
            sprintf_s(stmt2,256,
            " AND date(A.daccident) <= '%s' ",clsdateend);
            break;
   case '2': /* �O��� */
            sprintf_s(stmt2,256,
            " AND date(A.daccident) between '%s' and '%s' \
              AND C.dply_begin between '%s' AND '%s' ",
            clsdatebgn,clsdatebasic,clsdatebgn,clsdateend);
            break;
   case '3': /* �ƬG�� */
            sprintf_s(stmt2,256,
            " AND date(A.daccident) between '%s' and '%s' ",
            clsdatebgn,clsdateend);
            break;
   case '4': /* ���z�߮ר� add by sylvia 107.02.09 (1070208003_SC1) */
            sprintf_s(stmt2,256,
            " AND date(A.dclaim) between '%s' and '%s' ",
            clsdatebgn,clsdateend);
            break;
   default :
            break;

   }
   /**** ��ܸ�Ʈw�η~�Z��� ****/

   if (strcmp(trim(ibranch_1),"*") == 0)
   {
/*       printf("cursor2 \n"); */
       strcpy(stmt1,"select branch from servertbl where branch != 'S1' \
                     order by 1 ");
       strcpy(sWhere," ");
   }
   else
   {
/*       printf("cursor3 \n"); */
       $SELECT ibranch_abbr,iquota_grp[1,4]
          INTO $ibranch_abbr,$iquota_b
          FROM branch
         WHERE ibranch = $ibranch_1;
       if (SQLCODE == SQLNOTFOUND)
          return M_CMN_NBRANCH;
/*       printf("&&&&& iquota_b[%s]&&&&&&\n",iquota_b); */
       if (strlen(trim(ibranch_abbr))==0)
          sprintf_s(sWhere,1024," AND D.iquota[1,4] = '%s' ",iquota_b);
       else
          strcpy( sWhere," ");
       sprintf_s(stmt1,1024,"select iupcomp from branch where ibranch = '%s'",
               ibranch_1);
   }

   $PREPARE pre_Acurb FROM $stmt1;
   $DECLARE Acur_branch_b CURSOR FOR pre_Acurb;
   $OPEN    Acur_branch_b;

   while(1)
   {
      $FETCH Acur_branch_b INTO $sIupbranch;
      if (SQLCODE == SQLNOTFOUND) break;

      strcpy(sFull,get_full_dbname(sIupbranch));

/*      printf("[908R] select appraisal begin !!! \n"); */

      sprintf_s(stmt,2048,
             " SELECT count(*)             \
                 FROM %s:ca_stl_victim     \
                WHERE iclaim = ?           \
                  AND iins_item = ?        \
                  AND ivictim = ?          \
                  AND dgroup >= ? ",sFull);
      $PREPARE vid3 FROM $stmt;

      sprintf_s(stmt,2048,
             " SELECT count(*)              \
                 FROM %s:ca_stl_victim      \
                WHERE iclaim = ?            \
                  AND iins_item = ?         \
                  AND ivictim = ?           \
                  AND dgroup < ?            \
                  AND flast = ?   ",sFull);
      $PREPARE vid4 FROM $stmt;

      sprintf_s(stmt,2048,
             " SELECT fstl,mins_stl,mins_proc,mstl_health,flast,dgroup\
                 FROM %s:ca_stl_victim                                \
                WHERE iclaim = ?                                      \
                  AND iins_item = ?                                   \
                  AND ivictim = ?                                     \
                  AND dgroup <= ?       ",sFull);
      $PREPARE vid2 FROM $stmt;
      $DECLARE Acursor8d CURSOR FOR vid2;

      sprintf_s(stmt,2048,
             " SELECT fstl, mins_stl, mins_proc, mstl_health          \
                 FROM %s:ca_stl_victim                                \
                WHERE iclaim = ?                                      \
                  AND iins_item = ?                                   \
                  AND ivictim = ?                                     \
                  AND dgroup <= ? ",sFull);
      $PREPARE vid2a FROM $stmt;
      $DECLARE Acursor10d CURSOR FOR vid2a;


      sprintf_s(stmt,2048,
             " SELECT max(dclose),max(flast),max(dgroup)              \
                 FROM %s:ca_stl_victim                                \
                WHERE iclaim = ?                                      \
                  AND iins_item = ?                                   \
                  AND ivictim = ?                                     \
                  AND dgroup <= ? ",sFull);
      $PREPARE vid5 FROM $stmt;

      sprintf_s(stmt,2048,
             " SELECT First 1 dappraisal,mapp_cover,mapp_fee    \
                 FROM %s:ca_app_victim_hist            \
                WHERE iclaim = ?                       \
                  AND iins_item = ?                    \
                  AND ivictim = ?                      \
                  AND dappraisal <= ?                  \
                ORDER BY dappraisal Desc ",sFull);
      $PREPARE cahis1 FROM $stmt;

      sprintf_s(stmt,2048,
             " SELECT First 1 dappraisal,mapp_cover,mapp_fee    \
                 FROM %s:ca_app_victim_hist            \
                WHERE iclaim = ?                       \
                  AND iins_item = ?                    \
                  AND ivictim = ?                      \
                  AND dappraisal < ?                  \
                ORDER BY dappraisal Desc ",sFull);
      $PREPARE cahis11 FROM $stmt;

      sprintf_s(stmt,2048,
             " SELECT iproduct,mins_premium,drate_ym,provision        \
                 FROM %s:ply_ins_type                       \
                WHERE ipolicy = ? ",sFull);
      $PREPARE iprod4 FROM $stmt;

      sprintf_s(stmt_buf,500,"select max(ioth_tag)          \
                          from %s:stl_oth_dtl         \
                         where iclaim =? ",sFull);
      $prepare  pre12 from $stmt_buf;

      sprintf_s(stmt,2048,
             " SELECT First 1 dappraisal,mapp_cover,mapp_fee    \
                 FROM %s:ca_app_victim_hist            \
                WHERE iclaim = ?                       \
                  AND iins_item = ?                    \
                  AND ivictim = ?                      \
                  AND dappraisal < ?                  \
                ORDER BY dappraisal Desc ",sFull);
      $PREPARE cahis11 FROM $stmt;

      sprintf_s(stmt,2048,"SELECT first 1 b.qduty_adjuster \
                      FROM ca_ver_relation a ,ca_clm_victim_data b \
                     WHERE a.iverify = b.iclaim  \
                       AND b.fvictim_car = 'F' \
                       AND a.iclaim = ? \
                       order by 1 desc " );
      $PREPARE qduty_adjuster_1 from $stmt;

      /* ���إN����Ū�̷s�O���� modify by sylvia 106.12.20 (1061130011_C1) */
      sprintf_s(stmt_com,5000,
             " SELECT date(A.daccident),date(A.dclaim),    \
                      (SELECT nchi_full FROM branch WHERE ibranch = replace(A.iclaim[1,2],'A','0')), \
                      (SELECT nbranch FROM sa_branch_type WHERE ibranch = a.affiliated),A.iclaim ,  \
                      C.dply_begin,A.ipolicy,B.iins_item,B.mapp_cover, \
                      B.mapp_fee,C.ibig_comp,C.iofficer,A.iadjuster,   \
                      A.fcard_class,D.iquota,D.iresource,              \
                      C.nassured[1,20], D.ibrand, \
                      to_char(A.dacc_birth,'%%Y')::integer-1911||to_char(A.dacc_birth,'%%m%%d'), \
                      A.facc_sex,A.facc_rel,C.fsex, \
                      DECODE(C.dbirth,NULL,' ',to_char(C.dbirth,'%%Y')::integer-1911||'/'||to_char(C.dbirth,'%%m/%%d')), \
                      E.fassured,C.iacc_area,D.dpolicy,E.plia_acc,     \
                      E.pdmg_acc,A.factory_1,A.factory32_1,            \
                      D.fcomp_class,B.ivictim,H.icar_type,C.itag,      \
                      C.iengine,A.iacc_reason,E.nuser,C.ibig_office,   \
                      D.qply_period, \
                      to_char(E.dissue,'%%Y')::integer-1911||'/'||to_char(E.dissue,'%%m'), \
                      A.ofacname[1,60], C.iply_area, E.iroute, E.iassured, A.facc_duty, \
                      B.mapp_cover, to_char(A.daccident,'%%H') dacc_hours \
                 FROM %s:appraisal A,%s:ca_app_victim B,               \
                      %s:adjustment_ply C,%s:ori_ply_relation D,       \
                      %s:policy E, %s:ply_relation H                   \
                WHERE A.iclaim = B.iclaim                              \
                  AND C.iclaim = A.iclaim                              \
                  AND A.fcard_class = '1'  and D.ipolicy = H.ipolicy   \
                  AND B.mapp_cover >= ?                                \
                  %s %s                                                \
                  AND A.ipolicy = D.ipolicy                            \
                  AND A.ipolicy = E.ipolicy                            \
                  %s                                                   \
                  %s                                                   \
                  %s ",sFull,sFull,sFull,sFull,
                sFull,sFull,sWhere,stmt2,sWhere_Daccident,sWhere_Iroute,sWhere_Iofficer);

      printf("stmt_com[%s]\n",stmt_com);
      $PREPARE vid1 FROM $stmt_com;
      $DECLARE Acursord CURSOR FOR vid1;
      $OPEN    Acursord USING $loss_amt;
      while(1)
      {
         $FETCH Acursord INTO $daccident,$dclaim,$nbranch,$naffiliated,$iclaim,$dply_begin,
                              $ipolicy,$iins_item,$mins_app,$mproc_app,
                              $ibig_comp,$iofficer,$iadjuster_tmp,
                              $fcard_class , $iquota,
                              $iresource, $nassured, $ibrand,
                              $iacc_birth, $facc_sex, $facc_rel,
                              $fsex, $ibirth, $fassured, $iacc_area,
                              $dpolicy, $plia_acc:id1, $pdmg_acc:id2 ,
                              $factory_1,$factory32_1, $fcomp_class,
                              $ivictim, $icar_type, $itag, $iengine,
                              $iacc_reason,$nuser,$ibig_office,
                              $qply_period,$iissue_ym, $ofacname, $iply_area, $iroute, $iassured, $accident,
                              $mis_app_chk, $dacc_hours;

         if (SQLCODE == SQLNOTFOUND) break;

/*         printf("iclaim[%s]ipolicy[%s]\n",iclaim,ipolicy); */
         if (id1<0) plia_acc=0;
         if (id2<0) pdmg_acc=0;

         $EXECUTE cahis1
                    INTO $tmp_dappraisal,$mins_app,$mproc_app
                   USING $iclaim,$iins_item,$ivictim,$append;
         if (SQLCODE == SQLNOTFOUND)
         {
             /* ��������v�ɧ䤣����ܩ�I���e�|���w�� */
             continue;
         }

          $EXECUTE qduty_adjuster_1 INTO $qduty_adjuster USING $iclaim;
          printf("-------iclaim[%s]+++++++++\n",iclaim);
          printf("-------qduty_adjuster[%d]+++++++++\n",qduty_adjuster);

         /*�F�Ƴd��*/
        if(strcmp(trim(accident),"1")==0)
        {
                strcpy(accident_duty,"1:���F�d,�O��");
        }
        else if(strcmp(trim(accident),"2")==0)
        {
                strcpy(accident_duty,"2:�L�F�d,���O��");
        }
        else
        {
                strcpy(accident_duty,"3:���F�d,���O��");
        }

         /* �q���W�� */
         $SELECT nroute INTO $nroute FROM cm_route WHERE iroute = $iroute;
         if (SQLCODE == SQLNOTFOUND) strcpy(nroute, " ");

         if (option[0]=='1') {
            $EXECUTE cahis11
                INTO $out_tmp_dappraisal,$out_mins_app,$out_mproc_app
               USING $iclaim,$iins_item,$ivictim,$clsdatebgn;

            if (SQLCODE == SQLNOTFOUND)
            {
                out_tmp_dappraisal=0;
                out_mins_app=0;
                out_mproc_app=0;
            }

            $EXECUTE vid3
                INTO $iCnt
               USING $iclaim,$iins_item,$ivictim,$clsdatebgn;

            if (iCnt == 0){
               if ((iins_item[0] == 'B') || (iins_item[0] == 'C'))
                  strcpy(flast_1,"1");
               else
                  strcpy(flast_1,"2");

               $EXECUTE vid4
                   INTO $iCnt
                  USING $iclaim,$iins_item,$ivictim,$clsdatebgn,$flast_1;
               if (iCnt > 0) continue;
            }
         }

         $EXECUTE iprod4 INTO $iproduct,$mins_premium,$sFrate,$sProvision
            USING $ipolicy;

         lDpolicy = cm_ymd_edate(dpolicy);

         /* �M�ץ�^�k�@��O�N�g��N�� */
         if ((strncmp(iofficer,"W",1)   == 0) ||
             (strncmp(iofficer,"G98",3) == 0) ||
             (strncmp(iofficer,"F98",3) == 0))
         {
            $SELECT a.iofficer,b.nname,b.ibigcomp
               INTO $mend_iofficer,$nname,$ibig_comp
               FROM ca_promote_officer a,officer b
              WHERE iofficer_ori = $iofficer
                AND ibig_office  = $ibig_office
                AND a.iofficer   = b.iofficer;
            if (SQLCODE == SQLNOTFOUND)
            {
                strcpy(mend_iofficer, trim(iofficer));

                $SELECT nname
                   INTO $nname
                   FROM officer
                  WHERE iofficer = $iofficer;
                if (SQLCODE == SQLNOTFOUND)
                {
                    strcpy(nname," ");
                    strcpy(mend_iofficer," ");
                }
             }
             strcpy(iofficer, trim(mend_iofficer));
         }
         else
         {
             $SELECT nname
                INTO $nname
                FROM officer
               WHERE iofficer = $iofficer;

             if (SQLCODE == SQLNOTFOUND)
             {
                strcpy(nname," ");
                strcpy(iofficer," ");
             }
         }

         /* �O�o�q�� */
         /*******
         $SELECT bzfrom
            INTO $bzfrom
            FROM broker_agent
           WHERE ibroker = (SELECT ibroker_top FROM broker_agent
                 WHERE ibroker = (SELECT icar_broker FROM officer_broker WHERE iofficer = $iofficer));
         if (SQLCODE == SQLNOTFOUND) strcpy(bzfrom, " ");
         *******/

         rtnrc = cm_get_bzfrom(iofficer, icomm_obj, irate_type, bzfrom);
         if (rtnrc != M_CM_OK) strcpy(bzfrom," ");


         $SELECT nname
            INTO $iadjuster
            FROM officer
           WHERE iofficer = $iadjuster_tmp;

         /* peter */
         nbig_comp[0] = '\0';
         if ((ibig_comp[0] != '\0') && (ibig_comp[0] != ' '))
         {
              $SELECT ncode[1,10]
                 INTO $nbig_comp
                 FROM cu_code_data
                WHERE itype = '22'
                  AND icode = $ibig_comp;
              if (SQLCODE == SQLNOTFOUND)
                  nbig_comp[0] = '\0';
         }

/*         printf("*******iquota[%s] \n",iquota); */

         /* �w���ߴڤιw���O�Υ[�` */
         mins_app = mins_app + mproc_app;
         if (option[0]=='1')
            out_mins_app = out_mins_app + out_mproc_app;
         strncpy(iquota_tmp,ipolicy,2);
         iquota_tmp[2] = '\0';

         $SELECT nchi_full
            INTO $nchi_full
            FROM branch
           WHERE ibranch = $iquota_tmp;
         if (SQLCODE==SQLNOTFOUND) strcpy(nchi_full,iquota_tmp);

         $SELECT nins_type,fins_grp
            INTO $nins_type,$fins_grp
            FROM insurance_type
           WHERE iins_type = $iins_item;
         if (SQLCODE==SQLNOTFOUND) strcpy(nins_type,iins_item);

         if (fins_grp[0] == '1')
             strcpy(ifpce_id,factory_1);
         else if (fins_grp[0] == '2')
             strcpy(ifpce_id,factory32_1);
         else
             strcpy(ifpce_id," ");
         printf("ifpce_id[%s]\n", ifpce_id);

         sprintf_s(stmt,2048,
           "SELECT FIRST 1 nchi_full[1,60] \
              FROM cu_customer \
             WHERE ifpce_id = ? ");
         $PREPARE kid02 FROM $stmt;
         $EXECUTE kid02 INTO $factory_tmp USING $ifpce_id;
         if (SQLCODE == SQLNOTFOUND)
         {
             $SELECT nfactory
                INTO $factory_tmp
                FROM ca_factory
               WHERE ifactory = $ofacname
                 AND ifactory_ext = ' ';
             if (SQLCODE == SQLNOTFOUND) strcpy(factory_tmp, ofacname);
         }


         /************************************************************/
/*         printf("[908:]check �w���M���B \n");
         printf("iclaim[%s],iins_type[%s]\n",iclaim,iins_item);*/

         i = 0;
         out_mclose=0;
         mclose = 0;
         mclose1 = 0;
         fclose = 'N';
         ffclose = 'N';
         out_fclose = 'N';
         out_ffclose = 'N';
         mins_stl_close = mstl_health_close = 0;            /* peter */
         mins_proc_close = 0;           /* peter */
         mins_recovery_close = 0;       /* peter */
         msum_health = 0;
         mins_proc = 0;

         qlia_acc = atoi(fcomp_class);

         pdmg_acc = 0;

         strcpy(syymm,split_yymm(dply_begin));
         iyymm = atoi(syymm);

         if (option[0]=='1') /* ��~�� */
            $OPEN Acursor8d USING $iclaim,$iins_item,$ivictim,$clsdateend;
         else
            $OPEN Acursor8d USING $iclaim,$iins_item,$ivictim,$clsdatebasic;

/*         printf("iclaim[%s],iins_item[%s],ivictim[%s],clsdatebasic[%s]\n",
                  iclaim    ,iins_item    ,ivictim    ,clsdatebasic ); */

         while(1)
         {
            $FETCH Acursor8d
              INTO $fstl,$mins_stl,$mins_proc,$mstl_health,
                   $flast,$lDgroup;
            if(SQLCODE == SQLNOTFOUND)
               break;

            /* �������O�l�v���B 
            if (fstl[0]=='1') msum_health += mstl_health;
            else msum_health -= mstl_health;
               �w���ܤU��B�z
            */

/*            printf("[908]:flast[0]===>[%c]\n",flast[0]);
            printf("iclaim[%s]\n",iclaim);
            printf("fstl[%s]\n",fstl);
            printf("flast[%s]\n",flast);
            printf("mins_stl[%ld]\n",mins_stl); */

            if (option[0]=='1') /* ��~�� */
            {
               if ((lDgroup) < cm_ymd_edate(cls_datebgn))
               {
                  if (flast[0] == '2')
                     out_fclose =  'Y' ;

                  if (flast[0] == '1')
                      out_ffclose = 'Y';

                  if (flast[0] == '1' && iins_item[0] == 'B')
                      out_fclose = 'Y';

                  if (flast[0] == '1' && iins_item[0] == 'C')
                      out_fclose = 'Y';

                  if (fstl[0] == '1')
                      out_mclose += (double)(mins_stl + mins_proc + mstl_health);
                  else
                      out_mclose -= (double)(mins_stl - mins_proc + mstl_health);
               }
               if (fstl[0]=='1')
                   mclose += (double)(mins_stl + mins_proc + mstl_health);
               else if (fstl[0]=='2')
                   mclose -= (double)(mins_stl - mins_proc + mstl_health);

               if ((lDgroup) >= cm_ymd_edate(cls_datebgn))
               {
                  /* �����w�M */
                  if (fstl[0] == '1')
                  {
                     mclose1 +=  mins_stl + mins_proc + mstl_health;
                     mins_stl_close       +=  (mins_stl + mstl_health);      /* peter */
                     mins_proc_close      +=  mins_proc;     /* peter */
                     /* �������O�l�v���B */
                     msum_health          +=  mstl_health;
                  }
                  else
                  {
                     mclose1 = mclose1 - mins_stl + mins_proc - mstl_health;
                     mins_recovery_close  +=  (mins_stl + mstl_health);      /* peter */
                     mins_proc_close      +=  mins_proc;     /* peter */
                     /* �������O�l�v���B */
                     msum_health          -= mstl_health;
                  }
               }
            }
            else  /* �O���,�ƬG�� */
            {
               if (fstl[0]=='1')
               {
                  mclose += (double)(mins_stl+mins_proc+mstl_health);
                  mins_stl_close += (mins_stl+mstl_health); /* peter */
                  mins_proc_close+= mins_proc;              /* peter */
                  /* �������O�l�v���B */
                  msum_health          +=  mstl_health;
               }
               else if (fstl[0]=='2')
               {
                  mclose -= (double)(mins_stl-mins_proc+mstl_health);
                  mins_recovery_close+=(mins_stl+mstl_health); /* peter */
                  mins_proc_close    += mins_proc;           /* peter */
                  /* �������O�l�v���B */
                  msum_health          -= mstl_health;
               }
            }

            if (flast[0] == '2')
                fclose =  'Y' ;

            if (flast[0] == '1')
                ffclose = 'Y';

            if (flast[0] == '1' && iins_item[0] == 'B')
                fclose = 'Y';

            if (flast[0] == '1' && iins_item[0] == 'C')
                fclose = 'Y';

         }
         $CLOSE Acursor8d;

         if (option[0]=='1') {
             $EXECUTE vid5
                 INTO $dclose,$maxflast,$dgroup
                USING $iclaim,$iins_item,$ivictim,$clsdateend;
         }
         else {
             $EXECUTE vid5
                 INTO $dclose,$maxflast,$dgroup
                USING $iclaim,$iins_item,$ivictim,$clsdatebasic;
         }

         if ((mclose == 0) && (ffclose == 'Y'))
              fclose = 'Y';

         if (fclose == 'Y') {
             mins_outstl = 0;
             mproc_outstl = 0;     /* �w����,�L���M�O�θ�� */
         } else {
             mins_outstl = mins_app - mclose;
            /* mproc_outstl = mproc_app - mins_proc; */ /* ���M�O�� = �w���O�� - �w�M�O�� */
            mproc_outstl = mproc_app - mins_proc_close;  /* ���M�O�� = �w���O�� - �w�M�O�� */
         }
printf("vol-> mpro_outstl[%ld];;iclaim[%s]\n",mproc_outstl,iclaim);

         if ( mins_outstl < 0)
             mins_outstl = 0;

         if ( mproc_outstl < 0)
             mproc_outstl = 0;    /* �p��s�H�s�p�� */

         if (option[0]=='1')
         {
            mclose = mclose1;

            if ((out_tmp_dappraisal != 0) &&
               (out_tmp_dappraisal < cm_ymd_edate(cls_datebgn)))
            {
               if ((out_mclose == 0) && (out_ffclose == 'Y'))
                  out_fclose = 'Y';

               if (out_fclose == 'Y')
                  out_mins_outstl = 0;
               else
                  out_mins_outstl = out_mins_app - out_mclose;

               if ( out_mins_outstl < 0)
                    out_mins_outstl = 0;
            }
            else
            {    out_mins_outstl = 0; }
         }

/*         printf("END iclaim[%s],mclose[%ld]\n",iclaim,mclose); */

         strcpy(iquota_0,substring(iquota,1,4));
         strcat(iquota_0,"00");

         $SELECT nbranch
            INTO $fullname1
            FROM sa_branch_type
           WHERE ibranch = $iquota_0;

         if (SQLCODE == SQLNOTFOUND) strcpy(fullname1," ");

         $execute pre12 into $ioth_tag using $iclaim;
         if (SQLCODE == SQLNOTFOUND) strcpy(ioth_tag," ");

         /************************************************************/
         strcpy(iins_type,iins_item);



     	 printf("*************************************ADD NEW*******************************\n");
     	 printf("*************************************ADD NEW*******************************\n");
      	 printf("iclaim = %s \n",iclaim);
      	 printf("sFull = %s \n",sFull);
      /*********************�z���**********************************/
       	sprintf_s(stmt ,2048, "SELECT MAX(dentry) "
       	  	       "FROM %s:settlement "
       		       "WHERE iclaim = '%s' ",sFull,iclaim,iins_type);

       	 printf("dentry stmt = %s \n",stmt);

         $prepare Dentry from $stmt;
         $execute Dentry
       		  into $dentry;


        /*******************��ˡB���ơB�z���u��*******************************************/
         sprintf_s(stmt,2048,
            "SELECT sum(cpi.mpart),sum(cpi.mplate+cpi.mremove),sum(cpi.mvarnish) "
            "FROM ca_pro_ins cpi , ca_sign_receipt csr,%s:stl_ins_type sit "
            "WHERE cpi.iclaim = csr.iclaim "
            "AND cpi.iclaim = sit.iclaim "
            "AND cpi.isign = csr.isign "
            "AND cpi.iins_type = sit.iins_type "
            "AND csr.iclose_type = sit.iclose_type "
            "AND sit.fstl = '1' "
            "AND cpi.iclaim='%s' "
            "AND cpi.iins_type ='%s' "
            "AND cpi.isign <> ' ' ",sFull,iclaim,iins_type);

         $prepare sum_momey from $stmt;
         $execute sum_momey
             into $mpart,$mplate_and_remove,$mvarnish;


         /**********************�i�f �B �겣  ***********************************************/

         sprintf_s(stmt,2048,"SELECT min(ccm.icar_series) "
                      "FROM ca_car_model ccm , %s:adjustment_ply ap "
                      "WHERE ap.ibrand = ccm.ibrand "
                      "AND ap.iclaim = ?  " , sFull);

         $prepare icar_type from $stmt;
         $execute icar_type
             into $temp_icar_series
            using $iclaim;

         int tttt=strncmp(temp_icar_series,"10",2);
         printf("Result = %d \n",tttt);

         if(strncmp(temp_icar_series,"10",2)==0 )
         {
        	 strcpy(icar_series,"�겣��");
         }
         else
         {
        	 strcpy(icar_series,"�i�f��");
         }

         printf("icar_series = %s \n",icar_series);
         printf("temp_icar_series = %s \n",temp_icar_series);



         /*** 1.����  2.�D���� ***/
         printf("Actuarial = %s \n",Actuarial);
         if(Actuarial[0]=='1')
         {
         	 printf("****************���� *********************\n");
        	 car908_body_Actuarial();
         }
         else if(Actuarial[0]=='4')
         {
                printf("****************�l���� *********************\n");
      
                $select first 1 '(' || a.fcause_adjuster || ').' || c.ncode 
                   into $ncause_adjuster
                   from ca_clm_victim_data a, ca_ver_relation b, cu_code_data c
                  where a.iclaim          =  b.iverify
                    and b.iclaim          =  $iclaim
                    and a.fcause_adjuster =  c.icode
                    and c.itype           =  'BE'
                    and a.fvictim_car     =  'F';
  
                if (SQLCODE == SQLNOTFOUND)
                {
                    strcpy(ncause_adjuster," ");
                }

                car908_body_LossDef();
         }
         else
         {
		     printf("****************�D���� *********************\n");
		     if(Actuarial[0]=='3')
		        car908_body_ec();   /* �q�� */
		     else
        	    car908_body();      /* ��L */

         }

         mins_app=mins_outstl=out_mins_outstl=mins_stl=mstl_health=0;
         mclose = mproc_app = mins_proc = 0;
         mins_stl_close=mstl_health_close=mins_recovery_close=mins_proc_close=0;
         msum_health=0;
      }
      $CLOSE Acursord;
      $FREE Acursord;

   }

   $CLOSE Acur_branch_b;
   $FREE  Acur_branch_b;
   rgu_put_body(10);   max_count ++;

   return SUCCESS;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car908_ri_share()
{
   $WHENEVER SQLERROR GOTO errexit;
        $SET LOCK MODE TO WAIT;

   $create temp table car908_share
    (iyear      char(4),
     imodule    char(1),
     pret       decimal(5,2))
    with no log;

   $insert into car908_share
    select iyear,imodule,100 - sum(pshare)
      from ca_ri_company_info
     where itreaty not in
           (select itreaty from ca_ri_treaty_off)
     group by 1,2;

   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

double d45(num,num1)
double num;
int num1;
{
    long tmplong;
    double var1;
    double ten;
    int i;

    ten = 1;
    for(i = 1 ;i<=num1;i++)
    ten *= 10;

    num *= ten;
    if (num >= 0) var1 = 0.5;
    else var1 = (-0.5);

    num = num + var1;
    tmplong = num;

    num = tmplong/ten;
    return(num);
}

/*--------------------------------------------------------------------*/
/* �q�ӥ� add by sylvia 106.08.22 (1060620001_C1) */
long car908_body_ec()
{
    char  buf[16],buf1[4];
    short i;
    int   rc;
    $char stmt[2048];
    $char nresource[13], iacc_nfsex[3];

    printf("print car908_body_ec !!\n");

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    $select iins_ply into $iins_ply
       from insurance_type
      where iins_type = $iins_type;

    if (SQLCODE == SQLNOTFOUND)
        strcpy(iins_ply," ");

    $select ncode[1,12] into $nresource
       from cu_code_data
      where itype = '10'
        and icode = $iresource;

    if (SQLCODE == SQLNOTFOUND)
        strcpy(nresource," ");

    rc=read_brand2();
    strcpy(nbrand, rtrim(nbrand));
    if (rc<0)
        strcpy(nbrand,"**********");

    rc=read_cartype();
    strcpy(car_ncode, rtrim(car_ncode));
    if(rc<0)
        strcpy(car_ncode,"**********");

    if (fsex[0]=='1')
        strcpy(nfsex,"�k");
    else if (fsex[0]=='2')
        strcpy(nfsex,"�k");
    else
    {
        strcpy(ibirth,"");
        strcpy(nfsex," ");
    }

    $select nvl(ncode,'***')  into $nfassured
       from cu_code_data
      where itype = '09'
        and icode = $fassured;

    if (SQLCODE == SQLNOTFOUND)
        strcpy(nfassured," ");

    $select nvl(dvp_abbr,'***')  into $niacc_area
       from ca_dvp_ply_area
      where dvp_code = $iacc_area;

    if (SQLCODE == SQLNOTFOUND)
        strcpy(niacc_area," ");

    if (facc_sex[0]=='1')
        strcpy(iacc_nfsex,"�k");
    else if (facc_sex[0]=='2')
        strcpy(iacc_nfsex,"�k");
    else
    {
        strcpy(iacc_birth,"");
        strcpy(iacc_nfsex," ");
    }

    strcpy(iacc_nfsex,iacc_nfsex);


    /* if (facc_rel[0]=='1')
        strcpy(nfacc_rel,"���H");
    else if (facc_rel[0]=='2')
        strcpy(nfacc_rel,"�ˤ�");
    else if (facc_rel[0]=='3')
        strcpy(nfacc_rel,"���u");
    else if (facc_rel[0]=='4')
        strcpy(nfacc_rel,"����");
    else if (facc_rel[0]=='5')
        strcpy(nfacc_rel,"��L");
    else if (facc_rel[0]=='6')
        strcpy(nfacc_rel,"�t��");
    else if (facc_rel[0]=='7')
        strcpy(nfacc_rel,"�l�k");
    else strcpy(nfacc_rel,facc_rel); */
    if (facc_rel[0]=='1')
	      strcpy(nfacc_rel,"���H");
	   else if (facc_rel[0]=='A')
	      strcpy(nfacc_rel,"�۵M�H-�t��");
	   else if (facc_rel[0]=='B')
	      strcpy(nfacc_rel,"�۵M�H-���t����");
	   else if (facc_rel[0]=='C')
	      strcpy(nfacc_rel,"�۵M�H-�S�̩j�f");
	   else if (facc_rel[0]=='D')
	      strcpy(nfacc_rel,"�۵M�H-��L");
	   else if (facc_rel[0]=='E')
	      strcpy(nfacc_rel,"�k�H-�t�d�H");
	   else if (facc_rel[0]=='F')
	      strcpy(nfacc_rel,"�k�H-�t�d�H�a��");
	   else if (facc_rel[0]=='G')
	      strcpy(nfacc_rel,"�k�H-������");
	   else if (facc_rel[0]=='4')
	      strcpy(nfacc_rel,"�k�H-����");
	   else if (facc_rel[0]=='5')
	      strcpy(nfacc_rel,"�k�H-��L");
	   else strcpy(nfacc_rel,facc_rel);


    rc = read_kreserve();
    if (rc!= SUCCESS)
        strcpy(kreserve," ");

    $insert into tmp_tb908  values
    ($iquota, $fullname1, $nchi_full, $dply_begin, $dpolicy,
     $daccident, $dclaim, $dclose, $nbranch,$naffiliated,
     $iclaim, $ipolicy, $ivictim, $iins_type, $nins_type,
     $mins_premium, $mins_app, $out_mins_outstl, $mins_outstl, $mclose,
     $mins_stl_close, $mins_recovery_close, $mins_proc_close, $mdeduct, $ibig_comp,
     $nbig_comp, $iofficer, $nname, $iroute, $nroute,
     $bzfrom, $iadjuster, $nresource, $iassured, $nassured,
     $nuser, $ibrand, $nbrand, $car_ncode, $nfsex,
     $ibirth, $nfassured, $plia_acc, $pdmg_acc, $niacc_area,
     $iacc_nfsex, $iacc_birth, $nfacc_rel, $factory_tmp, $itag,
     $ioth_tag, $iengine, $iacc_reason, $maxflast, $kreserve,
     $dgroup, $pshare, $mproc_outstl, $minjured_cover, $mdeath_cover,
     $mdamage_cover, $iissue_ym, $iply_area, $msum_health, $accident_duty,
     $qduty_adjuster, $dentry, $mpart, $mplate_and_remove, $mvarnish,
     $icar_series);

    max_count ++;

    return SUCCESS;

errexit:
   printf("body[908]:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;

}

/* ------------------------------------------------------------------- */
/* �q�ӥ� add by sylvia 106.08.22 (1060620001_C1) */
long car908_initial()
{

    printf("--- car908_initial start --\n");
	int rc;
	char  msgbuf[100];

    $whenever sqlerror goto errexit;

    if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
    }

    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }

    $create temp table tmp_tb908
    (
        iquota          char(10),       --�~�Z���N��
        fullname1       char(26),       --�~�Z���W��
        nchi_full       char(12),       --�X����
        dply_begin      char(10),       --�O��ͮĩl��
        dpolicy         char(10),       --ñ����
        daccident       char(22),       --�X�I��
        dclaim          char(22),       --���z��
        dclose          char(10),       --�鵲��
        nbranch         char(40),       --�Ҧb�a
        naffiliated     char(40),       --�z�߬�O
        iclaim          char(18),       --�׸�
        ipolicy         char(20),       --�O�渹�X
        ivictim         char(12),       --���`�H�N��
        iins_type       char(8),        --�I�إN��
        nins_type       char(20),       --�I�ئW��
        mins_premium    int,            --ñ��O�O
        mins_app        int,            --�w���ߴ�
        out_mins_outstl int,            --���쥼�M
        mins_outstl     int,            --���M�ߴ�
        mclose          int,            --�w�M�ߴ�
        mins_stl_close  int,            --�ߥI���B
        mins_recovery_close int,        --�l�v���B
        mins_proc_close int,            --�z�߶O��
        mdeduct         int,            --�ۭt�B
        ibig_comp       char(8),        --�g�P���q
        nbig_comp       char(12),       --�g�P���q�W��
        iofficer        char(10),       --�g��N��
        nname           char(20),       --�W��
        iroute          char(20),       --�q���O�N��
        nroute          char(40),       --�q���O�W��
        bzfrom          char(8),        --�O�o�q��
        iadjuster       char(12),       --�z�ߤH��
        iresource       char(12),       --�~�Ȩӷ�
        iassured        char(12),       --�Q�O�I�H�N��
        nassured        char(20),       --�Q�O�I�H
        nuser           char(20),       --�ϥΤH
        ibrand          char(8),        --�t�P����
        nbrand          char(30),       --�t�P��������W��
        car_ncode       char(20),       --����
        nfsex           char(4),        --�Q�O�I�H�ʧO
        ibirth          char(10),       --�X�ͤ��
        nfassured       char(20),       --�Ȥᨭ��
        plia_acc        decimal(5,2),   --���d�ߴګY��
        pdmg_acc        decimal(5,2), 	--����ߴګY��
        niacc_area      char(10),       --�X�I�a
        iacc_nfsex      char(4),        --�F�ƪ̩ʧO
        iacc_birth      char(10),       --�X�ͤ��
        nfacc_rel       char(15),        --���Y
        factory         char(60),       --�O�׼t
        itag            char(12),       --�P�Ӹ��X
        ioth_tag        char(12),       --��y�P�Ӹ��X
        iengine         char(25),       --�������X
        iacc_reason     char(8),        --�X�I��]
        maxflast        char(6),        --���קO
        kreserve        char(5),        --�ǳƪ��I�O
        dgroup          char(10),       --�J�p���
        pshare          decimal(5,2),   --�ۯd�v
        mproc_outstl    int,            --���M�z�߶O��
        minjured_cover  int,            --�O�B1
        mdeath_cover    int,            --�O�B2
        mdamage_cover   int,            --�O�B3
        iissue_ym       char(10),       --�o�Ӥ��
        iply_area       char(12),       --�ӫO�a�ϥN��
        mstl_health     int,            --�������O�l�v���B
        accident_duty   char(20),       --�F�Ƴd���N��
        qduty_adjuster  int,            --�����F�d���%
        dentry          char(22),       --�z���
        mpart           int,            --��˪��B
        mplate          int,            --���ƪ��B
        mvarnish        int,            --�z���u����B
        icar_series     char(10)        --���t
    )with no log;

    $create index tb908_x1 on tmp_tb908(ipolicy);

    $create temp table tmp_tb908_ply
    (
        ipolicy     char(20),       -- �O�渹
        ipro_year   int,            -- �s�y�~��
        fmc         char(4),        -- �T�����O
        ipolicy_v   char(20),       -- ���N�I�O�渹
        iassured    char(12),       -- �Q�O�HID
        itag        char(12),       -- ����
        dpolicy     date,           -- ñ���
        dply_begin  date,           -- �_�O��
        dply_end    date,           -- ���O��
        frenew      char(1),        -- �s��O(Y:��O N:�s�O)
        ncar_type   char(14),       -- ���إN��+�W��(��:03�ۤp��)
        ibrand      char(8),        -- �t���N��
        series_name char(4),        -- �겣/�i�f
        dissue      date,           -- �o�Ӥ�
        fsex        char(2),        -- �ʧO
        dbirth      date,           -- �ͤ�
        plia_acc    decimal(5,2),   -- ���d�Y��
        pdmg_acc    decimal(5,2),   -- ����Y��
        sum_prem    int,            -- �`�O�O
        sum_prem_v  int,            -- ���N�I�`�O�O
        mprem_01    int,            -- 01�O�O
        mprem_05    int,            -- 05�O�O
        mprem_09    int,            -- 09�O�O
        mprem_11    int,            -- 11�O�O
        mprem_98    int,            -- 98�O�O
        mprem_31    int,            -- 31�O�O
        mprem_32    int,            -- 32�O�O
        mprem_29    int,            -- 29�O�O
        mprem_30    int,            -- 30�O�O
        mprem_301   int,            -- 301�O�O
        mprem_38    int,            -- 38�O�O
        mprem_39    int,            -- 39�O�O
        mprem_105   int,            -- 105�O�O
        mprem_55    int,            -- 55�O�O
        mprem_56    int,            -- 56�O�O
        mdamage_01  int,            -- 01�O�B
        mdamage_05  int,            -- 05�O�B
        mdamage_09  int,            -- 09�O�B
        mdamage_11  int,            -- 11�O�B
        mdamage_98  int,            -- 98�O�B
        minjured_31 int,            -- 31��˫O�B
        mdamage_31  int,            -- 31�ƬG�O�B
        mdamage_32  int,            -- 32�]�l�O�B
        mdamage_29  int,            -- 29�ƬG�O�B
        mdamage_30  int,            -- 30�ƬG�O�B
        mdamage_301 int,            -- 301�ƬG�O�B
        mdeath_55   int,            -- 55���`�O�B
        mdamage_55  int,            -- 55�ƬG�O�B
        mdamage_56  int,            -- 56���ݫO�B
        daily_pay_2 int,            -- 56���|���B
        daily_pay_3 int,            -- 56����I
        mdeduct_01  int,            -- 01�ۭt�B
        mdeduct_05  int,            -- 05�ۭt�B
        mdeduct_09  int             -- 09�ۭt�B
    )with no log;

    $create index tmp_tb908_ply_x1 on tmp_tb908_ply(ipolicy);
    $create index tmp_tb908_ply_x2 on tmp_tb908_ply(series_name);

    printf("--- car908_initial end --\n");
    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* ----------------------------------------------------------------------- */
/* �q�ӥ� add by sylvia 106.08.22 (1060620001_C1) */
long car908_print_clm()
{
    int	    rc;
    char	sfilename[81],stitle[3000],stmt[1024];
    $char	nname[41];
    $char   tmp_title[100],str1[11], str2[11], str3[11], str4[15], str5[15];
    $char   yy[4],mm[3],dd[3], msgbuf[100];

    $whenever sqlerror goto errexit;

    strcpy(sfilename,"�߮ש��Ӫ�");

    strcpy(stitle,"");

    /* �߮ת��B */
    rfmtlong(loss_amt, "-,---,--&", str1);
    sprintf_s(tmp_title,100,"\t\t �T���I���j�߮׳����]���B�W�L:%s�^\t\t\t\t �{���N��:CAR606\t \n\n",str1);
    strcat(stitle, tmp_title);

    /* �έp��� */
    if (strncmp(option,"1",1)==0)
       strcpy(str2, "���~�ר�");
    else if (strncmp(option,"2",1)==0)
       strcpy(str2, "�O��~�ר�");
    else if (strncmp(option,"3",1)==0)
       strcpy(str2, "�ƬG�~�ר�");
    else
       strcpy(str2, " ");

    /* �I�O */
    if (choice[0] == '1')
       strcpy(str3,"�j���I");
    else
       strcpy(str3,"���N�I");

    sprintf_s(tmp_title,100,"\t\t %s \t %s \n",str2,str3);
    strcat(stitle, tmp_title);  /* �έp�覡���I�O */


    /* �έp��� */
    cm_split_ymd_100(cls_datebgn, yy, mm, dd);
    sprintf_s(str4,15,"%s�~%s��%s��",yy,mm,dd);

    cm_split_ymd_100(cls_dateend, yy, mm, dd);
    sprintf_s(str5,15,"%s�~%s��%s��",yy,mm,dd);

    sprintf_s(tmp_title,100,"\t\t �έp����G %s �� %s  \n",str4,str5);
    strcat(stitle, tmp_title);

    sprintf_s(tmp_title,100,"\t\t �p�����G %s   ���������G%s  \n\n",clsdatebasic,append);
    strcat(stitle, tmp_title);

    strcat(stitle, "\t�~�Z���N��\t�~�Z���W��\t�X����\t�O��ͮĩl��\tñ����\t");
    strcat(stitle, "�X�I��\t���z��\t�鵲��\t�Ҧb�a\t�z�߬�O\t");
    strcat(stitle, "�׸�\t�O�渹�X\t���`�H�N��\t�I�إN��\t�I�ئW��\t");
    strcat(stitle, "ñ��O�O\t�w���ߴ�\t���쥼�M\t���M�ߴ�\t�w�M�ߴ�\t");
    strcat(stitle, "�ߥI���B\t�l�v���B\t�z�߶O��\t�ۭt�B\t�g�P���q\t");
    strcat(stitle, "�g�P���q�W��\t�g��N��\t�W��\t�q���O�N��\t�q���O�W��\t");
    strcat(stitle, "�O�o�q��\t�z�ߤH��\t�~�Ȩӷ�\t�Q�O�I�H�N��\t�Q�O�I�H\t");
    strcat(stitle, "�ϥΤH\t�t�P����\t�t�P��������W��\t����\t�Q�O�I�H�ʧO\t");
    strcat(stitle, "�X�ͤ��\t�Ȥᨭ��\t���d/�ߴګY��\t����ߴګY��\t�X�I�a\t");
    strcat(stitle, "�F�ƪ̩ʧO\t�X�ͤ��\t���Y\t�O�׼t\t�P�Ӹ��X\t");
    strcat(stitle, "��y�P�Ӹ��X\t�������X\t�X�I��]\t���קO\t�ǳƪ��I�O\t");
    strcat(stitle, "�J�p���\t�ۯd�v\t���M�z�߶O��\t�O�B1\t�O�B2\t");
    strcat(stitle, "�O�B3\t�o�Ӥ��\t�ӫO�a�ϥN��\t�������O�l�v���B\t�F�Ƴd���N��\t");
    strcat(stitle, "�����F�d���%\t�z���\t��˪��B\t���ƪ��B\t�z���u����B\t");
    strcat(stitle, "���t \n");

    strcpy(stmt,"select * from tmp_tb908 where 1=1 ");

    rc = unload_file(outputf,"A",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf,100," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* -------------------------------------------------------------------------- */
long car908_print_ply()
{
    int	    rc;
    char	sfilename[81],stitle[3000],stmt[1024];
    $char	nname[41];
    $char   tmp_title[100],str1[11], str2[11], str3[11], str4[15], str5[15];
    $char   yy[4],mm[3],dd[3], msgbuf[100];

    $whenever sqlerror goto errexit;

    strcpy(sfilename,"�߮׫O����Ӫ�");

    strcpy(stitle,"");

    /* �߮ת��B */
    rfmtlong(loss_amt, "-,---,--&", str1);
    sprintf_s(tmp_title,100,"\t\t �T���I���j�߮�_�O����ӡ]���B�W�L:%s�^\t\t\t\t �{���N��:CAR606\t \n\n",str1);
    strcat(stitle, tmp_title);

    /* �έp��� */
    if (strncmp(option,"1",1)==0)
       strcpy(str2, "���~�ר�");
    else if (strncmp(option,"2",1)==0)
       strcpy(str2, "�O��~�ר�");
    else if (strncmp(option,"3",1)==0)
       strcpy(str2, "�ƬG�~�ר�");
    else
       strcpy(str2, " ");

    /* �I�O */
    if (choice[0] == '1')
       strcpy(str3,"�j���I");
    else
       strcpy(str3,"���N�I");

    sprintf_s(tmp_title,100,"\t\t %s \t %s \n",str2,str3);
    strcat(stitle, tmp_title);  /* �έp�覡���I�O */


    /* �έp��� */
    cm_split_ymd_100(cls_datebgn, yy, mm, dd);
    sprintf_s(str4,15,"%s�~%s��%s��",yy,mm,dd);

    cm_split_ymd_100(cls_dateend, yy, mm, dd);
    sprintf_s(str5,15,"%s�~%s��%s��",yy,mm,dd);

    sprintf_s(tmp_title,100,"\t\t �έp����G %s �� %s  \n",str4,str5);
    strcat(stitle, tmp_title);

    sprintf_s(tmp_title,100,"\t\t �p�����G %s   ���������G%s  \n\n",clsdatebasic,append);
    strcat(stitle, tmp_title);

    strcat(stitle, "\t �T�����O\t ���N�I�O�渹\t �Q�O�I�HID\t ���P\t ñ���\t");
    strcat(stitle, "�O��ͮĤ�\t �O������\t �s��O\t ���اO\t �t�P�W��\t");
    strcat(stitle, "�i�f/�겣\t �����o�Ӥ��\t �Q�O�I�H�ʧO\t �X�ͤ��\t ���d�Y��\t");
    strcat(stitle, "����Y��\t �`�O�I�O\t �`���N�I�O�O\t 01�O�O\t 05�O�O\t");
    strcat(stitle, "09�I�O�O\t 11�O�O\t 98�I�O�O\t 31�I�O�O\t 32�I�O�O\t");
    strcat(stitle, "29�O�O\t 30�O�O\t 301�O�O\t 38�I�O�O\t 39�I�O�O\t");
    strcat(stitle, "105�O�O\t 55�O�O\t 56�O�O\t 01�O�B\t 05�O�B\t");
    strcat(stitle, "09�O�B\t 11�O�B\t 98�O�B\t 31��˫O�B\t 31�ƬG�O�B\t");
    strcat(stitle, "32�]�l�O�B\t 29�I�ƬG�O�B\t 30�I�ƬG�O�B\t 301�ƬG�O�B\t 55���`�O�B\t");
    strcat(stitle, "55�ƬG�O�B\t 56���ݫO�I��\t 56���|�������B\t 56����I\t 01�ۭt�B\t");
    strcat(stitle, "05�ۭt�B\t 09�ۭt�B\t");

    strcpy(stmt,"select fmc, ipolicy_v, iassured, itag, dpolicy, ");
    strcat(stmt,"dply_begin, dply_end, frenew, ncar_type, ibrand, ");
    strcat(stmt,"series_name, dissue, fsex, dbirth, plia_acc, ");
    strcat(stmt,"pdmg_acc, sum_prem, sum_prem_v, mprem_01, mprem_05, ");
    strcat(stmt,"mprem_09, mprem_11, mprem_98, mprem_31, mprem_32, ");
    strcat(stmt,"mprem_29, mprem_30, mprem_301, mprem_38, mprem_39, ");
    strcat(stmt,"mprem_105, mprem_55, mprem_56, mdamage_01, mdamage_05, ");
    strcat(stmt,"mdamage_09, mdamage_11, mdamage_98, minjured_31, mdamage_31, ");
    strcat(stmt,"mdamage_32, mdamage_29, mdamage_30, mdamage_301, mdeath_55, ");
    strcat(stmt,"mdamage_55, mdamage_56, daily_pay_2, daily_pay_3, mdeduct_01, ");
    strcat(stmt,"mdeduct_05, mdeduct_09 from tmp_tb908_ply where 1=1 ");

    rc = unload_file(outputf,"B",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf,100," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    $drop table tmp_tb908;
    $drop table tmp_tb908_ply;
    $drop table tp90801;


    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/* -------------------------------------------------------------------------- */
long car908_build_ec()
{
    $char   stmt[10000];
    $char   icar_series[11], ipolicy[21];


    DBinfo  *list;
    int     count_db,i;

    printf("---3621--- \n");
    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
    }
        printf("---3634--- \n");
    $select unique ipolicy from tmp_tb908 where 1=1 into temp tp90801 with no log;

        printf("---3636--- \n");
    for(i=0;i<count_db;i++)
    {
        printf("---3640--- \n");
        sprintf_s(stmt,10000,
        "insert into tmp_tb908_ply "
        "select a.ipolicy, b.ipro_year, "
        "       case when b.icar_type in ('01','02','32','34') then '����' else '�T��' end, "
        "       decode(fcard_class, '2', b.ipolicy, ' '), c.iassured, c.itag, "
        "       b.dpolicy, b.dply_begin, b.dply_end, decode(nvl(ilast_ply,' '),' ','N','Y'), "
        "       b.icar_type || (select ncode from car_type where fclass = '1' and icode = b.icar_type), "
        "       b.ibrand, ' ', c.dissue, decode(c.fsex,'1','�k','2','�k',' '), "
        "       c.dbirth, c.plia_acc, c.pdmg_acc, b.mdmg_prem + b.mlia_prem,"
        "       decode(b.fcard_class,'1',0,b.mdmg_prem + b.mlia_prem), "
        "       nvl((select d.mins_premium from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type in ('01','201')),0), "
        "       nvl((select d.mins_premium from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type in ('05','205')),0), "
        "       nvl((select d.mins_premium from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type in ('09','209')),0), "
        "       nvl((select d.mins_premium from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type in ('11','211')),0), "
        "       nvl((select d.mins_premium from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '98'),0), "
        "       nvl((select d.mins_premium from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type in ('31','231')),0), "
        "       nvl((select d.mins_premium from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type in ('32','232')),0), "
        "       nvl((select d.mins_premium from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '29'),0), "
        "       nvl((select d.mins_premium from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '30'),0), "
        "       nvl((select d.mins_premium from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '301'),0), "
        "       nvl((select d.mins_premium from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '38'),0), "
        "       nvl((select d.mins_premium from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '39'),0), "
        "       nvl((select d.mins_premium from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '105'),0), "
        "       nvl((select d.mins_premium from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '55'),0), "
        "       nvl((select d.mins_premium from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '56'),0), "
        "       nvl((select d.mdamage_cover from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type in ('01','201')),0), "
        "       nvl((select d.mdamage_cover from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type in ('05','205')),0), "
        "       nvl((select d.mdamage_cover from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type in ('09','209')),0), "
        "       nvl((select d.mdamage_cover from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type in ('11','211')),0), "
        "       nvl((select d.mdamage_cover from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '98'),0), "
        "       nvl((select d.minjured_cover from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type in ('31','231')),0), "
        "       nvl((select d.mdamage_cover from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type in ('31','231')),0), "
        "       nvl((select d.mdamage_cover from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type in ('32','232')),0), "
        "       nvl((select d.mdamage_cover from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '29'),0), "
        "       nvl((select d.mdamage_cover from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '30'),0), "
        "       nvl((select d.mdamage_cover from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '301'),0), "
        "       nvl((select d.mdeath_cover from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '55'),0), "
        "       nvl((select d.mdamage_cover from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '55'),0), "
        "       nvl((select d.mdamage_cover from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type = '56'),0), "
        "       nvl((select unique e.daily_pay from %s:ca_pa_ply e where e.ipolicy = a.ipolicy and e.iins_type = '56' and e.iins_scope = '2'),0), "
        "       nvl((select unique e.daily_pay from %s:ca_pa_ply e where e.ipolicy = a.ipolicy and e.iins_type = '56' and e.iins_scope = '3'),0), "
        "       nvl((select d.mdeduct from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type in ('01','201')),0),  "
        "       nvl((select d.mdeduct from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type in ('05','205')),0), "
        "       nvl((select d.mdeduct from %s:ply_ins_type d where d.ipolicy = a.ipolicy and d.iins_type in ('09','209')),0) "
        "  from tp90801 a, %s:ply_relation b, %s:policy c "
        " where a.ipolicy = b.ipolicy and a.ipolicy = c.ipolicy ",
        list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
        list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
        list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
        list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
        list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
        list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
        list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
        list[i].dbname);

        printf("stmt=[%s]\n",stmt);


        $prepare pre_ply1 from $stmt;
        $execute pre_ply1;

        printf("--- 3705 ---\n");
        sprintf_s(stmt,10000,"select ipolicy from tmp_tb908_ply where 1=1");

        printf("3708 --stmt=[%s]\n",stmt);

        $PREPARE pre_ply2 FROM $stmt;
        $DECLARE cur_ply2 CURSOR FOR pre_ply2 ;
        $OPEN cur_ply2;
        while (1)
        {
            $FETCH cur_ply2 into $ipolicy;
            if (SQLCODE == SQLNOTFOUND) break;

            printf("3718 --ipolicy =[%s]\n",ipolicy);

            $select first 1 icar_series into $icar_series
               from tmp_tb908
              where ipolicy = $ipolicy;

           printf("3724 --ipolicy =[%s],icar_series=[%s]\n",ipolicy,icar_series);

            $update tmp_tb908_ply
                set series_name = $icar_series
              where ipolicy = $ipolicy;
            printf("----- 3729 --\n");
        }
            printf("----- 3731 --\n");
        $close  cur_ply2;
        $free cur_ply2;
            printf("----- 3734 --\n");
   }

   return SUCCESS;

 errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}


long read_brand2()
{
    $char  ipro_year[4],drate[11];
    $char  stmt[1024];

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    $select first 1 replace(nbrand,'\"',''),ipro_year,drate
       into $nbrand,$ipro_year,$drate
       from ca_car_model
      where ibrand = $ibrand
      order by drate desc,ipro_year desc;

   if (SQLCODE == SQLNOTFOUND)
   {
       strcpy(nbrand," ");
   }

   /* ibrand=MM002900��, �|���첾, �ҥH���ȺI��20�X */
   strcpy(ibrand, trim(ibrand));
   if (strcmp(ibrand,"MM002900") == 0)
   {
        nbrand[21] = '\0';
   }

   return SUCCESS;
errexit:
   printf("read_brand[908]:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/* -------------------------------------------------------------------------- */
/* Ū��car908_wkd (sExecType=R�M��) */
long car908R_compulsory()
{
   char   fclose,ffclose,out_fclose,out_ffclose;
   $int   rec_no,id1,id2;
   $char  iquota_14[7];
   int    i,rc;
   $int    qlia_acc;
   $double plia_acc;
   $char   flast_1[2];


   $WHENEVER SQLERROR GOTO errexit;
	 $SET LOCK MODE TO WAIT;

   qlia_acc = 0;  mdeduct  = 0; pshare   = 0; pdmg_acc = 0;
   mins_app=mins_outstl=out_mins_outstl=mins_stl=mstl_health=mclose=mproc_app=0;
   out_mins_app=out_mproc_app=0;
   mins_stl_close=mstl_health_close=mins_recovery_close=mins_proc_close=0;
   mproc_outstl = 0;
   msum_health = 0;
   plia_acc = 0;
   mins_proc = 0;
   /************************�s�W�X�I��d�߱���**********************************/
	 if (strcmp(trim(Date_accident),"*") == 0)
   {
   		sprintf_s(sWhere_Daccident,125," ");

   }
   else
   {
   		strcpy(Date_accident , cm_to_infdate(Date_accident) );
      sprintf_s(sWhere_Daccident,125,"AND date(daccident) = '%s' ",Date_accident);
	 }

   /************************�s�W�q���N���d�߱���**********************************/
   if (strcmp(trim(ID_route),"*") == 0)
   {
   		sprintf_s(sWhere_Iroute,125," ");
	 }
   else
   {
   		sprintf_s(sWhere_Iroute,125,"AND iroute = '%s' ",ID_route);
	 }

	 /*************************�s�W�g��N���d�߱���**************************************************/
   if (strcmp(trim(ID_officer),"*") == 0)
   {
   		sprintf_s(sWhere_Iofficer,125," ");
	 }
   else
   {
   		sprintf_s(sWhere_Iofficer,125,"AND iofficer = '%s' ",ID_officer);
   }

   /**** ��ܷ~�Z��� ****/

   if (strcmp(trim(ibranch_1),"*") == 0)
   {
       strcpy(sWhere," ");
   }
   else
   {
			 $SELECT ibranch_abbr,iquota_grp[1,4]
          INTO $ibranch_abbr,$iquota_b
          FROM branch
         WHERE ibranch = $ibranch_1;
       if (SQLCODE == SQLNOTFOUND)
          return M_CMN_NBRANCH;

       if (strlen(trim(ibranch_abbr))==0)
          sprintf_s(sWhere,1024," AND iquota[1,4] = '%s' ",iquota_b);
       else
          sprintf_s( sWhere,1024," AND ipolicy[1,2] in (select ibranch from branch where iupcomp = '%s') ",ibranch_1);
   }

	 sprintf_s(stmt,2048,
	 		"select iquota, nquota, nchi_full, dply_begin, dpolicy, \
              daccident, dclaim, dclose, nbranch, naffiliated, \
	            iclaim, ipolicy, ivictim, iins_type, nins_type, \
	            mins_premium, mins_app, mins_outstl_bgn, mins_outstl_end, mclose, \
	            mins_stl_close, mins_recovery, mins_proc_close, mdeduct, ibig_comp, \
	            nbig_comp, iofficer, nofficer, iroute, nroute, \
	            bzfrom, iadjuster, nresource, iassured, nassured, \
	            nuser, ibrand, nbrand, car_ncode, nfsex, \
	            ibirth, nfassured, nvl(plia_acc,0), nvl(pdmg_acc,0), niacc_area, \
	            ndriver_sex, iacc_birth, nfacc_rel, factory_tmp, itag, \
	            ioth_tag, iengine, iacc_reason, maxflast, kreserve, \
	            dgroup, pshare, mproc_outstl, minjured_cover, mdeath_cover, \
	            mdamage_cover, iissue_ym, iply_area, mstl_health, accident_duty, \
	            qduty_adjuster, dentry, mpart, mplate, mvarnish, ncar_series,nvl(plia_acc,0) \
		     from car908_wkd \
		    where idatano = '%s'  \
		      and mis_app_chk >= ? %s %s %s %s ",
		      sIdataNo, sWhere, sWhere_Daccident, sWhere_Iroute,sWhere_Iofficer );

	 printf("car908R_compulsory: \n stmt[%s]\n",stmt);
	 $PREPARE vid1R FROM $stmt;
	 $DECLARE AcursordR CURSOR FOR vid1R;
	 $OPEN    AcursordR USING $loss_amt;
	 while(1)
	 {
   		$FETCH AcursordR INTO
   				$iquota, $fullname1, $nchi_full, $dply_begin, $dpolicy,
          $daccident, $dclaim, $dclose, $nbranch, $naffiliated,
          $iclaim, $ipolicy, $ivictim, $iins_type , $nins_type,
          $mins_premium, $mins_app, $out_mins_outstl, $mins_outstl, $mclose,
          $mins_stl_close, $mins_recovery_close, $mins_proc_close, $mdeduct, $ibig_comp,
          $nbig_comp, $iofficer, $nname, $iroute, $nroute,
       	  $bzfrom, $iadjuster, $ncode, $iassured, $nassured,
          $nuser, $ibrand, $nbrand, $car_ncode, $nfsex,
          $ibirth, $nfassured, $sPlia_acc, $pdmg_acc, $niacc_area,
          $ndriver_sex, $iacc_birth, $nfacc_rel, $factory_tmp, $itag,
          $ioth_tag, $iengine, $iacc_reason, $maxflast, $kreserve,
          $dgroup, $pshare, $mproc_outstl, $minjured_cover, $mdeath_cover,
          $mdamage_cover, $iissue_ym, $iply_area, $mstl_health, $accident_duty,
          $qduty_adjuster, $dentry, $mpart, $mplate_and_remove, $mvarnish, $icar_series, $plia_acc;

		  if (SQLCODE == SQLNOTFOUND) break;
      /************************************************************/

				 /*�F�Ƴd��*/
        if(strcmp(trim(accident_duty),"1")==0)
        {
                strcpy(accident_duty,"1:���F�d,�O��");
        }
        else if(strcmp(trim(accident_duty),"2")==0)
        {
                strcpy(accident_duty,"2:�L�F�d,���O��");
        }
        else
        {
                strcpy(accident_duty,"3:���F�d,���O��");
        }

        		/* ���[���ڥ�sFull (�]���[���ڨS���[�Jcar908_wkd �ҥH�C���ץX�ɭn���s����)*/
		printf("4989 sFull = %s,ipolicy = %s,ipolicy[2] = %s \n", sFull,  ipolicy,  ipolicy[2]);
		if (strcmp(sFull,"") == 0)
		{
			printf("5032 sFull = %s,ipolicy = %s,ipolicy[2] = %s \n", sFull,  ipolicy,  ipolicy[2]);
			switch(ipolicy[2])
			{
				case '0':
					strcpy(sFull, "newa00");
					break;
				case '1':
					strcpy(sFull, "newa40");
					break;
				case '2':
					strcpy(sFull, "newa70");
					break;
				case '5':
					strcpy(sFull, "newa22");
					break;
				case '6':
					strcpy(sFull, "newa33");
					break;
				case '7':
					strcpy(sFull, "newa66");
					break;
			}
			printf("5040 sFull = %s,ipolicy = %s,ipolicy[2] = %s \n", sFull,  ipolicy,  ipolicy[2]);
		}

			/*** 1.����  2.�D���� ***/
      printf("Actuarial = %s \n",Actuarial);
      if(Actuarial[0]=='1')
      {
      		printf("****************���� *********************\n");
        	car908_body_Actuarial();
      }
      else if(Actuarial[0]=='4')
      {
                printf("****************�l���� car908R_compulsory *********************\n");
                car908_body_LossDef();
      }
      else
      {
  		printf("****************�D���� 4244 *********************\n");
   	     	rc = car908_body();      /* ��L */
      }

      /* mins_app=mins_outstl=out_mins_outstl=mins_stl=mstl_health=0;
      mclose=mproc_app = 0;
      mins_stl_close=mstl_health_close=mins_recovery_close=mins_proc_close=0; */
      qlia_acc = 0; mdeduct  = 0; pshare   = 0; pdmg_acc = 0;
	    mins_app=mins_outstl=out_mins_outstl=mins_stl=mstl_health=mclose=mproc_app=0;
	    out_mins_app=out_mproc_app=0;
	    mins_stl_close=mstl_health_close=mins_recovery_close=mins_proc_close=0;
	    mproc_outstl = 0;
	    msum_health = 0;
	    plia_acc = 0;
	    mins_proc = 0;
	 }
   $CLOSE AcursordR;
   $FREE AcursordR;
   rgu_put_body(10);   max_count ++;

   return SUCCESS;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
/* --------------------------------------------------------------------------- */
long read_kreserve_bak()
{
    $char sProvision_tmp[22];/*1081225006-SC8-���ά�-�X�R���[���ڥN�X  �]�������20�X��+;�i��P�_*/
    $char  icode1[2];
    $whenever sqlerror goto errexit;
    $SET LOCK MODE TO WAIT;
   /* Ū���ǳƪ��N�X by Jessie 20050128*/
   /* �ץ����^�����D modify by sylvia 106.12.15 (1061130011_C1) */
   /* �t�X����������,�ק��^���覡 modify by sylvia 106.12.15 (1061205007_C3) */
   strcpy(iprodcode," ");
   if (strncmp(iins_ply,"21",2)==0)
   {
      if (strncmp(icar_type,"01",2)==0 || strncmp(icar_type,"02",2)==0
         || strncmp(icar_type,"32",2)==0 || strncmp(icar_type,"34",2)==0)
      {
         if (qply_period > 12)
             strcpy(iprodcode,"2");
         else
             strcpy(iprodcode,"1");
      }
   }

/*printf("iins_ply[%s]iproduct[%s]iprodcode[%s]fcar_class[%s]qply_period[%d]\n",
        iins_ply,iproduct,iprodcode,fcar_class,qply_period);*/
    /* �s�аӫ~(157,158,159),�T�w����03,�ۥ� (1061206004_SC2) */
    /* �]���s�Ш�����J,�����s�аӫ~�T�w���ت��]�w(1110304003_SC1) */
    /* else if ((strcmp(trim(iins_ply),"51") == 0) || (strcmp(trim(iins_ply),"157") == 0)
                || (strcmp(trim(iins_ply),"158") == 0) || (strcmp(trim(iins_ply),"159") == 0)) */
   if (strlen(trim(iproduct))==0)
   {
      if (strncmp(icar_type,"01",2)==0 || strncmp(icar_type,"02",2)==0
         || strncmp(icar_type,"32",2)==0 || strncmp(icar_type,"34",2)==0)
         strcpy(icode1,"3");
      else if (strcmp(trim(iins_ply),"51") == 0)
               strcpy(icode1,"1"); /* 51�I�ةT�w�� 1(�ۥ�) */
      else
         strcpy(icode1,fcar_class);


      strcpy(sProvision_tmp ,"");
      sprintf_s(sProvision_tmp,22,"%s;",trim(sProvision));
      printf("sProvision_tmp[%s]\n",sProvision_tmp);
      strcpy(sProvision , sProvision_tmp);

      if( strstr(sProvision , "T;") != '\0')
        {
            strcpy( iprodcode, "T");
    	}
    	else
    	{
    	    /* 1061205007_C1_���������ڰӫ~�Χ��²v���[���ڤW�u */
    	    if ((atoi(sFrate)>=90)&&(ISLEASED_CAR(icar_type)))
    	    {
    	        strcpy( iprodcode, "3");
    	    }

    	    /* if((strcmp(trim(iins_ply),"157") == 0) ||
    	       (strcmp(trim(iins_ply),"158") == 0) || (strcmp(trim(iins_ply),"159") == 0))
            {
                strcpy( iprodcode, " ");
            } */
    	}

        /* �����O�T�I(58�I�I��) ���ӫ~�N�X, ���t�~�P�_:
            �O�v�N��>= 94, icode2 = 2
            �O�v�N�� < 94, icode2 = 1
                modify by sylvia 107.05.31 (1070503006_SC4) */

        if (strcmp(trim(iins_ply),"58") == 0)
        {
            if (atoi(sFrate)>=94)
                strcpy( iprodcode, "2");
            else
                strcpy( iprodcode, "1");
    	}


      $select kreserve
         into $kreserve
         from cm_product_code
        where iins_class = 'C'
          and iins_type = $iins_ply
          and icode1 = $icode1
          and icode2 = $iprodcode;

          if (SQLCODE==SQLNOTFOUND)
                strcpy(kreserve," ");
   }
   else
   {

        /* �����O�T�I(58�I�I��) ���ӫ~�N�X, ���t�~�P�_:
            �O�v�N��>= 94, icode2 = 2
            �O�v�N�� < 94, icode2 = 1
                modify by sylvia 107.05.31 (1070503006_SC4) */
        if (strcmp(trim(iins_ply),"58") == 0)
        {
            if (atoi(sFrate)>=94)
                strcpy( iprodcode, "2");
            else
                strcpy( iprodcode, "1");
    	}

        $select distinct kreserve
           into $kreserve
           from cm_product_code
          where iproduct = $iproduct
            and icode2 = $iprodcode
            and iins_type = $iins_ply;

        if (SQLCODE==SQLNOTFOUND)
        {
            /*if ((strcmp(trim(iins_ply),"51") == 0) || (strcmp(trim(iins_ply),"157") == 0)
                || (strcmp(trim(iins_ply),"158") == 0) || (strcmp(trim(iins_ply),"159") == 0))
                strcpy(icode1,"1"); *//* 51�I�ةT�w�� 1(�ۥ�) */
            if (strcmp(trim(iins_ply),"51") == 0)
                strcpy(icode1,"1"); /* 51�I�ةT�w�� 1(�ۥ�) */
            else
                strcpy(icode1,fcar_class);

            strcpy(sProvision_tmp ,"");
	    sprintf_s(sProvision_tmp,22,"%s;",trim(sProvision));
	    printf("sProvision_tmp[%s]\n",sProvision_tmp);
	    strcpy(sProvision , sProvision_tmp);

            if( strstr(sProvision, "T;") != '\0')
            {
	            strcpy( iprodcode, "T");
        	}
        	else
        	{
        	    /* 1061205007_C1_���������ڰӫ~�Χ��²v���[���ڤW�u */
        	    if ((atoi(sFrate)>=90)&&(ISLEASED_CAR(icar_type)))
        	    {
        	        strcpy( iprodcode, "3");
        	    }
        	}

        	$select distinct kreserve
               into $kreserve
               from cm_product_code
              where iins_class = 'C'
                and iins_type = $iins_ply
                and icode1 = $icode1
                and icode2 = $iprodcode;

            if (SQLCODE==SQLNOTFOUND)
                strcpy(kreserve," ");
        }
   }
   return SUCCESS;

errexit:
   printf("read_kreserve_bak[908]:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
