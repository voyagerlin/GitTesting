/*********************************************************/
/*                                                       */
/*  PROGRAM: ca327m01s.ec                                */
/*                                                       */
/*********************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "is_def.h"
#include "safeclib.h"
#include <string.h>
#include <stdlib.h>
#include <time.h>
$include sqlca;

char tmpbuf[4000];
$char  dreprint[11];
$int   qreprint;
$char  DBName[5],type[2], sfile[20], ptype[6];
$char  buff[250],stmt[1000], sStmt[1024], stmt_type[500];
$char  ipolicy[21], nassured[80], itag[10], iengine[21], ipro_year[6];
$char  nuser[19]; /* Add by Julia Han in 2007/02/07 */
$char  nbrand[40], dbegin[13], dend[13], aassured[100], aassured_zip[10];
$char  ibrand[11], sibrand[11], sipro_year[6], fassured[2], fsex[2];
$char  ibig_branch[25], itel[16], ibig_office[6], ipolicy1[21], ipolicy2[21];
$char  comp_DB[3],icard_A[21],iofficer[11],nassured_x[80];

/** ca_promote **/
$char  iprmt[10], nprmt[30], iagent[10], iofficer_1[2], ioff_chk[10];
$char  fanother[2], iofficera_1[2], ioff_chka[10], ioff_chk_B[6], iins_list[21];
$int   iremark, iofficer_len = 0, ioff_ck_bgn = 0, ioff_ck_len, ioff_ck_end = 0;
$long  mlimit, lMdeduct, lmdamage_cover;
$int   lofficera = 0 , ioff_chk_bgna = 0, ioff_chk_lena, ioff_ch_enda = 0;
$char  pro_no[6];
$char  imodule[2],nprmt_full[51],nins_type[65],iins_desc[256],iins_wording1[361],flaw[2];

/* file */
$char    report_file1[30],report_file2[30],sTmp[1001];
$char    sData[81], userid[10];
 char    sApHome[30],outputf1[80], outputf[50], file[50], file1[50];
 char    prtstr[200],prtstr1[1500];
 char    getfile[50],txtfile[20];
 char    itmp[10];
 FILE    *fptr,*fptr1;
static int   recLen=1024;
static char  *bp;
 FILE    *fp;

/** time **/
struct tm *currenttime;
time_t bintime;
char   strtime[20];

$char  param1[21], param2[21],pro_no1[6],sNoPlyB[2] ,sbus_source[11] ;

/* N�g�����  modify by sylvia 103.09.17(1030630002_C1) */
$int  count_n;

static char *get_car_full_db();
int rptftpinsert();
int    strSearchReplace();

long car327(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
     long rtncode;
     long car327_query();
     char option;

     cm_buf_init(command);
     cm_buf_get("%c",&option);
     switch(option)
     {
          case 'Q':
               rtncode=car327_query(reply);
               break;

          default :
               if(exitsub(reply,M_CM_WRONG_OPTION) == True)
                   return M_CM_WRONG_OPTION;
               return apiRC;
     }
     if( type[0] == '1' ) /** 1.�ɮ� **/
        delfile();
     return(rtncode);
}

long car327_query(reply)
serverReply reply;
{
     int    rtn,pos,rc, rt;
     int    tmp_len, count, no_pay_cnt=0, pay_cnt=0;
     $char  Full_DBName[20], ipolicy_A[20];
     $char  payresult[5], paystatus[100], paydate[100], notedate[100], sIinsType[3];
     $char  sNinsType1[21];
     $long  ldend = 0, lMinjured_cover = 0, lMdeath_cover = 0, lMdamage_cover = 0;
     $int   qnext_year = 0, iCountDtl, qserial;
     int    i_ptype;
     char   errmsg[121];
     $long  lDaily_pay;
     $char  yy1[4], mm1[3],dd1[3],yy2[4], mm2[3],dd2[3],dperiod[31];
     
     
     
     

     cm_buf_get("%s %s %s %s %s ",DBName, type, sfile, param1, param2 );
     cm_buf_get("%s %s", ptype, userid);
   
     printf(" car327_query \n");    

     $WHENEVER SQLERROR GOTO errexit;
     
     /* if ptype(�M�ץN�X)�� "-" ==> �N���� "���s��O���ҹq�l��" */
     strcpy(pro_no, ptype );
     i_ptype = 0;

     if (db_select(DBName) == False)
     {
         if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
         else
            return apiRC;
     }
     printf("Trace -- param1 = [%s] \n",  param1);
     printf("Trace -- param2 = [%s] \n",  param2);
     if (ptype[0] == '-'){  /* ���s��O���ҹq�l��" */
     	 strcpy(pro_no1, trim(param1));  /* ���w�M��(pro_no1[0]==' ' or pro_no1[0]=='\0' �N��"�����w�M��") */
     	 strcpy(sNoPlyB, trim(param2));  /* ��J���ɮ׬�A�渹��B�渹 */
     }else{
     	 strcpy(ipolicy1, trim(param1));
     	 strcpy(ipolicy2, trim(param2));     	 
     }     

     $CREATE TEMP TABLE CAR327
     (
         ipolicy  char(21) default ' '
     )
     WITH NO LOG;

     $CREATE INDEX CAR327_ix1 ON CAR327 (ipolicy);

printf("Trace -- TEST1 \n");    
     if( strcmp(trim(type),"1") ==0 ) /** 1.�ɮ� **/
     {
     	   printf("Trace -- TEST2 \n");    
         rc = ca327_getfile(); 
         if( rc != M_CM_OK )
         {
      	    printf("getfile error \n");
      	    return apiRC;
         }
printf("Trace -- TEST3 \n");             
         printf("in type 1\n");
         
         time(&bintime);
         currenttime=localtime(&bintime);
         strftime(strtime,20,"%m%d%H%M",currenttime);

         sprintf_s(outputf, sizeof outputf, "car327_no_pay_%s.xls", trim(strtime));
         sprintf_s(outputf1, sizeof outputf1, "car327_print_%s.xls", trim(strtime));  /* <== �Y�� "���s��O���ҹq�l��"�A���Y�����s���q�l�� */
        
printf("Trace -- TEST4 \n");             
         rt = getApHome(sApHome);
         if (rt < 0) {
            printf("read Config file error!!\n");
            return M_CM_READ_CONFIG_ERR;
         }

         sprintf_s(file, sizeof file,"%s/rptftp/%s",sApHome,rtrim(outputf));
         sprintf_s(file1, sizeof file1,"%s/rptftp/%s",sApHome,rtrim(outputf1));
     
         if ((fptr=fopen(file,"w")) == NULL){
            sprintf_s(errmsg, sizeof errmsg,"Cannot open print file: %s",file);
            return M_CM_OPEN_FILE_FAIL;
         }
         
         if ((fptr1=fopen(file1,"w")) == NULL){
            sprintf_s(errmsg, sizeof errmsg,"Cannot open print file: %s",file);
            return M_CM_OPEN_FILE_FAIL;
         }
printf("Trace -- TEST5 \n");             
         /* car327_no_pay_%s */
         strcpy(prtstr, "�O�渹");
         strcat(prtstr, "\t");
         strcat(prtstr, "���P");
         strcat(prtstr, "\t");
         strcat(prtstr, "�Q�O�I�H");
         strcat(prtstr, "\t");
         strcat(prtstr, "A��O�渹");
         strcat(prtstr, "\t");
         fprintf(fptr,"%s\n",prtstr);
         
         /* car327_print_%s */
         
         if (ptype[0] == '-'){ /* ���s��O���ҹq�l��" */
         	 printf(" ------- ���s��O���ҹq�l�� \n " );
         	 /* ���Ltitle */
         	 strcpy(prtstr1, "\"");
			 strcat(prtstr1, "�������O");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "\t");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "�M�צW��");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "\t");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "���D�W��");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "\t");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "���P���X");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "\t");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "�������X");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "\t");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "�����~��");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "\t");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "�t�P����");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "\t");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "�O�I����");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "\t");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "�O�渹�X");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "\t");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "��O�I��(���e)");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "\t");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "�O�ٽd��");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "\t");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "��O���Ҥ��e����");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "\t");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "�g�P�ӦW��");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "\t");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "�l�a�ϸ�");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "\t");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "�O��W��");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "\t");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "�O��a�}");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "\t");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "�I�تk���N�X");
			 strcat(prtstr1, "\"");
			 strcat(prtstr1, "\t");     
	
         }else{
	         strcpy(prtstr1, "�O�渹");
	         strcat(prtstr1, "\t");
	         strcat(prtstr1, "���P");
	         strcat(prtstr1, "\t");
	         strcat(prtstr1, "�Q�O�I�H");
	         strcat(prtstr1, "\t");
         }
         fprintf(fptr1,"%s\n",prtstr1);

     }
     else
     {
     	 if(strcmp(trim(ipolicy1),"") != 0 )
     	 {
     	     printf("INSERT ipolicy1[%s]\n", ipolicy1 );
     	     $INSERT INTO CAR327 VALUES($ipolicy1);
     	 }
     	 if(strcmp(trim(ipolicy2),"") != 0 )
     	 {
     	     printf("INSERT ipolicy2[%s]\n", ipolicy2 );
     	     $INSERT INTO CAR327 VALUES($ipolicy2);
     	 }
     }
     
     /*
     if( atoi(ptype) == 4 )
     {
          strcpy(stmt_type," AND iofficer[1] = 'W' ");
     }
     else if( atoi(ptype) == 5 )
     {
          strcpy(stmt_type," AND iofficer[1,3] = 'F98'");
     }
     else if( atoi(ptype) == 6 )
     {
        
        
     }
     else if( atoi(ptype) == 7 ) 
     {
          strcpy(stmt_type, " ");
     }
     else if (atoi(ptype) == 8 )
     {
          strcpy(stmt_type," AND iofficer matches 'W*YT*' ");
     }
     else
     {
          strcpy(stmt_type, "AND iofficer[1] = 'W'");
     }
     */
     
     if (ptype[0] == '-'){ /* ���s��O���ҹq�l��" */
     	 /* �Y�O "���s��O���ҹq�l��", �h�����z�L officer�� sbus_source���o���� "�M�ץN�X"��,
     	     �A����ӱM�׬��������   */
     	 /* 990107, ���Y�����w�M��,�B���Ŀ���J���ɮ׬�A�渹,�h���i/���A�z�L officer �ɨ��o�M�ץN�X*/    
     	     
     	  strcpy(stmt_type, " ");
     	
     }else{
     	
	     if( strcmp( ptype, "Z00") == 0 )
	     {
	     	strcpy(stmt_type, " ");
	     	
	     	i_ptype = 7;
	     }
	     if( strncmp( ptype, "Z", 1) == 0 ||
	         strncmp( ptype, "Y18", 3) == 0)  /* Y18 �ΫH50part2,�]B��b�s���I�X��,�Guser����A��C�L���� */ 
	     {
	     	 strcpy(stmt_type, " ");
	     }
	     else
	     {
	     	 rc = get_ca_promote();
	     	 
	     	 sprintf_s(stmt_type, sizeof stmt_type, "AND iofficer[1] = '%s' AND iofficer[%d,%d] = '%s'  "
	                            "AND length(iofficer) = %d ",
	                 iofficer_1, ioff_ck_bgn, ioff_ck_end, trim(ioff_chk), iofficer_len);
	         
	         if( fanother[0] == 'Y' )
	         {
	             sprintf_s(stmt_type, sizeof stmt_type, "AND ((iofficer[1] = '%s' AND iofficer[%d,%d] = '%s'  "
	                            "AND length(iofficer) = %d) or (iofficer[1] = '%s' AND  "
	                            "iofficer[%d,%d] = '%s' AND length(iofficer) = %d)) ",
	                     iofficer_1, ioff_ck_bgn, ioff_ck_end, trim(ioff_chk), iofficer_len,
	                     iofficera_1, ioff_chk_bgna, ioff_ch_enda, ioff_chka, lofficera );
	         }
	         else
	         {
	             sprintf_s(stmt_type, sizeof stmt_type, "AND iofficer[1] = '%s' AND iofficer[%d,%d] = '%s'  "
	                            "AND length(iofficer) = %d ",
	                     iofficer_1, ioff_ck_bgn, ioff_ck_end, trim(ioff_chk), iofficer_len);
	         }
	     }  
     }
     cm_buf_init(ReplyBuf);
     cm_buf_res_msg();
     cm_buf_res_count();
   

     printf("\n\n=================\n");
     
     sprintf_s(sStmt, sizeof sStmt,"select sbus_source from officer where iofficer = ?");
     $PREPARE curOff FROM $sStmt;
  	 
     count=0;
     $DECLARE curx CURSOR for
       SELECT ipolicy
         INTO $ipolicy 
         FROM CAR327;
     $OPEN curx;
     while(1)
     {
         $FETCH curx;
         if(SQLCODE == SQLNOTFOUND) break;
     
         if( strlen(trim(ipolicy)) == 0 ) continue;
    
         strcpy(Full_DBName,get_car_full_db(ipolicy));
         strncpy(ipolicy, trim(ipolicy),13); 
         printf("ipolicy[%s]\n", ipolicy );
         
         /* �Y�O "���s��O���ҹq�l��", �h�����z�L officer�� sbus_source ���o���� "�M�ץN�X"��, �A����ӱM�׬��������   */
         sprintf_s(sStmt, sizeof sStmt,
           "SELECT a.ipolicy, a.dply_begin, a.dply_end, a.ipro_year, a.ibrand,  "
                  "b.nassured, b.nuser, b.itag, b.iengine, b.aassured, b.aassured_zip,  "
                  "b.fassured, b.fsex, a.ibig_office[1,3], a.icomp_in, a.dply_end,  "
                  "a.qnext_year, trim(a.icard) || '-A' ,a.iofficer  "
             "FROM %s:ply_relation a , %s:policy b  "
            "WHERE a.ipolicy = '%s' and a.ipolicy = b.ipolicy %s  "
              "AND a.fedr_class <> '1' ", 
           Full_DBName, Full_DBName, ipolicy, stmt_type );
        
         printf("stmt[%s]\n", sStmt);
 
         $PREPARE cura1 FROM $sStmt;
     	   $EXECUTE cura1 INTO $ipolicy, $dbegin, $dend, $ipro_year, $ibrand,
     	            $nassured, $nuser, $itag, $iengine, $aassured, $aassured_zip, 
     	            $fassured, $fsex, $ibig_office, $comp_DB, $ldend, $qnext_year,
                  $icard_A,$iofficer;

         if(SQLCODE == SQLNOTFOUND)
         {
             strcpy(prtstr, trim(ipolicy));
             strcat(prtstr, "\t");
             strcat(prtstr, " ");
             strcat(prtstr, "\t");
             strcat(prtstr, " ");
             strcat(prtstr, "\t");
             strcat(prtstr, " ");
             strcat(prtstr, "\t");
             if (ptype[0] == '-'){ /* ���s��O���ҹq�l��" */             	
                 strcat(prtstr, "�LB���ơA�O�渹:");
                 strcat(prtstr, ipolicy);                 
             }else{
                 strcat(prtstr, "�LB���ơA�нT�{�M�ץN���O�_���T");             	
             }             	    
             strcat(prtstr, "\t");
             fprintf(fptr,"%s\n",prtstr);
             no_pay_cnt++; 
             
             continue;
         }
     	 printf("===>ply_relation ok\n");
     	 
     	 strcpy(ipolicy_A  , " ");
     	 strcpy(sbus_source, " ");
     	 
   	 /* �O�_��N*�M�׸g�� (count_n > 0:N*�M�׸g��  count_n == 0:�DN*�M�׸g��    add by sylvia 103.09.17 */
  	    count_n = 0;
  	    
  	    if (strncmp(iofficer,"N",1) == 0 )
  	    {
     	    $select count(*) into $count_n
     	       from ca_promote_officer
     	      where iofficer_ori[1,1] = 'N'
     	        and iofficer_ori = $iofficer;
  	    }      
       

     	 if (ptype[0] == '-'){ /* ���s��O���ҹq�l��" */    

     		 if (pro_no1[0]==' ' || pro_no1[0]=='\0'){ /* �����w�M�� =>����B��O�渹 */
 		     	    /* ��J���ɮפ��e��B��O�渹, �P�M�׿ﶵ�]�w���X */
                 if ((iofficer[0] != 'W') && ( !(iofficer[0]=='H' && (iofficer[1] != '0' && iofficer[1] != '1' && iofficer[1] != '2')))
                     && (count_n == 0))
                 {
		              strcpy(prtstr, trim(ipolicy));
		              strcat(prtstr, "\t");
		              strcat(prtstr, " ");
		              strcat(prtstr, "\t");
	                  strcat(prtstr, " ");
	                  strcat(prtstr, "\t");
	                  strcat(prtstr, " ");
		              strcat(prtstr, "\t");
	                  strcat(prtstr, "�����DB��A�Э��s�T�{��J���ɮפ��e�P�y�M�׿ﶵ�z�]�w");
		              strcat(prtstr, "\t");
		              fprintf(fptr,"%s\n",prtstr);
		              no_pay_cnt++;	             
		              continue;  
                 }  
	     	 	    /* ���oB��O�椧�M�ץN�X */ 
	    	        $EXECUTE curOff INTO $sbus_source USING $iofficer;                       			         			     			
     		 }else{ /* �����w�M�� */
     		 	 
     		     if (sNoPlyB[0]=='1'){  /* ��J���ɮפ��e��A��O�渹, Ex.Y18 */
     		     	
 		     	     /* ��J���ɮפ��e��B��O�渹, �P�M�׿ﶵ�]�w���X */                     
                     if ((iofficer[0] == 'W') || (iofficer[0] == 'H' && (iofficer[1]!='0' && iofficer[1]!='1' && iofficer[1]!='2') )
                         || (count_n > 0) ){
			              strcpy(prtstr, trim(ipolicy));
			              strcat(prtstr, "\t");
			              strcat(prtstr, " ");
			              strcat(prtstr, "\t");
		                  strcat(prtstr, " ");
		                  strcat(prtstr, "\t");
		                  strcat(prtstr, " ");
			              strcat(prtstr, "\t");
		                  strcat(prtstr, "������B��A�P�y�M�׿ﶵ�z�]�w���y���w���M�׵LB��...��A��O�渹�z����");
			              strcat(prtstr, "\t");
			              fprintf(fptr,"%s\n",prtstr);
			              no_pay_cnt++;	             
			              continue;  
                     }    
                      		     	
     		         strcpy(ipolicy_A,ipolicy);
     		         
     		         /* ��J���ɮפ��e��A��O�渹, �Gsbus_source = " " 
     		            ��� pro_no1 ���o */
     		         strcpy(sbus_source, pro_no1);
     		     }else{     		    	         		    	         		    	
	    	    	/* ��J���ɮ׬�B��O�渹�B�����w�M�סA	    	    	
	    	    	   => �D "���w���M��" ���O��n���L     */                    
                    if ((iofficer[0] != 'W') && ( !(iofficer[0]=='H' && (iofficer[1] != '0' && iofficer[1] != '1' && iofficer[1] != '2')))
                         && (count_n == 0)){
			              strcpy(prtstr, trim(ipolicy));
			              strcat(prtstr, "\t");
			              strcat(prtstr, " ");
			              strcat(prtstr, "\t");
		                  strcat(prtstr, " ");
		                  strcat(prtstr, "\t");
		                  strcat(prtstr, " ");
			              strcat(prtstr, "\t");
		                  strcat(prtstr, "�����DB��A�Э��s�T�{��J���ɮפ��e�P�y�M�׿ﶵ�z�]�w");
			              strcat(prtstr, "\t");
			              fprintf(fptr,"%s\n",prtstr);
			              no_pay_cnt++;	             
			              continue;  
                    }
                    
	     	 	    /* ���oB��O�椧�M�ץN�X */ 
	    	        $EXECUTE curOff INTO $sbus_source USING $iofficer;                       	    	    	   
	    	        
	    	    	if (strncmp(sbus_source,pro_no1,3) != 0){
			              strcpy(prtstr, trim(ipolicy));
			              strcat(prtstr, "\t");
			              strcat(prtstr, " ");
			              strcat(prtstr, "\t");
		                  strcat(prtstr, " ");
		                  strcat(prtstr, "\t");
		                  strcat(prtstr, " ");
			              strcat(prtstr, "\t");
			              
			              strcat(prtstr, " �z�w���w���s���M�����O�� ");
			              strcat(prtstr, pro_no1);
			              strcat(prtstr, "�F�������M�����O�� ");
			              strcat(prtstr, sbus_source);
			              
			              strcat(prtstr, "\t");
			              fprintf(fptr,"%s\n",prtstr);
			              no_pay_cnt++;	             
			              continue;      	    		
	    	    	} 
	    	    		
	     	 	    /* ���oB��O�椧�M�ץN�X */ 
	    	        $EXECUTE curOff INTO $sbus_source USING $iofficer;   	    	    		
     		     }
     		 }
         }else{
        	 if ( strncmp( ptype, "Y18",3) == 0){
        		 strcpy(ipolicy_A,ipolicy);
        	 }
         }

     	 strcpy(sbus_source,trim(sbus_source));
     	 /**********  check ��A��O�_�w���O  ***********/
     	 
     	 /**  �ɮ���J(type=1); �O�渹�_��(type=2) */     	 
         if( (strcmp(trim(type),"1") ==0) && (qnext_year > 0) )
         {
         	/* "���s��O���ҹq�l��" ���|�� Y18 �ΫH50 �M�� */ 
         	/* "���s��O���ҹq�l��" ptype = "-"            */ 
         	         	         
         	 
            if (ipolicy_A[0]==' '){
	            /** B���A����(�O�渹) **/
	            /* 100.12.26 �ץ��u��"���ӫO�N��"��A��*/
	            sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy  "
	                          " FROM %s:ply_relation a , %s:policy b  "
	                          "WHERE a.ipolicy = b.ipolicy  "
	                          "  AND a.fcard_class = '2'  "
	                          "  AND a.iresource <> 'E'  "
	                          "  AND b.iengine = '%s'  "
	                          "  AND a.dply_end >= %d AND a.dply_end <= %d  "
	                          "  AND a.fedr_class <> '1'  "
	                          "  AND nvl(a.ibig_comp,' ') Between 'A' And 'P' ",
	                          Full_DBName, Full_DBName, iengine, ldend-30, ldend+30);
	         
	            $PREPARE get_A FROM $stmt;
	            $DECLARE get_Ad CURSOR for get_A;
	            $OPEN get_Ad;
	            $FETCH get_Ad INTO $ipolicy_A;
	            if(SQLCODE == SQLNOTFOUND) 
	              strcpy(ipolicy_A, " ");
	            $CLOSE get_Ad;
	            $FREE  get_Ad;
            }
            /* 100.12.26 �U�o�ֱM�פ����w���O�P�_ */
            if ((ptype[0] == '-')&&
                 ((strncmp(iofficer+(7-1),"FW",2)==0 )|| (strcmp(sbus_source,"C15")==0)
                   || (strcmp(sbus_source,"C17")==0)))
            {
            }else{	
	            ao_chk_charge(comp_DB, '1', ipolicy_A, " ", " ",
	                         payresult, paystatus, paydate, notedate);
	            printf("ipolicy_A[%s], payresult[%s]\n", ipolicy_A, payresult);          
	            if (payresult[0] != 'R')
	            {
	               /** �����O�O�椣�i�C�L **/
	               strcpy(prtstr, trim(ipolicy));
	               strcat(prtstr, "\t");
	               strcat(prtstr, trim(itag));
	               strcat(prtstr, "\t");
	               strcat(prtstr, trim(nassured));
	               strcat(prtstr, "\t");
	               strcat(prtstr, trim(ipolicy_A));
	               strcat(prtstr, "\t");
	               strcat(prtstr, trim("�����O"));
	               strcat(prtstr, "\t");
	               fprintf(fptr,"%s\n",prtstr);
	               no_pay_cnt++;
	            
	               if( i_ptype != 7 )  /* �D�Τ@�F�ʧ�O�ҩ� */
	                   continue;
	            }
            }	
            
     	 }
     	 
     	 /**********  �t�P�������  ***********/
    	 $DECLARE cur_model CURSOR for
     	   SELECT ibrand, ipro_year, nbrand
     	     INTO $sibrand, $sipro_year, $nbrand
     	     FROM ca_car_model 
     	    WHERE ibrand = $ibrand 
     	   ORDER BY ipro_year desc;
     	 $OPEN cur_model;
     	 $FETCH cur_model;
     	 $CLOSE cur_model;
     	 
     	 printf("--->ca_car_model ok\n");
     	 strcpy(nassured, trim(nassured));
     	 strcpy(nassured_x, nassured); /* �S���[�ٿת��O��W�� */
     	 strcpy(nuser, trim(nuser));
     	 if( (strcmp(trim(fassured),"1") == 0) ||(strcmp(trim(fassured),"3") == 0) ||
     	     (strcmp(trim(fassured),"5") == 0))
     	 {
     	     if( strcmp(trim(fsex),"1")==0 )
     	     {
     	 	 strcat(nassured, "  ����");
     	 	 strcat(nuser,"  ����");
     	     } else {
     	         strcat(nassured, "  �p�j");
     	         strcat(nuser,"  �p�j");
     	     }
     	 }
     	 
     	 /* N*�g��S�O�P�_ add by sylvia 103.09.18 */
     	 if (iofficer[0] = 'N')
     	 {
     	   /* ��A�欰A*�g�쪺�~�� */
     	   $select iofficer[1,3] into $ibig_office
     	      from ca_promote_officer
     	     where iofficer_ori = $iofficer
     	       and iofficer[1,1] = 'A';
     	 }
     	 /* ---------------------------------------------------------------- */
     	 $SELECT ibig_branch, itel
     	    INTO $ibig_branch, $itel
     	    FROM ca_big_office
     	   WHERE fclass = '1'
     	     AND ibig_comp = $ibig_office;
         if(SQLCODE == SQLNOTFOUND)
         {
             ibig_branch[0] = '\0';
             itel[0] ='\0';
         }    
     	 printf("ibig_branch[%s] itel[%s]\n", ibig_branch, itel );      
     	 
     	 printf("***ca_big_office ok\n");
     	 strcpy(dbegin, cm_from_infdate(dbegin));
     	 strcpy(dend  , cm_from_infdate(dend));
     	 
         if (ptype[0] == '-'){ /* ���s��O���ҹq�l��" */
     	 
	     	 cm_split_ymd(dbegin,yy1,mm1,dd1);
	     	 cm_split_ymd(dend  ,yy2,mm2,dd2);
	     	 strcpy(yy1,trim(yy1));
	     	 strcpy(yy2,trim(yy2));
	     	 
	     	 /* �O�I����:97�~01��05��~98�~01��05�� */
	     	 sprintf_s(dperiod, sizeof dperiod,"%s�~%s��%s���%s�~%s��%s��", yy1,mm1,dd1,yy2,mm2,dd2);     	      	 
	     	 printf(" ------- dperiod = [%s]\n " , dperiod);
         	
         	 /**********   ���o��B�椧�M�׸��   ***********/
         	 /* �������O�B�M�צW��(����)�B��O�I��(���e)�B�O�ٽd��B��O���Ҥ��e�����B�I�تk���N�X */

             printf(" ------- iofficer = [%s]\n " , iofficer);
             printf(" ------- sbus_source = [%s]\n " , sbus_source);
             sprintf_s(stmt, sizeof stmt,"SELECT imodule,nprmt_full,nins_type,iins_desc,iins_wording1,flaw   "
                           " FROM ca_promote  "
                           "WHERE iprmt = '%s'", sbus_source);
                           
            $PREPARE pre_ca_promote FROM $stmt;
            $EXECUTE pre_ca_promote into $imodule,$nprmt_full,$nins_type,$iins_desc,$iins_wording1,$flaw;
            
            if(SQLCODE == SQLNOTFOUND){
	              strcpy(prtstr, trim(ipolicy));
	              strcat(prtstr, "\t");
	              strcat(prtstr, trim(itag));
	              strcat(prtstr, "\t");
                  strcat(prtstr, trim(nassured));
                  strcat(prtstr, "\t");
                  strcat(prtstr, trim(ipolicy_A));
	              strcat(prtstr, "\t");
                  strcat(prtstr, "�g��H�]�w���u�~�Ȩӷ������v���~�εL�ӱM�סA�g��N��:");
                  strcat(prtstr, iofficer);
	              strcat(prtstr, "\t");
	              fprintf(fptr,"%s\n",prtstr);
	              no_pay_cnt++;	             
	              continue;   
	                      	
             }else{
             	  /* �]��������Ƥ��e(iins_desc�Biins_wording1)���_��A���F�bexcel �����T���,�G���������޸��A�_�� */
                  strcpy(prtstr1, "\""); 
				  strcat(prtstr1, trim(imodule));        /* �������O          */
				  strcat(prtstr1, "\"");
	 			  strcat(prtstr1, "\t");
	 			  strcat(prtstr1, "\"");
				  strcat(prtstr1, trim(nprmt_full));     /* �M�צW��(����)    */
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, "\t");
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, trim(nassured_x));     /* ���D�W��          */
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, "\t");
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, trim(itag));           /* ���P���X          */
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, "\t");
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, trim(iengine));        /* �������X          */
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, "\t");
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, trim(ipro_year));      /* �����~��          */
				  strcat(prtstr1, "�~"); 
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, "\t");
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, trim(nbrand));         /* �t�P����          */
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, "\t");
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, trim(dperiod));        /* �O�I����          */
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, "\t");
				  strcat(prtstr1, "\"");
				  if (strncmp(sbus_source,"Y18",3)==0){
				  	  strcat(prtstr1, trim(icard_A));    /* �O�d��-A          */
				  }else{	 			  	
				      strcat(prtstr1, trim(ipolicy));    /* �O�渹�X          */
				  }
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, "\t");
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, trim(nins_type));      /* ��O�I��(���e)    */
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, "\t");
				  strcat(prtstr1, "\"");
				  strSearchReplace(iins_desc,"�U"," \n"); /* client�ݱNVbCrLf�H "�U"���N,�G���ন����Ÿ�*/
				  strcat(prtstr1, trim(iins_desc));      /* �O�ٽd��          */
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, "\t");
				  strcat(prtstr1, "\"");
				  strSearchReplace(iins_wording1,"�U"," \n"); /* client�ݱNVbCrLf�H "�U"���N,�G���ন����Ÿ�*/
				  strcat(prtstr1, trim(iins_wording1));  /* ��O���Ҥ��e����  */				  
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, "\t");
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, trim(ibig_branch));    /* �g�P�ӦW��        */
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, "\t");
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, trim(aassured_zip));   /* �l�a�ϸ�          */
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, "\t");
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, trim(nassured));       /* �O��W��          */
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, "\t");
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, trim(aassured));       /* �O��a�}          */
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, "\t");
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, trim(flaw));           /* �I�تk���N�X      */  
				  strcat(prtstr1, "\"");
				  strcat(prtstr1, "\t");   
                 
		          fprintf(fptr1,"%s\n",prtstr1);  
		          pay_cnt++;         	
             }
         }else{	 
	         if ( strncmp( ptype, "Y18", 3) == 0)
	            strcpy(ipolicy,icard_A);    
	                 	
	         cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s ",ipolicy, nassured, nuser,
	                    itag, iengine, ipro_year, nbrand, dbegin, dend, 
	                    aassured, aassured_zip);
	         cm_buf_put("%s %s ",ibig_branch, itel);           
        
	         if( strcmp(trim(type),"1") ==0 )
	         { 
	           strcpy(prtstr1, trim(ipolicy));
	           strcat(prtstr1, "\t");
	           strcat(prtstr1, trim(itag));
	           strcat(prtstr1, "\t");
	           strcat(prtstr1, trim(nassured));
	           strcat(prtstr1, "\t");
	           fprintf(fptr1,"%s\n",prtstr1);
	           pay_cnt++;
	         } 	         
         }
                     
         count++;


         if( i_ptype == 7 )  /* �Τ@�F�ʧ�O�ҩ� */
         {
             sprintf_s(sStmt, sizeof sStmt,
               "SELECT COUNT(*)  "
                 " FROM %s:ply_ins_type  "
                 "WHERE ipolicy = '%s'", 
			Full_DBName, ipolicy);
        
             printf("stmt[%s]\n", sStmt);

             $PREPARE prep_ins FROM $sStmt;
             $EXECUTE prep_ins INTO $iCountDtl;
             $FREE prep_ins;

             cm_buf_put("%d", iCountDtl);

             sprintf_s(sStmt, sizeof sStmt,
               "SELECT a.iins_type, b.nins_type1, a.minjured_cover, a.mdeath_cover, a.mdamage_cover, b.qserial  "
                " FROM %s:ply_ins_type a, insurance_type b  "
                "WHERE a.iins_type = b.iins_type  "
                "  AND a.ipolicy = '%s'  "
                "ORDER BY b.qserial", Full_DBName, ipolicy);
        
             printf("stmt[%s]\n", sStmt);
             iCountDtl = 0;

             $PREPARE prep_ins FROM $sStmt;
             $DECLARE cur_ins CURSOR for prep_ins;

             $OPEN cur_ins;
             for(;;)
             {
                 $FETCH cur_ins INTO $sIinsType, $sNinsType1, $lMinjured_cover, $lMdeath_cover, $lMdamage_cover,
                                     $qserial;
                 if(SQLCODE == SQLNOTFOUND) break;
                 
                 /*960327,�s�W56�I�ؤ��B,��l�I�ؤ��B��0*/
                 lDaily_pay = 0;
                 if (strncmp(sIinsType,"56",2)==0){
		             sprintf_s(sStmt, sizeof sStmt,
		               "SELECT first 1 daily_pay  "
		                " FROM %s:ca_pa_ply  "
		                "WHERE ipolicy = '%s' AND daily_pay != 0 "
                       , Full_DBName, ipolicy);
		        
		             printf("stmt[%s]\n", sStmt);
				     $prepare pre_cur_pa from $sStmt;
			         $execute pre_cur_pa into $lDaily_pay;             	
                 }
                 
                 printf("-----lDaily_pay--[%ld]\n",lDaily_pay);
                 
                 cm_buf_put("%s %s %l %l %l %l", sIinsType, sNinsType1, lMinjured_cover, lMdeath_cover, lMdamage_cover,lDaily_pay);
                 iCountDtl ++;
             }
             $CLOSE cur_ins;
             $FREE  cur_ins;
         }
     }
     $CLOSE curx;
     $FREE  curx;
     
     printf(" ******************************************** \n");
     printf(" ------- no_pay_cnt = [%d]\n " , no_pay_cnt);
     printf(" -------    pay_cnt = [%d]\n " , pay_cnt);
     printf(" -------      count = [%d]\n " , count);
     if( strcmp(trim(type),"1") ==0 )
     {	 
        cm_buf_put("%d", no_pay_cnt);
        
        fclose(fptr);
        if( no_pay_cnt > 0 )
        {     
     	    rt = rptftpinsert(userid,"car327",outputf);
            if (rt != 0){
               printf("rptftp error\n");
               goto errexit;
            }
        }
        
     }
     
     printf(" &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& \n");
     
     cm_buf_put_msg(M_CM_OK);
     cm_buf_put_count(count);     
     
     $DROP TABLE CAR327;

     if( strcmp(trim(type),"1") ==0 )
     {
       fclose(fptr1);
       rt = rptftpinsert(userid,"car327",outputf1);
       if (rt != 0){
          printf("rptftp error\n");
          goto errexit;
       }
     }
     printf("ReplyBuf[%s]\n", ReplyBuf);
     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:

     printf("into errexit 1 \n");
     if(exitsub(reply,SQLCODE) == True)
     {
         printf("into errexit 2 \n");
         return SQLCODE;
     }
     else
         return apiRC;
}

long  ca327_getfile()
{
    int rtncode,Len;
    int i,d, tot_count=0;
    
    $WHENEVER sqlerror goto errexit;
    Len=0;
    printf("  into read file \n");
    rtncode = getApHome(sApHome);
    if (rtncode < 0) 
    {
         printf("read Config file error!!\n");
         return M_CM_READ_CONFIG_ERR;
    }
    sprintf_s(getfile, sizeof getfile, "%s/dat/car/%s", sApHome, sfile);

    printf("getfile[%s]\n",getfile);
    if ((fp=fopen(getfile,"rt"))==NULL) 
    {
    	printf("fopen file error \n");
    	return FALSE;
    }

    if ((bp=malloc(recLen))==NULL) 
    {
         printf("System malloc failed  !\n");
         return FAIL;
    }   	
    
    while(fgets(bp,recLen,fp))
    {
         
         sTmp[0]='\0';
         GetData(sTmp   , bp    , 1000);

         Len = strlen(trim(sTmp));

         if (Len > 1)
         {
            for(i=0;i<1000;i++)
            {
                printf("sTmp[%d] = [%c]\n",i ,sTmp[i]);
                if ((sTmp[i] == '\0') || (sTmp[i] == '\n'))
                    break;

                if ( isalnum(sTmp[i]) == 0 )
                  break; 

            }

            strncpy(sData,sTmp,i);
            sData[i] = '\0';
            d=strlen(sData);
            sData[d]='\0';
            strcpy(sData,rtrim(sData));

            printf("d = [%d] sData=[%s]\n", d, sData );

            $INSERT INTO CAR327 (ipolicy)
                        VALUES  ($sData);
            tot_count ++;
         }
         if (feof(fp)) break;

    } /* end of while */
/*
    if( tot_count > 100)
        return M_CM_OK;
*/    
  
 
    return M_CM_OK;
    
errexit:
    printf("before SQLCODE \n");
    return SQLCODE;    

}
delfile()
{
char sComm[128];
int  rc;
    if( strlen(getfile) != 0)
    {
        sprintf_s(sComm, sizeof sComm, "rm -f %s", getfile);
        printf("sComm=[%s]\n",sComm);
        rc = system(sComm);
        printf("rc code=[%d]\n",rc);
    }
}

int GetData(data,offset,length)
char *data;
int offset,length;
{
    data[0]='\0';
    memcpy(data,offset,length);
    data[length] = 0x00;
    printf("data[%s]\n",data);
}

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
        char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
        char sTmp_db_name[21];

        sTmp_db_name[0]='\0';
        if (*sIpolicy != '\0' && *sIpolicy !=' ')
        {
           sTmp_db_name[0]='\0';
           strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
           strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
                  USE_BRANCH_ID));
           strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
        }
  return sTmp_db_name;
}


int rptftpinsert(user,pgid,outfile)
$char *user,*pgid,*outfile;
{
   $WHENEVER SQLERROR GOTO errexit;
printf(" !!!!!!!!!!!!!!!!!!!! \n");
printf(" nuserid[%s] ipgid[%s] noutfile[%s]  \n",user,pgid,outfile);
   $insert into rptftplist
    (nuserid,ipgid,noutfile,dcreate)
    values
    ($user,$pgid,$outfile,current);
printf(" 222222222222222222 \n");
   return 0;

 errexit:
 printf("SQLCODE[%d] errmsg[%s]\n",SQLCODE,sqlca.sqlerrm);
 exit(1);
}

long get_ca_promote()
{
   
   $whenever sqlerror goto errexit;
   
   printf("===== start  get_ca_promote \n");
   printf("===== pro_no [%s] \n", pro_no );
   
   $SELECT iprmt, nprmt, iremark, iagent, iofficer_1, lofficer,
           ioff_chk_bgn, ioff_chk_len, ioff_chk, mlimit, fanother,
           iofficera_1, lofficera , ioff_chk_bgna, ioff_chk_lena, ioff_chka,
           iins_type
      INTO $iprmt, $nprmt, $iremark, $iagent, $iofficer_1, $iofficer_len,
           $ioff_ck_bgn, $ioff_ck_len, $ioff_chk, $mlimit, $fanother,
           $iofficera_1, $lofficera , $ioff_chk_bgna, $ioff_chk_lena, $ioff_chka,
           $iins_list
      FROM ca_promote
     WHERE iprmt = $pro_no;
   if(SQLCODE != SQLNOTFOUND )
   {
      strcpy(ioff_chk, trim(ioff_chk));
      ioff_ck_end = ioff_ck_bgn + ioff_ck_len -1;
      
      strcpy( iofficer_1, trim(iofficer_1));
      printf("===== finish get_ca_promote \n");
      
      if( fanother[0] == 'Y' )
      {
          ioff_ch_enda = ioff_chk_bgna + ioff_chk_lena -1;
          strcpy( iofficera_1, trim(iofficera_1));
      }
      else
          ioff_ch_enda=0;
      
      
      
      return M_CM_OK;
   }
   
errexit:
   
   printf("SQLCODE[%d] errmsg[%s]\n",SQLCODE,sqlca.sqlerrm);
   exit(FAIL);    
}

/* �Y searchString = replaceString      => �^�� searchString �b string�����Ӽ� */
/* �Y searchString != replaceString     => �N�b string����searchString ���N�� replaceString ,�æ^�Ǩ��N���Ӽ� */
/* �Y�j�M����εL����searchString�Q���N => �^�� 0 */
int strSearchReplace(char *string,char *searchString,char *replaceString)
 {
 char *currP, *baseStr;
 int  count = 0;

 currP = baseStr = NULL;

 while (*string)
      {
      currP = strstr (!currP ? string : baseStr, searchString);

      if (currP)
           {
           count++;
           baseStr = (currP + strlen (replaceString));
           strcpy (currP, (currP + strlen (searchString)));
           memmove (currP + strlen (replaceString),
                      currP, strlen (currP) + 1);
           memcpy (currP, replaceString, strlen (replaceString));
           }
      else
           break;
      }

 return count;
 }