/* ****************************************************************************
 * Program ID: ca401m04s.ec
 *
 * Description:
 *   ���C�L, �p�G�ק怜�ڲĤT�p�����O�a�},�q��,�g���H(��Ƨ���),
 *   �{�� Block endorse_item �]�n�ק�
 *   ca_rpt_endorse in ca_rpt_endorse.ec
 *   
 *   �j��L���v�q�ಾ
 *   �{�� ca_rpt_contrans.ec
 *
 * Author:   Tony96, S.Y.HWANG.870609
 *
 * ****************************************************************************/
#include <malloc.h>

#include <api_xsrv.h>
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "gls_array.h"
#include "gls_const.h"
#include "print.h"
#include "safeclib.h"

$include datetime.h;
$include decimal.h;

/* *** Message block *** */
#define _M860718
/* ********************* */

#define PAGE_LINE	72	/* �@����� */

/* *** Function prototype *** */
long car401_build();
long car401_build1();
long drop_temp_table();
long insert_tmp_table();

$char sUserid[11]="", kpid[12]="",g_fmask_yn[2]="";



/************************************************************************/
long car401_local_prn (reply)
serverReply reply;
{
  char sDBName[5],sHostName[21],tmpOutFile[51],sIendorse[ENDORSE_NUM],sFile[41];
  $char p_fmask[2],p_FreeForm[2],v_sMsg[512];
  int  iTmpLen,i;
  long iRtnCode;

  $WHENEVER SQLERROR GOTO errexit;

  /* cm_buf_get("%s %s %s", sDBName, sIendorse, p_fmask);  */  
  cm_buf_get("%s %s %s %s %s %s", sDBName, sIendorse, p_fmask, sUserid, p_FreeForm, kpid);  /*1111019012_SC2 ���I�Φ����O���Freeform�L�s�}�o*/

  printf("--trace kpid=[%s]\n",kpid);

  iRtnCode=0; 
  strcpy(v_sMsg , ""); strcpy(g_fmask_yn, "Y"); 

  if(db_select(sDBName) == False)
  {
       strcpy( v_sMsg, cm_get_errmsg(M_CM_DB_NOTOPEN));
       goto errexit;    
      /* return M_CM_DB_NOTOPEN;*/
  }  
 
  if (p_fmask[0]=='0')
  {
      strcpy(g_fmask_yn, "N");
  }  
  
  if (p_FreeForm[0]=='1')
  {
      strcpy(sFile," ");
          
      /* INSERT cm_freeform     ����Ǹ�    �I�O       �M�L�O    �C�L�O(0:�C�L 1:�w��) �����O(F:���� P:�ɦL) �Ӹ�����(Y/N)  ���C�L�Ƶ�(������) �C�L����O(������) �O�榬�ڥ��ƥ�  �O��O    �C�L���ڧO   �L�����N��  �{���W��   ����H��   ����ɶ�  �����ɶ� */          
      $INSERT INTO cm_freeform (kpid   , iins_cat, formid     , fprint        ,fformal            , fhide       ,fnote         ,fbranch        ,fpolicy ,fcondition, iprinter,ipgid   ,iupdate  ,tstime  ,tetime)
                       VALUES ($kpid  , 'C'     , 'CARPLY001', '0'           ,'F'                , $g_fmask_yn ,' '           ,' '             ,' '     , ' '      , ' '     ,'car401',$sUserid ,current ,current);    
  }
  else
  {
       sprintf_s(sFile, sizeof sFile, "%s.tx", getFileName());
  }
  /* iRtnCode = car401_build(sIendorse, sFile, p_fmask); */
  iRtnCode = car401_build(sIendorse, sFile, p_fmask, p_FreeForm); /*1111019012_SC2 ���I�Φ����O���Freeform�L�s�}�o*/
  if(iRtnCode != M_CM_OK)
  {
      if (p_FreeForm[0]=='1')
      {   
          if (iRtnCode > 0) 
          {
              sprintf_s(v_sMsg, sizeof v_sMsg,"car401_build()�GiRtnCode=[%ld],errmsg=[%s]", iRtnCode,cm_get_errmsg(iRtnCode));
          }
          else if (iRtnCode < 0) 
          {
              sprintf_s(v_sMsg, sizeof v_sMsg,"car401_build()�GSQL ERROR�GiRtnCode=[%ld]�Asqlerrm=[%s]", iRtnCode, sqlca.sqlerrm);
          }
      }

      goto errexit;
  }

  /*1111019012_SC2 ���I�Φ����O���Freeform�L�s�}�o*/
  if (p_FreeForm[0]=='1')
  {
      strcpy(sHostName , " "); 
      strcpy(tmpOutFile, " ");
  }
  else
  {
      gethostname(sHostName, sizeof(sHostName));
      rptinit();

      printf("-------->RPTDIR[%s]\n",RPTDIR);
      printf("-------->sFile[%s]\n",sFile);
      sprintf_s(tmpOutFile, sizeof tmpOutFile, "%s%s", RPTDIR, sFile);
  }

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s %d", M_CM_OK, sHostName, tmpOutFile, PAGE_LINE);

  iTmpLen = cm_buf_len(ReplyBuf);

  if(SendSyncReply(reply, ReplyBuf, iTmpLen, api_OKComplete) == False)
      return apiRC;
  else
      return M_CM_OK;

errexit:

    printf("{car401_local_prn} SQLCODE= [%ld],sqlerrm=[%s]\n",SQLCODE, sqlca.sqlerrm);
    printf("{car401_local_prn} iRtnCode= [%ld]\n",iRtnCode);
    printf("{car401_local_prn} v_sMsg = [%s]\n",v_sMsg);

    if (SQLCODE < 0) /* sql runtime error*/
    {
        sprintf_s(v_sMsg, sizeof v_sMsg,"SQL ERROR�GSQLCODE=[%ld]�Asqlerrm=[%s]", SQLCODE, sqlca.sqlerrm);
    }
    else if (iRtnCode < 0)
    {
        sprintf_s(v_sMsg, sizeof v_sMsg,"SQL ERROR�G(iRtnCode=[%ld])", iRtnCode);
    }

    if (strlen(v_sMsg)==0)
    {
        strcpy(v_sMsg, "�C�L�����楢�ѡA�Э���");
    }

    
    if (p_FreeForm[0]=='1')
    {         
       $WHENEVER SQLERROR CONTINUE;

       /* �g�J�� cm_freeform �i��|�Q rollback�A�G�n�A���g�J�@���A�Y����(-239)�|CONTINUE  */
       /* INSERT cm_freeform     ����Ǹ�    �I�O       �M�L�O    �C�L�O(0:�C�L 1:�w��) �����O(F:���� P:�ɦL) �Ӹ�����(Y/N)  ���C�L�Ƶ�(������) �C�L����O(������) �O�榬�ڥ��ƥ�  �O��O    �C�L���ڧO   �L�����N��  �{���W��   ����H��   ����ɶ�  �����ɶ� 
       $INSERT INTO cm_freeform (kpid   , iins_cat, formid     , fprint        ,fformal            , fhide       ,fnote         ,fbranch        , fversion    ,fpolicy ,fcondition, iprinter,ipgid   ,iupdate  ,tstime  ,tetime)
                         VALUES ($kpid  , 'C'     , 'CARPLY001', '0'           ,'F'                , $g_fmask_yn ,' '           ,' '            , ' '         ,' '     , ' '      , ' '     ,'car401',$sUserid ,current ,current);
       */                  
        
       $INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint, fversion) VALUES ($kpid,'C',' ',' ',' ','0','199',' ',' ','0',$v_sMsg,$sUserid,current,' ');
       
    }
/*
    if (iRtnCode != M_CM_OK)
    {*/
        if (exitsub(reply,iRtnCode)==True){                    
            return iRtnCode;
        }else{            
            return iRtnCode;
        }
/*    }
    else
    {
      
      iTmpLen = cm_buf_len(ReplyBuf);
      if (SendSyncReply(reply,ReplyBuf,iTmpLen,api_OKComplete)==False){
          return apiRC;
      }else{    
          return M_CM_OK; 
      }   
    }
*/
}

/*************************************************************************/
long car401_build (p_sIendorse, p_sFile, p_fmask,  p_fFreeForm)
$char *p_sIendorse, *p_sFile, *p_fmask, *p_fFreeForm;
{
  $char sFormFile[21], sTmpBuf[512], v_sMsg[512];
  $int  iRtnCode, iPgLine, i;
  long  lMprem_total;
  $char fcard_class[2], iroute[21], iassured[11], s_ipolicy[21],s_icard[21],s_iofficer[11],s_ileader[11];
  $char iendorse[ENDORSE_NUM], dcreate[11];

  $WHENEVER SQLERROR GOTO errexit;

  if (p_fFreeForm[0]=='1')
  {     

      printf("kpid=[%s] \n", kpid );

      strcpy(s_ipolicy," " ); strcpy(s_icard," " ); strcpy(s_iofficer," " );  strcpy(s_ileader," " );
      $SELECT ipolicy, CASE WHEN fcard_class ='1' THEN icard ELSE ' ' END , iofficer, ileader 
        INTO $s_ipolicy ,$s_icard ,$s_iofficer ,$s_ileader
        FROM edr_relation  
        WHERE iendorse = $p_sIendorse;
  }

  iRtnCode = chk_iendorse_status( p_sIendorse, v_sMsg);
  printf("chk_iendorse_status iRtnCode[%d]\n", iRtnCode);

  if(iRtnCode != M_CM_OK)
  {
      if (p_fFreeForm[0]=='1')
      {
          printf("chk_iendorse_status v_sMsg[%s]\n", v_sMsg);
          $INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint, fversion) VALUES($kpid,'C',$s_ipolicy,$p_sIendorse,$s_icard,'0','199',$s_iofficer,$s_ileader,'0',$v_sMsg,$sUserid,current,' ');
      }
      return iRtnCode;
  }

  $BEGIN WORK; /* �Y�L�줤�~�o�Ϳ��~�A�h�|���� Rollback */

  /*1111019012_SC2 ���I�Φ����O���Freeform�L�s�}�o*/
  if (p_fFreeForm[0] == '1')
  {
      iRtnCode = ca_freeform_endorse(p_sIendorse, &lMprem_total, "0", p_fmask, kpid);
      if(iRtnCode != M_CM_OK)
      {
          sprintf_s(sTmpBuf, sizeof sTmpBuf, "���[%s],kpid[%s] �C�L�����D(ca_freeform_endorse)", p_sIendorse, kpid);                                    
          $INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint, fversion) VALUES($kpid,'C',$s_ipolicy,$p_sIendorse,$s_icard,'0','199',$s_iofficer,$s_ileader,'0',$sTmpBuf,$sUserid,current,' ');
          $COMMIT WORK;
          return iRtnCode;
      }
      else
      {
          $INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint, fversion) VALUES($kpid,'C',$s_ipolicy,$p_sIendorse,$s_icard,'0','100',$s_iofficer,$s_ileader,'0',' ',$sUserid,current,' ');
      }
  }
  else
  {
      $SELECT nForm_File 
         INTO $sFormFile
         FROM Form
        WHERE ksys_grp = "CA" AND kPgmID = 401 AND iform_tp = "1";

      strcpy(sFormFile, rtrim(sFormFile));

      rgu_init_report(sFormFile, p_sFile);

      /*
      $select ipolicy 
        into $ipolicy
        from edr_relation
        where iendorse = $p_sIendorse;

      iRtnCode = chk_edr_dmg( ipolicy, p_sIendorse, v_sMsg);
      if( iRtnCode != M_CM_OK)
        return iRtnCode;
      */

      iPgLine = 0;
      iRtnCode = ca_rpt_endorse(p_sIendorse, &lMprem_total, p_fmask);
      if(iRtnCode != M_CM_OK)
      {
         $ROLLBACK WORK; 
         return iRtnCode;
      }  

      if(lMprem_total != 0)
      {
        iRtnCode = car401_body_receipt(p_sIendorse);
        if(iRtnCode != M_CM_OK)
        {
           $ROLLBACK WORK; 
           return iRtnCode;
        }    
      }

      data_report(&iPgLine);

      printf("---------------------- iPgLine[%d]\n",iPgLine);

      drop_temp_table();

      rgu_finish_report();
  }  

  /* 1001003001_C1 ���r�y����CVP�A�L�����(edr_relation.dendorse)�A�C�L����~�g�J�����(�浧�C�L) */
  $UPDATE edr_relation
      SET dendorse = today, fprint = '1'
    WHERE iendorse = $p_sIendorse
      AND dendorse is null
      AND dedr_close is null
      AND iendorse not like '%CVP%';

   $COMMIT WORK;
  
   return M_CM_OK;

errexit:

   if (SQLCODE < 0) iRtnCode = SQLCODE;

   printf("{car401_build} SQLCODE=[%d],sqlerrm=[%s]",SQLCODE, sqlca.sqlerrm);
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;

   return iRtnCode;


} /* car401_build */

/******************************************************************************/

long ca411_contact_transfer (reply)
serverReply reply;
{
  char sDBName[5],sHostName[21],tmpOutFile[51],sIendorse[ENDORSE_NUM],sFile[41];
  int  iRtnCode, iTmpLen;

  cm_buf_get("%s %s", sDBName, sIendorse);

  if(db_select(sDBName) == False)
    return M_CM_DB_NOTOPEN;

  sprintf_s(sFile, sizeof sFile, "%s.tx", getFileName());

  iRtnCode = car401_build1(sIendorse, sFile);

 if(iRtnCode != M_CM_OK){
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l", iRtnCode);
    iTmpLen = cm_buf_len(ReplyBuf);
    if(SendSyncReply(reply, ReplyBuf, iTmpLen, api_OKComplete) == False)
      return apiRC;
    else
      return iRtnCode;
  }

  gethostname(sHostName, sizeof(sHostName));
  rptinit();

printf("-------->RPTDIR[%s]\n",RPTDIR);
printf("-------->sFile[%s]\n",sFile);

  sprintf_s(tmpOutFile, sizeof tmpOutFile, "%s%s", RPTDIR, sFile);

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s %d", M_CM_OK, sHostName, tmpOutFile, PAGE_LINE);

  iTmpLen = cm_buf_len(ReplyBuf);

  if(SendSyncReply(reply, ReplyBuf, iTmpLen, api_OKComplete) == False)
    return apiRC;
  else
    return M_CM_OK;
}

/*************************************************************************/

long car401_build1 (p_sIendorse, p_sFile)
char *p_sIendorse, *p_sFile;
{
  $char sFormFile[21], sTmpBuf[512];
  $int  iRtnCode, iPgLine;
  long  lMprem_total;

  $WHENEVER SQLERROR GOTO errexit;

  $SELECT nForm_File 
     INTO $sFormFile
     FROM Form
    WHERE ksys_grp = "CA" AND kPgmID = 401 AND iform_tp = "2";
    
    printf(" sFormfile[%s]\n",sFormFile);

  strcpy(sFormFile, rtrim(sFormFile));

  rgu_init_report(sFormFile, p_sFile);


  iPgLine = 0;
  iRtnCode = ca_rpt_contrans(p_sIendorse);
  if(iRtnCode != M_CM_OK)
     return iRtnCode;

printf("---------------------- iPgLine[%d]\n",iPgLine);

  rgu_finish_report();

  return M_CM_OK;

errexit:
  printf("{ca401_build}: SQLCODE=[%d] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
  return SQLCODE;
} /* car401_build */
