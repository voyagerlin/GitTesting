/* Copyright (C) 2001 Intellisys Corporation */
/* Program : ca997p02s.ec                    */
/* �j����O�O�d�ߤ��ߧ����                  */
/* Author�GNeo Chen                          */
/* Time �G90/10/12                           */
/* Modified Date: 2010/04/21                 */
/* Purposed: �ӫO౻T�o�{�O���ܰʪ��ǰe���T
             �ʽ観�~,2010/04/21�ϥ�bug���覡,
             1. �N79�אּ�eAC,���A�ư�(�j����N)
             2. �ʽ�75����eAC + 08(�j����N)       
/*********************************************/
 
#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "sqlfatal.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"

#include "safeclib.h"

#define ONLINE_DATE "04/29/2007"	/* �e���T��Ʊj����N���ɤW�u�� */

/*--------------------------------------------------------------------*/

DBinfo  *list;
int     i=0,count_db=0,rc=0;

char    userid[11],option[2],outputf[21];
$char   DBName[05];
$char   dbgn1[11],dend1[11],datebgn[11],dateend[11];
$char   sApHome[31];
char    errmsg[200];
FILE    *errfpt;
FILE    *fptr;

$char   errFile[30],strlog[500],errlog[300];

/* data from edr_relation */
$char ipolicy[21],fcard_class[2],ilast_ply[21],icard[21];
$char icar_type[3],iissue_ym[6],ibrand[10],ipro_year[5],fcomp_class[3];
$long dply_begin=0,dply_end=0,dendorse=0,dedr_begin=0;
$char iendorse[21],sFedr_class[2],sFcard_class[2];
$char ipolicy_chg[21];
$char terminate_rsn[2], dcreate[31], tmp_dcreate[31];
   
/* data from endorsement */
$char ilicense[11],ibirth[9],fsex[2],fmarriage[2],fpt[2],iengine[CA_ENGINE_NUM];
$char ibody[CA_BODY_NUM],itag[CA_TAG_NUM],iassured[11],nassured[121],iply_area[3],fassured[2];
$char itag_last[CA_TAG_NUM], itag_next[CA_TAG_NUM];
$int  qcylinder=0, ipdmg_align=0, iplia_align=0, ipbrg_align=0;
$double qpt;
$int id1=0;

$char nassured_tmp[201];
   
/* data from edr_ins_type */
int iFetch,iTmpbuf;
$char iins_type[3],iins_type_rule[3],drate_ym[6],iedr_type[3];
$long  mdeduct=0,mprem=0;
$long  medrinj_cover=0, medrdea_cover=0, medrdmg_cover=0, medrins_prem=0;
   
/* others*/
$char prem_subtot_c[9],mins_premium_c[9];
$char objno[5],icode[2],drate[11];
$long prem_subtot,prem_subtot0,cntrlrec=0,birth_yyyy;
$char prtstr[500],sTmpInsType[3], iply_type[3];
$char prtstr_9[500];
char  tmp_yyyy[5];
$char  dply_yy[4],dply_mm[3],ibirth_yy[5],ibirth_mm[3],ibirth_dd[3],tmp_dd[3];
char  card_str[16],dply_begin_c[9],dply_end_c[9],endorse_c[9];
char  dply_begin_yy[4],dply_begin_mm[3],dply_begin_dd[3];
char  dply_end_yy[4],dply_end_mm[3],dply_end_dd[3];
$char  iissue_yy[5],iissue_mm[3],cntrlrec_c[7];
char  minjured_c[9],mdeath_c[9],mdamage_c[9],mdeduct_c[8],mprem_c[10];
char  dendorse_c[11],sTmpbuf[200];
char  sPrePolicy[21],sPrePolicy1[21],medrins_prem_c[10];
$char bzfrom[3];
long  yy_long=0,iRtnCode;
$long  lTmpMdeduct=0, lTmpMins_premium=0, prem_total=0, sDendorse=0, lTmp=0;
$date Today;
FILE  *fptr,efp;
$char  company_flag;
$int   count;
$char  CAR_COMPANY_E[3];
$char  CAR_COMPANY_P[3];
char  companyid[3];
int   rtn;

$char qpro_month_c[3];

long car9972_get_db();
long car9972_build_comp();
long car9972_edr_relation();
extern char *sformat_trade();
extern long split_policy();
extern int rptftpinsert();
static char *get_car_full_db();  /*   �ǤJ�O�渹��X���O�檺�k�ݸ��*/
long check_if_exist();
long  today, online_date, online;

/*--------------------------------------------------------------------*/

main(argc,argv)
int   argc;
char  **argv;
{
   int   rc;

   batchinit();

   strcpy(DBName,isNULLstr(argv[1]));
   strcpy(userid,isNULLstr(argv[2]));
   strcpy(option,isNULLstr(argv[3]));     /* 1:�j��T�����, 3:�j�������� 4:��歫�e, 5:���簣���e */
   strcpy(datebgn,isNULLstr(argv[4]));
   strcpy(dateend,isNULLstr(argv[5]));
   strcpy(outputf,isNULLstr(argv[6]));
   
   if (datebgn[0]=='*' || datebgn[0] == '\0') 
       strcpy(datebgn,  "80/01/01");
   if (dateend[0]=='*' || dateend[0] == '\0') 
       strcpy(dateend,  "99/12/31");

   strcpy(dbgn1,cm_to_infdate(datebgn));
   strcpy(dend1,cm_to_infdate(dateend));

   printf("dbgn1[%s] dend1[%s]\n",dbgn1,dend1);
   
   $WHENEVER SQLERROR GOTO errexit;
   
   rstrdate( ONLINE_DATE, &online_date);
   rtoday( &today);

   online = today >=online_date ? TRUE:FALSE;

   errfpt = (FILE *) STARTLOG();   

   rc=car9972_get_db();
   if (rc!=M_CM_OK)
        return rc;
    
   rc = getApHome(sApHome);
   if (rc < 0) {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
   }
   
   $CREATE TEMP TABLE CAR9972
   (
      Tiendorse    char(20),
      Tipolicy     char(20),
      TsFedr_class   char(2),
      TsFcard_class  char(2),
      Ticard       char(21),
      Tdendorse    int,
      Ticar_type    char(3),
      Tiissue_ym    char(8),
      Tibrand       char(8),
      Tipro_year    char(5),
      Tdedr_begin   int,
      Tfcomp_class  char(3),
      Tterminate_rsn char(1),
      dcreate  datetime year to fraction(3),
      Tbzfrom       char(2)
   ) WITH NO LOG;
   
   rc=car9972_edr_relation();
   if (rc!=M_CM_OK)
       return rc;
         
   rgetmsg(rc, errlog, sizeof(errlog));
   sprintf_s(strlog, sizeof strlog,"%s\n\t",errlog);

   if( strcmp(option,"1") == 0 )
   {
       rc=car9972_build_comp();
       if( rc!= M_CM_OK )
             strcat(strlog," isch_�j��T�����s�@���� ");
   }
   else if ( strcmp(option,"3") == 0 )
   {
       rc=car9972_build_comp();
       if( rc!= M_CM_OK )
             strcat(strlog," ismh_�j������O���s�@���� ");
   }
   else if ( strcmp(option,"4") == 0 )
   {
       rc=car9972_build_comp();
       if( rc!= M_CM_OK )
             strcat(strlog," ��歫�e���� ");
   }
   else 
   {
       rc=car9972_build_comp();
       if( rc!= M_CM_OK )
             strcat(strlog," ���𰣭��e���� ");
   }

   EWRITE(userid,rc,strlog);
   exit(1);
   
   exit(0);
   
errexit:
    printf("car9972-main:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE; 
}
/*--------------------------------------------------------------------*/

long car9972_edr_relation()
{
   int i;
   $char stmt_buf1[1024],stmt_buf2[1024];
   $char stmt_db[512],stmt_statement[1024];
   
   /* data from edr_relation */
   $char Eipolicy[21],Efcard_class[2],Eicard[21];
   $char Eicar_type[3],Eiissue_ym[6],Eibrand[10],Eipro_year[5],Efcomp_class[3];
   $long Edendorse,Ededr_begin;
   $char Eiendorse[21],EsFedr_class[2],EsFcard_class[2],Eterminate_rsn[2],Ebzfrom[3];
   $long tmp_cnt=0;
   
   for( i= 0;i<count_db;i++)
   {
   	
   	/* if option = 5, it has to join with table [ca_tmp_no] */
       	strcpy(stmt_statement,"");
       	strcpy(stmt_db,"");
        if( strcmp(option,"5") == 0 )
   	{
   		/*sprintf_s(stmt_db, sizeof stmt_db,", %s:ca_tmp_no b",list[i].dbname);*/
   		strcpy(stmt_db,", ca_tmp_no b");
   		strcpy(stmt_statement,"AND a.iendorse = b.ipolicy");
 	}
       /* End of statement */
       
        /***** prepare cursor for select edr_relation *****/
        sprintf_s(stmt_buf1, sizeof stmt_buf1,"SELECT %s %s %s %s FROM %s:%s %s %s %s %s %s %s",
                          "iendorse, a.ipolicy, fedr_class, fcard_class,",
                          "icard, dendorse, icar_type, iissue_ym,",
                          "ibrand, ipro_year,",
                          "dedr_begin, fcomp_class, terminate_rsn, dcreate, bzfrom",
                          list[i].dbname,"edr_relation a",stmt_db,
                          "WHERE dendorse BETWEEN ? AND ?",
                          " AND dedr_close is NOT NULL AND fcard_class = '1'",
                          " AND fedr_class not in ('A','B','3') ",
                          stmt_statement,  
                          " ORDER BY dcreate");      /*���g��H�������T*/

        printf("stmt[%s]\n",stmt_buf1);

        $PREPARE CUR_STMT1 FROM $stmt_buf1;
        $DECLARE scur_edr1 CURSOR FOR CUR_STMT1;
        $OPEN scur_edr1 USING $dbgn1, $dend1;
        
        while(1)
        {
           $FETCH scur_edr1
             INTO $Eiendorse, $Eipolicy, $EsFedr_class, $EsFcard_class,
                  $Eicard, $Edendorse, $Eicar_type,     $Eiissue_ym, 
                  $Eibrand, $Eipro_year, $Ededr_begin,  $Efcomp_class, $Eterminate_rsn, $dcreate , $Ebzfrom;

           if (SQLCODE == SQLNOTFOUND) break;
        
           $INSERT INTO CAR9972
           (
               Tiendorse, Tipolicy,   TsFedr_class, TsFcard_class, Ticard,
               Tdendorse, Ticar_type, Tiissue_ym,   Tibrand,       Tipro_year,
               Tdedr_begin, Tfcomp_class, Tterminate_rsn, dcreate ,Tbzfrom
           )
           VALUES
           (
               $Eiendorse, $Eipolicy, $EsFedr_class, $EsFcard_class,
               $Eicard,  $Edendorse,  $Eicar_type,   $Eiissue_ym,
               $Eibrand, $Eipro_year, $Ededr_begin,  $Efcomp_class, $Eterminate_rsn,
               $dcreate, $Ebzfrom
            );
        } /* end of while */
        $CLOSE scur_edr1;
        $FREE  scur_edr1;
   } /*end of dblist */
   
   return M_CM_OK;      
        
errexit:
    printf("car9972edr_relation:code=%d, msg=%s\n",SQLCODE,sqlca.sqlerrm);
    $DROP TABLE CAR9972;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;     
} /* end of get ori_ply_relation */

long car9972_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);

   return SQLCODE;
}
/* ------------------------------�j���I���--------------------------------------------*/
long car9972_build_comp()
{
   $char Tmp1[20],file0[51],tstmt[1024],stmt_buf2[1024],stmt_buf3[1024];
   $char stmt_buf4[600],stmt_buf5[500],stmt_bufa[500], stmt6[1024];
   $char drate_c[7], sIbrand_new[10], next_iendorse[21],chk_dpolicy[2];
   char  tmp_dbname[20];
   char  day_yy[5],day_mm[3],day_dd[3];
   $date Today;
   $long ldpolicy=0, lchk_date=0;
   long  rtncode;
   int  cond=0,i=0;   
   
   rtoday(&Today);
   
   /* If option = 1,3 loop is only running once; if option = 4, loop is running 2 times */
   if (strcmp(option,"1") == 0 || strcmp(option,"3") == 0) 
   {
   	cond = 2;
   } else {
   	cond = 1;
   }

   sprintf_s(tstmt, sizeof tstmt,"SELECT first 1 itag_last, itag_next FROM ca_change_tag_ori WHERE ipolicy = ? AND iendorse = ?");
   $PREPARE prep1 FROM $tstmt;
   
for (i=cond;i<3;i++)
{ 
   cntrlrec = 0;
   sprintf_s(tstmt, sizeof tstmt,"SELECT * FROM CAR9972");
   
   if( strcmp(option,"1") == 0 || (i == 1))    /* �j��T���O�I��� */
   {
        strcat(tstmt," WHERE TsFcard_class = '1' ");
        strcat(tstmt,"   AND Ticar_type not in ('01','02','32','34','35')");
        strcat(tstmt," ORDER BY dcreate ");
   }
   else if ( strcmp(option,"3") == 0 || (i == 2))  /* �j������O�I��� */ 
   {
        strcat(tstmt," WHERE TsFcard_class = '1' ");
        strcat(tstmt,"   AND (Ticar_type='01' OR Ticar_type='02' OR Ticar_type='32' OR Ticar_type='34' OR Ticar_type='35') ");
        strcat(tstmt," ORDER BY dcreate ");
   }
   else
   {
   	strcat(tstmt," ORDER BY dcreatee");
   }
   
   printf("tstmt[%s]\n",tstmt);
   
   $PREPARE CUR_TSTMT FROM $tstmt;
   $DECLARE scur_car9972 CURSOR FOR CUR_TSTMT;
                      
   $OPEN scur_car9972;
   
   iFetch = True;
   while(1)
   {
       $FETCH scur_car9972
         INTO $iendorse, $ipolicy,   $sFedr_class, $sFcard_class, $icard,
              $dendorse, $icar_type, $iissue_ym,   $ibrand,       $ipro_year,
              $dedr_begin, $fcomp_class, $terminate_rsn, $dcreate ,$bzfrom;

       if (SQLCODE == SQLNOTFOUND) break;

       strcpy(tmp_dbname,get_car_full_db(ipolicy));

       /***** prepare cursor for select endorsement *****/

       sprintf_s(stmt_buf2, sizeof stmt_buf2,"SELECT %s %s %s FROM %s:%s %s",
                 "ilicense,to_char(dbirth,'%Y'), to_char(dbirth,'%m'), to_char(dbirth,'%d'),fsex,fmarriage,qcylinder::int,qpt,fpt,iengine,ibody,",
                 "itag,iassured,nassured,dply_begin,dply_end,",
                 "pdmg_align,pbrg_align,plia_align, iply_area, fassured, to_char(dissue, '%Y'), to_char(dissue, '%m'), (lpad(NVL(qpro_month,0),2,'0'))",
                 tmp_dbname,"endorsement ",
                 "WHERE iendorse=? ");

       $PREPARE CUR_STMT2 FROM $stmt_buf2;
       $DECLARE scur_edr2 CURSOR FOR CUR_STMT2;

       /***** prepare cursor for select edr_ins_type *****/
       sprintf_s(stmt_buf3, sizeof stmt_buf3,"SELECT %s %s FROM %s:%s %s ",
                  "iedr_type,iins_type,medrinj_cover,medrdea_cover,medrdmg_cover,",
                  "mdeduct,medrins_prem,medr_prem,drate_ym",
                  tmp_dbname,"edr_ins_type",
                  "WHERE iendorse=? and iedr_type not in ('79','10')");
       $PREPARE CUR_STMT3 FROM $stmt_buf3;
       $DECLARE scur_edr3 CURSOR FOR CUR_STMT3;

       qpt = 0;

       $OPEN scur_edr2 USING $iendorse;
       $FETCH scur_edr2
         INTO $ilicense, $ibirth_yy, $ibirth_mm, $ibirth_dd, $fsex, $fmarriage, $qcylinder, $qpt:id1, $fpt,
              $iengine, $ibody, $itag, $iassured, $nassured, $dply_begin, $dply_end,
              $ipdmg_align, $ipbrg_align, $iplia_align, $iply_area, $fassured, $iissue_yy, $iissue_mm, $qpro_month_c;

       if (SQLCODE == SQLNOTFOUND)
       {
           $CLOSE scur_edr2;
            continue;
       }
       $CLOSE scur_edr2;
       
       
       rtn = getCompanyId(companyid);
         
       printf(" ************************** companyid[%s]\n",companyid);

       if (iFetch)                 /*�Ĥ@�����W�@���O�ۤv*/
       {
            sDendorse = dendorse;
            iFetch = FALSE;
            prem_total = 0;

            strcpy( endorse_c , cm_cdate_str_100( dendorse ));

            cm_split_ymd_100(endorse_c,day_yy,day_mm,day_dd);

            if( strcmp(option,"1") == 0 )
            {
                sprintf_s(Tmp1, sizeof Tmp1,"isch%s_%s%s%sc",companyid,day_yy,day_mm,day_dd);
                strcpy(iply_type,"ch");
                strcpy(fcard_class, "1");
            }
            else if ( strcmp(option,"3") == 0 )
            {
                sprintf_s(Tmp1, sizeof Tmp1,"ismh%s_%s%s%s",companyid,day_yy,day_mm,day_dd);
                strcpy(iply_type,"mh");
                strcpy(fcard_class, "1");
            }
            else
            {
            	if ( i == 1)
            	{
            		sprintf_s(Tmp1, sizeof Tmp1,"isch%s_%s%s%sc",companyid,day_yy,day_mm,day_dd);
            	} else {
            		sprintf_s(Tmp1, sizeof Tmp1,"ismh%s_%s%s%s",companyid,day_yy,day_mm,day_dd);
            	}
	    }
            sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);

            printf("[NOERROR]file0[%s] Tmp1[%s]\n",file0,Tmp1);
            fptr=fopen(file0,"w");

            
            if (strcmp(option,"4") != 0 || strcmp(option,"5") != 0)
            {
            	rc = check_if_exist(iply_type,dendorse,fcard_class,0);
            	if ( rc != M_CM_OK )
                	return rc;
            }           
       }  /* End of If which is iFetch */

       /* �����ثefile , open a new file*/
       
       if ( sDendorse != dendorse ) 
       {
           if (cntrlrec > 0)
           {
                strcpy(prtstr,"CNTRLREC");
                rfmtlong(cntrlrec,"&&&&&&",cntrlrec_c);
                strcat(prtstr,cntrlrec_c);
                fprintf(fptr, "%s\n", prtstr);
           }

           printf("### cntrlrec=[%s]\n",cntrlrec_c);

           fclose(fptr);

           rtncode = rptftpinsert( userid , "car9972" , Tmp1 );
           
           if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0)
           {
           	$insert into ca_trade_exam
                      	(iply_type,dpolicy,fcard_class,itrans_type,
                       	qcount,mamount,minjure,mcripple,mdeath)
               	values
                   	($iply_type,$sDendorse,$fcard_class,0,
                    	$cntrlrec,$prem_total,0,0,0);
            }

           sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%d",file0,cntrlrec);
           WRITELOG(errfpt , strlog);

           printf("errfpt[%s]\n",strlog);

           strcpy( endorse_c , cm_cdate_str_100( dendorse ));

           cm_split_ymd_100(endorse_c,day_yy,day_mm,day_dd);

           if( strcmp(option,"1") == 0 )
           {
                sprintf_s(Tmp1, sizeof Tmp1,"isch%s_%s%s%sc",companyid,day_yy,day_mm,day_dd);
                strcpy(iply_type,"ch");
                strcpy(fcard_class, "1");
           }
           else if (strcmp(option,"3") == 0)
           {
                sprintf_s(Tmp1, sizeof Tmp1,"ismh17_%s%s%s",day_yy,day_mm,day_dd);
                strcpy(iply_type,"mh");
                strcpy(fcard_class, "1");
           }
           else
           {
           	if ( i == 1)
            	{
            		sprintf_s(Tmp1, sizeof Tmp1,"isch%s_%s%s%sc",companyid,day_yy,day_mm,day_dd);
            	} else {
            		sprintf_s(Tmp1, sizeof Tmp1,"ismh%s_%s%s%s",companyid,day_yy,day_mm,day_dd);
            	}
           }

           sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);

           printf("[002]file0[%s] Tmp1[%s]\n",file0,Tmp1);
           fptr=fopen(file0,"w");

           rc = check_if_exist(iply_type,dendorse,fcard_class,0);
           if ( rc != M_CM_OK )
              return rc;

           cntrlrec = 0;
           prem_total = 0;
       }

       /* car9212111 ���o�O��ñ���dpolicy�A�P�_�ǰe���T�I�إN�� */
       sprintf_s(stmt_bufa, sizeof stmt_bufa,"SELECT dpolicy , CASE WHEN dpolicy < '08/01/2016' THEN 'Y' ELSE 'N' END \
                            FROM %s:ply_relation \
                           WHERE ipolicy = '%s' ",tmp_dbname, ipolicy );

       $PREPARE EXE_STMTa FROM $stmt_bufa;
       $EXECUTE EXE_STMTa INTO $ldpolicy,$chk_dpolicy;
       
       if(strcmp(companyid,"17")==0)
       {
       
           company_flag=ipolicy[7];
           
           printf(" ipolicy[%s]\n",ipolicy);
           printf(" company_flag[%c]\n",company_flag);
           strcpy(CAR_COMPANY_P,"17");
           
           
           if(company_flag > 65 )
           {  
                printf(" *************************************\n");           	
           	$select ipolicy_a
                  into $ipolicy_chg
                  from conv_ipolicy
                 where ipolicy_n = $ipolicy;
                 
                printf(" ****************** ipolicy[%s]\n",ipolicy);                 
                strcpy(CAR_COMPANY_E,"16");
                printf(" ****************** CAR_COMPANY_E[%s]\n",CAR_COMPANY_E);                     
           }
           else
           {
           	strcpy(ipolicy_chg, ipolicy );
           	strcpy(CAR_COMPANY_E,"17"); 
                printf(" ****************** CAR_COMPANY_E[%s]\n",CAR_COMPANY_E);             
           }
       }
       else
       {
            strcpy(ipolicy_chg, ipolicy );
       	    strcpy(CAR_COMPANY_P,"32");
            strcpy(CAR_COMPANY_E,"32");	
       }

       sDendorse = dendorse;

       strcpy(prtstr,"9"); prtstr[1]='\0';                 /*C1:���ʧO*/
       strcat(prtstr, CAR_COMPANY_E);

       if ((iRtnCode = split_policy(ipolicy_chg, sTmpbuf, objno)) != M_CM_OK)
       {
           printf("[%s][%s]\n", iendorse, ipolicy_chg);
           fprintf(errfpt, "[%s][%s]\n", iendorse, ipolicy_chg);
           continue;
       }
       strcat(prtstr, sformat_trade(sTmpbuf, 2, 15));

       rstrdate( "07/14/2003", &lchk_date);

       strcpy(icard, trim(icard));
       strcpy(iendorse, trim(iendorse));
       strcat(prtstr, CAR_COMPANY_P);
       strcat(prtstr, sformat_trade(iendorse, 2, 15));     /*C19-35:��渹�X*/

       /* �N�{��u�a�ϥN�����v���R���N��42�u�x�����v�B�N��63�u�x�n���v�B�N��65�u�������v�C*/

       if( strcmp( iply_area, "42") == 0)
           strcpy( iply_area, "41");
       else if( strcmp( iply_area, "63") == 0)
           strcpy( iply_area, "62");
       else if( strcmp( iply_area, "65") == 0)
           strcpy( iply_area, "64");

       strcat(prtstr, sformat_trade(iply_area, 2, 2));     /*C36-37:�ӫO�a�ϥN��*/

       strcpy(dply_begin_c, cm_cdate_str_100(dply_begin));
       cm_split_ymd_100(dply_begin_c,dply_begin_yy,dply_begin_mm,dply_begin_dd);
       strcpy(tmp_yyyy, itoa(1911+atoi(dply_begin_yy)));

       strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
       strcat(prtstr, sformat_trade(dply_begin_mm, 2, 2));
       strcat(prtstr, sformat_trade(dply_begin_dd, 2, 2)); /*C38-45:�O��_��*/
                                                           
       strcpy(dply_end_c,cm_cdate_str_100(dply_end));
       cm_split_ymd_100(dply_end_c,dply_end_yy,dply_end_mm,dply_end_dd);
       strcpy(tmp_yyyy,itoa(1911+atoi(dply_end_yy)));
       strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
       strcat(prtstr, sformat_trade(dply_end_mm, 2, 2));
       strcat(prtstr, sformat_trade(dply_end_dd, 2, 2));   /*C46-53:�O�樴��*/
                                                           

       if (strlen(trim(objno)) > 0) strcat(prtstr, sformat_trade(objno, 2, 4));
       else strcat(prtstr, "0001");                        /*C54-57:�O��Ъ���*/

/*�o�Ӧ~���Τ�����,��iissue_ym�o������,�諾����original_ply.dissure�����쪺�~��
		strncpy(iissue_yy, iissue_ym, 2);
        iissue_yy[2] = '\0';
        strncpy(iissue_mm, iissue_ym+3, 2);
        iissue_mm[2] = '\0';

        strcpy(tmp_yyyy,itoa(1911+atoi(iissue_yy)));*/

	   strcat(prtstr, sformat_trade(iissue_yy, 2, 4));
       strcat(prtstr, sformat_trade(iissue_mm, 2, 2));     /*C58-63:�o�Ӧ~��*/
                                                          
       strcat(prtstr, sformat_trade(ipro_year, 2, 4));
       strcat(prtstr, sformat_trade(qpro_month_c, 2, 2));  /*C64-69:�s�Ӧ~��*/ /*1120131002_SC1_�j��I��T�@�~���߫O�I��ƶǿ�W�椧�s�y�~����첧�ʮ״���*/

       /* �t�P�����N���ഫ modify by sylvia 100.09.30 (car9812112_C1) ----- */
        sIbrand_new[0] = '\0';
        $select first 1 ibrand_new into $sIbrand_new
           from ca_car_model
          where ibrand = $ibrand
            and ibrand_new <> ' '
          order by drate desc;
        
        if (sIbrand_new[0] != '\0')
            strcpy(ibrand, sIbrand_new);
       /* ----------------------------------------------------------------- */                                                          
       strcat(prtstr, sformat_trade(ibrand, 2, 8));        /*C70-77:  �t���N��*/

       strcat(prtstr, sformat_trade(iengine, 2, 25));      /*C78-102: �������X*/

       strcat(prtstr, sformat_trade(ibody, 2, 25));        /*C103-127:�������X*/
                               
       if (*sFedr_class == '7')    /*** ���P��� ***/
       {
           $EXECUTE prep1 INTO $itag_last, $itag_next USING $ipolicy, $iendorse;
           if( SQLCODE == SQLNOTFOUND)
           {
               /* 1061102009_C1 �ק�ǰe���T27���ؾ��񨮵P�W�h
               if (strcmp(icar_type,"27") == 0 && strcmp(chk_dpolicy,"Y") == 0)
                  strcpy(itag, " "); */                              /* ����27,���P���X�M�� modify by sylvia 101.02.24 (1001005007_C1) */
                  
               strcat(prtstr, sformat_trade(itag, 2, 12)); /*C128-139:�W���P�Ӹ��X*/
               strcat(prtstr, sformat_trade(itag, 2, 12)); /*C140-151:�����P�Ӹ��X*/
           }
           else
           {
               /* 1061102009_C1 �ק�ǰe���T27���ؾ��񨮵P�W�h
               if (strcmp(icar_type,"27") == 0 && strcmp(chk_dpolicy,"Y") == 0)
               {
                  strcpy(itag_last, " ");                               ����27,���P���X�M�� modify by sylvia 101.02.24 (1001005007_C1)
                  strcpy(itag_next, " ");
               }  */ 
               strcat(prtstr, sformat_trade(itag_last, 2, 12));   /*C128-139:�W���P�Ӹ��X*/
               strcat(prtstr, sformat_trade(itag_next, 2, 12));   /*C140-151:�����P�Ӹ��X*/
           }
       }
       else        /* ��L���  */
       {
           /* 1061102009_C1 �ק�ǰe���T27���ؾ��񨮵P�W�h
           if (strcmp(icar_type,"27") == 0 && strcmp(chk_dpolicy,"Y") == 0)
                  strcpy(itag, " ");     */                          /* ����27,���P���X�M�� modify by sylvia 101.02.24 (1001005007_C1) */
                  
           strcat(prtstr, sformat_trade(itag, 2, 12));     /*C128-139:�W���P�Ӹ��X*/
           strcat(prtstr, sformat_trade(itag, 2, 12));     /*C140-151:�����P�Ӹ��X*/
       }
       
       strcat(prtstr, sformat_trade(icar_type, 2, 2));     /*C152-153:���إN��*/
                                                           
       iTmpbuf = 10 * qcylinder;
       strcat(prtstr, sformat_trade(&iTmpbuf, 1, 6));      /*C154-159:�Ʈ�q*/
                                                         
       if (id1 == -1)
       {
            $SELECT MAX(qpassenger)
               INTO $qpt
               FROM ca_car_model
              WHERE ibrand = $ibrand;
       }

       iTmpbuf =  10 * qpt;
       strcat(prtstr, sformat_trade(&iTmpbuf, 1, 4));      /*C160-163:�����ƶq*/
                                                          
       strcat(prtstr, sformat_trade(fpt, 2, 1));           /*C164:    �������*/
                                                          
       strcat(prtstr, sformat_trade(iassured, 2, 10));     /*C165-174:�Q�O�I�H�ѧO�X*/

       sprintf_s(nassured_tmp, sizeof nassured_tmp,"%-200.200s",rtrim(nassured));
       strcat(prtstr, nassured_tmp);                       /*C175-374:�Q�O�I�H�m�W */

       strcat(prtstr, sformat_trade(ibirth_yy, 2, 4));
       strcat(prtstr, sformat_trade(ibirth_mm, 2, 2));
       strcat(prtstr, sformat_trade(ibirth_dd, 2, 2));     /*C375-382:�Q�O�I�H�X�ͦ~���*/
                                                  

       strcat(prtstr, sformat_trade(fsex, 2, 1));          /*C383:    �Q�O�I�H�ʧO*/
       strcat(prtstr, sformat_trade(fmarriage, 2, 1));     /*C384:    �Q�O�I�H�B�çO*/

       if (fassured[0]=='1'){
           strcat(prtstr,"1");
       }  else if(fassured[0]=='2'){
           strcat(prtstr,"3");
       }  else if(fassured[0]=='3'){
           strcat(prtstr,"2");
       }  else if(fassured[0]=='4'){
           strcat(prtstr,"9");
       }  else if(fassured[0]=='5'){
           strcat(prtstr,"8");
       }  else if(fassured[0]=='6'){
           strcat(prtstr,"9");
       } else strcat(prtstr, " ");                         /*C385:    �۵M�H/�k�H�O*/

       iTmpbuf = atoi(fcomp_class);
       strcat(prtstr, sformat_trade(&iTmpbuf, 1, 2));      /*C386-387:�Q�O�I�H����/������l����*/

       strcat(prtstr,"    ");                              /*C388-391:blank*/

       if (strcmp(iins_type, "01")==0 ||
           strcmp(iins_type, "05")==0 ||
           strcmp(iins_type, "08")==0 ||
           strcmp(iins_type, "09")==0 )
       {
           ipdmg_align=ipdmg_align*(-1);
           $SELECT icode INTO $icode FROM alignment
             WHERE fclass='4' AND palign=$ipdmg_align;
           if (SQLCODE==SQLNOTFOUND) strcat(prtstr, "0");
           else strcat(prtstr,icode);                      /*C392:����h�����u��*/
       }
       else
           strcat(prtstr, "0");

       if (strcmp(iins_type, "11")==0)
       {
           ipbrg_align=ipbrg_align*(-1);
           $SELECT icode INTO $icode FROM alignment
             WHERE fclass='4' AND palign=$ipbrg_align;
           if (SQLCODE==SQLNOTFOUND) strcat(prtstr, "0");
           else strcat(prtstr,icode);                      /*C393:�ѵs�h�����u��*/
       } else strcat(prtstr, "0");

       if (strcmp(iins_type, "31")==0 || strcmp(iins_type, "32")==0 ){
           iplia_align=iplia_align*(-1);
           $SELECT icode INTO $icode FROM alignment
             WHERE fclass='4' AND palign=$iplia_align;
           if (SQLCODE==SQLNOTFOUND) strcat(prtstr, "0");
           else strcat(prtstr,icode);                      /*C394:�d���h�����u��*/
       } else strcat(prtstr, "0");

       printf("Fedr_class[%s] iendorse[%s]\n",*sFedr_class,iendorse);

       if (*sFedr_class == '5' || *sFedr_class == '7')    /*** ��r���, or ���P��� ***/
       {
                if ( *sFedr_class == '7')    /*** ���P��� ***/
                    strcat(prtstr, "PR");                         /*C395-396:���ʽ�N��*/
                else
                    strcat(prtstr, "AC"); 
                strcat(prtstr, "21");                             /*C397-398:�O�I�����N��*/

                strcat(prtstr, sformat_trade(" ", 2, 1));         /*C399:    �W��O�B+��-�O��*/
                iTmpbuf = 0;
                strcat(prtstr, sformat_trade(&iTmpbuf, 1, 39));   /*C400-438:�C�@�ӤH�O�I���B(���)-�ۭt�B*/
                strcat(prtstr, sformat_trade(" ", 2, 1));         /*C439:    �[�h�O�O+��-�O��*/
                iTmpbuf = 0;
                strcat(prtstr, sformat_trade(&iTmpbuf, 1, 9));    /*C440-448:�[�h�O�I�O*/

                strcat(prtstr, CAR_COMPANY_E); 
                strcat(prtstr, sformat_trade(icard, 2, 15));      /*C449-465:�j��O�I�Ҹ��X*/

                strcat(prtstr, sformat_trade(" ", 2, 6));         /*C466-471:�O�v��I�~��*/

                strcpy(dendorse_c, cm_cdate_str_100(dedr_begin));
                cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                yy_long = 1911 + atoi(dply_yy);
                strcpy(tmp_yyyy, itoa(yy_long));
                strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
                strcat(prtstr, sformat_trade(dply_mm, 2, 2));
                strcat(prtstr, sformat_trade(tmp_dd, 2, 2));      /*C472-479:���ͮĤ�*/
                                                                  
                strcpy(dendorse_c, cm_cdate_str_100(dendorse));
                cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                yy_long = 1911 + atoi(dply_yy);
                strcpy(tmp_yyyy, itoa(yy_long));
                strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
                strcat(prtstr, sformat_trade(dply_mm, 2, 2));
                strcat(prtstr, sformat_trade(tmp_dd, 2, 2));      /*C480-487:�����*/

                strcat(prtstr, sformat_trade(bzfrom, 2, 2));      /*C488-489:�����*/
                                 
                cntrlrec++;
                fprintf(fptr, "%s\n", prtstr);
       } /* end ��� */
       else    /**** ����r��蠟�~����� ***/
       {
           /*���嶷���e�@�� AC */
           if (*sFedr_class == '9')
           {
                prtstr_9[0]='\0';
                strcpy(prtstr_9, prtstr);

                strcat(prtstr_9, "AC");                             /*C395-396:���ʽ�N��*/
                strcat(prtstr_9, "21");                             /*C397-398:�O�I�����N��*/

                strcat(prtstr_9, sformat_trade(" ", 2, 1));         /*C399:    �W��O�B+��-�O��*/
                iTmpbuf = 0;
                strcat(prtstr_9, sformat_trade(&iTmpbuf, 1, 39));   /*C400-438:�C�@�ӤH�O�I���B(���)-�ۭt�B*/
                strcat(prtstr_9, sformat_trade(" ", 2, 1));         /*C439:    �[�h�O�O+��-�O��*/
                iTmpbuf = 0;
                strcat(prtstr_9, sformat_trade(&iTmpbuf, 1, 9));    /*C440-448:�[�h�O�I�O*/

                strcat(prtstr_9, CAR_COMPANY_E);
                strcat(prtstr_9, sformat_trade(icard, 2, 15));      /*C449-465:�j�����*/

                strcat(prtstr_9, sformat_trade(" ", 2, 6));         /*C466-471:�O�v��I�~��*/

                strcpy(dendorse_c, cm_cdate_str_100(dedr_begin));
                cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                yy_long = 1911 + atoi(dply_yy);
                strcpy(tmp_yyyy, itoa(yy_long));
                strcat(prtstr_9, sformat_trade(tmp_yyyy, 2, 4));
                strcat(prtstr_9, sformat_trade(dply_mm, 2, 2));
                strcat(prtstr_9, sformat_trade(tmp_dd, 2, 2));      /*C472-479:���ͮĤ�*/
                                                                    
                strcpy(dendorse_c, cm_cdate_str_100(dendorse));
                cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                yy_long = 1911 + atoi(dply_yy);
                strcpy(tmp_yyyy, itoa(yy_long));
                strcat(prtstr_9, sformat_trade(tmp_yyyy, 2, 4));
                strcat(prtstr_9, sformat_trade(dply_mm, 2, 2));
                strcat(prtstr_9, sformat_trade(tmp_dd, 2, 2));      /*C480-487:�����*/
  
                strcat(prtstr_9, sformat_trade(bzfrom, 2, 2));      /*C488-489:�����*/
                
                cntrlrec++;
                fprintf(fptr, "%s\n", prtstr_9);
           } /* end ���� */

           /* �P�_�O�_���L�� */
           /* 2:�L�� */
           if (*sFedr_class == '2' || *sFedr_class == '8')
           {
                strcat(prtstr, "05");                               /*C395-396:���ʽ�N��*/
                
                /*sprintf_s(stmt_buf4, sizeof stmt_buf4,"SELECT iins_type FROM %s:ply_ins_type"
                                  " WHERE ipolicy = ? "
                                  "   AND nvl(fedr_status,' ') NOT IN ('1', '2', '3'); ",
                                  tmp_dbname);*/
				sprintf_s(stmt_buf4, sizeof stmt_buf4,"SELECT iins_type FROM %s:ply_ins_type"
                                  " WHERE ipolicy = ? ; ",
                                  tmp_dbname);
                printf("stmt_buf4[%s] ipolicy=[%s]\n",stmt_buf4, ipolicy );

                $PREPARE cus_ins_cur from $stmt_buf4;
                $DECLARE PLY_INS_CUR CURSOR for cus_ins_cur;

                $OPEN PLY_INS_CUR USING $ipolicy;
                while (1)
                {
                  $FETCH PLY_INS_CUR INTO $sTmpInsType;

                  if (SQLCODE == SQLNOTFOUND) break;

                  prtstr[396] = '\0';

                  /* car9602053 ���s�W���N�I�L�����O */
                  if ( *sFedr_class == '8')
                  {
                      strcpy(iins_type_rule," ");
                      $SELECT iins_type_rule
                         INTO $iins_type_rule
                         FROM insurance_type
                        WHERE iins_type = $sTmpInsType;
                      if (strlen(trim(iins_type_rule)) == 0)
                          strcpy(iins_type_rule,iins_type);

                      if((strcmp(fcard_class,"2")==0) && (strcmp(iins_type_rule,"21")==0))
                          strcpy(iins_type_rule,"23");

                      strcpy( sTmpInsType, iins_type_rule);

	              if( strcmp(iins_type_rule,"09") == 0 )
	                  strcpy( sTmpInsType, "07" );
                  }

                  strcat(prtstr, sTmpInsType);                      /*C397-398:�O�I�����N��*/
                  strcat(prtstr, sformat_trade(" ", 2, 1));         /*C399:    �W��O�B+��-�O��*/
                  iTmpbuf = 0;
                  strcat(prtstr, sformat_trade(&iTmpbuf, 1, 39));   /*C400-438:�C�@�ӤH�O�I���B(���)-�ۭt�B*/
                  strcat(prtstr, sformat_trade("+", 2, 1));         /*C439:    �[�h�O�O+��-�O��*/
                  strcat(prtstr, sformat_trade(&iTmpbuf, 1, 9));    /*C440-448:�[�h�O�I�O*/

                  strcat(prtstr, CAR_COMPANY_E);
                  strcat(prtstr, sformat_trade(icard, 2, 15));      /*C449-465:�j�����*/

                  strcat(prtstr, sformat_trade(" ", 2, 6));         /*C466-471:�O�v��I�~��*/

                  strcpy(dendorse_c, cm_cdate_str_100(dedr_begin));
                  cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                  yy_long = 1911 + atoi(dply_yy);
                  strcpy(tmp_yyyy, itoa(yy_long));
                  strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
                  strcat(prtstr, sformat_trade(dply_mm, 2, 2));
                  strcat(prtstr, sformat_trade(tmp_dd, 2, 2));      /*C472-479:���ͮĤ�*/

                  strcpy(dendorse_c, cm_cdate_str_100(dendorse));
                  cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
                  yy_long = 1911 + atoi(dply_yy);
                  strcpy(tmp_yyyy, itoa(yy_long));
                  strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
                  strcat(prtstr, sformat_trade(dply_mm, 2, 2));
                  strcat(prtstr, sformat_trade(tmp_dd, 2, 2));      /*C480-487:�����*/
                                                                 
                  strcat(prtstr, sformat_trade(bzfrom, 2, 2));      /*C488-489:�����*/

                  cntrlrec++;
                  fprintf(fptr, "%s\n", prtstr);
                }
                $CLOSE PLY_INS_CUR;
                $FREE PLY_INS_CUR;
           } /* end �L�� */

           /* car9602053 ���s�W���N�I�L�����O */
           if (*sFedr_class != '2')
           {
	           $OPEN scur_edr3 USING $iendorse;
	           while(1)
	           {
	                $FETCH scur_edr3
	                  INTO $iedr_type, $iins_type, $medrinj_cover, $medrdea_cover,
	                       $medrdmg_cover, $mdeduct, $medrins_prem, $mprem, $drate_ym;
	
	                printf(">>>fetch edr_ins_type,[%d] iedr_type[%s]\n",medrins_prem,iedr_type);
	                printf("iendorse[%s]  prem_total[%d]\n",iendorse, prem_total);
	
	                if (SQLCODE==SQLNOTFOUND)
	                {
	                     $CLOSE scur_edr3;
	                     break;
	                }                
	
	                strcpy(iins_type_rule," ");
	                if (strncmp(iins_type,"21",2) == 0)
	                {
	                     strcpy(iins_type_rule,"21");
	                     /* �B�zdrate */
	                     $SELECT TO_CHAR(drate, '%Y%m') INTO $drate_c
	                        FROM ca_rate_date
	                       WHERE icode=$drate_ym
	                         AND itable='compulsory_premium';
	                         
	                     if (SQLCODE == SQLNOTFOUND || drate_c[0] == '\0')
	                     {
	                          sprintf_s(errmsg, sizeof errmsg,"drate_ym[%s] not found in rate\n",drate_ym);
	                          fprintf(errfpt,"%s\n",errmsg);
	                          continue;
	                     }                                           
	                }
	                else
	                {
	                     $SELECT iins_type_rule
	                        INTO $iins_type_rule
	                        FROM insurance_type
	                       WHERE iins_type = $iins_type;
	                       if (strlen(trim(iins_type_rule)) == 0)
	                       {
	                           strcpy(iins_type_rule,iins_type);
	                       }
	
	                       if((strcmp(fcard_class,"2")==0) && (strcmp(iins_type_rule,"21")==0))
	                       {  strcpy(iins_type_rule,"23");  }
	
	                }
	                /**
	                if( lchk_date > ldpolicy )
	                {
	                     �O��ñ���b92/10/28�H�e�̡A�ǰe�����T�έ��I�إN��
	                     strcpy(iins_type_rule,iins_type);
	                }
	                **/
	                if( strcmp(iins_type_rule,"09") == 0 )
	                {
	                     strcpy( iins_type_rule, "07" );
	                }
	
	                prem_total += medrins_prem;
	
	                prtstr[394] = '\0';
	
	                if (strcmp(iedr_type, "01") == 0 ||    /*���P*/
	                    strcmp(iedr_type, "02") == 0 ||    /*���~�h�O*/
	                    strcmp(iedr_type, "03") == 0 ||    /*�j��h�O*/
	                    strcmp(iedr_type, "60") == 0 )     /*�h���h�O*/
	                {
	                     if (strcmp(iedr_type, "60") == 0)               /*C395-396:���ʽ�N�� */
	                         strcat(prtstr , "02");
	                     else if (strcmp(iedr_type,"01") == 0 || strcmp(iedr_type,"03") == 0)
	                         strcat(prtstr, iedr_type);
	                     else
	                     {
	                     	/* car9810302 */
	                     	/* ���ʽ謰02���~�h�O��,�ݭn�h��terminate_rsn�h�P�_�ݭn�ǰe��ةʽ�����T */
	                     	if (strcmp(terminate_rsn,"1") == 0 || strcmp(terminate_rsn,"9") == 0)
	                     	     strcat(prtstr,"03");
	                     	else if (strcmp(terminate_rsn,"4") == 0)
	                     	     strcat(prtstr,"04");
	                     	else
	                     	     strcat(prtstr,"02");
	                     }

	                     strcat(prtstr, iins_type_rule);                 /*C397-398:�O�I�����N�� */
	                     strcat(prtstr, " ");                            /*C399:    �W��O�B+��-�O��*/
	
	                     iTmpbuf = 0;
	                     strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));
	                     strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));
	                     strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));
	                     strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));
	                     strcat(prtstr, sformat_trade(&iTmpbuf, 1, 7));  /*C400-438:�C�@�ӤH�O�I���B(���)-�ۭt�B*/
	
	                     strcat(prtstr, "-");                            /*C439:    �[�h�O�O+��-�O�� */
	                     rfmtlong(((-1) * medrins_prem), "&&&&&&&&&", medrins_prem_c);
	                     strcat(prtstr, medrins_prem_c);                 /*C440-448:�[�h�O�O*/
	                     
	                     strcat(prtstr, CAR_COMPANY_E);             
	                     strcat(prtstr, sformat_trade(icard, 2, 15));    /*C449-465:�j�����*/
	                     
	                     strcat(prtstr, sformat_trade(" ", 2, 6));       /*C466-471:�O�v��I�~��*/
	
	                }
	                else if (strcmp(iedr_type, "04") == 0 ||    /*�O�B�ܰ�*/
	                         strcmp(iedr_type, "40") == 0 ||    /*�O�O�ܰ�*/
	                         strcmp(iedr_type, "85") == 0 ||    /*�j��ɮt�B*/
	                         strcmp(iedr_type, "76") == 0 ||
	                         strcmp(iedr_type, "78") == 0 ||
	                         strcmp(iedr_type, "75") == 0 )     /* �s�W��2010/04/21 */
	                {
                         strcat(prtstr, "08");                          /*C395-396:���ʽ�N��*/

	                     strcat(prtstr, iins_type_rule);                /*C397-398:�O�I�����N��*/
	
	                     if ((medrinj_cover + medrdea_cover + medrdmg_cover) >= 0)  
	                          strcat(prtstr, "+");
	                     else if ((medrinj_cover + medrdea_cover + medrdmg_cover) < 0)
	                          strcat(prtstr, "-");
	                     else strcat(prtstr, " ");                      /*C399:    �W��O�B+��-�O�� */
	
	                     if (medrinj_cover < 0) medrinj_cover *= -1;
	                     if (medrdea_cover < 0) medrdea_cover *= -1;
	                     if (medrdmg_cover < 0) medrdmg_cover *= -1;
	
	                     rfmtlong(medrinj_cover, "&&&&&&&&", minjured_c);
	                     strcat(prtstr,minjured_c);                     /*C400-407:��˫O�B*/
	                     rfmtlong(medrdea_cover,"&&&&&&&&",mdeath_c);
	                     strcat(prtstr,mdeath_c);                       /*C408-415:�ݼo�O�B*/
	                     rfmtlong(medrdea_cover,"&&&&&&&&",mdeath_c);
	                     strcat(prtstr,mdeath_c);                       /*C416-423:���`�O�B*/
	                     rfmtlong(medrdmg_cover,"&&&&&&&&",mdamage_c);
	                     strcat(prtstr,mdamage_c);                      /*C424-431:�O�B*/
	                     strcat(prtstr, sformat_trade(&iTmpbuf, 1, 7)); /*C432-438:�ۭt�B*/
	
	                     if (medrins_prem >= 0) strcat(prtstr, "+");    /*439:     �[�h�O�O+��-�O��*/
	                     else if (medrins_prem <0) strcat(prtstr, "-");
	                     else strcat(prtstr, " ");
	
	                     if (medrins_prem < 0) medrins_prem *= -1;
	                     rfmtlong(medrins_prem, "&&&&&&&&&", medrins_prem_c);
	                     strcat(prtstr, medrins_prem_c);                /*C440-448:�[�h�O�O*/
	                     
	                     strcat(prtstr, CAR_COMPANY_E);                 /*C449-465:�j�����*/
	                     strcat(prtstr, sformat_trade(icard, 2, 15)); 
	                     strcat(prtstr, sformat_trade(drate_c, 2, 6));  /*C466-471:�O�v��I�~��*/
	                }
	                else if (strcmp(iedr_type, "05") == 0)  /*�[�O�I��*/
	                {                                          
	                     strcat(prtstr, "08");                          /*C395-396:���ʽ�N��*/
	                     
	                     strcat(prtstr, iins_type_rule);                /*C397-398:�O�I�����N��*/
	
	                     strcat(prtstr, " ");                           /*C399:    �W��O�B+��-�O��*/
	                     rfmtlong(medrinj_cover, "&&&&&&&&", minjured_c);
	                     strcat(prtstr,minjured_c);                     /*C400-407:��˫O�B*/
	                     rfmtlong(medrdea_cover,"&&&&&&&&",mdeath_c);
	                     strcat(prtstr,mdeath_c);                       /*C408-415:�ݼo�O�B*/
	                     rfmtlong(medrdea_cover,"&&&&&&&&",mdeath_c);
	                     strcat(prtstr,mdeath_c);                       /*C416-423:���`�O�B*/
	                     rfmtlong(medrdmg_cover,"&&&&&&&&",mdamage_c);
	                     strcat(prtstr, mdamage_c);                     /*C424-431:�O�B*/
	                     strcat(prtstr, sformat_trade(&iTmpbuf, 1, 7)); /*C432-438:�ۭt�B*/
	                     if (medrins_prem >= 0) strcat(prtstr, "+");
	                     else if (medrins_prem <0) strcat(prtstr, "-");
	                     else strcat(prtstr, " ");                      /*439:     �[�h�O�O�O��*/
	                     rfmtlong(medrins_prem, "&&&&&&&&&", medrins_prem_c);
	                     strcat(prtstr, medrins_prem_c);                /*C440-448:�[�h�O�O*/
	                    
	                     strcat(prtstr, CAR_COMPANY_E);                 /*C449-465:�j�����*/
	                     strcat(prtstr, sformat_trade(icard, 2, 15));
	                     strcat(prtstr, sformat_trade(drate_c, 2, 6));  /*C466-471:�O�v��I�~��*/
	                }
	                else if ( strcmp(iedr_type, "20") == 0 ||
	                          strcmp(iedr_type, "77") == 0 )      /*�ۭt�B�ܰ�*/
	                {
	                    strcat(prtstr, "11");                           /*C395-396:���ʽ�N��*/
	
	                    strcat(prtstr, iins_type_rule);                 /*C397-398:�O�I�����N��*/
	
	                    strcat(prtstr, " ");                            /*C399:    �W��O�B+��-�O��*/
	                    iTmpbuf = 0;
	                    strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));  /*C400-407:��˫O�B*/
	                    strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));  /*C408-415:�ݼo�O�B*/
	                    strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));  /*C416-423:���`�O�B*/
	                    strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));  /*C424-431:�O�B*/
	
	                    sprintf_s(stmt_buf5, sizeof stmt_buf5,"SELECT mdeduct, mins_premium"
	                                      "  FROM %s:ply_ins_type_bak"
	                                      " WHERE iendorse = ? AND ipolicy = ? "
	                                      "   AND iins_type = ? ; ",tmp_dbname);
	
	                    $PREPARE CUS_PLY_BAK from $stmt_buf5;
	                    $EXECUTE CUS_PLY_BAK INTO $lTmpMdeduct, $lTmpMins_premium
	                       USING $iendorse, $ipolicy, $iins_type;
	
	                    if (SQLCODE == SQLNOTFOUND) continue;
	
	                    rfmtlong(lTmpMdeduct, "&&&&&&&", mdeduct_c);
	                    strcat(prtstr, mdeduct_c);                      /*C432-438:�ۭt�B*/
	
	                    strcat(prtstr, "-");                            /*439:     �[�h�O�O+��-�O��*/
	                    rfmtlong(lTmpMins_premium, "&&&&&&&&&", medrins_prem_c);
	                    strcat(prtstr, medrins_prem_c);                 /*C440-448:�[�h�O�O*/
	
	                    strcat(prtstr, sformat_trade(" ", 2, 17));      /*C449-465:�j��O�I�Ҹ��X*/
	
	                    strcat(prtstr, sformat_trade(" ", 2, 6));       /*C466-471:�O�v��I�~��*/
	
	                    strcpy(dendorse_c, cm_cdate_str_100(dedr_begin));
	                    cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
	                    yy_long = 1911 + atoi(dply_yy);
	                    strcpy(tmp_yyyy, itoa(yy_long));
	                    strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
	                    strcat(prtstr, sformat_trade(dply_mm, 2, 2));
	                    strcat(prtstr, sformat_trade(tmp_dd, 2, 2));    /*C472-479:���ͮĤ�*/
	                    strcpy(dendorse_c, cm_cdate_str_100(dendorse));
	                    cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
	                    yy_long = 1911 + atoi(dply_yy);
	                    strcpy(tmp_yyyy, itoa(yy_long));
	                    strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
	                    strcat(prtstr, sformat_trade(dply_mm, 2, 2));
	                    strcat(prtstr, sformat_trade(tmp_dd, 2, 2));    /*C480-487:�����*/
	                                                          
	                    strcat(prtstr, sformat_trade(bzfrom, 2, 2));    /*C488-489:�O�o�q���N��*/
	
	                    cntrlrec++;
	                    fprintf(fptr, "%s\n", prtstr);
	
	                    prtstr[394] = '\0';

	                    strcat(prtstr, "12");
	                    strcat(prtstr, iins_type_rule);
	                    strcat(prtstr, " ");
	                    iTmpbuf = 0;
	                    strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));  /*C400-407:��˫O�B*/
	                    strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));  /*C408-415:�ݼo�O�B*/
	                    strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));  /*C416-423:���`�O�B*/
	                    strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));  /*C424-431:�O�B*/
	                    rfmtlong(mdeduct, "&&&&&&&", mdeduct_c);
	                    strcat(prtstr, mdeduct_c);                      /*C432-438:�ۭt�B*/
	                    strcat(prtstr, "+");                            /*439:     �[�h�O�O+��-�O��*/
	                    lTmpMins_premium += medrins_prem;
	                    rfmtlong(lTmpMins_premium, "&&&&&&&&&", medrins_prem_c);
	                    strcat(prtstr, medrins_prem_c);                 /*C440-448:�[�h�O�O*/
	                    strcat(prtstr, sformat_trade(" ", 2, 17));      /*C449-465:�j��O�I�Ҹ��X*/
	                    strcat(prtstr, sformat_trade(" ", 2, 6));       /*C466-471:�O�v��I�~��*/
	                }
	                else if (strcmp(iedr_type, "50") == 0)  /*�_��*/
	                {
	                    strcat(prtstr, "88");                           /*C395-396:���ʽ�N��*/
	
	                    strcat(prtstr, iins_type_rule);                 /*C397-398:�O�I�����N��*/
	
	                    strcat(prtstr, " ");
	
	                    iTmpbuf = 0;
	                    strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));
	                    strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));
	                    strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));
	                    strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));
	                    strcat(prtstr, sformat_trade(&iTmpbuf, 1, 7));
	                    strcat(prtstr, "+");

                            strcpy( next_iendorse, "");
                            sprintf_s(stmt6, sizeof stmt6,"SELECT first 1 iendorse, dcreate"
                                              "  FROM %s:edr_relation"
                                              " WHERE ipolicy = ? and iendorse not like '%%CVP%%' "
                                              "   and dcreate > ? order by dcreate ; ",tmp_dbname);

                            $PREPARE curs1 from $stmt6;
                            $EXECUTE curs1 INTO $next_iendorse, $tmp_dcreate
                               USING $ipolicy, $dcreate;
                            
                            if( SQLCODE == SQLNOTFOUND)
                            {
                                sprintf_s(stmt6, sizeof stmt6,"SELECT mins_premium"
                                                  "  FROM %s:ply_ins_type"
                                                  " WHERE ipolicy = ? "
                                                  "   AND iins_type = ? ; ",tmp_dbname);
                                $PREPARE curs2 from $stmt6;
                                $EXECUTE curs2 INTO $lTmp
                                   USING $ipolicy, $iins_type;
                            }
                            else if( strlen( trim(next_iendorse)) != 0 )
                            {
                                sprintf_s(stmt6, sizeof stmt6,"SELECT mins_premium"
                                                  "  FROM %s:ply_ins_type_bak"
                                                  " WHERE iendorse = ? "
                                                  "   AND iins_type = ? ; ",tmp_dbname);

                                $PREPARE curs3 from $stmt6;
                                $EXECUTE curs3 INTO $lTmp
                                   USING $next_iendorse, $iins_type;
                            }
                            else
                                continue;

                            if( SQLCODE == SQLNOTFOUND)
                                continue;

	                    rfmtlong(lTmp, "&&&&&&&&&", medrins_prem_c);
	                    strcat(prtstr, medrins_prem_c);                 /*C440-448:�[�h�O�O, �_�Ķǰe���O�O*/

	                    strcat(prtstr, CAR_COMPANY_E);                  
	                    strcat(prtstr, sformat_trade(icard, 2, 15));    /*C449-465:�j�����*/
	                    strcat(prtstr, sformat_trade(drate_c, 2, 6));   /*C466-471:�O�v��I�~��*/
	                }
	                else if (strcmp(iedr_type, "79") == 0) /*** ���O�� ***/
	                {
	                	  /* �Y���O���ܰ�(79)�Ϊ̬O��L+�O���ܰ�(75),��h�W�u�eAC,�L�ݦA�e�@��99 */
	                	  /* 2010/04/21,�ȫO���ܰ�(79)�L�ݰe����,��75�]���|�����B�ܰ�,�ҥH
	                	     �N75����W���O�O�ܰʪ����ظ̧אּ�h�e�@��08 */
	                    continue;                                                         
	                }
	                else if(strcmp(iedr_type, "07") == 0)  /**/
	                {
	               	    /* 2010/04/21 �j���I����e07,��e08 */
	                    strcat(prtstr, "08");                           /*C395-396:���ʽ�N��*/
	
	                    strcat(prtstr, iins_type_rule);
	
	                    strcat(prtstr, " ");
	                    iTmpbuf = 0;
	                    strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));
	                    strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));
	                    strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));
	                    strcat(prtstr, sformat_trade(&iTmpbuf, 1, 8));
	                    strcat(prtstr, sformat_trade(&iTmpbuf, 1, 7));
	
	                    if (medrins_prem >= 0) strcat(prtstr, "+");
	                    else if (medrins_prem <0) strcat(prtstr, "-");
	                    else strcat(prtstr, " ");
	
	                    if (medrins_prem < 0) medrins_prem *= -1;
	                    rfmtlong(medrins_prem, "&&&&&&&&&", medrins_prem_c);
	                    strcat(prtstr, medrins_prem_c);                 /*C440-448:�[�h�O�O*/
	
	                    strcat(prtstr, CAR_COMPANY_E);                  /*C449-465:�j�����*/
	                    strcat(prtstr, sformat_trade(icard, 2, 15));
	
	                    strcat(prtstr, sformat_trade(&iTmpbuf, 1, 6));
	                }
	
	                if ( strcmp ( iedr_type , "20" ) == 0 )
	                   printf("len[%d] prtstr[%s]\n",strlen(prtstr),prtstr);
	
	                strcpy(dendorse_c, cm_cdate_str_100(dedr_begin));
	                cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
	                yy_long = 1911 + atoi(dply_yy);
	                strcpy(tmp_yyyy, itoa(yy_long));
	                strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
	                strcat(prtstr, sformat_trade(dply_mm, 2, 2));
	                strcat(prtstr, sformat_trade(tmp_dd, 2, 2));        /*C472-479:���ͮĤ�*/
	                strcpy(dendorse_c, cm_cdate_str_100(dendorse));
	                cm_split_ymd_100(dendorse_c, dply_yy, dply_mm, tmp_dd);
	                yy_long = 1911 + atoi(dply_yy);
	                strcpy(tmp_yyyy, itoa(yy_long));
	                strcat(prtstr, sformat_trade(tmp_yyyy, 2, 4));
	                strcat(prtstr, sformat_trade(dply_mm, 2, 2));
	                strcat(prtstr, sformat_trade(tmp_dd, 2, 2));        /*C480-487:�����*/

	                strcat(prtstr, sformat_trade(bzfrom, 2, 2));        /*C488-489:�O�o�q���N��*/

	                cntrlrec++;
	                fprintf(fptr, "%s\n", prtstr);
	           }   /* End of while which is scur_edr3 */
	           $CLOSE scur_edr3;
	         }  /* �P�_�O�_���L�� */
	       }  /****End of ����r��蠟�~����� ***/
   } /* end of while which is scur_car9972 */
   $CLOSE scur_car9972;
   $FREE  scur_car9972;
   $FREE  prep1;
   
   if (cntrlrec > 0)
   {
        strcpy(prtstr,"CNTRLREC");
        rfmtlong(cntrlrec,"&&&&&&",cntrlrec_c);
        strcat(prtstr,cntrlrec_c);
        fprintf(fptr, "%s\n", prtstr);
   }
   else if ( cntrlrec == 0 )
   {
        rstrdate( dbgn1 , &dendorse );
        
        strcpy( endorse_c , cm_cdate_str_100( dendorse ));
          
        cm_split_ymd_100(endorse_c,day_yy,day_mm,day_dd);
          
        /*printf("endorse_c[%s] day_yy[%s]\n",endorse_c,day_yy);*/
          
        if( strcmp(option,"1") == 0 )
        {
           sprintf_s(Tmp1, sizeof Tmp1,"isch%s_%s%s%sc",companyid,day_yy,day_mm,day_dd);
           strcpy(iply_type,"ch");
           strcpy(fcard_class, "1");
        }
        else if (strcmp(option,"3") == 0) 
        {
           sprintf_s(Tmp1, sizeof Tmp1,"ismh17_%s%s%s",day_yy,day_mm,day_dd);
           strcpy(iply_type,"mh");
           strcpy(fcard_class, "1");
        }
        else
        {
           if ( i == 1)
           {
            	sprintf_s(Tmp1, sizeof Tmp1,"isch%s_%s%s%sc",companyid,day_yy,day_mm,day_dd);
           } else {
            	sprintf_s(Tmp1, sizeof Tmp1,"ismh%s_%s%s%s",companyid,day_yy,day_mm,day_dd);
           }
        }

        sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
   
        printf("[NODATA] file0[%s] Tmp1[%s]\n",file0,Tmp1);
        fptr=fopen(file0,"w");
        
        strcpy(prtstr,"CNTRLREC");
        rfmtlong(0,"&&&&&&",cntrlrec_c);
        strcat(prtstr,cntrlrec_c);
        fprintf(fptr, "%s\n", prtstr);
        
        cntrlrec = prem_total = 0;
   }

   printf("### cntrlrec=[%s]\n",cntrlrec_c);
        
   fclose(fptr);
     
   rtncode = rptftpinsert( userid , "car9972" , Tmp1 );
     
   printf(" ******************************************* \n");

   if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0)
   {
   	$insert into ca_trade_exam
        	(iply_type,dpolicy,fcard_class,itrans_type,
                qcount,mamount,minjure,mcripple,mdeath)
        values
               	($iply_type,$dendorse,$fcard_class,0,
                $cntrlrec,$prem_total,0,0,0);
    }

   sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%d",file0,cntrlrec);
   WRITELOG(errfpt , strlog);
     
   printf("errfpt[%s]\n",strlog);
}     
   if (errfpt!=NULL) ENDLOG(errfpt);
   
   return M_CM_OK;

errexit:
    printf("car9972_build_comp:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    rc = SQLCODE;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return rc;
        
}

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}

long check_if_exist( iply_type, dpolicy, fcard_class, trans_type )
$char *iply_type;
$int dpolicy;
$char *fcard_class;
$int trans_type;
{
   
   $long trade_count, err_count, out_count;
   
   printf("iply_type[%s] dpolicy[%d]\n",iply_type,dpolicy);
   printf("fcard_class[%s] trans_type[%d]\n",fcard_class,trans_type);
   
   
   $SELECT qtradevan, qerr, qout
      INTO $trade_count, $err_count, $out_count
      FROM ca_trade_exam 
     WHERE iply_type = $iply_type
       AND dpolicy = $dpolicy
       AND fcard_class = $fcard_class 
       AND itrans_type = $trans_type;
  
    if ( SQLCODE == SQLNOTFOUND )  return M_CM_OK;      
    
   printf("trade_count[%d] [%d] [%d]\n",trade_count,err_count,out_count);
   
        
   if ( trade_count==0 && err_count==0 && out_count==0 )
   {
       
       $DELETE FROM ca_trade_exam 
         WHERE iply_type = $iply_type
           AND dpolicy = $dpolicy
           AND fcard_class = $fcard_class 
           AND itrans_type = $trans_type;
           
        return M_CM_OK; 
   
   }
   
   strcpy(sqlca.sqlerrm ,"�L�k���J�s�C - �b UNIQUE INDEX ��즳���Э�");
   
   return 239;
   
errexit:
    printf("check_if_exist:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    rc = SQLCODE;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return rc;  
   
}
