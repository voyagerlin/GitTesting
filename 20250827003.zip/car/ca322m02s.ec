
/************************************************/
/*                                              */
/*   PROGRAM : ca322m02s.ec                     */
/*   car320�n�O�ѦC�L                           */
/************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <decimal.h>

#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"

$include sqlca;
$include sqltypes;
$include "ply_ins_cover.h";
$include "var_length.h";

#include "ca301m01.h"
#include "comdata.h"

/*****************************************************************/
#define FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND
#define MAX_ROW  20
#define BLANK  2

struct lin
{
  int no;
  int pos[MAX_ROW];

  char *pp[MAX_ROW];
};

static struct lin ppage[80];

/****** for send/receive data buffer ******/
$static int    idd;
$static int    ide;
$static char   last_ply[20], tagnum[11];
$static char   relative_card[20], card1[20], card2[20], xxcard[20];
$static char   card1_8[20], card2_8[20];
$static char   last_card[20], abn_type[2], assuredi[14], assuredi_ext[3], assuredf[2], cutf[2];
$static char   assuredn[66], user[19], benefi[11], benefn[43], assureda[92],assureda_zip[6];
$static char   tmp_nassured[66], paymenta[92], tel[21],corp[11], ciphersf[2];
$static char   tphone_con[21],imovephone[21];
$static int    ply2_period,  ply1_period;
$static date   ply2_begin, ply2_end, ply1_begin, ply1_end;
$static char   issue_ym[6], pro_ym[8], brandi[9],brandn[13];
$static char   pro_year_min[5], pro_year_max[5];
$static char   car_typei[3], car_typen[11], cartype[3];
$static char   car_type1[3]; /*** �j��� ***/
$static int    cylinder;
$static char   engine[21], body[21], cal_way[2], license[11];
$static char   birth[9], sex[2], marriage[2], acc_align[3], limit[2];
$static int    dmg_align, lia_align, dmg_align_1, lia_align_1;
$static int    brg_align, brg_align_1;
$static char   officer[11], broker[11], cashier[11], examiner[11],entry[11];
$static char   resource[13], big_branch[6], big_office[10], big_sales[11];
$static double car_price;
$static char   equipment[31],ins_type[INSURANCE_TYPE],tmp_pagent[6],tmp_pcommission[6];
$static long   injured_cover, death_cover, damage_cover, deduct; /** 9 bytes **/
$static long   ins_premium, premium, premium1, premium2, premium3 ;
$static long   prem_minus_disc;   /*** ����������O�O ***/
$static char   prem_minus_disc_s[20];
static char    s_equipment[30];

$static char   fdiscount[2];      /*** �������O ***/
$static char   fcomp_24[2];
$static char   kind[2];

/* dale */
$static double pdiscount, pagent     , pcommission;
$static long   mdiscount, magent     , mcommission;
$static long   mdmg_agent, mdmg_commission, mlia_agent, mlia_commission;
$static long   tot_discount;      /*** �X�p(�`)�������B ***/
$static char   tot_discount_s[20];

static  long   rows;                                             /* num. of rows */
$static char   iestimate[20], facf[2], treaty[2], ciphersi[11], comp_frate[2];
$static date   ciphersd, facd;
$static double pdmg_factor_1st,pbrg_factor_1st,pdmg_factor_2nd,pbrg_factor_2nd;
$static double tmp_dmg_1st,tmp_brg_1st,tmp_dmg_2nd,tmp_brg_2nd;
$static double temp_pdmg_factor,temp_pbrg_factor;
$static short  dmg_2nd;
$static char   idmg_rate[3],ibrg_rate[3];
$static char   fcar_class[2],fuse_type[2];
$static char   iarea[3];
$static long   mdmg_prem, mlia_prem;
$static char   dbname_tp[45];
$static char   taipei_db[40];

$static double qpt;
$static char   fpt[2], cal_pro_year[5];
$static double psex_age2, psex_age1;
$static double plia_acc2, plia_acc1, pdmg_acc;

$static char   cal_car_id[3], fdeduct[2], fprint1[2], drate_ym[5];
$static int    car_age, car_age_mth, qcoverage, qserial;
$static long   cal_deduct, mpremium;
$static double short_prate, year_dep, pdepreciate, prate_1, cover_01_tmp;
$static long   cover_01, int_cover_01_tmp, thousand_cover_01;
$static int    PgLine;
$static char   tmp_brand[5];
$static char   icard_first2[3];
$static int    int_yr;
static  char   yr[5],cur_yr[5];

static long    dmg_total;
static int     times_3, outplyf, flag_new, ply1f, ply2f;
static int     iins, ictype, car_tp;
static int     tmp_len, flag_no_rel=0;
static int     int_cur_yr;
static int     int_ply_yr;

static char    *mark="V", *blank=" ", *none="�L";
static long    msg_code;
static char    outputf[21];

$static char   fixIns[12][INSURANCE_TYPE] ={"01","05","11","12","31","32","24","51","53","52","02","55"};
$static char   assureda1[53], assureda2[53];
$static char   assureda_zip_1[2], assureda_zip_2[2],assureda_zip_3[2];

$static char   engine1[16], engine2[16], body1[16], body2[16];
$char tbname[200], tbname56[200];
int   j,people,ins_17;
$char fins_grp[1+1];
$char stmt[1000],ins[INSURANCE_TYPE];

static char  datestr[16], ch1[100], ch2[100],str1[100];
static char  yy[4], mm[3], dd[3];
static char  yy1[4], mm1[3], dd1[3];
static char  yy2[4], mm2[3], dd2[3];
static char  yy3[4], mm3[3], dd3[3];
static char  yy4[4], mm4[3], dd4[3];
static char  yy5[4], mm5[3], dd5[3];
static char  yy6[4], mm6[3], dd6[3];
static char is_yy[4],is_mm[3],s_fpt[10];
static char fcar1[3],fcar2[3];
static char s_period[6],s_cylinder[6],s_qpt[10];
static char by[4],bm[4],bd[4];
static char sex1[2],sex2[2],marriage1[2],marriage2[2];
static char s_psex_age2[10],s_dmg_align[10],s_brg_align[10],s_lia_align[10];
static char s_plia_acc1[5],s_plia_acc2[5],s_pdmg_acc[5];
static char mark01[2],mark05[2],mark09[2],mark88[2],s_car_price[20],mark08[2];
static char damage_cover_01[20],deduct_01[20],ins_premium_01[20];
static char ins_premium_02[20];
static char damage_cover_11[20],deduct_11[20],ins_premium_11[20];
static char deduct_11_tmp[20];
static char ins_premium_17[20];
static char ins_premium_12[20];
static char ins_premium_24[20];
static char damage_cover_25[20],injured_cover_25[20],ins_premium_25[20];
static char damage_cover_31[20],injured_cover_31[20],ins_premium_31[20];
static char damage_cover_32[20],ins_premium_32[20];
static char damage_cover_52[20],injured_cover_52[20],ins_premium_52[20],death_cover_52[20],people_52[6];
static char damage_cover_53[20],injured_cover_52[20],ins_premium_53[20],death_cover_53[20];
static char mark51[3],mark53[3];
static char iins_type_5155[3],injured_cover_53[20],s_ply1_period[6],s_premium1[20];
static char s_premium2[20],out_premium1[20],s_premium3[20],out_premium2[20],out_premium3[20];
$char prn_deduct[20], str_deduct[9];
$char tmp_deduct[20];
$char nins_abbr[30], sTmp[21];
static int ins_no;
static char ins_abbr[10][30],oth_premium[10][20],cover[10][60];
static char oth_deduct[10][20],oth_ins_type[10][INSURANCE_TYPE];

$static long  qday;
$static long  coverage1,coverage2,coverage3;
$static char  sCoverage1[20],sCoverage2[20],sCoverage3[20];
$static char  flag_29_exist[2],flag_31_exist[2],flag_32_exist[2];
$static char  Str29_1[50];
$static char  Str29_2[50];
$static char  Str29_3[50];
$static char  tmpString1[45];
$static char  tmpString2[45];
$static char  tmpString3[45];
$static char  tmpDeduct[3];

static long qdmg_1[3],qlia_1[3];
static long mdmg_1[3],mlia_1[3];
static long qlia_acc_1,qdmg_acc_1;
static double pdmg_acc_1,plia_acc_1;
static long qdmg_2[3],qlia_2[3];
static long mdmg_2[3],mlia_2[3];
static long qlia_acc_2,qdmg_acc_2;
static double pdmg_acc_2,plia_acc_2;
static char inumber[21],fyear1[3],fyear2[3];
$static char nname[41];
$static char iemail[51];
char   rptstr322[10000];
$char  fcomp_class[3];
$char  lia_class[3];
$char  dmg_class[3];
$int   id1 = 0;
$int   dmg_acc_1st,dmg_acc_2nd,dmg_acc_3rd;
char   s_dmg_acc_1st[3],s_dmg_acc_2nd[3],s_dmg_acc_3rd[3];
$char  dexamine[11];
$char  ipolicy1[21];
$char  ipolicy2[21];
$char  ipolicy12[21];
$char  icar_fulldb[3];
$char  dpolicy[11];
$char  transno[21];
$char  iquery_num[15];
$char  iquery_num_c[15];
$char  deduct_30[11];
$double mbus_rule, mbusiness;

int    flag56, flag50;

long ca_query();
void car301_clear();
long ca_get_data();
void ca_put_body();
int risspace();
void put_print();
int get_18_6x_prt_deduct();
int IsFcomp51();
int IsFcomp24();
struct PLY_INS_COVER *move_ply_ins_cover_curr2( );

void car301_clear()
{
     int i;

     printf("in clear\n");
     ins_no=0;
     nins_abbr[0]=0;
     qcoverage=0;
     ins_17=0;
     for(i=0;i<10;i++)
     {
          ins_abbr[i][0]=0;
          oth_premium[i][0]=0;
          cover[i][0]=0;
          oth_deduct[i][0]=0;
          oth_ins_type[i][0]=0;
     }
     yy[0]=0;
     mm[0]=0;
     dd[0]=0;
     yy1[0]=0;
     mm1[0]=0;
     dd1[0]=0;
     yy2[0]=0;
     mm2[0]=0;
     dd2[0]=0;
     yy3[0]=0;
     mm3[0]=0;
     dd3[0]=0;
     yy4[0]=0;
     mm4[0]=0;
     dd4[0]=0;
     is_yy[0]=0;
     is_mm[0]=0;
     s_fpt[0]=0;
     fcar1[0]=0;
     fcar2[0]=0;
     s_period[0]=0;
     s_cylinder[0]=0;
     s_qpt[0]=0;
     fcomp_24[0]='\0';
     s_equipment[0]='\0';
     by[0]=0;
     bm[0]=0;
     bd[0]=0;
     sex1[0]=0;
     sex2[0]=0;
     marriage1[0]=0;
     marriage2[0]=0;
     s_psex_age2[0]=0;
     s_dmg_align[0]=0;
     s_brg_align[0]=0;
     s_lia_align[0]=0;
     s_plia_acc1[0]=0;
     s_plia_acc2[0]=0;
     s_pdmg_acc[0]=0;
     mark01[0]=0;
     mark05[0]=0;
     mark09[0]=0;
     mark08[0]=0;
     s_car_price[0]=0;
     damage_cover_01[0]=0;
     deduct_01[0]=0;
     ins_premium_01[0]=0;
     ins_premium_02[0]=0;
     out_premium1[0]=0;
     out_premium2[0]=0;
     out_premium3[0]=0;
     damage_cover_11[0]=0;
     deduct_11[0]=0;
     deduct_11_tmp[0]=0;
     ins_premium_11[0]=0;
     ins_premium_17[0]=0;
     ins_premium_12[0]=0;
     ins_premium_24[0]=0;
     damage_cover_25[0]=0;
     injured_cover_25[0]=0;
     ins_premium_25[0]=0;
     damage_cover_31[0]=0;
     injured_cover_31[0]=0;
     ins_premium_31[0]=0;
     damage_cover_32[0]=0;
     ins_premium_32[0]=0;
     damage_cover_52[0]=0;
     injured_cover_52[0]=0;
     ins_premium_52[0]=0;
     death_cover_52[0]=0;
     people_52[0]=0;
     benefn[0]='\0';
     iins_type_5155[0]=0;
     damage_cover_53[0]=0;
     injured_cover_53[0]=0;
     ins_premium_53[0]=0;
     death_cover_53[0]=0;
     mark51[0]=0;
     mark53[0]=0;
     s_ply1_period[0]=0;
     s_premium2[0]=0;
     s_premium1[0]=0;
     s_premium3[0]=0;

     fdiscount[0]=0;
     prem_minus_disc = 0;
     pdiscount = 0;
     mdiscount = 0;
     tot_discount = 0;

     qday=0;
     coverage1=0;
     coverage2=0;
     coverage3=0;
     sCoverage1[0]=0;
     sCoverage2[0]=0;
     sCoverage3[0]=0;
     strcpy(flag_29_exist,"N");
     strcpy(flag_31_exist,"N");
     strcpy(flag_32_exist,"N");
     Str29_1[0]=0;
     Str29_2[0]=0;
     Str29_3[0]=0;
     tmpString1[0]=0;
     tmpString2[0]=0;
     tmpString3[0]=0;
     tmpDeduct[0]=0;
     rptstr322[0] = '\0';
}

int risspace(char a[])
{
     int  i;
     int  len;

     len = strlen(a);
     for(i=0;i<len;i++)
     {
           if(a[i] != ' ' && a[i] != '\t') break;
     }

     if(i==len)
     return(0);
     else
     return(1);
}

/*****************************************************************/
int ca_rpt_322(kind,estimatei)
$char estimatei[];
{
    int   rc,i,j,type, other_ins;
    $char nins_type[28+1];
    $char nins_type1[13],nins_type2[13];

    $WHENEVER SQLERROR GOTO errexit;
    rc = getHeadBranch(taipei_db);
    if (rc < 0)
    {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
    }
    strcpy(dbname_tp,get_full_dbname(taipei_db)); /* get TP's full DB name */

    strcpy(iestimate,estimatei);
    printf("****** before into ca_query ******\n");
    printf("****** kind[%s] \n",kind);
    printf("****** iestimate[%s] \n",iestimate);

    car301_clear();

    printf("aft clear\n");
    rc=ca_query(estimatei);
    if(rc!=M_CM_OK)
         return rc;

    printf("aft query\n");
    rc=ca_get_data(iestimate,kind);
    if(rc!=M_CM_OK)
         return rc;

        printf("bef ca_put_body bef equip fcar1[%s]\n",fcar1);
        printf("bef ca_put_body bef equip fcar2[%s]\n",fcar2);
    printf("aft get_data\n");
    ca_put_body(kind);
         return M_CM_OK;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return SQLCODE;
}

/*****************************************************************/
long ca_query(estimatei)
$char estimatei[];
{
    $WHENEVER SQLERROR GOTO errexit;

    msg_code=M_CM_OK;                     /* set default return message code */
    rows=0;
    mdmg_prem=mlia_prem=0;

    if (estimatei[6]=='X') /**** ���`�� ****/
    {
        sprintf_s(stmt, sizeof stmt,
        "SELECT %s %s %s %s %s %s %s %s %s %s %s %s %s %s FROM %s:%s %s ",
        "ilast_ply,ilast_card,irelative_card,ixxcard,iins_card,icomp_card,",
        "qperiod,dbegin,dend,qcomp_period,dcomp_begin,dcomp_end,",
        "fassured,iassured,iassured_ext,nassured,ilicense,ibirth,fsex,fmarriage,",
        "nuser,ibenef,nbenef,aassured,aassured_zip,itel,icorps,apayment,iissue_ym,",
        "ipro_year || '/' || qpro_month::CHAR(3) as ipro_ym,ibrand,icar_type2,qcylinder,iengine,ibody,itag,",
        "mcar_price,nequipment,pdmg_align,pbrg_align,plia_align,iabn_type,",
        "fpass,ipass,dpass,ffac,dfac,itreaty,fcut,ibig_branch,ibig_office,",
        "ibig_sales,iresource,ibroker2,iofficer2,",
        "icashier,iexaminer,ientry,fcal_way,mdali_prem,",
        "mcomp_prem,ipass,dpass,dfac,pdmg_factor,pbrg_factor,qpt,fpt,",
        "psex_age2,psex_age1,plia_acc2,plia_acc1,pdmg_acc,",
        "ncar_abbr,nbrand_abbr,fdiscount,icar_type1,fcomp_24,dmg_acc_1st,dmg_acc_2nd,dmg_acc_3rd, ",
        "dexamine,ipolicy1,ipolicy2,transno,fcomp_class,lia_class,iemail,iquery_num,iquery_num_c, ",
        "mbus_rule, mbusiness ",
        dbname_tp,"abnormal_ply ",
        "WHERE iabnormal=? ");

        printf("ca_query:%s\n",stmt);

        $PREPARE CUR7 FROM $stmt;
        $DECLARE curg CURSOR FOR CUR7;
        $OPEN    curg USING  $estimatei;
        $FETCH   curg
            INTO $last_ply,$last_card,$relative_card,$xxcard,$card2,$card1,
                 $ply2_period:idd,$ply2_begin,$ply2_end,$ply1_period:ide,
                 $ply1_begin,$ply1_end,$assuredf,$assuredi,$assuredi_ext:id1,$assuredn,$license,
                 $birth,$sex,$marriage,$user,$benefi,$benefn,$assureda,$assureda_zip,$tel,$corp,
                 $paymenta,$issue_ym,$pro_ym,$brandi,$car_typei,
                 $cylinder,$engine,$body,$tagnum,$car_price,$equipment,
                 $dmg_align,$brg_align,$lia_align,$abn_type,
                 $ciphersf,$ciphersi,$ciphersd,$facf,$facd,
                 $treaty,$cutf,$big_branch,$big_office,
                 $big_sales,$resource,$broker,$officer,
                 $cashier,$examiner,$entry,$cal_way,$premium2,$premium1,
                 $ciphersi,$ciphersd,$facd,$pdmg_factor_1st,$pbrg_factor_1st,
                 $qpt,$fpt,
                 $psex_age2,$psex_age1,$plia_acc2,$plia_acc1,$pdmg_acc,
                 $car_typen,$brandn,$fdiscount,$car_type1,$fcomp_24,$dmg_acc_1st,$dmg_acc_2nd,$dmg_acc_3rd,
                 $dexamine,$ipolicy1,$ipolicy2,$transno,$fcomp_class,$lia_class,$iemail,
                 $iquery_num,$iquery_num_c, $mbus_rule, $mbusiness;
        if (NOT_FOUND)  return M_CA_NABNORMAL;
        $CLOSE curg;
        if (id1 == -1) strcpy(assuredi_ext," ");

        premium3  =  premium1 + premium2 ;

        sprintf_s(s_plia_acc1, sizeof s_plia_acc1,"%5.1f",plia_acc1);
        sprintf_s(s_plia_acc2, sizeof s_plia_acc2,"%5.1f",plia_acc2);
        sprintf_s(s_pdmg_acc, sizeof s_pdmg_acc,"%5.1f",pdmg_acc);

        strcpy(tmp_nassured,rtrim(assuredn));
        if (*sex == '1')
            strcat(tmp_nassured," ����");
        else if (*sex == '2')
            strcat(tmp_nassured," �p�j");
        if (strlen(trim(user))!=0) {
            strcat(tmp_nassured,"    �ϥΤH:");
            strcat(tmp_nassured,user);
        }
        printf("assuredn--------------->%s",assuredn);

        /*** ���ئW�� ***/
        $SELECT ncode
           INTO $car_typen
           FROM car_type
          WHERE icode = $car_typei
            AND fclass = '1';
        if(SQLCODE == SQLNOTFOUND)  strcpy(car_typen, " ");

        printf("%%%%%%%%%%%% abn_type[%s] user[%s] benefn[%s] qpt[%f] fpt[%s]\n",abn_type,user,benefn,qpt,fpt);
        printf("%%%%%%%%%%%% ciphersf[%s] ciphersi[%s] ciphersd[%s]\n",ciphersf,ciphersi,cm_cdate_str_100(ciphersd));
        printf("%%%%%%%%%%%% facf[%s] facd[%s]\n",facf,cm_cdate_str_100(facd));

        sprintf_s(stmt, sizeof stmt , "SELECT %s FROM %s:%s WHERE %s",
                       "drate_ym",
                       dbname_tp,
                       "abn_ply_ins_type",
                       "iabnormal = ? ");        

        $PREPARE CUR9 FROM $stmt;
        $DECLARE scur_0 CURSOR FOR CUR9;
        $OPEN    scur_0 USING :estimatei;
        printf("stmt[%s]\n",stmt);
        $FETCH   scur_0 INTO $drate_ym;
        if (NOT_FOUND) strcpy(drate_ym,"3");
        $CLOSE scur_0;
    }
    else  /**** ���`�� ****/
    {
        $SELECT icard1,icard2,ilast_ply,ilast_card,irelative_card,ixxcard,
                qply2_period,dply2_begin,dply2_end,
                qply1_period,dply1_begin,dply1_end,
                fassured,iassured,iassured_ext,nassured,ilicense,ibirth,fsex,fmarriage,
                nuser,ibenef,nbenef,aassured,aassured_zip,itel,icorps,apayment,
                iissue_ym,ipro_year || '/' || qpro_month::CHAR(3) as ipro_ym,ibrand,icar_type2,
                qcylinder,iengine,ibody,itag,mcar_price,nequipment,
                pdmg_align,pbrg_align,plia_align,fcut,
                mpremium2,mpremium1,ibig_branch,
                ibig_office,ibig_sales,iresource,ibroker2,iofficer2,icashier,
                iexaminer,ientry,fcal_way,pdmg_factor,pbrg_factor,qpt,fpt,
                psex_age2,psex_age1,plia_acc2,plia_acc1,pdmg_acc,
                ncar_abbr,nbrand_abbr,fdiscount,icar_type1,fcomp_24,dmg_acc_1st,dmg_acc_2nd,dmg_acc_3rd,
                dexamine,ipolicy1,ipolicy2,transno,fcomp_class,lia_class,iemail,iquery_num,iquery_num_c,
                mbus_rule, mbusiness
           INTO $card1,$card2,$last_ply,$last_card,$relative_card,$xxcard,
                $ply2_period:idd,$ply2_begin,$ply2_end,
                $ply1_period:ide,$ply1_begin,$ply1_end,$assuredf,
                $assuredi,$assuredi_ext:id1,$assuredn,$license,$birth,$sex,$marriage,$user,$benefi,
                $benefn,$assureda,$assureda_zip,$tel,$corp,$paymenta,$issue_ym,$pro_ym,$brandi,
                $car_typei,$cylinder,$engine,$body,$tagnum,$car_price,$equipment,
                $dmg_align,$brg_align,$lia_align,$cutf,
                $premium2,$premium1,
                $big_branch,$big_office,$big_sales,$resource,$broker,$officer,
                $cashier,$examiner,$entry,$cal_way,
                $pdmg_factor_1st,$pbrg_factor_1st,$qpt,$fpt, 
                $psex_age2,$psex_age1,$plia_acc2,$plia_acc1,$pdmg_acc,
                $car_typen,$brandn,$fdiscount,$car_type1,$fcomp_24,$dmg_acc_1st,$dmg_acc_2nd,$dmg_acc_3rd,
                $dexamine,$ipolicy1,$ipolicy2,$transno,$fcomp_class,$lia_class,$iemail,$iquery_num,$iquery_num_c,
                $mbus_rule, $mbusiness
           FROM estimate
          WHERE iestimate=$estimatei;
        if (NOT_FOUND)  return M_CA_NESTIMATE;

        if (id1 == -1) strcpy(assuredi_ext," ");
        premium3  =  premium1 + premium2 ;

        sprintf_s(s_plia_acc1, sizeof s_plia_acc1,"%5.1f",plia_acc1);
        sprintf_s(s_plia_acc2, sizeof s_plia_acc2,"%5.1f",plia_acc2);
        sprintf_s(s_pdmg_acc, sizeof s_pdmg_acc,"%5.1f",pdmg_acc);
        sprintf_s(dmg_class, sizeof dmg_class,"%.0f",(double)pdmg_acc/0.2);
        strcpy(tmp_nassured,rtrim(assuredn));

        if (*sex == '1')
            strcat(tmp_nassured," ����");
        else if (*sex == '2')
            strcat(tmp_nassured," �p�j");
        if (strlen(trim(user))!=0) {
            strcat(tmp_nassured,"    �ϥΤH:");
            strcat(tmp_nassured,user);
        }

        printf("assuredn--------------->%s",assuredn);
 
        /*** ���ئW�� ***/
        $SELECT ncode
           INTO $car_typen
           FROM car_type
          WHERE icode = $car_typei
            AND fclass = '1';
        if(SQLCODE == SQLNOTFOUND)  strcpy(car_typen, " ");


        printf("******* after 301-query resource[%s]\n",resource);
        printf("%%%%%%%%%%%% user[%s] benefn[%s]\n",user,benefn);

        $DECLARE scur CURSOR FOR
          SELECT drate_ym
            FROM est_ins_type
           WHERE iestimate = $estimatei;
           $OPEN scur;
          $FETCH scur INTO $drate_ym;
        if (NOT_FOUND) strcpy(drate_ym,'3');
        $CLOSE scur;
    }

    strcpy(s_dmg_acc_1st,itoa(dmg_acc_1st));
    strcpy(s_dmg_acc_2nd,itoa(dmg_acc_2nd));
    strcpy(s_dmg_acc_3rd,itoa(dmg_acc_3rd));

    $SELECT tphone_con, imovephone
       INTO $tphone_con, $imovephone
       FROM cu_customer
      WHERE ifpce_id = $assuredi
        AND ifpce_id_ext = $assuredi_ext;
         if (SQLCODE == SQLNOTFOUND)
         {
            strcpy(tphone_con," ");
            strcpy(imovephone," ");
         }

    printf("ipolicy2 [%s]\n",ipolicy2);
    if (strlen(trim(ipolicy2)) != 0)
    {
       strcpy(ipolicy12,ipolicy2);
    }
    else
    {
       strcpy(ipolicy12,ipolicy1);
    }
    
    printf("bef into ipolicy12\n");
    if (strlen(trim(ipolicy12)) != 0)
    {
       strcpy(icar_fulldb,get_car_full_db(ipolicy12)); 
       printf("icar_fulldb[%s]\n",icar_fulldb);

       sprintf_s(stmt, sizeof stmt,
        " SELECT dpolicy                 "
          " FROM %s:ply_relation         "
          "WHERE ipolicy = '%s' ",icar_fulldb,ipolicy12);
       printf("stmt[%s]\n",stmt);
        $PREPARE get_dpolicy FROM $stmt;
        $EXECUTE get_dpolicy
            INTO $dpolicy;
    }
    else
    {
        strcpy(dpolicy," ");
    }

    printf("End icar_full\n");
    /* 850624-mag */
    strncpy(cur_yr,cm_get_sysd(),4); cur_yr[4]='\0';
    printf("End1 icar_full\n");
    int_cur_yr=atoi(cur_yr);
    printf("End2 icar_full\n");
    memset(cal_pro_year,0,sizeof(cal_pro_year));
    printf("End3 icar_full\n");
    if (atoi(substring(pro_ym,1,4))<int_cur_yr-4)
        strcpy(cal_pro_year,itoa(int_cur_yr-4));
    else
        strcpy(cal_pro_year,substring(pro_ym,1,4));
    cal_pro_year[4]='\0';

    printf("brand[%s],cal_pro_year[%s],drate_ym[%s]\n",
            brandi  , cal_pro_year  ,  drate_ym);

    $SELECT DISTINCT fuse_type,idmg_rate,ibrg_rate
       INTO $fuse_type,$idmg_rate,$ibrg_rate
       FROM ca_car_model
      WHERE ibrand=$brandi
        AND ipro_year=$cal_pro_year
        AND drate=(SELECT drate
                     FROM ca_rate_date
                    WHERE icode=$drate_ym
                      AND itable='ca_car_model');
    if (NOT_FOUND)
    {
          $DECLARE CA_OPT11_MAX CURSOR FOR
            SELECT fuse_type,idmg_rate,ibrg_rate 
              INTO $fuse_type,$idmg_rate,$ibrg_rate 
              FROM ca_car_model
             WHERE ibrand=$brandi  
               AND ipro_year=(SELECT MAX(ipro_year)
                                FROM ca_car_model
                               WHERE ibrand=$brandi  
                                 AND drate=(SELECT drate
                                              FROM ca_rate_date
                                             WHERE icode=$drate_ym
                                               AND itable='ca_car_model'))
               AND drate=(SELECT drate FROM ca_rate_date
                           WHERE icode=$drate_ym AND itable='ca_car_model');
          $OPEN  CA_OPT11_MAX;
          $FETCH CA_OPT11_MAX;
          if (NOT_FOUND) return M_CA_NBRAND;
          $CLOSE CA_OPT11_MAX;
          $FREE  CA_OPT11_MAX;
    }
    printf("######### TEST car_typei[%s] \n", car_typei);

    cal_pro_year[0]='\0';

    if (car_typei[0] != ' ' && car_typei[0] != '\0')
    {
        /*** ���N���� ***/
        $SELECT fcar_class 
           INTO $fcar_class
           FROM car_type
          WHERE fclass = "1"
            AND icode=$car_typei;
        if (NOT_FOUND)  return M_CA_NCARTYPE;
    }
    else
    {
        /*** �j��� ***/
        $SELECT fcar_class
           INTO $fcar_class
           FROM car_type
          WHERE fclass = "1"
            AND icode=$car_type1;
        if (NOT_FOUND)  return M_CA_NCARTYPE;
    }

    return M_CM_OK;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return SQLCODE;
}

/* ***************************** */
long ca_get_data(estimatei,kind)
$char estimatei[];
{
    $char bak[4];
    $char tmp_mins_amt[15], tmp_daily_pay[10], stmt_56[200], tmp_cover[60];
    int   code,car_pricei;
    long  lCode, lPremSum;
    $long  mins_amt, daily_pay;
    char   v_sMsg[512];
    long   rtncode;
    char   sColumn[21], sTable[21], sDbname[21];


    $WHENEVER SQLERROR GOTO errexit;

    printf("car_typei[%s]\n",car_typei);
    printf("fcar_class[%s]\n",fcar_class);

    if (fcar_class[0]=='1')
        strcpy(fcar1,"V");
    else if (fcar_class[0]=='2')
        strcpy(fcar2,"V");

    strncpy(bak,estimatei,2);
    bak[2]=0;

    $SELECT dvp_code
       into $iarea
       from ca_area_code
      where sk_code=$bak;

    strncpy(assureda1,assureda,52);
    assureda1[52]='\0';
    strncpy(assureda2,&assureda[52],38);
    assureda2[38]='\0';
    strncpy(assureda_zip_1,assureda_zip,1);

    assureda_zip_2[0]=assureda_zip[1];
    assureda_zip_3[0]=assureda_zip[2];


    if ((ply2_period!=0) && (idd > 0))
        sprintf_s(s_period, sizeof s_period,"%2d",ply2_period);
    else
        strcpy(s_period," ");
    
    strcpy(datestr,cm_cdate_str_100(ply2_begin));
    cm_split_ymd_100(datestr,yy1,mm1,dd1);
   
    strcpy(datestr,cm_cdate_str_100(ply2_end));
    cm_split_ymd_100(datestr,yy2,mm2,dd2);

    strncpy(is_yy,issue_ym,2);
    strcpy(is_mm,&issue_ym[3]);
    
    sprintf_s(s_cylinder, sizeof s_cylinder, "%4d", cylinder);
   
    if (engine[0] !='\0' && engine[0] !=' ')
    {
       strncpy(engine1,engine,14);
       engine1[14]='\0';
       strncpy(engine2,&engine[14],14);
       engine2[14]='\0';
    }
    else
    {
       strncpy(engine1,body,14);
       engine1[14]='\0';
       strncpy(engine2,&body[14],14);
       engine2[14]='\0';
    }
  
    sprintf_s(s_qpt, sizeof s_qpt, "%5.1f", qpt);
   
    if(fpt[0] == 'P')    
        strcpy(s_fpt, "�H");
    else if(fpt[0] == 'T')   
        strcpy(s_fpt, "��");
    s_fpt[2]=0;

    birth[2] = birth[5] = '\0';
    strcpy(by,birth);
    strcpy(bm,&birth[3]);
    strcpy(bd,&birth[6]);
    
    if (*sex=='1') 
        strcpy(sex1,"V");
    else if (*sex=='2')
        strcpy(sex2,"V");

    if (*marriage=='1') 
        strcpy(marriage1,"V");
    else if (*marriage=='2')
        strcpy(marriage2,"V");
    
    sprintf_s(s_psex_age2, sizeof s_psex_age2, "%6.2f", psex_age2);
    
    sprintf_s(s_dmg_align, sizeof s_dmg_align, "%d", dmg_align);
    
    sprintf_s(s_brg_align, sizeof s_brg_align, "%d", brg_align);
   
    sprintf_s(s_lia_align, sizeof s_lia_align, "%d", lia_align);


    printf("****** into ca_fix ******\n");
    $WHENEVER SQLERROR GOTO errexit;

    if (estimatei[6]=='X')
    {
         sprintf_s(tbname, sizeof tbname,"%s:%s %s",dbname_tp
                ,"abn_ply_ins_type"
                ,"WHERE iabnormal=?");
                
         sprintf_s(tbname56, sizeof tbname56,"%s:%s %s",dbname_tp
                ,"abn_ca_pa_ply"
                ,"WHERE iabnormal=? AND iins_type = '56' AND mins_amt > 0");

        strcpy( sDbname, dbname_tp);
        strcpy( sTable, "abn_ply_ins_cover");
        strcpy( sColumn, "iabnormal");
    }
    else
    {
         sprintf_s(tbname, sizeof tbname,"%s %s"
                 ,"est_ins_type"
                 ,"WHERE iestimate=?");
                 
         sprintf_s(tbname56, sizeof tbname56,"%s %s"
                 ,"ca_pa_est"
                 ,"WHERE iestimate=? AND iins_type = '56' AND mins_amt > 0");

        strcpy( sDbname, "");
        strcpy( sTable, "est_ins_cover");
        strcpy( sColumn, "iestimate");
    }

    strcpy(deduct_30,"");
    sprintf_s(stmt, sizeof stmt,"SELECT %s %s %s FROM %s",
                 "iins_type,minjured_cover,mdeath_cover,",
                 "mdamage_cover,mdeduct,mins_premium,qserial,",
                 "pcommission,pagent,pdiscount,mdiscount,qday,drate_ym",
                 tbname);
    
    sprintf_s(stmt_56, sizeof stmt_56,"SELECT %s FROM %s ",
                    "first 1 mins_amt, daily_pay ",
                    tbname56 );

    IcurrPlyInsCover=IfirstPlyInsCover=IlastPlyInsCover=NULL;    /* set init pointer to NULL */
    #ifdef CA_CONS
        IfirstPlyInsCover = get_ply_ins_cover( sDbname, sTable, sColumn, iestimate, &rtncode, v_sMsg);
        if( rtncode != M_CM_OK)
            return rtncode;
    #endif

    flag56=0;
    flag50=0;
    printf("%s\n",stmt);
    $PREPARE CUR8 FROM $stmt;
    $DECLARE curh CURSOR FOR CUR8;
    $OPEN    curh USING $iestimate;
    for(;;)
    {
        /* strncpy(ins,&fixIns[j],2);
         ins[2]='\0';
        */
        strcpy(ins,&fixIns[j]);
        strcpy(ins, trim(ins));
        
        printf("iestimate[%s]ins[%s]\n",iestimate,fixIns[j]);
        printf("FETCH curh begin");

        $FETCH curh INTO $ins_type , $injured_cover , $death_cover ,
                         $damage_cover , $deduct , $ins_premium , $qserial ,
                         $pcommission , $pagent , $pdiscount , $mdiscount , $qday, $drate_ym;

        if (SQLCODE == SQLNOTFOUND)
            break;

        lPremSum = 0;
        strcpy(ins_type, trim(ins_type));
        
        if (strcmp(ins_type,"30")==0)
        {
           strcpy(deduct_30,itoa(deduct));
        }

        /* �W�B�d���I */
        if (strcmp(ins_type,"29")==0)
        {
            strcpy(flag_29_exist,"Y");

            lCode = lReturnIns29BaseCover(qday,&coverage1,&coverage2,&coverage3);
            rfmtlong(coverage1,"--,---,--&",sCoverage1);
            rfmtlong(coverage2,"--,---,--&",sCoverage2);
            rfmtlong(coverage3,"--,---,--&",sCoverage3);
            deduct = 0;
            qday = 0;
            strcpy(sCoverage1,trim(sCoverage1));
            strcpy(sCoverage2,trim(sCoverage2));
            strcpy(sCoverage3,trim(sCoverage3));
        }

        if (strcmp(ins_type,"31")==0)
        {
            strcpy(flag_31_exist,"Y");
        }

        if (strcmp(ins_type,"32")==0)
        {
            strcpy(flag_32_exist,"Y");
        }

        prn_deduct[0]=0;

        sprintf_s(str_deduct, sizeof str_deduct,"%d", deduct);

        printf("##### COUNT TOT_MDISCOUNT FDISCOUNT[%s]\n",fdiscount);

        if (fdiscount[0] == 'Y')
        {
            printf("COUNT PREM_MINUS_DISC & TOT_DISCOUNT\n");

            /**prem_minus_disc += (ins_premium - mdiscount);**/
            prem_minus_disc += ins_premium;
            tot_discount += mdiscount;
        }

        $SELECT prn_deduct
           INTO $prn_deduct
           FROM ca_dmg_mdeduct
          WHERE icar_type= $car_typei
            AND ideduct  = $str_deduct;

        printf("[%s][%d][%d][%d][%d],drate[%s]\n",ins_type,injured_cover,death_cover,damage_cover,ins_premium,drate_ym);

        if(strcmp(ins_type,"02")==0)
        {
             if(strcmp(kind,"1")==0)
             {
                 printf(" ********************** \n");
                 strcpy(trim(ins_type),"200");
             }                         /* �s�����M�L�n�] default �ҥH��N��@�ӨS�����I�� */
        }

        car_pricei = (int)(car_price * 10000);
        printf("car_pricei,float----> %d\n",car_pricei);
        strcpy(s_car_price,refmtamt(car_pricei,MILLIONTH));


        iins=atoi(ins_type);

        printf("iins[%d]\n",iins);
        switch (iins)
        {
            case 1: case 5: case 9: case 8:
                 if(iins==1)
                   strcpy(mark01,"*");
                 else if(iins==5)
                   strcpy(mark05,"*");
                 else if(iins==9)
                   strcpy(mark09,"*");
                 else
                   strcpy(mark08,"*");
                 car_pricei = (int)car_price * 10000;

                 printf("car_pricei,float----> %d\n",car_pricei);
                 strcpy(s_car_price,refmtamt(car_pricei,MILLIONTH));
                 printf("car_price,string---> %s\n",s_car_price);
                 strcpy(damage_cover_01,refmtamt(damage_cover,MILLIONTH));
                 strcpy(deduct_01,prn_deduct);
                 if( ins_premium_01[0] == 0)
                     strcpy(ins_premium_01,refmtamt(ins_premium,MILLIONTH));
                 break;

            case 2:                                                  /* �ª�02�I��  */
                 strcpy(ins_premium_02,refmtamt(ins_premium,MILLIONTH));
                 break;
            case 11:
                 strcpy(damage_cover_11,refmtamt(damage_cover,MILLIONTH));
                 strcpy(deduct_11,refmtamt(deduct,MILLIONTH));
                 strcpy(ins_premium_11,refmtamt(ins_premium,MILLIONTH));
                 break;

            case 17:
                 ins_17=1;
                 strcpy(ins_premium_17,refmtamt(ins_premium,MILLIONTH));
                 break;

            case 12:
                 strcpy(ins_premium_12,refmtamt(ins_premium,MILLIONTH));
                 break;
       
            case 24:
                 strcpy(ins_premium_24,refmtamt(ins_premium,MILLIONTH));
                 break;

            case 25:
                 strcpy(injured_cover_25,refmtamt(injured_cover,MILLIONTH));
                 strcpy(ins_premium_25,refmtamt(ins_premium,MILLIONTH));
                 strcpy(damage_cover_25,refmtamt(damage_cover,MILLIONTH));
                 break;

            case 31:
                 strcpy(injured_cover_31,refmtamt(injured_cover,MILLIONTH));
                 strcpy(ins_premium_31,refmtamt(ins_premium,MILLIONTH));
                 strcpy(damage_cover_31,refmtamt(damage_cover,MILLIONTH));
                 break;

            case 32:
                 strcpy(damage_cover_32,refmtamt(damage_cover,MILLIONTH));
                 strcpy(ins_premium_32,refmtamt(ins_premium,MILLIONTH));
                 break;

            case 52:
                 strcpy(injured_cover_52,refmtamt(injured_cover,MILLIONTH));
                 strcpy(death_cover_52,refmtamt(death_cover,MILLIONTH));
                 strcpy(ins_premium_52,refmtamt(ins_premium,MILLIONTH));
                 people = (int) (damage_cover / death_cover);
                 sprintf_s(people_52, sizeof people_52,"%d",people);
                 strcpy(damage_cover_52,refmtamt(damage_cover,MILLIONTH));
                 break;

            case 51: case 53: case 55:
                 if((iins == 51) || (iins == 55))
                 {
                     strcpy(mark51,"V");
                     strcpy(iins_type_5155, ins_type);
                 }
                 else if(iins == 53)
                     strcpy(mark53,"V");

                 strcpy(injured_cover_53,refmtamt(injured_cover,MILLIONTH));
                 strcpy(death_cover_53,refmtamt(death_cover,MILLIONTH));
                 strcpy(ins_premium_53,refmtamt(ins_premium,MILLIONTH));
                 strcpy(damage_cover_53,refmtamt(damage_cover,MILLIONTH));
                 break;

            case 21 :
                 break;
            case 10:
                
                 $SELECT nins_type
                    INTO $nins_abbr
                    FROM insurance_type
                   WHERE iins_type = $ins_type;

                 strcpy(oth_ins_type[ins_no],ins_type);
                 strcpy(oth_deduct[ins_no],"�P����l���I");
                 strcpy(ins_abbr[ins_no], nins_abbr );
                 
                 printf("ins_premium=[%d]\n", ins_premium );
                 strcpy(cover[ins_no],"�P����l���I");
                 strcpy(oth_premium[ins_no],refmtamt(ins_premium,MILLIONTH));

                 /* printf("--------- iins_type = 10 ----------\n\n");
                 printf("nins_abbr=[%s]\n" , nins_abbr );
                 printf("ins_abbr=[%s]\n", ins_abbr[ins_no]);
                 printf("==========end===============\n");  */
                 ins_no++;

                 break;
                 
             case 56:
                
                 flag56=1;
                 $SELECT nins_type
                    INTO $nins_abbr
                    FROM insurance_type
                   WHERE iins_type = $ins_type;
                   
                 /** Get mdamage_cover�Bmdeduct**/
                 $PREPARE car322_ins56 FROM $stmt_56;
                 $EXECUTE car322_ins56 INTO $mins_amt, $daily_pay
                    USING $iestimate;

                 strcpy(oth_ins_type[ins_no],ins_type);
                 strcpy(ins_abbr[ins_no], nins_abbr );
                 
                 strcpy(tmp_cover, "�ݼo�Φ��`�O�I��      ");
                 strcpy(tmp_mins_amt,refmtamt(mins_amt,MILLIONTH));
                 strcat(tmp_cover,tmp_mins_amt );
                 strcpy(cover[ins_no], tmp_cover );
                 strcpy(oth_premium[ins_no],refmtamt(ins_premium,MILLIONTH));
                 printf("ins_no=[%d] cover[ins_no]=[%s] tmp_cover=[%s]\n", ins_no, cover[ins_no], tmp_cover);
                 ins_no++;
                 
                 
                 strcpy(oth_ins_type[ins_no],"561");
                 strcpy(ins_abbr[ins_no], " " );
                 
                 strcpy(tmp_cover, "���|�������B               ");
                 strcpy(tmp_daily_pay,refmtamt(daily_pay,MILLIONTH));
                 strcat(tmp_cover,tmp_daily_pay );
                 strcpy(cover[ins_no], tmp_cover );
                 printf("ins_no=[%d] cover[ins_no]=[%s] tmp_cover=[%s]\n", ins_no, cover[ins_no], tmp_cover );
                 
                 strcpy(oth_premium[ins_no]," ");
                 ins_no++;
                 
                 printf("ins_no=[%d] cover[ins_no]=[%s]\n", ins_no-2, cover[ins_no-2]);
                 printf("ins_no=[%d] cover[ins_no]=[%s]\n", ins_no-1, cover[ins_no-1]);
                 
                 
                 break;
                 
             case 50:
                
                 flag50=1;
                 $SELECT nins_type
                    INTO $nins_abbr
                    FROM insurance_type
                   WHERE iins_type = $ins_type;
                   
                 /** Get mdamage_cover�Bmdeduct**/
                 $PREPARE car322_ins56 FROM $stmt_56;
                 $EXECUTE car322_ins56 INTO $mins_amt, $daily_pay
                    USING $iestimate;

                 strcpy(oth_ins_type[ins_no],ins_type);
                 strcpy(ins_abbr[ins_no], nins_abbr );
                 
                 strcpy(tmp_cover, "�ݼo�Φ��`�O�I��      ");
                 strcpy(tmp_mins_amt,refmtamt(death_cover,MILLIONTH));
                 strcat(tmp_cover,tmp_mins_amt );
                 strcpy(cover[ins_no], tmp_cover );
                 strcpy(oth_premium[ins_no],refmtamt(ins_premium,MILLIONTH));
                 printf("ins_no=[%d] cover[ins_no]=[%s] tmp_cover=[%s]\n", ins_no, cover[ins_no], tmp_cover);
                 ins_no++;
                 
                 
                 strcpy(oth_ins_type[ins_no],"501");
                 strcpy(ins_abbr[ins_no], "��@�T����q�ƬG");
                 
                 strcpy(tmp_cover, "�ˮ`�����O�I��               ");
                 strcpy(tmp_daily_pay,refmtamt(injured_cover,MILLIONTH));
                 strcat(tmp_cover,tmp_daily_pay );
                 strcpy(cover[ins_no], tmp_cover );
                 printf("ins_no=[%d] cover[ins_no]=[%s] tmp_cover=[%s]\n", ins_no, cover[ins_no], tmp_cover );
                 
                 strcpy(oth_premium[ins_no]," ");
                 ins_no++;
                 
                 printf("ins_no=[%d] cover[ins_no]=[%s]\n", ins_no-2, cover[ins_no-2]);
                 printf("ins_no=[%d] cover[ins_no]=[%s]\n", ins_no-1, cover[ins_no-1]);
                 
                 
                 break;
                 
            default:
                 qcoverage=0;

                 if(iins == 200 )
                 {  strcpy(ins_type,"02"); }

                 $SELECT nins_type, qcoverage
                    INTO $nins_abbr, $qcoverage
                    FROM insurance_type
                   WHERE iins_type = $ins_type;

                 strcpy(oth_ins_type[ins_no],ins_type);

                 strcpy(tmp_deduct,itoa(deduct));
                 if (get_18_6x_prt_deduct(ins_type,tmp_deduct) == 1)
                 {
                    strcpy(oth_deduct[ins_no],tmp_deduct);
                 }
                 else
                 {
                    if (deduct > 0)
                        strcpy(oth_deduct[ins_no],prn_deduct);
                    else if (deduct == 0)
                        strcpy(oth_deduct[ins_no],"�L");
                 }

                 if ((strcmp(trim(ins_type),"30") == 0) && (tmp_deduct[0] == '3'))
                 {
                    strcpy(nins_abbr,"�ĤT�H�d���I�W�B�d�����[����");
                 }
                 if (strcmp(trim(ins_type),"30") == 0)
                     strcpy(oth_deduct[ins_no],"�L");

                 strcpy(ins_abbr[ins_no],nins_abbr);
              
                 if( IfirstPlyInsCover != NULL)
                 {
                     /* CA_CONS */
                     if ( strcmp(trim(ins_type),"34") == 0)
                     {
                         IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "001");
                         strcpy( tmp_cover, trim(IcurrPlyInsCover->cover_name));
                         strcat( tmp_cover, refmtamt(IcurrPlyInsCover->mcover));
                         strcpy( oth_premium[ins_no], ""); /* �Ĥ@�椣�L�O�O */
                         lPremSum += IcurrPlyInsCover->mcover_prem; 
                         IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "002");
                         strcat( tmp_cover, trim(IcurrPlyInsCover->cover_name));
                         strcat( tmp_cover, refmtamt(IcurrPlyInsCover->mcover));
                         lPremSum += IcurrPlyInsCover->mcover_prem; 
                         strcpy(cover[ins_no], tmp_cover);
printf("1:tmp_cover[%s]\n", tmp_cover);
printf("1:cover[%s]\n", cover[ins_no]);
                         ins_no++;


                         strcpy(oth_ins_type[ins_no],"341");
                         strcpy(ins_abbr[ins_no], " " );

                         IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "003");
                         strcpy( tmp_cover, trim(IcurrPlyInsCover->cover_name));
                         strcat( tmp_cover, refmtamt(IcurrPlyInsCover->mcover));
                         lPremSum += IcurrPlyInsCover->mcover_prem; 
                         strcpy(oth_premium[ins_no],refmtamt(lPremSum,MILLIONTH));/* �L�X���I�ؤ��P�O�B�X�p���O�O */
                         IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "004");
                         strcat( tmp_cover, trim(IcurrPlyInsCover->cover_name));
                         strcat( tmp_cover, refmtamt(IcurrPlyInsCover->mcover));
                         strcpy(cover[ins_no], tmp_cover);
printf("2:tmp_cover[%s]\n", tmp_cover);
printf("2:cover[%s]\n", cover[ins_no]);
                         ins_no++;

                         break;
                     }
                 }

                 strcpy(oth_premium[ins_no],refmtamt(ins_premium,MILLIONTH));
                 for(j=0;j<qcoverage;j++)
                 {
                    if(j==0)
                        strcpy(cover[ins_no],refmtamt(damage_cover, MILLIONTH));
                    else if(j==1)
                        strcpy(cover[ins_no],refmtamt(injured_cover, MILLIONTH));
                    else
                        strcpy(cover[ins_no],refmtamt(death_cover, MILLIONTH));
                    printf("cover[%d]=[%s]\n", ins_no, cover[ins_no]);
                    ins_no++;
                 }
                 break;
        }
    }
    $CLOSE curh;

    if (flag56 || flag50) {
       if (ins_no < 6) {
          strcpy(oth_ins_type[ins_no]," * "); 
          strcpy(ins_abbr[ins_no],"��O�T���r�p�H�ˮ`�I");
          strcpy(cover[ins_no],"��,�ФĿ�O:�r�p�H�P�Q�O�I�H");
          strcpy(oth_deduct[ins_no],"���_:�ж�g�m�W");
          strcpy(oth_premium[ins_no]," ");
          ins_no++;
          strcpy(oth_ins_type[ins_no]," * "); 
          strcpy(ins_abbr[ins_no],"�����Ҹ�");
          strcpy(cover[ins_no],"�X�ͤ��               ���q�H");
          strcpy(oth_deduct[ins_no],"         ���Y");
          strcpy(oth_premium[ins_no]," ");
          ins_no++;
       }
    }
          
    strcpy(datestr,cm_cdate_str_100(ply1_begin));
    cm_split_ymd_100(datestr,yy3,mm3,dd3);

    strcpy(datestr,cm_cdate_str_100(ply1_end));
    cm_split_ymd_100(datestr,yy4,mm4,dd4);

    strcpy(datestr,cm_cdate_str_100(ply1_begin));
    cm_split_ymd_100(datestr,yy5,mm5,dd5);

    strcpy(datestr,cm_cdate_str_100(ply1_end));
    cm_split_ymd_100(datestr,yy6,mm6,dd6);

    if ((ply1_period!=0) && (ide > 0))
         sprintf_s(s_ply1_period, sizeof s_ply1_period,"%2d",ply1_period);
    else
         strcpy(s_ply1_period," ");

    sprintf_s(s_premium2, sizeof s_premium2,"%9.ld",premium2);
    sprintf_s(s_premium1, sizeof s_premium1,"%9.ld",premium1);
    sprintf_s(s_premium3, sizeof s_premium3,"%9.ld",premium3);

    /*�q�H�ߴګY��*/

    if(tagnum[0]==' ' || tagnum[0]=='\0') strcpy(inumber,engine);
        else strcpy(inumber,tagnum);
 
    printf("ca_acc-->inumber[%s]\n",trim(inumber));

    code=ca_accident_record(taipei_db,inumber,ply2_begin,"2",
                            qdmg_2,qlia_2,mdmg_2,mlia_2,&qdmg_acc_2,&qlia_acc_2,
                            &pdmg_acc_2,&plia_acc_2,fyear2,drate_ym);
    if(code!=M_CM_OK) return code;

    if (isalpha(card2[0]))
    {
           $SELECT nname
              INTO $nname
              FROM ca_big_office
             WHERE ibig_comp=$card2[0]
               AND ibig_office='000000000';
           if (SQLCODE != 0) nname[0]='\0';
    }
    else
    {
           nname[0]='\0';
    }

return M_CM_OK;
    errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return SQLCODE;
}

/*****************************************************************/

void ca_put_body(kind)
{
    int i,j,n;
    char qdmg_2_1[3],qlia_2_1[3];
    char qdmg_2_2[3],qlia_2_2[3];
    char qdmg_2_3[3],qlia_2_3[3];
    char qlia_acc_2_str[4],qdmg_acc_2_str[4];
    char pdmg_acc_2_str[5],plia_acc_2_str[5];
    char type_01[3],nme_01[7];
    char ch1[5];
    char newpage[4];
    char i_equipment[2];
    long  lTmp;
    double rTmp;

    {   /* �ǳƦC�L */

        printf("ca_put_body bef equip fcar1[%s]\n",fcar1);
        printf("ca_put_body bef equip fcar2[%s]\n",fcar2);


/**********************************************************************
        printf(" equipment[%s]\n",equipment);
        for(i=0;i<=29;i++)
        {
            if(strncmp(equipment + i,"0",1)!=0)
             {
                n = i+1;
                strcpy(i_equipment,itoa(n));
                printf("i_equipment[%s]\n",i_equipment);
                strcat(s_equipment,i_equipment);
                strcat(s_equipment," ");
                printf(" s_equipment[%s]\n",s_equipment);
             }
        }
*************************************************************************/
        strcpy(s_equipment,equip_get(equipment));
        printf("bef get s_equipment[%s]\n",s_equipment);
        for(i=0;i<strlen(s_equipment);i++)
        {
           if (s_equipment[i] == ',')
           {
               s_equipment[i] = ' ';
           }
        }

        put_print(s_equipment);            /* 1.�S�����O   */
        put_print(corp);                   /* 2.¾�ΥN��   */
        put_print(iarea);                  /* 3.�ӫO�a��   */
        put_print(fcar1);                  /* 4.�ۥΨ����O */
        put_print(fcar2);                  /* 5.��~�����O */

        put_print(iestimate);              /* 6.�պ⸹�X   */
        put_print(tel);                    /* 7.�q��(��)   */
        put_print(tphone_con);             /* 8.�q��(�])   */
        put_print(imovephone);             /* 9.��ʹq��   */

        put_print(tmp_nassured);           /* 10.�Q�O�I�H  */

        put_print(assureda_zip_1);         /* 11.�l�ϸ��X1 */
        put_print(assureda_zip_2);         /* 12.�l�ϸ��X2 */
        put_print(assureda_zip_3);         /* 13.�l�ϸ��X3 */
        put_print(assureda1);              /* 14.�a   */

        put_print(yy1);                    /* 15.�O�I�_���~*/
        put_print(mm1);                    /* 16.�O�I�_����*/
        put_print(dd1);                    /* 17.�O�I�_����*/

        if (risspace(benefn) != 0)         /* 18.����v�H  */
            put_print("V ");
        else
            put_print(" ");

        put_print(yy2);                    /* 19.�O�I�����~*/
        put_print(mm2);                    /* 20.�O�I������*/
        put_print(dd2);                    /* 21.�O�I������*/

        put_print(benefn);                 /* 22.����v�H  */

        put_print(is_yy);                  /* 23.�o�Ӧ~    */
        put_print(pro_ym);                 /* 24.�s�y�~��  */
        put_print(brandi);                 /* 25.�t�P�����N��*/
        put_print(car_typei);              /* 26.���������N��*/
        put_print(s_cylinder);             /* 27.�Ʈ�q      */
        put_print(s_qpt);                  /* 28.�Ӹ��H��    */

        put_print(is_mm);                  /* 29.�o�Ӥ�      */
        put_print(brandn);                 /* 30.�t�P��������*/
        put_print(car_typen);              /* 31.������������*/
      
        put_print(engine1);                /* 32.�������X    */
        put_print(tagnum);                 /* 33.�P�Ӹ��X    */
        put_print(s_fpt);                  /* 34.�Ӹ��H�Ƴ��*/

        if (*sex != '1' && *sex != '2')
        {
           put_print(" ");                 /* 35.���y*/
           put_print(" ");                 /* 36.���y*/
        }
        else if (isalpha(assuredi[0]) == 0 )
        {
             put_print(" ");               /* 35.����*/
             put_print("V");               /* 36.�~��*/
        }
        else
        {
             put_print("V");               /* 35.����*/
             put_print(" ");               /* 36.�~�y*/
        }

        put_print(assuredi);                /* 37.������*/
        put_print(by);                     /* 38.�X�ͦ~*/
        put_print(bm);                     /* 39.�X�ͤ�*/
        put_print(bd);                     /* 40.�X�ͤ�*/
        put_print(marriage1);              /* 41.�w�B*/
        put_print(marriage2);              /* 42.���B*/
        put_print(sex1);                   /* 43.�k��*/
        put_print(sex2);                   /* 44.�k��*/

        put_print(idmg_rate);              /* 45.����O�v�N��*/
        put_print(ibrg_rate);              /* 46.�ѵs�O�v�N��*/
        put_print(s_psex_age2);            /* 47.�~�֩ʧO�Y��*/
        put_print(s_dmg_align);            /* 48.�h���u�ݥN��-����*/
        put_print(s_brg_align);            /* 49.�h���u�ݥN��-�ѵs*/
        put_print(s_lia_align);            /* 50.�h���u�ݥN��-�d��*/

        if(mark01[0] ==      '*' )
        {
               strcpy(type_01,"01");
               strcpy(nme_01,"�Ҧ�");
        }
        else if (mark05[0] ==      '*' )
        {
               strcpy(type_01,"05");
               strcpy(nme_01,"�A��");
        }
        else  if (mark09[0] ==      '*')
        {
               strcpy(type_01,"09");
               strcpy(nme_01,"���郞");
        }
        else  if (mark08[0] ==      '*')
        {
               strcpy(type_01,"08");
               strcpy(nme_01,"�I���I");
        }
        else
        {
               type_01[0] = '\0';
               nme_01[0]  = '\0';
        }

        put_print(type_01);           /* 51.���l�N�� */
        put_print(nme_01) ;           /* 52.���l�W�� */
        put_print(damage_cover_01);   /* 53.���l�O�B */
        put_print(deduct_01);         /* 54.���l�ۭt�B*/
        put_print(ins_premium_01);    /* 55.���l�O�O */

        put_print(s_car_price);       /* 56.�ѵs����*/
        put_print(damage_cover_11);   /* 57.�ѵs�O�B*/

        if (strcmp(trim(deduct_11),"10")==0 || strcmp(trim(deduct_11),"20")==0)
        {
            strcpy(deduct_11_tmp , trim(deduct_11));
            strcat(deduct_11_tmp , "%");
            printf("\ndeduct_11_tmp[%s]\n",deduct_11_tmp);
            put_print(deduct_11_tmp);      /* 58.�ѵs�ۭt�B*/
        }
        else
        {
            put_print(deduct_11);          /* 58.�ѵs�ۭt�B*/
        }

        put_print(ins_premium_11);         /* 59.�ѵs�O�O */

        if (ins_17)
        {
            put_print("17"          );     /* 60.�ѧK���I��*/
            put_print("�ѵs�I�K����");     /* 61.�ѧK��W��*/
            put_print(ins_premium_17);     /* 62.�ѧK��O�O*/
        }
        else
        {
            put_print(" ");
            put_print(" ");
            put_print(" ");
        }

        if (strcmp(flag_29_exist,"Y")==0 &&
            strcmp(flag_31_exist,"N")==0 &&
            strcmp(flag_32_exist,"N")==0)
        {

             put_print("1");               /* 63. 29�I�ص��O */

             strcpy (Str29_1,"***�������ĤT�H�d���I�w�t���O�A�O�I���B");
             sprintf_s(Str29_2, sizeof Str29_2,"   ���C�@�H�ˮ`NT$%s;�C�@�ƬG�ˮ`",sCoverage1);
             sprintf_s(Str29_3, sizeof Str29_3,"   NT$%s;�C�@�ƬG�]�lNT$%s�C",sCoverage2,sCoverage3);

             put_print(Str29_1);           /* 64.�ĤT�H�d���I���  */
             put_print(Str29_2);           /* 65.�ĤT�H�d���I�ƬG  */
             put_print(Str29_3);           /* 66.�ĤT�H�d���I�]�l  */
 
             put_print(" ");               /* 67.  */
             put_print(" ");               /* 68.  */
             put_print(" ");               /* 69.  */
             put_print(" ");               /* 70.  */
        }
        else
        {
             put_print("2");               /* 63. 31�I�ص��O */
             put_print(injured_cover_31);  /* 64.�ĤT�H�d���I���  */
             put_print(damage_cover_31);   /* 65.�ĤT�H�d���I�ƬG  */
             put_print(tmpDeduct);         /* 66.�ĤT�H�d���I�ۭt�B  */
             put_print(ins_premium_31);    /* 67.�ĤT�H�d���I�O�O  */


             put_print(damage_cover_32);   /* 68.�ĤT�H�d���I�]�l�O�B */
             put_print(tmpDeduct);         /* 69.�ĤT�H�d���I�ۭt�B   */
             put_print(ins_premium_32);    /* 70.�ĤT�H�d���I�O�O     */
        }

        /*******************************************************************************
        if(strcmp(trim(kind),"2")==0)                             �ª�
        {
             rgu_put_body(BLANK);
             put_print(30,ins_premium_12,2);                      �s���I
             rgu_put_body(30);
             rgu_put_body(BLANK);

             if (strcmp(trim(fcomp_24),"Y")==0)                   ���s�I
             {
                 put_print(32,"(�[�j)",2);
             }
             else
             {
                 put_print(32," ",2);
             }
             put_print(32,ins_premium_24,2);
             rgu_put_body(32);
             rgu_put_body(BLANK);
             put_print(33,injured_cover_25,2);
             rgu_put_body(33);
             put_print(34,damage_cover_25,2);
             put_print(34,ins_premium_25,2);
             rgu_put_body(34);
        }
        ***************************************************************************/
        /* �s��  */
        {
            if (strcmp(trim(fcomp_24),"Y")==0)
            {
                put_print("(�[�j)");       /* 71.�[�j���O */
            }
            else
            {
                put_print(" ");
            }
            put_print(ins_premium_24);     /* 72.���s�I�O�O */

            put_print(ins_premium_12);     /* 73.�s���I�O�O */
        }

        put_print(mark51);                 /* 74.�����I�I�ص��O   */
        put_print(injured_cover_53);       /* 75.�C�@�H��˫O�B   */
        put_print(death_cover_53);         /* 76.�C�@�H���`�O�B   */

        put_print(mark53);                 /* 77.�ȫ��I�I�ص��O   */
        put_print(damage_cover_53);        /* 78.�C�@�ƬG�O�B     */
        put_print(ins_premium_53);         /* 79.�����I�O�O       */

        put_print(injured_cover_52);       /* 80.���D�d���I�C�@�H���    */
        put_print(death_cover_52);         /* 81.���D�d���I�C�@�H���`    */
        put_print(damage_cover_52);        /* 82.���D�d���I�C�@�ƬG      */
        put_print(ins_premium_52);         /* 83.���D�d���I�O�O          */

        /**********************************************   �ª�
        if(strcmp(kind,"2")==0)
        {
            put_print(42,ins_premium_02,2);
            rgu_put_body(42);
            rgu_put_body(BLANK);
        }
        ***********************************************/

        if(strcmp(kind,"1")==0) /* �s�� */
        {
            for(i=0;i<7;i++)
            {
                put_print(oth_ins_type[i]); /* 84.89.94.99. 104.109.114  ��L�I�إN��    */
                put_print(ins_abbr[i]);     /* 85.90.95.100.105.110.115  ��L�I�ئW��    */
                put_print(cover[i]);        /* 86.91.96.101.106.111.116  ��L�I�ثO�B    */
                put_print(oth_deduct[i]);   /* 87.92.97.102.107.112.117  ��L�I�ئۭt�B  */
                put_print(oth_premium[i]);  /* 88.93.98.103.108.113.118  ��L�I�ثO�O    */
            }
        }

        /******************************************************
        else   �ª�
        {
            for(i=0;i<2;i++)
            {
                put_print(43+i,oth_ins_type[i],1);   43 - 44
                put_print(43+i,ins_abbr[i],1);
                put_print(43+i,cover[i],2);
                put_print(43+i,oth_deduct[i],2);
                put_print(43+i,oth_premium[i],2);
                rgu_put_body(43+i);
            }
        }
        ********************************************************/

        /*** ���������O�������Χ������B�j��0�~�o�C�����r�ˤΧ������B ***/
        printf("\n##### fdiscount[%s] , prem_minus_disc[%ld] , tot_discount[%ld]\n",
                        fdiscount     , prem_minus_disc      , tot_discount);

        put_print(" ");               /* 119. */
        put_print(" ");               /* 120. */
        put_print(" ");               /* 121. */
        put_print(" ");               /* 122. */

        /*** �j���I�O�O�B���N�I�O�O�B�`�O�O ***/
        /***************************************************
        strcpy(out_premium1,refmtamt(s_premium1,MILLIONTH));
        strcpy(out_premium2,refmtamt(s_premium2,MILLIONTH));
        strcpy(out_premium3,refmtamt(s_premium3,MILLIONTH));
        put_print(46,s_premium1,2); 
        put_print(46,s_premium2,2);
        put_print(46,s_premium3,2);
        rgu_put_body(46);
        ***************************************************/
        
        strcpy(out_premium1,refmtamt(premium1,MILLIONTH));
        strcpy(out_premium2,refmtamt(premium2,MILLIONTH));
        strcpy(out_premium3,refmtamt(premium3,MILLIONTH));
        put_print(out_premium1);           /* 123.�j���I�O�O     */
        put_print(out_premium2);           /* 124.���N�I�O�O     */
        put_print(out_premium3);           /* 125.�`�O�O         */

        put_print(yy5);                    /* 126.�j��O�I�_���~ */
        put_print(mm5);                    /* 127.�j��O�I�_���� */
        put_print(dd5);                    /* 128.�j��O�I�_���� */

        put_print(yy6);                    /* 129.�j��O�I�����~ */
        put_print(mm6);                    /* 130.�j��O�I������ */
        put_print(dd6);                    /* 131.�j��O�I������ */

        put_print(officer);                /* 132.�g��H�N��     */
        /***************************************************
        if(strcmp(kind,"2")==0)
        {
           put_print(57,broker,1);
        }
        ****************************************************/
        put_print(s_dmg_acc_1st);          /* 133.����ߴڦ��ƫe�@�~ */
        put_print(s_dmg_acc_2nd);          /* 134.����ߴڦ��ƫe�G�~ */
        put_print(s_dmg_acc_3rd);          /* 135.����ߴڦ��ƫe�T�~ */

        put_print(s_plia_acc2);            /* 136.�d���ߴڰO���Y��   */
        put_print(s_pdmg_acc);             /* 137.����ߴڰO���Y��   */
        put_print(s_plia_acc1);            /* 138.�j��ߴڰO���Y��   */
        
        strcpy(dpolicy,cm_from_infdate_100(dpolicy));
        strcpy(dexamine,cm_from_infdate_100(dexamine));
        put_print(dexamine);              /*  139.�պ��� */
        put_print(dpolicy);               /*  140.ñ���� */
        put_print(transno);               /*  141.����s�� */
        put_print(lia_class);             /*  142.�d���ż� */
        put_print(dmg_class);             /*  143.����ż� */
        put_print(fcomp_class);           /*  144.�j��ż� */
        put_print(card1);                 /*  145.�j��d�� */
        put_print(out_premium1);          /*  146.�j��O�O */ 
        put_print(iemail);                /*  147.iemail   */

        if (iquery_num[0] == ' ' || iquery_num[0] == '\0')
           strcpy(iquery_num," ");

        if (iquery_num_c[0] == ' ' || iquery_num_c[0] == '\0')
           strcpy(iquery_num_c," ");

        if (iquery_num[0] != ' ' && iquery_num[0] != '\0')
        {
           put_print(iquery_num);            /*  148.���N�d�ߧǸ� */
           put_print(iquery_num_c);          /*  149.�j��d�ߧǸ� */
        }
        else
        {
           put_print(iquery_num_c);       
           put_print(iquery_num);          
        }

        printf("deduct_30[%s]\n",deduct_30);
        if (strlen(trim(deduct_30)) == 0)
        {
           put_print("");
        }
        else if ((!IsFcomp24(deduct_30)) && (!IsFcomp51(deduct_30)))
        {
           put_print("30�I�ةӫO�d�򤣥]�t�ĤT�H�d�����s���v�T�έ��ȳd�����[���ڡC");
        }
        else if (!IsFcomp24(deduct_30))
        {
           put_print("30�I�ةӫO�d�򤣥]�t�ĤT�H�d�����s���v�T���[���ڡC");
        }
        else if (!IsFcomp51(deduct_30))
        {
           put_print("30�I�ةӫO�d�򤣥]�t���ȳd�����[���ڡC");
        }
        else
        {
           put_print("");
        }        
        
        put_print(iins_type_5155);         /* �����I�I�إN��   */

      
        rTmp = mbus_rule - mbusiness;
        if( rTmp != 0) /* �j���I���u�f */
        {
            put_print( "�j���I�����O�O");           /* 152.�j���I�����O�O */

            lTmp = premium1 + (mbus_rule - mbusiness);
            strcpy( sTmp,refmtamt( lTmp,MILLIONTH));
            put_print( sTmp);           /* 153.�j���I�����O�O(�u�f�e) */

            put_print( "�j���I�u�f���B");           /* 154.�j���I�u�f���B */

            rfmtdouble(rTmp, "-,---,--&",  sTmp);
            put_print( sTmp);           /* 155.�j���I�u�f���B */
        }
        else
        {
           put_print("");
           put_print("");
           put_print("");
           put_print("");
        }

        if( tot_discount != 0) /* ���N�I�I���u�f */
        {
            put_print( "���N�I�����O�O");           /* 156.���N�I�����O�O�r�� */

            lTmp = premium2 + tot_discount;
            strcpy( sTmp,refmtamt( lTmp,MILLIONTH));
            put_print( sTmp);           /* 157.���N�I�����O�O(�u�f�e) */

            put_print( "���N�I�u�f���B");           /* 158.���N�I�u�f���B�r�� */

            strcpy( sTmp,refmtamt(tot_discount,MILLIONTH));  /* 159.���N�I�u�f���B */
            put_print( sTmp);
        }
        else
        {
           put_print("");
           put_print("");
           put_print("");
           put_print("");
        }
    }
}

void put_print(pstr)
char *pstr;
{
     printf("pstr[%s]\n",pstr);
     strcpy(pstr,rtrim(pstr));
     strcat(rptstr322,pstr);
     strcat(rptstr322,"|");
}

int get_18_6x_prt_deduct(gins_type,gprn_deduct)
char *gins_type;
char *gprn_deduct;
{
int  rtn;
char sTmpBuf[20];
char start_18[3];

     rtn = 0;
     if (strcmp(trim(gins_type),"18") == 0)
     {
        strncpy(sTmpBuf,gprn_deduct+2,2);
        sTmpBuf[2] = '\0';
        strcat(sTmpBuf,"%");
        strcat(sTmpBuf,"(�_���B");
        strncpy(start_18,gprn_deduct,2);
        start_18[2] = '\0';
        strcat(sTmpBuf,start_18);
        strcat(sTmpBuf,"%)");
        strcpy(gprn_deduct,sTmpBuf);
        rtn = 1;
     }
     else if ((strcmp(trim(gins_type),"62") == 0) ||
              (strcmp(trim(gins_type),"63") == 0) ||
              (strcmp(trim(gins_type),"64") == 0))
     {
        strcpy(sTmpBuf,"���ݮɶ�");
        strcat(sTmpBuf,trim(gprn_deduct));
        strcat(sTmpBuf,"�p��");
        strcpy(gprn_deduct,sTmpBuf);
        rtn = 1;
     }

     return rtn;
}

int IsFcomp24(str)
char *str;
{
    while (*str)
    {
        if (*str == '2')
        {
           str++;
           if (*str == '4')
           {
              return TRUE;
           }
           else
           {
              str--;
           }
        }
        str++;
    }
    return FALSE;
}

int IsFcomp51(str)
char *str;
{
    while (*str)
    {
        if (*str == '5')
        {
           str++;
           if (*str == '1')
           {
              return TRUE;
           }
           else
           {
              str--;
           }
        }
        str++;
    }
    return FALSE;
}


