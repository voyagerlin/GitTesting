/***********************************************
 * Copyright (C) 2001 Intellisys Corporation
 * ��o�i���ߥ��N�I�ӫO���
 * Program : car9995.ec
 * Modify : 2006/8/1 55,26,41,42,81,82,71,72�O�v��I�~��ק�
 ***********************************************/
 
/*109/01/01��s�ǰe�W�h-�¶ǰe�W��аѦҫe����*/

#include <stdio.h>
#include <stdlib.h>
#include "sqlfatal.h"
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "car_common.h"
#include <math.h>

double MyPower();
int DiffMonth();
long get_ca_car_model();
long get_dmg_cover();
long get_mcoefficient();
long get_prov_coefficient();
long get_mprem_base();

$char localdb[5],Taipei_FullName[20];
int  i, flag_check=0;
/* end of standard defined data */

$char userid[11], iquota[7];
char expdate[6];
char bgndate[10],enddate[10];
char prtfile[80],outputf[80],outputf1[80],tmp_outputf[21];
char option[2];
char errmsg[300];

 FILE  *fptr, *fptr_err;
$char  errFile[120];
$static char remotedb[DBNAME]; 
int   count_db,k; 
$char  data_yyyymm[7];

$char DBName[05];
$char msgbuf[128];
DBinfo *list;
char    sApHome[30];
int rtncode,rc;
char    filename[30];
FILE    *fp;
char  file_catalog[200];
$char filename1[200];

long car9995_get_db();
long car9995_build();
long car9995_final();
/*************************************************************/
main(argc,argv)
int argc;
char **argv;
{
	batchinit();
	
	strcpy(DBName, isNULLstr(argv[1]));
	strcpy(userid, isNULLstr(argv[2]));
	strcpy(expdate,isNULLstr(argv[3]));
	strcpy(outputf,isNULLstr(argv[4]));
	
	printf("DBName[%s],userid[%s],expdate[%s],outputf[%s] \n",DBName,userid,expdate,outputf);
	
	rc = car9995_get_db();
	if (rc != M_CM_OK)
	{
		return rc;
	}

	rc = car9995_build();
	if ( rc != SUCCESS ) {
	 	printf("error on car9995_build \n");
	 	EWRITE(userid, rc, errmsg);
		return rc;	
	}

	rc = car9995_final();
	if ( rc != SUCCESS ) {
	 	printf("error on car9995_show \n");
	 	EWRITE(userid, rc, errmsg);
		return rc;	
	}
}

long car9995_get_db()
{
	$whenever sqlerror goto errexit1;

	if (db_select(DBName) == DBName) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	
	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
	 	return rc;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit1:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car9995_build()
{
	char   bgn_yy[5],bgn_mm[3],end_mm[3];
	int    endyy,endmm;
	$long  dwritten_l,dpolicy;
	$char  ipolicy[POLICY_NUM_1], ilast_ply[POLICY_NUM_1];
	$char  sIpolicy1[POLICY_NUM_1];
	char  sPrePolicy1[POLICY_NUM_1], sPrePolicy[POLICY_NUM_1];
	$char  ipolicy_br[3], fpt[2], qpt_tmp[10], objno[5];
	$char  icode[2],acc_tmp[5],adjust_tmp[5],carfleet_rate_tmp[11];
	$long  dply_begin,dply_end;
	$char  ilicense[11],fsex[2],fmarriage[2],icar_type[3],ipro_year[5];
	$char  ibrand[9],ibrand_new[9],drate_ym[5],iacc_align[3],flimit[2];
	$char  iissue_yy[5],iissue_mm[3];
	$char  pdmg_align[2],plia_align[2],iins_type[INSURANCE_TYPE],dvp_code[3],pbrg_align[2];
	$int   ipdmg_align, iplia_align,ipbrg_align;
	$int   tmp_align;
	$long  mdamage_cover,mdeduct,mins_premium,bgndate_l,enddate_l,mprem;
	$long  mpure_prem,pure_total;
	$long  mdeduct01,minjured_cover,mdeath_cover;
	$int   qcylinder;
	$char  stmt_buf1[4096], stmt_buf2[4096], stmt_buf3[4096],drate_code[7];
	$char  product_kind[3],Maxmin[5];

	$double qpt,plia_acc,pdmg_acc,Maxminvalue;
	$double adjust_rate,car_t_rate,carfleet_rate;
	char   dply_begin_c[11],dply_end_c[11],mins_premium_c[10],mpure_prem_c[10],qcylinder_c[6];
	char   mdamage_c[9],minjured_c[9],mdeath_c[9],mdeduct_c[8],mprem_c[10],mprem_m[10],mpure_c[10];
	char   dpolicy_c[11],iproyear[5],drate_yy[5],drate_mm[3],drate_dd[3];
	char   dply_begin_yy[5],dply_begin_mm[3],dply_begin_dd[3];
	char   dply_end_yy[5],dply_end_mm[3],dply_end_dd[3];
	$char  dply_yy[5],dply_mm[3],ibirth_yy[5],tmp_dd[3];
	char   ilast_br[3],prtstr[304],ipolicy_tmp1[2],ipolicy_tmp2[7];
	char   cmdbuf[100],prem_c[13],prem_m[13],ipolciy_no[8],ilast_tmp1[2],ilast_tmp2[7];
	char   ipolicy_no[13],ilast_no[13], prem_subtot_c[9],prem_subtot_m[9];
	$long  prem_total,count1,count2;
	$long   prem_subtot=0, prem_subtot0=0, prem_subtot1=0;
	$double prem_subtot2= 0.0;
	$char  drate[YYYYMMDD], drate_c[9];
	$int    res,qpt_id;
	$char   aphome[40],stmt[4096], iply_area[3], sFassured[2], buf1[30];
	$char fcar_class[2],iproduct[13],ttday[20], provision[21],fcar_class_p[2];
	char   ttday_yy[5],ttday_mm[3],ttday_dd[3];
	$static date   Today;
	int  iFetch, iTmpbuf;
	int  policy_cnt;
	$char  ibroker[11], fbusiness[2],ibroker_top[11],bzfrom[3],bzfrom_before[3];
    $char  ibrand6[7],ibrand_78[3];
    $int   cnt;
    $int  f_1000401; /* �O���1000401 */
    $char iengine[CA_ENGINE_NUM],ibody[CA_BODY_NUM],itag[CA_TAG_NUM];
    $char iins_type_class[2];
    /*$char provision_t[21],pro_tmp[21];*/
	$int pro_cnt = 0;
	$char chk_157[2];
	int f_1090701;
	
	/* 1080822001_SC1_���N���I�έp�W�{�׭q��� */
	/*�s�y��*/
	$long qpro_month;
	$char qpro_month_c[3];
	/*���m���ȡB�t�ƪ��B*/
	$double mcar_price,mcar_price_ori,mequipment;
	$double p_mcar_price = 0.0;
	$char mcar_price_tmp[4];
	/*�ʧO�~�֫Y��*/
	$double psex_age_lia,psex_age_dmg;
	$char sex_age_tmp[5];
	/*���[����-������e*/
	$int cnt_iins_main = 0;
	$char iins_main[INSURANCE_TYPE];
	$int cnt_ins_type = 0;
	$char provision_tmp[21],provision_tmp2[21],provision_tmp_replace[21];
	$char c_pro_tmp[2];
	$char icar_type_ori[3];   /*�d�O�v�ɭn�έ쨮��*/
	$int cnt_prov_t,cnt_prov;
	$int qprovision;
	$double coefficient = 0.0,pcar_price = 0.0;
	/*���²v*/
	$long pdepreciate_year = 0,pdepreciate_year_tot = 0;
	$char pdepreciate_year_tmp[4],pdepreciate_year_tot_tmp[4],pdepreciate_year_tmp2[5];
	/*�I���ഫ-insurance_type_develop*/
	$char iins_type_main[3],iins_type_dtl[3],iins_type_develop[3],iins_type_rule[3],frule[2],fcal_way[2];
	/*�ߴڦ~���I�ơB�ߴڦ����I��*/
	$double qdmg_acc_sum,qdmg_acc,qdmg_acc_time,qdmg_acc_year;
	/*�O�O����-���t�Y�ƫO�O/�«O�O*/
	$long mins_premium_n,mpure_prem_n;
	$long mprem_prov,mprem_pure_prov;
	$long mprem_cal,mprem_pure_cal;
	$double mprem_base_prov;
	$double mprem_base = 0.0;
	$char mprem_base_c[14];
	$char mpure_prem_n_c[10];
    $char mprem_prov_c[10];
    $char mprem_pure_prov_c[10];
    $char mins_premium_n_c[10];
    $int ifleet = 0;
    $long mprov_tmp = 0,mprov_pure_tmp = 0;
    $double mprov_base_tmp = 0.0;
	$int qply_period;
    $int car_age150151,qday;
    $double qpassenger;
    $double pubi_acc;
    $long minjured_cover_tmp=0;
    $char chk_prov[2];
    $int mdeduct_ori;
    $char fins_cal_way[2];
    $char fProvision_c[2];
    /*�O�B����*/
	$long mcover_ori=0,mcover_prov=0;
	$char icar_series[3];
	$int chk_cover_per=0,chk_cover_E=0,chk_cover_K=0,chk_cover_Z=0;
	$long mcover_prov_tmp=0;
	$char mcover_ori_c[10],mcover_prov_tmp_c[10];
	
	$char dissue[11];
	char dissue_100[11],dpro_100[11];
	long ldissue = 0,ldpro = 0;
	$char dissue_pro_tmp[11],dpro[11];
	$int rc=0;
    $char v_sMsg[256];
	$char fins_grp[2];
	$char iri_ins[7];
	
	long iins_mult=0;
	char iin_mult_c[3];
	$char qdmg_acc_year_c[2],qdmg_acc_time_c[2];
	
	$long mcover1=0,mcover2=0,mcover3=0; 
	
	$int f_1090101 = 0,cnt_L = 0;
	$char fcar_kind[2],icomp_card[21];
	$int inext=0;
	$long mins_premium_tmp = 0;
	
	$int fcontract_err=0;
	$char fcar_class_pd[2];
	
	$char sDbirth[11], sDply_begin[11];
	$double age = 0.0,psex_age_chk = 0.0;
	$int chk_plia = 0;
	$long dbirth;
	
	$char iproduct_tmp[3];
	$char p_tmp[21];
	$long mprem_10 = 0,mprem_11 = 0,mprem_12 = 0,mprem_13 = 0,mprem_28 = 0;
	$long mprem_pure_10 = 0,mprem_pure_11 = 0,mprem_pure_12 = 0,mprem_pure_13 = 0,mprem_pure_28 = 0;
	
	$char iproduct_main[13];
	$int cnt_acc=0;
	$double psex_age_tmp = 0;
	
	$char irelative_ply[21];
	$char plyrel_DB[21];
	
	/* �g�Jca_dev_ply_edr */
	$char  t_data_yyyymm[7],t_idata[2],t_ipolicy[21],t_iendorse[21],t_icompany[3],t_iply_br[3],t_iply[13],t_iply_last_br[3],t_iply_last[13];
	$char  t_iedr_br[3],t_iedr[13],t_iarea[3],t_dedr_begin[9],t_dedr_end[9],t_dply_begin[9],t_dply_end[9],t_iobjno[5],t_iissue_ym[7],t_ipro_ym[7],t_ibrand[9];
	$char  t_icar_type_ori[3],t_icar_type[3],t_icar_type_no[3],t_iengine[26],t_itag[13],t_fpt[2],t_iassured[11],t_dbirth_y[5],t_fsex[2],t_fmarriage[2];
	$char  t_ipdmg_align[2],t_ipbrg_align[2],t_iplia_align[2],t_iins_type[7],t_iins_main[7],t_iins_type_main[2],t_iins_type_dtl[3];
	$char  t_iedr_type[3],t_iins_type_dev[5],t_iins_type_rule[3],t_frule[2],t_ubi_data[9],t_fmdeduct[2];
	$char  t_iproduct[13],t_drate_ym[7],t_dendorse_ym[7],t_dpolicy_ym[7],t_bzfrom[3],t_dsend[9];
	$long  t_qcylinder,t_qpt,t_padjust_rate,t_p_mcar_price,t_qdmg_acc_year,t_qdmg_acc_time,t_pdepreciate_year;
	$long  t_minjured_cover,t_mdeath_cover,t_mdamage_cover,t_mdamage_cover_bak,t_mdamage_cover_aft,t_iins_mult;
	$long  t_mdeduct,t_mprem,t_mprem_pure,t_mprem_bak,t_mprem_pure_bak,t_mprem_aft,t_mprem_pure_aft;
	$double t_pins_acc,t_psex_age,t_mprem_pure_base,t_mprem_pure_base_bak,t_mprem_pure_base_aft,t_coefficient;

	$char  stmp[1024],stmp1[1024],stmp2[1024];
	$char  stmp_ins1[1024],stmp_ins2[1024],stmp_ins3[1024],stmp_ins4[1024];

	$char iins_type_tmp[7];
	$char *prov;
	$char prov2[7];
	$int prov_cnt=0;
	$int prov_K=0,prov_T=0,prov_U=0,prov_J=0;
	
	$int cnt_149 = 0;
	
	$char icar_type_m[3],fcar_class_m[2];
	
	$char nequipment[31],foil_electric[2]="";
	$int f_1120501 = 0;
	
	$int chk_provY_noprem = 0;
	
	filename[0]    = '\0';
	file_catalog[0] = '\0';
	sprintf(filename,"%s/rptftp/", sApHome);
	sprintf(filename1,"AUTOW17_%d.txt",atoi(expdate)+191100);
	strcpy(file_catalog, trim(filename));
	strcat(file_catalog, trim(filename1));

	if ((fptr=fopen(file_catalog,"w")) == NULL)
	{
		sprintf(errmsg,"Cannot open print file: %s",outputf);
		return M_CM_OPEN_FILE_FAIL;
	}
	
	/* *** open error log file *** */
	res = getApHome(aphome);
	/*sprintf(errFile,"%s.%s.error",outputf,DBName);*/
	sprintf(errFile,"%s/tmp/%s.%s.error",sApHome,outputf,DBName);  /* �ץ���Ƨ��v�����D( fopen(errFile,"w")) == NULL )*/
	if ((fptr_err=fopen(errFile,"w")) == NULL)
	{
		sprintf(errmsg,"Cannot open print file: %s",errFile);
		return M_CM_OPEN_FILE_FAIL;
	}

	printf(">>>expdate=%s\n",expdate);
	strncpy(bgn_yy,&expdate[0],3); bgn_yy[3]='\0';
	strncpy(bgn_mm,&expdate[3],2); bgn_mm[2]='\0';
	if (strncmp(bgn_mm, "12",2) == 0)
	{
		endyy=atoi(bgn_yy)+1;
		endmm=1;
	}
	else
	{
		endyy=atoi(bgn_yy);
		endmm=atoi(bgn_mm)+1;
	}
	rfmtlong(endmm,"&&",end_mm);

	sprintf(bgndate,"%s/%s/%s",bgn_yy,bgn_mm,"01");
	sprintf(enddate,"%d/%s/%s",endyy,end_mm,"01");
	sprintf(data_yyyymm,"%s%s",itoa(atoi(bgn_yy)+1911),bgn_mm);
	printf(">>>bgndate=[%s] enddate=[%s]\n",bgndate,enddate);

	$WHENEVER SQLERROR GOTO errexit;

	bgndate_l=cm_ymd_cdate(bgndate);
	enddate_l=cm_ymd_cdate(enddate);

    /* �O���1000401 */
    if (bgndate_l >= cm_ymd_cdate("100/04/01")) f_1000401 = 1;
    else f_1000401 = 0;
    
    if (bgndate_l >= cm_ymd_cdate("109/07/01")) f_1090701 = 1;
    else f_1090701 = 0;
    

	/* ��ƻs�e��*/
	strcpy(ttday , cm_get_sysd());
	strncpy(ttday_yy,&ttday[0],4); ttday_yy[4] = '\0';
	strncpy(ttday_mm,&ttday[5],2); ttday_mm[2] = '\0';
	strncpy(ttday_dd,&ttday[8],2); ttday_dd[2] = '\0';

	printf(">>>before prepare ori_ply_relarion\n");
	/***** prepare cursor for select ori_ply_relation *****/
	prem_subtot0 = prem_subtot1 = prem_total = pure_total=0;
	count1 = 0;
	policy_cnt = 0;
	for(k=0;k<count_db;k++)
	{ 
		sprintf(stmt,"DELETE FROM %s:ca_dev_ply_edr WHERE data_yyyymm = '%s' AND idata = 'W'",list[k].dbname,data_yyyymm);
		$PREPARE DE_ca_dev_ply_edr FROM $stmt;
		$EXECUTE DE_ca_dev_ply_edr;

		/*
		      case when ipolicy[6,7] = 'V7' then 'Y' else 'N' end, 
			  => 
			  CASE WHEN EXISTS(SELECT '1' FROM newa00:ori_ins_type 
	                    WHERE ipolicy = a.ipolicy 
	                      AND iins_type IN ('157','158','159','160','171','172','257','258','259','260'))
         	  THEN 'Y' ELSE 'N' END, 
		*/
		sprintf(stmt_buf1,"SELECT ipolicy, ipolicy[1,%d], ilast_ply, \
								  dpolicy, dply_begin, dply_end, \
								  ibrand, icar_type, ipro_year, ibroker, bzfrom , ibrand[7,8], \
								  case when ipolicy[6,7] = 'V7' then 'Y' else 'N' end, qprovision, qply_period, \
								  CASE WHEN dpolicy >= '01/01/2020' THEN 1 ELSE 0 END, \
								  nvl(a.irelative_ply,' '), \
								  CASE WHEN dpolicy >= '05/01/2023' THEN 1 ELSE 0 END \
						     FROM %s:%s %s", CAR_POLICY_LEN,list[k].dbname,"ori_ply_relation a",
						   "WHERE fcard_class='2' \
						      AND ipolicy[6,7] <> 'VW' \
							  AND ipolicy[6,7] <> 'EB' \
							  AND ipolicy[6,7] <> 'TV' \
							  AND dpolicy >= ? \
							  AND dpolicy < ? ORDER BY 1");		  
		$PREPARE CUR_STMT1 FROM $stmt_buf1;
		$DECLARE scur_ply1 CURSOR FOR CUR_STMT1;

		printf(">>>before prepare original_ply\n");
	
		/***** prepare cursor for select original_ply *****/
	    /* 0991115001�]�����F�������X�֭p�� */
	    /* 1.���a�ϥN����42�u�x�����v�A�h�վ㬰41�u�x�����v */
	    /* 2.���a�ϥN����63�u�x�n���v�A�h�վ㬰62�u�x�n���v */
	    /* 3.���a�ϥN����65�u�������v�A�h�վ㬰64�u�������v */
		sprintf(stmt_buf2,"SELECT %s %s %s FROM %s:%s %s",
							"qcylinder,iassured[1,10],YEAR(dissue),MONTH(dissue),YEAR(dbirth),fsex,fmarriage,nvl(plia_acc,0),NVL(pdmg_acc,0),flimit,",
							"nvl(pdmg_align,0),NVL(plia_align,0),qpt,fpt,pbrg_align,DECODE(iply_area,'42','41','63','62','65','64',iply_area),fassured,",
							"nvl(iengine,' '),nvl(ibody,' '),itag,qpro_month,qdmg_acc_sum,NVL(mcar_price,0),NVL(psex_age,0),dissue,pubi_acc,fcal_way,dbirth,nequipment,mequipment",
							list[k].dbname,"original_ply ",
							"WHERE ipolicy=?");
		$PREPARE CUR_STMT2 FROM $stmt_buf2;
		$DECLARE scur_policy1 CURSOR FOR CUR_STMT2;
	
		printf(">>>before prepare ori_ins_type\n");
	
		/***** prepare cursor for select ori_ins_type *****/
		sprintf(stmt_buf3,"SELECT %s %s %s FROM %s:%s %s",
							"iins_type, mdeduct, mins_premium,round(mpure_prem), mprem, drate_ym, ",
							"NVL(minjured_cover,0), NVL(mdeath_cover,0), NVL(mdamage_cover,0),iproduct,nvl(provision,' '),adjust_rate,pcar_price,",
							"mins_premium_n,round(mpure_prem_n),psex_age,qday,(safe_rate+manage_rate)/100 ",
							list[k].dbname,"ori_ins_type",
							"WHERE ipolicy = ? ");
	
		$PREPARE CUR_STMT3 FROM $stmt_buf3;
		$DECLARE scur_ply_ins_a1 CURSOR FOR CUR_STMT3;
	
		sprintf(stmt,"SELECT fcar_class FROM car_type \
					   WHERE fclass = '1' AND icode = ? ");
		$PREPARE CUR_CARCLASS FROM $stmt;

		/*OUTER-�]���n����[���ڡAinsurance_type�|�d����*/
		sprintf(stmt,"SELECT a.iins_type_main,a.iins_type_dtl,a.iins_type_develop,a.iins_type_rule,nvl(b.fcal_way,' ') \
	                    FROM insurance_type_develop a, OUTER insurance_type b \
	                   WHERE a.iins_type = b.iins_type \
	                     AND a.iins_type = ? ");
		$PREPARE CUR_DEVELOP FROM $stmt;
		
		sprintf(stmt,"SELECT fins_grp,iri_ins \
	                    FROM insurance_type \
	                   WHERE iins_type = ? ");
		$PREPARE CUR_INSGRP FROM $stmt;
	
	    /***** prepare cursor for select ca_car_model *****/
	    /* 1000530002�t�P�����N���H�ഫ�t�P�����N�����e */
	    sprintf(stmt, "SELECT ibrand_new "
	                    "FROM ca_car_model "
	                   "WHERE ibrand = ? "
	                     "AND ibrand_new != ' ' "
	                "ORDER BY drate DESC;");
	    $PREPARE pr_ibrand FROM $stmt;
	    $DECLARE cur_ibrand CURSOR FOR pr_ibrand;
	    printf("stmt[%s]\n", stmt);
	    
	    /*provision temp table*/
		$CREATE TEMP TABLE prov_tmp (provision char(6)) WITH NO LOG;
		$CREATE INDEX prov_tmp_ix1 ON prov_tmp(provision);
		$CREATE TEMP TABLE prov_tmp2 (provision char(6)) WITH NO LOG;
		$CREATE INDEX prov_tmp2_ix1 ON prov_tmp2(provision);
		
		iFetch = TRUE;
		
		mcar_price = mcar_price_ori = mequipment = 0.0;
		psex_age_lia = psex_age_dmg = 0.0;
		mins_premium_n = mpure_prem_n = 0;
		
		$OPEN scur_ply1 USING $bgndate_l, $enddate_l;
		/*$OPEN scur_ply1;*//*TEST*/
		while (1)
		{
			$FETCH scur_ply1
			  INTO $ipolicy, $sIpolicy1, $ilast_ply, $dpolicy, $dply_begin,
			       $dply_end, $ibrand, $icar_type, $ipro_year, $ibroker, $bzfrom ,$ibrand_78, $chk_157, $qprovision, $qply_period, $f_1090101, $irelative_ply, $f_1120501;

			if (SQLCODE == SQLNOTFOUND) 
			{
				break;
			}
			strcpy(icar_type,trim(icar_type));
			strcpy(icar_type_ori,trim(icar_type));
			strcpy(drate_ym, trim(drate_ym));
			strcpy(irelative_ply, trim(irelative_ply));

			strcpy(icomp_card," ");	
			if (strlen(irelative_ply) > 0)
			{
				strcpy(plyrel_DB, get_car_full_db(irelative_ply));
				sprintf(stmp,"SELECT NVL(icard,' ') \
			                    FROM %s:ori_ply_relation \
			                   WHERE ipolicy = '%s' ",plyrel_DB,irelative_ply);
				$PREPARE ply_comp_card FROM $stmp;
				$EXECUTE ply_comp_card INTO $icomp_card;
			}
			else 
			{
				strcpy(icomp_card," ");	
			}

			$OPEN scur_policy1 USING $ipolicy;
			$FETCH scur_policy1
		      INTO $qcylinder,
				   $ilicense, $iissue_yy, $iissue_mm, $ibirth_yy, $fsex, $fmarriage, $plia_acc,
				   $pdmg_acc, $flimit, $ipdmg_align, $iplia_align,
				   $qpt:qpt_id, $fpt,
				   $ipbrg_align, $iply_area, $sFassured, $iengine, $ibody, $itag, $qpro_month, $qdmg_acc_sum,
				   $mcar_price, $psex_age_lia, $dissue, $pubi_acc, $fins_cal_way, $dbirth, $nequipment, $mequipment;
	
			if (SQLCODE == SQLNOTFOUND)
			{
				$CLOSE scur_policy1;
			}
			$CLOSE scur_policy1;
	
			if (iFetch)     /*�Ĥ@�����W�@���O�ۤv*/
			{
				strcpy(sPrePolicy1,  sIpolicy1);
				iFetch = FALSE;
			}
	
			if ( (strcmp(sPrePolicy1, sIpolicy1) != 0) && policy_cnt > 0 )
			{
				/*99:�O�O�`�p*/
				/* 1-16 */
				prtstr[16] = '\0';
				/* 17-34 */
				strcat(prtstr, sformat_trade(" ", 2, 18));
		
				/* 35-42  �O�I�ͮĶ}�l���*/
				cm_split_ymd_100(dply_begin_c,dply_begin_yy,dply_begin_mm,dply_begin_dd);
				if (dply_begin_yy[0] == '\0' ) strcat(prtstr,"0000");
				else strcat(prtstr,itoa(1911+(atoi(dply_begin_yy))));
				if (dply_begin_mm[0] == '\0') strcat(prtstr,"00");
				else strcat(prtstr,dply_begin_mm);
				if (dply_begin_dd[0] == '\0') strcat(prtstr,"00");
				else strcat(prtstr,dply_begin_dd);             
		
				/* 43-50  �O�I�ͮĲפ���*/
				cm_split_ymd_100(dply_end_c,dply_end_yy,dply_end_mm,dply_end_dd);
				if (dply_end_yy[0] == '\0') strcat(prtstr,"0000");
				else strcat(prtstr,itoa(1911+(atoi(dply_end_yy))));
				if (dply_end_mm[0] == '\0') strcat(prtstr,"00");
				else strcat(prtstr,dply_end_mm);
				if (dply_end_dd[0] == '\0') strcat(prtstr,"00");
				else strcat(prtstr,dply_end_dd);           
				
				/* 51-78 */
				strcat(prtstr, sformat_trade(" ", 2, 28));
				/* 79-83 */
				strcat(prtstr, "00000");
				/* 84-120 */
				strcat(prtstr, sformat_trade(" ", 2, 37));
				/* 121-124 */
				strcat(prtstr, "0000");
				/* 125-147 */
				strcat(prtstr, sformat_trade(" ", 2, 23));
				/* 148-151 */
				strcat(prtstr, "99");
				/* 150-160 */
				strcat(prtstr, sformat_trade(" ", 2, 11));
				/* 161-176 */
				strcat(prtstr, "+000");
				strcat(prtstr, "+0");
				strcat(prtstr, "+0");
				strcat(prtstr, "+000");
				strcat(prtstr, "+000");
				/* 177-184 */
				strcat(prtstr, sformat_trade(" ", 2, 8));
				/* 185-217 */
				strcat(prtstr, "+000000000");
				strcat(prtstr, "+000000000");
				strcat(prtstr, "+000000000");
				strcat(prtstr, "+00");
				/* 218 */
				strcat(prtstr, " ");
				/* 225-259 */
				strcat(prtstr, "0000000");
				
				if(prem_subtot0 < 0 ) strcat(prtstr,"-");
				else strcat(prtstr,"+");
				rfmtlong(prem_subtot0, "&&&&&&&&&", prem_subtot_c); /*�h���u�ݫ�*/
				strcat(prtstr,prem_subtot_c);
		
				if(prem_subtot1 < 0 ) strcat(prtstr,"-");
				else strcat(prtstr,"+");
				rfmtlong(prem_subtot1, "&&&&&&&&&", prem_subtot_m); /*�«O�O */
				strcat(prtstr,prem_subtot_m);
				
				strcat(prtstr,"+0000000000000");
				
				/* 260-277 */
				strcat(prtstr, sformat_trade(" ", 2, 18));  
		
				/* 278-283 */
				cm_split_ymd_100(dpolicy_c,dply_yy,dply_mm,tmp_dd);
				if (dply_yy[0] == '\0') strcat(prtstr,"0000");
				else strcat(prtstr,itoa (1911 + (atoi (dply_yy))));
				if (dply_mm[0] == '\0') strcat(prtstr,"00");
				else strcat(prtstr,dply_mm);
		
				/* 284-293 */
				strcat(prtstr, sformat_trade(" ", 2, 10)); 
				prtstr[293]='\0';
				if (atoi(data_yyyymm) >= 202101)
				{
					strcat(prtstr,"0000000000");
					prtstr[303]='\0';
				}
				
				fprintf(fptr,"%s\n",prtstr);
				/*99�[�`���p����*/
				/*count1++;*/
	
				prem_subtot0 = prem_subtot1 =0;
				prem_subtot2 = 0.0;
				policy_cnt = 0;
			}
			
			$TRUNCATE TABLE prov_tmp;  /*�M��prov_tmp*/
			$TRUNCATE TABLE prov_tmp2;  /*�M��prov_tmp*/
			strcpy(sPrePolicy1,     sIpolicy1);
			$OPEN scur_ply_ins_a1 USING $ipolicy;
			while (1)
			{
				/*2020/01 �s�ǰe�W��O�O�n����A�W�[mins_premium_n(�I�إ����Y�ƫO�O)*/
				$FETCH scur_ply_ins_a1
			      INTO $iins_type,$mdeduct,$mins_premium,$mpure_prem,$mprem,$drate_ym,
					   $minjured_cover,$mdeath_cover,$mdamage_cover,$iproduct,$provision,$adjust_rate,$pcar_price,
					   $mins_premium_n,$mpure_prem_n,$psex_age_dmg,$qday,$car_t_rate;
	            strcpy(iins_type,trim(iins_type));
	            printf("--509 iins_type[%s]\n",iins_type);
				if (SQLCODE == SQLNOTFOUND) 
				{
					break;
				}
				
				if (strcmp(trim(iins_type),"33")==0)  /* �ˮ`�I��Ƥ��e */
					continue;
		
				if (strcmp(trim(iins_type),"47")==0)  /* �����ˮ`�I��Ƥ��e */
					continue;
	
				if (strcmp(trim(iins_type),"48")==0)  /* �����ˮ`�I��Ƥ��e */
					continue;
	
				if (strcmp(trim(iins_type),"56")==0)  /* �r�p�H�ˮ`�I��Ƥ��e */
					continue;
	
				if (strcmp(trim(iins_type),"50")==0)  /* �r�p�H�ˮ`�I��Ƥ��e */
					continue;
	
				if (strcmp(trim(iins_type),"80")==0)  /* �ۥΨT����X�I�r�p�H�ˮ`��Ƥ��e */
					continue;
	
				if (strcmp(trim(iins_type),"89")==0)  /* �Ұ���r�p�H�ˮ`��Ƥ��e */
					continue;
	
				if (strcmp(trim(iins_type),"136")==0) /* ���ľ��c�r�p�H�ˮ`�I���e */
					continue;
	
				if (strcmp(trim(iins_type),"147")==0) /* �����j���I�r�p�H�ˮ`���[���ڸ�Ƥ��e */
					continue;
					
				if (strcmp(trim(iins_type),"166")==0)  /* �ĤT�H���[�r�p�H�ˮ`(�����D) */
					continue;
					
				if (strcmp(trim(iins_type),"266")==0)  /* �r�p�H�ˮ`�O�I (�����D) */
					continue;

				if (strcmp(trim(iins_type),"561")==0)  /* �r�V�Z�r�p�H�ˮ`�I */
					continue;

				if (strcmp(trim(iins_type),"562")==0)  /* �r�V�Z�r�p�H�ˮ`�������B*/
					continue;

				if (strcmp(trim(iins_type),"563")==0)  /* �r�V�Z�r�p�H�ˮ`��������I */
					continue;
										
				if (strcmp(trim(iins_type),"171")==0)  /* �������l�����d�� */
					continue;
					
				if (strcmp(trim(iins_type),"172")==0)  /* �����l���d�� */
					continue;
					
				if (strcmp(trim(iins_type),"173")==0)  /* �R�q�ΰ]���l���O�I */
					continue;
					
				if (strcmp(trim(iins_type),"174")==0)  /* �R�q�βĤT�H�d���O�I */
					continue;
				
				if (strcmp(trim(iins_type),"175")==0)  /* �R�q�λ䭷�άx�����[���� */
					continue;
				
				prem_total += mins_premium;
				pure_total += mpure_prem;
				printf("iins_type[%s],prem_total[%d],pure_total[%d],mins_premium[%d],mpure_prem[%d] \n",iins_type,prem_total,pure_total,mins_premium,mpure_prem);
				mdeduct_ori = 0;
				mdeduct_ori = mdeduct;
				provision_tmp[0] = '\0';
				provision_tmp2[0] = '\0';
				strcpy(provision_tmp ,trim(provision));
				iins_main[0] = '\0';
				cnt_ins_type = 0;
				cnt_ins_type++;
				cnt_prov_t = cnt_prov = 0;
				mprov_tmp = mprov_pure_tmp = 0;
				mprem_prov = 0;
				mprem_pure_prov = 0;
				printf("--provision_tmp[%s] \n",provision_tmp);
				chk_cover_per=0;
				chk_cover_E=0;
				chk_cover_K=0;
				chk_cover_Z=0;
				inext=0;
				
				while(cnt_ins_type>0)
				{
					printf("--695 cnt_ins_type[%d] iins_type[%s] iins_main[%s] provision_tmp[%s]\n",cnt_ins_type,iins_type,iins_main,provision_tmp);
					$SELECT count(*) INTO $prov_cnt FROM prov_tmp2;
					if(cnt_ins_type == 1)
					{
						/*���[���ڱƧ�-�̷Ӫ��[�����I�ض��ǭp��*/
						cnt_iins_main = 1;
						cnt_ins_type++;
						strcpy(iins_main,iins_type);
						
						strcpy(icar_type_m,TRANS_CAR_TYPE(icar_type));
						$EXECUTE CUR_CARCLASS INTO $fcar_class_m USING $icar_type_m;
						printf("icar_type[%s],icar_type_m[%s],fcar_class_m[0] = '%s' \n",icar_type,icar_type_m,fcar_class_m);

						if (provision_tmp[0] == '' || provision_tmp == '\0')
						{
							/*Do NOTHING*/
							cnt_ins_type = 0;
						}
						else 
						{
							prov = strtok(provision_tmp,";");
							while(prov)
							{
								strcpy(prov2,prov);
								strcpy(prov2,rtrim(prov2));
								printf("prov2[%s] \n",prov2);

								if (strcmp(prov2,"R") == 0 || strcmp(prov2,"V") == 0 || strcmp(prov2,"X") == 0 || strcmp(prov2,"C") == 0 )
								{
									printf("--RVXC\n");
								}
								else if(strcmp(prov2,"E") == 0)
								{
									/*E���ڤ��e�A��05+P+E�A�h��X��ӫO�O�B��Ѿl�O�BP�ǰe*/
									chk_cover_E++;	
								}
								else if ((strcmp(prov2,"P") == 0 || strcmp(prov2,"Q") ==0 || strcmp(prov2,"Z") ==0) &&
								         (strcmp(iins_type,"01") != 0  && strcmp(iins_type,"05") != 0  && 
								          strcmp(iins_type,"09") != 0  && strcmp(iins_type,"11") != 0  &&
								          strcmp(iins_type,"201") != 0 && strcmp(iins_type,"205") != 0 && 
								          strcmp(iins_type,"209") != 0 && strcmp(iins_type,"211") != 0 ))
								{
									/* 1130510009_C07_�s�W�q�ʨ��M�ݰӫ~(�O�o���T�ǿ�) */
									printf("--PQZ\n");
								}
								else if (strcmp(prov2,"M") ==0 && fcar_class_m[0] == '1')
								{
									/*M���ڶȩӫO��~��*/
									printf("--M\n");
								}
								else if ((strcmp(prov2,"M") == 0 && fcar_class_m[0] == '2') &&
								         (strcmp(iins_type,"01") != 0  && strcmp(iins_type,"05") != 0  && 
								          strcmp(iins_type,"09") != 0  && strcmp(iins_type,"11") != 0  && strcmp(iins_type,"181") != 0 &&
								          strcmp(iins_type,"201") != 0 && strcmp(iins_type,"205") != 0 && 
								          strcmp(iins_type,"209") != 0 && strcmp(iins_type,"211") != 0))
								{
									/* 1130510009_C07_�s�W�q�ʨ��M�ݰӫ~(�O�o���T�ǿ�) */
									printf("--M\n");
								}
								else if (strcmp(prov2,"K") == 0 && strcmp(iins_type,"09")  != 0)
								{
									printf("--09+K\n");
								}
								else if((strcmp(prov2,"F") == 0) &&
								        (strcmp(iins_type,"01") != 0  && strcmp(iins_type,"05") != 0  && strcmp(iins_type,"09") != 0  &&
								         strcmp(iins_type,"11") != 0  && strcmp(iins_type,"31") != 0  && strcmp(iins_type,"32") != 0  &&
								         strcmp(iins_type,"201") != 0 && strcmp(iins_type,"205") != 0 && strcmp(iins_type,"209") != 0 &&
								         strcmp(iins_type,"211") != 0 && strcmp(iins_type,"231") != 0 && strcmp(iins_type,"232") != 0))
								{
									/*����F���ڶȳ��e����D�I�B�ѵs�D�I�B�d���D�I*/	
									/* 1130510009_C07_�s�W�q�ʨ��M�ݰӫ~(�O�o���T�ǿ�) */
								}
								else if((strcmp(prov2,"T") == 0) &&
								        (strcmp(iins_type,"31") != 0  && strcmp(iins_type,"32") != 0 &&
								         strcmp(iins_type,"231") != 0 && strcmp(iins_type,"232") != 0))
								{
									/*����T���ڶȳ��e�d���D�I31�B32�B149*/	
									/* 1130510009_C07_�s�W�q�ʨ��M�ݰӫ~(�O�o���T�ǿ�) */
								}
								else if((strcmp(prov2,"H") == 0) &&
								        (strcmp(iins_type,"05") != 0   && strcmp(iins_type,"09") != 0   && strcmp(iins_type,"31") != 0  &&
								         strcmp(iins_type,"32") != 0   && strcmp(iins_type,"149") != 0  && strcmp(iins_type,"198") != 0 &&
								         strcmp(iins_type,"255") != 0  && strcmp(iins_type,"302") != 0  &&
								         strcmp(iins_type,"205") != 0  && strcmp(iins_type,"209") != 0  && strcmp(iins_type,"231") != 0 &&
								         strcmp(iins_type,"232") != 0  && strcmp(iins_type,"249") != 0))
								{
									/*�Ȧ�05�B09�B31�B32�B149�B198�B255�B302�i�H�ǰeH�C(266�I����,�]���ݶˮ`�I���e)*/	
									/* 1130510009_C07_�s�W�q�ʨ��M�ݰӫ~(�O�o���T�ǿ�) */
								}
								else if((strcmp(prov2,"Y") == 0) &&
								        (strcmp(iins_type,"01") != 0  && strcmp(iins_type,"05") != 0  && 
								         strcmp(iins_type,"09") != 0  && 
								         strcmp(iins_type,"201") != 0 && strcmp(iins_type,"205") != 0 && 
								         strcmp(iins_type,"209") != 0 && 
								         strcmp(iins_type,"198") != 0))
								{
									/* 1130827011_C09_�s�W�s�t��W�B���[����(Y)(���e) */
									/* �t�Ʊ���01�B05�B09�B201�B205�B209�B198�~�� */
								}
							    else
							    {
							    	chk_provY_noprem = 0;
							    	if(strcmp(prov2,"Y") == 0 && mequipment >0)
							    	{
							    		/* Y���ڭp��ŶZ��S�����B�]���e fcar_class = 1 carfleet_rate=0*/
							    		ifleet = 0;carfleet_rate = 0.0;
							    		printf("mcar_price[%f],mequipment[%f]\n",mcar_price,mequipment);
										rc = get_prov_coefficient( "Y",drate_ym,"1",iins_main,icar_type_ori,qprovision,qpt,
										                           mdeduct,minjured_cover,mdamage_cover,carfleet_rate,pcar_price,pubi_acc,
										                           mcar_price,mequipment,
										                           &ifleet,&coefficient,&chk_prov,v_sMsg);
										printf("--rc[%d] coefficient[%f] ifleet[%d] chk_prov[%s] \nv_sMsg[%s]\n",rc,coefficient,ifleet,chk_prov,v_sMsg);
										if( rc != M_CM_OK)
										{
											rc = insert_ca_log("car9995","W",ipolicy,cm_edate_str(dpolicy),"���[���ګY�Ʀ��~",userid,v_sMsg);
										}
										/*if (coefficient == 1)*/
										if (coefficient <= 1)
										{
											chk_provY_noprem = 1;
										}
							    	}
							    	printf("chk_provY_noprem[%d] \n",chk_provY_noprem);
							    	if (chk_provY_noprem > 0)
							    	{
							    		/* For�W��Y���ˮ֡A�Y��>1�~���[�O */
							    	}
							    	else 
							    	{							    	
										$INSERT INTO prov_tmp VALUES($prov2);
										$INSERT INTO prov_tmp2 VALUES($prov2);
										printf("INTO temp TABLE prov2[%s] \n",prov2);
										prov_K = 0;
										$SELECT count(*) INTO $prov_K FROM prov_tmp WHERE provision = 'K';
										if  (strcmp(prov2,"P") ==0) {strcpy(fProvision_c,"P"); chk_cover_per++;}
										else if (strcmp(prov2,"Q") ==0) {strcpy(fProvision_c,"Q"); chk_cover_per++;}
										else if (strcmp(prov2,"M") ==0) {strcpy(fProvision_c,"M"); chk_cover_per++;}
										else if (strcmp(prov2,"K") ==0) {chk_cover_K++;}
										cnt_prov_t++;
										if (strcmp(prov2,"Z") ==0) {strcpy(fProvision_c,"Z"); chk_cover_Z++;cnt_prov_t--;}
										
										if ((strcmp(prov2,"P") ==0) &&
									         (strcmp(iins_type,"129") == 0 || strcmp(iins_type,"20")  == 0 ||
									          strcmp(iins_type,"75")  == 0 || strcmp(iins_type,"76")  == 0 || 
									          strcmp(iins_type,"98")  == 0 || strcmp(iins_type,"110") == 0 || 
									          strcmp(iins_type,"111") == 0 || strcmp(iins_type,"23")  == 0 || 
									          strcmp(iins_type,"86")  == 0 ))
										{
											/*�o���I��P���ڤ��e���B �u���F����*/
											chk_cover_per--;cnt_prov_t--;
										}
										else if (strcmp(prov2,"P") ==0 && strcmp(iins_type,"09") == 0 && prov_K > 0)
										{
											/*K���ڻP���±��ڦP�ɶǰe�A���±��ڭn�e���u���F����*/
											chk_cover_per--;cnt_prov_t--;
										}
									}
								}
								prov = strtok(NULL,";");
							}
	                	}
					}
					else if (prov_cnt==0)
					{
						$DELETE FROM prov_tmp;
						$DELETE FROM prov_tmp2;
						cnt_ins_type = 0;
						break;
					}
					else
					{
						$SELECT FIRST 1 provision
						   INTO $iins_type_tmp
						   FROM prov_tmp2;
						printf("iins_type_tmp[%s] \n",iins_type_tmp);
						strcpy(iins_type,iins_type_tmp);
						strcpy(iins_type,trim(iins_type));
						cnt_ins_type++;
						
						prov_K = 0;
						$SELECT count(*) INTO $prov_K FROM prov_tmp WHERE provision = 'K';
						$DELETE FROM prov_tmp2 WHERE provision = $iins_type_tmp;
						
						if((strcmp(trim(iins_type),"P")==0)  &&
						   (strcmp(iins_main,"129") == 0 || strcmp(iins_main,"20")  == 0 ||
						    strcmp(iins_main,"75")  == 0 || strcmp(iins_main,"76")  == 0 || 
						    strcmp(iins_main,"98")  == 0 || strcmp(iins_main,"110") == 0 || 
						    strcmp(iins_main,"111") == 0 || strcmp(iins_main,"23")  == 0 || 
						    strcmp(iins_main,"86")  == 0 ))
						{
							inext++;
						}
						else if (strcmp(trim(iins_type),"P")==0 && strcmp(iins_main,"09") == 0 && prov_K > 0)
						{
							inext++;
						}
						else 
							cnt_prov++;
					}
					printf("--808iins_type[%s] \n",iins_type);
	
				
					/* �W�B�d���I���ۭt�B��춷�M�� 0 */
					if( (strcmp(trim(iins_type),"29")==0) || (strcmp(trim(iins_type),"30")==0) || (strcmp(trim(iins_type),"301")==0) || (strcmp(trim(iins_type),"302")==0) || 
					    (strcmp(trim(iins_type),"238")==0)|| (strcmp(trim(iins_type),"198")==0)|| (strcmp(trim(iins_type),"530")==0))
					{
						mdeduct = 0;
					}

					if( mins_premium < mpure_prem )
						mpure_prem = mins_premium;

					strcpy(ipolicy, trim(ipolicy));
	
					/*1-2  ���q�N��*/
					strcpy(prtstr, CAR_COMPANY);
					strcpy(t_icompany,CAR_COMPANY);
	
					/*3-4  ������c*/
					strncpy(ipolicy_br,&ipolicy[0],2); ipolicy_br[2]='\0';	
					if (ipolicy_br[0] == '\0') 
					{
						strcat(prtstr,"00");
						strcpy(t_iply_br,"00");
					}
					else
					{
						strcat(prtstr,ipolicy_br);
						strcpy(t_iply_br,ipolicy_br);
					}
	
					/*5-16  �O��s��*/
					if (ipolicy[0]=='\0')
					{
						strcat(prtstr,"          ");
						printf("policy is null[%s]\n",ipolicy);
						strcpy(t_iply," ");
					}
					else
					{
						if (strlen(ipolicy) >= 17)  /*���j�O��*/
						{
							strncat(prtstr, ipolicy+3, 10);
							strncpy(objno, &ipolicy[13], 4);
							objno[4]='\0';
							strncpy(t_iply, ipolicy+3, 10);
						}
						else
						{
							strncat(prtstr, ipolicy+3, 10);    
							if (strncmp(chk_157,"Y",1) == 0)  /*�r�ӫO�I��0000*/
								strcpy(objno, "0000");
							else 
								strcpy(objno, "0001");
							objno[4]='\0';
							strncpy(t_iply, ipolicy+3, 10);
						}
						strncpy(dvp_code,&ipolicy[0],2); dvp_code[2]='\0';
					}
					prtstr[14]='\0';
					strcat(prtstr, "  ");
					
					/*21-32  ��O�O��s��*/
					if (strlen(trim(ilast_ply)) == 0)
					{
						strcat(prtstr,"              ");
						strcpy(t_iply_last_br," ");
						strcpy(t_iply_last," ");
					}
					else
					{
						strcat(prtstr, CAR_COMPANY);
						strncpy(ilast_br,&ilast_ply[0],2); ilast_br[2]='\0';
						if (ilast_br[0] == '\0') strcat(prtstr,"00");
						else strcat(prtstr,ilast_br);
						strncat(prtstr, ilast_ply+3, 10);
						strcpy(t_iply_last_br,ilast_br);
						strncpy(t_iply_last,ilast_ply+3, 10);
					}
					prtstr[30]='\0';
					strcat(prtstr, "  ");
		
					/*33-34  �ӫO�a�ϥN��*/
					strcat(prtstr, iply_area);
					strcpy(t_iarea,iply_area);
					prtstr[34]='\0';
		
					/*35-42  �O�I�ͮĶ}�l���*/
					strcpy(dply_begin_c,cm_cdate_str_100(dply_begin));
					cm_split_ymd_100(dply_begin_c,dply_begin_yy,dply_begin_mm,dply_begin_dd);
		
					if (dply_begin_yy[0] == '\0' ) 
					{
						strcat(prtstr,"0000");
						strcpy(t_dply_begin,"0000");
					}
					else 
					{
						strcat(prtstr,itoa(1911+(atoi(dply_begin_yy))));
						strcpy(t_dply_begin,itoa(1911+(atoi(dply_begin_yy))));
					}
					if (dply_begin_mm[0] == '\0') 
					{
						strcat(prtstr,"00");
						strcat(t_dply_begin,"00");
					}
					else 
					{
						strcat(prtstr,dply_begin_mm);
						strcat(t_dply_begin,dply_begin_mm);
					}
					if (dply_begin_dd[0] == '\0') 
					{
						strcat(prtstr,"00");
						strcat(t_dply_begin,"00");
					}
					else 
					{
						strcat(prtstr,dply_begin_dd);
						strcat(t_dply_begin,dply_begin_dd);
					}
	
					/*43-50  �O�I�ͮĲפ���*/
					strcpy(dply_end_c,cm_cdate_str_100(dply_end));
					cm_split_ymd_100(dply_end_c,dply_end_yy,dply_end_mm,dply_end_dd);
		
					if (dply_end_yy[0] == '\0' ) 
					{
						strcat(prtstr,"0000");
						strcpy(t_dply_end,"0000");
					}
					else 
					{
						strcat(prtstr,itoa(1911+(atoi(dply_end_yy))));
						strcpy(t_dply_end,itoa(1911+(atoi(dply_end_yy))));
					}
					if (dply_end_mm[0] == '\0') 
					{
						strcat(prtstr,"00");
						strcat(t_dply_end,"00");
					}
					else 
					{
						strcat(prtstr,dply_end_mm);
						strcat(t_dply_end,dply_end_mm);
					}
					if (dply_end_dd[0] == '\0') 
					{
						strcat(prtstr,"00");
						strcat(t_dply_end,"00");
					}
					else 
					{
						strcat(prtstr,dply_end_dd);
						strcat(t_dply_end,dply_end_dd);
					}
		
					 /*51-54  �O��Ъ���*/
					if ((strlen(rtrim(objno))) == 0)
					{
						strcat(prtstr,"0001");
						strcpy(t_iobjno,"0001");
					}
					else
					{
						strcat(prtstr,objno);
						strcpy(t_iobjno,objno);
					}

					/*55-64  �o��/�s�y�~��*/
					if (strncmp(chk_157,"Y",1) == 0)   /*�s���I��*/
					{
						strcat(prtstr,"000000");   /*�o�Ӧ~��*/
						strcat(prtstr,"0000");     /*�s�y�~*/
						strcat(prtstr,"00");       /*�s�y��*/
						strcpy(t_iissue_ym,"000000");
						strcpy(t_ipro_ym,"000000");
					}
					else
					{
						/*55-60  ��l�o�Ӧ~��*/
						if (iissue_yy[0] == '\0')
						{
							strcat(prtstr,"0000");
							strcpy(t_iissue_ym,"0000");
						}
						else
						{
						 	rfmtlong(atoi(iissue_yy),"&&&&",iissue_yy);
						 	strcat(prtstr,iissue_yy);
							strcpy(t_iissue_ym,iissue_yy);
						}
						if (iissue_mm[0] == '\0') 
						{
							strcat(prtstr,"00");
							strcat(t_iissue_ym,"00"); 
						}
						else
						{
						 	rfmtlong(atoi(iissue_mm),"&&",iissue_mm);
							strcat(prtstr,iissue_mm);
							strcat(t_iissue_ym,iissue_mm);               
						}
	
						/*61-64  �s�y�~*/
						if(ipro_year[0]=='\0')
						{
							strcat(prtstr,"0000");
							strcpy(t_ipro_ym,"0000");
						}
						else
						{
							strcat(prtstr,ipro_year);
							strcpy(t_ipro_ym,ipro_year);
						}
	
						/*65-66  �s�y��*/
						if(qpro_month <= 0)  /* �¨��d�X��A�άOB�檺11�I���i�ର0 */
						{
							strcat(prtstr,"01");
							qpro_month = 1;
							strcat(t_ipro_ym,"01");
						}
						else
						{
							rfmtlong(qpro_month,"&&",qpro_month_c);
							strcat(prtstr,qpro_month_c);
							strcat(t_ipro_ym,qpro_month_c);     
						}
					}
					
		            /* 1000530002�t�P�����N���H�ഫ�t�P�����N�����e */
		            ibrand_new[0]='\0';
		            $OPEN cur_ibrand USING $ibrand;
		            $FETCH cur_ibrand INTO $ibrand_new;
		            if (ibrand_new[0]!='\0') strcpy(ibrand, ibrand_new);
		            $CLOSE cur_ibrand;
		            printf("ibrand[%s]ibrand_new[%s]\n", ibrand, ibrand_new);
		
					if(strncmp(ibrand,"151001",6)==0)   /* �O�o�L���t�� */
						strcpy(ibrand,"15061200");
	
					/*67-74  �t�P�����N��*/
		            /* �O�o�������t�P�����e6�X */
		            if (strncmp(chk_157,"Y",1) == 0)
		            {
		            	strcat(prtstr,"00000000");
		            	strcat(t_ibrand,"00000000");
		            }
		            else
		            {
			            strncpy(ibrand6, ibrand, 6);
			            ibrand6[6]='\0';
			            $SELECT COUNT(*)
			               INTO $cnt
			               FROM cu_code_data
			              WHERE itype = 'B9'
			                AND icode = $ibrand6;
			            if (cnt>0) ibrand[4]=ibrand[5]='0';
						
						if (ibrand[0] == '\0')
							strcat(prtstr,"00000000");
						else
						{
							strcat(prtstr,ibrand);
						}  
						strcpy(t_ibrand,ibrand);                                         
					}
					printf("prtstr=[%s]\n", prtstr);
					
	
					/*75-76  ���������N��*/
					/*201502�s�W�C�Ө��إN���A���إN���^�k*/
					/*�d�ߨt�ƥ��ഫ�e����-icar_type_ori*/
					strcpy(icar_type,TRANS_CAR_TYPE(icar_type));
					if (strncmp(chk_157,"Y",1) == 0) 
						strcat(prtstr,"00");
					else if (icar_type[0] == '\0') 
						strcat(prtstr,"00");
					else if (strcmp(icar_type,"51") == 0) /*���ӬO���|��*/
						strcat(prtstr,"34");
					else strcat(prtstr,icar_type); 
					
					if (strncmp(chk_157,"Y",1) == 0) 
					{
						strcpy(t_icar_type_ori,"00");
						strcpy(t_icar_type,"00");
					}
					else 
					{
						strcpy(t_icar_type_ori,icar_type_ori);
						strcpy(t_icar_type,icar_type);
					}
					
					/*77-78  �����������O�N�� */
					/*|  �����ۥ�| 01|
					  |  ������~| 02|
					  |�@��p�{��| 03|
					  |�h���p�{��| 04|*/
					printf("--�����������O�N��\n");
					if (strncmp(chk_157,"Y",1) == 0)
					{
						strcat(prtstr,"00");
						strcpy(t_icar_type_no,"00");
					}
					else 
					{
						if (f_1090101 > 0)
						{
							if(strcmp(icar_type,"01") == 0 || strcmp(icar_type,"02") == 0 || strcmp(icar_type,"32") == 0 || strcmp(icar_type,"34") == 0 || strcmp(icar_type,"35") == 0)
							{
								/*������L���ڴN�N����~��*/
					        	sprintf(stmp,"SELECT count(*) \
					        	                FROM %s:ori_ins_type \
					        	               WHERE ipolicy = '%s' AND (provision = 'L' OR provision matches '*;L*' OR provision matches '*L;*') ",list[k].dbname,ipolicy);
					        	$PREPARE ply_cnt_L FROM $stmp;
								$EXECUTE ply_cnt_L INTO $cnt_L;
								
						    	if(SQLCODE == SQLNOTFOUND) cnt_L = 0;
		
						        if (cnt_L > 0) 
						        {
						        	strcat(prtstr,"02");
						        	strcpy(t_icar_type_no,"02");
						        }
					        	else 
					        	{
					        		strcat(prtstr,"01");
					        		strcpy(t_icar_type_no,"01");
					        	}
					        	
							}
							else if(strcmp(icar_type,"07") == 0 || strcmp(icar_type,"15") == 0)
							{
								
								$SELECT FIRST 1 nvl(fkind,'')
					        	   INTO $fcar_kind
					        	   FROM ca_taxi_type
					        	  WHERE icard = $icomp_card
					        	  ORDER BY dupdate DESC;
					        	if (SQLCODE == SQLNOTFOUND) strcpy(fcar_kind,"N");
							    /*�h���p�{���A�]���u���j���I�~���g�J���ɡA�Ȭ����p�j���ҧP�_�P�_*/
								if(strcmp(fcar_kind,"Y") == 0) 
								{
									strcat(prtstr,"04");
									strcpy(t_icar_type_no,"04");
								}
					        	else 
					        	{
					        		strcat(prtstr,"03");
					        		strcpy(t_icar_type_no,"03");
					        	}
							}
							else if (strcmp(icar_type,"11") == 0 && equip_cmp(nequipment,"115") == TRUE) /* 1120316006_SC3_�O�o-���N�I���e�{�s�W���@�������������O�N��05�ή��s�X��t�ηs�W���@�����O */
							{
								strcat(prtstr,"05");
								strcpy(t_icar_type_no,"05");
							}
							else 
							{
								strcat(prtstr,"00");
								strcpy(t_icar_type_no,"00");
							}
						}
						else
						{
							strcat(prtstr,"00");
							strcpy(t_icar_type_no,"00");
						}
					}
					
					/*79-83  �Ʈ�q*/
					printf("--�Ʈ�q\n");
					if((strcmp(icar_type,"02") == 0) && (qcylinder > 49) && (strncmp(ibrand_78,"01",2) != 0) && strncmp(chk_157,"Y",1) != 0)
						qcylinder = 49;
					else if( (strcmp(icar_type,"01") == 0) && (qcylinder < 50) && (strncmp(ibrand_78,"01",2) != 0) && strncmp(chk_157,"Y",1) != 0)
						qcylinder = 124;
					else if( (strcmp(icar_type,"32") == 0) && (qcylinder < 251) && (strncmp(ibrand_78,"01",2) != 0) && strncmp(chk_157,"Y",1) != 0)
						qcylinder = 251;
		         	/*�q�ʨT���A�Ʈ𰨳̤p��40*/
		        	if (strcmp(ibrand,"E5011601") == 0 && (qcylinder < 40))
		            	qcylinder = 40;
					
					rfmtlong(qcylinder,"&&&&&",qcylinder_c);
					strcat(prtstr,qcylinder_c);
					t_qcylinder = qcylinder;
					
					/*84-108  ����/������*/
					printf("--����/������\n");
					if ((iengine[0]=='\0' || iengine[0]==' ') && (ibody[0]=='\0' || ibody[0]==' ')) 
					{
						strcat(prtstr,"                         ");
						strcpy(t_iengine," ");
					}
					else if (iengine[0]=='\0' || iengine[0]==' ') 
					{
						strcat(prtstr,ibody);
						strcpy(t_iengine,iengine);
					}
					else 
					{
						strcat(prtstr,iengine);
						strcpy(t_iengine,iengine);
					}
					
					/*109-120  �P�Ӹ��X*/
					printf("--�P�Ӹ��X\n");
					if (itag[0]=='\0' || itag[0]==' ')
					{
						strcat(prtstr,"            ");
						strcpy(t_itag," ");
					}
		        	else 
		        	{
		        		strcat(prtstr,itag);
		        		strcpy(t_itag,itag);
		        	}                
					
					/*121-124  �����ƶq*/
					printf("--�����ƶq\n");
					/*** if (qpt < 5) qpt = 5; ***/
					rfmtdouble((qpt*10),"&&&&", qpt_tmp);
					if ((strlen(rtrim(qpt_tmp))) == 0)
						strcat(prtstr,"0050");
					else
						strcat(prtstr,qpt_tmp);  
					t_qpt = qpt*10;              
		
					/*125-125  �������*/
					printf("--�������\n");
					if (strlen(rtrim(fpt)) == 0) 
					{
						strcat(prtstr," ");
						strcpy(t_fpt," ");
					}
					else 
					{
						strcat(prtstr,fpt);
						strcpy(t_fpt,fpt);
					}                 
		
					/*126-141  �Q�O�I�H���*/
					printf("--�Q�O�I�H���\n");
					strcpy(t_iassured,rtrim(ilicense));
					strcat(prtstr, rtrim(ilicense));           /*126-135  �Q�O�I�H�����Ҹ�/�νs*/
					for(i=0 ; i < (10-strlen(rtrim(ilicense))); i++)
						strcat(prtstr, " ");
		
					if (strcmp(sFassured, "1") == 0 ||
						strcmp(sFassured, "3") == 0 ||
						strcmp(sFassured, "5") == 0)
					{
						if (strlen(rtrim(ibirth_yy)) == 0) 
						{
							strcat(prtstr,"0000");
							strcpy(t_dbirth_y,"0000");
						}
						else
						{
							rfmtlong(atoi(ibirth_yy),"&&&&",ibirth_yy);
							strcat (prtstr, ibirth_yy);       /*136-139  �X�ͦ~��*/
							strcpy(t_dbirth_y,ibirth_yy);    
						}
						if (strlen(rtrim(fsex)) == 0) 
						{
							strcat(prtstr,"0");
							strcpy(t_fsex,"0");
						}
						else 
						{
							strcat(prtstr,fsex);              /*140-140  �ʧO*/
							strcpy(t_fsex,fsex);
						}
						if (strlen(rtrim(fmarriage)) == 0) 
						{
							strcat(prtstr,"0");
							strcpy(t_fmarriage,"0");
						}
						else 
						{
							strcat(prtstr,fmarriage);         /*141-141  �B�çO*/
							strcpy(t_fmarriage,fmarriage);
						}
					}
					else
					{
						strcat(prtstr, "000000"); 
						strcpy(t_dbirth_y,"0000");
						strcpy(t_fsex,"0");
						strcpy(t_fmarriage,"0");
					}
					prtstr[141]='\0';
					
					$EXECUTE CUR_INSGRP INTO $fins_grp,$iri_ins USING $iins_main;
					strcpy(fins_grp,trim(fins_grp));  /*�P�_���l���d*/
					strcpy(iri_ins,trim(iri_ins));    /*�P�_�ѵs�I*/
					
					/*142-144  �h�����u�ݥN��*/
					/*142-142  �����I�h�����u��*/
					printf("--�h�����u��\n");
					if (strncmp(fins_grp,"1",1) == 0 && strcmp(trim(iri_ins),"11") != 0)
					{
						tmp_align=ipdmg_align*(-1);
						$SELECT icode
						   INTO $icode
						   FROM alignment
						  WHERE fclass='4'
						    AND palign=$tmp_align;
						if (SQLCODE==SQLNOTFOUND)
						{
							strcat(prtstr, "0");
							strcpy(t_ipdmg_align,"0");
						}
						else
						{
							strcat(prtstr,rtrim(icode));
							strcpy(t_ipdmg_align,rtrim(icode));
						} 
					}
					else
					{
						strcat(prtstr, "0");
						strcpy(t_ipdmg_align,"0");
					}
						
					/*143-143  �ѵs�I�h�����u��*/
					if (strcmp(trim(iri_ins), "11")==0 )
					{
						tmp_align=ipbrg_align*(-1);
						$SELECT icode
						   INTO $icode
						   FROM alignment
						  WHERE fclass='4'
						    AND palign=$tmp_align;
						if (SQLCODE==SQLNOTFOUND)
						{
							strcat(prtstr, "0");
							strcpy(t_ipbrg_align,"0");
						}
						else
						{
							strcat(prtstr, rtrim(icode));
							strcpy(t_ipbrg_align,rtrim(icode));
						}
					}
					else
					{
						strcat(prtstr, "0");
						strcpy(t_ipbrg_align,"0");
					}
		
					/*144-144  �d���I�h�����u��*/
					if(strncmp(fins_grp,"2",1) == 0)
					{
						tmp_align=iplia_align*(-1);
						$SELECT icode
						   INTO $icode
						   FROM alignment
						  WHERE fclass='4'
						    AND palign=$tmp_align;
		
						if(SQLCODE==SQLNOTFOUND)
						{
							strcat(prtstr, "0");
							strcpy(t_iplia_align,"0");
						}
						else
						{
							strcat(prtstr, rtrim(icode));
							strcpy(t_iplia_align,rtrim(icode));
						} 
					}
					else
					{
						strcat(prtstr, "0");
						strcpy(t_iplia_align,"0");
					}
						
					/*���²v���e�����A�I�اP�_�n��*/
					/* 1130510009_C07_�s�W�q�ʨ��M�ݰӫ~(�O�o���T�ǿ�) */
					printf("--iins_type[%s] iins_main[%s]\n",iins_type,iins_main);
					printf("--���²v�ʤ���\n");
					fcontract_err = 0;
					pdepreciate_year = 0;
					pdepreciate_year_tmp2[0] = '\0';
					if (strncmp(fins_grp,"1",1) == 0 && cnt_iins_main == 1)
					{
						$SELECT pdepreciate::int
						   INTO $pdepreciate_year
						   FROM depreciation_rate a
	                      WHERE drate = (SELECT drate 
	                                       FROM ca_rate_date 
	                                      WHERE icode = $drate_ym
	                                        AND itable = 'depreciation_rate')
	                        AND fcar_class = (SELECT CASE WHEN icar_grp = '1' THEN '3' ELSE fcar_class END
	                                            FROM car_type
	                                           WHERE fclass = '1' 
	                                             AND icode = $icar_type_ori)
	                        AND qperiod_end  = '12';
	
						if (SQLCODE==SQLNOTFOUND) pdepreciate_year = 0;
						pdepreciate_year_tot = pdepreciate_year;
						t_pdepreciate_year = pdepreciate_year_tot;
						printf("pdepreciate_year[%d] pdepreciate_year_tot[%d]\n",pdepreciate_year,pdepreciate_year_tot);
						rfmtlong(pdepreciate_year_tot,"&&&", pdepreciate_year_tmp);
						strcat(pdepreciate_year_tmp2,"+");
						strcat(pdepreciate_year_tmp2,pdepreciate_year_tmp);
						$EXECUTE CUR_CARCLASS INTO $fcar_class_pd USING $icar_type_ori;
						strcpy(fcar_class_pd,trim(fcar_class_pd));
						if ((pdepreciate_year != 25) && fcar_class_pd[0] == '1') fcontract_err = 1;
						else if ((pdepreciate_year != 30) && fcar_class_pd[0] == '2') fcontract_err = 1; 
					}
					else if ((strcmp(iins_main,"01")  == 0 || strcmp(iins_main,"05")  == 0  || 
							  strcmp(iins_main,"09")  == 0 || strcmp(iins_main,"11")  == 0  ||
							  strcmp(iins_main,"110") == 0 || strcmp(iins_main,"111") == 0  ||
							  strcmp(iins_main,"129") == 0 || strcmp(iins_main,"20")  == 0  ||
							  strcmp(iins_main,"23")  == 0 || strcmp(iins_main,"75")  == 0  ||
							  strcmp(iins_main,"86")  == 0 || strcmp(iins_main,"86")  == 0  ||
							  strcmp(iins_main,"98")  == 0 ||
							  strcmp(iins_main,"201") == 0 || strcmp(iins_main,"205") == 0 || 
							  strcmp(iins_main,"209") == 0 || strcmp(iins_main,"211") == 0) && 
						     (strcmp(trim(iins_type), "P")==0))
					{
						$SELECT pdepreciate::int
						   INTO $pdepreciate_year
						   FROM depreciation_rate a
	 					  WHERE drate = (SELECT drate 
	 					                   FROM ca_rate_date 
	 					                  WHERE icode = $drate_ym
	                                        AND itable = 'depreciation_rate')
	                        AND fcar_class   = '6'
	                        AND qperiod_end  = '12';
						if (SQLCODE==SQLNOTFOUND) pdepreciate_year = 0;
						printf("pdepreciate_year[%d] pdepreciate_year_tot[%d]\n",pdepreciate_year,pdepreciate_year_tot);
						pdepreciate_year_tot -= pdepreciate_year;
						t_pdepreciate_year = 0 - pdepreciate_year_tot;
						rfmtlong(pdepreciate_year_tot,"&&&", pdepreciate_year_tot_tmp);
						strcpy(pdepreciate_year_tmp2,"-");
						strcat(pdepreciate_year_tmp2,pdepreciate_year_tot_tmp);
					}
					else if ((strcmp(trim(iins_main), "01")==0  || strcmp(trim(iins_main), "05")==0  ||
						      strcmp(trim(iins_main), "09")==0  || strcmp(trim(iins_main), "08")==0  ||
						      strcmp(trim(iins_main), "11")==0  ||
						      strcmp(trim(iins_main), "201")==0 || strcmp(trim(iins_main), "205")==0 ||
						      strcmp(trim(iins_main), "209")==0 || strcmp(trim(iins_main), "211")==0) &&
						     (strcmp(trim(iins_type), "Q")==0))
					{
						$SELECT pdepreciate::int
						   INTO $pdepreciate_year
						   FROM depreciation_rate a
	 					  WHERE drate = (SELECT drate 
	 					                   FROM ca_rate_date 
	 					                  WHERE icode = $drate_ym
	                                        AND itable = 'depreciation_rate')
	                        AND fcar_class   = '7'
	                        AND qperiod_end  = '12';
						pdepreciate_year_tot -= pdepreciate_year;
						t_pdepreciate_year = 0 - pdepreciate_year_tot;
						if (SQLCODE==SQLNOTFOUND) pdepreciate_year = 0;
						rfmtlong(pdepreciate_year_tot,"&&&", pdepreciate_year_tot_tmp);
						strcpy(pdepreciate_year_tmp2,"-");
						strcat(pdepreciate_year_tmp2,pdepreciate_year_tot_tmp);
					}
					else if ((strcmp(trim(iins_main), "01")==0  || strcmp(trim(iins_main), "05")==0  ||
						      strcmp(trim(iins_main), "09")==0  || strcmp(trim(iins_main), "08")==0  ||
						      strcmp(trim(iins_main), "11")==0  || strcmp(trim(iins_main), "181")==0 ||
						      strcmp(trim(iins_main), "201")==0 || strcmp(trim(iins_main), "205")==0 ||
						      strcmp(trim(iins_main), "209")==0 || strcmp(trim(iins_main), "211")==0) &&
						     (strcmp(trim(iins_type), "M")==0))
					{
						$SELECT pdepreciate::int
						   INTO $pdepreciate_year
						   FROM depreciation_rate a
	 					  WHERE drate = (SELECT drate 
	 					                   FROM ca_rate_date 
	 					                  WHERE icode = $drate_ym
	                                        AND itable = 'depreciation_rate')
	                        AND fcar_class   = '8'
	                        AND qperiod_end  = '12';
	                    if (SQLCODE==SQLNOTFOUND) pdepreciate_year = 0;
						pdepreciate_year_tot -= pdepreciate_year;
						t_pdepreciate_year = 0 - pdepreciate_year_tot;
	                	rfmtlong(pdepreciate_year_tot,"&&&", pdepreciate_year_tot_tmp);
						strcpy(pdepreciate_year_tmp2,"-");
						strcat(pdepreciate_year_tmp2,pdepreciate_year_tot_tmp);
					}
					else if ((strcmp(trim(iins_main), "01")==0  || strcmp(trim(iins_main), "05")==0  ||
						      strcmp(trim(iins_main), "09")==0  || strcmp(trim(iins_main), "08")==0  ||
						      strcmp(trim(iins_main), "11")==0  ||
						      strcmp(trim(iins_main), "201")==0 || strcmp(trim(iins_main), "205")==0 ||
						      strcmp(trim(iins_main), "209")==0 || strcmp(trim(iins_main), "211")==0) &&
						     (strcmp(trim(iins_type), "Z")==0))
					{
						$SELECT pdepreciate::int
						   INTO $pdepreciate_year
						   FROM depreciation_rate a
	 					  WHERE drate = (SELECT drate 
	 					                   FROM ca_rate_date 
	 					                  WHERE icode = $drate_ym
	                                        AND itable = 'depreciation_rate')
	                        AND fcar_class   = '4'
	                        AND qperiod_end  = '12';
	                    if (SQLCODE==SQLNOTFOUND) pdepreciate_year = 0;
						pdepreciate_year_tot -= pdepreciate_year;
						t_pdepreciate_year = 0 - pdepreciate_year_tot;
	                	rfmtlong(pdepreciate_year_tot,"&&&", pdepreciate_year_tot_tmp);
						strcpy(pdepreciate_year_tmp2,"-");
						strcat(pdepreciate_year_tmp2,pdepreciate_year_tot_tmp);
					}
					else 
					{
						strcat(pdepreciate_year_tmp2,"+000");
						t_pdepreciate_year = 0;
					}
						
					strcpy(t_iins_type,trim(iins_type));
					strcpy(t_iins_main,trim(iins_main));
	
					/*145-152  �o�i���߫O�I�����B�O�v�W�����
					  iins_type_main    �O�I�����j��
					  iins_type_dtl     �O�I�����Ӷ�
					  iins_type_develop �I�O�N��
					  iins_type_rule    �I�O����(10/20)
					  frule             �O�_���W���O�v(Y/N)		
					*/
					$EXECUTE CUR_DEVELOP
					    INTO $iins_type_main,$iins_type_dtl,$iins_type_develop,$iins_type_rule,$fcal_way
					   USING $iins_type;
					
					if (SQLCODE==SQLNOTFOUND)
					{
						strcpy(iins_type_main,"@");
						strcpy(iins_type_dtl,"@@");
						strcpy(iins_type_develop,"@@");
						strcpy(iins_type_rule,"20");
						strcpy(frule,"N");
						strcpy(fcal_way," ");
						rc = insert_ca_log("car9995","W",ipolicy,cm_edate_str(dpolicy),"�O�o�I�س]�w���~",userid,v_sMsg);
					}
					strcpy(iins_type_main,trim(iins_type_main));
					strcpy(iins_type_dtl,trim(iins_type_dtl));
					strcpy(iins_type_develop,trim(iins_type_develop));
					strcpy(iins_type_rule,trim(iins_type_rule));
					strcpy(fcal_way,trim(fcal_way));
					
					minjured_cover_tmp = minjured_cover;
		            /* 1000323008-A1��100�~4��1��_�ӫO���N���I�O�o�I�ج�51�B52�B53���C�@�ӤH��˫O�B�A�H�O�B�G���e */
		            if ((f_1000401==1) && (strcmp(trim(iins_type_develop),"51")==0 || strcmp(trim(iins_type_develop),"52")==0 || strcmp(trim(iins_type_develop),"53")==0))
		            {
		                minjured_cover_tmp = mdeath_cover;
		            }
		
					/*�O�v��I�~����ɳW�h�A�O�v�ͮĦ~��*/
					if (fcal_way[0] == '1')
					{
						sprintf(stmt,"SELECT to_char(drate, '%%Y%%m') drate_code FROM ca_rate_date \
						               WHERE itable = 'ca_rate' AND icode = ? ");
					}
					else
					{
						sprintf(stmt,"SELECT to_char(drate, '%%Y%%m') drate_code FROM ca_rate_date \
							           WHERE itable = 'cover_vs_premium' AND icode = ? ");
					}
					$PREPARE CUR_DRATE FROM $stmt;
					
					/*Y:���|�� N:�D���|��*/
					if (iins_type_rule[0] == '1') strcpy(frule,"Y");
					else if (iins_type_rule[0] == '2') strcpy(frule,"N");
					else strcpy(frule,"N");
					
					prov_T = 0;
					$SELECT count(*) INTO $prov_T FROM prov_tmp WHERE provision = 'T';
					
					/*�O�I�����N��-�����I�طf�t�S�w���[���ڶǰe�W��ݽվ�*/
					printf("--�O�I�����N��\n");
					if(strcmp(trim(iins_type),"11")== 0)
					{
						$EXECUTE CUR_CARCLASS INTO $fcar_class USING $icar_type;
						if(SQLCODE == SQLNOTFOUND)
							strcpy(fcar_class,"1");
	
						if( fcar_class[0] == '1' )
							strcpy(iproduct,"112100201011");
						else
							strcpy(iproduct,"122110201011");
						
						if ( mdeduct==0 && f_1090101 == 0)
						{
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"98");
							strcpy(iins_type_develop,"14");
							strcpy(iins_type_rule,"20");
							strcpy(frule, "N");
						}
						else if(fcontract_err == 1)
						{
							if (f_1120501 > 0) {}
							else  strcpy(iins_type_develop , "14");

							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"98");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}
						else if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
						{
							if (f_1120501 > 0) {}
							else  strcpy(iins_type_develop , "14");
							
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"98");
							strcpy(iins_type_rule,"20");
							strcpy(frule, "N");
						}
					}
					else if(strcmp(trim(iins_type),"211")== 0)  /* 1130510009_C07_�s�W�q�ʨ��M�ݰӫ~(�O�o���T�ǿ�) */
					{
						if(fcontract_err == 1)
						{
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"98");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}
						else if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
						{
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"98");
							strcpy(iins_type_rule,"20");
							strcpy(frule, "N");
						}
					}
					else if (strcmp(trim(iins_type), "01") == 0)
					{
						if ((mdeduct == 0 || mdeduct > 20000) && f_1090101 == 0)
						{
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"97");
							strcpy(iins_type_develop,"08");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}
						else if(fcontract_err == 1)
						{
							if (f_1120501 > 0) {}
							else  strcpy(iins_type_develop , "08");
							
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"97");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}
						else if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
						{
							if (f_1120501 > 0) {}
							else  strcpy(iins_type_develop , "08");
							
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"97");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}
					}
					else if (strcmp(trim(iins_type), "201") == 0) /* 1130510009_C07_�s�W�q�ʨ��M�ݰӫ~(�O�o���T�ǿ�) */
					{
						if(fcontract_err == 1)
						{
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"97");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}
						else if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
						{
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"97");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}
					}
					else if (strcmp(trim(iins_type),"05") == 0)
					{
						if ((mdeduct == 0 || mdeduct > 20000) && f_1090101 == 0)
						{
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"97");
							strcpy(iins_type_develop,"08");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}
						if(fcontract_err == 1)
						{
							if (f_1120501 > 0) {}
							else  strcpy(iins_type_develop , "08");
							
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"97");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}
						else if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
						{
							if (f_1120501 > 0) {}
							else  strcpy(iins_type_develop , "08");
							
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"97");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}
					}
					else if (strcmp(trim(iins_type),"205") == 0) /* 1130510009_C07_�s�W�q�ʨ��M�ݰӫ~(�O�o���T�ǿ�) */
					{
						if(fcontract_err == 1)
						{
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"97");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}
						else if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
						{
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"97");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}
					}
					else if (strcmp(trim(iins_type),"09") == 0)
					{
						$EXECUTE CUR_CARCLASS INTO $fcar_class USING $icar_type;
						if(SQLCODE == SQLNOTFOUND) strcpy(fcar_class,"1");
						strcpy(fcar_class,trim(fcar_class));
						printf("mdeduct[%d] fcar_class[%s] provision[%s] icar_type_ori[%s] fcontract_err[%d]\n",mdeduct,fcar_class,provision,icar_type_ori,fcontract_err);
						
						if (mdeduct != 0 && f_1090101 == 0)
						{
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"97");
							strcpy(iins_type_develop, "08");
							strcpy(iins_type_rule , "20");
							strcpy(frule,"N");
						}
						/* ���������I���|���u�� �ۤp��/�ۤp�f */ 
						else if ((strcmp(icar_type,"03") != 0) && (strcmp(icar_type,"21") != 0) &&
						         (strcmp(icar_type,"22") != 0) && (strcmp(icar_type,"04") != 0) &&
						         (strcmp(icar_type,"19") != 0))
						{
							if (f_1120501 > 0) {}
							else  strcpy(iins_type_develop , "08");
							
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"97");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}
						else if(fcontract_err == 1)
						{
							if (f_1120501 > 0) {}
							else  strcpy(iins_type_develop , "08");
							
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"97");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}

						if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
						{
							if (f_1120501 > 0) {}
							else  strcpy(iins_type_develop , "08");
							
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"97");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}
					}
					else if (strcmp(trim(iins_type),"209") == 0) /* 1130510009_C07_�s�W�q�ʨ��M�ݰӫ~(�O�o���T�ǿ�) */
					{
						$EXECUTE CUR_CARCLASS INTO $fcar_class USING $icar_type;
						if(SQLCODE == SQLNOTFOUND) strcpy(fcar_class,"1");
						strcpy(fcar_class,trim(fcar_class));
						printf("mdeduct[%d] fcar_class[%s] provision[%s] icar_type_ori[%s] fcontract_err[%d]\n",mdeduct,fcar_class,provision,icar_type_ori,fcontract_err);
						
						/* ���������I���|���u�� �ۤp��/�ۤp�f */ 
						if ((strcmp(icar_type,"03") != 0) && (strcmp(icar_type,"21") != 0) &&
						    (strcmp(icar_type,"22") != 0) && (strcmp(icar_type,"04") != 0) &&
						    (strcmp(icar_type,"19") != 0))
						{
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"97");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}
						else if(fcontract_err == 1)
						{
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"97");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}
						if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
						{
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"97");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}
					}
					else if (strcmp(trim(iins_type),"31")== 0)
					{
						$EXECUTE CUR_CARCLASS INTO $fcar_class USING $icar_type;
						if(SQLCODE == SQLNOTFOUND) strcpy(fcar_class,"1");
						strcpy(fcar_class,trim(fcar_class));
						
						if( abs(mdeduct) > 0 && f_1090101 == 0)
						{
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"99");
							strcpy(iins_type_develop , "31");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}
						
						if( mdamage_cover == 2 * minjured_cover_tmp )
						{

						}
						else
						{
							if( fcar_class[0] == '1' )
								strcpy(iproduct,"111120461211");
							else
								strcpy(iproduct,"121130461211");
						}
						
						if ( prov_T > 0 && fcar_class[0] == '2')
						{
								if( mdamage_cover == 2 * minjured_cover_tmp )
									strcpy(iproduct,"121130351211");
								else 
									strcpy(iproduct,"121130461211");
						}
						
					}
					else if (strcmp(trim(iins_type),"32")== 0)
					{
						if( abs(mdeduct) > 0 && f_1090101 == 0)
						{
							strcpy(iins_type_main,"Z");
							strcpy(iins_type_dtl,"99");
							strcpy(iins_type_develop , "32");
							strcpy(iins_type_rule , "20");
							strcpy(frule, "N");
						}
						
						if ( prov_T > 0 && fcar_class[0] == '2')
						{
							strcpy(iproduct,"121130361211");
						}
						
					}		
					else if((strcmp(trim(iins_type),"55")==0) &&
					        (strcmp(icar_type,"03") != 0 && strcmp(icar_type,"04") != 0 &&
					         strcmp(icar_type,"05") != 0 && strcmp(icar_type,"06") != 0 &&
					         strcmp(icar_type,"11") != 0 && strcmp(icar_type,"12") != 0 &&
					         strcmp(icar_type,"18") != 0 && strcmp(icar_type,"19") != 0 &&
					         strcmp(icar_type,"20") != 0 && strcmp(icar_type,"21") != 0 &&
					         strcmp(icar_type,"22") != 0 && strcmp(icar_type,"31") != 0 ))
					{
						/*55�I�ثD�ݳo�Ǩ��جҬ��D���|*/
						strcpy(iins_type_main,"Z");
						strcpy(iins_type_dtl,"91");
						strcpy(iins_type_develop, "51");
						strcpy(iins_type_rule , "20");
						strcpy(frule, "N");
					}
	
					/* ���ϨT���ȹB�~�d���O�I  ���|���O�B����>0 */
					if((strncmp(iins_type_develop,"54",2) == 0) && (minjured_cover_tmp < 1 || mdeath_cover < 1 || mdamage_cover < 1))
					{
						strcpy(iins_type_rule , "20");
						strcpy(frule, "N");
					}

					if (strcmp(iins_type,"131") == 0 || strcmp(iins_type,"132") == 0 || strcmp(iins_type,"24") == 0  ||
						strcmp(iins_type,"26") == 0  || strcmp(iins_type,"31") == 0  || strcmp(iins_type,"32") == 0  ||
						strcmp(iins_type,"41") == 0  || strcmp(iins_type,"42") == 0  ||
						strcmp(iins_type,"231") == 0 || strcmp(iins_type,"232") == 0 || 
						strcmp(iins_type,"331") == 0 || strcmp(iins_type,"332") == 0 )
					{
						chk_plia = 0;
						if (sFassured[0]=='1' || sFassured[0]=='3' || sFassured[0]=='5')  /*** �۵M�H ***/
						{
							/* ���d */
							strcpy( sDbirth,     cm_cdate_str_100(dbirth));
							strcpy( sDply_begin, cm_cdate_str_100(dply_begin));
							rc = get_age( sDbirth, sDply_begin, &age, v_sMsg);
							if (atoi(drate_ym) < 99)  /*99�O�v��]�w���ʧO�~�֫Y�Ƥ~�P���|���ۦP�A�Y���e�X���涷�Φ��@�����*/
								rc = get_sex_age_factor( "2", &age, fsex, "99", &psex_age_chk, v_sMsg);
							else 
								rc = get_sex_age_factor( "2", &age, fsex, drate_ym, &psex_age_chk, v_sMsg);
							if (psex_age_lia != psex_age_chk)
							{
								chk_plia = 1;
								rc = insert_ca_log("car9995","W",ipolicy,cm_edate_str(dpolicy),"�ʧO�~�֫Y�Ʋ��`",userid,v_sMsg);
							}
						}
						else chk_plia = 0;
						
						if (chk_plia > 0)
						{
							/*���w��31/32�F131/132���ݦ~�֫Y��*/
							/*231/232�P31/32*/
							if (strcmp(iins_type,"31") == 0  || strcmp(iins_type,"32") == 0 ||
							    strcmp(iins_type,"231") == 0 || strcmp(iins_type,"232") == 0)
							{
								strcpy(iins_type_main,"Z");
								strcpy(iins_type_dtl,"99");
								strcpy(iins_type_rule , "20"); 
								strcpy(frule, "N");
							}
						}
					}
					
					/*���[���ڹw�]��04-�]�����騮�d���|�v�T���[���ڪ��I�O���e*/
					printf("--iins_main[%s],iins_type[%s],fins_grp[%s],iri_ins[%s]\n",iins_main,iins_type,fins_grp,iri_ins);
					if(strncmp(iins_type,"P",1) == 0 || strncmp(iins_type,"Q",1) == 0 ||
					   strncmp(iins_type,"M",1) == 0 || strncmp(iins_type,"Z",1) == 0 ||
					   strncmp(iins_type,"D",1) == 0 || strncmp(iins_type,"K",1) == 0 ||
					   strncmp(iins_type,"S",1) == 0) 
					{
						if (strncmp(fins_grp,"1",1) == 0 && strcmp(trim(iri_ins),"11") != 0)
						{
							/*strcpy(iins_type_develop, "04");*/  /*�w�]�a�����I04*/
						}
						else if (strcmp(trim(iri_ins),"11") == 0)
						{
							strcpy(iins_type_develop, "13");
						}
						else
						{
							strcpy(iins_type_develop, "62");
						}
					}
					else if(strncmp(iins_type,"F",1) == 0 || strncmp(iins_type,"G",1) == 0 ||
					        strncmp(iins_type,"H",1) == 0 || strncmp(iins_type,"J",1) == 0 ||
					        strncmp(iins_type,"L",1) == 0 || strncmp(iins_type,"R",1) == 0 ||
					        strncmp(iins_type,"V",1) == 0)  
					{
						if (strncmp(fins_grp,"1",1) == 0 && strcmp(trim(iri_ins),"11") != 0)
						{
							/*strcpy(iins_type_develop, "04");*/ /*�w�]�a�����I04*/
						}
						else if (strcmp(trim(iri_ins),"11") == 0)
						{
							strcpy(iins_type_develop, "13");
						}
						else
						{
							strcpy(iins_type_develop, "62");
						}
					}
					
					/*145  �O�I�����j��*/
					if (strcmp(trim(iins_type_main),"")==0) 
					{
						strcat(prtstr," ");
						strcpy(t_iins_type_main," ");
					}
					else 
					{
						strcat(prtstr,trim(iins_type_main));
						strcpy(t_iins_type_main,trim(iins_type_main));
					}
					/*146-147  �O�I�����Ӷ�*/
					if (strcmp(trim(iins_type_dtl),"")==0) 
					{
						strcat(prtstr,"  ");
						strcpy(t_iins_type_dtl," ");
					}
					else 
					{
						strcat(prtstr,trim(iins_type_dtl));
						strcpy(t_iins_type_dtl,trim(iins_type_dtl));
					}
					/*148-149  �I�O�N��*/
					if (strcmp(trim(iins_type_develop),"")==0) 
					{
						strcat(prtstr,"  ");
						strcpy(t_iins_type_dev," ");
					}
					else 
					{
						strcat(prtstr,trim(iins_type_develop));
						strcpy(t_iins_type_dev,trim(iins_type_develop));
					}
					/*150-151  �I�O����*/
					if (strcmp(trim(iins_type_rule),"")==0) 
					{
						strcat(prtstr,"20");
						strcpy(t_iins_type_rule,"20");
					}
					else 
					{
						strcat(prtstr,trim(iins_type_rule));
						strcpy(t_iins_type_rule,trim(iins_type_rule));
					}
					/*152  �O�_���W���O�v*/
					if (strcmp(trim(iins_type_rule),"")==0) 
					{
						strcat(prtstr,"N");
						strcpy(t_frule,"N");
					}
					else 
					{
						strcat(prtstr,frule);
						strcpy(t_frule,frule);
					}
					printf("--666666iins_type_main[%s],iins_type_dtl[%s],iins_type_develop[%s],iins_type_rule[%s],frule[%s]\n",
					                iins_type_main,iins_type_dtl,iins_type_develop,iins_type_rule,frule);
					prtstr[152]='\0';
				
					/*153-156  �����[��T��*/
					/*F�Gori_ins_type.adjust_rate  T�Gori_ins_type.(safe_rate+manage_rate)*/
					
					printf("--�����[��T��\n");
					printf("iins_type[%s] adjust_rate[%f] car_t_rate[%f] \n",iins_type,adjust_rate,car_t_rate);
					carfleet_rate = 0;
					/*if (strcmp(iins_type,"T") == 0)
					{
						carfleet_rate = car_t_rate;
					}
					else if (strcmp(iins_type,"F") == 0)
					{
						carfleet_rate = adjust_rate;
					}*/
					/* 113.08.23�D�I���[�I���n�e */
					if (car_t_rate != 0)
					{
						carfleet_rate = car_t_rate;
					}
					else if (adjust_rate != 0)
					{
						carfleet_rate = adjust_rate;
					}
					else 
					{
						carfleet_rate = 0;
					}

					t_padjust_rate = carfleet_rate * 100;
					printf("t_padjust_rate[%d]\n",t_padjust_rate);
					
					if(carfleet_rate < 0)
					{
						strcat(prtstr,"-");
						rfmtdouble((carfleet_rate*100),"&&&", carfleet_rate_tmp);
						strcat(prtstr,carfleet_rate_tmp);
					}
					else
					{
						strcat(prtstr,"+");
						if( carfleet_rate > 0 )
						{
							rfmtdouble((carfleet_rate*100),"&&&", carfleet_rate_tmp);
							strcat(prtstr,carfleet_rate_tmp);
						}
						else
							strcat(prtstr,"000");
					}
					carfleet_rate_tmp[3] = '\0';
					printf("carfleet_rate[%f] carfleet_rate_tmp[%s]\n",carfleet_rate,carfleet_rate_tmp);
					prtstr[156]='\0';
					
					cnt_acc = 0;
					/*���ϥΨ�Y�ƭp��A���O������D�I���N�n��*/
					if (strcmp(trim(iins_type), "38")==0 || strcmp(trim(iins_type), "39")==0 ||
					    strcmp(trim(iins_type), "86")==0 || strcmp(trim(iins_type), "98")==0 ||
					    strcpy(trim(iins_type), "238") == 0)
					{
						sprintf(stmp1,"SELECT count(*) \
						                FROM %s:ori_ins_type a,insurance_type b \
						               WHERE a.iins_type = b.iins_type \
						                 AND a.ipolicy = '%s' \
						                 AND a.iins_type NOT IN ('38','39','86','98','238') \
						                 AND b.fins_grp = '1' \
						                 AND b.iri_ins <> '11';",list[k].dbname,ipolicy);
						
						$PREPARE ply_cnt_main FROM $stmp1;
						$EXECUTE ply_cnt_main INTO $cnt_acc;	    
					}
					else 
					{
						cnt_acc = 0;
					}
					
					/*157-160  �[�˳]�ƫ�W�L���m���椧�T��*/
					/*[���~�s����(���Ҽ{���²v)-�O�o���ߤ��i�����m����]/�O�o���ߤ��i�����m����*/
					/*�����o�]�w�ɳ]�w�������@�����i���m����*/
					printf("--�[�˳]�ƶW�L���m���椧�T��\n");
					if (strncmp(chk_157,"Y",1) == 0)
					{
						strcat(prtstr,"+000");
						t_p_mcar_price = 0;
					}
					else if((strcmp(iins_type,"38") == 0 || strcmp(iins_type,"39") == 0 || strcmp(iins_type,"238") == 0) && cnt_acc == 0)
					{
						strcat(prtstr,"+000");
						t_p_mcar_price = 0;
					}
					else 
					{
						p_mcar_price = mcar_price_ori = qpassenger = 0.0;
						icar_series[0] = '\0';
						printf("ibrand[%s] ipro_year[%s] drate_ym[%s] mcar_price_ori[%f] qpassenger[%f] icar_series[%s]\n",ibrand,ipro_year,drate_ym,mcar_price_ori,qpassenger,icar_series);
						rc = get_ca_car_model(ibrand,ipro_year,drate_ym,&mcar_price_ori,&qpassenger,&icar_series);
						printf("mcar_price_ori[%f] qpassenger[%f] icar_series[%s]\n",mcar_price_ori,qpassenger,icar_series);
						if (strncmp(fins_grp,"1",1) == 0)
						{
							if (mcar_price_ori == 0)
							{
								mcar_price_ori = mcar_price;
								rc = insert_ca_log("car9995","W",ipolicy,cm_edate_str(dpolicy),"�[�˳]�ƫ�W�L���m���椧�T�צ��~",userid,v_sMsg);
								strcat(prtstr,"+000");
								t_p_mcar_price = 0;
							}
							else 
							{
								p_mcar_price = (mcar_price - mcar_price_ori) / mcar_price_ori;
								printf("p_mcar_price[%f] \n",p_mcar_price);
								if((p_mcar_price*100) > 999)
								{
									rc = insert_ca_log("car9995","W",ipolicy,cm_edate_str(dpolicy),"�[�˳]�ƫ�W�L���m���椧�T�צ��~",userid,v_sMsg);
									strcat(prtstr,"+999");
									t_p_mcar_price = 999;
								}
								else if ((p_mcar_price*100) < -999)
								{
									rc = insert_ca_log("car9995","W",ipolicy,cm_edate_str(dpolicy),"�[�˳]�ƫ�W�L���m���椧�T�צ��~",userid,v_sMsg);
									strcat(prtstr,"-999");
									t_p_mcar_price = -999;
								}
								else
								{ 
									rfmtdouble((p_mcar_price*100),"&&&", mcar_price_tmp);
									if (p_mcar_price < 0) strcat(prtstr,"-");
									else strcat(prtstr,"+");
									strcat(prtstr,mcar_price_tmp);
									t_p_mcar_price = p_mcar_price*100;
								}
							}
						}
						else 
						{
							strcat(prtstr,"+000");
							t_p_mcar_price = 0;
						}
						printf("p_mcar_price[%f]\n",p_mcar_price);
					}
	
					/*161-164  �Q�O�I�H�ߴګY�� */
					printf("--�Q�O�I�H�ߴګY��\n");
					if ( strncmp(fins_grp,"1",1) == 0 && strcmp(iri_ins, "11") != 0)
					{
						/*���ϥΨ�Y�ƭp��A���O������D�I���N�n��*/
						if (strcmp(trim(iins_type), "38")==0 || strcmp(trim(iins_type), "39")==0 ||
						    strcmp(trim(iins_type), "86")==0 || strcmp(trim(iins_type), "98")==0 ||
						    strcmp(trim(iins_type), "238")==0 )
						{
							if (cnt_acc > 0)
							{
								if( pdmg_acc < 0 )
								{
									strcat(prtstr,"-");
									rfmtdouble((pdmg_acc*100),"&&&", acc_tmp);
									strcat(prtstr,acc_tmp);
								}
								else
								{
									strcat(prtstr,"+");
									if( pdmg_acc > 0 )
									{
										rfmtdouble((pdmg_acc*100),"&&&", acc_tmp);
										strcat(prtstr,acc_tmp);
									}
									else strcat(prtstr,"000");
								}
								t_pins_acc = pdmg_acc;	
							}
							else 
							{
								pdmg_acc = 0;
								strcat(prtstr,"+000");
								t_pins_acc = 0;
							}
						}
						else 
						{
							if( pdmg_acc < 0 )
							{
								strcat(prtstr,"-");
								rfmtdouble((pdmg_acc*100),"&&&", acc_tmp);
								strcat(prtstr,acc_tmp);
							}
							else
							{
								strcat(prtstr,"+");
								if( pdmg_acc > 0 )
								{
									rfmtdouble((pdmg_acc*100),"&&&", acc_tmp);
									strcat(prtstr,acc_tmp);
								}
								else strcat(prtstr,"000");
							}
							t_pins_acc = pdmg_acc;
						}
					}
					else if ( strncmp(fins_grp,"2",1) == 0 )
					{
						if( strcmp(trim(iins_type), "31")==0  || strcmp(trim(iins_type), "32")==0 ||
						    strcmp(trim(iins_type), "231")==0 || strcmp(trim(iins_type), "232")==0)
						{
							if( plia_acc < 0 )
							{
								if (strcmp(trim(iins_type_develop), "31")==0 || strcmp(trim(iins_type_develop), "32")==0)
								{
									$SELECT ncode
									   INTO $Maxmin
									   FROM cu_code_data
									  WHERE itype='T5'
									    AND icode='2';
									Maxminvalue=atof(Maxmin);
									if (plia_acc <  Maxminvalue)
									{
										plia_acc=Maxminvalue;
									}
								}
								strcat(prtstr,"-");
								rfmtdouble((plia_acc*100),"&&&", acc_tmp);
								strcat(prtstr,acc_tmp);
							}
							else
							{
								strcat(prtstr,"+");
								if( plia_acc > 0 )
								{
									if (strcmp(trim(iins_type_develop), "31")==0 || strcmp(trim(iins_type_develop), "32")==0)
									{
										$SELECT ncode
										   INTO $Maxmin
										   FROM cu_code_data
										  WHERE itype='T5'
										    AND icode='1';
										Maxminvalue=atof(Maxmin);
										if (plia_acc >  Maxminvalue)
										{
											plia_acc=Maxminvalue;
										}
									}
									rfmtdouble((plia_acc*100),"&&&", acc_tmp);
									strcat(prtstr,acc_tmp);
								}
								else strcat(prtstr,"000");
							}
							t_pins_acc = plia_acc;
						}
						else
						{
							if( plia_acc < 0 )
							{
								strcat(prtstr,"-");
								rfmtdouble((plia_acc*100),"&&&", acc_tmp);
								strcat(prtstr,acc_tmp);
							}
							else
							{
								strcat(prtstr,"+");
								if( plia_acc > 0 )
								{
									rfmtdouble((plia_acc*100),"&&&", acc_tmp);
									strcat(prtstr,acc_tmp);
								}
								else strcat(prtstr,"000");
							}
							t_pins_acc = plia_acc;
						}
					}
					else   
					{
						strcat(prtstr, "+999");
						t_pins_acc = 9.99;
					}
	
					/*165-168  �����I�ߴڬ����I��
					  �{����Ƭ�������ߴڬ����Y�ƤΤT�~���ߴڦ��ơA����ഫ�I�Ƭۮt�Y���L�ߴڦ~���I�ơC
					  �i�ߴڬ����I�� = �L�ߴڦ~���I�� + �ߴڦ����I�ơj
					  |�ߴڬ����I��|�ߴڬ����Y��|
					  |     -3     |    -0.6    |
					  |     -2     |    -0.4    |
					  |     -1     |    -0.2    |
					  |      0     |      0     |
					  |      1     |     0.2    |
					  |      2     |     0.4    |
					  |      3     |     0.6    |
					  3�I�H�W�C�W�[�@�I�A�ߴڬ����Y�ƧY�W�[0.2
					  
					  |�ߴڦ~��|�I��|�T�~���ߴڦ���|�I��|
					  |   3�~  | -3 |     1��      |  0 |
					  |   2�~  | -2 |     2��      |  1 |
					  |   1�~  | -1 |     3��      |  2 |
					  |   0�~  |  0 |     4��      |  3 |
					  4���H�W�A�C�W�[�@���ߡA�I�ƧY�W�[�@�I
					*/
					/*�ߴڬ����I��*/
					printf("--�ߴڬ����I��\n");
					qdmg_acc = 0;qdmg_acc_time = 0;qdmg_acc_year = 0;
					qdmg_acc_year_c[0] = '\0';
					qdmg_acc_time_c[0] = '\0';
					
					/*�����I�~�n�ǡA�ѵs����*/
					if ( strncmp(fins_grp,"1",1) == 0 && strcmp(iri_ins, "11") != 0)
					{
						if ((strcmp(trim(iins_type), "38")==0 || strcmp(trim(iins_type), "39")==0 ||
						     strcmp(trim(iins_type), "86")==0 || strcmp(trim(iins_type), "98")==0 || 
						     strcmp(trim(iins_type), "238")==0) && cnt_acc == 0)
						{
							strcat(prtstr,"+0");
							strcat(prtstr,"+0");
							t_qdmg_acc_year = 0;
							t_qdmg_acc_time = 0;
						}
						else
						{
							/*qdmg_acc-�ߴڬ����I��*/
							printf("pdmg_acc[%f] \n",pdmg_acc);
							if(pdmg_acc == 0) qdmg_acc = 0;
							else  qdmg_acc = (pdmg_acc/0.2);
							/*�L�h�T�~�ߴ��`����*/
							/*qdmg_acc_sum  - �T�~���ߴ��`����
							  qdmg_acc_tims - �ߴڦ����I��*/
							printf("qdmg_acc[%f] \n",qdmg_acc);
							if (qdmg_acc_sum == 0) qdmg_acc_time = 0;
							else qdmg_acc_time = qdmg_acc_sum - 1;
							printf("qdmg_acc_time[%f] \n",qdmg_acc_time);
							/*165-166  �L�ߴڦ~���I�� = �ߴڬ����I�� - �ߴڦ����I��*/
							qdmg_acc_year = qdmg_acc - qdmg_acc_time;
							printf("qdmg_acc_year[%f] \n",qdmg_acc_year);
							if (qdmg_acc_year < 0) 
							{
								strcat(prtstr,"-");
								rfmtdouble(qdmg_acc_year,"&", qdmg_acc_year_c);
								strcat(prtstr,qdmg_acc_year_c);
							}
							else 
							{
								strcat(prtstr,"+");
								rfmtdouble(qdmg_acc_year,"&", qdmg_acc_year_c);
								strcat(prtstr,qdmg_acc_year_c);
							}
							t_qdmg_acc_year = qdmg_acc_year;
							
							/*167-168  �ߴڦ����I��*/
							if (qdmg_acc_year < 0) 
							{
								if (qdmg_acc_time == 0) strcat(prtstr,"-");
								else strcat(prtstr,"+");
								rfmtdouble(qdmg_acc_time,"&", qdmg_acc_time_c);
								strcat(prtstr,qdmg_acc_time_c);
								t_qdmg_acc_time = qdmg_acc_time;
							}
							else 
							{
								strcat(prtstr,"+");
								rfmtdouble(qdmg_acc_time,"&", qdmg_acc_time_c);
								strcat(prtstr,qdmg_acc_time_c);
								t_qdmg_acc_time = qdmg_acc_time;
							}
						}
					}
					else 
					{
						strcat(prtstr,"+0");
						strcat(prtstr,"+0");
						t_qdmg_acc_year = 0;
						t_qdmg_acc_time = 0;
					}
					
					/*169-172  �Q�O�I�H�~�֩ʧO�Y��*/
					/*���d-"original_ply".psex_age_lia(��ƪ��sdecimal(15,12)�n��)  ����-"ori_ins_type".psex_age*/
					printf("--�Q�O�I�H�~�֩ʧO�Y��\n");
					sex_age_tmp[0] = '\0';
					if (strcmp(iri_ins, "11") == 0)  /*�ѵs����*/
					{
						strcat(prtstr,"+000");
						t_psex_age = 0;
					}
					else
					{
						/*�۵M�H�~�|���~�֩ʧO�Y��*/	
						if (strcmp(sFassured, "1") == 0 || strcmp(sFassured, "3") == 0 || strcmp(sFassured, "5") == 0)
						{
							if (strncmp(fins_grp,"1",1) == 0)
							{
								if(psex_age_dmg == 0)
								{
									psex_age_tmp = 0;
								
									sprintf(stmp2,"SELECT first 1 psex_age \
									                 FROM %s:ori_ins_type \
									                WHERE ipolicy = '%s' \
									                  AND iins_type IN (SELECT iins_type FROM insurance_type WHERE fins_grp = '1' AND iri_ins <> '11') \
									                  AND psex_age <> 0 ",list[k].dbname,ipolicy);
									$PREPARE ply_sexage FROM $stmp2;
									$EXECUTE ply_sexage INTO $psex_age_tmp;

									if(psex_age_tmp == 0)
									{
										/*Do nothing*/
									}
									else 
									{
										psex_age_dmg = psex_age_tmp;
									}
								}
													
								if( psex_age_dmg < 0 )
								{
									strcat(prtstr,"-");
									rfmtdouble((psex_age_dmg*100),"&&&", sex_age_tmp);
									strcat(prtstr,sex_age_tmp);
								}
								else
								{
									strcat(prtstr,"+");
									if( psex_age_dmg > 0 )
									{
										rfmtdouble((psex_age_dmg*100),"&&&", sex_age_tmp);
										strcat(prtstr,sex_age_tmp);
									}
									else strcat(prtstr,"000");
								}
								t_psex_age = psex_age_dmg;
							}
							else if(strncmp(fins_grp,"2",1) == 0) 
							{
								if (strcmp(iins_type,"131") == 0 || strcmp(iins_type,"132") == 0 || strcmp(iins_type,"24") == 0 ||									strcmp(iins_type,"26") == 0  || strcmp(iins_type,"31") == 0  || strcmp(iins_type,"32") == 0 ||
									strcmp(iins_type,"41") == 0  || strcmp(iins_type,"42") == 0  ||
									strcmp(iins_type,"231") == 0 || strcmp(iins_type,"232") == 0 ||	
									strcmp(iins_type,"331") == 0 || strcmp(iins_type,"332") == 0)
								{
									if( psex_age_lia < 0 )
									{
										strcat(prtstr,"-");
										rfmtdouble((psex_age_lia*100),"&&&", sex_age_tmp);
										strcat(prtstr,sex_age_tmp);
									}
									else
									{
										strcat(prtstr,"+");
										if( psex_age_lia > 0 )
										{
											rfmtdouble((psex_age_lia*100),"&&&", sex_age_tmp);
											strcat(prtstr,sex_age_tmp);
										}
										else strcat(prtstr,"000");
									}
									t_psex_age = psex_age_lia;
								}
								else 
								{
									strcat(prtstr,"+000");
									t_psex_age = 0;
								}
							}
							else 
							{
								strcat(prtstr,"+000");
								t_psex_age = 0;
							}
						}
						else 
						{
							strcat(prtstr,"+000");
							t_psex_age = 0;
						}
					}
	
					/*173-176  ���²v�ʤ���-�~���� */
					strcat(prtstr,pdepreciate_year_tmp2);
					prtstr[176] = '\0';
		
					prov_U = 0;
					$SELECT count(*) INTO $prov_U FROM prov_tmp WHERE provision = 'U';
					/*177-184  ubi�ӫ~�O�v�]�l */
					printf("--ubi\n");
					/*�ߤ@�@�iUBI 00007V9025252*/
					/*177  �O�v�p��O�_�Ҷq���{��*/
					if(prov_U > 0)
						strcat(prtstr,"1");
					else 
						strcat(prtstr,"0");
					/*177  �O�v�p��O�_�Ҷq�r�p�ɬq*/
					if(prov_U > 0)
						strcat(prtstr,"2");
					else 
						strcat(prtstr,"0");
					/*177  �O�v�p��O�_�Ҷq�r�p���q*/
					if(prov_U > 0)
						strcat(prtstr,"2");
					else 
						strcat(prtstr,"0");
					/*177  �O�v�p��O�_�Ҷq��L�r�p�欰*/
					if(prov_U > 0)
						strcat(prtstr,"2");
					else 
						strcat(prtstr,"0");
					/*181-184  �����r�p�H�ϥβߺD���覡(�����˸m�Bapp�B���׫O�i�����B��L)*/
					if(prov_U > 0)
						strcat(prtstr,"1222");
					else 
						strcat(prtstr,"0000");
						
					if(prov_U > 0)
						strcpy(t_ubi_data,"12221222");
					else 
						strcpy(t_ubi_data,"00000000");
	
					/*185-214  �O�I���B���*/
					/*185-194  �C�@�H��˫O�B*/
					printf("--�O�I���B���\n");
					if (cnt_iins_main == 1)
					{
						if (strncmp(fins_grp,"1",1) == 0) /*�����I������˫O�B ��38�B39*/
						{
							strcat(prtstr,"+000000000");
							t_minjured_cover = 0;
						}
						else 
						{
							if (strcmp(trim(iins_type), "34") == 0)
							{
								if(mdeath_cover < 0 ) strcat(prtstr,"-");
								else strcat(prtstr,"+");
								
								rfmtlong(mdeath_cover,"&&&&&&&&&",minjured_c);
								strcat(prtstr,minjured_c); 
								t_minjured_cover = mdeath_cover;
							}
							else 
							{
								if(minjured_cover_tmp < 0 ) strcat(prtstr,"-");
								else strcat(prtstr,"+");
								
								rfmtlong(minjured_cover_tmp,"&&&&&&&&&",minjured_c);
								strcat(prtstr,minjured_c); 
								t_minjured_cover = minjured_cover_tmp;
							}
						}
					}
					else 
					{
						strcat(prtstr,"+000000000");
						t_minjured_cover = 0;
					}
	
					/*195-204   �C�@���`�O�B*/
					if( cnt_iins_main == 1)
					{
						if (strncmp(fins_grp,"1",1) == 0) /*�����I���񦺤`*/
						{
							strcat(prtstr,"+000000000");
							t_mdeath_cover = 0;
						}
						else if( strcmp(trim(iins_type), "31") == 0  || strcmp(trim(iins_type), "131") == 0 ||
						         strcmp(trim(iins_type), "231") == 0 || strcmp(trim(iins_type), "331") == 0 )
						{
							if(minjured_cover < 0 ) strcat(prtstr,"-");
							else strcat(prtstr,"+");
	
							rfmtlong(minjured_cover,"&&&&&&&&&",minjured_c);
							strcat(prtstr,minjured_c);    /* �ĤT�H�d�����`�M��˫O�B�ۦP */
							t_mdeath_cover = minjured_cover;
						}
						else if (strcmp(trim(iins_type), "34") == 0)
						{
							if(mdamage_cover < 0 ) strcat(prtstr,"-");
							else strcat(prtstr,"+");
							
							rfmtlong(mdamage_cover,"&&&&&&&&&",mdeath_c);
							strcat(prtstr,mdeath_c);
							t_mdeath_cover = mdamage_cover;
						}
						else
						{
							if( mdeath_cover < 0 ) strcat(prtstr,"-");
							else strcat(prtstr,"+");
	
							rfmtlong(mdeath_cover,"&&&&&&&&&",mdeath_c);
							strcat(prtstr,mdeath_c);
							t_mdeath_cover = mdamage_cover;
						}
					}
					else 
					{
						strcat(prtstr,"+000000000");
						t_mdeath_cover = 0;
					}
	
					/*�ƬG�O�B���[���ڤ]�n���*/
					/*PQMZ���±���-�~�n�^��*/
					/*09+K && E���� �λs�y�~��L�ΥX�t�~��p��O�B*/
					printf("qpro_month[%d] ipro_year[%s]\n",qpro_month,ipro_year);
					sprintf(dpro,"%s/01/%s",itoa(qpro_month),ipro_year);
					strcpy(dpro,trim(dpro));
					printf("-1846 chk_cover_per[%d] mdamage_cover[%d] chk_cover_Z[%d]\n ",chk_cover_per,mdamage_cover,chk_cover_Z);
					if (cnt_iins_main == 1 )
					{
						if ((chk_cover_per > 0 || chk_cover_Z > 0))
						{
							strcpy(dissue_100,cm_from_infdate_100(dissue));
							strcpy(dpro_100,cm_from_infdate_100(dpro));
							printf("dissue_100[%s] dpro_100[%s]\n",dissue_100,dpro_100);
							ldissue = cm_ymd_cdate(dissue_100);
							ldpro = cm_ymd_cdate(dpro_100);
							printf("ldissue[%d] ldpro[%d]\n",ldissue,ldpro);
	
							if (strcmp(trim(icar_series),"10") ==0)
							{
								if(DiffMonth(ldissue,ldpro)>3)
									strcpy(dissue_pro_tmp,dpro);
								else 
									strcpy(dissue_pro_tmp,dissue);
							}
							else 
							{
								if(DiffMonth(ldissue,ldpro)>6)
									strcpy(dissue_pro_tmp,dpro);
								else 
									strcpy(dissue_pro_tmp,dissue);
							}
	
							mcover_ori = 0;mcover_prov = 0;
							printf("fins_cal_way[%s],iins_type[%s],fProvision_c[%s],dissue_pro_tmp[%s],drate_ym[%s],icar_type_ori[%s],mcar_price[%f],qply_period[%d],dply_begin[%ld],dply_end[%ld],mcover_ori[%d] \n",
							        fins_cal_way,iins_type,fProvision_c,dissue_pro_tmp,drate_ym,icar_type_ori,mcar_price,qply_period,dply_begin,dply_end,mcover_ori);
							/*���[���±��ګ�O�B*/
							rc = get_dmg_cover(iins_type,fProvision_c,dissue_pro_tmp,drate_ym,icar_type_ori,mcar_price,dply_begin,&mcover_prov);
							if( rc != M_CM_OK) 
							{
								mcover_prov = 0;
								rc = insert_ca_log("car9995","W",ipolicy,cm_edate_str(dpolicy),"���[���±��ګ�O�B",userid,v_sMsg);
							}
							/*����«O�B*/
							rc = get_dmg_cover(iins_type," ",dissue_pro_tmp,drate_ym,icar_type_ori,mcar_price,dply_begin,&mcover_ori);
							printf("iins_type[%s] mcover_ori[%d] mcover_prov[%d] \n",iins_type,mcover_ori,mcover_prov);
							if( rc != M_CM_OK) 
							{
								mcover_ori = 0;
								rc = insert_ca_log("car9995","W",ipolicy,cm_edate_str(dpolicy),"����«O�B���~",userid,v_sMsg);
							}
							/*����«O�B��0�A�����«�W���O�B�A��D�I�O�B��1000*/
							if(mcover_ori == 0 && mcover_prov == 0) 
							{
								mcover_ori = 1000;
							}
							else if(mcover_ori == 0 && mcover_prov > 0) 
							{
								mcover_ori = 1000;
							}
						}
						else 
						{
							mcover_ori = mcover_prov = 0;
						}
					}
					/*205-214   �C�@�ƬG�O�B*/
					if (cnt_iins_main == 1 )
					{
						if (strcmp(trim(iins_type),"10") == 0 && f_1090701 == 0)  /*109007001�e10�I�ؤ���O�B*/
						{
							strcat(prtstr,"+000000000");
							t_mdamage_cover = 0;
						}
						else if (chk_cover_per > 0 || chk_cover_Z > 0)
						{
							mcover_prov_tmp = mdamage_cover - mcover_ori;
							if (mcover_prov_tmp < 0)
							{
								if( mdamage_cover < 0 ) strcat(prtstr,"-");
								else strcat(prtstr,"+");
								mcover_prov_tmp = 0;
								rfmtlong(mdamage_cover,"&&&&&&&&&",mcover_ori_c);
								strcat(prtstr,mcover_ori_c);
								t_mdamage_cover = mdamage_cover;
							}
							else 
							{
								if( mcover_ori < 0 ) strcat(prtstr,"-");
								else strcat(prtstr,"+");
								if( mcover_ori > 999999999 )
									rfmtlong(mcover_ori,"999999999",mcover_ori_c);
								else 
									rfmtlong(mcover_ori,"&&&&&&&&&",mcover_ori_c);
								strcat(prtstr,mcover_ori_c);
								t_mdamage_cover = mcover_ori;
							}
							
							printf("mcover_prov_tmp[%d],mdamage_cover[%d],mcover_ori[%d] \n",mcover_prov_tmp,mdamage_cover,mcover_ori);
						}
						else
						{
							printf("-1908 chk_cover_per[%d] mdamage_cover[%d] chk_cover_Z[%d]\n ",chk_cover_per,mdamage_cover,chk_cover_Z);
							if( mdamage_cover < 0 ) strcat(prtstr,"-");
							else strcat(prtstr,"+");
				
							if( mdamage_cover > 999999999 )
								mdamage_cover = 999999999;
				
							rfmtlong(mdamage_cover,"&&&&&&&&&",mdamage_c);
							strcat(prtstr,mdamage_c);
							t_mdamage_cover = mdamage_cover;
						}
					}
					else if (strcmp(trim(iins_type),"P")==0 || strcmp(trim(iins_type),"Q")==0 || strcmp(trim(iins_type),"M")==0 || strcmp(trim(iins_type),"Z")==0)
					{
						printf("--PQMMZ\n");
						if (chk_cover_K > 0)
						{
							strcat(prtstr,"+000000000");
							t_mdamage_cover = 0;
						}
						else 
						{
							if( mcover_prov_tmp < 0 ) 
							{
								/*�O�B���t���n�ۦP*/
								strcat(prtstr,"-");
								prtstr[194] = '-';
								prtstr[184] = '-';
							}
							else strcat(prtstr,"+");
				
							if( mcover_prov_tmp > 999999999 )
								rfmtlong(mcover_prov_tmp,"&&&&&&&&&",mcover_prov_tmp_c);
							else 
								rfmtlong(mcover_prov_tmp,"&&&&&&&&&",mcover_prov_tmp_c);
							strcat(prtstr,mcover_prov_tmp_c);
							t_mdamage_cover = mcover_prov_tmp;
						}
					}
					else
					{
						strcat(prtstr,"+000000000");
						t_mdamage_cover = 0;
					}
					
					/*215-217  �O�٭���*/
					/*�S�w�I��  �O�B�O���Ʀ���*/
					printf("--�O�٭���\n");
					iins_mult = 0;
					if (strcmp(trim(iins_type), "31")==0 || strcmp(trim(iins_type), "231")==0) /*�ƬG�O�B/��˫O�B*/
					{
						iins_mult = mdamage_cover/minjured_cover;	
					}
					else if (strcmp(trim(iins_type), "109")==0)  /*(�ƬG�O�B-��˫O�B)/��˫O�B*/
					{
						iins_mult = (mdamage_cover-minjured_cover)/minjured_cover;
					}
					else if (strcmp(trim(iins_type), "301")==0)  /*2��*/
					{
						iins_mult = 2;
					}
					else if (strcmp(trim(iins_type), "302")==0)  /*2��*/
					{
						iins_mult = 2;
					}
					else if (strcmp(trim(iins_type), "131")==0 || strcmp(trim(iins_type), "331")==0)  /*�ƬG�O�B/��˫O�B*/
					{
						iins_mult = mdamage_cover/minjured_cover;
					}
					else if (strcmp(trim(iins_type), "124")==0)  /*2�� */
					{
						iins_mult = 2;
					}
					else if (strcmp(trim(iins_type), "34")==0)  /*�O�B�ǰe���վ� 1��*/
					{
						iins_mult = 1;
					}
					else if (strncmp(fins_grp,"1",1) != 0)
					{
						printf("iins_type[%s] fins_grp[%s] mdeath_cover[%ld]\n",iins_type,fins_grp,mdeath_cover);
						iins_mult = mdamage_cover/mdeath_cover;
					}
					else
						iins_mult = 0;
					
					if (iins_mult > 99)
					{
						strcat(prtstr,"+99");
						t_iins_mult = 99;
					} 
					else 
					{
						rfmtlong(iins_mult,"&&",iin_mult_c);
						strcat(prtstr,"+");
						strcat(prtstr,iin_mult_c);
						t_iins_mult = iins_mult;
					}
		
					/*218-225  �ۭt�B*/
					/*
					  ������O�N��
					  1:�s�x��
					  2:�N��(�ۭt�B���� 1:300/5000/7000 2:5000/8000 3:5000/8000/10000 4:3000/5000/8000)
					  3:�ʤ���
					  4:��L
					  5:�L�ۭt�B				
					*/
					printf("--�ۭt�B\n");
					if (strcmp(iins_type,iins_main) != 0)
					{
						mdeduct = 0;
						strcat(prtstr,"5");	
						strcpy(t_fmdeduct,"5");
					}
					else 
					{
						if(strcmp(trim(iins_type), "71")==0 || strcmp(trim(iins_type), "72")==0)
						{  
							strcat(prtstr,"1"); /*�s�x��*/
							mdeduct = 10000;
							strcpy(t_fmdeduct,"1");
						}
						else if(strcmp(trim(iins_type), "31")==0  || strcmp(trim(iins_type), "32")==0 ||
						        strcmp(trim(iins_type), "231")==0 || strcmp(trim(iins_type), "232")==0 )							    
						{
							if( mdeduct == 0 )
							{
								strcat(prtstr,"5");
								strcpy(t_fmdeduct,"5");
							}
							else
							{
								strcat(prtstr,"1");
								strcpy(t_fmdeduct,"1");
							}
						}
						else if(strcmp(trim(iins_type), "131")==0 || strcmp(trim(iins_type), "132")==0 || 
						        strcmp(trim(iins_type), "331")==0 || strcmp(trim(iins_type), "332")==0)
						{
							strcat(prtstr,"2");  /*�אּ�N��*/
							strcpy(t_fmdeduct,"2");
						    /*�ۭt�B�N��4 3000/5000/8000*/
						}
						else if(strcmp(trim(iins_type), "11")==0 || strcmp(trim(iins_type), "211")==0)
						{
							if( mdeduct == 0 )
							{
								strcat(prtstr,"5");
								strcpy(t_fmdeduct,"5");
							}
							else
							{
								strcat(prtstr,"3");
								strcpy(t_fmdeduct,"3");
							}
						}
						else if(strcmp(trim(iins_type), "08")==0)
						{
							if( mdeduct == 8 ) /*��L*/
							{
								strcat(prtstr,"4");
								strcpy(t_fmdeduct,"4");
								mdeduct = 0;
							}
							else 
							{
								strcat(prtstr,"5");
								strcpy(t_fmdeduct,"5");
							}
						}
						else if(strcmp(trim(iins_type), "01")==0 || strcmp(trim(iins_type), "201")==0)
						{
							if( mdeduct == 0 )
							{
								strcat(prtstr,"5");  /*�L�ۭt�B*/
								strcpy(t_fmdeduct,"5");
							}
							else if( mdeduct < 10 )
							{
								strcat(prtstr,"2");  /*�N��*/
								strcpy(t_fmdeduct,"2");
							}
							else 
							{
								strcat(prtstr,"1"); /*�s�x��*/
								strcpy(t_fmdeduct,"1");
							}
						}
						else if(strcmp(trim(iins_type), "05")==0 || strcmp(trim(iins_type), "205")==0)
						{
							if( mdeduct == 0 )
							{
								strcat(prtstr,"5");  /*�L�ۭt�B*/
								strcpy(t_fmdeduct,"5");
							}
							else if( mdeduct < 10 )
							{
								strcat(prtstr,"2");  /*�N��*/
								strcpy(t_fmdeduct,"2");
							}
							else 
							{
								strcat(prtstr,"1"); /*�s�x��*/
								strcpy(t_fmdeduct,"1");
							}
						}
						else if (strcmp(trim(iins_type),"09") == 0 || strcmp(trim(iins_type),"209") == 0)
						{
							if (mdeduct == 0)
							{
								strcat(prtstr,"5");  /*�L�ۭt�B*/
								strcpy(t_fmdeduct,"5");
							}
							else
							{
								strcat(prtstr,"1");  /*�s�x��*/
								strcpy(t_fmdeduct,"5");
							}
						}
						else if (strcmp(trim(iins_type),"18") == 0)
						{
							strcat(prtstr,"3");	/*�ʤ���*/
							strcpy(t_fmdeduct,"3");
							if (mdeduct == 5010 || mdeduct == 6010 || mdeduct == 7510)
								mdeduct = 10;
							else if (mdeduct == 6020 || mdeduct == 7520)
								mdeduct = 20;
						}
						else if (strcmp(trim(iins_type),"28") == 0)
						{
							if (mdeduct == 0)
							{
								strcat(prtstr,"5"); /*�L�ۭt�B*/
								strcpy(t_fmdeduct,"5");
							}
							else
							{
								strcat(prtstr,"3"); /*�ʤ���*/
								strcpy(t_fmdeduct,"3");
							}
						}
						else if (strcmp(trim(iins_type),"98") == 0)
						{
							strcat(prtstr,"5"); /*�L�ۭt�B*/
							strcpy(t_fmdeduct,"5");
							mdeduct = 0;        /*���B��0*/
			
						}
						else if (strcmp(trim(iins_type),"86") == 0)
						{
							strcat(prtstr,"5"); /*�L�ۭt�B*/
							strcpy(t_fmdeduct,"5");
							mdeduct = 0;        /*���B��0*/
			
						}
						else if (strcmp(trim(iins_type),"96") == 0)
						{
							strcat(prtstr,"5"); /*�L�ۭt�B*/
							strcpy(t_fmdeduct,"5");
							mdeduct = 0;        /*���B��0*/
						}
						else if (strcmp(trim(iins_type),"129") == 0)
						{
							if (mdeduct == 0)
							{
								strcat(prtstr,"5"); /*�L�ۭt�B*/
								strcpy(t_fmdeduct,"5");
							}
							else
							{
								strcat(prtstr,"3"); /*�ʤ���*/
								strcpy(t_fmdeduct,"3");
							}
						}
						else if(strcmp(trim(iins_type), "122")==0 )
						{
							if( mdeduct == 0 )
							{
								strcat(prtstr,"5"); /*�L�ۭt�B*/
								strcpy(t_fmdeduct,"5");
							}
							else if( mdeduct < 10 )
							{
								strcat(prtstr,"2"); /*�N��*/
								strcpy(t_fmdeduct,"2");
							}
							else
							{
								strcat(prtstr,"1"); /*�s�x��*/
								strcpy(t_fmdeduct,"1");
							}
						}
						else if(strcmp(trim(iins_type), "113")==0)
						{
							if( mdeduct == 0 )
							{
								strcat(prtstr,"5"); /*�L�ۭt�B*/
								strcpy(t_fmdeduct,"5");
							}
							else
							{
								strcat(prtstr,"1"); /*�s�x��*/
								strcpy(t_fmdeduct,"1");
							}
						}	
						else if(strcmp(trim(iins_type), "128")==0 )
						{
							if( mdeduct == 0 )
							{
								strcat(prtstr,"5"); /*�L�ۭt�B*/
								strcpy(t_fmdeduct,"5");
							}
							else
							{
								strcat(prtstr,"3"); /*�ʤ���*/
								strcpy(t_fmdeduct,"3");
							}
						}
						else if(strcmp(trim(iins_type), "149")==0 || strcmp(trim(iins_type), "249")==0 )
						{
							if( mdeduct == 0 )
							{
								strcat(prtstr,"5"); /*�L�ۭt�B*/
								strcpy(t_fmdeduct,"5");
							}
							else
							{
								strcat(prtstr,"1"); /*�s�x��*/
								strcpy(t_fmdeduct,"1");
							}
						}
						else if(strcmp(trim(iins_type), "176")==0 || strcmp(trim(iins_type), "177")==0 || strcmp(trim(iins_type), "178")==0)
						{
							if( mdeduct == 0 )
							{
								strcat(prtstr,"5");
								strcpy(t_fmdeduct,"5");
							}
							else
							{
								strcat(prtstr,"3");
								strcpy(t_fmdeduct,"3");
							}
						}
						else 
						{
							strcat(prtstr,"5");
							strcpy(t_fmdeduct,"5");
						}
	
						if(((strcmp(trim(iins_type_develop),"13") == 0) || (strcmp(trim(iins_type_develop),"35") == 0) ||
						    (strcmp(trim(iins_type_develop),"54") == 0) || (strcmp(trim(iins_type_develop),"62") == 0) ||
						    (strcmp(trim(iins_type_develop),"33") == 0) || (strcmp(trim(iins_type_develop),"04") == 0)) && 
						    (strcmp(trim(iins_type),"28")  != 0 && strcmp(trim(iins_type),"128") != 0 &&
						     strcmp(trim(iins_type),"113") != 0 && strcmp(trim(iins_type),"149") != 0 && strcmp(trim(iins_type),"249") != 0 && 
						     strcmp(trim(iins_type),"176") != 0 && strcmp(trim(iins_type),"177") != 0 && strcmp(trim(iins_type),"178") != 0  ))
							mdeduct = 0;
					}
					rfmtlong(mdeduct,"&&&&&&&",mdeduct_c);
					strcat(prtstr,mdeduct_c);
					t_mdeduct = mdeduct;
		
					/*226-235  ñ��O�O*/
					/*236-245  �«O�O*/
					printf("--ñ��/�«O�O \n");
					coefficient = 0.0;
					ifleet = 0;
					mprem_prov = 0;
					mprem_pure_prov = 0;
					t_coefficient = 0;
					if (cnt_iins_main == 1)
					{
						mprem_base = 0.0;      
						         
						printf("icar_type_ori[%s] iins_type[%s] mdeduct[%d] minjured_cover[%d] mdeath_cover[%d] mdamage_cover[%d]\n",icar_type_ori,iins_type,mdeduct,minjured_cover,mdeath_cover,mdamage_cover);
						
						mcover1 = minjured_cover;
						mcover2 = mdeath_cover;
						mcover3 = mdamage_cover;
						/*�򥻯«O�O(�v)*/
						printf("--�I�ذ򥻯«O�O \n");
						if(strcmp(trim(iins_type),"29") == 0 || strcmp(trim(iins_type),"124") == 0)
						{
							sprintf(stmp_ins1,"SELECT mdamage_cover \
							                     FROM %s:ori_ins_type \
							                    WHERE ipolicy = '%s' AND iins_type = '32' ",list[k].dbname,ipolicy);
							$PREPARE ply_ins_32 FROM $stmp_ins1;
							$EXECUTE ply_ins_32 INTO $mcover1;	    

							if(SQLCODE==SQLNOTFOUND) mcover1 = 0;
						}
						else if(strcmp(trim(iins_type),"109") == 0)
						{
							sprintf(stmp_ins2,"SELECT mdamage_cover \
							                     FROM %s:ori_ins_type \
							                    WHERE ipolicy = '%s' AND iins_type = '31' ",list[k].dbname,ipolicy);
							$PREPARE ply_ins_31 FROM $stmp_ins2;
							$EXECUTE ply_ins_31 INTO $mcover1;	  
							
							if(SQLCODE==SQLNOTFOUND) mcover1 = 0;    
							mcover2 = mdeath_cover;
						}
						else if(strcmp(trim(iins_type),"34") == 0 || strcmp(trim(iins_type),"87") == 0 || strcmp(trim(iins_type),"115") == 0)
						{
							sprintf(stmp_ins3,"SELECT mcover \
							                     FROM %s:ori_ins_cover \
							                    WHERE ipolicy = '%s' AND iins_type = '%s' AND icover_type = '001'",list[k].dbname,ipolicy,iins_type);
							$PREPARE ply_ins_34_1 FROM $stmp_ins3;
							$EXECUTE ply_ins_34_1 INTO $mcover1;	
							
							if(SQLCODE==SQLNOTFOUND) mcover1 = 0;

							sprintf(stmp_ins4,"SELECT mcover \
							                     FROM %s:ori_ins_cover \
							                    WHERE ipolicy = '%s' AND iins_type = '%s' AND icover_type = '002'",list[k].dbname,ipolicy,iins_type);
							$PREPARE ply_ins_34_2 FROM $stmp_ins4;
							$EXECUTE ply_ins_34_2 INTO $mcover2;	
							if(SQLCODE==SQLNOTFOUND) mcover2 = 0;
						}
	
						v_sMsg[0] = '\0';
						
						prov_J = 0;
						$SELECT count(*) INTO $prov_J FROM prov_tmp WHERE provision = 'J';
						if (prov_J > 0)
						{
							rc = get_mprem_base(fcal_way,icar_type_ori,iins_type,qpt,fpt,drate_ym,qply_period,dply_begin,
								                dissue,ipro_year,qpro_month,qday,mdeduct_ori,mcover1,mcover2,mcover3,qpassenger,mcar_price,ibrand,"J",&mprem_base,v_sMsg);
						}
						else 
						{
							rc = get_mprem_base(fcal_way,icar_type_ori,iins_type,qpt,fpt,drate_ym,qply_period,dply_begin,
								                dissue,ipro_year,qpro_month,qday,mdeduct_ori,mcover1,mcover2,mcover3,qpassenger,mcar_price,ibrand," ",&mprem_base,v_sMsg);
						}
						printf("mprem_base[%f]\n",mprem_base);
						printf("mdamage_cover[%d] \n ",mdamage_cover);
						if( rc != M_CM_OK) 
						{
							char s_sMsg[256];							
							strcpy(s_sMsg, "�򥻫O�O���~");							
                            if(v_sMsg[0] != '\0')							
							{
								trim_tail_white(v_sMsg);
                                strcat(s_sMsg, v_sMsg);
							}
							mprem_base = 0.0;
							/*rc = insert_ca_log("car9995","W",ipolicy,cm_edate_str(dpolicy),"�򥻫O�O���~",userid,v_sMsg);*/
							rc = insert_ca_log("car9995","W",ipolicy,cm_edate_str(dpolicy),s_sMsg ,userid,v_sMsg);
						}
	
						if ((cnt_prov_t == cnt_prov) || 
						    (cnt_prov_t == cnt_prov && chk_cover_Z > 0))
						{
							printf("--�I��ñ��/�«O�O1 \n");
							if( mins_premium < 0 ) strcat(prtstr,"-");
							else strcat(prtstr,"+");
							rfmtlong(mins_premium,"&&&&&&&&&",mins_premium_c);
							strcat(prtstr,mins_premium_c);
							
							if( mpure_prem < 0 ) strcat(prtstr,"-");
							else strcat(prtstr,"+");
							rfmtlong(mpure_prem,"&&&&&&&&&",mpure_prem_c);
							strcat(prtstr,mpure_prem_c);
							
							if( mprem_base < 0 ) strcat(prtstr,"-");
							else if ( mprem_base == 0 )
							{
								if( mpure_prem < 0 ) strcat(prtstr,"-");
								else strcat(prtstr,"+");
							}
							else strcat(prtstr,"+");
							rfmtdouble((mprem_base*10000),"&&&&&&&&&&&&&",mprem_base_c);
							strcat(prtstr,mprem_base_c);
							
							t_mprem = mins_premium;
							t_mprem_pure = mpure_prem;
							t_mprem_pure_base = mprem_base;
							
							printf("mprem_base[%f] mprem_base_c[%s]\n",mprem_base,mprem_base_c);
							mprem_prov = mprem_cal = mins_premium;
							mprem_pure_prov = mprem_pure_cal = mpure_prem;
						}
						else 
						{
							printf("--�I��ñ��/�«O�O2 \n");
							/*if (mins_premium_n == mins_premium) mins_premium_n = mins_premium;*/
							mins_premium_tmp = 0;
							if (mins_premium_n == mins_premium) 
								mpure_prem_n = mpure_prem;
							else if(abs(mins_premium - mins_premium_n) < abs(mpure_prem - mpure_prem_n))
							{
								mins_premium_tmp = (mpure_prem - mpure_prem_n) - (mins_premium - mins_premium_n);
								mpure_prem_n += mins_premium_tmp;
							}
							else mins_premium_tmp = 0;
							
							if( mins_premium_n < 0 ) strcat(prtstr,"-");
							else strcat(prtstr,"+");
							rfmtlong(mins_premium_n,"&&&&&&&&&",mins_premium_n_c);
							strcat(prtstr,mins_premium_n_c);
		
							if( mpure_prem_n < 0 ) strcat(prtstr,"-");
							else strcat(prtstr,"+");
							rfmtlong(mpure_prem_n,"&&&&&&&&&",mpure_prem_n_c);
							strcat(prtstr,mpure_prem_n_c);
							
							if( mprem_base < 0 ) strcat(prtstr,"-");
							else if ( mprem_base == 0 )
							{
								if( mpure_prem < 0 ) strcat(prtstr,"-");
								else strcat(prtstr,"+");
							}
							else
								strcat(prtstr,"+");
							rfmtdouble((mprem_base*10000),"&&&&&&&&&&&&&",mprem_base_c);
							strcat(prtstr,mprem_base_c);
							
							t_mprem = mins_premium_n;
							t_mprem_pure = mpure_prem_n;
							t_mprem_pure_base = mprem_base;
							
							printf("mprem_base[%f] mprem_base_c[%s]\n",mprem_base,mprem_base_c);
							mprem_prov = mprem_cal = mins_premium_n;
							mprem_pure_prov = mprem_pure_cal = mpure_prem_n;
						}
					}
					else 
					{
						printf("--���[����ñ��/�«O�O \n");
						
						if ((strcmp(trim(iins_type),"Z") == 0) ||
						    (strcmp(trim(iins_type),"P") == 0 && inext > 0))
						{		
						    strcat(prtstr,"+");
						    strcat(prtstr,"000000000");		    
						    strcat(prtstr,"+");
						    strcat(prtstr,"000000000");
						    strcat(prtstr,"+");
						    strcat(prtstr,"0000000000000");
						    mprem_prov += 0;
						    mprem_pure_prov+=0;
						    t_mprem = 0;
							t_mprem_pure = 0;
							t_mprem_pure_base = 0;
						}
						else if (cnt_prov_t == cnt_prov) 
						{
							printf("-main-iins_type[%s],iins_main[%s]\n",iins_type,iins_main);	
							mprem_prov = mins_premium - mins_premium_n - mprov_tmp;
							mprem_pure_prov = mpure_prem - mpure_prem_n - mprov_pure_tmp;
							
							if( mprem_prov < 0 ) strcat(prtstr,"-");
							else strcat(prtstr,"+");
							rfmtlong(mprem_prov,"&&&&&&&&&",mprem_prov_c);
						    strcat(prtstr,mprem_prov_c);
						    
						    if( mprem_pure_prov < 0 ) strcat(prtstr,"-");
							else strcat(prtstr,"+");
							rfmtlong(mprem_pure_prov,"&&&&&&&&&",mprem_pure_prov_c);
						    strcat(prtstr,mprem_pure_prov_c);
						    
						    if( mprem_pure_prov < 0 ) strcat(prtstr,"-");
							else strcat(prtstr,"+");
						    strcat(prtstr,"0000000000000");
						    
						    t_mprem = mprem_prov;
							t_mprem_pure = mprem_pure_prov;
							t_mprem_pure_base = 0;
						}	
						else 
						{
							printf("-prov-iins_type[%s],iins_main[%s]\n",iins_type,iins_main);	
							$EXECUTE CUR_CARCLASS INTO $fcar_class USING $icar_type_ori;
							if(SQLCODE == SQLNOTFOUND) strcpy(fcar_class,"1");
							strcpy(fcar_class,trim(fcar_class));
							v_sMsg[0] = '\0';
							ifleet = 0;
							rc = get_prov_coefficient( iins_type,drate_ym,fcar_class,iins_main,icar_type_ori,qprovision,qpt,
							                           mdeduct,minjured_cover,mdamage_cover,carfleet_rate,pcar_price,pubi_acc,
							                           mcar_price,mequipment,
							                           &ifleet,&coefficient,&chk_prov,v_sMsg);
							printf("--rc[%d] coefficient[%f] ifleet[%d] chk_prov[%s] \nv_sMsg[%s]\n",rc,coefficient,ifleet,chk_prov,v_sMsg);
							if( rc != M_CM_OK)
							{
								rc = insert_ca_log("car9995","W",ipolicy,cm_edate_str(dpolicy),"���[���ګY�Ʀ��~",userid,v_sMsg);
								t_coefficient = 0;
							}
							if (strcmp(chk_prov,"N") == 0) 
							{
								mprem_prov = 0;	
								mprem_pure_prov = 0;
								t_coefficient = 0;
							}
							else 
							{
								t_coefficient = coefficient;
								rc = get_mcoefficient(coefficient,ifleet,&mprem_cal,&mprem_pure_cal,&mprem_prov,&mprem_pure_prov);
								printf("mprem_cal[%d],mprem_pure_cal[%d]\n",mprem_cal,mprem_pure_cal);
								printf("mprem_prov[%d],mprem_pure_prov[%d]\n",mprem_prov,mprem_pure_prov);
							}
							rfmtlong(mprem_prov,"&&&&&&&&&",mprem_prov_c);
							if (mprem_prov < 0) strcat(prtstr,"-");
							else strcat(prtstr,"+");
						    strcat(prtstr,mprem_prov_c);
							rfmtlong(mprem_pure_prov,"&&&&&&&&&",mprem_pure_prov_c);
							if (mprem_pure_prov < 0) strcat(prtstr,"-");
							else strcat(prtstr,"+");
						    strcat(prtstr,mprem_pure_prov_c);
						    if (mprem_pure_prov < 0) strcat(prtstr,"-");
							else strcat(prtstr,"+");
						    strcat(prtstr,"0000000000000");
						    t_mprem = mprem_prov;
							t_mprem_pure = mprem_pure_prov;
							t_mprem_pure_base = 0;
							
							mprov_tmp += mprem_prov;
							mprov_pure_tmp += mprem_pure_prov;
						}
					}
	
					prem_subtot0 += mprem_prov;                 /*�u�ݫ�O�O*/
					prem_subtot1 += mprem_pure_prov;            /*�«O�O*/
					prem_subtot2 += mprem_base_prov;            /*�򥻯«O�O*/
					printf("prem_subtot0[%d],prem_subtot1[%d]\n",prem_subtot0,prem_subtot1);
					prtstr[259] = '\0';
	
					if (strcmp(iins_type,iins_main) == 0)
					{
						strcpy(iproduct_main,trim(iproduct));
					}
					else if (strcmp(iins_type,iins_main) != 0)
					{
						printf("get iprovision product \n");
						$EXECUTE CUR_CARCLASS INTO $fcar_class_p using $icar_type;
						strcpy(fcar_class_p,trim(fcar_class_p));
						printf("*******iproduct--iins_type[%s],iins_main[%s],fcar_class_p[%s] \n",iins_type,iins_main,fcar_class_p);
						printf("iproduct[%s],iproduct_main[%s] \n",iproduct,iproduct_main);
						if((strcmp(iins_type,"F") == 0) || (strcmp(iins_type,"G") == 0) || (strcmp(iins_type,"T") == 0))
						{
							strcpy(iproduct,iproduct_main);
						}
						else
						{
							
							if(strncmp(ibrand_78,"01",2) == 0)
							{
								strcpy(foil_electric,"1"); /*�q��*/
							}
							else
							{
								strcpy(foil_electric,"0"); /*�o��*/
							}

							if(((strcmp(iins_type,"L") == 0)  || (strcmp(iins_type,"R") == 0)) &&
							   ((strcmp(icar_type,"01") == 0) || (strcmp(icar_type,"02") == 0) || 
							    (strcmp(icar_type,"32") == 0) || (strcmp(icar_type,"34") == 0) || (strcmp(icar_type,"35") == 0)))
							strcpy(fcar_class_p,"3");
							
							$SELECT iproduct 
							   INTO $iproduct
							   FROM ca_provision_product
							  WHERE iprovision  = $iins_type
							    AND iins_type   = $iins_main
							    AND fclass      = $fcar_class_p
								AND foil_electric = $foil_electric;
							printf("SQLCODE[%d] iproduct[%s] \n",SQLCODE,iproduct);
							if (SQLCODE == SQLNOTFOUND)
							{
								if(strcmp(iins_type,"J") == 0)
								{
									$SELECT iproduct 
									   INTO $iproduct
								       FROM ca_provision_product
								      WHERE iprovision = $iins_type
								        AND iins_type  = $iins_main
								        and fclass     = '0'
								        AND icar_type  = $icar_type_ori
										AND foil_electric = $foil_electric;
								}
								else
								{
									$SELECT iproduct 
									   INTO $iproduct
								       FROM ca_provision_product
								      WHERE iprovision = $iins_type
								        AND iins_type  = $iins_main
								        and fclass     = '0'
								        AND icar_type  = $icar_type
										AND foil_electric = $foil_electric;
							    }
							    printf("SQLCODE[%d] iproduct[%s] \n",SQLCODE,iproduct);
								if (SQLCODE == SQLNOTFOUND)
								{
									if (strcmp(iins_type,"Z") == 0)
										strcpy(iproduct,"122111961011");
									else 
										strcpy(iproduct,"000000000000");
								}
								else
								{
									strcpy(iproduct,trim(iproduct));
									strcat(iproduct,"11");
								}
							}
							else
							{
								strcpy(iproduct,trim(iproduct));
								strcat(iproduct,"11");
							}
						}
					}
					printf("iproduct[%s] \n",iproduct);
					strcpy(t_iproduct,iproduct);
					
					/*260-271  �ӫ~�N�X*/
					printf("--�ӫ~�N�X \n");
					strcat(prtstr,iproduct);
					printf("prtstr[%s]\n",prtstr);
					printf("1926\n");
					
					strncpy(iproduct_tmp,iproduct+3,2);
					iproduct_tmp[2] = '\0';
					printf("iproduct_tmp[%s] \n",iproduct_tmp);
					if (strcmp(iproduct_tmp,"10") == 0) 
					{
						mprem_10 += mprem_prov;
						mprem_pure_10 += mprem_pure_prov;
					}
					else if (strcmp(iproduct_tmp,"11") == 0) 
					{
						mprem_11 += mprem_prov;
						mprem_pure_11 += mprem_pure_prov;
					}
					else if (strcmp(iproduct_tmp,"12") == 0) 
					{
						mprem_12 += mprem_prov;
						mprem_pure_12 += mprem_pure_prov;
					}
					else if (strcmp(iproduct_tmp,"13") == 0) 
					{
						mprem_13 += mprem_prov;
						mprem_pure_13 += mprem_pure_prov;
					}
					else if (strcmp(iproduct_tmp,"28") == 0) 
					{
						mprem_28 += mprem_prov;
						mprem_pure_28 += mprem_pure_prov;
					}
					
					printf("iins_type[%s]\n",iins_type);
					printf("mprem_10[%d]\n",mprem_10);
					printf("mprem_11[%d]\n",mprem_11);
					printf("mprem_12[%d]\n",mprem_12);
					printf("mprem_13[%d]\n",mprem_13);
					printf("mprem_28[%d]\n",mprem_28);
	
					/*272-277  �O�v��I�~�� */
					/*** 55���O�B�W���ӫ~200610�ͮ� 951026 ***/
					printf("--�O�v��I�~�� \n");
					if ((f_1000401==0) && (strcmp(trim(iins_type),"55")==0))
					{
						if (minjured_cover > 400000 || minjured_cover < 20000)
							strcpy(drate_code,"200610");
						else if (minjured_cover == 20000 || minjured_cover == 40000 ||
								 minjured_cover == 60000 || minjured_cover == 80000 ||
								 minjured_cover == 100000 || minjured_cover == 200000 ||
								 minjured_cover == 300000 || minjured_cover == 400000)
						{
							if (mdeath_cover == (minjured_cover * 5))
								strcpy(drate_code,"200601");
							else
								strcpy(drate_code,"200610");
						}
						else
							strcpy(drate_code,"200610");
						if ((mdeath_cover > 6000000) ||
							(mdeath_cover == minjured_cover))
						{
							strcpy(drate_code,"200607");
						}
					}
					else if (strcmp(trim(iins_type),"26")==0 ||
							 strcmp(trim(iins_type),"71")==0 || strcmp(trim(iins_type),"72")==0)
						strcpy(drate_code,"200601");
					else if (strcmp(trim(iins_type),"41")==0 || strcmp(trim(iins_type),"42")==0 ||
							 strcmp(trim(iins_type),"81")==0 || strcmp(trim(iins_type),"82")==0)
						strcpy(drate_code,"200511");
					else if (strcmp(trim(iins_type),"51")==0 && strncmp(drate_ym,"16",2)==0)
						strcpy(drate_code,"200107");
					else if (strcmp(trim(iins_type),"30")==0 && strcmp(trim(iins_type_rule),"33")!=0)
						strcpy(drate_code,"200107");
					else
					{
						printf("1964 drate_ym[%s]\n",drate_ym);
						$EXECUTE CUR_DRATE INTO $drate_code
					       USING $drate_ym;
					    if (SQLCODE==SQLNOTFOUND) strcpy(drate_code,"200107");
					    strcpy(drate_code,"200107");
					    printf("drate_code[%s],drate_ym[%s] \n",drate_code,drate_ym);
					    printf("1968\n");
						
					}
					strcat(prtstr,drate_code);
					strcpy(t_drate_ym,drate_code);
	
					/*278-283  ñ��~��*/
					printf("--ñ��~�� \n");
					strcpy(dpolicy_c,cm_cdate_str_100(dpolicy));
					cm_split_ymd_100(dpolicy_c,dply_yy,dply_mm,tmp_dd);
					if (dply_yy[0] == '\0') 
					{
						strcat(prtstr,"0000");
						strcpy(t_dpolicy_ym,"0000");
					}
					else 
					{
						strcat(prtstr,itoa(1911 + (atoi (dply_yy))));
						strcpy(t_dpolicy_ym,itoa(1911 + (atoi (dply_yy))));
					}
					if (dply_mm[0] == '\0') 
					{
						strcat(prtstr,"00");
						strcat(t_dpolicy_ym,"00");
					}
					else 
					{
						strcat(prtstr,dply_mm);
						strcat(t_dpolicy_ym,dply_mm);
					}
	
					/*284-285  �q���O�N��*/
					printf("--�q���O�N�� \n");
					strcat(prtstr,bzfrom);
					strcpy(bzfrom_before,bzfrom);
					strcpy(t_bzfrom,bzfrom);
					prtstr[285] = '\0';
	
					/*286-293  ��ƻs�e��*/
					printf("--��ƻs�e�� \n");
					strcat(prtstr,ttday_yy);
					strcat(prtstr,ttday_mm);
					strcat(prtstr,ttday_dd);
					strcpy(t_dsend,ttday_yy);
					strcat(t_dsend,ttday_mm);
					strcat(t_dsend,ttday_dd);
					
					/* UBI���{�� */
					if (atoi(data_yyyymm) >= 202101)
					{
						strcat(prtstr,"0000000000");
					}
					
					fprintf(fptr,"%s\n",prtstr);
					count1++;
					count2++;
					policy_cnt++;
					printf("prtstr[%s]\n",prtstr);
					cnt_iins_main = 0;
					
					printf("show data \n");
					printf("t_ipolicy[%s] \n",t_ipolicy);
					
					printf("data_yyyymm[%s],ipolicy[%s],t_icompany[%s],t_iply_br[%s],t_iply[%s],t_iply_last_br[%s],t_iply_last[%s] \n",
					        data_yyyymm,ipolicy,t_icompany,t_iply_br,t_iply,t_iply_last_br,t_iply_last);
					printf("t_iarea[%s],t_dply_begin[%s],t_dply_end[%s],t_iobjno[%s],t_iissue_ym[%s],t_ipro_ym[%s],t_ibrand[%s],t_icar_type_ori[%s],t_icar_type[%s],t_icar_type_no[%s] \n",
					        t_iarea,t_dply_begin,t_dply_end,t_iobjno,t_iissue_ym,t_ipro_ym,t_ibrand,t_icar_type_ori,t_icar_type,t_icar_type_no);
					printf("t_qcylinder[%d],t_iengine[%s],t_itag[%s],t_qpt[%d],t_fpt[%s],t_iassured[%s],t_dbirth_y[%s],t_fsex[%s],t_fmarriage[%s] \n",
					        t_qcylinder,t_iengine,t_itag,t_qpt,t_fpt,t_iassured,t_dbirth_y,t_fsex,t_fmarriage);
					printf("t_ipdmg_align[%s],t_ipbrg_align[%s],t_iplia_align[%s],t_iins_type[%s],t_iins_main[%s],t_iins_type_main[%s],t_iins_type_dtl[%s],t_iins_type_dev[%s],t_iins_type_rule[%s],t_frule[%s] \n",
					        t_ipdmg_align,t_ipbrg_align,t_iplia_align,t_iins_type,t_iins_main,t_iins_type_main,t_iins_type_dtl,t_iins_type_dev,t_iins_type_rule,t_frule);
					printf("t_padjust_rate[%d],t_p_mcar_price[%d],t_pins_acc[%f],t_qdmg_acc_year[%d],t_qdmg_acc_time[%d],t_psex_age[%f],t_pdepreciate_year[%d],t_ubi_data[%s] \n",
					        t_padjust_rate,t_p_mcar_price,t_pins_acc,t_qdmg_acc_year,t_qdmg_acc_time,t_psex_age,t_pdepreciate_year,t_ubi_data);
					printf("t_iins_mult[%d],t_fmdeduct[%s],t_mdeduct[%d],t_mprem[%d],t_mprem_pure[%d],t_mprem_pure_base[%f] \n",
					        t_iins_mult,t_fmdeduct,t_mdeduct,t_mprem,t_mprem_pure,t_mprem_pure_base);
					printf("t_coefficient[%f],t_iproduct[%s],t_drate_ym[%s],t_dpolicy_ym[%s],t_bzfrom[%s],t_dsend[%s] \n",
					        t_coefficient,t_iproduct,t_drate_ym,t_dpolicy_ym,t_bzfrom,t_dsend);
	
					/* �d�s��� 00-66 */
					sprintf(stmt,"INSERT INTO %s:ca_dev_ply_edr \
					                     (data_yyyymm,idata,ipolicy,iendorse,icompany,iply_br,iply,iply_last_br,iply_last, \
			                              iedr_br,iedr,iarea,dedr_begin,dedr_end,dply_begin,dply_end,iobjno,iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no, \
			                              qcylinder,iengine,itag,qpt,fpt,iassured,dbirth_y,fsex,fmarriage, \
			                              ipdmg_align,ipbrg_align,iplia_align,iins_type,iins_main,iins_type_main,iins_type_dtl,iedr_type_ori,iedr_type,iins_type_dev,iins_type_rule,frule, \
			                              padjust_rate,p_mcar_price,pins_acc,qdmg_acc_year,qdmg_acc_time,psex_age,pdepreciate_year,ubi_data, \
			                              minjured_cover,mdeath_cover,mdamage_cover,mdamage_cover_bak,mdamage_cover_aft, \
			                              iins_mult,fmdeduct,mdeduct,mprem,mprem_pure,mprem_pure_base, \
			                              mprem_bak,mprem_pure_bak,mprem_pure_base_bak,mprem_aft,mprem_pure_aft,mprem_pure_base_aft, \
			                              coefficient,iproduct,drate_ym,dendorse_ym,dpolicy_ym,bzfrom,dsend) \
					               VALUES(?,'W',?,' ',?,?,?,?,?, \
					                      ' ',' ',?,' ',' ',?,?,?,?,?,?,?,?,?, \
					                      ?,?,?,?,?,?,?,?,?, \
					                      ?,?,?,?,?,?,?,' ',' ',?,?,?, \
					                      ?,?,?,?,?,?,?,?, \
					                      ?,?,?,0,0, \
					                      ?,?,?,?,?,?, \
					                      0,0,0,0,0,0, \
					                      ?,?,?,' ',?,?,?)",list[k].dbname);
					$PREPARE insert_ply_edr FROM $stmt;
					$EXECUTE insert_ply_edr using $data_yyyymm,$ipolicy,$t_icompany,$t_iply_br,$t_iply,$t_iply_last_br,$t_iply_last,
					                              $t_iarea,$t_dply_begin,$t_dply_end,$t_iobjno,$t_iissue_ym,$t_ipro_ym,$t_ibrand,$t_icar_type_ori,$t_icar_type,$t_icar_type_no,
					                              $t_qcylinder,$t_iengine,$t_itag,$t_qpt,$t_fpt,$t_iassured,$t_dbirth_y,$t_fsex,$t_fmarriage,
					                              $t_ipdmg_align,$t_ipbrg_align,$t_iplia_align,$t_iins_type,$t_iins_main,$t_iins_type_main,$t_iins_type_dtl,$t_iins_type_dev,$t_iins_type_rule,$t_frule,
					                              $t_padjust_rate,$t_p_mcar_price,$t_pins_acc,$t_qdmg_acc_year,$t_qdmg_acc_time,$t_psex_age,$t_pdepreciate_year,$t_ubi_data,
					                              $t_minjured_cover,$t_mdeath_cover,$t_mdamage_cover,
					                              $t_iins_mult,$t_fmdeduct,$t_mdeduct,$t_mprem,$t_mprem_pure,$t_mprem_pure_base,
					                              $t_coefficient,$t_iproduct,$t_drate_ym,$t_dpolicy_ym,$t_bzfrom,$t_dsend;
				}
			}
		}
		printf("777 \n");
		if (count1 > 0 && count2 > 0)
		{
			/*99:�O�O�`�p*/
			/* 1-16 */
			prtstr[16] = '\0';
			/* 17-34 */
			strcat(prtstr, sformat_trade(" ", 2, 18));
	
			/* 35-42  �O�I�ͮĶ}�l���*/
			if (dply_begin_yy[0] == '\0' ) strcat(prtstr,"0000");
			else strcat(prtstr,itoa(1911+(atoi(dply_begin_yy))));
			if (dply_begin_mm[0] == '\0') strcat(prtstr,"00");
			else strcat(prtstr,dply_begin_mm);
			if (dply_begin_dd[0] == '\0') strcat(prtstr,"00");
			else strcat(prtstr,dply_begin_dd);             
	
			/* 43-50  �O�I�ͮĲפ���*/
			if (dply_end_yy[0] == '\0') strcat(prtstr,"0000");
			else strcat(prtstr,itoa(1911+(atoi(dply_end_yy))));
			if (dply_end_mm[0] == '\0') strcat(prtstr,"00");
			else strcat(prtstr,dply_end_mm);
			if (dply_end_dd[0] == '\0') strcat(prtstr,"00");
			else strcat(prtstr,dply_end_dd);           
			
			/* 51-78 */
			strcat(prtstr, sformat_trade(" ", 2, 28));
			/* 79-83 */
			strcat(prtstr, "00000");
			/* 84-120 */
			strcat(prtstr, sformat_trade(" ", 2, 37));
			/* 121-124 */
			strcat(prtstr, "0000");
			/* 125-147 */
			strcat(prtstr, sformat_trade(" ", 2, 23));
			/* 148-151 */
			strcat(prtstr, "99");
			/* 150-160 */
			strcat(prtstr, sformat_trade(" ", 2, 11));
			/* 161-176 */
			strcat(prtstr, "+000");
			strcat(prtstr, "+0");
			strcat(prtstr, "+0");
			strcat(prtstr, "+000");
			strcat(prtstr, "+000");
			/* 177-184 */
			strcat(prtstr, sformat_trade(" ", 2, 8));
			/* 185-217 */
			strcat(prtstr, "+000000000");
			strcat(prtstr, "+000000000");
			strcat(prtstr, "+000000000");
			strcat(prtstr, "+00");
			/* 218 */
			strcat(prtstr, " ");
			/* 225-259 */
			strcat(prtstr, "0000000");
			
			if(prem_subtot0 < 0 ) strcat(prtstr,"-");
			else strcat(prtstr,"+");
			rfmtlong(prem_subtot0, "&&&&&&&&&", prem_subtot_c); /*�h���u�ݫ�*/
			strcat(prtstr,prem_subtot_c);
	
			if(prem_subtot1 < 0 ) strcat(prtstr,"-");
			else strcat(prtstr,"+");
			rfmtlong(prem_subtot1, "&&&&&&&&&", prem_subtot_m); /*�«O�O */
			strcat(prtstr,prem_subtot_m);
			
			strcat(prtstr,"+0000000000000");
			
			/* 260-277 */
			strcat(prtstr, sformat_trade(" ", 2, 18));  
	
			/* 278-283 */
			if (dply_yy[0] == '\0') strcat(prtstr,"0000");
			else strcat(prtstr,itoa (1911 + (atoi (dply_yy))));
			if (dply_mm[0] == '\0') strcat(prtstr,"00");
			else strcat(prtstr,dply_mm);
	
			/* 284-293 */
			strcat(prtstr, sformat_trade(" ", 2, 10)); 
			prtstr[293]='\0';
			if (atoi(data_yyyymm) >= 202101)
			{
				strcat(prtstr,"0000000000");
				prtstr[303]='\0';
			}
			fprintf(fptr,"%s\n",prtstr);
			
			/*99�[�`���p����*/
			/*count1++;*/
			count2 = 0;
			prem_subtot0 = prem_subtot1 = 0;
			/*99�[�`���s�J ca_dev_ply_edr*/
		}
		$CLOSE scur_ply1;
		$FREE scur_ply1;
		$DROP TABLE prov_tmp;
		$DROP TABLE prov_tmp2;
	}
	fclose(fptr);
	
	rfmtlong(prem_total,"&&&&&&&&&&&&",prem_c);
	rfmtlong(pure_total,"&&&&&&&&&&&&",prem_m);
	printf("**************************************************\n");
	res = getApHome(aphome);
	if (res<0)
	{
		printf("In sigalrmcatcher func==>read config file error!!\n");
		exit(1);
	}

	if (count1==0)
		fprintf(fptr_err,"%s\n","�L���!!");
	else
	{
        /* �s����� */
        $SELECT iquota INTO $iquota FROM officer WHERE iofficer=$userid;

		rtoday(&Today);     /* get today's datetime */
		printf("### Today[%d],ipolicy_br[%s],prem_total[%d],count1[%d]\n",
					Today  ,  ipolicy_br  ,  prem_total  ,  count1);

		strcpy(Taipei_FullName,get_full_dbname("00"));

		$WHENEVER SQLERROR CONTINUE;

		sprintf(stmt,"DELETE FROM %s:ca_develop \
					   WHERE iclass='9995' AND ibranch=? AND data_yyyymm = ?",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus1 FROM $stmt;
		$EXECUTE insert_cus1 USING $DBName,$data_yyyymm;
		
		sprintf(stmt,"INSERT INTO %s:ca_develop \
		                (iquota,data_yyyymm,iclass,dsend,ibranch, \
                         product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
						VALUES(?,?,'9995',?,?,'99','C',?,?,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus99 FROM $stmt;
		$EXECUTE insert_cus99
			USING $iquota,$data_yyyymm,$Today,$DBName,$prem_total,$count1,$pure_total;
			
		sprintf(stmt,"INSERT INTO %s:ca_develop \
		                (iquota,data_yyyymm,iclass,dsend,ibranch, \
                         product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
						VALUES(?,?,'9995',?,?,'10','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus10 FROM $stmt;
		$EXECUTE insert_cus10
			USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_10,$mprem_pure_10;
			
		sprintf(stmt,"INSERT INTO %s:ca_develop \
		                (iquota,data_yyyymm,iclass,dsend,ibranch, \
                         product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
						VALUES(?,?,'9995',?,?,'11','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus11 FROM $stmt;
		$EXECUTE insert_cus11
			USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_11,$mprem_pure_11;
			
		sprintf(stmt,"INSERT INTO %s:ca_develop \
		                (iquota,data_yyyymm,iclass,dsend,ibranch, \
                         product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
						VALUES(?,?,'9995',?,?,'12','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus12 FROM $stmt;
		$EXECUTE insert_cus12
			USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_12,$mprem_pure_12;
			
		sprintf(stmt,"INSERT INTO %s:ca_develop \
		                (iquota,data_yyyymm,iclass,dsend,ibranch, \
                         product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
						VALUES(?,?,'9995',?,?,'13','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus13 FROM $stmt;
		$EXECUTE insert_cus13
			USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_13,$mprem_pure_13;
			
		sprintf(stmt,"INSERT INTO %s:ca_develop \
		                (iquota,data_yyyymm,iclass,dsend,ibranch, \
                         product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
						VALUES(?,?,'9995',?,?,'28','C',?,0,?,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus28 FROM $stmt;
		$EXECUTE insert_cus28
			USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_28,$mprem_pure_28;
	}
	printf("END\n");
	fclose(fptr_err);
	return SUCCESS;

errexit:
	printf("usrid=%s SOLCODE=%d sqlca.sqlerrm=%s\n",userid,SQLCODE,sqlca.sqlerrm);
	sprintf(errmsg,"userid=%s SOLCODE=%d sqlca.sqlerrm=%s ipolicy = %s",userid,SQLCODE,sqlca.sqlerrm,ipolicy);
	fprintf(fptr_err,"%s\n",errmsg);
	return SQLCODE;
}

long car9995_final()
{
	char sTmpMsg[1024];
	$char sfilename[81],stitle[1024],stmt[1024];
	$char DBName1[5];
	$long mprem, pure_mprem, qcnt;
	$char product_kind[3];
    
	$WHENEVER SQLERROR GOTO errexit;
	
	strcpy(DBName1,"00");
	if (db_select(DBName1) == False)  return M_CM_DB_NOTOPEN;
	
	$SELECT sum(mprem), sum(qcnt), sum(pure_mprem)
	   INTO $mprem, $qcnt, $pure_mprem
	   FROM ca_develop
	  WHERE iclass = '9995' AND product_kind = '99'
	    AND data_yyyymm  = $data_yyyymm;

	sprintf(sTmpMsg, "%s%s\n", "���ɧ���:", file_catalog);
	sprintf(sTmpMsg, "%s�O�O=[%d] �«O�O=[%d] ����=[%d]\n",sTmpMsg, mprem, pure_mprem, qcnt );
	
	/*29�I���p�p����*/
	sprintf(stmt,"SELECT product_kind, sum(mprem), sum(qcnt), sum(pure_mprem) \
	                FROM ca_develop \
	               WHERE iclass = '9995' AND product_kind <> '99' AND data_yyyymm = '%s' \
	               GROUP BY product_kind order by 1",data_yyyymm);
	$PREPARE pre_29_kind1 FROM $stmt;
	$DECLARE cur_29_kind2 CURSOR FOR pre_29_kind1;
	$OPEN cur_29_kind2;
	while (1)
	{
		$FETCH cur_29_kind2 INTO $product_kind ,$mprem, $qcnt, $pure_mprem;
		if (SQLCODE == SQLNOTFOUND) break;
		sprintf(sTmpMsg, "%s�I��=[%s] �O�O=[%d] �«O�O=[%d] ����=[%d]\n",sTmpMsg, product_kind, mprem, pure_mprem, qcnt );
	}

	EWRITE(userid, M_CM_OK, sTmpMsg);
	exit(SUCCESS);
	isfinish(rtncode);

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
