/************************************************/
/*                                              */
/*   PROGRAM : caqbas3.ec                       */
/*                                              */
/*   PURPOSE : server side standard program     */
/*                                              */
/************************************************/

#include <stdio.h>
#include <string.h>
#include <decimal.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "bfsmsgs.h"
#include "cmnmsgs.h"
#include "carmsgs.h"
#include "cusmsgs.h"
#include "safeclib.h"
$include sqlca;
$include "var_length.h";

#define DATENULL                0x80000000L

/*
*  Name: caqbase3
*
*  Description: The purpose of this function is to select corresponding
*               name from database according to the namecode and option.
*
*/
char v_sMsg[1512];

long caqbase3(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	long rtncode;
	long dws208_select_daction();
	char option;
	
	
	cm_buf_init(command);
	cm_buf_get("%c",&option);
	
	printf("caqbase3[%c]\n",option);
	switch(option)
	{
		case 'A':
			rtncode = dws208_select_daction(reply);
			break;
		
		default :
			if(exitsub(reply,M_CM_WRONG_OPTION) == True)
			return M_CM_WRONG_OPTION;
		return apiRC;
	}
	return(rtncode);
}

long dws208_select_daction(reply)
serverReply reply;
{
	$char DBName[5],iprog[7];
	$char daction[11];
	int   tmp_len, rc;

	cm_buf_get("%s %s", DBName, iprog);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}
	
	$SELECT daction INTO $daction FROM dw_date WHERE iaction = $iprog;
	
	if(SQLCODE==SQLNOTFOUND)
	{
		strcpy(daction," ");
	}
	
	cm_buf_init(ReplyBuf);
	
	cm_buf_put("%l %s",M_CM_OK, daction);
	
	tmp_len = cm_buf_len(ReplyBuf);
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		return apiRC;
	else
		return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
