/************************************************/
/*                                              */
/*   PROGRAM : ca204p01s.ec                     */
/*   Reviser : Johnny 6/39/1997                 */
/*                                              */
/************************************************/
     
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"
$include sqlca;

long car211(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
     long rtncode;
     long car211_update_exec();
     long car211_single_query();
     long car211_rcp_count();
     char option;

     cm_buf_init(command);
     cm_buf_get("%c",&option);
     switch(option)
     {
          case 'P':
                   rtncode=car211_update_exec(reply);
                   break;
          case '1':
                   rtncode=car211_single_query(reply);
                   break;
          case '2':
                   rtncode=car211_rcp_count(reply);
                   break;
          default :
                return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
     }
     return(rtncode);
}

/***************************************************************************/
long car211_update_exec(reply)
serverReply reply;
{
     /* standard defined host variables */
     $char DBName[5], stmt[1024];
     /* end of standard host var */

     /* table receipt */
     $char rcpbegin[CARD_NUM], rcpend[CARD_NUM];
     $char officer1[EMPLOYEE_ID], officer2[EMPLOYEE_ID];
     $char alterer[EMPLOYEE_ID];
     $long dalter;
     $char icard[CARD_NUM],icard1[CARD_NUM],icard2[CARD_NUM];
     $char current_state[2], rcpnum[11], acc_status[2];
     $char status;
      char RcpBgn_tmp[10], RcpEnd_tmp[10], RcpBgn_tmp1[3], RcpBgn_tmp2[7], sRcpBgn[8];
       int iRcpBgn, iRcpEnd, Rcp_cnt, istatus;
     /* end of receipt */

     /* standard defined data */
     int tmp_len;
     long MsgCode;
     /* end of standard data */

     /* self defined data */
     char s_dalter[20];
     int i,count=0;
     int process_cnt=0;
     /* end of self data */
     
     cm_buf_get("%s",DBName);
     cm_buf_get("%c %s %s %s",
                &status,rcpbegin,rcpend,alterer);
     dalter=cm_today();
     printf(" value:%c,%s,%s,%s.\n",
               status,rcpbegin,rcpend,alterer);

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     EXEC SQL BEGIN WORK;
     
     sprintf_s(stmt, sizeof stmt,"INSERT INTO receipt ( ireceipt, fstatus, ialter, dalter) VALUES ( ?,?,?,? )");
     $PREPARE INS_RCP FROM $stmt;
     
     sprintf_s(stmt, sizeof stmt,"UPDATE receipt SET ( fstatus, ialter, dalter) = ( ?,?,? ) WHERE ireceipt = ?");
     $PREPARE UPD_RCP FROM $stmt;
     
     sprintf_s(stmt, sizeof stmt,"UPDATE receipt SET ( fstatus, ialter, dalter) = ( ?,?,? ) "
                   " WHERE ireceipt = ? AND fstatus = ? ");
     $PREPARE UPD_RCP1 FROM $stmt;
     
     /** ���p��w�B�z�����ڼƶq **/
     strncpy( RcpBgn_tmp, rcpbegin+2, 5 );  RcpBgn_tmp[5] = '\0';
     strncpy( RcpEnd_tmp, rcpend+2, 5 );    RcpEnd_tmp[5] = '\0';
     iRcpBgn = atoi( RcpBgn_tmp );
     iRcpEnd = atoi( RcpEnd_tmp );
     
     Rcp_cnt = iRcpEnd - iRcpBgn + 1;
     process_cnt=0;
     
     for( i=0; i< Rcp_cnt; i++ )
     {
     	
     	/** Step 1. Get ���ڸ��X **/
     	if( i == 0 )
     	{
     	    strcpy( rcpnum , rcpbegin );
     	}
     	else
     	{
     	    strncpy( RcpBgn_tmp1, rcpnum,   2 );  RcpBgn_tmp1[2] = '\0';
            strncpy( RcpBgn_tmp2, rcpnum+2, 5 );  RcpBgn_tmp2[5] = '\0';
     	    
     	    iRcpBgn = atoi( RcpBgn_tmp2 );
            iRcpBgn++;
            
            rfmtlong(iRcpBgn,"&&&&&",sRcpBgn);
            
            sprintf_s(rcpnum, sizeof rcpnum, "%s%s", RcpBgn_tmp1, sRcpBgn);
            rcpnum[7]='\0';
     	}
     	
     	/** Step 2. Get current state **/
     	$SELECT fstatus
     	   INTO $current_state
     	   FROM receipt
     	  WHERE ireceipt = $rcpnum;
     	if( SQLCODE == SQLNOTFOUND )
     	{
     	    strcpy( current_state, "8" );
     	}
     	
     	#ifdef PRINTF_FLAG
     	   printf("ireceipt = [%s] current_state = [%s]\n", rcpnum, current_state );
        #endif 
     	
     	/** Step 3. �̳B�z���A�i��@�~ **/
     	switch (status)
     	{
     	    case '1':
     	       strcpy(acc_status, "4");	
     	       if( current_state[0] == '8' )
     	       {
     	       	   /** �L��ơA�s�W�@�o�B�򥢦��� **/
     	       	   $EXECUTE INS_RCP USING $rcpnum, $acc_status, $alterer , $dalter;
     	       	   process_cnt++;
     	       }
     	       else if( (current_state[0] == '4') || (current_state[0] == '5') )
     	       {
     	       	   /** �쪬�A�w���@�o�B�򥢡A���B�z **/
     	       }
     	       else
     	       {
     	           /** �󥿦��ڪ��A **/
     	           $EXECUTE UPD_RCP USING $acc_status, $alterer , $dalter, $rcpnum ;
     	       	   process_cnt++;
     	       }
     	       break;
     	    case '2':
     	       strcpy(acc_status, "5");	
     	       if( current_state[0] == '8' )
     	       {
     	       	   /** �L��ơA�s�W�@�o�B�򥢦��� **/
     	       	   $EXECUTE INS_RCP USING $rcpnum, $acc_status, $alterer , $dalter;
     	       	   process_cnt++;
     	       }
     	       else if( (current_state[0] == '4') || (current_state[0] == '5') )
     	       {
     	       	   /** �쪬�A�w���@�o�B�򥢡A���B�z **/
     	       }
     	       else
     	       {
     	           /** �󥿦��ڪ��A **/
     	           $EXECUTE UPD_RCP USING $acc_status, $alterer , $dalter, $rcpnum ;
     	       	   process_cnt++;
     	       }
     	       break;   
     	    case '3':
     	       strcpy(acc_status, "6");	
     	       if( current_state[0] == '4' )
     	       {
     	       	   $EXECUTE UPD_RCP1 USING $acc_status, $alterer , $dalter, $rcpnum ,$current_state;
     	       	   if( sqlca.sqlerrd[2] > 0 )
     	       	   {
     	       	      process_cnt++;
     	       	   }
     	       }
     	       else
     	       {
     	       	   /** ���A�����@�o�A���B�z**/
     	       }
     	       break;
     	    case '4':
     	       strcpy(acc_status, "7");	
     	       if( current_state[0] == '5' )
     	       {
     	       	   $EXECUTE UPD_RCP1 USING $acc_status, $alterer , $dalter, $rcpnum ,$current_state;
     	       	   if( sqlca.sqlerrd[2] > 0 )
     	       	   {
     	       	      process_cnt++;
     	       	   }
     	       }
     	       else
     	       {
     	       	   /** ���A�����򥢡A���B�z**/
     	       }
     	       break;
     	    default:
     	       
     	       break;
     	}
     	/** end switch **/
     	#ifdef PRINTF_FLAG
     	   printf("process_cnt = [%d]\n", process_cnt );
     	#endif
     	
     }
     
     if ( process_cnt == 0)
     {
          EXEC SQL WHENEVER SQLERROR CONTINUE;
          EXEC SQL ROLLBACK WORK;
          return exitsub(reply,M_CA_UPD_NRECORD) ? M_CA_UPD_NRECORD : apiRC;
     }
     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
     {
        EXEC SQL WHENEVER SQLERROR CONTINUE;
        EXEC SQL ROLLBACK WORK;
        return apiRC;
     }
     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     EXEC SQL COMMIT WORK;

     return api_OKComplete;

errexit:
     MsgCode = SQLCODE;
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     if (SQLCODE != 0) MsgCode = SQLCODE;
     return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/***************************************************************************/
long car211_single_query(reply)
serverReply reply;
{
     EXEC SQL char DBName[5];
     EXEC SQL char ireceipt[CARD_NUM];

     int  tmp_len;

     cm_buf_get("%s", DBName);
     cm_buf_get("%s", ireceipt);

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if (db_select (DBName) == False)
     {
         if (exitsub (reply, M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
         else
            return apiRC;
     }
     
     strcpy(ireceipt    , trim(ireceipt));

     EXEC SQL SELECT *
                FROM receipt
               WHERE ireceipt = :ireceipt;

     if (SQLCODE == SQLNOTFOUND)
     {
          if(exitsub(reply,M_CM_NOT_FOUND) == True)
              return M_CM_NOT_FOUND;
          else
              return apiRC;
     }
     
     cm_buf_init (ReplyBuf);
     cm_buf_put ("%l", M_CM_OK);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply (reply, ReplyBuf, tmp_len, api_OKComplete) == False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     printf ("SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
     if (exitsub (reply, SQLCODE) == True)
        return SQLCODE;
     else
        return apiRC;
} /* car211_single_query */


/***************************************************************************/
long car211_rcp_count(reply)
serverReply reply;
{
     EXEC SQL char DBName[5];
     EXEC SQL char rcp_begin[10];
     EXEC SQL char rcp_end[10];
     EXEC SQL long count_rcp;

     int  tmp_len;

     cm_buf_get("%s", DBName);
     cm_buf_get("%s", rcp_begin);
     cm_buf_get("%s", rcp_end);

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if (db_select (DBName) == False)
     {
         if (exitsub (reply, M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
         else
            return apiRC;
     }

     strcpy(rcp_begin , trim(rcp_begin));
     strcpy(rcp_end   , trim(rcp_end));

     count_rcp = 0;

     EXEC SQL SELECT count(*)
                INTO :count_rcp
                FROM receipt
               WHERE ireceipt >= :rcp_begin
                 AND ireceipt <= :rcp_end;


     printf("###### Total receipt [%ld]\n",count_rcp );

     cm_buf_init (ReplyBuf);
     cm_buf_put ("%l %l", M_CM_OK , count_rcp);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply (reply, ReplyBuf, tmp_len, api_OKComplete) == False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     printf ("SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
     if (exitsub (reply, SQLCODE) == True)
        return SQLCODE;
     else
        return apiRC;
} /* car211_rcp_count */

