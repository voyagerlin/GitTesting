/************************************************/
/*   PROGRAM : ca846q01s.ec                     */
/*   DATE    : 107.01.30                        */
/*   NOTE    : �߮פ�x�޲z����                 */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
$include datetime.h;
#include "carmsgs.h"
#include "commsgs.h"


$char DBName[05], outputf[N_FILE+1];
$char  userid[11];
DBinfo  *list;
int     count_db;


$char sBgnDate_e[11], sEndDate_e[11], sBgnDate[11], sEndDate[11], sArea[6], sAreaNew[6];
$char sBasicDate[11], sBasicDate_e[11], sFwork[2];
$long lBgnDate, lEndDate;

long car846_build();
void car846_title();
long car846_body();
long car846_print();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;

    batchinit();
    strcpy(DBName   ,  isNULLstr(argv[1]));
    strcpy(userid   ,  isNULLstr(argv[2]));
    strcpy(sBgnDate ,  isNULLstr(argv[3]));  /* ���z��_�� */
    strcpy(sEndDate ,  isNULLstr(argv[4]));  /* ���z�騴�� */
    strcpy(sArea    ,  isNULLstr(argv[5]));  /* �z�ߤ��� */
    strcpy(sBasicDate,  isNULLstr(argv[6])); /* ���z��Ǥ� */
    strcpy(sFwork   ,  isNULLstr(argv[7]));  /* ��/������z add by sylvia 107.06.26 (1070613003_SC1) */
    strcpy(outputf  ,  isNULLstr(argv[8]));

    strcpy(sBgnDate_e, cm_to_infdate(sBgnDate));
    strcpy(sEndDate_e, cm_to_infdate(sEndDate));
    rstrdate(sBgnDate_e, &lBgnDate);
    rstrdate(sEndDate_e, &lEndDate);

    strcpy(sArea, trim(sArea));
    if (strcmp(sArea, "3601") == 0) { strcpy(sAreaNew, "L101"); } 
    else if (strcmp(sArea, "3602") == 0) { strcpy(sAreaNew, "L103"); }
    else if (strcmp(sArea, "3607") == 0) { strcpy(sAreaNew, "L104"); }
    else if (strcmp(sArea, "3603") == 0) { strcpy(sAreaNew, "L105"); }
    else if (strcmp(sArea, "3604") == 0) { strcpy(sAreaNew, "L201"); } 
    else if (strcmp(sArea, "3605") == 0) { strcpy(sAreaNew, "L202"); } 
    else if (strcmp(sArea, "3606") == 0) { strcpy(sAreaNew, "L203"); }

    strcat(sArea,"*");
    strcat(sAreaNew,"*");

    strcpy(sBasicDate_e, cm_to_infdate(sBasicDate));

    rc=car846_get_db();
    if (rc!=M_CM_OK)
        return rc;

    rc = car846_build();
    if (rc != M_CM_OK)
        return rc;

    return M_CM_OK;

errexit:
    printf("main :SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

/*--------------------------------------------------------------------*/

long car846_build()
{
    int    rc;

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    rc = car846_body();
    if (rc != M_CM_OK)
        return rc;

   rc = car846_print();
   if (rc != M_CM_OK)
       return rc;


   return M_CM_OK;

errexit:
   EWRITE(userid,rc,sqlca.sqlerrm);
   return SQLCODE;
}

long car846_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car846_body()
{
    long rc;
    int k;
    $char stmt[9500],stmt2[3000];
    $char iclaim[CLAIM_NUM];
    $int fclaim_status,msettle,icount;

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    $create temp table car846tbl
    (
       iclaim      char(20),    --�߮׸��X
       iverify     char(20),    --�d�Ҹ�
       dclaim1     date,        -- ���z��(���)
       dclaim2     datetime year to minute ,        --���z��(�~�ܤ�)
       ibranch     char(3),     --���ݤ����q
       nchi_full   char(40),    --�z�߳��
       nbranch     char(40),    --�z�߬�O
       nname       char(10),    --�z�ߤH��
       nmgr        char(10),    --�z�ߥD��
       ditem1      datetime year to minute ,        --�p���O�r1-2-1
       ditem2      datetime year to minute ,        --�ɮ֥���2-1*
       ditem3      datetime year to minute ,        --�ɮְ]��2-2*
       ditem4      datetime year to minute ,        --�d�ҳq���O�r3-6*
       ditem5      datetime year to minute ,        --�ˤ`�M�ѫO�r4-5A-1
       ditem6      datetime year to minute          --�ˤ`�M�Ѱ]��4-5A-2
    )with no log;

    $create temp table car846tb3
    (
    	iclaim		char(20),						--�߮׸�
    	iverify     char(20),  					    --�d�Ҹ�
    	dclaim      datetime year to minute         --���z��(�~�ܤ�)
    )with no log;

    /* �^�����(�����������b0,1,2,4) */
    /* �U�CSQL��,ibranch�e����''�OASCII��127�X,�s�ɮɷ|���@�Ӧr��,���V�� */
    for(k=0;k<count_db;k++)
    {
       sprintf(stmt,
       " insert into car846tbl          \
         select a.iclaim as �߮׸��X,   \
                (select iverify from ca_ver_relation where iclaim = a.iclaim) as �d�Ҹ�, \
                a.dclaim as ���z���1,  \
                b.dclaim as ���z���2,   \
               (select ''||ibranch          \
                  from branch           \
                 where ibranch_abbr = a.iclaim[3]) as ���ݤ����q,    \
               (select nchi_full        \
                  from branch           \
                 where ibranch = replace(a.iclaim[1,2],'A','0')) as �z�߳��, \
               (select nbranch          \
                  from sa_branch_type   \
                 where ibranch = a.affiliated) as �z�߬�O,    \
               (select nname            \
                  from officer          \
                 where iofficer = a.adjustment) as �z�ߤH��,   \
               (select x.nname          \
                  from officer x, personal:asempl y            \
                 where x.iofficer = y.administrator            \
                   and y.empl_no  = a.adjustment) as �z�ߥD��, \
               (select min(dentry) from ca_clm_journal c where c.iverify = \
               (select iverify from ca_ver_relation where iclaim = a.iclaim) and itype = '1-2-1'), \
               (select min(dentry) from ca_clm_journal c where c.iverify = \
               (select iverify from ca_ver_relation where iclaim = a.iclaim) and itype matches '2-1*'), \
               (select min(dentry) from ca_clm_journal c where c.iverify = \
               (select iverify from ca_ver_relation where iclaim = a.iclaim) and itype matches '2-2*'), \
               (select min(dentry) from ca_clm_journal c where c.iverify = \
               (select iverify from ca_ver_relation where iclaim = a.iclaim) and itype matches '3-6*'), \
               (select min(dentry) from ca_clm_journal c where c.iverify = \
               (select iverify from ca_ver_relation where iclaim = a.iclaim) and itype matches '4-5A-1'), \
               (select min(dentry) from ca_clm_journal c where c.iverify = \
               (select iverify from ca_ver_relation where iclaim = a.iclaim) and itype matches '4-5A-2') \
           from ca_clm_process a, %s:appraisal b   \
          where a.iclaim = b.iclaim \
            and a.assign in ('0','1','2','4') \
            and a.iclaim[6] not in ('W','T','S') \
            and a.dclaim between '%s' and '%s'  \
            and (a.affiliated matches '%s' or a.affiliated matches '%s')\
            and (b.fcard_class = '2' \
                   or (select count(*) from sysdb:ca_ver_relation \
                        where iverify = (select iverify from sysdb:ca_ver_relation \
                                          where iclaim = a.iclaim ) \
                          and iclaim[6] <> 'C') =  0) \
            and a.dclaim >= '%s'", list[k].dbname,sBgnDate_e,sEndDate_e,sArea,sAreaNew,sBasicDate_e);


        printf("stmt[%s]\n",stmt);

        $prepare pre1 from $stmt;
        $execute pre1;
    }

    /* �ư�0�ߵ��� */
    for(k=0;k<count_db;k++)
    {
    		/* Ūiverify�����z�� add by sylvia 110.03.04 (1100120012_SC1) */
    		sprintf(stmt,"insert  into newa00:car846tb3 \
    		              select a.iclaim, a.iverify , b.dclaim \
    		                from car846tbl a, %s:appraisal b   \
                       where a.iverify = b.iclaim ", list[k].dbname);
        printf("stmt[%s]\n",stmt);
        $prepare pre_v1 from $stmt;
        $execute pre_v1;

        sprintf(stmt,"select a.iclaim from car846tbl a, %s:appraisal b   \
                      where a.iclaim = b.iclaim ", list[k].dbname);
        printf("stmt[%s]\n",stmt);
        $prepare pre2 from $stmt;
        $declare cur2 cursor for pre2;
        $open cur2;
        while (1)
        {
            $FETCH cur2 INTO $iclaim;
            if (SQLCODE == SQLNOTFOUND) break;
            printf("iclaim=[%s]\n",iclaim);

            fclaim_status = msettle = icount = 0;

            /* �O�_�w���פw�M(��߮�501,�����p�߮�501*2=1002) */
            $select nvl(sum(nvl(a.fclaim_status,0)),0)
               into $fclaim_status
               from ca_clm_process a
              where a.iclaim in
                (select b.iclaim from sysdb:ca_ver_relation b
                  where b.iverify =
                  (select c.iverify from sysdb:ca_ver_relation c
                    where c.iclaim = $iclaim)) ;

            printf("fclaim_status=[%d][%d]\n",fclaim_status,fclaim_status%501 );
            /* if ((fclaim_status==501) || (fclaim_status==1002))*/
            if ((fclaim_status > 0) && ((fclaim_status%501) == 0))
            {
                printf("----- 242 ------ \n");
                /* �w���ת��O�_0�� */
                sprintf(stmt2,
                    "select nvl(sum(nvl(msettle ,0)),0) \
                       from %s:settlement \
                       where fstl = '1' and iclaim in \
                        (select iclaim from sysdb:ca_ver_relation \
                          where iverify = (select iverify from sysdb:ca_ver_relation \
                                where iclaim = '%s'))",list[k].dbname,iclaim);
                printf("----- 251 ------ \n");
                $prepare pre3 from $stmt2;
                $execute pre3 into $msettle;

                printf("msettle=[%d]\n",msettle);
                /* 0�ߵ��ת�,�O�_�z��P�w���I�ج۲� */
                if (msettle == 0)
                {
                    sprintf(stmt2,
                        "select sum((select count(*) \
                                       from %s:app_ins_type \
                                      where iclaim = a.iclaim \
                                        and iins_type not in \
                                        (select iins_type from %s:stl_ins_type \
                                          where iclaim = a.iclaim and fstl = '1')) + \
                                    (select count(*) from %s:ca_app_victim \
                                      where iclaim = a.iclaim and iins_item not in \
                                        (select iins_item from %s:ca_stl_victim \
                                          where iclaim = a.iclaim and fstl = '1'))) \
                         from %s:settlement a  \
                        where a.fstl = '1' and a.iclaim in \
                            (select iclaim from sysdb:ca_ver_relation \
                              where iverify = (select iverify from sysdb:ca_ver_relation \
                              where iclaim = '%s'))",
                    list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,iclaim);
                    printf("stmt2=[%s]\n",stmt2);
                    $prepare pre4 from $stmt2;
                    $execute pre4 into $icount;
                    printf("icount=[%d]\n",icount);
                    if (icount == 0)
                    {
                        /* �T�{��0�ߵ���,�R����� */
                        $delete from car846tbl where iclaim = $iclaim;
                        $delete from car846tb3 where iclaim = $iclaim;
                    }
                }
            }
            printf("----- 287 ------ \n");
        }
        printf("----- 289 ------ \n");
    }
printf("----- 291  sFwork = [%s] ------ \n",sFwork);
    /* �p�ⶡ�j�ɶ���g�Jtemp table */
    $select a.iclaim,  to_char(a.dclaim2,'%Y-%m-%d %H:%M') as dclaim, a.iverify,
            (select to_char(dclaim,'%Y-%m-%d %H:%M') from car846tb3 where iclaim = a.iclaim and iverify = a.iverify) as dclaim_v,
            decode(b.fwork,'1','����','0','����',' ') as fwork,
            a.ibranch, a.nchi_full, a.nbranch, a.nname, a.nmgr,
            to_char(a.ditem1, '%Y-%m-%d %H:%M') as ditem1,
            case when a.ditem1 is null then null else
                case when (select fwork from cm_wrktbl where dwork = date(a.ditem1)) = 1 then 450 else
                    (select nvl(max(cast(icode as int)),0) from cu_code_data where itype = 'DS'
                        and ncode <= to_char(a.ditem1,'%H')*60 + to_char(a.ditem1,'%M')) end -
                case when b.fwork = 1 then 0 else
                    (select nvl(max(cast(icode as int)),0) from cu_code_data where itype = 'DS'
                        and ncode <= to_char(a.dclaim2 ,'%H')*60 + to_char(a.dclaim2,'%M')) end  +
                ((select count(*) from cm_wrktbl where dwork between date(a.dclaim2)
                  and date(a.ditem1)  and fwork = '0')-1) * 450 end as dtime1,
            to_char(a.ditem2, '%Y-%m-%d %H:%M') as ditem2,
            case when a.ditem2 is null then null else
                case when (select fwork from cm_wrktbl where dwork = date(a.ditem2)) = 1 then 450 else
                    (select nvl(max(cast(icode as int)),0) from cu_code_data where itype = 'DS'
                        and ncode <= to_char(a.ditem2,'%H')*60 + to_char(a.ditem2,'%M')) end -
                case when b.fwork = 1 then 0 else
                    (select nvl(max(cast(icode as int)),0) from cu_code_data where itype = 'DS'
                        and ncode <= to_char(a.dclaim2 ,'%H')*60 + to_char(a.dclaim2,'%M')) end  +
                ((select count(*) from cm_wrktbl where dwork between date(a.dclaim2)
                  and date(a.ditem2)  and fwork = '0')-1) * 450 end as dtime2,
            to_char(a.ditem3, '%Y-%m-%d %H:%M') as ditem3,
            case when a.ditem3 is null then null else
                case when (select fwork from cm_wrktbl where dwork = date(a.ditem3)) = 1 then 450 else
                    (select nvl(max(cast(icode as int)),0) from cu_code_data where itype = 'DS'
                        and ncode <= to_char(a.ditem3,'%H')*60 + to_char(a.ditem3,'%M')) end -
                case when b.fwork = 1 then 0 else
                    (select nvl(max(cast(icode as int)),0) from cu_code_data where itype = 'DS'
                        and ncode <= to_char(a.dclaim2 ,'%H')*60 + to_char(a.dclaim2,'%M')) end  +
                ((select count(*) from cm_wrktbl where dwork between date(a.dclaim2)
                  and date(a.ditem3)  and fwork = '0')-1) * 450 end as dtime3,
            to_char(a.ditem4, '%Y-%m-%d %H:%M') as ditem4,
            case when a.ditem4 is null then null else
                case when (select fwork from cm_wrktbl where dwork = date(a.ditem4)) = 1 then 450 else
                    (select nvl(max(cast(icode as int)),0) from cu_code_data where itype = 'DS'
                        and ncode <= to_char(a.ditem4,'%H')*60 + to_char(a.ditem4,'%M')) end -
                case when b.fwork = 1 then 0 else
                    (select nvl(max(cast(icode as int)),0) from cu_code_data where itype = 'DS'
                        and ncode <= to_char(a.dclaim2 ,'%H')*60 + to_char(a.dclaim2,'%M')) end  +
                ((select count(*) from cm_wrktbl where dwork between date(a.dclaim2)
                  and date(a.ditem4)  and fwork = '0')-1) * 450 end as dtime4,
            to_char(a.ditem5, '%Y-%m-%d %H:%M') as ditem5,
            case when a.ditem5 is null then null else
                case when (select fwork from cm_wrktbl where dwork = date(a.ditem5)) = 1 then 450 else
                    (select nvl(max(cast(icode as int)),0) from cu_code_data where itype = 'DS'
                        and ncode <= to_char(a.ditem5,'%H')*60 + to_char(a.ditem5,'%M')) end -
                case when b.fwork = 1 then 0 else
                    (select nvl(max(cast(icode as int)),0) from cu_code_data where itype = 'DS'
                        and ncode <= to_char(a.dclaim2 ,'%H')*60 + to_char(a.dclaim2,'%M')) end  +
                ((select count(*) from cm_wrktbl where dwork between date(a.dclaim2)
                  and date(a.ditem5)  and fwork = '0')-1) * 450 end as dtime5,
            to_char(a.ditem6, '%Y-%m-%d %H:%M') as ditem6,
            case when a.ditem6 is null then null else
                case when (select fwork from cm_wrktbl where dwork = date(a.ditem6)) = 1 then 450 else
                    (select nvl(max(cast(icode as int)),0) from cu_code_data where itype = 'DS'
                        and ncode <= to_char(a.ditem6,'%H')*60 + to_char(a.ditem6,'%M')) end -
                case when b.fwork = 1 then 0 else
                    (select nvl(max(cast(icode as int)),0) from cu_code_data where itype = 'DS'
                        and ncode <= to_char(a.dclaim2 ,'%H')*60 + to_char(a.dclaim2,'%M')) end  +
                ((select count(*) from cm_wrktbl where dwork between date(a.dclaim2)
                  and date(a.ditem6)  and fwork = '0')-1) * 450 end as dtime6,
            (select replace(replace(replace(replace(replace(multiset(select trim(iclaim) from ca_ver_relation
              where iverify = ff.iverify)::lvarchar, 'MULTISET{',''), 'ROW(''',''),''')',''),'}',''),',','�B')
              from ca_ver_relation ff  WHERE ff.iclaim = a.iclaim) as iclm_relation
    from car846tbl a, cm_wrktbl b
   where a.dclaim1 = b.dwork
     and cast(b.fwork as char(1)) matches $sFwork
   into temp car846tb2 with no log;


    return M_CM_OK;

errexit:
   printf("car846_body ==> SQLCODE:[%ld][%s] \n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   printf("   end EWRITE \n");
   return SQLCODE;
}

long car846_print()
{
   $char sfilename[200];
   $char stitle[1000];
   $char ssql[1000];
   $char sErrmsg[100];
   $int  rc;

   $WHENEVER ERROR goto errexit;
   $SET LOCK MODE TO WAIT;

   strcpy(sfilename,"�߮׶i�׳B�z��x�޲z����");
   printf("sfilename[%s]\n",sfilename);

   strcpy(stitle, sfilename);
   printf("stitle[%s]\n",stitle);
   strcat(stitle, "\n\t");
   strcat(stitle, "���z����G ");
   strcat(stitle, sBgnDate_e);
   strcat(stitle, " ~ ");
   strcat(stitle, sEndDate_e);
   strcat(stitle, "\n\t�߮׸��X\t�߮ר��z���\t�d�Ҹ��X\t�d�Ҹ����z���\t��/������z\t���ݤ����q\t�z�߳��\t�z�߬�O\t�z�ߤH��\t");
   strcat(stitle, "�z�ߥD��\t�p���O�r\t���j�ɶ�(��)\t�ɮ֥���\t���j�ɶ�(��)\t�ɮְ]��\t");
   strcat(stitle, "���j�ɶ�(��)\t�d��-�q���O�r\t���j�ɶ�(��)\t�ˤ`�M�ѡЧi���O�r\t");
   strcat(stitle, "���j�ɶ�(��)\t�ˤ`�M�ѡЧi����y\t���j�ɶ�(��)\t�d�����p�߮׸�\t");

   printf("stitle[%s]\n",stitle);

   sprintf(ssql,
    " select * from car846tb2 ");

   printf("ssql[%s]\n",ssql);

   rc = unload_file(outputf,"",sfilename,stitle,ssql);

   if (rc != SUCCESS)
   {
       if (rc == 3501)
       {
          sprintf(sErrmsg," ��J���^������䤣���� ",sfilename);
       }
       else
       {
          sprintf(sErrmsg," %s �ɮ׵L�k���� ",sfilename);
       }

       EWRITE(userid, rc , sErrmsg);
       exit(1);
   }

   return M_CM_OK;

errexit:
  printf("SQL=[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(1);

}
