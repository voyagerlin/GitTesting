/***********************************************************************/
/*   program id   : ca926q04s.ec                                       */
/*                                                                     */
/*   �ݳB�z�G                                                          */
/*        1.��Ƥ��:(1)�Ƚs�O�_�w�ϥ�(2)�Ƚs���B�P�߮ת��B�O�_�ۦP    */
/*                   (3)�O�_�������ηJ�p���z��ΰl�v���               */
/*                                                                     */
/***********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#define TRUE 1
#define FALSE 0

DBinfo  *list;
int     count_db;
char   	sApHome[50];
$char  	DBName[5], userid[11], sFile1[101], sFile2[101], outputf[21];
$char  	errMsg[5000000], stmp[5000000], sFullName[80],errMsg2[200], sItransno[51],
        sErrorMsg[400];
int 		offset;
FILE   *sfp,*fp;
static char  *bp;
static int   recLen=1024;
$char getfile[400], getfile2[400];
char delimiter;
char  sfilename[128],stitle[2048];

$char sIclaim[21], sIreceive[21], sIpolicy[21], sIofficer[11], sIcard[21],
      sTransno[21], sIcompany[3];
$int  iser_rec, mclaim, icnt1, icnt2;
/* ------------------------------------------------------------------------- */

long car9264_get_data();
long rc;
long rtncode;

char *get_car_full_db();

main(argc, argv)
int argc;
char **argv;
{
	char	sOpt1[2];

    batchinit();
    strcpy(DBName       ,isNULLstr(argv[1]));
    strcpy(userid       ,isNULLstr(argv[2]));
    strcpy(sIofficer    ,isNULLstr(argv[3]));		/* �u�߸g��N��  */
    strcpy(sOpt1        ,isNULLstr(argv[4]));		/* C:�l�v��Ƥ��  A:�l�v�������  */
    strcpy(sFile1       ,isNULLstr(argv[5]));		/* ���P�~����� */
    strcpy(sFile2       ,isNULLstr(argv[6]));		/* �]�Ȧ^�Ъ��Ƚs�� */
    strcpy(sTransno     ,isNULLstr(argv[7]));		/* ���ɧǸ� */
    strcpy(outputf      ,isNULLstr(argv[8]));

    printf("sFile1 = [%s] sFile2 = [%s]\n",sFile1, sFile2);
    strcpy(sFile1, trim(sFile1));
    strcpy(sFile2, trim(sFile2));

    rc = car9264_get_db();
    if (rc != M_CM_OK) {
        printf("error on car9264_get_db\n");
        EWRITE(userid, rc, "error on car9264_get_db");
        return rc;
    }

    $WHENEVER SQLERROR CONTINUE;

   	rc=car9264_get_data();  /* ��r���� Temp Table */
    if (rc != M_CM_OK)
    {
	        printf("car9264_get_data:errMsg=[%s]\n",errMsg);
	        EWRITE(userid, rc, "error on car9264_get_data");
	        return rc;
    }

	rc=car9264_check1();  /* C:�l�v��Ƥ�� */
    if (rc != M_CM_OK)
    {
	        printf("[�j���I�d���u_�l�v��Ƥ�� ���楢��]\n");

	        if (iser_rec == 999)
	        {
	            strcpy(stmp, "car9264 ���楢��,�нT�{�íץ���A���s����!!\n\n");
	        }
	        else
	        {
	            sprintf(stmp,"%s\n\n%8.8s\t %.8s\t %.8s\t %.10s\t %.8s\t %.10s\t %10.20s\t %16.50s\n\n",
	            "car9264 ���楢��,�нT�{�íץ���A���s����!!","�߮׸�","�Ȧ��s��","�Ƚs���B","�l�v��H","�P�~�N��","�Ƚs���A","�O�渹","���~��]");
            }
	        strcat(stmp,errMsg);
	        EWRITE(userid,rc,stmp);
	        return rc;
    }
    if (strcmp(sOpt1,"C") == 0)
    {
    	strcpy(stmp,"\n��Ƥ��L�~�I�I�Y�n���ɡA���~��i��i�l�v������ɡj�I�I");
    	printf("103:stmp=[%s]\n",stmp);
    	EWRITE(userid,rc,stmp);
    	return M_CM_OK;
    }


    if (strcmp(sOpt1,"A") == 0)
    {
    	rc=car9264_trans();  /* A:�l�v������� */
	    if (rc != M_CM_OK)
	    {
		        printf("[�j���I�d���u_�l�v������� ���楢��]\n");
		        sprintf(stmp,"car9264 ���楢��,�нT�{�íץ���A���s����!! \n\n ");

		        strcat(stmp,errMsg);
		        EWRITE(userid,rc,stmp);
		        return rc;
	    }
	    else
	    {
				strcpy(stmp,"\n������ɧ����I�I�Цܡi���s�����j����i�w���ɥ��鵲�j�@�~�I�I");
				printf("124:stmp=[%s]\n",stmp);
	    	EWRITE(userid,rc,stmp);
	    	return M_CM_OK;
	    }
    }
}

/* ------------------------------------------------------------------------- */
void GetData(data, maxlen, delimiter)
char *data, delimiter;
int maxlen;
{
    int fori, pre_offset, cnt=0;

    data[0]='\0';
    pre_offset = offset;

    for (fori=pre_offset; bp[fori]!=0x00&&bp[fori]!=0x0d&&bp[fori]!=0x0a&&bp[fori]!=delimiter; fori++)
    {
        offset++;
        if (cnt < maxlen-1)
        {
            data[cnt]=bp[fori];
            cnt++;
        }
    }

    offset++; /* ���ܤU�@�� */
    if (cnt==0) data[cnt++]=0x20; /* �L��Ƶ��ť� */
    data[cnt]=0x00;
    printf("pre_offset[%d]offset[%d]len[%d]data[%s]\n", pre_offset, offset, cnt, data);
}

/* ------------------------------------------------------------------------- */
long car9264_get_data()
{
	$char	sInumber[6], sTmpData1[50], sOth_claim[21], sOth_card[21],
	      sOth_nation[2], sOth_CarType[3], sOth_qpt[6], sOth_fpt[2], sOth_tag[13],
	      sYY[5], sMM[3], sDD[3], sHH[3],sMS[3], sOth_reason[3], sOth_area[3],
	      sOth_nassured[21], sOth_victim[11], sOth_Dvictim[11], sOth_item1[4],
	      sOth_item2[2], sOth_Mstl[8], sOth_fvictim[2], sOth_adjuster1[4],
	      sOth_adjuster2[4], sOth_adjuster3[4], sOth_tag2[13], sOth_cpy2[3],
	      sOth_card2[22], sOth_prem[8], sDaccident[17], sDacc_mdy[11], sIins_item[5],
	      sMprem[11], sNobject[21], sDatamth[6];
	$int	iNumber, icompany, iMins_stl, iQduty1, iQduty2, iQduty3, iMprem, iYY,
	      iMM, iDD, iHH, iMS, iline, ierrcnt, iOth_cpy2;
	$double	dblQpt;

    $WHENEVER SQLERROR GOTO errexit;

    sprintf(getfile,"%s/dat/car/%s",sApHome,sFile1);
    printf("getfile[%s]\n",getfile);

    if ((fp=fopen(getfile,"rt"))==NULL)
    {
        return FAIL;
    }

    if ((bp=malloc(recLen))==NULL) { printf("System malloc failed  !\n"); return
                                      FAIL; }

    /* ���j�Ÿ� */
    delimiter=''; /* �`�N:���j�Ÿ��� ascii(127) */
    /* $delete from car9263_tpm1 where 1=1; */

    iline = 0;			/* �ɮ׵��� */
    while(fgets(bp,recLen,fp))
    {
        if (feof(fp)) break;
        offset = 0;

        /* ��ƨ��o���Ǥ��i�ܰ� */
				GetData(sInumber,       sizeof(sInumber),       delimiter);     /* 1 �Ǹ�*/
    		strcpy(sInumber, trim(sInumber));
    		iNumber = atoi(sInumber);

    		GetData(sTmpData1,      sizeof(sTmpData1),	    delimiter);     /* 2 �P�~�O�I���q*/
    		strcpy(sTmpData1, trim(sTmpData1));
    		icompany = atoi(sTmpData1);
    		sprintf(sIcompany, "%02d", icompany);

    		GetData(sOth_claim,     sizeof(sOth_claim),     delimiter);     /* 3 �P�~�߮׸�*/
    		strcpy(sOth_claim, trim(sOth_claim));

    		GetData(sOth_card,      sizeof(sOth_card),      delimiter);     /* 4 �P�~�O�I�Ҹ�*/
    		strcpy(sOth_card, trim(sOth_card));

    		GetData(sOth_nation,    sizeof(sOth_nation),    delimiter);     /* 5 �P�~�Q�H�H�����N�� */
    		strcpy(sOth_nation, trim(sOth_nation));

    		GetData(sTmpData1,      sizeof(sTmpData1),      delimiter);     /*6 �P�~���إN�� */
    		strcpy(sTmpData1, trim(sTmpData1));
    		sprintf(sOth_CarType, "%02d", atoi(sTmpData1));

    		GetData(sOth_qpt,       sizeof(sOth_qpt),       delimiter);     /* 7 �P�~�����ƶq*/
 		    dblQpt = atof(sOth_qpt);

    		GetData(sOth_fpt,       sizeof(sOth_fpt),       delimiter);     /* 8 �P�~�������*/
    		strcpy(sOth_fpt, trim(sOth_fpt));

    		GetData(sOth_tag,       sizeof(sOth_tag),  		delimiter);     	/* 9 �P�~���P���X*/
    		strcpy(sOth_tag, trim(sOth_tag));

    		GetData(sYY,            sizeof(sYY),	        delimiter);     	/* 10 �X�I���(�褸�~) */
    		strcpy(sYY, trim(sYY));

    		GetData(sMM,	        sizeof(sMM),	        delimiter);     		/* 11 �X�I���(��) */
    		strcpy(sMM, trim(sMM));

    		GetData(sDD,	        sizeof(sDD),	        delimiter);     		/* 12 �X�I���(��) */
    		strcpy(sDD, trim(sDD));

    		GetData(sHH,	        sizeof(sHH),	        delimiter);     		/* 13 �X�I���(��) */
    		strcpy(sHH, trim(sHH));

    		GetData(sMS,	        sizeof(sMS),	        delimiter);     		/* 14 �X�I���(��) */
    		strcpy(sMS, trim(sMS));

    		GetData(sOth_reason,    sizeof(sOth_reason),	delimiter);     	/* 15 �P�~�X�I��]�N�� */
    		strcpy(sOth_reason, trim(sOth_reason));

    		GetData(sTmpData1,      sizeof(sTmpData1),      delimiter);     /* 16 �P�~�X�I�a�ϥN�� */
    		strcpy(sTmpData1, trim(sTmpData1));
    		sprintf(sOth_area, "%02d", atoi(sTmpData1));

    		GetData(sOth_nassured,  sizeof(sOth_nassured),  delimiter);     /* 17 �P�~���`�H�m�W */
    		strcpy(sOth_nassured, rtrim(sOth_nassured));

    		GetData(sOth_victim,    sizeof(sOth_victim),    delimiter);     /* 18 �P�~���`�H�����Ҹ� */
    		strcpy(sOth_victim, rtrim(sOth_victim));

    		GetData(sOth_Dvictim,   sizeof(sOth_Dvictim),   delimiter);     /* 19 �P�~���`�H�ͤ� */
    		strcpy(sOth_Dvictim, rtrim(sOth_Dvictim));

    		GetData(sOth_item1,	    sizeof(sOth_item1),	    delimiter);     /* 20 �P�~���I���O�ζ���1 */
    		strcpy(sOth_item1, trim(sOth_item1));

    		GetData(sOth_item2,     sizeof(sOth_item2),	    delimiter);     /* 21 �P�~���I���O�ζ���2*/
    		strcpy(sOth_item2, trim(sOth_item2));

    		GetData(sOth_Mstl,      sizeof(sOth_Mstl),		delimiter);     	/* 22 �P�~�z�ߪ��B*/
    		strcpy(sOth_Mstl, trim(sOth_Mstl));
    		iMins_stl = atoi(sOth_Mstl);

    		GetData(sOth_fvictim,   sizeof(sOth_fvictim),	delimiter);     	/* 23 �P�~���`�H�O*/
    		strcpy(sOth_fvictim, trim(sOth_fvictim));

    		GetData(sOth_adjuster1, sizeof(sOth_adjuster1), delimiter);     /* 24 �P�~�����F�d�ʤ��� */
    		strcpy(sOth_adjuster1, trim(sOth_adjuster1));
    		iQduty1 = atoi(sOth_adjuster1);

    		GetData(sOth_adjuster2, sizeof(sOth_adjuster2),	delimiter);     /* 25 �P�~��y���F�d�ʤ��� */
    		strcpy(sOth_adjuster2, trim(sOth_adjuster2));
    		iQduty2 = atoi(sOth_adjuster2);

    		GetData(sOth_adjuster3, sizeof(sOth_adjuster3),	delimiter);     /* 26 �P�~��L�F�d�ʤ��� */
    		strcpy(sOth_adjuster3, trim(sOth_adjuster3));
    		iQduty3 = atoi(sOth_adjuster3);

   			GetData(sOth_tag2,      sizeof(sOth_tag2),      delimiter);     /* 27 �P�~��y���P���X */
   			strcpy(sOth_tag2, trim(sOth_tag2));

   			GetData(sTmpData1,      sizeof(sTmpData1),	    delimiter);     /* 28 �P�~��y���q�N�X */
   			strcpy(sTmpData1, trim(sTmpData1));
    		iOth_cpy2 = atoi(sTmpData1);
    		sprintf(sOth_cpy2, "%02d", iOth_cpy2);

   			GetData(sOth_card2,     sizeof(sOth_card2),		delimiter);     	/* 29 �P�~��y�O�I�Ҹ� */
   			strcpy(sOth_card2, trim(sOth_card2));

   			GetData(sOth_prem,      sizeof(sOth_prem),      delimiter);     /* 30 ���u���B */
   			strcpy(sOth_prem, trim(sOth_prem));
   			iMprem = atoi(sOth_prem);

        /* -------------------------------------------------------------- */
        /* �X�I�ɶ� */
        iYY = atoi(sYY);
        iMM = atoi(sMM);
        iDD = atoi(sDD);
        iHH = atoi(sHH);
        iMS = atoi(sMS);
        sprintf(sDaccident,"%04d-%02d-%02d %02d:%02d", iYY, iMM, iDD, iHH, iMS);
        sprintf(sDacc_mdy,"%02d/%02d/%d",iMM,iDD,iYY);

        /* �������� */
        sprintf(sIins_item,"%s%01d",sOth_item1, atoi(sOth_item2));

        printf("259:  sDaccident=[%s],sIins_item[%s] \n\n",sDaccident, sIins_item);

        printf("255:  iline=[%d],[%d] \n\n",iline, strlen(sInumber));
    		if (strlen(sInumber) == 0)
    		{
       	    memset(bp, ' ', recLen);
       			continue;
    		}

        iline++;

        /* �g�JTemp Table */
        $insert into car9264_tpm1
        (
            inumber, icompany, iclaim, icard, fvictim_nation,
		    		icar_type, qpt, fpt, itag, dacc_yy,
    	    	dacc_mm, dacc_dd, dacc_hh, dacc_ms, iacc_reason,
    	    	iacc_area, nassured, ivictim, dvictim, iins_item1,
    	    	iins_item2, mins_stl, fvictim_car, qduty_adjuster, qduty_adjuster2,
    	    	qduty_adjuster3, itag2, oth_company, oth_card, mprem,
    	    	daccident, iins_item
    	  )
        values
        (
            $sInumber, $sIcompany, $sOth_claim, $sOth_card, $sOth_nation,
            $sOth_CarType, $dblQpt, $sOth_fpt, $sOth_tag, $sYY,
            $sMM, $sDD, $sHH, $sMS, $sOth_reason,
            $sOth_area, $sOth_nassured, $sOth_victim, $sOth_Dvictim, $sOth_item1,
            $sOth_item2, $iMins_stl, $sOth_fvictim, $iQduty1, $iQduty2,
            $iQduty3, $sOth_tag2, $sOth_cpy2, $sOth_card2, $iMprem,
            $sDaccident, $sIins_item
        );

        memset(bp, ' ', recLen);
    }
    fclose(fp);

    if (iline == 0)
    {
        EWRITE(userid, M_CM_NOT_FOUND, "�i���P�~������j�ɮפ��L���!! \n");
        return FAIL;
    }

	/* ��i�]�ȵ����Ƚs��ơj ---------------------------------------------- */
	sprintf(getfile2,"%s/dat/car/%s",sApHome,sFile2);
    printf("getfile2[%s]\n",getfile2);

    if ((fp=fopen(getfile2,"rt"))==NULL)
    {
        return FAIL;
    }

    if ((bp=malloc(recLen))==NULL) { printf("System malloc failed  !\n"); return
                                      FAIL; }

    /* ���j�Ÿ� */
    delimiter=',';

    iline = 0;			/* �ɮ׵��� */
    while(fgets(bp,recLen,fp))
    {
        if (feof(fp)) break;
        offset = 0;

        /* ��ƨ��o���Ǥ��i�ܰ� */
				GetData(sIclaim,       sizeof(sIclaim),       delimiter);     /* 1 �߮׸� */
    		strcpy(sIclaim, trim(sIclaim));
    		if ((strcmp(sIclaim,"�߮׸��X") == 0) || (strlen(sIclaim) < 11))
    			continue;

    		GetData(sIreceive,      sizeof(sIreceive),	  delimiter);     /* 2 �Ȧ��s�� */
    		strcpy(sIreceive, trim(sIreceive));

    		GetData(sMprem,     		sizeof(sMprem),     	delimiter);     /* 3 �l�v���� */
    		strcpy(sMprem, trim(sMprem));
    		iMprem = atoi(sMprem);

    		GetData(sNobject,      	sizeof(sNobject),      delimiter);		/* 4 �l�v��H */
    		strcpy(sNobject, trim(sNobject));

    		GetData(sTmpData1,      sizeof(sTmpData1),	    delimiter);   /* 5 �O�I���q�N�� */
    		printf("�O�I���q�N�� sTmpData1=[%s]\n",sTmpData1);
    		strcpy(sTmpData1, trim(sTmpData1));
    		icompany = atoi(sTmpData1);
    		if (icompany == 0)
    			strcpy(sIcompany," ");
    		else
    			sprintf(sIcompany, "%02d", icompany);

    		printf("�O�I���q�N�� sTmpData1=[%s] icompany=[%d] sIcompany=[%s]\n",sTmpData1,icompany, sIcompany);

				GetData(sDatamth,      sizeof(sDatamth),	    delimiter);   /* 6 ��Ʀ~�� */
				strcpy(sDatamth, trim(sDatamth));
				if (strlen(sDatamth) < 5)
					strcpy(sDatamth, " ");

    		if (strlen(sIclaim) == 0)
    		{
       	    memset(bp, ' ', recLen);
       			continue;
    		}

        iline++;

        /* �g�JTemp Table */
        $insert into car9264_tpm2
        (
            iclaim, ireceive, mclaim, nobject, icompany, datamth
    	  )
        values
        (
            $sIclaim, $sIreceive, $sMprem, $sNobject, $sIcompany, $sDatamth
        );

        memset(bp, ' ', recLen);
    }
    fclose(fp);

    if (iline == 0)
    {
        EWRITE(userid, M_CM_NOT_FOUND, "�i�]�|�����Ƚs�ɡj�ɮפ��L���!! \n");
        return FAIL;
    }




    return M_CM_OK;

errexit:
    rc = cm_show_sql_err("car9264_get_data", "");
    return rc;
}
/*----------------------------------------------------------------------------*/
long car9264_get_db()
{
    int	rc;
    char msgbuf[60];

		printf("DBName=[%s]\n",DBName);
    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
    }

    if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;
    }

    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }


    /* ���P�~������� */
    $CREATE TEMP table car9264_tpm1
    (
    	inumber				int,					-- 1 �Ǹ�
			icompany			char(2),			-- 2 �O�I���q
			iclaim				char(20),			-- 3 �߮׸�
			icard					char(20),			-- 4 �O�I�Ҹ�
			fvictim_nation		char(1),	-- 5 �Q�O�H�����N��
			icar_type			char(2),			-- 6 ���إN��
    	qpt						decimal(4,1),	-- 7 �����ƶq
    	fpt						char(1),			-- 8 �������
    	itag					char(12),			-- 9 ���P���X
    	dacc_yy			  char(4),		  -- 10 �X�I���(�褸�~)
    	dacc_mm			  char(2),		  -- 11 �X�I���(��)
    	dacc_dd 			char(2),		  -- 12 �X�I���(��)
    	dacc_hh 			char(2),		  -- 13 �X�I���(��)
    	dacc_ms 			char(2),		  -- 14 �X�I���(��)
    	iacc_reason		char(2),			-- 15 �X�I��]�N��
    	iacc_area			char(2),			-- 16 �X�I�a�ϥN��
    	nassured			char(20),			-- 17 ���`�H�m�W
    	ivictim				char(10),			-- 18 ���`�H�����Ҹ�
    	dvictim				char(8),			-- 19 ���`�H�ͤ�
    	iins_item1		char(3),			-- 20 ���I���O�ζ���1(A���� B���` C����)
    	iins_item2		char(1),			-- 21 ���I���O�ζ���2
    	mins_stl			int,					-- 22 �z�ߪ��B
    	fvictim_car				char(1),	-- 23 ���`�H�O
      qduty_adjuster		int,			-- 24 �����F�d�ʤ���
      qduty_adjuster2		int,			-- 25 ��y���F�d�ʤ���
      qduty_adjuster3		int,			-- 26 ��L�F�d�ʤ���
      itag2					char(12),			-- 27 ��y���P���X
      oth_company		char(2),			-- 28 ��y���q�N�X
      oth_card			char(21),			-- 29 ��y�O�I�Ҹ�
      mprem					int,				  -- 30 ���u���B
      daccident			datetime year to minute,		--31 �X�I�ɶ�
      iins_item			char(6)				--  32 ����
    )with no log;

    $create index car9264_tpm1_x1 on car9264_tpm1(icompany, iclaim);

    /* �]�ȵ����Ƚs�ɮ� */
    $CREATE TEMP table car9264_tpm2
    (
    	iclaim		char(20),		-- �߮׸�
    	ireceive	char(20), 	-- �Ȧ��s��
    	mclaim		int,				-- �l�v���B
    	nobject		char(20),		-- �l�v��H
    	icompany	char(2),		-- �O�I���q�N��
    	datamth		char(5)			-- ��Ʀ~��
    )with no log;
		$create index car9264_tpm2_x1 on car9264_tpm2(iclaim, ireceive);


		$create temp table tb_aaa
		(
				iclaim		char(20),		-- �߮׸�
	    	ireceive	char(20), 	-- �Ȧ��s��
	    	mclaim		int,				-- �l�v���B
	    	nobject		char(20),		-- �l�v��H
	    	icompany	char(2),		-- �O�I���q�N��
	    	datamth		char(5),		-- ��Ʀ~��
	    	mclaim_nt int,				-- �Ȧs�ɰl�v���B
	    	fstatus		char(1),		-- ���A
	    	ipolicy		char(20),		-- �O�渹
	    	sErrmsgs	char(200)	default ' '	-- ���~�T��
		)with no log;

    return M_CM_OK;


errexit:
    rc = cm_show_sql_err("car9264_get_db", "");
    return rc;
}

/* ------------------------------------------------------------------------ */
/* A:�l�v��Ƥ�� */
long car9264_check1()
{
	$char sTmpSql[500], sTmpSql2[500], sNobject[21], sFstatus[2], sErrmsgs[201],
	      sDataYM[6], nStatus[11], stmpmsg[200], sOth_cpy2[3];
	$int  iMclaim, iMclaim_nt, icnt3, icnt;

	$int  rtn, icnt1;
    $char sToday[11], sYN[2], iportfolio[11], igroup_profit[21], ibranch[6],
          sfulldb[25], sIcar_type[3], fapply[2], kreserve[6], icohort[5], fterm[2];
    $char sMsg[200];

    $WHENEVER SQLERROR GOTO errexit;

    /* 1.1 IFRS�ˮֶ}�� */
    $select first 1 today into $sToday
       from car_code
      where 1=1;

    printf("sToday=[%s]\n",sToday);
    rtn = cm_get_IFRS_DATE(sToday, &sYN);
    printf("sToday=[%s], sYN=[%s]\n",sToday,sYN);

    /* �ˮ֤�����P�Ƚs�����q�N���O�_�۲� add by sylvia 111.06.22 (1110602007_SC1) */
    /* 1.�@���ɬO�_�u���@�Ӥ��q */
    icnt1 = icnt2 = 0;
    $select count(unique oth_company) into $icnt1
       from car9264_tpm1
      where trim(oth_company) <> '';

    $select count(unique icompany) into $icnt2
       from car9264_tpm2
      where trim(icompany) <> '';

    if (icnt1 >1)
    {
        iser_rec = 999;
        strcpy(errMsg,"�i���P�~������j�����P���G�a��y���q���, �нT�{!! \n");
        return FAIL;
    }
    else if (icnt2 == 0)
    {
        iser_rec = 999;
        strcpy(errMsg,"�i�]�|�����Ƚs�ɡj����J���q�N��, �нT�{!!\n");
        return FAIL;
    }
    else if (icnt2 > 1)
    {
        iser_rec = 999;
        strcpy(errMsg,"�i�]�|�����Ƚs�ɡj�����P���G�a���q�N��, �нT�{!!\n");
        return FAIL;
    }
    else
    {
        /* 2.����P�Ƚs�O�_���P�@�a���q  */
        $select unique oth_company into $sOth_cpy2
           from car9264_tpm1
          where 1=1;

        $select unique icompany into $sIcompany
           from car9264_tpm2
          where 1=1;

        if (strcmp(sOth_cpy2,sIcompany)!= 0)
        {
            iser_rec = 999;
            strcpy(errMsg,"����P�Ƚs�ɪ����q�N�����P, �нT�{!!\n");
            return FAIL;
        }
    }
    iser_rec = 0;

    $insert into tb_aaa
	 select a.*, b.mclaim_nt, b.fstatus,
	        nvl((select ipolicy from ca_clm_process where iclaim = a.iclaim),' ') as ipolicy,
	        case when (a.icompany = '' or length(a.icompany) < 2) then '�Ƚs�ɫO�I���q�N�X����J'
	        	 when (a.datamth = '' or length(a.datamth) < 5) then '�Ƚs�ɸ�Ʀ~�를��J'
		    else
			     CASE WHEN fstatus = 'R' THEN
			            '�Ƚs�w�P�b'
			     else
			         CASE WHEN c.iclaim IS NULL THEN
			       	    '�Ƚs��Ƥ��b�����'
			       	 else
				         CASE WHEN a.mclaim <> b.mclaim_nt THEN
				       	            '�Ƚs�ɪ��B�P�]�|�t�μȽs�Ҹ����B���P'
				       		  WHEN a.mclaim <> nvl(c.mprem, -1) THEN
				       		        CASE WHEN nvl(c.mprem, -1) < 0 THEN
				       			 	    '�Ƚs��Ƥ��b�����'
				       			 	else
				       				    '�Ƚs�ɪ��B�P������u���B���P'
				       				END
				         Else ' '
				       	 END
				     END
			     END
		 	end AS sErrmsgs
        from car9264_tpm2 a, ao_close_temp b,
	         OUTER (SELECT UNIQUE iclaim, sum(mprem) as mprem from car9264_tpm1 c
	                 WHERE 1=1 GROUP BY 1) c
 	   where a.iclaim = b.iclaim
		 and a.ireceive = b.itmp_no
		 AND a.iclaim = c.iclaim
		 and b.iaccsub = '00' ;

    sprintf(sTmpSql, "select * from tb_aaa where ipolicy <> ' ' and length(sErrmsgs) > 0  ");
	printf("549:sTmpSql=[%s]\n",sTmpSql);
	$PREPARE pre_A1 FROM $sTmpSql;
    $DECLARE cur_A1 CURSOR for pre_A1;
    $OPEN cur_A1;
    while (1)
    {
    	$FETCH cur_A1 into $sIclaim, $sIreceive, $iMclaim, $sNobject,	$sIcompany,
    	                   $sDataYM, $iMclaim_nt, $sFstatus,	$sIpolicy, $sErrmsgs;
		if (SQLCODE == SQLNOTFOUND) break;

		icnt=0;
		$select count(*) into $icnt
		   from sysdb:ca_clm_com_trans
		  where fstl = '2' and istl_flag in ('A')
			and iclaim = $sIclaim
			and itmp_no = $sIreceive;

        if (icnt > 0)
		{
		    $select unique replace(replace(replace(replace(replace( multiset (select unique date(dcreate) from sysdb:ca_clm_com_trans
		      where fstl = '2' and istl_flag in ('A')
		        and iclaim = a.iclaim and itmp_no = a.itmp_no)::lvarchar, 'MULTISET{',''), 'ROW(''',''),''')',''),'}',''),',','�B')
               into $stmpmsg
		       from sysdb:ca_clm_com_trans a
			  where fstl = '2' and istl_flag in ('A')
				and iclaim = $sIclaim
				and itmp_no = $sIreceive;

            sprintf(sErrmsgs, "��Ƥw�b %s �妸���ɹL, �Э��s�T�{!! ", trim(stmpmsg));

			$update tb_aaa
		    	set sErrmsgs = $sErrmsgs
		      where iclaim = $sIclaim
		        and ireceive = $sIreceive
		        and mclaim = $iMclaim
		        and ipolicy = $sIpolicy;

				continue;
        }

		strcpy(sFullName, get_car_full_db(sIpolicy));
		icnt=0;
		sprintf(sTmpSql2,
                "SELECT count(*) FROM %s:ca_stl_victim \
                  WHERE iclaim = '%s' AND dclose IS NULL ", sFullName, sIclaim);

        $prepare pre_A2 from $sTmpSql2;
        $execute pre_A2 into $icnt;

		printf("568:sTmpSql=[%s]\n",sTmpSql2);
        if (icnt > 0)
        {
      	    $update tb_aaa
      	        set sErrmsgs = '����߮ש|���ߥI�ΰl�v�z�⥼�鵲'
      	      where iclaim = $sIclaim
      	        and ireceive = $sIreceive
      	        and mclaim = $iMclaim
      	        and ipolicy = $sIpolicy;
        }

        /*----------------------------------------------------------------*/
        /* IFRS�����ˮ� add by sylvia 111.10.28 (1110303007��SC3) */
        /*----------------------------------------------------------------*/
        strcpy(iportfolio, " ");
        strcpy(igroup_profit, " ");

        /*   1120914001_A01_IFRS17 �t�X��Ʀ^�ɬ����ק�   */
        strcpy(sYN,"N");
        if (strcmp(sYN,"Y") == 0)
        {
	        rc = chk_IFRS_claim("1", sIpolicy, sIclaim, "21", &iportfolio, &igroup_profit, &icnt3, &sMsg);
	        if (icnt1 > 0)
	        {

	            strcpy(errMsg2, sMsg);

	            $update tb_aaa
	      	        set sErrmsgs = $errMsg2
	      	      where iclaim = $sIclaim
	      	        and ireceive = $sIreceive
	      	        and mclaim = $iMclaim
	      	        and ipolicy = $sIpolicy;
	        }
				}
    }
    $CLOSE cur_A1;
    $FREE cur_A1;

	/* �p�ˮֵ��G,���~����<>0, �C�X���~��� */
	icnt = 0;
	strcpy(errMsg, " ");
	sprintf(sTmpSql,
			"select iclaim,ireceive,mclaim,nobject,icompany, decode(fstatus,'F','�Ȧ��@','�w�P�b'), "
			"       ipolicy,sErrmsgs  from tb_aaa where length(sErrmsgs) > 0 ");

			printf("589:sTmpSql=[%s]\n",sTmpSql);
	$PREPARE pre_A3 FROM $sTmpSql;
    $DECLARE cur_A3 CURSOR for pre_A3;
    $OPEN cur_A3;
    while (1)
    {
    	$FETCH cur_A3 into $sIclaim, $sIreceive, $iMclaim, $sNobject,	$sIcompany,
    	                   $nStatus,	$sIpolicy, $sErrmsgs;
		if (SQLCODE == SQLNOTFOUND) break;
		printf("sIclaim=[%s] sIcompany=[%s]\n",sIclaim,sIcompany);
		icnt++;
		strcpy(sIclaim, trim(sIclaim)); strcpy(sIreceive, trim(sIreceive));
		strcpy(sNobject, trim(sNobject)); strcpy(sIcompany, trim(sIcompany));
		strcpy(nStatus, rtrim(nStatus)); strcpy(sIpolicy, trim(sIpolicy));
		strcpy(sErrmsgs, trim(sErrmsgs));
		sprintf(sErrorMsg, "%.15s\t %.20s\t %8.0d\t %.12s\t  %12.4s\t          %.12s\t   %15.15s\t %.50s\n",
		                   sIclaim, sIreceive, iMclaim, sNobject,	sIcompany,
		                   nStatus,	sIpolicy, sErrmsgs);
		strcat(errMsg,sErrorMsg);

	}
	$CLOSE cur_A3;
    $FREE cur_A3;

	if (icnt > 0)
		return FALSE;
	else
		return M_CM_OK;

errexit:
    rc = cm_show_sql_err("car9264_check1", "");
    return rc;
}

/* -------------------------------------------------------------------------- */
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[31];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}

/* -------------------------------------------------------------------------- */
long car9264_trans()
{

    $char   sTrsqlm[1000];
    $char   sNobject[21],	sDataYM[6];
    $int    iMclaim, icnt;


    EXEC SQL WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT 2;

		$select count(*) into $icnt
		   from tb_aaa
		  where length(sErrmsgs) > 0 ;

		if (icnt > 0)
		{
			sprintf(sErrorMsg,"car9264 ���ɥ���,���� %d ��߮׸�Ʀ����~���ư�!! \n\n ",icnt);
			strcat(errMsg,sErrorMsg);
			return FALSE;
		}


    $Begin Work;

    sprintf(sTrsqlm,"select a.iclaim, a.ireceive, a.icompany, a. mclaim, "
                    "       (select ipolicy from ca_clm_process "
                    "         where iclaim = a.iclaim) as ipolicy "
                    "  from car9264_tpm2 a, newa00:ao_close_temp b "
                    " where a.iclaim = b.iclaim "
                    "   and a.ireceive = b.itmp_no "
                    "   and a.mclaim = b.mclaim_nt "
                    "   and b.fstatus = 'F'");
    $PREPARE pre_B1 FROM $sTrsqlm;
    $DECLARE cur_B1 CURSOR for pre_B1;
    $OPEN cur_B1;
    while (1)
    {
    	$FETCH cur_B1 into $sIclaim, $sIreceive, $sIcompany, $mclaim, $sIpolicy;

			if (SQLCODE == SQLNOTFOUND) break;

			/* 1.�l�v�޲z�@�~(car583) */
            rc=car583_insert();  /* �s�Wcar583 */
            if (rc != SUCCESS)
                return rc;

			/* 2.�l�v�z��@�~(car585) */
            rc=car585_insert();  /* �s�Wcar585 */
            if (rc != SUCCESS)
                return rc;
    }
    $CLOSE cur_B1;
    $FREE cur_B1;

    $commit work;
    return M_CM_OK;


errexit:
    rc = cm_show_sql_err("car9264_trans", "");
    rgetmsg(SQLCODE, sErrorMsg, sizeof(sErrorMsg));
    sprintf(errMsg2, sErrorMsg, sqlca.sqlerrm);
    sprintf(errMsg, "[%s]\n �i�׸�:%s�j SQLERROR(%d):%s\n",
            "car9264_trans:", trim(sIclaim), SQLCODE, errMsg2);
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}

/* -------------------------------------------------------------------------- */
long car583_insert()
{
    $char sTmpSql[500], sTmpSql2[20000], sIacc_reason[3];
    $int msettle;

    EXEC SQL WHENEVER SQLERROR GOTO errexit;

	strcpy(sFullName, get_car_full_db(sIpolicy));


	/* 1.���޲z�Ǹ� */
	iser_rec = 0;
	sprintf(sTmpSql,
			"SELECT FIRST 1 iser_rec \
			   FROM %s:recovery  WHERE iclaim = ? ORDER BY iser_rec DESC ",sFullName);

	$prepare pre_B2 from $sTmpSql;
    $execute pre_B2 into $iser_rec using $sIclaim;

    iser_rec++;		/* �޲z�Ǹ� */

	/* �O�d���B�X�I��] */
	$select unique icard, iacc_reason
	   into $sIcard, $sIacc_reason
	   from car9264_tpm1
	  where iclaim = $sIclaim;

	/* �ߥI���B�`�� */
	msettle = 0;
	sprintf(sTmpSql,
    		"SELECT sum(mins_stl + mstl_health) \
    		   FROM %s:ca_stl_victim  \
    		  WHERE iclaim = ? \
    		    AND fstl = '1'  AND dgroup <= today ",sFullName);

	$prepare pre_B3 from $sTmpSql;
    $execute pre_B3 into $msettle using $sIclaim;


	/* �g�Jrecovery */
	sprintf(sTmpSql2,
		"insert into %s:recovery "
		"  (iclaim, iser_rec, ipolicy, icard, iacc_reason, "
		"   fpart, msettle, mrec_done, mfee_done, mrecov, "
		"   mfee, frecover, frecov, freprocess, msal_done, "
		"   msal_fee, fsal, fsale, lawgiver, ilaw_window, "
		"   salesman, mmsal_done, mmrecov, iarrive_no, recov_man, "
		"   recov_comp, recov_branch, recov_claim, recov_officer, recov_tel, "
		"   recov_process, frecov_out, really_recovery, irecvory, irecvory2, "
		"   irec_kind, dlaw, flaw_status, iobject, nobject_owner, "
		"   itag_obj, mprice_first, mprice_second, mprice_third, fsale_method, "
		"   nbid_won, ncontact, itel, nreason_aban, itag_oth, "
		"   nowner_oth, aowner_oth, ndriver_oth, adriver_oth, itel_driver, "
		"   mmsal_really, nreason_sale, pduty_rec, ientry, dentry, "
		"   iupdate, dupdate, dsend_law, madjust, iexec_type, "
		"   frecov_out2, flaw_recover) "
		"	values "
		"   (? , ?, ?, ?, ?, "
		"    '4', ?, 0, 0, 0, "
		"    0, 5, 4, 0, 0, "
		"    0, 0, 0, ?, ' ', "
		"    ' ', 0, ?, ' ', '3', "
		"    ?, '*', '*', '*', '*', "
		"    ' ', 0, ?, ' ', ' ', "
		"    '1', current, 110, '1', ' ', "
		"     '1', 0, 0, 0, '1', "
		"    ' ', ' ', ' ', ' ', ' ', "
		"    ' ', ' ', ' ', ' ', ' ', "
		"    0, ' ', 0, ?, current, "
		"    ?, current, current, 0, 0, "
		"     0, ' ' )	", sFullName);

	$prepare pre_B4 from $sTmpSql2;
    $execute pre_B4 using $sIclaim, $iser_rec, $sIpolicy, $sIcard, $sIacc_reason,
			              $msettle, $sIofficer, $mclaim, $sIcompany, $mclaim,
			              $userid, $userid;

    return SUCCESS;

errexit:
    rc = cm_show_sql_err("car582_insert", "");
    rgetmsg(SQLCODE, sErrorMsg, sizeof(sErrorMsg));
    sprintf(errMsg2, sErrorMsg, sqlca.sqlerrm);
    sprintf(errMsg, "[%s]\n �i�߮׸�:%s  �Ƚs: %s�j SQLERROR(%d):%s\n",
            "car583_insert:", trim(sIclaim), trim(sIreceive), SQLCODE, errMsg2);

    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}

/* -------------------------------------------------------------------------- */
long car585_insert()
{
	$char sTmpSql[5000], sTmpSql2[20000], sTmpSq3[5000], sIacc_reason[3],
	      sIhealth[2], sIvictim[11], sIins_item[7], sFlast[2];
	$int  msettle, iclose_type, mstl_health, iself_duty, ioth_duty,
	      ianoth_duty, icnt, iMprem;
	$int  ichk1, ichk2;

    EXEC SQL WHENEVER SQLERROR GOTO errexit;

	strcpy(sFullName, get_car_full_db(sIpolicy));


	/* 1.���o�̫�@���z�⪺���O�l�v�O */

	sprintf(sTmpSql,
	    	"SELECT FIRST 1 ihealth  \
			   FROM %s:settlement  \
			  WHERE iclaim = ? AND fstl = '1'  order by dclose desc ",sFullName);

    printf("830:sTmpSql=[%s]\n",sTmpSql);
	$prepare pre_B5 from $sTmpSql;
    $execute pre_B5 into $sIhealth, $iclose_type using $sIclaim;


	/* 2.���O�l�v�`�B */
	mstl_health = 0;
	sprintf(sTmpSql,
	    	"SELECT sum(mstl_health) \
			   FROM %s:ca_stl_victim  \
			  WHERE iclaim = ? AND dgroup <= today ",sFullName);

    printf("843:sTmpSql=[%s]\n",sTmpSql);
	$prepare pre_B6 from $sTmpSql;
    $execute pre_B6 into $mstl_health using $sIclaim;

    if (mstl_health > 0)
    	strcpy(sIhealth,"2");

    /* 3.�l�v���� */
	iclose_type = 0;
	sprintf(sTmpSql,
			"SELECT nvl(max(iclose_type),0) \
			   FROM %s:settlement  \
			  WHERE iclaim = ? AND fstl = '2' ",sFullName);

    printf("856:sTmpSql=[%s]\n",sTmpSql);
	$prepare pre_B7 from $sTmpSql;
    $execute pre_B7 into $iclose_type using $sIclaim;

    iclose_type++;

    printf("863:sTmpSql=[%s]\n",sTmpSql);
	/* 4.�F�d�ʤ��� */
	$select unique qduty_adjuster, qduty_adjuster2, qduty_adjuster3
	   into $iself_duty, $ioth_duty, $ianoth_duty
	   from car9264_tpm1
	  where iclaim = $sIclaim;
    printf("869----------------------------\n");

	/* 5.�g�J settlement */
	sprintf(sTmpSql2,
		"insert into %s:settlement "
		"	(iclaim, fstl, iclose_type, fcard_class, ipolicy, "
		"	 icard, mparts_stl, mlabor_fee, mmater_fee, mpaint_fee, "
		"	 mdeduct, msettle, fsalvage, ireceive, istl_note, "
		"	 mnote016, ientry, dentry, qprint, iadjuster, "
		"	 frecover, fsale, istl_recover, ihealth, istl_flag, "
		"	 ioth_fassured, ioth_cartype, ioth_qpt, ioth_fpt, iself_duty, "
		"	 ioth_duty, ianoth_duty, mphoto_fee, mtraffic_fee, mmail_fee, "
		"	 mlaw_fee, mvision_fee, mother_fee, mplace_service, ioth_tag, "
		"	 ioth_nassured, ioth_iassured, ioth_aassured, ioth_tel, driver_nassured, "
		"	 driver_iassured, driver_aassured, driver_tel, ioth_compancy, mfree_fee, "
		"	 mmore_fee, c_reason, engin_sys, air_condition_sys, transmission_sys, "
		"	 electric_sys, brake_sys, ic_sys, other_sys, vouch_state, "
		"	 iser_rec, iupdate, dupdate, nnote_claim, freject, "
		"	 ipayno, ichk_recovery, ireason_norecovery, iapprove_flag) "
		"	values "
		"	 (?, '2', ?, '1', ?, "
		"	  ?, 0, 0, 0, 0, "
		"	  0, ?, '2', ?, ' ', "
		"	  0, ?, current, 0, ?, "
		"	  '3', ' ', '3', ?, 'A', "
		"	  0, ' ', 0, ' ', ?, "
		"	  ?, ?, 0, 0, 0, "
		"	  0, 0, 0, 0, ' ', "
		"	  ' ', ' ', ' ', ' ', ' ', "
		"	  ' ', ' ', ' ', ' ', 0, "
		"	  0, ' ', 0, 0, 0, "
		"	  0, 0, 0, 0, 110, "
		"	  ?, ?, current, '�j���I�F�d���u�վ�@�~--�妸����', 'N', "
		"	  ?, ' ', ' ', ' ') ", sFullName);

    printf("904:sTmpSql=[%s]\n",sTmpSql2);
	$prepare pre_B8 from $sTmpSql2;

    printf("sIclaim=[%s]iclose_type=[%d]sIpolicy=[%s]sIcard=[%s]mclaim=[%d]\n",sIclaim,iclose_type,sIpolicy,sIcard,mclaim);
    printf("sIreceive=[%s]userid=[%s]sIofficer=[%s]sIhealth=[%s]iself_duty=[%d]\n",sIreceive,userid,sIofficer,sIhealth,iself_duty);
    printf("ioth_duty=[%d]ianoth_duty=[%d]iser_rec=[%d]userid=[%s]sTransno=[%s]\n",ioth_duty,ianoth_duty,iser_rec,userid,sTransno);

    $execute pre_B8 using $sIclaim, $iclose_type, $sIpolicy, $sIcard, $mclaim,
                          $sIreceive, $userid, $sIofficer, $sIhealth, $iself_duty,
                          $ioth_duty, $ianoth_duty, $iser_rec, $userid, $sTransno;


    /* �μȽs�����q�OŪ�������� */
	sprintf(sTmpSql2,
			"select a.iclaim, a.ivictim, iins_item, sum(a.mprem) as mprem "
			"  from car9264_tpm1 a "
		    " where a.iclaim = '%s' "
		    "   and a.oth_company = '%s'  "
		    " group by 1,2,3 ", sIclaim, sIcompany);

    printf("918:sTmpSql=[%s]\n",sTmpSql2);
	$PREPARE pre_B9 FROM $sTmpSql2;
    $DECLARE cur_B9 CURSOR for pre_B9;
    $OPEN cur_B9;
    while (1)
    {
        $FETCH cur_B9 into $sIclaim, $sIvictim, $sIins_item, $iMprem;
		if (SQLCODE == SQLNOTFOUND) break;
		printf("sIclaim=[%s]sIvictim=[%s]sIins_item=[%s]iMprem=[%d]\n",sIclaim,sIvictim,sIins_item,iMprem);

		/* ���̫�@���߰l���O */
		sprintf(sTmpSql,
			"	select a.flast "
	  		"   from %s:ca_stl_victim a,  %s:settlement b "
	        "  where a.iclaim = b.iclaim "
	        "    AND a.fstl = b.fstl "
	        "    AND a.iclose_type = b.iclose_type  "
	        "    and a.iclaim    =  '%s'  "
	        "    and a.ivictim =  '%s'  "
	        "    and a.iins_item =  '%s'  "
	        "    and b.vouch_state = '130' "
	        "    and b.dclose IS NOT NULL   "
	        "    and b.dentry = ( SELECT max(d.dentry) FROM %s:ca_stl_victim c, %s:settlement d "
	        "                      where c.iclaim = d.iclaim   "
	        "                        and c.fstl = d.fstl   "
	        "                        and c.iclose_type = d.iclose_type   "
	        "                        and d.iclaim    =  b.iclaim         "
	        "                        and c.iins_item =  '%s'  ) ",
	        sFullName, sFullName, sIclaim, sIvictim, sIins_item,
	        sFullName, sFullName, sIins_item);

        printf("949:sTmpSql=[%s]\n",sTmpSql);
		$prepare pre_B10 from $sTmpSql;
	    $execute pre_B10 into $sFlast;

		if (SQLCODE == SQLNOTFOUND)
				strcpy(sFlast,"2");

        /* 6.�g�J ca_stl_victim */
		sprintf(sTmpSq3,
				"insert into %s:ca_stl_victim "
				"		(iclaim, fstl, iclose_type, iins_item, ivictim, "
				"    mins_comp, mins_stl, mins_proc, flast, mstl_health) "
				" values "
				"		(?, '2', ?, ?, ?, "
				"    0, ?, 0, ?, 0) ",sFullName);

            printf("962:sTmpSql=[%s]\n",sTmpSq3);
        $prepare pre_B11 from $sTmpSq3;
    	$execute pre_B11 using $sIclaim, $iclose_type, $sIins_item, $sIvictim, $iMprem, $sFlast;
    }
	$CLOSE cur_B9;
    $FREE cur_B9;


    /* 6.2 �ɤJ�������l�v�� ca_stl_victim */
    sprintf(sTmpSq3,
        	"insert into %s:ca_stl_victim "
        	"select unique iclaim, '2', %d, iins_item, ivictim, "
        	"       mins_comp, 0, 0, flast, '', "
        	"       0,'','' "
        	"  FROM %s:ca_stl_victim a "
        	" WHERE a.iclaim = '%s' AND fstl = '1' "
            "   AND NOT EXISTS (SELECT iclaim, iins_item, ivictim "
            "                     FROM car9264_tpm1 "
            "                    WHERE iclaim ='%s' "
            "                      AND iclaim = a.iclaim "
            "                      AND iins_item = a.iins_item "
            "                      AND ivictim = a.ivictim) ",
            sFullName, iclose_type, sFullName, sIclaim, sIclaim);

    printf("998:sTmpSql=[%s]\n",sTmpSq3);
    $prepare pre_B11b from $sTmpSq3;
    $execute pre_B11b;


	/* 7.�g�J payment */
	sprintf(sTmpSq3,
			"insert into %s:payment "
			"	(iclaim, fstl, iclose_type, ipayment, ifpce_id_ext, "
			"    qserial, irepair_shop, fassured, nchi_full, npayment, "
			"    xsettle_type, ipay_area, xptax, xfpay_cond, xibank, "
			"    xiaccount, aperm_con, xastl_obj_c, mpayment, fspeed, "
			"    dreceiver, dpaperwork, pay_kind, xmark, icur, "
			"    frec_type, izipcode, aaddress, nreceiver, iofficer, "
			"    ioff_branch, ioff_tel_ext, itelephone, imobilephone, nremark, "
			"    fchange, iemail, imobile, tfax, izipcode_con, "
			"    iprocess_type) "
			" values "
			"	(?, '2', ?, '16834703', ' ', "
			"    0, ' ', '2', '�s�w�F�ʮ��W�����O�I�ѥ��������q', '�s�w�F�ʮ��W�����O�I�ѥ��������q', "
			"    '1', '00', 0, '3', '0130659', "
			"    '065030005656', ' ', ' ', ?, 'C', "
			"    ' ', ' ', '5', ' ', ' ', "
			"    ' ', ' ', ' ', ' ', ' ', "
			"    ' ', ' ', ' ', ' ', ' ', "
			"    ' ', ' ', ' ', ' ', ' ', "
			"    ' ') ",sFullName);

    printf("992:sTmpSql=[%s]\n",sTmpSq3);
	$prepare pre_B12 from $sTmpSq3;
	$execute pre_B12 using $sIclaim, $iclose_type, $mclaim;


	/* 8.�s�Wca_local_stl (�t�X�x�_���b,�u�g��x�_) */
    sprintf(sTmpSq3,
        " insert into newa00:ca_local_stl \
             (dentry, ientry, iclaim, fstl, iclose_type, \
              ipolicy, icard, fchoose, ibranch) \
           values \
             (today, ?, ?, '2', ?, \
              ?, ?, '1', '00') ");
        printf("ca585_ca_local_stl[%s]\n",sTmpSq3);

    printf("1007:sTmpSql=[%s]\n",sTmpSq3);

    $prepare pre_B13 from $sTmpSq3;
    $execute pre_B13
       using $userid, $sIclaim, $iclose_type, $sIpolicy, $sIcard;


	/* 9.�g�J�O���� (ca_clm_com_trans) */
	sprintf(sTmpSql2,
    	"insert into sysdb:ca_clm_com_trans "
		"	(idate_ym, inumber, icompany, iclaim_p, icard_p, "
		"   fvictim_nation, icar_type, qpt, fpt, itag, "
		"   dacc_yy, dacc_mm, dacc_dd, dacc_hh, dacc_ms, "
		"   iacc_reason, iacc_area, nassured, ivictim, dvictim, "
		"   iins_item1, iins_item2, mins_stl, fvictim_car, qduty_adjuster, "
		"   qduty_adjuster2, qduty_adjuster3, itag2, oth_company,	oth_card, "
		"   mprem, itransno, ipolicy, iclaim, fstl, "
		"   iclose_type, adjustment, daccident, iins_item, istl_flag, "
		"   icreate, dcreate, iqserial, iupdate, dupdate, itmp_no ) "
     	" select a.datamth, b.inumber, b.icompany, b.iclaim, b.icard, "
     	"       b.fvictim_nation, b.icar_type, b.qpt, b.fpt, b.itag, "
     	"       b.dacc_yy, b.dacc_mm, b.dacc_dd, b.dacc_hh, b.dacc_ms, "
     	"       b.iacc_reason, b.iacc_area, b.nassured, b.ivictim, b.dvictim, "
     	"       b.iins_item1, nvl(b.iins_item2,' '), b.mins_stl, b.fvictim_car, b.qduty_adjuster, "
     	"       b.qduty_adjuster2, b.qduty_adjuster3, b.itag2, b.oth_company, b.oth_card, "
     	"       b.mprem, '%s', '%s', b.iclaim, '2', "
     	"       %d, '%s', b.daccident, b.iins_item, 'A', "
     	"       '%s', current, ' ', '%s', current, a.ireceive "
        "  from car9264_tpm2 a, car9264_tpm1 b "
        " where a.iclaim = b.iclaim "
        "   and cast(a.icompany as int) = cast(b.oth_company as int) "
        "   and a.iclaim = '%s'  and a.ireceive = '%s' "
        "   and a.mclaim = (select sum(mprem) from car9264_tpm1 c "
        "                    where c.iclaim = a.iclaim and cast(c.oth_company as int) = cast(a.icompany as int) ) ",
      sTransno, sIpolicy, iclose_type, sIofficer, userid, userid, sIclaim, sIreceive);

    printf("1043:sTmpSql=[%s]\n",sTmpSql2);

	$prepare pre_B14 from $sTmpSql2;
    $execute pre_B14;


    /* ����ˮ� add by sylvia 111.06.22 (1110602007_SC2) */
    /* 1.�ˮ�settlement */
    ichk1 = 0;
    sprintf(sTmpSql,
	    	"SELECT sum(msettle)  \
			   FROM %s:settlement  \
			  WHERE iclaim = '%s' AND fstl = '2' and iclose_type = %d  ",
			  sFullName, sIclaim, iclose_type);
    $prepare pre_dck1 from $sTmpSql;
    $execute pre_dck1 into $ichk1;

    if (ichk1 != mclaim)
    {
        rc = 14037;
        sprintf(errMsg, "[%s]\n �i�߮׸�:%s  �Ƚs: %s�j �g�Jsettlement�P�Ƚs���B����,�нT�{ \n",
            "car585_insert:", trim(sIclaim), trim(sIreceive));

        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        $SET LOCK MODE TO NOT WAIT;
        return rc;
    }

    /* 2.�ˮ� ca_stl_victim */
    ichk1 = 0;
    sprintf(sTmpSql,
	    	"SELECT sum(mins_stl)  \
			   FROM %s:ca_stl_victim  \
			  WHERE iclaim = '%s' AND fstl = '2' and iclose_type = %d  ",
			  sFullName, sIclaim, iclose_type);
    $prepare pre_dck2 from $sTmpSql;
    $execute pre_dck2 into $ichk1;

    if (ichk1 != mclaim)
    {
        rc = 14037;
        sprintf(errMsg, "[%s]\n �i�߮׸�:%s  �Ƚs: %s�j �g�Jca_stl_victim�P�Ƚs���B����,�нT�{ \n",
            "car585_insert:", trim(sIclaim), trim(sIreceive));

        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        $SET LOCK MODE TO NOT WAIT;
        return rc;
    }

    /* 3.�ˮ� payment */
    ichk1 = 0;
    sprintf(sTmpSql,
	    	"SELECT sum(mpayment)  \
			   FROM %s:payment  \
			  WHERE iclaim = '%s' AND fstl = '2' and iclose_type = %d  ",
			  sFullName, sIclaim, iclose_type);
    $prepare pre_dck2 from $sTmpSql;
    $execute pre_dck2 into $ichk1;

    if (ichk1 != mclaim)
    {
        rc = 14037;
        sprintf(errMsg, "[%s]\n �i�߮׸�:%s  �Ƚs: %s�j �g�Jpayment�P�Ƚs���B����,�нT�{ \n",
            "car585_insert:", trim(sIclaim), trim(sIreceive));

        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        $SET LOCK MODE TO NOT WAIT;
        return rc;
    }

    /* 3.�ˮ� ca_clm_com_trans */
    ichk1 = 0;
    sprintf(sTmpSql,
	    	"SELECT sum(mprem)  \
			   FROM sysdb:ca_clm_com_trans  \
			  WHERE iclaim = '%s' AND fstl = '2' and iclose_type = %d \
			    and istl_flag in ('A') and itmp_no =  '%s' ",
			  sIclaim, iclose_type,sIreceive);
    $prepare pre_dck3 from $sTmpSql;
    $execute pre_dck2 into $ichk1;

    if (ichk1 != mclaim)
    {
        rc = 14037;
        sprintf(errMsg, "[%s]\n �i�߮׸�:%s  �Ƚs: %s�j �g�Jca_clm_com_trans�P�Ƚs���B����,�нT�{ \n",
            "car585_insert:", trim(sIclaim), trim(sIreceive));

        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        $SET LOCK MODE TO NOT WAIT;
        return rc;
    }

	return SUCCESS;

errexit:
    rc = cm_show_sql_err("car585_insert", "");
    rgetmsg(SQLCODE, sErrorMsg, sizeof(sErrorMsg));
    sprintf(errMsg2, sErrorMsg, sqlca.sqlerrm);
    sprintf(errMsg, "[%s]\n �i�߮׸�:%s  �Ƚs: %s�j SQLERROR(%d):%s\n",
            "car585_insert:", trim(sIclaim), trim(sIreceive), SQLCODE, errMsg2);

    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}
