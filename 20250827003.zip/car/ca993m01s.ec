/**********************************************************************/
/*   program id   : ca993m01s.ec                                      */
/*   program name : ���I�O��s�P��ƺ��@�@�~                          */
/*   date written : 2022/07/15                                        */
/*   author       : 071004                                            */                                        
/**********************************************************************/
     
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"
$include sqlca;
$include decimal;


long car993(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car993_insert(),car993_single_query(),car993_history_query(),car993_update_exec(),car993_req_del(),car993_now_query();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
	   rtncode=car993_insert(reply);
	   break;
  case 'R':
	   rtncode=car993_req_del(reply); /*�ШD�R���O��s�P���x���-�ШD�R��*/
	   break;
  case 'Q':
	   rtncode=car993_single_query(reply);
	   break;
  case 'N':
	   rtncode=car993_now_query(reply);    /*�ШD�R���O��s�P���x���-�d��*/
	   break;
  case 'M':
           rtncode=car993_history_query(reply);/*�ǰe���{�d�ߡB�h���ƳB�z-�d��*/
	   break;
  case 'D':
  case 'U':
	   rtncode=car993_update_exec(reply,command,com_len);
	   break;
  default :
	   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
	    return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}
/*****************************************************************************************************/
long car993_insert(reply)
serverReply reply;
{

    $char DBName[5];

    $dec_t dec;


    int tmp_len;
    DBinfo *list;
    int i, j, k, is_add_fail=0, api_f;
    $char stmt_buf[2000],stmtx[2000],stmt1[500];
    $char userid[11];

    long MsgCode;

    $char  ipolicy[21], iendorse[21], iserno[3], ftype[2];
    $char  fassured_o[2], iassured_o[11], dbgn_o[11];
    $char  fapplicant_n[2],iapplicant_n[11],napplicant_n[121];
    $char  fassured_n[2],iassured_n[11],nassured_n[121];
    $char  dbgn_n[11],dend_n[11],fprocess[2],isys_source[4];
    $char  ntprop_cont[21],dpolicy[11],nremark[121],fstatus[4],iresult[5],nresult[121];
    $char  sdbgn_n[11], sdend_n[11], sdbgn_o[11], sdpolicy[11];
    
    $char  sins_count[4],sins_sno[4];
    $char  niins_name[251],niins_cont[251];
    int    iins_count;
    $int   iins_sno;
    
    cm_buf_get("%s %s",DBName,userid);
    cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
               ipolicy, iendorse, iserno, ftype,
               fassured_o, iassured_o, dbgn_o,
               fapplicant_n,iapplicant_n,napplicant_n,
               fassured_n,iassured_n,nassured_n,
               dbgn_n,dend_n,fprocess,isys_source,
               ntprop_cont,dpolicy,nremark,fstatus,iresult,nresult);
    
    cm_buf_get("%s ",sins_count);
    
    iins_count = atoi(sins_count);
    printf("iins_count[%d]\n",iins_count);
    



    if (db_select(DBName) == False) 
    { 
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
            return M_CM_DB_NOTOPEN;
        else  
            return apiRC;
    }

 
    if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
    {
        if(exitsub(reply,M_CM_NOT_DBLIST) == True)
            return M_CM_NOT_DBLIST;
        return apiRC;
    }
  

    /*create temp table*/
    sprintf_s(stmt1, sizeof stmt1,"create temp table car993_tmp2_%s (     \n"
                  "    ipolicy      char(20), \n"
                  "    iendorse     char(20), \n"
                  "    iserno       char(2),  \n"
                  "    iassured_o   char(10), \n"
                  "    iins_sno     integer,  \n"
                  "    niins_name   varchar(250), \n"
                  "    niins_cont   varchar(250) \n"
		  "     )with no log; \n"
		  ,trim(userid));
		  
    $PREPARE crt_tmp2 FROM $stmt1;
    $EXECUTE crt_tmp2 ;	      
    printf("stmt1[%s]\n",stmt1);
    
    
    for(k=1;k<=iins_count;k++)
    {
    	cm_buf_get("%s ",sins_sno);
    	cm_buf_get("%s ",niins_name);
    	cm_buf_get("%s ",niins_cont);
    	
    	iins_sno= atoi(sins_sno);

	sprintf_s(stmt1, sizeof stmt1,"INSERT INTO car993_tmp2_%s \n"
		      "VALUES (? , ? , ? , ? ,    \n"
 		      "        ? , ? , ? )        \n"    
		      ,trim(userid));
	
        $PREPARE insert_tmp2 FROM $stmt1;
        $EXECUTE insert_tmp2 using $ipolicy, $iendorse, $iserno, $iassured_o,
                                   $iins_sno,$niins_name, $niins_cont;

        printf("stmt1[%s]\n",stmt1);
        
        
    	
    }    
    
  

    $BEGIN WORK;
    for(j=0;j<i;j++)
    {
    	
        strcpy(sdbgn_n, cm_to_infdate(dbgn_n));
        strcpy(sdend_n, cm_to_infdate(dend_n));
        strcpy(sdbgn_o, cm_to_infdate(dbgn_o));
        strcpy(sdpolicy, cm_to_infdate(dpolicy));
    	
    	/*�D��*/
        sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:cm_ply_passbook \n"
 	                 "       (iins_cat, ipolicy, iendorse, iserno, ftype, \n"
 	                 "        fassured_o, iassured_o, dbgn_o, \n"
 	                 "        fapplicant_n, iapplicant_n, napplicant_n, \n"
 	                 "        fassured_n, iassured_n, nassured_n, \n"
 	                 "        dbgn_n, dend_n, fprocess, isys_source, \n"
 	                 "        ntprop_cont, dwritten, dentry, nremark, fstatus, \n"
 	                 "        iresult, nresult, iupdate, dupdate)\n"
	                 "VALUES ('C',?,?,?,?, \n"
	                 "        ?,?,?, \n"
	                 "        ?,?,?, \n"
	                 "        ?,?,?, \n"
	                 "        ?,?,?,?, \n"
	                 "        ?,?,current,?,?, \n"
	                 "        ?,?,?,current) \n"
                         ,list[j].dbname);
	
        $PREPARE insert_1 FROM $stmt_buf;
        $EXECUTE insert_1 USING  $ipolicy,     $iendorse,    $iserno,       $ftype,
                                 $fassured_o,  $iassured_o,  $sdbgn_o,
                                 $fapplicant_n,$iapplicant_n,$napplicant_n,
                                 $fassured_n,  $iassured_n,  $nassured_n,
                                 $sdbgn_n,     $sdend_n,     $fprocess,     $isys_source,
                                 $ntprop_cont, $sdpolicy,    $nremark,      $fstatus,
                                 $iresult,     $nresult,     $userid;
   
        if(SQLCODE != 0)
        {
            is_add_fail = 1;
            break;
        }
        
        /*������*/
        sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:cm_ply_passbook_dtl \n"
	                 " SELECT 'C',* FROM car993_tmp2_%s \n"
                         ,list[j].dbname,trim(userid));
	
        $PREPARE insert_2 FROM $stmt_buf;
        $EXECUTE insert_2 ;
        
        if(SQLCODE != 0)
        {
            is_add_fail = 1;
            break;
        }        
        
        
        /*Drop temp table*/
        sprintf_s(stmt1, sizeof stmt1,"DROP TABLE car993_tmp2_%s; \n",trim(userid));	   
        $PREPARE Drop_tmp2 FROM  $stmt1;
        $EXECUTE Drop_tmp2; 
        

        
        cm_buf_init(ReplyBuf);
        cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
        tmp_len = cm_buf_len(ReplyBuf);
        if( j == i-1 )
            api_f = api_OKComplete;
        else
            api_f = api_OK;

        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
        {
            is_add_fail = 2;
            break;
        }  

    } /* for loop */

    if( is_add_fail == 1 ) goto errexit;

    if( is_add_fail == 2 ) 
    {
        $ROLLBACK WORK;
        return apiRC;
    }


    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;
    return api_OKComplete;

errexit:
    $WHENEVER SQLERROR CONTINUE;    
    MsgCode = SQLCODE;
    $ROLLBACK WORK;
    if (SQLCODE != 0) MsgCode = SQLCODE;
    if(exitsub(reply,MsgCode) == True) 
        return MsgCode;
    else  
        return apiRC;
}
/*****************************************************************************************************/
long car993_req_del(reply) /*�ШD�R���O��s�P���x���-�ШD�R��*/
serverReply reply;
{


    $char DBName[5];

    $dec_t dec;

    int tmp_len;
    DBinfo *list;
    int i, j, is_add_fail=0, api_f;
    $char stmt_buf[2000],stmtx[2000];
    
    $char ipolicy[21],fassured[2],iassured[11],dbgn[11],dend[11],itag[21],dpolicy[11],iendorse[21];
    $char sdbgn[11],sdend[11],sdpolicy[11];
    $char ftype[2], isys_source[4],snumber[3],userid[11],iserno_del[5];
    $int  iserno = 0;
    
    long MsgCode;


    cm_buf_get("%s %s",DBName,userid);
    cm_buf_get("%s %s %s %s %s %s %s",ipolicy,fassured,iassured,dbgn,dend,itag,dpolicy);
    cm_buf_get("%s ",iendorse);

    if (db_select(DBName) == False) 
    { 
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
            return M_CM_DB_NOTOPEN;
        else  
            return apiRC;
    }


 
    if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
    {
        if(exitsub(reply,M_CM_NOT_DBLIST) == True)
            return M_CM_NOT_DBLIST;
        return apiRC;
    }
  

    strcpy(sdbgn, cm_to_infdate(dbgn));
    strcpy(sdend, cm_to_infdate(dend));
    strcpy(sdpolicy, cm_to_infdate(dpolicy));
    strcpy(iendorse, trim(iendorse));
    
    $BEGIN WORK;
    for(j=0;j<i;j++)
    {
    	
    	

        sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT FIRST 1 ftype, isys_source,iserno \n"
                         "  FROM sysdb:cm_ply_passbook \n"
 	                 " WHERE ipolicy='%s' \n"
 	                 "   AND dbgn_n='%s' AND fassured_n='%s' \n"
 	                 "   AND iassured_n='%s' ORDER BY CAST (iserno AS INTEGER) desc\n"
                         ,ipolicy,sdbgn,fassured,iassured);
	
        $PREPARE req_del_1 FROM $stmt_buf;
        $EXECUTE req_del_1 INTO $ftype, $isys_source, $iserno_del;
        
        sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT nvl(max(CAST (iserno AS INTEGER )),0)+1 \n"
                         "  FROM sysdb:cm_ply_passbook \n"
 	                 " WHERE ipolicy='%s' \n"
 	                 ,ipolicy);
	
        $PREPARE req_del_2 FROM $stmt_buf;
        $EXECUTE req_del_2 INTO $iserno;        
            	
        sprintf_s(snumber, sizeof snumber, "%02d", iserno);    	
        
        if(strcmp(trim(iendorse),"")!=0)
        {
            strcat(iendorse,"-D");	
        }
        
        /*�D��*/    	
        sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:cm_ply_passbook \n"
 	                 "       (iins_cat,ipolicy, iendorse, iserno, ftype, \n"
 	                 "        fassured_o, iassured_o, dbgn_o, \n"
 	                 "        fapplicant_n, iapplicant_n, napplicant_n, \n"
 	                 "        fassured_n, iassured_n, nassured_n, \n"
 	                 "        dbgn_n, dend_n, fprocess, isys_source, \n"
 	                 "        ntprop_cont, dwritten, dentry, nremark, fstatus, iupdate, dupdate)\n"
	                 "VALUES ('C',?,'%s',?,?, \n"
	                 "        ?,?,?, \n"
	                 "        '','','', \n"
	                 "        '','','', \n"
	                 "        ?,?,'D',?, \n"
	                 "        ?,?,current,'',100,?,current) \n"
                         ,list[j].dbname,iendorse);
	
        $PREPARE req_del_3 FROM $stmt_buf;
        $EXECUTE req_del_3 USING $ipolicy, $snumber, $ftype,
                                 $fassured, $iassured, $sdbgn,
                                 $sdbgn,$sdend,$isys_source,
                                 $itag, $sdpolicy, $userid;
        
        if(SQLCODE != 0)
        {
            is_add_fail = 1;
            break;
        }
        
        /*������*/
        sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:cm_ply_passbook_dtl \n"
 	                 "SELECT iins_cat, ipolicy, '%s', '%s', iassured_o, \n"
 	                 "       iins_sno, niins_name, niins_cont \n"
                         "  FROM cm_ply_passbook_dtl \n"
                         " WHERE iins_cat = 'C' AND ipolicy='%s' AND iserno='%s' \n"
                         ,list[j].dbname, iendorse, snumber, ipolicy, iserno_del); 
        
        $PREPARE req_del_4 FROM $stmt_buf;
        $EXECUTE req_del_4 ;
        
        if(SQLCODE != 0)
        {
            is_add_fail = 1;
            break;
        }
           
        
        cm_buf_init(ReplyBuf);
        cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
        tmp_len = cm_buf_len(ReplyBuf);
        if( j == i-1 )
            api_f = api_OKComplete;
        else
            api_f = api_OK;

        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
        {
            is_add_fail = 2;
            break;
        }  

    } /* for loop */

    if( is_add_fail == 1 ) goto errexit;

    if( is_add_fail == 2 ) 
    {
        $ROLLBACK WORK;
        return apiRC;
    }


    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;
    return api_OKComplete;

errexit:
    $WHENEVER SQLERROR CONTINUE;    
    MsgCode = SQLCODE;
    $ROLLBACK WORK;
    if (SQLCODE != 0) MsgCode = SQLCODE;
    if(exitsub(reply,MsgCode) == True) 
        return MsgCode;
    else  
        return apiRC;
}
/*****************************************************************************************************/
long car993_single_query(reply)
serverReply reply;
{

    $char DBName[5];

    $dec_t dec;

    int tmp_len;
    $char  ipolicy[21],iendorse[21], iserno[3];
    $char  stmt1[200];

    $char  v_ipolicy[21], v_iendorse[21], v_iserno[3], v_ftype[2];
    $char  v_fassured_o[2], v_iassured_o[11], v_dbgn_o[11];
    $char  v_fapplicant_n[2],v_iapplicant_n[11],v_napplicant_n[121];
    $char  v_fassured_n[2],v_iassured_n[11],v_nassured_n[121];
    $char  v_dbgn_n[11],v_dend_n[11],v_fprocess[2],v_isys_source[4];
    $char  v_ntprop_cont[21],v_dpolicy[11],v_nremark[121],v_fstatus[4],v_iresult[5],v_nresult[121];
    $char  v_iupdate[11],v_dupdate[25]; 
    
    $int   v_iins_count = 0,v_iins_sno = 0;    
    $char  v_niins_name[251], v_niins_cont[251];
        
            
    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s %s",ipolicy,iendorse, iserno);


    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False) 
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
            return M_CM_DB_NOTOPEN;
        else  
            return apiRC;
    }

    /*�D��*/

    $SELECT ipolicy,      iendorse,     iserno, ftype,
            fassured_o,   iassured_o,   dbgn_o,
            fapplicant_n, iapplicant_n, napplicant_n,
            fassured_n,   iassured_n,   nassured_n,
            dbgn_n,       dend_n,       fprocess,      isys_source,
            ntprop_cont,  dwritten,     nremark,       fstatus,     
            iresult,      nresult,
            iupdate,      dupdate
       INTO $v_ipolicy,     $v_iendorse,    $v_iserno,     $v_ftype,
            $v_fassured_o,  $v_iassured_o,  $v_dbgn_o,
            $v_fapplicant_n,$v_iapplicant_n,$v_napplicant_n,
            $v_fassured_n,  $v_iassured_n,  $v_nassured_n,
            $v_dbgn_n,      $v_dend_n,      $v_fprocess,   $v_isys_source,
            $v_ntprop_cont, $v_dpolicy,     $v_nremark,    $v_fstatus,     
            $v_iresult,     $v_nresult,
            $v_iupdate,     $v_dupdate
       FROM cm_ply_passbook
      WHERE ipolicy=$ipolicy AND iendorse=$iendorse AND iserno=$iserno;

    if(SQLCODE==SQLNOTFOUND) 
    {
        if(exitsub(reply,M_CA_NDEPRE_RATE) == True) 
            return M_CA_NDEPRE_RATE; 
        else  
            return apiRC;
    }



    cm_buf_init(ReplyBuf); 
    cm_buf_put("%l",M_CM_OK);
    cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
                v_ipolicy,     v_iendorse,    v_iserno,     v_ftype,
                v_fassured_o,  v_iassured_o,  v_dbgn_o,
                v_fapplicant_n,v_iapplicant_n,v_napplicant_n,
                v_fassured_n,  v_iassured_n,  v_nassured_n,
                v_dbgn_n,      v_dend_n,      v_fprocess,   v_isys_source,
                v_ntprop_cont, v_dpolicy,     v_nremark,    v_fstatus,     
                v_iresult,     v_nresult,
                v_iupdate,     v_dupdate);
    
    
    /*������*/
    
    $SELECT count(*)
       INTO $v_iins_count
       FROM cm_ply_passbook_dtl
      WHERE ipolicy=$ipolicy AND iendorse=$iendorse AND iserno=$iserno;
      
    cm_buf_put("%d ",v_iins_count);
      
    
    strcpy(stmt1,"SELECT iins_sno, trim(niins_name), trim(niins_cont) \n"
		  "  FROM sysdb:cm_ply_passbook_dtl \n"
		  " WHERE ipolicy = ? AND iendorse = ? AND iserno=? \n");
		  
			
    $PREPARE CUR_IINS FROM $stmt1;
    $DECLARE cur_iins_dtl CURSOR FOR CUR_IINS;
    $OPEN cur_iins_dtl using $ipolicy, $iendorse, $iserno;
    printf("stmt1[%s]\n",stmt1);
	
    while (1)
    {
			
        $FETCH cur_iins_dtl INTO $v_iins_sno, $v_niins_name, $v_niins_cont;
	            
	if (SQLCODE == SQLNOTFOUND) break;
			            
        cm_buf_put("%d %s %s", v_iins_sno, v_niins_name, v_niins_cont);
			            
		            
    }
    $CLOSE cur_iins_dtl;
    $FREE cur_iins_dtl;
    
    
    
    
    
    
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    if(exitsub(reply,SQLCODE) == True) 
        return SQLCODE;
    else  
        return apiRC;
}
/*****************************************************************************************************/
long car993_now_query(reply)
serverReply reply;
{
    
    $char DBName[5];
    
    $dec_t dec;
    $char  ipolicy[21];
    char   userid[7];
    $char  stmt1[1024],sTmp1[1024];

    char tmpbuf[4000];
    int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int i,total_count=0; 
    
        
    $char  ipolicy_tmp[21],iendorse_tmp[21],ftype_tmp[2],fassured_o_tmp[2],iassured_o_tmp[11],dbgn_o_tmp[11];
    $char  fapplicant_n_tmp[2],iapplicant_n_tmp[11],napplicant_n_tmp[121],fassured_n_tmp[2],iassured_n_tmp[11],nassured_n_tmp[121];
    $char  dbgn_n_tmp[11],dend_n_tmp[11],fprocess_tmp[2],isys_source_tmp[4];
    $char  ntprop_cont_tmp[21],dpolicy_tmp[11],nremark_tmp[210];
    $int   linnum = 0;

    $char  sIpolicy[21];
    $char  ntype[5]; 
    $char  fapplicant_n[2], iapplicant_n[11], napplicant_n[11];
    $char  fassured_n[2],iassured_n[11],nassured_n[11];
    $char  dbgn_n[11],dend_n[11],ntprop_cont[21],dpolicy[11],nremark[65],iendorse[21];      

                           

    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s", ipolicy,userid);


    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False) 
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
            return M_CM_DB_NOTOPEN;
        else  
            return apiRC;
    }


    
    strcpy(ipolicy_tmp,"");
    strcpy(iendorse_tmp,"");
    strcpy(ftype_tmp,"");
    strcpy(fassured_o_tmp,"");
    strcpy(iassured_o_tmp,"");
    strcpy(dbgn_o_tmp,"");
    strcpy(fapplicant_n_tmp,"");
    strcpy(iapplicant_n_tmp,"");
    strcpy(napplicant_n_tmp,"");
    strcpy(fassured_n_tmp,"");
    strcpy(iassured_n_tmp,"");
    strcpy(nassured_n_tmp,"");
    strcpy(dbgn_n_tmp,"");
    strcpy(dend_n_tmp,"");
    strcpy(fprocess_tmp,"");
    strcpy(isys_source_tmp,"");
    strcpy(ntprop_cont_tmp,"");
    strcpy(dpolicy_tmp,"");
    strcpy(nremark_tmp,"");


    

    /*create temp table*/
    sprintf_s(stmt1, sizeof stmt1,"create temp table car993_tmp1_%s (  \n"   
                  "    ipolicy      char(20), \n"
                  "    iendorse     char(20), \n"
 		  "    ftype        char(1), \n"
                  "    fapplicant_n char(1), \n"
                  "    iapplicant_n char(10), \n"
		  "    napplicant_n varchar(120), \n"
		  "    fassured_n   char(1), \n"
		  "    iassured_n   char(10), \n"
		  "    nassured_n   varchar(120), \n"
		  "    dbgn_n       date, \n"
		  "    dend_n       date, \n"
		  "    isys_source  char(3), \n"
		  "    ntprop_cont  char(20), \n"
		  "    dpolicy      date, \n"
		  "    nremark      char(210), \n"
		  "    linnum       int  )with no log; \n"
		  ,trim(userid));
		  
    $PREPARE crt_tmp FROM $stmt1;
    $EXECUTE crt_tmp ;
    
		      
    printf("stmt1[%s]\n",stmt1);
    
    			    
    /*�g�Jcar993_tmp1*/
			    
    strcpy(stmt1,"SELECT ipolicy,replace(iendorse,'-D',''),ftype,fassured_o,iassured_o,dbgn_o, \n"
 		  "       fapplicant_n,iapplicant_n,napplicant_n, \n"
 		  "       fassured_n,iassured_n,nassured_n, \n"
                  "       dbgn_n,dend_n,fprocess,isys_source, \n"
                  "       ntprop_cont,dwritten,nremark \n"
		  "  FROM sysdb:cm_ply_passbook \n"
		  " WHERE ipolicy = ? ORDER BY CAST (iserno AS INTEGER) \n");
		  
			
    $PREPARE CUR_NEWEST FROM $stmt1;
    $DECLARE cur_refresh CURSOR FOR CUR_NEWEST;
    $OPEN cur_refresh using $ipolicy;
    printf("stmt1[%s]\n",stmt1);
	
    while (1)
    {
			
        $FETCH cur_refresh INTO $ipolicy_tmp,      $iendorse_tmp,      $ftype_tmp,        $fassured_o_tmp,   $iassured_o_tmp, $dbgn_o_tmp,
 			        $fapplicant_n_tmp, $iapplicant_n_tmp, $napplicant_n_tmp, 
 			        $fassured_n_tmp,   $iassured_n_tmp,   $nassured_n_tmp,
                                $dbgn_n_tmp,       $dend_n_tmp,       $fprocess_tmp,     $isys_source_tmp,
                                $ntprop_cont_tmp,  $dpolicy_tmp,      $nremark_tmp;
			            
			            
	if (SQLCODE == SQLNOTFOUND) break;
			            
	if (strcmp(fprocess_tmp,"A") == 0)
	{
            sprintf_s(stmt1, sizeof stmt1,"SELECT count(*)+1 \n"
		          "  FROM car993_tmp1_%s \n"
		          " WHERE ipolicy = '%s' \n"
		          ,trim(userid),ipolicy);	
		          
            $PREPARE fprocess_A_1 FROM $stmt1;
            $EXECUTE fprocess_A_1 INTO $linnum;
                                  
            sprintf_s(stmt1, sizeof stmt1,"INSERT INTO car993_tmp1_%s \n"
		          "VALUES (? , ? , ? ,        \n"
		          "        ? , ? , ? ,        \n"
 		          "        ? , ? , ? ,        \n"
 		          "        ? , ? , ? ,        \n"
 		          "        ? , ? , ? , ? );   \n"
		          ,trim(userid));
	
	             
            $PREPARE fprocess_A_2 FROM $stmt1;
            $EXECUTE fprocess_A_2 using $ipolicy_tmp,      $iendorse_tmp,     $ftype_tmp,
		                        $fapplicant_n_tmp, $iapplicant_n_tmp, $napplicant_n_tmp, 
 		                        $fassured_n_tmp,   $iassured_n_tmp,   $nassured_n_tmp,
 		                        $dbgn_n_tmp,       $dend_n_tmp,       $isys_source_tmp,
 		                        $ntprop_cont_tmp,  $dpolicy_tmp,      $nremark_tmp,      $linnum;
			            	
	}
	else if (strcmp(fprocess_tmp,"U") == 0)
	{
		
            sprintf_s(stmt1, sizeof stmt1,"UPDATE car993_tmp1_%s     \n"
		          "   SET iendorse = ?,  \n"
		          "       ftype = ?,  \n"
		          "       fapplicant_n = ?, \n"
		          "       iapplicant_n = ?, \n"
		          "       napplicant_n = ?, \n"
		          "       fassured_n = ?, \n"
		          "       iassured_n = ?, \n"
		          "       nassured_n = ?, \n"
		          "       dbgn_n = ?, \n"
		          "       dend_n = ?, \n"
		          "       isys_source = ?, \n"
		          "       ntprop_cont = ?, \n"
		          "       dpolicy = ?, \n"
		          "       nremark = ? \n"
		          " WHERE ipolicy    = ? \n"
		          "   AND fassured_n = ? \n"
		          "   AND iassured_n = ? \n"
		          "   AND dbgn_n     = ? ; \n"
		          ,trim(userid));		
	    
	    
            $PREPARE fprocess_U_1 FROM  $stmt1;
            $EXECUTE fprocess_U_1 using $iendorse_tmp,     $ftype_tmp,
                                        $fapplicant_n_tmp, $iapplicant_n_tmp, $napplicant_n_tmp,
	                                $fassured_n_tmp,   $iassured_n_tmp,   $nassured_n_tmp,
	                                $dbgn_n_tmp,       $dend_n_tmp,
	                                $isys_source_tmp,  $ntprop_cont_tmp,  $dpolicy_tmp,      $nremark_tmp,
	                                $ipolicy_tmp,
	                                $fassured_o_tmp,
	                                $iassured_o_tmp,
	                                $dbgn_o_tmp;


	}
	else if(strcmp(fprocess_tmp,"D") == 0)
	{
            sprintf_s(stmt1, sizeof stmt1,"DELETE FROM car993_tmp1_%s     \n"
		          " WHERE ipolicy    = ? \n"
		          "   AND fassured_n = ? \n"
		          "   AND iassured_n = ? \n"
		          "   AND dbgn_n     = ? ; \n"
		          ,trim(userid));
		          	   
            printf("ipolicy_tmp[%s] \n",ipolicy_tmp);
            printf("fassured_o_tmp[%s] \n",fassured_o_tmp);
            printf("iassured_o_tmp[%s] \n",iassured_o_tmp);
            printf("dbgn_o_tmp[%s] \n",dbgn_o_tmp);
            
            $PREPARE fprocess_D_1 FROM  $stmt1;
            $EXECUTE fprocess_D_1 using $ipolicy_tmp,
	                                $fassured_o_tmp,
	                                $iassured_o_tmp,
	                                $dbgn_o_tmp;
	                                
			            	
	}
			            
		            
    }
    $CLOSE cur_refresh;
    $FREE cur_refresh;



    sprintf_s(sTmp1, sizeof sTmp1,"SELECT ipolicy,CASE ftype WHEN  'P' THEN '�ȥ�' ELSE '�q�l' END , \n"
                  "       fapplicant_n,iapplicant_n,napplicant_n[1,12], \n"
                  "       fassured_n,iassured_n,nassured_n[1,12], \n"
                  "       nvl(dbgn_n,''),nvl(dend_n,''),ntprop_cont,dpolicy,nremark,iendorse \n"
                  " FROM  car993_tmp1_%s WHERE ipolicy= ?  \n"
                  ,trim(userid));
    printf("sTmp1=[%s]\n",sTmp1);

    $PREPARE n1_pre FROM $sTmp1;
    $DECLARE n1_cur CURSOR FOR n1_pre;
    $OPEN n1_cur using $ipolicy;


    for(;;)
    {
    
        $FETCH n1_cur into $sIpolicy, 
                           $ntype, 
                           $fapplicant_n, $iapplicant_n, $napplicant_n,
                           $fassured_n,   $iassured_n,   $nassured_n,
                           $dbgn_n,       $dend_n,       $ntprop_cont,  $dpolicy, $nremark, $iendorse;
                           
                           
        if (SQLCODE != 0) break;

        cm_buf_init(tmpbuf); 
        if ( count == 0 )
        {
            cm_buf_res_msg();             /* reserve for MsgCode and count */
            cm_buf_res_count();          
        }

    
        cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s %s",
                   sIpolicy,      
                   ntype,        
                   fapplicant_n, iapplicant_n, napplicant_n,
                   fassured_n,   iassured_n,   nassured_n,
                   dbgn_n,       dend_n,       ntprop_cont,  dpolicy, nremark, iendorse);
        
        
        
        tmp_len = cm_buf_len(tmpbuf);
        if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
        {
            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else                               /* more than 4K, send to client side */ 
        { 
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);
            if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {

	        $CLOSE m1_cur;
	        $FREE m1_cur;
                return apiRC;
            }
            else               /* clear ReplyBuf and count to start all over again */
            {
                replycnt++;
                if (replycnt == 10)   /* more than 30K, client cannot display,error */
                {
	            cm_buf_init(ReplyBuf);
                    cm_buf_put("%l",M_CM_OUT_SPACE);
                    tmp_len = cm_buf_len(ReplyBuf);
                    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                        return apiRC;
                        
                    return M_CM_OUT_SPACE; 
                }
	        ReplyBuf[0] = '\0';
	        count = 0;
	        cm_buf_init(ReplyBuf);
                cm_buf_res_msg();           /* reserve for MsgCode and count */
                cm_buf_res_count();    
                cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s %s",
                           sIpolicy,      
                           ntype,        
                           fapplicant_n, iapplicant_n, napplicant_n,
                           fassured_n,   iassured_n,   nassured_n,
                           dbgn_n,       dend_n,       ntprop_cont,  dpolicy, nremark, iendorse);

	        repbuf_len = cm_buf_len(ReplyBuf);
	        count++;
            }
        } 
    }/* for loop */


    $CLOSE n1_cur;
    $FREE n1_cur;
  
    sprintf_s(stmt1, sizeof stmt1,"DROP TABLE car993_tmp1_%s; \n",trim(userid));	   

    $PREPARE Drop_tmp FROM  $stmt1;
    $EXECUTE Drop_tmp;  
    
    
    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
          return apiRC;
          
        return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
        if(exitsub(reply,M_CM_NOT_FOUND) == True) 
            return M_CM_NOT_FOUND;
        else  
            return apiRC;
    } 


   
   
   
errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}
/******************************************************************************/
long car993_history_query(reply)
serverReply reply;
{

    $char DBName[5];

    $dec_t dec;
    $char  sTmp1[1000], sTmp2[100],ipolicy[21];

    char tmpbuf[4000];
    int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int i,total_count=0; 

    $char  nprocess[5],sIpolicy[21],sIendorse[21],iserno[3];
    $char  ntype[5],fassured_o[2],iassured_o[11],dbgn_o[11]; 
    $char  fapplicant_n[2], iapplicant_n[11], napplicant_n[11];
    $char  fassured_n[2],iassured_n[11],nassured_n[11];
    $char  dbgn_n[11],dend_n[11],ntprop_cont[21],dpolicy[11];      
    $char  nremark[24],fstatus[4],dentry[25],dtransfer[25],dfinish[25],iupdate[10],dupdate[25];


    cm_buf_get("%s",DBName);
    cm_buf_get("%s",ipolicy);


    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False) 
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
            return M_CM_DB_NOTOPEN;
        else  
            return apiRC;
    }


    strcpy(sTmp1, "SELECT CASE fprocess WHEN 'A' THEN '�s�W' WHEN 'U' THEN '��' ELSE '�R��' END , \n"
                  "       ipolicy,iendorse,iserno, \n"
                  "       CASE ftype WHEN  'P' THEN '�ȥ�' ELSE '�q�l' END ,\n"
                  "       fassured_o,iassured_o,nvl(dbgn_o,''), \n"
                  "       fapplicant_n,iapplicant_n,napplicant_n[1,12], \n"
                  "       fassured_n,iassured_n,nassured_n[1,12], \n"
                  "       nvl(dbgn_n,''),nvl(dend_n,''),ntprop_cont,dwritten,nremark,fstatus, \n"
                  "       dentry,dtransfer,dfinish,iupdate,dupdate \n"
                  " FROM  cm_ply_passbook WHERE ipolicy= ? ORDER BY CAST (iserno AS INTEGER) \n");
    printf("sTmp1=[%s]\n",sTmp1);

    $PREPARE m1_pre FROM $sTmp1;
    $DECLARE m1_cur CURSOR FOR m1_pre;
    $OPEN m1_cur using $ipolicy;


    for(;;)
    {
    
        $FETCH m1_cur into $nprocess,   
                           $sIpolicy,     $sIendorse,    $iserno, 
                           $ntype, 
                           $fassured_o,   $iassured_o,   $dbgn_o,
                           $fapplicant_n, $iapplicant_n, $napplicant_n,
                           $fassured_n,   $iassured_n,   $nassured_n,
                           $dbgn_n,       $dend_n,       $ntprop_cont,  $dpolicy, $nremark, $fstatus,
                           $dentry,       $dtransfer,    $dfinish,      $iupdate, $dupdate;
                           
                           
        if (SQLCODE != 0) break;

        cm_buf_init(tmpbuf); 
        if ( count == 0 )
        {
            cm_buf_res_msg();             /* reserve for MsgCode and count */
            cm_buf_res_count();          
        }

    
        cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
                   nprocess,     sIpolicy,     sIendorse,    iserno, 
                   ntype,        fassured_o,   iassured_o,   dbgn_o,
                   fapplicant_n, iapplicant_n, napplicant_n,
                   fassured_n,   iassured_n,   nassured_n,
                   dbgn_n,       dend_n,       ntprop_cont,  dpolicy, 
                   nremark,      fstatus,      dentry,       dtransfer,    dfinish,
                   iupdate,      dupdate);
        
        
        
        tmp_len = cm_buf_len(tmpbuf);
        if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
        {
            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else                               /* more than 4K, send to client side */ 
        { 
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);
            if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {

	        $CLOSE m1_cur;
	        $FREE m1_cur;
                return apiRC;
            }
            else               /* clear ReplyBuf and count to start all over again */
            {
                replycnt++;
                if (replycnt == 10)   /* more than 30K, client cannot display,error */
                {
	            cm_buf_init(ReplyBuf);
                    cm_buf_put("%l",M_CM_OUT_SPACE);
                    tmp_len = cm_buf_len(ReplyBuf);
                    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                        return apiRC;
                        
                    return M_CM_OUT_SPACE; 
                }
	        ReplyBuf[0] = '\0';
	        count = 0;
	        cm_buf_init(ReplyBuf);
                cm_buf_res_msg();           /* reserve for MsgCode and count */
                cm_buf_res_count();    
                cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
                           nprocess,     sIpolicy,     sIendorse,    iserno, 
                           ntype,        fassured_o,   iassured_o,   dbgn_o,
                           fapplicant_n, iapplicant_n, napplicant_n,
                           fassured_n,   iassured_n,   nassured_n,
                           dbgn_n,       dend_n,       ntprop_cont,  dpolicy, 
                           nremark,      fstatus,      dentry,       dtransfer,    dfinish,
                           iupdate,      dupdate);

	        repbuf_len = cm_buf_len(ReplyBuf);
	        count++;
            }
        } 
    }/* for loop */


    $CLOSE m1_cur;
    $FREE m1_cur;
  
    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
          return apiRC;
          
        return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
        if(exitsub(reply,M_CM_NOT_FOUND) == True) 
            return M_CM_NOT_FOUND;
        else  
            return apiRC;
    } 

errexit:

    if(exitsub(reply,SQLCODE) == True) 
        return SQLCODE;
    else  
        return apiRC;
}
/******************************************************************************/

long car993_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{

    $char DBName[5];


    $dec_t dec;
    $int t_count;

    char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
    int tmp_len,raw_len;
    long dummy=0;
    DBinfo *list;
    int i, j, k, is_del_fail=0, is_upd_fail=0;
    $char stmt_buf[2000],userid[11],stmt1[500];

    $char  bef_ipolicy[21], bef_iendorse[21], bef_iserno[3];

    $char  sbef_dbgn_n[11], sbef_dend_n[11], sbef_dbgn_o[15], sbef_dpolicy[11];

    $char  aft_ipolicy[21], aft_iendorse[21], aft_iserno[3], aft_ftype[2];
    $char  aft_fassured_o[2], aft_iassured_o[11], aft_dbgn_o[11];
    $char  aft_fapplicant_n[2],aft_iapplicant_n[11],aft_napplicant_n[121];
    $char  aft_fassured_n[2],aft_iassured_n[11],aft_nassured_n[121];
    $char  aft_dbgn_n[11],aft_dend_n[11],aft_fprocess[2],aft_isys_source[4];
    $char  aft_ntprop_cont[21],aft_dpolicy[11],aft_nremark[121],aft_fstatus[4];
    $char  aft_iresult[5],aft_nresult[121];
    
    $char  saft_dbgn_n[11], saft_dend_n[11], saft_dbgn_o[15], saft_dpolicy[11];

    $char  sins_count[4],sins_sno[4];
    $char  niins_name[251],niins_cont[251];
    int    iins_count;
    $int   iins_sno;

    long MsgCode;


    comm = (char *) command;
    cm_buf_init(command);
    cm_buf_get("%c %s %s",&option,DBName,userid);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
            return M_CM_DB_NOTOPEN;
        else  
            return apiRC;
    }

    if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
    {
        if(exitsub(reply,M_CM_NOT_DBLIST) == True)
            return M_CM_NOT_DBLIST;
        return apiRC;
    }
    /* compare old record and current record, if the record has not been changed  
       since last request, update or delete the record, otherwise return errmsg
       to client side */

    /* get old record info from command buffer */ 
    /*memcpy(&raw_len,&comm[com_len],sizeof(int));   
    pos = &comm[com_len+sizeof(int)];
    raw_ptr = malloc(raw_len);
    if (raw_ptr != (char*)0)  
        memcpy(raw_ptr,pos,raw_len);
    else
    {
        /*if(exitsub(reply,M_CM_NOT_MALLOC) == True)*/   /* malloc fail */ 
            /*return M_CM_NOT_MALLOC;
        else  
            return apiRC;*/
    /*}*/
    
    /*cm_buf_init(raw_ptr); */         /* get index key from old record */
    /*cm_buf_get("%l",&dummy);*/

               
    cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
               bef_ipolicy, bef_iendorse, bef_iserno,
               aft_ipolicy, aft_iendorse, aft_iserno, aft_ftype,
               aft_fassured_o, aft_iassured_o, aft_dbgn_o,
               aft_fapplicant_n,aft_iapplicant_n,aft_napplicant_n,
               aft_fassured_n,aft_iassured_n,aft_nassured_n,
               aft_dbgn_n,aft_dend_n,aft_fprocess,aft_isys_source,
               aft_ntprop_cont,aft_dpolicy,aft_nremark,aft_fstatus,
               aft_iresult,aft_nresult);

    if ( option == 'U' )
    {
        cm_buf_get("%s ",sins_count);
    
        iins_count = atoi(sins_count);
        printf("iins_count[%d]\n",iins_count);

        /*create temp table*/
        sprintf_s(stmt1, sizeof stmt1,"create temp table car993_tmp3_%s (     \n"
                      "    ipolicy      char(20), \n"
                      "    iendorse     char(20), \n"
                      "    iserno       char(2),  \n"
                      "    iassured_o   char(10), \n"
                      "    iins_sno     integer,  \n"
                      "    niins_name   varchar(250), \n"
                      "    niins_cont   varchar(250) \n"
		      "     )with no log; \n"
		      ,trim(userid));
		  
        $PREPARE crt_tmp3 FROM $stmt1;
        $EXECUTE crt_tmp3 ;
        printf("stmt1[%s]\n",stmt1);
    
    
        for(k=1;k<=iins_count;k++)
        {
    	    cm_buf_get("%s ",sins_sno);
    	    cm_buf_get("%s ",niins_name);
    	    cm_buf_get("%s ",niins_cont);
    	
    	    iins_sno= atoi(sins_sno);

	    sprintf_s(stmt1, sizeof stmt1,"INSERT INTO car993_tmp3_%s \n"
		          "VALUES (? , ? , ? , ? ,    \n"
 		          "        ? , ? , ? )        \n"    
		          ,trim(userid));
	
            $PREPARE insert_tmp3 FROM $stmt1;
            $EXECUTE insert_tmp3 using $aft_ipolicy, $aft_iendorse, $aft_iserno, $aft_iassured_o,
                                       $iins_sno,$niins_name, $niins_cont;

            printf("stmt1[%s]\n",stmt1);
        
        }
    }
    
    
    $BEGIN WORK; 
    

    
    if(strcmp(trim(aft_dbgn_o),"") != 0)
    {
        sprintf_s(saft_dbgn_o, sizeof saft_dbgn_o,"'%s'",cm_to_infdate(aft_dbgn_o));
    }
    else
    {
    	strcpy(saft_dbgn_o,"DATE('')");
    }


    strcpy(saft_dbgn_n,cm_to_infdate(aft_dbgn_n));
    strcpy(saft_dend_n,cm_to_infdate(aft_dend_n));
    strcpy(saft_dpolicy,cm_to_infdate(aft_dpolicy));
    
                   
    sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT count(*) \n"
                     "  FROM cm_ply_passbook \n"
                     " WHERE ipolicy      = '%s' \n" 
                     "   AND iendorse     = '%s' \n" 
                     "   AND iserno       = '%s' \n",
                     bef_ipolicy,      bef_iendorse,    bef_iserno);

    /* if key value has been changed then SQLNOTFOUND,else put current value
       into cur_buf for comparison */ 
       
    $PREPARE chk_in_table FROM $stmt_buf;
    $EXECUTE chk_in_table INTO $t_count;
		            
    if (SQLCODE == SQLNOTFOUND || t_count == 0)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        if(exitsub(reply,M_CM_NOT_FOUND) == True) 
            return M_CM_NOT_FOUND;
        else  
            return apiRC;
    }
    $WHENEVER SQLERROR GOTO errexit;



  
  
    /* equal, then exec DB operation */

    if ( option == 'D' )
    {
        for(j=0;j<i;j++)
        {
            sprintf_s(stmt_buf, sizeof stmt_buf,
                    "DELETE FROM %s:cm_ply_passbook \n"
                    " WHERE ipolicy = ? \n"
                    "   AND iendorse = ? \n"
                    "   AND iserno = ? \n" 
                    ,list[j].dbname);
                        
            $PREPARE d_id FROM $stmt_buf;
            if(SQLCODE != 0)
            {
                is_del_fail = 1; 
                break;
            }
            $EXECUTE d_id USING $bef_ipolicy, $bef_iendorse, $bef_iserno;
            if(SQLCODE != 0)
            {
                is_del_fail = 1; 
                break;
            }


            sprintf_s(stmt_buf, sizeof stmt_buf,
                    "DELETE FROM %s:cm_ply_passbook_dtl \n"
                    " WHERE ipolicy = ? \n"
                    "   AND iendorse = ? \n"
                    "   AND iserno = ? \n" 
                    ,list[j].dbname);
                        
            $PREPARE d_id2 FROM $stmt_buf;
            $EXECUTE d_id2 USING $bef_ipolicy, $bef_iendorse, $bef_iserno;
            

            
            
        }/* for loop */

        if( is_del_fail ) goto errexit;
   
        cm_buf_init(ReplyBuf);
        cm_buf_put("%l",M_CM_OK);
        tmp_len = cm_buf_len(ReplyBuf);
        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return apiRC;
        }  

        $WHENEVER SQLERROR GOTO errexit;
        $COMMIT WORK;
        return api_OKComplete;
    }
    else if (option == 'U')
    {
        $WHENEVER SQLERROR CONTINUE;
        for(j=0;j<i;j++)
        {
            
            /*�D��*/
            sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE %s:cm_ply_passbook                       \n"
   		             "   SET (ipolicy,iendorse,iserno,                \n"
   		             "        ftype,fassured_o,iassured_o,dbgn_o,     \n"
   		             "        fapplicant_n,iapplicant_n,napplicant_n, \n"
   		             "        fassured_n,iassured_n,nassured_n,       \n"
   		             "        dbgn_n,dend_n,fprocess,isys_source,     \n"
                             "        ntprop_cont,dwritten,nremark,fstatus,   \n"
                             "        iresult,nresult,                        \n"
                             "        iupdate,dupdate)                        \n"
	                     "      =(?,?,?,       \n"
	                     "        ?,?,?,%s,    \n"
	                     "        ?,?,?,       \n"
	                     "        ?,?,?,       \n"
	                     "        ?,?,?,?,     \n"
	                     "        ?,?,?,?,     \n"
	                     "        ?,?,         \n"
	                     "        ?,current)   \n"
	                     "  WHERE ipolicy = ?  \n"
	                     "    AND iendorse = ? \n"
	                     "    AND iserno = ?   \n"
	                     ,list[j].dbname,saft_dbgn_o);

            $PREPARE u_id FROM $stmt_buf;
            if(SQLCODE != 0)
            {
                is_upd_fail = 1;
                break;
            }
            $EXECUTE u_id using $aft_ipolicy,      $aft_iendorse,     $aft_iserno, 
                                $aft_ftype,        $aft_fassured_o,   $aft_iassured_o,   
                                $aft_fapplicant_n, $aft_iapplicant_n, $aft_napplicant_n,
                                $aft_fassured_n,   $aft_iassured_n,   $aft_nassured_n,
                                $saft_dbgn_n,      $saft_dend_n,      $aft_fprocess,     $aft_isys_source,
                                $aft_ntprop_cont,  $saft_dpolicy,     $aft_nremark,      $aft_fstatus,
                                $aft_iresult,      $aft_nresult,
                                $userid,
                                $bef_ipolicy,      $bef_iendorse,     $bef_iserno;
                        
		
            if(SQLCODE != 0)
            {
                is_upd_fail = 1;
                break;
            }
            
           
            
            
            if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
            {
            	
                sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:cm_ply_passbook \n"
                                 "       (iins_cat, ipolicy, iendorse, iserno, ftype, \n"
 	                         "        fassured_o, iassured_o, dbgn_o, \n"
 	                         "        fapplicant_n, iapplicant_n, napplicant_n, \n"
 	                         "        fassured_n, iassured_n, nassured_n, \n"
 	                         "        dbgn_n, dend_n, fprocess, isys_source, \n"
 	                         "        ntprop_cont, dwritten, dentry, nremark, fstatus, iresult, nresult, iupdate, dupdate) \n"
	                         "VALUES ('C',?,?,?,?, \n"
	                         "        ?,?,%s, \n"
	                         "        ?,?,?, \n"
	                         "        ?,?,?, \n"
	                         "        ?,?,?,?, \n"
	                         "        ?,?,current,?,?,?,?,?,current) \n"
                                 ,list[j].dbname,saft_dbgn_o);
	
                $PREPARE ua_id FROM $stmt_buf;
                if(SQLCODE != 0)
                {
                    is_upd_fail = 1; 
                    break;
                }
        
                $EXECUTE ua_id USING  $aft_ipolicy,     $aft_iendorse,    $aft_iserno,       $aft_ftype,
                                      $aft_fassured_o,  $aft_iassured_o,  
                                      $aft_fapplicant_n,$aft_iapplicant_n,$aft_napplicant_n,
                                      $aft_fassured_n,  $aft_iassured_n,  $aft_nassured_n,
                                      $saft_dbgn_n,     $saft_dend_n,     $aft_fprocess,     $aft_isys_source,
                                      $aft_ntprop_cont, $saft_dpolicy,    $aft_nremark,      $aft_fstatus,     $aft_iresult, $aft_nresult, $userid;
                if(SQLCODE != 0)
                {
                    is_upd_fail = 1; 
                    break;
                }                         
                                 
            }


            /*������(���R���A�s�W)*/

            sprintf_s(stmt_buf, sizeof stmt_buf,
                    "DELETE FROM %s:cm_ply_passbook_dtl \n"
                    " WHERE ipolicy = ? \n"
                    "   AND iendorse = ? \n"
                    "   AND iserno = ? \n" 
                    ,list[j].dbname);
                        
            $PREPARE d_id3 FROM $stmt_buf;
            $EXECUTE d_id3 USING $bef_ipolicy, $bef_iendorse, $bef_iserno;
            
            sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:cm_ply_passbook_dtl \n"
	                     " SELECT 'C',* FROM car993_tmp3_%s \n"
                             ,list[j].dbname,trim(userid));
	
            $PREPARE insert_3 FROM $stmt_buf;
            $EXECUTE insert_3 ;
        
            if(SQLCODE != 0)
            {
                is_upd_fail = 1;
                break;
            }        
        
        
            /*Drop temp table*/
            sprintf_s(stmt1, sizeof stmt1,"DROP TABLE car993_tmp3_%s; \n",trim(userid));	   
            $PREPARE Drop_tmp3 FROM  $stmt1;
            $EXECUTE Drop_tmp3; 
            
            

        } /* for loop */

        


            
        if( is_upd_fail ) goto errexit;    
            
        cm_buf_init(ReplyBuf);
        cm_buf_put("%l",M_CM_OK);
        tmp_len = cm_buf_len(ReplyBuf);
        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return apiRC;
        }  

        $WHENEVER SQLERROR GOTO errexit;
        $COMMIT WORK;
        return api_OKComplete;
    }
    else
    {
        if(exitsub(reply,M_CM_WRONG_OPTION) == True) 
            return M_CM_WRONG_OPTION;
        else  
            return apiRC;
    } 

errexit:
    $WHENEVER SQLERROR CONTINUE;
    MsgCode = SQLCODE;
    $ROLLBACK WORK;
    if (SQLCODE != 0) MsgCode = SQLCODE;
    if(exitsub(reply,MsgCode) == True) 
        return MsgCode;
    else  
        return apiRC;
}