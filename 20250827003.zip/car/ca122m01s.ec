/************************************************/
/*                                              */
/*   PROGRAM : _RRxxxx.ec                       */
/*                                              */
/************************************************/
     
#include <stdio.h>
#include <decimal.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include "safeclib.h"


long car122(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car122_insert(),car122_single_query(),car122_multiple_query(),car122_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 
 switch(option)
 {
  case 'A':
           rtncode=car122_insert(reply);
           break;
  case 'Q':
           rtncode=car122_single_query(reply);
           break;
  case 'M':
           rtncode=car122_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car122_update_exec(reply,command,com_len);
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
            return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

long car122_insert(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 $int qage_bgn,qage_end;
 $char fsex[2],drate[11], tmp_pfactor[17];
 $double pfactor;
 $char fcard_class[7];
 dec_t dec_psex_age;

 /* standard defined data */
 int tmp_len;
 long MsgCode;
   DBinfo *list;
   int i, j, is_add_fail=0, api_f;
   $char stmt_buf[300];
 /* end of standard data */


 cm_buf_get("%s",DBName);
 cm_buf_get("%s %d %d %s %s %s ",fcard_class,&qage_bgn,&qage_end,
             fsex,tmp_pfactor,drate);

  
 $WHENEVER SQLERROR GOTO errexit;
 
 if (db_select(DBName) == False) 
 { 
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
 }
 
 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
 {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
 }
    
 $BEGIN WORK;

 deccvasc(tmp_pfactor,strlen(tmp_pfactor),&dec_psex_age);
 dectodbl(&dec_psex_age,&pfactor);
 
 for(j=0;j<i;j++)
 {
  sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO %s:ca_sex_age_factor (fcard_class,qage_bgn,qage_end, fsex,pfactor,drate) VALUES (?,?,?,?,?,?)" ,list[j].dbname);

  $PREPARE a_id FROM $stmt_buf;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
   
  $EXECUTE a_id USING $fcard_class,$qage_bgn,$qage_end,$fsex,$pfactor,$drate;
  if(SQLCODE != 0)
   {
     is_add_fail = 1;
    break;
   }
   cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  tmp_len = cm_buf_len(ReplyBuf);
  if( j == i-1 )
     api_f = api_OKComplete;
  else
     api_f = api_OK;

  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    {
      is_add_fail = 2;
     break;
    }  
#ifdef DEBUG 
printf("INSERT %d\n", j+1);
#endif
 } /* for loop */

printf("is_add_fail = %d\n", is_add_fail);
 if( is_add_fail == 1 ) goto errexit;

 if( is_add_fail == 2 ) 
  {
   $ROLLBACK WORK;
   return apiRC;
  }

 
 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

 errexit:
  $WHENEVER SQLERROR CONTINUE;
   printf("in errexit: is_add_fail = %d, SQLCODE = %d\n", is_add_fail, SQLCODE);
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}

long car122_single_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 $int qage_bgn,qage_end;
 $char fsex[2],drate[11];  
 $double pfactor = 0.0;
 $char fcard_class[7], tmp_pfactor[20];
 /* standard defined data */
 int tmp_len;
 /* end of standard data */

 /* self defined data */
 /* end of self data */
 cm_buf_get("%s",DBName);
 cm_buf_get("%s",fcard_class);
 cm_buf_get("%d",&qage_bgn);
 cm_buf_get("%d",&qage_end);
 cm_buf_get("%s",fsex);
 cm_buf_get("%s",drate); 
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 $SELECT pfactor 
  INTO $pfactor
  FROM ca_sex_age_factor 
  WHERE fcard_class =$fcard_class
    AND qage_bgn=$qage_bgn
    AND qage_end=$qage_end 
    AND fsex=$fsex 
    AND drate=$drate; 

 if(SQLCODE==SQLNOTFOUND) 
 {
   if(exitsub(reply,M_CA_NSEX_AGE_FACTOR) == True) 
   return M_CA_NSEX_AGE_FACTOR; 
   else  
    return apiRC;
 }
 
 sprintf_s( tmp_pfactor, sizeof tmp_pfactor, "%3.12f", pfactor );
  
 cm_buf_init(ReplyBuf); 
 cm_buf_put("%l",M_CM_OK);
 cm_buf_put("%s %d %d %s %s %s",fcard_class,qage_bgn,qage_end,fsex,tmp_pfactor,drate);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}

long car122_multiple_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table _RR */
 $int qage_bgn = 0,qage_end = 0;
 $char fsex[2],drate[11],bgn[4],end[4];
 $char drate_bgn[11],drate_end[11],bgn_bgn[4],bgn_end[4],end_bgn[4],end_end[4];
 $double pfactor = 0.0;
 $char fcard_class[7], tmp_pfactor[17];
 /* end of _RR */

 /* standard defined data */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0; 
 /* end of standard data */

 /* self defined data */
 /* end of self data */

 cm_buf_get("%s",DBName);
 cm_buf_get("%s",fcard_class);
 cm_buf_get("%s",bgn); 
 cm_buf_get("%s",end);
 cm_buf_get("%s",fsex);
 cm_buf_get("%s",drate);
 if (drate[0]=='*'){
    strcpy(drate_bgn,"01/01/1910");
    strcpy(drate_end,"12/31/2200");
 } 
 else{
    strcpy(drate_bgn,drate);
    strcpy(drate_end,drate);
 }
 if(bgn[0]=='*')
 {
        strcpy(bgn_bgn,"0");
        strcpy(bgn_end,"120");
 }
 else{
        strcpy(bgn_bgn,bgn);
        strcpy(bgn_end,bgn);
 }
  if(end[0]=='*')
 {
        strcpy(end_bgn,"0");
        strcpy(end_end,"120");
 }
 else{
        strcpy(end_bgn,end);
        strcpy(end_end,end);
 }
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 $DECLARE q_cur CURSOR FOR
    SELECT fcard_class,qage_bgn,qage_end,fsex,pfactor,drate
    INTO  $fcard_class,$qage_bgn,$qage_end,$fsex,$pfactor,$drate
    FROM ca_sex_age_factor 
    WHERE fcard_class MATCHES $fcard_class
    AND qage_bgn BETWEEN $bgn_bgn AND $bgn_end
    AND qage_end BETWEEN $end_bgn AND $end_end 
    AND fsex MATCHES $fsex 
    AND drate BETWEEN $drate_bgn AND $drate_end
    ORDER BY fcard_class,fsex;

 $OPEN q_cur;

 for(;;)
  {
    $FETCH q_cur;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf); 
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();          
     }
    
    sprintf_s( tmp_pfactor, sizeof tmp_pfactor, "%3.12f", pfactor );
    
    cm_buf_put("%s %d %d %s %s %s",fcard_class,qage_bgn,qage_end,fsex,tmp_pfactor,drate);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */ 
     { 
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE; 
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
            
        cm_buf_put("%s %d %d %s %s %s",fcard_class,qage_bgn,qage_end,fsex,tmp_pfactor,drate);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     } 
  } /* for loop */

 $CLOSE q_cur;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CA_NSEX_AGE_FACTOR) == True) 
    return M_CA_NSEX_AGE_FACTOR;
   else  
    return apiRC;
  } 

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}


long car122_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table _RR */
 $int qage_bgn,qage_end;
 $char fsex[2],drate[11];
 $double pfactor = 0.0;
 $double old_pfactor;
 $int old_qage_bgn,old_qage_end;
 $char old_fsex[2],old_drate[11];
 $char old_fcard_class[7],fcard_class[7];
 $char old_tmp_pfactor[17], tmp_pfactor[17];
 dec_t dec_psex_age;
 /* end of _RR */

 /* standard defined data */
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len;
 long dummy;
   DBinfo *list;
   int i, j, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[300];
 /* end of standard data */

 /* self defined data */
 long MsgCode;
 /* end of self data */

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }
 /* compare old record and current record, if the record has not been changed  
    since last request, update or delete the record, otherwise return errmsg
    to client side */

 /* get old record info from command buffer */ 

 memcpy(&raw_len,&comm[com_len],sizeof(int));   
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)  
  memcpy(raw_ptr,pos,raw_len);
 else
  {
   if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */ 
    return M_CM_NOT_MALLOC;
   else  
    return apiRC;
  }
    
 cm_buf_init(raw_ptr);          /* get index key from old record */
 cm_buf_get("%l %s %d %d %s %s %s",&dummy,old_fcard_class,&old_qage_bgn,&old_qage_end,
                             old_fsex,old_tmp_pfactor,old_drate);

 $BEGIN WORK;                
 $SELECT pfactor
    INTO $pfactor
    FROM ca_sex_age_factor 
   WHERE fcard_class = $old_fcard_class 
     AND qage_bgn=$old_qage_bgn 
     AND qage_end=$old_qage_end 
     AND fsex=$old_fsex 
     AND drate=$old_drate;

  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */ 

 if (SQLCODE == SQLNOTFOUND)
 {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CA_NSEX_AGE_FACTOR) == True) 
    return M_CA_NSEX_AGE_FACTOR;
   else  
    return apiRC;
 }
 $WHENEVER SQLERROR GOTO errexit;

 sprintf_s( tmp_pfactor, sizeof tmp_pfactor, "%3.12f", pfactor );

 cm_buf_init(cur_buf);
 cm_buf_put("%l %s %d %d %s %s %s",dummy,old_fcard_class,old_qage_bgn,
             old_qage_end,old_fsex,tmp_pfactor,old_drate);

 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CM_NOT_EQUAL) == True) 
    return M_CM_NOT_EQUAL;
   else  
    return apiRC;
  }
   $WHENEVER SQLERROR GOTO errexit;
 /* equal, then exec DB operation */
	free(raw_ptr);
 if ( option == 'D' )
  {
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf, "DELETE FROM %s: ca_sex_age_factor "
                       " WHERE fcard_class = ? and qage_bgn= ? AND qage_end=? "
                       " AND fsex=? AND drate=? " ,list[j].dbname); 
    $PREPARE d_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
    $EXECUTE d_id USING $old_fcard_class,$old_qage_bgn,$old_qage_end,$old_fsex,$old_drate;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
#ifdef DEBUG 
printf("Delete %d\n", j+1);
#endif
   }/* for loop */

   if( is_del_fail ) goto errexit;
   
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
/* 9/3/1993    $BEGIN WORK;               */ 
   cm_buf_init(command);
   cm_buf_get("%c %s %s %d %d %s %s %s",&option,DBName,fcard_class,&qage_bgn,
                   &qage_end,fsex,tmp_pfactor,drate);

   $WHENEVER SQLERROR CONTINUE;

   deccvasc(tmp_pfactor,strlen(tmp_pfactor),&dec_psex_age);
   dectodbl(&dec_psex_age,&pfactor);

   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf, "UPDATE %s:ca_sex_age_factor SET "
             " (fcard_class,qage_bgn,qage_end,fsex,pfactor,drate) "
             " = (?,?,?,?,?,?) WHERE fcard_class = ? AND qage_bgn = ? AND qage_end = ? "
             " AND fsex = ? AND drate = ?",list[j].dbname);

    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    $EXECUTE u_id USING $fcard_class,$qage_bgn,$qage_end,$fsex,$pfactor,$drate,
                        $old_fcard_class,$old_qage_bgn,$old_qage_end,$old_fsex,$old_drate;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {
        sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO %s:ca_sex_age_factor (fcard_class,qage_bgn,qage_end,fsex,pfactor,drate) VALUES (?,?,?,?,?,?)" ,list[j].dbname);

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }
      $EXECUTE ua_id USING $fcard_class,$qage_bgn,$qage_end,$fsex,$pfactor,$drate;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }
     }
#ifdef DEBUG 
printf("Update %d\n", j+1);
#endif
   } /* for loop */

   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True) 
    return M_CM_WRONG_OPTION;
   else  
    return apiRC;
  } 

 errexit:
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}
