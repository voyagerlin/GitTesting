/************************************************/
/*                                              */
/*   PROGRAM : ca157m01s.ec                     */
/*                                              */
/*   PURPOSE : �f�B�~���[����T���@              */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"
$include datetime.h;

$include sqlca;

char errbuf[512];

long car157(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car157_insert(),car157_single_query(),car157_multiple_query();
 long car157_update_exec(),car157_CHT_iassured(), car157_CHT_iroute();
 char option;
 int tmp_len;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
           rtncode=car157_insert(reply);
           break;
  case 'Q':
           rtncode=car157_single_query(reply);
           break;
  case 'M':
           rtncode=car157_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car157_update_exec(reply,command,com_len);
           break;
  case 'C':
           rtncode=car157_check(reply);
           break;         
  case '1':
  			  rtncode=car157_CHT_iassured(reply);
  			  break;
  case '2':
  			  rtncode=car157_CHT_iroute(reply);
  			  break;			  
  case 'E':   /* ��ƾ��W�� */
           rtncode=car157_insert_batch(reply);

           cm_buf_init(ReplyBuf);
           cm_buf_put("%l %s" , rtncode, errbuf);

           tmp_len = cm_buf_len(ReplyBuf);
           if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
               return apiRC;
           else
               return api_OKComplete;
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
             return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

long car157_insert(reply)
serverReply reply;
{
  $char DBName[5];
  $char iassured[13],iofficer[11],iroute[20],safe_rate[5],manage_rate[5];
  $char drate[11],strdrate[11],iupdate[11];

  
  /* �s�W���Τ���� add by sylvia 101.12.18 (1010918004_C1) */
  $char dexpire[11],strdexpire[11];
  
  
  
  int tmp_len;
  DBinfo *list;
  int i, j, is_add_fail=0, api_f;
  $char stmt_buf[300];
  long MsgCode;

  cm_buf_get("%s %s %s %s %s %s %s %s %s",DBName, iassured, iofficer, safe_rate, manage_rate, iroute,strdrate, strdexpire, iupdate);
  		
  strcpy(drate,cm_to_infdate(strdrate));
  
  /* ���Τ� */
  strcpy(strdexpire, trim(strdexpire));
  if (strlen(strdexpire) > 0 )
  		strcpy(dexpire,cm_to_infdate(strdexpire));
  else
  		strcpy(dexpire,"");

  $WHENEVER SQLERROR GOTO errexit;



  $BEGIN WORK;
  
   sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO ca_truck_transport "
         " (Iassured,Iofficer,Safe_rate,Manage_rate,Iroute,Drate,Dexpire,Iupdate,Dupdate) "
	     " VALUES (?,?,?,?,?,?,?,?,current)");	 

   $PREPARE a_id FROM $stmt_buf;
   $EXECUTE a_id USING $iassured,$iofficer,$safe_rate,$manage_rate,$iroute,$drate,
                       $dexpire, $iupdate;
   
   if(SQLCODE != 0) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   api_f = api_OKComplete;

   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    {
     is_add_fail = 2;
    }  

  if( is_add_fail == 1 ) goto errexit;

  if( is_add_fail == 2 ) 
  {
   $ROLLBACK WORK;
   return apiRC;
  }


  $WHENEVER SQLERROR GOTO errexit;

  $COMMIT WORK;
  return api_OKComplete;

errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if (SQLCODE != 0) MsgCode = SQLCODE;		/* rollback fail */
   if(exitsub(reply,MsgCode) ==	True)
     return MsgCode;
   else
     return apiRC;
}

long car157_single_query(reply)
serverReply reply;
{
  $char DBName[5];
  $char iassured[13],iofficer[11],iroute[20],safe_rate[5],manage_rate[5];
  $char iassured_name[22],iofficer_name[11];
  $char drate[11],strdrate[11];
  $char iupdate[11],dupdate[20];

  /* �s�W���Τ���� add by sylvia 101.12.18 (1010918004_C1) */
	$char dexpire[11],strdexpire[11];
	
  int tmp_len;

  cm_buf_get("%s %s %s %s %s %s %s %s ",DBName,iassured,iofficer,iroute,safe_rate,manage_rate,strdrate,strdexpire);
  		
  strcpy(drate,cm_to_infdate(strdrate));
  
  

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
     if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
       return M_CM_DB_NOTOPEN;
     else
       return apiRC;
  }
  
  /* ���Τ� */
  strcpy(strdexpire, trim(strdexpire));
  if (strlen(strdexpire) > 0 )
  {	  
  		strcpy(dexpire,cm_to_infdate(strdexpire));
  		printf("1:dexpire=[%s]iassured=[%s]iofficer=[%s]\n",dexpire,iassured,iofficer);
  		$SELECT Iupdate, Dupdate
         INTO $iupdate, $dupdate
         FROM ca_truck_transport
        WHERE Iassured = $iassured
          AND Iofficer = $iofficer
          AND Safe_rate = $safe_rate
          AND Manage_rate = $manage_rate
          AND Iroute = $iroute
          AND Drate = $drate
          AND dexpire = $dexpire;
  }
  else
  {
  		printf("2:dexpire=[%s]iassured=[%s]iofficer=[%s]\n",dexpire,iassured,iofficer);
  		$SELECT Iupdate, Dupdate
         INTO $iupdate, $dupdate
         FROM ca_truck_transport
        WHERE Iassured = $iassured
          AND Iofficer = $iofficer
          AND Safe_rate = $safe_rate
          AND Manage_rate = $manage_rate
          AND iroute = $iroute
          AND Drate = $drate
          AND dexpire is null;
  }

  if(SQLCODE==SQLNOTFOUND)
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)       
      return M_CM_NOT_FOUND;                        
    else
      return apiRC;
  }
  
  /* �Q�O�I�H���� */
  	$SELECT nchi_full[1,20]
  	   INTO $iassured_name
  	   FROM cu_customer
  	  WHERE ifpce_id = $iassured
            AND ifpce_id_ext = '';
  /* �g��H���� */
   $SELECT nname
      INTO $iofficer_name
      FROM officer
     WHERE iofficer = $iofficer;
  
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s",M_CM_OK, iassured, iassured_name,iofficer,iofficer_name,
  		safe_rate, manage_rate, iroute,strdrate, strdexpire, iupdate, dupdate);
  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car157_multiple_query(reply)
serverReply reply;
{
  $char DBName[5];
  $char iassured[13],iofficer[11],safe_rate[5],manage_rate[5],iroute[20];
  $char tmp_iassured[13],tmp_iofficer[11],tmp_safe_rate[5],tmp_manage_rate[5],tmp_iroute[20];
  $char drate[11],strdrate[11],tmp_drate[11];
  $char stmt[1024];

  char tmpbuf[4000],stmt_drate[128], stmt_dexpire[200],stmt_safe_rate[200],stmt_manage_rate[200];
  int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
  int i,total_count=0;
  
  /* �s�W���Τ���� add by sylvia 101.12.18 (1010918004_C1) */
  $char dexpire[11],strdexpire[11],tmp_dexpire[11];
  printf("-------------------------------------------------------------------\n");
  cm_buf_get("%s %s %s %s %s %s %s %s",DBName, tmp_iassured, tmp_iofficer, tmp_safe_rate, tmp_manage_rate, tmp_iroute,strdrate, strdexpire);
  
  strcpy(tmp_drate,cm_to_infdate(strdrate));
  strcpy(strdexpire, trim(strdexpire));

  printf("-------------------------------------------------------------------\n");
  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  if (strcmp(trim(strdrate),"*") != 0) 
  {
  		strcpy(tmp_drate,cm_to_infdate(strdrate));
  		sprintf_s(stmt_drate, sizeof stmt_drate, "AND Drate = '%s'",tmp_drate);
  } 
  else 
  {
  		strcpy(stmt_drate,"");
  }
  
	
  if (strcmp(trim(strdexpire),"*") != 0) 
  {
  		strcpy(tmp_dexpire,cm_to_infdate(strdexpire));
  		sprintf_s(stmt_dexpire, sizeof stmt_dexpire, "AND dexpire = '%s'",tmp_dexpire);
  } 
  else 
  {
  		strcpy(stmt_dexpire,"");
  }
  
  
  if (strcmp(trim(tmp_safe_rate),"*") != 0) 
  {
  		sprintf_s(stmt_safe_rate, sizeof stmt_safe_rate, "and Safe_rate = '%s'",tmp_safe_rate);
  } 
  else 
  {
  		strcpy(stmt_safe_rate,"");
  }
  
  
  if (strcmp(trim(tmp_manage_rate),"*") != 0) 
  {
  		sprintf_s(stmt_manage_rate, sizeof stmt_manage_rate, "and Manage_rate = '%s'",tmp_manage_rate);
  } 
  else 
  {
  		strcpy(stmt_manage_rate,"");
  }
  
  

  	sprintf_s(stmt, sizeof stmt,
  		"select Iassured, Iofficer, Safe_rate, Manage_rate, iroute ,Drate , nvl(dexpire,'') "
        "         from ca_truck_transport "
        "        where Iassured matches ? "
        "          and Iofficer matches ? "
        "          and Iroute matches ? %s %s %s %s",stmt_safe_rate,stmt_manage_rate,stmt_drate,stmt_dexpire);
                    
   $PREPARE CUR_CAID FROM $stmt;
   $DECLARE IDcur CURSOR FOR CUR_CAID;
   $OPEN IDcur USING $tmp_iassured,$tmp_iofficer,$tmp_iroute;

   for(;;)
   {
     $FETCH IDcur INTO $iassured,$iofficer,$safe_rate,$manage_rate,$iroute,$drate, $dexpire;
     if (SQLCODE != 0) break;

     cm_buf_init(tmpbuf);
     if ( count == 0 )
     {
       cm_buf_res_msg();             /* reserve for MsgCode and count */
       cm_buf_res_count();
     }
     
     /* Convert Era Date to Chinese Date */
     strcpy(strdrate, cm_from_infdate_100(drate));
     strcpy(strdexpire, cm_from_infdate_100(dexpire));
     
     cm_buf_put("%s %s %s %s %s %s %s ", iassured, iofficer,iroute,safe_rate, manage_rate,
                 strdrate, strdexpire);
     tmp_len = cm_buf_len(tmpbuf);
     if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
       memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
       repbuf_len += tmp_len;
       count++;
     }
     else                               /* more than 4K, send to client side */
     {
       cm_buf_init(ReplyBuf);
       cm_buf_put_msg(M_CM_OK);
       cm_buf_put_count(count);
       if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
         $CLOSE IDcur;
         return apiRC;
       }
       else               /* clear ReplyBuf and count to start all over again */
       {
         replycnt++;
         if (replycnt == 10)   /* more than 30K, client cannot display,error */
         {
           cm_buf_init(ReplyBuf);
           cm_buf_put("%l",M_CM_OUT_SPACE);
           tmp_len = cm_buf_len(ReplyBuf);
           if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
               return apiRC;
           return M_CM_OUT_SPACE;
         }
         ReplyBuf[0] = '\0';
         count = 0;
         cm_buf_init(ReplyBuf);
         cm_buf_res_msg();           /* reserve for MsgCode and count */
         cm_buf_res_count();
         cm_buf_put("%s %s %s %s %s %s %s", iassured,iofficer,iroute,
         safe_rate,manage_rate,strdrate, strdexpire);
         repbuf_len = cm_buf_len(ReplyBuf);
         count++;
       }
     }
  } /* for loop */

  $CLOSE IDcur;
  if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
  else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

errexit:
   if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
   else
     return apiRC;
}

long car157_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
  $char DBName[5];
  $char iassured[13],iofficer[11],safe_rate[5],manage_rate[5],iroute[20];
  $char old_iassured[13],old_iofficer[11],old_safe_rate[5],old_manage_rate[5],old_iroute[20];
  $char drate[11],strdrate[11],old_drate[11];
  $char old_iupdate[11],old_dupdate[20];
  $char iupdate[11],dbdupdate[20],dupdate[20];
  $char old_cname[22],old_nname[11];
  
  char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
  int tmp_len,raw_len;
  long dummy;
  long MsgCode;
  DBinfo *list;
   int i, j, is_upd_fail=0,is_del_fail=0;
  $char stmt_buf[300];
  $char dexpire[11],strdexpire[11],old_dexpire[11];

	comm = (char *) command;
	cm_buf_init(command);
	cm_buf_get("%c %s",&option,DBName);

	$WHENEVER SQLERROR GOTO errexit;


	
	/* get old record info from command buffer */

	memcpy(&raw_len,&comm[com_len],sizeof(int));
	pos = &comm[com_len+sizeof(int)];
	raw_ptr = malloc(raw_len);

 	if (raw_ptr != (char*)0) {
    		memcpy(raw_ptr,pos,raw_len);
	}
 	else
    	{
    		if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
    			return M_CM_NOT_MALLOC;
    		else	return apiRC;
    	}
   
 	cm_buf_init(raw_ptr);          /* get index key from old record */
printf("see if it's here!!\n");
 	
	cm_buf_get("%l %s %s %s %s %s %s %s %s %s %s %s",&dummy, old_iassured,old_cname,old_iofficer,
	             old_nname, old_safe_rate, old_manage_rate, old_iroute, strdrate, strdexpire, old_iupdate, 
	             old_dupdate);
  							
   strcpy(old_drate,cm_to_infdate(strdrate));
   
   strcpy(strdexpire, trim(strdexpire));
   
   strcpy(old_dexpire,cm_to_infdate(strdexpire));
   printf("old_dexpire=[%s]\n",old_dexpire);
   free(raw_ptr);
 	$BEGIN WORK;
 	$WHENEVER SQLERROR GOTO errexit;
 	/* table lock is necessary to avoid concurrent update problems */
 	$LOCK TABLE ca_truck_transport IN SHARE MODE;

	if (strlen(strdexpire) > 0) 
	{
 			$SELECT Dupdate
         INTO $dbdupdate
         FROM ca_truck_transport
         WHERE Iassured = $old_iassured
           AND Iofficer = $old_iofficer
           AND Safe_rate = $old_safe_rate
           AND Manage_rate = $old_manage_rate
           AND Iroute = $old_iroute
           AND Drate = $old_drate
           AND dexpire = $old_dexpire;
   }
   else
   {
  		$SELECT Dupdate
         INTO $dbdupdate
         FROM ca_truck_transport
         WHERE Iassured = $old_iassured
           AND Iofficer = $old_iofficer
           AND Safe_rate = $old_safe_rate
           AND Manage_rate = $old_manage_rate
           AND Iroute = $old_iroute
           AND Drate = $old_drate
           AND dexpire is null;
    }
 	if (SQLCODE == SQLNOTFOUND)
        {
    		$WHENEVER SQLERROR CONTINUE;
    		$ROLLBACK WORK;
    		if (exitsub(reply,M_CM_NOT_FOUND) == True)
        		return M_CM_NOT_FOUND;
    		else
        		return apiRC;
    	}

 
printf("org. dentry=[%s],db. dentry[%s]\n",old_dupdate,dbdupdate);

 	if (strcmp(old_dupdate,dbdupdate) != 0)
        {
    		$WHENEVER SQLERROR CONTINUE;
    		$ROLLBACK WORK;
    		if(exitsub(reply,M_CM_NOT_EQUAL) == True)
        		return M_CM_NOT_EQUAL;
    		else
        		return apiRC;
    	}
    	
 	$WHENEVER SQLERROR GOTO errexit;

 	/* equal, then exec DB operation */

 	 if ( option == 'D' )
  	 {
   	
   		
   			if (strlen(trim(old_dexpire)) == 0)
   			{
   				sprintf_s(stmt_buf, sizeof stmt_buf, "DELETE FROM ca_truck_transport WHERE Iassured=? "
		     						" AND Iofficer=? AND Safe_rate=? AND Manage_rate=? AND Iroute = ? "
		     						" AND Drate=? and dexpire is null"); 
	    		$PREPARE d_idx FROM $stmt_buf;
	    		$EXECUTE d_idx USING $old_iassured,$old_iofficer,$old_safe_rate,$old_manage_rate,$old_iroute,$old_drate;  
   			}
   			else
   			{
   				sprintf_s(stmt_buf, sizeof stmt_buf, "DELETE FROM ca_truck_transport WHERE Iassured=? "
		     						" AND Iofficer=? AND Safe_rate=? AND Manage_rate=? AND Iroute = ? "
		     						" AND Drate=? and dexpire = ?"); 
	    		$PREPARE d_id FROM $stmt_buf;
	    		$EXECUTE d_id USING $old_iassured,$old_iofficer,$old_safe_rate,$old_manage_rate,$old_iroute,$old_drate, $old_dexpire;  
   				
   			}
    		
   	

   	 if( is_del_fail ) goto errexit;
   
   	 cm_buf_init(ReplyBuf);
   	 cm_buf_put("%l",M_CM_OK);
   	 tmp_len = cm_buf_len(ReplyBuf);
   	 
   	 if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    	 {
     		$WHENEVER SQLERROR CONTINUE;
     		$ROLLBACK WORK;
     		return apiRC;
    	 }  
	
   	$WHENEVER SQLERROR GOTO errexit;
   	$COMMIT WORK;
   	return api_OKComplete;
  	}
 	else if (option == 'U')
   {	
   	cm_buf_init(command);
   	cm_buf_get("%c %s",&option,DBName);
   	cm_buf_get("%s %s %s %s %s %s %s %s", iassured, iofficer, safe_rate, 
  							manage_rate, iroute , strdrate, strdexpire, iupdate);
  							
  		 strcpy(drate,cm_to_infdate(strdrate));
  		 strcpy(dexpire,cm_to_infdate(strdexpire));
  		 
                             
   	$WHENEVER SQLERROR CONTINUE;
   	
    		sprintf_s(stmt_buf, sizeof stmt_buf, "UPDATE ca_truck_transport SET "
		     		 " (Iassured,Iofficer,Safe_rate,Manage_rate,iroute,Drate,dexpire,Iupdate,Dupdate) "
		     		 " = (?,?,?,?,?,?,?,?,current) "
		     		 " WHERE Iassured=? AND Iofficer=? AND Safe_rate=? AND Manage_rate=? AND Iroute = ? "
		     		 "  AND Drate=?");

    		$PREPARE u_id FROM $stmt_buf;
    		$EXECUTE u_id USING $iassured,$iofficer,$safe_rate,$manage_rate,$iroute,$drate, $dexpire, $iupdate,
       								$old_iassured,$old_iofficer,$old_safe_rate,$old_manage_rate,$old_iroute,$old_drate;
    		
    		if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     		{
  				sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO ca_truck_transport "
         			 " (Iassured,Iofficer,Safe_rate,Manage_rate,Iroute,Drate, dexpire, Iupdate) "
	 				 " VALUES (?,?,?,?,?,?,?,?)");	 

      		$PREPARE ua_id FROM $stmt_buf;
      		
      		$EXECUTE ua_id USING $iassured,$iofficer,$safe_rate,$manage_rate,$iroute,$drate, $dexpire, $iupdate;
      		
     		}
   	

   	if( is_upd_fail ) goto errexit;


   	cm_buf_init(ReplyBuf);
   	cm_buf_put("%l",M_CM_OK);
   	tmp_len = cm_buf_len(ReplyBuf);
   	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    	{
     		$WHENEVER SQLERROR CONTINUE;
     		$ROLLBACK WORK;
     		return apiRC;
    	}  

   	$WHENEVER SQLERROR GOTO errexit;
   	$COMMIT WORK;
   	return api_OKComplete;
  } else {
   	if(exitsub(reply,M_CM_WRONG_OPTION) == True) 
    		return M_CM_WRONG_OPTION;
   	else  
    		return apiRC;
  } 

 errexit:
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else
    return apiRC;
}

/* Check Iassured and get Chinese Name */
long car157_CHT_iassured(reply)
serverReply reply;
{
	$char DBName[5];
 	$char assured_code[11];
 	$char assured_name[22];
 int tmp_len;

 cm_buf_get("%s %s",DBName, assured_code);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $SELECT first 1 nchi_full[1,20] 
  INTO   $assured_name
  FROM   cu_customer 
  WHERE  ifpce_id=$assured_code;

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CM_NASSURED) == True)       /*?*/
    return M_CM_NASSURED;                        /*?*/
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s",M_CM_OK, assured_name);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
	
long car157_CHT_iroute(reply)
serverReply reply;
{
	$char DBName[5];
 	$char iroute_code[30];
 	$char iroute_name[30];
 int tmp_len;

 cm_buf_get("%s %s",DBName, iroute_code);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $SELECT nroute 
  INTO   $iroute_name
  FROM   cm_route 
  WHERE (dexpire IS NULL OR dexpire >= today)
  AND    iroute = $iroute_code;

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CMN_NROUTE) == True)       /*?*/
    return M_CMN_NROUTE;                        /*?*/
  else
    return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s",M_CM_OK, iroute_name);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
	
/* ��ƾ��W�� */
long car157_insert_batch(reply)
serverReply reply;
{
  $char DBName[5], stmt[2048], stmt_buf[300];
  char  sApHome[30], filename[101],logname[101], cmd_str[2048], userid[11];
  $int  rc, cnt, rc1;
  int   stmt_len;
  int i, j, is_add_fail=0, api_f;
  long MsgCode;

   rc = getApHome(sApHome);
   if (rc<0) {
      strcpy( errbuf,"read Config file error!!-->getApHome\n");
      return rc;
   }

   sprintf_s(filename, sizeof filename, "%s/dat/car/car157.txt", sApHome);
   sprintf_s(logname, sizeof logname, "%s/rptftp/car157_log.txt",sApHome);

  cm_buf_get("%s %s",DBName, userid);
  		
  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
     sprintf_s(errbuf, sizeof errbuf, "��Ʈw�L�k�}��[%s]\n", DBName);
     return M_CM_DB_NOTOPEN;
  }

   /* ����J�Ȧs��,�T�{��J���O�_���T */
   stmt_len = 0;
   stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt,
              "select * from ca_truck_transport where 1=0 into temp temp1 with no log;\r\n");
   stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt,
                      "load from %s delimiter '\t' insert into temp1; \r\n",
                       filename);
   sprintf_s(cmd_str, sizeof cmd_str, "dbaccess sysdb > %s 2>&1 << !\r\n"
                   "%s\r\n!", logname, stmt);
   printf("cmd_str[%s]\n",cmd_str);
   rc = system(cmd_str);
   if (rc != 0) {
       sprintf_s(errbuf, sizeof errbuf, "load file error[%s]\n���I���ɮפU���@�~�d��[Q],�T�{���~��]", logname);
       rc1=rptftpinsert(userid,"car157","car157_log.txt");
       return rc;
   }
   /* ��J�����ɮ� */
   stmt_len = 0;

   stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt,
              "select * from ca_truck_transport where 1=0 into temp temp1 with no log;\r\n");

   stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt,
                      "load from %s delimiter '\t' insert into temp1; \r\n",
                       filename);

   stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt, 
                      "insert into ca_truck_transport select * from temp1;\r\n");
   sprintf_s(cmd_str, sizeof cmd_str, "dbaccess sysdb > %s 2>&1 << !\r\n"
                   "%s\r\n!", logname,stmt);
   printf("cmd_str[%s]\n",cmd_str);
   rc = system(cmd_str);
   if (rc != 0) {
       sprintf_s(errbuf, sizeof errbuf, "load file error[%s]\n���I���ɮפU���@�~�d��[Q],�T�{���~��]", logname);
       rc1=rptftpinsert(userid,"car157","car157_log.txt");
       return rc;
   }
   sprintf_s(errbuf, sizeof errbuf, "���槹��");
   return M_CM_OK;

errexit:
     sprintf_s(errbuf, sizeof errbuf, "SQLCODE[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
     return SQLCODE;
}

long car157_check(reply)
serverReply reply;
{
  $char DBName[5];
  $char iassured[13],iofficer[11],iroute[20];
  $char cnt[2];
	
  int tmp_len;

  cm_buf_get("%s %s %s %s ",DBName,iassured,iofficer,iroute);
  		

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
     if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
       return M_CM_DB_NOTOPEN;
     else
       return apiRC;
  }
  
  $SELECT case WHEN count(*) > 0 THEN 'Y' else 'N' END
     INTO $cnt 
     FROM ca_truck_transport 
    WHERE iassured = $iassured
      AND iofficer = $iofficer
      AND iroute = $iroute;
  
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s ",M_CM_OK, cnt);
  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}