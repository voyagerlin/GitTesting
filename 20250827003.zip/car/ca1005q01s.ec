/************************************************/
/*   PROGRAM : ca1005q01s.ec                    */
/*                                              */
/*                                              */
/*   NOTE    : �z�ߥӽЮ�                       */
/*   DATE    : 10/23/2003                       */
/************************************************/

#include <stdio.h>
#include <math.h>
#include <decimal.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "sql.h"
$include datetime.h;
$include sqlca;
#include "carday.h"
#include "safeclib.h"

#define SUCCESS 1
#define PETER   


$static char dbname_tp[45];
$static char taipei_db[40];

$static char Nassured[66], Aassured[111], Iassured[13], Ibirth[11];
$static char Imgr[2],Icard[21];
$static char Ipolicy_card[21];
$static char Dply_begin[17] , Dply_end[17];
$static char Tag_num[CA_TAG_NUM] , Engine_num[21] , Car_type[3] , Ibrand[9];
$static char Iissue_ym[7] , Ipro_year[5],Qpro_month[4];
$static char str1[21] , str1_yy[4] , str1_mm[3] , str1_dd[3];
$static char str2[21] , str2_yy[4] , str2_mm[3] , str2_dd[3];
$static char str3_tmp[21] , str3[21] , str3_yy[4] , str3_mm[3] , str3_dd[3];
$static char Dpay[21];
$static char Frcvpay[2];
$static char Payway[20];

$static double Pdmg_acc_tmp , Plia_acc_tmp;
$static char   Pdmg_acc[6] , Plia_acc[6];
$static double Qcylinder_tmp;
$static char   Qcylinder[9];


static $char iins_type[7];
static $float  injured_cover;
static $float  death_cover;
static $float  damage_cover;
static $int  deduct,Ibatch_no;
static $char prn_deduct[20],str_deduct[9];
static $char Fcard_class[2];
static $char fedr_status[2];
static $char Fcomp_24[2];

int people , iins;

static $long i_date;
static $int  ins_premium;
static $char Iofficer[11];
static $char Nname[11];
static $int  qcoverage;
static $char nins_type[29];
$char nins_abbr[20];
static $char edomain1[20];
static $char sFullName[21];
$char ao_policy1[21], ao_policy2[21];
$char ao_policy2_tmp[21];

char fcomp_24_note[30];
int  ins_no;
char ins_abbr[10][20],domain[10][20],oth_premium[10][20],cover[10][20];
char oth_deduct[10][20],oth_ins_type[10][2];
$char provision[6];


extern char  *get_mdeduct();
extern double get_mcover();
$char FullName[50], DBName1[3], DBName[5];
$include sqlca;
$include sqltypes;

static int errCode;
static int miy=0;
char OutFile[20];
char tmpBody[N_TFILE+1], tmpTitle[N_TFILE+1]; 
int tmp_len;
static int  max_count=0;
extern char outputf[N_FILE+1];
char rptstr1001[10000];
char rptstr_dtl[10000];
$char DBName[5];
$char FormTp[3];
$int PgLine;


  $char itag[CA_TAG_NUM];
  $char FormFile[20], OutFile[20];
  $char iassured[11],iassured_ext[3],iengine[CA_ENGINE_NUM]; 
  $char nchi_full[30],iemail[21],imovephone[12],aperm[41];
  $char tphone_con[14],tphone_ext_con[11];   
  $char stmt[500];
  $char Pipolicy[21];
  

static char *get_car_full_db();  /*   �ǤJ�O�渹��X���O�檺�k�ݸ��*/

   
/******************** �{���D��A�B�z���z�Უ�ͽ߮׸��X���z��u�@���Z ****************/
long car1001_print(reply)
serverReply reply;
{
int res;
char aphome[40];
$char hostname[N_NAME+1];

         cm_buf_get("%s",DBName);
         printf("-----DB[%s]\n",DBName);
         if (db_select(DBName) == False)
            return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
         $SET LOCK MODE TO  WAIT 110;

         res = getApHome(aphome);
         if (res<0)
         {
             printf("In sigalrmcatcher func==>read config file error!!\n");
             return FAIL;
         }

         printf("car1001_build_R begin\n");
         errCode= car1001_build(reply);
         if (errCode != 1) return FAIL;
             printf("car1001_build_R OK\n");

         gethostname(hostname,sizeof(hostname));
         sprintf_s(tmpBody, sizeof tmpBody,"%s/reportfile/%s",aphome,OutFile);
         cm_buf_init(ReplyBuf);
         miy=0;
         cm_buf_put("%l %s %s %d",(long)M_CM_OK,hostname,tmpBody,miy);

         tmp_len=cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
             return FAIL;
         else
             return SUCCESS;
}

/*���o���ӽЮѸ��*/
long car1001_rpt_get(e_sIpolicy)
$char *e_sIpolicy;                           /*�O�渹�X or ��渹�X*/
{
	int rc,i,j,k,rtncode;
	$char stmt[1024], sStmt[1024], sNapplicant[121], fdeduct[2];
	char DBName1[3];
	char sbuf[40];
	char tmp_ibatch_no[3],result1[3],comment1[31],date1[9],lastdate1[9];
	$char pay_date[9], sply_relation[21], spolicy[21], sply_ins_type[21], ipolicy[21], iendorse[21], iendorse_tmp[21], skey[21];
  $char sipolicy[21], check_fedr[11], iapplicant[13], sca_pa_ply[21], sca_pa_edr[21];
  $long qday=0, lIns_type, iedr, ldendorse=0, ireissueNumber;
  $char itmp_policy[21], ftype_sp[3], reissueNumber[4];
  
  $char nbeneficiary[31], sNbeneficiary[61], relation_bene[31], sRelation_bene[61];
  $char r_ibranch_in[3], feply[2], iroute[21], ileader[11], nleader[11],nins_type[29],nowner[121];
  $double mkilo_ply_tmp=0.0;
  $char   mkilo_ply[10],itel[21],nbrand[31];
  $char sDinstall_ym[7],sIsequence[31],sAinstall_zip[7],sAinstall[91];
  
	rptstr1001[0] = '\0';
	rptstr_dtl[0] = '\0';

	$WHENEVER SQLERROR GOTO errexit;

        strcpy( iendorse_tmp, e_sIpolicy);
	printf("Policy ==>[%s] \n",e_sIpolicy);
	strcpy(sFullName, get_car_full_db(e_sIpolicy));
	printf("sFullName ==>[%s], strlen[%d]\n",sFullName, strlen(sFullName));
	if( strlen(sFullName) == 0)
            return 8888;
	
	/*rtncode = cm_get_unit_in(e_sIpolicy," ","" , " " ,"C3",DBName1,"");*/
        
        sprintf_s(stmt, sizeof stmt,"SELECT icomp_in FROM %s:ply_relation "
                     " WHERE ipolicy = '%s'", sFullName, e_sIpolicy);
	$PREPARE prep1_1 FROM $stmt;
	$EXECUTE prep1_1 INTO $DBName1;
	
	if( SQLCODE == SQLNOTFOUND ) /* ����� */
        {
           strncpy(r_ibranch_in,e_sIpolicy,2);
           r_ibranch_in[2] = '\0';

           EXEC SQL SELECT iupcomp
                      INTO :DBName1
                      FROM branch
                     WHERE ibranch = :r_ibranch_in;
           if(SQLCODE == SQLNOTFOUND)
	      return SQLNOTFOUND;
        }
        printf("DBName1[%s]\n",DBName1);

        strcpy( skey, e_sIpolicy); /*�O�渹�X or ��渹�X*/

        sprintf_s(stmt, sizeof stmt,"SELECT ipolicy, dendorse FROM %s:edr_relation "
                     " WHERE iendorse = '%s'", sFullName, skey);
	$PREPARE prep1 FROM $stmt;
	$EXECUTE prep1 INTO $e_sIpolicy, $ldendorse; /* e_sIpolicy ���O�渹 */

        if( SQLCODE == SQLNOTFOUND) /* ���O�� */
        {
            strcpy( sply_relation, "ply_relation"); /* table name */
            strcpy( spolicy, "policy"); /* table name */
            strcpy( sply_ins_type, "ply_ins_type"); /* table name */
            strcpy( sipolicy, "ipolicy"); /* ���W��  */
            iedr = 0;
            strcpy( e_sIpolicy, skey); /* e_sIpolicy ���O�渹 */
            strcpy( sca_pa_ply, "ca_pa_ply"); /* table name */
        }
        else /* �Y�����, �C�L��e���A */
        {
            strcpy( sply_relation, "ply_relation_bak"); /* table name */
            strcpy( spolicy, "policy_bak"); /* table name */
            strcpy( sply_ins_type, "ply_ins_type_bak"); /* table name */
            strcpy( sipolicy, "iendorse"); /* ���W�� */
            iedr = 1;
            strcpy( sca_pa_edr, "ca_pa_edr"); /* table name */
        }

    /*1110718002_SC2 �s�W�L���q�ʤG�����A35���ا�� ibody */
	sprintf_s(stmt, sizeof stmt,"SELECT B.icard , B.nassured , B.iassured , "
            "        to_char(dbirth,'%%Y')::integer - 1911 || '/' || to_char(dbirth,'%%m')|| '/' || to_char(dbirth,'%%d'), "
            "         trim(B.aassured) || ' ' || trim(B.mobil_phone), A.dply_begin , "
			" A.dply_end , B.itag ,Case When A.icar_type<>'35' Then B.iengine Else B.ibody End AS iengine , "
			" A.icar_type , A.ibrand , to_char(dissue,'%%Y')::integer - 1911 || '/' || to_char(dissue,'%%m'), "
            " A.ipro_year , B.qpro_month , "
			" B.qcylinder , B.pdmg_acc , "
			" B.plia_acc , A.iofficer,(SELECT imgr FROM officer WHERE iofficer = A.iofficer) , A.fcard_class, A.ibatch_no, B.fcomp_24, B.napplicant, A.ipolicy, B.iapplicant, "
			" A.itmp_policy, A.feply, B.iroute,B.itel,B.mkilo_ply,B.nowner, "
			" nvl(to_char(B.dinstall,'%%Y')::integer - 1911 || '/' || to_char(B.dinstall,'%%m'),' '), "
			" B.isequence, B.ainstall_zip, B.ainstall "
		"FROM %s:%s A , %s:%s B "
		"WHERE A.%s = B.%s "
		"  AND A.%s = '%s' AND A.dply_close is not null",  
	sFullName, sply_relation, sFullName, spolicy, sipolicy, sipolicy, sipolicy, skey );
        printf("stmt[%s]\n", stmt);
	$PREPARE GET_PLY1 FROM $stmt;
	$EXECUTE GET_PLY1 
	INTO $Icard , $Nassured, $Iassured , $Ibirth , $Aassured , $Dply_begin , $Dply_end ,
		$Tag_num , $Engine_num ,
		$Car_type , $Ibrand , $Iissue_ym , $Ipro_year , $Qpro_month ,
		$Qcylinder_tmp , $Pdmg_acc_tmp ,
		$Plia_acc_tmp , $Iofficer, $Imgr, $Fcard_class, $Ibatch_no, $Fcomp_24, $sNapplicant, $ipolicy, $iapplicant,
		$itmp_policy, $feply, $iroute, $itel, $mkilo_ply_tmp , $nowner,
		$sDinstall_ym, $sIsequence, $sAinstall_zip, $sAinstall;

        printf("nassured[%s]\n", Nassured);
		printf("Engine_num[%s]\n", Engine_num);
		printf("sIsequence[%s]\n", sIsequence);
		printf("sAinstall_zip[%s]\n", sAinstall_zip);		

	if (SQLCODE==SQLNOTFOUND)
	{
            return 8888;
	}
	$SELECT nname , ileader
           INTO $Nname, $ileader
	   FROM officer WHERE iofficer = $Iofficer;
	
	$SELECT nname
           INTO $nleader
	   FROM officer WHERE iofficer = $ileader;
	
	ireissueNumber = 0;
	if (Fcard_class[0]=='2')
	{
        $SELECT COUNT(*)
           INTO $ireissueNumber
           FROM ca_log
          WHERE itype = 'P' 
            AND ipgid = 'car307'
            AND ilog_number1 = $ipolicy;
    }
	else  /*1101004008_SC1 �ץ����ӽЮѦC�L���u�ȥ��ɵo���ơv����W�h*/
	{
        $SELECT COUNT(*)
           INTO $ireissueNumber
           FROM ca_card_log
          WHERE ipolicy = $ipolicy;
	}
    sprintf_s(reissueNumber, sizeof reissueNumber, "%d", ireissueNumber);	

	/* �u�O�_���O�v���G��ܤ��e�O�_���O+�ĳq�ʽ� 
	    add by larry 104.01.19 (1040107011_C1) */	
	$SELECT ftype_sp INTO $ftype_sp
	   FROM cm_pre_receive
	  WHERE ipre_rcv = $itmp_policy
	    AND iins_kind = $Fcard_class
	    AND ipre_end = ' ';
	if (SQLCODE==SQLNOTFOUND) strcpy(ftype_sp," ");

	printf("Select policy and ply_relation OK!!!\n");
	printf("Icard =======>[%s] \n",Icard);
	
	/*�s�y�~��*/
        strcat(Ipro_year, "/");
        strcat(Ipro_year, trim(Qpro_month));
        printf("**********Ipro_year = %s \n",Ipro_year);

	/******** �O��_�l�� */
	printf("Dply_begin ==>[%s] \n",Dply_begin);
	strcpy(str1,cm_from_infdate_100(Dply_begin));

	/******** �O��פ�� */
	printf("Dply_end ====>[%s] \n",Dply_end);
	strcpy(str2,cm_from_infdate_100(Dply_end));

	/******** �N���e�Y���ഫ���r��κA *********/
	sprintf_s(Pdmg_acc, sizeof Pdmg_acc,"%5.2f",Pdmg_acc_tmp);     /*** ���� ***/
	sprintf_s(Plia_acc, sizeof Plia_acc,"%5.2f",Plia_acc_tmp);     /*** ���d ***/

	printf("the Pdmg_acc is [%s] \n",Pdmg_acc);
	printf("the Plia_acc is [%s] \n",Plia_acc);

	/******** �N�Ʈ�q�Ѽƭ���r�� ****************/
	/*sprintf_s(Qcylinder, sizeof Qcylinder,"%4d",Qcylinder_tmp);*/ 
	sprintf_s(Qcylinder, sizeof Qcylinder,"%7.2f",Qcylinder_tmp);   /*1080902001_SC2 �Ʈ�q�X�ܤp���I2��*/

	printf("the Qcylinder is [%s] \n",Qcylinder);

	/******** �d�߫O��O�_�w���O ******************/
	pay_date[0] = '\0';
	result1[0]  = '\0';
	comment1[0] = '\0';
	date1[0]    = '\0';
	lastdate1[0]= '\0';

	if(Ibatch_no >= 0)
		strcpy(tmp_ibatch_no," ");
	else
		sprintf_s(tmp_ibatch_no, sizeof tmp_ibatch_no,"%d",Ibatch_no);

	if(strlen(trim( e_sIpolicy)) > CAR_POLICY_LEN)
	{
		strncpy(ao_policy1 ,  e_sIpolicy , CAR_POLICY_LEN);
		strcpy(ao_policy2,substring( e_sIpolicy,CAR_POLICY_LEN+1,4));
	}
	else
	{
		strncpy(ao_policy1 ,  e_sIpolicy , CAR_POLICY_LEN);
		strcpy(ao_policy2," ");
	}
	strcpy(ao_policy1,trim(ao_policy1));
	strcpy(ao_policy2,trim(ao_policy2));
	ao_chk_charge(DBName1, 'A', ao_policy1, ao_policy2 , tmp_ibatch_no, result1,
					comment1, date1, lastdate1);

	printf("ca_rpt_app-----aochk--Res[%s]\n",result1);
	printf("ca_rpt_app---lastdate1[%s]\n",lastdate1);
	if(strcmp(trim(result1),"R1")==0)

		strcpy(Payway,"�w���O");

	else if(strcmp(trim(result1),"R2")==0)

		strcpy(Payway,"�w���O;�I�{");

	else if(strcmp(trim(result1),"R3")==0)

		strcpy(Payway,"�w���O;�S��");

	else if(strcmp(trim(result1),"R4")==0)
	{

		strcpy(Payway,"���I,");
		strcat(Payway,lastdate1);
		strcpy(pay_date," ");
	}
	else if(strcmp(trim(result1),"R5")==0)

		strcpy(Payway,"�w���O,���{");

	else if(strcmp(trim(result1),"R6")==0)

		strcpy(Payway,"�H�Υd���P�b");

	else if(strcmp(trim(result1),"N2")==0)
	{
		strcpy(Payway,"�h��;");
		strcat(Payway,lastdate1);
		strcpy(pay_date," ");
	}
	else if(strcmp(trim(result1),"NC")==0)

		strcpy(Payway,"�w���O;�M��");

	else if(strcmp(trim(result1),"NA")==0)

		strcpy(Payway,"���O������");

	else if(strcmp(trim(result1),"NR")==0)

		strcpy(Payway,"���������O");

	else if(strcmp(trim(result1),"NR")==0)

		strcpy(Payway,"���Ѥ�");

    strcpy(nbrand," ");
    $Select first 1 nbrand into $nbrand 
       From ca_car_model where ibrand = $Ibrand;
       
    sprintf_s(mkilo_ply, sizeof mkilo_ply,"%9.2f",mkilo_ply_tmp);
/*
printf("-- trace itel[%s]\n ",itel);
printf("-- trace mkilo_ply[%s]\n ",mkilo_ply);
printf("-- trace nowner[%s]\n ",nowner);
*/
   
	/**************���̪�O����*****************/
        
	strcpy(rptstr1001,Icard);
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,e_sIpolicy);

	/*** ���o�Q�O�I�H�m�W(���e) ***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,trim(Nassured));
        printf("rptstr1001[%s]\n", rptstr1001);
	/*** ���o�Q�O�I�HID number ***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,Iassured);
	/*** ���o�Q�O�I�H�ͤ� ***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,Ibirth);
	/***���o���O��(���O���A)***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,Payway);
	strcat(rptstr1001,",");
	strcat(rptstr1001,trim(ftype_sp));
	/*** ���o���ڤ� ***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,pay_date);
	/*** ���o����(���e) ***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,Aassured);
	/*** ���o�O�I�����_�l ***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,str1);
	/*** ���o�O�I�����פ� ***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,str2);
	/*** ���o���P���X(���e) ***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,Tag_num);
	/*** ���o����/�������X(���e) ***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,rtrim(Engine_num));
	/*** ���o��������(���e) ***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,Car_type);
	/*** ���o�t�P����(���e) ***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,Ibrand);
	/*** ���o��l�o�Ӧ~��(���e) ***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,Iissue_ym);
	/*** ���o�s�y�~��(���e)***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,Ipro_year);
	/*** ���o�Ʈ�q(���e) ***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,Qcylinder);

	/******** �O�I���B ****************************/
	$WHENEVER SQLERROR GOTO errexit;
	strcpy(provision," ");

	sprintf_s(stmt, sizeof stmt,"SELECT a.iins_type, a.minjured_cover, a.mdeath_cover,    "
				 " a.mdamage_cover, a.mdeduct,a.mins_premium,a.fedr_status,  "
				 " a.provision, a.qday, b.fdeduct, b.nins_type               "
			     " FROM %s:%s a, insurance_type b "
			     " WHERE a.iins_type = b.iins_type and (a.%s = ?)", sFullName, sply_ins_type, sipolicy );

	printf("%s\n",stmt);

	$PREPARE CUR9 FROM $stmt;
	$DECLARE curh1 CURSOR FOR CUR9;
	$OPEN curh1 USING $skey;
	i=0;
	for(;;)
	{
		$FETCH curh1 INTO $iins_type,$injured_cover,$death_cover,
			$damage_cover,$deduct,$ins_premium,$fedr_status,
			$provision,$qday,$fdeduct,$nins_type;
		if(SQLCODE == SQLNOTFOUND) break;
		sprintf_s(str_deduct, sizeof str_deduct,"%d",deduct);
		prn_deduct[0]=0;
        /*
                $SELECT fdeduct
                   INTO $fdeduct
                   FROM insurance_type
                  WHERE iins_type = $iins_type;
        */
		$SELECT prn_deduct
			INTO $prn_deduct
			FROM ca_dmg_mdeduct
			WHERE icar_type=$Car_type
			AND ideduct=$str_deduct;
		printf("Ipolicy[%s][%s][%f][%f][%f]\n",e_sIpolicy,iins_type,injured_cover,death_cover,damage_cover);
		if(fedr_status[0] == '1') /*** ���h ***/
			continue;

		if(fedr_status[0] == '2') /*** �j�h ***/
			continue;

		if(fedr_status[0] == '3') /*** �h���h�O ***/
			continue;

		if(fedr_status[0] == '5' &&
			injured_cover == 0 &&
			death_cover == 0 &&
			damage_cover == 0)     /*** ���P ***/
			continue;
			
		strcat(rptstr_dtl,e_sIpolicy);
		strcat(rptstr_dtl,"\t");
		/*** ���o�I�� ***/
		strcat(rptstr_dtl,iins_type);
		strcat(rptstr_dtl,"\t");
		strcat(rptstr_dtl,rtrim(nins_type));

		/***  ���o�O�I���B ***/
		strcat(rptstr_dtl,"\t");
		/* 1000225003 �D���ϴ��O�θ��v�O�I�s�ӫ~�t�λݨD*/
		printf("iins_type[%s]=",iins_type); 
		
		lIns_type = atoi(iins_type);
		switch ( lIns_type)
        {
			case 38: case 39: case 238: /*1100119001_SC2 �s�W-�s�ӫ~(238�I-�D���ϴ��O�Ϊ��[����)�������ˮ֤Ϊ���*/
			    if (lIns_type==238) 
				{
					if(injured_cover != 0)
					{						
						/* �p�ƤG��L���U��@��, ex. 0.30/0.60;30���� => 0.3/0.6;30����  */
						if(((long)injured_cover % 10000) > 0)
							rfmtdouble((injured_cover / 10000), "(#####&.#)", sbuf); 
						else
							rfmtdouble((injured_cover / 10000), "(#####&)", sbuf);
						strcat(rptstr_dtl,trim(sbuf));
					}	
					if(damage_cover != 0)
					{
						if(injured_cover != 0 || death_cover != 0)
							strcat(rptstr_dtl,"/");
						if(((long)damage_cover % 10000) > 0)
							rfmtdouble((damage_cover / 10000), "(#####&.#)", sbuf);
						else
							rfmtdouble((damage_cover / 10000), "(#####&)", sbuf);
						strcat(rptstr_dtl,trim(sbuf));
					}								
				}

			    printf("qday[%d]=",qday);
				if(qday != 0)
				{
					if (lIns_type==38 || lIns_type==39) {
					   strcat(rptstr_dtl,"��Q���{");
					}

                    /*1101229013_SC2 �s�W238�I�ؤ������{�O�v*/
					if (qday==899 || qday==999)  /* ex. 0.3/0.6�������� */
					{  
						strcat( rptstr_dtl, "��������");

					}else{                       /* ex. 0.3/0.6;30���� */
						strcat(rptstr_dtl,";");
						rfmtlong( qday, "(#####&)", sbuf);
						strcat(rptstr_dtl,trim(sbuf));
						strcat(rptstr_dtl,"����");
					}
				}
				break;
			
			default:
				if(injured_cover != 0)
			    {
					
				    if(((long)injured_cover % 10000) > 0)
					    rfmtdouble((injured_cover / 10000), "(#####&.##)", sbuf);
				    else
					    rfmtdouble((injured_cover / 10000), "(#####&)", sbuf);
				    strcat(rptstr_dtl,trim(sbuf));
			    }
				if(death_cover != 0)
				{
					if(injured_cover != 0)
						strcat(rptstr_dtl,"/");
					if(((long)death_cover % 10000) > 0)
						rfmtdouble((death_cover / 10000), "(#####&.##)", sbuf);
					else
						rfmtdouble((death_cover / 10000), "(#####&)", sbuf);
					strcat(rptstr_dtl,trim(sbuf));
				}
				if(damage_cover != 0)
				{
					if(injured_cover != 0 || death_cover != 0)
						strcat(rptstr_dtl,"/");

					if (lIns_type==160) /*1110216005_SC1 �t�X�N�ɫO�ӫ~�վ�CAR401�B�q�l�O���E�O���t��*/
					{
                        strcpy(sbuf, "�̦�ӤW���Ӹ��H�ƴ�@�H����");
					}else{
						if(((long)damage_cover % 10000) > 0)
							rfmtdouble((damage_cover / 10000), "(#####&.##)", sbuf);
						else
							rfmtdouble((damage_cover / 10000), "(#####&)", sbuf);
					}	
					strcat(rptstr_dtl,trim(sbuf));
				}
				if(atoi(iins_type) == 18)
				{
					strcat(rptstr_dtl,",�_��");
					strcat(rptstr_dtl,substring(str_deduct,1,2));
					strcat(rptstr_dtl,"%");
				}

				break;
        }

		/*** ���o�ۭt�B ***/
		strcat(rptstr_dtl,"\t");
        if( fdeduct[0] == '0')
		{
		    strcat(rptstr_dtl," ");
		}	
		else if(lIns_type == 11  || lIns_type == 211 || 
		        lIns_type == 176 || lIns_type == 177 || lIns_type == 178) /*1130510009_C02 �s�W�q�ʨ��M�ݰӫ~(0701�W�u)*/
		{
			if (strlen(trim(str_deduct))>0)
			{
				strcat(rptstr_dtl,trim(str_deduct));			
				strcat(rptstr_dtl,"%");
			}
			else
			{
				strcat(rptstr_dtl," ");
			}
		}
		else if(lIns_type == 18)
		{
			strcat(rptstr_dtl,substring(str_deduct,3,2));
			strcat(rptstr_dtl,"%");
		}
		else
			strcat(rptstr_dtl,trim(prn_deduct));
		/*** ���o�O�O ***/
		strcat(rptstr_dtl,"\t");
		strcat(rptstr_dtl,refmtamt(ins_premium,MILLIONTH));
		/*** �O�_���Ұ���O�� ***/
		strcat(rptstr_dtl,"\t");
		strcat(rptstr_dtl,provision);

	        strcat(rptstr_dtl,"\t");
                if( iedr == 0)
	            strcat(rptstr_dtl,"");
                else
	            strcat(rptstr_dtl,skey);

		strcat(rptstr_dtl,"\n");
	i++;
	}
	$CLOSE curh1;
	$FREE  curh1;

	/******** ���t�Τ�� ********/
	rtoday(&i_date);
        if( iedr != 0) /* ���H���鬰�C�L��� */
            i_date = ldendorse;
	rdatestr(i_date,str3_tmp);
    printf("str3_tmp[%s]\n",str3_tmp);
	strcpy(str3,cm_from_infdate_100(str3_tmp));
	printf("str3[%s]\n",str3);

	/*********** �}�l�C�L�O����ӽЮ� *****************/
	if (strlen(trim(e_sIpolicy)) > CAR_POLICY_LEN)
	{
		strcpy(ao_policy2_tmp,"-");
		strcat(ao_policy2_tmp,ao_policy2);
		strcpy(ao_policy2_tmp,trim(ao_policy2_tmp));
	}
		
	/*** ���o����Y�� ***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,Pdmg_acc);
	/*** ���o����t�� ***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,Plia_acc);
	/*** ���o�g��H�N�� ***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,Iofficer);
	/*��O*/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,Imgr);	
	/*** ���o�g��H�m�W ***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,Nname);
	/*** ���o�C�L��� ***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,str3);
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,Fcard_class);
	/*** ���o�n�O�H(���e) add by sylvia 99.12.24 ***/
	strcat(rptstr1001,"\t");
	strcat(rptstr1001,sNapplicant);
	strcat(rptstr1001,"\t");
        if( iedr == 0)
	    strcat(rptstr1001,"");
        else
	    strcat(rptstr1001,skey);
	
	strcat(rptstr1001,"\t");
    printf("begin car_spec_policy\n");
	strcpy( check_fedr, "");
	$SELECT first 1 check_fedr 
		INTO $check_fedr
		FROM car_spec_policy
		WHERE (inumber = $ipolicy or inumber = $Iassured or inumber = $Icard or inumber = $iapplicant)
		AND check_fedr[10] != '0';
    printf("end car_spec_policy\n");
	strcat(rptstr1001, trim(check_fedr));
	strcat(rptstr1001,"\t");
	
	strcpy(nbeneficiary," ");
	strcpy(relation_bene," ");
	strcpy(sNbeneficiary," ");
	strcpy(sRelation_bene," ");
	k = 0;
	sprintf_s(sStmt, sizeof sStmt,"SELECT DISTINCT nbeneficiary, "
	              "        CASE WHEN iins_type in ('33','56','136','166','266') THEN "
	              "             (CASE WHEN relation_bene = '1' THEN '���H' "
	              "                   WHEN relation_bene = '2' THEN '�a��' "
	              "                   WHEN relation_bene = '3' THEN '�O�Υ������H' "
	              "                   WHEN relation_bene = '4' THEN '�ŰȤH' "
	              "                   WHEN relation_bene = '5' THEN '�]���޲z�H' "
	              "                   WHEN relation_bene = '6' THEN '�k�w�~�ӤH' "
	              "                   WHEN relation_bene = '7' THEN '�t��' "
	              "                   WHEN relation_bene = '8' THEN '���t����' "
	              "              ELSE ' ' END) "
	              "         ELSE ' ' END relation_bene "
	              "   FROM %s:%s "
	              "  WHERE %s = ? "
	              "    AND trim(nbeneficiary) <> '' "
	              "    AND nbeneficiary IS NOT NULL; ", sFullName, sca_pa_ply, sipolicy);
    printf("sStmt[%s]=",sStmt); 
	$PREPARE CUR10 FROM $sStmt;
	$DECLARE cur_caPaPly CURSOR FOR CUR10;
	$OPEN cur_caPaPly USING $skey;
	
	for(;;)
	{
      $FETCH cur_caPaPly INTO $nbeneficiary, $relation_bene;
      
      if(SQLCODE == SQLNOTFOUND) break;

      k++;
      if (k == 1)
      {
          strcpy(sNbeneficiary, trim(nbeneficiary));
          strcpy(sRelation_bene, trim(relation_bene));
      }
      else
      {
          if (k > 2) break;
          strcat(sNbeneficiary, ",");
          strcat(sNbeneficiary, trim(nbeneficiary));
          strcat(sRelation_bene, ",");
          strcat(sRelation_bene, trim(relation_bene));
      }
	}
	$CLOSE cur_caPaPly;
	$FREE  cur_caPaPly;
	
	strcat(rptstr1001, trim(sNbeneficiary));
	strcat(rptstr1001,"\t");
	strcat(rptstr1001, trim(sRelation_bene));
	strcat(rptstr1001,"\t");
	strcat(rptstr1001, trim(feply));
	strcat(rptstr1001,"\t");
	strcat(rptstr1001, trim(iroute));
	strcat(rptstr1001,"\t");
	strcat(rptstr1001, trim(ileader));
	strcat(rptstr1001,"\t");
	strcat(rptstr1001, trim(nleader));
	strcat(rptstr1001,"\t");
	strcat(rptstr1001, trim(reissueNumber));

	strcat(rptstr1001,"\t");
	strcat(rptstr1001, trim(itel));
	strcat(rptstr1001,"\t");
	strcat(rptstr1001, trim(mkilo_ply));
	strcat(rptstr1001,"\t");
	strcat(rptstr1001, rtrim(nowner));
	strcat(rptstr1001,"\t");
	strcat(rptstr1001, rtrim(nbrand));

    strcat(rptstr1001,"\t");                  /*1120927002_C02 �R�q�ΰӫ~�}�o*/
	strcat(rptstr1001,sDinstall_ym);
    strcat(rptstr1001,"\t");
	strcat(rptstr1001,rtrim(sIsequence));
    strcat(rptstr1001,"\t");
	strcat(rptstr1001,sAinstall_zip);
    strcat(rptstr1001,"\t");
	strcat(rptstr1001,rtrim(sAinstall));

	strcat(rptstr1001,"\n");

	return M_CM_OK;
    
	errexit:
		printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
		return SQLCODE;
}

long car1001_build(reply)
serverReply reply;
{
  $char  FormFile[N_FILE+1], sFullName[20], stmt[5000];
  int    i;
  int    errCode;
  int    rc;
  char userid[10];

/*  memset(sFullName,0,20);
    memset(stmt,0,1024); */
  
  cm_buf_get("%s %s",Pipolicy,userid);

  $WHENEVER SQLERROR GOTO errexit;
  $SELECT kPgNum_Line, nForm_File, iForm_Tp
     INTO $PgLine, $FormFile, $FormTp
     FROM Form
    WHERE ksys_grp = "CA" AND kPgmID = 1005;

printf(" FormFile[%s]\n",FormFile);
  strcpy(FormFile,rtrim(FormFile));
  strcpy(outputf, getFileName());
  sprintf_s(OutFile, sizeof OutFile,"%s.tx",outputf);
  printf(" OutFile[%s]\n",OutFile);
  

  rgu_init_report(FormFile,OutFile);
  /***********   P R O C E S S   B E G I N   **********/
  miy = 0;
  max_count = 0;

  rc=car1001_data(reply);
  if (rc != SUCCESS)
        { return exitsub(reply,rc) ? rc : apiRC; }


  /***********   P R O C E S S   E N D   **********/

  rgu_finish_report();

  if (miy == 0)
     return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND : apiRC;
  else {
     max_count = miy;
     printf("max_count=%d\n",max_count);
     return api_OKComplete;
  }

errexit:
  printf("sqlcode[%ld] sqlerrm[%s]",SQLCODE,sqlca.sqlerrm);
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;

}
long car1001_data(reply)
serverReply reply;
{
  $char  stmt[1024];
  char   TpName[20];
  long   MsgCode;
  $char  Ffac[2];
  int    errCode;

   strcpy(sFullName,get_car_full_db(Pipolicy));
       
     sprintf_s(stmt, sizeof stmt,
             "SELECT iassured,iassured_ext,itag,iengine,aassured, nassured[1,20], iemail[1,22], itel   "
             "  FROM %s:policy  "
             " WHERE ipolicy = '%s'",sFullName,Pipolicy);
      $PREPARE i_10 FROM $stmt;
       $EXECUTE i_10 into $iassured,$iassured_ext,$itag,$iengine,$aperm, $nchi_full, $iemail, $tphone_con;
   
      $select imovephone, tphone_ext_con  
         into $imovephone, $tphone_ext_con   
         from cu_customer
        where ifpce_id = $iassured
         and ifpce_id_ext = $iassured_ext; 

if(SQLCODE == SQLNOTFOUND)
{  
    nchi_full[0]='\0';
    iemail[0]='\0';
    imovephone[0]='\0';
    tphone_con[0]='\0';
    tphone_ext_con[0]='\0';
}

printf("  stmt:[%s] \n",stmt);
printf("  nchi_full[%s]\n",nchi_full);
printf("  itag[%s]\n",itag);
printf("  iengine[%s]\n",iengine);
printf("  iemail[%s]\n",iemail);
printf("  tphone_con[%s]\n",tphone_con);
printf("  tphone_ext_con[%s]\n",tphone_ext_con);

               

      rgu_put_body(1);
      rgu_put_body(2);
      rgu_put_body(3);
      rgu_put_body_string(5,trim(nchi_full),1);
      rgu_put_body_string(5,trim(itag),1);
      rgu_put_body_string(5,trim(iengine),1);
      rgu_put_body_string(5,trim(tphone_ext_con),1);
      rgu_put_body_string(5,trim(tphone_con),1);
      rgu_put_body_string(5,trim(imovephone),1);
      rgu_put_body_string(5,trim(aperm),1);
      rgu_put_body_string(5,trim(iemail),1);
      rgu_put_body(5);
      rgu_put_body(6);
      miy = miy + 1;
      max_count = max_count + 1;
      
     

  return SUCCESS;

errexit:
  printf("car501_data_R:sqlcode[%ld] sqlerrm[%s]\n",SQLCODE,sqlca.sqlerrm);
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  return MsgCode;
}

