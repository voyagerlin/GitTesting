#include <stdio.h>
#include <stdlib.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"

char         localdb[5];
char         userid[7];

char         errmsg[200];
char         aphome[40];
char         outputf[80] , outputf1[80], file0[50];
char         DBName[5];
static  int  count_db;

$char          Today_c[13];
$char          Today_yy[5] , Today_mm[3] , Today_dd[3];
$static char   exec_date[YYYYMMDD];
$static char   exec_time[20];     /*** �����s�@�ɶ� ***/
$char          sApHome[31];
char errmsg[200];
FILE *errfpt;

$date          Today;
$long          bgndate_l , enddate_l , cal_date_l;
$char          bgndate_c[14] , enddate_c[14];
$char          cal_date_c[14];
$static char   remotedb[DBNAME];
$static char   bgndate[YYYYMMDD], enddate[YYYYMMDD];

$char          Siins_type[6];
$char          where_stat[50];
$char          filename[200];

$char     iclaim[20], ipolicy[20], stmt[1024];
char      prtstr[500];
$long     v_prem = 0, v_ori_prem;

DBinfo  *list;
FILE    *fptr, *fptr_err = NULL;
time_t  lt;

main(argc,argv)
int  argc;
char **argv;
{
    long  rc , res, rt;
    char  sel_choice[2];

    $WHENEVER sqlerror goto errexit;

    strcpy(DBName,"00");
    
    rt = getApHome(sApHome);
    if (rt < 0) {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
    }   
    
    sprintf_s(file0, sizeof file0,"%s","v_prem_302.txt");
   
    fptr=fopen(file0,"w");    
    
    rc = get_db();
    if (rc != SUCCESS)
       return rc;
    
    sprintf_s(stmt, sizeof stmt,"SELECT ipolicy, v_ori_prem FROM policy_302 \
                   WHERE dply_begin >= '06/01/2004'\
                     AND fcard_class = '2'");
    
    $PREPARE pre_stmt FROM $stmt;
    $DECLARE cura1 CURSOR for pre_stmt;
    $OPEN cura1;
    while(1)
    {
    	$FETCH cura1 INTO $ipolicy, $v_prem;
    	if(SQLCODE == SQLNOTFOUND) break;
    	printf("ipolicy[%s]\n", ipolicy );
    	
    	v_ori_prem = 0;
    	
    	$SELECT sum(ori_premium)
    	   INTO $v_ori_prem
    	   FROM ply_ins_type_302
    	  WHERE ipolicy = $ipolicy;
    	if(SQLCODE == SQLNOTFOUND) 
    	   v_ori_prem =0;
    	   
    	$UPDATE policy_302
    	    SET v_ori_prem = $v_ori_prem
    	  WHERE ipolicy = $ipolicy;
    	
        strcpy(prtstr, ipolicy);
        strcat(prtstr,"	");
        strcat(prtstr,itoa(v_prem));
        strcat(prtstr,"	");
        strcat(prtstr,itoa(v_ori_prem));
        
        fprintf(fptr, "%s\n", prtstr);
    	
    	
    }
    $CLOSE cura1;
    $FREE  cura1;
    
    fclose(fptr);
    
    exit(0);

errexit:
    printf("SOLCODE=%d sqlca.sqlerrm=%s\n",SQLCODE,sqlca.sqlerrm);
    printf(errmsg,"SOLCODE=%s sqlca.sqlerrm=%s",SQLCODE,sqlca.sqlerrm);
    fprintf(fptr_err,"%s\n",errmsg);
    exit(0);
}


long get_db()
{

   if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }
    
   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return SUCCESS;

errexit:
 /*  sqlfatal();  */
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}