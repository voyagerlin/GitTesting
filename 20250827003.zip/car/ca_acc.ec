/**************************************************************
 *                                                                 
 *    ca_acc.ec : return �ߴګY��                               
 *                                                             
 ******************************************************************/

#include <stdio.h>
#include <commsgs.h>
$include sqlca;
$include datetime;
#include "ISvar.h"
#include "safeclib.h"
#define DATENULL                0x80000000L

static int
DiffMonth (d1, d2)      /* input data should be date format */
 long d1, d2;
{
  short mdy1[3], mdy2[3];
  int datediff = 0;
  rjulmdy (d1, mdy1);
  rjulmdy (d2, mdy2);
  datediff = (mdy1[2] * 12 + mdy1[0]) - (mdy2[2] * 12 + mdy2[0]);
  if (datediff < 0)
    datediff = 0;
  return datediff;
}
/***********************************************
�ϥ� ca_accident_record
�n�ǤJ���
     char SendDB[] : ���}�Ҥ���Ʈw
     char inumber[] : �P�Ӹ�/������
     $date dply : �_�O��
     char fcard_class[] : �j��A���N�O
�n�ǥX���
     long qdmg[3] : ����e�T�~�ߴڦ��� } ��long[3] ���}�C
     long qlia[3] : ���d�e�T�~�ߴڦ��� }
     long mdmg[3] : ����e�T�~�ߴڪ��B }
     long mlia[3] : ���d�e�T�~�ߴڪ��B }
     long qdmg_acc : ����֭p�ߴڰO���I��
     long qlia_acc : ���d�֭p�ߴڰO���I��
     double pdmg_acc : ����֭p�ߴڰO���Y��
     double plia_acc : ���d�֭p�ߴڰO���Y��
     char   fyear[0]: �e�@�~�O������ɬO�_�����(Y/N)
     char   fyear[1]: �e�G�~�O������ɬO�_�����(Y/N)
     char   fyear[2]: �e�T�~�O������ɬO�_�����(Y/N)
     char   fcomp_class:�j���I�e�@�~�O�浥��

return code : M_CM_OK �����\
      other : error code        

�ϥνd�� : 
code=ca_accident_record(SendDB,inumber,rate_date,"1",
                        qdmg,qlia,mdmg,mlia,
                        &qdmg_acc,&qlia_acc,&pdmg_acc,&plia_acc,
                        fyear,fcomp_class,drate_ym);

************************************************/

long ca_accident_record(SendDB,inumber,dply,fcard_class,
                        qdmg,qlia,mdmg,mlia,
                        qdmg_acc,qlia_acc,pdmg_acc,plia_acc,fyear,fcomp_class,drate_ym)
char SendDB[];
$char inumber[];
$date dply;
$char fcard_class[];
$long qdmg[],qlia[];
$long mdmg[],mlia[];
$long *qdmg_acc,*qlia_acc;
$double *pdmg_acc,*plia_acc;
char   fyear[];
$char  fcomp_class[2];
$char  drate_ym[6];
{
     $char ipolicy[POLICY_NUM_1],first_ipolicy[POLICY_NUM_1];
     $date rate_date;
     $int  pre_year;
     $date dply_bgn,dply_end;
     int   end_year;
     $long dmg_year,lia_year;
     $long dmg_flag,lia_flag;
     $long dmg_num,lia_num;
     $long dmg_num_1,lia_num_1;

     $int  qdmg_stl_cnt,qlia_stl_cnt;
     $int  qdmg_app_cnt,qlia_app_cnt;
     $long mlia_stl,mdmg_stl;
     $long mlia_app,mdmg_app;
   $double Plia_acc,Pdmg_acc;

     char  dply_bgn_str[10], dply_str[10],dply_end_str[10];
     char  yy1[4], mm1[3], dd1[3],fcomp_flag;
     char  yy2[4], mm2[3], dd2[3];
     char  yy3[4], mm3[3], dd3[3];
     int   int_yy1, int_yy2,int_yy3;
     $long tmp_mdmg_stl = 0, tmp_mdmg_app = 0;
     $long tmp_mlia_stl = 0, tmp_mlia_app = 0;
     $int  tmp_fdmg = 0, tmp_flia = 0;

     $char dply_c[11],dply_bgn_c[11];
     $int  count;
     int   i, j, k, ply_cnt;

     printf("INTO ca_accident()\n");

     $WHENEVER SQLERROR GOTO errexit;
/*
     if (db_select (SendDB) == 0)
     {
         return M_CM_DB_NOTOPEN;
     }
*/
     for(i=0;i<3;i++)
     {
         qdmg[i]=0;
         mdmg[i]=0;
         qlia[i]=0;
         mlia[i]=0;
         fyear[i]='N';
     }

     *qdmg_acc=*qlia_acc=0;   /* �I�� */
     *pdmg_acc=*plia_acc=0.0; /* �Y�� */

     dmg_year=lia_year=dmg_num=lia_num=0;

     rate_date=cm_ymd_cdate("87/07/01");

     /***�j���I���@�~,���N�I���T�~*******/
     if (fcard_class[0]== '1')  /* dply=�_�O�� */
         end_year = 1;
     else
         end_year = 3;          /* for loop ����T�� */

     strcpy(inumber,trim(inumber));

     printf("fcard_class[%c],end_year[%d]\n",fcard_class[0],end_year);
     printf("inumber[%s]\n",inumber);
     printf("dply == [%ld]\n",dply);

     strcpy(dply_c,cm_cdate_str(dply));

     printf("dply_c == [%s]\n",dply_c);

     /*************�j���I���e�@�~���F�d�ߴڦ���*************/
     for (pre_year=0; pre_year < end_year ; pre_year++)
     {
          /***** I �ߴڦ��� *****/

          ply_cnt=0;

          $DECLARE ply_cur CURSOR FOR
            SELECT ipolicy, dply_bgn, dply_end
              FROM ca_ply_period
             WHERE inumber=$inumber
               AND fcard_class=$fcard_class
               AND YEAR(dply_bgn)=YEAR($dply)-($pre_year+1);

          $OPEN ply_cur;
          while(1)
          {
               $FETCH ply_cur INTO $ipolicy,$dply_bgn,$dply_end;
               if (SQLCODE==SQLNOTFOUND) break;
               if (dply_bgn==DATENULL) break;
               if (pre_year == 0)
                    strcpy(first_ipolicy,ipolicy);

               printf("### first_ipolicy[%s]\n",first_ipolicy);

               /* �H�e�O��_�O�� */
               qdmg_stl_cnt=qlia_stl_cnt=0;
               qdmg_app_cnt=qlia_app_cnt=0;
               mlia_stl=mdmg_stl=0;
               mlia_app=mdmg_app=0;

               strcpy(dply_bgn_str,cm_cdate_str(dply_bgn));
               cm_split_ymd(dply_bgn_str,yy1,mm1,dd1);
               int_yy1=atoi(yy1);

               printf("I-�H�e�O��_�O��-yy1[%s] mm1[%s] dd1[%s]\n",yy1,mm1,dd1);

               if (int_yy1<80) break;
               /* �����_�O�� */
               strcpy(dply_str,cm_cdate_str(dply));
               cm_split_ymd(dply_str,yy2,mm2,dd2);
               int_yy2=atoi(yy2);
               if (int_yy2<80) break;

               printf("I-�����_�O��-----yy2[%s] mm2[%s] dd2[%s]\n",yy2,mm2,dd2);

               /* �H�e�O�樴�O�� */
               strcpy(dply_end_str,cm_cdate_str(dply_end));
               cm_split_ymd(dply_end_str,yy3,mm3,dd3);
               int_yy3=atoi(yy3);

               printf("I-�H�e�O�樴�O��-yy3[%s] mm3[%s] dd3[%s]\n",yy3,mm3,dd3);

               if ((int_yy1 != int_yy2-(pre_year+1)) && (int_yy3==int_yy2) &&
                   (int_yy3-int_yy1!=3))
                   continue;

               ply_cnt++;

               printf("<<<<<<<<<<<<<<<>>>>>>>\n");
               printf("inumber == [%s]\n",inumber);
               printf("fcard_class == [%s]\n",fcard_class);
               printf("ipolicy == [%s]\n",ipolicy);
               printf("<<<<<<<<<>>>>>>>>>>>>>\n");

               $SELECT SUM(fdmg),SUM(mdmg_stl),SUM(flia),SUM(mlia_stl),COUNT(*)
                  INTO $qdmg_stl_cnt,$mdmg_stl,$qlia_stl_cnt,$mlia_stl,$count
                  FROM ca_accident
                 WHERE inumber     = $inumber
                   AND fcard_class = $fcard_class
                   AND ipolicy     = $ipolicy;

               printf("<<<<<>>>>>>\n");
               printf("qlia_stl_cnt == [%d]\n",qlia_stl_cnt);
               printf("qdmg_stl_cnt == [%d]\n",qdmg_stl_cnt);
               printf("<<<<<>>>>>>\n");

               if (count==0)
               {
                   qdmg_stl_cnt=0;
                   qlia_stl_cnt=0;
                   mdmg_stl=0;
                   mlia_stl=0;
               }

               /* �w�w��,���X�p��� */
               count=0; mdmg_app=0; qdmg_app_cnt=0;

               $DECLARE acc_cur2 CURSOR FOR
                 SELECT mdmg_stl,mdmg_app,fdmg
                   FROM ca_accident
                  WHERE inumber     = $inumber
                    AND fcard_class = $fcard_class
                    AND ipolicy     = $ipolicy;
               $OPEN acc_cur2;
               while (1)
               {
                   $FETCH acc_cur2 INTO $tmp_mdmg_stl,$tmp_mdmg_app,$tmp_fdmg;
                   if (SQLCODE == SQLNOTFOUND) break;
                   if (tmp_mdmg_stl != 0) continue;
                   count++;
                   mdmg_app+=tmp_mdmg_app;
                   qdmg_app_cnt+=tmp_fdmg;
               }
               $CLOSE acc_cur2;
               $FREE acc_cur2;
               if (count==0) { mdmg_app=0; qdmg_app_cnt=0; }

               count=0; mlia_app=0; qlia_app_cnt=0;
               $DECLARE acc_cur3 CURSOR FOR
                 SELECT mlia_stl, mlia_app, flia
                   FROM ca_accident
                  WHERE inumber     = $inumber
                    AND fcard_class = $fcard_class
                    AND ipolicy     = $ipolicy;
               $OPEN acc_cur3;
               while (1)
               {
                   $FETCH acc_cur3 INTO $tmp_mlia_stl,$tmp_mlia_app,$tmp_flia;
                   if (SQLCODE == SQLNOTFOUND) break;
                   if (tmp_mlia_stl != 0) continue;
                   count++;
                   mlia_app+=tmp_mlia_app;
                   qlia_app_cnt+=tmp_flia;
               }
               $CLOSE acc_cur3;
               $FREE acc_cur3;

               if (count==0) { mlia_app=0; qlia_app_cnt=0; }

               printf("##### qlia_stl_cnt == [%d]\n",qlia_stl_cnt);
               printf("##### qdmg_stl_cnt == [%d]\n",qdmg_stl_cnt);
               printf("##### qdmg[%ld] \n",qdmg[pre_year]);
                             
               /* �w���νߴ� �[�` */
               mdmg[pre_year]+=mdmg_stl+mdmg_app;
               mlia[pre_year]+=mlia_stl+mlia_app;

               qdmg[pre_year]+=qdmg_stl_cnt;
               qlia[pre_year]+=qlia_stl_cnt;

               printf("##### fyear[%c],qdmg[%ld] qlia[%ld] mdmg[%ld] mlia[%ld]\n",
                       fyear[pre_year], qdmg[pre_year],  qlia[pre_year],  mdmg[pre_year],  mlia[pre_year]);


          } /* end of while I */
          $CLOSE ply_cur;

          if (ply_cnt==0) continue;

          fyear[pre_year] = 'Y';

          printf("fyear[%d]=[%c]\n",pre_year,fyear[pre_year]);
          /***** II �L�ߴڦ~�� *****/

          if (qdmg[pre_year]==0) dmg_flag=1;
          else dmg_flag=0;

          if (qlia[pre_year]==0) lia_flag=1;
          else lia_flag=0;

          if (dmg_flag!=0 || lia_flag!=0)
          {
              $DECLARE acc_cur CURSOR FOR
                SELECT dply_bgn,dply_end
                  FROM ca_ply_period
                 WHERE inumber=$inumber
                   AND fcard_class=$fcard_class
                   AND YEAR(dply_bgn)=(YEAR($dply)-($pre_year+1));
              $OPEN acc_cur;
              while(1)  /* II */
              {
                   $FETCH acc_cur INTO $dply_bgn,$dply_end;
                   if (SQLCODE==SQLNOTFOUND)
                       break;

                   strcpy(dply_bgn_str,cm_cdate_str(dply_bgn));
                   cm_split_ymd(dply_bgn_str,yy1,mm1,dd1);
                   int_yy1=atoi(yy1);

                   printf("II�H�e�O��_�O��-yy1[%s] mm1[%s] dd1[%s]\n",yy1,mm1,dd1);

                   strcpy(dply_str,cm_cdate_str(dply));
                   cm_split_ymd(dply_str,yy2,mm2,dd2);
                   int_yy2=atoi(yy2);

                   printf("II�����_�O��-----yy2[%s] mm2[%s] dd2[%s]\n",yy2,mm2,dd2);

                   if (int_yy1 != int_yy2-(pre_year+1)) continue;

                   printf("int_yy1[%d],int_yy2[%d]\n",int_yy1,int_yy2);
                   printf("Diff dply_end[%ld],dply_bgn[%d]\n",dply_end,dply_bgn);

                   if ( DiffMonth (dply_end,dply_bgn) < 10 ||
                        DiffMonth(dply,dply_end) > (2+pre_year*12) )
                   {
                        lia_flag=0;
                        dmg_flag=0;
                        break;
                   }
                   printf("DIFFMonth,dply_end[%ld],dply_bgn[%ld]\n",dply_end,dply_bgn);
              }  /* end of while II */
              $CLOSE acc_cur;
          }

          /*---- �֥[�L�ߴڦ~�� ----*/
          dmg_year+=dmg_flag;
          lia_year+=lia_flag;

          /*---- �֥[�ߴڦ��� ----*/
          dmg_num+=qdmg[pre_year];
          lia_num+=qlia[pre_year];
          printf("before close ply_cur\n");
          $CLOSE ply_cur;
          $FREE  ply_cur;
     }  /* end for */

     if (fcard_class[0]=='2')
     {     /* ���N */
           /*---- �ߴڰO���I��=�ߴڦ����I��+�L�ߴڦ~���I�� ----*/
           lia_num_1 = dmg_num_1 = 0;

           if (dmg_num == 0)
              dmg_num_1 = 1 ;
           else
              dmg_num_1 = dmg_num;

           if (lia_num == 0)
              lia_num_1 = 1;
           else
              lia_num_1 = lia_num;

           *qdmg_acc=dmg_year * (-1) + (dmg_num_1 - 1)  ;
           *qlia_acc=lia_year * (-1) + (lia_num_1 - 1)  ;

           *pdmg_acc=*qdmg_acc*0.2;  /* ����Y�� */
           *plia_acc=*qlia_acc*0.2;  /* ���d�Y�� */

           /* �ثe�ߴڬ����̤j��-0.4 ,�Y���I�����s�F��,�������o���� */
           /*********************************************************/

           if (*qdmg_acc<-2) { *qdmg_acc=-2; *pdmg_acc=-0.4; }
           if (*qlia_acc<-2) { *qlia_acc=-2; *plia_acc=-0.4; }

     }
     else
     {     /* �j��ż�-- ���~�F�ƱN�h�~�żƥ[�W******/
           if (strlen(trim(fcomp_class)) > 0 )
           {
                printf("ca_acc---------fcomp_class--->[%s]\n",fcomp_class);

                *qlia_acc    = atoi(fcomp_class);
                *qlia_acc    = *qlia_acc + (3 * lia_num) - lia_year;

                if       (      *qlia_acc     >      19       )

                            *qlia_acc = 19;

                else if  (      *qlia_acc        <       1       )

                            *qlia_acc =  1;


                $SELECT pcomp_factor
                   INTO $*plia_acc
                   FROM ca_comp_acc_factor
                  WHERE qclass=$*qlia_acc
                    and fcard_class = '1'
                    and drate = (select drate
                                   from ca_rate_date
                                  where icode = $drate_ym
                                    and itable = 'ca_comp_acc_factor');
                if (SQLCODE==SQLNOTFOUND) *plia_acc=0;
                     *qdmg_acc=0; *pdmg_acc=0;
           }
     }     /* end of fcard_class='1' */

     for (i=0; i<3; i++)
     {
           printf("fyear[%c],qdmg[%ld] qlia[%ld] mdmg[%ld] mlia[%ld]\n",
                   fyear[i], qdmg[i],  qlia[i],  mdmg[i],  mlia[i]);
     }

     printf("END OF qacc����[%ld],���d[%ld]\n",*qdmg_acc,*qlia_acc);
     printf("END OF pacc����[%f],���d[%f]\n",*pdmg_acc,*plia_acc);
     printf("END OF �ߴڦ~ year[%ld][%ld]\n",dmg_year,lia_year);
     printf("END OF �ߴڦ���[%ld][%ld]\n",dmg_num,lia_num);

     return M_CM_OK;

errexit:
     printf("ca_accident_record:SQLCODE=%ld sqlerrm=%s\n",SQLCODE,sqlca.sqlerrm);
     return SQLCODE;
}


