/************************************************/
/*                                              */
/*   PROGRAM : ca646m01s.ec                     */
/*                                              */
/*   DATE:     2015/05/09                       */
/*                                              */
/************************************************/

#include <stdio.h>
#include <string.h>
#include <decimal.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"

$include sqlca;

int isalpha (int c);
int isascii (int c);

long MsgCode;

DBinfo  *list;
int  count_db, i;
static int max_cnt;

long car646(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car646_insert(),car646_single_query(),car646_multiple_query(),
      car646_update_exec(),car646_squery(),car646_query2();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'P':rtncode=car646_get_ipolicy(reply);
           break;          
  case 'A':
           rtncode=car646_insert(reply);
           break;
  case 'Q':
           rtncode=car646_single_query(reply);
           break;
  case 'q':
           rtncode=car646_single_query2(reply);
           break;         
  case 'M':
           rtncode=car646_multiple_query(reply);
           break;
  case 'm':
           rtncode=car646_multiple_query2(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car646_update_exec(reply,command,com_len);
           break;  
  default :
        return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
 }
 return(rtncode);
}

long car646_get_ipolicy(reply)
serverReply reply;
{
    $char DBName[5], sFullName[21], stmt[1024];
    int tmp_len;
    $char userid[11];
    $char ipre_rcv[22],ipolicy[21];
    $char dbegin[11],dend[11],iassured[11],nassured[41],itag[CA_TAG_NUM],iofficer[11],nofficer[11],ileader[11],nleader[11]; 
    cm_buf_get("%s %s ",DBName,ipre_rcv);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
        return M_CM_DB_NOTOPEN;
      else
        return apiRC; 
    }	

    sprintf_s(stmt, sizeof stmt,"SELECT first 1 a.ipolicy1,a.iassured,a.nassured,a.dbegin,a.dend,a.itag,  "
                   "      a.iofficer,(SELECT nname FROM officer WHERE iofficer = a.iofficer),a.ileader,(SELECT nname FROM officer WHERE iofficer = a.ileader) "
                   " FROM cm_pre_receive a  "
                   "WHERE a.ipre_rcv = '%s' ", ipre_rcv);                  
    printf("stmt[%s]\n", stmt); 
    
    $PREPARE prep2 FROM $stmt;
    $EXECUTE prep2 INTO $ipolicy,$iassured,$nassured,$dbegin,$dend,$itag,$iofficer,$nofficer,$ileader,$nleader;
    
    if(SQLCODE==SQLNOTFOUND)
 	{
 	 if(exitsub(reply,M_CM_NOT_FOUND) == True)       /*?*/
  	  return M_CM_NOT_FOUND;                        /*?*/
  	  else
    	return apiRC;
 	} 
      
    strcpy(dbegin, cm_from_infdate_100(dbegin));
    strcpy(dend, cm_from_infdate_100(dend));
   
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s ",
                M_CM_OK,ipolicy,iassured,nassured,dbegin,dend,itag,iofficer,nofficer,ileader,nleader);

    tmp_len = cm_buf_len(ReplyBuf); 
    
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long car646_insert(reply)
serverReply reply;
{
     $char DBName[5],DBName1[5];
     $char LsBuffer[1024], sFullName[20];
     $char sFullName_sys[20];
     $char c_ipre_rcv[21],c_userid[11];
     $char check[2];
     $int check_fins_grp;
     $int count_cr1,count_cr2,count_cp;
     int LiBufLen;
     count_cr1=0;
     count_cr2=0;
     count_cp=0;
     cm_buf_get("%s",DBName);

     cm_buf_get("%s %s ", c_ipre_rcv,c_userid);
     
     if (db_select(DBName) == False)
     return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
     
     $BEGIN WORK;
     $WHENEVER SQLERROR GOTO errexit;
     
     /*�Y��CP�� �h�g�b�ݬ�CAR140-SV�]�w���g�� OR ����*/
     $SELECT count(*)
        INTO $count_cp
        FROM car_code a,cm_pre_receive b 
       WHERE b.ipre_rcv = $c_ipre_rcv
         AND (a.kind = 'SV' OR b.iroute like 'JB%')
         AND a.detail2 = b.iofficer;
     /*���ŦX2�B3�B4��*/
     $SELECT count(*) 
        INTO $count_cr1
        FROM cm_pre_receive a, policy_302 b
       WHERE a.ipre_rcv = b.iestimate_ori
         AND b.frenew_type in ('2','3','4')
         AND a.ipre_rcv = $c_ipre_rcv;
         
     $SELECT count(*)
       INTO $count_cr2
       FROM cm_pre_receive a, policy_302 b
      WHERE a.ipre_rcv = b.iestimate_sug
        AND b.frenew_type in ('2','3','4')
        AND a.ipre_rcv = $c_ipre_rcv;

printf("---------connt_cp[%d]\n",count_cp);     
printf("---------connt_cr[%d]\n",count_cr1);
printf("---------connt_cr[%d]\n",count_cr2);

     if(count_cr1 > 0 || count_cr2 > 0 ||count_cp > 0){           
     sprintf_s(LsBuffer, sizeof LsBuffer,"INSERT INTO ca_out_control  "
            "(ipre_rcv,icreate,dcreate,iupdate,dupdate)  "
      "VALUES (?,?,current,?,current)");
  
     $PREPARE a_id FROM $LsBuffer;
     $EXECUTE a_id USING $c_ipre_rcv,$c_userid,$c_userid;
  
     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     LiBufLen = cm_buf_len(ReplyBuf);   

     if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
     {
       $WHENEVER SQLERROR CONTINUE;
       $ROLLBACK WORK;
       return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     $COMMIT WORK;
     return api_OKComplete;    
     }
     
     else{
     /*M_CM_ADD_FAIL*/
     SQLCODE = 3551;
     goto errexit;
     }
     
     errexit:
         printf(" sqlerrm = %s\n",sqlca.sqlerrm);
         $WHENEVER SQLERROR CONTINUE;
         MsgCode = SQLCODE;
         $ROLLBACK WORK;
         if (SQLCODE != 0) MsgCode = SQLCODE;
         return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

long car646_single_query(reply)
serverReply reply;
{
 $char DBName[5], sFullName[21], stmt[1024];
 $char m_ipre_rcv[21];

 $char q_ipre_rcv[21],q_iassured[11],q_nassured[41],q_itag[CA_TAG_NUM],q_dbegin[11],q_dend[11],q_iofficer[11],q_nofficer[11],q_ileader[11],q_nleader[11],q_ientry[11];
 int tmp_len;
 
 cm_buf_get("%s %s ",DBName,m_ipre_rcv);
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
     
    sprintf_s(stmt, sizeof stmt,"SELECT first 1 a.ipre_rcv,a.iassured,a.nassured,a.dbegin,a.dend,a.itag,  "
                   "      a.iofficer,(SELECT nname FROM officer WHERE iofficer = a.iofficer),a.ileader,(SELECT nname FROM officer WHERE iofficer = a.ileader) "
                   " FROM cm_pre_receive a  "
                   "WHERE a.ipre_rcv = '%s' ", m_ipre_rcv);                  
    printf("stmt[%s]\n", stmt); 
    
    $PREPARE prep2 FROM $stmt;
    $EXECUTE prep2 INTO $q_ipre_rcv,$q_iassured,$q_nassured,$q_dbegin,$q_dend,$q_itag,$q_iofficer,$q_nofficer,$q_ileader,$q_nleader;
    
    strcpy(q_dbegin, cm_from_infdate_100(q_dbegin));
    strcpy(q_dend, cm_from_infdate_100(q_dend));
         
 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CM_NOT_FOUND) == True)       /*?*/
    return M_CM_NOT_FOUND;                        /*?*/
  else
    return apiRC;
 } 
 
 cm_buf_init(ReplyBuf);
 
 cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s",
             M_CM_OK, q_ipre_rcv,q_iassured,q_nassured,q_dbegin,q_dend,q_itag,q_iofficer,q_nofficer,q_ileader,q_nleader);
 
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

 errexit:
   MsgCode = cm_show_sql_err("ca646_single_query", NULL);
  if(exitsub(reply,MsgCode) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car646_single_query2(reply)
serverReply reply;
{
 $char DBName[5], sFullName[21], stmt[1024];
 $char m_ipre_rcv[21];
 $char q_ipre_rcv[21],q_iassured[11],q_nassured[41],q_itag[CA_TAG_NUM],q_dbegin[11],q_dend[11],q_iofficer[11],q_nofficer[11],q_ileader[11],q_nleader[11],q_ientry[11];
 $char q_icreate[11],q_dcreate[21],q_iupdate[11],q_dupdate[21];
 int tmp_len;
 
 cm_buf_get("%s %s ",DBName,m_ipre_rcv);
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
     
    sprintf_s(stmt, sizeof stmt,"SELECT first 1 a.ipre_rcv,a.iassured,a.nassured,a.dbegin,a.dend,a.itag,  "
                   "      a.iofficer,(SELECT nname FROM officer WHERE iofficer = a.iofficer),a.ileader,(SELECT nname FROM officer WHERE iofficer = a.ileader), "
                   " 	 b.icreate,b.dcreate,b.iupdate,b.dupdate  "
                   " FROM cm_pre_receive a , ca_out_control b  "
                   "WHERE a.ipre_rcv = b.ipre_rcv  "
                   "  AND b.ipre_rcv = '%s' ", m_ipre_rcv);                  
    printf("stmt[%s]\n", stmt); 
    
    $PREPARE prep2 FROM $stmt;
    $EXECUTE prep2 INTO $q_ipre_rcv,$q_iassured,$q_nassured,$q_dbegin,$q_dend,$q_itag,$q_iofficer,$q_nofficer,$q_ileader,$q_nleader,$q_icreate,$q_dcreate,$q_iupdate,$q_dupdate;
         
 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CM_NOT_FOUND) == True)       /*?*/
    return M_CM_NOT_FOUND;                        /*?*/
  else
    return apiRC;
 } 
 
    strcpy(q_dbegin, cm_from_infdate_100(q_dbegin));
    strcpy(q_dend, cm_from_infdate_100(q_dend));
 cm_buf_init(ReplyBuf);
 
 cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s ",
             M_CM_OK, q_ipre_rcv,q_iassured,q_nassured,q_dbegin,q_dend,q_itag,q_iofficer,q_nofficer,q_ileader,q_nleader,q_icreate,q_dcreate,q_iupdate,q_dupdate);
 
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

 errexit:
   MsgCode = cm_show_sql_err("ca646_single_query2", NULL);
  if(exitsub(reply,MsgCode) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car646_multiple_query(reply)
serverReply reply;
{
 $char DBName[5], sFullName[21], stmt[2048] , stmt2[1024],stmp1[256];
 
 $char c_ipre_rcv[21],c_iassured[11],c_itag[CA_TAG_NUM],c_iofficer[11],c_ileader[11],c_ientry[11],c_dply_begin[10],c_dply_begin2[10];
 $char ipre_rcv[21],iassured[11],nassured[41],itag[CA_TAG_NUM],dbegin[11],dend[11],iofficer[11],ileader[11],ientry[11],out_yn[2],iins_kind[2];
 
 /* $char sFullName_sys[20];  */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0,k;
 int OPEN_STAR;
 cm_buf_get("%s %s %s %s %s %s %s %s",DBName,c_ipre_rcv,c_itag,c_iassured,c_iofficer,c_ileader,c_dply_begin,c_dply_begin2);
 
 if(strcmp(c_dply_begin,"*")==0&&strcmp(c_dply_begin2,"*")==0)
 {
   strcpy(stmp1," ");	
 }
 else
 {
  printf("c_dply_begin[%s],c_dply_begin2[%s]\n",c_dply_begin,c_dply_begin2);
  strcpy(c_dply_begin,cm_to_infdate(c_dply_begin));
  strcpy(c_dply_begin2,cm_to_infdate(c_dply_begin2));
  printf("c_dply_begin[%s],c_dply_begin2[%s]\n",c_dply_begin,c_dply_begin2);
  sprintf_s(stmp1, sizeof stmp1,"AND b.dply_begin >= '%s' AND b.dply_begin < '%s'",c_dply_begin,c_dply_begin2);
 }
 $WHENEVER SQLERROR GOTO errexit;
 
 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 
 }
 
 sprintf_s(stmt, sizeof stmt,"SELECT unique a.ipre_rcv,a.iassured,a.nassured,a.itag,a.dbegin,a.dend,a.iofficer,a.ileader,  "
                "      CASE WHEN (SELECT count(*) FROM ca_out_control c WHERE c.ipre_rcv=a.ipre_rcv) >0 THEN 'N' ELSE 'Y' END   "
                " FROM cm_pre_receive a,policy_302 b  "
                "WHERE a.ipre_rcv = b.iestimate_ori  "
                "  AND a.ipre_rcv[6,7] ='CR'  "
                "  AND a.ipre_rcv matches '%s'  "
                "  AND a.itag matches '%s'  "
                "  AND a.iassured matches '%s'  "
                "  AND a.ipolicy1 = ''  "
                "  AND a.ipolicy2 = ''  "
                "  AND a.iofficer matches '%s'  "
                "  AND a.ileader matches '%s'   "
                "  AND b.frenew_type in ('2','3','4')  "
                "  AND a.iins_cat = 'C'  "
                "  AND a.ipre_end = ''  "
                "  AND a.deffect = b.dply_begin %s union ", c_ipre_rcv,c_itag,c_iassured,c_iofficer,c_ileader,stmp1);
 sprintf_s(stmt2, sizeof stmt2,"SELECT unique a.ipre_rcv,a.iassured,a.nassured,a.itag,a.dbegin,a.dend,a.iofficer,a.ileader,  "
                "      case WHEN (SELECT count(*) FROM ca_out_control c WHERE c.ipre_rcv=a.ipre_rcv) >0 THEN 'N' ELSE 'Y' END  "
                " FROM cm_pre_receive a,policy_302 b  "
                "WHERE a.ipre_rcv = b.iestimate_sug  "
                "  AND a.ipre_rcv[6,7] ='CR'  "
                "  AND a.ipre_rcv matches '%s'  "
                "  AND a.itag matches '%s'  "
                "  AND a.iassured matches '%s'  "
                "  AND a.ipolicy1 = ''  "
                "  AND a.ipolicy2 = ''  "
                "  AND a.iofficer matches '%s'  "
                "  AND a.ileader matches '%s'  "
                "  AND b.frenew_type in ('2','3','4')  "
                "  AND a.iins_cat = 'C'  "
                "  AND a.ipre_end = ''  "
                "  AND a.deffect = b.dply_begin %s ;", c_ipre_rcv,c_itag,c_iassured,c_iofficer,c_ileader,stmp1);
       strcat(stmt,stmt2);
        printf("stmt[%s]\n",stmt);

        $PREPARE cur_3 FROM $stmt;
        $DECLARE q_cur3 CURSOR FOR cur_3; 
       
    $OPEN q_cur3;
 
 for(;;)
  {
    $FETCH q_cur3 INTO $ipre_rcv,$iassured,$nassured,$itag,$dbegin,$dend,$iofficer,$ileader,$out_yn,$iins_kind;
   
    if (SQLCODE != 0) break;
    
    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }

    cm_buf_put("%s %s %s %s %s %s %s %s %s %s",
              ipre_rcv,iassured,nassured,itag,dbegin,dend,iofficer,ileader,out_yn,iins_kind);

    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
       	$CLOSE q_cur3;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;

        if(replycnt > 5) sleep(3);
        else if(replycnt > 3) sleep(2);
        else if(replycnt > 1) sleep(1);

        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();

        cm_buf_put("%s %s %s %s %s %s %s %s %s %s",
              ipre_rcv,iassured,nassured,itag,dbegin,dend,iofficer,ileader,out_yn,iins_kind);
              
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
   /* for loop */
  }


 $CLOSE q_cur3;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

 errexit:
   MsgCode = cm_show_sql_err("ca646_multiple_query", NULL);
   if(exitsub(reply,MsgCode) == True)
     return SQLCODE;
   else
     return apiRC;
}

long car646_multiple_query2(reply)
serverReply reply;
{
 $char DBName[5], sFullName[21], stmt[1024] , stmt2[1024],stmp1[256];
 
 $char c_ipre_rcv[21],c_ileader[11],c_dply_begin[10],c_dply_begin2[10];
 $char ipre_rcv[21],ileader[11],dply_begin[11];
 
 /* $char sFullName_sys[20];  */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0,k;
 int OPEN_STAR;
 cm_buf_get("%s %s %s %s %s",DBName,c_ipre_rcv,c_ileader,c_dply_begin,c_dply_begin2);
 
 if(strcmp(c_dply_begin,"*")==0&&strcmp(c_dply_begin2,"*")==0)
 {
   strcpy(stmp1," ");	
 }
 else
 {
  printf("c_dply_begin[%s],c_dply_begin2[%s]\n",c_dply_begin,c_dply_begin2);
  strcpy(c_dply_begin,cm_to_infdate(c_dply_begin));
  strcpy(c_dply_begin2,cm_to_infdate(c_dply_begin2));
  printf("c_dply_begin[%s],c_dply_begin2[%s]\n",c_dply_begin,c_dply_begin2);
  sprintf_s(stmp1, sizeof stmp1,"AND b.dply_begin >= '%s' AND b.dply_begin < '%s'",c_dply_begin,c_dply_begin2);
 }
 $WHENEVER SQLERROR GOTO errexit;
 
 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 
 }
 
 sprintf_s(stmt, sizeof stmt,"SELECT unique a.ipre_rcv,a.ileader,b.dply_begin  "
                " FROM cm_pre_receive a,policy_302 b ,ca_out_control c "
                "WHERE a.ipre_rcv = b.iestimate_ori  "
                "  AND a.ipre_rcv = c.ipre_rcv  "
                "  AND c.ipre_rcv matches '%s'  "
                "  AND a.ileader matches '%s'   "
                "  AND b.frenew_type in ('2','3','4') %s union ", c_ipre_rcv,c_ileader,stmp1);
 sprintf_s(stmt2, sizeof stmt2,"SELECT unique a.ipre_rcv,a.ileader,b.dply_begin  "
                " FROM cm_pre_receive a,policy_302 b ,ca_out_control c "
                "WHERE a.ipre_rcv = b.iestimate_sug  "
                "  AND a.ipre_rcv = c.ipre_rcv  "
                "  AND c.ipre_rcv matches '%s'  "
                "  AND a.ileader matches '%s'   "
                "  AND b.frenew_type in ('2','3','4') %s ;", c_ipre_rcv,c_ileader,stmp1);
       strcat(stmt,stmt2);
        printf("stmt[%s]\n",stmt);

        $PREPARE cur_5 FROM $stmt;
        $DECLARE q_cur5 CURSOR FOR cur_5; 
       
    $OPEN q_cur5;
 
 for(;;)
  {
    $FETCH q_cur5 INTO $ipre_rcv,$ileader,$dply_begin;
   
    if (SQLCODE != 0) break;
    
    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }

    cm_buf_put("%s %s %s ",
              ipre_rcv,ileader,dply_begin);

    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
       	$CLOSE q_cur5;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;

        if(replycnt > 5) sleep(3);
        else if(replycnt > 3) sleep(2);
        else if(replycnt > 1) sleep(1);

        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();

        cm_buf_put("%s %s %s ",
              ipre_rcv,ileader,dply_begin);
              
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
   /* for loop */
  }


 $CLOSE q_cur5;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

 errexit:
   MsgCode = cm_show_sql_err("ca646_multiple_query2", NULL);
   if(exitsub(reply,MsgCode) == True)
     return SQLCODE;
   else
     return apiRC;
}

long car646_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
        
 $char DBName[5] , sFullName[21], stmt[1024],userid[11];
 $char cur_ipre_rcv[21];
 $char cur_iupdate[11],cur_dupdate[21],cur_icreate[11],cur_dcreate[21];
 $char cur_iassured[11],cur_nassured[41],cur_itag[CA_TAG_NUM],cur_dbegin[11],cur_dend[11],cur_iofficer[11],cur_nofficer[11],cur_ileader[11],cur_nleader[11],cur_ientry[11];
 $char u_ipre_rcv[21];
 $char q_ipre_rcv[21];
 $char u_iupdate[11],u_dupdate[21],u_icreate[11],u_dcreate[21]; 
 $char q_iupdate[11],q_dupdate[21],q_icreate[11],q_dcreate[21];
 
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len; long dummy;
   DBinfo *list;
   int i, j, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[300],stmt_buf2[300];

 comm = (char *) command;
 cm_buf_init(command);

 cm_buf_get("%c %s %s",&option,DBName,userid);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
     return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

/*  if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
     return exitsub(reply,M_CM_NOT_DBLIST) ? M_CM_NOT_DBLIST : apiRC;  */

 memcpy(&raw_len,&comm[com_len],sizeof(int));
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)
  memcpy(raw_ptr,pos,raw_len);
 else
  { 
   return exitsub(reply,M_CM_NOT_MALLOC) ? M_CM_NOT_MALLOC : apiRC;
  }

 cm_buf_init(raw_ptr);          /* get index key from old record */
 cm_buf_get("%l %s",
             &dummy,q_ipre_rcv);
   printf("-------------q_ipre_rcv[%s]  userid[%s]\n", q_ipre_rcv,userid);           
 $BEGIN WORK;

    sprintf_s(stmt, sizeof stmt,"SELECT first 1 a.ipre_rcv,a.iassured,a.nassured,a.dbegin,a.dend,a.itag,  "
                   "      a.iofficer,(SELECT nname FROM officer WHERE iofficer = a.iofficer),a.ileader,(SELECT nname FROM officer WHERE iofficer = a.ileader), "
                   " 	 b.icreate,b.dcreate,b.iupdate,b.dupdate  "
                   " FROM cm_pre_receive a, ca_out_control b "
                   "WHERE a.ipre_rcv = b.ipre_rcv  "
                   "  AND b.ipre_rcv = '%s' ",  q_ipre_rcv);                  
    printf("stmt[%s]\n", stmt); 
    
    $PREPARE prep2 FROM $stmt;
    $EXECUTE prep2 INTO $cur_ipre_rcv,$cur_iassured,$cur_nassured,$cur_dbegin,$cur_dend,$cur_itag,$cur_iofficer,$cur_nofficer,$cur_ileader,$cur_nleader,$cur_icreate,$cur_dcreate,$cur_iupdate,$cur_dupdate;   
    strcpy(cur_dbegin, cm_from_infdate_100(cur_dbegin));
    strcpy(cur_dend, cm_from_infdate_100(cur_dend));
  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */

 if (SQLCODE == SQLNOTFOUND)
 {
   MsgCode = M_CM_NOT_FOUND;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
 }

 cm_buf_init(cur_buf);

 cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s ",
             dummy,cur_ipre_rcv,cur_iassured,cur_nassured,cur_dbegin,cur_dend,cur_itag,cur_iofficer,cur_nofficer,cur_ileader,cur_nleader,cur_iupdate,cur_dupdate,cur_icreate,cur_dcreate);            

 write(1,cur_buf,raw_len);
 write(1,"\n",1);
 write(1,raw_ptr,raw_len);
 write(1,"\n",1);

 printf("cur_buf[%s]\n",cur_buf);
 printf("raw_ptr[%s]\n",raw_ptr);
 
 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
 {
   MsgCode = M_CM_NOT_EQUAL;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
 }

 /* equal, then exec DB operation */

 if ( option == 'D' )
  {

    sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM ca_out_control WHERE ipre_rcv= ?");
    $PREPARE d_id FROM $stmt_buf;

    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      
     }
    $EXECUTE d_id USING $cur_ipre_rcv;

    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      
     }
    sprintf_s(stmt_buf2, sizeof stmt_buf2,"INSERT INTO ca_out_control_log values(?,?,current)");
    $PREPARE d_id2 FROM $stmt_buf2;
    $EXECUTE d_id2 USING $cur_ipre_rcv,$userid;

   if( is_del_fail ) goto errexit;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
   else if (option == 'U')
  {
   cm_buf_init(command);

   cm_buf_get("%c %s %s %s",
               &option,DBName,u_ipre_rcv,userid);
   
   printf("u_ipre_rcv[%s]\n",u_ipre_rcv);

   /* grasp old key */
   cm_buf_init(raw_ptr);
   free(raw_ptr);
   cm_buf_get("%l %s ",&dummy,q_ipre_rcv);
   
   $WHENEVER SQLERROR CONTINUE;
    
    sprintf_s(stmt_buf, sizeof stmt_buf,
                "UPDATE ca_out_control  "
                "   SET (ipre_rcv,iupdate,dupdate) "
                "     = (?,?,current )  "
                " WHERE ipre_rcv = ?");

    $PREPARE u_id FROM $stmt_buf;
    
    printf(" stmt_buf[%s] \n",stmt_buf);
    
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
     
     }
    
    $EXECUTE u_id USING $u_ipre_rcv,$userid;
    printf(" sqlca.sqlerrd[2]=[%d] \n",sqlca.sqlerrd[2]);

    if(SQLCODE != 0)
     {
      is_upd_fail = 1;    
     }

     if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {  
        sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO ca_out_control  "
        "(ipre_rcv,iupdate,dupdate,icreate,dcreate) "
        " VALUES (?,?,current,?,current)");

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        
       }
      $EXECUTE ua_id USING $u_ipre_rcv,$userid,$userid;

      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        
       }
     }
 
   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }
   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   MsgCode = M_CM_WRONG_OPTION;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
  }

errexit:
  MsgCode = SQLCODE;
  cm_show_sql_err("ca544_update_exec", stmt_buf);
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if(SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True)
   return MsgCode;
  else
   return apiRC;
}