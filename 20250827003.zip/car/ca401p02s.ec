/**********************************************************************/
/*   program id   : ca401p02s.ec                                      */
/*   program name : �O�I�����v�Q����q���ѩe�~�t�ӱH�e                */
/*   date written : 2017/10/26                                        */
/**********************************************************************/

#include <stdio.h>
#include <time.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"
$include "var_length.h";
$include sqltypes;
#include "globdata.h"
$include "safeclib.h";

$char	DBName[5], userid[11], sdate1[11];
DBinfo  *list;
char  	outputf[ N_FILE+1],sApHome[30],msgbuf[100],pathname[31],
        filename[50];
int     i,count_db;
FILE     *fp;

/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;
    $char cdate1[11];
      
    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(sdate1,  isNULLstr(argv[3])); /* mm/dd/yyyy 10/27/2017 */
    strcpy(outputf, isNULLstr(argv[4]));
    printf("DBName=[%s]\n",DBName);
    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
       return M_CM_DB_NOTOPEN;
    }
    
    rc = car401_get_db();
    if (rc != M_CM_OK) {
        printf("error on car401_get_db\n");
        return rc;
    }
    
    if( sdate1[0] == ' ' || sdate1[0] == '\0') /* �L��J����H�t�Τ鬰���� */
        $select first 1 today into $sdate1 from systables;

    printf("sdate1=[%s]\n",sdate1);

    $select first 1 year($sdate1)-1911||to_char(date($sdate1),'%m%d')    /* mm/dd/yyyy --> CYYMMDD */
       into $cdate1
       from systables;

    strcpy(cdate1, trim(cdate1));
    
    rc = getApHome(sApHome);
    sprintf_s(pathname, sizeof pathname,"%s/rptftp/car_out/",sApHome);
    sprintf_s(filename, sizeof filename,"%s%s_transfer.txt",pathname,cdate1); /* �ɮצW�١GCYYMMDD_transfer.txt */ 
    printf("filename[%s]\n",filename);

    /*----------------*/
    rc = car401_ply_data();
    if (rc != M_CM_OK) {
        printf("error on car401_ply_data\n");
        EWRITE(userid, rc, "�^����Ʀ��~!");
        return rc;
    }
    EWRITE(userid, rc, "���槹�� ");

    fclose(fp);
    printf("[car401]:process ok!\n"); 
}
/*----------------------------------------------------------------------------*/
long car401_get_db()
{
    int	rc;

    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }
    
    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
    }

    return M_CM_OK;
}
/*----------------------------------------------------------------------------*/
long car401_ply_data()
{
    int	rc, count,m;
    $char   stmt[4096],stmt1[100],stmt2[100];
    long    rtncode;

    $char   icard[21], iendorse[21], ipolicy[21], napplicant[121], itag[CA_TAG_NUM], edr_type[2], nbranch[51];
    $char   nleader[21], branch_tel[61], ext_tel[61], apayment_zip[8], apayment[101];
    $char   tmp_policy[101], tmp_ipolicy_begin_end[501],ipolicy_c[21] , dbname_c[7], iassured_v[13];
    $int    tmpCount;
    
    $whenever sqlerror goto errexit;
    for(i=0;i<count_db;i++)
    {  	 
        if( i == 0) 
        {    strcpy( stmt1, " ");
             strcpy( stmt2, " into temp xyz ");
        }
        else
        {    strcpy( stmt1, " insert into xyz ");
             strcpy( stmt2, " ");
        }

        sprintf_s(stmt, sizeof stmt,
              " %s SELECT a.icard , max(a.iendorse) as iendorse , c.ipolicy, d.dply_begin, d.dply_end, c.napplicant, \n"
              " 	nvl(c.itag,' ') as itag, CASE WHEN a.fedr_class IN ('2','8') THEN '1' ELSE '2' END edr_type,  \n"
              " 	(select nbranch from sa_branch_type where ibranch = trim(a.iquota[1,4]) || '00') as nbranch, \n"
              "     (select nname from officer where iofficer = e.ileader) AS nleader,nvl(f.branch_tel,' ') as branch_tel ,nvl(f.ext_tel, ' ') as ext_tel, \n"
              " 	 c.apayment_zip , c.apayment, a.ipolicy as ipolicy_c, 'newa'||a.icomp_in as dbname_c, c.iassured AS iassured_v \n"
              " FROM %s:edr_relation a, %s:endorsement b, %s:policy c, %s:ply_relation d, officer e, OUTER cm_emp_ext f \n"
              " WHERE a.iendorse = b.iendorse AND a.iendorse NOT LIKE '%%CVP%%' \n"
              " AND b.iengine = c.iengine \n"
              " AND c.ipolicy = d.ipolicy \n"
              " AND nvl(b.iengine,'') <> '' \n"
              " AND a.fcard_class = '1' \n"
              " AND d.fcard_class = '2' \n"
              " AND (a.fedr_class IN ('2','8') OR EXISTS (SELECT 1 FROM %s:edr_ins_type g WHERE a.iendorse = g.iendorse AND g.iedr_type = '02')) \n"
              " AND a.dendorse between date('%s')-10 and date('%s')-4 \n"
              " AND a.dedr_close IS NOT NULL \n"
              " AND a.terminate_rsn <> '4' \n"
              " AND d.dply_close IS NOT NULL \n"
              " AND d.iofficer = e.iofficer \n"
              " AND e.ileader = f.empl_no \n"
              " AND d.ipolicy not matches '*VW*' \n"
              " AND e.fprop <> 'E' \n"
              " AND d.dply_end >today+15 \n"
              " AND NOT EXISTS(SELECT 1 FROM %s:edr_relation h WHERE d.ipolicy = h.ipolicy AND h.fedr_class IN ('2','8') AND h.iendorse NOT LIKE '%%CVP%%') \n"
              " AND NOT EXISTS(SELECT 1 FROM %s:ply_ins_type i WHERE d.ipolicy = i.ipolicy AND i.mdamage_cover = 0) \n"
              " AND NOT EXISTS(SELECT 1 FROM %s:appraisal j WHERE d.ipolicy = j.ipolicy AND j.fpart IN ('1','2','3')) \n"
              " AND nvl(c.apayment,'') <>'' \n"
			  "	AND ( \n"
			  "	      ( a.fedr_class IN ('2','8') AND (NOT EXISTS(SELECT 1 FROM %s:policy p WHERE a.ipolicy = p.ipolicy AND p.iassured = c.iassured)) ) \n"
			  "     OR \n"
			  "	      ( EXISTS(SELECT 1 FROM %s:edr_ins_type g WHERE a.iendorse = g.iendorse AND g.iedr_type = '02') AND \n"
			  "	        EXISTS(SELECT 1 FROM %s:policy q       WHERE a.ipolicy  = q.ipolicy  AND q.iassured  = c.iassured) ) \n"
			  "	    ) \n"
			  " GROUP BY 1,3,4,5,6,7,8,9,10,11,12,13,14,15,16,17 \n "
			  " %s ",
               stmt1, list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,
               list[i].dbname, sdate1, sdate1, list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname,stmt2);
 
        printf("stmt[%s]\n", stmt);

		$PREPARE pre_ply from $stmt;
	        $EXECUTE pre_ply;
    }  

    count=0;

    $declare a_cur cursor for 
      select distinct icard, iendorse, napplicant, itag, edr_type, nbranch,
             nleader, branch_tel, ext_tel, apayment_zip, apayment ,ipolicy_c , dbname_c, iassured_v
        from xyz;
    $open a_cur;
    for(;;)
    {
        $fetch a_cur into $icard, $iendorse, $napplicant, $itag, $edr_type, $nbranch,
                          $nleader, $branch_tel, $ext_tel, $apayment_zip, $apayment , $ipolicy_c , $dbname_c, $iassured_v ;
        if(SQLCODE == SQLNOTFOUND) break;
    
        printf(" icard[%s], iendorse[%s], napplicant[%s], itag[%s], edr_type[%s], nbranch[%s]"
               "          nleader[%s], branch_tel[%s], ext_tel[%s], apayment_zip[%s], apayment[%s]"
               " ipolicy_c[%s],dbname_c[%s], iassured_v[%s] \n", 
                 icard, iendorse, napplicant, itag, edr_type, nbranch, nleader, branch_tel, ext_tel,
                 apayment_zip, apayment, ipolicy_c, dbname_c, iassured_v); 

        strcpy(dbname_c  ,trim(dbname_c));  
        strcpy(ipolicy_c ,trim(ipolicy_c));  
        strcpy(iassured_v,trim(iassured_v));  

        /* 1070926002_SC1_�ק��v�q����q�����ˮ� */        
        if (edr_type[0]=='1')  /* �L�� */
        { 
            /* ���j���I�O��L��e���Ҧ��Q�O�I�Hid�A�P���N�I���Q�O�I�Hid�A
               �Y��藍��A�N���j��P���N�q�Y��������O�P�@�Q�O�I�H�A�o���i��O
               �]���j��������Q��L���N�I����(�X���)�~�� (�Y�������ۦP�A���Q�O�I�H���P) */
            tmpCount = 0; 
		    sprintf_s(stmt, sizeof stmt,
		               "select count(*) \n"
		               "  from %s:edr_relation a, %s:policy_bak k \n"
		               " where a.iendorse = k.iendorse \n"
		               "   and a.fedr_class IN ('2','8') \n"
		               "   and a.ipolicy  = '%s' \n"
		               "   and k.iassured = '%s' \n"
		               "   and a.dendorse between date('%s')-10 and date('%s')-4 \n"
                       "   and a.dedr_close IS NOT NULL\n"
                       ,
	                   dbname_c, dbname_c, ipolicy_c, iassured_v, sdate1, sdate1 );
 
            printf("�L�� stmt[%s]\n", stmt);
		    $PREPARE pre_tmp FROM $stmt;            
		    $EXECUTE pre_tmp INTO $tmpCount;
            printf("-- trace tmpCount[%d]\n ",tmpCount);
	        if (tmpCount==0) continue;
        }

        count++;

        if( count==1) /* ����Ƥ~�}�� */
        {
           if ((fp=fopen(filename,"w")) == NULL) {
               printf("fopen error[%s]\n",filename);
               return M_CM_FAILED;
	       }
        }

        $declare b_cur cursor for 
          select trim(ipolicy)||'�A'||dply_begin||'~'||dply_end
            from xyz
           where icard = $icard and iendorse = $iendorse and napplicant = $napplicant and itag = $itag and edr_type = $edr_type and nbranch = $nbranch
             and nleader = $nleader and branch_tel = $branch_tel and ext_tel = $ext_tel and apayment_zip = $apayment_zip and apayment = $apayment
             and ipolicy_c = $ipolicy_c and dbname_c = $dbname_c and iassured_v = $iassured_v;

        m=0;
        strcpy( tmp_ipolicy_begin_end, "");
        $open b_cur;
        for(;;)
        {
            $fetch b_cur into $tmp_policy;
            if(SQLCODE == SQLNOTFOUND) break;
            m++;
            if( m== 1)
                strcat( tmp_ipolicy_begin_end, trim(tmp_policy));
            else
            {
                strcat( tmp_ipolicy_begin_end, "|");
                strcat( tmp_ipolicy_begin_end, trim(tmp_policy));
            }
        }
        strcpy(icard,trim(icard));                 
        strcpy(iendorse,trim(iendorse));           
        strcpy(tmp_ipolicy_begin_end,trim(tmp_ipolicy_begin_end));
        strcpy(napplicant,trim(napplicant));       
        strcpy(itag,trim(itag));                   
        strcpy(edr_type,trim(edr_type));           
        strcpy(nbranch,trim(nbranch));             
        strcpy(nleader,trim(nleader));             
        strcpy(branch_tel,trim(branch_tel));       
        strcpy(ext_tel,trim(ext_tel));             
        strcpy(apayment_zip,trim(apayment_zip));   
        strcpy(apayment,trim(apayment));

        fprintf( fp, "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n ",
         icard, iendorse, tmp_ipolicy_begin_end, napplicant, itag, edr_type, nbranch, nleader, branch_tel, ext_tel, apayment_zip, apayment);
        
    }
    if( count != 0) fclose(fp);

    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/

/* runbatch 00 705138 car4012 P 2 '12/01/2016' '12/01/2016'  */
