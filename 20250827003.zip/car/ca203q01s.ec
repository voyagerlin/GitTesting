/****************************************************
 * Copyright (C) 1993 Intellisys Corporation
 *
 * Program : ca203q01s.ec 
 *
 * revised : Johnny 1997/07/11
 *
 * Background Report   (Type : Free Style)
 ****************************************************/

#include <stdio.h>
#include <math.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"

#include "carmsgs.h" 
#include "commsgs.h" 
#include "cmnmsgs.h" 
#include "gls_array.h" 
#include "gls_const.h"
#include "sqlfatal.h"
#include "spcmsgs.h"

$char what_type[8],sitename[20];;
$char ipolicy[20],icard[20],nassured[122],aassured[92],apayment[92],ilicense[12],ibirth[10];
$char iassured[11];
$char fsex[2],ncar_abbr[14],iissue_ym[8],itag[CA_TAG_NUM],dply_begin[14],dply_end[14];
$char icar_type[4],ibrand[10],nbrand_abbr[14],ibody[CA_BODY_NUM],itel[21],iengine[CA_ENGINE_NUM];
 char iengine_ext[6];
$char irelative_ply[20],qcylinder_buf[20],qperiod_buf[20],mpremium_buf[20];
$char bcard1[20],bcard2[20],bcard3[20],mY[4],mN[4],rel_ins_type[24],pdate[16];
$char bak_ins[8],fmarriage[4],irelative_card[20], iquery_num[15];
$int qperiod,mpremium;
$double qcylinder;
int tmp_prem,other_prem,flag1=0;
$double qpt;
char  ch_amt[40],policy_y;
char  s_dpolicy[14];
static char yy1[4], mm1[3], dd1[3];
$char allins1[100],allins2[100],ins1[24],ins12[24],ins2[24],ins22[24],ins3[24];
$char ins32[24],irelative_ply1[20],rel_card1[20],rel_card2[20];
$char fcomp_class[3],fcomp_class_last[3],fpt,cqpt[6];
$char icard1[20],ipolicy1[20],nassured1[122],ncar_abbr1[14],nbrand_abbr1[14];
$char iengine1[CA_ENGINE_NUM],itag1[CA_TAG_NUM],ilicense1[12],dply_begin1[14],dply_end1[14],ibody1[CA_BODY_NUM+1];
$char itmp_policy[21],isign[11],ientry[11],iscan_no[26];

$char Ipolicy[20],Iofficer[11],Iofficer_tmp[13],Nofficer[21];
$char ileader[10],Nleader[21];
$char icorps[11], ibranch[7];
$char Nbranch[19];
$char remark[128];

/*ca_accident*/
$char Inumber[21];

/*----------------------------------------------------------------------*/
extern char RPTDIR[];

$char print_type[10],cardbegin[20], cardend[20], mark[20],check_card[20];
$char print_frm[2],print_card[2],flag_tag[2], print_kind[2];
$char qDentry_bgn[11], qDentry_end[11], qIpolicy3[4], qIquota[8], qIleader[11], qIentry[11];
$char qIpolicy_bgn[11], qIpolicy_end[11], qIcar_kind[2];

int max_count;

$char DBName[5];
$char FormTp[3];
char  outputf[20];
$char  userid[11];
static Today;

long car203_build();
long car203_body();
void put_body1(); /* �j���ҷs�� car203.fmt */
void put_body2(); /* ���N�d */
void put_body3(); /* �j�����ª� car2031.fmt */
void put_body4(); /* �O�N���ª� car2032.fmt */
void put_body5(); /* �@����ª� car2033.fmt */
void put_body6(); /* �O�N��s�� car2034.fmt */
void put_body7(); /* �@���s�� car2035.fmt */
void put_body8(); /* �@���s�� car2038.fmt */
/*---------------------------------------------------------------------*/
char s_qlia[3][10], fyear[3];
$date rate_date;
long qdmg[3],qlia[3];
long mdmg[3],mlia[3];
long qlia_acc,qdmg_acc;
double pdmg_acc,plia_acc;


main(argc, argv)
int argc;
char **argv;
{
 long rc;
 batchinit();
 strcpy(DBName,      isNULLstr(argv[1]));
 strcpy(userid,      isNULLstr(argv[2]));
 strcpy(print_type,  isNULLstr(argv[3]));  /** 1:���N 2:�j�� **/
 strcpy(what_type,   isNULLstr(argv[4]));  /** 1:�O�渹 2:�j����/���N�d **/
 strcpy(cardbegin,   isNULLstr(argv[5]));
 strcpy(cardend,     isNULLstr(argv[6]));
 strcpy(mark,        isNULLstr(argv[7]));  /** '0' , '1':�e�~��P�O **/
 strcpy(print_frm,   isNULLstr(argv[8]));  /** 3:���O�N��,4:���@����ª�,5:���@���s�� 8:102/9/1�W�u�s�� **/
 strcpy(flag_tag,    isNULLstr(argv[9]));  /** 1:���L���P, 0:�L���P(default) **/
 strcpy(print_kind, isNULLstr(argv[10])); /* 0:�O�I�ҦL�s 1:�D�~��d�L�� */
 printf("client send %s %s %s %c %s %s\n",print_type,cardbegin,cardend,mark[0],
         print_frm, print_kind);
 strcpy(print_kind, trim(print_kind));
 if (strcmp(print_kind, "0") == 0)
 {
     strcpy(outputf, isNULLstr(argv[11]));
 }
 else
 {
     strcpy(qDentry_bgn,  isNULLstr(argv[11]));  /** ��J���(�_) **/
     strcpy(qDentry_end,  isNULLstr(argv[12]));  /** ��J���(��) **/
     strcpy(qIpolicy3,    isNULLstr(argv[13]));  /** ���(�O��e�T�X) **/
     strcpy(qIquota,      isNULLstr(argv[14]));  /** �~�Z��� **/
     strcpy(qIleader,     isNULLstr(argv[15]));  /** �޲z�H�N�� **/
     strcpy(qIentry,      isNULLstr(argv[16]));  /** ��J�H�N�� **/
     strcpy(qIpolicy_bgn, isNULLstr(argv[17]));  /** �O�渹�X(�_) **/
     strcpy(qIpolicy_end, isNULLstr(argv[18]));  /** �O�渹�X(��) **/
     strcpy(qIcar_kind,   isNULLstr(argv[19]));  /** 0:���� 1:�T�� **/ 
     strcpy(outputf,      isNULLstr(argv[20]));
      printf("client send %s %s %s %s %s %s %s %s %s\n",qDentry_bgn,qDentry_end,qIpolicy3
              ,qIquota,qIleader,qIentry,qIpolicy_bgn,qIpolicy_end, qIcar_kind);
 }

 rc=car203_build();
 if (rc != M_CM_OK) return rc;
       
 if ((rc=save_form_info(F_FREE,"CA",203,userid,FormTp,max_count,outputf))<0)
 {
     EWRITE(userid,rc,"save_form_info failed");
     exit(FAIL);
 }
}
/******************************************************************************/
void clear_data()
{
  ipolicy[0]=icard[0]=irelative_ply[0]=itmp_policy[0]=0;
  isign[0]=ientry[0]=iscan_no[0]=0;
  fcomp_class[0]=fcomp_class_last[0]=0;
  cqpt[0]=0;
  nassured[0]=aassured[0]=0;
  apayment[0]=0;
  ncar_abbr[0]=0;
  iissue_ym[0]=0;
  itag[0]=0;
  iengine[0]=0;
  icar_type[0]=0;
  nbrand_abbr[0]=0;
  ibrand[0]=0;
  qcylinder_buf[0]=0;
  ibody[0]=0;
  dply_begin[0]=dply_end[0]=0;
  qperiod_buf[0]=0;
  mpremium_buf[0]=0;
  ilicense[0]=0;
  ibirth[0]=0;
  fsex[0]=0;
  itel[0]=0;
  bcard1[0]=0;
  irelative_card[0]=0;
  mY[0]=mN[0]=0;
  rel_ins_type[0]=0;
  pdate[0]=0;
  fmarriage[0]=0;
}
/******************************************************************************/
void clear_data3()
{
  ipolicy1[0]=icard1[0]=0;
  nassured1[0]=0;
  iassured[0]=0;
  ncar_abbr1[0]=nbrand_abbr1[0]=0;
  itag1[0]=0;
  iengine1[0]=ibody1[0]=0;
  ilicense1[0]=0;
  dply_begin1[0]=dply_end1[0]=0;
  allins2[0]=0;
  rel_card2[0]=0;
  ins12[0]=ins22[0]=ins32[0]=0;
}
/******************************************************************************/
void clear_data2()
{
  ipolicy[0]=icard[0]=0;
  nassured[0]=0;
  iassured[0]=0;
  ncar_abbr[0]=nbrand_abbr[0]=0;
  itag[0]=iengine[0]=ibody[0]=0;
  ilicense[0]=0;
  dply_begin[0]=dply_end[0]=0;
  irelative_ply[0]=0;

  ipolicy1[0]=icard1[0]=0;
  nassured1[0]=0;
  ncar_abbr1[0]=nbrand_abbr1[0]=0;
  iengine1[0]=0;
  ilicense1[0]=0;
  dply_begin1[0]=dply_end1[0]=0;
  allins1[0]=0;
  rel_card1[0]=0;
  ins1[0]=ins2[0]=ins3[0]=0;
}
/*----------------------------------------------------------------------------*/   
long car203_build()
{
  $char FormFile[N_FILE+1];
  char  OutFile[N_FILE];
  long  rtncode;

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      exit(FAIL);
  }

  $SELECT nForm_File, iForm_Tp
     INTO $FormFile, $FormTp
     FROM Form
    WHERE ksys_grp="CA" AND kPgmID = 203
      AND iform_tp = $print_frm;
      
printf("---- FormFile =[%s]\n",FormFile);
  strcpy(FormFile,rtrim(FormFile));  /* FormFile=car203.fmt */
  sprintf(OutFile,"%s.tx",outputf);
  rgu_init_report(FormFile,OutFile);
  rtoday(&Today);
  strcpy(s_dpolicy,cm_cdate_str_100(Today));
  cm_split_ymd_100(s_dpolicy,yy1,mm1,dd1);
  strcpy(print_kind, trim(print_kind));
  if (strcmp(print_kind, "1") == 0)
  {
  	  rtncode=car203_temp_table();
      if (rtncode != M_CM_OK)
      {
      		EWRITE(userid,rtncode,sqlca.sqlerrm);
		      return rtncode;
		  }
      rtncode=car203_check_no_outside();
      if (rtncode != M_CM_OK)
      {
      		EWRITE(userid,rtncode,sqlca.sqlerrm);
		      return rtncode;
		  }
  }
  rtncode=car203_body(); 
  if (rtncode != M_CM_OK) {
  	  if ( max_count == 0 && print_kind[0] == '1')
  	  {
         EWRITE(userid,rtncode,remark);
  	  }
  	  else
  	  {
         EWRITE(userid,rtncode,sqlca.sqlerrm);
      }
      printf("exit_rtncode----->%d\n",rtncode);
      exit (FAIL);
  }
  rgu_finish_report();
  printf("finish_code------>%d\n",rtncode);
  return M_CM_OK;
  
errexit:
  sqlfatal();
  EWRITE(userid,SQLCODE,sqlca.sqlerrm);
  exit (FAIL);
} 

/*----------------------------------------------------------------------------*/   
long car203_body()
{
  $char stmt[400], stmt1[400],stmt2[400], stmt3[400];
  $char Condition1[128], Condition2[128], Condition3[128], sFtype_pol[3];
  $char sFtype_sp[3], fstatus[2];
  $int  iFstatus, count_pass;
  char which_card[100],taipei_db[40];
  int i, j; 
  $int rc;          /* 1071113006_SC1_CAR203�s�W�C�L��� */
  $char Msg[256];  

  $WHENEVER SQLERROR GOTO errexit;
  max_count=0;
  $BEGIN WORK;
  if (print_type[0]=='2') /* �L�j��� */
  {
    if (print_kind[0] == '0')
    {
       if (what_type[0]=='1') /* ����:�O�渹 */
       {
        sprintf(which_card,"ipolicy >= '%s' AND ipolicy <= '%s' order by ipolicy",
                           cardbegin,cardend);
        $SELECT icard INTO $check_card 
           FROM policy 
          WHERE ipolicy = $cardbegin;
        if (SQLCODE==SQLNOTFOUND) strcpy(check_card," ");
       } else { /* ����:�j��� */
        sprintf(which_card,"icard >= '%s' AND icard <= '%s' order by icard",
                           cardbegin,cardend);
        strcpy(check_card,cardbegin);
        printf("check_card----->%s",check_card);
       }

       if (check_card[3] >='A' && check_card[3] <= 'Z')  /*�O�N��*/
       {
        if (getHeadBranch(taipei_db)<0) {
           printf("read Config file error!!\n");
           return M_CM_READ_CONFIG_ERR;
        }
        printf("taipei_db----->[%s]\n",taipei_db);
        strcpy(sitename,get_full_dbname(taipei_db));
        strcat(sitename,":");
       } else strcpy(sitename," ");

printf("      ### sitename=[%s] \n",sitename);

                         /* �j��d���B�O�渹�B�O�I�����Bñ���� �A�q�j��d�� */
       if(what_type[0]=='2')
       {    
         printf(" �j��d�� what_type = 2 \n");  /* �j��d�� */     
         sprintf(stmt1, "SELECT ipolicy, icard, qperiod, dissue \
                           FROM %scompulsory_card c, car_type t \
                          WHERE fclass='1' AND t.icode=c.icar_type AND %s",
                          sitename,which_card);
       } else {
       printf(" �O�渹 what_type = 1 \n"); /* �O�渹 */
       sprintf(stmt1, "SELECT ipolicy, icard \
                         FROM policy  \
                        WHERE %s",which_card);
       }
    }
    else
    {
       sprintf(stmt1, "SELECT ipolicy FROM car203_tmp_policy ORDER BY ipolicy ");
       strcpy(qIcar_kind, trim(qIcar_kind));
       if (strcmp(qIcar_kind, "0") == 0)
          strcpy(Condition1, "AND icar_type IN ('01','02','32','34','35') ");
       else
          strcpy(Condition1, "AND icar_type NOT IN ('01','02','32','34','35') ");
    }
    
    printf("stmt1 [%s]\n",stmt1);
    $PREPARE cur_stmt1 from $stmt1;
    $DECLARE cur_com1 CURSOR for cur_stmt1; 
    $OPEN cur_com1; 
    for(;;)
    {
      clear_data();
      policy_y = 'Y';
      $FETCH cur_com1 INTO $ipolicy,$icard,$qperiod,$pdate;
      printf("icard [%s] ipolicy [%s] \n",icard,ipolicy);
      if (SQLCODE == SQLNOTFOUND) {      
        printf(" SQLCODE = [%d]\n",SQLCODE);
        break;
      }
      strcpy(Ipolicy, ipolicy); /*Ipolicy�j��O��*/

      printf("[%s][%s][%s]\n",icard,ipolicy,pdate);
     
      if (print_kind[0] == '1')
      {
      	  /* 1060821005_C2_�j���Һ޲z�{�� */
      	  /* �j���Ҫ��A : 0.���X */
          strcpy(icard, "");
          sprintf(stmt3, "SELECT FIRST 1 icard, fstatus FROM compulsory_card \
                           WHERE icard >= '%s' \
                             AND icard <= '%s' \
                             AND fstatus in ('0','5','6') \
                             AND (trim(ipolicy) = '' OR ipolicy IS NULl) \
                             %s ORDER BY icard;",cardbegin, cardend, Condition1);
          $PREPARE card_cur FROM $stmt3;
          $EXECUTE card_cur INTO $icard, $fstatus;
          if (SQLCODE == SQLNOTFOUND) {
              strcpy(remark, "�ҿ�J���j���Ҹ��϶��t�����i�i��ñ��/�L�Ҥ��ҥd(���A�D0,5,6��),�нT�{���ҥd���iñ�檬�A");
              break;
          }
          printf("***** �j���Ҫ��A:[%s][0.���X]*****\n", icard);
      }

      $SELECT p.ipolicy, p.nassured, p.aassured, p.apayment, r.icar_type,
              p.ncar_abbr, 
              to_char(p.dissue,'%Y')::integer - 1911,
              p.itag, p.iengine, p.nbrand_abbr, 
              r.ibrand, p.qcylinder, p.ibody, r.dply_begin, r.dply_end, 
              r.qply_period, p.ilicense, 
              to_char(p.dbirth,'%Y')::integer - 1911 || '/' || to_char(p.dbirth,'%m/%d'), 
              p.fsex, p.itel, 
              r.dpolicy, r.ilast_card, p.fmarriage, r.mlia_prem, r.iofficer
              , p.fpt, p.qpt, p.iassured, r.ileader, r.icorps, r.iquota[1,4] || '00' ibranch, iquery_num,
              r.itmp_policy, r.isign, r.ientry, r.iscan_no
         INTO $ipolicy, $nassured, $aassured, $apayment, $icar_type,
              $ncar_abbr, 
              $iissue_ym, 
              $itag, $iengine, $nbrand_abbr, 
              $ibrand, $qcylinder, $ibody, $dply_begin, $dply_end, 
              $qperiod, $ilicense, 
              $ibirth, 
              $fsex, $itel,
              $pdate, $bcard1, $fmarriage, $mpremium, $Iofficer, 
              $fpt, $qpt, $iassured, $ileader, $icorps, $ibranch, $iquery_num,
              $itmp_policy,$isign, $ientry, $iscan_no
         FROM policy p, ply_relation r 
        WHERE p.ipolicy = r.ipolicy AND r.ipolicy=$ipolicy;
     
      printf("SQLCODE == [%d]\n",SQLCODE);
      if (SQLCODE== SQLNOTFOUND) 
      
      {  qperiod=0; pdate[0]=0; mpremium=0;policy_y = 'N'; 
         printf("not found\n");
      }

      else { 
         $SELECT  nname
            INTO  $Nofficer
            FROM  officer
           WHERE  iofficer = $Iofficer;

         $SELECT  nname
            INTO  $Nleader
            FROM  officer
           WHERE  iofficer = $ileader;

		 $SELECT nbranch
			 INTO $Nbranch
			 FROM sa_branch_type
			 WHERE ibranch = $ibranch;

         $SELECT  ncode
              INTO  $ncar_abbr
              FROM  car_type
              WHERE  icode = $icar_type AND fclass = '1';
              ncar_abbr[8] = '\0';
              printf("---------------->%s",ncar_abbr);  

         $SELECT irelative_ply,fcomp_class,fcomp_class_last INTO $irelative_ply
                 ,$fcomp_class,$fcomp_class_last  FROM ply_relation
           WHERE ipolicy=$ipolicy;
         if (SQLCODE != SQLNOTFOUND) 
         {
            /* select �I�إN�X from �O���I�ة��� */ 
            $DECLARE cur_ins CURSOR for
              SELECT iins_type
                FROM ply_ins_type  
               WHERE ipolicy=$irelative_ply;
            $OPEN cur_ins;
            for(;;)
            {
              $FETCH cur_ins into $bak_ins;
              if (SQLCODE == SQLNOTFOUND) break;

              strcat(rel_ins_type,rtrim(bak_ins)); 
            }
         }

	 $SELECT icard into $irelative_card
	    FROM ply_relation
	   WHERE ipolicy = $irelative_ply;
  printf( " irelative_card [%s] \n",irelative_card);

         $SELECT ilast_card into $bcard2
            FROM ply_relation
           WHERE icard=$bcard1;
         if (SQLCODE != SQLNOTFOUND)
         { 
            $SELECT ilast_card INTO $bcard3
               FROM ply_relation
              WHERE icard=$bcard2;
         }
      }
       
      /* car9711072 �Y���������ŭ�,�h�L�X������ */
      if(strlen(trim(iengine)) == 0) strcpy(iengine,ibody);
      
      
      printf("--- print_frm = [%s]\n",print_frm);
      if (strncmp(print_frm,"3",1)==0)
          put_body6(); /*�O�N��s�� */
      else if (strncmp(print_frm,"4",1)==0)
          put_body5(); /* �@����ª� */
      else if (strncmp(print_frm,"5",1)==0)
          put_body7(); /* �@���s�� */
      else if (strncmp(print_frm,"8",1)==0)
          put_body8(); /* �@���102/9/1�W�u�s�� */
     
      $UPDATE ply_relation 
          SET fprint = '1'
        WHERE ipolicy= $ipolicy 
          AND fprint = '0';
        
      rc = insert_ca_log("car203","P",icard,ipolicy,"�j���ҦC�L",userid,Msg);
	  printf("Msg[%s] rc[%d]",Msg,rc);
	  if( rc != M_CM_OK)
	  {
	   	 $ROLLBACK WORK;
		 return  rc;
	  }
               
      /* �Ȥ��{�d�A�z�Lcar344�C�L�e�~�O�I��
         �^���l�H�覡(0:���e�~�l�H) add by larry 103.03.13 (1010523004_C2) 
      if (strncmp(mark,"1",1) == 0){
        $UPDATE ply_relation
            SET fmail_type = '0'
          WHERE ipolicy = $ipolicy
            AND dpolicy = today
            AND fout_print = '1'
            AND fmail_type != '0'
            AND dply_close is null;
      }
      */
      /* �Ȥ��{�d�A�z�Lcar344�C�L�e�~�O�I��
         �^���l�H�覡(0:���e�~�l�H) add by �L�� 105.01.26 (1050115002_C1) */
      if (strncmp(mark,"1",1) == 0){
        $UPDATE ply_relation
            SET fmail_type = '0'
          WHERE ipolicy = $ipolicy
            AND fout_print = '1'
            AND fmail_type != '0'
            AND dout_trans is Null;

        $UPDATE ori_ply_relation
            SET fmail_type = '0'
          WHERE ipolicy = $ipolicy
            AND fout_print = '1'
            AND fmail_type != '0'
            AND dout_trans is Null;
      }
      
      
      
      /* �u�D�~��d�v�L�Ҧ^������� (1040828003_C2) add by larry */
      if (print_kind[0] == '1')
      {
      	  /* 1060821005_C2_�j���Һ޲z�{�� */
          printf("***** �D�~��dUPDATE *****\n");
          printf("***** ipolicy[%s], itmp_policy[%s], icard[%s]\n", ipolicy,itmp_policy,icard);
          /* �j��d�� */
          $UPDATE compulsory_card
              SET fstatus = '1',
                  ialter = $userid,
                  dalter = today,
                  ipolicy = $ipolicy
            WHERE icard = $icard
              AND fstatus in ('0','5','6')
              AND (trim(ipolicy) = '' OR ipolicy IS NULL);
          if (sqlca.sqlerrd[2]==0) {
			        $ROLLBACK WORK;
			        strcpy(remark, cm_get_errmsg(M_SP_AUDEXCP));
			        return M_SP_AUDEXCP; /* 22000 : ��Ʋ��ʮɵo�Ͳ��`�A�Э��� */
		      }
		      
		      strcpy(sFtype_pol, "");
		      strcpy(sFtype_sp, "");
		      $SELECT ftype_pol, ftype_sp INTO $sFtype_pol, $sFtype_sp
		         FROM cm_pre_receive
		        WHERE iins_cat = 'C'
		          AND ipre_rcv = $itmp_policy
		          AND iins_kind = '1'
		          AND ipre_end = ' ';
		       if (SQLCODE == SQLNOTFOUND)
		       {
		           $ROLLBACK WORK;
		           strcpy(remark, cm_get_errmsg(M_CA_PLY_NOT_FOUND));
		           return M_CA_PLY_NOT_FOUND;
		       }
		       strcpy(sFtype_pol, trim(sFtype_pol));
		       strcpy(sFtype_sp, trim(sFtype_sp));
		       printf("***** ftype_pol[%s], ftype_sp[%s]*****\n", sFtype_pol, sFtype_sp);	       
		       /* �O�����p�� */
		       /* �O�����O=�uPA�v�B�uSP-01�v�ΡuSP-10�v�h�^���uñ���(�t�Τ�)�v */
		       if ((strcmp(sFtype_pol, "SP") == 0 && strcmp(sFtype_sp, "01") == 0) || (strcmp(sFtype_pol, "SP") == 0 && strcmp(sFtype_sp, "10") == 0) ||
		            strcmp(sFtype_sp, "PA") == 0 || strcmp(sFtype_pol, "NA") == 0)
		       {
		           printf("***** ftype_sp: 01 or PA *****\n");
		           $UPDATE ply_relation
		               SET icard = $icard,
		                   dpolicy = today
		             WHERE ipolicy = $ipolicy
		               AND ipolicy = icard;
		       }
		       else
		       {
		       	   printf("***** ftype_sp NOT 01 , PA *****\n");
		       	   $UPDATE ply_relation
		               SET icard = $icard
		             WHERE ipolicy = $ipolicy
		               AND ipolicy = icard;
		       }
		       if (sqlca.sqlerrd[2]==0) {
			         $ROLLBACK WORK;
			         strcpy(remark, cm_get_errmsg(M_SP_AUDEXCP));
			         return M_SP_AUDEXCP; /* 22000 : ��Ʋ��ʮɵo�Ͳ��`�A�Э��� */
		       }
           
           /* �O��򥻸���� */
           $UPDATE policy
		           SET icard = $icard
		         WHERE ipolicy = $ipolicy
		           AND ipolicy = icard;
		       if (sqlca.sqlerrd[2]==0) {
			         $ROLLBACK WORK;
			         strcpy(remark, cm_get_errmsg(M_SP_AUDEXCP));
			         return M_SP_AUDEXCP; /* 22000 : ��Ʋ��ʮɵo�Ͳ��`�A�Э��� */
		       }
           
           /* �O�����O=�uSP-20�v�����^���u�L���v */
           if (strcmp(sFtype_pol, "SP") == 0 && strcmp(sFtype_sp, "20") == 0)
           {
               strcpy(Condition2, " ");
               strcpy(Condition3 ," ");
           }
           else
           {
           	   count_pass = iFstatus = 0;
               $SELECT count(ipre_rcv) into $count_pass
			            FROM ao_prercv_pass
			           WHERE iins_cat  = 'C'
			             AND ipre_rcv  = $itmp_policy
			             AND iins_kind = '1' 
			             AND ipre_end  = ' ';
			             			     
			         if (count_pass > 0)
			             iFstatus = 60 ;   /* �w�L��,�w���O */
			         else
                   iFstatus = 30 ;   /* �w�L��,�����O */
                   
               strcpy(Condition2 ,"dprint = current, ");
               sprintf(Condition3 ,"fstatus  = %d , ", iFstatus);
           }
          
           /* �@�γ����� */
           sprintf(stmt, "UPDATE cm_pre_receive \
	                           SET icard = '%s' , \
	                               %s \
	                               %s \
	                               iupdate = 'CAR203', \
	                               dupdate = current \
	                         WHERE iins_cat = 'C' \
	                           AND ipre_rcv = '%s' \
	                           AND iins_kind = '1' \
	                           AND ipre_end = ' ';", icard, Condition2, Condition3, itmp_policy);

	         printf("stmt=[%s]\n", stmt);
	   
	         $PREPARE cmPreRecevie_pre FROM $stmt;
	         $EXECUTE cmPreRecevie_pre;
           if (sqlca.sqlerrd[2]==0) {
			         $ROLLBACK WORK;
			         strcpy(remark, cm_get_errmsg(M_SP_AUDEXCP));
			         return M_SP_AUDEXCP; /* 22000 : ��Ʋ��ʮɵo�Ͳ��`�A�Э��� */
		       }
      }
    }
    $CLOSE cur_com1;
    $FREE cur_com1;
    printf("print_type2 end\n");
  } 
     else if (print_type[0]=='1') {
     if(what_type[0]=='1')  /*����:�O�渹*/
       sprintf(which_card,"c.ipolicy >= '%s' AND c.ipolicy <= '%s' order by p.ipolicy", cardbegin,cardend);
     else /* ����:���N�d */
       sprintf(which_card,"c.icard >= '%s' AND c.icard <= '%s' order by c.icard", cardbegin,cardend);

     sprintf(stmt,"SELECT i.nins_abbr \
                     FROM insurance_type i, ply_ins_type t \
                    WHERE t.ipolicy=? AND t.iins_type=i.iins_type \
                   ");
     printf("%s\n",stmt); 
     $PREPARE cur_insp from $stmt;
     $DECLARE cur_sel_ins CURSOR for cur_insp;
     
     sprintf(stmt,"SELECT c.icard, p.ipolicy, nassured, ncar_abbr, \
                           nbrand_abbr, iengine, ilicense, itag, ibody,\
                           dply_begin, dply_end, r.irelative_ply \
                     FROM policy p, card c, ply_relation r \
                    WHERE c.icard=p.icard AND r.icard=c.icard \
                      AND %s ", which_card);
printf("%s\n",stmt); 

    $PREPARE cur_stmt from $stmt;
    $DECLARE cur_card CURSOR for cur_stmt;
    $OPEN cur_card;
    for (i=0;i<9;i++) rgu_put_body(1);
    for(;;)
    {
      clear_data2();
      $FETCH cur_card INTO
        $icard, $ipolicy, $nassured, $ncar_abbr, $nbrand_abbr,
        $iengine, $ilicense, $itag, $ibody, $dply_begin, $dply_end, $irelative_ply;
      if (SQLCODE == SQLNOTFOUND) break;

      if (icard[1] <= 'Z' && icard[1] >='A') continue; /*�D�O�N��*/

      $SELECT a.icard INTO $rel_card1
         FROM ply_relation a,ply_relation b
        WHERE a.ipolicy=b.irelative_ply 
          AND b.icard=$icard;
      $OPEN cur_sel_ins using $ipolicy;
      for(;;)
      {
        $FETCH cur_sel_ins INTO $bak_ins;
        if (SQLCODE == SQLNOTFOUND) break;
        bak_ins[6]=0;

        /*** midify �T�d�ˤT�d�]=>�ĤT�H�d���I ***/
        if (strcmp(bak_ins,"�T�d��")==0) strcpy(bak_ins,"�ĤT�H");
        if (strcmp(bak_ins,"�T�d�]")==0) strcpy(bak_ins,"�d���I");

        strcat(allins1,bak_ins);
      } 
      $CLOSE cur_sel_ins;
   
again:
      clear_data3();
      $FETCH cur_card INTO
        $icard1,$ipolicy1,$nassured1,$ncar_abbr1,$nbrand_abbr1,
        $iengine1,$ilicense1,$itag1, $ibody1, $dply_begin1, $dply_end1, $irelative_ply1;
      if (SQLCODE == SQLNOTFOUND)
      {
        put_body2();     
        break;
      }
      if (icard1[1] <= 'Z' && icard1[1] >='A')
        goto again;
      $SELECT a.icard INTO $rel_card2
         FROM ply_relation a,ply_relation b
        WHERE a.ipolicy=b.irelative_ply 
          AND b.icard=$icard1;
      $OPEN cur_sel_ins using $ipolicy1;
      for(;;)
      {
        $FETCH cur_sel_ins into $bak_ins;
        if (SQLCODE == SQLNOTFOUND) break;
        bak_ins[6]=0;

        /*** midify �T�d�ˤT�d�]=>�ĤT�H�d���I ***/
        if (strcmp(bak_ins,"�T�d��")==0) strcpy(bak_ins,"�ĤT�H");
        if (strcmp(bak_ins,"�T�d�]")==0) strcpy(bak_ins,"�d���I");

        strcat(allins2,bak_ins);
      } 
      $CLOSE cur_sel_ins;

      put_body2();
    }
    $CLOSE cur_card;
    $FREE cur_card;
  }
  $COMMIT WORK;
  
  if (max_count==0)
      return M_CM_NOT_FOUND;

  return M_CM_OK;

errexit:
  sqlfatal();
  EWRITE(userid,SQLCODE,sqlca.sqlerrm);
  $ROLLBACK WORK;
  exit(FAIL);
}
/******************************************************************************/
long car203_check_no_outside()
{
    $char sStmt[4096];    
    $char sIpolicy[21], sItmp_policy[21], sDply_bgn[11];
    $char sIofficer[11],sIquota[8],sIcomm_obj[11], sIroute[21], sIroute_prop[3];
   
    $char ftype_sp[3], deffect4[11], deffect4_edr[10], err_flag[2];
    $char Condition1[128], Condition2[128];
    $int  count_receive, count_pass, sMprem;
    $long sToday, sLdeffect4;
    $int  iTmp, jTmp,fstatus;
    int rc;
  
    $WHENEVER SQLERROR GOTO errexit;
    
    strcpy(qIcar_kind, trim(qIcar_kind));
    if (strcmp(qIcar_kind, "0") == 0)
        strcpy(Condition1, " AND b.icar_type IN ('01','02','32','34','35') ");
    else
        strcpy(Condition1, " AND b.icar_type NOT IN ('01','02','32','34','35') ");

    strcpy(qIpolicy_bgn, trim(qIpolicy_bgn));
    if (strcmp(qIpolicy_bgn, "*") != 0)
        sprintf(Condition2, " AND a.ipolicy >= '%s' AND a.ipolicy <= '%s' "
                          , qIpolicy_bgn, qIpolicy_end);
    else
    	  strcpy(Condition2, " ");
    
	  sprintf(sStmt, 
	          "SELECT a.ipolicy, b.itmp_policy, b.dply_begin, b.iofficer, "
	          "       b.iquota, b.icomm_obj, a.iroute, a.iroute_prop  "
		 	      "  FROM policy a, ply_relation b "
		 	      " WHERE a.ipolicy = b.ipolicy "
		 	      "   AND a.ipolicy = b.icard "
		 	      "   AND a.icard = b.ipolicy "
		 	      "   AND b.ibig_comp = ' '"
		 	      "   AND b.dentry >= '%s' "
		 	      "   AND b.dentry <= '%s' "
		 	      "   AND a.ipolicy[1,3] matches '%s' "
		 	      "   AND b.iquota matches '%s' "
		 	      "   AND b.ileader matches '%s' "
		 	      "   AND b.ientry matches '%s' "
		 	      "   %s %s ORDER BY a.ipolicy;"
		 	      , qDentry_bgn, qDentry_end, qIpolicy3, qIquota, qIleader, qIentry, Condition1, Condition2);
    
    $PREPARE ca_card FROM $sStmt;
    $DECLARE no_outside_cur CURSOR FOR ca_card;
    $OPEN no_outside_cur;
    for(;;)
    {
        $FETCH no_outside_cur INTO $sIpolicy, $sItmp_policy, $sDply_bgn, 
                                   $sIofficer, $sIquota, $sIcomm_obj, $sIroute, 
                                   $sIroute_prop;
        if(SQLCODE == SQLNOTFOUND) break;
        
        strcpy(remark, "");
        /* �ˮ�(�@)�g��N���O�_���� */
        if( sIofficer[0] != 'W')
        {
            rc = cm_chk_policy("1", sIofficer, " ", " ", " ", " ", " ", " ");
            if( rc != M_CM_OK)
            {
                strcpy(remark, cm_get_errmsg(rc));
            	  continue;
            }
        }
        
        /* �ˮ�(�G)�~�Z���O�_���� */
        rc = cm_chk_policy("2", " ", " ", sIquota, " ", " ", " ", " ");
        if( rc != M_CM_OK)
        {
            strcpy(remark, cm_get_errmsg(rc));
            continue;
        }
        	
        /* �ˮ�(�T)�I����H�O�_����X�� */
        rc = cm_chk_policy("4", " ", " ", " ", sIcomm_obj, " ", " ", " ");
        if( rc != M_CM_OK)
        {
            strcpy(remark, cm_get_errmsg(rc));
            continue;
        }
        	
        /* �ˮ�(�|)�I����H���L�X���� */
        rc = cm_chk_policy("6", " ", " ", " ", sIcomm_obj, "C", " ", " ");
        if( rc != M_CM_OK)
        {
            strcpy(remark, cm_get_errmsg(rc));
            continue;
        }
        	
        /* �ˮ�(��)�q���N���P�q���ۭq�~�ȥN���������Y�O�_���T */
        rc = cm_chk_policy("7", " ", " ", " ", " ", " ", sIroute, sIroute_prop);
        if( rc != M_CM_OK)
        {
            strcpy(remark, cm_get_errmsg(rc));
            continue;
        }
      
        /* �ˮ�(��)�O�_�s�b�@�γ������� */
        count_receive = count_pass = 0;
        strcpy(ftype_sp, "");
        $SELECT ftype_sp,fstatus, count(ftype_sp)
           INTO $ftype_sp, $fstatus,$count_receive
           FROM cm_pre_receive
          WHERE iins_cat = 'C'
            AND ipre_rcv = $sItmp_policy
            AND iins_kind = '1'
            AND ipre_end = ' '
          GROUP BY ftype_sp,fstatus;
        
        if (count_receive > 0)
        {
        	/* 1060106005_C1 �ץ����s�t�ΥX��@�~(�p�P�N�����榬�O�@�o�ɻݦP�ɨ����i�X��@�~) */
	        if (fstatus == 90)
	        {	        	            
                strcpy(remark, "�@�γ�����w�@�o");
                continue;
	        }
	        else
	        {        	
	        	  /* �O�����O=[PA] */
	            strcpy(ftype_sp, trim(ftype_sp));
	            if (strcmp(ftype_sp, "PA") == 0)
	            {
	            	  /* �P�_�O�_�w���O */
	                $SELECT count(ipre_rcv) INTO $count_pass
				             FROM ao_prercv_pass
				            WHERE iins_cat  = 'C'
				              AND ipre_rcv  = $sItmp_policy
				              AND iins_kind = '1' 
				              AND ipre_end  = ' ';
				              
				    if (count_pass == 0)
				    {
	                    /* �ư��O�����O=[PA]�����O*/
	                    printf("***** ipolicy[%s]�G[PA]�����O ***** \n", ipolicy);
	                    continue;
	                }
	            }
	        }    	            
        }
        else
        {
            strcpy(remark, cm_get_errmsg(M_CA_PLY_NOT_FOUND));
            continue;
        }
        
        /* �ˮ�(�C)�O�_�O�� (�t�Τ� > �ͮĤ�+�|�Ӥu�@��) */
        sToday = 0;
		sLdeffect4 = 0;
		strcpy(deffect4, "");
		strcpy(deffect4_edr, "");
		/* �ͮĤ�+ �|�Ӥu�@�� */
		/*
		$SELECT skip 3 first 1 dwork
		   INTO $deffect4
		   FROM cm_wrktbl
		  WHERE dwork > $sDply_bgn
		    AND fwork = '0';*/

		jTmp = 0;
 		for(iTmp=1;jTmp<=4;iTmp++)
 		{
     		$select 1 
           	   from ca_holiday
       	  	  where (date($sDply_bgn) + $iTmp) between holiday_bgn and holiday_end;
       	  
     		if( SQLCODE == SQLNOTFOUND) jTmp++;
     	
     		printf("iTmp[%d,jTmp[%d]\n", iTmp, jTmp);
     		
     		if( jTmp == 4 ) break;

		}
 		$select first 1 to_char(date($sDply_bgn) + $iTmp) into $deffect4 from ca_holiday;
		              
		   strcpy(deffect4_edr, cm_from_infdate_100(deffect4));
		   sLdeffect4 = cm_ymd_cdate(deffect4_edr);
		   sToday = cm_today( ); /* �t�Τ� */
		   printf("***** Today[%ld], Deffect4[%ld]*****\n", sToday, sLdeffect4);
		   /* �i�t�Τ� > �ͮĤ�+�|�Ӥu�@�ѡj(�O����)*/
		   if (sToday > sLdeffect4)
		   {
		   	 strcpy(remark, "�O����");
		   	 continue;
		   }
        
        $INSERT INTO car203_tmp_policy VALUES($sIpolicy);
    }
    $CLOSE no_outside_cur;
    $FREE  no_outside_cur;
    
    return M_CM_OK;
    
errexit:
  sqlfatal();
  EWRITE(userid,SQLCODE,sqlca.sqlerrm);
  exit(FAIL);
}
/******************************************************************************/
long car203_temp_table()
{
	  $WHENEVER SQLERROR GOTO errexit;
	  
	  $create temp table car203_tmp_policy(
       ipolicy   char(20)   
     )with no log;
     
    $create temp table car203_tmp_card(
       icard    char(20)   
     )with no log;
      
    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;     
}
/******************************************************************************/
int cc_split(s_buf,t_buf,len)
char *s_buf;
char *t_buf;
int len;
{
  int i,flag;

  for(i=0;i<len;) {
    if((unsigned) s_buf[i]>128)  /* �ˬd�O�_������r�A�Y s_buf[i] > 128 ���ܬ�����r */
    {                                    /* �h�@������Ӧr���A�_�@��catch�@�Ӧr�� */
      strncpy(&t_buf[i],&s_buf[i],2);
      t_buf[i+2]='\0';
      i+=2;
    } else {
      strncpy(&t_buf[i],&s_buf[i],1);
      t_buf[i+1]='\0';
      i++;
    }
    if(i>len ) {
      t_buf[i-2]='\0';
      return i-2;
    } else if(i==len ) {
      return i;
    }
  }
}
/******************************************************************************/
split_ch(source,s1,s2,l)
char source[],s1[],s2[];
int l;
{
  char oo[200];
  int i;
  strcpy(oo,rtrim(source));
  if (strlen(oo)> l)
  {
    i=cc_split(oo,s1,l);
    strcpy(s2,&oo[i]);
  }else{
    strcpy(s1,oo);
    s2[0]=0;
  }
}
/******************************************************************************/
void put_body1()
{
  char tmpbuf[150],tmpbuf1[150];
  char yy[10],mm[10],dd[10];
  char tmpcard[21];
  int i;


rate_date=cm_ymd_cdate(cm_from_infdate_100(dply_begin));


  if ((ipolicy[0]!='\0')&&(ipolicy[0]!=' ')){
     if ((itag[0]!='\0')&&(itag[0]!=' '))
       { strcpy(Inumber, itag); }
     else
       { strcpy(Inumber, iengine); }
/**  crystal-removed at 87/01/19 
     ca_accident_record(DBName,Inumber ,rate_date,"1", qdmg,qlia, mdmg,mlia,
                        &qdmg_acc,&qlia_acc, &pdmg_acc,&plia_acc,fyear);
**/
  }else{
     strcpy(fyear,"NNN");
  }

  for(i=0;i<3;i++){
    printf("ca_accident[%d]:[%c]%ld\n",i,fyear[i],qlia[i]);
    if (fyear[i]=='Y')
       strcpy(s_qlia[i],itoa(qlia[i]));
    else
       strcpy(s_qlia[i]," ");
  }
/*
* for(i=0;i<6;i++)
*   rgu_put_body(1);
*/
  if (icard[1] <= 'Z' && icard[1] >='A')
  {
    tmpbuf[0]=0;
    strcpy(tmpbuf1,icard);
  }else{
    strncpy(tmpbuf,icard,2); tmpbuf[2]=0;
    strcpy(tmpbuf1,"17");
    strcat(tmpbuf1,&icard);
  }
    /*     rgu_put_body_string(10,tmpbuf,RIGHT); */
  strcpy(tmpcard,trim(tmpbuf1));
  rgu_put_body_string(10,tmpbuf1,LEFT);
  rgu_put_body_string(28,tmpbuf1,LEFT);
  rgu_put_body(10);
/*rgu_put_body(1);*/
  split_ch(nassured,tmpbuf,tmpbuf1,38);
  if (*fsex == '1')
       strcat(tmpbuf," ����");
  else if (*fsex == '2')
       strcat(tmpbuf," �p�j");
  tmpbuf[30]=0;
  tmpbuf1[30]=0;
  rgu_put_body_string(12,tmpbuf,LEFT);
  rgu_put_body_string(30,tmpbuf,LEFT);

  rgu_put_body(12);
  split_ch(aassured,tmpbuf,tmpbuf1,38);
  if (strlen(tmpbuf1)==0) {
      rgu_put_body_string(13," ",LEFT);
      rgu_put_body_string(13,trim(bcard1),LEFT);
      rgu_put_body_string(14,tmpbuf,LEFT);
  }
  else {
      rgu_put_body_string(13,tmpbuf,LEFT);
      rgu_put_body_string(13,trim(bcard1),LEFT);
      tmpbuf1[38]=0;
      rgu_put_body_string(14,tmpbuf1,LEFT);
  }
  rgu_put_body(13);
  rgu_put_body(14);
  if (strncmp(ilicense," ",1)==0)
      if (strncmp(iassured,"AAAAAAAAAA",10)!=0)
          strcpy(ilicense,iassured);
  for(i=0;i<10;i++) 
  {
   strncpy(tmpbuf,ilicense+i,1);
   tmpbuf[1]='\0';
   rgu_put_body_string(15,tmpbuf,LEFT);
  }
  rgu_put_body(15);
  rgu_put_body(1);
  rgu_put_body_string(16,nbrand_abbr,LEFT);
  rgu_put_body_string(36,nbrand_abbr,LEFT);
  ncar_abbr[8]=0;
  rgu_put_body_string(16,ncar_abbr,LEFT);
  rgu_put_body_string(34,ncar_abbr,LEFT);

  strcpy(yy,iissue_ym);
  yy[3]=0;
  rgu_put_body_string(16,yy,LEFT);
  rgu_put_body_string(34,yy,LEFT);
  
  /* car9901133 �Y��ܤ��L���P,�h���P���M���ť� */  
  if ((itag[0]!='\0' && itag[0]!=' ') && (flag_tag[0] != '1'))
     {
       itag[CA_TAG_NUM]=0;
       rgu_put_body_string(16,itag,LEFT);
       rgu_put_body_string(34,itag,LEFT);
     }
  else
     {
       rgu_put_body_string(16," ",LEFT);
       rgu_put_body_string(34," ",LEFT);
     }
  if ((iengine[0]!='\0')&&(iengine[0]!=' '))
     {
       iengine[21]=0;
       rgu_put_body_string(16,iengine,LEFT);
       rgu_put_body_string(34,iengine,LEFT);
     }
  else
     {
       /*rgu_put_body_string(16," ",LEFT);*/
       if((ibody[0]!='\0')&&(ibody[0]!=' '))
       {
           ibody[22]=0;
           rgu_put_body_string(16,ibody,LEFT);
       } else rgu_put_body_string(16," ",LEFT);
     }
  rgu_put_body(16);
  if(dply_begin[0]==0)
  {
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
  }else{
       strcpy(tmpbuf,cm_from_infdate_100(dply_begin));
       cm_split_ymd_100(tmpbuf,yy,mm,dd);
       rgu_put_body_string(17,yy,LEFT);
       rgu_put_body_string(31,yy,LEFT);
       rgu_put_body_string(17,mm,LEFT);
       rgu_put_body_string(31,mm,LEFT);
       rgu_put_body_string(17,dd,LEFT);
       rgu_put_body_string(31,dd,LEFT);
  }
  if(qperiod==0)
   {
       rgu_put_body_string(17,qperiod,LEFT);
       rgu_put_body_string(31,qperiod,LEFT);
   } else
   {
       strcpy(tmpbuf,itoa(qperiod));
       rgu_put_body_string(17,tmpbuf,LEFT);
       rgu_put_body_string(31,tmpbuf,LEFT);
   }
  rgu_put_body(17);

  if(dply_end[0]==0)
    {
        rgu_put_body_string(18,"",LEFT);
        rgu_put_body_string(18,"",LEFT);
        rgu_put_body_string(18,"",LEFT);
    } else
    {
        strcpy(tmpbuf,cm_from_infdate_100(dply_end));
        cm_split_ymd_100(tmpbuf,yy,mm,dd);
        rgu_put_body_string(18,yy,LEFT);
        rgu_put_body_string(18,mm,LEFT);
        rgu_put_body_string(18,dd,LEFT);
        rgu_put_body_string(32,yy,LEFT);
        rgu_put_body_string(32,mm,LEFT);
        rgu_put_body_string(32,dd,LEFT);
    }

  if (ibirth[0]==0) {
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"",LEFT);
  }else{
         cm_split_ymd_100(ibirth,yy,mm,dd);
         rgu_put_body_string(18,yy,LEFT);
         rgu_put_body_string(18,mm,LEFT);
         rgu_put_body_string(18,dd,LEFT);
  }

  if(fsex[0]=='1'){
         rgu_put_body_string(18,"v",LEFT);
         rgu_put_body_string(18,"",LEFT);
  }else if(fsex[0]=='2'){
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"v",LEFT);
  }else{
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"",LEFT);
  }
  if (fmarriage[0]=='1'){
         rgu_put_body_string(18,"v",LEFT);
         rgu_put_body_string(18,"",LEFT);
                         }
  else if (fmarriage[0]=='2')
  {
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"v",LEFT);
  }else{
         rgu_put_body_string(18,"",LEFT); 
         rgu_put_body_string(18,"",LEFT);
  }
  rgu_put_body_string(18,fcomp_class_last,LEFT);
  rgu_put_body(18);

    if(mpremium==0)
    {
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
    }else{
       strcpy(mpremium_buf,refmtamt(mpremium,MILLIONTH));
       rgu_put_body_string(26,rtrim(mpremium_buf),LEFT);
       tmp_prem=mpremium/10000;
       other_prem=mpremium%10000;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       tmp_prem=other_prem/1000;
       other_prem=other_prem%1000;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       tmp_prem=other_prem/100;
       other_prem=other_prem%100;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       tmp_prem=other_prem/10;
       other_prem=other_prem%10;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       num_to_chinese(ch_amt,other_prem);
       if (other_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);
    }
    if (strlen(irelative_ply)==0)
        rgu_put_body_string(19," ",LEFT);
    else {
        sprintf(tmpbuf,"17%s",trim(irelative_ply));
        rgu_put_body_string(19,tmpbuf,LEFT);
    }
    rgu_put_body_string(19,tmpcard,LEFT);
    rgu_put_body(19);
   if (fpt == 'P')
     {
          sprintf(cqpt,"%5.0f",qpt); 
          printf("cqpt---->%s\n",cqpt);
          rgu_put_body_string(20, cqpt, LEFT);    
     }
   else if ( fpt == 'T')
     {
          rgu_put_body_string(20,"",RIGHT);
          sprintf(cqpt,"%5.1f", qpt);
          rgu_put_body_string(20,cqpt,LEFT);
     } 
   else
      {
          rgu_put_body_string(20,"",RIGHT);
          rgu_put_body_string(20,"",LEFT);
      }
   rgu_put_body(20);
    rgu_put_body(1);
    rgu_put_body(1);
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(23,yy1,RIGHT);
       rgu_put_body_string(23,mm1,RIGHT);
       rgu_put_body_string(23,dd1,RIGHT);
    }else {
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(23," ",RIGHT);}

    rgu_put_body(23);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(26);
    rgu_put_body(28);
    rgu_put_body(1);
    rgu_put_body(30);
    rgu_put_body(31);
    rgu_put_body(32);
    rgu_put_body(1);
    rgu_put_body(34);
    rgu_put_body(1);
    if (qcylinder == 0 && strncmp(icar_type,"35",2) != 0)
    { rgu_put_body_string(36,"",LEFT);}
    else
    { strcpy(tmpbuf,itoa(qcylinder));
      rgu_put_body_string(36,tmpbuf,RIGHT);
    }
    strncpy(tmpbuf,iengine,15);
    if(strlen(trim(iengine)) >15) 
     {
      strncpy(iengine_ext,iengine+15,5);
      iengine_ext[5]= '\0';
     }
    else
      iengine_ext[0] = '\0';
    tmpbuf[15] = '\0'; 
    printf ("iaaa[%s]\n",tmpbuf);
    rgu_put_body_string(36,tmpbuf,LEFT);
    rgu_put_body_string(36,fcomp_class,RIGHT);
    rgu_put_body(36);
    rgu_put_body_string(37,iengine_ext,LEFT);
    rgu_put_body(37);
    rgu_put_body(1);
 /* rgu_put_body(1);*/
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(39,yy1,RIGHT);
       rgu_put_body_string(39,mm1,RIGHT);
       rgu_put_body_string(39,dd1,RIGHT);
    }else {
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);}
    rgu_put_body_string(39,Iofficer,LEFT); 
    rgu_put_body(39);
    rgu_put_body_string(40,Nofficer,LEFT); 
    rgu_put_body(40);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
 /* ibody[20]=0;
  * rgu_put_body_string(21,ibody,LEFT);
  * rgu_put_body(21);
  * ibrand[8]=0;
  * rgu_put_body_string(22,ibrand,LEFT);
  * rgu_put_body(22);
  * rgu_put_body(23);
  *if(apayment[0]==0 || apayment[0]==' ')
  *  split_ch(aassured,tmpbuf,tmpbuf1,28);
  *else 
  *  split_ch(apayment,tmpbuf,tmpbuf1,28);
  *tmpbuf1[28]=0;
  *       rgu_put_body_string(26,tmpbuf,LEFT);
  *       rgu_put_body(26);
  *       rgu_put_body_string(27,tmpbuf1,LEFT);
  *       rgu_put_body(27);
  *       itel[11]=0;
  *       rgu_put_body_string(28,itel,LEFT);
  *       rgu_put_body(28);
  *       rgu_put_body_string(29,irelative_ply,LEFT);
  *       rgu_put_body_string(29,rel_ins_type ,LEFT);
  *       rgu_put_body(29);


  * printf("===mpremium[%d]\n",mpremium);  
  * sprintf(Iofficer_tmp,"%s%s%s","(",rtrim(Iofficer),")");
  * rgu_put_body_string(31,Iofficer_tmp,RIGHT);
  * rgu_put_body(31);

  * for(i=32;i<35;i++) rgu_put_body(1);  

  * strcpy(tmpbuf,cm_from_infdate_100(pdate));
  * cm_split_ymd_100(tmpbuf,yy,mm,dd);
  * rgu_put_body_string(34,yy,LEFT);
  * rgu_put_body_string(34,mm,LEFT);
  * rgu_put_body_string(34,dd,LEFT);
  * rgu_put_body(34);
  *for(i=0 ; i < 6 ; i++)
    rgu_put_body(1);*/

   max_count+=32;
 

}
/******************************************************************************/
void put_body2()
{
  char n1[140],n2[140],n3[140],n4[140];
  char yy[10],mm[10],dd[10];
  int i;
  n1[0]=0;n2[0]=0;n3[0]=0;n4[0]=0;
  split_ch(allins1,ins1,n2,18);
  split_ch(n2,ins2,ins3,19);
  split_ch(allins2,ins12,n2,18);
  split_ch(n2,ins22,ins32,18);

    rgu_put_body(1);
    rgu_put_body(1);
  split_ch(nassured,n1,n2,36);
  n2[36]=0;
  split_ch(nassured1,n3,n4,36);
  n4[36]=0;
         rgu_put_body_string(53,n1,LEFT);
         rgu_put_body_string(53,n3,LEFT);
         rgu_put_body(53);
         rgu_put_body_string(54,n2,LEFT);
         rgu_put_body_string(54,n4,LEFT);
         rgu_put_body(54);

         rgu_put_body_string(55,ncar_abbr,LEFT);
         rgu_put_body_string(55,nbrand_abbr,LEFT);
         rgu_put_body_string(55,ncar_abbr1,LEFT);
         rgu_put_body_string(55,nbrand_abbr1,LEFT);
         rgu_put_body(55);
    rgu_put_body(1);
iengine[21]=ibody[22]=0;
ilicense[10]=0;
itag[CA_TAG_NUM-1]=0;
iengine1[21]=ibody1[22]=0;
ilicense1[10]=0;
itag1[CA_TAG_NUM-1]=0;

         if(strlen(trim(iengine)) == 0) strcpy(iengine,ibody);
         rgu_put_body_string(57,iengine,LEFT);
         
         /**rgu_put_body_string(57,ilicense,LEFT); **/
         
         /* car9901133 �Y��ܤ��L���P,�h���P���M���ť� */
         if (flag_tag[0] == '1') rgu_put_body_string(57," ",LEFT);
         else rgu_put_body_string(57,itag,LEFT);
         
         if(strlen(trim(iengine1)) == 0) strcpy(iengine1,ibody1);
         rgu_put_body_string(57,iengine1,LEFT);
         /**rgu_put_body_string(57,ilicense1,LEFT);**/
         
         /* car9901133 �Y��ܤ��L���P,�h���P���M���ť� */
         if (flag_tag[0] == '1') rgu_put_body_string(57," ",LEFT);
         else rgu_put_body_string(57,itag1,LEFT);
         rgu_put_body(57);


         rgu_put_body_string(58,ins1,LEFT);
         rgu_put_body_string(58,ins12,LEFT);
         rgu_put_body(58);
  
         rgu_put_body_string(59,ipolicy,LEFT);
         rgu_put_body_string(59,ins2,LEFT);
         rgu_put_body_string(59,ipolicy1,LEFT);
         rgu_put_body_string(59,ins22,LEFT);
         rgu_put_body(59);
         rgu_put_body_string(60,rel_card1,LEFT);
         rgu_put_body_string(60,ins3,LEFT);
         rgu_put_body_string(60,rel_card2,LEFT);
         rgu_put_body_string(60,ins32,LEFT);
    rgu_put_body(60);

     strcpy(n1,cm_from_infdate_100(dply_begin));
     cm_split_ymd_100(n1,yy,mm,dd);
         rgu_put_body_string(61,yy,LEFT);
         rgu_put_body_string(61,mm,LEFT);
         rgu_put_body_string(61,dd,LEFT);
     strcpy(n1,cm_from_infdate_100(dply_begin1));
     cm_split_ymd_100(n1,yy,mm,dd);
         rgu_put_body_string(61,yy,LEFT);
         rgu_put_body_string(61,mm,LEFT);
         rgu_put_body_string(61,dd,LEFT);
         rgu_put_body(61);
  
  
     strcpy(n1,cm_from_infdate_100(dply_end));
     cm_split_ymd_100(n1,yy,mm,dd);
         rgu_put_body_string(62,yy,LEFT);
         rgu_put_body_string(62,mm,LEFT);
         rgu_put_body_string(62,dd,LEFT);
     strcpy(n1,cm_from_infdate_100(dply_end1));
     cm_split_ymd_100(n1,yy,mm,dd);
         rgu_put_body_string(62,yy,LEFT);
         rgu_put_body_string(62,mm,LEFT);
         rgu_put_body_string(62,dd,LEFT);
         rgu_put_body(62);
  for(i=63;i<65;i++)
    rgu_put_body(1);
         rgu_put_body_string(65,icard,LEFT);
         icard1[18]=0;
         rgu_put_body_string(65,icard1,LEFT);
         rgu_put_body(65);
max_count+=19;
}
/******************************************************************************/
void put_body3()
{
  char tmpbuf[150],tmpbuf1[150];
  char yy[10],mm[10],dd[10];
  int i;

rate_date=cm_ymd_cdate(cm_from_infdate_100(dply_begin));

  if ((ipolicy[0]!='\0')&&(ipolicy[0]!=' ')){
     if ((itag[0]!='\0')&&(itag[0]!=' '))
       { strcpy(Inumber, itag); }
     else
       { strcpy(Inumber, iengine); }
/**  crystal-removed at 87/01/19 
     ca_accident_record(DBName,Inumber ,rate_date,"1", qdmg,qlia, mdmg,mlia,
                        &qdmg_acc,&qlia_acc, &pdmg_acc,&plia_acc,fyear);
**/
  }else{
     strcpy(fyear,"NNN");
  }

  for(i=0;i<3;i++){
    printf("ca_accident[%d]:[%c]%ld\n",i,fyear[i],qlia[i]);
    if (fyear[i]=='Y')
       strcpy(s_qlia[i],itoa(qlia[i]));
    else
       strcpy(s_qlia[i]," ");
  }
/*
* for(i=0;i<6;i++)
*   rgu_put_body(1);
*/
  if (icard[1] <= 'Z' && icard[1] >='A')   /* �O�N�� */
  {
    tmpbuf[0]=0;
    strcpy(tmpbuf1,icard);
  }else{
    strncpy(tmpbuf,icard,2); tmpbuf[2]=0;
    strcpy(tmpbuf1,"17");
    strcat(tmpbuf1,&icard);
  }
    /*     rgu_put_body_string(10,tmpbuf,RIGHT); */
  rgu_put_body_string(10,tmpbuf1,RIGHT);
  rgu_put_body_string(22,tmpbuf1,RIGHT);
  rgu_put_body_string(28,tmpbuf1,RIGHT);
  rgu_put_body(10);
  rgu_put_body(1);
  split_ch(nassured,tmpbuf,tmpbuf1,30);
  if (*fsex == '1')
       strcat(tmpbuf," ����");
  else if (*fsex == '2')
       strcat(tmpbuf," �p�j");
  tmpbuf[30]=0;
  tmpbuf1[30]=0;
  rgu_put_body_string(12,tmpbuf,LEFT);
  rgu_put_body_string(30,tmpbuf,LEFT);

  rgu_put_body(12);

  split_ch(aassured,tmpbuf,tmpbuf1,30);
  if (strlen(tmpbuf1)==0) {
      rgu_put_body_string(13," ",LEFT);
   /*   rgu_put_body_string(13,mY,LEFT);  */
      rgu_put_body_string(14,tmpbuf,LEFT);
  }
  else {
      rgu_put_body_string(13,tmpbuf,LEFT);
    /*  rgu_put_body_string(13,mY,LEFT);  */
      rgu_put_body_string(14,tmpbuf1,LEFT);
  }
  if (strncmp(ilicense," ",1)==0)
      if (strncmp(iassured,"AAAAAAAAAA",10)!=0)
          strcpy(ilicense,iassured);
  for(i=0;i<10;i++) 
  {
   strncpy(tmpbuf,ilicense+i,1);
   tmpbuf[1]='\0';
   rgu_put_body_string(14,tmpbuf,LEFT);
  }
  rgu_put_body_string(14,trim(bcard1),LEFT);
  rgu_put_body(13);
  rgu_put_body(14);
  rgu_put_body(1);
  rgu_put_body_string(16,ncar_abbr,LEFT);
  rgu_put_body_string(16,nbrand_abbr,LEFT);
  ncar_abbr[8]=0;
  rgu_put_body_string(34,ncar_abbr,LEFT);

  strcpy(yy,iissue_ym);
  yy[3]=0;
  rgu_put_body_string(16,yy,LEFT);
  rgu_put_body_string(34,yy,LEFT);
  if ((itag[0]!='\0' && itag[0]!=' ') && (flag_tag[0] != '1'))
     {
       itag[CA_TAG_NUM]=0;
       rgu_put_body_string(16,itag,LEFT);
       rgu_put_body_string(34,itag,LEFT);
     }
  else
     {
       iengine[21]=ibody[22]=0;
       
printf("iengine[%s]\n",iengine);
       if(strlen(trim(iengine)) == 0) strcpy(iengine,ibody);
       rgu_put_body_string(16,iengine,LEFT);
       rgu_put_body_string(34," ",LEFT);
     }
  rgu_put_body(16);
  if(dply_begin[0]==0)
  {
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
  }else{
       strcpy(tmpbuf,cm_from_infdate_100(dply_begin));
       cm_split_ymd_100(tmpbuf,yy,mm,dd);
       rgu_put_body_string(17,yy,LEFT);
       rgu_put_body_string(31,yy,LEFT);
       rgu_put_body_string(17,mm,LEFT);
       rgu_put_body_string(31,mm,LEFT);
       rgu_put_body_string(17,dd,LEFT);
       rgu_put_body_string(31,dd,LEFT);
  }
  if(qperiod==0)
   {
       rgu_put_body_string(17,qperiod,LEFT);
       rgu_put_body_string(31,qperiod,LEFT);
   } else
   {
       strcpy(tmpbuf,itoa(qperiod));
       rgu_put_body_string(17,tmpbuf,LEFT);
       rgu_put_body_string(31,tmpbuf,LEFT);
   }

  if (ibirth[0]==0) {
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }else{
         cm_split_ymd_100(ibirth,yy,mm,dd);
         rgu_put_body_string(17,yy,LEFT);
         rgu_put_body_string(17,mm,LEFT);
         rgu_put_body_string(17,dd,LEFT);
  }

  if(fsex[0]=='1'){
         rgu_put_body_string(17,"v",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }else if(fsex[0]=='2'){
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"v",LEFT);
  }else{
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }
  if (fmarriage[0]=='1'){
         rgu_put_body_string(17,"v",LEFT);
         rgu_put_body_string(17,"",LEFT);
  } else if (fmarriage[0]=='2') {
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"v",LEFT);
  }else{
         rgu_put_body_string(17,"",LEFT); 
         rgu_put_body_string(17,"",LEFT);
  }
  rgu_put_body_string(17,fcomp_class_last,LEFT);
  rgu_put_body(17);
  if(dply_end[0]==0)
    {
        rgu_put_body_string(18,"",LEFT);
        rgu_put_body_string(18,"",LEFT);
        rgu_put_body_string(18,"",LEFT);
    } else
    {
        strcpy(tmpbuf,cm_from_infdate_100(dply_end));
        cm_split_ymd_100(tmpbuf,yy,mm,dd);
        rgu_put_body_string(18,yy,LEFT);
        rgu_put_body_string(18,mm,LEFT);
        rgu_put_body_string(18,dd,LEFT);
        rgu_put_body_string(32,yy,LEFT);
        rgu_put_body_string(32,mm,LEFT);
        rgu_put_body_string(32,dd,LEFT);
    }
   if (fpt == 'P')
     {
          sprintf(cqpt,"%5.0f",qpt); 
          printf("cqpt---->%s\n",cqpt);
          rgu_put_body_string(18, cqpt, LEFT);    
     }
   else if ( fpt == 'T')
     {
          rgu_put_body_string(18,"",RIGHT);
          sprintf(cqpt,"%5.1f", qpt);
          rgu_put_body_string(18,cqpt,LEFT);
     } 
   else
      {
          rgu_put_body_string(18,"",RIGHT);
          rgu_put_body_string(18,"",LEFT);
      }
   rgu_put_body(18);
    if(mpremium==0)
    {
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
    }else{
       /* refmtamt => convert a money representation from long to currency format */
       strcpy(mpremium_buf,refmtamt(mpremium,MILLIONTH));
       rgu_put_body_string(26,rtrim(mpremium_buf),LEFT);
       tmp_prem=mpremium/10000;
       other_prem=mpremium%10000;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       tmp_prem=other_prem/1000;
       other_prem=other_prem%1000;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       tmp_prem=other_prem/100;
       other_prem=other_prem%100;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       tmp_prem=other_prem/10;
       other_prem=other_prem%10;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       num_to_chinese(ch_amt,other_prem);
       if (other_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);
    }
    rgu_put_body(19);
    rgu_put_body(1);
    rgu_put_body(1);
    if (strlen(irelative_ply)==0)
        rgu_put_body_string(22," ",LEFT);
    else {
        sprintf(tmpbuf,"17%s",trim(irelative_ply));
        rgu_put_body_string(22,tmpbuf,LEFT);
    }
    rgu_put_body(22);
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(23,yy1,RIGHT);
       rgu_put_body_string(23,mm1,RIGHT);
       rgu_put_body_string(23,dd1,RIGHT);
    }else {
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(23," ",RIGHT);}

    rgu_put_body(23);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(26);
    rgu_put_body(1);
    rgu_put_body(28);
    rgu_put_body(1);
    rgu_put_body(30);
    rgu_put_body(31);
    rgu_put_body(32);
    rgu_put_body(1);
    rgu_put_body(34);
    rgu_put_body(1);
    rgu_put_body_string(36,nbrand_abbr,LEFT);
    if (qcylinder == 0 && strncmp(icar_type,"35",2) != 0)
    { rgu_put_body_string(36,"",LEFT);}
    else
    { strcpy(tmpbuf,itoa(qcylinder));
      rgu_put_body_string(36,tmpbuf,LEFT);
    }
    strncpy(tmpbuf,iengine,15);
    if(strlen(trim(iengine)) >15) 
     {
      strncpy(iengine_ext,iengine+15,5);
      iengine_ext[5]= '\0';
     }
    else
      iengine_ext[0] = '\0';
    tmpbuf[15] = '\0'; 
    printf ("iaaa[%s]\n",tmpbuf);
    rgu_put_body_string(36,tmpbuf,LEFT);
    rgu_put_body_string(36,fcomp_class,LEFT);
    rgu_put_body(36);
    rgu_put_body_string(37,iengine_ext,LEFT);
    rgu_put_body(37);
    rgu_put_body(1);
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(39,yy1,RIGHT);
       rgu_put_body_string(39,mm1,RIGHT);
       rgu_put_body_string(39,dd1,RIGHT);
    }else {
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);}
    rgu_put_body(39);
    rgu_put_body_string(40,Iofficer,LEFT); 
    rgu_put_body(40);
    rgu_put_body_string(41,Nofficer,LEFT); 
    rgu_put_body(41);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
 /* ibody[22]=0;
  * rgu_put_body_string(21,ibody,LEFT);
  * rgu_put_body(21);
  * ibrand[8]=0;
  * rgu_put_body_string(22,ibrand,LEFT);
  * rgu_put_body(22);
  * rgu_put_body(23);
  *if(apayment[0]==0 || apayment[0]==' ')
  *  split_ch(aassured,tmpbuf,tmpbuf1,28);
  *else 
  *  split_ch(apayment,tmpbuf,tmpbuf1,28);
  *tmpbuf1[28]=0;
  *       rgu_put_body_string(26,tmpbuf,LEFT);
  *       rgu_put_body(26);
  *       rgu_put_body_string(27,tmpbuf1,LEFT);
  *       rgu_put_body(27);
  *       itel[11]=0;
  *       rgu_put_body_string(28,itel,LEFT);
  *       rgu_put_body(28);
  *       rgu_put_body_string(29,irelative_ply,LEFT);
  *       rgu_put_body_string(29,rel_ins_type ,LEFT);
  *       rgu_put_body(29);


  * printf("===mpremium[%d]\n",mpremium);  
  * sprintf(Iofficer_tmp,"%s%s%s","(",rtrim(Iofficer),")");
  * rgu_put_body_string(31,Iofficer_tmp,RIGHT);
  * rgu_put_body(31);

  * for(i=32;i<35;i++) rgu_put_body(1);  

  * strcpy(tmpbuf,cm_from_infdate_100(pdate));
  * cm_split_ymd_100(tmpbuf,yy,mm,dd);
  * rgu_put_body_string(34,yy,LEFT);
  * rgu_put_body_string(34,mm,LEFT);
  * rgu_put_body_string(34,dd,LEFT);
  * rgu_put_body(34);
  *for(i=0 ; i < 6 ; i++)
    rgu_put_body(1);*/

   max_count+=32;
}


void put_body4()
{
  char tmpbuf[150],tmpbuf1[150];
  char yy[10],mm[10],dd[10];
  int i;

rate_date=cm_ymd_cdate(cm_from_infdate_100(dply_begin));


  if ((ipolicy[0]!='\0')&&(ipolicy[0]!=' ')){
     if ((itag[0]!='\0')&&(itag[0]!=' '))
       { strcpy(Inumber, itag); }
     else
       { strcpy(Inumber, iengine); }
/**  crystal-removed at 87/01/19 
     ca_accident_record(DBName,Inumber ,rate_date,"1", qdmg,qlia, mdmg,mlia,
                        &qdmg_acc,&qlia_acc, &pdmg_acc,&plia_acc,fyear);
**/
  }else{
     strcpy(fyear,"NNN");
  }

  for(i=0;i<3;i++){
    printf("ca_accident[%d]:[%c]%ld\n",i,fyear[i],qlia[i]);
    if (fyear[i]=='Y')
       strcpy(s_qlia[i],itoa(qlia[i]));
    else
       strcpy(s_qlia[i]," ");
  }
   if(mpremium==0)  /* �O�O */
    {
          rgu_put_body_string(22,"",RIGHT);
          rgu_put_body_string(22,"",RIGHT);
          rgu_put_body_string(22,"",RIGHT);
          rgu_put_body_string(22,"",RIGHT);
          rgu_put_body_string(22,"",RIGHT);
    }else{
       /* refmtamt() convert a money representation from long to currency format */
       /* MILLIONTH  means  $###,###,### */
       strcpy(mpremium_buf,refmtamt(mpremium,MILLIONTH));
       rgu_put_body_string(26,rtrim(mpremium_buf),LEFT);
       tmp_prem=mpremium/10000;
       other_prem=mpremium%10000;
       num_to_chinese(ch_amt,tmp_prem); /* �N���ԧB�Ʀr �ন ����j�g�Ʀr */
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(22,ch_amt,RIGHT);

       tmp_prem=other_prem/1000;
       other_prem=other_prem%1000;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(22,ch_amt,RIGHT);

       tmp_prem=other_prem/100;
       other_prem=other_prem%100;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(22,ch_amt,RIGHT);

       tmp_prem=other_prem/10;
       other_prem=other_prem%10;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(22,ch_amt,RIGHT);

       num_to_chinese(ch_amt,other_prem);
       if (other_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(22,ch_amt,RIGHT);
    }


/* ���q�{�������D�A�� icard[1] �i��P�_���N�q
    �B�e���T�A�̫e���@�w�n�����q�N�X '17'
   if (icard[1] <= 'Z' && icard[1] >='A')   
    {
    tmpbuf[0]=0;
    strcpy(tmpbuf1,icard);
  }else{
    strncpy(tmpbuf,icard,2); tmpbuf[2]=0;
    strcpy(tmpbuf1,"17");
    strcat(tmpbuf1,&icard);
  }  */
  
  strcpy(tmpbuf1,"17");
  strcat(tmpbuf1,&icard);
  rgu_put_body_string(22,tmpbuf1,RIGHT); 
  
  if ( strncmp ( print_card ,"1",1) == 0 )
  {
    rgu_put_body_string(10,tmpbuf1,RIGHT);
    rgu_put_body_string(28,tmpbuf1,RIGHT);
  }
  rgu_put_body(10);
  rgu_put_body(1);
  split_ch(nassured,tmpbuf,tmpbuf1,30);
  if (*fsex == '1')
       strcat(tmpbuf," ����");
  else if (*fsex == '2')
       strcat(tmpbuf," �p�j");
  tmpbuf[30]=0;
  tmpbuf1[30]=0;
  rgu_put_body_string(12,tmpbuf,LEFT);
  rgu_put_body_string(30,tmpbuf,LEFT);

  rgu_put_body(12);

  split_ch(aassured,tmpbuf,tmpbuf1,30);
  if (strlen(tmpbuf1)==0) {
      rgu_put_body_string(13," ",LEFT);

      rgu_put_body_string(14,tmpbuf,LEFT);
  }
  else {
      rgu_put_body_string(13,tmpbuf,LEFT);

      rgu_put_body_string(14,tmpbuf1,LEFT);
  }
  if (strncmp(ilicense," ",1)==0)
      if (strncmp(iassured,"AAAAAAAAAA",10)!=0)
          strcpy(ilicense,iassured);
  for(i=0;i<10;i++) 
  {
   strncpy(tmpbuf,ilicense+i,1);
   tmpbuf[1]='\0';
   rgu_put_body_string(14,tmpbuf,LEFT);
  }
  rgu_put_body_string(14,trim(bcard1),LEFT);
  rgu_put_body(13);
  rgu_put_body(14);
  rgu_put_body(1);
  rgu_put_body_string(16,ncar_abbr,LEFT);
  rgu_put_body_string(16,nbrand_abbr,LEFT);
  ncar_abbr[8]=0;
  rgu_put_body_string(34,ncar_abbr,LEFT);

  strcpy(yy,iissue_ym);
  yy[3]=0;
  rgu_put_body_string(16,yy,LEFT);
  rgu_put_body_string(34,yy,LEFT);
  printf(" ---- itag = [%s]\n",itag);
  
  /* car9901133 �Y��ܤ��L���P,�h���P���M���ť� */
  if ((itag[0]!='\0' && itag[0]!=' ') && (flag_tag[0] != '1'))
     {
       itag[CA_TAG_NUM]=0;
       rgu_put_body_string(16,itag,LEFT);
       rgu_put_body_string(34,itag,LEFT);
     }
  else if (flag_tag[0] != '1')
     {
       iengine[21]=ibody[22]=0;
       if(strlen(trim(iengine)) == 0) strcpy(iengine,ibody);
       rgu_put_body_string(16,iengine,LEFT);
       rgu_put_body_string(34," ",LEFT);
     }
   else
     {
     	 rgu_put_body_string(16," ",LEFT);
       rgu_put_body_string(34," ",LEFT);  
     }
  rgu_put_body(16);
  if(dply_begin[0]==0)
  {
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
  }else{
       strcpy(tmpbuf,cm_from_infdate_100(dply_begin));
       cm_split_ymd_100(tmpbuf,yy,mm,dd);
       rgu_put_body_string(17,yy,LEFT);
       rgu_put_body_string(31,yy,LEFT);
       rgu_put_body_string(17,mm,LEFT);
       rgu_put_body_string(31,mm,LEFT);
       rgu_put_body_string(17,dd,LEFT);
       rgu_put_body_string(31,dd,LEFT);
  }
  if(qperiod==0)
   {
       rgu_put_body_string(17,qperiod,LEFT);
       rgu_put_body_string(31,qperiod,LEFT);
   } else
   {
       strcpy(tmpbuf,itoa(qperiod));
       rgu_put_body_string(17,tmpbuf,LEFT);
       rgu_put_body_string(31,tmpbuf,LEFT);
   }

  if (ibirth[0]==0) {
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }else{
         cm_split_ymd_100(ibirth,yy,mm,dd);
         rgu_put_body_string(17,yy,LEFT);
         rgu_put_body_string(17,mm,LEFT);
         rgu_put_body_string(17,dd,LEFT);
  }

  if(fsex[0]=='1'){
         rgu_put_body_string(17,"v",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }else if(fsex[0]=='2'){
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"v",LEFT);
  }else{
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }
  if (fmarriage[0]=='1'){
         rgu_put_body_string(17,"v",LEFT);
         rgu_put_body_string(17,"",LEFT);
  } else if (fmarriage[0]=='2') {
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"v",LEFT);
  }else{
         rgu_put_body_string(17,"",LEFT); 
         rgu_put_body_string(17,"",LEFT);
  }
  rgu_put_body_string(17,fcomp_class_last,LEFT);
  rgu_put_body(17);
  if(dply_end[0]==0)
    {
        rgu_put_body_string(18,"",LEFT);
        rgu_put_body_string(18,"",LEFT);
        rgu_put_body_string(18,"",LEFT);
    } else
    {
        strcpy(tmpbuf,cm_from_infdate_100(dply_end));
        cm_split_ymd_100(tmpbuf,yy,mm,dd);
        rgu_put_body_string(18,yy,LEFT);
        rgu_put_body_string(18,mm,LEFT);
        rgu_put_body_string(18,dd,LEFT);
        rgu_put_body_string(32,yy,LEFT);
        rgu_put_body_string(32,mm,LEFT);
        rgu_put_body_string(32,dd,LEFT);
    }
   if (fpt == 'P')
     {
          sprintf(cqpt,"%5.0f",qpt); 
          printf("cqpt---->%s\n",cqpt);
          rgu_put_body_string(18, cqpt, LEFT);    
     }
   else if ( fpt == 'T')
     {
          rgu_put_body_string(18,"",RIGHT);
          sprintf(cqpt,"%5.1f", qpt);
          rgu_put_body_string(18,cqpt,LEFT);
     } 
   else
      {
          rgu_put_body_string(18,"",RIGHT);
          rgu_put_body_string(18,"",LEFT);
      }
    rgu_put_body(18);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    if (strlen(irelative_ply)==0)
        rgu_put_body_string(22," ",LEFT);
    else {
        sprintf(tmpbuf,"17%s",trim(irelative_ply));
        rgu_put_body_string(22,tmpbuf,LEFT);
    }
    rgu_put_body(22);
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(23,yy1,RIGHT);
       rgu_put_body_string(23,mm1,RIGHT);
       rgu_put_body_string(23,dd1,RIGHT);
    }else {
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(23," ",RIGHT);}

    rgu_put_body(23);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(26);
    rgu_put_body(1);
    rgu_put_body(28);
    rgu_put_body(1);
    rgu_put_body(30);
    rgu_put_body(31);
    rgu_put_body(32);
    rgu_put_body(1);
    rgu_put_body(34);
    rgu_put_body(1);
    rgu_put_body_string(36,nbrand_abbr,LEFT);
    if (qcylinder == 0 && strncmp(icar_type,"35",2) != 0)
    { rgu_put_body_string(36,"",LEFT);}
    else
    { strcpy(tmpbuf,itoa(qcylinder));
      rgu_put_body_string(36,tmpbuf,LEFT);
    }
    strncpy(tmpbuf,iengine,15);
    if(strlen(trim(iengine)) >15) 
     {
      strncpy(iengine_ext,iengine+15,5);
      iengine_ext[5]= '\0';
     }
    else
      iengine_ext[0] = '\0';
    tmpbuf[15] = '\0'; 
    printf ("iaaa[%s]\n",tmpbuf);
    rgu_put_body_string(36,tmpbuf,LEFT);
    rgu_put_body_string(36,fcomp_class,LEFT);
    rgu_put_body(36);
    rgu_put_body_string(37,iengine_ext,LEFT);
    rgu_put_body(37);
    rgu_put_body(1);
    
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(39,yy1,RIGHT);
       rgu_put_body_string(39,mm1,RIGHT);
       rgu_put_body_string(39,dd1,RIGHT);
    }else {
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);}
    rgu_put_body(39);

    rgu_put_body_string(40,Iofficer,LEFT); 
    rgu_put_body(40);
    rgu_put_body_string(41,Nofficer,LEFT); 
    rgu_put_body(41);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1); 
    rgu_put_body(1);

   max_count+=32;
}

void put_body5() /* �@����ª�, print_frm = '4', car2033.fmt          */
 {
  char tmpbuf[150],tmpbuf1[150];
  char yy[10],mm[10],dd[10];
  int i;

rate_date=cm_ymd_cdate(cm_from_infdate_100(dply_begin));

  if ((ipolicy[0]!='\0')&&(ipolicy[0]!=' ')){
     if ((itag[0]!='\0')&&(itag[0]!=' '))
       { strcpy(Inumber, itag); }
     else
       { strcpy(Inumber, iengine); }

  }else{
     strcpy(fyear,"NNN");
  }

  for(i=0;i<3;i++){
    printf("ca_accident[%d]:[%c]%ld\n",i,fyear[i],qlia[i]);
    if (fyear[i]=='Y')
       strcpy(s_qlia[i],itoa(qlia[i]));
    else
       strcpy(s_qlia[i]," ");
  }
   if(mpremium==0)  /* �O�O */
    {
          rgu_put_body_string(21,"",RIGHT);
          rgu_put_body_string(21,"",RIGHT);
          rgu_put_body_string(21,"",RIGHT);
          rgu_put_body_string(21,"",RIGHT);
          rgu_put_body_string(21,"",RIGHT);
          rgu_put_body_string(58,"",RIGHT);
          rgu_put_body_string(58,"",RIGHT);
          rgu_put_body_string(58,"",RIGHT);
          rgu_put_body_string(58,"",RIGHT);
          rgu_put_body_string(58,"",RIGHT);
    }else{
       /* refmtamt() convert a money representation from long to currency format */
       /* MILLIONTH  means  $###,###,### */
       strcpy(mpremium_buf,refmtamt(mpremium,MILLIONTH));
       rgu_put_body_string(26,rtrim(mpremium_buf),LEFT);
       tmp_prem=mpremium/10000;
       other_prem=mpremium%10000;
       num_to_chinese(ch_amt,tmp_prem); /* �N���ԧB�Ʀr �ন ����j�g�Ʀr */
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(21,ch_amt,RIGHT);
       rgu_put_body_string(58,ch_amt,RIGHT);
       
       tmp_prem=other_prem/1000;
       other_prem=other_prem%1000;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(21,ch_amt,RIGHT);
       rgu_put_body_string(58,ch_amt,RIGHT);
       
       tmp_prem=other_prem/100;
       other_prem=other_prem%100;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(21,ch_amt,RIGHT);
       rgu_put_body_string(58,ch_amt,RIGHT);
       
       tmp_prem=other_prem/10;
       other_prem=other_prem%10;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(21,ch_amt,RIGHT);
       rgu_put_body_string(58,ch_amt,RIGHT);
       
       num_to_chinese(ch_amt,other_prem);
       if (other_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(21,ch_amt,RIGHT);
       rgu_put_body_string(58,ch_amt,RIGHT);
    }


/* ���q�{�������D�A�� icard[1] �i��P�_���N�q
    �B�e���T�A�̫e���@�w�n�����q�N�X '17'
   if (icard[1] <= 'Z' && icard[1] >='A')   
    {
    tmpbuf[0]=0;
    strcpy(tmpbuf1,icard);
  }else{
    strncpy(tmpbuf,icard,2); tmpbuf[2]=0;
    strcpy(tmpbuf1,"17");
    strcat(tmpbuf1,&icard);
  }  */
  
  strcpy(tmpbuf1,"17");
  strcat(tmpbuf1,&icard);
/*  rgu_put_body_string(22,tmpbuf1,RIGHT);  */
  
  if ( strncmp ( print_card ,"1",1) == 0 )
  {
    rgu_put_body_string(10,tmpbuf1,RIGHT);
    rgu_put_body_string(27,tmpbuf1,RIGHT);
    rgu_put_body_string(42,tmpbuf1,RIGHT);
    rgu_put_body_string(47,tmpbuf1,RIGHT);
    rgu_put_body_string(66,tmpbuf1,RIGHT);    
  }
  rgu_put_body(10);
  rgu_put_body(1);
  split_ch(nassured,tmpbuf,tmpbuf1,30);
  if (*fsex == '1')
       strcat(tmpbuf," ����");
  else if (*fsex == '2')
       strcat(tmpbuf," �p�j");
  tmpbuf[30]=0;
  tmpbuf1[30]=0;
  rgu_put_body_string(12,tmpbuf,LEFT);
  rgu_put_body_string(12,trim(bcard1),LEFT);
  rgu_put_body_string(30,tmpbuf,LEFT);
  rgu_put_body_string(48,tmpbuf,LEFT);
  rgu_put_body_string(68,tmpbuf,LEFT);
  rgu_put_body(12);

  split_ch(aassured,tmpbuf,tmpbuf1,30);
  if (strlen(tmpbuf1)==0) {
      rgu_put_body_string(13," ",LEFT);
      rgu_put_body_string(49," ",LEFT);
      
      rgu_put_body_string(14,tmpbuf,LEFT);
      rgu_put_body_string(50,tmpbuf,LEFT);
  }
  else {
      rgu_put_body_string(13,tmpbuf,LEFT);
      rgu_put_body_string(49,tmpbuf,LEFT);
      
      rgu_put_body_string(14,tmpbuf1,LEFT);
      rgu_put_body_string(50,tmpbuf1,LEFT);
  }
  if (strncmp(ilicense," ",1)==0)
      if (strncmp(iassured,"AAAAAAAAAA",10)!=0)
          strcpy(ilicense,iassured);
  for(i=0;i<10;i++) 
  {
   strncpy(tmpbuf,ilicense+i,1);
   tmpbuf[1]='\0';
   rgu_put_body_string(14,tmpbuf,LEFT);
  }
  rgu_put_body_string(14,trim(irelative_ply),LEFT);
  rgu_put_body(13);
  rgu_put_body(14);
  rgu_put_body(1);  
  rgu_put_body_string(36,substring(nbrand_abbr,1,8),LEFT);
  rgu_put_body_string(74,substring(nbrand_abbr,1,8),LEFT);
  rgu_put_body_string(34,ncar_abbr,LEFT);
  rgu_put_body_string(72,ncar_abbr,LEFT);
  nbrand_abbr[8]=0;
  ncar_abbr[6]=0;
  rgu_put_body_string(16,ncar_abbr,LEFT);
  rgu_put_body_string(16,nbrand_abbr,LEFT);
  rgu_put_body_string(52,ncar_abbr,LEFT);
  rgu_put_body_string(52,nbrand_abbr,LEFT);
  
  strcpy(yy,iissue_ym);
  yy[3]=0;
  rgu_put_body_string(16,yy,LEFT);
  rgu_put_body_string(34,yy,LEFT);
  rgu_put_body_string(52,yy,LEFT);
  rgu_put_body_string(72,yy,LEFT);
  printf(" ---- itag = [%s]\n",itag);
  
  /* car9901133 �Y��ܤ��L���P,�h���P���M���ť� */
  if ((itag[0]!='\0' && itag[0]!=' ') && (flag_tag[0] != '1'))
     {
       itag[CA_TAG_NUM]=0;
       rgu_put_body_string(16,itag,LEFT);
       rgu_put_body_string(34,itag,LEFT);
       rgu_put_body_string(52,itag,LEFT);
       rgu_put_body_string(72,itag,LEFT);
     }
  else if (flag_tag[0] != '1')
     {
       iengine[21]=0;
       printf("iengine[%s]\n",iengine);
       rgu_put_body_string(16,iengine,LEFT);
       rgu_put_body_string(34," ",LEFT);
       rgu_put_body_string(52,iengine,LEFT);
       rgu_put_body_string(72," ",LEFT);
     }
  else
     {
     	 rgu_put_body_string(16," ",LEFT);
       rgu_put_body_string(34," ",LEFT);
       rgu_put_body_string(52," ",LEFT);
       rgu_put_body_string(72," ",LEFT);
     }
  rgu_put_body(16);
  if(dply_begin[0]==0)
  {
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
  }else{
       strcpy(tmpbuf,cm_from_infdate_100(dply_begin));
       cm_split_ymd_100(tmpbuf,yy,mm,dd);
       rgu_put_body_string(17,yy,LEFT);
       rgu_put_body_string(31,yy,LEFT);
       rgu_put_body_string(53,yy,LEFT);
       rgu_put_body_string(69,yy,LEFT);
       rgu_put_body_string(17,mm,LEFT);
       rgu_put_body_string(31,mm,LEFT);
       rgu_put_body_string(53,mm,LEFT);
       rgu_put_body_string(69,mm,LEFT);
       rgu_put_body_string(17,dd,LEFT);
       rgu_put_body_string(31,dd,LEFT);
       rgu_put_body_string(53,dd,LEFT);
       rgu_put_body_string(69,dd,LEFT);
  }
  if(qperiod==0)
   {
       rgu_put_body_string(17,qperiod,LEFT);
       rgu_put_body_string(31,qperiod,LEFT);
       rgu_put_body_string(53,qperiod,LEFT);
       rgu_put_body_string(69,qperiod,LEFT);
   } else
   {
       strcpy(tmpbuf,itoa(qperiod));
       rgu_put_body_string(17,tmpbuf,LEFT);
       rgu_put_body_string(31,tmpbuf,LEFT);
       rgu_put_body_string(53,tmpbuf,LEFT);
       rgu_put_body_string(69,tmpbuf,LEFT);
   }

  if (ibirth[0]==0) {
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }else{
         cm_split_ymd_100(ibirth,yy,mm,dd);
         rgu_put_body_string(17,yy,LEFT);
         rgu_put_body_string(17,mm,LEFT);
         rgu_put_body_string(17,dd,LEFT);
  }

  if(fsex[0]=='1'){
         rgu_put_body_string(17,"v",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }else if(fsex[0]=='2'){
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"v",LEFT);
  }else{
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }
  if (fmarriage[0]=='1'){
         rgu_put_body_string(17,"v",LEFT);
         rgu_put_body_string(17,"",LEFT);
  } else if (fmarriage[0]=='2') {
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"v",LEFT);
  }else{
         rgu_put_body_string(17,"",LEFT); 
         rgu_put_body_string(17,"",LEFT);
  }
  rgu_put_body_string(17,fcomp_class_last,LEFT);
  rgu_put_body(17);
  if(dply_end[0]==0)
    {
        rgu_put_body_string(18,"",LEFT);
        rgu_put_body_string(18,"",LEFT);
        rgu_put_body_string(18,"",LEFT);
    } else
    {
        strcpy(tmpbuf,cm_from_infdate_100(dply_end));
        cm_split_ymd_100(tmpbuf,yy,mm,dd);
        rgu_put_body_string(18,yy,LEFT);
        rgu_put_body_string(18,mm,LEFT);
        rgu_put_body_string(18,dd,LEFT);
        rgu_put_body_string(32,yy,LEFT);
        rgu_put_body_string(32,mm,LEFT);
        rgu_put_body_string(32,dd,LEFT);
        rgu_put_body_string(54,yy,LEFT);
        rgu_put_body_string(54,mm,LEFT);
        rgu_put_body_string(54,dd,LEFT);
        rgu_put_body_string(70,yy,LEFT);
        rgu_put_body_string(70,mm,LEFT);
        rgu_put_body_string(70,dd,LEFT);
    }
   if (fpt == 'P')
     {
          sprintf(cqpt,"%5.0f",qpt); 
          printf("cqpt---->%s\n",cqpt);
          rgu_put_body_string(18, cqpt, LEFT);    
     }
   else if ( fpt == 'T')
     {
          rgu_put_body_string(18,"",RIGHT);
          sprintf(cqpt,"%5.1f", qpt);
          rgu_put_body_string(18,cqpt,LEFT);
     } 
   else
      {
          rgu_put_body_string(18,"",RIGHT);
          rgu_put_body_string(18,"",LEFT);
      }
    rgu_put_body(18);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(21);
/*    if (strlen(irelative_ply)==0)
        rgu_put_body_string(22," ",LEFT);
    else {
        sprintf(tmpbuf,"17%s",trim(irelative_ply));
        rgu_put_body_string(22,tmpbuf,LEFT);
    }  */
    rgu_put_body_string(22,irelative_card,LEFT);
    rgu_put_body(22);
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(23,yy1,RIGHT);
       rgu_put_body_string(23,mm1,RIGHT);
       rgu_put_body_string(23,dd1,RIGHT);
       rgu_put_body_string(59,yy1,RIGHT);
       rgu_put_body_string(59,mm1,RIGHT);
       rgu_put_body_string(59,dd1,RIGHT);
    }else {
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(59," ",RIGHT);
       rgu_put_body_string(59," ",RIGHT);
       rgu_put_body_string(59," ",RIGHT);}

    rgu_put_body(23);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(26);
    rgu_put_body(1);
    rgu_put_body(27);
    rgu_put_body(1);
    rgu_put_body(30);
    rgu_put_body(31);
    rgu_put_body(32);
    rgu_put_body(1);
    rgu_put_body(34);
    rgu_put_body(1);
    if (qcylinder == 0 && strncmp(icar_type,"35",2) != 0)
    { rgu_put_body_string(36,"",LEFT);
       rgu_put_body_string(74,"",LEFT); }
    else
    { strcpy(tmpbuf,itoa(qcylinder));
      rgu_put_body_string(36,tmpbuf,LEFT);
      rgu_put_body_string(74,tmpbuf,LEFT);
    }
    strncpy(tmpbuf,iengine,16);
    if(strlen(trim(iengine)) >16) 
     {
      strncpy(iengine_ext,iengine+16,4);
      iengine_ext[4]= '\0';
     }
    else
      iengine_ext[0] = '\0';
    tmpbuf[16] = '\0'; 
    printf ("iaaa[%s]\n",tmpbuf);
    rgu_put_body_string(36,tmpbuf,LEFT);
    rgu_put_body_string(74,tmpbuf,LEFT);
    rgu_put_body_string(36,fcomp_class,LEFT);
    rgu_put_body_string(74,fcomp_class,LEFT);
    rgu_put_body(36);
    rgu_put_body_string(37,iengine_ext,RIGHT);
    rgu_put_body_string(75,iengine_ext,RIGHT);
    rgu_put_body(37);
    rgu_put_body(1);
    
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(39,yy1,RIGHT);
       rgu_put_body_string(39,mm1,RIGHT);
       rgu_put_body_string(39,dd1,RIGHT);
       rgu_put_body_string(77,yy1,RIGHT);
       rgu_put_body_string(77,mm1,RIGHT);
       rgu_put_body_string(77,dd1,RIGHT);
    }else {
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(77," ",RIGHT);
       rgu_put_body_string(77," ",RIGHT);
       rgu_put_body_string(77," ",RIGHT);}
    rgu_put_body(39);

    rgu_put_body_string(40,Iofficer,LEFT); 
    rgu_put_body(40);
    rgu_put_body_string(41,Nofficer,LEFT); 
    rgu_put_body(41);
    rgu_put_body(42);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1); 
    rgu_put_body(47);
    rgu_put_body(1);
    rgu_put_body(48);
    rgu_put_body(49);
    rgu_put_body(50);
    rgu_put_body(1);
    rgu_put_body(52);
    rgu_put_body(53);
    rgu_put_body(54);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(58);
    rgu_put_body(1);
    rgu_put_body(59);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(66);
    rgu_put_body(1);
    rgu_put_body(68);
    rgu_put_body(69);
    rgu_put_body(70);
    rgu_put_body(1);
    rgu_put_body(72);
    rgu_put_body(1);
    rgu_put_body(74);
    rgu_put_body(75);
    rgu_put_body(1);
    rgu_put_body(77);   
    rgu_put_body_string(78,Nleader,1);
    rgu_put_body(78);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    
   max_count+=64;
}

void put_body6() /*�O�N��s��, print_frm='3', car2034.fmt */ 
{
  char tmpbuf[150],tmpbuf1[150];
  char yy[10],mm[10],dd[10];
  int i;

rate_date=cm_ymd_cdate(cm_from_infdate_100(dply_begin));


  if ((ipolicy[0]!='\0')&&(ipolicy[0]!=' ')){
     if ((itag[0]!='\0')&&(itag[0]!=' '))
       { strcpy(Inumber, itag); }
     else
       { strcpy(Inumber, iengine); }
/**  crystal-removed at 87/01/19 
     ca_accident_record(DBName,Inumber ,rate_date,"1", qdmg,qlia, mdmg,mlia,
                        &qdmg_acc,&qlia_acc, &pdmg_acc,&plia_acc,fyear);
**/
  }else{
     strcpy(fyear,"NNN");
  }

  for(i=0;i<3;i++){
    printf("ca_accident[%d]:[%c]%ld\n",i,fyear[i],qlia[i]);
    if (fyear[i]=='Y')
       strcpy(s_qlia[i],itoa(qlia[i]));
    else
       strcpy(s_qlia[i]," ");
  }
   if(mpremium==0)  /* �O�O */
    {
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
          rgu_put_body_string(19,"",RIGHT);
    }else{
       /* refmtamt() convert a money representation from long to currency format */
       /* MILLIONTH  means  $###,###,### */
       strcpy(mpremium_buf,refmtamt(mpremium,MILLIONTH));
       rgu_put_body_string(27,rtrim(mpremium_buf),LEFT);
       tmp_prem=mpremium/10000;
       other_prem=mpremium%10000;
       num_to_chinese(ch_amt,tmp_prem); /* �N���ԧB�Ʀr �ন ����j�g�Ʀr */
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       tmp_prem=other_prem/1000;
       other_prem=other_prem%1000;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       tmp_prem=other_prem/100;
       other_prem=other_prem%100;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       tmp_prem=other_prem/10;
       other_prem=other_prem%10;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);

       num_to_chinese(ch_amt,other_prem);
       if (other_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(19,ch_amt,RIGHT);
    }


/* ���q�{�������D�A�� icard[1] �i��P�_���N�q
    �B�e���T�A�̫e���@�w�n�����q�N�X '17'
   if (icard[1] <= 'Z' && icard[1] >='A')   
    {
    tmpbuf[0]=0;
    strcpy(tmpbuf1,icard);
  }else{
    strncpy(tmpbuf,icard,2); tmpbuf[2]=0;
    strcpy(tmpbuf1,"17");
    strcat(tmpbuf1,&icard);
  }  */
  
  strcpy(tmpbuf1,"17");
  strcat(tmpbuf1,&icard);
/*  rgu_put_body_string(19,tmpbuf1,RIGHT);  */
  
  if ( strncmp ( print_card ,"1",1) == 0 )
  {
    rgu_put_body_string(10,tmpbuf1,RIGHT);
    rgu_put_body_string(28,tmpbuf1,RIGHT);
  }
  rgu_put_body(10);
  rgu_put_body(1);
  rgu_put_body(1);  /* �s�W�@�� */
  split_ch(nassured,tmpbuf,tmpbuf1,30);
  if (*fsex == '1')
       strcat(tmpbuf," ����");
  else if (*fsex == '2')
       strcat(tmpbuf," �p�j");
  tmpbuf[30]=0;
  tmpbuf1[30]=0;
  rgu_put_body_string(12,tmpbuf,LEFT);
  rgu_put_body_string(30,tmpbuf,LEFT);

  rgu_put_body(12);

  split_ch(aassured,tmpbuf,tmpbuf1,36);
  if (strlen(tmpbuf1)==0) {
      rgu_put_body_string(13," ",LEFT);

      rgu_put_body_string(14,tmpbuf,LEFT);
  }
  else {
      rgu_put_body_string(13,tmpbuf,LEFT);

      rgu_put_body_string(14,tmpbuf1,LEFT);
  }

  if (strncmp(ilicense," ",1)==0)
      if (strncmp(iassured,"AAAAAAAAAA",10)!=0)
          strcpy(ilicense,iassured);
  for(i=0;i<10;i++) 
  {
   strncpy(tmpbuf,ilicense+i,1);
   tmpbuf[1]='\0';
   rgu_put_body_string(15,tmpbuf,LEFT);
  }
  rgu_put_body_string(13,trim(bcard1),LEFT);
  rgu_put_body(13);
  rgu_put_body(14);
  rgu_put_body(15);
  rgu_put_body_string(34,ncar_abbr,LEFT);
  rgu_put_body_string(36,nbrand_abbr,RIGHT);
  ncar_abbr[6]=0;
  nbrand_abbr[4]=0;
  rgu_put_body_string(16,nbrand_abbr,LEFT);
  rgu_put_body_string(16,ncar_abbr,LEFT);

  strcpy(yy,iissue_ym);
  yy[3]=0;
  rgu_put_body_string(16,yy,LEFT);
  rgu_put_body_string(34,yy,LEFT);
  printf(" ---- itag = [%s]\n",itag);
  
  /* car9901133 �Y��ܤ��L���P,�h���P���M���ť� */
  if ((itag[0]!='\0' && itag[0]!=' ') && (flag_tag[0] != '1'))
     {
       itag[CA_TAG_NUM]=0;
       rgu_put_body_string(16,itag,LEFT);
       rgu_put_body_string(34,itag,LEFT);
     }
  else
     {
       rgu_put_body_string(16," ",LEFT);
       rgu_put_body_string(34," ",LEFT);
     }

  iengine[21]=0;
  printf("iengine[%s]\n",iengine);
  rgu_put_body_string(16,iengine,LEFT);
  rgu_put_body(16);
  if(dply_begin[0]==0)
  {
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(31,"",LEFT);
       rgu_put_body_string(31,"",LEFT);
       rgu_put_body_string(31,"",LEFT);
  }else{
       strcpy(tmpbuf,cm_from_infdate_100(dply_begin));
       cm_split_ymd_100(tmpbuf,yy,mm,dd);
       rgu_put_body_string(17,yy,LEFT);
       rgu_put_body_string(31,yy,LEFT);
       rgu_put_body_string(17,mm,LEFT);
       rgu_put_body_string(31,mm,LEFT);
       rgu_put_body_string(17,dd,LEFT);
       rgu_put_body_string(31,dd,LEFT);
  }
  if(qperiod==0)
   {
       rgu_put_body_string(17,qperiod,LEFT);
       rgu_put_body_string(31,qperiod,LEFT);
   } else
   {
       strcpy(tmpbuf,itoa(qperiod));
       rgu_put_body_string(17,tmpbuf,LEFT);
       rgu_put_body_string(31,tmpbuf,LEFT);
   }
 if(dply_end[0]==0)
   {
       rgu_put_body_string(18,"",LEFT);
       rgu_put_body_string(18,"",LEFT);
       rgu_put_body_string(18,"",LEFT);
       rgu_put_body_string(32,"",LEFT);
       rgu_put_body_string(32,"",LEFT);
       rgu_put_body_string(32,"",LEFT);
   } else
   {
       strcpy(tmpbuf,cm_from_infdate_100(dply_end));
       cm_split_ymd_100(tmpbuf,yy,mm,dd);
       rgu_put_body_string(18,yy,LEFT);
       rgu_put_body_string(18,mm,LEFT);
       rgu_put_body_string(18,dd,LEFT);
       rgu_put_body_string(32,yy,LEFT);
       rgu_put_body_string(32,mm,LEFT);
       rgu_put_body_string(32,dd,LEFT);
   }
  if (ibirth[0]==0) {
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"",LEFT);
  }else{
         cm_split_ymd_100(ibirth,yy,mm,dd);
         rgu_put_body_string(18,yy,LEFT);
         rgu_put_body_string(18,mm,LEFT);
         rgu_put_body_string(18,dd,LEFT);
  }

  if(fsex[0]=='1'){
         rgu_put_body_string(18,"v",LEFT);
         rgu_put_body_string(18,"",LEFT);
  }else if(fsex[0]=='2'){
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"v",LEFT);
  }else{
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"",LEFT);
  }
  if (fmarriage[0]=='1'){
         rgu_put_body_string(18,"v",LEFT);
         rgu_put_body_string(18,"",LEFT);
  } else if (fmarriage[0]=='2') {
         rgu_put_body_string(18,"",LEFT);
         rgu_put_body_string(18,"v",LEFT);
  }else{
         rgu_put_body_string(18,"",LEFT); 
         rgu_put_body_string(18,"",LEFT);
  }
  rgu_put_body_string(18,fcomp_class_last,LEFT);
  rgu_put_body(17);

   if (fpt == 'P')
     {
          sprintf(cqpt,"%5.0f",qpt); 
          printf("cqpt---->%s\n",cqpt);
          rgu_put_body_string(20, cqpt, LEFT);    
     }
   else if ( fpt == 'T')
     {
          rgu_put_body_string(20,"",RIGHT);
          sprintf(cqpt,"%5.1f", qpt);
          rgu_put_body_string(20,cqpt,LEFT);
     } 
   else
      {
          rgu_put_body_string(20,"",RIGHT);
          rgu_put_body_string(20,"",LEFT);
      }
    if (strlen(irelative_ply)==0)
        rgu_put_body_string(19," ",LEFT);
    else {
        sprintf(tmpbuf,"17%s",trim(irelative_ply));
        rgu_put_body_string(19,tmpbuf,LEFT);
    } 
    if (strlen(irelative_card)==0)
        rgu_put_body_string(19," ",LEFT);
    else {
        rgu_put_body_string(19,irelative_card,LEFT);
    }
    rgu_put_body(18);
    rgu_put_body(19);
    rgu_put_body(20);
    rgu_put_body(1);
    rgu_put_body(1);
    
    if (strlen(trim(iscan_no))==0)
    	rgu_put_body_string(24," ",LEFT);
    else
    {
    	sprintf(tmpbuf,"���y�Ǹ�:%s",trim(iscan_no));
    	rgu_put_body_string(24,tmpbuf,LEFT);
    }
    
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(24,yy1,RIGHT);
       rgu_put_body_string(24,mm1,RIGHT);
       rgu_put_body_string(24,dd1,RIGHT);
    }else {
       rgu_put_body_string(24," ",RIGHT);
       rgu_put_body_string(24," ",RIGHT);
       rgu_put_body_string(24," ",RIGHT);}

    rgu_put_body(1);
    rgu_put_body(24);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(27);
    rgu_put_body(28);
    rgu_put_body(1);
    rgu_put_body(30);
    rgu_put_body(31);
    rgu_put_body(32);
    rgu_put_body(1);
    rgu_put_body(34);
    rgu_put_body(1);
    if (qcylinder == 0 && strncmp(icar_type,"35",2) != 0)
    { rgu_put_body_string(36,"",LEFT);}
    else
    { /*strcpy(tmpbuf,itoa(qcylinder));*/
      sprintf(tmpbuf, "%5.2f",qcylinder);
      rgu_put_body_string(36,tmpbuf,LEFT);
    }
    strncpy(tmpbuf,iengine,14);
    if(strlen(trim(iengine)) >14) 
     {
      strncpy(iengine_ext,iengine+14,6);
      iengine_ext[6]= '\0';
     }
    else
      iengine_ext[0] = '\0';
    tmpbuf[14] = '\0'; 
    printf ("iaaa[%s]\n",tmpbuf);
    rgu_put_body_string(36,tmpbuf,LEFT);
    rgu_put_body_string(36,fcomp_class,LEFT);
    rgu_put_body_string(36, iquery_num,LEFT);
    rgu_put_body(36);
    rgu_put_body_string(37,iengine_ext,LEFT);
    rgu_put_body(37);
    /*rgu_put_body(1);*/
    
    if (strlen(trim(irelative_ply))==0)
    	rgu_put_body_string(38," ",LEFT);
    else
    {
    	sprintf(tmpbuf,"���N�O�渹:%s",trim(irelative_ply));
    	rgu_put_body_string(38,tmpbuf,LEFT);
    }
    rgu_put_body(38);
    
    if (strlen(trim(iscan_no))==0)
    	rgu_put_body_string(39," ",LEFT);
    else
    {
    	sprintf(tmpbuf,"���y�Ǹ�:%s",trim(iscan_no));
    	rgu_put_body_string(39,tmpbuf,LEFT);
    }
    
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(39,yy1,RIGHT);
       rgu_put_body_string(39,mm1,RIGHT);
       rgu_put_body_string(39,dd1,RIGHT);
    }else {
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);}
    rgu_put_body(39);

    rgu_put_body_string(40,Iofficer,LEFT); 
    rgu_put_body(40);
    rgu_put_body_string(41,Nofficer,LEFT); 
    rgu_put_body(41);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1); 
 /*   rgu_put_body(1);   �R���@�� */

   max_count+=32;
}


void put_body7() /* �@���s��, print_frm = '5', car2035.fmt */
 {
  char tmpbuf[150],tmpbuf1[150];
  char tmpicard[21];
  char yy[10],mm[10],dd[10];
  int i;

  char nbrand_abbr_again[14];
printf("-------------- 2525 ------------------\n");
strcpy(tmpicard,"�Ҹ�:");
strcpy(icard,trim(icard));
strcat(tmpicard,icard);
printf("tmpicard==>[%s]\n",tmpicard);
rate_date=cm_ymd_cdate(cm_from_infdate_100(dply_begin));
  if ((ipolicy[0]!='\0')&&(ipolicy[0]!=' ')){
     if ((itag[0]!='\0')&&(itag[0]!=' '))
       { strcpy(Inumber, itag); }
     else
       { strcpy(Inumber, iengine); }

  }else{
     strcpy(fyear,"NNN");
  }

printf(" %%%%%%%%%%%%%%%%%%%^^^^^^^^^^^^^^^    \n");

  for(i=0;i<3;i++){
    printf("ca_accident[%d]:[%c]%ld\n",i,fyear[i],qlia[i]);
    if (fyear[i]=='Y')
       strcpy(s_qlia[i],itoa(qlia[i]));
    else
       strcpy(s_qlia[i]," ");
  }
   if(mpremium==0)  /* �O�O */
    {
          rgu_put_body_string(21,"",RIGHT);
          rgu_put_body_string(21,"",RIGHT);
          rgu_put_body_string(21,"",RIGHT);
          rgu_put_body_string(21,"",RIGHT);
          rgu_put_body_string(21,"",RIGHT);
          rgu_put_body_string(58,"",RIGHT);
          rgu_put_body_string(58,"",RIGHT);
          rgu_put_body_string(58,"",RIGHT);
          rgu_put_body_string(58,"",RIGHT);
          rgu_put_body_string(58,"",RIGHT);
         
    }else{
       /* refmtamt() convert a money representation from long to currency format */
       /* MILLIONTH  means  $###,###,### */
       strcpy(mpremium_buf,refmtamt(mpremium,MILLIONTH));
       rgu_put_body_string(26,rtrim(mpremium_buf),LEFT);
printf("XXXXXXXXXXXX mpremium_buf=[%s] \n",mpremium_buf);       
       tmp_prem=mpremium/10000;
       other_prem=mpremium%10000;
       num_to_chinese(ch_amt,tmp_prem); /* �N���ԧB�Ʀr �ন ����j�g�Ʀr */
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(21,ch_amt,RIGHT);
       rgu_put_body_string(58,ch_amt,RIGHT);
       
       tmp_prem=other_prem/1000;
       other_prem=other_prem%1000;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(21,ch_amt,RIGHT);
       rgu_put_body_string(58,ch_amt,RIGHT);
       
       tmp_prem=other_prem/100;
       other_prem=other_prem%100;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(21,ch_amt,RIGHT);
       rgu_put_body_string(58,ch_amt,RIGHT);
       
       tmp_prem=other_prem/10;
       other_prem=other_prem%10;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(21,ch_amt,RIGHT);
       rgu_put_body_string(58,ch_amt,RIGHT);
       
       num_to_chinese(ch_amt,other_prem);
       if (other_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(21,ch_amt,RIGHT);
       rgu_put_body_string(58,ch_amt,RIGHT);
       
    }
  

  if ( strncmp ( print_card ,"1",1) == 0 )
  {
    rgu_put_body_string(10,tmpbuf1,RIGHT);
    rgu_put_body_string(27,tmpbuf1,RIGHT);
    rgu_put_body_string(42,tmpbuf1,RIGHT);
    rgu_put_body_string(47,tmpbuf1,RIGHT);   
  }
  rgu_put_body(10);
  rgu_put_body(1);   
  rgu_put_body(1);     /* �s�W�@�� */
  
  split_ch(nassured,tmpbuf,tmpbuf1,30);
  if (*fsex == '1')
       strcat(tmpbuf," ����");
  else if (*fsex == '2')
       strcat(tmpbuf," �p�j");
  tmpbuf[30]=0;
  tmpbuf1[30]=0;
  rgu_put_body_string(12,tmpbuf,LEFT);
  printf("bcard1[%s]\n",bcard1);
  rgu_put_body_string(12,trim(bcard1),LEFT);
  rgu_put_body_string(30,tmpbuf,LEFT);
  rgu_put_body_string(48,tmpbuf,LEFT);
  rgu_put_body_string(66,tmpbuf,LEFT);
  rgu_put_body_string(68,tmpbuf,LEFT);
  rgu_put_body(12);

  split_ch(aassured,tmpbuf,tmpbuf1,30);
  if (strlen(tmpbuf1)==0) {
      rgu_put_body_string(13," ",LEFT);
      rgu_put_body_string(49," ",LEFT);
      rgu_put_body_string(67," ",LEFT);
      rgu_put_body_string(14,tmpbuf,LEFT);
      rgu_put_body_string(50,tmpbuf,LEFT);
  }
  else {
      rgu_put_body_string(13,tmpbuf,LEFT);
      rgu_put_body_string(49,tmpbuf,LEFT);
      rgu_put_body_string(67,tmpbuf,LEFT);
      rgu_put_body_string(14,tmpbuf1,LEFT);
      rgu_put_body_string(50,tmpbuf1,LEFT);
  }
  if (strncmp(ilicense," ",1)==0)
      if (strncmp(iassured,"AAAAAAAAAA",10)!=0)
          strcpy(ilicense,iassured);
  for(i=0;i<10;i++) 
  {
   strncpy(tmpbuf,ilicense+i,1);
   tmpbuf[1]='\0';
   rgu_put_body_string(14,tmpbuf,LEFT);
  }
  rgu_put_body_string(14,trim(irelative_ply),LEFT);
  rgu_put_body(13);
  rgu_put_body(14);
  rgu_put_body(1);  
  rgu_put_body_string(36,substring(nbrand_abbr,1,8),LEFT);
  rgu_put_body_string(74,substring(nbrand_abbr,1,8),LEFT);
  rgu_put_body_string(34,ncar_abbr,LEFT);
  rgu_put_body_string(72,ncar_abbr,LEFT);
  rgu_put_body_string(73,ncar_abbr,LEFT);
  strcpy(nbrand_abbr_again,substring(nbrand_abbr,1,8)); 
  
  nbrand_abbr[8]=0;
  ncar_abbr[6]=0;
  rgu_put_body_string(16,ncar_abbr,LEFT);
  rgu_put_body_string(16,nbrand_abbr,LEFT);
  rgu_put_body_string(52,ncar_abbr,LEFT);
  rgu_put_body_string(52,nbrand_abbr,LEFT);
  
  strcpy(yy,iissue_ym);
  yy[3]=0;
  rgu_put_body_string(16,yy,LEFT);
  rgu_put_body_string(34,yy,LEFT);
  rgu_put_body_string(52,yy,LEFT);
  rgu_put_body_string(72,yy,LEFT);
  rgu_put_body_string(73,yy,LEFT);
  printf(" ---- itag = [%s]\n",itag);
  
  /* car9901133 �Y��ܤ��L���P,�h���P���M���ť� */
  if ((itag[0]!='\0' && itag[0]!=' ') && (flag_tag[0] != '1'))
     {
       itag[CA_TAG_NUM]=0;
       rgu_put_body_string(16,itag,LEFT);
       rgu_put_body_string(34,itag,LEFT);
       rgu_put_body_string(52,itag,LEFT);
       rgu_put_body_string(72,itag,LEFT);
       rgu_put_body_string(73,itag,LEFT);
     }
  else if (flag_tag[0] != '1')
     {
       iengine[21]=0;
       printf("iengine[%s]\n",iengine);
       rgu_put_body_string(16,iengine,LEFT);
       rgu_put_body_string(34," ",LEFT);
       rgu_put_body_string(52,iengine,LEFT);
       rgu_put_body_string(72," ",LEFT);
       rgu_put_body_string(73," ",LEFT);
     }
  else
     {
     	 rgu_put_body_string(16," ",LEFT);
       rgu_put_body_string(34," ",LEFT);
       rgu_put_body_string(52," ",LEFT);
       rgu_put_body_string(72," ",LEFT);
       rgu_put_body_string(73," ",LEFT);
     }
  rgu_put_body(16);
 
  if(dply_begin[0]==0)
  {
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(17,"",LEFT);
       rgu_put_body_string(69,"",LEFT);
       rgu_put_body_string(69,"",LEFT);
       rgu_put_body_string(69,"",LEFT);
       
  }else{
       strcpy(tmpbuf,cm_from_infdate_100(dply_begin));
       cm_split_ymd_100(tmpbuf,yy,mm,dd);
       rgu_put_body_string(17,yy,LEFT);
       rgu_put_body_string(31,yy,LEFT);
       rgu_put_body_string(53,yy,LEFT);
       rgu_put_body_string(69,yy,LEFT);
       rgu_put_body_string(17,mm,LEFT);
       rgu_put_body_string(31,mm,LEFT);
       rgu_put_body_string(53,mm,LEFT);
       rgu_put_body_string(69,mm,LEFT);
       rgu_put_body_string(17,dd,LEFT);
       rgu_put_body_string(31,dd,LEFT);
       rgu_put_body_string(53,dd,LEFT);
       rgu_put_body_string(69,dd,LEFT);
     
  }
  if(qperiod==0)
   {
       rgu_put_body_string(17,qperiod,LEFT);
       rgu_put_body_string(31,qperiod,LEFT);
       rgu_put_body_string(53,qperiod,LEFT);
       rgu_put_body_string(69,qperiod,LEFT);
       
   } else
   {
       strcpy(tmpbuf,itoa(qperiod));
       rgu_put_body_string(17,tmpbuf,LEFT);
       rgu_put_body_string(31,tmpbuf,LEFT);
       rgu_put_body_string(53,tmpbuf,LEFT);
       rgu_put_body_string(69,tmpbuf,LEFT);
   }
   
   /* PRINT �O�I�үd�s��� (����)  */
   
    split_ch(aassured,tmpbuf,tmpbuf1,30);
  if (strlen(tmpbuf1)==0) {
      rgu_put_body_string(68,tmpbuf,LEFT);
      rgu_put_body_string(69," ",LEFT);
  }
  else {
      rgu_put_body_string(68,tmpbuf,LEFT);
      rgu_put_body_string(69,tmpbuf1,LEFT);
  }
      
/***************************************/


  if (ibirth[0]==0) {
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }else{
         cm_split_ymd_100(ibirth,yy,mm,dd);
         rgu_put_body_string(17,yy,LEFT);
         rgu_put_body_string(17,mm,LEFT);
         rgu_put_body_string(17,dd,LEFT);
  }

  if(fsex[0]=='1'){
         rgu_put_body_string(17,"v",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }else if(fsex[0]=='2'){
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"v",LEFT);
  }else{
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"",LEFT);
  }
  if (fmarriage[0]=='1'){
         rgu_put_body_string(17,"v",LEFT);
         rgu_put_body_string(17,"",LEFT);
  } else if (fmarriage[0]=='2') {
         rgu_put_body_string(17,"",LEFT);
         rgu_put_body_string(17,"v",LEFT);
  }else{
         rgu_put_body_string(17,"",LEFT); 
         rgu_put_body_string(17,"",LEFT);
  }
  rgu_put_body_string(17,fcomp_class_last,LEFT);
  rgu_put_body(17);
  if(dply_end[0]==0)
    {
        rgu_put_body_string(18,"",LEFT);
        rgu_put_body_string(18,"",LEFT);
        rgu_put_body_string(18,"",LEFT);
    } else
    {
        strcpy(tmpbuf,cm_from_infdate_100(dply_end));
        cm_split_ymd_100(tmpbuf,yy,mm,dd);
        rgu_put_body_string(18,yy,LEFT);
        rgu_put_body_string(18,mm,LEFT);
        rgu_put_body_string(18,dd,LEFT);
        rgu_put_body_string(32,yy,LEFT);
        rgu_put_body_string(32,mm,LEFT);
        rgu_put_body_string(32,dd,LEFT);
        rgu_put_body_string(54,yy,LEFT);
        rgu_put_body_string(54,mm,LEFT);
        rgu_put_body_string(54,dd,LEFT);
        rgu_put_body_string(70,yy,LEFT);
        rgu_put_body_string(70,mm,LEFT);
        rgu_put_body_string(70,dd,LEFT);
        rgu_put_body_string(71,yy,LEFT);
        rgu_put_body_string(71,mm,LEFT);
        rgu_put_body_string(71,dd,LEFT);
    }
   if (fpt == 'P')
     {
          sprintf(cqpt,"%5.0f",qpt); 
          printf("cqpt---->%s\n",cqpt);
          rgu_put_body_string(18, cqpt, LEFT);    
     }
   else if ( fpt == 'T')
     {
          rgu_put_body_string(18,"",RIGHT);
          sprintf(cqpt,"%5.1f", qpt);
          rgu_put_body_string(18,cqpt,LEFT);
     } 
   else
      {
          rgu_put_body_string(18,"",RIGHT);
          rgu_put_body_string(18,"",LEFT);
      }
    rgu_put_body(18);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(21);
    
    
     /* print �O�I�үd�s���(�O�I����) */
  if(dply_begin[0]==0)
  {
       rgu_put_body_string(70,"",LEFT);
       rgu_put_body_string(70,"",LEFT);
       rgu_put_body_string(70,"",LEFT);
       
  }else{
       strcpy(tmpbuf,cm_from_infdate_100(dply_begin));
       cm_split_ymd_100(tmpbuf,yy,mm,dd);
       rgu_put_body_string(70,yy,LEFT);
       rgu_put_body_string(70,mm,LEFT);
       rgu_put_body_string(70,dd,LEFT);
     
  }
  if(qperiod==0)
   {
       rgu_put_body_string(70,qperiod,LEFT);
       
   } else
   {
       strcpy(tmpbuf,itoa(qperiod));
       rgu_put_body_string(70,tmpbuf,LEFT);
   }
   /**************************************/ 
/*    if (strlen(irelative_ply)==0)
        rgu_put_body_string(22," ",LEFT);
    else {
        sprintf(tmpbuf,"17%s",trim(irelative_ply));
        rgu_put_body_string(22,tmpbuf,LEFT);
    }  */
    rgu_put_body_string(22,irelative_card,LEFT);
	rgu_put_body_string(22,trim(tmpicard),LEFT);
    rgu_put_body(22);
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(23,yy1,RIGHT);
       rgu_put_body_string(23,mm1,RIGHT);
       rgu_put_body_string(23,dd1,RIGHT);
       rgu_put_body_string(59,yy1,RIGHT);
       rgu_put_body_string(59,mm1,RIGHT);
       rgu_put_body_string(59,dd1,RIGHT);
    }else {
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(23," ",RIGHT);
       rgu_put_body_string(59," ",RIGHT);
       rgu_put_body_string(59," ",RIGHT);
       rgu_put_body_string(59," ",RIGHT);}

    rgu_put_body(23);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(26);
    rgu_put_body(1);
    rgu_put_body(27);
    rgu_put_body(1);
    rgu_put_body(30);
    rgu_put_body(31);
    rgu_put_body(32);
    rgu_put_body(1);
    rgu_put_body(34);
    rgu_put_body(1);
    
    if (qcylinder == 0 && strncmp(icar_type,"35",2) != 0)
    { rgu_put_body_string(36,"",LEFT);
      rgu_put_body_string(74,"",LEFT); }
    else
    { strcpy(tmpbuf,itoa(qcylinder));
      rgu_put_body_string(36,tmpbuf,LEFT);
      rgu_put_body_string(74,tmpbuf,LEFT);
    }
    strncpy(tmpbuf,iengine,16);
    
    
    if(strlen(trim(iengine)) >16) 
    {
      strncpy(iengine_ext,iengine+16,4);
      iengine_ext[4]= '\0';
    }
    else
      iengine_ext[0] = '\0';
     
      
    
    tmpbuf[16] = '\0'; 
    printf ("iaaa[%s]\n",tmpbuf);
    rgu_put_body_string(36,tmpbuf,LEFT);
    rgu_put_body_string(74,tmpbuf,LEFT);
    rgu_put_body_string(36,fcomp_class,LEFT);
    rgu_put_body_string(74,fcomp_class,LEFT);
    rgu_put_body_string(36,iquery_num,LEFT);
    rgu_put_body(36);
    rgu_put_body_string(37,iengine_ext,RIGHT);
    rgu_put_body_string(75,iengine_ext,RIGHT);
    rgu_put_body(37);
    rgu_put_body(1);
    
      /* print �O�I�үd�s���(�Q�O�I�T���G) */
    
    rgu_put_body_string(75,nbrand_abbr_again,LEFT); 
     if (qcylinder == 0 && strncmp(icar_type,"35",2) != 0)
    { 
      rgu_put_body_string(75,"",LEFT); }
    else
    { strcpy(tmpbuf,itoa(qcylinder));
      rgu_put_body_string(75,tmpbuf,LEFT);
    }
    strncpy(tmpbuf,iengine,16);
   if(strlen(trim(iengine)) >16) 
     {
      strncpy(iengine_ext,iengine+16,4);
      iengine_ext[4]= '\0';
      
     }
    else
    {
    iengine_ext[0] = '\0'; }
    
    tmpbuf[16] = '\0'; 
    rgu_put_body_string(75,tmpbuf,LEFT);
    rgu_put_body_string(75,fcomp_class,LEFT); 
    rgu_put_body_string(76,iengine_ext,RIGHT);
   
    rgu_put_body_string(78,ileader,LEFT);
	rgu_put_body_string(79,Nbranch,RIGHT);
	rgu_put_body_string(79,Nleader,LEFT);
	rgu_put_body_string(79,icorps,LEFT);
    
   /********************************************/
    
    
    if  (policy_y == 'Y')
    {
       rgu_put_body_string(39,yy1,RIGHT);
       rgu_put_body_string(39,mm1,RIGHT);
       rgu_put_body_string(39,dd1,RIGHT);
       rgu_put_body_string(77,yy1,RIGHT);
       rgu_put_body_string(77,mm1,RIGHT);
       rgu_put_body_string(77,dd1,RIGHT);
       rgu_put_body_string(78,yy1,RIGHT);
       rgu_put_body_string(78,mm1,RIGHT);
       rgu_put_body_string(78,dd1,RIGHT);
    }else {
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(39," ",RIGHT);
       rgu_put_body_string(77," ",RIGHT);
       rgu_put_body_string(77," ",RIGHT);
       rgu_put_body_string(77," ",RIGHT);
       rgu_put_body_string(78," ",RIGHT);
       rgu_put_body_string(78," ",RIGHT);
       rgu_put_body_string(78," ",RIGHT);}
       rgu_put_body(39);



  /* print �O�I�үd�s���(�O�I�O) */
  if(mpremium==0)  /* �O�O */
    {
       rgu_put_body_string(77,"",RIGHT);
       rgu_put_body_string(77,"",RIGHT);
       rgu_put_body_string(77,"",RIGHT);
       rgu_put_body_string(77,"",RIGHT);
       rgu_put_body_string(77,"",RIGHT);
    }else{
      
      /* strcpy(mpremium_buf,refmtamt(mpremium,MILLIONTH));
       rgu_put_body_string(26,rtrim(mpremium_buf),LEFT);  */
       tmp_prem=mpremium/10000;
       other_prem=mpremium%10000;
       num_to_chinese(ch_amt,tmp_prem); /* �N���ԧB�Ʀr �ন ����j�g�Ʀr */
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(77,ch_amt,RIGHT);
       
       tmp_prem=other_prem/1000;
       other_prem=other_prem%1000;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(77,ch_amt,RIGHT);
       
       tmp_prem=other_prem/100;
       other_prem=other_prem%100;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(77,ch_amt,RIGHT);
       
       tmp_prem=other_prem/10;
       other_prem=other_prem%10;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(77,ch_amt,RIGHT);
       
       num_to_chinese(ch_amt,other_prem);
       if (other_prem==0) strcpy(ch_amt,"�s");
       rgu_put_body_string(77,ch_amt,RIGHT);
       
    }
  
  /***********************************/
 
    rgu_put_body_string(40,Iofficer,LEFT); 
    rgu_put_body(40);
    rgu_put_body_string(41,Nofficer,LEFT); 
    rgu_put_body(41);
    rgu_put_body(42);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1); 
    rgu_put_body(47);
    rgu_put_body(1);
    rgu_put_body(48);
    rgu_put_body(49);
    rgu_put_body(50);
    rgu_put_body(1);
    rgu_put_body(52);
    rgu_put_body(53);
    rgu_put_body(54);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(58);
    rgu_put_body(1);
    rgu_put_body(59);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(1);
    rgu_put_body(66);
    rgu_put_body(67);
    rgu_put_body(68);
    rgu_put_body(69);
    rgu_put_body(70);
    rgu_put_body(71);
    rgu_put_body(72);
    rgu_put_body(73); 
    rgu_put_body(74);
    rgu_put_body(75);
    rgu_put_body(76);
    rgu_put_body(77);   
    rgu_put_body(1);
    rgu_put_body(78);
	rgu_put_body(79);
    rgu_put_body(1);
    rgu_put_body(1);
 /*   rgu_put_body(1);    */
 /*   rgu_put_body(1);  �R���@��   */
    
   max_count+=64;
   
   printf("--------------3100 ------------------\n");
}
/* -------------------------------------------------------------------------- */

void put_body8() /* �@���s��(102/09/01��), print_frm = '6', car2036.fmt */
{
		char tmpbuf[150],tmpbuf1[150];
		char tmpicard[21];
		char yy[10],mm[10],dd[10];
		int i;
		char yy_s[10],mm_s[10],dd_s[10], xqperiod[3];
		char yy_e[10],mm_e[10],dd_e[10], yy_o[10];
		char nbrand_abbr_again[14];
		char ch_amt01[40], ch_amt02[40],ch_amt03[40],ch_amt04[40],ch_amt05[40];
		printf("---------- put_body8 ------------------\n");
		strcpy(tmpicard,"�Ҹ�:");
		strcpy(icard,trim(icard));
		strcat(tmpicard,icard);
		printf("tmpicard==>[%s]\n",tmpicard);
		char  *ilocation;
                char  s_qcylinder_tail[4];
                char  s_qcylinder[9];
		
		rate_date=cm_ymd_cdate(cm_from_infdate_100(dply_begin));
		if ((ipolicy[0]!='\0')&&(ipolicy[0]!=' '))
		{
			if ((itag[0]!='\0')&&(itag[0]!=' '))
			{ strcpy(Inumber, itag); }
			else
			{ strcpy(Inumber, iengine); }
		}
		else
		{
			strcpy(fyear,"NNN");
		}

		for(i=0;i<3;i++)
		{
    		printf("ca_accident[%d]:[%c]%ld\n",i,fyear[i],qlia[i]);
    		if (fyear[i]=='Y')
       			strcpy(s_qlia[i],itoa(qlia[i]));
    		else
       			strcpy(s_qlia[i]," ");
  	}
    strcpy(ch_amt03," ");
		if(mpremium==0)  /* �O�O */
    {
				rgu_put_body_string(17,"",RIGHT);
				rgu_put_body_string(17,"",RIGHT);
				rgu_put_body_string(17,"",RIGHT);
				rgu_put_body_string(17,"",RIGHT);
				rgu_put_body_string(17,"",RIGHT);
				rgu_put_body_string(47,"",RIGHT);
				rgu_put_body_string(47,"",RIGHT);
				rgu_put_body_string(47,"",RIGHT);
				rgu_put_body_string(47,"",RIGHT);
				rgu_put_body_string(47,"",RIGHT);
				strcpy(ch_amt01," ");		/* �U */
				strcpy(ch_amt02," ");		/* �d */
				strcpy(ch_amt03," ");		/* �� */
				strcpy(ch_amt04," ");		/* �B */
				strcpy(ch_amt05," ");		/* �� */
				
		}
		else
		{
       strcpy(mpremium_buf,refmtamt(mpremium,MILLIONTH));
       /* rgu_put_body_string(26,rtrim(mpremium_buf),LEFT); */

       tmp_prem=mpremium/10000;
       other_prem=mpremium%10000;
       num_to_chinese(ch_amt,tmp_prem); /* �N���ԧB�Ʀr �ন ����j�g�Ʀr */
       
       if (tmp_prem==0) 
       	 strcpy(ch_amt,"�s");
       	 
       strcpy(ch_amt01, ch_amt);
       strcpy(ch_amt01, trim(ch_amt01));
       rgu_put_body_string(17,ch_amt,RIGHT);
       rgu_put_body_string(47,ch_amt,RIGHT);
       
       tmp_prem=other_prem/1000;
       other_prem=other_prem%1000;
       num_to_chinese(ch_amt,tmp_prem);

       if (tmp_prem==0) 
       		strcpy(ch_amt,"�s");

       strcpy(ch_amt02, ch_amt);
       strcpy(ch_amt02, trim(ch_amt02));
       rgu_put_body_string(17,ch_amt,RIGHT);
       rgu_put_body_string(47,ch_amt,RIGHT);

       tmp_prem=other_prem/100;
       other_prem=other_prem%100;
       num_to_chinese(ch_amt,tmp_prem);
       
       printf("3:ch_amt=[%s]\n",ch_amt);
       if (tmp_prem==0) 
       		strcpy(ch_amt,"�s");

			 strcpy(ch_amt03,ch_amt);
			 strcpy(ch_amt03, trim(ch_amt03));
       rgu_put_body_string(17,ch_amt,RIGHT);
       rgu_put_body_string(47,ch_amt,RIGHT);
       
       tmp_prem=other_prem/10;
       other_prem=other_prem%10;
       num_to_chinese(ch_amt,tmp_prem);
       if (tmp_prem==0) 
       		strcpy(ch_amt,"�s");

			 strcpy(ch_amt04,ch_amt);
			 strcpy(ch_amt04,trim(ch_amt04));
       rgu_put_body_string(17,ch_amt,RIGHT);
       rgu_put_body_string(47,ch_amt,RIGHT);
       
       num_to_chinese(ch_amt,other_prem);
       if (other_prem==0)
       		strcpy(ch_amt,"�s");

			 strcpy(ch_amt05,ch_amt);
			 strcpy(ch_amt05,trim(ch_amt05));
       rgu_put_body_string(17,ch_amt,RIGHT);
       rgu_put_body_string(47,ch_amt,RIGHT);
		}

		rgu_put_body(1);
		rgu_put_body(1);
		rgu_put_body(1);
		if (strncmp(mark,"1",1) == 0){ 
			rgu_put_body_string(64,icard,LEFT);
		  rgu_put_body(64);
		}
		else{
			rgu_put_body(1);}     /* �s�W�@�� */
    
  	/* �Ĥ@�p */
		split_ch(nassured,tmpbuf,tmpbuf1,30);
  	if (*fsex == '1')
    		strcat(tmpbuf," ����");
  	else if (*fsex == '2')
    		strcat(tmpbuf," �p�j");
		tmpbuf[30]=0;
		tmpbuf1[30]=0;
		rgu_put_body_string(11,tmpbuf,LEFT);	/* �Q�O�I�H */
		rgu_put_body_string(21,tmpbuf,LEFT);	/* �Q�O�I�H */
		rgu_put_body_string(41,tmpbuf,LEFT);	/* �Q�O�I�H */
	if (strncmp(mark,"1",1) == 0){ 
		rgu_put_body_string(51,icard,LEFT);
	}else{
		rgu_put_body_string(51," ",LEFT);} 
		rgu_put_body_string(51,tmpbuf,LEFT);	/* �Q�O�I�H */
		rgu_put_body_string(52,tmpbuf,LEFT);	/* �Q�O�I�H */
		rgu_put_body(11);
		
		split_ch(aassured,tmpbuf,tmpbuf1,30);
	if (strlen(tmpbuf1)==0) {
		rgu_put_body_string(12," ",LEFT);
		rgu_put_body_string(13,tmpbuf,LEFT);
		rgu_put_body_string(42," ",LEFT);
		rgu_put_body_string(43,tmpbuf,LEFT);
	}else{
  		rgu_put_body_string(12,tmpbuf,LEFT);
  		rgu_put_body_string(13,tmpbuf1,LEFT);
  		rgu_put_body_string(42,tmpbuf,LEFT);
  		rgu_put_body_string(43,tmpbuf1,LEFT);
	}
		rgu_put_body(12);	/* �q�T�B�Ĥ@�� */
		rgu_put_body(13); /* �q�T�B�ĤG�� */
		rgu_put_body(1);	/* �Ť@�� */
		rgu_put_body_string(14,substring(ncar_abbr,1,6),LEFT);		/* ���� */
		rgu_put_body_string(14,substring(nbrand_abbr,1,10),LEFT);	/* �t�P */

		
		strcpy(yy_o,iissue_ym);
		yy_o[3]=0;
		rgu_put_body_string(14,yy_o,LEFT);		/* �o�Ӧ~�� */

		
		/* car9901133 �Y��ܤ��L���P,�h���P���M���ť� */
		itag[CA_TAG_NUM]= '\0';
		iengine[21]='\0';
		
		if (strcmp(flag_tag, "1") == 0)
				strcpy(itag, " ");
			
		rgu_put_body_string(14,itag,LEFT);			/* ���P */
		rgu_put_body_string(14,iengine,LEFT);	/* ������ */

                	
		rgu_put_body_string(44,substring(ncar_abbr,1,6),LEFT);		/* ���� */
		rgu_put_body_string(44,substring(nbrand_abbr,1,10),LEFT);	/* �t�P */
		rgu_put_body_string(44,yy_o,LEFT);		/* �o�Ӧ~�� */		
		rgu_put_body_string(44,itag,LEFT);			/* ���P */			
		rgu_put_body_string(44,iengine,LEFT);	/* ������ */
				
		rgu_put_body(14);
		/* �O�I�_�� */
		if(dply_begin[0]==0)
		{		
		     rgu_put_body_string(15,"",LEFT);
		     rgu_put_body_string(15,"",LEFT);
		     rgu_put_body_string(15,"",LEFT);
		     rgu_put_body_string(22,"",LEFT);
		     rgu_put_body_string(22,"",LEFT);
		     rgu_put_body_string(22,"",LEFT);
		     rgu_put_body_string(22,trim(bcard1),LEFT);		/* �«O�I�Ҹ��X */
		     rgu_put_body_string(45,"",LEFT);
		     rgu_put_body_string(45,"",LEFT);
		     rgu_put_body_string(45,"",LEFT);
		}else{
		     strcpy(tmpbuf,cm_from_infdate_100(dply_begin));
		     cm_split_ymd_100(tmpbuf,yy,mm,dd);
		     rgu_put_body_string(15,yy,LEFT);
		     rgu_put_body_string(15,mm,LEFT);
		     rgu_put_body_string(15,dd,LEFT);
		     rgu_put_body_string(22,yy,LEFT);
		     rgu_put_body_string(22,mm,LEFT);
		     rgu_put_body_string(22,dd,LEFT);
		     rgu_put_body_string(22,trim(bcard1),LEFT);		/* �«O�I�Ҹ��X */
		     rgu_put_body_string(45,yy,LEFT);
		     rgu_put_body_string(45,mm,LEFT);
		     rgu_put_body_string(45,dd,LEFT);
		}
		
		/* �O�I���� */
		if(dply_end[0]==0)
		{
		    rgu_put_body_string(16,"",LEFT);
		    rgu_put_body_string(16,"",LEFT);
		    rgu_put_body_string(16,"",LEFT);
		    rgu_put_body_string(23,"",LEFT);
		    rgu_put_body_string(23,"",LEFT);
		    rgu_put_body_string(23,"",LEFT);
		    rgu_put_body_string(46,"",LEFT);
		    rgu_put_body_string(46,"",LEFT);
		    rgu_put_body_string(46,"",LEFT);
		}else{
		    strcpy(tmpbuf,cm_from_infdate_100(dply_end));
		    cm_split_ymd_100(tmpbuf,yy,mm,dd);
		    rgu_put_body_string(16,yy,LEFT);
		    rgu_put_body_string(16,mm,LEFT);
		    rgu_put_body_string(16,dd,LEFT);
		    rgu_put_body_string(23,yy,LEFT);
		    rgu_put_body_string(23,mm,LEFT);
		    rgu_put_body_string(23,dd,LEFT);
		    rgu_put_body_string(46,yy,LEFT);
		    rgu_put_body_string(46,mm,LEFT);
		    rgu_put_body_string(46,dd,LEFT);
		}
		
		/* �~�� */	
		if(qperiod==0)
		{
			rgu_put_body_string(16,qperiod,LEFT);
			rgu_put_body_string(23,qperiod,LEFT);
			rgu_put_body_string(46,qperiod,LEFT);
		} 
		else
		{
		     strcpy(tmpbuf,itoa(qperiod));
		     rgu_put_body_string(16,tmpbuf,LEFT);
		     rgu_put_body_string(23,tmpbuf,LEFT);
		     rgu_put_body_string(46,tmpbuf,LEFT);
		}
		rgu_put_body(15);
		rgu_put_body(16);
		rgu_put_body(1);
		rgu_put_body(1);
		rgu_put_body(17);		/* �O�O(����j�g) */
		rgu_put_body(1);
		rgu_put_body_string(60,ileader,RIGHT);	/* �޲z�H */
       	
       if (policy_y == 'Y')
       {
       rgu_put_body_string(18,yy1,RIGHT);
       rgu_put_body_string(18,mm1,RIGHT);
       rgu_put_body_string(18,dd1,RIGHT);
       rgu_put_body_string(27,yy1,RIGHT);
       rgu_put_body_string(27,mm1,RIGHT);
       rgu_put_body_string(27,dd1,RIGHT);
       rgu_put_body_string(48,yy1,RIGHT);
       rgu_put_body_string(48,mm1,RIGHT);
       rgu_put_body_string(48,dd1,RIGHT);
       rgu_put_body_string(59,yy1,RIGHT);
       rgu_put_body_string(59,mm1,RIGHT);
       rgu_put_body_string(59,dd1,RIGHT);
       rgu_put_body_string(60,yy1,RIGHT);
       rgu_put_body_string(60,mm1,RIGHT);
       rgu_put_body_string(60,dd1,RIGHT);
       }else {
       rgu_put_body_string(18," ",RIGHT);
       rgu_put_body_string(18," ",RIGHT);
       rgu_put_body_string(18," ",RIGHT);
       rgu_put_body_string(27," ",RIGHT);
       rgu_put_body_string(27," ",RIGHT);
       rgu_put_body_string(27," ",RIGHT);
       rgu_put_body_string(48," ",RIGHT);
       rgu_put_body_string(48," ",RIGHT);
       rgu_put_body_string(48," ",RIGHT);
       rgu_put_body_string(59," ",RIGHT);
       rgu_put_body_string(59," ",RIGHT);
       rgu_put_body_string(59," ",RIGHT);
       rgu_put_body_string(60," ",RIGHT);
       rgu_put_body_string(60," ",RIGHT);
       rgu_put_body_string(60," ",RIGHT);
       }
       
       rgu_put_body(18);   /* ñ��� */
       rgu_put_body(1);
       /* rgu_put_body(1); */
       
		/* �վ����T�d�ߧǸ����Ҹ���� modify by larry 103.07.21 (1030211007_C1) */
		rgu_put_body_string(62, iquery_num,LEFT);
		rgu_put_body_string(62,tmpicard,LEFT);	
		rgu_put_body(62);
		rgu_put_body(1);
		if (strncmp(mark,"1",1) == 0){ 
			rgu_put_body_string(65,icard,LEFT);
			rgu_put_body(65);
		}else{
			rgu_put_body(1);}		
		/* �O�I�үd�s���  */		
		rgu_put_body_string(21," ",LEFT);
		rgu_put_body(21);		/* �Q�O�I�H */
		rgu_put_body(1);		/* �Ť@�� */
		rgu_put_body(22);		/* �O�I�_�� & �«O�I�Ҹ��X */
		strcpy(irelative_ply, trim(irelative_ply));
		rgu_put_body_string(23,irelative_ply,LEFT);
		rgu_put_body(23);		/* �O�I���� */
		
		if (strncmp(ilicense," ",1)==0)
		{
		    if (strncmp(iassured,"AAAAAAAAAA",10)!=0)
			strcpy(ilicense,iassured);
		}
    
		for(i=0;i<10;i++) 
		{
			strncpy(tmpbuf,ilicense+i,1);
			tmpbuf[1]='\0';
			rgu_put_body_string(24,tmpbuf,LEFT);
		}
		rgu_put_body_string(24,trim(irelative_card),LEFT);		/* ���N�I�d�� */
		rgu_put_body(24);
		
		rgu_put_body_string(25,substring(ncar_abbr,1,8),LEFT);		/* ���� */
		rgu_put_body_string(55,substring(ncar_abbr,1,8),LEFT);		/* ���� */
		rgu_put_body_string(25,yy_o,LEFT);		/* �o�Ӧ~�� */
		rgu_put_body_string(55,yy_o,LEFT);		/* �o�Ӧ~�� */
		rgu_put_body_string(25,itag,LEFT);			/* ���P */
		rgu_put_body_string(55,itag,LEFT);			/* ���P */
		/* rgu_put_body_string(25,tmpicard,LEFT);		�j���Ҹ� */
		rgu_put_body_string(25,fcomp_class,LEFT);		/* �����Y�� */
		rgu_put_body(25);
		rgu_put_body_string(26,substring(nbrand_abbr,1,10),RIGHT);	/* �t�P */
		rgu_put_body_string(57,substring(nbrand_abbr,1,10),RIGHT);	/* �t�P */
		rgu_put_body_string(58,substring(nbrand_abbr,1,10),RIGHT);	/* �t�P */

		/* �Ʈ�q */
		if (qcylinder == 0 && strncmp(icar_type,"35",2) != 0)
		{ 
		    rgu_put_body_string(26,"",LEFT);		
		    rgu_put_body_string(57,"",LEFT);		
		    rgu_put_body_string(58,"",LEFT);		
		}
		else
		{
		    strcpy(s_qcylinder,"");
		    sprintf(s_qcylinder, "%5.2f",qcylinder);
                    strcpy(s_qcylinder,trim(s_qcylinder) );
                    /*�Ʈ�q���ƧP�_�A�Y�O .00 �h�ٲ������*/
    
                    strcpy(s_qcylinder_tail,"");
                    ilocation = strstr(s_qcylinder, ".");
                    printf("�Ʈ�q�p��[%d]\n",ilocation-s_qcylinder);
                    printf("�Ʈ�q�p��[%c%c%c]\n",s_qcylinder[ilocation-s_qcylinder],s_qcylinder[ilocation-s_qcylinder+1],s_qcylinder[ilocation-s_qcylinder+2]);
                    sprintf(s_qcylinder_tail,"%c%c%c",s_qcylinder[ilocation-s_qcylinder],s_qcylinder[ilocation-s_qcylinder+1],s_qcylinder[ilocation-s_qcylinder+2]);
                    printf("�Ʈ�q�p��[%s]\n",s_qcylinder_tail);
    
                    if(strcmp(s_qcylinder_tail,".00")==0)
                    {
                        s_qcylinder[ilocation-s_qcylinder]='\0';
                    }
                    printf("�Ʈ�q�p��[%s]\n",s_qcylinder);
                    
		    /*strcpy(tmpbuf,itoa(qcylinder));*/
		    rgu_put_body_string(26,s_qcylinder,RIGHT);
		    rgu_put_body_string(57,s_qcylinder,RIGHT);
		    rgu_put_body_string(58,s_qcylinder,RIGHT);
		}
		rgu_put_body_string(26,iengine,LEFT);				/* ������ */
		rgu_put_body_string(57,iengine,LEFT);				/* ������ */
		rgu_put_body_string(58,iengine,LEFT);				/* ������ */
		
		
		/* �ͤ� */
		if (ibirth[0]==0) 
		{
		    rgu_put_body_string(26,"",LEFT);
		    rgu_put_body_string(26,"",LEFT);
		    rgu_put_body_string(26,"",LEFT);
		}else{
		    cm_split_ymd_100(ibirth,yy,mm,dd);
		    rgu_put_body_string(26,yy,LEFT);
		    rgu_put_body_string(26,mm,LEFT);
		    rgu_put_body_string(26,dd,LEFT);
		}
		/* �ʧO */
		if(fsex[0]=='1'){
		    rgu_put_body_string(26,"v",LEFT);
		    rgu_put_body_string(26,"",LEFT);
		}else if(fsex[0]=='2'){
		    rgu_put_body_string(26,"",LEFT);
		    rgu_put_body_string(26,"v",LEFT);
		}else{
		    rgu_put_body_string(26,"",LEFT);
		    rgu_put_body_string(26,"",LEFT);
		}  
	  /* �B�� */
	  if (fmarriage[0]=='1'){
	      rgu_put_body_string(26,"v",LEFT);
	      rgu_put_body_string(26,"",LEFT);
	  } else if (fmarriage[0]=='2') {
	      rgu_put_body_string(26,"",LEFT);
	      rgu_put_body_string(26,"v",LEFT);
	  }else{
	      rgu_put_body_string(26,"",LEFT); 
	      rgu_put_body_string(26,"",LEFT);
	  }
	  rgu_put_body_string(26,fcomp_class_last,LEFT);		/* �W���Y�� */
	  rgu_put_body(26);
	  rgu_put_body(1);
	  rgu_put_body(27);		/* ñ��� */
	  /*rgu_put_body_string(62, iquery_num,LEFT);
	  rgu_put_body(62);*/
	  rgu_put_body(1);
	  
	  if (strlen(trim(iscan_no))==0)
	      rgu_put_body_string(30," ",LEFT);
	  else
	  {
	      sprintf(tmpbuf,"���y�Ǹ�:%s",trim(iscan_no));
	      rgu_put_body_string(30,tmpbuf,LEFT);
	  }
	  rgu_put_body(30);
	  
	  /*rgu_put_body(1);*/
	  rgu_put_body_string(31,ipolicy,LEFT);
	  rgu_put_body_string(31,Iofficer,LEFT); 
	  
	  rgu_put_body_string(31,isign,LEFT);/*�֫O�H��*/
	  rgu_put_body_string(31,ientry,LEFT);/*��J�H��*/
	  
	  rgu_put_body_string(31,Nofficer,LEFT); 
	  rgu_put_body(31);		/* �g��H */
	  
	  rgu_put_body(1);
	  rgu_put_body(1);
	  rgu_put_body(1);
	  if (strncmp(mark,"1",1) == 0)
	  { 
	  	rgu_put_body_string(66,icard,LEFT);
	  	rgu_put_body(66);
	  }
	  else
	  {
	  	rgu_put_body(1);
	  }   
		
		/* �ĤG�p ��Q�O�I�H���� */
		rgu_put_body(41);		/* �Q�O�I�H */
		rgu_put_body(42);		/* �q�T�B�Ĥ@�� */
		rgu_put_body(43);		/* �q�T�B�Ĥ@�� */
		rgu_put_body(1);
		rgu_put_body(44);		/* ����,�t�P,�o�Ӧ~��,���P,������ */
		rgu_put_body(45);		/* �O�I�_����,�~�� */
		rgu_put_body(46);		/* �O�I�_����,�~�� */
		rgu_put_body(1);
		rgu_put_body(1);
		rgu_put_body(1);		
		rgu_put_body(47);		/* �O�O */
                rgu_put_body(1);
		rgu_put_body(48);		/* ñ��� */
		
		
		/* �̤U���O�O�βĤT�p */
		
		rgu_put_body(1);
		rgu_put_body(1);
		if (strncmp(mark,"1",1) == 0){ 
			rgu_put_body_string(67,icard,LEFT);
		  rgu_put_body(67);
		}
		else{
			rgu_put_body(1);}
		rgu_put_body(51);		/* �k��Q�O�I�H */
		
		
		/* �O�I�_�� */
		if(dply_begin[0]==0)
		{		
		     strcpy(yy_s," ");
		     strcpy(mm_s," ");
		     strcpy(dd_s," ");
		}else{
		     strcpy(tmpbuf,cm_from_infdate_100(dply_begin));
		     cm_split_ymd_100(tmpbuf,yy_s,mm_s,dd_s);
		}
		
		/* �O�I���� */
		if(dply_end[0]==0)
		{
		    strcpy(yy_e," ");
		    strcpy(mm_e," ");
		    strcpy(dd_e," ");
		} else
		{
		    strcpy(tmpbuf,cm_from_infdate_100(dply_end));
		    cm_split_ymd_100(tmpbuf,yy_e,mm_e,dd_e);
		}

		/* �~�� */	
		strcpy(xqperiod,itoa(qperiod));
		
		split_ch(aassured,tmpbuf,tmpbuf1,30);
		if (strlen(tmpbuf1)==0) {
			rgu_put_body_string(52," ",LEFT);
			rgu_put_body_string(53,yy_s,LEFT);
			rgu_put_body_string(53,mm_s,LEFT);
			rgu_put_body_string(53,dd_s,LEFT);
			rgu_put_body_string(53,xqperiod,LEFT);
			rgu_put_body_string(53,tmpbuf,LEFT);
		}else{
		        rgu_put_body_string(52,tmpbuf,LEFT);
		        rgu_put_body_string(53,yy_s,LEFT);
	  		rgu_put_body_string(53,mm_s,LEFT);
	  		rgu_put_body_string(53,dd_s,LEFT);
	  		rgu_put_body_string(53,xqperiod,LEFT);
	  		rgu_put_body_string(53,tmpbuf1,LEFT);
		}
		rgu_put_body(52); /* �Q�O�I�H & �q�T�B�Ĥ@�� */
		rgu_put_body(53); /* �O�I�_�� & �q�T�B�ĤG�� */

		rgu_put_body_string(54,yy_e,LEFT);
		rgu_put_body_string(54,mm_e,LEFT);
		rgu_put_body_string(54,dd_e,LEFT);
		rgu_put_body_string(54,yy_s,LEFT);
		rgu_put_body_string(54,mm_s,LEFT);
		rgu_put_body_string(54,dd_s,LEFT);
		rgu_put_body_string(54,xqperiod,LEFT);	
			
		rgu_put_body_string(55,yy_e,LEFT);
		rgu_put_body_string(55,mm_e,LEFT);
		rgu_put_body_string(55,dd_e,LEFT);
		rgu_put_body(54); /* ���b�O�I���� & �k�b�O�I�_��B�O�� */
		rgu_put_body(55); /* ���b���ءB�o�Ӧ~��B���P & �k�b�O�I����*/
		/*rgu_put_body(1);*/
		rgu_put_body_string(56,fcomp_class,LEFT);	/* �����Y�� */
		rgu_put_body_string(56,ncar_abbr,LEFT);		/* ���� */
		rgu_put_body_string(56,yy_o,LEFT);		/* �o�Ӧ~�� */
		if (strcmp(flag_tag,"0") == 0)
		    rgu_put_body_string(56,itag,LEFT);		/* ���P */
		else
		    rgu_put_body_string(56," ",LEFT);		/* ���P */
 		rgu_put_body(56); /* �k�b���ءB�o�Ӧ~��B���P */
 		rgu_put_body_string(57,fcomp_class,LEFT);	/* �����Y�� */
 		rgu_put_body(57); /* ���b�t�P�B�Ʈ�q�B�������B�Y�� */
 		rgu_put_body(58); /* �k�b�t�P�B�Ʈ�q�B�������B�Y�� */
 		rgu_put_body(1); 
    
    printf("ch_amt01=[%s]\n",ch_amt01);
    printf("ch_amt02=[%s]\n",ch_amt02);
    printf("ch_amt03=[%s]\n",ch_amt03);
    printf("ch_amt04=[%s]\n",ch_amt04);
    printf("ch_amt05=[%s]\n",ch_amt05);
    
    rgu_put_body_string(59,ch_amt01,RIGHT);
    rgu_put_body_string(59,ch_amt02,RIGHT);
    rgu_put_body_string(59,ch_amt03,RIGHT);
    rgu_put_body_string(59,ch_amt04,RIGHT);
    rgu_put_body_string(59,ch_amt05,RIGHT);
    rgu_put_body(59); 
    rgu_put_body(1); 
    rgu_put_body(60); 
    rgu_put_body_string(61,Nbranch,RIGHT);
    rgu_put_body_string(61,Nleader,LEFT);
    rgu_put_body_string(61,icorps,LEFT);
    rgu_put_body(61);
    rgu_put_body(1); 
    rgu_put_body(1); 
    /* rgu_put_body(1);  */
    max_count+=72;
}
/* -------------------------------------------------------------------------- */
