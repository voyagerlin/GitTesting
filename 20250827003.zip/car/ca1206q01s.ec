/************************************************************************/
/*                                                                      */   
/*   program id   : ca1206q01s.ec                                        */
/*   program name : ���N�׽լd����                                      */
/*   date written : 2019/12/18                                          */
/*   author       : neo                                                 */
/************************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "safeclib.h"
/*--------------------------------------------------------------------*/
$char DBName[05],userid[11], ibranch_flag[2] , ibranch[8] , sfeedback[2] , score[2] , dbgn[9] , dend[9];

char  msgbuf[2048], sApHome[30], rpt_type[2], getfile[101];
char  v_sMsg[1024], outputf[N_FILE+1];
int   count_db,i;
DBinfo  *list;
FILE    *fp;



/*--------------------------------------------------------------------*/

main(argc,argv)
int  argc;
char **argv;
{  
   
   int rc;
   batchinit();
   strcpy(DBName,   		isNULLstr(argv[1]));
   strcpy(userid,  	 	isNULLstr(argv[2]));
   strcpy(ibranch_flag,     	isNULLstr(argv[3]));  /* ���z�����O */
   strcpy(ibranch,         	isNULLstr(argv[4]));  /* ���z��� */
   strcpy(sfeedback,     	isNULLstr(argv[5]));  /* �Ȥᦳ�L�^�X */
   strcpy(score,     		isNULLstr(argv[6]));  /* �Ȥ������*/
   strcpy(dbgn,    		isNULLstr(argv[7]));  /* ����϶�-�}�l */
   strcpy(dend,     		isNULLstr(argv[8]));  /* ����϶�-���� */
   strcpy(outputf,  		isNULLstr(argv[9]));  


   printf("outputf:s\n",outputf);
	printf("--1.car1206_get_db ------ \n");
	rc = car1206_get_db();
	if (rc != M_CM_OK) {
		EWRITE(userid,rc,msgbuf);
		return rc;
	}
	
    
        printf("--2.car1206_init_data ------ \n");
        rc = car1206_init_data();
        if (rc != M_CM_OK) {
            printf("error on car1206_init_data\n");
    		EWRITE(userid,rc,"�إ� temp table ���~!");
    		return rc;
        }
    
        printf("--3.car1206_query_detail ------ \n");
    	rc = car1206_query_detail();
        if (rc != M_CM_OK) {
        printf("error on car1206_query_detail\n");
    		EWRITE(userid, rc, "���̷s�߮׸��X���~");
    		return rc;
    	}
    	 
    	printf("--4.car1206_print_detail ------ \n");
        rc = car1206_print_detail();
        if (rc != M_CM_OK) {
         printf("error on car1206_print_detail\n");
         EWRITE(userid, rc, "���s�������Ӧ��~!");
         return rc;
        }
       
    
			
    return rc;

}
/******************************************************************************/
long car1206_get_db()
{
	int return_code;
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False) {
		strcpy(msgbuf,"��Ʈw�L�k�}��");
		return M_CM_DB_NOTOPEN;
	}

	return_code = getApHome(sApHome);
	if (return_code < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return return_code;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
	}

	return M_CM_OK;

errexit:
   printf("--car1206_get_db-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
long car1206_init_data()
{   
    $WHENEVER SQLERROR GOTO errexit;

    $create temp table tb_ca12061
    (
		inumber			VARCHAR(20),				-- 0800�ƬG�s��	
       		iclaim 			char(20),   				-- �z�߮׸�
       		itag			char(12),				-- ����
       		ndriver			varchar(20),				-- �r�p�H��
       		itel_ndriver		varchar(20),				-- �r�p�H���q��
		iserver			char(2),				-- �U���ߥN��
		nserver			char(30),				-- �U���ߦW��
		iunit			char(2),				-- �U���N��
		nunit			char(60),				-- �U���W��
		iadjuster       	char(10),       			-- �g��H�����s
		nadjuster       	char(10),       			-- �g��H���m�W
		iscore			char(1),				-- ��������
		nman_service    	varchar(20),   				-- �{���B�z�H��
		dclaim 			date,    				-- ���z��???????
        	daccident       	date,    				-- �X�I�ɶ�???????
		dscore			date,					-- �������???????
		scontent		lvarchar(1024),				-- ��ĳ���e
		sfeedback		char(1)					-- �Ȥᦳ�L�^�X
    )with no log;
	  
    return M_CM_OK;

errexit:
    printf("--car1206_init_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car1206_query_detail()
{
    int	    rc;
    $char   stmt1[2000],stmt2[100],stmt3[2000];
    $int    icnt = 0;
   
    $WHENEVER SQLERROR GOTO errexit;
	
	printf("ibranch_flag : %s \n",ibranch_flag);
	 
	if(strcmp(trim(ibranch_flag), "1") == 0 )
		sprintf_s(stmt3,2000 , "and Q.iquota matches '%s' " , ibranch);
    else 
		sprintf_s(stmt3,2000 , "and Q.iapp_unit = '%s' " , ibranch);
		
		printf("stmt2 : %s \n",stmt3);
		
        sprintf_s(stmt1,2000,
           "insert into tb_ca12061 \
            SELECT * FROM (	\
				SELECT 	s.inumber , s.iclaim , s.itag , s.ndriver , s.itel_ndriver ,\
						CASE WHEN o.iquota[1,4] = '3602' or o.iquota[1,4] = 'L103' THEN '00' \
							 WHEN o.iquota[1,4] = '3607' or o.iquota[1,4] = 'L104' THEN '22'\
							 WHEN o.iquota[1,4] = '3603' or o.iquota[1,4] = 'L105' THEN '33'\
							 WHEN o.iquota[1,4] = '3604' or o.iquota[1,4] = 'L201' THEN '40'\
							 WHEN o.iquota[1,4] = '3605' or o.iquota[1,4] = 'L202' THEN '66'\
							 WHEN o.iquota[1,4] = '3606' or o.iquota[1,4] = 'L203' THEN '70' END iquota, \
						CASE WHEN t.ibranch[1,4] ='3602' or t.ibranch[1,4] ='L103' THEN '�x�_�z�ߤ���' \
							 WHEN t.ibranch[1,4] ='3603' or t.ibranch[1,4] ='L105' THEN '��˭]�z�ߤ���'\
							 WHEN t.ibranch[1,4] ='3604' or t.ibranch[1,4] ='L201' THEN '������z�ߤ���'\
							 WHEN t.ibranch[1,4] ='3605' or t.ibranch[1,4] ='L202' THEN '���ūn�z�ߤ���'\
							 WHEN t.ibranch[1,4] ='3606' or t.ibranch[1,4] ='L203' THEN '����̲z�ߤ���'\
							 WHEN t.ibranch[1,4] ='3607' or t.ibranch[1,4] ='L104' THEN '�s�_�z�ߤ���' END nserver ,\
						o.iapp_unit , t.nbranch, s.iadjuster , o.nname , s.iscore , s.nman_service , \
						date(s.dclaim) as dclaim , date(s.daccident) as daccident , date(s.dscore) as dscore , s.scontent , \
						CASE WHEN s.iscore <> '' THEN 'Y' ELSE 'N' END sfeedback \
				FROM ca_sat_survey s , officer o , sa_branch_type t \
				WHERE s.iadjuster = o.iofficer \
				  AND o.iquota = t.ibranch \
			)Q	\
			WHERE  Q.sfeedback matches '%s' \
			  AND Q.iscore matches '%s'   %s  \
			  AND Q.dclaim BETWEEN '%s' AND '%s'", sfeedback , score , stmt3 , dbgn , dend );
         
        printf("stmt1=[%s]\n",stmt1);
        $PREPARE pre_A1 FROM $stmt1;
        $EXECUTE pre_A1;
    
     
    return M_CM_OK;
  
errexit:
    printf("--car1206_query_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* ------------------------------------------------------------------------- */
long car1206_print_detail()
{
    int     rc;
    char    sfilename[128],stitle[2048],stmt[2048];
    $int    icnt;

    $WHENEVER SQLERROR GOTO errexit;
    
    strcpy(sfilename,"���N�׽լd����");
    strcpy(stitle,"�{���N��:CAR12061\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");

    
    icnt = 0;
    $select count(*) into $icnt
      from tb_ca12061;
	  printf("icnt:%d\n",icnt);
    if (icnt == 0) 
    {
        sprintf_s(msgbuf,2048," %s �d�L���, �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return  M_CM_NOT_FOUND;
    }
    
    strcat(stitle,"\t080�渹\t�z�߮׸�\t����\t�r�p�H��\t�r�p�H���q��\t����\t��O\t�g��H��");
    strcat(stitle,"\t����\t�B�z�H��\t�X�I��\t���z��");
    strcat(stitle,"\t��Ų��\t��ĳ�Τ����ƶ�\t�Ȥᦳ�L�^�X");
	
    strcpy(stmt,"select ''''||inumber , iclaim , itag , ndriver , itel_ndriver , nserver , nunit , nadjuster ,\
                        iscore , nman_service , daccident , dclaim , \
                        dscore , replace(replace(scontent,chr(13),''),chr(10),'') AS scontent , sfeedback \
				 from tb_ca12061 where 1=1   order by iunit asc ");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {

        sprintf_s(msgbuf,2048," %s �ɮ׵L�k���� ",sfilename);

        EWRITE(userid, rc , msgbuf);
        return rc;
    }
    return M_CM_OK;
    
errexit:
    printf("--car1206_print_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

/******************************************************************************/



