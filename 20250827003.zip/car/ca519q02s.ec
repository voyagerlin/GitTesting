/************************************************/
/*						*/
/*   PROGRAM : ca519q02s.ec              	*/
/*   ñ�߲�10��β�15�餴���鵲email�q��        */
/*   DATE    : 2004/06/29			*/
/*   Modify  : 2006/03/09                       */
/************************************************/
#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "ca_field.h"
#include <locator.h>
#include "sqlfatal.h"

char  SysTm[ N_TM+1];
char  outputf[ N_FILE+1];
char  userid[11];

int  max_count, errCode;
int  tmp_len, rec_count;
int  miy;

/*** local function **/
long car5192_email();
long car5192_get_db();
long car5192_create_temp();
int GetWorkDate();

/*** other variable ***/
$long mdate;
$char stmt[1024], DBName[5], sFullName[20];
$char stmt1[1000], pre_ileader[11],ileader1[11], max_date[11], min_date[11],
      nsubject[60];
$int  mail_count;
$char mmsg[9000];
   
DBinfo  *list;
int     count_db;
int     i;

/***************************************************************************/
main(argc, argv)
int argc;
char **argv;
{
   int rc;
   
   strcpy(DBName,"00");
   
   rc = car5192_get_db();
   if (rc != M_CM_OK)
   {
       printf("error on car5192_get_db\n");
       return rc;
   }
            
   rc=car5192_email();
   if (rc != M_CM_OK)
   {
       printf("error on car5192_email\n");
       return rc;
   }
   
   rc=car5192_emailB();
   if (rc != M_CM_OK)
   {
       printf("error on car5192_emailB\n");
       return rc;
   }

   printf("[5192]:build ok!\n"); 
}

/**********************************************************************/
long car5192_email()
{
$char mbuf[9000];
$char mbuf_adj[9000];
$loc_t ctxt;

/* $char mmsg[1024]; */
$char iclaim[21],iadjuster[11],up_admin[11];
$char email[51],up_email[51],nname[20];
$char up_quota[11];
$char up_admin_email[51];
$char chinese_name[15];
$char chinese_name1[15];
$char up_up_email[51];
$char up_up_admin[7];
$char tbuf[501];
$char o_iadjuster[11],o_up_admin[11];
$char top_email[51];
int fetch,rc;
int tot_count;

/* for email */

   $whenever sqlerror goto errexit;
 
   printf("  *********************car519 email \n"); 

   rc = car5192_create_temp();
   if (rc != M_CM_OK)
      return rc;

   strcpy(nsubject,"ñ�����鵲�q��");
   
   sprintf(mmsg,
                "   ���q���z�Ҩ��z���߮�ñ�������w10�餴�����סA\n"
                "���A�ѩ��ݲz�ߥ����׭�],�÷��P���t�B�z�C</P>\n"
                "<table align=center border='1'>\n"
                "<tr><td>�߮׸��X</td><td>�z�߭�</td></tr>\n");
             
   for(i=0;i<count_db;i++) { 
      sprintf(stmt,
             "insert into car5192_10 \
              select distinct b.iadjuster,a.iclaim \
                from %s:ca_sign_receipt a,%s:appraisal b \
               where today - DATE(a.dpaperwork) = 10    \
                 and a.ifpce_id != '08628407'     \
                 and a.dclose is null             \
                 and a.iclaim = b.iclaim ",
              list[i].dbname,list[i].dbname);
      printf("stmt[%s]\n",stmt);
      $prepare main_id from $stmt;
      $execute main_id;
   }

   $declare m_cur cursor for
     select iadjuster,iclaim  
       from car5192_10
      order by 1,2;
   $open m_cur;

   tot_count = 0;
   strcpy(mbuf,rtrim(mmsg));

   for(;;) {
      $fetch m_cur
        into $iadjuster,$iclaim;
               
      if (SQLCODE == SQLNOTFOUND) break;
            
      if (tot_count == 0) {
         $select nname into $chinese_name
            from officer
           where iofficer = $iadjuster;
         if (SQLCODE==SQLNOTFOUND)
            strcpy(chinese_name,iadjuster);

         strcpy(o_iadjuster,trim(iadjuster));
      }
         
      strcpy(iadjuster,trim(iadjuster));    	
        
      printf("iclaim[%s],iadjuster[%s],o_iadjuster[%s]\n",
            iclaim,iadjuster,o_iadjuster);       

      if (strcmp(iadjuster,o_iadjuster)!=0) {
         printf(" **************************************************** \n"); 
          
         strcat(mbuf, "</table>\n");
           
         /* �u�o���z�ߤH�� */
         $select administrator,email 
            into $up_admin,$email
            from personal:asempl    
           where empl_no = $o_iadjuster;
            
         if (SQLCODE == SQLNOTFOUND) {
            strcpy(mbuf,rtrim(mmsg));
            continue;
         }

         strcpy(email,trim(email));
         strcat(email,"@tmnewa.com.tw"); 
                
         printf("10mbuf[%s]\n",mbuf);

         ctxt.loc_loctype = LOCMEMORY;
         ctxt.loc_buffer = mbuf;
         ctxt.loc_bufsize = 9000;
         ctxt.loc_size =  strlen(mbuf) + 1; 
           
         mdate = cm_today()+1;

         $INSERT INTO batchemail 
         (project_id, mail_date, receiver_email, receiver_name, cc,
          content,    key,       mail_count, nsubject)
          VALUES
         ("CAR5192",   $mdate,    $email, " " , " ",
           $ctxt,      "Y",       1, $nsubject);

         $select email
            into $up_admin_email
            from personal:asempl
           where empl_no = $up_admin
             and job_type >= '3';
         if (SQLCODE != SQLNOTFOUND)
         {
            strcpy(up_admin_email, trim(up_admin_email));
            strcat(up_admin_email, "@tmnewa.com.tw");          

            $INSERT INTO batchemail 
            (project_id, mail_date, receiver_email, receiver_name, cc,
             content,    key,       mail_count, nsubject)
             VALUES
            ("CAR5192",   $mdate,    $up_admin_email, " " , " ",
              $ctxt,      "Y",       1, $nsubject);
	 }
              
         strcpy(mbuf,rtrim(mmsg));

         $select nname into $chinese_name
            from officer
           where iofficer = $iadjuster;
         if (SQLCODE==SQLNOTFOUND)
            strcpy(chinese_name,iadjuster);
      }
         
      strcpy(iclaim,trim(iclaim));
      strcpy(chinese_name,trim(chinese_name));
        
      sprintf(tbuf,
            "<tr><td>%s</td><td>%s</td></tr>\n",iclaim,chinese_name);
     
      strcat(mbuf, tbuf);
        
      printf(" mbuf[%s]\n",mbuf);
       
      tot_count++;
      strcpy(o_iadjuster, iadjuster);
   }
    
   if (tot_count != 0) { /* �B�z�̫�@����� */

      strcat(mbuf, "</table>\n");
              
      /* �z�ߪ��ݥD�� �βz�� mail */  
      $select administrator,email 
         into $up_admin,$email
         from personal:asempl    
        where empl_no = $iadjuster;
            
      if (SQLCODE != SQLNOTFOUND) {

         strcpy(email,trim(email));
         strcat(email,"@tmnewa.com.tw");

         ctxt.loc_loctype = LOCMEMORY;
         ctxt.loc_buffer = mbuf;
         ctxt.loc_bufsize = 9000;
         ctxt.loc_size =  strlen(mbuf) + 1; 
           
         mdate = cm_today()+1;
           
         $INSERT INTO batchemail 
         (project_id, mail_date, receiver_email, receiver_name, cc,
          content,    key,       mail_count, nsubject)
          VALUES
         ("CAR5192",   $mdate,    $email, " " , " ",
           $ctxt,      "Y",       1, $nsubject);

         $select email
            into $up_admin_email
            from personal:asempl
           where empl_no = $up_admin
             and job_type >= '3';
         if (SQLCODE != SQLNOTFOUND)
         {
            strcpy(up_admin_email, trim(up_admin_email));
            strcat(up_admin_email, "@tmnewa.com.tw"); 
         
            $INSERT INTO batchemail 
            (project_id, mail_date, receiver_email, receiver_name, cc,
             content,    key,       mail_count, nsubject)
             VALUES
            ("CAR5192",   $mdate,    $up_admin_email, " " , " ",
              $ctxt,      "Y",       1, $nsubject);
	 }              
      }
   }   
    
   $CLOSE m_cur;
   $FREE  m_cur;

   /* ñ���W�L 15 �骺 */
  
   sprintf(mmsg,
           "   ���q���z���ݲz�ߨ��z���߮�ñ�������w15�餴�����סA\n"
           "���A�ѩ��ݲz�ߥ����׭�],�÷��P���t�B�z�C</P>\n"
           "<table align=center border='1'>\n"
           "<tr><td>�߮׸��X</td><td>�z�߭�</td></tr>\n");
                
   for(i=0;i<count_db;i++) { 
      sprintf(stmt,
             "insert into car5192_15 \
              select distinct c.administrator,b.iadjuster,a.iclaim \
                from %s:ca_sign_receipt a,%s:appraisal b,personal:asempl c \
               where today - DATE(a.dpaperwork) = 15    \
                 and a.ifpce_id != '08628407'     \
                 and a.dclose is null             \
                 and a.iclaim = b.iclaim          \
                 and b.iadjuster = c.empl_no ",
              list[i].dbname,list[i].dbname);
      printf("stmt[%s]\n",stmt);
      $prepare main_id from $stmt;
      $execute main_id;
   }
   
   $declare m_cur1 cursor for
     select up_admin,iadjuster,iclaim
       from car5192_15
      order by 1,2,3;
   $open m_cur1;

   tot_count = 0;
   strcpy(mbuf,rtrim(mmsg));
   strcpy(mbuf_adj,rtrim(mmsg));
   strcpy(o_up_admin," ");
   strcpy(up_admin," ");
   strcpy(o_iadjuster, " ");
   strcpy(iadjuster, " ");

   for(;;) {
      $fetch m_cur1
        into $up_admin,$iadjuster,$iclaim;
               
      if (SQLCODE == SQLNOTFOUND) break;
         
      if (tot_count == 0) {
         strcpy(o_up_admin,trim(up_admin));
      }

      fetch ++;
         
      strcpy(iadjuster,trim(iadjuster));  
      printf("iclaim[%s],iadjuster[%s]\n",iclaim,iadjuster);

      if(strcmp(iadjuster,o_iadjuster)!=0) {
         $select nname into $chinese_name
            from officer
           where iofficer = $iadjuster;
         if (SQLCODE==SQLNOTFOUND)
            strcpy(chinese_name,iadjuster);


      }

      strcpy(up_admin,trim(up_admin));

      if(strcmp(up_admin,o_up_admin)!=0) {
        	
          strcat(mbuf, "</table>\n");
          
          /* �u�o���z�ߪ��ݥD�� */
          /* �z�ߪ��ݥD�� mail */  
          $select email, unit_id[1,4] || '00' 
             into $up_email, $up_quota
             from personal:asempl    
            where empl_no = $o_up_admin
              and job_type >= '3';
           
          if (SQLCODE == SQLNOTFOUND) {
              strcpy(mbuf,rtrim(mmsg));
              continue;
          }

          strcpy(up_email,trim(up_email));
          strcat(up_email,"@tmnewa.com.tw"); 

          printf("15mbuf[%s]\n",mbuf);

          ctxt.loc_loctype = LOCMEMORY;
          ctxt.loc_buffer = mbuf;
          ctxt.loc_bufsize = 9000;
          ctxt.loc_size =  strlen(mbuf) + 1; 
            
          mdate = cm_today()+1;
            
          $INSERT INTO batchemail 
          (project_id, mail_date, receiver_email, receiver_name, cc,
           content,    key,       mail_count, nsubject)
           VALUES
          ("CAR5192",   $mdate,    $up_email, " "  ,	" " ,
           $ctxt,      "Y",       1, $nsubject);

          $select email
             into $top_email
             from personal:asempl
            where empl_no = (select resp_name from personal:unitid2ef where code_no = $up_quota)
              and job_type >= '3';
          if (SQLCODE != SQLNOTFOUND)
          {
             strcpy(top_email,trim(top_email));
             strcat(top_email,"@tmnewa.com.tw"); 
             
             $INSERT INTO batchemail 
             (project_id, mail_date, receiver_email, receiver_name, cc,
              content,    key,       mail_count, nsubject)
              VALUES
             ("CAR5192",   $mdate,    $top_email, " "  ,	" " ,
              $ctxt,      "Y",       1, $nsubject);
          }

           strcpy(mbuf,rtrim(mmsg));
           strcpy(mbuf_adj,rtrim(mmsg));                
      }
        
      strcpy(iclaim,trim(iclaim));
      strcpy(chinese_name,trim(chinese_name));
        
      sprintf(tbuf,
            "<tr><td>%s</td><td>%s</td></tr>\n",iclaim,chinese_name);
     
      strcat(mbuf, tbuf);
      strcat(mbuf_adj, tbuf);
        
      printf(" mbuf[%s]\n",mbuf);
        
      tot_count ++;
      strcpy(o_iadjuster,trim(iadjuster));
      strcpy(o_up_admin,trim(up_admin));
      	
   }
  
   if (tot_count != 0 ) { /* �B�z�̫�@����� */

      strcat(mbuf, "</table>\n");
      strcat(mbuf_adj, "</table>\n");
          
      /* �z�ߪ��ݥD�� mail */  
      $select email, unit_id[1,4] || '00' 
         into $up_email, $up_quota
         from personal:asempl    
        where empl_no = $up_admin
          and job_type >= '3';
            
      if (SQLCODE != SQLNOTFOUND) {

         strcpy(up_email,trim(up_email));
         strcat(up_email,"@tmnewa.com.tw"); 
            
         ctxt.loc_loctype = LOCMEMORY;
         ctxt.loc_buffer = mbuf;
         ctxt.loc_bufsize = 9000;
         ctxt.loc_size =  strlen(mbuf) + 1; 
           
         mdate = cm_today()+1;
           
         $INSERT INTO batchemail 
         (project_id, mail_date, receiver_email, receiver_name, cc,
          content,    key,       mail_count, nsubject)
          VALUES
         ("CAR5192",   $mdate,    $up_email, " "  ,	" " ,
          $ctxt,      "Y",       1, $nsubject);

          $select email
             into $top_email
             from personal:asempl
            where empl_no = (select resp_name from personal:unitid2ef where code_no = $up_quota)
              and job_type >= '3';
          if (SQLCODE != SQLNOTFOUND)
          {
             strcpy(top_email,trim(top_email));
             strcat(top_email,"@tmnewa.com.tw"); 
             
             $INSERT INTO batchemail 
             (project_id, mail_date, receiver_email, receiver_name, cc,
              content,    key,       mail_count, nsubject)
              VALUES
             ("CAR5192",   $mdate,    $top_email, " "  ,	" " ,
              $ctxt,      "Y",       1, $nsubject);
          }
      }
   }
   $CLOSE m_cur1;
   $FREE  m_cur1;
   
   return M_CM_OK;
  
errexit:
  sqlfatal();
  return SQLCODE;
}
/*-------------------------------------------------------------*/
long car5192_get_db()
{
   if (db_select(DBName) == False) {
      printf("[%s][%d][%s]",userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }
    
   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      printf("[%s][%d][%s]",userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;
}
/*-------------------------------------------------------------*/
long car5192_create_temp()
{
   $whenever sqlerror goto errexit;

   $create temp table car5192_10
   (iadjuster  char(10),
    iclaim     char(20))
   with no log;

   $create temp table car5192_15
   (up_admin   char(10),
    iadjuster  char(10),
    iclaim     char(20))
   with no log;

   return M_CM_OK;
  
errexit:
  sqlfatal();
  return SQLCODE;
}
/*-------------------------------------------------------------*/
/* ���Юֳq�� add by sylvia 106.09.30  */
/* �������z�q��, ��֤��A�o�email�q��, ���Ю֤~�n modify by sylvia 106.10.18 */
long car5192_emailB()
{
    $char mbuf[9000], tbuf[501];
    $char mbuf_adj[9000];
    
    $char mmsg1[1024],mmsg2[1024],mmsg7[1024],mmsg10[1024];
    $char iclaim[21],iadjuster[11];
    $char nadjustment[15];
    int rc;
    int tot_count;
    
    $int icnt;
    $char st1[4];

    /* for email */
    $whenever sqlerror goto errexit;
 
    printf("  *********************car519 emailB \n"); 

     $select count(*) into $icnt
       from ca_holiday
      where holiday_bgn <= today
        and holiday_end >= today;
    if (icnt > 0)   
    {
        printf("�D�u�@��, ���Юֳq�����o�eemail");
        return M_CM_OK;   
    }
    
    /* �����_1��_mail��D�� (�ˮ־���۵{���W�u106.10.13��_)  */
    strcpy(st1,"1");
    rc = GetWorkDate(st1);
    
    /* �������z�q��, ��֤��A�o�email�q��, ���Ю֤~�n modify by sylvia 106.10.18 */
    /* printf("564:�����_1��max_date=[%s]\n",max_date);
     $select iclaim, (select nname from officer where iofficer = a.adjustment) as nadjuster, 
           (select administrator from personal:asempl where empl_no = a.adjustment) as mgr1
      from ca_clm_process a
     where a.dappraisal >= '10/13/2017'
       and a.dappraisal <= $max_date 
       and a.frule = '1'
       and a.dfirst is null
       and a.fexam = 50
       into temp tb_dfirst_1 with no log; 
    
    $select count(*) into $icnt from tb_dfirst_1  where 1=1; */
    icnt = 0;
    if (icnt > 0)
    {
        strcpy(nsubject,"�w�w������ֳq��");
        sprintf(mmsg1,
            "���q���z���ݲz�߫ݪ�֤��߮׹w�������w1�u�@�餴����֡A �о��t�B�z�C</P></P>\n"
            "<table align=center border='1'>\n"
            "<tr><td>�߮׸��X</td><td>�z�߭�</td></tr>\n");    
        
        sprintf(stmt1,"select iclaim, nadjuster from tb_dfirst_1 where mgr1 = ? order by nadjuster");
        $PREPARE pre_day1 from $stmt1;
        $DECLARE cur_day1 CURSOR FOR pre_day1;    
        
        $DECLARE cur_mgr1 CURSOR FOR
          SELECT DISTINCT mgr1  INTO $ileader1
		    FROM tb_dfirst_1
	       WHERE 1=1
           ORDER BY mgr1;
        $OPEN  cur_mgr1;
        $FETCH cur_mgr1;
        strcpy(pre_ileader,ileader1);
        mail_count=0;
        for(;;)
        {
            if (SQLCODE==SQLNOTFOUND) break;
            memset(mbuf,0x00,sizeof(mbuf));
            memset(tbuf,0x00,sizeof(tbuf));
		    if (strcmp(ileader1,pre_ileader)!=0) 
            {
                $OPEN cur_day1 USING $pre_ileader;
                for(;;)
		        {
		            $FETCH cur_day1 INTO $iclaim, $nadjustment;
		            if (SQLCODE==SQLNOTFOUND) break;

                    sprintf(tbuf, "<tr><td>%s</td><td>%s</td></tr>\n",iclaim,nadjustment);
                    strcat(mbuf, tbuf);
                }
                strcat(mbuf, "</table>\n");
                
                strcpy(mmsg,mmsg1);
                strcat(mmsg,mbuf);
                printf("pre_ileader=[%s]\n",pre_ileader);
                printf("mmsg=[%s]\n",mmsg);
	            rc = car5192_write_email();
	    	    if (rc != M_CM_OK) {
					printf("�����1�� 625:error on car5192_write_email\n");
					return rc;
                }
	    	    mail_count=0;
            }
		    strcpy(pre_ileader,ileader1);
            mail_count++;
    		$fetch cur_mgr1;
	    }
	    
        if (mail_count!=0) {
            memset(mbuf,0x00,sizeof(mbuf));
            memset(tbuf,0x00,sizeof(tbuf));
            
            $OPEN cur_day1 USING $pre_ileader;
            for(;;)
	        {
	            $FETCH cur_day1 INTO $iclaim, $nadjustment;
	            if (SQLCODE==SQLNOTFOUND) break;
                sprintf(tbuf, "<tr><td>%s</td><td>%s</td></tr>\n",iclaim,nadjustment);
                strcat(mbuf, tbuf);
            }
            strcat(mbuf, "</table>\n");
            
            strcpy(mmsg,mmsg1);
            strcat(mmsg,mbuf);
            printf("pre_ileader=[%s]\n",pre_ileader);
            printf("mmsg=[%s]\n",mmsg);
            rc = car5192_write_email();
            if (rc!=M_CM_OK) {
		        printf("�����1�� 653error on car5192_write_email\n");
			    return rc;
			}
	    }
	    $FREE cur_day1;
        $CLOSE cur_mgr1;
        $FREE  cur_mgr1;
    }   
    
    /* ---------------------------------------------------------------------- */
    
    /* �����_2��_mail���D�� (�ˮ־���۵{���W�u106.10.13��_) */
    strcpy(st1,"2");
    rc = GetWorkDate(st1);

    /* �������z�q��, ��֤��A�o�email�q��, ���Ю֤~�n modify by sylvia 106.10.18 */    
    /* printf("668:�����_2�� max_date=[%s]\n",max_date);
    $select iclaim , (select nname from officer where iofficer = a.adjustment) as nadjuster, 
           (select administrator from personal:asempl where empl_no = 
              (select administrator from personal:asempl where empl_no = a.adjustment)) as mgr1
      from ca_clm_process a
     where a.dappraisal >= '10/13/2017'
       and a.dappraisal <= $max_date 
       and a.frule = '1'
       and a.dfirst is null
       and a.fexam = 50
      into temp tb_dfirst_2 with no log;
    
    
    $select count(*) into $icnt from tb_dfirst_2  where 1=1; 
    printf("683:�����_2�� icnt=[%d]\n",icnt); */
    icnt = 0;
    if (icnt > 0)
    {
        memset(ileader1,0x00,sizeof(ileader1));
        memset(pre_ileader,0x00,sizeof(pre_ileader));
        memset(mmsg,0x00,sizeof(mmsg));
                        
        strcpy(nsubject,"�w�w������ֳq��");
        sprintf(mmsg2,
            "���q���z���ݲz�߫ݪ�֤��߮׹w�������w2�u�@�餴����֡A �о��t�B�z�C</P></P>\n"
            "<table align=center border='1'>\n"
            "<tr><td>�߮׸��X</td><td>�z�߭�</td></tr>\n");
        
        sprintf(stmt1,"select iclaim, nadjuster from tb_dfirst_2 where mgr1 = ? order by nadjuster");

        $PREPARE pre_day2 from $stmt1;
        $DECLARE cur_day2 CURSOR FOR pre_day2;    
        
        $DECLARE cur_mgr2 CURSOR FOR
          SELECT DISTINCT mgr1  INTO $ileader1
		    FROM tb_dfirst_2
	       WHERE 1=1
           ORDER BY mgr1;
        $OPEN  cur_mgr2;
        $FETCH cur_mgr2;
        strcpy(pre_ileader,ileader1);
        mail_count=0;
        for(;;)
        {
            if (SQLCODE==SQLNOTFOUND) break;
            memset(mbuf,0x00,sizeof(mbuf));
            memset(tbuf,0x00,sizeof(tbuf));

		    if (strcmp(ileader1,pre_ileader)!=0) 
            {
                $OPEN cur_day2 USING $pre_ileader;
                for(;;)
		        {
		            $FETCH cur_day2 INTO $iclaim, $nadjustment;
		            if (SQLCODE==SQLNOTFOUND) break;

                    sprintf(tbuf, "<tr><td>%s</td><td>%s</td></tr>\n",iclaim,nadjustment);
                    strcat(mbuf, tbuf);
                }
                strcat(mbuf, "</table>\n");
                
                strcpy(mmsg,mmsg2);
                strcat(mmsg,mbuf);
                printf("pre_ileader=[%s]\n",pre_ileader);
                printf("mmsg=[%s]\n",mmsg);
                
	            rc = car5192_write_email();
	    	    if (rc != M_CM_OK) {
					printf("�����_2�� 735:error on car5192_write_email\n");
					return rc;
                }
	    	    mail_count=0;
            }
		    strcpy(pre_ileader,ileader1);
            mail_count++;
            
    		$fetch cur_mgr2;
	    }
	    
        if (mail_count!=0) {
            memset(mbuf,0x00,sizeof(mbuf));
            memset(tbuf,0x00,sizeof(tbuf));
            $OPEN cur_day2 USING $pre_ileader;
            for(;;)
	        {
	            $FETCH cur_day2 INTO $iclaim, $nadjustment;
	            if (SQLCODE==SQLNOTFOUND) break;

                sprintf(tbuf, "<tr><td>%s</td><td>%s</td></tr>\n",iclaim,nadjustment);
                strcat(mbuf, tbuf);
            }
            strcat(mbuf, "</table>\n");
            
            strcpy(mmsg,mmsg2);
            strcat(mmsg,mbuf);
            printf("pre_ileader=[%s]\n",pre_ileader);
            printf("mmsg=[%s]\n",mmsg);
            rc = car5192_write_email();
            if (rc!=M_CM_OK) {
		        printf("�����_2�� 766:error on car5192_write_email\n");
			    return rc;
			}
	    }
	    $FREE cur_day2;
        $CLOSE cur_mgr2;
        $FREE  cur_mgr2;
    }  
    
    /* ---------------------------------------------------------------------- */
    /* ���Ю�_7��_mail��D�ޤβz�� (�ˮ־���۵{���W�u106.10.13��_) */
    strcpy(st1,"7");
    rc = GetWorkDate(st1);
    
    printf("777:���Ю�_7�� max_date=[%s]\n",max_date);
    $select a.iclaim , a.adjustment , 
            (select nname from officer where iofficer = a.adjustment) as nadjustment,
            (select administrator from personal:asempl where empl_no = a.adjustment) as mgr1
       from ca_clm_process a, ca_clm_recheck b
      where a.iclaim = b.iclaim
        and date(a.dfirst) = date(b.drecheck)
        and b.fadm = '1'
        and date(a.dfirst) >= '10/13/2017'
        and date(a.dfirst) <= $max_date 
        and frule = '1'
        and fexam = 100 
        and b.dproc is null
       into temp tb_fexam_7 with no log;
       
    /* �Ю�_7��(��D��&�z��) */
    $select count(*) into $icnt from tb_fexam_7  where 1=1; 
    printf("794:�Ю�_7�� icnt=[%d]\n",icnt);
    if (icnt > 0)
    {
        memset(ileader1,0x00,sizeof(ileader1));
        memset(pre_ileader,0x00,sizeof(pre_ileader));
        memset(mmsg,0x00,sizeof(mmsg));
        
        strcpy(nsubject,"�w��֥�쥼�Юֳq��");    
        sprintf(mmsg7,
            "���q���z���ݲz�ߤw��֥�줧�߮ר����w7�u�@�餴���Ю֡A ���A�ѩ��ݲz�ߥ��Ю֭�],�÷��P���t�B�z�C</P></P>\n"
            "<table align=center border='1'>\n"
            "<tr><td>�߮׸��X</td><td>�z�߭�</td></tr>\n");    
            
        /* ��D�� */
        sprintf(stmt1,"select iclaim, nadjustment from tb_fexam_7 where mgr1 = ? order by adjustment");

        $PREPARE pre_day7 from $stmt1;
        $DECLARE cur_day7 CURSOR FOR pre_day7;
        
        $DECLARE cur_mgr7 CURSOR FOR
          SELECT DISTINCT mgr1  INTO $ileader1
		    FROM tb_fexam_7
	       WHERE 1=1
           ORDER BY mgr1;
        $OPEN  cur_mgr7;
        $FETCH cur_mgr7;
        strcpy(pre_ileader,ileader1);
        mail_count=0;
        for(;;)
        {
            if (SQLCODE==SQLNOTFOUND) break;
            memset(mbuf,0x00,sizeof(mbuf));
            memset(tbuf,0x00,sizeof(tbuf));
            
		    if (strcmp(ileader1,pre_ileader)!=0) 
            {
                $OPEN cur_day7 USING $pre_ileader;
                for(;;)
		        {
		            $FETCH cur_day7 INTO $iclaim, $nadjustment;
		            if (SQLCODE==SQLNOTFOUND) break;
		            
                    sprintf(tbuf, "<tr><td>%s</td><td>%s</td></tr>\n",iclaim,nadjustment);
                    strcat(mbuf, tbuf);
                }
                strcat(mbuf, "</table>\n");
                
                strcpy(mmsg,mmsg7);
                strcat(mmsg,mbuf);
                printf("pre_ileader=[%s]\n",pre_ileader);
                printf("mmsg=[%s]\n",mmsg);
	            rc = car5192_write_email();
	    	    if (rc != M_CM_OK) {
					printf("���Ю�_7��_�� 847:error on car5192_write_email\n");
					return rc;
                }
	    	    mail_count=0;
            }
		    strcpy(pre_ileader,ileader1);
            mail_count++;
            
    		$fetch cur_mgr7;
	    }
	    
	    
        if (mail_count!=0) {
            memset(mbuf,0x00,sizeof(mbuf));
            memset(tbuf,0x00,sizeof(tbuf));
            $OPEN cur_day7 USING $pre_ileader;
            for(;;)
	        {
	            $FETCH cur_day7 INTO $iclaim, $nadjustment;
	            if (SQLCODE==SQLNOTFOUND) break;

                sprintf(tbuf, "<tr><td>%s</td><td>%s</td></tr>\n",iclaim,nadjustment);
                strcat(mbuf, tbuf);
            }
            strcat(mbuf, "</table>\n");
            
            strcpy(mmsg,mmsg7);
            strcat(mmsg,mbuf);
            printf("pre_ileader=[%s]\n",pre_ileader);
            printf("mmsg=[%s]\n",mmsg);
                
            rc = car5192_write_email();
            if (rc!=M_CM_OK) {
		        printf("���Ю�_7��_�� 878:error on car5192_write_email\n");
			    return rc;
			}
	    }
	    $FREE cur_day7;
        $CLOSE cur_mgr7;
        $FREE  cur_mgr7;
	    
	    /* �z�߭� */
        sprintf(stmt1,"select iclaim, nadjustment from tb_fexam_7 where adjustment = ? order by iclaim");
        printf("885:stmt1[%s]\n",stmt1);
        $PREPARE pre_day7a from $stmt1;
        $DECLARE cur_day7a CURSOR FOR pre_day7a;
        
        $DECLARE cur_adj7 CURSOR FOR
          SELECT DISTINCT adjustment  INTO $ileader1
		    FROM tb_fexam_7
	       WHERE 1=1
           ORDER BY adjustment;
        $OPEN  cur_adj7;
        $FETCH cur_adj7;
        strcpy(pre_ileader,ileader1);
        mail_count=0;
        for(;;)
        {
            if (SQLCODE==SQLNOTFOUND) break;
            memset(mbuf,0x00,sizeof(mbuf));
            memset(tbuf,0x00,sizeof(tbuf));
            
		    if (strcmp(ileader1,pre_ileader)!=0) 
            {
                $OPEN cur_day7a USING $pre_ileader;
                for(;;)
		        {
		            $FETCH cur_day7a INTO $iclaim, $nadjustment;
		            if (SQLCODE==SQLNOTFOUND) break;
		            
                    sprintf(tbuf, "<tr><td>%s</td><td>%s</td></tr>\n",iclaim,nadjustment);
                    strcat(mbuf, tbuf);
                }
                strcat(mbuf, "</table>\n");
                
                strcpy(mmsg,mmsg7);
                strcat(mmsg,mbuf);
                printf("pre_ileader=[%s]\n",pre_ileader);
                printf("mmsg=[%s]\n",mmsg);
                
	            rc = car5192_write_email();
	    	    if (rc != M_CM_OK) {
					printf("���Ю�_7��_�z 824:error on car5192_write_email\n");
					return rc;
                }
	    	    mail_count=0;
            }
		    strcpy(pre_ileader,ileader1);
            mail_count++;
            
    		$fetch cur_adj7;
	    }
	    
        if (mail_count!=0) {
            memset(mbuf,0x00,sizeof(mbuf));
            memset(tbuf,0x00,sizeof(tbuf));
            $OPEN cur_day7a USING $pre_ileader;
            for(;;)
	        {
	            $FETCH cur_day7a INTO $iclaim, $nadjustment;
	            if (SQLCODE==SQLNOTFOUND) break;

                sprintf(tbuf, "<tr><td>%s</td><td>%s</td></tr>\n",iclaim,nadjustment);
                strcat(mbuf, tbuf);
            }
            strcat(mbuf, "</table>\n");
            
            strcpy(mmsg,mmsg7);
            strcat(mmsg,mbuf);
            
            printf("pre_ileader=[%s]\n",pre_ileader);
            printf("mmsg=[%s]\n",mmsg);
            
            rc = car5192_write_email();
            if (rc!=M_CM_OK) {
		        printf("���Ю�_7��_�z 955:error on car5192_write_email\n");
			    return rc;
			}
	    }
	    $FREE cur_day7a;
        $CLOSE cur_adj7;
        $FREE  cur_adj7;
    }    
    
    /* --------------------------------------------------------------------- */
    
    /* ���Ю�_10��_mail���D�� (�ˮ־���۵{���W�u106.10.13��_) */
    strcpy(st1,"10");
    rc = GetWorkDate(st1);
    
    printf("967:���Ю�_10��  max_date=[%s]\n",max_date);
    $select a.iclaim , a.adjustment ,
            (select nname from officer where iofficer = a.adjustment) as nadjustment,
            (select administrator from personal:asempl where empl_no = 
                    (select administrator from personal:asempl where empl_no = a.adjustment)) as mgr1
       from ca_clm_process a, ca_clm_recheck b
      where a.iclaim = b.iclaim
        and date(a.dfirst) = date(b.drecheck)
        and b.fadm = '1'
        and date(a.dfirst) >= '10/13/2017'
        and date(a.dfirst) <= $max_date 
        and frule = '1'
        and fexam = 100 
        and b.dproc is null
       into temp tb_fexam_10 with no log;
    
    /* �Ю�_10��(���D��) */
    $select count(*) into $icnt from tb_fexam_10  where 1=1; 
    printf("985:�Ю�_10�� icnt=[%d]\n",icnt);
    if (icnt > 0)
    {
        memset(ileader1,0x00,sizeof(ileader1));
        memset(pre_ileader,0x00,sizeof(pre_ileader));
        memset(mmsg,0x00,sizeof(mmsg));
        
        strcpy(nsubject,"�w��֥�쥼�Юֳq��");    
        sprintf(mmsg10,
            "���q���z���ݲz�ߤw��֥�줧�߮ר����w10�u�@�餴���Ю֡A ���A�ѩ��ݲz�ߥ��Ю֭�],�÷��P���t�B�z�C</P></P>\n"
            "<table align=center border='1'>\n"
            "<tr><td>�߮׸��X</td><td>�z�߭�</td></tr>\n");    
            
        /* ���D�� */
        sprintf(stmt1,"select iclaim, nadjustment from tb_fexam_10 where mgr1 = ? order by adjustment");
        $PREPARE pre_day10 from $stmt1;
        $DECLARE cur_day10 CURSOR FOR pre_day10;
        
        $DECLARE cur_mgr10 CURSOR FOR
          SELECT DISTINCT mgr1  INTO $ileader1
		    FROM tb_fexam_10
	       WHERE 1=1
           ORDER BY mgr1;
        $OPEN  cur_mgr10;
        $FETCH cur_mgr10;
        strcpy(pre_ileader,ileader1);
        mail_count=0;
        for(;;)
        {
            if (SQLCODE==SQLNOTFOUND) break;
            memset(mbuf,0x00,sizeof(mbuf));
            memset(tbuf,0x00,sizeof(tbuf));
            
		    if (strcmp(ileader1,pre_ileader)!=0) 
            {
                $OPEN cur_day10 USING $pre_ileader;
                for(;;)
		        {
		            $FETCH cur_day10 INTO $iclaim, $nadjustment;
		            if (SQLCODE==SQLNOTFOUND) break;
		            
                    sprintf(tbuf, "<tr><td>%s</td><td>%s</td></tr>\n",iclaim,nadjustment);
                    strcat(mbuf, tbuf);
                }
                strcat(mbuf, "</table>\n");
                
                strcpy(mmsg,mmsg10);
                strcat(mmsg,mbuf);
                printf("pre_ileader=[%s]\n",pre_ileader);
                printf("mmsg=[%s]\n",mmsg);
                
	            rc = car5192_write_email();
	    	    if (rc != M_CM_OK) {
					printf("���Ю�_10�� 1039:error on car5192_write_email\n");
					return rc;
                }
	    	    mail_count=0;
            }
		    strcpy(pre_ileader,ileader1);
            mail_count++;
            
    		$fetch cur_mgr10;
	    }
	    
        if (mail_count!=0) {
            memset(mbuf,0x00,sizeof(mbuf));
            memset(tbuf,0x00,sizeof(tbuf));
            $OPEN cur_day10 USING $pre_ileader;
            for(;;)
	        {
	            $FETCH cur_day10 INTO $iclaim, $nadjustment;
	            if (SQLCODE==SQLNOTFOUND) break;
	            
                sprintf(tbuf, "<tr><td>%s</td><td>%s</td></tr>\n",iclaim,nadjustment);
                strcat(mbuf, tbuf);
            }
            strcat(mbuf, "</table>\n");
            
            strcpy(mmsg,mmsg10);
            strcat(mmsg,mbuf);
            
            printf("pre_ileader=[%s]\n",pre_ileader);
            printf("mmsg=[%s]\n",mmsg);
                
            rc = car5192_write_email();
            if (rc!=M_CM_OK) {
		        printf("���Ю�_10�� 1071:error on car5192_write_email\n");
			    return rc;
			}
	    }
	    $FREE cur_day10;
        $CLOSE cur_mgr10;
        $FREE  cur_mgr10;
    }         
   return M_CM_OK;
  
errexit:
  sqlfatal();
  return SQLCODE;
}

/* -------------------------------------------------------------------------- */
/* ���e��N�Ӥu�@�� */
int GetWorkDate(wkdays)
char wkdays[4];
{
    int rc1,x1;
    $int icnt3,icnt2,icnt1,wkday;
    $int ddate1,ddate2;
    $char sdate1[11],sdate2[11],top_unit[11], mleader[11],v_sMsg[150];

    $WHENEVER SQLERROR GOTO errexit;

    icnt1 = atoi(wkdays);
    icnt3 = icnt2 = wkday = 0;
    x1 = 0;
    for(i=1;i<=180;i++)
    {
        icnt3 ++; 
        
        $select count(*) into $icnt2
           from ca_holiday
          where holiday_bgn <= today-$icnt3
            and holiday_end >= today-$icnt3;
            
        if (icnt2 == 0)
        {
            wkday++;
        }
        
        if (wkday ==  icnt1+1)
        {
            $select first 1 today-$icnt3 into $ddate1 from ca_holiday;
            strcpy(sdate1,cm_edate_str(ddate1));
            printf("[%d]�Ӥu�@��e��[%s]\n",icnt1,sdate1);
            if (x1 == 0)
                strcpy(max_date,sdate1);
                
            x1++;
        }
        
        if (wkday ==  icnt1+2)
        {
            $select first 1 today-$icnt3 into $ddate2 from ca_holiday;
            strcpy(sdate2,cm_edate_str(ddate2));
            printf("[%d]�Ӥu�@��e��[%s]\n",icnt1+1,sdate2);
            strcpy(min_date,sdate2);
            break;
        }
    }
    
    printf("\n �� %d �Ӥu�@�ѫe������϶���: %s ~ %s \n", icnt1, min_date,max_date );

    return M_CM_OK;


errexit:

  sprintf( v_sMsg, "1136:SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  return SQLCODE;

}


long car5192_write_email()
{
    $loc_t 	ctxt;
    $char email[51], chinese_name[11];
    
    $whenever sqlerror goto errexit;
    
    
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mmsg;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mmsg) + 1;

    strcpy(email," ");
    $select email,chinese_name
       into $email,$chinese_name
       from personal:asempl
      where empl_no = $pre_ileader
        and job_type >= '3';

    strcpy(email,trim(email));
    
    if (strlen(email) != 0)
    { 
      strcat(email,"@tmnewa.com.tw");
		
	/* ���R��batchemail�즳��mail,�A�s�W�@���s�� */
    $delete from batchemail
      where project_id = "CAR5192"
        and mail_date = today+1
        and receiver_email = $email
        and receiver_name = $chinese_name
        and nsubject = $nsubject;
		
      $INSERT INTO batchemail
		  (project_id, mail_date, receiver_email, receiver_name, cc, 
		   content, key, mail_count,nsubject)
       VALUES
		  ("CAR5192", today+1, $email, $chinese_name, " ", 
		   $ctxt, " ", $mail_count, $nsubject);
    }
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
