/**********************************************************
 *
 *   car_fun.ec
 *
 **********************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "rinmsgs.h"
#include <stdlib.h>
#include <decimal.h>
#include "globdata.h"  
#include "safeclib.h"
$include sqlca;

$struct itype_hist{
  char ipolicy[POLICY_NUM_1];
  char iins_type[INSURANCE_TYPE];
  char pay_status;
  long dedr_begin;
  long dedr_end;
  char fedr_status[3];
  long dendorse;
  int  minjured_cover;
  int  mdeath_cover;
  int  mdamage_cover;
  long mdeduct;
  int  mpremium;
  struct itype_hist *next;
  };

$struct ipa_hist{
  char  ipolicy[POLICY_NUM_1];
  char  iins_type[7];
  char  iinsurant[11];
  char  iins_scope;
  char  icareer;
  char  ninsurant[31];
  long  dbirth;
  long  dedr_begin;
  long  dedr_end;
  char  fedr_status[3];
  long  dendorse;
  int   mins_amt;
  int   mpremium;
  int   daily_pay;
  struct ipa_hist *next;
  };

void car_free_node();
void car_free_panode();
long get_adjust_21();
char *get_car_full_db();

/***********************************************************************/
void car_free_node(p)
struct itype_hist *p;
{
  struct itype_hist *pTmp;
  pTmp = p;
  while(pTmp->next){
    pTmp = pTmp->next;
    free(p);
    p = pTmp;
  }
  free(pTmp);
} /* car_free_node */

/***********************************************************************/
void car_free_panode(p)
struct ipa_hist *p;
{
  struct ipa_hist *pTmp;
  pTmp = p;
  while(pTmp->next){
    pTmp = pTmp->next;
    free(p);
    p = pTmp;
  }
  free(pTmp);
} /* car_free_node */

/***********************************************************************/
int car_get_premium(pDBSite, pIpolicy, pDaccident, pInsType)
$char *pDBSite;
$char *pIpolicy;
$char *pDaccident;
struct itype_hist **pInsType;
{
	struct itype_hist  *p, *s;
	$char sIins_type[INSURANCE_TYPE], stmt[500], stmt1[512], sWhereStr[80];
	short count=0, first=1;
	$char sIpolicy[POLICY_NUM_1], sIendorse[ENDORSE_NUM];
	$long lDedr_begin = 0, lDedr_end = 0;
	$char sFedr_status[3];
	$long lDendorse = 0;
	$int  iMinjured_cover = 0;
	$int  iMdeath_cover = 0;
	$int  iMdamage_cover = 0;
	$long iMdeduct = 0;
	$int  iMpremium = 0;
	char  sResult[3], sComment1[31], sComment2[31];
	char  sDate1[9], sDate2[9], sFullName[20];
	long  l_dacc;

	$int iMcover = 0;
	$char sIcover_type[4];

	strcpy(sFullName, get_full_dbname(pDBSite));

	printf("&&&&& car_get_premium: DBSite:[%s], FullDBName:[%s], Policy:[%s], Daccident:[%s] &&&&&\n", pDBSite, sFullName, pIpolicy, pDaccident);

	if(*pDaccident == '\0')
		strcpy(sWhereStr, "");
	else
		strcpy(sWhereStr, "AND dedr_begin <= ? AND dedr_end >= ? ");

	l_dacc = cm_ymd_cdate(cm_from_infdate_100(pDaccident));

	$WHENEVER SQLERROR GOTO errexit;
	*pInsType = (struct itype_hist *) calloc(1, sizeof(struct itype_hist));
	sprintf_s(stmt1,sizeof stmt1, "SELECT iins_type, iendorse \
                    FROM %s:ply_ins_type \
                    WHERE ipolicy = '%s' ORDER BY iins_type", 
            sFullName, pIpolicy);
	printf("ipolicy=[%s]\n",pIpolicy);
	$PREPARE s2 FROM $stmt1;
	$DECLARE a_cursor CURSOR FOR s2;
	$OPEN a_cursor;
	while(1)
	{
		printf("***** fetch *****\n");
		$FETCH a_cursor INTO $sIins_type, $sIendorse;
		if(SQLCODE == SQLNOTFOUND)
			break;

		if (strncmp(sIins_type,"34",2) == 0)
		{
			printf("get_prem: ipolicy:[%s]\n", pIpolicy);
			printf("get_prem: ins_type[%s]\n", sIins_type);
			/*��˫O�B*/
			sprintf_s(stmt,sizeof stmt, "SELECT dedr_begin,dedr_end,dendorse,mcover,icover_type,mcover_prem \
                           FROM %s:ply_ins_cover_hist \
                           WHERE ipolicy = '%s' AND iins_type = '%s' \
                           AND icover_type = '001' %s \
                           ORDER BY dedr_begin DESC, dendorse DESC, icover_type",
						   sFullName, pIpolicy, sIins_type, sWhereStr);
			$PREPARE s34a1 FROM $stmt;
			$DECLARE b_cursor34a1 CURSOR FOR s34a1;
			/*�ƬG��˫O�B*/
			sprintf_s(stmt,sizeof stmt, "SELECT dedr_begin,dedr_end,dendorse,mcover,icover_type,mcover_prem \
                           FROM %s:ply_ins_cover_hist \
                           WHERE ipolicy = '%s' AND iins_type = '%s' \
                           AND icover_type = '002' %s \
                           ORDER BY dedr_begin DESC, dendorse DESC, icover_type",
						   sFullName, pIpolicy, sIins_type, sWhereStr);
			$PREPARE s34a2 FROM $stmt;
			$DECLARE b_cursor34a2 CURSOR FOR s34a2;

			printf("pdaccident=[%s]\n",pDaccident);
			if(*pDaccident == '\0')
			{
				$OPEN b_cursor34a1;
				$OPEN b_cursor34a2;
			}
			else
			{
				$OPEN b_cursor34a1 USING $pDaccident, $pDaccident;
				$OPEN b_cursor34a2 USING $pDaccident, $pDaccident;
			}
						
			if(first)
				p = *pInsType;
			else
				p = (struct itype_hist *) calloc(1, sizeof(struct itype_hist));
			
			strcpy(p->ipolicy, pIpolicy);
			strcpy(p->iins_type, "34A");
			count++;
			while (1)
			{
				$FETCH b_cursor34a1 INTO  $lDedr_begin,$lDedr_end,$lDendorse,$iMcover,$sIcover_type,$iMpremium;
				if(SQLCODE == SQLNOTFOUND)
					break;

				p->dedr_begin = lDedr_begin;
				p->fedr_status[0] = '\0';
				p->dendorse = lDendorse;
				p->minjured_cover = iMcover;
				p->mpremium = iMpremium;
				break;
			}
			while (1)
			{
				$FETCH b_cursor34a2 INTO  $lDedr_begin,$lDedr_end,$lDendorse,$iMcover,$sIcover_type,$iMpremium;
				if(SQLCODE == SQLNOTFOUND)
					break;

				p->dedr_begin = lDedr_begin;
				p->fedr_status[0] = '\0';
				p->dendorse = lDendorse;
				p->mdamage_cover = iMcover;
				break;
			}

			$CLOSE b_cursor34a1;
			$CLOSE b_cursor34a2;
			p->mdeath_cover = 0;
			p->mdeduct = 0;
			p->next = NULL;

			if(first) 
				first = 0;
			else
				s->next = p;

			s = p;
			if(0)	free(p);
			
			/*���`�O�B*/
			sprintf_s(stmt,sizeof stmt, "SELECT dedr_begin,dedr_end,dendorse,mcover,icover_type,mcover_prem \
                           FROM %s:ply_ins_cover_hist \
						   WHERE ipolicy = '%s' AND iins_type = '%s' \
                           AND icover_type = '003' %s \
                           ORDER BY dedr_begin DESC,dendorse DESC, icover_type",
						   sFullName, pIpolicy, sIins_type, sWhereStr);
			$PREPARE s34b3 FROM $stmt;
			$DECLARE b_cursor34b3 CURSOR FOR S34b3;
			/*�ƬG���`�O�B*/
			sprintf_s(stmt,sizeof stmt, "SELECT dedr_begin,dedr_end,dendorse,mcover,icover_type,mcover_prem \
                           FROM %s:ply_ins_cover_hist \
						   WHERE ipolicy = '%s' AND iins_type = '%s' \
                           AND icover_type = '004' %s \
                           ORDER BY dedr_begin DESC,dendorse DESC, icover_type",
						   sFullName, pIpolicy, sIins_type, sWhereStr);
			$PREPARE s34b4 FROM $stmt;
			$DECLARE b_cursor34b4 CURSOR FOR S34b4;

			printf("pdaccident=[%s]\n",pDaccident);
			if(*pDaccident == '\0')
			{
				$OPEN b_cursor34b3;
				$OPEN b_cursor34b4;
			}
			else
			{
				$OPEN b_cursor34b3 USING $pDaccident, $pDaccident;
				$OPEN b_cursor34b4 USING $pDaccident, $pDaccident;
			}

			
			if(first)
				p = *pInsType;
			else
				p = (struct itype_hist *) calloc(1, sizeof(struct itype_hist));
			strcpy(p->ipolicy, pIpolicy);
			strcpy(p->iins_type, "34B");

			count++;
			while (1)
			{
				$FETCH b_cursor34b3 INTO $lDedr_begin,$lDedr_end,$lDendorse,$iMcover,$sIcover_type,$iMpremium;
				if(SQLCODE == SQLNOTFOUND)
					break;

				p->dedr_begin = lDedr_begin;
				p->fedr_status[0] = '\0';
				p->dendorse = lDendorse;
				p->mdeath_cover = iMcover;
				p->mpremium = iMpremium;
				break;
			}
			while (1)
			{
				$FETCH b_cursor34b4 INTO $lDedr_begin,$lDedr_end,$lDendorse,$iMcover,$sIcover_type,$iMpremium;
				if(SQLCODE == SQLNOTFOUND)
					break;

				p->dedr_begin = lDedr_begin;
				p->fedr_status[0] = '\0';
				p->dendorse = lDendorse;
				p->mdamage_cover = iMcover;
				break;

			}
			$CLOSE b_cursor34b3;
			$CLOSE b_cursor34b4;
			p->minjured_cover = 0;
			p->mdeduct = 0;
			p->next = NULL;

			if(first) 
				first = 0;
			else
				s->next = p;

			s = p;
			if(0)	free(p);
		}
		else
		{
			printf("get_prem: ipolicy:[%s]\n", pIpolicy);
			/* ************************************************/
			/* Fetch data form ply_ins_type_hist which are    */
			/*   max(dedr_begin)&max(fedr_status)             */
			/*   where dedr_begin <= daccident &ipolicy       */
			/**************************************************/
			sprintf_s(stmt,sizeof stmt, "SELECT dedr_begin, dedr_end, fedr_status, dendorse, \
								  minjured_cover, mdeath_cover, mdamage_cover, mdeduct, \
								  mpremium \
						   FROM %s:ply_ins_type_hist \
						   WHERE ipolicy = '%s' AND iins_type = '%s' %s \
						   AND fedr_status < 80 \
						   ORDER BY dedr_begin DESC, dendorse DESC, fedr_status DESC",
			/* 841109  ORDER BY dedr_begin DESC, fedr_status DESC", */
						   sFullName, pIpolicy, sIins_type, sWhereStr);

			printf("pdaccident=[%s]\n",pDaccident);
			$PREPARE s1 FROM $stmt;
			$DECLARE b_cursor CURSOR FOR s1;
			if(*pDaccident == '\0')
				$OPEN b_cursor;
			else
				$OPEN b_cursor USING $pDaccident, $pDaccident;

			while(1)
			{
				$FETCH b_cursor INTO $lDedr_begin, $lDedr_end, $sFedr_status, $lDendorse,
									 $iMinjured_cover, $iMdeath_cover, $iMdamage_cover, 
									 $iMdeduct, $iMpremium;
				if(SQLCODE == SQLNOTFOUND)
					break;
				printf("get_prem: ins_type[%s]\n", sIins_type);
				/**if(strcmp(sFedr_status, "01") == 0){
					$CLOSE a_cursor;
					$CLOSE b_cursor;
					return -2;
					break;   
				} else if((strcmp(sFedr_status,"03") == 0) || 
						   (strcmp(sFedr_status, "02") == 0))
					break;   
				**/
				if(first)
					p = *pInsType;
				else
					p = (struct itype_hist *) calloc(1, sizeof(struct itype_hist));

				printf("get_prem:sFedr_status:[%s],sIns_type:[%s]\n", sFedr_status, sIins_type);
				printf("get_prem:injure:[%ld], death:[%ld], damage_cover:[%ld], deduct:[%ld], premium:[%ld]\n", iMinjured_cover, iMdeath_cover, iMdamage_cover, iMdeduct, iMpremium);
				count++;
				/* ***** Put data into structure ***** */
				strcpy(p->ipolicy, pIpolicy);
				strcpy(p->iins_type, sIins_type);
				p->dedr_begin = lDedr_begin;
				strcpy(p->fedr_status, sFedr_status);
				p->dendorse = lDendorse;
				p->minjured_cover = iMinjured_cover;
				if (strncmp(sIins_type,"21",2) == 0)
				{
					p->mdeath_cover = get_adjust_21(l_dacc,iMdeath_cover);
				}
				else
				{
					p->mdeath_cover = iMdeath_cover;
				}

				if (strncmp(sIins_type,"21",2) == 0)
				{
					p->mdamage_cover = get_adjust_21(l_dacc,iMdamage_cover);
				}
				else
				{
					p->mdamage_cover = iMdamage_cover;
				}

				p->mdeduct = iMdeduct;
				p->mpremium = iMpremium;
				p->next = NULL;
				/* *****         End             ***** */

				/* ***** Make a linked list for ply_ins_type_hist data ***** */
				if(first) 
					first = 0;
				else
					s->next = p;

				s = p;
				if(0)	free(p);
				break;
			}/* while */
			$CLOSE b_cursor;
		}
	} /* while */
	$CLOSE a_cursor;

	printf("get_prem: count[%d]\n", count);
	
	if(0)	free(pInsType);
	
	if(count)
		return 0;
	else
		return -1;

errexit:
	return SQLCODE;
} /* car_get_premium */

/*********************************************************************/
double get_mcover_new(dMcover, accident, ply_bgn, icar_type, Haccident, ipolicy)
$double dMcover;
$char *accident, *ply_bgn, *icar_type, *Haccident, *ipolicy;
{
  int     accident_y, accident_m, accident_d, ply_bgn_y, ply_bgn_m, ply_bgn_d;
  long iHaccident;
  $int    iMonths;
  $double dRate;
  char    buf_y[4], buf_m[3], buf_d[3];
  $char   drate_ym[5];
  $char   ibranch_in[3];
  $char   stmt[2048];
  $char   sIpolicy[21];
  $char   sFull[31];

  printf("INTO &&&&& get_mcover() mcover:[%f], daccident:[%s], ply_bgn:[%s], icar_type:[%s] &&&&&\n", dMcover, accident, ply_bgn, icar_type);
  strcpy(sIpolicy, ipolicy);
  /* ***** step-1 ***** */
  /*
  buf[2] = '\0';
  strncpy(buf, accident,   2); accident_y = atoi(buf);
  strncpy(buf, accident+3, 2); accident_m = atoi(buf);
  strncpy(buf, accident+6, 2); accident_d = atoi(buf);
  */
  cm_split_ymd_100(accident, buf_y, buf_m, buf_d);
  accident_y = atoi(buf_y);
  accident_m = atoi(buf_m);
  accident_d = atoi(buf_d);
  iHaccident = atoi(Haccident);

  /*
  strncpy(buf, ply_bgn,   2);   ply_bgn_y = atoi(buf);
  strncpy(buf, ply_bgn+3, 2);   ply_bgn_m = atoi(buf);
  strncpy(buf, ply_bgn+6, 2);   ply_bgn_d = atoi(buf);
  */
  cm_split_ymd_100(ply_bgn, buf_y, buf_m, buf_d);
  ply_bgn_y = atoi(buf_y);
  ply_bgn_m = atoi(buf_m);
  ply_bgn_d = atoi(buf_d);

  iMonths = accident_y * 12 + accident_m - ply_bgn_y * 12 - ply_bgn_m;

  if(accident_d > ply_bgn_d) iMonths++;
  printf("\niHaccident[%d]\n",iHaccident);
  printf("accident_d==>[%d]  ,  ply_bgn_d==>[%d]\n",accident_d,ply_bgn_d);
  if(accident_d == ply_bgn_d && iHaccident >= 12) iMonths++;

  printf("sIpolicy[%s]\n",sIpolicy);
  strcpy(sFull, get_car_full_db(sIpolicy));
  printf(" sFull[%s]\n",sFull);
  sprintf_s(stmt,sizeof stmt,
   " select first 1 drate_ym        \
       from %s:ply_ins_type         \
      where ipolicy = ?             \
        and iins_type in ('01','05','08','09','85','73','74','75','76','11','18','101','102','201','205','209','211')    \
      order by 1 ", sFull );
     printf(" stmt [%s]\n",stmt);

  $PREPARE get_drate FROM $stmt;
  $EXECUTE get_drate 
      INTO $drate_ym
     USING $sIpolicy;

  if (SQLCODE == SQLNOTFOUND)
  {
     /* ***** step-2 ***** */
     $SELECT max(a.pdepreciate)
        INTO $dRate
        FROM depreciation_rate a, car_type b
       WHERE b.fclass = '1' AND b.icode = $icar_type AND 
             a.fcar_class = b.fcar_class AND a.qperiod_end >= $iMonths AND 
             a.qperiod_bgn < $iMonths;

     printf(">> 1 dRate[%f]\n",dRate);
  }
  else
  {
     sprintf_s(stmt,sizeof stmt,
      " select nvl(max(pdepreciate),0)                          \
          from depreciation_rate                                \
         where drate = (select drate from ca_rate_date          \
                         where icode = ? and itable = 'depreciation_rate')     \
                           and fcar_class = (select case when icar_grp = '1' then '3' else fcar_class end     \
                                               from car_type where fclass = '1' and icode = ?)                \
            and qperiod_end >= ?                                \
            and qperiod_bgn < ? "); 
     printf(" stmt [%s]\n",stmt);
     $PREPARE get_pdepre FROM $stmt;
     $EXECUTE get_pdepre 
         INTO $dRate
        USING $drate_ym, $icar_type, $iMonths, $iMonths;

     printf(">> 2 drate_ym[%s]\n",drate_ym);
     printf(">> 2 dRate[%f]\n",dRate);
  }

  if(SQLCODE == SQLNOTFOUND){
     dRate = 0;
     printf(" &&&&& get_mcover error: SQLNOTFOUND &&&&&\n");
  }

  return dMcover * (1 - dRate/100);

errexit:
  printf("get_mcover[errexit]:SQLCODE[%d],errstr[%s]\n",SQLCODE,sqlca.sqlerrm);
  return dMcover;
} /* get_mcover */
/*********************************************************************/
double get_mcover(dMcover, accident, ply_bgn, icar_type, Haccident)
$double dMcover;
$char *accident, *ply_bgn, *icar_type, *Haccident;
{
  int     accident_y, accident_m, accident_d, ply_bgn_y, ply_bgn_m, ply_bgn_d;
  long iHaccident;
  $int    iMonths;
  $double dRate;
  char    buf_y[4], buf_m[3], buf_d[3];

  printf("INTO &&&&& get_mcover() mcover:[%f], daccident:[%s], ply_bgn:[%s], icar_type:[%s] &&&&&\n", dMcover, accident, ply_bgn, icar_type);

  /* ***** step-1 ***** */
  /*
  buf[2] = '\0';
  strncpy(buf, accident,   2); accident_y = atoi(buf);
  strncpy(buf, accident+3, 2); accident_m = atoi(buf);
  strncpy(buf, accident+6, 2); accident_d = atoi(buf);
  */
  cm_split_ymd_100(accident, buf_y, buf_m, buf_d);
  accident_y = atoi(buf_y);
  accident_m = atoi(buf_m);
  accident_d = atoi(buf_d);
  iHaccident = atoi(Haccident);

  /*
  strncpy(buf, ply_bgn,   2);   ply_bgn_y = atoi(buf);
  strncpy(buf, ply_bgn+3, 2);   ply_bgn_m = atoi(buf);
  strncpy(buf, ply_bgn+6, 2);   ply_bgn_d = atoi(buf);
  */
  cm_split_ymd_100(ply_bgn, buf_y, buf_m, buf_d);
  ply_bgn_y = atoi(buf_y);
  ply_bgn_m = atoi(buf_m);
  ply_bgn_d = atoi(buf_d);

  iMonths = accident_y * 12 + accident_m - ply_bgn_y * 12 - ply_bgn_m;

  if(accident_d > ply_bgn_d) iMonths++;
  printf("\niHaccident[%d]\n",iHaccident);
  printf("accident_d==>[%d]  ,  ply_bgn_d==>[%d]\n",accident_d,ply_bgn_d);
  if(accident_d == ply_bgn_d && iHaccident >= 12) iMonths++;

  /* ***** step-2 ***** */
  $SELECT a.pdepreciate
     INTO $dRate
     FROM depreciation_rate a, car_type b
    WHERE b.fclass = '1' AND b.icode = $icar_type AND 
          a.fcar_class = b.fcar_class AND a.qperiod_end >= $iMonths AND 
          a.qperiod_bgn < $iMonths;

  if(SQLCODE == SQLNOTFOUND){
     dRate = 0;
     printf(" &&&&& get_mcover error: SQLNOTFOUND &&&&&\n");
  }

  return dMcover * (1 - dRate/100);

errexit:
  printf("get_mcover[errexit]:SQLCODE[%d],errstr[%s]\n",SQLCODE,sqlca.sqlerrm);
  return dMcover;
} /* get_mcover */

/************************************************************************/
char *get_mdeduct(DBname, Icar_type, ideduct)
$char *DBname, *Icar_type, *ideduct;
{
   $char sFullName[20], sStmt[1024];
   $long mdeduct;
   $static char  mdeduct_c[40];

  printf("-----get_mdeduct------\n");
  printf("DBname=%s,icar_type=%s,ideduct=%s...\n",DBname,Icar_type,ideduct);
   strcpy(sFullName, get_full_dbname(DBname));
   sprintf_s(sStmt,sizeof sStmt, "SELECT mdeduct \
                     FROM %s:ca_dmg_mdeduct \
                    WHERE icar_type = '%s' AND ideduct='%s' ",
           sFullName,Icar_type,ideduct);
   $PREPARE g_1 FROM $sStmt;
   $DECLARE g_cursor CURSOR FOR g_1;
   $OPEN g_cursor;
   $FETCH g_cursor INTO $mdeduct_c;
   $WHENEVER SQLERROR GOTO errexit;

   if (SQLCODE == SQLNOTFOUND)
        strcpy(mdeduct_c,ideduct);

   printf("mdeduct_c=%s...\n",mdeduct_c);
   $CLOSE g_cursor;
   $FREE  g_cursor;

   return mdeduct_c;

errexit:
  printf("get_mdeduct:sqlcode[%ld] sqlerrm[%s]",SQLCODE,sqlca.sqlerrm);
  return NULL;
} /* get_mdeduct */

/*************************************************************************/
 /*------get chinese for insurance_type-----*/
int get_nins_abbr(iins_type, nins_abbr)
$char nins_abbr[13], *iins_type;
{
  $WHENEVER SQLERROR GOTO abbr_err;

  $SELECT nins_abbr
     INTO $nins_abbr
     FROM insurance_type
    WHERE iins_type = $iins_type;
  if(SQLCODE == SQLNOTFOUND) nins_abbr[0] = '\0';

  return SQLCODE;

abbr_err:
  return SQLCODE;
}

/************************************************************************/
/*********************************************************************/
/*** �� settlement_object �� customer_basic_inf table Ū�����     ***/
/*** mark:�Ƶ���    nchi_abv:����²��                              ***/
/*********************************************************************/
int get_stl_obj(ifpce_id, nchi_abv, mark)
$char *ifpce_id, nchi_abv[13], mark[11];
{
  $WHENEVER SQLERROR GOTO errexit;

  $SELECT a.mark, b.nchi_abv
     INTO $mark,  $nchi_abv
     FROM settlement_object a, customer_basic_inf b
    WHERE a.ifpce_id=$ifpce_id
      AND a.ifpce_id=b.ifpce_id;
   printf ("sqlcode %d ",SQLCODE);
  if(SQLCODE == SQLNOTFOUND) {
      printf ("test");
        nchi_abv[0] = '\0';
        mark[0] = '\0';
  }
  return SQLCODE;

errexit:
  return SQLCODE;
}

/******************************************************************/ 
/** get_policy_db                                                **/
/** ��ca_clm_process �o�� ibranch_in                             **/
/**                                                              **/ 
/******************************************************************/ 
int get_policy_db(iclaim, ipolicy, ibranch_in)
$char *iclaim, *ipolicy, ibranch_in[6];
{
      
  printf ("in get_policy_db\n");
  printf ("iclaim[%s], ipolicy[%s]\n", iclaim, ipolicy);
  $WHENEVER SQLERROR GOTO errexit;
  $SELECT ibranch_in
     INTO $ibranch_in
     FROM ca_clm_process
    WHERE iclaim matches $iclaim
      AND ipolicy matches $ipolicy;
 
 if(SQLCODE == SQLNOTFOUND) {
    ibranch_in[0] = '\0';
  }
  return SQLCODE;

errexit:
  return SQLCODE;
}

/**  car_get_pahist Ū���ˮ`�I���ӳ̷s���  **/

int car_get_pahist(pDBSite, pIpolicy, pDaccident, pInsPa )
$char *pDBSite;
$char *pIpolicy;
$char *pDaccident;
struct ipa_hist **pInsPa;
{
  struct ipa_hist  *p, *s;
  $char sIins_type[INSURANCE_TYPE], stmt[500], stmt1[512], sWhereStr[80];
  short count=0, first=1;
  $char sIpolicy[POLICY_NUM_1], sIendorse[ENDORSE_NUM];
  $char sIinsurant[11], sNinsurant[31], sIins_scope[2], sIcareer[2];
  $long lDedr_begin, lDedr_end, lBirth;
  $char sFedr_status[3];
  $long lDendorse;
  $int  lMins_premium;
  $int  daily_pay;
  $int  lMins_amt;
  char  sFullName[20];

  strcpy(sFullName, get_full_dbname(pDBSite));

printf("&&&&& car_get_pahist: DBSite:[%s], FullDBName:[%s], Policy:[%s], Daccident:[%s] &&&&&\n",
        pDBSite, sFullName, pIpolicy, pDaccident);

  if(*pDaccident == '\0')
    strcpy(sWhereStr, "");
  else
    strcpy(sWhereStr, "AND dedr_begin <= ? AND dedr_end >= ? ");

  $WHENEVER SQLERROR GOTO errexit;
  *pInsPa = (struct ipa_hist *) calloc(1, sizeof(struct ipa_hist));

  sprintf_s(stmt1,sizeof stmt1, "SELECT iinsurant , iins_scope , icareer , ninsurant , dbirth \
                    FROM %s:ca_pa_ply \
                   WHERE ipolicy = '%s' ORDER BY iinsurant",
                   sFullName, pIpolicy );

  $PREPARE pa_cur FROM $stmt1;
  $DECLARE pa CURSOR FOR pa_cur;
  $OPEN pa;
  for(;;)
  {

      $FETCH pa INTO $sIinsurant , $sIins_scope , $sIcareer , $sNinsurant , $lBirth;
      if( SQLCODE == SQLNOTFOUND ) break;

      sprintf_s(stmt,sizeof stmt, "SELECT iins_type ,dedr_begin, dedr_end, fedr_status, dendorse, \
                            mins_amt , mins_premium ,daily_pay \
                       FROM %s:ca_pa_ply_hist \
                      WHERE ipolicy = '%s' AND iinsurant = '%s' \
                        AND iins_scope = '%s' AND icareer = '%s' %s \
                      ORDER BY dedr_begin DESC, dendorse DESC, fedr_status DESC",
                      sFullName, pIpolicy, sIinsurant, sIins_scope, sIcareer, sWhereStr);

      $PREPARE p1 FROM $stmt;
      $DECLARE pa_cursor CURSOR FOR p1;
      if(*pDaccident == '\0')
         $OPEN pa_cursor;
      else
         $OPEN pa_cursor USING $pDaccident, $pDaccident;

      while(1)
      {
         $FETCH pa_cursor INTO $sIins_type, $lDedr_begin, $lDedr_end, $sFedr_status, $lDendorse,
                               $lMins_amt,   $lMins_premium,$daily_pay;

         if( SQLCODE == SQLNOTFOUND ) break;

         if(first)
           p = *pInsPa;
         else
           p = (struct ipa_hist *)calloc(1, sizeof(struct ipa_hist));

         count++;
        /* ***** Put data into structure ***** */
        strcpy(p->ipolicy, pIpolicy);
		strcpy(p->iins_type, sIins_type);
        strcpy(p->iinsurant, sIinsurant);
        p->iins_scope = sIins_scope[0];
        p->icareer = sIcareer[0];
        strcpy(p->ninsurant, sNinsurant);
        p->dbirth = lBirth;
        p->dedr_begin = lDedr_begin;
        p->dedr_end = lDedr_end;
        strcpy(p->fedr_status, sFedr_status);
        p->dendorse = lDendorse;
        p->mins_amt = lMins_amt;
        p->mpremium = lMins_premium;
        p->daily_pay = daily_pay;
        p->next = NULL;

        /* *****         End             ***** */
        /* ***** Make a linked list for ply_ins_type_hist data ***** */
        if(first)
          first = 0;
        else
          s->next = p;

        s = p;
        break;

      }
      $CLOSE pa_cursor;
      $FREE  pa_cursor;

  }
  $CLOSE pa;
  $FREE  pa;

  if(count)
    return 0;
  else
    return -1;
	
errexit:
  
  return SQLCODE;

}

long get_adjust_21(dDacc,mdamcover3)
$long dDacc;
$long mdamcover3;
{
   /* 38411   -> 03/01/2005  */

   if ((dDacc >= 38411) && (mdamcover3 == 1400000))
   {
      mdamcover3 = 1500000;
   } 
   return mdamcover3;
}

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[31];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}

