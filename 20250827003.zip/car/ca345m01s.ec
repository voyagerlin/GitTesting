/**********************************************************************/
/*   program id   : ca345m01s.ec                                      */
/*   program name : �j���I�n�O�ѤΦ��ڦL�s�@�~                        */
/*   date written : 2014/05/12                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : Larry Liao                                        */
/*   pdf          : �j���I�n�O�Ѧs�d�p.pdf                            */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "carmsgs.h" 
#include "commsgs.h" 
#include "cmnmsgs.h" 
#include "gls_array.h" 
#include "gls_const.h"
#include "sqlfatal.h"
#include "safeclib.h"

#define direct_disc_98    "(���O��w�ɦ�������O���O�O�u�f)"

char  	outputf[ N_FILE+1];
char    option1[2],option2[2],interval_bgn[21],interval_end[21], ientry[11], check1[2], check2[2] ,fclass[2];
$char   sDpolicy_bgn[21],sDpolicy_end[21];
$char   sIpolicy_bgn[21],sIpolicy_end[21];
$char   sTemp1[256], sTemp2[512], sTemp3[256], sTemp4[256], sTemp5[256], sTemp6[256], sTemp7[256], sTemp8[256] , sTemp55[256], sTemp77[256];
$char   date[11],dToday[11],nyy[4],nmm[3],ndd[3];
$char  	userid[11];
$int    PgLine;
char    OutFile[31];
int     max_count;

$char	DBName[5];
$char FormTp[3];
DBinfo  *list;
static Today;
    
int    flen,count_db = 0,i,j,count;
FILE   *fp;
char   sApHome[30];
$char	 ftitle[1024];

$char	v_sMsg[1024],sErrMsg[1024];
char	msgbuf[100];
$char   Full_DB_ilastply[20];

/* �j�� */
$char ipolicy1[21], ipolicy2[21], sIpolicy1[21], sIpolicy2[21], icard1[21];
$char sIcard_bgn[21], sIcard_end[21];
$char irelative_ply[21], ilast_card[21], barcode[21], xqperiod[3], dpolicy[8];	  
$char dply_begin[8], dply_end[8], ilicense[11], dbirth[10], Nofficer[21];
$char fsex[2],ncar_abbr[14],iissue_ym[6], iissue_y[4], itag[CA_TAG_NUM], iassured[11];
$char mpremium_buf[20], ichk_num[2], xqcylinder[9];
$varchar nassured[121], aassured[91], apayment[91], iquery_num[121];
$int  qperiod, mpremium, qdrunk_driving;
$double qcylinder;
$char icar_type[4],ibrand[10],nbrand_abbr[14],ibody[CA_BODY_NUM],iengine[CA_ENGINE_NUM];
$char fmarriage[4], irelative_card[20], xqdrunk_driving[11];
int   tmp_prem,other_prem;
$char fcomp_class[3], fcomp_class_last[3];
$char iofficer[11], ileader[10], Nleader[21];
$char ibranch[7],sIbranch[11], Nbranch[19], ch_amt[40];
$char ch_amt01[40], ch_amt02[40], ch_amt03[40], ch_amt04[40], ch_amt05[40] ,Isign[11],Ientry[11],iscan_no[26],ireg_no[21];
$char Iroute1[21],bzfrom[3],nreg_no[41],itmp_policy[21],ilast_ply[21],dply_end_last[8],itmp_code[4];

/* ���N */
$char sIpolicy2[21], dpolicy2[11], dply2_begin[11], dply2_end[11];
$varchar nassured2[121],s_real_premium[256],eb_premium2[256];
$char iout_number[12], sIout_number[14], itag2[CA_TAG_NUM], mpremium2_buf[20], iofficer2[11];
$char iextra_charge[11], Nofficer2[11], Nleader2[11], ntarget2[3] ,Napplicant2[121];
$char npresident[11], tax_area[11], tax_area1[3], tax_area2[3], site2[3];
$char sIpolicy2_1[6], sIpolicy2_2[18], ireceipt[11], sDcreate2[24], dcreate[20];
$char Nbranch2[40] , Iroute2[21] , Nroute2[41] , Nsales2[11] ,magycom2_tmp[20],magycom2_tmp1[20];
$int  mpremium2, sNtarget2;     
$int magycom2;                            
long  t, sIreceipt;
static char *get_car_full_db();

void car345_clear();
/*----------------------------------------------------------------------------*/
long car345(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car345_print();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
   case 'P': rtncode=car345_print(reply);
             break;
            
   default :
            if(exitsub(reply,M_CM_WRONG_OPTION) == True)
              return M_CM_WRONG_OPTION;
            return apiRC;
 }
  return(rtncode);
}
/*----------------------------------------------------------------------------*/
long car345_print(reply)
serverReply reply;
{
	  $char stmt[4096], stmt1[4096], sStmt1[4096], sStmt2[4096], sStmt3[512], sStmt4[512],stmtA[512];
	  char  filename[512], fname[512], errmsg[512];
	  char  yy1[4],mm1[3],dd1[3],yy2[4],mm2[3],dd2[3];
	  $int  sCount;
	  int	  tmp_len, rc, cnt;
	  time_t now;
	  $char dply_close[11];
	  $char talbe_ply[20],talbe_ply_relation[20];
	  $char s_iofficer[11];
	  
    $WHENEVER SQLERROR GOTO errexit;
    
    cm_buf_get("%s %s %s %s",DBName, userid, option1, ibranch);
    cm_buf_get("%s %s %s %s %s %s %s %s", option2, interval_bgn, interval_end, ientry, s_iofficer, check1, check2, fclass);
    
    if (db_select(DBName) == False)
    {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
         return M_CM_DB_NOTOPEN;
      else
         return apiRC;
    }
         
    rc = car_get_db();
    if (rc != M_CM_OK) {
        printf("error on car_get_db\n");
        return rc;
    }
    
    printf("----- 134 car345_print -----\n");
                   
    /* option1 : 0 - ����� , 1 : �D����� */
    if (strncmp(option1,"0",1) == 0)
        strcpy(sTemp1," AND LEFT(b.iroute,2) = 'JB' ");
    else if (strncmp(option1,"1",1) == 0)	
    	  strcpy(sTemp1," AND LEFT(b.iroute,2) != 'JB' ");
    else
    	  strcpy(sTemp1," ");
    	  
    /* check1 : 0 - �ư��F����� , 1 : �����F����� */
    if (strncmp(check1,"0",1) == 0){
        strcpy(sTemp4," AND NOT EXISTS (SELECT 'a' FROM car_code \
                                         WHERE kind = 'SR' AND detail = b.iroute AND detail2 = a.iofficer)");
    }
    else{
    	  strcpy(sTemp4," AND EXISTS (SELECT 'a' FROM car_code \
                                     WHERE kind = 'SR' AND detail = b.iroute AND detail2 = a.iofficer)");
    }
    if (strncmp(check2,"0",1) == 0){
        strcpy(sTemp6," AND a.ipolicy[6,7] != 'EB'");
    }
    else{
    	strcpy(sTemp6," AND a.ipolicy[6,7] = 'EB'");
    }
    
    if (strncmp(ientry,"*",1) == 0){
        strcpy(sTemp7," ");
    }
    else{
    	sprintf_s(sTemp7, sizeof sTemp7," AND a.ientry = '%s'",ientry);
    }
    
    if (strncmp(s_iofficer,"*",1) == 0){
        strcpy(sTemp77," ");
    }
    else{
    	sprintf_s(sTemp77, sizeof sTemp77," AND a.iofficer = '%s'",s_iofficer);
    }
    
    if (strncmp(fclass,"1",1) == 0){
        strcpy(sTemp8,"AND a.fout_print = '1' AND a.fmail_type != '0' AND a.feply <> '1' AND a.icard[3,4] NOT IN ('C2','M2')");
    }
    else if (strncmp(fclass,"2",1) == 0){
    	/*�ư�B�BJ�g��Υ��x��O*/
    	strcpy(sTemp8,"AND a.feply = '1' AND a.fout_print = '0' AND iofficer[1] NOT IN ('B','J') AND ientry <> 'TRADE/SYS' AND iexaminer <> 'TRADE/SYS' AND a.icard[3,4] NOT IN ('C2','M2')");
    }
    else if (strncmp(fclass,"3",1) == 0){
    	/* C2/M2�@�ߦL�X���ެO�_�j��q�l���� */
    	strcpy(sTemp8,"AND a.icard[3,4] IN ('C2','M2')");
    }
    else if (strncmp(fclass,"4",1) == 0){
    	/* �ȥ� */
    	strcpy(sTemp8,"AND a.fout_print = '0' AND a.fmail_type = '0' AND a.feply <> '1' AND a.icard[3,4] NOT IN ('C2','M2') ");
    }
    else{
    	strcpy(sTemp8,"AND ((a.feply = '1' AND a.fout_print = '0' AND iofficer[1] NOT IN ('B','J') AND ientry <> 'TRADE/SYS' AND iexaminer <> 'TRADE/SYS') OR (a.fout_print = '1' AND a.fmail_type != '0' AND a.feply <> '1')) AND a.icard[3,4] NOT IN ('C2','M2') ");
    }
    
    /* option2 : 0 - ñ���� , 1 - �O�渹�X , 2 - �j���Ҹ� */
    /* 103/06/09 ���e�A�O��(�e�~��)���ڤW���i�e�~�O��Ǹ��j���ťաA���i�C�L */ 
    if (strncmp(option2,"0",1) == 0) {
        strcpy(sDpolicy_bgn, cm_to_infdate(interval_bgn));
        strcpy(sDpolicy_end, cm_to_infdate(interval_end)); 
        printf("--ñ��_��G[%s] , ñ�樴��G[%s] --\n-----", sDpolicy_bgn, sDpolicy_end);
        sprintf_s(sTemp2, sizeof sTemp2,"AND a.dpolicy BETWEEN '%s' AND '%s' ",sDpolicy_bgn, sDpolicy_end);
        sprintf_s(sTemp3, sizeof sTemp3,"AND b.dpolicy BETWEEN '%s' AND '%s' ",sDpolicy_bgn, sDpolicy_end);
        if (strncmp(fclass,"2",1) == 0 || strncmp(fclass,"3",1) == 0 || strncmp(fclass,"4",1) == 0){
        	strcpy(sTemp5," ");
        	strcpy(sTemp55," ");
        }
        else{
        	strcpy(sTemp5,"AND a.dout_trans is not null ");
        	strcpy(sTemp55,"AND b.dout_trans is not null ");
        }
    }
    else if (strncmp(option2,"1",1) == 0){
    	  strcpy(sIpolicy_bgn, trim(interval_bgn));
   		  strcpy(sIpolicy_end, trim(interval_end));
    	  printf("--�O��_���G[%s] , �O�樴���G[%s] --\n-----", sIpolicy_bgn, sIpolicy_end);
    	  sprintf_s(sTemp2, sizeof sTemp2,"AND a.ipolicy BETWEEN '%s' AND '%s' AND a.dpolicy >= '06/09/2014' ",sIpolicy_bgn, sIpolicy_end);
    	  strcpy(sTemp3,"AND b.dpolicy >= '06/09/2014' ");
    	  if (strncmp(fclass,"2",1) == 0 || strncmp(fclass,"3",1) == 0 || strncmp(fclass,"4",1) == 0){
        	strcpy(sTemp5," ");
        	strcpy(sTemp55," ");
          }
          else{
        	strcpy(sTemp5,"AND a.dout_trans is not null ");
        	strcpy(sTemp55,"AND b.dout_trans is not null ");
         }
    }
    else if (strncmp(option2,"2",1) == 0){
    	  strcpy(sIcard_bgn, trim(interval_bgn));
        strcpy(sIcard_end, trim(interval_end));
    	  printf("--�j���Ҹ�(�_)�G[%s] , �j���Ҹ�(��)�G[%s] --\n-----", sIcard_bgn, sIcard_end);
    	  sprintf_s(sTemp2, sizeof sTemp2,"AND a.fcard_class = '1' AND a.dpolicy >= '06/09/2014' "
    	                 "AND a.icard BETWEEN '%s' AND '%s' ",sIcard_bgn, sIcard_end);
    	  strcpy(sTemp3,"AND b.dpolicy >= '06/09/2014' ");
    	  if (strncmp(fclass,"2",1) == 0 || strncmp(fclass,"3",1) == 0 || strncmp(fclass,"4",1) == 0){
        	strcpy(sTemp5," ");
        	strcpy(sTemp55," ");
          }
          else{
        	strcpy(sTemp5,"AND a.dout_trans is not null ");
        	strcpy(sTemp55,"AND b.dout_trans is not null ");
          }
    }
    else {
        strcat(interval_bgn,"/00:00:00");
        strcat(interval_end,"/23:59:59");
        strcpy(sDpolicy_bgn,cm_sysd_edatetime(interval_bgn));
        strcpy(sDpolicy_end,cm_sysd_edatetime(interval_end));
        printf("--�e�~�C�L�_��G[%s] , �e�~�C�L����G[%s] --\n-----", sDpolicy_bgn, sDpolicy_end);
        sprintf_s(sTemp2, sizeof sTemp2,"AND a.dout_trans BETWEEN '%s' AND '%s' AND a.dpolicy >= '06/09/2014' ",sDpolicy_bgn, sDpolicy_end);
        sprintf_s(sTemp3, sizeof sTemp3,"AND b.dout_trans BETWEEN '%s' AND '%s' AND b.dpolicy >= '06/09/2014' ",sDpolicy_bgn, sDpolicy_end);  
        strcpy(sTemp5," ");
        strcpy(sTemp55," ");
    }
    
    time(&now);
    sprintf_s(fname, sizeof fname,"applicant_%s%s%ld.txt",DBName,userid,now);
    sprintf_s(filename, sizeof filename,"%s/rptftp/%s",sApHome,fname);
    fp=fopen(filename,"w");
    
    count = 0;               
    for(i=0;i<count_db;i++) 
    {    	 
    	 /* �i�e�~��j�O�渹�X */
    	 printf("-------------------------DBName[%s]\n",list[i].dbname);
       sprintf_s(stmt, sizeof stmt,"SELECT DISTINCT CASE WHEN a.fcard_class = '1' THEN a.ipolicy "
                    "                ELSE a.irelative_ply END, "
                    "                CASE WHEN a.fcard_class = '2' THEN a.ipolicy "
                    "                ELSE a.irelative_ply END, a.dply_close , b.itag "
                    "  FROM %s:ori_ply_relation a , %s:original_ply b "
                    " WHERE a.ipolicy = b.ipolicy "
                    "   AND a.ibranch = '%s'    "
                    "   AND a.fcard_class = '1' "
                    "   AND a.dply_close is not null "
                    "   %s %s %s %s %s %s %s %s union ",list[i].dbname, list[i].dbname, ibranch ,sTemp1, sTemp2, sTemp4, sTemp5 , sTemp6, sTemp7, sTemp8, sTemp77);
      sprintf_s(stmt1, sizeof stmt1,"SELECT DISTINCT CASE WHEN a.fcard_class = '1' THEN a.ipolicy "
                    "                ELSE a.irelative_ply END, "
                    "                CASE WHEN a.fcard_class = '2' THEN a.ipolicy "
                    "                ELSE a.irelative_ply END, a.dply_close , b.itag "
                    "  FROM %s:ply_relation a , %s:policy b "
                    " WHERE a.ipolicy = b.ipolicy "
                    "   AND a.ibranch = '%s'    "
                    "   AND a.dply_close is null "
                    "   AND a.fcard_class = '1' "
                    "   %s %s %s %s %s %s %s %s"
                    " ORDER BY 2 ",list[i].dbname, list[i].dbname, ibranch ,sTemp1, sTemp2, sTemp4, sTemp5 ,sTemp6, sTemp7, sTemp8, sTemp77);              
      strcat(stmt,stmt1); 
      printf("-----stmt[%s]-----\n",stmt);               
      $PREPARE ply_num FROM $stmt;
      $DECLARE policy_cur CURSOR FOR ply_num;
      $OPEN    policy_cur;
         
      for(;;)
      {  	  
         strcpy(dply_close,"");
         $FETCH policy_cur INTO $ipolicy1, $ipolicy2 ,$dply_close;       
         if (SQLCODE == SQLNOTFOUND) break;
          
         printf("+++++++++dply_close[%s]\n",dply_close); 
         if(strlen(dply_close)>0)
         {
         	strcpy(talbe_ply,"original_ply");
         	strcpy(talbe_ply_relation,"ori_ply_relation");         	
         }
         else
         {
         	strcpy(talbe_ply,"policy");
         	strcpy(talbe_ply_relation,"ply_relation");  
         } 
         count++;
         car345_clear();
         /* �j��O�� - �n�O������� */	
         sprintf_s(sStmt1, sizeof sStmt1,"SELECT a.ipolicy, b.icard, a.nassured, a.aassured, b.icar_type, "
                      "         year(a.dissue)-1911, a.itag, a.iengine, a.nbrand_abbr, b.ibrand, "
                      "         a.qcylinder, a.ibody, "
                      "         year(b.dply_begin)-1911||to_char(b.dply_begin,'%%m%%d'), "
                      "         year(b.dply_end)-1911||to_char(b.dply_end,'%%m%%d'), "
                      "         b.qply_period, a.ilicense, a.iquery_num, b.qdrunk_driving, "
                      "         year(a.dbirth)-1911||to_char(a.dbirth,'%%m%%d'), "
                      "         a.fsex, year(b.dpolicy)-1911||to_char(b.dpolicy,'%%m%%d'), "
                      "         b.ilast_card, a.fmarriage, b.mlia_prem, b.iofficer, "
                      "         a.iassured, b.ileader, b.iquota[1,4]||'00' ibranch, "
                      "         b.fcomp_class, b.fcomp_class_last, b.irelative_ply, "
                      "         (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
                      "         (SELECT nname FROM officer WHERE iofficer = b.ileader), "
                      "         (SELECT ncode FROM car_type WHERE icode = b.icar_type AND fclass = '1'), "
                      "         b.isign,b.ientry,b.iscan_no,b.ireg_no,a.iroute,b.bzfrom,b.itmp_policy,b.ilast_ply, "
                      "         case WHEN b.itmp_policy[5,7]='CVQ' OR b.itmp_policy[1,3]='17N'  THEN 'CVQ' else b.itmp_policy[6,7] END "
                      "    FROM %s:%s a, %s:%s b "
                      "   WHERE a.ipolicy = b.ipolicy "
                      "     AND a.ipolicy = '%s' "
                      "     AND b.fcard_class = '1' "
                      "     %s %s",list[i].dbname,talbe_ply,list[i].dbname,talbe_ply_relation,ipolicy1,sTemp3,sTemp55);
         printf("-----sStmt1[%s]-----\n",sStmt1);
         $PREPARE policy1_cur FROM $sStmt1;     
         $EXECUTE policy1_cur INTO $sIpolicy1, $icard1, $nassured, $aassured, $icar_type,   
                                   $iissue_ym, $itag, $iengine, $nbrand_abbr, $ibrand, 
                                   $qcylinder, $ibody, $dply_begin, $dply_end, $qperiod, 
                                   $ilicense,  $iquery_num, $qdrunk_driving, $dbirth,
                                   $fsex, $dpolicy, $ilast_card, $fmarriage, $mpremium,     
                                   $iofficer, $iassured, $ileader, $sIbranch, $fcomp_class, 
                                   $fcomp_class_last, $irelative_ply, $Nofficer, $Nleader, 
                                   $ncar_abbr,$Isign,$Ientry,$iscan_no,$ireg_no,$Iroute1,$bzfrom,$itmp_policy,$ilast_ply,
                                   $itmp_code;
         if (SQLCODE == SQLNOTFOUND)       
         {              
             printf("---�L�j��O��,����������N : [%s]\n", ipolicy2);
         }
         else 
         {
                 
             /* �j�����ˬd�X */
             $SELECT ichk_num INTO $ichk_num
                FROM compulsory_card
               WHERE icard = $icard1;
             if (SQLCODE == SQLNOTFOUND) strcpy(ichk_num," ");
          
             sprintf_s(stmt, sizeof stmt,"SELECT icard "
                          "  FROM %s:%s "
                          " WHERE ipolicy = '%s' ",list[i].dbname,talbe_ply_relation,irelative_ply);
             $PREPARE ply_data FROM $stmt;
	           $DECLARE plycard_cur CURSOR FOR ply_data;
	           $OPEN    plycard_cur;
	           $FETCH   plycard_cur INTO $irelative_card;
	           if (SQLCODE == SQLNOTFOUND) strcpy(irelative_card, " ");
	           $CLOSE plycard_cur;
	           $FREE  plycard_cur;
                           
             /* �Y���������ŭ�,�h�L�X������ */
             if(strlen(trim(iengine)) == 0) strcpy(iengine,ibody);
       
             strcpy(iissue_y,iissue_ym);     /* �o�Ӧ~�� */
	     iissue_y[3]=0;
		     
	     strcpy(xqperiod,itoa(qperiod)); /* �ӫO��� */
		     
	     strcpy(barcode,"17");
	     strcat(barcode,trim(icard1));
	
	     sprintf_s(xqcylinder, sizeof xqcylinder, "%5.2f", qcylinder);/* �Ʈ�q */
	     strcpy(xqdrunk_driving, itoa(qdrunk_driving)); /* �s�r���� */
		     	 	           
             if(mpremium == 0)  /* �O�O */
             {				  
	         strcpy(ch_amt01," ");		/* �U */
		 strcpy(ch_amt02," ");		/* �d */
		 strcpy(ch_amt03," ");		/* �� */
		 strcpy(ch_amt04," ");		/* �B */
		 strcpy(ch_amt05," ");		/* �� */				
	     }
             else
	     {
                 strcpy(mpremium_buf,refmtamt(mpremium,MILLIONTH));
                 tmp_prem=mpremium/10000;
                 other_prem=mpremium%10000;
                 num_to_chinese(ch_amt,tmp_prem); /* �N���ԧB�Ʀr �ন ����j�g�Ʀr */
                  
                 if (tmp_prem==0) strcpy(ch_amt,"�s");           	     	 
                 strcpy(ch_amt01, ch_amt);
                 strcpy(ch_amt01, trim(ch_amt01));
             
                 tmp_prem=other_prem/1000;
                 other_prem=other_prem%1000;
                 num_to_chinese(ch_amt,tmp_prem);
             
                 if (tmp_prem==0) strcpy(ch_amt,"�s");
                 strcpy(ch_amt02, ch_amt);
                 strcpy(ch_amt02, trim(ch_amt02));
             
                 tmp_prem=other_prem/100;
                 other_prem=other_prem%100;
                 num_to_chinese(ch_amt,tmp_prem);
                  
                 if (tmp_prem==0) strcpy(ch_amt,"�s");
		 strcpy(ch_amt03,ch_amt);
		 strcpy(ch_amt03, trim(ch_amt03));
             
                 tmp_prem=other_prem/10;
                 other_prem=other_prem%10;
                 num_to_chinese(ch_amt,tmp_prem);
             
                 if (tmp_prem==0) strcpy(ch_amt,"�s");
		 strcpy(ch_amt04,ch_amt);
		 strcpy(ch_amt04,trim(ch_amt04));
               
                 num_to_chinese(ch_amt,other_prem);
                 if (other_prem==0) strcpy(ch_amt,"�s");
		 strcpy(ch_amt05,ch_amt);
		 strcpy(ch_amt05,trim(ch_amt05));
             }
             
             /*����j���I�e������*/
             /*1090608008_SC1_�s�W�n�O�p�C�L�O�_���Ƨ�O�Ψ����r��*/
             strcpy(dply_end_last,"");
             if (strlen(trim(itmp_policy)) == 0)
             {
             	 strcpy(dply_end_last,"");
             	 
             }
             else
             {
                  /*��������*/
                  if(strncmp(trim(itmp_code),"CVQ",3)==0)
                  {
                  	sprintf_s(stmtA, sizeof stmtA,"SELECT nvl(year(dcomp_lastdend)-1911||to_char(dcomp_lastdend,'%%m%%d'),'') FROM %s:ca_quotation WHERE iquote='%s' AND iins_kind_ply='C1' ",list[i].dbname,itmp_policy);
                  	$PREPARE cur4 FROM $stmtA;     
                        $EXECUTE cur4 INTO $dply_end_last;  
                  }
                  /*�պ���*/
                  else if (strncmp(trim(itmp_code),"CP",2)==0)
                  {
                  	sprintf_s(stmtA, sizeof stmtA,"SELECT nvl(year(dcomp_lastdend)-1911||to_char(dcomp_lastdend,'%%m%%d'),'') FROM %s:estimate WHERE iestimate='%s' ",list[i].dbname,itmp_policy);
                  	$PREPARE cur4 FROM $stmtA;     
                        $EXECUTE cur4 INTO $dply_end_last;  
                  }
                  /*���`*/        	
             	  else if(strncmp(trim(itmp_code),"CX",2)==0)
             	  {
             	  	sprintf_s(stmtA, sizeof stmtA,"SELECT nvl(year(dcomp_lastdend)-1911||to_char(dcomp_lastdend,'%%m%%d'),'') FROM newa00:abnormal_ply WHERE iabnormal='%s' ",list[i].dbname,itmp_policy);
             	  	$PREPARE cur4 FROM $stmtA;     
                        $EXECUTE cur4 INTO $dply_end_last;  
             	  }
             	  else
             	  {
             	  	strcpy(dply_end_last,"");
             	  }
             }
             
             if(strlen(trim(dply_end_last)) == 0 && strlen(trim(ilast_ply)) != 0)
             {
                 strcpy(Full_DB_ilastply,"");
                 strcpy(Full_DB_ilastply,get_car_full_db(ilast_ply)); 
                 sprintf_s(stmtA, sizeof stmtA," SELECT nvl(year(dply_end)-1911||to_char(dply_end,'%%m%%d'),'') "
                                "   FROM %s:ply_relation WHERE ipolicy='%s' ",Full_DB_ilastply,ilast_ply);
                 $PREPARE cur5 FROM $stmtA;     
                 $EXECUTE cur5 INTO $dply_end_last;  
             }

             
	 }
	 magycom2 = 0 ;	
	      
	 /* ���N�O�� - ���������*/
	 sprintf_s(sStmt2, sizeof sStmt2,"SELECT a.ipolicy, year(b.dpolicy)-1911||to_char(b.dpolicy,'%%m%%d'), "
		         "      year(b.dply_begin)-1911||TO_CHAR(b.dply_begin,'%%m%%d'), "
		         "      year(b.dply_end)-1911||TO_CHAR(b.dply_end,'%%m%%d'), "
		         "      a.nassured, b.iout_number, a.itag, (b.mdmg_prem+b.mlia_prem) as mprem, "
		         "      b.iofficer, trim(a.iextra_charge), b.dcreate, "
		         "      (SELECT nname FROM officer WHERE iofficer = b.iofficer), "
		         "      (SELECT nname FROM officer WHERE iofficer = b.ileader) , a.napplicant, "
		         "      (SELECT nbranch FROM sa_branch_type WHERE ibranch = (SELECT iquota FROM officer WHERE iofficer = b.ileader)), "
		         "      a.iroute,(SELECT nroute FROM cm_route WHERE iroute = a.iroute), "
		         "      (SELECT nname FROM officer WHERE iofficer = b.ibig_sales), "
		         "      (mdmg_agent+mdmg_commi+mlia_agent+mlia_commi) "
		         " FROM %s:%s a, %s:%s b "
                 "        WHERE a.ipolicy = b.ipolicy "
                 "          AND a.ipolicy = '%s' "
                 "          AND b.fcard_class = '2' "
                 "          %s %s",list[i].dbname,talbe_ply,list[i].dbname,talbe_ply_relation,ipolicy2,sTemp3,sTemp55);
         printf("-----sStmt2[%s]\n-----",sStmt2);                   
         $PREPARE policy2_cur FROM $sStmt2;     
         $EXECUTE policy2_cur INTO $sIpolicy2, $dpolicy2, $dply2_begin, $dply2_end, $nassured2,
                                   $iout_number, $itag2, $mpremium2, $iofficer2, $iextra_charge,
                                   $sDcreate2, $Nofficer2, $Nleader2 , $Napplicant2 , $Nbranch2 , $Iroute2 , $Nroute2 , $Nsales2 , $magycom2;
	 if (SQLCODE == SQLNOTFOUND)       
         {  
             printf("---�L���N�O��,��������j�� : [%s]\n", ipolicy1);
             sNtarget2 = 1;
         }
         else 
         {
         	
	     strncpy(site2,ipolicy2,2);
             site2[2]='\0';
            
             $SELECT npresident,nchi_abv
                INTO $npresident,$tax_area
                FROM branch
               WHERE ibranch = $site2;
             if (SQLCODE == SQLNOTFOUND) 
             {
            	 strcpy(npresident, " ");
            	 strcpy(tax_area,   " ");
             }
                        
             strncpy(tax_area1,tax_area,2);
             tax_area1[2] = '\0';
             strcpy(tax_area2,tax_area+2);
             tax_area2[2] = '\0';
            
             strcpy(mpremium2_buf,refmtamt(mpremium2,MILLIONTH)); 
             sprintf_s(s_real_premium, sizeof s_real_premium,"�O�O %s ", mpremium2_buf);
             sprintf_s(eb_premium2, sizeof eb_premium2,"NT$%s.- ", trim(mpremium2_buf));
             if (strncmp(iextra_charge,"40",2) == 0 )
             {    	
    	         strcat(s_real_premium,direct_disc_98);
             }      
                                    	
             sprintf_s(sIpolicy2_1, sizeof sIpolicy2_1,"17%s",substring(sIpolicy2,1,3));
             strcpy(sIpolicy2_2,substring(sIpolicy2,4,20));
            
             strcpy(dcreate,substring(sDcreate2,1,19));
             $SELECT first 1 ireceipt, ntarget2
                INTO $ireceipt, $ntarget2 
                FROM cm_receipt_log
               WHERE ipolicy = $sIpolicy2
                 AND dprint = $dcreate
               ORDER BY 1;
             if (SQLCODE == SQLNOTFOUND) 
             {
            	strcpy(ireceipt," ");
            	strcpy(ntarget2,"1");
             }               

             strcpy(ntarget2,trim(ntarget2));
             if (strlen(ntarget2) == 0) 
            	 sNtarget2 = 1;
             else
            	 sNtarget2 = atoi(ntarget2);                        
	 }
	 
         strcpy(magycom2_tmp,itoa(magycom2));	
	 sprintf_s(magycom2_tmp1, sizeof magycom2_tmp1,"NT$%s.- ", magycom2_tmp);
	 strcpy(magycom2_tmp1,trim(magycom2_tmp1));	
	 printf("++++++++++++++++++magycom2[%d]  magycom2_tmp1[%s]\n",magycom2,magycom2_tmp1);     
		     /* �P�_���ک�����.�Ƶ���A����ƪ��ܫO��ӫO���e��-��Ƥ��e�G�i2�j 
		        �i�e�~�O��Ǹ��j�ݥ[�W-1�B-2... EX: Z1411300122-1�BZ1411300122-2... */
		        

	 /*���o�~�ȭ�����m�W*/
	 if(  (((ireg_no[3]>='A')&&(ireg_no[3]<='Z')) || ((ireg_no[3]>='a')&&(ireg_no[3]<='z')))   )  /*�ĥ|�X���^��r��*/
	 {
	 	/*�~�ȭ��n���Ҧr��*/
	 	if( strcmp(bzfrom,"10")==0 && strncmp(Iroute1,"KB",2)==0 )   
	 	{
	 		/*�O�o�q��10(KB��)*/
	 		$SELECT FIRST 1 b.nname
	 		   INTO $nreg_no
	 		   FROM cm_salesman_log a,officer b
	 		  WHERE a.ilicence=$ireg_no AND a.icomm_obj=b.icomm_obj AND iofficer=$iofficer;

	 	}
	 	else if ( strcmp(bzfrom,"40")==0 || ((strcmp(bzfrom,"10")==0 && strncmp(Iroute1,"KB",2)!=0))  ) 
	 	{
	 		/*�O�o�q��10(�DKB��)�B�O�o�q��40*/
	 		$SELECT  FIRST 1 nname 
	 		   INTO  $nreg_no
	 		   FROM  officer WHERE iofficer=(SELECT ileader FROM officer WHERE iofficer=$iofficer);
	 		
	 		  
	 	}
	 	else if ( strcmp(bzfrom,"20")==0 && strncmp(Iroute1,"CA",2)==0 )   
	 	{
	 		/*�O�o�q��20(���ӥ�)*/
	 		$SELECT FIRST 1 nname 
	 		   INTO $nreg_no
	 		   FROM ca_big_office 
	 		  WHERE ireg_no=$ireg_no;
	 		
	 	}
	 	else if ( strcmp(bzfrom,"30")==0 || (strcmp(bzfrom,"20")==0 && strncmp(Iroute1,"CA",2)!=0)  )   
	 	{
	 		/*�O�o�q��20(�D���ӥ�)�B�O�o�q��30*/
	 		$SELECT FIRST 1 nsales 
	 		   INTO $nreg_no
	 		   FROM cm_route_sales 
	 		  WHERE ilicence=$ireg_no;
	 		
	 	}
	 	else
	 	{
	 		strcpy(ireg_no,"");
	 	        strcpy(nreg_no,"");
	 		
	 	}	 	
	 	
	 }
	 else
	 {
	 	/*�����Ҧr���Ψ�L*/
	 	strcpy(ireg_no,"");
	 	strcpy(nreg_no,"");
	 	
	 }
		        
		     
         for(j = 1; j <= sNtarget2; j++)
         { 
             strcpy(sIout_number,trim(iout_number));	
             if (j < sNtarget2)
             {              	
                 strcat(sIout_number,"-");
                 strcat(sIout_number,itoa(j));
                 strcpy(sIout_number,trim(sIout_number));
                 printf("*******************************iout_number[%s]\n",sIout_number);
              	
                 sIreceipt = atol(ireceipt);
                 sIreceipt = sIreceipt - sNtarget2 + j;
                 printf("*******************************ireceipt[%ld]\n",sIreceipt);
                 fprintf(fp," \t \t \t \t \t \t \t \t \t");
		 fprintf(fp," \t \t \t \t \t \t \t");
		 fprintf(fp," \t \t \t \t \t \t \t");
		 fprintf(fp," \t \t \t \t \t \t");
		 fprintf(fp," \t \t \t%s\t%s\t%s\t%s\t",dpolicy2,sIout_number,tax_area1,tax_area2);
		 fprintf(fp,"%s\t%s\t%s\t%s\t%s\t%s\t",npresident,sIpolicy2_1,sIpolicy2_2,dply2_begin,dply2_end,nassured2);
		 fprintf(fp,"******(��U��)\t%s\t%s\t%s\t%s\t%s\t%s\t%ld\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t",iofficer2,Nofficer2,Nleader2,itag2,fsex,fmarriage,sIreceipt,Napplicant2,Nbranch2,Iroute2,Nroute2,Nsales2,eb_premium2,magycom2_tmp1);
		 fprintf(fp," \t \t \t \t \t \t \n");
	     }
	     else
	     {
		 if (sNtarget2 > 1)
		 {
		     strcat(sIout_number,"-");
              	     strcat(sIout_number,itoa(sNtarget2));
              	     strcpy(sIout_number,trim(sIout_number));
              	     strcpy(Napplicant2,trim(Napplicant2));
              	     printf("*******************************iout_number[%s]\n",sIout_number);
		 }	
		 fprintf(fp,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t",sIpolicy1,icard1,ichk_num,nassured,aassured,ncar_abbr,nbrand_abbr,Isign,Ientry);
		 fprintf(fp,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t",iissue_y,itag,iengine,dply_begin,dply_end,xqperiod,barcode);
		 fprintf(fp,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t",ch_amt01,ch_amt02,ch_amt03,ch_amt04,ch_amt05,dpolicy,fcomp_class);
		 fprintf(fp,"%s\t%s\t%s\t%s\t%s\t%s\t",ilast_card,irelative_ply,irelative_card,fcomp_class_last,iassured,dbirth);
		 fprintf(fp,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t",xqcylinder,iofficer,Nofficer,dpolicy2,sIout_number,tax_area1,tax_area2);
		 fprintf(fp,"%s\t%s\t%s\t%s\t%s\t%s\t",npresident,sIpolicy2_1,sIpolicy2_2,dply2_begin,dply2_end,nassured2);
		 fprintf(fp,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t",s_real_premium,iofficer2,Nofficer2,Nleader2,itag2,fsex,fmarriage,ireceipt,Napplicant2,Nbranch2,Iroute2,Nroute2,Nsales2,eb_premium2,magycom2_tmp1);
		 fprintf(fp,"%s\t%s\t%s\t%s\t%s\t%s\t%s\n",xqdrunk_driving,iquery_num,icar_type,iscan_no,ireg_no,nreg_no,dply_end_last);
	     }		                                
         }            		     
      }
      $CLOSE policy_cur;
      $FREE  policy_cur;
    }
    
     fclose(fp);
     
     if (count == 0)
     {
        if(exitsub(reply,M_CM_NOT_FOUND) == True)
           return M_CM_NOT_FOUND;
        else
           return apiRC;
     }

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     cm_buf_put("%s",fname);
   
     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
	  fclose(fp);
    printf("<car345_print> sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    if(exitsub(reply,SQLCODE) == True) return SQLCODE;
    else return apiRC;                                          	
}
/*----------------------------------------------------------------------------*/
long car_get_db()
{
    int	rc;
    
    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }
    
    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
    }

    return M_CM_OK;
}
/*----------------------------------------------------------------------------*/
void car345_clear()
{
	  qcylinder = qperiod = mpremium = mpremium2 = qdrunk_driving = 0;
    strcpy(sIpolicy1," "); strcpy(icard1," "); strcpy(nassured," "); 
    strcpy(aassured," ");  strcpy(icar_type," ");
    strcpy(iissue_y," "); strcpy(itag," "); strcpy(iengine," ");      
    strcpy(nbrand_abbr,""); strcpy(ibrand," "); strcpy(ibody," ");  
    strcpy(dply_begin," "); strcpy(dply_end," "); strcpy(ilicense," ");  
    strcpy(dbirth," "); strcpy(fsex," "); strcpy(dpolicy," ");
    strcpy(ilast_card," "); strcpy(fmarriage," "); strcpy(xqcylinder," ");  
    strcpy(iofficer," "); strcpy(iassured,""); strcpy(ileader," ");   
    strcpy(fcomp_class," "); strcpy(fcomp_class_last," ");
    strcpy(irelative_ply," "); strcpy(Nofficer," "); strcpy(Nleader," ");
    strcpy(ncar_abbr," "); strcpy(xqperiod," "); strcpy(barcode," ");
    strcpy(ch_amt01," "); strcpy(ch_amt02," "); strcpy(ch_amt03," ");
    strcpy(ch_amt04," "); strcpy(ch_amt05," "); strcpy(irelative_card," ");
    strcpy(ichk_num," "); strcpy(xqdrunk_driving," "); strcpy(iquery_num," ");
    
    strcpy(dpolicy2," "); strcpy(iout_number," "); strcpy(tax_area1," ");
    strcpy(tax_area2," "); strcpy(sIpolicy2_1," "); strcpy(npresident," ");
    strcpy(sIpolicy2_2," "); strcpy(dply2_begin," "); strcpy(dply2_end," ");
    strcpy(nassured2," "); strcpy(s_real_premium," ");strcpy(iofficer2," ");
    strcpy(Nofficer2," "); strcpy(Nleader2," "); strcpy(itag2," "); 
    strcpy(ireceipt," "); strcpy(Napplicant2," ");  strcpy(magycom2_tmp," "); 
    strcpy(Nbranch2," "); strcpy(Iroute2," "); strcpy(Nroute2," "); 
    strcpy(Nsales2," ");strcpy(magycom2_tmp1," ");strcpy(iscan_no," ");strcpy(ireg_no," ");
    strcpy(Iroute1," ");strcpy(bzfrom," ");strcpy(nreg_no,"");strcpy(itmp_policy," ");
    strcpy(dply_end_last," ");strcpy(itmp_code," ");strcpy(ilast_ply," ");
}
/*----------------------------------------------------------------------------*/
/*char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
        char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
        char sTmp_db_name[21];

        sTmp_db_name[0]='\0';
        if (*sIpolicy != '\0' && *sIpolicy !=' ')
        {
           sTmp_db_name[0]='\0';
           strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
           strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
                  USE_BRANCH_ID));
           strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
        }
  return sTmp_db_name;
}*/
/********************************************************************************/