/************************************************************************************/
/*                                                                                  */
/*      PROGRAM : ca307q03s.ec                                                      */
/*      Modify  :                                                                   */
/************************************************************************************/

#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "cmprint.h"
$include sqlca;
$include sqltypes;
#include <decimal.h>
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"

$char g_sDbName[5];
$char g_sUserId[11],g_ipolicy[21],g_userid2[11];
$char sfilename[41],stitle[1000],outputf[21],sErrmsg[200],dapplicant[31];
$char ipolicy[21],inumber[21],ipolicy1[21],inumber1[21],iupdate[11],iupdate1[11],dupdate[20];
$char iquota[7],nquota[41],nname[11];
$int  mins_premium=0,sunrate=0;
$char    stmt[3000];
char     g_sMsgBuf[1024];
long     rc=0;

int      count_db=0,i=0;
char     sApHome[30];
DBinfo   *list;

       
main (argc, argv)
int argc;
char **argv;
{
    int rtc=0;

    batchinit();

    strcpy(g_sDbName,isNULLstr(argv[1]));
    strcpy(g_sUserId,isNULLstr(argv[2]));
    strcpy(g_ipolicy,isNULLstr(argv[3]));
    strcpy(g_userid2,isNULLstr(argv[4]));
    strcpy(outputf,isNULLstr(argv[5]));

      if ((rtc=car307_init()) != SUCCESS)
        {
           EWRITE(g_sUserId,rtc,g_sMsgBuf);
           return rtc;
        }
      if ((rtc=car307_cacul()) != SUCCESS)
        {
            EWRITE(g_sUserId, rtc, g_sMsgBuf);
            return rtc;
        }
    
      rtc=car307_dtl_rptA();
    
if (rtc != SUCCESS)
  {
        EWRITE(g_sUserId,rtc,g_sMsgBuf);
        return rtc;
  }
    
}

car307_init()
{
    $WHENEVER SQLERROR goto errexit;

    if(db_select(g_sDbName) == False)
    {
     	strcpy(g_sMsgBuf,"DB [%s] : is not opened",g_sDbName);
     	return M_CM_DB_NOTOPEN;
    }

    $CREATE TEMP TABLE car307_tmp
    (
        ipolicy       char(20)    ,                        /*�Q�O�I�H�N��*/
        iquota        char(6) ,
        nquota        char(40)  ,
    	iupdate       char(10)    ,                        /*���ɤH��*/
    	nname         char(10)   ,
        dupdate       char(20)                             /*���ɮɶ�*/
    )WITH NO LOG;

    return SUCCESS;

errexit:
  printf("Steven:err[%ld][%s]\n",SQLCODE,sqlca.sqlerrm);
  sprintf_s(g_sMsgBuf, sizeof g_sMsgBuf,"%s",sqlca.sqlerrm);
  return SQLCODE;
}

car307_cacul()
{

    $WHENEVER SQLERROR goto errexit;
    printf("------------------g_ipolicy[%s]\n",g_ipolicy);
    printf("------------------g_userid2[%s]\n",g_userid2);
        
    sprintf_s(stmt, sizeof stmt, " Select a.ilog_number1,a.ilog_number2,iupdate,dupdate "
                  "  FROM ca_log a "
                  " WHERE a.ipgid = 'car307' "
                  "   AND a.ilog_number1 matches '%s' " 
                  "   AND a.iupdate matches '%s' ",g_ipolicy,g_userid2);             
                      

printf(" stmt[%s] \n\n", stmt);

    $PREPARE P1 FROM $stmt;
    $DECLARE cur_1 cursor for P1;
    $OPEN cur_1;

    for(;;)
    {
	    $FETCH cur_1
	      INTO $ipolicy ,$inumber ,$iupdate ,$dupdate;
	      	           
        if (SQLCODE==SQLNOTFOUND) break;

              
	      $SELECT iquota,nname
	      INTO $iquota,$nname
	      FROM officer
	      WHERE iofficer = $iupdate;

	      $SELECT nbranch 
	      INTO $nquota
	      FROM sa_branch_type 
	      WHERE ibranch = $iquota;
                            
              strcpy(ipolicy1, "�");                       /*���X�Ĥ@�X��0�A�����bexcel show �X*/
              strcat(ipolicy1,trim(ipolicy));                         
              
              strcpy(iupdate1, "�");
              strcat(iupdate1,trim(iupdate));
              
	      $INSERT INTO car307_tmp
	 	 VALUES ($ipolicy1,$iquota ,$nquota ,$iupdate1,$nname ,$dupdate);   /*���ӤW��car307_tmp����*/

    }
    $CLOSE cur_1;
    $FREE cur_1;
    
   
    return SUCCESS;
    
errexit:
  printf("Steven:err[%ld][%s]\n",SQLCODE,sqlca.sqlerrm);
  sprintf_s(g_sMsgBuf, sizeof g_sMsgBuf,"%s",sqlca.sqlerrm);
  return SQLCODE;
}

car307_dtl_rptA()
{
    char tmp[30];

    strcpy(sfilename,"�O��ɵo�C�L�O�� ");

    memset(stmt, 0x00, sizeof(stmt));
   
    sprintf_s(stmt, sizeof stmt," SELECT * FROM car307_tmp ");
                 
    sprintf_s(stitle, sizeof stitle,"�O��ɵo�C�L�O�� \n \t ");
    strcat(stitle,"�O�渹\t���\t���W��\t�C�L�H��ID\t�C�L�H��\t�C�L���\t");

 
    rc = unload_file(outputf," ",sfilename,stitle,stmt);
 
    if (rc != SUCCESS)
    {
        sprintf_s(sErrmsg, sizeof sErrmsg," %s �ɮ׵L�k���� ",sfilename);
        printf("-----IN");
        EWRITE(g_sUserId, rc , sErrmsg);
        exit(1);
    }

    return SUCCESS;

errexit:
  printf("Steven:err[%ld][%s]\n",SQLCODE,sqlca.sqlerrm);
  sprintf_s(g_sMsgBuf, sizeof g_sMsgBuf,"%s",sqlca.sqlerrm);
  return SQLCODE;
}