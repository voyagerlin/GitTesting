/*--------------------------------------------------*/
/*   PROGRAM : ca179m01s.ec by 101314          */
/*   MODIFIER:                                      */
/*                                                  */
/*   DATE    : 2021/09/02                           */
/*--------------------------------------------------*/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include <decimal.h>

#include <stdlib.h>
#include "cmprint.h"
#include "print.h"
#include "is_def.h"
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"


char errbuf[512];
$int count1;
$char getfile[300];
FILE   *fp;
static int   recLen=1024;
static char  *bp;
char delimiter;
int  offset;
int  tmp_len;
/*--------------------------------------------------*/
long car179(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	long rtncode;
	long car179_insert(),car179_single_query(),car179_multiple_query(),car179_update_exec();
	char option;

	cm_buf_init(command);
 	cm_buf_get("%c",&option);
        printf("38:option\n");
 	switch(option)
 	{
	  	case 'A':
    		rtncode=car179_insert(reply);
        	break;
  		case 'Q':
    		rtncode=car179_single_query(reply);
        	break;
  		case 'M':
        	rtncode=car179_multiple_query(reply);
        	break;
  		case 'D':
  		case 'U':
        	rtncode=car179_update_exec(reply,command,com_len);
        	break;
  		default :
    		if(exitsub(reply,M_CM_WRONG_OPTION) == True)
        		return M_CM_WRONG_OPTION;
           	return apiRC;
 	}
 	return(rtncode);
}

/*--------------------------------------------------*/
long car179_insert(reply)
serverReply reply;
{
	$char  DBName[3],option2[3];
	/*������*/	
	$char  irule[12],frule[3],iins_type1[102],iins_type2[102],icar_type[102],iabn_type[8],nrule_text[257],nexception[32],nmessage[257],provision[22],fuw_type[3];
	$char  dcheck1[40],dexpire[40],icreate[12],iupdate[12];
	$char  minjured_cover[40],mdeath_cover[40],mdamage_cover[40],mdeduct[40];
	/*�D��*/
	$char  irule_main[12],nrule_main[55],icreate2[12],iupdate2[12];
	
	int     rows,tmp_len,i;
	long    MsgCode;
	DBinfo  *list;
	int     k,j,is_add_fail=0, api_f;
	$int    chk_code;
	printf("85:\n");
	/* buf_get�����ܼơA���F���(dcreate�Bdupdate)�H�~ */
	cm_buf_get("%s %s",DBName,option2);
	
	cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s", 
	            irule,frule,iins_type1,iins_type2,icar_type,iabn_type,dcheck1, 
	            minjured_cover,mdeath_cover,mdamage_cover,mdeduct,nrule_text,nexception,nmessage, 
	            dexpire,icreate,iupdate,provision,fuw_type,irule_main,nrule_main,icreate2,iupdate2);

	$WHENEVER SQLERROR goto errexit;
	
	if(db_select(DBName) == False)
	{
		if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
			return M_CM_DB_NOTOPEN;
		return apiRC;
	}

	$BEGIN WORK;
	chk_code = 0;

	if(option2[0] == '1')  /*�s�W�D��*/
	{
		printf("121:option=[%s]\n",option2);
		$SELECT count(*)
		   INTO $chk_code
		   FROM ca_check_rule
		  WHERE irule_main = $irule_main;
	}
	else if(option2[0] == '2') /*�s�W������*/
	{
	    $SELECT count(*)
	       INTO $chk_code
	       FROM ca_check_setup a,ca_check_rule b 
	      WHERE a.irule_main = b.irule_main
	        AND a.irule = $irule
	        AND b.irule_main = $irule_main;
	}
	
	if (chk_code > 0)
	{
		$COMMIT WORK;
		return exitsub(reply,M_CM_DUPDATA) ? M_CM_DUPDATA :apiRC;
	}
	
	if(option2[0] == '1')  /*�s�W�D��*/
	{
		$INSERT INTO ca_check_rule (irule_main, nrule_main, icreate, dcreate, iupdate, dupdate)
		                    VALUES ($irule_main,$nrule_main,$icreate,current, "",      NULL);	
		printf("146:option=[%s]\n",option2);
	}
	else if(option2[0] == '2') /*�s�W������*/
	{         	 
		$INSERT INTO ca_check_setup (irule_main, irule, frule, iins_type1, iins_type2, icar_type, iabn_type, dcheck1, 
		                             minjured_cover,mdeath_cover, mdamage_cover, mdeduct, nrule_text, nexception, nmessage, 
		                             dexpire, icreate, dcreate, iupdate, dupdate, provision, fuw_type)
		                     VALUES ($irule_main,$irule,$frule,$iins_type1,$iins_type2,$icar_type,$iabn_type,NULL,
		                             $minjured_cover,$mdeath_cover,$mdamage_cover,$mdeduct,$nrule_text,$nexception,$nmessage,
		                             NULL,    $icreate,CURRENT, $icreate,CURRENT, $provision,$fuw_type);	
	}        

	if(is_add_fail == 3)
	{
		is_add_fail = 1;
	}
	
	printf("123:\n");
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l ",M_CM_OK);
	tmp_len = cm_buf_len(ReplyBuf);
	printf("127:\n");
	api_f = api_OKComplete;
	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
	{
		is_add_fail = 2;
	}

	if( is_add_fail == 1 ) goto errexit;
	if( is_add_fail == 2 )
	{
		$ROLLBACK WORK;
   		return apiRC;
  	}
  	
	$WHENEVER SQLERROR GOTO errexit;
   	$COMMIT WORK;
   	return api_OKComplete;

 errexit:
   	MsgCode = SQLCODE;
   	$WHENEVER SQLERROR CONTINUE;
   	$ROLLBACK WORK;
   	if( SQLCODE != 0) MsgCode = SQLCODE;
   	if(exitsub(reply,MsgCode) == True)
    	return MsgCode;
   	else
    	return apiRC;
}

/*--------------------------------------------------*/
long car179_single_query(reply)
serverReply reply;
{
	$char  DBName[3];
	/*������*/	
	$char  irule[6],frule[2],iins_type1[101],iins_type2[101],icar_type[101],iabn_type[7],nrule_text[256],nexception[31],nmessage[256],provision[21],fuw_type[2];
	$char  dcheck1[11],dexpire[11],icreate[11],dcreate[21],iupdate[11],dupdate[21];
	$long  minjured_cover,mdeath_cover,mdamage_cover,mdeduct;
	/*�D��*/
	$char  irule_main[6],nrule_main[51],icreate_main[11],dcreate_main[21],iupdate_main[11],dupdate_main[21];
	$int   chk_code;
	int    rows=0,tmp_len,first;
	$char  option2[2];

	cm_buf_get("%s %s %s %s",DBName,irule_main,irule,option2);

	printf("166:irule_main[%s],irule[%s] \n",irule_main,irule,option2);
	printf("167:car179_single_query\n");
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

	if(option2[0] == '1')   /*�Ȭd�ߥD�W�h�W��*/
	{
		$SELECT irule_main::char(5), nrule_main, NVL(icreate,' '), NVL(dcreate,' '), NVL(iupdate,' '), NVL(dupdate,' ')
		   INTO $irule_main, $nrule_main, $icreate_main, $dcreate_main, $iupdate_main, $dupdate_main
		   FROM ca_check_rule
		  WHERE irule_main = $irule_main;
		
		if(SQLCODE==SQLNOTFOUND)
		{
			if(exitsub(reply,M_CM_NOT_FOUND) == True) 
				return M_CM_NOT_FOUND;
			else
				return apiRC;
		}	   
	}	
	else  /*�d�ߥ���*/
	{
		$SELECT a.irule::char(5),a.frule,a.iins_type1,a.iins_type2,a.icar_type,a.iabn_type,a.dcheck1,
		        a.minjured_cover,a.mdeath_cover,a.mdamage_cover,a.mdeduct,a.nrule_text,a.nexception,a.nmessage,
		        a.dexpire,a.icreate,a.dcreate,a.iupdate,a.dupdate,a.provision,a.fuw_type,
		        b.irule_main::char(5),b.nrule_main,b.icreate,b.dcreate,b.iupdate,b.dupdate
		   INTO $irule,$frule,$iins_type1,$iins_type2,$icar_type,$iabn_type,$dcheck1,
		        $minjured_cover,$mdeath_cover,$mdamage_cover,$mdeduct,$nrule_text,$nexception,$nmessage,
		        $dexpire,$icreate,$dcreate,$iupdate,$dupdate,$provision,$fuw_type,
		        $irule_main,$nrule_main,$icreate_main,$dcreate_main,$iupdate_main,$dupdate_main
		   FROM ca_check_setup a, ca_check_rule b 
		  WHERE a.irule_main = b.irule_main
		    AND b.irule_main = $irule_main
		    AND a.irule = $irule;
	}
        
	if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True) 
			return M_CM_NOT_FOUND;
		else
			return apiRC;
	}
	cm_buf_init(ReplyBuf);
	
	if(option2[0] == '1')	
	{
		cm_buf_put("%l %s %s %s %s %s %s", M_CM_OK,irule_main,nrule_main,icreate_main,dcreate_main,iupdate_main,dupdate_main);
	}
	else
	{	
		cm_buf_put("%l %s %s %s %s %s %s %s %d %d %d %d %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s", 
		            M_CM_OK,irule,frule,iins_type1,iins_type2,icar_type,iabn_type,dcheck1, 
		            minjured_cover,mdeath_cover,mdamage_cover,mdeduct,nrule_text,nexception,nmessage, 
		            dexpire,icreate,dcreate,iupdate,dupdate,provision,fuw_type,
		            irule_main,nrule_main,icreate_main,dcreate_main,iupdate_main,dupdate_main);
	}

	tmp_len = cm_buf_len(ReplyBuf);
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		return apiRC;
	else
		return api_OKComplete;
	
errexit:
	if ( exitsub(reply,SQLCODE) == True )
		return SQLCODE;
	return apiRC;
}

/*--------------------------------------------------*/
long car179_multiple_query(reply)
serverReply reply;
{
	$char stmt[1024],DBName[3];
	$char irule_mainBuf[6],iruleBuf[6];
	$char irule_main[6],nrule_main[51],irule[6],nmessage[256];	
	$char stmp_irule_main[128],stmp_irule[128];
	$char iins_type1_tmp[31],iins_type2_tmp[31];
	char  tmpbuf[4000];
	int   count=0,repbuf_len=0,tmp_len=0,replycnt=0;
	int   i,total_count=0,flag;

	cm_buf_get("%s %s %s %s %s",DBName,irule_mainBuf,iruleBuf,iins_type1_tmp,iins_type2_tmp);

	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
			return M_CM_DB_NOTOPEN;
		return apiRC;
	}
	
	if(irule_mainBuf[0] == '*')
	{
		strcpy(stmp_irule_main," ");
	}
	else
	{
		sprintf(stmp_irule_main,"AND b.irule_main = '%s' ",irule_mainBuf);
	}
	
	if(iruleBuf[0] == '*')
	{
		strcpy(stmp_irule," ");
	}
	else
	{
		sprintf(stmp_irule,"AND a.irule = '%s' ",iruleBuf);
	}

	sprintf(stmt,"SELECT b.irule_main,b.nrule_main,a.irule,a.nmessage \
	                FROM ca_check_setup a ,ca_check_rule b \
	               WHERE a.irule_main = b.irule_main \
	                 AND iins_type1 matches '%s' \
	                 AND iins_type2 matches '%s' %s %s \
	               ORDER BY b.irule_main ",iins_type1_tmp,iins_type2_tmp,stmp_irule_main,stmp_irule);

	$PREPARE m_cur1 FROM $stmt;
	$DECLARE m_cur CURSOR FOR m_cur1;
	printf("266:stmt[%s]\n",stmt);
	$OPEN m_cur;
   	for(;;)
   	{
		$FETCH m_cur INTO $irule_main,$nrule_main,$irule,$nmessage;
		if (SQLCODE != 0) break;
		
		cm_buf_init(tmpbuf);
		printf("274:cm_buf_init\n");
		
		if ( count == 0 )
		{
			cm_buf_res_msg();               /* reserve for MsgCode and count */
			cm_buf_res_count();
		}
		
		cm_buf_put("%s %s %s %s",irule_main,nrule_main,irule,nmessage);
		printf("283:cm_buf_put\n");	
		tmp_len = cm_buf_len(tmpbuf);
		
		printf("286:tmpbuf[%s]\n",tmpbuf);
    	
      	if ( tmp_len + repbuf_len < 3000 )  /* buffer size less than 4K */
      	{
			memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
			repbuf_len += tmp_len;
			count++;
     	}
      	else                               /* more than 4K, send to client side */
      	{
			cm_buf_init(ReplyBuf);
			cm_buf_put_msg(M_CM_OK);
			cm_buf_put_count(count);
			if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
			{
				$CLOSE m_cur;
				$FREE m_cur;
				return apiRC;
			}
			else                      /* clear ReplyBuf and count to start all over again */
			{
				replycnt++;
				if (replycnt == 10)   /* more than 30K, client cannot display,error */
				{
					cm_buf_init(ReplyBuf);
					cm_buf_put("%l",M_CM_OUT_SPACE);
					tmp_len = cm_buf_len(ReplyBuf);
					if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
					return apiRC;
					return M_CM_OUT_SPACE;
				}
				ReplyBuf[0] = '\0';
				count = 0;
				cm_buf_init(ReplyBuf);
				cm_buf_res_msg();     /* reserve for MsgCode and count */
				cm_buf_res_count();
				
				cm_buf_put("%s %s %s %s",irule_main,nrule_main,irule,nmessage);
				printf("324:cm_buf_put\n");
				repbuf_len = cm_buf_len(ReplyBuf);
				count++;
			}
		}
	}  /* for loop */
	$CLOSE m_cur;
	$FREE m_cur;

	if (count > 0)  /* break out, at least one record is selected */
	{
		cm_buf_init(ReplyBuf);
		cm_buf_put_msg(M_CM_OK);
		cm_buf_put_count(count);
		if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
		return apiRC;
		return api_OKComplete;
	}
	else  /* break out, not any raw is found */
	{
		if( exitsub(reply,M_CM_NOT_FOUND) == True )
		return M_CM_NOT_FOUND;
		return apiRC;
	}

errexit:
	if ( exitsub(reply,SQLCODE) == True )
		return SQLCODE;
	return apiRC;
}

long car179_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{		
	$char    DBName[3],option2[2];
	/*������*/	
	$char irule[6],frule[2],iins_type1[101],iins_type2[101],icar_type[101],iabn_type[7],nrule_text[256],nexception[31],nmessage[256],provision[21],fuw_type[2];
	$char dcheck1[11],dexpire[11],icreate[11],iupdate[11],dcreate[21],dupdate[21];
	$long minjured_cover,mdeath_cover,mdamage_cover,mdeduct;
	/*�D��*/
	$char irule_main[6],nrule_main[51],icreate_main[11],dcreate_main[21],iupdate_main[11],dupdate_main[21],userid[11],userid_main[11];
	
	/*������cur*/	
	$char cur_irule[6], cur_frule[2], cur_iins_type1[101], cur_iins_type2[101], cur_icar_type[101], cur_iabn_type[7], cur_nrule_text[256], cur_nexception[31], cur_nmessage[256], cur_provision[21], cur_fuw_type[2];
	$char cur_dcheck1[11], cur_dexpire[11], cur_icreate[11], cur_iupdate[11];
	$long cur_minjured_cover, cur_mdeath_cover, cur_mdamage_cover, cur_mdeduct;
	$char cur_dcreate[21], cur_dupdate[21];
	/*�D��cur*/
	$char cur_irule_main[6],cur_nrule_main[51],cur_icreate_main[11],cur_iupdate_main[11],cur_dcreate_main[21],cur_dupdate_main[21];
	
	int   tmp_len,raw_len,count,rows=0,i,flag,count1,y;
	char  option,*pos,*raw_ptr,cur_buf[10000],*comm,type;
	long  dummy;
	long  MsgCode;
	int   first;
	int   k, j, is_del_fail=0, is_upd_fail=0;
	$int     chk_code;
	comm = (char *) command;
	
	cm_buf_init(command);
	cm_buf_get("%c %s %s",&option,DBName,option2);
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False) return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
	
	memcpy(&raw_len,&comm[com_len],sizeof(int));
	pos = &comm[com_len+sizeof(int)];
	raw_ptr = malloc(raw_len);
	
	if (raw_ptr != (char*)0)
		memcpy(raw_ptr,pos,raw_len);
	else
	{
		return exitsub(reply,M_CM_NOT_MALLOC) ? M_CM_NOT_MALLOC : apiRC;
	}

	/* buf_get�����ܼ� (dummy �e�@�����) */   
	cm_buf_init(raw_ptr);
	cm_buf_get("%l ",&dummy);
	
	$BEGIN WORK;
	
	if(option2[0] == '1')   /*�Ȭd�ߥD�W�h�W��*/
	{
		cm_buf_get("%s %s %s %s %s %s", irule_main,nrule_main,icreate_main,dcreate_main,iupdate_main,dupdate_main);
		
		$SELECT irule_main::char(5), nrule_main, nvl(icreate,' '), nvl(dcreate,' '), nvl(iupdate,' '), nvl(dupdate,' ')
		   INTO $cur_irule_main,$cur_nrule_main,$cur_icreate_main,$cur_dcreate_main,$cur_iupdate_main,$cur_dupdate_main
		   FROM ca_check_rule
		  WHERE irule_main = $irule_main;

		cm_buf_init(cur_buf);
		cm_buf_put("%l %s %s %s %s %s %s", M_CM_OK, cur_irule_main, cur_nrule_main, cur_icreate_main, cur_dcreate_main, cur_iupdate_main, cur_dupdate_main);
	}
	else
	{
		cm_buf_get("%s %s %s %s %s %s %s %d %d %d %d %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s", 
		            irule,frule,iins_type1,iins_type2,icar_type,iabn_type,dcheck1, 
		            &minjured_cover,&mdeath_cover,&mdamage_cover,&mdeduct,nrule_text,nexception,nmessage, 
		            dexpire,icreate,dcreate,iupdate,dupdate,provision,fuw_type,
		            irule_main,nrule_main,icreate_main,dcreate_main,iupdate_main,dupdate_main);

		$SELECT a.irule::char(5),a.frule,a.iins_type1,a.iins_type2,a.icar_type,a.iabn_type,a.dcheck1,
		        a.minjured_cover,a.mdeath_cover,a.mdamage_cover,a.mdeduct,a.nrule_text,a.nexception,a.nmessage,
		        a.dexpire,a.icreate,a.dcreate,a.iupdate,a.dupdate,a.provision,a.fuw_type,
		        b.irule_main::char(5),b.nrule_main,b.icreate,b.dcreate,b.iupdate,b.dupdate
		   INTO $cur_irule,$cur_frule,$cur_iins_type1,$cur_iins_type2,$cur_icar_type,$cur_iabn_type,$cur_dcheck1,
		        $cur_minjured_cover,$cur_mdeath_cover,$cur_mdamage_cover,$cur_mdeduct,$cur_nrule_text,$cur_nexception,$cur_nmessage,
		        $cur_dexpire,$cur_icreate,$cur_dcreate,$cur_iupdate,$cur_dupdate,$cur_provision,$cur_fuw_type,
		        $cur_irule_main,$cur_nrule_main,$cur_icreate_main,$cur_dcreate_main,$cur_iupdate_main,$cur_dupdate_main
		   FROM ca_check_setup a,ca_check_rule b 
		  WHERE a.irule_main = b.irule_main
		    AND b.irule_main = $irule_main
		    AND a.irule = $irule;
	
		if (SQLCODE == SQLNOTFOUND)
		{
			MsgCode = M_CM_NOT_FOUND;
			$WHENEVER SQLERROR CONTINUE;
			$ROLLBACK WORK;
			if(SQLCODE != 0) MsgCode = SQLCODE;
			return exitsub(reply,MsgCode) ? MsgCode : apiRC;
		}

		cm_buf_init(cur_buf);
		cm_buf_put("%l %s %s %s %s %s %s %s %d %d %d %d %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s", 
		            M_CM_OK,cur_irule,cur_frule,cur_iins_type1,cur_iins_type2, cur_icar_type, cur_iabn_type, cur_dcheck1, 
		            cur_minjured_cover, cur_mdeath_cover, cur_mdamage_cover, cur_mdeduct, cur_nrule_text, cur_nexception, cur_nmessage, 
		            cur_dexpire, cur_icreate, cur_dcreate, cur_iupdate, cur_dupdate, cur_provision, cur_fuw_type, 
		            cur_irule_main, cur_nrule_main, cur_icreate_main, cur_dcreate_main, cur_iupdate_main, cur_dupdate_main);
	}
	
   	$WHENEVER SQLERROR GOTO errexit;
	write(1, cur_buf, raw_len); 
	printf("cur_buf[%s]\n",cur_buf);
	write(1, raw_ptr, raw_len);
	printf("raw_ptr[%s]\n",raw_ptr);

	if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
	{
		MsgCode = M_CM_NOT_EQUAL;
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		if(SQLCODE != 0) MsgCode = SQLCODE;
		return exitsub(reply,MsgCode) ? MsgCode : apiRC;
	}
 
	$WHENEVER SQLERROR GOTO errexit;
	
	if( option == 'D' )
	{
		if(option2[0] == '1')  /*�D��DELETE*/
		{
			$DELETE FROM ca_check_rule WHERE irule_main = $cur_irule_main;
			$DELETE FROM ca_check_setup WHERE irule_main = $cur_irule_main;
		}
		else if(option2[0] == '2')   /*����DELETE*/
		{
			$DELETE FROM ca_check_setup WHERE irule_main = $cur_irule_main AND irule  = $cur_irule;
		}
	  
		cm_buf_init(ReplyBuf);
		cm_buf_put("%l", M_CM_OK);
		tmp_len = cm_buf_len(ReplyBuf);
		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
		{
			$WHENEVER SQLERROR CONTINUE;
			$ROLLBACK WORK;
			return apiRC;
		}
		$WHENEVER SQLERROR GOTO errexit;
		$COMMIT WORK;
		return api_OKComplete;
   	}
	else if(option == 'U')
	{   	  
		printf("579:\n");
		cm_buf_init(command);
		/*get�����ܼơA���F�����icreate*/
		cm_buf_get("%c %s %s",&option,DBName,option2);
		
		if(option2[0] == '1')  /*�D��DELETE*/
		{
			cm_buf_get("%s %s %s ",irule_main,nrule_main,userid);
		}
		else
		{
			cm_buf_get("%s %s %s %s %s %s %s %d %d %d %d %s %s %s %s %s %s %s %s %s %s %s %s", 
			            irule,frule,iins_type1,iins_type2,icar_type,iabn_type,dcheck1, 
			            &minjured_cover,&mdeath_cover,&mdamage_cover,&mdeduct,nrule_text,nexception,nmessage, 
			            dexpire,userid,provision,fuw_type,irule_main,nrule_main,userid_main);
		}
         /*�N����~�ର�褸�~*/                               	          
         strcpy(dcheck1,cm_to_infdate(dcheck1));
         strcpy(dexpire,cm_to_infdate(dexpire));
                    
        if(option2[0] == '1')  /*�D��*/
        {
			$UPDATE ca_check_rule
			    SET (nrule_main, iupdate, dupdate)
			      = ($nrule_main,$userid, current)
			  WHERE irule_main = $irule_main;
        }
        else if(option2[0] == '2')  /*������*/
        {
			$UPDATE ca_check_setup
			    SET(frule, iins_type1, iins_type2, icar_type, iabn_type, dcheck1, minjured_cover, mdeath_cover, mdamage_cover, mdeduct, nrule_text, nexception, nmessage, dexpire, iupdate, dupdate, provision, fuw_type)
			      =($frule, $iins_type1, $iins_type2, $icar_type, $iabn_type, $dcheck1, $minjured_cover, $mdeath_cover, $mdamage_cover, $mdeduct, $nrule_text, $nexception, $nmessage, $dexpire, $userid, current, $provision, $fuw_type)
			  WHERE irule_main = $irule_main 
			    AND irule = $irule;     	            
        }

		if( is_upd_fail ) goto errexit;
		cm_buf_init(ReplyBuf);
		cm_buf_put("%l",M_CM_OK);
		tmp_len = cm_buf_len(ReplyBuf);
		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
		{
			$WHENEVER SQLERROR CONTINUE;
			$ROLLBACK WORK;
			return apiRC;
		}
		$WHENEVER SQLERROR GOTO errexit;
		$COMMIT WORK;
		return api_OKComplete;
   	}
   	else
   	{
		return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
   	}

errexit:
	MsgCode = SQLCODE;
	$WHENEVER SQLERROR CONTINUE;
	$ROLLBACK WORK;
	if( SQLCODE != 0) MsgCode = SQLCODE;
	return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
