/************************************************/
/*                                              */
/*   PROGRAM : ca175m01s.ec                     */
/*                                              */
/*   PURPOSE : �O�o�j���I���@�{��               */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
$include sqlca;
#include "safeclib.h"

DBinfo  *list;
int  count_db, i;

long car175(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	/*
		P/E ca_dev_ply_edr_comp
		C/U ca_dev_clm_comp
		S   ca_dev_clm_vic_comp
		M   ca_dev_clm_health_comp
	*/
	long rtncode,type;
	long car175_single_query_PE(),car175_single_query_CU(),car175_single_query_S(),car175_single_query_M();
	long car175_multiple_query_PE(),car175_multiple_query_CU(),car175_multiple_query_S(),car175_multiple_query_M();
	long car176_update_exec_PE(),car176_update_exec_CU();
	
	char option[3];
	
	cm_buf_init(command);
	cm_buf_get("%s",option);
	switch(*option)
	{
		case 'Q':
			type = *(option+1)-'0';
			printf("type[%d] \n",type);
			if (type==1)
				rtncode=car175_single_query_PE(reply);
			else if (type == 2)
				rtncode=car175_single_query_CU(reply);
			else if (type == 3)
				rtncode=car175_single_query_S(reply);
			else 
				rtncode=car175_single_query_M(reply);
			break;

		case 'M':
			type = *(option+1)-'0';
			printf("type[%d] \n",type);
			if (type==1)
				rtncode=car175_multiple_query_PE(reply);
			else if (type == 2)
				rtncode=car175_multiple_query_CU(reply);
			else if (type == 3)
				rtncode=car175_multiple_query_S(reply);
			else 
				rtncode=car175_multiple_query_M(reply);
			break;
			
		case 'U':
			type = *(option+1)-'0';
			printf("type[%d] \n",type);
			if (type==1)
				rtncode=car175_update_exec_PE(reply,command,com_len);
			else if (type == 2)
				rtncode=car175_update_exec_CU(reply,command,com_len);
			else if (type == 3)
				rtncode=car175_update_exec_S(reply,command,com_len);
			else 
				rtncode=car175_update_exec_M(reply,command,com_len);
			break;

		default :
			if(exitsub(reply,M_CM_WRONG_OPTION) == True)
			 return M_CM_WRONG_OPTION;
		return apiRC;
	}
	return(rtncode);
}

long car175_single_query_PE(reply)
serverReply reply;
{
	$char DBName[5],data_yyyymm_in[7],idata_in[2],ipolicy_in[21],iendorse_in[21],iedr_type_in[3];
	$char sFullName[21],stmt[4096],stmp[2048];
	$char buff[250];
	int tmp_len;
	
	$char   data_yyyymm[7],idata[2],ipolicy[21],icard_company[3],icard_br[3],icard[16],icard_last_company[3],icard_last_br[3],icard_last[13];
	$char   iedr_company[3],iedr_br[3],iendorse[14],iarea[3],dedr_begin[9],dedr_end[9],dply_begin[9],dply_end[9],iobjno[5],iissue_year[5],ipro_year[5],ibrand[9];
	$char   icar_type[3],icar_type_no[3],iengine[26],itag[13],fpt[2],fassured[2],iassured[11],dbirth[9],fsex[2],fmarriage[2];
	$char   fcomp_class_last[3],fcomp_class[3],iedr_type[3];
	$char   iproduct[13],drate_ym[7],dpolicy_ym[7],bzfrom[3],dsend[9];
	$long   qcylinder = 0,qpt = 0,qdrunk_driving = 0,mprem = 0,mins_premium = 0,mdrunk_prem = 0;
	$double madjcom_prem = 0.0,mbusiness = 0.0,maintain = 0.0,mcompensation = 0.0,mstable = 0.0,mdrunk_pure_prem = 0.0;
	$char   madjcom_prem_tmp[13],mbusiness_tmp[10],maintain_tmp[10],mcompensation_tmp[10],mstable_tmp[10],mdrunk_pure_prem_tmp[13];

	cm_buf_get("%s %s %s %s %s %s ",DBName,data_yyyymm_in,idata_in,ipolicy_in,iendorse_in,iedr_type_in);
	strcpy(ipolicy_in,trim(ipolicy_in));

	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}

	if(idata_in[0] == 'P')
		strcpy(sFullName, get_car_full_db(ipolicy_in));
 	else 
 		strcpy(sFullName, get_car_full_db(iendorse_in));
 		
	sprintf_s(stmt, sizeof stmt,"SELECT data_yyyymm,idata,ipolicy,icard_company,icard_br,icard,icard_last_company,icard_last_br,icard_last, "
	                    " iedr_company,iedr_br,iendorse,iarea,dedr_begin,dedr_end,dply_begin,dply_end, "
	                    " iobjno,iissue_year,ipro_year,ibrand,icar_type,icar_type_no, "
	                    " qcylinder,iengine,itag,qpt,fpt,fassured,iassured,dbirth,fsex,fmarriage, "
	                    " fcomp_class_last,fcomp_class,iedr_type,qdrunk_driving, "
	                    " mprem,mins_premium,madjcom_prem,mbusiness,maintain,mcompensation,mstable, "
	                    " mdrunk_prem,mdrunk_pure_prem,iproduct,drate_ym,dpolicy_ym,bzfrom,dsend "
	               " FROM %s:ca_dev_ply_edr_comp "
	               " WHERE data_yyyymm = '%s' "
	               " AND idata       = '%s' "
	               " AND ipolicy     = '%s' "
	               " AND iendorse    = '%s' "
	               " AND iedr_type   = '%s'",sFullName,data_yyyymm_in,idata_in,ipolicy_in,iendorse_in,iedr_type_in);
     
	printf("stmt[%s]\n\n",stmt);    
	$PREPARE ply_edr_q FROM $stmt;
	$EXECUTE ply_edr_q INTO $data_yyyymm,$idata,$ipolicy,$icard_company,$icard_br,$icard,$icard_last_company,$icard_last_br,$icard_last,
	                        $iedr_company,$iedr_br,$iendorse,$iarea,$dedr_begin,$dedr_end,$dply_begin,$dply_end,
	                        $iobjno,$iissue_year,$ipro_year,$ibrand,$icar_type,$icar_type_no,
	                        $qcylinder,$iengine,$itag,$qpt,$fpt,$fassured,$iassured,$dbirth,$fsex,$fmarriage,
	                        $fcomp_class_last,$fcomp_class,$iedr_type,$qdrunk_driving,
	                        $mprem,$mins_premium,$madjcom_prem,$mbusiness,$maintain,$mcompensation,$mstable,
	                        $mdrunk_prem,$mdrunk_pure_prem,$iproduct,$drate_ym,$dpolicy_ym,$bzfrom,$dsend;

	if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)     
			return M_CM_NOT_FOUND;                     
		else
			return apiRC;
	}

	sprintf_s(madjcom_prem_tmp, sizeof madjcom_prem_tmp,"%.4f",madjcom_prem);
	sprintf_s(mbusiness_tmp, sizeof mbusiness_tmp,"%.4f",mbusiness);
	sprintf_s(maintain_tmp, sizeof maintain_tmp,"%.4f",maintain);
	sprintf_s(mcompensation_tmp, sizeof mcompensation_tmp,"%.4f",mcompensation);
	sprintf_s(mstable_tmp, sizeof mstable_tmp,"%.4f",mstable);
	sprintf_s(mdrunk_pure_prem_tmp, sizeof mdrunk_pure_prem_tmp,"%.4f",mdrunk_pure_prem);
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l %s %s %s %s %s %s %s %s %s ",M_CM_OK,data_yyyymm,idata,ipolicy,icard_company,icard_br,icard,icard_last_company,icard_last_br,icard_last);
	cm_buf_put("%s %s %s %s %s %s %s %s ",iedr_company,iedr_br,iendorse,iarea,dedr_begin,dedr_end,dply_begin,dply_end);
	cm_buf_put("%s %s %s %s %s %s ",iobjno,iissue_year,ipro_year,ibrand,icar_type,icar_type_no);
	cm_buf_put("%d %s %s %d %s %s %s %s %s %s ",qcylinder,iengine,itag,qpt,fpt,fassured,iassured,dbirth,fsex,fmarriage);
	cm_buf_put("%s %s %s %d ",fcomp_class_last,fcomp_class,iedr_type,qdrunk_driving);
	cm_buf_put("%d %d %s %s %s %s %s ",mprem,mins_premium,madjcom_prem_tmp,mbusiness_tmp,maintain_tmp,mcompensation_tmp,mstable_tmp);
	cm_buf_put("%d %s %s %s %s %s %s ",mdrunk_prem,mdrunk_pure_prem_tmp,iproduct,drate_ym,dpolicy_ym,bzfrom,dsend);
	
	tmp_len = cm_buf_len(ReplyBuf);
	
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		return apiRC;
	else
		return api_OKComplete;
	
	errexit:
	if(exitsub(reply,SQLCODE) == True)
		return SQLCODE;
	else
		return apiRC;
}

long car175_single_query_CU(reply)
serverReply reply;
{
	$char DBName[5],data_yyyymm_in[7],idata_in[2],iclaim_in[21],fstl_in[2],istl_class_in[4];
	$long iclose_type_in;
	$char sIbranch_in[3];
	$char sFullName[21],stmt[4096],stmp[2048];
	$char buff[250];
	int tmp_len;
	
	$char   data_yyyymm[7],idata[2],fend_yn[2],fstl[2],istl_recover[2],ihealth[2],dclaim[9];
	$char   iclm_company[3],iclm_br[3],iclaim[15],istl_flag[2],dgroup[9],icard_company[3],icard_br[3],icard[16];
	$char   dply_begin[9],dply_end[9],iarea[3],iobjno[5],iissue_year[5],ipro_year[5],ibrand[9];
	$char   icar_type[3],icar_type_no[3],iengine[26],itag[13],fpt[2];
	$char   ioth_fassured[2],ioth_cartype[3],ioth_fpt[2],ioth_tag[13],ioth_comp_yn[2],ioth_card_company[3],ioth_card[18],fcomp_class[3];
	$char   drate_ym[7],fassured[2],iassured[11],dbirth[8],fsex[2],fmarriage[2];
	$char   facc_nation[2],iacc_license[11],iacc_birth[8],facc_sex[2],facc_marri[2],facc_rel[2];
	$char   iacc_reason[3],facc_duty[2],fsubrogation[2];
	$char   daccident[9],iacc_area[3],istl_class[4];
	$char   iproduct[13],bzfrom[3],dsend[9];
	$long   iclose_type = 0,qcylinder = 0,qpt = 0,ioth_qpt = 0,qdrunk_driving = 0,mins_premium = 0,mdrunk_prem = 0;
	$long   iself_duty = 0,ioth_duty = 0,ianoth_duty = 0;
	$long   qacar_death = 0,qacar_cripple = 0,qacar_injure = 0,qbcar_death = 0,qbcar_cripple = 0,qbcar_injure = 0,qccar_death = 0,qccar_cripple = 0,qccar_injure = 0;
	$long   mcoverage = 0,victim_num = 0,mapp_cover = 0,mins_stl = 0,mins_proc = 0,mstl_health = 0,qhealth = 0,mhealth = 0,sum_all = 0;
	$double madjcom_prem = 0.0,mbusiness = 0.0,maintain = 0.0,mcompensation = 0.0,mstable = 0.0,mdrunk_pure_prem = 0.0;
	$char   madjcom_prem_tmp[13],mbusiness_tmp[10],maintain_tmp[10],mcompensation_tmp[10],mstable_tmp[10],mdrunk_pure_prem_tmp[13];

	cm_buf_get("%s %s %s %s %s %d %s ",DBName,data_yyyymm_in,idata_in,iclaim_in,fstl_in,&iclose_type_in,istl_class_in);
	strcpy(iclaim_in,trim(iclaim_in));

	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}

	/* ���o�߮׸�Ʈw */
	$SELECT ibranch_in
	   INTO $sIbranch_in
	   FROM ca_clm_process
	  WHERE iclaim = $iclaim_in;
	  
	strcpy(sFullName, get_full_dbname(sIbranch_in));
 		
	sprintf_s(stmt, sizeof stmt,"SELECT data_yyyymm,idata,fend_yn,fstl,istl_recover,ihealth,dclaim,iclm_company,iclm_br,iclaim,iclose_type,istl_flag, "
	                    " dgroup,icard_company,icard_br,icard,dply_begin,dply_end, "
	                    " iarea,iobjno,iissue_year,ipro_year,ibrand,icar_type,icar_type_no,qcylinder,iengine,itag,qpt,fpt, "
	                    " ioth_fassured,ioth_cartype,ioth_qpt,ioth_fpt,ioth_tag,ioth_comp_yn,ioth_card_company,ioth_card,fcomp_class, "
	                    " qdrunk_driving,mins_premium,madjcom_prem,mbusiness,maintain,mcompensation,mstable,mdrunk_prem,mdrunk_pure_prem, "
	                    " drate_ym,fassured,iassured,dbirth,fsex,fmarriage,facc_nation,iacc_license,iacc_birth,facc_sex,facc_marri,facc_rel, "
	                    " iacc_reason,facc_duty,fsubrogation,iself_duty,ioth_duty,ianoth_duty, "
	                    " qacar_death,qacar_cripple,qacar_injure,qbcar_death,qbcar_cripple,qbcar_injure,qccar_death,qccar_cripple,qccar_injure, "
	                    " daccident,iacc_area,istl_class,mcoverage,victim_num, "
	                    " mapp_cover,mins_stl,mins_proc,mstl_health,qhealth,mhealth,sum_all,iproduct,bzfrom,dsend "
	               " FROM %s:ca_dev_clm_comp "
	              " WHERE data_yyyymm = '%s' "
	                " AND idata       = '%s' "
	                " AND iclaim      = '%s' "
	                " AND fstl        = '%s' "
	                " AND iclose_type =  %d  "
	                " AND istl_class  = '%s'",sFullName,data_yyyymm_in,idata_in,iclaim_in,fstl_in,iclose_type_in,istl_class_in);
     
	printf("stmt[%s]\n\n",stmt);    
	$PREPARE clm_q FROM $stmt;
	$EXECUTE clm_q INTO $data_yyyymm,$idata,$fend_yn,$fstl,$istl_recover,$ihealth,$dclaim,$iclm_company,$iclm_br,$iclaim,$iclose_type,$istl_flag,
	                    $dgroup,$icard_company,$icard_br,$icard,$dply_begin,$dply_end,
	                    $iarea,$iobjno,$iissue_year,$ipro_year,$ibrand,$icar_type,$icar_type_no,$qcylinder,$iengine,$itag,$qpt,$fpt,
	                    $ioth_fassured,$ioth_cartype,$ioth_qpt,$ioth_fpt,$ioth_tag,$ioth_comp_yn,$ioth_card_company,$ioth_card,$fcomp_class,
	                    $qdrunk_driving,$mins_premium,$madjcom_prem,$mbusiness,$maintain,$mcompensation,$mstable,$mdrunk_prem,$mdrunk_pure_prem,
	                    $drate_ym,$fassured,$iassured,$dbirth,$fsex,$fmarriage,$facc_nation,$iacc_license,$iacc_birth,$facc_sex,$facc_marri,$facc_rel,
	                    $iacc_reason,$facc_duty,$fsubrogation,$iself_duty,$ioth_duty,$ianoth_duty,
	                    $qacar_death,$qacar_cripple,$qacar_injure,$qbcar_death,$qbcar_cripple,$qbcar_injure,$qccar_death,$qccar_cripple,$qccar_injure,
	                    $daccident,$iacc_area,$istl_class,$mcoverage,$victim_num,
	                    $mapp_cover,$mins_stl,$mins_proc,$mstl_health,$qhealth,$mhealth,$sum_all,$iproduct,$bzfrom,$dsend;

	if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)     
			return M_CM_NOT_FOUND;                     
		else
			return apiRC;
	}

	sprintf_s(madjcom_prem_tmp, sizeof madjcom_prem_tmp,"%.4f",madjcom_prem);
	sprintf_s(mbusiness_tmp, sizeof mbusiness_tmp,"%.4f",mbusiness);
	sprintf_s(maintain_tmp, sizeof maintain_tmp,"%.4f",maintain);
	sprintf_s(mcompensation_tmp, sizeof mcompensation_tmp,"%.4f",mcompensation);
	sprintf_s(mstable_tmp, sizeof mstable_tmp,"%.4f",mstable);
	sprintf_s(mdrunk_pure_prem_tmp, sizeof mdrunk_pure_prem_tmp,"%.4f",mdrunk_pure_prem);
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %d %s ",M_CM_OK,data_yyyymm,idata,fend_yn,fstl,istl_recover,ihealth,dclaim,iclm_company,iclm_br,iclaim,iclose_type,istl_flag);
	cm_buf_put("%s %s %s %s %s %s ",dgroup,icard_company,icard_br,icard,dply_begin,dply_end);
	cm_buf_put("%s %s %s %s %s %s %s %d %s %s %d %s ",iarea,iobjno,iissue_year,ipro_year,ibrand,icar_type,icar_type_no,qcylinder,iengine,itag,qpt,fpt);
	cm_buf_put("%s %s %d %s %s %s %s %s %s ",ioth_fassured,ioth_cartype,ioth_qpt,ioth_fpt,ioth_tag,ioth_comp_yn,ioth_card_company,ioth_card,fcomp_class);
	cm_buf_put("%d %d %s %s %s %s %s %d %s ",qdrunk_driving,mins_premium,madjcom_prem_tmp,mbusiness_tmp,maintain_tmp,mcompensation_tmp,mstable_tmp,mdrunk_prem,mdrunk_pure_prem_tmp);
	cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s ",drate_ym,fassured,iassured,dbirth,fsex,fmarriage,facc_nation,iacc_license,iacc_birth,facc_sex,facc_marri,facc_rel);
	cm_buf_put("%s %s %s %d %d %d ",iacc_reason,facc_duty,fsubrogation,iself_duty,ioth_duty,ianoth_duty);
	cm_buf_put("%d %d %d %d %d %d %d %d %d ",qacar_death,qacar_cripple,qacar_injure,qbcar_death,qbcar_cripple,qbcar_injure,qccar_death,qccar_cripple,qccar_injure);
	cm_buf_put("%s %s %s %d %d ",daccident,iacc_area,istl_class,mcoverage,victim_num);
	cm_buf_put("%d %d %d %d %d %d %d %s %s %s ",mapp_cover,mins_stl,mins_proc,mstl_health,qhealth,mhealth,sum_all,iproduct,bzfrom,dsend);
	
	tmp_len = cm_buf_len(ReplyBuf);
	
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		return apiRC;
	else
		return api_OKComplete;
	
	errexit:
	if(exitsub(reply,SQLCODE) == True)
		return SQLCODE;
	else
		return apiRC;
}

long car175_single_query_S(reply)
serverReply reply;
{
	$char DBName[5],data_yyyymm_in[7],iclaim_in[21],fstl_in[2],ivictim_in[11],iins_item_in[5];
	$long iclose_type_in;
	$char sIbranch_in[3];
	$char sFullName[21],stmt[4096],stmp[2048];
	$char buff[250];
	int tmp_len;
	
	$char data_yyyymm[7],fend_yn[2],fstl[2],istl_recover[2],ihealth[2],dclaim[9],iclm_company[3],iclm_br[3],iclaim[15];
	$char istl_flag[2],dgroup[9],icard_company[3],icard_br[3],icard[16],dply_begin[9],dply_end[9];
	$char fvictim_nation[2],ivictim[11],dvictim_yy[5],fvictim_sex[2],fvictim_car[2],fsubrogation[3],iins_item_1[2];
	$char fhealth[2],flast[2],daccident[9],iacc_area[3],iply_area[3],iacc_reason[3],iins_item[5];
	$char bzfrom[3],dsend[9];
	$long iclose_type = 0,iself_duty = 0,mcoverage = 0,mapp_cover = 0,mins_stl = 0,mins_proc = 0,mstl_health = 0,qhealth = 0,mhealth = 0,sum_all = 0;

	cm_buf_get("%s %s %s %s %d %s %s ",DBName,data_yyyymm_in,iclaim_in,fstl_in,&iclose_type_in,ivictim_in,iins_item_in);
	strcpy(iclaim_in,trim(iclaim_in));

	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}

	/* ���o�߮׸�Ʈw */
	$SELECT ibranch_in
	   INTO $sIbranch_in
	   FROM ca_clm_process
	  WHERE iclaim = $iclaim_in;
	  
	strcpy(sFullName, get_full_dbname(sIbranch_in));
 		
	sprintf_s(stmt, sizeof stmt,"SELECT data_yyyymm,fend_yn,fstl,istl_recover,ihealth,dclaim,iclm_company,iclm_br, "
	                    " iclaim,iclose_type,istl_flag,dgroup,icard_company,icard_br,icard, "
	                    " dply_begin,dply_end,fvictim_nation,ivictim,dvictim_yy, "
	                    " fvictim_sex,fvictim_car,fsubrogation,iself_duty,iins_item_1,fhealth,flast, "
	                    " daccident,iacc_area,iply_area,iacc_reason,iins_item, "
	                    " mcoverage,mapp_cover,mins_stl,mins_proc,mstl_health,qhealth,mhealth,sum_all, "
	                    " bzfrom,dsend "
	               " FROM %s:ca_dev_clm_vic_comp "
	              " WHERE data_yyyymm = '%s' "
	                " AND iclaim      = '%s' "
	                " AND fstl        = '%s' "
	                " AND iclose_type =  %d  "
	                " AND ivictim     = '%s' "
	                " AND iins_item   = '%s' ",sFullName,data_yyyymm_in,iclaim_in,fstl_in,iclose_type_in,ivictim_in,iins_item_in);
     
	printf("stmt[%s]\n\n",stmt);    
	$PREPARE clm_vic FROM $stmt;
	$EXECUTE clm_vic INTO $data_yyyymm,$fend_yn,$fstl,$istl_recover,$ihealth,$dclaim,$iclm_company,$iclm_br, 
	                      $iclaim,$iclose_type,$istl_flag,$dgroup,$icard_company,$icard_br,$icard, 
	                      $dply_begin,$dply_end,$fvictim_nation,$ivictim,$dvictim_yy, 
	                      $fvictim_sex,$fvictim_car,$fsubrogation,$iself_duty,$iins_item_1,$fhealth,$flast, 
	                      $daccident,$iacc_area,$iply_area,$iacc_reason,$iins_item, 
	                      $mcoverage,$mapp_cover,$mins_stl,$mins_proc,$mstl_health,$qhealth,$mhealth,$sum_all, 
	                      $bzfrom,$dsend;

	if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)     
			return M_CM_NOT_FOUND;                     
		else
			return apiRC;
	}
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l %s %s %s %s %s %s %s %s ",M_CM_OK,data_yyyymm,fend_yn,fstl,istl_recover,ihealth,dclaim,iclm_company,iclm_br);
	cm_buf_put("%s %d %s %s %s %s %s ",iclaim,iclose_type,istl_flag,dgroup,icard_company,icard_br,icard);
	cm_buf_put("%s %s %s %s %s ",dply_begin,dply_end,fvictim_nation,ivictim,dvictim_yy);
	cm_buf_put("%s %s %s %d %s %s %s ",fvictim_sex,fvictim_car,fsubrogation,iself_duty,iins_item_1,fhealth,flast);
	cm_buf_put("%s %s %s %s %s ",daccident,iacc_area,iply_area,iacc_reason,iins_item);
	cm_buf_put("%d %d %d %d %d %d %d %d ",mcoverage,mapp_cover,mins_stl,mins_proc,mstl_health,qhealth,mhealth,sum_all);
	cm_buf_put("%s %s ",bzfrom,dsend);

	
	tmp_len = cm_buf_len(ReplyBuf);
	
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		return apiRC;
	else
		return api_OKComplete;
	
	errexit:
	if(exitsub(reply,SQLCODE) == True)
		return SQLCODE;
	else
		return apiRC;
}

long car175_single_query_M(reply)
serverReply reply;
{
	$char DBName[5],data_yyyymm_in[7],iclaim_in[21],istl_flag_in[2],ivictim_in[11];
	$long iclose_type_in,iserial_in;
	$char sIbranch_in[3];
	$char sFullName[21],stmt[4096],stmp[2048];
	$char buff[250];
	int tmp_len;
	
	$char data_yyyymm[7],iclm_company[3],iclm_br[3],iclaim[15],daccident[9],dclaim[9],istl_flag[2],dgroup[9];
	$char fsubrogation[2],fvictim_nation[2],ivictim[11],fhealth[2],flast[2],dhosp_start[9],dsend[9];
	$long iclose_type = 0,iself_duty = 0,mhealth = 0,iserial = 0;

	cm_buf_get("%s %s %s %d %s %s %d ",DBName,data_yyyymm_in,iclaim_in,&iclose_type_in,istl_flag_in,ivictim_in,&iserial_in);
	strcpy(iclaim_in,trim(iclaim_in));

	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}

	/* ���o�߮׸�Ʈw */
	$SELECT ibranch_in
	   INTO $sIbranch_in
	   FROM ca_clm_process
	  WHERE iclaim = $iclaim_in;
	  
	strcpy(sFullName, get_full_dbname(sIbranch_in));
 		
	sprintf_s(stmt, sizeof stmt,"SELECT data_yyyymm,iclm_company,iclm_br,iclaim, "
	                    " daccident,dclaim,iclose_type,istl_flag,dgroup, "
	                    " fsubrogation,iself_duty,mhealth, "
	                    " fvictim_nation,ivictim,fhealth,flast,iserial,dhosp_start,dsend "
	               " FROM %s:ca_dev_clm_health_comp "
	              " WHERE data_yyyymm = '%s' "
	                " AND iclaim      = '%s' "
	                " AND iclose_type =  %d  "
	                " AND istl_flag   = '%s' "
	                " AND ivictim     = '%s' "
	                " AND iserial     =  %d  ",sFullName,data_yyyymm_in,iclaim_in,iclose_type_in,istl_flag_in,ivictim_in,iserial_in);
     
	printf("stmt[%s]\n\n",stmt);    
	$PREPARE clm_health FROM $stmt;
	$EXECUTE clm_health INTO $data_yyyymm,$iclm_company,$iclm_br,$iclaim,
	                         $daccident,$dclaim,$iclose_type,$istl_flag,$dgroup,
	                         $fsubrogation,$iself_duty,$mhealth,
	                         $fvictim_nation,$ivictim,$fhealth,$flast,$iserial,$dhosp_start,$dsend;

	if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)     
			return M_CM_NOT_FOUND;                     
		else
			return apiRC;
	}
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l %s %s %s %s ",M_CM_OK,data_yyyymm,iclm_company,iclm_br,iclaim);
	cm_buf_put("%s %s %d %s %s ",daccident,dclaim,iclose_type,istl_flag,dgroup);
	cm_buf_put("%s %d %d ",fsubrogation,iself_duty,mhealth);
	cm_buf_put("%s %s %s %s %d %s %s ",fvictim_nation,ivictim,fhealth,flast,iserial,dhosp_start,dsend);
	
	tmp_len = cm_buf_len(ReplyBuf);
	
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		return apiRC;
	else
		return api_OKComplete;
	
	errexit:
	if(exitsub(reply,SQLCODE) == True)
		return SQLCODE;
	else
		return apiRC;
}

long car175_multiple_query_PE(reply)
serverReply reply;
{
	$char DBName[5],data_yyyymm_in[7],idata_in[2],ipolicy_in[21],iendorse_in[21],iedr_type_in[3];
	$char userid[11],stmt[1024],v_sMsg[2040],stmp[128];
	$char data_yyyymm[7],idata[2],ipolicy[21],iendorse[21],iedr_type[3];
	char tmpbuf[4000];
	int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
	int i,total_count=0;
	int top_40 = 0,top_20 = 0 ,rc;
	
	cm_buf_get("%s %s %s %s %s %s ",DBName,data_yyyymm_in,idata_in,ipolicy_in,iendorse_in,iedr_type_in);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}
	
	if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
		printf("get_db_list error accur \n");
		return SQLCODE;
	}
	
	for(int k=0 ; k<count_db ; k++)
	{
	
		sprintf_s(stmt, sizeof stmt,"SELECT data_yyyymm,idata,ipolicy,iendorse,iedr_type "
		               " FROM %s:ca_dev_ply_edr_comp  "
		              " WHERE data_yyyymm matches '%s' "
		                " AND idata       matches '%s' "
		                " AND ipolicy     matches '%s' "
		                " AND iendorse    matches '%s' "
		                " AND iedr_type   matches '%s' ",list[k].dbname,data_yyyymm_in,idata_in,ipolicy_in,iendorse_in,iedr_type_in);	
		printf("stmt[%s]\n",stmt);
		$PREPARE mq_ply_edrs FROM $stmt;
		$DECLARE mq_ply_edr CURSOR FOR mq_ply_edrs;
		$OPEN mq_ply_edr;
		
		for(;;)
		{	
			$FETCH mq_ply_edr INTO $data_yyyymm,$idata,$ipolicy,$iendorse,$iedr_type;
			
			if (SQLCODE != 0) break;
			cm_buf_init(tmpbuf);
			if ( count == 0 )
			{
				cm_buf_res_msg();             /* reserve for MsgCode and count */
				cm_buf_res_count();
			}
			
			cm_buf_put("%s %s %s %s %s ",data_yyyymm,idata,ipolicy,iendorse,iedr_type);
			tmp_len = cm_buf_len(tmpbuf);
			if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
			{
				memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
				repbuf_len += tmp_len;
				count++;
			}
			else                               /* more than 4K, send to client side */
			{
				cm_buf_init(ReplyBuf);
				cm_buf_put_msg(M_CM_OK);
				cm_buf_put_count(count);
				if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
				{
					$CLOSE q_cur;
					return apiRC;
				}
				else               /* clear ReplyBuf and count to start all over again */
				{
					replycnt++;
					if (replycnt == 10)   /* more than 30K, client cannot display,error */
					{
						cm_buf_init(ReplyBuf);
						cm_buf_put("%l",M_CM_OUT_SPACE);
						tmp_len = cm_buf_len(ReplyBuf);
						if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
						return apiRC;
						return M_CM_OUT_SPACE;
					}
					ReplyBuf[0] = '\0';
					count = 0;
					cm_buf_init(ReplyBuf);
					cm_buf_res_msg();           /* reserve for MsgCode and count */
					cm_buf_res_count();
					cm_buf_put("%s %s %s %s %s  ",data_yyyymm,idata,ipolicy,iendorse,iedr_type);
					repbuf_len = cm_buf_len(ReplyBuf);
					count++;
				}
			}
		} /* for loop */
	}
	$CLOSE mq_ply_edr;
	
	if (count > 0)   /* break out, at least one record is selected */
	{
		cm_buf_init(ReplyBuf);
		cm_buf_put_msg(M_CM_OK);
		cm_buf_put_count(count);
		if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
			return apiRC;
		return api_OKComplete;
	}
	else            /* break out, not any row is found */
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
			return M_CM_NOT_FOUND;                               /*?*/
		else
			return apiRC;
	}

errexit:
	if(exitsub(reply,SQLCODE) == True)
		return SQLCODE;
	else
		return apiRC;
}

long car175_multiple_query_CU(reply)
serverReply reply;
{
	$char DBName[5],data_yyyymm_in[7],idata_in[2],iclaim_in[21],fstl_in[2],iclose_type_in[5],istl_class_in[4];
	$char userid[11],stmt[1024],v_sMsg[2040],stmp[128];
	$char data_yyyymm[7],idata[2],iclaim[21],fstl[2],istl_class[4];
	$long iclose_type = 0;
	char tmpbuf[4000];
	int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
	int i,total_count=0;
	int top_40 = 0,top_20 = 0 ,rc;
	
	cm_buf_get("%s %s %s %s %s %s %s ",DBName,data_yyyymm_in,idata_in,iclaim_in,fstl_in,iclose_type_in,istl_class_in);
	strcpy(iclaim_in,trim(iclaim_in));
	strcpy(iclose_type_in,trim(iclose_type_in));
	
	if(strcmp(iclose_type_in,"*")==0)
		strcpy(stmp," ");
	else 
		sprintf_s(stmp, sizeof stmp,"iclose_type = %s",iclose_type_in);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
		return M_CM_DB_NOTOPEN;
		else
		return apiRC;
	}
	
	if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
		printf("get_db_list error accur \n");
		return SQLCODE;
	}
	
	for(int k=0 ; k<count_db ; k++)
	{
	
		sprintf_s(stmt, sizeof stmt,"SELECT data_yyyymm,idata,iclaim,fstl,iclose_type,istl_class "
		               " FROM %s:ca_dev_clm_comp  "
		              " WHERE data_yyyymm matches '%s' "
		                " AND idata       matches '%s' "
		                " AND iclaim      matches '%s' "
		                " AND fstl        matches '%s' "
		                " %s "
		                " AND istl_class  matches '%s' ",list[k].dbname,data_yyyymm_in,idata_in,iclaim_in,fstl_in,stmp,istl_class_in);	
		printf("stmt[%s]\n",stmt);
		$PREPARE mq_clms FROM $stmt;
		$DECLARE mq_clm CURSOR FOR mq_clms;
		$OPEN mq_clm;

		for(;;)
		{	
			$FETCH mq_clm INTO $data_yyyymm,$idata,$iclaim,$fstl,$iclose_type,$istl_class;
			
			if (SQLCODE != 0) break;
			cm_buf_init(tmpbuf);
			if ( count == 0 )
			{
				cm_buf_res_msg();             /* reserve for MsgCode and count */
				cm_buf_res_count();
			}
			
			cm_buf_put("%s %s %s %s %d %s ",data_yyyymm,idata,iclaim,fstl,iclose_type,istl_class);
			tmp_len = cm_buf_len(tmpbuf);
			if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
			{
				memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
				repbuf_len += tmp_len;
				count++;
			}
			else                               /* more than 4K, send to client side */
			{
				cm_buf_init(ReplyBuf);
				cm_buf_put_msg(M_CM_OK);
				cm_buf_put_count(count);
				if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
				{
					$CLOSE q_cur;
					return apiRC;
				}
				else               /* clear ReplyBuf and count to start all over again */
				{
					replycnt++;
					if (replycnt == 10)   /* more than 30K, client cannot display,error */
					{
						cm_buf_init(ReplyBuf);
						cm_buf_put("%l",M_CM_OUT_SPACE);
						tmp_len = cm_buf_len(ReplyBuf);
						if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
						return apiRC;
						return M_CM_OUT_SPACE;
					}
					ReplyBuf[0] = '\0';
					count = 0;
					cm_buf_init(ReplyBuf);
					cm_buf_res_msg();           /* reserve for MsgCode and count */
					cm_buf_res_count();
					cm_buf_put("%s %s %s %s %d %s ",data_yyyymm,idata,iclaim,fstl,iclose_type,istl_class);
					repbuf_len = cm_buf_len(ReplyBuf);
					count++;
				}
			}
		} /* for loop */
	}
	$CLOSE mq_clm;
	
	if (count > 0)   /* break out, at least one record is selected */
	{
		cm_buf_init(ReplyBuf);
		cm_buf_put_msg(M_CM_OK);
		cm_buf_put_count(count);
		if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
			return apiRC;
		return api_OKComplete;
	}
	else            /* break out, not any row is found */
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
			return M_CM_NOT_FOUND;                               /*?*/
		else
			return apiRC;
	}

errexit:
	if(exitsub(reply,SQLCODE) == True)
		return SQLCODE;
	else
		return apiRC;
}

long car175_multiple_query_S(reply)
serverReply reply;
{
	$char DBName[5],data_yyyymm_in[7],iclaim_in[21],fstl_in[2],iclose_type_in[5],ivictim_in[11],iins_item_in[5];
	$char userid[11],stmt[1024],v_sMsg[2040],stmp[128];
	$char data_yyyymm[7],iclaim[21],fstl[2],ivictim[11],iins_item[5];
	$long iclose_type = 0;
	char tmpbuf[4000];
	int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
	int i,total_count=0;
	int top_40 = 0,top_20 = 0 ,rc;
	
	cm_buf_get("%s %s %s %s %s %s %s ",DBName,data_yyyymm_in,iclaim_in,fstl_in,iclose_type_in,ivictim_in,iins_item_in);
	strcpy(iclaim_in,trim(iclaim_in));
	strcpy(iclose_type_in,trim(iclose_type_in));
	
	if(strcmp(iclose_type_in,"*")==0)
		strcpy(stmp," ");
	else 
		sprintf_s(stmp, sizeof stmp,"iclose_type = %s",iclose_type_in);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
		return M_CM_DB_NOTOPEN;
		else
		return apiRC;
	}
	
	if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
		printf("get_db_list error accur \n");
		return SQLCODE;
	}
	
	for(int k=0 ; k<count_db ; k++)
	{
	
		sprintf_s(stmt, sizeof stmt,"SELECT data_yyyymm,iclaim,fstl,iclose_type,ivictim,iins_item "
		               " FROM %s:ca_dev_clm_vic_comp  "
		              " WHERE data_yyyymm matches '%s' "
		                " AND iclaim      matches '%s' "
		                " AND fstl        matches '%s' "
		                " %s "
		                " AND ivictim     matches '%s' "
		                " AND iins_item   matches '%s' ",list[k].dbname,data_yyyymm_in,iclaim_in,fstl_in,stmp,ivictim_in,iins_item_in);	
		printf("stmt[%s]\n",stmt);
		$PREPARE mq_clm_vics FROM $stmt;
		$DECLARE mq_clm_vic CURSOR FOR mq_clm_vics;
		$OPEN mq_clm_vic;
		
		for(;;)
		{	
			$FETCH mq_clm_vic INTO $data_yyyymm,$iclaim,$fstl,$iclose_type,$ivictim,$iins_item;
			
			if (SQLCODE != 0) break;
			cm_buf_init(tmpbuf);
			if ( count == 0 )
			{
				cm_buf_res_msg();             /* reserve for MsgCode and count */
				cm_buf_res_count();
			}
			
			cm_buf_put("%s %s %s %d %s %s ",data_yyyymm,iclaim,fstl,iclose_type,ivictim,iins_item);
			tmp_len = cm_buf_len(tmpbuf);
			if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
			{
				memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
				repbuf_len += tmp_len;
				count++;
			}
			else                               /* more than 4K, send to client side */
			{
				cm_buf_init(ReplyBuf);
				cm_buf_put_msg(M_CM_OK);
				cm_buf_put_count(count);
				if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
				{
					$CLOSE q_cur;
					return apiRC;
				}
				else               /* clear ReplyBuf and count to start all over again */
				{
					replycnt++;
					if (replycnt == 10)   /* more than 30K, client cannot display,error */
					{
						cm_buf_init(ReplyBuf);
						cm_buf_put("%l",M_CM_OUT_SPACE);
						tmp_len = cm_buf_len(ReplyBuf);
						if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
						return apiRC;
						return M_CM_OUT_SPACE;
					}
					ReplyBuf[0] = '\0';
					count = 0;
					cm_buf_init(ReplyBuf);
					cm_buf_res_msg();           /* reserve for MsgCode and count */
					cm_buf_res_count();
					cm_buf_put("%s %s %s %d %s %s ",data_yyyymm,iclaim,fstl,iclose_type,ivictim,iins_item);
					repbuf_len = cm_buf_len(ReplyBuf);
					count++;
				}
			}
		} /* for loop */
	}
	$CLOSE mq_clm_vic;
	
	if (count > 0)   /* break out, at least one record is selected */
	{
		cm_buf_init(ReplyBuf);
		cm_buf_put_msg(M_CM_OK);
		cm_buf_put_count(count);
		if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
			return apiRC;
		return api_OKComplete;
	}
	else            /* break out, not any row is found */
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
			return M_CM_NOT_FOUND;                               /*?*/
		else
			return apiRC;
	}

errexit:
	if(exitsub(reply,SQLCODE) == True)
		return SQLCODE;
	else
		return apiRC;
}

long car175_multiple_query_M(reply)
serverReply reply;
{
	$char DBName[5],data_yyyymm_in[7],iclaim_in[21],iclose_type_in[5],istl_flag_in[2],ivictim_in[11],iserial_in[5];
	$char userid[11],stmt[1024],v_sMsg[2040],stmp[128],stmp2[128];
	$char data_yyyymm[7],iclaim[21],istl_flag[2],ivictim[11];
	$long iclose_type = 0,iserial = 0;
	char tmpbuf[4000];
	int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
	int i,total_count=0;
	int top_40 = 0,top_20 = 0 ,rc;
	
	cm_buf_get("%s %s %s %s %s %s %s ",DBName,data_yyyymm_in,iclaim_in,iclose_type_in,istl_flag_in,ivictim_in,iserial_in);
	strcpy(iclaim_in,trim(iclaim_in));
	strcpy(iclose_type_in,trim(iclose_type_in));
	strcpy(iserial_in,trim(iserial_in));
	
	if(strcmp(iclose_type_in,"*")==0)
		strcpy(stmp," ");
	else 
		sprintf_s(stmp, sizeof stmp,"iclose_type = %s",iclose_type_in);
		
	if(strcmp(iserial_in,"*")==0)
		strcpy(stmp2," ");
	else 
		sprintf_s(stmp2, sizeof stmp2,"iserial = %s",iserial_in);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
		return M_CM_DB_NOTOPEN;
		else
		return apiRC;
	}
	
	if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
		printf("get_db_list error accur \n");
		return SQLCODE;
	}
	
	for(int k=0 ; k<count_db ; k++)
	{
	
		sprintf_s(stmt, sizeof stmt,"SELECT data_yyyymm,iclaim,iclose_type,istl_flag,ivictim,iserial "
		               " FROM %s:ca_dev_clm_health_comp  "
		              " WHERE data_yyyymm matches '%s' "
		                " AND iclaim      matches '%s' "
		                " %s "
		                " AND istl_flag   matches '%s' "
		                " AND ivictim     matches '%s' "
		                " %s ",list[k].dbname,data_yyyymm_in,iclaim_in,stmp,istl_flag_in,ivictim_in,stmp2);	
		printf("stmt[%s]\n",stmt);
		$PREPARE mq_clm_healths FROM $stmt;
		$DECLARE mq_clm_health CURSOR FOR mq_clm_healths;
		$OPEN mq_clm_health;
		
		for(;;)
		{	
			$FETCH mq_clm_health INTO $data_yyyymm,$iclaim,$iclose_type,$istl_flag,$ivictim,$iserial;
			
			if (SQLCODE != 0) break;
			cm_buf_init(tmpbuf);
			if ( count == 0 )
			{
				cm_buf_res_msg();             /* reserve for MsgCode and count */
				cm_buf_res_count();
			}
			
			cm_buf_put("%s %s %d %s %s %d ",data_yyyymm,iclaim,iclose_type,istl_flag,ivictim,iserial);
			tmp_len = cm_buf_len(tmpbuf);
			if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
			{
				memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
				repbuf_len += tmp_len;
				count++;
			}
			else                               /* more than 4K, send to client side */
			{
				cm_buf_init(ReplyBuf);
				cm_buf_put_msg(M_CM_OK);
				cm_buf_put_count(count);
				if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
				{
					$CLOSE q_cur;
					return apiRC;
				}
				else               /* clear ReplyBuf and count to start all over again */
				{
					replycnt++;
					if (replycnt == 10)   /* more than 30K, client cannot display,error */
					{
						cm_buf_init(ReplyBuf);
						cm_buf_put("%l",M_CM_OUT_SPACE);
						tmp_len = cm_buf_len(ReplyBuf);
						if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
						return apiRC;
						return M_CM_OUT_SPACE;
					}
					ReplyBuf[0] = '\0';
					count = 0;
					cm_buf_init(ReplyBuf);
					cm_buf_res_msg();           /* reserve for MsgCode and count */
					cm_buf_res_count();
					cm_buf_put("%s %s %d %s %s %d ",data_yyyymm,iclaim,iclose_type,istl_flag,ivictim,iserial);
					repbuf_len = cm_buf_len(ReplyBuf);
					count++;
				}
			}
		} /* for loop */
	}
	$CLOSE mq_clm_health;
	
	if (count > 0)   /* break out, at least one record is selected */
	{
		cm_buf_init(ReplyBuf);
		cm_buf_put_msg(M_CM_OK);
		cm_buf_put_count(count);
		if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
			return apiRC;
		return api_OKComplete;
	}
	else            /* break out, not any row is found */
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
			return M_CM_NOT_FOUND;                               /*?*/
		else
			return apiRC;
	}

errexit:
	if(exitsub(reply,SQLCODE) == True)
		return SQLCODE;
	else
		return apiRC;
}

long car175_update_exec_PE(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	$char   stmt[4096],DBName[5],sFullName[21];
	$char   data_yyyymm[7],idata[2],ipolicy[21],iendorse[21],iedr_type_tmp[3];
	$char   iarea[3],iissue_year[5],ipro_year[5],ibrand[9],icar_type[3],icar_type_no[3];
	$char   iengine[26],itag[13],fpt[2],fassured[2],iassured[11],dbirth[9],fsex[2],fmarriage[2];
	$char   fcomp_class_last[3],fcomp_class[3],iedr_type[3];
	$char   iproduct[13],drate_ym[7],bzfrom[3];
	$long   qcylinder,qpt,qdrunk_driving,mdrunk_prem;
	$double mdrunk_pure_prem;
	$char   mdrunk_pure_prem_tmp[13];
	dec_t   dec_mdrunk_pure_prem;
		
	char  option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
	int   tmp_len,raw_len;
	long  dummy;
	long  MsgCode;
	DBinfo *list;
	int   i, j, is_del_fail=0, is_upd_fail=0;
	$char stmt_buf[300];

	comm = (char *) command;
	cm_buf_init(command);
	cm_buf_get("%c %s %s %s %s %s %s ",&option,DBName,data_yyyymm,idata,ipolicy,iendorse,iedr_type_tmp);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}
	  
	if(idata[0] == 'P')
		strcpy(sFullName, get_car_full_db(ipolicy));
 	else 
 		strcpy(sFullName, get_car_full_db(iendorse));

	$BEGIN WORK;
	cm_buf_get("%s %s %s %s %s %s ",iarea,iissue_year,ipro_year,ibrand,icar_type,icar_type_no);
	cm_buf_get("%d %s %s %d %s ",&qcylinder,iengine,itag,&qpt,fpt);
	cm_buf_get("%s %s %s %s %s ",fassured,iassured,dbirth,fsex,fmarriage);
	cm_buf_get("%s %s %s ",fcomp_class_last,fcomp_class,iedr_type);
	cm_buf_get("%d %d %s ",&qdrunk_driving,&mdrunk_prem,mdrunk_pure_prem_tmp);
	cm_buf_get("%s %s %s ",iproduct,drate_ym,bzfrom);
	
	printf("iarea[%s],iissue_year[%s],ipro_year[%s],ibrand[%s],icar_type[%s],icar_type_no[%s], \n",iarea,iissue_year,ipro_year,ibrand,icar_type,icar_type_no);
	printf("qcylinder[%d],iengine[%s],itag[%s],qpt[%d],fpt[%s], \n",qcylinder,iengine,itag,qpt,fpt);
	printf("fassured[%s],iassured[%s],dbirth[%s],fsex[%s],fmarriage[%s], \n",fassured,iassured,dbirth,fsex,fmarriage);
	printf("fcomp_class_last[%s],fcomp_class[%s],iedr_type[%s], \n",fcomp_class_last,fcomp_class,iedr_type);
	printf("qdrunk_driving[%d],mdrunk_prem[%d],mdrunk_pure_prem_tmp[%s],\n",qdrunk_driving,mdrunk_prem,mdrunk_pure_prem_tmp);
	printf("iproduct[%s],drate_ym[%s],bzfrom[%s], \n",iproduct,drate_ym,bzfrom);

	/** convert from string to DECIMAL type **/
	deccvasc(mdrunk_pure_prem_tmp,strlen(mdrunk_pure_prem_tmp),&dec_mdrunk_pure_prem);
	dectodbl(&dec_mdrunk_pure_prem,&mdrunk_pure_prem);
	printf("mdrunk_pure_prem[%f] \n",mdrunk_pure_prem);
	
	/* �ݩ�򥻸�Ƴ����A�׸��㵧�� */
	sprintf_s(stmt, sizeof stmt,"UPDATE %s:ca_dev_ply_edr_comp "
	                " SET (iarea,iissue_year,ipro_year,ibrand,icar_type,icar_type_no, "
	                    " qcylinder,iengine,itag,qpt,fpt, "
	                    " fassured,iassured,dbirth,fsex,fmarriage, "
	                    " fcomp_class_last,fcomp_class,iedr_type, "
	                    " qdrunk_driving,mdrunk_prem,mdrunk_pure_prem, "
	                    " iproduct,drate_ym,bzfrom) "
	                 " = ('%s','%s','%s','%s','%s','%s', "
	                    "  %d ,'%s','%s', %d ,'%s', "
	                    " '%s','%s','%s','%s','%s', "
	                    " '%s','%s','%s', "
	                    "  %d , %d ,%.4f, "
	                    " '%s','%s','%s') "
	             " WHERE data_yyyymm = '%s' "
	               " AND idata       = '%s' "
	               " AND ipolicy     = '%s' "
	               " AND iendorse    = '%s' "
	               " AND iedr_type   = '%s'",sFullName,
	                                         iarea,iissue_year,ipro_year,ibrand,icar_type,icar_type_no,
	                                         qcylinder,iengine,itag,qpt,fpt,
	                                         fassured,iassured,dbirth,fsex,fmarriage,
	                                         fcomp_class_last,fcomp_class,iedr_type,
	                                         qdrunk_driving,mdrunk_prem,mdrunk_pure_prem,
	                                         iproduct,drate_ym,bzfrom,
	                                         data_yyyymm,idata,ipolicy,iendorse,iedr_type);
	printf("stmt[%s]\n",stmt);
	$PREPARE upd_ply_edr FROM $stmt;
	$EXECUTE upd_ply_edr;

	if(sqlca.sqlerrd[2] == 0)
	{
		  printf("no rows has been updated then insert it\n");
	}
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	tmp_len = cm_buf_len(ReplyBuf);
	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
	{
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		return apiRC;
	}
	$WHENEVER SQLERROR GOTO errexit;
	$COMMIT WORK;
	return api_OKComplete;

errexit:
	MsgCode = SQLCODE;
	$WHENEVER SQLERROR CONTINUE;
	$ROLLBACK WORK;              /* rollback fail */
	if(SQLCODE != 0) MsgCode = SQLCODE;
	if(exitsub(reply,MsgCode) == True)
	 return MsgCode;
	else
	 return apiRC;
}

long car175_update_exec_CU(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	$char stmt[4096],DBName[5],sFullName[21];
	$char data_yyyymm[7],idata[2],iclaim[21],fstl_tmp[2],istl_class_tmp[4];
	$long iclose_type_tmp;
	$char sIbranch_in[3];

	$char   fend_yn[2],fstl[2],istl_recover[2],ihealth[2],istl_flag[2],iissue_year[5],ipro_year[5],ibrand[9];
	$char   icar_type[3],icar_type_no[3],iengine[26],itag[13],fpt[2];
	$char   ioth_fassured[2],ioth_cartype[3],ioth_fpt[2],ioth_tag[13],ioth_comp_yn[2],ioth_card_company[3],ioth_card[18],fcomp_class[3];
	$char   drate_ym[7],fassured[2],iassured[11],dbirth[8],fsex[2],fmarriage[2];
	$char   facc_nation[2],iacc_license[11],iacc_birth[8],facc_sex[2],facc_marri[2],facc_rel[2];
	$char   iacc_reason[3],facc_duty[2],fsubrogation[2];
	$char   iacc_area[3],istl_class[4],iproduct[13],bzfrom[3];
	$long   iclose_type,qcylinder,qpt,ioth_qpt,qdrunk_driving,mdrunk_prem;
	$long   iself_duty,ioth_duty,ianoth_duty;
	$long   qacar_death,qacar_cripple,qacar_injure,qbcar_death,qbcar_cripple,qbcar_injure,qccar_death,qccar_cripple,qccar_injure;
	$long   mcoverage,victim_num;
	$double mdrunk_pure_prem;
	$char   mdrunk_pure_prem_tmp[13];
	dec_t dec_mdrunk_pure_prem;
		
	char  option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
	int   tmp_len,raw_len;
	long  dummy;
	long  MsgCode;
	DBinfo *list;
	int   i, j, is_del_fail=0, is_upd_fail=0;
	$char stmt_buf[300];

	comm = (char *) command;
	cm_buf_init(command);
	cm_buf_get("%c %s %s %s %s %s %d ",&option,DBName,data_yyyymm,idata,iclaim,fstl_tmp,&iclose_type_tmp);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}
	
	/* ���o�߮׸�Ʈw */
	$SELECT ibranch_in
	   INTO $sIbranch_in
	   FROM ca_clm_process
	  WHERE iclaim = $iclaim;
	  
	strcpy(sFullName, get_full_dbname(sIbranch_in));

	$BEGIN WORK;
	cm_buf_get("%s %s %s %s %d %s %s %s ",fend_yn,fstl,istl_recover,ihealth,&iclose_type,istl_flag,iissue_year,ipro_year);
	cm_buf_get("%s %s %s %d %s %s %d %s ",ibrand,icar_type,icar_type_no,&qcylinder,iengine,itag,&qpt,fpt);
	cm_buf_get("%s %s %d %s %s %s %s %s ",ioth_fassured,ioth_cartype,&ioth_qpt,ioth_fpt,ioth_tag,ioth_comp_yn,ioth_card_company,ioth_card);
	cm_buf_get("%s %d %d %s %s ",fcomp_class,&qdrunk_driving,&mdrunk_prem,mdrunk_pure_prem_tmp,drate_ym);
	cm_buf_get("%s %s %s %s %s %s ",fassured,iassured,dbirth,fsex,fmarriage,facc_nation);
	cm_buf_get("%s %s %s %s %s ",iacc_license,iacc_birth,facc_sex,facc_marri,facc_rel);
	cm_buf_get("%s %s %s %d %d %d ",iacc_reason,facc_duty,fsubrogation,&iself_duty,&ioth_duty,&ianoth_duty);
	cm_buf_get("%d %d %d %d %d %d %d %d %d ",&qacar_death,&qacar_cripple,&qacar_injure,&qbcar_death,&qbcar_cripple,&qbcar_injure,&qccar_death,&qccar_cripple,&qccar_injure);
	cm_buf_get("%s %d %d %s %s ",iacc_area,&mcoverage,&victim_num,iproduct,bzfrom);
	
	printf("fend_yn[%s],fstl[%s],istl_recover[%s],ihealth[%s],iclose_type[%d],istl_flag[%s],iissue_year[%s],ipro_year[%s] \n",fend_yn,fstl,istl_recover,ihealth,iclose_type,istl_flag,iissue_year,ipro_year);
	printf("ibrand[%s],icar_type[%s],icar_type_no[%s],qcylinder[%d],iengine[%s],itag[%s],qpt[%d],fpt[%s] \n",ibrand,icar_type,icar_type_no,qcylinder,iengine,itag,qpt,fpt);
	printf("ioth_fassured[%s],ioth_cartype[%s],ioth_qpt[%d],ioth_fpt[%s],ioth_tag[%s],ioth_comp_yn[%s],ioth_card_company[%s],ioth_card[%s] \n",ioth_fassured,ioth_cartype,ioth_qpt,ioth_fpt,ioth_tag,ioth_comp_yn,ioth_card_company,ioth_card);
	printf("fcomp_class[%s],qdrunk_driving[%d],mdrunk_prem[%d],mdrunk_pure_prem_tmp[%s],drate_ym[%s] \n",fcomp_class,qdrunk_driving,mdrunk_prem,mdrunk_pure_prem_tmp,drate_ym);
	printf("fassured[%s],iassured[%s],dbirth[%s],fsex[%s],fmarriage[%s],facc_nation[%s] \n",fassured,iassured,dbirth,fsex,fmarriage,facc_nation);
	printf("iacc_license[%s],iacc_birth[%s],facc_sex[%s],facc_marri[%s],facc_rel[%s] \n",iacc_license,iacc_birth,facc_sex,facc_marri,facc_rel);
	printf("iacc_reason[%s],facc_duty[%s],fsubrogation[%s],iself_duty[%d],ioth_duty[%d],ianoth_duty[%d] \n",iacc_reason,facc_duty,fsubrogation,iself_duty,ioth_duty,ianoth_duty);
	printf("qacar_death[%d],qacar_cripple[%d],qacar_injure[%d],qbcar_death[%d],qbcar_cripple[%d],qbcar_injure[%d],qccar_death[%d],qccar_cripple[%d],qccar_injure[%d] \n",qacar_death,qacar_cripple,qacar_injure,qbcar_death,qbcar_cripple,qbcar_injure,qccar_death,qccar_cripple,qccar_injure);
	printf("iacc_area[%s],istl_class[%s],mcoverage[%d],victim_num[%d],iproduct[%s],bzfrom[%s] \n",iacc_area,istl_class,mcoverage,victim_num,iproduct,bzfrom);

	/** convert from string to DECIMAL type **/
	deccvasc(mdrunk_pure_prem_tmp,strlen(mdrunk_pure_prem_tmp),&dec_mdrunk_pure_prem);
	dectodbl(&dec_mdrunk_pure_prem,&mdrunk_pure_prem);
	printf("mdrunk_pure_prem[%f] \n",mdrunk_pure_prem);
	
	/* �ݩ�򥻸�Ƴ����A�׸��㵧�� */
	/* istl_class */
	sprintf_s(stmt, sizeof stmt,"UPDATE %s:ca_dev_clm_comp "
	                " SET (fend_yn,fstl,istl_recover,ihealth,iclose_type,istl_flag,iissue_year,ipro_year, "
	                    " ibrand,icar_type,icar_type_no,qcylinder,iengine,itag,qpt,fpt, "
	                    " ioth_fassured,ioth_cartype,ioth_qpt,ioth_fpt,ioth_tag,ioth_comp_yn,ioth_card_company,ioth_card, "
	                    " fcomp_class,qdrunk_driving,mdrunk_prem,mdrunk_pure_prem,drate_ym, "
	                    " fassured,iassured,dbirth,fsex,fmarriage,facc_nation, "
	                    " iacc_license,iacc_birth,facc_sex,facc_marri,facc_rel, "
	                    " iacc_reason,facc_duty,fsubrogation,iself_duty,ioth_duty,ianoth_duty, "
	                    " qacar_death,qacar_cripple,qacar_injure,qbcar_death,qbcar_cripple,qbcar_injure,qccar_death,qccar_cripple,qccar_injure, "
	                    " iacc_area,mcoverage,victim_num,iproduct,bzfrom) "
	                  " = ('%s','%s','%s','%s', %d ,'%s','%s','%s', "
	                    " '%s','%s','%s', %d ,'%s','%s', %d ,'%s', "
	                    " '%s','%s', %d ,'%s','%s','%s','%s','%s', "
	                    " '%s', %d , %d ,%.4f,'%s', "
	                    " '%s','%s','%s','%s','%s','%s', "
	                    " '%s','%s','%s','%s','%s', "
	                    " '%s','%s','%s', %d , %d , %d , "
	                    "  %d , %d , %d , %d , %d , %d , %d , %d , %d , "
	                    " '%s', %d , %d ,'%s','%s') "
	              " WHERE data_yyyymm = '%s' "
	                " AND idata       = '%s' "
	                " AND iclaim      = '%s' "
	                " AND fstl        = '%s' "
	                " AND iclose_type =  %d",sFullName,
	                                        fend_yn,fstl,istl_recover,ihealth,iclose_type,istl_flag,iissue_year,ipro_year,
	                                        ibrand,icar_type,icar_type_no,qcylinder,iengine,itag,qpt,fpt,
	                                        ioth_fassured,ioth_cartype,ioth_qpt,ioth_fpt,ioth_tag,ioth_comp_yn,ioth_card_company,ioth_card,
	                                        fcomp_class,qdrunk_driving,mdrunk_prem,mdrunk_pure_prem,drate_ym,
	                                        fassured,iassured,dbirth,fsex,fmarriage,facc_nation,
	                                        iacc_license,iacc_birth,facc_sex,facc_marri,facc_rel,
	                                        iacc_reason,facc_duty,fsubrogation,iself_duty,ioth_duty,ianoth_duty,
	                                        qacar_death,qacar_cripple,qacar_injure,qbcar_death,qbcar_cripple,qbcar_injure,qccar_death,qccar_cripple,qccar_injure,
	                                        iacc_area,mcoverage,victim_num,iproduct,bzfrom,
	                                        data_yyyymm,idata,iclaim,fstl_tmp,iclose_type_tmp);
	printf("stmt[%s]\n",stmt);
	$PREPARE upd_clm FROM $stmt;
	$EXECUTE upd_clm;

	if(sqlca.sqlerrd[2] == 0)
	{
		  printf("no rows has been updated then insert it\n");
	}
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	tmp_len = cm_buf_len(ReplyBuf);
	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
	{
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		return apiRC;
	}
	$WHENEVER SQLERROR GOTO errexit;
	$COMMIT WORK;
	return api_OKComplete;

errexit:
	MsgCode = SQLCODE;
	$WHENEVER SQLERROR CONTINUE;
	$ROLLBACK WORK;              /* rollback fail */
	if(SQLCODE != 0) MsgCode = SQLCODE;
	if(exitsub(reply,MsgCode) == True)
	 return MsgCode;
	else
	 return apiRC;
}

long car175_update_exec_S(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	$char stmt[4096],DBName[5],sFullName[21];
	$char data_yyyymm[7],idata[2],iclaim[21],fstl_tmp[2],ivictim_tmp[11],iins_item_tmp[5];
	$long iclose_type_tmp;
	$char sIbranch_in[3];
	
	$char fend_yn[2],fstl[2],istl_recover[2],ihealth[2],istl_flag[2];
	$char fvictim_nation[2],ivictim[11],dvictim_yy[5],fvictim_sex[2],fvictim_car[2];
	$char fsubrogation[3],iins_item_1[2],fhealth[2],flast[2];
	$char iacc_area[3],iply_area[3],iacc_reason[3],iins_item[5],bzfrom[3];
	$long iclose_type,iself_duty;
		
	char  option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
	int   tmp_len,raw_len;
	long  dummy;
	long  MsgCode;
	DBinfo *list;
	int   i, j, is_del_fail=0, is_upd_fail=0;
	$char stmt_buf[300];

	comm = (char *) command;
	cm_buf_init(command);
	cm_buf_get("%c %s %s %s %s %d %s %s",&option,DBName,data_yyyymm,iclaim,fstl_tmp,&iclose_type_tmp,ivictim_tmp,iins_item_tmp);
	
	$WHENEVER SQLERROR GOTO errexit;
	$BEGIN WORK;
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}
	
	/* ���o�߮׸�Ʈw */
	$SELECT ibranch_in
	   INTO $sIbranch_in
	   FROM ca_clm_process
	  WHERE iclaim = $iclaim;
	  
	strcpy(sFullName, get_full_dbname(sIbranch_in));

	cm_buf_get("%s %s %s %s %d %s ",fend_yn,fstl,istl_recover,ihealth,&iclose_type,istl_flag);
	cm_buf_get("%s %s %s %s %s ",fvictim_nation,ivictim,dvictim_yy,fvictim_sex,fvictim_car);
	cm_buf_get("%s %d %s %s %s ",fsubrogation,&iself_duty,iins_item_1,fhealth,flast);
	cm_buf_get("%s %s %s %s %s ",iacc_area,iply_area,iacc_reason,iins_item,bzfrom);
	
	printf("fend_yn[%s],fstl[%s],istl_recover[%s],ihealth[%s],iclose_type[%d],istl_flag[%s] \n",fend_yn,fstl,istl_recover,ihealth,iclose_type,istl_flag);
	printf("fvictim_nation[%s],ivictim[%s],dvictim_yy[%s],fvictim_sex[%s],fvictim_car[%s] \n",fvictim_nation,ivictim,dvictim_yy,fvictim_sex,fvictim_car);
	printf("fsubrogation[%s],iself_duty[%d],iins_item_1[%s],fhealth[%s],flast[%s] \n",fsubrogation,iself_duty,iins_item_1,fhealth,flast);
	printf("iacc_area[%s],iply_area[%s],iacc_reason[%s],iins_item[%s],bzfrom[%s] \n",iacc_area,iply_area,iacc_reason,iins_item,bzfrom);

	/* �ݩ�򥻸�Ƴ����A�׸��㵧�� */
	sprintf_s(stmt, sizeof stmt,"UPDATE %s:ca_dev_clm_vic_comp "
	                " SET (fend_yn,fstl,istl_recover,ihealth,iclose_type,istl_flag, "
	                     " fvictim_nation,ivictim,dvictim_yy,fvictim_sex,fvictim_car, "
	                     " fsubrogation,iself_duty,iins_item_1,fhealth,flast, "
	                     " iacc_area,iply_area,iacc_reason,iins_item,bzfrom) "
	                  " = ('%s','%s','%s','%s', %d ,'%s', "
	                     " '%s','%s','%s','%s','%s', "
	                     " '%s', %d ,'%s','%s','%s', "
	                     " '%s','%s','%s','%s','%s') "
	              " WHERE data_yyyymm = '%s' "
	                " AND iclaim      = '%s' "
	                " AND fstl        = '%s' "
	                " AND iclose_type =  %d  "
	                " AND ivictim     = '%s' "
	                " AND iins_item   = '%s' ",sFullName,
	                                          fend_yn,fstl,istl_recover,ihealth,iclose_type,istl_flag,
	                                          fvictim_nation,ivictim,dvictim_yy,fvictim_sex,fvictim_car,
	                                          fsubrogation,iself_duty,iins_item_1,fhealth,flast,
	                                          iacc_area,iply_area,iacc_reason,iins_item,bzfrom,
	                                          data_yyyymm,iclaim,fstl_tmp,iclose_type_tmp,ivictim_tmp,iins_item_tmp);
	printf("stmt[%s]\n",stmt);
	$PREPARE upd_clm_vic FROM $stmt;
	$EXECUTE upd_clm_vic;

	if(sqlca.sqlerrd[2] == 0)
	{
		  printf("no rows has been updated then insert it\n");
	}
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	tmp_len = cm_buf_len(ReplyBuf);
	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
	{
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		return apiRC;
	}
	$WHENEVER SQLERROR GOTO errexit;
	$COMMIT WORK;
	return api_OKComplete;

errexit:
	MsgCode = SQLCODE;
	$WHENEVER SQLERROR CONTINUE;
	$ROLLBACK WORK;              /* rollback fail */
	if(SQLCODE != 0) MsgCode = SQLCODE;
	if(exitsub(reply,MsgCode) == True)
	 return MsgCode;
	else
	 return apiRC;
}

long car175_update_exec_M(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	$char stmt[4096],DBName[5],sFullName[21];
	$char data_yyyymm[7],idata[2],iclaim[21],istl_flag_tmp[2],ivictim_tmp[11];
	$long iclose_type_tmp,iserial_tmp;
	$char sIbranch_in[3];
	
	$char istl_flag[2],fsubrogation[2],fvictim_nation[2],ivictim[11],fhealth[2],flast[2],dhosp_start[9];
	$long iclose_type,iself_duty,iserial;

	char  option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
	int   tmp_len,raw_len;
	long  dummy;
	long  MsgCode;
	DBinfo *list;
	int   i, j, is_del_fail=0, is_upd_fail=0;
	$char stmt_buf[300];

	comm = (char *) command;
	cm_buf_init(command);
	cm_buf_get("%c %s %s %s %d %s %s %d ",&option,DBName,data_yyyymm,iclaim,&iclose_type_tmp,istl_flag_tmp,ivictim_tmp,&iserial_tmp);

	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}
	
	/* ���o�߮׸�Ʈw */
	$SELECT ibranch_in
	   INTO $sIbranch_in
	   FROM ca_clm_process
	  WHERE iclaim = $iclaim;

	strcpy(sFullName, get_full_dbname(sIbranch_in));

	$BEGIN WORK;
	cm_buf_get("%d %s %s %d %s ",&iclose_type,istl_flag,fsubrogation,&iself_duty,fvictim_nation);
	cm_buf_get("%s %s %s %d %s ",ivictim,fhealth,flast,&iserial,dhosp_start);
	printf("iclose_type[%d],istl_flag[%s],fsubrogation[%s],iself_duty[%d],fvictim_nation[%s] \n",iclose_type,istl_flag,fsubrogation,iself_duty,fvictim_nation);
	printf("ivictim[%s],fhealth[%s],flast[%s],iserial[%d],dhosp_start[%s] \n",ivictim,fhealth,flast,iserial,dhosp_start);

	/* �ݩ�򥻸�Ƴ����A�׸��㵧�� */
	sprintf_s(stmt, sizeof stmt,"UPDATE %s:ca_dev_clm_health_comp "
	                " SET (iclose_type,istl_flag,fsubrogation,iself_duty,fvictim_nation, "
	                     " ivictim,fhealth,flast,iserial,dhosp_start ) "
	                  " = ( %d ,'%s','%s', %d ,'%s', "
	                     " '%s','%s','%s', %d ,'%s') "
	              " WHERE data_yyyymm = '%s' "
	                " AND iclaim      = '%s' "
	                " AND iclose_type =  %d  "
	                " AND istl_flag   = '%s' "
	                " AND ivictim     = '%s' "
	                " AND iserial     =  %d ",sFullName,
	                                          iclose_type,istl_flag,fsubrogation,iself_duty,fvictim_nation,
	                                          ivictim,fhealth,flast,iserial,dhosp_start,
	                                          data_yyyymm,iclaim,iclose_type_tmp,istl_flag_tmp,ivictim_tmp,iserial_tmp);
	printf("stmt[%s]\n",stmt);
	$PREPARE upd_clm_health FROM $stmt;
	$EXECUTE upd_clm_health;

	if(sqlca.sqlerrd[2] == 0)
	{
		  printf("no rows has been updated then insert it\n");
	}
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	tmp_len = cm_buf_len(ReplyBuf);
	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
	{
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		return apiRC;
	}
	$WHENEVER SQLERROR GOTO errexit;
	$COMMIT WORK;
	return api_OKComplete;

errexit:
	MsgCode = SQLCODE;
	$WHENEVER SQLERROR CONTINUE;
	$ROLLBACK WORK;              /* rollback fail */
	if(SQLCODE != 0) MsgCode = SQLCODE;
	if(exitsub(reply,MsgCode) == True)
	 return MsgCode;
	else
	 return apiRC;
}