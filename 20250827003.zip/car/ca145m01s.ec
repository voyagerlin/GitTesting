/************************************************/
/*                                              */
/*   PROGRAM : ca145m01s.ec by Julia Han        */
/*                                              */
/*   PURPOSE : �«O�O�[��T����                 */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
$include datetime.h;
#include <decimal.h>
$include sqlca;
#include "safeclib.h"


long car145(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car145_insert(),car145_single_query(),car145_multiple_query();
 long car145_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
           rtncode=car145_insert(reply);
           break;
  case 'Q':
           rtncode=car145_single_query(reply);
           break;
  case 'M':
           rtncode=car145_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car145_update_exec(reply,command,com_len);
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
             return M_CM_WRONG_OPTION;
           return apiRC;
 }

 return(rtncode);
}

long car145_insert(reply)
serverReply reply;
{
  $char DBName[5];
  $char provision[7],iins_cat[2],iins_type[7],strirate[10];
  $int  irate;
  $double  adjust_rate,loss_rate_bgn,loss_rate_end;
  $char iupdate[11];
  
  dec_t    dec_adjust_rate,dec_loss_rate_bgn,dec_loss_rate_end;
  char stradjust_rate[6],strlrate_bgn[9],strlrate_end[9];
  int tmp_len;
  DBinfo *list;
  int i, j, is_add_fail=0, api_f;
  $char stmt_buf[300];
  long MsgCode;

  cm_buf_get("%s %s %s %s %s %s %s %s %s",DBName, iins_cat, provision,  iins_type,
  		 strirate, stradjust_rate, strlrate_bgn, strlrate_end, iupdate);
  		
  irate = atoi(strirate);
  deccvasc( stradjust_rate, strlen(stradjust_rate), &dec_adjust_rate);
  dectodbl( &dec_adjust_rate, &adjust_rate);
  deccvasc( strlrate_bgn, strlen(strlrate_bgn), &dec_loss_rate_bgn);
  dectodbl( &dec_loss_rate_bgn, &loss_rate_bgn);
  deccvasc( strlrate_end, strlen(strlrate_end), &dec_loss_rate_end);
  dectodbl( &dec_loss_rate_end, &loss_rate_end);

  $WHENEVER SQLERROR GOTO errexit;
  
  if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
  }


  if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }

  $BEGIN WORK;
  
   sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO ca_adj_pure_rate "
         " (Iins_cat,provision,Iins_type,Irate,adjust_rate,Loss_rate_bgn,Loss_rate_end,Iupdate) "
	 " VALUES (?,?,?,?,?,?,?,?)");	 

   $PREPARE a_id FROM $stmt_buf;
   $EXECUTE a_id USING $iins_cat,$provision,$iins_type,$irate,$adjust_rate,
   					     $loss_rate_bgn,$loss_rate_end,$iupdate;
   
   if(SQLCODE != 0) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   api_f = api_OKComplete;

   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    {
     is_add_fail = 2;
    }  

  if( is_add_fail == 1 ) goto errexit;

  if( is_add_fail == 2 ) 
  {
   $ROLLBACK WORK;
   return apiRC;
  }


  $WHENEVER SQLERROR GOTO errexit;

  $COMMIT WORK;
  return api_OKComplete;

errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if (SQLCODE != 0) MsgCode = SQLCODE;		/* rollback fail */
   if(exitsub(reply,MsgCode) ==	True)
     return MsgCode;
   else
     return apiRC;
}

long car145_single_query(reply)
serverReply reply;
{
  $char DBName[5];
  $char provision[7],iins_cat[2],iins_type[7],strirate[10];
  $int  irate;
  $double  adjust_rate = 0.0,loss_rate_bgn = 0.0,loss_rate_end = 0.0;
  $char iupdate[11],dupdate[20];

  int tmp_len;
  char    strtmp_adjustrate[50],strtmp_lossbgn[50],strtmp_lossend[50];

  cm_buf_get("%s %s %s %s %s",DBName, iins_cat, provision, iins_type, strirate);
  		
  irate = atoi(strirate); 			

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
     if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
       return M_CM_DB_NOTOPEN;
     else
       return apiRC;
  }
  
  $SELECT adjust_rate, Loss_rate_bgn, Loss_rate_end, Iupdate, Dupdate
     INTO $adjust_rate, $loss_rate_bgn, $loss_rate_end, $iupdate, $dupdate
     FROM ca_adj_pure_rate
    WHERE Iins_cat = $iins_cat
      AND provision = $provision
      AND Iins_type = $iins_type
      AND Irate = $irate;
      

     
  if(SQLCODE==SQLNOTFOUND)
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)       
      return M_CM_NOT_FOUND;                        
    else
      return apiRC;
  }
  
  sprintf_s(strtmp_adjustrate, sizeof strtmp_adjustrate, "%.2f",adjust_rate);
  sprintf_s(strtmp_lossbgn, sizeof strtmp_lossbgn, "%.2f",loss_rate_bgn);
  sprintf_s(strtmp_lossend, sizeof strtmp_lossend, "%.2f",loss_rate_end);  
  
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s %s %d %s %s %s %s %s",M_CM_OK, iins_cat, provision, iins_type,
  		irate, strtmp_adjustrate, strtmp_lossbgn, strtmp_lossend, iupdate, dupdate);
  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car145_multiple_query(reply)
serverReply reply;
{
  $char DBName[5];
  $char provision[7],iins_cat[2],iins_type[7];
  $char tmp_provision[7],tmp_iins_cat[2],tmp_iins_type[7],tmp_irate[10];
  $int irate = 0,org_irate;
  $double adjust_rate = 0.0,loss_rate_bgn = 0.0,loss_rate_end = 0.0;
  $char stmt[1024],stmt_irate[512];

  char tmpbuf[4000];
  int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
  int i,total_count=0;
  char    strtmp_adjustrate[50],strtmp_lossbgn[50],strtmp_lossend[50];

  cm_buf_get("%s %s %s %s %s",DBName, tmp_iins_cat, tmp_provision, tmp_iins_type, tmp_irate);
  
  if (strcmp(trim(tmp_irate),"*") != 0) 
  {
  	   org_irate = atoi(tmp_irate);
  		sprintf_s(stmt_irate, sizeof stmt_irate, "AND Irate = %d",org_irate);
  	} else {
  		strcpy(stmt_irate,"");
  	}
  
  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  	sprintf_s(stmt, sizeof stmt,
  		"select Iins_cat, provision, Iins_type, Irate, adjust_rate, Loss_rate_bgn, Loss_rate_end "
        "  from ca_adj_pure_rate "
        " where Iins_cat matches ? and provision matches ? and Iins_type matches ? %s ",stmt_irate);
                 
printf("stmt[%s]\n",stmt);                 
                    
   $PREPARE CUR_CAID FROM $stmt;
   $DECLARE IDcur CURSOR FOR CUR_CAID;
   $OPEN IDcur USING $tmp_iins_cat,$tmp_provision,$tmp_iins_type;

   for(;;)
   {
     $FETCH IDcur INTO $iins_cat,$provision,$iins_type,$irate,$adjust_rate,$loss_rate_bgn,$loss_rate_end;
     
     sprintf_s(strtmp_adjustrate, sizeof strtmp_adjustrate, "%.2f",adjust_rate);
	  sprintf_s(strtmp_lossbgn, sizeof strtmp_lossbgn, "%.2f",loss_rate_bgn);
  	  sprintf_s(strtmp_lossend, sizeof strtmp_lossend, "%.2f",loss_rate_end);
  
     if (SQLCODE != 0) break;

     cm_buf_init(tmpbuf);
     if ( count == 0 )
     {
       cm_buf_res_msg();             /* reserve for MsgCode and count */
       cm_buf_res_count();
     }
  
     cm_buf_put("%s %s %s %d %s %s %s", iins_cat, provision, iins_type, irate, 
     				strtmp_adjustrate, strtmp_lossbgn, strtmp_lossend);
     tmp_len = cm_buf_len(tmpbuf);
     if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
       memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
       repbuf_len += tmp_len;
       count++;
     }
     else                               /* more than 4K, send to client side */
     {
       cm_buf_init(ReplyBuf);
       cm_buf_put_msg(M_CM_OK);
       cm_buf_put_count(count);
       if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
         $CLOSE IDcur;
         return apiRC;
       }
       else               /* clear ReplyBuf and count to start all over again */
       {
         replycnt++;
         if (replycnt == 10)   /* more than 30K, client cannot display,error */
         {
           cm_buf_init(ReplyBuf);
           cm_buf_put("%l",M_CM_OUT_SPACE);
           tmp_len = cm_buf_len(ReplyBuf);
           if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
               return apiRC;
           return M_CM_OUT_SPACE;
         }
         ReplyBuf[0] = '\0';
         count = 0;
         cm_buf_init(ReplyBuf);
         cm_buf_res_msg();           /* reserve for MsgCode and count */
         cm_buf_res_count();
         cm_buf_put("%s %s %s %d %s %s %s", iins_cat, provision, iins_type, irate, 
         	       strtmp_adjustrate, strtmp_lossbgn, strtmp_lossend);
         repbuf_len = cm_buf_len(ReplyBuf);
         count++;
       }
     }
  } /* for loop */

  $CLOSE IDcur;
  if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
  else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

errexit:
   if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
   else
     return apiRC;
}

long car145_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
  $char DBName[5];
  $char provision[7],iins_cat[2],iins_type[7];
  $char old_provision[7],old_iins_cat[2],old_iins_type[7];
  $int irate,old_irate;
  $char strirate[10],old_iupdate[11],old_dupdate[20];
  $char iupdate[11],dbdupdate[20],dupdate[20];
  $double  adjust_rate,loss_rate_bgn,loss_rate_end;
  
  char old_adjust_rate[6],old_loss_bgn[9],old_loss_end[9];
  char tmp_adjust_rate[6],tmp_loss_bgn[9],tmp_loss_end[9];
  dec_t  dec_adjust_rate,dec_loss_bgn,dec_loss_end;
  char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
  int tmp_len,raw_len;
  long dummy;
  long MsgCode;
  DBinfo *list;
   int i, j, is_upd_fail=0,is_del_fail=0;
  $char stmt_buf[300];

 		comm = (char *) command;
	cm_buf_init(command);
	cm_buf_get("%c %s",&option,DBName);

	$WHENEVER SQLERROR GOTO errexit;

 	if (db_select(DBName) == False)
    	{
    		if (exitsub(reply,M_CM_DB_NOTOPEN) == True) return M_CM_DB_NOTOPEN;
    		else	return apiRC;
    	}

 	if ( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
    	{
    		if (exitsub(reply,M_CM_NOT_DBLIST) == True)	return M_CM_NOT_DBLIST;
    		return apiRC;
    	}
	
	/* get old record info from command buffer */

	memcpy(&raw_len,&comm[com_len],sizeof(int));
	pos = &comm[com_len+sizeof(int)];
	raw_ptr = malloc(raw_len);

 	if (raw_ptr != (char*)0) {
    		memcpy(raw_ptr,pos,raw_len);
	}
 	else
    	{
    		if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
    			return M_CM_NOT_MALLOC;
    		else	return apiRC;
    	}
   
 	cm_buf_init(raw_ptr);          /* get index key from old record */
 	
	cm_buf_get("%l %s %s %s %s %s %s %s %s %s",&dummy, old_iins_cat, old_provision, old_iins_type, strirate, old_adjust_rate,
						old_loss_bgn, old_loss_end, old_iupdate, old_dupdate);
  							
   old_irate = atoi(strirate);
   free(raw_ptr); 							
 	$BEGIN WORK;
 	$WHENEVER SQLERROR GOTO errexit;
 	/* table lock is necessary to avoid concurrent update problems */
 	$LOCK TABLE ca_id_officer IN SHARE MODE;

 	$SELECT Dupdate
         INTO $dbdupdate
         FROM ca_adj_pure_rate
         WHERE Iins_cat = $old_iins_cat
           AND provision = $old_provision
           AND Iins_type = $old_iins_type
           AND Irate = $old_irate;
  
 	if (SQLCODE == SQLNOTFOUND)
        {
    		$WHENEVER SQLERROR CONTINUE;
    		$ROLLBACK WORK;
    		if (exitsub(reply,M_CM_NOT_FOUND) == True)
        		return M_CM_NOT_FOUND;
    		else
        		return apiRC;
    	}

 
printf("org. dentry=[%s],db. dentry[%s]\n",old_dupdate,dbdupdate);

 	if (strcmp(old_dupdate,dbdupdate) != 0)
        {
    		$WHENEVER SQLERROR CONTINUE;
    		$ROLLBACK WORK;
    		if(exitsub(reply,M_CM_NOT_EQUAL) == True)
        		return M_CM_NOT_EQUAL;
    		else
        		return apiRC;
    	}
    	
 	$WHENEVER SQLERROR GOTO errexit;

 	/* equal, then exec DB operation */

 	 if ( option == 'D' )
  	 {
   	for(j=0;j<i;j++)
   	{
    		sprintf_s(stmt_buf, sizeof stmt_buf, "DELETE FROM %s:ca_adj_pure_rate WHERE Iins_cat=? "
    								" AND provision = ? AND Iins_type=? AND Irate=?" ,list[j].dbname); 
    		$PREPARE d_id FROM $stmt_buf;
    		if(SQLCODE != 0)
     		{
      		is_del_fail = 1; 
      		break;
     		}
    		$EXECUTE d_id USING $old_iins_cat,$old_provision,$old_iins_type,$old_irate;  
    		if(SQLCODE != 0)
     		{
      		is_del_fail = 1; 
      		break;
     		}
   	 }/* for loop */

   	 if( is_del_fail ) goto errexit;
   
   	 cm_buf_init(ReplyBuf);
   	 cm_buf_put("%l",M_CM_OK);
   	 tmp_len = cm_buf_len(ReplyBuf);
   	 
   	 if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    	 {
     		$WHENEVER SQLERROR CONTINUE;
     		$ROLLBACK WORK;
     		return apiRC;
    	 }  
	
   	$WHENEVER SQLERROR GOTO errexit;
   	$COMMIT WORK;
   	return api_OKComplete;
  	}
 	else if (option == 'U')
   {
   	cm_buf_init(command);
   	cm_buf_get("%c %s",&option,DBName);
   	cm_buf_get("%s %s %s %s %s %s %s %s", iins_cat, provision, iins_type, strirate, tmp_adjust_rate,
   	            tmp_loss_bgn,tmp_loss_end, iupdate);
  							
  		 irate = atoi(strirate);
  		 deccvasc( tmp_adjust_rate, strlen(tmp_adjust_rate), &dec_adjust_rate);
       dectodbl( &dec_adjust_rate, &adjust_rate);
       deccvasc( tmp_loss_bgn, strlen(tmp_loss_bgn), &dec_loss_bgn);
       dectodbl( &dec_loss_bgn, &loss_rate_bgn);
       deccvasc( tmp_loss_end, strlen(tmp_loss_end), &dec_loss_end);
       dectodbl( &dec_loss_end, &loss_rate_end);
                             
   	$WHENEVER SQLERROR CONTINUE;
   	for(j=0;j<i;j++)
   	{
    		sprintf_s(stmt_buf, sizeof stmt_buf, "UPDATE %s:ca_adj_pure_rate SET "
		     		 " (Iins_cat,provision,Iins_type,Irate,adjust_rate,Loss_rate_bgn,Loss_rate_end,Iupdate,Dupdate) "
		     		 " = (?,?,?,?,?,?,?,?,current) "
		     		 " WHERE Iins_cat=? AND provision=? AND Iins_type=? AND Irate=?",list[j].dbname);

    		$PREPARE u_id FROM $stmt_buf;
    		
    		if(SQLCODE != 0)
     		{
      		is_upd_fail = 1;
      		break;
     		}
    		$EXECUTE u_id USING $iins_cat,$provision,$iins_type,$irate,$adjust_rate,$loss_rate_bgn,
    								  $loss_rate_end,$iupdate,$old_iins_cat,$old_provision,$old_iins_type,$old_irate;
    		if(SQLCODE != 0)
     		{
      		is_upd_fail = 1;
      		break;
     		}
    		if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     		{
  				sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO %s:ca_adj_pure_rate "
         			 " (Iins_cat,provision,Iins_type,Irate,adjust_rate,Loss_rate_bgn,Loss_rate_end,Iupdate) "
	 				 "  VALUES (?,?,?,?,?,?,?,?)",list[j].dbname);	 

      		$PREPARE ua_id FROM $stmt_buf;
      		if(SQLCODE != 0)
       		{
        			is_upd_fail = 1; 
        			break;
       		}
      		$EXECUTE ua_id USING $iins_cat,$provision,$iins_type,$irate,$adjust_rate,$loss_rate_bgn,
      								   $loss_rate_end,$iupdate;
      		if(SQLCODE != 0)
       		{
        			is_upd_fail = 1; 
        			break;
       		}
     		}
   	} /* for loop */

   	if( is_upd_fail ) goto errexit;


   	cm_buf_init(ReplyBuf);
   	cm_buf_put("%l",M_CM_OK);
   	tmp_len = cm_buf_len(ReplyBuf);
   	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    	{
     		$WHENEVER SQLERROR CONTINUE;
     		$ROLLBACK WORK;
     		return apiRC;
    	}  

   	$WHENEVER SQLERROR GOTO errexit;
   	$COMMIT WORK;
   	return api_OKComplete;
  } else {
   	if(exitsub(reply,M_CM_WRONG_OPTION) == True) 
    		return M_CM_WRONG_OPTION;
   	else  
    		return apiRC;
  } 

 errexit:
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else
    return apiRC;
}

