/**********************************************************************/
/*   program id   : ca636q01s.ec                                      */
/*   program name : ���I����/���l�O����Ӫ�                           */
/*   date written : 2015/05/21                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : Larry Liao                                        */                                       
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "safeclib.h"

/****************************************************************************/
$char DBName[05],userid[11];
$char dgroup_bgn[11], dgroup_end[11];
$char sDgroup_bgn[11], sDgroup_end[11];
char  msgbuf[2048], sApHome[30];
char  v_sMsg[1024], outputf[N_FILE+1];
int   count_db,i;
DBinfo  *list;
$char stmt_tmp[2048];
/****************************************************************************/
main(argc, argv)
int argc;
char **argv;
{  
	int rc;

	batchinit();
	strcpy(DBName, 		   isNULLstr(argv[1]));
	strcpy(userid, 		   isNULLstr(argv[2]));               
	strcpy(dgroup_bgn,   isNULLstr(argv[3]));
	strcpy(dgroup_end,   isNULLstr(argv[4]));
	strcpy(outputf,      isNULLstr(argv[5]));
	
	printf("-----���פ��:[%s] ~ [%s]-----\n", dgroup_bgn, dgroup_end);
		
	rc = car636_get_db();
	if (rc != M_CM_OK) {
		EWRITE(userid,rc,msgbuf);
		return rc;
	}
 
  rc = car636_init_data();
  if (rc != M_CM_OK) {
    printf("Error on car636_init_data\n");
		EWRITE(userid,rc,"�إ� temp table ���~!");
		return rc;
  }
				
	rc = car636_query_detail();
  if (rc != M_CM_OK) {
    printf("Error on car636_query_detail\n");
		EWRITE(userid, rc, "�d�ߧ����Ӹ�Ʀ��~");
		return rc;
	}
	  
  rc = car636_print_detail();
  if (rc != M_CM_OK) {
     printf("Error on car636_print_detail\n");
     EWRITE(userid, rc, "���s�������Ӧ��~!");
     return rc;
  }    
			
  return rc;
}
/******************************************************************************/
long car636_init_data()
{   
    $WHENEVER SQLERROR GOTO errexit;
   
    	/*  	  nchi_abv        char(12),      /*�Ұ�*
	  	  nbranch         char(40),      /*���W��*
	  	  ipolicy         char(20),      /*�O�渹�X*
	  	  nassured        varchar(120),  /*�Q�O�I�H*
	  	  itag            char(8),       /*�P�Ӹ��X*
	  	  dpolicy         date,          /*ñ����*
	  	  dply_begin      date,          /*�ͮİ_��*
        dply_end        date,          /*�ͮĨ���*
        iofficer        char(10),      /*�g��N��*
        nofficer        char(10),      /*�g��W��*
        ileader         char(10),      /*�޲z�H�N��*
        nleader         char(10),      /*�޲z�H*
        fpart           char(10),      /*���l�W��*
        acc_reason      varchar(120),  /*�X�I��]*
        dgroup          date,          /*���פ��*
        iins_type       char(6),       /*�I�إN��*
        ori_mdamage_cover   integer,   /*��l-�O�I���B*
        ply_mdamage_cover   integer,   /*�̷s-�O�I���B*
        mins_stl        integer        /*�߰l���B*/
         	  	   
     /* �s�W���v�O(fcompensation) add by sylvia 107.01.22 (1061114005_C1) */
	  sprintf_s(stmt_tmp,2048,"create temp table car636_tmp(\
	  	  nchi_abv        char(12),    \
	  	  nbranch         char(40),    \
	  	  ipolicy         char(20),    \
	  	  nassured        varchar(120),\
	  	  itag            char(%d),    \
	  	  dpolicy         date,      \
	  	  dply_begin      date,      \
        dply_end        date,         \
        iofficer        char(10),     \
        nofficer        char(10),     \
        ileader         char(10),    \
        nleader         char(10),  \
        fpart           char(10),    \
        acc_reason      varchar(120), \
        dgroup          date,         \
        iins_type       char(6),      \
        ori_mdamage_cover   integer,  \
        ply_mdamage_cover   integer,  \
        mins_stl        integer,      \
        fcompensation   varchar(50), \
        iclaim          char(20),    \
        niadjuster     varchar(50)  \
	  )with no log;",CA_TAG_NUM-1);
     $PREPARE stmp FROM $stmt_tmp;
     $EXECUTE stmp;

	  
	  return M_CM_OK;

errexit:
    printf("--car636_init_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car636_query_detail()
{
   int	rc;
   $char sStmt[4096];
   
   $WHENEVER SQLERROR GOTO errexit;
   
   strcpy(sDgroup_bgn, cm_to_infdate(dgroup_bgn));
   strcpy(sDgroup_end, cm_to_infdate(dgroup_end));

   for(i=0;i<count_db;i++) 
   {
   	 /* ���l�G1.����2.�N��3.���� */
   	 /* �s�W���v�O(fcompensation) add by sylvia 107.01.22 (1061114005_C1) */
     sprintf_s(sStmt,4096,"INSERT INTO car636_tmp \
                    SELECT (SELECT nchi_abv FROM branch \
                             WHERE ibranch = d.ibranch) nchi_abv, \
                           (SELECT nbranch FROM sa_branch_type \
                             WHERE ibranch = d.iquota) nbranch, \
                           a.ipolicy, c.nassured, c.itag, d.dpolicy, \
                           d.dply_begin, d.dply_end, d.iofficer, \
                           (SELECT nname FROM officer \
                             WHERE iofficer = d.iofficer) nofficer, \
                           d.ileader, (SELECT nname FROM officer \
                                        WHERE iofficer = d.ileader) nleader, \
                           decode(a.fpart,'1','����','2','�N��','3','����') fpart,\
                           (a.iacc_reason || (SELECT ncode FROM adjustment_code WHERE fclass = '1' AND icode = a.iacc_reason)) acc_reason ,     \
                           b.dgroup, b.iins_type, \
                           (SELECT mdamage_cover FROM %s:ori_ins_type WHERE ipolicy = d.ipolicy AND iins_type = b.iins_type) ori_mdamage_cover ,\
                           (SELECT mdamage_cover FROM %s:ply_ins_type WHERE ipolicy = d.ipolicy AND iins_type = b.iins_type) ply_mdamage_cover ,\
                           CASE WHEN b.fstl = 2 THEN b.mins_stl*(-1) \
                                ELSE b.mins_stl END mins_stl, \
                           decode(a.fcompensation,'0','0:���l�αj���I','1','1:�{�����v','2','2:�״_���v',' ') fcompensation, \
                           a.iclaim, (select nname from officer where iofficer = a.iadjuster) nadjustment \
                      FROM %s:appraisal a, %s:stl_ins_type b, %s:policy c, \
                           %s:ply_relation d \
                     WHERE a.iclaim = b.iclaim \
                       AND a.ipolicy = c.ipolicy \
                       AND c.ipolicy = d.ipolicy \
                       AND a.fpart IN ('1','2','3') \
                       AND b.dgroup >= ? \
                       AND b.dgroup <= ?;", list[i].dbname, list[i].dbname,
                                            list[i].dbname, list[i].dbname,
                                            list[i].dbname, list[i].dbname);

      printf("sStmt[%s]\n",sStmt);             
      $PREPARE pre_ply from $sStmt;
      $EXECUTE pre_ply using $sDgroup_bgn, $sDgroup_end;
   }
    
    return M_CM_OK;
  
errexit:
    printf("--car636_query_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car636_print_detail()
{
    int     rc;
    char    sfilename[128],stitle[2048],stmt[2048];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"���I����/���l�O����Ӫ�");
    strcpy(stitle,"�{���N��:CAR636\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
/* �s�W���v�O(fcompensation) add by sylvia 107.01.22 (1061114005_C1) */
    strcat(stitle,"\t�Ұ�\t���W��\t�O�渹�X\t�Q�O�I�H\t���P���X\t");
    strcat(stitle,"ñ����\t�O��ͮĤ�\t�O������\t");
    strcat(stitle,"�g��N��\t�g��W��\t�޲z�H�N��\t�޲z�H�W��\t���l���A\t���v�O\t");
    strcat(stitle,"�X�I��]\t�J�p���\t�I�إN��\t��l-�O�I���B\t�̷s-�O�I���B\t�ߥI/�l�v���B\t");
    strcat(stitle,"�߮׸��X\t�߮׸g��W��\t");

    strcpy(stmt,"SELECT nchi_abv,nbranch,ipolicy,nassured,itag,dpolicy,"
                "       dply_begin,dply_end,iofficer,nofficer,ileader, "
	  	"       nleader,fpart,fcompensation,acc_reason,dgroup,iins_type,     "
	  	"       ori_mdamage_cover,ply_mdamage_cover,mins_stl,iclaim, niadjuster   "
                "   FROM car636_tmp ");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf,2048," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
    
errexit:
    printf("--car636_print_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car636_get_db()
{
	int return_code;
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False) {
		strcpy(msgbuf,"��Ʈw�L�k�}��");
		return M_CM_DB_NOTOPEN;
	}
	
	return_code = getApHome(sApHome);
	if (return_code < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return return_code;
  }
  
  if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
  }
  
  return M_CM_OK;

errexit:
   printf("--car636_get_db-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/