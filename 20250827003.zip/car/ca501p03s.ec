/**********************************************************************/
/*   program id   : ca501p03s.ec                                      */
/*   program name : �i�妸�j- �z�����h���Ʋ��s�@�~                  */
/*   date written : 2015/08/04                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : Larry Liao                                        */
/*   shell        : claimCare_out                                     */
/*   exec time    :(�C����T�I)                                     */
/* �p�G�ϥΪ̧ѰO�U�����P���ɮסA�Цܧַ����Ҷ]���L�C�������Ҧp�G�w�g */
/* ���\����L���i�ɶ]�A�|�ɭP�ɱH�\�ಧ�`                             */
/**********************************************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"
#include "safeclib.h"

char  	outputf[ N_FILE+1];
$char  	userid[11], sDdate[11];
char    cdate[11];
char	syy[4],smm[3],sdd[3],sdate[11];
$char   fileName[64], filePath[128];
$char   fileName1[64];
int     count_file,count_file1;
$char   remark[1024];

FILE    *fp;
$char	DBName[5];
char    sApHome[30], msgbuf[100];
$char	sErrMsg[1024];
$long	dsys;

DBinfo  *list;
int     count_db = 0 , k;
$char   fulldb[31];


/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;

    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(cdate,   isNULLstr(argv[3])); /* cyy/mm/dd */
    strcpy(outputf, isNULLstr(argv[4]));

    strcpy(sDdate,cm_to_infdate(cdate));
    printf("***** ���(�w�]�t�Τ�): [%s]*****\n",sDdate);    
    
    rc = car_get_db();
    if (rc != M_CM_OK) {
        printf("error on car_get_db\n");
        return rc;
    }

    /* �d�߲z�����h��� */
    rc = Query_claimCare();
    if ( rc != M_CM_OK ) {
    	  printf("error on Query_claimCare\n");
    	  EWRITE(userid, rc, sErrMsg);
        return rc;
    }

    /* ���l�q������ */
    rc = Query_dmgCare();
    if ( rc != M_CM_OK ) {
    	  printf("error on Query_dmgCare\n");
    	  EWRITE(userid, rc, sErrMsg);
        return rc;
    }

    /* ���]�����Y�ɮ� */
    rc = tar_file();
    if ( rc != M_CM_OK ) {
    	  printf("error tar_file\n");
    	  EWRITE(userid, rc, "���]�����Y�ɮצ��~!");
        return rc;
    }
    
}
/*----------------------------------------------------------------------------*/
long Query_claimCare()
{
    $char sNzip[CA_ZIP], sIpolicy[21], sIclaim[21], sDclaim[11], sNadjust[11];
    $char sDtoday[11], sCarDbName[21],sTmpSQL[500];
    $varchar sNassured[121], sNaddress[101], sItag[9], sIadjtel[103];
    $int  rc;
    $char stmt[4096];
    char  cmd_stmt[40000];
    $char sIverify[21], sRePrint[10];

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    sErrMsg[0] = '\0';

    printf("cdate = [%s]\n", cdate);
    dsys = cm_ymd_cdate(cdate);
    cm_char_split_3ymd(cdate, syy, smm, sdd);
    sprintf_s(sdate, 128, "%s%s%s", syy, smm, sdd);
    printf("sdate = [%s]\n", sdate);

    strcpy(fileName, " ");
    strcpy(filePath, " ");
    sprintf_s(fileName, 256, "%s_outclaim.txt", sdate);
    sprintf_s(filePath, 256, "%s/rptftp/%s", sApHome, fileName);
    printf("--- fileName�G[%s] ---\n", fileName);
    count_file = 0;

    fp = fopen(filePath, "w");

    /* �q��x���X���P�n�ɱH���h�窺�d�Ҹ��B�׸��B��H���� */
    sprintf_s(stmt, 4096,
        " SELECT unique iverify,                                   \
                 replace(itype,'5-1R-','') AS iclaim,              \
                 (select min(drecord) from ca_clm_journal where itype like '5-1-%%' and iverify = a.iverify  \
                        and replace(itype,'5-1-','') = replace(a.itype,'5-1R-','') ) AS drecord  \
           from ca_clm_journal a                                   \
          where drecord between Date('%s')-7 and Date('%s')-1      \
            and itype like '5-1R%%'                                \
           INTO temp tmp_reprint_claimCare ", sDdate, sDdate);

    printf("stmt[%s]\n", stmt);

    $prepare get_reprint_claimCare from $stmt;
    $execute get_reprint_claimCare;


    /* �d�߱���G��W�ӫO�����I(�ư���ˡB�]�l���ѵs)�Φ۵M�H */
    /* �ɱH���h��G��tmp_reprint_claimCare���߮׸��[�i�h*/
    sprintf_s(stmt, 4096, "SELECT UNIQUE a.nassured, b.nzip, b.naddress, a.ipolicy, \
                         a.iclaim, a.itag, a.dclaim, \
                         (SELECT nname FROM officer \
                           WHERE iofficer = (case when e.dexpire <= today then  \
                                              (select administrator from personal:asempl where empl_no = a.adjustment)  \
                                             else   a.adjustment \
                                              end )) AS nadjust, \
                         (SELECT rtrim(branch_tel) \
                            FROM cm_emp_ext \
                           WHERE empl_no = (case when e.dexpire <= today then  \
                                             (select administrator from personal:asempl where empl_no = a.adjustment)  \
                                            else   a.adjustment \
                                             end )) AS iadjtel, \
                         today AS dtoday \
	                  FROM ca_clm_process a, policy_new b, \
                         (SELECT iclaim1, insure_type, insure_instype, min(dappraisal) AS dappraisal \
                            FROM claim_app_dtl_h_2 \
                           WHERE insure_type = 'C' \
                             AND (                 \
                                    iclaim1 IN (SELECT iclaim1 \
                                               FROM claim_app_dtl_h_2 \
                                              WHERE dappraisal BETWEEN Date('%s')-7 AND Date('%s')-1) \
                                 OR iclaim1 IN (SELECT iclaim FROM tmp_reprint_claimCare) \
                                 ) \
                        GROUP BY iclaim1, insure_type, insure_instype \
                        ) AS c, cu_customer d, officer e  \
	                 WHERE a.ipolicy[1,13]  = b.ipolicy1 \
	                   AND a.ipolicy[14,20] = b.ipolicy2 \
                           AND a.adjustment     = e.iofficer \
	                   AND a.iclaim         = c.iclaim1 \
	                   AND c.insure_type    = 'C' \
	                   AND c.insure_instype IN (SELECT icode FROM cu_code_data WHERE itype = 'DA') \
	                   AND a.iassured       = d.ifpce_id  \
	                   AND d.fassured       IN ('1','3','5') \
	                   AND d.ifpce_id[1,1] BETWEEN 'A' AND 'Z' \
	                   AND length(trim(d.ifpce_id)) = 10 \
	                   AND (c.dappraisal     BETWEEN Date('%s')-7 AND Date('%s')-1 \
                        OR c.iclaim1 IN (SELECT iclaim FROM tmp_reprint_claimCare)) \
	                   AND 1 = (SELECT max(CASE WHEN \
	                                   (SELECT count(*) \
	                                      FROM insurance_type \
	                                     WHERE iins_type = x.insure_instype \
	                                       AND fins_grp = '2' \
	                                       AND fkind <> '3') > 0 THEN 4 \
	                                   WHEN \
	                                   (SELECT count(*) \
	                                      FROM insurance_type \
	                                     WHERE iins_type = x.insure_instype \
	                                       AND fkind     = '3') > 0 THEN 3 \
	                                   WHEN \
	                                   (SELECT count(*) \
	                                      FROM insurance_type \
	                                     WHERE iins_type = x.insure_instype \
	                                       AND fkind     = '2') > 0 THEN 2 \
	                                   ELSE 1 END) AS maxadj \
	                              FROM claim_app_dtl_2 x \
	                             WHERE x.iclaim1 = a.iclaim \
	                               AND x.insure_type = 'C') ", sDdate, sDdate,
	                                                           sDdate, sDdate);

    printf("stmt[%s]\n", stmt);
    $PREPARE out_claim FROM $stmt;
    $DECLARE CLAIM_CUR CURSOR FOR out_claim;
    $OPEN    CLAIM_CUR;

    for (;;)
    {
        $FETCH CLAIM_CUR INTO $sNassured, $sNzip, $sNaddress, $sIpolicy,
                              $sIclaim, $sItag, $sDclaim, $sNadjust, $sIadjtel,
                              $sDtoday;

        if (SQLCODE == SQLNOTFOUND) break;

        $select unique '(�ɱH)'
            into $sRePrint
            from tmp_reprint_claimCare
            where iclaim = $sIclaim;
        if (SQLCODE == SQLNOTFOUND) strcpy(sRePrint, "");

        printf("sRePrint = [%s], \n", sRePrint);

        /* ------------------------------------------------------------------ */
        /* �t�X�ݨD,�N�a�}�ζl���ϸ������z�߮׮ɯd�U����ơC
                      add by sylvia 108.06.26 (1080618014_SC1)  */
        printf("1. sNzip = [%s], sNaddress=[%s] \n", sNzip, sNaddress);
        strcpy(sCarDbName, get_car_full_db(sIpolicy));
        sprintf_s(sTmpSQL, 256, "select aassured_zip, aassured || '%s' \
	                         from %s:adjustment_ply \
	                        where iclaim = '%s' \
	                          and aassured_zip <> ' ' and aassured <> ' ' ",
            sRePrint, sCarDbName, sIclaim);

        $PREPARE chg_aasured FROM $sTmpSQL;
        $DECLARE chg_aasured_CUR CURSOR FOR chg_aasured;
        $OPEN    chg_aasured_CUR;
        $FETCH   chg_aasured_CUR INTO $sNzip, $sNaddress;
        $CLOSE chg_aasured_CUR;
        $FREE  chg_aasured_CUR;
        printf("2. sNzip = [%s], sNaddress=[%s] \n", sNzip, sNaddress);
        /* ------------------------------------------------------------------ */

  /*    fprintf(fp,"%s\t%s\t%s\t%s\t",sNassured, sNzip, sNaddress, sIpolicy);      */
        fprintf(fp, "%s\t%s\t%s\t%s\t", sNassured, sNzip, sNaddress, " ");
        fprintf(fp, "%s\t%s\t%s\t%s\t", sIclaim, sItag, sDclaim, sNadjust);
        fprintf(fp, "%s\t%s\n", sIadjtel, sDtoday);

        sprintf_s(remark, sizeof(remark), "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s",
            sNassured, sNzip, sNaddress, " ", sIclaim, sItag, sDclaim, sNadjust, sIadjtel, sDtoday);
        printf("remark[%s]\n", remark);

        $select unique iverify
            into $sIverify
            from ca_ver_relation
            where iclaim = $sIclaim;
        if (SQLCODE == SQLNOTFOUND) strcpy(sIverify, sIclaim);

        printf(" sIverify=[%s] \n", sIverify);

        $WHENEVER SQLERROR CONTINUE;

        /* �߮פ�x */
        $INSERT INTO ca_clm_journal
        (iverify, iserial,
            drecord, nplace, njournal, nremark, ientry, dentry, dcreate, inumber, iemail,
            itype)
            VALUES
            ($sIverify, (SELECT nvl(max(iserial), 0) + 1 FROM ca_clm_journal WHERE iverify = $sIverify),
                CAST(CURRENT AS DATETIME YEAR TO MINUTE), '�H��', '���h��', $remark, 'car5013', CURRENT, CURRENT, '', '',
                CASE
                WHEN(select count(*) FROM tmp_reprint_claimCare where iclaim = $sIclaim) > 0
                THEN '' ELSE '5-1-' || $sIclaim
                END);

        if (SQLCODE < 0) {
            if (sErrMsg[0] != '\0') {
                strcat(sErrMsg, ",");
            }
            strcat(sErrMsg, trim(sIclaim));
        }

        $WHENEVER SQLERROR GOTO errexit;

        count_file++;
    }
    $CLOSE CLAIM_CUR;
    $FREE  CLAIM_CUR;
    fclose(fp);

    if (sErrMsg[0] != '\0')
    {
        /*allen.wang@tmnewa.com.tw*/
        printf("[%s]\n", sErrMsg);
        sprintf_s(cmd_stmt, 256,
            "echo \"error iclaim %s\" | mailx -r ipisnew@tmnewa.com.tw -s \"[car5013] claimCare Insert ca_clm_journal error\" winnie.wang@tmnewa.com.tw ",
            sErrMsg);
        printf("[%s]\n", cmd_stmt);
        rc = system(cmd_stmt);
    }

    printf("count_file = [%d]", count_file);

    rc = rptftpinsert(userid, "car5013", fileName);
    if (rc != 0) {
        sprintf_s(sErrMsg, 256, "%s�g�Jrptftplist���~", fileName);
        return rc;
    }

    return M_CM_OK;

errexit:
    fclose(fp);
    printf("-- Query_claimCare -- SQLCODE=[%ld], sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}
/* -------------------------------------------------------------------------- */
long Query_dmgCare()
{
    $char sNzip[CA_ZIP], sIpolicy[21], sIclaim[21], sDclaim[11], sNadjust[11], sDgroup[11];
    $char sDtoday[11], sCarDbName[21], sTmpSQL[500];
    $varchar sNassured[121], sNaddress[101], sItag[9], sIadjtel[103], siins_type[50];
    $int  rc;
    $char stmt[4096];
    char  cmd_stmt[40000];
    $long msettle = 0;
    $char sIassured[13], sAdjustment[11], sDaccident[20], sDcontact[20],
        sDverify[20], sDsurvey[20], sFdmg_duty[2], sFedm[2], sEmail[51],
        sIroute[21], sDpre_mail[11], sFpart[2], sIacc_reason[4];
    $char sIverify[21], sRePrint[10];

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    if ((list = get_db_list(&count_db, DBName)) == (char*)0)
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;
    }

    sErrMsg[0] = '\0';

    printf("cdate = [%s]\n", cdate);
    dsys = cm_ymd_cdate(cdate);
    cm_char_split_3ymd(cdate, syy, smm, sdd);
    sprintf_s(sdate, 128, "%s%s%s", syy, smm, sdd);
    printf(" sdate = [%s]\n", sdate);

    strcpy(fileName1, " ");
    strcpy(filePath, " ");
    sprintf_s(fileName1, 256, "%s_outdmg.txt", sdate);
    sprintf_s(filePath, 256, "%s/rptftp/%s", sApHome, fileName1);
    printf("--- fileName1�G[%s] ---\n", fileName1);
    count_file1 = 0;

    $begin work;

    fp = fopen(filePath, "w");

    /* �q��x���X���P�n�ɱH�v�q�q�����d�Ҹ��B�׸��B��H���� */
    sprintf_s(stmt, 4096,
        " SELECT unique iverify,                                   \
                 replace(itype,'5-2R-','') AS iclaim,              \
                 (select min(drecord) from ca_clm_journal where itype like '5-2-%%' and iverify = a.iverify  \
                        and replace(itype,'5-2-','') = replace(a.itype,'5-2R-','') ) AS drecord  \
           from ca_clm_journal a                                   \
          where drecord between Date('%s')-7 and Date('%s')-1      \
            and itype like '5-2R%%'                                \
           INTO temp tmp_reprint_dmgCare ", sDdate, sDdate);

    printf("stmt[%s]\n", stmt);

    $prepare get_reprint_dmgCare from $stmt;
    $execute get_reprint_dmgCare;

    $create temp table clmtmp
    (
        iclaim         char(20),
        iclose_type    int
    )with no log;

    $create unique index axi1_clmtmp on clmtmp(iclaim);

    /* �ɱH�� */
    $create temp table clmtmp2
    (
        iclaim         char(20),
        iclose_type    int
    )with no log;

    $create unique index axi1_clmtmp2 on clmtmp2(iclaim);

    for (k = 0; k < count_db; k++)
    {
        strcpy(fulldb, list[k].dbname);

        /* ���������I�ت��]�w,��Ūcu_code_data.itype = 'H2'  modify by sylvia 108.08.26 (1080808001_SC1) */
        /* �ĤG�q�ɤJ�ɱH��� */
        sprintf_s(stmt, 8192,
            " insert into clmtmp                                        \
         select a.iclaim, max(a.iclose_type) as iclose_type        \
           from %s:stl_ins_type a                                  \
          where a.dgroup between Date('%s')-7 and Date('%s')-1     \
            and a.fstl = '1'                                       \
            and a.iins_type in (select d.iins_type from cu_code_data c, insurance_type d \
                                 where d.iins_type_tradevan = c.icode \
                                   and c.itype = 'H2' and d.iins_type not in ('86','110')) \
            and a.flast = '1'                                      \
            and a.iclaim not in (select iclaim from sysdb:ca_edm ) \
            and a.iclaim not in (select b.iclaim                        \
                                   from %s:stl_ins_type b               \
                                  where a.iclaim   =  b.iclaim          \
                                    and b.fstl     =  '1'               \
                                    and b.iins_type in \
                                        (select f.iins_type from cu_code_data e, insurance_type f \
                                          where f.iins_type_tradevan = e.icode \
                                            and e.itype = 'H2' and f.iins_type not in ('86','110')) \
                                    and b.iclose_type < a.iclose_type   \
                                    and b.flast    =  '1'               \
                                    and b.mins_stl >   0                \
                                    and b.dgroup != a.dgroup ) group by 1; \
                                                                             \
                                                                             \
         insert into clmtmp2                                       \
         select a.iclaim, max(a.iclose_type) as iclose_type        \
           from %s:stl_ins_type a join tmp_reprint_dmgCare b on a.iclaim = b.iclaim  \
          where a.dgroup between Date(b.drecord)-7 and Date(b.drecord)-1     \
            and a.fstl = '1'                                       \
            and a.iins_type in (select d.iins_type from cu_code_data c, insurance_type d \
                                 where d.iins_type_tradevan = c.icode \
                                   and c.itype = 'H2' and d.iins_type not in ('86','110')) \
            and a.flast = '1'                                      \
            and a.iclaim not in (select b.iclaim                        \
                                   from %s:stl_ins_type b               \
                                  where a.iclaim   =  b.iclaim          \
                                    and b.fstl     =  '1'               \
                                    and b.iins_type in \
                                        (select f.iins_type from cu_code_data e, insurance_type f \
                                          where f.iins_type_tradevan = e.icode \
                                            and e.itype = 'H2' and f.iins_type not in ('86','110')) \
                                    and b.iclose_type < a.iclose_type   \
                                    and b.flast    =  '1'               \
                                    and b.mins_stl >   0                \
                                    and b.dgroup != a.dgroup ) group by 1; ",
            fulldb, sDdate, sDdate, fulldb, fulldb, fulldb);

        printf("stmt[%s]\n", stmt);

        $prepare geticlaim from $stmt;
        $execute geticlaim;
    }

    $create temp table dmgdatatmp
    (
        nassured        VARCHAR(120),
        nzip            CHAR(6),
        naddress        VARCHAR(100),
        ipolicy         CHAR(20),
        iclaim          CHAR(20),
        itag            VARCHAR(12),
        dclaim          DATE,
        dgroup          DATE,
        nname           VARCHAR(10),
        branch_tel      VARCHAR(30),
        Dtoday          DATE,
        msettle         DECIMAL(32, 0),
        iassured        VARCHAR(12),
        adjustment      CHAR(10),
        daccident       DATETIME YEAR TO MINUTE,
        fdem            CHAR(1),
        ichannel        VARCHAR(20),
        iins_type_c     LVARCHAR(40),
        dpre_mail       DATE
    )with no log;

    sprintf_s(stmt, 8192,
        "  insert into dmgdatatmp \
        SELECT unique a.nassured, b.nzip, b.naddress, a.ipolicy, a.iclaim, \
              a.itag, a.dclaim, c.dgroup,    \
              nvl((SELECT rtrim(nname) FROM officer WHERE iofficer = a.adjustment and (dexpire is null or dexpire > today)),' ') AS nname,   \
              (SELECT rtrim(branch_tel) || ' #' ||rtrim(ext_tel) FROM cm_emp_ext WHERE empl_no = a.adjustment) AS branch_tel, \
              today AS Dtoday, (select sum(x.msettle - x.mfee)           \
                        from claim_stl_dtl_2 x                   \
                       where c.iclaim1      = x.iclaim1        \
                         and x.insure_instype in \
                  		   (select d.iins_type from cu_code_data c, insurance_type d \
                           where d.iins_type_tradevan = c.icode \
                             and c.itype = 'H2' and d.iins_type not in ('86','110')) \
                             and x.fstl         = '1'              \
                             and x.iclose_type <= d.iclose_type ) AS msettle, \
              a.iassured, a.adjustment, a.daccident,   \
              CASE WHEN b.ichannel[1,2] = 'JB' THEN \
                   case when (SELECT max(CASE WHEN (SELECT count(*) \
                                                    FROM insurance_type \
                                                   WHERE iins_type = x.insure_instype \
                                                     AND fins_grp = '2' \
                                                     AND fkind <> '3') > 0 THEN 4 \
                                            WHEN (SELECT count(*) \
                                                    FROM insurance_type \
                                                   WHERE iins_type = x.insure_instype \
                                                     AND fkind     = '3') > 0 THEN 3 \
                                            WHEN (SELECT count(*) \
                                                    FROM insurance_type \
                                                   WHERE iins_type = x.insure_instype \
                                                     AND fkind     = '2') > 0 THEN 2 \
                                            ELSE 1 END) \
                               FROM claim_app_dtl_2 x  WHERE x.iclaim1 = a.iclaim \
                                AND x.insure_type = 'C') = 1 then 'Y' else 'N' END \
                   ELSE 'N' END as fdem, b.ichannel, \
               (select replace(replace(replace(replace(replace( multiset (select UNIQUE trim(insure_instype) \
                               from claim_app_dtl where iclaim1 = a.iclaim AND fstl = '1' )::lvarchar, \
                               'MULTISET{',''), 'ROW(''',''),''')',''),'}',''),',','|') \
                  from ca_clm_process WHERE iclaim = a.iclaim) as iins_type_c , \
                  today+7 as dpre_mail \
         FROM ca_clm_process a, policy_new b, claim_stl_dtl_2 c, clmtmp d   \
        WHERE a.ipolicy[1,13]  = b.ipolicy1   \
          AND a.ipolicy[14,20] = b.ipolicy2   \
          AND c.dgroup         between Date('%s')-7 and Date('%s')-1   \
          AND a.iclaim         = c.iclaim1    \
          AND c.insure_instype IN \
          				(select f.iins_type from cu_code_data e, insurance_type f \
                    where f.iins_type_tradevan = e.icode \
                      and e.itype = 'H2' and f.iins_type not in ('86','110')) \
          AND c.fstl = '1'                    \
          AND c.iclaim1 = d.iclaim            \
          AND c.iclose_type = d.iclose_type ", sDdate, sDdate);

    printf("stmt[%s]\n", stmt);

    $prepare dmgdatatmp1 from $stmt;
    $execute dmgdatatmp1;

    /*�ɱH����*/
    sprintf_s(stmt, 8192,
        "  insert into dmgdatatmp \
        SELECT unique a.nassured, b.nzip, b.naddress , a.ipolicy, a.iclaim, \
        a.itag, a.dclaim, c.dgroup, \
        nvl((SELECT rtrim(nname) FROM officer WHERE iofficer = a.adjustment and (dexpire is null or dexpire > today)), ' ') AS nname, \
        (SELECT rtrim(branch_tel) || ' #' || rtrim(ext_tel) FROM cm_emp_ext WHERE empl_no = a.adjustment) AS branch_tel, \
        today AS Dtoday, (select sum(x.msettle - x.mfee)           \
                  from claim_stl_dtl_2 x                   \
                 where c.iclaim1 = x.iclaim1        \
                   and x.insure_instype in          \
                     (select d.iins_type from cu_code_data c, insurance_type d \
                       where d.iins_type_tradevan = c.icode \
                         and c.itype = 'H2' and d.iins_type not in('86', '110')) \
                         and x.fstl = '1'              \
                         and x.iclose_type <= d.iclose_type) AS msettle, \
        a.iassured, a.adjustment, a.daccident, 'X' as fdem, b.ichannel, '' as iins_type_c , today+7 as dpre_mail \
        FROM ca_clm_process a, policy_new b, claim_stl_dtl_2 c, clmtmp2 d,tmp_reprint_dmgCare e   \
        WHERE a.ipolicy[1, 13] = b.ipolicy1   \
        AND a.ipolicy[14, 20] = b.ipolicy2   \
        AND a.iclaim = e.iclaim \
        AND c.dgroup     between Date(e.drecord) - 7 and Date(e.drecord) - 1   \
        AND a.iclaim = c.iclaim1    \
        AND c.insure_instype IN \
        (select f.iins_type from cu_code_data e, insurance_type f \
            where f.iins_type_tradevan = e.icode \
            and e.itype = 'H2' and f.iins_type not in('86', '110')) \
        AND c.fstl = '1'                    \
        AND c.iclaim1 = d.iclaim            \
        AND c.iclose_type = d.iclose_type ");

    printf("stmt[%s]\n", stmt);

    $prepare dmgdatatmp2 from $stmt;
    $execute dmgdatatmp2;

    sprintf_s(stmt, 512, " SELECT * from dmgdatatmp ");

    printf("stmt[%s]\n", stmt);


    $PREPARE out_dmg FROM $stmt;
    $DECLARE DMG_CUR CURSOR FOR out_dmg;
    $OPEN    DMG_CUR;

    for (;;)
    {
        $FETCH DMG_CUR INTO $sNassured, $sNzip, $sNaddress, $sIpolicy, $sIclaim,
            $sItag, $sDclaim, $sDgroup, $sNadjust, $sIadjtel,
            $sDtoday, $msettle, $sIassured, $sAdjustment, $sDaccident,
            $sFedm, $sIroute, $siins_type, $sDpre_mail;

        if (SQLCODE == SQLNOTFOUND) break;

        $select unique '(�ɱH)'
            into $sRePrint
            from tmp_reprint_dmgCare
            where iclaim = $sIclaim;
        if (SQLCODE == SQLNOTFOUND) strcpy(sRePrint, "");

        printf("sRePrint = [%s], \n", sRePrint);

        /* ------------------------------------------------------------------ */
          /* �t�X�ݨD,�N�a�}�ζl���ϸ������z�߮׮ɯd�U����ơC
                        add by sylvia 108.06.26 (1080618014_SC1)  */
        printf("3. sNzip = [%s], sNaddress=[%s] \n", sNzip, sNaddress);
        strcpy(sCarDbName, get_car_full_db(sIpolicy));
        sprintf_s(sTmpSQL, 512, "select aassured_zip, aassured || '%s' \
	                         from %s:adjustment_ply \
	                        where iclaim = '%s' \
	                          and aassured_zip <> ' ' and aassured <> ' ' ",
            sRePrint, sCarDbName, sIclaim);

        $PREPARE chg_aasured2 FROM $sTmpSQL;
        $DECLARE chg_aasured2_CUR CURSOR FOR chg_aasured2;
        $OPEN    chg_aasured2_CUR;
        $FETCH   chg_aasured2_CUR INTO $sNzip, $sNaddress;
        $CLOSE chg_aasured2_CUR;
        $FREE  chg_aasured2_CUR;
        printf("4. sNzip = [%s], sNaddress=[%s] \n", sNzip, sNaddress);
        /* ------------------------------------------------------------------ */

        if (msettle == 0) continue;

        if (sNadjust[0] == ' ' || sNadjust[0] == '\0')
        {

            $select c.nname
                into $sNadjust
                from ca_clm_process a, personal:asempl b, officer c
                where a.iclaim = $sIclaim
                and a.adjustment = b.empl_no
                and b.administrator = c.iofficer;
            if (SQLCODE == SQLNOTFOUND) strcpy(sNadjust, " ");


            $select rtrim(z.branch_tel) || ' #' || rtrim(z.ext_tel)
                into $sIadjtel
                from ca_clm_process x, personal:asempl y, cm_emp_ext z
                where x.iclaim = $sIclaim
                and x.adjustment = y.empl_no
                and y.administrator = z.empl_no;
            if (SQLCODE == SQLNOTFOUND) strcpy(sIadjtel, " ");

        }

        /* �Y�z�߸g��|�L�q��,�H�D�ު��q�ܴ��N modify by sylvia 108.12.02 */
        if (sIadjtel[0] == ' ' || sIadjtel[0] == '\0')
        {
            $select rtrim(z.branch_tel) || ' #' || rtrim(z.ext_tel)
                into $sIadjtel
                from ca_clm_process x, personal:asempl y, cm_emp_ext z
                where x.iclaim = $sIclaim
                and x.adjustment = y.empl_no
                and y.administrator = z.empl_no;
            if (SQLCODE == SQLNOTFOUND) strcpy(sIadjtel, " ");
        }

        /*      fprintf(fp,"%s\t%s\t%s\t%s\t",sNassured, sNzip, sNaddress, sIpolicy);     */
        fprintf(fp, "%s\t%s\t%s\t%s\t", sNassured, sNzip, sNaddress, " ");
        fprintf(fp, "%s\t%s\t%s\t%s\t%s\t", sIclaim, sItag, sDclaim, sDgroup, sNadjust);
        fprintf(fp, "%s\t%ld\t%s\n", sIadjtel, msettle, sDtoday);


        /* (Start)�H�󤺮e�P�B�g�J�߮פ�x (1140115008_A01) */
        /* ���]��� */
        sprintf_s(remark, sizeof(remark), "%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%ld\t%s",
            sNassured, sNzip, sNaddress, " ", sIclaim, sItag, sDclaim, sDgroup, sNadjust, sIadjtel, msettle, sDtoday);
        printf("remark[%s]\n", remark);

        $select unique iverify
            into $sIverify
            from ca_ver_relation
            where iclaim = $sIclaim;
        if (SQLCODE == SQLNOTFOUND) strcpy(sIverify, sIclaim);

        printf(" sIverify=[%s] \n", sIverify);

        $WHENEVER SQLERROR CONTINUE;

        /* �߮פ�x */
        $INSERT INTO ca_clm_journal
        (iverify, iserial,
            drecord, nplace, njournal, nremark, ientry, dentry, dcreate, inumber, iemail,
            itype)
            VALUES
            ($sIverify, (SELECT nvl(max(iserial), 0) + 1 FROM ca_clm_journal WHERE iverify = $sIverify),
                CAST(CURRENT AS DATETIME YEAR TO MINUTE), '�H��', '�v�q�q��', $remark, 'car5013', CURRENT, CURRENT, '', '',
                CASE
                WHEN(select count(*) FROM tmp_reprint_dmgCare where iclaim = $sIclaim) > 0
                THEN '' ELSE '5-2-' || $sIclaim
                END);

        if (SQLCODE < 0) {
            if (sErrMsg[0] != '\0') {
                strcat(sErrMsg, ",");
            }
            strcat(sErrMsg, trim(sIclaim));
        }

        $WHENEVER SQLERROR GOTO errexit;

        /* �ɱH�H�󤣻ݦA�g�Jca_edm */
        if (strcmp(sFedm, "X") == 0) {
            count_file1++;
            continue;
        }

        /* (End)�H�󤺮e�P�B�g�J�߮פ�x (1140115008_A01) */


        /* (Start)�t�X�o�eEDM�ݨD,���^����L���üg�J ca_edm�Cadd by sylvia 108.08.26 (1080124010_SC2) */
            /* �����p���O�r (��108/9/12�|ĳ����)*/
        strcpy(sDcontact, "");
        $select min(a.drecord) into $sDcontact
            from ca_clm_journal a, ca_ver_relation b
            where a.iverify = b.iverify
            and b.iclaim = $sIclaim
            and a.itype = '1-2-1';

        /* �̫�@���p���O�r�w�d�� (��108/9/12�|ĳ����)(108/9/24 mail�^�Эn�אּ����)*/
        strcpy(sDverify, "");
        $select min(a.drecord) into $sDverify
            from ca_clm_journal a, ca_ver_relation b
            where a.iverify = b.iverify
            and b.iclaim = $sIclaim
            and a.itype in('3-6', '3-6-1');

        /* �����q�������ɮ֤�� (��108/9/12�|ĳ����)*/
        strcpy(sDsurvey, "");
        $select min(a.drecord) into $sDsurvey
            from ca_clm_journal a, ca_ver_relation b
            where a.iverify = b.iverify
            and b.iclaim = $sIclaim
            and a.itype in('2-3', '2-1A-1', '2-1A-2', '2-2A', '2-1B-1', '2-1B-2', '2-1B-3', '2-1B-4');

        /* ����F�d�N����Email */
        sprintf_s(sTmpSQL, 512, "select a.fdmg_duty, nvl(b.iemail, ' '), a.fpart, a.iacc_reason \
	                       from %s:appraisal a, %s:adjustment_ply b \
	                      where a.iclaim = b.iclaim \
	                        and a.iclaim = '%s' ", sCarDbName, sCarDbName, sIclaim);

        $PREPARE pre_edm1 FROM $sTmpSQL;
        $DECLARE cus_edm1 CURSOR FOR pre_edm1;
        $OPEN    cus_edm1;
        $FETCH   cus_edm1 INTO $sFdmg_duty, $sEmail, $sFpart, $sIacc_reason;
        $CLOSE cus_edm1;
        $FREE  cus_edm1;

        /* (End)���l�Τ�����]�X�I,���H�oEDM add by sylvia 109.01.22 (1081104003_SC1) */

        /* �������I������:�אּ�P�_�߮׸��Ĥ��X��S */
        strcpy(sFpart, trim(sFpart));
        strcpy(sIacc_reason, trim(sIacc_reason));
        /* if ((strcmp(sFpart,"4") != 0) || (strcmp(sIacc_reason,"15") == 0) ||
            (strcmp(sIacc_reason,"16") == 0) || (strcmp(sIacc_reason,"17") == 0)) */
        if ((strcmp(sFpart, "4") != 0) || sIclaim[5] == 'S')
        {
            strcpy(sFedm, "N");
        }

        /* sDpre_mail */
        if (strcmp(sFedm, "N") == 0)
            strcpy(sDpre_mail, "");

        $insert into ca_edm
        (nassured, iassured, itag, iclaim, adjustment,
            nadjust, daccident, dclaim, dcontact, dverify,
            dsurvey, fdmg_duty, dgroup, fedm, iemail,
            aassured_zip, aassured, iroute, ipolicy, iadj_tel,
            msettle_dmg, iins_type, dpre_mail, icreate, dcreate,
            iupdate, dupdate)
            values
            ($sNassured, $sIassured, $sItag, $sIclaim, $sAdjustment,
                $sNadjust, $sDaccident, $sDclaim, $sDcontact, $sDverify,
                $sDsurvey, $sFdmg_duty, $sDgroup, $sFedm, $sEmail,
                $sNzip, $sNaddress, $sIroute, $sIpolicy, $sIadjtel,
                $msettle, $siins_type, $sDpre_mail, $userid, current,
                $userid, current);

        count_file1++;
    }
    $CLOSE DMG_CUR;
    $FREE  DMG_CUR;
    fclose(fp);

    $commit work;

    if (sErrMsg[0] != '\0')
    {
        /*allen.wang@tmnewa.com.tw*/
        printf("[%s]\n", sErrMsg);
        sprintf_s(cmd_stmt, 256,
            "echo \"error iclaim %s\" | mailx -r ipisnew@tmnewa.com.tw -s \"[car5013] dmgCare Insert ca_clm_journal error\" winnie.wang@tmnewa.com.tw ",
            sErrMsg);
        printf("[%s]\n", cmd_stmt);
        rc = system(cmd_stmt);
    }

    printf("count_file1 = [%d]", count_file1);

    rc = rptftpinsert(userid, "car5013", fileName1);
    if (rc != 0) {
        sprintf_s(sErrMsg, 256, "%s�g�Jrptftplist���~", fileName1);
        return rc;
    }

    return M_CM_OK;

errexit:
    fclose(fp);
    printf("-- Query_claimCare -- SQLCODE=[%ld], sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    $rollback work;
    return SQLCODE;
}

/*----------------------------------------------------------------------------*/
long tar_file()
{
	int result;
	char tar[512], gzip[121];
	char command1[256],command2[256],copyCommand[256],copyCommand1[256];
    
    /*---------------------*/
    /*       for���~       */
    /*---------------------*/
    /* 1140120006_A01 ����X��Ƶ����~ */
    /* ���]�z�����h��r�� */
	/*sprintf_s(tar,256,"tar -cvf %s/rptftp/car_out/%s_claimCare.tar %s/rptftp/%s %s/rptftp/%s",
	                sApHome, sdate, sApHome, fileName, sApHome, fileName1 );
	printf("tar[%s]\n", tar);
	sprintf_s(command1,256, "%s", tar);
	result = system(command1);
	printf("tar-result[%d]\n", result);*/

	/* ���Y���]�n���ɮ�.gz */
	/*sprintf_s(gzip,256,"gzip %s/rptftp/car_out/%s_claimCare.tar", sApHome, sdate);
	printf("gzip[%s]\n", gzip);
	sprintf_s(command2,256, "%s", gzip);
	result = system(command2);
	printf("gzip-result[%d]\n", result);  */

    /*---------------------*/
    /*       for�ʳq       */
    /*---------------------*/
    /* ���� txt �ɮר���w�ؿ� */
    if (count_file > 0){
        sprintf_s(copyCommand,256, "cp %s/rptftp/%s %s/rptftp/car_claim/", sApHome, fileName, sApHome);
        printf("copyCommand[%s]\n", copyCommand);  
        result = system(copyCommand);
        printf("copy-result[%d]\n", result);
    }
    if (count_file1 > 0){
        sprintf_s(copyCommand1,256, "cp %s/rptftp/%s %s/rptftp/car_claim/", sApHome, fileName1, sApHome);
        printf("copyCommand1[%s]\n", copyCommand1);
        result = system(copyCommand1);
        printf("copy-result1[%d]\n", result);
    }

	return M_CM_OK;
}
/*----------------------------------------------------------------------------*/
long car_get_db()
{
    int	rc;
    $char stmt[4096];

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
       return M_CM_DB_NOTOPEN;
    }

    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }

    if ((list=get_db_list(&count_db,DBName)) == (char*)0)
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;
    }

    $create temp table claim_app_dtl_2
    (
         iclaim1           char(20),
         insure_type       char(1),
         insure_instype    char(6),
         mclaim_app        decimal(12,0)
    )with no log;

    $create unique index claim_app_dtl_2_ix1
         on claim_app_dtl_2(iclaim1, insure_type, insure_instype);

    $create temp table claim_app_dtl_h_2
    (
         iclaim1           char(20),
         insure_type       char(1),
         insure_instype    char(6),
         mclaim_app        decimal(12,0),
         dappraisal        date
    )with no log;

    $create unique index claim_app_dtl_h_2_ix1
         on claim_app_dtl_h_2(iclaim1, insure_type, insure_instype, dappraisal);

    $create index claim_app_dtl_h_2_ix2
         on claim_app_dtl_h_2(dappraisal);

    $create temp table claim_stl_dtl_2
    (
         iclaim1           char(20),
         fstl              char(1),
         iclose_type       char(4),
         insure_type       char(1),
         insure_instype    char(6),
         dgroup            date,
         msettle           decimal(12,0),
         mfee              decimal(8,0)
    )with no log;

    $create unique index claim_stl_dtl_2_ix1
         on claim_stl_dtl_2(iclaim1,fstl,iclose_type,insure_type,insure_instype);

    $create index claim_stl_dtl_2_ix2 on claim_stl_dtl_2(dgroup);

    for (k = 0; k < count_db; k++)
    {
        strcpy(fulldb, list[k].dbname);

        sprintf_s(stmt, 256,
            " insert into claim_app_dtl_2    \
           select iclaim, 'C', iins_type, mins_app   \
             from %s:app_ins_type ", fulldb);

        printf("stmt[%s]\n", stmt);

        $prepare getapp2 from $stmt;
        $execute getapp2;

        sprintf_s(stmt, 256,
            " insert into claim_app_dtl_h_2    \
           select iclaim, 'C', iins_type, mins_app, dappraisal   \
             from %s:app_ins_type_hist ", fulldb);

        printf("stmt[%s]\n", stmt);

        $prepare getapph2 from $stmt;
        $execute getapph2;

        sprintf_s(stmt, 512,
            " insert into claim_stl_dtl_2    \
           select iclaim, fstl, cast(iclose_type as char(4)), 'C', iins_type, dgroup,    \
                  decode(fstl,'2',mins_stl*(-1),mins_stl)+mins_proc, mins_proc    \
             from %s:stl_ins_type ", fulldb);

        printf("stmt[%s]\n", stmt);

        $prepare getstl2 from $stmt;
        $execute getstl2;
    }

/*
    $insert into claim_app_dtl_2
        select iclaim, 'C', iins_type, mins_app
        from newa00:app_ins_type;

    printf("app_ins_type\n");

    $insert into claim_app_dtl_h_2    
           select iclaim, 'C', iins_type, mins_app, dappraisal   
             from newa00:app_ins_type_hist;

    printf("app_ins_type_hist\n");

    $insert into claim_stl_dtl_2
        select iclaim, fstl, cast(iclose_type as char(4)), 'C', iins_type, dgroup,
        decode(fstl, '2', mins_stl * (-1), mins_stl) + mins_proc, mins_proc
        from newa00:stl_ins_type;

    printf("stl_ins_type\n");
    */

    return M_CM_OK;

errexit:
    printf("-- car_get_db -- SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
return SQLCODE;
}
/*----------------------------------------------------------------------------*/
