/****************************************************
 * Copyright (C) 1993 Intellisys Corporation
 *
 * Program : ca203q01s.ec 
 *
 * revised : Johnny 1997/07/11
 *
 * Background Report   (Type : Free Style)
 ****************************************************/

#include <stdio.h>
#include <math.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"

#include "carmsgs.h" 
#include "commsgs.h" 
#include "cmnmsgs.h" 
#include "gls_array.h" 
#include "gls_const.h"
#include "sqlfatal.h"
#include "spcmsgs.h"

$char what_type[8],sitename[20];;
$char ipolicy[21],icard[21],nassured[122],aassured[92],apayment[92],ilicense[12],ibirth[10];
$char iassured[11];
$char fsex[2],ncar_abbr[14],iissue_ym[8],itag[CA_TAG_NUM],dply_begin[14],dply_end[14];
$char icar_type[4],ibrand[10],nbrand_abbr[14],ibody[CA_BODY_NUM],itel[21],iengine[CA_ENGINE_NUM];
 char iengine_ext[6];
$char irelative_ply[20],qcylinder_buf[20],qperiod_buf[20],mpremium_buf[20];
$char bcard1[20],bcard2[20],bcard3[20],mY[4],mN[4],rel_ins_type[24],pdate[16];
$char bak_ins[8],fmarriage[4],irelative_card[20], iquery_num[15];
$int qperiod,mpremium;
$double qcylinder;
int tmp_prem,other_prem,flag1=0;
$double qpt;
char  ch_amt[40],policy_y;
char  s_dpolicy[14];
static char yy1[4], mm1[3], dd1[3];
$char allins1[100],allins2[100],ins1[24],ins12[24],ins2[24],ins22[24],ins3[24];
$char ins32[24],irelative_ply1[20],rel_card1[20],rel_card2[20];
$char fcomp_class[3],fcomp_class_last[3],fpt,cqpt[6];
$char icard1[20],ipolicy1[20],nassured1[122],ncar_abbr1[14],nbrand_abbr1[14];
$char iengine1[CA_ENGINE_NUM],itag1[CA_TAG_NUM],ilicense1[12],dply_begin1[14],dply_end1[14],ibody1[CA_BODY_NUM+1];
$char itmp_policy[21],isign[11],ientry[11],iscan_no[26];

$char Ipolicy[20],Iofficer[11],Iofficer_tmp[13],Nofficer[21];
$char ileader[10],Nleader[21];
$char icorps[11], ibranch[7];
$char Nbranch[19];
$char remark[128];

/*ca_accident*/
$char Inumber[21];

$int sqltmp;

$int frelative=0;

/*----------------------------------------------------------------------*/
extern char RPTDIR[];

$char print_type[10],cardbegin[20], cardend[20], mark[20],check_card[20];
$char print_frm[2],print_card[2],flag_tag[2], print_kind[2];
$char qDentry_bgn[11], qDentry_end[11], qIpolicy3[4], qIquota[8], qIleader[11], qIentry[11];
$char qIpolicy_bgn[11], qIpolicy_end[11], qIcar_kind[2];

$char feply[2];
$char dply_begin_100[11],dply_begin_yy[4],dply_begin_mm[3],dply_begin_dd[3];
$char dply_end_100[11],dply_end_yy[4],dply_end_mm[3],dply_end_dd[3];
$char s_today[11],tyy[4],tmm[3],tdd[3];
$char site2[3];
$char npresident[11],tax_area[11];
char tax_area1[3];
char tax_area2[3];
$char dcreate[21];
$char url1[256],url2[256],url3[256];
$char s_qperiod[3],s_qcylinder[9];

int max_count;

$char DBName[5];
$char FormTp[3];
$char  outputf[20];
$char  userid[11];
static Today;

long car203_build();
long car203_body();
long car203_freeform();
long insert_freeform();

char s_qlia[3][10], fyear[3];
$date rate_date;
long qdmg[3],qlia[3];
long mdmg[3],mlia[3];
long qlia_acc,qdmg_acc;
double pdmg_acc,plia_acc;

$char sToday1[11],sToday2[11];
$char skpid[12];
$char  errmsg[300];

$char r_itmp_policy[20];
$int  iout_draw = 0;
$char chk_35note[2];

$char ipgid[10];

long ca_free_data();

/*---------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
	long rc;
	batchinit();
	strcpy(DBName,      isNULLstr(argv[1]));
	strcpy(userid,      isNULLstr(argv[2]));
	strcpy(print_type,  isNULLstr(argv[3]));  /** 1:���N 2:�j�� **/
	strcpy(what_type,   isNULLstr(argv[4]));  /** 1:�O�渹 2:�j����/���N�d **/
	strcpy(cardbegin,   isNULLstr(argv[5]));
	strcpy(cardend,     isNULLstr(argv[6]));
	strcpy(mark,        isNULLstr(argv[7]));  /** '0','1':�e�~��P�O **/
	strcpy(print_frm,   isNULLstr(argv[8]));  /** 3:���O�N��,4:���@����ª�,5:���@���s�� 8:102/9/1�W�u�s�� **/
	strcpy(flag_tag,    isNULLstr(argv[9]));  /** 1:���L���P, 0:�L���P(default) **/
	strcpy(print_kind,  isNULLstr(argv[10])); /** 0:�O�I�ҦL�s 1:�D�~��d�L�� **/
	printf("client send %s %s %s %c %s %s\n",print_type,cardbegin,cardend,mark[0],print_frm,print_kind);
	strcpy(print_kind, trim(print_kind));
	if (strcmp(print_kind, "0") == 0)
	{
		strcpy(skpid,   isNULLstr(argv[11])); /** Freeform.kpid **/
		strcpy(ipgid,   isNULLstr(argv[12])); /** programid **/
		strcpy(outputf, isNULLstr(argv[13]));
	}
	else
	{
		strcpy(qDentry_bgn,  isNULLstr(argv[11]));  /** ��J���(�_) **/
		strcpy(qDentry_end,  isNULLstr(argv[12]));  /** ��J���(��) **/
		strcpy(qIpolicy3,    isNULLstr(argv[13]));  /** ���(�O��e�T�X) **/
		strcpy(qIquota,      isNULLstr(argv[14]));  /** �~�Z��� **/
		strcpy(qIleader,     isNULLstr(argv[15]));  /** �޲z�H�N�� **/
		strcpy(qIentry,      isNULLstr(argv[16]));  /** ��J�H�N�� **/
		strcpy(qIpolicy_bgn, isNULLstr(argv[17]));  /** �O�渹�X(�_) **/
		strcpy(qIpolicy_end, isNULLstr(argv[18]));  /** �O�渹�X(��) **/
		strcpy(qIcar_kind,   isNULLstr(argv[19]));  /** 0:���� 1:�T�� **/ 
		strcpy(skpid,        isNULLstr(argv[20]));  /** Freeform.kpid **/
		strcpy(ipgid,        isNULLstr(argv[21]));  /** programid **/
		strcpy(outputf,      isNULLstr(argv[22]));
		printf("client send %s %s %s %s %s %s %s %s %s \n",qDentry_bgn,qDentry_end,qIpolicy3,qIquota,qIleader,qIentry,qIpolicy_bgn,qIpolicy_end,qIcar_kind);
	}

	rc=car203_build();
	if (rc != M_CM_OK) 
	{
		if (rc != 0)
		{
			sprintf(errmsg,"�j���Ҳ��s���~[%d] ",rc);
			$INSERT INTO cm_freeform_dtl VALUES($skpid,'C',' ',' ',' ',' ',' ',199,' ',' ',' ',$errmsg,$userid,current);
		}
	}
	strcpy(errmsg,"�pCMN201���A���uF�v�B����{���N�����ucar203a�v�A�Ц�CMN545�T�{�O����檬�A");
	EWRITE(userid, 0, errmsg);
	return 0;
}
/******************************************************************************/
void clear_data()
{
	ipolicy[0]=icard[0]=irelative_ply[0]=itmp_policy[0]=0;
	isign[0]=ientry[0]=iscan_no[0]=0;
	fcomp_class[0]=fcomp_class_last[0]=0;
	cqpt[0]=0;
	nassured[0]=aassured[0]=0;
	apayment[0]=0;
	ncar_abbr[0]=0;
	iissue_ym[0]=0;
	itag[0]=0;
	iengine[0]=0;
	icar_type[0]=0;
	nbrand_abbr[0]=0;
	ibrand[0]=0;
	qcylinder_buf[0]=0;
	ibody[0]=0;
	dply_begin[0]=dply_end[0]=0;
	qperiod_buf[0]=0;
	mpremium_buf[0]=0;
	ilicense[0]=0;
	ibirth[0]=0;
	fsex[0]=0;
	itel[0]=0;
	bcard1[0]=0;
	irelative_card[0]=0;
	mY[0]=mN[0]=0;
	rel_ins_type[0]=0;
	pdate[0]=0;
	fmarriage[0]=0;
	frelative=0;
	chk_35note[0]=0;
}
/******************************************************************************/ 
long car203_build()
{
	$char FormFile[N_FILE+1];
	char  OutFile[N_FILE];
	long  rtncode;
	int   res=0,iTryCnt=0;
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		return M_CM_DB_NOTOPEN;
	}
	
	/* INSERT cm_freeform     kpid       ����Ǹ�,   iins_cat �I�O,       formid�M�L�O,      fprint   �C�L�O, fformal �����O, 
	                          fhide      �Ӹ�����,   fnote    ���C�L�Ƶ�, fbranch�C�L����O, fversion ���ƥ�, fpolicy �O��O, 
	                          fcondition �C�L���ڧO, iprinter �L�����N�� */
	/*$INSERT INTO cm_freeform (kpid, iins_cat, formid, fprint, fformal, 
	                          fhide, fnote, fbranch, fversion, fpolicy,
	                          fcondition, iprinter, ipgid, iupdate, tstime, tetime)
	                  VALUES ($skpid, 'C', 'CARCARD001', ' ', 'F',
	                          'N', ' ', ' ', ' ', ' ',
	                          ' ',  ' ', 'car203a', $userid, current, NULL);
	*/
	
	/* 1111019012_C05_���I�Φ����O���Freeform�L�s�}�o(�q�l�O��) - �D�ɲ���fversion�A�����ɷs�Wfversion */
	/* INSERT cm_freeform     kpid       ����Ǹ�,   iins_cat �I�O,       formid�M�L�O,      fprint   �C�L�O, fformal �����O, 
	                          fhide      �Ӹ�����,   fnote    ���C�L�Ƶ�, fbranch�C�L����O, fpolicy �O��O, 
	                          fcondition �C�L���ڧO, iprinter �L�����N�� */
	$INSERT INTO cm_freeform (kpid, iins_cat, formid, fprint, fformal, 
	                          fhide, fnote, fbranch, fpolicy,
	                          fcondition, iprinter, ipgid, iupdate, tstime, tetime)
	                  VALUES ($skpid, 'C', 'CARCARD001', ' ', 'F',
	                          'N', ' ', ' ', ' ',
	                          ' ',  ' ', $ipgid, $userid, current, NULL);

	rtoday(&Today);
	strcpy(s_dpolicy,cm_cdate_str_100(Today));
	cm_split_ymd_100(s_dpolicy,yy1,mm1,dd1);
	strcpy(print_kind, trim(print_kind));
	if (strcmp(print_kind, "1") == 0)
	{
		rtncode=car203_temp_table();
		if (rtncode != M_CM_OK)
		{
			sprintf(errmsg,"�j���Ҳ��s���`_car203_temp_table[%d]",rtncode);
			$INSERT INTO cm_freeform_dtl VALUES($skpid,'C',' ',' ',' ',' ',' ',199,' ',' ',' ',$errmsg,$userid,current);
			return 0;
		}

		rtncode=car203_check_no_outside();
		if (rtncode != M_CM_OK)
		{
			sprintf(errmsg,"�j���Ҳ��s���`_car203_check_no_outside[%d]",rtncode);
			$INSERT INTO cm_freeform_dtl VALUES($skpid,'C',' ',' ',' ',' ',' ',199,' ',' ',' ',$errmsg,$userid,current);
			return 0;
		}
	}
	
	rtncode=car203_body(); 
	if (rtncode != M_CM_OK)
	{
		if ( print_kind[0] == '1' )
		{
			sprintf(errmsg,"�j���Ҳ��s����_1[%s]",remark);
			$INSERT INTO cm_freeform_dtl VALUES($skpid,'C',' ',' ',' ',' ',' ',199,' ',' ',' ',$errmsg,$userid,current);
			return 0;
		}
		else
		{
			sprintf(errmsg,"�j���Ҳ��s����_2[%d]",sqlca.sqlerrm);
			$INSERT INTO cm_freeform_dtl VALUES($skpid,'C',' ',' ',' ',' ',' ',199,' ',' ',' ',$errmsg,$userid,current);
			return 0;
		}
	}
	
	/* UPDATE cm_freeform.tetime */
	$UPDATE cm_freeform
	    SET tetime = CURRENT
	  WHERE kpid = $skpid;
	
	printf("finish_code------>%d\n",rtncode);
	return M_CM_OK;

errexit:
	sqltmp = SQLCODE;
	$ROLLBACK WORK;
	return sqltmp;
} 

/*----------------------------------------------------------------------------*/   
long car203_body()
{
	$char stmt[400], stmt1[400],stmt2[400], stmt3[400];
	$char Condition1[128], Condition2[128], Condition3[128], sFtype_pol[3];
	$char sFtype_sp[3], fstatus[2];
	$int  iFstatus, count_pass, count_receipt;
	char which_card[100],taipei_db[40];
	int i, j; 
	$int rc;          /* 1071113006_SC1_CAR203�s�W�C�L��� */
	$char Msg[256];
	
	$WHENEVER SQLERROR GOTO errexit;
	max_count=0;
	$BEGIN WORK;
	if (print_type[0]=='2') /* �L�j��� */
	{
		if (print_kind[0] == '0')
		{
			if (what_type[0]=='1') /* ����:�O�渹 */
			{
				sprintf(which_card,"ipolicy >= '%s' AND ipolicy <= '%s' order by ipolicy",cardbegin,cardend);
				$SELECT icard INTO $check_card 
				   FROM policy 
				  WHERE ipolicy = $cardbegin;
				if (SQLCODE==SQLNOTFOUND) strcpy(check_card," ");
			}
			else  /* ����:�j��� */
			{
				sprintf(which_card,"icard >= '%s' AND icard <= '%s' order by icard",cardbegin,cardend);
				strcpy(check_card,cardbegin);
				printf("check_card----->%s",check_card);
			}

			if (check_card[3] >='A' && check_card[3] <= 'Z')  /*�O�N��*/
			{
				if (getHeadBranch(taipei_db)<0) 
				{
					printf("read Config file error!!\n");
					return M_CM_READ_CONFIG_ERR;
				}
				printf("taipei_db----->[%s]\n",taipei_db);
				strcpy(sitename,get_full_dbname(taipei_db));
				strcat(sitename,":");
			}
			else 
				strcpy(sitename," ");

			printf("      ### sitename=[%s] \n",sitename);
	
			/* �j��d���B�O�渹�B�O�I�����Bñ���� �A�q�j��d�� */
			if(what_type[0]=='2')
			{    
				printf(" �j��d�� what_type = 2 \n");  /* �j��d�� */     
				sprintf(stmt1, "SELECT ipolicy, icard, qperiod, dissue \
				                  FROM %scompulsory_card c, car_type t \
				                 WHERE fclass='1' AND t.icode=c.icar_type AND %s",sitename,which_card);
			} else {
				printf(" �O�渹 what_type = 1 \n"); /* �O�渹 */
				sprintf(stmt1, "SELECT ipolicy, icard \
				                  FROM policy  \
				                 WHERE %s",which_card);
			}
		}
		else
		{
			sprintf(stmt1, "SELECT ipolicy FROM car203_tmp_policy ORDER BY ipolicy ");
			strcpy(qIcar_kind, trim(qIcar_kind));
			if (strcmp(qIcar_kind, "0") == 0)
				strcpy(Condition1, "AND icar_type IN ('01','02','32','34','35') ");
			else
				strcpy(Condition1, "AND icar_type NOT IN ('01','02','32','34','35') ");
		}

		printf("stmt1 [%s]\n",stmt1);
		$PREPARE cur_stmt1 from $stmt1;
		$DECLARE cur_com1 CURSOR for cur_stmt1; 
		$OPEN cur_com1; 
		for(;;)
		{
			clear_data();
			policy_y = 'Y';
			$FETCH cur_com1 INTO $ipolicy,$icard,$qperiod,$pdate;
			printf("icard [%s] ipolicy [%s] \n",icard,ipolicy);
			if (SQLCODE == SQLNOTFOUND)
			{      
				printf(" SQLCODE = [%d]\n",SQLCODE);
				break;
			}
			strcpy(Ipolicy, ipolicy); /*Ipolicy�j��O��	*/
			printf("[%s][%s][%s]\n",icard,ipolicy,pdate);
     
			if (print_kind[0] == '1')
			{
				/* 1060821005_C2_�j���Һ޲z�{�� */
				/* �j���Ҫ��A : 0.���X */
				strcpy(icard, "");
				sprintf(stmt3, "SELECT FIRST 1 icard, fstatus FROM compulsory_card \
				                 WHERE icard >= '%s' \
				                   AND icard <= '%s' \
				                   AND fstatus in ('0','5','6') \
				                   AND (trim(ipolicy) = '' OR ipolicy IS NULl) \
				                    %s ORDER BY icard;",cardbegin, cardend, Condition1);
				$PREPARE card_cur FROM $stmt3;
				$EXECUTE card_cur INTO $icard, $fstatus;
				if (SQLCODE == SQLNOTFOUND) {
					strcpy(remark, "�ҿ�J���j���Ҹ��϶��t�����i�i��ñ��/�L�Ҥ��ҥd(���A�D0,5,6��),�нT�{���ҥd���iñ�檬�A");
					break;
				}
				printf("***** �j���Ҫ��A:[%s][0.���X]*****\n", icard);
			}

			/* 1130607001_C01_�R���j���I���ڷL�q��������� */
			$SELECT p.ipolicy, p.nassured, p.aassured, p.apayment, r.icar_type,
			        p.ncar_abbr, 
			        to_char(p.dissue,'%Y')::integer - 1911,
			        p.itag, p.iengine, p.nbrand_abbr, 
			        r.ibrand, p.qcylinder, p.ibody, r.dply_begin, r.dply_end, 
			        r.qply_period, p.ilicense, 
			        to_char(p.dbirth,'%Y')::integer - 1911 || '/' || to_char(p.dbirth,'%m/%d'), 
			        p.fsex, p.itel, 
			        r.dpolicy, r.ilast_card, p.fmarriage, r.mlia_prem, r.iofficer,
			        p.fpt, p.qpt, p.iassured, r.ileader, r.icorps, r.iquota[1,4] || '00' ibranch, iquery_num,
			        nvl(r.itmp_policy,''), r.isign, r.ientry, r.iscan_no, r.feply, to_char(r.dcreate,'%Y-%m-%d %H:%M:%S'),
			        case when r.dply_begin < '11/30/2024' then 'Y' else 'N' end 
			   INTO $ipolicy, $nassured, $aassured, $apayment, $icar_type,
			        $ncar_abbr, 
			        $iissue_ym, 
			        $itag, $iengine, $nbrand_abbr, 
			        $ibrand, $qcylinder, $ibody, $dply_begin, $dply_end, 
			        $qperiod, $ilicense, 
			        $ibirth, 
			        $fsex, $itel,
			        $pdate, $bcard1, $fmarriage, $mpremium, $Iofficer, 
			        $fpt, $qpt, $iassured, $ileader, $icorps, $ibranch, $iquery_num,
			        $itmp_policy,$isign, $ientry, $iscan_no, $feply, $dcreate, $chk_35note
			   FROM policy p, ply_relation r 
			  WHERE p.ipolicy = r.ipolicy AND r.ipolicy=$ipolicy;
     
			printf("SQLCODE == [%d]\n",SQLCODE);
			if (SQLCODE== SQLNOTFOUND) 
			{
				qperiod=0; pdate[0]=0; mpremium=0;policy_y = 'N'; 
				printf("not found\n");
			}
			else
			{
				$SELECT  nname
				   INTO  $Nofficer
				   FROM  officer
				  WHERE  iofficer = $Iofficer;

				$SELECT  nname
				   INTO  $Nleader
				   FROM  officer
				  WHERE  iofficer = $ileader;

				$SELECT nbranch
				   INTO $Nbranch
				   FROM sa_branch_type
				  WHERE ibranch = $ibranch;

				$SELECT  ncode
				   INTO  $ncar_abbr
				   FROM  car_type
				  WHERE  icode = $icar_type AND fclass = '1';
				ncar_abbr[8] = '\0';
				printf("---------------->%s \n",ncar_abbr);  
				
				frelative = 0;
				$SELECT nvl(irelative_ply,' '),fcomp_class,fcomp_class_last 
				   INTO $irelative_ply,$fcomp_class,$fcomp_class_last  
				   FROM ply_relation
				  WHERE ipolicy=$ipolicy;
				if (SQLCODE != SQLNOTFOUND) 
				{
					/* select �I�إN�X from �O���I�ة��� */ 
					$DECLARE cur_ins CURSOR for
					  SELECT iins_type
					    FROM ply_ins_type  
					   WHERE ipolicy=$irelative_ply;
					$OPEN cur_ins;
					for(;;)
					{
						$FETCH cur_ins into $bak_ins;
						if (SQLCODE == SQLNOTFOUND) break;
						strcat(rel_ins_type,rtrim(bak_ins)); 
					}
					
					strcpy(irelative_ply,trim(irelative_ply));
					if(strlen(irelative_ply)>0)
					{
						$SELECT nvl(itmp_policy,'')
						   INTO $r_itmp_policy 
						   FROM ply_relation 
						  WHERE ipolicy = $irelative_ply;
						  
						strcpy(itmp_policy,rtrim(itmp_policy));
						strcpy(r_itmp_policy,rtrim(r_itmp_policy));
						
						iout_draw = 0;
						$SELECT count(*)
						   INTO $iout_draw
						   FROM ca_out_draw 
						  WHERE ipolicy = $ipolicy
						    AND fout_type = '0';

						/* �qcm_receipt_log�P�_���N�I�O�_�w���L���ڡA�Y�L frelative = 1 (�L��j��) */						
						count_receipt = 0;
						$SELECT count(*)
						   INTO $count_receipt
						   FROM cm_receipt_log
						  WHERE iins_cat = 'C'
							AND ipolicy = $irelative_ply
							AND iendorse = ''
							AND finvalid = 0;

						printf("itmp_policy[%s] r_itmp_policy[%s] print_kind[%s] iout_draw[%d] ipgid[%s] count_receipt[%d]\n",itmp_policy,r_itmp_policy,print_kind,iout_draw,ipgid,count_receipt);
						if (strcmp(itmp_policy, r_itmp_policy) == 0 && iout_draw == 0 &&
    						((print_kind[0] != '0' && count_receipt == 0) || strncmp(ipgid, "car301", 6) == 0)) 
						{
    						frelative = 1;
						}
					}
					else 
					{
						frelative = 0;
					}
				}
				
				$SELECT icard into $irelative_card
				   FROM ply_relation
				  WHERE ipolicy = $irelative_ply;
				printf( " irelative_card [%s] \n",irelative_card);
				
				$SELECT ilast_card into $bcard2
				   FROM ply_relation
				  WHERE icard=$bcard1;
				if (SQLCODE != SQLNOTFOUND)
				{ 
					$SELECT ilast_card INTO $bcard3
					   FROM ply_relation
					  WHERE icard=$bcard2;
				}
			}
			
			/* car9711072 �Y���������ŭ�,�h�L�X������ */
			if(strlen(trim(iengine)) == 0) strcpy(iengine,ibody);
			
			rc = car203_freeform();

			$UPDATE ply_relation 
			    SET fprint = '1'
			  WHERE ipolicy= $ipolicy 
			    AND fprint = '0';
			
			rc = insert_ca_log("car203","P",icard,ipolicy,"�j���ҦC�L",userid,Msg);
			if( rc != M_CM_OK)
			{
				$ROLLBACK WORK;
				return  rc;
			}
			
			if (strncmp(mark,"1",1) == 0)
			{
				$UPDATE ply_relation
				    SET fmail_type = '0'
				  WHERE ipolicy = $ipolicy
				    AND fout_print = '1'
				    AND fmail_type != '0'
				    AND dout_trans is Null;
				
				$UPDATE ori_ply_relation
				    SET fmail_type = '0'
				  WHERE ipolicy = $ipolicy
				    AND fout_print = '1'
				    AND fmail_type != '0'
				    AND dout_trans is Null;
			}

			/* �u�D�~��d�v�L�Ҧ^������� (1040828003_C2) add by larry */
			if (print_kind[0] == '1')
			{
				/* 1060821005_C2_�j���Һ޲z�{�� */
				printf("***** �D�~��dUPDATE *****\n");
				printf("***** ipolicy[%s], itmp_policy[%s], icard[%s]\n", ipolicy,itmp_policy,icard);
				/* �j��d�� */
				$UPDATE compulsory_card
				    SET fstatus = '1',
				        ialter = $userid,
				        dalter = today,
				        ipolicy = $ipolicy
				  WHERE icard = $icard
				    AND fstatus in ('0','5','6')
				    AND (trim(ipolicy) = '' OR ipolicy IS NULL);
				if (sqlca.sqlerrd[2]==0) {
					$ROLLBACK WORK;
					strcpy(remark, cm_get_errmsg(M_SP_AUDEXCP));
					return M_SP_AUDEXCP; /* 22000 : ��Ʋ��ʮɵo�Ͳ��`�A�Э��� */
				}
				
				strcpy(sFtype_pol, "");
				strcpy(sFtype_sp, "");
				$SELECT ftype_pol, ftype_sp INTO $sFtype_pol, $sFtype_sp
				   FROM cm_pre_receive
				  WHERE iins_cat = 'C'
				    AND ipre_rcv = $itmp_policy
				    AND iins_kind = '1'
				    AND ipre_end = ' ';
				if (SQLCODE == SQLNOTFOUND)
				{
					$ROLLBACK WORK;
					strcpy(remark, cm_get_errmsg(M_CA_PLY_NOT_FOUND));
					return M_CA_PLY_NOT_FOUND;
				}
				strcpy(sFtype_pol, trim(sFtype_pol));
				strcpy(sFtype_sp, trim(sFtype_sp));
				printf("***** ftype_pol[%s], ftype_sp[%s]*****\n", sFtype_pol, sFtype_sp);	       
				/* �O�����p�� */
				/* �O�����O=�uPA�v�B�uSP-01�v�ΡuSP-10�v�h�^���uñ���(�t�Τ�)�v */
				if ((strcmp(sFtype_pol, "SP") == 0 && strcmp(sFtype_sp, "01") == 0) || 
				    (strcmp(sFtype_pol, "SP") == 0 && strcmp(sFtype_sp, "10") == 0) ||
				     strcmp(sFtype_sp,  "PA") == 0 || 
				     strcmp(sFtype_pol, "NA") == 0)
				{
					printf("***** ftype_sp: 01 or PA *****\n");
					$UPDATE ply_relation
					    SET icard = $icard,
					        dpolicy = today
					  WHERE ipolicy = $ipolicy
					    AND ipolicy = icard;
				}
				else
				{
					printf("***** ftype_sp NOT 01 , PA *****\n");
					$UPDATE ply_relation
					    SET icard = $icard
					  WHERE ipolicy = $ipolicy
					    AND ipolicy = icard;
				}
				if (sqlca.sqlerrd[2]==0) {
					$ROLLBACK WORK;
					strcpy(remark, cm_get_errmsg(M_SP_AUDEXCP));
					return M_SP_AUDEXCP; /* 22000 : ��Ʋ��ʮɵo�Ͳ��`�A�Э��� */
				}
				
				/* �O��򥻸���� */
				$UPDATE policy
				    SET icard = $icard
				  WHERE ipolicy = $ipolicy
				    AND ipolicy = icard;
				if (sqlca.sqlerrd[2]==0) {
					$ROLLBACK WORK;
					strcpy(remark, cm_get_errmsg(M_SP_AUDEXCP));
					return M_SP_AUDEXCP; /* 22000 : ��Ʋ��ʮɵo�Ͳ��`�A�Э��� */
				}
           
				/* �O�����O=�uSP-20�v�����^���u�L���v */
				if (strcmp(sFtype_pol, "SP") == 0 && strcmp(sFtype_sp, "20") == 0)
				{
					strcpy(Condition2, " ");
					strcpy(Condition3 ," ");
				}
				else
				{
					count_pass = iFstatus = 0;
					$SELECT count(ipre_rcv) into $count_pass
					   FROM ao_prercv_pass
					  WHERE iins_cat  = 'C'
					    AND ipre_rcv  = $itmp_policy
					    AND iins_kind = '1' 
					    AND ipre_end  = ' ';
					     
					if (count_pass > 0)
						iFstatus = 60 ;   /* �w�L��,�w���O */
					else
						iFstatus = 30 ;   /* �w�L��,�����O */
					
					strcpy(Condition2 ,"dprint = current, ");
					sprintf(Condition3 ,"fstatus  = %d , ", iFstatus);
				}
          
				/* �@�γ����� */
				sprintf(stmt, "UPDATE cm_pre_receive \
				                  SET icard = '%s' , \
				                   %s \
				                   %s \
				                      iupdate = 'CAR203', \
				                      dupdate = current \
				                WHERE iins_cat = 'C' \
				                  AND ipre_rcv = '%s' \
				                  AND iins_kind = '1' \
				                  AND ipre_end = ' ';", icard, Condition2, Condition3, itmp_policy);
				printf("stmt=[%s]\n", stmt);

				$PREPARE cmPreRecevie_pre FROM $stmt;
				$EXECUTE cmPreRecevie_pre;
				if (sqlca.sqlerrd[2]==0) {
					$ROLLBACK WORK;
					strcpy(remark, cm_get_errmsg(M_SP_AUDEXCP));
					return M_SP_AUDEXCP; /* 22000 : ��Ʋ��ʮɵo�Ͳ��`�A�Э��� */
				}
			}
			printf("skpid[%s] ipolicy[%s] icard[%s] Iofficer[%s] ileader[%s] \n ",skpid,ipolicy,icard,Iofficer);
			$INSERT INTO cm_freeform_dtl VALUES($skpid,'C',$ipolicy,' ',$icard,'0',' ',100,$Iofficer,$ileader,' ',' ',$userid,current); 
			/*rc = insert_ca_log("car203","P",icard,ipolicy,"�j���ҦC�L",userid,Msg);*/
		}
		$CLOSE cur_com1;
		$FREE cur_com1;
		printf("print_type2 end\n");
	}
	$COMMIT WORK;

  	return M_CM_OK;

errexit:
	sqltmp = SQLCODE;
	$ROLLBACK WORK;
	return sqltmp;
}
/******************************************************************************/
long car203_check_no_outside()
{
	$char sStmt[4096];    
	$char sIpolicy[21], sItmp_policy[21], sDply_bgn[11], sIcard_tmp[21];
	$char sIofficer[11],sIquota[8],sIcomm_obj[11], sIroute[21], sIroute_prop[3], sIleader[11];
	
	$char ftype_sp[3], deffect4[11], deffect4_edr[10], err_flag[2];
	$char Condition1[128], Condition2[128];
	$int  count_receive, count_pass, sMprem;
	$long sToday, sLdeffect4;
	$int  iTmp, jTmp,fstatus;
	int rc;
  
	$WHENEVER SQLERROR GOTO errexit;
    
	strcpy(qIcar_kind, trim(qIcar_kind));
	if (strcmp(qIcar_kind, "0") == 0) strcpy(Condition1, " AND b.icar_type IN ('01','02','32','34','35') ");
	else strcpy(Condition1, " AND b.icar_type NOT IN ('01','02','32','34','35') ");

	strcpy(qIpolicy_bgn, trim(qIpolicy_bgn));
	if (strcmp(qIpolicy_bgn, "*") != 0)
	sprintf(Condition2, " AND a.ipolicy >= '%s' AND a.ipolicy <= '%s' ",qIpolicy_bgn, qIpolicy_end);
	else strcpy(Condition2, " ");
    
	sprintf(sStmt,"SELECT a.ipolicy, b.itmp_policy, b.dply_begin, b.iofficer, "
	              "       b.iquota, b.icomm_obj, a.iroute, a.iroute_prop, a.icard, b.ileader  "
	              "  FROM policy a, ply_relation b "
	              " WHERE a.ipolicy = b.ipolicy "
	              "   AND a.ipolicy = b.icard "
	              "   AND a.icard = b.ipolicy "
	              "   AND b.ibig_comp = ' '"
	              "   AND b.dentry >= '%s' "
	              "   AND b.dentry <= '%s' "
	              "   AND a.ipolicy[1,3] matches '%s' "
	              "   AND b.iquota matches '%s' "
	              "   AND b.ileader matches '%s' "
	              "   AND b.ientry matches '%s' "
	              "   %s %s ORDER BY a.ipolicy;", qDentry_bgn, qDentry_end, qIpolicy3, qIquota, qIleader, qIentry, Condition1, Condition2);

	$PREPARE ca_card FROM $sStmt;
	$DECLARE no_outside_cur CURSOR FOR ca_card;
	$OPEN no_outside_cur;
	for(;;)
	{
		$FETCH no_outside_cur INTO $sIpolicy, $sItmp_policy, $sDply_bgn, 
		                           $sIofficer, $sIquota, $sIcomm_obj, $sIroute, 
		                           $sIroute_prop, $sIcard_tmp, $sIleader;
		if(SQLCODE == SQLNOTFOUND) break;
        
		strcpy(remark, "");
		/* �ˮ�(�@)�g��N���O�_���� */
		if( sIofficer[0] != 'W')
		{
			rc = cm_chk_policy("1", sIofficer, " ", " ", " ", " ", " ", " ");
			if( rc != M_CM_OK)
			{
				strcpy(remark, cm_get_errmsg(rc));
				$INSERT INTO cm_freeform_dtl VALUES($skpid,'C',$sIpolicy,' ',$sIcard_tmp,'0',' ',199,$sIofficer,$sIleader,' ',$remark,$userid,current); 
				continue;
			}
		}
		
		/* �ˮ�(�G)�~�Z���O�_���� */
		rc = cm_chk_policy("2", " ", " ", sIquota, " ", " ", " ", " ");
		if( rc != M_CM_OK)
		{
			strcpy(remark, cm_get_errmsg(rc));
			$INSERT INTO cm_freeform_dtl VALUES($skpid,'C',$sIpolicy,' ',$sIcard_tmp,'0',' ',199,$sIofficer,$sIleader,' ',$remark,$userid,current); 
			continue;
		}
		
		/* �ˮ�(�T)�I����H�O�_����X�� */
		rc = cm_chk_policy("4", " ", " ", " ", sIcomm_obj, " ", " ", " ");
		if( rc != M_CM_OK)
		{
			strcpy(remark, cm_get_errmsg(rc));
			$INSERT INTO cm_freeform_dtl VALUES($skpid,'C',$sIpolicy,' ',$sIcard_tmp,'0',' ',199,$sIofficer,$sIleader,' ',$remark,$userid,current); 
			continue;
		}
		
		/* �ˮ�(�|)�I����H���L�X���� */
		rc = cm_chk_policy("6", " ", " ", " ", sIcomm_obj, "C", " ", " ");
		if( rc != M_CM_OK)
		{
			strcpy(remark, cm_get_errmsg(rc));
			$INSERT INTO cm_freeform_dtl VALUES($skpid,'C',$sIpolicy,' ',$sIcard_tmp,'0',' ',199,$sIofficer,$sIleader,' ',$remark,$userid,current); 
			continue;
		}
		
		/* �ˮ�(��)�q���N���P�q���ۭq�~�ȥN���������Y�O�_���T */
		rc = cm_chk_policy("7", " ", " ", " ", " ", " ", sIroute, sIroute_prop);
		if( rc != M_CM_OK)
		{
			strcpy(remark, cm_get_errmsg(rc));
			$INSERT INTO cm_freeform_dtl VALUES($skpid,'C',$sIpolicy,' ',$sIcard_tmp,'0',' ',199,$sIofficer,$sIleader,' ',$remark,$userid,current); 
			continue;
		}
		
		/* �ˮ�(��)�O�_�s�b�@�γ������� */
		count_receive = count_pass = 0;
		strcpy(ftype_sp, "");
		$SELECT ftype_sp,fstatus, count(ftype_sp)
		   INTO $ftype_sp, $fstatus,$count_receive
		   FROM cm_pre_receive
		  WHERE iins_cat = 'C'
		    AND ipre_rcv = $sItmp_policy
		    AND iins_kind = '1'
		    AND ipre_end = ' '
		  GROUP BY ftype_sp,fstatus;
		
		if (count_receive > 0)
		{
			/* 1060106005_C1 �ץ����s�t�ΥX��@�~(�p�P�N�����榬�O�@�o�ɻݦP�ɨ����i�X��@�~) */
			if (fstatus == 90)
			{
				strcpy(remark, "�@�γ�����w�@�o");
				$INSERT INTO cm_freeform_dtl VALUES($skpid,'C',$sIpolicy,' ',$sIcard_tmp,'0',' ',199,$sIofficer,$sIleader,' ',$remark,$userid,current); 
				continue;
			}
			else
			{        	
				/* �O�����O=[PA] */
				strcpy(ftype_sp, trim(ftype_sp));
				if (strcmp(ftype_sp, "PA") == 0)
				{
					/* �P�_�O�_�w���O */
					$SELECT count(ipre_rcv) INTO $count_pass
					   FROM ao_prercv_pass
					  WHERE iins_cat  = 'C'
					    AND ipre_rcv  = $sItmp_policy
					    AND iins_kind = '1' 
					    AND ipre_end  = ' ';
				
					if (count_pass == 0)
					{
						/* �ư��O�����O=[PA]�����O*/
						printf("***** ipolicy[%s]�G[PA]�����O ***** \n", sIpolicy);
						$INSERT INTO cm_freeform_dtl VALUES($skpid,'C',$sIpolicy,' ',$sIcard_tmp,'0',' ',199,$sIofficer,$sIleader,' ','[PA]�����O ',$userid,current); 
						continue;
					}
				}
			}
		}
		else
		{
			strcpy(remark, cm_get_errmsg(M_CA_PLY_NOT_FOUND));
			$INSERT INTO cm_freeform_dtl VALUES($skpid,'C',$sIpolicy,' ',$sIcard_tmp,'0',' ',199,$sIofficer,$sIleader,' ',$remark,$userid,current); 
			continue;
		}
		
		/* �ˮ�(�C)�O�_�O�� (�t�Τ� > �ͮĤ�+�|�Ӥu�@��) */
		sToday = 0;
		sLdeffect4 = 0;
		strcpy(deffect4, "");
		strcpy(deffect4_edr, "");
		/* �ͮĤ�+ �|�Ӥu�@�� */
		jTmp = 0;
		for(iTmp=1;jTmp<=4;iTmp++)
		{
			$select 1 
			   from ca_holiday
			  where (date($sDply_bgn) + $iTmp) between holiday_bgn and holiday_end;
			
			if( SQLCODE == SQLNOTFOUND) jTmp++;
			printf("iTmp[%d,jTmp[%d]\n", iTmp, jTmp);
			if( jTmp == 4 ) break;
		}
		$select first 1 to_char(date($sDply_bgn) + $iTmp) into $deffect4 from ca_holiday;
		strcpy(deffect4_edr, cm_from_infdate_100(deffect4));
		sLdeffect4 = cm_ymd_cdate(deffect4_edr);
		sToday = cm_today( ); /* �t�Τ� */
		printf("***** Today[%ld], Deffect4[%ld]*****\n", sToday, sLdeffect4);
		/* �i�t�Τ� > �ͮĤ�+�|�Ӥu�@�ѡj(�O����)*/
		if (sToday > sLdeffect4)
		{
			strcpy(remark, "�O����");
			$INSERT INTO cm_freeform_dtl VALUES($skpid,'C',$sIpolicy,' ',$sIcard_tmp,'0',' ',199,$sIofficer,$sIleader,' ',$remark,$userid,current); 
			continue;
		}
		
		$INSERT INTO car203_tmp_policy VALUES($sIpolicy);
	}
	$CLOSE no_outside_cur;
	$FREE  no_outside_cur;

	return M_CM_OK;
	
errexit:
	sqlfatal();
	return SQLCODE;
	exit(FAIL);
}
/******************************************************************************/
long car203_freeform()
{
	char ch_amt01[40],ch_amt02[40],ch_amt03[40],ch_amt04[40],ch_amt05[40];
	int  rc=0;
	char stmp1[40];
	char *ilocation;
    char s_qcylinder_tail[4];
    char s_qcylinder[9];
    
	$WHENEVER SQLERROR GOTO errexit;
	{
		long *icolumn; /* ��l */
		icolumn = 1; 

		/* �򥻮榡�w�qH00 */
		{
			insert_freeform(&icolumn,"H00");

			/* ��B���L */
			insert_freeform(&icolumn,"0");

			/* �q�l�O�� */
			if (feply[0] == 'Y')
				insert_freeform(&icolumn,"Y");
			else 
				insert_freeform(&icolumn,"N");
			
			/* �L�q��������� */
			if(strncmp(icar_type,"35",2) == 0 && chk_35note[0] == 'Y')  
				insert_freeform(&icolumn,"1");
			else 
				insert_freeform(&icolumn,"0");
			
			/* �O�_�t���� */
			
			if (frelative > 0)  /* �P�@������A�ȥ��X��A�P�@�g��A�u�C�L�W�b�� */
				insert_freeform(&icolumn,"0");
			else                /* �D�W�z�θɦL�A�L���� */
				insert_freeform(&icolumn,"1");
			
			/* insert_freeform(&icolumn,"1"); */
			
			/* �ݥ��ˬd�X */
			insert_freeform(&icolumn,"Q");
		}

		/* �j���Ҥ��e */
		{
			insert_freeform(&icolumn,"CARD");
			
			/* �j���Ҹ��X */
			stmp1[0] = '\0';
			strcpy(stmp1,"17");
			strcat(stmp1,icard);
			insert_freeform(&icolumn,stmp1);
			
			/* �Q�O�I�H */
			insert_freeform(&icolumn,nassured);
	
			strcpy(dply_begin_100,cm_from_infdate_100(dply_begin));
			cm_split_ymd_100(dply_begin_100, dply_begin_yy, dply_begin_mm, dply_begin_dd);
			/* �O�I�����_(�~) */
			insert_freeform(&icolumn,dply_begin_yy);
	
			/* �O�I�����_(��) */
			insert_freeform(&icolumn,dply_begin_mm);
			
			/* �O�I�����_(��) */
			insert_freeform(&icolumn,dply_begin_dd);
			
			strcpy(dply_end_100,cm_from_infdate_100(dply_end));
			cm_split_ymd_100(dply_end_100, dply_end_yy, dply_end_mm, dply_end_dd);
			/* �O�I������(�~) */
			insert_freeform(&icolumn,dply_end_yy);
			
			/* �O�I������(��) */
			insert_freeform(&icolumn,dply_end_mm);
			
			/* �O�I������(��) */
			insert_freeform(&icolumn,dply_end_dd);
			
			/* �ӫO��� */
			sprintf(s_qperiod, "%d", qperiod);
			insert_freeform(&icolumn,s_qperiod);
			
			/* ���ئW�� */
			insert_freeform(&icolumn,ncar_abbr);
			
			/* ��l�o�Ӧ~�� */
			insert_freeform(&icolumn,iissue_ym);
			
			/* �P�Ӹ��X */
			insert_freeform(&icolumn,itag);
			
			/* �t�P���� */
			insert_freeform(&icolumn,nbrand_abbr);
			
			/* �Ʈ�q */
			sprintf(s_qcylinder, "%5.2f", qcylinder);
			strcpy(s_qcylinder,trim(s_qcylinder));
			/* �Ʈ�q���ƧP�_�A�Y�O .00 �h�ٲ������ */
			strcpy(s_qcylinder_tail,"");
            ilocation = strstr(s_qcylinder, ".");
            printf("�Ʈ�q�p��[%d]\n",ilocation-s_qcylinder);
            printf("�Ʈ�q�p��[%c%c%c]\n",s_qcylinder[ilocation-s_qcylinder],s_qcylinder[ilocation-s_qcylinder+1],s_qcylinder[ilocation-s_qcylinder+2]);
            sprintf(s_qcylinder_tail,"%c%c%c",s_qcylinder[ilocation-s_qcylinder],s_qcylinder[ilocation-s_qcylinder+1],s_qcylinder[ilocation-s_qcylinder+2]);
            printf("�Ʈ�q�p��[%s]\n",s_qcylinder_tail);
            if(strcmp(s_qcylinder_tail,".00")==0)
            {
				s_qcylinder[ilocation-s_qcylinder] = '\0';
			}
			insert_freeform(&icolumn,s_qcylinder);
			
			/* ���� */
			insert_freeform(&icolumn,iengine);
			
			/* �����ż� */
			insert_freeform(&icolumn,fcomp_class);

/* �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� */
/* �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� */	
/* �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� */

			/* ���޷|�帹1 */
			insert_freeform(&icolumn,"113.12.23");

			/* ���޷|�帹2 */
			insert_freeform(&icolumn,"1130151550");
			
/* �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� */
/* �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� */
/* �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� �ܭ��n�A���վ�@�w�n�� */
	
			/* �g��N�� */
			insert_freeform(&icolumn,Iofficer);
			
			/* �޲z�H�W�� */
			insert_freeform(&icolumn,Nleader);
			
			rtoday(&Today);
			strcpy(s_today,cm_cdate_str_100(Today));
			cm_split_ymd_100(s_today,tyy,tmm,tdd);
			/* �}�ߤ��(�~) */
			insert_freeform(&icolumn,tyy);
			
			/* �}�ߤ��(��) */
			insert_freeform(&icolumn,tmm);
			
			/* �}�ߤ��(��) */
			insert_freeform(&icolumn,tdd);
			
			/* �ݥ��ˬd�X */
			insert_freeform(&icolumn,"Q");
		}
		
		/* ���� */
		{
			insert_freeform(&icolumn,"RECEIPT");
			
			strncpy(site2,ipolicy,2);
			site2[2]='\0';
			
			npresident[0]= '\0';
			tax_area1[0] = '\0';
			tax_area2[0] = '\0';
	
			$SELECT npresident,nchi_abv
			   INTO $npresident,$tax_area
			   FROM branch
			WHERE ibranch = $site2;
			
			tax_area[4]='\0';
			strncpy(tax_area1,tax_area,2);
			tax_area1[2] = '\0';
			strcpy(tax_area2,tax_area+2);
			tax_area2[2] ='\0';
	    
		    /* �L����1 */
			insert_freeform(&icolumn,tax_area1);
			
			/* �L����2 */
			insert_freeform(&icolumn,tax_area2);
			
			/* �t�d�H */
			insert_freeform(&icolumn,npresident);
			
			/* ���� */
			insert_freeform(&icolumn,aassured);
			
			/* �O�O(�U */
			tmp_prem=mpremium/10000;
			other_prem=mpremium%10000;
			num_to_chinese(ch_amt,tmp_prem);     /* �N���ԧB�Ʀr �ন ����j�g�Ʀr */
			if (tmp_prem==0) strcpy(ch_amt,"�s");
			strcpy(ch_amt01, ch_amt);
			strcpy(ch_amt01, trim(ch_amt01));
			insert_freeform(&icolumn,ch_amt01);
	
			/* �O�O(�a */				
			tmp_prem=other_prem/1000;
			other_prem=other_prem%1000;
			num_to_chinese(ch_amt,tmp_prem);
			if (tmp_prem==0) strcpy(ch_amt,"�s");
			strcpy(ch_amt02, ch_amt);
			strcpy(ch_amt02, trim(ch_amt02));
			insert_freeform(&icolumn,ch_amt02);
	
			/* �O�O(�� */
			tmp_prem=other_prem/100;
			other_prem=other_prem%100;
			num_to_chinese(ch_amt,tmp_prem);
			if (tmp_prem==0) strcpy(ch_amt,"�s");
			strcpy(ch_amt03,ch_amt);
			strcpy(ch_amt03, trim(ch_amt03));
			insert_freeform(&icolumn,ch_amt03);
	
			/* �O�O(�B */
			tmp_prem=other_prem/10;
			other_prem=other_prem%10;
			num_to_chinese(ch_amt,tmp_prem);
			if (tmp_prem==0) strcpy(ch_amt,"�s");
			strcpy(ch_amt04,ch_amt);
			strcpy(ch_amt04,trim(ch_amt04));
			insert_freeform(&icolumn,ch_amt04);
	
			/* �O�O(�� */			
			num_to_chinese(ch_amt,other_prem);
			if (other_prem==0) strcpy(ch_amt,"�s");
			strcpy(ch_amt05,ch_amt);
			strcpy(ch_amt05,trim(ch_amt05));
			insert_freeform(&icolumn,ch_amt05);		
			
			/* ���z�ɶ� */
			printf("dcreate[%s] \n",dcreate);
			insert_freeform(&icolumn,dcreate);
			
			/* �ݥ��ˬd�X */
			insert_freeform(&icolumn,"Q");
		}
		
		strcpy(iassured,trim(iassured));
		strcpy(itag,trim(itag));
		/* QRCODE1 */
		{
			insert_freeform(&icolumn,"QRCODE1");
			strcpy(iassured,trim(iassured));
			sprintf(url1,"https://www.tmnewa.com.tw/b2c_v2/frontstage/certificatequery.aspx?OWNER_ID=%s\&CAR_NO=%s\&TYPE=0",iassured,itag);
			insert_freeform(&icolumn,url1);
			
			/* �ݥ��ˬd�X */
			insert_freeform(&icolumn,"Q");
		}
		
		/* QRCODE2 */
		{
			insert_freeform(&icolumn,"QRCODE2");
			
			sprintf(url2,"https://www.tmnewa.com.tw/b2c_v2/frontstage/certificatequery.aspx?OWNER_ID=%s\&CAR_NO=%s\&TYPE=2",iassured,itag);
			insert_freeform(&icolumn,url2);
			
			/* �ݥ��ˬd�X */
			insert_freeform(&icolumn,"Q");
		}
		
		/* QRCODE3 */
		{
			insert_freeform(&icolumn,"QRCODE3");
			
			/* 1130607001_C01_�R���j���I���ڷL�q��������� */
			/* �ͮĤ�>=11/30�A���[�K������ڡA�Ϥ����� */
			if(strncmp(icar_type,"35",2) == 0 && chk_35note[0] == 'Y')  
				strcpy(url3,"https://ecard.cali.org.tw/PPCP_QRY/file/EMotorClause.pdf");
			else 
				strcpy(url3," ");
	
			insert_freeform(&icolumn,url3);
			
			/* �ݥ��ˬd�X */
			insert_freeform(&icolumn,"Q");
		}
		
		/* ���� */
		insert_freeform(&icolumn,"END");
	}
	
	/*rc = ca_free_data(icard);*/
	
	return M_CM_OK;
	
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

/******************************************************************************/
long car203_temp_table()
{
	$WHENEVER SQLERROR GOTO errexit;

	$create temp table car203_tmp_policy(
		ipolicy   char(20)   
	)with no log;
	
	$create temp table car203_tmp_card(
		icard    char(20)   
	)with no log;
	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;     
}

/******************************************************************************/
long insert_freeform(iline,ncontent)
long  *iline;
$char ncontent[256];
{
	$long iline2;
	$char ncontent_tmp[256];
	iline2 = *iline;
	$WHENEVER SQLERROR GOTO errexit;
	printf("skpid=[%s],ipolicy=[%s],iline=[%d],ncontent=[%s]\n",skpid,ipolicy,iline2,ncontent);
	strcpy(ncontent_tmp,rtrim(ncontent));
	if (strcmp(ncontent_tmp,"")==0)
	{
		$INSERT INTO ca_freeform (kpid,   inumber, iline,  ncontent)
		                  VALUES ($skpid ,$icard  ,$iline2, ' ');
	}
	else 
	{
		$INSERT INTO ca_freeform (kpid,   inumber, iline,  ncontent)
		                  VALUES ($skpid ,$icard  ,$iline2,$ncontent);
	}
	
	iline2++;
	*iline = iline2;
errexit:
    return SQLCODE;
}

/******************************************************************************/
/* ���stxt.���ե� */
long ca_free_data(sIcard)
char *sIcard;
{
	$char iline;
	$char stmt_free[1024],s_icard[21],ncontent[256];
	FILE  *fptr, *fptr_err;
	int   count_db,k,i; 
	$char DBName[05];
	$char msgbuf[128];
	DBinfo *list;
	char    sApHome[30];
	int rtncode,rc;
	char    filename[30];
	FILE    *fp;
	char  file_catalog[200];
	$char filename1[200];
	char userid[12],errmsg2[300],Message[300];
	char  prtstr[500];

	strcpy(s_icard,sIcard);
	
	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
	 	return rc;
	}
	
	filename[0]    = '\0';
	file_catalog[0] = '\0';
	sprintf(filename,"%s/rptftp/", sApHome);
	sprintf(filename1,"car203a_%s_%s.txt",skpid,s_icard);
	strcpy(file_catalog, trim(filename));
	strcat(file_catalog, trim(filename1));
	printf("file_catalog[%s]\n",file_catalog);
	
	$whenever sqlerror goto errexitM;

	if ((fptr=fopen(file_catalog,"w")) == NULL)
	{
		return M_CM_OPEN_FILE_FAIL;
	}

	sprintf(stmt_free,"SELECT ncontent FROM ca_freeform WHERE inumber = '%s' and kpid = '%s' ORDER BY iline,rowid",s_icard,skpid);

	printf("stmt_free[%s] \n",stmt_free);
	$PREPARE ca_freeform_P FROM $stmt_free;
	$DECLARE ca_freeform_D CURSOR FOR ca_freeform_P;
	$OPEN ca_freeform_D;
	while (1)
	{
		$FETCH ca_freeform_D INTO $ncontent;
		if (SQLCODE == SQLNOTFOUND) break;

		strcpy(ncontent,rtrim(ncontent));
		printf("ncontent[%s] \n",ncontent);
		if (strcmp(ncontent,"C")==0 || strcmp(ncontent,"Q")==0)
		{
			fprintf(fptr,"%s\n",ncontent);
		}
		else if (strcmp(ncontent,"END")==0)
		{
			fprintf(fptr,"%s",ncontent);
		}
		else
		{
			fprintf(fptr,"%s",ncontent);
		}
	}
	$CLOSE ca_freeform_D;
	$FREE ca_freeform_D;
	
	fclose(fptr);
	
	printf("END\n");
	return M_CM_OK;

errexitM:
	printf("usrid=%s SOLCODE=%d sqlca.sqlerrm=%s\n",userid,SQLCODE,sqlca.sqlerrm);
	sprintf(errmsg2,"userid=%s SOLCODE=%d sqlca.sqlerrm=%s",userid,SQLCODE,sqlca.sqlerrm);
	fprintf(fptr_err,"%s\n",errmsg);
	return SQLCODE;	
}