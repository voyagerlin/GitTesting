/**********************************************************************/
/*   ��O�j���I���Ӫ�                      			      */
/*   PROGRAM : ca603q01s.ec                			      */
/*   DATE    : 88.07.26                    			      */
/**********************************************************************/
/*                             MODIFICATION LOG                        *
 *                                                                     *
 *   DATE         SE                         DESCRIPTION               *
 * --------  -------------  ----------------------------------------   *
 * 20050927  Jessie         �����g�P��--�W�[�ﶵ                       *
 *                          Checked for ����100�~�M��                  *
 * 20110823  Jessie         �g�P/�@��אּ�q���O;�W�[�H�ʮM�L           *
 *                                                                     *
 **********************************************************************/

#include <stdio.h>
#include <unistd.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"
char  ireport1[1],ireport2[1];
$char sIroute[21];
$char sale[4],icard[21],nassured[101],iofficer[11],ileader[11],iquota[7];
$char ipolicy[21],iengine[CA_ENGINE_NUM],dpolicy[11],dply_bgn[11],nassured[101];
$char ixxcard[21],iroute[21],icar_type[3],fsex[2],itag[CA_TAG_NUM];
$char zip[CA_ZIP],aassured[91];
$char dbgn1[11], dend1[11],dbgn2[11],dend2[11];
$double premium = 0;
char  MsgCode[100];

$char DBName[05];
char  outputf[N_FILE+1];
$char userid[11];

int	count_db;
DBinfo	*list;

FILE	*fp;
int	flen;
char	sApHome[31];
char	filename[51];
$char   stmt_tmp[1024];
/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;
   batchinit();
   strcpy(DBName,  isNULLstr(argv[1]));
   strcpy(userid,  isNULLstr(argv[2]));
   strcpy(dbgn2,   isNULLstr(argv[3]));
   strcpy(dend2,   isNULLstr(argv[4]));
   strcpy(sIroute, isNULLstr(argv[5]));
   strcpy(ireport1,isNULLstr(argv[6]));
   strcpy(ireport2,isNULLstr(argv[7]));
   strcpy(outputf, isNULLstr(argv[8]));

   strcpy(dbgn1, cm_to_infdate(dbgn2));
   strcpy(dend1, cm_to_infdate(dend2));

   rc = car603_get_db();
   if ( rc != M_CM_OK)
	return rc;

   rc = car603_privilege();
   if ( rc != M_CM_OK)
        return rc;

   rc = car603_accumulate();
   if ( rc != M_CM_OK)  {
        EWRITE(userid, rc, MsgCode);
        return rc;
   }

   strcpy(MsgCode," ");
   if (ireport1[0]=='1') {
      rc = car603_body_dtl();
      if (rc != M_CM_OK)
          return rc;
   }
   if (ireport2[0]=='1') {
      rc = car603_body_tot();
      if (rc != M_CM_OK)
          return rc;
   }
   if (ireport1[0]=='2') {
      rc = car603_body_envelop();
      if (rc != M_CM_OK)
          return rc;
   }
}
/*--------------------------------------------------------------------*/
long car603_get_db()
{
    if (db_select(DBName) == FALSE) {
	EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
	return M_CM_DB_NOTOPEN;
    }

    if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
    {
	EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
	return M_CM_NOT_DBLIST;
    }

    return M_CM_OK;
}
/*--------------------------------------------------------------------*/
long car603_accumulate()
{
  int    k;
 $char   stmt[2048];
 $char   irelative_ply[21];
 

   $WHENEVER SQLERROR GOTO errexit;

   sprintf_s(stmt_tmp, sizeof stmt_tmp,"CREATE TEMP TABLE car603  "
    "(  "
      "ipolicy           char(20) primary key,  "
      "iengine           char(%d),  "
      "sale              char(03),  "
      "dpolicy           date,  "
      "icard             char(20),  "
      "nassured          char(120),  "
      "dply_begin        date,  "
      "premium           decimal(12,0),  "
      "iofficer          char(10),  "
      "ileader           char(10),  "
      "iquota            char(06),  "
      "icar_type	char(2),  "
      "iroute		char(20),  "
      "zip		char(%d),  "
      "aassured		char(90),  "
      "fsex		char(1),  "
      "itag		char(%d)  "
    ") WITH NO LOG;",CA_ENGINE_NUM-1,CA_ZIP-1,CA_TAG_NUM-1);
     $PREPARE stmp FROM $stmt_tmp;
     $EXECUTE stmp;
     
   $create index car603_ix on car603
      (iengine,nassured);
   $create unique index car603_ix_1 on car603
      (icard);

   for(k=0;k<count_db;k++) {
      sprintf_s(stmt, sizeof stmt,
             "select a.iofficer[1,3],a.dpolicy,a.icard,b.nassured,  "
                     "a.dply_begin,a.mlia_prem + a.mdmg_prem prem,  "
                     "a.iofficer,a.ileader,a.iquota,a.ipolicy,b.iengine,  "
                     "nvl(a.irelative_ply,' '), date('%s') + 90,b.iroute,  "
                     "a.icar_type,b.aassured_zip,b.aassured,b.fsex,b.itag  "
                "from %s:ply_relation a,%s:policy b  "
                "where a.dpolicy >= ?  "
                 "and a.dpolicy <= ?  "
                 "and a.fcard_class = '1'  "
                 "and a.ipolicy = b.ipolicy  "
                 "and a.dply_close is not null  "
                 "and a.fedr_class != '1'  "
		 "and b.iroute matches ?",dend1,
                 list[k].dbname,list[k].dbname,dbgn1,dend1);

      printf("%s\n",stmt);
      $PREPARE pre_cur2 FROM $stmt;
      $DECLARE cur2 CURSOR FOR pre_cur2;
      $OPEN cur2 USING $dbgn1, $dend1, $sIroute;

      while(1) {
        $fetch cur2 into
               $sale,$dpolicy,$icard,$nassured,
               $dply_bgn,$premium,$iofficer,$ileader,
               $iquota,$ipolicy,$iengine,$irelative_ply,$dend2,
               $iroute,$icar_type,$zip,$aassured,$fsex,$itag;
        if(SQLCODE == SQLNOTFOUND) break;
	/****** 20110823 by Jessie
             ���t����
        if (strncmp(icar_type,"01",2)==0 || strncmp(icar_type,"02",2)==0 ||
            strncmp(icar_type,"32",2)==0 || strncmp(icar_type,"34",2)==0 )
            continue;

        if (itype[0]=='1') {       ���ӥ�
           if (imgr[0]!='1') continue;
        }
        else if (itype[0]=='2') {  �@���
           if (imgr[0]!='2') continue;
        } 
	******/

        if (strlen(trim(irelative_ply))!=0)
            continue;

        $INSERT INTO car603
             ( ipolicy,iengine,sale,dpolicy,icard,nassured,dply_begin,
               premium,iofficer,ileader,iquota,icar_type,iroute,zip,
	       aassured,fsex,itag )
        values($ipolicy,$iengine,$sale,$dpolicy,$icard,$nassured,$dply_bgn,
               $premium,$iofficer,$ileader,$iquota,$icar_type,
	       $iroute,$zip,$aassured,$fsex,$itag );
        printf("values in car603[%s][%s][%d][%s]\n",
                ipolicy,dpolicy,premium,iofficer);
    }
    $CLOSE cur2;
    $FREE  cur2;
    }
    
    if (ireport1[0]!='2') { /* �L�s�H��,���ݦҼ{���� */
    for(k=0;k<count_db;k++) {
    	stmt[0]='\0';
    	sprintf_s(stmt, sizeof stmt,
            "select a.irelative_ply, b.iengine, b.nassured, b.ixxcard  "
               "from %s:ply_relation a,%s:policy b  "
              "where a.dpolicy >= '%s'  "
                "and a.dpolicy <= '%s'  "
                "and a.fcard_class = '2'  "
                "and a.fedr_class != '1'  "
                "and a.ipolicy = b.ipolicy ",
             list[k].dbname,list[k].dbname,dbgn1,dend2);
    	printf("%s\n",stmt);
    	$PREPARE pre_cur3 FROM $stmt;
    	$DECLARE cur3 cursor for pre_cur3;
    	$open cur3;
    	while(1) {
       	$fetch cur3 into $irelative_ply, $iengine,$nassured,$ixxcard;
       	if (SQLCODE==SQLNOTFOUND) break;
       	if (strlen(trim(irelative_ply))!=0)
           continue;
       	printf("iengine[%s]ixxcard[%s]\n",iengine,ixxcard);
       	$delete from car603
          where iengine = $iengine
            and nassured = $nassured;
       	$delete from car603
          where icard = $ixxcard;
       	if (strncmp(ixxcard,"17",2)==0) {
          strcpy(ixxcard,substring(ixxcard,3,21));
          printf("ixxcard[%s]\n",ixxcard);
          $delete from car603
            where icard = $ixxcard;
       	}
    	}
   }
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car603_body_dtl()
{
 char  sfilename[51],stitle[1024],stmt[1024];
 int   rc;

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,rtrim(sIroute));
    strcat(sfilename,"��O�j���I���Ӫ�");
    strcpy(stitle,"�{���N��:CAR603\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t\tñ����:");
    strcat(stitle,dbgn1);
    strcat(stitle,"��");
    strcat(stitle,dend1);
    strcat(stitle,"\t\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(sfilename,"[CAR603]");

    strcat(stitle,"\t���N��\t���W��\tñ����\t�j���Ҹ�\t�O�渹�X\t");
    strcat(stitle,"�Q�O�I�H\t�_�O��\t�O�O\t�g��N��\t�޲z�H�N��\t");
    strcat(stitle,"����\t�q���N��\t�q���W��\t");

    strcpy(stmt,"select iquota,nbranch,dpolicy,icard,ipolicy,nassured,  "
                        "dply_begin,premium,iofficer,ileader,icar_type,iroute,  "
		        "(select nroute from cm_route where iroute = a.iroute)  "
                   "from car603 a,sa_branch_type b  "
                  "where iquota[1,4]||'00' = ibranch order by 1,3,4");

    if (ireport2[0]=='1')
    	rc = unload_file(outputf,"A",sfilename,stitle,stmt);
    else
    	rc = unload_file(outputf," ",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
        sprintf_s(MsgCode, sizeof MsgCode," %s �ɮ׵L�k���� ",sfilename);
        return rc;
    }

    return M_CM_OK;
   
errexit:
   sqlfatal();
   return SQLCODE; 
}
/*--------------------------------------------------------------------*/
long car603_body_tot()
{
 char  sfilename[51],stitle[1024],stmt[1024];
 int   rc;

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,rtrim(sIroute));
    strcat(sfilename,"��O�j���I�έp��");
    strcpy(stitle,"�{���N��:CAR603\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\tñ����:");
    strcat(stitle,dbgn1);
    strcat(stitle,"��");
    strcat(stitle,dend1);
    strcat(stitle,"\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(sfilename,"[CAR603]");
    strcat(stitle,"\t���N��\t���W��\t���\t�O�O\t�T�����\t�T���O�O\t");

    strcpy(stmt,"select iquota[1,4],nbranch,count(*),sum(premium),  "
			"(select count(*) from car603 where iquota[1,4]  "
			"= a.iquota[1,4] and icar_type not in (  "
			"'01','02','32','34','35')),  "
			"(select sum(premium) from car603 where iquota[1,4]  "
			"= a.iquota[1,4] and icar_type not in (  "
			"'01','02','32','34','35'))  "
                    "from car603 a,sa_branch_type b  "
                    "where iquota[1,4]||'00' = ibranch  "
                    "group by 1,2,5,6 order by 1");
    if (ireport1[0]=='1')
    	rc = unload_file(outputf,"B",sfilename,stitle,stmt);
    else
    	rc = unload_file(outputf," ",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
          sprintf_s(MsgCode, sizeof MsgCode," %s �ɮ׵L�k���� ",sfilename);
          return rc;
    }

    return M_CM_OK;
   
errexit:
   sqlfatal();
   return SQLCODE; 
}

/*--------------------------------------------------------------------*/
long car603_body_envelop()
{
 char  sfilename[51],stitle[1024],stmt[1024];
 int   rc,cnt;
$char  nsex[5];

    $WHENEVER SQLERROR GOTO errexit;

    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(MsgCode,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,MsgCode);
        return rc;
    }

    sprintf_s(filename, sizeof filename,"%s/batchfile/%s.tx",sApHome,outputf);
    fp=fopen(filename,"w");
    strcpy(stitle,"�j���Ҹ�\t���P\t�Q�O�I�H\t�ٿ�\t�l���ϸ�\t�a�}\n");
    fprintf(fp,stitle);

    $declare cur_env cursor for
      select icard,itag,nassured,decode(fsex,'1','����',
	     '2','�p�j',' '),zip,aassured
        from car603
       order by 1;
    $open cur_env;

    cnt=0;
    while(1) {
	$fetch cur_env
	  into $icard,$itag,$nassured,$nsex,$zip,$aassured;
	if (SQLCODE==SQLNOTFOUND) break;
	cnt++;
	strcpy(icard,rtrim(icard));
	strcpy(itag,rtrim(itag));
	strcpy(nassured,rtrim(nassured));
	strcpy(zip,rtrim(zip));
	strcpy(aassured,rtrim(aassured));
	fprintf(fp,"%s\t%s\t%s\t%s\t%s\t%s\n",
		icard,itag,nassured,nsex,zip,aassured);
    }

    fclose(fp);

    if ((rc=save_form_info(F_FREE,"CA", 603, userid, " ", cnt,
                outputf))<0)
            EWRITE(userid, rc, "save_form_info failed");

    return M_CM_OK;
   
errexit:
   sqlfatal();
   return SQLCODE; 
}
/*--------------------------------------------------------------------*/
long car603_privilege()
{
$int    flevel,cnt;
$char   falldb[2],imain[21];
char	*ptr;

    $whenever sqlerror goto errexit;

    $select falldb
       into $falldb
       from privilege
      where iemp = $userid
        and ipgid = 'car603';

    /* �����ٸ�Ʈw�v����,�L���ˮֳq���޲z�H */
    if (falldb[0]=='Y')
        return M_CM_OK;

    ptr=strstr(sIroute,"*");
    if (ptr) {
    	strcpy(imain,substring(sIroute,1,ptr-sIroute));
printf("ptr[%d]imain[%s]\n",ptr-sIroute,imain);
    	$select count(*)
	   into $cnt
       	   from cm_route
      	  where iroute = $imain
	    and fmain = 'Y';
    	if (cnt == 0) {
            strcpy(MsgCode,"�D�D�q���N���A���i��J*");
            EWRITE(userid,20,MsgCode);
            return 20;
	}
    }

    $select count(*)
       into $cnt
       from cm_route
      where iroute matches $sIroute
        and ileader = $userid;
    if (cnt==0) {
        strcpy(MsgCode,"�z�D�q���޲z�H�A���i���榹�q�����");
        EWRITE(userid,10,MsgCode);
        return 10;
    }

    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
