/**********************************************************************/
/*   program id   : ca917q01s.ec                                      */
/*   date written : 2005/10/27                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   temp table   : car917              io                            */
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"

/*--------------------------------------------------------------------*/
$char dbgn1[11], dend1[11], dbgn2[11], dend2[11], iins_type[7];
$char Ipolicy[21],Nassured[121],Icar_type[3];
$char Iofficer[11],Ileader[11],Ibig_office[10];
$long Dpolicy,Dply_begin,Dply_end;
$long mdmg_prem,mlia_prem,mdmg_disc,mlia_disc;
$double pdmg_disc,plia_disc;
$char Nbranch[40],Iquota[10],icode[11];
char  dtype[1],tit_dtype[8],ctype[1],paycheck[1];
$char iissue_ym[7],ipro_year[5],iengine[21],ibrand[9],nbrand[31];
$char itag[9],itel[21];
$char nofficer[11],ibig_comp[2];
char  fymark[90][2];
char  msgbuf[1000];
$char iassured[13];
$char iassured_ext[3];
$char tphone_con[21],imovephone[21];
$char Astmp[256];

$char iresource[2];
$char ileader[11],nname[11];
$char fedr_class[11],dendorse[11];
$char fassured[2];
$char ncode[30],F_ncode[30];
$char DBName[05],DBData[05];
char  outputf[N_FILE+1];
$char userid[11];
$char ibig_sales[11],s_name[21];
$char iins_cnt[3];
$char stmt[2048];
int   cnt;

/* AOI ao_chk_charge */
$int  ibatch_no;
char  tmp_ibatch_no[3];
char  ao_policy1[POLICY_NUM_1], ao_policy2[CA_TARGET_NUM];
char  a0result[3], a0comment[31], a0date1[9], a0date2[9];
$char ao_note[2];
$char falldb[2];

/* for �q���ϥ� */
$char iroute[21];

DBinfo  *list;
int     count_db , k;


/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;
   int i,k,n;

   batchinit();
   strcpy(DBName,   isNULLstr(argv[1]));
   strcpy(userid,   isNULLstr(argv[2]));
   strcpy(dbgn2 ,   isNULLstr(argv[3]));
   strcpy(dend2 ,   isNULLstr(argv[4]));
   strcpy(outputf , isNULLstr(argv[5]));

   strcpy(dbgn1, cm_to_infdate(dbgn2));
   strcpy(dend1, cm_to_infdate(dend2));

   printf("DBName[%s]\n",DBName);

   rc = car917_get_db();
   if (rc != M_CM_OK)
       return rc;

   rc = car917_accumulate();
   if (rc != M_CM_OK)
       return rc;

   rc = car917_build();
   if (rc != M_CM_OK)
       return rc;
}

/*--------------------------------------------------------------------*/
long car917_get_db()
{
    /* ��db_select�O��Ū���v�� */
    if (db_select(DBName) == FALSE)
    {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
    }

    if ((list=get_db_list(&count_db,DBName)) == (char*)0)
    {
       EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
       return M_CM_NOT_DBLIST;
    }

    return M_CM_OK;
}
/*--------------------------------------------------------------------*/
long car917_build()
{
 char  sfilename[41],stitle[1024],stmt[81];
 int rc;

    $whenever sqlerror goto errexit;

    strcpy(sfilename,"���O�ݰl�^���Ӫ�");
    strcpy(stitle,"�߮׸��X\t�J�p���\t���`�HID\t���`�H�m�W\t�z�ߪ��B\t�ߥI���O���B\n");

       strcat(stitle,"\t�J�p���:");
       strcat(stitle,dbgn1);
       strcat(stitle,"��");
       strcat(stitle,dend1);
       strcat(stitle,"\t\t\t�s�����:");
       strcat(stitle,cm_get_sysd());
       strcat(stitle,"\t");

    strcpy(stmt,"select * from car917 order by iclaim ");
    rc = unload_file(outputf," ",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
        sprintf_s(msgbuf,1000," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car917_accumulate()
{
$char stmpA[2048],stmpB[100],str[5],stmpC[512],stmpD[100];
int   rc,ply_cnt;
$int  flag,i,j,k,yy,kk;

    $whenever sqlerror goto errexit;

    if (db_select(DBName) == FALSE)
    {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
    }

    rc = car917_create_temp();
    if (rc != M_CM_OK)
       return rc;

    for(k=0;k<count_db;k++)
    {
       $delete from car917_vic where 0 = 0;
     	 /* ���ư� settlement.istl_flag = '7' ����� modify by sylvia 108.07.12 (1080710004_SC1)*/
     	 /* ���ư� settlement.istl_flag = 'A' ����� modify by sylvia 110.11.19 (1101008002_SC1) */
       /* sprintf_s(stmt,2048,
        " insert into car917_vic                        \
          select iclaim,ivictim,sum(decode(fstl,'2',(-1) * (mins_stl+mstl_health), (mins_stl+mstl_health))) as mstl  \
            from %s:ca_stl_victim                       \
           where iclaim in (select iclaim               \
                              from %s:ca_stl_victim     \
                             where dgroup between '%s' and '%s' and iins_item[1] = 'A')  \
             and iins_item[1] = 'A'                     \
             and dgroup is not null                     \
           group by iclaim,ivictim                      \
           having sum(decode(fstl,'2',(-1) * (mins_stl+mstl_health), (mins_stl+mstl_health))) > 200000   \
           ",list[k].dbname,list[k].dbname,dbgn1,dend1); */

       sprintf_s(stmt,2048,
        " insert into car917_vic                        \
          select a.iclaim, a.ivictim,sum(decode(a.fstl,'2',(-1) * (a.mins_stl+a.mstl_health), (a.mins_stl+a.mstl_health))) as mstl  \
            from %s:ca_stl_victim a , %s:settlement b   \
           where a.iclaim = b.iclaim and a.fstl = b.fstl and a.iclose_type = b.iclose_type \
             and a.iclaim in (select iclaim             \
                              from %s:ca_stl_victim     \
                             where dgroup between '%s' and '%s' and iins_item[1] = 'A')  \
             and a.iins_item[1] = 'A'                   \
             and a.dgroup is not null                   \
             and b.istl_flag not in ('7','A')           \
           group by a.iclaim, a.ivictim                 \
           having sum(decode(a.fstl,'2',(-1) * (a.mins_stl+a.mstl_health), (a.mins_stl+a.mstl_health))) > 200000   \
           ",list[k].dbname,list[k].dbname,list[k].dbname,dbgn1,dend1);

       printf("stmt[%s]\n",stmt);
       $prepare vic_id1 from $stmt;
       $execute vic_id1;

       sprintf_s(stmt,2048,
        " insert into car917                                                       \
          select a.iclaim, max(a.dgroup), a.ivictim,                               \
                 (select max(b.nchi_full) as nchi_full from cu_customer b where a.ivictim = b.ifpce_id) ,   \
                 sum(decode(a.fstl,'2',(-1)*(a.mins_stl),a.mins_stl)) as mstl,     \
                 sum(decode(a.fstl,'2',(-1)*(a.mstl_health),a.mstl_health)) as mstl_health \
            from %s:ca_stl_victim a,car917_vic c, %s:settlement b               \
           where a.iclaim  = c.iclaim  \
             and a.ivictim = c.ivictim \
             and a.iins_item[1] = 'A'  \
             and a.dgroup is not null  \
             and a.iclaim = b.iclaim and a.fstl = b.fstl and a.iclose_type = b.iclose_type \
             and b.istl_flag not in ('7','A')       \
           group by 1,3,4 ",list[k].dbname,list[k].dbname);

       printf("stmt[%s]\n",stmt);
       $prepare vic_id2 from $stmt;
       $execute vic_id2;
    }

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car917_create_temp()
{
    $whenever sqlerror goto errexit;

    $create temp table car917_vic
     (
        iclaim        char(20),
        ivictim       char(20),
        mstl          integer
     )with no log;

    $create index car917_vic_ix_1 on car917_vic(iclaim,ivictim);

    $create temp table car917
     (
        iclaim        char(20),
        dgroup        date,
        ivictim       char(20),
        nvictim       char(20),
        mstl          integer,
        mstl_health   integer
     )with no log;

    $create index car917_ix_1 on car917(iclaim);

    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
