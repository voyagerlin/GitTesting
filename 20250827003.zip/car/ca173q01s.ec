/************************************************/
/*                                              */
/*   PROGRAM : car173q01s.ec			*/
/*   Author  : 061476   			*/
/*   Date    : 2021/05/14			*/
/*   Name    : ���N�I����O�q���O���ƺ��@     */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <time.h>
#include <math.h>
#include "api_xsrv.h"
$include datetime.h;
#include "carmsgs.h"
#include "safeclib.h"

/*--------------------------------------------------------------------*/
$char   userid[11];
char    msgbuf[1000], sApHome[30];
$char   DBName[5];
char    outputf[N_FILE+1] ;
DBinfo  *list;
int     count_db;
$loc_t 	ctxt;

$char   ftype[2], dyy[4], dmm[3], dsned[11];
$long   mail_date;
/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
	int rc;
	batchinit();
	strcpy(DBName,   isNULLstr(argv[1]));
	strcpy(userid,   isNULLstr(argv[2]));
	strcpy(ftype,    isNULLstr(argv[3]));          /* P�G���ӳ��� M�G�H�omail */
	strcpy(dyy,      isNULLstr(argv[4]));          /* ��O�~ */
	strcpy(dmm,      isNULLstr(argv[5]));          /* ��O�� */
	if(strcmp(ftype,"P") == 0){
		strcpy(outputf,  isNULLstr(argv[6]));
	}else if(strcmp(ftype,"M") == 0){
		strcpy(dsned,    isNULLstr(argv[6]));  /* �H�o�� */
		strcpy(outputf,  isNULLstr(argv[7]));
		
		mail_date = cm_ymd_cdate(dsned); 		
	}
	
	rc = car173_get_db();
	if (rc != M_CM_OK)
	    return rc;
	
	rc = car173_get_data();
	if (rc != M_CM_OK)
	    return rc;
		
	if(strcmp(ftype,"P") == 0){
		/* �R���W�L�@�~��� */		
		rc=ca173_delete_data();
		if (rc != M_CM_OK)
		    return rc;
		
		rc=ca173_build1();
		if (rc != M_CM_OK)
		    return rc;    
	}else if(strcmp(ftype,"M") == 0){
		rc=ca173_build2();
		if (rc != M_CM_OK)
		    return rc;
	}

    return rc;
}

/*--------------------------------------------------------------------*/
long car173_get_db()
{
	int    rc;
	
	if (db_select(DBName) == False) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	
	if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
	{
		EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
		return M_CM_NOT_DBLIST;
	}
	
	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
		return rc;
	}
	
	return M_CM_OK;
}
/*--------------------------------------------------------------------*/
long car173_get_data()
{
	int   rc;
	char  sfilename[256], stitle[2048], stmt1[6000];
	$char stmt[2048];
	$int  iplyyear, iplymonth;
	$char sdate1[11], sdate2[11];
	
	$whenever sqlerror goto errexit;
	
	$create temp table car173_tmp1
	(
	    ileader         char(10),
	    nleader         char(10),
	    iofficer        char(10),
	    nofficer        char(10),
	    iroute          varchar(20),
	    nroute          varchar(40),
	    ipolicy         char(20),
	    itag            char(12),
	    nassured        varchar(120),
	    icar_type       char(2),   
	    dply_begin      date,       
	    nremark         varchar(255),
	    frenew          char(1),    
	    frenew_status   char(1),
	    iquota          char(6),
	    nquota          char(40),
	    iupdate         char(6),
	    dupdate         char(20)
 	)with no log;
	
	strcpy(dyy,trim(dyy));
	iplyyear = atoi(dyy);
	iplyyear += 1911;
	iplymonth = atoi(dmm);
	
	/* �̰_���~���_����� */
	$select first 1 MDY($iplymonth,'01',$iplyyear),add_months(MDY($iplymonth,'01',$iplyyear),1)-1
	   into $sdate1, $sdate2
	   from car_code; 
	
	sprintf_s(stmt, sizeof stmt, " INSERT INTO car173_tmp1 \n"
                       " SELECT a.ileader, e.nname, a.iofficer, b.nname, a.iroute, c.nroute, a.ipolicy,        \n"
                       "        a.itag, a.nassured, a.icar_type, a.dply_begin, a.nremark_reject,               \n"
                       "        case when a.freason_reject in ('P','7','9','B','Y','Z') then 'N' else 'Y' end, \n"
                       "        nvl(d.frenew_status,''), a.iquota, f.nbranch, case when d.dupdate is null then d.icreate else d.iupdate end , \n"
                       "        case when d.dupdate is null then to_char(d.dcreate,'%%Y-%%m-%%d %%H:%%M:%%S') else to_char(d.dupdate,'%%Y-%%m-%%d %%H:%%M:%%S') end \n"
                       "   FROM policy_302 a, officer b, cm_route c, officer e, sa_branch_type f,              \n"   
                       "        outer ca_no_renew d    \n"
                       "  WHERE a.iofficer = b.iofficer AND a.iroute = c.iroute   \n"
                       "    AND a.ipolicy = d.ipolicy AND a.ileader = e.iofficer  \n"
                       "    AND a.iquota = f.ibranch AND a.freason_reject <> ''   \n"
                       "    AND a.iofficer[1] not in ('N','W')                    \n"
                       "    AND fcard_class = '2' AND a.dply_begin between '%s' and '%s'  \n", sdate1, sdate2 );       
        $PREPARE insert_tmp1 FROM $stmt;
 	$EXECUTE insert_tmp1;
 	
 	sprintf_s(stmt, sizeof stmt, " INSERT INTO car173_tmp1 \n"
                       " SELECT distinct a.ileader, a.nleader, a.iofficer, a.nofficer, a.iroute,   \n"
                       "�@�@�@�@a.nroute, a.ipolicy,�@a.itag, a.nassured, a.icar_type, a.dply_end, \n"
                       "        a.remark_reject, a.frenew, nvl(b.frenew_status,''), c.iquota,    �@\n"
                       "        (SELECT nbranch FROM sa_branch_type WHERE c.iquota = ibranch), case when b.dupdate is null then b.icreate else b.iupdate end , \n"
                       "        case when b.dupdate is null then to_char(b.dcreate,'%%Y-%%m-%%d %%H:%%M:%%S') else to_char(b.dupdate,'%%Y-%%m-%%d %%H:%%M:%%S') end      \n"
                       "   FROM sysdb:car_renew_msg a, OUTER ca_no_renew b, policy_302f c    \n"
                       "  WHERE a.ipolicy = b.ipolicy AND a.ipolicy = c.ipolicy              \n"
                       "    AND a.iofficer[1] not in ('N','W')                               \n"
                       "    AND a.err_no in ('E40','E56','E57') AND a.dply_end between '%s' and '%s'  \n", sdate1, sdate2 );       
        $PREPARE insert_tmp2 FROM $stmt;
 	$EXECUTE insert_tmp2;
	
	return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long ca173_build1()
{
	int   rc;
	char  sfilename[256], stitle[2048], stmt1[6000];
	$char stmt[1024];
	$char sdate1[11], sdate2[11];
	
	$whenever sqlerror goto errexit;
	
	strcpy(sfilename,"���N�I����O�q���޲z����");
	sprintf_s(stitle, sizeof stitle,"�{���N��:CAR173 \t ��O�~��G%s/%s  \t\n",dyy,dmm);
	strcat(stitle,"\t�g��N��\t�g��W��\t�޲z�H�N��\t�޲z�H�W��\t�q���N��\t�q���W��\t");
	strcat(stitle,"�O�渹\t���P\t�Q�O�I�H\t����\t�O�I�_��\t�Ƶ�����\t");
	strcat(stitle,"���s��O��\t�H�e���A\t���N��\t���W��\t���ʤH��\t���ʮɶ�\t");

	strcpy(stmt1,"select chr(127)||iofficer, nofficer, ''''||ileader, nleader, iroute, nroute,  \n"
	             "ipolicy, chr(127)||itag, nassured, chr(127)||icar_type, dply_begin, nremark,      \n"
	             "frenew, decode(frenew_status,'Y','���H','N','�H',''), iquota, nquota,chr(127)||iupdate,dupdate \n"
	             "from car173_tmp1 where 1=1 ;     \n");

	rc = unload_file(outputf," ",sfilename,stitle,stmt1);
	
	if (rc != SUCCESS) 
	{
	    sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long ca173_build2()
{
	$char   project_id[8], subject[256], content[9000];
	$char   pre_email_nleader[51]=" ";
	$char   isend[7]=" ", pre_isend[7]=" ", nsend[11]= " ";
	$char   stmt[124];
	int     i,rc,fLast;
	char    sApHome[30];
	
	$WHENEVER SQLERROR GOTO errexit;
	
	rc = getApHome(sApHome);
	if (rc < 0) {
		printf("read Config file error!!\n");
		return M_CM_READ_CONFIG_ERR;
	}
	
	sprintf_s(stmt, sizeof stmt," SELECT trim(email)||'@tmnewa.com.tw' FROM sysdb:v_asempl WHERE empl_no= ? ");
	$PREPARE get_email FROM $stmt;
	   
	strcpy(project_id,"CAR173");
	
	$BEGIN WORK;
	
	$declare cur_1 cursor for
          select DISTINCT ileader 
            from car173_tmp1
           where frenew_status = ''
        order by ileader;
        $open cur_1;  
        
        while (1)
        {
        	$fetch cur_1 into $isend ;
        	
         	if(SQLCODE == SQLNOTFOUND) break;
         	
         	$SELECT nname[1,10] INTO $nsend
         	   FROM officer
         	  WHERE iofficer = $isend;
           	
         	strcpy(pre_isend ,rtrim(pre_isend));
         	strcpy(isend ,rtrim(isend));
         	strcpy(nsend ,rtrim(nsend));
         	       	
         	if((strcmp(pre_isend,isend)!=0))
         	{
         		if (strlen(trim(isend))>0)
         		{ 
         			$EXECUTE get_email into $pre_email_nleader USING $isend; /* ���o email address */         				
         			sprintf_s(subject, sizeof subject ,"�u���N�I����O�q���O���ƺ��@car173�v�������q��" );
         			sprintf_s(content, sizeof content ,
         			        "<html><body>  \n"
         			        "%s �z�n�G<p>  \n"
         			        "%s�먮�I��O���`��T���ӡA�z�Һ޲z���O���ơA  \n"
         			        "�]�ucar173���N�I����O�q���O���ƺ��@�v�|���������@�A  \n"
         			        "�L�k�i�����i����O�q����j�H�e�@�~�C<br>  \n"
         			        "�q�аȥ����餺�����A�խY���������D�Ь��ӤH�O�I���A���¡I<br><br>  \n"
         			        "&nbsp;&nbsp;�� �֫O�������D�A�Ь��ӤH�O�I�� �֫O��C<br>  \n"
         			        "&nbsp;&nbsp;�� ��O�������D�A�Ь��ӤH�O�I�� �~�Ȧ�F��C  \n"
         			        "</body></html>  \n", nsend, dmm);    
         			
         			ctxt.loc_loctype = LOCMEMORY;
         			ctxt.loc_buffer = content;
         			ctxt.loc_bufsize = 9000;
         			ctxt.loc_size =  strlen(content) + 1;  		             		        	        
      		          
        		        $INSERT INTO batchemail
        		        (project_id, mail_date, receiver_email, receiver_name, cc, content, key, mail_count, nsubject)
        		        VALUES
        		        ($project_id, $mail_date, $pre_email_nleader, $nsend, '', $ctxt, '', 0, $subject );
        		        
        		        if ( sqlca.sqlerrd[2] == 0 ){
        		        	sprintf_s(msgbuf, sizeof msgbuf, "�s�W��batchemail���ѡGproject_id[%s],mail_date[%ld],receiver_email[%s],receiver_name[%s],subject[%s] \n",
        		        	project_id, mail_date, pre_email_nleader, nsend, subject );
        		        	EWRITE(userid,SQLCODE,msgbuf);
        		        	$ROLLBACK WORK;
        		        	return -1;
        		        }       		        
        		}
        	}
        }
        $CLOSE cur_1;
        $FREE  cur_1;
        $COMMIT WORK; 	
 	sprintf_s(msgbuf, sizeof msgbuf,"�w�p�� %s �妸�o�email�q���޲z�H�I \n",cm_cdate_str_100(mail_date));
        EWRITE(userid,M_CM_OK,msgbuf);
        return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long ca173_delete_data()
{
	$whenever sqlerror goto errexit;
	
	$delete from ca_no_renew WHERE dcreate < date_add(to_char(today ,'%m/01/%Y') ,interval(-11) month to month) ;
		
	return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}