/***********************************************************************
 *   PROGRAM ID    : ca102q03s.ec                                      *
 *   PROGRAM NAME  : �Ȥ��ƺ޲z����email�q��(���ΫȤ�Ϊw����)       *
 *   AUTHOR        : Jessie                                            *
 *   DATE WRITTEN  : 2011/07/05                                        *
 ***********************************************************************
 *                             MODIFICATION LOG                        *
 *                                                                     *
 *   DATE         SE                         DESCRIPTION               *
 * --------  -------------  ----------------------------------------   *
 *                                                                     *
 **********************************************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"

#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"
#include "safeclib.h"

char  	outputf[ N_FILE+1];
$char  	userid[11];
char  	ddate[11];
char	syy[4],smm[3],sdd[3],sdate[11];

$char	DBName[5];
    
int     flen;
FILE    *fp;
char    sApHome[30];
$char   fname[50];
$char   nattachment[200];
$char   filename[101];
$char	ftitle[1024];
	
$char	mmsg[1024];
$char 	tbuf[501];
$char 	mbuf[9000];
$loc_t 	ctxt;

$char	smail[41];
$char	stmt[4096];
char	msgbuf[100];

$char	pre_ileader[11];
$int 	mail_count;
$long	dsys;

$char	ipolicy[21];
$char	icard[21];
$char	iassured[11];
$char	nassured[41];
$char	itag[CA_TAG_NUM];
$char	iofficer[11],ileader[11],nleader[11];
$char	freason[2],nreason[25];
$char	dend[11],dcreate[11],remark[255];
/* asempl */
$char	email[51],chinese_name[15];

/* �Ӹ�B�n add by larry 103.02.19 (1030211003_C1) */
$char sFassured[2],sNassured[41];
$char Full_DBName[20],stmt1[512];
$char stmt_tmp[1024];

char *get_car_full_db();
/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
int rc;
   
    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(ddate,   isNULLstr(argv[3])); /* cyy/mm/dd */
    strcpy(outputf, isNULLstr(argv[4]));

    rc = car1023_get_db();
    if (rc != M_CM_OK) {
        printf("error on car1023_get_db\n");
        return rc;
    }
            
    rc = car1023_init_data();
    if (rc != M_CM_OK) {
        printf("error on car1023_init_data\n");
        return rc;
    }
            
    rc=car1023_ply_data();
    if (rc != M_CM_OK) {
        printf("error on car1023_ply_data\n");
        return rc;
    }

    rc=car1023_send_email();
    if (rc != M_CM_OK) {
        printf("error on car1023_send_email\n");
        return rc;
    }
    
    /* �o�eemail�����ťD�ޤγq�T�B�� add by sylvia 101.05.15(1010112001_C1) 
       �אּ�o�e�޲z�H��D�ޤγ��D�� modify by sylvia 101.06.28 (1010619002_C1) */
    /* �o�eemail���޲z�H��D�� */
    rc=car1023_send_email_mgr3();
    if (rc != M_CM_OK) {
        printf("error on car1023_send_email_mgr3\n");
        return rc;
    }
    
    /* �o�eemail���޲z�H���D�� */
    rc=car1023_send_email_mgr2();
    if (rc != M_CM_OK) {
        printf("error on car1023_send_email_mgr2\n");
        return rc;
    }

    rc=car1023_final_email();
    if (rc != M_CM_OK) {
        printf("error on car1023_final_email\n");
        return rc;
    }

    rc=car1023_print();
    if (rc != M_CM_OK) {
        printf("error on car1023_print\n");
        return rc;
    }

    printf("[car1023]:process ok!\n"); 
}
/*--------------------------------------------------------------------*/
long car1023_get_db()
{
int	rc;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
    }
    
    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }

    return M_CM_OK;
}
/*--------------------------------------------------------------------*/
long car1023_init_data()
{
    $whenever sqlerror goto errexit;
    
     /*imgrled1				char(6),	-- ��ťD�ޭ��s
       imgrled2				char(6),	-- ���ťD�ޭ��s*/
    
    sprintf_s(stmt_tmp, sizeof stmt_tmp,
        "create temp table car1023 ("
	    "ipolicy	    char(20), "
        "icard           char(20), "
        "iassured        char(10), "
        "nassured        varchar(40), "
        "itag            char(%d), "
	    "dend	    date, "
        "iofficer        char(10), "
        "ileader         char(10), "
        "freason         char(1), "
        "imgrled1	    char(6), "
        "imgrled2        char(6), "
	    "dcreate	    date, "
        "remark          varchar(254))"
        "with no log;",CA_TAG_NUM-1);
        
    $PREPARE stmp FROM $stmt_tmp;
    $EXECUTE stmp;

    printf("ddate[%s]\n",ddate);
    dsys = cm_ymd_cdate(ddate);
    cm_char_split_3ymd(ddate,syy,smm,sdd);
    sprintf_s(sdate, sizeof sdate, "%s%s%s",syy,smm,sdd);
    printf("sdate=[%s]\n",sdate);

    /* ���Y */
    strcpy(ftitle,
        "�O�渹�X,���N�d��,�Q�O�I�HID,�Q�O�I�H�W��,����,�O������,"
        "�g��N��,�޲z�H,�Ȥ�޲z���O,car102�Ȥ�޲z���ɭ�],�Ȥ�޲z���ɤ�,�Ƶ�����\n");

    /* email��� */
    strcpy(mmsg,
	"�����H�󬰨t�Φ۰ʵo�X�A�ФŪ����^�H�A�Y�������ðݥi�q���ӤH�O�I���C</P>\n"
	"�������Ƭ����q���H�e��e30�餺�s�W�Ȥ��ƺ޲z���ӡA�����Ѻ޲z�P���x�����A�ѷ~�ȡA�S���|���ɸ�Ƥ����ĥ��N�O��̷s�g��N���޲z�H�A����ѱz�Ѱu�C</P>\n");

    strcpy(mbuf,rtrim(mmsg));
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mbuf;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mbuf) + 1;
		
    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car1023_ply_data()
{
int	rc;

		/* �ګO��Ƥ������O,�E�j�����n�e modify by sylvia 101.05.14 (1010112001_C1) */
    $whenever sqlerror goto errexit;

    sprintf_s(stmt, sizeof stmt,
	"insert into car1023 "
	"select ipolicy1,itarget2,a.iassured[1,3]||'****'||a.iassured[8,10],"
	"	a.nassured[1,40],itarget1,a.dins_end,a.iofficer,c.ileader, b.freason, "
	"(select resp_name from sa_branch_type e, personal:unitid2ef f "
	"  where e.ibranch = f.code_no and e.dexpire is null "
	"    and e.ibranch not in ('110100','110200') and e.ibranch = c.iquota), "
	"(select resp_name from sa_branch_type g, personal:unitid2ef h "
	"  where g.ibranch = h.code_no and g.dexpire is null "
	"    and g.ibranch not in ('110100','110200') "
	"    and g.ibranch[1,4] = c.iquota[1,4] and g.fprop = '2'), b.dcreate, b.remark "
	"  from reject_client b,policy_new a,officer c"
	" where b.dcreate >= ? - 30"
	"   and b.dcreate < ?"
	"   and ((b.itag = a.itarget1 and a.itarget1 != ' ')"
	"	or (b.ilicense = a.iassured and a.iassured != ' '))"
	"   and a.itarget1 != ' '"
	"   and a.dins_end > today"
	"   and a.insure_type = 'C'"
	"   and a.isys_source = 'CAR'"
	"   and a.ipolicy1[6,6] = 'V' "
	"   and a.ipolicy1[6,7] != 'VW' "
	"   and a.iofficer = c.iofficer");
	printf("dsys=[%ld]\n",dsys);
	printf("stmt[%s]\n",stmt);
	$prepare pre_ply from $stmt;
	$execute pre_ply using $dsys,$dsys;
	
	/* �T�{��D��=���D�ޮ�, ������D�޸�ơA�ȫO�d���D�޸�ơ@add by sylvia 101.06.27 */
	$update car1023 set imgrled1 = '' where imgrled1 = imgrled2;
         
	return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car1023_send_email()
{
    int	rc;
    $char	tmpstr[41];
    $whenever sqlerror goto errexit; 
    strcpy(stmt,
        "select ipolicy,icard,iassured,nassured,itag,a.dend,"
	"	a.iofficer,b.nname, a.freason, "
        "       decode(freason,'1','�r�p�ߺD�ά������ΫȤ�','2','���Ѩ�','3','���l��','4','�w����', "
        "                      '5','�z�ߴ���','6','�ƬG����','7','��b���I�λݯS�׳B�z�Ȥ�', "
        "                      '8','�Ȥ�S�O�T��','�֫O���O'), "
	"       a.dcreate, a.remark"
        "  from car1023 a,officer b"
	" where a.ileader = ? and a.ileader = b.iofficer"
        " order by ipolicy;");
    printf("stmt[%s]\n",stmt);
    $prepare pre_dtl from $stmt;
    $declare cur_dtl cursor for pre_dtl;
	
    $declare cur_temp cursor for
      select distinct ileader
	into $ileader
	from car1023
       order by ileader;
    $open cur_temp; 
    $fetch cur_temp;

    strcpy(pre_ileader,ileader);
    
    mail_count=0;
    while(1) 
    {
        if (SQLCODE==SQLNOTFOUND) break;

	if (strcmp(ileader,pre_ileader)!=0) 
	{
	    rc = car1023_write_email();
	    if (rc!=M_CM_OK) 
	    {
	        printf("error on car1023_write_email\n");
		return rc;
	    }
	    mail_count=0;
	}
	strcpy(pre_ileader,ileader);
	
	mail_count++;
	printf("ileader[%s]\n",ileader);
	memset(fname,0x00,sizeof(fname));
	memset(nattachment,0x00,sizeof(nattachment));
	memset(filename,0x00,sizeof(filename));
	sprintf_s(fname, sizeof fname, "%s�Ȥ��ƺ޲z_%s",sdate,trim(ileader));
	/*add by 071004 (1110322014_SC3_batchemail�ಾ�ܷs���x)*/
	sprintf_s(nattachment, sizeof nattachment, "%s�Ȥ��ƺ޲z_%s.csv",sdate,trim(ileader));
	sprintf_s(filename, sizeof filename, "%s/rptftp/car102/%s.csv",sApHome,fname);
	printf("filename[%s]\n",filename);
	fp=fopen(filename,"w");
		
	fprintf(fp,ftitle);
			
	$open cur_dtl using $ileader;
	
	while(1) 
	{
	    $fetch cur_dtl
	      into $ipolicy,$icard,$iassured,$nassured,$itag,
	           $dend,$iofficer,$nleader,$freason,$nreason,$dcreate,$remark;
	    if (SQLCODE==SQLNOTFOUND) break;
		    
	    /* �Ӹ�B�n (nassured) add by larry 103.02.19 (1030211003_C1) */
	    strcpy(Full_DBName,get_car_full_db(ipolicy));
	    sprintf_s(stmt1, sizeof stmt1, "SELECT fassured "
                           "FROM %s:policy "
                           "WHERE ipolicy = '%s' ",Full_DBName,ipolicy);
            $PREPARE policy_cur FROM $stmt1;             
            $EXECUTE policy_cur INTO $sFassured;
        
            strcpy(sFassured,trim(sFassured));
            printf("-----fassured[%s]\n-----",sFassured);
            if ((strncmp(sFassured,"1",1)==0)||(strncmp(sFassured,"3",1)==0)||(strncmp(sFassured,"5",1)==0))
            {
                strcpy(sNassured,substring(nassured,1,2));
	        strcat(sNassured,"�ݢ�");	        
            }
            else
            {
                strcpy(sNassured,nassured);
            }
	
	    printf("ipolicy[%s]\n",ipolicy);
	    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
		        ipolicy,icard,iassured,sNassured,itag,
	                dend,iofficer,nleader,freason,nreason,dcreate,remark);
	}
	$close cur_dtl;
	fclose(fp);
	$fetch cur_temp;
    }
    $free  cur_dtl;
    $close cur_temp;
    $free  cur_temp;
	    
    if (mail_count!=0) 
    {
        rc = car1023_write_email();
        if (rc!=M_CM_OK) 
        {
	    printf("error on car1023_write_email\n");
	    return rc;
	}
    }
           
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car1023_write_email()
{
    $whenever sqlerror goto errexit; 

    $select email,chinese_name
       into $email,$chinese_name
       from personal:asempl
      where empl_no = $pre_ileader;

    strcpy(email,trim(email));
    strcat(email,"@tmnewa.com.tw");
    printf("email[%s]\n",email);
    
    /*add by 071004 (1110322014_SC3_batchemail�ಾ�ܷs���x)*/	
    $INSERT INTO batchemail
		(project_id, mail_date, receiver_email,
		receiver_name, cc, content, key, mail_count, nattachment)
     VALUES
		("CAR1023", today+1, $email, $chinese_name,
			" ", $ctxt, $fname, $mail_count, $nattachment);

    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car1023_final_email()
{
    $whenever sqlerror goto errexit; 

    $select email,chinese_name
       into $email,$chinese_name
       from personal:asempl
      where empl_no = $userid;

    strcpy(email,trim(email));
    strcat(email,"@tmnewa.com.tw");
    printf("email[%s]\n",email);
		
    strcpy(mmsg,
	"�Ȥ��ƺ޲z���ɧ妸email�q�����N�I�O��̷s�޲z�H�@�~�w���槹���A�ԲӸ�ƽжi���I�t��cmn201�d�ߡC</P>\n");

    strcpy(mbuf,rtrim(mmsg));
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mbuf;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mbuf) + 1;
		
    $INSERT INTO batchemail
		(project_id, mail_date, receiver_email,
		receiver_name, cc, content, key, mail_count)
     VALUES
		("CAR1023", today+1, $email, $chinese_name,
			" ", $ctxt, " ",0);

    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car1023_print()
{
    int     rc;
    char    sfilename[100],stitle[1024],stmt[8000];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"�Ȥ��ƺ޲zemail����");
    strcpy(stitle,"�{���N��:CAR1023\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t\t\t\t\t\t\t\t\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(sfilename,"[CAR1023]");

    strcat(stitle,"\t�O�渹�X\t���N�d��\t�Q�O�I�HID\t�Q�O�I�H�W��\t");
    strcat(stitle,"����\t�O������\t�g��N��\t�޲z�H�N��\t�޲z�H\t");
    strcat(stitle,"�Ȥ�޲z���O\t car102�Ȥ�޲z���ɭ�]\t�Ȥ�޲z���ɤ�\t�Ƶ�����\t");

    strcpy(stmt,
	"select ipolicy,icard,iassured,nassured,itag,a.dend,"
	"	a.iofficer,a.ileader,b.nname,a.freason,"
	"       decode(freason,'1','�r�p�ߺD�ά������ΫȤ�','2','���Ѩ�','3','���l��','4','�w����', "
	"                      '5','�z�ߴ���','6','�ƬG����','7','��b���I�λݯS�׳B�z�Ȥ�', "
	"                      '8','�Ȥ�S�O�T��','�֫O���O'),"
	"	a.dcreate, a.remark"
	"  from car1023 a,officer b"
	" where a.ileader = b.iofficer order by 8,1");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf, " %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
errexit:
    sqlfatal();
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/

/* �אּ�o���O��޲z�H����ťD�� modify by sylvia 101.06.27 (1010619002_C1) */
long car1023_send_email_mgr3()
{
    int	rc;
    $char	tmpstr[41];
    $whenever sqlerror goto errexit; 
	
    strcpy(mmsg,
          "�����H�󬰨t�Φ۰ʵo�X�A�ФŪ����^�H�A�Y�������ðݥi�q���ӤH�O�I���C</P>\n"
	  "�������Ƭ����q���H�e��e30�餺�s�W�Ȥ��ƺ޲z���ӡA�����Ѻ޲z�P���x�����A�ѷ~�ȡA�󪾷|���ɸ�Ƥ����ĥ��N�O��̷s�g��N���޲z�H�A�@�ֶg���U��D�ޡA�ѱz�Ѱu�C</P>\n");
	

    strcpy(mbuf,rtrim(mmsg));
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mbuf;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mbuf) + 1;
	
    strcpy(stmt,
        "select ipolicy,icard,iassured,nassured,itag,a.dend,"
	"	a.iofficer,b.nname, a.freason, "
        "       decode(freason,'1','�r�p�ߺD�ά������ΫȤ�','2','���Ѩ�','3','���l��','4','�w����', "
        "                      '5','�z�ߴ���','6','�ƬG����','7','��b���I�λݯS�׳B�z�Ȥ�', "
        "                      '8','�Ȥ�S�O�T��','�֫O���O'), a.dcreate, a.remark"
        "  from car1023 a,officer b"
	" where a.imgrled1 <> '' and a.imgrled1 = ? and a.ileader = b.iofficer"
        " order by ipolicy;");
    printf("stmt[%s]\n",stmt);
    $prepare pre_mgr3_dtl from $stmt;
    $declare cur_mgr3_dtl cursor for pre_mgr3_dtl;
	
    $declare cur_mgr3_temp cursor for
      select distinct imgrled1
	into $ileader
	from car1023
       where imgrled1 <> ''
       order by imgrled1;
    $open cur_mgr3_temp; 
    $fetch cur_mgr3_temp;

    strcpy(pre_ileader,ileader);
    
    mail_count=0;
    while(1) 
    {
        if (SQLCODE==SQLNOTFOUND) break;

	if (strcmp(ileader,pre_ileader)!=0) 
	{
	    rc = car1023_write_email();
	    if (rc!=M_CM_OK) 
	    {
	        printf("error on car1023_write_email\n");
		return rc;
	    }
	    mail_count=0;
	}
	strcpy(pre_ileader,ileader);
	
	mail_count++;
	printf("��D��ileader[%s]\n",ileader);
	memset(fname,0x00,sizeof(fname));
	memset(nattachment,0x00,sizeof(nattachment));
	memset(filename,0x00,sizeof(filename));
	sprintf_s(fname, sizeof fname, "%s�Ȥ��ƺ޲z_mgr3_%s",sdate,trim(ileader));
	/*add by 071004 (1110322014_SC3_batchemail�ಾ�ܷs���x)*/
	sprintf_s(nattachment, sizeof nattachment, "%s�Ȥ��ƺ޲z_mgr3_%s.csv",sdate,trim(ileader));
	sprintf_s(filename, sizeof filename, "%s/rptftp/car102/%s.csv",sApHome,fname);
	printf("filename[%s]\n",filename);
	fp=fopen(filename,"w");
		
	fprintf(fp,ftitle);
			
	$open cur_mgr3_dtl using $ileader;
	
	while(1) 
	{
	    $fetch cur_mgr3_dtl
	      into $ipolicy,$icard,$iassured,$nassured,$itag,
	           $dend,$iofficer,$nleader,$freason,$nreason,$dcreate,$remark;
	    if (SQLCODE==SQLNOTFOUND) break;
		    
	    /* �Ӹ�B�n (nassured) add by larry 103.02.19 (1030211003_C1) */
	    strcpy(Full_DBName,get_car_full_db(ipolicy));
	    sprintf_s(stmt1, sizeof stmt1, "SELECT fassured "
                           "FROM %s:policy "
                           "WHERE ipolicy = '%s' ",Full_DBName,ipolicy);
            $PREPARE policy_cur3 FROM $stmt1;             
            $EXECUTE policy_cur3 INTO $sFassured;
        
            strcpy(sFassured,trim(sFassured));
            printf("-----fassured[%s]\n-----",sFassured);
            if ((strncmp(sFassured,"1",1)==0)||(strncmp(sFassured,"3",1)==0)||(strncmp(sFassured,"5",1)==0))
            {
                strcpy(sNassured,substring(nassured,1,2));
	        strcat(sNassured,"�ݢ�");	        
            }
            else
            {
        	strcpy(sNassured,nassured);
            }
	
	    printf("ipolicy[%s]\n",ipolicy);
	    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
		        ipolicy,icard,iassured,sNassured,itag,
	                dend,iofficer,nleader,freason,nreason,dcreate,remark);
	}
	$close cur_mgr3_dtl;
	fclose(fp);
	$fetch cur_mgr3_temp;
    }
    $free  cur_mgr3_dtl;
    $close cur_mgr3_temp;
    $free  cur_mgr3_temp;
	    
    if (mail_count!=0) 
    {
        rc = car1023_write_email();
        if (rc!=M_CM_OK) 
        {
	    printf("error on car1023_write_email\n");
	    return rc;
	}
    }
           
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/* �אּ�o���O��޲z�H�����ťD�� modify by sylvia 101.06.27 (1010619002_C1) */
long car1023_send_email_mgr2()
{
    int	rc;
    $char	tmpstr[41];
    $whenever sqlerror goto errexit; 
	
    strcpy(mmsg,
        "�����H�󬰨t�Φ۰ʵo�X�A�ФŪ����^�H�A�Y�������ðݥi�q���ӤH�O�I���C</P>\n"
	"�������Ƭ����q���H�e��e30�餺�s�W�Ȥ��ƺ޲z���ӡA�����Ѻ޲z�P���x�����A�ѷ~�ȡA�󪾷|���ɸ�Ƥ����ĥ��N�O��̷s�g��N���޲z�H�A�@�ֶg���U��D�ޡA�ѱz�Ѱu�C</P>\n");
	

    strcpy(mbuf,rtrim(mmsg));
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mbuf;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mbuf) + 1;
	
    strcpy(stmt,
        "select ipolicy,icard,iassured,nassured,itag,a.dend,"
	"	a.iofficer,b.nname, a.freason, "
        "       decode(freason,'1','�r�p�ߺD�ά������ΫȤ�','2','���Ѩ�','3','���l��','4','�w����', "
        "                      '5','�z�ߴ���','6','�ƬG����','7','��b���I�λݯS�׳B�z�Ȥ�' , "
        "                      '8','�Ȥ�S�O�T��','�֫O���O'), "
	"       a.dcreate, a.remark"
        "  from car1023 a,officer b"
	" where a.imgrled2 = ? and a.ileader = b.iofficer"
        " order by ipolicy;");
    printf("stmt[%s]\n",stmt);
    $prepare pre_mgr2_dtl from $stmt;
    $declare cur_mgr2_dtl cursor for pre_mgr2_dtl;
	
    $declare cur_mgr2_temp cursor for
      select distinct imgrled2
	into $ileader
	from car1023
       order by imgrled2;
    $open cur_mgr2_temp; 
    $fetch cur_mgr2_temp;

    strcpy(pre_ileader,ileader);
    
    mail_count=0;
    while(1) 
    {
        if (SQLCODE==SQLNOTFOUND) break;

        if (strcmp(ileader,pre_ileader)!=0) 
        {
            rc = car1023_write_email();
	    if (rc!=M_CM_OK) 
	    {
	        printf("error on car1023_write_email\n");
		return rc;
	    }
	    mail_count=0;
	}
	strcpy(pre_ileader,ileader);
	
	mail_count++;
	printf("���D��ileader[%s]\n",ileader);
	memset(fname,0x00,sizeof(fname));
	memset(nattachment,0x00,sizeof(nattachment));
	memset(filename,0x00,sizeof(filename));
	sprintf_s(fname, sizeof fname, "%s�Ȥ��ƺ޲z_mgr2_%s",sdate,trim(ileader));
	/*add by 071004 (1110322014_SC3_batchemail�ಾ�ܷs���x)*/
	sprintf_s(nattachment, sizeof nattachment, "%s�Ȥ��ƺ޲z_mgr2_%s.csv",sdate,trim(ileader));
	sprintf_s(filename, sizeof nattachment, "%s/rptftp/car102/%s.csv",sApHome,fname);
	printf("filename[%s]\n",filename);
	fp=fopen(filename,"w");
		
	fprintf(fp,ftitle);
			
	$open cur_mgr2_dtl using $ileader;
	
	while(1) 
	{
	    $fetch cur_mgr2_dtl
	      into $ipolicy,$icard,$iassured,$nassured,$itag,
	           $dend,$iofficer,$nleader,$freason,$nreason,$dcreate,$remark;
	    if (SQLCODE==SQLNOTFOUND) break;
		    
	    /* �Ӹ�B�n (nassured) add by larry 103.02.19 (1030211003_C1) */	
            strcpy(Full_DBName,get_car_full_db(ipolicy));
	    sprintf_s(stmt1, sizeof stmt1, "SELECT fassured "
                           "FROM %s:policy "
                           "WHERE ipolicy = '%s' ",Full_DBName,ipolicy);
            $PREPARE policy_cur2 FROM $stmt1;             
            $EXECUTE policy_cur2 INTO $sFassured;
        
            strcpy(sFassured,trim(sFassured));
            printf("-----fassured[%s]\n-----",sFassured);
            if ((strncmp(sFassured,"1",1)==0)||(strncmp(sFassured,"3",1)==0)||(strncmp(sFassured,"5",1)==0))
            {
                strcpy(sNassured,substring(nassured,1,2));
	        strcat(sNassured,"�ݢ�");	        
            }
            else
            {
        	strcpy(sNassured,nassured);
            }
	
	    printf("ipolicy[%s]\n",ipolicy);
	    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
		        ipolicy,icard,iassured,sNassured,itag,
	                dend,iofficer,nleader,freason,nreason,dcreate,remark);
	}
	$close cur_mgr2_dtl;
	fclose(fp);
	$fetch cur_mgr2_temp;
    }
    $free  cur_mgr2_dtl;
    $close cur_mgr2_temp;
    $free  cur_mgr2_temp;
	    
    if (mail_count!=0) 
    {
        rc = car1023_write_email();
        if (rc!=M_CM_OK) 
        {
	    printf("error on car1023_write_email\n");
	    return rc;
	}
    }
           
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*************************************************************/
/*char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
        char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
		char sTmp_db_name[21];
		
        sTmp_db_name[0]='\0';
        if (*sIpolicy != '\0' && *sIpolicy !=' ')
        {
           sTmp_db_name[0]='\0';
           strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
           strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
                  USE_BRANCH_ID));
           strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
        }
  return sTmp_db_name;
}*/
