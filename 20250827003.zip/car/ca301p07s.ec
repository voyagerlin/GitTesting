/**********************************************************************/
/*   program id   : ca301p07s.ec                                      */
/*   program name : ���i�L��޲z����@�~                              */
/*   date written : 2016/10/18                                        */
/*   shell        : car3017_print                                     */
/*   exec time    : 00:10                                             */
/**********************************************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"
#include "safeclib.h"

$char	DBName[5], userid[11], ddate[11];
DBinfo  *list;
char  	outputf[ N_FILE+1],sApHome[30],msgbuf[100];;
$loc_t 	ctxt;
$char	ftitle[1024],nsubject[512], nsub_1A[100],nsub_1M[100],nsub_5M[100],
        max_date[11],min_date[11],sdate3[11],pre_ileader[11];
int     i,count_db;
$char   fname[100],fnameM[100];
$char   filename[150], filenameM[150];
$int    mail_count ,err_cnt;
$long 	sToday,sLdeffect,deadline;
FILE    *fp;

$char stmt[3000], stmt1[3000], v_sMsg[2040], tmp_sMsg[1024], payMsg[5000];
$char sDdate[11];

/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;
      
    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(ddate,   isNULLstr(argv[3])); /* cyy/mm/dd */
    strcpy(outputf, isNULLstr(argv[4]));
    
    printf("ddate[%s]\n",ddate);
    strcpy(sDdate,cm_to_infdate(ddate));
    printf("-----dpolicy : [%s]\n-----",sDdate);
    
    sToday = cm_today( ); /* �t�Τ� */
	
	deadline = cm_ymd_cdate("105/11/10");
    
    printf("sToday[%d]\n",sToday);
    printf("deadline[%d]\n",deadline);
    
    printf("sToday[%d]\n",sToday);
    
    rc = car3017_get_db();
    if (rc != M_CM_OK) {
        printf("error on car3017_get_db\n");
        return rc;
    }
    
    rc = car3017_init_data();
    if (rc != M_CM_OK) {
        printf("error on car3017_init_data\n");
        return rc;
    }

    /* �d�߹O�����L���� */        
    rc = car3017_ply_data();
    if (rc != M_CM_OK) {
        printf("error on car3017_ply_data\n");
        EWRITE(userid, rc, "�d�߹O�����L���Ʀ��~!");
        return rc;
    }
    
    /* ��Ʀ��~��mail���ӫO�� �Ʋz */
    printf("err_cnt[%d]\n",err_cnt);
    if (err_cnt > 0)
    {
    	rc = car3017_write_email(); 
		if (rc != M_CM_OK) {
		    printf("error on car3017_write_email\n");
		    EWRITE(userid, rc, "�H�oE-mail�q�����~!");
		    return rc;
		}
    }
    
    
    printf("[car3017]:process ok!\n"); 
}
/*----------------------------------------------------------------------------*/
long car3017_get_db()
{
    int	rc;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
       return M_CM_DB_NOTOPEN;
    }
    
    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }
    
    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
    }

    return M_CM_OK;
}

/*---------------------------------------------------ciphers_mprem_2-------------------------*/
long car3017_ply_data()
{
    int	rc, n, m;
    $char ipolicy[21], itmp_policy[21], iassured[13], dply_begin[11], iofficer[11], ileader[11], dpolicy[11];
    $char iroute_main[21], fverify_note[2], fprint_note[2], ftype_pol[3], ftype_sp[3], ftype[3];
    $char after_date[11],dateline[11], before_date[11],bzfrom[3],iroute[21];
    $int  big_customer_cnt = 0,cn_day = 0,qday_permit,h_count,JC_cnt,iCountSP;
    $long pre_mprem_2,ciphers_mprem_2;
    
    $whenever sqlerror goto errexit;
    
    strcpy(tmp_sMsg,"");
    err_cnt = 0;
    
    /*
    if(sToday < deadline)
    {
    	strcpy(stmt1,"AND a.dentry > '10/31/2016'");
    }
    else
    {
    	strcpy(stmt1," ");
    }
    */
   
    /* �O�ͮĤ饼�L�� */

    for(i=0;i<count_db;i++) 
    {  	 
        sprintf_s(stmt, sizeof stmt,
            "select a.ipolicy, a.itmp_policy, b.iassured, a.dply_begin, a.iofficer, a.ileader, a.dpolicy, \
                    b.iroute,d.iroute_main, c.fverify_note, c.fprint_note, c.ftype_pol, c.ftype_sp, a.bzfrom,  \
                    (select count(*) from ca_permit where iclass = '05' and ftype_sp in ('A1','A2') AND (dexpire is null or dexpire > today) AND icode = d.iroute_main) + \
                    (select count(*) from ca_permit where iclass = '06' and ftype_sp in ('A1','A2') AND (dexpire is null or dexpire > today) AND icode = a.iofficer) + \
                    (select count(*) from ca_permit where iclass = '01' and ftype_sp in ('A1','A2') AND (dexpire is null or dexpire > today) AND icode = b.iassured) \
               from %s:ply_relation a, %s:policy b, cm_pre_receive c, cm_route d \
              where a.ipolicy = b.ipolicy \
                and b.iroute = d.iroute   \
              �@and a.dply_begin <= '%s'  \
                and a.dpolicy is null     \
                and a.ipolicy[6,7] <> 'VW' \
                and a.icar_type not in ('51','T1','T2') \
                and a.iofficer[1,1] not in ('W','H','N') \
                and a.ipolicy = c.ipolicy1 and c.ipolicy2 = ' ' \
                and a.itmp_policy = c.ipre_rcv and c.iins_kind = '2' and c.ipre_end = ' ' \
                and c.ftype_sp not in ('20','JC') \
                and c.fverify_note != '0' \
                and (c.fprint_note = ' ' or c.fprint_note = 'N'); ",list[i].dbname,list[i].dbname,sDdate);

        printf("stmt[%s]\n\n\n\n\n",stmt);

	    $PREPARE pre_over1 FROM $stmt;
        $DECLARE cur_pre_over1 CURSOR for pre_over1;
      	$OPEN cur_pre_over1;

      	while(1)
      	{
	    	$FETCH cur_pre_over1 INTO $ipolicy,$itmp_policy,$iassured,$dply_begin,$iofficer,$ileader,$dpolicy,
	    	                          $iroute,$iroute_main,$fverify_note,$fprint_note,$ftype_pol,$ftype_sp,$bzfrom,
	    	                          $big_customer_cnt;
	    	
	    	if (SQLCODE==SQLNOTFOUND) break;

	    	printf("ipolicy[%s]\n",ipolicy);

	    	strcpy(iroute,trim(iroute));
	    	
	    	printf("iroute[%s]\n",iroute);
	    	printf("ftype_pol[%s]ftype_sp[%s]\n",ftype_pol,ftype_sp);
	    			
			/* �P�_�O�_�s�b�O�g�N�ҥ~�B�z */
    		iCountSP = 0;
			$select count(*) into $iCountSP from car_code
		      where kind = 'SP' and detail = '1'
		        and detail2 = $iroute and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);
		    if (iCountSP == 0)
		    {
					$select count(*) into $iCountSP from car_code
				      where kind = 'SP' and detail = '2'
				        and detail2 = $iofficer and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);
		    }

	    	ciphers_mprem_2 = 0;

	    	$select mnt 
	           into $ciphers_mprem_2
	           from ao_prercv_pass
	          where ipre_rcv = $itmp_policy and iins_kind = '2' and ipre_end = ' ' ;
			
			printf("ciphers_mprem_2[%ld]\n",ciphers_mprem_2);
			
	        if (SQLCODE == SQLNOTFOUND)	
	        {
	    		/*** �̵M�����O�A�h��^Y(���i�L��) SP-10���~ ***/
		    	printf("fprint_note[%s]\n",fprint_note);
		    	if(strcmp(fprint_note,"N") == 0)
		    	{
		            if(strcmp(ftype_pol,"SP") == 0 && strcmp(ftype_sp,"10") == 0)
		            {
		            	/*** �w�ĳq�A���^�� ***/
		            }
		            else
		            {
		            	$update cm_pre_receive
		    			    set fprint_note = 'Y',dprint_note = current
		    			  where ipre_rcv = $itmp_policy and iins_kind = '2' and ipre_end = ' ';
		            }
		    	}
		    	else
		    	{
		    		strcpy(dply_begin, cm_edate2_add( dply_begin, 1, dply_begin));

		    		strcpy(before_date,cm_from_infdate_100(dply_begin));
		    		
		    		if (iCountSP > 0 )
		    		{
						printf("iCountSP[%d]\n",iCountSP);
		    			qday_permit = 15;
		    		}
		    		else
		    		{
			    		/*** �j���Ȥ� �]�w��car153(A1,A2) ***/
			    		printf("big_customer_cnt[%d]\n",big_customer_cnt);

			    		if(big_customer_cnt > 0)
			    		{
			    			$SELECT count(DISTINCT qday_permit_c)
		    	   			   INTO $cn_day
		           			   FROM ca_permit
		          			  WHERE (icode = $iroute_main
		             			 OR icode = $iassured
		             			 OR icode = $iofficer)
		   		    		    AND ftype_sp in ('A1','A2')
		   		    		    AND (dexpire is null or dexpire > today);
		   		    		   
		   		    		if (cn_day > 1)
		   					{
		   						/*** �]�w�����D�A��mail�q���ӫO���Ʋz ***/
		   						printf("215---cn_day[%d]\n",cn_day);
	
		   						$SELECT min(qday_permit_c)
		    	       			   INTO $qday_permit
		           	   			   FROM ca_permit
		          	  			  WHERE (icode = $iroute_main 
		           	     			 OR icode = $iassured
		            	 			 OR icode = $iofficer)
		   		    				AND ftype_sp in ('A1','A2')
		   		    				AND (dexpire is null or dexpire > today);
	
		   						sprintf_s(tmp_sMsg, sizeof tmp_sMsg,"�g��N��[%s]�Q�O�I�HID[%s]�D�q���N��[%s]��CAR153�ѼƳ]�w���~!\n",iofficer,iassured,iroute_main);
		   						
		   						$insert into tb_wk1 (tmp_sMsg)
			    			     values($tmp_sMsg);
	
			    			     err_cnt++;
		   					}
		   		    		else
		   		    		{
		   		    			$SELECT DISTINCT qday_permit_c
		    	       			   INTO $qday_permit
		           	   			   FROM ca_permit
		          	  			  WHERE (icode = $iroute_main 
		           	     			 OR icode = $iassured
		            	 			 OR icode = $iofficer)
		   		    				AND ftype_sp in ('A1','A2')
		   		    				AND (dexpire is null or dexpire > today);
		   		    		}
			    		}
			    		else	/*** �D�j���Ȥ� ***/
			    		{
			    			strcpy(fverify_note,trim(fverify_note));
			    			if(strcmp(fverify_note,"") == 0 || strcmp(fverify_note,"2") == 0)
			    			{
			    				qday_permit = 7;
			    			}
			    			else if (strcmp(fverify_note,"1") == 0)
			    			{
			    				qday_permit = 20;
			    			}
			    			else
			    			{
			    				/*** fverify_note���A���~ ***/
			    				sprintf_s(tmp_sMsg, sizeof tmp_sMsg,"�����渹[%s]�w��J���L��f�ֵ��O���~!\n",trim(itmp_policy));
			    			 	
			    			 	$insert into tb_wk1 (tmp_sMsg)
			    			     values($tmp_sMsg);
			    			     
			    			    err_cnt++;
			    			    
			    			    continue;
			    			}
			    		}
					}
					/* �P�_�O�_�W�L�]�w���u�@�ѼơA�p�W�L�]�w�u�@�Ѽƫh�^�����i�L����O */
					printf("qday_permit[%d]\n",qday_permit);
		    		rc = chk_working_date( before_date, qday_permit, &after_date, v_sMsg);
    				strcpy(dateline,cm_to_infdate(after_date));
    				printf("---232---dateline[%s]\n",dateline);
    				sLdeffect = cm_ymd_cdate(after_date);
    				if (sToday >= sLdeffect)
    				{
    					/*** update fprint_note = 'Y' ***/
    					$update cm_pre_receive
    					    set fprint_note = 'Y',dprint_note = current
    					  where ipre_rcv = $itmp_policy and iins_kind = '2' and ipre_end = ' ';
    				}
		    	}
		    }
		}
		$close cur_pre_over1;
		$free cur_pre_over1;
	 }

	return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

long car3017_init_data()
{
    $int icnt;
    $char yy[4],mm[3],dd[3];
    
    $whenever sqlerror goto errexit;
    
    /* ��Ʀ��~�Ȧs�� */
    $create temp table tb_wk1
    (
        tmp_sMsg  char(255)
        
    )with no log;
    
    return M_CM_OK;

errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}


long car3017_write_email()
{
    $char mmsg[1000], email[51], chinese_name[11],recipient[11];
    
    $whenever sqlerror goto errexit;
    
    strcpy(payMsg,"");

    sprintf_s(stmt, sizeof stmt,"select unique tmp_sMsg \
                    from tb_wk1; ");
    
    $prepare pre_mgr1 from $stmt;
    $declare cur_mgr1 cursor for pre_mgr1;
    $open cur_mgr1;
    while(1)
    {
        $fetch cur_mgr1 into $tmp_sMsg;
		
		if(SQLCODE==SQLNOTFOUND) break;

		strcpy(tmp_sMsg,trim(tmp_sMsg));
		strcat(tmp_sMsg,"</P>");
		strcat(payMsg,tmp_sMsg);
    }
    $close cur_mgr1;
	$free cur_mgr1;
   
    printf("payMsg[%s]\n",payMsg);
    
        /* email��� */
        sprintf_s(mmsg, sizeof mmsg,
	        "�D�ޡB�P�� ��w�G</P>\n\n"
	        "�H�U�����i�L��妸�B�z���~��ơA�нШ�U�B�z�A���¡C</P>\n\n"
	        "%s",payMsg);

	    /* mail �D�� */
	    strcpy(nsubject,"���i�L����O�妸���榳�~����");

    
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mmsg;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mmsg) + 1;

	
	/* �ӫO�� */
	$SELECT resp_name
	   INTO $recipient
       FROM personal:unitid2ef
      WHERE code_no = '320101';

    strcpy(email," ");
    $select email,chinese_name
       into $email,$chinese_name
       from personal:asempl
      where empl_no = $recipient;

    strcpy(email,trim(email));
    if (strlen(email) != 0){ 
    	
      strcpy(email,trim(email));
      strcat(email,"@tmnewa.com.tw");
      printf("-----email:[%s]-----\n",email);
      
		
      $INSERT INTO batchemail
		  (project_id, mail_date, receiver_email, receiver_name, cc, 
		   content, key, mail_count,nsubject)
       VALUES
		  ("CAR3017", today, $email, $chinese_name, "", 
		   $ctxt, " ", 1, $nsubject);
    }
    
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
