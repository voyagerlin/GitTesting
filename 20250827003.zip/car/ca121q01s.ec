/**********************************************************************/
/*   program id   : ca121q01s.ec                                      */
/*   program name : ������~��/�~�N��ƪ�                             */
/*   date written : 2024/03/26 by 120957                              */
/*   files        : sysdb:ca_big_office                               */
/*        	                                                      */
/*                                                                    */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
$include decimal;

DBinfo *list;
int   count_db;
char  outputf[21];
$char DBName[5];
$char userid[11];
$char msgbuf[128];

$char fclass[2],ibig_comp[11],ibig_branch[21],ibig_office[15],nname[41],itel[30];
$char email[41],ireg_no[11],felder[2],ffair[2];
$char dresign_c[12],dresign[12];
$char dcreate_c[12],dcreate[12],dupdate_c[12],dupdate[12];
$char stmt[2048],sMsg[4096],stmp1[128],stmp2[128],stmp3[128],stmp4[128];

int rc;

main(argc, argv)
int argc;
char **argv;
{

    batchinit();
    strcpy(DBName,       isNULLstr(argv[1]));
    strcpy(userid,       isNULLstr(argv[2]));
    strcpy(fclass, 	 isNULLstr(argv[3])); 
    strcpy(ibig_comp,    isNULLstr(argv[4]));
    strcpy(ibig_office,  isNULLstr(argv[5]));
    strcpy(ibig_branch,  isNULLstr(argv[6]));
    strcpy(nname,        isNULLstr(argv[7]));
    strcpy(itel,         isNULLstr(argv[8]));
    strcpy(email,        isNULLstr(argv[9]));
    strcpy(ireg_no,      isNULLstr(argv[10]));
    strcpy(dresign_c,    isNULLstr(argv[11]));
    strcpy(felder,       isNULLstr(argv[12]));
    strcpy(ffair,        isNULLstr(argv[13]));
    strcpy(dcreate_c,    isNULLstr(argv[14]));
    strcpy(dupdate_c,    isNULLstr(argv[15]));
    strcpy(outputf,      isNULLstr(argv[16]));
    
    strcpy(dresign, cm_to_infdate(dresign_c));
    strcpy(dcreate, cm_to_infdate(dcreate_c));
    strcpy(dupdate, cm_to_infdate(dupdate_c));
    
    if(dresign_c[0]=='*')
    {
	sprintf_s(stmp1,sizeof stmp1,"");
    }
    else
    {
	sprintf_s(stmp1,sizeof stmp1,
	"AND dresign = '%s' ",dresign);
    }
   
    if(email[0]=='*')
    {
	sprintf_s(stmp2,sizeof stmp2,"");
    }
    else
    {
	sprintf_s(stmp2,sizeof stmp2,
	"AND email = '%s' ",email);
    }   
    
    if(dcreate_c[0]=='*')
    {
	sprintf_s(stmp3,sizeof stmp3,"");
    }
    else
    {
    	sprintf_s(stmp3,sizeof stmp3,
	"AND DATE(dcreate) = '%s' ",dcreate);
    }
    
    if(dupdate_c[0]=='*')
    {
	sprintf_s(stmp4,sizeof stmp4,"");
    }
    else
    {
    	sprintf_s(stmp4,sizeof stmp4,
	"AND DATE(dupdate) = '%s' ",dupdate);
    }
    
    
    printf("DBName[%s]\n",DBName);
    printf("dresign\n",dresign); /*������褸�~*/
    printf("outputf[%s]\n",outputf);
    
    rc = car121_get_db();
    if (rc != M_CM_OK)
       return rc;

    
    rc = ca121_create_temp();
    if (rc != M_CM_OK)
       return rc;
    
    rc = car121_prepare_data();
    if (rc != M_CM_OK)
       return rc;    
       
    /*build report - ����*/
    rc = car121_build();
    if (rc != M_CM_OK)
       return rc;
       



}

long car121_build()
{
   int rc;
    char    sfilename[81],stitle[2048],stmt[2048];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"������~��/�~�N��ƺ��@��[CAR121]");
    strcat(sfilename,"\n");

    strcpy(stitle,"\t�{���N��:CAR121\t������~��/�~�N��ƪ�\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(stitle,"\n");

    strcat(stitle,"\t���O\t�g��/�~�N�N��/�~�Z���\t���ӦW�٤@/�O�N/���W��"
    	   "\t���ӦW�٤G/�ǯu���X\t��~��/�~�N�W��/�a�}\t�q��\tE-mail"
    	   "\t�n���Ҧr��\t��藍�ߦ��_��(��¾��)\t���ֽҵ{���V���O\t�����ݫȧ��V���O"
    	   "\t���ɤ��\t��s���");

    strcpy(stmt,"select *"
    		"  from car121_tmp1");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;

}

long car121_prepare_data()
{
   $char t_fclass[2],t_ibig_comp[11],t_ibig_branch[21],t_ibig_office[15],t_nname[41],t_itel[15];
   $char t_email[41],t_ireg_no[11],t_felder[2],t_ffair[2];
   $char t_dresign_c[12],t_dresign[12];
   $char t_dcreate[31],t_dupdate[31];
   
   

   $WHENEVER SQLERROR GOTO errexit;
   
   sprintf_s(stmt, sizeof stmt,
	   "SELECT fclass,ibig_comp,ibig_branch,ibig_office,nname, "
	   "itel,email,ireg_no,dresign,felder,ffair,dcreate,dupdate "
	   " FROM ca_big_office "
	   "WHERE fclass matches '%s' "
	   "  AND ibig_comp matches '%s' "
	   "  AND ibig_branch matches '%s' "
	   "  AND ibig_office matches '%s' "
	   "  AND nname matches '%s' "
	   "  AND itel matches '%s' "
	   "  %s "
	   "  AND ireg_no matches '%s' "
	   "  %s "
	   "  AND felder matches '%s' "
	   "  AND ffair matches '%s' "
	   "  %s "
	   "  %s "
   ,fclass,ibig_comp,ibig_branch,ibig_office,nname,itel,
   stmp2,ireg_no,stmp1,felder,ffair,stmp3,stmp4);
   
   printf("stmt[%s]\n", stmt);
   
   $PREPARE pre1 FROM $stmt;
   $DECLARE cur_pre1 CURSOR for pre1;
   $OPEN cur_pre1;
   	
   	while(1)
   	{
   		
   		
   		strcpy(t_fclass,"");
   		strcpy(t_ibig_comp,"");
   		strcpy(t_ibig_branch,"");
   		strcpy(t_ibig_office,"");
   		strcpy(t_nname,"");
   		strcpy(t_itel,"");
   		strcpy(t_email,"");
   		strcpy(t_ireg_no,"");
   		strcpy(t_dresign,"");
   		strcpy(t_felder,"");
   		strcpy(t_ffair,"");
   		strcpy(t_dcreate,"");
   		strcpy(t_dupdate,"");
   		
   		$FETCH cur_pre1 INTO $t_fclass,$t_ibig_comp,$t_ibig_branch,$t_ibig_office,
   				$t_nname,$t_itel,$t_email,$t_ireg_no,$t_dresign,$t_felder,$t_ffair,
   				$t_dcreate,$t_dupdate;
   		
   		if(SQLCODE == SQLNOTFOUND) break;
   		   		
   		strcpy(t_dresign_c,cm_from_infdate_100(t_dresign));
   		
   		/*
   		printf("fclass[%s] ibig_comp[%s] ibig_branch[%s] ibig_office[%s]"
   		       "nname[%s] itel[%s] email[%s] ireg_no[%s] dresign[%s] felder[%s] ffair[%s]",
   		       t_fclass,t_ibig_comp,t_ibig_branch,t_ibig_office,t_nname,t_itel,
   		       t_email,t_ireg_no,t_dresign,t_felder,t_ffair);
   		*/
   		$INSERT INTO car121_tmp1
   			(fclass,ibig_comp,ibig_branch,ibig_office,nname,itel,
   			 email,ireg_no,dresign,felder,ffair,dcreate,dupdate)
   			VALUES
   			($t_fclass,$t_ibig_comp,$t_ibig_branch,$t_ibig_office,$t_nname,$t_itel,
   			 $t_email,$t_ireg_no,$t_dresign_c,$t_felder,$t_ffair,$t_dcreate,$t_dupdate);
   	}
        $CLOSE cur_pre1;
        $FREE cur_pre1;
        
     return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}


long ca121_create_temp()
{
   /* Create table car121_tmp1 */
   $create temp table car121_tmp1
	(
	 fclass		char(2),
	 ibig_comp	char(11),
	 ibig_branch	char(21),
	 ibig_office	char(15),
	 nname		char(41),
	 itel		char(14),
	 email		char(41),
	 ireg_no	char(11),
	 dresign	char(10),
	 felder		char(2),
	 ffair		char(2),
	 dcreate	char(31),
	 dupdate	char(31)
	)with no log;
	printf("temp[%s]\n","temp_table_ok");
	
    return M_CM_OK;
    

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

long car121_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}