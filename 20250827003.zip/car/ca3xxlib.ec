/*----------------------------------------------------------------------------------------------
 * Program : ca3xxlib.ec  liburary function 2
 * Used By : ca302q01s.ec, ca303q01s.ec,ca302cq01s.ec,ca3024q01s.ec,ca3025q01s.ec,ca3027q01s.ec
 *----------------------------------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
$include sqlca;
$include sqltypes;
$include "ca3xxlib.h";
#include "ca301m01.h"
#include <math.h>
$include "ply_ins_cover.h";      /* 960612, ���ݪ��I34: */
$include "car_common.h";


/* #define  PRINTF_FLAG */

#define fmt "---------&"
static int sfr_302_rate;
double MyPower();
char *sLastChinese();
double dbl_len8();
double d45();
char*   trimx();
char *get_car_full_dbname();
long cm_ibank_pqnum2();

/*************************************************************************/
InitData()
{
    memset(estimatei,0,sizeof(estimatei));
    memset(irelative_ply,0,sizeof(irelative_ply));
    memset(last_ply,0,sizeof(last_ply));
    memset(policy1,0,sizeof(last_ply));
    memset(policy2,0,sizeof(last_ply));

    memset(tagnum,0,sizeof(tagnum));
    memset(relative_card,0,sizeof(relative_card));
    memset(card2,0,sizeof(card2));
    memset(card1,0,sizeof(card1));

    memset(xxcard,0,sizeof(xxcard));
    memset(last_card,0,sizeof(last_card));
    memset(abn_type,0,sizeof(abn_type));
    memset(assuredi,0,sizeof(assuredi));
    memset(assuredf,0,sizeof(assuredf));
    memset(cutf,0,sizeof(cutf));
    memset(assuredn,0,sizeof(assuredn));
    memset(user,0,sizeof(user));
    memset(benefi,0,sizeof(benefi));
    memset(benefn,0,sizeof(benefn));
    memset(assureda,0,sizeof(assureda));
    memset(paymenta,0,sizeof(paymenta));
    memset(tel,0,sizeof(tel));
    memset(passf,0,sizeof(passf));
    memset(issue_ym,0,sizeof(issue_ym));
    memset(pro_year,0,sizeof(pro_year));
    memset(brandi,0,sizeof(brandi));
    memset(brandn,0,sizeof(brandn));
    memset(car_typei,0,sizeof(car_typei));
    memset(car_typen,0,sizeof(car_typen));
    memset(engine,0,sizeof(engine));
    memset(body,0,sizeof(body));
    memset(cal_way,0,sizeof(cal_way));
    memset(license,0,sizeof(license));
    memset(birth,0,sizeof(birth));
    memset(sex,0,sizeof(sex));
    memset(marriage,0,sizeof(marriage));
    memset(acc_align,0,sizeof(acc_align));
    memset(limit,0,sizeof(limit));
    memset(officer,0,sizeof(officer));
    memset(broker,0,sizeof(broker));
    memset(cashier,0,sizeof(cashier));
    memset(resource,0,sizeof(resource));
    memset(big_branch,0,sizeof(big_branch));
    memset(big_office,0,sizeof(big_office));
    memset(big_sales,0,sizeof(big_sales));
    memset(equipment,0,sizeof(equipment));
    memset(ins_type,0,sizeof(ins_type));
    memset(facf,0,sizeof(facf));
    memset(treaty,0,sizeof(treaty));
    memset(passi,0,sizeof(passi));

    memset(drate_ym,0,sizeof(drate_ym));
    memset(fcar_class,0,sizeof(fcar_class));
    memset(fpt,0,sizeof(fpt)); /* 850624-mag */
    memset(fhuman,0,sizeof(fhuman));
    memset(comp_class_last,0,sizeof(comp_class_last));
    memset(comp_class,0,sizeof(comp_class));
    memset(specom,0,sizeof(specom));

    ply2_period=ply1_period=0;
    rows=dmg_align=lia_align=0;
    dmg_align_1=lia_align_1=0;
    cylinder=0.0;  /* �Ʈ�q�X�ܤp���I2�� (1080902001_SC3) */

    brg_align=brg_align_1=0; /* 850624-mag */

    ply2_begin=ply2_end=ply1_begin=ply1_end=DATENULL; /* DATENULL ?? */
    bef_ply2_begin=bef_ply2_end=bef_ply1_begin=bef_ply1_end=DATENULL;
    passd=facd=0;   /* DATENULL ?? */
    drnw_print_1=DATENULL;

    ddate_1st=DATENULL;
    ddate_2nd=DATENULL;

    car_price=0;
    injured_cover=death_cover=damage_cover=deduct=ins_premium=0;

    premium2=0;premium1=0;
    premium=0;

    mdmg_prem=mlia_prem=0;
    qserial=qcoverage=0;

    qday      = 0;
    mexpense  = 0;
    mexp_disc = 0;

    damage_add_flag = 0;
    thief_add_flag  = 0;

    /* 850624-mag */
    /* �t�X���X�ק� */
    qpt = 0;
    psex_age = 0;
    plia_acc = 0;
    pdmg_acc = 0;
    psex_age_damage = 0;

    punknown_acc = 0;
    psex_age_notfound=psex_age_notfound1=psex_age_notfound2=psex_age_notfound3=0;
/* crystal-861229 */
    premium1_bef=0;
    comprem1=diff_prem=0;
    readyrate=comprate=stablerate=investrate=0;
    premium1_24 = 0;
    premium1_ori= 0;
    pcar_price = 1.0;   /* add by sylvia  */
    safe_rate = manage_rate = 0.0;  /* ad by sylvia 104.12.02 (104111011_C1) */

}

/**************************************************************************/
InitData1()
{
    /* can not initialize last_ply */
    memset(estimatei,0,sizeof(estimatei));
    memset(irelative_ply,0,sizeof(irelative_ply));
    memset(policy1,0,sizeof(last_ply));
    memset(policy2,0,sizeof(last_ply));

    memset(tagnum,0,sizeof(tagnum));
    memset(relative_card,0,sizeof(relative_card));
    memset(card2,0,sizeof(card2));
    memset(card1,0,sizeof(card1));
    memset(icard_1,0,sizeof(card1));

    memset(xxcard,0,sizeof(xxcard));
    memset(last_card,0,sizeof(last_card));
    memset(abn_type,0,sizeof(abn_type));
    memset(assuredi,0,sizeof(assuredi));
    memset(assuredf,0,sizeof(assuredf));
    memset(cutf,0,sizeof(cutf));
    memset(assuredn,0,sizeof(assuredn));
    memset(user,0,sizeof(user));
    memset(benefi,0,sizeof(benefi));
    memset(benefn,0,sizeof(benefn));
    memset(assureda,0,sizeof(assureda));
    memset(paymenta,0,sizeof(paymenta));
    memset(tel,0,sizeof(tel));
    memset(passf,0,sizeof(passf));
    memset(issue_ym,0,sizeof(issue_ym));
    memset(pro_year,0,sizeof(pro_year));
    memset(brandi,0,sizeof(brandi));
    memset(brandn,0,sizeof(brandn));
    memset(car_typei,0,sizeof(car_typei));
    memset(car_typen,0,sizeof(car_typen));
    memset(engine,0,sizeof(engine));
    memset(body,0,sizeof(body));
    memset(cal_way,0,sizeof(cal_way));
    memset(license,0,sizeof(license));
    memset(birth,0,sizeof(birth));
    memset(sex,0,sizeof(sex));
    memset(marriage,0,sizeof(marriage));
    memset(acc_align,0,sizeof(acc_align));
    memset(acc_align_t,0,sizeof(acc_align));

    memset(limit,0,sizeof(limit));
    memset(officer,0,sizeof(officer));
    memset(broker,0,sizeof(broker));
    memset(cashier,0,sizeof(cashier));
    memset(resource,0,sizeof(resource));
    memset(big_branch,0,sizeof(big_branch));
    memset(big_office,0,sizeof(big_office));
    memset(big_sales,0,sizeof(big_sales));
    memset(equipment,0,sizeof(equipment));
    memset(ins_type,0,sizeof(ins_type));
    memset(facf,0,sizeof(facf));
    memset(treaty,0,sizeof(treaty));
    memset(passi,0,sizeof(passi));

    memset(drate_ym,0,sizeof(drate_ym));
    memset(fcar_class,0,sizeof(fcar_class));
    memset(fpt,0,sizeof(fpt)); /* 850624-mag */
    memset(fhuman,0,sizeof(fhuman));
    memset(comp_class_last,0,sizeof(comp_class_last));
    memset(comp_class,0,sizeof(comp_class));
    memset(specom,0,sizeof(specom));

    ply2_period=ply1_period=0;
    rows=dmg_align=lia_align=0;
    dmg_align_1=lia_align_1=0;
    cylinder=0.0; /* �Ʈ�q�X�ܤp���I2�� (1080902001_SC3) */

    brg_align=brg_align_1=0; /* 850624-mag */

    ply2_begin=ply2_end=ply1_begin=ply1_end=DATENULL; /* DATENULL ?? */
    bef_ply2_begin=bef_ply2_end=bef_ply1_begin=bef_ply1_end=DATENULL;
    passd=facd=0;   /* DATENULL ?? */
    drnw_print_1=DATENULL;

    ddate_1st=DATENULL;
    ddate_2nd=DATENULL;

    car_price=0;
    injured_cover=death_cover=damage_cover=deduct=ins_premium=0;

    premium2=0;premium1=0;
    premium=0;

    qday      = 0;
    mexpense  = 0;
    mexp_disc = 0;

    damage_add_flag = 0;
    thief_add_flag  = 0;

    mdmg_prem=mlia_prem=0;
    qserial=qcoverage=0;

    /* 850624-mag */
    /* �t�X���X�ק� */
    qpt = 0;
    psex_age = 0;
    plia_acc = 0;
    pdmg_acc = 0;
    psex_age_damage = 0;

    punknown_acc = 0;
    psex_age_notfound=psex_age_notfound1=psex_age_notfound2=psex_age_notfound3=0;
/* crystal-861229 */
    premium1_bef=0;
    comprem1=diff_prem=0;
    readyrate=comprate=stablerate=investrate=0;
    premium1_24 = 0;

    /* 980815*/
    dbirth = DATENULL;
    dissue = DATENULL;
    memset(issue,0,sizeof(issue));
    premium1_ori= 0;
    pcar_price = 1.0;   /* add by sylvia  */
    safe_rate = manage_rate = 0.0;  /* add by sylvia (104111011_C1) */
}
/*****************************************************************/

/* 101.04.30 ,add 96*/
/* 1030403 �s�W�ۥΨ���X�O�I(77,78,79,80,87,88,89) by sylvia 103.04.03 (1000310003_C3) */
/* 1030812 �s�W�����IA��(118,120,122) by sylvia 103.08.12 (1030725001_C4�B1030806001_C5) */
/* 1040602 �s�W���ıq�~�H����X�O�I(125,126,129,133,134) add by sylvia (1040407003_C6) */
/* 1040603 �s�W�s�A������ά������[�I(137,138,139,141,142) add by sylvia (1040515009_C4) */
/* 1041125 �s�W�������[�O�Y��(pcar_price)  add by sylvia 104.11.25 (1021211003_C1) */
/* 1041202 �W���޲z(manage_reate)�Φw��(safe_rate) �[��O�T��(T����) add by sylvia (104111011_C1) */
/* 1071108 86�I���u���B�z add by 061476 (1070522002_SC3)*/
/* 1111019 �����s�A��137.138.139.141.142�I�� (1100311005_SC9) */
int Insert_INS_TYPE (s1,p1,p2,p3,p4,p5,p10,p6,p7,s2,p8,p9,p11,p12,s3,pextra_charge, pbusiness, pcar_price,safe_rate,manage_rate,p13)
char   *s1,*s2,*s3;
long   p1,p2,p3,p4,p5,p9,p10,p11,p12,p13;
double p6,p7,p8;
double pextra_charge, pbusiness, pcar_price,safe_rate,manage_rate;
{
    /*** use a link list ***/
    Icurr=(struct INS_TYPE *)malloc(sizeof(struct INS_TYPE));

    if (Icurr==NULL){
		free(Icurr);
		return FAIL;
	}
    if (Ifirst==NULL) {     /* if it's first element?! */
        Ifirst=Ilast=Icurr;
        Icurr->next=NULL;

    } else if (strcmp(trim(s1),"01")==0 || strcmp(trim(s1),"11")==0 ||
               strcmp(trim(s1),"31")==0 || strcmp(trim(s1),"32")==0 ||
               strcmp(trim(s1),"36")==0 || strcmp(trim(s1),"37")==0 ||
               strcmp(trim(s1),"77")==0 || strcmp(trim(s1),"78")==0 ||
               strcmp(trim(s1),"05")==0 || strcmp(trim(s1),"09")==0 ||
               strcmp(trim(s1),"08")==0 || strcmp(trim(s1),"85")==0 ||
               strcmp(trim(s1),"96")==0 || strcmp(trim(s1),"98")==0 ||
               strcmp(trim(s1),"105")==0 || strcmp(trim(s1),"118")==0 ||
               strcmp(trim(s1),"120")==0 || strcmp(trim(s1),"122")==0 ||
               strcmp(trim(s1),"131")==0 || strcmp(trim(s1),"132")==0 ||
               strcmp(trim(s1),"113")==0 || strcmp(trim(s1),"114")==0 ||
               strcmp(trim(s1),"125")==0 || strcmp(trim(s1),"126")==0 ||
               strcmp(trim(s1),"133")==0 || strcmp(trim(s1),"134")==0 ||
               strcmp(trim(s1),"129")==0 || strcmp(trim(s1),"149")==0 ||
               strcmp(trim(s1),"86")==0  || strcmp(trim(s1),"181")==0 ||
               strcmp(trim(s1),"198")==0 || strcmp(trim(s1),"201")==0 ||
               strcmp(trim(s1),"205")==0 || strcmp(trim(s1),"209")==0 ||
               strcmp(trim(s1),"211")==0 || strcmp(trim(s1),"231")==0 ||
               strcmp(trim(s1),"232")==0 || strcmp(trim(s1),"249")==0 ||
               strcmp(trim(s1),"331")==0 || strcmp(trim(s1),"332")==0 ||
               strcmp(trim(s1),"531")==0 || strcmp(trim(s1),"532")==0)
    {
        /*** ins_type=01,11,31,32  should insert in front of the link list **/
        Icurr->next=Ifirst;
        Ifirst=Icurr;
    } else {
        Ilast->next=Icurr;
        Ilast=Icurr;
        Icurr->next=NULL;
    }
    strcpy(Icurr->ins_type,s1);
    Icurr->injured_cover=p1;
    Icurr->death_cover=p2;
    Icurr->damage_cover=p3;
    Icurr->deduct=p4;
    Icurr->ins_premium=p5;
    Icurr->bef_ins_premium=p10;

    /* 850718 dale add pagent pcommission */
    Icurr->pagent=p6;
    Icurr->pcommission=p7;
    strcpy(Icurr->frate,s2);
    Icurr->pdiscount=p8;
    Icurr->mprem=p9;
    Icurr->qday=p11;
    Icurr->mexpense=p12;
    strcpy(Icurr->provision,  s3);

    /* ��~�βĤT�H�f�B�~���[����"T"�B�j�v�~�Ȫ��[����"B"
    Icurr->safe_rate        = safe_rate;
    Icurr->manage_rate      = manage_rate;
    Icurr->educated_rate    = educated_rate;    */

    /* 97.11�J�O�v�ۥѤ� */
    Icurr->pextra_charge    = pextra_charge;
    Icurr->pbusiness        = pbusiness;
    Icurr->pcar_price       = pcar_price;   /* �������[�O�Y��  add by sylvia 104.11.25 (1021211003_C1) */

    /* ��~�βĤT�H�f�B�~���[����"T" add by sylvia 104.12.02 (104111011_C1) */
    Icurr->safe_rate        = safe_rate;
    Icurr->manage_rate      = manage_rate;

    Icurr->sug_iins_type=p13;

    rows++;

    return SUCCESS;
}
/*****************************************************************/
int Insert_INS_TYPE1 (s1,p1,p2,p3,s3,p5,p6,p7,p8,p9,p10,s2,p11,p12,p13)
char   *s1,*s2,*s3;
long   p1,p2,p3,p5,p6,p7,p8,p9,p10,p11,p12,p13;
{
    /*** use a link list ***/
    Icurr1=(struct INS_TYPE1 *)malloc(sizeof(struct INS_TYPE1));
    if (Icurr1==NULL){
		free(Icurr1);
		return FAIL;
	}
    if (Ifirst1==NULL) {     /* if it's first element?! */
        Ifirst1=Ilast1=Icurr1;
        Icurr1->next=NULL;
    } else {

        Ilast1->next=Icurr1;
        Ilast1=Icurr1;
        Icurr1->next=NULL;
    }

    strcpy(Icurr1->ins_type,s1);
    Icurr1->injured_cover=p1;
    Icurr1->death_cover=p2;
    Icurr1->damage_cover=p3;
    strcpy(Icurr1->ch_deduct,s3);
    Icurr1->ins_premium=p5;

    Icurr1->ori_inj_cover=p6;
    Icurr1->ori_dea_cover=p7;
    Icurr1->ori_dam_cover=p8;
    Icurr1->ori_deduct=p9;
    Icurr1->ori_premium=p10;
    Icurr1->qcoverage=p11;
    Icurr1->qserial=p12;
    Icurr1->qday=p13;

    strcpy(Icurr1->nins_type1,s2);

    rows++;

    return SUCCESS;
}


/*****************************************************************/
int Delete_INS_TYPE (Iptr)
struct INS_TYPE *Iptr;
{
    strcpy(Iptr->ins_type,"**");
    printf("----------Delete_INS_TYPE() ins_type[%s]\n",Iptr->ins_type);
    rows--;
}
/*****************************************************************/
int Scan_INS_TYPE (itype)        /* return data in Icurr */
int itype;
{
    Icurr=Ifirst;
    while (Icurr)
    {
        if (atoi(Icurr->ins_type)==itype) return SUCCESS;
        Icurr=Icurr->next;
    }
    return FAIL;
}

/*****************************************************************/
int Scan_INS_TYPE1 (itype)        /* return data in Icurr */
int itype;                        /* for sug and ori version */
{
    Icurr=Ifirst;
    while (Icurr)
    {
        if( (atoi(Icurr->ins_type)==itype) &&
            (Icurr->sug_iins_type == sug_type))
        {
            return SUCCESS;
        }
        Icurr=Icurr->next;
    }
    return FAIL;
}
/*****************************************************************/

/* 102.07.01 */
int SetCarAge(frate2)
char *frate2;
{
    char  issue_ymd[12];         /* extend CY/MM to CY/MM/DD */
    char  datestring[16], yy[4], mm[3], dd[3], yy2[4], mm2[3];
    int   yy1,mm1,yy3,mm3,t_short_prate;
    long  issue_date;
    $int  count_x=0;
    $char v_frate2[4];
    $double pdepreciate_year = 0.0,pdep_rate_year_honda=0.0;;

    printf("SetCarAge()>>>>>frate2[%s]\n",frate2);
    printf("SetCarAge()>>>>>cal_way[%s] ply_period[%s]\n",cal_way,qply_period);

    strcpy(v_frate2,frate2);

    /*** STEP 9 -- a. ; here we calculate car_age, year_dep ...etc.  ***/
    if (*cal_way=='M')
    {
      if (iSecondYear2 > 0){
        $SELECT prate INTO $short_prate
           FROM short_period_rate
          WHERE qperiod=$iSecondYear2;
        if (NOT_FOUND)  return M_CA_NSHORT_RATE;
        short_prate=short_prate/100.0;
      }else{
        $SELECT prate INTO $short_prate
           FROM short_period_rate
          WHERE qperiod=$qply_period;
        if (NOT_FOUND)  return M_CA_NSHORT_RATE;
        short_prate=short_prate/100.0;
      }

      #ifdef PRINTF_FLAG
          printf("cal_way[%s]\n",cal_way);
          printf("iSecondYear2[%d]\n",iSecondYear2);
          printf("qply_period[%d]\n",qply_period);
      #endif
    } else {
        short_prate=(double)(dply_end-dply_begin)/365.0;
        t_short_prate = short_prate *  100;
        short_prate = t_short_prate / 100.0;
    }

    /*** STEP 9 -- b. ***/
    if(strcmp(car_typei,"CS") == 0)
    {
    	car_age=0;
    	car_age_mth=0;
    	flag_new=TRUE;
    }
    else
    {
    	cm_long_split_3ymd(dissue,yy,mm,dd);
    	sprintf_s(issue_ymd,sizeof issue_ymd,"%s/%s/01",yy,mm);
    	issue_date=cm_ymd_cdate(issue_ymd);
    	car_age=DiffMonth(dply_begin,issue_date);

    	#ifdef PRINTF_FLAG
    	printf(" ------- dply_begin = [%ld]\n " , dply_begin);
    	printf(" ------- issue_date = [%ld]\n " , issue_date);
    	printf(" ------- car_age = [%d]\n " , car_age);
    	#endif

    	car_age_mth=car_age % 12;
    	printf(" ------- car_age_mth = [%d]\n " , car_age_mth);

    	yy3=atoi(yy); /* �o�Ӧ~(����)*/
    	mm3=atoi(mm); /* �o�Ӥ�*/

    	/** for flag_new **/
    	strcpy(datestring,cm_cdate_str_100(dply_begin));
    	cm_split_ymd_100(datestring,yy,mm,dd);
    	yy1=atoi(yy); /* �O��ͮĦ~(����)*/
    	int_ply_yr=yy1+1911; /* int_ply_yr for iins_type 11, 851024-mag */
    	mm1=atoi(mm); /* �O��ͮĤ� */

    	if (yy1-yy3>0 || (yy3-yy1==0 && mm1-mm3>=0))
    		flag_new=TRUE;
    	else flag_new=FALSE;

    	printf("Setcarage�� yy3[%d],yy1[%d],mm3[%d],mm1[%d]\n",yy3,yy1,mm3,mm1);
    }


    /*** STEP 9 -- c. ***/
    /* 1020808, �����ЫO�N�B�ŦX���w�t���A������I�ئb�e��(�� ca302q01s.ec�G�j�M "f_Honda_dep")�ϥίS�����²v�A�̫���[�W��E������ */
    pdep_rate_year_honda = 0.0;
    if (f_Honda_dep == 'Y'){
    	$SELECT (engname::DECIMAL(5,2))/100.0  Into $pdep_rate_year_honda
    	   FROM car_code
    	  WHERE kind   = 'P0'
    	    AND detail = $dep_Honda
    	    AND chiname::integer =12;

    	#ifdef PRINTF_FLAG
    	printf("����,�~��:dep_Honda=[%s]pdep_rate_year_honda=[%f]\n",dep_Honda,pdep_rate_year_honda);
    	#endif
    }

    /* 1020808, �����ЫO�N�B�ŦX���w�t���ϥίS�����²v�A���O�ѵs�I�վ�]�l�������A��~���²v���ϥζO�v�]�w�����²v�A���l�~�O�ϥΥ��Ч��²v*/
    /* 102.07.01, ���o�Ө��ؤ� "�~���²v", ��� car116�]�w*/
    /* �ۭt�v�N��>=79�_, ���UZ����,���²v=15%(�ȥH�ۥΨ����²v�N��) add by sylia 105.03.17  */
    pdepreciate_year = 0.0; pdep_rate_year = 0.0;

    if (atoi(v_frate2) >= 79)
    {
    	if (f_provision_Z == 'Y')
    	{
    		/* ��Z���� */
    		$SELECT a.pdepreciate/100.0 Into $pdepreciate_year
        	   FROM depreciation_rate a
        	  WHERE a.fcar_class = '4'
         	    AND a.qperiod_end = 12
          	    AND a.drate = (SELECT drate FROM ca_rate_date
        	                    WHERE itable = 'depreciation_rate' AND icode = $v_frate2 ) ;
	}
	else if ((f_provision_P == 'Y')||(f_sug_P == 'Y'))
	{
		/* ��P����,���²v=15% add by 061476 (1071226006_SC3) */
	    	$SELECT a.pdepreciate/100.0 Into $pdepreciate_year
        	   FROM depreciation_rate a
        	  WHERE a.fcar_class = '6'
         	    AND a.qperiod_end = 12
          	    AND a.drate = (SELECT drate FROM ca_rate_date
        	                    WHERE itable = 'depreciation_rate' AND icode = $v_frate2 ) ;
	}
	else if (f_provision_Q == 'Y')
	{
		/* ��Q����,���²v=20% add by 061476 (1071226006_SC3) */
	    	$SELECT a.pdepreciate/100.0 Into $pdepreciate_year
        	   FROM depreciation_rate a
        	  WHERE a.fcar_class = '7'
         	    AND a.qperiod_end = 12
          	    AND a.drate = (SELECT drate FROM ca_rate_date
        	                    WHERE itable = 'depreciation_rate' AND icode = $v_frate2 ) ;
	}
	else if (f_provision_M == 'Y')
	{
		/* ��M����,���²v=25% add by 061476 (1081105005_SC3) */
	    	$SELECT a.pdepreciate/100.0 Into $pdepreciate_year
        	   FROM depreciation_rate a
        	  WHERE a.fcar_class = '8'
         	    AND a.qperiod_end = 12
          	    AND a.drate = (SELECT drate FROM ca_rate_date
        	                    WHERE itable = 'depreciation_rate' AND icode = $v_frate2 ) ;
	}
	else
	{
	    	$SELECT a.pdepreciate/100.0 Into $pdepreciate_year
	    	   FROM depreciation_rate a, car_type b
	    	  WHERE a.fcar_class =
	    	        ( CASE WHEN b.icar_grp = '1' then '3'
	    	          ELSE b.fcar_class END )
	    	    AND b.fclass = '1' AND b.icode = $car_typei
	    	    AND a.qperiod_end = 12
	    	    AND a.drate = (SELECT drate FROM ca_rate_date
	    	                    WHERE itable = 'depreciation_rate' AND icode = $v_frate2 ) ;
	}
    }
    else
    {
		$SELECT a.pdepreciate/100.0 Into $pdepreciate_year
		   FROM depreciation_rate a ,car_type b
		  WHERE a.fcar_class =
		        ( CASE WHEN b.icar_grp = '1' then '3'
		          ELSE b.fcar_class END )
    	            AND b.fclass = '1' AND b.icode = $car_typei
    	            AND a.qperiod_end = 12
    	            AND a.drate = (SELECT drate FROM ca_rate_date
    	                            WHERE itable = 'depreciation_rate' AND icode = $v_frate2 ) ;
    }
    if (SQLCODE==SQLNOTFOUND) return M_CA_NDEPRE_RATE;

    pdep_rate_year = pdepreciate_year;

    if(strcmp(car_typei,"CS") == 0){
    	year_dep = MyPower(1, car_age/12);
    }else if (f_Honda_dep == 'Y'){
    	year_dep = MyPower(1-pdep_rate_year_honda, car_age/12);
    }else{
    	year_dep = MyPower(1-pdepreciate_year, car_age/12);
    }

    #ifdef PRINTF_FLAG
    printf("########## car_age[%d] car_age_mth[%d]\n",car_age,car_age_mth);
    printf("########## fcar_class[%s] year_dep[%f]\n",fcar_class,year_dep);
    #endif

    if (car_age_mth==0) {
    	pdepreciate=0;
    }else {
    	/* 1020808, �����ЫO�N�B�ŦX���w�t���A������I�ئb�e��(�� ca302q01s.ec�G�j�M "f_Honda_dep")�ϥίS�����²v�A�̫���[�W��E������ */
    	/* ���B�O�p�����²v, ���H car_age_mth �Ө����²v  modify by sylvia 103.06.17 (�\���q���ק�) */
    	if (f_Honda_dep == 'Y'){
    		$SELECT MAX(engname::DECIMAL(5,2)), count(*)
    		   INTO $pdepreciate, $count_x
    		   FROM car_code
    		  WHERE kind   = 'P0'
    		    AND detail = $dep_Honda
    		    AND chiname::integer >= $car_age_mth AND detail2::integer < $car_age_mth;

    		#ifdef PRINTF_FLAG
    		printf("����,���:pdepreciate=[%f]dep_Honda=[%s]car_age_mth=[%d]\n",pdepreciate,dep_Honda,car_age_mth);
    		#endif
    	}else{
    		/*102.07.01 ����²v�G*/
    		if (f_provision_Z == 'Y')
    		{
    			$SELECT MAX(a.pdepreciate), count(*)
    			   INTO $pdepreciate, $count_x
    			   FROM depreciation_rate a ,car_type b
    			  WHERE a.fcar_class = '4'
    			    AND b.fclass = '1' AND b.icode = $car_typei
    			    AND a.qperiod_end >= $car_age_mth AND a.qperiod_bgn < $car_age_mth
    			    AND a.drate = (SELECT drate FROM ca_rate_date
    			                    WHERE itable = 'depreciation_rate' AND icode = $v_frate2 ) ;
    		}
    		else if ((f_provision_P == 'Y')||(f_sug_P == 'Y'))
    		{
    			$SELECT MAX(a.pdepreciate), count(*)
    			   INTO $pdepreciate, $count_x
    			   FROM depreciation_rate a ,car_type b
    			  WHERE a.fcar_class = '6'
    			    AND b.fclass = '1' AND b.icode = $car_typei
    			    AND a.qperiod_end >= $car_age_mth AND a.qperiod_bgn < $car_age_mth
    			    AND a.drate = (SELECT drate FROM ca_rate_date
			 	            WHERE itable = 'depreciation_rate' AND icode = $v_frate2 ) ;
		}
		else if (f_provision_Q == 'Y')
		{
			$SELECT MAX(a.pdepreciate), count(*)
			   INTO $pdepreciate, $count_x
			   FROM depreciation_rate a ,car_type b
			  WHERE a.fcar_class = '7'
			    AND b.fclass = '1' AND b.icode = $car_typei
			    AND a.qperiod_end >= $car_age_mth AND a.qperiod_bgn < $car_age_mth
			    AND a.drate = (SELECT drate FROM ca_rate_date
			 	            WHERE itable = 'depreciation_rate' AND icode = $v_frate2 ) ;
		}
		else if (f_provision_M == 'Y')
		{
			$SELECT MAX(a.pdepreciate), count(*)
			   INTO $pdepreciate, $count_x
			   FROM depreciation_rate a ,car_type b
			  WHERE a.fcar_class = '8'
			    AND b.fclass = '1' AND b.icode = $car_typei
			    AND a.qperiod_end >= $car_age_mth AND a.qperiod_bgn < $car_age_mth
			    AND a.drate = (SELECT drate FROM ca_rate_date
			 	            WHERE itable = 'depreciation_rate' AND icode = $v_frate2 ) ;
		}
		else
		{
			$SELECT MAX(a.pdepreciate), count(*)
			   INTO $pdepreciate, $count_x
			   FROM depreciation_rate a ,car_type b
			  WHERE a.fcar_class=
			        ( CASE WHEN b.icar_grp = '1' then  '3'
			               ELSE b.fcar_class END )
			                AND b.fclass = '1' AND b.icode = $car_typei
			                AND a.qperiod_end >= $car_age_mth AND a.qperiod_bgn < $car_age_mth
			                AND a.drate = (SELECT drate FROM ca_rate_date
			 	                        WHERE itable = 'depreciation_rate' AND icode = $v_frate2 ) ;
		}
	}

        if (count_x == 0)  return M_CA_NDEPRE_RATE;
        pdepreciate=pdepreciate/100.0;
    }

  /* cover_01_tmp = car_price*10000.0*year_dep*(1.0-pdepreciate); */ /* �t�X�e�u�ק� modify by sylvia 103.07.21 */
  /* cover_01_tmp = (long)d45(car_price*10000.0*year_dep*(1.0-pdepreciate),0); *//*�t�X�e�u�ק� modify by sylvia 104.06.16*/
  cover_01_tmp = (long)floor(car_price*10000.0*year_dep*(1.0-pdepreciate)+ 0.000000001); /*�t�X�e�u�ק� modify by 061476 104.06.16 (1061205001_SC3)*/
  thousand_cover_01 = cover_01_tmp % 1000;
  if (thousand_cover_01 != 0) {
  	cover_01 = (cover_01_tmp)-(thousand_cover_01);
  } else {
  	cover_01 = cover_01_tmp;
  }

  #ifdef PRINTF_FLAG
  printf("## Cover_01_tmp[%ld] thou_cover_01[%ld] Cover_01[%ld]\n",cover_01_tmp,thousand_cover_01,cover_01);
  #endif
/*** STEP 9 -- d. ***/

    return SUCCESS;

}

/*************************************************************************************************/
/* 102.08.01 [E����]
  �Y�h�~���l�I���uE���ڡv�A�h��O�J�p�ɡA��u�վ����O�O�B�v�p��覡���G
  �Y�h�~�D�u���O��G�վ����O�O�B = [�h�~�O�B * (1-�~���²v)] (���ܤd��)
�ܭY�h�~���u���O��G�վ����O�O�B = [�h�~�O�B * (1-����²v)] (���ܤd��)

 �i�ѵs�I�j(11)�B�i�ѵs�l���I�ҫ�-�ѵs�j(96)  ��O�O�B ���u�վ����O�O�B�v
  �E[�ۥΨ�] 03�B04�B19�B21�B22���ءF[��~��] 07�B08�B14�B15���ءA
    �O�O�p�⤽�������u�վ�]�l�v���u���l�v�����A���קאּ�G

     �վ�]�l = �վ����O�O�B �� [���m���ȡ�(1.0 �� �~���²v) ���¦~�� (<= ���¦~�Ƭ����� )
                ~~~~~~~~~~~~~~
                  => cover_01
  102.08.08
   1. ���Х�  (�D�q���N���GCAC1P)
   2. ���²v�̤U�C����(�t���N��)�i��վ�
         ���²v�G15%	CRV(�t���N��C804*)�BACCORD(�t���N��C802*)�BCIVIC(�t���N��C803*)�BFIT����(�t���N��C805*)
         ���²v�G25%	INSIGHT(�t���N��94030500)�BCRZ(�t���N��94030600)
   3. �ŦX�W�z����(�t���N��)�̡A�䨮�l�I�����I�ص��O����E������
   4. ���ЯS������²v�]�w��car140 �A���O�N���GP0

*/
void SetCover_For_Prov_E(cover_last)
long cover_last;
{

    $int    count_x=0;
    long    thousand_res=0, tmp_cover_01=0;
    $double pdepreciate_pre=0.0;

    #ifdef PRINTF_FLAG
        printf("trace SetCover_For_Prov_E()\n ");
        printf("trace qply_period_pre[%d]\n ",qply_period_pre);
    #endif

    /* �����ЫO�N�B�ŦX���w�t���A������I�ئb�e��(�� ca302q01s.ec�G�j�M "f_Honda_dep")����E�����ڡA�B�ϥίS�����²v */
    if (f_Honda_dep == 'Y'){ /* �۶O�v�N��>79�_���A�� */
	    $SELECT MAX(engname::DECIMAL(5,2)), count(*)
	       INTO $pdepreciate_pre, $count_x
	       FROM car_code
	      WHERE kind   = 'P0'
	        AND detail = $dep_Honda
	        AND chiname::integer >= $qply_period_pre AND detail2::integer < $qply_period_pre;
    }
    else
    {
    	if (f_provision_Z == 'Y') /* ��Z���� add by sylvia 105.08.06 (1050531005_C1) */
    	{
    		$SELECT MAX(a.pdepreciate), count(*)
    		   INTO $pdepreciate_pre, $count_x
    		   FROM depreciation_rate a ,car_type b
    		  WHERE a.fcar_class= '4'
    		    AND b.fclass = '1' AND b.icode = $car_typei
    		    AND a.qperiod_end >= $qply_period_pre AND a.qperiod_bgn < $qply_period_pre
    		    AND a.drate = (SELECT drate FROM ca_rate_date
    		                    WHERE itable = 'depreciation_rate' AND icode = $tmp_frate2 ) ;
	}
	else if ((f_provision_P == 'Y')||(f_sug_P == 'Y'))
	{
		$SELECT MAX(a.pdepreciate), count(*)
    		   INTO $pdepreciate_pre, $count_x
    		   FROM depreciation_rate a ,car_type b
    		  WHERE a.fcar_class= '6'
    		    AND b.fclass = '1' AND b.icode = $car_typei
    		    AND a.qperiod_end >= $qply_period_pre AND a.qperiod_bgn < $qply_period_pre
    		    AND a.drate = (SELECT drate FROM ca_rate_date
    		                    WHERE itable = 'depreciation_rate' AND icode = $tmp_frate2 ) ;
	}
	else if (f_provision_Q == 'Y')
	{
		$SELECT MAX(a.pdepreciate), count(*)
    		   INTO $pdepreciate_pre, $count_x
    		   FROM depreciation_rate a ,car_type b
    		  WHERE a.fcar_class= '7'
    		    AND b.fclass = '1' AND b.icode = $car_typei
    		    AND a.qperiod_end >= $qply_period_pre AND a.qperiod_bgn < $qply_period_pre
    		    AND a.drate = (SELECT drate FROM ca_rate_date
    		                    WHERE itable = 'depreciation_rate' AND icode = $tmp_frate2 ) ;
	}
	else if (f_provision_M == 'Y')
	{
		$SELECT MAX(a.pdepreciate), count(*)
    		   INTO $pdepreciate_pre, $count_x
    		   FROM depreciation_rate a ,car_type b
    		  WHERE a.fcar_class= '8'
    		    AND b.fclass = '1' AND b.icode = $car_typei
    		    AND a.qperiod_end >= $qply_period_pre AND a.qperiod_bgn < $qply_period_pre
    		    AND a.drate = (SELECT drate FROM ca_rate_date
    		                    WHERE itable = 'depreciation_rate' AND icode = $tmp_frate2 ) ;
	}
        else
        {
        	$SELECT MAX(a.pdepreciate), count(*)
        	   INTO $pdepreciate_pre, $count_x
        	   FROM depreciation_rate a ,car_type b
        	  WHERE a.fcar_class=
        	        ( CASE WHEN b.icar_grp = '1' then  '3'
        	          else b.fcar_class END )
        	    AND b.fclass = '1' AND b.icode = $car_typei
        	    AND a.qperiod_end >= $qply_period_pre AND a.qperiod_bgn < $qply_period_pre
        	    AND a.drate = (SELECT drate FROM ca_rate_date
        	                    WHERE itable = 'depreciation_rate' AND icode = $tmp_frate2 ) ;
        }
    }
    if (count_x == 0)  return M_CA_NDEPRE_RATE;

    pdepreciate_pre=pdepreciate_pre/100.0;

    #ifdef PRINTF_FLAG
        printf("trace pdepreciate_pre[%f]\n ",pdepreciate_pre);
        printf("trace cover_last[%ld]\n ",cover_last);
    #endif

    tmp_cover_01 = (cover_last) * (1.0-pdepreciate_pre);
	thousand_res = tmp_cover_01 % 1000;
	cover_01 = tmp_cover_01 - thousand_res;

    #ifdef PRINTF_FLAG
	    printf(" cover_01[%ld]\n ",cover_01);
    #endif
}
/*****************************************************************/
/* �t�X198�I�دS���B�z�p��u��ڲ{�����ȡv add by 061476 (1091103004_SC1) */
int SetCover_198(frate2)
char *frate2;
{
    char  issue_ymd[12],pro_ymd[12];         /* extend CY/MM to CY/MM/DD */
    char  datestring[16], yy[4], mm[3], dd[3], yy2[4], mm2[3], yy_pro[4], mm_pro[3];
    int   yy1,mm1,yy3,mm3,yy4,mm4,t_short_prate;
    long  issue_date,pro_date;
    $int  count_x=0;
    $char v_frate2[4];
    $double pdepreciate_year = 0.0;
    $double year_dep_198 = 0.0; /*add by 071004 (1110222005_SC1_198�I�M11�I���²v���ۦP�A11�I�O�O�p�⤣���T�ץ�)*/


    printf("SetCover_198()>>>>>frate2[%s]\n",frate2);
    printf("SetCover_198()>>>>>cal_way[%s] ply_period[%s]\n",cal_way,qply_period);
    printf("198���­p��: �s�y�~[%s]�s�y��[%d]",pro_year,qpro_month);
    strcpy(v_frate2,frate2);

    /*** STEP 9 -- a. ; here we calculate car_age, year_dep ...etc.  ***/
    if (*cal_way=='M')
    {
    	if (iSecondYear2 > 0){
    		$SELECT prate INTO $short_prate
    		   FROM short_period_rate
    		  WHERE qperiod=$iSecondYear2;
    		if (NOT_FOUND)  return M_CA_NSHORT_RATE;
    		short_prate=short_prate/100.0;
    	}else{
    		$SELECT prate INTO $short_prate
    		   FROM short_period_rate
    		  WHERE qperiod=$qply_period;
    		if (NOT_FOUND)  return M_CA_NSHORT_RATE;
    		short_prate=short_prate/100.0;
    	}

    	#ifdef PRINTF_FLAG
    	printf("SetCover_198---cal_way[%s]\n",cal_way);
    	printf("SetCover_198---iSecondYear2[%d]\n",iSecondYear2);
    	printf("SetCover_198---qply_period[%d]\n",qply_period);
    	#endif
    }else{
    	short_prate=(double)(dply_end-dply_begin)/365.0;
        t_short_prate = short_prate *  100;
        short_prate = t_short_prate / 100.0;
    }

    /*** STEP 9 -- b. ***/
    cm_long_split_3ymd(dissue,yy,mm,dd);
    sprintf_s(issue_ymd,sizeof issue_ymd,"%s/%s/01",yy,mm); /*�o��*/

    sprintf_s(yy_pro,sizeof yy_pro,"%d",atoi(pro_year)-1911);
    sprintf_s(mm_pro,sizeof mm_pro,"%02d",qpro_month);
    sprintf_s(pro_ymd,sizeof pro_ymd,"%s/%s/01",yy_pro,mm_pro); /*�s�y*/

    issue_date=cm_ymd_cdate(issue_ymd);
    pro_date=cm_ymd_cdate(pro_ymd);

    /*��H�s�y�~������(1110802013_SC1_���~�T��E53-198�I�O�B�����ˮֳW�h�ץ�)*/
    /*car_age=DiffMonth(dply_begin,issue_date);*/
    car_age=DiffMonth(dply_begin,pro_date);

    /*#ifdef PRINTF_FLAG*/
    printf(" --SetCover_198----- dply_begin = [%ld]\n " , dply_begin);
    printf(" --SetCover_198----- issue_date = [%ld]\n " , issue_date);
    printf(" --SetCover_198----- pro_date = [%ld]\n " , pro_date);
    printf(" --SetCover_198----- car_age = [%d]\n " , car_age);
    /*#endif*/
    car_age_mth=car_age % 12;
    printf(" --SetCover_198----- car_age_mth = [%d]\n " , car_age_mth);

    yy3=atoi(yy); /* �o�Ӧ~(����)*/
    mm3=atoi(mm); /* �o�Ӥ�*/

    yy4=atoi(yy_pro); /* �s�y�~(����)*/
    mm4=atoi(mm_pro); /* �s�y��*/

    /** for flag_new **/
    strcpy(datestring,cm_cdate_str_100(dply_begin));
    cm_split_ymd_100(datestring,yy,mm,dd);
    yy1=atoi(yy); /* �O��ͮĦ~(����)*/
    int_ply_yr=yy1+1911; /* int_ply_yr for iins_type 11, 851024-mag */
    mm1=atoi(mm); /* �O��ͮĤ� */

    if (yy1-yy4>0 || (yy4-yy1==0 && mm1-mm4>=0))
        flag_new=TRUE;
    else
        flag_new=FALSE;

    /*** STEP 9 -- c. ***/
    pdepreciate_year = 0.0; /*pdep_rate_year = 0.0;*/

    if (fcar_class[0] == '1')
    {   /* �ۥΨ��H15%���­p�� */
    	$SELECT a.pdepreciate/100.0 Into $pdepreciate_year
    	   FROM depreciation_rate a
    	  WHERE a.fcar_class = '6'
    	    AND a.qperiod_end = 12
    	    AND a.drate = (SELECT drate FROM ca_rate_date
    	                    WHERE itable = 'depreciation_rate' AND icode = $v_frate2 ) ;
    }else{
    	/* ��~���H20%���­p�� */
    	$SELECT a.pdepreciate/100.0 Into $pdepreciate_year
    	   FROM depreciation_rate a
    	  WHERE a.fcar_class = '7'
    	    AND a.qperiod_end = 12
    	    AND a.drate = (SELECT drate FROM ca_rate_date
    	                    WHERE itable = 'depreciation_rate' AND icode = $v_frate2 ) ;
    }

    if (SQLCODE==SQLNOTFOUND) return M_CA_NDEPRE_RATE;

    /*pdep_rate_year = pdepreciate_year;*/  /*mark by 071004 (1110222005_SC1_198�I�M11�I���²v���ۦP�A11�I�O�O�p�⤣���T�ץ�)*/
    year_dep_198 = MyPower(1-pdepreciate_year, car_age/12);

    #ifdef PRINTF_FLAG
    printf("##SetCover_198######## car_age[%d] car_age_mth[%d]\n",car_age,car_age_mth);
    printf("##SetCover_198######## fcar_class[%s] year_dep_198[%f]\n",fcar_class,year_dep_198);
    #endif

    if (car_age_mth==0){
    	pdepreciate=0;
    } else {
    	/*102.07.01 ����²v�G*/
    	if (fcar_class[0] == '1')
    	{
    		$SELECT MAX(a.pdepreciate), count(*)
    		   INTO $pdepreciate, $count_x
    		   FROM depreciation_rate a ,car_type b
    		  WHERE a.fcar_class = '6'
    		    AND b.fclass = '1' AND b.icode = $car_typei
    		    AND a.qperiod_end >= $car_age_mth AND a.qperiod_bgn < $car_age_mth
    		    AND a.drate = (SELECT drate FROM ca_rate_date
    		                    WHERE itable = 'depreciation_rate' AND icode = $v_frate2 ) ;
    	}else{
    		$SELECT MAX(a.pdepreciate), count(*)
    		   INTO $pdepreciate, $count_x
    		   FROM depreciation_rate a ,car_type b
    		  WHERE a.fcar_class = '7'
    		    AND b.fclass = '1' AND b.icode = $car_typei
    		    AND a.qperiod_end >= $car_age_mth AND a.qperiod_bgn < $car_age_mth
    		    AND a.drate = (SELECT drate FROM ca_rate_date
    		                    WHERE itable = 'depreciation_rate' AND icode = $v_frate2 ) ;
    	}
    	if (count_x == 0)  return M_CA_NDEPRE_RATE;
        pdepreciate=pdepreciate/100.0;
    }

    cover_198_tmp = (long)floor(car_price*10000.0*year_dep_198*(1.0-pdepreciate)+ 0.000000001); /*�t�X�e�u�ק� modify by 061476 104.06.16 (1061205001_SC3)*/
    thousand_cover_198 = cover_198_tmp % 1000;
    if (thousand_cover_198 != 0) {
    	cover_198 = (cover_198_tmp)-(thousand_cover_198);
    } else {
    	cover_198 = cover_198_tmp;
    }
    #ifdef PRINTF_FLAG
    printf("##SetCover_198 Cover_198_tmp[%ld] thou_cover_198[%ld] Cover_198[%ld]\n",cover_198_tmp,thousand_cover_198,cover_198);
    #endif

    return SUCCESS;

}
/*************************************************************************************************/
int SetFactor()     /** calculate aa, bb2, cc, dd, ee1, ee2 **/
{
    int   car_age_yr, int_icode, flag_cnt=0;
    $char icode[3];
    $char ch[1+1];


    /* ���ִ�O */
    car_age_yr=car_age/12;
    $DECLARE cur_1 CURSOR FOR
      SELECT icode,palign INTO $icode,$aa
        FROM alignment WHERE fclass='5'
       ORDER BY icode DESC; /* AND MAX(icode)<=$car_age_year;*/
    $OPEN cur_1;
    $FETCH cur_1;
    if (NOT_FOUND) return M_CA_NALIGN_5;
    while (sqlca.sqlcode ==0) {
           int_icode=atoi(icode);
           if (int_icode <= car_age_yr) {
               flag_cnt++;
               break;
           }
           $FETCH cur_1;
    }
    if (flag_cnt==0) aa=0;
    aa=aa/100.0;

    ee1=dmg_align_1/100.0; /* ���l�I�h�����u�� */
    ee2=lia_align_1/100.0; /* ���d�I�h�����u�� */
    ee3=brg_align_1/100.0; /* ���d�I�h�����u�� */

    return SUCCESS;
}


/*****************************************************************/
int Calculate_cover_prem(ins_ptr,ical_ins,fcal_class,iins)
struct INS_TYPE *ins_ptr;
char *ical_ins, *fcal_class;
int iins;
{
    long    low_dmg_cover, high_dmg_cover;
    long    prem0203=0;
    int     adj_age;
    double  adj_yr_dep,high_coef, pdmg_acc_bak, punknown_acc_bak;
    long    tmp_cover_dep, cover_dep, thousand_cover_dep;
    double  pure_premium;
    $char   s_ins[INSURANCE_TYPE], tmp_provision[22];
    $long   chk_count;
    $double tmppure105=0.0,tmppure85 =0.0,tmppure118 =0.0,
            tmppure152=0.0,tmppure153=0.0,tmppure160 =0.0;
    $long   tmpcover_1=0;

     printf(">>>>> into Calculate_cover_prem()[%d]\n",iins);
    #ifdef PRINTF_FLAG
    printf(">>>>> into Calculate_cover_prem()\n");
    #endif

    sprintf_s(s_ins,sizeof s_ins,"%02d",iins);
    strcpy( s_ins,trim(s_ins));
    strcpy(tmp_provision,"");
    sprintf_s(tmp_provision,sizeof tmp_provision,"%s;",trim(ins_ptr->provision)); /* ���� */

    /* 102.08.26 �s�W �s�A��(105) �I�� */
    /* 1030811 �s�W�ߦw����A��(118),��������A��(120),�Ҧ�A��(122)  add by sylvia
       (1030725001_C4�B1030806001_C5) */
    if (iins==1 || iins==5 || iins==8 || iins==9 || iins==85 || iins==105 ||
        iins==118 || iins==120 || iins==122 || iins==125 || iins==126 ||
        iins==152 || iins==153 || iins==201 || iins==205 || iins==209)
    {
        /* 102.11.12 */
    	if (ins_ptr->sug_iins_type==0){
    	    #ifdef PRINTF_FLAG
    	    printf("trace ori iins [%ld]\n ",iins);
    	    printf("pdmg_acc_ori[%f]\n",pdmg_acc_ori);
            #endif

            pdmg_acc = pdmg_acc_ori;

            punknown_acc = punknown_acc_ori;

        }else{

            #ifdef PRINTF_FLAG
        	    printf("trace sug iins [%ld]\n ",iins);
                printf("pdmg_acc_sug[%f]\n",pdmg_acc_sug);
            #endif
            pdmg_acc = pdmg_acc_sug;
            punknown_acc = punknown_acc_sug;
        }

	    /* 980520,�j�v���[���ڤ��Ҽ{�F�Ƭ���(�j�v�ȳB�z�@���)    */
	    /* �������[���ڤ��Ҽ{�F�Ƭ����A���k�s�A���}function�A�٭� */
	    /* 101.06.25 */
	    if(strstr(tmp_provision,"F;") != NULL){
	        pdmg_acc_bak = pdmg_acc;
	        pdmg_acc = 0;

	        punknown_acc_bak = punknown_acc;
	        punknown_acc = 0;
	    }

	    /* G���ڤ��F���� add by sylvia 105.08.06 (1050705002_C3) */
	    if(strstr(tmp_provision,"G;") != NULL){
	        pdmg_acc_bak = pdmg_acc;
	        pdmg_acc = 0;

	        punknown_acc_bak = punknown_acc;
	        punknown_acc = 0;
	    }

	    if(strstr(tmp_provision,"B;") != NULL){
	       if (((ibig_comp[0]==' ')||(ibig_comp[0]=='')||(ibig_comp[0]=='\0'))&&(iofficer[0] != 'W')){
	           pdmg_acc_bak = pdmg_acc;
	           pdmg_acc = 0;

	           punknown_acc_bak = punknown_acc;
	           punknown_acc = 0;
	       }
	    }
    }
    if ((IsBlankNull(ical_ins)) || (iins == 152 || iins == 153 )) /* �D�I */
    {
        /*---------------------------------------------*/
        low_dmg_cover=(long)cover_01*0.9;
        high_dmg_cover=(long)cover_01*1.1;

        #ifdef PRINTF_FLAG
        printf("======= low_dmg[%ld] high_dmg[%ld]\n",low_dmg_cover,high_dmg_cover);
        #endif

        /* 102.08.26 �s�W105�I�ءA�ȾA�� 03 04 19 21 22����*/
        /* 1030811 �s�W�ߦw����A��(118),��������A��(120),�Ҧ�A��(122)  add by sylvia
       (1030725001_C4�B1030806001_C5) */
        /*---------------------------------------------*/
        if (iins==1 || iins==5 || iins==9 || iins==8 || iins==85 || iins==105 ||
            iins==118 || iins==120 || iins==122 || iins==125 || iins==126 ||
            iins==201 || iins==205 || iins==209)
        {
            #ifdef PRINTF_FLAG
            printf("######����flag_new[%d],cover_01[%d]\n",flag_new,cover_01);
            printf("ins_ptr->damage_cover[%d]\n",ins_ptr->damage_cover);
            #endif

            /* �O�B */
            tmpcover_1 = ins_ptr->injured_cover;
            ins_ptr->injured_cover=0;
            ins_ptr->death_cover=0;

            /* *********************************************************************************************************************
               102.08.26
               �s�A�������I =
               �]�����I�«O�O�ϡi���B�������l�«O�I�O�j�^�� �Q�O�I�T���s�y�~�פζO�v�N���Y�� �� �]�~�֩ʧO�Y�ơ� �ߴڬ����Y�ơ^

               101.04.20 ,85�I�بϥηs�¤��� flag�AflgIns85 ="1" ���ܨϥηs����
               �­p���k :
                  �I�������򥻯«O�I�O �� �Q�O�I�T���s�y�~�פζO�v�N���Y�� �� (�~�֩ʧO�Y�� + �ߴڬ����Y��) + �i���B�������l�«O�I�O�j

               �s�­p���k�� flgIns85 �ȫ��w(�s)(��)�������l :
                  (�«O�I�O �� �Q�O�I�T���s�y�~�פζO�v�N���Y�� +(�s)�������l) �� (�~�֩ʧO�Y�� + �ߴڬ����Y��) + (��)�������l)

                  �YflgIns85[0] ='1' : (��)�������l = 0 => �Y�s����
                  �YflgIns85[0] ='0' : (�s)�������l = 0 => �Y�¤���
            *************************************************************************************************************************/
            tmppure105 = 0.00 ;   tmppure85 = 0.00;  tmppure118 = 0.00;
            if ((iins==85)|| (iins==105) || (iins==118))
            {
            	 /* �I��85���������l�����ݭn�q�O�B�O�O�ɤ���X�򥻫O�O,�A�[�W����������I�O�O */
                 $SELECT mpremium,  mpremium,    mpremium,    pextra_charge/100
                    INTO $tmppure85,$tmppure105, $tmppure118, $pextra_charge
                    FROM cover_vs_premium
                   WHERE icar_type  = $cal_car_id
                     AND iins_type  = $s_ins
                     AND mcoverage1 = $tmpcover_1
                     AND drate      = (SELECT drate
                                         FROM ca_rate_date
                                        WHERE icode=$tmp_frate2
                                          AND itable='cover_vs_premium');

                 if (SQLCODE == SQLNOTFOUND) return M_CA_NCOVER_PREM;

                 #ifdef PRINTF_FLAG
                 printf("Trace -- tmppure85 = [%f] \n",  tmppure85);
                 printf("Trace -- tmppure105 = [%f] \n",  tmppure105);
                 printf("Trace -- tmppure118 = [%f] \n",  tmppure118);
                 #endif

                 if (iins==105){
               	     tmppure85  = 0.00;
               	     tmppure118  = 0.00;
                 }
                 else if (iins==118){
                     tmppure85  = 0.00;
               	     tmppure105  = 0.00;
                 }
                 else {
                     tmppure105  = 0.00;
               	     tmppure118  = 0.00;
                 }
            }

            /* 102.08.01 [E����]
              �Y�h�~���l�I���uE���ڡv�A�h��O�J�p�ɡA��u�վ����O�O�B�v�p��覡���G
          	  �Y�h�~�D�u���O��G�վ����O�O�B = [�h�~�O�B * (1-�~���²v)] (���ܤd��)
        �� 	  �Y�h�~���u���O��G�վ����O�O�B = [�h�~�O�B * (1-����²v)] (���ܤd��)
            */
            if (strstr(tmp_provision, "E;") != NULL) {
		        SetCover_For_Prov_E(ins_ptr->damage_cover);
            }
            /* K���ڬ��������B���[���ڡA�O�B�̬��w�ӫD���� add by 061476(1080408008_SC3)*/
            if(strstr(tmp_provision,"K;") == NULL){
            	if (flag_new==TRUE) {
            		ins_ptr->damage_cover = cover_01;
            	} else {
            		ins_ptr->damage_cover = cover_01;
            	/*
                if (ins_ptr->damage_cover==0) {
                    ins_ptr->damage_cover = cover_01;
                } else {
                    if (ins_ptr->damage_cover < low_dmg_cover ||
                        ins_ptr->damage_cover > high_dmg_cover )
                        ins_ptr->damage_cover = cover_01;
                }*/
                }
                damage_cover_01=ins_ptr->damage_cover;
            }

            #ifdef PRINTF_FLAG
            printf("#####��changed ins_ptr_damage_cover[%d]\n",ins_ptr->damage_cover);
            #endif
            if(damage_cover_01<=1200000)
              high_coef=1.00;
            else if((damage_cover_01>=1200001)&&(damage_cover_01<=1800000))
              high_coef=0.95;
            else if(damage_cover_01>=1800001)
              high_coef=0.90;
            prem0203=damage_cover_01*0.00045;

            /* �O�O */
            #ifdef PRINTF_FLAG
            printf("01@@@@@ mprem[%f] dmg_factor[%f]\n",mprem,dmg_factor);
           /* printf("01@@@@@ psex_age_damage[%f] pdmg_acc[%f]\n",psex_age_damage,pdmg_acc);*/
            printf("01@@@@@ prate_1[%f] short_prate[%f]\n",prate_1,short_prate);
            printf("01@@@@@ aa[%f] ee1[%f]\n",aa,ee1);
            printf("01@@@@@ car_price[%f] bb11[%f]\n",car_price,bb11);
            printf("01@@@@@ car_price[%f] bb11[%f]\n",car_price,bb11);
            printf("01@@@@@ high_coef[%f],prem0203[%d]\n",high_coef,prem0203);
            #endif

            /* 1. 4A,2B,9A���ئۥ�==>��~
               2. �t�t�X�e�u,�վ��²�ƫO�O�p��{��,��{���ƥ���U��
                  ²�Ƨ@�k:
                  ����:03,04,21,22,2C,19,9B(�ۥ�)�B07,08,14,15,2A,8A,4A,2B,9A(��~) ==> �򥻫O�Ox�O�v�N���Y��x (�ʧO�~�֫Y��+�ߴڬ����Y��)
                                                                                        (�Y�� ��~�� �� �k�H,  �ʧO�~�֫Y�� = 1 )
                  ��L����: ���m���� �� �򥻶O�v �� ( 1 + �t�P���t�[��O�Y��) �� ( 1 + ���ִ�O�Y�� + �ߴڬ����Y�� )

                modify by sylvia 105.01.12 (1041221009_C3) */
            if ((fcar_class[0]=='2')||(strcmp(cal_car_id,"19")==0)||(strcmp(cal_car_id,"9A")==0)||(strcmp(cal_car_id,"9B")==0)) /* ��~����19���� */
            {
                psex_age_damage = 1.0;
            }
            else
            {
                if (assuredf[0]=='1' || assuredf[0]== '3' || assuredf[0] == '5')
                {
                    /* �۵M�H */
                    #ifdef PRINTF_FLAG
    		    printf("PREM=mprem*dmg_factor*(psex_age_damage+pdmg_acc)*short_prate*(1+ee1)\n");
    		    printf("Trace1 -- s_ins = [%s] \n",  s_ins);
    		    #endif

    		    psex_age_damage = 1.0;
    		    psex_age_notfound3 = 1;

                    for (chk_count=0 ; chk_count<max_ca_sex_age_factor ; chk_count++)
    		    {
    		        if ((strcmp(ca_sex_age_factor[chk_count].fcard_class, s_ins) == 0) &&
    			    (strcmp(ca_sex_age_factor[chk_count].fsex, wsex) == 0) &&
    			    (ca_sex_age_factor[chk_count].qage_bgn <= age) &&
    			    (ca_sex_age_factor[chk_count].qage_end > age) &&
    			    (strcmp(ca_sex_age_factor[chk_count].frate, tmp_frate2) == 0))
                        {

    			    psex_age_notfound3  = 0;
    			    psex_age_damage = ca_sex_age_factor[chk_count].pfactor;

                            #ifdef PRINTF_FLAG
        		    printf("in Trace -- s_ins = [%s] \n",  s_ins);
        		    printf("in Trace -- tmp_frate2 = [%s] \n",  tmp_frate2);
        		    printf("in Trace -- age = [%f] \n",  age);
        		    printf("in Trace -- wsex = [%s] \n",  wsex);
        		    printf("in 01@@@@@ psex_age_damage[%f] pdmg_acc[%f]\n",psex_age_damage,pdmg_acc);
        		    printf("Trace -- ins1589_chg_flag = [%d] \n",  ins1589_chg_flag);
    			    #endif
    	                    break;
                        }
                    }
    		    #ifdef PRINTF_FLAG
                    printf("Trace -- psex_age_notfound3 = [%d] \n",  psex_age_notfound3);
                    #endif

    		    if(psex_age_notfound3==1)
    		    {
    		        ins_ptr->ins_premium=0;
    		        ins_ptr->bef_ins_premium=0;

    		        /*�䤣��ʧO�~�֫Y�ƮɡA�������^��M_CA_NSEX_AGE_FACTOR�A���{���~�򩹤U���A�ϸ�ƥi�H�g�Jpolicy_302f
    		          ��̤j���ӭp��O�O(�]���q�`�O�]���~�֤�car122�]�w���٭n�j�~�|�䤣��)�A���n�k���bE43���~ */
    		        /*�d�L�~�֫Y�ƮɡA�������p�J�p���\�A�վ�E43�]�w�W�h(1110601012_SC1)*/
    		        /*return M_CA_NSEX_AGE_FACTOR;*/



    		        $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$s_ins,'�~�֩ʧO�Y�Ƥ��s�b','1','E43',$iofficer);

    		        $SELECT FIRST 1 a.pfactor
    		           INTO $psex_age_damage
                           FROM ca_sex_age_factor a , ca_rate_date b
                          WHERE a.drate = b.drate
                            AND a.fcard_class =$s_ins
                            AND b.itable = 'ca_sex_age_factor3'
                            AND b.icode = $tmp_frate2 AND fsex = $wsex ORDER BY qage_end desc;

                        if (SQLCODE == SQLNOTFOUND) psex_age_damage = 1.0 ;

    		    }
    		    else
    		    {
    		        if (ins1589_chg_flag==1 )
    		        { /* �쥻09=>��ĳ05 */
    		            if (iins==9 || iins==209)
    		            {
    		                psex_age_damage_ori = psex_age_damage;
    		            }
    		            else if (iins==5 || iins==205)
    		            {
    		        	psex_age_damage_sug = psex_age_damage;;
    		            }
    		        }
    		        else if (ins1589_chg_flag==2 )
    		        { /* �쥻05=>��ĳ105 */
    		            if (iins==5 || iins==205)
    		            {
    		                psex_age_damage_ori = psex_age_damage;
    		            }
    		            else if (iins==105)
    		            {
    		        	psex_age_damage_sug = psex_age_damage;;
    		            }
    		        }
    		        else if (ins1589_chg_flag==3 )
    		        { /* �쥻85=>��ĳ105 */
    		            if (iins==85)
    		            {
    		                psex_age_damage_ori = psex_age_damage;
    		            }
    		            else if (iins==105)
    		            {
    		        	psex_age_damage_sug = psex_age_damage;;
    		            }
    		        }
    		        else if (ins1589_chg_flag==5 )
    		        { /* �쥻05=>��ĳ118 */
    		            if (iins==5 || iins==205)
    		            {
    		                psex_age_damage_ori = psex_age_damage;
    		            }
    		            else if (iins==118)
    		            {
    		                psex_age_damage_sug = psex_age_damage;;
    		            }
    		        }
    		        else if (ins1589_chg_flag==6 )
    		        { /* �쥻105=>��ĳ118 */
    		            if (iins==105)
    		            {
    		                psex_age_damage_ori = psex_age_damage;
    		            }
    		            else if (iins==118)
    		            {
    		        	psex_age_damage_sug = psex_age_damage;;
    		            }
    		        }
    		        else if (ins1589_chg_flag==7 )
    		        { /* �쥻09=>��ĳ120 */
    		            if (iins==9 || iins==209)
    		            {
    		                psex_age_damage_ori = psex_age_damage;
    		            }
    		            else if (iins==120)
    		            {
    		                psex_age_damage_sug = psex_age_damage;;
    		            }
    		        }
    		        else if (ins1589_chg_flag==8 )
    		        { /* �쥻01=>��ĳ122 */
    		            if (iins==1 || iins==201)
    		            {
    		                psex_age_damage_ori = psex_age_damage;
    		            }
    		            else if (iins==122)
    		            {
    		        	psex_age_damage_sug = psex_age_damage;
    		            }
    		        }
    		    }
                }
                else if (assuredf[0]=='2' || assuredf[0]== '4' || assuredf[0]== '6' )
                {
                    /* �k�H */
    		    #ifdef PRINTF_FLAG
    		    printf("PREM=mprem*dmg_factor*(1+pdmg_acc)*short_prate*(1+ee1)\n");
    		    #endif
                    psex_age_damage = 1.0;
    	        }
    	    }

            if (strcmp(cal_car_id,"03")==0 || strcmp(cal_car_id,"04")==0 ||
                strcmp(cal_car_id,"19")==0 || strcmp(cal_car_id,"21")==0 ||
                strcmp(cal_car_id,"22")==0 ||(ISNEW_CAR1(cal_car_id))    ||
                strcmp(cal_car_id,"07")==0 || strcmp(cal_car_id,"08")==0 ||
                strcmp(cal_car_id,"14")==0 || strcmp(cal_car_id,"15")==0 ||
                (ISNEW_CAR2(cal_car_id)))
            {
                ins_ptr->pure_prem     = ((mprem+tmppure105+tmppure118)*dmg_factor+tmppure85)*(psex_age_damage+pdmg_acc)*short_prate;  /* �«O�O-���t�������[�O */
		ins_ptr->ins_premium     = ((mprem+tmppure105+tmppure118)*dmg_factor+tmppure85)*(psex_age_damage+pdmg_acc)*ins_ptr->pcar_price*short_prate;        /*** round ***/
		ins_ptr->bef_ins_premium = ((mprem+tmppure105+tmppure118)*dmg_factor+tmppure85)*(psex_age_damage+pdmg_acc)*ins_ptr->pcar_price*short_prate;        /*** round ***/
            }
            else
            {
                ins_ptr->pure_prem     = (car_price*10000.0*prate_1+tmppure85+tmppure105+tmppure118)*(1+bb11)*(1+aa+pdmg_acc)*short_prate;      /*** round ***/
	        ins_ptr->ins_premium     = (car_price*10000.0*prate_1+tmppure85+tmppure105+tmppure118)*(1+bb11)*(1+aa+pdmg_acc)*ins_ptr->pcar_price*short_prate;      /*** round ***/
		ins_ptr->bef_ins_premium = (car_price*10000.0*prate_1+tmppure85+tmppure105+tmppure118)*(1+bb11)*(1+aa+pdmg_acc)*ins_ptr->pcar_price*short_prate;  /*** round ***/
            }

            if ((iins==85)|| (iins==105)|| (iins==118))
            {

                #ifdef PRINTF_FLAG
                printf("after ins_premium[%f],bef_ins_prem[%f]\n",ins_ptr->ins_premium,ins_ptr->bef_ins_premium);
                #endif
                /*�����I�|�N�O�B�@�G�M���s,��85�I�حn�O�d�O�B�@*/
                ins_ptr->injured_cover =  tmpcover_1;
            }
            /* premium_01 = ins_ptr->ins_premium;*/

	    #ifdef PRINTF_FLAG
	    printf("01@@@@@ ins_premium[%f]\n",ins_ptr->ins_premium);
	    #endif

        }
        else if ((iins==152) || (iins==153)) /* add by sylvia 105.12.30 */
        {
            /* �O�B */
            tmpcover_1 = ins_ptr->damage_cover;
            ins_ptr->injured_cover=0;
            ins_ptr->death_cover=0;

            tmppure152 = 0.00 ;   tmppure153 = 0.00;

            /* �������l�«O�O */
            $SELECT mpremium,  mpremium, pextra_charge/100
               INTO $tmppure152,$tmppure153, $pextra_charge
               FROM cover_vs_premium
              WHERE icar_type  = $cal_car_id
                AND iins_type  = $s_ins
                AND mcoverage1 = $tmpcover_1
                AND drate      = (SELECT drate
                                    FROM ca_rate_date
                                   WHERE icode=$tmp_frate2
                                     AND itable='cover_vs_premium');

            if (SQLCODE == SQLNOTFOUND) return M_CA_NCOVER_PREM;

            if (iins==152) tmppure153  = 0.00;
            if (iins==153) tmppure152  = 0.00;
            damage_cover_01=ins_ptr->damage_cover;

            /* �O�O */
            if ((fcar_class[0]=='2')||(strcmp(cal_car_id,"19")==0)||(strcmp(cal_car_id,"9A")==0)||(strcmp(cal_car_id,"9B")==0)) /* ��~����19���� */
            {
                psex_age_damage = 1.0;
            }
            else
            {
                if (assuredf[0]=='1' || assuredf[0]== '3' || assuredf[0] == '5')
                {
                    /* �۵M�H */
    		    psex_age_damage = 1.0;
    		    psex_age_notfound3 = 1;
                    for (chk_count=0 ; chk_count<max_ca_sex_age_factor ; chk_count++)
    		    {
    		        if ((strcmp(ca_sex_age_factor[chk_count].fcard_class, s_ins) == 0) &&
    			    (strcmp(ca_sex_age_factor[chk_count].fsex, wsex) == 0) &&
    			    (ca_sex_age_factor[chk_count].qage_bgn <= age) &&
    			    (ca_sex_age_factor[chk_count].qage_end > age) &&
    			    (strcmp(ca_sex_age_factor[chk_count].frate, tmp_frate2) == 0))
                        {
    			    psex_age_notfound3  = 0;
    			    psex_age_damage = ca_sex_age_factor[chk_count].pfactor;
    	                    break;
                        }
                    }

    		    if(psex_age_notfound3==1)
    		    {
    		        ins_ptr->ins_premium=0;
    		        ins_ptr->bef_ins_premium=0;

    		        /*�䤣��ʧO�~�֫Y�ƮɡA�������^��M_CA_NSEX_AGE_FACTOR�A
    		          ����̱��񪺨ӭp��O�O�A���n�k���bE43���~�A���{���~�򩹤U���A�ϸ�Ƽg�Jpolicy_302f*/
    		        /*�d�L�~�֫Y�ƮɡA�������p�J�p���\�A�վ�E43�]�w�W�h(1110601012_SC1)*/
    		        /*return M_CA_NSEX_AGE_FACTOR;*/

    		        $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$s_ins,'�~�֩ʧO�Y�Ƥ��s�b','1','E43',$iofficer);

    		        $SELECT FIRST 1 a.pfactor
    		           INTO $psex_age_damage
                           FROM ca_sex_age_factor a , ca_rate_date b
                          WHERE a.drate = b.drate
                            AND a.fcard_class =$s_ins
                            AND b.itable = 'ca_sex_age_factor3'
                            AND b.icode = $tmp_frate2 AND fsex = $wsex ORDER BY qage_end desc;

                        if (SQLCODE == SQLNOTFOUND) psex_age_damage = 1.0 ;
    		    }
    		    else
    		    {
                        psex_age_damage_ori = psex_age_damage;
                        psex_age_damage_sug = psex_age_damage;
    		    }
                }
                else if (assuredf[0]=='2' || assuredf[0]== '4' || assuredf[0]== '6' )
                {
                    /* �k�H */
    		    psex_age_damage = 1.0;
    	        }
    	    }

            if (strcmp(cal_car_id,"03")==0 || strcmp(cal_car_id,"04")==0 ||
                strcmp(cal_car_id,"19")==0 || strcmp(cal_car_id,"21")==0 ||
                strcmp(cal_car_id,"22")==0 ||(ISNEW_CAR1(cal_car_id))    ||
                strcmp(cal_car_id,"07")==0 || strcmp(cal_car_id,"08")==0 ||
                strcmp(cal_car_id,"14")==0 || strcmp(cal_car_id,"15")==0 ||
                (ISNEW_CAR2(cal_car_id)))
            {
                ins_ptr->pure_prem       = (tmppure152 * dmg_factor + tmppure153)*(psex_age_damage+punknown_acc)*short_prate;  /* �«O�O-���t�������[�O */
		ins_ptr->ins_premium     = (tmppure152 * dmg_factor + tmppure153)*(psex_age_damage+punknown_acc)*ins_ptr->pcar_price*short_prate;        /*** round ***/
		ins_ptr->bef_ins_premium = (tmppure152 * dmg_factor + tmppure153)*(psex_age_damage+punknown_acc)*ins_ptr->pcar_price*short_prate;        /*** round ***/
            }
            else
            {
                ins_ptr->pure_prem       = (car_price*10000.0*prate_1+tmppure153+tmppure152)*(1+bb11)*(1+aa+punknown_acc)*short_prate;      /*** round ***/
	        ins_ptr->ins_premium     = (car_price*10000.0*prate_1+tmppure153+tmppure152)*(1+bb11)*(1+aa+punknown_acc)*ins_ptr->pcar_price*short_prate;      /*** round ***/
		ins_ptr->bef_ins_premium = (car_price*10000.0*prate_1+tmppure153+tmppure152)*(1+bb11)*(1+aa+punknown_acc)*ins_ptr->pcar_price*short_prate;  /*** round ***/
            }
        }
        else if ((iins==11) || (iins==211) || (iins==96) || (iins==129)) /* 101.04.30*/
        {
            /* �O�B */
            ins_ptr->injured_cover=0;
            ins_ptr->death_cover=0;

            /* 102.08.01 [E����]
              �Y�h�~���l�I���uE���ڡv�A�h��O�J�p�ɡA��u�վ����O�O�B�v�p��覡���G
          	  �Y�h�~�D�u���O��G�վ����O�O�B = [�h�~�O�B * (1-�~���²v)] (���ܤd��)
        �� 	  �Y�h�~���u���O��G�վ����O�O�B = [�h�~�O�B * (1-����²v)] (���ܤd��)
            */
            if (strstr(tmp_provision, "E;") != NULL) {
		        SetCover_For_Prov_E(ins_ptr->damage_cover);
            }

            /* damage_cover of '11' always equal to damage_cover of '01' */
            #ifdef PRINTF_FLAG
            printf("��11 damage_cover_01[%d],cover_01[%d]\n",damage_cover_01, cover_01);
            printf("ins_ptr->provision-lib[%s]\n",ins_ptr->provision);
            #endif

            /* car9612252 �����ѵs�O�B�p�� */
            if (damage_cover_01==0)
            {
                ins_ptr->damage_cover = cover_01;
            }
            else
            {
                ins_ptr->damage_cover=damage_cover_01;

                /* �ѵs�I�O�B=�����I�O�B  ���Y�����I�S��E����,�ѵs�]����E���ڭp�� modify by sylvia 103.09.15 */
                if (damage_cover_01 < cover_01)
                {
                	/* �����I�O�B<�ѵs�I�O�B,���ܨ����I�LE����,�ѵs�I��E����, �G�n�����ѵs�I��E���� */
                	strcpy(ins_ptr->provision, "");
                }
                else if (damage_cover_01 > cover_01)
                {
                	/* �����I�O�B<�ѵs�I�O�B,���ܨ����I�LE����,�ѵs�I��E����, �G�n�����ѵs�I��E���� */
                	strcpy(ins_ptr->provision, "E");
                }
                cover_01=damage_cover_01; /* �O�O�p��Ϊ��O�B */
            }

            /* �O�O */

	    #ifdef PRINTF_FLAG
	    printf("11@@@@@ prate_1[%f] short_prate[%f]\n",prate_1,short_prate);
	    printf("11@@@@@ bb12[%f] ee3[%f]\n",bb12,ee3);
	    printf("ins_ptr->provision-lib[%s]\n",ins_ptr->provision);
	    #endif

 /***********************************************************************/
 /* 861209-mag                                                          */
 /*              �ӫD(cover_01/cover_dep)-->for other insurance company */
 /***********************************************************************/

            if (fcar_class[0]=='1') /* �ۥΨ� */
            {
                if (strcmp(cal_car_id,"03")==0 ||
                    strcmp(cal_car_id,"04")==0 ||
                    strcmp(cal_car_id,"19")==0 ||
                    strcmp(cal_car_id,"21")==0 ||
                    strcmp(cal_car_id,"22")==0 || (ISNEW_CAR1(cal_car_id)))
                {
				    #ifdef PRINTF_FLAG
				    printf("11@@@@@, int_ply_yr[%d] atoi:cal_pro_year[%d]\n",int_ply_yr,atoi(cal_pro_year));
				    #endif

				    adj_age=int_ply_yr-atoi(pro_year);
                    if (adj_age > 4) adj_age = 4;

                    /* 1020808, ���ЫO�N�B�ŦX���w�t���ϥίS�����²v�A���O�ѵs�I�վ�]�l������(cover_dep)�A��~���²v���ϥζO�v�]�w�����²v*/
                    /* 102.07.01 */
                    /*adj_yr_dep=MyPower(0.75,adj_age);*/
                    adj_yr_dep = MyPower(1-pdep_rate_year, adj_age);

				    #ifdef PRINTF_FLAG
				    printf("11@@@@@, adj_age[%d] adj_yr_dep[%f]\n",adj_age,adj_yr_dep);
				    #endif

                    /* 108.02.12 C�B�z�p�Ʀ�ƪ���ǫפ����A�|�ɭP�O�O���@�P�A�����ץ��P�X��ۦP modify by 061476 (1061205001_SC4) */
                    /* tmp_cover_dep = (int)(car_price*10000.0*adj_yr_dep); */
                    tmp_cover_dep = (long)(car_price*10000.0*adj_yr_dep + 0.000000001);
                    thousand_cover_dep = tmp_cover_dep % 1000;
                    if (thousand_cover_dep != 0) {
                        cover_dep = (tmp_cover_dep)-(thousand_cover_dep);
                    } else {
                        cover_dep = tmp_cover_dep;
                    }
				    #ifdef PRINTF_FLAG
				    printf("11@@@@@, cover_dep[%d]\n",cover_dep);
				    printf("11@@@@@ car_price[%f] brg_factor[%f]\n",car_price,brg_factor);
				    printf("PREM=car_price*prate_1*short_prate*brg_factor*(1+ee3)\n");
				    printf("                      *(cover_01/cover_dep)\n");
				    #endif
                    ins_ptr->ins_premium    =car_price*10000.0*prate_1*short_prate*brg_factor*((double)cover_01/cover_dep); /*** round ***/
                    ins_ptr->bef_ins_premium=car_price*10000.0*prate_1*short_prate*brg_factor*((double)cover_01/cover_dep); /*** round ***/
				    #ifdef PRINTF_FLAG
				    printf("11----- ins_premium[%f]\n",ins_ptr->ins_premium);
				    #endif

                } else {
				    #ifdef PRINTF_FLAG
				    printf("11@@@@@ damage[%d]\n",ins_ptr->damage_cover);
				    printf("damage_cover*prate_1*short_prate*(1+bb12)*(1+ee3)\n");
				    #endif
                    ins_ptr->ins_premium    =(ins_ptr->damage_cover)*prate_1*short_prate*(1+bb12); /*** round ***/
                    ins_ptr->bef_ins_premium=(ins_ptr->damage_cover)*prate_1*short_prate*(1+bb12); /*** round ***/
                }
            } else { /* ��~�� */
                if (strcmp(cal_car_id,"07")==0 ||
                    strcmp(cal_car_id,"08")==0 ||
                    strcmp(cal_car_id,"14")==0 ||
                    strcmp(cal_car_id,"15")==0 || (ISNEW_CAR2(cal_car_id)))
                {
                    adj_age=int_ply_yr-atoi(pro_year);
                    if (adj_age >  4)adj_age = 4;

                    /* 102.07.01 */
                    /*adj_yr_dep=MyPower(0.70,adj_age);*/
                    adj_yr_dep = MyPower(1-pdep_rate_year, adj_age);

                    /* 108.02.12 C�B�z�p�Ʀ�ƪ���ǫפ����A�|�ɭP�O�O���@�P�A�����ץ��P�X��ۦP modify by 061476 (1061205001_SC4) */
                    /* tmp_cover_dep = (int)(car_price*10000.0*adj_yr_dep); */
                    tmp_cover_dep = (long)(car_price*10000.0*adj_yr_dep + 0.000000001);
                    thousand_cover_dep = tmp_cover_dep % 1000;
                    if (thousand_cover_dep != 0) {
                        cover_dep = (tmp_cover_dep)-(thousand_cover_dep);
                    } else {
                        cover_dep = tmp_cover_dep;
                    }
				    #ifdef PRINTF_FLAG
				    printf("adj_age[%d]\n",adj_age);
				    printf("11@@@@@, cover_dep[%d]\n",cover_dep);
                    printf("## cover_01[%ld] \n",cover_01);
				    printf("11@@@@@ car_price[%f] brg_factor[%f]\n",car_price,brg_factor);
				    printf("11@@@@@ adj_yr_dep[%f]\n",adj_yr_dep);

				    printf("PREM=car_price*prate_1*short_prate*brg_factor*(1+ee3)\n");
				    printf("                      *(cover_01/cover_dep)\n");
				    #endif

                    /* 980306 fix*/
                    ins_ptr->ins_premium    =car_price*10000.0*prate_1*short_prate*brg_factor*((double)cover_01/cover_dep); /*** round ***/
                    ins_ptr->bef_ins_premium=car_price*10000.0*prate_1*short_prate*brg_factor*((double)cover_01/cover_dep); /*** round ***/
                } else {
                    ins_ptr->ins_premium    =(ins_ptr->damage_cover)*prate_1*short_prate*(1+bb12);    /*** round ***/
                    ins_ptr->bef_ins_premium=(ins_ptr->damage_cover)*prate_1*short_prate*(1+bb12) ;   /*** round ***/
                }
            }

		    #ifdef PRINTF_FLAG
		    printf("11@@@@@ ins_premium[%f]\n",ins_ptr->ins_premium);
		    #endif
            /* for calculate premium of iins_type='12' */
            premium_11=ins_ptr->damage_cover*short_prate+0.005;
		    #ifdef PRINTF_FLAG
		    printf("11@@@@@ premium_11[%d] FOR iins 12\n",premium_11);
		    #endif
        }
        else if (iins==18)   /*   940210  */
        {
            /* �O�B */
            ins_ptr->injured_cover = 0;
            ins_ptr->death_cover   = 0;

            /* 102.08.01 [E����]
              �Y�h�~���l�I���uE���ڡv�A�h��O�J�p�ɡA��u�վ����O�O�B�v�p��覡���G
          	  �Y�h�~�D�u���O��G�վ����O�O�B = [�h�~�O�B * (1-�~���²v)] (���ܤd��)
        �� 	  �Y�h�~���u���O��G�վ����O�O�B = [�h�~�O�B * (1-����²v)] (���ܤd��)
            */
           if (strstr(tmp_provision, "E;") != NULL) {
             	SetCover_For_Prov_E(ins_ptr->damage_cover);
			}
            ins_ptr->damage_cover=cover_01;
            /* damage_cover of '11' always equal to damage_cover of '01' */
            /************************************************************************
            if (damage_cover_01==0)
            {
                if (ins_ptr->damage_cover < low_dmg_cover ||
                    ins_ptr->damage_cover > high_dmg_cover )
                {
                    ins_ptr->damage_cover=cover_01;
                }
            }
            else
            {
                ins_ptr->damage_cover=damage_cover_01;
            }
            **************************************************************************/

            ins_ptr->ins_premium     = (double)(ins_ptr->damage_cover)*prate_1*short_prate;
            ins_ptr->bef_ins_premium = (double)(ins_ptr->damage_cover)*prate_1*short_prate;

            #ifdef PRINTF_FLAG
            printf("18@@@@@ ins_premium[%lf]\n",ins_ptr->ins_premium);
            printf("18@@@@@ bef_ins_premium[%lf]\n",ins_ptr->bef_ins_premium);
            #endif
            /* for calculate premium of iins_type='12' */
            premium_11 = ins_ptr->damage_cover*short_prate+0.005;
            /***
            premium_12 = ins_ptr->damage_cover+0.005;
            printf("18@@@@@ premium_11[%d],premium_12[%d] FOR iins 12\n",premium_11,premium_12);
            ***/
        }
        else if (iins==25)
        {
                /************FOR CKI---861211**********/
		    #ifdef PRINTF_FLAG
		    printf("25@@@@@ prate_1[%f] short_prate[%f]\n",prate_1,short_prate);
		    #endif

            ins_ptr->death_cover=0;

            ins_ptr->ins_premium=ins_ptr->injured_cover*prate_1
            *((float)ins_ptr->damage_cover/(float)ins_ptr->injured_cover)
            *short_prate;         /*** round ***/

            ins_ptr->bef_ins_premium=ins_ptr->injured_cover*prate_1
            *((float)ins_ptr->damage_cover/(float)ins_ptr->injured_cover)
            *short_prate;         /*** round ***/

	        #ifdef PRINTF_FLAG
	        printf("25@@@@@ ins_premium[%f]\n",ins_ptr->ins_premium);
	        #endif

        }
        else if  (iins==20 || iins==23) /* 990406 */
        {

            ins_ptr->injured_cover   = 0;
            ins_ptr->death_cover     = 0;
            #ifdef PRINTF_FLAG
            printf("iins==[%d] ,cover_01[%ld] ins_ptr->provision=[%s]ins_ptr->damage_cover=[%ld]\n", iins, cover_01,ins_ptr->provision,ins_ptr->damage_cover);
            #endif
            /* E�����ˮֽվ�(20,23,86�i���[E����,�����ˮ֫O�B) modify by sylvia 103.05.30 (1030324001_C3) */
              /*�Y�h�~���l�I���uE���ڡv�A�h��O�J�p�ɡA��u�վ����O�O�B�v�p��覡���G
          	  �Y�h�~�D�u���O��G�վ����O�O�B = [�h�~�O�B * (1-�~���²v)] (���ܤd��)
        �� 	  �Y�h�~���u���O��G�վ����O�O�B = [�h�~�O�B * (1-����²v)] (���ܤd��)  */
            /*if (strstr( ins_ptr->provision, "E") != NULL)
            {
		         SetCover_For_Prov_E(ins_ptr->damage_cover);
		         ins_ptr->damage_cover=cover_01;

		         printf("1211E:iins==[%d] ,cover_01[%ld] ins_ptr->provision=[%s]ins_ptr->damage_cover=[%ld]\n", iins, cover_01,ins_ptr->provision,ins_ptr->damage_cover);
            }
            else
            { */
            if (iins==20){
                /* �����C��0.1�U����� mark by sylvia 106.07.03 (1060627005_C1) */
   	            if ( ins_ptr->damage_cover >= high_dmg_cover )
   	            {
   	                ins_ptr->damage_cover=cover_01;
   	            }
   	            /* else if( ins_ptr->damage_cover == 0)
   	                ins_ptr->damage_cover=cover_01; */
   	        }else{
   	        	/* 990406,�|�ݭק�, iins==23 , 23�I�ثO�B�T���o�j�󭫸m������75%  */
   	            if ( ins_ptr->damage_cover >= high_dmg_cover )
   	            {
   	                ins_ptr->damage_cover=cover_01;
   	            }
   	            else if( ins_ptr->damage_cover == 0)
   	                ins_ptr->damage_cover=cover_01;
   	        }
   	      /*} */
   	        #ifdef PRINTF_FLAG
            printf("ins_ptr->damage_cover[%ld]\n",ins_ptr->damage_cover);
            #endif
            ins_ptr->ins_premium     = (double)ins_ptr->damage_cover*prate_1*short_prate;  /*** round ***/
            ins_ptr->bef_ins_premium = (double)ins_ptr->damage_cover*prate_1*short_prate;  /*** round ***/


        } else if (iins == 111) {
            if(qply_period <= 12 ){       /* <= 1�~ */
            	ins_ptr->ins_premium  = (double)ins_ptr->damage_cover*prate_1*short_prate;  /*** round ***/
            	ins_ptr->bef_ins_premium = ins_ptr->ins_premium ;
            }else if( qply_period == 24 ){  /* 1�~11�Ӥ�H�W��2�~�� */
                prate_1_sec = prate_1_sec/100;  /* bug�ץ�:�]car106�]�w���O�ʤ���,�ҥH�^���X�Ӫ��٭n�A���H100 add by sylvia 105.12.07 */
                ins_ptr->ins_premium  = (double)ins_ptr->damage_cover*prate_1_sec;
                ins_ptr->bef_ins_premium = ins_ptr->ins_premium ;
            }else if((qply_period > 12) && (qply_period < 24)){  /* �j��1�~�B �p�� 1�~11�Ӥ� */
                double ins_premium_1st, ins_premium_sec;
                prate_1_sec = prate_1_sec/100;  /* bug�ץ�:�]car106�]�w���O�ʤ���,�ҥH�^���X�Ӫ��٭n�A���H100 add by sylvia 105.12.07 */
                ins_premium_1st  = (double)ins_ptr->damage_cover*prate_1;
                ins_premium_sec  = (double)ins_ptr->damage_cover*prate_1_sec;
                ins_ptr->ins_premium = ins_premium_1st +
	                               ((ins_premium_sec-ins_premium_1st) * (qply_period-12)/12.0);
	        ins_ptr->bef_ins_premium = ins_ptr->ins_premium ;
            }
        }else {
            ins_ptr->injured_cover=0;
            ins_ptr->death_cover=0;

            ins_ptr->ins_premium   =ins_ptr->damage_cover*prate_1*short_prate;      /*** round ***/
            ins_ptr->bef_ins_premium=ins_ptr->damage_cover*prate_1*short_prate;  /*** round ***/
        }
    } else if ((strcmp(trim(ical_ins),"01")==0)||(strcmp(trim(ical_ins),"125")==0)) {   /* 02,03,04.... ���[�I */
            if (! Scan_INS_TYPE(1))
            	if (! Scan_INS_TYPE(5))
            	    if (! Scan_INS_TYPE(9))
                        if (!Scan_INS_TYPE(8))
                            if (!Scan_INS_TYPE(85))
                                if (!Scan_INS_TYPE(86))
                                    if (!Scan_INS_TYPE(98))
                                	if (!Scan_INS_TYPE(105))
                                	    if (!Scan_INS_TYPE(118))
                                	        if (!Scan_INS_TYPE(120))
                                	            if (!Scan_INS_TYPE(122))
                                	                if (!Scan_INS_TYPE(125))
                                	                    if (!Scan_INS_TYPE(126))
                                	                        if (!Scan_INS_TYPE(181))
                                	                            if (!Scan_INS_TYPE(198))
                                	                            	if (!Scan_INS_TYPE(201))
                                	                            	    if (!Scan_INS_TYPE(205))
                                	                            	        if (!Scan_INS_TYPE(209))
                                                return M_CA_INS01;
            ins_ptr->injured_cover=Icurr->injured_cover;
            ins_ptr->death_cover=Icurr->death_cover;
            ins_ptr->damage_cover=Icurr->damage_cover;
            ins_ptr->deduct=0;

            #ifdef PRINTF_FLAG
            printf("\n\n=========== in 01 ���[�I\n");
            printf("iins=[%d]\n", iins );
            #endif
            /*printf("premium_01 =[%f] prate_1=[%f]\n", premium_01 ,prate_1 );*/

            if (*fcal_class=='2')
            {
                if (iins == 10 || iins == 7 || iins == 127 )
                {
                   /* 950704 */
                   /* ����K���«O�O(07)= �����Iñ��O�O x �«O�O�v(0.014) */
                   /*ins_ptr->ins_premium = premium_01*prate_1; */ /*** round ***/
                   #ifdef PRINTF_FLAG
                   printf("premium_10_sug =[%ld] \n", premium_10_sug  );
                   printf("premium_10_ori =[%ld] \n", premium_10_ori  );
                   printf("iins[%d] sug_type[%d]\n",iins,sug_type);
                   #endif
                   /* 971203,�ѨM�����I����ĳ����O�զX�����P�I��(05,09)��,10�I�ت��O�O�p����D */
                   /*        �u�A�Ϋ�ĳ��O�զX��05,���O�զX��09�����p */

                   /* �O�O�p���޿�,��H  round(�D�I�«O�O * ���[�I�«O�O�v / (1-���[�O�βv)) �p��O�O
                      modify by sylvia 103.09.12 (1030523002_C3) */
                   if (sug_type==1)
                   {
                   	   /* if (premium_10_sug > 0){ premium_10  =premium_10_sug;
                   	   }else if (premium_10_ori > 0){ premium_10  =premium_10_ori;  }*/

                   	   if (purprem10_sug > 0)
                   	   {
                   	      purprem10 = purprem10_sug;
                   	   }
                   	   else if (purprem10_ori > 0)
                   	   {
                   	      purprem10 = purprem10_ori;
                   	   }
                   }else{
                   	   /* if (premium_10_ori > 0){  premium_10  =premium_10_ori;
                   	   }else if (premium_10_sug > 0){ premium_10  =premium_10_sug;   } */

                   	   if (purprem10_ori > 0)
                   	   {
                   	      purprem10 = purprem10_ori;
                   	   }
                   	   else if (purprem10_sug > 0)
                   	   {
                   	         purprem10 = purprem10_sug;
                   	   }
                   }
                   /* printf("premium_10 =[%ld] prate_1=[%f]\n", premium_10 ,prate_1 );
                   ins_ptr->ins_premium =(long)((double)premium_10*prate_1+0.5); *//* round */
                   #ifdef PRINTF_FLAG
                   printf("purprem10 =[%f] prate_1=[%f]\n", purprem10 ,prate_1 );
                   #endif
                   /* 127�I�ؤw����A10�B07�I�إ[���D�I�[�O�Y�� add by 061476 (1071226006_SC3)(1081105005_SC3)*/
                   /* 09+K�i���[10�I�ءA�[���D�I��O�Y�� modify by 061476 (1080408008_SC3) */
                   ins_ptr->ins_premium = purprem10 * ins_ptr->pcar_price * provision10_P * provision10_Q * provision10_M * provision10_K * provision10_H * provision10_Y * prate_1; /* round */
                }
                else
                {
                   ins_ptr->ins_premium = Icurr->ins_premium*prate_1;   /*** round ***/
                }
            }
            else
            {
                if (iins==2){
                	ins_ptr->ins_premium=Icurr->damage_cover*prate_1;                            /*** round ***/
                }else if (iins==176 || iins==177) {
                	ins_ptr->ins_premium=Icurr->damage_cover*prate_1;                            /*** round ***/
                	ins_ptr->deduct=cal_deduct;       /* ���ۭt�B�A���P�D�I�@�P  (Icurr->deduct���D�I�ۭt�B�A�ҥH�����) */
                }
                else{
                	ins_ptr->ins_premium=Icurr->damage_cover*prate_1*short_prate;                /*** round ***/
                }
            }
            ins_ptr->bef_ins_premium=ins_ptr->ins_premium;

            #ifdef PRINTF_FLAG
            printf("ins_ptr->ins_premium=[%f]\n", ins_ptr->ins_premium );
            #endif
    } else if (strcmp(trim(ical_ins),"11")==0) {   /* 13,60,130... ���[�I */
        if ((!Scan_INS_TYPE(11)) && (!Scan_INS_TYPE(211)) && (!Scan_INS_TYPE(129))) return M_CA_INS11;

        ins_ptr->injured_cover=Icurr->injured_cover;
        ins_ptr->death_cover=Icurr->death_cover;
        ins_ptr->damage_cover=Icurr->damage_cover;
        ins_ptr->deduct=0;

        if (*fcal_class=='2') {
            /*****
            ins_ptr->ins_premium=Icurr->bef_ins_premium*prate_1+0.5;
            ******/
            /* ins_ptr->ins_premium     = (long)(premium_17*prate_1+0.5); */

            /* �ק�17�I�ثO�O���D 108.07.26 add by 061476 (1080507001_SC2)*/
            if (sug_type==1)
            	purprem17 = purprem17_sug;
            else
            	purprem17 = purprem17_ori;

            /* �O�O�p��אּ: round(�D�I�«O�O * ���[�I�«O�O�v / (1-���[�O�βv))
               ���q�אּ�p��«O�O modify by sylvia 103.09.12*/
            /* 17�I�ض��[��P�BQ�BM���ڥ[�O�Y�� add by 061476 (1071226006_SC3)(1081105005_SC3) */
            if (iins == 17)
                ins_ptr->ins_premium  = purprem17 * provision17_P * provision17_Q * provision17_M * prate_1;
            else
                ins_ptr->ins_premium  = purprem17 * prate_1;

        } else {
            ins_ptr->ins_premium=Icurr->damage_cover*prate_1
                                *short_prate;               /*** round ***/
        }

        /* for calculate premium of iins_type='12' */
        ins_ptr->bef_ins_premium=ins_ptr->ins_premium;
        premium_11=ins_ptr->damage_cover*short_prate+0.005;
    } else if (strcmp(trim(ical_ins),"31")==0) {    /* 24,26 */
        #ifdef PRINTF_FLAG
        printf("INTO 31���[�I 24 \n");
        #endif

        if (! Scan_INS_TYPE1(31))
           if (! Scan_INS_TYPE1(149))
               if (! Scan_INS_TYPE1(231))
                   if (! Scan_INS_TYPE1(249))
                   	if (! Scan_INS_TYPE1(531))
           return M_CA_INS31;

        if (! Scan_INS_TYPE1(31) && ! Scan_INS_TYPE1(32) && ! Scan_INS_TYPE1(231) &&
            ! Scan_INS_TYPE1(232) && ! Scan_INS_TYPE1(531) && ! Scan_INS_TYPE1(532) &&
            (Scan_INS_TYPE1(149) || Scan_INS_TYPE1(249)))
        {
        	injured_cover = Icurr->injured_cover;
        	death_cover   = Icurr->injured_cover;
        	damage_cover  = Icurr->damage_cover;
        	deduct        = Icurr->deduct;
        	ins_premium   = Icurr->ins_premium;
        	pure_premium  = Icurr->pure_prem;
        }
        else
        {
        	injured_cover = Icurr->injured_cover;
        	death_cover   = Icurr->injured_cover;
        	damage_cover  = Icurr->damage_cover;
        	deduct        = Icurr->deduct;
        	ins_premium   = Icurr->ins_premium;
        	pure_premium  = Icurr->pure_prem;

        	if (! Scan_INS_TYPE1(32));
        	injured_cover = injured_cover+Icurr->injured_cover;
        	death_cover   = death_cover+Icurr->injured_cover;
        	damage_cover  = damage_cover+Icurr->damage_cover;
        	deduct        = deduct+Icurr->deduct;
        	ins_premium   = ins_premium+Icurr->ins_premium;
        	pure_premium  = pure_premium + Icurr->pure_prem;

        	if (! Scan_INS_TYPE1(149));
        	injured_cover=injured_cover+Icurr->injured_cover;
        	death_cover=death_cover+Icurr->injured_cover;
        	damage_cover=damage_cover+Icurr->damage_cover;
        	deduct=deduct+Icurr->deduct;
        	ins_premium=ins_premium+Icurr->ins_premium;
        	pure_premium= pure_premium + Icurr->pure_prem;
        }

        ins_ptr->injured_cover=injured_cover;
        ins_ptr->death_cover=death_cover;
        ins_ptr->damage_cover=damage_cover;
        ins_ptr->deduct=deduct;

        #ifdef PRINTF_FLAG
        printf("pure_prem[%f]\n", pure_premium );
        printf("24@@@@@  prate_1[%f] short_prate[%f]\n",prate_1,short_prate);
        printf("Trace -- fcal_class  = [%s] \n",  fcal_class);
        printf("Trace -- premium1_24 = [%ld] \n",  premium1_24);
        #endif

        if (fcal_class[0]=='2') {
	        /* 97.11�J�O�v�ۥѤ� */
	        if( f980101[0] == '1')
	            pextra_charge = ins_ptr->pextra_charge;
	        else
	            ins_ptr->pextra_charge = pextra_charge;

	        /* 100.03 fix 26�I�� */
/*
             ins_ptr->ins_premium     =  dbl_len8(pure_premium*prate_1*short_prate);
             ins_ptr->ins_premium     =  (long)(ins_ptr->ins_premium / (1 - pextra_charge) + 0.5);
             ins_ptr->ins_premium     += (long)(premium1_24*prate_1*short_prate+0.5);
             ins_ptr->bef_ins_premium =  dbl_len8(pure_premium*prate_1*short_prate);
             ins_ptr->bef_ins_premium =  (long)(ins_ptr->bef_ins_premium / (1 - pextra_charge) + 0.5);
             ins_ptr->bef_ins_premium += (long)(premium1_24*prate_1*short_prate+0.5);
*/
             /* �O�O�p��אּ: round(�D�I�«O�O * ���[�I�«O�O�v / (1-���[�O�βv))
               ���q�אּ�p��«O�O modify by sylvia 103.09.12 */

             if (sug_type==0){
                 ins_ptr->ins_premium  =  premium_3132_ori*prate_1*short_prate;                         /*** round ***/
             }else{
             	 ins_ptr->ins_premium  =  premium_3132_sug*prate_1*short_prate;                         /*** round ***/
             }
             /* ins_ptr->ins_premium     =  (long)(dbl_len8(ins_ptr->ins_premium)/(1-pextra_charge)+0.5); */

             /* premium1_24 �w���u���O�O[�Y���N�I���u����] */
             /* ins_ptr->ins_premium     += ((long)((double)premium1_24*prate_1+0.5)); */               /*** round ***/

             if (sug_type==0){
                 ins_ptr->bef_ins_premium =  premium_3132_ori*prate_1*short_prate;                         /*** round ***/
             }else{
             	 ins_ptr->bef_ins_premium =  premium_3132_sug*prate_1*short_prate;                         /*** round ***/
             }
             /* ins_ptr->bef_ins_premium =  (long)(dbl_len8(ins_ptr->bef_ins_premium)/(1-pextra_charge)+0.5); */
             /* ins_ptr->bef_ins_premium += ((long)((double)premium1_24*prate_1+0.5)); */   /*** round ***/


        } else {
            ins_ptr->ins_premium=damage_cover*prate_1*short_prate;
            ins_ptr->bef_ins_premium=ins_ptr->ins_premium;
        }

    #ifdef PRINTF_FLAG
    printf("24@@@@@ ins_premium[%f]\n",ins_ptr->ins_premium);
    #endif
    } else if (strcmp(trim(ical_ins),"133")==0) {
        if (! Scan_INS_TYPE1(133))  return M_CA_INS31;

        injured_cover=Icurr->injured_cover;
        death_cover=Icurr->injured_cover;
        damage_cover=Icurr->damage_cover;
        deduct=Icurr->deduct;
        ins_premium=Icurr->ins_premium;
        pure_premium=Icurr->pure_prem;

        if (! Scan_INS_TYPE1(134));
        injured_cover=injured_cover+Icurr->injured_cover;
        death_cover=death_cover+Icurr->injured_cover;
        damage_cover=damage_cover+Icurr->damage_cover;
        deduct=deduct+Icurr->deduct;
        ins_premium=ins_premium+Icurr->ins_premium;
        pure_premium= pure_premium + Icurr->pure_prem;

        ins_ptr->injured_cover=injured_cover;
        ins_ptr->death_cover=death_cover;
        ins_ptr->damage_cover=damage_cover;
        ins_ptr->deduct=deduct;

        if (fcal_class[0]=='2') {
	         pextra_charge = ins_ptr->pextra_charge;

             if (sug_type==0){
                 ins_ptr->ins_premium  =  premium_3132_ori*prate_1*short_prate;                         /*** round ***/
             }else{
             	 ins_ptr->ins_premium  =  premium_3132_sug*prate_1*short_prate;                         /*** round ***/
             }

             if (sug_type==0){
                 ins_ptr->bef_ins_premium =  premium_3132_ori*prate_1*short_prate;                         /*** round ***/
             }else{
             	 ins_ptr->bef_ins_premium =  premium_3132_sug*prate_1*short_prate;                         /*** round ***/
             }

        } else {
            ins_ptr->ins_premium=damage_cover*prate_1*short_prate;
            ins_ptr->bef_ins_premium=ins_ptr->ins_premium;
        }

    }
    else if (strcmp(trim(ical_ins),"77")==0)
    {    /* �I��88:��X�I���[���s */

        #ifdef PRINTF_FLAG
        printf("======== �I��88:��X�I���[���s ========================\n");
        printf("INTO 77���[�I 88 \n");
        #endif
        if (! Scan_INS_TYPE1(77) && ! Scan_INS_TYPE1(78))  return M_CA_INS7778;

        injured_cover=Icurr->injured_cover;
        death_cover=Icurr->injured_cover;
        damage_cover=Icurr->damage_cover;
        deduct=Icurr->deduct;
        ins_premium=Icurr->ins_premium;
        pure_premium=Icurr->pure_prem;

        if (! Scan_INS_TYPE1(78));
        injured_cover=injured_cover+Icurr->injured_cover;
        death_cover=death_cover+Icurr->injured_cover;
        damage_cover=damage_cover+Icurr->damage_cover;
        deduct=deduct+Icurr->deduct;
        ins_premium=ins_premium+Icurr->ins_premium;
        pure_premium= pure_premium + Icurr->pure_prem;

        ins_ptr->injured_cover=injured_cover;
        ins_ptr->death_cover=death_cover;
        ins_ptr->damage_cover=damage_cover;
        ins_ptr->deduct=deduct;

        #ifdef PRINTF_FLAG
        printf("pure_prem[%f]\n", pure_premium );
        printf("88@@@@@  prate_1[%f] short_prate[%f]\n",prate_1,short_prate);
        printf("Trace -- fcal_class  = [%s] \n",  fcal_class);
        printf("Trace -- premium1_88 = [%ld] \n",  premium1_24);
        #endif

        if (fcal_class[0]=='2')
        {
            pextra_charge = ins_ptr->pextra_charge;

            /* �O�O�p��אּ: round(�D�I�«O�O * ���[�I�«O�O�v / (1-���[�O�βv))
               ���q�אּ�p��«O�O modify by sylvia 103.09.12 */
            if (sug_type==0){
                  ins_ptr->ins_premium  =  premium_3132_ori*prate_1*short_prate;                         /*** round ***/
            }else{
                  ins_ptr->ins_premium  =  premium_3132_sug*prate_1*short_prate;                         /*** round ***/
            }
            /* ins_ptr->ins_premium     =  (long)(dbl_len8(ins_ptr->ins_premium)/(1-pextra_charge)+0.5); */

            /* premium1_24 �w���u���O�O[�Y���N�I���u����] */
            /* ins_ptr->ins_premium     += ((long)((double)premium1_24*prate_1+0.5));  */              /*** round ***/

            if (sug_type==0){
                  ins_ptr->bef_ins_premium =  premium_3132_ori*prate_1*short_prate;                         /*** round ***/
            }else{
                  ins_ptr->bef_ins_premium =  premium_3132_sug*prate_1*short_prate;                         /*** round ***/
            }
            /* ins_ptr->bef_ins_premium =  (long)(dbl_len8(ins_ptr->bef_ins_premium)/(1-pextra_charge)+0.5); */
            /* ins_ptr->bef_ins_premium += ((long)((double)premium1_24*prate_1+0.5));   */ /*** round ***/
        } else {
            ins_ptr->ins_premium=damage_cover*prate_1*short_prate;
            ins_ptr->bef_ins_premium=ins_ptr->ins_premium;
        }

       #ifdef PRINTF_FLAG
       printf("88@@@@@ ins_premium[%f]\n",ins_ptr->ins_premium);
       #endif
    }
    else if (strcmp(trim(ical_ins),"173")==0){

    	ins_ptr->injured_cover = 0;
        ins_ptr->death_cover   = 0;
        ins_ptr->damage_cover  = cover_01;
	ins_ptr->ins_premium      = (double)ins_ptr->damage_cover*prate_1;          /*** round ***/
	ins_ptr->bef_ins_premium  = (double)ins_ptr->damage_cover*prate_1;          /*** round ***/

	/*#ifdef PRINTF_FLAG*/
        printf("175@@@@@ ins_ptr->damage_cover[%ld]\n",ins_ptr->damage_cover);
        printf("175@@@@@ ins_premium[%lf]\n",ins_ptr->ins_premium);
        printf("175@@@@@ bef_ins_premium[%lf]\n",ins_ptr->bef_ins_premium);
        /*#endif*/
    }

    if (iins==1 || iins==5 || iins==8 || iins==9 || iins==85|| iins==105||
        iins==118 || iins==120 || iins==122 || iins==125 || iins==126 ||
        iins==152 || iins==153 || iins==201 || iins==205 || iins==209){
    	/* �������[���ڡB�j�vB���ڤ��p��F�Ƭ����A�٭�F�Ƭ��� ( �j�v�ȳB�z�@���) */
    	/* 101.06.25 */
    	if(strstr(tmp_provision,"F;") != NULL){
    		pdmg_acc = pdmg_acc_bak;
	        punknown_acc = punknown_acc_bak;
	}

	/* G���ڤ��F���� add by sylvia 105.08.06 (1050705002_C3) */
	if(strstr(tmp_provision,"G;") != NULL){
		pdmg_acc = pdmg_acc_bak;
	        punknown_acc = punknown_acc_bak;
	}
	if(strstr(tmp_provision,"B;") != NULL){
		if (((ibig_comp[0]==' ')||(ibig_comp[0]=='')||(ibig_comp[0]=='\0'))&&(iofficer[0] != 'W')){
			pdmg_acc = pdmg_acc_bak;
			punknown_acc = punknown_acc_bak;
		}
	}
    }
    return SUCCESS;
}

/*****************************************************************/

double MyPower(f1, i1)
double f1;
int i1;
{
int i;
double ff=1.0;

    for (i=0; i<i1; i++) {
        ff=ff*f1;
    }
    return ff;
}

/*****************************************************************/
long GetNextYearDate(pdate)
long pdate;
{
long ndate;
short mdy[3];

    rjulmdy(pdate,mdy);
    mdy[2]++;   /* mdy[2] is the year data */
    if ((mdy[0] == 2) && (mdy[1] == 29))
       mdy[1] = 28;

    rmdyjul(mdy,&ndate);
    return ndate;
}
/*****************************************************************/
int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
short mdy1[3], mdy2[3];
int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);

    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
    return datediff;
}
/*****************************************************************/
int DiffDay(d1,d2)      /* input data should be date format */
long d1, d2;
{
int datediff=0;

    datediff=(d1>d2) ? (int)(d1-d2):(int)(d2-d1);
    return datediff;
}
/*****************************************************************/
int IsBlankNull(str)
char *str;
{
    while (*str) {
        if (*str!=' ') return FALSE;
        str++;
    }
    return TRUE;
}
/*****************************************************************/
Put_Ins_Cost(ptn,ins_type,mode,print_prem,fdeduct,fmulti,f24,qday_11)
int ptn,ins_type,mode,print_prem,fdeduct;
char *fmulti;
char f24[2];
long qday_11;
{
char  tmp[40];
$char tmp_ins[INSURANCE_TYPE], tmp_last_ply[14], ideduct[3];
$long sum_prem=0;
int   person;
$char prn_deduct[40];

    #ifdef PRINTF_FLAG
    printf("Scan_Ins_Type[%d] Begin\n",ins_type);
    #endif

    if (Scan_INS_TYPE(ins_type))
    {
        strcpy(tmp,"");      /* initial to blank */

        if (ins_type==51 || ins_type==53 || ins_type==253)
        {
            if (ins_type==51 && mode==1) {
                rgu_put_body_string(ptn,"V",RIGHT);
            }
            if (ins_type==53 && mode==3) {
                rgu_put_body_string(ptn,"V",RIGHT);
            }
            if (ins_type==253 && mode==3) {
                rgu_put_body_string(ptn,"V",RIGHT);
            }
        }
        if ((ins_type==52) || (ins_type==252) || (ins_type==47) || (ins_type==147) )
        {
          if(mode==3)
          {
            if (fmulti[0]=='1')
                rgu_put_body_string(ptn," ",RIGHT);
            else {
                person=(int)(Icurr->damage_cover/Icurr->death_cover);
                strcpy(tmp,refmtamt(person,MILLIONTH));
                rgu_put_body_string(ptn,tmp,RIGHT);
            }
          }else{
                rgu_put_body_string(ptn," ",RIGHT);
          }
        }
        if (Icurr->qcoverage==1) {
            if (mode==3) {
                if (fmulti[0]=='1' &&
                    ins_type!=12 && ins_type!=24 && ins_type!=88 && ins_type!=2)
                    strcpy(tmp,"�Ԫ���");
                else
                    strcpy(tmp,refmtamt(Icurr->damage_cover,MILLIONTH));
            }
        } else if (Icurr->qcoverage==2) {
            if (mode==1) {
                if (fmulti[0]=='1')
                    strcpy(tmp,"�Ԫ���");
                else
                    strcpy(tmp,refmtamt(Icurr->injured_cover,MILLIONTH));
            }
            if (mode==3) {
                if (fmulti[0]=='1')
                    strcpy(tmp,"�Ԫ���");
                else
                    strcpy(tmp,refmtamt(Icurr->damage_cover,MILLIONTH));
            }
        } else {
            if (mode==1) {
                if (fmulti[0]=='1')
                    strcpy(tmp,"�Ԫ���");
                else
                    strcpy(tmp,refmtamt(Icurr->injured_cover,MILLIONTH));
            }
            if (mode==2) {
                if (fmulti[0]=='1')
                    strcpy(tmp,"�Ԫ���");
                else
                    strcpy(tmp,refmtamt(Icurr->death_cover,MILLIONTH));
            }
            if (mode==3) {
                if (fmulti[0]=='1')
                    strcpy(tmp,"�Ԫ���");
                else
                    strcpy(tmp,refmtamt(Icurr->damage_cover,MILLIONTH));
            }
        }
        if (mode != 0) {
            rgu_put_body_string(ptn,tmp,RIGHT);  /* mode?? _cover */
        }

        if (mode != 0) {
            if (fdeduct==0 )
            {
                rgu_put_body_string(ptn," ",LEFT); /* print blank */
            }
            else {
                if (ins_type==1 || ins_type==5 || ins_type==9 ||
                    ins_type==201 || ins_type==205 || ins_type==209 ||
                    ins_type==8 || ins_type==85|| ins_type==105 ||
                    ins_type==118 || ins_type==120 || ins_type==122 ||
                    ins_type==125 || ins_type==126 || ins_type==152 || ins_type==153)
                {
                    strcpy(ideduct,itoa(Icurr->deduct));
                    trim_tail_white(ideduct);

                    $SELECT prn_deduct INTO $prn_deduct
                       FROM ca_dmg_mdeduct
                      WHERE icar_type=$car_typei
                        AND ideduct=$ideduct;

                    if (SQLCODE==SQLNOTFOUND)
                        strcpy(prn_deduct," ");

                    strcpy(tmp,prn_deduct);
                } else {
                    strcpy(tmp,refmtamt(Icurr->deduct,MILLIONTH));
                }
                rgu_put_body_string(ptn,tmp,RIGHT);   /* deduct */
            }
        }

        #ifdef PRINTF_FLAG
        printf("ins_type[%d],f24[%s]\n",ins_type,f24);
        printf("print_prem[%d],fmulti[%s]\n",print_prem,fmulti);
        #endif

        if (print_prem) {
            if (fmulti[0]=='1')
            {
                sprintf_s(tmp_ins,sizeof tmp_ins,"%d",ins_type);
                strcpy(tmp_ins,trim(tmp_ins));
                strncpy(tmp_last_ply,last_ply,13);
                tmp_last_ply[13]='\0';

                strcpy(tmp_last_ply,trim(tmp_last_ply));
                #ifdef PRINTF_FLAG
                printf("tmp_last_ply[%s],tmp_ins[%s]\n",tmp_last_ply,tmp_ins);
                printf("INTO CY DBG\n");
                #endif
                $SELECT NVL(SUM(NVL(mins_premium,0)),0)
                   INTO $sum_prem
                   FROM ply_ins_type_302
                  WHERE ipolicy[1,13]=$tmp_last_ply
                    AND iins_type=$tmp_ins;
                    if (SQLCODE==SQLNOTFOUND) printf("FILE NOT FOUND!!\n");

            #ifdef PRINTF_FLAG
            printf("sum_prem[%ld]\n",sum_prem);
            #endif

                if(sum_prem==0)
                        strcpy(tmp,"0");
                else
                        strcpy(tmp,refmtamt(sum_prem,MILLIONTH));
            } else {
                if(Icurr->ins_premium==0)
                        strcpy(tmp,"0");
                else
                        strcpy(tmp,refmtamt((long)Icurr->ins_premium,MILLIONTH));

                #ifdef PRINTF_FLAG
                printf("Icurr->ins_premium[%ld]\n",(long)Icurr->ins_premium);
                #endif
            }

            if (strlen(trim(tmp))==0) strcpy(tmp," ");

            if ((ins_type == 24) || (ins_type == 88))
            {
                if (f24[0] == 'Y')
                {
                    rgu_put_body_string(ptn,"(�[�j)",1);
                }
                else
                {
                    rgu_put_body_string(ptn," ",1);
                }
            }

            if (ins_type == 11 || ins_type == 211 || ins_type == 96 || ins_type == 129) /*101.04.30*/
            {
                if (qday_11 > 0)
                {
                    rgu_put_body_string(ptn,"(�[��)",1);
                }
                else
                {
                    rgu_put_body_string(ptn," ",1);
                }
            }
            rgu_put_body_string(ptn,tmp,RIGHT);
        } else{

            if ((ins_type == 24) || (ins_type == 11) || (ins_type == 211) || (ins_type == 88) || (ins_type == 129))
            {
            rgu_put_body_string(ptn," ",LEFT);
            }
            rgu_put_body_string(ptn," ",LEFT);
        }
    } else {
        if (mode != 0) {
            rgu_put_body_string(ptn," ",LEFT);
            rgu_put_body_string(ptn," ",LEFT);
        }
        rgu_put_body_string(ptn," ",LEFT);
    }
    rgu_put_body(ptn);
}

/*****************************************************************/
Put_Ins_Cost_1(ptn_1,ins_type_1,mode_1,print_prem_1,
               fdeduct_1,qcoverage_1,inj,dea,dam,ded,prem,fmulti)
int  ptn_1,ins_type_1,mode_1,print_prem_1,fdeduct_1,qcoverage_1;
long inj,dea,dam,ded,prem;
char *fmulti;
{
char  tmp_1[40];
$char tmp_ins[INSURANCE_TYPE], tmp_last_ply[14];
$long sum_prem=0;
$char prn_deduct_1[40],ideduct_1[3];

     #ifdef PRINTF_FLAG
     printf("into Put_Ins_Cost_1 \n");
     printf("ins_type_1[%d]\n",ins_type_1);
     #endif

     if (ptn_1 == 57){
        if ((ins_type_1 == 34) || (ins_type_1 == 87)||(ins_type_1 == 115)){
            rgu_put_body_string(ptn_1,"�w�w�w�w",1);
            rgu_put_body_string(ptn_1,"�C�H���|",1);
        }else{
            rgu_put_body_string(ptn_1," ",RIGHT);
            rgu_put_body_string(ptn_1," ",RIGHT);
        }
     }

     if (ptn_1 == 58){
        if ((ins_type_1 == 34) || (ins_type_1 == 87)||(ins_type_1 == 115)){
            rgu_put_body_string(ptn_1,"34 ���ݪ��I",1);
            rgu_put_body_string(ptn_1,"�C�H���G",1);

        }else{
            rgu_put_body_string(ptn_1," ",RIGHT);
            rgu_put_body_string(ptn_1," ",RIGHT);
        }
     }

     if (ptn_1 == 53 || ptn_1 == 253){
        if (ins_type_1 == 50)
            rgu_put_body_string(ptn_1,"50   �r���I",1);
        else if ((ins_type_1 == 52)||(ins_type_1 == 252)||(ins_type_1 == 31)||
                 (ins_type_1 == 231)||(ins_type_1 == 133)||(ins_type_1 == 149)||
                 (ins_type_1 == 249)||(ins_type_1 == 531))
             printf("doing nothing\n");
        else
            rgu_put_body_string(ptn_1," ",RIGHT);
     }

     if (ptn_1 == 54){
        if ((ins_type_1 == 47)||(ins_type_1 == 50) ||(ins_type_1 == 147))
            rgu_put_body_string(ptn_1,"�w�w�w�w�w�w",1);
        else if ((ins_type_1 == 52)||(ins_type_1 == 252)||(ins_type_1 == 32)||
                 (ins_type_1 == 232)||(ins_type_1 == 134)||(ins_type_1 == 149)||
                 (ins_type_1 == 249)||(ins_type_1 == 532))
             printf("doing nothing\n");
        else
            rgu_put_body_string(ptn_1," ",RIGHT);
     }

     if (ptn_1 == 55){
        if (ins_type_1 == 47)
            rgu_put_body_string(ptn_1,"47   �r�p�I",1);
        else if (ins_type_1 == 147)
            rgu_put_body_string(ptn_1,"147   �r�p�I",1);
        else if (ins_type_1 == 50)
            rgu_put_body_string(ptn_1,"   (��@�ƬG)",1);
        else if (ins_type_1 != 12)
            rgu_put_body_string(ptn_1," ",RIGHT);
        else{

        }
     }

     #ifdef PRINTF_FLAG
     printf("Trace -- ptn_1 = [%s] \n",  ptn_1);
     printf(" ----xx--- qcoverage_1 = [%d]\n " , qcoverage_1);
     printf("Trace -- mode_1 = [%d] \n",  mode_1);
     printf("Trace -- fmulti[0] = [%c] \n",  fmulti[0]);
     printf("Trace -- mode_1 = [%d] \n",  mode_1);
     printf("Trace -- dam = [%ld] \n",  dam);
     #endif

     strcpy(tmp_1," ");      /* initial to blank */
        if (fmulti[0]=='0')
        {
            if (qcoverage_1==1) {
                if (mode_1==3) {
                    rfmtlong(dam,"---,---,--&",tmp_1);
                    /* printf("mode_1==3 Trace -- tmp_1 = [%s] \n",  tmp_1); */
                }
            } else if (qcoverage_1==2) {
                if (mode_1==1) {
                    rfmtlong(inj,"---,---,--&",tmp_1);
                }
                /* 960612, ���ݪ��I34 */
                if (mode_1==2) {
                    rfmtlong(dea,"---,---,--&",tmp_1);
                }

                if (mode_1==3) {
                	if (ins_type_1 == 50){
                        /* 50 �u���2�ӫO�B*/
                    }else{
                        rfmtlong(dam,"---,---,--&",tmp_1);
                    }
                }

            } else {
                if (mode_1==1) {
                    rfmtlong(inj,"---,---,--&",tmp_1);
                }
                if (mode_1==2) {
                    rfmtlong(dea,"---,---,--&",tmp_1);
                }
                if (mode_1==3) {
                    rfmtlong(dam,"---,---,--&",tmp_1);
                }
            }
        }

        #ifdef PRINTF_FLAG
        printf("mode_1[%d]\n",mode_1);
        printf("tmp_1[%s]\n",tmp_1);
        #endif

        if (mode_1 != 0) {
            rgu_put_body_string(ptn_1,trim(tmp_1),RIGHT);  /* mode?? _cover */
        }

        if (mode_1 != 0) {
            if (fdeduct_1==0 )
            {
                rgu_put_body_string(ptn_1," ",LEFT); /* print blank */
            }
            else
            {
                if (ins_type_1==1 || ins_type_1==5 || ins_type_1==9 ||
                    ins_type_1==201 || ins_type_1==205 || ins_type_1==209 ||
                    ins_type_1==8 || ins_type_1==85|| ins_type_1==105 ||
                    ins_type_1==118 || ins_type_1==120 || ins_type_1==122 ||
                    ins_type_1==125 || ins_type_1==126 || ins_type_1==152 || ins_type_1==153)
                {
                    strcpy(ideduct_1,itoa(ded));
                    trim_tail_white(ideduct_1);

                    $SELECT prn_deduct INTO $prn_deduct_1
                       FROM ca_dmg_mdeduct
                      WHERE icar_type=$car_typei
                        AND ideduct=$ideduct_1;

                    if (SQLCODE==SQLNOTFOUND)
                        strcpy(prn_deduct_1," ");

                    strcpy(tmp_1,prn_deduct_1);
                } else {
/*                    strcpy(tmp,refmtamt(ded,MILLIONTH));*/
                        rfmtlong(ded,"---,--&",tmp_1);
                }
                rgu_put_body_string(ptn_1,tmp_1,RIGHT);   /* deduct */
            }
        }

        #ifdef PRINTF_FLAG
        printf("print_prem_1[%d]\n",print_prem_1);
        printf("fmulti[%s]\n",fmulti);
        #endif

        if (print_prem_1) {
            if (fmulti[0]=='1')
            {
                sprintf_s(tmp_ins,sizeof tmp_ins,"%d",ins_type_1);
                strcpy(tmp_ins,trim(tmp_ins));
                strncpy(tmp_last_ply,last_ply,13);
                tmp_last_ply[13]='\0';

                strcpy(tmp_last_ply,trim(tmp_last_ply));
                $SELECT SUM(mins_premium) INTO $sum_prem
                   FROM ply_ins_type
                  WHERE ipolicy[1,13]=$tmp_last_ply
                    AND iins_type=$tmp_ins;

                if(sum_prem==0)
                        strcpy(tmp_1,"(          )");
                else
                        strcpy(tmp_1,refmtamt(sum_prem,MILLIONTH));
            } else {
                if(prem==0){
                         /* strcpy(tmp_1,"(          )");  */
                        strcpy(tmp_1," ");
                }
                else if(prem == -999){
                        strcpy(tmp_1,"�M�ץ�");
                }
                else{
                        rfmtlong(prem,"-,---,--&",tmp_1);
                }
            }
            printf("tmp_1[%s]\n",tmp_1);
            rgu_put_body_string(ptn_1,tmp_1,RIGHT);
        } else
            rgu_put_body_string(ptn_1,"",RIGHT);


    /*rgu_put_body(ptn_1);*/

}
/******************************************************************************/
Put_Other_Ins_Cost(ptn,ins_tp,nins_tp,edomain1,cover,
                   fdeduct,deduct,ins_premium,fmulti)
int   ptn;
$char *ins_tp;
char  *nins_tp, *edomain1, *fdeduct, *fmulti;
long  cover, deduct, ins_premium;
{
char ch[20];
$long sum_prem;
$char tmp_last_ply[14];

    rgu_put_body_string(ptn,ins_tp,LEFT);
    rgu_put_body_string(ptn,nins_tp,LEFT);
    rgu_put_body_string(ptn,edomain1,LEFT);

/******************************************
    if (fmulti[0]=='1') {
        rgu_put_body_string(ptn," ",LEFT);
    }
    else
    {
        if (cover==0) {
            rgu_put_body_string(ptn," ",LEFT);
        } else {
            strcpy(ch,refmtamt(cover,MILLIONTH));
            rgu_put_body_string(ptn,ch,RIGHT);
        }
    }
**********************************************/

    if (!strcmp(trim(ins_tp),"14")) rgu_put_body_string(ptn," ",RIGHT);
    if (!strcmp(trim(ins_tp),"15")) rgu_put_body_string(ptn," ",RIGHT);
    if (!strcmp(trim(ins_tp),"16")) rgu_put_body_string(ptn," ",RIGHT);


    if (*fdeduct=='0') {
        rgu_put_body_string(ptn,"0",RIGHT);
    } else if (*fdeduct==' ') {
        rgu_put_body_string(ptn," ",LEFT);
    } else {
        strcpy(ch,refmtamt(deduct,MILLIONTH));
        rgu_put_body_string(ptn,ch,RIGHT);
    }

    if (ins_premium==0) {
        rgu_put_body_string(ptn," ",LEFT);
    } else {
        if (fmulti[0]=='1') {
            strncpy(tmp_last_ply,last_ply,13);
            tmp_last_ply[13]='\0';

                strcpy(tmp_last_ply,trim(tmp_last_ply));
                $SELECT SUM(mins_premium) INTO $sum_prem
                   FROM ply_ins_type_302
                  WHERE ipolicy[1,13]=$tmp_last_ply
                    AND iins_type=$ins_tp;

            strcpy(ch,refmtamt(sum_prem,MILLIONTH));
        } else {
            strcpy(ch,refmtamt(ins_premium,MILLIONTH));
        }
        rgu_put_body_string(ptn,ch,RIGHT);
    }
    rgu_put_body(ptn);
}

/*****************************************************************/
Put_Other_Ins_Cost_1(ptn,ins_tp,nins_tp,edomain1,edomain2,
                     fdeduct,deduct,ins_premium,pre_cover,fmulti)
int   ptn;
$char *ins_tp;
char  *nins_tp, *edomain1, *edomain2, *fdeduct, *fmulti;
long  deduct, ins_premium, pre_cover;
{
char  ch[20];
$long sum_prem;
$char tmp_last_ply[14];
$char cov_tmp[21];

    rgu_put_body_string(ptn,ins_tp,LEFT);
    rgu_put_body_string(ptn,nins_tp,LEFT);
    if (strcmp(trim(ins_tp),"38")==0||strcmp(trim(ins_tp),"39")==0){
    	sprintf_s(cov_tmp,sizeof cov_tmp,"��Q���{ %ld",pre_cover);
    }else{
       rfmtlong(pre_cover,"---,---,--&",cov_tmp);
    }
    rgu_put_body_string(ptn,cov_tmp,2);
/*******************************************
    rgu_put_body_string(ptn,edomain1,LEFT);
    rgu_put_body_string(ptn,edomain2,LEFT);
********************************************/
	if (strcmp(trim(ins_tp),"38")==0||strcmp(trim(ins_tp),"39")==0){
		rgu_put_body_string(ptn,"���� �L",LEFT);
    }else{

	    if (*fdeduct=='0') {
	       rgu_put_body_string(ptn,"0",LEFT);
	    } else if (*fdeduct==' ') {
	        rgu_put_body_string(ptn,"",LEFT);
	    } else {
	        strcpy(ch,refmtamt(deduct,MILLIONTH));
	        rgu_put_body_string(ptn,ch,RIGHT);
	    }
    }
    if (ins_premium==0) {
        rgu_put_body_string(ptn,"",LEFT);
    } else {
        if (fmulti[0]=='1') {
            strncpy(tmp_last_ply,last_ply,13);
            tmp_last_ply[13]='\0';

                strcpy(tmp_last_ply,trim(tmp_last_ply));
                $SELECT SUM(mins_premium) INTO $sum_prem
                   FROM ply_ins_type
                  WHERE ipolicy[1,13]=$tmp_last_ply
                    AND iins_type=$ins_tp;

            if(sum_prem==0)
                strcpy(ch,"(          )");
            else
                strcpy(ch,refmtamt(sum_prem,MILLIONTH));
        } else {
            if(ins_premium==0)
                strcpy(ch,"(          )");
            else
                strcpy(ch,refmtamt(ins_premium,MILLIONTH));
        }
        rgu_put_body_string(ptn,ch,RIGHT);
    }
/*    rgu_put_body(ptn); */
}

/*****************************************************************/


/****************************************************************/
/*                                                              */
/* ������O��C�L��Ƶ��t�ӦC�L��O��(�O�N��A�@���)           */
/* option 1:�@��� 2:�O�N��                                     */
/*   �e�t�Ӹ�ơA�j����N�P�ɧ�O�̦X�֬��@�����               */
/*   �Y���j��  �A�P�_���N�I�O�_�P�ɧ�O�F                       */
/*   �Y�P�ɧ�O�A�]���N�O��w�N����O��Ƽg�X                   */
/*  ,�]���A�ӵ��j���Ƥ�������                                 */
/*  outputf1:p32_XX_5p                                          */
/*  outputf2:p32_ins_XX_5p                                      */
/****************************************************************/
int p32_print_1(option,iplyyear,iplymonth,outputf1,outputf2,outputf,userid,DBName,ipgid,intopt,print_chk)
char  DBName[5];
char  option[2];
char  userid[12],ipgid[9];
$int  iplyyear,iplymonth, intopt;
$char outputf1[65],outputf2[65],outputf[65],print_chk[31];
{
$char lia_ac_cntA[3], FormFile[N_FILE+1], OutFile[20];
$char ipolicy[21],ipolicy_1[21],icard[21],fcard_class[2],irelative_ply[21],
      dply_bgn_comp[11],dply_end_comp[11],last_policy_2[21],last_policy_3[21],
      dply_begin[11],dply_end[11],nassured[121],ilicense[13],ibirth[10],
      fsex[2],fmarriage[2],nuser[19],nbenef[43],aassured[91],itel[21],
      iply_area[11],iissue_ym[7],ipro_year[8],ibrand[9],nbrand_abbr[17],
      icar_type[3],ncar_type[17],iengine[CA_ENGINE_NUM],ibody[CA_BODY_NUM],itag[CA_TAG_NUM],mcar_price[11],
      fpt[2],idmg_rate[3],ibrg_rate[3],lia_ac_cnt1[3],lia_ac_cnt2[3],
      lia_ac_cnt3[3],dmg_ac_cnt1[3],dmg_ac_cnt2[3],dmg_ac_cnt3[3],plia_acc[6],
      pdmg_acc[5],plia_acc_c[6],dedr_begin[11],iofficer[11],
      nname[15],ibig_office[10],ibig_sales[11],ibig_policy[21],ibig_comp[2],
      ibig_branch[5],fcomp_class[3],fcomp_class_last[3],ileader[11],
      aassured_zip[CA_ZIP],irel_card[18],
      iquota[7],nchi_full[41],fnation[2],ch_ins_grp1[56],ch_ins_grp2[56],
      ch_ins_grp3[56],pre_dply1_bgn[11],pre_dply1_end[11],pre_prem1[7],
      pre_prem2[7],pre_dply2_bgn[11],pre_dply2_end[11],pre_sex_age[6],pre_sex_age_damage[6],
      pre_lia_acc[6],pre_dmg_acc[6],note1[21],nbrand[25],lia_ac_cntc[3],
      remark1[101],remark2[101],remark6[101],remark7[101],LHsIbig_Nname[11],remark3[737], sNequipment[31],
      iquota_fax[21], iquota_tel[21],vDrate_ym[4], punknown_acc[5], pre_unknown_acc[6];

$char iins_type[INSURANCE_TYPE],ch_deduct[13], lia_class[3], tmp_data[10];
$char nproject[21], remark4[101], remark5[141], nchi_tmp[31];
$long minjured_cover,mdeath_cover,mdamage_cover,mdeduct,mprem,mins_premium,
      qcoverage,pre_inj_cover,pre_dea_cover,pre_dam_cover,pre_deduct,
      pre_minsprem,qserial,t_date_bgn,t_date_end,ldaily_pay,pre_daily_pay,qserial_tmp,
      ldaily_pay_3, pre_daily_pay_3,ori_lDaily_pay_3 ;
$char remark_tmp1[101], remark_tmp2[101],remark_tmp4[101];

$int  comp_prem,qply_period,pdmg_align,pbrg_align,plia_align,
      v_prem,v_ori_prem,tot_prem,tot_ori_prem,linnum,t_count,code_prem;
$int  linnum_a;
$double qpt,psex_age,mbusiness,qcylinder;   /* �Ʈ�q�X�ܤp���I2�� (1080902001_SC3) */
$double psex_age_c, psex_age_v;
$char  BodyFile[21],TitleFile[21],BodyFmt[21],FormTp[3];
$char  TitleFmt[21],stmt[3072],prtstr[10000],sSpec[1024];
$int   ItemRow, TotColumn;
$int   StartRow,TitleRow;
$int   PgLine, Width;
$int   iMdiscount,iTot_mpay,iTot_ori_mpay;
$int   d_mdiscount,d_pre_mdiscount, iins_class;
int    rt,rc,unt,s;

$char  comp_date_begin[15],comp_date_end[15],sWhereA[300];
$char  icorps[11],ncorps[31], bzfrom1[2];
$char  sNbrand[25], fclass[2], sTmp1[31], tmp_ileader[11], sTmpIply[21];
$char  pre_ch_ins_grp1[56],pre_ch_ins_grp2[56],pre_ch_ins_grp3[56];
$double pdiscount;
$char  spdiscount[8],fassured[2];
$char   tphone_con[21],imovephone[21],iemail[51], icar_type_comp[3], ichange_note[129], icar_type_chg[21];
char   c_comp_prem[7],c_qply_period[3],c_qcylinder[9],c_pdmg_align[3],
       c_pbrg_align[3],c_plia_align[3],c_qpt[6],c_psex_age[6],c_mbusiness[9],
       c_v_prem[7],c_tot_prem[7],sApHome[21],xmp[20],xmp1[21],c_mequipment[7];
$int   tmp_cnt=0;
char   c_dmg_factor[8], c_brg_factor[8], flag_A09, fMotProj[2];
$char   ctmp_ipolicy[21]="",ctmp_iins_type[11]="",ctmp_iengine[CA_ENGINE_NUM]="",ctmp_message[51]="";
int    i,n,iins_line;
int    fBothIns; /* 0:�w�]�� 1:��j�� 2:����N 3:�j+�� 4:�����ĳ�j��(�������ѱM�רϥ�) */
$char  iins_type_i[INSURANCE_TYPE];

$int   qserial_i, qserial_j, iTmp, iYear, iCount,tmp_Count, iyear_pay;

$char  outputf8[65] , outputf9[65],  outputf10[65], outputf11[65], outputf12[65], outputf13[65], outputf14[65], outputf15[65],
       outputf16[65], outputf17[65], outputf18[65], outputf19[65], outputf20[65], outputf21[65], outputf22[65], outputf23[65],
       outputf24[65], outputf25[65], outputf26[65], outputf27[65], outputf28[65], outputf29[65], outputf30[65], outputf31[65],
       outputf32[65], outputf33[65], outputf34[65], outputf35[65], outputf36[65], outputf37[65], outputf38[65], outputf39[65],
       outputf40[65], outputf41[65], outputf42[65], outputf43[65], outputf44[65], outputf45[65], outputf46[65], outputf47[65],
       outputf48[65], outputf49[65], outputf50[65], outputf51[65], outputf52[65], outputf53[65], outputf54[65], outputf55[65],
       outputf56[65], outputf57[65], outputf58[65], outputf59[65], outputf60[65], outputf61[65], outputf62[65], outputf63[65],
       outputf1A[65], outputf1B[65], outputf2A[65], outputf2B[65], outputf1C[65], outputf2C[65];

char   file0[65] , file1[65],  file2[65],  file6[65],  file7[65],  file8[65],  file9[65] , file10[65], file11[65], file12[65],
       file13[65], file14[65], file15[65], file16[65], file17[65], file18[65], file19[65], file20[65], file21[65], file22[65],
       file23[65], file24[65], file25[65], file26[65], file27[65], file28[65], file29[65], file30[65], file31[65], file32[65],
       file33[65], file34[65], file35[65], file36[65], file37[65], file38[65], file39[65], file40[65], file41[65], file42[65],
       file43[65], file44[65], file45[65], file46[65], file47[65], file48[65], file49[65], file50[65], file51[65], file52[65],
       file53[65], file54[65], file55[65], file56[65], file57[65], file58[65], file59[65], file60[65], file61[65], file62[65],
       file63[65], file1A[65], file1B[65], file2A[65], file2B[65], file1C[65], file2C[65];

FILE   *fp0, *fp1, *fp2, *fp6, *fp7, *fp8, *fp9, *fp10,*fp11,*fp12,*fp13,*fp14,*fp15,*fp16,*fp17,*fp18,*fp19,*fp20,
       *fp21,*fp22,*fp23,*fp24,*fp25,*fp26,*fp27,*fp28,*fp29,*fp30,*fp31,*fp32,*fp33,*fp34,*fp35,*fp36,*fp37,*fp38,
       *fp39,*fp40,*fp41,*fp42,*fp43,*fp44,*fp45,*fp46,*fp47,*fp48,*fp49,*fp50,*fp51,*fp52,*fp53,*fp54,*fp55,*fp56,
       *fp57,*fp58,*fp59,*fp60,*fp61,*fp62,*fp63,
       *fp1A,*fp1B,*fp1C,*fp2A,*fp2B,*fp2C;

char   flag_Z,flag_M,flag_T,flag_P,flag_G,flag_L,flag_S,flag_Six,flag_Orix,
       flag_Jihsun,flag_ES,flag_AVIS,flag_PA,flag_TAXI1,flag_TAXI2,flag_RENT1,flag_RENT2,
       flag_RS,flag_no_print,flag_CHAILEASE,flag_SPECIAL,flag_B,flag_JB,flag_102,flag_JBDelete,
       flag_NEXTBANK,flag_J,flag_MOMO,flag_F,flag_PRO;

$char  ilicense_v[13];
$int   count_51;
$char  nofficer[11];
$int   count_barcode=0;
$char  sFullName[20]="";
$char  sFullDB[21];

/* 970822, �s�W�Ĥ@���Q�O�I�H�W�U */
$char  iinsurant_pa[11]=" " , ninsurant_pa[31]=" ", ibirth_pa[11], nbenif_pa[31],irel_pa[14];
$char  mm_pa[3], dd_pa[3], yyyy_pa[5];
$int   cy_pa,fLater=0;

$char  ioff_corps[11],nbroker[13];
$char  iresource[2]="";

$char  s_dbirth[11],s_dissue[11];
$char  tmp_yyyy[5],tmp_mm[3],tmp_dd[3];
$char  fBarcode_print[2] = " ";
$int   v_iplymonth;
$char  sTmp[151], sTmp4[151];
char   fKind;
$char  nroute[41] = " ";
$int   tmp_type = 0;
$char  sDmg_lia_remark1[21],sDmg_lia_remark2[21];
$char  dmg_point[3],dmg_point_sug[3],pdmg_acc_sug[5],dunknown_point[3];
$char  unknown_point[3],unknown_point_sug[3],punknown_acc_sug[5];
double dbl_pdmg_acc = 0.0,dbl_pdmg_acc_sug=0.0,
       dbl_punknown_acc = 0.0, dbl_punknown_acc_sug = 0.0;
char   count_linnum = 'Y';
char   control_col[23] = "~~00000000000000000000";
                        /*  12345678901234567890 */
$char  nsex_appl[3]=" " ,all_col_302[4072],stmt_302[8000] ;
$char  icode_no[11],tmp_ilicense[13],brand_BEV[2];
$char  Bcode1[12], Bcode2[19], Bcode3[18],ori_Bcode1[12], ori_Bcode2[19], ori_Bcode3[18];
$char  tmYY[4], tmMM[3], tmDD[3];
$char  s_paydate[11],c_paydate[10], iassured_cntry[2], iapplicant_cntry[2],
       foccup[2], noccup[6], applicant_foccup[2], applicant_noccup[6], tmobile_appl[21], aemail_appl[51];
$long  lng_dply_begin_comp,paydate,lng_paydate_comp,ori_deductx;
$char  freason_reject[2],nsecond_hand[41],tmp_ibig_office[10],ipolicy_print[21],iofficer_prmt[11];
char   fBarcode_mark , IsPlyB;
$int   mcomp_prem_sug,iRemark_yn, cnt_prmt,cnt_131;
$char  ireg_no[21]; /* �n���Ҹ� add by sylvia 103.09.11 (1030901003_C1) modify by 061476 (1080408005_SC3) */
$char  iins_scope[2],car_type_pre[3], sdate1[11], sdate2[11], iroute_accept[31], nins_scope[7];
char   iroute_accept_tmpbr[5],iroute_accept_tmpno[40];
$char  ply_route_main[21], sTmpRS[1000], sIroute_main[21], sIofficer[11], sProvision[22], fNo_print[2];
$int   RsCount,deduct301,count02,deduct02,cnt_payable,count55,
       cnt_chg67=0,count238=0,countBEV=0,mprem_no50=0,mprem_5556=0,cnt_renew_jb=0,cnt_provision_f=0;
$int   age_110, cnt_110, oth_110;
$char  dbirth1[11], dbirth2[11], iupcomp1[2], iupcomp2[2], iroute2[21], freason_reject2[2];
$char  aemail_eply[51], tmobile_eply[21], dc_change[2], icomm_obj[11], iroute_main[13],
       nsales[101], feterms[2], pre_comp_feply[2];
$char  dinstall[11], isequence[31], ainstall_zip[CA_ZIP], ainstall[91];
$char  sCYYMM[6];
$char  sviolate_prem[7],sdrunk_prem[7];
$char  dbirth_appl[11]=" ";
char   yy[4], mm[3], dd[3], dbirth_yy[4], dbirth_mm[3], dbirth_dd[3],
       dbirth_appl_yy[4], dbirth_appl_mm[3], dbirth_appl_dd[3];
int    age, age_appl;
$date  ldpolicy;


$struct car_code_rs
{
	char   iroute_main[21];
	char   iofficer[11];
	char   fno_print[2];
};
$struct car_code_rs *ca_unsend = NULL;


$WHENEVER SQLERROR GOTO errexit;
$SET LOCK MODE TO WAIT;

    printf("Trace ------------------- start p32_print_1() ------------------- \n");
    printf("Trace -- DBName = [%s] \n",  DBName);
    printf("Trace -- ipgid = [%s] \n",  ipgid);
    printf("Trace -- option = [%s] \n",  option);
    printf("Trace -- iplyyear = [%d] \n",  iplyyear);
    printf("Trace -- iplymonth = [%d] \n",  iplymonth);
    printf("Trace -- intopt = [%d] \n",  intopt);
    printf("Trace -- print_chk = [%s] \n",  print_chk);
    printf("Trace -- p32Where = [%s] \n",  p32Where);

    sprintf_s(sCYYMM,sizeof sCYYMM,"%d%02d",iplyyear-1911,iplymonth);

    /* ���o ���B�멳��� */
    sprintf_s(stmt,sizeof stmt, "SELECT '%02d/01/%d'::date,LAST_DAY('%02d/01/%d'::date) FROM systables WHERE tabid=1",
              iplymonth,iplyyear,iplymonth,iplyyear);
    $PREPARE predays FROM $stmt;
    $EXECUTE predays INTO $sdate1,$sdate2;

    printf("Trace -- sdate1 = [%s] sdate2 = [%s]\n",  sdate1,sdate2);
    /* ����~�έp�{���ˮ� add by sylvia 104.01.26 ----------------------------*/
    chk_PA = 0;
    $select count(*) into $chk_PA
       from car_code
      where  kind = 'RN'
        and detail = 'CHK_PA'
        and today >= date(detail2);

    /* �������H�e�W�� add by sylvia 104.04.02 (1040312001_C1) -------------- */
    /* �s�W�����s��O�n�O�ѿﶵ modify by 061476 (1090114002_SC1) */
    RsCount = 0;
    $select count(*) into $RsCount from car_code where kind = 'RS';
    ca_unsend = (struct car_code_rs *) calloc (RsCount,sizeof(struct car_code_rs));

    sprintf_s(sTmpRS,sizeof sTmpRS, "select detail, detail2, engname from car_code where kind = 'RS'");
    $PREPARE  prr_RS FROM $sTmpRS;
    $DECLARE  cur_RS CURSOR FOR prr_RS;
    $OPEN     cur_RS;
    i = 0;
    while(1)
    {
        $FETCH cur_RS INTO $sIroute_main, $sIofficer, $fNo_print;
        if(SQLCODE == SQLNOTFOUND)  break;
        strcpy(ca_unsend[i].iroute_main,  sIroute_main);
        strcpy(ca_unsend[i].iofficer,     sIofficer);
        strcpy(ca_unsend[i].fno_print,    fNo_print);
        i++;
    }
    $CLOSE   cur_RS;
    $FREE   cur_RS;
    printf("== �������H�e�]�w�e%d�f��\n",i);
    /* --------------------------------------------------------------------- */
    /* �z�߾n�~�H��  add by sylvia 104.09.17 (1040910012_C1) */
    $WHENEVER ERROR CONTINUE;
    $DROP TABLE tp_claim;
    $WHENEVER SQLERROR GOTO errexit;

    $select a.iquota, a.iofficer, a.nname, c.nbranch, b.iapp_unit, d.nchi_full,
            e.branch_tel, e.ext_fax,d.abusiness
       from officer a, cm_clm_adjuster b, sa_branch_type c, branch d, cm_emp_ext e
      where a.iofficer = a.ileader
        and a.iofficer = b.empl_no
        and a.iquota = c.ibranch
        and b.iapp_unit = d.ibranch
        and a.iofficer = e.empl_no
        and b.fadjuster <> ' '
        and c.iupcomp <> d.iupcomp
        and a.dexpire is null into temp tp_claim;

    /* --------------------------------------------------------------------- */
    $WHENEVER ERROR CONTINUE;
    $DROP TABLE tp_officer;
    $WHENEVER SQLERROR GOTO errexit;
    /* �M�ץ�g�� ----------------------------------------------------------- */
       $select iofficer_ori from ca_promote_officer where iofficer_ori[1,1] in ('W','H','N')
         group by 1  into temp tp_officer;
       $create index tp_officer_idx1 on tp_officer(iofficer_ori);
    /* --------------------------------------------------------------------- */

    sprintf_s( all_col_302 ,sizeof all_col_302,"%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
            "a.ipolicy,a.ipolicy_1,a.icard,a.fcard_class,a.irelative_ply,a.dply_bgn_comp,",
            "a.dply_end_comp,a.comp_prem,a.last_policy_2,a.last_policy_3,a.qply_period,",
            "a.dply_begin,a.dply_end,a.nassured,a.ilicense,a.ibirth,a.fsex,a.fmarriage,",
            "a.nuser,a.nbenef,a.aassured,a.itel,a.iply_area,a.iissue_ym,a.ipro_year||'/'||a.qpro_month,a.ibrand,",
            "a.nbrand_abbr,a.icar_type,a.ichange_note,a.ncar_type,a.qcylinder,a.iengine,a.ibody,",
            "a.itag,a.mcar_price,a.pdmg_align,a.pbrg_align,a.plia_align,a.qpt,a.fpt,a.idmg_rate,",
            "a.dmg_factor,a.ibrg_rate,a.brg_factor,a.psex_age,a.psex_age_damage,a.lia_ac_cnt1,",
            "a.lia_ac_cnt2,a.lia_ac_cnt3,a.lia_ac_cntc,a.dmg_ac_cnt1,a.dmg_ac_cnt2,a.dmg_ac_cnt3,",
            "a.plia_acc,a.pdmg_acc,a.plia_acc_c,a.fcar_class,a.dedr_begin,a.iofficer,a.nname,",
            "a.ibig_office,a.ibig_sales,a.ibig_policy,a.ibig_comp,a.ibig_branch,a.mbusiness,",
            "a.fcomp_class,a.fcomp_class_last,a.ileader,a.aassured_zip,a.irel_card,a.iquery_num,",
            "a.iquery_num_damage,a.iquota,a.nchi_full,a.fnation,a.v_prem,a.v_ori_prem,a.tot_prem,",
            "a.ch_ins_grp1,a.ch_ins_grp2,a.ch_ins_grp3,a.pre_dply1_bgn,a.pre_dply1_end,a.pre_prem1,",
            "a.pre_prem2,a.pre_dply2_bgn,a.pre_dply2_end,a.pre_sex_age,a.pre_sex_age_damage,",
            "a.pre_lia_acc,a.pre_dmg_acc,a.note1,a.linnum,a.nbrand,a.remark1,a.remark2,a.remark6,",
            "a.remark7,a.ibig_nname,a.mdiscount,a.tot_mpay,a.pre_ch_ins_grp1,a.pre_ch_ins_grp2,",
            "a.pre_ch_ins_grp3,a.icorps,a.ncorps,a.pdiscount,a.fcomp_24,a.remark3,a.fassured,",
            "a.tphone_con,a.imovephone,a.iemail,a.remark4,a.remark5,a.nproject,a.lia_class,a.nequipment,",
            "a.option,a.dbirth,a.dissue,a.iroute,a.bzfrom,a.irate_type,a.iroute_comm,a.iroute_prop,",
            "a.iupdate,a.dupdate,a.qdmg_acc_sum,a.qlia_acc_sum,a.iapplicant,a.napplicant,a.apayment_zip,",
            "a.apayment,a.fapplicant,a.fsex_appl,nvl(a.dbirth_appl,' '),a.itel_appl,a.ndeputy_appl,a.nrelation_appl,",
            "a.ndeputy_assured,a.iabn_type,a.iestimate_ori,a.iestimate_sug,a.itransno_ori,a.itransno_sug,",
            "a.fuw_status_ori,a.fuw_status_sug,a.frenew_type,a.freason_reject,a.mcomp_prem_sug,a.isecond_hand,",
            "a.pdmg_acc_sug, a.qdmg_acc_sum_sug, a.iquery_num_damage_sug,a.introducer,a.icard_main,a.qdrunk_driving,",
            "case when a.nproject like '�֪@%' then 1 else 0 end, ",
            "c.iroute_main,a.iofficer,mequipment, ",
            "a.iassured_cntry, a.iapplicant_cntry, a.iroute_accept, nvl(a.dbirth,' '), b.iupcomp, ",
            "a.punknown_acc_ori, a.pre_punknown_acc, a.qunknown_acc_sum_ori, a.punknown_acc_sug, a.qunknown_acc_sum_sug, ",
            "a.iquery_num_unknown_ori,  a.iquery_num_unknown_sug, a.aemail_eply, a.psex_age_c, a.iquery_num_c, ",
            "nvl((select '1' from sysdb:ca_dc_change d where d.ipolicy = a.ipolicy and d.iofficer_new = a.iofficer),'0'), ",
            "a.foccup, a.noccup, a.applicant_foccup, a.applicant_noccup, ",
            "a.tmobile_appl, a.aemail_appl, a.tmobile_eply, a.ireg_no, b.icomm_obj, ",
            "(select iroute_main from cm_route WHERE iroute = a.iroute), a.feterms, a.qviolate, ",
            "a.dinstall, a.isequence, a.ainstall_zip, a.ainstall ");

    strcpy(all_col_302,trimx(all_col_302));

    GiCnt = 0;
    linnum_a = 0;
    unt = 0;
    psex_age_c=0;
    psex_age_v=0;
    rt = getApHome(sApHome);
    if (rt < 0) {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
    }

    printf("before temp table iins_class\n");

    $WHENEVER ERROR CONTINUE;
    $DROP TABLE iins_class;
    $WHENEVER SQLERROR GOTO errexit;

    $CREATE TEMP TABLE iins_class
    (
      iins_type  char(6),
      iins_class integer,
      qserial    integer
    )
    WITH NO LOG;

    printf("create temp table done\n");

    $DECLARE cur_x1 CURSOR FOR
      SELECT iins_type, qserial
        FROM insurance_type
       WHERE iins_type = iins_ply
         AND qserial > 0;
    $OPEN  cur_x1;
    while(1)
    {
        $FETCH cur_x1 INTO $iins_type_i, $qserial_i;
        if(SQLCODE == SQLNOTFOUND) break;

        qserial_j = (int) qserial_i/10 +1;

        $insert into iins_class values( $iins_type_i, $qserial_j, $qserial_i);
    }
    $CLOSE cur_x1;
    $FREE  cur_x1;

    $WHENEVER ERROR CONTINUE;
    $DROP TABLE tmp_later;
    $WHENEVER SQLERROR GOTO errexit;

    $CREATE TEMP TABLE tmp_later(
       ipolicy  char(20)
    ) WITH NO LOG;
    sprintf_s(stmt,sizeof stmt,"INSERT INTO tmp_later VALUES (?)");
    $PREPARE pre_later FROM $stmt;

    printf("insert done\n");

    /* intopt==99,98 => ���s�ɮת��O�渹�ӷ��� newa00:ca_tmp_no */
    /* �ɦW�ϧO�X��ӷ�����                                  */
    if (intopt==99){
  	   if (strcmp(ipgid,"car302c")==0){
  	   	   fKind = 't';
  	  	   strcat(outputf1,"_test"); /* ���s���ե� */
  	  	   strcat(outputf2,"_test");
  	   }else if (strcmp(ipgid,"car302")==0){
  	   	   fKind = 'p';
  	  	   strcat(outputf1,"_part"); /* ���s�����J�p�� */
  	  	   strcat(outputf2,"_part");
           }
    }else if (intopt==98){
   	   fKind = 't';
  	   strcat(outputf1,"_test"); /* �g��car302 ���s���ե� */
  	   strcat(outputf2,"_test");
    }else{
   	   /* [del intopt == 25]102.03 �w��5/1�ᤧ 5,6��|���X�椧��O���ơA�ɻ����O�X���ơA�H�Q���H�o��O�� 102.07���i�R��*/
   	   if (intopt == 25){
  	   	   fKind = 'p';
  	  	   strcat(outputf1,"_part"); /* ���s�����J�p�� */
  	  	   strcat(outputf2,"_part");
           }else{
   	      fKind = ' ';
   	   }
    }

    /* �� print_chk�C�Ӧr���ӨM�w�O�_���s�Y�q�l��(0:�����s ;1:���s)
      2p: "000000000000000000000000000000"
          print_chk[0]  => tmnewa    ; print_chk[1] => ��W
          print_chk[2]  => �p���p��  ; print_chk[3] => �Τ@�F��

          ���`�N�Gprint_chk[0]='9' => Ū���~�bwhere�ܼƬ����󲣻s�ɮ�

      5p: "000000000000000000000000000000"
          print_chk[0] => tmnewa     ; print_chk[1] => �έ�
          print_chk[2] => ����       ; print_chk[3] => ���W
          print_chk[4] => ���M       ; print_chk[5] => �M�ץ�
          print_chk[8] => ����

          ���`�N�Gprint_chk[0]='9' => Ū���~�bwhere�ܼƬ����󲣻s�ɮ�

      ��L: "000000000000000000000000000000"
          print_chk[15] => �R�q��

          ���`�N�Gprint_chk[0]='9' => Ū���~�bwhere�ܼƬ����󲣻s�ɮ� */

    if (option[0] == '2')
    {
        /*** 5p: tmnewa ***/
        if (print_chk[0]=='1')
        {
                /* outputf1:"p32_%d_5p",iplymonth */
	        sprintf_s(file1,sizeof file1,"%s/rptftp/%s",sApHome,rtrim(outputf1));
	        rt = rptftpinsert(userid,ipgid,outputf1);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        /* outputf2:"p32_ins_%d_5p",iplymonth */
	        sprintf_s(file2,sizeof file2,"%s/rptftp/%s",sApHome,rtrim(outputf2));

	        rt = rptftpinsert(userid,ipgid,outputf2);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        fp1=fopen(file1,"w");
	        fp2=fopen(file2,"w");
        }

        /*** 5p: �έ� ***/
        if (print_chk[1]=='1')
        {
            /* 100.03.01,�w���� �έ�W�b�� */
      	    /* ����car302c�I�stest_data()�ɨ��o�έ�W�U�b��@�P���ɦW */
      	    if ((intopt==1) || (intopt==19))
      	    {
      	        sprintf_s( outputf10,sizeof outputf10, "p32_%d_A09_1", iplymonth);
      	  	sprintf_s( outputf11,sizeof outputf11, "p32_ins_%d_A09_1", iplymonth);
      	    }
      	    else if ((intopt==4) || (intopt==49))
      	    {
      	  	sprintf_s( outputf10,sizeof outputf10, "p32_%d_A09_4", iplymonth);
      	  	sprintf_s( outputf11,sizeof outputf11, "p32_ins_%d_A09_4", iplymonth);
      	    }
      	    else
      	    {
                if (fKind==' ')
                {
		    sprintf_s( outputf10,sizeof outputf10, "p32_%d_A09_%d", iplymonth, intopt);
		    sprintf_s( outputf11,sizeof outputf11, "p32_ins_%d_A09_%d", iplymonth, intopt);
      	  	}
      	  	else if (fKind=='t') /* ���s���ե� */
      	  	{
	            sprintf_s( outputf10,sizeof outputf10, "p32_%d_A09_test", iplymonth);
	            sprintf_s( outputf11,sizeof outputf11, "p32_ins_%d_A09_test", iplymonth);
      	  	}
      	  	else if (fKind=='p') /* ���s�����J�p�� */
      	  	{
	            sprintf_s( outputf10,sizeof outputf10, "p32_%d_A09_part", iplymonth);
	            sprintf_s( outputf11,sizeof outputf11, "p32_ins_%d_A09_part", iplymonth);
	        }
      	    }

	    sprintf_s( file10,sizeof file10,"%s/rptftp/%s",sApHome,rtrim(outputf10));
	    rt = rptftpinsert(userid,ipgid,outputf10);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }

	    sprintf_s( file11,sizeof file11,"%s/rptftp/%s",sApHome,rtrim(outputf11));
	    rt = rptftpinsert(userid,ipgid,outputf11);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
		goto errexit;
	    }
	    fp10=fopen(file10,"w");
	    fp11=fopen(file11,"w");
        }

        /*** 5p: ���� ***/
        if (print_chk[2]=='1')
        {
            if (fKind==' ')
            {
		sprintf_s( outputf18,sizeof outputf18, "p32_%d_5p_����", iplymonth);
		sprintf_s( outputf19,sizeof outputf19, "p32_ins_%d_5p_����", iplymonth);
  	    }
  	    else if (fKind=='t')  /* ���s���ե� */
  	    {
                sprintf_s( outputf18,sizeof outputf18, "p32_%d_5p_����_test", iplymonth);
                sprintf_s( outputf19,sizeof outputf19, "p32_ins_%d_5p_����_test", iplymonth);
  	    }
  	    else if (fKind=='p')  /* ���s�����J�p�� */
  	    {
                sprintf_s( outputf18,sizeof outputf18, "p32_%d_5p_����_part", iplymonth);
                sprintf_s( outputf19,sizeof outputf19, "p32_ins_%d_5p_����_part", iplymonth);
            }

	        sprintf_s(file18,sizeof file18,"%s/rptftp/%s",sApHome,rtrim(outputf18));
	        rt = rptftpinsert(userid,ipgid,outputf18);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }

	        sprintf_s(file19,sizeof file19,"%s/rptftp/%s",sApHome,rtrim(outputf19));
	        rt = rptftpinsert(userid,ipgid,outputf19);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        fp18=fopen(file18,"w");
	        fp19=fopen(file19,"w");
        }

        /*** 5p: ���W ***/
        if (print_chk[3]=='1')
        {
            if (fKind==' ')
            {
	        sprintf_s( outputf20,sizeof outputf20, "p32_%d_5p_���W", iplymonth);
		sprintf_s( outputf21,sizeof outputf21, "p32_ins_%d_5p_���W", iplymonth);
  	    }
  	    else if (fKind=='t')  /* ���s���ե� */
  	    {
                sprintf_s( outputf20,sizeof outputf20, "p32_%d_5p_���W_test", iplymonth);
                sprintf_s( outputf21,sizeof outputf21, "p32_ins_%d_5p_���W_test", iplymonth);

  	    }
  	    else if (fKind=='p')  /* ���s�����J�p�� */
  	    {
                sprintf_s( outputf20,sizeof outputf20, "p32_%d_5p_���W_part", iplymonth);
                sprintf_s( outputf21,sizeof outputf21, "p32_ins_%d_5p_���W_part", iplymonth);
            }

	    sprintf_s(file20,sizeof file20,"%s/rptftp/%s",sApHome,rtrim(outputf20));
	    rt = rptftpinsert(userid,ipgid,outputf20);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }

	    sprintf_s(file21,sizeof file21,"%s/rptftp/%s",sApHome,rtrim(outputf21));
	    rt = rptftpinsert(userid,ipgid,outputf21);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }
	    fp20=fopen(file20,"w");
	    fp21=fopen(file21,"w");
        }

        /*** 5p: ���M ***/
        /* 102.07.10�A���M�����X�@�A���M�S���榡�אּ��W���s5p�ɡAtmnewa 5p�ɮפ������t���M�� */
        if (print_chk[4]=='1')
        {
  	    if (fKind==' ')
  	    {
	        sprintf_s( outputf26,sizeof outputf26, "p32_%d_5p_���M", iplymonth);
		sprintf_s( outputf27,sizeof outputf27, "p32_ins_%d_5p_���M", iplymonth);

  	    }
  	    else if (fKind=='t') /* ���s���ե� */
  	    {
                sprintf_s( outputf26,sizeof outputf26, "p32_%d_5p_���M_test", iplymonth);
                sprintf_s( outputf27,sizeof outputf27, "p32_ins_%d_5p_���M_test", iplymonth);

  	    }
  	    else if (fKind=='p') /* ���s�����J�p�� */
  	    {
                sprintf_s( outputf26,sizeof outputf26, "p32_%d_5p_���M_part", iplymonth);
                sprintf_s( outputf27,sizeof outputf27, "p32_ins_%d_5p_���M_part", iplymonth);
            }

	    sprintf_s(file26,sizeof file26,"%s/rptftp/%s",sApHome,rtrim(outputf26));
	    rt = rptftpinsert(userid,ipgid,outputf26);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }

	    sprintf_s(file27,sizeof file27,"%s/rptftp/%s",sApHome,rtrim(outputf27));
	    rt = rptftpinsert(userid,ipgid,outputf27);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }

	    fp26=fopen(file26,"w");
	    fp27=fopen(file27,"w");
        }

        /*** 5p: �M�ץ� ***/
        if (print_chk[5]=='1')
        {

  	    if (fKind==' ')
  	    {
		sprintf_s( outputf8,sizeof outputf8, "p32_%d_5p_�M��", iplymonth);
		sprintf_s( outputf9,sizeof outputf9, "p32_ins_%d_5p_�M��", iplymonth);

  	    }
  	    else if (fKind=='t') /* ���s���ե� */
  	    {
                sprintf_s( outputf8,sizeof outputf8, "p32_%d_5p_�M��_test", iplymonth);
                sprintf_s( outputf9,sizeof outputf9, "p32_ins_%d_5p_�M��_test", iplymonth);

  	    }
  	    else if (fKind=='p') /* ���s�����J�p�� */
  	    {
                sprintf_s( outputf8,sizeof outputf8, "p32_%d_5p_�M��_part", iplymonth);
                sprintf_s( outputf9,sizeof outputf9, "p32_ins_%d_5p_�M��_part", iplymonth);
            }

	    sprintf_s(file8,sizeof file8,"%s/rptftp/%s",sApHome,rtrim(outputf8));
	    rt = rptftpinsert(userid,ipgid,outputf8);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }

	    sprintf_s(file9,sizeof file9,"%s/rptftp/%s",sApHome,rtrim(outputf9));
	    rt = rptftpinsert(userid,ipgid,outputf9);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }

	    fp8=fopen(file8,"w");
	    fp9=fopen(file9,"w");
        }

        /*** 5p: �p�{�� ***/
        if ((print_chk[6]=='1') && (chk_PA > 0))
        {

  	    if (fKind==' ')
  	    {
	        sprintf_s( outputf40,sizeof outputf40, "p32_%d_5p_�p�{��", iplymonth);
		sprintf_s( outputf41,sizeof outputf41, "p32_ins_%d_5p_�p�{��", iplymonth);

  	    }
  	    else if (fKind=='t') /* ���s���ե� */
  	    {
                sprintf_s( outputf40,sizeof outputf40, "p32_%d_5p_�p�{��_test", iplymonth);
                sprintf_s( outputf41,sizeof outputf41, "p32_ins_%d_5p_�p�{��_test", iplymonth);

  	    }
  	    else if (fKind=='p') /* ���s�����J�p�� */
  	    {
                sprintf_s( outputf40,sizeof outputf40, "p32_%d_5p_�p�{��_part", iplymonth);
                sprintf_s( outputf41,sizeof outputf41, "p32_ins_%d_5p_�p�{��_part", iplymonth);
            }

	    sprintf_s(file40,sizeof file40,"%s/rptftp/%s",sApHome,rtrim(outputf40));
	    rt = rptftpinsert(userid,ipgid,outputf40);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }

	    sprintf_s(file41,sizeof file41,"%s/rptftp/%s",sApHome,rtrim(outputf41));
	    rt = rptftpinsert(userid,ipgid,outputf41);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }

	    fp40=fopen(file40,"w");
	    fp41=fopen(file41,"w");

        }


        /*** 5p: ��� ***/
        if ((print_chk[7]=='1') && (chk_PA > 0))
        {

  	    if (fKind==' ')
  	    {
		sprintf_s( outputf44,sizeof outputf44, "p32_%d_5p_���", iplymonth);
		sprintf_s( outputf45,sizeof outputf45, "p32_ins_%d_5p_���", iplymonth);
  	    }
  	    else if (fKind=='t')/* ���s���ե� */
  	    {
                sprintf_s( outputf44,sizeof outputf44, "p32_%d_5p_���_test", iplymonth);
                sprintf_s( outputf45,sizeof outputf45, "p32_ins_%d_5p_���_test", iplymonth);
  	    }
  	    else if (fKind=='p')/* ���s�����J�p�� */
  	    {
                sprintf_s( outputf44,sizeof outputf44, "p32_%d_5p_���_part", iplymonth);
                sprintf_s( outputf45,sizeof outputf45, "p32_ins_%d_5p_���_part", iplymonth);
            }

	    sprintf_s(file44,sizeof file44,"%s/rptftp/%s",sApHome,rtrim(outputf44));
	    rt = rptftpinsert(userid,ipgid,outputf44);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }

	    sprintf_s(file45,sizeof file45,"%s/rptftp/%s",sApHome,rtrim(outputf45));
	    rt = rptftpinsert(userid,ipgid,outputf45);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }

	    fp44=fopen(file44,"w");
	    fp45=fopen(file45,"w");

        }

        /*** 5p: ���� (1091210006_SC2) ***/
        if (print_chk[8]=='1')
        {
            if (fKind==' ')
            {
                sprintf_s( outputf48,sizeof outputf48, "p32_%d_2p_����", iplymonth);
		sprintf_s( outputf49,sizeof outputf49, "p32_ins_%d_2p_����", iplymonth);

	    }
	    else if (fKind=='t') /* ���s���ե� */
	    {
		sprintf_s( outputf48,sizeof outputf48, "p32_%d_2p_����_test", iplymonth);
		sprintf_s( outputf49,sizeof outputf49, "p32_ins_%d_2p_����_test", iplymonth);

	    }
	    else if (fKind=='p') /* ���s�����J�p�� */
	    {
                sprintf_s( outputf48,sizeof outputf48, "p32_%d_2p_����_part", iplymonth);
                sprintf_s( outputf49,sizeof outputf49, "p32_ins_%d_2p_����_part", iplymonth);
            }

	    sprintf_s(file48,sizeof file48,"%s/rptftp/%s",sApHome,rtrim(outputf48));
	    rt = rptftpinsert(userid,ipgid,outputf48);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }

	    sprintf_s(file49,sizeof file49,"%s/rptftp/%s",sApHome,rtrim(outputf49));
	    rt = rptftpinsert(userid,ipgid,outputf49);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }

	    fp48=fopen(file48,"w");
	    fp49=fopen(file49,"w");

        }

        /*** 5p: ���q (1110329003_SC1) ***/
        if (print_chk[9]=='1')
        {
            if (fKind==' ')
            {
                sprintf_s( outputf56,sizeof outputf56, "p32_%d_2p_���q", iplymonth);
		sprintf_s( outputf57,sizeof outputf57, "p32_ins_%d_2p_���q", iplymonth);
	    }
	    else if (fKind=='t') /* ���s���ե� */
	    {
		sprintf_s( outputf56,sizeof outputf56, "p32_%d_2p_���q_test", iplymonth);
		sprintf_s( outputf57,sizeof outputf57, "p32_ins_%d_2p_���q_test", iplymonth);
            }
            else if (fKind=='p') /* ���s�����J�p�� */
            {
                sprintf_s( outputf56,sizeof outputf56, "p32_%d_2p_���q_part", iplymonth);
                sprintf_s( outputf57,sizeof outputf57, "p32_ins_%d_2p_���q_part", iplymonth);
            }

	    sprintf_s(file56,sizeof file56,"%s/rptftp/%s",sApHome,rtrim(outputf56));
	    rt = rptftpinsert(userid,ipgid,outputf56);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }

	    sprintf_s(file57,sizeof file57,"%s/rptftp/%s",sApHome,rtrim(outputf57));
	    rt = rptftpinsert(userid,ipgid,outputf57);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }

	    fp56=fopen(file56,"w");
	    fp57=fopen(file57,"w");

        }


        /*  Ū���~�bwhere�ܼ�(p32Where)�����󲣻s�ɮ� */
        if (print_chk[0]=='9')
        {
	    sprintf_s( outputf10,sizeof outputf10, "p32_%d_5p_other", iplymonth);
	    sprintf_s( file10,sizeof file10,"%s/rptftp/%s",sApHome,rtrim(outputf10));
	    rt = rptftpinsert(userid,ipgid,outputf10);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
		goto errexit;
	    }
	    sprintf_s( outputf11,sizeof outputf11, "p32_ins_%d_5p_other", iplymonth);
	    sprintf_s( file11,sizeof file11,"%s/rptftp/%s",sApHome,rtrim(outputf11));

	    rt = rptftpinsert(userid,ipgid,outputf11);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
		goto errexit;
	    }
	    fp10=fopen(file10,"w");
	    fp11=fopen(file11,"w");
        }
    }
    else
    {
        /*** 2p: tmnewa ***/
  	if (print_chk[0]=='1'){
	        /* outputf1:"p32_%d_2p",iplymonth */
	        strcpy(outputf1, trim(outputf1));
	        sprintf_s(outputf1A,sizeof outputf1A,"%s_�H",outputf1);
	        sprintf_s(outputf1B,sizeof outputf1B,"%s_���H",outputf1);
	        sprintf_s(outputf1C,sizeof outputf1C,"%s_�����s",outputf1);

	        sprintf_s(file1A,sizeof file1A,"%s/rptftp/%s",sApHome,rtrim(outputf1A));
	        rt = rptftpinsert(userid,ipgid,outputf1A);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }

	        sprintf_s(file1B,sizeof file1B,"%s/rptftp/%s",sApHome,rtrim(outputf1B));
	        rt = rptftpinsert(userid,ipgid,outputf1B);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }

	        sprintf_s(file1C,sizeof file1C,"%s/rptftp/%s",sApHome,rtrim(outputf1C));
	        rt = rptftpinsert(userid,ipgid,outputf1C);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }

	        /* outputf2:"p32_ins_%d_2p",iplymonth */
	        strcpy(outputf2, trim(outputf2));
	        sprintf_s(outputf2A,sizeof outputf2A,"%s_�H",outputf2);
	        sprintf_s(outputf2B,sizeof outputf2B,"%s_���H",outputf2);
	        sprintf_s(outputf2C,sizeof outputf2C,"%s_�����s",outputf2);

	        sprintf_s(file2A,sizeof file2A,"%s/rptftp/%s",sApHome,rtrim(outputf2A));
	        rt = rptftpinsert(userid,ipgid,outputf2A);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }

	        sprintf_s(file2B,sizeof file2B,"%s/rptftp/%s",sApHome,rtrim(outputf2B));
	        rt = rptftpinsert(userid,ipgid,outputf2B);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }

	        sprintf_s(file2C,sizeof file2C,"%s/rptftp/%s",sApHome,rtrim(outputf2C));
	        rt = rptftpinsert(userid,ipgid,outputf2C);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }

	        fp1A=fopen(file1A,"w");
	        fp1B=fopen(file1B,"w");
	        fp1C=fopen(file1C,"w");
	        fp2A=fopen(file2A,"w");
	        fp2B=fopen(file2B,"w");
	        fp2C=fopen(file2C,"w");
        }

  	/*** 2p: ��W ***/
  	if (print_chk[1]=='1'){
  		/* ��W�T���q�l�� */
  		/* �ק��W�󪺩w�q (1110309003_SC1_�w�ﯲ��M�p�{���q����H�e�ܧ�)*/
  	  	if (fKind==' '){
	            sprintf_s(outputf12,sizeof outputf12,"p32_%d_2p_Z",iplymonth);
	            sprintf_s(outputf13,sizeof outputf13,"p32_ins_%d_2p_Z",iplymonth);
  	  	}else if (fKind=='t'){  /* ���s���ե� */
	            sprintf_s(outputf12,sizeof outputf12,"p32_%d_2p_Z_test",iplymonth);
	            sprintf_s(outputf13,sizeof outputf13,"p32_ins_%d_2p_Z_test",iplymonth);
  	  	}else if (fKind=='p'){  /* ���s�����J�p�� */
	            sprintf_s(outputf12,sizeof outputf12,"p32_%d_2p_Z_part",iplymonth);
	            sprintf_s(outputf13,sizeof outputf13,"p32_ins_%d_2p_Z_part",iplymonth);
                }
	        sprintf_s(file12,sizeof file12,"%s/rptftp/%s",sApHome,rtrim(outputf12));

	        rt = rptftpinsert(userid,ipgid,outputf12);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        sprintf_s(file13,sizeof file13,"%s/rptftp/%s",sApHome,rtrim(outputf13));
	        rt = rptftpinsert(userid,ipgid,outputf13);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        fp12=fopen(file12,"w");
	        fp13=fopen(file13,"w");
        }
  	/*** 2p: �p���p�� ***/
  	if (print_chk[2]=='1'){
	        /* 970515 , �p���p�Ȩ�����q�l�� */
  	  	if (fKind==' '){
	            sprintf_s(outputf14,sizeof outputf14,"p32_%d_2p_M",iplymonth);
	            sprintf_s(outputf15,sizeof outputf15,"p32_ins_%d_2p_M",iplymonth);
  	  	}else if (fKind=='t'){  /* ���s���ե� */
	            sprintf_s(outputf14,sizeof outputf14,"p32_%d_2p_M_test",iplymonth);
	            sprintf_s(outputf15,sizeof outputf15,"p32_ins_%d_2p_M_test",iplymonth);
  	  	}else if (fKind=='p'){  /* ���s�����J�p�� */
	            sprintf_s(outputf14,sizeof outputf14,"p32_%d_2p_M_part",iplymonth);
	            sprintf_s(outputf15,sizeof outputf15,"p32_ins_%d_2p_M_part",iplymonth);
                }
	        sprintf_s(file14,sizeof file14,"%s/rptftp/%s",sApHome,rtrim(outputf14));

	        rt = rptftpinsert(userid,ipgid,outputf14);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        sprintf_s(file15,sizeof file15,"%s/rptftp/%s",sApHome,rtrim(outputf15));
	        rt = rptftpinsert(userid,ipgid,outputf15);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        fp14=fopen(file14,"w");
	        fp15=fopen(file15,"w");
        }
  	/*** 2p: �Τ@�F�� ***/
  	if (print_chk[3]=='1'){
	        /* 970515 , �Τ@�F�ʯ���q�l�� */
  	  	if (fKind==' '){
	            sprintf_s(outputf16,sizeof outputf16,"p32_%d_2p_T",iplymonth);
	            sprintf_s(outputf17,sizeof outputf17,"p32_ins_%d_2p_T",iplymonth);
  	  	}else if (fKind=='t'){  /* ���s���ե� */
	            sprintf_s(outputf16,sizeof outputf16,"p32_%d_2p_T_test",iplymonth);
	            sprintf_s(outputf17,sizeof outputf17,"p32_ins_%d_2p_T_test",iplymonth);
  	  	}else if (fKind=='p'){  /* ���s�����J�p�� */
	            sprintf_s(outputf16,sizeof outputf16,"p32_%d_2p_T_part",iplymonth);
	            sprintf_s(outputf17,sizeof outputf17,"p32_ins_%d_2p_T_part",iplymonth);
                }
	        sprintf_s(file16,sizeof file16,"%s/rptftp/%s",sApHome,rtrim(outputf16));

	        rt = rptftpinsert(userid,ipgid,outputf16);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        sprintf_s(file17,sizeof file17,"%s/rptftp/%s",sApHome,rtrim(outputf17));
	        rt = rptftpinsert(userid,ipgid,outputf17);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        fp16=fopen(file16,"w");
	        fp17=fopen(file17,"w");
        }
  	/*** 2p: �p����� ***/
  	if (print_chk[4]=='1'){

  	  	if (fKind==' '){
	            sprintf_s(outputf22,sizeof outputf22,"p32_%d_2p_L",iplymonth);
	            sprintf_s(outputf23,sizeof outputf23,"p32_ins_%d_2p_L",iplymonth);
  	  	}else if (fKind=='t'){  /* ���s���ե� */
	            sprintf_s(outputf22,sizeof outputf22,"p32_%d_2p_L_test",iplymonth);
	            sprintf_s(outputf23,sizeof outputf23,"p32_ins_%d_2p_L_test",iplymonth);
  	  	}else if (fKind=='p'){  /* ���s�����J�p�� */
	            sprintf_s(outputf22,sizeof outputf22,"p32_%d_2p_L_part",iplymonth);
	            sprintf_s(outputf23,sizeof outputf23,"p32_ins_%d_2p_L_part",iplymonth);
                }
	        sprintf_s(file22,sizeof file22,"%s/rptftp/%s",sApHome,rtrim(outputf22));

	        rt = rptftpinsert(userid,ipgid,outputf22);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        sprintf_s(file23,sizeof file23,"%s/rptftp/%s",sApHome,rtrim(outputf23));
	        rt = rptftpinsert(userid,ipgid,outputf23);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        fp22=fopen(file22,"w");
	        fp23=fopen(file23,"w");
        }
 	/*** 2p: ��s�T�� ***/
  	if (print_chk[5]=='1'){

  	  	if (fKind==' '){
	            sprintf_s(outputf24,sizeof outputf24,"p32_%d_2p_S",iplymonth);
	            sprintf_s(outputf25,sizeof outputf25,"p32_ins_%d_2p_S",iplymonth);
  	  	}else if (fKind=='t'){  /* ���s���ե� */
	            sprintf_s(outputf24,sizeof outputf24,"p32_%d_2p_S_test",iplymonth);
	            sprintf_s(outputf25,sizeof outputf25,"p32_ins_%d_2p_S_test",iplymonth);
  	  	}else if (fKind=='p'){  /* ���s�����J�p�� */
	            sprintf_s(outputf24,sizeof outputf24,"p32_%d_2p_S_part",iplymonth);
	            sprintf_s(outputf25,sizeof outputf25,"p32_ins_%d_2p_S_part",iplymonth);
                }
	        sprintf_s(file24,sizeof file24,"%s/rptftp/%s",sApHome,rtrim(outputf24));

	        rt = rptftpinsert(userid,ipgid,outputf24);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        sprintf_s(file25,sizeof file25,"%s/rptftp/%s",sApHome,rtrim(outputf25));
	        rt = rptftpinsert(userid,ipgid,outputf25);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        fp24=fopen(file24,"w");
	        fp25=fopen(file25,"w");
        }

 	/*** 2p: �ڤO�h�T�� ***/
  	if (print_chk[6]=='1'){

  	  	if (fKind==' '){
	            sprintf_s(outputf28,sizeof outputf28,"p32_%d_2p_�ڤO�h",iplymonth);
	            sprintf_s(outputf29,sizeof outputf29,"p32_ins_%d_2p_�ڤO�h",iplymonth);
  	  	}else if (fKind=='t'){  /* ���s���ե� */
	            sprintf_s(outputf28,sizeof outputf28,"p32_%d_2p_�ڤO�h_test",iplymonth);
	            sprintf_s(outputf29,sizeof outputf29,"p32_ins_%d_2p_�ڤO�h_test",iplymonth);
  	  	}else if (fKind=='p'){  /* ���s�����J�p�� */
	            sprintf_s(outputf28,sizeof outputf28,"p32_%d_2p_�ڤO�h_part",iplymonth);
	            sprintf_s(outputf29,sizeof outputf29,"p32_ins_%d_2p_�ڤO�h_part",iplymonth);
                }
	        sprintf_s(file28,sizeof file28,"%s/rptftp/%s",sApHome,rtrim(outputf28));

	        rt = rptftpinsert(userid,ipgid,outputf28);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        sprintf_s(file29,sizeof file29,"%s/rptftp/%s",sApHome,rtrim(outputf29));
	        rt = rptftpinsert(userid,ipgid,outputf29);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        fp28=fopen(file28,"w");
	        fp29=fopen(file29,"w");
        }

        /*** 2p: �鲱���x�q (1021218002_C1) ***/
  	if (print_chk[7]=='1'){

  	  	if (fKind==' '){
	            sprintf_s(outputf30,sizeof outputf30,"p32_%d_2p_�鲱���x�q",iplymonth);
	            sprintf_s(outputf31,sizeof outputf31,"p32_ins_%d_2p_�鲱���x�q",iplymonth);
  	  	}else if (fKind=='t'){  /* ���s���ե� */
	            sprintf_s(outputf30,sizeof outputf30,"p32_%d_2p_�鲱���x�q_test",iplymonth);
	            sprintf_s(outputf31,sizeof outputf31,"p32_ins_%d_2p_�鲱���x�q_test",iplymonth);
  	  	}else if (fKind=='p'){  /* ���s�����J�p�� */
	            sprintf_s(outputf30,sizeof outputf30,"p32_%d_2p_�鲱���x�q_part",iplymonth);
	            sprintf_s(outputf31,sizeof outputf31,"p32_ins_%d_2p_�鲱���x�q_part",iplymonth);
                }
	        sprintf_s(file30,sizeof file30,"%s/rptftp/%s",sApHome,rtrim(outputf30));

	        rt = rptftpinsert(userid,ipgid,outputf30);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        sprintf_s(file31,sizeof file31,"%s/rptftp/%s",sApHome,rtrim(outputf31));
	        rt = rptftpinsert(userid,ipgid,outputf31);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        fp30=fopen(file30,"w");
	        fp31=fopen(file31,"w");
        }

        /*** 2p: ��ù�T�� (1120724008_C02) ***/
  	if (print_chk[8]=='1'){

  	  	if (fKind==' '){
	            sprintf_s(outputf62,sizeof outputf62,"p32_%d_2p_��ù�T��",iplymonth);
	            sprintf_s(outputf63,sizeof outputf63,"p32_ins_%d_2p_��ù�T��",iplymonth);
  	  	}else if (fKind=='t'){  /* ���s���ե� */
	            sprintf_s(outputf62,sizeof outputf62,"p32_%d_2p_��ù�T��_test",iplymonth);
	            sprintf_s(outputf63,sizeof outputf63,"p32_ins_%d_2p_��ù�T��_test",iplymonth);
  	  	}else if (fKind=='p'){  /* ���s�����J�p�� */
	            sprintf_s(outputf62,sizeof outputf62,"p32_%d_2p_��ù�T��_part",iplymonth);
	            sprintf_s(outputf63,sizeof outputf63,"p32_ins_%d_2p_��ù�T��_part",iplymonth);
                }
	        sprintf_s(file62,sizeof file62,"%s/rptftp/%s",sApHome,rtrim(outputf62));

	        rt = rptftpinsert(userid,ipgid,outputf62);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        sprintf_s(file63,sizeof file63,"%s/rptftp/%s",sApHome,rtrim(outputf63));
	        rt = rptftpinsert(userid,ipgid,outputf63);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        fp62=fopen(file62,"w");
	        fp63=fopen(file63,"w");
        }

        /*** 2p: �w�����T�� (1030916005_C1) ***/
  	if (print_chk[9]=='1'){
  	  	if (fKind==' '){
	            sprintf_s(outputf34,sizeof outputf34,"p32_%d_2p_�w����",iplymonth);
	            sprintf_s(outputf35,sizeof outputf35,"p32_ins_%d_2p_�w����",iplymonth);
  	  	}else if (fKind=='t'){  /* ���s���ե� */
	            sprintf_s(outputf34,sizeof outputf34,"p32_%d_2p_�w����_test",iplymonth);
	            sprintf_s(outputf35,sizeof outputf35,"p32_ins_%d_2p_�w����_test",iplymonth);
  	  	}else if (fKind=='p'){  /* ���s�����J�p�� */
	            sprintf_s(outputf34,sizeof outputf34,"p32_%d_2p_�w����_part",iplymonth);
	            sprintf_s(outputf35,sizeof outputf35,"p32_ins_%d_2p_�w����_part",iplymonth);
                }
	        sprintf_s(file34,sizeof file34,"%s/rptftp/%s",sApHome,rtrim(outputf34));

	        rt = rptftpinsert(userid,ipgid,outputf34);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        sprintf_s(file35,sizeof file35,"%s/rptftp/%s",sApHome,rtrim(outputf35));
	        rt = rptftpinsert(userid,ipgid,outputf35);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        fp34=fopen(file34,"w");
	        fp35=fopen(file35,"w");
        }

        /*** 2p: ��L����~-����~(�T��) ***/
  	if ((print_chk[10]=='1') && (chk_PA > 0)){
  	  	if (fKind==' '){
	            sprintf_s(outputf36,sizeof outputf36,"p32_%d_2p_����~",iplymonth);
	            sprintf_s(outputf37,sizeof outputf37,"p32_ins_%d_2p_����~",iplymonth);
  	  	}else if (fKind=='t'){  /* ���s���ե� */
	            sprintf_s(outputf36,sizeof outputf36,"p32_%d_2p_����~_test",iplymonth);
	            sprintf_s(outputf37,sizeof outputf37,"p32_ins_%d_2p_����~_test",iplymonth);
  	  	}else if (fKind=='p'){  /* ���s�����J�p�� */
	            sprintf_s(outputf36,sizeof outputf36,"p32_%d_2p_����~_part",iplymonth);
	            sprintf_s(outputf37,sizeof outputf37,"p32_ins_%d_2p_����~_part",iplymonth);
                }
	        sprintf_s(file36,sizeof file36,"%s/rptftp/%s",sApHome,rtrim(outputf36));

	        rt = rptftpinsert(userid,ipgid,outputf36);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        sprintf_s(file37,sizeof file37,"%s/rptftp/%s",sApHome,rtrim(outputf37));
	        rt = rptftpinsert(userid,ipgid,outputf37);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        fp36=fopen(file36,"w");
	        fp37=fopen(file37,"w");
        }

        /*** 2p: �p�{��-(���t����) ***/
  	if ((print_chk[11]=='1') && (chk_PA > 0)){
  	  	if (fKind==' '){
	            sprintf_s(outputf38,sizeof outputf38,"p32_%d_2p_�p�{��",iplymonth);
	            sprintf_s(outputf39,sizeof outputf39,"p32_ins_%d_2p_�p�{��",iplymonth);
  	  	}else if (fKind=='t'){  /* ���s���ե� */
	            sprintf_s(outputf38,sizeof outputf38,"p32_%d_2p_�p�{��_test",iplymonth);
	            sprintf_s(outputf39,sizeof outputf39,"p32_ins_%d_2p_�p�{��_test",iplymonth);
  	  	}else if (fKind=='p'){  /* ���s�����J�p�� */
	            sprintf_s(outputf38,sizeof outputf38,"p32_%d_2p_�p�{��_part",iplymonth);
	            sprintf_s(outputf39,sizeof outputf39,"p32_ins_%d_2p_�p�{��_part",iplymonth);
                }
	        sprintf_s(file38,sizeof file38,"%s/rptftp/%s",sApHome,rtrim(outputf38));

	        rt = rptftpinsert(userid,ipgid,outputf38);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        sprintf_s(file39,sizeof file39,"%s/rptftp/%s",sApHome,rtrim(outputf39));
	        rt = rptftpinsert(userid,ipgid,outputf39);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        fp38=fopen(file38,"w");
	        fp39=fopen(file39,"w");
        }

        /*** 2p: ���-(���t����~) ***/
  	if ((print_chk[12]=='1') && (chk_PA > 0)){
  	  	if (fKind==' '){
	            sprintf_s(outputf42,sizeof outputf42,"p32_%d_2p_���",iplymonth);
	            sprintf_s(outputf43,sizeof outputf43,"p32_ins_%d_2p_���",iplymonth);
  	  	}else if (fKind=='t'){  /* ���s���ե� */
	            sprintf_s(outputf42,sizeof outputf42,"p32_%d_2p_���_test",iplymonth);
	            sprintf_s(outputf43,sizeof outputf43,"p32_ins_%d_2p_���_test",iplymonth);
  	  	}else if (fKind=='p'){  /* ���s�����J�p�� */
	            sprintf_s(outputf42,sizeof outputf42,"p32_%d_2p_���_part",iplymonth);
	            sprintf_s(outputf43,sizeof outputf43,"p32_ins_%d_2p_���_part",iplymonth);
                }
	        sprintf_s(file42,sizeof file42,"%s/rptftp/%s",sApHome,rtrim(outputf42));

	        rt = rptftpinsert(userid,ipgid,outputf42);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        sprintf_s(file43,sizeof file43,"%s/rptftp/%s",sApHome,rtrim(outputf43));
	        rt = rptftpinsert(userid,ipgid,outputf43);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        fp42=fopen(file42,"w");
	        fp43=fopen(file43,"w");
        }

        /*** 2p: �����}�M (1061229002_C1) ***/
  	if (print_chk[13]=='1'){
  	  	if (fKind==' '){
	            sprintf_s(outputf46,sizeof outputf46,"p32_%d_2p_�����}�M",iplymonth);
	            sprintf_s(outputf47,sizeof outputf47,"p32_ins_%d_2p_�����}�M",iplymonth);
  	  	}else if (fKind=='t'){  /* ���s���ե� */
	            sprintf_s(outputf46,sizeof outputf46,"p32_%d_2p_�����}�M_test",iplymonth);
	            sprintf_s(outputf47,sizeof outputf47,"p32_ins_%d_2p_�����}�M_test",iplymonth);
  	  	}else if (fKind=='p'){  /* ���s�����J�p�� */
	            sprintf_s(outputf46,sizeof outputf46,"p32_%d_2p_�����}�M_part",iplymonth);
	            sprintf_s(outputf47,sizeof outputf47,"p32_ins_%d_2p_�����}�M_part",iplymonth);
                }
	        sprintf_s(file46,sizeof file46,"%s/rptftp/%s",sApHome,rtrim(outputf46));

	        rt = rptftpinsert(userid,ipgid,outputf46);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        sprintf_s(file47,sizeof file47,"%s/rptftp/%s",sApHome,rtrim(outputf47));
	        rt = rptftpinsert(userid,ipgid,outputf47);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        fp46=fopen(file46,"w");
	        fp47=fopen(file47,"w");
        }

        /*** 2p: �S�����O (1100504003_SC1) ***/
  	if (print_chk[14]=='1'){
  	  	if (fKind==' '){
	            sprintf_s(outputf50,sizeof outputf50,"p32_%d_2p_�S�����O",iplymonth);
	            sprintf_s(outputf51,sizeof outputf51,"p32_ins_%d_2p_�S�����O",iplymonth);
  	  	}else if (fKind=='t'){  /* ���s���ե� */
	            sprintf_s(outputf50,sizeof outputf50,"p32_%d_2p_�S�����O_test",iplymonth);
	            sprintf_s(outputf51,sizeof outputf51,"p32_ins_%d_2p_�S�����O_test",iplymonth);
  	  	}else if (fKind=='p'){  /* ���s�����J�p�� */
	            sprintf_s(outputf50,sizeof outputf50,"p32_%d_2p_�S�����O_part",iplymonth);
	            sprintf_s(outputf51,sizeof outputf51,"p32_ins_%d_2p_�S�����O_part",iplymonth);
                }
	        sprintf_s(file50,sizeof file50,"%s/rptftp/%s",sApHome,rtrim(outputf50));

	        rt = rptftpinsert(userid,ipgid,outputf50);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        sprintf_s(file51,sizeof file51,"%s/rptftp/%s",sApHome,rtrim(outputf51));
	        rt = rptftpinsert(userid,ipgid,outputf51);
	        if (rt != 0)
	        {
	            printf("rptftp error\n");
	            goto errexit;
	        }
	        fp50=fopen(file50,"w");
	        fp51=fopen(file51,"w");
        }

        /*** 2p: �q��JB (1100820015_SC1) ***/
  	if (print_chk[15]=='1')
  	{

  	    if (fKind==' '){
	        sprintf_s(outputf52,sizeof outputf52,"p32_%d_2p_�H_JB",iplymonth);
	        sprintf_s(outputf53,sizeof outputf53,"p32_ins_%d_2p_�H_JB",iplymonth);
  	    }else if (fKind=='t'){  /* ���s���ե� */
	        sprintf_s(outputf52,sizeof outputf52,"p32_%d_2p_JB_test",iplymonth);
	        sprintf_s(outputf53,sizeof outputf53,"p32_ins_%d_2p_JB_test",iplymonth);
  	    }else if (fKind=='p'){  /* ���s�����J�p�� */
	        sprintf_s(outputf52,sizeof outputf52,"p32_%d_2p_JB_part",iplymonth);
	        sprintf_s(outputf53,sizeof outputf53,"p32_ins_%d_2p_JB_part",iplymonth);
            }

	    sprintf_s(file52,sizeof file52,"%s/rptftp/%s",sApHome,rtrim(outputf52));
	    rt = rptftpinsert(userid,ipgid,outputf52);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }
	    sprintf_s(file53,sizeof file53,"%s/rptftp/%s",sApHome,rtrim(outputf53));
	    rt = rptftpinsert(userid,ipgid,outputf53);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }
	    fp52=fopen(file52,"w");
	    fp53=fopen(file53,"w");
        }


        /*** 2p: �N�ӻȦ� (1110308005_SC3) ***/
        if(print_chk[16]=='1')
        {
  	    if (fKind==' '){
	        sprintf_s(outputf54,sizeof outputf54,"p32_%d_2p_�H_NEXTBANK",iplymonth);
	        sprintf_s(outputf55,sizeof outputf55,"p32_ins_%d_2p_�H_NEXTBANK",iplymonth);
  	    }else if (fKind=='t'){  /* ���s���ե� */
	        sprintf_s(outputf54,sizeof outputf54,"p32_%d_2p_NEXTBANK_test",iplymonth);
	        sprintf_s(outputf55,sizeof outputf55,"p32_ins_%d_2p_NEXTBANK_test",iplymonth);
  	    }else if (fKind=='p'){  /* ���s�����J�p�� */
	        sprintf_s(outputf54,sizeof outputf54,"p32_%d_2p_NEXTBANK_part",iplymonth);
	        sprintf_s(outputf55,sizeof outputf55,"p32_ins_%d_2p_NEXTBANK_part",iplymonth);
            }
	    sprintf_s(file54,sizeof file54,"%s/rptftp/%s",sApHome,rtrim(outputf54));

	    rt = rptftpinsert(userid,ipgid,outputf54);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }
	    sprintf_s(file55,sizeof file55,"%s/rptftp/%s",sApHome,rtrim(outputf55));
	    rt = rptftpinsert(userid,ipgid,outputf55);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }
	    fp54=fopen(file54,"w");
	    fp55=fopen(file55,"w");
        }

        /*** 2p: �I��MOMO (1110816006_SC1) ***/
        if(print_chk[17]=='1')
        {
  	    if (fKind==' '){
	        sprintf_s(outputf58,sizeof outputf58,"p32_%d_2p_MOMO",iplymonth);
	        sprintf_s(outputf59,sizeof outputf59,"p32_ins_%d_2p_MOMO",iplymonth);
  	    }else if (fKind=='t'){  /* ���s���ե� */
	        sprintf_s(outputf58,sizeof outputf58,"p32_%d_2p_MOMO_test",iplymonth);
	        sprintf_s(outputf59,sizeof outputf59,"p32_ins_%d_2p_MOMO_test",iplymonth);
  	    }else if (fKind=='p'){  /* ���s�����J�p�� */
	        sprintf_s(outputf58,sizeof outputf58,"p32_%d_2p_MOMO_part",iplymonth);
	        sprintf_s(outputf59,sizeof outputf59,"p32_ins_%d_2p_MOMO_part",iplymonth);
            }
	    sprintf_s(file58,sizeof file58,"%s/rptftp/%s",sApHome,rtrim(outputf58));

	    rt = rptftpinsert(userid,ipgid,outputf58);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }
	    sprintf_s(file59,sizeof file59,"%s/rptftp/%s",sApHome,rtrim(outputf59));
	    rt = rptftpinsert(userid,ipgid,outputf59);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }
	    fp58=fopen(file58,"w");
	    fp59=fopen(file59,"w");
        }

        /*** 2p: F���� (1110317002_SC1) ***/
        if(print_chk[18]=='1')
        {
  	    if (fKind==' '){
	        sprintf_s(outputf60,sizeof outputf60,"p32_%d_2p_F ",iplymonth);
	        sprintf_s(outputf61,sizeof outputf61,"p32_ins_%d_2p_F",iplymonth);
  	    }else if (fKind=='t'){  /* ���s���ե� */
	        sprintf_s(outputf60,sizeof outputf60,"p32_%d_2p_F_test",iplymonth);
	        sprintf_s(outputf61,sizeof outputf61,"p32_ins_%d_2p_F_test",iplymonth);
  	    }else if (fKind=='p'){  /* ���s�����J�p�� */
	        sprintf_s(outputf60,sizeof outputf60,"p32_%d_2p_F_part",iplymonth);
	        sprintf_s(outputf61,sizeof outputf61,"p32_ins_%d_2p_F_part",iplymonth);
            }
	    sprintf_s(file60,sizeof file60,"%s/rptftp/%s",sApHome,rtrim(outputf60));

	    rt = rptftpinsert(userid,ipgid,outputf60);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }
	    sprintf_s(file61,sizeof file61,"%s/rptftp/%s",sApHome,rtrim(outputf61));
	    rt = rptftpinsert(userid,ipgid,outputf61);
	    if (rt != 0)
	    {
	        printf("rptftp error\n");
	        goto errexit;
	    }
	    fp60=fopen(file60,"w");
	    fp61=fopen(file61,"w");
        }

        /*** ��L: �R�q�� (1120927002_C05)  ***/
  	if (print_chk[15]=='2'){
  		if (fKind==' ')
  		{
  			sprintf_s(outputf32,sizeof outputf32,"p32_%d_�R�q��",iplymonth);
  			sprintf_s(outputf33,sizeof outputf33,"p32_ins_%d_�R�q��",iplymonth);
  		}else if (fKind=='t'){
  			sprintf_s(outputf32,sizeof outputf32,"p32_%d_�R�q��_test",iplymonth);
  			sprintf_s(outputf33,sizeof outputf33,"p32_ins_%d_�R�q��_test",iplymonth);
  		}else if (fKind=='p'){
  			sprintf_s(outputf32,sizeof outputf32,"p32_%d_�R�q��_part",iplymonth);
  			sprintf_s(outputf33,sizeof outputf33,"p32_ins_%d_�R�q��_part",iplymonth);
  		}
  		sprintf_s(file32,sizeof file32,"%s/rptftp/%s",sApHome,rtrim(outputf32));

  		rt = rptftpinsert(userid,ipgid,outputf32);
  		if (rt != 0)
  		{
  			printf("rptftp error\n");
  			goto errexit;
  		}
  		sprintf_s(file33,sizeof file33,"%s/rptftp/%s",sApHome,rtrim(outputf33));
  		rt = rptftpinsert(userid,ipgid,outputf33);
  		if (rt != 0)
  		{
  			printf("rptftp error\n");
  			goto errexit;
  		}
  		fp32=fopen(file32,"w");
  		fp33=fopen(file33,"w");
        }

        /*  Ū���~�bwhere�ܼƬ����󲣻s�ɮ� */
        if (print_chk[0]=='9'){
		    sprintf_s( outputf12,sizeof outputf12, "p32_%d_2p_other", iplymonth);
		    sprintf_s( file12,sizeof file12,"%s/rptftp/%s",sApHome,rtrim(outputf12));

		    rt = rptftpinsert(userid,ipgid,outputf12);
		    if (rt != 0)
		    {
		        printf("rptftp error\n");
		        goto errexit;
		    }
		    sprintf_s( outputf13,sizeof outputf13, "p32_ins_%d_2p_other", iplymonth);
		    sprintf_s( file13,sizeof file13,"%s/rptftp/%s",sApHome,rtrim(outputf13));

		    rt = rptftpinsert(userid,ipgid,outputf13);
		    if (rt != 0)
		    {
                        printf("rptftp error\n");
		        goto errexit;
		    }
		    fp12=fopen(file12,"w");
		    fp13=fopen(file13,"w");
        }
    }

  sprintf_s(stmt,sizeof stmt, "SELECT first 1 ipolicy "
               "  FROM policy_302 "
               " WHERE Year(dply_begin) = ? "
               "   AND Month(dply_begin) = ? "
               "   AND iengine = ? "
               "   AND ilicense = ? "
               "   AND fcard_class = '1' ");

  $PREPARE prepA FROM $stmt;

  sprintf_s(stmt,sizeof stmt, "SELECT first 1 ipolicy "
               "  FROM policy_302 "
               " WHERE Year(dply_begin) = ? "
               "   AND Month(dply_begin) = ? "
               "   AND itag = ? "
               "   AND ilicense = ? "
               "   AND fcard_class = '1' ");

  $PREPARE prepB FROM $stmt;

  /* �j���I�W�M�����psex_age_c�Biquery_num_c  modify by sylvia 106.03.28 */
  sprintf_s(stmt,sizeof stmt,
    " SELECT dply_bgn_comp,dply_end_comp,comp_prem, \
             lia_ac_cntc,plia_acc_c,fcomp_class,fcomp_class_last, \
             irel_card,iquery_num_c,pre_dply1_bgn,pre_dply1_end, \
             pre_prem1,psex_age_c,remark1,remark2,remark4, icar_type, \
             ichange_note, dbirth, mcomp_prem_sug,qdrunk_driving,qviolate \
        FROM policy_302             \
       WHERE ipolicy = ?            \
         AND Year(dply_begin) = ?   \
         AND Month(dply_begin) = ? ");
  $PREPARE comdtl FROM $stmt;

  /* 950704 ,�s�W left join ca_pa_ply_302 �� daily_pay ��� */
  /* �] ca_pa_ply_302 ipolicy, iins_type ����U�����h�� , �G�[�W DISTINCT*/
  sprintf_s(stmt,sizeof stmt,
   "  SELECT DISTINCT a.ipolicy,a.iins_type, \
             a.minjured_cover,a.mdeath_cover,a.mdamage_cover,a.mdeduct,a.mprem,a.mins_premium, \
             a.qcoverage,a.pre_inj_cover,a.pre_dea_cover,a.pre_dam_cover,a.pre_deduct,         \
             a.pre_minsprem,a.qserial,a.ch_deduct,a.linnum,a.mdiscount,a.pre_mdiscount,a.qday, \
             a.mexpense,a.mexp_disc,a.ori_inj_cover , a.ori_dea_cover , a.ori_dam_cover ,      \
             a.ori_premium, b.iins_class, nvl(c.daily_pay,0),nvl(c.pre_daily_pay,0), nvl(c.ori_daily_pay,0),  \
             b.qserial, a.ori_deduct, nvl(c.iins_scope,' '), \
             case when a.iins_type in ('07','10','127') then  \
                  CAST(regex_replace(replace(replace(replace(replace(trim(provision)||';','S;',''),'P;',''),'Q;',''),'M;',''),';+$','')AS char(20)) \
                  when a.iins_type not in ('01','05','09','11','181','201','205','209','211') then  \
                  CAST(regex_replace(replace(replace(replace(trim(provision)||';','P;',''),'Q;',''),'M;',''),';+$','')AS char(20)) \
             else a.provision end \
        FROM ply_ins_type_302 as a \
        INNER JOIN iins_class as b \
              ON a.iins_type = b.iins_type \
         LEFT JOIN ca_pa_ply_302 as c \
              ON a.ipolicy = c.ipolicy AND a.iins_type=c.iins_type \
       WHERE a.ipolicy = ?  \
       ORDER BY  b.iins_class, b.qserial ");
  /* printf("stmt[%s]\n", stmt);
     printf(" ------- strlen stmt1 = [%d]\n " , strlen(stmt)); */
  $PREPARE ins_dtl FROM $stmt;
  $DECLARE cv_cur CURSOR FOR ins_dtl;

  /* 101.08.07 �����ǯu �q�ܦr�� */
  sprintf_s(stmt,sizeof stmt, " SELECT ibig_office, itel \
                    FROM ca_big_office \
                   WHERE fclass = ? \
                     AND ibig_comp = ? ");
  $PREPARE prep2 FROM $stmt;

  sprintf_s(stmt,sizeof stmt, " SELECT iquota, ileader  \
                    FROM officer \
                   WHERE iofficer = ?");

  $PREPARE prep3 FROM $stmt;

  sprintf_s( stmt,sizeof stmt, "SELECT NVL(SUM(NVL(mins_premium,0)),0)"
                 "  FROM ply_ins_type_302 "
                 " WHERE ipolicy = ? ");

  $PREPARE prep4 FROM $stmt;

  sprintf_s(stmt,sizeof stmt, " SELECT nname \
                    FROM officer \
                   WHERE iofficer = ?");

  $PREPARE prep6 FROM $stmt;

  sprintf_s(stmt,sizeof stmt, "SELECT icode_no,fgen302file1 \
                   FROM tmp_barcode_officer \
                  WHERE icode_no <> 'EB000001' \
                    and (iofficer =? or iofficer =? ) ");
  $PREPARE preBarcode_off FROM $stmt;

  sprintf_s(stmt,sizeof stmt, "SELECT icode_no,fgen302file1 \
                   FROM tmp_barcode_officer \
                  WHERE icode_no = 'EB000001' \
                    and (iofficer =? or iofficer =? ) ");
  $PREPARE preBarcode_off_51 FROM $stmt;

  sprintf_s(stmt,sizeof stmt, " SELECT nroute \
                     FROM cm_route \
                    WHERE iroute = ?");
  $PREPARE prep_nroute FROM $stmt;

  sprintf_s(stmt,sizeof stmt, "SELECT count(*) \
                   FROM tmp_no_barcode_list \
                  WHERE tmp_iofficer =? ");
  $PREPARE preNo_barcode FROM $stmt;

  sprintf_s(stmt,sizeof stmt, "SELECT count(*) \
                   FROM tmp_force_print_302 \
                  WHERE tmp_type =? and tmp_value =?");
  $PREPARE prePrint_302 FROM $stmt;

  /* 101.10 �A�ק� "�A��50�I�ؤ�����" �P�_�覡  */
  sprintf_s(stmt,sizeof stmt, "SELECT count(*) \
                   FROM tmp_ins50_cartype \
                  WHERE icar_type =? ");
  $PREPARE preIns50_cartype FROM $stmt;

  /* 101.10 �Afor tpl_barcode, check �O�_�ŦXtpl_barcode �z����� */
  sprintf_s(stmt,sizeof stmt, "select count(*) from policy_302 a  \
                  where a.ipolicy = ?  \
                    and a.icar_type in ('03','04','19','22','01','02') \
                    and a.ibrand[1,2] not in (%s) \
                    and NOT EXISTS (SELECT * FROM ply_ins_type_302 \
                                     WHERE ipolicy = a.ipolicy \
                                       AND iins_type in (%s,%s) ) ", SPC_BRAND_STRING, INS01_STRING, INS11_STRING) ;
  $PREPARE prep_tpl_chk FROM $stmt;

  /* �Z�O�h�~�u�O21+50�̥B��ĳ�I�ؤ����t�����ѵs�̡A��[�J�T����jbarcode */
  sprintf_s(stmt,sizeof stmt, "SELECT count(*) FROM ply_ins_type_302 a \
                  WHERE a.ipolicy =  ? \
                    AND EXISTS (SELECT * FROM ply_ins_type_302  \
                                 WHERE ipolicy = a.ipolicy  \
                                   AND iins_type = ? \
                                   AND pre_dam_cover > 0) \
                    AND NOT EXISTS (SELECT * FROM ply_ins_type_302  \
                                     WHERE ipolicy = a.ipolicy  \
                                       AND iins_type IN (%s,%s)  )  \
                    AND NOT EXISTS (SELECT * FROM ply_ins_type_302  \
                                     WHERE ipolicy = a.ipolicy  \
                                       AND iins_type <> '50' \
                                       AND pre_dam_cover > 0)  ", INS01_STRING, INS11_STRING) ;
  $PREPARE prep_check_ins FROM $stmt;

  /* 101.10 �Afor tpl_barcode, check �O�_�ŦX �D���Ӿ���barcode �I�ر��� */
  sprintf_s(stmt,sizeof stmt, "SELECT count(*) \
                   FROM ply_ins_type_302 \
                  WHERE ipolicy =? \
                    AND iins_type IN (%s,%s) ", INS01_STRING, INS11_STRING);
  $PREPARE prep_chk01_11 FROM $stmt;

  /* �ˮ�110�I�ج���:110����,110�I�حӼ�,����I�حӼ� add by sylvia 104.05.19  */
  sprintf_s(stmt,sizeof stmt, "SELECT round((year(dply_end)-ipro_year)*12+(month(dply_end)-qpro_month)),\
                       (select count(*) from ply_ins_type_last where ipolicy = a.ipolicy \
                           and iins_type in ('110','111','112')), \
                       (select count(*) from ply_ins_type_last where ipolicy = a.ipolicy) \
                  from ply_relation_last a, policy_last b \
                 where a.ipolicy = b.ipolicy and a.ipolicy = ? ");
  $PREPARE prep_110check FROM $stmt;


  sprintf_s(stmt,sizeof stmt, "SELECT count(*) "
                "  FROM policy_302 "
                " WHERE Year(dply_begin) = ? "
                "   AND Month(dply_begin) = ? "
                "   AND fcard_class = ?  "
                "   AND ipolicy = ? "
                "   AND ilicense = ? " );

  $PREPARE prepChk_rel FROM $stmt;

  sprintf_s(stmt,sizeof stmt, "SELECT paydate, year(paydate) \
                   FROM ao_rcv_type \
                  WHERE ipre_end = ' ' AND trcv = ? AND ipre_rcv= ? AND iins_kind = ? ");
  $PREPARE pre_paydate FROM $stmt;

  /* �����b���אּŪ��ao_rcv_acct add by 061476 (1090220003_SC1) */
  sprintf_s(stmt,sizeof stmt, "SELECT max(CASE WHEN ibank = '808' THEN iacc ELSE '' END), \
                        max(CASE WHEN ibank = '700' THEN iacc ELSE '' END), \
                        max(CASE WHEN ibank = '007' THEN iacc ELSE '' END), \
                        max(CASE WHEN ibank = '008' THEN iacc ELSE '' END), \
                        max(CASE WHEN ibank = '009' THEN iacc ELSE '' END), \
                        max(CASE WHEN ibank = '013' THEN iacc ELSE '' END), \
                        max(CASE WHEN ibank = 'MKT' THEN iacc ELSE '' END)  \
                FROM ao_rcv_acct WHERE trcv = ? ");
  $PREPARE pre_transno FROM $stmt;

  /* 102.12.03 barcodeú�ڳ椧���X�T�O�O���A�ϥ���O�ɤ��O�O�A�ӧ�q�@�}�l�g�J���C��ú���ɨ��o�O�O�A
               �Ӽt�ӱN�|��U�P�_�`�O�O�P���X�T�O�O(�C��ú���ɨ��o�O�O)�O�_�@�P */
  sprintf_s(stmt,sizeof stmt, "SELECT sum(mprem) \
                 FROM ao_rcv_type \
                WHERE data_type='3' and iyear= ? AND trcv = ? ");
  $PREPARE pre_payPrem FROM $stmt;

  /* 101.12 �A ���N�I�ګO��[���O7]�B [���OP(=���O1�B�P�@�O��X�I�T��)] �̩β��`��[���OY]�A�����s��O�q���ѡB�u���s�j���I��O�q����
  sprintf_s(stmt,sizeof stmt, "SELECT count(*) \
                   FROM tmp_reject_client_ply \
                  WHERE ipolicy = ? \
                    AND freason in ('7','P','Y')");
  $PREPARE prep_reject FROM $stmt;
  */
  /* 970822,�����ɼW�[�@���Q�O�I�H�W�U */
  sprintf_s(stmt,sizeof stmt, "SELECT first 1 nvl(ninsurant,' '),nvl(iinsurant,' '),to_char(dbirth) ,nvl(nbeneficiary,' '), \
                        CASE \
                           WHEN nvl(relation_bene,' ') = '1' THEN '���H' \
                           WHEN nvl(relation_bene,' ') = '2' THEN '�a��' \
                           WHEN nvl(relation_bene,' ') = '3' THEN '�O�Υ������H' \
                           WHEN nvl(relation_bene,' ') = '4' THEN '�ŰȤH' \
                           WHEN nvl(relation_bene,' ') = '5' THEN '�]���޲z�H' \
                           WHEN nvl(relation_bene,' ') = '6' THEN '�k�w�~�ӤH' \
                        ELSE ' ' END AS relation_bene \
                   FROM ca_pa_ply_302 \
                  WHERE ipolicy =? AND iins_type='56' ");
  $PREPARE prePa_list FROM $stmt;
  #ifdef PRINTF_FLAG
  printf(" ------- stmt = [%s]\n " , stmt);
  #endif

  /* 102.09.11 Ū��car_code�]�w�� (���j���ӦW��)*/
  sprintf_s(stmt,sizeof stmt, "SELECT chiname \
                   FROM car_code \
                  WHERE kind = ? AND detail = ? ");
  $PREPARE pre_second_hand FROM $stmt;

  /* 102.11.29 ���j�s�W�q�����u*/
  /* sprintf_s(stmt,sizeof stmt,  " SELECT trim(column_9) \
                     FROM cm_route_data \
                    WHERE ipolicy1 = ? and nvl(ipolicy2,' ')=' '"); */

  /* �o�������᪺����Ÿ� modify by sylvia 105.05.09 */
  sprintf_s(stmt,sizeof stmt,  " SELECT case when ascii(substr(column_9, length(column_9),1)) = 10 then \
                          substr(column_9, 1 , length(column_9)-2 ) else trim(column_9) end \
                      FROM cm_route_data \
                    WHERE ipolicy1 = ? and nvl(ipolicy2,' ')=' '");
  $PREPARE prep_route_data FROM $stmt;


  /* 102.12.25 ���oA��]�^�k�^�g�� */
  sprintf_s(stmt,sizeof stmt,  " SELECT iofficer \
                     FROM ca_promote_officer \
                    WHERE iofficer_ori = ? And ibig_office = ? ");
  $PREPARE prep_ca_prmt_off FROM $stmt;

  /* 102.12.25 ���oB�������A����I�N�� */
  sprintf_s(stmt,sizeof stmt, " SELECT ibus_location \
                    FROM officer \
                   WHERE iofficer = ?");
  $PREPARE prep_location FROM $stmt;

  /* 102.12.25 ���o�޲z�W�� */
  sprintf_s(stmt,sizeof stmt, " SELECT ibus_location \
                    FROM officer \
                   WHERE iofficer = ?");
  $PREPARE prep_location FROM $stmt;

  /* 111.04.22 �O�_�ئbcar354�� */
  sprintf_s(stmt,sizeof stmt, " SELECT count(*) \
                    FROM ca_renew_jb \
                   WHERE ipolicy = ? AND dply_ym = '%s' ",sCYYMM);
  $PREPARE prep_renew_jb FROM $stmt;

  /* 111.10.18 �O�_�]�tF���� */
  sprintf_s(stmt,sizeof stmt, " SELECT count(*) \
                    FROM ply_ins_type_302 \
                   WHERE ipolicy = ? AND trim(provision)||';' matches '*F;*' ");
  $PREPARE prep_provision_f FROM $stmt;


   /* 102.03 ���O�X��A�έ�^�k�s�w�L�s�A�������s�έ�ӧO�ɮ� */
   /* 100.03.01,�w���� �έ�W�b�� */
   /* �έ�W�b��H4�N��, �έ�U�b��H8�N��*/
  if( intopt == 1){         /* �u���s option in ('1') �B�t�έ�U�b�� */
      sprintf_s( sTmp,sizeof sTmp, " AND option = '1' ");
      sprintf_s( sTmp4,sizeof sTmp4, " AND option = '1' ");
  }else if( intopt == 19){  /* �u���s option in ('1','9') �B�t�έ�U�b�� (if 5p) */
      sprintf_s( sTmp,sizeof sTmp, " AND option in ('1','9') " );
      sprintf_s( sTmp4,sizeof sTmp4, " AND option in ('1','9') ");
  }else if( intopt == 2){   /* �u���s option in ('1') �����t�έ� (if 5p)*/
      sprintf_s( sTmp,sizeof sTmp, " AND option = '1' AND iofficer not like 'A09%%' ");
      sprintf_s( sTmp4,sizeof sTmp4," AND option = '1' AND ibig_office not like 'A09%%'");
  }else if( intopt == 11){  /* �u���s option in ('1','9')�����t�έ� (19-8=11) (if 5p) */
      sprintf_s( sTmp,sizeof sTmp, " AND option in ('1','9') AND iofficer not like 'A09%%' ");
      sprintf_s( sTmp4,sizeof sTmp4," AND option in ('1','9') AND ibig_office not like 'A09%%'");
  }else if( intopt == 4){   /* �u���s �έ�W�b��(option=4) */
      sprintf_s( sTmp,sizeof sTmp, " AND option = '4' " );
      sprintf_s( sTmp4,sizeof sTmp4, " AND option = '4' " );
  }else if( intopt == 49){  /* �u���s �έ�W�b��(�toption=9) */
      sprintf_s( sTmp,sizeof sTmp, " AND option in ('4','9') AND iofficer like 'A09%%' AND day(dply_begin) <16");
      sprintf_s( sTmp4,sizeof sTmp4," AND option in ('4','9') AND ibig_office like 'A09%%' AND day(dply_begin) <16");
  }else if( intopt == 9){   /* �u���s option=9�����)*/
      sprintf_s( sTmp,sizeof sTmp, " AND option = '9' ");
      sprintf_s( sTmp4,sizeof sTmp4, " AND option = '9' ");
  }else if( intopt == 55){   /* �u���s option=55�����)*/
      sprintf_s( sTmp,sizeof sTmp, " AND option = '55' ");
      sprintf_s( sTmp4,sizeof sTmp4, " AND option = '55' ");
  }else if( intopt == 99 || intopt == 98){  /* �u���s �b ca_tmp_no�������)*/
      sprintf_s( sTmp,sizeof sTmp, " AND ipolicy in (select ipolicy from newa00:ca_tmp_no)");
      sprintf_s( sTmp4,sizeof sTmp4, " AND ipolicy in (select ipolicy from newa00:ca_tmp_no)");
  }else if( intopt == 8){   /* �u���s �έ�U�b��(���toption=9) */
      sprintf_s( sTmp,sizeof sTmp, " AND option in = '1' AND iofficer like 'A09%%' AND day(dply_begin) >15");
      sprintf_s( sTmp4,sizeof sTmp4," AND option in = '1' AND ibig_office like 'A09%%' AND day(dply_begin) >15");
  }else if( intopt == 89){  /* �u���s �έ�U�b��(�toption=9) */
      sprintf_s( sTmp,sizeof sTmp, " AND option in ('1','9') AND iofficer like 'A09%%' AND day(dply_begin) >15");
      sprintf_s( sTmp4,sizeof sTmp4," AND option in ('1','9') AND ibig_office like 'A09%%' AND day(dply_begin) >15");
  }else if( intopt == 0 || intopt == -1){
      sprintf_s( sTmp,sizeof sTmp, " AND %s", p32Where);  /*  Ū���~�bwhere�ܼ�(p32Where)�����󲣻s�ɮ� */
      sprintf_s( sTmp4,sizeof sTmp4," AND %s", p32Where);
  }else{
      /* [del intopt == 25]102.03 �w��5/1�ᤧ 5,6��|���X�椧��O���ơA�ɻ����O�X���ơA�H�Q���H�o��O�� 102.07���i�R��*/
      if( intopt == 25){
	 sprintf_s( sTmp,sizeof sTmp, " AND ipolicy in (select ipolicy from newa00:ca_tmp_no)");
	 sprintf_s( sTmp4,sizeof sTmp4, " AND ipolicy in (select ipolicy from newa00:ca_tmp_no)");
      }else{
         strcpy( sTmp, " ");
         strcpy( sTmp4, " ");
      }
  }

  fLater = 0;

  /* option==>1:�@���  2:�O�N�� */
  for(s=1;s<=atoi(option);s++)
  {
     if (option[0] == '2') /* �O�N��  */
     {
       if (s==1)
       {
          strcpy(sWhereA," ORDER BY 1,64,119,61,3");
       }
       else
       {
       	  /* ���� p32_%d_5p_iquota  */
       	  continue;

          strcpy(sWhereA," ORDER BY 74,59,62,1 ");
       }

        sprintf_s(stmt_302,sizeof stmt_302,
           "  SELECT a.iofficer,Year(a.dply_begin),%s  \
                FROM policy_302 a ,officer b, cm_route c  \
               WHERE a.iofficer = b.iofficer      \
                 AND a.iroute = c.iroute \
                 AND a.dply_begin between '%s' and '%s' \
                 AND b.imgr = '1'        \
                 %s %s ", all_col_302, sdate1, sdate2, sTmp, sWhereA);
     }
     else
     {  /* �@���  */

        strcpy(sTmp4,sTmp); /* �]��sTmp����|�~��ϥΨ�, ���� LATER_PART �|�����D*/
LATER_PART:

        if (fLater == 1)
        {
       	     strcpy(sWhereA," AND a.ipolicy in (select ipolicy from tmp_later) \
       	                      ORDER BY a.iroute, a.fcard_class,a.dply_begin");
        }
        else
        {
       	     strcpy(sWhereA," ORDER BY a.iquota, a.ileader, a.iofficer, a.dply_begin ");
        }

        if (print_chk[15]=='2')
        {
        	sprintf_s(stmt_302,sizeof stmt_302,
        	   "   SELECT a.ibig_office,Year(a.dply_begin), %s  \
        	         FROM policy_302 a ,officer b, cm_route c   \
        	        WHERE a.iofficer = b.iofficer    \
        	          AND a.iroute = c.iroute \
        	          AND a.dply_begin between '%s' and '%s' \
        	          AND a.ipolicy matches '*ES*'           \
        	          %s %s ", all_col_302, sdate1, sdate2, sTmp4, sWhereA);
        }
        else
        {
        	sprintf_s(stmt_302,sizeof stmt_302,
        	    "   SELECT a.ibig_office,Year(a.dply_begin), %s  \
        	          FROM policy_302 a ,officer b, cm_route c   \
        	         WHERE a.iofficer = b.iofficer    \
        	           AND a.iroute = c.iroute \
        	           AND a.dply_begin between '%s' and '%s' \
        	           AND b.imgr <> '1'   \
        	           %s %s ", all_col_302, sdate1, sdate2, sTmp4, sWhereA);
        }

     }


printf(" ------- strlen stmt_302 = [%d]\n " , strlen(stmt_302));
printf("Trace -- stmt_302 = [%s] \n",  stmt_302);
     #ifdef PRINTF_FLAG
     printf(" ------- strlen stmt_302 = [%d]\n " , strlen(stmt_302));
     printf("Trace -- stmt_302 = [%s] \n",  stmt_302);
     #endif

     $PREPARE  pre_stmt FROM $stmt_302;
     $DECLARE  CA302_ply_3021 CURSOR FOR pre_stmt;

     $OPEN  CA302_ply_3021;
     while (1)
     {
  	strcpy( remark1, " ");
  	strcpy( remark2, " ");
  	strcpy( remark3, " ");
  	strcpy( remark4, " ");
  	strcpy( remark5, " ");
  	strcpy( remark6, " ");
  	strcpy( remark7, " ");
  	strcpy( nproject, " ");
  	strcpy( iemail, " ");
        strcpy( remark_tmp1, " ");
        strcpy( remark_tmp2, " ");
        strcpy( remark_tmp4, " ");

        strcpy(iquery_num," ");            /* �j�� */
        strcpy(iquery_num_damage," ");     /* ���� */
        strcpy(iquery_num_unknown," ");     /* �������l */
        strcpy(iquery_num_lia," ");        /* ���d */
        strcpy(iquery_num_damage_sug ," ");     /* ����(��ĳ) */
        strcpy(iquery_num_unknown_sug ," ");     /* �������l(��ĳ) */
        strcpy(iintroducer," ");
        strcpy(icard_main," ");
        qdrunk_driving = 0;
        qviolate = 0;
        strcpy(car_type_pre," "); /* �s�W����(4A,8A,9A,9B,2A,2B,2C)�^�k�ᨮ�� modify by sylvia 104.02.16(1040202006_C3) */
        strcpy(ply_route_main, " "); /* �O��D�q���N�� */

        $FETCH CA302_ply_3021
          INTO $tmp_data, $iYear, $ipolicy,$ipolicy_1,$icard,$fcard_class,
               $irelative_ply,$dply_bgn_comp,$dply_end_comp,$comp_prem,
               $last_policy_2,$last_policy_3,$qply_period,
               $dply_begin,$dply_end,
               $nassured,$ilicense,$ibirth,$fsex,$fmarriage,$nuser,
               $nbenef,$aassured,$itel,$iply_area,$iissue_ym,$ipro_year,
               $ibrand,$nbrand_abbr,$icar_type,$ichange_note,$ncar_type,
               $qcylinder,$iengine,$ibody,$itag,$mcar_price,$pdmg_align,
               $pbrg_align,$plia_align,$qpt,$fpt,$idmg_rate,$dmg_factor,
               $ibrg_rate,$brg_factor,
               $psex_age,$psex_age_damage,$lia_ac_cnt1,$lia_ac_cnt2,$lia_ac_cnt3,
               $lia_ac_cntc,$dmg_ac_cnt1,$dmg_ac_cnt2,$dmg_ac_cnt3,
               $plia_acc,$pdmg_acc,$plia_acc_c,$fcar_class,$dedr_begin,
               $iofficer,$nname,$ibig_office,$ibig_sales,$ibig_policy,
               $ibig_comp,$ibig_branch,$mbusiness,$fcomp_class,
               $fcomp_class_last,$ileader,$aassured_zip,$irel_card,
               $iquery_num_lia,$iquery_num_damage,$iquota,$nchi_full,
               $fnation,$v_prem,$v_ori_prem,$tot_prem,
               $ch_ins_grp1,$ch_ins_grp2,$ch_ins_grp3,$pre_dply1_bgn,
               $pre_dply1_end,$pre_prem1,$pre_prem2,$pre_dply2_bgn,
               $pre_dply2_end,$pre_sex_age,$pre_sex_age_damage,$pre_lia_acc,$pre_dmg_acc,$note1,
               $linnum,$sNbrand,$remark1,$remark2,$remark6,$remark7,$LHsIbig_Nname,$iMdiscount,$iTot_mpay,
               $pre_ch_ins_grp1,$pre_ch_ins_grp2,$pre_ch_ins_grp3,$icorps,$ncorps,$pdiscount,
               $fcomp_24,$remark3,$fassured,$tphone_con,$imovephone,$iemail,$remark4,
               $remark5,$nproject,$lia_class, $sNequipment, $iTmp,$s_dbirth,$s_dissue,$iroute,$bzfrom,$irate_type,$iroute_comm,$iroute_prop,$iupdate,$dupdate,
               $qdmg_acc_sum_renew,$qlia_acc_sum_renew,$iapplicant,$napplicant,$apayment_zip,$apayment,
               $fapplicant,$fsex_appl,$dbirth_appl,$itel_appl,$ndeputy_appl,$nrelation_appl,$ndeputy_assured,$abn_type,
               $iestimate_ori,$iestimate_sug,$itransno_ori,$itransno_sug,$fuw_status_ori,$fuw_status_sug,$frenew_type,$freason_reject,$mcomp_prem_sug,$isecond_hand,
               $pdmg_acc_sug, $qdmg_acc_sum_renew_sug, $iquery_num_damage_sug,$iintroducer,$icard_main,$qdrunk_driving,$iRemark_yn,
               $ply_route_main, $sIofficer, $mequipment,
               $iassured_cntry,$iapplicant_cntry, $iroute_accept, $dbirth1, $iupcomp1,
               $punknown_acc, $pre_unknown_acc, $qunknown_acc_sum_renew, $punknown_acc_sug, $qunknown_acc_sum_renew_sug,
               $iquery_num_unknown, $iquery_num_unknown_sug, $aemail_eply, $psex_age_c, $iquery_num,
               $dc_change, $foccup, $noccup, $applicant_foccup, $applicant_noccup,
               $tmobile_appl, $aemail_appl, $tmobile_eply, $ireg_no, $icomm_obj,
               $iroute_main, $feterms, $qviolate,
               $dinstall, $isequence, $ainstall_zip, $ainstall;


         if (SQLCODE == SQLNOTFOUND)
         {
            if (option[0] == '1'&& fLater==0)
            {
                /*  �@��� 2p ,��SUM����*/
          	fLater = 1;
                $CLOSE CA302_ply_3021;
                $FREE CA302_ply_3021;
          	goto LATER_PART;
            }
            else
            {
                break;
            }

         }
         IsPlyB = 'N';

         /* �p�{���M�ݫO�� (131,132�I�ؤ��L�d���I�ż�)  add by sylvia 103.10.15 */
         if((strcmp(icar_type, "07") == 0) || (strcmp(icar_type,"15") == 0))
         {
            cnt_131=0;
            $select count(ipolicy) into $cnt_131
               from ply_ins_type_302
              where ipolicy = $ipolicy
                and iins_type in ('131','132','331','332');
            if (cnt_131 > 0)
               strcpy(lia_class," ");
         }

         /* ����N�I���O�v�N�� add by sylvia 103.04.30 (1030307001_C1)----------------- */
         strcpy(ipolicy, trim(ipolicy));
         $select first 1 drate_ym  into $vDrate_ym
            from ply_ins_type_302
           where ipolicy = $ipolicy and iins_type <> '21';

         if (SQLCODE == SQLNOTFOUND) strcpy(vDrate_ym, " ");
         /* -------------------------------------------------------------------------- */




         /* �]���I�sTRANS_CAR_TYPE()�n�[�J�O�v�N��, �ҥH����o�� */
         strcpy(car_type_pre,TRANS_CAR_TYPE(icar_type,vDrate_ym));    /* �s�W���ئ^�k���� */
         #ifdef PRINTF_FLAG
         printf("ipolicy == [%s] irelative_ply[%s]icar_type=[%s]car_type_pre=[%s]\n",ipolicy,irelative_ply,icar_type,car_type_pre);
         #endif

         /* �s�W�C�L�~�ȭ��m�W add by 061476 108.08.15 (1080725002_SC1) */
         strcpy(nsales," ");
         if ( strlen(trim(ireg_no)) >0 )
         {
         	if ((strcmp(bzfrom,"10") == 0)&&(strncmp(iroute,"KB",2) == 0))
         	{
         		$SELECT nname INTO $nsales
         		FROM v_commission_obj
         		WHERE icomm_obj = $icomm_obj;

         		if (SQLCODE == SQLNOTFOUND) strcpy(nsales," ");
         	}
         	else if ((strcmp(bzfrom,"10") == 0)||(strcmp(bzfrom,"40") == 0))
         	{
         		$SELECT nname INTO $nsales
         		FROM v_commission_obj
         		WHERE icomm_obj = $ileader;

         		if (SQLCODE == SQLNOTFOUND) strcpy(nsales," ");
         	}
         	else if ((strcmp(bzfrom,"20") == 0)&&(strncmp(iroute,"CA",2) == 0))
         	{
         		$SELECT nname INTO $nsales
         		FROM ca_big_office
         		WHERE fclass = '2' and ibig_comp = $ibig_sales;

         		if (SQLCODE == SQLNOTFOUND) strcpy(nsales," ");
         	}
         	else if ((strcmp(bzfrom,"20") == 0)||(strcmp(bzfrom,"30") == 0))
         	{
         		$SELECT nsales INTO $nsales
         		FROM cm_route_sales
         		WHERE isales = $ibig_sales and iroute = $iroute_main;

         		if (SQLCODE == SQLNOTFOUND) strcpy(nsales," ");
         	}
         	else
         	    strcpy(nsales," ");
         }


         /* -------------------------------------------------------------------------------------------------- */
         strcpy(nbrand,sLastChinese(sNbrand,20));

         strcpy( iofficer, trim(iofficer));
         strcpy( iroute, trim(iroute));
         strcpy( iquota, trim(iquota));
         count_linnum = 'Y';

         /* EASYCAR ��� SUM ��z add by sylvia 105.08.06 (1050804003_C1) */
         if (fLater == 0){
         	 if ((ISSUM(iroute)) || (ISEASYCAR(iroute))){
         	     $EXECUTE pre_later USING $ipolicy;
         	     continue;
         	 }
	     }

         if (intopt == -1){
         	  /* �ϥθ���^���\��, ��continue��L����  */
         }else{
	         if (option[0] == '1'){ /*  �@��� 2p */

		         /* 980727, �����M�׷~�ȥu�Lbarcode */
	        	 /* 990604,�[�������G
	        	    1.�u�x�_�M�סv(1�~��)���s���A�]���¨�(if��O)�A�G�ҭn�H�obarcode�A���H�q���ѡB�q����
	        	    2. �D�u�x�_�M�סv(2�~��),�p�G�O�s���A�h�N�����Ĥ@�~�A���ɤ����Hbarcode�γq���ѡB�q����
	        	                             �p�G�O�¨��A�h�N�����ĤG�~�H��A���ɭn�H�obarcode�A���H�q���ѡB�q����
	        	    ==> �ҥH�A�u�n�g��N���O�b�e�����M�׷~�ȡf�̪�list���A�h���H�q���ѡB�q����
	        	 */


		          /* 101.01.18,�����}�M ���L��O�q���ѡB�u�L�q����*/
		          /* 107.01.05 �����}�M ���s���s�n�O�� mark by 061476 (1061229002_C1)*/
		          /*if (ISCHAILEASE(iroute)) continue ;*/

		          /* 101.06.08,���Ȱ�گ��� ���L��O�q���ѡB�u�L�q����*/
		          /* 107.01.05 ���Ȱ�گ��� ���s���s�n�O�� mark by 061476 (1061229002_C1)*/
		          /*if (ISFEI(iroute)) continue ;*/

	         }else{
	         	 /* 102.07.10�A���M�����X�@�A���M�S���榡�אּ��W���s5p�ɡAtmnewa 5p�ɮפ������t���M�� */
	         	 /* 100.12.26, ���W�^�k�ѷs�w�L�s��O��A�������t�~���s�q�l�� */
	         	 /* 100.03.03, " AND a.ibig_comp not in ('L','G') " ��g�b�{�����z�ﱼ */
	         	 /*
	         	 if (print_chk[0]=='1'){
	         	 	  if (iofficer[0] =='L'){
	         	 	  	  continue; 	* 5p:tmnewa => ���t���M�B���W *
	         	 	  }
	             }*/
	         }
         }
         strcpy(ilicense,trim(ilicense));
         fBothIns = 0;

         strcpy(dbirth2," ");
         strcpy(iupcomp2," ");
         strcpy(iroute2," ");
         strcpy(freason_reject2," ");
         strcpy(pre_comp_feply,"0"); /*�e��j���I�O�_���q�l�O�� �w�]0:�ȥ� add by 071004 (1101130006_SC1_���s�ɱj���I�q�l���ҹq�����A�W�[�P�_�ư����d�q�ܬO�ȥ�)*/

         if (fcard_class[0] == '1')
         {
              t_count = 0;

              if (strlen(trim(irelative_ply))>0){
                  /* ���M�P�@ID,���ͤ餣�P�Τ��P�O�o�q��,������j (1050718003_C1, 1050714004_C1) */
                  /* �t�X�O�o�q���X�s,���q���N����H��1�X���  (1060111005_C3) */
                  /* �ק��ˮ֡G�O�o�q���N���������@�P�A�_�h������j/��� (1090430005_SC1) */
                  /* �W�[�ˮ֡G�޲z�H�ݤ@�P  (1090616006_SC1) */
                  strncpy(bzfrom1,bzfrom,1);
                  bzfrom1[1] = '\0';
                  $SELECT  first 1 ilicense, freason_reject, nvl(dbirth,' '), iroute,
                           (select iupcomp from officer where iofficer = a.iofficer)
                     INTO  $ilicense_v, $freason_reject2, $dbirth2, $iroute2, $iupcomp2
                     FROM  policy_302 a
                    WHERE  ipolicy           = $irelative_ply
                      AND  YEAR(dply_begin)  = $iplyyear
                      AND  MONTH(dply_begin) = $iplymonth
                      AND  fcard_class       = '2'
                      AND  bzfrom = $bzfrom
                      AND  ileader = $ileader
                      AND  not exists (select iofficer_ori from tp_officer where iofficer_ori = a.iofficer)
                      AND  not (iofficer[1] = 'L' and iofficer[7] = 'B');

                  if (SQLCODE != SQLNOTFOUND) {
                  	   t_count = 1 ;
                  }
              }

	      strcpy(ilicense_v,trim(ilicense_v));
	      strcpy(iroute,trim(iroute));
	      strcpy(iroute2,trim(iroute2));
	      if (strcmp(ilicense, ilicense_v)!=0){
	           t_count = 0;    /* �j��B���N���P�O��,������j */
	      }else if (strcmp(dbirth1, dbirth2) != 0) {
	           t_count = 0;    /* ���M�P�@ID,���ͤ餣�P,������j */
              }else if (strcmp(iupcomp1, iupcomp2) != 0) {
	           t_count = 0;    /* �g�줣�P�Ұ�, ������j bug�ץ� */
              }else if ((freason_reject2[0]=='P')||(freason_reject2[0]=='7')||(freason_reject2[0]=='Y')||(freason_reject2[0]=='9')||
                        (freason_reject2[0]=='Z')||(freason_reject2[0]=='B')){
	           t_count = 0;    /* ���N�I���ګO�B���`��, ������j (1131202009_C01) */
	      }else if (((strncmp(iroute,"KA",2) == 0)||(strncmp(iroute2,"KA",2) == 0))&&(strcmp(iroute, iroute2) != 0)){
	      	   t_count = 0;    /* KA*���P�q���N��,������j (1100719003_SC1)*/
	      }

	      /* �w��CAR102�����OP.7.9�̡A�j���I�@�ߤ����s��O�n�O�� add by 061476 107.01.19 (1070111012_C1) */
	      /* car102��10����Ӳ�9���A�����s��O�n�O�� add by 061476 107.11.27 (1071029004_SC3) */
	      if ((freason_reject[0]=='P')||(freason_reject[0]=='7')||(freason_reject[0]=='9')||(freason_reject[0]=='B')){
	           continue;
	      }

              if (t_count == 1)
              {
                   continue;

              }else{

              	  fBothIns = 1 ;  /* ��j */
              	  psex_age_v = 0; /* �ʧO�~�֫Y��(���N)��0 (1110322012_SC2) */
	          /* psex_age_c = psex_age; */ /* �w���j��M�����add by sylvia 106.03.28 */

	          /* strcpy(iquery_num,iquery_num_lia); *//* �j�� *//* �w���j��M�����add by sylvia 106.03.28 */
	          strcpy(iquery_num_damage," ");     /* ���� */
	          strcpy(iquery_num_unknown," ");     /* ���� */

	          $select count(iins_type) into $tmp_cnt
	             from ply_ins_type_302
	            where ipolicy = $ipolicy
	              and iins_type in ('149','249');

	          if  (tmp_cnt == 0) {
	              strcpy(iquery_num_lia," ");        /* ���d */ /*����ĳ149�~�M��,����ĳ149���M�� add by sylvia 106.03.28 */
	          }
	          strcpy(iquery_num_damage_sug," ");     /* ���� */
	          strcpy(iquery_num_unknown_sug," ");     /* ���� */

	          /* ���o�h�~�j���I �q�l�O����O add by 071004 (1101130006_SC1_���s�ɱj���I�q�l���ҹq�����A�W�[�P�_�ư����d�q�ܬO�ȥ�)*/
	          strcpy(sFullDB, get_car_full_dbname(ipolicy));
		  sprintf_s(stmt,sizeof stmt,"SELECT feply FROM %s:ply_relation WHERE ipolicy = '%s'",sFullDB, ipolicy );
		  $PREPARE get_feply FROM $stmt;
		  $EXECUTE get_feply INTO $pre_comp_feply;

		  /*���o���j�H�W�[�O�B�s�r�[�O(1110608012_SC3)*/
                  strcpy(sviolate_prem,"0");
                  strcpy(sdrunk_prem,"0");

		  $select mviolate_prem,mdrunk_prem
                     into $sviolate_prem,$sdrunk_prem
                     from ply_ins_type_302
                    where ipolicy = $ipolicy and iins_type = '21';

                  if (SQLCODE == SQLNOTFOUND )
                  {
                      strcpy(sviolate_prem,"0");
                      strcpy(sdrunk_prem,"0");
                  }




                  if(strcmp(pre_comp_feply,"0") == 0)
                  {
                      /*��j�e��q�l�O����O�Y�O�ȥ��A�h�M���q�l�O��H�eEmail�B�H�e��������*/
                      strcpy(aemail_eply," ");
                      strcpy(tmobile_eply," ");
                  }


              }
         }
         else
         {
              /* "�j+��"��"����N"���ګO��[���O7]�B [���OP(=���O1�B�P�@�O��X�I�T��)] �β��`��[���OY]�̡A�����s��O�q���ѡB�u���s�j���I��O�q����*/
      	      /* �֫O���A40 (freason_reject='Z') ���P�ګO�Ȥ�, ��өګO�Ȥ��z (1040624002_C1) */
      	      /* car102��10����Ӳ�9���A�����s��O�n�O�� (1071029004_SC3) */
              if ((freason_reject[0]=='P')||(freason_reject[0]=='7')||(freason_reject[0]=='Y')||(freason_reject[0]=='9')||
                  (freason_reject[0]=='Z')||(freason_reject[0]=='B')){
              	  continue;
              }
              /* �W�[�˥ߧP�_  (1081018008_SC1) */
              if( (iofficer[0]=='W') || (iofficer[0] == 'H' && (iofficer[1]!='0' && iofficer[1]!='1' && iofficer[1]!='2')) ||
                  ((iofficer[0]=='L')&&(iofficer[6]=='B'))  ){
              	 IsPlyB = 'Y';
              }
              else if (iofficer[0]=='N')
              {
                  /* �O�_���M���B�� (N�g��N��) --------------------------------------------------------*/
      	          cnt_prmt = 0;
      	          /* $select count(*) into $cnt_prmt from ca_promote_officer where iofficer_ori = $iofficer; */

      	          $select count(*) into $cnt_prmt from ca_promote_officer where iofficer_ori = $iofficer;
      	          if (cnt_prmt > 0) IsPlyB = 'Y';
      	          /*---------------------------------------------------------------------------------------*/
              }

              fBothIns = 2 ; /* ����N */

              /* 1080819 ����barcode�㨮���ѱM��,����N(�L���p��)��ĳ�j���I add by sylvia (1030806002_C1) */
              if (ISMOT(icar_type) && strcmp(icar_type,"35")!=0)
              {
	              $SELECT count(*) INTO $t_count FROM tmp_barcode_officer
	                WHERE icode_no='MOTOR20' AND (iofficer = $iofficer Or iofficer = $iroute);

	              if ((t_count>0) && (strlen(trim(irelative_ply))==0) && (mcomp_prem_sug > 0) && (comp_prem == 0))
      	                  fBothIns = 4 ; /* �����㨮���ѥB����N,�|��ĳ�j���I */
	      }

	      t_count = 0;
              comp_prem = 0;
              /*psex_age_c= 0; mark by 061476 (1110322012_SC2)*/
              strcpy(pre_prem1," ");
              strcpy(plia_acc_c," ");
              strcpy(iquery_num," ");
              qdrunk_driving = 0;
              qviolate = 0;
              strcpy(sviolate_prem,"0");
              strcpy(sdrunk_prem,"0");

	      /* �H�U���,�Y�ŦX[�����ĳ�j��(fBothIns == 4)]�ɶ��O�d,
	         �Y�º鬰���(fBothIns == 2) �� �j+��(fBothIns == 3�A�U���@�I�|�P�_) �h���M�� modify by sylvia 103.08.20 */
              if (fBothIns == 2)
              {
                 strcpy(fcomp_class," ");
                 mcomp_prem_sug = 0 ;
                 strcpy(dply_bgn_comp," ");
                 strcpy(dply_end_comp," ");
              }
	      /*------------------------------------------------------------ */
              strcpy(dbirth2," ");
              strcpy(iupcomp2," ");
              strcpy(iroute2," ");
              if (IsPlyB != 'Y'){ /* B�椣�������p�j���I*/

	              if (strlen(trim(irelative_ply))>0)
	              {
	                  /* ���o�j���I�O��ID*/
	                  /* �t�X�O�o�q���X�s,���q���N����H��1�X��� (1060111005_C3) */
	                  /* �ק��ˮ֡G�O�o�q���N���������@�P�A�_�h������j/���  (1090430005_SC1) */
	                  /* �W�[�ˮ֡G�޲z�H�ݤ@�P (1090616006_SC1) */
	                  strncpy(bzfrom1, bzfrom, 1);
	                  bzfrom1[1] = '\0';

	                  $SELECT  first 1 ilicense, nvl(dbirth,' '), iroute,
	                           (select iupcomp from officer where iofficer = a.iofficer)
	                     INTO  $ilicense_v, $dbirth2, $iroute2, $iupcomp2
	                     FROM  policy_302 a
	                    WHERE  ipolicy           = $irelative_ply
	                      AND  YEAR(dply_begin)  = $iplyyear
	                      AND  MONTH(dply_begin) = $iplymonth
	                      AND  bzfrom = $bzfrom
	                      AND  ileader = $ileader
	                      AND  fcard_class       = '1';
	                  if (SQLCODE != SQLNOTFOUND)
	                  {
	                      t_count = 1 ;
	                  }
	              }

	              strcpy(ilicense_v,trim(ilicense_v));
	              strcpy(iroute,trim(iroute));
	              strcpy(iroute2,trim(iroute2));
	              if (strcmp(ilicense, ilicense_v)!=0){
		           t_count = 0 ;       /* �j��B���N���P�O��,������� */
		      }else if (strcmp(dbirth1, dbirth2) != 0){
		           t_count = 0 ;       /* ���M�P�@ID,���ͤ餣�P,������� */
		      }else if (strcmp(iupcomp1, iupcomp2) != 0){
		           t_count = 0 ;       /* �g�줣�P�Ұ�,������� add by sylvia 105.09.14 bug�ץ�*/
		      }else if (((strncmp(iroute,"KA",2) == 0)||(strncmp(iroute2,"KA",2) == 0))&&(strcmp(iroute, iroute2) != 0)){
		           t_count = 0;        /* KA*���P�q���N��,������� add by 061476 (1100719003_SC1) */
		      }

	              /*psex_age_c= 0; mark by 061476 (1110322012_SC2) */
	              if (t_count==1)
	              {
	              	  fBothIns = 3 ; /* ���N+�j�� */

	              	  /* ���o�j���I������� */
	                  psex_age_v = psex_age;
	                  $EXECUTE comdtl
	                      INTO $dply_bgn_comp,$dply_end_comp,$comp_prem,$lia_ac_cntc,
	                           $plia_acc_c,$fcomp_class,$fcomp_class_last,$irel_card,
	                           $iquery_num,$pre_dply1_bgn,$pre_dply1_end,
	                           $pre_prem1,$psex_age_c,$remark_tmp1, $remark_tmp2,$remark_tmp4, $icar_type_comp,
	                           $ichange_note,$s_dbirth,$mcomp_prem_sug,$qdrunk_driving,$qviolate
	                     USING $irelative_ply,$iplyyear,$iplymonth;

                          /*���o���j�H�W�[�O�B�s�r�[�O(1110608012_SC3)*/
                          $select mviolate_prem,mdrunk_prem
                             into $sviolate_prem,$sdrunk_prem
                             from ply_ins_type_302
                            where ipolicy = $irelative_ply and iins_type = '21';

                          if (SQLCODE == SQLNOTFOUND )
                          {
                              strcpy(sviolate_prem,"0");
                              strcpy(sdrunk_prem,"0");
                          }


			  /* 102.12.25:�ثe�j���I�|���T�����A�u��"����O�q���Ѥw�ɦ��j���I 100���u�f�A���N�I�ɦ�������O�u�f�C"
	                               ���T���b�j���I�J�p�ɡA�O��b remark4  */
			  /* �N�j���㪺�O��q�T��T���X�֦ܥ��N�I*/
	                  /* remark_tmp4: in �j���I   remark4�Gin ���N�I */
	                  if( strlen(trim(remark_tmp4)) > 0 )
	                  {
                      	      strcpy( remark4, remark_tmp4);
	                  }
	              }/* �j+��(fBothIns = 3)  end */
	              else
	              {
	              	/* ����N�ʧO�~�֫Y�� (1110322012_SC2) */
	              	psex_age_c = 0;
	              	psex_age_v = psex_age;
	              }
              }
         }

         /************** ������  [�z��]�w��D���ӥ�A���sbarcode�̡A�����s��O�q����(�����ҥ~) ������ ********************************/
         fBarcode_mark = 'N';

         if (option[0] == '1'){

              if (intopt == -1){
 	              /* �ϥθ���^���\��, ��continue��L����  */
 	      }else{

                  /* ��g���Q�� frenew_type �P�_ */
                  if ((frenew_type[0]=='2')||(frenew_type[0]=='3')){ /* �Hbarcode *//* �B���O��e�~�C�L */

	                 /* 970725, �O�_�ݭn�L�sbarcode�~,�A�L��O�q����,��car147�]�w�M�w */
	                 fBarcode_print[0] = ' '; fBarcode_print[1] = '\0';
	                 if (strcmp(icar_type,"51") == 0)
	                 {

	                    /* $EXECUTE preBarcode_off_51 INTO $icode_no,$fBarcode_print using $iofficer,$iroute; */
	                    continue;
	                 }


	                 $EXECUTE preBarcode_off INTO $icode_no,$fBarcode_print using $iofficer,$iroute;

	                 if (SQLCODE != SQLNOTFOUND){

	                     if (fBarcode_print[0]=='Y') {
	                     	 /*car147�Ȧ�q��barcode��B�]�w�n�P�ɦL��O�q���ѡA���q���ѭn���O"����w�H�W��ú�O��"�r�� */
	                     	 fBarcode_mark = 'Y';
	                     }else{
	                     	 continue; /*car147�Ȧ�q��barcode��B���]�w�n�P�ɦL��O�q���� */
	                     }

                         }else{ /* �T������j barcode ���n�P�ɦL�q���Ѫ� */

                             if (frenew_type[0]=='2')
                             {
	                         fBarcode_mark = 'Y';  /* �T������j barcode �@�߭n�P�ɱH�q���Ѫ� */
	                     }
                         }

                  }

              }
              /************* �� ���϶��ק�,�j�������γ��n�P�ɭק� ca3024q01s.ec �P���޿�  �� *************/
         }

         /************** ������  �w��D���ӥ�A���sbarcode�̡A�����s��O�q����(�����ҥ~) ������ ********************************/

         /* �g���N��(ibroker) */
         ibroker[0]='\0';
         strcpy(nbroker , "            ");

         /*9912, �d���T�� X31:��ܴ��ܰT�� */
         if (strncmp(lia_ac_cnt3,"31",2)==0){
         	   strcpy(sDmg_lia_remark1,"���N�I�d�L���T�Y��");
         	   strcpy(sDmg_lia_remark2,"�A�Э��s�T�{");
         }else{
         	   strcpy(sDmg_lia_remark1," ");
         	   strcpy(sDmg_lia_remark2," ");
         }

         /* 9912,���C�L��� �� */
         strcpy(lia_ac_cnt1," ");   strcpy(lia_ac_cnt2," ");    strcpy(lia_ac_cnt3," ");
         strcpy(lia_ac_cntc," ");   strcpy(dmg_ac_cnt1," ");    strcpy(dmg_ac_cnt2," ");   strcpy(dmg_ac_cnt3," ");
         /* ���C�L��� �� */

         if (fcard_class[0] == '2'){
             /* tot_prem   = comp_prem + v_prem ;        074   �`�O�O(A+C) */
             tot_prem   = mcomp_prem_sug + v_prem ;     /*  074   ��ĳ��O�զX�`�O�O(A+C) */
             iTot_mpay += comp_prem;                    /*  iTot_mpay:�ꦬ���B ?? */
             tot_ori_prem = comp_prem + v_ori_prem  ;   /*  114   ���O�զX�`�O�I�O(B+C)    */
         }else{
         	 /* ��j �� ��j����ĳ���N(47�B50)*/
             tot_ori_prem = comp_prem + v_ori_prem;     /*  114   ���O�զX�`�O�I�O(B+C)    */
             tot_prem   = mcomp_prem_sug + v_prem ;     /*  074   ��ĳ��O�զX�`�O�O(A+C)   ��j����ĳ���N(47�B50)�ɡA���N�I�O�O�|��bv_prem�Btot_prem */
             iTot_mpay += comp_prem;   /* iTot_mpay:�ꦬ���B ?? */
         }

         #ifdef PRINTF_FLAG
         printf("ipolicy[%s] v_ori_prem[%d] mcomp_prem_sug[%d]\n", ipolicy, tot_ori_prem, mcomp_prem_sug );
         printf("ipolicy[%s] tot_ori_prem[%d]\n", ipolicy, tot_ori_prem);
         #endif
         /* 102.09.11 ���j���ӦW�� */
         strcpy(isecond_hand,trim(isecond_hand));
         strcpy(nsecond_hand," ");
         if ( (isecond_hand[0] != '\0') && (isecond_hand[0] != ' ') ){
             $EXECUTE pre_second_hand INTO $nsecond_hand USING "B2",$isecond_hand;
         }

         /*--------------------- 102.03 �A�[�J���O�X��������---------------------*/

    	 strcpy(s_paydate ," ");  strcpy(c_paydate ," ");
    	 strcpy(Bcode1    ," ");  strcpy(Bcode2    ," ");  strcpy(Bcode3    ," ");
    	 strcpy(ori_Bcode1," ");  strcpy(ori_Bcode2," ");  strcpy(ori_Bcode3," ");
    	 strcpy(tmYY ," ");       strcpy(tmMM ," ");       strcpy(tmDD ," ");
    	 strcpy(itransno_ori_atm," ");  strcpy(itransno_ori_700," ");  strcpy(itransno_ori_007," ");
    	 strcpy(itransno_ori_008," ");  strcpy(itransno_ori_009," ");  strcpy(itransno_ori_013," ");
    	 strcpy(itransno_ori_MKT," ");  strcpy(itransno_ori_post," ");
    	 strcpy(itransno_sug_atm," ");  strcpy(itransno_sug_700," ");  strcpy(itransno_sug_007," ");
    	 strcpy(itransno_sug_008," ");  strcpy(itransno_sug_009," ");  strcpy(itransno_sug_013," ");
    	 strcpy(itransno_sug_MKT," ");  strcpy(itransno_sug_post," ");

    	 /* �q�L�t�μf�̡֪A���|���������ú�ڳ�A���F���Юװ��~�A�@�ߤ��Lú�ڳ�(�S���g�Jao_rcv_type)
    	    �G���|���P�b�s���A�Ӥ]�N���ݭn���ͱ��X */
    	 if ((fuw_status_ori==500) && strlen(trim(itransno_ori))>0){

    	 	/* 102.05 �j���I�B�F���ЮסB�ĳq��ú�O����(cm_pre_receive.paydate)�� NULL(null_date)
    	 	   �ҥH�n��ܴC��ú���ɨ��o"ú�O����"  */
    	 	/*$EXECUTE pre_paydate INTO $s_paydate using  $iestimate_ori,$fcard_class;    */
    	 	/* $EXECUTE pre_paydate INTO $s_paydate using  $iYear,$itransno_ori,$iestimate_ori,$fcard_class; */

    	 	$EXECUTE pre_paydate INTO $s_paydate, $iyear_pay using  $itransno_ori,$iestimate_ori,$fcard_class;
    	 	if (SQLCODE==SQLNOTFOUND){
    	 		printf("ao_rcv_type �䤣��ú�ڳ渹[%s],������ iestimate_ori[%s],fcard_class[%s]iyear_pay=[%d]\n ",itransno_ori,iestimate_ori,fcard_class,iyear_pay);
    	 		return -1;
    	 		/* paydate = dply_begin - 1;
			      * �j��+���N�G���N�����p�P����B�P�O��ID���j���I�A���s�T�wú�O���� *
			 	  if (fBothIns==3){
					 * �j����Nú�O�����n�@�P�A�H�̥�����̬��D��@�� *
					 rstrdate( dply_bgn_comp, &lng_dply_begin_comp );
					 lng_paydate_comp = lng_dply_begin_comp -1 ;
					 if (lng_paydate_comp < paydate) {
						 paydate = lng_paydate_comp ;
					 }

			     }
			     strcpy(s_paydate,cm_edate_str(paydate));
			     */
              }
              strcpy(c_paydate,cm_from_infdate_100(s_paydate));
              printf("trace ori c_paydate[%s]\n ",c_paydate);

              /* �����b���אּŪ��ao_rcv_acct add by 061476 (1090220003_SC1) */
              $EXECUTE pre_transno
                 INTO $itransno_ori_atm,$itransno_ori_700,$itransno_ori_007,$itransno_ori_008,
                      $itransno_ori_009,$itransno_ori_013,$itransno_ori_MKT
                using $itransno_ori;

              cm_char_split_3ymd(c_paydate,tmYY,tmMM,tmDD);
              strcpy(itransno_ori_700, trim(itransno_ori_700));
              sprintf_s(itransno_ori_post,sizeof itransno_ori_post,"%s%s%s%s",tmYY,tmMM,tmDD,itransno_ori_700);  /* �l�F����ú�ڳ渹 */

              /* 102.12.03 barcodeú�ڳ椧���X�T�O�O���A�ϥ���O�ɤ��O�O�A�ӧ�q�@�}�l�g�J���C��ú���ɨ��o�O�O�A
                 �Ӽt�ӱN�|��U�P�_�`�O�O�P���X�T�O�O(�C��ú���ɨ��o�O�O)�O�_�@�P */
              code_prem = 0;

              /* $EXECUTE pre_payPrem Into $code_prem using $iYear,$itransno_ori; */
              $EXECUTE pre_payPrem Into $code_prem using $iyear_pay,$itransno_ori;
              ao_crd_bcode(itransno_ori_MKT, c_paydate, &code_prem, ori_Bcode1, ori_Bcode2, ori_Bcode3);
              /*ao_crd_bcode(itransno_ori_013, c_paydate, &code_prem, ori_Bcode1, ori_Bcode2, ori_Bcode3);*/
              /*ao_crd_bcode(itransno_ori, c_paydate, &code_prem, ori_Bcode1, ori_Bcode2, ori_Bcode3);*/
    	 }
    	 if ((fuw_status_sug==500) && strlen(trim(itransno_sug))>0){

    	 	if (strlen(trim(s_paydate))==0){/* ���O�զX�f�֥��q�L */
    	 		/* $EXECUTE pre_paydate INTO $s_paydate using  $iYear,$itransno_sug,$iestimate_sug,$fcard_class; */

    	 		$EXECUTE pre_paydate INTO $s_paydate,$iyear_pay using  $itransno_sug,$iestimate_sug,$fcard_class;
    	 		if (SQLCODE==SQLNOTFOUND){
    	 			printf("ao_rcv_type �䤣��ú�ڳ渹[%s],������ iestimate_sug[%s],fcard_class[%s]iyear_pay[%d]\n ",itransno_sug,iestimate_sug,fcard_class,iyear_pay);
    	 			return -1;
    	 		}
    	 		strcpy(c_paydate,cm_from_infdate_100(s_paydate));
    	 		printf("trace sug c_paydate[%s]\n ",c_paydate);
    	 	}

    	 	/* �����b���אּŪ��ao_rcv_acct add by 061476 (1090220003_SC1) */
    	 	$EXECUTE pre_transno
    	 	    INTO $itransno_sug_atm,$itransno_sug_700,$itransno_sug_007,$itransno_sug_008,
    	 	         $itransno_sug_009,$itransno_sug_013,$itransno_sug_MKT
    	 	   using $itransno_sug;

    	 	cm_char_split_3ymd(c_paydate,tmYY,tmMM,tmDD);
    	 	strcpy(itransno_sug_700, trim(itransno_sug_700));
    	 	sprintf_s(itransno_sug_post,sizeof itransno_sug_post,"%s%s%s%s",tmYY,tmMM,tmDD,itransno_sug_700);  /* �l�F����ú�ڳ渹 */

    	 	/* 102.12.03 barcodeú�ڳ椧���X�T�O�O���A�ϥ���O�ɤ��O�O�A�ӧ�q�@�}�l�g�J���C��ú���ɨ��o�O�O�A
    	 	�Ӽt�ӱN�|��U�P�_�`�O�O�P���X�T�O�O(�C��ú���ɨ��o�O�O)�O�_�@�P */
    	 	code_prem = 0;

    	 	/* $EXECUTE pre_payPrem Into $code_prem using $iYear,$itransno_sug; */
    	 	$EXECUTE pre_payPrem Into $code_prem using $iyear_pay,$itransno_sug;
    	 	ao_crd_bcode(itransno_sug_MKT, c_paydate, &code_prem, Bcode1, Bcode2, Bcode3);
    	 	/*ao_crd_bcode(itransno_sug, c_paydate, &code_prem, Bcode1, Bcode2, Bcode3);*/
    	 	/*ao_crd_bcode(itransno_sug, c_paydate, &tot_prem, Bcode1, Bcode2, Bcode3);*/
    	 }

    	 /* 102.11.29 �q�����u�Hcmn503�]�w���D(�̷s),�줣��ɥΫO�������introducer, �ثe�u�����j�n�L */
    	 /* �]�e�ݮɤw���ˮ֡A�G�קאּ����즳�ȫK���s modify by 061476 107.10.05 (1070927002_SC1) */
    	 /* if (ISYUANT(iroute)){
    	    $EXECUTE prep_route_data INTO $iintroducer using $ipolicy;
    	 }else{
    	 	strcpy(iintroducer," ");
    	 } */
    	 $EXECUTE prep_route_data INTO $iintroducer using $ipolicy;
    	 if(SQLCODE == SQLNOTFOUND) strcpy(iintroducer," ");

         /* 970414 ,�s�W��X���:�g��H�W�� */
         $EXECUTE prep6 INTO $nofficer USING $iofficer;
         if(SQLCODE == SQLNOTFOUND){
         	   strcpy(nofficer, " ");
         }else{
         	   strcpy(nofficer, trim(nofficer));
         }

         flag_Z   = 'N';
         flag_M   = 'N';
         flag_T   = 'N';
         flag_L   = 'N';
         flag_S   = 'N';
         flag_P   = 'N';
         flag_A09 = 'N';
         flag_G   = 'N';      /* ���W */
         flag_Six = 'N';      /* ���M */
         flag_Orix= 'N';      /* �ڤO�h */
         flag_Jihsun = 'N';   /* �鲱���x�q */
         flag_AVIS   = 'N';   /* �w�����T�� */
         flag_CHAILEASE = 'N';/* �����M�} */
         flag_B     = 'N';    /* ���� */
         flag_JB    = 'N';    /* JB */
         flag_102   = 'N';    /* �Dcar102�ګO */
         flag_PA    = 'N';    /* ��L����~ */
         flag_TAXI1 = 'N';    /* 2P �p�{��(07,15) */
         flag_TAXI2 = 'N';    /* 5P �p�{��(07,15) */
         flag_RENT1 = 'N';    /* 2P ���(14,21,08) */
         flag_RENT2 = 'N';    /* 5P ���(14,21,08) */
         flag_RS    = 'Y';    /* �@���_�w�]�����H�e */
         flag_no_print = 'N'; /* �w�]�n���s��O�� */
         flag_NEXTBANK = 'N'; /* �N�ӻȦ�*/
         flag_JBDelete = 'N'; /* JB��O�_�ئbcar354�� (�w�]N:���bcar354)*/
         flag_J    = 'N';     /* ���q*/
         flag_MOMO = 'N';     /* �I��*/
         flag_F    = 'N';     /* F���� */
         flag_ES   = 'N';     /* �R�q�� */
         flag_PRO  = 'N';     /* ��ù�T�� */
         cnt_renew_jb    = 0;
         cnt_provision_f = 0;
         strcpy(ilicense,rtrim(ilicense));
         strcpy(tmp_ilicense, rtrim(ilicense));

    	 /* 102.12.25, 61��Gibig_branch(����) ���ϥ� => ���ӥ�]�tB��^��A��g��e�T�X;�D���ӥ��ť� */
    	 strcpy(ibig_branch," ");
    	 strcpy(ibig_office,trim(ibig_office));
         strcpy(ipolicy_print, ipolicy);

         if (option[0] == '1')
         {
	         /* ��W�T�� */
	         if (ISGOSUN(iofficer,iroute))
	         {
	             flag_Z   = 'Y';
	             count_linnum = 'N';  /* �W���ɮסAtmnewa 2p�ɤ� count */
	         }

	         /* �p���p�Ȩ����� */
	         if (ISPONYRENT(iofficer,iroute))
	         {
	             flag_M   = 'Y';
	             count_linnum = 'N';  /* �W���ɮסAtmnewa 2p�ɤ� count */
	         }

	         /*  �Τ@�F��(�~�Ȩӷ���:����~��)   */
		 if (ISTOKYO(iofficer,tmp_ilicense))
		 {
	             flag_T   = 'Y';
	             count_linnum = 'N';  /* �W���ɮסAtmnewa 2p�ɤ� count */
	         }

	         /*  �p����گ���   */
	         if (ISUFLC(iroute))
	         {
	              flag_L  = 'Y';
	              count_linnum = 'N';  /* �W���ɮסAtmnewa 2p�ɤ� count */
	         }

	         /*  ��s�T��   */
	         if (ISSHING(iroute))
	         {
	              flag_S  = 'Y';
	              count_linnum = 'N';  /* �W���ɮסAtmnewa 2p�ɤ� count */
	         }

	         /*  �ڤO�h�T��   */
	         if (ISORIX(iroute))
	         {
	              flag_Orix  = 'Y';
	              count_linnum = 'N';  /* �W���ɮסAtmnewa 2p�ɤ� count */
	         }

	         /*  �鲱����q (1021218002_C1)  */
	         if (ISJIHSUN(iroute))
	         {
	              flag_Jihsun  = 'Y';
	              count_linnum = 'N';  /* �W���ɮסAtmnewa 2p�ɤ� count */
	         }

	         /*  ��ù�T�� (1120724008_C02)  */
	         if (ISPRO(iroute))
	         {
	              flag_PRO  = 'Y';
	              count_linnum = 'N';  /* �W���ɮסAtmnewa 2p�ɤ� count */
	         }

	         /*  �w���� (1030916005_C1)  */
	         if (ISAVIS(iroute))
	         {
	              flag_AVIS  = 'Y';
	              count_linnum = 'N';  /* �W���ɮסAtmnewa 2p�ɤ� count */
	         }

	         /* �����}�M (1061229002_C1) */
	         if (ISCHAILEASE (iroute))
	         {
	              flag_CHAILEASE  = 'Y';
	              count_linnum = 'N';  /* �W���ɮסAtmnewa 2p�ɤ� count */
	         }

	         /* JB�ư������s (1091210006_SC2) */
	         if (strcmp(iroute,"JB") == 0)
	         {
	              flag_JB  = 'Y';
	              count_linnum = 'N';  /* 2P�t�~���s�ɮסAtmnewa 2p�ɤ� count */

	              $EXECUTE prep_renew_jb INTO $cnt_renew_jb USING $ipolicy;
                      if(SQLCODE == SQLNOTFOUND)
                      {
         	          flag_JBDelete = 'N';
                      }
                      else
                      {
                          if(cnt_renew_jb == 0)
                              flag_JBDelete = 'N';
                          else
                              flag_JBDelete = 'Y';
                      }
	         }

	         /* �N�ӻȦ� (1110308005_SC3)*/
	         if (ISNEXTBANK (iroute))
	         {
	              flag_NEXTBANK  = 'Y';
	              count_linnum = 'N';  /* �W���ɮסAtmnewa 2p�ɤ� count */
	         }

	         /* �I�� (1110816006_SC1)*/
	         if (ISMOMO (iroute))
	         {
	              flag_MOMO  = 'Y';
	              count_linnum = 'N';  /* �W���ɮסAtmnewa 2p�ɤ� count */
	         }

	         /* F���� (1110317002_SC1)*/
	         $EXECUTE prep_provision_f INTO $cnt_provision_f USING $ipolicy;
	         if (cnt_provision_f > 0)
	         {
	              flag_F  = 'Y';
	              count_linnum = 'N';  /* �W���ɮסAtmnewa 2p�ɤ� count */
	         }

	         /*  �R�q��  (1120927002_C05) */
	         if (strncmp(ipolicy+(5),"ES",2)==0){
	              flag_ES  = 'Y';
	              count_linnum = 'N';  /* �W���ɮסAtmnewa 2p�ɤ� count */
	         }

	         /* 110.05.24 car102���H�U���O�C�J�i�S�����O�j�� add by 061476 (1100504003_SC1) */
	         /* 110.06.02 �YJB��ŦX����h���C�JJB�ɤ� modify by 061476 (1100504003_SC2) */
	         if ((freason_reject[0]=='1')||(freason_reject[0]=='2')||(freason_reject[0]=='3')||(freason_reject[0]=='4')||
	             (freason_reject[0]=='5')||(freason_reject[0]=='6')||(freason_reject[0]=='8')||(freason_reject[0]=='A'))
	         {

	              flag_102  = 'Y';
	              count_linnum = 'N';  /* �W���ɮסAtmnewa 2p�ɤ� count */
	              if (flag_JB == 'Y') flag_JB  = 'N';
	              if (flag_NEXTBANK == 'Y') flag_NEXTBANK  = 'N';
	              if (flag_MOMO == 'Y') flag_MOMO  = 'N';
	         }

	         if (chk_PA > 0)
	         {
    	             /* �s�W:��L����(PA* �ư��즳����~),�B���������ιq�ʦۦ樮 add by sylvia 104.01.22 (1040114003_C1) */
    	             /* ���Ȱ�گ����_��O�ɤ��e�é�J����~�ɤ� modify by 061476 (1061229002_C1)*/
             	     if ((strncmp(iroute,"PA",2) == 0) && (!(ISMOT(icar_type))) && (strcmp(icar_type,"51") != 0))
             	     {
             	        if( (!(ISCHAILEASE(iroute))) && (!(ISGOSUN(iofficer,iroute))) &&
             	            (!(ISPONYRENT(iofficer,iroute))) && (!(ISTOKYO(iofficer,ilicense))) &&
             	            (!(ISUFLC(iroute))) && (!(ISSHING(iroute))) && (!(ISORIX(iroute))) &&
             	            (!(ISJIHSUN(iroute))) && (!(ISAVIS(iroute))) && (!(ISPRO(iroute))) )
             	        {
             	            flag_PA  = 'Y';
    	                    count_linnum = 'N';  /* �W���ɮסAtmnewa 2p�ɤ� count */
             	        }
             	     }

             	     /* �ư��즳�W�ߪ��D����~ add by sylvia 104.01.22 (1040114003_C1) */
             	     if ((strncmp(iroute,"PA",2) != 0) && (fuw_status_ori == 180))
             	     {
             	         if( (!(ISCHAILEASE(iroute))) && (!(ISFEI(iroute))) && (!(ISGOSUN(iofficer,iroute))) &&
             	             (!(ISPONYRENT(iofficer,iroute))) && (!(ISTOKYO(iofficer,ilicense))) &&
             	             (!(ISUFLC(iroute))) && (!(ISSHING(iroute))) && (!(ISORIX(iroute))) &&
             	             (!(ISJIHSUN(iroute))) && (!(ISAVIS(iroute))) && (!(ISPRO(iroute))) )
             	         {
             	             /* �p�{�� */
             	             if ((strcmp(icar_type,"07") == 0) || (strcmp(icar_type,"15") == 0))
             	             {

             	                 flag_TAXI1  = 'Y';
                                 count_linnum = 'N';  /* �W���ɮסAtmnewa 2p�ɤ� count */
             	             }
             	             else
             	             {   /* ���--�������p�O�欰14,21,08���� */
             	                 flag_RENT1  = 'Y';
                                 count_linnum = 'N';  /* �W���ɮסAtmnewa 2p�ɤ� count */
             	             }
             	         }
             	     }
                 }

                 /* �O�_�����H�e add by sylvia 104.04.28 (1040312001_C1) ---------*/
                 if (count_linnum == 'Y')
                 {
                     for(i=0;i<RsCount;i++)
                     {
                         if((memcmp(ca_unsend[i].iroute_main, ply_route_main,20) == 0) &&
                            (memcmp(ca_unsend[i].iofficer, sIofficer,10) == 0))
                         {
                             flag_RS= 'N';   /* �������H�e */
                             count_linnum = 'N';
                             if (strcmp(ca_unsend[i].fno_print,"Y") == 0)
                                 flag_no_print = 'Y';  /* �����s��O�n�O�� */
                             break;
                         }
                     }

                     /* �۰ʥX��(frenew_type = 3)���O, �n�A�ˮ֬O�_���e�ި�W��f,�Y���ި�W��,�h���H�e add by sylvia 105.04.28 */
                     /* �������q�ˮ� modify by sylvia 105.12.07  ( 1051206006_C1 )*/
                     /*
                     if (strcmp(frenew_type,"3") == 0)
                     {

                         tmp_cnt = 0;
                         $select count(detail2) into $tmp_cnt
                            from car_code
                           where kind = 'SK'
                             and detail = '1'
                             and detail2 = $ileader;
                         if (tmp_cnt > 0)
                         {
                             flag_RS= 'N';
                             count_linnum = 'N';
                         }
                     } */

                 }

                 /* barcode ��̬O�_�Ŀ�e�C�L��O�q���ѡf�P�_�A�p�G���Ŀ�A�n��b �e�������H�e�f�̭��@*
             �@     �H�K���Ʋ��sú�ڸ��  add by sylvia 104.04.28 */
                 /* 51���ئ]���L��榡���P, �n��b���H�e, �ǥ�barcode���ͿW���ɮ� */
                 if ((fBarcode_mark=='Y')||(strcmp(icar_type,"51") == 0))
                 {
                     flag_RS= 'N';   /* �������H�e */
                     count_linnum = 'N';
                 }

                 /* ------------------------------------------------------------- */
                 /*********    �@�����޲z�H��줧�q�ܤζǯu    ***********/
         	 /* 100.12.26 ,SUM ����ܺ޲z�H�p����T*/
         	 /* EASYCAR ��� SUM ��z add by yslvia 105.08.06 (1050804003_C1) */
         	 /* �ק�SUM�BEASYCAR�^���W�h mark by 061476 (1090603011_SC1) */
         	 if ((ISSUM(iroute)) || (ISEASYCAR(iroute)))
         	 {

		     /* �޲z�H�W�٤ιq�ܡB�ǯu��Hcm121�]�w��������,�~�Z�������ť�
			modify by sylvia 103.07.04 (1030627007_C1) */
		     $select ncontact[1,14],tphone,tfax
			into $nname, $iquota_tel, $iquota_fax
			from cm_route
		       where iroute = $iroute;

		     if (SQLCODE==SQLNOTFOUND)
		     {
		         strcpy(nname     ," ");   /* �޲z�H�W��          */
		         strcpy(iquota_tel," ");   /* �޲z�H���ݳ��q�� */
		         strcpy(iquota_fax," ");   /* �޲z�H���ݳ��ǯu */
		     }

         	 }
         	 else
         	 {
	             strcpy( fclass, "3");
	             $EXECUTE prep3 INTO $sTmp, $tmp_ileader USING $ileader;

	             if( ileader[0] == '6') /* �����޲z�H�����H��޲z�H����쬰��� */
	             {
	                 $EXECUTE prep3 INTO $sTmp, $sTmp1 USING $tmp_ileader;
	             }

	             $EXECUTE prep2 INTO $iquota_fax, $iquota_tel USING $fclass, $sTmp;

	             if(SQLCODE == SQLNOTFOUND)
	             {
	                 /* 102.07.01 �O����~����~�@��( 630220) �O����~����~�G��(630230) �ǯu���@��
		            �ҥH�������H��ų��N�X�����ơA�줣��~�γ��ų��N�X��
		            (���O�q����ثe�S��show�ǯu���X)*/
		         sTmp[4] = '0';  sTmp[5] = '0';
		         $EXECUTE prep2 INTO $iquota_fax, $iquota_tel USING $fclass, $sTmp;
		         if(SQLCODE == SQLNOTFOUND)
		         {
	                     strcpy( iquota_fax, " ");
	                     strcpy( iquota_tel, " ");
		         }
	             }
                 }

                 /******** ���o�q���W�� ********/
	         $EXECUTE prep_nroute INTO $nroute USING $iroute;
	         if(SQLCODE == SQLNOTFOUND)
	         {
	             strcpy(nroute, " ");
	         }
	         else
	         {
	             strcpy(nroute, trimx(nroute));
	         }

		 /* 990927,�O���ȥ��b�䪺�u��O�q���ѡv�W�[�C�L����T�G
		   	   �q���W�١G�O�����N �O������W��
		   	   �~�ȭ��m�W�G(�~�ȭ��m�W)
		 */
	         if (strncmp(iroute,"I050",4 )==0)
	         {
	             /* �O���� */
	             if (strlen(nroute) < 31)
	             {
	                 strcpy(sTmp1,nroute);
	         	 sprintf_s(nroute,sizeof nroute,"�O�����N %s",sTmp1);
	             }
	         }
         }
         else
         {
	     /* 102.07.10�A���M�����X�@�A���M�S���榡�אּ��W���s5p�ɡAtmnewa 5p�ɮפ������t���M�� */
	     /* �O�N�� �۵M�HID4~7�X�H"*"�����N ( ���M(L*)�Υ���(P*)���~ ) */
	     /* �� "��n�]�u��" ���M(L*)�Υ���(P*)�b ca3025q01s.ec �B�z, �G�L�ݦA�B�~�P�_�O�N���� */
	     /*  ******  �p�G���W���L�O�N�A�����`�NID���óB�z    ********/
	     /* 106.12.08 �]�L�s�t�ӥi�t�X���Ӹ�B�n�A�G�����O�N����O�ɳQ�O�I�HID��ƾB�n�]�w */


             if (( IsPlyB =='Y' )&& (ibig_comp[0]!='L'))
             {
                 /* B�� */ /* ���M�M�׭n�ư� (1081018008_SC1) */
             	 count_linnum = 'N';
             }
             else
             {
	         if (ibig_comp[0]=='P')
	         {
	             flag_P  = 'Y';          /* ���пW���ɮ� */
	             count_linnum = 'N';     /* �P�\���T�{,tmnewa 5p �ɮפ��n�񥻥Х�  modify by sylvia 104.01.23 */
	         }
	         else if (ibig_comp[0]=='G')
	         {
	             flag_G  = 'Y';          /* ���W�W���ɮ� */
	             count_linnum = 'N';     /* �P�\���T�{,tmnewa 5p �ɮפ��n����W��  modify by sylvia 104.01.23 */
	         }
	         else if (ibig_comp[0]=='L')
	         {
	             flag_Six  = 'Y';        /* ���M�W���ɮסAtmnewa 5p�ɮפ����t���M��A���� count */
	             count_linnum = 'N';
	         }
	         else if (ibig_comp[0]=='B')
	         {
	             flag_B  = 'Y';          /* ���׿W���ɮסAtmnewa 5p�ɮפ����t���ץ�A���� count */
	             count_linnum = 'N';
	         }
	         else if (ibig_comp[0]=='J')
	         {
	             flag_J  = 'Y';          /* ���q�W���ɮסAtmnewa 5p�ɮפ����t���q��A���� count */
	             count_linnum = 'N';
	         }
	         else if (strncmp(ipolicy+(5),"ES",2)==0)
	         {
	             flag_ES  = 'Y';         /* �R�q�οW���ɮסAtmnewa 5p�ɮפ����t�A���� count  (1120927002_C05) */
	             count_linnum = 'N';
	         }
	         else if  ((chk_PA > 0) && (fuw_status_ori == 180))
	         {
	             if ((strcmp(icar_type,"07") == 0) || (strcmp(icar_type,"15") == 0))
	             {
	                 flag_TAXI2  = 'Y';        /* �p�{��*/
	             	 count_linnum = 'N';
	             }
	             else
	             {
	             	 /* ���--�������p�O�欰14,21,08���� */
	             	 flag_RENT2  = 'Y';        /* ���*/
	             	 count_linnum = 'N';
	             }
	         }
	         else if (strncmp( iofficer,"A09",3)==0 )
	         {
	             flag_A09 = 'Y';
	             count_linnum = 'N'; /* A09�W���ɮסAtmnewa 5p�ɤ� count A09 */
	         }
	     }



	     /*********   �O�N��B�M�ץ�L�ݺ޲z�H���q�ܡB�ǯu�γq����T    ***********/
             strcpy( iquota_fax, " ");
             strcpy( iquota_tel, " ");
             strcpy( iroute, " ");
             strcpy( nroute, " ");

             /********   �~�NID  ********/
             /* �\���ק�P�_����:�g��N����1�X������B�BP���A��~���N����1�X�O�^��AND��4�X�O�Ʀr �A�q��4�X�_�}�l�B4�X
                modify by sylvia 103.09.12 */
             /* 102.07.10�A���M�����X�@�A���M�S���榡�אּ��W���s5p�ɡAtmnewa 5p�ɮפ������t���M�� */
	     if (strlen(ibig_sales)>=10)
	     {

	         if ((iofficer[0]!='B')&&(iofficer[0]!='P')&&(isalpha(ibig_sales[0]))&&(isdigit(ibig_sales[3])))
	         {
	             strncpy(ibig_sales+(3),"****",4);
	         }
	     }

             /******** 102.12.25  B��   ********/
             strcpy(iofficer_prmt," ");
    	     if ( IsPlyB =='Y' )
    	     {
    	         $EXECUTE prep_ca_prmt_off Into $iofficer_prmt using $iofficer, $ibig_office;
    	 	 if (SQLCODE == SQLNOTFOUND )
    	 	 {
    	 	     /*�YA��g�찱�ΡA�hca_promote_officer �N���|����A��g�줧������� ex. B14038
    	 	       => ��B��W�������^�k�g��N�� */
    	 	     $SELECT iofficer_prmt Into $iofficer_prmt FROM ply_relation_last
                       WHERE ipolicy= $ipolicy;
    	 	 }
    	 	 strncpy(ibig_branch,iofficer_prmt,3);

		 /* B�椧"�޲z�H�W��(nname)"�n��"A��޲z�H�W��"���*/
		 strcpy(tmp_ileader," "); strcpy(nname," ");
		 $EXECUTE prep3 INTO $sTmp, $tmp_ileader USING $iofficer_prmt;
		 $EXECUTE prep6 INTO $nname USING $tmp_ileader;

		 /*  �`�N�G���ӥ󪺾��I�N�����G
		           �O���ɩ񪺬O(A�BB��): �ζ�(A)=A��g��N��;��l�O�N="�g��H�ɳ]�w���g�P�Ӿ��I�N��(ibus_location)"
		           ��O�ɩ񪺬O:   A�� �G���O"�g��H�ɳ]�w���g�P�Ӿ��I�N��(ibus_location)"
		                           B�� �G�ζ�(A)=A��g��N��; ����(B)="�g��H�ɳ]�w���g�P�Ӿ��I�N��(ibus_location)"
		                                    (==> �]�N�OB���ӥh�~�O���ۦP�����I�N����� )
		           ���O���s�q�l�ɮɡA�Y�OB��A�B�O�ζ����ܡA����I�N����쥲���HA��g��h�����g�P�Ӿ��I�N��(ibus_location)
		 */

		 if ((ibig_office[0]=='A')&&(strlen(ibig_office)==6))
		 {
		     /* ibig_office = �ζ�A��g�� */
		     strcpy(tmp_ibig_office,ibig_office);
		     $EXECUTE prep_location	Into $ibig_office using $tmp_ibig_office;
		 }

		 /* �M�ץ���O�n�O�Ѷ��񡨪ťա������G
                    �n�O�H����������G�n�O�H�W�١B�n�O�H������/�νs�B�n�O�H�a�}�l���ϸ��B
                                        �n�O�H�a�}�B�n�O�H�ʧO�B�n�O�H�X�ͤ���B�n�O�H�q�ܡB
                                        �n�O�H���k�H�N���H�B�n�O�H�P�Q�O�I�H���Y
                    �A�ȤH��������T�G�A�ȤH��(�޲z�H�W��)�B���B�q�ܡB�ǯu*/

		 strcpy(iapplicant,tmp_ilicense); /* �n�O�H�P�Q�O�I�Hid�ۦP�ɡA�N���|�L�n�O�H��T */
		 strcpy(napplicant," ");          /* �]�n�O�H�W�ٰ��~) */

                 /* ���騮�d�ߴڬ�����Ƥ]���L*/
                 strcpy(lia_ac_cnt1 ," ");  strcpy(lia_ac_cnt2 ," ");  strcpy(lia_ac_cnt3 ," ");
                 strcpy(dmg_ac_cnt1 ," ");  strcpy(dmg_ac_cnt2 ," ");  strcpy(dmg_ac_cnt3 ," ");
                 strcpy(lia_ac_cntc ," ");  strcpy(pdmg_acc    ," ");  strcpy(plia_acc_c  ," ");
                 strcpy(pre_lia_acc ," ");  strcpy(pre_dmg_acc ," ");  strcpy(sDmg_lia_remark1," ");
                 strcpy(sDmg_lia_remark2," ");  strcpy(iquery_num_lia," ");
                 strcpy(iquery_num," ");        strcpy(iquery_num_damage," ");
                 strcpy(dmg_point   ," ");  strcpy(lia_class   ," ");  strcpy(pdmg_acc_sug," ");
                 strcpy(punknown_acc    ," "); strcpy(pre_unknown_acc ," ");strcpy(punknown_acc_sug," ");
                 strcpy(iquery_num_unknown," ");

		 strSearchReplace(ipolicy_print,"-B","");  /* �h�� "-B"�]����B��^ */

    	     }
    	     else
    	     {
    	         strncpy(ibig_branch, iofficer, 3);
    	     }
    	     ibig_branch[3]='\0';

         }

         /* JB�q��,�޲z�H��������O�A�Ȳ� �q�ܬ�0800366168�M�u modify by sylvia 103.06.13(1030613002_C1) */
         /* ���קK���s�ɱN�q�ܵ����Ʀr�ӥh0�A�W�[�i-�j�Ÿ� modify by 061476 (1100310005_SC1) */
         /* JB�ȪA�q�ܭn���y (1110928005_SC1) */
         strcpy(iroute, trim(iroute));
         if (strcmp(iroute,"JB") == 0 || ISNEXTBANK(iroute))
         {
            strcpy(nname,"������O�A�Ȳ�");
            strcpy(iquota_tel, "0800-369-168");
         }

         if ((strcmp(iofficer,"890502") == 0) ||(strcmp(iofficer,"890502A") == 0) ||
             (strcmp(iofficer,"03A1498001") == 0) ||
             ((strcmp(iofficer,"940920A") == 0) && (strcmp(iroute,"PD16834703890502") == 0)))
         {
    	    /* �]���s�_�������p���z�ର�U��, ��O�~�ȳq���窺�p���H��ƪť�
    	       ����:1.�g��N��:890502�B890502A�B03A1498001�Ҧ��q��;
    	              2.�g��N��=940920A�B�q���N��=PD16834703890502
    	       add by sylvia 104.03.06 (1040212006_C1)*/
    	    strcpy(nname," ");
            strcpy(iquota_tel," ");
            strcpy(iquota_fax," ");
         }

         /* ---------------------------------------------------------------- */
         /* �z�߾n�~�H�����q�ܤζǯu���אּ�n�~�����  add by sylvia 104.09.17 (1040910012_C1) */
         $select branch_tel, ext_fax
            into $iquota_tel, $iquota_fax
            from tp_claim
           where iofficer = $ileader;
         /*----------------------------------------------------------------- */



         strcpy(prtstr,"17");
         strcat(prtstr,rtrim(ipolicy_print));           /*  001   �O�渹�X    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(ipolicy_1));               /*  002   �O�渹�X�G    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(icard));                   /*  003   �O�I��/�d��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(fcard_class));             /*  004   �j����N�O    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(irelative_ply));           /*  005   ���p�O�渹    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(dply_bgn_comp));           /*  006   �j��ӫO�_��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(dply_end_comp));           /*  007   �j��ӫO����    */
         strcat(prtstr,"\t");

         /* �����㨮����,����N(�L���p��)��ĳ�j���I,comp_prem�H��ĳ��mcomp_prem_sug���N   add by sylvia (1030806002_C1) */
         /* �٭쬰�j���I���O�զX�O�O */
         /*if (fBothIns == 4)
            rfmtlong(mcomp_prem_sug,"-----&",c_comp_prem);
         else */
            rfmtlong(comp_prem,"-----&",c_comp_prem);

         strcat(prtstr,rtrim(c_comp_prem));             /*  008   �j��O�O    */  /* ���B��"���O�զX���j���I�O�O" [�p�G�O����(iroute�GJB)�A��ĳ�B���O�զX���j���I�O�O�i�ण�@��] */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(last_policy_2));           /*  009   �e�G�~���N�O�渹    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(last_policy_3));           /*  010   �e�T�~���N�O�渹    */
         strcat(prtstr,"\t");
         strcpy(c_qply_period,itoa(qply_period));
         strcat(prtstr,rtrim(c_qply_period));           /*  011   �ӫO���    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(dply_begin));              /*  012   �ӫO�_��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(dply_end));                /*  013   �ӫO����    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(nassured));                /*  014   �Q�O�I�H    */
         strcat(prtstr,"\t");
         strcat(prtstr,ilicense);                       /*  015   �r�Ӹ��X    */
         strcat(prtstr,"\t");

         if(strlen(trim(s_dbirth)) > 0 )
         {
	     cm_split_ymd(s_dbirth, tmp_mm, tmp_dd, tmp_yyyy);
	     sprintf_s(s_dbirth,sizeof s_dbirth,"%d/%s/%s", atoi(tmp_yyyy)-1911,tmp_mm,tmp_dd);
         }
         else
         {
             strcpy(s_dbirth,"");
         }
         strcat(prtstr,rtrim(s_dbirth));                /*  016   �X�ͤ��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(fsex));                    /*  017   �ʧO    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(fmarriage));               /*  018   �B�ê��p    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(nuser));                   /*  019   �ϥΤH    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(nbenef));                  /*  020   ����v�H    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(aassured));                /*  021   ���}    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(itel));                    /*  022   �p���q��(��)    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(iply_area));               /*  023   �ӫO�a�ϥN��    */
         strcat(prtstr,"\t");

         /* �W�[�P�_�R�q�ΫO�浹�ť� */
         if (strncmp(ipolicy+(5),"ES",2)==0)
         {
         	strcat(prtstr," ");                     /*  024   �o�Ӧ~��    */
         	strcat(prtstr,"\t");
         	strcat(prtstr," ");                     /*  025   �s�y�~��    */
         	strcat(prtstr,"\t");
         }
         else
         {
         	/* �]���s�Wdbirth ,dissue,  ��3�X����~*/
         	cm_split_ymd(s_dissue, tmp_mm, tmp_dd, tmp_yyyy);
         	if ((atoi(tmp_yyyy)-1911)>=100)
         	{
         		sprintf_s(s_dissue,sizeof s_dissue,"%d/%s", atoi(tmp_yyyy)-1911,tmp_mm);
         	}
         	else
         	{
         		sprintf_s(s_dissue,sizeof s_dissue,"0%d/%s", atoi(tmp_yyyy)-1911,tmp_mm);
         	}
         	strcat(prtstr,rtrim(s_dissue));         /*  024   �o�Ӧ~��    */
         	strcat(prtstr,"\t");
         	strcat(prtstr,rtrim(ipro_year));        /*  025   �s�y�~��    */
         	strcat(prtstr,"\t");
         }

         strcat(prtstr,rtrim(ibrand));                  /*  026   �t�P�����N��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(nbrand_abbr));             /*  027   �t�P�C�L�W��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(car_type_pre));            /*  028   �^�k��O�o���إN��    */
         strcat(prtstr,"\t");
         /* �]���s����,���Φ^�k�᪺�O�o���ح��s���o add by sylvia  */
         if (icar_type[1] >= 65)
         {
             $select ncode into $ncar_type
                from car_type
               where fclass='1' and icode = $car_type_pre;
         }
         strcat(prtstr,rtrim(ncar_type));               /*  029   ���ئC�L�W��    */
         strcat(prtstr,"\t");
         rfmtdouble(qcylinder,"####&.##",c_qcylinder);  /* �Ʈ�q�X�ܤp���I2�� (1080902001_SC3) */
         strcat(prtstr,rtrim(c_qcylinder));             /*  030   �Ʈ�q    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(iengine));                 /*  031   �������X    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(ibody));                   /*  032   �������X    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(itag));                    /*  033   �P�Ӹ��X    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(mcar_price));              /*  034   ���m����    */
         strcat(prtstr,"\t");
         strcpy(c_pdmg_align,itoa(pdmg_align));
         strcat(prtstr,rtrim(c_pdmg_align));            /*  035   �h�������u��    */
         strcat(prtstr,"\t");
         strcpy(c_pbrg_align,itoa(pbrg_align));
         strcat(prtstr,rtrim(c_pbrg_align));            /*  036   �h���ѵs�u��    */
         strcat(prtstr,"\t");
         strcpy(c_plia_align,itoa(plia_align));
         strcat(prtstr,rtrim(c_plia_align));            /*  037   �h���d���u��    */
         strcat(prtstr,"\t");
         rfmtdouble(qpt,"---&.&", c_qpt);
         strcat(prtstr,trim(c_qpt));                    /*  038   �����ƶq    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(fpt));                     /*  039   �������    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(idmg_rate));               /*  040   ����l���O�v�N��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(ibrg_rate));               /*  041   �ѵs�l���O�v�N��    */
         strcat(prtstr,"\t");
         strcat(prtstr," ");                            /*  042   �ʧO�~�֫Y��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(lia_ac_cnt1));             /*  043   �e�@�~�d�ߦ���    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(lia_ac_cnt2));             /*  044   �e�G�~�d�ߦ���    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(lia_ac_cnt3));             /*  045   �e�T�~�d�ߦ���    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(lia_ac_cntc));             /*  046   �e�@�~�j�ߦ���    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(dmg_ac_cnt1));             /*  047   �e�@�~����ߦ�    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(dmg_ac_cnt2));             /*  048   �e�G�~����ߦ�    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(dmg_ac_cnt3));             /*  049   �e�T�~����ߦ�    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(plia_acc));                /*  050   ���d�ߴګY��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(pdmg_acc));                /*  051   ����ߴګY��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(plia_acc_c));              /*  052   �j��ߴګY��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(fcar_class));              /*  053   �ۥ���~���O    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(dedr_begin));              /*  054   ���ͮİ_��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(iofficer));                /*  055   �g��H    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(nname));                   /*  056   �޲z�H�W��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(ibig_office));             /*  057   ������~��    */
         strcat(prtstr,"\t");
         strcat(prtstr,trim(ibig_sales));               /*  058   ���ӷ~�N�N��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(ibig_policy));             /*  059   �j�O�渹    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(ibig_comp));               /*  060   �O�N���q�N��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(ibig_branch));             /*  061   ����    */
         strcat(prtstr,"\t");
         rfmtdouble(mbusiness,"-------&.&",c_mbusiness);
         strcat(prtstr,trim(c_mbusiness));              /*  062   �~�ȶO��(��)    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(fcomp_class));             /*  063   �j����ż�    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(fcomp_class_last));        /*  064   �j��e���ż�    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(ileader));                 /*  065   �޲z�H���u�N��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(aassured_zip));            /*  066   �l���ϸ�    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(irel_card));               /*  067   �e�@�~�j���Ҹ�    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(iquery_num));              /*  068   �j���I�d�����T�Ǹ� (��"�e�G�~�j���Ҹ�")   */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(iquery_num_damage));       /*  069 �����I�d�����T�Ǹ�  (��"�e�T�~�j���Ҹ�")     */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(iquota));                  /*  070   �~�Z���N��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(nchi_full));               /*  071   �~�Z���W��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(fnation));                 /*  072   ���y    */
         strcat(prtstr,"\t");
         strcpy(c_v_prem,itoa(v_prem));
         strcat(prtstr,rtrim(c_v_prem));                /*  073   ���N�O�O(A)    */
         strcat(prtstr,"\t");
         strcpy(c_tot_prem,itoa(tot_prem));
         strcat(prtstr,rtrim(c_tot_prem));              /*  074   �`�O�O(A+C)    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(ch_ins_grp1));             /*  075   ��O���e�@    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(ch_ins_grp2));             /*  076   ��O���e�G    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(ch_ins_grp3));             /*  077   ��O���e�T    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(pre_dply1_bgn));           /*  078   �e���j��ӫO�_��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(pre_dply1_end));           /*  079   �e���j��ӫO����    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(pre_prem1));               /*  080   �e���j��O�O    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(pre_prem2));               /*  081   �e�����N�O�O    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(pre_dply2_bgn));           /*  082   �e�����N�ӫO�_��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(pre_dply2_end));           /*  083   �e�����N�ӫO����    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(pre_sex_age));             /*  084   �e���~�֫Y��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(pre_lia_acc));             /*  085   �e���d���ߴګY��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(pre_dmg_acc));             /*  086   �e������ߴګY��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(note1));                   /*  087   �Ƶ� (�S�ϥ�,��ť�) *//* 1040508 ���s�ҥ�,�אּ��m�M�ץN�� */
         strcat(prtstr,"\t");

         /* �w���� �έ�W�b�� */
         if (count_linnum=='Y') linnum_a += 1;

         strcat(prtstr,rtrim(itoa(linnum_a)));          /*  088   �y����    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(nbrand));                  /*  089   �t�P�W��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(remark1));                 /*  090   �Ƶ��@    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(remark2));                 /*  091   �Ƶ��G    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(remark6));                 /*  092   �Ƶ���    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(remark7));                 /*  093   �Ƶ��C    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(LHsIbig_Nname));           /*  094   �~�N�W��    */
         strcat(prtstr,"\t");
         strcat(prtstr,itoa(iMdiscount));               /*  095   �������B    */
         strcat(prtstr,"\t");
         strcat(prtstr,itoa(iTot_mpay));                /*  096   �ꦬ���B(A+C)    */
         strcat(prtstr,"\t");
         strcat(prtstr," ");                            /*  097   �e����O���e�@    *//*pre_ch_ins_grp1 ���u�o�L�e���ӫO����A�G���������T*/
         strcat(prtstr,"\t");
         strcat(prtstr," ");                            /*  098   �e����O���e�G    *//*pre_ch_ins_grp2  */
         strcat(prtstr,"\t");
         strcat(prtstr," ");                            /*  099   �e����O���e�T    *//*pre_ch_ins_grp3  */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(icorps));                  /*  100   ¾�ΥN��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(ncorps));                  /*  101   ¾�ΦW��    */
         strcat(prtstr,"\t");
         rfmtdouble(pdiscount,"--&.&&",spdiscount);
         strcat(prtstr,rtrim(spdiscount));              /*  102   �����v    */
         strcat(prtstr,"\t");
         strcat(prtstr,fcomp_24);                       /*  103   �s�v�I���O    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(remark3));                 /*  104   �Ƶ��T    */
         strcat(prtstr,"\t");
         strcat(prtstr,fassured);                       /*  105   �Q�O�I�H�ʽ�    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(tphone_con));              /*  106   �p���q��(�])    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(imovephone));              /*  107   ��ʹq��    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(iemail));                  /*  108   email�b��    */
         strcat(prtstr,"\t");
         rfmtdouble(psex_age_c,"-&.&&", c_psex_age);
         strcat(prtstr,trim(c_psex_age));               /*  109   �~�֩ʧO�Y��(�j��)    */
         strcat(prtstr,"\t");
         rfmtdouble(psex_age_v,"-&.&&", c_psex_age);
         strcat(prtstr,trim(c_psex_age));               /*  110   �~�֩ʧO�Y��(���N)    */
         strcat(prtstr,"\t");
         rfmtdouble(dmg_factor,"-&.&&&&", c_dmg_factor);
         strcat(prtstr,trim(c_dmg_factor));             /*  111   ����l���I�Y��    */
         strcat(prtstr,"\t");
         rfmtdouble(brg_factor,"-&.&&&&", c_brg_factor);
         strcat(prtstr,trim(c_brg_factor));             /*  112   �ѵs�l���I�Y��    */
         strcat(prtstr,"\t");
         strcpy(c_v_prem,itoa(v_ori_prem));
         strcat(prtstr,rtrim(c_v_prem));                /*  113   ���O�զX�O�I�O(B)    */
         strcat(prtstr,"\t");
         strcpy(c_tot_prem,itoa(tot_ori_prem));
         strcat(prtstr,rtrim(c_tot_prem));              /*  114   ���O�զX�`�O�I�O(B+C)    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(remark4));                 /*  115   remark4    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(remark5));                 /*  116   �O��q�T    */
         strcat(prtstr,"\t");
         strcat(prtstr, " ");                           /*  117   �~�ȥN�X ,990728=> �w�אּ nequipment	���O(�t�P�t��)	char(30)    */
         strcat(prtstr,"\t");
         strcat(prtstr, iquota_tel);                    /*  118   �޲z�H���ݳ��q��    */
         strcat(prtstr,"\t");
         strcat(prtstr, iquota_fax);                    /*  119   �޲z�H���ݳ��ǯu    */
         strcat(prtstr,"\t");
         strcpy(ichange_note, trim(ichange_note));
         strcat(prtstr, ichange_note);                  /*  120   �j���I���ز���    */
         strcat(prtstr,"\t");
         strcat(prtstr, nofficer);                      /*  121   �g��H�W��    */
         strcat(prtstr,"\t");
         strcat(prtstr, nbroker);                       /*  122   �g���H�W��    */
         strcat(prtstr,"\t");
         strcat(prtstr, iroute);                        /*  123   �q���N��   */
         strcat(prtstr,"\t");
         strcat(prtstr, nroute);                        /*  124   �q���W��   */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(sDmg_lia_remark1));        /*  125   if X31��=> ���N�I�d�L���T    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(sDmg_lia_remark2));        /*  126   if X31��=> �Y��,�Э��s�T�{   */
         strcat(prtstr,"\t");
         strcat(prtstr," ");                            /*  127   �ثe�񤭳��s�a�}  */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(iquery_num_lia));          /*  128 ���d�I�d�����T�Ǹ�   */
         strcat(prtstr,"\t");

         if (strlen(trim(pdmg_acc))>0){
            rstod(pdmg_acc,&dbl_pdmg_acc);
            rfmtdouble(dbl_pdmg_acc/0.2,"-&", dmg_point); /*  129 ����ߴڬ����I��   */
            strcat(prtstr,trim(dmg_point));
         }else{
         	strcat(prtstr," ");
         }
         strcat(prtstr,"\t");

         strcat(prtstr,rtrim(lia_class));               /*  130 ���d�̷s�ż�   */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(napplicant));              /*  131 �n�O�H�W��  */
         strcat(prtstr,"\t");

         /* �Y�u�n�O�H�����Ҧr���v���ťթλP�u�Q�O�I�H�����Ҧr���v���P�h�@�ߦL�X�H�U�n�O�H����T�A�_�h�ť�*/
         strcpy(iapplicant,rtrim(iapplicant));

         /* ���׳Q�O�H�P�n�O�H�O�_�P�@�H, �n�O�H����٬O�n���L (1030905001_C1) */
         strcat(prtstr,rtrim(iapplicant));	        /*  132 �n�O�H������/�νs	varchar(12)*/
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(apayment_zip));	        /*  133 �n�O�H�a�}�l���ϸ�	char(5)*/
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(apayment));	        /*  134 �n�O�H�a�}        	varchar(90)*/
         strcat(prtstr,"\t");

         if (fsex_appl[0]=='1'){
         	strcpy(nsex_appl,"�k");
         }else if (fsex_appl[0]=='2'){
         	strcpy(nsex_appl,"�k");
         }else{
         	strcpy(nsex_appl," ");       /* �k�H */
         }
         strcat(prtstr,rtrim(nsex_appl));	        /*  135 �n�O�H�ʧO	        char(2)*/
         strcat(prtstr,"\t");

         if(strlen(trim(dbirth_appl)) > 0 ){            /*  136 �n�O�H�X�ͤ��	    date*/
         	cm_split_ymd(dbirth_appl, tmp_mm, tmp_dd, tmp_yyyy);
         	sprintf_s(s_dbirth_appl,sizeof s_dbirth_appl,"%d/%s/%s", atoi(tmp_yyyy)-1911,tmp_mm,tmp_dd);
         }else{
         	strcpy(s_dbirth_appl," ");
         }

         strcat(prtstr,rtrim(s_dbirth_appl));
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(itel_appl));	        /*  137 �n�O�H�q��	        varchar(20)*/
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(ndeputy_appl));            /*  138 �n�O�H���k�H�N���H	varchar(50)*/
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(nrelation_appl));          /*  139 �n�O�H�P�Q�O�I�H���Y	varchar (40)*/
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(ndeputy_assured));	        /*  140 �Q�O�I�H���k�H�N���H	varchar(50)*/
         strcat(prtstr,"\t");

         if (strlen(trim(ori_Bcode1))>0){               /* 141 ���X�@ (��+��ĳ��O�զX)  */
             strcat(prtstr, ori_Bcode1);
         }else if (strlen(trim(Bcode1))>0){
         	 strcat(prtstr, Bcode1);
         }else{
         	 strcat(prtstr, " ");
         }
         strcat(prtstr,"\t");
         strcat(prtstr, ori_Bcode2);                    /* 142 ���X�G (���O�զX)  */
         strcat(prtstr,"\t");
         strcat(prtstr, ori_Bcode3);                    /* 143 ���X�T (���O�զX)  */
         strcat(prtstr,"\t");
         strcat(prtstr, Bcode2);                        /* 144 ���X�G (��ĳ��O�զX)  */
         strcat(prtstr,"\t");
         strcat(prtstr, Bcode3 );                       /* 145 ���X�T (��ĳ��O�զX)  */
         strcat(prtstr,"\t");
         strcat(prtstr, rtrim(s_paydate));              /* 146 ú�O���� (MM/DD/YYYY) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(nsecond_hand));            /*  147 ���j����W��	varchar(40)*/
         strcat(prtstr,"\t");

         if (strlen(trim(pdmg_acc_sug))>0){             /* ���Y�Ƥ~�L */
         	 strcat(prtstr, rtrim(pdmg_acc_sug));   /*  148 ����ߴګY��(��ĳ)   */
         	 strcat(prtstr,"\t");

         	 strcat(prtstr,rtrim(iquery_num_damage_sug));      /*  149 �����I�d�����T�Ǹ�(��ĳ)   */
         	 strcat(prtstr,"\t");

             rstod(pdmg_acc_sug,&dbl_pdmg_acc_sug);
             rfmtdouble(dbl_pdmg_acc_sug/0.2,"-&", dmg_point_sug); /*  150 ����ߴڬ����I��(��ĳ)     */
             strcat(prtstr,trim(dmg_point_sug));
         }else{
         	 strcat(prtstr,"\t\t");
         }
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(iintroducer));             /*  151 �श�~�ȭ�/�q�����u*/
         strcat(prtstr,"\t");
         strcat(prtstr,trim(itoa(qdrunk_driving)));     /*  152 �s�r���� */
         strcat(prtstr,"\t");
         strcat(prtstr,vDrate_ym);                      /*  153 ���N�I�O�v�N�� add by sylvia 103.04.30 (1030307001_C1)*/
         strcat(prtstr,"\t");
         strcat(prtstr,ireg_no);                        /*  154 ��~���n���Ҧr�� add by sylvia 103.09.11 (1030901003_C1) */
         strcat(prtstr,"\t");
         strcat(prtstr,iestimate_ori);                  /*  155 ���O�զX�����渹 add by sylvia 103.12.02 (1031111001_C3) */
         strcat(prtstr,"\t");
         strcat(prtstr,iestimate_sug);                  /*  156 ��ĳ��O�զX�����渹 add by sylvia 103.12.02 (1031111001_C3) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(icar_type));               /*  157 ���������N��(�X�檺���إN��) add by sylvia 104.02.17 (1040202006_C3)    */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(itransno_sug_atm));        /*  158 ��ĳ��O�զX_ATMú�ڽs�� add by sylvia 104.03.27 (1040312001_C1) */
         strcat(prtstr,"\t");

         /* ����ú�ڽs����, ATMú�ڪ��B�ť� */
         if (fuw_status_sug != 500)
            strcpy(c_tot_prem," ");
         else
         {
            tot_prem = tot_prem-15;
            strcpy(c_tot_prem,itoa(tot_prem));
         }
         strcat(prtstr,rtrim(c_tot_prem));              /*  159   ��ĳ��O�զX�`�O�O(A+C)_ATMú�ڪ��B add by sylvia 104.03.27 (1040312001_C1) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(itransno_ori_atm));        /*  160   ���O�զX_ATMú�ڽs�� add by sylvia 104.03.27 (1040312001_C1) */
         strcat(prtstr,"\t");

         /* ����ú�ڽs����, ATMú�ڪ��B�ť� */
         if (fuw_status_ori != 500)
            strcpy(c_tot_prem," ");
         else
         {
            tot_ori_prem = tot_ori_prem-15;
            strcpy(c_tot_prem,itoa(tot_ori_prem));
         }
         strcat(prtstr,rtrim(c_tot_prem));              /*  161   ���O�զX�`�O�O(B+C)_ATMú�ڪ��B add by sylvia 104.03.27 (1040312001_C1) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(itransno_sug_post));       /*  162   ��ĳ��O�զX_�l�F����ú�ڽs�� add by sylvia 104.03.27 (1040312001_C1) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(itransno_ori_post));       /*  163   ���O�զX_�l�F����ú�ڽs�� add by sylvia 104.03.27 (1040312001_C1) */
         strcat(prtstr,"\t");
         rfmtlong(mcomp_prem_sug,"-----&",c_comp_prem);
         strcat(prtstr,rtrim(c_comp_prem));             /*  164 �j���I�O�O(��ĳ��O�զX) add by sylvia 104.05.20 */
         strcat(prtstr,"\t");


         tot_ori_prem = 0;
         $select decode(mins_premium,0,0,mprem-mins_premium) into $tot_ori_prem
            from ply_ins_type_302
           where ipolicy = $ipolicy and iins_type = '21';

         if (SQLCODE == SQLNOTFOUND )
         {
            tot_ori_prem = 0;
            if (fBothIns == 3)
            {
                $select decode(mins_premium,0,0,mprem-mins_premium) into $tot_ori_prem
                   from ply_ins_type_302
                  where ipolicy = $irelative_ply and iins_type = '21';

                if (SQLCODE == SQLNOTFOUND )
                    tot_ori_prem = 0;
            }
         }

         strcpy(c_tot_prem,itoa(tot_ori_prem));
         strcat(prtstr,rtrim(c_tot_prem));              /*  165   �j���I�O�O�����B(��ĳ�զX) add by sylvia 104.03.27 (1040312001_C1) */
         strcat(prtstr,"\t");

         tot_ori_prem = 0;
         $select decode(ori_premium,0,0,mprem-ori_premium) into $tot_ori_prem
            from ply_ins_type_302
           where ipolicy = $ipolicy and iins_type = '21';

         if (SQLCODE == SQLNOTFOUND )
         {
            tot_ori_prem = 0;
            if (fBothIns == 3)
            {
                $select decode(ori_premium, 0,0,mprem-ori_premium) into $tot_ori_prem
                   from ply_ins_type_302
                  where ipolicy = $irelative_ply and iins_type = '21';

                if (SQLCODE == SQLNOTFOUND )
                    tot_ori_prem = 0;
            }
         }
         strcpy(c_tot_prem,itoa(tot_ori_prem));
         strcat(prtstr,rtrim(c_tot_prem));              /*  166   �j���I�O�O�����B(���O�զX) add by sylvia 104.05.20 */
         strcat(prtstr,"\t");
         rfmtdouble(mequipment,"---&.&", c_mequipment);
         strcat(prtstr,trim(c_mequipment));             /*  167   �t�ƻ�    */
         strcat(prtstr,"\t");
         strcat(prtstr,iassured_cntry);                 /*  168   �Q�O�I�H��O���O(RBA) add by sylvia 105.03.03 (1050105008_C4) */
         strcat(prtstr,"\t");
         strcat(prtstr,iapplicant_cntry);               /*  169   �n�O�H��O���O(RBA) add by sylvia 105.03.03 (1050105008_C4) */
         strcat(prtstr,"\t");

         /*I006�X�w�C�L�X�Ӫ����z�s���վ�A�ȭק�C�L�X�Ӫ����z�s���A�t�ΤJ�檺���z�s���W�h���ܡC*/
         /*modify by 071004 1100323003_SC1_�X�w�n�O�Ѩ��z�s�����X�����վ�*/
         /* 21702+����N�X+����z�s��(�@25�X)*/
         /* �¨�G ex�G2170213460021711305250017 */

	 /*I006�X�w�C�L�X�Ӫ����z�s���վ�A�ȭק�C�L�X�Ӫ����z�s���A�t�ΤJ�檺���z�s���W�h���ܡC*/
         /* modify by 080284 1111216003_C02_�X�w���I�ب��z�s���W�h�վ�*/
         /* ���I���q�N�X(3�X) + ����O(4�X) + ���z���(7�X) + �ץ�O(1�X) + �I�O(1�X) + �y����(3�X) = 19�X */
         /* ���q�X: 117���I���q�N�X(�T�w)�B����O: (�q�q���N�����o�A��4�X) */
         /* ���z���:(�Ψt�Τ�CYYMMDD)�B�ץ�O:(N:�s��BC:��O��BS:����)�B�I�O(A�G�T�����I) */
         /* �s��G ex�G2170200300011700301130424CA62 */
         strcpy(iroute_accept_tmpbr," "); /*����N�X�G4�X*/
         strcpy(iroute_accept_tmpno," "); /*���z�s���G19�X�A�����X�ƥ���0*/

         /*if(strncmp(iroute,"I006",4)==0)
         {
             strncpy(iroute_accept_tmpbr,iroute+4,4);
             iroute_accept_tmpbr[4]='\0';
             for(i=0;i<21-strlen(trim(iroute_accept));i++)
             {
             	iroute_accept_tmpno[i]='0';
             	if(i==21-strlen(trim(iroute_accept))-1) iroute_accept_tmpno[i+1]='\0';
             }

             sprintf_s(iroute_accept_tmpno,sizeof iroute_accept_tmpno,"%s%s",iroute_accept_tmpno,iroute_accept);
             iroute_accept_tmpno[21]='\0';

             strcpy(iroute_accept,"21702");
             strcat(iroute_accept,iroute_accept_tmpbr);
             strcat(iroute_accept,iroute_accept_tmpno);
             iroute_accept[30]='\0';
         }*/

         /* ��113/01�J�p113/03��O��ư_, ���Ȩ��z�s�������ɧאּ16�X,
            �b�C�L��r�ɮ�, ���z�s��(16�X)+��4��j/���O(1�X) = 17�X  �e�L��t
            ��Ʈw���e�s16�X���ܡC modify by sylvia 112.12.21 (1121006006_C01) */
         if(strncmp(iroute,"I009",4)==0)
         {
            strcpy(iroute_accept,trim(iroute_accept));
            strcpy(fcard_class,rtrim(fcard_class));
            strcat(iroute_accept, fcard_class);
         }

         strcat(prtstr,iroute_accept);                  /*  170   �X�w���z�s�� add by sylvia 105.06.04 (1050107005_C4) */
         strcat(prtstr,"\t");
         strcat(prtstr,bzfrom);                         /*  171   �O�o�q���N�� add by sylvia 105.08.24 (1050812001_C1) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(pre_unknown_acc));         /*  172   �e���������l�ߴګY��    */
         strcat(prtstr,"\t");
         if (strlen(trim(iquery_num_unknown)) < 5 )
            strcat(prtstr," ");                         /*  173   �������l�ߴګY��  (���O)   */
         else
            strcat(prtstr,rtrim(punknown_acc));         /*  173   �������l�ߴګY��  (���O)   */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(iquery_num_unknown));      /*  174 �������l�d�����T�Ǹ�  (���O)     */
         strcat(prtstr,"\t");
         if (strlen(trim(iquery_num_unknown_sug)) < 5 )
            strcat(prtstr, " ");       /*  175�������l�ߴګY��(��ĳ)   */
         else
            strcat(prtstr, rtrim(punknown_acc_sug));    /*  175�������l�ߴګY��(��ĳ)   */
       	 strcat(prtstr,"\t");
       	 strcat(prtstr,rtrim(iquery_num_unknown_sug));  /*  176 �������l�I�d�����T�Ǹ�(��ĳ)   */
       	 strcat(prtstr,"\t");
       	 strcat(prtstr,rtrim(aemail_eply));             /*  177   �q�l�O��email   */
       	 strcat(prtstr,"\t");
       	 strcat(prtstr,foccup);                         /*  178   �Q�O�I�H¾�~�O(RBA) add by sylvia 106.08.16 (1060606002_C5) */
         strcat(prtstr,"\t");
         strcat(prtstr,noccup);                         /*  179   �Q�O�I�H¾�~�O�N��(RBA) add by sylvia 106.08.16 (1060606002_C5) */
         strcat(prtstr,"\t");
         strcat(prtstr,applicant_foccup);               /*  180   �n�O�I�H¾�~�O(RBA) add by sylvia 106.08.16 (1060606002_C5) */
         strcat(prtstr,"\t");
         strcat(prtstr,applicant_noccup);               /*  181   �n�O�I�H¾�~�O�N��(RBA) add by sylvia 106.08.16 (1060606002_C5) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(itransno_ori_007));        /*  182   ���O�զX_�@�ȵ����b�� add by sylvia 106.12.18 (1060831012) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(itransno_ori_008));        /*  183   ���O�զX_�ػȵ����b�� add by sylvia 106.12.18 (1060831012) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(itransno_ori_009));        /*  184   ���O�զX_���ȵ����b�� add by sylvia 106.12.18 (1060831012) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(itransno_sug_007));        /*  185   ��ĳ��O�զX_�@�ȵ����b�� add by sylvia 106.12.18 (1060831012) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(itransno_sug_008));        /*  186   ��ĳ��O�զX_�ػȵ����b�� add by sylvia 106.12.18 (1060831012) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(itransno_sug_009));        /*  187   ��ĳ��O�զX_���ȵ����b�� add by sylvia 106.12.18 (1060831012) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(tmobile_appl));            /*  188   �n�O�H������X add by 061476 107.01.24 (1061003004_C1) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(aemail_appl));             /*  189   �n�O�HEmail add by 061476 107.01.24 (1061003004_C1) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(tmobile_eply));            /*  190   �q�l�O����²�T add by 061476 108.06.18 (1080417001_SC3) */
       	 strcat(prtstr,"\t");
       	 strcat(prtstr,rtrim(nsales));                  /*  191   �~�ȭ��m�W add by 061476 108.08.15 (1080725002_SC1) */
       	 strcat(prtstr,"\t");
       	 strcat(prtstr,rtrim(itransno_ori_013));        /*  192   ���O�զX_�@�ص����b�� add by 061476 108.11.19 (1070518005_SC1)  */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(itransno_sug_013));        /*  193   ��ĳ��O�զX_�@�ص����b�� add by 061476 108.11.19 (1070518005_SC1) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(itransno_ori));            /*  194   ���O�զX_ú�ڳ渹(=����Ǹ�) add by 061476 108.11.21 (1070518005_SC1)  */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(itransno_sug));            /*  195   ��ĳ��O�զX_ú�ڳ渹(=����Ǹ�) add by 061476 108.11.21 (1070518005_SC1) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(feterms));                 /*  196   �ȥ��O��u�q�l���ڡv���O add by 061476 110.06.07 (1100419003_SC4) */
         strcat(prtstr,"\t");
         /*strcat(prtstr,rtrim(itoa(qviolate)));*/      /*    ���j�H�W����(GO) add by 071004 (1110608012_SC3) */
         /*strcat(prtstr,"\t");*/
         /*strcat(prtstr,rtrim(sviolate_prem));*/       /*    ���j�H�W�[�O(GP) add by 071004 (1110608012_SC3) */
         /*strcat(prtstr,"\t");*/
         /*strcat(prtstr,rtrim(sdrunk_prem));*/         /*    �s�r�[�O(GQ) add by 071004 (1110608012_SC3) */
         /*strcat(prtstr,"\t");*/
         strcat(prtstr,rtrim(dinstall));                /*  197   �R�q�Φw�˦~�� add by 130956 (1120927002_C05) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(isequence));               /*  198   �R�q�β��~�Ǹ� add by 130956 (1120927002_C05) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(ainstall_zip));            /*  199   �R�q�Φw�˶l���ϸ� add by 130956 (1120927002_C05) */
         strcat(prtstr,"\t");
         strcat(prtstr,rtrim(ainstall));                /*  200   �R�q�Φw�˦a�} add by 130956 (1120927002_C05) */
         strcat(prtstr,"\t");


         /***** 101.05.29�G�s�W�C�L����X���A�����û���b�̥���
         ����O�q���W�C��Q�A�Ƚվ㻡���ϥΡu�ĤT�X�v�G1=>�C�L�H�U�T���F 0=>���C�L�H�U�T��
         ���ϥδ����G2012/08 ~ 2013/07 ����O��
           1.�Z���إN�X��03�B04�B19�B21�B22�̡A��O�q���ѡB��O�q����ΫK�Q�ө�ú�ڳ�һݷs�W�H�U�T���C
           2.�T�����Ĵ�����101/08 ~ 102/07������O��C
           3.�T�������g�b�t�ӳB�G
	   		�������A�ȫ~��A�����q�ۧY��_�T���O�I�O��վ㬰�Z�ŦX�U�C���󤧤@�̡A�Y���ѹD���ϴ��A�ȡG
	   		1.	���N�T���O�I�O�O�F3,000���H�W(���t�j��T���d���O�I�γ�@�T����q�ƬG�r�p�H�ˮ`���[���ګO�O)�F
	   		2.	���N�T���ĤT�H�d���O�I���[�r�p�H�ˮ`�O�I�έ�����˳d�����[���ګO�O�X�p�F1,300���H�W�C
	   		�����q�D���ϴ��A�Ȭ������e�A�H�����q�������i�����e���ǡC
	   		���G���ŦX�W�C���󤧨��D�A�w�ﬢ�ߧ�O�����q<�T���D���ϴ��O�ΫO�I>
         *****/
         control_col[3-1] = '0';
         if (IsPlyB != 'Y'){ /* 102.12.25 B�椣��ܩ�Q�A�ȽհT�� */
             if (ISCAR_SET1(icar_type)){
         	     control_col[3-1] = '1';
         	 }
         }

         /* barcode��B�P�ɭn�L��O�q���Ѫ̡A�q���ѤW�n�L "����w�H�W��ú�O��" �r�� */
         /* �ϥΦC�L����X���u�ĥ|�X�v�G1=>�C�L�H�U�T���F 0=>���C�L�H�U�T���A�C�L��O��q�T�� */
         /* (�ثe�u��2p) */
         control_col[4-1] = '0';
         if (fBarcode_mark=='Y'){
             control_col[4-1] = '1';
         }

         /***( control_col[5-1] �b��O�q����(ca3024q01s.ec)���ϥ� )***/
         /* ���[�L�����種�T��  add by sylvia 104.06.25 (1040624002_C1) */
         /* ���@��(���O115)�T�� (1120316006_SC4) */
         control_col[5-1] = '0';
         if (ISMOT(icar_type) && strcmp(icar_type,"35")!=0){
         	control_col[5-1] = '1';
         }
         if(equip_cmp(sNequipment,"115") == True){
         	count55 = 0;
         	$SELECT count(*) INTO $count55
         	   FROM ply_ins_type_302 a
         	  WHERE a.iins_type = '55'
         	    AND ipolicy = $ipolicy;

         	if (count55 > 0)
         		control_col[5-1] = '2';
         }

         /*1110401005_SC1_������O��W�[�L�s�Ӹ�P�N�ѡA�W�[�P�_�k�H/�۵M�H*/
         /*�n�O�H�ʽ�: 0=>�۵M�H�F1=>�k�H*/
         control_col[6-1] = '0';
         strcpy(fapplicant,trim(fapplicant));
         if(strcmp(fapplicant,"2") == 0 || strcmp(fapplicant,"4") == 0 || strcmp(fapplicant,"6") == 0 )
         {
             control_col[6-1] = '1';
         }


         /* 102.12.25 �M�ץ�  W�g��(�ζ�)�BH�g��(�ζ�)�BH�g��(����) ��������~���I�B�~�N�C�L��m���t��
                      �G���ѲĤC�X���O�ѧP�_�GW�g��(�ζ�)(���O=1)�BH�g��(�ζ�)(���O=2)�BH�g��(����)(���O=3)  */
         control_col[7-1] = '0';
         if (IsPlyB == 'Y')
         {
             if (iofficer[0]=='W')
             {
                 control_col[7-1] = '1';
             }
             else if (iofficer[0]=='H')
             {
             	 if (ibig_branch[0]=='A')
             	 {
             	 	 control_col[7-1] = '2';
             	 }
             	 else if (ibig_branch[0]=='B')
             	 {
             	     control_col[7-1] = '3';
             	 }
             }
             else if (iofficer[0]=='N')
             {
             	 if (ibig_comp[0]=='A')
             	 {
             	 	 control_col[7-1] = '2';
             	 }
             	 else if (ibig_comp[0]=='B')
             	 {
             	     control_col[7-1] = '3';
             	 }
             }
         }

         /* �M�׵��O ��8�X:0:���L 1:�֪@�M�� 2: �䭷�x���I������r*/
         control_col[8-1] = '0';
         /* �����Ȥ��O�䭷�x���I����r��Ѽt�ӦC�L  add by 061476 107.01.05 (1061229001_C1)
             �������z�A�b�䭷�u�`�Y�N���{�e�A��ĳ�z���n����ǳơA�]���z���R�����n���I�W���C�@����H���o�G�䭷ĵ���A�O�I���q�N�Ȱ����z�ӫO�䭷�x���I�A�B�Y�z�����~�[�O�A����������D�I�Ҹ������p���O�O�C */

         count02 = deduct02 = 0;
         $SELECT count(*) INTO $count02
         FROM ply_ins_type_302 a
         WHERE a.iins_type = '02'
         AND ipolicy = $ipolicy ;

         if (count02 == 0)
         {
         	$SELECT count(*) INTO $deduct02
         	FROM ply_ins_type_302 a, insurance_type b
         	WHERE a.iins_type = b.iins_type
         	AND b.fins_grp = '1'
         	AND ipolicy = $ipolicy ;

         	if (deduct02 == 0)
         	{
         		control_col[8-1] = '0';
         	}
         	else if(deduct02 != 0)
         	{
         		control_col[8-1] = '2';
         	}
         }
         else if (count02 != 0)
         {
         	control_col[8-1] = '0';
         }

         /* "�C�L����X���"��9�X: �D���ϴ��O�O�ˮֵ��O:�D���ϴ��O�O����(���O�զX���A130),
             �мt�ө�e���O�զX�`�O�O�f��L�U�C��r ==> ���ŦX�D���ϴ��A�ȧ�O�W�h add by sylvia 104.05.08(1040225002_C1) */
         /* �t�X38�B39��������ӱ���X���O�÷s�W238�I�اP�_ modify by 061476 (1100119001_SC3) */
         control_col[9-1] = '0';

         $SELECT count(*) INTO $count238
            FROM ply_ins_type_302 a
           WHERE a.iins_type = '238'
             AND ori_dam_cover = 0
             AND ipolicy = $ipolicy;

         if (count238 > 0)
         	control_col[9-1] = '1';

         /* "�C�L����X���"��10�X: �����O�J�p���O(frenew_type) 1:�@����O 2:barcode(�e�~) 3:�۰ʥX��&�e�~
             add by sylvia 105.04.28 (1050321006_C2) */
         control_col[10-1] = '0';
         if (strlen(trim(frenew_type)) > 0)
            control_col[10-1] = frenew_type[0];

         /* 105.12.31 ���������I����,�ഫ�s�ӫ~  add by sylvia 105.12.31 */
         /* �t�X�ۥΨ���X�I����,�ק�g�k  modify by sylvia 106.09.26 (1060510003_C3) */
         /* 108.07�_�s�v�I���� modify by 061476 (1080311008_SC3) */
         /* �q�ʨ� (1130510009_C13) */
         control_col[11-1] = '0';
         if ((iissue_ym[0]=='1') || (iissue_ym[0]=='2')||(iissue_ym[0]=='3')){
             control_col[11-1] = iissue_ym[0];
         }
         strcpy(brand_BEV, substring(ibrand,7,2));
         if (strncmp(brand_BEV,"01",2) == 0)
         {
         	$SELECT count(*) INTO $countBEV
         	   FROM ply_ins_type_302 a
         	  WHERE a.iins_type in ('201','205','209','211','231','232','249','331','332','252','253')
         	    AND pre_dam_cover = 0
         	    AND ipolicy = $ipolicy;

         	if (countBEV > 0)
         		control_col[11-1] = '4';
         }
         /* 1: �O�_����(���s+A)�����(���s) add by sylvia 106.04.11 */
         /* 2: �����ҰϽվ���O�զX���O  add by 061476 (1080308004_SC1) 108.03.21 */
         control_col[12-1] = '0';
         if (strcmp(dc_change,"1") == 0)
         {
         	control_col[12-1] = '1';
         }
         if (cnt_chg67 > 0)
         {
         	control_col[12-1] = '2';
         }

         /* ����=03,04,19,22 �B�q���N��<>JB   (���[149�I��DM��) add by sylvia 106.04.17 (1060411008_C1)*/
         control_col[13-1] = '0';
         if (((strcmp(icar_type,"03") == 0) || (strcmp(icar_type,"04") == 0) ||
             (strcmp(icar_type,"19") == 0) || (strcmp(icar_type,"22") == 0)) &&
             (strcmp(iroute,"JB") != 0)) {
                control_col[13-1] = '1';
         }

         /* 106.04.20 ��301�I�ئۭt�B�P�_�C�L����X,�H�Q�t�ӥ[�L�ˮ`�I���O: add by sylvia 106.04.20  (1060329005_C4)
            109.12.25 �W�[�I�ءB�ۭt�B�P�_ modify by 061476 (1091221005_SC1)
            111.04.20 �W�[�I�� modify by 071004 (1110308005_SC3)
            �ۭt�B  ����X
              1       1
              2       2
             155      3
             255      4
              3       5
             355      6               */

         control_col[14-1] = '0';

         if ((fBothIns == 3)||(fBothIns == 2))
         {
            $select nvl(mdeduct,0) into $deduct301
               from ply_ins_type_302
              where ipolicy = $ipolicy and iins_type in ('30','301','302','530');

            if (SQLCODE == SQLNOTFOUND )  deduct301 = 0;

            if (deduct301 == 0)
                control_col[14-1] = '0';
            else if (deduct301 == 1)
                control_col[14-1] = '1';
            else if (deduct301 == 2)
                control_col[14-1] = '2';
            else if (deduct301 == 155)
                control_col[14-1] = '3';
            else if (deduct301 == 255)
                control_col[14-1] = '4';
            else if (deduct301 == 3)
                control_col[14-1] = '5';
            else if (deduct301 == 355)
                control_col[14-1] = '6';
            else
                control_col[14-1] = '0';
         }

         /* "�C�L����X���"��15�X:�w�⥼�I���ڵ��O add by 061476 (1070522004_SC1) */
         control_col[15-1] = '0';

         cnt_payable = 0;
         $SELECT count(*) INTO $cnt_payable
            FROM sysdb:car_renew_msg
           WHERE freason = 'A'
             AND ipolicy = $ipolicy
             AND dply_end between $sdate1 and $sdate2;

         if (cnt_payable > 0)
         {
         	control_col[15-1] = '1';
         }

         /* �W�[65���ˮִ����T�� (1111205007_SC1) */
         control_col[16-1] = '0';
         if (strcmp(fcard_class,"2") == 0)
         {
         	age = 0; age_appl = 0;
            	cm_split_ymd_100(cm_from_infdate_100(dply_begin),yy,mm,dd);
            	$select dpolicy into $ldpolicy
            	   from ply_relation_last
            	  where ipolicy = $ipolicy;

            	if (strlen(trim(dbirth1)) > 0)
            	{
            		cm_split_ymd_100(cm_from_infdate_100(dbirth1),dbirth_yy,dbirth_mm,dbirth_dd);

            		if (atoi(mm) < atoi(dbirth_mm))
            			age = atoi(yy)- atoi(dbirth_yy) - 1;
            		else
            			age = atoi(yy)- atoi(dbirth_yy);

            		if (age < 0)  age = 0;
            		if (strncmp(mm,dbirth_mm,2) == 0)
            		{
            			if (atoi(dbirth_dd) > atoi(dd))
            			{
            				age = age - 1;
            			}
            		}
            	}

            	if (strlen(trim(dbirth_appl)) > 0)
            	{
            		cm_split_ymd_100(cm_from_infdate_100(dbirth_appl),dbirth_appl_yy,dbirth_appl_mm,dbirth_appl_dd);

            		if (atoi(mm) < atoi(dbirth_appl_mm))
            			age_appl = atoi(yy)- atoi(dbirth_appl_yy) - 1;
            		else
            			age_appl = atoi(yy)- atoi(dbirth_appl_yy);

            		if (age_appl < 0)  age_appl = 0;
            		if (strncmp(mm,dbirth_appl_mm,2) == 0)
            		{
            			if (atoi(dbirth_appl_dd) > atoi(dd))
            			{
            				age_appl = age_appl - 1;
            			}
            		}
            	}

            	/* �e��ñ���2022/11/01(44865)����ǧP�_ */
            	if ((ldpolicy < 44865) && (age >= 65 || age_appl >= 65))
            		control_col[16-1] = '1';
            	if ((ldpolicy >= 44865) && (age == 65 || age_appl == 65))
            		control_col[16-1] = '1';
         }

         strcat(prtstr,control_col);            /*  [�̥���] �������(�����û���b�̥���)   */
         strcat(prtstr,"\t");



         /**** �`�N�G���P�ɦ� ca302cq01s.ec �� make_title_file() �s�W��쪺����W�� *****************************/

         /*
         strcat(prtstr, iupdate);  981001,�s�W�J�p�H��id
         strcat(prtstr,"\t");
         */

         /* �� print_chk�C�Ӧr���ӨM�w�O�_���s�Y�q�l��(0:�����s ;1:���s)
         2p: "000000000000000000000000000000"
             print_chk[0]  => tmnewa    ; print_chk[1] => ��W
             print_chk[2]  => �p���p��  ; print_chk[3] => �Τ@�F��
             print_chk[0]='9' => Ū���~�bwhere�ܼƬ����󲣻s�ɮ�
         5p: "000000000000000000000000000000"
             print_chk[0]= => tmnewa    ; print_chk[1] => �έ�  ; ; print_chk[2] => ����
             print_chk[0]='9' => Ū���~�bwhere�ܼƬ����󲣻s�ɮ�        */

         /* ------- ���ե�flag ------- */
         /*printf(" [%s]\n",ipolicy_print);
         printf(" flag_A09[%c][%c][%c][%c]\n",flag_A09,flag_Z,flag_M,flag_T);
         printf(" flag_P[%c][%c][%c][%c]\n",flag_P,flag_G,flag_L,flag_S);
         printf(" flag_Six[%c][%c][%c][%c]\n",flag_Six,flag_Orix,IsPlyB,flag_Jihsun);
         printf(" flag_ES[%c][%c][%c][%c]\n",flag_ES,flag_AVIS,flag_CHAILEASE,flag_B);
         printf(" flag_JB[%c][%c][%c][%c]\n",flag_JB,flag_102,flag_PA,flag_TAXI1);
         printf(" flag_TAXI2[%c][%c][%c][%c]\n",flag_TAXI2,flag_RENT1,flag_RENT2,flag_NEXTBANK);
         printf(" flag_J[%c][%c][%c][%c]\n",flag_J,flag_MOMO,flag_F,flag_PRO);*/

         if (s == 1)
         {  /* �̥~��for�j�� ==> for(s=1;s<=atoi(option);s++) */
             if (flag_A09 == 'Y')
             {
                   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[1]=='1')
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_Z == 'Y')
             {
             	   flag_A09 = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[1]=='1')
                   {
             	       fprintf(fp12,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_M == 'Y')
             {
             	   flag_A09 = 'N';
                   flag_Z   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[2]=='1')
                   {
             	       fprintf(fp14,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_T == 'Y')
             {
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[3]=='1')
                   {
             	       fprintf(fp16,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_P == 'Y')
             {
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[2]=='1')
                   {
             	       fprintf(fp18,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_G == 'Y')
             {
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[3]=='1')
                   {
             	       fprintf(fp20,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_Six == 'Y')
             {
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[4]=='1')
                   {
             	       fprintf(fp26,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(IsPlyB == 'Y')
             {
             	   flag_A09 = 'N';
                   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[5]=='1')
                   {
             	       fprintf(fp8,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_L == 'Y')
             {
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[4]=='1')
                   {
             	       fprintf(fp22,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_S == 'Y')
             {
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[5]=='1')
                   {
             	       fprintf(fp24,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_Orix == 'Y')
             {
                   flag_A09 = 'N';
                   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[6]=='1')
                   {
             	       fprintf(fp28,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_Jihsun == 'Y')
             {
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[7]=='1')
                   {
             	       fprintf(fp30,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_AVIS == 'Y')
             {
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_CHAILEASE = 'N';
                   flag_ES = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[9]=='1')
                   {
             	       fprintf(fp34,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_PA == 'Y')
             {
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[10]=='1')
                   {
             	       fprintf(fp36,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_TAXI1 == 'Y')
             {
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[11]=='1')
                   {
             	       fprintf(fp38,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_RENT1 == 'Y')
             {
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[12]=='1')
                   {
             	       fprintf(fp42,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_TAXI2 == 'Y')
             {
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[6]=='1')
                   {
             	       fprintf(fp40,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_RENT2 == 'Y')
             {
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[7]=='1')
                   {
             	       fprintf(fp44,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_CHAILEASE == 'Y')
             {
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[13]=='1')
                   {
             	       fprintf(fp46,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_B == 'Y')
             {
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[8]=='1')
                   {
             	       fprintf(fp48,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_J == 'Y')
             {
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_B = 'N';
                   flag_CHAILEASE = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[9]=='1')
                   {
             	       fprintf(fp56,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_JB == 'Y')
             {
             	   /* JB�S�����s�B�z (1091210006_SC2) */
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   flag_B   = 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   /* �q��2p ������ (1100820015_SC1)*/
                   /* ���A����u���s������(1110308005_SC3)*/
                   if ((option[0] == '1')&&(print_chk[15]=='1'))
                   {
                       if (flag_JBDelete=='N')
                           fprintf(fp52,"%s\n",prtstr);
                   }

             	   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_NEXTBANK == 'Y')
             {
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   flag_B   = 'N';
                   IsPlyB   = 'N';
                   flag_JB = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if ((print_chk[16]=='1'))
                   {
                       fprintf(fp54,"%s\n",prtstr);
                   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_MOMO == 'Y')
             {
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   flag_B   = 'N';
                   IsPlyB   = 'N';
                   flag_JB = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if ((print_chk[17]=='1'))
                   {
                       fprintf(fp58,"%s\n",prtstr);
                   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_PRO == 'Y')
             {
                   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_CHAILEASE = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';

                   if (print_chk[8]=='1')
                   {
             	       fprintf(fp62,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_ES == 'Y')
             {
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[15]=='2')
                   {
                   	fprintf(fp32,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                        fprintf(fp12,"%s\n",prtstr);
                   }
             } /* ---�W�[�s�����s�ɭn�g�bflag_F��flag_102���e�A�]���i��|�P�ɲŦX��̫�--- */
             else if(flag_F == 'Y')
             {
             	   /* �@�w�n��belse�e���A��L���s�ɫ᭱ */
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   flag_B   = 'N';
                   IsPlyB   = 'N';
                   flag_JB = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_PRO = 'N';

                   if ((print_chk[18]=='1'))
                   {
                       fprintf(fp60,"%s\n",prtstr);
                   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else if(flag_102 == 'Y')
             {
             	   /* �@�w�n��belse�e���A��L���s�ɫ᭱ */
             	   flag_A09 = 'N';
             	   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[14]=='1')
                   {
             	       fprintf(fp50,"%s\n",prtstr);
             	   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             else
             {
                   flag_A09 = 'N';
                   flag_Z   = 'N';
                   flag_M   = 'N';
                   flag_T   = 'N';
                   flag_P   = 'N';
                   flag_G   = 'N';
                   flag_L   = 'N';
                   flag_S   = 'N';
                   flag_Six = 'N';
                   flag_Orix= 'N';
                   IsPlyB   = 'N';
                   flag_Jihsun = 'N';
                   flag_ES = 'N';
                   flag_AVIS = 'N';
                   flag_CHAILEASE = 'N';
                   flag_B = 'N';
                   flag_JB = 'N';
                   flag_102 = 'N';
                   flag_PA = 'N';       /* ����~ */
                   flag_TAXI1 = 'N';    /* �p�{��2P */
                   flag_TAXI2 = 'N';    /* �p�{��5P */
                   flag_RENT1 = 'N';    /* ���2P */
                   flag_RENT2 = 'N';    /* ���5P */
                   flag_NEXTBANK = 'N';
                   flag_J = 'N';
                   flag_MOMO = 'N';
                   flag_F = 'N';
                   flag_PRO = 'N';

                   if (print_chk[0]=='1')
                   {
                       if (option[0] == '2')
                       {
                           /* 5p �D�� */
                           fprintf(fp1,"%s\n",prtstr);
                       }
                       else
                       {
                           /* 2p �D�� */
                           if (flag_no_print == 'N') /* �n���s�n�O�� */
                           {
                               if(flag_RS == 'Y')
                                   fprintf(fp1A,"%s\n",prtstr);     /* �����H�e */
                               else
                          	   fprintf(fp1B,"%s\n",prtstr);     /* �������H�e */
                           }
                           else
                           {
                               fprintf(fp1C,"%s\n",prtstr);    /* �����s�n�O�� */
                           }
                       }
                   }

                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp10,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9'))
                   {
                       fprintf(fp12,"%s\n",prtstr);
                   }
             }
             GiCnt ++;

         }
         else
         {

         }

         if (s == 1)
         {

            $OPEN cv_cur USING $ipolicy;
            for(;;)
            {
               strcpy(iins_scope,' ');
               $FETCH cv_cur
                 INTO $ipolicy,$iins_type,
                      $minjured_cover,$mdeath_cover,$mdamage_cover,$mdeduct,$mprem,$mins_premium,
                      $qcoverage,$pre_inj_cover,$pre_dea_cover,$pre_dam_cover,$pre_deduct,
                      $pre_minsprem,$qserial,$ch_deduct,$linnum,$d_mdiscount,$d_pre_mdiscount,$qday,
                      $mexpense,$mexp_disc,$ori_inj_cover,$ori_dea_cover, $ori_dam_cover,
                      $ori_premium, $iins_class, $ldaily_pay,$pre_daily_pay,$ori_lDaily_pay,$qserial_tmp,
                      $ori_deductx, $iins_scope, $sProvision;
               if (SQLCODE == SQLNOTFOUND) break;

               strcpy(iins_type,trim(iins_type));

               /* �t�X56�I�طs�W��������I���ӫ~ add by sylvia 103.11.19 (1030918003_C4) */
               ldaily_pay_3 = pre_daily_pay_3 = ori_lDaily_pay_3 = 0;  /* ����I�����O�B */
               if ( ((strcmp(iins_type,"56") == 0)||(strcmp(iins_type,"136") == 0)||(strcmp(iins_type,"166") == 0)||(strcmp(iins_type,"266") == 0))
                    && (strcmp(iins_scope,"3") == 0) )
               {
                  ldaily_pay_3 = ldaily_pay;          /* ����I��(��ĳ��O�զX) */
                  pre_daily_pay_3 = pre_daily_pay;    /* ����I��(�e��) */
                  ori_lDaily_pay_3 = ori_lDaily_pay;  /* ����I��(���O�զX) */
                  ldaily_pay = pre_daily_pay = ori_lDaily_pay = 0;   /* ���B�� */
               }

               /* A���ӫ~(118,119,120,121,122,123)
                  118,120,122�O�O:����`�O�O118+119, 120+121, 122+123���`�O�O
                  119,121,123�ۭt�B�ΫO�O: ��0�мt�ӯd��
                  modify by sylvia 103.10.08  ------------------------------------------------------------------------ */
               /* �s�W138+139�I��(�s�A�������IA��)  add by sylvia 104.06.03 (1040515009_C4) */
               /* �����s�A��137.138.139.141.142�I�� (1100311005_SC9) */
               if ((strcmp(iins_type,"118") == 0) || (strcmp(iins_type,"120") == 0) || (strcmp(iins_type,"122") == 0))
               {
                  $select sum(mprem),sum(mins_premium), sum(pre_minsprem),sum(ori_premium)
                     into $mprem,$mins_premium,$pre_minsprem,$ori_premium
                     from ply_ins_type_302
                    where ipolicy = $ipolicy
                      and iins_type in ('118','119','120','121','122','123');
               }
               else if ((strcmp(iins_type,"119") == 0) || (strcmp(iins_type,"121") == 0) || (strcmp(iins_type,"123") == 0))
               {
                  mprem = mins_premium = pre_minsprem = ori_premium = mdeduct = pre_deduct = ori_deductx = 0;
                  strcpy(ch_deduct," ");
               }
               /* A���P�_ end ---------------------------------------------------------------------------- */

               if( qcoverage == 1 ){
               	 if ((strcmp(trim(iins_type),"56") == 0)||(strcmp(trim(iins_type),"136") == 0)||(strcmp(trim(iins_type),"166") == 0)||(strcmp(trim(iins_type),"266") == 0))
               	     /* 950704, 56 �O�B��=1,�����L3�� */
               	     iins_line = 3;
                 else
                     iins_line = 1;
               }
               else if( qcoverage == 2 )
               {
                  iins_line = 3;
               }
               else if( qcoverage == 3 )
               {
                  iins_line = 4;
               }
               else
               {
                  iins_line = 1;
               }

               strcpy(prtstr,"17");
               strcat(prtstr,rtrim(ipolicy_print));/*   01 �O�渹�X   */
               strcat(prtstr,"\t");
               strcat(prtstr,rtrim(iins_type));    /*   02 �I�إN��   */
               strcat(prtstr,"\t");
               rfmtlong(minjured_cover,fmt,xmp);
               strcat(prtstr,trim(xmp));           /*   03 �O�B�@(��) */
               strcat(prtstr,"\t");
               rfmtlong(mdeath_cover,fmt,xmp);
               strcat(prtstr,trim(xmp));           /*   04 �O�B�G(��) */
               strcat(prtstr,"\t");
               rfmtlong(mdamage_cover,fmt,xmp);
               strcat(prtstr,trim(xmp));           /*   05 �O�B�T(��) */
               strcat(prtstr,"\t");
               rfmtlong(mdeduct,fmt,xmp);
               strcat(prtstr,trim(xmp));           /*   06 �ۭt�B   */
               strcat(prtstr,"\t");
               rfmtlong(mprem,fmt,xmp);
               strcat(prtstr,trim(xmp));           /*   07 �O�O�@(��) */
               strcat(prtstr,"\t");
               rfmtlong(mins_premium,fmt,xmp);
               strcat(prtstr,trim(xmp));           /*   08 �O�O�G(��) */
               strcat(prtstr,"\t");
               rfmtlong(qcoverage,fmt,xmp);
               strcat(prtstr,trim(xmp));           /*   09 �O�B�Ӽ�   */
               strcat(prtstr,"\t");
               rfmtlong(pre_inj_cover,fmt,xmp);
               strcat(prtstr,trim(xmp));           /*   10 �e���O�B�@ */
               strcat(prtstr,"\t");
               rfmtlong(pre_dea_cover,fmt,xmp);
               strcat(prtstr,trim(xmp));           /*   11 �e���O�B�G */
               strcat(prtstr,"\t");
               rfmtlong(pre_dam_cover,fmt,xmp);
               strcat(prtstr,trim(xmp));           /*   12 �e���O�B�T */
               strcat(prtstr,"\t");
               rfmtlong(pre_deduct,fmt,xmp);
               strcat(prtstr,trim(xmp));           /*   13 �e���ۭt�B */
               strcat(prtstr,"\t");
               rfmtlong(pre_minsprem,fmt,xmp);
               strcat(prtstr,trim(xmp));           /*   14 �e���O�O   */
               strcat(prtstr,"\t");
               rfmtlong(qserial,fmt,xmp);
               strcat(prtstr,trim(xmp));           /*   15 �C�L����   */
               strcat(prtstr,"\t");
               strcat(prtstr,trim(ch_deduct));     /*   16 �ۭt�B���� */
               strcat(prtstr,"\t");
               strcat(prtstr,trim(itoa(linnum_a))); /*  17 �y����     */
               strcat(prtstr,"\t");
               strcat(prtstr,itoa(d_mdiscount));    /*  18 �������B   */
               strcat(prtstr,"\t");
               strcat(prtstr,itoa(d_pre_mdiscount)); /* 19 �e���������B  */
               strcat(prtstr,"\t");

               if(strcmp(rtrim(iins_type), "238")==0 && qday==999)
                   strcpy(xmp, "����");  /*modify by 071004 (1101229013_SC3_�s�W238�I�ؤ������{�O�v(111/4/1�W�u))*/
               else
                   rfmtlong(qday,fmt,xmp);

               strcat(prtstr,trim(xmp));             /* 20 �N�B���Ѽ�   */
               strcat(prtstr,"\t");

               rfmtlong(mexpense,fmt,xmp);
               strcat(prtstr,trim(xmp));             /* 21 �N�B���O��   */
               strcat(prtstr,"\t");
               rfmtlong(mexp_disc,fmt,xmp);
               strcat(prtstr,trim(xmp));             /* 22 �N�B���u�f���B   */
               strcat(prtstr,"\t");
               rfmtlong(ori_inj_cover,fmt,xmp);
               strcat(prtstr,trim(xmp));             /* 23 ���O�զX�O�B�@(��)   */
               strcat(prtstr,"\t");
               rfmtlong(ori_dea_cover,fmt,xmp);
               strcat(prtstr,trim(xmp));             /* 24 ���O�զX�O�B�G(��)   */
               strcat(prtstr,"\t");
               rfmtlong(ori_dam_cover,fmt,xmp);
               strcat(prtstr,trim(xmp));             /* 25 ���O�զX�O�B�T(��)   */
               strcat(prtstr,"\t");
               rfmtlong(ori_deductx,fmt,xmp);
               strcat(prtstr,trim(xmp));             /* 26 ���O�զX�ۭt�B       */
               strcat(prtstr,"\t");
               rfmtlong(ori_premium,fmt,xmp);
               strcat(prtstr,trim(xmp));             /* 27 ���O�զX�O�I�O(��)   */
               strcat(prtstr,"\t");
               rfmtlong(iins_line,fmt,xmp);
               strcat(prtstr,trim(xmp));             /* 28 �I�ئC�L���   */
               strcat(prtstr,"\t");


               rfmtlong(ldaily_pay,fmt,xmp);
               strcat(prtstr,trim(xmp));             /* 29 ���|�������B�]��ĳ��O�զX�^     */
               strcat(prtstr,"\t");
               rfmtlong(ldaily_pay_3,fmt,xmp);
               strcat(prtstr,trim(xmp));             /* 30 ���|��������I�]��ĳ��O�զX�^ */
               strcat(prtstr,"\t");


               /* 970822,�����ɼW�[�@���Q�O�I�H�W�U */
          	   strcpy(iinsurant_pa, " ");
          	   strcpy(ninsurant_pa, " ");
          	   strcpy(ibirth_pa, " ");
          	   strcpy(nbenif_pa, " ");
          	   strcpy(irel_pa, " ");

/*             101.01.31 �����C�L�W�U

               if (strcmp(trim(iins_type),"56") == 0){
	               $EXECUTE prePa_list INTO $ninsurant_pa, $iinsurant_pa, $ibirth_pa, $nbenif_pa, $irel_pa
	                 USING $ipolicy;
		           if((SQLCODE == SQLNOTFOUND)||(iinsurant_pa[0]==' ')||(iinsurant_pa[0]=='\0')){
		          	   strcpy(ninsurant_pa, " ");
		          	   strcpy(iinsurant_pa, " ");
		          	   strcpy(ibirth_pa, " ");
		          	   strcpy(nbenif_pa, " ");
		          	   strcpy(irel_pa, " ");
		           }else{
	                   cm_split_ymd(ibirth_pa, mm_pa, dd_pa, yyyy_pa);
	                   cy_pa = atoi(yyyy_pa)-1911;
	                   sprintf_s(ibirth_pa,sizeof ibirth_pa,"%d%s%s",cy_pa,mm_pa, dd_pa);
	                   strcpy(ninsurant_pa,rtrim(ninsurant_pa));
	                   strcpy(iinsurant_pa,rtrim(iinsurant_pa));
	                   strcpy(ibirth_pa,rtrim(ibirth_pa));
	                   strcpy(nbenif_pa,rtrim(nbenif_pa));
	                   strcpy(irel_pa,rtrim(irel_pa));
	                   strncpy(iinsurant_pa+(3),"****",4);
		           }
		           printf(" ------- ibirth_pa = [%s]\n " , ibirth_pa);
	           }
*/
               strcat(prtstr,rtrim(ninsurant_pa));   /* 31 �Q�O�I�H�m�W(pa)   */
               strcat(prtstr,"\t");
               strcat(prtstr,rtrim(iinsurant_pa));   /* 32 �Q�O�I�H�����Ҧr�� (pa)  */
               strcat(prtstr,"\t");
               strcat(prtstr,rtrim(ibirth_pa));      /* 33 �Q�O�I�H�ͤ�(pa)   */
               strcat(prtstr,"\t");
               strcat(prtstr,rtrim(nbenif_pa));      /* 34 ���q�H�m�W(pa)  */
               strcat(prtstr,"\t");
               strcat(prtstr,rtrim(irel_pa));        /* 35 �Q�O�I�H�P���q�H���Y(pa)   *  */
               strcat(prtstr,"\t");

               /* 980416 ,56�I�� �������B���O�զX�B�h�~��O�զX*/
               rfmtlong(ori_lDaily_pay,fmt,xmp);
               strcat(prtstr,trim(xmp));             /* 36 ���|�������B�]���O�զX�^   */
               strcat(prtstr,"\t");
               rfmtlong(ori_lDaily_pay_3,fmt,xmp);
               strcat(prtstr,trim(xmp));             /* 37 ���|��������I���]���O�զX�^   */
               strcat(prtstr,"\t");
               rfmtlong(pre_daily_pay,fmt,xmp);
               strcat(prtstr,trim(xmp));             /* 38 ���|�������B�]�e���^ */
               strcat(prtstr,"\t");
               rfmtlong(pre_daily_pay_3,fmt,xmp);
               strcat(prtstr,trim(xmp));             /* 39 ���|��������I���]�e���^ */
               strcat(prtstr,"\t");
               strcat(prtstr,trim(sProvision));      /* 40 �I�ت��[���� add by sylvia 104.11.27 (1021211003_C1) */
               strcat(prtstr,"\t");

               strcpy(nins_scope," ");
               if (strcmp(iins_type,"35") == 0)
               {
               	   if (strcmp(iins_scope,"1") == 0)
               	       strcpy(nins_scope,"�O�W��");
               	   else if (strcmp(iins_scope,"2") == 0)
               	       strcpy(nins_scope,"�a�x��");
               }
               strcat(prtstr,trim(nins_scope));      /* 41 �ӫO�d��(pa) add by 061476 109.02.18 (1090106011_SC2) */
               strcat(prtstr,"\t");


	           /* �� print_chk�C�Ӧr���ӨM�w�O�_���s�Y�q�l��(0:�����s ;1:���s)
	           2p: "000000000000000000000000000000"
	               print_chk[0]  => tmnewa    ; print_chk[1] => ��W
	               print_chk[2]  => �p���p��  ; print_chk[3] => �Τ@�F��
	               print_chk[0]='9' => Ū���~�bwhere�ܼƬ����󲣻s�ɮ�
	           5p: "000000000000000000000000000000"
	               print_chk[0]= => tmnewa    ; print_chk[1] => �έ�
	               print_chk[0]='9' => Ū���~�bwhere�ܼƬ����󲣻s�ɮ�        */

               if(flag_A09 == 'Y' ){
               	   if (print_chk[1]=='1'){
                      fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_P == 'Y'){
               	   if (print_chk[2]=='1'){
               	      fprintf(fp19,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_G == 'Y'){

               	   if (print_chk[3]=='1'){
               	      fprintf(fp21,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_Six == 'Y'){
               	   if (print_chk[4]=='1'){
               	      fprintf(fp27,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
              }else if(IsPlyB == 'Y'){
               	   if (print_chk[5]=='1'){
               	      fprintf(fp9,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_Z == 'Y'){
               	   if (print_chk[1]=='1'){
               	      fprintf(fp13,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_M == 'Y'){
               	   if (print_chk[2]=='1'){
               	      fprintf(fp15,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_T == 'Y'){
               	   if (print_chk[3]=='1'){
               	      fprintf(fp17,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_L == 'Y'){
               	   if (print_chk[4]=='1'){
               	      fprintf(fp23,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_S == 'Y'){
               	   if (print_chk[5]=='1'){
               	      fprintf(fp25,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_Orix == 'Y'){
               	   if (print_chk[6]=='1'){
               	      fprintf(fp29,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_Jihsun == 'Y'){
               	   if (print_chk[7]=='1'){
               	      fprintf(fp31,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_PRO == 'Y'){
               	   if (print_chk[8]=='1'){
               	      fprintf(fp63,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_AVIS == 'Y'){
               	   if (print_chk[9]=='1'){
               	      fprintf(fp35,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_PA == 'Y'){
               	   if (print_chk[10]=='1'){
               	      fprintf(fp37,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_TAXI1 == 'Y'){
               	   if (print_chk[11]=='1'){
               	      fprintf(fp39,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_TAXI2 == 'Y'){
               	   if (print_chk[6]=='1'){
               	      fprintf(fp41,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_RENT1 == 'Y'){
               	   if (print_chk[12]=='1'){
               	      fprintf(fp43,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_RENT2 == 'Y'){
               	   if (print_chk[7]=='1'){
               	      fprintf(fp45,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_CHAILEASE == 'Y'){
               	   if (print_chk[13]=='1'){
               	      fprintf(fp47,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_B == 'Y'){
               	   if (print_chk[8]=='1'){
               	      fprintf(fp49,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_J == 'Y'){
               	   if (print_chk[9]=='1'){
               	      fprintf(fp57,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_JB == 'Y'){
               	   /* JB�S�����s�B�z (1091210006_SC2) */
               	   /* �q��2p ������ (1100820015_SC1)*/
                   if ((option[0] == '1')&&(print_chk[15]=='1')){
                   	if (flag_JBDelete=='N')
                   	    fprintf(fp53,"%s\n",prtstr);
                   }
               	   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_NEXTBANK == 'Y'){
               	   if (print_chk[16]=='1'){
               	          fprintf(fp55,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_MOMO == 'Y'){
               	   if (print_chk[17]=='1'){
               	          fprintf(fp59,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_F == 'Y'){
               	   if (print_chk[18]=='1'){
               	          fprintf(fp61,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_102 == 'Y'){
               	   if (print_chk[14]=='1'){
               	      fprintf(fp51,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else if(flag_ES == 'Y'){
               	   if (print_chk[15]=='2'){
               	   	fprintf(fp33,"%s\n",prtstr);
               	   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }else{
               	   if (print_chk[0]=='1')
               	   {
               	      if(option[0] == '2')
               	      {
               	            /* 5p������ */
               	            fprintf(fp2,"%s\n",prtstr);
               	      }
               	      else
               	      {
               	      	/* 2p������ */
               	      	if (flag_no_print == 'N') /* �n���s�n�O�� */
               	      	{
               	      	    if(flag_RS == 'Y')
                                fprintf(fp2A,"%s\n",prtstr);     /* �����H�e */
                            else
                                fprintf(fp2B,"%s\n",prtstr);     /* �������H�e */
                        }
                        else
                        {
                            fprintf(fp2C,"%s\n",prtstr);    /* �����s�n�O�� */
                        }
                      }
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '2')&&(print_chk[0]=='9')){
                  	  fprintf(fp11,"%s\n",prtstr);
                   }
                   /* �~�bWhere���� */
                   if ((option[0] == '1')&&(print_chk[0]=='9')){
                  	  fprintf(fp13,"%s\n",prtstr);
                   }
               }
            }
            $CLOSE cv_cur;

         } /* END fprintf ply_ins_type_302   */

     }
     $CLOSE CA302_ply_3021;
     $FREE CA302_ply_3021;

  }/* end s for */

  if (option[0] == '2')
  {
      /*fclose(fp0);*/
      if (print_chk[0]=='1'){
         fclose(fp1); /* Tmnewa 5p */
         fclose(fp2); /* Tmnewa 5p */
      }

      if (print_chk[1]=='1'){
	      fclose(fp10); /* �έ� A09 */
	      fclose(fp11); /* �έ� A09 */
      }
      if (print_chk[2]=='1'){
	      fclose(fp18); /* ���� */
	      fclose(fp19); /* ���� */
      }
      if (print_chk[3]=='1'){
	      fclose(fp20); /* ���W */
	      fclose(fp21); /* ���W */
      }
      if (print_chk[4]=='1'){
	      fclose(fp26); /* ���M */
	      fclose(fp27); /* ���M */
      }
      if (print_chk[5]=='1'){
	      fclose(fp8); /* ���M */
	      fclose(fp9); /* ���M */
      }
      if ((print_chk[6]=='1') && (chk_PA > 0)){
	      fclose(fp40); /* �p�{��5p */
	      fclose(fp41); /* �p�{��5p */
      }
      if ((print_chk[7]=='1') && (chk_PA > 0)){
	      fclose(fp44); /* ���5p */
	      fclose(fp45); /* ���5p */
      }
      if (print_chk[8]=='1'){
	      fclose(fp48); /* ����2p */
	      fclose(fp49); /* ����2p */
      }
      if (print_chk[9]=='1'){
	      fclose(fp56); /* ���q2p */
	      fclose(fp57); /* ���q2p */
      }
      if (print_chk[0]=='9'){
	      fclose(fp10); /* �~�bWhere���� */
	      fclose(fp11); /* �~�bWhere���� */
      }
  }
  else
  {

      if (print_chk[0]=='1'){
          fclose(fp1A);  /* Tmnewa 2p */ /* �����H�e */
          fclose(fp1B);  /* Tmnewa 2p */ /* �������H�e */
          fclose(fp1C);  /* Tmnewa 2p */ /* �����s */
          fclose(fp2A);  /* Tmnewa 2p */ /* �����H�e */
          fclose(fp2B);  /* Tmnewa 2p */ /* �������H�e */
          fclose(fp2C);  /* Tmnewa 2p */ /* �����s */
      }
      if (print_chk[1]=='1'){
          fclose(fp12); /* ��W 2p   */
          fclose(fp13); /* ��W 2p   */
      }
      if (print_chk[2]=='1'){
          fclose(fp14); /* �p���p�� 2p   */
          fclose(fp15); /* �p���p�� 2p   */
      }
      if (print_chk[3]=='1'){
          fclose(fp16); /* �Τ@�F�� 2p   */
          fclose(fp17); /* �Τ@�F�� 2p   */
      }
      if (print_chk[4]=='1'){
          fclose(fp22); /* �p����� 2p   */
          fclose(fp23); /* �p����� 2p   */
      }
      if (print_chk[5]=='1'){
          fclose(fp24); /* ��s�T�� 2p   */
          fclose(fp25); /* ��s�T�� 2p   */
      }
      if (print_chk[6]=='1'){
          fclose(fp28); /* �ڤO�h�T�� 2p   */
          fclose(fp29); /* �ڤO�h�T�� 2p   */
      }
      if (print_chk[7]=='1'){
          fclose(fp30); /* �鲱���x�q 2p   */
          fclose(fp31); /* �鲱���x�q 2p   */
      }
      if (print_chk[8]=='1'){
          fclose(fp62); /* ��ù�T�� 2p   */
          fclose(fp63); /* ��ù�T�� 2p   */
      }
      if (print_chk[9]=='1'){
          fclose(fp34); /* �w���� 2p   */
          fclose(fp35); /* �w���� 2p   */
      }
      if (print_chk[13]=='1'){
          fclose(fp46); /* �����}�M 2p   */
          fclose(fp47); /* �����}�M 2p   */
      }
      if (print_chk[14]=='1'){
          fclose(fp50); /* �S�����O 2p   */
          fclose(fp51); /* �S�����O 2p   */
      }
      if (print_chk[15]=='1'){
          fclose(fp52); /* �q�� 2p   */
          fclose(fp53); /* �q�� 2p   */
      }
      if (print_chk[16]=='1'){
          fclose(fp54); /* �N�ӻȦ� 2p   */
          fclose(fp55); /* �N�ӻȦ� 2p   */
      }
      if (print_chk[17]=='1'){
          fclose(fp58); /* �I�� 2p   */
          fclose(fp59); /* �I�� 2p   */
      }
      if (print_chk[18]=='1'){
          fclose(fp60); /* F���� 2p   */
          fclose(fp61); /* F���� 2p   */
      }
      if (print_chk[15]=='2'){
      	  fclose(fp32); /* �R�q�� 2p   */
      	  fclose(fp33); /* �R�q�� 2p   */
      }
      if (chk_PA > 0)
      {

          if (print_chk[10]=='1'){
              fclose(fp36); /* ��L����~(�T��) 2p   */
              fclose(fp37); /* ��L����~(�T��) 2p   */
          }

          if (print_chk[11]=='1'){
              fclose(fp38); /* �p�{�� 2p   */
              fclose(fp39); /* �p�{�� 2p   */
          }

          if (print_chk[12]=='1'){
              fclose(fp42); /* ��� 2p   */
              fclose(fp43); /* ��� 2p   */
          }

      }
      if (print_chk[0]=='9'){
	       fclose(fp12); /* �~�bWhere���� */
	       fclose(fp13); /* �~�bWhere���� */
      }
  }


  $drop table iins_class;
  $drop table tp_claim;
  free(ca_unsend);

  return 1;

errexit:
/* reset error handling */
/*    $WHENEVER SQLERROR CONTINUE;  */
    printf("----- p32_print_1 FALSE : SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}


char *sLastChinese(sStrTmp,iStrLen)
char *sStrTmp;
int  iStrLen;
{
int  iTrueLen;
int  i,x;


     iTrueLen = strlen(rtrim(sStrTmp));

     if (iStrLen > iTrueLen) return sStrTmp;
     sStrTmp[iStrLen] = '\0';

     for(i = 0; i< iStrLen; i++){
         if ((int)(sStrTmp[i]) >= 128){
                x = i;
                i++;
         }
     }

     if ((iStrLen - 1) == x) {
          sStrTmp[x] = '\0';
     }

     return sStrTmp;


}

double dbl_len8(fulldbl)
double fulldbl;
{
     int chk_flag;
     if (fulldbl < 0)
          chk_flag = 1;
     else
          chk_flag = 0;

     fulldbl = fabs(fulldbl);

     fulldbl = (floor(fulldbl*pow(10,8)))/pow(10,8);

     if (chk_flag == 1)
         return -1 * fulldbl;
     else
         return fulldbl;
}
/* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
double d45(num,num1)
double num;
int num1;
{
    long tmplong;
    double var1;
    double ten;
    int i;

    ten = 1;
    for(i = 1 ;i<=num1;i++)
    ten *= 10;

    num *= ten;

    /* �|�ˤ��J+0.5 �אּ +0.500000000001 modify by sylvia 106.02.02 (1060126001_C3) */
    if (num >= 0) var1 = 0.500000000001;
    else var1 = (-0.500000000001);

    num = num + var1;
    tmplong = num;

    num = tmplong/ten;
    return(num);
}
/* 103.02.05 �]���s�r�[�O, �s�W�Ѽ�
	 1:�ǤJ��:drunk_driving (�s�r�H�W����)�Bqviolate(���j�H�W����)
	 2:�^�ǭ�:pdrunk_prem (�s�r�[�O)�Bpdrunk_pure_prem(�s�r�«O�O)�Bmviolate_prem(���j�H�W�[�O)�Bmviolate_pure_prem(���j�H�W�«O�O)  */
int Get_comp_prem_302(b_car_type,ppremium,p_plia_acc,comp_prem,q_qply_period,userid,q_drunk_driving,qviolate,pdrunk_prem,pdrunk_pure_prem,mviolate_prem,mviolate_pure_prem)
char       b_car_type[3];
long       *ppremium;
double     p_plia_acc;
int        q_qply_period;      /* �h�~�O�� */
$struct    comp_prem_t *comp_prem;
char       userid[11];
int        q_drunk_driving;
$long      *pdrunk_prem;
$double    *pdrunk_pure_prem;
int        qviolate;
$long      *mviolate_prem;
$double    *mviolate_pure_prem;
{
    $char  cartype[3];
    $double lSy_prem1_bef;
    $double dblSy_mbusiness;
    $double mready,mcompensation,mstable,madjcom_prem;
    $double lSecondYear_prem;
    $double pinterest;
    $double mresearch,pcapital, dpremium, maintain,dbl_ppremium,psex_age21;

    $long   chk_count;
    $int    cnt_n47;
    int     find_flag;
    $int    iDrunk_prem;   /* �j���I�榸�s�r�[�O���B */
    $int    iViolate_prem; /* �j���I�榸���j�H�W�[�O���B */

    $WHENEVER SQLERROR GOTO errexit;

    #ifdef PRINTF_FLAG
    printf("######### Get_comp_prem_302 \n");
    #endif

    lSy_prem1_bef = 0;
    dblSy_mbusiness = 0;
    mresearch = 0;
    pcapital = 0;
    psex_age21 = 0.0;
    iDrunk_prem = 0;
    iViolate_prem = 0;
    *pdrunk_prem = 0;
    *pdrunk_pure_prem = 0.0;
    *mviolate_prem = 0;
    *mviolate_pure_prem = 0.0;
    mbus_rule = 0.0;    /* �W���~�ȶO�� add by sylvia 104.04.22 */

    strcpy(cartype,b_car_type);

    if ( strncmp(b_car_type,"22",2) == 0)
    {
        if ( (assuredf[0] == '2') || (assuredf[0] == '4') || (assuredf[0] == '6'))
           strcpy(fassured_comp,"2");
        else
           strcpy(fassured_comp,"1");
    }else{
    	strcpy(fassured_comp," ");
    }


    if (*fuse_type=='1')
    { /*�ȳf���*/
    	 /* fcar_note => �e�ݤw�g�S�b�� */
         if(strcmp(fcar_note,"98")==0)
                 strcpy(cartype,"04");
         else if(strcmp(fcar_note,"99")==0)
                 strcpy(cartype,"03");
    }

    strcpy(cartype, trim(cartype));
    strcpy(frate,   trim(frate));


    if (!ISMOT(cartype))
    {
         #ifdef PRINTF_FLAG
         printf("qpt[%f]\n",qpt);
         printf("frate[%s]\n",frate);
         #endif

         find_flag = 0;

         for (chk_count=0 ; chk_count<max_comp_prem ; chk_count++)
         {

              if ((strcmp(comp_prem[chk_count].icar_type, cartype) == 0) &&
                  (comp_prem[chk_count].qperiod == 12)  &&
                  (((comp_prem[chk_count].qcar_personbgn <= qpt) &&
                    (comp_prem[chk_count].qcar_personend >= qpt)) ||
                   (comp_prem[chk_count].qcar_personbgn == 0))  &&
                  (strcmp(comp_prem[chk_count].frate,frate) == 0)&&
                  (comp_prem[chk_count].fassured[0]== fassured_comp[0]))
              {
                   premium1_bef = comp_prem[chk_count].mpremium;
                   comprem1     = comp_prem[chk_count].mbusiness;
                   readyrate    = comp_prem[chk_count].pready_rate;
                   comprate     = comp_prem[chk_count].pcomprate;
                   stablerate   = comp_prem[chk_count].pstablerate;
                   investrate   = comp_prem[chk_count].pinvestrate;
                   mresearch    = comp_prem[chk_count].mresearch;
                   maintain     = comp_prem[chk_count].maintain;
                   pcapital     = comp_prem[chk_count].pcapital;
                   iDrunk_prem  = comp_prem[chk_count].mdrunk_prem;
                   iViolate_prem= comp_prem[chk_count].mviolate_prem;

                   mbus_rule = comprem1;
                   find_flag = 1;
                   break;
              }

         }

         if (find_flag == 0)
         {
                *ppremium    = 0;
         }
         else
         {

                readyrate  = readyrate/100.0;
                comprate   = comprate/100.0;
                stablerate = stablerate/100.0;
                investrate = investrate/100.0;
                pcapital   = pcapital/100;

		/* �s�r�[�O = �榸�s�r�[�O���B * �s�r���� */
		*pdrunk_prem = iDrunk_prem * q_drunk_driving;

		/* �s�r�«O�O = �s�r�[�O * (1-�S�O���v���-�w�w���) */
		*pdrunk_pure_prem = d45( *pdrunk_prem * (1 - comprate - stablerate), 2);

		/* ���j�H�W�[�O = �榸���j�H�W�[�O���B * ���j�H�W���� */
		*mviolate_prem = iViolate_prem * qviolate;

		/* ���j�H�W�«O�O = ���j�H�W�[�O * (1-�S�O���v���-�w�w���) */
		*mviolate_pure_prem = d45( *mviolate_prem * (1 - comprate - stablerate), 4);


                #ifdef PRINTF_FLAG
                printf("1�~��:pdrunk_prem=[%ld] pdrunk_pure_prem=[%f]\n",*pdrunk_prem,*pdrunk_pure_prem);
                printf("1�~��:mviolate_prem=[%ld] mviolate_pure_prem=[%f]\n",*mviolate_prem,*mviolate_pure_prem);
                printf("Get_comp_prem---assuredf[%s],car_type[%s]\n",assuredf,cartype);
                #endif

	        /** �p��W��[�k�w]�O�I�O **/
	        if ((fcar_class[0]=='1') &&
	            (assuredf[0]=='1' || assuredf[0]=='3' || assuredf[0]=='5') &&
	            (strcmp(cartype,"03")==0 || strcmp(cartype,"04")==0 || strcmp(cartype,"22")==0))
	        {
	            /* ����03,04,22�۵M�Hpsex_age1�̶ǤJ�� */
	            psex_age21 = psex_age1;
	        }
	        else
	        {
	            psex_age21 = 1.0;
	        }

		/* 103.02.05 �s�r�t�X�s�r�[�O,�ק�O�O�p�⤽�� */
		/* �`�O�O=Round( [(�վ��«O�O + �~�ȶO�� + ����o�O + �إ��O�I���O�� ) /
                    ( 1 - �ǳƪ����s�v - ���v�������v - �w�w��������v - ��������v + ��ꦬ�q�v )]+�s�r�[�O,0) */
            	/* 961225, 9703�j���I�����ܧ�: [premium1_bef*(psex_age21+p_plia_acc)]�����|�ˤ��J��p�ƲĤG�� */
            	/* 981208, 9903�_�j���I�վ��«O�O [premium1_bef*(psex_age21+p_plia_acc)]���A�|�ˤ��J��p�ƲĤG�� */
            	/*         (�ثe�O�v�ɱj��«O�Opremium1_bef�����K�O�]�w�ܤp��2��, �G�|�ˤ��J�ܤp�ƲĤG��ثe���v�T�O�O )*/

                *ppremium=d45((((d45(premium1_bef,2)*(psex_age21+p_plia_acc)+comprem1+mresearch+maintain)/
                              (1-readyrate-comprate-stablerate-pcapital+investrate)) + *pdrunk_prem + *mviolate_prem),0);

                #ifdef PRINTF_FLAG
                printf("premium1_bef[%f]\n",premium1_bef);
                printf("psex_age21[%f]\n",psex_age21);
                printf("p_plia_acc[%f]\n",p_plia_acc);
                printf("comprem1[%f]\n",comprem1);
                printf("Get_comp_prem compulsory_premium_2[%d]\n",*ppremium);
                #endif
         }
    }
    else
    {

    	 if(strcmp(cartype,"35") != 0)
    	 {

    	     /*01.02.32.34����*/
             find_flag = 0;

             for (chk_count=0 ; chk_count<max_comp_prem ; chk_count++)
             {
                  if ((strcmp(comp_prem[chk_count].icar_type, cartype) == 0) &&
                      (comp_prem[chk_count].qperiod == 12)  &&
                      (((comp_prem[chk_count].qcar_personbgn <= qpt) &&
                        (comp_prem[chk_count].qcar_personend >= qpt)) ||
                       (comp_prem[chk_count].qcar_personbgn == 0))  &&
                      (strcmp(comp_prem[chk_count].frate,frate) == 0)&&
                      (comp_prem[chk_count].fassured[0]== fassured_comp[0]))
                  {
                       premium1_bef = comp_prem[chk_count].mpremium;
                       readyrate    = comp_prem[chk_count].pready_rate;
                       comprate     = comp_prem[chk_count].pcomprate;
                       stablerate   = comp_prem[chk_count].pstablerate;
                       investrate   = comp_prem[chk_count].pinvestrate;
                       mbusiness    = comp_prem[chk_count].mbusiness;
                       mresearch    = comp_prem[chk_count].mresearch;
                       maintain     = comp_prem[chk_count].maintain;
                       pcapital     = comp_prem[chk_count].pcapital;

                       mbus_rule = mbusiness;
                       find_flag = 1;
                       break;
                  }

             }
             printf("Trace -- Get_comp_prem_302 MOT find_flag = [%d] \n",  find_flag);
             if (find_flag == 0)
                  *ppremium = 0;
             else
             {
                  readyrate/=100.0;
                  comprate/=100.0;
                  stablerate/=100.0;
                  investrate/=100.0;
                  pcapital/=100.0;
                  /* �j���I�����ܧ�: [premium1_bef*(psex_age+p_plia_acc)]�����|�ˤ��J��p�ƲĤG�� */
                  /* �����I�����ק�(�򥻯«O�Opremium1_bef�쥻�N�w�|�ˤ��J��p�ƲĤG��)*/

                  dpremium = d45( ((d45(premium1_bef,2)+mbusiness+mresearch+maintain) /
                                (1-readyrate-comprate-stablerate-pcapital+investrate)),0 );
                  *ppremium = dpremium;


                  #ifdef PRINTF_FLAG
                  printf("first year *ppremium=[%ld]\n", *ppremium );
                  #endif

                  if (q_qply_period == 24)
                  {
                       /*�p��ĤG�~�j������O�O*/
                       $SELECT mpremium,pready_rate,pcomprate,pstablerate,
                               pinvestrate,mbusiness,pinterest,maintain
                          INTO $lSy_prem1_bef, $readyrate, $comprate, $stablerate,
                               $investrate, $dblSy_mbusiness, $pinterest, $maintain
                          FROM compulsory_premium
                         WHERE icar_type=$cartype
                           AND qperiod=24
                           AND ((qcar_personbgn <= $qpt AND qcar_personend >= $qpt)
                                OR (qcar_personbgn=0))
                           AND fassured= $fassured_comp
                           AND drate=(SELECT drate FROM ca_rate_date
                                   WHERE icode=$frate
                                     AND itable='compulsory_premium');
                       if (NOT_FOUND)
                            *ppremium = 0;
                       else
                       {
                            readyrate/=100.0;
                            comprate/=100.0;
                            stablerate/=100.0;
                            investrate/=100.0;
                            pinterest/=100.0; /* ��{�v */

                            #ifdef PRINTF_FLAG
                            printf("lSy_prem1_bef=[%f] dblSy_mbusiness=[%f]\n",lSy_prem1_bef, dblSy_mbusiness);
                            printf("maintain=[%f] readyrate=[%f]\n",  maintain ,readyrate);
                            printf("comprate=[%f] stablerate=[%f]\n",  comprate ,stablerate);
                            printf("pcapital=[%f] investrate=[%f]\n",  pcapital ,investrate);
                            printf("pinterest=[%f] \n",  pinterest );
                            printf("d45(1/(1+pinterest),5)=[%f] \n",  d45(1/(1+pinterest),5) );
                            #endif


                            mbus_rule = mbus_rule+dblSy_mbusiness;

                            lSecondYear_prem = (d45(lSy_prem1_bef,2)+dblSy_mbusiness+maintain)/
                                                (1-readyrate-comprate-stablerate-pcapital+investrate)*
                                                d45(1/(1+pinterest),5);
                            #ifdef PRINTF_FLAG
                            printf("Second lSecondYear_prem=[%f]\n", lSecondYear_prem );
                            #endif

                            *ppremium = (long)(d45((dpremium + lSecondYear_prem), 0));

                       }
                  }
             }

             #ifdef PRINTF_FLAG
             printf("*ppremium=[%d]\n", *ppremium );
             #endif
    	 }
    	 else if (strcmp(cartype,"35") == 0)
         {
             /*35����*/
             /*�@�ߥH�@�~���J�p*/
             /*add by 071004 (1110718002_SC3_�s�W�L���q�ʤG����)*/
             find_flag = 0;

             for (chk_count=0 ; chk_count<max_comp_prem ; chk_count++)
             {
                  if ((strcmp(comp_prem[chk_count].icar_type, cartype) == 0) &&
                      (comp_prem[chk_count].qperiod == 12)  &&
                      (strcmp(comp_prem[chk_count].frate,frate) == 0))
                  {
                       premium1_bef = comp_prem[chk_count].mpremium;
                       readyrate    = comp_prem[chk_count].pready_rate;
                       comprate     = comp_prem[chk_count].pcomprate;
                       stablerate   = comp_prem[chk_count].pstablerate;
                       investrate   = comp_prem[chk_count].pinvestrate;
                       mbusiness    = comp_prem[chk_count].mbusiness;
                       mresearch    = comp_prem[chk_count].mresearch;
                       maintain     = comp_prem[chk_count].maintain;
                       pcapital     = comp_prem[chk_count].pcapital;

                       mbus_rule = mbusiness;
                       find_flag = 1;
                       break;
                  }

             }
             printf("Trace -- Get_comp_prem_302 MOT find_flag = [%d] \n",  find_flag);
             if (find_flag == 0)
                  *ppremium = 0;
             else
             {
                  readyrate/=100.0;
                  comprate/=100.0;
                  stablerate/=100.0;
                  investrate/=100.0;
                  pcapital/=100.0;


                  dpremium = d45( ((d45(premium1_bef,2)+mbusiness+mresearch+maintain) /
                                (1-comprate-stablerate)),0 );
                  *ppremium = dpremium;


             }

             #ifdef PRINTF_FLAG
             printf("*ppremium=[%d]\n", *ppremium );
             #endif

         }




    }
    printf("Trace -- before SUCCESS\n");
    return SUCCESS;

errexit:
    printf(" Get_comp_prem_302() error: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* ����O�J�p�@�~(CAR302)�p��O�O�ϥ� */
int Cal_ins_prem_302(INS_ptr,ictype,mode,wk_date,INS_ptr_33,
                     cover_vs_prem, ca_rate,
                     min_car_factor,
                     car_model_factor, ca_sex_age_factor,
                     ca_car_model, insurance_type,userid)
struct INS_TYPE *INS_ptr;
struct INS_TYPE_33 *INS_ptr_33;
$struct cover_vs_prem_t *cover_vs_prem;
$struct ca_rate_t *ca_rate;
$struct min_car_factor_t     *min_car_factor;
$struct car_model_factor_t   *car_model_factor;
$struct ca_sex_age_factor_t  *ca_sex_age_factor;
$struct ca_car_model_t       *ca_car_model;
$struct insurance_type_t     *insurance_type;
int    ictype, mode;

$long  wk_date;
{
    int     code, flag_car, flag_dam, flag_person;
    $char   fcal_way[2], fins_grp[2], ical_ins[INSURANCE_TYPE], isame_ins[INSURANCE_TYPE], fcal_class[2];
    long    org_ins_premium;
    $char   icar_series[3],car_series[2];
    $char   sstmt[9000];
    $long   next_cover1,next_cover2,next_cover3;

    $char   sIpyear[5];
    $double wk_qpt;

    $long   cal_prem;
    $char   ssdb[3];

    $char   tmp_ipoy[21];

    $long   prem_47_2; /** 47�I�زĤG�~�`�O�O **/
    $char   iins_scope_tmp[2], icareer_tmp[2];
    $long   lMins_amt_33;
    $long   lDaily_pay_33;
    $double prate_icareer, prate_add_med;
    $double prate_dailypay, cal_mr_pure_prem, msi_premium,plia_acc_ori;

    $long   LngMexpensePrem;    /* ���[�N�B��ñ��O�O */
    $long   LngMexpensePremOri; /* ���[�N�B���W���O�O */
    $long   LngMexpenseDisc;    /* ���[�N�B���u�f�O�O */
    $long   LngQday;

    $long   chk_count;
    int     find_flag;
    int     cover_time;

    $char   frate_chk[4], f_30_change, str_deduct[10],sIns[7];;
    double  lChk_12_prem;
    $double provision_C = 1.0;
    $double provision_P = 1.0;  /* P�BQ���� (1071226006_SC3) */
    $double provision_Q = 1.0;
    $double provision_M = 1.0;  /* (1081105005_SC3) */
    $double provision_K = 1.0;  /* (1080408008_SC3) */
    $double provision_L = 1.0;  /* (1080708002_SC3) */
    $double provision_H = 1.0;  /* (1110308005_SC3) */
    $double provision_Y = 1.0;  /* (1130827011_C03) */

    $double pmequipment_rate = 0.0;
    $char   fcar_class_tmp[2];

    $double ins_premium1,ins_premium2,bef_ins_premium1, bef_ins_premium2;
    $int    iCar_age;     /* 38,39 �I�بϥΡ@*/
    $char   pro_ymd[11];  /* 238�I�بϥ� */
    $long   lpro_ymd;     /* 238�I�بϥ� */
    $long   mcover1_32_ori, mcover1_32_sug, mcover1_32;	 /* 101.11,�x�s32�I�ثO�B,����29�I�حp��� */
    $int    iCount = 0;
    $double insmpurm_109_ori,insmpurm_109_sug;   /* 31�I�د«O�O��109�I�حp��ϥ� add by sylvia 103.05.15 */
    $long   mcover1_109_ori,mcover3_109_ori, mcover1_109_sug,mcover3_109_sug,base_mcover;/* 31�I�ثO�B��109�I�ط��O�B1�p��O�O�ϥ� add by sylvia 103.05.15 */
    double  adjn_47;    /* 47�I�ثO�O�p��վ�� */
    $long   mcover1_124;
    $int    mdeduct_124;
    $int    deduct_113,deduct_113_sec,deduct_30,deduct_30_sec;
    $double dbl_psex_age=1.0; /*(1091103004_SC1)*/
    $char   tmp_provision[22];

    $WHENEVER SQLERROR GOTO errexit;

    #ifdef PRINTF_FLAG
    printf("INTO Cal_ins_prem_302()\n");
    printf("111 fcomp_24[%s]\n",fcomp_24);
    printf("Trace1 -- plia_acc = [%f] \n",  plia_acc);
    #endif

    mdmg_prem     = mlia_prem       = 0;
    mdmg_discount = mlia_discount   = 0;
    mdmg_agent    = mdmg_commission = 0;
    mlia_agent    = mlia_commission = 0;

    damage_cover_01 = 0;
    flag_car        = 0;
    mpremium_sec    = 0;

    premium_10       = 0;
    premium_10_sug   = 0;
    premium_10_ori   = 0;
    premium_3132_ori = 0;
    premium_3132_sug = 0;
    purprem10_ori = purprem10_sug = purprem10 = purprem17 = 0.0;
    provision10_P = provision10_Q = provision10_M = provision10_K = provision10_H = provision10_Y = 1.0;
    provision17_P = provision17_Q = provision17_M = 1.0;

    mcover1_32_ori = 0; mcover1_32_sug = 0; mcover1_32 = 0;
    mcover1_109_ori = mcover1_109_sug = mcover3_109_ori = mcover3_109_sug = base_mcover = 0;
    insmpurm_109_ori = insmpurm_109_sug = 0;

     /* 971216, �]��22����, add fassured*/
    if ( strncmp(cal_car_id,"22",2) == 0)
    {
    	if ((assuredf[0] == '2') || (assuredf[0] == '4') || (assuredf[0] == '6'))
           strcpy(fassured_comp,"2");
        else
           strcpy(fassured_comp,"1");
    }else{
    	strcpy(fassured_comp," ");
    }

    if (*fuse_type=='1')
    {
    	/* fcar_note => �e�ݤw�g�S�b�� */
        if(strcmp(fcar_note,"98")==0)
            strcpy(cal_car_id,"04");
        else if(strcmp(fcar_note,"99")==0)
            strcpy(cal_car_id,"03");
    }

    #ifdef PRINTF_FLAG
    printf("Cal_ins_prem_302()####### cal_car_id[%s]\n",cal_car_id);
    #endif

    /********** Scan through every ins_type ****************/
    INS_ptr=Ifirst;
    f_30_change = 'N';

    /* 47�I�طs�º�k���վ��  add by sylvia 103.05.21 (1030407005_C4) */
    if (f1030601[0] == 1) adjn_47 = 0.0;
    else  adjn_47 = 0.5;

    /* --------------------------------------------------------------- */
    while (INS_ptr)
    {
        #ifdef PRINTF_FLAG
        printf("Cal_ins_prem_302()#######--------- Scan every ins[%s] sug_type[%d]\n",INS_ptr ->ins_type,INS_ptr->sug_iins_type);
        printf("injur_cover[%d] death_cover[%d] damage_cover[%d] \n",INS_ptr->injured_cover, INS_ptr->death_cover, INS_ptr->damage_cover );
        printf("Trace -- TEST = [%s] \n",  INS_ptr->provision);
        printf("Trace a -- plia_acc = [%f] \n",  plia_acc);
        #endif

        if (memcmp(INS_ptr->ins_type,"**",2)==0)
        {   /* deleted ins_type */
            INS_ptr=INS_ptr->next;
            continue;
        }

        if (strcmp(trim(INS_ptr->ins_type),"21")==0)
        {   /* deleted ins_type */
            INS_ptr=INS_ptr->next;
            continue;
        }

        strcpy(ins_type,INS_ptr->ins_type);
        strcpy(ins_type,trim(ins_type));
        iins=atoi(ins_type);

        sug_type = INS_ptr->sug_iins_type;

        cal_deduct=0;
        cal_deduct=INS_ptr->deduct;

        org_ins_premium=INS_ptr->ins_premium; /* make a copy of org. premium */

        strcpy(tmp_provision,"");
        sprintf_s(tmp_provision,sizeof tmp_provision,"%s;",trim(INS_ptr->provision)); /* ���� */

        /*------------------------*/
        qday = 0;
        find_flag = 0;
        printf("INS_ptr->ins_type[%s]\n",INS_ptr->ins_type);

        for (chk_count=0 ; chk_count<max_insurance_type ; chk_count++)
        {
             if (strcmp(insurance_type[chk_count].iins_type,ins_type)==0)
             {
                  strcpy(fcal_way,  insurance_type[chk_count].fcal_way);
                  strcpy(isame_ins, insurance_type[chk_count].isame_ins);
                  qserial         = insurance_type[chk_count].qserial;
                  qcoverage       = insurance_type[chk_count].qcoverage;
                  strcpy(fdeduct,   insurance_type[chk_count].fdeduct);
                  strcpy(fins_grp,  insurance_type[chk_count].fins_grp);

                  find_flag = 1;
                  break;
             }
        }
        if (find_flag == 0) return M_CA_NINS_TYPE;



        #ifdef PRINTF_FLAG
        printf("find_flag=[%d]\n",find_flag);
        printf("qserial=[%d]\n",qserial);
        #endif

        if ((strcmp(trim(INS_ptr->ins_type),"34")==0) ||
            (strcmp(trim(INS_ptr->ins_type),"87")==0) ||
            (strcmp(trim(INS_ptr->ins_type),"115")==0))
        {
            if (find_flag == 1){
            	*(INS_ptr->fdeduct)=*fdeduct;
            	*(INS_ptr->fins_grp)=*fins_grp;
            	INS_ptr->qcoverage=qcoverage;
            	INS_ptr->qserial=qserial;

            	#ifdef PRINTF_FLAG
            	printf("34,87,115 INS_ptr->qserial=[%d]\n",INS_ptr->qserial);
            	#endif
            }
            INS_ptr=INS_ptr->next;
            continue;
        }

        #ifdef PRINTF_FLAG
        printf("INS_ptr->frate[%s]\n",INS_ptr->frate);
        #endif

        if ((INS_ptr->frate[0]!=' ') && (INS_ptr->frate[0]!='\0'))
        {
        	strcpy(frate_chk, INS_ptr->frate);
        }
        else
        {
        	if (iins!=21){
        		strcpy(frate_chk, tmp_frate2);
        	}else{
        		strcpy(frate_chk, tmp_frate1);
        	}
        }
        strcpy(frate_chk, trim(frate_chk));

        #ifdef PRINTF_FLAG
        printf("Cal_ins_prem_302()####### cal_deduct[%d] frate_chk[%s]\n",cal_deduct,frate_chk);
        #endif

        /*����*/
        cal_pro_year[0]='\0';

        find_flag = 0;
        for (chk_count=0 ; chk_count<max_min_car_factor ; chk_count++)
        {
             if ((strcmp(min_car_factor[chk_count].fdmg_brg, "1") == 0) &&
                 (strcmp(min_car_factor[chk_count].frate, frate_chk) == 0))
             {
                  find_flag  = 1;
                  strcpy(cal_pro_year, min_car_factor[chk_count].ipro_year);
                  break;
             }
        }

        if (find_flag == 0)
        {
            $SELECT MIN(DISTINCT ipro_year)
               INTO $cal_pro_year
               FROM car_model_factor
              WHERE fdmg_brg='1' ;
        }

        if(atoi(pro_year)-atoi(cal_pro_year)>0)
            strcpy(cal_pro_year,pro_year);

        #ifdef PRINTF_FLAG
        printf("CCDBG brandi[%s]\n",brandi);
        printf("CCDBG ipro_year[%s]\n",cal_pro_year);
        printf("CCDBG frate_chk[%s]\n",frate_chk);
        #endif

        strcpy(brandi,       trim(brandi));
        strcpy(cal_pro_year, trim(cal_pro_year));

        #ifdef PRINTF_FLAG
        printf("######### brandi[%s],cal_pro_year[%s],frate_chk[%s]\n",brandi,cal_pro_year,frate_chk);
        #endif

        $SELECT idmg_rate
           INTO $idmg_rate
           FROM ca_car_model
          WHERE ibrand    = $brandi
            AND ipro_year = $cal_pro_year
            AND drate=(SELECT drate
                         FROM ca_rate_date
                        WHERE icode  = $frate_chk
                          AND itable = 'ca_car_model');

        if(NOT_FOUND)
        {
             #ifdef PRINTF_FLAG
             printf("######### 1. brandi[%s],cal_pro_year[%s],frate_chk[%s]\n",brandi,cal_pro_year,frate_chk);
             #endif

             /* �אּ����<ipro_year ���̤j�~��, �A�䤣��~�� >ipro_year ���̤p�~��
                 ��: ��J���s�y�~����2014, �Y�d�L2014�~�������, �h���� <2014����1�� (2013), �A�d����h�� >2014����@��(2015)
                modify by sylvia 104.09.15  (1040714001_C3) */

             $DECLARE dg011_cur CURSOR FOR
               SELECT idmg_rate,ipro_year
                 INTO $idmg_rate,$sIpyear
                 FROM ca_car_model
                WHERE ibrand=$brandi
                  AND ipro_year < $cal_pro_year
                  AND drate=(SELECT drate
                               FROM ca_rate_date
                              WHERE icode  = $frate_chk
                                AND itable = 'ca_car_model')
                ORDER BY ipro_year desc;
             $OPEN dg011_cur;
             $FETCH dg011_cur;

             if(NOT_FOUND)
             {
                 #ifdef PRINTF_FLAG
                 printf("######### 2. brandi[%s],cal_pro_year[%s],frate_chk[%s]\n",brandi,cal_pro_year,frate_chk);
                 #endif

                 $DECLARE dg021_cur CURSOR FOR
                   SELECT idmg_rate,ipro_year
                     INTO $idmg_rate,$sIpyear
                     FROM ca_car_model
                    WHERE ibrand=$brandi
                      AND ipro_year > $cal_pro_year
                      AND drate=(SELECT drate
                                   FROM ca_rate_date
                                  WHERE icode=$frate_chk
                                    AND itable='ca_car_model')
                     ORDER BY ipro_year ;
                 $OPEN dg021_cur;
                 $FETCH dg021_cur;

                 if(NOT_FOUND)
                    strcpy(idmg_rate,"0");

             }
        }
        #ifdef PRINTF_FLAG
        printf("CCDBG idmg_rate[%s]\n",idmg_rate);
        #endif

        cal_pro_year[0]='\0';

        /*�ѵs*/
        find_flag = 0;
        for (chk_count=0 ; chk_count<max_min_car_factor ; chk_count++)
        {
             if ((strcmp(min_car_factor[chk_count].fdmg_brg, "2") == 0) &&
                 (strcmp(min_car_factor[chk_count].frate, frate_chk) == 0))
             {
                  find_flag  = 1;
                  strcpy(cal_pro_year, min_car_factor[chk_count].ipro_year);
                  break;
             }
        }

        if (find_flag == 0) /* NOT FOUND */
        {
            $SELECT MIN(DISTINCT ipro_year)
               INTO $cal_pro_year
               FROM car_model_factor
              WHERE fdmg_brg='2' ;
        }


        if(atoi(pro_year)-atoi(cal_pro_year)>0)
            strcpy(cal_pro_year,pro_year);

        strcpy(brandi,       trim(brandi));
        strcpy(cal_pro_year, trim(cal_pro_year));


        $SELECT ibrg_rate
           INTO $ibrg_rate
           FROM ca_car_model
          WHERE ibrand    = $brandi
            AND ipro_year = $cal_pro_year
            AND drate=(SELECT drate
                         FROM ca_rate_date
                        WHERE icode=$frate_chk
                          AND itable='ca_car_model');

        if(NOT_FOUND)
        {
            /* �אּ����<ipro_year ���̤j�~��, �A�䤣��~�� >ipro_year ���̤p�~��
                ��: ��J���s�y�~����2014, �Y�d�L2014�~�������, �h���� <2014����1�� (2013), �A�d����h�� >2014����@��(2015)
                modify by sylvia 104.09.15  (1040714001_C3)       */

            $DECLARE br011_cur CURSOR FOR
               SELECT ibrg_rate,ipro_year
                 INTO $ibrg_rate,$sIpyear
                 FROM ca_car_model
                WHERE ibrand=$brandi
                  AND ipro_year < $cal_pro_year
                  AND drate=(SELECT drate
                               FROM ca_rate_date
                              WHERE icode=$frate_chk
                                AND itable='ca_car_model')
                ORDER BY ipro_year desc;

             $OPEN br011_cur;
             $FETCH br011_cur;
             if(NOT_FOUND)
             {
                 $DECLARE br022_cur CURSOR FOR
                   SELECT ibrg_rate,ipro_year
                     INTO $ibrg_rate,$sIpyear
                     FROM ca_car_model
                    WHERE ibrand    = $brandi
                      AND ipro_year > $cal_pro_year
                      AND drate=(SELECT drate
                                   FROM ca_rate_date
                                  WHERE icode  = $frate_chk
                                    AND itable = 'ca_car_model')
                    ORDER BY ipro_year ;

                 $OPEN br022_cur;
                 $FETCH br022_cur;
                 if (NOT_FOUND)
                     strcpy(ibrg_rate,"0");
             }
        }
        #ifdef PRINTF_FLAG
        printf("@@@@@@ car103�����m���ȡGmcar_price[%lf]\n",mcar_price);
        printf("@@@@@@ �e�椧���m���ȡGcar_price[%lf]\n",car_price);
        #endif


        /*--BUG-- ���s���@����l��(12�B28�I�ط|���L) */
        provision_P = 1.0;
        provision_Q = 1.0;
        provision_M = 1.0;
        provision_K = 1.0;
				provision_L = 1.0;
				provision_H = 1.0;
				provision_Y = 1.0;
				strcpy(fcar_class_tmp, substring(fcar_class,1,1));

				/* 980520,�j�v���[���ڤ��Ҽ{�F�Ƭ���(�j�v�ȳB�z�@���)    */
				/* �������[���ڤ��Ҽ{�F�Ƭ����A���k�s�A���}function�A�٭� */
				if (iins==31 || iins==32 || iins==149 || iins==231 || iins==232 ||
				    iins==249 || iins==531 || iins==532){
		    /* 101.06.25 */
		    		if(strstr(tmp_provision,"F;") != NULL){
		            plia_acc_ori = plia_acc;
		            plia_acc = 0;
		    		}

				    /* G���ڤ��F���� add by sylvia 105.08.06 (1050705002_C3) */
				    if(strstr(tmp_provision,"G;") != NULL){
				            plia_acc_ori = plia_acc;
				            plia_acc = 0;
				    }

				    if(strstr(tmp_provision,"B;") != NULL){
				            plia_acc_ori = plia_acc;
				            plia_acc = 0;
				    }
        }
        /* 77,78�I�ؤ��Ҽ{����,�G���k�s,���}function�A�٭�
           add by sylvia 103.04.03 1000310003_C3 */
        if (iins==77 || iins==78)
        {
        	plia_acc_ori = plia_acc;
        	plia_acc = 0;
        }


        /* add by 071004 (1110308005_SC3_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h)*/
        if (strstr(tmp_provision,"H;") != NULL)
        {
        	$EXECUTE pre_ca_add_prov
        	INTO $provision_H
        	USING $car_typei,$ins_type,"H","0",$frate_chk;

        	if (NOT_FOUND) provision_H = 1.0;
        }
        else
            provision_H = 1.0;


        /*** �ˮ`�I�O�I�O���p�� ***/
        if (iins==33)
        {
             lMins_premium33 = 0;
             lPure_premium33 = 0;
             lMcommission33  = 0;
             lMagent33       = 0;
             lMdiscount33    = 0;
             lBef_premium33  = 0;

             if (Ifirst_33 == NULL)
                  printf("if Ifirst_33 = NULL \n");

             lMins_amt_sum_33 = 0;
             INS_ptr_33       = Ifirst_33;
             while (INS_ptr_33)
             {
                  strcpy(iins_scope_tmp    , INS_ptr_33->cIins_scope); /* �ӫO�d�� */
                  strcpy(icareer_tmp       , INS_ptr_33->cIcareer);    /* ¾�~���O */
                  lMins_amt_33             = INS_ptr_33->lMins_amt;
                  lDaily_pay_33            = INS_ptr_33->lDaily_pay;

                  if (strcmp(trim(INS_ptr_33->iins_type),"33")!=0)
                  {   /* deleted ins_type */
                      INS_ptr_33=INS_ptr_33->next;
                      continue;
                  }

                  #ifdef PRINTF_FLAG
                  printf("cal_car_id[%s] iins_scope_tmp[%s]\n",cal_car_id, iins_scope_tmp);
                  printf("lDaily_pay_33[%d]\n", lDaily_pay_33);
                  #endif

                  lMins_amt_sum_33 += lMins_amt_33;

                  INS_ptr_33->dPdiscount   = INS_ptr->pdiscount;

                  $SELECT drate
                     FROM ca_rate_date
                    WHERE icode  = $frate_chk
                      AND itable = 'ca_rate';
                  if (NOT_FOUND)  return M_CA_NRATE_DATE;

                  /* 1.���o�򥻶O�v (prate)%, ���[�O�βv */
                  EXEC SQL SELECT prate, NVL(pextra_charge/100,0)
                             INTO $prate_1, $pextra_charge
                             FROM ca_rate
                            WHERE icar_type = '03'
                              AND iins_type = '33'
                              AND mdeduct   = 0
                              AND qpt_bgn   = $iins_scope_tmp
                              AND qpt_end   = 0
                              AND drate     = (SELECT drate
                                                 FROM ca_rate_date
                                                WHERE icode  = $frate_chk
                                                  AND itable = 'ca_rate');
                  if (NOT_FOUND)
                  {
                  	prate_1 = 0;
                  	pextra_charge = 0;
                  }
                  /* 97.11�J�O�v�ۥѤ� */
                  if( f980101[0] == '1')
                  	pextra_charge_mr = INS_ptr->pextra_charge;
                  else
                  	INS_ptr->pextra_charge = pextra_charge_mr;


                  /* 2.���o¾�~���O�O�v�� (prate)% */
                  EXEC SQL SELECT NVL(prate,100)
                             INTO $prate_icareer
                             FROM ca_rate
                            WHERE icar_type = '03'
                              AND iins_type = '33'
                              AND mdeduct   = 0
                              AND qpt_bgn   = 0
                              AND qpt_end   = $icareer_tmp
                              AND drate     = (SELECT drate
                                                 FROM ca_rate_date
                                                WHERE icode  = $frate_chk
                                                  AND itable = 'ca_rate');
                  if (NOT_FOUND)
                  {
                      prate_icareer = 0;
                  }


                  /* 3.�򥻫����[�������o�ˮ`���|�������򥻶O�v */
                  if( strcmp( iins_scope_tmp , "3" ) == 0 )
                  {
                      EXEC SQL SELECT prate
                                 INTO $prate_dailypay
                                 FROM ca_rate
                                WHERE icar_type = '03'
                                  AND iins_type = '33'
                                  AND mdeduct   = $lDaily_pay_33
                                  AND qpt_bgn   = '3'
                                  AND qpt_end   = 0
                                  AND drate     = (SELECT drate
                                                  FROM ca_rate_date
                                                 WHERE icode  = $frate_chk
                                                   AND itable = 'ca_rate');
                      if (NOT_FOUND)
                      {
                          prate_dailypay =0;
                      }
                  }
                  else
                     prate_dailypay =0;

                  #ifdef PRINTF_FLAG
                  printf("prate_dailypay[%f]\n",prate_dailypay);
                  printf("====> count pure premium\n");
                  #endif
                  /* 1.�ˮ`�M�I�O�O */
                  INS_ptr_33->lPure_premium = ((float)lMins_amt_33 * (float)prate_1/100.0)
                                              * (float)prate_icareer/100 * (float)short_prate;     /* round */

                  /* 2.�ˮ`�W���O�O */
                  INS_ptr_33->lMins_premium = (long)(d45(((INS_ptr_33->lPure_premium)/(1-pextra_charge)),0));
                  lBef_premium33 += (long)INS_ptr_33->lMins_premium;    /* �W���O�O�t���� */

                  /* 3.�p���u�f���B */
                  INS_ptr_33->lMdiscount   = (long)(d45(((float)INS_ptr_33->lMins_premium*INS_ptr_33->dPdiscount/100.0),0));

                  /* 4.�p��ñ��O�O */
                  INS_ptr_33->lMins_premium = INS_ptr_33->lMins_premium - INS_ptr_33->lMdiscount;

                  if( strcmp( iins_scope_tmp , "3" ) == 0 )
                  {
                      /* 1.�����M�I�O�O */
                      INS_ptr_33->lMr_pure_prem = (((float)lDaily_pay_33 * (float) prate_dailypay/100 ) + 136.8 )
                                                  * (float)prate_icareer/100 * (float)short_prate;

                      /* 2.�����W���O�O */
                      INS_ptr_33->lMr_ins_prem=(long)(d45((INS_ptr_33->lMr_pure_prem/(1-pextra_charge)),0));
                      lBef_premium33 += (long)INS_ptr_33->lMr_ins_prem;    /* �W���O�O�t���� */

                      /* 3.�����u�f���B */
                      INS_ptr_33->lMr_discount   = (long)(d45(((float)INS_ptr_33->lMr_ins_prem*INS_ptr_33->dPdiscount/100.0),0));

                      /* 4.����ñ��O�O */
                      INS_ptr_33->lMr_ins_prem = INS_ptr_33->lMr_ins_prem - INS_ptr_33->lMr_discount;

                  }
                  else
                  {
                      INS_ptr_33->lMr_pure_prem = 0;
                      INS_ptr_33->lMr_ins_prem  = 0;
                      INS_ptr_33->lMr_discount  = 0;
                  }

                  /** �O�O = �ˮ` + ���� **/
                  INS_ptr_33->lMdiscount += INS_ptr_33->lMr_discount;
                  INS_ptr_33->lMins_premium += INS_ptr_33->lMr_ins_prem;
                  INS_ptr_33->lPure_premium += INS_ptr_33->lMr_pure_prem;

                  lMins_premium33 += (long)INS_ptr_33->lMins_premium;
                  lMcommission33  += INS_ptr_33->lMcommission;
                  lMagent33       += INS_ptr_33->lMagent;
                  lMdiscount33    += INS_ptr_33->lMdiscount;

                  #ifdef PRINTF_FLAG
                  printf("lMins_premium33[%ld]\n",lMins_premium33);
                  #endif
                  INS_ptr_33=INS_ptr_33->next;
             }

             INS_ptr->bef_ins_premium = lBef_premium33;
             INS_ptr->ins_premium     = lMins_premium33;
             INS_ptr->mdiscount       = lMdiscount33;
             INS_ptr->injured_cover   = 0;
             INS_ptr->death_cover     = 0;
             INS_ptr->damage_cover    = lMins_amt_sum_33;

             goto step_9_e_iii; /* �����p��O�O�X�p�Φ����B�N�z�B�����X�p���B */
        }

        if (iins==35)
        {
             lMins_premium33 = 0;
             lPure_premium33 = 0;
             lMcommission33  = 0;
             lMagent33       = 0;
             lMdiscount33    = 0;
             lBef_premium33  = 0;

             if (Ifirst_33 == NULL)
                  printf("if Ifirst_35 = NULL \n");

             lMins_amt_sum_33 = 0;
             INS_ptr_33       = Ifirst_33;
             while (INS_ptr_33)
             {
                  strcpy(iins_scope_tmp    , INS_ptr_33->cIins_scope); /* �ӫO�d�� */
                  strcpy(icareer_tmp       , INS_ptr_33->cIcareer);    /* ¾�~���O */
                  lMins_amt_33             = INS_ptr_33->lMins_amt;
                  lDaily_pay_33            = INS_ptr_33->lDaily_pay;

                  if (strcmp(trim(INS_ptr_33->iins_type),"35")!=0)
                  {   /* deleted ins_type */
                      INS_ptr_33=INS_ptr_33->next;
                      continue;
                  }

                  #ifdef PRINTF_FLAG
                  printf("cal_car_id[%s] iins_scope_tmp[%s]\n",cal_car_id, iins_scope_tmp);
                  printf("lDaily_pay_33[%d]\n", lDaily_pay_33);
                  #endif

                  lMins_amt_sum_33 += lMins_amt_33;

                  INS_ptr_33->dPdiscount   = INS_ptr->pdiscount;

                  $SELECT drate
                     FROM ca_rate_date
                    WHERE icode  = $frate_chk
                      AND itable = 'ca_rate';
                  if (NOT_FOUND)  return M_CA_NRATE_DATE;

                  $SELECT mpremium,  NVL(pextra_charge/100,0)
                     INTO $mpremium_1, $pextra_charge
                     FROM cover_vs_premium
                    WHERE icar_type = $car_typei
                      AND iins_type = '35'
                      AND mdeduct   = $iins_scope_tmp
                      AND mcoverage1 = 0
                      AND mcoverage2 = $lMins_amt_33
                      AND drate      = (SELECT drate
                                          FROM ca_rate_date
                                         WHERE icode  = $frate_chk
                                           AND itable = 'cover_vs_premium');

                  if (NOT_FOUND) return M_CA_NCOVER_PREM;
		          /* 97.11�J�O�v�ۥѤ� */
		          if( f980101[0] == '1')
		              pextra_charge = INS_ptr->pextra_charge;
		          else
		              INS_ptr->pextra_charge = pextra_charge;

                  #ifdef PRINTF_FLAG
                  printf("====> count pure premium\n");
                  #endif
                  /* 1.�ˮ`�M�I�O�O */
                  INS_ptr_33->lPure_premium = (float)mpremium_1 * (float)short_prate;     /* round */

                  /* 2.�ˮ`�W���O�O */
                  INS_ptr_33->lMins_premium = (long)(d45((INS_ptr_33->lPure_premium/(1-pextra_charge)),0));
                  lBef_premium33 += (long)INS_ptr_33->lMins_premium;    /* �W���O�O�t���� */

                  /* 3.�p���u�f���B */
                  INS_ptr_33->lMdiscount   = (long)(d45(((float)INS_ptr_33->lMins_premium*INS_ptr_33->dPdiscount/100.0),0));

                  /* 4.�p��ñ��O�O */
                  INS_ptr_33->lMins_premium = INS_ptr_33->lMins_premium - INS_ptr_33->lMdiscount;

                  INS_ptr_33->lMr_pure_prem = 0;
                  INS_ptr_33->lMr_ins_prem  = 0;
                  INS_ptr_33->lMr_discount  = 0;


                  lMins_premium33 += (long)INS_ptr_33->lMins_premium;
                  lMcommission33  += INS_ptr_33->lMcommission;
                  lMagent33       += INS_ptr_33->lMagent;
                  lMdiscount33    += INS_ptr_33->lMdiscount;

                  #ifdef PRINTF_FLAG
                  printf("lMins_premium33[%ld]\n",lMins_premium33);
                  #endif
                  INS_ptr_33=INS_ptr_33->next;
             }

             INS_ptr->bef_ins_premium = lBef_premium33;
             INS_ptr->ins_premium     = lMins_premium33;
             INS_ptr->mdiscount       = lMdiscount33;
             INS_ptr->injured_cover   = 0;
             INS_ptr->death_cover     = 0;
             INS_ptr->damage_cover    = lMins_amt_sum_33;

             goto step_9_e_iii; /* �����p��O�O�X�p�Φ����B�N�z�B�����X�p���B */
        }

        if (iins==48)
        {
             lMins_premium33 = 0;
             lPure_premium33 = 0;
             lMcommission33  = 0;
             lMagent33       = 0;
             lMdiscount33    = 0;
             lBef_premium33  = 0;

             if (Ifirst_33 == NULL)
                  printf("if Ifirst_48 = NULL \n");

             lMins_amt_sum_33 = 0;
             INS_ptr_33       = Ifirst_33;
             while (INS_ptr_33)
             {

                  strcpy(iins_scope_tmp    , INS_ptr_33->cIins_scope); /* �ӫO�d�� */
                  strcpy(icareer_tmp       , INS_ptr_33->cIcareer);    /* ¾�~���O */
                  lMins_amt_33             = INS_ptr_33->lMins_amt;
                  lDaily_pay_33            = INS_ptr_33->lDaily_pay;

                  if (strcmp(trim(INS_ptr_33->iins_type),"48")!=0)
                  {   /* deleted ins_type */
                      INS_ptr_33=INS_ptr_33->next;
                      continue;
                  }

                  #ifdef PRINTF_FLAG
                  printf("cal_car_id[%s] iins_scope_tmp[%s]\n",cal_car_id, iins_scope_tmp);
                  printf("Trace -- lMins_amt_33 = [%ld] \n",  lMins_amt_33);
                  printf("lDaily_pay_33[%d]\n", lDaily_pay_33);
                  #endif

                  lMins_amt_sum_33 += lMins_amt_33;

                  INS_ptr_33->dPdiscount   = INS_ptr->pdiscount;

                  $SELECT drate
                     FROM ca_rate_date
                    WHERE icode  = $frate_chk
                      AND itable = 'ca_rate';
                  if (NOT_FOUND)  return M_CA_NRATE_DATE;

                  /* 1.���o���ݯ«O�O (mpremium), ���[�O�βv */
                  $SELECT mpremium,  NVL(pextra_charge/100,0)
                     INTO $mpremium_1, $pextra_charge
                     FROM cover_vs_premium
                    WHERE icar_type = $car_typei
                      AND iins_type = '48'
                      AND mdeduct   = 0
                      AND mcoverage1 = 0
                      AND mcoverage2 = $lMins_amt_33
                      AND drate      = (SELECT drate
                                          FROM ca_rate_date
                                         WHERE icode  = $frate_chk
                                           AND itable = 'cover_vs_premium');
                   if (NOT_FOUND) return M_CA_NCOVER_PREM;
			       /* 97.11�J�O�v�ۥѤ� */
			       if( f980101[0] == '1')
			           pextra_charge = INS_ptr->pextra_charge;
			       else
			           INS_ptr->pextra_charge = pextra_charge;

                   #ifdef PRINTF_FLAG
                   printf("-------->mpremium_1=[%f]\n", mpremium_1 );
                   #endif

                   /* 2.���o���[�����¶O (mpremium), ���[�O�βv */
                   $SELECT mpremium,  NVL(pextra_charge/100,0)
                     INTO $mpremium_mr, $pextra_charge_mr
                     FROM cover_vs_premium
                    WHERE icar_type = $car_typei
                      AND iins_type = '48'
                      AND mdeduct   = 1
                      AND mcoverage1 = 0
                      AND mcoverage2 = $lDaily_pay_33
                      AND drate      = (SELECT drate
                                          FROM ca_rate_date
                                         WHERE icode  = $frate_chk
                                           AND itable = 'cover_vs_premium');
                   if (NOT_FOUND) return M_CA_NCOVER_PREM;

                   /* 97.11�J�O�v�ۥѤ� */
                   if( f980101[0] == '1')
                   	pextra_charge_mr = INS_ptr->pextra_charge;
                   else
                   	INS_ptr->pextra_charge = pextra_charge_mr;

                   #ifdef PRINTF_FLAG
                   printf("====> count pure premium\n");
                   #endif
                   /* 1.�ˮ`�M�I�O�O */
                   INS_ptr_33->lPure_premium = (float)mpremium_1 * (float)short_prate;     /* round */

                   /* 2.�ˮ`�W���O�O */
                   INS_ptr_33->lMins_premium = (long)(d45((INS_ptr_33->lPure_premium/(1-pextra_charge)),0));
                   lBef_premium33 += (long)INS_ptr_33->lMins_premium;    /* �W���O�O�t���� */

                   /* 3.�p���u�f���B */
                   INS_ptr_33->lMdiscount   = (long)(d45(((float)INS_ptr_33->lMins_premium*INS_ptr_33->dPdiscount/100.0),0));

                   /* 4.�p��ñ��O�O */
                   INS_ptr_33->lMins_premium = INS_ptr_33->lMins_premium - INS_ptr_33->lMdiscount;

                   if( strcmp( iins_scope_tmp , "2" ) == 0 )
                   {
                      /* 1.�����M�I�O�O */
                      INS_ptr_33->lMr_pure_prem = (float)mpremium_mr * (float)short_prate;

                      /* 2.�����W���O�O */
                      INS_ptr_33->lMr_ins_prem=(long)(d45((INS_ptr_33->lMr_pure_prem/(1-pextra_charge_mr)),0));
                      lBef_premium33 += (long)INS_ptr_33->lMr_ins_prem;    /* �W���O�O�t���� */

                      /* 3.�����u�f���B */
                      INS_ptr_33->lMr_discount   = 0;

                      /* 4.����ñ��O�O */
                      INS_ptr_33->lMr_ins_prem = INS_ptr_33->lMr_ins_prem - INS_ptr_33->lMr_discount;

                      #ifdef PRINTF_FLAG
                      printf("\nlMr_pure_prem[%f]\n", INS_ptr_33->lMr_pure_prem);
                      printf("lMr_ins_prem[%f]\n", INS_ptr_33->lMr_ins_prem);
                      #endif
                   }
                   else
                   {
                      INS_ptr_33->lMr_pure_prem = 0;
                      INS_ptr_33->lMr_ins_prem  = 0;
                      INS_ptr_33->lMr_discount  = 0;
                   }

                   /** �O�O = �ˮ` + ���� **/
                   INS_ptr_33->lMdiscount += INS_ptr_33->lMr_discount;
                   INS_ptr_33->lMins_premium += INS_ptr_33->lMr_ins_prem;
                   INS_ptr_33->lPure_premium += INS_ptr_33->lMr_pure_prem;

                   lMins_premium33 += (long)INS_ptr_33->lMins_premium;
                   lMcommission33  += INS_ptr_33->lMcommission;
                   lMagent33       += INS_ptr_33->lMagent;
                   lMdiscount33    += INS_ptr_33->lMdiscount;

                   #ifdef PRINTF_FLAG
                   printf("lMins_premium33[%ld]\n",lMins_premium33);
                   #endif
                   INS_ptr_33=INS_ptr_33->next;
             }

             INS_ptr->bef_ins_premium = lBef_premium33;
             INS_ptr->ins_premium     = lMins_premium33;
             INS_ptr->mdiscount       = lMdiscount33;
             INS_ptr->injured_cover   = 0;
             INS_ptr->death_cover     = 0;
             INS_ptr->damage_cover    = lMins_amt_sum_33;

             goto step_9_e_iii; /* �����p��O�O�X�p�Φ����B�N�z�B�����X�p���B */
        }

        /* �s�W266 (1110308005_SC_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h)*/
        if ((iins==56) || (iins==136) || (iins==166) || (iins==266))
        {
             strcpy(sIns,itoa(iins));
             lMins_premium33 = 0;
             lPure_premium33 = 0;
             lMcommission33  = 0;
             lMagent33       = 0;
             lMdiscount33    = 0;
             lBef_premium33  = 0;
             if (Ifirst_33 == NULL)
                  printf("if Ifirst_56/136/166/266 = NULL \n");

             lMins_amt_sum_33 = 0;
             INS_ptr_33       = Ifirst_33;
             while (INS_ptr_33)
             {
             	  if (INS_ptr_33->sug_iins_type != INS_ptr->sug_iins_type) {
                      INS_ptr_33=INS_ptr_33->next;
                      continue;
             	  }
             	  if (lMins_amt_sum_33>0) break; /* 960807,56�O�B���֥[�W�椤(ca_pa_ply)�Ҧ����r�p�H�O�B */

                  strcpy(iins_scope_tmp    , INS_ptr_33->cIins_scope); /* �ӫO�d�� */
                  strcpy(icareer_tmp       , INS_ptr_33->cIcareer);    /* ¾�~���O */

                  /* �������ɫO�B, ���ӧO���o ���O�զX �� ��ĳ��O�զX ���O�B */
                  lMins_amt_33             = INS_ptr->damage_cover;
                  lDaily_pay_33            = INS_ptr_33->lDaily_pay;


                  if (strcmp(trim(INS_ptr_33->iins_type),sIns)!=0)
                  {   /* deleted ins_type */
                      INS_ptr_33=INS_ptr_33->next;
                      continue;
                  }

                  #ifdef PRINTF_FLAG
                  printf("cal_car_id[%s] iins_scope_tmp[%s]\n",cal_car_id, iins_scope_tmp);
                  printf("lDaily_pay_33[%d]\n", lDaily_pay_33);
                  #endif

                  lMins_amt_sum_33 += lMins_amt_33;
                  INS_ptr_33->dPdiscount   = INS_ptr->pdiscount;

                  #ifdef PRINTF_FLAG
                  printf("lMins_amt_33[%ld]\n",lMins_amt_33);
                  printf("lMins_amt_sum_33[%ld]\n", lMins_amt_sum_33);
                  #endif
                  $SELECT drate
                     FROM ca_rate_date
                    WHERE icode  = $frate_chk
                      AND itable = 'ca_rate';
                  if (NOT_FOUND)  return M_CA_NRATE_DATE;

                  /* 1.���o���ݯ«O�O (mpremium), ���[�O�βv */
                  $SELECT mpremium,  NVL(pextra_charge/100,0)
                     INTO $mpremium_1, $pextra_charge
                     FROM cover_vs_premium
                    WHERE icar_type = $car_typei
                      AND iins_type = $sIns
                      AND mdeduct   = 0
                      AND mcoverage1 = 0
                      AND mcoverage2 = $lMins_amt_33
                      AND drate      = (SELECT drate
                                          FROM ca_rate_date
                                         WHERE icode  = $frate_chk
                                           AND itable = 'cover_vs_premium');
                  if (NOT_FOUND) return M_CA_NCOVER_PREM;

                  /* 97.11�J�O�v�ۥѤ� */
                  if( f980101[0] == '1')
                  	pextra_charge = INS_ptr->pextra_charge;
                  else
                  	INS_ptr->pextra_charge = pextra_charge;

                  printf("-------->mpremium_1=[%f]\n", mpremium_1 );
                  if( strcmp( iins_scope_tmp , "2" ) == 0 )
                  {
                      /* 2.���o���[�����¶O (mpremium), ���[�O�βv */
                      $SELECT mpremium,  NVL(pextra_charge/100,0), msi_premium
                         INTO $mpremium_mr, $pextra_charge_mr, $msi_premium
                         FROM cover_vs_premium
                        WHERE icar_type  = $car_typei
                          AND iins_type  = $sIns
                          AND mdeduct    = 1
                          AND mcoverage1 = 0
                          AND mcoverage2 = $lDaily_pay_33
                          AND drate      = (SELECT drate
                                              FROM ca_rate_date
                                             WHERE icode  = $frate_chk
                                               AND itable = 'cover_vs_premium');

                      if (NOT_FOUND) return M_CA_NCOVER_PREM;

                      /* 97.11�J�O�v�ۥѤ� */
                      if( f980101[0] == '1')
                      	pextra_charge_mr = INS_ptr->pextra_charge;
                      else
                       	INS_ptr->pextra_charge = pextra_charge_mr;
                  }
                  else if( strcmp( iins_scope_tmp , "3" ) == 0 )   /* ����I�� add by sylvia 103.11.19 (1030918003_C4) */
                  {
                      /* 2.���o���[�����¶O (mpremium), ���[�O�βv */
                      $SELECT mpremium,  NVL(pextra_charge/100,0), msi_premium
                         INTO $mpremium_mr, $pextra_charge_mr, $msi_premium
                         FROM cover_vs_premium
                        WHERE icar_type  = $car_typei
                          AND iins_type  = $sIns
                          AND mdeduct    = 2
                          AND mcoverage1 = 0
                          AND mcoverage2 = $lDaily_pay_33
                          AND drate      = (SELECT drate
                                              FROM ca_rate_date
                                             WHERE icode  = $frate_chk
                                               AND itable = 'cover_vs_premium');

                       if (NOT_FOUND) return M_CA_NCOVER_PREM;

                       /* 97.11�J�O�v�ۥѤ� */
                       if( f980101[0] == '1')
                       	pextra_charge_mr = INS_ptr->pextra_charge;
                       else
                       	INS_ptr->pextra_charge = pextra_charge_mr;
                  }

                  #ifdef PRINTF_FLAG
                  printf("====> count pure premium\n");
                  #endif
                  /* 1.�ˮ`�M�I�O�O */
                  INS_ptr_33->lPure_premium = (float)mpremium_1 * (float)short_prate;     /* round */

                  /* 2.�ˮ`�W���O�O */
                  INS_ptr_33->lMins_premium = (long)(d45((INS_ptr_33->lPure_premium * provision_H /(1-pextra_charge)),0));
                  lBef_premium33 += (long)INS_ptr_33->lMins_premium;    /* �W���O�O�t���� */

                  /* 3.�p���u�f���B */
                  INS_ptr_33->lMdiscount   = (long)(d45(((float)INS_ptr_33->lMins_premium*INS_ptr_33->dPdiscount/100.0),0));

                  /* 4.�p��ñ��O�O */
                  INS_ptr_33->lMins_premium = INS_ptr_33->lMins_premium - INS_ptr_33->lMdiscount;

                  #ifdef PRINTF_FLAG
                  printf("56-�u�f�v[%f]\n", INS_ptr_33->dPdiscount );
                  printf("56-�ˮ`--------------\n");
                  printf("56-�M�I�O�O[%f]\n", INS_ptr_33->lPure_premium);
                  printf("56-�W���O�O[%ld]\n", (long)INS_ptr_33->lMins_premium);
                  printf("56-�W���O�O(lBef_premium33�W���O�O�t����)[%ld]\n", lBef_premium33);
                  printf("56-�u�f���B[%ld]\n", INS_ptr_33->lMdiscount);
                  printf("56-ñ��O�O[%f]\n", INS_ptr_33->lMins_premium);
                  #endif
                  if(( strcmp( iins_scope_tmp , "2" ) == 0 ) || ( strcmp( iins_scope_tmp , "3" ) == 0 ))
                  {
                      /* 1.�����M�I�O�O */
                      INS_ptr_33->lMr_pure_prem = (float)mpremium_mr * (float)short_prate;

                      /* 950704,�]�«O�O�ӧC�A�H�P��O�O����@���A�G�h�[ msi_premium �վ�O�O */
                      cal_mr_pure_prem= (float)(mpremium_mr + msi_premium) * (float)short_prate;

                      /* 2.�����W���O�O */
                      INS_ptr_33->lMr_ins_prem=(long)(d45((cal_mr_pure_prem * provision_H /(1-pextra_charge_mr)),0));
                      lBef_premium33 += (long)INS_ptr_33->lMr_ins_prem;    /* �W���O�O�t���� */

                      /* 3.�����u�f���B */
                      INS_ptr_33->lMr_discount   = (long)(d45(((double)INS_ptr_33->lMr_ins_prem*INS_ptr_33->dPdiscount/100.0),0));

                      /* 4.����ñ��O�O */
                      INS_ptr_33->lMr_ins_prem = INS_ptr_33->lMr_ins_prem - INS_ptr_33->lMr_discount;

                      #ifdef PRINTF_FLAG
                      printf("56-���� [%s]--------------\n",iins_scope_tmp);
                      printf("56-�M�I�O�O[%f]\n", cal_mr_pure_prem);
                      printf("56-�W���O�O[%ld]\n", (long)INS_ptr_33->lMr_ins_prem);
                      printf("56-�W���O�O(lBef_premium33�W���O�O�t����)[%ld]\n", lBef_premium33);
                      printf("56-�u�f���B[%ld]\n", INS_ptr_33->lMr_discount);
                      printf("56-ñ��O�O[%f]\n", INS_ptr_33->lMr_ins_prem);
                      #endif
                  }
                  else
                  {
                  	cal_mr_pure_prem          = 0;
                  	INS_ptr_33->lMr_pure_prem = 0;
                  	INS_ptr_33->lMr_ins_prem  = 0;
                  	INS_ptr_33->lMr_discount  = 0;
                  }

                  /** �O�O = �ˮ` + ���� **/
                  INS_ptr_33->lMdiscount += INS_ptr_33->lMr_discount;
                  INS_ptr_33->lMins_premium += INS_ptr_33->lMr_ins_prem;
                  INS_ptr_33->lPure_premium += INS_ptr_33->lMr_pure_prem;


                  lMins_premium33 += (long)INS_ptr_33->lMins_premium;
                  lMcommission33  += INS_ptr_33->lMcommission;
                  lMagent33       += INS_ptr_33->lMagent;
                  lMdiscount33    += INS_ptr_33->lMdiscount;

                  #ifdef PRINTF_FLAG
                  printf("lMins_premium33[%ld]\n",lMins_premium33);
                  #endif

                  INS_ptr_33=INS_ptr_33->next;
             }

             INS_ptr->bef_ins_premium = lBef_premium33;
             INS_ptr->ins_premium     = lMins_premium33;
             INS_ptr->mdiscount       = lMdiscount33;
             INS_ptr->injured_cover   = 0;
             INS_ptr->death_cover     = 0;
             INS_ptr->damage_cover    = lMins_amt_sum_33;


             goto step_9_e_iii; /* �����p��O�O�X�p�Φ����B�N�z�B�����X�p���B */
        }

        /*�j��s*/
        #ifdef PRINTF_FLAG
        printf(" 222 fcomp_24[%s]\n",fcomp_24);
        printf("ply1f[%d]\n",ply1f);
        #endif

        if (ply2f==TRUE)
        {
             #ifdef PRINTF_FLAG
             printf("Trace2 -- plia_acc = [%f] \n",  plia_acc);
             printf("mag:idmg_rate[%s] ibrg_rate[%s] pro_year[%s]\n",idmg_rate,ibrg_rate,cal_pro_year);
             #endif
             if ((fcar_class[0]=='1' &&
                 (strcmp(car_typei,"03")==0 || strcmp(car_typei,"04")==0 ||
                  strcmp(car_typei,"19")==0 || strcmp(car_typei,"21")==0)||
                  strcmp(car_typei,"22")==0 || ISNEW_CAR1 (cal_car_id))  ||
                 (fcar_class[0]=='2' &&
                 (strcmp(car_typei,"07")==0 || strcmp(car_typei,"08")==0 ||
                  strcmp(car_typei,"14")==0 || strcmp(car_typei,"15")==0)||
                  ISNEW_CAR2 (cal_car_id)) )
             {
                  #ifdef PRINTF_FLAG
                  printf("idmg_rate[%s],cal_pro_yrar[%s],frate_chk[%s]\n",idmg_rate,cal_pro_year,frate_chk);
                  #endif
                  cal_pro_year[0]='\0';

                  find_flag = 0;
                  for (chk_count=0 ; chk_count<max_min_car_factor ; chk_count++)
                  {
                       if ((strcmp(min_car_factor[chk_count].fdmg_brg, "1") == 0) &&
                           (strcmp(min_car_factor[chk_count].frate, frate_chk) == 0))
                       {
                            find_flag  = 1;
                            strcpy(cal_pro_year, min_car_factor[chk_count].ipro_year);
                            break;
                       }
                  }

                  if (find_flag == 0)  /* NOT FOUND */
                  {
                       $SELECT MIN(DISTINCT ipro_year)
                          INTO $cal_pro_year
                          FROM car_model_factor
                         WHERE fdmg_brg='1'
                           AND drate=(SELECT drate
                                        FROM ca_rate_date
                                       WHERE icode  = $frate_chk
                                         AND itable = 'car_model_factor');
                  }

                  if(atoi(pro_year)-atoi(cal_pro_year)>0)
                       strcpy(cal_pro_year,pro_year);

                  #ifdef PRINTF_FLAG
                  printf("select dmg_factor-->cal_pro_year[%s],irate[%s],icode[%s]\n", cal_pro_year,idmg_rate,frate_chk);
                  #endif

                  dmg_factor = 0;
                  strcpy(idmg_rate,    trim(idmg_rate));
                  strcpy(cal_pro_year, trim(cal_pro_year));

                  find_flag  = 0;
                  for (chk_count=0 ; chk_count<max_car_model_factor ; chk_count++)
                  {
                       if ((strcmp(car_model_factor[chk_count].fdmg_brg, "1") == 0) &&
                           (strcmp(car_model_factor[chk_count].irate, idmg_rate) == 0) &&
                           (strcmp(car_model_factor[chk_count].ipro_year, cal_pro_year) == 0) &&
                           (strcmp(car_model_factor[chk_count].frate, frate_chk) == 0))
                       {
                            find_flag  = 1;
                            dmg_factor = car_model_factor[chk_count].pfactor;
                            break;
                       }
                  }
                  if (find_flag == 0)  /* NOT FOUND */
                      dmg_factor = 0;


                  cal_pro_year[0]='\0';
                  find_flag = 0;
                  for (chk_count=0 ; chk_count<max_min_car_factor ; chk_count++)
                  {
                       if ((strcmp(min_car_factor[chk_count].fdmg_brg, "2") == 0) &&
                           (strcmp(min_car_factor[chk_count].frate, frate_chk) == 0))
                       {
                            find_flag  = 1;
                            strcpy(cal_pro_year, min_car_factor[chk_count].ipro_year);
                            break;
                       }
                  }

                  if (find_flag == 0)
                  {
                       $SELECT MIN(DISTINCT ipro_year)
                          INTO $cal_pro_year
                          FROM car_model_factor
                         WHERE fdmg_brg='2'
                           AND drate=(SELECT drate
                                        FROM ca_rate_date
                                       WHERE icode  = $frate_chk
                                         AND itable = 'car_model_factor');
                  }

                  #ifdef PRINTF_FLAG
                  printf("!!!!!!!pro_year[%s],cal_pro_year[%s]\n",pro_year,cal_pro_year);
                  #endif

                  if(atoi(pro_year)-atoi(cal_pro_year)>0)
                      strcpy(cal_pro_year,pro_year);

                  #ifdef PRINTF_FLAG
                  printf("cal_pro_year[%s],ibrg_rate[%s]\n",cal_pro_year,ibrg_rate);
                  #endif

                  brg_factor = 0;
                  strcpy(ibrg_rate,    trim(ibrg_rate));
                  strcpy(cal_pro_year, trim(cal_pro_year));

                  find_flag  = 0;
                  for (chk_count=0 ; chk_count<max_car_model_factor ; chk_count++)
                  {
                       if ((strcmp(car_model_factor[chk_count].fdmg_brg, "2") == 0) &&
                           (strcmp(car_model_factor[chk_count].irate, ibrg_rate) == 0) &&
                           (strcmp(car_model_factor[chk_count].ipro_year, cal_pro_year) == 0) &&
                           (strcmp(car_model_factor[chk_count].frate, frate_chk) == 0))
                       {
                            find_flag  = 1;
                            brg_factor = car_model_factor[chk_count].pfactor;
                            break;
                       }
                  }
                  if (find_flag == 0)
                       brg_factor = 0;
             }
             else
             {
                  dmg_factor=0;
                  brg_factor=0;
             }
        }
        #ifdef PRINTF_FLAG
        printf("mag:dmg_factor[%f] brg_factor[%f]\n",dmg_factor,brg_factor);
        #endif

        /* 101.04.30 */
        /** a. b. c. d. has already done in previous SetCarAge() function call **/
        /*** e. ***/

        if (iins == 12 || /* �s��Q�ѷl���I */
            iins == 28)   /* ���B�s�t��     */
        {

            if (!Scan_INS_TYPE(11) && !Scan_INS_TYPE(211) && !Scan_INS_TYPE(18)&& !Scan_INS_TYPE(96)) return M_CA_INS11;

            if (iins == 12 ) /* �s��Q�ѷl���I */
            {
                INS_ptr->damage_cover  = 0;
                INS_ptr->deduct        = 0;
            }
            INS_ptr->injured_cover = 0;
            INS_ptr->death_cover   = 0;
            cal_deduct             = INS_ptr->deduct;

            #ifdef PRINTF_FLAG
            printf("brandi[%s]\n",brandi);
            printf("pro_year[%s]\n",pro_year);
            #endif

            /* �s��Q�ѷl���I�̨��t�M�w�O�I�O */
            $DECLARE CA_OPT21 CURSOR FOR
              SELECT icar_series,drate
                INTO $icar_series
                FROM ca_car_model
               WHERE ibrand=$brandi
                 AND ipro_year=$pro_year
               ORDER BY drate DESC;
            $OPEN CA_OPT21;
            $FETCH CA_OPT21;
            #ifdef PRINTF_FLAG
            printf("SQLCODE [%d] icar_series[%s]\n",SQLCODE,icar_series);
            #endif
            if (NOT_FOUND)
            {
                $DECLARE CA_OPT2D CURSOR FOR
                  SELECT icar_series,drate
                    INTO $icar_series
                    FROM ca_car_model
                   WHERE ibrand=$brandi
                     AND ipro_year=(SELECT MAX(ipro_year)
                                      FROM ca_car_model
                                     WHERE ibrand=$brandi)
                   ORDER BY drate DESC;
                $OPEN CA_OPT2D;
                $FETCH CA_OPT2D;
                if (NOT_FOUND)
                     strcpy(icar_series,"10");
                /*return M_CA_NBRAND;*/
                $CLOSE CA_OPT2D;
                $FREE CA_OPT2D;
            }
            $CLOSE CA_OPT21;
            $FREE CA_OPT21;

	    strcpy(icar_series, trim(icar_series));
	    strcpy(ins_type, trim(ins_type));

	    if (iins ==12 )
	    {  /* �s��Q�ѷl���I */

	        find_flag=0;
	        for (chk_count=0 ; chk_count<max_ca_rate ; chk_count++)
	        {
	            if ((strcmp(ca_rate[chk_count].icar_type, icar_series) == 0) &&
	                (strcmp(ca_rate[chk_count].iins_type, ins_type) == 0) &&
	                (strcmp(ca_rate[chk_count].frate, frate_chk) == 0) &&
	                (ca_rate[chk_count].mdeduct == cal_deduct))
	            {
	                find_flag     = 1;

	                prate_1       = ca_rate[chk_count].prate;
	                pextra_charge = ca_rate[chk_count].pextra_charge;

	                break;
	           }
	        }


		/* 97.11�J�O�v�ۥѤ� */
		if( f980101[0] == '1')
		    pextra_charge = INS_ptr->pextra_charge;
		else
		    INS_ptr->pextra_charge = pextra_charge;

	        if (find_flag == 0)
	            prate_1=0;
	        /*return M_CA_NRATE;*/
	        prate_1=prate_1/100.0;

	        #ifdef PRINTF_FLAG
	        printf("Cal_ins_prem()#######12 premium_11[%ld] prate_1[%f] series[%s]\n",premium_11,prate_1,icar_series);
	        #endif

	        INS_ptr->ins_premium = premium_11 * prate_1 * short_prate;    /*** round ***/

	        lChk_12_prem = 1000 * (1.0 - pextra_charge);

	        if (strcmp(icar_series,"10") == 0)                  /* �s���I�̧C�O�O */
	        {
	            if (INS_ptr->ins_premium < lChk_12_prem)
	                INS_ptr->ins_premium = lChk_12_prem;
	        }
	        else
	        {
	            if (INS_ptr->ins_premium < lChk_12_prem * 2)
	                INS_ptr->ins_premium = lChk_12_prem * 2;
	        }

	    }
	    else if( iins == 28)
	    {   /* 971223, ���B�s�t��  */

                injured_cover = INS_ptr->injured_cover;
                death_cover   = INS_ptr->death_cover;
                damage_cover  = INS_ptr->damage_cover;

                /* �s�t����w���O�I���B���o����Q�O�I�T���{��(��ګO�B)��75% */
                /* ���ѵs�D�I���²v�h��@�~(�Ӥ��O�T�w���H0.75) modify by 061476 (1080218008_SC2) */
                if( damage_cover > premium_11 * (1-pdep_rate_year))
                {
                    printf("Trace -- iins = [%d] \n",  iins);
	            printf("damage_cover -- TEST = [%ld] \n",  damage_cover);
	            printf("premium_11 -- TEST = [%ld] \n",  premium_11);
	            return M_CA_OVER_75_PERCENT;
	        }

                mpremium      = 0;
                pextra_charge = 0;

                find_flag     = 0;
                for (chk_count=0 ; chk_count<max_cover_prem ; chk_count++)
                {
                     if ((strcmp(cover_vs_prem[chk_count].icar_type, icar_series) == 0) &&
                         (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                         (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                         (cover_vs_prem[chk_count].mcoverage1 == injured_cover)&&
                         (cover_vs_prem[chk_count].mcoverage2 == damage_cover)&&
                         (cover_vs_prem[chk_count].mdeduct == cal_deduct))
                     {
                          find_flag     = 1;
                          mpremium      = cover_vs_prem[chk_count].mpremium;
                          pextra_charge = cover_vs_prem[chk_count].pextra_charge;
                          break;
                     }
                }

	        if (find_flag==0)  return M_CA_NCOVER_PREM;

	        INS_ptr->ins_premium     = mpremium * short_prate;
	    }

            INS_ptr->bef_ins_premium=INS_ptr->ins_premium;

            #ifdef PRINTF_FLAG
            printf("12@@@@@ ins_premium[%f]\n",INS_ptr->ins_premium);

            #endif

            goto step_9_e_iii;
        }

        if (iins == 128)   /*  ���ľ��c�q�~�H�����B�s�t�� */
        {

            if (!Scan_INS_TYPE(129) ) return M_CA_INS11;


            INS_ptr->injured_cover = 0;
            INS_ptr->death_cover   = 0;
            cal_deduct             = INS_ptr->deduct;


             /* �s��Q�ѷl���I�̨��t�M�w�O�I�O */
            $DECLARE CA_OPT211 CURSOR FOR
              SELECT icar_series,drate
                INTO $icar_series
                FROM ca_car_model
               WHERE ibrand=$brandi
                 AND ipro_year=$pro_year
               ORDER BY drate DESC;
            $OPEN CA_OPT211;
            $FETCH CA_OPT211;
            #ifdef PRINTF_FLAG
            printf("SQLCODE [%d] icar_series[%s]\n",SQLCODE,icar_series);
            #endif
            if (NOT_FOUND)
            {
                $DECLARE CA_OPT2D1 CURSOR FOR
                  SELECT icar_series,drate
                    INTO $icar_series
                    FROM ca_car_model
                   WHERE ibrand=$brandi
                     AND ipro_year=(SELECT MAX(ipro_year)
                                      FROM ca_car_model
                                     WHERE ibrand=$brandi)
                   ORDER BY drate DESC;
                $OPEN CA_OPT2D1;
                $FETCH CA_OPT2D1;
                if (NOT_FOUND)
                     strcpy(icar_series,'10');
                /*return M_CA_NBRAND;*/
                $CLOSE CA_OPT2D1;
                $FREE CA_OPT2D1;
            }
            $CLOSE CA_OPT211;
            $FREE CA_OPT211;

            strcpy(icar_series, trim(icar_series));
            strcpy(ins_type, trim(ins_type));

            if( iins == 128){

                injured_cover = INS_ptr->injured_cover;
                death_cover   = INS_ptr->death_cover;
                damage_cover  = INS_ptr->damage_cover;

                /* �s�t����w���O�I���B���o����Q�O�I�T���{��(��ګO�B)��75% */
                /* ���ѵs�D�I���²v�h��@�~(�Ӥ��O�T�w���H0.75) modify by 061476 (1080218008_SC2) */
                if( damage_cover > premium_11 * (1-pdep_rate_year)){
	                return M_CA_OVER_75_PERCENT;
	        }

                mpremium      = 0;
                pextra_charge = 0;

                find_flag     = 0;
                for (chk_count=0 ; chk_count<max_cover_prem ; chk_count++)
                {
                     if ((strcmp(cover_vs_prem[chk_count].icar_type, icar_series) == 0) &&
                         (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                         (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                         (cover_vs_prem[chk_count].mcoverage1 == injured_cover)&&
                         (cover_vs_prem[chk_count].mcoverage2 == damage_cover)&&
                         (cover_vs_prem[chk_count].mdeduct == cal_deduct))
                     {
                          find_flag     = 1;
                          mpremium      = cover_vs_prem[chk_count].mpremium;
                          pextra_charge = cover_vs_prem[chk_count].pextra_charge;
                          break;
                     }
                }

	            if (find_flag==0)  return M_CA_NCOVER_PREM;

	            INS_ptr->ins_premium     = mpremium * short_prate;
	    }

            INS_ptr->bef_ins_premium=INS_ptr->ins_premium;
            goto step_9_e_iii;
        }

        /* P/Q���ڥ[�O�Y�� add by 061476(1071226006_SC3) */
        if ((f_provision_P == 'Y')||(f_sug_P == 'Y'))
        {
        	$EXECUTE pre_ca_add_prov
        	INTO $provision_P
        	USING $fcar_class_tmp,$ins_type,"P","0",$frate_chk;

        	if (NOT_FOUND) provision_P = 1.0;
        }
        else
            provision_P = 1.0;

        if (f_provision_Q == 'Y')
        {
        	$EXECUTE pre_ca_add_prov
        	INTO $provision_Q
        	USING $fcar_class_tmp,$ins_type,"Q","0",$frate_chk;

        	if (NOT_FOUND) provision_Q = 1.0;
        }
        else
            provision_Q = 1.0;

        if (f_provision_M == 'Y')
        {
        	$EXECUTE pre_ca_add_prov
        	INTO $provision_M
        	USING $fcar_class_tmp,$ins_type,"M","0",$frate_chk;

        	if (NOT_FOUND) provision_M = 1.0;
        }
        else
            provision_M = 1.0;

        if (strstr(tmp_provision,"K;") != NULL)
        {
        	damage_cover  = INS_ptr->damage_cover;
        	$EXECUTE pre_ca_add_prov
        	INTO $provision_K
        	USING $car_typei,$ins_type,"K",$damage_cover,$frate_chk;

        	if (NOT_FOUND) provision_K = 1.0;
        }
        else
            provision_K = 1.0;

        if (strstr(tmp_provision,"L;") != NULL)
        {
        	damage_cover  = INS_ptr->damage_cover;
        	$EXECUTE pre_ca_add_prov
        	INTO $provision_L
        	USING $car_typei,$ins_type,"L","0",$frate_chk;

        	if (NOT_FOUND) provision_L = 1.0;
        }
        else
            provision_L = 1.0;

        /* Y���ڥ[�O�Y�� (1130827011_C03) */
        if (f_provision_Y == 'Y')
        {
        	if ((iins==1) || (iins==5) || (iins==9) || (iins==198) ||
        	    (iins==201) || (iins==205) || (iins==209))
        	{
        	    	if (mequipment > 0)
        			pmequipment_rate = d45((mequipment/(car_price - mequipment)),4);

        		$SELECT first 1 coefficient
        		   INTO $provision_Y
        		   FROM ca_add_provision
        		  WHERE icar_type = $car_typei
        		    AND iins_type = '*'
        		    AND provision = 'Y'
        		    AND mexpense <= $pmequipment_rate
        		    AND drate     = (SELECT drate
        		                       FROM ca_rate_date
        		                      WHERE icode  = $frate_chk
        		                        AND itable = 'ca_add_provision')
        		  ORDER BY mexpense desc;

        		if (NOT_FOUND) provision_Y = 1.0;
        	}else
        		provision_Y = 1.0;
        }
        else
            provision_Y = 1.0;



        /*** e.(i) ***/

        if (*fcal_way != '1' && *fcal_way != '4') goto step_9_e_ii;

        /* 1:�O�v�ɭp��O�O */

        if (iins==1 || iins==5 || iins==9 || iins==8 || iins==85|| iins==105 ||
           iins==118 || iins==120 || iins==122 || iins==125 || iins==126 ||
           iins==201 || iins==205 || iins==209)
        {
            if (strcmp(cal_car_id,"05")==0 || strcmp(cal_car_id,"06")==0 ||
                strcmp(cal_car_id,"09")==0 || strcmp(cal_car_id,"10")==0 ||
                strcmp(cal_car_id,"20")==0)
            {
                wk_qpt=qpt;
            }
            else
            {
                wk_qpt=0;
            }
        }
        else
        {
            wk_qpt=0;
        }
        #ifdef PRINTF_FLAG
        printf("Cal_ins_prem_302()####### fpt[%s] qpt[%f] wk_qpt[%f]\n",fpt,qpt,wk_qpt);
        #endif

        /* get �򥻫O�O,�p��v,�p���I��,������� */
        if (fpt[0]=='P')
        {
            prate_1       = 0;
            mprem         = 0;
            ical_ins[0]   = '\0';
            fcal_class[0] = '\0';
            pextra_charge = 0.00;
            find_flag     = 0;

            for (chk_count=0 ; chk_count<max_ca_rate ; chk_count++)
            {
                 if ((strcmp(ca_rate[chk_count].icar_type, cal_car_id)==0) &&
                     (strcmp(ca_rate[chk_count].iins_type, ins_type)==0) &&
                     (strcmp(ca_rate[chk_count].frate, frate_chk)==0) &&
                     (ca_rate[chk_count].mdeduct == cal_deduct) &&
                     (ca_rate[chk_count].qpt_bgn <= wk_qpt) &&
                     (ca_rate[chk_count].qpt_end >= wk_qpt))
                 {
                      find_flag     = 1;

                      prate_1       = ca_rate[chk_count].prate;
                      mprem         = ca_rate[chk_count].mprem;
                      pextra_charge = ca_rate[chk_count].pextra_charge;

                      strcpy(ical_ins   , ca_rate[chk_count].ical_ins);
                      strcpy(fcal_class , ca_rate[chk_count].fcal_class);

                      break;
                 }
            }
            if (iins==111)
            {
                pextra_charge = INS_ptr->pextra_charge;

	        for (chk_count=0 ; chk_count<max_ca_rate ; chk_count++)
                {
                    if ((strcmp(ca_rate[chk_count].icar_type, icar_type)==0) &&
                        (strcmp(ca_rate[chk_count].iins_type, ins_type)==0) &&
                        (strcmp(ca_rate[chk_count].frate, frate_chk)==0) &&
                        (ca_rate[chk_count].mdeduct == 1) &&
                        (ca_rate[chk_count].qpt_bgn <= wk_qpt) &&
                        (ca_rate[chk_count].qpt_end >= wk_qpt))
                    {
                          find_flag     = 1;
                          prate_1       = ca_rate[chk_count].prate;
                          mprem         = ca_rate[chk_count].mprem;
                          strcpy(ical_ins   , ca_rate[chk_count].ical_ins);
                          strcpy(fcal_class , ca_rate[chk_count].fcal_class);
                          break;
                    }
                }
                if (find_flag==0)
                {
                	/* return M_CA_NCOVER_PREM;*/
	                prate_1 = mprem = 0.0;
	        }

                for (chk_count=0 ; chk_count<max_ca_rate ; chk_count++)
                {
                    if ((strcmp(ca_rate[chk_count].icar_type, icar_type)==0) &&
                        (strcmp(ca_rate[chk_count].iins_type, ins_type)==0) &&
                        (strcmp(ca_rate[chk_count].frate, frate_chk)==0) &&
                        (ca_rate[chk_count].mdeduct == 2) &&
                        (ca_rate[chk_count].qpt_bgn <= wk_qpt) &&
                        (ca_rate[chk_count].qpt_end >= wk_qpt))
                    {
                        find_flag     = 1;
                        prate_1_sec   = ca_rate[chk_count].prate;
                        mprem         = ca_rate[chk_count].mprem;
                        strcpy(ical_ins   , ca_rate[chk_count].ical_ins);
                        strcpy(fcal_class , ca_rate[chk_count].fcal_class);
                        break;
                    }
                }
                if (find_flag==0)
                {
                	/* return M_CA_NCOVER_PREM;*/
	                prate_1_sec = mprem = 0.0;
	        }
            }
        }
        else
        {
            if ((strcmp(cal_car_id,"06")==0 || strcmp(cal_car_id,"10")==0 ||
                 strcmp(cal_car_id,"20")==0) &&
                (iins==1 || iins==5 || iins == 9 || iins == 8 || iins == 85 ||
                 iins == 105 || iins == 125 || iins == 126 || iins==201 || iins==205 || iins == 209))
            {
                prate_1       = 0;
                mprem         = 0;
                ical_ins[0]   = '\0';
                fcal_class[0] = '\0';
                pextra_charge = 0.00;
                find_flag     = 0;

                for (chk_count=0 ; chk_count<max_ca_rate ; chk_count++)
                {
                     if ((strcmp(ca_rate[chk_count].icar_type, cal_car_id)==0) &&
                         (strcmp(ca_rate[chk_count].iins_type, ins_type)==0) &&
                         (strcmp(ca_rate[chk_count].frate, frate_chk)==0) &&
                         (ca_rate[chk_count].mdeduct == cal_deduct) &&
                         (ca_rate[chk_count].qpt_bgn <  wk_qpt) &&
                         (ca_rate[chk_count].qpt_end >= wk_qpt))
                     {
                          find_flag     = 1;

                          prate_1       = ca_rate[chk_count].prate;
                          mprem         = ca_rate[chk_count].mprem;
                          pextra_charge = ca_rate[chk_count].pextra_charge;

                          strcpy(ical_ins   , ca_rate[chk_count].ical_ins);
                          strcpy(fcal_class , ca_rate[chk_count].fcal_class);

                          break;
                     }
                }
            }
            else
            {
                prate_1       = 0;
                mprem         = 0;
                ical_ins[0]   = '\0';
                fcal_class[0] = '\0';
                pextra_charge = 0.00;
                find_flag     = 0;

                for (chk_count=0 ; chk_count<max_ca_rate ; chk_count++)
                {
                     if ((strcmp(ca_rate[chk_count].icar_type, cal_car_id)==0) &&
                         (strcmp(ca_rate[chk_count].iins_type, ins_type)==0) &&
                         (strcmp(ca_rate[chk_count].frate, frate_chk)==0) &&
                         (ca_rate[chk_count].mdeduct == cal_deduct) &&
                         (ca_rate[chk_count].qpt_bgn <= wk_qpt) &&
                         (ca_rate[chk_count].qpt_end >= wk_qpt))
                     {
                          find_flag     = 1;

                          prate_1       = ca_rate[chk_count].prate;
                          mprem         = ca_rate[chk_count].mprem;
                          pextra_charge = ca_rate[chk_count].pextra_charge;

                          strcpy(ical_ins   , ca_rate[chk_count].ical_ins);
                          strcpy(fcal_class , ca_rate[chk_count].fcal_class);

                          break;
                     }
                }
            }
        }

        if (find_flag == 0)  /* NOT FOUND */
        {
            prate_1 = 0;
            mprem   = 0;
            pextra_charge = 0.00;
            /*return M_CA_NRATE;*/
        }
        prate_1=prate_1/100.0;

        #ifdef PRINTF_FLAG
        printf("cal_car_id[%s],ins_type[%s],cal_deduct[%ld],wk_qpt[%f],mprem[%f]\n", cal_car_id,ins_type,cal_deduct,wk_qpt,mprem);
        printf("Cal_ins_prem()####### prate_1[%f]\n",prate_1);
        #endif

        /* ical_ins:�p���I��, fcal_class:�O�B�O�O�O */
        code = Calculate_cover_prem(INS_ptr,ical_ins,fcal_class,iins);
        if (code != SUCCESS) return code;
        goto step_9_e_iii;

        /*** e.(ii) ***/
        step_9_e_ii:
        if (*fcal_way != '2') goto step_9_e_iii; /* 2:�O�B�O�O�ɱo��O�O */
        /* �ѳ��'��'�אּ���'�d' */

        injured_cover = INS_ptr->injured_cover;
        death_cover   = INS_ptr->death_cover;
        damage_cover  = INS_ptr->damage_cover;

        #ifdef PRINTF_FLAG
        printf("Cal_ins_prem()####### inj[%ld] dea[%ld] dam[%ld]\n",injured_cover,death_cover,damage_cover);
        printf("Trace3 -- plia_acc = [%f] \n",  plia_acc);
        #endif

        if (!IsBlankNull(isame_ins))
        {    /* 31,32,71,72,77,78,109 */
             if (iins == 71 || iins == 72)  /* 960814,71�B72�I�אּ�����ۭt�B���� */
             {
                 mpremium      = 0;
                 pextra_charge = 0;

                 find_flag     = 0;
                 for (chk_count=0 ; chk_count<max_cover_prem ; chk_count++)
                 {
                      if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                          (cover_vs_prem[chk_count].mcoverage2 == damage_cover)&&
                          (cover_vs_prem[chk_count].mdeduct == cal_deduct))
                      {
                           find_flag     = 1;
                           mpremium      = cover_vs_prem[chk_count].mpremium;
                           pextra_charge = cover_vs_prem[chk_count].pextra_charge;
                           break;
                      }
                 }


		 /* 100.01.04, �f�B�~���[����C */
		 if (iins == 71)
		 {
                     /* 101.06.25 */
                     if(strstr(tmp_provision,"C;") != NULL)
                     {
		         $EXECUTE pre_ca_add_prov
			     INTO $provision_C
			    USING $car_typei,"71","C","0",$frate_chk;

			 if (NOT_FOUND)
			 {
			     provision_C = 1.0;
			 }
			 else
			 {
			     provision_C += 1.0;
			 }

			 printf("Trace -- provision_C = [%f] \n",  provision_C);
		     }
		     else
		     {
		         provision_C = 1.0;
		     }
		 }
             }
             else if (iins==31 || iins==32 || iins==231 || iins==232 ||
                      iins==77 || iins==78 || iins==133 || iins==134 ||
                      iins==149|| iins==249 || iins==531 || iins==532)
             {
             	     #ifdef PRINTF_FLAG
             	     printf("Cal_ins_prem()#######31,32,77,78 car[%s] inj[%ld] dam[%ld]\n",cal_car_id,injured_cover,damage_cover);
             	     printf("Cal_ins_prem()#######3132,77,78 cal_car_id[%s] ins_tp[%s]\n",cal_car_id,ins_type);
             	     printf("Cal_ins_prem()#######3132,77,78 inj[%d] dam[%d]\n",injured_cover,damage_cover);
             	     printf("31313131313131[%c],sug_type[%d],injured_cover[%d]\n", f_30_change,sug_type,injured_cover);
             	     #endif

             	     #ifdef PRINTF_FLAG
             	     printf("Cal_ins_prem()#######iins=[%d]3132 cal_car_id[%s]\n",iins,cal_car_id);
             	     printf("Cal_ins_prem()#######3132,77,78 ins_type[%s] \n",ins_type);
             	     printf("Cal_ins_prem()#######3132,77,78 frate_chk[%s]\n",frate_chk);
             	     printf("Cal_ins_prem()#######3132,77,78 injured_cover[%d]\n",injured_cover);
             	     printf("Cal_ins_prem()#######3132,77,78 damage_cover[%d]\n",damage_cover);
             	     printf("Cal_ins_prem()#######3132,77,78 cal_deduct[%d]\n",cal_deduct);
             	     printf("max_cover_prem 3132,77,78[%d]\n",max_cover_prem);
             	     #endif

             	     /* 101.11,�O�d32�I�ثO�B, ��29�I�ثO�O�p��ϥ�   */
             	     /* 32���O�B3���ѵ�124�I�حp��O�B1�ϥ� add by sylvia 104.06.12 (1040302007_C6) */
             	     /* �O�d134�I�ثO�B��29�I�بϥ� add by sylvia 104.11.12 (1041030001_C4) */
             	     if ((iins==32)||(iins==232)||(iins==134)){
             	     	if (sug_type == 0) {
             	     		mcover1_32_ori = damage_cover;
             	     	}else if (sug_type == 1) {
             	     		mcover1_32_sug = damage_cover;
             	     	}
             	     }

             	     /* �O�d31�I�ثO�B1��109�I�ط��O�B1�ϥ� */
             	     /* �O�d31�I�ثO�B1��124�I�حp��ۭt�B�ϥ� add by sylvia 104.06.12 (1040302007_C6) */
             	     /* �O�d133�I�ثO�B��29�I�بϥ� add by sylvia 104.11.12 (1041030001_C4) */
             	     if ((iins==31)||(iins==231)||(iins==133)){
             	     	if (sug_type == 0) {
             	     		mcover1_109_ori = injured_cover;
             	     		mcover3_109_ori = damage_cover;
             	     	}else if (sug_type == 1) {
             	     		mcover1_109_sug = injured_cover;
             	     		mcover3_109_sug = damage_cover;
             	     	}
             	     }

                     mpremium      = 0;
                     pextra_charge = 0;

                     find_flag     = 0;
                     for (chk_count=0;chk_count<max_cover_prem;chk_count++)
                     {
                          if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                              (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                              (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                              (cover_vs_prem[chk_count].mcoverage1 == injured_cover) &&
                              (cover_vs_prem[chk_count].mcoverage2 == damage_cover)  &&
                              (cover_vs_prem[chk_count].mdeduct == cal_deduct))
                          {
                               find_flag     = 1;
                               mpremium      = cover_vs_prem[chk_count].mpremium;
                               pextra_charge = cover_vs_prem[chk_count].pextra_charge;

                               #ifdef PRINTF_FLAG
                               printf("2.Cal_ins_prem()-----3132,77,78 mpremium[%f]\n",mpremium);
                               #endif

                               break;
                          }
                     }

                     if( find_flag == 0 )
                     {
                     	  damage_cover = injured_cover * 2;
                     	  /* printf("---> injured_cover[%ld]  ###########################################################\n",injured_cover);
                           printf("---> damage_cover[%ld]  ###########################################################\n",damage_cover);
                           printf("---> cal_deduct[%ld]  ###########################################################\n",cal_deduct); */

                          for (chk_count=0;chk_count<max_cover_prem;chk_count++)
                          {
                              if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                                  (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                                  (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                                  (cover_vs_prem[chk_count].mcoverage1 == injured_cover) &&
                                  (cover_vs_prem[chk_count].mcoverage2 == damage_cover)  &&
                                  (cover_vs_prem[chk_count].mdeduct == cal_deduct))
                              {
                                   find_flag     = 1;
                                   mpremium      = cover_vs_prem[chk_count].mpremium;
                                   pextra_charge = cover_vs_prem[chk_count].pextra_charge;
                                   INS_ptr->damage_cover = damage_cover;
                                   break;
                               }
                          }
                     }
             }
             else if (iins==131 || iins==132 || iins==331 || iins==332) /* �p�{���M�ݫO�� */
             {
                  mpremium      = 0;
                  pextra_charge = 0;
                  find_flag     = 0;
                  for (chk_count=0;chk_count<max_cover_prem;chk_count++)
                  {
                     if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                         (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                         (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                         (cover_vs_prem[chk_count].mcoverage1 == injured_cover) &&
                         (cover_vs_prem[chk_count].mcoverage2 == damage_cover)  &&
                         (cover_vs_prem[chk_count].mdeduct == cal_deduct))
                     {
                     	find_flag     = 1;
                        mpremium      = cover_vs_prem[chk_count].mpremium;
                        pextra_charge = cover_vs_prem[chk_count].pextra_charge;
                        deduct_rate = (double)(cover_vs_prem[chk_count].msi_premium)*0.01;

                        #ifdef PRINTF_FLAG
                        printf("line:7773�p�{��==>131,132==>deduct_rate=[%f]\n",deduct_rate);
                        printf("cover_vs_prem[chk_count].msi_premium/100=[%f]\n",cover_vs_prem[chk_count].msi_premium/100);
                        printf("cover_vs_prem[chk_count].msi_premium=[%ld]\n",cover_vs_prem[chk_count].msi_premium);
                        printf("mpremium=[%f]\n",mpremium);
                        #endif

                        break;
                     }
                  }

                  if( find_flag == 0 )
                  {
                     damage_cover = injured_cover * 2;
                     for (chk_count=0;chk_count<max_cover_prem;chk_count++)
                     {
                        if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                            (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                            (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                            (cover_vs_prem[chk_count].mcoverage1 == injured_cover) &&
                            (cover_vs_prem[chk_count].mcoverage2 == damage_cover)  &&
                            (cover_vs_prem[chk_count].mdeduct == cal_deduct))
                        {
                           find_flag     = 1;
                           mpremium      = cover_vs_prem[chk_count].mpremium;
                           pextra_charge = cover_vs_prem[chk_count].pextra_charge;
                           deduct_rate = cover_vs_prem[chk_count].msi_premium/100;
                           INS_ptr->damage_cover = damage_cover;

                           #ifdef PRINTF_FLAG
                           printf("mpremium=[%f]\n",mpremium);
                           #endif

                           break;
                        }
                     }
                  }
             }
             else if (iins==29) /* 101.11, 29�I�ثO�O�p��ק�   */
             {
                 #ifdef PRINTF_FLAG
                 printf("3:29292929292929[%c],ins_type[%d]\n", f_30_change,iins);
                 #endif

                 mcover1_32 = 0;
                 if (sug_type == 0 ){
                 	mcover1_32 = mcover1_32_ori;
                 }else if (sug_type == 1 ){
                 	mcover1_32 = mcover1_32_sug;
                 }

                 #ifdef PRINTF_FLAG
                 printf("trace sug_type[%d], mcover1_32[%ld]\n ", sug_type, mcover1_32);
                 #endif

                 if ((mcover1_32 >= 200000) && (mcover1_32 < 500000))
                 	mcover1_32 = 200000;
                 else if ((mcover1_32 >= 500000) && (mcover1_32 <= 1000000))
                 	mcover1_32 = 500000;
                 else	mcover1_32 = 0;

                 mpremium      = 0;
                 pextra_charge = 0;

                 find_flag     = 0;
                 #ifdef PRINTF_FLAG
                 printf("iins 29 cal_car_id=[%s] frate_chk=[%s] damage_cover=[%ld] cal_deduct=[%ld]\n",cal_car_id,frate_chk,damage_cover,cal_deduct);
                 #endif

                 for (chk_count=0 ; chk_count<max_cover_prem ; chk_count++)
                 {
                      if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                          (cover_vs_prem[chk_count].mcoverage1 == mcover1_32) &&
                          (cover_vs_prem[chk_count].mcoverage2 == damage_cover) &&
                          (cover_vs_prem[chk_count].mdeduct == cal_deduct))
                      {
                           find_flag     = 1;
                           mpremium      = cover_vs_prem[chk_count].mpremium;
                           pextra_charge = cover_vs_prem[chk_count].pextra_charge;

                           break;
                      }
                 }
             }
             else if (iins==30)
             {
                 #ifdef PRINTF_FLAG
                 printf("3:30303030303030[%c],ins_type[%d]\n", f_30_change,iins);
                 #endif

                 if ( sug_type == 1 && f_30_change == 'Y'){
                 	#ifdef PRINTF_FLAG
                 	printf("1:cal_deduct=INS_ptr->deduct[%ld]\n", cal_deduct=INS_ptr->deduct);
                 	#endif

                 	sprintf_s(str_deduct,sizeof str_deduct,"%ld", cal_deduct);
                 	if( str_deduct[0] == '2')
                 	{
                 		str_deduct[0] = '1';
                 		INS_ptr->deduct = atoi( str_deduct);
                 		cal_deduct=INS_ptr->deduct;
                 	}
                 	#ifdef PRINTF_FLAG
                 	printf("2:cal_deduct=INS_ptr->deduct[%ld]\n", cal_deduct=INS_ptr->deduct);
                 	#endif
                 }

                 /* 30�I�ؼW�[����2�~���A�O�B�O�O�ɦۭt�B��ܤ覡��[�ۭt�B+�~��] add by 061476 (1100415003_SC6) */
                 deduct_30     = cal_deduct * 10 + 1;
                 deduct_30_sec = cal_deduct * 10 + 2;

                 mpremium      = 0;
                 mpremium_sec  = 0;
                 pextra_charge = 0;
                 find_flag     = 0;
                 #ifdef PRINTF_FLAG
                 printf("iins 30 cal_car_id=[%s] frate_chk=[%s] damage_cover=[%ld] cal_deduct=[%ld]\n",cal_car_id,frate_chk,damage_cover,cal_deduct);
                 #endif

                 for (chk_count=0 ; chk_count<max_cover_prem ; chk_count++)
                 {
                      if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                          (cover_vs_prem[chk_count].mcoverage2 == damage_cover) &&
                          (cover_vs_prem[chk_count].mdeduct == deduct_30))
                      {
                           find_flag     = 1;
                           mpremium      = cover_vs_prem[chk_count].mpremium;
                           break;
                      }
                 }

                 /* �����h��2�~���O�O */
                 if (ISMOT(cal_car_id))
                 {
                 	for (chk_count=0 ; chk_count<max_cover_prem ; chk_count++)
                 	{
                 		if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                 		    (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                 		    (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                 		    (cover_vs_prem[chk_count].mcoverage2 == damage_cover) &&
                 		    (cover_vs_prem[chk_count].mdeduct == deduct_30_sec))
                 		{
                 			find_flag     = 1;
                 			mpremium_sec  = cover_vs_prem[chk_count].mpremium;
                 			break;
                 		}
                 	}
                 }
             }
             else if (iins==301 || iins==302 || iins==530) /* �s�W301�I�� add by sylvia 106.04.17 (1060329005_C4) */
             {
                 for (chk_count=0 ; chk_count<max_cover_prem ; chk_count++)
                 {
                      if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                          (cover_vs_prem[chk_count].mcoverage1 == injured_cover) &&
                          (cover_vs_prem[chk_count].mcoverage2 == damage_cover) &&
                          (cover_vs_prem[chk_count].mdeduct == cal_deduct))
                      {
                           find_flag     = 1;
                           mpremium      = cover_vs_prem[chk_count].mpremium;
                           pextra_charge = cover_vs_prem[chk_count].pextra_charge;

                           break;
                      }
                 }

             }
             else if (iins==124) /* 124�I�ثO�O�p�� add by sylvia 104.06.12 (1040302007_C6)   */
             {
             	 mcover1_32 = 0;
                 mdeduct_124 = 0;
                 mcover1_124 = 0;

                 if (sug_type == 0 ){
                 	mcover1_32 = mcover1_32_ori;
	                mdeduct_124 = mcover1_109_ori;
	         }else if (sug_type == 1 ){
	                mcover1_32 = mcover1_32_sug;
	                mdeduct_124 = mcover1_109_sug;
	         }

	         /* 124�O�B1=32�I�بƬG�O�B�h 20�U/50�U, �O���b car_code.kind = 32_124  */
	         if ((mcover1_32 > 1000000) || (mcover1_32 < 200000))
	         	mcover1_32 = 0;
	         else
	         {
	         	$select max(cast(detail2 as int)) into $mcover1_124
                           from car_code
                          where kind = 'RN'
                            and detail = '32_124'
                            and cast(detail2 as int)  <= $mcover1_32;

                        if(SQLCODE == SQLNOTFOUND) mcover1_124 = 0;
                 }

                 /* 124�ۭt�B=31�I����˫O�B�U�� */
                 $select engname into $mdeduct_124
                    from car_code
                   where kind = 'RN' and detail = '31_124'
                     and cast(detail2 as int) =
                        (select max(cast(detail2 as int))
                    from car_code
                   where kind     = 'RN'
                     and detail = '31_124'
                     and cast(detail2 as int) <= $mdeduct_124) ;

                 if(SQLCODE == SQLNOTFOUND) mdeduct_124 = 0;
                 INS_ptr->deduct = mdeduct_124;
                 mpremium      = 0;
                 pextra_charge = 0;

                 find_flag     = 0;

                 for (chk_count=0 ; chk_count<max_cover_prem ; chk_count++)
                 {
                      if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                          (cover_vs_prem[chk_count].mcoverage1 == mcover1_124) &&
                          (cover_vs_prem[chk_count].mcoverage2 == damage_cover) &&
                          (cover_vs_prem[chk_count].mdeduct == mdeduct_124))
                      {
                           find_flag     = 1;
                           mpremium      = cover_vs_prem[chk_count].mpremium;
                           pextra_charge = cover_vs_prem[chk_count].pextra_charge;
                           break;
                      }
                 }
             }
             else if (iins == 38 || iins == 39)
             {
                 /* ����1:�H�ۭt�B(���{��||����)���o�򥻯«O�O
                 /* ����2:�ۭt�B205:�e2�X�����{��, ��1�X������.
                 /* ����3:���֭p�� = �s�y�~ �� �_�O�~
                 /* ����4:����5�~�H�W--���t5�~�� ( > 5)
                          ����5�~�H�U--�t5�~ ( <= 5)
                          �]�W,�Y���֤��~, ���H�ۭt�B=200�p��O�O */
                 iCar_age = atoi(cm_eyear_str(dply_begin)) - atoi(pro_year); /* �D���ϴ��I�ب��� */
                 if ( iCar_age <= 0)   iCar_age = 1 ; /* ���~��1�~ */
                 else if ( iCar_age >= 9)   iCar_age = 9 ; /* �j��9�~��9�~ */

                 qday = INS_ptr->qday;
                 iCar_age = qday * 10 + iCar_age;
                 /* printf("iCar_age=[%d]\n",iCar_age);
                 printf("Trace -- qday = [%ld] \n",  qday); */

                 /* �ק�O�O�p��W�h modify by 061476 108.07.17 (1080627011_SC1) */
                 find_flag     = 0;
                 $SELECT a.mpremium, a.pextra_charge/100
                    INTO $mpremium, $pextra_charge
                    FROM cover_vs_premium a
                   WHERE a.icar_type=$cal_car_id
                     AND a.iins_type=$ins_type
                     AND a.mcoverage1 = $injured_cover
                     AND a.mcoverage2 = $damage_cover
                     AND drate=(SELECT drate
                                  FROM ca_rate_date
                                 WHERE icode=$frate
                                   AND itable='cover_vs_premium')
                     AND mdeduct = nvl((select max(mdeduct) from cover_vs_premium
                                         where icar_type = a.icar_type
                                           and iins_type = a.iins_type
                                           and mcoverage1 = a.mcoverage1
                                           and mcoverage2 = a.mcoverage2
                                           and drate = a.drate
                                           and mdeduct < $iCar_age
                                           and mdeduct >= $qday * 10),0);
                 if(SQLCODE == SQLNOTFOUND){
                 	 printf("Trace -- 38 39 ins SQLNOTFOUND \n");
                 	 printf("Trace -- cal_car_id = [%s] \n",  cal_car_id);
                 	 printf("Trace -- ins_type = [%s] \n",  ins_type);
                 	 printf("Trace -- injured_cover = [%ld] \n",  injured_cover);
                 	 printf("Trace -- damage_cover = [%ld] \n",  damage_cover);
                 	 printf("Trace -- frate = [%s] \n",  frate);
                 	 printf("Trace -- iCar_age = [%d] \n",  iCar_age);

                 	 return M_CA_NCOVER_PREM;  /*108.07.17*/

                 }else{
                 	 find_flag = 1;
                 }
             }
             else if (iins==109)
             {
                 #ifdef PRINTF_FLAG
                 printf("Cal_ins_prem()#######109 mcover1_109_ori[%ld] mcover1_109_sug[%ld]\n",mcover1_109_ori,mcover1_109_sug);
                 printf("Cal_ins_prem()#######109 inj[%d] dam[%d]\n",injured_cover,damage_cover);
                 #endif

                 mpremium      = 0;
                 pextra_charge = 0;
                 find_flag     = 0;

                 if (sug_type == 0 )
                 {
                     /* ����109�I��[�ݼo�W�B���[����]��ĳ��O���O�B�վ� modify by sylvia 106.01.16
                        (1051215003_C1) */
                     injured_cover = mcover1_109_ori;
                     INS_ptr->death_cover = death_cover;
                     INS_ptr->damage_cover = death_cover;
                 }
                 else
                 {
                     /* injured_cover = mcover1_109_sug; */

                     /* �ק�109�J�p�W�h--��ĳ��O���O�B��(�O�B1+�O�B2)<=31�I�ثO�B3���̤j��O���B */
                     /* $select first 1 mcoverage2 into $death_cover
                        from cover_vs_premium
                        where iins_type = '109'
                          and icar_type = $cal_car_id
                          and drate = (SELECT drate  FROM ca_rate_date
                                        WHERE icode=$frate_chk
                                          AND itable='cover_vs_premium')
                          and mcoverage1 = $mcover1_109_sug
                          and (mcoverage1+mcoverage2) <= $mcover3_109_sug
                        order by mcoverage2 desc;

                     if (NOT_FOUND)
                           death_cover = INS_ptr->death_cover;
                     else
                     {
                        INS_ptr->death_cover = death_cover;
                        INS_ptr->damage_cover = death_cover;
                     } */

                    /* ����109�I��[�ݼo�W�B���[����]��ĳ��O���O�B�վ� modify by sylvia 106.01.16
                        (1051215003_C1) */
                    injured_cover = mcover1_109_ori;
                    INS_ptr->death_cover = death_cover;
                    INS_ptr->damage_cover = death_cover;
                 }

                 for (chk_count=0;chk_count<max_cover_prem;chk_count++)
                 {
                       if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                           (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                           (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                           (cover_vs_prem[chk_count].mcoverage1 == injured_cover) &&
                           (cover_vs_prem[chk_count].mcoverage2 == death_cover))
                       {
                            find_flag     = 1;
                            mpremium      = cover_vs_prem[chk_count].mpremium;
                            pextra_charge = cover_vs_prem[chk_count].pextra_charge;
                            #ifdef PRINTF_FLAG
                              printf("2.Cal_ins_prem()-----109 mpremium[%f]\n",mpremium);
                            #endif
                            break;
                       }
                 }
                 if( find_flag == 0 )
                     mpremium=0;
             }
             else if (iins==113)
             {
             	mpremium      = 0;
             	pextra_charge = 0;
             	pextra_charge = INS_ptr->pextra_charge;
             	find_flag     = 0;

                /* 113�B114�I�ؼW�[�ۭt�B�A�O�B�O�O�ɦۭt�B��ܤ覡��[�ۭt�B+�~��] add by 061476
                   107.04.24 (1070313002_SC4) */
                deduct_113     = cal_deduct * 10 + 1;
                deduct_113_sec = cal_deduct * 10 + 2;

                for (chk_count=0;chk_count<max_cover_prem;chk_count++)
                {
                    if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                        (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                        (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                        (cover_vs_prem[chk_count].mcoverage1 == injured_cover) &&
                        (cover_vs_prem[chk_count].mcoverage2 == damage_cover) &&
                        (cover_vs_prem[chk_count].mdeduct == deduct_113))
                    {
                        find_flag     = 1;
                        mpremium      = cover_vs_prem[chk_count].mpremium;
                        break;
                    }
                }
                if (find_flag==0)
                {
                	/* return M_CA_NCOVER_PREM;*/
	                mpremium = 0.0;
	        }

                for (chk_count=0;chk_count<max_cover_prem;chk_count++)
                {
                    if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                        (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                        (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                        (cover_vs_prem[chk_count].mcoverage1 == injured_cover) &&
                        (cover_vs_prem[chk_count].mcoverage2 == damage_cover) &&
                        (cover_vs_prem[chk_count].mdeduct == deduct_113_sec))
                    {
                        find_flag     = 1;
                        mpremium_sec  = cover_vs_prem[chk_count].mpremium;
                        break;
                    }
                }
                if (find_flag==0)
                {
                	/* return M_CA_NCOVER_PREM;*/
	                mpremium_sec = 0.0;
	        }
            }
            else if (iins==114)
            {
                mpremium      = 0;
                pextra_charge = 0;
                pextra_charge = INS_ptr->pextra_charge;
                find_flag     = 0;

                /* 113�B114�I�ؼW�[�ۭt�B�A�O�B�O�O�ɦۭt�B��ܤ覡��[�ۭt�B+�~��] add by 061476
                   107.04.24 (1070313002_SC4) */
                deduct_113     = cal_deduct * 10 + 1;
                deduct_113_sec = cal_deduct * 10 + 2;

                for (chk_count=0;chk_count<max_cover_prem;chk_count++)
                {
                    if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                        (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                        (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                        (cover_vs_prem[chk_count].mcoverage2 == damage_cover) &&
                        (cover_vs_prem[chk_count].mdeduct == deduct_113))
                    {
                        find_flag     = 1;
                        mpremium      = cover_vs_prem[chk_count].mpremium;
                        break;
                    }
                }
                if (find_flag==0)
                {
                	/* return M_CA_NCOVER_PREM;*/
	                mpremium = 0.0;
	        }

                for (chk_count=0;chk_count<max_cover_prem;chk_count++)
                {
                    if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                        (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                        (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                        (cover_vs_prem[chk_count].mcoverage2 == damage_cover) &&
                        (cover_vs_prem[chk_count].mdeduct == deduct_113_sec))
                    {
                        find_flag     = 1;
                        mpremium_sec  = cover_vs_prem[chk_count].mpremium;
                        break;
                    }
                }
                if (find_flag==0)
                {
                	/* return M_CA_NCOVER_PREM;*/
	                mpremium_sec = 0.0;
	        }
             }
             else
             {
                 mpremium      = 0;
                 pextra_charge = 0;

                 find_flag     = 0;
                 for (chk_count=0 ; chk_count<max_cover_prem ; chk_count++)
                 {
                      if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                          (cover_vs_prem[chk_count].mcoverage2 == damage_cover) &&
                          (cover_vs_prem[chk_count].mdeduct == cal_deduct))
                      {
                           find_flag     = 1;
                           mpremium      = cover_vs_prem[chk_count].mpremium;
                           pextra_charge = cover_vs_prem[chk_count].pextra_charge;
                           break;
                      }
                 }
             }

             if (find_flag == 0)
                 mpremium=0;

             #ifdef PRINTF_FLAG
             printf("Cal_ins_prem()#######iins=[%d]3132,77,78 mprem[%f]\n",iins,mpremium);
             #endif

             /* 100.03 fix 26�I�� ( premium_3132 �nby sug_type �[�` ) */
             if (iins==31 || iins==32 || iins==231 || iins==232 || iins==77 || iins==78 || iins==113 || iins==114 ||
                 iins==133 || iins==134 || iins==149 || iins==249 || iins==531 || iins==532)
             {
	         #ifdef PRINTF_FLAG
	         printf("fcar_class=[%c]\n",fcar_class[0]);
	         #endif

                 if (fcar_class[0]=='1')  /* �ۥΨ� */
                 {
                     if (strcmp(cal_car_id,"03")==0 ||
                         strcmp(cal_car_id,"04")==0 ||
                         strcmp(cal_car_id,"22")==0 )
                     {
                         if (assuredf[0]=='1' || assuredf[0]=='3' || assuredf[0]=='5') /* �۵M�H */
                         {
                             if ((iins == 77) || (iins == 78))
                             {
                                 /* 77,78�n���d�ۤv�M�ݪ��~�֩ʧO�Y�� 103.04.09 */
                                 strcpy(sIns,itoa(iins));
                                 strcpy(sIns,trim(sIns));
                                 find_flag = 0;
                                 for (chk_count=0 ; chk_count<max_ca_sex_age_factor ; chk_count++)
            			 {
            			     if ((strcmp(ca_sex_age_factor[chk_count].fcard_class, sIns) == 0) &&
            				 (strcmp(ca_sex_age_factor[chk_count].fsex, wsex) == 0) &&
            				 (ca_sex_age_factor[chk_count].qage_bgn <= age) &&
            				 (ca_sex_age_factor[chk_count].qage_end > age) &&
            				 (strcmp(ca_sex_age_factor[chk_count].frate, frate_chk) == 0))
            			     {
            			         find_flag  = 1;
            				 psex_age2 = ca_sex_age_factor[chk_count].pfactor;

            				 #ifdef PRINTF_FLAG
            				 printf("in Trace -- sIns = [%s] \n",  sIns);
            				 printf("in Trace -- frate_chk = [%s] \n",  frate_chk);
            				 printf("in Trace -- age = [%f] \n",  age);
            				 printf("in Trace -- wsex = [%s] \n",  wsex);
            				 #endif
            				 break;
            			     }
            			 }
            			 if (find_flag == 0)    psex_age2=0;
                             }


                             #ifdef PRINTF_FLAG
                             printf("psex_age2[%f] acc[%f] short[%f] ee2[%f]\n",psex_age2,plia_acc,short_prate,ee2);
                             #endif

                             if(psex_age_notfound2==1)
                             {
	                         #ifdef PRINTF_FLAG
	                         printf("psex_age_notfound2[%d] \n",psex_age_notfound2);
	                         #endif
                                 INS_ptr->ins_premium     = 0;
                                 INS_ptr->bef_ins_premium = 0;

                                 /*�䤣��ʧO�~�֫Y�ơA�W�[�g�Jcar_renew_msg�A�k���bE43 (1110601012_SC1)*/
                                 $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�~�֩ʧO�Y�Ƥ��s�b','1','E43',$iofficer);
                             }
                             else
                             {
                                 INS_ptr->ins_premium     = mpremium *(psex_age2+plia_acc) *short_prate;
                                 INS_ptr->bef_ins_premium = mpremium *(psex_age2+plia_acc) *short_prate;
                             }
                             /* premium_3132 for calculate */
                             /* ins_type='24' or '26' or other */
                             if(psex_age_notfound2==1)
                             {
                                 premium_3132_ori = 0;
                                 premium_3132_sug = 0;
                                 INS_ptr->pure_prem = 0;
                                 if (iins==31 || iins==231)
                                 {
                                     /* �O�d31�I�«O�O��109�I�ثO�O�p��ϥ� add by sylvia 103.05.15 */
                                     insmpurm_109_ori = insmpurm_109_sug = INS_ptr->pure_prem;
                                 }
                             }
                             else
                             {
                                 if (sug_type==0)
                                 {
                                     premium_3132_ori=premium_3132_ori +dbl_len8((mpremium*(psex_age2+plia_acc)));
                                 }
                                 else
                                 {
                                     premium_3132_sug=premium_3132_sug +dbl_len8((mpremium*(psex_age2+plia_acc)));
                                 }

                                 INS_ptr->pure_prem = mpremium*(psex_age2+plia_acc);

                                 if (iins==31 || iins==231)
                                 {
                                     /* �O�d31�I�«O�O��109�I�ثO�O�p��ϥ� add by sylvia 103.05.15 */
                                     if (sug_type==0)
                                         insmpurm_109_ori = INS_ptr->pure_prem;
                                     else
                                         insmpurm_109_sug = INS_ptr->pure_prem;
                                 }
                             }
                         }
                         else
                         {
                             #ifdef PRINTF_FLAG
                             printf("#3plia_acc[%2.2f],short[%2.1f],ee2[%2.1f]\n", plia_acc,short_prate,ee2);
                             #endif

                             INS_ptr->ins_premium     = mpremium *(1+plia_acc) *short_prate;
                             INS_ptr->bef_ins_premium = mpremium *(1+plia_acc) *short_prate;

                             /* premium_3132 for calculate */
                             /* ins_type='24' or '26' or other */
                             if (sug_type==0)
                             {
                                 premium_3132_ori=premium_3132_ori+dbl_len8((mpremium *(1+plia_acc)));  /*** round ***/
                             }
                             else
                             {
                                 premium_3132_sug=premium_3132_sug+dbl_len8((mpremium *(1+plia_acc)));  /*** round ***/
                             }

                             INS_ptr->pure_prem = dbl_len8((mpremium *(1+plia_acc)));  /*** round ***/

                             if (iins==31 || iins==231)
                             {
                                 /* �O�d31�I�«O�O��109�I�ثO�O�p��ϥ� add by sylvia 103.05.15 */
                                 if (sug_type==0)
                                     insmpurm_109_ori = INS_ptr->pure_prem;
                                 else
                                     insmpurm_109_sug = INS_ptr->pure_prem;
                             }
                         }
                     }
                     else
                     {
                         #ifdef PRINTF_FLAG
                         printf("#1plia_acc[%2.2f],short[%2.1f],ee2[%2.1f]\n", plia_acc,short_prate,ee2);
                         printf("31,32,77,78@@@@@ mpremium[%f]\n",mpremium);
                         #endif

                         if ( iins == 113 || iins == 114)
                         {
                             if(qply_period <= 12 )
                             {  /* <= 1�~ */
                                 INS_ptr->ins_premium      = mpremium *(1.0) *short_prate;
                                 INS_ptr->bef_ins_premium  = mpremium *(1.0) *short_prate;
                             }
                             else if( qply_period == 24 )
                             {  /* 1�~11�Ӥ�H�W��2�~�� */
                                 INS_ptr->ins_premium      = mpremium_sec * (1.0) *short_prate;
                                 INS_ptr->bef_ins_premium  = mpremium_sec * (1.0) *short_prate;
                             }
                             else if((qply_period > 12) && (qply_period < 24))
                             {  /* �j��1�~�B �p�� 1�~11�Ӥ� */
                                 INS_ptr->ins_premium      = mpremium +((mpremium_sec-mpremium) * (qply_period-12)/12.0);
                                 INS_ptr->bef_ins_premium  = mpremium +((mpremium_sec-mpremium) * (qply_period-12)/12.0);
                             }
                         }
                         else
                         {
                             INS_ptr->ins_premium      = mpremium *(1+plia_acc) *short_prate;
                             INS_ptr->bef_ins_premium  = mpremium *(1+plia_acc) *short_prate;

    			     #ifdef PRINTF_FLAG
    			     printf("31,32,77,78@@@@@ INS_ptr->ins_premium[%f]\n",INS_ptr->ins_premium);
    			     printf("31,32,77,78@@@@@ INS_ptr->bef_ins_premium[%f]\n",INS_ptr->bef_ins_premium);
    			     #endif
                             /* premium_3132 for calculate */
                             /* ins_type='24' or '26' or other */
                             if (sug_type==0)
                             {
                                 premium_3132_ori=premium_3132_ori+dbl_len8((mpremium *(1+plia_acc)));
                             }
                             else
                             {
                            	 premium_3132_sug=premium_3132_sug+dbl_len8((mpremium *(1+plia_acc)));
                             }
                             INS_ptr->pure_prem = dbl_len8((mpremium *(1+plia_acc)));
                         }

                         if (iins==31 || iins==231)
                         {
                             /* �O�d31�I�«O�O��109�I�ثO�O�p��ϥ� add by sylvia 103.05.15 */
                             if (sug_type==0)
                                 insmpurm_109_ori = INS_ptr->pure_prem;
                             else
                                 insmpurm_109_sug = INS_ptr->pure_prem;
                         }

			 #ifdef PRINTF_FLAG
			 printf("31,32,77,78@@@@@ premium_3132_ori[%f]\n",premium_3132_ori);
			 printf("31,32,77,78@@@@@ premium_3132_sug[%f]\n",premium_3132_sug);
			 printf("31,32,77,78@@@@@ INS_ptr->pure_prem[%f]\n",INS_ptr->pure_prem);
			 #endif
                     }
                 }
                 else
                 {
                     /* ��~�� */
                     #ifdef PRINTF_FLAG
                     printf("��~��1\n");
                     #endif

                     INS_ptr->ins_premium     = mpremium *(1+plia_acc) *short_prate;
                     INS_ptr->bef_ins_premium = mpremium *(1+plia_acc) *short_prate;

                     /* premium_3132 for calculate */
                     /* ins_type='24' or '26' or other */
                     if (sug_type==0)
                     {
                         premium_3132_ori=premium_3132_ori+dbl_len8((mpremium *(1+plia_acc))); /*** round ***/
                     }
                     else
                     {
                         premium_3132_sug=premium_3132_sug+dbl_len8((mpremium *(1+plia_acc))); /*** round ***/
                     }

                     INS_ptr->pure_prem = dbl_len8((mpremium *(1+plia_acc))); /*** round ***/

                     if (iins==31 || iins==231)
                     {
                         /* �O�d31�I�«O�O��109�I�ثO�O�p��ϥ� add by sylvia 103.05.15 */
                         if (sug_type==0)
                             insmpurm_109_ori = INS_ptr->pure_prem;
                         else
                             insmpurm_109_sug = INS_ptr->pure_prem;
                     }

                 }
                 #ifdef PRINTF_FLAG
                 printf("31,32,77,78@@@@@ ins_premium[%f]\n",INS_ptr->ins_premium);
                 #endif
             }
             else if (iins==131 || iins==132 || iins==331 || iins==332)
             {
             	/* �«O�I�O �� �򥻯«O�O �� (1�Ϧۭt�B����v) �� (1�Ͻߴڬ����Y��)
	           (�ۭt�B����v�G131�I�G-4.00%  �F 132�I�G-10.00% �i���j)
                    �`�O�I�O ��  ROUND(�«O�I�O �� (1 - ���[�O�βv),0)) */
                INS_ptr->ins_premium     = mpremium *(1+deduct_rate) * (1+plia_acc) * short_prate;
                INS_ptr->bef_ins_premium = INS_ptr->ins_premium ;
             }
             else if (iins==109)
             {
                /* 109 �I�د«O�O = 31�I�د«O�O*109�I�ؼW�B���ƫY�� add by larry 102.11.22 (1021001004_C1)*/
                if (sug_type==0)
                {
             	    INS_ptr->ins_premium = insmpurm_109_ori*(mpremium/100.0);
                }
                else
                {
             	    INS_ptr->ins_premium = insmpurm_109_sug*(mpremium/100.0);
                }

                INS_ptr->bef_ins_premium = INS_ptr->ins_premium;

             }
             else if (iins==30)
             {
             	/* �Ϥ����T���p�⤽�� add by 061476 (1100415003_SC6) */
             	if (ISMOT(cal_car_id))
             	{
             		if(qply_period <= 12 ){
             			INS_ptr->ins_premium      = mpremium *(1.0) *short_prate;
             			INS_ptr->bef_ins_premium  = mpremium *(1.0) *short_prate;
             		}else if( qply_period == 24 ){
             			INS_ptr->ins_premium      = mpremium_sec * (1.0) *short_prate;
             			INS_ptr->bef_ins_premium  = mpremium_sec * (1.0) *short_prate;
             		}else if((qply_period > 12) && (qply_period < 24)){
             			INS_ptr->ins_premium      = mpremium + ((mpremium_sec-mpremium) * (qply_period-12)/12.0);
             			INS_ptr->bef_ins_premium  = mpremium + ((mpremium_sec-mpremium) * (qply_period-12)/12.0);
             		}
             	}
             	else
             	{
             		INS_ptr->ins_premium=mpremium*short_prate;
             		INS_ptr->bef_ins_premium=mpremium*short_prate;
             	}

             	#ifdef PRINTF_FLAG
             	printf("30@@@@@ ins_premium[%f]\n",INS_ptr->ins_premium);
             	#endif
             }
             else
             {
                 INS_ptr->ins_premium=mpremium*short_prate;
                 INS_ptr->bef_ins_premium=mpremium*short_prate;
                 #ifdef PRINTF_FLAG
                 printf("71,72@@@@@ ins_premium[%f]\n",INS_ptr->ins_premium);
                 #endif
             }
        }
        else
        {    /* 14,25,51,52,19 */      /* 61,65,68,69,47,176,177 */

             if (iins==25)
             {
                 $SELECT mpremium, pextra_charge/100
                    INTO $mpremium, $pextra_charge
                    FROM cover_vs_premium
                   WHERE icar_type=$cal_car_id
                     AND iins_type=$ins_type
                     AND mcoverage1=$injured_cover
                     AND drate=(SELECT drate
                                  FROM ca_rate_date
                                 WHERE icode=$frate_chk
                                   AND itable='cover_vs_premium');
                 if (NOT_FOUND)
                      mpremium=0;
                 /*return M_CA_NCOVER_PREM;*/
                 /*  crystal-861107,prevent devied zero */
                 if (injured_cover==0)
                 {
                      INS_ptr->ins_premium    =0;
                      INS_ptr->bef_ins_premium=0;
                 }
                 else
                 {
                      INS_ptr->ins_premium=((float)damage_cover/(float)injured_cover) *mpremium*short_prate;
                      INS_ptr->bef_ins_premium=((float)damage_cover/(float)injured_cover) *mpremium*short_prate;
                 }
             }
             /* 161�B162�I�ثO�O�p�� add by 061476 107.02.27 (1070212002_SC3) */
             else if (iins == 161 || iins == 162)
             {
             	/* ����<ipro_year ���̤j�~��, �A�䤣��~�� >ipro_year ���̤p�~�� */
             	$SELECT first 1 decode(icar_series,'10','1','2')
             	   INTO $car_series
             	   FROM ca_car_model
             	  WHERE ibrand    = $brandi
             	    AND ipro_year = $pro_year
             	    AND drate     = (SELECT drate
             	                       FROM ca_rate_date
             	                      WHERE icode = $frate_chk
             	                        AND itable = 'ca_car_model');
             	if (NOT_FOUND)
             	{
             	    $SELECT first 1 decode(icar_series,'10','1','2')
             	       INTO $car_series
             	       FROM ca_car_model
             	      WHERE ibrand    = $brandi
             	        AND ipro_year < $pro_year
             	        AND drate     = (SELECT drate
             	                           FROM ca_rate_date
             	                          WHERE icode = $frate_chk
             	                            AND itable = 'ca_car_model');
             	    if (NOT_FOUND)
             	    {
             	    	$SELECT first 1 decode(icar_series,'10','1','2')
             	           INTO $car_series
             	           FROM ca_car_model
             	          WHERE ibrand    = $brandi
             	            AND ipro_year > $pro_year
             	            AND drate     = (SELECT drate
             	                               FROM ca_rate_date
             	                              WHERE icode = $frate_chk
             	                                AND itable = 'ca_car_model');
             	    }
             	}

             	$SELECT mpremium, pextra_charge/100
             	   INTO $mpremium, $pextra_charge
             	   FROM cover_vs_premium
             	  WHERE icar_type  = $cal_car_id
             	    AND iins_type  = $ins_type
             	    AND mcoverage2 = $damage_cover
             	    AND mdeduct    = $car_series
             	    AND drate      = (SELECT drate
                                        FROM ca_rate_date
                                       WHERE icode  = $frate_chk
                                         AND itable = 'cover_vs_premium');

                INS_ptr->ins_premium     = mpremium * short_prate;
                INS_ptr->bef_ins_premium = mpremium * short_prate;
             }
             /* 178�I�ثO�O�p��  (1130510009_C13) */
             else if (iins == 178)
             {
             	mpremium      = 0;
             	find_flag     = 0;

             	for (chk_count=0;chk_count<max_cover_prem;chk_count++)
             	{
             		if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
             		    (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
             		    (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
             		    (cover_vs_prem[chk_count].mcoverage1 == injured_cover) &&
             		    (cover_vs_prem[chk_count].mcoverage2 == damage_cover) &&
             		    (cover_vs_prem[chk_count].mdeduct == cal_deduct))
             		{
             			find_flag     = 1;
             			mpremium      = cover_vs_prem[chk_count].mpremium;
             			break;
             		}
             	}

             	if (find_flag == 0)
             	{
             		mpremium = 0;
             	}

             	INS_ptr->ins_premium = mpremium * short_prate;
             	INS_ptr->bef_ins_premium = mpremium * short_prate;
             	#ifdef PRINTF_FLAG
             	printf("178---->ins_premium[%f]\n",INS_ptr->ins_premium);
             	#endif
             }
             else if (iins == 15 || iins == 16 || iins == 66 || iins == 67 ||
                      iins == 106 || iins == 80 || iins == 119 || iins == 121 ||
                      iins == 123 || iins == 154 || iins == 155 || iins == 156 ||
                      iins == 163 || iins == 237) /* 981106 , 102.10.25 add 106 */
             {
                 /* 80�I��  add by sylvia 1030407 */
                 mpremium      = 0;
                 pextra_charge = 0;

                 find_flag     = 0;

                 for (chk_count=0;chk_count<max_cover_prem;chk_count++)
                 {
                      if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                          (cover_vs_prem[chk_count].mcoverage1 == injured_cover) &&
                          (cover_vs_prem[chk_count].mcoverage2 == damage_cover))
                      {
                           find_flag     = 1;
                           mpremium      = cover_vs_prem[chk_count].mpremium;
                           pextra_charge = cover_vs_prem[chk_count].pextra_charge;
                           qday          = damage_cover/injured_cover;
                           break;
                      }
                 }

                 if (find_flag == 0)
                 {
                     mpremium = 0;
                 }

                 INS_ptr->ins_premium = mpremium * short_prate;
                 INS_ptr->bef_ins_premium = mpremium * short_prate;
                 #ifdef PRINTF_FLAG
                 printf("15 16 66 67 106 80 119 121 123---->ins_premium[%f]\n",INS_ptr->ins_premium);
                 #endif
             }
             else if (iins == 14 || iins == 61 || iins == 65 ||
                      iins == 68 || iins == 69 || iins == 19 ||
                      iins == 97 || iins == 27 || iins == 108 ||
                      iins == 79 || iins == 89)
             {
                 /* 22�I�حp��,�t�X�ӫ~�I����,���112�I�حp��a�覡 modify by sylvia 105.12.30 */
             	 /*** 14,61,65,68,69,19 �N���O , 102.07.25 add 27�I ***/
             	 /* 79,89�I��  add by sylvia 1030407 */
                 #ifdef PRINTF_FLAG
                 printf("14---------cov1[%d] cov3[%d],\n",injured_cover,damage_cover);
                 printf("frate_chk == [%s]\n",frate_chk);
                 #endif


                 #ifdef PRINTF_FLAG
                 printf("icar_type == [%s]\n",cal_car_id);
                 printf("iins_type == [%s]\n",ins_type);
                 printf("mcoverage2 == [%d]\n",damage_cover);
                 #endif

                 find_flag     = 0;
                 mpremium      = 0;
                 pextra_charge = 0;

                 for (chk_count=0;chk_count<max_cover_prem;chk_count++)
                 {
                      if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].frate,     frate_chk) == 0) &&
                          (cover_vs_prem[chk_count].mcoverage2 == damage_cover))
                      {
                           find_flag     = 1;
                           mpremium      = cover_vs_prem[chk_count].mpremium;
                           pextra_charge = cover_vs_prem[chk_count].pextra_charge;
                           break;
                      }
                 }

                 if (find_flag == 0)
                      mpremium = 0;

                 INS_ptr->ins_premium = mpremium * short_prate;
                 INS_ptr->bef_ins_premium = mpremium * short_prate;
                 #ifdef PRINTF_FLAG
                 printf("14---->ins_premium[%f]\n",INS_ptr->ins_premium);
                 #endif
             }
             /* 102.08 �s�W�q�ʦۦ樮��X�O�I 101,102,103,104 */
             /* 100.01.13 ,add 86�I�� ;  102.07.01 add 98�I�� */
             /* 1041222 �s�W143�I�� add by sylvia 104.12.22 (1041203004_C4) */
             else if (iins==62 || iins==63 || iins==64 || iins==86 || iins==98 ||
             	      iins==101 || iins==102 || iins==103 || iins==104 ||
             	      iins == 107 || iins == 143 )
             {
                 #ifdef PRINTF_FLAG
                 printf("INTO 62 63 64 86 143 iins[%d],injured_cover[%ld],damage_cover[%ld],cal_deduct[%ld]\n",iins,injured_cover,damage_cover,cal_deduct);
                 #endif
                 /* 102.05 86�I�طs�W32���ضO�v */
                 /* ���קK��O�J�p���ɦ]�O�v�վ�P�ϭ��m���ȥi��������P���ۭt�B�A�G�������s�̨䭫�m���Ȩ��o�ۭt�B */

                 /* E�����ˮֽվ�(20,23,86�i���[E����,�����ˮ֫O�B) modify by sylvia 103.05.30 (1030324001_C3)
                  �Y�h�~���l�I���uE���ڡv�A�h��O�J�p�ɡA��u�վ����O�O�B�v�p��覡���G
          	      �Y�h�~�D�u���O��G�վ����O�O�B = [�h�~�O�B * (1-�~���²v)] (���ܤd��)
        �� 	      �Y�h�~���u���O��G�վ����O�O�B = [�h�~�O�B * (1-����²v)] (���ܤd��)  */
                  /* if ((iins==86)&&(strstr(INS_ptr->provision, "E") != NULL))
                  {
      		         SetCover_For_Prov_E(INS_ptr->damage_cover);
      		         INS_ptr->damage_cover=cover_01;
      		         damage_cover=cover_01;
                  } */

                  /* 86�I�O�O�p��,�۶O�v�N��>=74�_,���ۭt�B; �O�v�N��<74,�ۭt�B�������ŶZ  modify by sylvia 104.06.11 */
                  if (atoi(frate_chk) < 74)
                  {

                      if ((iins==86)&&(strcmp(cal_car_id,"32")==0)) {
                         $SELECT min(mdeduct) INTO $cal_deduct
                            FROM cover_vs_premium
                           WHERE iins_type  = '86' AND icar_type = '32'
                             AND mcoverage1 = $injured_cover
                             AND mcoverage2 = $damage_cover
                             AND mdeduct   >= $car_price      /* car_price(���G�U��) */
                             AND drate      = (SELECT drate FROM ca_rate_date
                                               WHERE icode  = $frate_chk
                                                 AND itable = 'cover_vs_premium');
                         INS_ptr->deduct = cal_deduct;
                     }
                 }
                 else
                 {
                    if ((iins==86)&&(strcmp(cal_car_id,"32")==0)) {

                        cal_deduct = INS_ptr->deduct ;

                        $SELECT min(mcoverage1) INTO $injured_cover
                            FROM cover_vs_premium
                           WHERE iins_type  = '86' AND icar_type = '32'
                             AND mcoverage1 >= $car_price
                             AND mcoverage2 = $damage_cover
                             AND mdeduct   = $cal_deduct      /* car_price(���G�U��) */
                             AND drate      = (SELECT drate FROM ca_rate_date
                                               WHERE icode  = $frate_chk
                                                 AND itable = 'cover_vs_premium');

                         #ifdef PRINTF_FLAG
                         printf("cal_deduct=[%d]injured_cover=[%ld]\n",cal_deduct,injured_cover);
                         printf("car_price=[%f]damage_cover=[%ld]\n",car_price,damage_cover);
                         printf("frate_chk=[%s]\n",frate_chk);
                         #endif
                     }
                 }

                 find_flag     = 0;
                 for (chk_count=0;chk_count<max_cover_prem;chk_count++)
                 {
                      if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].frate, frate_chk) == 0) &&
                          (cover_vs_prem[chk_count].mcoverage1 == injured_cover) &&
                          (cover_vs_prem[chk_count].mcoverage2 == damage_cover)&&
                          (cover_vs_prem[chk_count].mdeduct == cal_deduct))
                      {
                           find_flag     = 1;
                           mpremium      = cover_vs_prem[chk_count].mpremium;
                           pextra_charge = cover_vs_prem[chk_count].pextra_charge;
                           break;
                      }
                 }

                 #ifdef PRINTF_FLAG
                 printf("trace find_flag[%d]\n ",find_flag);
                 printf("trace mpremium[%f]\n ",mpremium);
                 #endif

                 if (find_flag == 0)
                      mpremium = 0;

                 /* 101.11,  12/1�_�O�v�ɷs�W"�O�B�@"
                 $SELECT mpremium, pextra_charge/100
                    INTO $mpremium, $pextra_charge
                    FROM cover_vs_premium
                   WHERE icar_type  = $cal_car_id
                     AND iins_type  = $ins_type
                     AND mcoverage1 = $injured_cover
                     AND mcoverage2 = $damage_cover
                     AND mdeduct    = $cal_deduct
                     AND drate=(SELECT drate
                                  FROM ca_rate_date
                                 WHERE icode  = $frate_chk
                                   AND itable = 'cover_vs_premium');
                 if (NOT_FOUND)
                     return M_CA_NCOVER_PREM;
                 */

                 INS_ptr->ins_premium     = mpremium*short_prate;   /*** round ***/
                 INS_ptr->bef_ins_premium = mpremium*short_prate;   /*** round ***/
                 INS_ptr->pure_prem = INS_ptr->ins_premium;     /* �«O�O-���t�������[�O, ��07,10,127 �I�بϥ� */
                 #ifdef PRINTF_FLAG
                 printf("62 63 64 143 ---->iins[%d]\n",iins);
                 printf("62 63 64 143 ---->iins[%d]\n",iins);
                 printf("62 63 64 143 ---->mpremium[%ld]\n",damage_cover);
                 printf("62 63 64 143 ---->cal_deduct[%ld]\n",cal_deduct);
                 printf("62 63 64 143 ---->pextra_charge[%f]\n",pextra_charge);
                 printf("62 63 64 143 ---->ins_premium[%f]\n",INS_ptr->ins_premium);
                 #endif
             }
             /* 198�I�حp�⤽�� add by 061476 109.11.06 (1091103004_SC1) */
             else if (iins==198)
             {
             	$SELECT mpremium, pextra_charge/100
             	   INTO $mpremium, $pextra_charge
             	   FROM cover_vs_premium
             	  WHERE icar_type  = $cal_car_id
             	    AND iins_type  = $ins_type
             	    AND mcoverage1 = $injured_cover
             	    AND mcoverage2 = $damage_cover
             	    AND mdeduct    = 0
             	    AND drate      = (SELECT drate
                                        FROM ca_rate_date
                                       WHERE icode  = $frate_chk
                                         AND itable = 'cover_vs_premium');
                if (NOT_FOUND)
                     return M_CA_NCOVER_PREM;

                if ((fcar_class[0]=='2') || (assuredf[0]=='2' || assuredf[0]=='4' || assuredf[0]=='6'))
                	dbl_psex_age  = 1.0;
                else
                {
                    psex_age_notfound3 = 1;
    		    psex_age_damage = 1.0 ;
                    for (chk_count=0 ; chk_count<max_ca_sex_age_factor ; chk_count++)
    		    {
    		        if ((strcmp(ca_sex_age_factor[chk_count].fcard_class, ins_type) == 0) &&
    			    (strcmp(ca_sex_age_factor[chk_count].fsex, wsex) == 0) &&
    			    (ca_sex_age_factor[chk_count].qage_bgn <= age) &&
    			    (ca_sex_age_factor[chk_count].qage_end > age) &&
    			    (strcmp(ca_sex_age_factor[chk_count].frate, frate_chk) == 0))
                        {

    			    psex_age_notfound3  = 0;
    			    psex_age_damage = ca_sex_age_factor[chk_count].pfactor;
    	                    break;
                        }
                    }

    		    if(psex_age_notfound3==1)
    		    {

    		        $SELECT FIRST 1 a.pfactor
    		           INTO $psex_age_damage
                           FROM ca_sex_age_factor a , ca_rate_date b
                          WHERE a.drate = b.drate
                            AND a.fcard_class =$ins_type
                            AND b.itable = 'ca_sex_age_factor3'
                            AND b.icode = $frate_chk AND fsex = $wsex ORDER BY qage_end desc;

                        if (SQLCODE == SQLNOTFOUND) psex_age_damage = 1.0 ;

                        dbl_psex_age = psex_age_damage;
                        /*�䤣��ʧO�~�֫Y�ơA�W�[�g�Jcar_renew_msg�A�k���bE43 (1110601012_SC1)*/
                        $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�~�֩ʧO�Y�Ƥ��s�b','1','E43',$iofficer);
                    }
                    else
                    {
                        dbl_psex_age = psex_age_damage;
                    }

                    #ifdef PRINTF_FLAG
                    printf("in Trace -- psex_age_notfound3 = [%d] \n", psex_age_notfound3);
        	    printf("in Trace -- ins_type = [%s] \n", ins_type);
        	    printf("in Trace -- frate_chk = [%s] \n",   frate_chk);
        	    printf("in Trace -- age = [%f] \n",  age);
        	    printf("in Trace -- wsex = [%s] \n",  wsex);
        	    printf("in 198@@@@@ psex_age_damage[%f] \n",psex_age_damage);
    		    #endif
                }

                if (sug_type == 0){
                	pdmg_acc = pdmg_acc_ori;
                	punknown_acc = punknown_acc_ori;
                }else{
                	pdmg_acc = pdmg_acc_sug;
                	punknown_acc = punknown_acc_sug;
                }

                INS_ptr->ins_premium     = (mpremium*dmg_factor)*(dbl_psex_age+pdmg_acc)*short_prate; /*** round ***/
                INS_ptr->bef_ins_premium = (mpremium*dmg_factor)*(dbl_psex_age+pdmg_acc)*short_prate; /*** round ***/
                INS_ptr->pure_prem       = INS_ptr->ins_premium;
             }
             else if (iins == 238)
             {
                 /* �s�W238�I�ثO�O�p�� add by 061476 (1100119001_SC3)
                    ����1�G�H�ۭt�B(���{��||����)���o�򥻯«O�O
                    ����2�G�ۭt�B�e3�X�����{�ơA��2�X������
                    ����3�G���{�ƾ���30�B�T��100
                    ����4�G���֭p�� = �s�y�~�� �� �_�O�~��
                           ����15�~�H�W      -> 99
                           ����10-15(���t)�~ -> 15
                           ����3-10(���t)�~  -> 10
                           ����0-3(���t)�~   -> 03
                    �G�Y15�~�H�W���ӫO�A�ۭt�B��10099
                    ����5�G�����ȥi�ӫO0-3(���t)�~�A�G�����ۭt�B�u��3003   */


                 sprintf_s(pro_ymd,sizeof pro_ymd,"%d/01/%s",qpro_month,pro_year);

                 strcpy(pro_ymd,cm_from_infdate_100(pro_ymd));
                 lpro_ymd = cm_ymd_cdate(pro_ymd);             /* ����~���((y)yy/mm/dd)�নDate(long) */
                 iCar_age = DiffMonth(dply_begin,lpro_ymd);    /* �D���ϴ��I�ب���(��) */

                 if( iCar_age < 3*12 )        iCar_age = 3;
                 else if( iCar_age < 10*12 )  iCar_age = 10;
                 else if( iCar_age < 15*12 )  iCar_age = 15;
                 else                         iCar_age = 99;

                 qday = INS_ptr->qday;
                 iCar_age = qday * 100 + iCar_age;

                 $SELECT a.mpremium, a.pextra_charge/100
                    INTO $mpremium, $pextra_charge
                    FROM cover_vs_premium a
                   WHERE a.icar_type = $cal_car_id
                     AND a.iins_type = $ins_type
                     AND a.mcoverage1 = $injured_cover
                     AND a.mcoverage2 = $damage_cover
                     AND drate = (SELECT drate
                                    FROM ca_rate_date
                                   WHERE icode = $frate
                                     AND itable = 'cover_vs_premium')
                     AND mdeduct = nvl((select max(mdeduct) from cover_vs_premium
                                         where icar_type = a.icar_type
                                           and iins_type = a.iins_type
                                           and mcoverage1 = a.mcoverage1
                                           and mcoverage2 = a.mcoverage2
                                           and drate = a.drate
                                           and mdeduct = $iCar_age),0);

                 if(SQLCODE == SQLNOTFOUND) return M_CA_NCOVER_PREM;

                 INS_ptr->ins_premium     = mpremium * short_prate;
                 INS_ptr->bef_ins_premium = mpremium * short_prate;

             }
             else if (iins==174)
             {
             	$SELECT a.mpremium, a.pextra_charge/100
             	   INTO $mpremium, $pextra_charge
             	   FROM cover_vs_premium a
             	  WHERE a.icar_type  = $cal_car_id
             	    AND a.iins_type  = $ins_type
             	    AND a.mcoverage1 = $injured_cover
             	    AND a.mcoverage2 = $damage_cover
             	    AND a.mdeduct    = $cal_deduct
             	    AND a.drate = (SELECT drate
             	                     FROM ca_rate_date
             	                    WHERE icode  = $frate
             	                      AND itable = 'cover_vs_premium');

             	if (NOT_FOUND)  return M_CA_NCOVER_PREM;

             	INS_ptr->ins_premium     = mpremium * short_prate;
             	INS_ptr->bef_ins_premium = mpremium * short_prate;
             }
             else if ((iins==47) || (iins==147) || (iins==110) || (iins==112) ||
                      (iins==117) || (iins==22))
             {
                   sprintf_s(sstmt,sizeof sstmt,"SELECT %s FROM %s WHERE %s %s %s %s %s %s %s %s %s",
                                "mpremium, pextra_charge/100 ",
                                "cover_vs_premium ",
                                "icar_type  = ? ",
                                "AND iins_type  = ? ",
                                "AND mcoverage1 = ? ",
                                "AND mcoverage2 = ? ",
                                "AND mdeduct    = 1 ",
                                "AND drate=(SELECT drate ",
                                "             FROM ca_rate_date ",
                                "            WHERE icode  = ? ",
                                "              AND itable = 'cover_vs_premium')");

                   #ifdef PRINTF_FLAG
                   printf("sstmt=[%s]\n", sstmt );
                   printf("cal_car_id=[%s] ins_type=[%s] injured_cover=[%d] death_cover=[%d] frate_chk=[%s]\n",
                           cal_car_id , ins_type , injured_cover , death_cover , frate_chk);
                   #endif

                   EXEC SQL PREPARE CUR_47_stmt FROM   :sstmt;
                   EXEC SQL DECLARE cur_47      CURSOR FOR CUR_47_stmt;

                   if ( (iins==110) || (iins==112) || (iins==22))
                   {
                        EXEC SQL OPEN cur_47  USING  :cal_car_id , :ins_type ,
                                                     :injured_cover , :damage_cover , :frate_chk;
                   }
                   else
                   {
                        EXEC SQL OPEN cur_47  USING  :cal_car_id , :ins_type ,
                                                     :injured_cover , :death_cover , :frate_chk;
                   }

                   EXEC SQL FETCH   cur_47 INTO :mpremium ,:pextra_charge;
                   if (NOT_FOUND)
                       return M_CA_NCOVER_PREM;

                   EXEC SQL CLOSE   cur_47;
                   EXEC SQL FREE    cur_47;

               /* �]147�I�إi�O�T���@�~���A�G�u���������د����G�~���A�קK�줣���Ʀӿ��~ 107.07.27 (1070314007_SC3)*/
               if (strncmp(cal_car_id,"01",2)==0 || strncmp(cal_car_id,"02",2)==0 || strncmp(cal_car_id,"32",2)==0 || strncmp(cal_car_id,"34",2)==0)
               {
                   sprintf_s(sstmt,sizeof sstmt,"SELECT %s FROM %s WHERE %s %s %s %s %s %s %s %s %s",
                                "mpremium, pextra_charge/100 ",
                                "cover_vs_premium ",
                                "icar_type  = ? ",
                                "AND iins_type  = ? ",
                                "AND mcoverage1 = ? ",
                                "AND mcoverage2 = ? ",
                                "AND mdeduct    = 2 ",
                                "AND drate=(SELECT drate ",
                                "             FROM ca_rate_date ",
                                "            WHERE icode  = ? ",
                                "              AND itable = 'cover_vs_premium')");

                   #ifdef PRINTF_FLAG
                   printf("sstmt=[%s]\n", sstmt );
                   printf("cal_car_id=[%s] ins_type=[%s] injured_cover=[%d] death_cover=[%d] frate_chk=[%s]\n",
                           cal_car_id , ins_type , injured_cover , death_cover , frate_chk);
                   #endif

                   EXEC SQL PREPARE CUR_47_stmta FROM   :sstmt;
                   EXEC SQL DECLARE cur_47a      CURSOR FOR CUR_47_stmta;
                   if ( (iins==110) || (iins==112) || (iins==22))
                   {
                       EXEC SQL OPEN cur_47a using  :cal_car_id , :ins_type ,
                                                    :injured_cover , :damage_cover , :frate_chk;
                   }
                   else
                   {
                        EXEC SQL OPEN cur_47a using  :cal_car_id , :ins_type ,
                                                     :injured_cover , :death_cover , :frate_chk;
                   }
                   EXEC SQL FETCH   cur_47a INTO :mpremium_sec ,:pextra_charge;

                   if (NOT_FOUND)
                       return M_CA_NCOVER_PREM;

                   EXEC SQL CLOSE   cur_47a;
                   EXEC SQL FREE    cur_47a;
               }
             }else if (iins==57 || iins==59 || iins==60){

             	 find_flag     = 0  ;
             	 mpremium      = 0.0;
             	 pextra_charge = 0.0;

                 #ifdef PRINTF_FLAG
             	 printf("Trace -- iins = [%d] \n",  iins);
             	 printf("Trace -- injured_cover = [%ld] \n",  injured_cover);
             	 #endif

             	 /* ��� */
             	 if (injured_cover > 0){
	                 for (chk_count=0;chk_count<max_cover_prem;chk_count++)
	                 {
	                      if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
	                          (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
	                          (strcmp(cover_vs_prem[chk_count].frate,     frate_chk) == 0) &&
	                          (cover_vs_prem[chk_count].mcoverage1 == injured_cover) &&
	                          (cover_vs_prem[chk_count].mcoverage2 == 0))
	                      {
	                           find_flag     = 1;
	                           mpremium      = cover_vs_prem[chk_count].mpremium;
	                           pextra_charge = cover_vs_prem[chk_count].pextra_charge;
	                           break;
	                      }
	                 }
	                 if (find_flag == 0) return M_CA_NCOVER_PREM;
                 }

                 find_flag     = 0  ;
                 mpremium_sec  = 0.0;
                 pextra_charge = 0.0;
                 #ifdef PRINTF_FLAG
                 printf("57,59,60 ��� mpremiumc [%f]\n",mpremium);
                 printf("Trace -- pextra_charge = [%f] \n",  pextra_charge);
                 printf("Trace -- death_cover = [%ld] \n",  death_cover);
                 #endif
                 if (death_cover > 0){
                 	/* ����*/
                 	for (chk_count=0;chk_count<max_cover_prem;chk_count++)
                 	{
	                      if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
	                          (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
	                          (strcmp(cover_vs_prem[chk_count].frate,     frate_chk) == 0) &&
	                          (cover_vs_prem[chk_count].mcoverage1 == 0) &&
	                          (cover_vs_prem[chk_count].mcoverage2 == death_cover))
	                      {
	                           find_flag     = 1;
	                           mpremium_sec  = cover_vs_prem[chk_count].mpremium;
	                           pextra_charge = cover_vs_prem[chk_count].pextra_charge;
	                           break;
	                      }
	                }
	                if (find_flag == 0) return M_CA_NCOVER_PREM;
	         }else{
	         	return M_CA_NCOVER_PREM;
	         }

                 ins_premium1             = (mpremium*short_prate);/* ��� */
                 ins_premium2             = (mpremium_sec*short_prate);/* ���� */
                 bef_ins_premium1         = (mpremium*short_prate);/* ��� */
                 bef_ins_premium2         = (mpremium_sec*short_prate);/* ���� */
                 INS_ptr->ins_premium     = ins_premium1+ins_premium2;
                 INS_ptr->bef_ins_premium = bef_ins_premium1+bef_ins_premium2;

                 #ifdef PRINTF_FLAG
                 printf("57,59,60 ���� mpremium_sec [%f]\n",mpremium_sec);
                 printf("Trace -- pextra_charge = [%f] \n",  pextra_charge);
                 printf("Trace -- ins_premium1 = [%f] \n",  ins_premium1);
                 printf("Trace -- ins_premium2 = [%f] \n",  ins_premium2);
                 #endif
             }else{
                 /*  55,49,51,50 */  /* 98.11.04,add 57,59,60 ; 100.02.17, ���� 57,59,60   */
                 /* 135 add by sylvia 104.06.02 */

                 find_flag     = 0;
                 mpremium      = 0;
                 pextra_charge = 0;

                 #ifdef PRINTF_FLAG
                 printf("iins_type[%s],cal_car_id[%s],frate_chk[%s]\n",ins_type, cal_car_id, frate_chk);
                 printf("cover1[%ld],cover2[%ld]\n",injured_cover,death_cover);
                 #endif

                 for (chk_count=0;chk_count<max_cover_prem;chk_count++)
                 {
                      if ((strcmp(cover_vs_prem[chk_count].icar_type, cal_car_id) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].iins_type, ins_type) == 0) &&
                          (strcmp(cover_vs_prem[chk_count].frate,     frate_chk) == 0) &&
                          (cover_vs_prem[chk_count].mcoverage1 == injured_cover) &&
                          (cover_vs_prem[chk_count].mcoverage2 == death_cover))
                      {
                           find_flag     = 1;
                           mpremium      = cover_vs_prem[chk_count].mpremium;
                           pextra_charge = cover_vs_prem[chk_count].pextra_charge;
                           break;
                      }
                 }

                 #ifdef PRINTF_FLAG
                 printf("57,59,60 mpremium[%f]\n",mpremium);
                 #endif

                 if (find_flag == 0){
                      /* 980310,�䤣���,���է�j�@�Ū��ŶZ */
                      next_cover1 = 0;
                      next_cover2 = 0;

                      if (iins==52 || iins==53 || iins==55 || iins==135 ||
                          iins==255 || iins==252 || iins==253 || iins==555){
	                      $DECLARE next_cur9 CURSOR FOR
	                        SELECT mcoverage1,mcoverage2
	                          INTO $next_cover1,$next_cover2
	                          FROM cover_vs_premium
	                         WHERE icar_type=$cal_car_id
	                           AND iins_type=$ins_type
	                           AND mcoverage2 > $death_cover
	                           AND drate=(SELECT drate
	                                        FROM ca_rate_date
	                                       WHERE icode=$frate_chk
	                                         AND itable='cover_vs_premium')
	                         ORDER BY 1,2;
	                      $OPEN next_cur9;
	                      $FETCH next_cur9;
	                      if (SQLCODE == SQLNOTFOUND)
	                      {
	                      	  /* �A�䤣���,��է�p�@�Ū��ŶZ */
	                      	  find_flag = 0;
		                      next_cover1 = 0;
		                      next_cover2 = 0;
		                      $DECLARE next_cur9x CURSOR FOR
		                        SELECT mcoverage1,mcoverage2
		                          INTO $next_cover1,$next_cover2
		                          FROM cover_vs_premium
		                         WHERE icar_type=$cal_car_id
		                           AND iins_type=$ins_type
		                           AND mcoverage2 < $death_cover
		                           AND drate=(SELECT drate
		                                        FROM ca_rate_date
		                                       WHERE icode=$frate_chk
		                                         AND itable='cover_vs_premium')
		                         ORDER BY 1 DESC,2 DESC;
		                      $OPEN next_cur9x;
		                      $FETCH next_cur9x;
		                      if (SQLCODE == SQLNOTFOUND)
		                      {
		                      	  find_flag = 0;
			                      INS_ptr->injured_cover = 0;
		                          INS_ptr->death_cover = 0;
		                          INS_ptr->damage_cover = 0;
		                          INS_ptr->ins_premium = 0;
		                          INS_ptr->bef_ins_premium = 0;
		                          mpremium = 0;
		                          #ifdef PRINTF_FLAG
		                          printf("INTO 5x not found\n");
		                          #endif
		                      }else{
		                          $SELECT mpremium, pextra_charge/100
		                             INTO $mpremium, $pextra_charge
		                             FROM cover_vs_premium
		                            WHERE icar_type=$cal_car_id
		                              AND iins_type=$ins_type
		                              AND mcoverage1=$next_cover1
		                              AND mcoverage2=$next_cover2
		                              AND drate=(SELECT drate
		                                           FROM ca_rate_date
		                                          WHERE icode=$frate_chk
		                                            AND itable='cover_vs_premium');
		                      	  find_flag = 1;
		                          injured_cover = next_cover1;
		                          death_cover   = next_cover2;
		                          INS_ptr->injured_cover = next_cover1;
		                          INS_ptr->death_cover = next_cover2;
		                          if (iins==53 ||iins==55 ||iins==135 ||iins==255 ||
		                              iins==253 ||iins==555){
		                          	  damage_cover=(qpassenger-1)*death_cover;
		                          }else if(iins==52||iins==252){
		                          	  damage_cover=qpassenger*death_cover;
		                          }
		                          INS_ptr->damage_cover=damage_cover;

		                          #ifdef PRINTF_FLAG
		                          printf("next_cover1[%ld]\n",next_cover1);
		                          printf("next_cover2[%ld]\n",next_cover2);
		                          printf("mpremium[%f]\n",mpremium);
		                          printf("FOUND \n");
		                          #endif
		                      }
		                      $CLOSE next_cur9x;
		                      $FREE  next_cur9x;
	                      }else{

	                          $SELECT mpremium, pextra_charge/100
	                             INTO $mpremium, $pextra_charge
	                             FROM cover_vs_premium
	                            WHERE icar_type=$cal_car_id
	                              AND iins_type=$ins_type
	                              AND mcoverage1=$next_cover1
	                              AND mcoverage2=$next_cover2
	                              AND drate=(SELECT drate
	                                           FROM ca_rate_date
	                                          WHERE icode=$frate_chk
	                                            AND itable='cover_vs_premium');
	                      	  find_flag = 1;
	                          injured_cover = next_cover1;
	                          death_cover   = next_cover2;
	                          INS_ptr->injured_cover = next_cover1;
	                          INS_ptr->death_cover = next_cover2;
	                          if (iins==53 ||iins==55 ||iins==135 ||iins==255 ||
	                              iins==253 ||iins==555){
	                          	  damage_cover=(qpassenger-1)*death_cover;
	                          }else if(iins==52||iins==252){
	                          	  damage_cover=qpassenger*death_cover;
	                          }
	                          INS_ptr->damage_cover=damage_cover;

	                          #ifdef PRINTF_FLAG
	                          printf("next_cover1[%ld]\n",next_cover1);
	                          printf("next_cover2[%ld]\n",next_cover2);
	                          printf("mpremium[%f]\n",mpremium);
	                          printf("FOUND \n");
	                          #endif
	                      }
	                      $CLOSE next_cur9;
	                      $FREE  next_cur9;

                      }else{ /* �D 52 53 55 255 �� */

	                      $DECLARE next_cur3 CURSOR FOR
	                        SELECT mcoverage1,mcoverage2
	                          INTO $next_cover1,$next_cover2
	                          FROM cover_vs_premium
	                         WHERE icar_type=$cal_car_id
	                           AND iins_type=$ins_type
	                           AND mcoverage1 > $injured_cover
	                           AND drate=(SELECT drate
	                                        FROM ca_rate_date
	                                       WHERE icode=$frate_chk
	                                         AND itable='cover_vs_premium')
	                         ORDER BY 1,2;
	                      $OPEN next_cur3;
	                      $FETCH next_cur3;
	                      if (SQLCODE == SQLNOTFOUND)
	                      {
	                      	  /* �A�䤣���,��է�p�@�Ū��ŶZ */
	                      	  find_flag = 0;
		                      next_cover1 = 0;
		                      next_cover2 = 0;
		                      $DECLARE next_cur3x CURSOR FOR
		                        SELECT mcoverage1,mcoverage2
		                          INTO $next_cover1,$next_cover2
		                          FROM cover_vs_premium
		                         WHERE icar_type=$cal_car_id
		                           AND iins_type=$ins_type
		                           AND mcoverage1 < $injured_cover
		                           AND drate=(SELECT drate
		                                        FROM ca_rate_date
		                                       WHERE icode=$frate_chk
		                                         AND itable='cover_vs_premium')
		                         ORDER BY 1 DESC,2 DESC;
		                      $OPEN next_cur3x;
		                      $FETCH next_cur3x;
		                      if (SQLCODE == SQLNOTFOUND)
		                      {
		                      	  find_flag = 0;
			                      INS_ptr->injured_cover = 0;
		                          INS_ptr->death_cover = 0;
		                          INS_ptr->damage_cover = 0;
		                          INS_ptr->ins_premium = 0;
		                          INS_ptr->bef_ins_premium = 0;
		                          mpremium = 0;
		                          #ifdef PRINTF_FLAG
		                          printf("INTO 5x not found\n");
		                          #endif
		                      }else{
		                          $SELECT mpremium, pextra_charge/100
		                             INTO $mpremium, $pextra_charge
		                             FROM cover_vs_premium
		                            WHERE icar_type=$cal_car_id
		                              AND iins_type=$ins_type
		                              AND mcoverage1=$next_cover1
		                              AND mcoverage2=$next_cover2
		                              AND drate=(SELECT drate
		                                           FROM ca_rate_date
		                                          WHERE icode=$frate_chk
		                                            AND itable='cover_vs_premium');
		                      	  find_flag = 1;
		                          injured_cover = next_cover1;
		                          death_cover   = next_cover2;
		                          INS_ptr->injured_cover = next_cover1;
		                          INS_ptr->death_cover = next_cover2;

		                          if(iins==49){
		                          	damage_cover=qpassenger*death_cover;
		                          }
		                          INS_ptr->damage_cover=damage_cover;

		                          #ifdef PRINTF_FLAG
		                          printf("next_cover1[%ld]\n",next_cover1);
		                          printf("next_cover2[%ld]\n",next_cover2);
		                          printf("mpremium[%f]\n",mpremium);
		                          printf("FOUND \n");
		                          #endif
		                      }
		                      $CLOSE next_cur3x;
		                      $FREE  next_cur3x;
	                      }else{

	                          $SELECT mpremium, pextra_charge/100
	                             INTO $mpremium, $pextra_charge
	                             FROM cover_vs_premium
	                            WHERE icar_type=$cal_car_id
	                              AND iins_type=$ins_type
	                              AND mcoverage1=$next_cover1
	                              AND mcoverage2=$next_cover2
	                              AND drate=(SELECT drate
	                                           FROM ca_rate_date
	                                          WHERE icode=$frate_chk
	                                            AND itable='cover_vs_premium');
	                      	  find_flag = 1;
	                          injured_cover = next_cover1;
	                          death_cover   = next_cover2;
	                          INS_ptr->injured_cover = next_cover1;
	                          INS_ptr->death_cover = next_cover2;

	                          if(iins==49){
	                          	damage_cover=qpassenger*death_cover;
	                          }
	                          INS_ptr->damage_cover=damage_cover;

	                          #ifdef PRINTF_FLAG
	                          printf("next_cover1[%ld]\n",next_cover1);
	                          printf("next_cover2[%ld]\n",next_cover2);
	                          printf("mpremium[%f]\n",mpremium);
	                          printf("FOUND \n");
	                          #endif
	                      }
	                      $CLOSE next_cur3;
	                      $FREE  next_cur3;
                      }
                 }
                 /*return M_CA_NCOVER_PREM;*/
                 #ifdef PRINTF_FLAG
                 printf("cal_car_id[%s]\n",cal_car_id);
                 printf("ins_type[%s]\n",ins_type);
                 printf("injured_cover[%d]\n",injured_cover);
                 printf("death_cover[%d]\n",death_cover);
                 printf("frate_chk[%s]\n",frate_chk);
                 #endif


             	 /* 971008,49�I�Ӹ��H�ƥ]�t�r�p+���� */
                 if (iins==49)
                 {
                     if (damage_cover==0)
                     {
                         damage_cover=qpassenger*death_cover;
                         INS_ptr->damage_cover=qpassenger*death_cover;
                         /*  crystal-861107,prevent devied zero */
                         if (death_cover==0) death_cover=1;
                     }
                     else
                     {
                         if (death_cover==0) death_cover=1;
                         /*  return M_CA_51DEATH_COVER_BIG0; */
                         flag_dam=damage_cover % death_cover;
                         if (flag_dam != 0) flag_dam=0;
                         /*  return M_CA_NDEATHCOVER_TIMES;  */
                     }
                 }
                 /* 950704 */
                 if ((iins==55) || (iins==135) || (iins==255) || (iins==555))
                 {
                     if (damage_cover==0)
                     {
                         damage_cover=(qpassenger-1)*death_cover;
                         INS_ptr->damage_cover=(qpassenger-1)*death_cover;
                         /*  crystal-861107,prevent devied zero */
                         if (death_cover==0) death_cover=1;
                     }
                     else
                     {
                         if (death_cover==0)
                             return M_CA_NCOVER_PREM;

                         flag_dam = damage_cover % death_cover;

                         if (flag_dam != 0)
                             return M_CA_NCOVER_PREM;

                         flag_person = (damage_cover / death_cover);

                         #ifdef PRINTF_FLAG
                         printf("1flag_person=[%d]\n", flag_person );
                         printf("qpassenger=[%d]\n", qpassenger );
                         #endif

                         /* �X��ɪ������H�ƥi��j�� ca_car_model��qpassenger
                         if (flag_person > qpassenger-1)
                             return M_CA_NCOVER_PREM;
                         */
                     }
                 }

                 #ifdef PRINTF_FLAG
                 printf(" ------- short_prate = [%f]\n " , short_prate);
                 printf(" ------- pextra_charge = [%f]\n " , pextra_charge);
                 printf("55/53/49---------cov1[%d] cov2[%d]\n",injured_cover,death_cover);
                 printf("55/53/49---------date[%s]\n",cm_cdate_str_100(wk_date));
                 printf("Cal_ins_prem()#######55@@ short_prate[%f] mpremium[%f]\n",short_prate,mpremium);
                 printf("Cal_ins_prem()#######55@@ death[%d] damage[%d]\n",death_cover,damage_cover);
                 printf("Cal_ins_prem()#######55@@ (damage/death)*mpremium*short_prate\n");
                 printf(" ------- test1 iins[%d]\n ",iins);
                 #endif

                 if (iins==50)
                 {
                      INS_ptr->ins_premium     = mpremium*short_prate; /* round */
                      INS_ptr->bef_ins_premium = mpremium*short_prate; /* round */
                 }
                 else if ((iins!=47 ) && (iins!=147 )&& (iins!=110 )&& (iins!=112 )&&
                           (iins!=117 )&& (iins!=22 ))
                 {
                      #ifdef PRINTF_FLAG
		      printf("iins[%d],damage_cover[%lf],death_cover[%lf] mpremium[%lf]\n",iins , damage_cover , death_cover,mpremium);
		      #endif

		      INS_ptr->ins_premium=((float)damage_cover /(float)death_cover) *mpremium*short_prate;    /*** round ***/
		      INS_ptr->bef_ins_premium=((float)damage_cover /(float)death_cover) *mpremium*short_prate;   /*** round ***/
		 }
                 #ifdef PRINTF_FLAG
                 printf("51@@@@@ ins_premium[%f]\n",INS_ptr->ins_premium);
                 #endif
             }

             if ((iins==47)||(iins==147))
             {
             	/****950704, 47:�����j���I���[�r�p�H�ˮ`�O�I ***/
             	/* �O�v�ۥѤƤ��� */
             	/* �O���p��@�~��,�O�O���ƨ̫����ҭp��«O�O,�p�Ʀ���G��,�ĤT��|�ˤ��J�C*/
             	/* �O�����@�~~�G�~��,�̭�l���󤧤����p��«O�O�p�Ʀ���G��,�ĤT��|�ˤ��J�C*/
             	if( f980101[0] == '1')
             	{
             		$double short_prate_47;
             		short_prate_47 = qply_period/12.0 ;

             		#ifdef PRINTF_FLAG
             		printf("short_prate_47[%f],qply_period[%d]\n", short_prate_47,qply_period);
             		#endif

             		/* �۶O�v�ͮĤ�06/01/2014�_,47�I�د«O�O�p�ⲧ��
                              (1)�@�~��«O�O+((2�~��«O�O-1�~��«O�O)*(�W�L�@�~��ơ�n)/12)
�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@ (��47�����Gadjn_47 = 0.5;��L�Gadjn_47 = 0)
                              (2)�p��L�{�����«O�O��ĺ�ǼƦr(���A�|�ˤ��J),
                                 ����g�J��Ʈw�ɤ~�|�ˤ��J(���׷s�º�k)
                              (3)47�I�ت��u��(�����@�~)�p���ī���p��,�]��O�S�������@�~����,
                                 �����p�⦳�~,�Ȯɥ��d��.�ȥ������|�ˤ��J������
                              modify by sylvia 103.05.21  (1030407005_C4)
                        */

                        if( short_prate_47 == 1) /* 1�~�� */
                        	INS_ptr->pure_prem = mpremium;
                        else if( short_prate_47 == 2) /* 2�~�� */
                        	INS_ptr->pure_prem = mpremium_sec;
                        else if( short_prate_47 < 1)
                        {
                        	INS_ptr->pure_prem = mpremium * short_prate_47; /* �p��L�{�����|�ˤ��J  */
                        }
                        else if( short_prate_47 > 1 && short_prate_47 < 2)
                        {
                        	INS_ptr->pure_prem =  mpremium +
                                       ((mpremium_sec-mpremium) * (iSecondYear2 -adjn_47)/12.0); /* �p��L�{�����|�ˤ��J  */
                        }
                        else
                        	return M_CA_47_PERIOD;

                        INS_ptr->ins_premium     = (long)(d45((INS_ptr->pure_prem * provision_L / ( 1 - INS_ptr->pextra_charge)),0));
                        INS_ptr->bef_ins_premium = INS_ptr->ins_premium;
                        INS_ptr->pure_prem = d45( INS_ptr->pure_prem * provision_L,0);
                }else{
                	if (short_prate>1){
                		INS_ptr->ins_premium     = (long)(d45(mpremium,0));
                		INS_ptr->bef_ins_premium = (long)(d45(mpremium,0));
                		INS_ptr->pure_prem = (long)((float)(349.0)+0.5);
                	}else{
                		INS_ptr->ins_premium     = (long)(d45((mpremium*short_prate),0));
                		INS_ptr->bef_ins_premium = (long)(d45((mpremium*short_prate),0));
                		INS_ptr->pure_prem = (long)(d45((349.0 * short_prate),0));
                	}

                	if (iSecondYear2 > 0)
                	{
                		if ((iSecondYear2 == 12) &&
                		    (strcmp(sTmpmmB, sTmpmmE) == 0) &&
                		    (strcmp(sTmpddB, sTmpddE) == 0))
                		{
                			prem_47_2 = 349;
                			INS_ptr->pure_prem += (prem_47_2);

                			INS_ptr->ins_premium     += (long)(d45((mpremium_sec - mpremium),0));
                			INS_ptr->bef_ins_premium += (long)(d45((mpremium_sec - mpremium),0));
                		}
                		else if (strcmp(sTmpddB, sTmpddE) == 0)
                		{
                			prem_47_2 = d45(((mpremium_sec - mpremium)*((iSecondYear2-0.5)/12)),0);
                			INS_ptr->pure_prem += (prem_47_2);

                			INS_ptr->ins_premium     += (long)(d45(((mpremium_sec - mpremium)*((iSecondYear2-0.5)/12)),0));
                			INS_ptr->bef_ins_premium += (long)(d45(((mpremium_sec - mpremium)*((iSecondYear2-0.5)/12)),0));
                		}
                		else
                		{
                			prem_47_2 = d45(((mpremium_sec - mpremium)*((iSecondYear2-0.5)/12)),0);
                			INS_ptr->pure_prem += (prem_47_2);

                			INS_ptr->ins_premium     += (long)(d45(((mpremium_sec - mpremium)*((iSecondYear2-0.5)/12)),0));
                			INS_ptr->bef_ins_premium += (long)(d45(((mpremium_sec - mpremium)*((iSecondYear2-0.5)/12)),0));
                		}
                	}
                }

                #ifdef PRINTF_FLAG
                printf("iins[%d],ins_premium[%lf],pure_premium[%lf]\n",iins , INS_ptr->ins_premium , INS_ptr->pure_prem);
                #endif
             }

             if ((iins==110)||(iins==112)||(iins==117)||(iins==22))
             {
                    $double short_prate_110;
                    short_prate_110 = qply_period/12.0 ;

                    if( short_prate_110 == 1) /* 1�~�� */
                        INS_ptr->pure_prem = mpremium;
                    else if( short_prate_110 == 2) /* 2�~�� */
                        INS_ptr->pure_prem = mpremium_sec;
                    else if( short_prate_110 < 1)
                    {
                        INS_ptr->pure_prem = mpremium * short_prate_110; /* �p��L�{�����|�ˤ��J  */
                    }
                    else if( short_prate_110 > 1 && short_prate_110 < 2)
                    {
                        INS_ptr->pure_prem =  mpremium +
                            ((mpremium_sec-mpremium) * (qply_period-12)/12.0); /* �p��L�{�����|�ˤ��J  */
                    }
                    else
                        return M_CA_47_PERIOD;


                    INS_ptr->ins_premium     = (long)(d45((INS_ptr->pure_prem * provision_L / ( 1 - INS_ptr->pextra_charge)),0));
                    INS_ptr->bef_ins_premium = INS_ptr->ins_premium;
                    INS_ptr->pure_prem = d45( INS_ptr->pure_prem * provision_L,0);

                    #ifdef PRINTF_FLAG
                    printf("iins[%d],ins_premium[%lf],pure_premium[%lf]\n",iins , INS_ptr->ins_premium , INS_ptr->pure_prem);
                    #endif
             }
        }

        /*** e.(iii) ***/
        step_9_e_iii:
        #ifdef PRINTF_FLAG
        printf("iins[%d]\n",iins);
        #endif

        /* 97.11�J�O�v�ۥѤ� */
        if( f980101[0] == '1')
            pextra_charge = INS_ptr->pextra_charge;
        else
            INS_ptr->pextra_charge = pextra_charge;

        /* 100.01.04, �f�B�~���[����C */
        if (iins == 71){
        	if(strstr(tmp_provision,"C;") != NULL){
        		/* INS_ptr->ins_premium �b71�I�ت��[C���ڤ����w�q���«O�O,���U�~�|�h�����H1-���[�O�βv���ʧ@ */
	        	INS_ptr->ins_premium     *= ( provision_C );
	        	INS_ptr->bef_ins_premium *= ( provision_C );
	        }
        }

        /* T���ں޲z�Φw���[��O�T�� add by sylvia 104.12.02 (104111011_C1) */
        if(strstr(tmp_provision,"T;") != NULL)
        {
           INS_ptr->ins_premium     *= ( 1 + (INS_ptr->safe_rate/100.0) + (INS_ptr->manage_rate/100.0) );
           INS_ptr->bef_ins_premium *= ( 1 + (INS_ptr->safe_rate/100.0) + (INS_ptr->manage_rate/100.0) );
        }

        switch(iins)
        {
              case 47:  case 147: case 117: case 110: case 112: case 22:
                   #ifdef PRINTF_FLAG
                   printf("47,147:INS_ptr->ins_premium [%f]\n",INS_ptr->ins_premium);
                   #endif
                   break;
              case 17:
              case 24:
              case 88:
                   #ifdef PRINTF_FLAG
                   printf("INS_ptr->ins_premium [%f]\n",INS_ptr->ins_premium);
                   #endif

                   INS_ptr->ins_premium = (long)(d45((INS_ptr->ins_premium / (1.0-pextra_charge)),0));
                   INS_ptr->bef_ins_premium = INS_ptr->ins_premium;
                   break;
             case 26:
                   INS_ptr->ins_premium = (long)(d45((INS_ptr->ins_premium / (1.0-pextra_charge)),0));
                   INS_ptr->bef_ins_premium = INS_ptr->ins_premium;
                   break;
             case 10: case 7: case 127:
             	   #ifdef PRINTF_FLAG
                   printf("INTO iins[%d] pextra_charge [%f]\n",iins,pextra_charge);
                   printf("INS_ptr->ins_premium [%f]\n",INS_ptr->ins_premium);
                   #endif

                   INS_ptr->pure_prem = INS_ptr->ins_premium;
                   INS_ptr->ins_premium = (long)(d45((INS_ptr->ins_premium / (1.0-pextra_charge)),0));
                   INS_ptr->bef_ins_premium = INS_ptr->ins_premium;
                   break;
              case 33:
              case 35:
              case 48:
              case 56: case 136: case 166: case 266:
                   break;
              default:
                   switch(iins)
                   {
                         case 1: case 5: case 8: case 9: case 201: case 205: case 209: case 85: case 98: case 105:
                         case 118: case 120: case 122: case 125: case 126: case 181: case 198:

                             ee_tmp = ee1;
                             if (STOP_CHG1589_FLAG == 'Y')
                             {
                                 if ((iins == 1)||(iins == 5)||(iins == 9)||(iins == 201)||(iins == 205)||(iins == 209)||(iins == 181)||(iins == 198))
                                 {
                                     printf("iins[%d] sug_type[%d]\n",iins,sug_type);
                                     premium_10 = d45((INS_ptr->bef_ins_premium / (1.0-pextra_charge)),0);
                                     purprem10 = INS_ptr->pure_prem;    /* �«O�O--��07,10�I�بϥ�,���t�������[�O�Y�� add by sylvia 103.09.12 (1030523002_C3) */

                                     premium_10_sug = premium_10;
                                     purprem10_sug = purprem10;   /*�{��γo�ըS���u��*/
                                     premium_10_ori = premium_10;
                                     purprem10_ori = purprem10;
                                     provision10_P = provision_P;
                                     provision10_Q = provision_Q;
                                     provision10_M = provision_M;
                                     provision10_H = provision_H;
                                     provision10_K = provision_K;
                                     provision10_Y = provision_Y;
                                 }
                             }
                             else
                             {
                                 /* 971203,�ѨM�����I����ĳ����O�զX�����P�I��(05,09)��,10�I�ت��O�O�p����D */
                                 printf("iins[%d] sug_type[%d]\n",iins,sug_type);

                                 premium_10 = d45((INS_ptr->bef_ins_premium / (1.0-pextra_charge)),0);
                                 purprem10 = INS_ptr->pure_prem;    /* �«O�O--��07,10�I�بϥ�,���t�������[�O�Y�� add by sylvia 103.09.12 (1030523002_C3) */

				 if (ins1589_chg_flag==1 ){ /* �쥻09=>��ĳ05 */
    	                             if (iins==5||iins==205){
    	                             	   premium_10_sug = premium_10;
    	                             	   purprem10_sug = purprem10;  /* �«O�O add by sylvia 103.09.12 */
    	                             }else if (iins==9||iins==209){
    	                             	   premium_10_ori = premium_10;
    	                             	   purprem10_ori = purprem10;  /* �«O�O add by sylvia 103.09.12  */
    	                             }
				 }else if (ins1589_chg_flag==2 ){ /* �쥻05=>��ĳ105 */
				     if (iins==105){
				           premium_10_sug = premium_10;
				           purprem10_sug = purprem10;  /* �«O�O add by sylvia 103.09.12  */
				     }else if (iins==5||iins==205){
				           premium_10_ori = premium_10;
				           purprem10_ori = purprem10;  /* �«O�O add by sylvia 103.09.12  */
				     }
				 }else if (ins1589_chg_flag==3 ){ /* �쥻85=>��ĳ105 */
				     if (iins==105){
				           premium_10_sug = premium_10;
				           purprem10_sug = purprem10;  /* �«O�O add by sylvia 103.09.12  */
				     }else if (iins==85){
				           premium_10_ori = premium_10;
				           purprem10_ori = purprem10;  /* �«O�O add by sylvia 103.09.12  */
				     }
				 }else if (ins1589_chg_flag==5 ){ /* �쥻05=>��ĳ118 */
				     if (iins==118){
				           premium_10_sug = premium_10;
				           purprem10_sug = purprem10;
				     }else if (iins==5||iins==205){
				           premium_10_ori = premium_10;
				           purprem10_ori = purprem10;
				     }
				 }else if (ins1589_chg_flag==6 ){ /* �쥻105=>��ĳ118 */
				     if (iins==118){
				           premium_10_sug = premium_10;
				           purprem10_sug = purprem10;
				     }else if (iins==105){
				           premium_10_ori = premium_10;
				           purprem10_ori = purprem10;
				     }
				 }else if (ins1589_chg_flag==7 ){ /* �쥻09=>��ĳ120 */
				     if (iins==120){
				           premium_10_sug = premium_10;
				           purprem10_sug = purprem10;
				     }else if (iins==9||iins==209){
				           premium_10_ori = premium_10;
				           purprem10_ori = purprem10;
				     }
				 }else if (ins1589_chg_flag==8 ){ /* �쥻01=>��ĳ122 */
				     if (iins==122){
				           premium_10_sug = premium_10;
				           purprem10_sug = purprem10;
				     }else if (iins==1||iins==201){
				           premium_10_ori = premium_10;
				           purprem10_ori = purprem10;
				     }
				 }
                             }

			     #ifdef PRINTF_FLAG
			     printf(" ------- ins1589_chg_flag = [%d]\n " , ins1589_chg_flag);
                             printf(" ------- premium_10_sug = [%ld]purprem10_sug=[%f]\n " , premium_10_sug,purprem10_sug);
                             printf(" ------- premium_10_ori = [%ld]purprem10_ori=[%f]\n " , premium_10_ori,purprem10_ori);
                             printf(" ------- premium_10 = [%ld]purprem10=[%f]\n " , premium_10,purprem10);
                             #endif

                             break;
                         case 86:
                             /* �}��86�I�إi���[10�I�� add by 061476 107.11.08 (1070522002_SC3) */
                             premium_10 = d45((INS_ptr->bef_ins_premium / (1.0-pextra_charge)),0);
                             purprem10 = INS_ptr->pure_prem;    /* �«O�O--��10�I�بϥ�,���t�������[�O�Y�� */

                             premium_10_sug = premium_10;
                             purprem10_sug = purprem10;
                             premium_10_ori = premium_10;
                             purprem10_ori = purprem10;
                             provision10_P = provision_P;
                             provision10_Q = provision_Q;
                             provision10_M = provision_M;
                             provision10_Y = provision_Y;

                             break;
                         case 31: case 32: case 231: case 232: case 133: case 134: case 149: case 249:
                         case 531: case 532:
                             ee_tmp = ee2;
                             break;
                         case 11: case 211: case 96: case 129: /* 101.04.30*/
                             ee_tmp = ee3;

                             premium_17 = d45((INS_ptr->bef_ins_premium / (1 - pextra_charge)),0) ;
                             purprem17 = INS_ptr->bef_ins_premium; /* �«O�O add by sylvia 103.09.12  */

                             /* BUG�G�����N���O���ĳ��O���Ȥ��}�s�A�~���|�Q�\�� 108.07.26 add by 061476 (1080507001_SC2)*/
                             if (sug_type==1)
                             {
                             	premium_17_sug = premium_17;
                             	purprem17_sug = purprem17;
                             }
                             else
                             {
                             	premium_17_ori = premium_17;
                             	purprem17_ori = purprem17;
                             }
                             provision17_P = provision_P;
                             provision17_Q = provision_Q;
                             provision17_M = provision_M;

                             break;
                         default:
                             ee_tmp = 0;
                   }


                   #ifdef PRINTF_FLAG
                   printf("ee_tmp[%f]\n",ee_tmp);
                   printf("Cal_ins_prem()#######---------ins_prem[%f]\n",INS_ptr->ins_premium);
                   #endif
                   if (iins==57 || iins==59 || iins==60)
                   {
                         INS_ptr->bef_ins_premium   = (d45((bef_ins_premium1 * provision_P * provision_Q * provision_M * provision_K * provision_L /(1.0-pextra_charge)*(1.0+(double)ee_tmp)),0))+
                                                      (d45((bef_ins_premium2 * provision_P * provision_Q * provision_M * provision_K * provision_L /(1.0-pextra_charge)*(1.0+(double)ee_tmp)),0));  /* round */
                         INS_ptr->ins_premium = (d45((ins_premium1 * provision_P * provision_Q * provision_M * provision_K * provision_L /(1.0-pextra_charge)*(1.0+(double)ee_tmp)), 0))+
                                                (d45((ins_premium2 * provision_P * provision_Q * provision_M * provision_K * provision_L /(1.0-pextra_charge)*(1.0+(double)ee_tmp)), 0));
                   }
                   else if (iins==131 || iins==132 || iins==331 || iins==332)
                   {
	                   #ifdef PRINTF_FLAG
	                   printf("Trace -- iins = [%d] \n",  iins);
	                   printf("131,132�M�I�O�OINS_ptr->ins_premium[%f]\n",INS_ptr->ins_premium);
	                   printf("dbl_len8(INS_ptr->bef_ins_premium)[%f]\n",dbl_len8(INS_ptr->bef_ins_premium));
	                   printf("pextra_charge[%f]\n",pextra_charge);
	                   printf("ee_tmp[%f]\n",ee_tmp);
	                   printf("(dbl_len8(INS_ptr->bef_ins_premium) / (1 - pextra_charge) *(1+ee_tmp) + 0.5)[%f]\n",(dbl_len8(INS_ptr->bef_ins_premium) / (1 - pextra_charge) *(1+ee_tmp) + 0.5));
	                   #endif

	                   INS_ptr->bef_ins_premium = d45((INS_ptr->bef_ins_premium * provision_P * provision_Q * provision_M * provision_K * provision_L / (1.0 - pextra_charge) *(1.0+(double)ee_tmp)),0);
	                   INS_ptr->ins_premium = d45((INS_ptr->ins_premium * provision_P * provision_Q * provision_M * provision_K * provision_L / (1.0-pextra_charge) * (1.0+(double)ee_tmp)), 0);

	                   #ifdef PRINTF_FLAG
	                   printf("131,132�W��INS_ptr->ins_premium[%f]\n",INS_ptr->ins_premium);
	                   printf("INS_ptr->mdiscount[%ld]\n",INS_ptr->mdiscount);
	                   #endif
	           }
                   else
                   {
	                   #ifdef PRINTF_FLAG
	                   printf("Trace -- iins = [%d] \n",  iins);
	                   printf("�M�I�O�OINS_ptr->ins_premium[%f]\n",INS_ptr->ins_premium);
	                   printf("dbl_len8(INS_ptr->bef_ins_premium)[%f]\n",dbl_len8(INS_ptr->bef_ins_premium));
	                   printf("pextra_charge[%f]\n",pextra_charge);
	                   printf("ee_tmp[%f]\n",ee_tmp);
	                   printf("(dbl_len8(INS_ptr->bef_ins_premium) / (1 - pextra_charge) *(1+ee_tmp) + 0.5)[%f]\n",(dbl_len8(INS_ptr->bef_ins_premium) / (1 - pextra_charge) *(1+ee_tmp) + 0.5));
	                   #endif

	                   /* �O�O�p�⤽���[��P�BQ�BK�BL���ڥ[/��O�Y�� add by 061476(1071226006_SC3)(1080408008_SC3)(1080708002_SC3)(1081105005_SC3) */
	                   /* �[��H���[���ګY�� modify by 071004 (1110308005_SC3_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h)*/
	                   INS_ptr->bef_ins_premium = d45((INS_ptr->bef_ins_premium * provision_P * provision_Q * provision_M * provision_K * provision_L * provision_H * provision_Y / (1.0 - pextra_charge) *(1.0+(double)ee_tmp)),0);
	                   INS_ptr->ins_premium = d45((INS_ptr->ins_premium * provision_P * provision_Q * provision_M *provision_K * provision_L * provision_H * provision_Y / (1.0-pextra_charge) * (1.0+(double)ee_tmp)), 0);

	                   #ifdef PRINTF_FLAG
	                   printf("�W��INS_ptr->ins_premium[%f]\n",INS_ptr->ins_premium);
	                   printf("INS_ptr->mdiscount[%ld]\n",INS_ptr->mdiscount);
	                   #endif
	           }
                   break;
        }
        #ifdef PRINTF_FLAG
        printf("-------->INS_ptr->pcommission[%4.2f]\n",INS_ptr->pcommission);
        printf("-------->INS_ptr->pagent[%4.2f]\n",INS_ptr->pagent);
        printf("-------->INS_ptr->pdiscount[%4.2f]\n",INS_ptr->pdiscount);
        #endif

        /** 12 �I�ثO�B���O�O��6�� **/
        /** 12�I�ثO�B���A�t���˥h�B�z (1080422010_SC4) **/
        if( iins == 12 )
           INS_ptr->damage_cover = (long)(INS_ptr->ins_premium*6);
           /* INS_ptr->damage_cover = (long)((INS_ptr->ins_premium*6)/1000)*1000;*/

        /* 950704 */
        /* �ˮ`�I�O�I�O�Φ����B�N�z�B�����w�g�p��A�𶷭��s�p�� */
        if( (iins==33) || (iins==35) || (iins==48) || (iins==56) || (iins==136) || (iins==166)|| (iins==266))
        {
            /* �ˮ`�I�O�I����������2�G���d�I */
            if (*fdiscount!='Y')
            {
                 INS_ptr->mdiscount   = 0;
            }
            else
            {
                 mlia_discount        = mlia_discount + INS_ptr->mdiscount;
            }
        }
        else
        {
            cal_pdiscount   = INS_ptr->pdiscount;
            cal_prem        = INS_ptr->ins_premium;

            if (*fins_grp=='1')  /*���l*/
            {
                if (*fdiscount!='Y')
                {
                     INS_ptr->mdiscount   = 0;
                }
                else
                {
                     #ifdef PRINTF_FLAG
                     printf("-------->cal_pdiscount[%4.2f]\n",cal_pdiscount);
                     printf("-------->cal_prem[%ld]\n",cal_prem);
                     #endif

                     INS_ptr->mdiscount   = (long)(d45(((float)cal_prem*cal_pdiscount/100),0));

                     mdmg_discount=mdmg_discount+INS_ptr->mdiscount;
                }
                mdmg_prem=mdmg_prem+INS_ptr->ins_premium;

                #ifdef PRINTF_FLAG
                printf("Cal_ins_prem_302()####### mdmg_discount[%f]\n",mdmg_discount);
                printf("------ mdmg_commission[%f] mdmg_agent[%f]\n",mdmg_commission,mdmg_agent);
                #endif
            }
            else
            {
                if (*fdiscount!='Y')
                {
                     INS_ptr->mdiscount   = 0;
                }
                else
                {
                     INS_ptr->mdiscount   = (long)(d45(((float)cal_prem*cal_pdiscount/100),0));
                     mlia_discount=mlia_discount+INS_ptr->mdiscount;
                }
                #ifdef PRINTF_FLAG
                printf("Cal_ins_prem_302()####### mlia_discount[%f]\n",mlia_discount);
                printf("------------- mlia_commission[%f] mlia_agent[%f]\n",mlia_commission,mlia_agent);
                #endif
            }

        }

        /* �]33�I�ؤw�����U�Ӷ��Q�O�I�H������ �A�w��ñ��O�O */
        /* 960528,�ץ��޿� */
        if ((iins != 33) && (iins != 35) && (iins != 48) && (iins != 56) && (iins != 136) && (iins != 166) && (iins != 266))
            INS_ptr->ins_premium = INS_ptr->ins_premium - INS_ptr->mdiscount;

        if ((damage_add_flag == 1)||(thief_add_flag == 1)){
        	LngQday = INS_ptr->qday;
	        #ifdef PRINTF_FLAG
	        printf("iins[%d] LngQday[%d] sug_type[%d]\n",iins,LngQday,sug_type);
	        #endif
        }

       /* 101.04.30 ,add 96 */
       /* ���[����N�B���Ϊ��[�ѵs�N�B�� */
       if ( (LngQday>0)&&(
             ((iins == 1 || iins == 5 || iins == 8 || iins == 9 || iins == 85||
               iins == 105 || iins == 118 || iins == 120 || iins == 122 ||
               iins == 125 || iins == 126 || iins == 201 || iins == 205 || iins == 209) && (damage_add_flag == 1)) ||
             (((iins == 11) || (iins == 211) || (iins == 96) || (iins == 129)) && (thief_add_flag == 1)) ) )
       {
             /*�I�� ins_type                 */
             /*���� car_typei2               */
             /*�Ѽ� LngQday = INS_ptr->qday  */
             /*�O��ͮİ_�� ply2_begin       */

             /*LngQday = INS_ptr->qday;*/

             $SELECT mexpense
                INTO :LngMexpensePrem
                FROM ca_add_mplace
               WHERE iins_type = $ins_type
                 AND icar_type = $cal_car_id
                 AND qday      = $LngQday
                 AND drate = (SELECT MAX(drate)
                                FROM ca_add_mplace
                               WHERE iins_type = $ins_type
                                 AND icar_type = $cal_car_id
                                 AND qday      = $LngQday
                                 AND drate     <= $dply_begin);
                #ifdef PRINTF_FLAG
                printf("LngMexpensePrem[%ld]\n",LngMexpensePrem);
                printf("ins_type[%s] cal_car_id[%s] qday[%ld]\n",ins_type,cal_car_id,LngQday);
                #endif
             if (NOT_FOUND)
             {
                #ifdef PRINTF_FLAG
                printf("M_CA_NOT_ADD_MPLACE\n");
                #endif
                 /* return M_CA_NOT_ADD_MPLACE; */
                 LngMexpensePrem = 0;
                 LngQday = 0;
                 INS_ptr->qday = 0;
             }

             LngMexpensePremOri = (long)(d45(((double)LngMexpensePrem*(1.0+(double)ee_tmp)),0));
             INS_ptr->mexp_disc = (long)(d45((LngMexpensePremOri*cal_pdiscount/100.0),0));

             #ifdef PRINTF_FLAG
             printf("ori_mexpenseprem[%ld],mexp_disc[%ld]\n",LngMexpensePremOri,INS_ptr->mexp_disc);
             #endif
             INS_ptr->mexpense  = LngMexpensePremOri - INS_ptr->mexp_disc;

             INS_ptr->bef_ins_premium += LngMexpensePremOri;
             INS_ptr->ins_premium     += INS_ptr->mexpense;
             INS_ptr->mdiscount       += INS_ptr->mexp_disc;
       }
       else if(iins == 15 || iins == 16 || iins == 66 || iins == 67 || iins == 38 ||
               iins == 39 || iins == 106 || iins == 119 || iins == 121 || iins == 123 ||
               iins == 156 || iins == 154 || iins == 155 || iins == 163 || iins == 238)
       {
       	     INS_ptr->qday      = qday;
             INS_ptr->mexp_disc = 0;
             INS_ptr->mexpense  = 0;
       }
       else if(iins == 29)
       {
              /* �W�B�d���I���Nqday�k0,qday���O����h�O�B�N�� */
             INS_ptr->mexp_disc = 0;
             INS_ptr->mexpense  = 0;
       }
       else
       {
             INS_ptr->qday      = 0;
             INS_ptr->mexp_disc = 0;
             INS_ptr->mexpense  = 0;
       }

       premium2     = premium2     + INS_ptr->ins_premium;

       /* �����N�z�v�ϥ�ñ��O�O����v   */
       if (mode==0) goto rec_ins_qcvg;

       /*** e.(v) ***/

       rec_ins_qcvg:
       /*** keep every insurance type's fdeduct & qcoverage.. ***/
       *(INS_ptr->fdeduct)=*fdeduct;
       *(INS_ptr->fins_grp)=*fins_grp;
       INS_ptr->qcoverage=qcoverage;
       INS_ptr->qserial=qserial;

       #ifdef PRINTF_FLAG
       printf("Cal_ins_prem_302()####### INS_ptr->drate_ym[%s]\n",INS_ptr->drate_ym);
       #endif

       if (iins==31 || iins==32 || iins==149 || iins==231 || iins==232 ||
           iins==249 || iins==531 || iins==532){
       	/* �������[���ڡB�j�vB���ڤ��p��F�Ƭ����A�٭�F�Ƭ��� ( �j�v�ȳB�z�@���) */
       	if(strstr(tmp_provision,"F;") != NULL){
       		plia_acc = plia_acc_ori;
       	}

       	/* G���ڤ��F���� add by sylvia 105.08.06 (1050705002_C3) */
       	if(strstr(tmp_provision,"G;") != NULL){
       		plia_acc = plia_acc_ori;
       	}

       	if(strstr(tmp_provision,"B;") != NULL){
       		plia_acc = plia_acc_ori;
       	}
       }

       /* 77,78�I�ؤ��p��F�Ƭ����A�٭�F�Ƭ��� add by sylvia 103.04.03 (1000310003_C3)*/
       if (iins==77 || iins==78)
       {
       	plia_acc = plia_acc_ori;
       }

       INS_ptr=INS_ptr->next;
    }   /** end while-INS_ptr **/

    #ifdef PRINTF_FLAG
    printf("end of Cal_ins_prem_302()####### \n");
    #endif
    return SUCCESS;

errexit:
    printf(" Cal_ins_prem_302() error: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/*****************************************************************/
/* 101.04.30 ,add 96*/
int Insert_SUG_TYPE (s1,p1,p2,p3,p4,p5,p10,p6,p7,s2,p8,p9,p11,p12,p13)
char   *s1,*s2;
long   p1,p2,p3,p4,p5,p9,p10,p11,p12,p13;
double p6,p7,p8;
{
    int  g_list=0;
    /*** use a link list ***/
    printf("-------------------------\n");
    printf("into Insert_SUG_TYPE s1=[%s]\n",s1);


    Icur1=Ifirst;
    while (Icur1)
    {
        if( (atoi(Icur1->ins_type)==atoi(s1)) &&
            (Icur1->sug_iins_type == p13))
        {
            g_list=1;
            break;
        }
        Icur1=Icur1->next;
    }

    if( g_list == 0 )
    {
        printf("in insert data\n");
        /** list �L��ơA�s�W�I�� **/
        Icurr=(struct INS_TYPE *)malloc(sizeof(struct INS_TYPE));
        if (Icurr==NULL) return FAIL;
        if (Ifirst==NULL) {     /* if it's first element?! */
            Ifirst=Ilast=Icurr;
            Icurr->next=NULL;
        }else if (strcmp(trim(s1),"01")==0 || strcmp(trim(s1),"11")==0 ||
                  strcmp(trim(s1),"31")==0 || strcmp(trim(s1),"32")==0 ||
                  strcmp(trim(s1),"36")==0 || strcmp(trim(s1),"37")==0 ||
                  strcmp(trim(s1),"77")==0 || strcmp(trim(s1),"78")==0 ||
                  strcmp(trim(s1),"05")==0 || strcmp(trim(s1),"09")==0 ||
                  strcmp(trim(s1),"08")==0 || strcmp(trim(s1),"85")==0 ||
                  strcmp(trim(s1),"96")==0 || strcmp(trim(s1),"98")==0 ||
                  strcmp(trim(s1),"105")==0 || strcmp(trim(s1),"118")==0 ||
                  strcmp(trim(s1),"120")==0 || strcmp(trim(s1),"125")==0 ||
                  strcmp(trim(s1),"126")==0 || strcmp(trim(s1),"129")==0 ||
                  strcmp(trim(s1),"133")==0 || strcmp(trim(s1),"134")==0 ||
                  strcmp(trim(s1),"149")==0 || strcmp(trim(s1),"181")==0 ||
                  strcmp(trim(s1),"198")==0 || strcmp(trim(s1),"201")==0 ||
                  strcmp(trim(s1),"205")==0 || strcmp(trim(s1),"209")==0 ||
                  strcmp(trim(s1),"211")==0 || strcmp(trim(s1),"231")==0 ||
                  strcmp(trim(s1),"232")==0 || strcmp(trim(s1),"249")==0 ||
                  strcmp(trim(s1),"531")==0 || strcmp(trim(s1),"532")==0)
        {
            /*** ins_type=01,11,31,32  should insert in front of the link list **/
            Icurr->next=Ifirst;
            Ifirst=Icurr;
        } else {
            Ilast->next=Icurr;
            Ilast=Icurr;
            Icurr->next=NULL;
        }
        strcpy(Icurr->ins_type,s1);
        Icurr->injured_cover=p1;
        Icurr->death_cover=p2;
        Icurr->damage_cover=p3;
        Icurr->deduct=p4;
        Icurr->ins_premium=p5;
        Icurr->bef_ins_premium=p10;

        /* 850718 dale add pagent pcommission */
        Icurr->pagent=p6;
        Icurr->pcommission=p7;
        strcpy(Icurr->frate,s2);
        Icurr->pdiscount=p8;
        Icurr->mprem=p9;
        Icurr->qday=p11;
        Icurr->mexpense=p12;
        Icurr->sug_iins_type=p13;
        rows++;
    }
    else
    {
        /** list ����ơA���O�B **/
        printf("in update data Icur1->sug_iins_type=[%d]\n",Icur1->sug_iins_type);
        printf("Icur1->injured_cover=[%d] p1=[%d]\n",Icur1->injured_cover,p1);

        Icur1->injured_cover=p1;
        Icur1->death_cover=p2;
        Icur1->damage_cover=p3;
    }


    return SUCCESS;
}
/*****************************************************************/
int Delete_SUG_TYPE (s1)
char   *s1;
{
    int  g_list=0;
    /*** use a link list ***/
    Icur1=Ifirst;
    while (Icur1)
    {
        if( atoi(Icur1->ins_type)==atoi(s1) )
        {
            strcpy(Icur1->ins_type,"**");

            rows--;
        }
        Icur1=Icur1->next;
    }

    return SUCCESS;
}

/* 96.01.10, ��ca302q01s.ec ���ܦ� */
/**************************************************************************
Insert_INS_TYPE_33(cIinsurant, cNinsurant, lDbirth, cAinsurant, cIins_scope, cIcareer,
                   lMins_amt, lMins_premium,
                   dPcommission, lMcommission, dPagent, lMagent, dPdiscount, lMdiscount,
                   cNapplicant, cRelation_appl,
                   cNbeneficiary, cRelation_bene))
***************************************************************************/
int Insert_INS_TYPE_33(c1, c2, l1, c3, c4, c5, l2, l3, d1, l4, d2, l5, d3, l6, c6, c7, c8, c9, l7, l8, d4, c10, c11, c12, c13, l9)
char   *c1, *c2, *c3, *c4, *c5, *c6, *c7, *c8, *c9, *c10, *c11, *c12, *c13;
long   l1, l2, l3, l4, l5, l6, l7, l8,l9;
double d1, d2, d3, d4;
{
    #ifdef PRINTF_FLAG
	printf("\ Insert_INS_TYPE_33---------Insert_INS_TYPE_33-------\n");
	printf("c1=[%s]\n",c1);
	printf("c2=[%s]\n",c2);
	printf("l1=[%ld]\n",l1);
	printf("c3=[%s]\n",c3);
	printf("c4=[%s]\n",c4);
	printf("c5=[%s]\n",c5);
	printf("l2=[%ld]\n",l2);
	printf("l3=[%ld]\n",l3);
	printf("d1=[%f]\n",d1);
	printf("l4=[%ld]\n",l4);
	printf("d2=[%f]\n",d2);
	printf("l5=[%ld]\n",l5);
	printf("d3=[%f]\n",d3);
	printf("l6=[%ld]\n",l6);
	printf("c6=[%s]\n",c6);
	printf("c7=[%s]\n",c7);
	printf("c8=[%s]\n",c8);
	printf("c9=[%s]\n",c9);
	printf("l7=[%ld]\n",l7);
	printf("l8=[%ld]\n",l8);
	printf("d4=[%f]\n",d4);
	printf("c10=[%s]\n",c10);
	printf("c11=[%s]\n",c11);
	printf("c12=[%s]\n",c12);
	printf("c13=[%s]\n",c13);
	printf("\Insert_INS_TYPE_33---------Insert_INS_TYPE_33-------\n");
    #endif
    Icurr_33=(struct INS_TYPE_33 *)malloc(sizeof(struct INS_TYPE_33));
    if (Icurr_33==NULL) return FAIL;
    if (Ifirst_33==NULL)
    {
        Ifirst_33=Ilast_33=Icurr_33;
        Icurr_33->next=NULL;
    }
    else
    {
        Ilast_33->next = Icurr_33;
        Ilast_33       = Icurr_33;
        Icurr_33->next = NULL;
    }

    strcpy(Icurr_33->cIinsurant,     c1);
    strcpy(Icurr_33->cNinsurant,     c2);
    strcpy(Icurr_33->cAinsurant,     c3);
    strcpy(Icurr_33->cIins_scope,    c4);
    strcpy(Icurr_33->cIcareer,       c5);
    strcpy(Icurr_33->cNapplicant,    c6);
    strcpy(Icurr_33->cRelation_appl, c7);
    strcpy(Icurr_33->cNbeneficiary,  c8);
    strcpy(Icurr_33->cRelation_bene, c9);
    strcpy(Icurr_33->iins_type,      c10);
    strcpy(Icurr_33->cTbenef,        c11);
    strcpy(Icurr_33->cAbenef_zip,    c12);
    strcpy(Icurr_33->cAbenef,        c13);

    Icurr_33->lDbirth       = l1;
    Icurr_33->lMins_amt     = l2;
    Icurr_33->lMins_premium = l3;
    Icurr_33->dPcommission  = d1;
    Icurr_33->lMcommission  = l4;
    Icurr_33->dPagent       = d2;
    Icurr_33->lMagent       = l5;
    Icurr_33->dPdiscount    = d3;
    Icurr_33->lMdiscount    = l6;
    Icurr_33->lDaily_pay    = l7;
    Icurr_33->lMr_ins_prem  = l8;
    Icurr_33->lMr_pure_prem = d4;
    Icurr_33->sug_iins_type = l9;

    return SUCCESS;
}

/*****************************************************************/
/* 960612, ex. ���ݪ��I34 */
int Insert_PLY_INS_COVER(c1, c2, c3, c4, c5, l1, l2, l3, l4, d1, l5, l6, l7, d2, d3, i1)
char   *c1, *c2, *c3, *c4, *c5;
long   l1, l2, l3, l4, l5, l6, l7;
double d1,d2,d3;
int    i1;
{
    #ifdef PRINTF_FLAG
		printf("Insert_PLY_INS_COVER----------------\n");
		printf("c1=[%s]\n",c1);
		printf("c2=[%s]\n",c2);
		printf("c3=[%s]\n",c3);
		printf("c4=[%s]\n",c4);
		printf("c5=[%s]\n",c5);
		printf("l1=[%ld]\n",l1);
		printf("l2=[%ld]\n",l2);
		printf("l3=[%ld]\n",l3);
		printf("l4=[%ld]\n",l4);
		printf("d1=[%f]\n",d1);
		printf("l5=[%ld]\n",l5);
		printf("l6=[%ld]\n",l6);
		printf("l7=[%ld]\n",l7);
		printf("d2=[%f]\n",d2);
		printf("d3=[%f]\n",d3);
		printf("i1=[%d]\n",i1);
		printf("Insert_PLY_INS_COVER----------------\n");
    #endif

    /* i1:��ĳ���A=> 0:���O�զX; 1:��ĳ��O�զX */
    if (i1==0){
	    IcurrPlyInsCover=(struct PLY_INS_COVER *)malloc(sizeof(struct PLY_INS_COVER));
	    if (IcurrPlyInsCover==NULL) return FAIL;
	    if (IfirstPlyInsCover==NULL)
	    {
	        IfirstPlyInsCover=IlastPlyInsCover=IcurrPlyInsCover;
	        IcurrPlyInsCover->next=NULL;
	    }
	    else
	    {
	        IlastPlyInsCover->next = IcurrPlyInsCover;
	        IlastPlyInsCover       = IcurrPlyInsCover;
	        IcurrPlyInsCover->next = NULL;
	    }

	    strcpy(IcurrPlyInsCover->iins_type,c1);         /* �I�إN�� */
	    strcpy(IcurrPlyInsCover->cover_name,c2);        /* �O�B���� */
	    strcpy(IcurrPlyInsCover->print_name,c3);        /* �O�B�C�L�W�� */
	    strcpy(IcurrPlyInsCover->icover_type,c4);       /* �O�B���� */
	    strcpy(IcurrPlyInsCover->iprem_cover_type,c5);  /* ��m�O�O���O�B���� */

	    IcurrPlyInsCover->mcover = l1;                  /* �O�B */
	    IcurrPlyInsCover->mcover_prem = l2;             /* ñ��O�O */
	    IcurrPlyInsCover->mdiscount = l3;               /* ���� */
	    IcurrPlyInsCover->mprem = l4;                   /* �W���O�O */
	    IcurrPlyInsCover->mpure_prem = d1;              /* �«O�O */

	    IcurrPlyInsCover->mcover_prem_n = l5;           /* �D�A�Ψ���ñ��O�O */
	    IcurrPlyInsCover->mdiscount_n = l6;             /* �D�A�Ψ������� */
	    IcurrPlyInsCover->mprem_n = l7;                 /* �D�A�Ψ����W���O�O */
	    IcurrPlyInsCover->mpure_prem_n = d2;            /* �D�A�Ψ����«O�O */

	    IcurrPlyInsCover->pextra_charge = d3;           /* ���[�O�βv */

    }else{
	    IcurrPlyInsCover1=(struct PLY_INS_COVER *)malloc(sizeof(struct PLY_INS_COVER));
	    if (IcurrPlyInsCover1==NULL) return FAIL;
	    if (IfirstPlyInsCover1==NULL)
	    {
	        IfirstPlyInsCover1=IlastPlyInsCover1=IcurrPlyInsCover1;
	        IcurrPlyInsCover1->next=NULL;
	    }
	    else
	    {
	        IlastPlyInsCover1->next = IcurrPlyInsCover1;
	        IlastPlyInsCover1       = IcurrPlyInsCover1;
	        IcurrPlyInsCover1->next = NULL;
        }
	    strcpy(IcurrPlyInsCover1->iins_type,c1);         /* �I�إN�� */
	    strcpy(IcurrPlyInsCover1->cover_name,c2);        /* �O�B���� */
	    strcpy(IcurrPlyInsCover1->print_name,c3);        /* �O�B�C�L�W�� */
	    strcpy(IcurrPlyInsCover1->icover_type,c4);       /* �O�B���� */
	    strcpy(IcurrPlyInsCover1->iprem_cover_type,c5);  /* ��m�O�O���O�B���� */

	    IcurrPlyInsCover1->mcover = l1;                  /* �O�B */
	    IcurrPlyInsCover1->mcover_prem = l2;             /* ñ��O�O */
	    IcurrPlyInsCover1->mdiscount = l3;               /* ���� */
	    IcurrPlyInsCover1->mprem = l4;                   /* �W���O�O */
	    IcurrPlyInsCover1->mpure_prem = d1;              /* �«O�O */
	    IcurrPlyInsCover1->mcover_prem_n = l5;           /* �D�A�Ψ���ñ��O�O */
	    IcurrPlyInsCover1->mdiscount_n = l6;             /* �D�A�Ψ������� */

	    IcurrPlyInsCover1->mprem_n = l7;                 /* �D�A�Ψ����W���O�O */
	    IcurrPlyInsCover1->mpure_prem_n = d2;            /* �D�A�Ψ����«O�O */
	    IcurrPlyInsCover1->pextra_charge = d3;           /* ���[�O�βv */
    }

    /*IcurrPlyInsCover->suggest = i1;*/                 /* ��ĳ���A=> 0:���O�զX; 1:��ĳ��O�զX */
    return SUCCESS;

}
/*****************************************************************/

/* 960110, ���o�O�O�p��һݤ������Y���ɨæs�� struct */
long Get_Data_For_Cal_ins_prem_302(iply_ym_end,userid)
int iply_ym_end;
char  userid[12];
{

    $char    icar_type_chk[3];
    $char    iins_type_chk[INSURANCE_TYPE];
    $long    mcoverage1_chk;
    $long    mcoverage2_chk;
    $long    mdeduct_chk;
    $double  mpremium_chk;
    $double  pextra_charge_chk;
    $char    isame_ins_chk[INSURANCE_TYPE];
    $long    msi_coverage_chk;
    $long    msi_premium_chk;
    $date    drate_chk;
    $char    frate_chk[4];
    $float   qpt_bgn_chk;
    $float   qpt_end_chk;
    $char    fpt_chk[2];
    $double  prate_chk;
    $double  mprem_chk;
    $char    ical_ins_chk[INSURANCE_TYPE];
    $char    fcal_class_chk[2];

    /* �O�v�� */
    $char    icar_type_comp[3];
    $int     qperiod_comp;
    $double  qcar_personbgn_comp;
    $double  qcar_personend_comp;
    $long    mcoverage1_comp;
    $long    mcoverage2_comp;
    $long    mcoverage3_comp;
    $double  mpremium_comp;
    $double  mbusiness_comp;
    $double  mresearch_comp;
    $double  maintain_comp;
    $date    drate_comp;
    $double  pready_rate_comp;
    $double  pcomprate_comp;
    $double  pstablerate_comp;
    $double  pinvestrate_comp;
    $double  pinterest_comp;
    $double  pcapital_comp;
    $long    mdrunk_prem;
    $long    mviolate_prem;
    $char    frate_comp[4];

    $char    fdmg_brg_fac[3];
    $char    irate_fac[3];
    $char    ipro_year_fac[5];
    $double  pfactor_fac;
    $date    drate_fac;
    $char    frate_fac[4];

    $char    fcard_class_sex[6];
    $int     qage_bgn_sex;
    $int     qage_end_sex;
    $char    fsex_sex[2];
    $double  pfactor_sex;
    $date    drate_sex;
    $char    frate_sex[4];

    $char   ibrand_mdl[9];
    $char   nbrand_abbr_mdl[13];
    $char   nbrand_mdl[31];
    $char   nbrand_eng_mdl[21];
    $char   icar_type_mdl[3];
    $char   fpt_mdl[2];
    $char   fuse_type_mdl[2];
    $char   icar_series_mdl[3];
    $char   ipro_year_mdl[5];
    $char   idmg_rate_mdl[3];
    $char   ibrg_rate_mdl[3];
    $char   frate_mdl[4];
    $double qcylinder_mdl;  /* �Ʈ�q�X�ܤp���I2�� (1080902001_SC3) */
    $double qpassenger_mdl;
    $date   dalter_mdl;
    $date   drate_mdl;
    $double mcar_price_mdl;
    $char   fdmg_brg_min[3];
    $char   ipro_year_min[5];
    $date   drate_min;
    $char   frate_min[4];
    $char   iins_type_ins[INSURANCE_TYPE];
    $char   nins_type_ins[29];
    $char   nins_abbr_ins[7];
    $char   edomain1_ins[25];
    $char   edomain2_ins[81];
    $int    qcoverage_ins;
    $char   fdeduct_ins[2];
    $char   isame_ins_ins[INSURANCE_TYPE];
    $char   imain_ins_ins[INSURANCE_TYPE];
    $char   fins_grp_ins[2];
    $char   fprint_ins[2];
    $int    qserial_ins;
    $char   fcal_way_ins[2];
    $char   fprint1_ins[2];
    $char   iins_type_rule_ins[3];
    $char   frule_ins[2];
    $char   iri_ins_ins[INSURANCE_TYPE];
    $int    tmp_iym_end;
    $char   renew_icode[4];
    $int    renew_iym_bgn;
    $int    renew_iym_end;
    $char   renew_fcard_class[2];
    $char   renew_code_flag[2];
    $long   renew_deffect_bgn;
    $long   renew_deffect_end;
    $char   update_ipolicy[21];
    $char   update_iofficer[11];
    $char   update_ibig_sales[11];
    $char   update_note[3];
    $char   SelectEquip[100];

    $char   comp_fcard_class[2];
    $int    comp_qclass;
    $double comp_factor;

    $char    stmt_buf[8192];
	/*$char    tmp_frate1[3];   �j��O�v�ͮĥN�� */
	/*$char    tmp_frate2[3];   ���N�O�v�ͮĥN�� */

    $char    err_buf[151];
    $char    fassured_comp_t[2] ;
    $char    fcar_class[3];

    /* �j���I��� */
    $char    comp_iroute_main[21], comp_officer[11], comp_iins_cat[2], comp_iyear[3];
    $int     comp_busi;

    /* �������Y�� add by sylvia 104.11.25 (1021211003_C1) */
    $int iCountx;
    $long car_price_bgn,car_price_end;



    $WHENEVER SQLERROR GOTO errexit;
		/*
			min_car_factor=NULL;
			cover_vs_prem=NULL;
			ca_rate=NULL;
			comp_prem=NULL;
			car_model_factor=NULL;
			ca_sex_age_factor=NULL;
			ca_car_model=NULL;
			insurance_type=NULL;
			ca_rate_renew=NULL;
			ca_comp_acc_factor=NULL;
		*/
    /****************************************************/

    tmp_iym_end = iply_ym_end;

    /* �j���I��O�O�v�N��
    $SELECT icode
       INTO $tmp_frate1
       FROM ca_rate_renew
      WHERE iym_bgn <= $tmp_iym_end
        AND iym_end >= $tmp_iym_end
        AND fcard_class = '1';
    if (SQLCODE == SQLNOTFOUND)
    {
       sprintf_s( err_buf,sizeof err_buf, "�j���I��O�O�v�ͮĦ~��[%d] not in ca_rate_renew", tmp_iym_end);
       EWRITE(userid,M_CA_NRATE_DATE, err_buf);
       return M_CA_NRATE_DATE;
    }

    strcpy(tmp_frate1,trim(tmp_frate1));*/

    /* ���N�I��O�O�v�N��
    $SELECT icode
       INTO $tmp_frate2
       FROM ca_rate_renew
      WHERE iym_bgn <= $tmp_iym_end
        AND iym_end >= $tmp_iym_end
        AND fcard_class = '2';
    if (SQLCODE == SQLNOTFOUND)
    {
       sprintf_s( err_buf,sizeof err_buf, "���N�I��O�O�v�ͮĦ~��[%d] not in ca_rate_renew", tmp_iym_end);
       EWRITE(userid, M_CA_NRATE_DATE, err_buf);
       return M_CA_NRATE_DATE;
    }

    strcpy(tmp_frate2,trim(tmp_frate2));*/

    #ifdef PRINTF_FLAG
    printf("tmp_frate1[%s]\n",tmp_frate1);
    printf("tmp_frate2[%s]\n",tmp_frate2);
    printf("begin insert into min_car_model_t \n");
    #endif

   /****************************************************/
    max_min_car_factor = (max_min_car_factor==NULL) ? 0 : max_min_car_factor ;
    /*max_min_car_factor = 0;*/
    sprintf_s(stmt_buf,sizeof stmt_buf,"SELECT %s FROM %s %s WHERE %s %s %s %s %s ",
                     " a.fdmg_brg, MIN(a.ipro_year), a.drate, b.icode ",
                     " car_model_factor a ,",
                     " ca_rate_date b ",
                     " a.drate = b.drate ",
                     " AND b.itable = 'car_model_factor'",
                     " AND b.icode = ? ",
                     " GROUP BY 1,3,4 ",
                     " ORDER BY 1,4 desc ");

    $PREPARE CUR_TMP  FROM $stmt_buf;
    #ifdef PRINTF_FLAG
    printf("stmt_buf[%s]\n",stmt_buf);
    #endif
    $DECLARE cur_H CURSOR FOR CUR_TMP;
    $OPEN    cur_H USING $tmp_frate2;
    for(;;)
    {
        $FETCH cur_H INTO $fdmg_brg_min, $ipro_year_min, $drate_min, $frate_min;

        if (SQLCODE == SQLNOTFOUND)
            break;
        /* the following block is modified by paili */
        min_car_factor=(struct min_car_factor_t *) realloc (min_car_factor,(max_min_car_factor+1) * sizeof(struct min_car_factor_t));

        strcpy(min_car_factor[max_min_car_factor].fdmg_brg  , trim(fdmg_brg_min));
        strcpy(min_car_factor[max_min_car_factor].ipro_year , trim(ipro_year_min));
        strcpy(min_car_factor[max_min_car_factor].frate     , trim(frate_min));

        min_car_factor[max_min_car_factor].drate = drate_min;
        max_min_car_factor ++;
    }
    $CLOSE  cur_H;
    $FREE   cur_H;
    #ifdef PRINTF_FLAG
    printf("max_min_car_factor[%ld]\n",max_min_car_factor);
    printf("begin insert into cover_vs_prem_t \n");
    #endif
    max_cover_prem = (max_cover_prem==NULL) ? 0 : max_cover_prem ;
    /*max_cover_prem = 0;*/

    sprintf_s(stmt_buf,sizeof stmt_buf,"SELECT DISTINCT %s %s FROM %s %s WHERE %s %s %s %s ",
                     " a.icar_type, a.iins_type, a.mcoverage1, a.mcoverage2, a.mdeduct,",
                     " a.mpremium, a.pextra_charge/100, a.isame_ins, a.msi_coverage, a.msi_premium, a.drate, b.icode ",
                     " cover_vs_premium a ,",
                     " ca_rate_date b ",
                     " a.drate = b.drate ",
                     " AND b.itable = 'cover_vs_premium'",
                     " AND b.icode = ? ",
                     " ORDER BY a.drate desc ,a.icar_type,a.iins_type ");

    $PREPARE CUR_TMP  FROM $stmt_buf;

    #ifdef PRINTF_FLAG
    printf("stmt_buf[%s]\n",stmt_buf);
    #endif
    $DECLARE cur_A CURSOR FOR CUR_TMP;
    $OPEN    cur_A USING $tmp_frate2;
    for(;;)
    {
        $FETCH cur_A INTO $icar_type_chk, $iins_type_chk,  $mcoverage1_chk, $mcoverage2_chk, $mdeduct_chk,
                          $mpremium_chk, $pextra_charge_chk, $isame_ins_chk, $msi_coverage_chk, $msi_premium_chk, $drate_chk, $frate_chk;
        if (SQLCODE == SQLNOTFOUND)
            break;
        /* the following block is modified by paili */
        cover_vs_prem=(struct cover_vs_prem_t *) realloc (cover_vs_prem,(max_cover_prem+1) * sizeof(struct cover_vs_prem_t));

        strcpy(cover_vs_prem[max_cover_prem].icar_type , trim(icar_type_chk));
        strcpy(cover_vs_prem[max_cover_prem].iins_type , trim(iins_type_chk));
        strcpy(cover_vs_prem[max_cover_prem].isame_ins , trim(isame_ins_chk));
        strcpy(cover_vs_prem[max_cover_prem].frate     , trim(frate_chk));

        cover_vs_prem[max_cover_prem].mcoverage1    = mcoverage1_chk;
        cover_vs_prem[max_cover_prem].mcoverage2    = mcoverage2_chk;
        cover_vs_prem[max_cover_prem].mdeduct       = mdeduct_chk;
        cover_vs_prem[max_cover_prem].mpremium      = mpremium_chk;
        cover_vs_prem[max_cover_prem].pextra_charge = pextra_charge_chk;
        cover_vs_prem[max_cover_prem].msi_coverage  = msi_coverage_chk;
        cover_vs_prem[max_cover_prem].msi_premium   = msi_premium_chk;
        cover_vs_prem[max_cover_prem].drate         = drate_chk;

        max_cover_prem ++;
    }
    $CLOSE  cur_A;
    $FREE   cur_A;
    #ifdef PRINTF_FLAG
    printf("end insert into cover_vs_prem_t:num[%ld] \n",max_cover_prem);

    printf("begin insert into ca_rate_t \n");
    #endif
    max_ca_rate = (max_ca_rate==NULL) ? 0 : max_ca_rate ;
    /*max_ca_rate = 0;*/

    sprintf_s(stmt_buf,sizeof stmt_buf,"SELECT DISTINCT %s %s FROM %s %s WHERE %s %s %s %s ",
                     " a.icar_type, a.iins_type, a.mdeduct, a.qpt_bgn, a.qpt_end, a.fpt, ",
                     " a.prate, a.mprem, a.pextra_charge/100, a.ical_ins, a.fcal_class, a.drate, b.icode ",
                     " ca_rate a ,",
                     " ca_rate_date b ",
                     " a.drate = b.drate ",
                     " AND b.itable = 'ca_rate'",
                     " AND b.icode = ? ",
                     " ORDER BY a.drate desc ,a.icar_type,a.iins_type ");

    $PREPARE CUR_TMP  FROM $stmt_buf;
    #ifdef PRINTF_FLAG
    printf("stmt_buf[%s]\n",stmt_buf);
    #endif
    $DECLARE cur_B CURSOR FOR CUR_TMP;
    $OPEN    cur_B USING $tmp_frate2;
    for(;;)
    {
        $FETCH cur_B INTO $icar_type_chk, $iins_type_chk, $mdeduct_chk, $qpt_bgn_chk, $qpt_end_chk, $fpt_chk,
                          $prate_chk, $mprem_chk, $pextra_charge_chk, $ical_ins_chk, $fcal_class_chk, $drate_chk, $frate_chk;

        if (SQLCODE == SQLNOTFOUND)
            break;
        /* the following block is modified by paili */
        ca_rate=(struct ca_rate_t *) realloc (ca_rate,(max_ca_rate+1) * sizeof(struct ca_rate_t));

        strcpy(ca_rate[max_ca_rate].icar_type , trim(icar_type_chk));
        strcpy(ca_rate[max_ca_rate].iins_type , trim(iins_type_chk));
        strcpy(ca_rate[max_ca_rate].fpt       , trim(fpt_chk));
        strcpy(ca_rate[max_ca_rate].ical_ins  , trim(ical_ins_chk));
        strcpy(ca_rate[max_ca_rate].fcal_class, trim(fcal_class_chk));
        strcpy(ca_rate[max_ca_rate].frate     , trim(frate_chk));

        ca_rate[max_ca_rate].mdeduct       = mdeduct_chk;
        ca_rate[max_ca_rate].qpt_bgn       = qpt_bgn_chk;
        ca_rate[max_ca_rate].qpt_end       = qpt_end_chk;
        ca_rate[max_ca_rate].prate         = prate_chk;
        ca_rate[max_ca_rate].mprem         = mprem_chk;
        ca_rate[max_ca_rate].pextra_charge = pextra_charge_chk;
        ca_rate[max_ca_rate].drate         = drate_chk;

        max_ca_rate ++;
    }
    $CLOSE  cur_B;
    $FREE   cur_B;
    #ifdef PRINTF_FLAG
    printf("end insert into ca_rate_t:num[%ld] \n",max_ca_rate);

    printf("begin insert into comp_prem_t \n");
    #endif

    max_comp_prem = (max_comp_prem==NULL) ? 0 : max_comp_prem ;
    /*max_comp_prem = 0;*/
    /* 971216, �]��22����, add fassured*/
    sprintf_s(stmt_buf,sizeof stmt_buf,"SELECT DISTINCT %s %s %s FROM %s %s WHERE %s %s %s %s ",
                     " a.icar_type,a.qperiod,a.qcar_personbgn,a.qcar_personend,a.mcoverage1,a.mcoverage2,a.mcoverage3,",
                     " a.mpremium,a.mbusiness,a.mresearch,a.maintain,",
                     " a.pready_rate,a.pcomprate,a.pstablerate,a.pinvestrate,a.pinterest,a.pcapital,a.drate,b.icode,a.fassured,a.mdrunk_prem,a.mviolate_prem ",
                     " compulsory_premium a ,",
                     " ca_rate_date b ",
                     " a.drate = b.drate ",
                     " AND b.itable = 'compulsory_premium'",
                     " AND b.icode = ? ",
                     " ORDER BY a.drate desc, a.icar_type");

    $PREPARE CUR_TMP  FROM $stmt_buf;
    #ifdef PRINTF_FLAG
    printf("stmt_buf[%s]\n",stmt_buf);
    #endif
    $DECLARE cur_C CURSOR FOR CUR_TMP;
    $OPEN    cur_C USING $tmp_frate1;
    for(;;)
    {

        $FETCH cur_C INTO $icar_type_comp,$qperiod_comp,$qcar_personbgn_comp,$qcar_personend_comp,$mcoverage1_comp,$mcoverage2_comp,$mcoverage3_comp,
                          $mpremium_comp,$mbusiness_comp,$mresearch_comp,$maintain_comp,
                          $pready_rate_comp,$pcomprate_comp,$pstablerate_comp,$pinvestrate_comp,$pinterest_comp,$pcapital_comp,$drate_comp,$frate_comp,
                          $fassured_comp_t,$mdrunk_prem,$mviolate_prem;
        if (SQLCODE == SQLNOTFOUND)
            break;
        /* the following block is modified by paili */
        comp_prem=(struct comp_prem_t *) realloc (comp_prem,(max_comp_prem+1) * sizeof(struct comp_prem_t));

        if (fassured_comp[0]=='\0'){
        	fassured_comp[0] = ' '  ;
        	fassured_comp[1] = '\0' ;
        }
        strcpy(comp_prem[max_comp_prem].icar_type , trim(icar_type_comp));
        strcpy(comp_prem[max_comp_prem].frate     , trim(frate_comp));
        strcpy(comp_prem[max_comp_prem].fassured  , fassured_comp_t);

        comp_prem[max_comp_prem].qperiod         = qperiod_comp;
        comp_prem[max_comp_prem].qcar_personbgn  = qcar_personbgn_comp;
        comp_prem[max_comp_prem].qcar_personend  = qcar_personend_comp;
        comp_prem[max_comp_prem].mcoverage1      = mcoverage1_comp;
        comp_prem[max_comp_prem].mcoverage2      = mcoverage2_comp;
        comp_prem[max_comp_prem].mcoverage3      = mcoverage3_comp;
        comp_prem[max_comp_prem].mpremium        = mpremium_comp;
        comp_prem[max_comp_prem].mbusiness       = mbusiness_comp;
        comp_prem[max_comp_prem].mresearch       = mresearch_comp;
        comp_prem[max_comp_prem].maintain        = maintain_comp;
        comp_prem[max_comp_prem].drate           = drate_comp;
        comp_prem[max_comp_prem].pready_rate     = pready_rate_comp;
        comp_prem[max_comp_prem].pcomprate       = pcomprate_comp;
        comp_prem[max_comp_prem].pstablerate     = pstablerate_comp;
        comp_prem[max_comp_prem].pinvestrate     = pinvestrate_comp;
        comp_prem[max_comp_prem].pinterest       = pinterest_comp;
        comp_prem[max_comp_prem].pcapital        = pcapital_comp;
        comp_prem[max_comp_prem].mdrunk_prem     = mdrunk_prem;  /* 103.02.05 �s�r�[�O/�� */
        comp_prem[max_comp_prem].mviolate_prem   = mviolate_prem; /*���j�H�W�[�O�[�O(1110608012_SC3)*/

        max_comp_prem ++;
    }
    $CLOSE  cur_C;
    $FREE   cur_C;
    #ifdef PRINTF_FLAG
    printf("end insert into comp_prem_t:num[%ld] \n",max_comp_prem);

    printf("begin insert into car_model_factor_t \n");
    #endif

    max_car_model_factor = (max_car_model_factor==NULL) ? 0 : max_car_model_factor ;
    /*max_car_model_factor = 0;*/

    sprintf_s(stmt_buf,sizeof stmt_buf,"SELECT DISTINCT %s FROM %s %s WHERE %s %s %s %s ",
                     " a.fdmg_brg, a.irate, a.ipro_year, a.pfactor, a.drate, b.icode ",
                     " car_model_factor a ,",
                     " ca_rate_date b ",
                     " a.drate = b.drate ",
                     " AND b.itable = 'car_model_factor'",
                     " AND b.icode = ? ",
                     " ORDER BY a.drate desc ,a.fdmg_brg, a.ipro_year desc, a.irate ");

    $PREPARE CUR_TMP  FROM $stmt_buf;
    #ifdef PRINTF_FLAG
    printf("stmt_buf[%s]\n",stmt_buf);
    #endif
    $DECLARE cur_E CURSOR FOR CUR_TMP;
    $OPEN    cur_E USING $tmp_frate2;
    for(;;)
    {
        $FETCH cur_E INTO $fdmg_brg_fac, $irate_fac, $ipro_year_fac, $pfactor_fac, $drate_fac, $frate_fac;

        if (SQLCODE == SQLNOTFOUND)
            break;

        car_model_factor=(struct car_model_factor_t *) realloc (car_model_factor,(max_car_model_factor+1) * sizeof(struct car_model_factor_t));

        strcpy(car_model_factor[max_car_model_factor].fdmg_brg  , trim(fdmg_brg_fac));
        strcpy(car_model_factor[max_car_model_factor].irate     , trim(irate_fac));
        strcpy(car_model_factor[max_car_model_factor].ipro_year , trim(ipro_year_fac));
        strcpy(car_model_factor[max_car_model_factor].frate     , trim(frate_fac));

        car_model_factor[max_car_model_factor].pfactor = pfactor_fac;
        car_model_factor[max_car_model_factor].drate   = drate_fac;

        max_car_model_factor ++;
    }
    $CLOSE  cur_E;
    $FREE   cur_E;
    #ifdef PRINTF_FLAG
    printf("end insert into car_model_factor_t:num[%ld] \n",max_car_model_factor);

    printf("begin insert into ca_sex_age_factor_t \n");
    #endif

    max_ca_sex_age_factor = (max_ca_sex_age_factor==NULL) ? 0 : max_ca_sex_age_factor ;

    /* 990601, �����I�~�֩ʧO�Y�ƨ�99/06/01�s�O�v�׽վ�A������G���G�i�ҡB�A�B�B������l���j�Ρi�����B��+����l���j
       ��ca_rate_date, �M�w �j���I�B���d�I(31,32)�B�����I�B36�I�B37�I�U�۪��O�v�ͮĤ�
       ��ca_sex_age_factor2 �O�[�\���d�I(31,32)(fcard_class='2')�Ψ����I(fcard_class='3'),�{�N�����I����X�ӡG

       ca_sex_age_factor1:  �j���I�O�v�]�w
       ca_sex_age_factor2:  ���d�I(31,32)�O�v�]�w
       ca_sex_age_factor3:  �����I(01,05,08,09,85,105...)�O�v�]�w
       ca_sex_age_factor36: 37�I�O�v�]�w
       ca_sex_age_factor37: 37�I�O�v�]�w
    */
    /* 980310, �O�v�ۥѤ�,���N�I�~�֩ʧO�Y�Ʃ�����d�Ψ��� [fcard_class in ('2','3')]�A
               �t�N�j��Υ��N�I���O�v�]�w(ca_rate_date)��}��ca_sex_age_factor1 �� ca_sex_age_factor2
               �]�����table���u���@��ca_sex_age_factor�^ */
     sprintf_s(stmt_buf,sizeof stmt_buf,"SELECT DISTINCT  a.fcard_class, a.qage_bgn, a.qage_end, a.fsex, a.pfactor, a.drate, b.icode \
                       FROM ca_sex_age_factor a , ca_rate_date b \
                       WHERE  a.drate = b.drate  \
                       AND a.fcard_class = '1' \
                        AND b.itable = 'ca_sex_age_factor1' \
                       AND b.icode = ? \
                       union \
                       SELECT DISTINCT  a.fcard_class, a.qage_bgn, a.qage_end, a.fsex, a.pfactor, a.drate, b.icode \
                       FROM ca_sex_age_factor a , ca_rate_date b \
                       WHERE  a.drate = b.drate  \
                       AND a.fcard_class = '2' \
                       AND b.itable = 'ca_sex_age_factor2' \
                       AND b.icode = ? \
                       union \
                       SELECT DISTINCT  a.fcard_class, a.qage_bgn, a.qage_end, a.fsex, a.pfactor, a.drate, b.icode \
                       FROM ca_sex_age_factor a , ca_rate_date b \
                       WHERE  a.drate = b.drate  \
                       AND a.fcard_class = '3' \
                       AND b.itable = 'ca_sex_age_factor3' \
                       AND b.icode = ? \
                       union \
                       SELECT DISTINCT  a.fcard_class, a.qage_bgn, a.qage_end, a.fsex, a.pfactor, a.drate, b.icode \
                       FROM ca_sex_age_factor a , ca_rate_date b \
                       WHERE  a.drate = b.drate  \
                       AND a.fcard_class = '36' \
                       AND b.itable = 'ca_sex_age_factor36' \
                       AND b.icode = ? \
                       union \
                       SELECT DISTINCT  a.fcard_class, a.qage_bgn, a.qage_end, a.fsex, a.pfactor, a.drate, b.icode \
                       FROM ca_sex_age_factor a , ca_rate_date b \
                       WHERE  a.drate = b.drate  \
                       AND a.fcard_class = '37' \
                       AND b.itable = 'ca_sex_age_factor37' \
                       AND b.icode = ? \
                       union \
                       SELECT DISTINCT  a.fcard_class, a.qage_bgn, a.qage_end, a.fsex, a.pfactor, a.drate, b.icode \
                       FROM ca_sex_age_factor a , ca_rate_date b \
                       WHERE  a.drate = b.drate  \
                       AND a.fcard_class = '77' \
                       AND b.itable = 'ca_sex_age_factor77' \
                       AND b.icode = ? \
                       union \
                       SELECT DISTINCT  a.fcard_class, a.qage_bgn, a.qage_end, a.fsex, a.pfactor, a.drate, b.icode \
                       FROM ca_sex_age_factor a , ca_rate_date b \
                       WHERE  a.drate = b.drate  \
                       AND a.fcard_class = '78' \
                       AND b.itable = 'ca_sex_age_factor78' \
                       AND b.icode = ? \
                       union \
                       SELECT DISTINCT  a.fcard_class, a.qage_bgn, a.qage_end, a.fsex, a.pfactor, a.drate, b.icode \
                       FROM ca_sex_age_factor a , ca_rate_date b \
                       WHERE  a.drate = b.drate  \
                       AND a.fcard_class not in ('1','2','3','36','37','77','78') \
                       AND b.itable = 'ca_sex_age_factor3' \
                       AND b.icode = ? \
                       ORDER BY a.drate desc ,1 ,4 ,2 ,3");
    $PREPARE CUR_TMP  FROM $stmt_buf;
    #ifdef PRINTF_FLAG
    printf("stmt_buf[%s]\n",stmt_buf);
    #endif
    $DECLARE cur_F CURSOR FOR CUR_TMP;
    $OPEN    cur_F USING $tmp_frate1, $tmp_frate2, $tmp_frate2, $tmp_frate2, $tmp_frate2,
                         $tmp_frate2, $tmp_frate2, $tmp_frate2;
    for(;;)
    {
        $FETCH cur_F INTO $fcard_class_sex ,$qage_bgn_sex ,$qage_end_sex,
                          $fsex_sex, $pfactor_sex, $drate_sex, $frate_sex;

        if (SQLCODE == SQLNOTFOUND)
            break;
        /* the following block is modified by paili */
        ca_sex_age_factor=(struct ca_sex_age_factor_t *) realloc (ca_sex_age_factor,(max_ca_sex_age_factor+1) * sizeof(struct ca_sex_age_factor_t));

        strcpy(ca_sex_age_factor[max_ca_sex_age_factor].fcard_class  , trim(fcard_class_sex));
        strcpy(ca_sex_age_factor[max_ca_sex_age_factor].fsex         , trim(fsex_sex));
        strcpy(ca_sex_age_factor[max_ca_sex_age_factor].frate        , trim(frate_sex));

        ca_sex_age_factor[max_ca_sex_age_factor].qage_bgn = qage_bgn_sex;
        ca_sex_age_factor[max_ca_sex_age_factor].qage_end = qage_end_sex;
        ca_sex_age_factor[max_ca_sex_age_factor].pfactor = pfactor_sex;
        ca_sex_age_factor[max_ca_sex_age_factor].drate   = drate_sex;

        max_ca_sex_age_factor ++;
    }
    $CLOSE  cur_F;
    $FREE   cur_F;
    #ifdef PRINTF_FLAG
    printf("end insert into ca_sex_age_factor_t:num[%ld] \n",max_ca_sex_age_factor);
    #endif

    max_ca_car_model = (max_ca_car_model==NULL) ? 0 : max_ca_car_model ;
    /*max_ca_car_model = 0;*/

    /*980407, ca_car_model struct �S���Ψ�*/
    ca_car_model = NULL;

/*
    sprintf_s(stmt_buf,sizeof stmt_buf,"SELECT DISTINCT %s %s %s %s %s FROM %s %s WHERE %s %s %s %s ",
                     " a.ibrand,a.nbrand_abbr,a.nbrand,a.nbrand_eng,",
                     " a.mcar_price,a.icar_type, a.qcylinder, a.qpassenger,",
                     " a.fpt,a.dalter, a.fuse_type,a.icar_series, a.ipro_year,",
                     " a.idmg_rate,a.ibrg_rate,",
                     " a.drate,b.icode ",
                     " ca_car_model a ,",
                     " ca_rate_date b ",
                     " a.drate = b.drate ",
                     " AND b.itable = 'ca_car_model'",
                     " AND b.icode = ? ",
                     " ORDER BY a.drate desc,a.icar_type,a.ibrand,a.ipro_year desc ");

    $PREPARE CUR_TMP  FROM $stmt_buf;

    #ifdef PRINTF_FLAG
    printf("stmt_buf[%s]\n",stmt_buf);
    #endif

    $DECLARE cur_G CURSOR FOR CUR_TMP;
    $OPEN    cur_G USING $tmp_frate2;
    for(;;)
    {
        $FETCH cur_G INTO $ibrand_mdl, $nbrand_abbr_mdl, $nbrand_mdl, $nbrand_eng_mdl,
                          $mcar_price_mdl, $icar_type_mdl, $qcylinder_mdl, $qpassenger_mdl,
                          $fpt_mdl, $dalter_mdl, $fuse_type_mdl, $icar_series_mdl, $ipro_year_mdl,
                          $idmg_rate_mdl, $ibrg_rate_mdl,
                          $drate_mdl, $frate_mdl;

        if (SQLCODE == SQLNOTFOUND)
            break;

        ca_car_model=(struct ca_car_model_t *) realloc (ca_car_model,(max_ca_car_model+1) * sizeof(struct ca_car_model_t));

        strcpy(ca_car_model[max_ca_car_model].ibrand       , trim(ibrand_mdl));
        strcpy(ca_car_model[max_ca_car_model].nbrand_abbr  , trim(nbrand_abbr_mdl));
        strcpy(ca_car_model[max_ca_car_model].nbrand       , trim(nbrand_mdl));
        strcpy(ca_car_model[max_ca_car_model].nbrand_eng   , trim(nbrand_eng_mdl));
        strcpy(ca_car_model[max_ca_car_model].icar_type    , trim(icar_type_mdl));
        strcpy(ca_car_model[max_ca_car_model].fpt          , trim(fpt_mdl));
        strcpy(ca_car_model[max_ca_car_model].fuse_type    , trim(fuse_type_mdl));
        strcpy(ca_car_model[max_ca_car_model].icar_series  , trim(icar_series_mdl));
        strcpy(ca_car_model[max_ca_car_model].ipro_year    , trim(ipro_year_mdl));
        strcpy(ca_car_model[max_ca_car_model].idmg_rate    , trim(idmg_rate_mdl));
        strcpy(ca_car_model[max_ca_car_model].ibrg_rate    , trim(ibrg_rate_mdl));
        strcpy(ca_car_model[max_ca_car_model].frate        , trim(frate_mdl));

        ca_car_model[max_ca_car_model].qcylinder  = qcylinder_mdl;
        ca_car_model[max_ca_car_model].qpassenger = qpassenger_mdl;
        ca_car_model[max_ca_car_model].dalter     = dalter_mdl;
        ca_car_model[max_ca_car_model].drate      = drate_mdl;
        ca_car_model[max_ca_car_model].mcar_price = mcar_price_mdl;

        max_ca_car_model ++;
    }
    $CLOSE  cur_G;
    $FREE   cur_G;
    #ifdef PRINTF_FLAG
    printf("end insert into max_ca_car_model:num[%ld] \n",max_ca_car_model);
    #endif
*/
    max_insurance_type = (max_insurance_type==NULL) ? 0 : max_insurance_type ;
    /*max_insurance_type = 0;*/

    sprintf_s(stmt_buf,sizeof stmt_buf,"SELECT %s %s %s %s FROM %s %s",
                     "iins_type, nins_type, nins_abbr, edomain1, edomain2,",
                     "qcoverage, fdeduct, isame_ins, imain_ins, fins_grp,",
                     "fprint, qserial, fcal_way, fprint1, iins_type_rule,",
                     "frule, iri_ins ",
                     "insurance_type WHERE iins_type = iins_ply ",
                     "ORDER BY iins_type ");

    $PREPARE CUR_TMP  FROM $stmt_buf;

    #ifdef PRINTF_FLAG
    printf("stmt_buf[%s]\n",stmt_buf);
    #endif

    $DECLARE cur_I CURSOR FOR CUR_TMP;
    $OPEN    cur_I;
    for(;;)
    {
        $FETCH cur_I INTO $iins_type_ins, $nins_type_ins, $nins_abbr_ins, $edomain1_ins, $edomain2_ins,
                          $qcoverage_ins, $fdeduct_ins, $isame_ins_ins, $imain_ins_ins, $fins_grp_ins,
                          $fprint_ins, $qserial_ins, $fcal_way_ins, $fprint1_ins, $iins_type_rule_ins,
                          $frule_ins, $iri_ins_ins;

        if (SQLCODE == SQLNOTFOUND)
            break;
        /* the following block is modified by paili */
        insurance_type=(struct insuracne_type_t *) realloc (insurance_type,(max_insurance_type+1) * sizeof(struct insurance_type_t));

        strcpy(insurance_type[max_insurance_type].iins_type        , trim(iins_type_ins));
        strcpy(insurance_type[max_insurance_type].nins_type        , trim(nins_type_ins));
        strcpy(insurance_type[max_insurance_type].nins_abbr        , trim(nins_abbr_ins));
        strcpy(insurance_type[max_insurance_type].edomain1         , trim(edomain1_ins));
        strcpy(insurance_type[max_insurance_type].edomain2         , trim(edomain2_ins));
        strcpy(insurance_type[max_insurance_type].fdeduct          , trim(fdeduct_ins));
        strcpy(insurance_type[max_insurance_type].isame_ins        , trim(isame_ins_ins));
        strcpy(insurance_type[max_insurance_type].imain_ins        , trim(imain_ins_ins));
        strcpy(insurance_type[max_insurance_type].fins_grp         , trim(fins_grp_ins));
        strcpy(insurance_type[max_insurance_type].fprint           , trim(fprint_ins));
        strcpy(insurance_type[max_insurance_type].fcal_way         , trim(fcal_way_ins));
        strcpy(insurance_type[max_insurance_type].fprint1          , trim(fprint1_ins));
        strcpy(insurance_type[max_insurance_type].iins_type_rule   , trim(iins_type_rule_ins));
        strcpy(insurance_type[max_insurance_type].frule            , trim(frule_ins));
        strcpy(insurance_type[max_insurance_type].iri_ins          , trim(iri_ins_ins));

        insurance_type[max_insurance_type].qcoverage  = qcoverage_ins;
        insurance_type[max_insurance_type].qserial    = qserial_ins;

        max_insurance_type ++;
    }
    $CLOSE  cur_I;
    $FREE   cur_I;

    max_ca_rate_renew = (max_ca_rate_renew==NULL) ? 0 : max_ca_rate_renew ;
    /*max_ca_rate_renew = 0;*/

    sprintf_s(stmt_buf,sizeof stmt_buf,"SELECT %s FROM %s WHERE %s %s ",
                     " icode,iym_bgn,iym_end,fcard_class,code_flag,deffect_bgn,deffect_end ",
                     "ca_rate_renew ",
                     " iym_bgn <= ? ",
                     " AND iym_end >= ? ");
    $PREPARE CUR_TMP  FROM $stmt_buf;
    #ifdef PRINTF_FLAG
    printf("stmt_buf[%s]\n",stmt_buf);
    #endif
    $DECLARE cur_J CURSOR FOR CUR_TMP;
    $OPEN    cur_J USING $tmp_iym_end, $tmp_iym_end;
    for(;;)
    {
        $FETCH cur_J INTO $renew_icode,$renew_iym_bgn,$renew_iym_end,$renew_fcard_class,$renew_code_flag,$renew_deffect_bgn,$renew_deffect_end;

        if (SQLCODE == SQLNOTFOUND)
            break;
        /* the following block is modified by paili */
        ca_rate_renew=(struct ca_rate_renew_t *) realloc (ca_rate_renew,(max_ca_rate_renew+1) * sizeof(struct ca_rate_renew_t));

        strcpy(ca_rate_renew[max_ca_rate_renew].icode        , trim(renew_icode));
        strcpy(ca_rate_renew[max_ca_rate_renew].fcard_class  , trim(renew_fcard_class));
        strcpy(ca_rate_renew[max_ca_rate_renew].code_flag    , trim(renew_code_flag));

        ca_rate_renew[max_ca_rate_renew].iym_bgn  = renew_iym_bgn;
        ca_rate_renew[max_ca_rate_renew].iym_end  = renew_iym_end;

        ca_rate_renew[max_ca_rate_renew].deffect_bgn  = renew_deffect_bgn;
        ca_rate_renew[max_ca_rate_renew].deffect_end  = renew_deffect_end;

        max_ca_rate_renew ++;
    }
    $CLOSE  cur_J;
    $FREE   cur_J;

    /* ��O�j���I�O�O��� add by sylvia 104.04.21 (1040312001_C1)--------------- */
    /* �j���I�����~���u�f���B�վ�Acar159���A�ϥ� mark by 061476 110.01.21 (1100118005_SC3) */
    /*cnt_comp = 0;
    $select count(*) into $cnt_comp from car_renew_comp ;
    cal_comp = (struct renew_comp *) calloc (cnt_comp,sizeof(struct renew_comp));

    sprintf_s(stmt_buf,sizeof stmt_buf, "select iroute_main, iofficer, iins_cat, iyear, mother_busi from car_renew_comp ");

    $PREPARE  prr_comp FROM $stmt_buf;
    $DECLARE  cur_comp CURSOR FOR prr_comp;
    $OPEN     cur_comp;
    max_renew_comp = 0;
    while(1)
    {
        $FETCH cur_comp INTO $comp_iroute_main, $comp_officer, $comp_iins_cat, $comp_iyear, $comp_busi ;
        if(SQLCODE == SQLNOTFOUND)  break;

        #ifdef PRINTF_FLAG
            printf("---comp_iroute_main=[%s] ---- \n",comp_iroute_main);
            printf("---comp_officer=[%s] ---- \n",comp_officer);
            printf("---comp_iins_cat=[%s] ---- \n",comp_iins_cat);
            printf("---comp_iyear=[%s] ---- \n",comp_iyear);
            printf("---comp_busi=[%d] ---- \n",comp_busi);
        #endif

        strcpy(cal_comp[max_renew_comp].iroute_main,  comp_iroute_main);
        strcpy(cal_comp[max_renew_comp].iofficer,     comp_officer);
        strcpy(cal_comp[max_renew_comp].iins_cat,     comp_iins_cat);
        strcpy(cal_comp[max_renew_comp].iyear,     comp_iyear);
        cal_comp[max_renew_comp].mother_busi = comp_busi;
        max_renew_comp++;
    }
    $CLOSE   cur_comp;
    $FREE   cur_comp;
    printf("== ��O�j���I�O�O���e%d�f��\n",max_renew_comp);*/


    /* 101.07.03,ca_comp_acc_factor �[ fcar_class ���A���Τ��즹struct  */
/*
    #ifdef PRINTF_FLAG
    printf("before ca_comp_acc_factor \n");
    #endif

    max_ca_comp_factor = (max_ca_comp_factor==NULL) ? 0 : max_ca_comp_factor ;

    sprintf_s(stmt_buf,sizeof stmt_buf,"SELECT %s FROM %s WHERE %s %s ",
                     " a.fcard_class, a.qclass, a.pcomp_factor, a.fcar_class ",
                     " ca_comp_acc_factor a , ca_rate_date b",
                     " b.icode = ?  AND a.drate = b.drate",
                     " AND itable = 'ca_comp_acc_factor' ");
    $PREPARE CUR_COMP  FROM $stmt_buf;

    #ifdef PRINTF_FLAG
    printf("stmt_buf[%s]\n",stmt_buf);
    #endif

    $DECLARE cur_J1 CURSOR FOR CUR_COMP;
    $OPEN    cur_J1 USING $tmp_frate2;
    for(;;)
    {
        $FETCH cur_J1 INTO $comp_fcard_class,$comp_qclass,$comp_factor,$fcar_class;

        if (SQLCODE == SQLNOTFOUND)
            break;

        ca_comp_acc_factor=(struct ca_comp_acc_factor_t *) realloc (ca_comp_acc_factor,(max_ca_comp_factor+1) * sizeof(struct ca_comp_acc_factor_t));

        strcpy(ca_comp_acc_factor[max_ca_comp_factor].fcard_class   , trim(comp_fcard_class));

        ca_comp_acc_factor[max_ca_comp_factor].qclass  = comp_qclass;
        ca_comp_acc_factor[max_ca_comp_factor].pcomp_factor  = comp_factor;
        strcpy(ca_comp_acc_factor[max_ca_comp_factor].fcar_class   , trim(fcar_class));
        max_ca_comp_factor ++;
    }
    $CLOSE  cur_J1;
    $FREE   cur_J1;

    #ifdef PRINTF_FLAG
    printf(" after ca_comp_acc_factor \n");
    #endif
*/
    return M_CM_OK;

errexit:
    printf(" Get_Data_For_Cal_ins_prem_302() error: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/*100.06.27,�q���N���ĤG���q */
long prepare_barcode_ioff(iplyyear,iplymonth)
int iplyyear,iplymonth;
{
	$char sSQL[1024]=" ";
	$char icode_no[11],officer_type[2],iofficer[21];
	$char s_iofficer[11];
	int i_officer_type;
	$char sWhere[31],s1[20];
     short  plymdy[3];
     long   plydate;
	 int    i,j;
	$int    chk_count = 0;
	char *p1,*p2,*ioff;
	char  ioff_item[3][1][5]={" "," "," "};

	$char fgen302file1[2],fgen302file2[2];

	$WHENEVER SQLERROR GOTO errexit;
	$CREATE TEMP TABLE tmp_barcode_officer
	(
	    icode_no       char(10)    NOT NULL,
	    iofficer       char(20)    NOT NULL,
	    fgen302file1   char(1)     NOT NULL,
	    fgen302file2   char(1)     NOT NULL
	)WITH NO LOG;
    $CREATE INDEX idx_barcode_off_0 ON tmp_barcode_officer(icode_no);
    $CREATE INDEX idx_barcode_off_1 ON tmp_barcode_officer(iofficer);

	/* ��O�~���(��=01)*/
    plymdy[2] = (short)iplyyear;
    plymdy[0] = (short)iplymonth;
    plymdy[1] = (short)(1);

    rmdyjul(plymdy,&plydate);

    sprintf_s(sSQL,sizeof sSQL,"SELECT a.icode_no, a.officer_type, a.iofficer, b.fgen302file1, b.fgen302file2 \
                    FROM sysdb:car302_barcode_officer a ,sysdb:car302_barcode_setup b \
                   WHERE a.icode_no = b.icode_no AND b.dbegin <= %ld AND b.dend >= %ld ",
                 plydate,plydate);
    $PREPARE PRE_STMT FROM $sSQL;
    $DECLARE CUR_Officer CURSOR for PRE_STMT;
    $OPEN CUR_Officer ;
    while (1)
    {
       $FETCH CUR_Officer INTO $icode_no,$officer_type,$iofficer,$fgen302file1,$fgen302file2;

       if (SQLCODE == SQLNOTFOUND) break;
       chk_count++;

       #ifdef PRINTF_FLAG
       printf("icode_no[%s]\n" , icode_no);
       printf("officer_type[%s]\n" , officer_type);
       printf("iofficer[%s]\n" , iofficer);
       #endif

       strcpy(s_iofficer,trim(iofficer));
       #ifdef PRINTF_FLAG
       printf("s_iofficer[%s]\n" , s_iofficer);
       #endif

        /* 1:�g��N��, 2: x�g���N��x �令=>�D�q���N�� ,3: �g��N��*(1) 4. �g��N��*(2) */
        i_officer_type = atoi(officer_type);
        switch (i_officer_type){
         	 case 1:
                sprintf_s(sSQL,sizeof sSQL, "INSERT INTO tmp_barcode_officer values('%s','%s','%s','%s')",
                             icode_no,s_iofficer,fgen302file1,fgen302file2);
         	 	break;

         	 case 2:  /* 101.10, ����(��)�ϥγq���N�� ,���A�ର�g�� */
                sprintf_s(sSQL,sizeof sSQL, "INSERT INTO tmp_barcode_officer \
                               SELECT '%s',iroute,'%s','%s' FROM sysdb:cm_route Where iroute like '%s%%' ",
                             icode_no,fgen302file1,fgen302file2,s_iofficer);
         	 	break;

         	 case 3:
                sprintf_s(sSQL,sizeof sSQL, "INSERT INTO tmp_barcode_officer \
                               SELECT '%s',iofficer,'%s','%s' FROM sysdb:officer Where iofficer matches '%s'",
                             icode_no,fgen302file1,fgen302file2,s_iofficer);
         	 	break;

         	 case 4:
				ioff = strtok(s_iofficer,"|") ;       /* ex. 1-R|7-D */
				strcpy(sWhere," ");
				i=0;
				while(ioff != NULL){                  /* => ioff = "1-R" */
				     strcpy(ioff_item[i][0] ,ioff);
					 i++;
		             ioff = strtok(NULL,"|");         /* ���o�U�@�� ioff => "7-D" */
				}

				for (j=0;j<3;j++){
					if (strncmp(ioff_item[j][0]," ",1)!=0){
						  p1 = strtok(ioff_item[j][0],"-") ;   /* p = 1 */
						  if (p1 != NULL){
						  	  p2 = strtok(NULL,"-");           /* ���o�U�@�� p = R */
						  }else{
						  	  break;
						  }
					      s1[0]='\0';
					      sprintf_s(s1,sizeof s1," iofficer[%d] = '%c'", atoi(p1), p2[0]);
					      if (j==0){
					      	strcat(sWhere, s1);
					      }else{
					      	strcat(sWhere, " AND ");
					      	strcat(sWhere, s1);
					      }
					}
				}
			    printf("sWhere[%s]\n" , sWhere);

                sprintf_s(sSQL,sizeof sSQL, "INSERT INTO tmp_barcode_officer \
                               SELECT '%s',iofficer,'%s','%s' FROM sysdb:officer WHERE %s",
                             icode_no,fgen302file1,fgen302file2, sWhere);
         	 	break;
         	default:
         		continue;
        }

        printf("Insert tmp_barcode_officer sSQL[%s]\n" , sSQL);
        $PREPARE pre_tmp FROM $sSQL;
        $EXECUTE pre_tmp;

    }
    $close CUR_Officer;
    $free  CUR_Officer;
    if (chk_count==0) return -1; /* ������O�~��L���Ĥ��]�w�ɻݮM�� */


    #ifdef PRINTF_FLAG
        i=0 ;
        sprintf_s(sSQL,sizeof sSQL, "SELECT icode_no,iofficer,fgen302file1,fgen302file2 FROM tmp_barcode_officer");
	    $PREPARE PRE_STMT FROM $sSQL;
	    $DECLARE CUR_tmp1 CURSOR for PRE_STMT;
	    $OPEN CUR_tmp1 ;
	    while (1)
	    {
	       $FETCH CUR_tmp1 INTO $icode_no, $iofficer,$fgen302file1,$fgen302file2;

	       if (SQLCODE != 0) break;
	       i++;
	       /* printf("[%d]: icode_no[%s] iofficer[%s]\n " ,i, icode_no,iofficer);
	       printf("[%d]: fgen302file1[%s] fgen302file2[%s]\n " ,i, fgen302file1,fgen302file2); */

        }
        $CLOSE CUR_tmp1;
        $FREE CUR_tmp1;
    #endif
    chk_count = 0;
    $SELECT count(*) INTO $chk_count FROM tmp_barcode_officer;

    #ifdef PRINTF_FLAG
    printf("SQLCODE[%d]\n" , SQLCODE);
    printf(" ------- chk_count = [%d]\n " , chk_count);
    #endif

    if (chk_count>0){
    	return M_CM_OK;
    }else{
    	return -1;
    }

errexit:
   printf("11948 sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   return SQLCODE;

}

void date_add(yy1,mm1,dd1,yy2,mm2,dd2,yy3,mm3,dd3)
int *yy1,*mm1,*dd1,*yy2,*mm2,*dd2,*yy3,*mm3,*dd3;
{
   int  leap_year; /* �|�~ */
   double  x1,x2,x3;
   long    lnum;
   int     i;
   /***  yy1/mm1/dd1 + yy2 + mm2 + dd2 = yy3/mm3/dd3 ***/
   printf("***date_add***(1)yy1[%d]mm1[%d]dd1[%d]\n",*yy1,*mm1,*dd1);
   *yy3=*yy1+*yy2;
   *mm3=*mm1+*mm2;
   *dd3=*dd1+*dd2;
   printf("***date_add***(2)yy3[%d]mm3[%d]dd3[%d]\n",*yy3,*mm3,*dd3);
 /*  if (*mm3 > 12) {
      *mm3 -= 12;
      *yy3 += 1;
   } */
   lnum =  *mm3 / 12;
   for (i=0;i<lnum;i++)
   {
      if (*mm3 > 12) {
          *mm3 -= 12;
          *yy3 += 1;
       }
    }

   /*** check leap year ***/
   x1 = fmod(*yy3+1911,4);
   x2 = fmod(*yy3+1911,100);
   x3 = fmod(*yy3+1911,400);

   /* 2008/3/5 fix*/
   if ((x1==0 && x2!=0)||x3==0)
   	   leap_year=1;
   else
   	   leap_year=0;
printf(" ------- x1 = [%f]\n " , x1);
printf(" ------- x2 = [%f]\n " , x2);
printf(" ------- x3 = [%f]\n " , x3);
printf(" ------- leap_year = [%d]\n " , leap_year);
/*
   if (x1==0)
      leap_year=1;
   if (x2==0)
      leap_year=0;
   if (x3==0)
      leap_year=1;
*/

   /*** check month ***/
   if (*mm3==1 || *mm3==3 || *mm3==5 || *mm3==7 || *mm3==8 ||
       *mm3==10 || *mm3==12) {
      if (*dd3 > 31) {
         *dd3 -= 31;
         *mm3 += 1;
         if (*mm3 > 12)
            *yy3 += 1;
      }
   }
   else {
        if (*mm3==2) {
           if (leap_year) {
              if (*dd3 > 29) {
                 *dd3 -= 29;
                 *mm3 += 1;
              }
           }
           else {
              if (*dd3 > 28) {
                 *dd3 -= 28;
                 *mm3 += 1;
              }
           }
        }
        else {
           if (*dd3 > 30) {
              *dd3 -= 30;
              *mm3 += 1;
           }
        }
   }
   printf("***date_add***(3)yy3[%d]mm3[%d]dd3[%d]\n",*yy3,*mm3,*dd3);
   return;
}


long MyDateAdd(lDate,nnext,spart )
long lDate;
int   nnext;
char spart;
{
   short  mdy[3];
   short  mdy3[3];
   int   imdy[3];
   int yyyy, mm, dd;
   long ndate;

   rjulmdy(lDate, mdy);

   imdy[2] = (int)mdy[2]-1911;
   imdy[0] = (int)mdy[0];
   imdy[1] = (int)mdy[1];

   printf("mdy_y[%ld]\n",mdy[2]);
   printf("mdy_m[%ld]\n",mdy[0]);
   printf("mdy_d[%ld]\n",mdy[1]);

   printf("nnext[%d]\n",nnext);
   printf("spart[%c]\n",spart);

   if (spart=='y'){
       date_add(&imdy[2],&imdy[0],&imdy[1],&nnext,0,0,&yyyy,&mm,&dd);
   }else if (spart=='m'){
       date_add(&imdy[2],&imdy[0],&imdy[1],0,&nnext,0,&yyyy,&mm,&dd);
   }else if (spart=='d'){
   	   date_add(&imdy[2],&imdy[0],&imdy[1],0,0,&nnext,&yyyy,&mm,&dd);
   }else{
   	   return -1;
   }

   printf("yyyy[%ld]",yyyy);
   printf("mm[%ld]",mm);
   printf("dd[%ld]",dd);

   mdy3[2] = (short)yyyy+1911;
   mdy3[0] = (short)mm;
   mdy3[1] = (short)dd;

   rmdyjul(mdy3,&ndate);
   return ndate;

}

/*980327, trim() �[�j��, �R���r���Y���H�Τ��������� ' ', '\f' , '\n' , '\r' ,'\t' , '\v' ���r��*/
 char* trimx (char *str)
{
      char *ibuf, *obuf;

      if (str)
      {
            for (ibuf = obuf = str; *ibuf; )
            {
                  while (*ibuf && (isspace (*ibuf)))
                        ibuf++;
                  if (*ibuf && (obuf != str))
                        *(obuf++) = ' ';
                  while (*ibuf && (!isspace (*ibuf)))
                        *(obuf++) = *(ibuf++);
            }
            *obuf = '\0';
      }
      return (str);
}

/* 990604, ��]�w��cus101,���O�GC5 */
/* 981130,�s�W Y*VK*( �M���O�g ) */
/* �T����j�B�i��ĳ50�����ؤ��@���A�אּbarcode�覡
   ���B�����~���g��,�Y����barcode �ĭ���O��覡 */
long no_barcode_list()
{

    $char icode[11],ncode[41];
    $char stmt[1024];

	$WHENEVER SQLERROR GOTO errexit;
	$CREATE TEMP TABLE tmp_no_barcode_list
	(
	    tmp_iofficer       char(10)    NOT NULL
	)WITH NO LOG;

    $DECLARE no_bc_cur CURSOR FOR
       SELECT icode,trim(ncode) FROM cu_code_data WHERE itype= 'C5';

    $OPEN no_bc_cur;
    while (1){
       $FETCH no_bc_cur INTO $icode,$ncode;

       if (SQLCODE != 0) break;
       if (ncode[0]=='M'){
       	   sprintf_s(stmt,sizeof stmt,"select iofficer from officer where iofficer matches '%s'",
       	           icode);

	       $PREPARE preTmp FROM $stmt;
	       $DECLARE curTmp2 CURSOR FOR preTmp;
	       $OPEN    curTmp2;
	       for(;;){
	       	  $FETCH curTmp2 INTO $icode;
	       	  if (SQLCODE==SQLNOTFOUND) break;
              $insert into tmp_no_barcode_list values($icode);
	       }
	       $CLOSE curTmp2;
	       $FREE curTmp2;
       }else if (ncode[0]=='X'){
       	   continue;
       }else{
       	   $insert into tmp_no_barcode_list values($icode);
       }
    }
    $CLOSE no_bc_cur;
    $FREE  no_bc_cur;

    $DELETE FROM tmp_no_barcode_list WHERE tmp_iofficer in (
      select icode from cu_code_data where itype='C5' and ncode[1]='X');

  	return M_CM_OK;

errexit:
   printf("12160 sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   return SQLCODE;

}

/* 991019,�]�w��cus101,���O�GC7 */
/* ���B�M�欰�@�߶��L��O�q���� */
/* �M��]�t���B�g�쵥 */
/* icode[1] = 1 => ��� ;  icode[1] = 2 => �g�� */

/*
itype	icode		ncode		tcode_remark
char(2)	char(10)	char(40)	char(20)
---------------------------------------------------
C7		100			67*
C7		101			6603*
C7		102			6102*
C7		103			6402*
C7		104			6462*
C7		201			Y62049FJ
*/

long Force_Print_302_list()
{

    $char c_code,ncode[41],tcode_remark[21],tmp_ncode[41];
    $char stmt[1024];
    $int  intProjYear;

	$WHENEVER SQLERROR GOTO errexit;
	$CREATE TEMP TABLE tmp_force_print_302
	(
	    tmp_type       integer     NOT NULL,  /*  1 => ��� ;  2 => �g�� */
	    tmp_value      char(41)    NOT NULL
	) WITH NO LOG;

    $DECLARE force_cur CURSOR FOR
       SELECT icode[1],trim(ncode),trim(tcode_remark) FROM cu_code_data WHERE itype= 'C7';

    $OPEN force_cur;
    while (1){
       $FETCH force_cur INTO $c_code,$ncode,$tcode_remark;

       if (SQLCODE != 0) break;
       if (tcode_remark[0]!='X'){
       	   if (c_code=='1'){
	       	   sprintf_s(stmt,sizeof stmt,"SELECT ibranch FROM sa_branch_type WHERE ibranch matches '%s'", ncode);
		       $PREPARE preTmp FROM $stmt;
		       $DECLARE curTmp3 CURSOR FOR preTmp;
		       $OPEN    curTmp3;
		       for(;;){
		       	   $FETCH curTmp3 INTO $tmp_ncode;
		       	   if (SQLCODE==SQLNOTFOUND) break;
	               $insert into tmp_force_print_302 values($c_code,$tmp_ncode);
		       }
		       $CLOSE curTmp3;
		       $FREE curTmp3;

       	   }else if (c_code=='2'){
	       	   sprintf_s(stmt,sizeof stmt,"select iofficer from officer where iofficer matches '%s'", ncode);
		       $PREPARE preTmp FROM $stmt;
		       $DECLARE curTmp4 CURSOR FOR preTmp;
		       $OPEN    curTmp4;
		       for(;;){
		       	   $FETCH curTmp4 INTO $tmp_ncode;
		       	   if (SQLCODE==SQLNOTFOUND) break;
	               $insert into tmp_force_print_302 values($c_code,$tmp_ncode);
		       }

		       $CLOSE curTmp4;
		       $FREE curTmp4;
	       }
       }else{
       	   continue;
       }
    }
    $CLOSE force_cur;
    $FREE  force_cur;

    $DELETE FROM tmp_force_print_302 WHERE tmp_value in (
      select ncode from cu_code_data where itype='C7' and tcode_remark[1]='X' and icode[1]= tmp_force_print_302.tmp_type);

  	return M_CM_OK;


errexit:
   printf("12246 sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   return SQLCODE;

}

/* 980825, ��O�J�p�e�A�M�� working table */
long clear_ply_last()
{
	$WHENEVER SQLERROR GOTO errexit;

	$database sysdb;
	$truncate table ca_pa_ply_last;
	$truncate table ply_ins_cover_last;
	$truncate table ply_ins_type_last;
	$truncate table ply_relation_last;
	$truncate table policy_last;

	$BEGIN WORK;
	printf("Trace --  BEGIN WORK  \n" );
	$LOCK TABLE ca_pa_ply_last IN SHARE MODE ;
	$LOCK TABLE ply_ins_cover_last IN SHARE MODE ;
	$LOCK TABLE ply_ins_type_last IN SHARE MODE ;
	$LOCK TABLE ply_relation_last IN SHARE MODE ;
	$LOCK TABLE policy_last IN SHARE MODE ;
	$COMMIT WORK;

	$database newa00;

	printf("Trace -- clear_ply_last()-- end \n");
  	return M_CM_OK;

errexit:
   printf("12726 sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   $ROLLBACK WORK;
   return SQLCODE;

}

long clear_ply_last_bak()
{
	$WHENEVER SQLERROR GOTO errexit;

	printf("Trace -- clear_ply_last()-- begin \n");
	$BEGIN WORK;
	printf("Trace --  BEGIN WORK  \n" );
	$LOCK TABLE ca_pa_ply_last IN SHARE MODE ;
	$LOCK TABLE ply_ins_cover_last IN SHARE MODE ;
	$LOCK TABLE ply_ins_type_last IN SHARE MODE ;
	$LOCK TABLE ply_relation_last IN SHARE MODE ;
	$LOCK TABLE policy_last IN SHARE MODE ;

	$DELETE FROM ca_pa_ply_last WHERE 1=1;
	$DELETE FROM ply_ins_cover_last WHERE 1=1;
	$DELETE FROM ply_ins_type_last WHERE 1=1;
	$DELETE FROM ply_relation_last WHERE 1=1;
	$DELETE FROM policy_last WHERE 1=1;

	$COMMIT WORK;
	printf("Trace --  COMMIT WORK  \n" );

/*	�S�� UPDATE STATISTICS �v��
	$UPDATE STATISTICS FOR TABLE ply_ins_cover_last;
	printf("UPDATE STATISTICS 1  \n" );
	$UPDATE STATISTICS FOR TABLE ply_ins_type_last;
	printf("UPDATE STATISTICS 2  \n" );
	$UPDATE STATISTICS FOR TABLE ca_pa_ply_last;
	printf("UPDATE STATISTICS 3  \n" );
	$UPDATE STATISTICS FOR TABLE ply_relation_last;
	printf("UPDATE STATISTICS 4  \n" );
	$UPDATE STATISTICS FOR TABLE policy_last;
	printf("UPDATE STATISTICS 5  \n" );
*/
	printf("Trace -- clear_ply_last()-- end \n");
  	return M_CM_OK;
errexit:
   printf("12770 sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   $ROLLBACK WORK;
   printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   return SQLCODE;

}

/* 980825, �̫��w�~�]�褸�^�B��A�M����O��� */
long clear_ply_302(iYear,iMonth,iOption )
$int  iYear,iMonth;
$int  iOption;
{
    $char stmt[1024],tmp_stmt[256], str[30], tp_ipolicy[21];
    $char nowdate[21];
    $date today_date,clr_date;
    $short tmp_mdy[3];
    int itmp,ii;
    $int chkCount;
    $char sdate1[11], sdate2[11];


		str[0] = ' '; str[1] = '\0';

		/* �� option ����R���Y���w�~���� */
		switch (iOption){
			case  -1:  /* ����J�p�@�~�ɡA�M����O�~�뤧���Ӥ�e���; */
			    break;
			case 302:  /* �M���Y���w�~��Ҧ���� */
			    break;
			case 3021:
				strcpy(str, " AND option in ('1','9')" );  /* �R���Ӥ�Boption in ('1','9')���*/
			    break;
			case 3022:
				strcpy(str, " AND option in ('1')" );
			    break;
			case 3023:
				strcpy(str, " AND option in ('4','9')" );
			    break;
			case 3024:
				strcpy(str, " AND option in ('4')" );
			    break;
	    }

		printf("Trace -- clear_ply_302()-- begin \n");
		printf("Trace -- iYear [%d]  \n",  iYear);
		printf("Trace -- iMonth [%d] \n",  iMonth);
		printf("Trace -- iOption [%d] \n", iOption);

		$WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

		/* check ���L���  */
		chkCount = 0;
    strcpy(tp_ipolicy," ");
    $select MDY($iMonth,'01',$iYear),LAST_DAY(MDY($iMonth,'01',$iYear))
       into $sdate1, $sdate2 from systables where tabid = 1;

		sprintf_s(stmt,sizeof stmt,
	        " SELECT first 1 ipolicy FROM policy_302 WHERE dply_begin between '%s' and '%s'  %s" ,
	          sdate1, sdate2, str );
		printf("Trace -- stmt = [%s] \n",  stmt);

		$PREPARE chk_ply302 FROM $stmt;
		$EXECUTE chk_ply302 Into $tp_ipolicy;

		if (SQLCODE == SQLNOTFOUND) return M_CM_OK;

		/** 980825, ���קK�~�R��G�Ӥ몺��O�ɡA�[�ˮ� **/
    /* �@�뱡�p�����\�R����G�Ӥ뤧��O���, ���D��T�H����e�ݤU����(���� iOption <> -1 ) */
    if (iOption == -1){
		    tmp_mdy[2] = iYear ;  tmp_mdy[0] = iMonth ;  tmp_mdy[1] = 1 ;
		    rtoday(&today_date);
		    rmdyjul(tmp_mdy,&clr_date);
		    printf("Trace -- TEST = [%s] \n",  cm_edate_str(clr_date));
		    printf("Trace -- TEST = [%s] \n",  cm_edate_str(today_date));
		    itmp = DiffMonth(today_date, clr_date);
		    printf("Trace -- itmp = [%d] \n",  itmp);

		    if (itmp <= 2){
		        printf("�u�i�R����������2�Ӥ�e����O���\n");
		        return -2;
				}
		}

		$BEGIN WORK;

		$LOCK TABLE ply_ins_cover_302 IN SHARE MODE ;
		$LOCK TABLE ply_ins_type_302  IN SHARE MODE ;
		$LOCK TABLE ca_pa_ply_302     IN SHARE MODE ;
		$LOCK TABLE policy_302        IN SHARE MODE ;
		$LOCK TABLE sysdb:car_renew_msg  IN SHARE MODE ;
		$LOCK TABLE policy_302f       IN SHARE MODE ; /* add by sylvia 105.01.18 (1041001006_C1) */
		$LOCK TABLE ply_ins_assured_302     IN SHARE MODE ; /* add by sylvia 114.04.22 (1140409004_C01) */

		sprintf_s(stmt,sizeof stmt,
	        " SELECT ipolicy FROM policy_302 WHERE dply_begin between '%s' and '%s'  %s into temp tb_delete with no log;" ,
	          sdate1, sdate2, str );
		printf("Trace -- stmt = [%s] \n",  stmt);

		$PREPARE chk_del FROM $stmt;
		$EXECUTE chk_del ;

    /* DELETE ply_ins_cover_302 */
		/* sprintf_s( stmt,sizeof stmt, "DELETE FROM ply_ins_cover_302 WHERE ipolicy IN ( SELECT ipolicy %s )", tmp_stmt); */
		sprintf_s( stmt,sizeof stmt, "DELETE FROM ply_ins_cover_302 WHERE exists ( SELECT ipolicy from tb_delete where tb_delete.ipolicy = ply_ins_cover_302.ipolicy )");

		$PREPARE del_ply FROM $stmt;
		$EXECUTE del_ply;

    /* DELETE ply_ins_type_302 */
		/* sprintf_s( stmt,sizeof stmt, "DELETE FROM ply_ins_type_302 WHERE ipolicy IN ( SELECT ipolicy %s )", tmp_stmt); */

		sprintf_s( stmt,sizeof stmt, "DELETE FROM ply_ins_type_302 WHERE exists ( SELECT ipolicy from tb_delete where tb_delete.ipolicy = ply_ins_type_302.ipolicy )");

		$PREPARE del_ply FROM $stmt;
		$EXECUTE del_ply;

    /* DELETE ca_pa_ply_302 */
		/* sprintf_s( stmt,sizeof stmt, "DELETE FROM ca_pa_ply_302 WHERE ipolicy IN ( SELECT ipolicy %s )", tmp_stmt); */

		sprintf_s( stmt,sizeof stmt, "DELETE FROM ca_pa_ply_302 WHERE exists ( SELECT ipolicy from tb_delete where tb_delete.ipolicy = ca_pa_ply_302.ipolicy )");

		$PREPARE del_ply FROM $stmt;
		$EXECUTE del_ply;

		/* DELETE ply_ins_assured_302 */
		sprintf_s( stmt,sizeof stmt, "DELETE FROM ply_ins_assured_302 WHERE exists ( SELECT ipolicy from tb_delete where tb_delete.ipolicy = ply_ins_assured_302.ipolicy )");

		$PREPARE del_ply FROM $stmt;
		$EXECUTE del_ply;

		/* �R����O���D��T��(car_renew_msg)  add by sylvia 104.07.08 (1040106005_C1) */
    /* �R��ƫe���� : mail���޲z�̪����� */
    iCnt_Before = 0;
    $select count(*) into $iCnt_Before
       FROM sysdb:car_renew_msg a join car_code b on a.err_no = b.detail2
      WHERE a.dply_end between $sdate1 and $sdate2
        and b.kind = 'RN' and b.detail = 'Mail_To_Leader'
        and engname = 'Y';

    /* �R��ƫᵧ�� : ���׬O�_�nmail���޲z�H�����~���� */
		sprintf_s( stmt,sizeof stmt, "DELETE FROM sysdb:car_renew_msg WHERE dply_end between '%s' and '%s' ",
	                sdate1, sdate2);
		$PREPARE del_ply FROM $stmt;
		$EXECUTE del_ply;

    /* �R��ƫᵧ�� */
		$select count(*) into $iCnt_After
	  	 FROM sysdb:car_renew_msg
	 	  WHERE dply_end between $sdate1 and $sdate2;

		$COMMIT WORK;

		/* �אּ�C1000��commit �@��:policy_302 */
		ii = 0;
		sprintf_s(tmp_stmt,sizeof tmp_stmt,
		        " FROM policy_302 WHERE ipolicy in (select ipolicy from tb_delete) ");

		sprintf_s(stmt,sizeof stmt,"select ipolicy %s for update",tmp_stmt);
		$prepare d_pre from $stmt;

		$begin work;
		$declare d_cur cursor with hold for d_pre;
		$open  d_cur ;
	  while (1)
    {
        $FETCH d_cur;
        if (SQLCODE == SQLNOTFOUND) break;
        ii++;

        $delete from policy_302 where current of d_cur;

        if (ii > 1000)
        {
            $commit work;
            $begin  work;
            ii = 0;
        }
    }
    $close d_cur;
    $free  d_cur;
    $commit work;


    /* �אּ�C1000��commit �@��:policy_302f */
		ii = 0;
		sprintf_s(tmp_stmt,sizeof tmp_stmt,
	        " FROM policy_302f WHERE dply_begin between '%s' and '%s'  %s", sdate1, sdate2, str );
		sprintf_s(stmt,sizeof stmt,"select ipolicy %s for update",tmp_stmt);
		$prepare d_pref from $stmt;

		$begin work;
		$declare d_curf cursor with hold for d_pref;
		$open  d_curf ;
    while (1)
    {
        $FETCH d_curf;
        if (SQLCODE == SQLNOTFOUND) break;
        ii++;

        $delete from policy_302f where current of d_curf;

        if (ii > 1000)
        {
            $commit work;
            $begin  work;
            ii = 0;
        }
    }
    $close d_curf;
    $free  d_curf;
    $commit work;


    /* sprintf_s( stmt,sizeof stmt, "DELETE FROM sysdb:policy_302f WHERE dply_begin between '%s' and '%s' ",
	                sdate1, sdate2);
		$PREPARE del_ply FROM $stmt;
		$EXECUTE del_ply; */

		/*
		  (�L�v�� $UPDATE STATISTICS)
			$UPDATE STATISTICS FOR TABLE ply_ins_cover_302;
			$UPDATE STATISTICS FOR TABLE ply_ins_type_302;
			$UPDATE STATISTICS FOR TABLE ca_pa_ply_302;
			$UPDATE STATISTICS FOR TABLE policy_302;
		*/
		printf("Trace -- clear_ply_302()-- end \n");
  	return M_CM_OK;

errexit:
   printf("12418: sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   $WHENEVER SQLERROR CONTINUE;     /* reset error handling */
   $ROLLBACK WORK;
   printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   return SQLCODE;

}


/*  1. ����car302a,car302b �ˮֱ�����浲�G�A�q�L�ɨ�Ȭ�1 ,�_�h��0 �C
    2. ����O�@�~"�����J�p"�]�����J�p�h���ˬd�^�e�i���ˬd�A�ȥ�����
       ��1��i�i��J�p�A�ӥ�������ץ����ˮֵ��G�L�~�ɡA��Ȥ�|��1�C
    3. ���J�p����(���צ��\�Υ���)�ɡA�A�N�ˬd�ȧאּ 0,����U���J�p�e
       �A�װ���car302a, car302b��A�Y�ҳq�L�ˮ֤�|��אּ1�C
    4. sOption : �U�ˮֵ{�����l���O�A�ثe�u���@�ӡA�q���@���ϡ�

*/
long ply_302_key(iType,sProg,sOption,sResult,sUserid)
$char  sOption[2],sProg[8],sResult[2],sUserid[11];
$int   iType;
{
	$char stmt[1024];
	$int  rtValue;

	$WHENEVER SQLERROR GOTO errexit;
	rtValue = -1 ;
    switch (iType){
     	case 1: /* ��s�ˮֵ��G��*/
     	    if ((strcmp(sProg,"car302a") == 0)  && (strcmp(sOption,"D") == 0) )
     	    {
     	        sprintf_s(stmt,sizeof stmt,
    			        "UPDATE car_code Set engname = 'car302', chiname = '%s', iupdate='%s', dupdate = current \
    			        WHERE kind = 'RN' AND detail = '%s' AND detail2 = '%s'",
    			        sResult, sUserid, sProg , sOption);
     	    }
     	    else
     	    {
    			sprintf_s(stmt,sizeof stmt,
    			        "UPDATE car_code Set chiname = '%s', iupdate='%s', dupdate = current \
    			        WHERE kind = 'RN' AND detail = '%s' AND detail2 = '%s'",
    			        sResult, sUserid, sProg , sOption);
			}
			rtValue = 1;
	        $PREPARE pre_key FROM $stmt;
	        $EXECUTE pre_key;
	        return rtValue;
     	    break;

     	case 2:  /* ���o�U�ˮֵ{�����G�Ȥ��M */
     		     /* => �^�ǬO���@���ˮֵ{�����q�L */
			sprintf_s(stmt,sizeof stmt,
			        "SELECT sum(chiname::integer) FROM car_code \
			        WHERE kind = 'RN' AND detail = '%s' AND detail2 = '%s'",
			        sProg, sOption );
	        $PREPARE pre_key FROM $stmt;
	        $EXECUTE pre_key INTO $rtValue;
	        if (rtValue==0){ /* car302a ���q�L�ˮ� */
	        	return (65+32) ;  /* chr(65+32) = "a" */
	        }

			sprintf_s(stmt,sizeof stmt,
			        "SELECT sum(chiname::integer) FROM car_code \
			        WHERE kind = 'RN' AND detail = '%s' AND detail2 = '%s'",
			         sProg, sOption );
	        $PREPARE pre_key FROM $stmt;
	        $EXECUTE pre_key INTO $rtValue;
	        if (rtValue==0){ /* car302b���q�L�ˮ� */
	        	return (66+32) ;  /* chr(66+32) = "b" */
	        }
	        return 1;
     	    break;
    }


errexit:
   printf("12493 sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}


long GetPlyFromEngine(sDBName,lPlyEnd_Bgn,lPlyEnd_End,sTable)
$char sDBName[5];
$char sTable[51];
$long lPlyEnd_Bgn, lPlyEnd_End;
{
    int     count_db1;

    $char   stmt[2048],sTmp[21],stmt2[512],stmt3[512];
    $char   xBranch[3];
    $WHENEVER SQLERROR GOTO errexit;

    printf("GetPlyFromEngine() \n");
    $CREATE TEMP TABLE tmp_data(
       ipolicy   char(20)
    )  WITH NO LOG;

    strcpy(sTable, trim(sTable));
    sprintf_s(stmt2,sizeof stmt2, "INSERT INTO tmp_data Values (?)");
    $PREPARE preIns FROM $stmt2;

    sprintf_s(stmt3,sizeof stmt3, "INSERT INTO %s SELECT ipolicy FROM tmp_data ",sTable);
    $PREPARE preIns2 FROM $stmt3;

    sprintf_s(stmt2,sizeof stmt2, "DELETE FROM %s WHERE 1=1",sTable);
    $PREPARE preDel FROM $stmt2;


    $DECLARE sdb_cur_x CURSOR FOR
       SELECT branch FROM servertbl WHERE branch <> 'S1';
    $OPEN sdb_cur_x;
    while (1)
    {
       $FETCH sdb_cur_x INTO $xBranch;

       if (SQLCODE != 0) break;

       sprintf_s(stmt,sizeof stmt,
		 "SELECT a.ipolicy \
		    FROM newa%s:policy a,newa%s:ply_relation b  \
		   WHERE a.ipolicy=b.ipolicy and nvl( b.dply_close,'')<>'' \
		     AND b.dply_end between %ld and %ld \
		     AND b.icar_type not in ('35','51') \
		     AND a.iengine in (select ipolicy from newa00:ca_tmp_no) \
		   union \
		  SELECT a.ipolicy \
		    FROM newa%s:policy a,newa%s:ply_relation b  \
		   WHERE a.ipolicy=b.ipolicy and nvl( b.dply_close,'')<>'' \
		     AND b.dply_end between %ld and %ld \
		     AND b.icar_type in ('35','51') \
		     AND (a.iengine in (select ipolicy from newa00:ca_tmp_no) or a.ibody in (select ipolicy from newa00:ca_tmp_no))",
		 xBranch ,xBranch , lPlyEnd_Bgn, lPlyEnd_End, xBranch ,xBranch , lPlyEnd_Bgn, lPlyEnd_End);


       $PREPARE preTmp FROM $stmt;
       $DECLARE curTmp CURSOR FOR preTmp;
       $OPEN    curTmp;
       for(;;){
         	  $FETCH curTmp INTO $sTmp;
         	  if (SQLCODE==SQLNOTFOUND) break;
         	  $EXECUTE preIns USING $sTmp;
       }
       $CLOSE curTmp;
       $FREE curTmp;
    }
    $CLOSE sdb_cur_x;
    $FREE  sdb_cur_x;

    $EXECUTE preDel;
    $EXECUTE preIns2;
    return M_CM_OK;

errexit:
   printf("12578 sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}



long test_data(iplymonth,intopt)
int intopt;
{
    int result;
    char p0[101], p1[101], p2[101] ,p3[101], p4[101],p5[101], p6[101], p7[101], p8[101], p9[101], p10[101],p11[101],p12[101];
    char sApHome[31], command[768];

    result = getApHome(sApHome);
    if (result < 0)
    {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
    }
    if( intopt == 0)
    {
        sprintf_s( p0,sizeof p0,"%s/exec/car302t", sApHome);
        sprintf_s( p1,sizeof p1,"%s/rptftp/p32_%d_2p", sApHome, iplymonth);
        sprintf_s( p2,sizeof p2,"%s/rptftp/p32_ins_%d_2p", sApHome, iplymonth);
        sprintf_s( p3,sizeof p3,"%s/rptftp/p32_%d_5p", sApHome, iplymonth);
        sprintf_s( p4,sizeof p4,"%s/rptftp/p32_ins_%d_5p", sApHome, iplymonth);
        sprintf_s( p5,sizeof p5,"%s/rptftp/p32_%d_2p_Z", sApHome, iplymonth);       /* ��W */
        sprintf_s( p6,sizeof p6,"%s/rptftp/p32_ins_%d_2p_Z", sApHome, iplymonth);
        sprintf_s( p7,sizeof p7,"%s/rptftp/p32_%d_2p_M", sApHome, iplymonth);       /* �p���p�Ȩ����� */
        sprintf_s( p8,sizeof p8,"%s/rptftp/p32_ins_%d_2p_M", sApHome, iplymonth);
        sprintf_s( p9,sizeof p9,"%s/rptftp/p32_%d_2p_T", sApHome, iplymonth);       /* �Τ@�F�ʯ���   */
        sprintf_s( p10,sizeof p10,"%s/rptftp/p32_ins_%d_2p_T", sApHome, iplymonth);
        sprintf_s( p11,sizeof p11,"%s/rptftp/p32_%d_A09_1", sApHome, iplymonth);     /* �έ�U�b��  */
        sprintf_s( p12,sizeof p12,"%s/rptftp/p32_ins_%d_A09_1", sApHome, iplymonth);

        printf(" p0[%s]\n p1[%s]\n p2[%s]\n p3[%s]\n p4[%s]\n p5[%s]\n p6[%s]\n p7[%s]\n p8[%s]\n p9[%s]\n p10[%s]\n p11[%s]\n p12[%s]\n",
                 p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12);

        sprintf_s( command,sizeof command, "%s %s %s %s %s %s %s %s %s %s %s %s %s", p0, p1, p2, p3, p4, p5, p6, p7, p8, p9, p10, p11, p12);
    }
    else
    {
        sprintf_s( p0,sizeof p0,"%s/exec/car302t1", sApHome);
        sprintf_s( p1,sizeof p1,"%s/rptftp/p32_%d_A09_4", sApHome, iplymonth);
        sprintf_s( p2,sizeof p2,"%s/rptftp/p32_ins_%d_A09_4", sApHome, iplymonth);

        printf(" p0[%s]\n p1[%s]\n p2[%s]\n ", p0, p1, p2);

        sprintf_s( command,sizeof command, "%s %s %s", p0, p1, p2);
    }

    printf("command[%s]\n", command);
    result = system( command);
    printf("result[%d]\n", result);
    puts("test_data ok");
    return M_CM_OK;

errexit:
    printf(" 12636 test_data() sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);

    return SQLCODE;
}

/* 981208,���o���w�O�v�ͮĤ餧�j���I�ζˮ`�I(47�B50�B48)�O�B
long get_comp_pa_cover(srate_code,sins_type)
$char srate_code[3];
$char sins_type[5];
{
    if (atoi(sins_type)==21){
    	 $SELECT first 1 mcoverage1,mcoverage2,mcoverage3
    	    INTO $injured_cover_comp,$death_cover_comp,$damage_cover_comp
    	    FROM compulsory_premium
           WHERE drate     = (select drate from ca_rate_date
                                where icode = $srate_code
                                  and itable = 'compulsory_premium');
         if (SQLCODE==SQLNOTFOUND) return -2;
    }else{
       if (atoi(sins_type)==47 || atoi(sins_type)==50){
    	  $SELECT DISTINCT mcoverage1,mcoverage2,(mcoverage1+mcoverage2)
    	     INTO $injured_cover_pa,$death_cover_pa,$damage_cover_pa
    	     FROM cover_vs_premium
		    WHERE iins_type = $sins_type
		      AND drate     = (select drate from ca_rate_date
                                where icode = $srate_code
                                  and itable = 'cover_vs_premium');
          if (SQLCODE==SQLNOTFOUND) return -2;
	   }else if (atoi(sins_type)==48){
    	  $SELECT DISTINCT mcoverage2
    	     INTO $injured_cover_pa
    	     FROM cover_vs_premium
		    WHERE iins_type = $sins_type
		      AND mdeduct   = 1
		      AND drate     = (select drate from ca_rate_date
                                where icode = $srate_code
                                  and itable = 'cover_vs_premium');
		  if (SQLCODE==SQLNOTFOUND) return -2;
    	  $SELECT DISTINCT mcoverage2
    	     INTO $death_cover_pa
    	     FROM cover_vs_premium
		    WHERE iins_type = $sins_type
		      AND mdeduct   = 0
		      AND drate     = (select drate from ca_rate_date
                                where icode = $srate_code
                                  and itable = 'cover_vs_premium');
          if (SQLCODE==SQLNOTFOUND) return -2;

		  damage_cover_pa = injured_cover_pa + death_cover_pa ;
	   }else{
	       return -1;
	   }
    }

    return M_CM_OK;

errexit:
    printf("get_comp_pa_cover() sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);

    return SQLCODE;
}
*/

/* 981208,���o���w�O�v�N�����j���I�ζˮ`�I(47�B50�B48)�O�B */
long get_comp_pa_cover(srate_code1,srate_code2)
$char srate_code1[4];
$char srate_code2[4];
{
     /* �j���I�O�B */
	 $SELECT first 1 mcoverage1,mcoverage2,mcoverage3
	    INTO $injured_cover_comp,$death_cover_comp,$damage_cover_comp
	    FROM compulsory_premium
       WHERE mcoverage1> 0
         AND drate     = (select drate from ca_rate_date
                           where icode = $srate_code1
                             and itable = 'compulsory_premium');
     if (SQLCODE==SQLNOTFOUND) return -2;

     /* 50�I�O�B */
	 $SELECT first 1 mcoverage1,mcoverage2,(mcoverage1+mcoverage2)
	    INTO $injured_cover_pa_50,$death_cover_pa_50,$damage_cover_pa_50
	    FROM cover_vs_premium
	   WHERE iins_type = '50'
	     AND mcoverage1> 0
	     AND drate     = (select drate from ca_rate_date
                           where icode = $srate_code2
                             and itable = 'cover_vs_premium');
     if (SQLCODE==SQLNOTFOUND) return -2;

     /* 47�I�O�B */
	 $SELECT first 1 mcoverage1,mcoverage2,(mcoverage1+mcoverage2)
	    INTO $injured_cover_pa_47,$death_cover_pa_47,$damage_cover_pa_47
	    FROM cover_vs_premium
	   WHERE iins_type = '47'
	     AND mcoverage1> 0
	     AND drate     = (select drate from ca_rate_date
                           where icode = $srate_code2
                             and itable = 'cover_vs_premium');
     if (SQLCODE==SQLNOTFOUND) return -2;

     /* 147�I�O�B */
	 $SELECT first 1 mcoverage1,mcoverage2,(mcoverage1+mcoverage2)
	    INTO $injured_cover_pa_147,$death_cover_pa_147,$damage_cover_pa_147
	    FROM cover_vs_premium
	   WHERE iins_type = '147'
	     AND mcoverage1> 0
	     AND drate     = (select drate from ca_rate_date
                           where icode = $srate_code2
                             and itable = 'cover_vs_premium');
    if (SQLCODE==SQLNOTFOUND) return -2;

     /* 48�I�O�B */
	 $SELECT first 1 mcoverage2
	    INTO $injured_cover_pa_48
	    FROM cover_vs_premium
	   WHERE iins_type = '48'
	     AND mdeduct   = 1
	     AND mcoverage2> 0
	     AND drate     = (select drate from ca_rate_date
                           where icode = $srate_code2
                             and itable = 'cover_vs_premium');
	 $SELECT first 1 mcoverage2
	    INTO $death_cover_pa_48
	    FROM cover_vs_premium
	   WHERE iins_type = '48'
	     AND mdeduct   = 0
	     AND mcoverage2> 0
	     AND drate     = (select drate from ca_rate_date
                           where icode = $srate_code2
                             and itable = 'cover_vs_premium');
     if (SQLCODE==SQLNOTFOUND) return -2;

	 damage_cover_pa_48 = injured_cover_pa_48 + death_cover_pa_48 ;


     return M_CM_OK;

errexit:
    printf("12774 get_comp_pa_cover() sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);

    return SQLCODE;
}

/* �Y searchString = replaceString      => �^�� searchString �b string�����Ӽ� */
/* �Y searchString != replaceString     => �N�b string����searchString ���N�� replaceString ,�æ^�Ǩ��N���Ӽ� */
/* �Y�j�M����εL����searchString�Q���N => �^�� 0 */
int strSearchReplace(char *string,char *searchString,char *replaceString)
 {
 char *currP, *baseStr;
 int  count = 0;
 $char tmp_currP[60001];
 currP = baseStr = NULL;

 while (*string)
      {
      currP = strstr (!currP ? string : baseStr, searchString);

      if (currP)
           {
           count++;
           baseStr = (currP + strlen (replaceString));

           /* strcpy (currP, (currP + strlen (searchString))); */

	   strcpy (tmp_currP, (currP + strlen (searchString)));
	   strcpy (currP, tmp_currP);

           memmove (currP + strlen (replaceString),
                      currP, strlen (currP) + 1);
           memcpy (currP, replaceString, strlen (replaceString));
           }
      else
           break;
      }

 return count;
 }


 /* 100.06 ���N�I�@�Υ��x�W�沧��*/
 /* 99.11�^�����d���T��� */
 /* if sBranch[0] = " " => All DB
    if iType[0]   = " " => All Type ( iType = Y00�G�����I;Y01�G�k�H�L���P;Y02�G�k�H�����P  )
 */

long GetNoTradeData(sBranch,lPly_Bgn,lPly_End,iType,userid)
$char sBranch[3];
$long lPly_Bgn, lPly_End;
$char iType[4];
$char userid[12];
{
    int   count_db1,i;
    $char stmt[2048],sTmp[21],stmt2[512],sType_stmt[512];
    $char xBranch[3];
    $char sTable[60],xType[4];
    $char ipolicy[21],iassured[13],itag[CA_TAG_NUM],iengine[CA_ENGINE_NUM],icar_type[3];
    $char iofficer[11],lia_class_pre[3],s_pdmg_acc_pre[6],iflag[2];
    $char s_punknown_acc_pre[6];
    $date ply_end;
    char  fOneBranchOnly,fOneTypeOnly;

    $WHENEVER SQLERROR GOTO errexit;
    printf("Trace ------ GetNoTradeData() begin---------------------------  \n");
    printf("Trace -- sBranch  = [%s] \n",  sBranch);
    printf("Trace -- lPly_Bgn = [%ld] \n", lPly_Bgn);
    printf("Trace -- lPly_End = [%ld] \n", lPly_End);
    printf("Trace -- iType    = [%s] \n",  iType);
    printf("Trace -- userid    = [%s] \n", userid);

    if (strlen(trim(sBranch))==2)
    { /* �u�^����@��Ʈw */
        fOneBranchOnly = 'Y';
    }
    else
    {
    	fOneBranchOnly = 'N';
    }

    if (strlen(trim(iType))>1)
    {    /* �u�^����@itype */
	fOneTypeOnly = 'Y';
    }
    else
    {
    	fOneTypeOnly = 'N';
    }

    sprintf_s(stmt2,sizeof stmt2, "INSERT INTO ca_no_trade_302 \
	                                    Values (?,?,?,?,?,null,?,current,?,null,?)");
    $PREPARE preNo_trade_Ins FROM $stmt2;

    sprintf_s(stmt2,sizeof stmt2, "DELETE FROM ca_no_trade_302 WHERE ipolicy = ?");
    $PREPARE preNo_trade_Del FROM $stmt2;


    /* 102.08 �q�ʦۦ樮(�L���P)���d���T*/
    /* 100.06 �����I�n�d���T*/
    /* ��O�J�p���d���T��ư��k�H�������P���� add by sylvia 104.08.12 (1040811002_C1) */


    for (i=0;i<2;i++)
    {
        if(fOneTypeOnly == 'Y')
	{ /* �u�^����@itype */
	    i = atoi(iType[2]);
	}

	switch (i)
	{

	    case 0: /*Y00*/
	        strcpy (xType,"Y00");
                sprintf_s(sType_stmt,sizeof sType_stmt,"%s"," AND b.fcard_class='2' AND b.icar_type = '51' " );
	 	break;
	    case 1: /*Y01*/
	 	strcpy (xType,"Y01");
	 	sprintf_s(sType_stmt,sizeof sType_stmt,"%s"," AND b.fcard_class='2' AND a.fassured IN ('2','4','6') AND \
	 			              b.icar_type <> '51' AND  nvl(a.itag,'')='' " );
	 	break;
	    case 2: /*Y02*//* �k�H�������P , �w�ư�, �����|���楻�q  sylvia 104.08.12 */
	 	strcpy (xType,"Y02");
	 	sprintf_s(sType_stmt,sizeof sType_stmt,"%s"," AND a.ipolicy = c.ipolicy AND a.iassured = c.iassured AND \
	 			              b.fcard_class='2' AND a.fassured IN ('2','4','6') AND  \
	 			              b.icar_type <> '51'  AND nvl(a.itag,'')<>'' AND nvl(c.itag,'')<>'' AND a.itag <> c.itag " );
 	 	break;
	}

	$DECLARE sdb_cur_no_trade CURSOR WITH HOLD FOR
	  SELECT branch FROM servertbl WHERE branch <> 'S1';
	$OPEN sdb_cur_no_trade;
	while (1)
	{
	    $FETCH sdb_cur_no_trade INTO $xBranch;

	    if (SQLCODE != 0) break;
            $begin work;
	    printf("Trace -- xBranch = [%s] \n",  xBranch);
	    if (fOneBranchOnly=='Y')
	    { /* �u�^����@��Ʈw */
	        strcpy(xBranch,sBranch);
	       	printf("  Trace -- xBranch = [%s] \n",  xBranch);
	    }
	    if (i==2)
	    {
	        sprintf_s(sTable,sizeof sTable,",newa%s:%s c",xBranch, "original_ply");
	    }
	    else
	    {
	        strcpy (sTable," ");
	    }

	    sprintf_s(stmt,sizeof stmt,"SELECT a.ipolicy,b.dply_end \
			 FROM newa%s:policy a,newa%s:ply_relation b %s  \
			 WHERE a.ipolicy=b.ipolicy AND nvl(b.fedr_class,' ')<>'1' AND nvl( b.dply_close,'')<>'' \
			 %s \
			 AND b.dply_end BETWEEN %ld And %ld ",
			 xBranch ,xBranch ,sTable,sType_stmt, lPly_Bgn, lPly_End);
	    printf("Trace -- TEST = [%s] \n",  stmt);
	    $WHENEVER SQLERROR CONTINUE;

	    $PREPARE preTmp FROM $stmt;
	    $DECLARE curTmp5 CURSOR FOR preTmp;
	    $OPEN    curTmp5;

	    for(;;)
	    {
	        $FETCH curTmp5 INTO $ipolicy,$dply_end;
	        if (SQLCODE==SQLNOTFOUND) break;

	        /* insert into ca_no_trade_302*/
                $EXECUTE preNo_trade_Ins USING $ipolicy,$dply_end," "," ",$xType,$userid," "," ";
                if (SQLCODE == -239)
                {
                    $EXECUTE preNo_trade_Del USING $ipolicy;
                    $EXECUTE preNo_trade_Ins USING $ipolicy,$dply_end," "," ",$xType,$userid," "," ";
                }
                else if (SQLCODE != 0)
                {
                     goto errexit;
                }
	    }
	    $CLOSE curTmp5;
	    $FREE curTmp5;
	    $WHENEVER SQLERROR GOTO errexit;
	    if (fOneBranchOnly=='Y')
	    { /* �u�^����@��Ʈw */
	        break;
	    }
	    $commit work;
	}
	$CLOSE sdb_cur_no_trade;
	$FREE  sdb_cur_no_trade;

	if(fOneTypeOnly == 'Y')
	{ /* �u�^����@itype */
	    	break; /* �u�^����@itype */
	}

    }
    printf("Trace ------ GetNoTradeData() end---------------------------  \n");
    return M_CM_OK;

errexit:
   printf("12955 sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   $WHENEVER SQLERROR CONTINUE;
   $rollback work;
   return SQLCODE;
}

/* �� ���o���d���T�� ����[��O�I�ơB���d�̷s�ż�
    �ӷ��Gca_no_trade_302
    return :
    M_NOTRADE_NO_UNKNOWN            -30300
	M_NOTRADE_NO_RECORD             -30299
	M_NOTRADE_NO_DMG_LIA            -30298
	M_NOTRADE_NO_DMG                -30297
	M_NOTRADE_NO_LIA                -30298
   -30299: ca_no_trade_302 �d�L���
   -30298: ca_no_trade_302 �d����ơA�L"����[��O�I��"�B�L"���d�̷s�ż�"
   -30297: ca_no_trade_302 �d����ơA���L"����[��O�I��
   -30297: ca_no_trade_302 �d����ơA���L"���d�̷s�ż�"

   outRef:
    qdmg_point�G����[��O�I��
    lia_class �G���d�̷s�ż�
    qunknown_dmg�G�������l�[��O�I��
    sType     �G���d���T��N��
   */
long get_ca_no_trade_302(
  char  *mipolicy,
  int   *qdmg_point,
  int   *lia_class,
  int   *qunknown_dmg,
  char  *sType)
{

	$char stmt[1024],v_ipolicy[21], s_iType[4];
	$int i_qdmg_point=-9999,i_lia_class=-9999,i_unknown_point=-9999;

	long  errCode;

    $WHENEVER SQLERROR GOTO errexit;
    strcpy(s_iType," ");
    strcpy(v_ipolicy,mipolicy);
    printf("Trace -- in get_ca_no_trade_302() \n");
    printf("Trace -- vipolicy = [%s] \n",  v_ipolicy);

	sprintf_s(stmt,sizeof stmt, "SELECT nvl(qdmg::INTEGER,-9999),nvl(lia_class::INTEGER,-9999),itype, \n\
	                      nvl(qunknown_dmg::INTEGER,-9999) \n\
	                 FROM ca_no_trade_302 \n\
	                WHERE ipolicy = '%s'",v_ipolicy );
	printf("Trace -- stmt = [%s] \n",  stmt);
	$PREPARE preNo_trade FROM $stmt;
	$Execute preNo_trade Into $i_qdmg_point,$i_lia_class, $s_iType, $i_unknown_point;

	if (SQLCODE==SQLNOTFOUND){

			i_qdmg_point  = 0;
			i_lia_class   = 4;
			i_unknown_point = 0;
			/* strcpy(s_iType," "); */
		    errCode       = M_NOTRADE_NO_RECORD;

	}
	else
	{

	    if (i_unknown_point ==-9999) i_unknown_point = 0;

		if ((i_qdmg_point==-9999) && (i_lia_class==-9999)){
			i_qdmg_point  = 0;
			i_lia_class   = 4;
			errCode       = M_NOTRADE_NO_DMG_LIA;

		}else if (i_qdmg_point==-9999) {  /* i_lia_class ���� */
		    i_qdmg_point  = 0;
		    errCode       = M_NOTRADE_NO_DMG;

		}else if (i_lia_class==-9999) {   /* i_qdmg_point ���� */
			i_lia_class   = 4;
			errCode       = M_NOTRADE_NO_LIA;

		}else{
			errCode       = M_CM_OK  ;
		}
	}

	strcpy(sType, s_iType) ;

    *qdmg_point   = i_qdmg_point  ;

    *lia_class    = i_lia_class   ;

    *qunknown_dmg   = i_unknown_point  ;


    return errCode;

errexit:
    printf("13034 get_ca_no_trade_302() sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

long get_ca_no_trade_taxi(
  char  *mipolicy,
  int   *qdmg_point,
  double   *lia_class,
  char  *sType)
{

	$char stmt[1024],v_ipolicy[21], s_iType[4]=" ";
	$int i_qdmg_point=-9999;
	$double i_lia_class=-9999;

	long  errCode;

   $WHENEVER SQLERROR GOTO errexit;
   strcpy(v_ipolicy,mipolicy);
   printf("Trace -- in get_ca_no_trade_taxi() \n");
   printf("Trace -- vipolicy = [%s] \n",  v_ipolicy);

   sprintf_s(stmt,sizeof stmt, "SELECT nvl(qdmg::INTEGER,-9999),nvl(lia_class,-9999),itype \n\
	                 FROM ca_no_trade_302 \n\
	                WHERE ipolicy = '%s'",v_ipolicy );
	/*printf("Trace -- stmt = [%s] \n",  stmt);*/
	$PREPARE preNo_trade FROM $stmt;
	$Execute preNo_trade Into $i_qdmg_point,$i_lia_class, $s_iType;

	if (SQLCODE==SQLNOTFOUND){
			i_qdmg_point  = 0;
			i_lia_class   = 0.0;
		   errCode       = M_NOTRADE_NO_RECORD;

	}else{
		if ((i_qdmg_point==-9999) && (i_lia_class==-9999)){
			i_qdmg_point  = 0;
			i_lia_class   = 0.0;
			errCode       = M_NOTRADE_NO_DMG_LIA;

		}else if (i_qdmg_point==-9999) {  /* i_lia_class ���� */
		    i_qdmg_point  = 0;
		    errCode       = M_NOTRADE_NO_DMG;

		}else if (i_lia_class==-9999) {   /* i_qdmg_point ���� */
			i_lia_class   = 0.0;
			errCode       = M_NOTRADE_NO_LIA;

		}else{
			errCode       = M_CM_OK  ;
		}
	}

	strcpy(sType, s_iType) ;

    *qdmg_point   = i_qdmg_point  ;
    *lia_class    = i_lia_class   ;

    return errCode;

errexit:
    printf("13095 get_ca_no_trade_taxi() sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/* 102.11.12 �s�W�ǤJ iacc_kind(�G�X)�G
    iacc_kind[0]������Y�����O[ 1:����(Ex.01�B08�I��); 3:�������l�榸(Ex.105�B85�I��); 4:�������l���p(Ex.05�B09�I��) ]
                              [ 6:�¤������I�h��(�t4.�������l���p)  7:�¤������l�榸(�t4.�������l���p)]
    iacc_kind[1]�����d�Y�����O( �ثe�u���@�ءA�T�w�� '2:���d') */
/* 100.06���T����,�s�W �J�`���O: 2=�T�� ,3=����  */

/* �� ���o�d���T��ΤH�u�f�֫��J�� ����[��O�I�ơB���d�̷s�ż�
    �ӷ��Gca_trade_302
    return :
	M_NOTRADE_NO_RECORD             -30299
	M_NOTRADE_NO_DMG_LIA            -30298
	M_NOTRADE_NO_DMG                -30297
	M_NOTRADE_NO_LIA                -30298
   -30299: ca_no_trade_302 �d�L���
   -30298: ca_no_trade_302 �d����ơA�L"����[��O�I��"�B�L"���d�̷s�ż�"
   -30297: ca_no_trade_302 �d����ơA���L"����[��O�I��
   -30297: ca_no_trade_302 �d����ơA���L"���d�̷s�ż�"

   outRef:
    query_num_dmg        �G���T�d�ߧǸ�(���N�I)
    qdmg_point           �G����[��O�I��
    lia_class            �G���d�̷s�ż�
    qdmg_acc_sum         �G����T�~���ߴڦ����`�M
    qlia_acc_sum         �G���d�T�~���ߴڦ����`�M
    trade_msg_no_dmg     �G���T�^�Ф��T���N�X
    qunknown_point       �G����[��O�I��
    qunknown_acc_sum     �G����T�~���ߴڦ����`�M
    qdmg_acc_sum_5y      �G����e���~�߮צ���(�w�M�B�ߴڪ��B��0)
    qlia_acc_sum_5y      �G���d�e���~�߮צ���
    qduty_sum_5y         �G�e���~�F�d���p������(����+���d)
    qdmg_acc_sum_5y_pure �G����e���~�߮צ���
    qacc_sum_5y          �G�e���~�߮צ���(����+���d)
    fhave_newa_c_2y      �G�e�G�~�O�_�b�s�w��O�L�T���I
    dfirst_ply           �G���N�I�̦���O��

   */
long get_ca_trade_302(
  char  *fassured,
  char  *iassured,
  char  *itag,
  char  *icar_kind,
  char  *iacc_kind,
  long  *dMinQuery,
  char  *query_num_dmg,
  char  *query_num_lia,
  int   *qdmg_point,
  int   *lia_class,
  int   *qdmg_acc_sum,
  int   *qlia_acc_sum,
  char  *trade_msg_no_dmg,
  char  *trade_msg_no_lia,
  char  *query_num_unknown,
  int   *qunknown_point,
  int   *qunknown_acc_sum,
  char  *trade_msg_no_unknown,
  int   *qdmg_acc_sum_5y,
  int   *qlia_acc_sum_5y,
  int   *qduty_sum_5y,
  int   *qdmg_acc_sum_5y_pure,
  int   *qacc_sum_5y,
  int   *fhave_newa_c_2y,
  char  *dfirst_ply)
{
	$char stmt[1024];
	$char iacc_kind1;
	/*$char v_iass1[3],v_iass2[3];*/

	/* �Ѽ�in */
	$char v_fassured[2],v_iassured[12],v_itag[CA_TAG_NUM],v_icar_kind[2],v_iacc_kind[3];
	$long v_dMinQuery;

	/* �Ѽ�out */
	$char s_query_num_dmg[21]=" ", s_trade_msg_no_dmg[5]=" ";
	$char s_query_num_lia[21]=" ", s_trade_msg_no_lia[5]=" ";
	$char s_query_num_unknown[21]=" ", s_trade_msg_no_unknown[5]=" ";
	$char s_dfirst_ply[11]=" ";
	$int  i_qdmg_point=-9999,i_lia_class=-9999,i_qdmg_acc_sum=-9999,i_qlia_acc_sum=-9999;
	$int  i_qunknown_point=-9999,i_qunknown_acc_sum=-9999;
	$int  i_qdmg_acc_sum_5y=-9999,i_qlia_acc_sum_5y=-9999,i_qdmg_duty_sum_5y=-9999,i_qlia_duty_sum_5y=-9999;
	$int  i_qdmg_acc_sum_5y_pure=-9999,i_fhave_newa_c_2y=-9999;
	long  errCode;

	$WHENEVER SQLERROR GOTO errexit;

	strcpy(v_fassured  , trim(fassured));
	strcpy(v_iassured  , trim(iassured));
	v_dMinQuery = dMinQuery ;
	strcpy(v_icar_kind , icar_kind);
	strcpy(v_iacc_kind , iacc_kind);

	errCode = M_CM_OK  ;

	printf("Trace -- in get_get_ca_trade_302() \n");
	printf("Trace -- v_iassured = [%s] \n",  v_iassured);
	printf("Trace -- v_dMinQuery = [%ld] \n",  v_dMinQuery);

	/*99.12.09�}�l�A���T�w��ܥ����νs��T */
	/* �νs�Ȯ��٧t��*���A�ȨϥΨ���������,�P�ɤ��e��G�X */

	/* �k�H */
	if ((v_fassured[0]=='2') || (v_fassured[0]=='4') || (v_fassured[0] == '6')){
		strcpy(v_itag      , itag);
	/* �۵M�H */
	}else{
		if (TRADE3022 == 0)
			strcpy(v_itag      , " ");
		else
			strcpy(v_itag      , itag);
	}
	printf("Trace -- v_itag  = [%s] \n",  v_itag);

	strcpy(query_num_unknown, " ") ;
	strcpy(trade_msg_no_unknown , " ") ;
	*qunknown_point   = 0;
	*qunknown_acc_sum = 0;
	/* ���o �����I�� */
	if ((v_iacc_kind[0]!='0')&&(v_iacc_kind[0]!=' ')){  /* ���� */
		if ((v_iacc_kind[0] == '6') || (v_iacc_kind[0] == '7'))
		{   /* ���ӫO152,153�������l */
			iacc_kind1 = '4'; /* ���ӫO152,153, ���鬰05,09�I�� */
			sprintf_s(stmt,sizeof stmt, "SELECT iquery_num,nvl(qpoint::INTEGER,-9999),nvl(qacc_sum::INTEGER,-9999),imsg_no \n\
			                 FROM ca_trade_302 \n\
			                WHERE iassured='%s' AND itag ='%s' AND icar_kind = '%s' AND iacc_kind = '%c' \n\
			                  AND dquery IN ( \n\
			                      SELECT max(dquery) \n\
			                        FROM ca_trade_302 \n\
			                       WHERE iassured  = '%s' AND itag ='%s' \n\
			                         AND icar_kind = '%s' AND iacc_kind = '%c' \n\
			                         AND dquery >= %ld::date ) " ,
			v_iassured,v_itag,v_icar_kind,v_iacc_kind[0],v_iassured,v_itag,v_icar_kind,v_iacc_kind[0],v_dMinQuery );

			$PREPARE preNo_tradeA FROM $stmt;
			$Execute preNo_tradeA Into $s_query_num_unknown,$i_qunknown_point,
			                           $i_qunknown_acc_sum,$s_trade_msg_no_unknown;

			if (SQLCODE==SQLNOTFOUND){
				strcpy(s_query_num_unknown, " ") ;
				strcpy(s_trade_msg_no_unknown , " ") ;
				i_qunknown_point  = 0;
				i_qunknown_acc_sum= 0;
				errCode       = M_NOTRADE_NO_UNKNOWN;
			}else{
				if (i_qunknown_point==-9999) {
					i_qunknown_point  = 0;
					i_qunknown_acc_sum= 0;
					errCode       = M_NOTRADE_NO_UNKNOWN;
				}
			}
			strcpy(query_num_unknown, s_query_num_unknown) ;
			strcpy(trade_msg_no_unknown , s_trade_msg_no_unknown ) ;
			*qunknown_point   = i_qunknown_point  ;
			*qunknown_acc_sum = i_qunknown_acc_sum;
		}
		else
		{
			iacc_kind1 = v_iacc_kind[0];
			strcpy(query_num_unknown, " ") ;
			strcpy(trade_msg_no_unknown , " " ) ;
			*qunknown_point   = 0 ;
			*qunknown_acc_sum = 0;
		}
	 	/* sprintf_s(stmt,sizeof stmt, "SELECT iquery_num,nvl(qpoint::INTEGER,-9999),nvl(qacc_sum::INTEGER,-9999),imsg_no \n\
		                 FROM ca_trade_302 \n\
		                 WHERE iassured='%s' AND itag ='%s' AND icar_kind = '%s' AND iacc_kind = '%c' \n\
		                   AND dquery IN ( \n\
	                            SELECT max(dquery) \n\
	                              FROM ca_trade_302 \n\
		                         WHERE iassured  = '%s' AND itag ='%s' \n\
		                           AND icar_kind = '%s' AND iacc_kind = '%c' \n\
		                           AND dquery >= %ld::date ) " ,
	           v_iassured,v_itag,v_icar_kind,v_iacc_kind[0],v_iassured,v_itag,v_icar_kind,v_iacc_kind[0],v_dMinQuery ); */
	        /* ���� */
	        sprintf_s(stmt,sizeof stmt, "SELECT iquery_num,nvl(qpoint::INTEGER,-9999),nvl(qacc_sum::INTEGER,-9999), \n\
	                              nvl(qacc_sum_5y::INTEGER,-9999),nvl(qduty_sum_5y::INTEGER,-9999), \n\
	                              nvl(qdmg_acc_sum_5y::INTEGER,-9999),nvl(fhave_newa_c_2y::INTEGER,-9999), \n\
	                              dfirst_ply,imsg_no \n\
	                         FROM ca_trade_302 \n\
	                        WHERE iassured='%s' AND itag ='%s' AND icar_kind = '%s' AND iacc_kind = '%c' \n\
	                          AND dquery IN ( \n\
	                              SELECT max(dquery) \n\
	                                FROM ca_trade_302 \n\
	                               WHERE iassured  = '%s' AND itag ='%s' \n\
	                                 AND icar_kind = '%s' AND iacc_kind = '%c' \n\
	                                 AND dquery >= %ld::date ) " ,
	        v_iassured,v_itag,v_icar_kind,iacc_kind1,v_iassured,v_itag,v_icar_kind,iacc_kind1,v_dMinQuery );

		printf("Trace -- stmt = [%s] \n",  stmt);
		$PREPARE preNo_trade1 FROM $stmt;
		$Execute preNo_trade1 Into $s_query_num_dmg,$i_qdmg_point,$i_qdmg_acc_sum,
		                           $i_qdmg_acc_sum_5y,$i_qdmg_duty_sum_5y,
		                           $i_qdmg_acc_sum_5y_pure,$i_fhave_newa_c_2y,
		                           $s_dfirst_ply,$s_trade_msg_no_dmg;

		if (SQLCODE==SQLNOTFOUND){
			strcpy(s_query_num_dmg, " ") ;
			strcpy(s_trade_msg_no_dmg , " ") ;
			i_qdmg_point  = 0;
			i_qdmg_acc_sum= 0;
			i_qdmg_acc_sum_5y = 0;
			i_qdmg_duty_sum_5y = 0;
			i_qdmg_acc_sum_5y_pure = 0;
			i_fhave_newa_c_2y = 0;
			errCode       = M_NOTRADE_NO_DMG;
		}else{
			if (i_qdmg_point==-9999) {
				i_qdmg_point  = 0;
				i_qdmg_acc_sum= 0;
				i_qdmg_acc_sum_5y = 0;
				i_qdmg_duty_sum_5y = 0;
				i_qdmg_acc_sum_5y_pure = 0;
				i_fhave_newa_c_2y = 0;
				errCode       = M_NOTRADE_NO_DMG;
			}
		}
		strcpy(query_num_dmg, s_query_num_dmg) ;
		strcpy(dfirst_ply , s_dfirst_ply ) ;
		strcpy(query_num_dmg, s_query_num_dmg) ;
		*qdmg_point   = i_qdmg_point  ;
		*qdmg_acc_sum = i_qdmg_acc_sum;
		*qdmg_acc_sum_5y = i_qdmg_acc_sum_5y;
		*qdmg_acc_sum_5y_pure = i_qdmg_acc_sum_5y_pure;
		*fhave_newa_c_2y = i_fhave_newa_c_2y;
	}
	/* ���o ���d�ż�(�@��) */
	if ((v_iacc_kind[1]!='0')&&(v_iacc_kind[1]!=' ')){  /* ���d */
	 	sprintf_s(stmt,sizeof stmt, "SELECT iquery_num,nvl(qpoint::INTEGER,-9999),nvl(qacc_sum::INTEGER,-9999), \n\
	 	                      nvl(qacc_sum_5y::INTEGER,-9999),nvl(qduty_sum_5y::INTEGER,-9999),imsg_no \n\
	 	                 FROM ca_trade_302 \n\
	 	                WHERE iassured='%s' AND itag ='%s' AND icar_kind = '%s' AND iacc_kind = '%c' \n\
	 	                  AND dquery IN ( \n\
	 	                      SELECT max(dquery) \n\
	 	                        FROM ca_trade_302 \n\
	 	                       WHERE iassured  = '%s' AND itag ='%s' \n\
	 	                         AND icar_kind = '%s' AND iacc_kind = '%c' \n\
	 	                         AND dquery >= %ld::date ) " ,
	 	v_iassured,v_itag,v_icar_kind,v_iacc_kind[1],v_iassured,v_itag,v_icar_kind,v_iacc_kind[1],v_dMinQuery );


		printf("Trace -- stmt = [%s] \n",  stmt);
		$PREPARE preNo_trade2 FROM $stmt;
		$Execute preNo_trade2 Into $s_query_num_lia,$i_lia_class,$i_qlia_acc_sum,
		                           $i_qlia_acc_sum_5y,$i_qlia_duty_sum_5y,$s_trade_msg_no_lia;

		if (SQLCODE==SQLNOTFOUND){
			strcpy(s_query_num_lia, " ") ;
			strcpy(s_trade_msg_no_lia , " ") ;
			i_lia_class   = 4;
			i_qlia_acc_sum= 0;
			i_qlia_acc_sum_5y = 0;
			i_qlia_duty_sum_5y = 0;

			if (errCode == M_NOTRADE_NO_DMG){
				errCode = M_NOTRADE_NO_DMG_LIA ;
			}else{
				errCode = M_NOTRADE_NO_LIA ;
			}
		}else{
			if (i_lia_class==-9999) {
				i_lia_class   = 4;
				i_qlia_acc_sum= 0;
				i_qlia_acc_sum_5y = 0;
				i_qlia_duty_sum_5y = 0;
				if (errCode == M_NOTRADE_NO_DMG){
					errCode = M_NOTRADE_NO_DMG_LIA ;
				}else{
					errCode = M_NOTRADE_NO_LIA ;
				}
			}
		}

		strcpy(query_num_lia, s_query_num_lia) ;
		strcpy(trade_msg_no_lia , s_trade_msg_no_lia ) ;
		*lia_class    = i_lia_class   ;
		*qlia_acc_sum = i_qlia_acc_sum;
		*qlia_acc_sum_5y = i_qlia_acc_sum_5y;

		*qduty_sum_5y = i_qdmg_duty_sum_5y + i_qlia_duty_sum_5y;
		*qacc_sum_5y = i_qdmg_acc_sum_5y_pure + i_qlia_acc_sum_5y;

	}

	return errCode;

errexit:
    printf("13292 get_ca_trade_302() sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

long get_ca_trade_taxi(
  char   *fassured,
  char   *iassured,
  char   *itag,
  char   *icar_kind,
  char   *iacc_kind,
  long   *dMinQuery,
  char   *query_num_dmg,
  char   *query_num_lia,
  int    *qdmg_point,
  double *lia_class,
  int    *qdmg_acc_sum,
  int    *qlia_acc_sum,
  char   *trade_msg_no_dmg,
  char   *trade_msg_no_lia,
  char   *query_num_unknown,
  int    *qunknown_point,
  int    *qunknown_acc_sum,
  char   *trade_msg_no_unknown,
  int    *qdmg_acc_sum_5y,
  int    *qlia_acc_sum_5y,
  int    *qduty_sum_5y,
  int    *qdmg_acc_sum_5y_pure,
  int    *qacc_sum_5y,
  int    *fhave_newa_c_2y,
  char   *dfirst_ply  )
{
   $char stmt[1024];
   $char iacc_kind1;
   /* �Ѽ�in */
   $char v_fassured[2],v_iassured[12],v_itag[CA_TAG_NUM],v_icar_kind[2],v_iacc_kind[3];
   $long v_dMinQuery;

   /* �Ѽ�out */
   $char s_query_num_dmg[21]=" ", s_trade_msg_no_dmg[5]=" ";
   $char s_query_num_lia[21]=" ", s_trade_msg_no_lia[5]=" ";
   $char s_query_num_unknown[21]=" ", s_trade_msg_no_unknown[5]=" ";
   $char s_dfirst_ply[11]=" ";
   $int  i_qdmg_point=-9999,i_qdmg_acc_sum=-9999,i_qlia_acc_sum=-9999;
   $int  i_qdmg_acc_sum_5y=-9999,i_qlia_acc_sum_5y=-9999,i_qdmg_duty_sum_5y=-9999,i_qlia_duty_sum_5y=-9999;
   $int  i_qdmg_acc_sum_5y_pure=-9999,i_fhave_newa_c_2y=-9999;
   $double i_lia_class=-9999;
   $int  i_qunknown_point=-9999,i_qunknown_acc_sum=-9999;
   long  errCode;

   $WHENEVER SQLERROR GOTO errexit;

   strcpy(v_fassured  , trim(fassured));
   strcpy(v_iassured  , trim(iassured));
   v_dMinQuery = dMinQuery ;
   strcpy(v_icar_kind , icar_kind);
   strcpy(v_iacc_kind , iacc_kind);

   errCode = M_CM_OK  ;

   printf("Trace -- in get_ca_trade_taxi() \n");
   printf("Trace -- v_iassured = [%s] \n",  v_iassured);
   printf("Trace -- v_dMinQuery = [%ld] \n",  v_dMinQuery);

    /* �k�H */
    if ((v_fassured[0]=='2') || (v_fassured[0]=='4') || (v_fassured[0] == '6')){
         strcpy(v_itag      , itag);
         printf("Trace -- v_itag  = [%s] \n",  v_itag);

    }
	else
	{ /* �۵M�H */

      if (TRADE3022 == 0)
         strcpy(v_itag      , " ");
      else
         strcpy(v_itag      , itag);
    }

    strcpy(query_num_unknown, " ") ;
    strcpy(trade_msg_no_unknown , " ") ;
    *qunknown_point   = 0;
    *qunknown_acc_sum = 0;

    /* ���o �����I�� */
    if ((v_iacc_kind[0]!='0')&&(v_iacc_kind[0]!=' '))
    {
        if ((v_iacc_kind[0] == '6') || (v_iacc_kind[0] == '7'))
        {   /* ���ӫO152,153�������l */
            iacc_kind1 = 4; /* ���ӫO152,153, ���鬰05,09�I�� */
            sprintf_s(stmt,sizeof stmt, "SELECT iquery_num,nvl(qpoint::INTEGER,-9999),nvl(qacc_sum::INTEGER,-9999),imsg_no \n\
                             FROM ca_trade_302 \n\
                            WHERE iassured='%s' AND itag ='%s' AND icar_kind = '%s' AND iacc_kind = '%c' \n\
                              AND dquery IN ( \n\
                                  SELECT max(dquery) \n\
                                    FROM ca_trade_302 \n\
                                   WHERE iassured  = '%s' AND itag ='%s' \n\
                                     AND icar_kind = '%s' AND iacc_kind = '%c' \n\
                                     AND dquery >= %ld::date ) " ,
                     v_iassured,v_itag,v_icar_kind,v_iacc_kind[0],v_iassured,
                     v_itag,v_icar_kind,v_iacc_kind[0],v_dMinQuery );

    		printf("Trace -- stmt = [%s] \n",  stmt);
            $PREPARE preNo_tradeB FROM $stmt;
    		$Execute preNo_tradeB Into
                $s_query_num_unknown,$i_qunknown_point,$i_qunknown_acc_sum,$s_trade_msg_no_unknown;

    		if (SQLCODE==SQLNOTFOUND){
    	        strcpy(s_query_num_unknown, " ") ;
    	        strcpy(s_trade_msg_no_unknown , " ") ;

    			i_qunknown_point  = 0;
    			i_qunknown_acc_sum= 0;
    			errCode       = M_NOTRADE_NO_UNKNOWN;
    		}else{
    			if (i_qunknown_point==-9999) {
    			    i_qunknown_point  = 0;
    			    i_qunknown_acc_sum= 0;
    			    errCode       = M_NOTRADE_NO_UNKNOWN;
    			}
    		}
    	    strcpy(query_num_unknown, s_query_num_unknown) ;
    	    strcpy(trade_msg_no_unknown , s_trade_msg_no_unknown ) ;
    	    *qunknown_point   = i_qunknown_point  ;
    	    *qunknown_acc_sum = i_qunknown_acc_sum;
        }
        else
        {
            iacc_kind1 = v_iacc_kind[0];
        }
        /* sprintf_s(stmt,sizeof stmt, "SELECT iquery_num,nvl(qpoint::INTEGER,-9999),nvl(qacc_sum::INTEGER,-9999),imsg_no \n\
                       FROM ca_trade_302 \n\
                      WHERE iassured='%s' AND itag ='%s' AND icar_kind = '%s' AND iacc_kind = '%c' \n\
                        AND dquery IN ( \n\
                            SELECT max(dquery) \n\
                              FROM ca_trade_302 \n\
                             WHERE iassured  = '%s' AND itag ='%s' \n\
                               AND icar_kind = '%s' AND iacc_kind = '%c' \n\
                               AND dquery >= %ld::date ) " ,
                     v_iassured,v_itag,v_icar_kind,v_iacc_kind[0],v_iassured,
                     v_itag,v_icar_kind,v_iacc_kind[0],v_dMinQuery ); */
        /* �ʤֳr���ɭP�p�{���Y�Ƭd���� modify by 061476 (1090803002_SC5) */
        sprintf_s(stmt,sizeof stmt, "SELECT iquery_num,nvl(qpoint::INTEGER,-9999),nvl(qacc_sum::INTEGER,-9999), \n\
                       nvl(qacc_sum_5y::INTEGER,-9999),nvl(qduty_sum_5y::INTEGER,-9999), \n\
                       nvl(qdmg_acc_sum_5y::INTEGER,-9999),nvl(fhave_newa_c_2y::INTEGER,-9999), \n\
                       dfirst_ply,imsg_no \n\
                       FROM ca_trade_302 \n\
                      WHERE iassured='%s' AND itag ='%s' AND icar_kind = '%s' AND iacc_kind = '%c' \n\
                        AND dquery IN ( \n\
                            SELECT max(dquery) \n\
                              FROM ca_trade_302 \n\
                             WHERE iassured  = '%s' AND itag ='%s' \n\
                               AND icar_kind = '%s' AND iacc_kind = '%c' \n\
                               AND dquery >= %ld::date ) " ,
                     v_iassured,v_itag,v_icar_kind,iacc_kind1,v_iassured,
                     v_itag,v_icar_kind,iacc_kind1,v_dMinQuery );
        printf("Trace -- stmt = [%s] \n",  stmt);
		$PREPARE preNo_trade11 FROM $stmt;
		$Execute preNo_trade11 Into $s_query_num_dmg,$i_qdmg_point,$i_qdmg_acc_sum,
		                            $i_qdmg_acc_sum_5y,$i_qdmg_duty_sum_5y,
		                            $i_qdmg_acc_sum_5y_pure,$i_fhave_newa_c_2y,
		                            $s_dfirst_ply,$s_trade_msg_no_dmg;

		if (SQLCODE==SQLNOTFOUND)
		{
			strcpy(s_query_num_dmg, " ") ;
			strcpy(s_trade_msg_no_dmg , " ") ;
			strcpy(s_dfirst_ply , " ") ;
			i_qdmg_point  = 0;
			i_qdmg_acc_sum= 0;
			i_qdmg_acc_sum_5y = 0;
			i_qdmg_duty_sum_5y = 0;
			i_qdmg_acc_sum_5y_pure = 0;
			i_fhave_newa_c_2y = 0;
			errCode       = M_NOTRADE_NO_DMG;
		}else
		{
			if (i_qdmg_point==-9999) {
			    i_qdmg_point  = 0;
			    i_qdmg_acc_sum= 0;
			    i_qdmg_acc_sum_5y = 0;
			    i_qdmg_duty_sum_5y = 0;
			    i_qdmg_acc_sum_5y_pure = 0;
			    i_fhave_newa_c_2y = 0;
			    errCode       = M_NOTRADE_NO_DMG;
			}
		}

	    strcpy(query_num_dmg, s_query_num_dmg) ;
	    strcpy(trade_msg_no_dmg , s_trade_msg_no_dmg) ;
	    strcpy(dfirst_ply , s_dfirst_ply) ;
	    *qdmg_point   = i_qdmg_point  ;
	    *qdmg_acc_sum = i_qdmg_acc_sum;
	    *qdmg_acc_sum_5y = i_qdmg_acc_sum_5y;
	    *qdmg_acc_sum_5y_pure = i_qdmg_acc_sum_5y_pure;
	    *fhave_newa_c_2y = i_fhave_newa_c_2y;
    }

    /* ���o ���d�ż� (�p�{��)*/
    if ((v_iacc_kind[1]!='0')&&(v_iacc_kind[1]!=' '))
    {
        sprintf_s(stmt,sizeof stmt, "SELECT iquery_num,nvl(qpoint,0.0),nvl(qacc_sum::INTEGER,-9999),imsg_no \n\
   	                 FROM ca_trade_302 \n\
   		             WHERE iassured='%s' AND itag ='%s' AND icar_kind = '%s' AND iacc_kind = '%c' \n\
   		               AND dquery IN ( \n\
   	                      SELECT max(dquery) \n\
   	                        FROM ca_trade_302 \n\
   		                    WHERE iassured  = '%s' AND itag ='%s' \n\
   		                      AND icar_kind = '%s' AND iacc_kind = '%c' \n\
   		                      AND dquery >= %ld::date ) " ,
                     v_iassured,v_itag,v_icar_kind,v_iacc_kind[1],v_iassured,
                     v_itag,v_icar_kind,v_iacc_kind[1],v_dMinQuery );

        printf("Trace -- stmt = [%s] \n",  stmt);
   	    $PREPARE preNo_trade21 FROM $stmt;
        $Execute preNo_trade21 Into
                   $s_query_num_lia,$i_lia_class,$i_qlia_acc_sum,$s_trade_msg_no_lia;

        if (SQLCODE==SQLNOTFOUND)
        {
   	        strcpy(s_query_num_lia, " ") ;
   	        strcpy(s_trade_msg_no_lia , " ") ;
   		    i_lia_class   = 0.0; /* �p�{�����d�Y�� */
   		    i_qlia_acc_sum= 0;
   		    if (errCode == M_NOTRADE_NO_DMG){
   				errCode = M_NOTRADE_NO_DMG_LIA ;
   		    }else{
   				errCode = M_NOTRADE_NO_LIA ;
   		    }
   	}
   	strcpy(query_num_lia, s_query_num_lia) ;
   	strcpy(trade_msg_no_lia , s_trade_msg_no_lia ) ;
   	*lia_class    = i_lia_class   ;
   	*qlia_acc_sum = i_qlia_acc_sum;

   	/* �t�XHCC�֫O�ҫ��p��A�p�{�����W�[������d(�@��)���e���~�߮צ��ƤΫe���~�F�d���p������
   	   (�p�{�����t�~��A�ҥH�n��@�먮�d�����) add by 061476 (1090803002_SC2) */
   	sprintf_s(stmt,sizeof stmt, "SELECT nvl(qacc_sum_5y::INTEGER,-9999),nvl(qduty_sum_5y::INTEGER,-9999) \n\
   	                 FROM ca_trade_302 \n\
   		             WHERE iassured='%s' AND itag ='%s' AND icar_kind = '%s' AND iacc_kind = '%c' \n\
   		               AND dquery IN ( \n\
   	                      SELECT max(dquery) \n\
   	                        FROM ca_trade_302 \n\
   		                    WHERE iassured  = '%s' AND itag ='%s' \n\
   		                      AND icar_kind = '%s' AND iacc_kind = '2' \n\
   		                      AND dquery >= %ld::date ) " ,
                     v_iassured,v_itag,v_icar_kind,v_iacc_kind[1],v_iassured,
                     v_itag,v_icar_kind,v_dMinQuery );

        printf("Trace -- stmt = [%s] \n",  stmt);
        $PREPARE preNo_trade31 FROM $stmt;
        $Execute preNo_trade31 Into
        $i_qlia_acc_sum_5y,$i_qlia_duty_sum_5y;

        if (SQLCODE==SQLNOTFOUND)
        {
        	i_qlia_acc_sum_5y   = 0;
        	i_qlia_duty_sum_5y  = 0;
        	if (errCode == M_NOTRADE_NO_DMG){
        		errCode = M_NOTRADE_NO_DMG_LIA ;
        	}else{
        		errCode = M_NOTRADE_NO_LIA ;
        	}
        }
        *qlia_acc_sum_5y = i_qlia_acc_sum_5y;

	*qduty_sum_5y = i_qdmg_duty_sum_5y + i_qlia_duty_sum_5y;
	*qacc_sum_5y = i_qdmg_acc_sum_5y_pure + i_qlia_acc_sum_5y;
    }

    return errCode;
errexit:
    printf("13436 get_ca_trade_taxi() sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/* ���d���T��G
�i�����I�j����G(���O=Y00)
   �j����N�O�G���N�I
   ���ءG����('01','02','32','34')

�i�k�H�L���P�j����G(���O=Y01)
   �j����N�O�G���N�I
   �����G�ť�
   ���ءG�D����

�i�k�H�����P�j����G(���O=Y02)
   �j����N�O�G���N�I
   �����G�D�ť�
   ���ءG�D����
   �����P�G�̷s�O��P��l�O��Τ@�s���ۦP�A�����P���P�A
   �B��l�O�樮�P�D�ť�
*/
long IsNOTrade302Case(FullDB,icar_type,tagnum,fassured,ipolicy,sType)
$char FullDB[31];
$char icar_type[3];
$char tagnum[CA_TAG_NUM];
$char fassured[2];
$char ipolicy[21];
$char *sType[4];
{

  $char tmp_db[3],sFull[31],stmt[1024];
  $int  iCnt;
  $WHENEVER SQLERROR GOTO errexit;
  printf("Trace -- in IsNOTrade302Case() \n");

   /* 100.06���T����,�����n�d���T */
   /*�i�q�ʦۦ樮�jY00*/
   /* 102.08 Y00 �אּ for �q�ʦۦ樮*/
   if (strncmp(icar_type,"51",2)==0){
   	   strcpy(sType,"Y00");
   	   return 1;

   }

   /*�i�k�H�L���P�jY01   */
   if ( (strlen(trim(tagnum))==0) && ((fassured[0]=='2')||(fassured[0]=='4')||(fassured[0]=='6')) )
   {
   	  strcpy(sType,"Y01");
	  return 1;
   }

   /* �i�k�H�����P�jY02 */
   /* �k�H�����P, �H�s���P�d���T...�G���q�ư� mark by sylvia 104.08.18 (1040811002_C1) */
   /* if (strlen(trim(ipolicy))>0){

   	   iCnt = 0;
	   strcpy(sFull,trim(FullDB));
       printf("sFull[%s]\n" , sFull);

	   sprintf_s(stmt,sizeof stmt,
	   "SELECT count(*) \n\
	   FROM %s:policy a,%s:ply_relation b ,%s:original_ply c \n\
	   WHERE a.ipolicy=b.ipolicy AND a.ipolicy = c.ipolicy AND a.iassured = c.iassured \n\
	     AND b.fcard_class='2' AND a.fassured IN ('2','4','6') AND b.icar_type Not in ('01','02','32','34') \n\
         AND b.fedr_class<>'1' AND nvl( b.dply_close,'')<>'' \n\
         AND nvl(a.itag,'')<>'' AND nvl(c.itag,'')<>'' AND a.itag <> c.itag \n\
         AND a.ipolicy ='%s'",
	   sFull ,sFull ,sFull, ipolicy);

	   $PREPARE preIsNo_trade FROM $stmt;
	   $Execute preIsNo_trade Into $iCnt;
	   if (iCnt>0){
	   	   strcpy(sType,"Y02");
	   	   return 1;
	   }
   } */
   strcpy(sType," ");
   return 0;

errexit:
    printf("13519 IsNOTrade302Case() sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}



/*100.06.27,�q���N���ĤG���q */
/*=======================================================================================
 �O�_�ҥγq���~�ȱ���G�ȧP�_��"�D�q��"�O�_�ҥ�
 ��g�� cmfun2s.ec =>
 long cm_get_route_auth(v_insure_type, v_iroute, v_iofficer, o_fstart, o_fauth)
=======================================================================================*/

long ca_get_route_auth(v_insure_type, v_iroute, o_fstart)
$char *v_insure_type, *v_iroute;
$char *o_fstart;
{
    $char   sIcomm_rule[1+1], sIroute[20+1], sFexpire[1+1], sFstartup[1+1];
    $char   stmt[1024];
    $int    qroute_comm;
    long    rc;

    printf("**************cm_get_route_auth()**************: \n");
    printf("Input: \n");
    printf("    v_insure_type [%s]\n", v_insure_type);  /* �X�@�j�I�O */
    printf("    v_iroute      [%s]\n", v_iroute);       /* �D�q���N�� */
   /*  printf("    v_iofficer    [%s]\n", v_iofficer);     �g��H�N�� */


    $WHENEVER SQLERROR goto ErrExit;

    strcpy(o_fstart, "N");
    qroute_comm = 0;
    rc = M_CM_OK;

    /* �X�@�j�I�O�ݬ��uC.���I M.���I F.���� B.�Ӥ� O.�s���I A.�ˮ`�I H.���d�I�v */
    if (v_insure_type[0] != 'C' &&
        v_insure_type[0] != 'M' && v_insure_type[0] != 'F' &&
        v_insure_type[0] != 'B' && v_insure_type[0] != 'O' &&
        v_insure_type[0] != 'A' && v_insure_type[0] != 'H')
    {
        rc = M_CMN_INS_ERR;
        goto ReturnRC;
    }

    /* �O�_�w�ҥγq���~�ȱ��� */
    /*
    $SELECT iroute_main
       INTO $sIroute_main
       FROM cm_route
      WHERE iroute = $v_iroute;

    if (SQLCODE == SQLNOTFOUND) rc = M_CMN_ROUTE_NOEXIST;
    */
    $SELECT (CASE WHEN dstart_comm <= TODAY THEN '1' ELSE '0' END)
       INTO $sFstartup
       FROM cm_route
      WHERE iroute = $v_iroute
        AND fmain = 'Y';

    if (SQLCODE == SQLNOTFOUND)
    {
        rc = M_CMN_ROUTE_NOEXIST;
        goto ReturnRC;
    }
    /*
    if (sFexpire[0] == '1')
    {
        rc = M_CMN_ROUTE_EXPIRE;
        goto ReturnRC;
    }*/

    if (sFstartup[0] == '1')
    {
        /* �T�{�q���~�ȱ��󦳵L�]�w */
        /* �~�ȱ��󥼳]�w�Y���ҥ� */

        /* ���X�@����W�h�N�� 1�q���M�ݱ��� 2�q���������� */
        $SELECT icomm_rule
           INTO $sIcomm_rule
           FROM cm_route_comm_rule
          WHERE iroute = $v_iroute
            AND insure_type = $v_insure_type;

        if (SQLCODE == SQLNOTFOUND)
        {
            rc = M_CMN_ROUTE_NOCOOPER;
            goto ReturnRC;
        }

        if (sIcomm_rule[0] == '1')  /* �q���M�ݱ���, �H�D�q���N��+�I�O�� */
        {
            strcpy(sIroute, v_iroute);
            printf("-------  sIcomm_rule[0] == '1' ------- \n");
        }
        else if (sIcomm_rule[0] == '2' && v_iroute[0] != 'P') /* �q���������� �DP�}�Y���q��, �H�q�������N��+�I�O�� */
        {
            strncpy(sIroute, v_iroute, 2);
            sIroute[2] = '\0';
            printf("------- sIcomm_rule[0] == '2' && v_iroute[0] != 'P' \n ------");
        }
        else if (sIcomm_rule[0] == '2' && v_iroute[0] == 'P') /* �q���������� P�}�Y���q��, �H KA+�I�O�� */
        {
            strcpy(sIroute, "KA");
            printf("------- sIcomm_rule[0] == '2' && v_iroute[0] == 'P' \n ------");
        }
        else
        {

            rc = M_CMN_ROUTE_NOCOOPER;
            goto ReturnRC;
        }

        $SELECT count(*)
           INTO $qroute_comm
           FROM cm_route_comm
          WHERE iroute = $sIroute
            AND insure_type = $v_insure_type;

        if (qroute_comm > 0)
            strcpy(o_fstart, "Y");
        else
            rc = M_CMN_ROUTE_NOCOMM;   /* �w�ҥ� �� �q���~�ȱ��󥼳]�w ==> ���ҥ� */
    }


ReturnRC:
    printf("Output: \n");
    printf("    rc            [%d]\n", rc);
    printf("    o_fstart      [%s]\n", o_fstart);
   /* printf("    o_fauth       [%s]\n", o_fauth);*/
    printf("**************cm_get_route_auth() end**************: \n");
    return rc;

ErrExit:
    printf("13654 cm_get_route_auth: sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}


/* 101.10,���o�i��O50�I�ؤ����� */
long get_ins50_car_type(iplyyear,iplymonth)
$int  iplyyear,iplymonth;
{
    $char sDplyEndBgn[11];

    $WHENEVER SQLERROR goto ErrExit;
    sprintf_s(sDplyEndBgn,sizeof sDplyEndBgn,"%d/01/%d",iplymonth,iplyyear);
    printf("trace sDplyEndBgn[%s]\n ",sDplyEndBgn);


    $SELECT distinct a.icar_type
       FROM cover_vs_premium a, ca_rate_date b
      WHERE a.drate = b.drate
        and a.iins_type='50'
        and b.itable = 'cover_vs_premium'
        and b.icode = (SELECT icode FROM ca_rate_renew
    	                               WHERE deffect_bgn <= $sDplyEndBgn
    	                                 AND deffect_end >= $sDplyEndBgn
    	                                 AND fcard_class = '2')
       INTO temp tmp_ins50_cartype WITH NO log;
    if (SQLCODE == SQLNOTFOUND){
    	printf("get_ins50_car_type()iplyyear=[%d],iplymonth=[%d] ,\n",iplyyear,iplymonth);
    	return SQLCODE;
    }else{
        return M_CM_OK;
    }

ErrExit:
    printf("13686 get_ins50_car_type() sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* 102.12.25 ���� "AND a.iofficer[1] <> 'W'"  ����*/
/* 12.18, �אּ�u�H���޲z�H */
/*101.12,�^���Ӧ~����O���ګO��B���`��  */
long prepare_reject_client_ply(iplyyear,iplymonth,intopt)
$int iplyyear,iplymonth,intopt;
{
     long  lngMsg ;
     $char ipolicy[21],itag[CA_TAG_NUM],iengine[CA_ENGINE_NUM], ilicense[13],  nassured[121], icar_type[3], dply_begin[11];
     $char freason[2] , nreason[41] , nquota[41],iofficer[11],nofficer[11],ileader[11], nleader[11];
     $char iroute[21],nroute[41], abn_type[2],fRenew[2], remark_reject[255] ;
     $char stmt[3572],s_dupdate[21],icreate[11],str[101], fcard_class[2], irelative_ply[21];
     $int  t_count = 0, rc_count = 0;
     $char sFirstDay[11],sLastDay[11],sIbig_sales[11],sNsales[41];
     $int  ifuw_status_ori;

     $WHENEVER ERROR CONTINUE;
     $DROP TABLE tmp_itag_reject;
     $DROP TABLE tmp_iengine_reject;
     $DROP TABLE tmp_ilicense_reject;
     $DROP TABLE tmp_reject_client_ply;
     $WHENEVER SQLERROR GOTO errexit;

     $SELECT itag,freason,remark,dexpire,icreate,dupdate FROM reject_client
       WHERE nvl(itag,' ')<>' ' AND nvl(itag,'*')<>'*'
        INTO temp tmp_itag_reject WITH NO log;

     $SELECT iengine,freason,remark,dexpire,icreate,dupdate FROM reject_client
       WHERE nvl(iengine,' ')<>' ' AND nvl(iengine,'*')<>'*'
        INTO temp tmp_iengine_reject WITH NO log;

     $SELECT ilicense,freason,remark,dexpire,icreate,dupdate,itag,iengine FROM reject_client
       WHERE nvl(ilicense,' ')<>' ' AND nvl(ilicense,'*')<>'*'
        INTO temp tmp_ilicense_reject WITH NO log;

     if((intopt==9)||( intopt == 25 )||(intopt == 55))
     {
      	  strcpy(str," And a.ipolicy in (select ipolicy from newa00:ca_tmp_no) ") ;
     }
     else
     {
      	  strcpy(str," And a.option <> 55 ") ;  /* ���t���ثO�g(8-11��) add by sylvia 105.05.19 (1050504009_C1) */
     }

     sprintf_s(stmt,sizeof stmt, "SELECT '%02d/01/%d'::date,LAST_DAY('%02d/01/%d'::date) FROM systables WHERE tabid=1",
                   iplymonth,iplyyear,iplymonth,iplyyear);
     $PREPARE preLastDay FROM $stmt;
     $EXECUTE preLastDay INTO $sFirstDay,$sLastDay;
     printf("trace sFirstDay[%s]\n ",sFirstDay);
     printf("trace sLastDay[%s]\n " ,sLastDay);
     /*  --------------------------------------------------------------------------------------   */

     /* �ư��M�ץ�(W*��N*�g�쪺�O��)   modify by sylvia 104.06.26 (1040623003_C1) */
     /* �s�W �֫O���A=40 ���O�欰�ګO���, ���L�s�n�O��,�u���s�j���I�q����   modify by sylvia 104.06.26 (1040623003_C1) */
     /* �s�W �֫O���A=41 ���O�欰�ګO���, ���L�s�n�O��,�u���s�j���I�q����   modify by sylvia 104.11.27 (1021211003_C1) */
     /* �t�XRBA�����I�ˮ֭ץ� modify by sylvia 106.08.15 (1060606002_C5)
        (1) �Ҧ��O��(�t�j��B���N�B�M�ץ�)���n�B�Q�O�I�H���n�i���ˮ�
        (2) ��j�O��(�L���p�������p�O�椣�b�P�@����~��) �ˮ֭Y��1�B7�B9���O���J�p,��L���O�n�J�p,������ĳ���N�I��(47,50,149)*/

      sprintf_s(stmt,sizeof stmt, "SELECT \n\
                          a.fcard_class, a.irelative_ply, a.ipolicy, nvl(a.itag,' ') AS itag, a.iengine, a.ilicense, a.nassured, a.icar_type, a.dply_begin, \n\
                          e.nbranch as nquota, d.ileader, d.nname AS nleader, a.iofficer, c.nname AS nofficer, a.iroute, b.nroute, \n\
                          a.iabn_type , \n\
                          CAST(' '      AS CHAR(2)) freason        , CAST(' '      AS CHAR(40)) nreason, \n\
                          CAST(' '      AS CHAR(254)) remark_reject, CAST(' '      AS CHAR(2)) fRenew, \n\
                          decode(a.iofficer[1,1],'J',ibig_sales,'B',ibig_sales,' ') as ibig_sales,  \n\
                          case when a.iofficer[1,1] in ('B','J') then \n\
                               nvl((select nname from ca_big_office where fclass = '2' and ibig_comp = a.ibig_sales),' ') else ' ' end  as nsales, \n\
                          a.fuw_status_ori \n\
                     FROM policy_302 a, cm_route b , officer c, officer d , sa_branch_type e \n\
                    WHERE a.iofficer = c.iofficer AND a.ileader = d.iofficer  AND a.iroute = b.iroute AND a.iquota = e.ibranch \n\
                      AND a.dply_begin between '%s' AND '%s' \n\
                      AND a.fassured IN ('1','3','5')  \n\
                      AND (a.ilicense IN (SELECT ilicense FROM tmp_ilicense_reject) \n\
                           OR a.itag IN  (SELECT itag FROM tmp_itag_reject ) \n\
                           OR a.iengine IN  (SELECT iengine FROM tmp_iengine_reject) \n\
                           OR a.iabn_type ='Y' OR a.fuw_status_ori in ('40','41')) %s \n\
                     UNION \n\
                     SELECT \n\
                          a.fcard_class, a.irelative_ply, a.ipolicy, nvl(a.itag,' ') AS itag, a.iengine, a.ilicense, a.nassured, a.icar_type, a.dply_begin, \n\
                          e.nbranch as nquota, d.ileader, d.nname AS nleader, a.iofficer, c.nname AS nofficer, a.iroute, b.nroute, \n\
                          a.iabn_type , \n\
                          CAST(' '      AS CHAR(2)) freason        , CAST(' '      AS CHAR(40)) nreason, \n\
                          CAST(' '      AS CHAR(254)) remark_reject, CAST(' '      AS CHAR(2)) fRenew, \n\
                          decode(a.iofficer[1,1],'J',ibig_sales,'B',ibig_sales,' ') as ibig_sales,  \n\
                          case when a.iofficer[1,1] in ('B','J') then \n\
                               nvl((select nname from ca_big_office where fclass = '2' and ibig_comp = a.ibig_sales),' ') else ' ' end as nsales, \n\
                          a.fuw_status_ori \n\
                     FROM policy_302 a, cm_route b , officer c, officer d , sa_branch_type e \n\
                    WHERE a.iofficer = c.iofficer AND a.ileader = d.iofficer  AND a.iroute = b.iroute AND a.iquota = e.ibranch \n\
                      AND a.dply_begin between '%s' AND '%s' \n\
                      AND a.fassured IN ('2','4','6') \n\
                      AND (a.ilicense IN (SELECT ilicense FROM tmp_ilicense_reject \n\
                    WHERE (nvl(itag,' ')=' ' or itag = '*') \n\
                      AND (nvl(iengine,' ')=' ' or iengine = '*') ) \n\
                          OR a.itag IN  (SELECT itag FROM tmp_itag_reject ) \n\
                          OR a.iengine IN  (SELECT iengine FROM tmp_iengine_reject) \n\
                          OR a.iabn_type ='Y' OR a.fuw_status_ori in ('40','41')) %s \n\
                     INTO temp tmp_reject_client_ply WITH NO log " ,
                    sFirstDay,sLastDay,str,sFirstDay,sLastDay,str);

      $PREPARE preRejectClient FROM $stmt;
      $Execute preRejectClient;

      sprintf_s(stmt,sizeof stmt, "insert into tmp_reject_client_ply \n\
                     SELECT a.fcard_class, a.irelative_ply, a.ipolicy, nvl(a.itag,' ') AS itag, a.iengine, a.iapplicant, a.nassured, a.icar_type, a.dply_begin, \n\
                            e.nbranch as nquota, d.ileader, d.nname AS nleader, a.iofficer, c.nname AS nofficer, a.iroute, b.nroute, \n\
                            a.iabn_type , \n\
                            CAST(' '      AS CHAR(2)) freason        , CAST(' '      AS CHAR(40)) nreason, \n\
                            CAST(' '      AS CHAR(254)) remark_reject, CAST(' '      AS CHAR(2)) fRenew, \n\
                            decode(a.iofficer[1,1],'J',ibig_sales,'B',ibig_sales,' ') as ibig_sales,  \n\
                            case when a.iofficer[1,1] in ('B','J') then \n\
                                 nvl((select nname from ca_big_office where fclass = '2' and ibig_comp = a.ibig_sales),' ') else ' ' end  as nsales, \n\
                            a.fuw_status_ori \n\
                       FROM policy_302 a, cm_route b , officer c, officer d , sa_branch_type e \n\
                      WHERE a.iofficer = c.iofficer AND a.ileader = d.iofficer  AND a.iroute = b.iroute AND a.iquota = e.ibranch \n\
                        AND a.dply_begin between '%s' AND '%s' \n\
                        AND a.fapplicant IN ('1','3','5')  \n\
                        AND a.iapplicant IN (SELECT ilicense FROM tmp_ilicense_reject) %s; ",sFirstDay,sLastDay,str);

     $PREPARE preRejectClient1 FROM $stmt;
	 $Execute preRejectClient1;

     sprintf_s(stmt,sizeof stmt, "insert into tmp_reject_client_ply \n\
                    select  a.fcard_class, a.irelative_ply, a.ipolicy, nvl(a.itag,' ') AS itag, a.iengine, a.iapplicant, a.nassured, a.icar_type, a.dply_begin, \n\
                            e.nbranch as nquota, d.ileader, d.nname AS nleader, a.iofficer, c.nname AS nofficer, a.iroute, b.nroute, \n\
                            a.iabn_type , \n\
                            CAST(' '      AS CHAR(2)) freason        , CAST(' '      AS CHAR(40)) nreason, \n\
                            CAST(' '      AS CHAR(254)) remark_reject, CAST(' '      AS CHAR(2)) fRenew, \n\
                            decode(a.iofficer[1,1],'J',ibig_sales,'B',ibig_sales,' ') as ibig_sales,  \n\
                            case when a.iofficer[1,1] in ('B','J') then \n\
                                 nvl((select nname from ca_big_office where fclass = '2' and ibig_comp = a.ibig_sales),' ') else ' ' end as nsales, \n\
                            a.fuw_status_ori \n\
                       FROM policy_302 a, cm_route b , officer c, officer d , sa_branch_type e \n\
                      WHERE a.iofficer = c.iofficer AND a.ileader = d.iofficer  AND a.iroute = b.iroute AND a.iquota = e.ibranch \n\
                        AND a.dply_begin between '%s' AND '%s' \n\
                        AND a.fapplicant IN ('2','4','6') \n\
                        AND a.iapplicant IN (SELECT ilicense FROM tmp_ilicense_reject \n\
                                              WHERE (nvl(itag,' ')=' ' or itag = '*') \n\
                                                AND (nvl(iengine,' ')=' ' or iengine = '*')) %s " ,sFirstDay,sLastDay,str);

     $PREPARE preRejectClient2 FROM $stmt;
     $Execute preRejectClient2;

     $CREATE INDEX idx_tmp_rc1 ON  tmp_reject_client_ply(ipolicy);
     $CREATE INDEX idx_tmp_rc2 ON  tmp_reject_client_ply(ileader);
     $CREATE INDEX idx_tmp_rc3 ON  tmp_reject_client_ply(fcard_class);

     rc_count = 0;

     sprintf_s(stmt,sizeof stmt," SELECT * FROM tmp_reject_client_ply " );

     $PREPARE  pre_stmt FROM $stmt;
     $DECLARE  cur_reject CURSOR FOR pre_stmt;
     $OPEN     cur_reject ;
     while (1)
     {
         $FETCH cur_reject
           INTO $fcard_class, $irelative_ply, $ipolicy, $itag,    $iengine, $ilicense,  $nassured, $icar_type, $dply_begin,
                $nquota,  $ileader, $nleader, $iofficer, $nofficer, $iroute,    $nroute , $abn_type,
                $freason, $nreason, $remark_reject, $fRenew, $sIbig_sales, $sNsales, $ifuw_status_ori;
         if(SQLCODE == SQLNOTFOUND) break;

      	 t_count = 0; strcpy(freason," ");
      	 strcpy(remark_reject ," ");   strcpy(s_dupdate ," ");  strcpy(icreate ," ");

         $SELECT FIRST 1 freason,remark,dupdate,icreate,count(itag)
            Into $freason,$remark_reject,$s_dupdate,$icreate,$t_count
            FROM tmp_itag_reject
           WHERE itag = $itag
             AND (dexpire IS NULL Or dexpire > $dply_begin) GROUP BY 1,2,3,4 ORDER BY dupdate DESC;

         if( t_count==0)
         {
             t_count = 0; strcpy(freason," ");
             strcpy(remark_reject ," ");   strcpy(s_dupdate ," ");  strcpy(icreate ," ");

             $SELECT FIRST 1 freason,remark,dupdate,icreate,count(iengine)
                Into $freason,$remark_reject,$s_dupdate,$icreate,$t_count
                FROM tmp_iengine_reject
               WHERE iengine = $iengine
                 AND (dexpire IS NULL Or dexpire > $dply_begin) GROUP BY 1,2,3,4 ORDER BY dupdate DESC;

             if( t_count==0)
             {
                 t_count = 0; strcpy(freason," ");
                 strcpy(remark_reject ," ");   strcpy(s_dupdate ," ");  strcpy(icreate ," ");

                 $SELECT FIRST 1 freason,remark,dupdate,icreate,count(ilicense)
                    Into $freason,$remark_reject,$s_dupdate,$icreate,$t_count
                    FROM tmp_ilicense_reject
                   WHERE ilicense = $ilicense
                     AND (dexpire IS NULL Or dexpire > $dply_begin) GROUP BY 1,2,3,4 ORDER BY dupdate DESC;

                 if( t_count==0)
                 {
                     if (abn_type[0]!='Y')
                     {
                         /* �֫O���A=40  add by sylvia 104.06.26 (1040623003_C1) */
                         if (ifuw_status_ori == 40)
                         {
                             strcpy(freason,"Z");
                             strcpy(remark_reject ,"������/�]��/�j�������ӫO�����I/�j����/�S���t���A�Э��s�f�ֳ���");
                         }
                         else if (ifuw_status_ori == 41)
                         {
                             strcpy(freason,"Z");
                             strcpy(remark_reject ,"�O�B�W�L�{�����B");
                         }
                         else
                         {
                             /* ���O�ګO�� ,���O���`�� */
                             $DELETE FROM tmp_reject_client_ply WHERE ipolicy = $ipolicy;
              	             continue;
              	         }
                     }
                     else
                     {
                         /* ���O�ګO�� , �O���`�� */
                         strcpy(freason,"Y");
                         strcpy(remark_reject ,"�O�O���`");
                     }
                 } /* ilicense */
             }/* iengine */
         }/* itag */

         strcpy(fRenew," ");  /* �O�_���s��O�� */
         switch (freason[0])
         {
               case '1':
               	          if (strncmp(icreate,"car5083",7)==0)
               	          {
          	              freason[0] = 'P'; strcpy(fRenew,"N");
          	              sprintf_s(nreason,sizeof nreason,"%s","�r�p�ߺD�ά������}�Ȥ�");
                          }
                          else
                          {
                              if (abn_type[0]=='Y' )
                              {
		                  strcpy(freason,"Y");
		                  strcpy(remark_reject ,"�O�O���`");
                          	  sprintf_s(nreason,sizeof nreason,"%s","���`��"); strcpy(fRenew,"N");
                              }
                              else
                              {
                          	  strcpy(fRenew,"Y");
                          	  sprintf_s(nreason,sizeof nreason,"%s","�r�p�ߺD�ά������}�Ȥ�");
                              }
                          }
               	          break;

               case '2':  sprintf_s(nreason,sizeof nreason,"%s","���Ѩ�");
               case '3':  sprintf_s(nreason,sizeof nreason,"%s","���l��");
               case '4':  sprintf_s(nreason,sizeof nreason,"%s","�w����");
               case '5':  sprintf_s(nreason,sizeof nreason,"%s","�z�ߴ���");
               case '6':  sprintf_s(nreason,sizeof nreason,"%s","�ƬG���O");
                      	  if (abn_type[0]=='Y' )
                      	  { /* case 2 ~ 6 �p�G�P�ɬ����`��A�h�������`�� */
	                       strcpy(freason,"Y");
	                       strcpy(remark_reject ,"�O�O���`");
                      	       sprintf_s(nreason,sizeof nreason,"%s","���`��"); strcpy(fRenew,"N");
                      	  }
                      	  else
                      	  {
                      	       strcpy(fRenew,"Y");
                      	  }
                          break;
               case '7':  sprintf_s(nreason,sizeof nreason,"%s","�æ��D�w���I�Ȥ�");
                          strcpy(fRenew,"N");
                          break;

               case '8':  sprintf_s(nreason,sizeof nreason,"%s","�Ȥ�S�O�T��");  /* 102.06.28 */
          	   	  strcpy(fRenew,"Y");
          	   	  break;

               case '9':  sprintf_s(nreason,sizeof nreason,"%s","�֫O���O");    /* 102.08.12 */
          	   	  strcpy(fRenew,"N");    /* modify by sylvia Y--> N , (�ӻ��T�{)1030407  */
          	   	  break;

               case 'B':  sprintf_s(nreason,sizeof nreason,"%s","����W��H��");  /* 107.11.23 (1071029004_SC3) */
          	   	  strcpy(fRenew,"N");
          	   	  break;

               case 'Y':  sprintf_s(nreason,sizeof nreason,"%s","���`��");
          	   	  strcpy(fRenew,"N");
          	   	  break;

               case 'Z':
               	          if (ifuw_status_ori == 40)
               	          {
               	          	sprintf_s(nreason,sizeof nreason,"%s","������/�]����O�����I"); /* add by sylvia 104.06.26 (1040623003_C1) */
               	          	strcpy(fRenew,"N");
               	          }
               	          else if (ifuw_status_ori == 41)
               	          {
               	          	sprintf_s(nreason,sizeof nreason,"%s","�O�B�W�L�{�����B"); /* add by 061476 108.11.11 (1081029003_SC1) */
               	          	strcpy(fRenew,"N");
               	          }

          	   	  break;

               default:   sprintf_s(nreason,sizeof nreason,"%s","(���w�q)"); strcpy(remark_reject ," ");
               	          break;
         }

         printf("����15302:ipolicy=[%s]fRenew=[%s]freason=[%s]nreason=[%s]remark_reject=[%s]",
                 ipolicy, fRenew, freason, nreason, remark_reject);

  	 $UPDATE tmp_reject_client_ply
	     SET freason = $freason , nreason=$nreason , remark_reject = $remark_reject , fRenew= $fRenew
	   WHERE ipolicy = $ipolicy ;

	 rc_count++;
     }
     $CLOSE cur_reject;
     $FREE  cur_reject;


     /* �N���D��(car_renew_msg) �g�J�ګO��  add by sylvia 104.07.09 (1040106005_C1) */
     t_count = 0;
     $select count(ipolicy) into $t_count
        from sysdb:car_renew_msg
       where dply_end between $sFirstDay and $sLastDay
         and ipolicy[3] in ('0','1','2','5','6','7')
         and err_no in (select detail2 from car_code where kind = 'RN'
                           and detail = 'Mail_To_Leader' and engname = 'Y');
     if (t_count > 0)
     {
         $insert into tmp_reject_client_ply
          select (select fcard_class from ply_relation_last where ipolicy = a.ipolicy) ,
                 (select irelative_ply from ply_relation_last where ipolicy = a.ipolicy),
                 ipolicy, itag, iengine, iassured,
                 nassured, icar_type, dply_end, nquota, ileader, nleader, iofficer,
                 nofficer, iroute, nroute, iabn_type, freason, nreason,
                 remark_reject, frenew, ibig_sales, nsales, '0'
            from sysdb:car_renew_msg a
           where dply_end between $sFirstDay and $sLastDay
             and ipolicy[3] in ('0','1','2','5','6','7')
             and err_no in (select detail2 from car_code where kind = 'RN'
                              and detail = 'Mail_To_Leader' and engname = 'Y');
         rc_count = rc_count+t_count;
     }

     if (rc_count == 0){
    	lngMsg = -1 ; /* �Ө���~��L����ګO��B���`�� */
     }else{
    	lngMsg = M_CM_OK;
     }

     return lngMsg;
errexit:
   printf("13939 prepare_reject_client_ply sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   return SQLCODE;

}


long do_car_code(fDoWhat,s_kind, s_detail, s_detail2, s_chiname, s_engname, ikey_num,sUserid)
$char  fDoWhat, s_kind[2], s_detail[20], s_detail2[20], s_chiname[40], s_engname[40], sUserid[11];
$int   ikey_num;
{
	$char stmt[1024];
	$int  rtValue;

	$WHENEVER SQLERROR GOTO errexit;
	rtValue = -1 ;
    switch (fDoWhat){
     	case 'A': /* �s�W */
			sprintf_s(stmt,sizeof stmt,
			        "INSERT Into car_code Values ('%s','%s','%s','%s','%s',0,'%s',current,'%s',current)",
			        s_kind, s_detail , s_detail2,s_chiname,s_engname,sUserid,sUserid);

	        $PREPARE pre_keyA FROM $stmt;
	        $EXECUTE pre_keyA;
	        if (sqlca.sqlerrd[2] > 0) rtValue = 1;
      	    break;

       case 'U': /* �ק�, key ���i�ק� */
       	    if (ikey_num==3){
				sprintf_s(stmt,sizeof stmt,
				        "UPDATE car_code Set chiname = '%s',engname = '%s',iupdate='%s',dupdate = current \
				          WHERE kind = '%s' AND detail = '%s' AND detail2 = '%s'",
				         s_chiname,s_engname, sUserid, s_kind, s_detail , s_detail2);
			}else if (ikey_num==2){
				sprintf_s(stmt,sizeof stmt,
				        "UPDATE car_code  Set detail2 = '%s', chiname = '%s',engname = '%s', iupdate = '%s', dupdate = current \
				          WHERE kind = '%s' AND detail = '%s'",
				         s_detail2, s_chiname,s_engname, sUserid, s_kind, s_detail );
		    }
		    printf("stmt=[%s]\n",stmt);
	        $PREPARE pre_keyU FROM $stmt;
	        $EXECUTE pre_keyU;
	        if (sqlca.sqlerrd[2] > 0) rtValue = 1;
     	    break;

     	case 'D': /* �R�� */

       	    if (ikey_num==3){
				sprintf_s(stmt,sizeof stmt,
				        "DELETE FROM car_code  \
				          WHERE kind = '%s' AND detail = '%s' AND detail2 = '%s'",
				        s_kind, s_detail , s_detail2);
			}else if (ikey_num==2){
				sprintf_s(stmt,sizeof stmt,
				        "DELETE FROM car_code  \
				          WHERE kind = '%s' AND detail = '%s'",
				        s_kind, s_detail);
		    }
	        $PREPARE pre_keyD FROM $stmt;
	        $EXECUTE pre_keyD;
	        if (sqlca.sqlerrd[2] > 0) rtValue = 1;
     	    break;

     	case 'Q': /* �d��(�O�_���ӳ]�w) */
     		/* rtValue :  1  �����,�B�ܤ֤@���ŦX�d�߱���
     		   rtValue :  0  �����,���L�ŦX�d�߱��󤧸��
     		   rtValue : -1  �Ӭd�߱���d�L���*/
       	    if (ikey_num==4){  /* ex.  �icheck �]�w��chiname �O�_�� 'Y' or 'N'*/
				sprintf_s(stmt,sizeof stmt,
				        "SELECT Count(*) FROM car_code  \
				          WHERE kind = '%s' AND detail = '%s' AND detail2 = '%s' AND chiname ='%s'",
				        s_kind, s_detail ,s_detail2,s_chiname);
       	    }else if (ikey_num==3){
				sprintf_s(stmt,sizeof stmt,
				        "SELECT Count(*) FROM car_code  \
				          WHERE kind = '%s' AND detail = '%s' AND detail2 = '%s'",
				        s_kind, s_detail , s_detail2);
			}else if (ikey_num==2){
				sprintf_s(stmt,sizeof stmt,
				        "SELECT Count(*) FROM car_code  \
				          WHERE kind = '%s' AND detail = '%s'",
				        s_kind, s_detail);
			}else if (ikey_num==1){
				sprintf_s(stmt,sizeof stmt,
				        "SELECT Count(*) FROM car_code  \
				          WHERE kind = '%s' ", s_kind );
		    }
	        $PREPARE pre_keyQ FROM $stmt;
	        $EXECUTE pre_keyQ Into $rtValue;
	        if (rtValue > 0) {
	        	rtValue = 1;
	        }else if (rtValue <= 0) {
	        	rtValue = -1;
	        }
     	    break;
    }
    return rtValue;


errexit:
   printf("14057 sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}


/* �f�֥N�X�]�w��G car_code kind = 'RN' , detail = 'car302_check'
--  ---------------------------------------------------------------------------------------------------------------
�f��
�N�X                                           �f�ֶ���
--  ---------------------------------------------------------------------------------------------------------------
                                          �i���O�κޱ��~�ȥ�j
--  ---------------------------------------------------------------------------------------------------------------
 10     31�B231�B133�B149�B249�I�بƬG�O�B>12000�U (1��2)
 20     �]�w��car102���ګO�Ȥ��
       �u�ګO���O1�B�P�@�O��X�I�T���v�Ρu�ګO���O7�v���H�o��O�q���ѡA��l���O�|�H�o��O�q���ѡA�����Lú�ڳ�
 30     �D�s���ΥB�D�ʤO���񨮡A�Ө������ťժ�
        �s���G�����o�Ӧ~��� ����O��ͮĦ~��F�ʤO���񨮡G27����
 40     (1) �Q�O�I�T���ӫO���l�I
        (2) �ӫO���l�I�A�O�B�j��600�U
        (3) 32���ئ��ӫO55.49.117.255�ɡA�Y���~�צ����d�X�I�F�d1��4
 41	(1) ���d�I(RIN113���k��31�P51���O���I��) �X�p�O�B > 20000�U (2��)
        (2) 52�B53�B55�B57�B59�B60�B135�B255���@�I�ؤ� ��˫O�B>1000�U �B �ƬG�O�B>8000�U
        (3) �ŦX�������[�O�Y��
 70	��t�����ӫO�N�ӫO�����X�j������l���I(85�I��)
        ��t�����ӫO�N�G���g��N����cmn108�]�w���u�~�Ȩӷ��v���G�u1  ��t�����ӫO�N�v
100	��O�U�C�I�ؤ��@�̡G
           57(�C�����ȹB�~���ȳd���O�I)
           59(�����T���ȹB�~���ȳd���O�I)
           60(���ϨT���ȹB�~���ȳd���O�I)
110	�Ȥᨭ���O���~�̡C�Q�O�I�H�ʽ�(fassured)�G 4(��~�k�HID���~)�B5(�ꤺ�۵M�HID���~)�B6(�ꤺ�k�HID���~)

140     ���H�U���[���ڪ̡G D�BF�BB�BG�BJ�BR�BX�B32����+L�BT���ڥB�L�k���o�[��O�T�ת�
170     (1) �����}�M�B���Ȱ�گ���B��W�T���B�p������B�Τ@�F�ʯ���B�p����گ���B��s�T���B�ڤO�h�T���B�鲱����q�B�w�����T��
        (2) ��L����(PA*,�ư��W�z����~)�A�B���������ιq�ʦۦ樮
        �H�W������H�o��O�q���ѡA�C�~��O���O���Ӵ��Ѩ������s�w���s�����A�G���g�J�w���@�γ����ɤδC��ú����

180     �D���Ӫ�07�B15���ءA�B���bcar140-RN��CHK_NO_180�A�e�榳���d�Ψ���F�d��1(���F�d,�O��)���߮�
        �������p���O�欰14�B21�B08���ءA�@����180
--  ---------------------------------------------------------------------------------------------------------------
	                                 �i���l�I��O�զX����j
--  ---------------------------------------------------------------------------------------------------------------
200	���O�զX�L����B�ѵs�I�A����ĳ��O�զX������B�ѵs�I��
210	���O�զX������B�ѵs�I�A����ĳ��O�զX����B�ѵs�I���ۭt�B�O�B�����ʪ�
            (1)�P�_��O�p���G�I�ة����ɦ��L���l�I(�����I���ѵs�I)�A
                �Y�L�A�h�f�ֳq�L(���O�B��ĳ��O�զX���f�֪��A�X�G500)�A
                �Y���A�A�P�_�u���L�󴫨����I�v(�h�~09 -> �אּ��ĳ05)
                    �Y���󴫡A�h�f�֤��q�L(�f�֪��A�X�G210)
                    �Y�S�󴫡A�A�P�_�Ө��l����B��ĳ��O�զX���e���L�ۦP�A
                        �Y�ۦP  �A�h�f�ֳq�L(�f�֪��A�X�G500)�A
                        �Y���ۦP�A�h�G
                            �Y�L���O�զX�h��ĳ��O�զX�f�֤��q�L(��ĳ��O�� �X�f�֪��A�X�G150)
                            �Y�����O�զX�h��ĳ��O�զX�f�֤��q�L(��ĳ��O�զX�f�֪��A�X�G150)
            (2)�����I�G01�B05�B08�B09�B85�B98�B105�I��
            (3)�ѵs�I�G11�B18�B86�I��
*/

/* 102.03 �i�t�μf�֡j1~14 ���A��2�B13�����~*/
/* �@�i��O��A����O�զX�B��ĳ��O�զX �i��|�����P��"�f�֤��q�L��]"�A
   �����ެO�ƻ�f�֤��q�L��]�A�D�n�O���F�P�_�O�_�L�s�ӧ�O�զXú�ڳ�    */

/* 102.09.06
  �w�郞�ج��ۥΤp�Ȩ�(03)�B�ۥΤp�ȳf��(22)�B��������p�Ȩ�(21)�B�ۥΤp�f��(04)�B���q�渹�ۥΤp�f��(19) �̡A
  �Y����O�榳�ӫO�u�A������l���I�v�̡G
      1.��O�q���ѤW�@�ߤ����[ú�ڳ�A�Y�ϸӥ�q�L�t�μf�֥�M�C
      2.�Y��car147�]�w���Ȧ�q��barcode��A�h���L�sbarcode�n�O�ѡA�u�L�s
          �j���I�q�������O�n�O��(2p)(�Ȧ�q����car147�W�Ҧ��]�w�n�[�L2p��
         �O�n�O��)�C

  ���ŦX�W�z���Ϊ̡A�Y�G
  (1)���q�L�t�μf�̡֪A�f�֪��A�X�N��500�אּ505�C
  (2)���q�L�t�μf�̡֪A�f�֪��A�X���ܰʡC

*/

long check_policy(
  struct INS_TYPE *INS_ptr,
  char *ipolicy,
  char *ibrand,
  char *icar_type,
  char *itag,
  char *iofficer,
  char *iroute,
  char *ilicense,
  char *fassured,
  char *s_dissue,
  char *s_dply_begin_pre,
  char *frate2,
  int  *ins1589_chg_flag,
  int  *rt_uw_status_ori,
  int  *rt_uw_status_sug  )
{
    char  tmp_yy1[4],tmp_mm1[3],tmp_dd1[3];
    char  tmp_yy2[4],tmp_mm2[3],tmp_dd2[3];
    $char tmp_iins[7],tmp_provision[22];
    int   rc,rt_uw_ori,rt_uw_sug,rt_uw_ori_in,rt_uw_sug_in,f_ins1589_chg_flag;
    $int  tmp_count = 0;
    $char v_iofficer[11],v_ibrand[9],v_frate2[4],v_ipolicy[21],v_iroute[21];
    $long ri_sum_chk_ori = 0,ri_sum_chk_sug = 0;
    int   chk98_sug;     /* �O�_����ĳ98�I��,�B�O�B��5�U��10�U 0:�L 1:��  add by sylvia (1040317005_C1) */
    int   chk11_sug;     /* �O�_����ĳ11�I��  0:�L 1:��  add by sylvia (1040317005_C1) */
    $int  cnt_sports;    /* �]�� */
    $int  cnt_acc;       /* ����+���d�X�I���� */
    $long mcar_price_h4; /* �S���ԭ��m���� */
    $char sFullDB[21], stmt[258];

    $WHENEVER SQLERROR GOTO errexit;

    printf("trace ipolicy[%s]\n ",ipolicy);
    printf("trace ibrand[%s]\n ",ibrand);
    printf("trace icar_type[%s]\n ",icar_type);

    printf("trace *rt_uw_status_ori[%d]\n ",*rt_uw_status_ori);
    printf("trace *rt_uw_status_sug[%d]\n ",*rt_uw_status_sug);

    rt_uw_ori_in = *rt_uw_status_ori ;  /* �bcheck_policy ()���e���ˮ֪��A */
    rt_uw_sug_in = *rt_uw_status_sug ;
    f_ins1589_chg_flag = *ins1589_chg_flag;

    rt_uw_ori = -1 ; /* �bcheck_policy () ���|���f��*/
    rt_uw_sug = -1 ;

    if ((rt_uw_ori_in!=-1)&&(rt_uw_sug_in!=-1)){ /* �G��O�զX�����μf�F */
    	rt_uw_ori = rt_uw_ori_in ;
	rt_uw_sug = rt_uw_sug_in ;
	goto UW_RESULT  ;
    }
    if (rt_uw_ori_in!=-1){                       /* ���O�զX�����μf�F */
	rt_uw_ori = rt_uw_ori_in ;
    }
    if (rt_uw_sug_in!=-1){                       /* ��ĳ��O�զX�����μf�F */
	rt_uw_sug = rt_uw_sug_in ;
    }

    /*--------------------------------	�i���O�κޱ��~�ȥ�j-----------------------------------------*/

    /* -------------------------- ���A�B���I�صL�����ˮ� -------------------------*/

    /* [�ˮֶ���]�G 11.�Ȥᨭ���O���~�̡A4(��~�k�HID���~), 5(�ꤺ�۵M�HID���~), 6(�ꤺ�k�HID���~)]	 */
    if ((fassured[0] == '4') || (fassured[0] == '5') || (fassured[0] == '6'))
    {
        if (rt_uw_ori == -1) rt_uw_ori = 110 ;
	if (rt_uw_sug == -1) rt_uw_sug = 110 ;
	goto UW_RESULT  ;
    }

    /* [�ˮֶ���]�G 3.�D�s���ΥB�D�ʤO���񨮡A�Ө������ťժ�  */
    if (strlen(trim(itag)) ==0)
    {    /* �������ť� */
        if (strncmp(icar_type,"27",2) != 0 && strncmp(icar_type,"CS",2) != 0)
        {   /* �D�ʤO���� */
	    cm_split_ymd_100(s_dply_begin_pre, tmp_yy1,tmp_mm1,tmp_dd1);
	    cm_split_ymd_100(s_dissue        , tmp_yy2,tmp_mm2,tmp_dd2);
	    if ((atoi(tmp_yy1)!=atoi(tmp_yy2)) && (atoi(tmp_mm1)!=atoi(tmp_mm2)))
	    {
	        if (rt_uw_ori == -1) rt_uw_ori = 30 ;
		if (rt_uw_sug == -1) rt_uw_sug = 30 ;
		goto UW_RESULT	;
	    }
	}
    }


    /* [�ˮֶ���]�G 17.�����}�M�B���Ȱ�گ���B��W�T���B�p���p�Ȩ�����B
                       �Τ@�F�ʯ���B�p����گ���B��s�T���B�ڤO�h�T���B
                       �鲱����q�B�w�����T���B��ù�T��	*/
    if ( (ISCHAILEASE(iroute)) || (ISFEI(iroute)) ||(ISGOSUN(iofficer,iroute)) || (ISPONYRENT(iofficer,iroute)) ||
         (ISTOKYO(iofficer,ilicense)) || (ISUFLC(iroute)) || (ISSHING(iroute)) || (ISORIX(iroute)) ||
         (ISJIHSUN(iroute)) || (ISAVIS(iroute)) || (ISPRO(iroute)) )
    {
        if (rt_uw_ori == -1) rt_uw_ori = 170 ;
	if (rt_uw_sug == -1) rt_uw_sug = 170 ;
 	goto UW_RESULT ;
    }

    /* �s�W:��L����(PA* �ư��즳����~),�B���������ιq�ʦۦ樮 add by sylvia 104.01.22 (1040114003_C1) */
    if ((chk_PA > 0) && ((strncmp(iroute,"PA",2) == 0) && (!(ISMOT(icar_type))) && (strcmp(icar_type,"51") != 0)))
    {
    	if (rt_uw_ori == -1) rt_uw_ori = 170 ;
    	if (rt_uw_sug == -1) rt_uw_sug = 170 ;
    	goto UW_RESULT ;
    }

    /* [�ˮֶ���]�G 4.�Q�O�I�T���ݶ]���ΦW�Q�}��������	*/
    /* �E�]���G�D�W�z�t�P����car103�t�P������ƺ��@�]�w���A�u�]�������v = ��Y�� */
    /* �s�W�j���� */
    strcpy(v_ibrand,ibrand);
    strcpy(v_frate2,frate2);
    tmp_count = 0;
    cnt_sports = 0;
    $SELECT count(*) INTO $tmp_count FROM ca_car_model
      WHERE ibrand = $v_ibrand AND sports_car = 'Y'
        AND  drate = (SELECT drate FROM ca_rate_date
                       WHERE icode = $v_frate2 AND itable = 'ca_car_model');
    cnt_sports = tmp_count;

    if ((strncmp(itag,"KUA",3)==0) || (strncmp(itag,"KUM",3)==0))
    {
        if (rt_uw_ori == -1) rt_uw_ori = 40 ;	/* ���O�զX�f�֥N�X */
        if (rt_uw_sug == -1) rt_uw_sug = 40 ;	/* ��ĳ��O�զX�f�֥N�X */
        goto UW_RESULT ;
    }


    /* ---------  ����W�ˮ֨��d�I�O�B (�]������O�B���[�`) -------------*/

    /* �ק�f�ֱ����10�אּ41�A�B�C�J�ګO���� add by 061476 108.11.11 (1081029003_SC1) */
    /*  ���d�I(RIN113���k��31�P51���O���I��) �X�p�O�B > 20000�U (2��)  */
    ri_sum_chk_ori = 0;
    ri_sum_chk_sug = 0;
    INS_ptr=Ifirst;
    while (INS_ptr)
    {

    	if (memcmp(INS_ptr->ins_type,"**",2)==0)
    	{ /* deleted ins_type */
            INS_ptr=INS_ptr->next;  continue;
        }
    	strcpy(tmp_iins, INS_ptr->ins_type);  strcpy(tmp_iins, trim(tmp_iins));
    	strcpy(tmp_provision,"");  sprintf_s(tmp_provision,sizeof tmp_provision,"%s;",trim(INS_ptr->provision)); /* ���� */

        tmp_count = 0;
        $SELECT count(*) Into $tmp_count FROM ca_fac_ins_setup
          WHERE iins_type = $tmp_iins
            AND iri_ins IN ('31','51');
        if (tmp_count>0)
        {
            if (INS_ptr->sug_iins_type==0)
            {   /* ���O�զX */
                ri_sum_chk_ori = ri_sum_chk_ori + INS_ptr->damage_cover;
        	if (ri_sum_chk_ori > 200000000)
        	{
	            rt_uw_ori = 41 ;
	            INS_ptr=INS_ptr->next;  continue;
        	}
            }
            else if (INS_ptr->sug_iins_type==1)
            {   /* ��ĳ��O�զX*/
                ri_sum_chk_sug = ri_sum_chk_sug + INS_ptr->damage_cover;
        	if (ri_sum_chk_sug > 200000000)
        	{
	            rt_uw_sug = 41 ;
	            INS_ptr=INS_ptr->next;  continue;
        	}
            }
        }

        /* 52.53.55.57.59.60.135.255 ���@�I�ؤ� ��˫O�B>1000�U �B �ƬG�O�B>8000�U*/
        /* �s�W255�I�� (1110308005_SC3)*/
        if ( (strcmp(tmp_iins,"52")==0) || (strcmp(tmp_iins,"53")==0) || (strcmp(tmp_iins,"55")==0) ||
             (strcmp(tmp_iins,"57")==0) || (strcmp(tmp_iins,"59")==0) || (strcmp(tmp_iins,"60")==0) ||
             (strcmp(tmp_iins,"135")==0)||(strcmp(tmp_iins,"255")==0) || (strcmp(tmp_iins,"252")==0) ||
             (strcmp(tmp_iins,"253")==0) ||(strcmp(tmp_iins,"555")==0)){
        	if (INS_ptr->sug_iins_type==0){/* ���O�զX */
        		if(INS_ptr->damage_cover>0){
        			if( (INS_ptr->death_cover>10000000)&&(INS_ptr->damage_cover>80000000)){
	        			rt_uw_ori = 41 ;
	        			INS_ptr=INS_ptr->next;  continue;
        			}
        		}
        	}else if (INS_ptr->sug_iins_type==1){  /* ��ĳ��O�զX*/
        		if(INS_ptr->damage_cover>0){
        			if( (INS_ptr->death_cover>10000000)&&(INS_ptr->damage_cover>80000000)){
	        			rt_uw_sug = 41 ;
	        			INS_ptr=INS_ptr->next;  continue;
        			}
        		}
        	}
        }
        INS_ptr=INS_ptr->next;
        continue;
    }

    /* ---------  ���I�ئ������ˮ֡A�G���O�զX�B��ĳ��O�զX�����}�P�_ -------------*/



    INS_ptr=Ifirst;
    while (INS_ptr)
    {

        if (memcmp(INS_ptr->ins_type,"**",2)==0)
        {
            /* deleted ins_type */
            INS_ptr=INS_ptr->next;
            continue;
        }

        /* ���[�����X�RBUG�ץ� (1101013005_SC1) */
        strcpy(tmp_iins, INS_ptr->ins_type);  strcpy(tmp_iins, trim(tmp_iins));
    	strcpy(tmp_provision,"");  sprintf_s(tmp_provision,sizeof tmp_provision,"%s;",trim(INS_ptr->provision)); /* ���� */

        if ((rt_uw_ori != -1)&&(rt_uw_sug != -1))
        {
            /* �G�ӧ�O�զX�f�֪��A���w�g���O -1�A�G�i�H���X�F*/
            goto UW_RESULT;
        }

        if (rt_uw_ori != -1)
        {
            /* ���O�զX�f�֪��A�w�g���O -1�A�G���᪺�I�ؤ��ݭn�A�ˮ֭��O�զX�F */
    	    if (INS_ptr->sug_iins_type==0)
    	    {
    	        INS_ptr=INS_ptr->next;
    	        continue;
    	    }
        }

        if (rt_uw_sug != -1)
        {
            /* ��ĳ��O�զX�f�֪��A�w�g���O -1�A�G���᪺�I�ؤ��ݭn�A�ˮ֫�ĳ��O�զX�F */
    	    if (INS_ptr->sug_iins_type==1)
    	    {
    	        INS_ptr=INS_ptr->next;
    		continue;
    	    }
        }

        strcpy(tmp_iins, INS_ptr->ins_type);  strcpy(tmp_iins, trim(tmp_iins));


        /* [�ˮֶ���]�G10. ��O�U�C�I�ؤ��@�̡G
           �C�����ȹB�~���ȳd���O�I�G57�I�� �E�����T���ȹB�~���ȳd���O�I�G59�I�� �E���ϨT���ȹB�~���ȳd���O�I�G60�I�� */
        if ( (strcmp(tmp_iins,"57")==0) || (strcmp(tmp_iins,"59")==0) || (strcmp(tmp_iins,"60")==0) )
        {
            if (INS_ptr->sug_iins_type==0)
            {
                /* ���O�զX */
        	if(INS_ptr->damage_cover>0)
        	{
        	    rt_uw_ori = 100 ;
        	    INS_ptr=INS_ptr->next;  continue;
        	}
            }
            else if (INS_ptr->sug_iins_type==1)
            {
            	/* ��ĳ��O�զX*/
        	if(INS_ptr->damage_cover>0)
        	{
        	    rt_uw_sug = 100 ;
        	    INS_ptr=INS_ptr->next;  continue;
        	}
            }
        }


        /* [�ˮֶ���]�G 7.��t�����ӫO�N�ӫO�����X�j������l���I */
        if (strcmp(tmp_iins,"85")==0)
        {
            strcpy(v_iofficer,iofficer);
            if (INS_ptr->sug_iins_type==0)
            {
            	/* ���O�զX */
        	if(INS_ptr->damage_cover>0)
        	{
        	    tmp_count = 0;
		    $SELECT count(*) Into $tmp_count FROM officer WHERE iofficer= $v_iofficer AND fprop = '1';
		    if (tmp_count > 0)
		    {
    		        rt_uw_ori = 70 ;
    			INS_ptr=INS_ptr->next;  continue;
        	    }
        	}
            }
            else if (INS_ptr->sug_iins_type==1)
            {
            	/* ��ĳ��O�զX*/
        	if(INS_ptr->damage_cover>0)
        	{
        	    tmp_count = 0;
		    $SELECT count(*) Into $tmp_count FROM officer WHERE iofficer= $v_iofficer AND fprop = '1';
		    if (tmp_count > 0)
		    {
    		        rt_uw_sug = 70 ;
    			INS_ptr=INS_ptr->next;  continue;
        	    }
        	}
            }
        }

	/* �W�Q�����[�O����D�I�~�C���H�u�֫O40,�ȩӫO�ѵs�I�h���C�J�H�u�֫O,
	   ���U�C���l�I>600�U���ˮ֤���  add by sylvia 104.03.23 (1040317005_C1)*/
	/* �W�Q���ζ]��, ���ӫO������ѵs��,
	   (1) ����Ը��B�S���ԡB����  �@�ߦC���H�u�֫O
	   (2) �O�ɱ��B����B�L�_�����B�k�ԧQ�B�Ҵ��ܴ��B���S�Q�B�L�ֵ��O�B>300�U,�n�C�J�H�u��
	   modify by sylvia 106.09.19 (1060414005_C2) */
	/* �u�nCAR103�]��������쬰Y�A���׫O�B�@�ߵ��w40  add by 061476 107.01.17(1070109009_C1)*/
	/* �S���ԭ��m����>300�U�C���H�u�֫O40 modify by 061476 109.03.10 (1090114007_SC3) */
	/* �ק�H�u�֫O40���� modify by 061476 110.05.20 (1100504003_SC1)(1100616004_SC1) */
	/* �H�u�֫O40�ק�֫O�W�h modify by 071004 (1110512003_SC1)*/

	/* [�ˮֶ���]�G�W�Q���ζ]�����X�I���� */
	/*���ӫO������ѵs�A�B�ӫO�榳�߮׻F�d��1��4�A�B�ŦX�H�U���@�����
          (1)�t�N�e2�X��70(����Ը�)�BB4(����)
          (2)�t�N�e2�X��H4
          (3)�W�Q��(���tH4)�B������ѵs�O�B> 300�U
          (4)�]��
          (5)�t�N��2�X��01(���tH4)�A�B������ѵs�O�B> 300�U
        */
	if ((ISSPC_BRAND(ibrand) || (cnt_sports > 0) || (strncmp(ibrand+6,"01",2)==0)) && ((ISINS01(tmp_iins))||(ISINS11(tmp_iins))))
	{
		tmp_count = 0;
        	strcpy(v_ipolicy,ipolicy);
        	strcpy(sFullDB, get_car_full_dbname(v_ipolicy));

        	sprintf_s(stmt,sizeof stmt, " select count(*) from %s:appraisal "
        	              " where (facc_duty IN ('1','4') or fdmg_duty IN ('1','4')) "
        	              " and ipolicy = ? ; ",sFullDB);
        	$PREPARE stm_cnt FROM $stmt;
        	$EXECUTE stm_cnt INTO $tmp_count USING $v_ipolicy;

        	if (tmp_count > 0)
        	{
        		if ((strncmp(ibrand,"70",2)==0) || (strncmp(ibrand,"B4",2)==0) ||(strncmp(ibrand,"H4",2)==0))
        		{
        			if (INS_ptr->sug_iins_type==0){  /* ���O�զX */
        				rt_uw_ori = 40 ;
        				INS_ptr=INS_ptr->next;  continue;
        			}else if (INS_ptr->sug_iins_type==1){  /* ��ĳ��O�զX*/
        				rt_uw_sug = 40 ;
        				INS_ptr=INS_ptr->next;  continue;
        			}
        		}

        		/*if (strncmp(ibrand,"H4",2)==0)
        		{
        			mcar_price_h4 = 0;
        			$select (mcar_price*10000)
        			into $mcar_price_h4
        			from policy_last
        			where ipolicy = $ipolicy;

        			if (mcar_price_h4 > 3000000)
        			{
        				if (INS_ptr->sug_iins_type==0){   ���O�զX
        					rt_uw_ori = 40 ;
        					INS_ptr=INS_ptr->next;  continue;
        				}else if (INS_ptr->sug_iins_type==1){   ��ĳ��O�զX
        					rt_uw_sug = 40 ;
        					INS_ptr=INS_ptr->next;  continue;
        				}
        			}
        		}*/

        		if(ISSPC_BRAND(ibrand) && strncmp(ibrand,"H4",2) != 0 )
        		{
        		    if (INS_ptr->sug_iins_type==0){  /* ���O�զX */
        			if(INS_ptr->damage_cover > 3000000){
        				rt_uw_ori = 40 ;
        				INS_ptr=INS_ptr->next;  continue;
        			}
        		    }else if (INS_ptr->sug_iins_type==1){  /* ��ĳ��O�զX*/
        			if(INS_ptr->damage_cover > 3000000){
        				rt_uw_sug = 40 ;
        				INS_ptr=INS_ptr->next;  continue;
        			}
        		    }
        		}


        		if(cnt_sports > 0){
        			if (INS_ptr->sug_iins_type==0){  /* ���O�զX */
        				rt_uw_ori = 40 ;
        				INS_ptr=INS_ptr->next;  continue;
        			}else if (INS_ptr->sug_iins_type==1){  /* ��ĳ��O�զX*/
        				rt_uw_sug = 40 ;
        				INS_ptr=INS_ptr->next;  continue;
        			}
        		}

        		if( strncmp(ibrand+6,"01",2)==0 && strncmp(ibrand,"H4",2) != 0 )
        		{
        		    if (INS_ptr->sug_iins_type==0){  /* ���O�զX */
        			if(INS_ptr->damage_cover > 3000000){
        				rt_uw_ori = 40 ;
        				INS_ptr=INS_ptr->next;  continue;
        			}
        		    }else if (INS_ptr->sug_iins_type==1){  /* ��ĳ��O�զX*/
        			if(INS_ptr->damage_cover > 3000000){
        				rt_uw_sug = 40 ;
        				INS_ptr=INS_ptr->next;  continue;
        			}
        		    }
        		}

        	}
        }

        /* [�ˮֶ���]�G���l�I�O�B > 600�U */
        /* modify by 071004 (1110512003_SC1_�H�u�֫O40�ק�֫O�W�h)*/
        if ((ISINS01(tmp_iins)) ||(ISINS11(tmp_iins))){
        	if (INS_ptr->sug_iins_type==0){  /* ���O�զX */
        	    if(INS_ptr->damage_cover > 6000000){
    			    rt_uw_ori = 40 ;
    			    INS_ptr=INS_ptr->next;  continue;
        		}
        	}else if (INS_ptr->sug_iins_type==1){  /* ��ĳ��O�զX*/
        		if(INS_ptr->damage_cover > 6000000){
    			    rt_uw_sug = 40 ;
    			    INS_ptr=INS_ptr->next;  continue;
        		}
        	}
        }

        /* add by 071004 (1110308005_SC3_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h)*/
        /* [�ˮֶ���]�G 32���ئ��ӫO55.49.117.255�ɡA�Y���~�צ��X�I�F�d1��4�ɡA�k���ܤH�u�֫O40 */
        /* �s�W555�I�� add by sylvia 114.04.30 (1140409004_C01) */
        if (strcmp(icar_type,"32") == 0)
        {
            if ((strcmp(tmp_iins,"55")==0) || (strcmp(tmp_iins,"49")==0) ||
                (strcmp(tmp_iins,"117")==0) || (strcmp(tmp_iins,"255")==0) ||
                (strcmp(tmp_iins,"555")==0))
            {

                tmp_count = 0;
			        	strcpy(v_ipolicy,ipolicy);
			        	strcpy(sFullDB, get_car_full_dbname(v_ipolicy));

			        	sprintf_s(stmt,sizeof stmt, " select count(*) from %s:appraisal "
										        	              " where facc_duty IN ('1','4') "
										        	              " and ipolicy = ? ; ",sFullDB);
			        	$PREPARE stm_cnt3 FROM $stmt;
			        	$EXECUTE stm_cnt3 INTO $tmp_count USING $v_ipolicy;

			        	if (tmp_count > 0)
			        	{
			                    if (INS_ptr->sug_iins_type==0){  /*���O�զX*/
			                	rt_uw_ori = 40 ;
			                	INS_ptr=INS_ptr->next;  continue;
			        	    }else if (INS_ptr->sug_iins_type==1){  /*��ĳ��O�զX*/
			        	        rt_uw_sug = 40 ;
			        	        INS_ptr=INS_ptr->next;  continue;
			        	    }
			        	}

            }
        }


        /* [�ˮֶ���]�G 41.�ŦX�������[�O�Y��	--------------------------------
          ���[���� | �X�I���� | �[�O�Y�� | �֫O���A
           ���[ S       ����      = 1.0     continue (���Ű������[�O)
           ���[ S       ����      > 1.0     41       (�ŦX�������[�O)
           ���[ S       >=1       ���ˮ�    41       (�ŦX�������[�O)
           ���[ S       =0        = 1.0     continue (���Ű������[�O,�@�֨���S����)
           ���[ S       =0        > 1.0     continue (�ŦX�������[�O,�H�[�O�O�v�p��,�ì��t�ή֫O)

           (104.11/27 ���Ȯɥ����ױ�, ���ʱo�Ʋz�q�� */
        if ((INS_ptr->sug_iins_type==0)||(INS_ptr->sug_iins_type==1)){
            if ((strstr(tmp_provision,"S;") != NULL) || (INS_ptr->pcar_price > 1.0) ||
                (INS_ptr->pcar_price < 1.0))
            {
                rt_uw_ori = 41 ;
    	       	rt_uw_sug = 41 ;
    	       	goto UW_RESULT ;
	    }
        }

        /* 102.06.05�s�W�G31�I�بƬG�O�B>12000�U */
        /* �s�W531�I�� add by sylvia 114.04.30 (1140409004_C01) */
        if ((strcmp(tmp_iins,"31")==0)|| (strcmp(tmp_iins,"231")==0)|| (strcmp(tmp_iins,"133")==0)||
            (strcmp(tmp_iins,"149")==0)|| (strcmp(tmp_iins,"249")==0) ||
            (strcmp(tmp_iins,"531")==0)){
        	if (INS_ptr->sug_iins_type==0){  /* ���O�զX */
        		if(INS_ptr->damage_cover>0){
        			if(INS_ptr->damage_cover>120000000){
	        			rt_uw_ori = 10 ;
	        			INS_ptr=INS_ptr->next;  continue;
        			}
        		}
        	}else if (INS_ptr->sug_iins_type==1){  /* ��ĳ��O�զX*/
        		if(INS_ptr->damage_cover>0){
        			if(INS_ptr->damage_cover>120000000){
	        			rt_uw_sug = 10 ;
	        			INS_ptr=INS_ptr->next;  continue;
        			}
        		}
        	}
        }

        /* ���d�I(RIN113���k��31�P51���O���I��) �X�p�O�B > 20000�U (2��)  */
        /*tmp_count = 0;
        $SELECT count(*) Into $tmp_count FROM ca_fac_ins_setup
          WHERE iins_type = $tmp_iins
            AND iri_ins IN ('31','51');
        if (tmp_count>0){
        	if (INS_ptr->sug_iins_type==0){  * ���O�զX *
        	    ri_sum_chk_ori = ri_sum_chk_ori + INS_ptr->damage_cover;
        	    if (ri_sum_chk_ori > 200000000){
	        		rt_uw_ori = 10 ;
	        		INS_ptr=INS_ptr->next;  continue;
        	    }
        	}else if (INS_ptr->sug_iins_type==1){  * ��ĳ��O�զX*
        		ri_sum_chk_sug = ri_sum_chk_sug + INS_ptr->damage_cover;
        	    if (ri_sum_chk_sug > 200000000){
	        		rt_uw_sug = 10 ;
	        		INS_ptr=INS_ptr->next;  continue;
        	    }
            }
        }*/



        /* 07,15����,31��32�I�ئۭt�B < 1�U, �B�D����....�֫O���A=180   add by sylvia 104.01.26 */
        /* �w��car140���ORN��CHK_NO_180�A����180�֫O���A modify by 061476 (1090820002_SC1) */
        if (chk_PA > 0)
        {
            if ((strcmp(icar_type,"07") == 0) || (strcmp(icar_type,"15") == 0))
            {
                strcpy(v_iofficer,iofficer);
                strcpy(v_iroute,iroute);
                tmp_count = 0;
                $SELECT count(*) Into $tmp_count FROM officer WHERE iofficer= $v_iofficer AND imgr = '1';

                if (tmp_count == 0) /* �D���� */
                {
                	tmp_count = 0;
                	$SELECT count(*) into $tmp_count
                	   FROM car_code
                	  WHERE kind = 'RN' AND detail = 'CHK_NO_180'
                	    AND detail2 = $v_iofficer AND engname = $v_iroute;

                	if (tmp_count == 0) /* �bCHK_NO_180������180�֫O���A */
                	{

                	    /*1101008003_SC1_��O�J�p07.15���ؽվ�H�u�֫O180*//*modify by 071004 */
                	    /*�վ㦨�e�榳���d�Ψ���F�d��1(���F�d,�O��)���߮סA�~��180*/

                            tmp_count = 0;
        	            strcpy(v_ipolicy,ipolicy);
        	            strcpy(sFullDB, get_car_full_dbname(v_ipolicy));

        	            sprintf_s(stmt,sizeof stmt, " select count(*) from %s:appraisal "
        	                          " where (facc_duty IN ('1') or fdmg_duty IN ('1')) "
        	                          " and ipolicy = ? ; ",sFullDB);
        	            $PREPARE stm_cnt2 FROM $stmt;
        	            $EXECUTE stm_cnt2 INTO $tmp_count USING $v_ipolicy;

        	            if (tmp_count > 0)
        	            {
                	        if (INS_ptr->sug_iins_type==0){  /*���O�զX*/

                		    rt_uw_ori = 180 ;
                		    INS_ptr=INS_ptr->next;  continue;

        	        	}else if (INS_ptr->sug_iins_type==1){  /*��ĳ��O�զX*/

        	        	    rt_uw_sug = 180 ;
        	        	    INS_ptr=INS_ptr->next;  continue;

        	        	}
        	            }
                	}
                }
            }
        }


        /* [�ˮֶ���]�G 14.���H�U���[���ڪ̡G T�BD�BF�BB�BE���ڪ� */
        /* E���ڤ��A�אּ140  modify by sylvia 104.01.22 (1040112005_C1)  */
        /* G���ڤ��F���� add by sylvia 105.08.06 (1050705002_C3) */
        /* J���ڤ��D���� add by sylvia 105.09.23 (1050801002_C4) */
        /* R���ڦC�J�H�u�f�� add by 061476 106.12.13 (1061124001_C1) */
        /* 98�I�ت��[E���� add by 061476 107.02.07 (1060914009_C3)-> 98����אּ09+K (1080408008_SC3)
           -> K����09+K�אּ198(1091103004_SC1) */
        /* X���ڦC�J�H�u�֫O add by 061476 107.11.08 (1070928002_SC4)*/
        /* 32���ت��[L���� add by 061476 108.09.17 (1080708002_SC3)*/
        /* ���ܼf�֥N�X180�� (1101126007_SC1_�H�u�֫O140�A09+K+E �ק��ˮֶ���) modify br 071004 */
        /* 1110617008_SC1_�վ���O�L�s�W�h198�I+E*/
        if ((INS_ptr->sug_iins_type==0)||(INS_ptr->sug_iins_type==1)){
	        if( (strstr(tmp_provision,"D;") != NULL) ||
	            (strstr(tmp_provision,"F;") != NULL) ||
	            (strstr(tmp_provision,"B;") != NULL) ||
	            (strstr(tmp_provision,"G;") != NULL) ||
	            (strstr(tmp_provision,"J;") != NULL) ||
	            (strstr(tmp_provision,"R;") != NULL) ||
	            (strstr(tmp_provision,"X;") != NULL) ||
	            ((strstr(tmp_provision,"L;") != NULL) && (strcmp(icar_type,"32") == 0))) {
	        	rt_uw_ori = 140 ;
	        	rt_uw_sug = 140 ;
	        	goto UW_RESULT ;
	        }

	        /* �}�l�p��T����,�i���oT���ڥ[��O�T��,�i���`�֫O;�Y�L�k���o,�~�אּ140
	           modify by sylvia 104.12.02 (104111011_C1) */
	        if ((strstr(tmp_provision,"T;") != NULL) &&
	            ((INS_ptr->safe_rate == 0.0) && (INS_ptr->manage_rate == 0.0)))
	        {
	        	rt_uw_ori = 140 ;
	        	rt_uw_sug = 140 ;
	        	goto UW_RESULT ;
	        }
        }




        INS_ptr=INS_ptr->next;
        continue;
    }
    puts(" �i���O�κޱ��~�ȥ�jpassed !\n ");

    /* �g�L�i���O�κޱ��~�ȥ�j�f�֫�A�w��|��"���f��"���A���A�A�i��i���l�I��O�զX����j�f��      */

    /*---------------------------------�i���l�I��O�զX����j----------------------------------------*/

    int fIns01_ori,fIns01_sug,tmp_01_cover_ori,tmp_01_cover_sug,tmp_01_deduct_ori,tmp_01_deduct_sug;
    int fIns11_ori,fIns11_sug,tmp_11_cover_ori,tmp_11_cover_sug,tmp_11_deduct_ori,tmp_11_deduct_sug;


    fIns01_ori = 0 ; fIns01_sug = 0 ; fIns11_ori = 0 ; fIns11_sug = 0 ;
    tmp_01_cover_ori= tmp_01_cover_sug= tmp_01_deduct_ori= tmp_01_deduct_sug=0;
    tmp_11_cover_ori= tmp_11_cover_sug= tmp_11_deduct_ori= tmp_11_deduct_sug=0;

    if( (rt_uw_ori == -1)||(rt_uw_sug == -1) ){

    	INS_ptr=Ifirst;

    	chk98_sug = 0;

    	while (INS_ptr){
    		if (memcmp(INS_ptr->ins_type,"**",2)==0){ /* deleted ins_type */
    			INS_ptr=INS_ptr->next;  continue;
	        }

	    	strcpy(tmp_iins, INS_ptr->ins_type);  strcpy(tmp_iins, trim(tmp_iins));

	    	if (ISINS01(tmp_iins)){  /* ���� */
	    		if (INS_ptr->sug_iins_type==0){
	    			if(INS_ptr->damage_cover>0){       /* ���O�զX */
	    				fIns01_ori = 1;
	    				tmp_01_cover_ori  = INS_ptr->damage_cover;
	    				tmp_01_deduct_ori = INS_ptr->deduct;
	    			}
	    		}else if (INS_ptr->sug_iins_type==1){      /* ��ĳ��O�զX*/
	    			fIns01_sug = 1;
	    			tmp_01_cover_sug  = INS_ptr->damage_cover;
	    			tmp_01_deduct_sug = INS_ptr->deduct;

	    			/* ����ĳ98�I��,�B�O�B��5�U��10�U 0:�L 1:��  add by sylvia (1040317005_C1) */
	    			if ((strcmp(tmp_iins,"98") == 0) &&
	    			    ((tmp_01_cover_sug == 50000) || (tmp_01_cover_sug == 100000))){
	    			    	chk98_sug = 1;
	    			}
	    		}
	    	}

	    	if(ISINS11(tmp_iins)){  /* �ѵs  */
	    		if (INS_ptr->sug_iins_type==0){
	    			if(INS_ptr->damage_cover>0){       /* ���O�զX */
	    				fIns11_ori = 1;
	    				tmp_11_cover_ori  = INS_ptr->damage_cover;
	    				tmp_11_deduct_ori = INS_ptr->deduct;
	    			}
	    		}else if (INS_ptr->sug_iins_type==1){      /* ��ĳ��O�զX*/
	    			fIns11_sug = 1;
	    			tmp_11_cover_sug  = INS_ptr->damage_cover;
	    			tmp_11_deduct_sug = INS_ptr->deduct;
	    		}
	    	}

	    	if ((fIns01_ori==1) && (fIns11_ori==1) && (fIns01_sug==1) && (fIns11_sug==1)) break;

	        INS_ptr=INS_ptr->next;
	        continue;
	}

	/*  200	���O�զX�L����B�ѵs�I�A����ĳ��O�զX������B�ѵs�I��	    */
	if ( (fIns01_ori==0) && (fIns01_sug==1) ){
		/*���O�զX�L����,��ĳ��O�զX������ */
	        /* ��ĳ�����O98�I��(�B��ĳ��98�I�O�B!=5�U��10�U) �C���H�u�֫O��  modify by sylvia 104.03.23(1040317005_C1) */
	        if (chk98_sug == 0){
	        	if (rt_uw_sug == -1) rt_uw_sug = 200;
	    	}
	}else if ( (fIns11_ori==0) && (fIns11_sug==1) ){
		/*���O�զX�L�ѵs,��ĳ��O�զX���ѵs */
	    	if (rt_uw_sug == -1) rt_uw_sug = 200;
	}

	/*  210	���O�զX������B�ѵs�I�A����ĳ��O�զX����B�ѵs�I���ۭt�B�O�B�����ʪ� */
	if ( (fIns01_ori==1) && (fIns01_sug==1) ){
		/*���O�B��ĳ��O�զX�������� */
	    	/* �I�ؤ��P�G(�����I���ĳ��O�զX��"�ɯ�") Ex. �h�~09 => ��O05(ex.�Υ�) ; �h�~05(or 85) => ��O105(102.08.26)(102.09.23 ) */
	    	/* ��A���ӫ~��(f_ins1589_chg_flag = 5,6,78) ���i�C�Lú�ڳ� modify by sylvia 103.12.16 (1031209009_C1) */
	        if ((f_ins1589_chg_flag > 0) && (f_ins1589_chg_flag < 5)) {
	        	if (rt_uw_sug == -1) rt_uw_sug = 210;
	        }else{
		    	if ((tmp_01_cover_ori!=tmp_01_cover_sug)||(tmp_01_deduct_ori!=tmp_01_deduct_sug)){
		    		/* �O�B�Φۭt�B���P*/
		    		if (rt_uw_sug == -1) rt_uw_sug = 210;
		    	}
	    	}
	}
	/* �ѵs�I�٬O�n�A�P�_�@��  modify by sylvia 104.07.15 (bug�ץ�) */
	if ( (fIns11_ori==1) && (fIns11_sug==1) )
	{
		/*���O�B��ĳ��O�զX�����ѵs */
	    	/* �O�B�Φۭt�B���P*/
	    	/* �վ��ѵs�I�P�_�W�h 061476 108.08.19 (1080808005_SC1) */
	    	if (tmp_11_cover_ori!=tmp_11_cover_sug){
	    		/* �O�B���P*/
	    		if (rt_uw_sug == -1) rt_uw_sug = 210;
	    	}
	}
    }

    puts(" �i���l�I��O�զX����jpassed !\n ");

    /*----------------------------------------------------------------------------------------------*/
    /* �����̫�@���f��(�ګO��B���`�󰣥~�A�O�b�J�p����@��update policy_302)�A�ܦ��|�����f�̡֪A
       �f�֪��A�אּ "�q�L�f��"(500)*/

    if (rt_uw_ori == -1) rt_uw_ori = 500;
    if (rt_uw_sug == -1) rt_uw_sug = 500;

UW_RESULT:

	*rt_uw_status_ori = rt_uw_ori;  /* �f�ֵ��G�N�X(���O�զX)  */
	*rt_uw_status_sug = rt_uw_sug;  /* �f�ֵ��G�N�X(��ĳ��O�զX)*/

    return M_CM_OK;


errexit:
    printf("14786 ca3xxlib.ec check_policy() sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

	/*-- long WriteToEstimate(iplyyear,iplymonth,intopt,ipgid,userid)
	     �ت� �G
	       (1)�g�J���O�X��һݬ�����ơG
	          �w��Ӧ~��Ҧ���O��ơA���ͭ��O�B��ĳ��O�զX�������渹�Bú�ڥ���s���G
	         (a)�̾ڡu���N�I���O�B��ĳ��O�զX�f�֪��A�v(�j���I�����O�B��ĳ��O�զX�f�֪��A�@�߬�500)�G
	           �E�Y���N�I�G�ӲզX��       <> 500 => �h�ӵ���O�椣���ͳ����渹��ú�ڥ���s���B���g�Jcm_pre_receive�Bao_rcv_type
	           �E�Y���N�I�䤤�@�ӧ�O�զX <> 500 => �h�ӵ���O��ӧ�O�զX�����ͳ����渹��ú�ڥ���s���B���g�Jcm_pre_receive�Bao_rcv_type
	           �E�Y���N�I�G�ӲզX��       =  500 => �h�ӵ���O��G�ӲզX�Ҳ��ͳ����渹��ú�ڥ���s���B�Ҽg�Jcm_pre_receive�Bao_rcv_type

	         (b)��Ƽg�J�G
	           (i) update policy_302�Gfuw_status_ori�Bfuw_status_sug (�����渹)
	                                    itransno_ori�Bitransno_sug   (ú�ڥ���s��)
			     [�j��B���N�P����B�P�O��](�_�h������j�B����N)�G
			                   / �j�� \
			       �� ���O            �ۦP�����渹 => �ۦPú�ڥ���s��
			                   \ ���N /
			                   / �j�� \
			       �� ��ĳ��O          �ۦP�����渹 => �ۦPú�ڥ���s��
			                   \ ���N /

			   (ii)insert cm_pre_receive (102.03.14)�G(cm_pre_receive_p1(U) �G ipre_rcv + iins_kind + ipre_end)
			       iins_cat (�I�O)     , ipre_rcv (�����渹)  , iins_kind (�I��)       , iins_kind_ply (�I��), ftype (���O���A)       , ipre_end (�t�B���) ,
			       iassured (�Q�O�HID) , nassured (�Q�O�H�W��) , iapplicant (�n�O�HID)) , napplicant (�n�O�H�W��) , itag (���P���X) ,
			       iengine (�������X   , deffect (�w�w�ͮİ_��) , paydate (ú�O����)   , mprem (������ú�O�O)   , isub (�����q�O) ,
			       iofficer (�g��N��) , ileader (�޲z�H)     , iquota (�~�Z���)      , icomm_obj (�I����H)   , iroute (�q���N��) ,
			       fcommit (�����O)    , ientry (��J�H��)    , dentry (��J���)      , isys (�t�ΧO)
			       igroup (�H�uú�O�帹) , fstatus (���A)     , iupdate (��s�H��)     , dupdate (��s���) ,
			       ipolicy1 (�O�渹�X1), ipolicy2 (�O�渹�X2) , iendorse (��渹�X)    , icard (�O�d���X)       , dprint (�L��ɶ�) ,
			       fprint_rcv (ú�ڳ�C�L���O) , iedr_return (��z�覡)

			   (ii)insert ao_rcv_type (102.03.14)�G(ao_rcv_type_ix_1(U) �G trcv + tseq + iyear)  +iins_kind ??
			       data_type (�ӷ��O) , iyear (�~��) , trcv (ú�O�渹) , tseq (ú�O�Ǹ�) , ipolicy1 (�O�渹�X1) ,
			       ipolicy2 (�O�渹�X2) , iendorse (��渹�X) , ipre_end (�t�B���) , times (����) , icard (�O�d���X) ,
			       ipre_rcv (�w���s��) , mprem (�����O�O) , iassured (�Ȥ�s��) , iassured_ext (�Ȥ����) ,
			       nassured (�O��W��) , userid (�s��H��) , paydate (ú�O����) , isub (�����q�O) , ibroker (�g���H[��ڬO�g�J"�I����H"]) ,
			       iofficer (�g��H) , insure_type (�I�O) , iins_kind (�I��) , dpay (�J�b��)

           (2)�P�_�O�_��barcode��A�g�J policy_302.frenew_type (= '2') �Bfuw_status_ori( = 500)�Bfuw_status_sug( = 500)
           (3)�Y�����ĳq��(I0),���׬O�_����barcode��,�u����j�C�Lú�ڳ�,�j+���γ�����Lú�ڳ�,�B���ǤJ�O��e�~�C�L�d��C(modify by sylvia 104.03.30(1040312001_C1))
	-----------------------------------------------------------------------------------------------------*/

long WriteToEstimate(fChoice,iplyyear,iplymonth,intopt,ipgid,userid)
$int   iplyyear,iplymonth,intopt;
$char  fChoice[2],ipgid[9],userid[12];
{
    $int   t_count;
    $char  stmt[2048];
    int    rc,i,n,fBothIns,record_cnt,fBothIns_sug,rc2,fpayable,freject_Z;
    $int   iTmp, iYear, iCount,tmp_Count,tmp_cnt=0,v_iplymonth,tmp_type = 0,tseq;
    $char  sFullName[20]="",ilicense_v[13],fBarcode_print[2] = " ",icode_no[11],tmp_ilicense[13];
    $char  all_col_302[3000],stmt_302[9000] ;
    $char  str[101],str1[101];
    $char  sFirstDay[11],sLastDay[11],sTmpIcomp[2],sTmpChDate[10],sTmpChDate_sys[10],sTmpChDate_pay[10];
    $char  fcommit[2],isub[3],isys[2];
    $char  dply_bgn_comp[11],dply_end_comp[11],freason_reject[2],s_dply_begin_comp[11],ftype_pol[3],ftype_sp[3];
    $int   v_prem,v_ori_prem,tot_prem, mcomp_prem_sug,comp_prem,mcomp_prem_sug1,mcomp_prem_sug2;
    $date  Today,paydate,paydate_ext;
    $long  lng_dply_begin_comp,lng_paydate_comp;
    $double mprem;
    char   fNoData,Is_JC,Is_SP,fChk_bc1,Is_PrintBC;
    $char  iofficer_comp[11], ileader_comp[11], iquota_comp[7], icomm_obj_comp[11], iroute_comp[21], ibranch_comp[3],isub_comp[3];
    $char  iroute12[3], fsend_msg[2], mobile_phone[21], mobile_phone_c[21],fassured[2];
    $date  null_date = DATENULL ;
    $char  iquota1_4[5],imgr[2], sIins_kind_ply[3],sComm_obj[3],
           chk_renew_3[2], bzfrom_c[3], iroute_c[21], bzfrom1[2];
    char  IsPlyB;
    $int   cnt_prmt,iCount_20,iCount_10;
    $char  cm_dbegin[11],cm_dend[11],dbegin_302[11],dend_302[11], imgr_c[2];
    $char  tmYY[4], tmMM[3], tmDD[3],chk_I0[2], leaderI0[11], officerI0[11];
    int    iTESTprem;
    $long  idate;
    $char  ymd[12], iroute_accept[21], cdate[11], cdate2[11];
    $char  dbirth1[11], dbirth2[11], iupcomp1[2], iupcomp2[2], ipolicy67[3], iroute2[21], freason_reject2[2];
    $char  ibig_sales[11], icomm_obj[11], iroute_main[13], ireg_no_tmp[21], freg_no_chg[2];
    $char  tmobile_appl[21], aemail_appl[51], ipolicy13[4];

    $int   D1060126,ChkDmgIns;
    char   F_type[5];

    $char  istl_obj[13],istl_obj_ext[3],nstl_obj[101];
    $double mnt;
    $int   cnt4750,cnt_chk10;

    /*
      ftype_pol ftype_sp    ����
                  PA       �A�Φ��O�X��
      NA          EB       �D���O�X��-�q�ʦۦ樮
      NA          EW       �D���O�X��-�����O�T
      NA          RN       �D���O�X��-��104/01-02��O��ϥ�
      NA          TV       �D���O�X��-���ը�
      NA          ES       �D���O�X��-�R�q��
      SP          01       �ĳq��-�j���I(��j)
      SP          10       �ĳq��-���q�ĳq
      SP          20       �ĳq��-�O�g�N
    */

    $WHENEVER SQLERROR GOTO errexit;
    if (intopt == 25){
        $WHENEVER SQLERROR CONTINUE;
    }
    $SET LOCK MODE TO WAIT;

    printf("trace In WriteToEstimate()\n ");


    sprintf_s(stmt,sizeof stmt, "SELECT icode_no,fgen302file1 \
                     FROM tmp_barcode_officer \
                    WHERE icode_no <> 'EB000001' \
                      and (iofficer =? or iofficer =?) ");
    $PREPARE preBarcode_off FROM $stmt;

    sprintf_s(stmt,sizeof stmt, "SELECT icode_no,fgen302file1 \
                     FROM tmp_barcode_officer \
                    WHERE icode_no = 'EB000001' \
                      and (iofficer =? or iofficer =? )");
    $PREPARE preBarcode_off_51 FROM $stmt;

    sprintf_s(stmt,sizeof stmt, "SELECT count(*) \
                     FROM tmp_no_barcode_list \
                    WHERE tmp_iofficer =? ");
    $PREPARE preNo_barcode FROM $stmt;

    /* 101.10 �A�ק� "�A��50�I�ؤ�����" �P�_�覡  */
    sprintf_s(stmt,sizeof stmt, "SELECT count(*) \
                     FROM tmp_ins50_cartype \
                    WHERE icar_type =? ");
    $PREPARE preIns50_cartype FROM $stmt;

    /* 101.10 �Afor tpl_barcode, check �O�_�ŦXtpl_barcode �z����� */
    sprintf_s(stmt,sizeof stmt, "select count(*) from policy_302 a  \
                    where a.ipolicy = ?  \
                      and a.icar_type in ('03','04','19','22','01','02') \
                      and a.ibrand[1,2] not in (%s) \
                      and NOT EXISTS (SELECT * FROM ply_ins_type_302 \
                                       WHERE ipolicy = a.ipolicy \
                                         AND iins_type in (%s,%s) ) ", SPC_BRAND_STRING, INS01_STRING, INS11_STRING) ;

    printf("chk trace char[%s]\n ",stmt);
    $PREPARE prep_tpl_chk FROM $stmt;

    /* �Z�O�h�~�u�O21+50�̥B��ĳ�I�ؤ����t�����ѵs�̡A��[�J�T����jbarcode */
    sprintf_s(stmt,sizeof stmt, "SELECT count(*) FROM ply_ins_type_302 a \
                    WHERE a.ipolicy =  ? \
                      AND EXISTS (SELECT * FROM ply_ins_type_302  \
                                   WHERE ipolicy = a.ipolicy  \
                                     AND iins_type = ? \
                                     AND pre_dam_cover > 0) \
                      AND NOT EXISTS (SELECT * FROM ply_ins_type_302  \
                                       WHERE ipolicy = a.ipolicy  \
                                         AND iins_type IN (%s,%s) )  \
                      AND NOT EXISTS (SELECT * FROM ply_ins_type_302  \
                                       WHERE ipolicy = a.ipolicy  \
                                         AND iins_type <> '50' \
                                         AND pre_dam_cover > 0)  ", INS01_STRING, INS11_STRING) ;
    printf("chk trace 2 char[%s]\n ",stmt);
    $PREPARE prep_check_ins FROM $stmt;

    /* 101.10 �Afor tpl_barcode, check �O�_�ŦX �D���Ӿ���barcode �I�ر��� */
    sprintf_s(stmt,sizeof stmt, "SELECT count(*) \
                     FROM ply_ins_type_302 \
                    WHERE ipolicy =? \
                      AND iins_type IN (%s,%s) ", INS01_STRING, INS11_STRING) ;
    $PREPARE prep_chk01_11 FROM $stmt;

    sprintf_s(stmt,sizeof stmt, "SELECT sum(mins_premium) FROM ply_ins_type_302 \
                    WHERE ipolicy =? and iins_type = ?");
    $PREPARE prep_prem_sug1 FROM $stmt;

    sprintf_s(stmt,sizeof stmt, "SELECT sum(mins_premium) FROM ply_ins_type_302 \
                    WHERE ipolicy =? and iins_type <> '21'");
    $PREPARE prep_prem_sug2 FROM $stmt;

    sprintf_s(stmt,sizeof stmt, "Update policy_302 \
                      Set ireg_no = ? \
                    WHERE ipolicy = ? ; ");
    $PREPARE prep_upd_302_ireg_no FROM $stmt;

    sprintf_s(stmt,sizeof stmt, "Update policy_302f \
                      Set ireg_no = ? \
                    WHERE ipolicy = ? ; ");
    $PREPARE prep_upd_302f_ireg_no FROM $stmt;

    /* 102.12.03 �Y�O�j���I�w���P�_����j�üg�Jú�ڽs���A�h���N�I�Y�ϧP�_�����j��+���N���A�]���A�^���j���I��ú�ڳ渹�B�����渹 */
    /* �w��barcode��A���s�^�����A */
    /* �W�[�@�ȡB�ػȡB���ȵ����b�� add by sylvia 106.12.18 (1060831012) */
    /* �W�[����@�ص����b�� add by 061476 108.11.19 (1070518005_SC1) */
    sprintf_s(stmt,sizeof stmt, "Update policy_302 \
                      Set iestimate_ori= ?,itransno_ori= ?, fuw_status_ori =? ,frenew_type = ?, \
                          itransno_ori_atm = ?, itransno_ori_post = ?, iroute_accept = ?, \
                          itransno_ori_007 = ?, itransno_ori_008 = ?, itransno_ori_009 = ?, \
                          itransno_ori_013 = ? \
                    WHERE ipolicy = ? and iestimate_ori = '' and itransno_ori = ''; ");
    $PREPARE prep_upd_302_ori FROM $stmt;

    sprintf_s(stmt,sizeof stmt, "Update policy_302f \
                      Set iestimate_ori= ?,itransno_ori= ?, fuw_status_ori =? ,frenew_type = ?, \
                          itransno_ori_atm = ?, itransno_ori_post = ?, iroute_accept = ?, \
                          itransno_ori_007 = ?, itransno_ori_008 = ?, itransno_ori_009 = ?, \
                          itransno_ori_013 = ? \
                    WHERE ipolicy = ? and iestimate_ori = '' and itransno_ori = '';");
    $PREPARE prep_upd_302f_ori FROM $stmt;

    sprintf_s(stmt,sizeof stmt, "Update policy_302 \
                      Set iestimate_sug= ?,itransno_sug= ?, fuw_status_sug = ? ,frenew_type = ?, \
                          itransno_sug_atm = ?, itransno_sug_post = ?, \
                          itransno_sug_007 = ?, itransno_sug_008 = ?, itransno_sug_009 = ?, \
                          itransno_sug_013 = ? \
                    WHERE ipolicy = ?  and iestimate_sug = '' and itransno_sug = ''; ");
    $PREPARE prep_upd_302_sug FROM $stmt;

    sprintf_s(stmt,sizeof stmt, "Update policy_302f \
                      Set iestimate_sug= ?,itransno_sug= ?, fuw_status_sug = ? ,frenew_type = ?, \
                          itransno_sug_atm = ?, itransno_sug_post = ?, \
                          itransno_sug_007 = ?, itransno_sug_008 = ?, itransno_sug_009 = ?, \
                          itransno_sug_013 = ? \
                    WHERE ipolicy = ?  and iestimate_sug = '' and itransno_sug = ''; ");
    $PREPARE prep_upd_302f_sug FROM $stmt;

    sprintf_s(stmt,sizeof stmt, "Update policy_302 \
                      Set iroute_accept = ? \
                    WHERE ipolicy = ? and iestimate_ori = '' and itransno_ori = ''; ");
    $PREPARE prep_upd_302_accept FROM $stmt;

    sprintf_s(stmt,sizeof stmt, "Update policy_302f \
                      Set iroute_accept = ? \
                    WHERE ipolicy = ? and iestimate_ori = '' and itransno_ori = '';");
    $PREPARE prep_upd_302f_accept FROM $stmt;


    /* Insert �w���@�γ����� (cm_pre_receive)  */
    /* �t�X�@�γ�������cm_pre_receive�s�Wiins_kind_ply���(�j��=C1,���N=C2
       add by sylvia 103.05.19 (1020111001_CG) */
    /* �s�Wfsend_msg(�O�_�ǰe²�T)�Bmobile_phone(��ʹq��) add by sylvia 105.04.11 (1050330002_C1)  */
    /* �s�Wilast_policy(�e�O�渹) add by 061476 (1100312004_SC1) */
    /* �I�O �����渹 �I�� �I�� ���O���A �t�B��� �Q�O�HID �Q�O�H�W�� �n�O�HID �n�O�H�W�� ���P�� ������ �w�w�ͮİ_�� ú�O���� ������ú�O�O �����q�O �g��N�� �޲z�H �~�Z��� �I����H �q���N�� �����O ��J�H�� ��J��� �t�ΧO �Ȥ�̫�ú�ڤ� �̫�J�b�� �H�uú�O�帹 ���A ��s�H�� ��s��� �O�渹�X1 �O�渹�X2 ��渹�X �O�d���X �L��ɶ� ú�ڳ�C�L�ɶ� ��z�覡 �O�����O �ĳq���O �_�O�� ���O�� �O�_�H�o²�T ��ʹq�� �e�O�渹 */
    sprintf_s(stmt,sizeof stmt, "INSERT INTO cm_pre_receive \
                          (iins_cat,ipre_rcv,iins_kind,iins_kind_ply,ftype,ipre_end,iassured,nassured,iapplicant,napplicant,itag,iengine,deffect,paydate,mprem,isub,iofficer,ileader,iquota,icomm_obj,iroute,fcommit, ientry,dentry , isys,igroup,fstatus,iupdate,dupdate,ipolicy1,ipolicy2,iendorse,icard,dprint,dprint_rcv,iedr_return,ftype_pol,ftype_sp,dbegin,dend,fsend_msg,mobile_phone,ilast_policy ) \
                   VALUES ('C'     ,   ?    ,   ?     ,     ?       , 'P' ,  ' '   ,    ?   ,    ?   ,     ?    ,    ?     ,  ? ,   ?   ,   ?   ,   ?   ,  ?  ,  ? ,    ?   ,   ?   ,   ?  ,    ?    ,   ?  ,   ?   ,  ?    ,current,   ? , ' '  ,  10   ,   ?  ,current,  ' '   ,  ' '   ,  ' '   , ' ' , NULL , current  ,   '9'      ,    ?    ,?       ,?     ,?,   ?,         ?,           ?) ") ;
    $PREPARE prep_receive FROM $stmt;

    /* Insert �C��ú�O����� (ao_rcv_type) */
    /* �t�Xao_rcv_type�s�W�e�S��ú�ڴ���(paydate_ext)�f,���=�ͮĤ�  modify by sylvia 104.03.31 (1040319002_C1) */
    /* �ӷ��O	 �~��	ú�O�渹	ú�O�Ǹ�	�O�渹�X1	�O�渹�X2	��渹�X	�t�B���	����	�O�d���X	�w���s��	�����O�O	�Ȥ�s��	�Ȥ����	�O��W��	�s��H��	ú�O����	�S��ú�ڴ���    �����q�O	�g���H	x�g��H	�I�O	�I��	�J�b��	 */
    /*(��O=3)    �s�W���trcv_main (�O��100%) trcv(�O��-15��) modify by sylvia 104.02.25 */
    sprintf_s(stmt,sizeof stmt, "INSERT INTO ao_rcv_type \
                          (data_type , iyear , trcv , trcv_main , tseq , ipolicy1 , ipolicy2 , iendorse , ipre_end , times , icard , ipre_rcv , mprem , iassured , iassured_ext , nassured ,  userid , paydate , paydate_ext, isub  , ibroker , iofficer , insure_type , iins_kind , dpay ) \
                   VALUES (  '3'     ,   ?   ,   ?  ,  ?        , ?    ,   ' '    ,   ' '    ,    ' '   ,    ' '   ,  0    ,  ' '  ,     ?    ,   ?   ,    ?     ,     ' '      ,    ?     ,     ?   ,   ?     ,   ?   ,   ?        ,   ?     ,   ?      ,     'C'     ,     ?     , NULL ) ") ;
    $PREPARE prep_rcv_type FROM $stmt;

    /* Update �w���@�γ����� (cm_pre_receive) dprint_rcv ��null (�j�� + ���N�� update) */
    sprintf_s(stmt,sizeof stmt, "UPDATE cm_pre_receive Set dprint_rcv = NULL \
                    WHERE iins_cat = 'C' AND ipre_rcv = ? AND iins_kind matches '*' AND ipre_end = ' ' ") ;
    $PREPARE prep_upd_receive FROM $stmt;

    /* 102.05.15,�ĳq���O����01:�Q�O�I�HID�A02�G�����A03�G�������A04�G�q�����O�A05�G�D�q���N��(�]�w��{��car153)*/
    /* ca_premit �s�Wftype_sp: 10(���q�ĳq)20(�O�g�N), �u���a��Ѱ��ܧC��20-->10  modify by sylvia 103.12.01 (1031111001_C3) */
    sprintf_s(stmt,sizeof stmt, "SELECT count(*) FROM ca_permit \
                    WHERE (dexpire IS NULL OR dexpire > today) \
                      AND ftype_sp = ? \
   		      AND ( (iclass = '01' AND icode = ? ) OR \
   			    (iclass = '02' AND icode = ? ) OR \
   			    (iclass = '03' AND icode = ? ) OR \
   			    (iclass = '04' AND icode = ? ) OR \
   			    (iclass = '05' AND icode = (SELECT iroute_main FROM cm_route WHERE iroute = ? ) )  )") ;
    $PREPARE prep_permit FROM $stmt;

    /* 102.09.06  chk ���O�զX�_��?�I��*/
    sprintf_s(stmt,sizeof stmt, "SELECT count(*) FROM ply_ins_type_302 \
                    WHERE ipolicy =? and iins_type = ? and ori_dam_cover > 0");
    $PREPARE prep_chk_ori FROM $stmt;

    /* �]�����������I����,�ˮ֬O�_���ӫO����ӫ~, ������ӫ~��ú�ڴ����@�߬�106/01/31
         add by sylvia 105.12.08(1051206007_C1) */
    /* 105.12.09 �אּ106/01/31 */
    $select first 1 date('01/31/2017') into $D1060126 FROM systables WHERE tabid=1;

    sprintf_s(stmt,sizeof stmt, "SELECT count(*) FROM ply_ins_type_302  WHERE ipolicy = ? \
                      and iins_type in  ('85','105','118','119','120','121','122','123','125','126','111','112')");
    $PREPARE prep_chk_dmgins FROM $stmt;
    /*  --------------------------------------------------------------------- */

    /* ���o ���B�멳��� */
    sprintf_s(stmt,sizeof stmt, "SELECT '%02d/01/%d'::date,LAST_DAY('%02d/01/%d'::date) FROM systables WHERE tabid=1",
                  iplymonth,iplyyear,iplymonth,iplyyear);
    $PREPARE preLastDay FROM $stmt;
    $EXECUTE preLastDay INTO $sFirstDay,$sLastDay;
    printf("trace sFirstDay[%s]\n ",sFirstDay);
    printf("trace sLastDay[%s]\n " ,sLastDay);

    /* �����J�p */
    if((intopt==9)||( intopt == 25 )||( intopt == 55 )){
        /* [del intopt == 25]102.03 �w��5/1�ᤧ 5,6��|���X�椧��O���ơA�ɻ����O�X���ơA�H�Q���H�o��O�� 102.07���i�R��*/
        /* ��ӳ����J�p�覡�ɸ�� */
   	    strcpy(str," And a.ipolicy in (select ipolicy from newa00:ca_tmp_no) ") ;
    }else{
   	    strcpy(str," ");
    }

   /* ���N�M�ץ�W*�k�����ӥ�A�ݭn�ק�P�_����A�]
          �M�ץ�H*�g���ibigcomp �]�w��"A"�]�ζ��^ or "B"�]���ء^�A�|�Q�k�쨮�ӥ�F
          �M�ץ�W*��ibigcomp �]�w��" "�A�|�Q�k��D���ӥ�A�GSQL����n�אּ�ϥ�imgr
      (���Ӥ@���O)������A�hH* or W*�ұN��"���ӥ�"�]img=1�^*/
    if (fChoice[0]=='1'){
   	    strcpy(str1," AND b.imgr <> '1' ") ; /* car302(�����J�p�D���ӥ�) �I�s WriteToEstimate()�� */
    }else if (fChoice[0]=='2'){
        strcpy(str1," AND b.imgr = '1' ") ;      /* car302(�����J�p���ӥ�αM�ץ�) �I�s WriteToEstimate()�� */
    }else{
  	    strcpy(str1," ");  /* car302c �I�s WriteToEstimate()��, fChoice = " " */
    }

    /* �t�X�@�γ�������cm_pre_receive�s�Wiins_kind_ply���(�j��=C1,���N=C2
       add by sylvia 103.05.19 (1020111001_CG) */
    /* chk_I0 �P�_�O�_�����ĳq��(I0) add by sylvia 104.03.30 (1040312001_C1) */
    /* chk_I0 �s�W�ҥ~�޲z(�n�Lú�ڳ�) modify by sylvia 104.08.10 (1040805001_C1) */
    /* chk_I0 �����ҥ~�޲z(���ĳq��(I0)�����}�񲣻sú�ڳ�) modify by 061476 107.04.24 (1070116004_SC1) */

    sprintf_s( all_col_302 ,sizeof all_col_302,"%s %s %s %s %s %s %s",
             "a.ipolicy,a.fcard_class,'C'||trim(a.fcard_class),a.irelative_ply,a.nassured,",
             "a.comp_prem,a.dply_begin,a.dply_end,a.ilicense,nvl(a.iengine,' '),nvl(a.itag,' '),a.iofficer,nvl(a.ibig_comp,' '),",
             "a.ileader,a.iquota, a.v_prem,a.v_ori_prem,a.tot_prem,a.iroute,a.iapplicant,a.napplicant,a.icar_type, ",
             "a.freason_reject,a.fuw_status_ori,a.fuw_status_sug,a.mcomp_prem_sug,a.frenew_type,b.imgr,a.dply_begin,a.dply_end, ",
             "(select decode(iroute_dim2,'I0','Y','N') from cm_route where iroute = iroute_main \
                  and iroute = (select iroute_main from cm_route where iroute = a.iroute)), b.icomm_obj[1,2], ",
             " nvl(replace(trim(imovephone),'-'),' '),fassured, bzfrom, dply_begin, nvl(dbirth,' '), b.iupcomp,a.ipolicy[6,7], ",
             "a.ibig_sales,b.icomm_obj,(select iroute_main from cm_route WHERE iroute = a.iroute),a.tmobile_appl,a.aemail_appl,a.ipolicy[1,3] " );
    strcpy(all_col_302,trimx(all_col_302));

    /* 102.12.25 ���� "AND a.iofficer[1] <> 'W'"  ����*/
    sprintf_s(stmt_302,sizeof stmt_302,
        "   SELECT Year(a.dply_begin), %s \
              FROM policy_302 a,officer b \
             WHERE a.iofficer = b.iofficer \
               And a.dply_begin between '%s' and '%s' \
                %s %s \
          ORDER BY b.imgr, a.iquota, a.fcard_class, a.iofficer ",  all_col_302,sFirstDay,sLastDay,str,str1);

    fNoData = 'N';
    n = 0;  record_cnt = 0;

    strcpy(fsend_msg,"N");  /* �O�_�ǰe²�T: �w�]N,   Y:�@��� & �DJB & �ư������ιq�ʦۦ樮, ����D�ť� */

    printf("length: stmt_302=[%d] all_col_302=[%d]\n", strlen(stmt_302),strlen(all_col_302));
    printf("stmt_302=[%s]\n",stmt_302);

    $PREPARE  pre_stmt FROM $stmt_302;
    $BEGIN WORK;
    $DECLARE  cur_estimate CURSOR WITH HOLD FOR pre_stmt;

    $OPEN     cur_estimate ;
    while (1)
    {
        $FETCH cur_estimate
          INTO $iYear, $ipolicy,$fcard_class,$sIins_kind_ply,$irelative_ply,$nassured,
               $comp_prem, $dply_begin,$dply_end,$ilicense,$iengine, $itag, $iofficer,$ibig_comp,
               $ileader, $iquota, $v_prem,$v_ori_prem,$tot_prem,$iroute,$iapplicant,$napplicant,$icar_type,
               $freason_reject,$fuw_status_ori,$fuw_status_sug,$mcomp_prem_sug,$frenew_type,$imgr,
               $dbegin_302, $dend_302, $chk_I0, $sComm_obj, $mobile_phone, $fassured, $bzfrom, $cdate2, $dbirth1,
               $iupcomp1, $ipolicy67, $ibig_sales, $icomm_obj, $iroute_main, $tmobile_appl, $aemail_appl, $ipolicy13;

        if (SQLCODE == SQLNOTFOUND) {
            if (record_cnt==0)  fNoData = 'Y';
     	    break;
        }
        record_cnt++;


	strcpy( iroute   , trim(iroute));
	strcpy( iofficer , trim(iofficer));
	strcpy( ilicense , trim(ilicense));

	strcpy(fsend_msg,"N");  /* �O�_�ǰe²�T: �w�]N*/
	strcpy(mobile_phone_c," ");
	strcpy(mobile_phone, trim(mobile_phone));

        IsPlyB = 'N';

        strcpy( iquota      , trim(iquota));
        strcpy( ilicense_v  ," ");
        strcpy( s_dply_begin_comp," ");
        strcpy( ftype_pol   ," ");
        strcpy( ftype_sp    ,"PA");  /*  �t�X���O�X��104/01/01�W�u,�s�Wftype_sp��� add by sylvia 103.12.01 */

        strcpy( iofficer_comp ," "); strcpy( ileader_comp ," "); strcpy( iquota_comp ," ");
        strcpy( icomm_obj_comp   ," ");
        strcpy( iroute_comp   ," "); strcpy( ibranch_comp ," "); strcpy( isub_comp   ," ");

        strcpy(dply_bgn_comp," ");
        strcpy(dply_end_comp," ");
        strcpy(cm_dbegin," ");
        strcpy(cm_dend," ");

        fBothIns = -1;     /* �O�_�� "�j��+���N" �B���ۦP����B�ۦPID */
        fBothIns_sug = 0;  /* ��������,�����ĳ�j�� 0:�w�]����  4:�ŦX���� */
        freject_Z = 0;     /* ���N�I�O�_�ݩ�ګO���OZ (�������ΫO�B�W�L�{�����B) */
        strcpy(chk_renew_3,"N");    /* �w�]���ŦX: �ˮ֬O�_�ŦX�i�۰ʥX�� frenew_type=3�j���򥻱���: (1)�O�o�q��=10/40 (2)�DJB (3)���p[�j+��]����10/40  */
        strcpy(bzfrom_c," ");
        strcpy(iroute_c," ");
        fpayable = 0;  /* �O�_�ݩ�u�w�⥼�I���ڡv�W�� */
        cnt4750 = 0;   /* �O�_�P�ɩӫO�r�˰ӫ~*/
        cnt_chk10 = 0; /* �O�_�]�Ȥ��Ƥ����㤣�Lú�ڳ� */

        /* �r�˰ӫ~���i�P�ɩӫO add by 061476 108.04.09 (1080319007_SC3) */
        /* �վ�֫O���A505�W�h(�����r�ӫ~���i�P�ɩӫO������ mark by sylvia (1140522006_C01) */
        /* if ((strcmp(fcard_class,"2") == 0)&&((fuw_status_ori==500)||(fuw_status_sug==500)))
        {
        	$SELECT count(*) INTO $cnt4750
        	FROM ply_ins_type_302
        	WHERE ipolicy = $ipolicy
        	AND iins_type in ('47','49','50','56');

        	if (cnt4750 >= 2)
        	{
        		if (fuw_status_ori==500) fuw_status_ori = 505;
        		if (fuw_status_sug==500) fuw_status_sug = 505;
        	}
        } */

        /* ���ӫO�j���I�A�Y�n�O�H����Memail�Ҭ��Ū̡A���Lú�ڳ�
           ���]�m�bCHK_10����줴�n��ú�ڳ渹 add by 061476 109.05.14 (1090421003_SC1) */
        if ((strcmp(bzfrom,"10") == 0)&&
            ((strlen(trim(tmobile_appl))==0)&&(strlen(trim(aemail_appl))==0)))
        {
        	if ((strcmp(fcard_class,"1") == 0)||
        	    (strcmp(fcard_class,"2") == 0)&&(strlen(trim(irelative_ply))>0))
        	{
        		$SELECT count(*) INTO $cnt_chk10
        		   FROM car_code
        		  WHERE kind = 'RN' AND detail = 'CHK_10'
        		    AND detail2 = $ipolicy13;

        		if (cnt_chk10 == 0)
        		{
        			if (fuw_status_ori==500) fuw_status_ori = 505;
        			if (fuw_status_sug==500) fuw_status_sug = 505;
        		}
        	}
        }

        /* �ݡu�w�⥼�I���ڡv�W��̡A����ú�ڳ渹�ά�����car_renew_msg�� add by 061476 107.06.20 (1070522004_SC1)*/
	if ((strcmp(fassured,"1") == 0)||(strcmp(fassured,"3") == 0)||(strcmp(fassured,"5") == 0))
	{
	    $SELECT istl_obj,istl_obj_ext,nstl_obj,sum(mnt)
	       INTO $istl_obj,$istl_obj_ext,$nstl_obj,$mnt
	       FROM ao_pay_unpaid a,notes_payable b
	      WHERE dproc is null
	        AND a.iacc = b.iacc and a.iunpaid = b.ichk_no and a.istl_obj <> " "
	        AND istl_obj = $ilicense
	      group by 1,2,3;

	    if (SQLCODE != SQLNOTFOUND)
	    {
	    	fpayable = 1;

	    	sprintf_s(stmt,sizeof stmt, " insert into sysdb:car_renew_msg "
	    	              " select a.ipolicy, nvl(a.itag,' '), nvl(a.iengine,' '), a.ilicense, a.nassured, "
	    	              " a.icar_type,a.dply_begin, e.nbranch, a.ileader, d.nname, a.iofficer, c.nname, a.iroute, "
	    	              " b.nroute, nvl(a.iabn_type,' '), 'A', '�w�⥼�I����','A01','�w�⥼�I���ڤ���ú�ڳ渹','Y', "
	    	              " nvl(decode(a.iofficer[1,1],'J',ibig_sales,'B',ibig_sales,' '),' '), "
	    	              " case when a.iofficer[1,1] in ('B','J') then "
	    	              "       nvl((select nname from ca_big_office where fclass = '2' and ibig_comp = a.ibig_sales),' ') "
	    	              "       else ' ' end, '%s',current "
	    	              " FROM policy_302 a, cm_route b, officer c, officer d, sa_branch_type e "
	    	              " WHERE a.iquota = e.ibranch AND a.iroute = b.iroute "
	    	              " AND a.iofficer = c.iofficer  AND a.ileader = d.iofficer AND a.ipolicy = '%s' ",userid, ipolicy);

	    	$PREPARE pre_stmt FROM $stmt;
	    	$EXECUTE pre_stmt;

	    	if (fuw_status_ori==500) fuw_status_ori = 505;
	    	if (fuw_status_sug==500) fuw_status_sug = 505;
	    }
	}

	/* ---------------- Ū���~�ȭ��n���Ҧr�� ---------------- */
	/* �w��j���I����n���Ҧr�� add by 061476 108.07.19 (1080408005_SC3) */
	/* �¥��N�I�a�h�~�n���Ҧr�� modify by 061476 109.12.04 (1091013004_SC1) */
	/* ����N�]����̷s�n���Ҧr�� modify by 130956 (1130815004_C01) */
	/* �t�XKBTA��վ��^���W�h (1140108010_C02) */
	strcpy(ireg_no_tmp," "); strcpy(freg_no_chg,"N");
	if (strncmp(iroute,"KA",2) == 0)
	{
		$SELECT ilicence INTO $ireg_no_tmp
		   FROM cm_salesman_log
		  WHERE icomm_obj = $icomm_obj
		    AND dbusiness is null;

		if (SQLCODE == SQLNOTFOUND) strcpy(ireg_no_tmp," ");

		if ((strlen(trim(ireg_no_tmp))==0) || (strcmp(ireg_no_tmp,"10000")==0))
		{
			$SELECT ilicence INTO $ireg_no_tmp
			   FROM cm_salesman_log
			  WHERE icomm_obj = $ileader
			    AND dbusiness is null;

			if (SQLCODE == SQLNOTFOUND) strcpy(ireg_no_tmp," ");
		}

		strcpy(freg_no_chg,"Y");
	}
	else if (strncmp(iroute,"KB",2) == 0)
	{
		$SELECT ilicence INTO $ireg_no_tmp
		   FROM cm_salesman_log
		  WHERE icomm_obj = $icomm_obj
		    AND dbusiness is null;

		if (SQLCODE == SQLNOTFOUND) strcpy(ireg_no_tmp," ");

		strcpy(freg_no_chg,"Y");
	}
	else if ((strcmp(bzfrom,"10") == 0)||(strcmp(bzfrom,"40") == 0))
	{
		$SELECT ilicence INTO $ireg_no_tmp
		   FROM cm_salesman_log
		  WHERE icomm_obj = $ileader
		    AND dbusiness is null;

		if (SQLCODE == SQLNOTFOUND) strcpy(ireg_no_tmp," ");

		strcpy(freg_no_chg,"Y");
	}
	else if ((iofficer[0] == 'J')||(iofficer[0] == 'B'))
	{
		$SELECT ireg_no INTO $ireg_no_tmp
		   FROM ca_big_office
		  WHERE fclass = '2' and ibig_comp = $ibig_sales;

		if (SQLCODE == SQLNOTFOUND) strcpy(ireg_no_tmp," ");

		strcpy(freg_no_chg,"Y");
	}

	if (strcmp(freg_no_chg,"Y") == 0)
	{
		$EXECUTE prep_upd_302_ireg_no  using $ireg_no_tmp, $ipolicy;
		$EXECUTE prep_upd_302f_ireg_no using $ireg_no_tmp, $ipolicy;
	}

        /* �ק�M�ץ�g�����*/
        /* ��j�B����B�j+��  ���P�_(Start) ----------------------------------- */
        if (fcard_class[0] == '1'){

            t_count = 0;
            strcpy(mobile_phone_c, trim(mobile_phone));   /* �O�d�j���I����� */
            strcpy(dbirth2," ");
            strcpy(iupcomp2," ");
            strcpy(iroute2," ");
            strcpy(freason_reject2," ");

            if (strlen(trim(irelative_ply))>0){
                /* �t�X�O�o�q���X�s,���q���N����H��1�X���  (1060111005_C3) */
                /* �ק��ˮ֡G�O�o�q���N���������@�P�A�_�h������j/���  (1090430005_SC1) */
                /* �W�[�ˮ֡G�޲z�H�ݤ@�P  (1090616006_SC1) */
                strncpy(bzfrom1, bzfrom,1);
                bzfrom1[1,1] = '\0';

                $SELECT  first 1 ilicense,freason_reject,nvl(replace(trim(imovephone),'-'),' '),
                         nvl(dbirth,' '),iroute,
                         (select iupcomp from officer where iofficer = a.iofficer)
                   INTO  $ilicense_v, $freason_reject2, $mobile_phone, $dbirth2, $iroute2, $iupcomp2
                   FROM  policy_302 a
                  WHERE  ipolicy           = $irelative_ply
                    AND  YEAR(dply_begin)  = $iplyyear
                    AND  MONTH(dply_begin) = $iplymonth
                    AND  fcard_class       = '2'
                    AND  bzfrom = $bzfrom
                    AND  ileader = $ileader
                    AND ( iofficer[1] <> 'W' and not (iofficer[1] = 'H' and iofficer[2] not in ('0','1','2'))
                          and iofficer not in
                          (select unique iofficer_ori from ca_promote_officer where iofficer_ori[1] = 'N'));

                if (SQLCODE != SQLNOTFOUND) {
                    strcpy(mobile_phone, trim(mobile_phone));
           	        t_count = 1 ;
                }

                if (t_count==1){
                	strcpy(ilicense_v,trim(ilicense_v));
                	strcpy(iroute,trim(iroute));
                	strcpy(iroute2,trim(iroute2));
                	if (strcmp(ilicense, ilicense_v)!=0){
                		/* �j��B���N���P�O��,������j */
                		t_count = 0 ;
	                }else if (strcmp(dbirth1,dbirth2) != 0) {
	                	/* ���M�P�@ID,���ͤ餣�P,������j add by sylvia 105.08.16 (1050718003_C1, 1050714004_C1) */
	                	printf("�P�@ID,���ͤ餣�P,������j \n");
	                	t_count = 0 ;
	                }else if (strcmp(iupcomp1,iupcomp2) != 0) {
	                	/* �g�줣�P�Ұ�,������j add by sylvia 105.09.14 bug�ץ� */
	                	printf("�g�줣�P�Ұ�,������j \n");
	                	t_count = 0 ;
	                }else if ((freason_reject2[0]=='P')||(freason_reject2[0]=='7')||(freason_reject2[0]=='Y')||(freason_reject2[0]=='9')||
	                          (freason_reject2[0]=='Z')||(freason_reject2[0]=='B')){
	                        /* �֫O���A40,41 (freason_reject='Z') ���P�ګO�Ȥ�, ��өګO�Ȥ��z (1040624002_C1) */
	                        /* car102��10����Ӳ�9���A�����s��O�n�O�� (1071029004_SC3) */
	                        printf("trace ���N�I���ګO�B���`��, ������j \n ");
	                        t_count = 0 ;
	                        /* �ګO���OZ�ʽ���S���A�@�ߵ����@���(frenew_type=1) add by 061476 109.03.05 (1090214006_SC1) */
	                        if (freason_reject2[0]=='Z') freject_Z = 1;
	                }else if(((strncmp(iroute,"KA",2) == 0)||(strncmp(iroute2,"KA",2) == 0))&&(strcmp(iroute, iroute2) != 0)){
	                	/* KA*���P�q���N��,������j add by 061476 (1100719003_SC1)*/
	                	t_count = 0;
	                }else{
	                	printf("trace �j��B���N�P�O��\n ");
	                	continue; /* �j���I���p�����N�I�A���ۦP����B�ۦPID */
	                }
	        }
            }
            if (t_count==0)
            {
                strcpy(mobile_phone, trim(mobile_phone_c));   /* �٭����� */

                fBothIns = 1;  /* (����)��j */
                strcpy(dply_bgn_comp,dbegin_302);
                strcpy(dply_end_comp,dend_302);

                if ((strcmp(imgr,"2") == 0) && (strncmp(iroute,"JB",2) != 0) &&
                    (strlen(mobile_phone) == 10) && (strncmp(mobile_phone,"09",2)==0) && (ISMOT(icar_type)==0) && (strcmp(icar_type,"35") != 0) && (strcmp(fassured,"1") == 0) )
                {
                    strcpy(fsend_msg,itoa(fBothIns)); /* �אּN:���o  1:��j  2:���  3:�j+�� modify by sylvia 105.06.04*/
                }

                /* �O�o�q��10/40 �B �q���N�� <> 'JB' , �C�� �i�۰ʥX�����O�j, chk_renew_3 = Y add by sylvia  */
                /* ���׫�ĳ�έ��O,�u�n���@��>=500, �N�i�H�C���۰ʥX�� 10505/03 ౻T�T�{ */
                /* �w��JB�q����O���O�ץ�--�אּ�۰ʥX��(frenew_type = '3'  modify by sylvia 105.07.29 (1050728007_C1) */
                if (((strcmp(bzfrom,"40") == 0) ||(strcmp(bzfrom,"41") == 0)||(strcmp(bzfrom,"10") == 0)) &&
                    ((fuw_status_ori >= 500) || (fuw_status_sug >= 500)))
                {
                    strcpy(chk_renew_3,"Y");
                }
                else
                {
                    strcpy(chk_renew_3,"N");
                }

            }

        }
        else
        {
            /* �ګO��β��`�� */
            /* �֫O���A40,41 (freason_reject='Z') ���P�ګO�Ȥ�, ��өګO�Ȥ��z modify by sylvia 104.06.30 (1040624002_C1) */
            /* car102��10����Ӳ�9���A�����s��O�n�O�� add by 061476 107.11.27 (1071029004_SC3) */
            if ((freason_reject[0]=='P')||(freason_reject[0]=='7')||(freason_reject[0]=='Y')||(freason_reject[0]=='9')||
                (freason_reject[0]=='Z')||(freason_reject[0]=='B'))
     	  	    continue;

            if( (iofficer[0]=='W') || (iofficer[0] == 'H' && (iofficer[1]!='0' && iofficer[1]!='1' && iofficer[1]!='2'))){
                IsPlyB = 'Y';
            }
            else if (iofficer[0]=='N')
            {
            	/* �O�_���M���B�� (N�g��N��) --------------------------------------------------------*/
            	cnt_prmt = 0;
            	$select count(*) into $cnt_prmt from ca_promote_officer where iofficer_ori = $iofficer;
            	if (cnt_prmt > 0) IsPlyB = 'Y';
            	/*---------------------------------------------------------------------------------------*/
            }
            strcpy(mobile_phone_c," ");
            t_count = 0;
            strcpy(imgr_c," ");
            strcpy(bzfrom_c," ");
            strcpy(dbirth2," ");
            strcpy(iupcomp2," ");
     	    if (IsPlyB =='N'){
                if (strlen(trim(irelative_ply))>0){
	                /* ���o�j���I�O��ID*/
	                /* �t�X�O�o�q���X�s,���q���N����H��1�X��� modify by sylvia 106.01.25 (1060111005_C3) */
	                /* �ק��ˮ֡G�O�o�q���N���������@�P�A�_�h������j/��� modify by 061476 (1090430005_SC1) */
	                /* �W�[�ˮ֡G�޲z�H�ݤ@�P add by 061476 (1090616006_SC1) */
	                strncpy(bzfrom1, bzfrom, 1);
	                bzfrom1[1] = '\0';

	                $SELECT  first 1 ilicense,dply_begin,comp_prem,mcomp_prem_sug,
	                         a.iofficer, a.ileader, a.iquota, a.iroute,
	                         dply_bgn_comp,dply_end_comp,nvl(replace(trim(imovephone),'-'),' ') ,
	                         (select imgr from officer where iofficer = a.iofficer),
	                         bzfrom, nvl(dbirth,' '),
	                         (select iupcomp from officer where iofficer = a.iofficer)
	                   INTO  $ilicense_v,$s_dply_begin_comp,$comp_prem,$mcomp_prem_sug,
	                         $iofficer_comp, $ileader_comp, $iquota_comp, $iroute_comp,
	                         $dply_bgn_comp, $dply_end_comp, $mobile_phone_c, $imgr_c,
	                         $bzfrom_c, $dbirth2, $iupcomp2
	                   FROM  policy_302 a
	                  WHERE  ipolicy           = $irelative_ply
	                    AND  YEAR(dply_begin)  = $iplyyear
	                    AND  MONTH(dply_begin) = $iplymonth
	                    AND  fcard_class       = '1'
	                    AND  bzfrom = $bzfrom
	                    AND  ileader = $ileader;
	                if (SQLCODE != SQLNOTFOUND) {
	                	t_count = 1 ;
	                	strcpy(mobile_phone_c, trim(mobile_phone_c));
	                }

	                if (t_count==1){
	                	strcpy(ilicense_v,trim(ilicense_v));
	                	strcpy(iroute,trim(iroute));
	                	strcpy(iroute_comp,trim(iroute_comp));
	                	if (strcmp(ilicense, ilicense_v)!=0){
	                		t_count = 0 ;    /* �j��B���N���P�O��,������� */
		                }else if(strcmp(dbirth1,dbirth2) != 0){
		                	t_count = 0 ;    /* �PID,���P�ͤ�,������� add by sylvia 105.08.16 (1050718003_C1, 1050714004_C1) */
		                }else if(strcmp(iupcomp1,iupcomp2) != 0){
		                	t_count = 0 ;    /* �g���ҰϤ��P,������� add by sylvia 105.09.14 bug�ץ� */
		                }else if (((strncmp(iroute,"KA",2) == 0)||(strncmp(iroute_comp,"KA",2) == 0))&&(strcmp(iroute, iroute_comp) != 0)){
		                	t_count = 0;     /* KA*���P�q���N��,������� add by 061476 (1100719003_SC1) */
		                }
		        }
                }
            }
            if (t_count==0)
            {
                fBothIns = 2;  /* (����)����N */

                /* �Y������N�A�n�N�j��O�O�k�s (1130912002_C01) */
                comp_prem = 0;
                mcomp_prem_sug = 0;

                strcpy(mobile_phone_c," "); /* �M�űj���I��� */
                /* 1080819 ����barcode�㨮���ѱM��,����N(�L���p��)��ĳ�j���I add by sylvia (1030806002_C1) */
                if (ISMOT(icar_type) && strcmp(icar_type,"35") != 0 )
                {
	                $SELECT count(*) INTO $t_count
	                   FROM tmp_barcode_officer
	                  WHERE icode_no='MOTOR20' AND (iofficer = $iofficer Or iofficer = $iroute);

	                if ((t_count>0) && (strlen(trim(irelative_ply))==0) && (mcomp_prem_sug > 0) && (comp_prem == 0))
      	                fBothIns_sug = 4 ; /* �����㨮���ѥB����N,�|��ĳ�j���I */
                }

	        strcpy(dply_bgn_comp,dbegin_302); /* �]�������ĳ�j��, �ҥH��j���I�_��=���N�I�_�� */
                strcpy(dply_end_comp,dend_302);   /* �]�������ĳ�j��, �ҥH��j���I����=���N�I���� */

                if ((strcmp(imgr,"2") == 0) && (strncmp(iroute,"JB",2) != 0) &&
                    (strlen(mobile_phone) == 10) && (strncmp(mobile_phone,"09",2)==0) && (ISMOT(icar_type)==0) && (strcmp(icar_type,"35") != 0) &&
                    (strcmp(icar_type,"51") != 0) && (IsPlyB =='N') && (strcmp(fassured,"1") == 0))
                {

                    strcpy(fsend_msg,itoa(fBothIns)); /* �אּN:���o  1:��j  2:���  3:�j+�� modify by sylvia 105.06.04*/

                }

                /* �O�o�q��10/40 �B �q���N�� <> 'JB' , �C�� �i�۰ʥX�����O�j, chk_renew_3 = Y add by sylvia  */
                /* �w��JB�q����O���O�ץ�--�אּ�۰ʥX��(frenew_type = '3'  modify by sylvia 105.07.29 (1050728007_C1) */

                if (((strcmp(bzfrom,"40") == 0)||(strcmp(bzfrom,"41") == 0)||(strcmp(bzfrom,"10") == 0)) &&
                    ((fuw_status_ori >= 500) || (fuw_status_sug >= 500)))
                {
                    strcpy(chk_renew_3,"Y");
                }
                else
                    strcpy(chk_renew_3,"N");

            }
            else
            {
                fBothIns = 3;  /* ���N+�j��G�j���I���p�����N�I�A���ۦP����B�ۦPID */

                strcpy(mobile_phone, trim(mobile_phone));
                strcpy(mobile_phone_c, trim(mobile_phone_c));

                if (strcmp(imgr, imgr_c) != 0)
                {
                    /* �j+��, �Y���ݨ��ӤΤ@���, �h�@�ߤ��o²�T add by sylvia 105.04.27(౻T�q��) */
                    strcpy(fsend_msg,"N");
                    strcpy(mobile_phone, " ");
                    strcpy(chk_renew_3,"N");
                }
                else
                {
                    if ((strcmp(imgr,"2") == 0) && (strncmp(iroute,"JB",2) != 0) && (strcmp(icar_type,"35") != 0) &&
                        (ISMOT(icar_type)==0) && (strcmp(fassured,"1") == 0))
                    {
                        if ((strlen(mobile_phone) == 10) && (strncmp(mobile_phone,"09",2)==0))
                        {
                            strcpy(fsend_msg,itoa(fBothIns)); /* �אּN:���o  1:��j  2:���  3:�j+�� modify by sylvia 105.06.04*/

                        }
                        else if ((strlen(mobile_phone_c) == 10) && (strncmp(mobile_phone_c,"09",2)==0))
                        {
                            strcpy(mobile_phone, trim(mobile_phone_c)); /* ���N�I�L�����, �H�j���I������a�J */
                            strcpy(fsend_msg,itoa(fBothIns)); /* �אּN:���o  1:��j  2:���  3:�j+�� modify by sylvia 105.06.04*/
                        }
                        else
                        {
                            /* �L���Ī������,�����L��� */
                            strcpy(mobile_phone, " ");
                            strcpy(fsend_msg,"N");
                        }

                    }

                    /* �O�o�q��10/40 �B �q���N�� <> 'JB' , �C�� �i�۰ʥX�����O�j, chk_renew_3 = Y add by sylvia  */
                    /* 1.	�j+���䤤�@����20/30/90�q��,�@�߬��D�۰ʥX��,���ޮ֫O���A��
                       2.	�j+������10/40�q��,�u�n���@����>=500���A���ݦ۰ʥX�愻  105.05.03 �ӫO౻T�q��*/
                    /* �w��JB�q����O���O�ץ�--�אּ�۰ʥX��(frenew_type = '3'  modify by sylvia 105.07.29 (1050728007_C1) */
                    /* if (((strcmp(bzfrom,"40") == 0) && (strncmp(iroute,"JB",2) != 0)) || (strcmp(bzfrom,"10") == 0)) */
                    if ((strcmp(bzfrom,"40") == 0) ||(strcmp(bzfrom,"41") == 0)|| (strcmp(bzfrom,"10") == 0))
                    {

                        if ((strcmp(bzfrom_c,"40") == 0) ||(strcmp(bzfrom_c,"41") == 0)|| (strcmp(bzfrom_c,"10") == 0))
                        {
                            if ((fuw_status_ori >= 500) || (fuw_status_sug >= 500))
                                strcpy(chk_renew_3,"Y");
                            else
                                strcpy(chk_renew_3,"N");
                        }
                        else
                           strcpy(chk_renew_3,"N");
                    }
                    else
                         strcpy(chk_renew_3,"N");
                }
            }
        }/* ��j�B����B�j+��  ���P�_(END) ----------------------------------- */
        /*--------------------------------------------------------------------------------------------- */

        /* 102.12.25,�ק郞�ӥ�P�_*/
	/*if ((ibig_comp[0]==' ')||(ibig_comp[0]=='')||(ibig_comp[0]=='\0')||(ibig_comp[0]=='*')){*/
	if (imgr[0]!='1'){
	    strcpy(fcommit,"N");     /* �����O  N:�@�� */
	}else{
	    if (IsPlyB!='Y'){
	        strcpy(fcommit,"1");  /* �����O  1:�j�v */
	    }else{
                if (iofficer[0]=='N')
                    strcpy(fcommit,"1");  /* B��N�g�� �����O�� "1:�j�v"  */
                else
	 	    strcpy(fcommit,"N");  /* B��(W*�BH*)�����O�� "N:�@��"  */
	    }
        }
	printf("trace fcommit[%s]\n ",fcommit);

        /*--------------------------------------------------------------------------------------------- */
        /* [102.07.01] �w�����W�u�G�@�ߥ����O���ĳq��:SP */
        /* 102.05,check�O�_���ĳq�� */
        #if _VERSION == _VER_PRE
            printf("trace _VER_PRE\n" );
            iCount = 1;
        #elif _VERSION == _VER_OK
            printf("trace _VER_OK\n" );

            strncpy(iroute12,iroute,2);
            iroute12[2]='\0';
            iCount = iCount_20 = iCount_10 = 0; Is_SP = 'N';
            printf("ilicense=[%s]itag=[%s]iengine=[%s]iroute12=[%s]iroute=[%s]\n",ilicense,itag,iengine,iroute12,iroute);

            $EXECUTE prep_permit INTO $iCount_10 using "10", $ilicense, $itag, $iengine, $iroute12, $iroute;

            if (iofficer[0] != 'W')
                $EXECUTE prep_permit INTO $iCount_20 using "20", $ilicense, $itag, $iengine, $iroute12, $iroute;
        #endif

        if (iCount_20 > 0){
     	    Is_SP = 'Y' ;   /* �S�O�ĳq��_�O�g�N */
     	    strcpy(ftype_pol, "SP" );
     	    strcpy(ftype_sp, "20" );
        }else if (iCount_10 > 0){
     	    Is_SP = 'Y' ;   /* �S�O�ĳq��_�O�g�N */
     	    strcpy(ftype_pol, "SP" );
     	    strcpy(ftype_sp, "10" );
        }

        if (strncmp(ipolicy+(5),"EB",2)==0)
        {
            strcpy(ftype_pol, "NA" );
            strcpy(ftype_sp, "EB" );
        }

        if (strncmp(ipolicy+(5),"ES",2)==0)
        {
            strcpy(ftype_pol, "NA" );
            strcpy(ftype_sp, "ES" );
        }

        /**************  �T�{�O�_�� barcode��Abarcode�� frenew_type = '2' ********************************/
        /* �s�W �i�۰ʥX�����O frenew-type = '3'�j add by sylvia 105.04.27 (1050321006_C2)
             ����: 1.�O�o�q��=10(�~�ȭ�) �� 40(�����~��)
                   2.�ư�JB
                   3.�ư�[�j+��]���@�O�椣��10/40��                   */
        fChk_bc1 = 'N';
        Is_JC = 'N';
        Is_PrintBC = 'Y'; /*102.11.08, ��O�n�O�ѬO�_�L���X(�w�]�n) */

        if (strcmp(chk_renew_3,"Y") == 0)
        {
            strcpy(frenew_type,"3");    /* ���ŦX �۰ʥX�� ����(chk_renew_3), frenew_type = 3 */
        }
        else
        {
            frenew_type[0] = '1';  frenew_type[1] = '\0';   /* �@����O�� */
        }


        /* barcode ��P�_(Start) ------------------------------------------------------------------------*/
        if (imgr[0]!='1')
        {

            /* �@���(�D���ӥ�) */

            /*------------------------------  �� check �O�O�_��barcode��  ��   ----------------------------*/

            /***** 1. check �O�_�� car147 barcode (�T�������|��) *****/
            /* 970725, �_�ݭn�L�sbarcode�~,�A�L��O�q����,��car147�]�w�M�w */
            fBarcode_print[0] = ' '; fBarcode_print[1] = '\0';

            $EXECUTE preBarcode_off INTO $icode_no,$fBarcode_print using $iofficer,$iroute;

            if (SQLCODE != SQLNOTFOUND)
            {
                if (strcmp(frenew_type,"3") != 0) /* �D�۰ʥX���~�|�ন barcode��, �۰ʥX�����barcode�� */
                {
                    /* 101.10,�� car147 barcode �����ŦX tpl_code ����̡A �@�߰���O�q���� */
              	    if (strncmp(icode_no,"TPL_CODE",8)==0)
              	    {
                        if (fcard_class[0] == '1')
                        {
                            /* ��TPL_CODE�]�w���q���B����j��(�ε�����j��)�̡A�Y�@�ߵ����� tpl barcode ��*/
                            /* ����08���ت�����   modify by sylvia 105.03.23 (1050317003_C1) */
                            if (((strcmp(icar_type,"14") == 0)||(strcmp(icar_type,"21") == 0))
                                && (chk_PA > 0))
                            {
                                printf("����14,21���Lbarcode");/* add by sylvia 104.01.26 */
                            }
              	            else
              	            {
           	                frenew_type[0] = '2';  frenew_type[1] = '\0';
              	            }
                        }
                        else
                        {
                            iCount = 0;
                  	    $EXECUTE prep_tpl_chk INTO $iCount using $ipolicy;
                  	    if (iCount>0)
                  	    {
                  	    	/* �ŦX tpl_code => barcode*/
                  	        frenew_type[0] = '2';  frenew_type[1] = '\0';
                  	    }
              	        }
              	    }
              	    else if (strncmp(icode_no,"EB00000",7) ==0)
              	    {
              	    	/* �q�ʦۦ樮��X�O�I */
                    }
                    else
                    {
                        /*car147�]�w���q����A���Dtpl barcode */
                        /* ����08���ت�����   modify by sylvia 105.03.23 (1050317003_C1) */
                        if (((strcmp(icar_type,"14") == 0)||(strcmp(icar_type,"21") == 0))
                             && (chk_PA > 0))
                        {
                            printf("����14,21���Lbarcode");/* add by sylvia 104.01.26 */
                        }
                        else
                        {
                            frenew_type[0] = '2';  frenew_type[1] = '\0';
                            fChk_bc1 = 'Y'; /* ���i��|�ӫO�����I���q��barcode�� */
                        }
                    }
                }
            }
            else
            {
                if (strncmp(icar_type,"51",2) ==0)
                {
                    if (strcmp(frenew_type,"3") != 0)
                    {
          	        frenew_type[0] = '2';
          	        frenew_type[1] = '\0';
          	    }
          	}
                /* [102.07.01] �w�����W�u�G���F���Ю׳]�w�����W�u�A�Y�A�N����"�L�F���Юץ�"�A�h�|�@���k���ĳq�� */
          	/* �P�_�O�_���F���Ю� */
		/*102.03 �F���Юפ@�߬� ��O�q���� + �q���� */
		/*       �q���N���GJC* �B�O��ID���]�w��car_code(kind=��26��) */
      	        rc = 0;
      	        if (strncmp(iroute,"JC",2)==0){
                    rc = do_car_code('Q',"26",ilicense," "," "," ",2,userid);
      	  	    if (rc==1)  {
      	  	         Is_JC = 'Y';
      	  	         /* �t�X���O�X��104/01/01�W�u,�ק�F���Ю�ftype_pol=NA,ftype_sp = JC   modify by sylvia 103.12.01(1031111001_C3) */
      	  	         strcpy(ftype_pol, "NA" );
      	  	         strcpy(ftype_sp, "JC" );
      	  	    }
      	  	}

     	        /***** 2. check �O�_�� �D���Ӿ���barcode *****/
     	        /* 101.10 �A�]��tpl barcode, �D���Ӿ���barcode �]�t�@�~���ΤG�~�� */
                if (ISMOT(icar_type) ){
                        /* �M���O�g �n�L��O�q����*/
 	                if (!((iofficer[0]=='Y')&&(strSearchReplace(iofficer,"VK","VK")>0))){
              	        /* SUM �@�߬� ��O�q���� + �q���� */
              	        /* EASYCAR ��� SUM ��z add by sylvia 105.08.06 (1050804003_C1) */
              	  	    if ((!(ISSUM(iroute))) && (!(ISEASYCAR(iroute)))){
                                if ( (ISCHAILEASE(iroute)) || (ISFEI(iroute)) ||(ISGOSUN(iofficer,iroute))||(ISPONYRENT(iofficer,iroute)) ||
                                     (ISTOKYO(iofficer,ilicense))||(ISUFLC(iroute))||(ISSHING(iroute))||(ISJIHSUN(iroute)) ||
                                     (ISAVIS(iroute))||(ISPRO(iroute)))
                                {
                                    /*�o�ǯ�����H�o��O�q���Ѥ�barcode*/
                                }else{
                                    if (Is_JC=='N'){
                                    /* �D���Ӿ���barcode�P�_ */
		                        if (strncmp(icar_type,"32",2) !=0){ /* 32���ؤ��� barcode */
		                            if (fcard_class[0] == '2'){
                                            /* �����N�I :���ܸӵ�������N�αj��+���N�A
		                                        (1)����N(�Lirelative_ply) => ����barcode
		                                        (2)�j��+���N(��irelative_ply) => �n��barcode(���N���i�t������ѵs)*/
		                            /*���j��B���N�̡A���������ۦP����~��A�B�ۦP�Q�O�I�H(���L��)
		                              �䤤���@���ມ���̡A�h����O�q���ѡA����barcode */
		                            /*(�Y���ມ���A�����|��������N�A����N����[�J"��jbarcode")*/
		                                if (fBothIns ==3){
		                      	            iCount = 0 ;
		                      	            $EXECUTE prep_chk01_11 INTO $iCount USING $ipolicy; /* chk �O�_����������ѵs*/
		                      	            if (iCount==0){
		                      	                /*---- �ˮ֦ܦ��� "�D���Ӿ���barcode�B���H�o��O�q����" �� ----*/
		                      	                if (strcmp(frenew_type,"3") != 0)
		                      	                {
		                      	                    frenew_type[0] = '2';  frenew_type[1] = '\0';
		                      	                }
		                      	            }
		                          	}
		                            }else{
		                            /* ���j���I�A���ܬ�"��j"�άO"�j��+���N���O���P����~��Τ��P�O��ID"
			          	       �o�ǳ�������j�A�|��ĳ 47 �B��barcode    */
			          	        if (strcmp(frenew_type,"3") != 0)
			          	      	{
			          	      	    frenew_type[0] = '2';  frenew_type[1] = '\0';
			          	      	}
			          	    }
                                        }
                                    }
                                }
                            }
                        }
                /***** 3. check �O�_�� �D���ӨT�� ��j(or +50�I)barcode *****/
                } else {

                    /* 980616 ,�T����O�j�� => ��ĳ50�I�� => ���F���s��barcode*/
      	            /*   ����G�Ҧ��@��� �]���~�G �^*/
                    /*   ���ءG07�B03�B04�B06�B10�B12�B13�B15�B19�B20�B21�B22�B30  */
                    /*        Z12010C(�T���I������O)��car147�]�w���Ȧ�q�����ǤJ��barcode���s,������q����+�q���� */
  	            /* 101.10 �A�ק� "�A��50�I�ؤ�����" �P�_�覡  */

  	            iCount = 0;
  	            $Execute preIns50_cartype INTO $iCount Using $icar_type;
                    if (iCount > 0)
                    {
              	        /* SUM �@�߬� ��O�q���� + �q���� */
              	        /* EASYCAR ��� SUM ��z add by sylvia 105.08.06 (1050804003_C1) */
              	  	if ((!(ISSUM(iroute))) && (!(ISEASYCAR(iroute))))
              	  	{
              	  	    /* �s�W:��L����(�T��) ���H�o��O�q���Ѥ�barcode add by sylvia 104.01.23 (1040114003_C1) */
                            if ((ISCHAILEASE(iroute)) || (ISFEI(iroute)) ||(ISGOSUN(iofficer,iroute))||(ISPONYRENT(iofficer,iroute)) ||
                                (ISTOKYO(iofficer,ilicense))||(ISUFLC(iroute))||(ISSHING(iroute))||(ISJIHSUN(iroute))||
                                (ISAVIS(iroute))||(ISPRO(iroute)))
                            {
                                /*�o�ǯ�����H�o��O�q���Ѥ�barcode*/
                            }
                            else
                            {
                                if ((chk_PA > 0) && ((ISCAR_SET2(icar_type)) || ((strncmp(iroute,"PA",2) == 0) && (strcmp(icar_type,"51") != 0))))
                                {
                                    /* �U�C�G����car140�]�w(kind = RN, detail=CHK_PA, detail2:�ư���), ���H�o��O�q���Ѥ�barcode */
                                    /* 1.��L����(�T��):PA* + �T��(���t�����ιq�ʦۦ樮) */
                                    /* 2.�D����~,�O07,15,14,21  */
                                }
                                else if (Is_JC=='N')
                                {
		                    /* �b tmp_no_barcode_list ����,����barcode, ����O�q����+�q����覡 */
		                    tmp_Count = 0;
		                    $Execute preNo_barcode INTO $tmp_Count Using $iofficer;
                                    if( tmp_Count == 0)
                                    {
		                        if (fcard_class[0] == '2')
		                        {
		                            /*���j��B���N�̡A���������ۦP����~��A�B�ۦP�Q�O�I�H(���L��)
		                              �䤤���@���ມ���̡A�h����O�q���ѡA����barcode */
		                            /*(�Y���ມ���A�����|��������N�A����N����[�J"��jbarcode")*/
		                            if (fBothIns ==3)
		                            {
		                      	        iCount = 0 ;
		                      	        $EXECUTE prep_check_ins INTO $iCount USING $ipolicy,"50";  /*�h�~�u�O21+50�̥B��ĳ�I�ؤ����t�����ѵs�̡A��[�J�T����jbarcode */
		                      	        if ((iCount>0) && (strcmp(frenew_type,"3") != 0))
		                      	        {
		                      	            /*---- �ˮ֦ܦ��w�ŦX�T����jbarcode ------*/
		                      	            frenew_type[0] = '2';  frenew_type[1] = '\0';
		                      	        }
		                            }
		                        }
		                        else
		                        {
		                            /* �ܦ������j��A���ܬ�"��j"�άO"�j��+���N���O���P����~��Τ��P�O��ID"
		                               �o�ǳ�������j�A�|��ĳ 50 �B��barcode    */
		                            if (strcmp(frenew_type,"3") != 0)
		                            {
		                                frenew_type[0] = '2';  frenew_type[1] = '\0';
		                            }
		                        }
		                    }
                                }
                            }
                        }
                    }
                }
            }

            /* �ګO���OZ�@�ߵ����@���(frenew_type=1) add by 061476 109.03.05 (1090214006_SC1) */
            if (freject_Z == 1)
            {
            	strcpy(frenew_type,"1");
            }

            /**********  �T�{��barcode ��A�^��frenew_type='2'�A�f�֪��A = 500 ,    ******************************/

	    if (frenew_type[0] == '2'){
                /* 102.10.18
                �w��Ȧ����O���BARCODE��ŦX�H�U���O�����,�@�ߤ����s��OBARCODEú�ڭn�O��,�����ݲ��s�j���I����q����!
                1.��O��O�զX���e�F�{������(�t�μf�֤��q�L��]�N�X10)
                2.�Q�O�I�T���ݶ]���ΦW�Q�}��������(�t�μf�֤��q�L��]40)
                  (��ca302q01s.ec�����w�j���I���t�μf�֪��A�@�߬�500�A�G�p�G�O��jbarcode�A���|�� <500�����A�A
                  �Y��j���|�����O���󭭨�)  */
                /* �p�{���ί���]���o�^�����A  add by sylvia 104.02.11 */
                /* 38,39�I���ˮ�, �]���^�����A  add by sylvia 104.04.22 (�\���q�ܳq��) */
                /* �ګO���O��P�B7�B9�]���^�����A add by 061476 107.01.23*/
                /* ���Lú�ڳ�N���n�A�^�����A add by 061476 108.04.26 (�\���q�ܳq��) */
                /* ����130�B131�֫O���A modify by 061476 110.04.01 (1100119001_SC3) */
                printf("����1214:ipolicy=[%s]fuw_status_sug=[%d],fuw_status_ori=[%d]frenew_type=[%s]\n",ipolicy,fuw_status_sug,fuw_status_ori,frenew_type);
                if ((fuw_status_ori != 10)&&(fuw_status_ori != 40)&&(fuw_status_ori != 41)&&
                    (fuw_status_ori != 180)&&(fuw_status_ori != 140)&&(fuw_status_ori != 20)&&
                    (fuw_status_ori != 505)) fuw_status_ori = 500 ;
	 	if ((fuw_status_sug != 10)&&(fuw_status_sug != 40)&&(fuw_status_sug != 41)&&
	 	    (fuw_status_sug != 180)&&(fuw_status_sug != 140)&&(fuw_status_ori != 20)&&
	 	    (fuw_status_ori != 505)) fuw_status_sug = 500 ;

                /*102.09.06 : 03 04 19 21 22���ءA�h�~��05��,2p�B5p���Lú�ڳ�
	 		                  barcode��(�D�n���Ȧ�barcode)���i�঳05�I�ءA�åB���L2p��O�n�O�ѡA�]���Lú�ڳ�  */
	 	if (fChk_bc1=='Y'){
	 		tmp_Count = 0;
	 		/* �t�X���O�X��104/01/01�W�u,�h�~��05�I,���n�C�Lú�ڳ�,�G���d�h�~�O�_�ӫO05�I��,tmp_Count = 0  modify by sylvia 103.12.16 (1031209009_C1) */
	 		/* $EXECUTE prep_chk_ori INTO $tmp_Count USING $ipolicy,"05"; */
	 		if( tmp_Count > 0){
	 			fuw_status_ori = 505 ; fuw_status_sug = 505 ;
	 		}
                }

                if (fpayable == 1)  /* �w�⥼�I���ڤ��Lú�ڳ� */
                {
                    if (fuw_status_ori==500) fuw_status_ori = 505;
                    if (fuw_status_sug==500) fuw_status_sug = 505;
                }

            }

        }   /* barcode ��P�_(END) */
        printf("trace frenew_type[%s] \n " , frenew_type);
        printf("trace fuw_status_ori[%d] fuw_status_sug[%d]\n ",fuw_status_ori,fuw_status_sug);

        /* ���ĳq��(I0)�D��j��(�Y�����N�I�O�O��),���Lú�ڳ�,���e�~�C�L add by sylvia 104.03.30 */
        /* ���ĳq��(I0)�����}�񲣻sú�ڳ�A�������e�~�C�L modify by 061476 107.04.24 (1070116004_SC1) */
        /* BUG�G�P�\���T�{�A�Y�ݩ���O���O���i3:�۰ʥX��j���^�����@����O�� modify by 061476 107.06.12 */
        /* printf("15959:chk_I0=[%s]fBothIns=[%d]fuw_status_ori=[%d]fuw_status_sug=[%d]\n",chk_I0,fBothIns,fuw_status_ori,fuw_status_sug); */
        if (strcmp(chk_I0,"Y") == 0 && strcmp(frenew_type,"3") != 0)
        {
            if ((fuw_status_ori==500) && (fBothIns > 1))
            {
                /* fuw_status_ori = 505; */
                strcpy(frenew_type,"1");  /* 1:�@����O��(���e�~�C�L) */
            }

            if ((fuw_status_sug==500) && (fBothIns > 1))
            {
                /* fuw_status_sug = 505; */
                strcpy(frenew_type,"1");  /* 1:�@����O��(���e�~�C�L) */
            }
	}

	/* ���Ȥ@�ߤ��Lú�ڳ�A�G�b���Nfrenew_type�㦨 1:�@����O�� add by 061476 107.04.26 (1070116004_SC1) */
	if (strncmp(iroute,"I009",4) == 0)
	{
	   strcpy(frenew_type,"1");
	}

        /*
        if ((fuw_status_ori < 500) && (fuw_status_sug < 500)) continue; /* �G�ӧ�O�զX�ҥ��q�L�t�μf�� ���g�J������ */

        /**********  �ǳƼg�J "�w���@�γ����� (cm_pre_receive)�B�C��ú�O����� (ao_rcv_type)"   ***************/
        /* �P�_�O�_�C�Lú�ڳ�(Start) ----------------------------------------------------------------------- */
        if ((frenew_type[0] == '1') || (frenew_type[0] == '3'))
        {/* �Dbarcode�� */

            if (imgr[0]!='1')
            {/* �D���� */
                /* 102.11.05 check �O�_���]�w���L�s���X����� */
                rc = 0;
                strncpy(iquota1_4,iquota,4); iquota1_4[4] = '\0';
                /* �t�X���O�X��104/01/01�W�u, �Ҧ����@�ߦL�sú�ڳ� mark by sylvia 103.12.01 (1031111001_C3) */
	 		    /* rc = do_car_code('Q',"RN","CAR302_BC",iquota1_4," "," ",3);
      	        if (rc==1)  {
    	  	        Is_PrintBC = 'N';
      	        } */
      	        /* �t�X���O�X��104/01/01�W�u, ��H�I����H�P�_�O�_�L�sú�ڳ� mark by sylvia 103.12.01 (1031111001_C3) */
      	        iCount = 0;
                $select count(*) into $iCount
                   from car_code
                  where kind = 'RN'
                    and detail = 'COMM_MGR2'
                    and detail2 = (select icomm_obj from officer where iofficer = $iofficer);

                /* if (Is_JC=='Y'||Is_PrintBC=='N') { */
	  	        /* �F���ۼ�(JC)��COMM_MGR2�]�w�����Lú�ڳ� */

	  	if (Is_JC=='Y'||iCount>0) {
                    if (fuw_status_ori==500) fuw_status_ori = 505;
                    if (fuw_status_sug==500) fuw_status_sug = 505;
	  	}else{
	  	    /* 102.10.16
                       �Y�G�ӧ�O�զX���f�֪��A�Ҭ�500�A�B�O�O�۵��A�h�N��ĳ��O�զX���f�֪��A�אּ 505
                       (���ܳq�L�t�μf��,�����Lú�ڳ�(�������@�γ�������))�A��barcode�󤴺����f�֪��A��500	*/

	  	    if ((fuw_status_ori == 500) && (fuw_status_sug ==500)){
   	  	        switch (fBothIns){

   	  	    	    case 3:
                                if ((comp_prem==mcomp_prem_sug)&&(v_ori_prem==v_prem)){
                       		    fuw_status_sug = 505;
                                }
                                break;

   	  	    	    case 2:
   	  	    	    /* �Y�ŦX�����㨮���ѥB�����ĳ�j��(fBothIns_sug=4)�����C�Lú�ڳ� modify by sylvia 103.08.20 */
                       	        if (v_ori_prem==v_prem){
                                    if (fBothIns_sug != 4)
                       		        fuw_status_sug = 505;
                                    }
                                break;

   	  	    	    case 1:
                       	        if (comp_prem==mcomp_prem_sug){
                       	    	    /*chk "������j"�� �̡A�O�_����ĳ47 �� 50 �����N�I(�z�פWbarcode��(frenew_type='2')�~�|��)*/
                       	    	    mcomp_prem_sug1 = 0;
                                    $EXECUTE prep_prem_sug2 Into $mcomp_prem_sug1 using  $ipolicy;
                                    if (mcomp_prem_sug1 == 0){ /* �±j���I */
                       		        fuw_status_sug = 505;
                       		    }
                                }
                                break;
                        }
                    }

                }

            }else{
                /* ����(�t�M�ץ�) */
                /* [102.07.01] �w�����W�u�G�@�ߵ����ĳq��A�B���ӥ�u�����A���Lú�ڳ� */
                #if _VERSION == _VER_PRE
		if (fuw_status_ori==500) fuw_status_ori = 505;
		if (fuw_status_sug==500) fuw_status_sug = 505;
		#elif _VERSION == _VER_OK
		/* �t�X���O�X��104/01/01�W�u, ��H�I����H�P�_�O�_�L�sú�ڳ� mark by sylvia 103.12.01 (1031111001_C3) */
      	        iCount = 0;
	 	$select count(*) into $iCount
                   from car_code
                  where kind = 'RN'
                    and detail = 'COMM_MGR1'
                    and detail2 matches (select icomm_obj[1,2]||'*' from officer where iofficer = $iofficer);
                /* �]�w�bcar140���I����H�αM�ץ󤣦C�Lú�ڳ� add by sylvia 103.12.02 */

                /* ���ظg�P��8-11����O���Lú�ڳ� add by sylvia 105.05.17 (1050504009_C1) */
                if (((iCount > 0) || (IsPlyB == 'Y')) || ( intopt == 55 ))
                {
                    if (fuw_status_ori==500) fuw_status_ori = 505;
		    if (fuw_status_sug==500) fuw_status_sug = 505;
                }
                #endif
            }
        }/* �P�_�O�_�C�Lú�ڳ�(END) */

        strcpy(iestimate_ori," ");  strcpy(iestimate_sug," "); strcpy(iroute_accept, " ");
        strcpy(itransno_ori ," ");  strcpy(itransno_sug ," ");
        strcpy(isub ," ");          strcpy(icomm_obj ," ");
        strcpy(itransno_ori_atm ," ");  strcpy(itransno_sug_atm ," ");
        strcpy(itransno_ori_post ," ");  strcpy(itransno_sug_post ," ");
        strcpy(itransno_ori_007 ," ");  strcpy(itransno_sug_007 ," ");
        strcpy(itransno_ori_008 ," ");  strcpy(itransno_sug_008 ," ");
        strcpy(itransno_ori_009 ," ");  strcpy(itransno_sug_009 ," ");
        strcpy(itransno_ori_013 ," ");  strcpy(itransno_sug_013 ," ");
        strcpy(tmYY ," ");  strcpy(tmMM ," "); strcpy(tmDD ," ");

        /* sTmpIcomp[0] = ipolicy[2];  sTmpIcomp[1] = '\0'; */ /* ���~, ��H�g��N���Ӭd�� mark by sylvia 104.04.22 */

        $SELECT ibranch,icomm_obj,iupcomp INTO $ibranch,$icomm_obj, $sTmpIcomp FROM officer WHERE iofficer = $iofficer;  /* ������c,�I����H */
        $SELECT iupcomp INTO $isub FROM branch WHERE ibranch = $ibranch ;    /* �����q   */

        rtoday(&Today);
        strcpy(sTmpChDate_sys, cm_cdate_str_100(Today));      /* �t�Τ� */
        strcpy(sTmpChDate    , cm_cdate_str_100(dply_begin)); /* �ͮĤ� */


        /* ú�ڳ�Ǹ����1�}�l,ú�O�Ǹ��G ��j=1 , ����N=1 , �j��(=1)+���N(=2)  modify by sylvia 103.06.30  (1030410003_C2) */
        /* tseq = 0 */; /* ú�O�Ǹ��G ��j=0 , ����N=0 , �j��(=0)+���N(=1) */
        tseq = 1 ;
        /* paydate = dply_begin - 1; */
        /* �אּ�ͮĤ�-7 modify by sylvia 104.02.06 */
        /* paydate = dply_begin - 7; */

        /* �s�W[�S��ú�ڴ���(paydate_ext)]=�ͮĤ�@add by sylvia 104.03.31 (1040319002_C1) */
        paydate_ext  = dply_begin;

        /* JB�q��ú�ڴ������ͮĤ�-1���� modify by sylvia 105.06.13 (1050602005_C1) */
        /* �R�q��(����CS)ú�ڴ������ͮĤ�-1���� (1120927002_C05) */
        if ((strcmp(frenew_type,"3") == 0) || (strncmp(iroute,"JB",2) == 0) || (strcmp(icar_type,"CS") == 0))
        {
            /* �۰ʥX���, ú�ڴ�=�ͮĤ�-1����� */
             paydate = dply_begin - 1;
        }
        else
        {
            /* �אּ�ͮĤ�-4�Ӥu�@�� modify by sylvia 104.03.26(1040312001_C1) */
            $select skip 4 first 1 dwork  into $paydate
               from cm_wrktbl
              where dwork <=  $dply_begin
                and fwork = '0'
              order by 1 desc;
        }

        /* �j��+���N�G���N�����p�P����B�P�O��ID���j���I�A���s�T�wú�O���� */
	if (fBothIns==3){

	    /* ( ���ɤ@�w�� fcard_class[0]=='2') */
	    /* �j����Nú�O�����n�@�P�A�H�̥�����̬��D��@�� */
	    rstrdate( s_dply_begin_comp, &lng_dply_begin_comp );
	    /* lng_paydate_comp = lng_dply_begin_comp -1 ; */
	    /* �אּ�ͮĤ�-7 modify by sylvia 104.02.06 */
	    /* lng_paydate_comp = lng_dply_begin_comp -7 ; */

            /* JB�q��ú�ڴ����אּ�ͮĤ�-1���� modify by sylvia 105.06.13 (1050602005_C1) */
            /* �R�q��(����CS)ú�ڴ������ͮĤ�-1���� (1120927002_C05) */
            if ((strcmp(frenew_type,"3") == 0) || (strncmp(iroute,"JB",2) == 0) || (strcmp(icar_type,"CS") == 0))
            {
                /* �۰ʥX���, ú�ڴ�=�ͮĤ�-1����� */
                 lng_paydate_comp = lng_dply_begin_comp -1 ;
            }
            else
            {
    	        /* �אּ�ͮĤ�-4�u�@�� modify by sylvia 104.03.26(1040312001_C1) */
    		$select skip 4 first 1 dwork  into $lng_paydate_comp
                   from cm_wrktbl
                  where dwork <=  $lng_dply_begin_comp
                    and fwork = '0'
                  order by 1 desc;
            }

	    if (lng_paydate_comp < paydate) {
	        paydate = lng_paydate_comp ;
		/* �s�W[�S��ú�ڴ���(paydate_ext)]=�ͮĤ�@add by sylvia 104.03.31 (1040319002_C1) */
                paydate_ext  = lng_dply_begin_comp;
	    }

            strcpy(iofficer,trim(iofficer));  strcpy(iofficer,trim(iofficer_comp));

	    if ( strcmp(iofficer,iofficer_comp)!=0 ){
	        $SELECT ibranch,icomm_obj INTO $ibranch_comp,$icomm_obj_comp FROM officer WHERE iofficer = $iofficer_comp;
		$SELECT iupcomp INTO $isub_comp FROM branch WHERE ibranch = $ibranch_comp ;
	    }else{
		strcpy(ibranch_comp,ibranch);   strcpy(icomm_obj_comp,icomm_obj);   strcpy(isub_comp,isub);
	    }
        }

        /* �]�����������I����, �ȮɱN106/02�����O��,��/��ĳ��O�զX���t�����,ú�ڴ��@�ߧאּ106/01/26
		       add by sylvia 105.12.08(1051206007_C1) */
	if ((iplyyear == 2017) && (iplymonth == 2))
	{
	    if ((fBothIns==2) ||(fBothIns==3))
	    {
    	        ChkDmgIns = 0;
    	        $EXECUTE prep_chk_dmgins INTO $ChkDmgIns USING $ipolicy;
    	        if (ChkDmgIns > 0)
    	        {
    	            paydate = D1060126 ;    /* ú�ڴ����T�w��106/01/26 */
                    paydate_ext  = D1060126;    /* �S��ú�ڴ����T�w��106/01/26 */
    	        }
	    }
	}

        strcpy(sTmpChDate_pay, cm_cdate_str_100(paydate));    /* ú�O����(CYY/MM/DD) */
        iYear = atoi(cm_eyear_str(paydate));    /* bug�ץ�, iyear����ú�O�������~��, �ӫD�O��ͮĦ~�� */
        printf("trace sTmpChDate_pay[%s], iYear=[%d]\n ",sTmpChDate_pay, iYear);

        /*********************************** ���O�զX **************************************/
        if ((strcmp(fsend_msg,"N") == 0) || (strlen(mobile_phone) != 10) || (strncmp(mobile_phone,"09",2)!=0))  /* ��ʹq�� */
        {
            strcpy(mobile_phone," ");  /* ��ʹq�� */
            strcpy(fsend_msg,"N");
        }


        /*=================================*/
        /*                                 */
        /*            ���O�զX           */
        /*                                 */
        /*=================================*/
        if (fuw_status_ori >=500)
        {
	    strcpy(isys,"4") ;

            /******************/
            /**  ��ú�ڳ渹  **/
            /******************/
	    if (fuw_status_ori != 505)
	    {

                if ((frenew_type[0] == '1') || (frenew_type[0] == '3'))
                {
                    /* ��O�q���� + �q����*/
                    if (fcommit[0]=='N')
                    {
                    	/* �D���� ( �P�b�s�� = "6075....")*/
		        /* ������c�N�X�אּ1�X0  modify by sylvia 103.06.30  (1030410003_C2) */
		        /* �t�X�Ȧ�����b��, ��I�s cm_get_va_num()  modify by sylvia 106.12.19 (1060831012_C3) */
		        /* �t�X�|�X�@ú�O��睊�A�s�W����@�ص����b�� modify by 061476 108.11.19 (1070518005_SC1) */
		        strcpy(F_type,"6075");
		        rc = cm_get_va_num(F_type, "0", "0", sTmpChDate_pay, comp_prem+v_ori_prem, itransno_ori, itransno_ori_007, itransno_ori_008, itransno_ori_009, itransno_ori_atm, itransno_ori_013);
		        if (rc != 0)
		        {
		            $ROLLBACK WORK;
		            return rc;
		        }

		    }
		    else if (fcommit[0]=='1')
		    {
		    	/* ���� ( �P�b�s�� = "6074....")*/
		        /* ������c�N�X�אּ1�X0  modify by sylvia 103.06.30  (1030410003_C2) */
		        /* ��BS(��i)&JH(�ؤ�)����6074�~,��l����ú�ڳ渹��6890 modify by sylvia 105.0.15 (1040922001_C1) */
		        if ((strcmp(sComm_obj,"BS") == 0)||(strcmp(sComm_obj,"JH") == 0))
		        {
		            /* �t�X�Ȧ�����b��, ��I�s cm_get_va_num()  modify by sylvia 106.12.19 (1060831012_C3) */
		            /* �t�X�|�X�@ú�O��睊�A�s�W����@�ص����b�� modify by 061476 108.11.19 (1070518005_SC1) */
    	        	    strcpy(F_type,"6074");
    	        	    rc = cm_get_va_num(F_type, "0", "0", sTmpChDate_pay, comp_prem+v_ori_prem, itransno_ori, itransno_ori_007, itransno_ori_008, itransno_ori_009, itransno_ori_atm, itransno_ori_013);
    	        	    if (rc != 0){
    		                $ROLLBACK WORK;
    		                return rc;
    		            }

    		        }
    		        else
    		        {

    		            /* �t�X�Ȧ�����b��, ��I�s cm_get_va_num()  modify by sylvia 106.12.19 (1060831012_C3) */
    		            /* �t�X�|�X�@ú�O��睊�A�s�W����@�ص����b�� modify by 061476 108.11.19 (1070518005_SC1) */
    		            strcpy(F_type,"6890");
    	        	    rc = cm_get_va_num(F_type, "0", "0", sTmpChDate_pay, comp_prem+v_ori_prem, itransno_ori, itransno_ori_007, itransno_ori_008, itransno_ori_009, itransno_ori_atm, itransno_ori_013);
    	        	    if (rc != 0){
    		                $ROLLBACK WORK;
    		                return rc;
    		            }

    		        }

                    }
                }
                else if (frenew_type[0] == '2')
                {
                    /*�� barcode ��O�n�O��(�P�b�s�� = "9100...")  103.11.27����9100�s�X */
		    /* ����9100���6075 modify by sylvia 103.11.27 */
		    /* �t�X�Ȧ�����b��, ��I�s cm_get_va_num()  modify by sylvia 106.12.19 (1060831012_C3) */
		    /* �t�X�|�X�@ú�O��睊�A�s�W����@�ص����b�� modify by 061476 108.11.19 (1070518005_SC1) */
		    strcpy(F_type,"6075");
    	            rc = cm_get_va_num(F_type, "0", "0", sTmpChDate_pay, comp_prem+v_ori_prem, itransno_ori, itransno_ori_007, itransno_ori_008, itransno_ori_009, itransno_ori_atm, itransno_ori_013);
		    if (rc != 0)
		    {
		        $ROLLBACK WORK;
		        return rc;
		    }

		}
		printf("trace itransno_ori[%s]  \n " ,itransno_ori);
            }


            /*---------------------------------------------------------------------------------*/
            /*----                         ���B�z �j+���� "�j��" BEGIN                     ----*/
            /*---------------------------------------------------------------------------------*/

            /*�Y�O���N�I�A�h�����Ainsert �@���j���I(�p�G���p���j��渹�O�P����B�P�O��ID����) */
            if (fBothIns==3)
            {
                /* �j��+���N�G���N�����p�P����B�P�O��ID���j���I */
                /* 102.04.01 �ܧ�A���סB���q�n���ͦU�۳����渹�A�B�P�@��O�椧�j��B���N����O���ͳ渹*/


                /******************/
                /**  �������渹  **/
                /******************/

                if (ibig_comp[0]=='B' && IsPlyB=='N')
                {
                    rc = cm_get_serial_num("C1", "BC", "0", "00", sTmpChDate, iestimate_ori);
                    iestimate_ori[8] = '9'; /* ��9�X�אּ"9"�A�H�קK�Pb2b���X���� */
                    printf("trace BC 2 iestimate_ori[%s] \n " ,iestimate_ori);
                }
                else if (ibig_comp[0]=='J' && IsPlyB=='N')
                {
                    rc = cm_get_serial_num("C1", "JC", "0", "00", sTmpChDate, iestimate_ori);
                    iestimate_ori[8] = '9'; /* ��9�X�אּ"9"�A�H�קK�Pb2b���X���� */
                    printf("trace JC 2 iestimate_ori[%s] \n " ,iestimate_ori);
                }
                else
                {
                    rc = cm_get_serial_num("C1", "RN", sTmpIcomp, ibranch, sTmpChDate, iestimate_ori);
                }

                if (rc != 0){
                    $ROLLBACK WORK;
                    return rc;
                }

                /* 102.05 �j���Iú�O����(cm_pre_receive.paydate)�� NULL(null_date) */
    		mprem = (1.0)*comp_prem; /*�j���I�O�O(���O�զX)*/
    		/* �t�X�@�γ�������cm_pre_receive�s�Wiins_kind_ply���(�j��=C1,���N=C2 add by sylvia 103.05.19 (1020111001_CG) */
                /* �t�X���O�X��104/01/01�W�u,�s�Wftype_sp,dbegin,dend��� add by sylvia 103.12.01 */
                strcpy(cm_dbegin,dply_bgn_comp); /* �O�I�_�� */
                strcpy(cm_dend,dply_end_comp);   /* �O�I���� */

                /********************************************/
                /**  Insert �@�γ������� (cm_pre_receive)  **/
                /********************************************/

                if (strcmp(ftype_sp,"PA") == 0)
                {
                    $EXECUTE prep_receive
                       using $iestimate_ori, "1", "C1", $ilicense, $nassured, $iapplicant, $napplicant, $itag,
                	     $iengine, $lng_dply_begin_comp, $null_date, $mprem, $isub_comp, $iofficer_comp, $ileader_comp, $iquota_comp,
                	     $icomm_obj_comp, $iroute_comp, $fcommit, $userid , $isys, $ipgid, "SP", "01", $cm_dbegin, $cm_dend,
                	     $fsend_msg, $mobile_phone, $irelative_ply;
                }
                else
                {
                    $EXECUTE prep_receive
                       using $iestimate_ori, "1", "C1", $ilicense, $nassured, $iapplicant, $napplicant, $itag,
                	     $iengine, $lng_dply_begin_comp, $null_date, $mprem, $isub_comp, $iofficer_comp, $ileader_comp, $iquota_comp,
                	     $icomm_obj_comp, $iroute_comp, $fcommit, $userid , $isys, $ipgid, $ftype_pol, $ftype_sp, $cm_dbegin, $cm_dend,
                	     $fsend_msg, $mobile_phone, $irelative_ply;
                }

                /*******************************************/
                /**  Insert �C��ú�O����� (ao_rcv_type)  **/
                /*******************************************/

                if (fuw_status_ori != 505)
                {
		    /* ao_rcv_type ��ibroker����ڬO��micomm_obj(�I����H�N��) (102.03.19 �å�T�{ )*/
		    /* ú�ڳ�Ǹ���1�}�l   modify by sylvia 103.06.30 (1030410003_C2) */
		    /* �t�X���O�X��,6074/6075�s�X���[�W���B�ˮ�   modify by sylvia 103.11.27 */
		    /* �K�Q�ө�(���B100%) */
		    $EXECUTE prep_rcv_type
		       using $iYear, $itransno_ori, $itransno_ori, "1" ,$iestimate_ori, $mprem, $ilicense, $nassured, $ipgid,
			     $paydate, $paydate_ext, $isub_comp, $icomm_obj_comp, $iofficer_comp,"1" ;

                }
                else
                {

    	            $EXECUTE prep_upd_receive using $iestimate_ori;  /* ���Lú�ڳ�̡A����ú�ڳ�L��� */
		}


		cm_char_split_3ymd(sTmpChDate_pay,tmYY,tmMM,tmDD);
		if (fuw_status_ori == 500)
		{
		    strcpy(itransno_ori_013, trim(itransno_ori_013));
		    sprintf_s(itransno_ori_post,sizeof itransno_ori_post,"%s%s%s%s",tmYY,tmMM,tmDD,itransno_ori_013);  /* �l�F����ú�ڳ渹 */
		}
		else
		{
		    strcpy(itransno_ori_post, " ");
		}

                /********************/
                /*  ���q�����z�s��  */
                /********************/

                if(strncmp(iroute,"I006",4) == 0)
                {
                    strcpy(cdate, cm_from_infdate_100(cdate2));
                    rc = cm_ibank_pqnum2("Q1","CR",iroute, cdate, "N", "R", iroute_accept);
                    printf("rc = [%d]\n",rc);
                    if (rc != 0)
                    {
                        $ROLLBACK WORK;
                        return rc;
                    }

                    if(strlen(trim(iroute_accept))==0)
                    	strcpy(iroute_accept," ");

                }
                else if((strncmp(iroute,"I806",4) == 0) || (strncmp(iroute,"I009",4) == 0) ||
                        (strncmp(iroute,"I050",4) == 0) || (strncmp(iroute,"I018",4) == 0) ||
                        (strncmp(iroute,"I005",4) == 0) || (strncmp(iroute,"I004",4) == 0) ||
                        (strncmp(iroute,"I118",4) == 0) || (strncmp(iroute,"BA83709986",4) == 0))
                {
                    strcpy(cdate, cm_from_infdate_100(cdate2));
                    rc = cm_ibank_pqnum2("Q1",ipolicy67,iroute, cdate, "N", "R", iroute_accept);
                    printf("17167:rc = [%d],ipolicy67=[%s]iroute=[%s]iroute_accept=[%s]\n",rc,ipolicy67,iroute,iroute_accept);
                    if (rc != 0)
                    {
                        $ROLLBACK WORK;
                        return rc;
                    }
                    if(strlen(trim(iroute_accept))==0)
                    	strcpy(iroute_accept," ");
                }
                else
                    strcpy(iroute_accept," ");

                printf("17590:irotue=[%s]iroute_accept=[%s]\n",iroute,iroute_accept);
                printf("*************************************************** \n");

                /*********************************/
                /*  �^�gpolicy_302�Bpolicy_302f  */
                /*********************************/

                $EXECUTE prep_upd_302_ori
                   using $iestimate_ori , $itransno_ori,$fuw_status_ori, $frenew_type ,
                         $itransno_ori_atm, $itransno_ori_post, $iroute_accept,
                         $itransno_ori_007,$itransno_ori_008,$itransno_ori_009,$itransno_ori_013,
                         $irelative_ply;

                $EXECUTE prep_upd_302f_ori
                   using $iestimate_ori , $itransno_ori,$fuw_status_ori, $frenew_type ,
                         $itransno_ori_atm, $itransno_ori_post, $iroute_accept,
                         $itransno_ori_007,$itransno_ori_008,$itransno_ori_009,$itransno_ori_013,
                         $irelative_ply;

    	    }
            /*---------------------------------------------------------------------------------*/
            /*----                        ���B�z �j+���� "�j��" END                        ----*/
            /*---------------------------------------------------------------------------------*/



            /*---------------------------------------------------------------------------------*/
            /*----             �A�B�z "��j"�B"����N" �� �j+����"���N" BEGIN              ----*/
            /*---------------------------------------------------------------------------------*/


            /******************/
            /**  �������渹  **/
            /******************/

    	    if (ibig_comp[0]=='B' && IsPlyB=='N' )
    	    {
    	        rc = cm_get_serial_num("C1", "BC", "0", "00", sTmpChDate, iestimate_ori);
    		iestimate_ori[8] = '9'; /* ��9�X�אּ"9"�A�H�קK�Pb2b���X���� */
    		printf("trace BC 1 iestimate_ori[%s] \n " ,iestimate_ori);
    	    }
    	    else if (ibig_comp[0]=='J' && IsPlyB=='N' )
    	    {
    		rc = cm_get_serial_num("C1", "JC", "0", "00", sTmpChDate, iestimate_ori);
    		iestimate_ori[8] = '9'; /* ��9�X�אּ"9"�A�H�קK�Pb2b���X���� */
    		printf("trace JC 1 iestimate_ori[%s] \n " ,iestimate_ori);
    	    }
    	    else
    	    {
    	    	if (fBothIns!=3)
    	    	{
    	    	    /* �j��B���N�P�@�����渹�A�e���j���I�w���L�� */
                    rc = cm_get_serial_num("C1", "RN", sTmpIcomp, ibranch, sTmpChDate, iestimate_ori);
                }
    	    }

            if (rc!=0)
            {
	        printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",
	                SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
	        $ROLLBACK WORK;
	        return rc;
	    }


            if (fcard_class[0]=='2')
            {
	    	mprem = (1.0)*v_ori_prem;  /*���N�I�O�O(���O�զX)*/
	    	strcpy(cm_dbegin,dbegin_302); /* �O�I�_�� */
	    	strcpy(cm_dend,dend_302);     /* �O�I���� */
	    	if (fBothIns==3) tseq = 2 ;/* ú�ڳ�Ǹ����1�}�l,ú�O�Ǹ��G ��j=1 , ����N=1 , �j��(=1)+���N(=2)  modify by sylvia 103.06.30  (1030410003_C2) */
	    }
	    else
	    {
        	mprem = (1.0)*comp_prem;   /*�j���I�O�O(���O�զX)*/
        	strcpy(cm_dbegin,dply_bgn_comp);   /* �O�I�_�� */
	    	strcpy(cm_dend,dply_end_comp);     /* �O�I���� */
            }


            /********************************************/
            /**  Insert �@�γ������� (cm_pre_receive)  **/
            /********************************************/

            /* 102.05 �j���I�B�F���ЮסB�ĳq��ú�O����(cm_pre_receive.paydate)�� NULL(null_date) */
            /* �t�X�@�γ�������cm_pre_receive�s�Wiins_kind_ply���(�j��=C1,���N=C2 add by sylvia 103.05.19 (1020111001_CG) */
            if ((fcard_class[0]=='1')||(Is_JC == 'Y')||(Is_SP == 'Y'))
            {
                /* ���ݩ�JC��SP/10,SP/20���j���I,ftype_pol=SP & ftyep_sp = 01   �t�X���O�X��104/01/01�W�u�ק� add by sylvia 103.12.01*/
                if ((fcard_class[0]=='1') && (Is_JC != 'Y') && (strcmp(ftype_sp,"20") != 0))
                {
                	$EXECUTE prep_receive
                	   using $iestimate_ori, $fcard_class, $sIins_kind_ply, $ilicense, $nassured, $iapplicant, $napplicant, $itag,
                	         $iengine, $dply_begin, $null_date, $mprem, $isub, $iofficer, $ileader, $iquota,
                	         $icomm_obj, $iroute, $fcommit,  $userid , $isys, $ipgid, "SP", "01", $cm_dbegin, $cm_dend,
                	         $fsend_msg, $mobile_phone, $ipolicy;
                }
                else
                {
                	$EXECUTE prep_receive
                	   using $iestimate_ori, $fcard_class, $sIins_kind_ply, $ilicense, $nassured, $iapplicant, $napplicant, $itag,
                	         $iengine, $dply_begin, $null_date, $mprem, $isub, $iofficer, $ileader, $iquota,
                	         $icomm_obj, $iroute, $fcommit,  $userid , $isys, $ipgid, $ftype_pol, $ftype_sp, $cm_dbegin, $cm_dend,
                	         $fsend_msg, $mobile_phone, $ipolicy;
                }
            }
            else
            {
            	$EXECUTE prep_receive
            	   using $iestimate_ori, $fcard_class, $sIins_kind_ply, $ilicense, $nassured, $iapplicant, $napplicant, $itag,
            	         $iengine, $dply_begin, $paydate, $mprem, $isub, $iofficer, $ileader, $iquota,
            	         $icomm_obj, $iroute, $fcommit,  $userid , $isys, $ipgid, $ftype_pol, $ftype_sp, $cm_dbegin, $cm_dend,
            	         $fsend_msg, $mobile_phone, $ipolicy;
            }

            /*******************************************/
            /**  Insert �C��ú�O����� (ao_rcv_type)  **/
            /*******************************************/

            if (fuw_status_ori != 505)
            {

	        /* �t�X���O�X��,6074/6075�s�X���[�W���B�ˮ�   modify by sylvia 103.11.27 */
                $EXECUTE prep_rcv_type
		   using $iYear, $itransno_ori, $itransno_ori, $tseq, $iestimate_ori, $mprem, $ilicense, $nassured, $ipgid,
		         $paydate, $paydate_ext, $isub, $icomm_obj, $iofficer,$fcard_class  ;

            }
            else
            {
        	$EXECUTE prep_upd_receive using $iestimate_ori; /* ���Lú�ڳ�̡A����ú�ڳ�L��� */
            }


            cm_char_split_3ymd(sTmpChDate_pay,tmYY,tmMM,tmDD);
	    if (fuw_status_ori == 500)
	    {
	        strcpy(itransno_ori_013, trim(itransno_ori_013));
		sprintf_s(itransno_ori_post,sizeof itransno_ori_post,"%s%s%s%s",tmYY,tmMM,tmDD,itransno_ori_013);  /* �l�F����ú�ڳ渹 */
	    }
	    else
	    {
		sprintf_s(itransno_ori_post,sizeof itransno_ori_post," ");  /* �l�F����ú�ڳ渹 */
	    }

	    #ifdef PRINTF_FLAG
	    printf("iestimate_ori=[%s]\n",iestimate_ori);
	    printf("itransno_ori=[%s]\n",itransno_ori);
	    printf("frenew_type=[%s]\n",frenew_type);
	    printf("itransno_ori_atm=[%s]\n",itransno_ori_atm);
	    printf("itransno_ori_post=[%s]\n",itransno_ori_post);
	    printf("ipolicy=[%s]\n",ipolicy);
	    #endif

            printf("*************************************************** \n");

            /********************/
            /*  ���q�����z�s��  */
            /********************/

            if(strncmp(iroute,"I006",4) == 0)
            {
                if (fBothIns!=3)
                {
                    strcpy(cdate, cm_from_infdate_100(cdate2));
                    rc = cm_ibank_pqnum2("Q1","CR",iroute, cdate, "N", "R", iroute_accept);
                    printf("rc = [%d]\n",rc);
                    if (rc != 0)
                    {
                        $ROLLBACK WORK;
                        return rc;
                    }

                    if(strlen(trim(iroute_accept))==0)
                        strcpy(iroute_accept," ");
                }
            }
            else if((strncmp(iroute,"I806",4) == 0) || (strncmp(iroute,"I009",4) == 0) ||
                    (strncmp(iroute,"I050",4) == 0) || (strncmp(iroute,"I018",4) == 0) ||
                    (strncmp(iroute,"I005",4) == 0) || (strncmp(iroute,"I004",4) == 0) ||
                    (strncmp(iroute,"I118",4) == 0) || (strncmp(iroute,"BA83709986",4) == 0))
            {

                if (fBothIns!=3)
                {
                    strcpy(cdate, cm_from_infdate_100(cdate2));
                    rc = cm_ibank_pqnum2("Q1",ipolicy67,iroute, cdate, "N", "R", iroute_accept);
                    printf("17343:rc = [%d],ipolicy67=[%s]iroute=[%s]iroute_accept=[%s]\n",rc,ipolicy67,iroute,iroute_accept);

                    if (rc != 0)
                    {
                        $ROLLBACK WORK;
                        return rc;
                    }

                    if(strlen(trim(iroute_accept))==0)
                        strcpy(iroute_accept," ");
                }
            }
            else
                strcpy(iroute_accept," ");

            printf("16895:irotue=[%s]iroute_accept=[%s],ipolicy=[%s] \n",iroute,iroute_accept, ipolicy);
            printf("*************************************************** \n");


            /*********************************/
            /*  �^�gpolicy_302�Bpolicy_302f  */
            /*********************************/

            $EXECUTE prep_upd_302_ori
               using $iestimate_ori , $itransno_ori,$fuw_status_ori, $frenew_type ,
                     $itransno_ori_atm, $itransno_ori_post, $iroute_accept,
                     $itransno_ori_007,$itransno_ori_008,$itransno_ori_009,$itransno_ori_013,
                     $ipolicy ;

            $EXECUTE prep_upd_302f_ori
               using $iestimate_ori , $itransno_ori,$fuw_status_ori, $frenew_type ,
                     $itransno_ori_atm, $itransno_ori_post, $iroute_accept,
                     $itransno_ori_007,$itransno_ori_008,$itransno_ori_009,$itransno_ori_013,
                     $ipolicy ;

            if (strncmp(iroute,"I009",4) == 0 && fBothIns != 3 && strlen(trim(irelative_ply))>0)
            {
            	/*���ȳq��(I009)�A�Y�Q������j�A�B�����p�����N�I�A�P��update���p�����N�I*/
            	/*����(I009)�q�����O�զX�f�֪��A<500�A�]�n���q�����z�s��(1110510005_SC1)*/

            	$EXECUTE prep_upd_302_accept
                   using $iroute_accept,
                         $irelative_ply;

                $EXECUTE prep_upd_302f_accept
                   using $iroute_accept,
                         $irelative_ply;

            }

            /*-------------------------------------------------------------------------------*/
            /*----             �A�B�z "��j"�B"����N" �� �j+����"���N" END              ----*/
            /*-------------------------------------------------------------------------------*/



        }
        else if (fuw_status_ori < 500 && strncmp(iroute,"I009",4) == 0)
        {
	    /*����(I009)�q�����O�զX�f�֪��A<500�A�]�n���q�����z�s��(1110510005_SC1)*/

            /********************/
            /*  ���q�����z�s��  */
            /********************/
            strcpy(cdate, cm_from_infdate_100(cdate2));
            rc = cm_ibank_pqnum2("Q1",ipolicy67,iroute, cdate, "N", "R", iroute_accept);

            if (rc != 0)
            {
                $ROLLBACK WORK;
                return rc;
            }

            if(strlen(trim(iroute_accept))==0)
                strcpy(iroute_accept," ");


            /*********************************/
            /*  �^�gpolicy_302�Bpolicy_302f  */
            /*********************************/

            $EXECUTE prep_upd_302_accept
               using $iroute_accept,
                     $ipolicy ;

            $EXECUTE prep_upd_302f_accept
               using $iroute_accept,
                     $ipolicy ;

            $EXECUTE prep_upd_302_accept
               using $iroute_accept,
                     $irelative_ply;

            $EXECUTE prep_upd_302f_accept
               using $iroute_accept,
                     $irelative_ply;


        }/* ���O�զX(END) */





        /*=================================*/
        /*                                 */
        /*           ��ĳ��O�զX          */
        /*                                 */
        /*=================================*/

        mcomp_prem_sug2 = 0 ;

        if (fuw_status_sug >=500)
        {
	    strcpy(isys,"5") ; /* ��ĳ��O�զX */


            /******************/
            /**  ��ú�ڳ渹  **/
            /******************/

            if (fuw_status_sug != 505)
            {

                if ((frenew_type[0] == '1') || (frenew_type[0] == '3'))
                {
                    /* ��O�q���� + �q����*/
                    if (fcommit[0]=='N')
                    {
                        /* �D���� ( �P�b�s�� = "6074....")*/
		        /* ������c�N�X�אּ1�X0  modify by sylvia 103.06.30  (1030410003_C2) */
		        /* �t�X�Ȧ�����b��, ��I�scm_get_va_num()  modify by sylvia 106.12.19 (1060831012_C3) */
		        /* �t�X�|�X�@ú�O��睊�A�s�W����@�ص����b�� modify by 061476 108.11.19 (1070518005_SC1) */
		        strcpy(F_type,"6075");
		        rc = cm_get_va_num(F_type, "0", "0", sTmpChDate_pay, mcomp_prem_sug+v_prem, itransno_sug, itransno_sug_007, itransno_sug_008, itransno_sug_009, itransno_sug_atm, itransno_sug_013);
		        if (rc != 0)
		        {
		            $ROLLBACK WORK;
		            return rc;
		        }

		    }
		    else if (fcommit[0]=='1')
		    {
		        /* ���� ( �P�b�s�� = "6075....")*/
		        /* ������c�N�X�אּ1�X0  modify by sylvia 103.06.30  (1030410003_C2) */
		        /* ��BS(��i)&JH(�ؤ�)����6074�~,��l����ú�ڳ渹��6890 modify by sylvia 105.0.15 (1040922001_C1) */
		        if ((strcmp(sComm_obj,"BS") == 0)||(strcmp(sComm_obj,"JH") == 0))
		        {
    		            /* �t�X�Ȧ�����b��, ��I�scm_get_va_num()  modify by sylvia 106.12.19 (1060831012_C3) */
    		            /* �t�X�|�X�@ú�O��睊�A�s�W����@�ص����b�� modify by 061476 108.11.19 (1070518005_SC1) */
    		            strcpy(F_type,"6074");
    		            rc = cm_get_va_num(F_type, "0", "0", sTmpChDate_pay, mcomp_prem_sug+v_prem, itransno_sug, itransno_sug_007, itransno_sug_008, itransno_sug_009, itransno_sug_atm, itransno_sug_013);
    		            if (rc != 0)
    		            {
    		                $ROLLBACK WORK;
    		                return rc;
    		            }

    		        }
    		        else
    		        {
    		            /* �t�X�Ȧ�����b��, ��I�scm_get_va_num()  modify by sylvia 106.12.19 (1060831012_C3) */
    		            /* �t�X�|�X�@ú�O��睊�A�s�W����@�ص����b�� modify by 061476 108.11.19 (1070518005_SC1) */
    		            strcpy(F_type,"6890");
    		            rc = cm_get_va_num(F_type, "0", "0", sTmpChDate_pay, mcomp_prem_sug+v_prem, itransno_sug, itransno_sug_007, itransno_sug_008, itransno_sug_009, itransno_sug_atm, itransno_sug_013);

    		            if (rc != 0)
    		            {
    		                $ROLLBACK WORK;
    		                return rc;
    		            }

    		        }
		    }
		}
		else if (frenew_type[0] == '2')
		{
		    /*�� barcode ��O�n�O��(�P�b�s�� = "9100...") */
		    /* ����9100���6075 modify by sylvia 103.11.27 */
		    /* �t�X�Ȧ�����b��, ��I�scm_get_va_num()  modify by sylvia 106.12.19 (1060831012_C3) */
		    /* �t�X�|�X�@ú�O��睊�A�s�W����@�ص����b�� modify by 061476 108.11.19 (1070518005_SC1) */
		    strcpy(F_type,"6075");
		    rc = cm_get_va_num(F_type, "0", "0", sTmpChDate_pay, mcomp_prem_sug+v_prem, itransno_sug, itransno_sug_007, itransno_sug_008, itransno_sug_009, itransno_sug_atm, itransno_sug_013);
		    if (rc != 0)
		    {
		        $ROLLBACK WORK;
		        return rc;
		    }
		}
		printf("trace itransno_sug[%s] \n "  ,itransno_sug);
	    }


            /*---------------------------------------------------------------------------------*/
            /*----                         ���B�z �j+���� "�j��" BEGIN                     ----*/
            /*---------------------------------------------------------------------------------*/

	    /*�Y�O���N�I�A�h�����Ainsert �@���P�����渹���j���I(�p�G���p���j��渹�O�P����B�P�O��ID����) */
	    /* 1030819 ����barcode�㨮���ѱM��,����N��ĳ�j���I(fBothIns_sug==4) add by sylvia (1030806002_C1) */
    	    if ((fBothIns==3)||((fBothIns==2)&&(fBothIns_sug==4)))
    	    {

                /******************/
                /**  �������渹  **/
                /******************/

    	        /* �j��+���N�G���N�����p�P����B�P�O��ID���j���I */
                /* 102.04.01 �ܧ�A���סB���q�n���ͦU�۳����渹�A�B�P�@��O�椧�j��B���N����O���ͳ渹*/
                if (ibig_comp[0]=='B' && IsPlyB=='N')
                {
                    rc = cm_get_serial_num("C1", "BC", "0", "00", sTmpChDate, iestimate_sug);
                    iestimate_sug[8] = '9'; /* ��9�X�אּ"9"�A�H�קK�Pb2b���X���� */
                    printf("trace BC 2 iestimate_sug[%s] \n " ,iestimate_sug);
    	        }
    	        else if (ibig_comp[0]=='J' && IsPlyB=='N')
    	        {
    	            rc = cm_get_serial_num("C1", "JC", "0", "00", sTmpChDate, iestimate_sug);
    	            iestimate_sug[8] = '9'; /* ��9�X�אּ"9"�A�H�קK�Pb2b���X���� */
    	            printf("trace JC 2 iestimate_sug[%s] \n " ,iestimate_sug);
    	        }
    	        else
    	        {
    	            rc = cm_get_serial_num("C1", "RN", sTmpIcomp, ibranch, sTmpChDate, iestimate_sug);
    	        }

                if (rc!=0)
                {
	            printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
	            $ROLLBACK WORK;
	            return rc;
	        }

    		printf("trace fBothIns==3 or fBothIns_sug==4 iestimate_sug[%s]  \n " ,iestimate_sug);

    		/* 102.05 �j���Iú�O����(cm_pre_receive.paydate)�� NULL(null_date) */
    		/* �t�X�@�γ�������cm_pre_receive�s�Wiins_kind_ply���(�j��=C1,���N=C2add by sylvia 103.05.19 (1020111001_CG) */

    		mprem = (1.0)*mcomp_prem_sug; /*�j���I�O�O(��ĳ��O�զX)*/
    		printf("mprem=[%f]\n",mprem);

    		/* �����㨮����,�����ĳ�j��,�j�������ƻP���N�I�ۦP */
    		if (fBothIns_sug == 4)
    		{
    			lng_dply_begin_comp = dply_begin;
    			strcpy(isub_comp,isub);
    			strcpy(iofficer_comp, iofficer);
    			strcpy(ileader_comp, ileader);
    			strcpy(iquota_comp,iquota);
    			strcpy(icomm_obj_comp,icomm_obj);
    			strcpy(iroute_comp, iroute);
    		}
    		/* -------------------------------------------------------------------- */

    		strcpy(cm_dbegin,dply_bgn_comp); /* �O�I�_�� */
                strcpy(cm_dend,dply_end_comp);   /* �O�I���� */


                /********************************************/
                /**  Insert �@�γ������� (cm_pre_receive)  **/
                /********************************************/

                if (strcmp(ftype_sp,"PA") == 0)
                {
                	$EXECUTE prep_receive
                	   using $iestimate_sug, "1", "C1", $ilicense, $nassured, $iapplicant, $napplicant, $itag,
                	         $iengine, $lng_dply_begin_comp, $null_date, $mprem, $isub_comp, $iofficer_comp, $ileader_comp, $iquota_comp,
                	         $icomm_obj_comp, $iroute_comp, $fcommit, $userid, $isys, $ipgid, "SP", "01", $cm_dbegin, $cm_dend,
                	         $fsend_msg, $mobile_phone, $irelative_ply;
                }
                else
                {
                	$EXECUTE prep_receive
                	   using $iestimate_sug, "1", "C1", $ilicense, $nassured, $iapplicant, $napplicant, $itag,
                	         $iengine, $lng_dply_begin_comp, $null_date, $mprem, $isub_comp, $iofficer_comp, $ileader_comp, $iquota_comp,
                	         $icomm_obj_comp, $iroute_comp, $fcommit, $userid, $isys, $ipgid, $ftype_pol, $ftype_sp, $cm_dbegin, $cm_dend,
                	         $fsend_msg, $mobile_phone, $irelative_ply;
		}

                /*******************************************/
                /**  Insert �C��ú�O����� (ao_rcv_type)  **/
                /*******************************************/


	        if (fuw_status_sug != 505)
	        {
                    /* ú�ڳ�Ǹ���1�}�l   modify by sylvia 103.06.30 (1030410003_C2) */
	            /* �t�X���O�X��,6074/6075�s�X���[�W���B�ˮ�   modify by sylvia 103.11.27 */

		    $EXECUTE prep_rcv_type
		       using $iYear, $itransno_sug, $itransno_sug,"1" ,$iestimate_sug, $mprem, $ilicense, $nassured, $ipgid,
			     $paydate, $paydate_ext, $isub_comp, $icomm_obj_comp, $iofficer_comp, "1" ;


                }
                else
                {
    	            $EXECUTE prep_upd_receive using $iestimate_sug;  /* ���Lú�ڳ�̡A����ú�ڳ�L��� */
		}

		cm_char_split_3ymd(sTmpChDate_pay,tmYY,tmMM,tmDD);
		if (fuw_status_sug == 500)
		{
		    strcpy(itransno_sug_013, trim(itransno_sug_013));
		    sprintf_s(itransno_sug_post,sizeof itransno_sug_post,"%s%s%s%s",tmYY,tmMM,tmDD,itransno_sug_013);  /* �l�F����ú�ڳ渹 */
		}
		else
		{
		    sprintf_s(itransno_sug_post,sizeof itransno_sug_post," ");  /* �l�F����ú�ڳ渹 */
		}


                /*********************************/
                /*  �^�gpolicy_302�Bpolicy_302f  */
                /*********************************/

                $EXECUTE prep_upd_302_sug
                   using $iestimate_sug , $itransno_sug,$fuw_status_sug, $frenew_type ,
                         $itransno_sug_atm, $itransno_sug_post,
                         $itransno_sug_007, $itransno_sug_008, $itransno_sug_009, $itransno_sug_013,
                         $irelative_ply;

                $EXECUTE prep_upd_302f_sug
                   using $iestimate_sug , $itransno_sug,$fuw_status_sug, $frenew_type ,
                         $itransno_sug_atm, $itransno_sug_post,
                         $itransno_sug_007, $itransno_sug_008, $itransno_sug_009, $itransno_sug_013,
                         $irelative_ply;

    	    }

            /*---------------------------------------------------------------------------------*/
            /*----                        ���B�z �j+���� "�j��" END                        ----*/
            /*---------------------------------------------------------------------------------*/



            /*--------------------------------------------------------------------------------------------------------*/
            /*----      �A�B�z "��j"�B"����N" �� �j+����"���N" �� �����㨮���ѳ����ĳ�j�"���N" BEGIN        ----*/
            /*--------------------------------------------------------------------------------------------------------*/


            /******************/
            /**  �������渹  **/
            /******************/

    	    if (ibig_comp[0]=='B' && IsPlyB=='N')
    	    {
    	        rc = cm_get_serial_num("C1", "BC", "0", "00", sTmpChDate, iestimate_sug);
    		iestimate_sug[8] = '9'; /* ��9�X�אּ"9"�A�H�קK�Pb2b���X���� */
    		printf("trace BC 1 iestimate_sug[%s] \n " ,iestimate_sug);
    	    }
    	    else if (ibig_comp[0]=='J' && IsPlyB=='N')
    	    {
    		rc = cm_get_serial_num("C1", "JC", "0", "00", sTmpChDate, iestimate_sug);
    		iestimate_sug[8] = '9'; /* ��9�X�אּ"9"�A�H�קK�Pb2b���X���� */
    		printf("trace JC 1 iestimate_sug[%s] \n " ,iestimate_sug);
    	    }
    	    else
    	    {
    	    	if ((fBothIns!=3) && (fBothIns_sug!=4))
    	    	{
    	    	    /* �j��B���N�P�@�����渹�A�e���j���I�w���L�� */
    	            rc = cm_get_serial_num("C1", "RN", sTmpIcomp, ibranch, sTmpChDate, iestimate_sug);
    	        }
            }


            if (rc!=0)
            {
	        printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
	        $ROLLBACK WORK;
	        return rc;
	    }

            if (fcard_class[0]=='2')
            {
	        mprem = (1.0)*v_prem;         /*���N�I�O�O(��ĳ��O�զX)*/
	    	if ((fBothIns==3)||((fBothIns==2)&&(fBothIns_sug==4))) tseq = 2 ;   /* ú�ڳ�Ǹ����1�}�l,ú�O�Ǹ��G ��j=1 , ����N=1 , �j��(=1)+���N(=2)  modify by sylvia 103.06.30  (1030410003_C2) */
	    	strcpy(cm_dbegin,dbegin_302); /* �O�I�_�� */
                strcpy(cm_dend,dend_302);   /* �O�I���� */
	    }
	    else
	    {

                strcpy(cm_dbegin,dply_bgn_comp); /* �O�I�_�� */
                strcpy(cm_dend,dply_end_comp);   /* �O�I���� */

                if (fBothIns==1)
                {
                    /* (����)��j */
	            /* �h�~��j(��"������j")��A����ĳ47��50�̡A���M�u���j��O�渹�A���g�J�������ɮɭn�H�j��B"���N"���}�G��
	               �ҥH�n���O���o�j��B���N�I���O�O */
	            /* ���o��b�j���I�������ɤ��D21�I�ؤ��O�O */
                    $EXECUTE prep_prem_sug2 Into $mcomp_prem_sug2 using  $ipolicy;
	        }

                /* ��j��ĳ���N */
		if (mcomp_prem_sug2 > 0)
		{
		    /* ����ĳ47�� 50�I�خɡA����insert�@��"���N�I"������δC��ú���� */
                    mprem = (1.0)*mcomp_prem_sug2;

                    if (strcmp(fsend_msg,"N") != 0)
                    {
                        strcpy(fsend_msg,"3"); /* ��j��ĳ���N, �|�ܦ��j+�� */
                    }

                    /* 102.05 �F���ЮסB�ĳq��ú�O����(cm_pre_receive.paydate)�� NULL(null_date) */
                    /*        ( frenew_type= 2 , ���Ӥ��|���F���Юץ�,���٬O�@�_�P�_) */
                    /* �t�X�@�γ�������cm_pre_receive�s�Wiins_kind_ply���(�j��=C1,���N=C2 add by sylvia 103.05.19 (1020111001_CG) */

                    /********************************************/
                    /**  Insert �@�γ������� (cm_pre_receive)  **/
                    /********************************************/

                    if ((Is_SP == 'Y')||(Is_JC == 'Y'))
                    {
                    	$EXECUTE prep_receive
                    	   using $iestimate_sug, "2", "C2", $ilicense, $nassured, $iapplicant, $napplicant, $itag,
                    	         $iengine, $dply_begin, $null_date, $mprem, $isub, $iofficer, $ileader, $iquota,
                    	         $icomm_obj, $iroute, $fcommit, $userid, $isys, $ipgid, $ftype_pol, $ftype_sp, $cm_dbegin, $cm_dend,
                    	         $fsend_msg, $mobile_phone, $ipolicy;
                    }
                    else
                    {
                    	$EXECUTE prep_receive
                    	   using $iestimate_sug, "2", "C2", $ilicense, $nassured, $iapplicant, $napplicant, $itag,
                    	         $iengine, $dply_begin, $paydate, $mprem, $isub, $iofficer, $ileader, $iquota,
                    	         $icomm_obj, $iroute, $fcommit, $userid, $isys, $ipgid, $ftype_pol, $ftype_sp, $cm_dbegin, $cm_dend,
                    	         $fsend_msg, $mobile_phone, $ipolicy;
                    }

                    /*******************************************/
                    /**  Insert �C��ú�O����� (ao_rcv_type)  **/
                    /*******************************************/

                    if (fuw_status_sug != 505)
                    {
                        /* ú�ڳ�Ǹ���1�}�l   modify by sylvia 103.06.30 (1030410003_C2) */
	                /* �t�X���O�X��,6074/6075�s�X���[�W���B�ˮ�   modify by sylvia 103.11.27 */
			$EXECUTE prep_rcv_type
			   using $iYear, $itransno_sug, $itransno_sug,"2", $iestimate_sug, $mprem, $ilicense, $nassured, $ipgid,
				 $paydate, $paydate_ext, $isub, $icomm_obj, $iofficer, "2" ;

		    }
		    else
		    {
		        $EXECUTE prep_upd_receive using $iestimate_sug;  /* ���Lú�ڳ�̡A����ú�ڳ�L��� */
		    }
		}
	        mprem = (1.0)*mcomp_prem_sug; /*�j���I�O�O(��ĳ��O�զX)*/
            }
            printf("trace iestimate_sug[%s]  \n " ,iestimate_sug);


            /********************************************/
            /**  Insert �@�γ������� (cm_pre_receive)  **/
            /********************************************/

            /* 102.05 �j���I�B�F���ЮסB�ĳq��ú�O����(cm_pre_receive.paydate)�� NULL(null_date) */
            /* �t�X�@�γ�������cm_pre_receive�s�Wiins_kind_ply���(�j��=C1,���N=C2 add by sylvia 103.05.19 (1020111001_CG) */
            if ((fcard_class[0]=='1')||(Is_JC == 'Y')||(Is_SP == 'Y'))
            {
                /* ���ݩ�JC��SP/10,SP/20���j���I,ftype_pol=SP & ftyep_sp = 01   �t�X���O�X��104/01/01�W�u�ק� add by sylvia 103.12.01*/
                if ((fcard_class[0]=='1') && (Is_JC != 'Y') && (strcmp(ftype_sp,"20") != 0))
                {
                	$EXECUTE prep_receive
                	   using $iestimate_sug, $fcard_class, $sIins_kind_ply, $ilicense, $nassured, $iapplicant, $napplicant, $itag,
                	         $iengine, $dply_begin, $null_date, $mprem, $isub, $iofficer, $ileader, $iquota,
                	         $icomm_obj, $iroute, $fcommit, $userid, $isys, $ipgid, "SP", "01", $cm_dbegin, $cm_dend,
                	         $fsend_msg, $mobile_phone, $ipolicy;
                }
                else
                {
                	$EXECUTE prep_receive
                	   using $iestimate_sug, $fcard_class, $sIins_kind_ply, $ilicense, $nassured, $iapplicant, $napplicant, $itag,
                	         $iengine, $dply_begin, $null_date, $mprem, $isub, $iofficer, $ileader, $iquota,
                	         $icomm_obj, $iroute, $fcommit, $userid, $isys, $ipgid, $ftype_pol, $ftype_sp, $cm_dbegin, $cm_dend,
                	         $fsend_msg, $mobile_phone, $ipolicy;
                }
            }
            else
            {
            	$EXECUTE prep_receive
            	   using $iestimate_sug, $fcard_class, $sIins_kind_ply, $ilicense, $nassured, $iapplicant, $napplicant, $itag,
            	         $iengine, $dply_begin, $paydate, $mprem, $isub, $iofficer, $ileader, $iquota,
            	         $icomm_obj, $iroute, $fcommit, $userid , $isys, $ipgid, $ftype_pol, $ftype_sp, $cm_dbegin, $cm_dend,
            	         $fsend_msg, $mobile_phone, $ipolicy;
	    }

            /*******************************************/
            /**  Insert �C��ú�O����� (ao_rcv_type)  **/
            /*******************************************/

	    if (fuw_status_sug != 505)
	    {
                /* �t�X���O�X��,6074/6075�s�X���[�W���B�ˮ�   modify by sylvia 103.11.27 */
		$EXECUTE prep_rcv_type
		   using $iYear, $itransno_sug, $itransno_sug,$tseq, $iestimate_sug, $mprem, $ilicense, $nassured, $ipgid,
		         $paydate, $paydate_ext, $isub, $icomm_obj, $iofficer, $fcard_class  ;

            }
            else
            {
        	$EXECUTE prep_upd_receive using $iestimate_sug; /* ���Lú�ڳ�̡A����ú�ڳ�L��� */
            }


            cm_char_split_3ymd(sTmpChDate_pay,tmYY,tmMM,tmDD);
            if (fuw_status_sug == 500)
            {
	        strcpy(itransno_sug_013, trim(itransno_sug_013));
		sprintf_s(itransno_sug_post,sizeof itransno_sug_post,"%s%s%s%s",tmYY,tmMM,tmDD,itransno_sug_013);  /* �l�F����ú�ڳ渹 */
	    }
	    else
	    {
		strcpy(itransno_sug_post, " ");
	    }

            /*********************************/
            /*  �^�gpolicy_302�Bpolicy_302f  */
            /*********************************/

            $EXECUTE prep_upd_302_sug
               using $iestimate_sug , $itransno_sug,$fuw_status_sug, $frenew_type ,
                     $itransno_sug_atm, $itransno_sug_post,
                     $itransno_sug_007, $itransno_sug_008, $itransno_sug_009, $itransno_sug_013,
                     $ipolicy;

            $EXECUTE prep_upd_302f_sug
               using $iestimate_sug , $itransno_sug,$fuw_status_sug, $frenew_type ,
                     $itransno_sug_atm, $itransno_sug_post,
                     $itransno_sug_007, $itransno_sug_008, $itransno_sug_009, $itransno_sug_013,
                     $ipolicy;


            /*--------------------------------------------------------------------------------------------------------*/
            /*----      �A�B�z "��j"�B"����N" �� �j+����"���N" �� �����㨮���ѳ����ĳ�j�"���N" BEGIN        ----*/
            /*--------------------------------------------------------------------------------------------------------*/


        }/* ��ĳ��O�զX(END) */


        n ++;
	if (n == 500)
	{
	    /* �C500��commit�@�� */
	    $COMMIT WORK;
	    $BEGIN WORK;
	    n = 0;
	}
    }
    $CLOSE cur_estimate;
    $FREE cur_estimate;

    $WHENEVER SQLERROR CONTINUE;
    $COMMIT WORK;

    if (fNoData!='Y'){
        return M_CM_OK;
    }else{
  	    return -1;
    }


errexit:
    printf("16335 ca3xxlib.ec WriteToEstimate() sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* �p�� 6074/6075 ���T������s�X (�Y�Ť���B���B���ˮֳW�h���s�X) add by sylvia 103.11.26 */
/* sOpt==> O:���O�զX N:��ĳ��O�զX */
/* sOpt2==> A:���O�զX_ATM    B:��ĳ��O�զX_�K�Q�ө� */
int GetTransNo(sOpt,TmpMprem,sOpt2)
char sOpt[2],sOpt2[2];
int TmpMprem;
{
   int n1, chk1, chk2, sum1, x;
   char sTrans1[21], sMprem[9],sTrans2[21];



   strcpy(sTrans1," ");strcpy(sTrans2," ");
   if (strcmp(sOpt,"O") == 0)
   {
      if (strcmp(sOpt2,"B") == 0)
        strcpy(sTrans1,trim(itransno_ori)); /* ���O�զX_�K�Q�ө�ú�ڽs��(ORI) */
      else
        strcpy(sTrans1,trim(itransno_ori_atm)); /* ���O�զX_ATMú�ڽs��(ORI) */
   }
   else if(strcmp(sOpt,"N") == 0)
   {
      if (strcmp(sOpt2,"B") == 0)
        strcpy(sTrans1,trim(itransno_sug)); /* ��ĳ��O�զX_�K�Q�ө�ú�ڽs��(SUG) */
      else
        strcpy(sTrans1,trim(itransno_sug_atm)); /* ��ĳ��O�զX_ATMú�ڽs��(SUG) */
   }
   sprintf_s(sMprem,sizeof sMprem,"%08d",TmpMprem);   /* �O�O */

   /* �Ĥ@�h */
   chk1 = sum1 = 0;
   for(n1=0;n1<13;n1++)
   {
      if (n1<6)
     {
        x = (sTrans1[n1]-48)*(n1+4);
     }
      else
     {
         x = (sTrans1[n1]-48)*(n1-5);
     }
     sum1 = sum1+(x%10); /* ���Ӧ�ƥ[�` */

   }
   chk1 = 10-(sum1%10) ; /* �Ĥ@���ˬd�X (10-(sum1���Ӧ��)) */
   /* printf("�Ĥ@�h:chk1[%d]sum1=[%d]\n",chk1,sum1); */

   /* �ĤG�h:���B�ˮ� */
   chk2 = sum1 = 0;
   for(n1=0;n1<8;n1++)
   {
     x = (sMprem[n1]-48)*(8-n1);
     sum1 = sum1+(x%10);  /* ���Ӧ�ƥ[�` */

   }
   chk2 = 10-(sum1%10); /* �ĤG���ˬd�X (10-(sum1���Ӧ��)) */
   /* printf("�ĤG�h:chk2[%d]sum1=[%d]\n",chk2,sum1); */


   sprintf_s(sTrans2,sizeof sTrans2,"%.13s%d",sTrans1,(chk1+chk2)%10);   /* ����ú��ú�� */

   if (strcmp(sOpt,"O") == 0)
   {
        if (strcmp(sOpt2,"B") == 0)
        {
            strcpy(itransno_ori,sTrans2); /* ���O�զX_�K�Q�ө�ú�ڽs��(ORI) */
        }
        else
        {
            strcpy(itransno_ori_atm,sTrans2); /* ���O�զX_ATMú�ڽs��(ORI) */
        }
   }
   else if(strcmp(sOpt,"N") == 0)
   {
      if (strcmp(sOpt2,"B") == 0)
      {
        strcpy(itransno_sug,sTrans2); /* ��ĳ��O�զX_�K�Q�ө�ú�ڽs��(SUG) */
       }
      else
      {
        strcpy(itransno_sug_atm,sTrans2); /* ��ĳ��O�զX_ATMú�ڽs��(SUG) */
       }
   }

   return SUCCESS;
}

/* -------------------------------------------------------------------------- */
long WriteToCar320(fChoice,iplyyear,iplymonth,intopt,ipgid,userid)
$int   iplyyear,iplymonth,intopt;
$char  fChoice[2],ipgid[9],userid[12];
{
    $char stmt[800], sTpSQL[10000], stmt2[200];
    $char sFirstDay[11],sLastDay[11], sIestimate_sug[21],sFullDB[21];
    $int   cnt_cmp;

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;


    if (intopt != 55)
        return M_CM_OK;

    printf("------ WriteToCar320 Start ------------ \n");

    /* ���o ���B�멳��� */
    sprintf_s(stmt,sizeof stmt, "SELECT '%02d/01/%d'::date,LAST_DAY('%02d/01/%d'::date) FROM systables WHERE tabid=1",
                  iplymonth,iplyyear,iplymonth,iplyyear);
    $PREPARE preLastDay FROM $stmt;
    $EXECUTE preLastDay INTO $sFirstDay,$sLastDay;
    printf("-- sFirstDay=[%s] sLastDay=[%s]\n ",sFirstDay,sLastDay);

    if (fChoice[0]=='1')
    {
        strcpy(stmt2," AND (select imgr from officer where iofficer = a.iofficer) <> '1' ") ;
    }
    else
    { strcpy(stmt2," AND (select imgr from officer where iofficer = a.iofficer) = '1' ") ;}

    $BEGIN WORK;

    sprintf_s(stmt,sizeof stmt, "select unique iestimate_sug from policy_302 a, newa00:ca_tmp_no b \
                    where a.ipolicy = b.ipolicy and a.dply_begin between '%s' and '%s' \
                      and a.option = '55' and fuw_status_sug >= 500 \
                      and iestimate_sug <> ' '  %s ",sFirstDay,sLastDay,stmt2);
    $PREPARE  per_fb1 FROM $stmt;
    $DECLARE  cusr_fb1 CURSOR FOR per_fb1;
    $OPEN     cusr_fb1;
    while(1)
    {
        $FETCH cusr_fb1 INTO $sIestimate_sug;
        if(SQLCODE == SQLNOTFOUND)  break;

        cnt_cmp = 0;
        $select count(iestimate_sug) into $cnt_cmp from policy_302 where iestimate_sug = $sIestimate_sug and fcard_class = '2';

        strcpy(sFullDB, get_car_full_dbname(sIestimate_sug));

        if (cnt_cmp > 0)
        {
            /* ����B�j+�� */
            sprintf_s(sTpSQL,sizeof sTpSQL,
                "insert into %s:estimate \
                    (iestimate, qply2_period, dply2_begin, dply2_end, qply1_period, \
                     dply1_begin, dply1_end, fassured, iassured,  nassured, \
                     ibirth, fsex, fmarriage, aassured, aassured_zip, \
                     itel, iissue_ym, ipro_year, ibrand, nbrand_abbr, \
                     icar_type2, icar_type1, ncar_abbr, qcylinder, iengine, \
                     itag, mcar_price, nequipment, mpremium2, mpremium1, \
                     ibig_comp, ibig_branch, ibig_office, ibig_sales, iresource,  \
                     iofficer2, iofficer1, iexaminer, dexamine, ientry, \
                     dentry, dapply, fcal_way, idmg_rate, pdmg_factor, \
                     ibrg_rate, pbrg_factor, ibranch, qpt, fpt, \
                     psex_age2, psex_age1, psex_age_damage, lia_class, plia_acc2, \
                     plia_acc1, pdmg_acc, fcomp_class, fcomp_class_last, ipay_way, \
                     iquery_num_c, iquery_num, icar_flag1, icar_flag2, qpro_month, \
                     iaccept, iquery_num_damage, iapplicant, napplicant, dbirth, \
                     dissue, iextra_charge, mequipment, iroute_prop, iroute, \
                     iofficer_prmt, iquota_prmt, ileader_prmt, nfax_cus, nemail_cus, \
                     nroute_cus, nname_cus, itel_cus, mobil_phone_cus, nnote_cus, \
                     nnote_leader, irate_type1, irate_type2, bzfrom1, bzfrom2, \
                     iroute_comm1, iroute_comm2, icomm_obj1, icomm_obj2, qlia_acc_sum, \
                     qdmg_acc_sum, fapplicant, fsex_appl, dbirth_appl, itel_appl, \
                     ndeputy_appl, nrelation_appl, ndeputy_assured, fuw_status, iuw_first, \
                     duw_first, duw_submit, idm_number, pdmg_acc2, qdmg_acc_sum2, \
                     iquery_num_damage2, pdmg_acc3, qdmg_acc_sum3, iquery_num_damage3, qdrunk_driving, \
                     fout_print, fmail_type, iassured_cntry, iapplicant_cntry, funknown_dmg, \
                     mbus_rule,mbusiness, apayment, apayment_zip, fdiscount ) \
              select a.iestimate_sug, a.qply_period, a.dply_begin, a.dply_end, nvl(b.qply_period,0), \
                     b.dply_begin, b.dply_end, a.fassured, a.ilicense, \
                     replace(replace(a.nassured,'����',''),'�p�j',''), \
                     a.ibirth, a.fsex, a.fmarriage, a.aassured[4,90], a.aassured[1,3], \
                     a.itel, a.iissue_ym, a.ipro_year, a.ibrand, a.nbrand_abbr, \
                     a.icar_type, b.icar_type, a.ncar_type, a.qcylinder, a.iengine, \
                     a.itag, (replace(a.mcar_price,',')/10000), a.nequipment, a.v_prem, nvl(b.mcomp_prem_sug,0), \
                     a.ibig_comp, a.ibig_branch, a.ibig_office, a.ibig_sales, \
                     (select fprop from officer where iofficer = a.iofficer), \
                     a.iofficer, b.iofficer, a.ileader, date(a.dupdate), a.ileader, \
                     date(a.dupdate), today, 'M', a.idmg_rate, a.dmg_factor, \
                     a.brg_factor, a.brg_factor, a.iestimate_sug[1,2], a.qpt, a.fpt, \
                     a.psex_age, nvl(b.psex_age,0), a.psex_age_damage, a.lia_class, a.plia_acc, \
                     nvl(b.plia_acc_c,0), a.pdmg_acc, b.fcomp_class, b.fcomp_class_last , ' ' , \
                     b.iquery_num, a.iquery_num, ' ', ' ', a.qpro_month, \
                     ' ', decode(a.funknown_dmg_sug,' ',a.iquery_num_damage_sug, '1', a.iquery_num_damage_sug, ' '), \
                     a.iapplicant, a.napplicant, a.dbirth, \
                     a.dissue, a.bzfrom, a.mequipment, a.iroute_prop, a.iroute, \
                     ' ', ' ', ' ', ' ', ' ', \
                     ' ', ' ', ' ', ' ', ' ', \
                     ' ', nvl(b.irate_type,' '), nvl(a.irate_type,' '), nvl(b.bzfrom,' '), nvl(a.bzfrom,' '), \
                     nvl(b.iroute_comm,' '), nvl(a.iroute_comm,' '), nvl((select icomm_obj from officer where iofficer = b.iofficer),' '), \
                     nvl((select icomm_obj from officer where iofficer = a.iofficer),' '), a.qlia_acc_sum, \
                     a.qdmg_acc_sum, a.fapplicant, a.fsex_appl, a.dbirth_appl, ' ', \
                     a.ndeputy_appl, a.nrelation_appl, a.ndeputy_assured, a.fuw_status_sug, 'system', \
                     a.dupdate, a.dupdate, ' ', \
                     decode(a.funknown_dmg_sug,'2',a.pdmg_acc_sug,'0'), \
                     decode(a.funknown_dmg_sug,'2',a.qdmg_acc_sum_sug,0), \
                     decode(a.funknown_dmg_sug,'2',a.iquery_num_damage_sug,' '), \
                     decode(a.funknown_dmg_sug,'3',a.pdmg_acc_sug,'0'), \
                     decode(a.funknown_dmg_sug,'3',a.qdmg_acc_sum_sug,0), \
                     decode(a.funknown_dmg_sug,'3',a.iquery_num_damage_sug,' '), \
                     nvl(b.qdrunk_driving,0), '0', '0', a.iassured_cntry, a.iapplicant_cntry, \
                     a.funknown_dmg_sug, \
                     (select unique mbusiness from compulsory_premium where icar_type = b.icar_type \
                      and qperiod = '12' and drate =  \
                      (select max(drate) from compulsory_premium where drate <= b.dply_begin)), \
                      (select unique mbusiness from compulsory_premium where icar_type = b.icar_type \
                      and qperiod = '12' and drate =  \
                      (select max(drate) from compulsory_premium where drate <= b.dply_begin)), \
                     a.apayment[4,90], a.apayment[1,3], 'N' \
                from policy_302 a, outer policy_302 b \
               where a.iestimate_sug = b.iestimate_sug \
                 and a.fcard_class = '2' and b.fcard_class = '1' and a.iestimate_sug = '%s' ", sFullDB, sIestimate_sug );
        }else { /* ��j */
            sprintf_s(sTpSQL,sizeof sTpSQL,
                "insert into %s:estimate \
                    (iestimate, qply2_period, dply2_begin, dply2_end, qply1_period, \
                     dply1_begin, dply1_end, fassured, iassured,  nassured, \
                     ibirth, fsex, fmarriage, aassured, aassured_zip, \
                     itel, iissue_ym, ipro_year, ibrand, nbrand_abbr, \
                     icar_type2, icar_type1, ncar_abbr, qcylinder, iengine, \
                     itag, mcar_price, nequipment, mpremium2, mpremium1, \
                     ibig_comp, ibig_branch, ibig_office, ibig_sales, iresource,  \
                     iofficer2, iofficer1, iexaminer, dexamine, ientry, \
                     dentry, dapply, fcal_way, idmg_rate, pdmg_factor, \
                     ibrg_rate, pbrg_factor, ibranch, qpt, fpt, \
                     psex_age2, psex_age1, psex_age_damage, lia_class, plia_acc2, \
                     plia_acc1, pdmg_acc, fcomp_class, fcomp_class_last, ipay_way, \
                     iquery_num_c, iquery_num, icar_flag1, icar_flag2, qpro_month, \
                     iaccept, iquery_num_damage, iapplicant, napplicant, dbirth, \
                     dissue, iextra_charge, mequipment, iroute_prop, iroute, \
                     iofficer_prmt, iquota_prmt, ileader_prmt, nfax_cus, nemail_cus, \
                     nroute_cus, nname_cus, itel_cus, mobil_phone_cus, nnote_cus, \
                     nnote_leader, irate_type1, irate_type2, bzfrom1, bzfrom2, \
                     iroute_comm1, iroute_comm2, icomm_obj1, icomm_obj2, qlia_acc_sum, \
                     qdmg_acc_sum, fapplicant, fsex_appl, dbirth_appl, itel_appl, \
                     ndeputy_appl, nrelation_appl, ndeputy_assured, fuw_status, iuw_first, \
                     duw_first, duw_submit, idm_number, pdmg_acc2, qdmg_acc_sum2, \
                     iquery_num_damage2, pdmg_acc3, qdmg_acc_sum3, iquery_num_damage3, qdrunk_driving, \
                     fout_print, fmail_type, iassured_cntry, iapplicant_cntry, funknown_dmg, \
                     mbus_rule, mbusiness, apayment, apayment_zip, fdiscount ) \
              select a.iestimate_sug, 0, '', '', a.qply_period, \
                     a.dply_begin, a.dply_end, a.fassured, a.ilicense, a.nassured, \
                     a.ibirth, a.fsex, a.fmarriage, a.aassured[4,90], a.aassured[1,3], \
                     a.itel, a.iissue_ym, a.ipro_year, a.ibrand, a.nbrand_abbr, \
                     ' ', a.icar_type, a.ncar_type, a.qcylinder, a.iengine, \
                     a.itag, (replace(a.mcar_price,',')/10000), a.nequipment, 0, a.mcomp_prem_sug, \
                     a.ibig_comp, a.ibig_branch, a.ibig_office, a.ibig_sales, \
                     (select fprop from officer where iofficer = a.iofficer), \
                     a.iofficer, a.iofficer, a.ileader, date(a.dupdate), a.ileader, \
                     date(a.dupdate), today, 'M', a.idmg_rate, a.dmg_factor, \
                     a.brg_factor, a.brg_factor, a.iestimate_sug[1,2], a.qpt, a.fpt, \
                     0, a.psex_age, 0, a.lia_class, 0.0, \
                     a.plia_acc_c, 0.0, a.fcomp_class, a.fcomp_class_last , ' ' , \
                     a.iquery_num, ' ', ' ', ' ', a.qpro_month, \
                     ' ', decode(a.funknown_dmg_sug,' ',a.iquery_num_damage_sug, '1', a.iquery_num_damage_sug, ' '), \
                     a.iapplicant, a.napplicant, a.dbirth, \
                     a.dissue, a.bzfrom, a.mequipment, a.iroute_prop, a.iroute, \
                     ' ', ' ', ' ', ' ', ' ', \
                     ' ', ' ', ' ', ' ', ' ', \
                     ' ', a.irate_type, a.irate_type, nvl(a.bzfrom,' '), nvl(a.bzfrom,' '), \
                     nvl(a.iroute_comm,' '), nvl(a.iroute_comm,' '), nvl((select icomm_obj from officer where iofficer = a.iofficer),' '), \
                     nvl((select icomm_obj from officer where iofficer = a.iofficer),' '), 0, \
                     0, a.fapplicant, a.fsex_appl, a.dbirth_appl, ' ', \
                     a.ndeputy_appl, a.nrelation_appl, a.ndeputy_assured, a.fuw_status_sug, 'system', \
                     a.dupdate, a.dupdate, ' ', \
                     decode(a.funknown_dmg_sug,'2',a.pdmg_acc_sug,'0'), \
                     decode(a.funknown_dmg_sug,'2',a.qdmg_acc_sum_sug,0), \
                     decode(a.funknown_dmg_sug,'2',a.iquery_num_damage_sug,' '), \
                     decode(a.funknown_dmg_sug,'3',a.pdmg_acc_sug,'0'), \
                     decode(a.funknown_dmg_sug,'3',a.qdmg_acc_sum_sug,0), \
                     decode(a.funknown_dmg_sug,'3',a.iquery_num_damage_sug,' '), \
                     nvl(a.qdrunk_driving,0), '0', '0', a.iassured_cntry, a.iapplicant_cntry, \
                     a.funknown_dmg_sug, \
                     (select unique mbusiness from compulsory_premium where icar_type = a.icar_type \
                      and qperiod = '12' and drate =  \
                      (select max(drate) from compulsory_premium where drate <= a.dply_begin)), \
                     (select unique mbusiness from compulsory_premium where icar_type = a.icar_type \
                      and qperiod = '12' and drate =  \
                      (select max(drate) from compulsory_premium where drate <= a.dply_begin)), \
                     a.apayment[4,90], a.apayment[1,3], 'N' \
                from policy_302 a \
               where a.fcard_class = '1' and a.iestimate_sug = '%s' ", sFullDB, sIestimate_sug );
        }


        $PREPARE pre_fb2 FROM $sTpSQL;
        $EXECUTE pre_fb2;


        sprintf_s(sTpSQL,sizeof sTpSQL,
            "insert into %s:est_ins_type \
                (iestimate, iins_type, minjured_cover, mdeath_cover, mdamage_cover, \
                   mdeduct, mins_premium, qserial, mdiscount, drate_ym, \
                   mprem, qday, mexpense, mexp_disc, provision, \
                   safe_rate, manage_rate, mdrunk_prem, mdrunk_pure_prem, pcar_price, \
                   mcommission) \
             select a.iestimate_sug, b.iins_type, b.minjured_cover, b.mdeath_cover, b.mdamage_cover, \
                    b.mdeduct, b.mins_premium, b.qserial, b.mdiscount, b.drate_ym, \
                    b.mprem, b.qday, b.mexpense, b.mexp_disc, b.provision, \
                    b.safe_rate, b.manage_rate, b.mdrunk_prem, b.mdrunk_pure_prem, b.pcar_price, \
                    case when b.iins_type = '21' then \
                       (select unique mservice from cm_route_commc \
                         WHERE iroute = (select iroute_main from cm_route where iroute = a.iroute) \
                           and insure_type = 'C' and iins_cat = \
                               (select ncode from cu_code_data where itype = '97' and icode = a.icar_type) \
                           and irate_type = a.irate_type  and iroute_comm = a.iroute_comm \
                           and iyear = 0 and iins_type = '21') else 0 end \
               from policy_302 a, ply_ins_type_302 b \
              where a.ipolicy = b.ipolicy and b.mdamage_cover > 0 \
                and a.iestimate_sug = '%s' ", sFullDB, sIestimate_sug );

        $PREPARE pre_fb3 FROM $sTpSQL;
        $EXECUTE pre_fb3;



        sprintf_s(sTpSQL,sizeof sTpSQL,
            "insert into %s:ca_pa_est \
                 (iestimate, iins_type, iinsurant, ninsurant, dbirth, \
                  ainsurant, iins_scope, icareer, mins_amt, mins_premium, \
                  mdiscount, napplicant, relation_appl, nbeneficiary, relation_bene, \
                  daily_pay, mr_ins_prem, mr_pure_prem ) \
             select a.iestimate_sug, b.iins_type, b.iinsurant, b.ninsurant, b.dbirth, \
                    b.ainsurant, b.iins_scope, b.icareer, b.mins_amt, b.mins_premium, \
                    b.mdiscount, b.napplicant, b.relation_appl, b.nbeneficiary, b.relation_bene, \
                    b.daily_pay, b.mr_ins_prem, b.mr_pure_prem \
               from policy_302 a, ca_pa_ply_302 b \
              where a.ipolicy = b.ipolicy and b.mins_amt > 0 \
                and a.iestimate_sug = '%s' ", sFullDB, sIestimate_sug );
        $PREPARE pre_fb4 FROM $sTpSQL;
        $EXECUTE pre_fb4;

        sprintf_s(sTpSQL,sizeof sTpSQL,
            "insert into %s:est_ins_cover \
                 (iestimate, iins_type, icover_type, mcover, mcover_prem, \
                  mdiscount, mprem, mpure_prem ) \
             select a.iestimate_sug, b.iins_type, b.icover_type, b.mcover, b.mcover_prem, \
                    b.mdiscount, b.mprem, 0 \
               from policy_302 a, ply_ins_cover_302 b \
              where a.ipolicy = b.ipolicy  and b.mcover > 0 \
                and a.iestimate_sug = '%s'", sFullDB, sIestimate_sug );
        $PREPARE pre_fb5 FROM $sTpSQL;
        $EXECUTE pre_fb5;


    }
    $CLOSE cusr_fb1;
    $FREE cusr_fb1;
    $COMMIT WORK;
    printf("------ WriteToCar320 END ------------ \n");
    return M_CM_OK;

errexit:
    printf("17646 ca3xxlib.ec WriteToCar320() sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* -------------------------------------------------------------------------- */
char *get_car_full_dbname(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[31];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}
/* -------------------------------------------------------------------------- */
