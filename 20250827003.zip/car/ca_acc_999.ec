#include <stdio.h>
#include <commsgs.h>
$include sqlca;
$include datetime;
#include "ISvar.h"
#include "safeclib.h"

long getPlyInsHistData(fIclaim, fClmInsType, fMdeduct, fProvision, fminjured_cover, fmdeath_cover, fmdamage_cover, fdbegin)
$char *fIclaim;
$char *fClmInsType;
$long  *fMdeduct;
$char  *fProvision;
$long *fminjured_cover;
$long *fmdeath_cover;
$long *fmdamage_cover; 
$long *fdbegin;
{
char sfull[31];
$char sIbranch_in[3];
$char stmtfun[4096];
$char sIpolicy[21];

$char iins_type[7],iins_ply[7];
$long mdeduct=0;
$char provision[21];
$char dendorse[11];
$char fedr_status[3];
$char sDaccident[31];
$long minjured_cover=0, mdeath_cover=0, mdamage_cover=0;
$long ldply_begin=0;

$char iclaim[21],IInsType[7];

  $WHENEVER SQLERROR GOTO errexit;
  
  strcpy(iclaim,fIclaim);
  strcpy(IInsType,trim(fClmInsType));

  $select ipolicy, ibranch_in, daccident
     into $sIpolicy, $sIbranch_in, $sDaccident
     from ca_clm_process
    where iclaim = $iclaim;
    if (SQLCODE == SQLNOTFOUND)
    {
       *fMdeduct = 0;
       strcpy(fProvision,"");
       return M_CM_NOT_FOUND;
    }
  printf("sIpolicy[%s],sIbranch_in[%s],sDaccident[%s] \n",sIpolicy, sIbranch_in, sDaccident);
  strcpy(sfull, get_full_dbname(sIbranch_in));

  if(strncmp(IInsType,"157",3) == 0 || strncmp(IInsType,"158",3) == 0 || strncmp(IInsType,"159",3) == 0 || strncmp(IInsType,"160",3) == 0)
  {
  sprintf_s(stmtfun, sizeof stmtfun,
   "SELECT first 1                                    \
           insurance_type.iins_type AS iins_type,     \
           insurance_type.iins_ply  AS iins_ply,      \
           PlyInsTypeHist.mdeduct,                    \
           nvl(PlyInsTypeHist.provision,' '),         \
           nvl(PlyInsTypeHist.dendorse,' '),          \
           nvl(PlyInsTypeHist.fedr_status,' '),       \
           PlyInsTypeHist.minjured_cover,              \
           PlyInsTypeHist.mdeath_cover,                \
           PlyInsTypeHist.mdamage_cover,               \
           date(PlyInsTypeHist.dtedr_begin)          \
      FROM sysdb:insurance_type AS insurance_type INNER JOIN %s:ply_ins_type_hist AS PlyInsTypeHist ON insurance_type.iins_ply = PlyInsTypeHist.iins_type \
     WHERE PlyInsTypeHist.fedr_status   < 80          \
       AND PlyInsTypeHist.ipolicy       = ?           \
       AND insurance_type.iins_type     = ?           \
       AND PlyInsTypeHist.dtedr_begin <= ? \
       AND PlyInsTypeHist.dtedr_end >= ?  \
  ORDER BY PlyInsTypeHist.dedr_begin DESC, PlyInsTypeHist.dendorse DESC,  PlyInsTypeHist.fedr_status DESC, iins_ply DESC, iins_type DESC ",sfull);
  }
  else
  {
  sprintf_s(stmtfun, sizeof stmtfun,
   "SELECT first 1                                    \
           insurance_type.iins_type AS iins_type,     \
           insurance_type.iins_ply  AS iins_ply,      \
           PlyInsTypeHist.mdeduct,                    \
           nvl(PlyInsTypeHist.provision,' '),         \
           nvl(PlyInsTypeHist.dendorse,' '),          \
           nvl(PlyInsTypeHist.fedr_status,' '),       \
           PlyInsTypeHist.minjured_cover,              \
           PlyInsTypeHist.mdeath_cover,                \
           PlyInsTypeHist.mdamage_cover,               \
           PlyInsTypeHist.dedr_begin \
      FROM sysdb:insurance_type AS insurance_type INNER JOIN %s:ply_ins_type_hist AS PlyInsTypeHist ON insurance_type.iins_ply = PlyInsTypeHist.iins_type \
     WHERE PlyInsTypeHist.fedr_status   < 80          \
       AND PlyInsTypeHist.ipolicy       = ?           \
       AND insurance_type.iins_type     = ?           \
       AND CAST(PlyInsTypeHist.dedr_begin AS DATETIME year TO minute)+ 12 units hour <= ? \
       AND CAST(PlyInsTypeHist.dedr_end AS DATETIME year TO minute)+ 12 units hour >= ?  \
  ORDER BY PlyInsTypeHist.dedr_begin DESC, PlyInsTypeHist.dendorse DESC,  PlyInsTypeHist.fedr_status DESC, iins_ply DESC, iins_type DESC ",sfull);
  }
  
  printf("stmtfun[%s]\n",stmtfun);
  $prepare getHistData from $stmtfun;
  $execute getHistData
      into $iins_type, $iins_ply, $mdeduct, $provision, $dendorse, $fedr_status, $minjured_cover, $mdeath_cover, $mdamage_cover, $ldply_begin
     using $sIpolicy, $IInsType, $sDaccident, $sDaccident;
  if (SQLCODE == SQLNOTFOUND)
  {
       *fMdeduct = 0;
       strcpy(fProvision,"");
       return M_CM_NOT_FOUND;
  }
  
  printf("--iins_type[%s],iins_ply[%s],mdeduct[%d],provision[%s],dendorse[%s],fedr_status[%s],minjured_cover[%d],mdeath_cover[%d],mdamage_cover[%d],ldply_begin[%d] \n",
          iins_type,iins_ply,mdeduct,provision,dendorse,fedr_status,minjured_cover,mdeath_cover,mdamage_cover,ldply_begin);
  
  *fMdeduct = mdeduct;
  strcpy(fProvision, trim(provision));
  *fminjured_cover = minjured_cover;
  *fmdeath_cover = mdeath_cover;
  *fmdamage_cover = mdamage_cover;
  *fdbegin = ldply_begin;
 
	return M_CM_OK;

errexit:
    printf("getPlyHistData:SQLCODE=%ld sqlerrm=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}


char *getPolicyBakData(fIclaim)
$char *fIclaim;
{
char sfull[31];
$char sIbranch_in[3];
$char stmtfun[3000];
$char sIpolicy[21];
$static char sIendorse[21];
$char dClaim[11];
$static char rtnInum[21];
$char sDcreate[31];
$int  icnt=0;
$char iclaim[21];

  $WHENEVER SQLERROR GOTO errexit;
  stmtfun[0] = '\0';
  strcpy(iclaim,fIclaim);
  strcpy(rtnInum,"");
  strcpy(sIendorse,"");
  icnt = 0;

  printf("iclaim[%s]\n",iclaim);

  $select ipolicy, ibranch_in
     into $sIpolicy, $sIbranch_in
     from ca_clm_process
    where iclaim = $iclaim;
    if (SQLCODE == SQLNOTFOUND) 
    {
       return rtnInum;
    }

  strcpy(sfull, get_full_dbname(sIbranch_in));

  /* �����S��bak, �����^�Ǫť�(Ū���̷s�O��) */ 
  sprintf_s(stmtfun, sizeof stmtfun,
    " select count(*)     \
        from %s:ply_relation_bak    \
       where ipolicy = ? ",sfull);
  printf("stmtfun[%s]\n",stmtfun);
  $prepare getbkcnt1 from $stmtfun;
  $execute getbkcnt1 into $icnt using $sIpolicy;

  if (icnt == 0) return rtnInum;
  
  /* ������z���ᦳ��諸��1��bak, �Y�O���z���U�쪺�̷s�O���� (��Ū���Q�O�I�H�P���z���U�ۦP��bak) */
  sprintf_s(stmtfun, sizeof stmtfun,
    " select first 1 a.iendorse, d.dcreate          \
        from %s:policy_bak a, %s:appraisal b, %s:adjustment_ply c, %s:ply_relation_bak d  \
       where b.iclaim       = ?                 \
         and a.ipolicy      = b.ipolicy         \
         and a.iendorse     = d.iendorse        \
         and b.iclaim       = c.iclaim          \
         and a.iassured     = c.iassured        \
         and a.iassured_ext = c.iassured_ext    \
         and d.dcreate     >= b.dclaim          \
       order by 2,1 asc ", sfull, sfull, sfull, sfull);
  printf("stmtfun[%s]\n",stmtfun);
  $prepare getend1 from $stmtfun;
  $execute getend1
      into $sIendorse, $sDcreate 
     using $iclaim;
  if (SQLCODE == SQLNOTFOUND)
  {  
      /* �AŪ�̷s�O��ݬO�_���P�Q�O�I�H��� (Ū���Q�O�I�H�P���z�ɬۦP���̷s�O�� ) */
      sprintf_s(stmtfun, sizeof stmtfun,
        " select first 1 '' as iendorse, date(b.dclaim)   \
            from %s:policy a, %s:appraisal b, %s:adjustment_ply c  \
           where b.iclaim       = ?                 \
             and a.ipolicy      = b.ipolicy         \
             and b.iclaim       = c.iclaim          \
             and a.iassured     = c.iassured        \
             and a.iassured_ext = c.iassured_ext ", sfull, sfull, sfull);
      printf("stmtfun[%s]\n",stmtfun);
      $prepare getend2 from $stmtfun;
      $execute getend2
          into $sIendorse, $sDcreate 
         using $iclaim;
      if (SQLCODE == SQLNOTFOUND)
      {
          /* �A����z���e����諸��1��bak (��Ū���Q�O�I�H�P���z���U�ۦP��bak) */
          sprintf_s(stmtfun, sizeof stmtfun,
            " select first 1 a.iendorse, d.dcreate      \
                from %s:policy_bak a, %s:appraisal b, %s:adjustment_ply c, %s:ply_relation_bak d  \
               where b.iclaim       = ?                 \
                 and a.ipolicy      = b.ipolicy         \
                 and a.iendorse     = d.iendorse        \
                 and b.iclaim       = c.iclaim          \
                 and a.iassured     = c.iassured        \
                 and a.iassured_ext = c.iassured_ext    \
                 and d.dcreate      < b.dclaim          \
               order by 2,1 desc ", sfull, sfull, sfull, sfull); 
          printf("stmtfun[%s]\n",stmtfun);
          $prepare getend3 from $stmtfun;
          $execute getend3
              into $sIendorse, $sDcreate 
             using $iclaim; 
          if (SQLCODE == SQLNOTFOUND) 
          {
              /* ����z���ᦳ��諸��1��bak (��Ū���Q�O�I�HId)  */
              sprintf_s(stmtfun, sizeof stmtfun,
                " select first 1 a.iendorse, d.dcreate      \
                    from %s:policy_bak a, %s:appraisal b, %s:ply_relation_bak d  \
                   where b.iclaim       = ?                 \
                     and a.ipolicy      = b.ipolicy         \
                     and a.iendorse     = d.iendorse        \
                     and d.dcreate     >= b.dclaim          \
                   order by 2,1 asc ", sfull, sfull, sfull);
              printf("stmtfun[%s]\n",stmtfun);
              $prepare getend4 from $stmtfun;
              $execute getend4
                  into $sIendorse, $sDcreate 
                 using $iclaim;
              if (SQLCODE == SQLNOTFOUND)
              {
              	  $CLOSE getend4;
                  return rtnInum;               
              }
          }
      }
  }
  strcpy(sIendorse,trim(sIendorse));
  printf("sIendorse[%s]\n",sIendorse);
  return sIendorse;

errexit:
    printf("getPolicyBakData:SQLCODE=%ld sqlerrm=%s\n",SQLCODE,sqlca.sqlerrm);
    return rtnInum;
}

