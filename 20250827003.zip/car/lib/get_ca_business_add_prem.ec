/*
   Name       : get_ca_business_add_prem
   Purpose    : �̸g��N���M�~�ȥN�X�ܷ~�ȥN�X�p���O�O�]�w��(ca_business_add_prem)Ū���p�����B(madd_prem)
                (�g��N���ݩ�P���M�פ~��Ū��)

   Input      : v_iofficer         �g��N�� 
                v_ibusiness        �~�ȥN�X

   return code: M_CM_OK            ���\
                v_madd_prem        �պ�O�O 
                v_sMsg             �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"

$include "var_length.h";

void end_get_ca_business_add_prem( );

long get_ca_business_add_prem( char   *v_iofficer,
                               char   *v_ibusiness,
                               long   *v_madd_prem,
                               char   *v_sMsg)
{
  long     rtncode;
  $long    madd_prem=0;
  $char    iofficer[IOFFICER], ibusiness[IBUSINESS];

    $WHENEVER SQLERROR GOTO errexit;

    puts("");
    puts("******************************");
    puts("begin get_ca_business_add_prem function");
    printf("    v_iofficer[%s], v_ibusiness[%s]\n", v_iofficer, v_ibusiness);

    strcpy( iofficer,  v_iofficer);
    strcpy( ibusiness, v_ibusiness);

    $SELECT madd_prem
       INTO $madd_prem
       FROM ca_business_add_prem
      WHERE iofficer  = $iofficer
        AND ibusiness = $ibusiness;

    if(SQLCODE==SQLNOTFOUND)
    {
        sprintf_s( v_sMsg,250, "    madd_prem not in table ca_business_add_prem by iofficer[%s], ibusiness[%s]\n", 
                              iofficer, ibusiness);
        end_get_ca_business_add_prem( v_sMsg);
        return M_CA_IBUSINESS_ADD_PREM;   /* �~�ȥN�X�p���O�O�����ɡA�нT�{�A�ά��ӫO����car146�]�w */
    }


    *v_madd_prem = madd_prem;

    sprintf_s( v_sMsg,250, "Found �~�ȥN�X�p���O�O(ca_business_add_prem.madd_prem)[%d]\n", madd_prem);

    end_get_ca_business_add_prem( v_sMsg);

    return M_CM_OK;

errexit:

  sprintf_s( v_sMsg,250, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  end_get_ca_business_add_prem( v_sMsg);
  return SQLCODE;

}

void end_get_ca_business_add_prem( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_ca_business_add_prem function");
  puts("******************************");
  puts("");
}
