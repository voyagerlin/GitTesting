
#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"

/* ------------------------------------------------------------------------------------
'�Ǧ^2�Ӥ���۹j�X�~�X��X��
'�y�k�GGetInterval�_�l��, ������, �~, ��, ��
'input:�_�l��,������
'output:�~, ��, ��
'ex: GetInterval #2/29/2008#, #9/28/2009#, iYear, iMonth, iDay ==> 1�~, 7��, 0��
------------------------------------------------------------------------------------ */
long GetInterval(startDate, endDate, iYear, iMonth, iDay)
$long startDate, endDate;
long *iYear, *iMonth, *iDay;
{
long iTmp=0, rc=0;
$char stmt[512];

    $WHENEVER SQLERROR GOTO errexit;

    printf("1:GetInterval:startDate[%d],endDate[%d]\n", startDate, endDate);
    rc = GetIntervalPart( startDate, endDate, "Y", iYear);
    if( rc != M_CM_OK) return rc;
    sprintf_s(stmt, sizeof stmt, "select first 1 (date_add( %d, interval(%d) year to year))"
                   "  from systables ", startDate, *iYear);
    printf("stmt[%s]\n", stmt);
    $PREPARE prep5 FROM $stmt;
    $EXECUTE prep5 INTO $startDate;
    $FREE prep5;

    printf("2:GetInterval:startDate[%d],endDate[%d]\n", startDate, endDate);
    rc = GetIntervalPart(startDate, endDate, "M", iMonth);
    if( rc != M_CM_OK) return rc;

    sprintf_s(stmt, sizeof stmt, "select first 1 (date_add( %d, interval(%d) month to month))"
                   "  from systables ", startDate, *iMonth);
    printf("stmt[%s]\n", stmt);
    $PREPARE prep4 FROM $stmt;
    $EXECUTE prep4 INTO $startDate;
    $FREE prep4;

    printf("3:GetInterval:startDate[%d],endDate[%d]\n", startDate, endDate);
    rc = GetIntervalPart(startDate, endDate, "D", iDay);
    if( rc != M_CM_OK) return rc;
    printf("����۹j[%d]�~,[%d]��,[%d]��\n", *iYear, *iMonth, *iDay);
    return M_CM_OK;

errexit:
  printf ("GetInterval:SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  return SQLCODE;
}

/* ------------------------------------------------------------------------------------
�Ǧ^2�Ӥ�����϶��A����������~�B��B��
�y�k�GGetIntervalPart(�_�l�� as date, ������ as date, ������ as string)
input:�_�l��,������
output: �϶�
ex: GetIntervalPart((#2/29/2008#, #2/28/2009# , "Y") ==> 1 �~
ex: GetIntervalPart((#2/29/2008#, #2/28/2009# , "M") ==> 12 ��
ex: GetIntervalPart((#2/29/2008#, #2/28/2009# , "D") ==> 365 ��
------------------------------------------------------------------------------------ */
long GetIntervalPart( startDate, endDate, interval, IntervalPart)
$long startDate, endDate;
char *interval;
long *IntervalPart;
{
$char stmt[512];
    $WHENEVER SQLERROR GOTO errexit;
    printf("GetIntervalPart:interval[%c],startDate[%d],endDate[%d]\n", *interval,startDate, endDate);
    switch( *interval)
    {
        case 'Y':
            *IntervalPart = (endDate - startDate) / 366;    /* ��Ʀ~ */
            sprintf_s(stmt, sizeof stmt, "select first 1 (date_add( %d, interval(%d) year to year))"
                           "  from systables ", startDate, *IntervalPart+1);
            printf("stmt[%s]\n", stmt);
            $PREPARE prep3 FROM $stmt;
            $EXECUTE prep3 INTO $startDate;
            $FREE prep3;
            for(;;)
            {
                if( startDate > endDate) break;
                $select first 1 (date_add( $startDate, interval(1) year to year))
                   into $startDate
                   from systables;
                *IntervalPart = *IntervalPart + 1;
            }
            break;
        case 'M':
            *IntervalPart = (endDate - startDate) / 31;    /* ��Ƥ� */
            sprintf_s(stmt, sizeof stmt, "select first 1 (date_add( %d, interval(%d) month to month))"
                           "  from systables ", startDate, *IntervalPart+1);
            printf("stmt[%s]\n", stmt);
            $PREPARE prep2 FROM $stmt;
            $EXECUTE prep2 INTO $startDate;
            $FREE prep2;
            for(;;)
            {
                if( startDate > endDate) break;
                $select first 1 (date_add( $startDate, interval(1) month to month))
                   into $startDate
                   from systables;
                *IntervalPart = *IntervalPart + 1;
            }
            break;
        case 'D':
            *IntervalPart = endDate - startDate;
            break;
    }
    return M_CM_OK;

errexit:
  printf ("GetIntervalPart:SQLCODE:%d ERROR MESSAGE:%s\n", SQLCODE, sqlca.sqlerrm);
  return SQLCODE;
}

