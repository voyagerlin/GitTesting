/*
   Name       : get_cover_vs_premium
   Input      : *v_sIcar_type		���إN��
                v_iIns			�I�إN��
                v_mcoverage1		�O�B1
                v_mcoverage2		�O�B2
                v_mdeduct		
                *v_frate 		�O�v�N��
                *v_ibroker              �g���N��
                *v_fstart       �O�_�w�ҥγq������
                               (Y:�w�ҥ� N:���ҥ� ��L:�ѥ�FUNCTION�ˮ�)
                *v_iofficer     �g��N��
                *v_iroute       �q���N��
                *v_irate_type   �O�v�O 
                *v_iroute_comm  �~�ȱ���
                *v_bzfrom       �O�o�q���N��
                

   Output     : return code 		M_CM_OK ���\
                v_mpremium		�򥻯«O�O
                v_pextra_charge		���[�O�βv ex:0.325
                v_pbusiness		�~�޶O�βv ex:0.1
                v_isame_ins		�P�I�N��
                v_msi_coverage		�P�I��˫O�B
                v_msi_premium		�P�I�O�O
                v_sMsg      		�T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"
$include cmnroute.h;

void end_get_cover_vs_premium( );

long get_cover_vs_premium( char   *v_sIcar_type, 
                           int    v_iIns, 
                           long   v_mcoverage1, 
                           long   v_mcoverage2, 
                           long   v_mdeduct,  
                           char   *v_frate, 
                           char   *v_ibroker, 
                           char   *v_fstart, 
                           char   *v_iofficer,
                           char   *v_iroute, 
                           char   *v_irate_type, 
                           char   *v_iroute_comm, 
                           char   *v_bzfrom,
                           double *v_mpremium, 
                           double *v_pextra_charge,
                           double *v_pbusiness,
                           char   *v_isame_ins, 
                           long   *v_msi_coverage, 
                           long   *v_msi_premium, 
                           int    v_ply_period,
                           char   *v_sMsg)
{
  $int     iIns;
  $long    mcoverage1, mcoverage2, mdeduct, msi_coverage=0, msi_premium=0;
  $char    isame_ins[7], icar_type[3], frate[5], f980401[2], iextra_charge[11], ibroker[11];
  $double  mpremium=0, pextra_charge=0, pextra_charge1, pbusiness;
  long     rc;
  
  /* �t�X�q���ĤG���q */
  char    sFstart[2], sFauth[2], deffect[11];
  $char   sIofficer[11], sIroute[21], sIrate_type[2], sIroute_comm[4], sBzfrom[3];
  $struct cm_route_comm o_stcomm;
  int     o_qrec = 0;

  $WHENEVER SQLERROR GOTO errexit;

  puts("");
  puts("******************************");
  puts("begin get_cover_vs_premium function");
  printf("    v_sIcar_type[%s], v_iIns[%d], v_mcoverage1[%d], v_mcoverage2[%d], v_mdeduct[%d], v_frate[%s], v_ibroker[%s]\n",
               v_sIcar_type, v_iIns, v_mcoverage1, v_mcoverage2, v_mdeduct,  v_frate, v_ibroker);
  
  strcpy(v_sMsg," ");
  printf("v_sMsg[%s]\n", v_sMsg);

  strcpy( icar_type, v_sIcar_type);
  iIns = v_iIns;
  mcoverage1 = v_mcoverage1;
  mcoverage2 = v_mcoverage2;
  mdeduct = v_mdeduct;
  strcpy( frate, v_frate);
  strcpy( ibroker, v_ibroker);
  
  /* �t�X�q���G�ק� */
    /* 1.�O�_�w�ҥγq������ */
    strcpy(sFstart, v_fstart);
    strcpy(sIofficer, v_iofficer);
    strcpy(sIroute, v_iroute);
    strcpy(sIrate_type, v_irate_type);
    strcpy(sIroute_comm, v_iroute_comm);
    strcpy(sBzfrom, v_bzfrom);
    if ((strcmp(sFstart,"Y") != 0) && (strcmp(sFstart,"N") != 0))
    { 
         /* �T�{�O�ҥγq���~�ȱ���α��v */
         rc = cm_get_route_auth("C", sIroute, sIofficer, sFstart, sFauth);
          if( rc != M_CM_OK)
          {
            strcpy(v_sMsg, cm_get_errmsg(rc));
            end_get_cover_vs_premium( v_sMsg);
            return  rc;
          }
    }
  
  
  if (strcmp(sFstart,"Y") == 0)
  {
      strcpy(iextra_charge, sBzfrom);
  }           
  else
  {
  /* �O�v�ۥѤ� */
     rc = get_broker_agent( ibroker, iextra_charge, v_sMsg);
     if( rc != M_CM_OK)
         return rc;
  }

  /* �O�v�ۥѤ� */
  $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
     INTO $f980401
     FROM ca_rate_date
    WHERE icode  = $frate
      AND itable = 'cm_extra_charge';

  if(SQLCODE==SQLNOTFOUND) return M_CA_EXTRA_CHARGE_DRATE;

  printf("f980401[%s]\n", f980401);

  /* �O�v�ۥѤ� */
  if( f980401[0] == '1')
  {
        /*  1090916003-�����@-�I�߫O�N�����T�걵-���[�O�βv �W�[�D�q���N���P�_*/
      rc = get_cm_extra_charge_car( iextra_charge, frate, &pextra_charge1, &pbusiness, v_ply_period, v_iIns, sIroute ,v_sMsg);
      if( rc != M_CM_OK)
          return rc;
      *v_pbusiness = pbusiness;
  }
  else
      *v_pbusiness = 0;

  $SELECT mpremium, pextra_charge/100, isame_ins, msi_coverage, msi_premium
     INTO $mpremium, $pextra_charge, $isame_ins, $msi_coverage, $msi_premium
     FROM cover_vs_premium
    WHERE icar_type = $icar_type
      AND iins_type = $iIns
      AND mcoverage1 = $mcoverage1
      AND mcoverage2 = $mcoverage2
      AND mdeduct = $mdeduct
      AND drate=(SELECT drate
                   FROM ca_rate_date
                  WHERE icode=$frate
                    AND itable='cover_vs_premium');

  if(SQLCODE==SQLNOTFOUND)
  {
      sprintf_s( v_sMsg, 250,"iIns[%d], v_sIcar_type[%s], mcoverage1[%d], mcoverage2[%d], v_mdeduct[%d], v_frate[%s] "
                       "not in cover_vs_premium\n", iIns, v_sIcar_type, mcoverage1, mcoverage2, v_mdeduct, v_frate);

      end_get_cover_vs_premium( v_sMsg);
      return M_CA_NCOVER_PREM;
  }
  printf("mpremium[%f], \n", mpremium);
  printf("pextra_charge1[%f], pextra_charge[%f], \n", pextra_charge1, pextra_charge); 
  printf("isame_ins[%s], \n", isame_ins);
  printf("msi_coverage[%d], \n", msi_coverage);
  printf("msi_premium[%d]\n", msi_premium);

  *v_mpremium = mpremium; 

  if( f980401[0] == '1')
      *v_pextra_charge = pextra_charge1; 
  else
      *v_pextra_charge = pextra_charge; 

  strcpy( v_isame_ins, isame_ins);
  *v_msi_coverage = msi_coverage;
  *v_msi_premium = msi_premium;

  sprintf_s(v_sMsg,250,"Found mpremium[%f], pextra_charge[%f], pbusiness[%f], isame_ins[%s], msi_coverage[%d], msi_premium[%d]\n",
                       *v_mpremium, *v_pextra_charge, *v_pbusiness, *v_isame_ins, *v_msi_coverage, *v_msi_premium);

  end_get_cover_vs_premium( v_sMsg);

  return M_CM_OK;

errexit:

  sprintf_s( v_sMsg, 250,"SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  end_get_cover_vs_premium( v_sMsg);
  return SQLCODE;
}

void end_get_cover_vs_premium( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_cover_vs_premium function");
  puts("******************************");
  puts("");
}
