/* INSERT data INTO TABLE �պ� ca_est_bound, �̷s ca_ply_bound, ��l ca_ori_bound,
            ��� ca_edr_bound, ���` abn_ca_ply_bound, abn_ca_edr_bound,
            �ƥ� ca_ply_bound_bak

   Name       : insert_ca_ply_bound
   Input      : v_sDbname	        ��Ʈw�W��
                v_sTable  	        Table Name
                v_sColumn               Column Name
                v_sData			�պ⸹�A�O�渹�A���`���A�Χ�渹�X
                v_ibound                ���O���� ex: A01,A02,A03
                
   Output     : M_CM_OK     ���\
                v_sMsg      �T��
*/

#include "api_xsrv.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"
#define MsgLen 512

void end_insert_ca_ply_bound( );

long insert_ca_ply_bound( char *v_sDbname,
                          char *v_sTable,
                          char *v_sColumn,
                          char *v_sData,
                          char *v_ibound,
                          char *v_sMsg)
{
  $char   ibound[4];                /* ���O���� */ 

  $char   stmt[2048];
  char    sdb[61];
  int     iInsertCount=0, sInputlen=0, i=0, j=0, k=0;
  strcpy(v_sMsg," ");
   
  $WHENEVER SQLERROR GOTO errexit;

  iInsertCount = 0;
  puts("");
  puts("******************************");
  puts("begin insert_ca_ply_bound function");
  printf("     v_sDbname=[%s], v_sTable=[%s], v_sColumn[%s], v_sData[%s] ,v_ibound[%s]\n",
               v_sDbname, v_sTable, v_sColumn, v_sData, v_ibound);
  
  if( *v_sDbname == '')
      strcpy( sdb, v_sTable);
  else
      sprintf_s(sdb, sizeof sdb, "%s:%s", v_sDbname, v_sTable);

  sprintf_s(stmt, sizeof stmt, "INSERT INTO %s ( %s, ibound) "
                 "       VALUES ('%s', ? )" , sdb, v_sColumn, v_sData );
  printf( "     stmt[%s]\n", stmt);

  $PREPARE prep_bound FROM $stmt;

  sInputlen = strlen(v_ibound);
  j = 0;
  k = 0;
  for(i=0;i<sInputlen;i++)
  {
     if (v_ibound[i] == ',')
     {
         if (i == 0) break;
         strncpy(ibound,v_ibound+k,j);
         ibound[j] = '\0';
         k = i + 1;
         j = 0;
         $EXECUTE prep_bound USING $ibound;
         iInsertCount ++;
     }
     else
         j++;
  }
  $FREE prep_bound;

  sprintf_s(v_sMsg, MsgLen, "�s�W[%d]��\n", iInsertCount);
  end_insert_ca_ply_bound( v_sMsg);
  
  return M_CM_OK;

errexit:

  sprintf_s(v_sMsg, MsgLen, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  end_insert_ca_ply_bound( v_sMsg);
  return SQLCODE;
}

void end_insert_ca_ply_bound( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end insert_ca_ply_bound function");
  puts("******************************");
  puts("");
}
