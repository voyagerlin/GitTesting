/*
   Name       : get_pre_type_pol

   Input      : v_ipre_num      �պ⸹/�O�渹/��渹 
                v_fEstPlyEdr    0:�պ� 1�G�O��  2�G���
                v_fcard_class   1:�j�� 2:���N (��"0:�պ�"�ɻݭn,��l�i�Ǫť�)

   return code: M_CM_OK         ���\
                v_paydate       ú�ڴ��� 
                v_ftype_pol     �O�����O 
                v_ftype_sp      �O�����O�Ӷ� 
                v_sMsg          �T��

   �u�����ǡG���|�F���� (�O�T=�ۦ樮>�ۼ�>��O��) > �ĳq�� (�O�g�N>�j���I>���q����)  > ���O�X���

*/

#include "commsgs.h"
#include "carmsgs.h"
#include "var_length.h"
#include "ISvar.h"
#include "safeclib.h"
#define MsgLen 512

void end_get_pre_type_pol( );

long get_pre_type_pol(char   *v_ipre_num,
                      int     v_isource,
                      char   *v_fcard_class,
                      char   *v_paydate,
                      char   *v_ftype_pol,
                      char   *v_ftype_sp,
                      char   *v_sMsg)
{
    long     rtncode=0;
    $char    iassured[IASSURED], ipre_num[IPOLICY], iroute[21], ipolicy[IPOLICY], paydate[DATE], ftype_pol[3], ftype_sp[3];
    $char    itag[CA_TAG_NUM], iengine[CA_ENGINE_NUM], fcard_class[2],ilast_ply[IPOLICY],tmp_fcard_class[2];
    $char    dply_begin1[DATE],dply_begin2[DATE],tmp_dply_begin[DATE],iofficer1[IOFFICER],iofficer2[IOFFICER];
    $int     iCount=0,iCountEW=0,iCountEB=0,iCountSP=0,fCarFlag1=0,fCarFlag2=0,tmp_fCarFlag=0,fTransferCar=0,fPayWithCheck=0,iCountTV=0,iCountES=0;
    $date    d_tmp_dply_begin;
    short    tmp_mdy[3];
    $char    icard[21]=" ",ileader[11]=" ";
    
	strcpy(v_sMsg," "); 
	
    $WHENEVER SQLERROR GOTO errexit;

    puts("");
    puts("******************************");
    puts("begin get_pre_type_pol function");
    /*printf("    v_ipre_num[%s] \n", v_ipre_num);*/
    
    /* fCarFlag1�G�j��s�¨�(1:�s��;2:�¨�) ; fCarFlag2�G���N�s�¨�(1:�s��;2:�¨�) */
    fCarFlag1 = 0;
    fCarFlag2 = 0;
    fTransferCar = 0;
    fPayWithCheck = 0;
    iCountEW = iCountEB = iCountTV = iCountES = 0;
    strcpy(ipre_num,trim(v_ipre_num));
    
    switch(v_isource)
    {
        case 0: /* �պ�  */
        
             if (v_ipre_num[6] != 'X')
             {		                         	
	         $SELECT iassured, iroute, ' ', nvl(itag,' '), nvl(iengine,' '), ' ', nvl(ilast_ply,' '), dply1_begin, dply2_begin, iofficer1, iofficer2,
			 case when ((year(dply1_begin)*12+month(dply1_begin))-(year(dissue)*12+month(dissue))) <=1 THEN 1 ELSE 2 END ,
			 case when ((year(dply2_begin)*12+month(dply2_begin))-(year(dissue)*12+month(dissue))) <=1 THEN 1 ELSE 2 END ,
			 case when nequipment[2] in ('1','3','5','7','9','B','D','F','H','J','L','N','P','R','T','V','X','Z','b','d','f','h','j','l','n','p','r','t','v','x','z','.') THEN 1 ELSE 0 END ,
			 case when nequipment[7] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.') THEN 1 ELSE 0 END
		    INTO $iassured, $iroute, $ipolicy, $itag, $iengine, $fcard_class, $ilast_ply, $dply_begin1, $dply_begin2, $iofficer1, $iofficer2, $fCarFlag1, $fCarFlag2,$fTransferCar,$fPayWithCheck
		    FROM estimate
		   WHERE iestimate = $ipre_num;
				      
		 $SELECT count(*) INTO $iCountEW
		    FROM est_ins_type
		   WHERE iestimate = $ipre_num
		     AND iins_type = '58'; 
				        
		 if (iCountEW==0)
		 {
		     $SELECT count(*) INTO $iCountEB
			FROM est_ins_type
		       WHERE iestimate = $ipre_num
			 and iins_type in ('101','102','103','104');
			 
		     if (iCountEB==0)
		     {
		         $SELECT count(*) INTO $iCountTV
			    FROM est_ins_type
			   WHERE iestimate = $ipre_num
			     and iins_type in ('145','146','148');
			     
			 if (iCountTV==0)
			 {
		             $SELECT count(*) INTO $iCountES
			        FROM est_ins_type
			       WHERE iestimate = $ipre_num
			         and iins_type in ('173','174','175');	
			 	
			 }
		     }	
		 } 
			        
             }
             else
             {
             	
		$SELECT iassured, iroute, ' ', nvl(itag,' '), nvl(iengine,' '), ' ', nvl(ilast_ply,' '), dcomp_begin, dbegin, iofficer1, iofficer2,
			case when ((year(dcomp_begin)*12+month(dcomp_begin))-(year(dissue)*12+month(dissue))) <=1 THEN 1 ELSE 2 END ,
			case when ((year(dbegin)*12+month(dbegin))-(year(dissue)*12+month(dissue))) <=1 THEN 1 ELSE 2 END ,
			case when nequipment[2] in ('1','3','5','7','9','B','D','F','H','J','L','N','P','R','T','V','X','Z','b','d','f','h','j','l','n','p','r','t','v','x','z','.') THEN 1 ELSE 0 END ,
			case when nequipment[7] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.') THEN 1 ELSE 0 END
		   INTO $iassured, $iroute, $ipolicy, $itag, $iengine, $fcard_class, $ilast_ply, $dply_begin1, $dply_begin2, $iofficer1, $iofficer2, $fCarFlag1, $fCarFlag2,$fTransferCar,$fPayWithCheck
		   FROM newa00:abnormal_ply
		  WHERE iabnormal = $ipre_num;
			        
		$SELECT count(*) INTO $iCountEW
		   FROM newa00:abn_ply_ins_type
		  WHERE iabnormal = $ipre_num
		    AND iins_type = '58'; 
				        
		if (iCountEW==0)
		{
		    $SELECT count(*) INTO $iCountEB
		       FROM newa00:abn_ply_ins_type
		      WHERE iabnormal = $ipre_num
			and iins_type in ('101','102','103','104');
		    
		    if (iCountEB==0)
		    {
		        $SELECT count(*) INTO $iCountTV
			   FROM newa00:abn_ply_ins_type
			  WHERE iabnormal = $ipre_num
			    and iins_type in ('145','146','148');
			
			if (iCountTV==0)
			{
		             $SELECT count(*) INTO $iCountES
			        FROM newa00:abn_ply_ins_type
			       WHERE iabnormal = $ipre_num
			         and iins_type in ('173','174','175');
				
			}
		    }						  	
		} 
	     }
	     
	     if (SQLCODE==SQLNOTFOUND)
	     {    	 
	         return M_CA_NESTIMATE; /* 4088:�֫O��Ƥ��s�b*/
	     }
	     strcpy(fcard_class, v_fcard_class);
             break;
             
        case 1: /* �O�� */
        
	     $SELECT b.iassured,b.iroute,a.ipolicy,nvl(b.itag,' '),nvl(b.iengine,' '),a.fcard_class,nvl(a.ilast_ply,' '), a.icard, a.ileader,
		     case when a.fcard_class = '1' then to_char(a.dply_begin) else ' ' end,
		     case when a.fcard_class = '2' then to_char(a.dply_begin) else ' ' end,
		     case when a.fcard_class = '1' then to_char(a.iofficer)   else ' ' end,
		     case when a.fcard_class = '2' then to_char(a.iofficer)   else ' ' end,			         	
		     case when a.fcard_class = '1' then 
                     case when ((year(a.dply_begin)*12+month(a.dply_begin))-(year(b.dissue)*12+month(b.dissue))) <=1 THEN 1 ELSE 2 END
		     else 0 end,
		     case when a.fcard_class = '2' then 
			  case when ((year(a.dply_begin)*12+month(a.dply_begin))-(year(b.dissue)*12+month(b.dissue))) <=1 THEN 1 ELSE 2 END
		     else 0 end,			         
		     case when b.nequipment[2] in ('1','3','5','7','9','B','D','F','H','J','L','N','P','R','T','V','X','Z','b','d','f','h','j','l','n','p','r','t','v','x','z','.') THEN 1 ELSE 0 END ,
		     case when b.nequipment[7] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.') THEN 1 ELSE 0 END
                INTO $iassured, $iroute, $ipolicy, $itag, $iengine, $fcard_class, $ilast_ply, $icard, $ileader, $dply_begin1, $dply_begin2, $iofficer1, $iofficer2, $fCarFlag1, $fCarFlag2 ,$fTransferCar,$fPayWithCheck
		FROM ply_relation a, policy b
	       WHERE a.ipolicy = b.ipolicy 
		 AND a.ipolicy = $ipre_num;
		 
	     if (SQLCODE==SQLNOTFOUND)
	     {    	 
	         return M_CA_NESTIMATE; /* 4088:�֫O��Ƥ��s�b*/
	     }	     
             break;
             
        case 2: /* ��� */		
           
             break;
    }   
    
    strcpy( dply_begin1, trim(dply_begin1));    
    strcpy( dply_begin2, trim(dply_begin2));         
    
    strcpy( ftype_pol, " ");   /* �w�]���ť� = ���O�X��� */
    strcpy( ftype_sp , " ");
 
   
    iCount = 0;
    if( strstr( ipolicy, "VW") || (iCountEW > 0) ) 
    { 
        strcpy( ftype_pol, "NA");
        strcpy( ftype_sp , "EW");
        iCount = 1;
    }
    else if( strstr( ipolicy, "EB") || (iCountEB > 0) ) 
    {
        strcpy( ftype_pol, "NA");
        strcpy( ftype_sp , "EB");
        iCount = 1;
    }
    else if( strstr( ipolicy, "TV") || (iCountTV > 0) ) 
    {
        strcpy( ftype_pol, "NA");
        strcpy( ftype_sp , "TV");
        iCount = 1;
    }
    else if( strstr( ipolicy, "ES") || (iCountES > 0) ) 
    {
        strcpy( ftype_pol, "NA");
        strcpy( ftype_sp , "ES");
        iCount = 1;
    }
    else if( strncmp( iroute, "JC", 2) == 0 )
    {  
    	/* 104.04.01 �պⶥ�q���P�_JC�� */ 
        if (v_isource != 0 )
        {
        	 
	    $SELECT count(*) INTO $iCount
	       FROM car_code
	      WHERE kind = '26' AND detail = $iassured;
	    if (iCount > 0)
	    {	
	        strcpy( ftype_pol, "NA");
	        strcpy( ftype_sp , "JC");
	    }
        }
    }
    
    if (iCount==0)
    {
       /* 103.12.26:���w�q "NA-RN" (�L�����) 
          1.103�~�ͮġA104�~2�멳�e�����X��(�L��)(�L��e�A�H"�t�Τ�"���@ñ���P�_)
          2.104�~1,2����ͮĥB1,2���ñ�椧�¨��C(�L��e�A�H"�t�Τ�"���@ñ���P�_)
             �s���W�h��: (�ͮĦ~��-�o�Ӧ~��)�ݤp�󵥩�@�Ӥ�B�L���O[02�L�ᨮ]�l���t�λ{�w���s��  
            
            if �䲼ú�� 
               =>RN
            OR 
	           if �t�Τ� < 03/01/2015  
		       	   if �ͮĤ� < 03/01/2015
		       	       if �ͮĦ~ = 2015  
		       	          if �¨� �� �L�ᨮ 
		       	              =>RN
		       	        else
		       	           =>RN

       */ 
       /* �P�_�O�_��104�~1�B2����O��(�t�Τ鶷 < 03/01/2015) */       
       
       iCount = 0;
       if (v_isource == 0 || v_isource == 1) 
       {
       	   
       }
       
       printf("-- trace �L����� iCount[%d]\n ",iCount);
       if (iCount > 0)
       {	
           strcpy( ftype_pol, "NA");
           strcpy( ftype_sp , "RN");           
       }       
       else
       {    
       	   /* �P�_�S�w�q��(�X�涥�q) */
	   /* �P�_�ĳq�ʽ��u�����ǡG�Y���O�g�N��h���A�ΫO�g�Nftype_sp=20�A�D�O�g�N��A�A�αj���Ifcard_class=1�A�̫�A�Τ��q����ftype_sp=10 */	        
	   iCount = 0;        
	   if (v_isource != 0 && iofficer2[0] !='W') /* �պⶥ�q���P�_�ĳq��B�O�g�N�ĥ�q�ư��M�ץ�W�g�� */
	   {		        	
	       $select count(*) into $iCount
		  from ca_permit 	           
		 where (dexpire is null or dexpire > today) and 
		        ((iclass = '01' and icode = $iassured ) or
		         (iclass = '02' and icode = $itag ) or
		         (iclass = '03' and icode = $iengine ) or
		         (iclass = '04' and $iroute like trim(icode)||'%') or
		         (iclass = '05' and $iroute like trim(icode)||'%'))
		   and ftype_sp = '20';

	       /* 1040507002_C1: �����~�������i�A�ΫO�g�N�󤧳B�z�覡*/
	       if( iCount > 0)
	       {
	           iCount = 0; 
		   if( fcard_class[0] == '1')
		   { 
		       $select count(*) into $iCount from officer
			 where iofficer = $iofficer1 and irate_type = 'C';
		   }
		   else
		   {
		       $select count(*) into $iCount from officer
			 where iofficer = $iofficer2 and irate_type = 'C';		        	
		   }
			        
		   if (iCount > 0 )
		   {
			        	
		       /* 1040618003_C1�S�w�q���ҥ~�޲z */
		       iCountSP = 0;
		       $select count(*) into $iCountSP from car_code
			 where kind = 'SP' and detail = '1'
			   and detail2 = $iroute and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);
		       
		       if (iCountSP == 0)
		       {
		           if( fcard_class[0] == '1')
		           {
			       $select count(*) into $iCountSP from car_code
				 where kind = 'SP' and detail = '2'
				   and detail2 = $iofficer1 and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);
			   }
			   else
			   {
			       $select count(*) into $iCountSP from car_code
				 where kind = 'SP' and detail = '2'
				   and detail2 = $iofficer2 and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);
			   }        	
		       }					    
		       if (iCountSP>0)
		       { 
		       	   /* ���ŦX���~�q���A���i�� SP-20 */
		           iCount = 0;
		       } 
		   }
	       }		            
	   }
	        
	   /* �S�w�q�� */
	   if( iCount > 0)
	   {   
	       strcpy( ftype_pol, "SP");
	       strcpy( ftype_sp , "20");
	   }
	   else  /* �պⶥ�q �άO �D�S�w�q��(�X�涥�q) */
	   {	        	
	       if( fcard_class[0] == '1')
	       {   
	           if  (v_isource ==0)
	           {   
	           	/* �պ� */
		       strcpy( ftype_pol, " " );
		       strcpy( ftype_sp , "PA");	            		
	           }
	           else /* �X�� */
	           {
		       strcpy( ftype_pol, "SP");
		       strcpy( ftype_sp , "01");
		            		                    
                       strcpy(icard,trim(icard));
                       if (strcmp(icard,ipre_num)==0) /* �D�~��d */
                       { 
                    	   /*�u�D�S�w�q���v�j���I[���O�X��]�޲z�H�M�� */
                    	   /* 1:�޲z�H�N�� 2�G�D�q���N��  3�G�g��N�� */
		           iCountSP = 0;
			   $select count(*) into $iCountSP from car_code
			     where kind = 'SQ' and detail = '1'
			       and detail2 = $ileader and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);
			   
			   if (iCountSP == 0)
			   {
	                       $select count(*) into $iCountSP from car_code
				 where kind = 'SQ' and detail = '2'
				   and $iroute like trim(detail2)||'%' and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);
			       
			       if (iCountSP == 0)
			       {
			           if( fcard_class[0] == '1')
			           {
				       $select count(*) into $iCountSP from car_code
					 where kind = 'SQ' and detail = '3'
					   and detail2 = $iofficer1 and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);
				   }
				   else
				   {
				       $select count(*) into $iCountSP from car_code
					 where kind = 'SQ' and detail = '3'
					   and detail2 = $iofficer2 and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);
				   }
			       }
			   }

			   if (iCountSP > 0)
			   {
			       strcpy( ftype_pol, " ");
			       strcpy( ftype_sp , "PA");
			   }
                       }
                   }
	       }
	       else
	       {
		   iCount = 0;		        
		   if (v_isource != 0) /* �պⶥ�q���P�_�ĳq�� */            	
		   {	
		       $select count(*) into $iCount	                   
		          from ca_permit 
		         where (dexpire is null or dexpire > today) and 
		               ((iclass = '01' and icode = $iassured ) or
		                (iclass = '02' and icode = $itag ) or
		                (iclass = '03' and icode = $iengine ) or
		                (iclass = '04' and $iroute like trim(icode)||'%') or
		                (iclass = '05' and $iroute like trim(icode)||'%'))
		           and ftype_sp = '10';		
	           }
	           if( iCount > 0)
	           {   
	               strcpy( ftype_pol, "SP");
	               strcpy( ftype_sp , "10");		                    
	           }
	           else
	           {
	               /* ���O�X��� */  
		       strcpy( ftype_sp , "PA");
	           }	                
	       }
	   }
       }
    }
    
    
    /* ú�ڴ��� */	    
    if ( ( ftype_pol[0]==' ') && (strncmp(ftype_sp,"PA",2) == 0) )
    {
        if( fcard_class[0] == '1')
	{
	    strcpy(paydate, dply_begin1);
	}
	else
	{
	    strcpy(paydate, dply_begin2);
	}
		
    }
    else
    {
        strcpy(paydate," ");
    }
    
    sprintf_s(v_sMsg, MsgLen, " paydate[%s], ftype_pol[%s], ftype_sp[%s]\n ", paydate, ftype_pol, ftype_sp);    
    
    strcpy( v_paydate  , paydate);
    strcpy( v_ftype_pol, ftype_pol);
    strcpy( v_ftype_sp , ftype_sp);
            
    end_get_pre_type_pol( v_sMsg);

    return M_CM_OK;

errexit:

  sprintf_s(v_sMsg, MsgLen, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  end_get_pre_type_pol( v_sMsg);
  return SQLCODE;

}

void end_get_pre_type_pol( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_pre_type_pol function");
  puts("******************************");
  puts("");
}
