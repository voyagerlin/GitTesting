/* purpose    : �^�ǶǤJ���I�ةM�O�B�N������������
   Name       : move_ply_ins_cover_curr2
   Input      : v_IfirstPlyInsCover    		
                v_iIns 			�I�إN�� ex:34
                v_sIcover_type		�O�B�N��
                
   Output     : IcurrPlyInsCover 
*/

#include "commsgs.h"
#include "carmsgs.h"
$include "ply_ins_cover.h";
$include "var_length.h";
#include "safeclib.h"
/* void end_move_ply_ins_cover_curr2( ); */

struct PLY_INS_COVER *move_ply_ins_cover_curr2( v_IfirstPlyInsCover, v_iIns, v_sIcover_type)
$int     *v_iIns;
struct   PLY_INS_COVER *v_IfirstPlyInsCover;
$char    *v_sIcover_type;
{
struct   PLY_INS_COVER *IcurrPlyInsCover;

  puts("");
  puts("******************************");
  puts("begin move_ply_ins_cover_curr2 function");
  printf("     v_iIns=[%d], v_sIcover_type=[%s]\n", *v_iIns, v_sIcover_type);
  
  IcurrPlyInsCover = v_IfirstPlyInsCover;

  while( IcurrPlyInsCover)
  {
      puts("");

      if( *v_iIns == atoi( IcurrPlyInsCover->iins_type) &&
          strncmp( IcurrPlyInsCover->icover_type, v_sIcover_type, 3 ) == 0)
          break;

      IcurrPlyInsCover = IcurrPlyInsCover->next;
  }

  printf("     after move to v_iIns=[%d], v_sIcover_type=[%s]\n"
         "     IcurrPlyInsCover->iins_type    [%s]\n"
         "     IcurrPlyInsCover->cover_name   [%s]\n"
         "     IcurrPlyInsCover->icover_type  [%s]\n"
         "     IcurrPlyInsCover->mcover       [%d]\n"
         "     IcurrPlyInsCover->mcover_prem  [%d]\n"
         "     IcurrPlyInsCover->mprem        [%d]\n"
         "     IcurrPlyInsCover->mpure_prem   [%f]\n"
         "     IcurrPlyInsCover->pextra_charge[%f]\n", *v_iIns, v_sIcover_type,
               IcurrPlyInsCover->iins_type,
               IcurrPlyInsCover->cover_name,
               IcurrPlyInsCover->icover_type,
               IcurrPlyInsCover->mcover,
               IcurrPlyInsCover->mcover_prem,
               IcurrPlyInsCover->mprem,
               IcurrPlyInsCover->mpure_prem,
               IcurrPlyInsCover->pextra_charge );

  /* end_move_ply_ins_cover_curr2( v_sMsg); */

  return IcurrPlyInsCover;

}
/* 
void end_move_ply_ins_cover_curr2( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end move_ply_ins_cover_curr2 function");
  puts("******************************");
  puts("");
}
*/
