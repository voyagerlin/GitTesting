/* SELECT data FROM TABLE ply_ins_cover, abn_ply_ins_type, est_ins_cover, edr_ins_cover, abn_edr_ins_cover
   Name       : get_ply_ins_cover
   Input      : v_sDbname	        ��Ʈw�W��
                v_sTable  	        Table Name	
                v_sColumn               Column Name
                v_sData			�պ⸹�A�O�渹�A���`���A�Χ�渹�X
                
   Output     : IfirstPlyInsCover
                M_CM_OK     ���\
                v_sMsg      �T��
*/

#include "api_xsrv.h"
#include "commsgs.h"
#include "carmsgs.h"
$include "ply_ins_cover.h";
$include "var_length.h";
#include "safeclib.h"
void end_get_ply_ins_cover( );

struct   PLY_INS_COVER *get_ply_ins_cover( v_sDbname, v_sTable, v_sColumn, v_sData, v_rtncode, v_sMsg)
$char    *v_sDbname, *v_sTable, *v_sColumn, *v_sData, *v_sMsg;
long     *v_rtncode;
{
  struct   PLY_INS_COVER *IfirstPlyInsCover, *IcurrPlyInsCover, *IlastPlyInsCover;
  $char   iins_type[IINS_TYPE];			/* �I�إN�� */
  $char   cover_name[COVER_NAME];		/* �O�B���� */
  $char   print_name[COVER_NAME];		/* �O�B�C�L�W�� */ 
  $char   icover_type[ICOVER_TYPE];		/* �O�B���� */
  $char   iprem_cover_type[ICOVER_TYPE];	/* ��m�O�O���O�B���� */
  $long   mcover = 0;				/* �O�B */
  $long   mcover_prem = 0;				/* ���� */
  $long   mdiscount = 0;				/* ñ��O�O */
  $long   mprem = 0;				/* �W���O�O */
  $double mpure_prem = 0;				/* �«O�O */
  $double pextra_charge;			/* ���[�O�βv */
  $char   stmt[2048], sDbname[61],tmp_sMsg[512];

  $WHENEVER SQLERROR GOTO errexit;

  puts("");
  puts("******************************");
  puts("begin get_ply_ins_cover function");
  printf("     v_sDbname=[%s], v_sTable=[%s], v_sColumn[%s], v_sData[%s]\n", v_sDbname, v_sTable, v_sColumn, v_sData);
  strcpy(v_sMsg," ");
  strcpy( tmp_sMsg, " ");
  
  if( strlen(v_sDbname) != 0)
      sprintf_s( sDbname,sizeof sDbname, "%s:%s", v_sDbname, v_sTable);
  else						/* �����wDB�N��localdb */
      sprintf_s( sDbname,sizeof sDbname, v_sTable);

  sprintf_s( stmt,sizeof stmt, "SELECT a.iins_type, cover_name, print_name, a.icover_type, a.mcover, "
                 "       a.mcover_prem, a.mdiscount, a.mprem, a.mpure_prem, b.iprem_cover_type "
                 "  FROM %s a, insurance_cover b"
                 " WHERE a.iins_type = b.iins_type"
                 "   AND a.icover_type = b.icover_type"
                 "   AND %s = '%s'"
                 " ORDER BY a.iins_type, a.icover_type", sDbname, v_sColumn, v_sData );
  printf( "     stmt[%s]\n", stmt);

  IcurrPlyInsCover=IfirstPlyInsCover=IlastPlyInsCover=NULL;    /* set init pointer to NULL */

  $PREPARE prep_cover FROM $stmt;
  $DECLARE cur_cover CURSOR FOR prep_cover;
  $OPEN cur_cover;
  for(;;)
  {
      $FETCH cur_cover  INTO $iins_type, $cover_name, $print_name, $icover_type, $mcover, 
                             $mcover_prem, $mdiscount, $mprem, $mpure_prem, $iprem_cover_type;
      if( SQLCODE == SQLNOTFOUND)
          break;

      IcurrPlyInsCover=(struct PLY_INS_COVER *)malloc(sizeof(struct PLY_INS_COVER));
      
      if(IcurrPlyInsCover==NULL) free(IcurrPlyInsCover);  /* �t�X���X���y�B�z */
      
      
      if ( IfirstPlyInsCover==NULL)
      {
           IfirstPlyInsCover = IcurrPlyInsCover;
      }
      else
      {
          IlastPlyInsCover->next = IcurrPlyInsCover;
      }
      IlastPlyInsCover = IcurrPlyInsCover;
      IcurrPlyInsCover->next = NULL;

      strcpy( IcurrPlyInsCover->iins_type, iins_type);
      strcpy( IcurrPlyInsCover->cover_name, cover_name);
      strcpy( IcurrPlyInsCover->print_name, print_name);
      strcpy( IcurrPlyInsCover->icover_type, icover_type);
      strcpy( IcurrPlyInsCover->iprem_cover_type, iprem_cover_type);
      IcurrPlyInsCover->mcover        = mcover;
      IcurrPlyInsCover->mcover_prem   = mcover_prem;
      IcurrPlyInsCover->mdiscount     = mdiscount;
      IcurrPlyInsCover->mprem         = mprem;
      IcurrPlyInsCover->mpure_prem    = mpure_prem;
      IcurrPlyInsCover->pextra_charge = 0;

      printf("    IcurrPlyInsCover->iins_type    [%s]\n"
             "    IcurrPlyInsCover->cover_name   [%s]\n"
             "    IcurrPlyInsCover->print_name   [%s]\n"
             "    IcurrPlyInsCover->icover_type  [%s]\n"
             "    IcurrPlyInsCover->iprem_cover_type  [%s]\n"
             "    IcurrPlyInsCover->mcover       [%d]\n"
             "    IcurrPlyInsCover->mcover_prem  [%d]\n"
             "    IcurrPlyInsCover->mdiscount    [%d]\n"
             "    IcurrPlyInsCover->mprem        [%d]\n"
             "    IcurrPlyInsCover->mpure_prem   [%f]\n",
                  IcurrPlyInsCover->iins_type,
                  IcurrPlyInsCover->cover_name,
                  IcurrPlyInsCover->print_name,
                  IcurrPlyInsCover->icover_type,
                  IcurrPlyInsCover->iprem_cover_type,
                  IcurrPlyInsCover->mcover,
                  IcurrPlyInsCover->mcover_prem,
                  IcurrPlyInsCover->mdiscount,
                  IcurrPlyInsCover->mprem,
                  IcurrPlyInsCover->mpure_prem);
      puts("");
	  
  }
  end_get_ply_ins_cover( v_sMsg);
  
  *v_rtncode = M_CM_OK;

  return IfirstPlyInsCover;

errexit:

  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy( v_sMsg, tmp_sMsg);
  end_get_ply_ins_cover( v_sMsg);
  *v_rtncode = SQLCODE;
  return IfirstPlyInsCover;
}

void end_get_ply_ins_cover( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_ply_ins_cover function");
  puts("******************************");
  puts("");
}
