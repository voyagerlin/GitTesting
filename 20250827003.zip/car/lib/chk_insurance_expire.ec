/*
   Name       : chk_insurance_expire
   Input      : v_sIins_type ex:55
   return code: M_CM_OK ���\
   Output     : v_sMsg      �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"
void end_chk_insurance_expire( );

long chk_insurance_expire( v_sIins_type, v_sMsg)
$char    *v_sIins_type, *v_sMsg;
{
  $int  fexpire = 0, iCount = 0;
  $long rtncode;
  char   taipei_db[40];
  $char  dbname_tp[40], stmt[512],tmp_sMsg[512];

  $WHENEVER SQLERROR GOTO errexit;

  puts("");
  puts("***********************************");
  puts("begin chk_insurance_expire function");
  printf("     v_sIins_type=[%s]\n", v_sIins_type);
  strcpy( tmp_sMsg, " ");
  
  $SELECT CASE WHEN dexpire IS NULL OR dexpire > TODAY THEN 0 ELSE 1 END CASE
     INTO $fexpire
     FROM insurance_type
    WHERE iins_type=$v_sIins_type;

  if(SQLCODE==SQLNOTFOUND)
  {
      sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "v_sIins_type[%s] not in table:insurance_type\n", v_sIins_type);
	  strcpy( v_sMsg, tmp_sMsg);
      end_chk_insurance_expire( v_sMsg);
      return M_CA_NINS_TYPE;
  }

  if( fexpire == 1)
  {
      sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "v_sIins_type[%s]�I�ؤw���ΡA�Ь��ӫO�� \n", v_sIins_type);
	  strcpy( v_sMsg, tmp_sMsg);
      end_chk_insurance_expire( v_sMsg);
      return M_CA_INS_EXPIRE;
  }

  rtncode = getHeadBranch(taipei_db);
  if (rtncode < 0)
  {
      sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "getHeadBranch Fail:read Config file error!!\n");
	  strcpy( v_sMsg, tmp_sMsg);
      end_chk_insurance_expire( v_sMsg);
      return M_CM_READ_CONFIG_ERR;
  }

  /* get TAIPEI's full DB name for abnormal policy */
  strcpy(dbname_tp,get_full_dbname(taipei_db));

  sprintf_s( stmt,sizeof stmt, "SELECT COUNT(*) "
                 "  FROM %s:v_group_instype "
                 " WHERE icode= '%s' ", dbname_tp, v_sIins_type);
  printf("stmt[%s]\n", stmt);
  $PREPARE prepA FROM $stmt;
  $EXECUTE prepA INTO $iCount;

  if( iCount ==0 )
  {
      sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "v_sIins_type[%s] not in view:v_group_instype\n", v_sIins_type);
	  strcpy( v_sMsg, tmp_sMsg);
      end_chk_insurance_expire( v_sMsg);
      return M_CA_NO_BIS;
  }

  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "found v_sIins_type and not expire [%s]\n", v_sIins_type);
  strcpy( v_sMsg, tmp_sMsg);
  end_chk_insurance_expire( v_sMsg);
  return M_CM_OK;

errexit:
  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]); 
  strcpy( v_sMsg, tmp_sMsg);
  end_chk_insurance_expire( v_sMsg);
  return SQLCODE;
}

void end_chk_insurance_expire( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end chk_insurance_expire function");
  puts("*********************************");
  puts("");
}

