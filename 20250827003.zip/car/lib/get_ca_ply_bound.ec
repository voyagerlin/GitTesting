/* SELECT data FROM TABLE �պ� ca_est_bound, �̷s ca_ply_bound, ��l ca_ori_bound,
                          ��� ca_edr_bound, ���` abn_ca_ply_bound, abn_ca_edr_bound,
                          �ƥ� ca_ply_bound_bak
   Name       : get_ca_ply_bound
   Input      : v_sDbname	        ��Ʈw�W��
                v_sTable  	        Table Name	
                v_sColumn               Column Name
                v_sData			�պ⸹�A�O�渹�A�O��沧�`���A�Χ�渹�X
                
   Output     : M_CM_OK     ���\
                v_ibound    ���O���� ex: A01,A02,A03
                v_sMsg      �T��
*/

#include "api_xsrv.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"
void end_get_ca_ply_bound( );

long get_ca_ply_bound( char *v_sDbname,
                       char *v_sTable,
                       char *v_sColumn,
                       char *v_sData,
                       char *v_ibound,
                       char *v_sMsg)
{
  $char   ibound[4];	               /* ���O���� */ 
  $char   stmt[2048], sDbname[61],tmp_sMsg[512];

  $WHENEVER SQLERROR GOTO errexit;

  puts("");
  puts("******************************");
  puts("begin get_ca_ply_bound function");
  printf("     v_sDbname=[%s], v_sTable=[%s], v_sColumn[%s], v_sData[%s]\n", v_sDbname, v_sTable, v_sColumn, v_sData);
  strcpy( tmp_sMsg, " ");
  
  if( strlen(v_sDbname) != 0)
      sprintf_s( sDbname,sizeof sDbname, "%s:%s", v_sDbname, v_sTable);
  else						/* �����wDB�N��localdb */
      sprintf_s( sDbname,sizeof sDbname, v_sTable);

  sprintf_s( stmt,sizeof stmt, "SELECT ibound" 
                 "  FROM %s "
                 " WHERE %s = '%s'"
                 " ORDER BY ibound", sDbname, v_sColumn, v_sData );
  printf( "     stmt[%s]\n", stmt);

  $PREPARE prep_bound FROM $stmt;
  $DECLARE cur_bound CURSOR FOR prep_bound;
  $OPEN cur_bound;
  printf("v_ibound      [%s]\n", v_ibound);
  strcpy( v_ibound, "");
  printf("v_ibound      [%s]\n", v_ibound);
  for(;;)
  {
      $FETCH cur_bound  INTO $ibound;
      if( SQLCODE == SQLNOTFOUND)
          break;

      strcat( v_ibound, ibound);
      strcat( v_ibound, ",");
  }
  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "v_ibound      [%s]\n", v_ibound);
  strcpy( v_sMsg, tmp_sMsg);
  end_get_ca_ply_bound( v_sMsg);
  
  puts("");

  return M_CM_OK;

errexit:

  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy( v_sMsg, tmp_sMsg);
  end_get_ca_ply_bound( v_sMsg);
  return SQLCODE;
}

void end_get_ca_ply_bound( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_ca_ply_bound function");
  puts("******************************");
  puts("");
}
