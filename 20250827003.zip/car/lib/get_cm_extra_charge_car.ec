/*
   Name       : get_cm_extra_charge_car
   Purpose    : �̸g���s�թM�O�v�N�����o���[�O�βv�M�~�޶O�βv

   Input      : v_iextra_charge ���[�O�βv�N�� 
                v_drate_ym      �O�v�N�� 
                v_ply_period    �O��O�� ( 103.04.30:1030407005_C1_�ӽзs�ӫ~�W�u-������X�O�I)(�]���s�W�G�~�����[�O�βv)
                v_iIns          �I�إN��
                v_iroute        �q���N��   1090916003-�����@-�I�߫O�N�����T�걵-���[�O�βv �W�[�D�q���N���P�_

   return code: M_CM_OK         ���\
                v_pextra_charge ���[�O�βv 
                v_pbusiness     �~�޶O�βv
                v_sMsg          �T��
                
*/

#include "commsgs.h"
#include "carmsgs.h"
$include "var_length.h";
#include "safeclib.h"
void end_get_cm_extra_charge_car( );

long get_cm_extra_charge_car( char   *v_iextra_charge,
                              char   *v_drate_ym,
                              double *v_pextra_charge,
                              double *v_pbusiness,
                              int    v_ply_period,  
                              int    v_iIns,
                              char   *v_iroute,
                              char   *v_sMsg)
{
  long     rtncode;
  $double  pextra_charge = 0, pbusiness = 0;
  $char    iextra_charge[11], drate_ym[DRATE_YM],iins_type[6],iyear[2],tmp_sMsg[512];
  $char    sIroute[21],sIroute_main[21];/*  1090916003-�����@-�I�߫O�N�����T�걵-���[�O�βv �W�[�D�q���N���P�_*/
  
    $WHENEVER SQLERROR GOTO errexit;

    puts("");
    puts("******************************");
    puts("begin get_cm_extra_charge_car function");
    printf("    v_iextra_charge[%s], v_drate_ym[%s]v_iroute[%s]\n", v_iextra_charge, v_drate_ym,v_iroute);

    
    strcpy( iextra_charge, v_iextra_charge);
    strcpy( drate_ym, v_drate_ym);  
    strcpy( sIroute, v_iroute);  
    strcpy( tmp_sMsg, " ");
	
    $SELECT nvl(iroute_main,' ')
       INTO $sIroute_main
       FROM cm_route
      WHERE iroute = $sIroute;
    if(SQLCODE==SQLNOTFOUND)
    {
        return M_CA_EXTRA_CHARGE;
    }
    else if (trim(sIroute_main)=="")
    {
        return M_CA_EXTRA_CHARGE;
    }
      
    if ((v_ply_period <= 12)||(v_iIns == 58)){  
        strcpy(iyear ,"1"); 
    }else{
        strcpy(iyear ,"2"); /* �ӫO���>12�A�ϥΤG�~�����[�O�βv */    
    }
    
    if (v_iIns<10){
    	sprintf_s(iins_type,sizeof iins_type,"%02d",v_iIns);
    }else{
    	sprintf_s(iins_type,sizeof iins_type, "%d",v_iIns);
    }
    printf("-- trace iins_type[%s]\n ",iins_type);
    $SELECT pextra_charge/100, pbusiness/100
       INTO $pextra_charge, $pbusiness
       FROM cm_extra_charge
      WHERE iins_cat = 'C'
        AND iextra_charge  = $iextra_charge
        AND iins_type  = $iins_type
        AND iyear  = $iyear
        AND iroute = $sIroute_main
        AND drate  = (SELECT drate
                        FROM ca_rate_date
                       WHERE icode  = $drate_ym
                         AND itable = 'cm_extra_charge');

    if(SQLCODE==SQLNOTFOUND)
    {
        printf("-- * + iroute");
	    $SELECT pextra_charge/100, pbusiness/100
	       INTO $pextra_charge, $pbusiness
	       FROM cm_extra_charge
	      WHERE iins_cat = 'C'
	        AND iextra_charge  = $iextra_charge
	        AND iins_type  = '*'
	        AND iyear  = $iyear
            AND iroute = $sIroute_main
	        AND drate  = (SELECT drate
	                        FROM ca_rate_date
	                       WHERE icode  = $drate_ym
	                         AND itable = 'cm_extra_charge');    	
	    if(SQLCODE==SQLNOTFOUND)
	    {
            printf("-- iins_type + *");
            $SELECT pextra_charge/100, pbusiness/100
               INTO $pextra_charge, $pbusiness
               FROM cm_extra_charge
              WHERE iins_cat = 'C'
                AND iextra_charge  = $iextra_charge
                AND iins_type  = $iins_type
                AND iyear  = $iyear
                AND iroute  = '*'
                AND drate  = (SELECT drate
                                FROM ca_rate_date
                               WHERE icode  = $drate_ym
                                 AND itable = 'cm_extra_charge');    	
            if(SQLCODE==SQLNOTFOUND)
            {
                printf("-- * + *");
                $SELECT pextra_charge/100, pbusiness/100
                   INTO $pextra_charge, $pbusiness
                   FROM cm_extra_charge
                  WHERE iins_cat = 'C'
                    AND iextra_charge  = $iextra_charge
                    AND iins_type  = '*'
                    AND iyear  = $iyear
                    AND iroute  = '*'
                    AND drate  = (SELECT drate
                                    FROM ca_rate_date
                                   WHERE icode  = $drate_ym
                                     AND itable = 'cm_extra_charge');    	
                if(SQLCODE==SQLNOTFOUND)
                {
                    sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "    iextra_charge[%s], drate_ym[%s] not in table cm_extra_charge\n", 
                                          iextra_charge, drate_ym);
                    strcpy( v_sMsg, tmp_sMsg);
                    end_get_cm_extra_charge_car( v_sMsg);
                    return M_CA_EXTRA_CHARGE;
                }

            }
	        
	    }    
    }

    sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "    Found pextra_charge[%f], pbusiness[%f] \n", pextra_charge, pbusiness);
    strcpy( v_sMsg, tmp_sMsg);
	
    *v_pextra_charge = pextra_charge;
    *v_pbusiness = pbusiness;

    end_get_cm_extra_charge_car( v_sMsg);

    return M_CM_OK;

errexit:

  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy( v_sMsg, tmp_sMsg);
  end_get_cm_extra_charge_car( v_sMsg);
  return SQLCODE;

}

void end_get_cm_extra_charge_car( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_cm_extra_charge_car function");
  puts("******************************");
  puts("");
}
