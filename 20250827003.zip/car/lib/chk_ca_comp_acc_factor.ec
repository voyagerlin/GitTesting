/*
   Name       : chk_ca_comp_acc_factor
   Input      : v_sFcard_class 		1:�j��,2:���N
                v_sClass 		�ż�
                v_sIcar_type			���إN��			
                v_frate  �O�v�N��
   return code: M_CM_OK ���\
   Output     : v_sMsg      �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
void end_chk_ca_comp_acc_factor( );

long chk_ca_comp_acc_factor( v_sFcard_class, v_sClass, v_sIcar_type, v_frate,v_sMsg)
$char   *v_sFcard_class, *v_sClass, *v_sIcar_type, *v_frate,*v_sMsg;
{
  $char imgr[2], sQuery[512],tmp_sMsg[512];
  $int  iCount;
  $double pcomp_factor;
  $char sFcar_class[2];

  $WHENEVER SQLERROR GOTO errexit;

  puts("");
  puts("***********************************");
  puts("begin chk_ca_comp_acc_factor function");
  printf("     v_sFcard_class=[%s], v_sIcar_type=[%s],v_sClass=[%s]v_frate[%s]\n", v_sFcard_class, v_sIcar_type, v_sClass,v_frate);
  strcpy( tmp_sMsg, " ");
  
	$select fcar_class into $sFcar_class
		 from car_type
		where fclass = '1'
		  and icode = $v_sIcar_type;
		  
  $SELECT pcomp_factor
     INTO $pcomp_factor
     FROM ca_comp_acc_factor
    WHERE fcard_class = $v_sFcard_class 
      AND qclass||' ' = $v_sClass
      and fcar_class = $sFcar_class
      AND drate = (SELECT drate
                      FROM ca_rate_date
                     WHERE icode=$v_frate
                       AND itable='ca_comp_acc_factor');


  if(SQLCODE==SQLNOTFOUND)
  {
      sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "v_sFcard_class=[%s], v_sClass=[%s] not in table: ca_comp_acc_factor\n", 
                                                 v_sFcard_class, v_sClass);
	  strcpy( v_sMsg, tmp_sMsg);
      end_chk_ca_comp_acc_factor( v_sMsg);
      return M_CA_COMP_CLASS_ERR;
  }

  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "v_sFcard_class=[%s], v_sClass=[%s] v_frate=[%s] in table: ca_comp_acc_factor\n", v_sFcard_class, v_sClass,v_frate);
  strcpy( v_sMsg, tmp_sMsg);
  end_chk_ca_comp_acc_factor( v_sMsg);

  return M_CM_OK;

errexit:
  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]); 
  strcpy( v_sMsg, tmp_sMsg);
  end_chk_ca_comp_acc_factor( v_sMsg);
  return SQLCODE;
}

void end_chk_ca_comp_acc_factor( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end chk_ca_comp_acc_factor function");
  puts("*********************************");
  puts("");
}

