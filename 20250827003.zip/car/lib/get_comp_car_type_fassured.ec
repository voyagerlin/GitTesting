/*
   Name       : get_comp_car_type_fassured
   Purpose    : car9712022 �j���I�ȳf������۵M�H�k�H�O�v 
                980301���e�ȳf���۵M�H�P04�A�k�H�P19
                �̱j���I���إN��,�O�v�N��,�Q�O�I�H�ʽ���o���إN���M�Q�O�I�H�ʽ�

   Input      : *v_icar_type		���إN��
                *v_comp_frate           �O�v�N��
                *v_fassured             �Q�O�I�H�ʽ�
   Output     : return code 		M_CM_OK ���\
                *v_comp_icar_type       ���إN�� 
                *v_comp_fassured        �Q�O�I�H�ʽ� 
                v_sMsg      		�T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"
void end_get_comp_car_type_fassured( );

long get_comp_car_type_fassured( char   *v_icar_type,
                                 char   *v_comp_frate,
                                 char   *v_fassured,
                                 char   *v_comp_icar_type,
                                 char   *v_comp_fassured,
                                 char   *v_sMsg)
{
  $char f980301[2];
  $char comp_frate[5],tmp_sMsg[512];
  $WHENEVER SQLERROR GOTO errexit;


  puts("");
  puts("******************************");
  puts("begin get_comp_car_type_fassured function");
  printf("     v_icar_type[%s], v_comp_frate[%s], v_fassured[%s] \n ", 
               v_icar_type, v_comp_frate, v_fassured); 

  strcpy( comp_frate, v_comp_frate);

  strcpy( v_comp_fassured, " ");

  strcpy( tmp_sMsg, " ");
  if( strncmp( v_icar_type, "22", 2)==0)
  {
      $SELECT case when drate >= date('03/01/2009') then '1' else '0' end
         INTO $f980301
         FROM ca_rate_date
        WHERE icode  = $comp_frate
                       AND itable = 'compulsory_premium';

      if (SQLCODE == SQLNOTFOUND)  return M_CA_COMP_DRATE;

      printf("f980301[%s]\n", f980301);

      if( f980301[0] == '1')
      {
          strcpy( v_comp_icar_type, v_icar_type);
          if((strcmp(v_fassured,"1")==0)||(strcmp(v_fassured,"3")==0)||(strcmp(v_fassured,"5")==0))
              strcpy( v_comp_fassured, "1");
          else
              strcpy( v_comp_fassured, "2");
      }
      else /* 980301���e�ȳf���۵M�H�P04�A�k�H�P19 */
      {
          if((strcmp(v_fassured,"1")==0)||(strcmp(v_fassured,"3")==0)||(strcmp(v_fassured,"5")==0))
          {
              strcpy( v_comp_icar_type,"04");
          }
          else
          {
              strcpy( v_comp_icar_type,"19");
          }
      }
  }
  else
      strcpy( v_comp_icar_type, v_icar_type);

  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "get v_comp_icar_type[%s], v_comp_fassured[%s] \n", v_comp_icar_type, v_comp_fassured);
  strcpy(v_sMsg, tmp_sMsg);
  end_get_comp_car_type_fassured( v_sMsg);

  return M_CM_OK;

errexit:

  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy(v_sMsg, tmp_sMsg);
  end_get_comp_car_type_fassured( v_sMsg);
  return SQLCODE;


}

void end_get_comp_car_type_fassured( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_comp_car_type_fassured function");
  puts("******************************");
  puts("");
}
