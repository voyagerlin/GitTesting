/*
   Name       : chk_ibig_sales
   Input      : v_sIofficer 	�g��N��	ex: A03017
                v_sIbig_sales	�~�N�N�� 
   return code: M_CM_OK ���\
   Output     : v_sMsg      �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
void end_chk_ibig_sales( );

long chk_ibig_sales( v_sIofficer, v_sIbig_sales, v_sMsg)
$char    *v_sIofficer, *v_sIbig_sales, *v_sMsg;
{
  $char imgr[2],tmp_sMsg[512];;
  $int  iCount = 0;

  $WHENEVER SQLERROR GOTO errexit;

  puts("");
  puts("***********************************");
  puts("begin chk_ibig_sales function");
  printf("     v_sIofficer=[%s]\n", v_sIofficer);
  strcpy( tmp_sMsg, " ");
  
  $SELECT imgr 
     INTO $imgr
     FROM officer
    WHERE iofficer=$v_sIofficer;

  if(SQLCODE==SQLNOTFOUND)
  {
      sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "v_sIofficer[%s] not in table:officer\n", v_sIofficer);
	  strcpy( v_sMsg, tmp_sMsg);
      end_chk_ibig_sales( v_sMsg);
      return M_CMN_NOFFICER;
  }

  if( imgr[0] == '1')	/* ���ӥ� */
  {
      $SELECT COUNT(*)
         INTO $iCount
         FROM ca_big_office
        WHERE fclass = '2'			/* 2:�~�N */
          AND ibig_comp = $v_sIbig_sales;	/* �~�N�N�� */

      if( iCount == 0)
      {
          sprintf_s( tmp_sMsg, sizeof tmp_sMsg,"v_sIofficer[%s].imgr = [%s] ==> ���ӥ�A�~�N�N��[%s] not in ca_big_office\n", 
 							v_sIofficer, imgr, v_sIbig_sales);
		  strcpy( v_sMsg, tmp_sMsg);
          end_chk_ibig_sales( v_sMsg);
          return M_CA_BIG_SALES_NOT_FOUND;
      }
      else
      {
          sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "v_sIofficer[%s].imgr = [%s] ==> ���ӥ�A�~�N�N��[%s] found in ca_big_office\n", 
 							v_sIofficer, imgr, v_sIbig_sales);
		  strcpy( v_sMsg, tmp_sMsg);
          end_chk_ibig_sales( v_sMsg);
          return M_CM_OK;
      }
  }
  else if( imgr[0] == '0')	/* �D�X��g��N�����i�X�� */
  {
      sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "v_sIofficer[%s].imgr = [%s] ==> �D�X��g��N�����i�X�� \n", v_sIofficer, imgr);
	  strcpy( v_sMsg, tmp_sMsg);
      end_chk_ibig_sales( v_sMsg);
      return M_CA_IMGR_ERR;
  }
  else
  {
      sprintf_s( tmp_sMsg, sizeof tmp_sMsg,"v_sIofficer[%s].imgr = [%s] ==> �D���ӥ�A�����ˮַ~�N�N��\n", v_sIofficer, imgr);
	  strcpy( v_sMsg, tmp_sMsg);
      end_chk_ibig_sales( v_sMsg);
      return M_CM_OK;
  }

errexit:
  sprintf_s( tmp_sMsg, sizeof tmp_sMsg,"SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]); 
  strcpy( v_sMsg, tmp_sMsg);
  end_chk_ibig_sales( v_sMsg);
  return SQLCODE;
}

void end_chk_ibig_sales( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end chk_ibig_sales function");
  puts("*********************************");
  puts("");
}

