/*
   �������O�T�l�O�渹
   Name       : get_VW_ipolicy_num
   Input      : v_sIext_policy 		ex:00095VW000505 �����O�T�D�O�渹
   return code: M_CM_OK 		���\
   Output     : v_sIpolicy 		ex:00095VW0005050001
                v_sMsg      		�T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "ISconstant_car.h"
#include "safeclib.h"
#define MsgLen 512

void end_get_VW_ipolicy_num( );

long get_VW_ipolicy_num( v_sIext_policy, v_sIpolicy, v_sMsg)
$char *v_sIext_policy, *v_sIpolicy, *v_sMsg;
{
  $int    iply_seq=0;
  strcpy(v_sMsg," "); 
  
  $WHENEVER SQLERROR GOTO errexit;

  puts("");
  puts("***********************************");
  puts("begin get_VW_ipolicy_num function");
  printf("     INPUT:v_sIext_policy=[%s]\n", v_sIext_policy);

  /* �T�wv_sIext_policy in ca_ply_ext */

  $SELECT iply_seq+1
     INTO $iply_seq
     FROM ca_ply_ext
    WHERE ipolicy = $v_sIext_policy;
  
  if(SQLCODE==SQLNOTFOUND)
  {
      sprintf_s(v_sMsg, MsgLen, "v_sIext_policy[%s] �����O�T�D�O�渹 not in table:ca_ply_ext\n", v_sIext_policy);
      end_get_VW_ipolicy_num( v_sMsg);
      return M_CA_PLY_MAIN_NO_GET;
  }

  puts("end select ca_ply_ext");
  
  $SELECT case when max(ipolicy[14]) = ' ' then 1 else nvl(max(ipolicy[14,17]),0)+1 end case
     INTO $iply_seq
     FROM policy
    WHERE ipolicy[1,13] = $v_sIext_policy;

  puts("end select policy");
  
  $UPDATE ca_ply_ext
      SET iply_seq = $iply_seq,
          dupdate  = current
    WHERE ipolicy = $v_sIext_policy;

  puts("end update ca_ply_ext");
  
  v_sIext_policy[CAR_POLICY_LEN]='\0';

  printf("v_sIext_policy[%s]\n", v_sIext_policy);

  sprintf_s(v_sIpolicy, 21, "%s%04d", v_sIext_policy, iply_seq);
  printf("OUTPUT ���o�����O�T�l�O�渹�Gv_sIpolicy[%s]\n", v_sIpolicy);

  end_get_VW_ipolicy_num( v_sMsg);
  return M_CM_OK;

errexit:
  sprintf_s(v_sMsg, MsgLen, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]); 
  end_get_VW_ipolicy_num( v_sMsg);
  return SQLCODE;
}

void end_get_VW_ipolicy_num( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_VW_ipolicy_num function");
  puts("*********************************");
  puts("");
}

