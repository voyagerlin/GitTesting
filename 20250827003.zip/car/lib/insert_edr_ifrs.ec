/***********************************************************************
 *                                                                     *
 *   program id   : insert_edr_ifrs.ec                                 *
 *   program name : ���Iifrs17���ͤ@�t�@�����C���function                  *
 *                                                                     *
 **********************************************************************/
#include <stdio.h>
#include <api_xsrv.h>
#include <comdata.h>
#include <globdata.h>
#include <commsgs.h>
#include <carmsgs.h>
#include <cmnmsgs.h>
#include "sammsgs.h"
#include <decimal.h>
#include <math.h>
#include <stdlib.h>;
#include <string.h>;
#include <ctype.h>
#include "globdata.h"
#include "is_def.h"
#include "print.h"
$include "var_length.h";
#include "safeclib.h"

#define TRUE                  1
#define FALSE                 0
#define DATENULL              0x80000000L
#define FOUND                 sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND             sqlca.sqlcode==SQLNOTFOUND


void end_insert_edr_ifrs( );
char *get_db();

/*****  1111101004_SC1 ��氣�C���t�λݨD��G�̾ڡu���C�ӷ����v���ͤ@�t�@����(IFRS17���C)���   *************

 �ǤJ: v_iendorse(���C�ӷ���渹)�Bv_iprog(�{���N��)
 �ǥX: iendorse1_out(�t��)�Biendorse2_out(����)
 
 �� ��ӡi�g����j��������O�B���ʽ�G
 [�t�����]
    ��ƨӷ�: ���� v_iendorse �e���O��A�Y v_iendorse �������O��ƥ���(bak) 
    ������O�GA
    ���ʽ�G80
    ���C���p��渹�Gv_iendorse
 [�������]
    ��ƨӷ�: ��� v_iendorse
    ������O�GA
    ���ʽ�G81
    ���C���p��渹�Gv_iendorse    

   =============================================================================================

        �� ����: �̷s�O��P�A�Ĥ@�����(E1)�G��e�A�N�̷s�O��P�ƥ���K1�F���A�N����Ʀ^�g�̷ܳs�O��P(��ƪ��A�ܬ�P1) ...

                                   ( ���@�~ )            ( ���鵲�@�~ )  
                           ---------------------------    ------------   
          [�̷s�O��(����)]   [ P  ��  P1   ��  P2  ��   P3  ��  P4  ��   P5  ]  
                  ( �� �^�g )                                 
          [�������]                ��E1     ��E2     ��E3    ��E4(�t)  ��E5(��)
                  ( �� �ƥ� )      ��       ��       ��      ��       ��
          [��e�O��ƥ�(bak��)        K1      K2      K3     K4       K5

          
        �� �YE2���u���C�ӷ����v�A�h�i���鵲�@�~�j�ɡA���۰ʲ��͡u�@�t(E4)�@��(E5)���C���v�G
                     
          �� �t��(���C)���E4 �� ��ƨӷ��G
              �u���C�ӷ����v�����e�O��P1�A��YE2�����e�O��ƥ��iK2�j�A�䤤���B������춷�ġu�t���v�B�z

          �� ����(���C)���E5 �� ��ƨӷ��G
               �P ���B�B�O�O�����G��ƨӷ��P�t���A������ġu�����v�B�z
               �P ��l���G�ϥΡu���C�ӷ����v������O��P2�A��YE3�����e�O��
                         �ƥ��ɡiK3�j�F�YE2�w���̫�@�����A�h�ϥΡu���C�ӷ���
                         ��v������O��P2�A�Y�����U�i�̷s�O��j�C 

          
*/  


/*********************************************************/
/* get db list */
char *get_db(sIpolicy)
char *sIpolicy;
{
  $char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  static char sTmp_db_name[21];
  static char rtnd[11];

  $WHENEVER SQLERROR GOTO errexit;

  sTmp_db_name[0] = '\0';
  if (*sIpolicy != '\0' && *sIpolicy != ' ')
  {
    sTmp_db_name[0] = '\0';
    strncpy(sTmpScomp, sIpolicy + 2, 1);
    sTmpScomp[1] = '\0';
    printf("sTmpScomp = %s\n", sTmpScomp);
    $SELECT iupcomp
        INTO $sTmpcomp
            FROM branch
                WHERE ibranch_abbr = $sTmpScomp;
    if (SQLCODE == SQLNOTFOUND)
    {
      strcpy(rtnd, itoa(SQLCODE));
      goto errexit;
    }
    /*
    strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
           USE_BRANCH_ID));
    */
    printf("sTmpcomp = %s\n", sTmpcomp);
    strcpy(sTmp_db_name, sTmpcomp);
  }
  return sTmp_db_name;

errexit:
  return rtnd;
}

 long insert_edr_ifrs( v_iendorse, v_iprog, iendorse1_out, iendorse2_out, v_sMsg)
$char *v_iendorse, *v_iprog, *iendorse1_out, *iendorse2_out, *v_sMsg ;
{

     long MsgCode;
     long rc;
     char  sIbilling[3];
     char  sIbranchIcomp[CA_POL_BRH_NUM];
     char  sIcomp_in[BRANCH_ID], sIbranch_in[BRANCH_ID];
     char  sIcomp_in_short[BRANCH_ID];
     $char ipolicy[21];
     $char sDB[3];   
     $char fedr_class[2];         
     $char temp[POLICY_NUM_1];
     $char temp1[POLICY_NUM_1];
     $date dwritten;
     $char iedr_type1[3];
     $char iedr_type2[3];
     $char stmt[20000],sSql[10000];
     $int  ibatch_no=0;
     $char payresult[3], paystatus[32], paydate[11], notedate[11];
     $char fpay[2];
     $long stepi;
     $long fRtnCode;
     $int  iedr_cnt, i;
     $char ibranch_at[3], icomp_at[3];
     $char batchno[4];
     $char sIdir[9];     
     $int  edrrel_qcount;
     $int  edrins_qcount, iCount;
     char  policy_1[POLICY_NUM_1], policy_2[POLICY_NUM_2];
     char  presult[11], pdesc[51], ibroker_expire[2];
     $char s_ipolicy[21], sIendorse[21];  
     $char sIedr_examiner[11],iquota_new[7],iedr_next[21];
     $int  medrins_prem=0,mins_premium=0,medr_commission=0,medr_agent=0,mcommission=0,magent=0;
     char tmp_sMsg[512];

     $WHENEVER SQLERROR GOTO errexit;

     printf("v_iendorse[%s] \n", v_iendorse);
     printf("v_iprog[%s]\n", v_iprog); 

     strcpy(iendorse1_out,"");
     strcpy(iendorse1_out,"");
     strcpy(tmp_sMsg," ");

     edrrel_qcount = 0;
     edrins_qcount = 0;

     /* ���o v_iendorse ���O�渹�B���H�� */
     strcpy(s_ipolicy," ");
     strcpy(sIedr_examiner," ");
     $SELECT ipolicy,iedr_examiner 
        into $s_ipolicy, $sIedr_examiner
        FROM edr_relation
       WHERE iendorse = $v_iendorse;    

     printf("s_ipolicy[%s]\n", s_ipolicy);     
     printf("sIedr_examiner[%s]\n", sIedr_examiner);          


     /* get ���B�z������c & �����q*/
     strcpy(sIdir, " ");
     $SELECT idir INTO $sIdir
        FROM user
       WHERE iemp = $sIedr_examiner;
     if (SQLCODE == SQLNOTFOUND)
     {
         return M_CA_NO_USERID;
     }     
     printf("int cm_get_unit_at: idir[%s]\n", sIdir);   
       
     strncpy(ibranch_at, sIdir, BRANCH_ID - 1);
     ibranch_at[BRANCH_ID - 1] = '\0';
     printf("ibranch_at[%s]\n", ibranch_at);

     strcpy(icomp_at, " ");
     $SELECT iupcomp  INTO $icomp_at
        FROM sa_branch_type
       WHERE ibranch = $sIdir;
     if (SQLCODE == SQLNOTFOUND)
     {
         return M_CMN_NBRANCH;
     }
     printf("icomp_at[%s]\n", icomp_at);
     
     strcpy(sDB, get_db(s_ipolicy));
     /*
     
     iCount = 0;
     $SELECT COUNT(*) INTO $iCount
        FROM edr_relation
       WHERE ipolicy = $s_ipolicy
         AND iendorse not like '%CVP%' AND dedr_close is null;

     if (iCount != 0) * ���O��|����楼�鵲,�ݤ鵲��j�ѦA��� *
     {
         return M_CA_EDR_NO_CLOSE;
     }
     */
     rtoday(&dwritten);
     strcpy(fedr_class, "A");   /* ��Ӹg���蠟������O */
     strcpy(iedr_type1, "80");  /* �t�����ʽ� */
     strcpy(iedr_type2, "81");  /* �������ʽ� */
 

     policy_1[0] = '\0';  policy_2[0] = '\0';
     strncpy(policy_1, s_ipolicy, CAR_POLICY_LEN);
     policy_1[CAR_POLICY_LEN] = 0;
     if (strlen(s_ipolicy) > CAR_POLICY_LEN)
     {
        strcpy(policy_2, &s_ipolicy[CAR_POLICY_LEN]);
     }
     else
     {
        strcpy(policy_2, " ");
     }
     strcpy(ibroker_expire, "N");


     /* get ���s�X���O*/
     strncpy(sIbilling, s_ipolicy + CAR_POL_CHR_POS - 1, 2);
     sIbilling[2] = '\0';
     printf("sIbilling[%s]\n", sIbilling);

     /* get ����k�ݤ�����c & �����q*/
     strncpy(sIbranchIcomp, s_ipolicy, CA_POL_BRH_NUM - 1);
     sIbranchIcomp[CA_POL_BRH_NUM - 1] = '\0';
     printf("sIbranchIcomp[%s]\n", sIbranchIcomp);

     fRtnCode = cm_get_unit_in("", sIbranchIcomp, sIedr_examiner,
                              sIbranchIcomp, "C1", sIcomp_in, sIbranch_in);
     if (fRtnCode != M_CM_OK)
     {
          return fRtnCode;
     }
     
     strcpy(sIcomp_in_short, get_upcomp(sIcomp_in, USE_BRANCH_ID, USE_SHORT_BRANCH_ID));

                       
     stepi = cm_get_serial_num("C4", sIbilling,
                              sIcomp_in_short, sIbranch_in,
                              cm_cdate_str_100(cm_today()),
                              temp);
     if (stepi != 0)
     {
          if (stepi == 1 || stepi == 2)
          {
               stepi = M_CM_DB_NOTOPEN;
          }
          else if (stepi == 3)
          {
               stepi = M_CMN_NAUTONUMBERING;
          }          
          return stepi;
     }


     printf("�t����渹temp[%s]\n", temp);

     stepi = cm_get_serial_num("C4", sIbilling,
                              sIcomp_in_short, sIbranch_in,
                              cm_cdate_str_100(cm_today()),
                              temp1);
     if (stepi != 0)
     {
          /*$WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;*/
          if (stepi == 1 || stepi == 2)
          {
               stepi = M_CM_DB_NOTOPEN;
          }
          else if (stepi == 3)
          {
               stepi = M_CMN_NAUTONUMBERING;
          }          
          return stepi;
     }
     printf("������渹temp1[%s]\n", temp1);

     printf("END get number\n");

     policy_1[0] = '\0';
     policy_2[0] = '\0';

     strncpy(policy_1, s_ipolicy, CAR_POLICY_LEN);
     policy_1[CAR_POLICY_LEN] = 0;

     printf("END s_ipolicy split \n");

     if (strlen(s_ipolicy) > CAR_POLICY_LEN)
          strcpy(policy_2, &s_ipolicy[CAR_POLICY_LEN]);
     else
          strcpy(policy_2, " ");

     printf("policy_1[%s]\n", policy_1);
     printf("policy_2[%s]\n", policy_2);
     printf("ibatch_no[%d]\n", ibatch_no);
     printf("sDB[%s]\n", sDB);

     strcpy(batchno, itoa(ibatch_no));
     printf("batchno[%s]\n", batchno);

     strcpy(fpay, " ");
     strcpy(payresult," ");
     /* get ���O���A      
     rc = ao_chk_charge(sDB, '3', policy_1, policy_2, batchno,
                         payresult, paystatus, paydate, notedate);
     printf("rc[%d]\n", rc);
     if (rc != TRUE)
     {
          return rc; 
     }
     printf("payresult[%s]\n", payresult);

     
     if (payresult[0] != 'R')
     {
          strcpy(fpay, "1");
     }
     */

     /* �T�{ v_iendorse �O�_��s_ipolicy���̫�@�����A�Y���O�A�h��Xv_iendorse���U�@�i���G
        �� ��X�O��s_ipolicy�����̡A�j�� v_iendorse ���̤p��渹�F
          �Y�䤣��A�N�� v_iendorse �w�g�O�̫�@�����         
     */

     strcpy(iedr_next," ");
     $SELECT min(iendorse) INTO $iedr_next
        FROM edr_relation 
       WHERE ipolicy = $s_ipolicy 
         AND iendorse Not Like '%CVP%'
         AND dcreate > (SELECT dcreate FROM edr_relation WHERE iendorse = $v_iendorse);

     printf("--trace iedr_next=[%s]\n",iedr_next);
     
     /***************************** �� �}�l�t���@�~ ��*****************************/     
     /*
         �� �t��(���C)��椧 ��ƨӷ��G
              �u���C�ӷ����v(v_iendorse)�����e�O��A��YE2�����e�O��ƥ��iK2�j�A�䤤���B������춷�ġu�t���v�B�z
     */

     /**** START �t���e�ƥ� ****/
     rc = bk_401(sDB, s_ipolicy, temp);
     if (rc != M_CM_OK)
     {
          return rc;
     }
     /**** END   �t���e�ƥ� ****/
     printf("END �t�� bk401\n");


     /*----------------------- �B�z�t�������� -----------------------*/

     
     edrrel_qcount = -1;
     edrins_qcount = -1;

     /* [edr_ins_type] �H ply_ins_type_bak �����"�ĭt��" ���� edr_ins_type */
     /* (iproduct �����e�ӫ~�N�X )*/

     stmt[0] = '\0';
     sprintf_s(stmt, sizeof stmt,
               "INSERT INTO edr_ins_type "
               "    (iendorse, iins_type, iedr_type, medrinj_cover, medrdea_cover,        "
               "     medrdmg_cover, mdeduct, medrins_prem, medrpure_prem, fcal_way,       "
               "     pcal, qserial, pcommission, medr_commission, pagent, medr_agent,     "
               "     pdiscount, medr_discount, drate_ym, medr_prem, iproduct,ipaid_base,  "
               "     qday, medr_expense, medr_exp_disc, qcount, provision,irate,          "
               "     adjust_rate,mins_premium_n, mpure_prem_n , mprem_n, safe_rate,       "
               "     manage_rate, educated_rate, deviation_rate, pextra_charge, pbusiness,"
               "     psex_age,pshipping, mdrunk_prem, mdrunk_pure_prem, mviolate_prem,    "
               "     mviolate_pure_prem  )                                                "
               " SELECT '%s', iins_type, '%s',                                            "
               "     minjured_cover*(-1), mdeath_cover*(-1), mdamage_cover*(-1),          "
               "     mdeduct*(-1), mins_premium*(-1), mpure_prem*(-1),'M', 100,           "
               "     qserial, pcommission*(-1), mcommission*(-1),pagent*(-1),             "
               "     magent*(-1), pdiscount*(-1), mdiscount*(-1), drate_ym,               "
               "     mprem*(-1), iproduct, ipaid_base, qday*(-1), mexpense*(-1),          "
               "     mexp_disc*(-1), %ld ,provision,irate,adjust_rate,                    "
               "     mins_premium_n*(-1), mpure_prem_n*(-1), mprem_n*(-1),safe_rate,      "
               "     manage_rate,educated_rate, deviation_rate,pextra_charge, pbusiness,  "
               "     psex_age,pshipping,mdrunk_prem*(-1), mdrunk_pure_prem*(-1),          "
               "     mviolate_prem*(-1), mviolate_pure_prem*(-1)                          "
               "  FROM ply_ins_type_bak "
               " WHERE iendorse = '%s'  ",
               temp, iedr_type1, edrins_qcount, v_iendorse);
     printf("stmt[%s]\n", stmt);
     $PREPARE eins1 FROM $stmt;
     $EXECUTE eins1;

     /* [ca_pa_edr] �H ca_pa_ply_bak �����"�ĭt��" ���� ca_pa_edr */

     stmt[0] = '\0';
     sprintf_s(stmt, sizeof stmt,
               "INSERT INTO ca_pa_edr  "
               "     (iendorse, iins_type, iinsurant, iedr_type, ninsurant, dbirth,"
               "     ainsurant, iins_scope, icareer, medrins_amt, fcal_way, pcal,  "
               "     medrins_prem, medrpure_prem, pcommission,                     "
               "     medr_commission, pagent, medr_agent, pdiscount,               "
               "     medr_discount, dendorse, napplicant, relation_appl,           "
               "     nbeneficiary,relation_bene,tbenef, abenef_zip, abenef,        "
               "     medr_daily_pay, medr_mr_ins_prem , medr_mr_pure_prem )        "
               " SELECT '%s', iins_type, iinsurant, '%s', ninsurant, dbirth,       "
               "     ainsurant, iins_scope, icareer, mins_amt*(-1), 'M', 100,      "
               "     mins_premium*(-1), mpure_prem*(-1),pcommission*(-1),          "
               "     mcommission*(-1), pagent*(-1),magent*(-1),pdiscount*(-1),     "
               "     mdiscount*(-1), %ld, napplicant, relation_appl,nbeneficiary,  "
               "     relation_bene,tbenef, abenef_zip, abenef,                     "
               "     daily_pay*(-1),mr_ins_prem*(-1),mr_pure_prem*(-1)             "
               "  FROM ca_pa_ply_bak  "
               " WHERE iendorse = '%s'",
               temp, iedr_type1,  dwritten, v_iendorse);
     printf("stmt[%s]\n", stmt);
     $PREPARE caedr1 FROM $stmt;
     $EXECUTE caedr1;


     /* [edr_ins_cover] �H ply_ins_cover_bak �����"�ĭt��" ���� edr_ins_cover */
     stmt[0] = '\0';
     sprintf_s(stmt, sizeof stmt,
               "INSERT INTO edr_ins_cover "
               "    (iendorse, iins_type, icover_type, mcover, mcover_prem, "
               "     mdiscount, mprem, mpure_prem )                         "
               " SELECT '%s', iins_type, icover_type,                       "
               "     mcover * (-1), mcover_prem * (-1), mdiscount * (-1),   "
               "     mprem * (-1), mpure_prem * (-1)                        "
               " FROM ply_ins_cover_bak "
               " WHERE iendorse = '%s'",  temp, v_iendorse);
     printf("stmt[%s]\n", stmt);
     $PREPARE eins_cover1 FROM $stmt;
     $EXECUTE eins_cover1;


     /***** �u�@�t�@�����C���v�ت����O���F���̷s�O��A�G�̷s�O���Ƥ������� ********/
     /* [ply_ins_type] �H ply_ins_type_bak �����"�ĭt��"�� ply_ins_type ��ƶi��update
     stmt[0] = '\0';
     sprintf_s(stmt, sizeof stmt,
               "MERGE Into ply_ins_type p \
                USING (SELECT * FROM ply_ins_type_bak WHERE iendorse = '%s') k \
                   ON ( p.ipolicy = k.ipolicy And p.iins_type = k.iins_type)   \
                 WHEN MATCHED THEN                      \
                      UPDATE SET                        \
                         p.minjured_cover     = p.minjured_cover     + (-1) * k.minjured_cover    , \
                         p.mdeath_cover       = p.mdeath_cover       + (-1) * k.mdeath_cover      , \
                         p.mdamage_cover      = p.mdamage_cover      + (-1) * k.mdamage_cover     , \
                         p.mdeduct            = p.mdeduct            + (-1) * k.mdeduct           , \
                         p.mins_premium       = p.mins_premium       + (-1) * k.mins_premium      , \
                         p.mpure_prem         = p.mpure_prem         + (-1) * k.mpure_prem        , \
                         p.pcommission        = p.pcommission        + (-1) * k.pcommission       , \
                         p.mcommission        = p.mcommission        + (-1) * k.mcommission       , \
                         p.pagent             = p.pagent             + (-1) * k.pagent            , \
                         p.magent             = p.magent             + (-1) * k.magent            , \
                         p.pdiscount          = p.pdiscount          + (-1) * k.pdiscount         , \
                         p.mdiscount          = p.mdiscount          + (-1) * k.mdiscount         , \
                         p.mprem              = p.mprem              + (-1) * k.mprem             , \
                         p.qday               = p.qday               + (-1) * k.qday              , \
                         p.mexpense           = p.mexpense           + (-1) * k.mexpense          , \
                         p.mexp_disc          = p.mexp_disc          + (-1) * k.mexp_disc         , \
                         p.mdrunk_prem        = p.mdrunk_prem        + (-1) * k.mdrunk_prem       , \
                         p.mdrunk_pure_prem   = p.mdrunk_pure_prem   + (-1) * k.mdrunk_pure_prem  , \
                         p.mviolate_prem      = p.mviolate_prem      + (-1) * k.mviolate_prem     , \
                         p.mviolate_pure_prem = p.mviolate_pure_prem + (-1) * k.mviolate_pure_prem, \
                         p.mins_premium_n     = p.mins_premium_n     + (-1) * k.mins_premium_n    , \
                         p.mpure_prem_n       = p.mpure_prem_n       + (-1) * k.mpure_prem_n      , \
                         p.mprem_n            = p.mprem_n            + (-1) * k.mprem_n           , \
                         p.iproduct           = k.iproduct   , \
                         p.provision          = k.provision  , \
                         p.ipaid_base         = k.ipaid_base , \
                         p.psex_age           = k.psex_age   , \
                         p.iendorse           = '%s' ",
          v_iendorse , temp);            
          
                
     printf("stmt[%s]\n", stmt);     
     $PREPARE pins1 FROM $stmt;
     $EXECUTE pins1;
     */

     /*�H ca_pa_ply_bak �����"�ĭt��"�� ca_pa_ply ��ƶi��update
     stmt[0] = '\0';
     sprintf_s(stmt, sizeof stmt,
               "MERGE Into ca_pa_ply p \
                USING (SELECT * FROM ca_pa_ply_bak WHERE iendorse = '%s' ) k \
                   ON (p.ipolicy = k.ipolicy And p.iins_type = k.iins_type  \
                       And p.iinsurant = k.iinsurant And p.iins_scope = k.iins_scope \
                       And p.icareer = k.icareer ) \
                 WHEN MATCHED THEN                         \
                      UPDATE SET                           \
                         p.mins_amt      = p.mins_amt     + (-1) * k.mins_amt    , \
                         p.mins_premium  = p.mins_premium + (-1) * k.mins_premium, \
                         p.mpure_prem    = p.mpure_prem   + (-1) * k.mpure_prem  , \
                         p.pcommission   = p.pcommission  + (-1) * k.pcommission , \
                         p.mcommission   = p.mcommission  + (-1) * k.mcommission , \
                         p.pagent        = p.pagent       + (-1) * k.pagent      , \
                         p.magent        = p.magent       + (-1) * k.magent      , \
                         p.pdiscount     = p.pdiscount    + (-1) * k.pdiscount   , \
                         p.mdiscount     = p.mdiscount    + (-1) * k.mdiscount   , \
                         p.daily_pay     = p.daily_pay    + (-1) * k.daily_pay   , \
                         p.mr_ins_prem   = p.mr_ins_prem  + (-1) * k.mr_ins_prem , \
                         p.mr_pure_prem  = p.mr_pure_prem + (-1) * k.mr_pure_prem, \
                         p.iendorse      = '%s' ",
            v_iendorse , temp);
                 
     printf("stmt[%s]\n", stmt);
     $PREPARE cains1 FROM $stmt;
     $EXECUTE cains1;
     */

     /*�H ply_ins_cover_bak �����"�ĭt��"�� ply_ins_cover ��ƶi��update
     * (ply_ins_cover_bak �S���O�渹���A�ҥH�n�� join ply_ins_type_bak �H���o�O�渹) *
     stmt[0] = '\0';
     sprintf_s(stmt, sizeof stmt,
               "MERGE Into ply_ins_cover p \
                USING (SELECT b.ipolicy,a.* FROM ply_ins_cover_bak a,ply_ins_type_bak b \
                        WHERE a.iendorse = b.iendorse and a.iendorse = '%s' \
                          and a.iins_type = b.iins_type) k \
                   ON ( p.ipolicy = k.ipolicy And p.iins_type = k.iins_type \
                        And p.icover_type = k.icover_type ) \
                 WHEN MATCHED THEN                      \
                      UPDATE SET                        \
                         p.mcover       = p.mcover      + (-1) * k.mcover      , \
                         p.mcover_prem  = p.mcover_prem + (-1) * k.mcover_prem , \
                         p.mdiscount    = p.mdiscount   + (-1) * k.mdiscount   , \
                         p.mprem        = p.mprem       + (-1) * k.mprem       , \
                         p.mpure_prem   = p.mpure_prem  + (-1) * k.mpure_prem ",
            v_iendorse);
     printf("stmt[%s]\n", stmt);
     $PREPARE cains_cover FROM $stmt;
     $EXECUTE cains_cover;
     */

     /*----------------------- �B�z�t���D�� -----------------------*/

     /* [edr_relation] �H ply_relation_bak �����"�ĭt��" ���� edr_relation */

     stmt[0] = '\0';     
     sprintf_s(stmt, sizeof stmt,
              "INSERT INTO edr_relation "
              "  (iendorse, fcard_class, ipolicy, icard, irelative_ply, irelative_edr, "
              "  fedr_class, fpay, ipay, iedr_field, dedr_begin, dedr_end, "
              "  ipro_year, ibrand, icar_type, medrdmg_agent, medrdmg_commi, "
              "  medrdmg_prem, medrdmg_pure_prem, medrlia_agent, medrlia_commi, "
              "  medrlia_prem, medrlia_pure_prem, ibig_comp, ibig_branch, ibig_office, "
              "  ibig_sales, iresource, ibroker, iofficer, ileader, icorps, iedr_area, "
              "  iedr_cashier, iedr_examiner, dedr_examine, dentry, dendorse, "
              "  fprint, itreaty, ibranch, iquota, icomp_in, ibranch_in, icomp_at, "
              "  ibranch_at, medr_ready, medr_stable, medr_compensate, medr_adjcom, "
              "  medr_research, medr_invest, medr_bus_rule, medr_business, "
              "  medr_capital, medr_maintain, fcomp_class, fcomp_class_last, fdiscount, medrdmg_disc, "
              "  medrlia_disc, iedr_return, icar_flag, terminate_rsn, qcount, "
              "  iofficer_prmt, iquota_prmt, ileader_prmt, irate_type, bzfrom, iroute_comm, icomm_obj, "
              "  qprovision,isecond_hand, icard_main, qdrunk_driving, isign,feply,feedr,aemail_eply, "
              "  tmobile_eply,ireg_no,dnotifyornot,isign_edr,dsign_edr,fsign_status_edr,funder_chk_edr,iprog, "
              "  qviolate,iendorse_dere,idere_type) "
              " SELECT '%s', fcard_class, ipolicy, icard, irelative_ply, ' ', "
              "  '%s', '%s', ' ', ' ', dply_begin, dply_end, "
              "  ipro_year, ibrand, icar_type, mdmg_agent * (-1), mdmg_commi * (-1), "
              "  mdmg_prem * (-1), mdmg_pure_prem * (-1), mlia_agent * (-1), mlia_commi * (-1), "
              "  mlia_prem * (-1), mlia_pure_prem * (-1), ibig_comp, ibig_branch, ibig_office, "
              "  ibig_sales, iresource, ibroker, iofficer, ileader, icorps, iarea, "
              "  '%s', '%s', %ld, %ld, '', "
              "  1, itreaty, ibranch, iquota, icomp_in, ibranch_in,  icomp_at , "
              "  ibranch_at , mready * (-1), mstable * (-1), mcompensation * (-1), madjcom_prem * (-1), "
              "  mresearch * (-1), minvest * (-1), mbus_rule * (-1), mbusiness * (-1), "
              "  mcapital * (-1), maintain * (-1), fcomp_class, fcomp_class_last, fdiscount, mdmg_discount * (-1), "
              "  mlia_discount * (-1), '0', icar_flag, '0', %ld, "
              "  iofficer_prmt, iquota_prmt, ileader_prmt, irate_type, bzfrom, iroute_comm, icomm_obj, "
              "  qprovision, isecond_hand, icard_main, qdrunk_driving, isign,feply, "
              "  (CASE WHEN fcard_class='2' THEN feply ELSE '0' END) AS feedr , aemail_eply, "
              "  tmobile_eply,ireg_no,dnotifyornot,'system',today,40,'N','%s', "
              "  qviolate, '%s', ' '  "
              "  FROM ply_relation_bak "
              " WHERE iendorse = '%s' ",
               temp, fedr_class, fpay,  sIedr_examiner, sIedr_examiner,dwritten, dwritten,edrrel_qcount,
               v_iprog, v_iendorse, v_iendorse);
     printf("stmt[%s]\n", stmt);
     $PREPARE edr1 FROM $stmt;
     $EXECUTE edr1;


     /*1071105008_SC2_ �������Ȩ��z��(FS)�A�éw�ɦ۰ʤU���ɮ�
     strcpy(iroute_accept_edr, " ");
     if (strncmp(b_iroute, "I009", 4) == 0)
     {
     strcpy(temp, trim(temp));
     sprintf_s(iroute_accept_edr, sizeof iroute_accept_edr, "CHB%s", temp);
     }

     printf("-- trace iroute_accept_edr[%s]\n ", iroute_accept_edr);
     */

     /* [endorsement] �H policy_bak �����"�ĭt��" ���� endorsement */
    
     stmt[0] = '\0';
     sprintf_s(stmt, sizeof stmt,
              "INSERT INTO endorsement "
              "  (iendorse, qply_period, dply_begin, dply_end, fassured, iassured,                    "
              "  iassured_ext, nassured, ilicense, fsex, fmarriage, nuser,                            "
              "  ibenef, nbenef, aassured, aassured_zip, itel,itel_night, mobil_phone,iemail, apayment, apayment_zip, "
              "  iply_area, nbrand_abbr, ncar_abbr, fcar_note, qcylinder, iengine, ibody,             "
              "  itag, mcar_price, nequipment, flimit, pdmg_align, pbrg_align, plia_align,            "
              "  idmg_rate, pdmg_factor, ibrg_rate, pbrg_factor, qpt, fpt, psex_age,                  "
              "  psex_age_damage,lia_class,plia_acc, dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd, pdmg_acc, "
              "  fhuman,fcomp_24,payresult,iext_policy, qpro_month, mkilo_ply,mkilo_edr, irisk,       "
              "  irelative_ext,napplicant, dbirth, dissue,iextra_charge, gextra_charge,               "
              "  pextra_charge,iquery_num_damage, iquery_num,introducer, mequipment,survey_num, bound_num, "
              "  abnormal_num, iapplicant,iroute,qlia_acc_sum, qdmg_acc_sum,                          "
              "  fapplicant,fsex_appl,dbirth_appl,itel_appl,ndeputy_appl,nrelation_appl,ndeputy_assured, "
              "  iassured_cntry,iapplicant_cntry,fequipment1,fequipment2,fequipment3,fequipment4,      "
              "  fequipment5,fequipment6,fequipment9,nequipment9,punknown_acc,iquery_num_unknown,qunknown_acc_sum, "
              "  nassured_cntry, napplicant_cntry,foccup, noccup, applicant_foccup, applicant_noccup, iowner, "
              "  nowner, iroute_accept,tmobile_appl,aemail_appl)   "
              " SELECT '%s', a.qply_period, a.dply_begin, a.dply_end,b.fassured, b.iassured,       "
              "  b.iassured_ext, b.nassured,b.ilicense, b.fsex, b.fmarriage, b.nuser,          "
              "  b.ibenef, b.nbenef, b.aassured, b.aassured_zip, b.itel, b.itel_night, b.mobil_phone,iemail, b.apayment, b.apayment_zip, "
              "  b.iply_area, b.nbrand_abbr,b.ncar_abbr, b.fcar_note, b.qcylinder, b.iengine, b.ibody,  "
              "  b.itag, b.mcar_price, b.nequipment, b.flimit, b.pdmg_align,b.pbrg_align, b.plia_align, "
              "  b.idmg_rate, b.pdmg_factor,b.ibrg_rate, b.pbrg_factor, b.qpt, b.fpt, b.psex_age,      "
              "  b.psex_age_damage,b.lia_class, b.plia_acc, b.dmg_acc_1st, b.dmg_acc_2nd,b.dmg_acc_3rd, b.pdmg_acc, "
              "  b.fhuman,b.fcomp_24,'%s',b.iext_policy,b.qpro_month,b.mkilo_ply,b.mkilo_edr,b.irisk, "
              "  b.irelative_ext,b.napplicant,b.dbirth,b.dissue,b.iextra_charge,b.gextra_charge, "
              "  b.pextra_charge,b.iquery_num_damage,b.iquery_num,b.introducer,b.mequipment,b.survey_num, b.bound_num, "
              "  b.abnormal_num, b.iapplicant,iroute,b.qlia_acc_sum,b.qdmg_acc_sum , "
              "  b.fapplicant,b.fsex_appl,b.dbirth_appl,b.itel_appl,b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured, "
              "  CASE WHEN b.iassured_cntry='' THEN '8' ELSE b.iassured_cntry END,   "
              "  CASE WHEN b.iapplicant_cntry='' THEN '8' ELSE b.iapplicant_cntry END,b.fequipment1,b.fequipment2, "
              "  b.fequipment3,b.fequipment4,b.fequipment5,b.fequipment6,b.fequipment9,b.nequipment9,b.punknown_acc, "
              "  b.iquery_num_unknown,b.qunknown_acc_sum,b.nassured_cntry, b.napplicant_cntry,b.foccup, b.noccup, "
              "  b.applicant_foccup, b.applicant_noccup,b.iowner,b.nowner,' ',b.tmobile_appl , b.aemail_appl "
              " FROM ply_relation_bak a,policy_bak b   "
              " WHERE a.iendorse = b.iendorse AND a.iendorse = '%s' ", 
          temp, payresult, v_iendorse);
            
          
     printf("stmt[%s]\n", stmt);
     $PREPARE endor1 FROM $stmt;
     $EXECUTE endor1;

      /***** �u�@�t�@�����C���v�ت����O���F���̷s�O��A�G�̷s�O���Ƥ������� ********/
     /*�H ply_relation_bak �����"�ĭt��"�� ply_relation ��ƶi��update
     stmt[0] = '\0';
     sprintf_s(stmt, sizeof stmt,
               "MERGE Into ply_relation p \
                USING (SELECT * FROM ply_relation_bak WHERE iendorse = '%s') k \
                   ON ( p.ipolicy = k.ipolicy )         \
                 WHEN MATCHED THEN                      \
                      UPDATE SET                        \
                         p.mdmg_prem      = p.mdmg_prem      + (-1) * k.mdmg_prem      , \
                         p.mdmg_agent     = p.mdmg_agent     + (-1) * k.mdmg_agent     , \
                         p.mdmg_commi     = p.mdmg_commi     + (-1) * k.mdmg_commi     , \
                         p.mlia_prem      = p.mlia_prem      + (-1) * k.mlia_prem      , \
                         p.mlia_agent     = p.mlia_agent     + (-1) * k.mlia_agent     , \
                         p.mlia_commi     = p.mlia_commi     + (-1) * k.mlia_commi     , \
                         p.mdmg_pure_prem = p.mdmg_pure_prem + (-1) * k.mdmg_pure_prem , \
                         p.mlia_pure_prem = p.mlia_pure_prem + (-1) * k.mlia_pure_prem , \
                         p.mready         = p.mready         + (-1) * k.mready         , \
                         p.mstable        = p.mstable        + (-1) * k.mstable        , \
                         p.mcompensation  = p.mcompensation  + (-1) * k.mcompensation  , \
                         p.madjcom_prem   = p.madjcom_prem   + (-1) * k.madjcom_prem   , \
                         p.mresearch      = p.mresearch      + (-1) * k.mresearch      , \
                         p.minvest        = p.minvest        + (-1) * k.minvest        , \
                         p.mbus_rule      = p.mbus_rule      + (-1) * k.mbus_rule      , \
                         p.mbusiness      = p.mbusiness      + (-1) * k.mbusiness      , \
                         p.mcapital       = p.mcapital       + (-1) * k.mcapital       , \
                         p.maintain       = p.maintain       + (-1) * k.maintain       , \
                         p.mdmg_discount  = p.mdmg_discount  + (-1) * k.mdmg_discount  , \
                         p.mlia_discount  = p.mlia_discount  + (-1) * k.mlia_discount  , \
                         p.icar_type      = k.icar_type     , \
                         p.qply_period    = k.qply_period   , \
                         p.dply_begin     = k.dply_begin    , \
                         p.dply_end       = k.dply_end        \
                         ", 
          v_iendorse);
             
     printf("stmt[%s]\n", stmt);
     $PREPARE ply1 FROM $stmt;
     $EXECUTE ply1;
     */

     /* �t�V��� Insert �� cm_pre_receive */     
     rc = insert_cm_pre_receive_edr(temp, s_ipolicy, v_iprog, tmp_sMsg);
     if (rc != M_CM_OK)
     {
         return rc;
     }

     /**** END �B�z�t���D��  ****/

     /***************************** �� �����t���@�~ ��*****************************/     

     /***************************** �� �}�l�����@�~ ��*****************************/
     /*
          �� ����(���C)���E5 �� ��ƨӷ��G
               �P ���B�B�O�O�����G��ƨӷ��P�t���A������ġu�����v�B�z
               �P ��l���G�ϥΡu���C�ӷ����v������O��P2�A��YE3�����e�O��
                         �ƥ��ɡiK3�j�F�YE2�w���̫�@�����A�h�ϥΡu���C�ӷ���
                         ��v������O��P2�A�Y�����U�i�̷s�O��j�C  
     */

     edrrel_qcount = 1;
     edrins_qcount = 1;

     /*$WHENEVER SQLERROR goto errexit;*/     

     /**** START �����e�ƥ� ****/
     rc = bk_401(sDB, s_ipolicy, temp1);
     if (rc != M_CM_OK)
     {
         return rc;
     }
     /**** END �����e�ƥ� ****/




     /*----------------------- �B�z���������� -----------------------*/             
     

     /* v_iendorse �w�g�O�̫�@�����A�ϥη��U�̷s�O���ƨӲ���"�D���B�B�O�O�������" */
     sSql[0] = '\0';
     strcpy(sSql, " iendorse, iins_type, iedr_type, medrinj_cover,                  "
                  "  medrdea_cover, medrdmg_cover, mdeduct, medrins_prem,           "
                  "  medrpure_prem, fcal_way, pcal, qserial, pcommission,           "
                  "  medr_commission, pagent, medr_agent, pdiscount, medr_discount, "
                  "  drate_ym, medr_prem, iproduct, ipaid_base, qday, medr_expense, "
                  "  medr_exp_disc, qcount, provision,irate,adjust_rate, psex_age, mdrunk_prem,"
                  "  mdrunk_pure_prem, mviolate_prem , mviolate_pure_prem,          "
                  "  mins_premium_n, mpure_prem_n , mprem_n,safe_rate,manage_rate,  "
                  "  educated_rate, deviation_rate, pextra_charge, pbusiness,pshipping ");
     trim_tail_white(sSql);

     stmt[0] = '\0';
     if (strlen(trim(iedr_next))==0) 
     {
          sprintf_s(stmt, sizeof stmt,
              "INSERT INTO edr_ins_type (%s) "
              " SELECT '%s', a.iins_type, '%s',                                     "
              "      a.minjured_cover , a.mdeath_cover ,                            "
              "      a.mdamage_cover, a.mdeduct,a.mins_premium, a.mpure_prem,       "
              "      'M', 100, a.qserial, a.pcommission, a.mcommission, a.pagent,   "
              "      a.magent,a.pdiscount,a.mdiscount,b.drate_ym,a.mprem,b.iproduct,"
              "      b.ipaid_base, a.qday, a.mexpense,a.mexp_disc,%ld, b.provision, "
              "      b.irate,b.adjust_rate,b.psex_age,a.mdrunk_prem, a.mdrunk_pure_prem,"
              "      a.mviolate_prem,a.mviolate_pure_prem ,a.mins_premium_n,        "
              "      a.mpure_prem_n ,a.mprem_n ,b.safe_rate,b.manage_rate,b.educated_rate,"
              "      b.deviation_rate, b.pextra_charge,b.pbusiness ,b.pshipping     "
              " FROM ply_ins_type_bak a, ply_ins_type b                             "
              " WHERE a.ipolicy  = b.ipolicy and a.iins_type = b.iins_type          "
              "   AND a.iendorse = '%s' ",
               sSql,temp1, iedr_type2, edrins_qcount, v_iendorse);     
     }
     else
     { /* �ϥ� v_iendorse ���U�@�i���iedr_next��bak��ƨӲ���"�D���B�B�O�O�������" */

          sprintf_s(stmt, sizeof stmt,
               "INSERT INTO edr_ins_type (%s) "
               " SELECT '%s', a.iins_type, '%s',                                     "
               "      a.minjured_cover , a.mdeath_cover ,                            "
               "      a.mdamage_cover, a.mdeduct,a.mins_premium, a.mpure_prem,       "
               "      'M', 100, a.qserial, a.pcommission, a.mcommission, a.pagent,   "
               "      a.magent,a.pdiscount,a.mdiscount,b.drate_ym,a.mprem,b.iproduct,"
               "      b.ipaid_base, a.qday, a.mexpense,a.mexp_disc,%ld, b.provision, "
               "      b.irate,b.adjust_rate,b.psex_age,a.mdrunk_prem, a.mdrunk_pure_prem,"
               "      a.mviolate_prem,a.mviolate_pure_prem ,a.mins_premium_n,        "
               "      a.mpure_prem_n ,a.mprem_n ,b.safe_rate,b.manage_rate,b.educated_rate,"
               "      b.deviation_rate, b.pextra_charge,b.pbusiness ,b.pshipping     "
               " FROM ply_ins_type_bak a, ply_ins_type_bak b                         "
               " WHERE a.ipolicy  = b.ipolicy and a.iins_type = b.iins_type         "
               "   AND a.iendorse = '%s'      and b.iendorse  = '%s'",
               sSql,temp1, iedr_type2, edrins_qcount, v_iendorse, iedr_next);        

     }

     printf("stmt[%s]\n", stmt);
     $PREPARE eins2 FROM $stmt;
     $EXECUTE eins2;


     /***** �u�@�t�@�����C���v�ت����O���F���̷s�O��A�G�̷s�O���Ƥ������� ********/
     /* [ply_ins_type] �H ply_ins_type_bak ����ƹ� ply_ins_type ��ƶi��update
     stmt[0] = '\0';
     sprintf_s(stmt, sizeof stmt,
               "MERGE Into ply_ins_type p \
                USING (SELECT a.*,nvl(b.iproduct,a.iproduct) AS iproduct_edr \
                         FROM ply_ins_type_bak a, outer edr_ins_type b \
                        WHERE a.iendorse = b.iendorse And a.iendorse = '%s' \
                         And a.iins_type = b.iins_type ) k \
                   ON ( p.ipolicy = k.ipolicy And p.iins_type = k.iins_type)   \
                 WHEN MATCHED THEN                      \
                      UPDATE SET                        \
                         p.minjured_cover     = p.minjured_cover     + k.minjured_cover    , \
                         p.mdeath_cover       = p.mdeath_cover       + k.mdeath_cover      , \
                         p.mdamage_cover      = p.mdamage_cover      + k.mdamage_cover     , \
                         p.mdeduct            = p.mdeduct            + k.mdeduct           , \
                         p.mins_premium       = p.mins_premium       + k.mins_premium      , \
                         p.mpure_prem         = p.mpure_prem         + k.mpure_prem        , \
                         p.pcommission        = p.pcommission        + k.pcommission       , \
                         p.mcommission        = p.mcommission        + k.mcommission       , \
                         p.pagent             = p.pagent             + k.pagent            , \
                         p.magent             = p.magent             + k.magent            , \
                         p.pdiscount          = p.pdiscount          + k.pdiscount         , \
                         p.mdiscount          = p.mdiscount          + k.mdiscount         , \
                         p.mprem              = p.mprem              + k.mprem             , \
                         p.qday               = p.qday               + k.qday              , \
                         p.mexpense           = p.mexpense           + k.mexpense          , \
                         p.mexp_disc          = p.mexp_disc          + k.mexp_disc         , \
                         p.mdrunk_prem        = p.mdrunk_prem        + k.mdrunk_prem       , \
                         p.mdrunk_pure_prem   = p.mdrunk_pure_prem   + k.mdrunk_pure_prem  , \
                         p.mviolate_prem      = p.mviolate_prem      + k.mviolate_prem     , \
                         p.mviolate_pure_prem = p.mviolate_pure_prem + k.mviolate_pure_prem, \
                         p.mins_premium_n     = p.mins_premium_n     + k.mins_premium_n    , \
                         p.mpure_prem_n       = p.mpure_prem_n       + k.mpure_prem_n      , \
                         p.mprem_n            = p.mprem_n            + k.mprem_n           , \
                         p.iproduct           = k.iproduct_edr  , \
                         p.provision          = k.provision     , \
                         p.ipaid_base         = k.ipaid_base    , \
                         p.psex_age           = k.psex_age      , \
                         p.iendorse           = '%s' ", 
          iedr_next, temp1);
            
     printf("stmt[%s]\n", stmt);
     $PREPARE pins2 FROM $stmt;
     $EXECUTE pins2;
     */



     
     /****  �B�z�ˮ`�I���I��   ****/

     /* v_iendorse �w�g�O�̫�@�����A�ϥη��U�̷s�O���ƨӲ���"�D���B�B�O�O�������" */
     sSql[0] = '\0';
     strcpy(sSql, " iendorse, iins_type, iinsurant, iedr_type, ninsurant, dbirth,      "
                  " ainsurant, iins_scope, icareer, medrins_amt, fcal_way, pcal,       "
                  " medrins_prem, medrpure_prem, pcommission,                          "
                  " medr_commission, pagent, medr_agent, pdiscount,                    "
                  " medr_discount, dendorse, napplicant, relation_appl,                "
                  " nbeneficiary,relation_bene,tbenef, abenef_zip, abenef,             "
                  " medr_daily_pay, medr_mr_ins_prem , medr_mr_pure_prem ");   
     trim_tail_white(sSql);

     stmt[0] = '\0';
     if (strlen(trim(iedr_next))==0) 
     {
          sprintf_s(stmt, sizeof stmt,
              "INSERT INTO ca_pa_edr (%s) "
              " SELECT '%s',a.iins_type,b.iinsurant,'%s',b.ninsurant,b.dbirth,          "
              "      b.ainsurant, b.iins_scope,b.icareer, a.mins_amt, 'M',100,          "
              "      a.mins_premium,a.mpure_prem, a.pcommission,a.mcommission,          "
              "      a.pagent, a.magent,a.pdiscount, a.mdiscount, '', b.napplicant,     "
              "      b.relation_appl,b.nbeneficiary, b.relation_bene, b.tbenef,         "
              "      b.abenef_zip,b.abenef,a.daily_pay,a.mr_ins_prem,a.mr_pure_prem     "
              " FROM ca_pa_ply_bak a , ca_pa_ply b                                      "
              " WHERE a.ipolicy  = b.ipolicy and a.iins_type = b.iins_type              "
              "   AND a.iendorse = '%s'",
               sSql,temp1, iedr_type2, v_iendorse );   
     }
     else
     { /* �ϥ� v_iendorse ���U�@�i���iedr_next��bak��ƨӲ���"�D���B�B�O�O�������" */

          sprintf_s(stmt, sizeof stmt,
              "INSERT INTO ca_pa_edr (%s) "
              " SELECT '%s',a.iins_type,b.iinsurant,'%s',b.ninsurant,b.dbirth,          "
              "      b.ainsurant, b.iins_scope,b.icareer, a.mins_amt, 'M',100,          "
              "      a.mins_premium,a.mpure_prem, a.pcommission,a.mcommission,          "
              "      a.pagent, a.magent,a.pdiscount, a.mdiscount, '', b.napplicant,     "
              "      b.relation_appl,b.nbeneficiary, b.relation_bene, b.tbenef,         "
              "      b.abenef_zip,b.abenef,a.daily_pay,a.mr_ins_prem,a.mr_pure_prem     "
              " FROM ca_pa_ply_bak a , ca_pa_ply_bak b                                  "
              " WHERE a.ipolicy  = b.ipolicy and a.iins_type = b.iins_type              "
              "   AND a.iendorse = '%s'      and b.iendorse  = '%s'",
               sSql,temp1, iedr_type2, v_iendorse, iedr_next );       
     }

     printf("stmt[%s]\n", stmt);
     $PREPARE caedr2 FROM $stmt;
     $EXECUTE caedr2;


     /***** �u�@�t�@�����C���v�ت����O���F���̷s�O��A�G�̷s�O���Ƥ������� ********/
     /*[ca_pa_ply] �H ca_pa_ply_bak ����ƹ� ca_pa_ply ��ƶi��update
     stmt[0] = '\0';
     sprintf_s(stmt, sizeof stmt,
               "MERGE Into ca_pa_ply p \
                USING (SELECT * FROM ca_pa_ply_bak WHERE iendorse = '%s') k \
                   ON ( p.ipolicy = k.ipolicy And p.iins_type = k.iins_type And \
                        p.iinsurant = k.iinsurant And p.iins_scope = k.iins_scope And p.icareer = k.icareer ) \
                 WHEN MATCHED THEN                         \
                      UPDATE SET                           \
                         p.mins_amt     = p.mins_amt     + k.mins_amt    , \
                         p.mins_premium = p.mins_premium + k.mins_premium, \
                         p.mpure_prem   = p.mpure_prem   + k.mpure_prem  , \
                         p.pcommission  = p.pcommission  + k.pcommission , \
                         p.mcommission  = p.mcommission  + k.mcommission , \
                         p.pagent       = p.pagent       + k.pagent      , \
                         p.magent       = p.magent       + k.magent      , \
                         p.pdiscount    = p.pdiscount    + k.pdiscount   , \
                         p.mdiscount    = p.mdiscount    + k.mdiscount   , \
                         p.daily_pay    = p.daily_pay    + k.daily_pay   , \
                         p.mr_ins_prem  = p.mr_ins_prem  + k.mr_ins_prem , \
                         p.mr_pure_prem = p.mr_pure_prem + k.mr_pure_prem, \
                         p.iendorse     = '%s' ",
            v_iendorse , temp1);

     printf("stmt[%s]\n", stmt);
     $PREPARE cains2 FROM $stmt;
     $EXECUTE cains2;
     */


     /* v_iendorse �w�g�O�̫�@�����A�ϥη��U�̷s�O���ƨӲ���"�D���B�B�O�O�������" */     
     /* ply_ins_cover_bak �S��"�D���B�B�O�O�������"(�O�B�N����� icover_type ���|����)�A�G�����B�z "�D���B�B�O�O�������"*/     
     stmt[0] = '\0';
     sprintf_s(stmt, sizeof stmt,
               "INSERT INTO edr_ins_cover "
               " (iendorse, iins_type, icover_type, mcover, mcover_prem, "
               "      mdiscount, mprem, mpure_prem )                     "
               " SELECT '%s', iins_type, icover_type,                    "
               "      mcover , mcover_prem, mdiscount,                   "
               "      mprem , mpure_prem                                 "
               " FROM ply_ins_cover_bak  "
               " WHERE iendorse = '%s'",
               temp1, v_iendorse);

     $PREPARE eins_cover2 FROM $stmt;
     $EXECUTE eins_cover2;


     /***** �u�@�t�@�����C���v�ت����O���F���̷s�O��A�G�̷s�O���Ƥ������� ********/
     /*[ply_ins_cover] �H ply_ins_cover_bak�Bply_ins_type_bak ����ƹ� ply_ins_cover ��ƶi��update
     stmt[0] = '\0';
     sprintf_s(stmt, sizeof stmt,
               "MERGE Into ply_ins_cover p \
                USING (SELECT b.ipolicy,a.* FROM ply_ins_cover_bak a,ply_ins_type_bak b \
                        WHERE a.iendorse = b.iendorse and a.iendorse = '%s' and b.ipolicy = '%s' and \
                              a.iins_type = b.iins_type) k \
                   ON ( p.ipolicy = k.ipolicy And p.iins_type = k.iins_type And \
                        p.icover_type = k.icover_type ) \
                 WHEN MATCHED THEN                      \
                      UPDATE SET                        \
                         p.mcover       = p.mcover      + k.mcover      , \
                         p.mcover_prem  = p.mcover_prem + k.mcover_prem , \
                         p.mdiscount    = p.mdiscount   + k.mdiscount   , \
                         p.mprem        = p.mprem       + k.mprem       , \
                         p.mpure_prem   = p.mpure_prem  + k.mpure_prem ",
            v_iendorse, s_ipolicy);

     printf("stmt[%s]\n", stmt);
     $PREPARE cains_cover2 FROM $stmt;
     $EXECUTE cains_cover2;
     */


     

     /*----------------------- �B�z�����D�� -----------------------*/
     
     /***** �u�@�t�@�����C���v�ت����O���F���̷s�O��A�G�̷s�O���Ƥ������� ********/
     /*[ply_relation] �H ply_relation_bak�Bedr_relation�Bendorsement ����ƹ� ply_relation ��ƶi��update
     stmt[0] = '\0';
     sprintf_s(stmt, sizeof stmt,
               "MERGE Into ply_relation p \
                USING (SELECT a.*,b.icar_type as icar_type_edr,c.qply_period as qply_period_edr  \
                              ,c.dply_begin as dply_begin_edr ,c.dply_end as dply_end_edr \
                         FROM ply_relation_bak a, edr_relation b, endorsement c \
                        WHERE a.iendorse = b.iendorse And a.iendorse = c.iendorse 
                          And a.iendorse = iendorse = '%s') k \
                   ON ( p.ipolicy = k.ipolicy )   \
                 WHEN MATCHED THEN                      \
                      UPDATE SET                        \
                         p.mdmg_prem      = p.mdmg_prem      + k.mdmg_prem      , \
                         p.mdmg_agent     = p.mdmg_agent     + k.mdmg_agent     , \
                         p.mdmg_commi     = p.mdmg_commi     + k.mdmg_commi     , \
                         p.mlia_prem      = p.mlia_prem      + k.mlia_prem      , \
                         p.mlia_agent     = p.mlia_agent     + k.mlia_agent     , \
                         p.mlia_commi     = p.mlia_commi     + k.mlia_commi     , \
                         p.mdmg_pure_prem = p.mdmg_pure_prem + k.mdmg_pure_prem , \
                         p.mlia_pure_prem = p.mlia_pure_prem + k.mlia_pure_prem , \
                         p.mready         = p.mready         + k.mready         , \
                         p.mstable        = p.mstable        + k.mstable        , \
                         p.mcompensation  = p.mcompensation  + k.mcompensation  , \
                         p.madjcom_prem   = p.madjcom_prem   + k.madjcom_prem   , \
                         p.mresearch      = p.mresearch      + k.mresearch      , \
                         p.minvest        = p.minvest        + k.minvest        , \
                         p.mbus_rule      = p.mbus_rule      + k.mbus_rule      , \
                         p.mbusiness      = p.mbusiness      + k.mbusiness      , \
                         p.mcapital       = p.mcapital       + k.mcapital       , \
                         p.maintain       = p.maintain       + k.maintain       , \
                         p.mdmg_discount  = p.mdmg_discount  + k.mdmg_discount  , \
                         p.mlia_discount  = p.mlia_discount  + k.mlia_discount  , \
                         p.icar_type      = k.icar_type_edr     , \
                         p.qply_period    = k.qply_period_edr   , \
                         p.dply_begin     = k.dply_begin_edr    , \
                         p.dply_end       = k.dply_end_edr      ", 
          v_iendorse );
     printf("stmt[%s]\n", stmt);
     $PREPARE ply2 FROM $stmt;
     $EXECUTE ply2;        
     */     


     /* v_iendorse �w�g�O�̫�@�����A�ϥη��U�̷s�O���ƨӲ���"�D���B�B�O�O�������" */
     sSql[0] = '\0';
     strcpy(sSql, " iendorse, fcard_class, ipolicy, icard, irelative_ply, irelative_edr, "
                  " fedr_class, fpay, ipay, iedr_field, dedr_begin, dedr_end,  "
                  " ipro_year, ibrand, icar_type, medrdmg_agent, medrdmg_commi,  "
                  " medrdmg_prem, medrdmg_pure_prem, medrlia_agent, medrlia_commi, "
                  " medrlia_prem, medrlia_pure_prem, ibig_comp, ibig_branch, ibig_office,  "
                  " ibig_sales, iresource, ibroker, iofficer, ileader, icorps, iedr_area,  "
                  " iedr_cashier, iedr_examiner, dedr_examine, dentry, dendorse, "
                  " fprint, itreaty, ibranch, iquota, icomp_in, ibranch_in, icomp_at,  "
                  " ibranch_at, medr_ready, medr_stable, medr_compensate, medr_adjcom, "
                  " medr_research, medr_invest, medr_bus_rule, medr_business,  "
                  " medr_capital, medr_maintain, fcomp_class, fcomp_class_last, fdiscount, medrdmg_disc, "
                  " medrlia_disc, iedr_return, icar_flag, terminate_rsn, qcount, "
                  " iofficer_prmt, iquota_prmt, ileader_prmt, irate_type,bzfrom,iroute_comm,icomm_obj,qprovision, "
                  " isecond_hand, icard_main, qdrunk_driving, isign, "
                  " feply, feedr, aemail_eply, tmobile_eply,ireg_no,dnotifyornot,isign_edr,dsign_edr,fsign_status_edr,"
                  " funder_chk_edr,iprog,qviolate,iendorse_dere,idere_type");
     trim_tail_white(sSql);

     stmt[0] = '\0';
     if (strlen(trim(iedr_next))==0) 
     {
          sprintf_s(stmt, sizeof stmt,
              "INSERT INTO edr_relation (%s) "
              " SELECT '%s', b.fcard_class, b.ipolicy, b.icard, b.irelative_ply, ' ', "
              "     '%s', '%s', ' ', ' ',b.dply_begin, b.dply_end ,  "
              "     b.ipro_year, b.ibrand, b.icar_type, a.mdmg_agent, a.mdmg_commi,  "
              "     a.mdmg_prem, a.mdmg_pure_prem, a.mlia_agent, a.mlia_commi, "
              "     a.mlia_prem, a.mlia_pure_prem, b.ibig_comp, b.ibig_branch, b.ibig_office, "
              "     b.ibig_sales, b.iresource, b.ibroker, b.iofficer, b.ileader, b.icorps, b.iarea, "
              "     '%s', '%s', %ld, %ld, '', "
              "     1, b.itreaty, b.ibranch, b.iquota, b.icomp_in, b.ibranch_in, b.icomp_at,  "
              "     b.ibranch_at, a.mready, a.mstable, a.mcompensation, a.madjcom_prem, "
              "     a.mresearch, a.minvest, a.mbus_rule, a.mbusiness, "
              "     a.mcapital, a.maintain, b.fcomp_class, b.fcomp_class_last, b.fdiscount, a.mdmg_discount,  "
              "     a.mlia_discount, '0', b.icar_flag, '0', %ld, b.iofficer_prmt, b.iquota_prmt, b.ileader_prmt, "
              "     b.irate_type,b.bzfrom,b.iroute_comm,b.icomm_obj, b.qprovision, b.isecond_hand, b.icard_main, "
              "     b.qdrunk_driving, b.isign,b.feply, (CASE WHEN b.fcard_class='2' THEN b.feply ELSE '0' END) AS feedr, "
              "     b.aemail_eply, b.tmobile_eply, b.ireg_no,b.dnotifyornot,'system',today,40,'N', '%s' ,b.qviolate, '%s',' ' "
              "     FROM ply_relation_bak a, ply_relation b "
              " WHERE a.ipolicy = b.ipolicy "
              "   AND a.iendorse = '%s'  ",
                    sSql,temp1, fedr_class, fpay, sIedr_examiner, sIedr_examiner, dwritten, dwritten,
                    edrrel_qcount, v_iprog, v_iendorse, v_iendorse);

     }
     else
     { /* �ϥ� v_iendorse ���U�@�i���iedr_next��bak��ƨӲ���"�D���B�B�O�O�������" */

          sprintf_s(stmt, sizeof stmt,
               "INSERT INTO edr_relation (%s) "
               " SELECT '%s', b.fcard_class, b.ipolicy, b.icard, b.irelative_ply, ' ', "
               "     '%s', '%s', ' ', ' ',b.dply_begin, b.dply_end ,  "
               "     b.ipro_year, b.ibrand, b.icar_type, a.mdmg_agent, a.mdmg_commi,  "
               "     a.mdmg_prem, a.mdmg_pure_prem, a.mlia_agent, a.mlia_commi, "
               "     a.mlia_prem, a.mlia_pure_prem, b.ibig_comp, b.ibig_branch, b.ibig_office, "
               "     b.ibig_sales, b.iresource, b.ibroker, b.iofficer, b.ileader, b.icorps, b.iarea, "
               "     '%s', '%s', %ld, %ld, '', "
               "     1, b.itreaty, b.ibranch, b.iquota, b.icomp_in, b.ibranch_in, b.icomp_at,  "
               "     b.ibranch_at, a.mready, a.mstable, a.mcompensation, a.madjcom_prem, "
               "     a.mresearch, a.minvest, a.mbus_rule, a.mbusiness, "
               "     a.mcapital, a.maintain, b.fcomp_class, b.fcomp_class_last, b.fdiscount, a.mdmg_discount,  "
               "     a.mlia_discount, '0', b.icar_flag, '0', %ld, b.iofficer_prmt, b.iquota_prmt, b.ileader_prmt, "
               "     b.irate_type,b.bzfrom,b.iroute_comm,b.icomm_obj, b.qprovision, b.isecond_hand, b.icard_main, "
               "     b.qdrunk_driving, b.isign,b.feply, (CASE WHEN b.fcard_class='2' THEN b.feply ELSE '0' END) AS feedr, "
               "     b.aemail_eply, b.tmobile_eply, b.ireg_no,b.dnotifyornot,'system',today,40,'N', '%s' ,b.qviolate, '%s',' ' "
               "     FROM ply_relation_bak a, ply_relation_bak b "
               " WHERE a.ipolicy = b.ipolicy "
               "  AND a.iendorse = '%s' and b.iendorse = '%s' ",
                    sSql,temp1, fedr_class, fpay, sIedr_examiner, sIedr_examiner, dwritten, dwritten,
                    edrrel_qcount, v_iprog, v_iendorse, v_iendorse, iedr_next);
     }
     printf("stmt[%s]\n", stmt);
     $PREPARE edr2 FROM $stmt;
     $EXECUTE edr2;  
          
     /* v_iendorse �w�g�O�̫�@�����A�ϥη��U�̷s�O���ƨӲ���"�D���B�B�O�O�������" */
     sSql[0] = '\0';
     strcpy(sSql, " iendorse, qply_period, dply_begin, dply_end, fassured, iassured, "
                  " iassured_ext, nassured, ilicense, fsex, fmarriage, nuser, "
                  " ibenef, nbenef, aassured, aassured_zip, itel, apayment, apayment_zip, "
                  " iply_area, nbrand_abbr, ncar_abbr, fcar_note, qcylinder, iengine, ibody, "
                  " itag, mcar_price, nequipment, flimit, pdmg_align, pbrg_align, plia_align, "
                  " idmg_rate, pdmg_factor, ibrg_rate, pbrg_factor, qpt, fpt, psex_age, psex_age_damage, lia_class, "
                  " plia_acc, dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd, pdmg_acc, fhuman, fcomp_24, "
                  " iext_policy, qpro_month, mkilo_ply,mkilo_edr, irisk,irelative_ext, "
                  " napplicant, dbirth, dissue, "
                  " iextra_charge, gextra_charge, pextra_charge, "
                  " iquery_num_damage, iquery_num, mequipment,  "
                  " survey_num, bound_num, abnormal_num, iapplicant, iroute, qlia_acc_sum, qdmg_acc_sum, "
                  " fapplicant,fsex_appl,dbirth_appl,itel_appl,ndeputy_appl,nrelation_appl,ndeputy_assured,"
                  " iassured_cntry,iapplicant_cntry, nassured_cntry, napplicant_cntry, "
                  " foccup, noccup, applicant_foccup, applicant_noccup, iroute_accept,tmobile_appl , aemail_appl");
     trim_tail_white(sSql);

     stmt[0] = '\0';
     if (strlen(trim(iedr_next))==0) 
     {
          sprintf_s(stmt, sizeof stmt,
               "INSERT INTO endorsement (%s) "
               " SELECT '%s', c.qply_period, c.dply_begin, c.dply_end, "
               "      b.fassured, b.iassured, b.iassured_ext, b.nassured, "
               "      b.ilicense, b.fsex, b.fmarriage, b.nuser, "
               "      b.ibenef, b.nbenef, b.aassured, b.aassured_zip, b.itel, "
               "      b.apayment, b.apayment_zip, b.iply_area, b.nbrand_abbr, "
               "      b.ncar_abbr, b.fcar_note, b.qcylinder, b.iengine, b.ibody, "
               "      b.itag, b.mcar_price, b.nequipment, b.flimit, b.pdmg_align, "
               "      b.pbrg_align, b.plia_align, b.idmg_rate, b.pdmg_factor, "
               "      b.ibrg_rate, b.pbrg_factor, b.qpt, b.fpt, b.psex_age, b.psex_age_damage, "
               "      b.lia_class, b.plia_acc, b.dmg_acc_1st, b.dmg_acc_2nd, "
               "      b.dmg_acc_3rd, b.pdmg_acc, b.fhuman, b.fcomp_24, "
               "      b.iext_policy,b.qpro_month,b.mkilo_ply,b.mkilo_edr,b.irisk,b.irelative_ext, "
               "      b.napplicant, b.dbirth, b.dissue, "
               "      b.iextra_charge, b.gextra_charge, b.pextra_charge, "
               "      b.iquery_num_damage, b.iquery_num, b.mequipment, "
               "      b.survey_num, b.bound_num, b.abnormal_num, b.iapplicant,b.iroute, b.qlia_acc_sum, b.qdmg_acc_sum, "
               "      b.fapplicant,b.fsex_appl,b.dbirth_appl,b.itel_appl,b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured,"
               "      CASE WHEN b.iassured_cntry='' THEN '8' ELSE b.iassured_cntry END, "
               "      CASE WHEN b.iapplicant_cntry='' THEN '8' ELSE b.iapplicant_cntry END, b.nassured_cntry, b.napplicant_cntry, "
               "      b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup, b.iroute_accept ,b.tmobile_appl , b.aemail_appl "
               " FROM policy_bak a, policy b, ply_relation c "
               " WHERE a.ipolicy = b.ipolicy AND a.ipolicy = c.ipolicy "
               "   AND a.iendorse = '%s' ", 
                 sSql,temp1, v_iendorse);

     }
     else
     { /* �ϥ� v_iendorse ���U�@�i���iedr_next��bak��ƨӲ���"�D���B�B�O�O�������" */

          sprintf_s(stmt, sizeof stmt,
               "INSERT INTO endorsement (%s) "
               " SELECT '%s', c.qply_period, c.dply_begin, c.dply_end, "
               "      b.fassured, b.iassured, b.iassured_ext, b.nassured, "
               "      b.ilicense, b.fsex, b.fmarriage, b.nuser, "
               "      b.ibenef, b.nbenef, b.aassured, b.aassured_zip, b.itel, "
               "      b.apayment, b.apayment_zip, b.iply_area, b.nbrand_abbr, "
               "      b.ncar_abbr, b.fcar_note, b.qcylinder, b.iengine, b.ibody, "
               "      b.itag, b.mcar_price, b.nequipment, b.flimit, b.pdmg_align, "
               "      b.pbrg_align, b.plia_align, b.idmg_rate, b.pdmg_factor, "
               "      b.ibrg_rate, b.pbrg_factor, b.qpt, b.fpt, b.psex_age, b.psex_age_damage, "
               "      b.lia_class, b.plia_acc, b.dmg_acc_1st, b.dmg_acc_2nd, "
               "      b.dmg_acc_3rd, b.pdmg_acc, b.fhuman, b.fcomp_24, "
               "      b.iext_policy,b.qpro_month,b.mkilo_ply,b.mkilo_edr,b.irisk,b.irelative_ext, "
               "      b.napplicant, b.dbirth, b.dissue, "
               "      b.iextra_charge, b.gextra_charge, b.pextra_charge, "
               "      b.iquery_num_damage, b.iquery_num, b.mequipment, "
               "      b.survey_num, b.bound_num, b.abnormal_num, b.iapplicant,b.iroute, b.qlia_acc_sum, b.qdmg_acc_sum, "
               "      b.fapplicant,b.fsex_appl,b.dbirth_appl,b.itel_appl,b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured,"
               "      CASE WHEN b.iassured_cntry='' THEN '8' ELSE b.iassured_cntry END, "
               "      CASE WHEN b.iapplicant_cntry='' THEN '8' ELSE b.iapplicant_cntry END, b.nassured_cntry, b.napplicant_cntry, "
               "      b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup, b.iroute_accept ,b.tmobile_appl , b.aemail_appl "
               " FROM policy_bak a, policy_bak b, ply_relation_bak c    "
               " WHERE a.ipolicy  = b.ipolicy AND a.ipolicy = c.ipolicy "
               "   AND b.iendorse = c.iendorse "
               "   AND a.iendorse = '%s' and  b.iendorse = '%s' ", 
                 sSql,temp1, v_iendorse, iedr_next);
     }
     printf("stmt[%s]\n", stmt);
     $PREPARE endor2 FROM $stmt;
     $EXECUTE endor2;  

     rc = insert_cm_pre_receive_edr(temp1, s_ipolicy, v_iprog, tmp_sMsg);
     if (rc != M_CM_OK)
     {     
          return rc;
     }

     /**** END �򥻸���ɥ��� ****/

     /* check �t���D�ɩ��Ӫ��B�O�_�@�P */
     medrins_prem = medr_commission = medr_agent = 0;
     $SELECT SUM(medrins_prem), SUM(medr_commission), SUM(medr_agent) 
        INTO $medrins_prem, $medr_commission, $medr_agent 
        FROM edr_ins_type 
       WHERE iendorse = $temp;

     $SELECT medrlia_prem + medrdmg_prem, medrlia_commi + medrdmg_commi, medrlia_agent + medrdmg_agent 
        INTO $mins_premium, $mcommission, $magent 
        FROM edr_relation 
       WHERE iendorse = $temp;

     printf("negative iendorse[%s]\n", temp);
     printf("medrins_prem    [%d] mins_premium[%d]\n", medrins_prem, mins_premium);
     printf("medr_commission [%d] mcommission [%d]\n", medr_commission, mcommission);
     printf("medr_agent      [%d] magent      [%d]\n", medr_agent, magent);

     if ((medrins_prem != mins_premium)||(medr_commission != mcommission)||(medr_agent != magent))
     {
         return M_CA_EDR_PREM_NOT_EQUAL;
     }

     /* check �����D�ɩ��Ӫ��B�O�_�@�P */
     medrins_prem = medr_commission = medr_agent = 0;
     $SELECT SUM(medrins_prem), SUM(medr_commission), SUM(medr_agent) 
        INTO $medrins_prem, $medr_commission, $medr_agent 
        FROM edr_ins_type 
       WHERE iendorse = $temp1;

     $SELECT medrlia_prem + medrdmg_prem, medrlia_commi + medrdmg_commi, medrlia_agent + medrdmg_agent 
        INTO $mins_premium, $mcommission, $magent 
        FROM edr_relation 
       WHERE iendorse = $temp1;

     printf("iendorse[%s]\n", temp1);
     printf("medrins_prem    [%d] mins_premium[%d]\n", medrins_prem, mins_premium);
     printf("medr_commission [%d] mcommission [%d]\n", medr_commission, mcommission);
     printf("medr_agent      [%d] magent      [%d]\n", medr_agent, magent);

     if ((medrins_prem != mins_premium)||(medr_commission != mcommission)||(medr_agent != magent))
     {
         return M_CA_EDR_PREM_NOT_EQUAL;
     }


     $select a.iendorse, a.iedr_type, a.iins_type, a.medrins_prem, sum(b.medrins_prem) 
        from edr_ins_type a, ca_pa_edr b 
       where a.iendorse = b.iendorse and a.iins_type = b.iins_type and a.iendorse = $temp 
       group by 1, 2, 3, 4 
      having a.medrins_prem<> sum(b.medrins_prem);

     printf("SQLCODE[%d]\n", SQLCODE);
     if (SQLCODE != SQLNOTFOUND)
     {
         return M_CA_EDR_PREM_NOT_EQUAL;
     }

     printf("SQLCODE[%d]\n", SQLCODE);
     $select a.iendorse, a.iedr_type, a.iins_type, a.medrins_prem, sum(b.medrins_prem) 
        from edr_ins_type a, ca_pa_edr b 
       where a.iendorse = b.iendorse and a.iins_type = b.iins_type and a.iendorse = $temp1 
       group by 1, 2, 3, 4 
      having a.medrins_prem<> sum(b.medrins_prem);

     if (SQLCODE != SQLNOTFOUND)
     {
         return M_CA_EDR_PREM_NOT_EQUAL;
     }

     /**** END �D�ɥ��� ****/

     /*****  ���������@�~   *****/

     strcpy(iendorse1_out, temp);
     strcpy(iendorse2_out, temp1);

     strcpy(v_sMsg, tmp_sMsg);
     printf("iendorse1_out=[%s]\n", iendorse1_out); 
     printf("iendorse2_out=[%s]\n", iendorse2_out); 
     printf("end insert_edr_ifrs()\n");      

     return M_CM_OK;

errexit:

  sprintf_s(tmp_sMsg, sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy(v_sMsg, tmp_sMsg);
  end_insert_edr_ifrs( v_sMsg);
  return SQLCODE;
}


void end_insert_edr_ifrs( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_edr_paydate function");
  puts("******************************");
  puts("");
}

