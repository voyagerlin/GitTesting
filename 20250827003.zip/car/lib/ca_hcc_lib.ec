#include <stdio.h>
#include <math.h>
#include <string.h>
#include "api_xsrv.h"
#include "globdata.h"
#include "commsgs.h"
#include "safeclib.h"
$include sqltypes;
$include "ca_hcc.h";

/* --------------------------------------------------------------------------------------------------------------

  �� HCC�֫O�ҫ��ظm���̾ڤι�H����p�U (������ѩI�s�ݧP�_�B�z)�G
    1.�O��ʽ�G�۵M�H
    2.���ءG 03�B04�B22�B01�B02�B32�B34
    3.�q���G���q��
    4.�I�ءG���I�� (���ư��i�D����q��(JB)����j���I�j)

  �� HCC�֫O�]�l ca_hcc_factor.itype �w�q�G
    0:���ůż�
    1:�ʧO�αB��
    2:�~��
    3:�e���~�����I�߮ץB�ߴڪ��B��0���߮ץ��
    4:�e���~�ĤT�H�d���I���߮ץ��
    5:�e���~���F�d�p�����߮ץ��
    6:��O�~�� (����)
    7:���إN�� (����)
    8:����
    9:��O���� (����)
    10:��O���d
    11:��O�ѵs
    12:���[�I�ƶq
    13:�a�ϥN��
    14:���ؤΫO��
    15:�O�_�[�O�ˮ`�I
    16:��O�ӫ~�`��
    17:�e5�~�߮ץ��
    18:�L�h2�~�O�_���b�s�w��O�L�T���I
    19:�����ݩ�
    20:��O�D������[�I�Ӽ�
    21:��O������[�I�Ӽ�
    
   -------------------------------------------------------------------------------------------------------------
  
  [126�O�v(�t)�H�e�I�s�ϥ�]
  �� get_ca_hcc_level() �ѼơG   
    [�ǤJ] stuHcc_fac�A�ǤJ�O�������T�ι�ڧ�O�I�زզX(��) ( �W��� ca_hcc.h )
    [�ǥX] stuHcc_lvl ( �W��� ca_hcc.h )
      1. ���ůż� intQlevel[INS_SETS] �Y�� stuHcc_lvl.qlevel[INS_SETS] (�ت��ȳ�¬��F��K�ֳt���o"���ůż�" )
      2. �Y "���ůż�" = -1 �A�N���ӧ�O�զX�� "�D�q��(JB*)����j"�Alib �|���L���B�z�A�����|�]���Ӧ^�ǿ��~�A�ӷ|�~��B�z��L��O�զX
      3. �^�ǭȤ�strMsg�G      
         �^�ǭ� = M_CM_OK �N���Ө���O��/������blib���B�z�S���o�Ϳ��~
         �^�ǭ� �� M_CM_OK �AstrMsg �N�x�s���~�T��      


  [127�O�v(�t)�H��I�s�ϥ�]
  �� get_ca_hcc_level_cartype() �ѼơG
    [�ǤJ] stuHcc_fac�A�ǤJ�O�������T�ι�ڧ�O�I�زզX(��) ( �W��� ca_hcc.h )
    [�ǥX] stuHcc_lvl ( �W��� ca_hcc.h )
         
         
----------------------------------------------------------------------------------------------------------------*/

#define DMG_SIZE 10 /* ����D�I�Ӽ�(�}�C�j�p) */
#define LIA_SIZE 13 /* ���d�D�I�Ӽ�(�}�C�j�p) */
#define BRG_SIZE 5 /* �ѵs�D�I�Ӽ�(�}�C�j�p) */


long get_ca_hcc_level(intQlevel,
                      stuHcc_fac,
                      stuHcc_lvl,
                      strMsg)
$int    *intQlevel;
$struct CA_HCC_FACTOR stuHcc_fac;
$struct CA_HCC_LEVEL *stuHcc_lvl;
$char   *strMsg;
{

    static char sDMG_MAIN_01[DMG_SIZE][INSURANCE_TYPE] = {{"01"}, {"05"}, {"09"},  {"86"},  {"110"}, {"181"}, {"198"}, {"201"}, {"205"}, {"209"}}; /*����D�I*/
    static char sLIA_MAIN_31[LIA_SIZE][INSURANCE_TYPE] = {{"31"}, {"32"}, {"113"}, {"114"}, {"133"}, {"134"}, {"149"}, {"255"}, {"266"}, {"302"}, {"231"}, {"232"}, {"249"}}; /*�d���D�I*/
    static char sBRG_MAIN_11[BRG_SIZE][INSURANCE_TYPE] = {{"11"}, {"20"}, {"111"}, {"129"}, {"211"}};                            /*�ѵs�D�I*/

    $char stmt[8000], sTmp[200], v_sNumber[21];
    $char sRoute_main[INS_SETS][21];                                /* JB�G�q�ӥB��j;  ALL:���q�����j+���γ���N */
    $char fLia_31[INS_SETS][2], fBrg_11[INS_SETS][2], fDmg_01[INS_SETS][2], fIns_58[INS_SETS][2];
    $char sCartype_year[5];         /* ���ؤΫO�� */
    $long v_dPlyBeginDate_main[INS_SETS], v_dFirstPlyDate_main[INS_SETS];    
    $long ltmp, rc;
    $double dblAge[INS_SETS], dblTmp;
    $int itype;                     /* �֫O�]�l���O */
    $int iExt_Ins_Count[INS_SETS];  /* ���[�I�ƶq   */
    int i, k, iCount[INS_SETS], iMainCount[INS_SETS], Act_Ins_Sets; /* Act_Ins_Sets�G��ڶǤJ����O�զX�� */
    
    $WHENEVER SQLERROR GOTO errexit;

    TRACE("\n\n***************************************\n");
    printf("begin get_ca_hcc_level() function\n");    
    strMsg[0] = '\0';    
    itype = -1;    
    /* --------------------------------------  ���o��ڶǤJ����O�զX��   ------------------------------------*/

    Act_Ins_Sets = 0;    
    for (i = Act_Ins_Sets; i < INS_SETS; i++)
    {

        IcurrHccIns = IfirstHccIns;

       while (IcurrHccIns)
        {
            if (i == IcurrHccIns->iIns_Set)
            {
                Act_Ins_Sets++;
                break;
            }
            IcurrHccIns = IcurrHccIns->next;
        }
    }
    if (Act_Ins_Sets == 0)
    {
        strcat(strMsg, "�L�I�ا�O�զX;\n");
        goto errexit;
    }

    printf("=> ��ڧ�O�զX��(Act_Ins_Sets)=[%d]\n\n", Act_Ins_Sets);

    /* -------------------------------   �˵��ǤJ�Ѽ� stuHcc_fac (for debug)  ---------------------------*/


    TRACE("stuHcc_fac.sNumber                 = [%s]\n", stuHcc_fac.sNumber);
    TRACE("stuHcc_fac.sRoute                  = [%s]\n", stuHcc_fac.sRoute);
    TRACE("stuHcc_fac.sSex                    = [%s]\n", stuHcc_fac.sSex);
    TRACE("stuHcc_fac.sMarriage               = [%s]\n", stuHcc_fac.sMarriage);
    TRACE("stuHcc_fac.iPlyPeriod              = [%d]\n", stuHcc_fac.iPlyPeriod);
    TRACE("stuHcc_fac.sCarType                = [%s]\n", stuHcc_fac.sCarType);
    TRACE("stuHcc_fac.sZipCode                = [%s]\n", stuHcc_fac.sZipCode);
    TRACE("stuHcc_fac.sTrade                  = [%s]\n", stuHcc_fac.sTrade);
    TRACE("stuHcc_fac.iDamageAccidentSum5year = [%d]\n", stuHcc_fac.iDamageAccidentSum5year);
    TRACE("stuHcc_fac.iLiaAccidentSum5year    = [%d]\n", stuHcc_fac.iLiaAccidentSum5year);
    TRACE("stuHcc_fac.iDutyAccidentSum5year   = [%d]\n", stuHcc_fac.iDutyAccidentSum5year);
    

    for (i = 0; i < Act_Ins_Sets; i++)
    {
        if (risnull(CLONGTYPE, &stuHcc_fac.dPlyBeginDate_C1[i]) == 0)
        {
            TRACE("�զX[%d]�GstuHcc_fac.dPlyBeginDate_C1 = [%ld]=>[%s]\n", i, stuHcc_fac.dPlyBeginDate_C1[i], cm_edate_str(stuHcc_fac.dPlyBeginDate_C1[i]));
        }
        else
        {
            TRACE("�զX[%d]�GstuHcc_fac.dPlyBeginDate_C1 = [null]\n", i);
        }
        if (risnull(CLONGTYPE, &stuHcc_fac.dPlyBeginDate_C2[i]) == 0)
        {
            TRACE("�զX[%d]�GstuHcc_fac.dPlyBeginDate_C2 = [%ld]=>[%s]\n", i, stuHcc_fac.dPlyBeginDate_C2[i], cm_edate_str(stuHcc_fac.dPlyBeginDate_C2[i]));
        }
        else
        {
            TRACE("�զX[%d]�GstuHcc_fac.dPlyBeginDate_C2 = [null]\n", i);
        }
    }

    if (risnull(CLONGTYPE, &stuHcc_fac.dFirstPlyDate_C1) == 0)
    {
        TRACE("stuHcc_fac.dFirstPlyDate_C1 = [%ld]=>[%s]\n", stuHcc_fac.dFirstPlyDate_C1, cm_edate_str(stuHcc_fac.dFirstPlyDate_C1));
    }
    else
    {
        TRACE("stuHcc_fac.dFirstPlyDate_C1 = [null]\n");
    }

    if (risnull(CLONGTYPE, &stuHcc_fac.dFirstPlyDate_C2) == 0)
    {
        TRACE("stuHcc_fac.dFirstPlyDate_C2 = [%ld]=>[%s]\n", stuHcc_fac.dFirstPlyDate_C2, cm_edate_str(stuHcc_fac.dFirstPlyDate_C2));
    }
    else
    {
        TRACE("stuHcc_fac.dFirstPlyDate_C2 = [null]\n");
    }

    if (risnull(CLONGTYPE, &stuHcc_fac.dBirthDate) == 0)
    {
        TRACE("stuHcc_fac.dBirthDate = [%ld]=>[%s]\n", stuHcc_fac.dBirthDate, cm_edate_str(stuHcc_fac.dBirthDate));
    }
    else
    {
        TRACE("stuHcc_fac.dBirthDate = [null]\n");
    }

    IcurrHccIns = IfirstHccIns;
    while (IcurrHccIns)
    {
        TRACE("=> �զX[%d]�GstuHcc_fac.sInsType = [%s]\n", IcurrHccIns->iIns_Set, IcurrHccIns->sIns_type);
        IcurrHccIns = IcurrHccIns->next;
    }


    /* -----------------------------------   ���ˮֶǤJ�Ѽ� stuHcc_fac  -------------------------------*/

    strcpy(v_sNumber, rtrim(stuHcc_fac.sNumber));

    if (strlen(trim(stuHcc_fac.sRoute)) == 0)
    {
        strcat(strMsg, " sRoute ���i�ť�;");
    }

    /* sNumber(�渹) ���v�T�żƭp��A�G�i�ťաC�����ǤJ�渹�A�^�Ǥ����~�T�����~�|��ܳ渹 */
    if (strlen(trim(stuHcc_fac.sSex)) == 0)
    {
        strcat(strMsg, " sSex ���i�ť�;");
    }
    /*if (strlen(trim(stuHcc_fac.sMarriage))== 0)         {  strcat(strMsg," sMarriage ���i�ť�;");   } */
    if (risnull(CLONGTYPE, &stuHcc_fac.dBirthDate) == 1)
    {
        strcat(strMsg, " dBirthDate ���i�ť�;");
    }
    if (strlen(trim(stuHcc_fac.sCarType)) == 0)
    {
        strcat(strMsg, " sCarType ���i�ť�;");
    }
    /*if (strlen(trim(stuHcc_fac.sZipCode))== 0)          {  strcat(strMsg," sZipCode ���i�ť�;");    }*/
    if (stuHcc_fac.iPlyPeriod <= 0)
    {
        strcat(strMsg, " iPlyPeriod �ƭȦ��~;");
    }   
    if (strlen(trim(stuHcc_fac.sTrade)) == 0)
    {
        strcat(strMsg, " sTrade ���i�ť�;");
    }
    if (strlen(trim(stuHcc_fac.sExistPlyDetail)) == 0)
    {
        strcat(strMsg, " sExistPlyDetail ���i�ť�;");
    }    
    rtrim_space(strMsg);
    if (strlen(strMsg) > 0)
    {
        sprintf_s(strMsg, 250,"get_ca_hcc_level() Err�G%s(�渹[%s])", strMsg, v_sNumber);
        goto errexit;
    }

    /* --------------------------------    PREPARE SQL   ----------------------------------*/

    /* �O�v�ͮĤ�(ca_rate_renew�@�ߧ���N�I) */
    sprintf_s(stmt, sizeof stmt,"SELECT drate FROM ca_rate_date "
                                "  WHERE itable = 'ca_hcc_factor' "
                                "    AND icode in (SELECT icode FROM ca_rate_renew "
                                "                   WHERE ? BETWEEN  deffect_bgn AND deffect_end "
                                "                     AND fcard_class = '2')");
    $PREPARE preDrate FROM $stmt;

    sprintf_s(stmt, sizeof stmt, "SELECT pfactor FROM ca_hcc_factor "
                                 "   WHERE drate = ? "
                                 "     AND iroute_main = ? "
                                 "     AND itype = ? "
                                 "     AND ifactor_bgn = ? ");
    $PREPARE preFactor1 FROM $stmt;

    sprintf_s(stmt, sizeof stmt, "SELECT pfactor FROM ca_hcc_factor "
                                 "   WHERE drate = ? "
                                 "     AND iroute_main = ? "
                                 "     AND itype = ? "
                                 "     AND (? >= ifactor_bgn And ? < ifactor_end)");
    $PREPARE preFactor2 FROM $stmt;

    /* ---------------------------------------- �B�z�U��O�զX ----------------------------------------*/

    for (i = 0; i < Act_Ins_Sets; i++)
    {

        /* -----------------------------------    ��l��   ------------------------------------*/

        TRACE("\n====================================== ��O�զX[%d] ======================================\n", i);
      
        strcpy(sRoute_main[i], " ");
        rsetnull(CLONGTYPE, (char *)&v_dPlyBeginDate_main[i]);
        rsetnull(CLONGTYPE, (char *)&v_dFirstPlyDate_main[i]);

        intQlevel[i] = 0;
        stuHcc_lvl->qlevel[i] = 0;
        stuHcc_lvl->pscore[i] = 0.0;

        strcpy(stuHcc_lvl->iroute_main[i], " ");
        rsetnull(CLONGTYPE, (char *)&stuHcc_lvl->drate[i]);

        strcpy(stuHcc_lvl->i1_sex_marriage_value[i], " ");
        stuHcc_lvl->p1_sex_marriage_factor[i] = 0.0;

        stuHcc_lvl->q2_age_value[i] = 0;
        stuHcc_lvl->p2_age_factor[i] = 0.0;

        stuHcc_lvl->q3_dmg_acc_sum_5y_value[i] = 0;
        stuHcc_lvl->p3_dmg_acc_sum_5y_factor[i] = 0.0;

        stuHcc_lvl->q4_lia_acc_sum_5y_value[i] = 0;
        stuHcc_lvl->p4_lia_acc_sum_5y_factor[i] = 0.0;

        stuHcc_lvl->q5_duty_acc_sum_5y_value[i] = 0;
        stuHcc_lvl->p5_duty_acc_sum_5y_factor[i] = 0.0;

        stuHcc_lvl->q8_car_age_value[i] = 0;
        stuHcc_lvl->p8_car_age_factor[i] = 0.0;

        strcpy(stuHcc_lvl->f10_lia_value[i], " ");
        stuHcc_lvl->p10_lia_factor[i] = 0.0;

        strcpy(stuHcc_lvl->f11_brg_value[i], " ");
        stuHcc_lvl->p11_brg_factor[i] = 0.0;

        stuHcc_lvl->q12_ext_ins_sum_value[i] = 0;
        stuHcc_lvl->p12_ext_ins_sum_factor[i] = 0.0;

        strcpy(stuHcc_lvl->i13_ply_area_value[i], " ");
        stuHcc_lvl->p13_ply_area_factor[i] = 0.0;

        strcpy(stuHcc_lvl->i14_cartype_year_value[i], " ");
        stuHcc_lvl->p14_cartype_year_factor[i] = 0.0;

        /* ---------------  �ˮ� 21�I�� �P �j���I�ͮĤ� �O�_�@�P(�P�ɦ��ΦP�ɵL)  --------------- 
        iCount[i] = 0; 
        IcurrHccIns = IfirstHccIns;
        while( IcurrHccIns)
        {
            if (i == IcurrHccIns->iIns_Set)
            {
                printf("=> �զX[%d]�GstuHcc_fac.sInsType = [%s]\n",IcurrHccIns->iIns_Set,trim(IcurrHccIns->sIns_type));

                if (strcmp("21", trim(IcurrHccIns->sIns_type))==0) 
                {
                    iCount[i]++ ;
                }
            }
            IcurrHccIns = IcurrHccIns->next;
        }
        printf( "21 iCount[%d] = [%d]", i ,iCount[i]);
        if ( risnull(CLONGTYPE, &stuHcc_fac.dPlyBeginDate_C1[i])==( iCount[i]>0 ? 1:0 ) )
        {
            sprintf(strMsg,"get_ca_hcc_level() Err�G�j���I�ͮĤ�P21�I�ت��s�b���A���@�P(�渹[%s])(�զX[%d])",v_sNumber,i);
            goto errexit; 
        } 
        */

        /* ---------------  �P�_sRoute_main �� [JB]�q��+��j  �� [ALL]�����q(�j+���γ��)  ----------------*/

        strcpy(sRoute_main[i], "ALL");                                        /* ���w�]�� [ALL] �� */

        if (strncmp(stuHcc_fac.sRoute, "JB", 2) == 0)                         /* JB �q���N�� */
        {
            if (risnull(CLONGTYPE, &stuHcc_fac.dPlyBeginDate_C2[i]) == 1)     /* �L���N�I�ͮĤ�,������j */
            {
                if (risnull(CLONGTYPE, &stuHcc_fac.dPlyBeginDate_C1[i]) == 1) /* �]�L�j��ͮĤ� */
                {
                    sprintf_s(strMsg, 250,"get_ca_hcc_level()_1 Err�G�L�j��Υ��N�ͮĤ�(�渹[%s])(�զX[%d])", v_sNumber, 1);
                    goto errexit;
                }
                else
                {
                    strcpy(sRoute_main[i], "JB");                             /* JB�q���N�� �B ��j => [JB] �� */
                }
            }
        }
        else                                                                  
        {
            if (risnull(CLONGTYPE, &stuHcc_fac.dPlyBeginDate_C2[i]) == 1)     /* �L���N�I�ͮĤ�,������j */
            {
                if (risnull(CLONGTYPE, &stuHcc_fac.dPlyBeginDate_C1[i]) == 1) /* �]�L�j��ͮĤ� */
                {
                    sprintf_s(strMsg, 250,"get_ca_hcc_level()_2 Err�G�L�j��Υ��N�ͮĤ�(�渹[%s])(�զX[%d])", v_sNumber, i);
                    goto errexit;
                }
                else
                {
                    /* ��j���DJB�q���G ���L�ӧ�O�զX���B�z, ����X intQlevel=-1 �ѫe�ݧP�_ */
                    intQlevel[i] = -1;
                    stuHcc_lvl->qlevel[i] = -1;
                    continue; /* �����_����A���U�@��O�զX */
                }
            }
        }

        strcpy(stuHcc_lvl->iroute_main[i], sRoute_main[i]);
        printf(" => �զX[%d]�GstuHcc_lvl->iroute_main = [%s]\n", i, stuHcc_lvl->iroute_main[i]);

        /* -------------------  �̿� [JB]�B[ALL] �������P�_  --------------------*/

        if (strncmp(sRoute_main[i], "JB", 2) == 0)
        {
            v_dPlyBeginDate_main[i] = stuHcc_fac.dPlyBeginDate_C1[i];
            v_dFirstPlyDate_main[i] = stuHcc_fac.dFirstPlyDate_C1;
        }
        else
        {
            v_dPlyBeginDate_main[i] = stuHcc_fac.dPlyBeginDate_C2[i];        /* �����N�I,�ͮĤ�H���N���D */
            v_dFirstPlyDate_main[i] = stuHcc_fac.dFirstPlyDate_C2;
        }

        TRACE(" -------------------  [���o�O�v�ͮĤ�]  --------------------\n");

        $EXECUTE preDrate INTO $stuHcc_lvl->drate[i] USING $v_dPlyBeginDate_main[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level() Err�G�䤣�� itable=ca_hcc_factor���O�v�ͮĤ�drate(�O�I�ͮĤ�[%s],�渹[%s](�զX[%d]))", cm_edate_str(v_dPlyBeginDate_main[i]), v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->drate = [%s]\n", i, cm_edate_str(stuHcc_lvl->drate[i]));

        /* =============================   �}�l�B�z HCC�֫O�]�l  ==================================== */

        /* ---------------  �i1:�ʧO�αB�áj----------------------------*/
        itype = 1;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);

        strcpy(stuHcc_lvl->i1_sex_marriage_value[i], ((stuHcc_fac.sSex[0] == '1' || stuHcc_fac.sSex[0] == 'M') ? "M" : "F"));

        if (strlen(trim(stuHcc_fac.sMarriage)) != 0)
        {
            strcat(stuHcc_lvl->i1_sex_marriage_value[i], trim(stuHcc_fac.sMarriage));
        }
        else /* �B�å�����*/
        {
            strcat(stuHcc_lvl->i1_sex_marriage_value[i], "0");
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->i1_sex_marriage_value = [%s]\n", i, stuHcc_lvl->i1_sex_marriage_value[i]);

        $EXECUTE preFactor1 INTO $stuHcc_lvl->p1_sex_marriage_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype, $stuHcc_lvl->i1_sex_marriage_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level() Err�G�䤣�� �ʧO�αB�ëY��(i1_sex_marriage_value[%s],�渹[%s](�զX[%d]))", stuHcc_lvl->i1_sex_marriage_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p1_sex_marriage_factor = [%f]\n", i, stuHcc_lvl->p1_sex_marriage_factor[i]);

        /* ----------------- �i2:�~�֡j----------------------------------*/
        itype = 2;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);

        dblAge[i] = 0.0;
        sTmp[0] = '\0';
        rc = get_age(stuHcc_fac.dBirthDate, v_dPlyBeginDate_main[i], &dblAge[i], sTmp);

        TRACE("=> �զX[%d]�Grc = [%ld],dblAge = [%f]\n", i, rc, dblAge[i]);

        if (rc != M_CM_OK)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level() Err�G%s,�渹[%s](�զX[%d]))", sTmp, v_sNumber, i);
            goto errexit;
        }
        stuHcc_lvl->q2_age_value[i] = (int)dblAge[i];

        TRACE(" => �զX[%d]�GstuHcc_lvl->q2_age_value = [%d]\n", i, stuHcc_lvl->q2_age_value[i]);

        $EXECUTE preFactor2 INTO $stuHcc_lvl->p2_age_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype,
            $stuHcc_lvl->q2_age_value[i], $stuHcc_lvl->q2_age_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level() Err�G�䤣�� �~�֫Y��(q2_age_value[%d],�渹[%s](�զX[%d]))", stuHcc_lvl->q2_age_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p2_age_factor = [%f]\n", i, stuHcc_lvl->p2_age_factor[i]);

        /* ---------------  �i3:�e���~�����I�߮ץB�ߴڪ��B��0���߮ץ�ơj------*/
        itype = 3;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);
        if (stuHcc_fac.sTrade[0] != 'Y')                      /* �S�d���T */
        {
            stuHcc_lvl->q3_dmg_acc_sum_5y_value[i] = 99;      /* �S�d���T =>  ifactor_bgn = 99 */ 
        }
        else
        {
            if (stuHcc_fac.sExistPlyDetail[0]  != 'Y')        /* ���T�L�ӫO����*/
            {
                stuHcc_lvl->q3_dmg_acc_sum_5y_value[i] = -1;  /* ���d���T,���L�ӫO���� =>  ifactor_bgn = -1 */ 
            }
            else
            {
                stuHcc_lvl->q3_dmg_acc_sum_5y_value[i] = stuHcc_fac.iDamageAccidentSum5year;
            } 
        } 

        TRACE(" => �զX[%d]�GstuHcc_lvl->q3_dmg_acc_sum_5y_value = [%d]\n", i, stuHcc_lvl->q3_dmg_acc_sum_5y_value[i]);

        $EXECUTE preFactor2 INTO $stuHcc_lvl->p3_dmg_acc_sum_5y_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype,
            $stuHcc_lvl->q3_dmg_acc_sum_5y_value[i], $stuHcc_lvl->q3_dmg_acc_sum_5y_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level() Err�G�䤣�� �e���~�����I�߮ץB�ߴڪ��B��0���߮ץ�ƫY��(q3_dmg_acc_sum_5y_value[%d],�渹[%s](�զX[%d]))", stuHcc_lvl->q3_dmg_acc_sum_5y_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p3_dmg_acc_sum_5y_factor = [%f]\n", i, stuHcc_lvl->p3_dmg_acc_sum_5y_factor[i]);

        /* ---------------  �i4:�e���~�ĤT�H�d���I���߮ץ�ơj----------------*/
        itype = 4;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);
        
        if (stuHcc_fac.sTrade[0] != 'Y')                      /* �S�d���T */
        {
            stuHcc_lvl->q4_lia_acc_sum_5y_value[i] = 99;      /* �S�d���T =>  ifactor_bgn = 99 */ 
        }
        else
        {
            if (stuHcc_fac.sExistPlyDetail[0]  != 'Y')        /* ���T�L�ӫO����*/
            {
                stuHcc_lvl->q4_lia_acc_sum_5y_value[i] = -1;  /* ���d���T,���L�ӫO���� =>  ifactor_bgn = -1 */ 
            }
            else
            {
                stuHcc_lvl->q4_lia_acc_sum_5y_value[i] = stuHcc_fac.iLiaAccidentSum5year;
            } 
        } 

        TRACE(" => �զX[%d]�GstuHcc_lvl->q4_lia_acc_sum_5y_value = [%d]\n", i, stuHcc_lvl->q4_lia_acc_sum_5y_value[i]);

        $EXECUTE preFactor2 INTO $stuHcc_lvl->p4_lia_acc_sum_5y_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype,
            $stuHcc_lvl->q4_lia_acc_sum_5y_value[i], $stuHcc_lvl->q4_lia_acc_sum_5y_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level() Err�G�䤣�� �e���~�ĤT�H�d���I���߮ץ�ƫY��(q4_lia_acc_sum_5y_value[%d],�渹[%s](�զX[%d]))", stuHcc_lvl->q4_lia_acc_sum_5y_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p4_lia_acc_sum_5y_factor = [%f]\n", i, stuHcc_lvl->p4_lia_acc_sum_5y_factor[i]);

        /* ---------------  �i5:�e���~���F�d���p�����߮ץ�ơj-----------------*/
        itype = 5;  

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);

        if (stuHcc_fac.sTrade[0] != 'Y')                      /* �S�d���T */
        {
            stuHcc_lvl->q5_duty_acc_sum_5y_value[i] = 99;      /* �S�d���T =>  ifactor_bgn = 99 */ 
        }
        else
        {
            if (stuHcc_fac.sExistPlyDetail[0]  != 'Y')        /* ���T�L�ӫO����*/
            {
                stuHcc_lvl->q5_duty_acc_sum_5y_value[i] = -1;  /* ���d���T,���L�ӫO���� =>  ifactor_bgn = -1 */ 
            }
            else
            {
                stuHcc_lvl->q5_duty_acc_sum_5y_value[i] = stuHcc_fac.iDutyAccidentSum5year;
            } 
        } 

        TRACE(" => �զX[%d]�GstuHcc_lvl->q5_duty_acc_sum_5y_value = [%d]\n", i, stuHcc_lvl->q5_duty_acc_sum_5y_value[i]);

        $EXECUTE preFactor2 INTO $stuHcc_lvl->p5_duty_acc_sum_5y_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype,
            $stuHcc_lvl->q5_duty_acc_sum_5y_value[i], $stuHcc_lvl->q5_duty_acc_sum_5y_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level() Err�G�䤣�� �e���~���F�d���p�����߮ץ�ƫY��(q5_duty_acc_sum_5y_value[%d],�渹[%s](�զX[%d]))", stuHcc_lvl->q5_duty_acc_sum_5y_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p5_duty_acc_sum_5y_factor = [%f]\n", i, stuHcc_lvl->p5_duty_acc_sum_5y_factor[i]);

        /* ---------------  �i8:���֡j------------------------------------*/
        itype = 8;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);

        if (risnull(CLONGTYPE, &v_dFirstPlyDate_main[i]) == 1)
        {
            if (stuHcc_fac.sTrade[0] != 'Y')                   /* �S�d���T */
            {
                stuHcc_lvl->q8_car_age_value[i] = 99;          /* [�S�d���T]=> [JB] : �Y�u�̦���O��-�j��v�L��, ifactor_bgn = 99; [ALL]: �Y�u�̦���O��-���N�v�L��, ifactor_bgn = 99 */ 
            }
            else
            {
                stuHcc_lvl->q8_car_age_value[i] = -1;          /* [���d���T]=> [JB] : �Y�u�̦���O��-�j��v�L��, ifactor_bgn = -1; [ALL]: �Y�u�̦���O��-���N�v�L��, ifactor_bgn = -1 */
            }
        }
        else
        {
            dblAge[i] = 0.0;
            sTmp[0] = '\0';
            rc = get_age(v_dFirstPlyDate_main[i], v_dPlyBeginDate_main[i], &dblAge[i], sTmp);
            TRACE("=> �զX[%d]�Grc = [%ld],dblAge = [%f]\n", i, rc, dblAge[i]);
            if (rc != M_CM_OK)
            {
                sprintf_s(strMsg, 250,"get_ca_hcc_level() Err�G%s,�渹[%s](�զX[%d]))", sTmp, v_sNumber, i);
                goto errexit;
            }
            stuHcc_lvl->q8_car_age_value[i] = (int)dblAge[i];
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->q8_car_age_value = [%d]\n", i, stuHcc_lvl->q8_car_age_value[i]);

        $EXECUTE preFactor2 INTO $stuHcc_lvl->p8_car_age_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype,
            $stuHcc_lvl->q8_car_age_value[i], $stuHcc_lvl->q8_car_age_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level() Err�G�䤣�� ���֫Y��(q8_car_age_value[%d],�渹[%s](�զX[%d]))", stuHcc_lvl->q8_car_age_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p8_car_age_factor = [%f]\n", i, stuHcc_lvl->p8_car_age_factor[i]);

        /* -------------------------------------------------------------*/

        /* ------------  [���o��O�զX�I�إN���G�P�_ �O�_��O���d�B�ѵs�B����A�Ϊ��[�I�ƶq]  ------------*/

        strcpy(fLia_31[i], "N");
        strcpy(fBrg_11[i], "N");
        strcpy(fDmg_01[i], "N");
        strcpy(fIns_58[i], "N");
        sTmp[0] = '\0';
        iExt_Ins_Count[i] = 0;
        iMainCount[i] = 0;
        iCount[i] = 0;

        if (strncmp(sRoute_main[i], "JB", 2) == 0)
        {
            strcpy(fLia_31[i], "C");
            strcpy(fBrg_11[i], "C");
            strcpy(fDmg_01[i], "C");
            iExt_Ins_Count[i] = 0;
        }
        else
        {
            IcurrHccIns = IfirstHccIns;
            while (IcurrHccIns)
            {
                if (i == IcurrHccIns->iIns_Set)
                {
                    
                    TRACE("=> �զX[%d]�GstuHcc_fac.sInsType = [%s]\n", IcurrHccIns->iIns_Set, IcurrHccIns->sIns_type);

                    strcpy(sTmp, trim(IcurrHccIns->sIns_type));
  
                    TRACE("=> �զX[%d]�GsTmp = [%s]\n", i, sTmp);

                    if (strcmp("21", sTmp) == 0) /* ALL�u����N�I�� */
                    {
                        IcurrHccIns = IcurrHccIns->next;
                        continue;
                    }
                    else if (strcmp("58", sTmp) == 0) /* �O�T�I */
                    {
                        strcpy(fIns_58[i], "Y");
                        break;
                    }
                    
                    for (k = 0; k < LIA_SIZE; k++)
                    {
                        /*printf("k=[%d],sLIA_MAIN_31 = [%s]\n",k,sLIA_MAIN_31[k]);*/
                        if (strcmp(sLIA_MAIN_31[k], sTmp) == 0)
                        {
                            strcpy(fLia_31[i], "Y");
                            iMainCount[i]++;
                        }
                    }
                    for (k = 0; k < BRG_SIZE; k++)
                    {
                        /*printf("k=[%d],sBRG_MAIN_11 = [%s]\n",k,sBRG_MAIN_11[k]);*/
                        if (strcmp(sBRG_MAIN_11[k], sTmp) == 0)
                        {
                            strcpy(fBrg_11[i], "Y");
                            iMainCount[i]++;
                        }
                    }
                    for (k = 0; k < DMG_SIZE; k++)
                    {
                        /*printf("k=[%d],sDMG_MAIN_01 = [%s]\n",k,sDMG_MAIN_01[k]);*/
                        if (strcmp(sDMG_MAIN_01[k], sTmp) == 0)
                        {
                            strcpy(fDmg_01[i], "Y");
                            iMainCount[i]++;
                        }
                    }

                    iCount[i]++;
                }
                IcurrHccIns = IcurrHccIns->next;
            }

            iExt_Ins_Count[i] = iCount[i] - iMainCount[i]; /* ��l�������[�I */
        }

        TRACE("�զX[%d]�GfIns_58 = [%s]\n", i, fIns_58[i]);
        TRACE("�զX[%d]�GfLia_31 = [%s]\n", i, fLia_31[i]);
        TRACE("�զX[%d]�GfBrg_11 = [%s]\n", i, fBrg_11[i]);
        TRACE("�զX[%d]�GfDmg_01 = [%s]\n", i, fDmg_01[i]);
        TRACE("�զX[%d]�GiExt_Ins_Count = [%d]\n", i, iExt_Ins_Count[i]);

        /* �O�T�I��� "��j���DJB�q��"�G ���L�ӧ�O�զX���B�z, ����X intQlevel=-1 �ѫe�ݧP�_ */
        if (fIns_58[i][0] == 'Y')
        {
            intQlevel[i] = -1;
            stuHcc_lvl->qlevel[i] = -1;
            continue; /* �����_����A���U�@��O�զX */
        }

        /* ---------------  �i10:��O���d(N:�_, Y:�O, C:��j)�j--------------*/
        itype = 10;
        TRACE("-----------------------   itype = [%d]----------------------\n", itype);

        strcpy(stuHcc_lvl->f10_lia_value[i], fLia_31[i]);
 
        TRACE(" => �զX[%d]�GstuHcc_lvl->f10_lia_value = [%s]\n", i, stuHcc_lvl->f10_lia_value[i]);

        if (fLia_31[i][0] == 'Y')
        {
            strcpy(fLia_31[i], "1");
        }
        else if (fLia_31[i][0] == 'N')
        {
            strcpy(fLia_31[i], "0");
        }

        TRACE("�զX[%d]�GfLia_31 (for sql) = [%s]\n", i, fLia_31[i]);

        $EXECUTE preFactor1 INTO $stuHcc_lvl->p10_lia_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype, $fLia_31[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level() Err�G�䤣�� ��O���d�Y��(p10_lia_factor[%s],�渹[%s](�զX[%d]))", stuHcc_lvl->f10_lia_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p10_lia_factor = [%f]\n", i, stuHcc_lvl->p10_lia_factor[i]);

        /* ---------------  �i11:��O�ѵs(N:�_, Y:�O, C:��j)�j----------------*/
        itype = 11;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);

        strcpy(stuHcc_lvl->f11_brg_value[i], fBrg_11[i]);

        TRACE(" => �զX[%d]�GstuHcc_lvl->f11_brg_value = [%s]\n", i, stuHcc_lvl->f11_brg_value[i]);

        if (fBrg_11[i][0] == 'Y')
        {
            strcpy(fBrg_11[i], "1");
        }
        else if (fBrg_11[i][0] == 'N')
        {
            strcpy(fBrg_11[i], "0");
        }

        TRACE("�զX[%d]fBrg_11 (for sql) = [%s]\n", i, fBrg_11[i]);

        $EXECUTE preFactor1 INTO $stuHcc_lvl->p11_brg_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype, $fBrg_11[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg,250, "get_ca_hcc_level() Err�G�䤣�� ��O�ѵs�Y��(f11_brg_value[%s],�渹[%s](�զX[%d]))", stuHcc_lvl->f11_brg_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p11_brg_factor = [%f]\n", i, stuHcc_lvl->p11_brg_factor[i]);

        /* ---------------  �i12:���[�I�ƶq�j----------------------------------*/
        itype = 12;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);
        
        stuHcc_lvl->q12_ext_ins_sum_value[i] = iExt_Ins_Count[i];

        TRACE(" => �զX[%d]�GstuHcc_lvl->q12_ext_ins_sum_value = [%d]\n", i, stuHcc_lvl->q12_ext_ins_sum_value[i]);
  
        $EXECUTE preFactor2 INTO $stuHcc_lvl->p12_ext_ins_sum_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype,
            $stuHcc_lvl->q12_ext_ins_sum_value[i], $stuHcc_lvl->q12_ext_ins_sum_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level() Err�G�䤣�� ���֫Y��(q8_car_age_value[%d],�渹[%s](�զX[%d]))", stuHcc_lvl->q8_car_age_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p12_ext_ins_sum_factor = [%f]\n", i, stuHcc_lvl->p12_ext_ins_sum_factor[i]);
  
        /* ---------------  �i13:�a�ϥN���j----------------------------------*/
        itype = 13;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);
  
        if (strlen(trim(stuHcc_fac.sZipCode)) != 0)
        {
            sTmp[0] = '\0';
            rc = get_ply_area(stuHcc_fac.sZipCode, stuHcc_lvl->i13_ply_area_value[i], sTmp);
            if (rc != M_CM_OK)
            {
                sprintf_s(strMsg, 250,"get_ca_hcc_level() Err�G%s,�渹[%s](�զX[%d]))", sTmp, v_sNumber, i);
                goto errexit;
            }
        }
        else /* �l���ϸ�������*/
        {
            strcpy(stuHcc_lvl->i13_ply_area_value[i], "00");
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->i13_ply_area_value = [%s]\n", i, stuHcc_lvl->i13_ply_area_value[i]);
 
        $EXECUTE preFactor1 INTO $stuHcc_lvl->p13_ply_area_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype, $stuHcc_lvl->i13_ply_area_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level() Err�G�䤣�� �a�ϥN�X�Y��(f11_brg_value[%s],�渹[%s](�զX[%d]))", stuHcc_lvl->i13_ply_area_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p13_ply_area_factor = [%f]\n", i, stuHcc_lvl->p13_ply_area_factor[i]);

        /* ---------------  �i14:���ؤΫO���j----------------------------------*/
        itype = 14;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);

        k = (int)ceil( (stuHcc_fac.iPlyPeriod/12.0) );
        sprintf_s(sCartype_year, sizeof sCartype_year,"%s-%d", stuHcc_fac.sCarType, k);        
        strcpy(stuHcc_lvl->i14_cartype_year_value[i], sCartype_year);

        TRACE(" => �զX[%d]�GstuHcc_lvl->i14_cartype_year_value = [%s]\n", i, stuHcc_lvl->i14_cartype_year_value[i]);

        $EXECUTE preFactor1 INTO $stuHcc_lvl->p14_cartype_year_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype, $stuHcc_lvl->i14_cartype_year_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level() Err�G�䤣�� ���ؤΫO���Y��(i14_cartype_year_value[%s],�渹[%s](�զX[%d]))", stuHcc_lvl->i14_cartype_year_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p14_cartype_year_factor = [%f]\n", i, stuHcc_lvl->p14_cartype_year_factor[i]);

        /* ---------------  �i0:���ůżơj----------------------------------*/

        itype = 0;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);

        stuHcc_lvl->pscore[i] =
            stuHcc_lvl->p1_sex_marriage_factor[i] *
            stuHcc_lvl->p2_age_factor[i] *
            stuHcc_lvl->p3_dmg_acc_sum_5y_factor[i] *
            stuHcc_lvl->p4_lia_acc_sum_5y_factor[i] *
            stuHcc_lvl->p5_duty_acc_sum_5y_factor[i] *
            stuHcc_lvl->p8_car_age_factor[i] *
            stuHcc_lvl->p10_lia_factor[i] *
            stuHcc_lvl->p11_brg_factor[i] *
            stuHcc_lvl->p12_ext_ins_sum_factor[i] *
            stuHcc_lvl->p13_ply_area_factor[i] *
            stuHcc_lvl->p14_cartype_year_factor[i];

        TRACE(" => �զX[%d]�GstuHcc_lvl->pscore = [%f]\n", i, stuHcc_lvl->pscore[i]);

        $EXECUTE preFactor2 INTO $intQlevel[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype,
            $stuHcc_lvl->pscore[i], $stuHcc_lvl->pscore[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level() Err�G�䤣�� ���ůż�(�`���� pscore[%f],�渹[%s](�զX[%d]))", stuHcc_lvl->pscore[i], v_sNumber, i);
            goto errexit;
        }
        stuHcc_lvl->qlevel[i] = intQlevel[i];

        TRACE(" => �զX[%d]stuHcc_lvl->qlevel = [%d]\n", i, stuHcc_lvl->qlevel[i]);

    }

    printf("end   get_ca_hcc_level() function\n");
    TRACE("***************************************\n\n\n");

    return M_CM_OK;

errexit:
    puts(strMsg);
    printf("end  get_ca_hcc_level() function (with error)\n");
    printf("***************************************\n\n");
    if (strlen(strMsg) == 0)
    {
        sprintf_s(strMsg, 250,"get_ca_hcc_level() Err�G SQLCODE=[%d], sqlerrmsg=[%s] sqlca.sqlerrd[1]=[%d]\n", SQLCODE, sqlca.sqlerrm, sqlca.sqlerrd[1]);
        return SQLCODE;
    }
    else
    {
        return -99999;
    }
}

/* ------------------------------------------------------------------------------------------------------------------------ */

/* �p��~�֡B���� ( �Ѧ� get_age.ec )*/
long get_age(dFrom, dply_begin, rAge, s_msg)
    $long dFrom,
    dply_begin, *s_msg;
$double *rAge;
{
    $long date1=0, iTmp, tmpDate=0;
    $double iYear, age1=0, iYearTmp;
    $char sTmp[1024];

    printf("\n\n--->begin get_age()\n");
    $WHENEVER SQLERROR GOTO errexit;
    *rAge = 0;

    iYearTmp = (double)(dply_begin - dFrom) / 366;
    /*
    printf("iYearTmp[%f]\n", iYearTmp);*/
    TRACE("floor(iYearTmp)[%f]\n", floor(iYearTmp));
    
    iYear = floor(iYearTmp); /* ����Ʀ~ */
    /*printf("�ͮĤ��ͤ骺��Ʀ~(���~�t�|���վ�)[%f]\n", iYear);*/

    iTmp = iYear + 1;
    $select first 1 date_add($dFrom, $iTmp units year)  
       into $tmpDate
       from systables;
    /*printf("�ͤ��ͮĤ��Ʀ~����@�~�᪺���[%s]\n", cm_long_3ymd(tmpDate));*/

    while (tmpDate <= dply_begin)
    {
        iYear = iYear + 1;
        $select first 1 date_add($tmpDate, 1 units year)
           into $tmpDate
           from systables;
    }
    /*printf("�ͮĤ��ͤ骺��Ʀ~(�վ��)[%f]\n", iYear);*/
    iTmp = dtoi(iYear);
    $select first 1 date_add($dFrom, $iTmp units year)
       into $date1
       from systables;
    TRACE("iYear[%f], date1[%s], dply_begin[%s]\n", iYear, cm_long_3ymd(date1), cm_long_3ymd(dply_begin));

    $select first 1 ($dply_begin - $date1)::integer / (date_add($date1, interval(1) year to year) - $date1)::integer
       into $age1
       from systables;
    /*printf("SQLCODE[%d]\n�ͮĤ��ͤ馩����Ʀ~�Ѿl���p�Ʀ~����[%f]\n", SQLCODE, age1);*/

    *rAge = iYear + age1;
    if (*rAge < 0)
        *rAge = 0;

    printf("\n--->end get_age()\n\n");
    return M_CM_OK;

errexit:
    printf("\n--->end get_age()(with error)\n\n");
    sprintf_s(s_msg, 250,"get_age() Err�G SQLCODE=[%d], sqlerrmsg=[%s] sqlca.sqlerrd[1]=[%d]\n", SQLCODE, sqlca.sqlerrm, sqlca.sqlerrd[1]);
    return SQLCODE;
}

/* ------------------------------------------------------------------------------------------------------------------------ */

/* �l���ϸ� �e�T�X���� �ӫO�a�ϥN�X ( �Ѧ� CACHECK.bas �� zipcode_plyarea() ) */
long get_ply_area(zip_code, ply_area, s_msg)
    $char *zip_code,
    *ply_area, *s_msg;
{
    char sZip[4];
    int iZip;
    TRACE("\n\n--->begin get_ply_area()\n");
    TRACE("zip_code = [%s]\n", zip_code);
    if (strlen(trim(zip_code)) < 3)
    {
        sprintf_s(s_msg, 250,"get_ply_area() Err�G �l���ϸ�(zip_code=[%s])���~\n", zip_code);
        goto errexit;
    }

    strncpy(sZip, trim(zip_code), 3);
    sZip[3] = '\0';
    iZip = atoi(sZip);
    TRACE("zip_code = [%d]\n", iZip);

    if (iZip >= 100 && iZip <= 116)
    {
        strcpy(ply_area, "01");
    }
    else if (iZip >= 220 && iZip <= 253)
    {
        strcpy(ply_area, "06");
    }
    else if (iZip >= 207 && iZip <= 208)
    {
        strcpy(ply_area, "06");
    }
    else if (iZip >= 200 && iZip <= 206)
    {
        strcpy(ply_area, "11");
    }
    else if (iZip >= 290 && iZip <= 290)
    {
        strcpy(ply_area, "11");
    }
    else if (iZip >= 260 && iZip <= 272)
    {
        strcpy(ply_area, "12");
    }
    else if (iZip >= 320 && iZip <= 338)
    {
        strcpy(ply_area, "13");
    }
    else if (iZip >= 300 && iZip <= 315)
    {
        strcpy(ply_area, "14");
    }
    else if (iZip >= 350 && iZip <= 369)
    {
        strcpy(ply_area, "15");
    }
    else if (iZip >= 400 && iZip <= 408)
    {
        strcpy(ply_area, "41");
    }
    else if (iZip >= 411 && iZip <= 439)
    {
        strcpy(ply_area, "41");
    }
    else if (iZip >= 540 && iZip <= 558)
    {
        strcpy(ply_area, "43");
    }
    else if (iZip >= 500 && iZip <= 530)
    {
        strcpy(ply_area, "44");
    }
    else if (iZip >= 630 && iZip <= 655)
    {
        strcpy(ply_area, "45");
    }
    else if (iZip >= 970 && iZip <= 983)
    {
        strcpy(ply_area, "81");
    }
    else if (iZip >= 950 && iZip <= 966)
    {
        strcpy(ply_area, "82");
    }
    else if (iZip >= 600 && iZip <= 625)
    {
        strcpy(ply_area, "61");
    }
    else if (iZip >= 700 && iZip <= 709)
    {
        strcpy(ply_area, "62");
    }
    else if (iZip >= 710 && iZip <= 745)
    {
        strcpy(ply_area, "62");
    }
    else if (iZip >= 800 && iZip <= 813)
    {
        strcpy(ply_area, "64");
    }
    else if (iZip >= 817 && iZip <= 819)
    {
        strcpy(ply_area, "64");
    }
    else if (iZip >= 820 && iZip <= 852)
    {
        strcpy(ply_area, "64");
    }
    else if (iZip >= 814 && iZip <= 815)
    {
        strcpy(ply_area, "64");
    }
    else if (iZip >= 900 && iZip <= 947)
    {
        strcpy(ply_area, "66");
    }
    else if (iZip >= 880 && iZip <= 885)
    {
        strcpy(ply_area, "67");
    }
    else if (iZip >= 890 && iZip <= 896)
    {
        strcpy(ply_area, "90");
    }
    else if (iZip >= 209 && iZip <= 212)
    {
        strcpy(ply_area, "91");
    }
    else
    {
        sprintf_s(s_msg, 250,"get_ply_area() Err�G �l���ϸ�(zip_code=[%s])��������ӫO�a�ϥN�X\n", zip_code);
        goto errexit;
    }
    TRACE("ply_area = [%s]\n", ply_area);

    TRACE("\n--->end get_ply_area()\n\n");
    return M_CM_OK;

errexit:
    printf("--->end get_ply_area()(with error)\n\n");
    return -99999;
}
/* ------------------------------------------------------------------------------------------------------------------------ */
long get_ca_hcc_level_cartype(intQlevel,
                      stuHcc_fac,
                      stuHcc_lvl,
                      strMsg)
$int    *intQlevel;
$struct CA_HCC_FACTOR stuHcc_fac;
$struct CA_HCC_LEVEL *stuHcc_lvl;
$char   *strMsg;
{

    static char sDMG_MAIN_01[DMG_SIZE][INSURANCE_TYPE] = {{"01"}, {"05"}, {"09"},  {"86"},  {"110"}, {"181"}, {"198"}, {"201"}, {"205"}, {"209"}}; /*����D�I*/
    static char sLIA_MAIN_31[LIA_SIZE][INSURANCE_TYPE] = {{"31"}, {"32"}, {"113"}, {"114"}, {"133"}, {"134"}, {"149"}, {"255"}, {"266"}, {"302"}, {"231"}, {"232"}, {"249"}}; /*�d���D�I*/
    static char sBRG_MAIN_11[BRG_SIZE][INSURANCE_TYPE] = {{"11"}, {"20"}, {"111"}, {"129"}, {"211"}};                            /*�ѵs�D�I*/

    $char stmt[8000], sTmp[200], v_sNumber[21];
    $char sRoute_main[INS_SETS][21];  /* C01�G�T��  M01:���� */
    $char fLia_31[INS_SETS][2], fBrg_11[INS_SETS][2], fDmg_01[INS_SETS][2], fIns_58[INS_SETS][2], fIns_47[INS_SETS][2], fIns_56[INS_SETS][2];
    $char sCartype_year[5];         /* ���ؤΫO�� */
    $long v_dPlyBeginDate_main[INS_SETS], v_dFirstPlyDate_main[INS_SETS];    
    $long ltmp, rc;
    $double dblAge[INS_SETS], dblTmp;
    $int itype;                     /* �֫O�]�l���O */
    $int iExt_Ins_Count[INS_SETS];  /* ���[�I�ƶq   */
    int i, k, iCount[INS_SETS], iMainCount[INS_SETS], Act_Ins_Sets; /* Act_Ins_Sets�G��ڶǤJ����O�զX�� */
    char sPlyBeginDate[INS_SETS][11]; /* �O��ͮĤ� */
    char sPlyBeginYear[INS_SETS][5];  /* �O��ͮĦ~ */
    int i_31_32[INS_SETS],i_110_111[INS_SETS],i_113_114_115[INS_SETS],i_47_147[INS_SETS],i_other[INS_SETS],icnt_product[INS_SETS]; /* ��O�ӫ~�`�� */
    int iExtNotDmgCount[INS_SETS],iExtIsDmgCount[INS_SETS]; /* �D������[�I�ӼơB������[�I�Ӽ� */
    
    $WHENEVER SQLERROR GOTO errexit;

    TRACE("\n\n***************************************\n");
    printf("begin get_ca_hcc_level_cartype() function\n");    
    strMsg[0] = '\0';    
    itype = -1;    
    /* --------------------------------------  ���o��ڶǤJ����O�զX��   ------------------------------------*/

    Act_Ins_Sets = 0;    
    for (i = Act_Ins_Sets; i < INS_SETS; i++)
    {

        IcurrHccIns = IfirstHccIns;

       while (IcurrHccIns)
        {
            if (i == IcurrHccIns->iIns_Set)
            {
                Act_Ins_Sets++;
                break;
            }
            IcurrHccIns = IcurrHccIns->next;
        }
    }
    if (Act_Ins_Sets == 0)
    {
        strcat(strMsg, "�L�I�ا�O�զX;\n");
        goto errexit;
    }

    printf("=> ��ڧ�O�զX��(Act_Ins_Sets)=[%d]\n\n", Act_Ins_Sets);

    /* -------------------------------   �˵��ǤJ�Ѽ� stuHcc_fac (for debug)  ---------------------------*/


    TRACE("stuHcc_fac.sNumber                 = [%s]\n", stuHcc_fac.sNumber);
    TRACE("stuHcc_fac.sRoute                  = [%s]\n", stuHcc_fac.sRoute);
    TRACE("stuHcc_fac.sSex                    = [%s]\n", stuHcc_fac.sSex);
    TRACE("stuHcc_fac.sMarriage               = [%s]\n", stuHcc_fac.sMarriage);
    TRACE("stuHcc_fac.iPlyPeriod              = [%d]\n", stuHcc_fac.iPlyPeriod);
    TRACE("stuHcc_fac.sCarType                = [%s]\n", stuHcc_fac.sCarType);
    TRACE("stuHcc_fac.sZipCode                = [%s]\n", stuHcc_fac.sZipCode);
    TRACE("stuHcc_fac.sTrade                  = [%s]\n", stuHcc_fac.sTrade);
    TRACE("stuHcc_fac.iDamageAccidentSum5year = [%d]\n", stuHcc_fac.iDamageAccidentSum5year);
    TRACE("stuHcc_fac.iLiaAccidentSum5year    = [%d]\n", stuHcc_fac.iLiaAccidentSum5year);
    TRACE("stuHcc_fac.iDutyAccidentSum5year   = [%d]\n", stuHcc_fac.iDutyAccidentSum5year);
    TRACE("stuHcc_fac.sProdYear               = [%s]\n", stuHcc_fac.sProdYear);
    TRACE("stuHcc_fac.sAssuredID              = [%s]\n", stuHcc_fac.sAssuredID);
    TRACE("stuHcc_fac.sBrandNo                = [%s]\n", stuHcc_fac.sBrandNo);
    TRACE("stuHcc_fac.iAccidentSum5year       = [%d]\n", stuHcc_fac.iAccidentSum5year);
    TRACE("stuHcc_fac.fHave_Newa_C_2y         = [%s]\n", stuHcc_fac.fHave_Newa_C_2y);

    
    
    for (i = 0; i < Act_Ins_Sets; i++)
    {
        if (risnull(CLONGTYPE, &stuHcc_fac.dPlyBeginDate_C1[i]) == 0)
        {
            TRACE("�զX[%d]�GstuHcc_fac.dPlyBeginDate_C1 = [%ld]=>[%s]\n", i, stuHcc_fac.dPlyBeginDate_C1[i], cm_edate_str(stuHcc_fac.dPlyBeginDate_C1[i]));
        }
        else
        {
            TRACE("�զX[%d]�GstuHcc_fac.dPlyBeginDate_C1 = [null]\n", i);
        }
        if (risnull(CLONGTYPE, &stuHcc_fac.dPlyBeginDate_C2[i]) == 0)
        {
            TRACE("�զX[%d]�GstuHcc_fac.dPlyBeginDate_C2 = [%ld]=>[%s]\n", i, stuHcc_fac.dPlyBeginDate_C2[i], cm_edate_str(stuHcc_fac.dPlyBeginDate_C2[i]));
        }
        else
        {
            TRACE("�զX[%d]�GstuHcc_fac.dPlyBeginDate_C2 = [null]\n", i);
        }
    }

    if (risnull(CLONGTYPE, &stuHcc_fac.dFirstPlyDate_C1) == 0)
    {
        TRACE("stuHcc_fac.dFirstPlyDate_C1 = [%ld]=>[%s]\n", stuHcc_fac.dFirstPlyDate_C1, cm_edate_str(stuHcc_fac.dFirstPlyDate_C1));
    }
    else
    {
        TRACE("stuHcc_fac.dFirstPlyDate_C1 = [null]\n");
    }

    if (risnull(CLONGTYPE, &stuHcc_fac.dFirstPlyDate_C2) == 0)
    {
        TRACE("stuHcc_fac.dFirstPlyDate_C2 = [%ld]=>[%s]\n", stuHcc_fac.dFirstPlyDate_C2, cm_edate_str(stuHcc_fac.dFirstPlyDate_C2));
    }
    else
    {
        TRACE("stuHcc_fac.dFirstPlyDate_C2 = [null]\n");
    }

    if (risnull(CLONGTYPE, &stuHcc_fac.dBirthDate) == 0)
    {
        TRACE("stuHcc_fac.dBirthDate = [%ld]=>[%s]\n", stuHcc_fac.dBirthDate, cm_edate_str(stuHcc_fac.dBirthDate));
    }
    else
    {
        TRACE("stuHcc_fac.dBirthDate = [null]\n");
    }

    IcurrHccIns = IfirstHccIns;
    while (IcurrHccIns)
    {
        TRACE("=> �զX[%d]�GstuHcc_fac.sInsType = [%s]\n", IcurrHccIns->iIns_Set, IcurrHccIns->sIns_type);
        IcurrHccIns = IcurrHccIns->next;
    }


    /* -----------------------------------   ���ˮֶǤJ�Ѽ� stuHcc_fac  -------------------------------*/

    strcpy(v_sNumber, rtrim(stuHcc_fac.sNumber));

    if (strlen(trim(stuHcc_fac.sRoute)) == 0)
    {
        strcat(strMsg, " sRoute ���i�ť�;");
    }

    /* sNumber(�渹) ���v�T�żƭp��A�G�i�ťաC�����ǤJ�渹�A�^�Ǥ����~�T�����~�|��ܳ渹 */
    if (strlen(trim(stuHcc_fac.sSex)) == 0)
    {
        strcat(strMsg, " sSex ���i�ť�;");
    }
    /*if (strlen(trim(stuHcc_fac.sMarriage))== 0)         {  strcat(strMsg," sMarriage ���i�ť�;");   } */
    if (risnull(CLONGTYPE, &stuHcc_fac.dBirthDate) == 1)
    {
        strcat(strMsg, " dBirthDate ���i�ť�;");
    }
    if (strlen(trim(stuHcc_fac.sCarType)) == 0)
    {
        strcat(strMsg, " sCarType ���i�ť�;");
    }
    /*if (strlen(trim(stuHcc_fac.sZipCode))== 0)          {  strcat(strMsg," sZipCode ���i�ť�;");    }*/
    if (stuHcc_fac.iPlyPeriod <= 0)
    {
        strcat(strMsg, " iPlyPeriod �ƭȦ��~;");
    }   
    if (strlen(trim(stuHcc_fac.sTrade)) == 0)
    {
        strcat(strMsg, " sTrade ���i�ť�;");
    }
    if (strlen(trim(stuHcc_fac.sExistPlyDetail)) == 0)
    {
        strcat(strMsg, " sExistPlyDetail ���i�ť�;");
    }    
    rtrim_space(strMsg);
    if (strlen(strMsg) > 0)
    {
        sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G%s(�渹[%s])", strMsg, v_sNumber);
        goto errexit;
    }

    /* --------------------------------    PREPARE SQL   ----------------------------------*/

    /* �O�v�ͮĤ�(ca_rate_renew�@�ߧ���N�I) */
    sprintf_s(stmt, sizeof stmt,"SELECT drate FROM ca_rate_date "
                                "  WHERE itable = 'ca_hcc_factor' "
                                "    AND icode in (SELECT icode FROM ca_rate_renew "
                                "                   WHERE ? BETWEEN  deffect_bgn AND deffect_end "
                                "                     AND fcard_class = '2')");
    $PREPARE preDrate FROM $stmt;

    sprintf_s(stmt, sizeof stmt, "SELECT pfactor FROM ca_hcc_factor "
                                 "   WHERE drate = ? "
                                 "     AND iroute_main = ? "
                                 "     AND itype = ? "
                                 "     AND ifactor_bgn = ? ");
    $PREPARE preFactor1 FROM $stmt;

    sprintf_s(stmt, sizeof stmt, "SELECT pfactor FROM ca_hcc_factor "
                                 "   WHERE drate = ? "
                                 "     AND iroute_main = ? "
                                 "     AND itype = ? "
                                 "     AND (? >= ifactor_bgn And ? < ifactor_end)");
    $PREPARE preFactor2 FROM $stmt;
    
    sprintf_s(stmt, sizeof stmt, "SELECT FIRST 1 CASE WHEN icar_series='10' THEN '0' ELSE '1' END  "
                                 "  FROM ca_car_model"
                                 " WHERE drate = (SELECT drate FROM ca_rate_date "
                                 "                 WHERE itable = 'ca_car_model' "
                                 "                   AND icode in (SELECT icode FROM ca_rate_renew "
                                 "                                  WHERE ? BETWEEN  deffect_bgn AND deffect_end "
                                 "                                    AND fcard_class = '2'))"
                                 "   AND ibrand = ? ");
    $PREPARE preCarSeries FROM $stmt;
    
    /* ---------------------------------------- �B�z�U��O�զX ----------------------------------------*/

    for (i = 0; i < Act_Ins_Sets; i++)
    {

        /* -----------------------------------    ��l��   ------------------------------------*/

        TRACE("\n====================================== ��O�զX[%d] ======================================\n", i);
      
        strcpy(sRoute_main[i], " ");
        rsetnull(CLONGTYPE, (char *)&v_dPlyBeginDate_main[i]);
        rsetnull(CLONGTYPE, (char *)&v_dFirstPlyDate_main[i]);

        intQlevel[i] = 0;
        stuHcc_lvl->qlevel[i] = 0;
        stuHcc_lvl->pscore[i] = 0.0;

        strcpy(stuHcc_lvl->iroute_main[i], " ");
        rsetnull(CLONGTYPE, (char *)&stuHcc_lvl->drate[i]);

        strcpy(stuHcc_lvl->i1_sex_marriage_value[i], " ");
        stuHcc_lvl->p1_sex_marriage_factor[i] = 0.0;

        stuHcc_lvl->q2_age_value[i] = 0;
        stuHcc_lvl->p2_age_factor[i] = 0.0;

        stuHcc_lvl->q3_dmg_acc_sum_5y_value[i] = 0;
        stuHcc_lvl->p3_dmg_acc_sum_5y_factor[i] = 0.0;

        stuHcc_lvl->q4_lia_acc_sum_5y_value[i] = 0;
        stuHcc_lvl->p4_lia_acc_sum_5y_factor[i] = 0.0;

        stuHcc_lvl->q5_duty_acc_sum_5y_value[i] = 0;
        stuHcc_lvl->p5_duty_acc_sum_5y_factor[i] = 0.0;

        stuHcc_lvl->q8_car_age_value[i] = 0;
        stuHcc_lvl->p8_car_age_factor[i] = 0.0;

        strcpy(stuHcc_lvl->f10_lia_value[i], " ");
        stuHcc_lvl->p10_lia_factor[i] = 0.0;

        strcpy(stuHcc_lvl->f11_brg_value[i], " ");
        stuHcc_lvl->p11_brg_factor[i] = 0.0;

        stuHcc_lvl->q12_ext_ins_sum_value[i] = 0;
        stuHcc_lvl->p12_ext_ins_sum_factor[i] = 0.0;

        strcpy(stuHcc_lvl->i13_ply_area_value[i], " ");
        stuHcc_lvl->p13_ply_area_factor[i] = 0.0;

        strcpy(stuHcc_lvl->i14_cartype_year_value[i], " ");
        stuHcc_lvl->p14_cartype_year_factor[i] = 0.0;

        strcpy(stuHcc_lvl->f15_injure_value[i], " ");
        stuHcc_lvl->p15_injure_factor[i] = 0.0;
        
        stuHcc_lvl->q16_product_sum_value[i] = 0;
        stuHcc_lvl->p16_product_sum_factor[i] = 0.0;
        
        stuHcc_lvl->q17_acc_sum_5y_value[i] = 0;
        stuHcc_lvl->p17_acc_sum_5y_factor[i] = 0.0;   
        
        strcpy(stuHcc_lvl->f18_have_newa_c_2y_value[i], " ");
        stuHcc_lvl->p18_have_newa_c_2y_factor[i] = 0.0;    
          
        strcpy(stuHcc_lvl->i19_series_value[i], " ");
        stuHcc_lvl->p19_series_factor[i] = 0.0; 
        
        stuHcc_lvl->q20_ext_ins_notdmg_value[i] = 0;
        stuHcc_lvl->p20_ext_ins_notdmg_factor[i] = 0.0;
        
        stuHcc_lvl->q21_ext_ins_isdmg_value[i] = 0;
        stuHcc_lvl->p21_ext_ins_isdmg_factor[i] = 0.0; 
        
  
       

        /* ---------------  �P�_sRoute_main �� [C01]����  �� [M01]�T��  ----------------*/


        if (risnull(CLONGTYPE, &stuHcc_fac.dPlyBeginDate_C2[i]) == 1)     /* �L���N�I�ͮĤ�,������j */
        {
            if (risnull(CLONGTYPE, &stuHcc_fac.dPlyBeginDate_C1[i]) == 1) /* �]�L�j��ͮĤ� */
            {
                sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype()_2 Err�G�L�j��Υ��N�ͮĤ�(�渹[%s])(�զX[%d])", v_sNumber, i);
                goto errexit;
            }
            else
            {
                /* ��j�G���B�z, ����X intQlevel=-1 �ѫe�ݧP�_ */
                intQlevel[i] = -1;
                stuHcc_lvl->qlevel[i] = -1;
                continue; /* �����_����A���U�@��O�զX */
            }
        }
        
        if (strcmp(stuHcc_fac.sCarType, "03") == 0 || strcmp(stuHcc_fac.sCarType, "04") == 0 || strcmp(stuHcc_fac.sCarType, "22") == 0)
        {
            strcpy(sRoute_main[i], "C01");	
        }
        else if(strcmp(stuHcc_fac.sCarType, "01") == 0 || strcmp(stuHcc_fac.sCarType, "02") == 0 || strcmp(stuHcc_fac.sCarType, "32") == 0 || strcmp(stuHcc_fac.sCarType, "34") == 0)
        {
            strcpy(sRoute_main[i], "M01");	
        }
        else
        {
            sprintf_s(strMsg,250, "get_ca_hcc_level_cartype() Err�G�DHCC�p�⨮��(�渹[%s])(�զX[%d])", v_sNumber, i);
            goto errexit;	
        }

        strcpy(stuHcc_lvl->iroute_main[i], sRoute_main[i]);
        printf(" => �զX[%d]�GstuHcc_lvl->iroute_main = [%s]\n", i, stuHcc_lvl->iroute_main[i]);

        /* -------------------  ���o�O�v�ͮĤ�  --------------------*/


        v_dPlyBeginDate_main[i] = stuHcc_fac.dPlyBeginDate_C2[i];        /* �ͮĤ�H���N���D */
        v_dFirstPlyDate_main[i] = stuHcc_fac.dFirstPlyDate_C2;
        

        TRACE(" -------------------  [���o�O�v�ͮĤ�]  --------------------\n");

        $EXECUTE preDrate INTO $stuHcc_lvl->drate[i] USING $v_dPlyBeginDate_main[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� itable=ca_hcc_factor���O�v�ͮĤ�drate(�O�I�ͮĤ�[%s],�渹[%s](�զX[%d]))", cm_edate_str(v_dPlyBeginDate_main[i]), v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->drate = [%s]\n", i, cm_edate_str(stuHcc_lvl->drate[i]));

        /* =============================   �}�l�B�z HCC�֫O�]�l  ==================================== */

        /* ---------------  �i1:�ʧO�αB�áj----------------------------*/
        itype = 1;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);

        strcpy(stuHcc_lvl->i1_sex_marriage_value[i], ((stuHcc_fac.sSex[0] == '1' || stuHcc_fac.sSex[0] == 'M') ? "M" : "F"));

        if (strlen(trim(stuHcc_fac.sMarriage)) != 0)
        {
            strcat(stuHcc_lvl->i1_sex_marriage_value[i], trim(stuHcc_fac.sMarriage));
        }
        else /* �B�å�����*/
        {
            strcat(stuHcc_lvl->i1_sex_marriage_value[i], "0");
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->i1_sex_marriage_value = [%s]\n", i, stuHcc_lvl->i1_sex_marriage_value[i]);

        $EXECUTE preFactor1 INTO $stuHcc_lvl->p1_sex_marriage_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype, $stuHcc_lvl->i1_sex_marriage_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� �ʧO�αB�ëY��(i1_sex_marriage_value[%s],�渹[%s](�զX[%d]))", stuHcc_lvl->i1_sex_marriage_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p1_sex_marriage_factor = [%f]\n", i, stuHcc_lvl->p1_sex_marriage_factor[i]);

        /* ----------------- �i2:�~�֡j----------------------------------*/
        itype = 2;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);

        dblAge[i] = 0.0;
        sTmp[0] = '\0';
        rc = get_age(stuHcc_fac.dBirthDate, v_dPlyBeginDate_main[i], &dblAge[i], sTmp);

        TRACE("=> �զX[%d]�Grc = [%ld],dblAge = [%f]\n", i, rc, dblAge[i]);

        if (rc != M_CM_OK)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G%s,�渹[%s](�զX[%d]))", sTmp, v_sNumber, i);
            goto errexit;
        }
        stuHcc_lvl->q2_age_value[i] = (int)dblAge[i];

        TRACE(" => �զX[%d]�GstuHcc_lvl->q2_age_value = [%d]\n", i, stuHcc_lvl->q2_age_value[i]);

        $EXECUTE preFactor2 INTO $stuHcc_lvl->p2_age_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype,
            $stuHcc_lvl->q2_age_value[i], $stuHcc_lvl->q2_age_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� �~�֫Y��(q2_age_value[%d],�渹[%s](�զX[%d]))", stuHcc_lvl->q2_age_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p2_age_factor = [%f]\n", i, stuHcc_lvl->p2_age_factor[i]);

        /* ---------------  �i3:�e���~�����I�߮ץB�ߴڪ��B��0���߮ץ�ơj------*/
        itype = 3;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);
        if (stuHcc_fac.sTrade[0] != 'Y')                      /* �S�d���T */
        {
            stuHcc_lvl->q3_dmg_acc_sum_5y_value[i] = 99;      /* �S�d���T =>  ifactor_bgn = 99 */ 
        }
        else
        {
            if (stuHcc_fac.sExistPlyDetail[0]  != 'Y')        /* ���T�L�ӫO����*/
            {
                stuHcc_lvl->q3_dmg_acc_sum_5y_value[i] = -1;  /* ���d���T,���L�ӫO���� =>  ifactor_bgn = -1 */ 
            }
            else
            {
                stuHcc_lvl->q3_dmg_acc_sum_5y_value[i] = stuHcc_fac.iDamageAccidentSum5year;
            } 
        } 

        TRACE(" => �զX[%d]�GstuHcc_lvl->q3_dmg_acc_sum_5y_value = [%d]\n", i, stuHcc_lvl->q3_dmg_acc_sum_5y_value[i]);

        $EXECUTE preFactor2 INTO $stuHcc_lvl->p3_dmg_acc_sum_5y_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype,
            $stuHcc_lvl->q3_dmg_acc_sum_5y_value[i], $stuHcc_lvl->q3_dmg_acc_sum_5y_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� �e���~�����I�߮ץB�ߴڪ��B��0���߮ץ�ƫY��(q3_dmg_acc_sum_5y_value[%d],�渹[%s](�զX[%d]))", stuHcc_lvl->q3_dmg_acc_sum_5y_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p3_dmg_acc_sum_5y_factor = [%f]\n", i, stuHcc_lvl->p3_dmg_acc_sum_5y_factor[i]);

        /* ---------------  �i4:�e���~�ĤT�H�d���I���߮ץ�ơj----------------*/
        itype = 4;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);
        
        if (stuHcc_fac.sTrade[0] != 'Y')                      /* �S�d���T */
        {
            stuHcc_lvl->q4_lia_acc_sum_5y_value[i] = 99;      /* �S�d���T =>  ifactor_bgn = 99 */ 
        }
        else
        {
            if (stuHcc_fac.sExistPlyDetail[0]  != 'Y')        /* ���T�L�ӫO����*/
            {
                stuHcc_lvl->q4_lia_acc_sum_5y_value[i] = -1;  /* ���d���T,���L�ӫO���� =>  ifactor_bgn = -1 */ 
            }
            else
            {
                stuHcc_lvl->q4_lia_acc_sum_5y_value[i] = stuHcc_fac.iLiaAccidentSum5year;
            } 
        } 

        TRACE(" => �զX[%d]�GstuHcc_lvl->q4_lia_acc_sum_5y_value = [%d]\n", i, stuHcc_lvl->q4_lia_acc_sum_5y_value[i]);

        $EXECUTE preFactor2 INTO $stuHcc_lvl->p4_lia_acc_sum_5y_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype,
            $stuHcc_lvl->q4_lia_acc_sum_5y_value[i], $stuHcc_lvl->q4_lia_acc_sum_5y_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� �e���~�ĤT�H�d���I���߮ץ�ƫY��(q4_lia_acc_sum_5y_value[%d],�渹[%s](�զX[%d]))", stuHcc_lvl->q4_lia_acc_sum_5y_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p4_lia_acc_sum_5y_factor = [%f]\n", i, stuHcc_lvl->p4_lia_acc_sum_5y_factor[i]);

        /* ---------------  �i5:�e���~���F�d���p�����߮ץ�ơj-----------------*/
        itype = 5;  

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);

        if (stuHcc_fac.sTrade[0] != 'Y')                      /* �S�d���T */
        {
            stuHcc_lvl->q5_duty_acc_sum_5y_value[i] = 99;      /* �S�d���T =>  ifactor_bgn = 99 */ 
        }
        else
        {
            if (stuHcc_fac.sExistPlyDetail[0]  != 'Y')        /* ���T�L�ӫO����*/
            {
                stuHcc_lvl->q5_duty_acc_sum_5y_value[i] = -1;  /* ���d���T,���L�ӫO���� =>  ifactor_bgn = -1 */ 
            }
            else
            {
                stuHcc_lvl->q5_duty_acc_sum_5y_value[i] = stuHcc_fac.iDutyAccidentSum5year;
            } 
        } 

        TRACE(" => �զX[%d]�GstuHcc_lvl->q5_duty_acc_sum_5y_value = [%d]\n", i, stuHcc_lvl->q5_duty_acc_sum_5y_value[i]);

        $EXECUTE preFactor2 INTO $stuHcc_lvl->p5_duty_acc_sum_5y_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype,
            $stuHcc_lvl->q5_duty_acc_sum_5y_value[i], $stuHcc_lvl->q5_duty_acc_sum_5y_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� �e���~���F�d���p�����߮ץ�ƫY��(q5_duty_acc_sum_5y_value[%d],�渹[%s](�զX[%d]))", stuHcc_lvl->q5_duty_acc_sum_5y_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p5_duty_acc_sum_5y_factor = [%f]\n", i, stuHcc_lvl->p5_duty_acc_sum_5y_factor[i]);

        /* ---------------  �i8:���֡j------------------------------------*/
        itype = 8;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);
        
        if (strcmp(sRoute_main[i], "C01") == 0)  /* �T�� */
        {
            if (risnull(CLONGTYPE, &v_dFirstPlyDate_main[i]) == 1)
            {
                if (stuHcc_fac.sTrade[0] != 'Y')                   /* �S�d���T */
                {
                    stuHcc_lvl->q8_car_age_value[i] = 99;          /* [�S�d���T]=> �Y�u�̦���O��-�j��v�L��, ifactor_bgn = 99;  */ 
                }
                else
                {
                    stuHcc_lvl->q8_car_age_value[i] = -1;          /* [���d���T]=> �Y�u�̦���O��-�j��v�L��, ifactor_bgn = -1; */
                }
            }
            else
            {
                dblAge[i] = 0.0;
                sTmp[0] = '\0';
                rc = get_age(v_dFirstPlyDate_main[i], v_dPlyBeginDate_main[i], &dblAge[i], sTmp);
                TRACE("=> �զX[%d]�Grc = [%ld],dblAge = [%f]\n", i, rc, dblAge[i]);
                if (rc != M_CM_OK)
                {
                    sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G%s,�渹[%s](�զX[%d]))", sTmp, v_sNumber, i);
                    goto errexit;
                }
                stuHcc_lvl->q8_car_age_value[i] = (int)dblAge[i];
            }
        }
        else  /* ���� */
        {
            /*�O��ͮĦ~��h�Q�O�I�����s�y�~(���ݤ��)*/
            strcpy(sPlyBeginDate[i],cm_edate_str(v_dPlyBeginDate_main[i]));
            TRACE("�O��ͮĤ�sPlyBeginDate[%s]\n", sPlyBeginDate[i]);
            strncpy(sPlyBeginYear[i],sPlyBeginDate[i]+6,4);
            TRACE("�O��ͮĦ~sPlyBeginYear[%s]\n", sPlyBeginYear[i]);
            stuHcc_lvl->q8_car_age_value[i] = atoi(sPlyBeginYear[i])-atoi(stuHcc_fac.sProdYear);

        }

        
        TRACE(" => �զX[%d]�GstuHcc_lvl->q8_car_age_value = [%d]\n", i, stuHcc_lvl->q8_car_age_value[i]);

        $EXECUTE preFactor2 INTO $stuHcc_lvl->p8_car_age_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype,
            $stuHcc_lvl->q8_car_age_value[i], $stuHcc_lvl->q8_car_age_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� ���֫Y��(q8_car_age_value[%d],�渹[%s](�զX[%d]))", stuHcc_lvl->q8_car_age_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p8_car_age_factor = [%f]\n", i, stuHcc_lvl->p8_car_age_factor[i]);

        /* -------------------------------------------------------------*/

        /* ------------  [���o��O�զX�I�إN���G�P�_ �O�_��O���d�B�ѵs�B����A�Ϊ��[�I�ƶq]  ------------*/

        strcpy(fLia_31[i], "N");
        strcpy(fBrg_11[i], "N");
        strcpy(fDmg_01[i], "N");
        strcpy(fIns_58[i], "N");
        strcpy(fIns_47[i], "N");
        strcpy(fIns_56[i], "0");
        sTmp[0] = '\0';
        iExt_Ins_Count[i] = 0;
        iMainCount[i] = 0;
        iCount[i] = 0;
        i_31_32[i] = 0;
        i_110_111[i] = 0;
        i_113_114_115[i] = 0;
        i_47_147[i] = 0;
        i_other[i] = 0;
        icnt_product[i] = 0;
        iExtNotDmgCount[i] = 0;
        iExtIsDmgCount[i] = 0;
        
        IcurrHccIns = IfirstHccIns;
        while (IcurrHccIns)
        {
            if (i == IcurrHccIns->iIns_Set)
            {
                    
                TRACE("=> �զX[%d]�GstuHcc_fac.sInsType = [%s]\n", IcurrHccIns->iIns_Set, IcurrHccIns->sIns_type);

                strcpy(sTmp, trim(IcurrHccIns->sIns_type));
  
                TRACE("=> �զX[%d]�GsTmp = [%s]\n", i, sTmp);

                if (strcmp("21", sTmp) == 0) /* �u����N�I�� */
                {
                    IcurrHccIns = IcurrHccIns->next;
                    continue;
                }
                else if (strcmp("58", sTmp) == 0) /* �O�T�I */
                {
                    strcpy(fIns_58[i], "Y");
                    break;
                }
                
                if (strcmp("47", sTmp) == 0 || strcmp("147", sTmp) == 0) /* �O�_��O47�B147 */
                {
                    strcpy(fIns_47[i], "Y");
                }
                 
                if (strcmp("50", sTmp) == 0 || strcmp("147", sTmp) == 0 || strcmp("48", sTmp) == 0 || strcmp("56", sTmp) == 0 ||
                    strcmp("166", sTmp) == 0 || strcmp("266", sTmp) == 0 ) /* �O�_�[�O�ˮ`�I */
                {
                    strcpy(fIns_56[i], "1");
                } 
                 
                if (strcmp("31", sTmp) == 0 || strcmp("32", sTmp) == 0 || strcmp("231", sTmp) == 0 || strcmp("232", sTmp) == 0) /* ��O�ӫ~�ƭp�� */
                {
                    i_31_32[i] = 1 ;
                }
                else if (strcmp("110", sTmp) == 0 || strcmp("111", sTmp) == 0 )
                {
                    i_110_111[i] = 1 ;
                }
                else if (strcmp("113", sTmp) == 0 || strcmp("114", sTmp) == 0 || strcmp("115", sTmp) == 0)
                {
                    i_113_114_115[i] = 1 ;
                }
                else if (strcmp("47", sTmp) == 0 || strcmp("147", sTmp) == 0 )
                {
                    i_47_147[i] = 1 ;
                }
                else
                {
                    i_other[i]++;
                }
                
                if (strcmp("55", sTmp) == 0 || strcmp("12", sTmp) == 0 || strcmp("16", sTmp) == 0 || strcmp("17", sTmp) == 0 ||
                    strcmp("19", sTmp) == 0 || strcmp("27", sTmp) == 0 || strcmp("28", sTmp) == 0 || strcmp("29", sTmp) == 0 ||
                    strcmp("30", sTmp) == 0 || strcmp("301", sTmp) == 0 || strcmp("34", sTmp) == 0 || strcmp("35", sTmp) == 0 ||
                    strcmp("52", sTmp) == 0 || strcmp("109", sTmp) == 0 || strcmp("124", sTmp) == 0 || strcmp("164", sTmp) == 0 ||
                    strcmp("165", sTmp) == 0 || strcmp("255", sTmp) == 0 || strcmp("302", sTmp) == 0 )  /* �D������[�I�Ӽ� */
                {
                    iExtNotDmgCount[i]++;
                }
                
                if (strcmp("07", sTmp) == 0 || strcmp("10", sTmp) == 0 || strcmp("15", sTmp) == 0 ||
                    strcmp("66", sTmp) == 0 || strcmp("67", sTmp) == 0 || strcmp("62", sTmp) == 0 || strcmp("63", sTmp) == 0 ||
                    strcmp("64", sTmp) == 0 || strcmp("143", sTmp) == 0 || strcmp("154", sTmp) == 0 || strcmp("155", sTmp) == 0 ||
                    strcmp("156", sTmp) == 0 || strcmp("163", sTmp) == 0 || strcmp("161", sTmp) == 0 || strcmp("162", sTmp) == 0)  /* ������[�I�Ӽ� */
                {
                    iExtIsDmgCount[i]++;
                }
                
                for (k = 0; k < LIA_SIZE; k++)
                {
                    /*printf("k=[%d],sLIA_MAIN_31 = [%s]\n",k,sLIA_MAIN_31[k]);*/
                    if (strcmp(sLIA_MAIN_31[k], sTmp) == 0)
                    {
                    	if( strcmp(sTmp,"31") == 0 || strcmp(sTmp,"32") == 0 || strcmp(sTmp,"149") == 0 || strcmp(sTmp,"113") == 0 || strcmp(sTmp,"114") == 0 ||
                    	    strcmp(sTmp,"231") == 0 || strcmp(sTmp,"232") == 0 || strcmp(sTmp,"249") == 0)
                        {
                            strcpy(fLia_31[i], "Y");
                        }
                        
                        iMainCount[i]++;
                    }
                }
                for (k = 0; k < BRG_SIZE; k++)
                {
                    /*printf("k=[%d],sBRG_MAIN_11 = [%s]\n",k,sBRG_MAIN_11[k]);*/
                    if (strcmp(sBRG_MAIN_11[k], sTmp) == 0)
                    {
                    	if( strcmp(sTmp,"11") == 0 || strcmp(sTmp,"211") == 0 )
                        {
                            strcpy(fBrg_11[i], "Y");
                        }
                        
                        iMainCount[i]++;
                    }
                }
                for (k = 0; k < DMG_SIZE; k++)
                {
                    /*printf("k=[%d],sDMG_MAIN_01 = [%s]\n",k,sDMG_MAIN_01[k]);*/
                    if (strcmp(sDMG_MAIN_01[k], sTmp) == 0)
                    {
                        strcpy(fDmg_01[i], "Y");
                        iMainCount[i]++;
                    }
                }

                iCount[i]++;
            }
            IcurrHccIns = IcurrHccIns->next;
        }

        iExt_Ins_Count[i] = iCount[i] - iMainCount[i]; /* ��l�������[�I */
        icnt_product[i]= i_31_32[i] + i_110_111[i] + i_113_114_115[i] + i_47_147[i] + i_other[i]; /* ��O�ӫ~�`�� */
        
        
        TRACE("�զX[%d]�GfIns_56 = [%s]\n", i, fIns_56[i]);
        TRACE("�զX[%d]�GfIns_47 = [%s]\n", i, fIns_47[i]);
        TRACE("�զX[%d]�GfIns_58 = [%s]\n", i, fIns_58[i]);
        TRACE("�զX[%d]�GfLia_31 = [%s]\n", i, fLia_31[i]);
        TRACE("�զX[%d]�GfBrg_11 = [%s]\n", i, fBrg_11[i]);
        TRACE("�զX[%d]�GfDmg_01 = [%s]\n", i, fDmg_01[i]);
        TRACE("�զX[%d]�GiExt_Ins_Count = [%d]\n", i, iExt_Ins_Count[i]);
        TRACE("�զX[%d]�Gicnt_product = [%d]\n", i, icnt_product[i]);
        
        
        /* �O�T�I�G ���L�ӧ�O�զX���B�z, ����X intQlevel=-1 �ѫe�ݧP�_ */
        if (fIns_58[i][0] == 'Y')
        {
            intQlevel[i] = -1;
            stuHcc_lvl->qlevel[i] = -1;
            continue; /* �����_����A���U�@��O�զX */
        }
        
        /* ��O47�B147�G ���L�ӧ�O�զX���B�z, ����X intQlevel=-1 �ѫe�ݧP�_*/
        if (fIns_47[i][0] == 'Y' && iCount[i] == 1 )
        {
            intQlevel[i] = -1;
            stuHcc_lvl->qlevel[i] = -1;
            continue; /* �����_����A���U�@��O�զX */
        } 
        

        /* ---------------  �i10:��O���d(N:�_, Y:�O)�j--------------*/
        itype = 10;
        TRACE("-----------------------   itype = [%d]----------------------\n", itype);

        strcpy(stuHcc_lvl->f10_lia_value[i], fLia_31[i]);
 
        TRACE(" => �զX[%d]�GstuHcc_lvl->f10_lia_value = [%s]\n", i, stuHcc_lvl->f10_lia_value[i]);

        if (fLia_31[i][0] == 'Y')
        {
            strcpy(fLia_31[i], "1");
        }
        else if (fLia_31[i][0] == 'N')
        {
            strcpy(fLia_31[i], "0");
        }

        TRACE("�զX[%d]�GfLia_31 (for sql) = [%s]\n", i, fLia_31[i]);

        $EXECUTE preFactor1 INTO $stuHcc_lvl->p10_lia_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype, $fLia_31[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� ��O���d�Y��(p10_lia_factor[%s],�渹[%s](�զX[%d]))", stuHcc_lvl->f10_lia_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p10_lia_factor = [%f]\n", i, stuHcc_lvl->p10_lia_factor[i]);

        /* ---------------  �i11:��O�ѵs(N:�_, Y:�O)�j----------------*/
        itype = 11;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);

        strcpy(stuHcc_lvl->f11_brg_value[i], fBrg_11[i]);

        TRACE(" => �զX[%d]�GstuHcc_lvl->f11_brg_value = [%s]\n", i, stuHcc_lvl->f11_brg_value[i]);

        if (fBrg_11[i][0] == 'Y')
        {
            strcpy(fBrg_11[i], "1");
        }
        else if (fBrg_11[i][0] == 'N')
        {
            strcpy(fBrg_11[i], "0");
        }

        TRACE("�զX[%d]fBrg_11 (for sql) = [%s]\n", i, fBrg_11[i]);

        $EXECUTE preFactor1 INTO $stuHcc_lvl->p11_brg_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype, $fBrg_11[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� ��O�ѵs�Y��(f11_brg_value[%s],�渹[%s](�զX[%d]))", stuHcc_lvl->f11_brg_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p11_brg_factor = [%f]\n", i, stuHcc_lvl->p11_brg_factor[i]);

        /* ---------------  �i12:���[�I�ƶq�j----------------------------------*/
        itype = 12;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);
        
        stuHcc_lvl->q12_ext_ins_sum_value[i] = iExt_Ins_Count[i];

        TRACE(" => �զX[%d]�GstuHcc_lvl->q12_ext_ins_sum_value = [%d]\n", i, stuHcc_lvl->q12_ext_ins_sum_value[i]);
  
        $EXECUTE preFactor2 INTO $stuHcc_lvl->p12_ext_ins_sum_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype,
            $stuHcc_lvl->q12_ext_ins_sum_value[i], $stuHcc_lvl->q12_ext_ins_sum_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� ���[�I�ƶq�Y��(q12_ext_ins_sum_value[%d],�渹[%s](�զX[%d]))", stuHcc_lvl->q12_ext_ins_sum_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p12_ext_ins_sum_factor = [%f]\n", i, stuHcc_lvl->p12_ext_ins_sum_factor[i]);
  
        /* ---------------  �i13:�a�ϥN���j----------------------------------*/
        itype = 13;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);
  
        if (strlen(trim(stuHcc_fac.sZipCode)) != 0)
        {
            sTmp[0] = '\0';
            rc = get_ply_area(stuHcc_fac.sZipCode, stuHcc_lvl->i13_ply_area_value[i], sTmp);
            if (rc != M_CM_OK)
            {
                sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G%s,�渹[%s](�զX[%d]))", sTmp, v_sNumber, i);
                goto errexit;
            }
        }
        else /* �l���ϸ�������*/
        {
            strcpy(stuHcc_lvl->i13_ply_area_value[i], "00");
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->i13_ply_area_value = [%s]\n", i, stuHcc_lvl->i13_ply_area_value[i]);
 
        $EXECUTE preFactor1 INTO $stuHcc_lvl->p13_ply_area_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype, $stuHcc_lvl->i13_ply_area_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� �a�ϥN�X�Y��(i13_ply_area_value[%s],�渹[%s](�զX[%d]))", stuHcc_lvl->i13_ply_area_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p13_ply_area_factor = [%f]\n", i, stuHcc_lvl->p13_ply_area_factor[i]);

        /* ---------------  �i14:���ؤΫO���j----------------------------------*/
        itype = 14;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);

        k = (int)ceil( (stuHcc_fac.iPlyPeriod/12.0) );
        sprintf_s(sCartype_year, sizeof sCartype_year,"%s-%d", stuHcc_fac.sCarType, k);        
        strcpy(stuHcc_lvl->i14_cartype_year_value[i], sCartype_year);

        TRACE(" => �զX[%d]�GstuHcc_lvl->i14_cartype_year_value = [%s]\n", i, stuHcc_lvl->i14_cartype_year_value[i]);

        $EXECUTE preFactor1 INTO $stuHcc_lvl->p14_cartype_year_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype, $stuHcc_lvl->i14_cartype_year_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� ���ؤΫO���Y��(i14_cartype_year_value[%s],�渹[%s](�զX[%d]))", stuHcc_lvl->i14_cartype_year_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p14_cartype_year_factor = [%f]\n", i, stuHcc_lvl->p14_cartype_year_factor[i]);


        /* ---------------  �i15:�O�_�[�O�ˮ`�I�j----------------------------------*/
        
        itype = 15;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);

        strcpy(stuHcc_lvl->f15_injure_value[i], fIns_56[i]);

        TRACE(" => �զX[%d]�GstuHcc_lvl->f15_injure_value = [%s]\n", i, stuHcc_lvl->f15_injure_value[i]);

        TRACE("�զX[%d]fIns_56 (for sql) = [%s]\n", i, fIns_56[i]);

        $EXECUTE preFactor1 INTO $stuHcc_lvl->p15_injure_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype, $fIns_56[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� �[�O�ˮ`�I�Y��(f15_injure_value[%s],�渹[%s](�զX[%d]))", stuHcc_lvl->f15_injure_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p15_injure_factor = [%f]\n", i, stuHcc_lvl->p15_injure_factor[i]);

        
        /* ---------------  �i16:��O�ӫ~�`�ơj----------------------------------*/
        itype = 16;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);
        
        stuHcc_lvl->q16_product_sum_value[i] = icnt_product[i];

        TRACE(" => �զX[%d]�GstuHcc_lvl->q16_product_sum_value = [%d]\n", i, stuHcc_lvl->q16_product_sum_value[i]);
  
        $EXECUTE preFactor2 INTO $stuHcc_lvl->p16_product_sum_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype,
            $stuHcc_lvl->q16_product_sum_value[i], $stuHcc_lvl->q16_product_sum_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� ��O�ӫ~�`�ƫY��(q16_product_sum_value[%d],�渹[%s](�զX[%d]))", stuHcc_lvl->q16_product_sum_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p16_product_sum_factor = [%f]\n", i, stuHcc_lvl->p16_product_sum_factor[i]);
  
        
        /* ---------------  �i17:�e5�~�߮ץ�ơj----------------------------------*/
        itype = 17;  

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);

        if (stuHcc_fac.sTrade[0] != 'Y')                      /* �S�d���T */
        {
            stuHcc_lvl->q17_acc_sum_5y_value[i] = 99;      /* �S�d���T =>  ifactor_bgn = 99 */ 
        }
        else
        {
            if (stuHcc_fac.sExistPlyDetail[0]  != 'Y')        /* ���T�L�ӫO����*/
            {
                stuHcc_lvl->q17_acc_sum_5y_value[i] = -1;  /* ���d���T,���L�ӫO���� =>  ifactor_bgn = -1 */ 
            }
            else
            {
                stuHcc_lvl->q17_acc_sum_5y_value[i] = stuHcc_fac.iAccidentSum5year;
            } 
        } 

        TRACE(" => �զX[%d]�GstuHcc_lvl->q17_acc_sum_5y_value = [%d]\n", i, stuHcc_lvl->q17_acc_sum_5y_value[i]);

        $EXECUTE preFactor2 INTO $stuHcc_lvl->p17_acc_sum_5y_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype,
            $stuHcc_lvl->q17_acc_sum_5y_value[i], $stuHcc_lvl->q17_acc_sum_5y_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� �e���~�߮ץ�ƫY��(q17_acc_sum_5y_value[%d],�渹[%s](�զX[%d]))", stuHcc_lvl->q17_acc_sum_5y_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p17_acc_sum_5y_factor = [%f]\n", i, stuHcc_lvl->p17_acc_sum_5y_factor[i]);
        
        
        /* ---------------  �i18:�L�h2�~�O�_���b�s�w��O�L�T���I�j----------------------------------*/
        itype = 18;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);
        
        if (stuHcc_fac.fHave_Newa_C_2y[0] == 'Y')
        {
            strcpy(stuHcc_fac.fHave_Newa_C_2y, "1");
        }
        else if (stuHcc_fac.fHave_Newa_C_2y[0] == 'N')
        {
            strcpy(stuHcc_fac.fHave_Newa_C_2y, "0");
        }
        
        strcpy(stuHcc_lvl->f18_have_newa_c_2y_value[i], stuHcc_fac.fHave_Newa_C_2y);

        TRACE(" => �զX[%d]�GstuHcc_lvl->f18_have_newa_c_2y_value = [%s]\n", i, stuHcc_lvl->f18_have_newa_c_2y_value[i]);


        $EXECUTE preFactor1 INTO $stuHcc_lvl->p18_have_newa_c_2y_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype, $stuHcc_lvl->f18_have_newa_c_2y_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� �L�h2�~�O�_���b�s�w��O�L�T���I(f18_have_newa_c_2y_value[%s],�渹[%s](�զX[%d]))", stuHcc_lvl->f18_have_newa_c_2y_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p18_have_newa_c_2y_factor = [%f]\n", i, stuHcc_lvl->p18_have_newa_c_2y_factor[i]);
        
        /* ---------------  �i19:�����ݩʡj----------------------------------*/
        itype = 19;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);
        
        $EXECUTE preCarSeries INTO $stuHcc_lvl->i19_series_value[i] USING $v_dPlyBeginDate_main[i], $stuHcc_fac.sBrandNo;
        
        TRACE(" => �զX[%d]�GstuHcc_lvl->i19_series_value = [%s]\n", i, stuHcc_lvl->i19_series_value[i]);
        
        $EXECUTE preFactor1 INTO $stuHcc_lvl->p19_series_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype, $stuHcc_lvl->i19_series_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� �����ݩ�(i19_series_value[%s],�渹[%s](�զX[%d]))", stuHcc_lvl->i19_series_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p19_series_factor = [%f]\n", i, stuHcc_lvl->p19_series_factor[i]);
        
        /* ---------------  �i20:��O�D������[�I�Ӽơj----------------------------------*/
        itype = 20;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);
        
        stuHcc_lvl->q20_ext_ins_notdmg_value[i] = iExtNotDmgCount[i];

        TRACE(" => �զX[%d]�GstuHcc_lvl->q20_ext_ins_notdmg_value = [%d]\n", i, stuHcc_lvl->q20_ext_ins_notdmg_value[i]);
  
        $EXECUTE preFactor2 INTO $stuHcc_lvl->p20_ext_ins_notdmg_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype,
            $stuHcc_lvl->q20_ext_ins_notdmg_value[i], $stuHcc_lvl->q20_ext_ins_notdmg_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� ��O�D������[�I�ӼƫY��(q20_ext_ins_notdmg_value[%d],�渹[%s](�զX[%d]))", stuHcc_lvl->q20_ext_ins_notdmg_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p20_ext_ins_notdmg_factor = [%f]\n", i, stuHcc_lvl->p20_ext_ins_notdmg_factor[i]);

        
        /* ---------------  �i21:��O������[�I�Ӽơj----------------------------------*/
        itype = 21;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);
        
        stuHcc_lvl->q21_ext_ins_isdmg_value[i] = iExtIsDmgCount[i];

        TRACE(" => �զX[%d]�GstuHcc_lvl->q21_ext_ins_isdmg_value = [%d]\n", i, stuHcc_lvl->q21_ext_ins_isdmg_value[i]);
  
        $EXECUTE preFactor2 INTO $stuHcc_lvl->p21_ext_ins_isdmg_factor[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype,
            $stuHcc_lvl->q21_ext_ins_isdmg_value[i], $stuHcc_lvl->q21_ext_ins_isdmg_value[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� ��O������[�I�ӼƫY��(q21_ext_ins_isdmg_value[%d],�渹[%s](�զX[%d]))", stuHcc_lvl->q21_ext_ins_isdmg_value[i], v_sNumber, i);
            goto errexit;
        }

        TRACE(" => �զX[%d]�GstuHcc_lvl->p21_ext_ins_isdmg_factor = [%f]\n", i, stuHcc_lvl->p21_ext_ins_isdmg_factor[i]);
        
        

        /* ---------------  �i0:���ůżơj----------------------------------*/

        itype = 0;

        TRACE("-----------------------   itype = [%d]----------------------\n", itype);

        stuHcc_lvl->pscore[i] =
            stuHcc_lvl->p1_sex_marriage_factor[i] *
            stuHcc_lvl->p2_age_factor[i] *
            stuHcc_lvl->p3_dmg_acc_sum_5y_factor[i] *
            stuHcc_lvl->p4_lia_acc_sum_5y_factor[i] *
            stuHcc_lvl->p5_duty_acc_sum_5y_factor[i] *
            stuHcc_lvl->p8_car_age_factor[i] *
            stuHcc_lvl->p10_lia_factor[i] *
            stuHcc_lvl->p11_brg_factor[i] *
            stuHcc_lvl->p12_ext_ins_sum_factor[i] *
            stuHcc_lvl->p13_ply_area_factor[i] *
            stuHcc_lvl->p14_cartype_year_factor[i] *
            stuHcc_lvl->p15_injure_factor[i] *
            stuHcc_lvl->p16_product_sum_factor[i] *
            stuHcc_lvl->p17_acc_sum_5y_factor[i] *
            stuHcc_lvl->p18_have_newa_c_2y_factor[i] *
            stuHcc_lvl->p19_series_factor[i] *
            stuHcc_lvl->p20_ext_ins_notdmg_factor[i] *
            stuHcc_lvl->p21_ext_ins_isdmg_factor[i];      
            


        TRACE(" => �զX[%d]�GstuHcc_lvl->pscore = [%f]\n", i, stuHcc_lvl->pscore[i]);

        $EXECUTE preFactor2 INTO $intQlevel[i] USING $stuHcc_lvl->drate[i], $stuHcc_lvl->iroute_main[i], $itype,
            $stuHcc_lvl->pscore[i], $stuHcc_lvl->pscore[i];
        if (SQLCODE == SQLNOTFOUND)
        {
            sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G�䤣�� ���ůż�(�`���� pscore[%f],�渹[%s](�զX[%d]))", stuHcc_lvl->pscore[i], v_sNumber, i);
            goto errexit;
        }
        stuHcc_lvl->qlevel[i] = intQlevel[i];

        TRACE(" => �զX[%d]stuHcc_lvl->qlevel = [%d]\n", i, stuHcc_lvl->qlevel[i]);

    }

    printf("end   get_ca_hcc_level_cartype() function\n");
    TRACE("***************************************\n\n\n");

    return M_CM_OK;

errexit:
    puts(strMsg);
    printf("end  get_ca_hcc_level_cartype() function (with error)\n");
    printf("***************************************\n\n");
    if (strlen(strMsg) == 0)
    {
        sprintf_s(strMsg, 250,"get_ca_hcc_level_cartype() Err�G SQLCODE=[%d], sqlerrmsg=[%s] sqlca.sqlerrd[1]=[%d]\n", SQLCODE, sqlca.sqlerrm, sqlca.sqlerrd[1]);
        return SQLCODE;
    }
    else
    {
        return -99999;
    }
}