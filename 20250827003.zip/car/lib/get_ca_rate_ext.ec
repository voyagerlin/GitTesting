/*
   Name       : get_ca_rate_ext

   Input      : v_irate         �O�v�N�� 
                v_icar_flag_ext �s�¨�   1�G�s���A2�G�¨�
                v_iparts        �O�T���O 1�G�����A2�G�ʤO�ǰʨt��
                v_qperiod       �O�T���
                v_qmiles        �O�T���{��
                v_irisk         ���I����
                v_pro_year      �s�y�~��
                v_drate_ym      �O�v�N��
                v_ibroker       �g���N��
                v_pro_month     �s�y���
                v_ply2_begin    ���N�ͮĤ� 
                v_fstart        �O�_�w�ҥγq������
                                (Y:�w�ҥ� N:���ҥ� ��L:�ѥ�FUNCTION�ˮ�)
                v_iofficer      �g��N��
                v_iroute        �q���N��
                v_irate_type    �O�v�O 
                v_iroute_comm   �~�ȱ���
                v_bzfrom        �O�o�q���N��
                v_fPlyEdr       P:�O��, E:���
                v_mdamage_cover �C�@�N�~�ƬG�̰����v���B(58�I�ؤ��O�B) 1030826001_C1 �O�T�I�O�v�p�⤽���վ�,�t�ηs�W�p��]�l
                                 
                
   return code: M_CM_OK         ���\
                v_mpure         �«O�O
                v_pextra_charge ���[�O��
                v_pbusiness
                v_sMsg          �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"
void end_get_ca_rate_ext( );

long get_ca_rate_ext( v_irate, v_icar_flag_ext, v_iparts, v_qperiod, v_qmiles, v_irisk, v_pro_year,
                      v_drate_ym, v_ibroker, v_pro_month, v_ply2_begin, v_fstart, v_iofficer, v_iroute,
                      v_irate_type, v_iroute_comm, v_bzfrom, v_fPlyEdr, v_mdamage_cover,
                      v_mpure, v_pextra_charge, v_pbusiness, v_sMsg)
$char    *v_irate, *v_icar_flag_ext, *v_iparts, *v_pro_year, *v_irisk, *v_drate_ym, *v_ibroker, *v_sMsg;
$char    *v_fstart, *v_iofficer, *v_iroute, *v_irate_type, *v_iroute_comm, *v_bzfrom, *v_fPlyEdr;
$long    *v_qperiod, *v_qmiles, v_pro_month, v_ply2_begin, v_mdamage_cover; 
$double  *v_mpure, *v_pextra_charge, *v_pbusiness;
{
  $long    qperiod, qmiles, rc; 
  $double  iPassYear;
  $double  mpure = 0, pextra_charge = 0, pextra_charge1, pbusiness, pmcover1_ext ;
  $char    drate_ym[5], f980401[2], iextra_charge[11], ibroker[11];
  char     ply2_begin_yy[4], ply2_begin_mm[3], ply2_begin_dd[3];
  
   /* �t�X�q���ĤG���q */
  char    sFstart[2], sFauth[2];
  $char   sIofficer[11], sIroute[21], sIrate_type[2], sIroute_comm[4], 
          sBzfrom[3],tmp_sMsg[512];
          
    $WHENEVER SQLERROR GOTO errexit;

    puts("");
    puts("******************************");
    puts("begin get_ca_rate_ext function");
    printf("    v_irate[%s], v_icar_flag_ext[%s], v_iparts[%s], v_qperiod[%d], \n"
           "    v_qmiles[%d], v_irisk[%s], v_pro_year[%s], v_drate_ym[%s], v_ibroker[%s] v_mdamage_cover[%ld] \n", 
               v_irate, v_icar_flag_ext, v_iparts, *v_qperiod, *v_qmiles, v_irisk, v_pro_year, v_drate_ym, v_ibroker,v_mdamage_cover);

    qperiod = *v_qperiod;
    qmiles = *v_qmiles;
    strcpy( drate_ym, v_drate_ym);
    strcpy( ibroker, v_ibroker);
    
    /* �t�X�q���G�ק� */
    /* 1.�O�_�w�ҥγq������ */
    strcpy(sFstart, v_fstart);
    strcpy(sIofficer, v_iofficer);
    strcpy(sIroute, v_iroute);
    strcpy(sIrate_type, v_irate_type);
    strcpy(sIroute_comm, v_iroute_comm);
    strcpy(sBzfrom, v_bzfrom);
	strcpy( tmp_sMsg, " ");
	
    if ((strcmp(sFstart,"Y") != 0) && (strcmp(sFstart,"N") != 0))
    { 
         /* �T�{�O�ҥγq���~�ȱ���α��v */
         if( v_fPlyEdr[0] != 'E')
         {
           rc = cm_get_route_auth("C", sIroute, sIofficer, sFstart, sFauth);
           if( rc != M_CM_OK)
           {
             strcpy(v_sMsg, cm_get_errmsg(rc));
             end_get_ca_rate_ext( v_sMsg);
                   return  rc;
           }
         }
         else strcpy( sFstart, "Y");
    }
    
    if (strcmp(sFstart,"Y") == 0)
         strcpy(iextra_charge, sBzfrom);
    else
    {
          /* �O�v�ۥѤ� */
          rc = get_broker_agent( ibroker, iextra_charge, v_sMsg);
          if( rc != M_CM_OK)
              return rc;
    }
    
    /* �O�v�ۥѤ� */
    $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
       INTO $f980401
       FROM ca_rate_date
      WHERE icode  = $drate_ym
        AND itable = 'cm_extra_charge';

    if(SQLCODE==SQLNOTFOUND) return M_CA_EXTRA_CHARGE_DRATE;

    printf("f980401[%s]\n", f980401);

    /* �O�v�ۥѤ� *//* 103.05 �O�T�I�@�ߧ�@�~�����[�O�βv�A�G�O��������12 */
    /*if( f980401[0] == '1')
    {   
        rc = get_cm_extra_charge_car( iextra_charge, drate_ym, &pextra_charge1, &pbusiness, 12, 58, v_sMsg);
        if( rc != M_CM_OK)
            return rc;
        *v_pbusiness = pbusiness;
    }
    else*/
        *v_pbusiness = 0;

    cm_long_split_3ymd(v_ply2_begin, ply2_begin_yy, ply2_begin_mm, ply2_begin_dd);
    printf("ply2_begin_yy[%s], ply2_begin_mm[%s], ply2_begin_dd[%s]\n", ply2_begin_yy, ply2_begin_mm, ply2_begin_dd);
    printf("v_pro_year[%d], v_pro_month[%d]\n", atoi(v_pro_year)-1911, v_pro_month);

    iPassYear = (double)(((atoi( ply2_begin_yy)+1911 - atoi(v_pro_year)) * 12) + (atoi( ply2_begin_mm) - v_pro_month)) / 12;

    printf("iPassYear[%f]\n", iPassYear);

    if( *v_icar_flag_ext == '1')
    {
        puts("�s��");
        $SELECT first 1 mpure, pextra_charge/100, iyear
           INTO $mpure, $pextra_charge
           FROM ca_rate_ext
          WHERE irate         = $v_irate
            AND icar_flag     = $v_icar_flag_ext
            AND iparts        = $v_iparts
            AND qperiod       = $qperiod
            AND qmiles        = $qmiles
            AND irisk         = $v_irisk
            AND iyear         >= $iPassYear 
          ORDER BY iyear;
    }
    else if( *v_icar_flag_ext == '2')
    {
        puts("�¨�");
        $SELECT first 1 mpure, pextra_charge/100, iyear
           INTO $mpure, $pextra_charge
           FROM ca_rate_ext
          WHERE irate         = $v_irate
            AND icar_flag     = $v_icar_flag_ext
            AND iparts        = $v_iparts
            AND qperiod       = $qperiod
            AND qmiles        = $qmiles
            AND irisk         = $v_irisk
            AND iyear         > $iPassYear 
          ORDER BY iyear;
    }
    else
    {
        sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "    v_irate[%s], v_icar_flag_ext[%s], v_iparts[%s], v_qperiod[%d], v_qmiles[%d],"
                         " v_irisk[%s], v_pro_year[%s] iPassYear[%f] not in ca_rate_ext(car143 set)\n", 
                           v_irate, v_icar_flag_ext, v_iparts, *v_qperiod, *v_qmiles, v_irisk, v_pro_year, iPassYear);
		strcpy( v_sMsg, tmp_sMsg);
        end_get_ca_rate_ext( v_sMsg);
        return M_CA_RATE_EXT_NO_GET;
    }

    if(SQLCODE==SQLNOTFOUND)
    {
        sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "    v_irate[%s], v_icar_flag_ext[%s], v_iparts[%s], v_qperiod[%d], v_qmiles[%d],"
                         " v_irisk[%s], v_pro_year[%s] not in ca_rate_ext(car143 set)\n", 
                           v_irate, v_icar_flag_ext, v_iparts, *v_qperiod, *v_qmiles, v_irisk, v_pro_year);
		strcpy( v_sMsg, tmp_sMsg);
        end_get_ca_rate_ext( v_sMsg);
        return M_CA_RATE_EXT_NO_GET;
    }
    sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "found mpure[%f], pextra_charge[%f]\n", mpure,  pextra_charge);
	strcpy( v_sMsg, tmp_sMsg);
    /*103.09.04 1030826001_C1:�O�T�I�O�v�p�⤽���վ�,�t�ηs�W�p��]�l */
    /* [���B�վ�Y��] */
    
    pmcover1_ext = 1.0; 
    $select chiname::DECIMAL INTO $pmcover1_ext  
       from car_code           
      where kind = '58' 
        and detail2 = $v_irisk
        and detail::integer  = $v_mdamage_cover;
                               
    printf("-- trace pmcover1_ext[%f]\n ",pmcover1_ext);     
          	
    *v_mpure = mpure * pmcover1_ext;
    
    printf("-- trace v_mpure[%f]\n ",v_mpure);     
    
    /*if( f980401[0] == '1')
        *v_pextra_charge = pextra_charge1;
    else*/
        *v_pextra_charge = pextra_charge;
    printf("-- v_pextra_charge  pextra_charge[%f]\n ",pextra_charge);  

    end_get_ca_rate_ext( v_sMsg);

    return M_CM_OK;

errexit:

  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy( v_sMsg, tmp_sMsg);
  end_get_ca_rate_ext( v_sMsg);
  return SQLCODE;


}

void end_get_ca_rate_ext( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_ca_rate_ext function");
  puts("******************************");
  puts("");
}
