/*
   Name       : checkPersonAndCarry.ec
   Input      : v_icar_type, v_cylinder, v_qpt, v_fpt
                
   return code: M_CM_OK ���\
   Output     : v_sMsg      �T��
*/

#include "commsgs.h"
#include "safeclib.h"

void end_ca_checkPersonAndCarry();
int no_check = 0;

long ca_checkPersonAndCarry(v_icar_type, v_cylinder, v_qpt, v_fpt, v_sMsg)
$char    *v_icar_type, *v_qpt, *v_fpt, *v_sMsg;
$char     *v_cylinder;
/*$double     *v_cylinder; 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
{
  $char icar_type[3];
  $char db_fpt[2];
  $double db_mincylinder=0,db_maxcylinder=0;
  $double db_minqpt=0,db_maxqpt=0;
  int legal_flag = 0;
  double int_cylinder = 0.0;
  char qpt[21],fpt[2],tmp_fpt[2];
  long fpt_check = 0;
  double f_qpt = 0;
  dec_t dec_qpt;
  
  
  $WHENEVER SQLERROR GOTO errexit;

  puts("");
  puts("******************************");
  puts("begin ca_checkPersonAndCarry");
  printf("     v_icar_type[%s],v_cylinder[%s],v_qpt[%s],v_fpt[%s]\n",v_icar_type,v_cylinder,v_qpt,v_fpt);

  strcpy(icar_type, trim(v_icar_type));
  /*int_cylinder = *v_cylinder; 1080902001-SC1-�Ʈ�q�X�W�p���I2�� */
  rstod(v_cylinder,&int_cylinder);
  
  strcpy(qpt, trim(v_qpt));
  f_qpt = atof(qpt);
  deccvasc( qpt, strlen(qpt), &dec_qpt);
  dectodbl( &dec_qpt, &f_qpt);
  strcpy(fpt, trim(v_fpt));  

  $SELECT fpt,min_qpt,max_qpt,min_cylinder,max_cylinder
     INTO $db_fpt,$db_minqpt,$db_maxqpt,$db_mincylinder,$db_maxcylinder
     FROM car_type
    WHERE icode = $icar_type
      AND fclass = '1';            

  if(SQLCODE==SQLNOTFOUND)
  {
      strcat( v_sMsg, "���إ��رƮ�q������ơA�Ь��ӫO��");                    
      end_ca_checkPersonAndCarry( v_sMsg);
      return M_CM_ORDINARY_CHECK;
   }
    

   	/** ������� **/
   	/** 1. P(�H), 2. T(��), 3. P OR T => �L�ˮ� **/
   		if (strncmp(db_fpt,"1",1) == 0)
   		{
   			strcpy(tmp_fpt,"P");
   		} else if (strncmp(db_fpt,"2",2) == 0)
   		{
   			strcpy(tmp_fpt,"T");
   		} else {
   			fpt_check = 1;
   		}

        printf("db�������[%s]input[%s]fpt_check[%d]\n",tmp_fpt,fpt,fpt_check);   		
   		/** �P�_��J���������O�_�ŦX�Ө��ئbDB����������� **/
   		if (fpt_check != 1 && strncmp(tmp_fpt,fpt,1) != 0)
   		{
   			legal_flag = 1;
   			strcat(v_sMsg,"������즳�~;");
   		}
   	
   	/** �����H�� **/
        printf("�������[%f],max[%f],min[%f]\n",f_qpt,db_maxqpt,db_minqpt);  
			if (db_maxqpt != 0 || db_minqpt != 0)
			{
   			if (f_qpt > db_maxqpt || f_qpt < db_minqpt)
   			{
   				legal_flag = 1;
   				strcat(v_sMsg,"�����H�Ʃξ��Ʀ��~;");
   			}
   		}
   		
	  	/** �Ʈ�q�ˮ� **/
        printf("�Ʈ�q[%f],max[%f],min[%f]\n",int_cylinder,db_maxcylinder,db_mincylinder);
			if (db_maxcylinder != 0 || db_mincylinder != 0)
			{  	
	  			if (int_cylinder > db_maxcylinder || int_cylinder < db_mincylinder)
   			{   			   				
   				legal_flag = 1;
   				strcat(v_sMsg,"�Ʈ�q���~;");
   			}
   		}
   		
   end_ca_checkPersonAndCarry( v_sMsg);
printf("legal_flag = [%d]\n",legal_flag);      
   if (legal_flag == 0) return M_CM_OK;
   else return M_CM_ORDINARY_CHECK;
   
errexit:

  sprintf_s( v_sMsg, 250,"SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  end_ca_checkPersonAndCarry( v_sMsg);
  return SQLCODE;   
}

void end_ca_checkPersonAndCarry( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end checkPersonAndCarry function");
  puts("******************************");
  puts("");
}
