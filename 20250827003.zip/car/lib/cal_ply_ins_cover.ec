/*
   Name       : cal_ply_ins_cover
   Input      : v_iIns    		�I�إN�� ex:34
                v_IfirstPlyInsCover
                v_sIcar_type		���إN��
                v_sFrate  		�O�v�N��
                v_rShort        	�u���v 
                v_abn_type              ���`�N��
                v_fdiscount             �u�f�_(Y/N)
                v_cal_itype_disc        �u�f�覡(1:�̩T�w���B,2:�̤�v)
                v_mdiscount             �u�f���B(�̩T�w���B�ɥΨӨ����v)
                v_pdiscount             �u�f��v
                v_provision             ���[����
                v_adjust_rate           �«O�O�[��T�פ�v
                v_deviation_rate        �«O�O�����v 
                v_ibroker               �g���N�� 
                v_safe_rate             �w�����I�[��T�עH
                v_manage_rate           �޲z���I�[��T�עH
                v_educated_rate         �g��ץ��]�l
                v_fstart       �O�_�w�ҥγq������
                               (Y:�w�ҥ� N:���ҥ� ��L:�ѥ�FUNCTION�ˮ�)
                v_iofficer     �g��N��
                v_iroute       �q���N��
                v_irate_type   �O�v�O 
                v_iroute_comm  �~�ȱ���
                v_bzfrom       �O�o�q���N��
                v_fPlyEdr      P:�O��, E:���
                v_ply_period  �O��O�� ( 103.04.30:1030407005_C1_�ӽзs�ӫ~�W�u-������X�O�I)
                
   return code: M_CM_OK ���\
   Output     : v_IfirstPlyInsCover.mcover_prem		ñ��O�O
                v_IfirstPlyInsCover.mdiscount	        ����
                v_IfirstPlyInsCover.mprem		�W���O�O
                v_IfirstPlyInsCover.mpure_prem 		�«O�O
                v_IfirstPlyInsCover.pextra_charge 	���[�O�βv
                v_sMsg      �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"
$include "ply_ins_cover.h";
$include "var_length.h";
double d45();
void end_cal_ply_ins_cover( );
struct PLY_INS_COVER *move_ply_ins_cover_curr2( );

long cal_ply_ins_cover( int    *v_iIns, 
                        struct PLY_INS_COVER *v_IfirstPlyInsCover,
                        char   *v_sIcar_type, 
                        char   *v_sFrate, 
                        double *v_rShort, 
                        char   *v_abn_type, 
                        char   *v_fdiscount, 
                        char   *v_cal_itype_disc, 
                        long   v_mdiscount, 		/* call by value */
                        double *v_pdiscount, 
                        char   *v_provision, 
                        double *v_adjust_rate,
                        double v_deviation_rate,
                        char   *v_ibroker,
                        double v_safe_rate,
                        double v_manage_rate,
                        double v_educated_rate,
                        double v_pshipping,
                        char   *v_fstart, 
                        char   *v_iofficer,
                        char   *v_iroute, 
                        char   *v_irate_type, 
                        char   *v_iroute_comm, 
                        char   *v_bzfrom,
                        char   *v_fPlyEdr,
                        int    v_ply_period,
                        char   *v_sMsg)
{
  $int     iIns, rtncode,ply_period;
  $long    mcoverage1, mcoverage2;
  $double  rMpremium, rPextra_charge, rPbusiness;
  $double  rMpremium_2, rPextra_charge_2, rPbusiness_2;
  $long    lMdiscount_sum, lMprem_sum;
  struct   PLY_INS_COVER *IcurrPlyInsCover;
  $char    iins_type[IINS_TYPE], icover_type[ICOVER_TYPE], iprem_cover_type[ICOVER_TYPE];
  $char    ins_type[IINS_TYPE];
  $long    mdeduct, msi_coverage, msi_premium;
  $long    msi_coverage_2, msi_premium_2;
  $char    isame_ins[7], frate[5], f980401[2];
  $double  provision_C=1.0;
  $char    sProvision_tmp[22];/* 1081225006-SC1-���ά�-�X�R���[���ڥN�X    �]�������20�X��+;�i��P�_*/
  
  /* �t�X�q���ĤG���q */
  char    sFstart[2], sFauth[2];
  $char   sIofficer[11], sIroute[21], sIrate_type[2], sIroute_comm[4], 
          sBzfrom[3];
  

  $WHENEVER SQLERROR GOTO errexit;
 
  puts("");
  puts("******************************");
  puts("begin cal_ply_ins_cover function");
  printf("v_iIns=[%d]\n", *v_iIns); 
  printf("v_sIcar_type=[%s]\n", v_sIcar_type); 
  printf("v_sFrate=[%s]\n", v_sFrate);
  printf("v_rShort[%f]\n", *v_rShort);
  printf("v_abn_type[%s]\n", v_abn_type);
  printf("v_fdiscount=[%s]\n", v_fdiscount);
  printf("v_cal_itype_disc=[%s]\n", v_cal_itype_disc); 
  printf("v_mdiscount=[%d]\n", v_mdiscount);
  printf("v_pdiscount[%f]\n", *v_pdiscount);
  printf("v_provision[%s]\n", v_provision);
  printf("v_adjust_rate[%f]\n", *v_adjust_rate);
  printf("v_deviation_rate[%f]\n", v_deviation_rate);
  printf("v_safe_rate[%f]\n", v_safe_rate);
  printf("v_manage_rate[%f]\n", v_manage_rate);
  printf("v_educated_rate[%f]\n", v_educated_rate);
  printf("v_pshipping[%f]\n",v_pshipping);
  printf("v_ply_period=[%d]\n", v_ply_period); 
  
  strcpy(sProvision_tmp,"");/* 1081225006-SC1-���ά�-�X�R���[���ڥN�X    �]�������20�X��+;�i��P�_*/ 
  sprintf_s(sProvision_tmp,sizeof sProvision_tmp,"%s;" ,trim(v_provision));
  printf("sProvision_tmp[%s]\n", sProvision_tmp);
  /* �t�X�q���G�ק� */
    /* 1.�O�_�w�ҥγq������ */
    strcpy(sFstart, v_fstart);
    strcpy(sIofficer, v_iofficer);
    strcpy(sIroute, v_iroute);
    strcpy(sIrate_type, v_irate_type);
    strcpy(sIroute_comm, v_iroute_comm);
    strcpy(sBzfrom, v_bzfrom);
    if ((strcmp(sFstart,"Y") != 0) && (strcmp(sFstart,"N") != 0))
    { 
         /* �T�{�O�ҥγq���~�ȱ���α��v */
         if( v_fPlyEdr[0] != 'E')
         {
             rtncode = cm_get_route_auth("C", sIroute, sIofficer, sFstart, sFauth);
              if( rtncode != M_CM_OK)
              {
                strcpy(v_sMsg, cm_get_errmsg(rtncode));
                end_cal_ply_ins_cover( v_sMsg);
                      return  rtncode;
              }
         }
         else strcpy( sFstart, "Y");
    }
  
  strcpy( frate, v_sFrate);

  /* �O�v�ۥѤ� */
  $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
     INTO $f980401
     FROM ca_rate_date
    WHERE icode  = $frate
                   AND itable = 'cm_extra_charge';

  if (SQLCODE==SQLNOTFOUND)  return M_CA_EXTRA_CHARGE_DRATE;

  printf("f980401[%s]\n", f980401);

  IcurrPlyInsCover = v_IfirstPlyInsCover;
  
  while( IcurrPlyInsCover)
  {
      strcpy( iins_type, IcurrPlyInsCover->iins_type);
      strcpy( iprem_cover_type, IcurrPlyInsCover->iprem_cover_type);

      $SELECT iprem_cover_type
         INTO $iprem_cover_type
         FROM insurance_cover
        WHERE iins_type   = $iins_type
          AND icover_type = $iprem_cover_type; 

      if( SQLCODE == SQLNOTFOUND)
      {
          sprintf_s( v_sMsg, 250,"iins_type[%s], iprem_cover_type[%s]"
                                 "not in insurance_cover\n", iins_type, iprem_cover_type);
          end_cal_ply_ins_cover( v_sMsg);
          return M_CA_PREM_COVER_TYPE_ERR;
      }

      strcpy( IcurrPlyInsCover->iprem_cover_type, iprem_cover_type);

      /* �_�l�� 0 */
      IcurrPlyInsCover->mpure_prem_n  = 0;
      IcurrPlyInsCover->mprem_n       = 0;
      IcurrPlyInsCover->mcover_prem_n = 0;
      
      printf("     IcurrPlyInsCover->iins_type    [%s]\n"
             "     IcurrPlyInsCover->cover_name   [%s]\n"
             "     IcurrPlyInsCover->icover_type  [%s]\n"
             "     IcurrPlyInsCover->iprem_cover_type  [%s]\n"
             "     IcurrPlyInsCover->mcover       [%d]\n"
             "     IcurrPlyInsCover->mcover_prem  [%d]\n"
             "     IcurrPlyInsCover->mdiscount    [%d]\n"
             "     IcurrPlyInsCover->mprem        [%d]\n"
             "     IcurrPlyInsCover->mpure_prem   [%f]\n"
             "     IcurrPlyInsCover->pextra_charge[%f]\n",
                   IcurrPlyInsCover->iins_type,
                   IcurrPlyInsCover->cover_name,
                   IcurrPlyInsCover->icover_type,
                   IcurrPlyInsCover->iprem_cover_type,
                   IcurrPlyInsCover->mcover,
                   IcurrPlyInsCover->mcover_prem,
                   IcurrPlyInsCover->mdiscount,
                   IcurrPlyInsCover->mprem,
                   IcurrPlyInsCover->mpure_prem,
                   IcurrPlyInsCover->pextra_charge );
      puts("");
      

      IcurrPlyInsCover = IcurrPlyInsCover->next;
  }
  
  iIns = *v_iIns;    
  
  /******************************************�p��W���O�O***************************************** */
  switch (iIns)
  {
      case 34: case 87: case 115:
      { 
          IcurrPlyInsCover = move_ply_ins_cover_curr2( v_IfirstPlyInsCover, &iIns, "001");
          mcoverage1 = IcurrPlyInsCover->mcover;
          IcurrPlyInsCover = move_ply_ins_cover_curr2( v_IfirstPlyInsCover, &iIns, "002");
          mcoverage2 = IcurrPlyInsCover->mcover;
          
          /* ���|���ݪ� */
          mdeduct =1; 
          rtncode = get_cover_vs_premium( v_sIcar_type, iIns, mcoverage1, mcoverage2, mdeduct, v_sFrate, v_ibroker,
                                          sFstart, sIofficer, sIroute, sIrate_type, sIroute_comm, sBzfrom,
                                          &rMpremium, &rPextra_charge, &rPbusiness, isame_ins, &msi_coverage, &msi_premium,v_ply_period,
                                          v_sMsg );
          if( rtncode != M_CM_OK) return M_CA_34_1_NOT_FOUND;          
          	
          if (v_ply_period > 12){
          	  /* 2�~���O�v */
	          mdeduct =21; 
	          rtncode = get_cover_vs_premium( v_sIcar_type, iIns, mcoverage1, mcoverage2, mdeduct, v_sFrate, v_ibroker,
	                                          sFstart, sIofficer, sIroute, sIrate_type, sIroute_comm, sBzfrom,
	                                          &rMpremium_2, &rPextra_charge_2, &rPbusiness_2, isame_ins, &msi_coverage_2, &msi_premium_2,v_ply_period,
	                                          v_sMsg );	
	          if( rtncode != M_CM_OK) return M_CA_34_1_NOT_FOUND;            	
          }
          
          IcurrPlyInsCover = move_ply_ins_cover_curr2( v_IfirstPlyInsCover,&iIns, IcurrPlyInsCover->iprem_cover_type);

          if (iIns==115){       
              if(v_ply_period <= 12 ){         /* <= 1�~ */                  
		          IcurrPlyInsCover->mpure_prem   = rMpremium * (*v_rShort) ;
		                                          
              }else if( v_ply_period == 24 ){  /* 1�~11�Ӥ�H�W��2�~�� */
		          IcurrPlyInsCover->mpure_prem   = rMpremium_2 ;
		          
              }else if((v_ply_period > 12) && (v_ply_period < 24)){  /* �j��1�~�B �p�� 1�~11�Ӥ� */
              	
                  IcurrPlyInsCover->mpure_prem =  rMpremium +
                          ((rMpremium_2-rMpremium) * ((v_ply_period-12)/12.0));
              }else{
                  return M_CA_47_PERIOD; /*4533=�ӫO�~�����~�A�Ь��ӫO��*/
              }    
              
		      IcurrPlyInsCover->mpure_prem_n = IcurrPlyInsCover->mpure_prem;
              IcurrPlyInsCover->mprem   = (long)d45( (IcurrPlyInsCover->mpure_prem / ( 1 - rPextra_charge)) ,0);
	          IcurrPlyInsCover->mprem_n = (long)d45( (IcurrPlyInsCover->mpure_prem_n / ( 1 - rPextra_charge)) ,0);
                                             	   	  	          
          }else{
	          IcurrPlyInsCover->mpure_prem   = rMpremium * (*v_rShort) * (1 + v_deviation_rate/100.0);
	          IcurrPlyInsCover->mpure_prem_n = IcurrPlyInsCover->mpure_prem;

              
	           /* if( v_provision[0] == 'F' || v_provision[0] == 'B' || v_provision[0] == 'G' )car9804233�j�v���[���� */
               /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X  ��g�k���~�ݤ@�ֽվ��קK�~�z�� */
               if (( strstr(sProvision_tmp, "F;") != '\0') || ( strstr(sProvision_tmp, "B;") != '\0') || ( strstr(sProvision_tmp, "G;") != '\0'))
	              IcurrPlyInsCover->mpure_prem = rMpremium * (1 + *v_adjust_rate) * (*v_rShort);
	
	           /*if( v_provision[0] == 'B' || v_provision[0] == 'A') car9804233�j�v���[���� */
               if (( strstr(sProvision_tmp, "B;") != '\0') || ( strstr(sProvision_tmp, "A;") != '\0'))
	          {
	              IcurrPlyInsCover->mpure_prem *= ( 1 + (v_safe_rate/100.0) + (v_manage_rate/100.0) );
	              IcurrPlyInsCover->mpure_prem *= ( v_educated_rate); 
	          }
	          
	           /* if( v_provision[0] == 'C')car9808043 �f�B�~���[���� */
               if (( strstr(sProvision_tmp, "C;") != '\0'))
	          {
	          	  IcurrPlyInsCover->mpure_prem *= ( v_pshipping);
	          }
	          
	          IcurrPlyInsCover->mprem = (long)d45( (IcurrPlyInsCover->mpure_prem / ( 1 - rPextra_charge)) ,0);
	          IcurrPlyInsCover->mprem_n = (long)d45( (IcurrPlyInsCover->mpure_prem_n / ( 1 - rPextra_charge)) ,0);
	          /* �W���O�O�ĥ|�ˤ��J�A�P�U�O��½T�{�����G */
          }
          puts("");
          printf("001:mcoverage1[%d], 002:mcoverage2[%d]\n"
                 "IcurrPlyInsCover->mpure_prem   [%f]\n"
                 "IcurrPlyInsCover->pextra_charge[%f]\n"
                 "IcurrPlyInsCover->mprem        [%d]\n", 
                 mcoverage1, mcoverage2, IcurrPlyInsCover->mpure_prem, 
                 IcurrPlyInsCover->pextra_charge, IcurrPlyInsCover->mprem);
          /* -----------------------------------------------------------------------------------------*/
          
          /* ���G���ݪ� */
          IcurrPlyInsCover = move_ply_ins_cover_curr2( v_IfirstPlyInsCover, &iIns, "003");
          mcoverage1 = IcurrPlyInsCover->mcover;
          IcurrPlyInsCover = move_ply_ins_cover_curr2( v_IfirstPlyInsCover, &iIns, "004");
          mcoverage2 = IcurrPlyInsCover->mcover;
          mdeduct =2; 
          rtncode = get_cover_vs_premium( v_sIcar_type, iIns, mcoverage1, mcoverage2, mdeduct, v_sFrate, v_ibroker,
                                          sFstart, sIofficer, sIroute, sIrate_type, sIroute_comm, sBzfrom,
                                          &rMpremium, &rPextra_charge, &rPbusiness, isame_ins, &msi_coverage, &msi_premium,v_ply_period,
                                          v_sMsg );
          if(SQLCODE==SQLNOTFOUND) return M_CA_34_2_NOT_FOUND;

          if (v_ply_period > 12){
          	  /* 2�~���O�v */
	          mdeduct =22; 
	          rtncode = get_cover_vs_premium( v_sIcar_type, iIns, mcoverage1, mcoverage2, mdeduct, v_sFrate, v_ibroker,
	                                          sFstart, sIofficer, sIroute, sIrate_type, sIroute_comm, sBzfrom,
	                                          &rMpremium_2, &rPextra_charge_2, &rPbusiness_2, isame_ins, &msi_coverage_2, &msi_premium_2,v_ply_period,
	                                          v_sMsg );	
	          if( rtncode != M_CM_OK) return M_CA_34_2_NOT_FOUND;            	
          }
          
          IcurrPlyInsCover = move_ply_ins_cover_curr2( v_IfirstPlyInsCover,&iIns,IcurrPlyInsCover->iprem_cover_type);

         if (iIns==115){       
              if(v_ply_period <= 12 ){         /* <= 1�~ */                  
		          IcurrPlyInsCover->mpure_prem   = rMpremium * (*v_rShort) ;
		                                          
              }else if( v_ply_period == 24 ){  /* 1�~11�Ӥ�H�W��2�~�� */
		          IcurrPlyInsCover->mpure_prem   = rMpremium_2 ;
		          
              }else if((v_ply_period > 12) && (v_ply_period < 24)){  /* �j��1�~�B �p�� 1�~11�Ӥ� */
              	
                  IcurrPlyInsCover->mpure_prem = rMpremium +
                          ((rMpremium_2-rMpremium) * ((v_ply_period-12)/12.0));
              }else{
                  return M_CA_47_PERIOD; /*4533=�ӫO�~�����~�A�Ь��ӫO��*/
              }    
              
		      IcurrPlyInsCover->mpure_prem_n = IcurrPlyInsCover->mpure_prem;
              IcurrPlyInsCover->mprem   = (long)d45( (IcurrPlyInsCover->mpure_prem / ( 1 - rPextra_charge)) ,0);
	          IcurrPlyInsCover->mprem_n = (long)d45( (IcurrPlyInsCover->mpure_prem_n / ( 1 - rPextra_charge)) ,0);
                                             	   	  	          
          }else{
          	
	          IcurrPlyInsCover->mpure_prem   = rMpremium * (*v_rShort) * (1 + v_deviation_rate/100.0);
	          IcurrPlyInsCover->mpure_prem_n = IcurrPlyInsCover->mpure_prem;
              
              /* 1081225006-SC1-���ά�-�X�R���[���ڥN�X  �վ�provision�ҽk�d�߼g�k�קK�~�z�� F->F99*
               if( v_provision[0] == 'F' || v_provision[0] == 'B' || v_provision[0] == 'G') 
             */
             /* car9804233�j�v���[���� */
              if( ( strstr(sProvision_tmp, "F;") != '\0')|| ( strstr(sProvision_tmp, "B;") != '\0') || ( strstr(sProvision_tmp, "G;") != '\0')) 
	              IcurrPlyInsCover->mpure_prem = rMpremium * (1 + *v_adjust_rate) * (*v_rShort);
	
	           /* car9804233�j�v���[���� if( v_provision[0] == 'B' || v_provision[0] == 'A')*/
               if( ( strstr(sProvision_tmp, "B;") != '\0')|| ( strstr(sProvision_tmp, "A;") != '\0'))
	          {
	              IcurrPlyInsCover->mpure_prem *= ( 1 + (v_safe_rate/100.0) + (v_manage_rate/100.0) );
	              IcurrPlyInsCover->mpure_prem *= ( v_educated_rate); 
	          }
	           /* car9808043 �f�B�~���[���� if( v_provision[0] == 'C')*/
               if (strstr(sProvision_tmp, "C;") != '\0')
	          {
	          	  IcurrPlyInsCover->mpure_prem *= ( v_pshipping);
	          }
	          
	          IcurrPlyInsCover->mprem = (long)d45( (IcurrPlyInsCover->mpure_prem / ( 1 - rPextra_charge)) ,0);
	          IcurrPlyInsCover->mprem_n = (long)d45( (IcurrPlyInsCover->mpure_prem_n / ( 1 - rPextra_charge)) ,0);
	          /* �W���O�O�ĥ|�ˤ��J�A�P�U�O��½T�{�����G */
          }
          puts("");
          printf("003:mcoverage1[%d], 004:mcoverage2[%d]\n"
                 "IcurrPlyInsCover->mpure_prem   [%f]\n"
                 "IcurrPlyInsCover->pextra_charge[%f]\n"
                 "IcurrPlyInsCover->mprem        [%d]\n", 
                 mcoverage1, mcoverage2, IcurrPlyInsCover->mpure_prem, 
                 IcurrPlyInsCover->pextra_charge, IcurrPlyInsCover->mprem);          
          break;
      }
      default:
      {
          sprintf_s( v_sMsg, 250,"iIns[%d]�I�ثO�B�O�O�p�⤽�����]�w in function cal_ply_ins_cover\n", iIns);
          end_cal_ply_ins_cover( v_sMsg);
          return M_CA_CALC_NOT_SET;
          break;
      }
  }

  /******************************************�p��ñ��O�O***************************************** */

  lMprem_sum = 0;
  IcurrPlyInsCover = v_IfirstPlyInsCover;
  while( IcurrPlyInsCover)
  {
      /* �[�`���I�ت��W���O�O,���u�f���T�w���B�ɥΨӭ˱���v��X���u�f���B */
      if( iIns == atoi( IcurrPlyInsCover->iins_type))
      {
          lMprem_sum = lMprem_sum + IcurrPlyInsCover->mprem;
          IcurrPlyInsCover->pextra_charge = rPextra_charge;
          IcurrPlyInsCover->pbusiness = rPbusiness;
      }

      IcurrPlyInsCover = IcurrPlyInsCover->next;
  }
  printf("[%d]�I�ت��W���O�OlMprem_sum[%d]\n", iIns, lMprem_sum);

  if ( v_cal_itype_disc[0] == '1')    /*  �̩T�w���B  */
  {
      if( lMprem_sum != 0)
          *v_pdiscount = d45( (double)v_mdiscount / (double)lMprem_sum * 100, 2);
      else
          *v_pdiscount = 0;
      printf("�̩T�w���B�˱��u�f��vv_pdiscount=[%f]\n", *v_pdiscount);
  }

  /* �p���u�f�Mñ��O�O */
  lMdiscount_sum = 0;
  IcurrPlyInsCover = v_IfirstPlyInsCover;
  while( IcurrPlyInsCover)
  {
      if( iIns == atoi( IcurrPlyInsCover->iins_type))
      {
          if (*v_fdiscount == 'N')
          {
              IcurrPlyInsCover->mdiscount   = 0; 
              IcurrPlyInsCover->mdiscount_n = 0; 
          }
          else if (*v_fdiscount == 'Y' || *v_fdiscount == '')
          {
              IcurrPlyInsCover->mdiscount   = (long)d45( (IcurrPlyInsCover->mprem * (*v_pdiscount) / 100)   ,0);
              IcurrPlyInsCover->mdiscount_n = (long)d45( (IcurrPlyInsCover->mprem_n * (*v_pdiscount) / 100) ,0);
          }
          /* �u�f�ĥ|�ˤ��J�A�P�U�O��½T�{�����G */

          lMdiscount_sum = lMdiscount_sum + IcurrPlyInsCover->mdiscount;

	  /* �������`�~�p��O�O�A���`�O�O��user��J */
          if( *v_abn_type !='Z' && *v_abn_type != 'Y')
          {
              IcurrPlyInsCover->mcover_prem =   IcurrPlyInsCover->mprem   - IcurrPlyInsCover->mdiscount;
              IcurrPlyInsCover->mcover_prem_n = IcurrPlyInsCover->mprem_n - IcurrPlyInsCover->mdiscount_n;
          }
          else
          {
              /* ���`�O�O��user��J���i�C��W���O�O */
              if( IcurrPlyInsCover->mcover_prem < IcurrPlyInsCover->mpure_prem)
              {
                  sprintf_s( v_sMsg, 250,"iins_type[%d], icover_type[%s]"
                                         "��user��J�����`�O�O[%d]�C��M�I�O�O[%f]\n",
                           iIns, IcurrPlyInsCover->icover_type, IcurrPlyInsCover->mcover_prem, IcurrPlyInsCover->mpure_prem);
                  end_cal_ply_ins_cover( v_sMsg);
                  return M_CA_PREMIUM_ERROR1;
              }
              if( f980401[0] == '1')
              {
                  /* �O�v�ۥѤƤ���,�վ�O�O��O�O�̪��[�O�βv�]�w�Ȧ^���M�I�O�O
                     (�������[�O�βv��v����)�C */
                  IcurrPlyInsCover->mpure_prem =  
                     (long)d45( (IcurrPlyInsCover->mcover_prem * (1-IcurrPlyInsCover->pextra_charge) ) ,0);
              }
          }
      }
      IcurrPlyInsCover = IcurrPlyInsCover->next;
  }

  if ( v_cal_itype_disc[0] == '1')    /*  �̩T�w���B  */
  {
      printf("�̩T�w���B�˱���v��X���u�f���B[%d], �T�w�u�f���B[%d]\n", lMdiscount_sum, v_mdiscount);
      if( lMdiscount_sum != v_mdiscount) /* �̩T�w���B�˱���v��X���u�f���B != �T�w�u�f���B */
      {
          puts("���۵�");
          IcurrPlyInsCover = v_IfirstPlyInsCover;

          while( IcurrPlyInsCover)
          {
              if( iIns == atoi( IcurrPlyInsCover->iins_type))
              {
                  /* �N�t�B��즳�u�f���Ĥ@����� */
                  if( IcurrPlyInsCover->mprem - IcurrPlyInsCover->mcover_prem != 0)
                  {
                      IcurrPlyInsCover->mcover_prem = IcurrPlyInsCover->mcover_prem + (v_mdiscount - lMdiscount_sum);
                      IcurrPlyInsCover->mcover_prem_n = IcurrPlyInsCover->mcover_prem_n + (v_mdiscount - lMdiscount_sum);
                      break;
                  }
              }
              IcurrPlyInsCover = IcurrPlyInsCover->next;
          }
      }
  }

  end_cal_ply_ins_cover( v_sMsg);

  return M_CM_OK;

errexit:

  sprintf_s( v_sMsg, 250,"SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  end_cal_ply_ins_cover( v_sMsg);
  return SQLCODE;

}

void end_cal_ply_ins_cover( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end cal_ply_ins_cover function");
  puts("******************************");
  puts("");
}



double d45(num,num1)
double num;
int num1;
{
    long tmplong;
    double var1;
    double ten;
    int i;

    ten = 1;
    for(i = 1 ;i<=num1;i++)
    ten *= 10;

    num *= ten;
    if (num >= 0) var1 = 0.500000000001;
    else var1 = (-0.500000000001);

    num = num + var1;
    tmplong = num;

    num = tmplong/ten;
    return(num);
}