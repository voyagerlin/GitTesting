#include "commsgs.h"
long ca_get_riv_fstatus( v_sIquotation, v_sFstatus)
$char v_sIquotation[11], v_sFstatus[2];
{
   $WHENEVER SQLERROR GOTO errexit;
    $SELECT fstatus
       INTO $v_sFstatus
       FROM riv_quotation
      WHERE iquotation = $v_sIquotation;
    printf("In ca_get_riv_fstatus ==> iquotation[%s], fstatus[%s] \n", v_sIquotation, v_sFstatus);
    return M_CM_OK;

errexit:
   printf( "ca_get_riv_fstatus SQLCODE[%d], sqlca.sqlerrm[%s]\n",
                        SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
