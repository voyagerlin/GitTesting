/*
   Name       : get_age
   Input      : sDbirth       ex: 55/12/31
                sDply_begin   ex: 95/07/15 
   return code: M_CM_OK ���\
   Output     : rAge          ��T�~��
                v_sMsg  �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include <math.h>
#include "safeclib.h"
void end_get_age( );

long get_age( sDbirth, sDply_begin, rAge, v_sMsg)
$char    *sDbirth, *sDply_begin, *v_sMsg;
$double  *rAge;
{
  $long   dply_begin, dbirth, date1 = 0, iTmp, tmpDate = 0;
  $double iYear, age1 = 0, iYearTmp;
  $char   sTmp[1024],tmp_sMsg[512];

  puts("");
  puts("******************************");
  puts("Begin get_age function");
  printf("     sDbirth=[%s], sDply_begin=[%s]\n", sDbirth, sDply_begin);
  strcpy( tmp_sMsg, " ");

  if( strlen( trim(sDbirth)) == 0){
      *rAge = 0;
  }else
  {
  	  /* 104.03.24 fix ����e or 0�~) */
      if ( sDbirth[0]=='-' || ( sDbirth[0]=='0' && sDbirth[1]=='0' && sDbirth[2]=='0' )){
      	 sDbirth[0] = '0' ; sDbirth[1] = '0' ; sDbirth[2] = '1' ;
      	 printf("  fixed sDbirth = [%s]\n", sDbirth);
      }
        	
      dply_begin = cm_cdate_lng( sDply_begin); /* ����~��long */
      dbirth     = cm_cdate_lng( sDbirth);     /* ����~��long */

      iYearTmp = (double)(dply_begin - dbirth) / 366;
      printf("iYearTmp[%f]\n", iYearTmp);

      iYear = floor(iYearTmp); /* ����Ʀ~ */
      printf("�ͮĤ��ͤ骺��Ʀ~(���~�t�|���վ�)[%f]\n", iYear);

      iTmp = iYear+1;
      $select first 1 date_add( $dbirth, $iTmp units year)
         into $tmpDate
         from systables;

      printf("�ͤ��ͮĤ��Ʀ~����@�~�᪺���[%s]\n", cm_long_3ymd(tmpDate));

      while ( tmpDate <= dply_begin)
      {
          iYear = iYear + 1;

          $select first 1 date_add( $tmpDate, 1 units year)
             into $tmpDate
             from systables;
      }

      printf("�ͮĤ��ͤ骺��Ʀ~(�վ��)[%f]\n", iYear);

      iTmp = dtoi(iYear);
      $select first 1 date_add( $dbirth, $iTmp units year)
         into $date1
         from systables;

      printf("iYear[%f], date1[%s], dply_begin[%s]\n", iYear, cm_long_3ymd(date1), cm_long_3ymd(dply_begin));

      $select first 1 ($dply_begin - $date1)::integer / (date_add( $date1, interval(1) year to year) - $date1)::integer
         into $age1
         from systables;

     printf("SQLCODE[%d]\n�ͮĤ��ͤ馩����Ʀ~�Ѿl���p�Ʀ~����[%f]\n", SQLCODE, age1);

      *rAge = iYear + age1;
      if ( *rAge < 0) *rAge = 0;

  }

  sprintf_s( tmp_sMsg, sizeof tmp_sMsg,"�ͤ�[%s],�ͮĤ�[%s], ��T�~��(�t�p��)[%f]\n", sDbirth, sDply_begin, *rAge);
  strcpy( v_sMsg, tmp_sMsg);
  printf("v_sMsg=[%s]\n",v_sMsg);
  end_get_age( v_sMsg);

  return M_CM_OK;

}

void end_get_age( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("End get_age function");
  puts("******************************");
  puts("");
}

