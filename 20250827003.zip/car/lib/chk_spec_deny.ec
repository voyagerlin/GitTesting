/*
   Name       : chk_spec_deny
   Input      : v_ipolicy, v_icard, v_iassured, v_iapplicant
   return code: M_CM_OK ���\
   Output     : v_sMsg      �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"

#define MsgLen 512

void end_chk_spec_deny( );

long chk_spec_deny( v_ipolicy, v_icard, v_iassured, v_iapplicant, v_sMsg)
$char    *v_ipolicy, *v_icard, *v_iassured, *v_iapplicant, *v_sMsg;
{
  $int  iCount=0;
  strcpy(v_sMsg," "); 
  
  $WHENEVER SQLERROR GOTO errexit;

  puts("");
  puts("***********************************");
  puts("begin chk_spec_deny");
  
  printf("     v_ipolicy=[%s]\n"	, v_ipolicy);
  printf("     v_icard=[%s]\n"		, v_icard);
  printf("     v_iassured=[%s]\n"	, v_iassured);
  printf("     v_iapplicant=[%s]\n"	, v_iapplicant);
  
  iCount = 0;

  $select count(*) into $iCount
     from car_spec_policy
    where (   inumber = $v_ipolicy 
           or inumber = $v_icard 
           or inumber = $v_iassured 
           or inumber = $v_iapplicant)
      and check_fedr[10] = '1';
      
  if (iCount == 0)
  {
      sprintf_s(v_sMsg, MsgLen, "�O���ƥ����� \n");
      end_chk_spec_deny( v_sMsg);
      return M_CM_OK;
  }    
  else
  {
      sprintf_s(v_sMsg, MsgLen, " �O�������� \n");
      end_chk_spec_deny( v_sMsg);
      return M_CA_SPEC_DENY;
  }    


errexit:
  sprintf_s(v_sMsg, MsgLen, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]); 
  end_chk_spec_deny( v_sMsg);
  return SQLCODE;
}

void end_chk_spec_deny( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end chk_spec_deny function");
  puts("*********************************");
  puts("");
}

