/*
   Name       : chk_holiday
   Purpose    : �̿�J�������ca_holidayŪ���Ӥ���O�_������,�Y�O������^�ǤU�@�Ӥu�@��,
                �Y�D����h�^�ǶǤJ�����

   Input      : v_before_date          function�e�ݶǨӪ����                

   return code: M_CM_OK          ���\
                v_after_date     �^�Ǫ����
                v_sMsg           �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"
void end_chk_holiday( );

long chk_holiday( char   *v_before_date,
                  char   *v_after_date,                  
                  char   *v_sMsg)
{
  long     rtncode;
  $char    before_date[11], after_date[11], tmp_sMsg[512];  
  $int     h_count=0;

    $WHENEVER SQLERROR GOTO errexit;

    puts("");
    puts("******************************");
    puts("begin chk_holiday function");
printf("    v_before_date[%s]\n", v_before_date);

    strcpy(before_date, cm_to_infdate(v_before_date)); 
    strcpy( tmp_sMsg, " ");
	
    for(;;)
   {
      $SELECT count(*)
         INTO $h_count
         FROM ca_holiday
        WHERE holiday_bgn <=  $before_date
          AND holiday_end >=  $before_date;
printf("h_count[%d]\n",h_count);          
          
      if(h_count == 0)
      {
      	/* �D���� */        
      	break;
      }	    
      else
      {
      	/* ���� */
      	$SELECT max(holiday_end)+1
           INTO $after_date
           FROM ca_holiday
          WHERE holiday_bgn <=  $before_date
            AND holiday_end >=  $before_date;
            
        if(SQLCODE == 0)
        {
        	strcpy(before_date, after_date); 
        }	     
      }
   }
   strcpy(v_after_date, cm_from_infdate_100(before_date)); 
printf("v_after_date[%s]\n",v_after_date);   

sprintf_s( tmp_sMsg, sizeof tmp_sMsg,"�U�@�u�@�鬰[%s]\n", before_date);
    strcpy( v_sMsg, tmp_sMsg);
    end_chk_holiday( v_sMsg);

    return M_CM_OK;

errexit:

  sprintf_s( tmp_sMsg, sizeof tmp_sMsg,"SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy( v_sMsg, tmp_sMsg);
  end_chk_holiday( v_sMsg);
  return SQLCODE;

}

void end_chk_holiday( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end chk_holiday function");
  puts("******************************");
  puts("");
}
