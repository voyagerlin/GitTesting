/*
   Name       : chk_working_date
   Purpose    : 1. �ΰj��Ū����J�������ca_holiday�T�{�Ӥ���O�_������,
                �Y�O������h�p���ܼ�(cnt)���[�@,�Y�D����h�p���ܼ�(cnt)�[�@,
                ����p���ܼƻP�ǤJ���u�@�ѼƧk�X�h���X�j��
                2. �N�ǤJ���u�@�ѼƧk�X������^��

   Input      : v_before_date, v_working_day   function�e�ݶǨӪ����,�H�Τu�@�Ѽ�              

   return code: M_CM_OK          ���\
                v_after_date     �^�Ǫ����
                v_sMsg           �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"

void end_chk_working_date( );

long chk_working_date( char   *v_before_date, int *v_working_day,
                  char   *v_after_date,                  
                  char   *v_sMsg)
{
  long     rtncode;
  $char    before_date[11], after_date[11],tmp_sMsg[512];  
  $int     h_count=0;
  int      i=1;

    $WHENEVER SQLERROR GOTO errexit;

    puts("");
    puts("******************************");
    puts("begin chk_working_date function");
printf("    v_before_date[%s],working days[%d]\n", v_before_date, v_working_day);

    strcpy(before_date, cm_to_infdate(v_before_date)); 
    strcpy(after_date, " ");
    strcpy( tmp_sMsg, " ");
	
   for(i=1;i<=v_working_day;i++)
   {   	   	   	   	
   	h_count = 0;
   	
      $SELECT count(*)
         INTO $h_count
         FROM ca_holiday
        WHERE holiday_bgn <=  $before_date
          AND holiday_end >=  $before_date;
printf("h_count[%d],i[%d],before_date[%s]\n",h_count,i,before_date);                      
      
      if(h_count == 0)
      {
      	/* �D���� */              	                   	
      	strcpy(before_date,cm_edate2_add( before_date, 1, before_date));
      }	    
      else
      {
      	/* ���� */
      	$SELECT max(holiday_end)    	
           INTO $after_date
           FROM ca_holiday
          WHERE holiday_bgn <=  $before_date
            AND holiday_end >=  $before_date;
          
         if(SQLCODE == 0) strcpy(before_date, after_date); 
         
         strcpy(before_date, cm_edate2_add( before_date, 1, before_date));
         
         i--;                     
      }                        
   }
   
   /* �ˬd�U�@�Ӥ���O�_������,�^�Ǫ�����n�O�U�@�Ӥu�@�� */
   if (h_count != 0)
   {
      	$SELECT max(holiday_end)+1      	
           INTO $after_date
           FROM ca_holiday
          WHERE holiday_bgn <=  $before_date
            AND holiday_end >=  $before_date;
          
         if(SQLCODE == 0) strcpy(before_date, after_date);  
    }     
      
   strcpy(v_after_date, cm_from_infdate_100(before_date)); 
printf("v_after_date[%s],i[%d]\n",v_after_date,i);   

sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "�U�@�u�@�鬰[%s]\n", before_date);
    strcpy( v_sMsg, tmp_sMsg);
    end_chk_working_date( v_sMsg);

    return M_CM_OK;

errexit:

  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy( v_sMsg, tmp_sMsg);
  end_chk_working_date( v_sMsg);
  return SQLCODE;

}

void end_chk_working_date( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end chk_working_date function");
  puts("******************************");
  puts("");
}
