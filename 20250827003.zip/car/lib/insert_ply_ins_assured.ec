/* INSERT data INTO TABLE �պ�est_ins_assured, �̷sply_ins_assured, ��lori_ins_assured,
            ���edr_ins_assured, ���`abn_ply_ins_assured, abn_edr_ins_assured,
            �ƥ�ply_ins_assured_bak

   Name       : insert_ply_ins_assured
   Input      : v_sDbname	        ��Ʈw�W��
                v_sTable  	        Table Name
                v_sColumn               Column Name
                v_sData			�պ⸹�A�O�渹�A���`���A�Χ�渹�X
                v_IfirstPlyInsAssured
                v_sIins_type		���]�w�I�ءA�h�s�W���I�ءA�S���]�w�N�s�W�Ҧ��I��
                
   Output     : M_CM_OK     ���\
                v_sMsg      �T��
*/

#include "api_xsrv.h"
#include "commsgs.h"
#include "carmsgs.h"
$include "ply_ins_assured.h";
$include "var_length.h";
#include "safeclib.h"
void end_insert_ply_ins_assured( );

long insert_ply_ins_assured( char *v_sDbname,
                            char *v_sTable,
                            char *v_sColumn,
                            char *v_sData,
                            struct PLY_INS_ASSURED *v_IfirstPlyInsAssured,
                            char *v_sIins_type,
                            char *v_sMsg)
{
  struct  PLY_INS_ASSURED *IcurrPlyInsAssured;
  $char   iins_type [IINS_TYPE];                /* �I�إN�� */
  $char   provision [7];                        /* �I�إN�� */ /*1081225006-SC1-���ά�-�X�R���[���ڥN�X  6�X */
  $char   iassured  [IASSURED];                 /* �Q�O�I�Hid */
  $char   nassured  [NASSURED];                 /* �Q�O�I�H�m�W */
  $char   dbirth    [DATE];                     /* �X�ͤ�� */
  $char   nbenef    [NBENEF];                   /* ���q�H�m�W */
  $char   rel_benef [REL_BENEF];                /* ���q�H�P�Q�O�I�H���Y */
  $char   tbenef    [21];                       /* ���q�H�p���q�� (1110310005_SC1) */
  $char   abenef_zip[CA_ZIP];                   /* ���q�H�l���ϸ� */
  $char   abenef    [91];                       /* ���q�H�a�} */
  long    iserial;                              /* �Ǹ� */

  $char   stmt[2048];
  char    sdb[61],tmp_sMsg[512];
  int     iInsertCount;

  $WHENEVER SQLERROR GOTO errexit;

  iInsertCount = 0;
  puts("");
  puts("******************************");
  puts("begin insert_ply_ins_assured function");
  printf("     v_sDbname=[%s], v_sTable=[%s], v_sColumn[%s], v_sData[%s],"
         "     v_sIins_type[%s], strlen( trim(v_sIins_type))[%d]\n",
               v_sDbname, v_sTable, v_sColumn, v_sData, v_sIins_type, strlen( trim(v_sIins_type)));
  
  strcpy(tmp_sMsg," ");
  
  if( *v_sDbname == '')
      strcpy( sdb, v_sTable);
  else
      sprintf_s( sdb,sizeof sdb, "%s:%s", v_sDbname, v_sTable);

  sprintf_s( stmt,sizeof stmt, "INSERT INTO %s ( %s, iins_type, provision, iassured, nassured, dbirth, "
                 "                 nbenef, rel_benef, tbenef, abenef_zip, abenef ) "
                 "       VALUES ('%s', ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)" , sdb, v_sColumn, v_sData );
  printf( "     stmt[%s]\n", stmt);

  IcurrPlyInsAssured=v_IfirstPlyInsAssured;

  puts("------ line67 ------");
  
  $PREPARE prep_assured FROM $stmt;
  
  puts("------ line71 ------");
  while(IcurrPlyInsAssured)
  {
      printf("    IcurrPlyInsAssured->iins_type    [%s]\n"
             "    IcurrPlyInsAssured->provision    [%s]\n"
             "    IcurrPlyInsAssured->iassured     [%s]\n"
             "    IcurrPlyInsAssured->nassured     [%s]\n"
             "    IcurrPlyInsAssured->dbirth       [%s]\n"
             "    IcurrPlyInsAssured->nbenef       [%s]\n"
             "    IcurrPlyInsAssured->rel_benef    [%s]\n"
             "    IcurrPlyInsAssured->tbenef       [%s]\n"
             "    IcurrPlyInsAssured->abenef_zip   [%s]\n"
             "    IcurrPlyInsAssured->abenef       [%s]\n",
                  IcurrPlyInsAssured->iins_type,
                  IcurrPlyInsAssured->provision,
                  IcurrPlyInsAssured->iassured,
                  IcurrPlyInsAssured->nassured,
                  IcurrPlyInsAssured->dbirth,
                  IcurrPlyInsAssured->nbenef,
                  IcurrPlyInsAssured->rel_benef,
                  IcurrPlyInsAssured->tbenef,
                  IcurrPlyInsAssured->abenef_zip,
                  IcurrPlyInsAssured->abenef);
      puts("");

      strcpy(v_sIins_type, trim(v_sIins_type));
      strcpy(IcurrPlyInsAssured->iins_type, trim(IcurrPlyInsAssured->iins_type));
      strcpy(v_sIins_type, trim(v_sIins_type));
      
      /* if( strlen( trim(v_sIins_type)) != 0 && strcmp( trim(IcurrPlyInsAssured->iins_type), trim(v_sIins_type)) != 0) */
      if( (strlen(v_sIins_type) != 0) && (strcmp(IcurrPlyInsAssured->iins_type, v_sIins_type) != 0))
      {
          IcurrPlyInsAssured = IcurrPlyInsAssured -> next;
          puts("continue");
          continue;
      }

      strcpy( iins_type, trim(IcurrPlyInsAssured->iins_type));
      strcpy( provision, trim(IcurrPlyInsAssured->provision));
      strcpy( iassured,  IcurrPlyInsAssured->iassured);
      strcpy( nassured,  IcurrPlyInsAssured->nassured);
      strcpy( dbirth,    IcurrPlyInsAssured->dbirth);
      strcpy( nbenef,    IcurrPlyInsAssured->nbenef);
      strcpy( rel_benef, IcurrPlyInsAssured->rel_benef);
      strcpy( tbenef,    IcurrPlyInsAssured->tbenef);
      strcpy( abenef_zip,IcurrPlyInsAssured->abenef_zip);
      strcpy( abenef,    IcurrPlyInsAssured->abenef);
      
      if (strlen(provision) == 0 )
          strcpy(provision, " ");
      
      if (strlen(iins_type) == 0 )
          strcpy(iins_type, " ");
					
      $EXECUTE prep_assured using $iins_type, $provision, $iassured, $nassured, 
                                  $dbirth, $nbenef, $rel_benef, $tbenef, $abenef_zip, $abenef;
      iInsertCount ++;

      IcurrPlyInsAssured = IcurrPlyInsAssured -> next;

  }
  $FREE prep_assured;
  puts("------ line109 ------ ");
  
  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "�s�W[%d]��\n", iInsertCount);
  strcpy(v_sMsg, tmp_sMsg);
  end_insert_ply_ins_assured( v_sMsg);
  
  return M_CM_OK;

errexit:

  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy(v_sMsg, tmp_sMsg);
  end_insert_ply_ins_assured( v_sMsg);
  return SQLCODE;
}

void end_insert_ply_ins_assured( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end insert_ply_ins_assured function");
  puts("******************************");
  puts("");
}

