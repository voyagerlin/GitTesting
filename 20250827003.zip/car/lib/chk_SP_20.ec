/*
   Name       : chk_SP_20

   Input      : iofficer1      	�j��g��N�� 
                iofficer2    	���N�g��N��
                iassured   		�Q�O�I�H
                itag			���P���X
                iengine			�������X
                iroute			�q���N��

   return code: M_CM_OK         ���\
   				v_iCount		0:�DSP-20(�s�bcar153�B�s�bcar140�ҥ~��)		
   								1:SP-20		
   								-1:�DSP-20(���s�bcar153)
   				v_sMsg          �T��

*/
#include "commsgs.h"
#include "carmsgs.h"
#include "var_length.h"
#include "ISvar.h"
#include "safeclib.h"
void end_chk_SP_20( );

long chk_SP_20(    char   *v_iofficer,
					  char   *v_iassured,
                      char   *v_itag,
                      char   *v_iengine,
                      char	 *v_iroute,
                      int    *v_iCount,
                      char   *v_sMsg)
{
	$char iofficer[11],iassured[13],itag[13],iengine[CA_ENGINE_NUM],iroute[21],tmp_sMsg[512];
	$int iCount,iCountSP;
	
	strcpy(iofficer,v_iofficer);
	strcpy(iassured,v_iassured);
	strcpy(itag,v_itag);
	strcpy(iengine,v_iengine);
	strcpy(iroute,v_iroute);
	strcpy( tmp_sMsg, " ");
	
	puts("");
    puts("******************************");
    puts("begin chk_SP_20 function");
	
	iCount = 0;
	iCountSP = 0;

	if (iofficer[0] !='W')
	{		        	
	    $select count(*) into $iCount
	       from ca_permit 	           
	      where (dexpire is null or dexpire > today) and 
	            ((iclass = '01' and icode = $iassured ) or
	             (iclass = '02' and icode = $itag ) or
	             (iclass = '03' and icode = $iengine ) or
	             (iclass = '04' and $iroute like trim(icode)||'%') or
	             (iclass = '05' and $iroute like trim(icode)||'%'))
	        and ftype_sp = '20';
	
	    /* �����~�������i�A�ΫO�g�N�󤧳B�z�覡*/
	    if( iCount > 0)
	    {
	    	iCount = 0;
	    	
	    	/* ����:irate_type = 'C' �����~��:irate_type = 'D' */ 
        	$select count(*) into $iCount from officer
        	  where iofficer = $iofficer and irate_type = 'C';

	        if (iCount > 0 )
	        {
	        	/* �S�w�q���ҥ~�޲z */
	    	    iCountSP = 0;
				$select count(*) into $iCountSP from car_code
			      where kind = 'SP' and detail = '1'
			        and detail2 = $iroute and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);
			    if (iCountSP == 0)
			    {
						$select count(*) into $iCountSP from car_code
					      where kind = 'SP' and detail = '2'
					        and detail2 = $iofficer and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);
			    }					    
			    else if (iCountSP>0)
			    { /* ���ŦX���~�q���A���i�� SP-20 */
			    	iCount = 0;
			    }
	        }
	    }
	    else
	    {
	    	iCount = -1;
	    }
	}
	
	if (iCount > 0)
		*v_iCount = 1 ;
	else
		*v_iCount = iCount ;
	
	sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "iCount[%d]\n", iCount);
	strcpy(v_sMsg,tmp_sMsg);
	end_chk_SP_20( v_sMsg);
	
	return M_CM_OK;


errexit:

  sprintf_s( tmp_sMsg, sizeof tmp_sMsg,"SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy( v_sMsg, tmp_sMsg);
  end_chk_SP_20( v_sMsg);
  return SQLCODE;
}

void end_chk_SP_20( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end chk_SP_20 function");
  puts("******************************");
  puts("");
}