#define _safec_tmnewa_
#define strcpy(s1,s2) strcpy_tm(s1,s2)
#define strlen(s1) strlen_tm(s1)
#define strncpy(s1,s2,s3) strncpy_tm(s1,s2,s3)
#define strcat(s1,s2) strcat_tm(s1,s2)
#define strncat(s1,s2,s3) strncat_tm(s1,s2,s3)
#define strtok(s1,s2) strtok_tm(s1,s2)
#define memcpy(s1,s2,s3) memcpy_tm(s1,s2,s3)
#define atoi(s) atoi_tm(s)
#define atol(s) atol_tm(s)
#define atof(s) atof_tm(s)
extern int atoi_tm(const char *str);
extern long atol_tm(const char *str);
extern double atof_tm(const char *str);
