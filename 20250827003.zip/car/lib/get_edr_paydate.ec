/*
   Name       : get_edr_paydate

   Input      : v_iendorse      ��� 

   return code: M_CM_OK         ���\
                v_paydate       ú�ڴ��� 
                v_ftype_pol     �O�����O 
                v_ftype_sp      �O�����O�Ӷ� 
                v_sMsg          �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "ISvar.h"
#include "safeclib.h"
#define TRUE 1
#define FALSE 0

$include "var_length.h";

void end_get_edr_paydate( );

long get_edr_paydate( char   *v_iendorse,
                      char   *v_paydate,
                      char   *v_ftype_pol,
                      char   *v_ftype_sp,
                      char   *v_sMsg)
{
  long     rtncode;
  $char    iendorse[21], paydate[DATE], ftype_pol[3], ftype_sp[3];
   char    tmp_sMsg[512];
    $WHENEVER SQLERROR GOTO errexit;

    puts("");
    puts("******************************");
    puts("begin get_edr_paydate function");
    printf("    v_iendorse[%s] \n", v_iendorse);
    strcpy(tmp_sMsg," ");
    strcpy( iendorse, v_iendorse);
    rtncode = get_result( iendorse, ftype_pol, ftype_sp, tmp_sMsg);
    if( rtncode != M_CM_OK) return rtncode;

    if ( ftype_pol[0]==' '&& strncmp(ftype_sp,"PA",2) == 0)
        $select dedr_begin
           into $paydate
           from edr_relation
          where iendorse = $iendorse;
    else
        strcpy( paydate, " ");

    strcpy( v_paydate, paydate);
    strcpy( v_ftype_pol, ftype_pol);
    strcpy( v_ftype_sp, ftype_sp);
    
    strcpy( v_sMsg, tmp_sMsg);
    end_get_edr_paydate( v_sMsg);
    return M_CM_OK;

errexit:

  sprintf_s(tmp_sMsg, sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy( v_sMsg, tmp_sMsg);
  end_get_edr_paydate( v_sMsg);
  return SQLCODE;

}

long get_result( iendorse, ftype_pol, ftype_sp, v_sMsg)
$char *iendorse, *ftype_pol, *ftype_sp, *v_sMsg;
{
  long     rtncode;
  $char    iassured[IASSURED], iroute[21], ipolicy[21], paydate[DATE];
  $char    itag[CA_TAG_NUM], iengine[CA_ENGINE_NUM], fcard_class[2], ipolicy1[21], ipolicy2[21], nequipment[31], nequipment_bak[31], irate_type[2];
  $char    iofficer[11];
  $int     iCountJC=0, iCountSP=0, icheck_date=0, iDpolicy=0, iNotSP20=0;
   char    tmp_sMsg[512];

    strcpy(tmp_sMsg," ");
    $SELECT b.iassured, b.iroute, a.ipolicy, b.itag, b.iengine, a.fcard_class, a.ipolicy[1,13],a.ipolicy[14,20],
            CASE WHEN c.dply_begin BETWEEN '01/01/2015' AND '02/28/2015' AND c.dpolicy BETWEEN '01/01/2015' AND '02/28/2015' THEN 1 ELSE 0 END,
            b.nequipment, d.nequipment, case when c.dpolicy < '01/01/2015' then 1 else 0 end, a.irate_type, a.iofficer
       INTO $iassured, $iroute, $ipolicy, $itag, $iengine, $fcard_class, $ipolicy1, $ipolicy2, $icheck_date, $nequipment, $nequipment_bak, $iDpolicy,
            $irate_type, $iofficer
       FROM edr_relation a, endorsement b, ply_relation c, policy_bak d
      WHERE a.iendorse = b.iendorse
        AND a.ipolicy = c.ipolicy
        AND a.iendorse = $iendorse
        AND a.iendorse = d.iendorse;
    
    /* 2015/5/1 ���O�����O�W�h�u�����Ǧp�U�G
       1.�@�γ������ɧ䤣��O����,ñ���<01/01/2015->OT, else error
       2.�O�榳OT.EW.EB->�̨�O��
       2.JC->�̨�]�w�ɧP�_
       2.��榳�i97�䲼ú�ڡj���O->RN
       3.CAR153���]�w20�O�g�N�ĳq->SP20
       4.CAR153���]�w10���q�ĳq(�D�P�_�O��)->SP10
       5.�Y�����O�W�z?���NPA,�j��SP01
       AP�O�S���Ӯ�,��CAR158�i��]�w,�G���ǤJ��沣�ͤ��P�_�W�h.
    */

    $SELECT first 1 ftype_pol, ftype_sp
       INTO $ftype_pol, $ftype_sp
       FROM cm_pre_receive
      WHERE ipolicy1 = $ipolicy1
        AND ipolicy2 = $ipolicy2
        AND iendorse = ' '
        AND iins_kind = $fcard_class
        AND ipre_end = ' ';

    if(SQLCODE == SQLNOTFOUND)
    {
        if( iDpolicy == 1) /* ñ���<01/01/2015 */
        {
            strcpy( ftype_pol, "NA");
            strcpy( ftype_sp, "OT");
            return M_CM_OK;
        }
        else
        {
            strcpy( ftype_pol, " ");
            strcpy( ftype_sp, " "); /* ��97���O���U�P�_ */
        }
    }

    /*1120927002_C02 �R�q�ΰӫ~�}�o => "ES"*/
    if( strncmp( ftype_sp, "OT", 2) == 0 || strncmp( ftype_sp, "EW", 2) == 0 || strncmp( ftype_sp, "EB", 2) == 0 ||
        strncmp( ftype_sp, "TV", 2) == 0 || strncmp( ftype_sp, "ES", 2) == 0 )
    {
        /* �̨�O�� dummy */
        return M_CM_OK;
    }

    if( strncmp( ftype_sp, "JC", 2) == 0)
    {
        $SELECT count(*) INTO $iCountJC
           FROM car_code
          WHERE kind = '26' AND detail = $iassured;
        if (iCountJC > 0)
        {
            strcpy( ftype_pol, "NA");
            strcpy( ftype_sp , "JC");
            return M_CM_OK;
        }
    }

    /* 2015/7/1���� 
    if(equip_cmp(nequipment,"97") == TRUE)
    {
        strcpy( ftype_pol, "NA");
        strcpy( ftype_sp, "RN");
        return M_CM_OK;
    } */

    $select count(*)
       into $iCountSP
       from ca_permit
      where (dexpire is null or dexpire > today) and
           ((iclass = '01' and icode = $iassured ) or
            (iclass = '02' and icode = $itag ) or
            (iclass = '03' and icode = $iengine ) or
            (iclass = '04' and $iroute like trim(icode)||'%') or
            (iclass = '05' and $iroute like trim(icode)||'%'))
        and ftype_sp = '20';

    if( iCountSP != 0 && irate_type[0] != 'D')
    {
        $select count(*) into $iNotSP20 from car_code
          where kind = 'SP' and detail = '1'
            and detail2 = $iroute and (trim(engname) = '' or nvl(engname::date,'12/31/2050'::date) > today);

        if( iNotSP20 == 0)
        {
            $select count(*) into $iNotSP20 from car_code
              where kind = 'SP' and detail = '2'
                and detail2 = $iofficer and (trim(engname) = '' or nvl(engname::date,'12/31/2050'::date) > today);

            if( iNotSP20 == 0) /* �s�bca_permit,�B���������~��,�B���s�bcar_code,�~�OSP20 */
            {
                strcpy( ftype_pol, "SP");
                strcpy( ftype_sp, "20");
                return M_CM_OK;
            }
        }
    }

    $select count(*)
       into $iCountSP
       from ca_permit
      where (dexpire is null or dexpire > today) and
           ((iclass = '01' and icode = $iassured ) or
            (iclass = '02' and icode = $itag ) or
            (iclass = '03' and icode = $iengine ) or
            (iclass = '04' and $iroute like trim(icode)||'%') or
            (iclass = '05' and $iroute like trim(icode)||'%'))
        and ftype_sp = '10';

    strcpy( v_sMsg, tmp_sMsg);
    if( iCountSP != 0)
    {
        strcpy( ftype_pol, "SP");
        strcpy( ftype_sp, "10");
        return M_CM_OK;
    }

    if( fcard_class[0] == '1')
    {   
        strcpy( ftype_pol, "SP");
        strcpy( ftype_sp, "01");
        return M_CM_OK;
    }
    else
    {
        strcpy( ftype_pol, " ");
        strcpy( ftype_sp, "PA");
        return M_CM_OK;
    }

errexit:

  sprintf_s(tmp_sMsg, sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy( v_sMsg, tmp_sMsg);  
  end_get_edr_paydate( v_sMsg);
  return SQLCODE;
}


void end_get_edr_paydate( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_edr_paydate function");
  puts("******************************");
  puts("");
}
