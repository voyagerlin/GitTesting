/*
   Name       : chk_valid_isign
   Purpose    : �P�_�u�֫O�H���v�O�_���C�U���A��֫O�H��

   Input      : *v_isign		�֫O�H���N��
                *v_date                 �ˮ֤�
   
   Output     : return code 	M_CM_OK ���\
                rtValid[0]      N:�D�A��֫O�H�� ; Y:�A��֫O�H�� 
                rtValid[1]      ���~�T���N�X�]�O�d�\��^
                v_sMsg      	�T��	                  
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"

void end_chk_valid_isign( );


long chk_valid_isign( char *v_iins_cat, char *v_isign, char *v_date, char *v_fsign,char *v_valid ,char *v_sMsg)
{
    $char sIins_cat[2],sIsign[11],sMsg[512];
    $char sdate[11], check_date[11],sFsign[7]; /*1091021005-SC1-���ά�-�s�W�A�Ȥ��ߩ�����*/
    $int  iCount1;
    char  rtValid[3];    	
    long  t;
    
    $WHENEVER SQLERROR GOTO errexit;
    puts("");
    puts("******************************");
    puts("begin chk_valid_isign function");
    
    strcpy(sIins_cat , trim(v_iins_cat));
    strcpy(sIsign    , trim(v_isign));
    strcpy(sdate     , trim(v_date));
    strcpy(sFsign     , trim(v_fsign));/*1091021005-SC1-���ά�-�s�W�A�Ȥ��ߩ�����*/
    if( strlen( trim(sdate)) == 0)
    {
        t = cm_today();
        strcpy( check_date,  cm_edate_str(t));
    }
    else
        strcpy( check_date, sdate);
    printf("check_date[%s]\n", check_date);
    strcpy(rtValid,"N0");
    strcpy(v_sMsg," ");
	strcpy(sMsg," ");    
    iCount1 = 0;
    $select count(*) into $iCount1
       from cm_signatory
      where iins_cat = $sIins_cat
        and isign    = $sIsign
        AND CHARINDEX(fsign,$sFsign) > 0
        and deffect <= $check_date
        and (dexpire is null or dexpire > $check_date) ;
	          		
    if (iCount1 > 0){
    	strcpy(rtValid,"Y0"); 
    }
	
	strcpy(v_valid, rtValid);
	 
    if (rtValid[0] == 'N'){
	    switch (rtValid[1])
	    {
	         case '0': 
				sprintf_s(sMsg,sizeof sMsg,"�֫O�H��[%s]�D�C�U�A��֫O�H��",sIsign); 
				strcpy(v_sMsg,sMsg);
				break;
	         default : 
				sprintf_s(sMsg,sizeof sMsg,"chk_valid_isign()�^�ǭȥ��w�q(�֫O�H��[%s])",sIsign); 
				strcpy(v_sMsg,sMsg);
				break;
	    }
	    printf("-- trace v_sMsg[%s]\n ",v_sMsg);    
    }
     
    return M_CM_OK;

errexit:
  sprintf_s( sMsg,sizeof sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy(v_sMsg,sMsg);
  end_chk_valid_isign( v_sMsg);
  return SQLCODE;

}    


void end_chk_valid_isign( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end chk_valid_isign function");
  puts("******************************");
  puts("");
}
