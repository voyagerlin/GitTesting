/*
Name        : get_ply_ins_dtl
Input       : v_itype          ��ƪ��O
              v_ipolicy        �O�渹	
              v_iendorse       ��渹
              v_iins_type      �I�إN��
return code : M_CM_OK ���\  
Output      : 
              v_nins_type      �I�ئW��
              v_edomain        �D�n���I����
              v_cover_print1   �O�B�W��1
              v_ncover1        �O�I���B1
              v_ndeduct        �ۭt�B
              v_cover_print2   �O�B�W��2
              v_ncover2        �O�I���B2
              v_cover_print3   �O�B�W��3
              v_ncover3        �O�I���B3
              v_cover_print4   �O�B�W��4
              v_ncover4        �O�I���B4
              v_sMsg           �T��
*/


/*
	2022/11/11 stevechiang
	����O��C�L�}�o�i��ϥΦ�function�I�s������T�A�����{���X�����ѡC
*/

#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include <malloc.h>
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "print.h"
#include "is_def.h"
#include "carmsgs.h"
#include "commsgs.h"
$include "ply_ins_cover.h";
$include "var_length.h";
#include "car_common.h"
#include "ISvar.h"
#include "safeclib.h"

void end_get_ply_ins_dtl();
char *get_car_full_db();

long  get_ply_ins_dtl( v_itype, v_ipolicy, v_iendorse, v_icar_type, v_iins_type, v_nins_type, v_edomain, v_cover_print1, v_ncover1, v_ndeduct, v_cover_print2, v_ncover2, v_cover_print3, v_ncover3, v_cover_print4, v_ncover4, n_ins_premium, v_sMsg)
$char *v_itype, *v_ipolicy, *v_iendorse, *v_icar_type, *v_iins_type, *v_nins_type, *v_edomain, *v_cover_print1, *v_cover_print2, *v_cover_print3, *v_cover_print4, *n_ins_premium, *v_sMsg;
$char  *v_ndeduct, *v_ncover1, *v_ncover2, *v_ncover3, *v_ncover4;
{

	$char  cover_print1[121], cover_print2[121], cover_print3[121], cover_print4[121];
	$char  ndeduct[20],ncover1[20],ncover2[20],ncover3[20],ncover4[20];
	$char  stmt[2048], sStmt[1024], sDbname[61];
	$char  table_ins_type[30], table_pa[30], table_cover[30], stmp1[128];
	$char  Full_DBName[20];
	$long  injured_cover = 0,death_cover = 0,damage_cover = 0,deduct = 0,ins_premium = 0,qserial = 0,qday = 0;
	$char  drate_ym[5];
	$char  nins_type[121], edomain[81], cover_print[121], fdeduct[2], deduct_print[21], sFcal_way[2];
	$char  tmp_deduct[20];
	$char  deduct_30[11], deduct_301[11], deduct_302[11];
	$int   qcoverage;

	$char  *ptr;
	$char  contain_coverage[121],prt_coverage[121];
	$int   iins;
	
	$char  fcar_class[2], ncar_abbr[14];
	
	$char  iins_scope_56[2],tmp_iins_scope[3];
	$char  f52535524[2],f626364[2],f86[2];
	$char  fcomp_24 = 0;
	$char  prn_deduct[20];
	$int   insurance_cover_count,daily_pay;
	$long  lPremSum;
	
	$char  sColumn[21], itmp[21];
	long   rtncode;
	
	$char v_sMsg2[256]; /* ���T����J���ɭԥΪ��Ȧs�}�C */
	$char strtmp[256]; /* ���T����J���ɭԥΪ��Ȧs�}�C2 */
	
	strcpy(v_sMsg," ");

	$WHENEVER SQLERROR GOTO errexit;
	puts("begin get_ply_ins_dtl function");
	printf(" v_itype=[%s], v_ipolicy=[%s], v_iendorse[%s], v_iins_type[%s]\n", v_itype, v_ipolicy, v_iendorse, v_iins_type);
	
	/* �M�� */
	v_ndeduct[0] = v_ncover1[0] = v_ncover2[0] = v_ncover3[0] = v_ncover4[0] = '\0';
	v_cover_print1[0] = v_cover_print2[0] = v_cover_print3[0] = v_cover_print4[0] = '\0';
	
	strcpy(Full_DBName, get_car_full_dbname(v_ipolicy));
	
	/* 1:��l�O�� 2:��� 3:�̷s�O�� */
	if(v_itype[0] == '1') 
	{
		strcpy(table_ins_type,"ori_ins_type");
		sprintf_s(stmp1, sizeof stmp1,"WHERE ipolicy = '%s' ",v_ipolicy,v_iins_type);
		strcpy(table_pa,"ca_pa_ori");
		/* For ���ݪ� cover table */
		strcpy(table_cover,"ori_ins_cover");
		strcpy(sColumn,"ipolicy");
		strcpy(itmp,v_ipolicy);
	}
	else if(v_itype[0] == '2') 
	{
		strcpy(table_ins_type,"ply_ins_type_bak");
		sprintf_s(stmp1, sizeof stmp1,"WHERE ipolicy = '%s' AND iendorse = '%s' ",v_ipolicy,v_iendorse);
		strcpy(table_pa,"ca_pa_ply_bak");
		/* For ���ݪ� cover table */
		strcpy(table_cover,"ply_ins_cover_bak");
		strcpy(sColumn,"iendorse");
		strcpy(itmp,v_iendorse);
	}
	else if(v_itype[0] == '3') 
	{
		strcpy(table_ins_type,"ply_ins_type");
		sprintf_s(stmp1, sizeof stmp1,"WHERE ipolicy = '%s' ",v_ipolicy,v_iins_type);
		strcpy(table_pa,"ca_pa_ply");
		/* For ���ݪ� cover table */
		strcpy(table_cover,"ply_ins_cover");
		strcpy(sColumn,"ipolicy");
		strcpy(itmp,v_ipolicy);
	}
	
	sprintf_s(stmt, sizeof stmt,"SELECT minjured_cover, mdeath_cover, mdamage_cover, mdeduct, mins_premium, qserial, "
	                    " qday, drate_ym "
	               " FROM %s:%s %s AND iins_type = '%s' ORDER BY qserial",Full_DBName,table_ins_type,stmp1,v_iins_type);
	printf("stmt[%s]\n", stmt);
	
	$PREPARE prep_ins_type FROM $stmt;
	$DECLARE cur_ins_type CURSOR FOR prep_ins_type;
	$OPEN cur_ins_type;
	$FETCH cur_ins_type INTO $injured_cover, $death_cover, $damage_cover, $deduct, $ins_premium, $qserial, $qday, $drate_ym;
	$CLOSE cur_ins_type;
	$FREE cur_ins_type;
	
	printf("injured_cover[%d] death_cover[%d] damage_cover[%d] deduct[%d] qday[%d]\n",injured_cover,death_cover,damage_cover,deduct,qday);
	
	$SELECT nins_type,  edomain2, nvl(qcoverage,0), nvl(cover_print,' '), fdeduct, nvl(deduct_print,' '), fcal_way
	   INTO $nins_type, $edomain, $qcoverage,          $cover_print,     $fdeduct,    $deduct_print,    $sFcal_way
	   FROM insurance_type
	  WHERE iins_type = $v_iins_type;
	  
	strcpy(nins_type,trim(nins_type));
	strcpy(edomain,trim(edomain));
    
	$SELECT fcar_class, ncode
	   INTO $fcar_class, $ncar_abbr
	   FROM car_type
	  WHERE icode = $v_icar_type AND fclass = '1';
	
	if(SQLCODE == SQLNOTFOUND) strcpy( fcar_class, " ");

/**********************************************************************************************************************************************************/	
	if (strcmp(trim(v_iins_type),"56") == 0  || strcmp(trim(v_iins_type),"136") == 0 || 
	    strcmp(trim(v_iins_type),"166") == 0 || strcmp(trim(v_iins_type),"266") == 0)
	{
		/*if (strcmp(trim(v_iins_type),"56") == 0)
			strcpy(sNassured_56_136,"56 �Q�O�I�H:");
		else if(strcmp(trim(v_iins_type),"136") == 0)
			strcpy(sNassured_56_136,"136�Q�O�I�H:");
		else if(strcmp(trim(v_iins_type),"166") == 0)
			strcpy(sNassured_56_136,"166�Q�O�I�H:");    
		else
			strcpy(sNassured_56_136,"266�Q�O�I�H:"); */

		sprintf_s(stmt, sizeof stmt,"SELECT distinct iins_scope "
		               " FROM %s:%s %s "
		               "  AND (nvl(fedr_status,'') != '1' AND "
		               "       nvl(fedr_status,'') != '2' AND "
		               "       nvl(fedr_status,'') != '3');",Full_DBName,table_pa,stmp1);
		
		$PREPARE pa_ply_56_scope FROM $stmt;
		$DECLARE pa_ply_56_scope_cur CURSOR FOR pa_ply_56_scope;
		$OPEN  pa_ply_56_scope_cur;
		
		$FETCH pa_ply_56_scope_cur INTO $iins_scope_56;
		$CLOSE pa_ply_56_scope_cur;
		$FREE  pa_ply_56_scope_cur;
		
		if((strcmp(trim(iins_scope_56),"2")==0)) /* 56�I�ؤ������B���P����I�� */
		{
			qcoverage = 2; 
			strcpy(cover_print,"���|�������B;���G����");
		}
		else if((strcmp(trim(iins_scope_56),"3")==0))
		{
			qcoverage = 2; 
			strcpy(cover_print,"�ˮ`�����й���I��;���G����");
		}
	}

	if ((strcmp(trim(v_iins_type),"24") == 0)  || (strcmp(trim(v_iins_type),"52") == 0) ||
	    (strcmp(trim(v_iins_type),"53") == 0)  || (strcmp(trim(v_iins_type),"55") == 0) ||
	    (strcmp(trim(v_iins_type),"135") == 0) || (strcmp(trim(v_iins_type),"255") == 0))
	{
		/* �I��52,53,55,24 �O�v�ͮĤ� >- '04/06/2011', �A�ηs�� add by sylvia 100.03.29 (1000323008)*/
		if(strcmp(sFcal_way,"1") == 0)
		{
			$SELECT case when drate >= date('04/06/2011') then '1' else '0' end
			   INTO $f52535524
			   FROM ca_rate_date
			  WHERE icode  = $drate_ym
			    AND itable = 'ca_rate';
		}
		else
		{
			$SELECT case when drate >= date('04/06/2011') then '1' else '0' end
			   INTO $f52535524
			   FROM ca_rate_date
			  WHERE icode  = $drate_ym
			    AND itable = 'cover_vs_premium';
		}
		if (SQLCODE == SQLNOTFOUND)  return M_CA_EXTRA_CHARGE_DRATE;
		printf("drate_ym=[%s] f52535524=[%s]\n",drate_ym,f52535524);

		/* �I��52,53,55,24 �s�¦��t add by sylvia 100.03.29 */
		if (strcmp(f52535524,"0") == 0)
		{   /* �A���¨� �O�v�ͮĤ� < 04/06/2011 */
			printf("-------------- �A���¨� �O�v�ͮĤ� < 04/06/2011 ---------\n");
			if (strcmp(trim(v_iins_type),"24")==0)
				strcpy(nins_type,"���s���v�T���ר��`�H���v�I");
			else if (strcmp(trim(v_iins_type),"52")==0)
			{
				strcpy(nins_type,"���D�d���I");
				qcoverage = 3; /* �¨3�ӫO�B--���,���`,�ƬG */
				strcpy(cover_print,"�C�@�H���;�C�@�H���`;�C�@�N�~�ƬG���`�B");
			}
			else if (strcmp(trim(v_iins_type),"53")==0)
			{
				qcoverage = 3; /* �¨3�ӫO�B--���,���`,�ƬG */
				strcpy(cover_print,"�C�@�H���;�C�@�H���`;�C�@�N�~�ƬG���`�B");
			}
			else if (strcmp(trim(v_iins_type),"55")==0 || strcmp(trim(v_iins_type),"135")==0 || strcmp(trim(v_iins_type),"255")==0)
			{
				qcoverage = 3; /* �¨3�ӫO�B--���,���`,�ƬG */
				strcpy(cover_print,"�C�@�H���;�C�@�H���`�Υ���;�C�@�N�~�ƬG���`�B");
			}
		}
		else
		{   
			/* �A�ηs�� �O�v�ͮĤ� >= 04/06/2011 (�̳]�w�ɦC�L) */
			printf("-------------- �A�ηs�� �O�v�ͮĤ� > 04/06/2011 ---------\n");
			if (strcmp(trim(v_iins_type),"52")==0)
			{
				if (fcar_class[0] == '1')
				{
					strcpy(nins_type,"���D�d�����[����");
				}
				else
				{
					strcpy(nins_type,"�T�����D�d���O�I");
				}
			}
		}
	}

	if ((strcmp(trim(v_iins_type),"62") == 0) || (strcmp(trim(v_iins_type),"63") == 0) ||
	    (strcmp(trim(v_iins_type),"64") == 0) || (strcmp(trim(v_iins_type),"143") == 0))
	{
		/* �I��62,63,64 �O�v�ͮĤ� >= '12/01/2012', �A�ηs�� add by sylvia 101.12.25 (1011214002_C1)*/
		/* �s�W143�I�� add by �L�� 104.12.14 (1041203004_C2)*/   
		$SELECT case when drate >= date('12/01/2012') then '1' else '0' end
		   INTO $f626364
		   FROM ca_rate_date
		  WHERE icode  = $drate_ym
		    AND itable = 'cover_vs_premium';
		
		if (SQLCODE == SQLNOTFOUND)  return M_CA_EXTRA_CHARGE_DRATE;
		printf("drate_ym=[%s] f626364=[%s]\n",drate_ym,f626364);
		
		if (strcmp(f626364,"0") == 0)
		{   
			/* �A���¨� �O�v�ͮĤ� < 12/01/2012 */
			printf("-------------- �A���¨� �O�v�ͮĤ� < 12/01/2012 ---------\n");
			if (strcmp(trim(v_iins_type),"62")==0)
			{
				qcoverage = 1; /* �¨�u��1�ӫO�B--�ƬG */
				strcpy(cover_print," ");
			}
			else if (strcmp(trim(v_iins_type),"63")==0)
			{
				qcoverage = 1; /* �¨�u��1�ӫO�B--�ƬG */
				strcpy(cover_print," ");
			}
			else if (strcmp(trim(v_iins_type),"64")==0)
			{
				qcoverage = 1; /* �¨�u��1�ӫO�B--�ƬG */
				strcpy(cover_print," ");
			}
		}
		else
		{   
			/* �A�ηs�� �O�v�ͮĤ� >= 12/01/2012 (�̳]�w�ɦC�L) */
			printf("-------------- �A�ηs�� �O�v�ͮĤ� > 12/01/2012 ---------\n");
			/* ��car108�]�w: 62,63,64�O�B��2��--��ˡB�ƬG, �O�B��r�̳]�w�ɳ]�w */
		}
	}     

	/* �P�_�I��47 �O�v�ͮĤ� >= '03/01/2020', �I�ئW�٨̳]�w�ɦC�L*/
	/*            �O�v�ͮĤ� <  '03/01/2020', �I�ئW�٦C�L�u�����r�p�H�ˮ`�O�I�v*/
	/* 1081205009_SC4_�t�X47�I�رq�D�I�אּ���[�I�A�ק���s/E�O��/B2B/B2C�ˮ�(�Цb12�멳����)*/
	if (strcmp(trim(v_iins_type),"47") == 0 )
	{
		if (atoi(drate_ym) < 111)
		{   
			/*�����C�L�u�����r�p�H�ˮ`�O�I�v*/
			strcpy(nins_type,"�����r�p�H�ˮ`�O�I");
		}
		else
		{  
			/* ��car108�]�w*/
		}
	}
	
	/*1120927002_C09_�R�q�ΰӫ~�}�o*/
	/*if(strcmp(trim(v_iins_type), "175") == 0)
	{
		strcpy(cover_print, "�P�]���l���O�I");
		printf("175\n");
	}
	
	if(strcmp(trim(v_iins_type), "174") == 0)
	{
		strcpy(cover_print, "�C�@�N�~�ƬG���d��;�ֿn�̰����v���B");
		printf("174\n");
	}*/
	
	

	/* ��X�ۭt�B���C�L���e,fdeduct = 1�ɥN�����ۭt�B */
	printf("0110: �ۭt�B����[%s],deduct_print[%s]\n",fdeduct,deduct_print);
	if (strncmp(fdeduct,"1",1) == 0)
	{
		if (strcmp(trim(v_iins_type),"86") == 0)
		{
			$SELECT case when drate >= date('06/08/2015') then '1' else '0' end
			   INTO $f86
			   FROM ca_rate_date
			  WHERE icode  = $drate_ym
			    AND itable = 'cover_vs_premium';

			if (SQLCODE == SQLNOTFOUND) return M_CA_EXTRA_CHARGE_DRATE;
		
			strcpy(v_ndeduct,"");
			if (strcmp(trim(f86),"1") == 0)
			{
				if (deduct != 0)
				{
					sprintf_s(deduct_print, sizeof deduct_print,"%d",deduct);
					strcpy(v_ndeduct,deduct_print);
					strcat(v_ndeduct,"%");
				}
				else
				{
					strcpy(v_ndeduct,"�L");
				}
			}
			else
			{
				strcpy(v_ndeduct,"�L");
			}
		}
		else
		{
			if ((strcmp(trim(deduct_print),"") == 0) ||(strcmp(trim(deduct_print),'\0') == 0))
			{
				/*sprintf_s(v_ndeduct, sizeof v_ndeduct,"%d",deduct);*/
				sprintf_s(strtmp, sizeof strtmp, "%d", deduct);
				strcpy(v_ndeduct, strtmp);
				prn_deduct[0]=0;

				$SELECT prn_deduct
				   INTO $prn_deduct
				   FROM ca_dmg_mdeduct
				  WHERE icar_type = $v_icar_type
				    AND ideduct = $v_ndeduct;
				
				strcpy(v_ndeduct, trim(prn_deduct));
			}
			else
			{
				strcpy(v_ndeduct,deduct_print);
			}
		}
	}
	else
	{
		strcpy(v_ndeduct,deduct_print);
	}
		
	/* �O�B��ܦW�٩�C */
	if (qcoverage > 1)
	{
		int q = 1;
		ptr = strtok(cover_print,";");
		while (ptr != NULL)
		{
			strcpy(prt_coverage,trim(ptr));
			if(q == 1) strcpy(v_cover_print1,prt_coverage);
			else if(q == 2) strcpy(v_cover_print2,prt_coverage);
			else if(q == 3) strcpy(v_cover_print3,prt_coverage);
			else if(q == 4) strcpy(v_cover_print4,prt_coverage);
			ptr = strtok(NULL,";");
			q++;
		}
	}
	else 
		strcpy(v_cover_print1,trim(cover_print));

	iins=atoi(v_iins_type);
    switch (iins)
    {
		case 1: case 5: case 9: case 8: case 86: case 110: case 120: case 122: case 125: case 126: case 152: case 153: case 161: case 162: case 201: case 205: case 209:

			strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
	    	if (iins == 120)
	    	{
				sprintf_s(sStmt, sizeof sStmt, "SELECT sum(mins_premium) "
				                " FROM %s:%s %s   "
				                "  AND iins_type in ('120','121');",Full_DBName,table_ins_type,stmp1);
				$PREPARE plyInsType120_cur FROM $sStmt;
				$EXECUTE plyInsType120_cur INTO $ins_premium;
	    	}
	    	else if (iins == 122)
	    	{
				sprintf_s(sStmt, sizeof sStmt, "SELECT sum(mins_premium) "
				                " FROM %s:%s %s "
				                "  AND iins_type in ('122','123');",Full_DBName,table_ins_type,stmp1);
				$PREPARE plyInsType122_cur FROM $sStmt;
				$EXECUTE plyInsType122_cur INTO $ins_premium;
	    	}
	    	strcpy(n_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
    		break;

		case 85:
		
			strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
			strcpy(v_ncover2,rtrim(refmtamt(injured_cover,MILLIONTH)));
			strcpy(n_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
			break;

		/* �����¦����s�A�������I�����{���]�w(137�B138�B139�B141�B142�I��) (1100311005_SC6)*/
		case 105: case 118:
		
			strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
			strcpy(v_ncover2,rtrim(refmtamt(injured_cover,MILLIONTH)));
			if (iins == 118)
			{
				sprintf_s(sStmt, sizeof sStmt, "SELECT sum(mins_premium) "
				                " FROM %s:%s %s "
				                "  AND iins_type in ('118','119');",Full_DBName,table_ins_type,stmp1);
				$PREPARE plyInsType118_cur FROM $sStmt;
				$EXECUTE plyInsType118_cur INTO $ins_premium;
			}
			strcpy(n_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
			break;

		case 2: case 3: case 7: case 150:
		
		    strcpy(v_ncover1," ");
		    strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
		    if (iins == 150)
		    {
		    	strcpy(v_ncover1,"�̱��ڬ��w");
		    	/*sprintf_s(tmp_150151, sizeof tmp_150151,"���m����:%.1f�U",mcar_price);
				ins_150151 = 1;*/
		    }
		    break;

		case 10: case 127:
		
			strcpy(n_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
			break;

		case 11: case 129: case 211:
		
			/*ins_11 = 1;*/
			strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
			
			if (deduct == 0)
			{}
			else 
			{
				strcat(v_ndeduct,refmtamt(deduct,MILLIONTH));
				strcat(v_ndeduct,"%");
			}
			strcpy(n_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
			break;

		case 12:
		
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			strcpy(v_ndeduct,rtrim(refmtamt(damage_cover,MILLIONTH)));
			strcat(v_ndeduct,"��");
			break;

		case 28: case 128:
		
			strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
			if (deduct == 0)
			{}
			else 
			{
				strcat(v_ndeduct,refmtamt(deduct,MILLIONTH));
				strcat(v_ndeduct,"%");
			}
			strcpy(n_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
			break;

		case 14:
		
			/*ins_14=1;*/
			strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			/*if (equip_cmp(nequipment,"5") == TRUE)
			{
				strcpy(nequipment_7h_14,"1");
			}
			else
			{
				strcpy(nequipment_7h_14,"0");
			}
			strcpy(iofficer_7h_14,substring(iofficer,1,3));
			printf("0140: nequipment_7h_14:[%s]\n,iofficer_7h_14:[%s]",nequipment_7h_14,iofficer_7h_14);
			
			if ( strncmp(nequipment_7h_14,"1",1)==0 && strcmp(trim(dpolicy),"")!=0 &&
			   ( iofficer[0] == 'A' || iofficer[0] == 'B') )
			{
				ins_14=2;
				premium_7h_14 = ins_premium;
				old_premium_7h_14 = old_premium;
				mdiscount_7h_14 = ins_mdiscount;
			}*/
			break;

		case 15: case 16: case 66: case 67: case 106: case 119: case 121: case 123:
		
			strcpy(v_ncover1,ltoa(qday));
			strcat(v_ncover1,"��");
			if (iins != 119 && iins != 121 && iins != 123 )
			{
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			}
			else
			{
				strcpy(v_ncover2,rtrim(refmtamt(injured_cover,MILLIONTH)));
			}
			break;

		case 17: case 130: case 151:
		
			/*ins_17=1;*/
			strcpy(n_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
			strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
			/*�U�L�@���M�׸ɵo���L17�I��*/
			/*if (equip_cmp(nequipment,"5") == TRUE)
			{
				strcpy(nequipment_17,"1");
			}
			else
			{
				strcpy(nequipment_17,"0");
			}
			
			printf("0150: nequipment_17:[%s]\n",nequipment_17);
			
			if ((strcmp(nequipment_17,"1")==0 && strcmp(trim(dpolicy),"")!=0 &&
			   ( iofficer[0] == 'A' || iofficer[0] == 'B' || iofficer[0] == 'J')) ||
			strncmp(sIpolicyB_type,"1",1) == 0 )
			{
				/* ins_17=2���ɭԥN���ɵo�B���O17�I��,17�I�ؤ��e���C�L,�O�O�]�n� *
				/* �M�ץ�O�� 17�I�ؤ��e���C�L,�O�O�]�n� *
				bufa_ins_17 = 1;
				ins_17=2;
				premium_17 = ins_premium;
				old_premium_17 = old_premium;
				mdiscount_17 = ins_mdiscount;
			}*/
			
			if (iins == 151)
			{
				strcpy(v_ncover1,"�̱��ڬ��w");
				/*sprintf_s(tmp_150151, sizeof tmp_150151,"���m����:%.1f�U",mcar_price);
				ins_150151 = 1;*/
			}
			break;

		case 18:
		
			strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			strcpy(tmp_deduct,itoa(deduct));
			strncpy(deduct_30,&tmp_deduct[2],2);
			deduct_30[2] = '%';
			deduct_30[3] = '\0';
			strcpy(v_ndeduct,deduct_30);
			strcat(v_ndeduct,"(�_��");
			strncpy(deduct_30,tmp_deduct,2);
			deduct_30[2] = '%';
			deduct_30[3] = '\0';
			strcat(v_ndeduct,deduct_30);
			strcat(v_ndeduct,")");
			break;

		case 19:
		
			/*ins_19=1;*/
			strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			/*if (equip_cmp(nequipment,"5") == TRUE)
			{
			    strcpy(nequipment_7h_19,"1");
			}
			else
			{
			    strcpy(nequipment_7h_19,"0");
			}
			strcpy(iofficer_7h_19,substring(iofficer,1,3));
			printf("0190: nequipment_7h_19:[%s]\n,iofficer_7h_19:[%s]",nequipment_7h_19,iofficer_7h_19);
			
			if ( (strncmp(nequipment_7h_19,"1",1)==0 && strcmp(trim(dpolicy),"")!=0 &&
			   ( iofficer[0] == 'A' || iofficer[0] == 'B')) || strncmp(sIpolicyB_type,"1",1) == 0 )
			{
			    /* �M�ץ�O�� 19�I�ؤ��e���C�L,�O�O�]�n� *
			    bufa_ins_19 = 1;
			    ins_19=2;
			    premium_7h_19 = ins_premium;
			    old_premium_7h_19 = old_premium;
			    mdiscount_7h_19 = ins_mdiscount;
			}*/
			break;

		case 20: case 23: case 111:
		
			strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
		
		case 22: case 112:
		
			strcpy(v_ncover1,refmtamt(damage_cover,MILLIONTH));
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
		
		case 24: case 88: case 26:
/*?*/
			if (fcomp_24 == 'Y' && strlen(n_ins_premium) != 0)
			{
				strcpy(n_ins_premium,"�[�j ");
				strcat(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			} 
			else 
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
		
		case 29: case 124:
		
			strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

		case 30: case 530:
			
			strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
			/*strcpy(tmp_deduct,itoa(deduct));
			strcpy(deduct_30,tmp_deduct);*/
			
			/*�T�{���[�O24*
			$SELECT v_iins_type
			   INTO $iins_type24
			   FROM ply_ins_type
			  WHERE ipolicy = $ipolicy
			    AND v_iins_type = '24';
			if(SQLCODE == SQLNOTFOUND)
			{
				flag24=0;
			}
			else
			{
				flag24=1;
			}
			
			/*�T�{���[�O55*
			$SELECT v_iins_type
			   INTO $iins_type55
			   FROM ply_ins_type
			  WHERE ipolicy = $ipolicy
			    AND v_iins_type = '55';
			if(SQLCODE == SQLNOTFOUND)
			{
				flag55=0;
			}
			else
			{
				flag55=1;
			}
			
			/*�T�{���[�O255*
			$SELECT v_iins_type
			   INTO $iins_type55
			   FROM ply_ins_type
			  WHERE ipolicy = $ipolicy
			    AND v_iins_type = '255';
			if(SQLCODE == SQLNOTFOUND)
			{
				flag255=0;
			}
			else
			{
				flag255=1;
			}
			
			/*�T�{���[�O49 or 117*
			$SELECT v_iins_type
			FROM ply_ins_type
			WHERE ipolicy = $ipolicy
			AND v_iins_type IN ('49','117');
			if(SQLCODE == SQLNOTFOUND)
			{
				flag49117=0;
			}
			else
			{
				flag49117=1;
			}
			
			if((flag24 == 1) && (flag55 == 1) && (strncmp(fchk_24,"Y",1) == 0))
			{
				if ((IsFcomp24(deduct_30)) && (IsFcomp55(deduct_30)))
				{
					strcpy(ps_dtl,str_ins_30_13);
				}
				else if (IsFcomp24(deduct_30))
				{
					strcpy(ps_dtl,str_ins_30_21);
				}
				else if (IsFcomp55(deduct_30))
				{
					strcpy(ps_dtl,str_ins_30_22);
				}
				else
				{
					strcpy(ps_dtl,str_ins_30_1 );
				}
			}
			else if((flag24 == 1) && (strncmp(fchk_24,"Y",1) == 0))
			{
				if (IsFcomp24(deduct_30))
				{
					strcpy(ps_dtl,str_ins_30_12);
				}
				else
				{
					strcpy(ps_dtl,str_ins_30_2);
				}		
			}
			else if((flag55 == 1) || (flag49117 == 1)) 
			{
				if (IsFcomp55(deduct_30))
				{
					strcpy(ps_dtl,str_ins_30_11);
				}
				else
				{
					strcpy(ps_dtl,str_ins_30_3);
				}		
			}
			else if(flag255 == 1)
			{
				strcpy(ps_dtl,str_ins_30_4);
			}*/
			
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

		case 301:

			/*$SELECT v_iins_type
			   INTO $iins_type55
			   FROM ply_ins_type
			  WHERE ipolicy = $ipolicy
			    AND v_iins_type = '55';
			if(SQLCODE == SQLNOTFOUND)
			{
				flag55=0;
			}
			else
			{
				flag55=1;
			}
			
			$SELECT v_iins_type
			   INTO $iins_type55
			   FROM ply_ins_type
			  WHERE ipolicy = $ipolicy
			    AND v_iins_type = '255';
			if(SQLCODE == SQLNOTFOUND)
			{
				flag255=0;
			}
			else
			{
				flag255=1;
			}*/
			strcpy(v_ncover1,rtrim(refmtamt(injured_cover,MILLIONTH)));
			strcpy(v_ncover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
			strcpy(tmp_deduct,itoa(deduct));
			strcpy(deduct_301,tmp_deduct);
			/*
			if(flag55 == 1)
			{
				if (IsFcomp55(deduct_301))
				{
					strcpy(ps_dtl,str_ins_301_11);
				}
				else
				{
					strcpy(ps_dtl,str_ins_301_1);
				}
			}
			else if(flag255 == 1)
			{
				strcpy(ps_dtl,str_ins_301_2);
			}*/
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
			
		case 302:

			/*$SELECT v_iins_type
			   INTO $iins_type55
			   FROM ply_ins_type
			  WHERE ipolicy = $ipolicy
			    AND v_iins_type = '55';
			if(SQLCODE == SQLNOTFOUND)
			{
				flag55=0;
			}
			else
			{
				flag55=1;
			}
			
			$SELECT v_iins_type
			   INTO $iins_type55
			   FROM ply_ins_type
			  WHERE ipolicy = $ipolicy
			    AND v_iins_type = '255';
			if(SQLCODE == SQLNOTFOUND)
			{
				flag255=0;
			}
			else
			{
				flag255=1;
			}*/
			
			strcpy(v_ncover1,rtrim(refmtamt(injured_cover,MILLIONTH)));
			strcpy(v_ncover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
			strcpy(tmp_deduct,itoa(deduct));
			strcpy(deduct_302,tmp_deduct);
			/*
			if(flag55 == 1)
			{
				if (IsFcomp55(deduct_302))
				{
					strcpy(ps_dtl,str_ins_302_11);
				}
				else
				{
					strcpy(ps_dtl,str_ins_302_1);
				}
			}
			else if(flag255 == 1)
			{
				if (IsFcomp55(deduct_302))
				{
					strcpy(ps_dtl,str_ins_302_21);
				}
				else
				{
					strcpy(ps_dtl,str_ins_302_2);
				}
			}*/
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;


		case 31: case 36: case 113: case 131: case 133: case 231: case 331: case 531:
			
			if(iins == 131)
			{
				strcpy(v_ncover1,refmtamt(injured_cover,MILLIONTH));
				/* �Y�O�B�G�W�L99,999,999��,��H�U����� */
				if (damage_cover > 99999999)
				{
					strcpy(v_ncover2,refmtamt((damage_cover/10000),MILLIONTH));
					strcat(v_ncover2,"�U");
				}
				else
					strcpy(v_ncover2,refmtamt(damage_cover,MILLIONTH));
				
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			}
			else
			{
				/*ins_31 = 1;*/
				strcpy(v_ncover1,refmtamt(injured_cover,MILLIONTH));
				/* �Y�O�B�G�W�L99,999,999��,��H�U����� */
				if (damage_cover > 99999999)
				{
					strcpy(v_ncover2,refmtamt((damage_cover/10000),MILLIONTH));
					strcat(v_ncover2,"�U");
				}
				else
					strcpy(v_ncover2,refmtamt(damage_cover,MILLIONTH));
				
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
				
				printf("--113 v_ndeduct[%s] deduct[%d] \n",v_ndeduct,deduct);
				
				if (iins == 31 || iins == 133 || iins == 113)
					strcpy(v_ndeduct,refmtamt(deduct,MILLIONTH));
				
				printf("--113 v_ndeduct[%s] deduct[%d] \n",v_ndeduct,deduct);
				
				/*ins_31_multiple = damage_cover / injured_cover;*/
				
				/* ���w�r�p�H */
				/*if(strstr(trim(provision),"D;") != NULL)
				{
					strcpy(ins31_provision,"�i���w�r�p�H�j");
					printf("---- 1439---v_iins_type=[%s]provision=[%s]ins31_provision=[%s]\n",v_iins_type,provision,ins31_provision);
				}
				else if(strstr(trim(provision),"J;") != NULL)
				{
					provision_J = 1;
					strcpy(ins31_provision,"�i�S�w�γ~�[�T�w�ϥΤH�j");
					printf("---- 1439---v_iins_type=[%s]provision=[%s]ins31_provision=[%s]\n",v_iins_type,provision,ins31_provision);
				}
				else
					ins31_provision[0]= '\0';*/
			}
			
			break;

		case 32: case 37: case 114: case 132: case 134: case 149: case 232: case 332: case 249: case 532:
				
			if(iins == 132)
			{
				strcpy(v_ncover1,refmtamt(damage_cover,MILLIONTH));
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			}
			else
			{
				/*ins_32 = 1;*/
				strcpy(v_ncover1,refmtamt(damage_cover,MILLIONTH));
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			}
			
			if (iins == 32 || iins == 134 || iins == 149 || iins == 114 || iins == 532)
				strcpy(v_ndeduct,refmtamt(deduct,MILLIONTH));
			break;

		case 34: case 87: case 115:
		
			/* �Ψ�Ū�����ݪ��I�ت��O�B�O�O */
			insurance_cover_count = 0;
			$SELECT COUNT(*)
			   INTO $insurance_cover_count
			   FROM insurance_cover
			  WHERE iins_type = $v_iins_type;
			/* �������ݪ����Ū�� */

/*?*/
			IcurrPlyInsCover=IfirstPlyInsCover=IlastPlyInsCover=NULL;    /* set init pointer to NULL */
		    #ifdef CA_CONS
		        IfirstPlyInsCover = get_ply_ins_cover( Full_DBName, table_cover, sColumn, itmp, &rtncode, v_sMsg);
		        if( rtncode != M_CM_OK)
		            return rtncode;
		    #endif
			
			/* �ΨӳB�z�I��34 */
			if( insurance_cover_count != 0)
			{    /* CA_CONS */
				IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "001");
				strcpy(v_ncover1, refmtamt(IcurrPlyInsCover->mcover, MILLIONTH));
				lPremSum += IcurrPlyInsCover->mcover_prem;

				IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "002");
				strcpy(v_ncover2, refmtamt(IcurrPlyInsCover->mcover, MILLIONTH));
				lPremSum += IcurrPlyInsCover->mcover_prem;

				IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "003");
				strcpy(v_ncover3, refmtamt(IcurrPlyInsCover->mcover, MILLIONTH));
				lPremSum += IcurrPlyInsCover->mcover_prem;

				IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "004");
				strcpy(v_ncover4, refmtamt(IcurrPlyInsCover->mcover,MILLIONTH));
				
				strcpy(n_ins_premium,refmtamt( lPremSum,MILLIONTH)); /* �L�X���I�ؤ��P�O�B�X�p���O�O */
			}
			break;

		case 38: case 39:
		
			strcpy(v_ncover1,ltoa(qday));
			strcat(v_ncover1,"����");
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

		case 35: 
/*?*/			
			/*strcpy(Full_DBName,get_car_full_db(ipolicy));*/
			sprintf_s(stmt, sizeof stmt,"SELECT distinct iins_scope "
			              " FROM %s:%s %s "
			              "  AND iins_type = '35' "
			              "  AND mins_amt > 0;",Full_DBName,table_pa,stmp1);
			$PREPARE pa_ply_35 FROM $stmt;
			$DECLARE pa_ply35_cur CURSOR FOR pa_ply_35;
			$OPEN pa_ply35_cur;
			$FETCH pa_ply35_cur INTO $tmp_iins_scope;
			$CLOSE pa_ply35_cur;
			$FREE pa_ply35_cur;
			
			strcpy(nins_type,trim(nins_type));
			
			if( strcmp(trim(tmp_iins_scope),"1") == 0 ) strcat(nins_type,"  �O�W��");
			else if( strcmp(trim(tmp_iins_scope),"2") == 0 ) strcat(nins_type,"  �a�x��");
/*?*/		
			if (strcmp(trim(tmp_iins_scope),"1") != 0) strcpy(cover_print,"");
			
			strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
    
		case 48:
		
			if (damage_cover > 99999999)
			{
				strcpy(v_ncover1,refmtamt((damage_cover/10000),MILLIONTH));
				strcat(v_ncover1,"�U");	
			}
			else
			{
				strcpy(v_ncover1,refmtamt(damage_cover,MILLIONTH));
			}
			
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

		case 47: case 147:
		
			/*if(strcmp(v_iins_type,"147")==0) ins_56 = 1;*/
			
			if (injured_cover > 99999999)
			{
				strcpy(v_ncover1,refmtamt((injured_cover/10000),MILLIONTH));
				strcat(v_ncover1,"�U");                		
			}
			else
			{
				strcpy(v_ncover1,refmtamt(injured_cover,MILLIONTH));
			}
			
			if (death_cover > 99999999)
			{
				strcpy(v_ncover2,refmtamt((death_cover/10000),MILLIONTH));
				strcat(v_ncover2,"�U");               		
			}
			else
			{
				strcpy(v_ncover2,refmtamt(death_cover,MILLIONTH));
			}
			
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

		case 49: 
		
			strcpy(v_ncover1,refmtamt(injured_cover,MILLIONTH));
			strcpy(v_ncover2,refmtamt(death_cover,MILLIONTH));
			strcpy(v_ncover3,refmtamt(damage_cover,MILLIONTH));
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

		case 50:
		
			if (injured_cover > 99999999)
			{
				strcpy(v_ncover1,refmtamt((injured_cover/10000),MILLIONTH));
				strcat(v_ncover1,"�U");                		
			}
			else
			{
				strcpy(v_ncover1,refmtamt(injured_cover,MILLIONTH));                	
			}
			
			if (death_cover > 99999999)
			{
				strcpy(v_ncover2,refmtamt((death_cover/10000),MILLIONTH));
				strcat(v_ncover2,"�U");                	
			}
			else
			{
				strcpy(v_ncover2,refmtamt(death_cover,MILLIONTH));                	
			}
			
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

		case 52: case 252:
		
			if (qcoverage > 2)
			{
				strcpy(v_ncover1,refmtamt(injured_cover,MILLIONTH));
				strcpy(v_ncover2,refmtamt(death_cover,MILLIONTH));
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
				/*people = (int) (damage_cover / death_cover);*/
				/* �Y�O�B�T�W�L99,999,999��,��H�U����� */
				if (damage_cover > 99999999)
				{
					strcpy(v_ncover3,refmtamt((damage_cover/10000),MILLIONTH));
					strcat(v_ncover3,"�U");
				}
				else
				strcpy(v_ncover3,refmtamt(damage_cover,MILLIONTH));
			}
			else
			{
				strcpy(v_ncover1,refmtamt(death_cover,MILLIONTH));
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
				/*people = (int) (damage_cover / death_cover);*/
				/* �Y�O�B�T�W�L99,999,999��,��H�U����� */
				if (damage_cover > 99999999)
				{
					strcpy(v_ncover2,refmtamt((damage_cover/10000),MILLIONTH));
					strcat(v_ncover2,"�U");
				}
				else
					strcpy(v_ncover2,refmtamt(damage_cover,MILLIONTH));
			}
			break;

		case 51:
			
			/*ins_51 = 1;*/
			strcpy(v_ncover1,refmtamt(injured_cover,MILLIONTH));
			strcpy(v_ncover2,refmtamt(death_cover,MILLIONTH));
			/* �Y�O�B�T�W�L99,999,999��,��H�U����� */
			if (damage_cover > 99999999)
			{
				strcpy(v_ncover3,refmtamt((damage_cover/10000),MILLIONTH));
				strcat(v_ncover3,"�U");
			}
			else
				strcpy(v_ncover3,refmtamt(damage_cover,MILLIONTH));
			
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			
			/*if( (iins == 51) && (death_cover == damage_cover))
			strcpy(ps_dtl,str_ps);*/
			break;

		case 53: case 55: case 117: case 135: case 255: case 253: case 555:
		
			if (qcoverage > 2)
			{
				strcpy(v_ncover1,refmtamt(injured_cover,MILLIONTH));
				strcpy(v_ncover2,refmtamt(death_cover,MILLIONTH));
				/* �Y�O�B�T�W�L99,999,999��,��H�U����� */
				if (damage_cover > 99999999)
				{
					strcpy(v_ncover3,refmtamt((damage_cover/10000),MILLIONTH));
					strcat(v_ncover3,"�U");
				}
				else
					strcpy(v_ncover3,refmtamt(damage_cover,MILLIONTH));
				
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			}
			else
			{
				strcpy(v_ncover1,refmtamt(death_cover,MILLIONTH));
				/* �Y�O�B�G�W�L99,999,999��,��H�U����� */
				if (damage_cover > 99999999)
				{
					strcpy(v_ncover2,refmtamt((damage_cover/10000),MILLIONTH));
					strcat(v_ncover2,"�U");
				}
				else
					strcpy(v_ncover2,refmtamt(damage_cover,MILLIONTH));
				
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			}
			
			break;

		case 56: case 136: case 166: case 266:
			
			daily_pay = 0;
			/*ins_56 = 1;
			strcpy(Full_DBName,get_car_full_db(ipolicy));*/
			sprintf_s(stmt, sizeof stmt,"SELECT max(daily_pay) "
			              " FROM %s:%s %s "
			              "  AND iins_type in ('56','136','166','266');",Full_DBName,table_pa,stmp1);
			$PREPARE pa_ply_56 FROM $stmt;
			$DECLARE pa_ply56_cur CURSOR FOR pa_ply_56;
			$OPEN  pa_ply56_cur;
			$FETCH pa_ply56_cur INTO $daily_pay;
			$CLOSE pa_ply56_cur;
			$FREE  pa_ply56_cur;
			
			strcpy(v_ncover1,refmtamt(daily_pay,MILLIONTH));
			if (damage_cover > 99999999)
			{
				strcpy(v_ncover2, refmtamt((damage_cover /10000),MILLIONTH));
				strcat(v_ncover2,"�U");                 	
			}
			else
			{
				strcpy(v_ncover2, refmtamt(damage_cover,MILLIONTH));
			}
			
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

		case 57: case 59: case 60:
		
			if (qcoverage > 2)
			{
				/* ���L��� */
				strcpy(v_ncover1,refmtamt(injured_cover,MILLIONTH));
				strcpy(v_ncover2,refmtamt(death_cover,MILLIONTH));
				/* �Y�O�B�T�W�L99,999,999��,��H�U����� */
				if (damage_cover > 99999999)
				{
					strcpy(v_ncover3,refmtamt((damage_cover/10000),MILLIONTH));
					strcat(v_ncover3,"�U");
				}
				else
					strcpy(v_ncover3,refmtamt(damage_cover,MILLIONTH));
			}
			else
			{
				/* ���L��� */
				strcpy(v_ncover1,refmtamt(death_cover,MILLIONTH));
				/* �Y�O�B�G�W�L99,999,999��,��H�U����� */
				if (damage_cover > 99999999)
				{
					strcpy(v_ncover2,refmtamt((damage_cover/10000),MILLIONTH));
					strcat(v_ncover2,"�U");
				}
				else
					strcpy(v_ncover2,refmtamt(damage_cover,MILLIONTH));
			}
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			
			/*ins_575960 = 1;*/
			break;

		case 61: case 65: case 69: case 68: case 108:
		
			strcpy(v_ncover1,refmtamt(damage_cover,MILLIONTH));
			strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
		
		case 62: case 63: case 64: case 143:
		
			if (qcoverage > 1)
			{	
				/* �A�ηs��(���G�ӫO�B) add by sylvia 101.12.25 (1011214002_C1) */
				strcpy(v_ncover1,refmtamt(injured_cover,MILLIONTH));
				strcpy(v_ncover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcat(v_ndeduct,refmtamt(deduct,MILLIONTH));
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			}
			else
			{
				/* �A���¨�(�u���@�ӫO�B) */
				strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcat(v_ndeduct,refmtamt(deduct,MILLIONTH));
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
			}
			break;

			case 71: case 72: case 78: case 79: case 89: case 90:
				
				strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
				break;

			case 77: case 80:
				
				strcpy(v_ncover1,refmtamt(injured_cover,MILLIONTH));
				if (damage_cover > 99999999)
				{
				strcpy(v_ncover2,refmtamt((damage_cover/10000),MILLIONTH));
				strcat(v_ncover2,"�U");
				}
				else
				strcpy(v_ncover2,refmtamt(damage_cover,MILLIONTH));
				
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
				break;

			case 96:
				
				strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcpy(v_ndeduct,refmtamt(deduct,MILLIONTH));
				strcat(v_ndeduct,"%");
				/* strcpy(n_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH))); */
				/* Ū��96+97�O�O */
				sprintf_s(sStmt, sizeof sStmt, "SELECT sum(mins_premium) "
				                " FROM %s:%s %s "
				                "  AND iins_type in ('96','97');",Full_DBName,table_pa,stmp1);
				$PREPARE plyInsType96_cur FROM $sStmt;
				$EXECUTE plyInsType97_cur INTO $ins_premium;
				
				strcpy(n_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
				break;
			
			case 97:
			
				strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
				break;

			case 107:
			
				strcpy(v_ncover1,refmtamt(injured_cover,MILLIONTH));
				strcpy(v_ncover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcat(v_ndeduct,refmtamt(deduct,MILLIONTH));
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
				break;

			case 154: case 155: case 156: case 163:
			
				strcpy(v_ncover1,ltoa(qday));
				strcat(v_ncover1,"��");
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
				strcpy(v_ncover2,rtrim(refmtamt(injured_cover,MILLIONTH)));
				break;

			case 238:
			
				if (qday == 999)
				{
					/*strcpy(v_ncover4,"����");*/
					strcat(nins_type,"(��Q���{����");
				}
				else
				{
					/*strcpy(v_ncover4,ltoa(qday));*/
					strcat(nins_type,"(��Q���{");
					strcat(nins_type,ltoa(qday));
				}
				/*strcat(v_ncover4,"����");*/
				strcat(nins_type,"����)");

				strcpy(v_cover_print1,"�C�@�ƬG");
				strcpy(v_cover_print2,"�O�I����");
				
				strcpy(v_ncover1,rtrim(refmtamt(injured_cover,MILLIONTH)));
				strcpy(v_ncover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
	
				break;
				
			case 173:
				
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
				strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
				break;
				
			case 174:
			
				strcpy(v_ncover1,refmtamt(injured_cover,MILLIONTH));
				strcpy(v_ncover2,refmtamt(damage_cover,MILLIONTH));
				
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
				strcpy(v_ndeduct,refmtamt(deduct,MILLIONTH));
				strcat(v_ndeduct,"%");
				break;
				
			case 175:

				strcpy(v_ncover1," ");
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
				break;
				
			case 176:
				
				if (deduct == 0)
				{}
				else 
				{
					strcat(v_ndeduct,refmtamt(deduct,MILLIONTH));
					strcat(v_ndeduct,"%");
				}
				strcpy(v_ncover1," ");
		    		strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
		    		break;
		    		
			case 177:
			
				if (deduct == 0)
				{}
				else 
				{
					strcat(v_ndeduct,refmtamt(deduct,MILLIONTH));
					strcat(v_ndeduct,"%");
				}
				strcpy(v_ncover1," ");
		    		strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
		    		break;
		    		
			case 178:
			/*
				strcpy(v_cover_print1,"�ƬG���B");
				strcpy(v_cover_print2,"�~�׭��B");
			*/
				if (deduct == 0)
				{}
				else 
				{
					strcat(v_ndeduct,refmtamt(deduct,MILLIONTH));
					strcat(v_ndeduct,"%");
				}
				
				strcpy(v_ncover1,rtrim(refmtamt(injured_cover,MILLIONTH)));
				strcpy(v_ncover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
				break;
					
			case 237:
						
				strcpy(v_cover_print1,"�C�@�ƬG");
				strcpy(v_cover_print2,"�O�I����");
				
				strcpy(v_ncover1,rtrim(refmtamt(injured_cover,MILLIONTH)));
				strcpy(v_ncover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
				break;

			case 561: case 563:
			
				strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
				break;

			case 562:
			
				strcpy(v_ncover1,rtrim(refmtamt(injured_cover,MILLIONTH)));				
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
				break;

			default:
			
				strcpy(v_ncover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcpy(n_ins_premium,refmtamt(ins_premium,MILLIONTH));
				break;
	}
	
	/* �I�ئW�� */
	strcpy(v_nins_type,trim(nins_type));
	/*  */
	strcpy(v_edomain,trim(edomain));
	
	
	end_get_ply_ins_dtl( v_sMsg);
	return M_CM_OK;
	
errexit:
	sprintf_s(v_sMsg2, sizeof v_sMsg2, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
	strcpy(v_sMsg, v_sMsg2);
	/*sprintf_s(v_sMsg, sizeof v_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);*/
	end_get_ply_ins_dtl( v_sMsg);
	return SQLCODE;

}

void end_get_ply_ins_dtl( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_ply_ins_dtl function");
  puts("******************************");
  puts("");
}

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
	char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
	static char sTmp_db_name[21];
	
	sTmp_db_name[0]='\0';
	if (*sIpolicy != '\0' && *sIpolicy !=' ')
	{
		sTmp_db_name[0]='\0';
		strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
		strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
		strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
	}
	return sTmp_db_name;
}