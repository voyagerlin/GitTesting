/*
   Name       : get_route_data
   Input      : v_iType  1:sales name     2:route name
                v_sIofficer      �g��N��
                v_sIbig_officer  ��~���I�N��   
                v_sIbig_sales    �~�N�N�� ( = "", if v_iType == 2)
                v_sNName   ��~���I�W��  or  �~�N�W��
   return code: M_CM_OK ���\
   Output     : v_sName   ��~���m�W
                v_sMsg        �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"

long get_route_data( v_iType, v_sIofficer,v_sIbig_office, v_sIbig_sales, v_sNName, v_sMsg)
$int     v_iType;
$char    *v_sIofficer,*v_sIbig_office, *v_sIbig_sales, *v_sNName, *v_sMsg;
{
  $int    iType ;
  $char   sIofficer[11]= "" ,sIbig_office [10]="",sIbig_sales[11] ="" , sName[41]="" ;
  $char   sIbig_office1_4[5]="",sFsales[2]="",sIcar_broker[11]="";
  $char   sImgr[2]="";  
  
  $char v_sMsg2[1000]; /* ���T����J���ɭԥΪ��Ȧs�}�C */

  $WHENEVER SQLERROR GOTO errexit;

  iType = v_iType;  
  strcpy( sIofficer, v_sIofficer);
  strcpy( sIbig_office, v_sIbig_office);
  strcpy( sIbig_sales   ,  v_sIbig_sales);
  
  /*sName = (char *) malloc(sizeof(v_sNName)+1);*/
  
  printf("     iType[%d], sIofficer=[%s],  sIbig_sales=[%s]\n",  iType, sIofficer, sIbig_sales);
  printf("     ibig_office[%s]\n",sIbig_office);
  
  /*sName[0] = '\0';*/
  v_sNName [0] = '\0'; 

  if (sIofficer[0]=='' || sIofficer[0]=='\0'){
	  sprintf_s(v_sMsg2, sizeof v_sMsg2, "�g��N���ť� sIofficer=[%S] \n", sIofficer);
	  strcpy(v_sMsg, v_sMsg2);
	  /*sprintf_s(v_sMsg, sizeof v_sMsg, "�g��N���ť� sIofficer=[%S] \n", sIofficer);*/
	  return -1;
  }
  
  if (sIbig_office[0]=='' || sIbig_office[0]=='\0')
  {
      strcpy(v_sNName," ");
      return M_CM_OK;
  }       
   
  if (iType == 1)
  {
  	  if (sIbig_sales[0]=='' || sIbig_sales[0]=='\0')
  	  {
          strcpy(v_sNName," ");
      	 return M_CM_OK;
     } else {  
          strncpy(sIbig_office1_4,sIbig_office,4);
          strcat(sIbig_office1_4,"*");
          printf("Trace -- sIbig_office1_4 = [%s] \n",  sIbig_office1_4);
     }     
  }   
  /* dws9807212 ���fsales��table��officer�ɧאּ�q����(cm_route),�ҥH�ݭn��
       officer.iroute[1,4]������h�^��cm_route����fsales */
  /* �t�X�q���ĤG���q,���A�^���g���H�N�� */     
  /* $SELECT nvl(b.icar_broker,''),nvl(a.imgr,' ')
     INTO $sIcar_broker, $sImgr
     FROM officer a,officer_broker b  
    WHERE a.iofficer = b.iofficer
      AND a.iofficer = $sIofficer;      */
  $SELECT nvl(a.imgr,' ')
     INTO $sImgr
     FROM officer a
    WHERE a.iofficer = $sIofficer;      
  if(SQLCODE==SQLNOTFOUND){
  	  printf("Trace -- iofficer = [%s] \n",  sIofficer);
 	  return M_CA_NOT_IOFFICER;	 
  } 	     
  
printf("sImgr[%s]\n",sImgr);
  
  /* ���ӥ�imgr��쬰"1",��L�h�����q�� */
  
  if (iType == 1){  /* �~�N����~���W�� */
	  /* if ( (sImgr[0]!='1') ||
	 	  (strncmp(sIcar_broker,"RD",2)==0 || strncmp(sIcar_broker,"RDA",3)==0 ) ) */
	  if (sImgr[0]!='1')
	   {
	 	   printf("Trace -- TEST 6\n");
	 	   printf("Get -- �~�N����~���W�� \n");
	 	  /* cmn121/127 �]�w��*/
 	       $SELECT nsales INTO $sName FROM cm_route_sales WHERE isales = $sIbig_sales AND iroute matches $sIbig_office1_4;
 	       printf("Trace1 -- sName = [%s] \n",  sName);
 	       printf("Trace -- SQLNOTFOUND = [%d] \n",  SQLNOTFOUND);
	       if(SQLCODE==SQLNOTFOUND){
	         printf("Trace -- sIbig_office1_4 = [%s] \n",  sIbig_office1_4);
	     	 printf("Trace -- cm_route_sales.isales = [%s] \n",  sIbig_sales);
	     	 return M_CMN_NSALES;
	      }
	   }else{
	   	  /* car121 �]�w��*/	   	    	   
          $SELECT nname[1,10] INTO $sName FROM ca_big_office WHERE fclass = '2'  AND ibig_comp = $sIbig_sales;     	  	
	       if(SQLCODE==SQLNOTFOUND){
	     	 printf("Trace -- ca_big_office.ibig_comp = [%s] \n",  sIbig_sales);
	     	 return M_CA_BIG_SALES_NOT_FOUND;
	      }
	   }
  }else if (iType == 2){ /* ��~���I�W�� */
	  /* if ( (sImgr[0]!='1') ||
	 	  (strncmp(sIcar_broker,"RD",2)==0 || strncmp(sIcar_broker,"RDA",3)==0 ) ) */
	 	if (sImgr[0]!='1')
	 	{
	 	  /* cmn121/127 �]�w��*/
 	       $SELECT nroute INTO $sName FROM cm_route WHERE iroute = $sIbig_office;
	       if(SQLCODE==SQLNOTFOUND){
	         printf("Trace -- sIbig_office = [%s] \n",  sIbig_office);
	     	 return M_CMN_NROUTE;
	      }
	   }else{
	   	  /* car121 �]�w��*/
          $SELECT nname[1,10] INTO $sName FROM ca_big_office WHERE fclass = '1'  AND ibig_comp = $sIofficer;     	  	
	      if(SQLCODE==SQLNOTFOUND){
	     	 printf("Trace -- sIofficer = [%s] \n",  sIofficer);
	     	 return M_CA_NBIG_OFFICE;
	      }
	   } 
  }else{
	 sprintf_s(v_sMsg2, sizeof v_sMsg2, "iType=[%d] ���O���ĭ�\n", iType);
	 strcpy(v_sMsg, v_sMsg2);
     /*sprintf_s(v_sMsg, sizeof v_sMsg, "iType=[%d] ���O���ĭ�\n", iType);*/
     return -1;
  }
  
  printf("Trace -- sName = [%s] \n",  sName);
  strcpy( v_sNName, trim(sName));

  
printf("**************** julia\n");
printf("length sname[%d];;v_snname[%d]\n",strlen(sName),strlen(v_sNName));	

  free(sName);

  return M_CM_OK;

errexit:
  sprintf_s(v_sMsg2, sizeof v_sMsg2, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy(v_sMsg, v_sMsg2);
  /*sprintf_s(v_sMsg, sizeof v_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);*/
  return SQLCODE;
}
