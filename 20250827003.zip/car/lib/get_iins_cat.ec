/*
   Name       : get_iins_cat
   Purpose    : �̨��إN�����o�������O

   Input      : *v_icar_type		���إN��
                1:�X���,2:�������[���ڥ�
                v_qperiod               �O��(��)

   Output     : return code 		M_CM_OK ���\
                *v_iins_cat	  	�������O	
                *v_iyear	        �~��
                v_sMsg      		�T��
*/

#include "commsgs.h"
#include "carmsgs.h"
$include "var_length.h";
#include "safeclib.h"

void end_get_iins_cat( );

long get_iins_cat( char   *v_icar_type,
                   int    v_itype,
                   int    v_period,
                   char   *v_iins_cat,
                   char   *v_iyear,
                   char   *v_sMsg)
{
  $char tmp_iins_cat[IINS_CAT],tmp_icar_type[10];  
  $WHENEVER SQLERROR GOTO errexit;

  puts("");
  puts("******************************");
  puts("begin get_iins_cat function");
  printf("     v_icar_type[%s] v_period[%s] \n ", v_icar_type, v_period); 
  printf("funtion in \n");
  /* 103.11.05:1031022002_C1:�t�X�T���I�������������� */
  /* �L�q���i�ӫO1-5�~�j���I (1110718002_SC1) */
  /* �s�W�L�q�������I�O(1111019003_SC1) */
  strcpy( tmp_icar_type, v_icar_type);
  strcpy( tmp_icar_type, trim(tmp_icar_type));
  strcpy( tmp_iins_cat, " ");  strcpy( v_iins_cat, " ");  strcpy( v_iyear, " ");
  
  $SELECT trim(ncode) INTO $tmp_iins_cat 
     FROM cu_code_data
    WHERE itype = '97'
      AND icode = $tmp_icar_type;
  if(SQLCODE==SQLNOTFOUND) return M_CA_IINS_CAT_NOT_FOUND;
  printf("     tmp_iins_cat[%s] \n ", tmp_iins_cat); 
    
  if (strncmp(tmp_iins_cat,"Z",1)==0 || strncmp(tmp_iins_cat,"Y",1)==0  ){
  	if(v_period < 24){
  		strcpy( v_iyear, "1");
  	}else if(v_period >= 24 && v_period < 36){
  		strcpy( v_iyear, "2");  
  	}else if(v_period >= 36 && v_period < 48){
  		strcpy( v_iyear, "3");  
  	}else if(v_period >= 48 && v_period < 60){
  		strcpy( v_iyear, "4");  
  	}else if(v_period == 60){
  		strcpy( v_iyear, "5");  
  	}
  }else{
  	strcpy( v_iyear, "0");
  }
    
  if( v_itype != 1){  /* �u�� get_ca_id_officer( v_itype=2)   */
  	  if (tmp_iins_cat[0]=='X') {
  	 	  tmp_iins_cat[0] = 'C'; 
  	  }
  }
  
  strcpy(v_iins_cat, tmp_iins_cat);
  
/*  
  if( strncmp( v_icar_type, "01", 2) ==0 ||
      strncmp( v_icar_type, "02", 2) ==0 ||
      strncmp( v_icar_type, "32", 2) ==0 ||
      strncmp( v_icar_type, "34", 2) ==0 )
  {
      strcpy( v_iins_cat, "Z");
      if( v_period == 24)
          strcpy( v_iyear, "2");
      else
          strcpy( v_iyear, "1");
           
  }
  else if( strncmp( v_icar_type, "03", 2) ==0 ||
           strncmp( v_icar_type, "04", 2) ==0 ||
           strncmp( v_icar_type, "19", 2) ==0 ||
           strncmp( v_icar_type, "21", 2) ==0 ||
           strncmp( v_icar_type, "22", 2) ==0 )
  {
      strcpy( v_iins_cat, "C");
      strcpy( v_iyear, "0");
  }
  else
  {
      if( v_itype == 1)
          strcpy( v_iins_cat, "X");
      else
          strcpy( v_iins_cat, "C");
      strcpy( v_iyear, "0");
  }
*/
  sprintf_s( v_sMsg, 250,"Found v_icar_type[%s] ==> iins_cat[%s] ==> v_iyear[%s] \n", v_icar_type, v_iins_cat, v_iyear);

  end_get_iins_cat( v_sMsg);

  return M_CM_OK;

errexit:

  sprintf_s( v_sMsg, 250,"SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  end_get_iins_cat( v_sMsg);
  return SQLCODE;


}

void end_get_iins_cat( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_iins_cat function");
  puts("******************************");
  puts("");
}