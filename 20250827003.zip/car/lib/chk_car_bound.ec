/*
   Name       : chk_car_bound
   Input      : v_sIestimate 	�պ⸹	ex: A03017
   return code: M_CM_OK ���\
   Output     : v_bound         �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
long chk_car_bound( v_sIestimate, v_bound)
$char    *v_sIestimate,*v_bound;
{
	  $char stmt[2048],v_sMsg[1024];
	  $char iestimate[21],ibrand[9],sIins_type[7];
	  $int  mdamage_cover = 0;
	  $char have_over_600[2],sports_car[2];
	  $int haveDmg,haveBrg,flagm,iCount = 0,iins_type,flag;

	  haveDmg = 0;
	  haveBrg = 0;
	  flag = 0;
	  strcpy(have_over_600,"N");
	  strcpy(v_bound,"");

	  $WHENEVER SQLERROR GOTO errexit;

	  puts("");
	  puts("***********************************");
	  puts("begin chk_car_bound function");
	  printf("v_sIestimate=[%s]\n", v_sIestimate);
	  
	  $SELECT iestimate,ibrand
	     INTO $iestimate,$ibrand
	     FROM estimate
	    WHERE iestimate = $v_sIestimate;

	    if(SQLCODE == SQLNOTFOUND)
	    	return M_CMN_NO_DATA_FOUND;

	  sprintf_s(stmt,sizeof stmt,
			"SELECT iins_type,mdamage_cover"
			"  FROM est_ins_type   "
			" WHERE iestimate = '%s' "
			,iestimate);
			
			printf("stmt[%s]\n", stmt);
	
	        $PREPARE pre1_1 FROM $stmt;
	        $DECLARE cur_pre1_1 CURSOR for pre1_1;
	      	$OPEN cur_pre1_1;
	      	
	   while(1)
	   {
	   		$FETCH cur_pre1_1 INTO $sIins_type,$mdamage_cover;
	
	        if(SQLCODE == SQLNOTFOUND) break;
			
			iins_type = atoi(sIins_type);
			switch(iins_type)
			{
			   case 1: case 5: case 8: case 9: case 85: case 98: case 105: case 118: case 120: case 122: case 125: case 126: case 137: case 138:
			   	haveDmg = 1;
			   	if (mdamage_cover > 6000000)
			   		strcpy(have_over_600,"Y");
			   break;
			   
			   case 11: case 18: case 96: case 129: case 211:
			   	haveBrg = 1;
			   	if (mdamage_cover > 6000000)
			   		strcpy(have_over_600,"Y");
			   break;
			   
			   default:
			   break;
			}
	   }
	   
	   /*** �]������ ***/
	   $SELECT COUNT(*)
          INTO $iCount
          FROM ca_car_model
         WHERE ibrand=$ibrand
           AND sports_car = 'Y'
           AND (dexpire is null or dexpire > today);

		 if( iCount != 0)
		     strcpy( sports_car, "Y");
		 else
		     strcpy( sports_car, "N");

	   /*** ���O����B01�ˮ� ***/
	   if(haveDmg == 1 || haveBrg == 1)
	   {
	   		if( strncmp(trim(ibrand),"34",2) == 0 || strncmp(trim(ibrand),"37",2) == 0 ||
				strncmp(trim(ibrand),"44",2) == 0 || strncmp(trim(ibrand),"70",2) == 0 ||
				strncmp(trim(ibrand),"C2",2) == 0 || strncmp(trim(ibrand),"77",2) == 0 ||
				strncmp(trim(ibrand),"78",2) == 0 || strncmp(trim(ibrand),"29",2) == 0 ||
				strncmp(trim(ibrand),"B4",2) == 0 || strncmp(trim(ibrand),"D1",2) == 0 ||
				strncmp(trim(ibrand),"G8",2) == 0 || strncmp(trim(ibrand),"H4",2) == 0)
			{
				printf("B01.�t�P�����N���}�Y��34�B37�B44�B70�BC2�B77�B78�B29�BB4�BD1�BG8�BH4�ӫO�����I���ѵs�I\n");
				flag = 1;
			}
			
			if(strcmp(trim(sports_car),"Y") ==0 && (haveDmg == 1 || haveBrg == 1))
			{
				printf("B01.�]��/�S�w�����ӫO���l�I\n");
				flag = 1;
			}

			if(strcmp(have_over_600,"Y") == 0)
			{
				printf("B01.�O�B�O600�U�W�Q�����ӫO�����I���ѵs�I\n");
				flag = 1;
			}
			
			if (flag == 1)
	   		{
	   			strcat(v_bound,"B01;");
	   			flag = 0;
	   		}
	   }

	   return M_CM_OK;

errexit:
  sprintf_s( v_sMsg,sizeof v_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]); 
  return SQLCODE;
}

