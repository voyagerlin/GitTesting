/*****************************************************************************/
/*  BACKUP Policy DATA Into policy_bak, ply_relation_bak, ply_ins_type_bak   */
/*****************************************************************************/
/*10.23.2023�G1120927002_C02 �R�q�ΰӫ~�}�o */

#include "commsgs.h"
#include "cmnmsgs.h"
#define FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND
#include "ISvar.h"
$include "var_length.h";
$include "ply_ins_cover.h";
$include "ply_ins_assured.h";
$include sqlca;
$include sqltypes;
#include "safeclib.h"

bk_401 (DB, policy, endorse)
char *DB;
$char *policy, *endorse;
{
    EXEC SQL BEGIN DECLARE SECTION;
         /***** Table:ply_relation *****/
         char     ipolicy[21],icard[21];
         char     fcard_class[2],irelative_ply[21],ilast_card[21],ilast_ply[21];
         char     inext_ply[21],itmp_policy[21],itreaty[2],iissue_ym[6],ipro_year[5];
         char     ibrand[9],icar_type[3],ibig_comp[2],ibig_branch[5],ibig_office[10],ibig_sales[11];
         char     iresource[2],ibroker[11],iofficer[11],ileader[11],icorps[11];
         char     iarea[11],icashier[11],iexaminer[11];
         char     ientry[11],fprint[2],fedr_class[2],ibranch[3],iquota[7],icomp_in[3],ibranch_in[3];
         char     icomp_at[3],ibranch_at[3],fcomp_class[3],fcomp_class_last[3],fdiscount[2],ipay_way[2];
         char     icar_flag[2],transno[21];
         long     qply_period,mdmg_agent,mdmg_commi,mdmg_discount,mdmg_prem,mlia_agent;
         long     mlia_commi,mlia_discount,mlia_prem;
         long     dply_begin,dply_end,dexamine,dentry,dpolicy,dply_close,dapply,drenew_print;
         long     dtransfer,dendorse;
         double   mdmg_pure_prem,mlia_pure_prem,mready,mstable,mcompensation,madjcom_prem,mbusiness,mresearch,mcapital;
         double   minvest, mbus_rule,maintain;
         int      ibatch_no,seqno;
         char     iofficer_prmt[11],iquota_prmt[7],ileader_prmt[11];           /* (�M�ץ�)�^�k�g��H�N��,�~�Z���H�κ޲z�H */
         char     isecond_hand[7], icard_main[21];
         int      qdrunk_driving,qviolate;  /*1110608012_SC2 �s�W�j��I�O�v�ǤJ���j�H�W�[�O���*/
         char     feply[2], feedr[2],feterms[2], aemail_eply[51], dcreate_eply[31],tmobile_eply[21];
         long     mdrunk_prem,mviolate_prem;              /*1110608012_SC2 �s�W�j��I�O�v�ǤJ���j�H�W�[�O���*/
         double   mdrunk_pure_prem,mviolate_pure_prem;
         double   pcar_price;
         char     isign[11];
         char     dtply_begin[17],dtply_end[17],ireg_no[21]; 
         char     dnotifyornot[31]; /* 1090831006_SC2 �{�ҥ��x�j��q�l���ҥ���g�����mail�ˮ� */
         char     funder_chk[2]="",iprog[11]="";
         int      fsign_status=0;
         char     ftrans_third[2]=""; /* 1110303014_SC2 �t�X���ظ�Ʀ@�ɡA�ӽШ��I�Φ����X��t�ηs�W��� */


         /***** Table:policy *****/
         /* char     ipolicy[21],icard[21]; */
         char     ixxcard[21], fassured[2], iassured[13], iassured_ext[3], nassured[121], ilicense[11];
         char     ibirth[9], fsex[2], fmarriage[2], nuser[19], ibenef[11], nbenef[43], aassured[91];
         char     aassured_zip[CA_ZIP], itel[21], iemail[51], itel_night[21], mobil_phone[21], apayment[91], apayment_zip[CA_ZIP], iply_area[11];
         char     itel_night_cus[21], mobil_phone_cus[21], iemail_cus[51];
         char     nbrand_abbr[13], ncar_abbr[13], fcar_note[3], iengine[CA_ENGINE_NUM], ibody[CA_BODY_NUM], itag[CA_TAG_NUM], nequipment[31];
         char     flimit[2], iabn_type[2], fpass[2], ipass[11], ffac[2], fcut[2], fcal_way[2], idmg_rate[3];
         char     ibrg_rate[3], fpt[2], lia_class[3], fhuman[2], fcomp_24[2];
         long     pdmg_align, pbrg_align, plia_align;
         int      dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd;
         long     dpass, dfac;
         double   mcar_price, pdmg_factor, pbrg_factor, qpt, psex_age, plia_acc, pdmg_acc, psex_age_damage,qcylinder;
         char     iext_policy[21], irisk[2], irelative_ext[21];         
         long     qpro_month, mkilo_ply, mkilo_edr;
         char     napplicant[121];                                      /* car9705152 - �n�O�H */
         long     dbirth, dissue;                                       /* cmn9708011 - ����100�~ */
         char     iextra_charge[11];                                    /* for���[�O�βv�ϥ� */
         int      gextra_charge;                                        /* for���[�O�βv�ϥ� */
         char     iquery_num_damage[15], iquery_num[15];                /* car9706251 - ���T�d�ߧǸ�*/         
         double   mequipment;                                           /* ���m���t�t�ƻ� */
         char     survey_num[121], bound_num[121], abnormal_num[11];      /* ����easy flow�渹 */
         char     iapplicant[13];                                       /* �n�O�HID */ 
         char     iroute[21];                                           /* �q���N�� */        
         char     irate_type[2],bzfrom[3],iroute_comm[4],icomm_obj[11];
         char     ibound[421];

         /* 1000728003_C2 �ĤT�H�d���I���ŧאּ5��(���) */
         long     qlia_acc_sum, qdmg_acc_sum;

         $char fapplicant[2], fsex_appl[2], dbirth_appl[11], itel_appl[21], ndeputy_appl[51], nrelation_appl[41], ndeputy_assured[51];

         /***** Table:ply_ins_type *****/
         /* char     ipolicy[21]; */
         char     iins_type[7], fedr_status[2], iendorse_old[21], drate_ym[5], iproduct[13];
         double   mpure_prem, pcommission, pagent, pdiscount;
         long     minjured_cover, mdeath_cover, mdamage_cover, mdeduct, mins_premium;
         int      qserial;
         /* long     dendorse; */
         long     dedr_begin, dedr_end;
         long     mcommission, magent, mdiscount, mprem;
         char     ipaid_base[3];
         long     qday, mexpense, mexp_disc;
         char     dtedr_begin[17],dtedr_end[17];     /* 1061108001_SC6_�t�X�s�еo�i���ߨt�λݨD���Ѭ����t�Υ\�� yyyy-mm-dd HH:MM */ 

         /***** Table:ca_pa_ply *****/
         /* char     ipolicy[21]; */
         /* napplicant & dbirth �Pcar9705152�@��,�G�L���ŧi */
         char     iinsurant[11], ninsurant[31], ainsurant[91], iins_scope[2], icareer[2];
         /*char     iendorse_old[21], fedr_status[2]; */
         char     relation_appl[2], nbeneficiary[31], relation_bene[2],tbenef[21],abenef_zip[CA_ZIP],abenef[91];
         long     mins_amt;
         long     daily_pay, mr_ins_prem;
         double   mr_pure_prem;
         char     provision[21];
         int      qnext_year;
         char     iinstall[11];
         /* long     mins_premium, mcommission, magent, mdiscount, dpolicy; */
         /* long     dendorse, dedr_begin, dedr_end; */
         /* double   mpure_prem, pcommission, pagent, pdiscount; */

         struct PLY_INS_COVER *IfirstPlyInsCover;

         /* GCAR�������[���ڷs�W���     */
         $int    irate;
         $double adjust_rate;
         $double mins_premium_n;
         $double mpure_prem_n;
         $long   mprem_n;
         
         /* 'car9610231��~�βĤT�H�f�B�~���[���� */
         $double safe_rate;
         $double manage_rate;
         $double educated_rate;

         /* �«O�O�����v */
         $double deviation_rate;

         /* �O�v�ۥѤ� */
         $double pextra_charge;
         $double pbusiness;

         $double ins_psex_age;     /* �I�ةʧO�~�֫Y�� */
         $double pshipping;        /* car9808043���[����C */

         $long   qprovision;

         $char   dtrans_b2b[31], idm_number[11], dcreate[31]; /* �O�檺dcreate */
         $char   iroute_prop[3], iroute_accept[21];
        
         $char   iins_kit[4];
         $long   mcover_limit;
         $char iassured_cntry[2], iapplicant_cntry[2];
         $char fcharge_type[11];
         $char fequipment1[2],fequipment2[2],fequipment3[2],fequipment4[2],fequipment5[2],fequipment6[2],fequipment9[2],nequipment9[101];
         $char nassured_cntry[51], napplicant_cntry[51];
         $char foccup[2], noccup[6];
         $char applicant_foccup[2], applicant_noccup[6];
         $char iowner[13], nowner[121], dbirth_owner[11];
         $char tmobile_appl[21], aemail_appl[51],iscan_no[26]; /* 1101018008_SC2 �q�lñ�ݱ��y�s������X�W��25�X */              
         

    EXEC SQL END   DECLARE SECTION;

    char   DBname[21];
    char   str[2];
    $int   tmp_qedr_serial, qedr_serial;
    $char  prep_stmt[8192];

    $char  v_sMsg[1512];
    long   rtncode;
    char   sColumn[21], sTable[21], sDbname[21];

    $long  dinstall;
    $char  isequence[31], ainstall_zip[7], ainstall[91]; /*1120927002_C02 �R�q�ΰӫ~�}�o*/    

    $WHENEVER SQLERROR GOTO errexit;

    printf ("{bk_401.0010}: policy[%s]\n", policy);

    printf("1:endorse[%s]\n", endorse);
    strcpy (DBname, get_full_dbname (DB));

    /*** �iTable�j�Gply_relation ***/
    prep_stmt[0]='\0';
    sprintf_s(prep_stmt, sizeof prep_stmt, "SELECT %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s FROM %s:%s WHERE %s",
                        "ipolicy,icard,",
                        "fcard_class,irelative_ply,ilast_card,ilast_ply,",
                        "inext_ply,itmp_policy,itreaty,iissue_ym,ipro_year,",
                        "ibrand,icar_type,ibig_comp,ibig_branch,ibig_office,ibig_sales,",
                        "iresource,ibroker,iofficer,ileader,icorps,",
                        "iarea,icashier,iexaminer,",
                        "ientry,fprint,fedr_class,ibranch,iquota,icomp_in,ibranch_in,",
                        "icomp_at,ibranch_at,fcomp_class,fcomp_class_last,fdiscount,ipay_way,",
                        "icar_flag,transno,",
                        "qply_period,mdmg_agent,mdmg_commi,mdmg_discount,mdmg_prem,mlia_agent,",
                        "mlia_commi,mlia_discount,mlia_prem,",
                        "dply_begin,dply_end,dexamine,dentry,dpolicy,dply_close,dapply,drenew_print,",
                        "dtransfer,dendorse,",
                        "mdmg_pure_prem,mlia_pure_prem,mready,mstable,mcompensation,madjcom_prem,mbusiness,",
                        "mbus_rule,mresearch,mcapital,minvest,maintain,",
                        "ibatch_no,seqno,qnext_year,iinstall,iofficer_prmt,iquota_prmt,ileader_prmt,irate_type,bzfrom,",
                        "iroute_comm,icomm_obj,qprovision,dtrans_b2b,dcreate,isecond_hand,icard_main, qdrunk_driving, isign,",
                        "feply, aemail_eply,dcreate_eply,iscan_no,dtply_begin,dtply_end,tmobile_eply,ireg_no,dnotifyornot,fsign_status,funder_chk,",
                        "feterms,iprog,ftrans_third,qviolate",
                        DBname,
                        "ply_relation",
                        "ipolicy = ?");
    printf("2:endorse[%s]\n", endorse);
    $PREPARE ply_q1 FROM   $prep_stmt;
    printf("prep_stmt[%s]\n",prep_stmt);
    $DECLARE ply_c1 CURSOR FOR ply_q1;
    $OPEN    ply_c1 USING  $policy;
    $FETCH   ply_c1 INTO   $ipolicy,$icard,
                           $fcard_class,$irelative_ply,$ilast_card,$ilast_ply,
                           $inext_ply,$itmp_policy,$itreaty,$iissue_ym,$ipro_year,
                           $ibrand,$icar_type,$ibig_comp,$ibig_branch,$ibig_office,$ibig_sales,
                           $iresource,$ibroker,$iofficer,$ileader,$icorps,
                           $iarea,$icashier,$iexaminer,
                           $ientry,$fprint,$fedr_class,$ibranch,$iquota,$icomp_in,$ibranch_in,
                           $icomp_at,$ibranch_at,$fcomp_class,$fcomp_class_last,$fdiscount,$ipay_way,
                           $icar_flag,$transno,
                           $qply_period,$mdmg_agent,$mdmg_commi,$mdmg_discount,$mdmg_prem,$mlia_agent,
                           $mlia_commi,$mlia_discount,$mlia_prem,
                           $dply_begin,$dply_end,$dexamine,$dentry,$dpolicy,$dply_close,$dapply,$drenew_print,
                           $dtransfer,$dendorse,
                           $mdmg_pure_prem,$mlia_pure_prem,$mready,$mstable,$mcompensation,$madjcom_prem,$mbusiness,
                           $mbus_rule,$mresearch,$mcapital,$minvest,$maintain,
                           $ibatch_no,$seqno,$qnext_year,$iinstall,$iofficer_prmt,$iquota_prmt,$ileader_prmt,
                           $irate_type,$bzfrom,$iroute_comm,$icomm_obj,$qprovision,$dtrans_b2b,$dcreate,$isecond_hand,$icard_main, $qdrunk_driving,$isign,
                           $feply, $aemail_eply,$dcreate_eply,$iscan_no,$dtply_begin,$dtply_end,$tmobile_eply,$ireg_no,$dnotifyornot,$fsign_status,$funder_chk,
                           $feterms,$iprog,$ftrans_third,$qviolate;
    $CLOSE ply_c1;
    $FREE  ply_c1;

    printf("3:endorse[%s]\n", endorse);
    /*** get qedr_serial ***/
    sprintf_s(prep_stmt, sizeof prep_stmt, "SELECT %s FROM %s:%s WHERE %s %s", 
                        "ipolicy , qedr_serial ", 
                        DBname,
                        "ply_relation_bak ",
                        "ipolicy = ? ",
                        "ORDER BY qedr_serial DESC");
    $PREPARE ply_q7 FROM   $prep_stmt;
    $DECLARE ply_c7 CURSOR FOR ply_q7;
       $OPEN ply_c7 USING  $policy;
      $FETCH ply_c7 INTO   $ipolicy, $tmp_qedr_serial;
    if (SQLCODE == SQLNOTFOUND)
    {
         qedr_serial = 1;
    }
    else
    {
         strcpy (str, itoa(tmp_qedr_serial));
         str[1] = '\0';
         if (str[0] == '\0' || str[0] == ' ')
              tmp_qedr_serial = 0;
         qedr_serial = tmp_qedr_serial + 1;
    }

    /*******************************/
    sprintf_s(prep_stmt, sizeof prep_stmt, "INSERT INTO %s:%s (%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s) VALUES (%s %s %s %s)",
                        DBname,
                        "ply_relation_bak ",
                        "iendorse,ipolicy,icard,",
                        "fcard_class,irelative_ply,ilast_card,ilast_ply,",
                        "inext_ply,itmp_policy,itreaty,iissue_ym,ipro_year,",
                        "ibrand,icar_type,ibig_comp,ibig_branch,ibig_office,ibig_sales,",
                        "iresource,ibroker,iofficer,ileader,icorps,",
                        "iarea,icashier,iexaminer,",
                        "ientry,fprint,fedr_class,ibranch,iquota,icomp_in,ibranch_in,",
                        "icomp_at,ibranch_at,fcomp_class,fcomp_class_last,fdiscount,ipay_way,",
                        "icar_flag,transno,",
                        "qply_period,mdmg_agent,mdmg_commi,mdmg_discount,mdmg_prem,mlia_agent,",
                        "mlia_commi,mlia_discount,mlia_prem,",
                        "dply_begin,dply_end,dexamine,dentry,dpolicy,dply_close,dapply,drenew_print,",
                        "dtransfer,dendorse,",
                        "mdmg_pure_prem,mlia_pure_prem,mready,mstable,mcompensation,madjcom_prem,mbusiness,",
                        "mbus_rule,mresearch,mcapital,minvest,maintain,",
                        "ibatch_no,seqno,qedr_serial,qnext_year,iinstall,",
                        "iofficer_prmt,iquota_prmt,ileader_prmt,irate_type,bzfrom,iroute_comm,icomm_obj,qprovision,dtrans_b2b,",
                        "dcreate,isecond_hand,icard_main, qdrunk_driving,isign,feply, aemail_eply,dcreate_eply,iscan_no,",
                        "dtply_begin,dtply_end,tmobile_eply,ireg_no,dnotifyornot,fsign_status,funder_chk,feterms,iprog,ftrans_third,qviolate ",
                        "?,?,?,  ?,?,?,?,  ?,?,?,?,?,  ?,?,?,?,?,?,  ?,?,?,?,?,",
                        "?,?,?,  ?,?,?,?,?,?,?,  ?,?,?,?,?,?,  ?,?,  ?,?,?,?,?,?,",
                        "?,?,?,  ?,?,?,?,?,?,?,?,  ?,?,  ?,?,?,?,?,?,?,",
                        "?,?,?,?,?,  ?,?,?,?,?,  ?,?,?,?,?,?,?,?, ?,?,?,?,?, ?, ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?");
printf("prep_stmt[%s]\n",prep_stmt);
    printf("4:endorse[%s]\n", endorse);
                        
    $PREPARE ply_q2 FROM $prep_stmt;
    $EXECUTE ply_q2
       USING $endorse, $ipolicy,$icard,
             $fcard_class,$irelative_ply,$ilast_card,$ilast_ply,
             $inext_ply,$itmp_policy,$itreaty,$iissue_ym,$ipro_year,
             $ibrand,$icar_type,$ibig_comp,$ibig_branch,$ibig_office,$ibig_sales,
             $iresource,$ibroker,$iofficer,$ileader,$icorps,
             $iarea,$icashier,$iexaminer,
             $ientry,$fprint,$fedr_class,$ibranch,$iquota,$icomp_in,$ibranch_in,
             $icomp_at,$ibranch_at,$fcomp_class,$fcomp_class_last,$fdiscount,$ipay_way,
             $icar_flag,$transno,
             $qply_period,$mdmg_agent,$mdmg_commi,$mdmg_discount,$mdmg_prem,$mlia_agent,
             $mlia_commi,$mlia_discount,$mlia_prem,
             $dply_begin,$dply_end,$dexamine,$dentry,$dpolicy,$dply_close,$dapply,$drenew_print,
             $dtransfer,$dendorse,
             $mdmg_pure_prem,$mlia_pure_prem,$mready,$mstable,$mcompensation,$madjcom_prem,$mbusiness,
             $mbus_rule,$mresearch,$mcapital,$minvest,$maintain,
             $ibatch_no,$seqno,$qedr_serial,$qnext_year,$iinstall,
             $iofficer_prmt,$iquota_prmt,$ileader_prmt,
             $irate_type,$bzfrom,$iroute_comm,$icomm_obj,$qprovision,$dtrans_b2b,$dcreate,$isecond_hand,$icard_main, $qdrunk_driving, $isign,
             $feply, $aemail_eply,$dcreate_eply,$iscan_no,$dtply_begin,$dtply_end,$tmobile_eply,$ireg_no,$dnotifyornot,
             $fsign_status,$funder_chk,$feterms,$iprog,$ftrans_third,$qviolate;


    /***** Table:policy ==> Table:policy_bak *****/
    sprintf_s(prep_stmt, sizeof prep_stmt, "SELECT %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s FROM %s:%s WHERE %s",
                        "ipolicy,icard,",
                        "ixxcard, fassured, iassured, iassured_ext, nassured, ilicense,",
                        "ibirth, fsex, fmarriage, nuser, ibenef, nbenef, aassured,",
                        "aassured_zip, itel, iemail, apayment, apayment_zip, iply_area,",
                        "nbrand_abbr, ncar_abbr, fcar_note, iengine, ibody, itag, nequipment,",
                        "flimit, iabn_type, fpass, ipass, ffac, fcut, fcal_way, idmg_rate,",
                        "ibrg_rate, fpt, lia_class, fhuman, fcomp_24,",
                        "qcylinder, pdmg_align, pbrg_align, plia_align,",
                        "dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd,",
                        "dpass, dfac,",
                        "mcar_price, pdmg_factor, pbrg_factor, qpt, psex_age, psex_age_damage, plia_acc, pdmg_acc,",
                        "iext_policy, qpro_month, mkilo_ply, mkilo_edr, irisk, irelative_ext,",
                        "napplicant, dbirth, dissue, iextra_charge, gextra_charge, pextra_charge,",
                        "iquery_num_damage, iquery_num, mequipment, ",
                        "survey_num, bound_num, abnormal_num, iapplicant, iroute, qlia_acc_sum, qdmg_acc_sum, itel_night, mobil_phone, ",
                        "fapplicant,fsex_appl,dbirth_appl,itel_appl,ndeputy_appl,nrelation_appl,ndeputy_assured,idm_number, iroute_prop, iroute_accept, iins_kit, mcover_limit ,iassured_cntry,iapplicant_cntry,fcharge_type,", 
                        "fequipment1,fequipment2,fequipment3,fequipment4,fequipment5,fequipment6,fequipment9,nequipment9, ",
                        "nassured_cntry, napplicant_cntry, foccup, noccup, applicant_foccup, applicant_noccup, iowner, nowner, dbirth_owner, ",
                        "tmobile_appl, aemail_appl, dinstall, isequence, ainstall_zip, ainstall ",
                        DBname,
                        "policy",
                        "ipolicy = ?");

    printf("5:endorse[%s]\n", endorse);
    $PREPARE ply_q3 FROM   $prep_stmt;
    printf("prep_stmt[%s]\n",prep_stmt);
    $DECLARE ply_c3 CURSOR FOR ply_q3;
    $OPEN    ply_c3 USING  $policy;
    $FETCH   ply_c3 INTO   $ipolicy,$icard,
                           $ixxcard, $fassured, $iassured, $iassured_ext, $nassured, $ilicense,
                           $ibirth, $fsex, $fmarriage, $nuser, $ibenef, $nbenef, $aassured,
                           $aassured_zip, $itel, $iemail, $apayment, $apayment_zip, $iply_area,
                           $nbrand_abbr, $ncar_abbr, $fcar_note, $iengine, $ibody, $itag, $nequipment,
                           $flimit, $iabn_type, $fpass, $ipass, $ffac, $fcut, $fcal_way, $idmg_rate,
                           $ibrg_rate, $fpt, $lia_class, $fhuman, $fcomp_24,
                           $qcylinder, $pdmg_align, $pbrg_align, $plia_align,
                           $dmg_acc_1st, $dmg_acc_2nd, $dmg_acc_3rd,
                           $dpass, $dfac,
                           $mcar_price, $pdmg_factor, $pbrg_factor, $qpt, $psex_age, $psex_age_damage, $plia_acc, $pdmg_acc,
                           $iext_policy, $qpro_month, $mkilo_ply, $mkilo_edr, $irisk, $irelative_ext,
                           $napplicant, $dbirth, $dissue,$iextra_charge, $gextra_charge, $pextra_charge,                           
                           $iquery_num_damage, $iquery_num, $mequipment,
                           $survey_num, $bound_num, $abnormal_num, $iapplicant, $iroute, $qlia_acc_sum, $qdmg_acc_sum, 
                           $itel_night, $mobil_phone, $fapplicant,$fsex_appl,$dbirth_appl,$itel_appl,$ndeputy_appl,
                           $nrelation_appl,$ndeputy_assured,$idm_number,$iroute_prop, $iroute_accept, $iins_kit, $mcover_limit,
                           $iassured_cntry, $iapplicant_cntry, $fcharge_type, $fequipment1,$fequipment2,$fequipment3,$fequipment4,
                           $fequipment5,$fequipment6,$fequipment9,$nequipment9,$nassured_cntry, $napplicant_cntry,
                           $foccup, $noccup, $applicant_foccup, $applicant_noccup, $iowner, $nowner, $dbirth_owner,
                           $tmobile_appl, $aemail_appl,$dinstall, $isequence, $ainstall_zip, $ainstall;
    $CLOSE ply_c3;
    $FREE  ply_c3;

    /* ����ȪA����ɮפ��q��[�]],��ʹq��,email�b�� */
    /* 1060607007_C1 ���t�Ψ����a�ȪA�� */
    /* 
    EXEC SQL SELECT tphone_con , imovephone , iemail
               INTO :itel_night_cus , :mobil_phone_cus, :iemail_cus
               FROM cu_customer
              WHERE ifpce_id     = $iassured
                AND ifpce_id_ext = $iassured_ext;

    if (NOT_FOUND)
    {
        itel_night_cus[0] = '\0';
        mobil_phone_cus[0] = '\0';
        iemail_cus[0] = '\0';
    }
   
    if( strlen( trim(itel_night)) == 0)
        strcpy( itel_night, itel_night_cus);

    if( strlen( trim(mobil_phone)) == 0)
        strcpy( mobil_phone, mobil_phone_cus);

    if( strlen( trim(iemail)) == 0)
        strcpy( iemail, iemail_cus);
    */

    if (risnull(SQLCHAR,itel_night) == 1) strcpy( itel_night, " "); 
    if (risnull(SQLCHAR,mobil_phone) == 1) strcpy( mobil_phone, " "); 

    printf("6:endorse[%s]\n", endorse);
    sprintf_s(prep_stmt, sizeof prep_stmt, "INSERT INTO %s:%s (%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s) VALUES(%s %s %s) ",
                        DBname,
                        "policy_bak ",
                        "iendorse, ipolicy, icard,",
                        "ixxcard, fassured, iassured, iassured_ext, nassured, ilicense,",
                        "ibirth, fsex, fmarriage, nuser, ibenef, nbenef, aassured,",
                        "aassured_zip, itel, itel_night, iemail, mobil_phone, apayment, apayment_zip, iply_area,",
                        "nbrand_abbr, ncar_abbr, fcar_note, iengine, ibody, itag, nequipment,",
                        "flimit, iabn_type, fpass, ipass, ffac, fcut, fcal_way, idmg_rate,",
                        "ibrg_rate, fpt, lia_class, fhuman, fcomp_24,",
                        "qcylinder, pdmg_align, pbrg_align, plia_align,",
                        "dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd,",
                        "dpass, dfac,",
                        "mcar_price, pdmg_factor, pbrg_factor, qpt, psex_age, psex_age_damage, plia_acc, pdmg_acc,",
                        "iext_policy, qpro_month, mkilo_ply, mkilo_edr, irisk, irelative_ext, ",
                        "napplicant, dbirth, dissue, ",
                        "iextra_charge, gextra_charge, pextra_charge, ",
                        "iquery_num_damage, iquery_num, mequipment, ",
                        "survey_num, bound_num, abnormal_num, iapplicant, iroute, qlia_acc_sum, qdmg_acc_sum, ",
                        "fapplicant,fsex_appl,dbirth_appl,itel_appl,ndeputy_appl,nrelation_appl,ndeputy_assured,idm_number,iroute_prop, iroute_accept,iins_kit,mcover_limit,iassured_cntry,iapplicant_cntry,fcharge_type, ",
                        "fequipment1,fequipment2,fequipment3,fequipment4,fequipment5,fequipment6,fequipment9,nequipment9, ",
                        "nassured_cntry, napplicant_cntry, foccup, noccup, applicant_foccup, applicant_noccup, iowner, nowner, dbirth_owner, ",
                        "tmobile_appl, aemail_appl,dinstall, isequence, ainstall_zip, ainstall ",
                        "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,",
                        "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,",
                        "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?");
    $PREPARE ply_q4 FROM $prep_stmt;
    printf("prep_stmt[%s]\n",prep_stmt);
    $EXECUTE ply_q4
       USING $endorse, $ipolicy, $icard,
             $ixxcard, $fassured, $iassured, $iassured_ext, $nassured, $ilicense,
             $ibirth, $fsex, $fmarriage, $nuser, $ibenef, $nbenef, $aassured,
             $aassured_zip, $itel, $itel_night, $iemail, $mobil_phone, $apayment, $apayment_zip, $iply_area,
             $nbrand_abbr, $ncar_abbr, $fcar_note, $iengine, $ibody, $itag, $nequipment,
             $flimit, $iabn_type, $fpass, $ipass, $ffac, $fcut, $fcal_way, $idmg_rate,
             $ibrg_rate, $fpt, $lia_class, $fhuman, $fcomp_24,
             $qcylinder, $pdmg_align, $pbrg_align, $plia_align,
             $dmg_acc_1st, $dmg_acc_2nd, $dmg_acc_3rd,
             $dpass, $dfac,
             $mcar_price, $pdmg_factor, $pbrg_factor, $qpt, $psex_age, $psex_age_damage, $plia_acc, $pdmg_acc,
             $iext_policy, $qpro_month, $mkilo_ply, $mkilo_edr, $irisk, $irelative_ext,
             $napplicant, $dbirth, $dissue,
             $iextra_charge, $gextra_charge, $pextra_charge,
             $iquery_num_damage, $iquery_num, $mequipment,
             $survey_num, $bound_num, $abnormal_num, $iapplicant, $iroute, $qlia_acc_sum, $qdmg_acc_sum,
             $fapplicant,$fsex_appl,$dbirth_appl,$itel_appl,$ndeputy_appl,$nrelation_appl,$ndeputy_assured,$idm_number,
             $iroute_prop, $iroute_accept, $iins_kit, $mcover_limit, $iassured_cntry, $iapplicant_cntry,$fcharge_type,
             $fequipment1,$fequipment2,$fequipment3,$fequipment4,$fequipment5,$fequipment6,$fequipment9,$nequipment9,
             $nassured_cntry, $napplicant_cntry, $foccup, $noccup, $applicant_foccup, $applicant_noccup,
             $iowner, $nowner, $dbirth_owner, $tmobile_appl, $aemail_appl,$dinstall, $isequence, $ainstall_zip, $ainstall;

    prep_stmt[0]='\0';

    printf("7:endorse[%s]\n", endorse);
    sprintf_s(prep_stmt, sizeof prep_stmt, "SELECT %s %s %s %s %s %s %s %s %s %s %s %s FROM %s:%s WHERE %s",
                        "ipolicy,",
                        "iins_type, fedr_status, iendorse, drate_ym, iproduct,",
                        "mpure_prem, pcommission, pagent, pdiscount,",
                        "minjured_cover, mdeath_cover, mdamage_cover, mdeduct, mins_premium,",
                        "qserial,",
                        "dendorse, dedr_begin, dedr_end,",
                        "mcommission, magent, mdiscount, mprem, ipaid_base,",
                        "qday, mexpense, mexp_disc, provision,",
                        "irate, adjust_rate, mins_premium_n, mpure_prem_n, mprem_n,", 
                        "safe_rate, manage_rate, educated_rate, deviation_rate, pextra_charge, ",
                        "pbusiness, psex_age, pshipping,mdrunk_prem, mdrunk_pure_prem, pcar_price,",
                        "dtedr_begin,dtedr_end,mviolate_prem, mviolate_pure_prem ",
                         DBname,
                        "ply_ins_type",
                        "ipolicy=?");

    $PREPARE ply_q5 FROM   $prep_stmt;
    printf("prep_stmt[%s]\n",prep_stmt);
    $DECLARE ply_c5 CURSOR FOR ply_q5;
    $OPEN    ply_c5 USING  $policy;

    printf("8:endorse[%s]\n", endorse);
    prep_stmt[0]='\0';
    sprintf_s(prep_stmt, sizeof prep_stmt, "INSERT INTO %s:%s (%s %s %s %s %s %s %s %s %s %s %s %s) VALUES (%s %s)",
                        DBname,
                        "ply_ins_type_bak ",
                        "iendorse, ipolicy,",
                        "iins_type, fedr_status, iendorse_old, drate_ym, iproduct,",
                        "mpure_prem, pcommission, pagent, pdiscount,",
                        "minjured_cover, mdeath_cover, mdamage_cover, mdeduct, mins_premium,",
                        "qserial,",
                        "dendorse, dedr_begin, dedr_end,",
                        "mcommission, magent, mdiscount, mprem, ipaid_base,",
                        "qday, mexpense, mexp_disc, provision,",
                        "irate, adjust_rate, mins_premium_n, mpure_prem_n, mprem_n,",
                        "safe_rate, manage_rate, educated_rate, deviation_rate, pextra_charge,",
                        "pbusiness, psex_age, pshipping,mdrunk_prem, mdrunk_pure_prem, pcar_price,",
                        "dtedr_begin,dtedr_end,mviolate_prem, mviolate_pure_prem",
                        "?,?,  ?,?,?,?,?,  ?,?,?,?,  ?,?,?,?,?,  ?,  ?,?,?,  ?,?,?,?,?,",
                        "?,?,?,?, ?,?,?,?,?, ?,?,?,?,?,  ?,?,?,?,?, ?,?,?, ?,?");

    $PREPARE ply_q6 FROM $prep_stmt;
    for (;;)
    {
         $FETCH ply_c5 INTO $ipolicy,
                            $iins_type, $fedr_status, $iendorse_old, $drate_ym, $iproduct,
                            $mpure_prem, $pcommission, $pagent, $pdiscount,
                            $minjured_cover, $mdeath_cover, $mdamage_cover, $mdeduct,  $mins_premium,
                            $qserial,
                            $dendorse, $dedr_begin, $dedr_end,
                            $mcommission, $magent, $mdiscount, $mprem, $ipaid_base,
                            $qday, $mexpense, $mexp_disc, $provision,
                            $irate, $adjust_rate, $mins_premium_n, $mpure_prem_n, $mprem_n,
                            $safe_rate, $manage_rate, $educated_rate, $deviation_rate, $pextra_charge,
                            $pbusiness, $psex_age, $pshipping,$mdrunk_prem, $mdrunk_pure_prem, $pcar_price,
                            $dtedr_begin,$dtedr_end,$mviolate_prem, $mviolate_pure_prem;
         if (SQLCODE != 0) break;

         printf("9:endorse[%s], iins_type[%s]\n", endorse, iins_type);
         $EXECUTE ply_q6
            USING $endorse, $ipolicy,
                  $iins_type, $fedr_status, $iendorse_old, $drate_ym, $iproduct,
                  $mpure_prem, $pcommission, $pagent, $pdiscount,
                  $minjured_cover, $mdeath_cover, $mdamage_cover, $mdeduct,  $mins_premium,
                  $qserial,
                  $dendorse, $dedr_begin, $dedr_end,
                  $mcommission, $magent, $mdiscount, $mprem, $ipaid_base,
                  $qday, $mexpense, $mexp_disc, $provision,
                  $irate, $adjust_rate, $mins_premium_n, $mpure_prem_n, $mprem_n,
                  $safe_rate, $manage_rate, $educated_rate, $deviation_rate, $pextra_charge, 
                  $pbusiness, $psex_age, $pshipping,$mdrunk_prem, $mdrunk_pure_prem, $pcar_price,
                  $dtedr_begin,$dtedr_end,$mviolate_prem, $mviolate_pure_prem;
        printf("SQLCODE[%d]\n", SQLCODE);
    }
    $CLOSE ply_c5;
    $FREE  ply_c5;

    strcpy( sDbname, DBname);
    strcpy( sColumn, "ipolicy");
    strcpy( sTable,  "ply_ins_cover");

    IfirstPlyInsCover = get_ply_ins_cover( sDbname, sTable, sColumn, ipolicy, &rtncode, v_sMsg);

    if( rtncode != M_CM_OK)
        return rtncode;

    strcpy( sColumn, "iendorse");
    strcpy( sTable,  "ply_ins_cover_bak");

    rtncode = insert_ply_ins_cover( sDbname, sTable, sColumn, endorse, IfirstPlyInsCover, "", v_sMsg);
    if( rtncode != M_CM_OK)
        return rtncode;
 
    strcpy( sDbname, DBname);
    strcpy( sColumn, "ipolicy");
    strcpy( sTable,  "ply_ins_assured");

    IfirstPlyInsAssured = get_ply_ins_assured( sDbname, sTable, sColumn, ipolicy, &rtncode, v_sMsg);

    if( rtncode != M_CM_OK)
        return rtncode;

    strcpy( sColumn, "iendorse");
    strcpy( sTable,  "ply_ins_assured_bak");

    rtncode = insert_ply_ins_assured( sDbname, sTable, sColumn, endorse, IfirstPlyInsAssured, "", v_sMsg);
    if( rtncode != M_CM_OK)
        return rtncode;

    /* car9903041 ���s�t�λP���O�B�ɨ�����s�� */
    strcpy( sColumn, "ipolicy");
    strcpy( sTable,  "ca_ply_bound");

    rtncode = get_ca_ply_bound( sDbname, sTable, sColumn, ipolicy, ibound, v_sMsg);

    if( rtncode != M_CM_OK)
        return rtncode;

    strcpy( sColumn, "iendorse");
    strcpy( sTable,  "ca_ply_bound_bak");

    rtncode = insert_ca_ply_bound( sDbname, sTable, sColumn, endorse, ibound, v_sMsg);
    if( rtncode != M_CM_OK)
        return rtncode;

    /*** �ˮ`�I���Ӹ�Ƴƥ�:ca_pa_ply_bak ***/
    sprintf_s(prep_stmt, sizeof prep_stmt, "SELECT %s %s %s %s %s %s %s %s %s %s %s FROM %s:%s WHERE %s",
                        "ipolicy , iins_type, iinsurant , ninsurant , dbirth , ainsurant , ",
                        "iins_scope , icareer , ",
                        "mins_amt , mins_premium , mpure_prem ,",
                        "pcommission , mcommission , ",
                        "pagent , magent , ",
                        "pdiscount , mdiscount ,",
                        "dpolicy , ",
                        "iendorse , dendorse , dedr_begin , dedr_end , fedr_status ,",
                        "napplicant , relation_appl , ",
                        "nbeneficiary , relation_bene, ",
                        "daily_pay, mr_ins_prem, mr_pure_prem,tbenef,abenef_zip,abenef ",
                         DBname,
                        "ca_pa_ply",
                        "ipolicy=?");
    $PREPARE ply_q8 FROM $prep_stmt;
    printf("prep_stmt[%s]\n",prep_stmt);
    $DECLARE ply_c8 CURSOR FOR ply_q8;
    $OPEN    ply_c8 USING $policy;

    sprintf_s(prep_stmt, sizeof prep_stmt, "INSERT INTO %s:%s (%s %s %s %s %s %s %s %s %s %s %s) VALUES (%s)",
                        DBname,
                        "ca_pa_ply_bak ",
                        "iendorse , iins_type, ipolicy , iinsurant , ninsurant , dbirth , ainsurant , ",
                        "iins_scope , icareer , ",
                        "mins_amt , mins_premium , mpure_prem , ",
                        "pcommission , mcommission , ",
                        "pagent , magent , ",
                        "pdiscount , mdiscount ,",
                        "dpolicy , ",
                        "iendorse_old , dendorse , dedr_begin , dedr_end , fedr_status ,",
                        "napplicant , relation_appl , ",
                        "nbeneficiary , relation_bene, ",
                        "daily_pay, mr_ins_prem, mr_pure_prem,tbenef,abenef_zip,abenef",
                        "?,?,?,?,?,?,  ?,?,  ?,?,?,  ?,?,  ?,?,  ?,?,  ?,  ?,?,?,?,?,  ?,?,  ?,?, ?,?,?,?,?,?,?");
    $PREPARE ply_q9 FROM $prep_stmt;
    printf("prep_stmt[%s]\n",prep_stmt);
    for (;;)
    {
         $FETCH ply_c8
           INTO $ipolicy, $iins_type, $iinsurant, $ninsurant, $dbirth, $ainsurant,
                $iins_scope, $icareer,
                $mins_amt, $mins_premium, $mpure_prem,
                $pcommission, $mcommission,
                $pagent, $magent,
                $pdiscount, $mdiscount,
                $dpolicy,
                $iendorse_old, $dendorse, $dedr_begin, $dedr_end, $fedr_status,
                $napplicant, $relation_appl,
                $nbeneficiary, $relation_bene,
                $daily_pay, $mr_ins_prem, $mr_pure_prem, $tbenef, $abenef_zip, $abenef;

         printf("ca_pa_ply_bak:SQLCODE[%d]\n" , SQLCODE); 

         if (SQLCODE != 0) break;

         strcpy(ipolicy,trim(ipolicy));
         printf("iinsurant[%s],iins_scope[%s],icareer[%s]\n",iinsurant,iins_scope,icareer);
         printf("ipolicy[%s],iendorse[%s],iins_type[%s]\n",ipolicy,endorse,iins_type);

         $EXECUTE ply_q9
            USING $endorse, $iins_type, $ipolicy, $iinsurant, $ninsurant, $dbirth, $ainsurant,
                  $iins_scope, $icareer,
                  $mins_amt, $mins_premium, $mpure_prem ,
                  $pcommission, $mcommission,
                  $pagent, $magent,
                  $pdiscount, $mdiscount,
                  $dpolicy,
                  $iendorse_old, $dendorse, $dedr_begin, $dedr_end, $fedr_status,
                  $napplicant, $relation_appl,
                  $nbeneficiary, $relation_bene,
                  $daily_pay, $mr_ins_prem, $mr_pure_prem, $tbenef, $abenef_zip, $abenef;

    }
    $CLOSE ply_c8;
    $FREE  ply_c8;

    return M_CM_OK;

errexit:
    printf ("bk_401: SQLCODE=%ld sqlerrm=%s\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
} /* end of bk_401 */

update_reject_policy ( ipolicy, iedr_examiner)
$char *ipolicy, *iedr_examiner;
{
$int iCount;
$char imgr[2],stmt[1024];
$char sFullName[21];

     $WHENEVER SQLERROR GOTO errexit;
     strcpy(sFullName, get_car_full_db(ipolicy));
     
     printf(" ------ update_reject_policy() ------\n");
     printf("ipolicy[%s] iedr_examiner[%s]\n", ipolicy,iedr_examiner);

     strcpy(imgr," ");
     sprintf_s(stmt, sizeof stmt,"select imgr from officer a, %s:ply_relation b where a.iofficer = b.iofficer and b.ipolicy = '%s'",
             sFullName,ipolicy );
     $PREPARE prepRejct FROM  $stmt;
     $EXECUTE prepRejct Into $imgr;
 
     printf("imgr[%s]\n", imgr);     
     if( imgr[0] == '1')
     {
         puts("�O�N��");
         /* ������O1,2,4,6,8,9,�ư���z�覡���~�����,�O�d��z�覡�ܧ�᪺��� */
         
         iCount = 0;
         sprintf_s(stmt, sizeof stmt,
                "SELECT count(*) FROM %s:edr_relation a "
                " WHERE a.ipolicy = '%s' AND a.iedr_return in ('1','0') "
                "   AND a.iendorse not like '%%CVP%%' "
                "   AND ( "
                "          (a.fedr_class in ('1','2','4','6','8','9') AND a.iendorse NOT IN (SELECT b.irelative_edr FROM %s:edr_relation b WHERE a.ipolicy = b.ipolicy)) "
                "         OR "
                "           (a.fedr_class = 'B' "
                "               AND a.irelative_edr<>'' "
                "               AND a.iendorse NOT IN (SELECT min(c.iendorse) FROM %s:edr_relation c  "
                "                                       WHERE a.ipolicy = c.ipolicy "
                "                                         AND c.irelative_edr<> '' "
                "                                         AND a.irelative_edr = c.irelative_edr) "
                "             ) "
                "       )", 
                  sFullName,ipolicy,sFullName,sFullName );
         printf("stmt[%s]\n", stmt); 
         $PREPARE prepRejct2 FROM $stmt;
         $EXECUTE prepRejct2 Into $iCount;
     
         printf("iCount[%d]\n", iCount);
         if(iCount!=0) /* �O�N�󦳫Ȥ�˿���A����J��z�覡(iedr_return='0')�����Ȥ�˿�,����O�J�p */
         {
             puts("�O�N�󦳫Ȥ�˿�L����A����O�J�p");
             /* car137(�L��J�p�����) (�J�p), �Y������������ */
             $UPDATE reject_policy
                 SET dexpire = today,
                     iupdate = $iedr_examiner,
                     dupdate = current year to second
               WHERE ipolicy = $ipolicy
                     AND fins_grp = 'A';
         }
         else /* �O�N��L�Ȥ�˿���A�n��O�J�p */
         {
             puts("�O�N��L�Ȥ�˿���A�n��O�J�p");
             /* car137(�L��J�p�����) (�J�p),�Y������������ */
             $UPDATE reject_policy
                 SET dexpire = '',
                     iupdate = $iedr_examiner,
                     dupdate = current year to second
               WHERE ipolicy = $ipolicy
                     AND fins_grp = 'A';
             if (sqlca.sqlerrd[2] == 0) /* car137(�L��J�p�L���) �s�Wcar137 */
             {
                 $INSERT INTO reject_policy (ipolicy, fins_grp, icreate, dcreate, iupdate, remark)
                                     VALUES ($ipolicy, 'A', $iedr_examiner, current year to second, ' ', ' ');
             }
         }
     }
     else /* �@���L���椣��O�J�p �Y������������ */
     {
         puts("�@���L���椣��O�J�p �Y������������");
         $UPDATE reject_policy
             SET dexpire = today,
                 iupdate = $iedr_examiner,
                 dupdate = current year to second
              WHERE ipolicy = $ipolicy
             AND fins_grp = 'A';
     }
    return M_CM_OK;

errexit:
    printf ("update_reject_policy: SQLCODE=%ld sqlerrm=%s\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}
