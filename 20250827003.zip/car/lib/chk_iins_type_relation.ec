/* �ˬd�ӫO���[�I�A�ݩӫO�D�I 
   �ˬd�I�ئۭt�B 
   Name       : chk_iins_type_relation
   Input      : v_sDbname               ��Ʈw�W��
                v_sTable                Table Name
                v_sColumn               Column Name
                v_sData                 �պ⸹�A�O�渹�A���`���A�Χ�渹�X
                v_iabn_type             ���`���A 
                v_nequipment            ���O���A

   Output     : return code 		M_CM_OK ���\
                v_sMsg      		�T��
*/

#include "api_xsrv.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"
#define TRUE                  1
#define FALSE                 0

void end_chk_iins_type_relation( );

$struct PLY_INS_TYPE {
 char   iins_type[7];
 long   mdamage_cover;
 long   mdeduct;
 long   minjured_cover;
 long   mins_premium;
 struct PLY_INS_TYPE *next;
} ;

struct   PLY_INS_TYPE *IcurrPlyInsType, *IfirstPlyInsType, *IlastPlyInsType;

long chk_iins_type_relation( char *v_sDbname,
                             char *v_sTable,
                             char *v_sColumn,
                             char *v_sData,
                             char *v_iabn_type,
                             char *v_nequipment,
                             char *v_iroute,
                             char   *v_sMsg)
{
  $long    mdamage_cover = 0, mdeduct = 0, minjured_cover = 0, mpremium = 0; 
  $char    iins_type[7], stmt[2048],s_iroute[21],tmp_sMsg[512];
  int      iins, cnt_iins=0;
  char     sdb[61];
  $int     t_count = 0;

  $WHENEVER SQLERROR GOTO errexit;

  puts("");
  puts("******************************");
  puts("begin chk_iins_type_relation function");
  printf("     v_sDbname=[%s], v_sTable=[%s], v_sColumn[%s], v_sData[%s], v_iabn_type[%s], v_nequipment[%s] \n",
               v_sDbname, v_sTable, v_sColumn, v_sData, v_iabn_type, v_nequipment);
  strcpy(s_iroute,trim(v_iroute));
  strcpy( tmp_sMsg, " ");
  
  if( *v_sDbname == '')
      strcpy( sdb, v_sTable);
  else
      sprintf_s( sdb,sizeof sdb, "%s:%s", v_sDbname, v_sTable);

  IcurrPlyInsType=IfirstPlyInsType=IlastPlyInsType=NULL;    /* set init pointer to NULL */

  sprintf_s( stmt,sizeof stmt, "SELECT iins_type, minjured_cover, mdamage_cover, mdeduct, mins_premium "
                 "  FROM %s "
                 " WHERE %s = '%s' ", sdb, v_sColumn, v_sData);

  $PREPARE prepA FROM $stmt;
  $DECLARE cursA CURSOR FOR prepA;

  $OPEN cursA;
  for(;;)
  {
      $FETCH cursA  INTO $iins_type, $minjured_cover, $mdamage_cover, $mdeduct, $mpremium;

      if( SQLCODE == SQLNOTFOUND)
          break;

      IcurrPlyInsType=(struct PLY_INS_TYPE *)malloc(sizeof(struct PLY_INS_TYPE));
      if ( IfirstPlyInsType==NULL)
      {
           IfirstPlyInsType = IcurrPlyInsType;
      }
      else
      {
          IlastPlyInsType->next = IcurrPlyInsType;
      }
      IlastPlyInsType = IcurrPlyInsType;
      IcurrPlyInsType->next = NULL;

      strcpy( IcurrPlyInsType->iins_type, iins_type);
      IcurrPlyInsType->mdamage_cover = mdamage_cover;
      IcurrPlyInsType->mdeduct = mdeduct;
      IcurrPlyInsType->minjured_cover = minjured_cover;
      IcurrPlyInsType->mins_premium = mpremium;
      
      /* �Ψӭp�⦳���I�حӼ� */
      if (mdamage_cover > 0)
           cnt_iins += 1;
      
      if(0) free(IcurrPlyInsType);
  }
  $CLOSE cursA;
  $FREE cursA;

  IcurrPlyInsType = IfirstPlyInsType;

  while( IcurrPlyInsType)
  {
      iins = atoi ( IcurrPlyInsType->iins_type);
      switch( iins)
      {
          case 34: if( IcurrPlyInsType->mdamage_cover != 0 && chk_cover( 31) != M_CM_OK && chk_cover( 36) != M_CM_OK && chk_cover( 149) != M_CM_OK &&
                       chk_cover(231) != M_CM_OK && chk_cover(232) != M_CM_OK && chk_cover(249) != M_CM_OK && chk_cover(531) != M_CM_OK && chk_cover(532) != M_CM_OK) 
                       return M_CA_31;
                   if( IcurrPlyInsType->mdeduct != 0 ) 
                       return M_CA_deduct_34;
                   break;
          case 72: if( IcurrPlyInsType->mdamage_cover != 0 && chk_cover( 71) != M_CM_OK) 
                       return M_CA_71;
                   break;
          case 47: /* if( IcurrPlyInsType->mdamage_cover != 0 && chk_cover( 49) == M_CM_OK && 
                       *v_iabn_type != 'S' && *v_iabn_type != 'Y')
                       return M_CA_47_49;  47�I�ػP49�I�ءA�P�ɩӫO�����HS,Y��X��, car9711201����(౻T) */
                   break;
          case 56: /* if( IcurrPlyInsType->mdamage_cover != 0 && chk_cover( 50) == M_CM_OK )
                       return M_CA_50_56;  50�I�ػP56�I�ءA���i�P�ɩӫO, car9711201����(౻T) */
                   break;
          case 50: if( IcurrPlyInsType->mdeduct != 0 ) 
                       return M_CA_deduct_50;
printf("cnt_iin[%d],v_nequipment[%s]\n",cnt_iins,v_nequipment);                       
                   if (cnt_iins == 1)      /* ��W�ӫO50��11�I�خɡAReturn M_CA_ONLY1150��ca401lib.ec�P�_�Ǵ����λŤ�M�� */
                        return M_CA_ONLY1150;           
                   if (cnt_iins == 2 && (chk_cover(11) == M_CM_OK || chk_cover(211) == M_CM_OK)) /* ��W�ӫO50+11�I�خɡAReturn M_CA_ONLY1150��ca401lib.ec�P�_�Ǵ����λŤ�M�� */
                        return M_CA_ONLY1150;
                   break;
          case 20: 
                   if( IcurrPlyInsType->mdamage_cover != 0 && (chk_cover( 11) == M_CM_OK || chk_cover(211) == M_CM_OK))
                       return M_CA_20_11;

                   if( IcurrPlyInsType->mdeduct != 0 ) 
                       return M_CA_deduct_20;
                   break;
          case 22: /*if( IcurrPlyInsType->mdamage_cover != 0 && chk_cover( 20) != M_CM_OK ) 
                       return M_CA_20;
*/

                   if( IcurrPlyInsType->mdamage_cover != 0 && (chk_cover( 11) == M_CM_OK || chk_cover(211) == M_CM_OK))
                       return M_CA_22_11;

                   if( IcurrPlyInsType->mdeduct != 0 ) 
                       return M_CA_deduct_22;
                   break;
          /* case 28: 
                   if( IcurrPlyInsType->mdamage_cover != 0 && 
                      ( chk_cover( 12) == M_CM_OK
                      )
                   ) 
                       return M_CA_28_12;

                   if( IcurrPlyInsType->mdamage_cover != 0 && chk_cover( 11) != M_CM_OK &&
                       *v_iabn_type != 'S' && *v_iabn_type != 'Y')
                       return M_CA_28_11;

                   break; */
          case 57:
                   /*57�I�ػP59,60�I�ءA���i�P�ɩӫO */
          			 if( IcurrPlyInsType->mdamage_cover != 0 && 
          			   (chk_cover(59) == M_CM_OK || chk_cover(60) == M_CM_OK))
                       return M_CA_57_59_60; 
                   break;
          case 59:
                   /*59�I�ػP57,60�I�ءA���i�P�ɩӫO */
          			 if( IcurrPlyInsType->mdamage_cover != 0 && 
          			   (chk_cover(57) == M_CM_OK || chk_cover(60) == M_CM_OK))
                       return M_CA_57_59_60; 
                   break;         
          case 60:
                   /*60�I�ػP57,59�I�ءA���i�P�ɩӫO */
          			 if( IcurrPlyInsType->mdamage_cover != 0 && 
          			   (chk_cover(57) == M_CM_OK || chk_cover(59) == M_CM_OK))
                       return M_CA_57_59_60; 
                   break; 
          case 15:       
                   /*15�I�ػP66,67�I�ءA���i�P�ɩӫO */
          			 if( IcurrPlyInsType->mdamage_cover != 0 && 
          			   (chk_cover(66) == M_CM_OK || chk_cover(67) == M_CM_OK))
                       return M_CA_15_66_67;                    
                   break;
          case 66:       
                   /*66�I�ػP15,67�I�ءA���i�P�ɩӫO,�B�ӫO05,09�ɤ��i�ӫO66 */
          			 if( IcurrPlyInsType->mdamage_cover != 0 && 
          			   (chk_cover(15) == M_CM_OK || chk_cover(67) == M_CM_OK))
                       return M_CA_15_66_67;
                   /* 103.09.05  �I��15.16.66.67.106�i�H��W�ӫO,��������D�I�����       
                   if( IcurrPlyInsType->mdamage_cover != 0 &&
                     (chk_cover(5) == M_CM_OK || chk_cover(9) == M_CM_OK || chk_cover(85) == M_CM_OK))
                       return M_CA_01_66;
                   * �ӫO66�I�إ����ܤ֩ӫO01�I�� *
                   if( IcurrPlyInsType->mdamage_cover != 0 &&
                     (chk_cover(1) != M_CM_OK))
                       return M_CA_01_66;*/
                   break;
          case 67:       
                   /*67�I�ػP15,66�I�ءA���i�P�ɩӫO,�B�ӫO09�ɤ��i�ӫO67 */
          			 if( IcurrPlyInsType->mdamage_cover != 0 && 
          			   (chk_cover(15) == M_CM_OK || chk_cover(66) == M_CM_OK))
                       return M_CA_15_66_67; 
                   /* 103.09.05  �I��15.16.66.67.106�i�H��W�ӫO,��������D�I�����     
                   if( IcurrPlyInsType->mdamage_cover != 0 && 
                     (chk_cover(9) == M_CM_OK))
                       return M_CA_01_05_67;
                   * �ӫO67�I�إ����ܤ֩ӫO01,05���@�I�� *
                   if( IcurrPlyInsType->mdamage_cover != 0 &&
                     (chk_cover(1) != M_CM_OK && chk_cover(5) != M_CM_OK && chk_cover(85) != M_CM_OK))
                       return M_CA_01_05_67; */
                   break;
          case 31: 
          case 231:
                   if( IcurrPlyInsType->mdamage_cover != 0 && chk_cover( 36) == M_CM_OK )
                       return M_CA_31_36;  /* 31�I�ػP36�I�ءA���i�P�ɩӫO */
                   if( IcurrPlyInsType->mdamage_cover != 0 && chk_cover( 37) == M_CM_OK )
                       return M_CA_31_37;  /* 31�I�ػP37�I�ءA���i�P�ɩӫO */
                   break;
          case 32: 
          case 232:
                   if( IcurrPlyInsType->mdamage_cover != 0 && chk_cover( 37) == M_CM_OK )
                       return M_CA_32_37;  /* 32�I�ػP37�I�ءA���i�P�ɩӫO */
                   if( IcurrPlyInsType->mdamage_cover != 0 && chk_cover( 36) == M_CM_OK )
                       return M_CA_32_36;  /* 32�I�ػP36�I�ءA���i�P�ɩӫO */
                   break;
          case 85: if( IcurrPlyInsType->mdamage_cover != 0 && 
                     (chk_cover(1) == M_CM_OK || chk_cover(5) == M_CM_OK || chk_cover(8) == M_CM_OK ||
                      chk_cover(9) == M_CM_OK || chk_cover(201) == M_CM_OK || chk_cover(205) == M_CM_OK || chk_cover(209) == M_CM_OK))
                        return M_CA_01_05_EXIST;     /* 85�I�ػP01,05,08,09���i�P�ɩӫO */
                   if( (IcurrPlyInsType->mdamage_cover == 0 && IcurrPlyInsType->minjured_cover != 0) ||
                        (IcurrPlyInsType->mdamage_cover != 0 && IcurrPlyInsType->minjured_cover == 0))
                        return M_CA_85_MCOVERCHK;    /* 85�I�ثO�B�@�O�B�T���o�@�Ӭ��s�t�@�Ӧ��O�B */
                   if( IcurrPlyInsType->mdamage_cover != 0 &&
                     ( chk_cover(61) == M_CM_OK || chk_cover(62) == M_CM_OK || chk_cover(63) == M_CM_OK ||
                       chk_cover(64) == M_CM_OK || chk_cover(65) == M_CM_OK || chk_cover(68) == M_CM_OK ||
                       chk_cover(69) == M_CM_OK))
                        return M_CA_85_NONRENTAL;    /* 85�I�ؤ��o���[61.65.68.69.62.63.64�I�� */
                   if ( IcurrPlyInsType->mdamage_cover != 0 && IcurrPlyInsType->minjured_cover != 0)
                   {
                   	   if (IcurrPlyInsType->mdamage_cover <= IcurrPlyInsType->minjured_cover)
                            return M_CA_85_BEYONDCARPRICE; /* 85�I�ت��������l���o�j��@�먮�l */
                   }
                   /* car9812241�ӫO85�I�ثO�O�Y�C�󤣩����l(�O�B�@),�����H�ӫO */
                   /* ��b�X���ˮ֪�(chk_ply_rule.ec)���ˮ�  mark by sylvia 100.12.12 */
                   /* if (IcurrPlyInsType->mdamage_cover != 0 && (IcurrPlyInsType->minjured_cover > IcurrPlyInsType->mins_premium))
                        return M_CA_85_LOWPREMIUM; */
                   break;
                   
          case 86: if( IcurrPlyInsType->mdamage_cover != 0 && 
                     (chk_cover(1) == M_CM_OK || chk_cover(5) == M_CM_OK || chk_cover(8) == M_CM_OK ||
                      chk_cover(9) == M_CM_OK || chk_cover(85) == M_CM_OK || chk_cover(201) == M_CM_OK ||
                      chk_cover(205) == M_CM_OK || chk_cover(209) == M_CM_OK ))
                        return M_CA_01_05_EXIST;     /* 86�I�ؤ��i�P�����I�P�ɩӫO */
                   break;
          case 23: if ( IcurrPlyInsType->mdamage_cover != 0 &&
                      ( chk_cover(1) == M_CM_OK || chk_cover(5) == M_CM_OK || chk_cover(201) == M_CM_OK || chk_cover(205) == M_CM_OK))
                        return M_CA_NOT_0105;     /* 23�I�ؤ��i�P�����I�P�ɩӫO */
                   break;
          case 11: 
          case 211:
printf("cnt_iin[%d],v_nequipment[%s]\n",cnt_iins,v_nequipment);          
                  if (cnt_iins == 1 && IcurrPlyInsType->mdamage_cover != 0) /* ��W�ӫO50��11�I�خɡAReturn M_CA_ONLY1150��ca401lib.ec�P�_�Ǵ����λŤ�M�� */
                        return M_CA_ONLY1150;           
                  if (cnt_iins == 2 && chk_cover(50) == M_CM_OK && IcurrPlyInsType->mdamage_cover != 0) /* ��W�ӫO50+11�I�خɡAReturn M_CA_ONLY1150��ca401lib.ec�P�_�Ǵ����λŤ�M�� */
                        return M_CA_ONLY1150; 

				  /*1050118006_C1:PA80521360(�Τ@�F��)�i��O�ѵs�I(�L�ۭt�B)���[�ѵs���l�K����(17)
				  t_count = 0;
				  $SELECT count(*) Into $t_count FROM car_code
				    WHERE kind = 'EX' AND detail='1' AND detail2 = $s_iroute;
				  if (t_count==0)
				  {           
	                  if (IcurrPlyInsType->mdamage_cover != 0 && IcurrPlyInsType->mdeduct == 0 &&
	                      chk_cover(17) == M_CM_OK && *v_iabn_type != 'S' && *v_iabn_type != 'Y')
	                        return M_CA_MDEDUCT11_17;     
	              }    1070731008-SC1-�ѵs�I�K�ۭt�B���ˮ� */       
                   break;      
          case 77: case 78: case 87:
                  if( (IcurrPlyInsType->mdamage_cover != 0) && 
                      (chk_cover(24) == M_CM_OK || chk_cover(25) == M_CM_OK || chk_cover(26) == M_CM_OK || 
                       chk_cover(30) == M_CM_OK || chk_cover(31) == M_CM_OK || 
                       chk_cover(32) == M_CM_OK || chk_cover(34) == M_CM_OK || chk_cover(35) == M_CM_OK || 
                       chk_cover(41) == M_CM_OK || chk_cover(42) == M_CM_OK || chk_cover(43) == M_CM_OK || 
                       chk_cover(44) == M_CM_OK || chk_cover(45) == M_CM_OK || chk_cover(46) == M_CM_OK || 
                       chk_cover(48) == M_CM_OK || chk_cover(49) == M_CM_OK || chk_cover(52) == M_CM_OK || 
                       chk_cover(55) == M_CM_OK || chk_cover(56) == M_CM_OK || chk_cover(231) == M_CM_OK ||
                       chk_cover(232) == M_CM_OK || chk_cover(252) == M_CM_OK))
                          return M_CA_NOT_31325556;  /* 77,78,79,80�I�ؤ��o�P31,32,55,56�I��(�t����[�I)�P�ɩӫO */
                   
                   if( IcurrPlyInsType->mdamage_cover != 0 && 
                        (chk_cover(77) != M_CM_OK || chk_cover(78) != M_CM_OK || chk_cover(87) != M_CM_OK)) 
                       return M_CA_INS777887;

                   break;
                   
          case 79: case 80: 
                  if( (IcurrPlyInsType->mdamage_cover != 0) && 
                      (chk_cover(24) == M_CM_OK || chk_cover(25) == M_CM_OK || chk_cover(26) == M_CM_OK || 
                       chk_cover(30) == M_CM_OK || chk_cover(31) == M_CM_OK || 
                       chk_cover(32) == M_CM_OK || chk_cover(34) == M_CM_OK || chk_cover(35) == M_CM_OK || 
                       chk_cover(41) == M_CM_OK || chk_cover(42) == M_CM_OK || chk_cover(43) == M_CM_OK || 
                       chk_cover(44) == M_CM_OK || chk_cover(45) == M_CM_OK || chk_cover(46) == M_CM_OK || 
                       chk_cover(48) == M_CM_OK || chk_cover(49) == M_CM_OK || chk_cover(52) == M_CM_OK || 
                       chk_cover(55) == M_CM_OK || chk_cover(56) == M_CM_OK || chk_cover(231) == M_CM_OK || 
                       chk_cover(232) == M_CM_OK || chk_cover(252) == M_CM_OK))
                          return M_CA_NOT_31325556;  /* 77,78,79,80�I�ؤ��o�P31,32,55,56�I��(�t����[�I)�P�ɩӫO */
                   break;
                   
          case 88: if( IcurrPlyInsType->mdamage_cover != 0 && (chk_cover(77) != M_CM_OK || chk_cover(78) != M_CM_OK)) 
                       return M_CA_INS7778;
                   break;
                   
          case 89: if( IcurrPlyInsType->mdamage_cover != 0 && chk_cover(80) != M_CM_OK ) 
                       return M_CA_INS8980;
                   if( IcurrPlyInsType->mdamage_cover != 0 && chk_cover(90) == M_CM_OK ) 
                       return M_CA_NOT_8990;
                   break;
                   
          case 90: if( IcurrPlyInsType->mdamage_cover != 0 && chk_cover(80) != M_CM_OK ) 
                       return M_CA_INS9080;
                   if( IcurrPlyInsType->mdamage_cover != 0 && chk_cover(89) == M_CM_OK ) 
                       return M_CA_NOT_8990;
                   break;                                                          
      }

      IcurrPlyInsType = IcurrPlyInsType->next;
  }

  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "Found [%s] [%s] in [%s]\n", v_sColumn, v_sData, v_sTable);
  strcpy( v_sMsg, tmp_sMsg);
  end_chk_iins_type_relation( v_sMsg);

  return M_CM_OK;

errexit:

  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy( v_sMsg, tmp_sMsg);
  end_chk_iins_type_relation( v_sMsg);
  return SQLCODE;

}

long chk_cover( int v_iins)
{
  struct   PLY_INS_TYPE *Icurr;

  Icurr= IfirstPlyInsType;
  
  while( Icurr)
  {
      if( v_iins == atoi( Icurr->iins_type))
      {
          if( Icurr->mdamage_cover == 0)
              return 0;
          else
              return M_CM_OK;
      }
      Icurr= Icurr->next;
  }

  return 0;

}

void end_chk_iins_type_relation( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end chk_iins_type_relation function");
  puts("******************************");
  puts("");
}
