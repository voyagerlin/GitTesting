/*
   Name       : chk_IFRS_claim
   Input      : v_card_class 1:�j�� 2���N
                v_iply    	 �O�渹
                v_iclm   	 �߮׸�
                v_ins_type   �z���I��
   return code: M_CM_OK ���\
   Output     : v_iportfolio �զX�N�X
                v_igroup     �s�եN�X
                v_icnt       ���~����
                v_sMsg       �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "comdata.h"
#include "globdata.h"
#include "safeclib.h"

char sTmp_db_name[31];
char *get_car_full_db();
void end_chk_IFRS_claim( );

long chk_IFRS_claim(v_card_class, v_iply, v_iclm, v_ins_type, v_iportfolio, v_igroup, v_icnt, v_sMsg)
$char	*v_card_class, *v_iply, *v_iclm, *v_ins_type, *v_iportfolio, *v_igroup, *v_sMsg;
$int  *v_icnt;
{
	$char sIportfolio[11], sIgroup[21], sFulldb[25], sIcar_type[3], sFapply[2],
	      sKreserve[6], sIcohort[5], sFterm[2], sIpolicy[21], sIclaim[21],
	      sInsType[7],sTpSQL[1000];
	int	errcnt;

    $WHENEVER SQLERROR GOTO errexit;

	puts("begin chk_IFRS_claim function");
	printf("v_card_class[%s], v_iply=[%s], v_iclm=[%s], v_ins_type=[%s]\n",
	        v_card_class, *v_iply, *v_iclm, *v_ins_type);

	strcpy(sIpolicy, v_iply);
	strcpy(sIclaim, v_iclm);
	strcpy(sInsType, v_ins_type);

    strcpy(sIportfolio, " ");
	strcpy(sIgroup, ' ');

	errcnt = 0;

    /* 1.���ˮ֫O��O�_���զX�N�X(iportfolio)�θs�եN�X(igroup_profit) */
    $select unique fapply, iportfolio, igroup_profit, kreserve,
            (SELECT UNIQUE fterm
               from cm_product_code b, insurance_type c
              WHERE b.iins_type = c.iins_ply
                and b.iins_class = 'C'
                AND b.kreserve = a.kreserve
                AND b.iproduct = a.iproduct
                and b.iins_type = a.insure_instype ) as fterm, icohort
       into $sFapply, $sIportfolio, $sIgroup, $sKreserve, $sFterm, $sIcohort
	   from policy_main_dtl a
      where ipolicy1 = $sIpolicy
        and insure_instype = (select iins_ply from insurance_type
                               where iins_type = $sInsType);

	strcpy(sIportfolio, trim(sIportfolio));
	strcpy(sIgroup, trim(sIgroup));
	strcpy(sKreserve, trim(sKreserve));
	strcpy(sIcohort, trim(sIcohort));

    /* if((strlen(sIportfolio)==0)||(strlen(sIgroup)==0))
	{

  	    $SELECT iportfolio INTO $sIportfolio
	       FROM  cm_reserve_portfolio
          WHERE  kreserve = $sKreserve
		    AND   ftype = 'D'
			AND   fterm = $sFterm
			AND   fproportion = 'D';

        if (SQLCODE == SQLNOTFOUND)
		{
			errcnt = errcnt+1;
		}

		if (strlen(sIcohort)==0)
        {
            $select year(dwritten) into $sIcohort
               from policy_main
              where ipolicy1 = $sIpolicy
                and ipolicy2 = ' '
                and iendorsement = ' ';
        }

		strcpy(sIcar_type," ");
		if (strcmp(v_card_class,"1") == 0)
		{
			strcpy(sFulldb, get_car_full_db(sIpolicy));
			strcpy(sFulldb, trim(sFulldb));

			if (strlen(sIclaim)> 5)
			{
				sprintf_s(sTpSQL,1000,
                    "select icar_type  from %s:adjustment_ply where iclaim = '%s'",
                    sFulldb, sIclaim);

                $prepare get_car_type from $sTpSQL;
                $execute get_car_type into $sIcar_type;
                $free get_car_type;
			}
			else
			{

				$select itarget5 into $sIcar_type
				   from policy_new
				  where ipolicy1 = $sIpolicy
				    and ipolicy2 = '';
			}
		}
        $SELECT igroup_profit into $sIgroup
	       FROM  cm_profit_code
	      WHERE  iportfolio = $sIportfolio
	        AND  icohort  = $sIcohort
	        AND  isubcode = $sIcar_type;

		if (SQLCODE == SQLNOTFOUND)
            errcnt = errcnt+2;
    } */


    if (strlen(sIportfolio)==0)
        errcnt = errcnt + 1;

    if (strlen(sIgroup)==0)
        errcnt = errcnt + 2;

	*v_icnt = errcnt;
	strcpy(v_sMsg, " ");
	if (errcnt == 0 )
	{
		strcpy(v_iportfolio, trim(sIportfolio));	/* �զX�N�X */
		strcpy(v_igroup, trim(sIgroup));					/* �s�եN�X */
		strcpy(v_sMsg,  " ");
	}
	else if (errcnt == 1 )
	{
		strcpy(v_iportfolio, " ");					/* �զX�N�X */
		strcpy(v_igroup, trim(sIgroup));		/* �s�եN�X */
		sprintf_s(v_sMsg, sizeof v_sMsg, "�O�渹[%s]�߮׸�[%s]�I��[%s]�d�L�i�զX�N�X�j,�Ь���ⳡ�]�w\n",sIpolicy,sIclaim,sInsType );
	}
	else if (errcnt == 2 )
	{
		strcpy(v_iportfolio, trim(sIportfolio));	/* �զX�N�X */
		strcpy(v_igroup, " ");										/* �s�եN�X */
		sprintf_s(v_sMsg, sizeof v_sMsg, "�O�渹[%s]�߮׸�[%s]�I��[%s]�d�L�i�s�եN�X�j,�Ь���ⳡ�]�w\n",sIpolicy,sIclaim,sInsType );
	}
	else if (errcnt == 3 )
	{
		strcpy(v_iportfolio, " ");	/* �զX�N�X */
		strcpy(v_igroup, " ");			/* �s�եN�X */
		sprintf_s(v_sMsg, sizeof v_sMsg, "�O�渹[%s]�߮׸�[%s]�I��[%s]�d�L�i�զX�N�X�j�B�i�s�եN�X�j,�Ь���ⳡ�]�w\n",sIpolicy,sIclaim,sInsType );
	}

	printf("148:v_iportfolio=[%s], v_igroup=[%s], v_icnt=[%d]\n",
  				v_iportfolio, v_igroup, *v_icnt);

	printf("151:v_sMsg=[%s]\n",v_sMsg);

    end_chk_IFRS_claim( v_sMsg);

	printf("----- end Function ------ \n");

  return M_CM_OK;

errexit:

  sprintf_s( v_sMsg, sizeof v_sMsg, "chk_IFRS:SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  end_chk_IFRS_claim( v_sMsg);
  return SQLCODE;


}

void end_chk_IFRS_claim( v_sMsg)
char *v_sMsg;
{
    printf("     v_sMsg[%s]\n", v_sMsg);
    puts("end end_chk_IFRS_claim function");
    puts("******************************");
    puts("");
}
/*---------------------------------------------------------------*/
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{   char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
    
    sTmp_db_name[0]='\0';
    if (*sIpolicy != '\0' && *sIpolicy !=' ')
    { sTmp_db_name[0]='\0';
      strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
      strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
      USE_BRANCH_ID));
      strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
      printf("sTmp_db_name=[%s]sTmpcomp=[%s]\n",sTmp_db_name,sTmpcomp);
    }
    return sTmp_db_name;
}