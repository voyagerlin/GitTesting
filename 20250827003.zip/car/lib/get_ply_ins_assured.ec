/* SELECT data FROM TABLE �պ� est_ins_assured, �̷s ply_ins_assured, ��l ori_ins_assured,
                          ��� edr_ins_assured, ���` abn_ply_ins_assured, abn_edr_ins_assured,
                          �ƥ� ply_ins_assured_bak
   Name       : get_ply_ins_assured
   Input      : v_sDbname	        ��Ʈw�W��
                v_sTable  	        Table Name	
                v_sColumn               Column Name
                v_sData			�պ⸹�A�O�渹�A�O��沧�`���A�Χ�渹�X
                
   Output     : IfirstPlyInsAssured
                M_CM_OK     ���\
                v_sMsg      �T��
*/

#include "api_xsrv.h"
#include "commsgs.h"
#include "carmsgs.h"
$include "ply_ins_assured.h";
$include "var_length.h";
#include "safeclib.h"
void end_get_ply_ins_assured( );

struct   PLY_INS_ASSURED *get_ply_ins_assured( char *v_sDbname,
                                             char *v_sTable,
                                             char *v_sColumn,
                                             char *v_sData,
                                             long *v_rtncode,
                                             char *v_sMsg)
{
  struct  PLY_INS_ASSURED *IfirstPlyInsAssured, *IcurrPlyInsAssured, *IlastPlyInsAssured;
  $char   iins_type [IINS_TYPE];                /* �I�إN�� */
  $char   provision [7];                        /* ���[���� *//*1081225006-SC1-���ά�-�X�R���[���ڥN�X  6�X*/
  $char   iassured  [IASSURED];                 /* �Q�O�I�Hid */
  $char   nassured  [NASSURED];                 /* �Q�O�I�H�m�W */
  $char   dbirth    [DATE];                     /* �X�ͤ�� */
  $char   nbenef    [NBENEF];                   /* ���q�H�m�W */
  $char   rel_benef [REL_BENEF];                /* ���q�H�P�Q�O�I�H���Y */
  $char   tbenef    [21];                       /* ���q�H�p���q�� (1110310005_SC1) */
  $char   abenef_zip[CA_ZIP];                   /* ���q�H�l���ϸ� */
  $char   abenef    [91];                       /* ���q�H�a�} */
  $long   iserial = 0;                          /* �Ǹ� */


  $char   stmt[2048], sDbname[61],tmp_sMsg[512];

  $WHENEVER SQLERROR GOTO errexit;

  puts("");
  puts("******************************");
  puts("begin get_ply_ins_assured function");
  printf("     v_sDbname=[%s], v_sTable=[%s], v_sColumn[%s], v_sData[%s]\n", v_sDbname, v_sTable, v_sColumn, v_sData);
  strcpy(v_sMsg," ");
  strcpy( tmp_sMsg, " ");
  
  if( strlen(v_sDbname) != 0)
      sprintf_s( sDbname,sizeof sDbname, "%s:%s", v_sDbname, v_sTable);
  else						/* �����wDB�N��localdb */
      sprintf_s( sDbname,sizeof sDbname, v_sTable);

  sprintf_s( stmt,sizeof stmt, "SELECT iins_type, provision, iassured, nassured, dbirth, nbenef, "
                 "       rel_benef, tbenef, abenef_zip, abenef, iserial" 
                 "  FROM %s "
                 " WHERE %s = '%s'"
                 " ORDER BY iins_type, provision", sDbname, v_sColumn, v_sData );
  printf( "     stmt[%s]\n", stmt);

  IcurrPlyInsAssured=IfirstPlyInsAssured=IlastPlyInsAssured=NULL;    /* set init pointer to NULL */

  $PREPARE prep_assured FROM $stmt;
  $DECLARE cur_assured CURSOR FOR prep_assured;
  $OPEN cur_assured;
  for(;;)
  {
      $FETCH cur_assured INTO $iins_type, $provision, $iassured, $nassured, $dbirth, $nbenef, 
                              $rel_benef, $tbenef, $abenef_zip, $abenef, $iserial;
      if( SQLCODE == SQLNOTFOUND)
          break;

      IcurrPlyInsAssured=(struct PLY_INS_ASSURED *)malloc(sizeof(struct PLY_INS_ASSURED));
      
      if(IcurrPlyInsAssured==NULL) free(IcurrPlyInsAssured);  /* �t�X���X���y�B�� */
      
      
      if ( IfirstPlyInsAssured==NULL)
      {
           IfirstPlyInsAssured = IcurrPlyInsAssured;
      }
      else
      {
          IlastPlyInsAssured->next = IcurrPlyInsAssured;
      }
      IlastPlyInsAssured = IcurrPlyInsAssured;
      IcurrPlyInsAssured->next = NULL;

      strcpy( IcurrPlyInsAssured->iins_type, iins_type);
      strcpy( IcurrPlyInsAssured->provision, provision);
      strcpy( IcurrPlyInsAssured->iassured, iassured);
      strcpy( IcurrPlyInsAssured->nassured, nassured);
      strcpy( IcurrPlyInsAssured->dbirth, dbirth);
      strcpy( IcurrPlyInsAssured->nbenef, nbenef);
      strcpy( IcurrPlyInsAssured->rel_benef, rel_benef);
      strcpy( IcurrPlyInsAssured->tbenef, tbenef);
      strcpy( IcurrPlyInsAssured->abenef_zip, abenef_zip);
      strcpy( IcurrPlyInsAssured->abenef, abenef);
      IcurrPlyInsAssured->iserial = iserial;

      printf("    IcurrPlyInsAssured->iins_type    [%s]\n"
             "    IcurrPlyInsAssured->provision    [%s]\n"
             "    IcurrPlyInsAssured->iassured     [%s]\n"
             "    IcurrPlyInsAssured->nassured     [%s]\n"
             "    IcurrPlyInsAssured->dbirth       [%s]\n"
             "    IcurrPlyInsAssured->nbenef       [%s]\n"
             "    IcurrPlyInsAssured->rel_benef    [%s]\n"
             "    IcurrPlyInsAssured->tbenef       [%s]\n"
             "    IcurrPlyInsAssured->abenef_zip   [%s]\n"
             "    IcurrPlyInsAssured->abenef       [%s]\n"
             "    IcurrPlyInsAssured->iserial      [%d]\n",
                  IcurrPlyInsAssured->iins_type,
                  IcurrPlyInsAssured->provision,
                  IcurrPlyInsAssured->iassured,
                  IcurrPlyInsAssured->nassured,
                  IcurrPlyInsAssured->dbirth,
                  IcurrPlyInsAssured->nbenef,
                  IcurrPlyInsAssured->rel_benef,
                  IcurrPlyInsAssured->tbenef,
                  IcurrPlyInsAssured->abenef_zip,
                  IcurrPlyInsAssured->abenef,
                  IcurrPlyInsAssured->iserial);
      puts("");
	
  }
  end_get_ply_ins_assured( v_sMsg);
  
  *v_rtncode = M_CM_OK;

  return IfirstPlyInsAssured;

errexit:

  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy( v_sMsg, tmp_sMsg);
  end_get_ply_ins_assured( v_sMsg);
  *v_rtncode = SQLCODE;
  return IfirstPlyInsAssured;
}

void end_get_ply_ins_assured( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_ply_ins_assured function");
  puts("******************************");
  puts("");
}

