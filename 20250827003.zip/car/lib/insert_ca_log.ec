/*
   Name       : insert_ca_log
   
   Input      : v_ipgid     �{���N��
                v_itype        �@�~���O
                v_ilog1        log�s��1
                v_ilog2        log�s��2
                v_content      �@�~���e
                v_userid       ��s�H��

   return code: M_CM_OK         ���\
                v_sMsg          �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "ISvar.h"
$include "var_length.h";
#include "safeclib.h"
#define MsgLen 512

void end_insert_ca_log( );

long insert_ca_log(v_ipgid,v_itype,v_ilog1,v_ilog2,v_content,v_userid,v_sMsg)
$char   *v_ipgid, *v_itype, *v_ilog1, *v_ilog2, *v_content, *v_userid, *v_sMsg;
{
  long     rtncode=0;
  strcpy(v_sMsg," "); 
  
    $WHENEVER SQLERROR GOTO errexit;

    /*puts("");
    puts("******************************");
    puts("begin insert_ca_log function");*/
    printf("    v_ipgid[%s] \n", v_ipgid);
    printf("    v_itype[%s] \n", v_itype);
    printf("    v_ilog1[%s] \n", v_ilog1);
    printf("    v_ilog2[%s] \n", v_ilog2);
    printf("    v_content[%s] \n", v_content);
    printf("    v_userid[%s] \n", v_userid);


        $INSERT INTO ca_log 
         (ipgid,itype,ilog_number1,ilog_number2,ncontent,iupdate,dupdate)
          VALUES 
         ($v_ipgid,$v_itype,$v_ilog1,$v_ilog2,$v_content,$v_userid,current);

    /*end_insert_ca_log( v_sMsg);*/
    /*printf("     v_sMsg[%s]\n", v_sMsg);*/
    return M_CM_OK;

errexit:

  sprintf_s(v_sMsg, MsgLen, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  end_insert_ca_log( v_sMsg);
  return SQLCODE;

}

void end_insert_ca_log( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end insert_ca_log function");
  puts("******************************");
  puts("");
}
