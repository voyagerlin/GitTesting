/*
   Name       : get_ca_compcard.ec  (�j���Ҩt�ΰt�d)

   Input      : v_iofficer     �g��H�N��
                v_ioffice      �O�N���q�N��
                v_iquota       �~�Z���
                v_iblling      ��ڦr�y
                v_icar_type    ���إN��
                v_icar_type    �~��
				v_dissue       ñ�o���
				v_qperiod      �O��(��)
				v_ibranch_in   �O�I��ñ�o�~��  
                
   return code: M_CM_OK         ���\
                v_sMsg          �T��
*/
/*1070125001_SC5_�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o*/
#include "commsgs.h"
#include "cmnmsgs.h"
#include "carmsgs.h"
#include "safeclib.h"

void end_get_ca_compcard();
long get_ca_compcard();

long get_ca_compcard(v_iofficer,v_ioffice,v_iquota,v_iblling,v_icar_type,v_icar_year,v_dissue,v_qperiod,v_ibranch_in,v_sMsg)
$char *v_iofficer,*v_ioffice,*v_iquota,*v_iblling,*v_icar_type,*v_icar_year,*v_dissue,*v_ibranch_in,*v_sMsg;
int *v_qperiod;
{
    $char  cardnum[21],tmp_cardnum[21];
    $char sIbilling[7];
    int   card_len;
    $char  dissue_c[11],dissue_100[11];
    $char  ioffice[7],icardyear[4],ichk_num[2],sIbranch_in[3];
    int   num_count = 0,fRtnCode =0,reply =0;
    $char icardyear_yy[4],icardyear_mm[3],icardyear_dd[3],ibroker_top[2],dreceive[11],sIcardyear[11];
    $int rnt_msg,rc_ioff,c_iofficer;
    $char ioff_fin_out[2],ideliver[11];
    $char stmt_buf[1024];
    $int qperiod;
    $char bzfrom[3];
    $char iissue_comp[3],ibranch_in[3];

    $WHENEVER SQLERROR GOTO errexit;
	
    /*puts("");
    puts("******************************");
    puts("begin get_ca_compcard function");*/

    printf("v_iofficer[%s],v_ioffice[%s],v_iquota[%s],v_iblling[%s],v_icar_type[%s],v_icar_year[%s],v_dissue[%s],v_qperiod[%d],v_ibranch_in[%s] \n",
	    v_iofficer,v_ioffice,v_iquota,v_iblling,v_icar_type,v_icar_year,v_dissue,v_qperiod,v_ibranch_in);

    if (trim(v_iofficer) == "") return M_CMN_NOFFICER;
    strcpy(iissue_comp ,"");
    strcpy(ibranch_in, substring(v_ibranch_in,1,2));
    strcpy(dissue_100,cm_from_infdate_100(v_dissue));  			

    strcpy(icardyear, v_icar_year);
    strcpy(sIcardyear, v_icar_year);
    strcat(sIcardyear, "/01/01");
	
    printf("--v_icar_year[%s] sIcardyear[%s] \n",v_icar_year,sIcardyear);

    strcpy(sIbilling, v_iblling);
    strncat(sIbilling,v_ioffice,1);
    sIbilling[2]='\0';
    printf("#########sIbilling[%s]\n",sIbilling);
    strcpy(sIbilling,trim(sIbilling));
	
    qperiod = v_qperiod;
			
    fRtnCode = cm_get_serial_num_dwritten ("C1", sIbilling," " ," ", dissue_100, sIcardyear, tmp_cardnum);
    printf("fRtnCode[%d]\n",fRtnCode);
    if (fRtnCode !=0 )
    {
        $WHENEVER SQLERROR goto errexit;
        strcpy(v_sMsg, "�j���Ҩ������~");
        end_get_ca_rate_ext(v_sMsg);
        return fRtnCode;
    }

    card_len = strlen(trim(tmp_cardnum));
    strncpy(cardnum,tmp_cardnum,card_len - 1);
    cardnum[card_len-1]= '\0';
    strncpy(ichk_num,tmp_cardnum+card_len-1,1);
    ichk_num[1] = '\0';

    printf("tmp_cardnum[%s]  card_len[%d]\n",tmp_cardnum,card_len);

    $SELECT iupcomp
       INTO $iissue_comp
       FROM branch
      WHERE ibranch = $ibranch_in;
    
    sprintf_s(stmt_buf,sizeof stmt_buf,"UPDATE compulsory_card "
	                               "   SET iofficer=?, ioffice= ?, iquota=?, icardyear=?, "
	                               "       dissue=?, iissue_branch=?, "
	                               "       iissue_comp=?, icar_type=?, "
	                               "       qperiod=?, fstatus=? "
	                               " WHERE icard=? ");
    $PREPARE ins_comp_u FROM $stmt_buf;
    $EXECUTE ins_comp_u
       USING $v_iofficer, $v_ioffice, $v_iquota, $icardyear, $v_dissue, $ibranch_in,
	     $iissue_comp, $v_icar_type, $qperiod, "7", $cardnum;
	
    if (sqlca.sqlerrd[2] == 0)
    {
        sprintf_s(stmt_buf,sizeof stmt_buf,"INSERT INTO compulsory_card %s %s VALUES %s",
		                           "(icard,iofficer,ioffice,iquota,icardyear,dissue,",
		                           "iissue_branch,iissue_comp,icar_type,qperiod,fstatus,ichk_num)",
		                           "(?,?,?,?,?,?,?,?,?,?,'7',?)");
        $PREPARE ins_comp_a FROM $stmt_buf;
        $EXECUTE ins_comp_a
	   USING $cardnum,$v_iofficer,$v_ioffice,$v_iquota,$icardyear,$v_dissue,
		 $ibranch_in,$iissue_comp,$v_icar_type,$qperiod,$ichk_num;
		
	if (sqlca.sqlerrd[2] == 0)
	{
	    $WHENEVER SQLERROR goto errexit;
	    strcpy(v_sMsg, "�g�J�j���ҥd�ɦ��~");
	    end_get_ca_compcard( v_sMsg);
	    return SQLCODE;
	}
    }

    rnt_msg=0;
    rc_ioff =0;
    c_iofficer =0;
    strcpy(ioff_fin_out,"");
	
    strcpy(ideliver,v_iofficer);
	
    printf("chk �]�w��car140(55��) \n");
    $SELECT NVL(count(*),0) 
       INTO $c_iofficer 
       FROM car_code 
      WHERE kind ='55' 
	AND detail = $ideliver;
    if(c_iofficer == 0)
    {
        printf("chk �H�Ƹ����\n");
	$SELECT NVL(count(*),0) 
	   INTO $c_iofficer 
	   FROM personal:asempl
	  WHERE empl_no = $ideliver
	    AND move_type < 59;
	if(c_iofficer == 0)
	{
	    printf("�O�o�q���N��=>");
	    rc_ioff = cm_get_bzfrom(ideliver," "," ",bzfrom);
	    printf("bzfrom [%s]\n",bzfrom);
	    if((strcmp(bzfrom,"20") == 0 )||(strcmp(bzfrom,"21") == 0 )||(strcmp(bzfrom,"30") == 0 )||(strcmp(bzfrom,"31") == 0 ))
	    {
	        strcpy(ioff_fin_out,"2");
		printf("�O�N/�O�g\n");
	    }
	    else
	    {
	        $SELECT nvl(b.ibroker_top[1], ' ') 
		   INTO $ibroker_top
		   FROM officer a,outer v_commission_obj b
		  WHERE a.iofficer = $ideliver
		    AND a.icomm_obj = b.icomm_obj;
		if(SQLCODE == SQLNOTFOUND)
		{
		    strcpy(ioff_fin_out,"X");
		    printf("�g��N�����s�b");
		}
		else
		{
		    if(strcmp(ibroker_top,"I") == 0 )
		    {
		        strcpy(ioff_fin_out,"2");
		        printf("�g��N��-����");
		    }    
		    else
		    {
		        strcpy(ioff_fin_out,"0");
		        printf("�g��N��-���o��J");
		    }
		}
	    }
	}
	else
	{
	    strcpy(ioff_fin_out,"2");
	}
    }
    else
    {
        strcpy(ioff_fin_out,"1");
    }

    strcpy(dreceive,v_dissue);
    $UPDATE compulsory_card
        SET ideliver_old = $ideliver,
            ideliver     = $ideliver,
            ddeliver_old = $dreceive,
            ddeliver     = $dreceive,
            ireceive     = 'system',
            fin_out      = $ioff_fin_out,
            fstatus      = '0'
      WHERE icard  = $cardnum;

    if (sqlca.sqlerrd[2] == 0)
    {
        $WHENEVER SQLERROR goto errexit;
        strcpy(v_sMsg, "�۰ʰt�o�g�쥢��");
        end_get_ca_compcard( v_sMsg);
        return SQLCODE;
    }
    printf("--cardnum[%s]\n",cardnum);	
    /*end_get_ca_compcard(v_sMsg);*/
    printf("     v_sMsg[%s]\n", v_sMsg);
    return M_CM_OK;
	
errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    end_get_ca_compcard(v_sMsg);
    return SQLCODE;
}

void end_get_ca_compcard(v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_ca_compcard function");
  puts("******************************");
  puts("");
}