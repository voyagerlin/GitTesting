/* Name       : change_iresource
   Input      : *v_iassured	 	�Q�O�I�HID
                *v_iresource		�~�Ȩӷ�

   Output     : return code 		M_CM_OK ���\
                *v_iresource		�~�Ȩӷ�
                *v_sMsg      		�T��
    car9602122
    �Q�O�I�H�����Y���~(cu_company_dtl.irel_group='01')�B�ӥB�~�Ȩӷ���3:�@����u�B9:���u�A
    �~�Ȩӷ��אּ�@��8:���Y���~
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"

void end_change_iresource( );

long change_iresource( char   *v_iassured, 
                       char   *v_iresource, 
                       char   *v_sMsg)
{
  $char    iassured[12];
  $int     iCount;

  $WHENEVER SQLERROR GOTO errexit;

  puts("");
  puts("******************************");
  puts("begin change_iresource function");
  printf("     v_iassured[%s], v_iresource[%s]\n", v_iassured, v_iresource);

  strcpy( iassured, v_iassured);
               
  iCount = 0; 
  /* �Ȯɤ��ק�~�Ȩӷ��A�@�k�n�A�Q��
  $SELECT COUNT(*)
     INTO $iCount
     FROM cu_company_dtl
    WHERE ifpce_id = $iassured
      AND irel_group = '01';
  */
  if( iCount != 0 && ( *v_iresource == '3' || *v_iresource == '9'))
  {
      strcpy( v_iresource, "8");
      sprintf_s( v_sMsg, 250,"v_iassured[%s] found in cu_company_dtl so change v_iresource to [%s] \n",
                        v_iassured, v_iresource );
      end_change_iresource( v_sMsg);
  }

  sprintf_s( v_sMsg, 250, "v_iresource[%s] no change\n", v_iresource);

  end_change_iresource( v_sMsg);

  return M_CM_OK;

errexit:

  sprintf_s( v_sMsg, 250, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  end_change_iresource( v_sMsg);
  return SQLCODE;

}

void end_change_iresource( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end change_iresource function");
  puts("******************************");
  puts("");
}
