/* �ˬd�O�_�ӫO���I�� 
   Name       : chk_iins_existed
   Input      : v_sDbname               ��Ʈw�W��
                v_sTable                Table Name
                v_sColumn               Column Name
                v_sData                 �պ⸹�A�O�渹�A���`���A�Χ�渹�X
                v_sIins_type            �I�إN��
                v_iabn_type             ���`���A 


   Output     : return code 		M_CM_OK ���\
                v_sDmg_cover     ���I�ت��O�B
                v_sMsg      		�T��
*/

#include "api_xsrv.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"
void end_chk_iins_existed( );

long chk_iins_existed( char *v_sDbname,
                       char *v_sTable,
                       char *v_sColumn,
                       char *v_sData,
                       char *v_sIins_type,
                       char *v_iabn_type,
                       long *v_sDmg_cover,
                       char *v_sMsg)
{
  $long    mdamage_cover = 0; 
  $char    stmt[2048],tmp_sMsg[512];
  char     sdb[61];

  $WHENEVER SQLERROR GOTO errexit;

  puts("");
  puts("******************************");
  puts("begin chk_iins_existed function");
  printf("     v_sDbname=[%s], v_sTable=[%s], v_sColumn[%s], v_sData[%s], v_iabn_type[%s] \n",
               v_sDbname, v_sTable, v_sColumn, v_sData, v_iabn_type);
  printf("     v_iins_type[%s]\n", v_sIins_type);               
  strcpy( tmp_sMsg, " ");
  
  if( *v_sDbname == '')
      strcpy( sdb, v_sTable);
  else
      sprintf_s( sdb,sizeof sdb, "%s:%s", v_sDbname, v_sTable);  

  sprintf_s( stmt,sizeof stmt, "SELECT mdamage_cover "
                 "  FROM %s "
                 " WHERE %s = '%s' AND iins_type = '%s'", sdb, v_sColumn, v_sData, v_sIins_type);

  $PREPARE prepA FROM $stmt;
  $EXECUTE prepA INTO $mdamage_cover;
  
  *v_sDmg_cover = mdamage_cover;

printf("iins_type[%s],damage_cover[%ld]\n",v_sIins_type,mdamage_cover);
  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "Found [%s] [%s] in [%s]\n", v_sColumn, v_sData, v_sTable);
  strcpy( v_sMsg, tmp_sMsg);

  end_chk_iins_existed( v_sMsg);

  return M_CM_OK;

errexit:

  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy( v_sMsg, tmp_sMsg);
  end_chk_iins_existed( v_sMsg);
  return SQLCODE;

}


void end_chk_iins_existed( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end chk_iins_existed function");
  puts("******************************");
  puts("");
}
