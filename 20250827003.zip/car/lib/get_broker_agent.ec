/*
   Name       : get_broker_agent
   Input      : v_sIbroker
   return code: M_CM_OK ���\
                v_sIextra_charge  ���[�O�βv�N��,�ثe���O�o�q���O�N�� broker_agent.bzfrom
   Output     : v_sMsg      �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
$include "var_length.h";
#include "safeclib.h"

void end_get_broker_agent( );

long get_broker_agent( v_sIbroker, v_sIextra_charge, v_sMsg)
$char    *v_sIbroker, *v_sIextra_charge, *v_sMsg;
{
  $char bzfrom[3];

  $WHENEVER SQLERROR GOTO errexit;

  puts("");
  puts("***********************************");
  puts("begin get_broker_agent function");
  printf("     v_sIbroker=[%s]\n", v_sIbroker);

  $SELECT bzfrom 
     INTO $bzfrom
     FROM broker_agent
    WHERE ibroker=$v_sIbroker;

  if(SQLCODE==SQLNOTFOUND)
  {
      sprintf_s( v_sMsg, 250,"v_sIbroker[%s] not in table:broker_agent\n", v_sIbroker);
      end_get_broker_agent( v_sMsg);
      return M_CA_NBROKER;
  }

  strcpy( v_sIextra_charge, bzfrom);
  sprintf_s( v_sMsg, 250,"Found v_sIextra_charge[%s]\n ", v_sIextra_charge);
  end_get_broker_agent( v_sMsg);
  return M_CM_OK;

errexit:
  sprintf_s( v_sMsg, 250,"SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]); 
  end_get_broker_agent( v_sMsg);
  return SQLCODE;
}

void end_get_broker_agent( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_broker_agent function");
  puts("*********************************");
  puts("");
}

