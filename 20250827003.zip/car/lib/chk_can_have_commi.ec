/*
   Name       : chk_can_have_commi
   Input      : v_sIbroker       �g���s�� 
                v_sIleader       �޲z�H�N��
                v_mcommission    ����(����O)
   return code: M_CM_OK ���\
   Output     : v_sMsg      �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"
void end_chk_can_have_commi( );

long chk_can_have_commi( v_sIbroker, v_sIleader, v_mcommission, v_sMsg)
$char *v_sIbroker, *v_sIleader, *v_sMsg; 
long  v_mcommission;
{
  $char sIbroker_top[11],tmp_sMsg[512];
  
  $WHENEVER SQLERROR GOTO errexit;

  puts("");
  puts("***********************************");
  puts("begin chk_can_have_commi function");
  printf("     v_sIbroker=[%s], v_sIleader[%s]\n", v_sIbroker, v_sIleader);
  strcpy( tmp_sMsg, " ");
  
  $SELECT ibroker_top
     INTO $sIbroker_top
     FROM broker_agent
    WHERE ibroker = $v_sIbroker;

  if(SQLCODE==SQLNOTFOUND)
  {
      sprintf_s( tmp_sMsg, sizeof tmp_sMsg,"v_sIbroker[%s] not in broker_agent \n", v_sIbroker);
	  strcpy( v_sMsg, tmp_sMsg);
      end_chk_can_have_commi( v_sMsg);
      return M_CA_NOT_IBROKER;
  }

  if( sIbroker_top[0] == '1' && v_mcommission > 0) /* ibroker_top�Ĥ@�X=1,�����I���~�� */
  {
      sprintf_s( tmp_sMsg, sizeof tmp_sMsg,"sIbroker_top[%s] �����I���~�Ȥ��i�H������[%d]\n", sIbroker_top, v_mcommission);
	  strcpy( v_sMsg, tmp_sMsg);
      end_chk_can_have_commi( v_sMsg);
      return M_CA_CANT_HAVE_COMMI1;
  }
  else if( sIbroker_top[0] == '0') /* �����u�~�ȭ� */
  {
      $SELECT first 1 ileader
         FROM cm_salesman_log
        WHERE ileader=$v_sIleader
          AND ibroker_top = '00000'
          AND fcar = '1';               /* ���I */

      if(SQLCODE==SQLNOTFOUND && v_mcommission > 0)
      {
          sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "v_sIleader[%s] not in cm_salesman_log �L�n�����,���i�H������[%d]\n", v_sIleader, v_mcommission);
		  strcpy( v_sMsg, tmp_sMsg);
          end_chk_can_have_commi( v_sMsg);
          return M_CA_CANT_HAVE_COMMI2;
      }
  }

  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "sIbroker_top[%s], v_sIleader[%s] ����[%d] \n", sIbroker_top, v_sIleader, v_mcommission);
  strcpy( v_sMsg, tmp_sMsg);
  end_chk_can_have_commi( v_sMsg);
  return M_CM_OK;

errexit:
  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]); 
  strcpy( v_sMsg, tmp_sMsg);
  end_chk_can_have_commi( v_sMsg);
  return SQLCODE;
}

void end_chk_can_have_commi( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end chk_can_have_commi function");
  puts("*********************************");
  puts("");
}

