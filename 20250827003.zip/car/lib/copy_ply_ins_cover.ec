/* purpose    : �ƻsply_ins_cover 
   Name       : copy_ply_ins_cover
   Input      : v_IfirstPlyInsCover    		
                
   Output     : IcurrPlyInsCover 
*/

#include "api_xsrv.h"
#include "commsgs.h"
#include "carmsgs.h"
$include "ply_ins_cover.h";
$include "var_length.h";
#include "safeclib.h"
/* void end_copy_ply_ins_cover( ); */

struct PLY_INS_COVER *copy_ply_ins_cover( v_IfirstPlyInsCover)
struct   PLY_INS_COVER *v_IfirstPlyInsCover;
{
struct   PLY_INS_COVER *IcurrPlyInsCover, *IfirstNewPlyInsCover, *IcurrNewPlyInsCover, *IlastNewPlyInsCover;

  puts("");
  puts("******************************");
  puts("begin copy_ply_ins_cover function");
  
  IcurrNewPlyInsCover=IfirstNewPlyInsCover=IlastNewPlyInsCover=NULL;    /* set init pointer to NULL */

  IcurrPlyInsCover = v_IfirstPlyInsCover;

  while( IcurrPlyInsCover)
  {
      IcurrNewPlyInsCover=(struct PLY_INS_COVER *)malloc(sizeof(struct PLY_INS_COVER));
      if (IfirstNewPlyInsCover==NULL)
      {
          IfirstNewPlyInsCover=IcurrNewPlyInsCover;
      }
      else
      {
          IlastNewPlyInsCover->next=IcurrNewPlyInsCover;
      }
      IlastNewPlyInsCover=IcurrNewPlyInsCover;
      IcurrNewPlyInsCover->next=NULL;

      strcpy( IcurrNewPlyInsCover->iins_type ,IcurrPlyInsCover->iins_type);
      strcpy( IcurrNewPlyInsCover->icover_type ,IcurrPlyInsCover->icover_type);
      strcpy( IcurrNewPlyInsCover->cover_name ,IcurrPlyInsCover->cover_name);
      strcpy( IcurrNewPlyInsCover->print_name ,IcurrPlyInsCover->print_name);
      strcpy( IcurrNewPlyInsCover->iprem_cover_type ,IcurrPlyInsCover->iprem_cover_type);
      IcurrNewPlyInsCover->mcover        = IcurrPlyInsCover->mcover;
      IcurrNewPlyInsCover->mcover_prem   = IcurrPlyInsCover->mcover_prem;
      IcurrNewPlyInsCover->mdiscount     = IcurrPlyInsCover->mdiscount;
      IcurrNewPlyInsCover->mprem         = IcurrPlyInsCover->mprem;
      IcurrNewPlyInsCover->mpure_prem    = IcurrPlyInsCover->mpure_prem;
      IcurrNewPlyInsCover->pextra_charge = IcurrPlyInsCover->pextra_charge;

      IcurrNewPlyInsCover->mcover_prem_n   = IcurrPlyInsCover->mcover_prem_n;
      IcurrNewPlyInsCover->mdiscount_n     = IcurrPlyInsCover->mdiscount_n;
      IcurrNewPlyInsCover->mprem_n         = IcurrPlyInsCover->mprem_n;
      IcurrNewPlyInsCover->mpure_prem_n    = IcurrPlyInsCover->mpure_prem_n;

      IcurrPlyInsCover = IcurrPlyInsCover->next;
	  
	  if(0) free(IcurrNewPlyInsCover);
  }

  /* end_copy_ply_ins_cover( v_sMsg); */

  return IfirstNewPlyInsCover;

}
/* 
void end_copy_ply_ins_cover( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end copy_ply_ins_cover function");
  puts("******************************");
  puts("");
}
*/
