/* INSERT data INTO TABLE ply_ins_cover, abn_ply_ins_type, est_ins_cover, edr_ins_cover, abn_edr_ins_cover
   Name       : insert_ply_ins_cover
   Input      : v_sDbname	        ��Ʈw�W��
                v_sTable  	        Table Name	
                v_sColumn               Column Name
                v_sData			�պ⸹�A�O�渹�A���`���A�Χ�渹�X
                v_IfirstPlyInsCover
                v_sIins_type		���]�w�I�ءA�h�s�W���I�ءA�S���]�w�N�s�W�Ҧ��I�� 
                
   Output     : M_CM_OK     ���\
                v_sMsg      �T��
*/

#include "api_xsrv.h"
#include "commsgs.h"
#include "carmsgs.h"
$include "ply_ins_cover.h";
$include "var_length.h";
#include "safeclib.h"
void end_insert_ply_ins_cover( );

long insert_ply_ins_cover( v_sDbname, v_sTable, v_sColumn, v_sData, v_IfirstPlyInsCover, v_sIins_type, v_sMsg)
$char    *v_sDbname, *v_sTable, *v_sColumn, *v_sData, *v_sMsg, *v_sIins_type;
struct   PLY_INS_COVER *v_IfirstPlyInsCover;
{
  struct   PLY_INS_COVER *IcurrPlyInsCover;
  $char   iins_type[IINS_TYPE];			/* �I�إN�� */
  $char   cover_name[COVER_NAME];		/* �O�B���� */
  $char   icover_type[ICOVER_TYPE];		/* �O�B���� */
  $long   mcover;				/* �O�B */
  $long   mcover_prem;				/* ñ��O�O */
  $long   mdiscount;				/* ���� */
  $long   mprem;				/* �W���O�O */
  $double mpure_prem;				/* �«O�O */
  $double pextra_charge;			/* ���[�O�βv */
  $char   stmt[2048],tmp_sMsg[512];
  char    sdb[61];
  int     iInsertCount;

  $WHENEVER SQLERROR GOTO errexit;

  iInsertCount = 0;
  puts("");
  puts("******************************");
  puts("begin insert_ply_ins_cover function");
  printf("     v_sDbname=[%s], v_sTable=[%s], v_sColumn[%s], v_sData[%s], v_sIins_type[%s], strlen( trim(v_sIins_type))[%d]\n", 
               v_sDbname, v_sTable, v_sColumn, v_sData, v_sIins_type, strlen( trim(v_sIins_type)));
  strcpy( tmp_sMsg, " ");
  
  if( *v_sDbname == '')
      strcpy( sdb, v_sTable);
  else
      sprintf_s( sdb,sizeof sdb, "%s:%s", v_sDbname, v_sTable);

  sprintf_s( stmt,sizeof stmt, "INSERT INTO %s ( %s, iins_type, icover_type, mcover, mcover_prem, mdiscount, mprem, mpure_prem) "
                 "       VALUES ('%s', ?, ?, ?, ?, ?, ?, ?)" , sdb, v_sColumn, v_sData );
  printf( "     stmt[%s]\n", stmt);

  IcurrPlyInsCover=v_IfirstPlyInsCover;

  $PREPARE prep_cover FROM $stmt;

  while(IcurrPlyInsCover)
  {
      printf("    IcurrPlyInsCover->iins_type    [%s]\n"
             "    IcurrPlyInsCover->cover_name   [%s]\n"
             "    IcurrPlyInsCover->icover_type  [%s]\n"
             "    IcurrPlyInsCover->mcover       [%d]\n"
             "    IcurrPlyInsCover->mcover_prem  [%d]\n"
             "    IcurrPlyInsCover->mdiscount    [%d]\n"
             "    IcurrPlyInsCover->mprem        [%d]\n"
             "    IcurrPlyInsCover->mpure_prem   [%f]\n",
                  IcurrPlyInsCover->iins_type,
                  IcurrPlyInsCover->cover_name,
                  IcurrPlyInsCover->icover_type,
                  IcurrPlyInsCover->mcover,
                  IcurrPlyInsCover->mcover_prem,
                  IcurrPlyInsCover->mdiscount,
                  IcurrPlyInsCover->mprem,
                  IcurrPlyInsCover->mpure_prem);
      puts("");

      strcpy(v_sIins_type, trim(v_sIins_type));
      strcpy(IcurrPlyInsCover->iins_type, trim(IcurrPlyInsCover->iins_type));
      strcpy(v_sIins_type, trim(v_sIins_type));
      
      
      /* if( strlen( trim(v_sIins_type)) != 0 && strncmp( IcurrPlyInsCover->iins_type, v_sIins_type, 2) != 0) */
      if( (strlen( v_sIins_type) != 0) && (strcmp( IcurrPlyInsCover->iins_type, v_sIins_type) != 0))
      {
          IcurrPlyInsCover = IcurrPlyInsCover -> next;
          puts("continue");
          continue;
      }

      strcpy( iins_type,   IcurrPlyInsCover->iins_type);
      strcpy( icover_type, IcurrPlyInsCover->icover_type);
      mcover      = IcurrPlyInsCover->mcover;
      mcover_prem = IcurrPlyInsCover->mcover_prem;
      mdiscount   = IcurrPlyInsCover->mdiscount;
      mprem       = IcurrPlyInsCover->mprem;
      mpure_prem  = IcurrPlyInsCover->mpure_prem;

      $EXECUTE prep_cover  USING $iins_type, $icover_type, $mcover, $mcover_prem, $mdiscount, $mprem, $mpure_prem;
      iInsertCount ++;

      IcurrPlyInsCover = IcurrPlyInsCover -> next;

  }
  $FREE prep_cover;

  sprintf_s( tmp_sMsg, sizeof tmp_sMsg,"�s�W[%d]��\n", iInsertCount);
  strcpy( v_sMsg, tmp_sMsg);
  end_insert_ply_ins_cover( v_sMsg);
  
  return M_CM_OK;

errexit:

  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy( v_sMsg, tmp_sMsg);
  end_insert_ply_ins_cover( v_sMsg);
  return SQLCODE;
}

void end_insert_ply_ins_cover( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end insert_ply_ins_cover function");
  puts("******************************");
  puts("");
}
