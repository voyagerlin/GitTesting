/*
   Name       : get_commission_agent
   Purpose    : 

   Input      : v_iins_cat     �I�O 
                v_ibroker      �g���N�� 
                v_iins_type    �I�إN�� 
                v_iyear        �~�� 
                v_fstart       �O�_�w�ҥγq������
                               (Y:�w�ҥ� N:���ҥ� ��L:�ѥ�FUNCTION�ˮ�)
                v_iofficer     �g��N��
                v_iroute       �q���N��
                v_irate_type   �O�v�O 
                v_iroute_comm  �~�ȱ���
                v_fPlyEdr      P:�O��, E:���

   return code: M_CM_OK                 ���\
                v_pagent		�N�z�v
                v_pdiscount		�����v
                v_pcommiss		�����v
                v_mservice		����O
                v_mother_busi		��L�~�ȶO�Χ��
                v_icheck_disc		�u�f�v�ˮֽX
                v_icheck_commi		�����v�ˮֽX
		          v_icheck_agent		�N�z�v�ˮֽX
		          v_icheck_busi		�~�ȶO�Χ���ˮֽX
		          v_ipaid_base		�I����¦
		          v_pfix_agent		�N�z�v�T�w���
		          v_icheck_mservice	����O�v�ˮֽX
		          v_itype_disc		�u�f���A
                v_sMsg                  �T��
                
*/

#include "commsgs.h"
#include "carmsgs.h"
$include "var_length.h";
$include cmnroute.h;
#include "safeclib.h"
void end_get_commission_agent( );

long get_commission_agent( char   *v_iins_cat, 
                           char   *v_ibroker, 
                           char   *v_iins_type, 
                           char   *v_iyear,
                           char   *v_drate_ym,
                           double *v_pagent, 
                           double *v_pdiscount,
                           double *v_pcommiss, 
                           double *v_mservice,
                           double *v_mother_busi,
                           char   *v_icheck_disc, 
                           char   *v_icheck_commi, 
                           char   *v_icheck_agent, 
                           char   *v_icheck_busi,
                           char   *v_ipaid_base, 
                           double *v_pfix_agent, 
                           char   *v_icheck_mservice,
                           char   *v_itype_disc,
                           char   *v_fstart, 
                           char   *v_iofficer,
                           char   *v_iroute,
                           char   *v_irate_type,
                           char   *v_iroute_comm,
                           char   *v_fPlyEdr,
                           char   *v_sMsg)
{
  long     rtncode;
  $char    stmt[512], sTable[31],tmp_sMsg[512];
  $char    iins_cat[IINS_CAT], ibroker[IBROKER], iins_type[IINS_TYPE], iyear[5];
  $char    drate_ym[DRATE_YM];
  $char    f980401[2]; /* 1:commission_agent�O�v�ͮĤ�>=980401,�O�v�ۥѤƫ�
                          0:commission_agent�O�v�ͮĤ�< 980401,�O�v�ۥѤƫe */
  $double pagent = 0, pdiscount = 0, pcommiss = 0, mservice = 0, mother_busi = 0, pfix_agent = 0;
  $char   icheck_disc[2], icheck_commi[2], icheck_agent[2], icheck_busi[2];
  $char   ipaid_base[2], icheck_mservice[2], itype_disc[2];
  
  /* �t�X�q���ĤG���q */
  char    sFstart[2], sFauth[2], deffect[11];
  $char   sIofficer[11], sIroute[21], sIrate_type[2], sIroute_comm[4];
  $struct cm_route_comm o_stcomm;
  int     o_qrec = 0;
  

    $WHENEVER SQLERROR GOTO errexit;

    puts("");
    puts("******************************");
    puts("begin get_commission_agent function");
    printf("    v_iins_cat[%s], v_ibroker[%s], v_iins_type[%s], v_iyear[%s], v_drate_ym[%s]\n", 
                v_iins_cat, v_ibroker, v_iins_type, v_iyear, v_drate_ym);

    strcpy( iins_cat,  v_iins_cat);
    strcpy( ibroker,   v_ibroker);
    strcpy( iins_type, v_iins_type);
    strcpy( iyear,     v_iyear);
    strcpy( drate_ym,  v_drate_ym);
    
    strcpy(sFstart, v_fstart);
    strcpy(sIofficer, v_iofficer);
    strcpy(sIroute, v_iroute);
    strcpy(sIrate_type, v_irate_type);
    strcpy(sIroute_comm, v_iroute_comm);
    strcpy( tmp_sMsg, " ");
	
    printf("sFstart=[%s]sIofficer=[%s]sIroute=[%s]sIrate_type=[%s]sIroute_comm=[%s]\n",
            sFstart, sIofficer,sIroute,sIrate_type,sIroute_comm);

    $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
       INTO $f980401
       FROM ca_rate_date
      WHERE icode  = $drate_ym
        AND itable = 'commission_agent';

    if(SQLCODE==SQLNOTFOUND)
        return M_CA_COMMI_DRATE;
        
    /* �t�X�q���G�ק� */
    /* 1.�O�_�w�ҥγq������ */
    if ((strcmp(sFstart,"Y") != 0) && (strcmp(sFstart,"N") != 0))
    { 
         /* �T�{�O�ҥγq���~�ȱ���α��v */
         if( v_fPlyEdr[0] != 'E')
         {
         rtncode = cm_get_route_auth("C", sIroute, sIofficer, sFstart, sFauth);
          if( rtncode != M_CM_OK)
          {
            strcpy(v_sMsg, cm_get_errmsg(rtncode));
            end_get_commission_agent( v_sMsg);
                  return  rtncode;
          }
         }
         else strcpy( sFstart, "Y");
    }
    
    /* 2.�w�ҥΫh�ϥΦ@��function���~�ȱ���, ���ҥΫh�ϥέ�{�� */
    if( strcmp(sFstart, "Y") == 0)
    {
       /* �w�ҥγq���N�� */
       deffect[0]= '\0';
       memset(&o_stcomm, 0, sizeof(o_stcomm));
       o_qrec = 0;
       
       rtncode = cm_get_insure_comm(sIroute, sIrate_type, sIroute_comm, "C", iins_cat, iins_type, iyear, &o_qrec, &o_stcomm, deffect);
       printf(" �������������������������������������������� ------\n");
       if( rtncode != M_CM_OK)
       { 
            strcpy(v_sMsg, cm_get_errmsg(rtncode));
            end_get_commission_agent( v_sMsg);
            return  rtncode;
       }
       else if( o_qrec == 0)
       {
       	   /* 103.11.05: �Y���I�O��C�BZ �� X �ɡA�H C �I�O�A��@���A��l�I�O�h�_(1031022002_C1:�t�X�T���I��������������) */       	   
       	   if ((iins_cat[0] == 'C') || (iins_cat[0] == 'X') || (iins_cat[0] == 'Z')){
       	   	   printf("-- trace iins_cat[%s]\n ",iins_cat);
	           memset(&o_stcomm, 0x00, sizeof(o_stcomm));
	           o_qrec = 0;
	           strcpy( iins_cat, "C");
	           strcpy( iyear, "0");
	           rtncode = cm_get_insure_comm(sIroute, sIrate_type, sIroute_comm, "C", iins_cat, iins_type, iyear, &o_qrec, &o_stcomm, deffect);
	           if( rtncode != M_CM_OK)
	           {
	               strcpy(v_sMsg, cm_get_errmsg(rtncode));
	               end_get_commission_agent(v_sMsg);
	               return  rtncode;
	           }
	      }

          if( o_qrec == 0)
          {
               sprintf_s( tmp_sMsg,sizeof tmp_sMsg, " �q���N��[%s], �O�v�O[%s], �~�ȱ���N��[%s], �I�O[%s], �I��[%s], �~��[%s], �����N�z�v�ɸ�Ƨ䤣��\n ",
                                  sIroute, sIrate_type, sIroute_comm, iins_cat, iins_type, iyear);
			   strcpy( v_sMsg, tmp_sMsg);
               end_get_commission_agent( v_sMsg);
               return M_CA_NCOMMISSION_AGENT;
          }
       }

       *v_pagent		= o_stcomm.pagent * 100;
       *v_pdiscount	= o_stcomm.pdiscount *100;
       *v_pcommiss	= o_stcomm.pcommiss*100;
       *v_mservice	 	= o_stcomm.mservice;
       *v_mother_busi	= o_stcomm.mother_busi;
       strcpy( v_icheck_disc, o_stcomm.icheck_disc);
       strcpy( v_icheck_commi, o_stcomm.icheck_commi);
       strcpy( v_icheck_agent, o_stcomm.icheck_agent);
       strcpy( v_icheck_busi, o_stcomm.icheck_busi);
       strcpy( v_ipaid_base, o_stcomm.ipaid_base);
       *v_pfix_agent	= o_stcomm.pfix_agent;		
       strcpy( v_icheck_mservice, o_stcomm.icheck_mservice);	
       strcpy( v_itype_disc, o_stcomm.itype_disc);		
    }
    else
    {
       /* ���ҥγq���N�� */
       if( strcmp( trim(iins_type), "21") == 0)
           strcpy( sTable, "commission_agent");
       else if( f980401[0] == '1') 
           strcpy( sTable, "commission_agent");
       else if( f980401[0] == '0') 
           strcpy( sTable, "commission_agent_old");
   
       sprintf_s(stmt,sizeof stmt, "SELECT pagent*100,  decode(itype_disc,'2',pdiscount*100,pdiscount),"
                     "       pcommiss*100, mservice,    mother_busi,"
                     "       icheck_disc, icheck_commi,    icheck_agent, icheck_busi, ipaid_base, "
                     "       pfix_agent,  icheck_mservice, itype_disc"
                     "  FROM %s"
                     " WHERE iins_cat = ?"
                     "   AND ibroker  = ?"
                     "   AND iins_type = ?"
                     "   AND iyear = ?", sTable); 
       printf("    prep1[%s]\n", stmt); 
       $PREPARE prep1 FROM $stmt;
   
       $EXECUTE prep1 INTO $pagent,      $pdiscount,       $pcommiss,     $mservice,    $mother_busi,     
                           $icheck_disc, $icheck_commi,    $icheck_agent, $icheck_busi, $ipaid_base,      
                           $pfix_agent,  $icheck_mservice, $itype_disc
                     USING $iins_cat, $ibroker, $iins_type, $iyear;
   
       if(SQLCODE==SQLNOTFOUND)
       {
           printf( "    �I�O[%s], �g���N��[%s], �I��[%s], �~��[%s], �����N�z�v�ɸ�Ƨ䤣��(%s)\n ",
                        iins_cat, ibroker, iins_type, iyear, sTable);
   
           strcpy( iins_cat, "C");
           strcpy( iyear, "0");
           $EXECUTE prep1 INTO $pagent,      $pdiscount,       $pcommiss,     $mservice,    $mother_busi,     
                               $icheck_disc, $icheck_commi,    $icheck_agent, $icheck_busi, $ipaid_base,      
                               $pfix_agent,  $icheck_mservice, $itype_disc
                         USING $iins_cat, $ibroker, $iins_type, $iyear;
           if(SQLCODE==SQLNOTFOUND)
           {
               sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "    �I�O[%s], �g���N��[%s], �I��[%s], �~��[%s], �����N�z�v�ɸ�Ƨ䤣��(%s)\n ",
                                     iins_cat, ibroker, iins_type, iyear, sTable);
			   strcpy( v_sMsg, tmp_sMsg);
               end_get_commission_agent( v_sMsg);
               return M_CA_NCOMMISSION_AGENT;
           }
       }
   
       *v_pagent		= pagent;	
       *v_pdiscount	= pdiscount;		
       *v_pcommiss		= pcommiss;	
       *v_mservice	 	= mservice;	
       *v_mother_busi	= mother_busi;
       strcpy( v_icheck_disc, icheck_disc);
       strcpy( v_icheck_commi, icheck_commi);
       strcpy( v_icheck_agent, icheck_agent);
       strcpy( v_icheck_busi, icheck_busi);
       strcpy( v_ipaid_base, ipaid_base);
       *v_pfix_agent	= pfix_agent;		
       strcpy( v_icheck_mservice, icheck_mservice);	
       strcpy( v_itype_disc, itype_disc);		
    }
printf("[%s]\n", v_ipaid_base);
    sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "Found �q���N��[%s], �O�v�O[%s], �~�ȱ���N��[%s], �I�O[%s], �g���N��[%s], �I��[%s], �~��[%s] in %s \n"
                     "     *v_pagent           [%f]\n"
                     "     *v_pdiscount        [%f]\n"
                     "     *v_pcommiss         [%f]\n"
                     "     *v_mservice         [%f]\n"
                     "     *v_mother_busi      [%f]\n"
                     "     *v_icheck_disc      [%s]\n"
                     "     *v_icheck_commi     [%s]\n"
                     "     *v_icheck_agent     [%s]\n"
                     "     *v_icheck_busi      [%s]\n"
                     "     *v_ipaid_base       [%s]\n"
                     "     *v_pfix_agent       [%f]\n"
                     "     *v_icheck_mservice  [%s]\n"
                     "     *v_itype_disc       [%s]\n",
                     sIroute, sIrate_type, sIroute_comm, iins_cat, ibroker, iins_type, iyear, sTable, 
                     *v_pagent,      *v_pdiscount,   *v_pcommiss,
                     *v_mservice,    *v_mother_busi, v_icheck_disc,
                     v_icheck_commi, v_icheck_agent, v_icheck_busi,
                     v_ipaid_base,   *v_pfix_agent,  v_icheck_mservice,
                     v_itype_disc);
	strcpy( v_sMsg, tmp_sMsg);
printf("[%s]\n", v_ipaid_base);
    end_get_commission_agent( v_sMsg);
printf("[%s]\n", v_ipaid_base);

    return M_CM_OK;

errexit:

  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy( v_sMsg, tmp_sMsg);
  end_get_commission_agent( v_sMsg);
  return SQLCODE;

}

void end_get_commission_agent( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_commission_agent function");
  puts("******************************");
  puts("");
}
