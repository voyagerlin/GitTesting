/*
   Name       : get_estimate_prem
   Purpose    : �̸պ⸹�ܸպ��ɡ]estimate�^���o�պ���B�O�O�A�A�Hfunction get_proj_pdiscount���o�ꦬ��ҭp��X�պ�O�O
                �պ�O�O = �պ���B�O�O * �ꦬ��� 

   Input      : v_iestimate        �պ⸹ 

   return code: M_CM_OK            ���\
                v_premium_est      �պ�O�O 
                v_sMsg             �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"
$include "var_length.h";

void end_get_estimate_prem( );

long get_estimate_prem( char   *v_sDbname,
                        char   *v_iestimate,
                        double v_pdiscount,
                        long   *v_premium_est,
                        char   *v_sMsg)
{
  long     rtncode, premium_est;
  $long    premium=0;
  $double  pdiscount = 0;
  $char    iestimate[IESTIMATE], iofficer[IOFFICER], icorps[ICORPS];
  $char    stmt[2048], sDbname1[61],sDbname2[61];

    $WHENEVER SQLERROR GOTO errexit;

    puts("");
    puts("******************************");
    puts("begin get_estimate_prem function");
    printf("    v_iestimate[%s]\n", v_iestimate);
    printf("v_sDbname[%s]\n",v_sDbname);
    if( strlen(v_sDbname) != 0){
        sprintf_s( sDbname1,sizeof sDbname1,"%s:estimate", v_sDbname);
        sprintf_s( sDbname2,sizeof sDbname2,"%s:est_ins_type", v_sDbname);
    }else{                                          /* �����wDB�N��localdb */
        strcpy( sDbname1, "estimate");
        strcpy( sDbname2, "est_ins_type");
    }
    printf("sDbname1[%s]\n",sDbname1);
    printf("sDbname2[%s]\n",sDbname2);        
    strcpy( iestimate, v_iestimate);
    
    
    if (v_pdiscount == 0)
    {
        pdiscount = 0 ;
    }
    else 
    {
        pdiscount = v_pdiscount ; 
    }
    

    
    /* v_pdiscount ��0���ܥ����A�h���o�M�׳]�w��pdiscount*/
    if (pdiscount == 0.0){

	    sprintf_s( stmt, sizeof stmt,"SELECT iofficer2, icorps "
	                                 "  FROM %s "
	                                 " WHERE iestimate='%s' "
	                                 , sDbname1, iestimate );
	    printf("stmt[%s]\n",stmt);                    
	    $PREPARE prep_est FROM $stmt;
	    $EXECUTE prep_est INTO $iofficer, $icorps;
	    printf("SQLCODE[%d]\n",SQLCODE);  
	    if(SQLCODE==SQLNOTFOUND)
	    {
	        sprintf_s( v_sMsg, 250,"    iestimate[%s] not in table estimate\n", iestimate);
	        end_get_estimate_prem( v_sMsg);
	        return M_CA_ESTIMATE_IOFFICER;   /* �̸պ⸹���o�պ���B�O�O���g��N���䤣�� */
	    }
	
	    /* �̸g��N��,¾�ΥN���ܫP���g��]�w�ɡ]spc_officer�^���o�P�P�N���]spc_code�^�A
	       �H�P�P�N���ܫP���M�׳]�w�ɡ]spc_proj�^���o�ꦬ��ҡ]pdiscount�^  */
	
	    rtncode = get_proj_pdiscount( iofficer, icorps, &pdiscount, v_sMsg );
	
	    if( rtncode != M_CM_OK)
	        return rtncode;    

	    sprintf_s( v_sMsg, 250,"Found �P���M�׳]�w��(spc_proj)���o�ꦬ���pdiscount[%f]\n", pdiscount);
	    printf("%s", v_sMsg);
    
    }

    sprintf_s( stmt, sizeof stmt,"SELECT mins_premium "
                                 "  FROM %s "
                                 " WHERE iestimate='%s' "
                                 "   AND iins_type <> '21' "
                                 , sDbname2, iestimate );
    $PREPARE prep_est_ins FROM $stmt;
    
    $DECLARE curs1 CURSOR FOR prep_est_ins;
    
    premium_est = 0;

    $OPEN curs1;
    while(1)
    {
        $FETCH curs1 INTO $premium;
        if(SQLCODE == SQLNOTFOUND)
            break;

        /* �v�I�حp���|�ˤ��J�A�[�` */
        premium_est = premium_est + (long)( premium * pdiscount / 100 + 0.5);
    }
    $CLOSE curs1;
    $FREE curs1;

    *v_premium_est = premium_est;

    sprintf_s( v_sMsg, 250,"�պ�O�O[%d]\n", *v_premium_est);

    end_get_estimate_prem( v_sMsg);

    return M_CM_OK;

errexit:

  sprintf_s( v_sMsg, 250,"SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  end_get_estimate_prem( v_sMsg);
  return SQLCODE;

}

void end_get_estimate_prem( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_estimate_prem function");
  puts("******************************");
  puts("");
}
