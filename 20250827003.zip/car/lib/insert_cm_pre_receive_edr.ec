/*
   Name       : insert_cm_pre_receive_edr

   Input      : v_iendorse      ��� 
                v_ipolicy       �O��
                v_ipgid         �{���N��

   return code: M_CM_OK         ���\
                v_sMsg          �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "ISvar.h"
$include "var_length.h";
#include "safeclib.h"

void end_insert_cm_pre_receive_edr( );

long insert_cm_pre_receive_edr( v_iendorse,
                                v_ipolicy,
                                v_ipgid,
                                v_sMsg)
$char   *v_iendorse, *v_ipolicy, *v_ipgid, *v_sMsg;
{
  long     rtncode;
  $char    spaydate[DATE], ftype_pol[3], ftype_sp[3], ftype[2], fcommit[2], siedr_return[2], iins_kind_ply[3];
  $char    sDB[3], sFull[31], stmt[1024];

  $char fcard_class[2];
  $char iassured[IASSURED], nassured[121], iapplicant[12], napplicant[121], itag[CA_TAG_NUM], iengine[CA_ENGINE_NUM], iofficer[11];
  $char ileader[11], iquota[7], icomm_obj[11], iroute[21], iedr_examiner[11];
  $char icard[21], ibig_comp[2], iedr_return[2], dedr_begin[11], dedr_end[11];
  $long mprem=0, iCount=0;
  $char sTmpPolicy1[21], sTmpPolicy2[21];
   char tmp_sMsg[512];

    $WHENEVER SQLERROR GOTO errexit;

    puts("");
    puts("******************************");
    puts("begin insert_cm_pre_receive_edr function");
    printf("    v_iendorse[%s] \n", v_iendorse);
    printf("    v_ipolicy[%s] \n", v_ipolicy);
    printf("    v_ipgid[%s] \n", v_ipgid);

    strcpy(tmp_sMsg," ");

    strcpy(sDB,get_db(v_ipolicy));
    strcpy(sFull,trim(get_full_dbname(sDB)));

    sprintf_s(stmt, sizeof stmt, "SELECT distinct fcard_class, medrdmg_prem+medrlia_prem, iassured, nassured, "
                   "       iapplicant,  napplicant, nvl(itag,' '), nvl(iengine,' '), iofficer, "
                   "       ileader, iquota,   icomm_obj, iroute, iedr_examiner, "
                   "       icard, ibig_comp, iedr_return, dedr_begin, dedr_end "
                   "  FROM  %s:edr_relation a, %s:endorsement b, %s:edr_ins_type c "
                   " WHERE a.iendorse = b.iendorse "
                   "   AND a.iendorse = c.iendorse "
                   "   AND a.iendorse = '%s' "
                   "   AND a.ipolicy = '%s' "
                   "   AND (c.medrins_prem != 0 OR c.medr_commission != 0 OR c.medr_agent != 0)",
                      sFull, sFull, sFull, v_iendorse, v_ipolicy);
    $PREPARE prep1 FROM $stmt;
    $EXECUTE prep1 INTO $fcard_class, $mprem, $iassured, $nassured, 
                        $iapplicant,  $napplicant, $itag, $iengine, $iofficer, 
                        $ileader, $iquota,   $icomm_obj, $iroute, $iedr_examiner, 
                        $icard, $ibig_comp, $iedr_return, $dedr_begin, $dedr_end;
    if( SQLCODE == 0)
    {
        if( mprem > 0)
            strcpy( ftype, "E");
        else
            strcpy( ftype, "1");

        if (isalpha(ibig_comp[0]))
            strcpy( fcommit, "1");
        else
            strcpy( fcommit, "N");

        if( iedr_return[0] != '1' && iedr_return[0] != '2')
            strcpy( siedr_return, "9");
        else
            strcpy( siedr_return, iedr_return);

        rtncode = get_edr_paydate( v_iendorse, spaydate, ftype_pol, ftype_sp, tmp_sMsg);
        if( rtncode != M_CM_OK)
            return rtncode;

        rtncode = split_policy(v_ipolicy, sTmpPolicy1, sTmpPolicy2);
        if (rtncode != M_CM_OK) return rtncode;

        if( fcard_class[0] == '1')
            strcpy( iins_kind_ply, "C1");
        else
            strcpy( iins_kind_ply, "C2");

        $INSERT INTO cm_pre_receive 
         (iins_cat,   ipre_rcv,   iins_kind,  ftype,      ipre_end,
          iassured,   nassured,   iapplicant, napplicant, itag,
          iengine,    deffect,    paydate,    mprem,      isub,
          iofficer,   ileader,    iquota,     icomm_obj,  iroute,
          fcommit,    ientry,     dentry,     isys,       igroup,
          fstatus,    iupdate,    dupdate,    ipolicy1,   ipolicy2,
          iendorse,   icard,      dprint,     dprint_rcv, iedr_return,
          ftype_pol,  iins_kind_ply, dclose,  ftype_sp,   dbegin,
          dend)
          VALUES 
          ( 'C', $v_iendorse, $fcard_class, $ftype, ' ',
            $iassured, $nassured, $iapplicant, $napplicant, $itag,
            $iengine, $dedr_begin, $spaydate, $mprem, $sDB,
            $iofficer, $ileader, $iquota, $icomm_obj, $iroute,
            $fcommit, $iedr_examiner, current year to second, '1', ' ',
            '10', $v_ipgid, current year to second, $sTmpPolicy1, $sTmpPolicy2,
            $v_iendorse, $icard, NULL, NULL, $siedr_return,
            $ftype_pol, $iins_kind_ply, NULL, $ftype_sp, $dedr_begin,
            $dedr_end);
    }
    $FREE prep1;

    sprintf_s(stmt, sizeof stmt, "SELECT COUNT(*) FROM %s:edr_relation a, cm_pre_receive b "
                   " WHERE a.iendorse = b.ipre_rcv"
                   "   AND a.fcard_class = b.iins_kind"
                   "   AND ipre_end = '' "
                   "   AND a.iendorse = ?"
                   "   AND (a.medrdmg_prem+a.medrlia_prem) <> b.mprem", sFull);

    $PREPARE prep2 FROM $stmt;
    $EXECUTE prep2 INTO $iCount USING $v_iendorse;
    if( iCount != 0)
        return M_CA_PRE_ERR;
        
    strcpy(v_sMsg, tmp_sMsg);
    end_insert_cm_pre_receive_edr(v_sMsg);
    
    return M_CM_OK;

errexit:
  sprintf_s(tmp_sMsg, sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy(v_sMsg, tmp_sMsg);
  end_insert_cm_pre_receive_edr(v_sMsg);
  return SQLCODE;

}

void end_insert_cm_pre_receive_edr(v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end insert_cm_pre_receive_edr function");
  puts("******************************");
  puts("");
}
