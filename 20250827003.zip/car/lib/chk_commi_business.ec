/*
   Name       : chk_commi_business
   Input      : v_type           1:���`��n�ˮ�(�Φb�O��M�g����,�������), 
                                 2:���`���ˮ�(�Φbcar401���)
                v_iabn_type      ���`���O
                v_icode          �O�v�N�� 
                v_mcommission    ����O
                v_mbusiness      ñ��~�ȶO��
   return code: M_CM_OK ���\
   Output     : v_sMsg      �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"
void end_chk_commi_business( );

long chk_commi_business( v_type, v_iabn_type, v_icode, v_mcommission, v_mbusiness, v_sMsg)
long v_type, v_mcommission;
$char *v_iabn_type, *v_icode, *v_sMsg; 
double v_mbusiness;
{
  $char f990301[2], isError[2], tmp_sMsg[512];
  
  $WHENEVER SQLERROR GOTO errexit;

  puts("");
  puts("***********************************");
  puts("begin chk_commi_business function");
  printf("     v_type[%d], v_iabn_type[%s], v_icode[%s], v_mcommission[%d], v_mbusiness[%f]\n", 
               v_type, v_iabn_type, v_icode, v_mcommission, v_mbusiness);
  strcpy( tmp_sMsg, " ");
  
  if( v_type == 1 || (v_type != 1 && *v_iabn_type != 'S' && *v_iabn_type != 'Y'))
  { 
      $SELECT case when drate >= date('03/01/2010') then '1' else '0' end
         INTO $f990301
         FROM ca_rate_date
        WHERE icode  = $v_icode
          AND itable = 'compulsory_premium';

      if(SQLCODE==SQLNOTFOUND)
      {
          sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "�j���I�O�v�ͮĤ�䤣��,�Ь��ӫO����car120�]�w\n");
		  strcpy( v_sMsg, tmp_sMsg);
          end_chk_commi_business( v_sMsg);
          return M_CA_COMP_DRATE;
      }

      if( f990301[0] == '1')
      {
          if( v_mcommission > v_mbusiness) 
          {
              sprintf_s( tmp_sMsg, sizeof tmp_sMsg,"�j���I����O[%d]���i�j��~�ȶO��[%f],�Ь��ӫO��\n", v_mcommission, v_mbusiness);
			  strcpy( v_sMsg, tmp_sMsg);
              end_chk_commi_business( v_sMsg);
              if( v_type == 1)
                  return M_CA_COMMI_BUSINESS;
              else
                  return M_CA_COMMI_BUSINESS1;
          }
      }
  }

  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "chk_commi_business OK \n");
  strcpy( v_sMsg, tmp_sMsg);
  end_chk_commi_business( v_sMsg);
  return M_CM_OK;

errexit:
  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]); 
  strcpy( v_sMsg, tmp_sMsg);
  end_chk_commi_business( v_sMsg);
  return SQLCODE;
}

void end_chk_commi_business( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end chk_commi_business function");
  puts("*********************************");
  puts("");
}

