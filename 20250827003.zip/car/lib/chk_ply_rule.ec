#include "api_xsrv.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "cachkrule.h"
#include "globdata.h"
#include "safeclib.h"
#define SUCCESS   1
#define FAIL      0
 

void end_chk_ply_rule( );
int chk_exception();
int chk_reject_client();

$char  sOfficer[11], sCheck_rule[2], chk_reject[2],sIroute[21];
$int  iFreson5083,iFreson1, iFreson2, iFreson3, iFreson4, iFreson5, iFreson6, iFreson7,  iFreson8, iFreson9, 
      iFresonA, iFresonB;
$char sNassured[121], sIlicense[13], sIengine[CA_ENGINE_NUM], sIbody[CA_BODY_NUM], sItag[21], 
      sPly_edr[10],sNapplicant[121], sIapplicant[13] ;
$char ChkRuleInsType[10] ;
$char sImgr[2];           /* 1070824009-SC2-�֫O�����ˮ֭ק�-�P�@�O��@�~�X�I�T��*/
int   car_type19, ins_type3132;
$long lngInsPrem1,lngInsPrem2,lngInsCover;   
char  *get_car_full_db(); /* 1070531004-SC1-��ã��-�ק���sCAR301�A09+162��05+161��O���ˮ�*/
$char tmp_fulldb[20],sData_chk[21],sdb_chk[61],sColumn_chk[21],sdbname_chk[31];

$int  iChkCount,iChkRate; /*  1081205009-SC1-��ã��-�t�X47�I�رq�D�I�אּ���[�I */
$char tmp_ruleIns[101];
$char *sChkProvTok;       /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X  ����I�ة��Ӹ̪����[����*/
$char sProvDelimiter[9];  /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X  �����ɤW��������*/
$char sChkProvision[21];  /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X */
/* --------------------------------------------------------------------------- */
long chk_ply_rule(RUL_OP,v_sMsg)
struct PLY_RULE_OP *RUL_OP;
char   *v_sMsg;
{
  
   $int      iIrule_main = 0, iIrule = 0, iInstype1, iInstype2, iInstype3;
   $char     sFrule[2], sIins_type1[101], sIins_type2[101], sIcar_type[101], 
             sIabn_type[7], sDcheck1[11], sNrule_text[256], sNexception[31],
             sNmessage[300], sInstmp1[10], sInstmp2[10], sColumn[21],sData[21],
             sVabntype[10], sVcar_type[6], sTmpinstype[7], sIendorse[21],
             sFcar_class[2], sTokInsType[101], sProvision[21], sProvision_tmp[21], 
             sIcarTypetmp[11], sFcar_classtmp[11], sTokType[101], sIlast_ply[21];
   $double   dblMinjured_cover = 0, dblMdeath_cover = 0, dblMdamage_cover = 0;
   $long    mdamage_cover, mdeduct, minjured_cover, mpremium, tmp_amount;
   $char    iins_type[7], stmt[3000], sCar_sql[150], provision[21], fuw_type[2], fedr_class[2];
   int      iins;
   char     sdb[61], sdbname[31], pass12[2];
   char     sOption[2],sNeed_abn[2],sNeed_mcheck[2],tmp_sMsg[512];
   int      Icount1, Icount2, rc1, Icount3;
   $long    dedr_begin, dply_begin, itmp;
   char     *token, *token1;
   $long    mprem1300, mprem3000; 	/* �W�h14,3839�I�ثO�O�����ˮ֨ϥ� add by sylvia 103.01.22 */
   

   $WHENEVER SQLERROR GOTO errexit;

   puts("begin chk_ply_rule function");
   
   while (IfirstPlyrule != NULL)
   {                                /* free �ˮ֪����e */
       IcurrPlyrule=IfirstPlyrule;
       IfirstPlyrule=IcurrPlyrule->next;
       free(IcurrPlyrule);
   }
   
   
   /* 1. Ū�J�O��򥻸�U(RUL_OP) ------------------------------------------ */
   
   printf("��Ʈw    RUL_OP->op_sDbname=[%s]\n",RUL_OP->op_sDbname);
   printf("��ƪ�    RUL_OP->op_sTable=[%s]\n",RUL_OP->op_sTable);
   printf("���      RUL_OP->op_sColumn=[%s]\n",RUL_OP->op_sColumn);
   printf("��Ƥ��e  RUL_OP->op_sData=[%s]\n",RUL_OP->op_sData);
   printf("���`��    RUL_OP->op_iabn_type=[%s]\n",RUL_OP->op_iabn_type);
   printf("���O���O  RUL_OP->op_nequipment=[%s]\n",RUL_OP->op_nequipment);
   printf("�s��/�պ� RUL_OP->op_option=[%s]\n",RUL_OP->op_option);
   printf("�g��N��  RUL_OP->op_officer=[%s]\n",RUL_OP->op_officer);
   printf("����      RUL_OP->op_cartype=[%s]\n",RUL_OP->op_cartype);
   printf("�O��W��  RUL_OP->op_nassured=[%s]\n",RUL_OP->op_nassured);
   printf("�O��ID    RUL_OP->op_ilicense=[%s]\n",RUL_OP->op_ilicense);
   printf("�������X  RUL_OP->op_iengine=[%s]\n",RUL_OP->op_iengine);
   printf("�������X  RUL_OP->op_ibody=[%s]\n",RUL_OP->op_ibody);
   printf("���P���X  RUL_OP->op_itag=[%s]\n",RUL_OP->op_itag);
   printf("�O/���   RUL_OP->op_ply_edr=[%s]\n",RUL_OP->op_ply_edr);
   printf("���L�j��  RUL_OP->op_ply1f=[%s]\n",RUL_OP->op_ply1f);
   printf("��渹    RUL_OP->op_iendorse=[%s]\n",RUL_OP->op_iendorse);
   printf("���H���`��f��    RUL_OP->op_need_abn=[%s]\n",RUL_OP->op_need_abn);
   printf("���H�u�֫ORUL_OP->op_need_mcheck=[%s]\n",RUL_OP->op_need_mcheck);
   printf("�ذe���I��RUL_OP->op_free_ins=[%s]\n",RUL_OP->op_free_ins);
   printf("�n�O�HID  RUL_OP->op_iapplicant=[%s]\n",RUL_OP->op_iapplicant);
   printf("�n�O�H�W��RUL_OP->op_napplicant=[%s]\n",RUL_OP->op_napplicant);
   printf("�q���N��RUL_OP->op_iroute=[%s]\n",RUL_OP->op_iroute);
   
   
   strcpy(RUL_OP->op_sDbname, trim(RUL_OP->op_sDbname)); /* ��Ʈw */
   strcpy(RUL_OP->op_sTable, trim(RUL_OP->op_sTable));   /* ��ƪ��W�� */
   
   if (strcmp(RUL_OP->op_sDbname,"") == 0)
   {
       strcpy( sdb, "");
       strcpy( sdbname, "");
       strcpy( sdb_chk, "");
       strcpy( sdbname_chk, "");  
   }
   else
   {
       sprintf_s(sdb, sizeof sdb, "%s:%s",RUL_OP->op_sDbname,RUL_OP->op_sTable);
       sprintf_s(sdbname,sizeof sdbname, "%s:",RUL_OP->op_sDbname);
       strcpy( sdb_chk, sdb);
       strcpy( sdbname_chk, sdbname);
   }
   
   /*printf("sdb=[%s]\n",sdb);  */ 
   strcpy(sOption, trim(RUL_OP->op_option));       /* 1:�O�O�p��A��L:�w�s��Ʈw */
   strcpy(sOfficer, trim(RUL_OP->op_officer));     /* �g��N�� */
   strcpy(sVcar_type, trim(RUL_OP->op_cartype));   /* ���� */
   
   if (strcmp(sVcar_type,"19") == 0)	/* 19���� */
       car_type19 = 1;
   else
       car_type19 = 0;
   strcpy(sData_chk,"");		
   strcpy(sColumn_chk,"");
   sprintf_s(sVabntype,sizeof sVabntype, ";%s;",trim(RUL_OP->op_iabn_type));  /* ���`����O */
   strcpy(sColumn, trim(RUL_OP->op_sColumn));      /* ��� */
   strcpy(sColumn_chk,sColumn);
   strcpy(sData, trim(RUL_OP->op_sData));          /* ��Ƥ��e */
   strcpy(sData_chk,sData);
   strcpy(sNassured, rtrim(RUL_OP->op_nassured));  /* �Q�O�I�H�m�W */
   strcpy(sIlicense, trim(RUL_OP->op_ilicense));   /* �r�Ӹ��X => ��w�q��"�Q�O�I�HID", 1060523001_C1_���I�պ�X��@�~�s�W��-�Ȥᱱ�޷s�W�n�O�HID�ˮ�*/
   strcpy(sIengine, trim(RUL_OP->op_iengine));     /* �������X */
   strcpy(sIbody, trim(RUL_OP->op_ibody));         /* �������X */
   strcpy(sItag, trim(RUL_OP->op_itag));           /* ���P���X */
   strcpy(sIendorse, trim(RUL_OP->op_iendorse));   /* ��渹 */ 
   strcpy(sNeed_abn, "N");						   /* ���H���`��f��,�w�]��N */
   strcpy(sNeed_mcheck, "N");					   /* ���H�u�֫O,�w�]��N */   
   sprintf_s(sIcarTypetmp,sizeof sIcarTypetmp, ";%s;", trim(RUL_OP->op_cartype));
   sprintf_s(sPly_edr,sizeof sPly_edr, ";%s;",trim(RUL_OP->op_ply_edr)); 
   /*printf("sPly_edr=[%s]sVabntype=[%s]\n",sPly_edr,sVabntype);    */  
   strcpy(RUL_OP->op_free_ins, trim(RUL_OP->op_free_ins));   
   strcpy(sIapplicant, trim(RUL_OP->op_iapplicant));   /* �n�O�HID */
   strcpy(sNapplicant, trim(RUL_OP->op_napplicant));   /* �n�O�H�W�� */
   strcpy(sIroute    , trim(RUL_OP->op_iroute));       /* �q���N�� */
   
   strcpy(tmp_sMsg," ");
   
   /*1.1 �ۥ�/��~�Ψ����R (add by sylvia 100.12.26) ---------------------- */
   memset(sFcar_class, 0x00, sizeof(sFcar_class));
   
   $select fcar_class into $sFcar_class
      from car_type
     where fclass = '1'
       and icode = $sVcar_type
       and trim(fcar_class) <> '';
   
   if( SQLCODE == SQLNOTFOUND)
   {
       sprintf_s(tmp_sMsg,sizeof tmp_sMsg, "���إN��[%s]���~,�нT�{!",sVcar_type);
       strcpy(v_sMsg,tmp_sMsg);
       return M_CA_CHKRULE;
   }
   sprintf_s(sFcar_classtmp,sizeof sFcar_classtmp, ";%s;", trim(sFcar_class));
   strcpy(tmp_ruleIns,"");
   strcpy(sCar_sql," "); 
   /* 104.10.26 fix:���� "����"�z��A"����"������"�D�W�h"���B�z�A
                   ==> �ݦP�ɭץ� "�D�W�h1"�B"�D�W�h14" 
         fix��]�G ex. �D�W�h9:�D�W�d������,���i���[D����; 
                   ==> �D�W�h�o�����ث�A�ӥD�W�h�N�L�k�Q�ˮ�  */
        
   /* �W�[���اP�_SQL  add by sylvia 100.12.26 */
 
   /* --------------------------------------------------------------------- */
   strcpy(chk_reject, "N");
   iChkCount = 0;  iChkRate = 0;                 /*  1081205009-SC1-��ã��-�t�X47�I�رq�D�I�אּ���[�I */
   IcurrPlyrule=IfirstPlyrule=IlastPlyrule=NULL; /* set init pointer to NULL */
   strcpy(sImgr,""); 
      
   $select nvl(imgr,'') INTO $sImgr from officer where iofficer=$sOfficer; /* 1070824009-SC2-�֫O�����ˮ֭ק�-�P�@�O��@�~�X�I�T��*/
   
   memset(tmp_sMsg,0,sizeof(tmp_sMsg));
   
   /* 2. Ū�J�ˮ֪����e ----------------------------------------------------- */
   sprintf_s(stmt,sizeof stmt, "select b.irule_main, b.irule, b.frule, b.iins_type1, b.iins_type2, "
                 "       b.icar_type, b.iabn_type, b.dcheck1, b.minjured_cover, "
                 "       b.mdeath_cover, b.mdamage_cover, b.nrule_text, b.nexception, "
                 "       b.nmessage, b.provision, b.fuw_type "
                 "  from ca_check_rule a, ca_check_setup b"
                 " where a.irule_main = b.irule_main "
                 "   and (b.dexpire is null or b.dexpire > today) "
                 "   and  nexception not matches '*%s*' %s order by 1,2",sPly_edr, sCar_sql);
   /*printf("�ˮ֪����e stmt=[%s]\n",stmt);*/
   
   $PREPARE prep1 FROM $stmt;
   $DECLARE curs1 CURSOR FOR prep1;
   $OPEN curs1;
   puts("OPEN curs1");
   for(;;)
   {
       $FETCH curs1 INTO 
          $iIrule_main, $iIrule, $sFrule, $sIins_type1, $sIins_type2, 
          $sIcar_type, $sIabn_type, $sDcheck1, $dblMinjured_cover,
          $dblMdeath_cover, $dblMdamage_cover, $sNrule_text, $sNexception, 
          $sNmessage, $sProvision, $fuw_type;
       /*puts("FETCH");*/

       if( SQLCODE == SQLNOTFOUND)
           break;

       IcurrPlyrule=(struct CHK_RULE_SETUP *)malloc(sizeof(struct CHK_RULE_SETUP));

       if ( IfirstPlyrule==NULL)
       {
           IfirstPlyrule = IcurrPlyrule;
       }
       else
       {
           IlastPlyrule->next = IcurrPlyrule;
       }

       IlastPlyrule = IcurrPlyrule;
       IcurrPlyrule->next = NULL;
       IcurrPlyrule->irule_main = iIrule_main;               /* �D�W�h�N�� */
       IcurrPlyrule->irule = iIrule;                         /* ���ӳW�h */
       strcpy( IcurrPlyrule->frule, trim(sFrule));           /* �ˮ��ݩ� */
       strcpy( IcurrPlyrule->iins_type1, trim(sIins_type1)); /* �I��1 */
       strcpy( IcurrPlyrule->iins_type2, trim(sIins_type2)); /* �I��2 */
       strcpy( IcurrPlyrule->icar_type, trim(sIcar_type));   /* ���� */
       strcpy( IcurrPlyrule->iabn_type, trim(sIabn_type));   /* ���`��   */
       strcpy( IcurrPlyrule->dcheck1, sDcheck1);             /* �ˮ֤�1  */
       strcpy( IcurrPlyrule->nrule_text, trim(sNrule_text)); /* ��L�W�h */
       strcpy( IcurrPlyrule->nexception, trim(sNexception)); /* �ҥ~�B�z   */
       strcpy( IcurrPlyrule->nmessage, trim(sNmessage));     /* ���~�T��   */

       IcurrPlyrule->minjured_cover = dblMinjured_cover;     /* �O�B�@ */
       IcurrPlyrule->mdeath_cover = dblMdeath_cover;         /* �O�B�G   */
       IcurrPlyrule->mdamage_cover = dblMdamage_cover;       /* �O�B�T   */

       strcpy( IcurrPlyrule->provision, trim(sProvision));   /* ���[����  */
       strcpy( IcurrPlyrule->fuw_type, trim(fuw_type));      /* ���[����  */
	  
       if(0) free(IcurrPlyrule);  /*�Ų������� (�]���X�˴������I)*/
   }
   $CLOSE curs1;
   $FREE curs1;
 
   /* 3. �D�պ�,�hŪ�J�w�s�J��Ʈw���I�ة��Ӹ��(�պ��Ƥw�ѫO/���{���g�J)--*/
   if (strcmp(sOption, "1") != 0)
   {
       ins_type3132 = 0; /* 31,32�I�حӼ� */
       IcurrPlyInsCheck=IfirstPlyInsCheck=IlastPlyInsCheck=NULL; /* set init pointer to NULL */

       strcpy(RUL_OP->op_sData, trim(RUL_OP->op_sData));
       puts("op_sData");
       sprintf_s( stmt,sizeof stmt, "SELECT trim(iins_type), minjured_cover, mdamage_cover, "
                                    "       mdeduct, mins_premium, provision "
                                    "  FROM %s "
                                    " WHERE %s = '%s' ", 
                                    sdb, RUL_OP->op_sColumn, RUL_OP->op_sData);
   
       /*printf("��Ʈw����� stmt=[%s]\n ",stmt);*/
       $PREPARE prepA FROM $stmt;
       $DECLARE cursA CURSOR FOR prepA;
   
       $OPEN cursA;
       for(;;)
       {
           $FETCH cursA  INTO $iins_type, $minjured_cover, $mdamage_cover, $mdeduct, $mpremium, $provision;
   
           if( SQLCODE == SQLNOTFOUND)
               break;

           strcpy(iins_type,trim(iins_type));
           IcurrPlyInsCheck=(struct PLY_INS_CHECK *)malloc(sizeof(struct PLY_INS_CHECK));
           if ( IfirstPlyInsCheck==NULL)
           {
               IfirstPlyInsCheck = IcurrPlyInsCheck;
           }
           else
           {
               IlastPlyInsCheck->next = IcurrPlyInsCheck;
           }

           IlastPlyInsCheck = IcurrPlyInsCheck;

           IcurrPlyInsCheck->next = NULL;

           strcpy( IcurrPlyInsCheck->iins_type, iins_type);   /* �I�إN�� */
           IcurrPlyInsCheck->mdamage_cover = mdamage_cover;         /* �O�B3 */
           IcurrPlyInsCheck->mdeduct = mdeduct;                     /* �ۭt�B */
           IcurrPlyInsCheck->minjured_cover = minjured_cover;       /* �O�B1 */
           IcurrPlyInsCheck->mins_premium = mpremium;               /* �O�O */
           strcpy( IcurrPlyInsCheck->provision, trim(provision));   /* ���[���� */ 
       }
       $CLOSE cursA;
       $FREE cursA;
   }
  
   /* 4. �����I�غ������R (add by sylvia 100.10.11) ---------------------------- */
   iInstype1 = iInstype2 = iInstype3 = 0 ; /* 1:���� 2:���d 3:�j�� */
  
   /*puts("�����I�غ������R");*/

   $select iins_type from insurance_type where 1=0 into temp tmpinstype;
   
   IcurrPlyInsCheck = IfirstPlyInsCheck;
   while (IcurrPlyInsCheck)
   {
       if (IcurrPlyInsCheck->mdamage_cover == 0)
           printf("1 IcurrPlyInsCheck->mdamage_cover == 0 -- \n");  /* �O�B=0 ���L */
       else
       {
           strcpy(sTmpinstype, trim(IcurrPlyInsCheck->iins_type));			
					
	   if ((strcmp(sTmpinstype,"31") == 0) || (strcmp(sTmpinstype,"32") == 0) ||
	       (strcmp(sTmpinstype,"231") == 0) || (strcmp(sTmpinstype,"232") == 0))
	       ins_type3132++;
				 		
				 		
           $insert into tmpinstype (iins_type) values ($sTmpinstype);
       }
       IcurrPlyInsCheck = IcurrPlyInsCheck->next;
   }
  
   $select nvl(sum(decode(fins_grp,'1',1,0)),0), 
           nvl(sum(decode(fins_grp,'2',1,0)),0),
           nvl(sum(decode(fins_grp,'3',1,0)),0)
      into $iInstype1, $iInstype2, $iInstype3
      from insurance_type
     where iins_type in (select iins_type from tmpinstype);
  
   $drop table tmpinstype;

   if (strcmp(RUL_OP->op_ply1f, "1") == 0)
       iInstype3 = 1;
      
   /*puts("op_ply1f");*/
   /*printf("�O��ӫO�������R:����=[%d], ���d[%d], �j��[%d]\n",iInstype1,iInstype2,iInstype3);*/
             
   
                
   /* -------------------------------------------------------------------------- */ 
   
   /* �}�l�ˮ�---------------------------------------------------------------- */ 
   strcpy(pass12,"N");	/* �w�]���ŦX�D�W�h12 */
   IcurrPlyrule = IfirstPlyrule;

   while(IcurrPlyrule)
   {
       if ((strlen(IcurrPlyrule->iabn_type) > 2) && (strstr(IcurrPlyrule->iabn_type, sVabntype)))
       {
           printf(" ------ �U���`���O�ҥ~ --- \n");
           IcurrPlyrule = IcurrPlyrule->next;
           continue;
       }
                        
       strcpy(sCheck_rule, "N");     /* �w�]���ŦX�ˮֳW�h */
       iIrule_main = IcurrPlyrule->irule_main;   /* �D�W�h */
       
       switch(iIrule_main)
       {
           case 1:  /* �D�W�h1: �ӫOiins_type1 �����ӫO iins_type 2 ---------- */
           
               if ((iInstype1+iInstype2) > 0) /* �ȱj��ˮ� modify by sylvia 100.10.11 */
               {   
            	
                   /* 104.10.26 fix:�p�Grule���]�w���ءA�����ŦX���ر���~�ˮ� */              	
           	   /*           fix "�ۥΨ�,�ӫO52�I�ض��f���@�D�I;" ���ˮ֡A  */
             	           	    
         	   if( (strlen(IcurrPlyrule->icar_type)<3)             ||   /* �S���]�w���ر��󤺮e     */
         	       (strstr(IcurrPlyrule->icar_type, sIcarTypetmp)) ||   /* �]�w���e�� "����"        */ 
         	       (strstr(IcurrPlyrule->icar_type, sFcar_classtmp)) )  /* �]�w���e�� "�ۥ�/��~�O" */
         	   { 
		            	
	               /*printf("irule_main=[%d] irule = [%d] �ӫO[%s] �����ӫO [%s]\n",iIrule_main,IcurrPlyrule->irule, IcurrPlyrule->iins_type1,IcurrPlyrule->iins_type2);*/
	               Icount1 = Icount2 = 0;
	               IcurrPlyInsCheck = IfirstPlyInsCheck;
	               
	               /* �v�I�ؤ�� -------------------------------------------------- */
	               while (IcurrPlyInsCheck)
	               {
	                   sprintf_s(sInstmp1,sizeof sInstmp1, ";%s;", trim(IcurrPlyInsCheck->iins_type));
	                   /*printf("* ply_ins_type=[%s]\n",sInstmp1);*/
	
	                   if( strlen( sIendorse) > 0)
	                   {
	                       $select fedr_class
	                          into $fedr_class
	                          from edr_relation
	                         where iendorse = $sIendorse;
	
	                       if( (fedr_class[0] == '1' ||
	                            fedr_class[0] == '2' ||
	                            fedr_class[0] == '4' ||
	                            fedr_class[0] == '5' ||
	                            fedr_class[0] == '8' ||
	                            equip_cmp( RUL_OP->op_nequipment,"21") ||
	                            equip_cmp( RUL_OP->op_nequipment,"22") ||
	                            equip_cmp( RUL_OP->op_nequipment,"25") ||
	                            equip_cmp( RUL_OP->op_nequipment,"59") ||
	                            equip_cmp( RUL_OP->op_nequipment,"69") ||
	                            equip_cmp( RUL_OP->op_nequipment,"70") ||
	                            equip_cmp( RUL_OP->op_nequipment,"72") ||
	                            equip_cmp( RUL_OP->op_nequipment,"74") ||
	                            equip_cmp( RUL_OP->op_nequipment,"78") ||
	                            equip_cmp( RUL_OP->op_nequipment,"79") ||
	                            equip_cmp( RUL_OP->op_nequipment,"81") ||
	                            equip_cmp( RUL_OP->op_nequipment,"83") ||
	                            equip_cmp( RUL_OP->op_nequipment,"87") ||
	                            equip_cmp( RUL_OP->op_nequipment,"89") ||
	                            equip_cmp( RUL_OP->op_nequipment,"93") ||
	                            equip_cmp( RUL_OP->op_nequipment,"94") ||
	                            equip_cmp( RUL_OP->op_nequipment,"95") ||
	                            equip_cmp( RUL_OP->op_nequipment,"96") ) &&
	                            (strcmp( IcurrPlyInsCheck->iins_type, "12") == 0 ||
	                             strcmp( IcurrPlyInsCheck->iins_type, "17") == 0 ||
	                             strcmp( IcurrPlyInsCheck->iins_type, "19") == 0 ||
	                             strcmp( IcurrPlyInsCheck->iins_type, "28") == 0 ))
	                       {
	                           IcurrPlyInsCheck = IcurrPlyInsCheck->next;
	                           continue;
	                       }
	                   }
	
	                   if (IcurrPlyInsCheck->mdamage_cover == 0)
	                       printf("* IcurrPlyInsCheck->mdamage_cover == 0 -- \n");
	                   else
	                   {
	                  	                  	 
	                       if (strstr(IcurrPlyrule->iins_type1, sInstmp1))
	                       {                     	
	                           Icount1 = Icount1 + 1;	                     	  	                   	                     		                        
	                           /*printf("--- Icount1=[%d]\n",Icount1);*/
	                       }
	                     
	                       if (strstr(IcurrPlyrule->iins_type2, sInstmp1))
	                       {
	                           Icount2 = Icount2 + 1;
	                           /*printf("--- Icount2=[%d]\n",Icount2);*/
	                       }
	
	                  	 
	                     
	                       if ((strlen(RUL_OP->op_free_ins) > 2) && (strstr(IcurrPlyrule->iins_type2, RUL_OP->op_free_ins)))
	                       {
	                           /*printf("IcurrPlyrule->iins_type2=[%s]\n",IcurrPlyrule->iins_type2);*/
	                     	   /*printf("RUL_OP->op_free_ins=[%s]\n",RUL_OP->op_free_ins);*/
	                     		
	                           Icount2 = Icount2 + 1;
	                           /*printf("Icount2=[%d]\n",Icount2);*/
	                       }
	                     
	                   }
	                   IcurrPlyInsCheck = IcurrPlyInsCheck->next;
	               }/* end �v�I�ؤ�� */
	               
	               /* �D�W�h1 �ˮֵ��G -------------------------------------------- */               
	               if (((Icount1 > 0) && (Icount2 > 0)) || (Icount1 == 0))
	                   strcpy(sCheck_rule, "Y");  /* �ŦX�W�h */
	               else if (strlen(IcurrPlyrule->nexception) > 2)
	               {  
	                   /* call �ҥ~�B�z */
	                   rc1 = chk_exception(IcurrPlyrule->nexception);
	                   if (rc1 != SUCCESS)
	                   {
	                       sprintf_s(tmp_sMsg,sizeof tmp_sMsg, "�ˮֳW�h %d �ҥ~�B�z���~!", IcurrPlyrule->irule);
	                       strcpy(v_sMsg,tmp_sMsg);
	                       return M_CA_CHKRULE;
	                   }
	               }
	   
	               if (strcmp(sCheck_rule,"N") == 0 )
	               {
	                   if (strcmp(IcurrPlyrule->frule,"E") == 0)
	                   {
	                       /* ���_, �^�ǿ��~�T�� */
	                       strcpy(tmp_sMsg, trim(IcurrPlyrule->nmessage));
	                       strcpy(v_sMsg,tmp_sMsg);
	                       return M_CA_CHKRULE;
	                   }
	                   else
	                   {
	                       strcat(tmp_sMsg, trim(IcurrPlyrule->nmessage));
	                       strcpy(sNeed_mcheck,"Y"); /* ���H�u�֫O */
	                   }
	               }
         	   }               
               }        /* end �ȱj��ˮ� modify by sylvia 100.10.11 */
               break;   /* end �D�W�h1 -----------------------------------------*/
         
           case 2:  /* �D�W�h2: iins_type1 �P iins_type 2 ���i�P�ɩӫO ------- */
           
               if ((iInstype1+iInstype2) > 0) /* �ȱj��ˮ� modify by sylvia 100.10.11 */
               { 
                   /*printf("irule_main=[%d] irule = [%d]:�I��[%s]�P[%s]���i�P�ɩӫO\n",iIrule_main,IcurrPlyrule->irule, IcurrPlyrule->iins_type1,IcurrPlyrule->iins_type2);*/
                   Icount1 = Icount2 = 0;
                   IcurrPlyInsCheck = IfirstPlyInsCheck;
               
                   /* �v�I�ؤ�� -------------------------------------------------- */
                   while (IcurrPlyInsCheck)
                   {
                       sprintf_s(sInstmp1,sizeof sInstmp1, ";%s;", trim(IcurrPlyInsCheck->iins_type));
                       /*printf("** ply_ins_type=[%s]\n",sInstmp1);*/
                       if (IcurrPlyInsCheck->mdamage_cover == 0)
                           printf("** IcurrPlyInsCheck->mdamage_cover == 0 -- \n");
                       else
                       {
                           if (strstr(IcurrPlyrule->iins_type1, sInstmp1))
                           {
                               Icount1 = Icount1 + 1;
                           }
                           
                           if (strstr(IcurrPlyrule->iins_type2, sInstmp1))
                           {
                               Icount2 = Icount2 + 1;
                    	   }
                       }
                       IcurrPlyInsCheck = IcurrPlyInsCheck->next;
                   }/* end �v�I�ؤ�� --------------------------------------------- */
               
                   /* �D�W�h2 �ˮֵ��G -------------------------------------------- */
                   if ((Icount1 == 0) || (Icount2 == 0))
                       strcpy(sCheck_rule, "Y");
                   else if (strlen(IcurrPlyrule->nexception) > 2)
                   {  
                       /* call �ҥ~�B�z */
                       rc1 = chk_exception(IcurrPlyrule->nexception);
                       if (rc1 != SUCCESS)
                       {
                           sprintf_s(tmp_sMsg,sizeof tmp_sMsg, "�ˮֳW�h %d �ҥ~�B�z���~!", IcurrPlyrule->irule);
                           strcpy(v_sMsg,tmp_sMsg);
                           return M_CA_CHKRULE;
                       }
                   }
                           
                   if (strcmp(sCheck_rule,"N") == 0 )
                   {  
                       /* ���ųW�h */
                       if (strcmp(IcurrPlyrule->frule,"E") == 0)
                       {
                           /* ���_, �^�ǿ��~�T�� */
                           strcpy(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                           strcpy(v_sMsg,tmp_sMsg);
                           return M_CA_CHKRULE;
                       }
                       else
                       {
                           strcat(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                           strcpy(sNeed_mcheck,"Y"); /* ���H�u�֫O */
                       }
                   }
               }/* end �ȱj��ˮ� modify by sylvia 100.10.11 */   
               break;  /* end �D�W�h2 ----------------------------------------- */
            
           case 3:  /* �D�W�h3: iins_type1 ���I�ؤ��i�P�ɩӫO --------------- */
           
               if ((iInstype1+iInstype2) > 0) /* �ȱj��ˮ� modify by sylvia 100.10.11 */
               { 
                   /*printf("irule_main=[%d] irule = [%d]:�I��[%s]���i�P�ɩӫO\n",iIrule_main,IcurrPlyrule->irule, IcurrPlyrule->iins_type1);*/
                   Icount1 =  0;
                   IcurrPlyInsCheck = IfirstPlyInsCheck;
               
                   /* �v�I�ؤ�� -------------------------------------------------- */
                   while (IcurrPlyInsCheck)
                   {
                       sprintf_s(sInstmp1,sizeof sInstmp1, ";%s;", trim(IcurrPlyInsCheck->iins_type));
                       /*printf("*** ply_ins_type=[%s]\n",sInstmp1);*/
                       if (IcurrPlyInsCheck->mdamage_cover == 0)
                           printf("*** IcurrPlyInsCheck->mdamage_cover == 0 -- \n");
                       else
                       {
                           if (strstr(IcurrPlyrule->iins_type1, sInstmp1))
                           {
                               Icount1 = Icount1 + 1;
                           }
                       }
                       IcurrPlyInsCheck = IcurrPlyInsCheck->next;
                   } /* end �v�I�ؤ�� -------------------------------------------- */
               
                   /* �D�W�h3 �ˮֵ��G -------------------------------------------- */
                   if (Icount1 <= 1)  
                       strcpy(sCheck_rule, "Y");
                   else if (strlen(IcurrPlyrule->nexception) > 2)
                   {  
                       /* call �ҥ~�B�z */
                       rc1 = chk_exception(IcurrPlyrule->nexception);
                       if (rc1 != SUCCESS)
                       {
                           sprintf_s(tmp_sMsg, sizeof tmp_sMsg,"�ˮֳW�h %d �ҥ~�B�z���~!", IcurrPlyrule->irule);
                           strcpy(v_sMsg,tmp_sMsg);
                           return M_CA_CHKRULE;
                       }
                   }
   
                   if (strcmp(sCheck_rule,"N") == 0 )
                   {  
                       /* ���ųW�h */
                       if (strcmp(IcurrPlyrule->frule,"E") == 0)
                       {
                           /* ���_, �^�ǿ��~�T�� */
                           strcpy(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                           strcpy(v_sMsg,tmp_sMsg);
                           return M_CA_CHKRULE;
                       }
                       else
                       {
                           strcat(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                           strcpy(sNeed_mcheck,"Y"); /* ���H�u�֫O */
                       }
                   }
               }/* end �ȱj��ˮ� modify by sylvia 100.10.11 */
               break;  /* end �D�W�h3 ----------------------------------------- */

           case 4:  /* �ګO�Ȥ��ˮ� */
         
               /* 1071029004_SC1_�s�W���sCAR102�Ȥ���@�ɲ�10��---����W��H�� */
               /* �w��10���O����W��W�[�j���I�ˮ� */
	       if ((iInstype1+iInstype2+iInstype3) > 0) 
	       {
	           if (strcmp(chk_reject,"Y") != 0) 
		   {
		       rc1 = chk_reject_client();
		       if (rc1 != SUCCESS)
		       {
		           /*sprintf_s(tmp_sMsg,sizeof tmp_sMsg, "�ˮֳW�h %d �ګO�Ȥ��ˮ֦��~!", IcurrPlyrule->irule);*/
			   sprintf_s(tmp_sMsg, sizeof tmp_sMsg,"�t�Φ��L���A�Э��աI(chk_reject_client(),SQLCODE = [%d])", IcurrPlyrule->irule,rc1);
			   strcpy(v_sMsg,tmp_sMsg);
			   return M_CA_CHKRULE;
		       }
		   }
		   /*printf("�i�j+���ˮ�10�� BEGIN�j \n");
		     printf("IcurrPlyrule->nrule_text=[%s] iFresonB=[%d]\n",IcurrPlyrule->nrule_text,iFresonB);
		     printf("IcurrPlyrule->iins_type1=[%s]\n",IcurrPlyrule->iins_type1);*/
		   /* 10���O����W��j�������ˮ�-�Y������W��h���_ */
		   if ((strstr(IcurrPlyrule->nrule_text,"B")) && (iFresonB > 0))
		   {
		       /*printf("IcurrPlyrule->iins_type1=[%s]\n",IcurrPlyrule->iins_type1);*/
		       /* ���L�ӫO�S�w���O���I�� */
		       if ((strcmp(trim(IcurrPlyrule->iins_type1),"") == 0))
		       {
		           /*printf("sCheck_rule=[%s]IcurrPlyrule->frule=[%s]\n",sCheck_rule,IcurrPlyrule->frule);*/
			   if (strcmp(sCheck_rule,"N") == 0 )
			   {
			       /*printf("iFresonB[%d]\n",iFresonB);*/
			       if (strcmp(IcurrPlyrule->frule,"E") == 0)
			       {
			           /* ���_, �^�ǿ��~�T�� */
				   strcpy(tmp_sMsg, trim(IcurrPlyrule->nmessage));
				   strcpy(v_sMsg,tmp_sMsg);
				   return M_CA_CHKRULE;
			       }
			   }
		       }
		   }
		   /*printf("�i�j+���ˮ�10�� END�j \n");*/
		   if ((iInstype1+iInstype2) > 0)  /* ���N�I�ˮ� */
		   {
		       /* 1061101005�s�W8.9�������ܰT��*/
		       if ((iFreson1+iFreson2+iFreson3+iFreson4+iFreson5+iFreson6+iFreson7+iFreson8+iFreson9+iFresonA) > 0)
		       {
		           /*printf("IcurrPlyrule->iabn_type=[%s]sVabntype=[%s]\n",IcurrPlyrule->iabn_type,sVabntype);*/
			   /* ���ŦX�ګO���� */
		           if (((strstr(IcurrPlyrule->nrule_text,"7")) && (iFreson7 > 0)) ||
			       ((strstr(IcurrPlyrule->nrule_text,"8")) && (iFreson8 > 0)) ||
			       ((strstr(IcurrPlyrule->nrule_text,"9")) && (iFreson9 > 0)) ||
			       ((strstr(IcurrPlyrule->nrule_text,"A")) && (iFresonA > 0)) ||
			       ((strstr(IcurrPlyrule->nrule_text,"1")) && (iFreson1 > 0)) ||
			       ((strstr(IcurrPlyrule->nrule_text,"2")) && (iFreson2 > 0)) ||
			       ((strstr(IcurrPlyrule->nrule_text,"3")) && (iFreson3 > 0)) ||
			       ((strstr(IcurrPlyrule->nrule_text,"4")) && (iFreson4 > 0)) ||
			       ((strstr(IcurrPlyrule->nrule_text,"5")) && (iFreson5 > 0)) ||
			       ((strstr(IcurrPlyrule->nrule_text,"6")) && (iFreson6 > 0)))
			   {
			       /* ���L�ӫO�S�w���O���I�� */
			       if (((strstr(IcurrPlyrule->iins_type1,"1")) && (iInstype1 > 0)) ||
				   ((strstr(IcurrPlyrule->iins_type1,"2")) && (iInstype2 > 0)) ||
				   ((strstr(IcurrPlyrule->iins_type1,"3")) && (iInstype3 > 0)) ||
				    (strcmp(trim(IcurrPlyrule->iins_type1),"") == 0))
			       {
			           /* 1070528003-SC1-�֫O�����ˮ֭ק�-�P�@�O��@�~�X�I�T��(�t)�H�W-P-car5083
				      1.�г��֫O�T�{�ûݰe�ӫO���ӫ~�쭭�O�f��(��CAR102)*/
				   if (strlen(IcurrPlyrule->iabn_type)>2)
				       strcpy(sNeed_abn,"Y");
									
				   if (strlen(IcurrPlyrule->nexception) > 2)
				   {  
				       /* call �ҥ~�B�z */
				       rc1 = chk_exception(IcurrPlyrule->nexception);
				       if (rc1 != SUCCESS)
				       {
				           sprintf_s(tmp_sMsg,sizeof tmp_sMsg, "�ˮֳW�h %d �ҥ~�B�z���~!", IcurrPlyrule->irule);
					   strcpy(v_sMsg,tmp_sMsg);
					   return M_CA_CHKRULE;
				       }
				   }
								
				   /*printf("sCheck_rule=[%s]IcurrPlyrule->frule=[%s]\n",sCheck_rule,IcurrPlyrule->frule);*/
				   if (strcmp(sCheck_rule,"N") == 0 )
				   {

				       /*printf("iFreson1[%d]\n",iFreson1);
					 printf("iFreson5083[%d]\n",iFreson5083);
					 printf("sIendorse[%s]\n",sIendorse);
					 printf("sImgr[%s]\n",sImgr);*/
				       if (strcmp(IcurrPlyrule->frule,"E") == 0)
				       {
				           /* ���_, �^�ǿ��~�T�� */
					   strcpy(tmp_sMsg, trim(IcurrPlyrule->nmessage));
					   strcpy(v_sMsg,tmp_sMsg);
					   return M_CA_CHKRULE;
				       }
				       else
				       {
				           /* ���קK[�j+��]�P�ɥX��,�ˮְT������,�G�����ˮ� */
					   if ((strstr(IcurrPlyrule->nrule_text,"1")) && (iFreson1 > 0) && (iFreson5083>0)) /* 1070528003-SC1-�֫O�����ˮ֭ק�-�P�@�O��@�~�X�I�T��*/
					   {
					       if ((strcmp(sImgr,"1") == 0 ) || (strlen(sIendorse) > 0))
					       {
					           /* 1070824009-SC2-���өӫO���ˮ֦P�@�O��X�I�T��(officer.imgr)+��椣�ˮ֦P�@�O��X�I�T�� */
						   strcpy(tmp_sMsg, "");
					       }
					       else if (strstr(tmp_sMsg, "�г��֫O�T�{�ûݰe�ӫO�����O�f��(��CAR102)"))
					           strcpy(tmp_sMsg, "");
					       else
					       {
					           strcpy(tmp_sMsg, "�г��֫O�T�{�ûݰe�ӫO�����O�f��(��CAR102)");
						   strcpy(sNeed_mcheck,"Y"); /* ���H�u�֫O */
					       }
					   }
					   else if (strstr(tmp_sMsg, trim(IcurrPlyrule->nmessage)))
					   {
					       strcat(tmp_sMsg, "");
					   }
					   else
					   {
					       strcat(tmp_sMsg, trim(IcurrPlyrule->nmessage));
					       strcpy(sNeed_mcheck,"Y"); /* ���H�u�֫O */
					   }
				       }
				   }
			       }/* end ���L�ӫO�S�w���O���I�� */
			   }/* end ���ŦX�ګO���� */ 
		       }
		   }
	       }
               break; 

           case 5:  /* ��[���[�I�A�ͮĤ�ݩ�D�I�ͮĤ餧��l�i�ӫO */ 
           
               if( strlen( sIendorse)>0 && strcmp( RUL_OP->op_sColumn, "ipolicy") == 0 && (iInstype1+iInstype2) > 0)
               {
                   /*printf("irule_main=[%d] irule = [%d] ��[���[�I[%s]�A�ͮĤ�ݩ�D�I[%s]�ͮĤ餧��l�i�ӫO\n",iIrule_main,IcurrPlyrule->irule, IcurrPlyrule->iins_type1, IcurrPlyrule->iins_type2);*/

                   Icount1 = Icount2 = 0;
                   IcurrPlyInsCheck = IfirstPlyInsCheck;

                   /* �v�I�ؤ�� -------------------------------------------------- */
                   while (IcurrPlyInsCheck)
                   {
                       sprintf_s(sInstmp1, sizeof sInstmp1,";%s;", trim(IcurrPlyInsCheck->iins_type));
                       /*printf("* ply_ins_type=[%s]\n",sInstmp1);*/
                       if (IcurrPlyInsCheck->mdamage_cover == 0)
                           printf("* IcurrPlyInsCheck->mdamage_cover == 0 -- \n");
                       else
                       {
                           if (strstr(IcurrPlyrule->iins_type1, sInstmp1))  /*  �ӫO���[�I */
                           {
                               /* �ˬd�Ӫ��[�I�O�_����[?, �P�ɨ����ͮĤ� */
                               sprintf_s( stmt,sizeof stmt, "select dedr_begin "
                                                            "  from %s edr_relation a, %s edr_ins_type b "
                                                            " where a.iendorse = b.iendorse "
                                                            "   and a.iendorse = '%s'"
                                                            "   and iins_type = '%s'"
                                                            "   and iedr_type = '05'", sdbname, sdbname, sIendorse, IcurrPlyInsCheck->iins_type);
                               /*printf("0:stmt[%s]\n", stmt);*/
                               $PREPARE prep1 FROM $stmt;
                               $EXECUTE prep1 INTO $dedr_begin;
                               if( SQLCODE == SQLNOTFOUND)
                               {
                                   $FREE prep1;
                                   IcurrPlyInsCheck = IcurrPlyInsCheck->next;
                                   continue;
                               }
                               $FREE prep1;

                               {
                               int ilen;
                               char *istart, *iend;
                               char sInstmp[7], iins_type2[64], *stmp;
                               istart = IcurrPlyrule->iins_type2;
                               for(;;)
                               {
                                   stmp = strstr(istart,";");
                                   if( stmp == NULL) break;
                                   /*printf("stmp[%s]\n", stmp);*/
                                   ilen = stmp - istart;
                                   if( ilen==0) {istart = istart + ilen +1; continue;}
                                   /*printf("ilen[%d]\n", ilen);*/
                                   /* ���D�I�ͮĤ� */
                                   strncpy( sInstmp, istart, ilen);
                                   sInstmp[ilen] = 0;
                                   /*printf("�D�I[%s]\n", sInstmp);*/

                                   sprintf_s( stmt, sizeof stmt,"SELECT dedr_begin, dendorse "
                                                                "  FROM %s ply_ins_type_hist "
                                                                " WHERE ipolicy   = '%s' "
                                                                "   AND iins_type = '%s' "
 	                                                        "   AND fedr_status MATCHES '7*' "
                                                                " ORDER BY dendorse desc; ", sdbname, RUL_OP->op_sData, sInstmp);
                                   /*printf("1:stmt[%s]\n", stmt);*/
                                   $PREPARE prep2 FROM $stmt;
                                   $EXECUTE prep2 INTO $dply_begin;
                                   if( SQLCODE == SQLNOTFOUND)
                                   {
                                       sprintf_s( stmt,sizeof stmt, "SELECT dedr_begin, dendorse "
                                                                    "  FROM %s ply_ins_type_hist "
                                                                    " WHERE ipolicy   = '%s' "
                                                                    "   AND iins_type = '%s' "
 	                                                            "   AND (fedr_status = '05' OR fedr_status = ' ') "
                                                                    " ORDER BY dendorse desc; ", sdbname , RUL_OP->op_sData, sInstmp);
                                       /*printf("2:stmt[%s]\n", stmt);*/
                                       $PREPARE prep2 FROM $stmt;
                                       $EXECUTE prep2 INTO $dply_begin;
                                       if( SQLCODE == SQLNOTFOUND)
                                       {
                                           $FREE prep1;
                                           $FREE prep2;
                                           istart = istart + ilen +1;
                                           continue;
                                       }
                                       $FREE prep2;
                                   }
                                   $FREE prep1;

                                   if( dedr_begin < dply_begin) /* ���[�I�ݩ�D�I�ͮī�l�i�ӫO */
                                   {   
                                       if (strcmp(IcurrPlyrule->frule,"E") == 0)
                                       {
                                           /* ���_, �^�ǿ��~�T�� */
                                           strcpy(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                                           strcpy(v_sMsg,tmp_sMsg);
                                           return M_CA_CHKRULE;
                                       }
                                       else
                                       {	
                                           strcat(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                                           strcpy(sNeed_mcheck,"Y"); /* ���H�u�֫O */
                                       }
                                   }
                                   istart = istart + ilen +1;
                               }
                               }
                           }
                       }
                       IcurrPlyInsCheck = IcurrPlyInsCheck->next;
                   } /* end �v�I�ؤ�� */
               }
               break;
         
           case 6:  /* �D�W�h6: �I�ثO�O���i�p���I�ثO�B ;85; (09 + 153)---------- */
           
               if ((iInstype1+iInstype2) > 0) /* �ȱj��ˮ� */
               {   
               
                   char fIns85 = 'N';
               	
                   /*printf("irule_main=[%d] irule = [%d] [%s]�I�ثO�O���i�p���I�ثO�B [%s]\n",iIrule_main,IcurrPlyrule->irule, IcurrPlyrule->iins_type1,IcurrPlyrule->nrule_text);*/
                   Icount1 = 0; fIns85 = 'N';
                   lngInsPrem1=lngInsPrem2=lngInsCover=0;
                   IcurrPlyInsCheck = IfirstPlyInsCheck;
                   strcpy(ChkRuleInsType, "");
                   /* �v�I�ؤ�� -------------------------------------------------- */
                   while (IcurrPlyInsCheck)
                   {
                       sprintf_s(sInstmp1,sizeof sInstmp1, ";%s;", trim(IcurrPlyInsCheck->iins_type));
                       if (strcmp(sInstmp1, ";85;" )==0) fIns85 = 'Y';
                  	
                       if (IcurrPlyInsCheck->mdamage_cover == 0)
                           printf("* IcurrPlyInsCheck->mdamage_cover == 0 -- \n");
                       else
                       {
                           if (strstr(IcurrPlyrule->iins_type1, sInstmp1))
                           {
                     	       if (lngInsPrem1 == 0)
                     	       { 
                     	           lngInsPrem1 = IcurrPlyInsCheck->mins_premium;  /*ex.09 */
                     	       }
                     	       else
                     	       {
                     	           lngInsPrem2 = IcurrPlyInsCheck->mins_premium;  /*ex.153 */	
                     	       }	
                     	       strcpy(ChkRuleInsType, trim(IcurrPlyInsCheck->iins_type));
                        
                               /*printf("sInstmp1=[%s]IcurrPlyrule->nrule_text=[%s]\n ",sInstmp1,IcurrPlyrule->nrule_text);
                               printf("�O�O [%ld]�O�B�@[%ld]�O�B�T[%ld]------------\n",IcurrPlyInsCheck->mins_premium,IcurrPlyInsCheck->minjured_cover, IcurrPlyInsCheck->mdamage_cover);*/


                        
                           }
                     
                           if (strstr(IcurrPlyrule->iins_type2, sInstmp1))
                           {	
                     	       if (strstr(IcurrPlyrule->nrule_text,";minjured;"))
                     	       {         		
                     		   lngInsCover	 = IcurrPlyInsCheck->minjured_cover; 
                     	       }
                     	       else
                     	       {
                     		   lngInsCover	 = IcurrPlyInsCheck->mdamage_cover;
                               }
                           }                       
                       }
                       IcurrPlyInsCheck = IcurrPlyInsCheck->next;
                   }/* end �v�I�ؤ�� */
               
                   /*printf("-- trace lngInsPrem1[%ld]\n ",lngInsPrem1);
                     printf("-- trace lngInsPrem2[%ld]\n ",lngInsPrem2);
                     printf("-- trace lngInsCover[%ld]\n ",lngInsCover);*/
                     
                   if (lngInsCover>0)
                   {
	               if (fIns85=='Y')	               	
	               {	               	    	               	    
	                   if  ((lngInsPrem1 + lngInsPrem2) < lngInsCover) Icount1 = Icount1 + 1;	               	    
	               }
	               else
	               {
	                   if ((lngInsPrem1>0) && (lngInsPrem2>0))
	                   {
	                       if  ((lngInsPrem1 + lngInsPrem2) < lngInsCover) Icount1 = Icount1 + 1;
	                   }
	               }
                   }
                   
                   /* �D�W�h6 �ˮֵ��G -------------------------------------------- */
                   if (Icount1 < 1)
                       strcpy(sCheck_rule, "Y");  /* �ŦX�W�h */
                   else if (strlen(IcurrPlyrule->nexception) > 2)
                   {  
                       /* call �ҥ~�B�z */
                       rc1 = chk_exception(IcurrPlyrule->nexception);
                       if (rc1 != SUCCESS)
                       {
                           sprintf_s(tmp_sMsg,sizeof tmp_sMsg, "�ˮֳW�h %d �ҥ~�B�z���~!", IcurrPlyrule->irule);
                           strcpy(v_sMsg,tmp_sMsg);
                           return M_CA_CHKRULE;
                       }
                   }
   
                   if (strcmp(sCheck_rule,"N") == 0 )
                   {
                       if (strcmp(IcurrPlyrule->frule,"E") == 0)
                       {
                           /* ���_, �^�ǿ��~�T�� */
                           strcpy(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                           strcpy(v_sMsg,tmp_sMsg);
                           return M_CA_CHKRULE;
                       }
                       else
                       {
                           strcat(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                           strcpy(sNeed_mcheck,"Y"); /* ���H�u�֫O */
                       }
                   }
               }/* end �ȱj��ˮ� modify by sylvia 100.10.11 */
               break;/* end �D�W�h6 -----------------------------------------*/
            
           case 7:  /* �D�W�h7: iins_type1 ���I�إ����P�ɩӫO --------------- */
         
               if ((iInstype1+iInstype2) > 0) 
               { 
                   /*printf("irule_main=[%d] irule = [%d]:�I��[%s]�����P�ɩӫO\n",iIrule_main,IcurrPlyrule->irule, IcurrPlyrule->iins_type1);*/
                      
                   Icount1 = Icount2 = 0;
               
                   /* �T�{iins_type1 �����I�حӼ� */
                   strcpy(sTokInsType, IcurrPlyrule->iins_type1);
                   token = strtok(sTokInsType,";");
                   while (token != NULL)
                   {
                       Icount1 ++;
                       /*printf("token=[%s]\n",token);*/
                       token = strtok(NULL,";");
                   }
                   /*printf("�I��1�Ӽ�Icount1=[%d][%s]\n",Icount1,IcurrPlyrule->iins_type1);*/
                   IcurrPlyInsCheck = IfirstPlyInsCheck;
               
                   /* �v�I�ؤ�� -------------------------------------------------- */
                   while (IcurrPlyInsCheck)
                   {
                       sprintf_s(sInstmp1, sizeof sInstmp1,";%s;", trim(IcurrPlyInsCheck->iins_type));
                       /*printf("*** ply_ins_type=[%s]\n",sInstmp1);*/
                       if (IcurrPlyInsCheck->mdamage_cover == 0)
                           printf("*** IcurrPlyInsCheck->mdamage_cover == 0 -- \n");
                       else
                       {
                           if (strstr(IcurrPlyrule->iins_type1, sInstmp1))
                           {
                               Icount2 = Icount2 + 1;
                               /*printf("Icount2=[%d]\n",Icount2);*/
                           }
                       }
                       IcurrPlyInsCheck = IcurrPlyInsCheck->next;
                       /*printf("�I��1�Ӽ�Icount1=[%d]���ӫO�I��1���Ӽ�Icount2[%d]\n",Icount1,Icount2);*/
                   }/* end �v�I�ؤ�� -------------------------------------------- */
               
                   /* �D�W�h7 �ˮֵ��G -------------------------------------------- */
                   if ((Icount2 == 0) ||(Icount2 == Icount1))
                       strcpy(sCheck_rule, "Y");
                   else if (strlen(IcurrPlyrule->nexception) > 2)
                   {  
                       /* call �ҥ~�B�z */
                       rc1 = chk_exception(IcurrPlyrule->nexception);
                       if (rc1 != SUCCESS)
                       {
                           sprintf_s(tmp_sMsg, sizeof tmp_sMsg, "�ˮֳW�h %d �ҥ~�B�z���~!", IcurrPlyrule->irule);
                           strcpy(v_sMsg,tmp_sMsg);
                           return M_CA_CHKRULE;
                       }
                   }
   
                   if (strcmp(sCheck_rule,"N") == 0 )
                   {  
                       /* ���ųW�h */
                       if (strcmp(IcurrPlyrule->frule,"E") == 0)
                       {
                           /* ���_, �^�ǿ��~�T�� */
                           strcpy(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                           strcpy(v_sMsg,tmp_sMsg);
                           return M_CA_CHKRULE;
                       }
                       else
                       {
                           strcat(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                           strcpy(sNeed_mcheck,"Y"); /* ���H�u�֫O */
                       }
                   }
               }/* end �ȱj��ˮ� modify by sylvia 100.10.11 */
               break;  /* end �D�W�h7 ----------------------------------------- */
               
           case 8:  /* �D�W�h8: �ˮ֯S�w�I�إi�ϥΤ����[���� */ 
           
               iChkCount = 0; iChkRate = 0 ;/*  1081205009-SC1-��ã��-�t�X47�I�رq�D�I�אּ���[�I */
               IcurrPlyInsCheck = IfirstPlyInsCheck;
               /*printf("irule_main=[%d] irule = [%d]:-[%s]**[%s]**[%s]sData_chk[%s]\n",iIrule_main,IcurrPlyrule->irule, IcurrPlyrule->provision, IcurrPlyrule->iins_type1, IcurrPlyrule->iins_type2,sData_chk);*/
               /* �v�I�ؤ�� -------------------------------------------------- */
               while (IcurrPlyInsCheck)
               {
                   /*1081225006-SC1-���ά�-�X�R���[���ڥN�X*/
                   strcpy(sChkProvision,IcurrPlyInsCheck->provision);
                   /*printf("IcurrPlyInsCheck->provision[%s]\n",IcurrPlyInsCheck->provision);
                     printf("              sChkProvision[%s]\n",sChkProvision);    */                    
                   itmp=0;
                   strcpy(sProvDelimiter," ");
                   sChkProvTok = strtok(sChkProvision,";");
                    
                   while (sChkProvTok )  /*while(IcurrPlyInsCheck->provision[itmp])*/
                   {

                       /*printf("sChkProvTok[%s]\n",sChkProvTok);*/
                       sprintf_s(sProvDelimiter,sizeof sProvDelimiter,";%s;",trim(sChkProvTok));
                       /*printf("sProvDelimiter[%s]\n",sProvDelimiter);*/
                       if (IcurrPlyInsCheck->mdamage_cover == 0)
                           printf("*** IcurrPlyInsCheck->mdamage_cover == 0 -- \n");
                       else
                       {
                           strcpy(tmp_ruleIns," ");
                           strcpy(stmt," ");
                            
                           if (strlen(trim(IcurrPlyrule->nexception)) > 2)
                           {
                               iChkRate  = atoi(IcurrPlyrule->nexception);
                               /*printf("1081205009-SC1-��ã��-�t�X47�I�رq�D�I�אּ���[�I sColumn_chk[%s]\n",sColumn_chk);
                                 printf("�¸պ�S��table�i�d�ߡAcar301�պ�ǤJ�O�v�a�JiChkCount[%d]nexcep[%d]\n",iChkCount,iChkRate);*/
                                
                               if (strcmp( sColumn_chk, "ipolicy") == 0)
                               {
                                   sprintf_s( stmt, sizeof stmt,"select count(*) \n"
                                                                "  from %s ply_relation a ,%sply_ins_type b\n"
                                                                " where a.ipolicy = '%s' and a.ipolicy = b.ipolicy \n"
                                                                "   AND b.drate_ym::int < %d"
                                                                "   AND b.iins_type = '%s'\n", 
                                   sdbname_chk,sdbname_chk, sData_chk,iChkRate ,trim(IcurrPlyrule->iins_type2) );
                               }
                               else if (strcmp( sColumn_chk, "iestimate") == 0)
                               {
                                   sprintf_s( stmt,sizeof stmt, "select count(*) \n"
                                                                "  from %s estimate a ,%s est_ins_type b\n"
                                                                " where a.iestimate = '%s' and a.iestimate=b.iestimate \n"
                                                                "   AND b.drate_ym::int < %d"
                                                                "   AND b.iins_type = '%s' \n", 
                                   sdbname_chk,sdbname_chk, sData_chk,iChkRate ,trim(IcurrPlyrule->iins_type2) );
                               }
                               else
                               {
                                   /* �¸պ�S��table�i�d�ߡAcar301�պ�ǤJ�O�v�a�J �A�Pnexception�]�w�����*/
                                   iChkCount = atoi(sColumn_chk);
                                   /*printf("iChkCount[%d]nexcep[%d]\n",iChkCount,iChkRate);*/
                                   if (iChkCount < iChkRate) 
                                   {
                                       iChkCount = 1;  
                                   }
                                   else
                                   {
                                       iChkCount = 0;  
                                   }
                               }
                                
                               if ((strlen(trim(sColumn_chk))>0) && (strlen(trim(stmt)) >0))
                               {
                                   /*printf("case 8:stmt[%s]\n", stmt);*/
                                   $PREPARE pre_case8_chk FROM $stmt;
                                   $EXECUTE pre_case8_chk INTO $iChkCount;
                                   if( SQLCODE == SQLNOTFOUND)
                                   {
                                       $FREE pre_case8_chk;   
                                   }
                                   $FREE pre_case8_chk;
                               }
                           }
                            
                           if (iChkCount > 0) 
                           {
                               sprintf_s(tmp_ruleIns,sizeof tmp_ruleIns,"%s;%s;",IcurrPlyrule->iins_type1,IcurrPlyrule->iins_type2);
                           }
                           else
                           {
                               strcpy(tmp_ruleIns,IcurrPlyrule->iins_type1);
                           }
                           
                           /*printf("iChkCount[%d]\ntmp_ruleIns[%s]\n",iChkCount,tmp_ruleIns);*/
                           
                           if (strstr(IcurrPlyrule->provision, sProvDelimiter))
                           {
                              
                               sprintf_s(sInstmp1,sizeof sInstmp1, ";%s;", trim(IcurrPlyInsCheck->iins_type));
                               if ( !strstr(tmp_ruleIns, sInstmp1))
                               {
                                   if (strcmp(IcurrPlyrule->frule,"E") == 0)
                                   {
                                       /* ���_, �^�ǿ��~�T�� */
                                       strcpy(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                                       strcpy(v_sMsg,tmp_sMsg);
                                       return M_CA_CHKRULE;
                                   }
                                   else
                                   {
                                       strcat(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                                       strcpy(sNeed_mcheck,"Y"); /* ���H�u�֫O */
                                   }
                               }
                           }
                       }
                       itmp++;
                       sChkProvTok = strtok(NULL,";");
                   }
                   IcurrPlyInsCheck = IcurrPlyInsCheck->next;
               }/* end �v�I�ؤ�� -------------------------------------------- */        
               break;
               
           case 9:  /* �D�W�h9: �S�w���إi�ϥΤ����[���� */ 
         
               IcurrPlyInsCheck = IfirstPlyInsCheck;
               /* �v�I�ؤ�� -------------------------------------------------- */
               while (IcurrPlyInsCheck)
               {
                   /*1081225006-SC1-���ά�-�X�R���[���ڥN�X*/
                   strcpy(sChkProvision,IcurrPlyInsCheck->provision);
                   /*printf("IcurrPlyInsCheck->provision[%s]\n",IcurrPlyInsCheck->provision);
                   printf("              sChkProvision[%s]\n",sChkProvision); */                       
                   itmp=0;
                   strcpy(sProvDelimiter," ");
                   sChkProvTok = strtok(sChkProvision,";");
                   while (sChkProvTok ) /*while(IcurrPlyInsCheck->provision[itmp])*/
                   {
                       /*printf("sChkProvTok[%s]\n",sChkProvTok);*/
                       sprintf_s(sProvDelimiter,sizeof sProvDelimiter,";%s;",trim(sChkProvTok));
                       /*printf("sProvDelimiter[%s]\n",sProvDelimiter);*/

                        
                       if (IcurrPlyInsCheck->mdamage_cover == 0)
                       {
                           printf("*** IcurrPlyInsCheck->mdamage_cover == 0 -- \n");
                       }
                       else
                       {
                           if (strstr(IcurrPlyrule->provision, sProvDelimiter))
                           {
                               /*printf("*** sIcarTypetmp=[%s]\n",sIcarTypetmp);		      	
                                 printf("*** IcurrPlyrule->icar_type=[%s]\n",IcurrPlyrule->icar_type);*/		      	
                               if ( !strstr(IcurrPlyrule->icar_type, sIcarTypetmp))
                               {
                                   if (strcmp(IcurrPlyrule->frule,"E") == 0)
                                   {
                                       /* ���_, �^�ǿ��~�T�� */
                                       strcpy(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                                       strcpy(v_sMsg,tmp_sMsg);
                                       return M_CA_CHKRULE;
                                   }
                                   else
                                   {
                                       strcat(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                                       strcpy(sNeed_mcheck,"Y"); /* ���H�u�֫O */
                                   }
                               }
                           }
                       }
                       itmp++;
                       sChkProvTok = strtok(NULL,";");
                   }
                   IcurrPlyInsCheck = IcurrPlyInsCheck->next;
               } /* end �v�I�ؤ�� -------------------------------------------- */
               break;
               
           case 10:  /* �D�W�h10:�S�w���ة��I�ػݸg�ӫO���ӮצP�N���i���[�S�w���� */ 
         
               IcurrPlyInsCheck = IfirstPlyInsCheck;
               /* �v�I�ؤ�� -------------------------------------------------- */
               strcpy(ChkRuleInsType, " ");
               /*printf("car_type19=[%d]ins_type3132=[%d]\n",car_type19,ins_type3132);*/
               while (IcurrPlyInsCheck)
               {
                   /*1081225006-SC1-���ά�-�X�R���[���ڥN�X*/
                   strcpy(sChkProvision,IcurrPlyInsCheck->provision);
                   /*printf("IcurrPlyInsCheck->provision[%s]\n",IcurrPlyInsCheck->provision);
                     printf("              sChkProvision[%s]\n",sChkProvision);     */                   
                   itmp=0;
                   strcpy(sProvDelimiter," ");
                   sChkProvTok = strtok(sChkProvision,";");
                   /*printf("IcurrPlyrule->irule=[%d][%d]\n",iIrule_main, IcurrPlyrule->irule);*/
                   while (sChkProvTok )/*while(IcurrPlyInsCheck->provision[itmp])*/
                   {
                       /*printf("sChkProvTok[%s]\n",sChkProvTok);*/
                       sprintf_s(sProvDelimiter,sizeof sProvDelimiter,";%s;",trim(sChkProvTok));
                       /*printf("sProvDelimiter[%s]\n",sProvDelimiter);*/

                       if (IcurrPlyInsCheck->mdamage_cover == 0)
                       {   
                           printf("*** IcurrPlyInsCheck->mdamage_cover == 0 -- \n");
                       }
                       else
                       {
                           if (strstr(IcurrPlyrule->provision, sProvDelimiter))
                           {
                               sprintf_s(sInstmp1,sizeof sInstmp1, ";%s;", trim(IcurrPlyInsCheck->iins_type));
                               if ( strstr(IcurrPlyrule->iins_type1, sInstmp1) &&
                                    strstr(IcurrPlyrule->icar_type, sIcarTypetmp))
                               {
                                   strcpy(sCheck_rule,"Y"); 
                                   strcpy(ChkRuleInsType, trim(IcurrPlyInsCheck->iins_type));
                                   /*printf("--- ChkRuleInsType=[%s] ----\n",ChkRuleInsType);*/
                                   break;
                               }
                           }
                       }
                       itmp++;
                       
                       sChkProvTok = strtok(NULL,";");
                   }
                   if (strcmp(sCheck_rule,"Y") == 0 ) break;
                   IcurrPlyInsCheck = IcurrPlyInsCheck->next;
               }/* end �v�I�ؤ�� -------------------------------------------- */
               
               /* call �ҥ~�B�z */
               rc1 = chk_exception(IcurrPlyrule->nexception);
               if (rc1 != SUCCESS)
               {
                   sprintf_s(tmp_sMsg,sizeof tmp_sMsg, "�ˮֳW�h %d �ҥ~�B�z���~!", IcurrPlyrule->irule);
                   strcpy(v_sMsg,tmp_sMsg);
                   return M_CA_CHKRULE;
               }
               
               if (strcmp(sCheck_rule,"Y") == 0 )
               {  
                   /* ���ųW�h */
                   if (strcmp(IcurrPlyrule->frule,"E") == 0)
                   {
                       /* ���_, �^�ǿ��~�T�� */
                       if (strstr(tmp_sMsg, trim(IcurrPlyrule->nmessage)) == NULL)
                       {
                           strcpy(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                           strcpy(v_sMsg,tmp_sMsg);
                       }
                       return M_CA_CHKRULE;
                   }
                   else
                   {
                       if (strstr(tmp_sMsg, trim(IcurrPlyrule->nmessage)) == NULL)
                           strcat(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                     
                       strcpy(sNeed_mcheck,"Y"); /* ���H�u�֫O */
                   }
               }
               break;
               
           case 11:  /* �D�W�h11:[�I��1]���[[�S�w����]��,���o�[�O[�I��2] --------------- */
            
               if (iInstype1+ iInstype2 > 0) 
               { 
                   /*printf("irule_main=[%d] irule = [%d]:[%s]���[�S�w����[%s]��,���o�[�O[%s]\n",iIrule_main,IcurrPlyrule->irule, IcurrPlyrule->iins_type1, IcurrPlyrule->provision, IcurrPlyrule->iins_type2);*/
                   Icount1 = Icount2 = 0;                      
                   IcurrPlyInsCheck = IfirstPlyInsCheck;
                   /* �v�I�ؤ�� -------------------------------------------------- */
                   while (IcurrPlyInsCheck)
                   {
                       /*1081225006-SC1-���ά�-�X�R���[���ڥN�X*/
                       strcpy(sChkProvision,IcurrPlyInsCheck->provision);
                       /*printf("IcurrPlyInsCheck->provision[%s]\n",IcurrPlyInsCheck->provision);
                         printf("              sChkProvision[%s]\n",sChkProvision);  */                      

                       sprintf_s(sInstmp1,sizeof sInstmp1, ";%s;", trim(IcurrPlyInsCheck->iins_type));
                       /*printf("----- sInstmp1=[%s]IcurrPlyInsCheck->provision=[%s]\n",sInstmp1,IcurrPlyInsCheck->provision);*/
                       if (IcurrPlyInsCheck->mdamage_cover == 0)
                           printf("*** IcurrPlyInsCheck->mdamage_cover == 0 -- \n");
                       else
                       {

                           if (strstr(IcurrPlyrule->iins_type1, sInstmp1))
                           {
                               strcpy(sProvDelimiter," ");
                               sChkProvTok = strtok(sChkProvision,";");
                               while (sChkProvTok )
                               {
                                   /*printf("sChkProvTok[%s]\n",sChkProvTok);*/
                                   sprintf_s(sProvDelimiter, sizeof sProvDelimiter,";%s;",trim(sChkProvTok));
                                   /*printf("sProvDelimiter[%s]\n",sProvDelimiter);*/
                                   if (strstr(IcurrPlyrule->provision, sProvDelimiter))
                                   {
                                       Icount1 = Icount1 + 1;
                                       /*printf("Icount1[%d]\n",Icount1);*/
                                   }
                                   sChkProvTok = strtok(NULL,";");
                               }
                           }
                           
                           /* ���ӫO�I��2���I�� */
                           if (strstr(IcurrPlyrule->iins_type2, sInstmp1))
                           {
                               Icount2 = Icount2 + 1;
                           }
                           /*printf("Icount1=[%d]Icount2=[%d]\n",Icount1,Icount2);*/
                       }
		       IcurrPlyInsCheck = IcurrPlyInsCheck->next;
		   }/* end �v�I�ؤ�� -------------------------------------------- */
		               
		   /* �D�W�h11 �ˮֵ��G -------------------------------------------- */
		   if ((Icount1 == 0) || ((Icount1 > 0) && (Icount2 == 0)))
		       strcpy(sCheck_rule, "Y");
		   else if (strlen(IcurrPlyrule->nexception) > 2)
		   {  
		       /* call �ҥ~�B�z */
		       rc1 = chk_exception(IcurrPlyrule->nexception);
		       if (rc1 != SUCCESS)
		       {
		           sprintf_s(tmp_sMsg, sizeof tmp_sMsg, "�ˮֳW�h %d �ҥ~�B�z���~!", IcurrPlyrule->irule);
		           strcpy(v_sMsg,tmp_sMsg);
		           return M_CA_CHKRULE;
		       }
		   }
		   
		   if (strcmp(sCheck_rule,"N") == 0 )
		   {  
		       /* �����[���o�ӫO���I�� */
		       if (strcmp(IcurrPlyrule->frule,"E") == 0)
		       {
		           /* ���_, �^�ǿ��~�T�� */
		           strcpy(tmp_sMsg, trim(IcurrPlyrule->nmessage));
		           strcpy(v_sMsg,tmp_sMsg);
		           return M_CA_CHKRULE;
		       }
		       else
		       {	
		           strcat(tmp_sMsg, trim(IcurrPlyrule->nmessage));
		           strcpy(sNeed_mcheck,"Y"); /* ���H�u�֫O */
		       }
		   }
	       }/* end �ȱj��ˮ� modify by sylvia 100.10.11 */
               break;  /* end �D�W�h11 ----------------------------------------- */
            
	   case 12:  /* �D�W�h12: iins_type1 �����P iins_type2 �������I�إ����P�ɩӫO --------------- */
	   
               if ((iInstype1+iInstype2) > 0) 
               { 
                   /*printf("irule_main=[%d] irule = [%d]:�I��1[%s]�����P�I��2[%s]�����I�ئP�ɩӫO\n",iIrule_main,IcurrPlyrule->irule, IcurrPlyrule->iins_type1, IcurrPlyrule->iins_type2);*/
               
                   strcpy(sTokType, IcurrPlyrule->iins_type2);
                   token1 = strtok(sTokType,"!");
                   /*printf("token1=[%s]\n",token1);*/
                   while (token1 != NULL)
                   {
                       Icount1 = Icount2 = Icount3 = 0;
                       /* �T�{iins_type2 �����I�حӼ� */
               	       strcpy(sTokInsType, token1);
               	       itmp=0;
               	       while (sTokInsType[itmp])
               	       {
               	           if (sTokInsType[itmp] == ';')
               		       Icount3++;
               				
               		   itmp++;
               	       }
               	       if (Icount3 > 0) Icount3=Icount3-1;
		       /*printf("�I��2�Ӽ�Icount3=[%d][%s]\n",Icount3,token1);*/
		       IcurrPlyInsCheck = IfirstPlyInsCheck;
               			
              	       /* �v�I�ؤ�� -------------------------------------------------- */
		       while (IcurrPlyInsCheck)
		       {
		           sprintf_s(sInstmp1, sizeof sInstmp1, ";%s;", trim(IcurrPlyInsCheck->iins_type));		                  
		              
		           if (IcurrPlyInsCheck->mdamage_cover == 0)
		               printf("*** IcurrPlyInsCheck->mdamage_cover == 0 -- \n");
		           else
		           {
		               /*printf("3:token1=[%s]sInstmp1=[%s]IcurrPlyrule->iins_type1=[%s]\n",token1,sInstmp1,IcurrPlyrule->iins_type1);*/
		               if (strstr(IcurrPlyrule->iins_type1, sInstmp1))
		               {
		                   Icount1 = Icount1 + 1;
		               }
		                     
		               if (strstr(token1, sInstmp1))
		               {
		                   Icount2 = Icount2 + 1;
		               }
		           }
		           IcurrPlyInsCheck = IcurrPlyInsCheck->next;
		           /*printf("�I��1�Ӽ�Icount1=[%d]���ӫO�I��2���Ӽ�Icount2[%d]\n",Icount1,Icount2);*/
		       } /* end �v�I�ؤ�� -------------------------------------------- */
		               
		       if (((Icount1 > 0) && (Icount2 == Icount3)) || (Icount1 == 0))
                           strcpy(sCheck_rule, "Y");
                  			
	               token1 = strtok(NULL,"!");
	           }
	           
   		   /* �D�W�h12 �ˮֵ��G -------------------------------------------- */

                   if ((strcmp(sCheck_rule,"N") == 0) && (strlen(IcurrPlyrule->nexception) > 2))
                   {  
                       /* call �ҥ~�B�z */
                       rc1 = chk_exception(IcurrPlyrule->nexception);
                       if (rc1 != SUCCESS)
                       {
                           sprintf_s(tmp_sMsg, sizeof tmp_sMsg,"�ˮֳW�h %d �ҥ~�B�z���~!", IcurrPlyrule->irule);
                           strcpy(v_sMsg,tmp_sMsg);
                           return M_CA_CHKRULE;
                       }
                   }
   
                   if (strcmp(sCheck_rule,"N") == 0 )
                   {  
                       /* ���ųW�h */
                       if (strcmp(IcurrPlyrule->frule,"E") == 0)
                       {
                           /* ���_, �^�ǿ��~�T�� */
                           strcpy(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                           strcpy(v_sMsg,tmp_sMsg);
                           return M_CA_CHKRULE;
                       }
                       else
                       {
                           strcat(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                           strcpy(sNeed_mcheck,"Y"); /* ���H�u�֫O */
                       }
                   }
               }/* end �ȱj��ˮ� modify by sylvia 100.10.11 */
               break;  /* end �D�W�h12 ----------------------------------------- */
            
           case 13:  /* �D�W�h13: �I�ثO�B���i�j���B ---------- */
         
               if ((iInstype1+iInstype2) > 0) /* �ȱj��ˮ� */
               {   
                   /*printf("irule_main=[%d] irule = [%d] [%s]�I�ثO�B���i�j���B [%ld]\n",iIrule_main,IcurrPlyrule->irule, IcurrPlyrule->iins_type1,IcurrPlyrule->minjured_cover);*/
                   Icount1 = 0;
                   IcurrPlyInsCheck = IfirstPlyInsCheck;
               
                   /* �v�I�ؤ�� -------------------------------------------------- */
                   while (IcurrPlyInsCheck)
                   {
                       sprintf_s(sInstmp1, sizeof sInstmp1, ";%s;", trim(IcurrPlyInsCheck->iins_type));
                       if (IcurrPlyInsCheck->mdamage_cover == 0)
                           printf("* IcurrPlyInsCheck->mdamage_cover == 0 -- \n");
                       else
                       {
                           if (strstr(IcurrPlyrule->iins_type1, sInstmp1))
                           {
                               /*printf("sInstmp1=[%s]IcurrPlyrule->minjured_cover=[%ld]\n ",sInstmp1,IcurrPlyrule->minjured_cover);*/
                               /*printf("�O�O [%ld]�O�B�@[%ld]�O�B�T[%ld]------------\n",IcurrPlyInsCheck->mins_premium,IcurrPlyInsCheck->minjured_cover,IcurrPlyInsCheck->mdamage_cover);*/

                               if ((IcurrPlyrule->minjured_cover > 0) &&(IcurrPlyInsCheck->minjured_cover > IcurrPlyrule->minjured_cover))
                               {
                                   Icount1 = Icount1 + 1;
                               }
                        
                           }
                       }
                       IcurrPlyInsCheck = IcurrPlyInsCheck->next;
                   }/* end �v�I�ؤ�� */
               
                   /* �D�W�h13 �ˮֵ��G -------------------------------------------- */
                   if (Icount1 < 1)
                       strcpy(sCheck_rule, "Y");  /* �ŦX�W�h */
                   else if (strlen(IcurrPlyrule->nexception) > 2)
                   {  
                       /* call �ҥ~�B�z */
                       rc1 = chk_exception(IcurrPlyrule->nexception);
                       if (rc1 != SUCCESS)
                       {
                           sprintf_s(tmp_sMsg, sizeof tmp_sMsg, "�ˮֳW�h %d �ҥ~�B�z���~!", IcurrPlyrule->irule);
                           strcpy(v_sMsg,tmp_sMsg);
                           return M_CA_CHKRULE;
                       }
                   }
   
                   if (strcmp(sCheck_rule,"N") == 0 )
                   {
                       if (strcmp(IcurrPlyrule->frule,"E") == 0)
                       {
                           /* ���_, �^�ǿ��~�T�� */
                           strcpy(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                           strcpy(v_sMsg,tmp_sMsg);
                           return M_CA_CHKRULE;
                       }
                       else
                       {
                           strcat(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                           strcpy(sNeed_mcheck,"Y"); /* ���H�u�֫O */
                       }
                   }
               }/* end �ȱj��ˮ� modify by sylvia 100.10.11 */
               break;/* end �D�W�h13 -----------------------------------------*/
            
           case 14:  /* �D�W�h14: �D���ϴ�(38,39�I��)�M���ˮ�(���W�h������t�ή֫O) ---------- */         	
               
               if ((iInstype1+iInstype2) > 0) /* �ȱj��ˮ� */
               {  
                
                   /* 104.10.26 fix:�p�Grule���]�w���ءA�����ŦX���ر���~�ˮ� */              	
         	   if( (strlen(IcurrPlyrule->icar_type)<3)             ||   /* �S���]�w���ر��󤺮e     */
         	       (strstr(IcurrPlyrule->icar_type, sIcarTypetmp)) )    /* �]�w���e�� "����"        */ 
         	   { 	
		       char *icar_type_p,*nexception_p;
		       char  icar_type[2][1][101] = {" " ," " };
		       char  nexception[2][1][31] = {" " ," " };
		       int  i ;               
                    	 
         	       icar_type_p = strtok(IcurrPlyrule->icar_type,"|") ;       /* ex. ;03;21;22;04;19;9A;9B;2B;2C;4A;8A;|;07;08;15; */					
         	        
                       i = 0;  
                         	    	
		       while(icar_type_p != NULL)
		       {
		       	   /* => icar_type[0][0] = ";03;21;22;04;19;9A;9B;2B;2C;4A;8A;" */
			   strcpy(icar_type[i][0] ,icar_type_p);
			   i++;
			   icar_type_p = strtok(NULL,"|");         /* => icar_type[1][0] = ";07;08;15;" */
		       }	         	   
	               /*printf("irule_main=[%d] irule = [%d] [%s][%s]�D���ϴ�(38,39�I��)�M���ˮ�\n",iIrule_main,IcurrPlyrule->irule, IcurrPlyrule->iins_type1,IcurrPlyrule->iins_type2);
	                 printf("-- trace icar_type[0][0][%s]\n ",icar_type[0][0]); 	
	                 printf("-- trace icar_type[1][0][%s]\n ",icar_type[1][0]); */	       
	               Icount1 = 0;Icount2 = 0;
	               mprem3000 = 0;mprem1300=0;
	                                                            
	               IcurrPlyInsCheck = IfirstPlyInsCheck;
	               
	               /* �v�I�ؤ�� -------------------------------------------------- */
	               while (IcurrPlyInsCheck)
	               {
	                   sprintf_s(sInstmp1, sizeof sInstmp1,";%s;", trim(IcurrPlyInsCheck->iins_type));
			   /* 1080115004-SC1-E�O�����N�I�O�O�n�����M�׫O�O�ӧP�_38.39�I */
			   if ((strlen(RUL_OP->op_free_ins) > 2) && (strstr(sInstmp1, RUL_OP->op_free_ins)))
			   {
			       /*printf("1080115004-SC1-E�O�����N�I�O�O�n�����M�׫O�O�ӧP�_38.39�I\n");
				 printf("sInstmp1=[%s]\n",sInstmp1);
				 printf("RUL_OP->op_free_ins=[%s]\n",RUL_OP->op_free_ins);*/
			   }
			   else
			   {
			       if (IcurrPlyInsCheck->mdamage_cover == 0)
			           printf("* IcurrPlyInsCheck->mdamage_cover == 0 -- \n");
			       else
			       {
				   if ((strcmp(sInstmp1,";50;") !=0) && (strcmp(sInstmp1,";21;") !=0)
					&& (strcmp(sInstmp1,";39;") !=0) && (strcmp(sInstmp1,";38;") !=0))
				   {
				       mprem3000 = mprem3000+ IcurrPlyInsCheck->mins_premium; /* ���榩��50+21+39+38�O�O */
				   }
								
				   if ((strcmp(sInstmp1,";55;") ==0) || (strcmp(sInstmp1,";56;") ==0)
					|| (strcmp(sInstmp1,";79;") ==0) || (strcmp(sInstmp1,";80;") ==0))
				   {
				       mprem1300 = mprem1300+ IcurrPlyInsCheck->mins_premium;	/* �֥[55+56+79+80�O�O */
				   }
								
				   if ((strncmp(sOfficer,"R",1)==0) &&(strncmp(sOfficer+6,"C",1)==0)
					&& (strcmp(sInstmp1,";89;") ==0))
				   {
				       mprem1300 = mprem1300+ IcurrPlyInsCheck->mins_premium; /* �g���1�X=R & ��7�X=C, �֥[55+56+79+80+89�O�O */
				   }	   
				   /*printf("sInstmp1=[%s]mprem1300=[%ld]mprem3000=[%ld]\n",sInstmp1,mprem1300,mprem3000);*/
				   if (strstr(IcurrPlyrule->iins_type1, sInstmp1))
				   {
				       Icount1 = Icount1 + 1;	/* ���ӫO38�I�� */
				   }
				   
				   if (strstr(IcurrPlyrule->iins_type2, sInstmp1))
				   {
				       Icount2 = Icount2 + 1;	/* ���ӫO39�I�� */
				   }
			       }
			   }
	                   IcurrPlyInsCheck = IcurrPlyInsCheck->next;
	               } /* end �v�I�ؤ�� */	               
	               
	               Icount3 = 0; 
	               
	               /* �D�W�h14 �ˮֵ��G -------------------------------------------- */
	               /*printf("Icount1=[%d]Icount2=[%d]mprem1300=[%ld]mprem3000=[%ld]\n",Icount1,Icount2,mprem1300,mprem3000);*/
	               if ((Icount1+Icount2) > 0)
	               {
	               	   strcpy(sCheck_rule, "N");  
	               	    
	               	   if (strstr(icar_type[0][0], sIcarTypetmp)) /* ";03;21;22;04;19;9A;9B;2B;2C;4A;8A;"  */
	               	   {	               	
			       if (Icount1 > 0) /* ��38�I��*/
			       { 	
			           if (strstr(icar_type[0][0], sIcarTypetmp))
			           {	
				       if ((mprem3000 >= 3000 ) || (mprem1300 >= 1300 ))
				       {
				           /* ���ӫO38�I��,�B�ŦX�O�O�ˮֱ���:ĵ�i */
				           strcpy(IcurrPlyrule->frule,"W");
				           strcpy(IcurrPlyrule->nmessage,"�������w�ɦ�������Q�K�O�D���ϴ��A�ȡA�нT�{�O�_�������λ��U����Q�ݨD��A�A���O38�I��(��Q�����W�d�Ш����q�����T��)�C;");
				       }
				       else
				       {
				           strcpy(IcurrPlyrule->frule,"W");
				           strcpy(IcurrPlyrule->nmessage," ");				               			
				       }
			           }
			       }
			       else   /* �L38�I�� , ��39�I�� */
			       {                                
			           if ((mprem3000 >= 3000 ) || (mprem1300 >= 1300 )) /* �ŦX�O�O�ˮֱ���:ĵ�i */
			           {			               			
			               strcpy(IcurrPlyrule->frule,"W");
			               strcpy(IcurrPlyrule->nmessage,"�������w�ɦ�������Q�K�O�D���ϴ��A�ȡA�i��W��O39�I�ءA�Y�ĥ����λ��U����Q�̶������O38�I��(��Q�����W�d�Ш����q�����T��)�C;");			               			
			           }
			           else
			           {
			               /* ���ӫO39�I��,���ŦX�O�O�ˮֱ���:���_�{��,�Y�ˮ֪��W�h�ΰT�� */
			               /* strcpy(IcurrPlyrule->frule,"E");
			               strcpy(IcurrPlyrule->nmessage,"�����ݥ��ӫO38�I�عD���ϴ��򥻫��l�i�[�O39�I�عD���ϴ��O�٫��A�p���S�����p�Ь��ӫO���Ĳ��`��B�z�C;"); */			               			
			               Icount3 = 1; /* ���P�_���L�ҥ~ => ;89_1; */
			           }
			       }
			   } 
			   else if (strstr(icar_type[1][0], sIcarTypetmp))  /* ";07;08;15;" */
			   {
			       if (Icount1 == 0) /* �L38�I�� , ��39�I��*/
			       {       			
		                   strcpy(IcurrPlyrule->frule,"E");		               			
		               	   Icount3 = 2; /* ���P�_���L�ҥ~  => ;89_2; */
			       }
		               else
		               {
		                   strcpy(IcurrPlyrule->frule,"W");
		               	   strcpy(IcurrPlyrule->nmessage," ");	
		               }			               	
			   }	

                           if ((Icount3>0)&&(strcmp(sCheck_rule,"N") == 0 )&&(strlen(IcurrPlyrule->nexception) > 2))
                           {	
		               /* call �ҥ~�B�z */		                    	 
		               nexception_p = strtok(IcurrPlyrule->nexception,"|") ;       /* ex. ;89_1;|;89_2; */					
		         	        
		               i = 0;    	    	
			       while(nexception_p != NULL)
			       {                  
			       	   /* => nexception[0][0] = ";89_1;" */
				   strcpy(nexception[i][0] ,nexception_p);
				   i++;
				   nexception_p = strtok(NULL,"|");         /* => nexception[1][0] = ";89_2;" */
			       }    	   
			       /*printf("-- trace nexception[0][0][%s]\n ",nexception[0][0]); 	
			         printf("-- trace nexception[1][0][%s]\n ",nexception[1][0]); 	   
			         printf("-- trace Icount3[%d]\n ",Icount3); */	   
	               		                  
		               rc1 = chk_exception(nexception[Icount3-1][0]);  /* �̭��i��|�ܧ� sCheck_rule �� */
		               if (rc1 != SUCCESS)
		               {
		                   sprintf_s(tmp_sMsg, sizeof tmp_sMsg, "�ˮֳW�h %d �ҥ~�B�z���~!", IcurrPlyrule->irule);
		                   strcpy(v_sMsg,tmp_sMsg);
		                   return M_CA_CHKRULE;
		               }
			   }   	
			            	               
		           if (strcmp(sCheck_rule,"N") == 0 )
		           {    	               	         
			       if (strcmp(IcurrPlyrule->frule,"E") == 0)
			       {
			           /* ���_, �^�ǿ��~�T�� */
			           strcpy(tmp_sMsg, trim(IcurrPlyrule->nmessage));
			           strcpy(v_sMsg,tmp_sMsg);
			           return M_CA_CHKRULE;
			       }
			       else
			           strcat(tmp_sMsg, trim(IcurrPlyrule->nmessage));
			   }      
	               }
                   }
               }/* end �ȱj��ˮ� modify by sylvia 103.01.22 */
            
               break;   /* end �D�W�h14 -----------------------------------------*/

           case 15:  /* �D�W�h15: iins_type1 �P �Diins_type 1 �]iins_type2���~�^���i�P�ɩӫO ------- */
           
               if ((iInstype1+iInstype2) > 0) /* �ȱj��ˮ� modify by sylvia 100.10.11 */
               { 
                   /*printf("irule_main=[%d] irule = [%d]:�I��[%s]�P�D�I��[%s]���i�P�ɩӫO\n",iIrule_main,IcurrPlyrule->irule, IcurrPlyrule->iins_type1, IcurrPlyrule->iins_type1);*/
                   Icount1 = Icount2 = 0;
                   IcurrPlyInsCheck = IfirstPlyInsCheck;
               
                   /* �v�I�ؤ�� -------------------------------------------------- */
                   while (IcurrPlyInsCheck)
                   {
                       sprintf_s(sInstmp1, sizeof sInstmp1, ";%s;", trim(IcurrPlyInsCheck->iins_type));
                       /*printf("** ply_ins_type=[%s]\n",sInstmp1);*/
                       if (IcurrPlyInsCheck->mdamage_cover == 0)
                           printf("** IcurrPlyInsCheck->mdamage_cover == 0 -- \n");
                       else
                       {
                           if (strstr(IcurrPlyrule->iins_type1, sInstmp1))
                           {
                               Icount1 = Icount1 + 1; 
                           }
                           else
                           {
                     	       /* 140407003_C1_�ӽзs�ӫ~�@�~-���ľ��c�q�~�H���T����X�O�I(104.11.11) */ 
                     	       if (!strstr(IcurrPlyrule->iins_type2, sInstmp1))
                     	       {
                                   Icount2 = Icount2 + 1;
                               }    
                           }
                       }
                  
                       IcurrPlyInsCheck = IcurrPlyInsCheck->next;
                   }/* end �v�I�ؤ�� --------------------------------------------- */
               
                   /* �D�W�h15 �ˮֵ��G -------------------------------------------- */
                   if ((Icount1 == 0) || (Icount2 == 0))
                       strcpy(sCheck_rule, "Y");
                   else if (strlen(IcurrPlyrule->nexception) > 2)
                   {  
                       /* call �ҥ~�B�z */
                       rc1 = chk_exception(IcurrPlyrule->nexception);
                       if (rc1 != SUCCESS)
                       {
                           sprintf_s(tmp_sMsg, sizeof tmp_sMsg, "�ˮֳW�h %d �ҥ~�B�z���~!", IcurrPlyrule->irule);
                           strcpy(v_sMsg,tmp_sMsg);
                           return M_CA_CHKRULE;
                       }
                   }
                           
                   if (strcmp(sCheck_rule,"N") == 0 )
                   {  
                       /* ���ųW�h */
                       if (strcmp(IcurrPlyrule->frule,"E") == 0)
                       {
                           /* ���_, �^�ǿ��~�T�� */
                           strcpy(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                           strcpy(v_sMsg,tmp_sMsg);
                           return M_CA_CHKRULE;
                       }
                       else
                       {
                           strcat(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                           strcpy(sNeed_mcheck,"Y"); /* ���H�u�֫O */
                       }
                   }
               }/* end �ȱj��ˮ�  */   
               break;  /* end �D�W�h15 ----------------------------------------- */ 
                          
           case 16: /* 1070803004-SC1-28�I�رư����� �S�w�I�ؤ��}��S�w���ةӫO*/
        
               IcurrPlyInsCheck = IfirstPlyInsCheck;
               /* �v�I�ؤ�� -------------------------------------------------- */
               strcpy(ChkRuleInsType, " ");
               /*printf("car_type19=[%d]sIcarTypetmp=[%s]\n",car_type19,sIcarTypetmp);*/
               while (IcurrPlyInsCheck)
               {
                   itmp=0;
                   /*printf("IcurrPlyrule->irule=[%d][%d]\n",iIrule_main, IcurrPlyrule->irule);*/
                   if (IcurrPlyInsCheck->mdamage_cover == 0)
                       printf("*** IcurrPlyInsCheck->mdamage_cover == 0 -- \n");
                   else
                   {
                       sprintf_s(sInstmp1, sizeof sInstmp1, ";%s;", trim(IcurrPlyInsCheck->iins_type));
                       if ( strstr(IcurrPlyrule->iins_type1, sInstmp1) && strstr(IcurrPlyrule->icar_type, sIcarTypetmp))
                       {
                           strcpy(sCheck_rule,"Y"); 
                           strcpy(ChkRuleInsType, trim(IcurrPlyInsCheck->iins_type));
                           /*printf("--- ChkRuleInsType=[%s] ----\n",ChkRuleInsType);*/
                           break;
                       }
                   }
                   itmp++;
                   if (strcmp(sCheck_rule,"Y") == 0 ) break;
                   IcurrPlyInsCheck = IcurrPlyInsCheck->next;
               }/* end �v�I�ؤ�� -------------------------------------------- */
           
               /* call �ҥ~�B�z */
               rc1 = chk_exception(IcurrPlyrule->nexception);
               if (rc1 != SUCCESS)
               {
                   sprintf_s(tmp_sMsg, sizeof tmp_sMsg, "�ˮֳW�h %d �ҥ~�B�z���~!", IcurrPlyrule->irule);
                   strcpy(v_sMsg,tmp_sMsg);
                   return M_CA_CHKRULE;
               }
           
               if (strcmp(sCheck_rule,"Y") == 0 )
               { 
                   /* ���ųW�h */
                   if (strcmp(IcurrPlyrule->frule,"E") == 0)
                   {
                       /* ���_, �^�ǿ��~�T�� */
                       if (strstr(tmp_sMsg, trim(IcurrPlyrule->nmessage)) == NULL)
                       {
                           strcpy(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                           strcpy(v_sMsg,tmp_sMsg);
                       }
                 
                       return M_CA_CHKRULE;
                   }
                   else
                   {
                       if (strstr(tmp_sMsg, trim(IcurrPlyrule->nmessage)) == NULL)
                           strcat(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                 
                       strcpy(sNeed_mcheck,"Y"); /* ���H�u�֫O */
                   }
               }
               break;
               
           case 17: /* 1070928002-SC1-�s�W�O�I�����ܧ�Τ��~�פ���[����(���I���[�γ������[)*/
        
               IcurrPlyInsCheck = IfirstPlyInsCheck;
               /* �v�I�ؤ�� -------------------------------------------------- */
               Icount1=0;
               Icount2=0;
               /*printf("irule_main=[%d] irule = [%d]:-[%s]**[%s]**[%s]sData_chk[%s]\n",iIrule_main,IcurrPlyrule->irule, IcurrPlyrule->provision, IcurrPlyrule->iins_type1, IcurrPlyrule->iins_type2,sData_chk);*/
               iChkCount = 0; iChkRate = 0 ;/*  1081205009-SC1-��ã��-�t�X47�I�رq�D�I�אּ���[�I */
               if (strlen(trim(IcurrPlyrule->nexception)) > 2)
               {
                   iChkRate  = atoi(IcurrPlyrule->nexception);
                   /*printf("sColumn_chk[%s]�¸պ�S��table�i�d�ߡAcar301�պ�ǤJ�O�v�a�JiChkCount[%d]nexcep[%d]\n",sColumn_chk,iChkCount,iChkRate);*/
                   strcpy(stmt," ");
                   if (strcmp( sColumn_chk, "ipolicy") == 0)
                   {
                       sprintf_s( stmt, sizeof stmt, "select count(*) \n"
                                                     "  from %s ply_relation a ,%s ply_ins_type b\n"
                                                     " where a.ipolicy = '%s' and a.ipolicy = b.ipolicy \n"
                                                     "   AND b.drate_ym::int >= %d"
                                                     "   AND b.iins_type = '%s'"
                                                     "   AND b.mdamage_cover > 0 ;\n" , sdbname_chk,sdbname_chk, sData_chk,iChkRate ,trim(IcurrPlyrule->iins_type1) );
                   }
                   else if (strcmp( sColumn_chk, "iestimate") == 0)
                   {
                       sprintf_s( stmt, sizeof stmt, "select count(*) "
                                                     "  from %s estimate a , %s est_ins_type b\n"
                                                     " where a.iestimate = '%s' and a.iestimate=b.iestimate \n"
                                                     "   AND b.drate_ym::int >= %d"
                                                     "   AND b.iins_type = '%s' " 
                                                     "   AND b.mdamage_cover > 0 ;\n" , sdbname_chk,sdbname_chk, sData_chk,iChkRate ,trim(IcurrPlyrule->iins_type1) );
                   }
                   else
                   {
                       /* �¸պ�S��table�i�d�ߡAcar301�պ�ǤJ�O�v->iChkCount�a�J �A�Pnexception�]�w->iChkRate���*/
                       iChkCount = atoi(sColumn_chk);
                       /*printf("iChkCount[%d]nexcep[%d]\n",iChkCount,iChkRate);*/
                       if (iChkCount < iChkRate) 
                       {
                           iChkCount = 0; 
                       }
                       else
                       {
                           iChkCount = 1; /* ���ˮ�iins_type1*/   
                       }
                   }
                
                   if ((strlen(trim(sColumn_chk))>0) && (strlen(trim(stmt)) >0))
                   {
                       /*printf("case 17:stmt[%s]\n", stmt);*/
                       $PREPARE pre_case17_chk FROM $stmt;
                       $EXECUTE pre_case17_chk INTO $iChkCount;
                       if( SQLCODE == SQLNOTFOUND)
                       {
                           $FREE pre_case17_chk;
                       }
                       $FREE pre_case17_chk;
                   }
               }
            
            
            
               while (IcurrPlyInsCheck)
               {
                   strcpy(stmt," ");
                   strcpy(sProvision_tmp," ");
                   if (IcurrPlyInsCheck->mdamage_cover != 0)
                   {
                       /*1081225006-SC1-���ά�-�X�R���[���ڥN�X*/
                       strcpy(sChkProvision,IcurrPlyInsCheck->provision);
                       /*printf("IcurrPlyInsCheck->provision[%s]\n",IcurrPlyInsCheck->provision);
                         printf("              sChkProvision[%s]\n",sChkProvision); */                       
                       itmp=0;
                       Icount1++;
                       /*printf("17-0-IcurrPlyInsCheck->iins_type[%s]\n",IcurrPlyInsCheck->iins_type);*/
                       strcpy(sProvDelimiter," ");
                       sChkProvTok = strtok(sChkProvision,";");                    
                       while (sChkProvTok )/*while(IcurrPlyInsCheck->provision[itmp])*/
                       {
                           /*printf("sChkProvTok[%s]\n",sChkProvTok);*/
                           sprintf_s(sProvDelimiter, sizeof sProvDelimiter,";%s;",trim(sChkProvTok));
                           /*printf("sProvDelimiter[%s]\n",sProvDelimiter);*/

                           if (IcurrPlyInsCheck->mdamage_cover == 0)
                           {
                               printf("17-2 IcurrPlyInsCheck->mdamage_cover == 0 -- \n");
                           }
                           else
                           {
                               /*printf("17-3 trace sProvision_tmp[%s]\n",sProvision_tmp);*/
                               if (strstr(IcurrPlyrule->provision, sProvDelimiter))
                               {
                                   Icount2++;
                                   /*printf("17-4--Icount2[%d]\n",Icount2);*/
                               }
                           }
                           itmp++;
                      
                           sChkProvTok = strtok(NULL,";");
                       }
                   }
                
                   IcurrPlyInsCheck = IcurrPlyInsCheck->next;
                
               } /* end �v�I�ؤ�� -------------------------------------------- */
               
               /*
                Icount1:�Ҧ��I�ئU��
                Icount2:�����w���[�I���Ӽ�
                iChkCount:�S�w�ư������@�_���[���Ӽ�
               */
               /*printf("17-8--Icount1!=Icount2[%d][%d][%d]\n",Icount1,Icount2,iChkCount);*/
               if ((strcmp(IcurrPlyrule->frule,"E") == 0) && Icount2 > 0)
               {
                
                   /*printf("17-9--sVabntype[%s]\n",sVabntype);*/
                   if ((Icount1!=Icount2))  /*  1070814003-SC1-��ã��-�ק�R�����ˮ�(�t���s�BE�O���BB2B) */
                   {
                       if (iChkCount > 0)
                       {
                           if (Icount1 != (Icount2+iChkCount))
                           {
                               /* ���_, �^�ǿ��~�T�� */
                               strcpy(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                               strcpy(v_sMsg,tmp_sMsg);
                               return M_CA_CHKRULE;
                           }
                       }
                       else
                       {
                           /* ���_, �^�ǿ��~�T�� */
                           strcpy(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                           strcpy(v_sMsg,tmp_sMsg);
                           return M_CA_CHKRULE;
                       }
                   }
                
               }
               else if (Icount2 > 0)
               {
                   printf("=========Icount2[%d]======\n",Icount2);
                   if (strstr(tmp_sMsg, trim(IcurrPlyrule->nmessage)) == NULL)
                       strcat(tmp_sMsg, trim(IcurrPlyrule->nmessage));
                   strcpy(sNeed_mcheck,"Y"); /* ���H�u�֫O */
               }
               printf("17---Icount1[%d]Icount2[%d]\n",Icount1,Icount2);
               break;
       }
       IcurrPlyrule = IcurrPlyrule->next;
   }/* �ˮֵ��� */
  
   while (IfirstPlyInsCheck != NULL)
   {                                /* free ñ����ˮ֤��e */
       IcurrPlyInsCheck=IfirstPlyInsCheck;
       IfirstPlyInsCheck=IcurrPlyInsCheck->next;
       free(IcurrPlyInsCheck);
   }
  
   while (IfirstPlyrule != NULL)
   {                                /* free �ˮ֪����e */
       IcurrPlyrule=IfirstPlyrule;
       IfirstPlyrule=IcurrPlyrule->next;
       free(IcurrPlyrule);
   }
   printf("***********************************************************************\n");
   printf("*****sNeed_abn=[%s]sNeed_mcheck=[%s]\n",sNeed_abn,sNeed_mcheck);
   strcpy(RUL_OP->op_need_abn, sNeed_abn);												/* ���H���`��f�� */
   strcpy(RUL_OP->op_need_mcheck, sNeed_mcheck);										/* ���H�u�֫O */
   printf("RUL_OP->op_need_abn=[%s]\n",RUL_OP->op_need_abn);
   printf("RUL_OP->op_need_mcheck=[%s]\n",RUL_OP->op_need_mcheck);
  
   strcpy(v_sMsg, tmp_sMsg);
   end_chk_ply_rule(v_sMsg);
  
   return M_CM_OK;

errexit:
   sprintf_s( tmp_sMsg, sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
   strcpy(v_sMsg, tmp_sMsg);
   end_chk_ply_rule( v_sMsg);
   return SQLCODE;
}

void end_chk_ply_rule(v_sMsg)
char *v_sMsg;
{
   printf("     v_sMsg[%s]\n", v_sMsg);
   puts("end chk_ply_rule function");
   puts("******************************");
   puts("");
}

/* �ҥ~�B�z add by sylvia 100.10.12 ----------------------------------------- */
int chk_exception(sException)
char *sException;
{
   $char TmpSql[1000],sTmp[11]=" ";
   $int ExCount;
   $char stmt[2000];
	 
   $WHENEVER SQLERROR GOTO errexit;
   /* �ҥ~�N�X:01 �M�ץ�ҥ~(W�g��ҥ~)*/
   /* �M�ץ�[�JM�g��,�B����M0��M9) add by sylvia 102.12.11 (1021122001_C1) */
   if (strstr(sException,";01;"))
   {
       /*printf("01:sException=[%s]sOfficer=[%s]\n",sException,sOfficer);*/
       if (strncmp(sOfficer, "W", 1 ) == 0 || strncmp(sOfficer, "N", 1 ) == 0)
       {
           strcpy(sCheck_rule, "Y");  /* �ŦX�W�h */ 
           return SUCCESS;
       }
       else
       {
      	   if (strncmp(sOfficer, "H", 1 ) == 0) 
      	   {
      	       if ((strncmp(sOfficer, "H0", 2 ) != 0) && (strncmp(sOfficer, "H1", 2 ) != 0) && (strncmp(sOfficer, "H2", 2 ) != 0))
      	       {
      	           strcpy(sCheck_rule, "Y");  /* �ŦX�W�h */ 
            	   return SUCCESS;
      	       }
      	   }
       }
   }/* end �ҥ~�N�X:01 */
   
   /* �ҥ~�N�X:B01 B2B�ҥ~1(B*��J*�g��,19����,�O31,32�I��,���[D����,��ĵ�i,�����U���`)*/
   /* add by sylvia 102.10.29 (1020625001_C1) */
   if (strstr(sException,";B01;"))
   {
       /*printf("B01:sException=[%s]sOfficer=[%s]\n",sException,sOfficer);*/
       if ((strncmp(sOfficer, "B", 1 ) == 0) || (strncmp(sOfficer, "J", 1 ) == 0))
       {
           if ((car_type19 > 0) && (ins_type3132 > 0))
      	   {
	       strcpy(IcurrPlyrule->frule, "W");  /* �uĵ�i,�����_�{�� */ 
	       strcpy(IcurrPlyrule->nmessage,"����:�S�w���ة��I�ػݸg�ӫO���ӮצP�N���i���[D����;");
	       return SUCCESS;
	   }
       }
   }/* end �ҥ~�N�X:B01 */
   
   /* �ҥ~�N�X:03==�ˮ֬O�_��car140 kind=31 ���]�w���I�θg��N�� */
   /* add by sylvia 102.11.11 (1021108001_C1) */
   if (strstr(sException,";03;"))
   {
       /*printf("03:sException=[%s]sOfficer=[%s]\n",sException,sOfficer);*/
       $select count(*) into $ExCount
          from car_code
         where kind = '31'
           and detail2 = $sOfficer
           and trim(detail) = $ChkRuleInsType;
      
       if (ExCount > 0)
       {
           strcpy(IcurrPlyrule->frule, "W");  /* �uĵ�i,�����_�{�� */ 
           return SUCCESS;
       }    
      
   }  

   /* �D���ϴ�(38,39�I��)�ҥ~���p */ 
   if (strstr(sException,";89_1;"))
   {   	 
       /*printf("03:sException=[%s]\n",sException);
       printf("89_1:sIroute=[%s]sOfficer=[%s]\n",sIroute,sOfficer);*/

       ExCount = 0;
       $select count(*) into $ExCount from car_code
	 where kind = '89' and detail ='1' 
	   and $sIlicense matches decode(trim(detail2),'','*',detail2) and $sOfficer matches decode(trim(chiname),'','*',chiname)
	   and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);
       /*printf("--1 trace ExCount[%d]\n ",ExCount);*/	       	
       if (ExCount==0)
       {
           $select count(*) into $ExCount from car_code
	     where kind = '89' and detail ='2' 
	       and $sIlicense matches decode(trim(detail2),'','*',detail2) and $sIroute matches decode(trim(chiname),'','*',chiname)
	       and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);	   	
	   printf("--2 trace ExCount[%d]\n ",ExCount);	       	
       }
      
       if (ExCount > 0)
       {
           strcpy(sCheck_rule, "Y");  /* �ŦX�W�h */ 
           return SUCCESS;
       }    
      
   }
   else if (strstr(sException,";89_2;"))   	
   {
       /*printf("03:sException=[%s]\n",sException);
       printf("89_2:sIroute=[%s]sOfficer=[%s]\n",sIroute,sOfficer);*/

       ExCount = 0;
       $select count(*) into $ExCount from car_code
	 where kind = '89' and detail ='A' 
	   and $sIlicense matches decode(trim(detail2),'','*',detail2) and $sOfficer matches decode(trim(chiname),'','*',chiname)
	   and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);
       /*printf("--A trace ExCount[%d]\n ",ExCount);   */ 	
       if (ExCount==0)
       {
           $select count(*) into $ExCount from car_code
	     where kind = '89' and detail ='B' 
	       and $sIlicense matches decode(trim(detail2),'','*',detail2) and $sIroute matches decode(trim(chiname),'','*',chiname)
	       and (trim(engname) = '' or nvl(engname::date,'12/31/2099'::date) > today);	   	
	   printf("--B trace ExCount[%d]\n ",ExCount);    	     	
       }
      
       if (ExCount > 0)
       {
           strcpy(sCheck_rule, "Y");  /* �ŦX�W�h */ 
           return SUCCESS;
       }    	
   }
   
   if  (strstr(sException,"ilast_ply")) /* 1070531004-SC1-��ã��-�ק���sCAR301�A09+162��05+161��O���ˮ�*/
   {
       /*printf("ilast_ply:sException=[%s]sData_chk[%s]\n",sException,sData_chk);
       printf("          ChkRuleInsType[%s]lngInsCover[%ld]\n",ChkRuleInsType,lngInsCover);*/
        
       if ((strlen(sdb_chk) == 0) && strlen(trim(sData_chk)) > 0)
       {   
           /* EX: 6-97 �W�[�P�_��162���O�B�B�׻P�h�~�p��άۦP�ɡA�h�����ˮֲ��`��@�~'*/
           strcpy(tmp_fulldb,get_car_full_db(sData_chk));
           /*printf("�O�O�p��Ltable�����ǤJ�e�渹[%s]tmp_fulldb[%s]\n",sData_chk,tmp_fulldb);*/
           sprintf_s( stmt, sizeof stmt, "select count(*) \n"
                                         "  from %s:ply_ins_type a \n"
                                         " where a.ipolicy = '%s'\n"
                                         "   AND iins_type = '%s' "
                                         "   AND mdamage_cover > 0 "
                                         "   AND %d  <= mdamage_cover \n", tmp_fulldb, sData_chk , ChkRuleInsType, lngInsCover);
       }
       else
       {
           printf("��table�����渹\n");
           if (strcmp( sColumn_chk, "ipolicy") == 0)
           {
               sprintf_s( stmt, sizeof stmt, "select count(*) \n"
                                             "  from %s ply_relation a \n"
                                             " where a.ipolicy = '%s'\n"
                                             "   AND %d  <= (SELECT sum(b.mcover3) \n"
                                             "  FROM policy_main_dtl b \n"
                                             " WHERE b.insure_instype = '%s'"
                                             "   and b.mcover3 > 0 \n"
                                             "   AND a.ilast_ply = b.ipolicy1 )\n", sdbname_chk, sData_chk, lngInsCover , ChkRuleInsType);
           }
           else if (strcmp( sColumn_chk, "iestimate") == 0)
           {
                sprintf_s( stmt, sizeof stmt, "select count(*) \n"
                                              "  from %s estimate a \n"
                                              " where a.iestimate = '%s'\n"
                                              "   AND %d  <= (SELECT sum(b.mcover3) \n"
                                              "  FROM policy_main_dtl b \n"
                                              " WHERE b.insure_instype = '%s'"
                                              "   and b.mcover3 > 0 \n"
                                              "   AND a.ilast_ply = b.ipolicy1 )\n", sdbname_chk, sData_chk, lngInsCover , ChkRuleInsType);
           }
            
       }
       /*printf("0:stmt[%s]\n", stmt);*/
       $PREPARE pre_ply_ins_chk FROM $stmt;
       $EXECUTE pre_ply_ins_chk INTO $ExCount;
       if( SQLCODE == SQLNOTFOUND)
       {
           $FREE pre_ply_ins_chk;
       }
       $FREE pre_ply_ins_chk;
        
       printf("ExCount[%d]\n",ExCount);
       if (ExCount > 0)
       {
           strcpy(sCheck_rule, "Y");  /* �ŦX�W�h */ 
           return SUCCESS;
       }
   }/* end �ҥ~�N�X:01 */  
   return SUCCESS;
   
errexit:
   printf("SQLCODE=%d\n",SQLCODE);
   return SQLCODE;
}

int chk_reject_client()
{
	
   $WHENEVER SQLERROR GOTO errexit;
   /* �ˮ֩ګO��� ------------------------------------------------------------- */
   printf(" �����������������������ˮ֩ګO��ơ���������������������������������\n");
   iFreson5083 = iFreson1 = iFreson2 = iFreson3 = iFreson4 = iFreson5 = iFreson6 =  0;
   iFreson7 = iFreson8 = iFreson9 = iFresonA = iFresonB = 0;
   /* 1061101005�s�W8.9�������ܰT��*/
   printf("sNassured=[%s]sIlicense=[%s]sItag=[%s]sIengine=[%s]sIbody=[%s]\n",sNassured,sIlicense,sItag,sIengine,sIbody);
    /* �ˮ�car102�]�w */
   /* 1070528003-SC1-�֫O�����ˮ֭ק�-�P�@�O��@�~�X�I�T��(�t)�H�W-P-car5083*/
   $select nvl(sum(decode(freason,'1',decode(icreate,'car5083',3,0),0)),0),
           nvl(sum(decode(freason,'1',1,0)),0), 
           nvl(sum(decode(freason,'2',1,0)),0),
           nvl(sum(decode(freason,'3',1,0)),0), 
           nvl(sum(decode(freason,'4',1,0)),0),
           nvl(sum(decode(freason,'5',1,0)),0),
           nvl(sum(decode(freason,'6',1,0)),0),
           nvl(sum(decode(freason,'7',1,0)),0),
           nvl(sum(decode(freason,'8',1,0)),0),
           nvl(sum(decode(freason,'9',1,0)),0),
           nvl(sum(decode(freason,'B',1,0)),0)  
      into $iFreson5083,$iFreson1, $iFreson2, $iFreson3, $iFreson4, $iFreson5, $iFreson6,
           $iFreson7, $iFreson8, $iFreson9, $iFresonB
      from reject_client
     where (dexpire is null or  dexpire > today)
       and ( nassured = case when trim(nassured)='' then NULL else $sNassured end
             or nassured = case when trim(nassured)='' then NULL else $sNapplicant end
             or ilicense = case when trim(ilicense)='' then NULL else $sIlicense end
             or ilicense = case when trim(ilicense)='' then NULL else $sIapplicant end
             or itag = case when trim(itag)='' then NULL else $sItag end
             or iengine = case when trim(iengine)='' then NULL else $sIengine end
             or ibody = case when trim(ibody)='' then NULL else $sIbody end);

   /* (���B���ϥζˮ`�W�U�ˮ�, �G����;�� Cal_ins_premium ()�����ˮ� )
	From: ��౻T 
	Sent: Wednesday, May 04, 2016 11:42 AM
	To: ���ӻ�
	Cc: ���ʱo
	����car102-hth103�ˮ�,���վ㬰���ˮֶˮ`�I�ӫ~,�ثe��48���W�U*/       
   /*1041117006_C1 �ˮ`�I�ګO���ˮ֭ק�(���� ireason[1,1] = 'A' WHERE ����)       
        hth103�]�w
        $select count(iassured) into $iFresonA
           from ot_refused_cus
          where iassured = $sIlicense;*/  
   iFresonA = 0;
   /*printf("�ګO���:iFreson1=[%d][%d]iFreson2=[%d]\n",iFreson5083,iFreson1,iFreson2);
   printf("�ګO���:iFreson3=[%d]iFreson4=[%d]\n",iFreson3,iFreson4);
   printf("�ګO���:iFreson5=[%d]iFreson6=[%d]\n",iFreson5,iFreson6);
   printf("�ګO���:iFreson7=[%d]iFresonA=[%d]\n",iFreson7,iFresonA);
   printf("�ګO���:iFreson8=[%d]iFreson9=[%d]\n",iFreson8,iFreson9);
   printf("�ګO���:iFresonB=[%d]\n",iFresonB);*/
   strcpy(chk_reject,"Y");
      
   return SUCCESS;
      
errexit:
   printf("SQLCODE=%d\n",SQLCODE);
   return SQLCODE;
}
