/*
   Name       : get_ca_truck_transport
   Purpose    : (1)�H �Q�O�I�HID�B�g��N���B�q���N���� [�O�v�ͮĤ�ذ_�O��]�B
                   [���Τ鬰NULL�άO���Τ�>�t�Τ�] ������A���o�̤j(�̱���_�O��)���u�O�v�ͮĤ�v
                (2)�A�� �Q�O�I�HID�B�g��N���B�q���N���ΤW�z���o���u�O�v�ͮĤ�v�A���o
                   �u�޲z���I�[��T�סv�Ρu�w�����I�[��T�סv

   Input      : v_iassured      �Q�O�I�HID
                v_iofficer      �g��N�� 
                v_iroute        �q���N�� 
                v_dply_begin    �O��ͮĤ�A��[�ɬ����ͮĤ�
                v_dpolicy       ñ���:�պ�B�n�O�B�X�欰�t�Τ�, ��欰�O��ñ���

    Output    : v_safe_rate     �w���[��O�T�סAex: -10
                v_manage_rate   �޲z�[��O�T�סAex: -10               
                v_sMsg          �T��

   return code: M_CM_OK         ���\

   
*/

#include "commsgs.h"
#include "carmsgs.h"
$include "var_length.h";
#include "safeclib.h"
void end_get_ca_truck_transport( );

long get_ca_truck_transport(char   *v_iassured, 
	                        char   *v_iofficer, 
	                        char   *v_iroute, 
	                        char   *v_dply_begin,
	                        char   *v_dpolicy,
	                        double *v_safe_rate,
	                        double *v_manage_rate,
	                        char   *v_sMsg)
{
  long     rtncode;
  $double  safe_rate = 0, manage_rate = 0;
  $char    iins_cat[IINS_CAT], iassured[IASSURED], iofficer[IOFFICER], iroute[21], dply_begin[DATE], dpolicy[DATE],tmp_sMsg[512];

    $WHENEVER SQLERROR GOTO errexit;

    puts("");
    puts("******************************");
    puts("begin get_ca_truck_transport function");
    printf("    v_iassured[%s], v_iofficer[%s],v_iroute [%s], v_dply_begin[%s], v_dpolicy[%s]\n", 
                v_iassured, v_iofficer,v_iroute, v_dply_begin,v_dpolicy );

    strcpy( iassured  , trim(v_iassured));
    strcpy( iofficer  , trim(v_iofficer));
    strcpy( iroute    , trim(v_iroute));
    strcpy( dply_begin, trim(v_dply_begin));
    strcpy( dpolicy   , trim(v_dpolicy));
    strcpy( tmp_sMsg, " ");
	
    if (strlen(dpolicy) == 0)
    		strcpy(dpolicy, cm_edate_str(cm_today()));
    		
    printf("dpolicy=[%s]\n ",dpolicy);

    $SELECT safe_rate ,manage_rate
       INTO $safe_rate , $manage_rate
       FROM ca_truck_transport
      WHERE iassured  = $iassured
        AND iofficer  = $iofficer
        AND iroute    = $iroute
        AND drate = (SELECT MAX(drate)
                       FROM ca_truck_transport
                      WHERE iassured  = $iassured
                        AND iofficer  = $iofficer
                        AND iroute    = $iroute
                        AND drate    <= $dply_begin
                        AND (dexpire is null or dexpire > $dpolicy))
        AND (dexpire is null or dexpire > $dpolicy);

    if(SQLCODE==SQLNOTFOUND)
    {
        sprintf_s( tmp_sMsg, sizeof tmp_sMsg,"    iassured[%s], iofficer[%s], iroute[%s],\n "
                         "    dply_begin[%s] not in table ca_truck_transport(car157 set)\n", 
                              iassured, iofficer, iroute, dply_begin);
        strcpy( v_sMsg, tmp_sMsg);
        end_get_ca_truck_transport( v_sMsg);
        return M_CA_TRUCK_TRANSPORT;
    }                

    sprintf_s( tmp_sMsg, sizeof tmp_sMsg,"Found safe_rate[%f], manage_rate[%f]\n", safe_rate, manage_rate);
    strcpy( v_sMsg, tmp_sMsg);
    *v_safe_rate   = safe_rate;
    *v_manage_rate = manage_rate;

    end_get_ca_truck_transport( v_sMsg);

    return M_CM_OK;

errexit:

  sprintf_s( tmp_sMsg,sizeof tmp_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy( v_sMsg, tmp_sMsg);
  end_get_ca_truck_transport( v_sMsg);
  return SQLCODE;

}

void end_get_ca_truck_transport( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_ca_truck_transport function");
  puts("******************************");
  puts("");
}
