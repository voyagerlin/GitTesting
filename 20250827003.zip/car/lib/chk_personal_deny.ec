/*
   Name       : chk_personal_deny
   Input      : v_iassured
   return code: M_CM_OK (�i�X��) , else (���i�X��)
   Output     : v_sMsg      �T�� (�Y"�����P", M_CM_OK ���|�^��"�����P"�����T�� )
*/

#include "commsgs.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
void end_chk_personal_deny( );

long chk_personal_deny( v_iassured, v_sMsg)
$char    *v_iassured, *v_sMsg;
{
  $int  iCount,rc;  
  $char sMsg[512]=" ",o_sFply_chk[2]=" ";

  $WHENEVER SQLERROR GOTO errexit;

  puts("");
  puts("***********************************");
  puts("begin chk_personal_deny");
  printf("     v_iassured=[%s]\n", v_iassured);

/*  
  iCount = 0;
  
  $select count(*) into $iCount
     from cm_personal_deny
    where iassured = $v_iassured
      and (funsale_ins[1,1] = '1' or funrenew_ins[1,1] = '1' or
           funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
      and ddeny <= today 
      and (dexpire is null or dexpire >= today);
      
  if (iCount == 0)
  {
      sprintf_s( v_sMsg, sizeof v_sMsg,"v_iassured[%s] �Ӹꥼ���� \n", v_iassured);
      end_chk_personal_deny( v_sMsg);
      return M_CM_OK;
  }    
  else
  {
      sprintf_s( v_sMsg,sizeof v_sMsg, "v_iassured[%s] �Ӹ�w���� \n", v_iassured);
      end_chk_personal_deny( v_sMsg);
      return M_CA_PERSONAL_DENY;
  }    
*/

  rc = cm_chk_personal(v_iassured, "C" , "*" , sMsg, o_sFply_chk);   /* cmfun2s.ec */
  strcpy(v_sMsg, sMsg);
      
  if (rc != M_CM_OK)
  {   	  
  	  end_chk_personal_deny( v_sMsg);
  	  return rc; 	
  }
  else /* M_CM_OK */
  {  	  
      if (o_sFply_chk[0]=='N')   /* ���i�X�� */
      {	 
      	  /* ��ܰT�� M_CA_PERSONAL_DENY */
      	  strcpy(v_sMsg, cm_get_errmsg(M_CA_PERSONAL_DENY));     
      	  end_chk_personal_deny( v_sMsg);
	      return  M_CA_PERSONAL_DENY;  /* 4616:�Q�O�I�H�Ӹ�w����ϥ� */
      }
      else /* �i�X�� */  
      {   
      	   end_chk_personal_deny( v_sMsg);   	  
      	  /*  ��ܰT�� cm_chk_personal()�^�Ǥ��T��(sMsg)
      	     Ex."�����P" sMsg �|�^�� "����Ӹ�w�ӽа���u��P�v�A�нT�{�C" */
      }
  }

  return M_CM_OK;

errexit:
  sprintf_s( sMsg, sizeof sMsg,"SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]); 
  strcpy(v_sMsg, sMsg);
  end_chk_personal_deny( v_sMsg);
  return SQLCODE;
}

void end_chk_personal_deny( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end chk_personal_deny function");
  puts("*********************************");
  puts("");
}

