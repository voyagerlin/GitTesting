/*
   Name       : get_privilege
   Purpose    : �� �ϥΪ̥N��(userid) �M �{���N��(ipgid) ��privilegeŪ�� data

   Input      : v_userid       �ϥΪ̥N��
                v_ipgid        �{���N��

   return code: M_CM_OK        ���\
                v_flevel       �ϥμh�� (�ثe�Ȭdflevel�A�Y�ݭn�i�s�W)
                v_sMsg         �T��
*/

#include "commsgs.h"
#include "carmsgs.h"
$include "var_length.h";
#include "safeclib.h"

void end_get_privilege( );

long get_privilege( char   *v_userid,
                    char   *v_ipgid,
                    int    *v_flevel,
                    char   *v_sMsg)
{
  long     rtncode;
  $int     flevel = 0;
  $char    userid[USERID], ipgid[IPGID], iupcomp[IUPCOMP], ibranch[IBRANCH], stmt[256];
  char     policyDBname[41];
  
  $char v_sMsg2[1000]; /* ���T����J���ɭԥΪ��Ȧs�}�C */

    $WHENEVER SQLERROR GOTO errexit;

    puts("");
    puts("******************************");
    puts("begin get_privilege function");
    printf("    v_userid[%s], v_ipgid[%s]\n", v_userid, v_ipgid);

    strcpy( userid,  v_userid);
    strcpy( ipgid, v_ipgid);

    $SELECT ibranch 
       INTO $ibranch
       FROM officer
      WHERE iofficer = $userid;

    if(SQLCODE==SQLNOTFOUND)
    {
        sprintf_s(v_sMsg2, sizeof v_sMsg2, "    userid not in table officer by userid[%s]\n", userid);
        /*sprintf_s(v_sMsg, sizeof v_sMsg, "    userid not in table officer by userid[%s]\n", userid);*/
        strcpy(v_sMsg, v_sMsg2);
        end_get_privilege( v_sMsg);
        return M_CA_NO_OFFICER;   /* �ϥΪ̵n�J��ID�b�g��H�ɧ䤣�� */ 
    }

    $SELECT iupcomp
       INTO $iupcomp
       FROM branch
      WHERE ibranch = $ibranch;

    if(SQLCODE==SQLNOTFOUND)
    {
        sprintf_s(v_sMsg2, sizeof v_sMsg2, "    ibranch not in table branch by ibranch[%s]\n", ibranch);
        /*sprintf_s(v_sMsg, sizeof v_sMsg, "    ibranch not in table branch by ibranch[%s]\n", ibranch);*/
        strcpy(v_sMsg, v_sMsg2);
        end_get_privilege( v_sMsg);
        return M_CA_NO_IUPCOMP;   /* �ϥΪ̵n�J��ID�b�g��H�ɳ]�w�����ݤ�����bcmn107�䤣�� */
    }

    strcpy( policyDBname, get_full_dbname( iupcomp));

    sprintf_s(stmt, sizeof stmt, "SELECT flevel"
                   "  FROM %s:privilege"
                   " WHERE iemp  = '%s' "
                   "   AND ipgid = '%s' ", policyDBname, userid, ipgid);
    printf("stmt[%s]\n", stmt);
    $PREPARE prep1 FROM $stmt;
    $EXECUTE prep1 INTO $flevel;

    if(SQLCODE==SQLNOTFOUND)
    {
        sprintf_s(v_sMsg2, sizeof v_sMsg2, "    flevel not in table privilege by userid[%s], ipgid[%s]\n", 
                              userid, ipgid);
        strcpy(v_sMsg, v_sMsg2);
        /*sprintf_s(v_sMsg, sizeof v_sMsg, "    flevel not in table privilege by userid[%s], ipgid[%s]\n", 
                              userid, ipgid);*/
        end_get_privilege( v_sMsg);
        $FREE prep1;
        return M_CA_NO_PRIVILEGE;   /* �ϥ��v���䤣�� */ 
    }
    $FREE prep1;

    *v_flevel = flevel;
    
    sprintf_s(v_sMsg2, sizeof v_sMsg2, "Found �ϥ��v�� (privilege.flevel)[%d]\n", flevel);
    strcpy(v_sMsg, v_sMsg2);
    /*sprintf_s(v_sMsg, sizeof v_sMsg, "Found �ϥ��v�� (privilege.flevel)[%d]\n", flevel);*/

    end_get_privilege( v_sMsg);

    return M_CM_OK;

errexit:
  sprintf_s(v_sMsg2, sizeof v_sMsg2, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
  strcpy(v_sMsg, v_sMsg2);
  /*sprintf_s(v_sMsg, sizeof v_sMsg, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);*/
  end_get_privilege( v_sMsg);
  return SQLCODE;

}

void end_get_privilege( v_sMsg)
char *v_sMsg;
{
  printf("     v_sMsg[%s]\n", v_sMsg);
  puts("end get_privilege function");
  puts("******************************");
  puts("");
}
