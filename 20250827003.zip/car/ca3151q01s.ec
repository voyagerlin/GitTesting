/*-------------------------------------------------------------------
 * Program: ca3151q01s.ec
 * Date   : 05/25/2005
 * Neo
 *-------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include <time.h>
#include <math.h>

$include datetime.h;
$include "ca3xxlib.h";
$include sqlca;
$include sqltypes;

#define  FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define  NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND

#define  PRINTF_FLAG;

/*****************************************************************/

int     checktime = 0;

$char   nname[21],office[11];
$char   plyyear[4],plymonth[3],db[3];
char    s_today[11], s_cur_yr[4], s_cur_mth[3];
$char   sfins[2];

$char   stmt[8192],stmt_buf[1024];
$char   tmp_relative_ply[POLICY_NUM_1];
$int    t_count;
char    lia_flag,dmg_flag;

$int    iplyyear,iplymonth,linnum,periodcnt;
$char   cy_type[3],cy_fpt[2];
$long   cy_qpt,man_qty,t_date;
$long   sug_qpt;
$char   iquota_tc[11];
char    inextflag[2];
$char   icar_flag[2];
$double main_discount;
$char   lia_class[3];
$int    dmg_acc_1st,dmg_acc_2nd,dmg_acc_3rd;
$int    bqdmg[3];
$date   dpolicy;
char    dmg_flag_p;
$int    iseq_tmp;
$char   dclaim_tmp[11],dprocess_tmp[11],drescue_tmp[11];
$char   qday_tmp[11];
int     itp;
$char   sclmdb[21];
$int    tmp_iym_end;
$char   renew_icode[3];
$char   branch_stmt[20];

/*****************************************************************/
int     max_count,label1=0;
$char   DBName[5];
$char   FormTp[3];
char    option[2];
$char    userid[11];
char    opflag[2];
$int    fg1,y;
int     rtcn;
$char   clmply[21],clm_db[3];
$int    clmcnt ;
$char   sIdir[10];

$char    sDplyEndBgn[11],sDplyEndEnd[11];
$long    lDplyEndBgn    ,lDplyEndEnd;
$int     iYY,iMM;
$char    sYY[4],sMM[3];
$char    iquota_branch[8];
char    rdmg,rlia,rvkind;

/*****  unload data   *****/
$char  ipolicy[21],nassured[41],iassured[11];
$char  tel_night[21],movephone[21],iofficer[11],off_name[20];
$char  lead_name[20],icorps[11],corp_name[20],nbranch[31];
$char  iassured_ext[3];
char   sApHome[30];
int    tot_count;
$char  dply_bgn_i[11], dply_end_i[11];
$char  iupdate[11], ipart[3];

$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;

char BodyFile[ N_FILE+1];
char TitleFile[ N_FILE+1];
$char TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
char outputf[ N_FILE+1];

/*****************************************************************/
int     sPrepare();
long    car3151_build1();
char*   get_car_full_db();

main(argc,argv)
int argc;
char **argv;
{
    long  src;
    char  tmpopt[2];

    strcpy(DBName   , isNULLstr(argv[1]));
    strcpy(userid   , isNULLstr(argv[2]));
    strcpy(plyyear  , isNULLstr(argv[3]));
    strcpy(plymonth , isNULLstr(argv[4]));
    strcpy(iofficer , isNULLstr(argv[5]));
    strcpy(option   , isNULLstr(argv[6]));
    strcpy(outputf  , isNULLstr(argv[7]));

    iplyyear = atoi(plyyear);
    iplyyear += 1911;
    iplymonth = atoi(plymonth);

    /***********************************************/
    /***********************************************/
    /* begin */
    sprintf(sDplyEndBgn,"%s/%s/01",plyyear,plymonth);
    lDplyEndBgn = cm_ymd_cdate(sDplyEndBgn);

    /* end   */
    if (strcmp(trim(plymonth),"12")==0)
    {
        iYY = atoi(plyyear) + 1;
        strcpy(sYY, itoa(iYY));
        sprintf(sDplyEndEnd,"%s/01/01",sYY);
    }
    else
    {
        iMM = atoi(plymonth) + 1;
        strcpy(sMM, itoa(iMM));
        sprintf(sDplyEndEnd,"%s/%s/01",plyyear,sMM);
    }
    lDplyEndEnd = cm_ymd_cdate(sDplyEndEnd)-1;

    printf("lDplyEndBgn[%ld]\n",lDplyEndBgn);
    printf("lDplyEndEnd[%ld]\n",lDplyEndEnd);

    /***********************************************/
    /***********************************************/

    src = car3151_build1();
    if (src != M_CM_OK) goto errexit;
    
    return M_CM_OK;

errexit:
    printf("------car315_err: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    exit(1);
}

long car3151_build1()
{
    $int     PgLine,t_count;
    $char    FullDBName[20],TpDBName[20];
    $char    stmt_buf[8192],buf1[2000], stmt_quo[1024];
    long     rtncode;
    int      count;
    int      rc,x,rt;
    int      cur_yr, cur_mth;
    char     sTmpMsg[80], msgbuf[200];

    long     i;
    $char    plyYYMM[6];
    $int    tmp_iym_end;
    $char   tmp_YYMM[6];
    $char   iupdate[10];
    $char   fulldbname[20], tmp_buf[11];
    $date   Today;
    $long   mdiscount , mprem , mins_premium;
    $double pdiscount;

    batchinit();

    $WHENEVER SQLERROR GOTO car315_err;

    if (db_select(DBName) == False)
    {
        EWRITE(userid,M_CM_DB_NOTOPEN,DBName);
        return M_CM_DB_NOTOPEN;
    }

    /* For Check Server */

    strcpy(iupdate, userid);
    strcpy(tmp_YYMM,trim(plyyear));

    if ((atoi(plymonth) >= 1) && (atoi(plymonth) <= 9))
    {
         strcat(tmp_YYMM, "0");
         strcat(tmp_YYMM, trim(plymonth));
    }
    else
    {
         strcat(tmp_YYMM, trim(plymonth));
    }

    tmp_iym_end=atoi(tmp_YYMM);

    #ifdef PRINTF_FLAG
    printf("tmp_iym_end[%d]\n",tmp_iym_end);
    #endif

    strcpy(plyYYMM, trim(tmp_YYMM));

    #ifdef PRINTF_FLAG
    printf("plyYYMM[%s]\n",plyYYMM);
    #endif
    
    /***********************************************/
    strcpy(db,"00");
    rtoday(&Today);     /* get today's datetime */
    strcpy(s_today,cm_cdate_str_100(Today));
    strncpy(s_cur_yr,s_today,3);
    strncpy(s_cur_mth,&s_today[4],2);
    cur_yr = atoi(s_cur_yr);
    cur_yr += 1911;
    cur_mth = atoi(s_cur_mth);

    sprintf(stmt,"SELECT %s FROM %s WHERE %s",
                 " fins_grp ",
                 " reject_policy ",
                 " ipolicy = ? ");
    $PREPARE fins1 FROM $stmt;
    $DECLARE fins_cur CURSOR FOR fins1;

    #ifdef PRINTF_FLAG
    printf("1.----- plyyear[%s] plymonth[%s]\n",plyyear,plymonth);
    printf("3.0 >>>>option2[%s]\n",option);
    #endif

    $WHENEVER SQLERROR GOTO car315_err;
    $SET LOCK MODE TO WAIT;

    /**linnum ply_ins_type_302,policy_302 sequential�P�B ***/
    rtncode=1,linnum=0;

    rtncode = getHeadBranch(taipei_db);
    if (rtncode < 0)
    {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
    }
    strcpy(TpDBName,get_full_dbname(taipei_db));
    
    #ifdef PRINTF_FLAG
    printf("3.>>>> yr[%d] mth[%d]\n",iplyyear,iplymonth);
    #endif
    
    /* mark by 071004 (1101118007_SC1_����CAR3022.CAR311�A�ק�CAR3151.CAR315��Ƥ���CUS201) */
    /*sprintf(stmt,"SELECT %s FROM %s WHERE %s",
                 " tphone_con, imovephone ",
                 " cu_customer ",
                 " ifpce_id = ? AND ifpce_id_ext = ? ");
    $PREPARE rphone_id FROM $stmt;*/
    
    #ifdef PRINTF_FLAG
    printf("4.>>>> rphone_id \n");
    #endif
    
    /** Get nbranch **/
    sprintf(stmt,"SELECT %s FROM %s WHERE %s",
                 " nbranch ",
                 " sa_branch_type ",
                 " ibranch = ? ");
    $PREPARE rbranch_id FROM $stmt;
    
    #ifdef PRINTF_FLAG
    printf("5.>>>> rbranch_id userid=[%s]\n", userid);
    #endif
    
    $SELECT idir
       INTO $sIdir
       FROM user
      WHERE iemp = $userid;
    if (SQLCODE == SQLNOTFOUND)
    {
        return M_CM_NOT_FOUND;
    }
       
    strncpy(iquota_branch, sIdir, 4);
    
    printf("iquota_branch=[%s] sIdir=[%s]\n", iquota_branch, sIdir );
    
    
    if( option[0] == '3' )
    {
       
       printf("iquota_branch=[%s]\n", iquota_branch );
       
       if( strcmp(trim(iquota_branch),"3201") != 0 )
       {
       	   printf("�D�ӫO�������");
       	   SQLCODE = M_CM_NOT_FOUND;
       	   return M_CM_NOT_FOUND;
       }
        
       /** �إ�Temp Table **/
       rc = sTable();
       if (rc != TRUE)
       {
           printf("sTable() FALSE \n");
           goto car315_err ;
       }
    
       printf("before sPrepare \n");
       /*  ��z���   policy -> policy_last  */
       rc = sPrepare();
       if (rc != TRUE)
       {
          printf("sPrepare() FALSE \n");
          goto car315_err ;
       }
       printf("End sPrepare \n");


       $DECLARE CA302_4 CURSOR for
         SELECT DISTINCT a.ipolicy,irelative_ply,a.fcard_class,a.dply_begin,a.dply_end,a.iquota,
                a.iofficer,(select nname from officer where iofficer = a.iofficer),
                a.ileader,(select nname from officer where iofficer = a.ileader),
                c.nassured[1,40], c.iassured, c.iassured_ext, c.ilicense, c.itel
           FROM renew_ply_last a, renew_ins_last b, renew_policy_last c
          WHERE a.ipolicy = b.ipolicy
            AND a.ipolicy = c.ipolicy
            AND b.fedr_status not in ('1','2','3')
            AND b.mdamage_cover <> 0
          ORDER BY a.fcard_class;
       $OPEN CA302_4;
       while (1)
       {     
           $FETCH CA302_4 
             INTO $last_ply,$tmp_relative_ply,$fcard_class,$dply_bgn_i,$dply_end_i,
                  $iquota,$iofficer,$off_name,$ileader,$lead_name,$nassured,
                  $iassured,$iassured_ext,$ilicense,$tel; 
           if (SQLCODE != 0) break;

           #ifdef PRINTF_FLAG
           printf("lastply[%s],big_office[%s]\n",last_ply,big_office);
           printf("�O�N�� check �O�_��O�j��\n");
           #endif

           /*  �ګO�󤣲���  */
           rdmg = 'N';
           rlia = 'N';
           rvkind = 'N';

           $OPEN fins_cur USING $last_ply;
           for(;;)
           {
               $FETCH fins_cur INTO $sfins;
               if (SQLCODE == SQLNOTFOUND) break;

               if (sfins[0] == '1')
               {
                   rdmg = 'Y';
               }

               if (sfins[0] == '2')
               {
                   rlia = 'Y';
               }

               if ((sfins[0] == '3') || (sfins[0] == '4'))
               {
                    rvkind = 'Y';
               }
           }
           $CLOSE fins_cur;

           if (rvkind == 'Y') continue;

           if (fcard_class[0] == '2')
           {
              /* �B�z���Ѩ���������O */
              strcpy(clmply,last_ply);
           }
           else
           {
              /* �B�z���Ѩ���������O */
              strcpy(clmply,tmp_relative_ply);
           }

           if (strlen(trim(clmply)) >= 13)
           {
              #ifdef PRINTF_FLAG
              printf("clmply[%s]\n",clmply);
              #endif
              strcpy(clm_db,get_car_full_db(clmply));
              #ifdef PRINTF_FLAG
              printf("clm_db [%s]\n",clm_db);
              #endif

              sprintf(stmt, "SELECT %s FROM %s:%s WHERE %s %s",
                            " count(*) ",
                            get_full_dbname(clm_db),
                            "appraisal ",
                            " ipolicy = ? ",
                            " AND fpart IN ('1','2','3') ");

              $PREPARE clmid1 FROM $stmt;
              $EXECUTE clmid1 INTO $clmcnt USING $clmply;
              if (clmcnt > 0) continue;
           }

           #ifdef PRINTF_FLAG
           printf("after lastply[%s],big_office[%s]\n",last_ply,big_office);
           printf("3.0>>>last_ply[%s],ibig_comp[%s]\n",ibig_comp,last_ply);
           #endif
         
          /** ��Ƽg�J policy_expire **/
          
          $INSERT INTO policy_expire VALUES
          ( $last_ply, $dply_bgn_i, $dply_end_i, $iquota, $iofficer, $ileader, 
             $Today,   '',          $iupdate, '', '' );
          
          if( sqlca.sqlerrd[2] > 0 )
          {
             printf("INSERT INTO policy_expire ipolicy=[%s]\n",last_ply );
          }
          else
          {
             printf("NO INSERT INTO  policy_expire ipolicy=[%s]\n",last_ply );
          }
          
          max_count++;
          
                    
       }  /* end of while */
       $CLOSE CA302_4;
       $FREE CA302_4;
    
       /** �s�@�ɮ� **/
       $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
              kTot_Col, kPgNum_Line, kWidth, iform_tp
         INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow,
              $TotColumn, $PgLine, $Width, $FormTp
         FROM Form
        WHERE ksys_grp="CA" AND kPgmID = 315 AND iform_tp = '1';

       strcpy( TitleFmt,rtrim(TitleFmt));
       strcpy( BodyFmt,rtrim(BodyFmt));
       sprintf( TitleFile,"%s.ti",outputf);
       sprintf( BodyFile,"%s.bd",outputf);
       
       /* ***** title file ***** */
       rgu_init_report(TitleFmt,TitleFile);
       rgu_put_head();
       rgu_finish_report();

       /* ***** body file ***** */
       rgu_init_report(BodyFmt,BodyFile);
    	
       sprintf(msgbuf,"�J�p��Ʀ��\, �@�p [%ld]�����",max_count);
    	
       rgu_put_body_string(1, msgbuf, 1);
       rgu_put_body(1);   max_count=1;
    	
       rgu_finish_report();
    	
       rtncode=create_sign_form("car315",BodyFile,Width);
       if (rtncode != 0)
       {
          EWRITE(userid,rtncode,"Error on creating sign form");
          printf("Error on creating sign form, rtncode=%d\n",rtncode);
          return;
       }

       if((rc=save_form_info(F_BLK1,"CA",315,userid,FormTp,max_count,outputf))<0)
           EWRITE(userid,rc,"save form info failure!");  
           
       $drop table renew_ply_last;
       $drop table renew_policy_last;
       $drop table renew_ins_last;
       $drop table CAR3151;
        
    }
    else
    {
    	
    	/** �s�@�ɮ� **/
    	$SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
                kTot_Col, kPgNum_Line, kWidth, iform_tp
           INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow,
                $TotColumn, $PgLine, $Width, $FormTp
           FROM Form
          WHERE ksys_grp="CA" AND kPgmID = 315 AND iform_tp = '2';

        strcpy( TitleFmt,rtrim(TitleFmt));
        strcpy( BodyFmt,rtrim(BodyFmt));
        sprintf( TitleFile,"%s.ti",outputf);
        sprintf( BodyFile,"%s.bd",outputf);
        
        /* ***** title file ***** */
        rgu_init_report(TitleFmt,TitleFile);
        rgu_put_head_string(1, cm_sysd_cdatetime_100(cm_get_sysd()));  /* get_currdt */
        rgu_put_head_string(1, plyyear);
        rgu_put_head_string(1, plymonth);
        rgu_put_head();
        rgu_finish_report();

        /* ***** body file ***** */
        rgu_init_report(BodyFmt,BodyFile);
        max_count = 0;
        
        rgu_put_body(2);
        max_count++;
        
        if( (strcmp(trim(iquota_branch),"3201") != 0) && (strcmp(trim(iquota_branch),"4302") != 0) )
        {
            sprintf(stmt_quo, "AND a.iquota in (select c.ibranch \
                             from officer a, branch b, sa_branch_type c \
                            where iofficer = '%s' and a.iupcomp = b.ibranch_abbr \
                              and b.iupbranch  = c.iupcomp)", userid );
        }
        else
            strcpy(stmt_quo," ");
        
        printf("stmt_quo=[%s]\n", stmt_quo);

        sprintf(stmt,"SELECT ipolicy, dply_begin, dply_end, a.iquota, a.iofficer, a.ileader, \
                (select nname from officer where iofficer = a.iofficer ), \
                (select nname from officer where iofficer = a.ileader ),  \
                a.dupdate, a.iupdate,a.ipart,c.qorder \
                FROM policy_expire a, sa_branch_type b, sa_frm_module c \
               WHERE dply_end between ? AND ? \
                 AND a.iquota = b.ibranch \
                 AND b.igroup = c.igroup \
                 AND c.ifrm_module = '01' %s \
               ORDER BY c.qorder, a.iquota, a.ipolicy", stmt_quo );
        
        printf("stmt=[%s]\n", stmt);

        $PREPARE CAR315_FMT1 FROM $stmt;
        $DECLARE CAR315_FMT CURSOR FOR CAR315_FMT1;
        $OPEN CAR315_FMT USING $lDplyEndBgn, $lDplyEndEnd;
        while(1)
        {
            $FETCH  CAR315_FMT            
              INTO $ipolicy,$dply_bgn_i,$dply_end_i,$iquota,$iofficer,$ileader,
                   $off_name,$lead_name,$dupdate,$iupdate,$ipart;
            
            if( SQLCODE == SQLNOTFOUND )
               break;
               
            strcpy(clm_db,get_car_full_db(ipolicy));
            printf("clm_db=[%s]\n", clm_db);
            
            sprintf(stmt,"SELECT a.iassured, a.iassured_ext, a.ilicense, a.nassured[1,40], \
                                 a.itel, b.icorps, a.itel_night, a.mobil_phone\
                            FROM %s:policy a, %s:ply_relation b\
    	               WHERE a.ipolicy = ? AND a.ipolicy = b.ipolicy ",
    	               get_full_dbname(clm_db),
    	               get_full_dbname(clm_db) );
    	    
    	    $PREPARE get_iassured FROM $stmt;
    	    $EXECUTE get_iassured 
    	        INTO $iassured, $iassured_ext, $ilicense,
    	             $nassured, $tel, $icorps, $tel_night, $movephone 
    	       using $ipolicy;
    	             
    	    printf("ipolicy=[%s] icorps=[%s]\n",ipolicy, icorps );
    	             
    	    sprintf(stmt,"SELECT sum(mins_premium), sum(mprem) \
    	                    FROM %s:ply_ins_type \
    	                   WHERE ipolicy = ?",get_full_dbname(clm_db) );
    	    
    	    $PREPARE get_prem FROM $stmt;
    	    $EXECUTE get_prem INTO $mins_premium, $mprem USING $ipolicy;
    	    
    	    mdiscount = mprem - mins_premium;
    	    pdiscount = (double)mdiscount / (double)mprem * 100;
    	    
            /** get tphone_con, imovephone **/
    	    /*$EXECUTE rphone_id INTO $tel_night, $movephone 
    	                     USING $iassured, $iassured_ext;
      	    if(SQLCODE == SQLNOTFOUND) 
    	    {
    	       strcpy( tel_night, " ");
    	       strcpy( movephone, " ");
    	    }*/
    	
    	    $EXECUTE rbranch_id INTO $nbranch USING $iquota;
    	    if(SQLCODE == SQLNOTFOUND) 
    	    {
    	       strcpy( nbranch, " ");
      	    }
      	    
      	    if( strlen(trim(icorps)) != 0 )
      	    {
      	    	$SELECT nname INTO $corp_name
      	    	   FROM officer
      	    	  WHERE iofficer = $icorps;
      	    }
      	    else
      	        strcpy( corp_name," ");
      	        
            rgu_put_body_string(3,rtrim( nbranch ) ,1);
            rgu_put_body_string(3,rtrim( iquota ) ,1);
            rgu_put_body_string(3,rtrim( ipolicy ) ,1);
            rgu_put_body_string(3,rtrim( dply_bgn_i ) ,1);
            rgu_put_body_string(3,rtrim( dply_end_i) ,1);
            rgu_put_body_string(3,rtrim( nassured ) ,1);
            rgu_put_body_string(3,rtrim( iassured ) ,1);
            rgu_put_body_string(3,rtrim( ilicense ) ,1);
            rgu_put_body_string(3,rtrim( tel ) ,1);
            rgu_put_body_string(3,rtrim( tel_night ) ,1);
            rgu_put_body_string(3,rtrim( movephone ) ,1);
            rgu_put_body_string(3,rtrim( iofficer ) ,1);
            rgu_put_body_string(3,rtrim( off_name ) ,1);
            rgu_put_body_string(3,rtrim( ileader ) ,1);
            rgu_put_body_string(3,rtrim( lead_name ) ,1);
            rgu_put_body_string(3,rtrim( icorps ) ,1);
            rgu_put_body_string(3,rtrim( corp_name ) ,1);
            
            rfmtlong( mins_premium, "##########", tmp_buf );
            rgu_put_body_string(3, tmp_buf ,1);
            rfmtlong( mprem, "##########", tmp_buf );
            rgu_put_body_string(3, tmp_buf ,1);
            
            rfmtdouble( pdiscount,"&&.&&", tmp_buf);
            rgu_put_body_string(3, tmp_buf ,1);
            
            if( strlen(trim(dupdate)) == 0 )
                strcpy( iupdate, " ");
            
            rgu_put_body_string(3,rtrim( dupdate ) ,1);
            rgu_put_body_string(3,rtrim( iupdate ) ,1);
            rgu_put_body_string(3,rtrim( ipart ) ,1);
            
            rgu_put_body(3);
            
            max_count++;
        
        }
        $CLOSE CAR315_FMT;
        $FREE  CAR315_FMT;
        
    	rgu_finish_report();
    	
    	rtncode=create_sign_form("car315",BodyFile,Width);
        if (rtncode != 0)
        {
          EWRITE(userid,rtncode,"Error on creating sign form");
          printf("Error on creating sign form, rtncode=%d\n",rtncode);
          return;
        }

        if((rc=save_form_info(F_BLK1,"CA",315,userid,FormTp,max_count,outputf))<0)
           EWRITE(userid,rc,"save form info failure!");
           
    	
    }
    
    return M_CM_OK;

car315_err:
    printf("in car315_err\n");
    printf("------car315_err: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    $WHENEVER SQLERROR CONTINUE;     /* reset error handling */
    return SQLCODE;
}

int sPrepare()
{
     $date   Today;
     $char   FullDBName[30], stmt_buf[8192];
     $int    pre_cnt;
     
     $char   xBranch[3];
     int     i;

     $char   tmp_ipolicy[21];
     $date   tmp_dply_begin, tmp_dply_end;
     $char   tmp_iresource[3];
     $char   tmp_iofficer[11];
     $char   tmp_icorps[10];
     $long   count_num;

     $WHENEVER SQLERROR GOTO errexit;
     $SET LOCK MODE TO WAIT ;

     rtoday(&Today);     /* get today's datetime */
     /** 
     pre_cnt = 0;
     $SELECT count(*)
        INTO $pre_cnt
        FROM policy_expire
       WHERE dply_end between $lDplyEndBgn and $lDplyEndEnd;
     
     if( pre_cnt > 0 )
         return FALSE;
     **/
     printf("in Prepare\n");
     
     $DECLARE sdb_cur CURSOR WITH HOLD FOR
       SELECT branch
         INTO $xBranch
         FROM servertbl
        WHERE branch <> 'S1';  
     $OPEN sdb_cur;

     for(;;)
     {
          $FETCH sdb_cur;
          if (SQLCODE == SQLNOTFOUND) break;

          printf("in servertbl xBranch[%s]\n", xBranch);
          strcpy(FullDBName,get_full_dbname(xBranch));

          stmt_buf[0] = '\0';
          sprintf(stmt_buf, " INSERT INTO renew_ply_last SELECT a.ipolicy ,a.icard , a.fcard_class, a.irelative_ply , a.dply_begin, a.dply_end , \
                              b.dissue ,a.ipro_year,a.ibrand ,a.icar_type ,a.mdmg_prem ,a.mlia_prem ,a.ibig_comp, \
                              a.ibig_branch,a.ibig_office,a.ibig_sales ,a.iresource ,a.ibroker ,a.iofficer,a.ileader, \
                              a.icorps ,a.iarea ,a.dpolicy,a.ibranch,a.iquota ,a.icar_flag  \
                              FROM %s:ply_relation a, %s:policy b WHERE a.ipolicy = b.ipolicy AND a.ipolicy = ? ",FullDBName, FullDBName);
          $PREPARE ins_re FROM $stmt_buf;
          printf("done ins_re\n");

          stmt_buf[0] = '\0';
          sprintf(stmt_buf, " INSERT INTO renew_policy_last SELECT ipolicy ,icard ,fassured,iassured ,iassured_ext,nassured ,ilicense ,dbirth ,fsex ,fmarriage, \
                              nuser ,aassured ,aassured_zip ,itel ,iemail ,iply_area ,nbrand_abbr,ncar_abbr ,fcar_note ,\
                              qcylinder ,iengine ,ibody ,itag ,mcar_price ,nequipment ,fcal_way ,idmg_rate,pdmg_factor ,\
                              ibrg_rate ,pbrg_factor,qpt ,fpt ,psex_age ,lia_class,plia_acc ,pdmg_acc ,fhuman ,fcomp_24 \
                              FROM %s:policy WHERE ipolicy = ? ",FullDBName);
          $PREPARE ins_po FROM $stmt_buf;
          printf("done ins_po\n");
          
          stmt_buf[0] = '\0';
          sprintf(stmt_buf, " INSERT INTO renew_ins_last SELECT ipolicy ,iins_type ,minjured_cover ,mdeath_cover ,mdamage_cover,mdeduct ,mins_premium, \
                              mpure_prem ,qserial ,fedr_status ,dendorse ,dedr_begin ,dedr_end ,iendorse ,pcommission, \
                              mcommission ,pagent ,magent ,pdiscount ,mdiscount ,drate_ym ,mprem ,iproduct ,ipaid_base, \
                              qday  ,mexpense  ,mexp_disc  FROM %s:ply_ins_type WHERE ipolicy = ? ",FullDBName);
          $PREPARE ins_type FROM $stmt_buf;
          printf("done ins_type\n");

          $BEGIN WORK;
          printf("Preparing ipolicy Please Wait .....\n");

          /* �z�糧����O�J�p�@�~�ŦX����϶����O�� */
          count_num = 0;
          stmt_buf[0] = '\0';
          sprintf(stmt_buf, " SELECT %s FROM %s:%s %s:%s %s WHERE %s %s %s %s %s %s %s %s %s %s ",
                            " a.ipolicy, a.dply_begin, a.dply_end, a.iresource, a.iofficer, a.icorps ",
                            FullDBName,"ply_relation a,",
                            FullDBName,"policy b, ",
                            " officer c ",
                            " a.dply_end between ? and ? ",
                            " AND a.fcard_class = '2' ",
                            " AND a.iresource <> '1' ",
                            " AND a.iresource <> 'A' ",
                            " AND a.iofficer[1] <> 'Z' ",
                            "  ",
                            " AND c.dexpire is not null ",
                            " AND a.ileader = c.iofficer ",
                            " AND a.iofficer not in (select iofficer from expire_officer ) ",
                            " AND a.ipolicy = b.ipolicy ");
                            
          printf("[%s]\n",stmt_buf);
          printf("lDplyEndBgn[%ld] ",lDplyEndBgn);
          printf("lDplyEndEnd[%ld]\n",lDplyEndEnd);
          printf("iofficer[%s]\n", iofficer );
          $PREPARE ins_ply_tmp FROM $stmt_buf;
          $DECLARE ins_ply     CURSOR WITH HOLD FOR ins_ply_tmp;
          $OPEN    ins_ply     USING  $lDplyEndBgn, $lDplyEndEnd;
          while(1)
          {
              $FETCH ins_ply INTO $tmp_ipolicy, $tmp_dply_begin, $tmp_dply_end, $tmp_iresource, $tmp_iofficer, $tmp_icorps;
              if (SQLCODE == SQLNOTFOUND) break;

              printf("tmp_ipolicy[%s]\n", tmp_ipolicy);
              
              /*  iresource != 'E' */
              if (strncmp(tmp_iresource,"E",1)==0)
                   continue;

              /*  iofficer[1,3] != 'G98' */
              if (strncmp(tmp_iofficer,"G98",3)==0)
                   continue;
                   
              /*  icorps[1,4] != 'C111' */
              if (strncmp(tmp_icorps,"C111",4)==0)
                   continue;
              
              /*  (iofficer[1] != 'W' AND  iofficer[7,8] not in ('JT','IS','IF','BE','YF','YI'))  */             
              if ((tmp_iofficer[0] == 'W') || (tmp_iofficer[0] == 'H' && (tmp_iofficer[1]!='0' && tmp_iofficer[1]!='1' && tmp_iofficer[1]!='2') ))
              {
              	   /*
                   if((strncmp(tmp_iofficer+(7-1),"BE",2)==0) ||
                      (strncmp(tmp_iofficer+(7-1),"JT",2)==0) ||
                      (strncmp(tmp_iofficer+(7-1),"YF",2)==0) ||
                      (strncmp(tmp_iofficer+(7-1),"IF",2)==0) ||
                      (strncmp(tmp_iofficer+(7-1),"IS",2)==0) ||
                      (strncmp(tmp_iofficer+(7-1),"RL",2)==0) ||
                      (strncmp(tmp_iofficer+(7-1),"YI",2)==0) )
                   {*/
                        continue;
                   /*}*/
              }

              printf("INSERTING ply_relation_last\n");
              $EXECUTE ins_re USING $tmp_ipolicy;

              printf("INSERTING policy_last\n");
              $EXECUTE ins_po USING $tmp_ipolicy;
 
              printf("INSERTING ply_ins_type_last\n");
              $EXECUTE ins_type USING $tmp_ipolicy;
              
              count_num ++;

              if (count_num == 500)
              {
                   $COMMIT WORK;
                   $BEGIN WORK;
                   count_num = 0;
              }
          }
          $CLOSE ins_ply;
          $FREE  ins_ply;

          $COMMIT WORK;
          
     }
     $CLOSE sdb_cur;
     $FREE  sdb_cur;
     
     printf("finish s_Prepare() \n");

     return TRUE;
errexit:
     $ROLLBACK WORK;
     printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
     return SQLCODE;
}

long sTable()
{
    
    printf("Begin Create sTable \n"); 

    $CREATE TEMP TABLE renew_ply_last
    (
      ipolicy char(20)
          default ' ',
      icard char(20)
          default ' ',
      fcard_class char(1)
          default ' ',
      irelative_ply char(20)
          default ' ',
      dply_begin date,
      dply_end date,
      dissue date 
          default null,
      ipro_year char(4)
          default ' ',
      ibrand char(8)
          default ' ',
      icar_type char(2)
          default ' ',
      mdmg_prem integer
          default 0,
      mlia_prem integer
          default 0,
      ibig_comp char(1)
          default ' ',
      ibig_branch char(4)
          default ' ',
      ibig_office char(9)
          default ' ',
      ibig_sales char(10)
          default ' ',
      iresource char(1)
          default ' ',
      ibroker char(10)
          default ' ',
      iofficer char(10)
          default ' ',
      ileader char(10)
          default ' ',
      icorps char(10)
          default ' ',
      iarea char(10)
          default ' ',
      dpolicy date,
      ibranch char(2)
          default ' ',
      iquota char(6)
          default ' ',
      icar_flag char(1) not null
    )WITH NO LOG;
    $CREATE INDEX renew_ply_1 ON renew_ply_last(ipolicy);
    $CREATE INDEX renew_ply_2 ON renew_ply_last(icard);
    
    $CREATE TEMP TABLE renew_policy_last
    (
      ipolicy char(20)
          default ' ',
      icard char(20)
          default ' ',
      fassured char(1)
          default ' ',
      iassured char(12)
          default ' ',
      iassured_ext char(2)
          default ' ',
      nassured char(120)
          default ' ',
      ilicense char(10)
          default ' ',
      dbirth date 
          default null,
      fsex char(1)
          default ' ',
      fmarriage char(1)
          default ' ',
      nuser char(18)
          default ' ',
      aassured char(90)
          default ' ',
      aassured_zip char(6)
          default ' ',
      itel char(20)
          default ' ',
      iemail char(50)
          default ' ',
      iply_area char(10)
          default ' ',
      nbrand_abbr char(12)
          default ' ',
      ncar_abbr char(12)
          default ' ',
      fcar_note char(2)
          default ' ',
      qcylinder decimal(7,2)
          default 0.0,
      iengine char(20)
          default ' ',
      ibody char(20)
          default ' ',
      itag char(8)
          default ' ',
      mcar_price decimal(5,1)
          default 0.0,
      nequipment char(30)
          default ' ',
      fcal_way char(1)
          default ' ',
      idmg_rate char(2)
          default ' ',
      pdmg_factor decimal(6,4)
          default 0.0000,
      ibrg_rate char(2)
          default ' ',
      pbrg_factor decimal(6,4)
          default 0.0000,
      qpt decimal(4,1)
          default 0.0,
      fpt char(1)
          default ' ',
      psex_age decimal(15,12)
          default 0.00,
      lia_class char(2)
          default '4',
      plia_acc decimal(5,2)
          default 0.00,
      pdmg_acc decimal(5,2)
          default 0.00,
      fhuman char(1)
          default '1',
      fcomp_24 char(1)
          default ' '
    )WITH NO LOG;
    
    $create unique index renew_ix_1 on renew_policy_last(icard);
    $create unique index renew_ix_2 on renew_policy_last(ipolicy);
    
    $CREATE TEMP TABLE renew_ins_last
    (
      ipolicy char(20)
          default ' ',
      iins_type char(6)
          default ' ',
      minjured_cover integer
          default 0,
      mdeath_cover integer
          default 0,
      mdamage_cover integer
          default 0,
      mdeduct integer
          default 0,
      mins_premium integer
          default 0,
      mpure_prem decimal(10,3)
          default 0,
      qserial smallint
          default 0,
      fedr_status char(1)
          default ' ',
      dendorse date,
      dedr_begin date,
      dedr_end date,
      iendorse char(20)
          default ' ',
      pcommission decimal(4,2)
          default 0,
      mcommission integer
          default 0,
      pagent decimal(4,2)
          default 0,
      magent integer
          default 0,
      pdiscount decimal(4,2)
          default 0,
      mdiscount integer
          default 0,
      drate_ym char(4)
          default ' ',
      mprem integer
          default 0,
      iproduct char(12)
          default ' ',
      ipaid_base char(1)
          default 'A',
      qday  integer
          default 0,
      mexpense  integer
          default 0,
      mexp_disc integer
          default 0
    )WITH NO LOG;
    
    $create unique index renew_ins_ix_1 on renew_ins_last (ipolicy,iins_type);
    $create index renew_ins_ix_2 on renew_ins_last(ipolicy);
    
    $CREATE TEMP TABLE CAR3151
    (
    	ipolicy     char(20),
    	dply_begin  date,
    	dply_end    date,
    	nassured    char(40),
    	iassured    char(10),
    	ilicense    char(10),
    	tel         char(20),
    	tel_night   char(20),
    	movephone   char(20),
    	iofficer    char(10),
    	off_name    char(20),
    	ileader     char(10),
    	lead_name   char(20),
    	icorps      char(10),
    	corp_name   char(20),
    	iquota      char(10),
    	nbranch     char(30)
    )
    WITH NO LOG;
    $CREATE INDEX CAR3151_ix1 ON CAR3151(ipolicy);
    
    $CREATE TEMP TABLE expire_officer
    (
       iofficer   char(20)
    )
    with no log;

    $INSERT INTO expire_officer VALUES('710187');
    $INSERT INTO expire_officer VALUES('7S0079');
    $INSERT INTO expire_officer VALUES('700731');
    $INSERT INTO expire_officer VALUES('712787');
    $INSERT INTO expire_officer VALUES('712873');
    $INSERT INTO expire_officer VALUES('7S0141');
    $INSERT INTO expire_officer VALUES('712880');
    $INSERT INTO expire_officer VALUES('7S0158');
    $INSERT INTO expire_officer VALUES('708643');
    $INSERT INTO expire_officer VALUES('712794');
    $INSERT INTO expire_officer VALUES('7S0165');
    $INSERT INTO expire_officer VALUES('701268');
    $INSERT INTO expire_officer VALUES('712622');
    $INSERT INTO expire_officer VALUES('7C0219');
    $INSERT INTO expire_officer VALUES('712646');
    $INSERT INTO expire_officer VALUES('711360');
    $INSERT INTO expire_officer VALUES('712653');
    $INSERT INTO expire_officer VALUES('710400');
    $INSERT INTO expire_officer VALUES('712677');
    $INSERT INTO expire_officer VALUES('712701');
    $INSERT INTO expire_officer VALUES('7S0172');
    $INSERT INTO expire_officer VALUES('7C0082');
    $INSERT INTO expire_officer VALUES('712718');
    $INSERT INTO expire_officer VALUES('7C0075');
    $INSERT INTO expire_officer VALUES('712725');
    $INSERT INTO expire_officer VALUES('7C0178');
    $INSERT INTO expire_officer VALUES('712756');
    $INSERT INTO expire_officer VALUES('702379');
    $INSERT INTO expire_officer VALUES('712763');
    $INSERT INTO expire_officer VALUES('712770');
    $INSERT INTO expire_officer VALUES('7C0109');
    $INSERT INTO expire_officer VALUES('701299');

    printf("End Create sTable \n");

    return TRUE;
     
errexit:
     $ROLLBACK WORK;
     printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
     return SQLCODE;
}

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, sTmpcomp);
  }
  return sTmp_db_name;
}
