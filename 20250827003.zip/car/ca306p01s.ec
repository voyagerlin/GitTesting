/*************************************************************/
/*                                                           */
/*   PROGRAM : oth101_laser_policy_EN.ec  by Lin             */
/*   ���                         10/20/2004                 */
/*************************************************************/

/* LINE_HEIGTH : �氪                                  */
/* INS_LINE    : �O���Ʀ��                          */
/* AMT_LINE    : �O�B��Ʀ��                          */
/* XPOS_MA     : �����I�ئW�� X ����                   */
/* XPOS_MB     : �����I�ئW�� X ����                   */
/* XPOS_APPROVE: �֭�帹     X ����                   */
#define  LINE_HEIGTH  5
#define  INS_LINE     3
#define  AMT_LINE     4
#define  XPOS_MA      "60"
#define  XPOS_MB      "60"
#define  XPOS_APPROVE "155"

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "cmprint.h"
#include "ISvar_gls.h"
#include "funlist.h"
$include decimal.h;
$include sqlca;
$include carmsgs.h;
$include "var_length.h";
#include "print.h" 
#include "safeclib.h"
/*$include othnew.h;
$include othmsgs.h;*/
int *iGetChinesePos();

/* �q�l���ڻ������(1101201016_SC1) */
#define str_feterms1 "���ۦ����O�I��Υ����q���Ѥ�QR Code�ɡA�Y�����w�����O����ڡC"
#define str_feterms2 "���pQR Code���X�l���εL�k�ϥΩζ��ȥ��O����ڽЬ��~�ȪA�ȤH���ΫȪA�M�u�C"

char option[2];
/***************************************************************************/
long car3061(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;     
{
	long rtncode;
 	
 	long ca_rpt_ext_L();
 	long ca_rpt_eb_L(); /* �q�ʦۦ樮 */
 	/*char option;*/

 	cm_buf_init(command);
 	cm_buf_get("%c",&option);
 	switch(option[0])
        {
  	    case 'A':
 	  	 rtncode = ca_ipolicy_count(reply,command,com_len);
 	  	 break;
 	    case 'B':
 	  	 rtncode = ca_chk_feply(reply,command,com_len);
 	  	 break;
  	    case '6':
 	    case '7':
 	  	 rtncode = ca_rpt_ext_L(reply,command,com_len);
 	  	 break;
 	    case '8':
 	    case '9':
 	  	 rtncode = ca_rpt_eb_L(reply,command,com_len);
 	  	 break;
 	    case '4':
 	    case '5':
 	  	 rtncode = ca_rpt_tv_L(reply,command,com_len);
 	  	 break;
 	  	 
 	    default :
            if(exitsub(reply,M_CM_WRONG_OPTION) == True)
            {
   	        return M_CM_WRONG_OPTION;
            }
        } 	
 	return(rtncode);
}
/**************************************************************/ 
long ca_ipolicy_count(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 /* standard defined host variables */
char  OutFile[21],hostname[20],tmpOutFile[51];
char  aphome[40];
int   tmp_len=0;
DBinfo *list;	

$char DBName[DBNAME];
$char stmt[1024],stmt1[128];
$char data1[10],date2[10],iquota[11],ileader[10],ply_bgn[21],ply_end[21];
$char dentry1[11],dentry2[11];
$char ipolicy_min[21],ipolicy_max[21];
$int  count=0;
int   count_db=0;
$char userid[11];
	
	cm_buf_get("%s %s %s %s %s %s %s",DBName,data1,date2,iquota,ileader,ply_bgn,ply_end);
	
	strcpy(dentry1, cm_to_infdate(data1));
	strcpy(dentry2, cm_to_infdate(date2));
	
	$WHENEVER SQLERROR GOTO errexit;
	if (db_select (DBName) == False)
	{
	    if (exitsub (reply, M_CM_DB_NOTOPEN) == True)
		return M_CM_DB_NOTOPEN;
	    else
		return apiRC;
	}
	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) 
	{
	    if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
		return M_CM_NOT_DBLIST;
	    else
		return apiRC;
	}
 	
	if (ply_bgn[0]=='*' || ply_bgn[0]==' ' || ply_bgn[0]=='\0')
	    sprintf_s(stmt1, sizeof stmt1, " " );
	else
	    sprintf_s(stmt1, sizeof stmt1, " and (ipolicy >= '%s' and ipolicy <= '%s') ", ply_bgn, ply_end );
 		
	/** �i�L�O���Ƥ��o�W�L100�� **/    
	sprintf_s(stmt, sizeof stmt, " select count(*)                       \n"
                       "   from ply_relation                   \n"
                       "  where fcard_class = '2'              \n"
                       "    and dpolicy is null                \n"
                       "    and dply_close is null             \n"
                       "    and dentry between '%s' and '%s'   \n"
                       "    and ileader matches '%s'           \n"
                       "    and iquota matches '%s' %s         \n"
                       "    and (iofficer[1] not in ('W','N') and not (iofficer[1] = 'H' and iofficer[2] not in ('0','1','2')) );    \n"
                       , dentry1, dentry2, ileader, iquota, stmt1 );       
        $PREPARE count1 FROM $stmt;   printf("######stmt[%s]\n",stmt); 
 	$EXECUTE count1 INTO $count;
 	
	if (count > 100){
	    strcpy(ipolicy_min," ");
	    strcpy(ipolicy_max," ");
	    
	    sprintf_s(stmt, sizeof stmt, " select first 1 ipolicy                \n"
                           "   from ply_relation                   \n"
                           "  where fcard_class = '2'              \n"
                           "    and dpolicy is null                \n"
                           "    and dply_close is null             \n"
                           "    and dentry between '%s' and '%s'   \n"
                           "    and ileader matches '%s'           \n"
                           "    and iquota matches '%s' %s         \n"
                           "    and (iofficer[1] not in ('W','N') and not (iofficer[1] = 'H' and iofficer[2] not in ('0','1','2')) )    \n"
                           "  order by 1;                          \n"
                           , dentry1, dentry2, ileader, iquota, stmt1 );       
            $PREPARE sel_min FROM $stmt;
            $EXECUTE sel_min INTO $ipolicy_min;
            
	    sprintf_s(stmt, sizeof stmt, " select skip 99 first 1 ipolicy        \n"
                           "   from ply_relation                   \n"
                           "  where fcard_class = '2'              \n"
                           "    and dpolicy is null                \n"
                           "    and dply_close is null             \n"
                           "    and dentry between '%s' and '%s'   \n"
                           "    and ileader matches '%s'           \n"
                           "    and iquota matches '%s' %s         \n"
                           "    and (iofficer[1] not in ('W','N') and not (iofficer[1] = 'H' and iofficer[2] not in ('0','1','2')) )    \n"
                           "  order by 1;                          \n"
                           , dentry1, dentry2, ileader, iquota, stmt1 );       
            $PREPARE sel_max FROM $stmt;
            $EXECUTE sel_max INTO $ipolicy_max;          
	}
	else
	{
	    strcpy(ipolicy_min," ");
	    strcpy(ipolicy_max," ");
	}       
        
        printf("######count[%d]min[%s]max[%s]\n",count,ipolicy_min,ipolicy_max); 
 
        gethostname(hostname,sizeof(hostname));
        sprintf_s(tmpOutFile, sizeof tmpOutFile, "%s/reportfile/%s", aphome,OutFile);
        
        cm_buf_init (ReplyBuf);
        cm_buf_put ("%l %d %s %s", M_CM_OK,count,ipolicy_min,ipolicy_max);
        
        tmp_len = cm_buf_len(ReplyBuf);
        if (SendSyncReply (reply, ReplyBuf, tmp_len, api_OKComplete) == False)
            return apiRC;
        else
            return api_OKComplete;

errexit:
     printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
     return SQLCODE;
}
/**************************************************************/ 
long ca_chk_feply(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 /* standard defined host variables */
char  OutFile[21],hostname[20],tmpOutFile[51];
char  aphome[40];
int   tmp_len=0;
DBinfo *list;	

$char DBName[DBNAME];
$char stmt[1024],stmt1[128];
$char ply_bgn[21],ply_end[21];
$int  feply=0;
int   count_db=0;
$char userid[11];
	
	cm_buf_get("%s %s %s",DBName,ply_bgn,ply_end);
	
	$WHENEVER SQLERROR GOTO errexit;
	if (db_select (DBName) == False)
	{
	    if (exitsub (reply, M_CM_DB_NOTOPEN) == True)
		return M_CM_DB_NOTOPEN;
	    else
		return apiRC;
	}
	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) 
	{
	    if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
		return M_CM_NOT_DBLIST;
	    else
		return apiRC;
	}
  
	$select count(*) into $feply
	   from ply_relation
	  where feply = '1'
	    and ipolicy >= $ply_bgn
	    and ipolicy <= $ply_end;

        cm_buf_init (ReplyBuf);
        cm_buf_put ("%l %d", M_CM_OK,feply);
        
        tmp_len = cm_buf_len(ReplyBuf);
        if (SendSyncReply (reply, ReplyBuf, tmp_len, api_OKComplete) == False)
            return apiRC;
        else
            return api_OKComplete;

errexit:
     printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
     return SQLCODE;
}
/**************************************************************/ 
long ca_rpt_ext_L(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{		
 /* standard defined host variables */
int   rc;
char  tempstr[121];
char  OutFile[21],outputf[21],tmpOutFile[51];
char  hostname[20];
int   copies=0, res=0, xpos_ma=0, xpos_mb=0;
long  msg=0;
char  aphome[40];
int   tmp_len=0,i=0;
char  bch_date[12],ech_date[12],ipolicyfrt[4],ipolicybak[11];
char  tabstr[2];
char  nyy[4],nmm[3],ndd[3];
char  syy[4],smm[3],sdd[3],eyy[4],emm[3],edd[3];/*��O�I����*/
int count=0;

 /* variables using in DB */
 $char DBName[DBNAME];
 $char FormFile[21], prnDev[21], prnFile[21];
 $int  PgLine=0;
 $char sdentry[11];
 $char co_cname[101],co_ename[101],co_addr[101];
  
 $char policyedr_bgn[21],policyedr_end[21];
 $char ipolicy[21], iendorse[21];
 $char dply_begin_ext[11],dply_end_ext[11],dpolicy[11],dply_begin[11],dply_end[11];
 $char nassured_ext[121],nassured[121],nowner[121],itag[CA_TAG_NUM];
 $char iengine[CA_ENGINE_NUM],ibody[CA_BODY_NUM],nbrand_abbr[13],ibrand[9],nbrand[31];
 $long mpremium=0;
 $char mpremium_tmp[12],mpremium_tmp2[12];
 $char dentry_ext[20];
 $long qperiod=0,qmiles=0;
 $double mkilo_ply;
 $char icar_flag[2],iparts[2];
 $int mcover1;
 $double mcar_price;
 $char mcar_price_tmp[11];

 /* variables for form */
int print_line=0, ypos=0, objnum=0, len1=0;
char nins_kind_desc[73],temp1[101],temp2[21];
char ipolicytmp[4],spos_ma[11],spos_mb[11];
char addr[101];

/* variables from client */
char inputDate[YYYMMDD],sIbranch[BRANCH_ID],ikind[2];
$char ply_bgn[POLICY_NUM_1],ply_end[POLICY_NUM_1];
$char ipolicy_bgn[21],ipolicy_end[21];
$char iendorse_bgn[21],iendorse_end[21];
$char dentry[YYYYMMDD];
long t=0;
$char dToday[11];
$char co_place[2],nchi_abv[21];
$char chkAdd[2],sIestimate[21],sIassured[13];
char year_chinese[5],mile_chinese[60];
char mkiloply_tmp[12];
int iTmp=0,itext=0,iTmp2=0; /*�_��P�_�ϥ�*/
char nbrand_1[20],nbrand_2[20]; /*�t�P�����_��*/
char nowner_1[20],nowner_2[20]; /*���D�_��*/

$char f_1070601[2];
 
  strcpy(chkAdd,"0");
  count = 0;
  t = cm_today();
  
  /* get data from client program */
  /* cm_buf_get("%c",&option); */
  cm_buf_get("%s",DBName);
  
  switch(option[0])
  {
    case '6':
  	cm_buf_get("%s",inputDate);
  	cm_buf_get("%s",sIbranch);
  	cm_buf_get("%s",ply_bgn);
  	cm_buf_get("%s",ply_end);
  	cm_buf_get("%s",ikind);
  	
  	strcpy(dentry, cm_to_infdate(inputDate));
	  break;
    case '7':
  	cm_buf_get("%s",ply_bgn);
  	cm_buf_get("%s",ply_end);
  	cm_buf_get("%s",ikind);
  	cm_buf_get("%s",chkAdd);
  	break;
  	
    default :
        if(exitsub(reply,M_CM_WRONG_OPTION) == True)
        {
   	       return M_CM_WRONG_OPTION;
        }
  }
  
  split_policy(ply_bgn, ipolicy_bgn, iendorse_bgn);
  split_policy(ply_end, ipolicy_end, iendorse_end);

  tabstr[0] = 0x9;
  tabstr[1] = 0x0;

  $WHENEVER SQLERROR GOTO errexit;
  if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

  printf("laser print 1-1 and option[%s]\n",option);

  /*CHOICE */
  /*$WHENEVER SQLERROR GOTO optL_err;*/
 
  $SELECT kpgnum_line,nform_file INTO $PgLine,$FormFile
     FROM form
    WHERE ksys_grp="CA" AND kpgmid = 2131 AND iform_tp = "VW";
    
   if (SQLCODE==SQLNOTFOUND)
  {
    printf("FormFile not found in Form!!\n");
    goto optL_err;
  }
  
  strcpy(FormFile,rtrim(FormFile));
  strcpy(outputf, getFileName());
  sprintf_s(OutFile, sizeof OutFile,"%s.tx",outputf);
  rgu_init_report(FormFile,OutFile);
  msg = M_CM_OK;

  /* insert */
  strcpy(co_cname, laser_get_cname());
  strcpy(co_ename, laser_get_ename());
  strcpy(co_addr , laser_get_addr());

   switch(option[0])
  {
    case '6':
   	$DECLARE PLY_CUR_6 CURSOR FOR
   	 SELECT b.ipolicy,a.nassured,a.dply_begin,a.dply_end,c.itag,
           	 substr(c.nassured,1,9),c.iengine,c.ibody,c.nbrand_abbr,b.ibrand,
           	b.dply_begin,b.dply_end,(b.mlia_prem + b.mdmg_prem),b.dentry,
           	a.qperiod,a.qmiles,a.icar_flag,a.iparts,c.mkilo_ply,b.itmp_policy,c.iassured,
           	c.nowner,a.mcover1,c.mcar_price
      	FROM ca_ply_ext a, ply_relation b, policy c
     	WHERE a.ipolicy = $ipolicy_bgn
       	AND b.ipolicy >= $ply_bgn
       	AND b.ipolicy <= $ply_end
       	AND c.ipolicy = b.ipolicy
       	AND b.dentry <= $dentry
       	AND b.dpolicy IS NULL;
       	$OPEN PLY_CUR_6; 	
       	break;
       	
    case '7':
   	$DECLARE PLY_CUR_7 CURSOR FOR
   	 SELECT b.ipolicy,a.nassured,a.dply_begin,a.dply_end,b.dpolicy,c.itag,
           	 substr(c.nassured,1,9),c.iengine,c.ibody,c.nbrand_abbr,b.ibrand,
           	b.dply_begin,b.dply_end,(b.mlia_prem + b.mdmg_prem),b.dentry,
           	a.qperiod,a.qmiles,a.icar_flag,a.iparts,c.mkilo_ply,b.itmp_policy,c.iassured,
           	c.nowner,a.mcover1,c.mcar_price,
           	case when a.dpolicy >= '06/01/2018' then 'Y' else 'N' end
      	FROM ca_ply_ext a, ply_relation b, policy c
     	WHERE a.ipolicy = $ipolicy_bgn
       	AND b.ipolicy >= $ply_bgn
       	AND b.ipolicy <= $ply_end
       	AND b.dpolicy IS NOT NULL
       	AND c.ipolicy = b.ipolicy;
       	$OPEN PLY_CUR_7;
       	break;
       	
     default :
        if(exitsub(reply,M_CM_WRONG_OPTION) == True)
        {
   	       return M_CM_WRONG_OPTION;
        }
   }
   
	/* get today's date */
   strcpy(dpolicy,cm_edate_str(t));
   strcpy(dToday,cm_from_infdate_100(dpolicy));
   cm_split_ymd_100(dToday,nyy,nmm,ndd);
   
    $BEGIN WORK;
   
   while (1) {
   	if (strcmp(option,"6") == 0) {
   		$FETCH PLY_CUR_6 INTO 
   		   $ipolicy,$nassured_ext,$dply_begin_ext,$dply_end_ext,
   		   $itag,$nassured,$iengine,$ibody,$nbrand_abbr,
   		   $ibrand,$dply_begin,$dply_end,$mpremium,$dentry_ext,
   		   $qperiod,$qmiles,$icar_flag,$iparts,$mkilo_ply,$sIestimate,$sIassured,
   		   $nowner,$mcover1,$mcar_price;
printf("4 like seven [%s]\n",ipolicy);
      	} else {
      		$FETCH PLY_CUR_7 INTO
      		    $ipolicy,$nassured_ext,$dply_begin_ext,$dply_end_ext,
      		    $dpolicy,$itag,$nassured,$iengine,$ibody,$nbrand_abbr,
      		    $ibrand,$dply_begin,$dply_end,$mpremium,$dentry_ext,
      		    $qperiod,$qmiles,$icar_flag,$iparts,$mkilo_ply,$sIestimate,$sIassured,
      		    $nowner,$mcover1,$mcar_price,$f_1070601;
	}
   	
   	if (SQLCODE == SQLNOTFOUND) break;
        
   strcpy(dpolicy,trim(dpolicy));
   /* get date ends */
   
   /* set form title */
   /*1080912007_SC1_�ק�car306�O�T�I�����Y by 071004 2020/02/27*/
        if (strcmp(option,"6") == 0)
            strcpy(nins_kind_desc,"�s�w�F�ʮ��W�����T�������O�T�O�ΫO�I"); 
        else 
        {
        
   	    if(strncmp(f_1070601,"Y",1) == 0)
   	        strcpy(nins_kind_desc,"�s�w�F�ʮ��W�����T�������O�T�O�ΫO�I"); 
   	    else
   	        strcpy(nins_kind_desc,"�s�w�F�ʮ��W�����O�T�����d���O�I"); 
   	}
  

   	/* �O�渹�X */
   	strcat(nins_kind_desc, "���");
   	rgu_put_body_string(1,nins_kind_desc,1);
   	rgu_put_body_string(1,ipolicy_bgn,1);
   	rgu_put_body_string(1," ",1);
   	rgu_put_body_string(1,co_cname,1);
   	rgu_put_body_string(1,co_ename,1);
   	rgu_put_body_string(1,co_addr,1);

   	/* �]�I�ئW�٪��פ��P�A�p��_�l��m�A�H�K�m����� */
   	len1 = strlen(nins_kind_desc) / 4;
   	xpos_ma = 105 - ( 5 * len1);
   	xpos_mb = xpos_ma;

   	sprintf_s(spos_ma, sizeof spos_ma,"%d",xpos_ma);


	if(strcmp(option,"6") == 0)
	{
	    rgu_put_body_string(1,"����",1);
	}
	else
	{
	    if(strcmp(chkAdd,"1") == 0) 
	    {
	        rgu_put_body_string(1,"�ɵo",1);
	    }
	    else
	    {
		rgu_put_body_string(1,"",1);
	    }
	}
        

   	rgu_put_body_string(1,spos_ma,1);
   	rgu_put_body_string(1,nins_kind_desc,1);
   	
   	if (count==0)
   	   rgu_put_body(1);
   	   
    	if (count != 0)  
   	  rgu_put_body(99); /* ���� */  	   
   /* set ends */
        count++;
  
   	

        
        
   	/* Select nbrand */
   	$DECLARE PLY_CUR_1 CURSOR FOR
     	 SELECT nbrand
      	 FROM ca_car_model
      	 WHERE ibrand = $ibrand
      	 ORDER BY ipro_year;
      
   	$OPEN PLY_CUR_1;
   
    	while (1)
    	{
    		$FETCH PLY_CUR_1 INTO $nbrand;
    		if (SQLCODE == SQLNOTFOUND) break;
    	}
   	$CLOSE PLY_CUR_1;
   	$FREE PLY_CUR_1;
   	/* Select nbrand ends */
       
printf("seven likes 4 either[%s];;nbrand[%s]\n",ipolicy,nbrand);
   	strncpy(ipolicytmp, ipolicy, 3);
   	ipolicytmp[3]=0x0;
   	strcpy(temp1, "17");
   	strcat(temp1, ipolicytmp);
   	strcat(temp1, "�r��");
   	strncpy(temp2, ipolicy+3, 17);
   	temp2[17]=0x0;
   	strcat(temp1, trim(temp2));
   	strcat(temp1, "��" );

   	rgu_put_body_string(2,temp1,1);

   	strncpy(ipolicytmp, ply_bgn, 3);
   	ipolicytmp[3]=0x0;
   	strcpy(temp1, "17");
   	strcat(temp1, ipolicytmp);
   	strcat(temp1, "�r��");
   	strncpy(temp2, ply_bgn+3, 10);
   	temp2[10]=0x0;
   	strcat(temp1, trim(temp2));
   	strcat(temp1, "��" );

   	rgu_put_body_string(2,temp1,1);

   	rgu_put_body_string(2,nassured_ext,1);

   	/* �O�I���� */
   	strcpy(bch_date,cm_from_infdate_100(dply_begin_ext));
   	cm_split_ymd_100(bch_date,syy,smm,sdd);
   	strcpy(ech_date,cm_from_infdate_100(dply_end_ext));
   	cm_split_ymd_100(ech_date,eyy,emm,edd);

   	rgu_put_body_string(2,syy,2);
   	rgu_put_body_string(2,smm,2);
   	rgu_put_body_string(2,sdd,2);
   	rgu_put_body_string(2,"12",2);
   	rgu_put_body_string(2,eyy,2);
   	rgu_put_body_string(2,emm,2);
   	rgu_put_body_string(2,edd,2);
   	rgu_put_body_string(2,"12",2);
   	rgu_put_body(2);

   	/* �ӫO�d�� */
    	objnum = 0;

   	/* ��榳�Ĵ����W��u */
   	ypos = 57 + ((INS_LINE + objnum)  * LINE_HEIGTH);
   	sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
   	rgu_put_body_string(6,tempstr,1);
   	rgu_put_body_string(6,tempstr,1);

   	/* ��榳�Ĵ��� */
   	ypos = 57 + ((INS_LINE + objnum + 1)  * LINE_HEIGTH);
   	sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
   	rgu_put_body_string(6,tempstr,1);

   	strcpy(bch_date,cm_from_infdate_100(dpolicy));
   	cm_split_ymd_100(bch_date,syy,smm,sdd);
   	strcpy(ech_date,cm_from_infdate_100(dply_end_ext));
   	cm_split_ymd_100(ech_date,eyy,emm,edd);
   	rgu_put_body_string(6,syy,2);
   	rgu_put_body_string(6,smm,2);
   	rgu_put_body_string(6,sdd,2);
   	rgu_put_body_string(6,"12",2);
   	rgu_put_body_string(6,eyy,2);
   	rgu_put_body_string(6,emm,2);
   	rgu_put_body_string(6,edd,2);
   	rgu_put_body_string(6,"12",2);
   	/*rgu_put_body(5);*/
   
   	/* ��榳�Ĵ����U��u */
   	ypos = ypos + LINE_HEIGTH;
   	sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
   	rgu_put_body_string(6,tempstr,1);
   	rgu_put_body_string(6,tempstr,1);
   	rgu_put_body(6);
   

        /* �Ƶ� */
   	ypos = ypos + 1;
   	sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
   	rgu_put_body_string(41,tempstr,1);
   	rgu_put_body_string(41,tempstr,1);
   	ypos = ypos + 1 ;
   	sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
   	rgu_put_body_string(41,tempstr,1);
   	
   	rgu_put_body(41);

        
   	ypos = ypos + 2 * LINE_HEIGTH;
   	sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
   	rgu_put_body_string(42,tempstr,1);
   	rgu_put_body_string(42,tempstr,1);
   	rgu_put_body(42);

   	
   	
   
   
   	/* show date on the line 43 */
   	rgu_put_body_string(43,syy,1);
   	rgu_put_body_string(43,smm,1);
   	rgu_put_body_string(43,sdd,1);
   	
   	/*  ����j�g  */
   	num_to_chinese(year_chinese,qperiod);            
     	strcpy(year_chinese,trim(year_chinese));
     	strcat(year_chinese,"�Ӥ��");
	strcpy(tempstr,"(");
	strcat(tempstr,year_chinese);
						
     	num_to_chinese(mile_chinese,qmiles);
     	strcpy(mile_chinese,trim(mile_chinese));
     	strcat(mile_chinese,"����");
     	strcat(tempstr,mile_chinese);
     	strcat(tempstr,")");

	rgu_put_body_string(43,tempstr,1);
     	/* Ends of Chinese */
   	/* show date on the line 43 ends */
   
   	/* show iendorse details */
   	strcpy(tempstr,NULL);
   	strcat(tempstr,syy);
   	strcat(tempstr,".");
   	strcat(tempstr,smm);
   	strcat(tempstr,".");
   	strcat(tempstr,sdd);
   	rgu_put_body_string(43,tempstr,1);
   	rgu_put_body_string(43,itag,1);
   	strcpy(nowner,trim(nowner));
   	if(strcmp(nowner,"") == 0)
   	{
		if(exitsub(reply,M_CA_VW_PRINT) == True)
        {
        	$ROLLBACK WORK;
   	    	return M_CA_VW_PRINT;
        }
   	}
   	else
   	{
    	    /*���D�_��*/

    	    iTmp=itext=iTmp2=0;
    	    iTmp = iGetChinesePos(nowner,17);
	    strcpy(nowner_1,"");
	    strcpy(nowner_2,"");
	    strncpy(nowner_1,nowner,iTmp+1);
	    nowner_1[iTmp+1] = '\0';
	    itext = itext + iTmp + 1;
	 	
	    if (itext <= strlen(nowner))
	    {
	        iTmp2 = iGetChinesePos(nowner+itext,17);
	        strncpy(nowner_2,nowner+itext,iTmp2+1);
	        nowner_2[iTmp2+1] = '\0';
	        itext = itext + iTmp2 + 1;
	    }
	    else strcpy(nowner_2,"");
printf("nowner_1[%s]\n",nowner_1);
printf("nowner_2[%s]\n",nowner_2);
   	    rgu_put_body_string(43,nowner_1,1);
   	}
   	
   	
   
        /* Process Date */
       	strcpy(bch_date,cm_from_infdate_100(dply_begin));
       	cm_split_ymd_100(bch_date,syy,smm,sdd);
       	strcpy(ech_date,cm_from_infdate_100(dply_end));
       	cm_split_ymd_100(ech_date,eyy,emm,edd);

printf("org. date[%s],new year[%s],newmonth[%s],newday[%s]\n",ech_date,eyy,emm,edd);       	
        strcpy(tempstr,NULL);
   	strcat(tempstr,syy);
   	strcat(tempstr,".");
   	strcat(tempstr,smm);
   	strcat(tempstr,".");
   	strcat(tempstr,sdd);
   	strcat(tempstr,"-");
   	strcat(tempstr,eyy);
   	strcat(tempstr,".");
   	strcat(tempstr,emm);
   	strcat(tempstr,".");
   	strcat(tempstr,edd);
   	
   	rgu_put_body_string(43,tempstr,1);
   	
   	rgu_put_body_string(43,nbrand_abbr,1);
   	
     /* Process Date ends */
     
    
    	if (strlen(iengine) > 2)
    	{
    		rgu_put_body_string(43,iengine,1);
    	} else {
    		rgu_put_body_string(43,ibody,1);
    	}
   	
    	rgu_put_body_string(43,"(����12��)",1);
    	
    	/*�t�P�����_��*/

    	iTmp=itext=iTmp2=0;
    	iTmp = iGetChinesePos(nbrand,16);
	strcpy(nbrand_1,"");
	strcpy(nbrand_2,"");
	strncpy(nbrand_1,nbrand,iTmp+1);
	nbrand_1[iTmp+1] = '\0';
	itext = itext + iTmp + 1;
	 	
	if (itext <= strlen(nbrand))
	{
	    iTmp2 = iGetChinesePos(nbrand+itext,16);
	    strncpy(nbrand_2,nbrand+itext,iTmp2+1);
	    nbrand_2[iTmp2+1] = '\0';
	    itext = itext + iTmp2 + 1;
	}
	else strcpy(nbrand_2,"");
	 	
	 	
    	rgu_put_body_string(43,nbrand_1,1);
    	rgu_put_body_string(43,nbrand_2,1);
    	rgu_put_body(43);
    	
    	rgu_put_body(44);
    	/*rgu_put_body(45);*/
    	
    	ypos = ypos + 8 * LINE_HEIGTH;
    	sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
    	rgu_put_body_string(46,tempstr,1);

    	/* Access �O�T�s�� */
    	strcpy(tempstr,"�G.�O�T�s�� : ");
    	/*1080128009_SC1_���O�T�I���C�L�{��CAR306�BCAR307���O�T�s����� by 071004 2019.02.18*/
    	/*if (strcmp(icar_flag,"1") == 0)
    	{
    		strcat(tempstr,"�s��");
    	} else {
    		strcat(tempstr,"���j��");
    	}*/
    	if (strcmp(iparts,"1") == 0)
    	{
    	    strcat(tempstr,"����");
    		
    	} else {
    	    strcat(tempstr,"�ʤO�ǰʨt��");
    		
    	}
    	strcat(tempstr,"\0");
    	rgu_put_body_string(46,tempstr,1);

        /*1080912008_SC1_�O�T�I�����ܨ��{�Ƥ@�P by 071004 2020.02.27*/
	rfmtdouble(mkilo_ply,"<<,<<<,<<<,<<<",mkiloply_tmp);
	strcpy(tempstr,", �ӫO���{�� : ");
	strcat(tempstr,mkiloply_tmp);
	strcat(tempstr,"  ����");

	rgu_put_body_string(46,tempstr,1);
    	/* Ends of Access */
    	rgu_put_body(46);
    	
    	ypos = ypos + 2 * LINE_HEIGTH;  
   	sprintf_s(tempstr, sizeof tempstr,"%d", ypos); 
   	rgu_put_body_string(47,tempstr,1); 
   	   
     	
     	/*1060818002_C2_�O�T�I�{���ק�*/
      	
      	if(mcover1 == 0)
   	{
	     rfmtdouble(mcar_price,"<<<<<.<",mcar_price_tmp);
	     strcat(mcar_price_tmp,"�U��");
	     sprintf_s(tempstr, sizeof tempstr,"�T.�Q�O�T�T�������s���ȡG%s",mcar_price_tmp);
   	}
   	else
   	{
   	     /* �`�O�O */
	     rfmtlong(mpremium,"<<,<<<,<<<,<<<",mpremium_tmp);
	     printf(" mpremium = %s \n", mpremium_tmp);
	     sprintf_s(tempstr, sizeof tempstr,"�T.Ų��e���ƥ�,�Q�O�I�H���[ú�O�I�O %s",ascii_judge(mpremium_tmp, "NT"));
	     /* �`�O�O ends */
    	}	
      	rgu_put_body_string(47,tempstr,1);
      	
   	rgu_put_body(47);
   	   
   	if(mcover1 == 0)
   	{
	    ypos = ypos + 2 * LINE_HEIGTH;  
	    sprintf_s(tempstr, sizeof tempstr,"%d", ypos); 
	    rgu_put_body_string(48,tempstr,1); 
	    rfmtlong(mpremium,"<<,<<<,<<<,<<<",mpremium_tmp);
	    printf(" mpremium = %s \n", mpremium_tmp);
	    sprintf_s(tempstr, sizeof tempstr,"�|.Ų��e���ƥ�,�Q�O�I�H���[ú�O�I�O %s",ascii_judge(mpremium_tmp, "NT"));
	    rgu_put_body_string(48,tempstr,1);
	    rgu_put_body(48);
        }
   	
   	ypos = ypos + 2 * LINE_HEIGTH;; 
   	sprintf_s(tempstr, sizeof tempstr,"%d",ypos); 
   	rgu_put_body_string(49,tempstr,1);
   	rgu_put_body(49);
   	 
   	ypos = ypos + 2 * LINE_HEIGTH; 
   	sprintf_s(tempstr, sizeof tempstr,"%d",ypos); 
   	rgu_put_body_string(50,tempstr,1); 
   	rgu_put_body(50);
   
   	/* Bottom */
  
  	strncpy(co_place,ipolicy_bgn+2,1);
  	co_place[1]=0x0;
       
  	$select nchi_abv
           into $nchi_abv
           from branch
       	  where ibranch_abbr = $co_place;
       
  	if(SQLCODE != 0) strcpy(nchi_abv, " ");
       
   	rgu_put_body_string(9,nyy,1);
   	rgu_put_body_string(9,nmm,1);
   	rgu_put_body_string(9,ndd,1);
   	rgu_put_body_string(9,nchi_abv);
       
   	rgu_put_body(9);
   	   
   	  /* put page fragement */

   	  /* put ends */
   	
   	   /* �N���n��T�g�^db */
        printf("update dpolicy of ply_relation[%s]\n",ipolicy);
  	$UPDATE ply_relation 
            SET fprint = "1", dpolicy = $dpolicy  
          WHERE fcard_class = '2'
            AND dply_close is NULL
            AND ipolicy = $ipolicy
            AND dpolicy is NULL;
  	   /* �g�^db ends */
  	
        /*  1031111001_C1 ���O�X������{���վ�  */
        rc = Upd_Cm_pre_receive(sIestimate, ipolicy, sIassured);
        if (rc != SUCCESS)
        {
            $ROLLBACK WORK;
            return rc;      	         		            		
        }
   }
   
   if (strcmp(option,"6") == 0) {
   	$CLOSE PLY_CUR_6;
   	$FREE PLY_CUR_6;
   } else {
   	$CLOSE PLY_CUR_7;
   	$FREE PLY_CUR_7;
   }

   rgu_put_body(91); /* ��ȧX */
  /********************************** ��椺�e END *******************************/
 
  rgu_finish_report();

  /* if there's no policy that can be printed */
  if (count == 0)
  {
    printf("�L���i�C�L\n");
    $ROLLBACK WORK;
    /*SQLCODE = M_CA_NREL_PLY;
    goto optL_err;*/
    if(exitsub(reply,M_CA_NOREC_ERR) == True)
        {
   	       return M_CA_NOREC_ERR;
        }
  }
  
  if (msg == M_CM_OK)
  {
        res = getApHome(aphome);
        if (res<0)
        {
            printf("In sigalrmcatcher func==>read config file error!!\n");
            $ROLLBACK WORK;
            return res;
        }
 
        gethostname(hostname,sizeof(hostname));
        sprintf_s(tmpOutFile, sizeof tmpOutFile, "%s/reportfile/%s", aphome,OutFile);
  }

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s %d", msg, hostname, tmpOutFile, PgLine);

  tmp_len = cm_buf_len(ReplyBuf);

  if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  {
      $ROLLBACK WORK;
      return apiRC;
  }
    
  $COMMIT WORK;
  return M_CM_OK;

optL_err:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    /*$ROLLBACK WORK;*/
    return SQLCODE;

 errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return SQLCODE;
}

/************************************************************************/
long ca_rpt_eb_L(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
  int   rc=0;
  char  tempstr[121];
  char  OutFile[21],outputf[21],tmpOutFile[51];
  char  hostname[20];
  int   res=0, xpos_ma=0, xpos_mb=0;
  long  msg=0;
  char  aphome[40];
  int   tmp_len=0,i=0;
  char  bch_date[12],ech_date[12];
  char  nyy[4],nmm[3],ndd[3];
  char  syy[4],smm[3],sdd[3],eyy[4],emm[3],edd[3];  /*��O�I����*/
  int   count,count1,cnt;
	
  /* variables using in DB */
  $char DBName[DBNAME],userid[11];
  $char FormFile[21];
  $int  PgLine=0,count_pass=0,count_receive=0;
  $char co_cname[101],co_ename[101],co_addr[101];
  
  $char sIpolicy[21],sIlast_ply[21],sIassured[13],sIply_area[11],sIestimate[21],iassured_pt[13];
  $char sIendorse[21],feedr[2],siserno[3],stmt3[512];
  $char dpolicy[11],sDply_begin[11],sDply_end[11],fstatus[3],sFassured[2];
  $char sFeply[2],sIroute[21],sPasswd[13],sIapplicant[13],sIcomp_in[3],sAemail_eply[51],sTmobile_eply[21],yyyy[5];
  $int  eply_cnt=0,iserno=0,chk_ftype=0;
  $char e_nfile[36];
  $varchar sNassured[121],sApayment[91],sAassured[91];
  $char sIengine[CA_ENGINE_NUM],sIbrand[9],nbrand[31],sIins_type[7],sNins_type[29];
  $long sMdeduct=0,sMins_premium=0,mpremium=0,sMinjured_cover=0,sMdamage_cover=0,sMinjured,sMdamage=0;
  $char sMdeduct_tmp[19],sMcover_tmp[19],sMins_premium_tmp[19],sMinjured_tmp[6],sMdamage_tmp[6];
  $char sMcar_price_tmp[11],mpremium_tmp[19];
  $double sMcar_price;
  
  $char    itype[2],iversion[2],iprint[11],dreceipt[11],fnote[2]; 
  
  /* variables for form */
  int print_line=0, ypos=0, len1=0;
  char ipolicytmp[4],ipolicytmp2[15],stmt[101],stmt1[101],stmt2[101];
  char ilast_ply_tmp[4],ilast_ply_tmp2[15];
  char nins_kind_desc[51],spos_ma[11];
  
  /* variables from client */
  char inputDate1[10],inputDate2[10],sIbranch[4],ikind[2];
  $char ply_bgn[21],ply_end[21],bigipolicy[2],ProtectData[2];
  $char str_sEterms[2],feterms[2];
  $char dentry1[11],dentry2[11];
  $char co_place[2],nchi_abv[21],chkAdd[2];
  $char dToday[11];
  long t=0;
  
  $char stmt_ncont[1024],ncontract[21],viins_type[7],ncontent1[251],ncontent2[251];
  
  t = cm_today();
  
  cm_buf_get("%s %s",DBName,userid);
      
  if(strcmp(option,"8") == 0){
  	cm_buf_get("%s",inputDate1);
  	cm_buf_get("%s",inputDate2);
  	cm_buf_get("%s",ply_bgn);
  	cm_buf_get("%s",ply_end);
  	cm_buf_get("%s",bigipolicy);
  	cm_buf_get("%s",ProtectData);
  	
  	strcpy(dentry1, cm_to_infdate(inputDate1));
  	strcpy(dentry2, cm_to_infdate(inputDate2));
  }
  else{
  	cm_buf_get("%s",ply_bgn);
  	cm_buf_get("%s",ply_end);
  	cm_buf_get("%s",chkAdd);
  	cm_buf_get("%s",bigipolicy);
  	cm_buf_get("%s",ProtectData);
  	cm_buf_get("%s",str_sEterms);
  }
  
  $WHENEVER SQLERROR GOTO errexit;
  if (db_select(DBName) == False)
  {
  	if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
  	    return M_CM_DB_NOTOPEN;
  	else  
  	    return apiRC;
  }
  
  $SELECT kpgnum_line,nform_file INTO $PgLine,$FormFile
     FROM form
    WHERE ksys_grp="CA" AND kpgmid = 2131 AND iform_tp = "EB";
    
   if (SQLCODE==SQLNOTFOUND)
  {
  	printf("FormFile not found in Form!!\n");
  	goto optL_err;
  }
  
  strcpy(FormFile,rtrim(FormFile));
  strcpy(outputf, getFileName());
  sprintf_s(OutFile, sizeof OutFile,"%s.tx",outputf);
  rgu_init_report(FormFile,OutFile);
  msg = M_CM_OK;

  /* insert */
  strcpy(co_cname, laser_get_cname());
  strcpy(co_ename, laser_get_ename());
  strcpy(co_addr , laser_get_addr());
  
  if(strcmp(option,"8") == 0){ 
  	$DECLARE PLY_CUR_8 CURSOR for
  	  SELECT a.itmp_policy,a.ipolicy,a.ilast_ply,b.nassured,b.iassured,b.apayment,b.aassured,
  	         a.ibrand,b.iengine,b.iply_area,b.mcar_price,a.dply_begin,a.dply_end,b.fassured,
  	         a.feply,b.iroute,b.iassured,b.iapplicant,a.icomp_in,a.aemail_eply,a.tmobile_eply,
  	         year(today),a.feterms
  	    FROM ply_relation a, policy b
     	   WHERE a.ipolicy = b.ipolicy
       	     AND a.ipolicy >= $ply_bgn
       	     AND a.ipolicy <= $ply_end
       	     AND a.dentry >= $dentry1
       	     AND a.dentry <= $dentry2
       	     AND a.dpolicy IS NULL;
       	
       	$OPEN PLY_CUR_8;
  }
  else{
  	$DECLARE PLY_CUR_9 CURSOR for
  	SELECT a.ipolicy,a.ilast_ply,b.nassured,b.iassured,b.apayment,b.aassured,
  	       a.ibrand,b.iengine,b.iply_area,b.mcar_price,a.dply_begin,a.dply_end,b.fassured,
  	       a.feply,b.iroute,b.iassured,b.iapplicant,a.icomp_in,a.aemail_eply,a.tmobile_eply,
  	       year(today),a.feterms
  	  FROM ply_relation a, policy b
     	 WHERE a.ipolicy = b.ipolicy
       	   AND a.ipolicy >= $ply_bgn
       	   AND a.ipolicy <= $ply_end     	
       	   AND a.dpolicy IS NOT NULL;
       	
       	$OPEN PLY_CUR_9;	
  }	
  
  $BEGIN WORK;
  count = count1 = 0;
  
  for(;;)
  {
  	if(strcmp(option,"8") == 0){
  		$FETCH PLY_CUR_8 INTO $sIestimate,$sIpolicy,$sIlast_ply,$sNassured,$sIassured,$sApayment,$sAassured,
   		                      $sIbrand,$sIengine,$sIply_area,$sMcar_price,$sDply_begin,$sDply_end,$sFassured,
   		                      $sFeply,$sIroute,$sPasswd,$sIapplicant,$sIcomp_in,$sAemail_eply,$sTmobile_eply,
   		                      $yyyy,$feterms;
   	}else{
   		$FETCH PLY_CUR_9 INTO $sIpolicy,$sIlast_ply,$sNassured,$sIassured,$sApayment,$sAassured,
   		                      $sIbrand,$sIengine,$sIply_area,$sMcar_price,$sDply_begin,$sDply_end,$sFassured,
   		                      $sFeply,$sIroute,$sPasswd,$sIapplicant,$sIcomp_in,$sAemail_eply,$sTmobile_eply,
   		                      $yyyy,$feterms;	
   	}
   	
   	if (SQLCODE == SQLNOTFOUND) break;
   	count++;
    
    	/* get today's date */
	strcpy(dpolicy,cm_edate_str(t));  
	strcpy(dToday,cm_from_infdate_100(dpolicy));
	cm_split_ymd_100(dToday,nyy,nmm,ndd);
	/* get date ends */
    
	/* �q�l���ڵ��O�P�_(1101201016_SC1) */
	printf("str_sEterms[%s]\n",str_sEterms);
	if(strcmp(option,"8") != 0){
		if (strcmp(str_sEterms,"0")==0 ){
			/*�̷̳s�O����*/
			strcpy(feterms,trim(feterms));
		}else if(strcmp(str_sEterms,"1")==0){
			/*�q�l����*/
			strcpy(feterms,"1");
		}else{
			/*�ȥ�����*/
			strcpy(feterms,"0");
		}
		printf("feterms[%s]\n",feterms);
	}
	
	if (strcmp(sFeply,"1") == 0)
	{
		$select count(*) into $eply_cnt
                   from cm_e_policy
                  where ipolicy = $sIpolicy;
                
                if (eply_cnt!=0) strcpy(sFeply,"0");
	}
	
	if((strcmp(option,"8") == 0)&&(strcmp(sFeply,"1") == 0)){
		/* EB�i�ιq�l�O��(1100712007_SC7) */
		/* 1060328006_C1 �s�W�q�l�O�椽�ΫH�c(�q�ӳ��ϥ�) */
		if (strcmp(sIroute,"JB") == 0) strcpy(sIcomp_in , "88");
		
		/* �q�l�O�椣�ݦL�X�ȥ���ơA�ݱN�O���Ƽg�J�q�l�O������ */
		/*�O�o���ɦW*/
		strcpy(e_nfile,"");
		strcat(e_nfile,"P17CAR_");
		strcat(e_nfile,trim(sIpolicy));
		strcat(e_nfile,"_");
		strcat(e_nfile,trim(yyyy));
		strcpy(e_nfile,trim(e_nfile));
		
		/*�O�o�q�l�O��*/
		$INSERT INTO cm_e_policy(iins_cat,ipolicy,iendorse,iserno,ftype,fspeed,iins_kind_ply,iendorse_ti,
            	                         fprocess,fdata,ibranch_code,icustomer,npassword,nemai_send,tsms_mobile,
            	                         nfile,dbgn,dend,fstatus,iapplicant,iassured,ientry,dentry,iupdate,dupdate,
            	                         nplyidx1,nplyidx2,nplyidx3,nedridx1,nedridx2,nedridx3)
				 VALUES ('C',$sIpolicy,' ','01','2','1','C2',' ',
				         'A','P',$sIcomp_in,$sIapplicant,$sPasswd,$sAemail_eply,$sTmobile_eply,
				         $e_nfile,$sDply_begin,$sDply_end,100,$sIapplicant,$sIassured,$userid,CURRENT,$userid,CURRENT,
				         ' ',' ',' ',' ',' ',' ');
	}else if((strcmp(option,"9") == 0)&&(strcmp(sFeply,"1") == 0)){	
		/*** �D�q�l�O��ݥ���אּ�q�l�O���A�ɱH�e�q�l�O�� ***/
		/*** ��w���q�l�O��A�����z�Le�O���ɵo�q�l�O�� ***/
		strcpy(sIendorse, "");
		sprintf_s(stmt3, sizeof stmt3, " SELECT first 1 iendorse,feedr "
		              "   FROM edr_relation "
		              "  WHERE ipolicy = '%s'"
		              "    AND iendorse not like '%%CVP%%'"
		              "  ORDER BY dcreate DESC; ", sIpolicy );
		$PREPARE prep1 FROM $stmt3;
		$EXECUTE prep1 INTO $sIendorse,$feedr;
		
		if (strcmp(feedr,"2") != 0)
            	{
            		$ROLLBACK WORK;            		
			return 0;
		}
		
		/* 1060328006_C1 �s�W�q�l�O�椽�ΫH�c(�q�ӳ��ϥ�) */
		if (strcmp(sIroute,"JB") == 0) strcpy(sIcomp_in , "88");
		
		/* �q�l�O�椣�ݦL�X�ȥ���ơA�ݱN�O���Ƽg�J�q�l�O������ */
		$select nvl(max(iserno),0)+1
		   into $iserno
		   from cm_e_policy
		  where ipolicy = $sIpolicy;
		
		sprintf_s(siserno, sizeof siserno, "%02d", iserno);  
		
		/*�O�o���ɦW*/
		strcpy(e_nfile,"");
		strcat(e_nfile,"P17CAR_");
		strcat(e_nfile,trim(sIpolicy));
		strcat(e_nfile,"_");
		strcat(e_nfile,trim(yyyy));
		strcpy(e_nfile,trim(e_nfile));
		
		/*�P�_�O�_���ǰe�L�O�o����*/
		$select count(*)
		   into $chk_ftype
		   from cm_e_policy
		  where ipolicy = $sIpolicy and ftype='2' and iins_cat='C';
		
		if(chk_ftype > 0 )  /*�j��0���ܦ��ǰe�L�O�o����-->�쬰�q�l(�O�o)�ɵo�q�l(�O�o)*/
		{
			$ROLLBACK WORK;            		
			return 0;
		}
		else  /*����0���ܥ��ǰe�L�O�o����-->�쬰�ȥ��ɵo�q�l or �쬰�q�l(TWCA)�ɵo�q�l(�O�o)*/ 
		{
			$INSERT INTO cm_e_policy (iins_cat,ipolicy,iendorse,iserno,ftype,fspeed,iins_kind_ply,
                                                  iendorse_ti,fprocess,fdata,ibranch_code,icustomer,npassword,
                                                  nemai_send,tsms_mobile,nfile,dbgn,dend,fstatus,
                                                  iapplicant,iassured,ientry,dentry,iupdate,dupdate,
                                                  nplyidx1,nplyidx2,nplyidx3,nedridx1,nedridx2,nedridx3)
                                          VALUES ('C',$sIpolicy,$sIendorse,$siserno,'2','1','C2',
                                                  '', 'A','P',$sIcomp_in,$sIapplicant,$sPasswd,
                                                  $sAemail_eply,$sTmobile_eply,$e_nfile,$sDply_begin,$sDply_end,100,
                                                  $sIapplicant,$sIassured,$userid,CURRENT,'car3071',CURRENT,
                                                  ' ',' ',' ',' ',' ',' '); 
                }

	}else{
		/* �ȥ� */
		sprintf_s(stmt_ncont, sizeof stmt_ncont,"SELECT max(ncontract ),a.iins_type "
		                   "  FROM  ca_terms a, ply_ins_type b"
		                   " WHERE a.iins_type = b.iins_type"
		                   "   AND  b.ipolicy = '%s' "
		                   "   AND  deffect <= '%s' "
		                   "   AND  dcreate <= '%s' "
		                   " GROUP BY a.iins_type "
		                   " ORDER BY 1 DESC ",sIpolicy,sDply_begin,dpolicy);
		$PREPARE term_eb FROM $stmt_ncont;
		printf("stmt_ncont[%s]\n",stmt_ncont);
		$DECLARE term_ncon_eb CURSOR FOR term_eb;
		$OPEN term_ncon_eb;
		$FETCH term_ncon_eb INTO $ncontract,$viins_type;
		$CLOSE term_ncon_eb;
		$FREE  term_ncon_eb;
		
		$SELECT ncontent1,ncontent2
		   INTO $ncontent1,$ncontent2
		   FROM ca_terms
		  WHERE ncontract = $ncontract
		    AND iins_type = $viins_type;
		
		strcpy(ncontent1,trim(ncontent1));
		strcpy(ncontent2,trim(ncontent2));
		if(strlen(ncontent1) == 0) strcpy(ncontent1," ");
		if(strlen(ncontent2) == 0) strcpy(ncontent2," ");
		printf("\n---ncontent1[%s]\n",ncontent1);
		printf("\n---ncontent2[%s]\n",ncontent2);
		
		strcpy(nins_kind_desc,"�s�w�F�ʮ��W�����q�ʦۦ樮��X�O�I�O�I��");
		
		rgu_put_body_string(1,nins_kind_desc,1);
		rgu_put_body_string(1,ncontent1,2);
		rgu_put_body_string(1,ncontent2,2);
		rgu_put_body_string(1,co_cname,1);
		rgu_put_body_string(1,co_ename,1);
		rgu_put_body_string(1,co_addr,1);
		
		printf("nins_kind_desc[%s]",nins_kind_desc);
		printf("co_cname[%s]",co_cname);
		printf("co_ename[%s]",co_ename);
		printf("co_addr[%s]",co_addr);
		
		if(strcmp(option,"8") == 0){
			rgu_put_body_string(1,"����",1);
		}else{
			if(strcmp(chkAdd,"1") == 0) {
				rgu_put_body_string(1,"�ɵo",1);
			}else{
				rgu_put_body_string(1,"",1);
			}
		}
		
		/* �]�I�ئW�٪��פ��P�A�p��_�l��m�A�H�K�m����� */
		len1 = strlen(nins_kind_desc) / 4;
		xpos_ma = 105 - ( 5 * len1);
		xpos_mb = xpos_ma;
		
		sprintf_s(spos_ma, sizeof spos_ma,"%d",xpos_ma);
		rgu_put_body_string(1,spos_ma,1);
		rgu_put_body_string(1,nins_kind_desc,1);
		rgu_put_body_string(1,"0",2);
		rgu_put_body_string(1,"0",2);
		
		rgu_put_body(1);
		
		/*�Ӹ�B�n*/
		if(strncmp(ProtectData,"1",1) == 0 )                    
		{
			if( sFassured[0] == '1' || sFassured[0] == '3' || sFassured[0] == '5' )
			{
				/*�����Ҹ��X*/
				strcpy(iassured_pt, sIassured);
				strcpy(sIassured,substring(iassured_pt,1,4));
				strcat(sIassured,"****");
				strcat(sIassured,substring(iassured_pt,9,2));
			}
		}
		
		strcpy(bigipolicy,trim(bigipolicy));
		if (strcmp(bigipolicy,"1") == 0){
			if (count == 1){
				strncpy(ipolicytmp, sIpolicy, 3);
				ipolicytmp[3]=0x0;
				strncpy(ipolicytmp2, sIpolicy+3, 14);
				ipolicytmp2[14]=0x0;
				strcpy(stmt1,"17");
				strcat(stmt1,ipolicytmp);
				strcat(stmt1,"�r��");
				strcat(stmt1,ipolicytmp2);
				strcat(stmt1,"��");
				strcat(stmt1,"  �ԫO�����");
				
				rgu_put_body_string(2,stmt1,1);
				strcpy(stmt1,sNassured);
				strcat(stmt1," �ԫO�����");
				rgu_put_body_string(2,stmt1,1);
				rgu_put_body_string(2,"",1);
				rgu_put_body_string(2,"",1);
				rgu_put_body_string(2,"",1);
				rgu_put_body_string(2,"",1);
				rgu_put_body_string(2,"",1);
				rgu_put_body_string(2,"",1);
				rgu_put_body_string(2,"",1);
				rgu_put_body_string(2,"",1);
				rgu_put_body_string(2,"",1);
				rgu_put_body_string(2,"",1);
				rgu_put_body_string(2,"",1);
				rgu_put_body_string(2,"",1);
				rgu_put_body_string(2,"",1);
				rgu_put_body_string(2,"",1);
				rgu_put_body_string(2,"",1);   
				rgu_put_body(2);
				rgu_put_body_string(7,"",1);
				rgu_put_body(7);
				
				strcpy(sIpolicy,trim(sIpolicy));
				if(strlen(sIpolicy) == 17){ 
					rgu_put_body_string(8,sIpolicy,1);
					rgu_put_body(8);
				}
				else{
					rgu_put_body_string(11,sIpolicy,1);
					rgu_put_body(11);
				}
				
				ypos = 161;
				sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
				rgu_put_body_string(81,tempstr,1);
				 /* EB�q�l����(1101201016_SC1) */
				 if (strcmp(feterms,"1")==0){
				 	rgu_put_body_string(81,str_feterms1,1);
				 	rgu_put_body_string(81,str_feterms2,1);
				 }else{
				 	rgu_put_body_string(81,"",1);
				 	rgu_put_body_string(81,"",1);
				 }
				 rgu_put_body(81); 
			} 
		}else{
			if (count1 != 0) rgu_put_body(99); /* ���� */
			count1++;
			
			strcpy(ipolicytmp,"");
			strcpy(ipolicytmp2,"");  
			strncpy(ipolicytmp, sIpolicy, 3);
			ipolicytmp[3]=0x0;
			strncpy(ipolicytmp2, sIpolicy+3, 14);
			ipolicytmp2[14]=0x0;
			strcpy(stmt1,"17");
			strcat(stmt1,ipolicytmp);
			strcat(stmt1,"�r��");
			strcat(stmt1,ipolicytmp2);
			strcat(stmt1,"��");
			
			strcpy(sIpolicy,trim(sIpolicy));
			if(strlen(sIpolicy) == 17){ 
				rgu_put_body_string(8,sIpolicy,1);
				rgu_put_body(8);
			}else{
				rgu_put_body_string(11,sIpolicy,1);
				rgu_put_body(11);
			}
			
			strcpy(ilast_ply_tmp,"");
			strcpy(ilast_ply_tmp2,"");
			
			strcpy(sIlast_ply,trim(sIlast_ply)); 	
			if(strlen(sIlast_ply) == 0 )
			{
				strcat(stmt1,"  ���O��Y");
				strcat(stmt1,"     ");
				strcat(stmt1,"�r��");
				strcat(stmt1,"          ");
				strcat(stmt1,"���O����O");	
			}else{
				strncpy(ilast_ply_tmp, sIlast_ply, 3);
				ilast_ply_tmp[3]=0x0;
				strncpy(ilast_ply_tmp2, sIlast_ply+3, 14);
				ilast_ply_tmp2[14]=0x0;
				strcpy(ilast_ply_tmp2,trim(ilast_ply_tmp2));
				strcat(stmt1,"  ���O��Y");
				strcat(stmt1,"17");
				strcat(stmt1,ilast_ply_tmp);
				strcat(stmt1,"�r��");
				strcat(stmt1,ilast_ply_tmp2);
				strcat(stmt1,"���O����O");
			}
			
			rgu_put_body_string(2,stmt1,1);
			rgu_put_body_string(2,sNassured,1);
			rgu_put_body_string(2,sIassured,1);
			rgu_put_body_string(2,sApayment,1);
			rgu_put_body_string(2,sAassured,1);
			rgu_put_body_string(2,sIbrand,1);  	
			rgu_put_body_string(2,sIengine,1);
			rgu_put_body_string(2,"�x�W�B���B�����B�����άF���Ϊv�v�ҤΤ���L�a��",1);
			rfmtdouble(sMcar_price,"<<<<<.<",sMcar_price_tmp);
			strcat(sMcar_price_tmp,"�U��");
			rgu_put_body_string(2,sMcar_price_tmp,1);
			
			/* �O�I���� */
			strcpy(bch_date,cm_from_infdate_100(sDply_begin));
			cm_split_ymd_100(bch_date,syy,smm,sdd);
			strcpy(ech_date,cm_from_infdate_100(sDply_end));
			cm_split_ymd_100(ech_date,eyy,emm,edd);
			
			rgu_put_body_string(2,syy,2);
			rgu_put_body_string(2,smm,2);
			rgu_put_body_string(2,sdd,2);
			rgu_put_body_string(2,"12",2);
			rgu_put_body_string(2,eyy,2);
			rgu_put_body_string(2,emm,2);
			rgu_put_body_string(2,edd,2);
			rgu_put_body_string(2,"12",2);
			
			rgu_put_body(2);
			rgu_put_body(10);
			rgu_put_body(3);
			
			/* �O�I�����B�ۭt�B�B�O�I���B�B�O�I�O */
			$DECLARE PLY_INS_TYPE CURSOR for
			  SELECT a.iins_type,a.mdeduct,b.nins_type,
			         a.minjured_cover,a.mdamage_cover,a.mins_premium
			    FROM ply_ins_type a, insurance_type b
			   WHERE a.iins_type = b.iins_type
			     AND a.ipolicy = $sIpolicy;
			
			$OPEN PLY_INS_TYPE;
			cnt = 0;
			mpremium = 0;
			
			for(;;)
			{
				$FETCH PLY_INS_TYPE INTO $sIins_type,$sMdeduct,$sNins_type,
				                         $sMinjured_cover,$sMdamage_cover,$sMins_premium;
				if (SQLCODE == SQLNOTFOUND) break;
				cnt++;
				
				strcpy(stmt,trim(sIins_type));
				strcat(stmt," ");
				strcat(stmt,sNins_type);
				
				strcpy(sIins_type,trim(sIins_type));
				if(strcmp(sIins_type,"103") == 0)
				{
					sMinjured = sMinjured_cover / 10000;
					sMdamage = sMdamage_cover / 10000;
					rfmtlong(sMinjured,"<,<<<",sMinjured_tmp);
					rfmtlong(sMdamage,"<,<<<",sMdamage_tmp);
					strcpy(stmt2,trim(sMinjured_tmp));
					strcat(stmt2,"�U");
					strcat(stmt2,"/");
					strcat(stmt2,trim(sMdamage_tmp));
					strcat(stmt2,"�U");
				}else{
					rfmtlong(sMdamage_cover,"<<,<<<,<<<,<<<,<<<",stmt2);
				}	
				
				rfmtlong(sMdeduct,"<<,<<<,<<<,<<<,<<<",sMdeduct_tmp);
				rfmtlong(sMins_premium,"<<,<<<,<<<,<<<,<<<",sMins_premium_tmp); 
				
				mpremium = mpremium + sMins_premium;                       
				
				rgu_put_body_string(4,stmt,1);
				rgu_put_body_string(4,sMdeduct_tmp,2);
				rgu_put_body_string(4,stmt2,2);
				rgu_put_body_string(4,sMins_premium_tmp,2);
				rgu_put_body(4);
			}
			$CLOSE PLY_INS_TYPE;
			$FREE  PLY_INS_TYPE;  
			
			rgu_put_body(5);
			
			ypos = 125 + (cnt*5);
			sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
			rgu_put_body_string(6,tempstr,1);
			rgu_put_body_string(6,tempstr,1);
			
			/* �`�O�I�O */
			ypos = ypos + 1;
			sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
			rgu_put_body_string(6,tempstr,1);
			rfmtlong(mpremium,"<<,<<<,<<<,<<<,<<<",mpremium_tmp);
			rgu_put_body_string(6,mpremium_tmp,1);
			
			ypos = ypos + 5;
			sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
			rgu_put_body_string(6,tempstr,1);
			rgu_put_body_string(6,tempstr,1);
			rgu_put_body(6);
			
			ypos = ypos + 10;
			sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
			rgu_put_body_string(81,tempstr,1);
			/* EB�q�l����(1101201016_SC1) */
			if (strcmp(feterms,"1")==0){
				rgu_put_body_string(81,str_feterms1,1);
				rgu_put_body_string(81,str_feterms2,1);
			}else{
				rgu_put_body_string(81,"",1);
				rgu_put_body_string(81,"",1);
			}
			rgu_put_body(81);
		}  
		strncpy(co_place,ply_bgn+2,1);
		co_place[1]=0x0;
		
		$SELECT nchi_abv
		   INTO $nchi_abv
		   FROM branch
		  WHERE ibranch_abbr = $co_place;
		if(SQLCODE != 0) strcpy(nchi_abv, " ");
		
		rgu_put_body_string(9,nyy,1);
		rgu_put_body_string(9,nmm,1);
		rgu_put_body_string(9,ndd,1);
		rgu_put_body_string(9,nchi_abv);
		rgu_put_body(9);
		
		rgu_put_body(91);
	}   /* �ȥ�END */
  	
  	/* �N���n��T�g�^db */
  	printf("update dpolicy of ply_relation[%s]\n",sIpolicy);
  	$UPDATE ply_relation 
      	    SET fprint = "1", dpolicy = $dpolicy  
      	  WHERE fcard_class = '2'
      	    AND dply_close is NULL
      	    AND ipolicy = $sIpolicy
      	    AND dpolicy is NULL;
  	/* �g�^db ends */
  	
  	if(strcmp(option,"8") == 0){ 
  		/* �^���@�γ������� ---------------------------------------------- */
  		/*  1031111001_C1 ���O�X������{���վ� (Upd_Cm_pre_receive() �b caxxxlib.ec) */
  		rc = Upd_Cm_pre_receive(sIestimate, sIpolicy, sIassured);
  		if (rc != SUCCESS)
  		{
  			$ROLLBACK WORK;
  			return rc;
  		}
        
        /* => ��I�s Upd_Cm_pre_receive()  
        $select count(ipre_rcv) into $count_pass
           from ao_prercv_pass
          where iins_cat = 'C'
            and ipre_rcv = $sIestimate
            and iins_kind = '2' ;
        $select count(ipre_rcv) into $count_receive
           from cm_pre_receive
          where iins_cat = 'C'
            and ipre_rcv = $sIestimate
            and iins_kind = '2' ;

				printf("519:sIestimate=[%s]count_pass[%d]count_receive=[%d]\n",sIestimate, count_pass,count_receive);
        if (count_receive > 0)
        {
        	if (count_pass > 0)
        			strcpy(fstatus, "60"); * �w�X��,�w���O *
        	else
        			strcpy(fstatus, "30"); * �w�X��,�����O *

        		 $update cm_pre_receive
        		    set dprint = current,
        		        fstatus = $fstatus,
        		        ftype_pol = 'EB',
        		        paydate = ''
        		  where iins_cat = 'C'
                and ipre_rcv = $sIestimate
                and iins_kind = '2';
        }*/
        }  
   }
   if (strcmp(option,"8") == 0) {
   	$CLOSE PLY_CUR_8;
   	$FREE  PLY_CUR_8;
   }
   else{
   	$CLOSE PLY_CUR_9;
   	$FREE  PLY_CUR_9;
   }  
   	
  rgu_finish_report();
  
  if (count == 0)
  {
    printf("�L�O��i�C�L\n");
    $ROLLBACK WORK;
    /*SQLCODE = M_CA_NREL_PLY;
    goto optL_err;*/
    if(exitsub(reply,M_CA_NOREC_ERR) == True)
    {
   	   return M_CA_NOREC_ERR;
    }
  }
  
    if (msg == M_CM_OK)
    {
        res = getApHome(aphome);
        if (res<0)
        {
            printf("In sigalrmcatcher func==>read config file error!!\n");
            $ROLLBACK WORK;
            return res;
        }

        gethostname(hostname,sizeof(hostname));
        sprintf_s(tmpOutFile, sizeof tmpOutFile, "%s/reportfile/%s", aphome,OutFile);
    }

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %d", msg, hostname, tmpOutFile, PgLine);

    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    {
    	$ROLLBACK WORK;
        return apiRC;
    }
   
    $COMMIT WORK;
    return M_CM_OK;

optL_err:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    /*$ROLLBACK WORK;*/
    return SQLCODE;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return SQLCODE;
}

/************************************************************************/
long ca_rpt_tv_L(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	int   rc=0;
  char  tempstr[121];
  char  OutFile[21],outputf[21],tmpOutFile[51];
  char  hostname[20];
  int   res=0, xpos_ma=0, xpos_mb=0;
  long  msg=0;
  char  aphome[40];
  int   tmp_len=0,i=0;
  char  bch_date[12],ech_date[12];
  char  nyy[4],nmm[3],ndd[3];
  char  syy[4],smm[3],sdd[3],eyy[4],emm[3],edd[3];  /*��O�I����*/
  int   count=0,count1=0,cnt=0;
	
  /* variables using in DB */
  $char DBName[DBNAME];
  $char FormFile[21];
  $int  PgLine=0,count_pass=0,count_receive=0;
  $char co_cname[101],co_ename[101],co_addr[101];
  
  $char sIpolicy[21],sIlast_ply[21],sIassured[13],sIply_area[11],sIestimate[21],iassured_pt[13];
  $char dpolicy[11],sDply_begin[11],sDply_end[11],fstatus[3],sFassured[2];
  $varchar sNassured[121],sApayment[91],sAassured[91];
  $char sItag[CA_TAG_NUM],sIbrand[9],nbrand[31],sIins_type[7],sNins_type[29];
  $long sMdeduct=0,sMins_premium=0,mpremium=0,sMinjured_cover=0,sMdamage_cover=0,sMinjured=0,sMdamage=0,sMcover_limit=0;
  $char sMdeduct_tmp[19],sMcover_tmp[19],sMins_premium_tmp[19],sMinjured_tmp[6],sMdamage_tmp[6],sMcover_limit_tmp[19];
  $char sMcar_price_tmp[11],mpremium_tmp[19];
  $double sMcar_price;
  
  $char    itype[2],iversion[2],iprint[11],dreceipt[11],fnote[2],sItel[21]; 
  
  /* variables for form */
  int print_line=0, ypos=0, len1=0;
  char ipolicytmp[4],ipolicytmp2[15],stmt[101],stmt1[101],stmt2[101],stmt3[101];
  char ilast_ply_tmp[4],ilast_ply_tmp2[15];
  char nins_kind_desc[51],spos_ma[11];
  
  /* variables from client */
  char inputDate1[10],inputDate2[10],sIbranch[4],ikind[2];
  $char ply_bgn[21],ply_end[21],bigipolicy[2],ProtectData[2];
  $char dentry1[11],dentry2[11];
  $char co_place[2],nchi_abv[21],chkAdd[2];
  $char dToday[11];
  long t=0;
  
  $char stmt_ncont[1024],ncontract[21],viins_type[7],ncontent1[251],ncontent2[251];  
  
    t = cm_today();
  
    cm_buf_get("%s",DBName);
       
  if(strcmp(option,"4") == 0){
    cm_buf_get("%s",inputDate1);
    cm_buf_get("%s",inputDate2);
    cm_buf_get("%s",ply_bgn);
    cm_buf_get("%s",ply_end);
    cm_buf_get("%s",bigipolicy);
    cm_buf_get("%s",ProtectData);
    
    strcpy(dentry1, cm_to_infdate(inputDate1));
    strcpy(dentry2, cm_to_infdate(inputDate2));
  }
  else{
    cm_buf_get("%s",ply_bgn);
  	cm_buf_get("%s",ply_end);
  	cm_buf_get("%s",chkAdd);
  	cm_buf_get("%s",bigipolicy);
  	cm_buf_get("%s",ProtectData);
  }
  
  $WHENEVER SQLERROR GOTO errexit;
  if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }
  
  $SELECT kpgnum_line,nform_file INTO $PgLine,$FormFile
     FROM form
    WHERE ksys_grp="CA" AND kpgmid = 2131 AND iform_tp = "TV";
    
   if (SQLCODE==SQLNOTFOUND)
  {
    printf("FormFile not found in Form!!\n");
    goto optL_err;
  }
  
  strcpy(FormFile,rtrim(FormFile));
  strcpy(outputf, getFileName());
  sprintf_s(OutFile, sizeof OutFile,"%s.tx",outputf);
  rgu_init_report(FormFile,OutFile);
  msg = M_CM_OK;

  /* insert */
  strcpy(co_cname, laser_get_cname());
  strcpy(co_ename, laser_get_ename());
  strcpy(co_addr , laser_get_addr());
  
  /* get today's date */
  strcpy(dpolicy,cm_edate_str(t));  
  strcpy(dToday,cm_from_infdate_100(dpolicy));
  cm_split_ymd_100(dToday,nyy,nmm,ndd);
  /* get date ends */
 
  if(strcmp(option,"4") == 0){ 
   $DECLARE PLY_CUR_4 CURSOR FOR
   	 SELECT a.itmp_policy,a.ipolicy,a.ilast_ply,b.nassured,b.iassured,b.apayment,b.aassured,
           	a.ibrand,b.itag,b.iply_area,b.mcar_price,a.dply_begin,a.dply_end,b.fassured,
           	case when length(b.itel) = 0 then b.mobil_phone else b.itel end,b.mcover_limit
       FROM ply_relation a, policy b
     	WHERE a.ipolicy = b.ipolicy
       	AND a.ipolicy >= $ply_bgn
       	AND a.ipolicy <= $ply_end
       	AND a.dentry >= $dentry1
       	AND a.dentry <= $dentry2
       	AND a.dpolicy IS NULL;
       	
   $OPEN PLY_CUR_4;
  }
  else{
   $DECLARE PLY_CUR_5 CURSOR FOR
   	 SELECT a.ipolicy,a.ilast_ply,b.nassured,b.iassured,b.apayment,b.aassured,
           	a.ibrand,b.itag,b.iply_area,b.mcar_price,a.dply_begin,a.dply_end,b.fassured,
           	case when length(b.itel) = 0 then b.mobil_phone else b.itel end,b.mcover_limit
       FROM ply_relation a, policy b
     	WHERE a.ipolicy = b.ipolicy
       	AND a.ipolicy >= $ply_bgn
       	AND a.ipolicy <= $ply_end     	
       	AND a.dpolicy IS NOT NULL;
       	
   $OPEN PLY_CUR_5;	
  }	
  
  $BEGIN WORK;
  count = count1 = 0;
  
  for(;;)
  {
  	if(strcmp(option,"4") == 0){
  	 $FETCH PLY_CUR_4 INTO $sIestimate,$sIpolicy,$sIlast_ply,$sNassured,$sIassured,$sApayment,$sAassured,
   		                     $sIbrand,$sItag,$sIply_area,$sMcar_price,$sDply_begin,$sDply_end,$sFassured,
   		                     $sItel,$sMcover_limit;
   	}else{
   	 $FETCH PLY_CUR_5 INTO $sIpolicy,$sIlast_ply,$sNassured,$sIassured,$sApayment,$sAassured,
   		                     $sIbrand,$sItag,$sIply_area,$sMcar_price,$sDply_begin,$sDply_end,$sFassured,
   		                     $sItel,$sMcover_limit;	
   	}
   	 	                    
    if (SQLCODE == SQLNOTFOUND) break;
    count++;
    
	sprintf_s(stmt_ncont, sizeof stmt_ncont,"SELECT max(ncontract ),a.iins_type "
		                    " FROM  ca_terms a, ply_ins_type b"
		                   " WHERE a.iins_type = b.iins_type"
		                    "  AND  b.ipolicy = '%s' "
		                    "  AND  deffect <= '%s' "
		                    "  AND  dcreate <= '%s' "
		                    " GROUP BY a.iins_type "
		                    " ORDER BY 1 DESC ",sIpolicy,sDply_begin,dpolicy);
		                    printf("stmt_ncont[%s]\n",stmt_ncont);
	  $PREPARE term_tv FROM $stmt_ncont;
	  $DECLARE term_ncon_tv CURSOR FOR term_tv;
	  $OPEN term_ncon_tv;
	  $FETCH term_ncon_tv INTO $ncontract,$viins_type;
	  $CLOSE term_ncon_tv;
	  $FREE  term_ncon_tv;
		
	  $SELECT ncontent1,ncontent2
	     INTO $ncontent1,$ncontent2
	     FROM ca_terms
	    WHERE ncontract = $ncontract
		  AND iins_type = $viins_type;
	
	  strcpy(ncontent1,trim(ncontent1));
	  strcpy(ncontent2,trim(ncontent2));
	  if(strlen(ncontent1) == 0) strcpy(ncontent1," ");
	  if(strlen(ncontent2) == 0) strcpy(ncontent2," ");
	  printf("\n---ncontent1[%s]\n",ncontent1);
	  printf("\n---ncontent2[%s]\n",ncontent2);
	  
	  strcpy(nins_kind_desc,"�s�w�F�ʮ��W�����T���~���ը�����X�O�I�O�I��");
	  
	  rgu_put_body_string(1,nins_kind_desc,1);
	  rgu_put_body_string(1,ncontent1,2);
	  rgu_put_body_string(1,ncontent2,2);
	  rgu_put_body_string(1,co_cname,1);
	  rgu_put_body_string(1,co_ename,1);
	  rgu_put_body_string(1,co_addr,1);
	  
	  if(strcmp(option,"4") == 0){
	  	 rgu_put_body_string(1,"����",1);
	  }
	  else{
	  	 if(strcmp(chkAdd,"1") == 0) {
	        rgu_put_body_string(1,"�ɵo",1);
	   	 }
	   	 else{
	   		  rgu_put_body_string(1,"",1);
	   	 }
	  }
	  
	  /* �]�I�ئW�٪��פ��P�A�p��_�l��m�A�H�K�m����� */
	  len1 = strlen(nins_kind_desc) / 4;
	  xpos_ma = 105 - ( 5 * len1);
	  xpos_mb = xpos_ma;
	  
	  sprintf_s(spos_ma, sizeof spos_ma,"%d",xpos_ma);
	  rgu_put_body_string(1,spos_ma,1);
	  rgu_put_body_string(1,nins_kind_desc,1);
	  rgu_put_body_string(1,"0",2);
	  rgu_put_body_string(1,"0",2);
	  	
	  rgu_put_body(1);
    
       /*�Ӹ�B�n*/
       if(strncmp(ProtectData,"1",1) == 0 )                    
       {
         if( sFassured[0] == '1' || sFassured[0] == '3' || sFassured[0] == '5' )
         {
         	/*�����Ҹ��X*/
      		strcpy(iassured_pt, sIassured);
                strcpy(sIassured,substring(iassured_pt,1,4));
     		strcat(sIassured,"****");
     		strcat(sIassured,substring(iassured_pt,9,2));
         }
       }
       
    strcpy(bigipolicy,trim(bigipolicy));


   	if (count1 != 0) rgu_put_body(99); /* ���� */
    count1++;
     
    strcpy(ipolicytmp,"");
    strcpy(ipolicytmp2,"");  
    strncpy(ipolicytmp, sIpolicy, 3);
   	ipolicytmp[3]=0x0;
   	strncpy(ipolicytmp2, sIpolicy+3, 14);
   	ipolicytmp2[14]=0x0;
    strcpy(stmt1,"17");
   	strcat(stmt1,ipolicytmp);
   	strcat(stmt1,"�r��");
   	strcat(stmt1,ipolicytmp2);
   	strcat(stmt1,"��");
   	
   	strcpy(sIpolicy,trim(sIpolicy));
    if(strlen(sIpolicy) == 17){ 
       rgu_put_body_string(8,sIpolicy,1);
       rgu_put_body(8);
    }
    else{
       rgu_put_body_string(11,sIpolicy,1);
       rgu_put_body(11);
    }
   	
   	strcpy(ilast_ply_tmp,"");
    strcpy(ilast_ply_tmp2,"");
    
    strcpy(sIlast_ply,trim(sIlast_ply)); 	
   	if(strlen(sIlast_ply) == 0 )
   	{
   		strcat(stmt1,"  ���O��Y");
   		strcat(stmt1,"     ");
   	  strcat(stmt1,"�r��");
   	  strcat(stmt1,"          ");
   	  strcat(stmt1,"���O����O");	
   	}
   	else{
   		strncpy(ilast_ply_tmp, sIlast_ply, 3);
   	  ilast_ply_tmp[3]=0x0;
   	  strncpy(ilast_ply_tmp2, sIlast_ply+3, 14);
   	  ilast_ply_tmp2[14]=0x0;
   	  strcpy(ilast_ply_tmp2,trim(ilast_ply_tmp2));
   		strcat(stmt1,"  ���O��Y");
      strcat(stmt1,"17");
      strcat(stmt1,ilast_ply_tmp);
   	  strcat(stmt1,"�r��");
   	  strcat(stmt1,ilast_ply_tmp2);
   	  strcat(stmt1,"���O����O");
    }
   	 	
   	rgu_put_body_string(2,stmt1,1);
   	rgu_put_body_string(2,sNassured,1);
   	rgu_put_body_string(2,sIassured,1);
   	rgu_put_body_string(2,sAassured,1);
   	rgu_put_body_string(2,sItel,1);
   	rgu_put_body_string(2,sItag,1);

   	
    /* �O�I���� */
   	strcpy(bch_date,cm_from_infdate_100(sDply_begin));
   	cm_split_ymd_100(bch_date,syy,smm,sdd);
   	strcpy(ech_date,cm_from_infdate_100(sDply_end));
   	cm_split_ymd_100(ech_date,eyy,emm,edd);
   
   	rgu_put_body_string(2,syy,2);
   	rgu_put_body_string(2,smm,2);
   	rgu_put_body_string(2,sdd,2);
   	rgu_put_body_string(2,"12",2);
   	rgu_put_body_string(2,eyy,2);
   	rgu_put_body_string(2,emm,2);
   	rgu_put_body_string(2,edd,2);
   	rgu_put_body_string(2,"12",2);
   	
    rgu_put_body(2);
    rgu_put_body(10);
   	rgu_put_body(3);
   	rgu_put_body(7);
    
     
   	/* �O�I�����B�ۭt�B�B�O�I���B�B�O�I�O */
   	$DECLARE PLY_INS_TYPE1 CURSOR for
   	   SELECT a.iins_type,a.mdeduct,a.minjured_cover,a.mdamage_cover,a.mins_premium
   	     FROM ply_ins_type a, insurance_type b
   	    WHERE a.iins_type = b.iins_type
   	      AND a.ipolicy = $sIpolicy;
   	      
    $OPEN PLY_INS_TYPE1;
    cnt = 0;
    mpremium = 0;

    for(;;)
    {
    	$FETCH PLY_INS_TYPE1 INTO $sIins_type,$sMdeduct,$sMinjured_cover,$sMdamage_cover,$sMins_premium;
    	if (SQLCODE == SQLNOTFOUND) break;
    	

    	    	
    	rfmtlong(sMdeduct,"<<,<<<,<<<,<<<,<<<",sMdeduct_tmp);
    	rfmtlong(sMinjured_cover,"<<,<<<,<<<,<<<,<<<",stmt2);
    	rfmtlong(sMdamage_cover,"<<,<<<,<<<,<<<,<<<",stmt3);
    	rfmtlong(sMins_premium,"<<,<<<,<<<,<<<,<<<",sMins_premium_tmp);
    	
printf("sMdeduct_tmp[%s]\n",sMdeduct_tmp);
printf("sMinjured_cover[%s]\n",stmt2);
printf("sMdamage_cover[%s]\n",stmt3);
printf("sMins_premium[%s]\n",sMins_premium_tmp);
    	    	
    	if(strcmp(trim(sIins_type),"145") == 0)
    	{
printf("sIins_type[%s]\n",sIins_type);
		/*�C�@�ӤH��˳d��*/
    		rgu_put_body_string(72,sMdeduct_tmp,2);
   	  	rgu_put_body_string(72,stmt2,2);
   	  	rgu_put_body_string(72,sMins_premium_tmp,2);
   	  	rgu_put_body(72);
   	  	/*�C�@�N�~�ƬG��˳d��*/
		rgu_put_body_string(73,sMdeduct_tmp,2);
   	  	rgu_put_body_string(73,stmt3,2);
   	  	rgu_put_body(73);

    	}
    	else if(strcmp(trim(sIins_type),"146") == 0)
    	{
printf("sIins_type[%s]\n",sIins_type);
    		rgu_put_body_string(74,sMdeduct_tmp,2);
   	  	rgu_put_body_string(74,stmt3,2);
   	  	rgu_put_body_string(74,sMins_premium_tmp,2);
   	  	rgu_put_body(74);
    	}
    	else
    	{
printf("sIins_type[%s]\n",sIins_type);
    		rgu_put_body_string(71,sMdeduct_tmp,2);
   	  	rgu_put_body_string(71,stmt3,2);
   	  	rgu_put_body_string(71,sMins_premium_tmp,2);
   	  	rgu_put_body(71);
    	}	
   	
    	mpremium = mpremium + sMins_premium;                       

   }
   $CLOSE PLY_INS_TYPE1;
   $FREE  PLY_INS_TYPE1; 
   
   	  /* �������̰����v���B */ 
   	  rfmtlong(sMcover_limit,"<<,<<<,<<<,<<<,<<<",sMcover_limit_tmp);
   	  rgu_put_body_string(75,sMcover_limit_tmp,2);
   	  rgu_put_body(75);
     
   	  /* �`�O�I�O */
	  rgu_put_body(77);
   	  rfmtlong(mpremium,"<<,<<<,<<<,<<<,<<<",mpremium_tmp);
   	  rgu_put_body_string(78,mpremium_tmp,1);
   	  rgu_put_body(78);
   	  rgu_put_body(79);
	
   	  rgu_put_body(81);
   	
   	  
   	  strncpy(co_place,ply_bgn+2,1);
  	  co_place[1]=0x0;

  	  $SELECT nchi_abv
     	   INTO $nchi_abv
     	   FROM branch
    	  WHERE ibranch_abbr = $co_place;
  	    if(SQLCODE != 0) strcpy(nchi_abv, " ");
  
   	  rgu_put_body_string(9,nyy,1);
   	  rgu_put_body_string(9,nmm,1);
   	  rgu_put_body_string(9,ndd,1);
   	  rgu_put_body_string(9,nchi_abv);
      rgu_put_body(9);
    
      rgu_put_body(91);
      /* �N���n��T�g�^db */
printf("update dpolicy of ply_relation[%s]\n",sIpolicy);
  	  $UPDATE ply_relation 
      	  SET fprint = "1", dpolicy = $dpolicy  
      	WHERE fcard_class = '2'
      	  AND dply_close is NULL
      	  AND ipolicy = $sIpolicy
      	  AND dpolicy is NULL;
  	 /* �g�^db ends */
  	
  	if(strcmp(option,"4") == 0){ 
  	 /* �^���@�γ������� ---------------------------------------------- */

        /*  1031111001_C1 ���O�X������{���վ� (Upd_Cm_pre_receive() �b caxxxlib.ec) */
    	rc = Upd_Cm_pre_receive(sIestimate, sIpolicy, sIassured);
     	if (rc != SUCCESS)
     	{
     		$ROLLBACK WORK;
        	return rc;		            		
        }
     }  
  }
   if (strcmp(option,"4") == 0) {
   	$CLOSE PLY_CUR_4;
   	$FREE  PLY_CUR_4;
   }
   else{
   	$CLOSE PLY_CUR_5;
   	$FREE  PLY_CUR_5;
   }  
   	
  rgu_finish_report();
  
  if (count == 0)
  {
    printf("�L�O��i�C�L\n");
    $ROLLBACK WORK;
    /*SQLCODE = M_CA_NREL_PLY;
    goto optL_err;*/
    if(exitsub(reply,M_CA_NOREC_ERR) == True)
    {
   	   return M_CA_NOREC_ERR;
    }
  }
  
    if (msg == M_CM_OK)
    {
        res = getApHome(aphome);
        if (res<0)
        {
            printf("In sigalrmcatcher func==>read config file error!!\n");
            $ROLLBACK WORK;
            return res;
        }
 
        gethostname(hostname,sizeof(hostname));
        sprintf_s(tmpOutFile, sizeof tmpOutFile, "%s/reportfile/%s", aphome,OutFile);
    }

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %d", msg, hostname, tmpOutFile, PgLine);

    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    {
    	$ROLLBACK WORK;
        return apiRC;
    }
    
    $COMMIT WORK;
    return M_CM_OK;

optL_err:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    /*$ROLLBACK WORK;*/
    return SQLCODE;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
/** ���o���^���q�������T���嵲����m **/
int *iGetChinesePos(sStrTmp,iPos)
char *sStrTmp;
int  iPos;
{
   int  iTrueLen=0;
   int  i=0,x=0;

   for(i = 0; i<= iPos; i++){
         if ((int)(sStrTmp[i]) >= 128){
                i++;
         }
   }
   return (i-1);
}