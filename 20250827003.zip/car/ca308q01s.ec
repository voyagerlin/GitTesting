/************************************************/
/*                                              */
/*   PROGRAM : ca308q01s.ec by Dennis Chang     */
/*                                              */
/*   DATE    : 1993/09/14                       */
/*   UPDATE  : 2002/03/22 by Jessie �[�~�ȥγ���*/
/*                                              */
/************************************************/
#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
$include "gls_for_ins.h";
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"

/*------------------------------------*/
struct GLS_FOR_INS *get_gls_for_ins();  /* 1080912006-SC1-�f�ӿo-�s�Wñ��������ˮ�*/
extern char RPTDIR[];
$date    Today;
char     ctype[2];
int      itype;
$char    Ipolicy[ POLICY_NUM_1];
$char    Icard[CARD_NUM];
$char    Nassured[ 41];
$char    Icar_type[ CA_CAR_TYPE_NUM];
$char    Ibroker[BROKER];
$char    sIcomm_obj[11];
$char    Dply_begin[11];
$char    Iofficer[ EMPLOYEE_ID];
$char    Icashier[ EMPLOYEE_ID];
$char    Iresource[ 2];
$char    char_plydate[ YYMMDD];
$char    char_plydate2[YYYYMMDD];
$char    sIbranchIcomp[CA_POL_BRH_NUM+1];
$char    dptbgn[ BRANCH_ID], dptend[ BRANCH_ID];
$char    DBName[ DBNAME];
$char    Iquota[7],Iacc_type[3],Nbranch[21];
$char    pre_branch[3];

$long    Dply_period=0;
$int     Mlia_prem,Mlia_agent=0;
$int     Mlia_commi=0;

$int     Mlia_prem_car;       /*car*/
$int     Mlia_commi_car;      /*car*/

$int     Mlia_prem_moto;      /*moto*/
$int     Mlia_commi_moto;     /*moto*/

$date    long_dply_begin, long_dply_end;
$double  Mcompensation;
$double  Mpure_prem=0, Mextra_charge, Pextra_charge;

$double  Mcompensation_car;   /*car*/
$double  Mcompensation_moto;  /*moto*/

$int     Mdamage_cover=0;

$int    ItemRow, TotColumn;

long    Brk_mlia_prem=0, Brk_mlia_commi=0;
double  Brk_mcompensation=0,Tot_mcompensation=0;
long    Tot_mlia_prem=0, Tot_mlia_commi=0;
double  Brk_mpure_prem[4],Brk_mextra_charge[4];
double  Tot_mpure_prem[4],Tot_mextra_charge[4];
double  Brk_mply_prem[4],Tot_mply_prem[4];

long    Brk_mlia_prem_car=0, Brk_mlia_commi_car=0;         /*car*/
double  Brk_mcompensation_car=0,Tot_mcompensation_car=0;   /*car*/
long    Tot_mlia_prem_car=0, Tot_mlia_commi_car=0;         /*car*/

long    Brk_mlia_prem_moto=0, Brk_mlia_commi_moto=0;       /*moto*/
double  Brk_mcompensation_moto=0,Tot_mcompensation_moto=0; /*moto*/
long    Tot_mlia_prem_moto=0, Tot_mlia_commi_moto=0;       /*moto*/

/* �j��T��[�ۥ�] */
double  Tot_mcompensation_car_14=0.0;
long    Tot_mlia_prem_car_14=0;
long    Tot_mlia_commi_car_14=0;
/* �j��T��[�ӷ~] */
double  Tot_mcompensation_car_15=0.0;
long    Tot_mlia_prem_car_15=0;
long    Tot_mlia_commi_car_15=0;
/* �j�����[�@�~��] */
double  Tot_mcompensation_moto_p1=0.0;
long    Tot_mlia_prem_moto_p1=0;
long    Tot_mlia_commi_moto_p1=0;
/* �j�����[�G�~��] */
double  Tot_mcompensation_moto_p2=0.0;
long    Tot_mlia_prem_moto_p2=0;
long    Tot_mlia_commi_moto_p2=0;

/* �j��L���q�ʤG��[�@�~��] */
double  Tot_mcompensation_moto35_p1=0.0;
long    Tot_mlia_prem_moto35_p1=0;
long    Tot_mlia_commi_moto35_p1=0;
/* �j��L���q�ʤG��[�G�~��] */
double  Tot_mcompensation_moto35_p2=0.0;
long    Tot_mlia_prem_moto35_p2=0;
long    Tot_mlia_commi_moto35_p2=0;
/* �j��L���q�ʤG��[�T�~��] */
double  Tot_mcompensation_moto35_p3=0.0;
long    Tot_mlia_prem_moto35_p3=0;
long    Tot_mlia_commi_moto35_p3=0;

/* 1080912006-SC1-�f�ӿo-�s�Wñ��������ˮ� */
long    lDiff_ca_gl=0;
char    buf_Diff[20],buf_GLS[20];

$char   FormTp[3];
char    BodyFile[ N_FILE+1];
char    TitleFile[ N_FILE+1];
char    outputf[ N_FILE+1];
char    userid[USER_ID];
$char   yy[YYY], mm[MM], dd[DD];
$char   tmp_yy[YYY];
char    addname[1];

static int pagenum=1;
static int linecnt=0;

$int    StartRow,TitleRow;
$int    PgLine=0, Width=0;
int     flag_check=0,max_count,cnt=0;
int     miy;
$char   FullDBName[20],nchi_abv[13];

#define LINEOFPAGE 38
#define NEXTPAGE   8

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;
   $char inf_plydate[12];
   Mlia_prem=0;
   
   batchinit();
   strcpy(DBName,         isNULLstr(argv[1]));
   strcpy(userid,         isNULLstr(argv[2]));
   strcpy(char_plydate,   isNULLstr(argv[3]));
   strcpy(sIbranchIcomp,  isNULLstr(argv[4]));
   strcpy(ctype,          isNULLstr(argv[5]));
   strcpy(outputf,        isNULLstr(argv[6]));
   strcpy(sIbranchIcomp,  trim(sIbranchIcomp));
   strcat(sIbranchIcomp,  "*");
   itype=atoi(ctype);
   strcpy(addname,"");

   

   printf("outputf[%s]\n",outputf);
   rc=car308_get_db();
   if (rc!=SUCCESS)
       return rc;

   rtoday(&Today);     /* get today's datetime */

   if (itype==1) /* �]�ȥ� */
       car308_build();
   if (itype==2) /* �~�ȥ� */
       car308_build1();
   if (itype==0) /* ���� */
   {
       strcpy(addname,"A");
       car308_build();
       strcpy(addname,"B");
       car308_build1();
   }
} 

/*--------------------------------------------------------------------*/
long car308_get_db()
{
   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return 0;
   }
   strcpy(FullDBName,get_full_dbname(DBName));
   return SUCCESS;
}

/*--------------------------------------------------------------------*/
/* �]�ȥ� */
long car308_build()
{
   $char TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
   $long plydate;
   int   rc;
   int   i,BranchCnt;
   $char fname[101];

   printf("in car308_build\n");

   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 308 AND iForm_Tp = "1";

   strcpy(TitleFmt,rtrim(TitleFmt));
   strcpy(BodyFmt,rtrim(BodyFmt));
   sprintf_s(TitleFile,sizeof TitleFile,"%s%s.ti",outputf,addname);
   sprintf_s(BodyFile,sizeof BodyFile,"%s%s.bd",outputf,addname);

   strcpy(char_plydate2,cm_to_infdate(char_plydate));
   cm_split_ymd_100(char_plydate,yy,mm,dd);

   printf("***** plydate yy[%s] mm[%s] dd[%s]\n",yy,mm,dd);

   plydate = cm_ymd_cdate(char_plydate);

   printf("char_plydate2[%s]\n",char_plydate2);

   miy = 0;

   /* build title */
   rgu_init_report(TitleFmt,TitleFile);
   car308_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   car308_data();
   rgu_finish_report();

   max_count = miy;
   create_sign_form("car308",BodyFile,Width);
   max_count+=3;

   if ((rc=save_form_info(F_BLK0,"CA",308,userid,FormTp,max_count,outputf))<0)
        EWRITE(userid, rc,"save_form_info failed");

   printf("##############yy[%s],mm[%s],dd[%s],outputf[%s]\n",yy,mm,dd,outputf);

   sprintf_s(fname,sizeof fname,"�j��_�O��_%s%s%s",yy,mm,dd);
   printf("car308_build:fname[%s]\n",fname);
   gen_filename(outputf,addname,fname);

   return api_OKComplete;

errexit:
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return 0;
}

/*--------------------------------------------------------------------*/
/* �~�ȥ� */
long car308_build1()
{
   $char TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
   $long plydate;
   int   rc;
   int   i,BranchCnt;
   $char fname[101];

   printf("in car308_build1\n");

   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 308 AND iForm_Tp = "2";

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf_s( TitleFile,sizeof TitleFile,"%s%s.ti",outputf,addname);
   sprintf_s( BodyFile,sizeof BodyFile,"%s%s.bd",outputf,addname);

   strcpy(char_plydate2,cm_to_infdate(char_plydate));
   cm_split_ymd_100(char_plydate,yy,mm,dd);

   printf("***** plydate yy[%s] mm[%s] dd[%s]\n",yy,mm,dd);

   plydate = cm_ymd_cdate(char_plydate);

   printf("char_plydate2[%s]\n",char_plydate2);

   miy = 0;

   /* build title */
   rgu_init_report( TitleFmt,TitleFile);
   car308_title1();
   rgu_finish_report();

   rgu_init_report( BodyFmt,BodyFile);
   car308_data1();
   rgu_finish_report();

   max_count = miy;
   create_sign_form("car308",BodyFile,Width);
   max_count+=3;

   if ((rc=save_form_info(F_BLK1,"CA",308,userid,FormTp,max_count,outputf))<0)
        EWRITE(userid, rc,"save_form_info failed");

   sprintf_s(fname,sizeof fname,"�j��_�O��[�~�ȥ�]_%s%s%s",yy,mm,dd);
   printf("car308_build1:fname[%s]\n",fname);
   gen_filename(outputf,addname,fname);

   return api_OKComplete;

errexit:
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return 0;
}
/*--------------------------------------------------------------------*/
long car308_title()
{
   $long dclosing, plydate_l;
   /* $char ivoucher[GL_VCHR_NO], ivouch_tot[13]; */
   $char ivoucher[13], ivouch_tot[13];
   $short id;
   char  sub_title[30];

   printf("in title!\n");

   $WHENEVER SQLERROR GOTO errexit;

   strncpy( tmp_yy, &yy[1],2);
   tmp_yy[2] = '\0';
   strcpy( yy, tmp_yy);
   printf("yy[%s]\n", yy);

	 ivouch_tot[0] = '\0';	/* �]�ȦX�᪺֫�J��s�����X */
	 
   $SELECT dlast_closing, ivoucher 
      INTO $dclosing:id, $ivoucher
      FROM last_daily_close 
     WHERE ibill_type="CA1"
       AND iyear = $yy;
   if (SQLCODE == SQLNOTFOUND) dclosing = (long) 0;

   plydate_l=cm_ymd_cdate(char_plydate);
   printf("------>debug dclosing[%d]\n", dclosing);
   printf("------>debug plydate_l[%d]\n", plydate_l);
   
   /* ��J��s�����X, ���h�л\�즳���ǲ����X	modify by sylvia 101.07.23(1001228004_C1) */
   $select unique kcracc_num_tot into $ivouch_tot
      from gl_vchrxn_sub
     where kcracc_num = $ivoucher;
   if (SQLCODE == SQLNOTFOUND) ivouch_tot[0] = '\0';
   
   if (ivouch_tot[0] != '\0')
   		strcpy(ivoucher, ivouch_tot);

   if (dclosing < plydate_l)
   {
        flag_check=1;
        rgu_put_head_string(1, "(�ˮ֥�)");
   }
   else if (dclosing==plydate_l)
   {
        strcpy(sub_title, "(�s�����X:");
        strcat(sub_title, ivoucher);
        trim_tail_white(sub_title);
        strcat(sub_title, ")");
        rgu_put_head_string(1, sub_title);
   }
   else
   {
        rgu_put_head_string(1, "(�ɵo��)");
   }

   rgu_put_head_string(1,cm_sysd_cdatetime_100(cm_get_sysd()));

  $SELECT nchi_abv 
     INTO $nchi_abv FROM branch
    WHERE ibranch = $DBName;

   rgu_put_head_string(1,DBName);
   rgu_put_head_string(1,nchi_abv);
   rgu_put_head_string(1, yy);
   rgu_put_head_string(1, mm);
   rgu_put_head_string(1, dd);
   rgu_put_head();
printf("after title!\n");
   return api_OKComplete;

errexit:
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
}

/*--------------------------------------------------------------------*/
long car308_title1()
{
   $long dclosing, plydate_l;
   $short id;
   printf("in title1!\n");

   $WHENEVER SQLERROR GOTO errexit;

   strncpy( tmp_yy, &yy[1],2);
   tmp_yy[2] = '\0';
   strcpy( yy, tmp_yy);
   printf("yy[%s]\n", yy);

   $SELECT dlast_closing
      INTO $dclosing:id
      FROM last_daily_close 
     WHERE ibill_type="CA1"
       AND iyear = $yy;
   if (SQLCODE == SQLNOTFOUND) dclosing = (long) 0;

   plydate_l=cm_ymd_cdate(char_plydate);

   if (dclosing < plydate_l) {
        flag_check=1;
        rgu_put_head_string(1, "(�~���ˮ֥�)");
   }
   else
        rgu_put_head_string(1, "(�~�ȥ�)");

   rgu_put_head_string(1,cm_sysd_cdatetime_100(cm_get_sysd()));

   rgu_put_head_string(1, yy);
   rgu_put_head_string(1, mm);
   rgu_put_head_string(1, dd);
   rgu_put_head();

printf("after title1!\n");
   return api_OKComplete;

errexit:
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
/* �]�ȥ�:���Ӹ�� */
car308_body()
{
   char buf1[20], buf2[20], buf3[20], buf4[20];
   char ch1[14], ch2[9];
   char buffer[30];

   linecnt+=1;

   if ( linecnt > LINEOFPAGE)
      car308_brk();
  
   Brk_mcompensation += (double)((long)(Mcompensation+0.5));
   Brk_mlia_prem  += Mlia_prem;
   Brk_mlia_commi += Mlia_commi;

   Brk_mcompensation_car += Mcompensation_car;/*car*/
   Brk_mlia_prem_car  += Mlia_prem_car;/*car*/
   Brk_mlia_commi_car += Mlia_commi_car;/*car*/

   Brk_mcompensation_moto += Mcompensation_moto;/*moto*/
   Brk_mlia_prem_moto  += Mlia_prem_moto;/*moto*/
   Brk_mlia_commi_moto += Mlia_commi_moto;/*moto*/

   strncpy(ch1,Ipolicy,18);
   ch1[18]='\0';
   rgu_put_body_string( 2,ch1,1);      /*1*/

   rgu_put_body_string( 2,Icard,1);    /*2*/

   strncpy(buffer,Nassured,20);
   buffer[20]='\0';
   rgu_put_body_string( 2,buffer,1);      /*3*/
   rgu_put_body_string( 2,rtrim(Icar_type),1);   /*4*/
   rgu_put_body_string( 2,sIcomm_obj,1);     /*5*/
   rgu_put_body_string(2,cm_cdate_str_100(long_dply_begin),1);
   rgu_put_body_string(2,cm_cdate_str_100(long_dply_end),1);
   sprintf_s(buffer,sizeof buffer,"%ld",Dply_period);
   rgu_put_body_string( 2,buffer,1);      /*8*/

   rfmtlong(Mdamage_cover/10000,"##&",buf1);     
   rfmtdouble(Mcompensation, "----&", buf2); 
   strcpy(buf3, refmtamt(Mlia_prem,MILLIONTH));
   strcpy(buf4, refmtamt(Mlia_commi,MILLIONTH));

   rgu_put_body_string( 2,buf1,2);                  /*9�O�B(�U)*/
   rgu_put_body_string( 2,buf2,2);                  /*10���v��*/
   rgu_put_body_string( 2,buf3,2);                  /*11�O�O*/
   rgu_put_body_string( 2,buf4,2);                  /*12����*/
   rgu_put_body_string( 2,Iofficer,1);              /*13�g��N��*/
   rgu_put_body_string( 2,rtrim(Iresource),1);      /*14�~�Ȩӷ�*/
   rgu_put_body( 2);
   miy++;

   printf("body:Ipolicy[%s]Icard[%s]Nassured[%s]\n",Ipolicy,Icard,Nassured);
   printf("Icar_type[%s]sIcomm_obj[%s]\n", Icar_type,sIcomm_obj);
   printf("Dply_begin[%s]\n",cm_cdate_str_100(long_dply_begin));
   printf("agent:[%d]Mlia_prem[%d]Mlia_commi[%d]Mcompensation[%7.3f]\n",
           Mlia_agent,Mlia_prem,Mlia_commi,Mcompensation);
   printf("Iofficer[%s]Icashier[%s]\n", Iofficer,Icashier);
}

/*--------------------------------------------------------------------*/
car308_body1()
{
   char buf1[20], buf2[20], buf3[20], buf4[20];
   char ch1[14], ch2[9];
   char buffer[30];
   double dtl_mpure_prem[4],dtl_mextra_charge[4],dtl_mply_prem[4];
   double dtl_pextra_charge[4];
   int    i,iacc;

   linecnt+=1;

   if ( linecnt > 50 ) {
      car308_brk1();
      rgu_put_body(NEXTPAGE);            miy++;
      rgu_put_body_string(1,pre_branch,1);
      rgu_put_body_string(1,nchi_abv,1);
      rgu_put_body(1);
      pagenum += 1;
   }
  
   strncpy(ch1,Ipolicy,18);
   ch1[18]='\0';
   rgu_put_body_string( 2,ch1,1);      /*1*/
   rgu_put_body_string( 2,Icard,1);    /*2*/
   strncpy(buffer,Nassured,20);
   buffer[20]='\0';
   rgu_put_body_string( 2,buffer,1);   /*3*/
   Nbranch[14]='\0';
   rgu_put_body_string( 2,Nbranch,1);  /*4*/
   rgu_put_body_string( 2,Iofficer,1); /*5*/

   for (i=0;i<3;i++) {
        dtl_mpure_prem[i]=dtl_mextra_charge[i]=dtl_mply_prem[i]=0;
        dtl_pextra_charge[i]=0;
   }
   

   if (Mlia_prem != 0)
   {
       Pextra_charge = (Mextra_charge/Mlia_prem)*100;
   }
   else if (Mlia_prem == 0)
   {
       Pextra_charge = 0;
   }
   
   
   iacc=atoi(Iacc_type);
   iacc=iacc-14;
   for(i=0;i<3;i++) {
       if (i==iacc) {
           dtl_mpure_prem[i]=Mpure_prem;
           dtl_mextra_charge[i]=Mextra_charge;
           dtl_mply_prem[i]=Mlia_prem;
           dtl_pextra_charge[i]=Pextra_charge;
           Brk_mpure_prem[i] += Mpure_prem;
           Brk_mextra_charge[i] += Mextra_charge;
           Brk_mply_prem[i] += Mlia_prem;
       }
   }
      
   for (i=0;i<3;i++) {
       rfmtdouble(dtl_mpure_prem[i],"--,---,---.---",buf1);     
       rfmtdouble(dtl_mextra_charge[i],"--,---,---.---",buf2);     
       rfmtdouble(dtl_pextra_charge[i],"----.--",buf3);     
       rfmtdouble(dtl_mply_prem[i], "-,---,---,--&", buf4); 
       rgu_put_body_string( 2,buf1,2); /*6�«O�O*/
       rgu_put_body_string( 2,buf2,2); /*7���[�O��*/
       rgu_put_body_string( 2,buf3,2); /*8���[�O�βv*/
       rgu_put_body_string( 2,buf4,2); /*9ñ��O�O*/
   }
   rgu_put_body( 2);
   miy++;
}

/*--------------------------------------------------------------------*/
car308_brk()
{
   char buf1[20],buf2[20],buf3[20];

   rfmtdouble(Brk_mcompensation,"--,--&",buf1);
   strcpy(buf2,refmtamt(Brk_mlia_prem,MILLIONTH));
   strcpy(buf3,refmtamt(Brk_mlia_commi,MILLIONTH));

   rgu_put_body(3);                  miy++;
   rgu_put_body_string(4,buf1,2);
   rgu_put_body_string(4,buf2,2);
   rgu_put_body_string(4,buf3,2);
   rgu_put_body( 4);                  miy++;
   rgu_put_body( 3);                  miy++;
   rgu_put_body(NEXTPAGE);            miy++;

   linecnt = 0;

   printf("Brk:[%ld] [%ld] [%8.3f]\n",
           Brk_mlia_prem,Brk_mlia_commi,Brk_mcompensation);

   printf("Brk:[%ld] [%ld] [%8.3f]\n",
           Brk_mlia_prem_car,Brk_mlia_commi_car,Brk_mcompensation_car);
   
   printf("Brk:[%ld] [%ld] [%8.3f]\n",
           Brk_mlia_prem_moto,Brk_mlia_commi_moto,Brk_mcompensation_moto);        

   Tot_mcompensation  += Brk_mcompensation;
   Tot_mlia_prem  += Brk_mlia_prem;
   Tot_mlia_commi += Brk_mlia_commi;

   Tot_mcompensation_car  += Brk_mcompensation_car;/*car*/
   Tot_mlia_prem_car  += Brk_mlia_prem_car;/*car*/
   Tot_mlia_commi_car += Brk_mlia_commi_car;/*car*/
   
   Tot_mcompensation_moto  += Brk_mcompensation_moto;/*moto*/
   Tot_mlia_prem_moto  += Brk_mlia_prem_moto;/*moto*/
   Tot_mlia_commi_moto += Brk_mlia_commi_moto;/*moto*/

   Brk_mcompensation  = 0;
   Brk_mlia_prem  = 0;
   Brk_mlia_commi = 0;
   
   Brk_mcompensation_car  = 0;/*car*/
   Brk_mlia_prem_car  = 0;/*car*/
   Brk_mlia_commi_car = 0;/*car*/
   
   Brk_mcompensation_moto  = 0;/*moto*/
   Brk_mlia_prem_moto  = 0;/*moto*/
   Brk_mlia_commi_moto = 0;/*moto*/

   pagenum += 1;
}

/*--------------------------------------------------------------------*/
car308_brk1()
{
   char buf1[20],buf2[20],buf3[20],buf4[20];
   int  i;

   rgu_put_body(3);                  miy++;
   for(i=0;i<3;i++) {
       Tot_mpure_prem[i] += Brk_mpure_prem[i]; 
       Tot_mextra_charge[i] += Brk_mextra_charge[i];
       Tot_mply_prem[i] += Brk_mply_prem[i];
   }
   for(i=0;i<3;i++) {
       rfmtdouble(Brk_mpure_prem[i],"--,---,---.---",buf1);     
       rfmtdouble(Brk_mextra_charge[i],"--,---,---.---",buf2);     
       if (Brk_mply_prem[i]==0)
           Pextra_charge=0;
       else
           Pextra_charge=Brk_mextra_charge[i] / Brk_mply_prem[i] * 100;
       rfmtdouble(Pextra_charge,"----.--",buf3);     
       rfmtdouble(Brk_mply_prem[i], "-,---,---,--&", buf4); 
       rgu_put_body_string(4,buf1,2);
       rgu_put_body_string(4,buf2,2);
       rgu_put_body_string(4,buf3,2);
       rgu_put_body_string(4,buf4,2);
   }

   rgu_put_body( 4);                  miy++;
   rgu_put_body( 3);                  miy++;

   linecnt = 0;

   for(i=0;i<3;i++) 
       Brk_mpure_prem[i]=Brk_mextra_charge[i]=Brk_mply_prem[i]=0;

}

/*--------------------------------------------------------------------*/
long car308_tot()
{
    /*1080912006-SC1-�f�ӿo-�s�Wñ��������ˮ�*/
   long rtncode;
   char    v_sMsg[3000];
   $char kacctitem[5],kclsfyitem[5],eacc_title[41];
   $long mdeal;
   $int  iseq;
   char buf1[20],buf2[20],buf3[20],buf4[20];
   char bufC1[20],bufC2[20],bufC3[20];
   char bufM1[20],bufM2[20],bufM3[20];
   char bufC1_14[20],bufC2_14[20],bufC3_14[20];
   char bufC1_15[20],bufC2_15[20],bufC3_15[20];
   char bufM1_P1[20],bufM2_P1[20],bufM3_P1[20];
   char bufM1_P2[20],bufM2_P2[20],bufM3_P2[20];
   
   char bufM1_P35_1[20],bufM2_P35_1[20],bufM3_P35_1[20];
   char bufM1_P35_2[20],bufM2_P35_2[20],bufM3_P35_2[20];
   char bufM1_P35_3[20],bufM2_P35_3[20],bufM3_P35_3[20];
   char bufM1_P35_4[20],bufM2_P35_4[20],bufM3_P35_4[20];
   char bufM1_P35_5[20],bufM2_P35_5[20],bufM3_P35_5[20];
   
   $WHENEVER SQLERROR GOTO errexit;
   $EXECUTE IMMEDIATE "DROP TABLE IF EXISTS tmp_gl_list";
   $CREATE TEMP TABLE tmp_gl_list
    (
        iseq        INTEGER         default 0,
        kacctitem   CHAR(4),
        kclsfyitem  CHAR(4),
        eacc_title  CHAR(40),
        mdeal       DECIMAL(15,0)    default 0
    ) with no log;
    $CREATE INDEX tmp_gl_idx ON tmp_gl_list (kclsfyitem);
   mdeal=0;
   strcpy(kclsfyitem,"");
   strcpy(kclsfyitem,"");
   strcpy(eacc_title,"");
   
   printf("in car308_tot,compensation[%9.3f]\n",Brk_mcompensation);

   rfmtdouble(Brk_mcompensation, "--,--&", buf1);

   printf("in car308_tot\n");
   strcpy(buf2, refmtamt(Brk_mlia_prem,MILLIONTH));
   strcpy(buf3, refmtamt(Brk_mlia_commi,MILLIONTH));

   printf("in car308_tot_1\n");
   rgu_put_body( 3);                miy++;
   rgu_put_body_string( 4,buf1,2);
   rgu_put_body_string( 4,buf2,2);
   rgu_put_body_string( 4,buf3,2);
   rgu_put_body( 4);                miy++;

   /* ��ñ���C�L�`���� */
   printf("cnt[%d]\n",cnt);
   rgu_put_body( 3);                miy++;
   rgu_put_body_string( 9,itoa(cnt),2);
   rgu_put_body( 9);                miy++;
   rgu_put_body( 3);                miy++;

   printf("F1 car308_tot_2\n");
   printf("tot: cnt[%d][%ld] [%ld] [%ld] [%ld] [%8.3f]\n",
        cnt,Brk_mlia_prem,Brk_mlia_commi,Tot_mlia_prem,Tot_mlia_commi,Tot_mcompensation);

   printf("F1 car308_tot_2_car\n");/*car*/
   printf("tot: cnt[%d][%ld] [%ld] [%ld] [%ld] [%8.3f]\n",
        cnt,Brk_mlia_prem_car,Brk_mlia_commi_car,Tot_mlia_prem_car,Tot_mlia_commi_car,Tot_mcompensation_car);

   printf("F1 car308_tot_2_moto\n");/*moto*/
   printf("tot: cnt[%d][%ld] [%ld] [%ld] [%ld] [%8.3f]\n",
        cnt,Brk_mlia_prem_moto,Brk_mlia_commi_moto,Tot_mlia_prem_moto,Tot_mlia_commi_moto,Tot_mcompensation_moto);

   Tot_mcompensation += Brk_mcompensation;
   Tot_mlia_prem += Brk_mlia_prem;
   Tot_mlia_commi += Brk_mlia_commi;

   Tot_mcompensation_car += Brk_mcompensation_car;/*car*/
   Tot_mlia_prem_car += Brk_mlia_prem_car;/*car*/
   Tot_mlia_commi_car += Brk_mlia_commi_car;/*car*/

   Tot_mcompensation_moto += Brk_mcompensation_moto;/*moto*/
   Tot_mlia_prem_moto += Brk_mlia_prem_moto;/*moto*/
   Tot_mlia_commi_moto += Brk_mlia_commi_moto;/*moto*/

   rfmtdouble(Tot_mcompensation,",----,--&",buf1);
   strcpy(buf2, refmtamt(Tot_mlia_prem,MILLIONTH));
   strcpy(buf3, refmtamt(Tot_mlia_commi,MILLIONTH));

   /* �j��T���ۥ�   */
   rfmtdouble(Tot_mcompensation_car_14,",----,--&",bufC1_14);/*car*/
   strcpy(bufC2_14, refmtamt(Tot_mlia_prem_car_14,MILLIONTH));/*car*/
   strcpy(bufC3_14, refmtamt(Tot_mlia_commi_car_14,MILLIONTH));/*car*/

   /* �j��T���ӷ~   */
   rfmtdouble(Tot_mcompensation_car_15,",----,--&",bufC1_15);/*car*/
   strcpy(bufC2_15, refmtamt(Tot_mlia_prem_car_15,MILLIONTH));/*car*/
   strcpy(bufC3_15, refmtamt(Tot_mlia_commi_car_15,MILLIONTH));/*car*/

   /* �j������@�~�� */
   rfmtdouble(Tot_mcompensation_moto_p1,",----,--&",bufM1_P1);/*moto*/
   strcpy(bufM2_P1, refmtamt(Tot_mlia_prem_moto_p1,MILLIONTH));/*moto*/
   strcpy(bufM3_P1, refmtamt(Tot_mlia_commi_moto_p1,MILLIONTH));/*moto*/

   /* �j������G�~�� */
   rfmtdouble(Tot_mcompensation_moto_p2,",----,--&",bufM1_P2);/*moto*/
   strcpy(bufM2_P2, refmtamt(Tot_mlia_prem_moto_p2,MILLIONTH));/*moto*/
   strcpy(bufM3_P2, refmtamt(Tot_mlia_commi_moto_p2,MILLIONTH));/*moto*/
  
   /* �j��L���q�ʤG���@�~�� */
   rfmtdouble(Tot_mcompensation_moto35_p1,",----,--&",bufM1_P35_1);  /*moto35*/
   strcpy(bufM2_P35_1, refmtamt(Tot_mlia_prem_moto35_p1,MILLIONTH)); /*moto35*/
   strcpy(bufM3_P35_1, refmtamt(Tot_mlia_commi_moto35_p1,MILLIONTH));/*moto35*/
   
   /* �j��L���q�ʤG���G�~�� */
   rfmtdouble(Tot_mcompensation_moto35_p2,",----,--&",bufM1_P35_2);  /*moto35*/
   strcpy(bufM2_P35_2, refmtamt(Tot_mlia_prem_moto35_p2,MILLIONTH)); /*moto35*/
   strcpy(bufM3_P35_2, refmtamt(Tot_mlia_commi_moto35_p2,MILLIONTH));/*moto35*/
   
   /* �j��L���q�ʤG���T�~�� */
   rfmtdouble(Tot_mcompensation_moto35_p3,",----,--&",bufM1_P35_3);  /*moto35*/
   strcpy(bufM2_P35_3, refmtamt(Tot_mlia_prem_moto35_p3,MILLIONTH)); /*moto35*/
   strcpy(bufM3_P35_3, refmtamt(Tot_mlia_commi_moto35_p3,MILLIONTH));/*moto35*/

   /* �j��T�����X�p */
   rfmtdouble(Tot_mcompensation_car,",----,--&",bufC1);/*car*/
   strcpy(bufC2, refmtamt(Tot_mlia_prem_car,MILLIONTH));/*car*/
   strcpy(bufC3, refmtamt(Tot_mlia_commi_car,MILLIONTH));/*car*/

   /* �j��������X�p */
   rfmtdouble(Tot_mcompensation_moto,",----,--&",bufM1);/*moto*/
   strcpy(bufM2, refmtamt(Tot_mlia_prem_moto,MILLIONTH));/*moto*/
   strcpy(bufM3, refmtamt(Tot_mlia_commi_moto,MILLIONTH));/*moto*/

   /* �ťզC */
   rgu_put_body(10);                miy++;
   rgu_put_body(10);                miy++;

   rgu_put_body( 5);                miy++;

   /* �T���j�� */
   rgu_put_body_string( 6,"�j��ۥΨT���I",1); /* ��� */
   rgu_put_body_string( 6,bufC2_14,2); /* �O  �O */
   rgu_put_body_string( 6,"0",2);      /* ��  �� */
   rgu_put_body_string( 6,"0",2);      /* �N�z�O */
   rgu_put_body_string( 6,bufC3_14,2); /* ����O */
   /*rgu_put_body_string( 5,bufC1_14,2); *//* ���v�� */
   rgu_put_body( 6);                miy++;

   rgu_put_body_string( 6,"�j��ӷ~�T���I",1); /* ��� */
   rgu_put_body_string( 6,bufC2_15,2); /* �O  �O */
   rgu_put_body_string( 6,"0",2);      /* ��  �� */
   rgu_put_body_string( 6,"0",2);      /* �N�z�O */
   rgu_put_body_string( 6,bufC3_15,2); /* ����O */
   /*rgu_put_body_string( 6,bufC1_15,2); *//* ���v�� */
   rgu_put_body( 6);                miy++;

   /* �T���j��X�p */
   rgu_put_body_string( 7,"�X�p",1);
   rgu_put_body_string( 7,bufC2,2);    /* �O  �O */
   rgu_put_body_string( 7,"0",2);      /* ��  �� */
   rgu_put_body_string( 7,"0",2);      /* �N�z�O */
   rgu_put_body_string( 7,bufC3,2);    /* ����O */
   /*rgu_put_body_string( 6,bufC1,2); */   /* ���v�� */
   rgu_put_body( 7);                miy+=2;
   rgu_put_body(11);                miy+=1;

   /* �����j�� */
   rgu_put_body_string( 6,"�j������@�~��",1); /* ��� */
   rgu_put_body_string( 6,bufM2_P1,2); /* �O  �O */
   rgu_put_body_string( 6,"0",2);      /* ��  �� */
   rgu_put_body_string( 6,"0",2);      /* �N�z�O */
   rgu_put_body_string( 6,bufM3_P1,2); /* ����O */
   /*rgu_put_body_string( 6,bufM1_P1,2); *//* ���v�� */
   rgu_put_body( 6);                miy++;

   rgu_put_body_string( 6,"�j������G�~��",1); /* ��� */
   rgu_put_body_string( 6,bufM2_P2,2); /* �O  �O */
   rgu_put_body_string( 6,"0",2);      /* ��  �� */
   rgu_put_body_string( 6,"0",2);      /* �N�z�O */
   rgu_put_body_string( 6,bufM3_P2,2); /* ����O */
   /*rgu_put_body_string( 6,bufM1_P2,2); *//* ���v�� */
   rgu_put_body( 6);                miy++;

   /* �L�q���j�� */
   rgu_put_body_string( 6,"�j��L�q���@�~��",1); /* ��� */
   rgu_put_body_string( 6,bufM2_P35_1,2); /* �O  �O */
   rgu_put_body_string( 6,"0",2);      /* ��  �� */
   rgu_put_body_string( 6,"0",2);      /* �N�z�O */
   rgu_put_body_string( 6,bufM3_P35_1,2); /* ����O */
   rgu_put_body( 6);                miy++;

   rgu_put_body_string( 6,"�j��L�q���G�~��",1); /* ��� */
   rgu_put_body_string( 6,bufM2_P35_2,2); /* �O  �O */
   rgu_put_body_string( 6,"0",2);      /* ��  �� */
   rgu_put_body_string( 6,"0",2);      /* �N�z�O */
   rgu_put_body_string( 6,bufM3_P35_2,2); /* ����O */
   rgu_put_body( 6);                miy++;
   
   rgu_put_body_string( 6,"�j��L�q���T�~��",1); /* ��� */
   rgu_put_body_string( 6,bufM2_P35_3,2); /* �O  �O */
   rgu_put_body_string( 6,"0",2);      /* ��  �� */
   rgu_put_body_string( 6,"0",2);      /* �N�z�O */
   rgu_put_body_string( 6,bufM3_P35_3,2); /* ����O */
   rgu_put_body( 6);                miy++;

   /* �����j��X�p */
   rgu_put_body_string( 7,"�X�p",1);
   rgu_put_body_string( 7,bufM2,2);    /* �O  �O */
   rgu_put_body_string( 7,"0",2);      /* ��  �� */
   rgu_put_body_string( 7,"0",2);      /* �N�z�O */
   rgu_put_body_string( 7,bufM3,2);    /* ����O */
   /*rgu_put_body_string( 7,bufM1,2);  */  /* ���v�� */
   rgu_put_body( 7);                miy+=2;

   /* �`�p  */
   rgu_put_body_string( 7,"�`�p",1);
   rgu_put_body_string( 7,buf2,2);     /* �O  �O */
   rgu_put_body_string( 7,"0",2);      /* ��  �� */
   rgu_put_body_string( 7,"0",2);      /* �N�z�O */
   rgu_put_body_string( 7,buf3,2);     /* ����O */
   /*rgu_put_body_string( 7,buf1,2); */ /* ���v�� */
   rgu_put_body( 7);                miy+=2;

   printf("in car308_tot_2\n");
   printf("tot: cnt[%d][%ld] [%ld] [%ld] [%ld] [%8.3f]\n",
        cnt,Brk_mlia_prem,Brk_mlia_commi,Tot_mlia_prem,Tot_mlia_commi,Tot_mcompensation);

   printf("in car308_tot_2_car\n");/*car*/
   printf("tot: cnt[%d][%ld] [%ld] [%ld] [%ld] [%8.3f]\n",
        cnt,Brk_mlia_prem_car,Brk_mlia_commi_car,Tot_mlia_prem_car,Tot_mlia_commi_car,Tot_mcompensation_car);

   printf("in car308_tot_2_moto\n");/*moto*/
   printf("tot: cnt[%d][%ld] [%ld] [%ld] [%ld] [%8.3f]\n",
        cnt,Brk_mlia_prem_moto,Brk_mlia_commi_moto,Tot_mlia_prem_moto,Tot_mlia_commi_moto,Tot_mcompensation_moto);
    
    /*1080912006-SC1-�f�ӿo-�s�Wñ��������ˮ�*/
    printf("1080912006-SC1-�f�ӿo-�s�Wñ��������ˮ�\n");
    IfirstGlsForIns = get_gls_for_ins(char_plydate2, "C", "P", &rtncode, v_sMsg);
    if( rtncode != M_CM_OK) return rtncode;
    strcpy(kacctitem,    "");
    strcpy(kclsfyitem,    "");
    strcpy(eacc_title,    "");
    mdeal =0;    
    IcurrGlsForIns = IfirstGlsForIns;
    iseq = 0;
    while( IcurrGlsForIns)
    {
        printf("iseq[%d]kacctitem    [%s],"
               "kclsfyitem   [%s],"
               "eacc_title   [%s],"
               "mdeal        [%ld]\n",iseq,
                IcurrGlsForIns->kacctitem,
                IcurrGlsForIns->kclsfyitem,
                IcurrGlsForIns->eacc_title,
                IcurrGlsForIns->mdeal);
                
        strcpy(kacctitem,IcurrGlsForIns->kacctitem);
        strcpy(kclsfyitem,IcurrGlsForIns->kclsfyitem);
        strcpy(eacc_title,IcurrGlsForIns->eacc_title);
        mdeal =IcurrGlsForIns->mdeal;
        
        
        $INSERT INTO tmp_gl_list (iseq,kacctitem,kclsfyitem,eacc_title,mdeal)
              VALUES ($iseq,  $kacctitem,  $kclsfyitem,  $eacc_title,  $mdeal);
        iseq++;             
        IcurrGlsForIns = IcurrGlsForIns->next;
    }
    strcpy(kacctitem,    "");
    strcpy(kclsfyitem,    "");
    strcpy(eacc_title,    "");
    mdeal =0;
    rgu_put_body(12);                miy+=3;
    printf("*****************************************************************\n");
    $DECLARE gls_cur CURSOR FOR
      SELECT trim(kacctitem),trim(kclsfyitem),trim(eacc_title),mdeal
        INTO $kacctitem,     $kclsfyitem,      $eacc_title,     $mdeal
        FROM tmp_gl_list
       WHERE kclsfyitem in ('1400','1500','1600','1601','3210','3220','3230')
    ORDER BY iseq;
    $OPEN gls_cur;
    for(;;)
    {
         $FETCH gls_cur ;
         printf("kacctitem[%s]",kacctitem);
         printf("kclsfyitem[%s]\n",kclsfyitem);
         printf("mdeal[%ld]\n",mdeal);
         if (SQLCODE == SQLNOTFOUND) break;
    
        /*�|�p���4100�O�O���J/5103����O��X	�|�p�l��	��l�ئW��	�������B	�`�b���B	�t�B
         �]���^�Ǿ�i�ǲ����ӡA�ݬD�X�j���I���l�� 4100 �O�O���J 5103 ����O��X
         1400-�j��ۥΨT���I             1500-�j��ӷ~�T���I           1600-�j������@�~��            1601-�j������G�~��*/
        rgu_put_body_string(13,kacctitem,1);
        rgu_put_body_string(13,kclsfyitem,1);
        rgu_put_body_string(13,eacc_title,1);
        lDiff_ca_gl=0;
        
        strcpy(buf_GLS, refmtamt(mdeal,MILLIONTH));
        if (strncmp(kclsfyitem, "1400", 4) ==0)
        {
            if (strncmp(kacctitem, "4100", 4) ==0)
            {
                printf("Tot_mlia_prem_car_14[%ld]\n",Tot_mlia_prem_car_14);
                lDiff_ca_gl = Tot_mlia_prem_car_14 - mdeal ;
                printf("lDiff_ca_gl[%ld]\n",lDiff_ca_gl);
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                rgu_put_body_string(13,bufC2_14,1);
                rgu_put_body_string(13,buf_GLS,1);
                rgu_put_body_string(13,buf_Diff,1);
            }
            else
            {
                lDiff_ca_gl = Tot_mlia_commi_car_14 - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                rgu_put_body_string(13,bufC3_14,1);
                rgu_put_body_string(13,buf_GLS,1);
                rgu_put_body_string(13,buf_Diff,1);
            }
        }
        else if (strncmp(kclsfyitem, "1500", 4) ==0)
        {
            
            if (strncmp(kacctitem, "4100", 4) ==0)
            {
                lDiff_ca_gl = Tot_mlia_prem_car_15 - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                rgu_put_body_string(13,bufC2_15,1);
                rgu_put_body_string(13,buf_GLS,1);
                rgu_put_body_string(13,buf_Diff,1);
            }
            else
            {
                lDiff_ca_gl = Tot_mlia_commi_car_15 - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                rgu_put_body_string(13,bufC3_15,1);
                rgu_put_body_string(13,buf_GLS,1);
                rgu_put_body_string(13,buf_Diff,1);
            }
        }
        else if (strncmp(kclsfyitem, "1600", 4) ==0)
        {
            if (strncmp(kacctitem, "4100", 4) ==0)
            {
                lDiff_ca_gl = Tot_mlia_prem_moto_p1 - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                rgu_put_body_string(13,bufM2_P1,1);
                rgu_put_body_string(13,buf_GLS,1);
                rgu_put_body_string(13,buf_Diff,1);
            }
            else
            {
                lDiff_ca_gl = Tot_mlia_commi_moto_p1 - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                rgu_put_body_string(13,bufM3_P1,1);
                rgu_put_body_string(13,buf_GLS,1);
                rgu_put_body_string(13,buf_Diff,1);
            }
        }
        else if (strncmp(kclsfyitem, "1601", 4) ==0)
        {
            if (strncmp(kacctitem, "4100", 4) ==0)
            {
                lDiff_ca_gl = Tot_mlia_prem_moto_p2 - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                rgu_put_body_string(13,bufM2_P2,1);
                rgu_put_body_string(13,buf_GLS,1);
                rgu_put_body_string(13,buf_Diff,1);
            }
            else
            {
                lDiff_ca_gl = Tot_mlia_commi_moto_p2 - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                rgu_put_body_string(13,bufM3_P2,1);
                rgu_put_body_string(13,buf_GLS,1);
                rgu_put_body_string(13,buf_Diff,1);
            }
        }
        else if (strncmp(kclsfyitem, "3210", 4) ==0)
        {
            if (strncmp(kacctitem, "4100", 4) ==0)
            {
                lDiff_ca_gl = Tot_mlia_prem_moto35_p1 - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                rgu_put_body_string(13,bufM2_P35_1,1);
                rgu_put_body_string(13,buf_GLS,1);
                rgu_put_body_string(13,buf_Diff,1);
            }
            else
            {
                lDiff_ca_gl = Tot_mlia_commi_moto35_p1 - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                rgu_put_body_string(13,bufM3_P35_1,1);
                rgu_put_body_string(13,buf_GLS,1);
                rgu_put_body_string(13,buf_Diff,1);
            }
        } 
        else if (strncmp(kclsfyitem, "3220", 4) ==0)
        {
            if (strncmp(kacctitem, "4100", 4) ==0)
            {
                lDiff_ca_gl = Tot_mlia_prem_moto35_p2 - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                rgu_put_body_string(13,bufM2_P35_2,1);
                rgu_put_body_string(13,buf_GLS,1);
                rgu_put_body_string(13,buf_Diff,1);
            }
            else
            {
                lDiff_ca_gl = Tot_mlia_commi_moto35_p2 - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                rgu_put_body_string(13,bufM3_P35_2,1);
                rgu_put_body_string(13,buf_GLS,1);
                rgu_put_body_string(13,buf_Diff,1);
            }
        }
        else if (strncmp(kclsfyitem, "3230", 4) ==0)
        {
            if (strncmp(kacctitem, "4100", 4) ==0)
            {
                lDiff_ca_gl = Tot_mlia_prem_moto35_p3 - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                rgu_put_body_string(13,bufM2_P35_3,1);
                rgu_put_body_string(13,buf_GLS,1);
                rgu_put_body_string(13,buf_Diff,1);
            }
            else
            {
                lDiff_ca_gl = Tot_mlia_commi_moto35_p3 - mdeal ;
                strcpy(buf_Diff, refmtamt(lDiff_ca_gl,MILLIONTH));
                rgu_put_body_string(13,bufM3_P35_3,1);
                rgu_put_body_string(13,buf_GLS,1);
                rgu_put_body_string(13,buf_Diff,1);
            }
        }
        rgu_put_body(13);                miy++;
    }
    $CLOSE gls_cur;
    $FREE  gls_cur;
    printf("=================gls================================\n");
   linecnt = 0;
   cnt=0;

   Brk_mlia_prem  = 0;
   Brk_mlia_commi = 0;
   Tot_mlia_prem  = 0;
   Tot_mlia_commi = 0;
   
   Brk_mlia_prem_car  = 0;/*car*/
   Brk_mlia_commi_car = 0;/*car*/
   Tot_mlia_prem_car  = 0;/*car*/
   Tot_mlia_commi_car = 0;/*car*/

   Brk_mlia_prem_moto  = 0;/*moto*/
   Brk_mlia_commi_moto = 0;/*moto*/
   Tot_mlia_prem_moto  = 0;/*moto*/
   Tot_mlia_commi_moto = 0;/*moto*/

   pagenum += 1;
   return api_OKComplete;
errexit:
EWRITE(userid, SQLCODE, sqlca.sqlerrm);
return 0;
}

/*--------------------------------------------------------------------*/
car308_tot1()
{
   char buf1[20],buf2[20],buf3[20],buf4[20];
   int  i;

   car308_brk1();

   for(i=0;i<3;i++) {
       Tot_mpure_prem[3] += Tot_mpure_prem[i]; 
       Tot_mextra_charge[3] += Tot_mextra_charge[i];
       Tot_mply_prem[3] += Tot_mply_prem[i];
   }
   for(i=0;i<3;i++) {
       rfmtdouble(Tot_mpure_prem[i],"--,---,---.---",buf1);     
       rfmtdouble(Tot_mextra_charge[i],"--,---,---.---",buf2);     
       if (Tot_mply_prem[i]==0)
           Pextra_charge=0;
       else
           Pextra_charge=Tot_mextra_charge[i] / Tot_mply_prem[i] * 100;
       rfmtdouble(Pextra_charge,"----.--",buf3);     
       rfmtdouble(Tot_mply_prem[i], "-,---,---,--&", buf4); 
       rgu_put_body_string(5,buf1,2);
       rgu_put_body_string(5,buf2,2);
       rgu_put_body_string(5,buf3,2);
       rgu_put_body_string(5,buf4,2);
   }

   rgu_put_body( 5);                miy++;
   rfmtdouble(Tot_mpure_prem[3],"--,---,---.---",buf1);     
   rfmtdouble(Tot_mextra_charge[3],"--,---,---.---",buf2);     
   if (Tot_mply_prem[3]==0)
       Pextra_charge=0;
   else
       Pextra_charge=Tot_mextra_charge[3] / Tot_mply_prem[3] * 100;
   rfmtdouble(Pextra_charge,"----.--",buf3);     
   rfmtdouble(Tot_mply_prem[3], "-,---,---,--&", buf4); 
   rgu_put_body_string(6,buf1,2);
   rgu_put_body_string(6,buf2,2);
   rgu_put_body_string(6,buf3,2);
   rgu_put_body_string(6,buf4,2);
   rgu_put_body( 6);                miy++;
   rgu_put_body( 3);                miy++;

   linecnt = 0;
   cnt=0;
   pagenum += 1;

   for(i=0;i<4;i++)
       Tot_mpure_prem[i]=Tot_mextra_charge[i]=Tot_mply_prem[i]=0;
}

/*--------------------------------------------------------------------*/
long car308_data()
{
   $char stmt_buf1[3000], stmt_buf2[4000], stmt_buf3[4000];
   $char stmt_bufCM[4000];
   $char stm_ply1[21], stm_ply2[21], stm_ply3[21];
   $char stm_plyCM[21], sTmp[51];
      
   char  dt_brk[3], abn_brk[4], brh_brk[4];
   int   i, first, s_branch_cnt=0;

   $char  iproduct[13];
   $char  kclsfyitem[5];
   $char  kreserve[6];
   $char  provision[21],drate_ym[5];
   long   rtncode;

	 $char buf1_00[300],buf1_22[300],buf1_33[300],buf1_40[300],buf1_66[300],buf1_70[300];
	 $char buf2_00[400],buf2_22[400],buf2_33[400],buf2_40[400],buf2_66[400],buf2_70[400];
	 $char buf3_00[400],buf3_22[400],buf3_33[400],buf3_40[400],buf3_66[400],buf3_70[400];
	 $char bufCM_00[400],bufCM_22[400],bufCM_33[400],bufCM_40[400],bufCM_66[400],bufCM_70[400];
	 
   /* �j��T��[�ۥ�] */
   Tot_mcompensation_car_14=0.0;
   Tot_mlia_prem_car_14=0;
   Tot_mlia_commi_car_14=0;

   /* �j��T��[�ӷ~] */
   Tot_mcompensation_car_15=0.0;
   Tot_mlia_prem_car_15=0;
   Tot_mlia_commi_car_15=0;

   /* �j�����[�@�~��] */
   Tot_mcompensation_moto_p1=0.0;
   Tot_mlia_prem_moto_p1=0;
   Tot_mlia_commi_moto_p1=0;

   /* �j�����[�G�~��] */
   Tot_mcompensation_moto_p2=0.0;
   Tot_mlia_prem_moto_p2=0;
   Tot_mlia_commi_moto_p2=0;
   
   /* �j��L���q�ʤG��[�@�~��] */
   Tot_mcompensation_moto35_p1=0.0;
   Tot_mlia_prem_moto35_p1=0;
   Tot_mlia_commi_moto35_p1=0;
   
   /* �j��L���q�ʤG��[�G�~��] */
   Tot_mcompensation_moto35_p2=0.0;
   Tot_mlia_prem_moto35_p2=0;
   Tot_mlia_commi_moto35_p2=0;
   
   /* �j��L���q�ʤG��[�T�~��] */
   Tot_mcompensation_moto35_p3=0.0;
   Tot_mlia_prem_moto35_p3=0;
   Tot_mlia_commi_moto35_p3=0;

   first = 1;
   miy=0;
   memset(Icar_type,0,sizeof(Icar_type));

   $WHENEVER SQLERROR GOTO errexit;

   strcpy(dt_brk,"  ");    /*  initialize dt_brk  */
   if (flag_check == 1)
   {
        strcpy(stm_ply1,  "ply_relation");
        strcpy(stm_ply2,  "policy");
        strcpy(stm_ply3,  "ply_ins_type");
        strcpy(stm_plyCM, "ply_relation");
   }
   else
   {
        strcpy(stm_ply1,  "ori_ply_relation");
        strcpy(stm_ply2,  "original_ply");
        strcpy(stm_ply3,  "ori_ins_type");
        strcpy(stm_plyCM, "ori_ply_relation");
   }

   /***** prepare cursor for select ply_relation *****/
   /* �t�X�q���ĤG���q�Ұ�,�H[�I����Hicomm_obj]���N[�g���Hibroker]��� modify by sylvia 100.06.03 */
   /* �t�X�]�|���پ�X,�u�b�x�_����,�����]6�Ӹ�Ʈw���,�����U�e����J���O�ݨD,��Hunion��s���Ӹ�Ʈw��� */
   /* sprintf(stmt_buf1,"SELECT %s %s %s FROM %s:%s %s %s",
                     "ipolicy,icard,icomm_obj,icar_type,mlia_agent,mlia_prem,",
                     "mlia_commi,mcompensation,iofficer,icashier,iresource,",
                     "dply_begin,dply_end,qply_period",
                     FullDBName, stm_ply1,
                     "WHERE fcard_class='1' AND dpolicy=? AND ipolicy MATCHES ? AND dply_close is not null",
                     "ORDER BY ipolicy,icard"); */
   
   sprintf_s(buf1_00,sizeof buf1_00,"SELECT %s %s %s FROM newa00:%s %s ",
                     "ipolicy,icard,icomm_obj,icar_type,mlia_agent,mlia_prem,",
                     "mlia_commi,mcompensation,iofficer,icashier,iresource,",
                     "dply_begin,dply_end,qply_period",
                     stm_ply1,
                     "WHERE fcard_class='1' AND dpolicy=? AND ipolicy MATCHES ? AND dply_close is not null");
   sprintf_s(buf1_22,sizeof buf1_22,"SELECT %s %s %s FROM newa22:%s %s ",
                     "ipolicy,icard,icomm_obj,icar_type,mlia_agent,mlia_prem,",
                     "mlia_commi,mcompensation,iofficer,icashier,iresource,",
                     "dply_begin,dply_end,qply_period",
                     stm_ply1,
                     "WHERE fcard_class='1' AND dpolicy=? AND ipolicy MATCHES ? AND dply_close is not null");
   sprintf_s(buf1_33,sizeof buf1_33,"SELECT %s %s %s FROM newa33:%s %s ",
                     "ipolicy,icard,icomm_obj,icar_type,mlia_agent,mlia_prem,",
                     "mlia_commi,mcompensation,iofficer,icashier,iresource,",
                     "dply_begin,dply_end,qply_period",
                     stm_ply1,
                     "WHERE fcard_class='1' AND dpolicy=? AND ipolicy MATCHES ? AND dply_close is not null");
   sprintf_s(buf1_40,sizeof buf1_40,"SELECT %s %s %s FROM newa40:%s %s ",
                     "ipolicy,icard,icomm_obj,icar_type,mlia_agent,mlia_prem,",
                     "mlia_commi,mcompensation,iofficer,icashier,iresource,",
                     "dply_begin,dply_end,qply_period",
                     stm_ply1,
                     "WHERE fcard_class='1' AND dpolicy=? AND ipolicy MATCHES ? AND dply_close is not null");
   sprintf_s(buf1_66,sizeof buf1_66,"SELECT %s %s %s FROM newa66:%s %s ",
                     "ipolicy,icard,icomm_obj,icar_type,mlia_agent,mlia_prem,",
                     "mlia_commi,mcompensation,iofficer,icashier,iresource,",
                     "dply_begin,dply_end,qply_period",
                     stm_ply1,
                     "WHERE fcard_class='1' AND dpolicy=? AND ipolicy MATCHES ? AND dply_close is not null");                     
   sprintf_s(buf1_70,sizeof buf1_70,"SELECT %s %s %s FROM newa70:%s %s %s",
                     "ipolicy,icard,icomm_obj,icar_type,mlia_agent,mlia_prem,",
                     "mlia_commi,mcompensation,iofficer,icashier,iresource,",
                     "dply_begin,dply_end,qply_period",
                     stm_ply1,
                     "WHERE fcard_class='1' AND dpolicy=? AND ipolicy MATCHES ? AND dply_close is not null",
                     "ORDER BY ipolicy,icard");
                     
   sprintf_s(stmt_buf1,sizeof stmt_buf1, "%s union all %s union all %s union all %s union all %s union all %s",
           buf1_00, buf1_22, buf1_33, buf1_40, buf1_66, buf1_70);
   $PREPARE CUR_STMT1 FROM $stmt_buf1;
   $DECLARE scur_ply1 CURSOR FOR CUR_STMT1;
   printf("%s\n",stmt_buf1);

   /***** prepare cursor for select original_ply *****/
   /* sprintf(stmt_buf2,"SELECT %s FROM %s:%s %s",
                     "nassured",
                     FullDBName, stm_ply2,
                     "WHERE ipolicy=? AND icard=?"); */
   sprintf_s(buf2_00,sizeof buf2_00,"SELECT nassured FROM newa00:%s WHERE ipolicy=? AND icard=?", stm_ply2);
   sprintf_s(buf2_22,sizeof buf2_22,"SELECT nassured FROM newa22:%s WHERE ipolicy=? AND icard=?", stm_ply2);
   sprintf_s(buf2_33,sizeof buf2_33,"SELECT nassured FROM newa33:%s WHERE ipolicy=? AND icard=?", stm_ply2);
   sprintf_s(buf2_40,sizeof buf2_40,"SELECT nassured FROM newa40:%s WHERE ipolicy=? AND icard=?", stm_ply2);
   sprintf_s(buf2_66,sizeof buf2_66,"SELECT nassured FROM newa66:%s WHERE ipolicy=? AND icard=?", stm_ply2);
   sprintf_s(buf2_70,sizeof buf2_70,"SELECT nassured FROM newa70:%s WHERE ipolicy=? AND icard=?", stm_ply2);
   sprintf_s(stmt_buf2,sizeof stmt_buf2,"%s union all %s union all %s union all %s union all %s union all %s", 
           buf2_00, buf2_22, buf2_33, buf2_40, buf2_66, buf2_70 );
   printf("stmt_buf2=[%s]\n",stmt_buf2);
	            
   $PREPARE CUR_STMT2 FROM $stmt_buf2;
   $DECLARE scur_policy1 CURSOR FOR CUR_STMT2;

   /***** prepare cursor for select ori_ins_type *****/
   /* sprintf(stmt_buf3,"SELECT %s FROM %s:%s %s",
                     "mdamage_cover, iproduct[4,5], provision",
                     FullDBName, stm_ply3,
                     "WHERE ipolicy=?"); */
   sprintf_s(buf3_00,sizeof buf3_00,"SELECT %s FROM newa00:%s WHERE ipolicy=? ",
                   "mdamage_cover, iproduct[4,5], provision,drate_ym", stm_ply3);
   sprintf_s(buf3_22,sizeof buf3_22,"SELECT %s FROM newa22:%s WHERE ipolicy=? ",
                   "mdamage_cover, iproduct[4,5], provision,drate_ym", stm_ply3);
   sprintf_s(buf3_33,sizeof buf3_33,"SELECT %s FROM newa33:%s WHERE ipolicy=? ",
                   "mdamage_cover, iproduct[4,5], provision,drate_ym", stm_ply3);
   sprintf_s(buf3_40,sizeof buf3_40,"SELECT %s FROM newa40:%s WHERE ipolicy=? ",
                   "mdamage_cover, iproduct[4,5], provision,drate_ym", stm_ply3);
   sprintf_s(buf3_66,sizeof buf3_66,"SELECT %s FROM newa66:%s WHERE ipolicy=? ",
                   "mdamage_cover, iproduct[4,5], provision,drate_ym", stm_ply3);
   sprintf_s(buf3_70,sizeof buf3_70,"SELECT %s FROM newa70:%s WHERE ipolicy=? ",
                   "mdamage_cover, iproduct[4,5], provision,drate_ym", stm_ply3);
   sprintf_s(stmt_buf3,sizeof stmt_buf3,"%s union all %s union all %s union all %s union all %s union all %s", 
           buf3_00, buf3_22, buf3_33, buf3_40, buf3_66, buf3_70 );
   printf("stmt_buf3=[%s]\n",stmt_buf3);	                    
   $PREPARE CUR_STMT3 FROM $stmt_buf3;
   $DECLARE scur_ins_type1 CURSOR FOR CUR_STMT3;

   /***** prepare cursor for select ply_relation *****/
   /* sprintf(stmt_bufCM,"SELECT %s FROM %s:%s %s",
                      "mlia_prem,mlia_commi,mcompensation",
                      FullDBName, stm_plyCM,
                      "WHERE ipolicy=?"); */
   sprintf_s(bufCM_00,sizeof bufCM_00,"SELECT %s FROM newa00:%s WHERE ipolicy=? ",
                      "mlia_prem,mlia_commi,mcompensation", stm_plyCM);
   sprintf_s(bufCM_22,sizeof bufCM_22,"SELECT %s FROM newa22:%s WHERE ipolicy=? ",
                      "mlia_prem,mlia_commi,mcompensation", stm_plyCM);
   sprintf_s(bufCM_33,sizeof bufCM_33,"SELECT %s FROM newa33:%s WHERE ipolicy=? ",
                      "mlia_prem,mlia_commi,mcompensation", stm_plyCM);
   sprintf_s(bufCM_40,sizeof bufCM_40,"SELECT %s FROM newa40:%s WHERE ipolicy=? ",
                      "mlia_prem,mlia_commi,mcompensation", stm_plyCM);
   sprintf_s(bufCM_66,sizeof bufCM_66,"SELECT %s FROM newa66:%s WHERE ipolicy=? ",
                      "mlia_prem,mlia_commi,mcompensation", stm_plyCM);
   sprintf_s(bufCM_70,sizeof bufCM_70,"SELECT %s FROM newa70:%s WHERE ipolicy=? ",
                      "mlia_prem,mlia_commi,mcompensation", stm_plyCM);
   sprintf_s(stmt_bufCM,sizeof stmt_bufCM,"%s union all %s union all %s union all %s union all %s union all %s", 
           bufCM_00, bufCM_22, bufCM_33, bufCM_40, bufCM_66, bufCM_70 );
   printf("stmt_bufCM=[%s]\n",stmt_bufCM);
	 
   $PREPARE CUR_STMTCM FROM $stmt_bufCM;
   $DECLARE scur_plyCM CURSOR FOR CUR_STMTCM;

   $OPEN scur_ply1 USING $char_plydate2, $sIbranchIcomp,
                         $char_plydate2, $sIbranchIcomp,
                         $char_plydate2, $sIbranchIcomp,
                         $char_plydate2, $sIbranchIcomp,
                         $char_plydate2, $sIbranchIcomp,
                         $char_plydate2, $sIbranchIcomp;

   /*---- START PROCESS ----*/
   while (1)
   {
      $FETCH scur_ply1
        INTO $Ipolicy, $Icard, $sIcomm_obj, $Icar_type, $Mlia_agent,
             $Mlia_prem, $Mlia_commi, $Mcompensation,
             $Iofficer, $Icashier, $Iresource, $long_dply_begin,
             $long_dply_end, $Dply_period;

      if (SQLCODE == SQLNOTFOUND) break;

      strcpy(Icar_type,trim(Icar_type));

      $OPEN  scur_policy1 USING $Ipolicy, $Icard, $Ipolicy, $Icard,
                                $Ipolicy, $Icard, $Ipolicy, $Icard,
                                $Ipolicy, $Icard, $Ipolicy, $Icard;
      $FETCH scur_policy1 INTO $Nassured;
      $CLOSE scur_policy1;
      if (SQLCODE == SQLNOTFOUND) continue;

      $OPEN  scur_ins_type1 USING $Ipolicy, $Ipolicy, $Ipolicy, $Ipolicy, $Ipolicy, $Ipolicy;
      $FETCH scur_ins_type1 INTO $Mdamage_cover, $Iacc_type, $provision,$drate_ym;
      $CLOSE scur_ins_type1;
      if (SQLCODE == SQLNOTFOUND) continue;

      /* ���v����|�ˤ��J�ܾ�Ʀ� */
      Mcompensation = (double)((long)(Mcompensation+0.5));

      strcpy(Icar_type , trim(Icar_type));
      if ((strcmp(Icar_type,"01")==0) || (strcmp(Icar_type,"02")==0) ||
          (strcmp(Icar_type,"32")==0) || (strcmp(Icar_type,"34")==0) || (strcmp(Icar_type,"35")==0))
      {
           Mlia_prem_moto     = Mlia_prem;
           Mlia_commi_moto    = Mlia_commi;
           Mcompensation_moto = (double)((long)(Mcompensation+0.5));
           Mlia_prem_car      = Mlia_commi_car = Mcompensation_car = 0;
      }
      else
      {
           Mlia_prem_car     = Mlia_prem;
           Mlia_commi_car    = Mlia_commi;
           Mcompensation_car = (double)((long)(Mcompensation+0.5));
           Mlia_prem_moto    = Mlia_commi_moto = Mcompensation_moto = 0;
      }

      printf("==============================> Dply_begin[%s]\n",Dply_begin);

      /* ���q�Ϥ������@�~���ΤG�~���A�ΨT���Ϥ��ۥΩΰӷ~�A */
      /* ����|�p��l�� */
      strcpy(drate_ym ,trim(drate_ym) );
      rtncode = get_product_code_car("C","21",Icar_type,Dply_period,iproduct,kclsfyitem,kreserve, provision,drate_ym);
      if (rtncode != M_CM_OK)
      {
           return rtncode;
      }

      strcpy(kclsfyitem,trim(kclsfyitem));

      if (strcmp(kclsfyitem,"1400")==0)  /* �j��ۥΨT���I */
      {
           Tot_mcompensation_car_14 += Mcompensation;
           Tot_mlia_prem_car_14     += Mlia_prem;
           Tot_mlia_commi_car_14    += Mlia_commi;
      }

      if (strcmp(kclsfyitem,"1500")==0)  /* �j��ӷ~�T���I */
      {
           Tot_mcompensation_car_15 += Mcompensation;
           Tot_mlia_prem_car_15     += Mlia_prem;
           Tot_mlia_commi_car_15    += Mlia_commi;
      }

      if (strcmp(kclsfyitem,"1600")==0)  /* �j������@�~�� */
      {
           Tot_mcompensation_moto_p1 += Mcompensation;
           Tot_mlia_prem_moto_p1     += Mlia_prem;
           Tot_mlia_commi_moto_p1    += Mlia_commi;
      }

      if (strcmp(kclsfyitem,"1601")==0)  /* �j������G�~�� */
      {
           Tot_mcompensation_moto_p2 += Mcompensation;
           Tot_mlia_prem_moto_p2     += Mlia_prem;
           Tot_mlia_commi_moto_p2    += Mlia_commi;
      }
      
      if (strcmp(kclsfyitem,"3210")==0)  /* �j��L���q�ʤG���@�~�� */
      {
           Tot_mcompensation_moto35_p1 += Mcompensation;
           Tot_mlia_prem_moto35_p1     += Mlia_prem;
           Tot_mlia_commi_moto35_p1    += Mlia_commi;
      }
      
      if (strcmp(kclsfyitem,"3220")==0)  /* �j��L���q�ʤG���G�~�� */
      {
           Tot_mcompensation_moto35_p2 += Mcompensation;
           Tot_mlia_prem_moto35_p2     += Mlia_prem;
           Tot_mlia_commi_moto35_p2    += Mlia_commi;
      }
      
      if (strcmp(kclsfyitem,"3230")==0)  /* �j��L���q�ʤG���T�~�� */
      {
           Tot_mcompensation_moto35_p3 += Mcompensation;
           Tot_mlia_prem_moto35_p3     += Mlia_prem;
           Tot_mlia_commi_moto35_p3    += Mlia_commi;
      }

      if (strncmp(dt_brk, "  ", 2) == 0)
      {
          strncpy(dt_brk, Dply_begin, 2); dt_brk[2]='\0';
          strncpy(abn_brk, &Ipolicy[5], 2); abn_brk[2]='\0';
          strncpy(brh_brk, Ipolicy, 2); brh_brk[2]='\0';
      }

      if ((strncmp(dt_brk, Dply_begin, 2) != 0) ||
          (strncmp(abn_brk, &Ipolicy[5], 2) !=0) ||
          (strncmp(brh_brk, Ipolicy, 2) !=0))
      {
          car308_brk();
          strncpy(dt_brk, Dply_begin, 2); dt_brk[2]='\0';
          strncpy(abn_brk, &Ipolicy[5], 2); abn_brk[2]='\0';
          strncpy(brh_brk, Ipolicy, 2); brh_brk[2]='\0';
      }

      car308_body();
      cnt++;

   } /* end while */

   $CLOSE scur_ply1;

   $FREE scur_ply1;
   $FREE scur_policy1;
   $FREE scur_ins_type1;
   $FREE scur_plyC;
   $FREE scur_plyM;

   printf("**********before car308_tot: s_branch_cnt[%d]\n",s_branch_cnt);

   if (cnt > 0) car308_tot();

   return SUCCESS;

errexit:
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return 0;
}

/*--------------------------------------------------------------------*/
long car308_data1()
{
   $char stmt_buf1[4000], stmt_buf2[400], stmt_buf3[4000];
   $char stmt_bufCM[400];
   $char stm_ply1[21], stm_ply2[21], stm_ply3[21];
   $char stm_plyCM[21];
   $char buf1_00[400], buf1_22[400], buf1_33[400], buf1_40[400], buf1_66[400], 
         buf1_70[400];
	 $char buf3_00[400], buf3_22[400], buf3_33[400], buf3_40[400], buf3_66[400], 
         buf3_70[400];
   int   i, first, s_branch_cnt;

   first = 1;
   miy=0;
   memset(Icar_type,0,sizeof(Icar_type));

   $WHENEVER SQLERROR GOTO errexit;

   for(i=0;i<4;i++) {
       Brk_mpure_prem[i]=Tot_mpure_prem[i]=0;
       Brk_mextra_charge[i]=Tot_mextra_charge[i]=0;
       Brk_mply_prem[i]=Tot_mply_prem[i]=0;
   }

   strcpy(pre_branch,"  ");    /*  initialize */
   if (flag_check == 1)
   {
      strcpy(stm_ply1, "ply_relation");
      strcpy(stm_ply2, "policy");
      strcpy(stm_ply3, "ply_ins_type");
      strcpy(stm_plyCM, "ply_relation");
   } else {
      strcpy(stm_ply1, "ori_ply_relation");
      strcpy(stm_ply2, "original_ply");
      strcpy(stm_ply3, "ori_ins_type");
      strcpy(stm_plyCM, "ori_ply_relation");
   }

      /***** prepare cursor for select ply_relation *****/
      /* �t�X�]�|���پ�X,�u�b�x�_����,�����]6�Ӹ�Ʈw���,�����U�e����J���O�ݨD,��Hunion��s���Ӹ�Ʈw��� */   
      /* sprintf(stmt_buf1,"SELECT %s FROM %s:%s a,%s:%s b %s %s %s",
        "a.ipolicy,a.icard,iquota[1,4],iofficer,nassured",
         FullDBName,stm_ply1,FullDBName,stm_ply2,
        "WHERE fcard_class='1' AND dpolicy=? AND a.ipolicy MATCHES ?",
        "AND a.ipolicy=b.ipolicy ",
        "ORDER BY 1,2"); */
   sprintf_s(buf1_00,sizeof buf1_00,"SELECT %s FROM newa00:%s a,newa00:%s b %s %s ",
                      "a.ipolicy,a.icard,iquota[1,4],iofficer,nassured",
                      stm_ply1,stm_ply2,
                      "WHERE fcard_class='1' AND dpolicy=? AND a.ipolicy MATCHES ?",
                      "AND a.ipolicy=b.ipolicy ");
   sprintf_s(buf1_22,sizeof buf1_22,"SELECT %s FROM newa22:%s a,newa22:%s b %s %s ",
                      "a.ipolicy,a.icard,iquota[1,4],iofficer,nassured",
                      stm_ply1,stm_ply2,
                      "WHERE fcard_class='1' AND dpolicy=? AND a.ipolicy MATCHES ?",
                      "AND a.ipolicy=b.ipolicy ");
   sprintf_s(buf1_33,sizeof buf1_33,"SELECT %s FROM newa33:%s a,newa33:%s b %s %s ",
                      "a.ipolicy,a.icard,iquota[1,4],iofficer,nassured",
                      stm_ply1,stm_ply2,
                      "WHERE fcard_class='1' AND dpolicy=? AND a.ipolicy MATCHES ?",
                      "AND a.ipolicy=b.ipolicy ");
   sprintf_s(buf1_40,sizeof buf1_40,"SELECT %s FROM newa40:%s a,newa40:%s b %s %s ",
                      "a.ipolicy,a.icard,iquota[1,4],iofficer,nassured",
                      stm_ply1,stm_ply2,
                      "WHERE fcard_class='1' AND dpolicy=? AND a.ipolicy MATCHES ?",
                      "AND a.ipolicy=b.ipolicy ");
   sprintf_s(buf1_66,sizeof buf1_66,"SELECT %s FROM newa66:%s a,newa66:%s b %s %s ",
                      "a.ipolicy,a.icard,iquota[1,4],iofficer,nassured",
                      stm_ply1,stm_ply2,
                      "WHERE fcard_class='1' AND dpolicy=? AND a.ipolicy MATCHES ?",
                      "AND a.ipolicy=b.ipolicy ");
   sprintf_s(buf1_70,sizeof buf1_70,"SELECT %s FROM newa70:%s a,newa70:%s b %s %s %s ",
                      "a.ipolicy,a.icard,iquota[1,4],iofficer,nassured",
                      stm_ply1,stm_ply2,
                      "WHERE fcard_class='1' AND dpolicy=? AND a.ipolicy MATCHES ?",
                      "AND a.ipolicy=b.ipolicy ", "ORDER BY 1,2");
                      
   sprintf_s(stmt_buf1,sizeof stmt_buf1, "%s union all %s union all %s union all %s union all %s union all %s ",
			        buf1_00, buf1_22, buf1_33, buf1_40, buf1_66, buf1_70);
			        
   printf("stmt_buf1=[%s]\n",stmt_buf1);
      $PREPARE CUR_STMT11 FROM $stmt_buf1;
      $DECLARE scur_ply11 CURSOR FOR CUR_STMT11;

      /***** prepare cursor for select ori_ins_type 84.10.27 by Bai *****/
      /* sprintf(stmt_buf3,"SELECT %s FROM %s:%s %s",
                        "iproduct[4,5],mins_premium,nvl(mpure_prem,0)",
                        FullDBName,stm_ply3,
                        "WHERE ipolicy=?"); */
   sprintf_s(buf3_00,sizeof buf3_00,"SELECT %s FROM newa00:%s WHERE ipolicy=? ",
                      "iproduct[4,5],mins_premium,nvl(mpure_prem,0)", stm_ply3);
   sprintf_s(buf3_22,sizeof buf3_22,"SELECT %s FROM newa22:%s WHERE ipolicy=? ",
                      "iproduct[4,5],mins_premium,nvl(mpure_prem,0)", stm_ply3);
   sprintf_s(buf3_33,sizeof buf3_33,"SELECT %s FROM newa33:%s WHERE ipolicy=? ",
                      "iproduct[4,5],mins_premium,nvl(mpure_prem,0)", stm_ply3);
   sprintf_s(buf3_40,sizeof buf3_40,"SELECT %s FROM newa40:%s WHERE ipolicy=? ",
                      "iproduct[4,5],mins_premium,nvl(mpure_prem,0)", stm_ply3);
   sprintf_s(buf3_66,sizeof buf3_66,"SELECT %s FROM newa66:%s WHERE ipolicy=? ",
                      "iproduct[4,5],mins_premium,nvl(mpure_prem,0)", stm_ply3);
   sprintf_s(buf3_70,sizeof buf3_70,"SELECT %s FROM newa70:%s WHERE ipolicy=? ",
                      "iproduct[4,5],mins_premium,nvl(mpure_prem,0)", stm_ply3);
                      
   sprintf_s(stmt_buf3,sizeof stmt_buf3, "%s union all %s union all %s union all %s union all %s union all %s ",
			        buf3_00, buf3_22, buf3_33, buf3_40, buf3_66, buf3_70);    
   printf("stmt_buf3=[%s]\n",stmt_buf3);
						        
      $PREPARE CUR_STMT31 FROM $stmt_buf3;
      $DECLARE scur_ins_type11 CURSOR FOR CUR_STMT31;

      $OPEN scur_ply11 USING $char_plydate2, $sIbranchIcomp, 
                             $char_plydate2, $sIbranchIcomp,
                             $char_plydate2, $sIbranchIcomp,
                             $char_plydate2, $sIbranchIcomp,
                             $char_plydate2, $sIbranchIcomp,
                             $char_plydate2, $sIbranchIcomp;

      /*---- START PROCESS ----*/
      while (1)
      {
         $FETCH scur_ply11
           INTO $Ipolicy, $Icard, $Iquota, $Iofficer, $Nassured;
         
         if (SQLCODE == SQLNOTFOUND) break;

         Iquota[4]='\0';
         strcat(Iquota,"00");
         $SELECT nbranch INTO $Nbranch
            FROM sa_branch_type
           WHERE ibranch = $Iquota;
 
         $OPEN scur_ins_type11 USING $Ipolicy, $Ipolicy, $Ipolicy, $Ipolicy,
                                     $Ipolicy, $Ipolicy;
         $FETCH scur_ins_type11
           INTO $Iacc_type,$Mlia_prem,$Mpure_prem;
         $CLOSE scur_ins_type11;
         if (SQLCODE == SQLNOTFOUND) continue;

         Mextra_charge = Mlia_prem - Mpure_prem;

         if (strncmp(pre_branch,"  ", 2) == 0) {
             strncpy(pre_branch, Ipolicy, 2); pre_branch[2]='\0';
             $SELECT nchi_full
                INTO $nchi_abv FROM branch
               WHERE ibranch = $pre_branch;
              rgu_put_body_string(1,pre_branch,1);
              rgu_put_body_string(1,nchi_abv,1);
              rgu_put_body(1);
         }

         if (strncmp(pre_branch, Ipolicy, 2) !=0)
         {
             car308_tot1();
             rgu_put_body(NEXTPAGE);          miy++;
             strncpy(pre_branch, Ipolicy, 2); pre_branch[2]='\0';
             $SELECT nchi_full
                INTO $nchi_abv FROM branch
               WHERE ibranch = $pre_branch;
              rgu_put_body_string(1,pre_branch,1);
              rgu_put_body_string(1,nchi_abv,1);
              rgu_put_body(1);
         }

         car308_body1();
         cnt++;

      } /* end while */

      $CLOSE scur_ply11;

      $FREE scur_ply11;
      $FREE scur_ins_type11;

     if (cnt > 0) car308_tot1();

   return SUCCESS;

errexit:
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return 0;
}
/*--------------------------------------------------------------------*/
