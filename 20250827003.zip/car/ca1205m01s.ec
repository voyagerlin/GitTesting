/**********************************************************************/
/*   program id   : car1205m01s.ec                                    */
/*   program name : �z�ߵ��׳��i��EDM���@                             */
/*   date modified: 080284     2019/05/15                             */
/*   date modify  :                                                   */
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"
$include sqlca;
$include "var_length.h";

$char iassured[121] , nassured[13] , itag[26] , aassured_zip[CA_ZIP]  , iclaim[21] , adjustment[11] , dclaim[11] , dcontact[18];
$char dverify[18] , dsurvey[18] , fdmg_duty[20] , dgroup[11] , fedm[2] , dedm[18] , iemail[51] , iroute[21] ;
$char nroute[41] , ipolicy[21] , iadj_tel[21] ;
$char icreate[11] , dcreate[25] , iupdate[11] , dupdate[25] , ncreate[31] , nupdate[31];
$int msettle_dmg = 0;
$char assured[133] , aassured[96] , nadjust[41] , route[61];
$char slt_iclaim[21] , slt_itag[26] , slt_iroute[21] , slt_fedm[2] , slt_dedm_bgn[11] , slt_dedm_end[11] , slt_dcreate_bgn[25] , slt_dcreate_end[25];
$char old_fedm[2];

long car1205(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car1205_single_query(),car1205_multiple_query();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'Q':
           rtncode=car1205_single_query(reply);
           break;
  case 'M':
           rtncode=car1205_multiple_query(reply);
           break;
  case 'U':rtncode=car1205_update_exec(reply,command,com_len);
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
             return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

/*----------------------------------------------------------------------------*/

long car1205_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    $char DBName[5],icard[18], stmp_sql[2000],old_icard[18];
    char   option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
    int    tmp_len,raw_len;
    long   dummy;
    long   MsgCode;
    char   tmp_buf[20];
    long   tmp_long;
    $int   iRows;
    int lenErr,icnt,i,x;
    char strmax[20],strmin[20];
	$char stmt[20000];


    comm = (char *) command;
    cm_buf_init(command);
    cm_buf_get("%c %s %s ", &option, DBName, old_fedm);



    if(db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

	$BEGIN WORK;

    $WHENEVER SQLERROR GOTO errexit;

    if(option == 'U')
    {
         printf("OPTION U");

         cm_buf_init(command);
         cm_buf_get("%c %s %s %s %s %s", &option, DBName , fedm , iupdate , dupdate , iclaim);

        sprintf_s(stmt,20000,"UPDATE ca_edm    "
                     "   SET fedm = '%s' ,     "
                     "       iupdate = '%s', "
					 "       dupdate = '%s' "
                     " WHERE iclaim = '%s'   "
                     , fedm , iupdate , dupdate , iclaim);

		printf("stmt=[%s]\n", stmt);
        $prepare p_sq from $stmt;
        $EXECUTE p_sq;

         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OK);
         tmp_len = cm_buf_len(ReplyBuf);

         if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
         {
             $WHENEVER SQLERROR CONTINUE;
             $ROLLBACK WORK;
             return apiRC;
         }

         $WHENEVER SQLERROR GOTO errexit;
         $COMMIT WORK;
         return api_OKComplete;
    }
    else
    {
         return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
    }
errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/*----------------------------------------------------------------------------*/

long car1205_single_query(reply)
serverReply reply;
{
    $char DBName[5],icard[18],date1[11];

    int tmp_len,lenErr,icnt,i,x;
    char strmax[20],strmin[20];

    cm_buf_get("%s %s %s %s %s %s %s  ", DBName , iclaim , itag , iroute , fedm , dedm  , dcreate  );

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $SELECT
		TRIM(e.iassured || e.nassured ) AS assured,
		e.itag , TRIM(e.aassured_zip || e.aassured) AS aassured ,
		e.iclaim , TRIM(e.adjustment || e.nadjust) AS nadjust , e.dclaim ,
		e.dcontact , e.dverify , e.dsurvey ,
		CASE e.fdmg_duty WHEN '1' THEN '(1) ���F�d,�p��'
						 WHEN '2' THEN '(2) �L�F�d,���p��'
						 WHEN '3' THEN '(3) ���F�d,���p��' END fdmg_duty ,
		e.dgroup , e.fedm , e.dedm , e.iemail ,
		TRIM( e.iroute || r.nroute ) AS route ,	e.msettle_dmg ,
		e.icreate , e.dcreate , e.iupdate , e.dupdate
	INTO $assured , $itag , $aassured , $iclaim , $nadjust , $dclaim , $dcontact , $dverify , $dsurvey ,
		 $fdmg_duty , $dgroup , $fedm , $dedm , $iemail , $route  ,
		 $msettle_dmg , $icreate , $dcreate , $iupdate , $dupdate
	FROM ca_edm e , cm_route r
	WHERE e.iroute = r.iroute
	  AND  e.iclaim = $iclaim
	  AND  e.itag = $itag
	  AND  e.fedm = $fedm ;


    if (SQLCODE == SQLNOTFOUND)
		return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND : apiRC;

    $SELECT nname INTO $ncreate
      FROM  officer
      WHERE iofficer = $icreate;
      if(SQLCODE==SQLNOTFOUND) strcpy(ncreate," ");

    $SELECT nname INTO $nupdate
      FROM  officer
      WHERE iofficer = $iupdate;
      if(SQLCODE==SQLNOTFOUND) strcpy(nupdate," ");

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);


    cm_buf_put("%s %s %s %s %s ", assured , itag , aassured , iclaim , nadjust);
    cm_buf_put("%s %s %s %s %s %s %s %s", dclaim , dcontact , dverify , dsurvey , fdmg_duty , dgroup , fedm , dedm);
	cm_buf_put("%s %s %d", iemail , route  , msettle_dmg );
	cm_buf_put("%s %s %s %s %s %s "   , icreate , ncreate , dcreate , iupdate , nupdate , dupdate);
	strcpy(old_fedm , trim(fedm));

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

  errexit:
     if(exitsub(reply,SQLCODE) == True)
        return SQLCODE;
     else
        return apiRC;
}
/*=======================================================*/
long car1205_multiple_query(reply)
serverReply reply;
{
    $char DBName[5];
	$char stmt[4096];

    char tmpbuf[4000] , sSQL1[1024] ;
    int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int i,total_count=0;

	int demd_bgn_len = 0 , dedm_end_len = 0 , dcreate_bgn_len = 0 , dcreate_end_len = 0;

    cm_buf_get("%s %s %s %s %s %s %s %s %s %s", DBName , iclaim , itag , iroute , fedm , iassured , slt_dedm_bgn , slt_dedm_end , slt_dcreate_bgn , slt_dcreate_end );

	demd_bgn_len = strlen(slt_dedm_bgn);
	dedm_end_len = strlen(slt_dedm_end);

	printf("demd_bgn_len : %s  , dedm_end_len : %s \n" ,demd_bgn_len,dedm_end_len );

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

	if ( demd_bgn_len > 1 && dedm_end_len > 1)
		sprintf_s(sSQL1,1024, "AND date(e.dedm) between '%s' AND '%s'" , slt_dedm_bgn , slt_dedm_end );

	printf("sSQL1:%s\n",sSQL1);


	sprintf_s(stmt,4096,
				  " SELECT TRIM(e.iassured || e.nassured ) AS assured, 						"
				  "	e.itag , TRIM(e.aassured_zip || e.aassured) AS aassured ,				"
				  "	e.iclaim , TRIM(e.adjustment || e.nadjust) AS nadjust , e.dclaim ,		"
				  "	e.dcontact , e.dverify , e.dsurvey , 									"
				  "	CASE e.fdmg_duty WHEN '1' THEN '(1) ���F�d,�p��'						"
				  "					 WHEN '2' THEN '(2) �L�F�d,���p��'						"
				  "					 WHEN '3' THEN '(3) ���F�d,���p��' END fdmg_duty ,		"
				  "	e.dgroup , e.fedm , e.dedm , e.iemail ,									"
				  "	TRIM( e.iroute || r.nroute ) AS route ,	e.iroute ,						"
				  "	e.msettle_dmg , 								"
				  "	e.icreate , e.dcreate , e.iupdate , e.dupdate 							"
				  " FROM ca_edm e , cm_route r "
                  " WHERE e.iclaim MATCHES '%s' "
				  "  AND e.itag MATCHES '%s' "
				  "  AND e.iroute MATCHES '%s' "
				  "  AND e.fedm MATCHES '%s' "
				  "  AND e.iassured MATCHES '%s' "
				  "  %s    "
				  "  AND e.dcreate ::date between '%s' AND '%s' "
				  "  AND r.iroute = e.iroute "
				" ORDER BY e.iclaim , e.itag , e.iroute DESC ", iclaim , itag , iroute , fedm , iassured , sSQL1 , slt_dcreate_bgn , slt_dcreate_end);
    $prepare p_stmt from $stmt;
    $declare q_cur  cursor for p_stmt;
    $OPEN q_cur;
    printf("stmt:%s\n",stmt);
    for(;;)
    {
        $FETCH q_cur INTO $assured , $itag , $aassured , $iclaim , $nadjust , $dclaim , $dcontact , $dverify , $dsurvey ,
						  $fdmg_duty , $dgroup , $fedm , $dedm , $iemail , $route , $iroute ,
						  $msettle_dmg , $icreate , $dcreate , $iupdate , $dupdate   , $ncreate , $nupdate ;

        if (SQLCODE != 0) break;
        cm_buf_init(tmpbuf);
        if ( count == 0 )
        {
            cm_buf_res_msg();             /* reserve for MsgCode and count */
            cm_buf_res_count();
        }

		cm_buf_put("%s %s %s %s %s %s %s ", iclaim , iassured , itag , iroute , fedm , dedm  , dcreate);

		tmp_len = cm_buf_len(tmpbuf);
        if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
        {
            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else                               /* more than 4K, send to client side */
        {
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);
            if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {
                $CLOSE q_cur;
                return apiRC;
            }
            else               /* clear ReplyBuf and count to start all over again */
            {
                replycnt++;
                if (replycnt == 10)   /* more than 30K, client cannot display,error */
                {
                    cm_buf_init(ReplyBuf);
                    cm_buf_put("%l",M_CM_OUT_SPACE);
                    tmp_len = cm_buf_len(ReplyBuf);
                    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                        return apiRC;
                    return M_CM_OUT_SPACE;
                }
                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();           /* reserve for MsgCode and count */
                cm_buf_res_count();
                cm_buf_put("%s %s %s %s %s %s %s ", iclaim , iassured , itag , iroute , fedm , dedm  , dcreate);

                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
            }
        }
    } /* for loop */
    $CLOSE q_cur;
    $FREE q_cur;
    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
            return apiRC;
        return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
        if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
            return M_CM_NOT_FOUND;                               /*?*/
        else
			return apiRC;
    }

 errexit:
   if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
   else
     return apiRC;
}
