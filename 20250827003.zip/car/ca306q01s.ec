/************************************************/
/*   PROGRAM : ca306q01s.ec by Dennis Chang     */
/*   DATE    : 1993/10/04                       */
/*             1998/06/09                       */
/*             2001/07/23                       */
/************************************************/
#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include <malloc.h>
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "print.h"
#include "is_def.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
$include "var_length.h";
#define DATENULL                0x80000000L

$int PgLine;
char OutFile[20];
FILE  *fptr;
/*** Screen Variable ***/
$char  char_dentry0[YYMMDD],char_dentry1[YYMMDD], dentry0[YYYYMMDD],dentry1[YYYYMMDD];
$char  ply_bgn[POLICY_NUM_1],ply_end[POLICY_NUM_1];
$char  sIbranch[BRANCH_ID], ileader[11];

/*** Report Variable ***/
$char  XIpolicy[POLICY_NUM_1];
$char  RIpolicy[POLICY_NUM_1];
$date  Today;
$char  old_iply[2];

/*****************************/
$char DBName[DBNAME];
$char  userid[USER_ID];
char  FormTp[3];
char  TitleFmt[N_FILE+1];
char  outputf[20];
int   max_count=0,iPrintlist=0; /* 2008/04/17�s�W�ǤJ�@�Ѽ�iPrintlist,0���C�L�W�U,1�����L */
$int  ibatch_no;
$char list_print[2];
$int iCountFunsale;

/*** transno ***/
$char   ymd[12], iroute4[13], chb_ply[2];
$static char sTmpIbranch[BRANCH_ID], sTmpIcomp[BRANCH_ID];
$char   sTransno[21], ikind[2], sErrMsg[2048], xIquota[10],sTrans[21], PrintDlist[2], ProtectData[2];
$int    iSeqno;
$char   sTmp1[3600], sTmp2[600];
char s_prog[11], s_subject[101], s_file[101], s_err[101], tmpcmd[150];
FILE *fp;
$char mbuf[9000];
$char Errfile[60],outputf2[30];
char     sApHome[30];
/* ��r�y�� Add in 2006/09/27 by Julia */
char tmpword[3];
int iEplyCnt;/* 1061108001-SC4-�s��*/
static int iFpolicy;
static int iFbig;
$char chkoutprint[2];/*1061012002-SC3 ISID+rba*/
long car306_build();
long ca_rpt_policy();
long ca_rpt_policy_old();
long car306_mailV7();
/*---------------------------------------------------------------------*/
main(argc,argv)
int argc;
char **argv;
{
    int rc, rtncode;
    $int count_print;
		$char errmsg[512],v_sMsg[2048];

    batchinit();
    strcpy(DBName,isNULLstr(argv[1]));
    strcpy(userid,isNULLstr(argv[2]));
    strcpy(char_dentry0,isNULLstr(argv[3]));
    strcpy(char_dentry1,isNULLstr(argv[4]));
    strcpy(sIbranch, isNULLstr(argv[5]));
    strcpy(ileader, isNULLstr(argv[6]));
    strcpy(ply_bgn, isNULLstr(argv[7]));
    strcpy(ply_end, isNULLstr(argv[8]));
    strcpy(ikind,   isNULLstr(argv[9]));
    strcpy(old_iply, isNULLstr(argv[10]));      /* �P�_�O�_���«O��C�L */
    strcpy(list_print,isNULLstr(argv[11]));     /* �P�_�O�_�C�L�W�U */
    strcpy(xIquota,isNULLstr(argv[12]));     		/* �~�Z��� */
    strcpy(PrintDlist,isNULLstr(argv[13]));     /* �O�_�C�LD���ڦW�U:0:���L 1:�C�L */
    strcpy(ProtectData,isNULLstr(argv[14]));    /* �Ӹ�B�n 0:���B�n 1:�B�n */
    strcpy(outputf, isNULLstr(argv[15]));

    /*strcpy(chb_ply,isNULLstr(argv[12]));     		�O�_�C�L���ȫO�� 0:���L���ȫO�� 1:�ȦC�L���ȫO�� */

    $WHENEVER SQLERROR GOTO errexit;
    rc = getApHome(sApHome);
    if (rc<0) {
       strcpy(errmsg,"read Config file error!!-->getApHome\n");
       EWRITE(userid,rc,errmsg);
       return rc;
    }

    strcpy(dentry0, cm_to_infdate(char_dentry0));
    strcpy(dentry1, cm_to_infdate(char_dentry1));
    rtoday(&Today);
    /* �~�� */
    strcpy(ymd,cm_cdate_str(Today));
    /* ������c */
    strncpy(sTmpIbranch, sIbranch, 2);
    sTmpIbranch[2] = '\0';
    /* �����q */
    strncpy(sTmpIcomp, sIbranch+2, 1);
    sTmpIcomp[1] = '\0';

    iPrintlist = atoi(list_print);           /* �O�_�C�L�W�U */

    printf("*****before car306_build() dentry0[%s]dentry1[%s]\n",dentry0,dentry1);
    printf("ply_bgn[%s],ply_end[%s]\n",ply_bgn,ply_end);

    if (sIbranch[0]=='*' || sIbranch[0]==' ' || sIbranch[0]=='\0')
        strcpy(sIbranch, "*");

		if (db_select(DBName) == False)  return M_CM_DB_NOTOPEN;
		/* �إ�temp table ------------------------------------------------------ */
		$create temp table tmp_tb
		(
			ipolicy			char(20),		-- �O�渹
			fprint      char(1),		-- �i�_�C�L�O��
			errmsg			char(255),		-- ���~�T��
			ftype_pol   char(2),		--JC:�F���ۼ�,SP:�S�O�ĳq
			iestimate   char(20)
		) with no log;
		/* --------------------------------------------------------------------- */

	  rc = car306_chkpolicy();
	  if (rc != M_CM_OK)
      {
        printf("car306_chkpolicy[%d][%s]\n", rc, sErrMsg);
        EWRITE(userid, rc, sErrMsg);
        return rc;
      }

	 $select count(ipolicy) into $count_print
	    from tmp_tb
	   where fprint <> 'Y';
	 if (count_print > 0)
	 {
	      sprintf(outputf2,"Car306_%s.txt",outputf);
   	      sprintf(Errfile,"%s/rptftp/%s",sApHome,outputf2);
   	      printf("Errfile=[%s]\n",Errfile);
   	      if ((fptr=fopen(Errfile,"w")) == NULL){
              sprintf(errmsg,"Cannot open print file: %s",Errfile);
              return M_CM_OPEN_FILE_FAIL;
          }
   	  	  strcpy(sErrMsg, "�U�C�O��L�k�C�L(��]�����p�U),�нT�{: \n\n");
   	  	  fprintf(fptr,"%s",sErrMsg);

   	  	  $DECLARE PLY_CUR_B1 CURSOR FOR
   	  	  	select ipolicy, errmsg
   	  	  	  from tmp_tb
   	  	  	 where fprint <> 'Y';
   	  	   $OPEN PLY_CUR_B1;
   	  	  while (1)
       	  {
       	  		$FETCH PLY_CUR_B1 INTO $XIpolicy, $errmsg;
       	  		if (SQLCODE == SQLNOTFOUND) break;

       	  		strcpy(XIpolicy, trim(XIpolicy));
       	  		strcpy(errmsg, trim(errmsg));
       	  		printf("XIpolicy=[%s]errmsg=[%s]\n",XIpolicy,errmsg);
       	  		fprintf(fptr, "�O�� %s:   %s \n",XIpolicy,errmsg);
       	  }
   	  	  $close PLY_CUR_B1;
   	  	  $free PLY_CUR_B1;

   	  	  $INSERT INTO rptftplist (nuserid, ipgid,     noutfile,   dcreate)
                            VALUES ($userid, 'car306',  $outputf2,   current);
           printf("-- bbb--\n");
           fclose(fptr);
	 }

	 /*
	 $select count(ipolicy) into $count_print
	    from tmp_tb
	   where fprint <> 'N';
	 if (count_print == 0)
	 {
	 	 rc = M_CA_NREL_PLY;
         printf("car306_build[�O��w�L�L�Χ䤣�즹�O�渹,�Φܡi�ɮפU���j�d�ݵL�k�C�L��]!]\n");
         EWRITE(userid, rc, "�O��w�L�L�Χ䤣�즹�O�渹,�Φܡi�ɮפU���j�d�ݵL�k�C�L��]!!");
         return rc;
	 }
	 */

    rc=car306_build();
    printf("car306_build[%d]\n",rc);

    if (rc == M_CA_NREL_PLY)
    {
        printf("car306_build[�O��w�L�L�Χ䤣�즹�O�渹,�Φܡi�ɮפU���j�d�ݵL�k�C�L��]!]\n");
        EWRITE(userid, rc, "�O��w�L�L�Χ䤣�즹�O�渹,�Φܡi�ɮפU���j�d�ݵL�k�C�L��]!!");
        rtncode=car306_mailV7();
        return rc;
    }
    else if (rc == M_CA_NLENGTH)
    {
        printf("car306_build[�O�渹��J���~!]\n");
        EWRITE(userid, rc, "�O�渹��J���~!");
        rtncode=car306_mailV7();
        return rc;
    }
    else if (rc == M_CA_TOBE_NO_PRINT)
    {
        printf("car306_build[�C�L���O�欰�M�׷~�ȡA�G�N����ܫO�椺�e���!]\n");
        EWRITE(userid, rc, "�C�L���O�欰�M�׷~�ȡA�G�N����ܫO�椺�e���!");
        rtncode=car306_mailV7();
        return rc;
    }
    else if (rc == M_CA_NESTIMATE) /*�^���@�γ����檬�A����*/
    {
        printf("car306_build[�^���@�γ����檬�A����!]\n");
        EWRITE(userid, rc, "�t�Φ��L���A�еy�ԦA����!");
        rtncode=car306_mailV7();
        return rc;
    }
    else if (rc != M_CM_OK)
    {
        printf("car306_build[%s]\n", sErrMsg);
        EWRITE(userid, rc, sErrMsg);
        rtncode=car306_mailV7();
        return rc;
    }
    rtncode=car306_mailV7();
    printf("*****after car306_build() dentry0[%s]dentry1[%s]\n",dentry0,dentry1);

    if (old_iply[0] == 'A')
    {
printf("�s��\n");      
         if (rc=(save_form_info(F_FREE,"CA",306,userid,FormTp,max_count,outputf))<0)
         EWRITE(userid,rc,"save_form_info failed");
         
    } else {
printf("�ª�\n");
         if (rc=(save_form_info(F_FREE,"CA",3062,userid,FormTp,max_count,outputf))<0)
         EWRITE(userid,rc,"save_form_info failed");
    }
    
    errexit:
    printf("SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;

}
long car306_mailV7()
{
    int rc,rt;
    $char sApHome[31];
    if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
    {
       /* strcpy(outputf, getFileName());*/
        rt = getApHome(sApHome);
        if (rt < 0) {
            printf("read Config file error!!\n");
            return M_CM_READ_CONFIG_ERR;
        }
        printf("outputf[%s]\n", outputf);
        /*sprintf(file0,"%s/rptftp/%s",sApHome,rtrim(noutfile));
        strcpy(s_file, FA_full_ERRDIR());
        sprintf(s_file, "Car306_%s%s.txt", s_file, outputf);*/
        sprintf(s_file, "%s/rptftp/Car306_%s.txt",sApHome, outputf);
        printf("s_file[%s]\n", s_file);

        sprintf(tmpcmd,"rm %s", s_file);
        system(tmpcmd);

        if ((fp=fopen(s_file, "a")) == 0) printf("open file error! Exit Program\n");
        fprintf(fp, "%s\n", mbuf);
        fclose(fp);

        strcpy(s_prog, "CAR306");
        strcpy(s_subject, "V7�O��C�L-�۰ʱƵ{�B�z���G�q��");

        /* �H���Ū�� cu_code_data.itype='DO' */
        rc=FA_send_mail(s_prog, s_subject, s_file, s_err);
        return M_CM_OK;
    }    
    return M_CM_OK;
}
/******************************************************************************/
long car306_build()
{
    int    count=0;
    int    count_no_tobe=0;
    int    rc;
    $char  FormFile[N_FILE+1];
    $char  stmt[400];
    $char  tmp_policy[POLICY_NUM_1];
    $char  sTmpbgn1[POLICY_NUM_1], sTmpend1[POLICY_NUM_1];
    $char  sTmpbgn2[POLICY_NUM_1], sTmpend2[POLICY_NUM_1];
    $date  dDpolicy;
    $date  dDply_close;
    $short no_null;
    $char  nbenef_tmp[43], nbenef[43];
    $char  sTmpiofficer[11], sIresource[2], sIbroker[11], sIquota[11], sIleader[11];
    $char  nequipment14[2];
    $char  nequipment[31];
    $char  itmp_pol_a[21], tmp_transno[21], v_sMsg[512];
    char fbusiness[2], ibroker_top[11], bzfrom[3];
    $long  mcommission;
    $char  sIcomm_obj[11], sIroute_comm[4], sIroute_prop[3], sIroute[21];
    $char fprint[2], serrmsg[512], fstatus[3], sIestimate[21], ftype_pol[3];
    $int  count_pass, count_receive;
    $char sIassured[13],sIapplicant[13];
    $int iCountDeny;
    $char sFeply2[2],sIcomp_in[3],sAemail_eply[51],sDply_end[11],sDply_bgn[11];
    $char sFeply1[2],sIcard1[21],sDpolicy1[11],sIquota1[7],sNassured1[121],sPasswd[13];
    $char sIrelative_ply[21],sIserial[12],date[11],dToday[11],ireceipt[21];
    $char yyyy[5];
    long t;
    $int res;
    $datetime year to second dt_dprint;
    $char e_nfile[36];
    $int fspeed;
    
    $char tmobile_eply[21];

    /* if (db_select(DBName) == False)  return M_CM_DB_NOTOPEN; */

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;
    iEplyCnt = 0 ; 
    iFpolicy = TRUE;   /*�H�O�渹�C�L*/
    iFbig = FALSE;     /*�L�j�O��J�`*/
    count = 0;
    count_no_tobe = 0;

    if (ply_bgn[0]=='*' || ply_bgn[0]==' ' || ply_bgn[0]=='\0')
    {
        iFpolicy = FALSE;
        iFbig = FALSE;
    }

    if (ply_end[0]=='*' || ply_end[0]==' ' || ply_end[0]=='\0')
    {
        iFpolicy = FALSE;
        iFbig = FALSE;
    }

    if (iFpolicy)
    {
        rc = split_policy(ply_bgn, sTmpbgn1, sTmpbgn2);
        if (rc !=  M_CM_OK) return rc;
        rc = split_policy(ply_end, sTmpend1, sTmpend2);
        if (rc !=  M_CM_OK) return rc;

        if (strcmp(sTmpbgn1, sTmpend1) != 0)
        {
            strcpy(ply_bgn, sTmpbgn1);
            strcpy(ply_end, sTmpend1);
            iFbig = FALSE;
        }
        else
        {
            if (strlen(sTmpbgn2) == CAR_TARGET_LEN &&
                strlen(sTmpend2) == CAR_TARGET_LEN)
            {
                if (strcmp(sTmpbgn2, sTmpend2) == 0) iFbig = FALSE;
                else iFbig = TRUE;
            }
            else
            {
                strcpy(ply_bgn, sTmpbgn1);
                strcpy(ply_end, sTmpend1);
                iFbig = FALSE;
            }
        }
        printf("sTmpbgn1------------>[%s]\n",sTmpbgn1);

        if (strlen(ply_bgn) == CAR_PLY_TAG_LEN)
        {

		            $SELECT MAX(ibatch_no)+1
		               INTO $ibatch_no:no_null
		               FROM ply_relation a
		              WHERE ipolicy[1,13]= $sTmpbgn1
		                AND dply_close IS NOT NULL
		                AND ileader matches $ileader
		                AND iquota matches $xIquota;
		            if (SQLCODE == SQLNOTFOUND || no_null==-1) ibatch_no=1;

		            printf("17-->ibatch_no[%d]\n", ibatch_no);
		            printf("17-->SQLCODE[%d]\n", SQLCODE);
		            printf("17-->no_null[%d]\n", no_null);

		            /*�j�O���update�帹*/
		            $UPDATE ply_relation
		                SET ibatch_no = $ibatch_no
		              WHERE fcard_class = '2'
		                AND dply_close is NULL
		                AND dpolicy is NULL
		                AND (ipolicy >= $ply_bgn
		                AND  ipolicy <= $ply_end)
		                AND ileader matches $ileader
		                AND iquota matches $xIquota
		                AND ipolicy in (select ipolicy from tmp_tb where fprint = 'Y');

        }
        else ibatch_no=0;
    }
    else ibatch_no = 0;

    /* �P�_�C�L�s�ª��� */
      if (old_iply[0] == 'A')
      {
				 printf("�s��\n");
         $SELECT kPgNum_Line, nForm_File INTO $PgLine, $FormFile
            FROM Form
           WHERE ksys_grp="CA" AND kPgmID = 306;
       } else
       {
				 printf("�ª�\n");
       	 $SELECT kPgNum_Line, nForm_File INTO $PgLine, $FormFile
            FROM Form
           WHERE ksys_grp="CA" AND kPgmID = 3062;
       }

    strcpy(FormFile,rtrim(FormFile));
    sprintf(OutFile,"%s.tx",outputf);

    /* 104.01.09 �ư��M�ץ� */
		printf("what is file name? [%s]\n",OutFile);
    if (iFpolicy)
    {
        if (iFbig)
        {
            $DECLARE PLY_CUR_1 CURSOR FOR
              SELECT a.ipolicy , a.iofficer , a.iresource , a.dpolicy, a.dply_close, a.ibroker,
                     a.iquota, a.mlia_commi + a.mdmg_commi, a.ileader,
                     a.icomm_obj, a.iroute_comm, b.iroute, b.iroute_prop,
                     c.iestimate,a.irelative_ply,
                     (select iroute_main from cm_route where iroute = b.iroute),
                     c.ftype_pol,b.iassured,b.iapplicant,a.feply,a.icomp_in,a.aemail_eply,a.dply_end,
                     b.iassured,a.tmobile_eply,year(today),a.dply_begin
                FROM ply_relation a, policy b, tmp_tb c
               WHERE a.ipolicy = b.ipolicy
                 AND a.ipolicy = c.ipolicy
                 AND b.ipolicy = c.ipolicy
                 AND c.fprint='Y'
                 AND a.fcard_class='2'
                 AND a.dpolicy is NULL
                 AND a.dply_close is NULL
                 AND a.ileader matches $ileader
                 AND a.iquota matches $xIquota
                 AND (a.ipolicy >= $ply_bgn
                 AND  a.ipolicy <= $ply_end)
                 AND (a.iofficer[1] not in ('W','N') and not (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) ) ;
            printf("-----> into PLY_CUR_1\n");
        }
        else
        {
            $DECLARE PLY_CUR_2 CURSOR FOR
              SELECT a.ipolicy , a.iofficer , a.iresource , a.dpolicy, a.dply_close, a.ibroker,
                     a.iquota, a.mlia_commi + a.mdmg_commi, a.ileader,
                     a.icomm_obj, a.iroute_comm, b.iroute, b.iroute_prop,
                     c.iestimate,a.irelative_ply,
                     (select iroute_main from cm_route where iroute = b.iroute),
                     c.ftype_pol, b.iassured,b.iapplicant,a.feply,a.icomp_in,a.aemail_eply,a.dply_end,
                     b.iassured,a.tmobile_eply,year(today),a.dply_begin
                FROM ply_relation a, policy b, tmp_tb c
               WHERE a.ipolicy = b.ipolicy
                 AND a.ipolicy = c.ipolicy
                 AND b.ipolicy = c.ipolicy
                 AND c.fprint='Y'
                 AND a.fcard_class='2'
                 AND a.dpolicy is NULL
                 AND a.dply_close is NULL
                 AND a.ileader matches $ileader
                 AND a.iquota matches $xIquota
                 AND (a.ipolicy >= $ply_bgn AND a.ipolicy <= $ply_end)
                 AND (a.iofficer[1] not in ('W','N') and not (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) )
               ORDER BY a.ipolicy;
            printf("-----> into PLY_CUR_2\n");
        }
    }
    else
    {   
    	if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
    	{
	    	/*�u�L�D�j�O��*/
	        $DECLARE PLY_CUR_4 CURSOR FOR
	          SELECT a.ipolicy , a.iofficer , a.iresource , a.dpolicy , a.dply_close, a.ibroker,
	                 a.iquota, a.mlia_commi + a.mdmg_commi, a.ileader,
	                 a.icomm_obj, a.iroute_comm, b.iroute, b.iroute_prop,
	                 c.iestimate,a.irelative_ply,
	                 (select iroute_main from cm_route where iroute = b.iroute),
	                 c.ftype_pol,b.iassured,b.iapplicant,a.feply,a.icomp_in,a.aemail_eply,a.dply_end,
	                 b.iassured,a.tmobile_eply,year(today),a.dply_begin
	            FROM ply_relation a, policy b, tmp_tb c
	           WHERE a.ipolicy = b.ipolicy
	             AND a.ipolicy = c.ipolicy
	             AND b.ipolicy = c.ipolicy
	             AND c.fprint='Y'
	             AND a.dentry between $dentry0 and $dentry1
	             AND a.ileader matches $ileader
	             AND a.ipolicy[1,3] MATCHES $sIbranch
	             AND a.ipolicy[6,7] = 'V7'
	             AND a.fcard_class='2'
	             AND a.dpolicy is NULL
	             AND a.dply_close is NULL
	             AND LENGTH(a.ipolicy) = 13
	             AND a.ileader matches $ileader
	             AND a.iquota matches $xIquota
	             AND (a.iofficer[1] not in ('W','N') and not (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) )
	           ORDER BY a.ipolicy;
	        printf("-----> into PLY_CUR_4\n");
    	}
        else
        {
	    	/*�u�L�D�j�O��*/
	        $DECLARE PLY_CUR_3 CURSOR FOR
	          SELECT a.ipolicy , a.iofficer , a.iresource , a.dpolicy , a.dply_close, a.ibroker,
	                 a.iquota, a.mlia_commi + a.mdmg_commi, a.ileader,
	                 a.icomm_obj, a.iroute_comm, b.iroute, b.iroute_prop,
	                 c.iestimate,a.irelative_ply,
	                 (select iroute_main from cm_route where iroute = b.iroute),
	                 c.ftype_pol,b.iassured,b.iapplicant,a.feply,a.icomp_in,a.aemail_eply,a.dply_end,
	                 b.iassured,a.tmobile_eply,year(today),a.dply_begin
	            FROM ply_relation a, policy b, tmp_tb c
	           WHERE a.ipolicy = b.ipolicy
	             AND a.ipolicy = c.ipolicy
	             AND b.ipolicy = c.ipolicy
	             AND c.fprint='Y'
	             AND a.dentry between $dentry0 and $dentry1
	             AND a.ileader matches $ileader
	             AND a.ipolicy[1,3] MATCHES $sIbranch
	             AND a.fcard_class='2'
	             AND a.dpolicy is NULL
	             AND a.dply_close is NULL
	             AND LENGTH(a.ipolicy) = 13
	             AND a.ileader matches $ileader
	             AND a.iquota matches $xIquota
	             AND (a.iofficer[1] not in ('W','N') and not (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) )
	           ORDER BY a.ipolicy;
	        printf("-----> into PLY_CUR_3\n");
    	}
    }

    rgu_init_report(FormFile, OutFile);

    if (iFpolicy)
        if (iFbig) $OPEN PLY_CUR_1; else $OPEN PLY_CUR_2;
    else
    {
    	if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
    		$OPEN PLY_CUR_4;
    	else 
        	$OPEN PLY_CUR_3;
    }

    $BEGIN WORK;

    while (1)
    {
        XIpolicy[0]='\0';
        /*----------------------------------------------------------------*/
        if (iFpolicy)
        {
            if (iFbig)
                 $FETCH PLY_CUR_1 INTO $XIpolicy, $sTmpiofficer , $sIresource , $dDpolicy, $dDply_close,
                                       $sIbroker, $sIquota, $mcommission, $sIleader,
                                       $sIcomm_obj, $sIroute_comm, $sIroute, $sIroute_prop,
                                       $sIestimate, $sIrelative_ply, $iroute4, $ftype_pol, $sIassured, $sIapplicant, $sFeply2,$sIcomp_in,
				       $sAemail_eply,$sDply_end,$sPasswd,$tmobile_eply,$yyyy,$sDply_bgn;
            else
                 $FETCH PLY_CUR_2 INTO $XIpolicy, $sTmpiofficer , $sIresource , $dDpolicy, $dDply_close,
                                       $sIbroker, $sIquota, $mcommission, $sIleader,
                                       $sIcomm_obj, $sIroute_comm, $sIroute, $sIroute_prop,
                                       $sIestimate, $sIrelative_ply, $iroute4, $ftype_pol, $sIassured, $sIapplicant, $sFeply2,$sIcomp_in,
                                       $sAemail_eply,$sDply_end,$sPasswd,$tmobile_eply,$yyyy,$sDply_bgn;
				}
        else
        {
        	if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
        	{
	            $FETCH PLY_CUR_4 INTO $XIpolicy, $sTmpiofficer , $sIresource , $dDpolicy, $dDply_close,
	                                       $sIbroker, $sIquota, $mcommission, $sIleader,
	                                       $sIcomm_obj, $sIroute_comm, $sIroute, $sIroute_prop,
	                                       $sIestimate, $sIrelative_ply, $iroute4, $ftype_pol, $sIassured, $sIapplicant, $sFeply2,$sIcomp_in,
	                                       $sAemail_eply,$sDply_end,$sPasswd,$tmobile_eply,$yyyy,$sDply_bgn;
			}
            else 
            {
	            $FETCH PLY_CUR_3 INTO $XIpolicy, $sTmpiofficer , $sIresource , $dDpolicy, $dDply_close,
	                                       $sIbroker, $sIquota, $mcommission, $sIleader,
	                                       $sIcomm_obj, $sIroute_comm, $sIroute, $sIroute_prop,
	                                       $sIestimate, $sIrelative_ply, $iroute4, $ftype_pol, $sIassured, $sIapplicant, $sFeply2,$sIcomp_in,
	                                       $sAemail_eply,$sDply_end,$sPasswd,$tmobile_eply,$yyyy,$sDply_bgn;
           }
		}
        if (SQLCODE == SQLNOTFOUND) break;

        /* �ˮ֭Ӹ�O�_����ϥ�  add by sylvia 103.02.17 (1020924002_C2)
           ����car306_chkpolicy�ˮ�*/
        strcpy(iroute4, trim(iroute4));
        strcpy(sIroute, trim(sIroute));
        printf("ipolicy=[%s], iroute4[%s]\n",XIpolicy, iroute4);

/*
        if (strcmp(chb_ply, "0") == 0)
        {
        	/* ���L���ȫO��
        	printf("---- ���L���ȫO�� ----- \n");
        	if (strcmp(iroute4,"I009") == 0) continue;
        }
        else
        {
        	/* �ȦL���ȫO��
        	printf("---- �ȦL���ȫO�� ----- \n");
        	if (strcmp(iroute4,"I009") != 0) continue;
        }
*/

        if ((dDpolicy != DATENULL) || (dDply_close != DATENULL)) continue;
	printf("404:XIpolicy=[%s]\n",XIpolicy);
        count++;

        strcpy(sTmpiofficer, trim(sTmpiofficer));

        printf("sTmpIcomp[%s],sTmpIbranch[%s],ymd[%s]\n", sTmpIcomp, sTmpIbranch, ymd);

        /* 104.03.25 ���A��8193����s���A�L��ɤ]���A�L�������s�� */
        /* ----------------------------------------------------------------------
        * b2c9810011 b2c�����b���L�����ͥ���s��(���]���ثe�ȮɵL�k�ѨMitmp_policy�Q����
           �պ⸹��|�Q�\���ҥH�Ȯ��٬O���h�����s��,�Y����s������ƫh�L��������s��,
           �Y���չL��b2c���պ⸹��100%�O�d��itmp_policy,���U�N�L���t�~�P�O����s�� *
        strcpy(itmp_pol_a," ");
        $SELECT itmp_policy, nvl(transno,' '), transno
           INTO $itmp_pol_a, $tmp_transno, $sTransno
           FROM ply_relation
          WHERE ipolicy = $XIpolicy;

        * ���O14�����o§�A���ݲ��ͥ���s�� *
        $SELECT nequipment
           INTO $nequipment
           FROM policy
          WHERE ipolicy = $XIpolicy;

        if( (equip_cmp(nequipment,"14") == TRUE) || (equip_cmp(nequipment,"37") == TRUE) ||
            (strncmp(itmp_pol_a,"17N",3) == 0))
        {
            * �������o§���O *
        }
        else
        {
            printf("����s��===>sTmpIcomp[%s]\n",sTmpIcomp);

            * b2c9810011 ������s���̤����� *
            if (tmp_transno[0] == '\0' || tmp_transno[0] == ' ')
                 rc = cm_get_serial_num("AO", "A1", sTmpIcomp, sTmpIcomp, ymd, sTransno);
            else
            {
                 strcpy(sTransno, tmp_transno);
                 rc = 0;
            }

            printf("sTransno[%s]\n",sTransno);
            printf("4.#################\n");

            if (rc != 0)
            {
                $WHENEVER SQLERROR CONTINUE;
                $ROLLBACK WORK;
                return rc;
            }
            else
            {
                $UPDATE ply_relation
                    SET transno = $sTransno,
                        seqno = '1'
                  WHERE ipolicy = $XIpolicy
                    AND dply_close is NULL
                    AND dpolicy is NULL;
                $SELECT irelative_ply
                   INTO $RIpolicy
                   FROM ply_relation
                  WHERE ipolicy = $XIpolicy;

                $UPDATE ply_relation
                    SET transno = $sTransno,
                        seqno = '2'
                  WHERE ipolicy = $RIpolicy;
            }
        }
        printf("5.#################\n");
         printf("sTransno=[%s]\n",sTransno);
        ------------------------------------------------------------------ */
        strcpy(sTmpiofficer, trim(sTmpiofficer));
        /* �g��N����W99999BE�ɡAW99999IF,W99999IS, �h�𶷻s�@������ */
        if( (strncmp(sTmpiofficer,"W",1)==0) && (strncmp(sTmpiofficer+6,"LE30",4)!=0) )
        {
            /* �E�M�a�x�M�׻ݦL�O�� */
            /* Do not call ca_rpt_policy() */
        }
        else if ( (strncmp(sTmpiofficer,"F9813501",7)==0) || (strncmp(sTmpiofficer,"F9814201",7)==0) )
        {
             /* Do not call ca_rpt_policy() */
        }
        else
        {
            
		if((strcmp(sFeply2,"1") == 0))
        	{

    	            /* 1060328006_C1 �s�W�q�l�O�椽�ΫH�c(�q�ӳ��ϥ�) */
    	            if (strcmp(sIroute,"JB") == 0) strcpy(sIcomp_in , "88");
    	            
    	            /*�P�_�r�y��V7-->�ֳt��*/
    	            fspeed=1;
    	            if (strncmp(XIpolicy+5,"V7",2)==0) fspeed=2;
    	            
    	            
    		        		
        	    /* �q�l�O�椣�ݦL�X�ȥ���ơA�ݱN�O���Ƽg�J�q�l�O������ */
        	    /*�O�o���ɦW*/
        	    strcpy(e_nfile,"");
        	    strcat(e_nfile,"P17CAR_");
        	    strcat(e_nfile,trim(XIpolicy));
        	    strcat(e_nfile,"_");
        	    strcat(e_nfile,trim(yyyy));
        	    strcpy(e_nfile,trim(e_nfile));
        	    
        	    
        	    /*TWCA���ɦW*/
        	    /*
        	    strcpy(e_nfile,trim(XIpolicy));
        	    strcat(e_nfile,"01");
        	    */
        	    
        	    /*�O�o�q�l�O��*/
            	    $INSERT INTO cm_e_policy(iins_cat,ipolicy,iendorse,iserno,ftype,fspeed,iins_kind_ply,iendorse_ti,
            	                             fprocess,fdata,ibranch_code,icustomer,npassword,nemai_send,tsms_mobile,
            	                             nfile,dbgn,dend,fstatus,iapplicant,iassured,ientry,dentry,iupdate,dupdate,
            	                             nplyidx1,nplyidx2,nplyidx3,nedridx1,nedridx2,nedridx3)
				     VALUES ('C',$XIpolicy,' ','01','2',$fspeed,'C2',' ',
				             'A','P',$sIcomp_in,$sIapplicant,$sPasswd,$sAemail_eply,$tmobile_eply,
				             $e_nfile,$sDply_bgn,$sDply_end,100,$sIapplicant,$sIassured,$userid,CURRENT,$userid,CURRENT,
				             ' ',' ',' ',' ',' ',' ');
                    
        	    
        	    /*TWCA�q�l�O��*/
        	    /*
            	    $INSERT INTO cm_e_policy(iins_cat,ipolicy,iendorse,iserno,ibranch_code,icustomer,npassword,nemai_send,tsms_mobile,nfile,dend,fstatus,ientry,dentry,iupdate,dupdate)
				     VALUES ('C',$XIpolicy,' ','01',$sIcomp_in,$sIapplicant,$sPasswd,$sAemail_eply,$tmobile_eply,$e_nfile,$sDply_end,100,$userid,CURRENT,$userid,CURRENT);
                    */
                    
                    iEplyCnt ++;
		    strcpy(sIrelative_ply,trim(sIrelative_ply));
				
		    /* �q�l��O���� */
		    if(strlen(sIrelative_ply) > 0)
		    {
		        $SELECT a.feply,a.icard,nvl(a.dpolicy," "),a.iquota,b.nassured
			   INTO $sFeply1,$sIcard1,$sDpolicy1,$sIquota1,$sNassured1
			   FROM ply_relation a,policy b
			  WHERE a.ipolicy = b.ipolicy
			    AND a.ipolicy = $sIrelative_ply;
					
			if (SQLCODE != SQLNOTFOUND)
			{
			    if(strcmp(sFeply1,"2") == 0)
			    {
			        strcpy(sDpolicy1,trim(sDpolicy1));

				if(strlen(sDpolicy1) == 0)
				{
					$update ply_relation
					    set feply = '0'
					  where ipolicy = $sIrelative_ply;
				}
				/* �ק�ܹq�l�O��{��������
				else
				{
				    t = cm_today();
				    strcpy(date,cm_edate_str(t));
				    strcpy(dToday,cm_from_infdate_100(date));
				    res = cm_get_serial_num_dwritten("C1","T","00","0","",dToday,ireceipt);
							
			            printf("res=%d\n",res);
			            printf("ireceipt=%s\n",ireceipt);

			            if (res != 0) return res;

			            strncpy(sIserial,XIpolicy,3);
			            sIserial[3] = '\0';
			            strcat(sIserial,ireceipt);
			          			
			            printf("sIserial=[%s]\n",sIserial);
			          			
			            $SELECT dprint Into $dt_dprint 
                       		       From cm_pre_receive
                      		      Where ipre_rcv = $sIestimate 
                      			and iins_kind ='1'
                      			and ipre_end = ' ' 
                      			and dprint is not null;

				    $INSERT INTO ca_card_proof
				     VALUES ($sIserial,$sIrelative_ply,$sIcard1,$dt_dprint,$sIquota1,$sNassured1,$userid,current);
				}*/
			    }
			}
		    }
                }
                else
                {
                    /* 1061012002-SC3 ISID+rba�j���I�G�����X��@�~���L��� ���N�I ���ܦL��@�~���L���*/
                    chkoutprint[0] = '\0';
                    $select fout_print into $chkoutprint
                       from ply_relation
                      where ipolicy = $XIpolicy;
                    if(chkoutprint[0] !='1')/* 1061012002-SC3 ISID+rba�j���I�G�����X��@�~���L��� ���N�I ���ܦL��@�~���L���*/
                    {
                        /* �D�q�l�O��ݦL�X�ȥ���� */
                        if (old_iply[0] == 'A')
                            rc=ca_rpt_policy(XIpolicy, "", ibatch_no, ikind, iFbig, iPrintlist, "a", ply_end, userid, PrintDlist, ProtectData, DBName, "0" ,"","","","0");
                        else
                            rc=ca_rpt_policy_old(XIpolicy, "", ibatch_no, ikind, iFbig);
        
                        if (rc != M_CM_OK)
                        {
                            strcpy(v_sMsg, cm_get_errmsg(rc));
                            sprintf( sErrMsg, "�O�渹[%s], %s", XIpolicy, v_sMsg);
                            $ROLLBACK WORK;
                            return rc;
                        }
                    }
		}
		count_no_tobe ++;
        }

        $UPDATE ply_relation
            SET fprint = "1",
                dpolicy = $Today
          WHERE fcard_class = '2'
            AND dply_close is NULL
            AND dpolicy is NULL
            AND ipolicy = $XIpolicy;

        /* �^���@�γ������� ---------------------------------------------- */
        /*  1031111001_C1 ���O�X������{���վ� (Upd_Cm_pre_receive() �b caxxxlib.ec) */
    	rc = Upd_Cm_pre_receive(sIestimate, XIpolicy, sIassured);
     	if (rc != SUCCESS)
     	{
     		$ROLLBACK WORK;
        	return rc;

        }
        /* => ��I�s Upd_Cm_pre_receive()
        $select count(ipre_rcv) into $count_pass
           from ao_prercv_pass
          where iins_cat = 'C'
            and ipre_rcv = $sIestimate
            and iins_kind = '2' ;
        $select count(ipre_rcv) into $count_receive
           from cm_pre_receive
          where iins_cat = 'C'
            and ipre_rcv = $sIestimate
            and iins_kind = '2' ;

				printf("519:sIestimate=[%s]count_receive[%d]count_receive=[%d]\n",sIestimate, count_receive,count_receive);
				 printf("sTransno=[%s]\n",sTransno);
        if (count_receive > 0)
        {
        	if (count_pass > 0)
        			strcpy(fstatus, "60"); * �w�X��,�w���O *
        	else
        			strcpy(fstatus, "30"); * �w�X��,�����O *

        	if ((strcmp(ftype_pol,"JC") == 0) || (strcmp(ftype_pol, "SP") == 0))
        	{
        		 printf("----- JC or SP ftype_pol=[%s]--------- \n",ftype_pol);
        		 $update cm_pre_receive
        		    set dprint = current,
        		        fstatus = $fstatus,
        		        ftype_pol = $ftype_pol,
        		        paydate = ''
        		  where iins_cat = 'C'
                and ipre_rcv = $sIestimate
                and iins_kind = '2';
        	}
        	else
        	{
        		printf("----- �@�� --------- \n");
        		$update cm_pre_receive
        		    set dprint = current,
        		        fstatus = $fstatus
        		  where iins_cat = 'C'
                and ipre_rcv = $sIestimate
                and iins_kind = '2';
        	}
        }

        * �W��ú�ڥ�,�]���������渹,�G�H����s������O�J�p�������渹,
           �Y���A=50�h�^�����A=90(�@�o),�Y����L���A���i�^���C
            add by sylvia 102.08.09 *
        printf("sTransno=[%s][%d]\n",sTransno,count_receive+count_pass);
        if (((count_receive+count_pass) > 0) && (strncmp(sTransno,"9100",4) == 0))
        {
        		$update cm_pre_receive
        		    set dupdate = current,
        		        fstatus = '90',
        		        iupdate = 'car301'
        		  where iins_cat = 'C'
        		    and fstatus = '50'
        		    and iins_kind = '2'
                and ipre_rcv in
                (select ipre_rcv from ao_rcv_type
                    where insure_type = 'C' and trcv = $sTransno
                      and iins_kind = '2' and trim(ipolicy1) = ''
                      and trim(ipolicy2) = '' and trim(iendorse) = '');
        }
        */
			/* ----------------------------------------------------------------- */
        $SELECT nbenef
           INTO $nbenef_tmp
           FROM policy
          WHERE ipolicy = $XIpolicy;

        printf("the nbenef_tmp ==> [%s]\n",nbenef_tmp);

        /* ������v�H, �n�A���L�@���O�� */
        if ((strcmp(trim(nbenef_tmp),"") == 0) ||(strcmp(trim(nbenef_tmp),'\0') == 0))
        {
            printf("the nbenef is not exist !!!\n");
        }
        else
        {
            printf("the nbenef is exist !!!\n");
            strcpy(sTmpiofficer, trim(sTmpiofficer));

            if( (strncmp(sTmpiofficer,"W",1)==0) && (strncmp(sTmpiofficer+6,"LE30",4)!=0) )
            {
                    /* Do not call ca_rpt_policy() */
                    /* �E�M�a�x�M�׻ݦL�O�� */
            }
            else if ( (strncmp(sTmpiofficer,"F9813501",7)==0) || (strncmp(sTmpiofficer,"F9814201",7)==0) )
            {
                    /* Do not call ca_rpt_policy() */
            }
            else
            {
                /* 1061012002-SC3 ISID+rba�j���I�G�����X��@�~���L��� ���N�I ���ܦL��@�~���L���*/
                chkoutprint[0] = '\0';
                $select fout_print into $chkoutprint
                   from ply_relation
                  where ipolicy = $XIpolicy;                
                /* 1061012002-SC3 ISID+rba�j���I�G�����X��@�~���L��� ���N�I ���ܦL��@�~���L���*/
				if((strcmp(sFeply2,"1") != 0) && (strcmp(chkoutprint,"1") != 0))
        		{
	            	 if (old_iply[0] == 'A')
	                    rc=ca_rpt_policy(XIpolicy, "", ibatch_no, ikind, iFbig, iPrintlist, "a", ply_end,userid,PrintDlist,ProtectData,DBName,"0" ,"","","","0");
	                 else
	                    rc=ca_rpt_policy_old(XIpolicy, "", ibatch_no, ikind, iFbig);
	
	                 if (rc != M_CM_OK)
	                 {
	                 	  $ROLLBACK WORK;
	                 	  return rc;
	                 }
				}
            }
        }

        if (iFpolicy && iFbig) break;
    }

    printf("------>iFpolicy [%d]\n", iFpolicy);
    printf("------>iFbig [%d]\n", iFbig);

    if (iFpolicy)
        if (iFbig)
             $CLOSE PLY_CUR_1;
        else
             $CLOSE PLY_CUR_2;
    else
    {
    	if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
    		$CLOSE PLY_CUR_4;
    	else 
        	$CLOSE PLY_CUR_3;
    }

    if (iFpolicy)
        if (iFbig) $FREE PLY_CUR_1; else $FREE PLY_CUR_2;
    else
    {
    	if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
    		$FREE PLY_CUR_4;
    	else 
    		$FREE PLY_CUR_3;
    }

    if (count == 0)
    {
        $ROLLBACK WORK;
        return M_CA_NREL_PLY;
    }
    printf("count_no_tobe[%d],count[%d]\n",count_no_tobe, count);
    /* �C�L�h�i�O��������ζ�TOBE�M�׮ɡA�h��ܤ��o�C�L�O�椺�e���T�� */
    if ((count_no_tobe == 0) && (count != 0))
    {
        printf("1\n");
        $COMMIT WORK;
        return M_CA_TOBE_NO_PRINT;
    }

    /* �C�L�@�i�O��B���M�׷~�ȮɡA�h��ܤ��o�C�L�O�椺�e���T��
    if ((count == 1) && (strncmp(sTmpiofficer,"W",1)==0))
    {
            printf("2\n");
            $COMMIT WORK;
            return M_CA_TOBE_NO_PRINT;
    } */

    /* �C�L�@�i�O��B���M�׷~��(H�g��)�ɡA�h��ܤ��o�C�L�O�椺�e���T��
       add by sylvia 103.01.07 (1021122001_C1)
    if ((count == 1) && ((strncmp(sTmpiofficer,"H",1)==0) &&
    	(strncmp(sTmpiofficer,"H0",2)!=0) && (strncmp(sTmpiofficer,"H1",2)!=0) &&
    	(strncmp(sTmpiofficer,"H2",2)!=0)))
    {
            printf("3 (H�g��) \n");
            $COMMIT WORK;
            return M_CA_TOBE_NO_PRINT;
    }*/

    /* �C�L�@�i�O��B���M�׷~��(N�g��)�ɡA�h��ܤ��o�C�L�O�椺�e���T�� (1030630002_C4)
    strcpy(sIresource, trim(sIresource));
    if ((count == 1) && ((strncmp(sTmpiofficer,"N",1)==0) &&
    	(strncmp(sIresource,"E",1)==0)))
    {
            printf("4 (N�g��) \n");
            $COMMIT WORK;
            return M_CA_TOBE_NO_PRINT;
    }*/

    rgu_finish_report();


    printf( "iFpolicy[%d]\n", iFpolicy);
    if (iFpolicy)
    {
        printf("strlen(ply_bgn)[%d] , CAR_PLY_TAG_LEN[%d]\n", strlen(ply_bgn) , CAR_PLY_TAG_LEN);
        if (strlen(ply_bgn) == CAR_PLY_TAG_LEN)
        {
        		printf("------------- 639 ----------------------- \n");
            puts("�j�O��");

		            $UPDATE ply_relation
		                SET fprint = "1", dpolicy = $Today
		              WHERE fcard_class = '2'
		                AND dply_close is NULL
		                AND dpolicy is NULL
		                AND (ipolicy >= $ply_bgn
		                AND  ipolicy <= $ply_end)
		                AND ileader matches $ileader
		                AND iquota matches $xIquota
		                AND ipolicy in (select ipolicy from tmp_tb where fprint = 'Y')
		                AND (iofficer[1] not in ('W','N') and not (iofficer[1] = 'H' and iofficer[2] not in ('0','1','2')) );

        }
        else
        {
        		printf("------------- 651 ----------------------- \n");

	            $UPDATE ply_relation
	                SET fprint = "1", dpolicy = $Today
	              WHERE fcard_class = '2'
	                AND dply_close is NULL
	                AND dpolicy is NULL
	                AND LENGTH(ipolicy) = 13
	                AND (ipolicy >= $ply_bgn
	                AND  ipolicy <= $ply_end)
	                AND ileader matches $ileader
	                AND iquota matches $xIquota
	                AND ipolicy in (select ipolicy from tmp_tb where fprint = 'Y')
	                AND (iofficer[1] not in ('W','N') and not (iofficer[1] = 'H' and iofficer[2] not in ('0','1','2')) );

		}
    }
    else
    {
    		printf("------------- 664 ----------------------- \n");

	        $UPDATE ply_relation
	            SET fprint = "1", dpolicy = $Today
	          WHERE dentry between $dentry0 and $dentry1
	            AND ipolicy[1,3] MATCHES $sIbranch
	            AND fcard_class='2'
	            AND dply_close is NULL
	            AND dpolicy is NULL
	            AND LENGTH(ipolicy) = 13
	            AND ileader matches $ileader
	            AND iquota matches $xIquota
	            AND ipolicy in (select ipolicy from tmp_tb where fprint = 'Y')
	            AND (iofficer[1] not in ('W','N') and not (iofficer[1] = 'H' and iofficer[2] not in ('0','1','2')) );

    }
    $COMMIT WORK;
    return M_CM_OK;

errexit:
    printf("SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car306_chkpolicy()
{
    int    count=0;
    int    count_no_tobe=0;
    int    rc;
    $char  FormFile[N_FILE+1];
    $char  stmt[400];
    $char  tmp_policy[POLICY_NUM_1];
    $char  sTmpbgn1[POLICY_NUM_1], sTmpend1[POLICY_NUM_1];
    $char  sTmpbgn2[POLICY_NUM_1], sTmpend2[POLICY_NUM_1];
    $date  dDpolicy;
    $date  dDply_close;
    $short no_null;
    $char  nbenef_tmp[43], nbenef[43];
    $char  sTmpiofficer[11], sIbroker[11], sIquota[11], sIleader[11];
    $char  nequipment14[2];
    $char  nequipment[31];
    $char  itmp_pol_a[21], tmp_transno[21], v_sMsg[512];
    char fbusiness[2], ibroker_top[11], bzfrom[3];
    $long  mcommission;
    $char  sIcomm_obj[11], sIroute_comm[4], sIroute_prop[3], sIroute[21];
    /* ���O�X�� */
    $char	sIestimate[21], sAbn_type[2], sImgr[2];
    $char sIpolicy1[21], sIpolicy2[21], dply_begin[11], iins_kind[2];
    $char deffect4[11];
    $int  iCountJC, iCountEW, ifuw_status, iCountSP;
    $double mprem,mnt1;
    $int  iCntSP1, iCntSP2, iCntSP3, iCntSP4, iCntSP5, iCountDeny ;
    $char sIassured[13];
    $char sPassPrint[2] = " " , ChkPlyType[3] = " " ;
    $int  ichk_status;
    $char ipass_policy[POLICY_NUM_1];
    
    /* --------------------------------------------------------------------- */

    /* if (db_select(DBName) == False)  return M_CM_DB_NOTOPEN; */

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    iFpolicy = TRUE;   /*�H�O�渹�C�L*/
    iFbig = FALSE;     /*�L�j�O��J�`*/
    count = 0;
    count_no_tobe = 0;
    iCountSP = iCntSP1 = iCntSP2 = iCntSP3 = iCntSP4 = iCntSP5 = 0;
    sTmp1[0]= '\0';
    sTmp2[0]= '\0';

    if (ply_bgn[0]=='*' || ply_bgn[0]==' ' || ply_bgn[0]=='\0')
    {
        iFpolicy = FALSE;
        iFbig = FALSE;
    }

    if (ply_end[0]=='*' || ply_end[0]==' ' || ply_end[0]=='\0')
    {
        iFpolicy = FALSE;
        iFbig = FALSE;
    }

    if (iFpolicy)
    {
        rc = split_policy(ply_bgn, sTmpbgn1, sTmpbgn2);
        if (rc !=  M_CM_OK) return rc;
        rc = split_policy(ply_end, sTmpend1, sTmpend2);
        if (rc !=  M_CM_OK) return rc;

        if (strcmp(sTmpbgn1, sTmpend1) != 0)
        {
            strcpy(ply_bgn, sTmpbgn1);
            strcpy(ply_end, sTmpend1);
            iFbig = FALSE;
        }
        else
        {
            if (strlen(sTmpbgn2) == CAR_TARGET_LEN &&
                strlen(sTmpend2) == CAR_TARGET_LEN)
            {
                if (strcmp(sTmpbgn2, sTmpend2) == 0) iFbig = FALSE;
                else iFbig = TRUE;
            }
            else
            {
                strcpy(ply_bgn, sTmpbgn1);
                strcpy(ply_end, sTmpend1);
                iFbig = FALSE;
            }
        }
        printf("sTmpbgn1------------>[%s]\n",sTmpbgn1);
        if (strlen(ply_bgn) == CAR_PLY_TAG_LEN)
        {

	            $SELECT MAX(ibatch_no)+1
	               INTO $ibatch_no:no_null
	               FROM ply_relation a
	              WHERE ipolicy[1,13]= $sTmpbgn1
	                AND dply_close IS NOT NULL
	                AND ileader matches $ileader
	                AND iquota matches $xIquota;
	            if (SQLCODE == SQLNOTFOUND || no_null==-1) ibatch_no=1;

        }
        else ibatch_no=0;
    }
    else ibatch_no = 0;

    if (iFpolicy)
    {
        if (iFbig)
        {
            $DECLARE PLY_CUR_A1 CURSOR FOR
              SELECT a.ipolicy , a.iofficer , a.dpolicy, a.dply_close, a.ibroker,
                     a.iquota, a.mlia_commi + a.mdmg_commi, a.ileader,
                     a.icomm_obj, a.iroute_comm, b.iroute, b.iroute_prop,
                     (select iroute_main from cm_route where iroute = b.iroute),
                     b.iassured
                FROM ply_relation a, policy b
               WHERE a.ipolicy = b.ipolicy
                 AND a.fcard_class='2'
                 AND a.dpolicy is NULL
                 AND a.dply_close is NULL
                 AND a.ileader matches $ileader
                 AND a.iquota matches $xIquota
                 AND (a.ipolicy >= $ply_bgn
                 AND  a.ipolicy <= $ply_end);
            printf("-----> into PLY_CUR_1\n");
        }
        else
        {
            $DECLARE PLY_CUR_A2 CURSOR FOR
              SELECT a.ipolicy , a.iofficer , a.dpolicy, a.dply_close, a.ibroker,
                     a.iquota, a.mlia_commi + a.mdmg_commi, a.ileader,
                     a.icomm_obj, a.iroute_comm, b.iroute, b.iroute_prop,
                     (select iroute_main from cm_route where iroute = b.iroute),
                     b.iassured
                FROM ply_relation a, policy b
               WHERE a.ipolicy = b.ipolicy
                 AND a.fcard_class='2'
                 AND a.dpolicy is NULL
                 AND a.dply_close is NULL
                 AND a.ileader matches $ileader
                 AND a.iquota matches $xIquota
                 AND (a.ipolicy >= $ply_bgn AND a.ipolicy <= $ply_end)
               ORDER BY a.ipolicy;
            printf("-----> into PLY_CUR_2\n");
        }
    }
    else
    {   
    	if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
    	{
	        $DECLARE PLY_CUR_A4 CURSOR FOR
	          SELECT a.ipolicy , a.iofficer , a.dpolicy , a.dply_close, a.ibroker,
	                 a.iquota, a.mlia_commi + a.mdmg_commi, a.ileader,
	                 a.icomm_obj, a.iroute_comm, b.iroute, b.iroute_prop,
	                 (select iroute_main from cm_route where iroute = b.iroute),
	                 b.iassured
	            FROM ply_relation a, policy b
	           WHERE a.ipolicy = b.ipolicy
	             AND a.dentry between $dentry0 and $dentry1
	             AND a.ileader matches $ileader
	             AND a.iquota matches $xIquota
	             AND a.ipolicy[1,3] MATCHES $sIbranch
	             AND a.ipolicy[6,7] = 'V7'
	             AND a.fcard_class='2'
	             AND a.dpolicy is NULL
	             AND a.dply_close is NULL
	             AND LENGTH(a.ipolicy) = 13
	           ORDER BY a.ipolicy;
	        printf("-----> into PLY_CUR_A4\n");
    	}
    	else 
    	{
	    	/*�u�L�D�j�O��*/
	        $DECLARE PLY_CUR_A3 CURSOR FOR
	          SELECT a.ipolicy , a.iofficer , a.dpolicy , a.dply_close, a.ibroker,
	                 a.iquota, a.mlia_commi + a.mdmg_commi, a.ileader,
	                 a.icomm_obj, a.iroute_comm, b.iroute, b.iroute_prop,
	                 (select iroute_main from cm_route where iroute = b.iroute),
	                 b.iassured
	            FROM ply_relation a, policy b
	           WHERE a.ipolicy = b.ipolicy
	             AND a.dentry between $dentry0 and $dentry1
	             AND a.ileader matches $ileader
	             AND a.iquota matches $xIquota
	             AND a.ipolicy[1,3] MATCHES $sIbranch
	             AND a.fcard_class='2'
	             AND a.dpolicy is NULL
	             AND a.dply_close is NULL
	             AND LENGTH(a.ipolicy) = 13
	           ORDER BY a.ipolicy;
	        printf("-----> into PLY_CUR_3\n");
		}
    }

    if (iFpolicy)
        if (iFbig) $OPEN PLY_CUR_A1; else $OPEN PLY_CUR_A2;
    else
    {
    	if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
    		$OPEN PLY_CUR_A4;
    	else 
        	$OPEN PLY_CUR_A3;
    }

    while (1)
    {
        XIpolicy[0]='\0';
        /*----------------------------------------------------------------*/
        if (iFpolicy)
            if (iFbig)
                 $FETCH PLY_CUR_A1 INTO $XIpolicy, $sTmpiofficer , $dDpolicy, $dDply_close,
                                       $sIbroker, $sIquota, $mcommission, $sIleader,
                                       $sIcomm_obj, $sIroute_comm, $sIroute, $sIroute_prop, $iroute4,
                                       $sIassured;
            else
                 $FETCH PLY_CUR_A2 INTO $XIpolicy, $sTmpiofficer , $dDpolicy, $dDply_close,
                                       $sIbroker, $sIquota, $mcommission, $sIleader,
                                       $sIcomm_obj, $sIroute_comm, $sIroute, $sIroute_prop, $iroute4,
                                       $sIassured;
        else
        	if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
        		$FETCH PLY_CUR_A4 INTO $XIpolicy, $sTmpiofficer , $dDpolicy, $dDply_close,
	                                       $sIbroker, $sIquota, $mcommission, $sIleader,
	                                       $sIcomm_obj, $sIroute_comm, $sIroute, $sIroute_prop, $iroute4,
	                                       $sIassured;
        	else
	            $FETCH PLY_CUR_A3 INTO $XIpolicy, $sTmpiofficer , $dDpolicy, $dDply_close,
	                                       $sIbroker, $sIquota, $mcommission, $sIleader,
	                                       $sIcomm_obj, $sIroute_comm, $sIroute, $sIroute_prop, $iroute4,
	                                       $sIassured;

        if (SQLCODE == SQLNOTFOUND) break;

        strcpy(iroute4, trim(iroute4));
        printf("ipolicy=[%s], iroute4[%s]\n",XIpolicy, iroute4);
        strcpy(ipass_policy,trim(XIpolicy));

        /*
        if (strcmp(chb_ply, "0") == 0)
        {
        	/* ���L���ȫO��

        	if (strcmp(iroute4,"I009") == 0) continue;
        		printf("---- �D���ȫO�� ----- \n");
        }
        else
        {
        	/* �ȦL���ȫO��

        	if (strcmp(iroute4,"I009") != 0) continue;
        		printf("---- ���ȫO�� ----- \n");
        }
        */

        if ((dDpolicy != DATENULL) || (dDply_close != DATENULL)) continue;

	if( sTmpiofficer[0] != 'W')
	{
	      	if (strcmp(ipass_policy,"22507V9010855")==0 || strcmp(ipass_policy,"22507V9010856")==0 || strcmp(ipass_policy,"22507V9010857")==0 || strcmp(ipass_policy,"22507V9010858")==0)
	        {
	            printf("--1070807012_SC1_���N�I�O��w���O���]�޲z�H��¾�L�k�L����D�B�z \n");
	        }
	        else
	        {
		    /* �t�X�q���ĤG���q, ��H�@��function�ˮ� */
		    rc = cm_chk_policy("1", sTmpiofficer, " ", " ", " ", " ", " ", " ");
		    if( rc != M_CM_OK)
		    {
		        strcpy(v_sMsg, trim(cm_get_errmsg(rc)));
		        /* �g�Jtemp table,���O����C�L,�ø���U�@�� */
		        $insert into tmp_tb (ipolicy,  fprint, errmsg)
		         values            ($XIpolicy,   'N', $v_sMsg);
		        continue;
		    }
	        }
	}

        /* �t�X�q���ĤG���q, ��H�@��function�ˮ� */
        rc = cm_chk_policy("2", " ", " ", sIquota, " ", " ", " ", " ");
        if( rc != M_CM_OK)
        {
            strcpy(v_sMsg, trim(cm_get_errmsg(rc)));
	          /* �g�Jtemp table,���O����C�L,�ø���U�@�� */
		$insert into tmp_tb (ipolicy,  fprint, errmsg)
	           values            ($XIpolicy,   'N', $v_sMsg);
	          continue;
        }

        /* �I����H�O�_����X�� */
        if (strcmp(ipass_policy,"22507V9010855")==0 || strcmp(ipass_policy,"22507V9010856")==0 || strcmp(ipass_policy,"22507V9010857")==0 || strcmp(ipass_policy,"22507V9010858")==0)
        {
            printf("--1070807012_SC1_���N�I�O��w���O���]�޲z�H��¾�L�k�L����D�B�z \n");
        }
        else
        {
	    rc = cm_chk_policy("4", " ", " ", " ", sIcomm_obj, " ", " ", " ");
	    if( rc != M_CM_OK)
	    {
	        strcpy(v_sMsg, trim(cm_get_errmsg(rc)));
		/* �g�Jtemp table,���O����C�L,�ø���U�@�� */
		$insert into tmp_tb (ipolicy,  fprint, errmsg)
		  values            ($XIpolicy,   'N', $v_sMsg);
		continue;
	    }
	}
		
	if (strcmp(ipass_policy,"22507V9010855")==0 || strcmp(ipass_policy,"22507V9010856")==0 || strcmp(ipass_policy,"22507V9010857")==0 || strcmp(ipass_policy,"22507V9010858")==0)
        {
            printf("--1070807012_SC1_���N�I�O��w���O���]�޲z�H��¾�L�k�L����D�B�z \n");
        }
        else
        {
	    /* �I����H���L�X���� */
	    rc = cm_chk_policy("6", " ", " ", " ", sIcomm_obj, "C", " ", " ");
	    if( rc != M_CM_OK)
	    {
	        strcpy(v_sMsg, trim(cm_get_errmsg(rc)));
		/* �g�Jtemp table,���O����C�L,�ø���U�@�� */
		$insert into tmp_tb (ipolicy,  fprint, errmsg)
		  values            ($XIpolicy,   'N', $v_sMsg);
		continue;
	    }
	}
		
        /* �I����H��10000,������ add by sylvia 100.06.22 */
        if((strcmp(trim(sIcomm_obj),"10000") == 0)  && (mcommission > 0))
        {
            strcpy(v_sMsg, trim(cm_get_errmsg(rc)));
	    /* �g�Jtemp table,���O����C�L,�ø���U�@�� */
	    $insert into tmp_tb (ipolicy,  fprint, errmsg)
	      values            ($XIpolicy,   'N', $v_sMsg);
	    continue;
        }

        /* �q���N���P�q���ۭq�~�ȥN���������Y�O�_���T add by sylvia 100.06.22 */
        rc = cm_chk_policy("7", " ", " ", " ", " ", " ", sIroute, sIroute_prop);
        if( rc != M_CM_OK)
        {
            strcpy(v_sMsg, trim(cm_get_errmsg(rc)));
	    /* �g�Jtemp table,���O����C�L,�ø���U�@�� */
	    $insert into tmp_tb (ipolicy,  fprint, errmsg)
	      values            ($XIpolicy,   'N', $v_sMsg);
	    continue;
        }
        
        /*�ˮ֬O�_�f�ֳq�L�Afsign_status>=30 ---------------------------------*/
        /*1091021005_SC5_�s�W�A�Ȥ��ߩ�����*/
        ichk_status=0;
        $SELECT count(*) INTO $ichk_status FROM ply_relation WHERE ipolicy = $XIpolicy AND fsign_status>=30;
        
        if  (ichk_status == 0)
        {
            sprintf( v_sMsg, "�O�渹[%s]���i�L��A�]���`�����q�|���f�֩��", XIpolicy);
            /* �g�Jtemp table,���O����C�L,�ø���U�@�� */
            $insert into tmp_tb (ipolicy,  fprint, errmsg)
	      values            ($XIpolicy,   'N', $v_sMsg);
	    continue;
        }
        
        /*--------------------------------------------------------------------*/
        
        /* �ˮ֭Ӹ�O�_����ϥ�  add by sylvia 103.02.17 (1020924002_C2) */
        iCountDeny=0;
        iCountFunsale=0;
        $select count(*) into $iCountDeny
           from cm_personal_deny
          where iassured = $sIassured
            and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
            and ddeny <= today
            and (dexpire is null or dexpire >= today);

        if  (iCountDeny > 0)
        {
            sprintf( v_sMsg, "�O�渹[%s]�Ӹ갱��ϥ�", XIpolicy);
            /* �g�Jtemp table,���O����C�L,�ø���U�@�� */
            $insert into tmp_tb (ipolicy,  fprint, errmsg)
	      values            ($XIpolicy,   'N', $v_sMsg);
	    continue;
        }
     
        /* �ˮ֭Ӹ�O�_����ϥ�(end)  ---------------------------------------- */

        /* �ˮ֬O�_�e�~�C�L  add by sylvia 103.03.13 (1010523004_C3)  */
        /* 1061012002-SC3 ISID+rba�j���I�G�����X��@�~���L��� ���N�I ���ܦL��@�~���L���*/
        chkoutprint[0] = '\0';
        $select fout_print,itmp_policy into $chkoutprint,$sIestimate
           from ply_relation
          where ipolicy = $XIpolicy;
        /*
         if (strcmp(chkoutprint,"0") != 0)
         {
             sprintf( v_sMsg, "�O�渹[%s]�w���O�e�~�C�L", XIpolicy);
             * �g�Jtemp table,���O����C�L,�ø���U�@�� *
             $insert into tmp_tb (ipolicy,  fprint, errmsg)
	           values            ($XIpolicy,   'N', $v_sMsg);
	          continue;
         }
        * �ˮ֬O�_�e�~�C�L(end)  ---------------------------------------- */

         
        /*  1031111001_C1 ���O�X������{���վ�  */
        #if _CA_VERSION == 1
            printf("-- trace _CA_VERSION = 1\n ");
            
            

         /*  1041013003_C1_car320.car301.car401��������(F)��J�ި�             */ 
         strcpy(sPassPrint,"N");
	 rc = check_ca_id_officer(XIpolicy," ",sPassPrint,v_sMsg);
	 if( rc != M_CM_OK || sPassPrint[0]=='N' ){
	     /* �g�Jtemp table,���O����C�L,�ø���U�@�� */
	     strcpy(v_sMsg, trim(cm_get_errmsg(rc)));
	     printf("-- trace v_sMsg[%s]\n ",v_sMsg);	             
	     $insert into tmp_tb (ipolicy,  fprint, errmsg)
               values            ($XIpolicy,   'N', $v_sMsg);
	     continue;
	 }	
	 strcpy(sPassPrint,"N"); strcpy(ChkPlyType," ");
	 rc = chk_policy_print(XIpolicy,sPassPrint,ChkPlyType,v_sMsg);
	 if( rc != M_CM_OK || sPassPrint[0]!='Y' ){
	     /* �g�Jtemp table,���O����C�L,�ø���U�@�� */
	     printf("-- trace v_sMsg[%s]\n ",v_sMsg);
	     $insert into tmp_tb (ipolicy,  fprint, errmsg)
	       values            ($XIpolicy,   'N', $v_sMsg);
	     continue;
	 }	    	    

	 #else
	     printf("-- trace _CA_VERSION <> 1\n ");
	     $select a.itmp_policy, b.iabn_type, c.imgr,
	             case when b.iroute[1,2] = 'JC' then
	             (select count(detail) from car_code where kind = '26'
	                        and detail = b.iassured) else 0 end ,
	             a.ipolicy[1,13],
	             case when a.ipolicy[6,7] = 'VW' then 1 else 0 end,
	             case when length(trim(a.ipolicy)) > 13 then
	                      a.ipolicy[14,17] else ' ' end,
	             case when trim(b.iabn_type) <> '' then
	                      nvl((select fuw_status from newa00:abnormal_ply
	                      	    where iabnormal = a.itmp_policy),-100)
	                      else nvl((select fuw_status from estimate
	                      	         where iestimate = a.itmp_policy),-100) end,
	             (select count(icode) from ca_permit where iclass = '01'
	               		  and (dexpire is null or dexpire > today)
	               		  and trim(icode) <> '' and icode = b.iassured),
	             (select count(icode) from ca_permit where iclass = '02'
	                    and (dexpire is null or dexpire > today)
	                    and trim(icode) <> '' and icode = b.itag),
	             (select count(icode) from ca_permit where iclass = '03'
	                    and (dexpire is null or dexpire > today)
	                    and trim(icode) <> '' and icode = b.iengine),
	             (select count(icode) from ca_permit where iclass = '04'
	                    and (dexpire is null or dexpire > today)
	                    and trim(icode) <> '' and icode = b.iroute[1,2]),
	             (select count(icode) from ca_permit where iclass = '05'
	                    and (dexpire is null or dexpire > today)
	                    and trim(icode) <> '' and icode =
	                        (select iroute_main from cm_route where iroute = b.iroute)),
	             (mdmg_prem + mlia_prem), dply_begin
	        into $sIestimate, $sAbn_type, $sImgr, $iCountJC,
	             $sIpolicy1, $iCountEW, $sIpolicy2, $ifuw_status,
	             $iCntSP1, $iCntSP2, $iCntSP3, $iCntSP4, $iCntSP5,
	             $mprem, $dply_begin
	        from ply_relation a, policy b, officer c
	       where a.ipolicy = b.ipolicy and a.iofficer = c.iofficer
	         and a.fcard_class = '2' and a.dpolicy is null
	         and a.ipolicy = $XIpolicy
	         AND a.ileader matches $ileader
	         AND a.iquota matches $xIquota;

	     iCountSP = iCntSP1 + iCntSP2 + iCntSP3 + iCntSP4 + iCntSP5 ;

	     printf("XIpolicy=[%s]mprem=[%ld]ileader=[%s]xIquota=[%s]\n",XIpolicy,mprem,ileader,xIquota);
	     if ((ifuw_status == -1) || (ifuw_status >= 600))
	     {
	         /* �¬y�{�S����,�i�H���`�C�L�O�� & �鵲 */
		 printf("�¬y�{�S����,�i�H���`�C�L�O�� & �鵲 :XIpolicy=[%s]\n",XIpolicy);
	     }
	     else if (iCountJC > 0)
	     {
	   	 /* �F���ۼХ�(JC) */
    		 printf("�F���ۼХ�(JC) :XIpolicy=[%s]\n",XIpolicy);
	     }
	     else if (iCountEW > 0)
	     {
	   	 /* �O�T�I(EW) */
    		 printf("�O�T�I(EW :XIpolicy=[%s]\n",XIpolicy);
	     }
	     else if (iCountSP > 0)
	     {
	   	 /* �ĳq�ץ�(SP) */
    		 printf("�ĳq�ץ�(SP) :XIpolicy=[%s]\n",XIpolicy);
	     }
	     else if ((ifuw_status == -100 ) || ((ifuw_status >=500) && (ifuw_status < 600)))
	     {
	   	 /* ���I�պ��ɬd�L���,�i��O��O��αM�ץ�; 500/510 ���`���O�X��y�{ */
		 $select fuw_status,	iestimate
		    into $ifuw_status, $sIestimate
		    from estimate
		   where ipolicy2 = $sIpolicy1 and dentry >= add_months(today,-6);
		 printf("979:ifuw_status=[%d]sIestimate=[%s]\n",ifuw_status,sIestimate);

	   	 if (SQLCODE == SQLNOTFOUND) ifuw_status = 500; /* �������ɧ䤣��, ���ӬO��O���(B2B�B�@���barcode) */
	   	 if (ifuw_status == -1)
	   	 {
	   	     /*�¬y�{,�i���`�X��鵲 */
     		     printf("�¬y�{,�i���`�X��鵲 :XIpolicy=[%s]\n",XIpolicy);
	   	 }
	   	 else
	   	 {
		     /* ��@�γ������ɸ�� */
		     $select unique ipre_rcv, iins_kind into $sIestimate, $iins_kind
			from cm_pre_receive
		       where ipolicy1 = $sIpolicy1 and ipolicy2 = $sIpolicy2;
		     printf("��@�γ������ɸ�� :sIpolicy1=[%s]sIpolicy2=[%s]\n",sIpolicy1,sIpolicy2);
		     if (SQLCODE == SQLNOTFOUND)
	   	     {
	   	         /* ���b���I��������, ���b�@�γ�������...���D�j�F.......*/
			 $insert into tmp_tb (ipolicy,  fprint, errmsg, ftype_pol)
		          values             ($XIpolicy,   'A', '�d�L��������','0');
			 printf("���b���I��������, ���b�@�γ�������...���D�j�F :XIpolicy=[%s]\n",XIpolicy);
			 continue;
	   	     }
	   	     else
	   	     {
	   	         strcpy(deffect4,cm_check_workday(dply_begin, deffect4));
	   		 printf("dply_begin=[%s]deffect4=[%s]\n",dply_begin,deffect4);
	   		 /* ú�Ǫ��`�O�O */
			 $select nvl(sum(b.mnt),0) into $mnt1
			    from cm_pre_receive a, ao_prercv_pass b
			   where a.iins_cat = b.iins_cat
			     and a.ipre_rcv = b.ipre_rcv
			     and a.iins_kind = b.iins_kind
			     and a.ipre_end = b.ipre_end
			     and a.iins_cat = 'C'
			     and a.fstatus != 90
			     and a.ipre_rcv = $sIestimate
			     and a.iins_kind = $iins_kind
			     and ((a.ftype_pol = '1M' and b.dcoll_last <= (a.deffect + 30))
			   	  or (a.ftype_pol = ' ' and b.dcoll_last <= $deffect4))
			     and b.dacc_last is not null;

			 printf("sIestimate=[%s]iins_kind=[%s]deffect4=[%s]mnt1=[%f]mprem=[%f]\n",sIestimate,iins_kind,deffect4,mnt1,mprem);
			 if(mnt1 >= mprem)
			 {
			     /* �O�O����,�i���`�L��鵲 */
			     printf("�O�O����,�i���`�L��鵲 :XIpolicy=[%s]mnt1=[%f]mprem=[%f]\n",XIpolicy,mnt1,mprem);
			 }
			 else
			 {
			     if (strcmp(sImgr,"1") == 0)
			     {
			         /* �j�v����*/
				 if ((sIcomm_obj[0]=='B') || (sIcomm_obj[0]=='J'))
				 {
				     if ((mprem - mnt1) <= 10)
				     {
				         /* 10���e�\�d��,�i���`�L��鵲 */
				         printf("10���e�\�d��,�i���`�L��鵲 :XIpolicy=[%s]mnt1=[%f]mprem=[%f]\n",XIpolicy,mnt1,mprem);
				     }
				     else
				     {
				         /* ���O������,�L�k�L��鵲 */
					 $insert into tmp_tb (ipolicy,  fprint, errmsg)
				            values           ($XIpolicy,   'A', '���O������');
				         printf("���O������,�L�k�L��鵲:XIpolicy=[%s]mnt1=[%f]mprem=[%f]\n",XIpolicy,mnt1,mprem);
				         continue;
				     }
				 }
				 else
				 {
				     if ((mprem - mnt1) <= 100)
				     {
				         /* 100���e�\�d��,�i���`�L��鵲 */
				         printf("100���e�\�d��,�i���`�L��鵲:XIpolicy=[%s]mnt1=[%f]mprem=[%f]\n",XIpolicy,mnt1,mprem);
				     }
				     else
				     {
					 /* ���O������,�L�k�L��鵲 */
					 $insert into tmp_tb (ipolicy,  fprint, errmsg)
				            values           ($XIpolicy,   'A', '���O������');
				         printf(">100���e�\�d��,���O������,�L�k�L��鵲:XIpolicy=[%s]mnt1=[%f]mprem=[%f]\n",XIpolicy,mnt1,mprem);
				         continue;
				     }
				 }
			     }
			     else
			     {
				 /* ���O������,�L�k�L��鵲 */
				 $insert into tmp_tb (ipolicy,  fprint, errmsg)
				    values           ($XIpolicy,   'A', '���O������');
				 printf("1076:���O������,�L�k�L��鵲:XIpolicy=[%s]\n",XIpolicy);
				 continue;
			     }
			 }
	   	     }
	   	 }
	     }
	     else
	     {
		 /* ���D��, �L�k�k��........ */
		 $insert into tmp_tb (ipolicy,  fprint, errmsg)
		    values           ($XIpolicy,   'A', '���D��, �L�k�k��........');
		 printf("1088:���D��, �L�k�k��:XIpolicy=[%s]\n",XIpolicy);
		 continue;
	     }
	 #endif
	 /* ------------------------------------------------------------------ */
         $insert into tmp_tb (ipolicy, fprint, errmsg, ftype_pol, iestimate) values ($XIpolicy, 'Y',' ','0', $sIestimate);

        strcpy(sTmpiofficer, trim(sTmpiofficer));
        printf("sTmpIcomp[%s],sTmpIbranch[%s],ymd[%s]\n", sTmpIcomp, sTmpIbranch, ymd);
        if (iFpolicy && iFbig) break;
    }
    if (iFpolicy)
        if (iFbig)
             $CLOSE PLY_CUR_A1;
        else
             $CLOSE PLY_CUR_A2;
    else
    	if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
    		$CLOSE PLY_CUR_A4;
    	else 
        	$CLOSE PLY_CUR_A3;

    if (iFpolicy)
        if (iFbig) $FREE PLY_CUR_A1; else $FREE PLY_CUR_A2;
    else 
    	if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
    		$FREE PLY_CUR_A4;
    	else 
    		$FREE PLY_CUR_A3;

    return M_CM_OK;

errexit:
    printf("SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
    strcpy(sErrMsg,"�O���ˮ֦��~!!");
    return SQLCODE;
}
/******************************************************************************/
/* �µ{���ƥ��ȩ� */
long car306_buildx()
{
    int    count=0;
    int    count_no_tobe=0;
    int    rc;
    $char  FormFile[N_FILE+1];
    $char  stmt[400];
    $char  tmp_policy[POLICY_NUM_1];
    $char  sTmpbgn1[POLICY_NUM_1], sTmpend1[POLICY_NUM_1];
    $char  sTmpbgn2[POLICY_NUM_1], sTmpend2[POLICY_NUM_1];
    $date  dDpolicy;
    $date  dDply_close;
    $short no_null;
    $char  nbenef_tmp[43], nbenef[43];
    $char  sTmpiofficer[11],sIresource[2] ,sIbroker[11], sIquota[11], sIleader[11];
    $char  nequipment14[2];
    $char  nequipment[31];
    $char  itmp_pol_a[21], tmp_transno[21], v_sMsg[512];
    char fbusiness[2], ibroker_top[11], bzfrom[3];
    $long  mcommission;
    $char  sIcomm_obj[11], sIroute_comm[4], sIroute_prop[3], sIroute[21];
		$char  char_dentry[YYMMDD],dentry[YYYYMMDD];
    if (db_select(DBName) == False)  return M_CM_DB_NOTOPEN;

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;



    iFpolicy = TRUE;   /*�H�O�渹�C�L*/
    iFbig = FALSE;     /*�L�j�O��J�`*/
    count = 0;
    count_no_tobe = 0;

    if (ply_bgn[0]=='*' || ply_bgn[0]==' ' || ply_bgn[0]=='\0')
    {
        iFpolicy = FALSE;
        iFbig = FALSE;
    }

    if (ply_end[0]=='*' || ply_end[0]==' ' || ply_end[0]=='\0')
    {
        iFpolicy = FALSE;
        iFbig = FALSE;
    }

    if (iFpolicy)
    {
        rc = split_policy(ply_bgn, sTmpbgn1, sTmpbgn2);
        if (rc !=  M_CM_OK) return rc;
        rc = split_policy(ply_end, sTmpend1, sTmpend2);
        if (rc !=  M_CM_OK) return rc;

        if (strcmp(sTmpbgn1, sTmpend1) != 0)
        {
            strcpy(ply_bgn, sTmpbgn1);
            strcpy(ply_end, sTmpend1);
            iFbig = FALSE;
        }
        else
        {
            if (strlen(sTmpbgn2) == CAR_TARGET_LEN &&
                strlen(sTmpend2) == CAR_TARGET_LEN)
            {
                if (strcmp(sTmpbgn2, sTmpend2) == 0) iFbig = FALSE;
                else iFbig = TRUE;
            }
            else
            {
                strcpy(ply_bgn, sTmpbgn1);
                strcpy(ply_end, sTmpend1);
                iFbig = FALSE;
            }
        }
        printf("sTmpbgn1------------>[%s]\n",sTmpbgn1);

        if (strlen(ply_bgn) == CAR_PLY_TAG_LEN)
        {
            $SELECT MAX(ibatch_no)+1
               INTO $ibatch_no:no_null
               FROM ply_relation
              WHERE ipolicy[1,13]= $sTmpbgn1
                AND dply_close IS NOT NULL;
            if (SQLCODE == SQLNOTFOUND || no_null==-1) ibatch_no=1;

            printf("17-->ibatch_no[%d]\n", ibatch_no);
            printf("17-->SQLCODE[%d]\n", SQLCODE);
            printf("17-->no_null[%d]\n", no_null);

            /*�j�O���update�帹*/
            $UPDATE ply_relation
                SET ibatch_no = $ibatch_no
              WHERE fcard_class = '2'
                AND dply_close is NULL
                AND dpolicy is NULL
                AND (ipolicy >= $ply_bgn
                AND  ipolicy <= $ply_end);
        }
        else ibatch_no=0;
    }
    else ibatch_no = 0;

    /* �P�_�C�L�s�ª��� */
      if (old_iply[0] == 'A')
      {
				 printf("�s��\n");
         $SELECT kPgNum_Line, nForm_File INTO $PgLine, $FormFile
            FROM Form
           WHERE ksys_grp="CA" AND kPgmID = 306;
       } else
       {
				 printf("�ª�\n");
       	 $SELECT kPgNum_Line, nForm_File INTO $PgLine, $FormFile
            FROM Form
           WHERE ksys_grp="CA" AND kPgmID = 3062;
       }

    strcpy(FormFile,rtrim(FormFile));
    sprintf(OutFile,"%s.tx",outputf);

		printf("what is file name? [%s]\n",OutFile);
    if (iFpolicy)
    {
        if (iFbig)
        {
            $DECLARE PLY_CUR_x1 CURSOR FOR
              SELECT a.ipolicy , a.iofficer , a.iresource , a.dpolicy, a.dply_close, a.ibroker,
                     a.iquota, a.mlia_commi + a.mdmg_commi, a.ileader,
                     a.icomm_obj, a.iroute_comm, b.iroute, b.iroute_prop
                FROM ply_relation a, policy b
               WHERE a.ipolicy = b.ipolicy
                 AND a.fcard_class='2'
                 AND a.dpolicy is NULL
                 AND a.dply_close is NULL
                 AND (a.ipolicy >= $ply_bgn
                 AND  a.ipolicy <= $ply_end);
            printf("-----> into PLY_CUR_1\n");
        }
        else
        {
            $DECLARE PLY_CUR_x2 CURSOR FOR
              SELECT a.ipolicy , a.iofficer , a.iresource , a.dpolicy, a.dply_close, a.ibroker,
                     a.iquota, a.mlia_commi + a.mdmg_commi, a.ileader,
                     a.icomm_obj, a.iroute_comm, b.iroute, b.iroute_prop
                FROM ply_relation a, policy b
               WHERE a.ipolicy = b.ipolicy
                 AND a.fcard_class='2'
                 AND a.dpolicy is NULL
                 AND a.dply_close is NULL
                 AND (a.ipolicy >= $ply_bgn AND a.ipolicy <= $ply_end)
               ORDER BY a.ipolicy;
            printf("-----> into PLY_CUR_2\n");
        }
    }
    else
    {   /*�u�L�D�j�O��*/
        $DECLARE PLY_CUR_x3 CURSOR FOR
          SELECT a.ipolicy , a.iofficer , a.iresource ,a.dpolicy , a.dply_close, a.ibroker,
                 a.iquota, a.mlia_commi + a.mdmg_commi, a.ileader,
                 a.icomm_obj, a.iroute_comm, b.iroute, b.iroute_prop
            FROM ply_relation a, policy b
           WHERE a.ipolicy = b.ipolicy
             AND a.dentry = $dentry
             AND a.ipolicy[1,3] MATCHES $sIbranch
             AND a.fcard_class='2'
             AND a.dpolicy is NULL
             AND a.dply_close is NULL
             AND LENGTH(a.ipolicy) = 13
           ORDER BY a.ipolicy;
        printf("-----> into PLY_CUR_3\n");
    }

    rgu_init_report(FormFile, OutFile);

    if (iFpolicy)
        if (iFbig) $OPEN PLY_CUR_x1; else $OPEN PLY_CUR_x2;
    else
        $OPEN PLY_CUR_x3;

    $BEGIN WORK;

    while (1)
    {
        XIpolicy[0]='\0';
        /*----------------------------------------------------------------*/
        if (iFpolicy)
            if (iFbig)
                 $FETCH PLY_CUR_x1 INTO $XIpolicy, $sTmpiofficer , $sIresource , $dDpolicy, $dDply_close,
                                       $sIbroker, $sIquota, $mcommission, $sIleader,
                                       $sIcomm_obj, $sIroute_comm, $sIroute, $sIroute_prop;
            else
                 $FETCH PLY_CUR_x2 INTO $XIpolicy, $sTmpiofficer , $sIresource , $dDpolicy, $dDply_close,
                                       $sIbroker, $sIquota, $mcommission, $sIleader,
                                       $sIcomm_obj, $sIroute_comm, $sIroute, $sIroute_prop;
        else
            $FETCH PLY_CUR_x3 INTO $XIpolicy, $sTmpiofficer , $sIresource , $dDpolicy, $dDply_close,
                                       $sIbroker, $sIquota, $mcommission, $sIleader,
                                       $sIcomm_obj, $sIroute_comm, $sIroute, $sIroute_prop;

        if (SQLCODE == SQLNOTFOUND) break;
        if ((dDpolicy != DATENULL) || (dDply_close != DATENULL)) continue;


        if( sTmpiofficer[0] != 'W')
        {
            /* �t�X�q���ĤG���q, ��H�@��function�ˮ� */
            rc = cm_chk_policy("1", sTmpiofficer, " ", " ", " ", " ", " ", " ");
            if( rc != M_CM_OK)
            {
                strcpy(v_sMsg, cm_get_errmsg(rc));
                sprintf( sErrMsg, "�O�渹[%s], %s", XIpolicy, v_sMsg);
                $ROLLBACK WORK;
                return rc;
            }
        }

        /* �t�X�q���ĤG���q, ��H�@��function�ˮ� */
        rc = cm_chk_policy("2", " ", " ", sIquota, " ", " ", " ", " ");
        if( rc != M_CM_OK)
        {
            strcpy(v_sMsg, cm_get_errmsg(rc));
            sprintf( sErrMsg, "�O�渹[%s], %s", XIpolicy, v_sMsg);
            $ROLLBACK WORK;
            return rc;
        }

        /* �t�X�q���ĤG���q, ��H�@��function�ˮ� */
        /* �I����H�O�_����X�� */
        rc = cm_chk_policy("4", " ", " ", " ", sIcomm_obj, " ", " ", " ");
        if( rc != M_CM_OK)
        {
            strcpy(v_sMsg, cm_get_errmsg(rc));
            sprintf( sErrMsg, "�O�渹[%s], %s", XIpolicy, v_sMsg);
            $ROLLBACK WORK;
            return rc;
        }

        /* �I����H���L�X���� */
        rc = cm_chk_policy("6", " ", " ", " ", sIcomm_obj, "C", " ", " ");
        if( rc != M_CM_OK)
        {
            strcpy(v_sMsg, cm_get_errmsg(rc));
            sprintf( sErrMsg, "�O�渹[%s], %s", XIpolicy, v_sMsg);
            $ROLLBACK WORK;
            return rc;
        }

        /* �I����H��10000,������ add by sylvia 100.06.22 */
        if((strcmp(trim(sIcomm_obj),"10000") == 0)  && (mcommission > 0))
        {
            strcpy(v_sMsg, "���I���~�Ȥ��i�H������");
            sprintf( sErrMsg, "�O�渹[%s], %s", XIpolicy, v_sMsg);
            $ROLLBACK WORK;
            return rc;
        }

        /* �q���N���P�q���ۭq�~�ȥN���������Y�O�_���T add by sylvia 100.06.22 */
        rc = cm_chk_policy("7", " ", " ", " ", " ", " ", sIroute, sIroute_prop);
        if( rc != M_CM_OK)
        {
            strcpy(v_sMsg, cm_get_errmsg(rc));
            sprintf( sErrMsg, "�O�渹[%s], %s", XIpolicy, v_sMsg);
            $ROLLBACK WORK;
            return rc;
        }
        count++;

        strcpy(sTmpiofficer, trim(sTmpiofficer));

        printf("sTmpIcomp[%s],sTmpIbranch[%s],ymd[%s]\n", sTmpIcomp, sTmpIbranch, ymd);

        /* b2c9810011 b2c�����b���L�����ͥ���s��(���]���ثe�ȮɵL�k�ѨMitmp_policy�Q����
           �պ⸹��|�Q�\���ҥH�Ȯ��٬O���h�����s��,�Y����s������ƫh�L��������s��,
           �Y���չL��b2c���պ⸹��100%�O�d��itmp_policy,���U�N�L���t�~�P�O����s�� */
        strcpy(itmp_pol_a," ");
        $SELECT itmp_policy, nvl(transno,' ')
           INTO $itmp_pol_a, $tmp_transno
           FROM ply_relation
          WHERE ipolicy = $XIpolicy;

        /* ���O14�����o§�A���ݲ��ͥ���s�� */
        $SELECT nequipment
           INTO $nequipment
           FROM policy
          WHERE ipolicy = $XIpolicy;

        if( (equip_cmp(nequipment,"14") == TRUE) || (equip_cmp(nequipment,"37") == TRUE) ||
            (strncmp(itmp_pol_a,"17N",3) == 0))
        {
            /* �������o§���O */
        }
        else
        {
            printf("����s��===>sTmpIcomp[%s]\n",sTmpIcomp);

            /* b2c9810011 ������s���̤����� */
            if (tmp_transno[0] == '\0' || tmp_transno[0] == ' ')
                 rc = cm_get_serial_num("AO", "A1", sTmpIcomp, sTmpIcomp, ymd, sTransno);
            else
            {
                 strcpy(sTransno, tmp_transno);
                 rc = 0;
            }

            printf("sTransno[%s]\n",sTransno);
            printf("4.#################\n");

            if (rc != 0)
            {
                $WHENEVER SQLERROR CONTINUE;
                $ROLLBACK WORK;
                return rc;
            }
            else
            {
                $UPDATE ply_relation
                    SET transno = $sTransno,
                        seqno = '1'
                  WHERE ipolicy = $XIpolicy
                    AND dply_close is NULL
                    AND dpolicy is NULL;

                $SELECT irelative_ply
                   INTO $RIpolicy
                   FROM ply_relation
                  WHERE ipolicy = $XIpolicy;

                $UPDATE ply_relation
                    SET transno = $sTransno,
                        seqno = '2'
                  WHERE ipolicy = $RIpolicy;
            }
        }
        printf("5.#################\n");

        strcpy(sTmpiofficer, trim(sTmpiofficer));
        /* �g��N����W99999BE�ɡAW99999IF,W99999IS, �h�𶷻s�@������ */
        if( (strncmp(sTmpiofficer,"W",1)==0) && (strncmp(sTmpiofficer+6,"LE30",4)!=0) )
        {
            /* �E�M�a�x�M�׻ݦL�O�� */
            /* Do not call ca_rpt_policy() */
        }
        else if ( (strncmp(sTmpiofficer,"F9813501",7)==0) || (strncmp(sTmpiofficer,"F9814201",7)==0) )
        {
             /* Do not call ca_rpt_policy() */
        }
        else
        {
                 if (old_iply[0] == 'A')
                     rc=ca_rpt_policy(XIpolicy, "", ibatch_no, ikind, iFbig, iPrintlist, "a", ply_end, userid,PrintDlist,"","","");
                 else
                     rc=ca_rpt_policy_old(XIpolicy, "", ibatch_no, ikind, iFbig);

                 if (rc != M_CM_OK)
                 {
                        strcpy(v_sMsg, cm_get_errmsg(rc));
                        sprintf( sErrMsg, "�O�渹[%s], %s", XIpolicy, v_sMsg);
                        $ROLLBACK WORK;
                        return rc;
                 }
                count_no_tobe ++;
             
        }

        $UPDATE ply_relation
            SET fprint = "1",
                dpolicy = $Today
          WHERE fcard_class = '2'
            AND dply_close is NULL
            AND dpolicy is NULL
            AND ipolicy = $XIpolicy;

        $SELECT nbenef
           INTO $nbenef_tmp
           FROM policy
          WHERE ipolicy = $XIpolicy;

        printf("the nbenef_tmp ==> [%s]\n",nbenef_tmp);

        /* ������v�H, �n�A���L�@���O�� */
        if ((strcmp(trim(nbenef_tmp),"") == 0) ||(strcmp(trim(nbenef_tmp),'\0') == 0))
        {
            printf("the nbenef is not exist !!!\n");
        }
        else
        {
            printf("the nbenef is exist !!!\n");
            strcpy(sTmpiofficer, trim(sTmpiofficer));

            if( (strncmp(sTmpiofficer,"W",1)==0) && (strncmp(sTmpiofficer+6,"LE30",4)!=0) )
            {
                    /* Do not call ca_rpt_policy() */
                    /* �E�M�a�x�M�׻ݦL�O�� */
            }
            else if ( (strncmp(sTmpiofficer,"F9813501",7)==0) || (strncmp(sTmpiofficer,"F9814201",7)==0) )
            {
                    /* Do not call ca_rpt_policy() */
            }
            else
            {
                /* 1061012002-SC3 ISID+rba�j���I�G�����X��@�~���L��� ���N�I ���ܦL��@�~���L���*/
                chkoutprint[0] = '\0';
                $select fout_print into $chkoutprint
                   from ply_relation
                  where ipolicy = $XIpolicy;                
                if(chkoutprint[0] !='1') /* 1061012002-SC3 ISID+rba�j���I�G�����X��@�~���L��� ���N�I ���ܦL��@�~���L���*/
                {
                      if (old_iply[0] == 'A')
                        rc=ca_rpt_policy(XIpolicy, "", ibatch_no, ikind, iFbig, iPrintlist, "a", ply_end,userid,PrintDlist,"","","");
                     else
                        rc=ca_rpt_policy_old(XIpolicy, "", ibatch_no, ikind, iFbig);

                     if (rc != M_CM_OK)
                     {
                          $ROLLBACK WORK;
                          return rc;
                     }
                }
            }
        }

        if (iFpolicy && iFbig) break;
    }

    printf("------>iFpolicy [%d]\n", iFpolicy);
    printf("------>iFbig [%d]\n", iFbig);

    if (iFpolicy)
        if (iFbig)
             $CLOSE PLY_CUR_x1;
        else
             $CLOSE PLY_CUR_x2;
    else
        $CLOSE PLY_CUR_x3;

    if (iFpolicy)
        if (iFbig) $FREE PLY_CUR_1; else $FREE PLY_CUR_2;
    else $FREE PLY_CUR_x3;

    if (count == 0)
    {
        $ROLLBACK WORK;
        return M_CA_NREL_PLY;
    }
    printf("count_no_tobe[%d],count[%d]\n",count_no_tobe, count);
    /* �C�L�h�i�O��������ζ�TOBE�M�׮ɡA�h��ܤ��o�C�L�O�椺�e���T�� */
    if ((count_no_tobe == 0) && (count != 0))
    {
        printf("1\n");
        $COMMIT WORK;
        return M_CA_TOBE_NO_PRINT;
    }

    /* �C�L�@�i�O��B���M�׷~�ȮɡA�h��ܤ��o�C�L�O�椺�e���T�� */
    if ((count == 1) && (strncmp(sTmpiofficer,"W",1)==0))
    {
            printf("2\n");
            $COMMIT WORK;
            return M_CA_TOBE_NO_PRINT;
    }

    /* �C�L�@�i�O��B���M�׷~�ȮɡA�h��ܤ��o�C�L�O�椺�e���T�� (1030630002_C4)*/
    strcpy(sIresource, trim(sIresource));
    if ((count == 1) && ((strncmp(sTmpiofficer,"N",1)==0) &&
    	(strncmp(sIresource,"E",1)==0)))
    {
            printf("3 \n");
            $COMMIT WORK;
            return M_CA_TOBE_NO_PRINT;
    }

    rgu_finish_report();


    printf( "iFpolicy[%d]\n", iFpolicy);
    if (iFpolicy)
    {
        printf("strlen(ply_bgn)[%d] , CAR_PLY_TAG_LEN[%d]\n", strlen(ply_bgn) , CAR_PLY_TAG_LEN);
        if (strlen(ply_bgn) == CAR_PLY_TAG_LEN)
        {
            puts("�j�O��");
            $UPDATE ply_relation
                SET fprint = "1", dpolicy = $Today
              WHERE fcard_class = '2'
                AND dply_close is NULL
                AND dpolicy is NULL
                AND (ipolicy >= $ply_bgn
                AND  ipolicy <= $ply_end);
        }
        else
            $UPDATE ply_relation
                SET fprint = "1", dpolicy = $Today
              WHERE fcard_class = '2'
                AND dply_close is NULL
                AND dpolicy is NULL
                AND LENGTH(ipolicy) = 13
                AND (ipolicy >= $ply_bgn
                AND  ipolicy <= $ply_end);
    }
    else
    {
        $UPDATE ply_relation
            SET fprint = "1", dpolicy = $Today
          WHERE dentry = $dentry
            AND ipolicy[1,3] MATCHES $sIbranch
            AND fcard_class='2'
            AND dply_close is NULL
            AND dpolicy is NULL
            AND LENGTH(ipolicy) = 13;
    }

    $COMMIT WORK;

    return M_CM_OK;

errexit:
    printf("SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}