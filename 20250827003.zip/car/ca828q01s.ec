#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include <math.h>
#include "gls_array.h"
#include "gls_const.h"

#define SUCCESS                 1
#define FAIL                    0
#define YES                     1
#define NO                      0
#define NEXTPAGE                7
#define FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND
#define fmt "---,---,---,--&"

extern char RPTDIR[];

/****  get data from client  ****/
$char  DBName[5];
char   userid[11];
$char  ibranch[4];
$char  datebgn[11], dateend[11];
$char  outputf[21];

/****  car828_p  ****/
$char  cDatebgn[11], cDateend[11];
$long  lMins_stl;
$char  sDclose[11];

$char  path_DataFile[80];

static int pagenum=1;
$char  FormTp[3];
char   BodyFile[ N_FILE+1];
char   TitleFile[ N_FILE+1];
$int   StartRow,TitleRow;
$int   ItemRow, TotColumn;
$int   PgLine, Width;
$int   iCnt;
int    max_count, errCode;
int    tmp_len;

$char  stmt[2048];
long   msg_code;

$struct Rec828 {
   char sIunit[3];
   char sNunit[31];
   char sNacc_driver[21];
   char sItel[21];
   char sIins_type[31];
   long lMstl;
   char sIpolicy[21];
   char sNassured[121];
   char sIclaim[21];
   char sIadjuster[11];
   char sNadjuster[21];
   char sDaccident[11];
   char sDclose[11];
   char sNassured_tel[21];
   char sItag[CA_TAG_NUM];
} r;

long car828_build1();
long car828_build2();
void car828_title1();
void car828_title2();
void car828_body();

main(argc,argv)
int  argc;
char **argv;
{
   long rc=0;

   batchinit();

   strcpy(DBName,       isNULLstr(argv[1]));
   strcpy(userid,       isNULLstr(argv[2]));
   strcpy(datebgn,      isNULLstr(argv[3]));  /* �鵲�_�� */
   strcpy(dateend,      isNULLstr(argv[4]));  /* �鵲���� */
   strcpy(outputf,      isNULLstr(argv[5]));


   rc = car828_build1();

   if (rc == api_OKComplete)
   {
       create_sign_form("car828",BodyFile, Width);
       if ((rc=save_form_info(F_BLK1,"CA",828,userid,FormTp,max_count,outputf))<0)
            EWRITE(userid,rc,"save_form_info_failed");
   }

   max_count = 0;
   printf(" BEF car828_build2() \n");

   rc = car828_build2();

   if (rc == api_OKComplete)
   {
       create_sign_form("car828",BodyFile, Width);
       if ((rc=save_form_info(F_BLK1,"CA",828,userid,FormTp,max_count,outputf))<0)
            EWRITE(userid,rc,"save_form_info_failed");
   }
}

long car828_build1()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
   $char  iclaim[CLAIM_NUM], ipolicy[POLICY_NUM_1], daccident[15];
   $long  dclose_ctype, dclose_rtype;
   int    i;

   $WHENEVER SQLERROR GOTO errexit;

   if(db_select(DBName) == False)
   {
       EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
       return FAIL;
   }

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 828;

   strcpy(TitleFmt, rtrim(TitleFmt));
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf(TitleFile, "%sA.ti", outputf);
   sprintf(BodyFile, "%sA.bd", outputf);

   $WHENEVER SQLERROR GOTO errexit;

   /* �B�z���Y */
   rgu_init_report(TitleFmt, TitleFile);
   car828_title1();
   rgu_finish_report();

   /* �B�z���� */
   rgu_init_report(BodyFmt, BodyFile);

   /* �}�l������� */
   car828_p1();

   $DECLARE Acursor1 CURSOR FOR
     SELECT *
       FROM car828_TEMP1
      ORDER BY 1,2,4;

   $OPEN Acursor1;

   for (i=0; ; i++)
   {
      $FETCH Acursor1
        INTO $r.sIunit,$r.sIclaim,$r.sIadjuster,$r.sIpolicy,
             $r.sNassured,$r.sNacc_driver,$r.sItel,$r.sIins_type,
             $r.lMstl,$r.sDaccident,$r.sDclose,$r.sNassured_tel,
             $r.sItag;

      if (SQLCODE == SQLNOTFOUND)
      {
         if (i == 0)
         {
            EWRITE(userid, SQLCODE, "�L�X�G���󪺸�� !");
            return 0;
         }
         break;
      }

      $SELECT nname
         INTO $r.sNadjuster
         FROM officer
        WHERE iofficer = $r.sIadjuster;
        if (SQLCODE == SQLNOTFOUND) strcpy(r.sNadjuster," ");

      $SELECT nchi_full
         INTO $r.sNunit
         FROM branch
        WHERE ibranch = $r.sIunit;
        if (SQLCODE == SQLNOTFOUND)
            strcpy(r.sNunit," ");

        car828_body();
   }
   $CLOSE Acursor1;
   $FREE Acursor1;

   rgu_put_body(2); max_count++;
   rgu_finish_report();

   $DROP TABLE car828_TEMP1;

   return SUCCESS;

errexit:
   /* printf("Lai:err,%d",SQLCODE);  */
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return 0;
}



long car828_build2()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
   $char  iclaim[CLAIM_NUM], ipolicy[POLICY_NUM_1], daccident[15];
   $long  dclose_ctype, dclose_rtype;
   int    i;

   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 828;

   strcpy(TitleFmt, rtrim(TitleFmt));
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf(TitleFile, "%sB.ti", outputf);
   sprintf(BodyFile, "%sB.bd", outputf);

   $WHENEVER SQLERROR GOTO errexit;

   /* �B�z���Y */
   rgu_init_report(TitleFmt, TitleFile);
   car828_title2();
   rgu_finish_report();

   /* �B�z���� */
   rgu_init_report(BodyFmt, BodyFile);

   /* �}�l������� */
   car828_p2();

   $DECLARE Acursor12 CURSOR FOR
     SELECT *
       FROM car828_TEMP2
      ORDER BY 1,2,4;

   $OPEN Acursor12;

   for (i=0; ; i++)
   {
      $FETCH Acursor12
        INTO $r.sIunit,$r.sIclaim,$r.sIadjuster,$r.sIpolicy,
             $r.sNassured,$r.sNacc_driver,$r.sItel,$r.sIins_type,
             $r.lMstl,$r.sDaccident,$r.sDclose,$r.sNassured_tel,
             $r.sItag;

      if (SQLCODE == SQLNOTFOUND)
      {
         if (i == 0)
         {
            EWRITE(userid, SQLCODE, "�L�X�G���󪺸�� !");
            return 0;
         }
         break;
      }

      $SELECT nname
         INTO $r.sNadjuster
         FROM officer
        WHERE iofficer = $r.sIadjuster;
        if (SQLCODE == SQLNOTFOUND) strcpy(r.sNadjuster," ");

      $SELECT nchi_full
         INTO $r.sNunit
         FROM branch
        WHERE ibranch = $r.sIunit;
        if (SQLCODE == SQLNOTFOUND)
            strcpy(r.sNunit," ");

        car828_body();
   }
   $CLOSE Acursor12;
   $FREE Acursor12;

   rgu_put_body(2); max_count++;
   rgu_finish_report();

   $DROP TABLE car828_TEMP2;

   return SUCCESS;

errexit:
   /* printf("Lai:err,%d",SQLCODE);  */
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return 0;
}


car828_p1()
{

     $char sBranch[3];
     $char stmt[2048];
     $char sIclaim[21],sIclose_type[2],sIpolicy[21],sIadjuster[11];
     $char sIstl_note[4];
     $char sNassured[121],sIofficer[11];
     $long  lMins_stl;
     $char  sDclose[11],sNacc_driver[21];
     $char  sDrivertel[21],Nassured_tel[21];
     $char  sDaccident[11],sIunit[3];
     $char  sInsTmp[31];
     $char  sIins_type[5],sItag[CA_TAG_NUM];
     int    i;

     $WHENEVER SQLERROR goto errexit;

     $CREATE TEMP TABLE car828_TEMP1
     (
     iunit       char(3)    default ' ',
     iclaim      char(20)   default ' ',
     iadjuster   char(10)   default ' ',
     ipolicy     char(20)   default ' ',
     nassured    char(120)  default ' ',
     nacc_driver char(20)   default ' ',
     itel        char(20)   default ' ',
     iins_type   char(30)   default ' ',
     mstl        integer    default 0,
     daccident   date       ,
     dclose      date       ,
     nassure_tel char(20)   default ' ',
     itag        char(12)    default ' '
     )WITH NO LOG;

 
     /*** �߮ר��z����B�z ***/
     if (datebgn[0] == '*') strcpy(datebgn, "88/01/01");
     if (dateend[0] == '*') strcpy(dateend, "99/12/31");
     if (dateend[0] == ' ') strcpy(dateend, datebgn);

     strcpy(cDatebgn, cm_to_infdate(datebgn));
     strcpy(cDateend, cm_to_infdate(dateend));

     $DECLARE s_cur CURSOR FOR
       SELECT branch
         INTO $sBranch
         FROM servertbl
        WHERE branch <> 'S1';
     $OPEN s_cur;
     for(;;){
     $FETCH s_cur;
     if (SQLCODE == SQLNOTFOUND) break;

            sprintf(stmt,
            " SELECT SUM(NVL(mins_stl,0))                  \
                FROM %s:stl_ins_type                       \
               WHERE iclaim = ?                            \
                 AND fstl = '1'                            \
                 AND dclose IS NOT NULL                    \
                 AND iins_type IN ('01','05','08','09') ",
                 get_full_dbname(sBranch));
            $PREPARE cid02 FROM $stmt;

         printf("stmt[%s]\n",stmt);
           sprintf(stmt,
            " SELECT ipolicy,nacc_driver,drivertel,  \
                     DATE(daccident),iadjuster       \
                FROM %s:appraisal                    \
               WHERE iclaim = ? ",get_full_dbname(sBranch));
         printf("stmt[%s]\n",stmt);
            $PREPARE cid03 FROM $stmt;

            sprintf(stmt,
            " SELECT nassured              \
                FROM %s:adjustment_ply     \
               WHERE iclaim = ? ",get_full_dbname(sBranch));
         printf("stmt[%s]\n",stmt);
            $PREPARE cid04 FROM $stmt;

            sprintf(stmt,
            " SELECT iins_type             \
                FROM %s:app_ins_type       \
               WHERE iclaim = ? ",get_full_dbname(sBranch));
         printf("stmt[%s]\n",stmt);
            $PREPARE cid05 FROM $stmt;
            $DECLARE cid05_cur CURSOR FOR cid05;
            
            sprintf(stmt,
            " SELECT itel , itag      \
                FROM %s:policy        \
               WHERE ipolicy = ? ",get_full_dbname(sBranch));
         printf("stmt[%s]\n",stmt);
            $PREPARE cid06 FROM $stmt;

           sprintf(stmt,
            " SELECT iclaim,MAX(dclose)                    \
                FROM %s:stl_ins_type                       \
               WHERE fstl = '1'                            \
                 AND flast = '1'                           \
                 AND iins_type IN ('01','05','08','09')    \
                 AND dclose between ? AND ?                \
                 GROUP BY 1 ",get_full_dbname(sBranch));
         printf("stmt[%s]\n",stmt);
         $PREPARE cid01 FROM $stmt;
         $DECLARE st_cur CURSOR FOR cid01;
         $OPEN st_cur USING $cDatebgn,$cDateend;
         for(;;){
         $FETCH st_cur INTO $sIclaim,$sDclose;
         if (SQLCODE == SQLNOTFOUND) break;

             printf("sIclaim[%s]\n",sIclaim);

           $EXECUTE cid02 INTO $lMins_stl USING $sIclaim;
            if (lMins_stl > 50000) continue;

           $EXECUTE cid03
               INTO $sIpolicy,$sNacc_driver,$sDrivertel,
                    $sDaccident,$sIadjuster
              USING $sIclaim;
              if (SQLCODE == SQLNOTFOUND){
                  strcpy(sIpolicy," ");
                  strcpy(sNacc_driver," ");
                  strcpy(sDrivertel," ");
                  strcpy(sDaccident," ");
                  strcpy(sIadjuster," ");
              }

             $EXECUTE cid04
                 INTO $sNassured
                USING $sIclaim;
              if (SQLCODE == SQLNOTFOUND)
                  strcpy(sNassured," ");

               i = 0;
              $OPEN cid05_cur USING $sIclaim;
              for(;;){
               $FETCH cid05_cur INTO $sIins_type;
               if (SQLCODE == SQLNOTFOUND) break;
               i++;

               if (i == 1)
                   strcpy(sInsTmp,sIins_type);
               else{
                   strcat(sInsTmp,sIins_type);
                   /*
                   sprintf(sInsTmp,"%s %s",sInsTmp,rtrim(sIins_type));
                   */
               }
              }
              $CLOSE cid05_cur;

             $EXECUTE cid06
                 INTO $Nassured_tel, $sItag
                USING $sIpolicy;
              if (SQLCODE == SQLNOTFOUND)
              {
                  strcpy(Nassured_tel," ");
                  strcpy(sItag, " ");
              }

          strcpy(sIunit,substring(sIclaim,1,2));

         $INSERT INTO car828_TEMP1
            VALUES ($sIunit, $sIclaim, $sIadjuster, $sIpolicy,
                    $sNassured,$sNacc_driver,$sDrivertel,$sInsTmp,
                    $lMins_stl,$sDaccident,$sDclose,$Nassured_tel,$sItag);

         }
         $CLOSE st_cur;
         $FREE  st_cur;
     }
     $CLOSE s_cur;
     $FREE  s_cur;

     printf("#######car828_p() OK!!!!\n");
     return M_CM_OK;

errexit:
  if (SQLCODE != 0) msg_code = SQLCODE;
  printf("car828_p():SQLCODE=[%ld], sqlerrm=[%s]\n",msg_code, sqlca.sqlerrm);
  return SQLCODE;
}



car828_p2()
{

     $char sBranch[3];
     $char stmt[2048];
     $char sIclaim[21],sIclose_type[2],sIpolicy[21],sIadjuster[11];
     $char sIstl_note[4];
     $char sNassured[121],sIofficer[11];
     $long  lMins_stl;
     $char  sDclose[11],sNacc_driver[21];
     $char  sDrivertel[21],sNassued_tel[21];
     $char  sDaccident[11],sIunit[3];
     $char  sInsTmp[31];
     $char  sIins_type[5], sItag[12];
     int    i;
     $int   iCnt;

     $WHENEVER SQLERROR goto errexit;


     $CREATE TEMP TABLE car828_TEMP2
     (
     iunit       char(3)    default ' ',
     iclaim      char(20)   default ' ',
     iadjuster   char(10)   default ' ',
     ipolicy     char(20)   default ' ',
     nassured    char(120)  default ' ',
     nacc_driver char(20)   default ' ',
     itel        char(20)   default ' ',
     iins_type   char(30)   default ' ',
     mstl        integer    default 0,
     daccident   date       ,
     dclose      date       ,
     nassure_tel char(20)   default ' ',
     itag        char(12)    default ' '
     )WITH NO LOG;

 
     /*** �߮ר��z����B�z ***/
     if (datebgn[0] == '*') strcpy(datebgn, "88/01/01");
     if (dateend[0] == '*') strcpy(dateend, "99/12/31");
     if (dateend[0] == ' ') strcpy(dateend, datebgn);

     strcpy(cDatebgn, cm_to_infdate(datebgn));
     strcpy(cDateend, cm_to_infdate(dateend));

     $DECLARE s_cur2 CURSOR FOR
       SELECT branch
         INTO $sBranch
         FROM servertbl
        WHERE branch <> 'S1';
     $OPEN s_cur2;
     for(;;){
     $FETCH s_cur2;
     if (SQLCODE == SQLNOTFOUND) break;

            sprintf(stmt,
            " SELECT SUM(NVL(mins_stl,0))                  \
                FROM %s:stl_ins_type                       \
               WHERE iclaim = ?                            \
                 AND fstl = '1'                            \
                 AND dclose IS NOT NULL                    \
                 AND iins_type IN (SELECT iins_type        \
                                     FROM %s:stl_ins_type  \
                                    WHERE iclaim = ?       \
                                      AND fstl = '1'       \
                                      AND flast = '1'      \
                                      AND dclose between ? AND ?         \
                                      AND iins_type IN ('93','94','95','32')) ",
                 get_full_dbname(sBranch),get_full_dbname(sBranch));

             printf("stmt[%s]\n",stmt);
            $PREPARE tid02 FROM $stmt;

           sprintf(stmt,
            " SELECT ipolicy,nacc_driver,drivertel,  \
                     DATE(daccident),iadjuster       \
                FROM %s:appraisal                    \
               WHERE iclaim = ? ",get_full_dbname(sBranch));
             printf("stmt[%s]\n",stmt);
            $PREPARE tid03 FROM $stmt;

            sprintf(stmt,
            " SELECT nassured              \
                FROM %s:adjustment_ply     \
               WHERE iclaim = ? ",get_full_dbname(sBranch));
             printf("stmt[%s]\n",stmt);
            $PREPARE tid04 FROM $stmt;

            sprintf(stmt,
            " SELECT iins_type             \
                FROM %s:app_ins_type       \
               WHERE iclaim = ? ",get_full_dbname(sBranch));
             printf("stmt[%s]\n",stmt);
            $PREPARE tid05 FROM $stmt;
            $DECLARE tid05_cur CURSOR FOR tid05;

            sprintf(stmt,
            " SELECT count(*)                                               \
                FROM %s:settlement a,%s:ply_ins_type b,%s:ply_relation c    \
               WHERE a.ipolicy = b.ipolicy                                  \
                 AND b.ipolicy = c.ipolicy                                  \
                 AND c.fedr_class <> '1'                                    \
                 AND a.iclaim = ?                                           \
                 AND b.iins_type IN ('01','05','08','09') ",
                 get_full_dbname(sBranch),get_full_dbname(sBranch),
                 get_full_dbname(sBranch));
             printf("stmt[%s]\n",stmt);
            $PREPARE tid06 FROM $stmt;

            sprintf(stmt,
            " SELECT itel , itag      \
                FROM %s:policy        \
               WHERE ipolicy = ? ",get_full_dbname(sBranch));
             printf("stmt[%s]\n",stmt);
            $PREPARE tid07 FROM $stmt;
            
           sprintf(stmt,
            " SELECT iclaim,MAX(dclose)                                    \
                FROM %s:stl_ins_type                                       \
               WHERE fstl = '1'                                            \
                 AND flast = '1'                                           \
                 AND iins_type IN ('93','94','95','32')                    \
                 AND dclose between ? AND ?                                \
                 GROUP BY 1 ",get_full_dbname(sBranch));
         printf("stmt[%s]\n",stmt);
         $PREPARE tid01 FROM $stmt;
         $DECLARE st_cur2 CURSOR FOR tid01;
         $OPEN st_cur2 USING $cDatebgn,$cDateend;
         for(;;){
         $FETCH st_cur2 INTO $sIclaim,$sDclose;
         if (SQLCODE == SQLNOTFOUND) break;

             printf("sIclaim[%s]\n",sIclaim);


           $EXECUTE tid06 INTO $iCnt USING $sIclaim;
            if (iCnt > 0) continue;

           $EXECUTE tid02
               INTO $lMins_stl
              USING $sIclaim,$sIclaim,$cDatebgn,$cDateend;

           $EXECUTE tid03
               INTO $sIpolicy,$sNacc_driver,$sDrivertel,
                    $sDaccident,$sIadjuster
              USING $sIclaim;
              if (SQLCODE == SQLNOTFOUND){
                  strcpy(sIpolicy," ");
                  strcpy(sNacc_driver," ");
                  strcpy(sDrivertel," ");
                  strcpy(sDaccident," ");
                  strcpy(sIadjuster," ");
              }

             $EXECUTE tid04
                 INTO $sNassured
                USING $sIclaim;
              if (SQLCODE == SQLNOTFOUND)
                  strcpy(sNassured," ");

               i = 0;
              $OPEN tid05_cur USING $sIclaim;
              for(;;){
               $FETCH tid05_cur INTO $sIins_type;
               if (SQLCODE == SQLNOTFOUND) break;
               i++;

               if (i == 1)
                   strcpy(sInsTmp,sIins_type);
               else{
                   strcat(sInsTmp,sIins_type);

                   /*
                   sprintf(sInsTmp,"%s %s",sInsTmp,rtrim(sIins_type));
                   */
               }

              }
              $CLOSE tid05_cur;

              $EXECUTE tid07
                 INTO $sNassued_tel , $sItag
                USING $sIpolicy;
              if (SQLCODE == SQLNOTFOUND)
              {
                  strcpy(sNassued_tel," ");
                  strcpy(sItag, " ");
              }

          strcpy(sIunit,substring(sIclaim,1,2));

         $INSERT INTO car828_TEMP2
            VALUES ($sIunit, $sIclaim, $sIadjuster, $sIpolicy,
                    $sNassured,$sNacc_driver,$sDrivertel,$sInsTmp,
                    $lMins_stl,$sDaccident,$sDclose,$sNassued_tel,
                    $sItag);

         }
         $CLOSE st_cur2;
         $FREE  st_cur2;
     }
     $CLOSE s_cur2;
     $FREE  s_cur2;

     printf("#######car828_p() OK!!!!\n");
     return M_CM_OK;

errexit:
  if (SQLCODE != 0) msg_code = SQLCODE;
  printf("car828_p():SQLCODE=[%ld], sqlerrm=[%s]\n",msg_code, sqlca.sqlerrm);
  return SQLCODE;
}

void car828_title1()
{
   char currdate[20];
   char yy[4], mm[3], dd[3];
   char yy1[4], mm1[3], dd1[3];

   /*** get current_date ***/

   rgu_put_head_string(1, "�����I");
   strcpy(currdate,cm_sysd_cdate_100(cm_get_sysd()));
   cm_split_ymd_100(currdate, yy, mm, dd);

   rgu_put_head_string(1, yy);
   rgu_put_head_string(1, mm);
   rgu_put_head_string(1, dd);

   /*** �߮פ鵲�϶� ***/
   cm_split_ymd_100(datebgn, yy1, mm1, dd1);
   rgu_put_head_string(1, yy1);
   rgu_put_head_string(1, mm1);
   rgu_put_head_string(1, dd1);
   cm_split_ymd_100(dateend, yy1, mm1, dd1);
   rgu_put_head_string(1, yy1);
   rgu_put_head_string(1, mm1);
   rgu_put_head_string(1, dd1);

   rgu_put_head();
}


void car828_title2()
{
   char currdate[20];
   char yy[4], mm[3], dd[3];
   char yy1[4], mm1[3], dd1[3];

   /*** get current_date ***/
   strcpy(currdate,cm_sysd_cdate_100(cm_get_sysd()));
   cm_split_ymd_100(currdate, yy, mm, dd);

   rgu_put_head_string(1, "�N�~�I");
   rgu_put_head_string(1, yy);
   rgu_put_head_string(1, mm);
   rgu_put_head_string(1, dd);

   /*** �߮פ鵲�϶� ***/
   cm_split_ymd_100(datebgn, yy1, mm1, dd1);
   rgu_put_head_string(1, yy1);
   rgu_put_head_string(1, mm1);
   rgu_put_head_string(1, dd1);
   cm_split_ymd_100(dateend, yy1, mm1, dd1);
   rgu_put_head_string(1, yy1);
   rgu_put_head_string(1, mm1);
   rgu_put_head_string(1, dd1);

   rgu_put_head();
}



void car828_body()
{
char Tmp[31];

   rgu_put_body_string(1, trim(r.sNunit), 1);
   rgu_put_body_string(1, trim(r.sIclaim), 1);
   rgu_put_body_string(1, trim(r.sItag), 1);
   rgu_put_body_string(1, trim(r.sNadjuster), 1);
   rgu_put_body_string(1, trim(r.sIpolicy), 1);
   rgu_put_body_string(1, trim(r.sNassured), 1);
   rgu_put_body_string(1, trim(r.sNassured_tel), 1);
   rgu_put_body_string(1, trim(r.sNacc_driver), 1);
   rgu_put_body_string(1, trim(r.sItel), 1);
   rgu_put_body_string(1, rtrim(r.sIins_type), 1);
   rfmtlong(r.lMstl,fmt,Tmp);
   rgu_put_body_string(1, trim(Tmp), 1);
   rgu_put_body_string(1, trim(r.sDaccident), 1);
   rgu_put_body_string(1, trim(r.sDclose), 1);
   rgu_put_body(1);
   max_count++;
}

