/**********************************************************************/
/*   program id   : ca650q01s.ec                                      */
/*   program name : �ɤs������O����                                  */
/*   date written : 2016/03/18 by 041090                              */
/*   files        : ply_relation                                      */
/*                                                                    */
/**********************************************************************/
 
#include <stdio.h>
#include <stdlib.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "api_xsrv.h"
$include decimal;
#include <string.h>
#include "safeclib.h"
char delimiter;
int   count_db,k; 
$char dentry[11];

char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];
$char falldb[2];

int offset;
char   sApHome[50];
FILE   *fp;
static char  *bp;
long   rtncode;


$char dcreate[11],nassured[101],iassured[11],itag[CA_TAG_NUM],nofficer[22],nleader[22];
$char icurrent_state[52],iapproval_status[53],drcv[11],ipolicy[21],iassured_1[12];
$int mprem=0,h_count=0;
$char before_date[11],before_date2[11];
$char mm1[3],dd1[3],yy1[4],mm2[3],dd2[3],yy2[4];
$char dbgn[25],dend[25];
$char stmt[4096];
$char stmt_tmp[2048];
int rc;

DBinfo *list;

main(argc, argv)
int argc;
char **argv;
{

    batchinit();
    strcpy(DBName,    isNULLstr(argv[1]));
    strcpy(userid,    isNULLstr(argv[2]));
    strcpy(dentry,    isNULLstr(argv[3]));
    strcpy(outputf,   isNULLstr(argv[4]));

printf("dentry[%s]\n",dentry);

    rc = car650_get_db();
    if (rc != M_CM_OK)
       return rc;

    rtncode = getApHome(sApHome);
    if (rtncode < 0)
    {
        EWRITE(userid, M_CM_READ_CONFIG_ERR, "read Config file error!!");
        return FAIL;
    }

    rc = ca650_create_temp();
    if (rc != M_CM_OK)
       return rc;

    rc = car650_prepare_data_ALL();
    if (rc != M_CM_OK)
       return rc;

    rc = car650_build();
    if (rc != M_CM_OK)
       return rc;
}

long car650_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
         return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car650_prepare_data_ALL()
{

   $WHENEVER SQLERROR GOTO errexit;
   if (db_select(DBName) == FALSE)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   }
	
   strcpy(dentry,cm_to_infdate(dentry));
   printf("dentry2[%s]\n",dentry);
   cm_edate2_add(dentry, (-1), before_date);
   printf("before_date[%s]\n",before_date);
   
   while(1)
   {
   	printf("before_date[%s]\n",before_date);
	$SELECT count(*)
	  INTO $h_count
	  FROM ca_holiday
	 WHERE holiday_bgn <=  $before_date
	   AND holiday_end >=  $before_date;
	      
        if(h_count==1)
		cm_edate2_add(before_date, (-1), before_date);
	else
		break;
   }

   cm_split_ymd(before_date, mm1, dd1, yy1);
   sprintf_s(dbgn, sizeof dbgn,"%s-%s-%s 00:00:00.000",yy1,mm1,dd1);
   
   /*cm_edate2_add(dentry, (-1), before_date2);*/
   cm_split_ymd(dentry, mm2, dd2, yy2);
   sprintf_s(dend, sizeof dend,"%s-%s-%s 00:00:00.000",yy2,mm2,dd2);
   
   printf("dbgn[%s] dend[%s]\n",dbgn,dend);
        
	sprintf_s(stmt, sizeof stmt,
		"SELECT to_char(a.dcreate,'%%Y/%%m/%%d') AS dcreate, a.nassured, a.iassured, b.itag, a.mprem,  "
		"	trim(a.iofficer)||'/'||(SELECT nname FROM officer WHERE iofficer = a.iofficer) AS nofficer, "
		"	trim(a.ileader)||'/'||(SELECT nname FROM officer WHERE iofficer = a.ileader) AS nleader,  "
		"	a.icurrent_state||'/'||decode(a.icurrent_state,100,'��ƿ�J��','') AS icurrent_state,  "
		"	a.iapproval_status||'/'||decode(a.iapproval_status,500,'�۰ʳ����q�L','') AS iapproval_status,  "
		"	CASE WHEN a.iroute_def_1 = '06' THEN (SELECT max(dgroup) FROM newa00:ao_prercv_detail  "
		"	                                                   WHERE ipre_rcv = a.iquote AND iins_kind = a.iins_kind AND ipre_end = '' )  "
		"	                                ELSE Date('') END AS drcv, "
		"	a.ipolicy  "
        "        FROM newa00:quotation_master a, newa00:ca_quotation b  "
	    "   WHERE a.iquote = b.iquote  "
	    "     AND a.iins_kind_ply = b.iins_kind_ply  "
	    "     AND a.icreate = 'ESUN/SYS'  "
	    "     AND a.dcreate >= '%s'  "
	    "     AND a.dcreate < '%s'   "
	    "     AND a.dsign IS NOT NULL;",dbgn,dend);

	printf("stmt[%s]\n", stmt);

          $PREPARE pre1_1 FROM $stmt;
          $DECLARE cur_pre1_1 CURSOR for pre1_1;
      	  $OPEN cur_pre1_1;

      	while(1)
      	{
         	$FETCH cur_pre1_1 INTO $dcreate,$nassured,$iassured,$itag,$mprem,$nofficer,$nleader,$icurrent_state,$iapproval_status,$drcv,$ipolicy;
         			               			     
         	if(SQLCODE == SQLNOTFOUND) break;
         	
         	strcpy(iassured_1, "�");
      		strcat(iassured_1,trim(iassured));
     
		$INSERT INTO car650_tmp
          		     (dcreate,nassured,iassured,itag,mprem,nofficer,nleader,icurrent_state,iapproval_status,drcv,ipolicy)
		      	VALUES
          		     ($dcreate,$nassured,$iassured_1,$itag,$mprem,$nofficer,$nleader,$icurrent_state,$iapproval_status,$drcv,$ipolicy);
	}
        $CLOSE cur_pre1_1;
        $FREE cur_pre1_1;

     return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/

long car650_build()
{
   int rc;
    char    sfilename[81],stitle[2048],stmt[2048];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"�ɤs������O����[car650]");

    strcpy(stitle,"\t�{���N��:car650\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");

    strcat(stitle,"\t��J���\t�Q�O�I�H\tID\t���P���X\t�O�O\t�g��H��\t�޲z�H��\t�@�~���A\t�������G\t�Ȧ�ú�O��\t�O�渹�X\t");


    strcpy(stmt,"select * from car650_tmp");
    		
	printf("stmt[%s]\n",stmt);
	
    rc = unload_file(outputf," ",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;

}

long ca650_create_temp()
{

   sprintf_s(stmt_tmp, sizeof stmt_tmp,"create temp table car650_tmp  "
	"(  "
	" dcreate char(10), "
	" nassured varchar(100), "
	" iassured char(12),  "
	" itag char(%d), "
	" mprem decimal(12,0), "
	" nofficer char(21), "
	" nleader char(21), "
	" icurrent_state varchar(51), "
	" iapproval_status varchar(52), "
	" drcv date, "
	" ipolicy char(20) "
	")with no log;",CA_TAG_NUM-1);

	printf("stmt_tmp[%s]\n",stmt_tmp);
    $PREPARE stmp FROM $stmt_tmp;
    $EXECUTE stmp;
    
    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}