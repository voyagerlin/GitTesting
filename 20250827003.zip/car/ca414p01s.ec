/************************************************/
/*   �M�׷~�ȳ�O�ѵs���[�I�@�~(�R��11�I��)     */
/*           11:TOBE�M��                        */
/*           19:50�ǩ_                          */
/*   PROGRAM : ca414p01s.ec  BY jessie          */
/*   DATE    : 2002/06/11                       */
/*   Modify  : yyyy/mm/dd                       */
/************************************************/
#include <stdio.h>
#include <stdlib.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "car_equip.h"
#include "globdata.h"
$include sqlca;
$include "safeclib.h";

/*--------------------------------------------------------------------*/
DBinfo  *list;
int     i,count_db;

$char   DBName[05];
char    userid[11],outputf[21];
char    opt_ply[2];
char    opt_num[2];
$char   ipolicy[21];
$char   ipolicy_end[21];
$char   iengine[CA_ENGINE_NUM];

char    msgbuf[262144];

char    msgbuf_del[131072];   /* �w�R������ */
char    msgbuf_fail[131072];  /* ���ѩ���   */
char    tmpbuf1[131072];
char    tmpbuf2[131072];

long    del_count;            /* �w�R������ */
long    fail_count;           /* ���ѵ���   */
long    total_count;          /* ���R������ */

$char   dpolicy[11],dply_close[11],iofficer[11];
$char   dendorse[11],dedr_close[11];
$char   ipolicy_cur[21];
$char   iengine_cur[CA_ENGINE_NUM];
$char   nequipment[31];

$char   iply_w[21];           /* B���ˮ� */
$char   sFullName[20];

$char   stmt[4096];
$long   mprem=0,mpure_prem=0,magent=0,mcommission=0,mdiscount=0;
$char   ipolicy_m[21];
$char   iendorse[21];
$long   medr_prem=0,medr_pure=0,medr_agent=0,medr_commission=0,medr_discount=0;


/*--------------------------------------------------------------------*/
int          IsBlankNull();
main(argc,argv)
int   argc;
char  **argv;
{
   int   rc;

   batchinit();

   strcpy(DBName,      isNULLstr(argv[1]));
   strcpy(userid,      isNULLstr(argv[2]));
   strcpy(opt_ply,     isNULLstr(argv[3]));
   strcpy(opt_num,     isNULLstr(argv[4]));
   strcpy(ipolicy,     isNULLstr(argv[5]));
   strcpy(ipolicy_end, isNULLstr(argv[6]));
   strcpy(iengine,     isNULLstr(argv[7]));
   strcpy(outputf,     isNULLstr(argv[8]));

   rc = car414_get_db();
   if (rc != M_CM_OK)
   {
       EWRITE(userid , rc , msgbuf);
       return rc;
   }

   total_count = 0;
   del_count   = 0;
   fail_count  = 0;

   msgbuf[0]      = '\0';
   msgbuf_del[0]  = '\0';
   msgbuf_fail[0] = '\0';
   tmpbuf1[0]     = '\0';
   tmpbuf2[0]     = '\0';

   strcpy(ipolicy,     trim(ipolicy));
   strcpy(ipolicy_end, trim(ipolicy_end));
   strcpy(iengine,     rtrim(iengine)); /* iengine�����i�঳�Ů�,���i��trim */

   if (strncmp(opt_num,"1",1)==0) /* �浧 */
   {
       strcpy(ipolicy_end, ipolicy);
   }

   /* �O��Χ��O */
   if ((strncmp(opt_ply,"1",1)==0))
   {
       /* ���R������ */
       total_count =  atoi(ipolicy_end+7) - atoi(ipolicy+7) + 1;

       rc = car414_read_ply();
       if (rc != M_CM_OK)
       {
          EWRITE(userid , rc , msgbuf);
          return rc;
       }
   }
   else
   {
       /* ���R������ */
       total_count =  atoi(ipolicy_end+8) - atoi(ipolicy+8) + 1;

       rc = car414_read_edr();
       if (rc != M_CM_OK)
       {
          EWRITE(userid , rc , msgbuf);
          return rc;
       }
   }

   return rc;
}

/*--------------------------------------------------------------------*/
long car414_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car414_read_ply()
{
   int   rc,chk_prmt;
   $int  relcnt;
   $char iremark[4];
   int   count_num;

   count_num = 0;

   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

   $BEGIN WORK;

   sprintf_s(stmt, sizeof stmt,"SELECT %s %s FROM %s %s WHERE %s %s ",
                " a.ipolicy, NVL(a.dpolicy,' '), NVL(a.dply_close,' '), a.iofficer, ",
                " nequipment, iengine ",
                " ply_relation a ,",
                " policy b ",
                "     a.ipolicy BETWEEN ? AND ? ",
                " AND a.ipolicy = b.ipolicy ");
   $PREPARE pre_ply_tmp1 FROM $stmt;
   $DECLARE cur_ply_1    CURSOR WITH HOLD FOR pre_ply_tmp1;
   $OPEN    cur_ply_1    USING  $ipolicy, $ipolicy_end;
   while(1)
   {
        $FETCH cur_ply_1 INTO $ipolicy_cur, $dpolicy, $dply_close, $iofficer,
                              $nequipment, $iengine_cur;

        /* �浧�R���d�L��Ʈ� */
        if ((SQLCODE == SQLNOTFOUND) && (strncmp(opt_num,"1",1)==0) && (count_num == 0))
        {
             fail_count ++;
             sprintf_s(msgbuf, sizeof msgbuf,"�O��[%s]��Ƨ䤣��\n",ipolicy);
             goto errexit;
        }

        if (SQLCODE == SQLNOTFOUND) break;

        strcpy(ipolicy_cur, trim(ipolicy_cur));
        strcpy(iengine_cur, rtrim(iengine_cur)); /* iengine_cur�����i�঳�Ů�,���i��trim */
        strcpy(iofficer,    trim(iofficer));

        /* �浧�R���ɤ������X���@�P */
        if (strncmp(opt_num,"1",1)==0)
        {
             if (strcmp(iengine_cur, iengine) != 0)
             {
                 SQLCODE = 100;
                 fail_count ++;
                 sprintf_s(msgbuf, sizeof msgbuf,"�O��[%s]�������X[%s]�P��J���������X[%s]����\n",ipolicy_cur,iengine_cur,iengine);
                 goto errexit;
             }
        }

        /* �����O�M�׷~�Ȥ��o�R�� */
        /* �¦��g�k 
        if ((equip_cmp(nequipment,"11") == FALSE) &&
            (equip_cmp(nequipment,"19") == FALSE) &&
            (equip_cmp(nequipment,"21") == FALSE) &&
            (equip_cmp(nequipment,"22") == FALSE) &&
            (equip_cmp(nequipment,"25") == FALSE) &&
            (equip_cmp(nequipment,"26") == FALSE) &&
            (equip_cmp(nequipment,"28") == FALSE) &&
            (equip_cmp(nequipment,"29") == FALSE) &&
            (equip_cmp(nequipment,"31") == FALSE) &&
            (equip_cmp(nequipment,"33") == FALSE) &&
            (equip_cmp(nequipment,"34") == FALSE) &&
            (equip_cmp(nequipment,"35") == FALSE) &&
            (equip_cmp(nequipment,"36") == FALSE) &&
            (equip_cmp(nequipment,"43") == FALSE) &&
            (equip_cmp(nequipment,"45") == FALSE) &&
            (equip_cmp(nequipment,"39") == FALSE) && 
            (equip_cmp(nequipment,"59") == FALSE) && 
            (equip_cmp(nequipment,"54") == FALSE) &&
            (equip_cmp(nequipment,"62") == FALSE))
        {
             fail_count ++;
             sprintf_s(msgbuf_fail, sizeof msgbuf_fail,"     �O��[%s]�D���M�׷~�ȡA���i�R��\n",ipolicy_cur);
             strcat(tmpbuf1, msgbuf_fail);

             if (strncmp(opt_num,"1",1)==0)
             {
                 SQLCODE = 100;
                 strcpy(msgbuf, msgbuf_fail);
                 goto errexit;
             }
             continue;
        } */
        /* �s���g�k Modified by Julia Han in 2007/06/22 
        	$DECLARE cur_prmt CURSOR FOR
     		  SELECT distinct iremark
             FROM ca_promote
            WHERE iins_type like '%11%';*/

        /*1130510009_C02 �s�W�q�ʨ��M�ݰӫ~(0701�W�u)
          �s�W 211 �I,�ç�gSQL�P�_�覡�A�קK��L�I�إN�����t��'11'���r���ɳQ�~�P�� 11
          (ex. 111,112,11*,*11...��) */
        $DECLARE cur_prmt CURSOR FOR    
          SELECT distinct iremark
            FROM ca_promote
           WHERE (regex_match(iins_type, '(,| +|^)11(,| +|$)') OR 
                  regex_match(iins_type, '(,| +|^)211(,| +|$)'));

   		$OPEN cur_prmt;
   		chk_prmt=0;
   		while(1) {
       		$FETCH cur_prmt INTO $iremark;
       		if (SQLCODE==SQLNOTFOUND) break;

       		if (equip_cmp(nequipment,iremark) == TRUE) {
           		chk_prmt=1; 
           		break;
       		}
   		}
   		$CLOSE cur_prmt;
   		$FREE  cur_prmt;

   	/* �����O�M�׷~�Ȥ��o�R�� */
   		if (chk_prmt==0)
   		{
        		
             fail_count ++;
             sprintf_s(msgbuf_fail, sizeof msgbuf_fail,"     �O��[%s]�D���M�׷~�ȡA���i�R��\n",ipolicy_cur);
             strcat(tmpbuf1, msgbuf_fail);

             if (strncmp(opt_num,"1",1)==0)
             {
                 SQLCODE = 100;
                 strcpy(msgbuf, msgbuf_fail);
                 goto errexit;
             }
             continue;
   		}
   	  /* End of Modified by Julia */

        /* �O��w�鵲,���o�R�� */
        if (dply_close[1] != ' ')
        {
             fail_count ++;
             sprintf_s(msgbuf_fail, sizeof msgbuf_fail,"     �O��[%s]�w�鵲[%s]�A���i�R��\n",ipolicy_cur,dply_close);
             strcat(tmpbuf1, msgbuf_fail);

             if (strncmp(opt_num,"1",1)==0)
             {
                 SQLCODE = 100;
                 strcpy(msgbuf, msgbuf_fail);
                 goto errexit;
             }
             continue;
        }

        $SELECT mins_premium , mpure_prem , magent , mcommission , mdiscount
           INTO $mprem , $mpure_prem , $magent , $mcommission , $mdiscount
           FROM ply_ins_type
          WHERE ipolicy   = $ipolicy_cur
            AND iins_type in ('11','211');
        if (SQLCODE == SQLNOTFOUND)
        {
             fail_count ++;
             sprintf_s(msgbuf_fail, sizeof msgbuf_fail,"     �O��[%s]�L11�I��\n",ipolicy_cur);
             strcat(tmpbuf1, msgbuf_fail);

             if (strncmp(opt_num,"1",1)==0)
             {
                 strcpy(msgbuf, msgbuf_fail);
                 goto errexit;
             }
             continue;
        }

        relcnt = 0;

        $DECLARE ser_cur CURSOR FOR
          SELECT ipolicy
            FROM assured_vs_ply
           WHERE iengine     = $iengine_cur
             AND fcard_class = '2';
             /* Modified by Juli Han in 2007/06/21 */
             /*AND icard[6,7]  = 'CC';*/
        $OPEN ser_cur;
        for(;;)
        {
             $FETCH ser_cur INTO $iply_w;

             if (SQLCODE == SQLNOTFOUND) break;

             strcpy(sFullName, get_car_full_db(iply_w));
             
printf("iply_w[%s],ipolicy_m[%s],\n",iply_w,ipolicy_cur);                     

             /* A���B����w�O��ͮĴ����t�Z���W�L�|�Ӥ�A�H�קK���P�~�פ��O��P�ɭp�J */
             /* �s�W�M�ץ�P�_:H�g��B������H0-H2  modify by sylvia 103.01.17 (1021122001_C1)*/
             sprintf_s(stmt, sizeof stmt, "SELECT %s FROM %s:%s %s %s:%s WHERE %s %s %s %s %s %s %s %s %s %s %s %s",
                           " {+ INDEX (a ca_plyrel_ix_2) } count(*) ",
                           sFullName, " ply_relation a , ",
                           " ply_relation b, ",
                           sFullName, " ply_ins_type c ",
                           "     a.ipolicy = ? ",
                           " AND b.ipolicy = ? ",
                           " AND (a.iofficer[1] = 'W' OR a.iofficer[1] = 'N' ",
                           "  OR (a.iofficer[1,1] = 'H' and a.iofficer[1,2] not in ('H0','H1','H2')) ",
                           "  OR a.iofficer[1,3] = 'F98' ",
                           "  OR a.iofficer[1,3] = 'G98' ",
                           "  OR a.iofficer in ('P13011D','P13028D') ", 
                           "  OR b.iofficer in ('P13011','P13028')) ",
                           " AND a.dply_close IS NOT NULL ",
                           " AND a.ipolicy = c.ipolicy ",
                           " AND c.iins_type in ('11','211') ",
                           " AND c.mdamage_cover != 0 ",
                           " AND ABS(((YEAR(a.dply_begin)-1911)*12+MONTH(a.dply_begin)) - ((YEAR(b.dply_begin)-1911)*12+MONTH(b.dply_begin))) <= 4 ");
printf("stmt[%s]\n",stmt);

             $PREPARE be1 FROM $stmt;
             $EXECUTE be1 INTO $relcnt USING $iply_w, $ipolicy_cur;

             if (relcnt > 0) break;
        }
        $CLOSE ser_cur;
        $FREE  ser_cur;

printf("what's relcnt??[%d] \n",relcnt);

        if (relcnt == 0)
        {
             if (car414_chk_next(ipolicy_cur,nequipment) != TRUE)
             {
                fail_count ++;
                sprintf_s(msgbuf_fail, sizeof msgbuf_fail,"�O��[%s]���M�׫O��[B��]�|���X��\n",ipolicy_cur);
                strcat(tmpbuf1, msgbuf_fail);

                if (strncmp(opt_num,"1",1)==0)
                {
                    SQLCODE = 100;
                    strcpy(msgbuf, msgbuf_fail);
                    goto errexit;
                }
                continue;
             }
        }

        relcnt = 0;
        $SELECT count(*)
           INTO $relcnt
           FROM ply_ins_type a , insurance_type b
          WHERE a.ipolicy   = $ipolicy_cur
            AND a.iins_type = b.iins_type
            AND a.iins_type not in ('11','211')
            AND b.imain_ins in ('11','211');
        if (relcnt == 0)
        {
             fail_count ++;
             strcpy(msgbuf_fail,"     �O��[%s]�L11�I�ؤ����[�I�A���i�R��11�I��\n", ipolicy_cur);
             strcat(tmpbuf1, msgbuf_fail);
             if (strncmp(opt_num,"1",1)==0)
             {
                 SQLCODE = 100;
                 strcpy(msgbuf, msgbuf_fail);
                 goto errexit;
             }
             continue;
        }

        /* Begin UPDATE and DELETE Data for iins_type == '11' */
        $UPDATE ply_relation
            SET mdmg_prem      = mdmg_prem      - $mprem,
                mdmg_pure_prem = mdmg_pure_prem - $mpure_prem,
                mdmg_agent     = mdmg_agent     - $magent,
                mdmg_commi     = mdmg_commi     - $mcommission,
                mdmg_discount  = mdmg_discount  - $mdiscount
          WHERE ipolicy = $ipolicy_cur;
        if (sqlca.sqlerrd[2] != 1)
        {
             fail_count ++;
             strcpy(msgbuf_fail,"     �O��[%s]�L�O�����p�ɸ��\n",ipolicy_cur);
             strcat(tmpbuf1, msgbuf_fail);

             if (strncmp(opt_num,"1",1)==0)
             {
                 SQLCODE = 100;
                 strcpy(msgbuf, msgbuf_fail);
                 goto errexit;
             }
             continue;
        }

        $DELETE FROM ply_ins_type
          WHERE ipolicy   = $ipolicy_cur
            AND iins_type in ('11','211');
        if (sqlca.sqlerrd[2] != 1)
        {
             fail_count ++;
             strcpy(msgbuf_fail,"     �O��[%s]�L�����ɸ��\n",ipolicy_cur);
             strcat(tmpbuf1, msgbuf_fail);

             if (strncmp(opt_num,"1",1)==0)
             {
                 SQLCODE = 100;
                 strcpy(msgbuf, msgbuf_fail);
                 goto errexit;
             }

             $ROLLBACK WORK;
             $BEGIN    WORK;
             continue;
        }

        del_count ++;
        sprintf_s(msgbuf_del, sizeof msgbuf_del,"     �O��[%s]�w�R���ѵs�I�A�O�O�@[%d]��\n",ipolicy_cur,mprem);
        strcat(tmpbuf2, msgbuf_del);
        count_num ++;

        $COMMIT WORK;
        $BEGIN  WORK;
        printf("1���R������[%ld],�w�R������[%ld],���ѵ���[%ld]\n", total_count, del_count, fail_count);
   }
   printf("2���R������[%ld],�w�R������[%ld],���ѵ���[%ld]\n", total_count, del_count, fail_count);
   $CLOSE cur_ply_1;
   $FREE  cur_ply_1;

   $COMMIT WORK;

   printf("3���R������[%ld],�w�R������[%ld],���ѵ���[%ld]\n", total_count, del_count, fail_count);

   sprintf_s(msgbuf, sizeof msgbuf, "\n�����R������[%ld]\n���w�R������[%ld]\n�����ѵ���[%ld]\n",total_count, del_count, fail_count);
   strcat(msgbuf , "\n\n�w�R���O����ӡG\n");
   strcat(msgbuf , tmpbuf2);
   strcat(msgbuf , "\n\n���ѩ��ӡG\n");
   strcat(msgbuf , tmpbuf1);

   printf("msgbuf[%s]\n",msgbuf);

   EWRITE(userid , M_CM_OK , msgbuf);
   return M_CM_OK;

errexit:
   rc = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   sqlfatal();
   return rc;
}

/*--------------------------------------------------------------------*/
long car414_read_edr()
{
   int    rc,chk_prmt;
   $int   relcnt, iCount;
   int    count_num;
   $char iremark[4];
   $char fcard_class[2], dlock[31];

   count_num = 0;

   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

   $BEGIN WORK;
   
   sprintf_s(stmt, sizeof stmt,"SELECT %s %s FROM %s %s WHERE %s %s ",
                " a.iendorse, NVL(a.dendorse,' '), NVL(a.dedr_close,' '), a.ipolicy, a.iofficer, ",
                " b.nequipment, b.iengine, a.fcard_class, a.dlock ",
                " edr_relation a ,",
                " endorsement b ",
                "     a.iendorse BETWEEN ? AND ? ",
                " AND a.iendorse = b.iendorse ");
   $PREPARE pre_edr_tmp1 FROM $stmt;
   $DECLARE cur_edr_1    CURSOR WITH HOLD FOR pre_edr_tmp1;
   $OPEN    cur_edr_1    USING  $ipolicy, $ipolicy_end;
   while(1)
   {
        $FETCH cur_edr_1 INTO $iendorse, $dendorse, $dedr_close, $ipolicy_m, $iofficer,
                              $nequipment, $iengine_cur, $fcard_class, $dlock;

        /* �浧�R���d�L��Ʈ� */
        if ((SQLCODE == SQLNOTFOUND) && (strncmp(opt_num,"1",1)==0) && (count_num == 0))
        {
             fail_count ++;
             sprintf_s(msgbuf, sizeof msgbuf,"���[%s]��Ƨ䤣��\n",ipolicy);
             goto errexit;
        }

        if (SQLCODE == SQLNOTFOUND) break;

        strcpy(iendorse,    trim(iendorse));
        strcpy(iengine_cur, trim(iengine_cur));
        strcpy(ipolicy_m,   trim(ipolicy_m));
        strcpy(iofficer,    trim(iofficer));

        /* �浧�R���ɤ������X���@�P */
        if (strncmp(opt_num,"1",1)==0)
        {
             if (strcmp(iengine_cur, iengine) != 0)
             {
                 SQLCODE = 100;
                 fail_count ++;
                 sprintf_s(msgbuf, sizeof msgbuf,"���[%s]�������X[%s]�P��J���������X[%s]����\n",iendorse,iengine_cur,iengine);
                 goto errexit;
             }
        }

        /* �����O�M�׷~�Ȥ��o�R�� */
        /* �¦��g�k
        if ((equip_cmp(nequipment,"11") == FALSE) &&
            (equip_cmp(nequipment,"19") == FALSE) &&
            (equip_cmp(nequipment,"21") == FALSE) &&
            (equip_cmp(nequipment,"22") == FALSE) &&
            (equip_cmp(nequipment,"25") == FALSE) &&
            (equip_cmp(nequipment,"26") == FALSE) &&
            (equip_cmp(nequipment,"28") == FALSE) &&
            (equip_cmp(nequipment,"29") == FALSE) &&
            (equip_cmp(nequipment,"31") == FALSE) &&
            (equip_cmp(nequipment,"33") == FALSE) &&
            (equip_cmp(nequipment,"34") == FALSE) &&
            (equip_cmp(nequipment,"35") == FALSE) &&
            (equip_cmp(nequipment,"36") == FALSE) &&
            (equip_cmp(nequipment,"43") == FALSE) &&
            (equip_cmp(nequipment,"45") == FALSE) &&
            (equip_cmp(nequipment,"39") == FALSE) &&
            (equip_cmp(nequipment,"59") == FALSE) && 
            (equip_cmp(nequipment,"54") == FALSE) &&
            (equip_cmp(nequipment,"62") == FALSE))
        {
             fail_count ++;
             sprintf_s(msgbuf_fail, sizeof msgbuf_fail,"     ���[%s]�D���M�׷~�ȡA���i�R��\n",iendorse);
             strcat(tmpbuf1, msgbuf_fail);

             if (strncmp(opt_num,"1",1)==0)
             {
                 SQLCODE = 100;
                 strcpy(msgbuf, msgbuf_fail);
                 goto errexit;
             }
             continue;
        } */
        /* �s���g�k Modified by Julia Han in 2007/06/22 
        	$DECLARE cur_prmt1 CURSOR FOR
     		  SELECT distinct iremark
             FROM ca_promote
            WHERE iins_type like '%11%';*/

        /*1130510009_C02 �s�W�q�ʨ��M�ݰӫ~(0701�W�u)
          �s�W 211 �I,�ç�gSQL�P�_�覡�A�קK��L�I�إN�����t��'11'���r���ɳQ�~�P�� 11
          (ex. 111,112,11*,*11...��) */
        $DECLARE cur_prmt1 CURSOR FOR    
          SELECT distinct iremark
            FROM ca_promote
           WHERE (regex_match(iins_type, '(,| +|^)11(,| +|$)') OR 
                  regex_match(iins_type, '(,| +|^)211(,| +|$)'));
   		$OPEN cur_prmt1;
   		chk_prmt=0;
   		while(1) {
       		$FETCH cur_prmt1 INTO $iremark;
       		if (SQLCODE==SQLNOTFOUND) break;

       		if (equip_cmp(nequipment,iremark) == TRUE) {
           		chk_prmt=1; 
           		break;
       		}
   		}
   		$CLOSE cur_prmt1;
   		$FREE  cur_prmt1;

   	  /* �����O�M�׷~�Ȥ��o�R�� */
   		if (chk_prmt==0)
   		{
        		fail_count ++;
             sprintf_s(msgbuf_fail, sizeof msgbuf_fail,"     ���[%s]�D���M�׷~�ȡA���i�R��\n",iendorse);
             strcat(tmpbuf1, msgbuf_fail);

             if (strncmp(opt_num,"1",1)==0)
             {
                 SQLCODE = 100;
                 strcpy(msgbuf, msgbuf_fail);
                 goto errexit;
             }
             continue;
   		}
   		/* End of Modified by Julia */
printf("what's endorse[%s]\n",iendorse);   		

        /* ���w�鵲,���o�R�� */
        if (dedr_close[1] != ' ')
        {
             fail_count ++;
             sprintf_s(msgbuf_fail, sizeof msgbuf_fail,"     ���[%s]�w�鵲[%s]�A���i�R��\n",iendorse,dedr_close);
             strcat(tmpbuf1, msgbuf_fail);

             if (strncmp(opt_num,"1",1)==0)
             {
                 SQLCODE = 100;
                 strcpy(msgbuf, msgbuf_fail);
                 goto errexit;
             }
             continue;
        }

           /* 1020111001_C2 ���O�X����@�~ */
           $SELECT COUNT(*)
              INTO $iCount
              FROM cm_pre_receive
             WHERE ipre_rcv = $iendorse
               AND iins_kind = $fcard_class
               AND ipre_end = ' '
               AND (fstatus != '10' OR dprint_rcv IS NOT NULL);
           if( iCount != 0)   /* �w�C�Lú�O���,���o�R����� */
           {
               fail_count ++;
               sprintf_s(msgbuf_fail, sizeof msgbuf_fail,"     ���[%s]�w�C�Lú�O��A���i�R��\n",iendorse);
               strcat(tmpbuf1, msgbuf_fail);
  
               if (strncmp(opt_num,"1",1)==0)
               {
                   SQLCODE = 100;
                   strcpy(msgbuf, msgbuf_fail);
                   goto errexit;
               }
               continue;
           }

           $SELECT COUNT(*)
              INTO $iCount
              FROM sysdb:cm_tmp_receipt
             WHERE ipre_rcv = $iendorse
               AND dprint IS NOT NULL;
           if( iCount != 0)   /* �w�C�L�w���O�O�ҩ�,���o�R����� */
           {
               fail_count ++;
               sprintf_s(msgbuf_fail, sizeof msgbuf_fail,"     ���[%s]�w�C�L�w���O�O�ҩ��A���i�R��\n",iendorse);
               strcat(tmpbuf1, msgbuf_fail);
  
               if (strncmp(opt_num,"1",1)==0)
               {
                   SQLCODE = 100;
                   strcpy(msgbuf, msgbuf_fail);
                   goto errexit;
               }
               continue;
           }

           if( strlen(trim(dlock)) != 0 ) /* B2B����鵲�ɶ�����A���饼ú�O����椣�i�R�� */
           {
               fail_count ++;
               sprintf_s(msgbuf_fail, sizeof msgbuf_fail,"     ���[%s]�w��^B2B�A���i�R��\n",iendorse);
               strcat(tmpbuf1, msgbuf_fail);
  
               if (strncmp(opt_num,"1",1)==0)
               {
                   SQLCODE = 100;
                   strcpy(msgbuf, msgbuf_fail);
                   goto errexit;
               }
               continue;
           }


        $SELECT medrins_prem,medrpure_prem,medr_agent,medr_commission,medr_discount
           INTO $medr_prem,$medr_pure,$medr_agent,$medr_commission,$medr_discount
           FROM edr_ins_type
          WHERE iendorse  = $iendorse
            AND iins_type in ('11','211');

        if (SQLCODE==SQLNOTFOUND)
        {
             fail_count ++;
             sprintf_s(msgbuf_fail, sizeof msgbuf_fail,"     ���[%s]�L11�I��\n",iendorse);
             strcat(tmpbuf1, msgbuf_fail);

             if (strncmp(opt_num,"1",1)==0)
             {
                 strcpy(msgbuf, msgbuf_fail);
                 goto errexit;
             }
             continue;
        }

        relcnt = 0;
        $DECLARE ser_cur1 CURSOR FOR
          SELECT ipolicy
            INTO $iply_w
            FROM assured_vs_ply
           WHERE iengine     = $iengine_cur
             AND fcard_class = '2';
             /* Modified by Julia in 2007/06/21 */
             /* AND icard[6,7]  = 'CC';*/
        $OPEN ser_cur1;
        for(;;)
        {
             $FETCH ser_cur1 INTO $iply_w;
printf("ipolicy[%s],iengine[%s],ipolicy_m[%s]\n",iply_w,iengine_cur,ipolicy_m);             

             if (SQLCODE == SQLNOTFOUND) break;

             strcpy(sFullName, get_car_full_db(iply_w));                  

             /* A���B����w�O��ͮĴ����t�Z���W�L�|�Ӥ�A�H�קK���P�~�פ��O��P�ɭp�J */
             sprintf_s(stmt, sizeof stmt, "SELECT %s FROM %s:%s %s %s:%s WHERE %s %s %s %s %s %s %s %s %s %s %s %s",
                           " {+ INDEX (a ca_plyrel_ix_2) } count(*) ",
                           sFullName,
                           " ply_relation a , ",
                           " ply_relation b , ",
                           sFullName, " ply_ins_type c ",
                           "     a.ipolicy = ? ",
                           " AND b.ipolicy = ? ",
                           " AND (a.iofficer[1] = 'W' OR a.iofficer[1] = 'N' ",
                           "  OR (a.iofficer[1,1] = 'H' and a.iofficer[1,2] not in ('H0','H1','H2')) ",
                           "  OR a.iofficer[1,3] ='F98' ", 
                           "  OR a.iofficer[1,3] ='G98' ", 
                           "  OR a.iofficer in ('P13011D','P13028D') ", 
                           "  OR b.iofficer in ('P13011','P13028')) ",
                           " AND a.dply_close IS NOT NULL ",
                           " AND a.ipolicy = c.ipolicy ",
                           " AND c.iins_type in ('11','211') ",
                           " AND c.mdamage_cover != 0 ",
                           " AND ABS(((YEAR(a.dply_begin)-1911)*12+MONTH(a.dply_begin)) - ((YEAR(b.dply_begin)-1911)*12+MONTH(b.dply_begin))) <= 4 ");
printf("stmt[%s]\n",stmt);
             $PREPARE be2 FROM $stmt;
             $EXECUTE be2 INTO $relcnt USING $iply_w, $ipolicy_m;

             if (relcnt > 0) break;
        }
        $CLOSE ser_cur1;
        $FREE  ser_cur1;        

        if (relcnt == 0)
        {
             if (car414_chk_next(ipolicy_m,nequipment) != TRUE)
             {
                fail_count ++;
                sprintf_s(msgbuf_fail, sizeof msgbuf_fail,"���[%s]���M�׫O��[B��]�|���X��\n",iendorse);
                strcat(tmpbuf1, msgbuf_fail);

                if (strncmp(opt_num,"1",1)==0)
                {
                    SQLCODE = 100;
                    strcpy(msgbuf, msgbuf_fail);
                    goto errexit;
                }
                continue;
             }
        }

        relcnt = 0;

        $SELECT mins_premium , mpure_prem , magent , mcommission , mdiscount
           INTO $mprem , $mpure_prem , $magent , $mcommission , $mdiscount
           FROM ply_ins_type
          WHERE ipolicy   = $ipolicy_m
            AND iins_type in ('11','211');

        if (SQLCODE==SQLNOTFOUND)
        {
             fail_count ++;
             strcpy(msgbuf_fail,"     ���[%s]��[%s]�̷s�O���I���ɵL11�I��\n", iendorse,ipolicy_m);
             strcat(tmpbuf1, msgbuf_fail);
             if (strncmp(opt_num,"1",1)==0)
             {
                 SQLCODE = 100;
                 strcpy(msgbuf, msgbuf_fail);
                 goto errexit;
             }
             continue;
        }

        if ((mprem       != medr_prem)       ||
            (mpure_prem  != medr_pure)       ||
            (magent      != medr_agent)      ||
            (mcommission != medr_commission) ||
            (mdiscount   != medr_discount))
        {
             fail_count ++;
             strcpy(msgbuf_fail,"     ���[%s]���O��[%s]�w��11�I��,���i�R�������\n", iendorse,ipolicy_m);
             strcat(tmpbuf1, msgbuf_fail);
             if (strncmp(opt_num,"1",1)==0)
             {
                 SQLCODE = 100;
                 strcpy(msgbuf, msgbuf_fail);
                 goto errexit;
             }
             continue;
        }

        /* Begin UPDATE and DELETE Data for iins_type == '11' */
        $UPDATE ply_relation
            SET mdmg_prem      = mdmg_prem      - $mprem,
                mdmg_pure_prem = mdmg_pure_prem - $mpure_prem,
                mdmg_agent     = mdmg_agent     - $magent,
                mdmg_commi     = mdmg_commi     - $mcommission,
                mdmg_discount  = mdmg_discount  - $mdiscount
          WHERE ipolicy = $ipolicy_m;
        if (sqlca.sqlerrd[2] != 1)
        {
             fail_count ++;
             strcpy(msgbuf_fail,"     ���[%s]�L[%s]�O�����p�ɸ��\n",iendorse,ipolicy_m);
             strcat(tmpbuf1, msgbuf_fail);

             if (strncmp(opt_num,"1",1)==0)
             {
                 SQLCODE = 100;
                 strcpy(msgbuf, msgbuf_fail);
                 goto errexit;
             }
             continue;
        }

        $DELETE FROM ply_ins_type
          WHERE ipolicy   = $ipolicy_m
            AND iins_type in ('11','211');
        if (sqlca.sqlerrd[2] != 1)
        {
             fail_count ++;
             strcpy(msgbuf_fail,"     ���[%s]�L[%s]�O������ɸ��\n",iendorse,ipolicy_m);
             strcat(tmpbuf1, msgbuf_fail);

             if (strncmp(opt_num,"1",1)==0)
             {
                 SQLCODE = 100;
                 strcpy(msgbuf, msgbuf_fail);
                 goto errexit;
             }

             $ROLLBACK WORK;
             $BEGIN    WORK;
             continue;
        }

        $UPDATE edr_relation
            SET medrdmg_prem      = medrdmg_prem      - $mprem,
                medrdmg_pure_prem = medrdmg_pure_prem - $mpure_prem,
                medrdmg_agent     = medrdmg_agent     - $magent,
                medrdmg_commi     = medrdmg_commi     - $mcommission,
                medrdmg_disc      = medrdmg_disc      - $mdiscount
          WHERE iendorse = $iendorse;
        if (sqlca.sqlerrd[2] != 1)
        {
             fail_count ++;
             strcpy(msgbuf_fail,"     ���[%s]�L������p�ɸ��\n",iendorse);
             strcat(tmpbuf1, msgbuf_fail);

             if (strncmp(opt_num,"1",1)==0)
             {
                 SQLCODE = 100;
                 strcpy(msgbuf, msgbuf_fail);
                 goto errexit;
             }

             $ROLLBACK WORK;
             $BEGIN    WORK;
             continue;
        }

        $DELETE FROM edr_ins_type
          WHERE iendorse  = $iendorse
            AND iins_type in ('11','211');
        if (sqlca.sqlerrd[2] != 1)
        {
             fail_count ++;
             strcpy(msgbuf_fail,"     ���[%s]�L�������ɸ��\n",iendorse);
             strcat(tmpbuf1, msgbuf_fail);

             if (strncmp(opt_num,"1",1)==0)
             {
                 SQLCODE = 100;
                 strcpy(msgbuf, msgbuf_fail);
                 goto errexit;
             }

             $ROLLBACK WORK;
             $BEGIN    WORK;
             continue;
        }

        $UPDATE cm_pre_receive
            SET mprem = mprem - $mprem
          WHERE ipre_rcv = $iendorse
            AND iins_kind = $fcard_class
            AND ipre_end = ' ' ;

        if (sqlca.sqlerrd[2] != 1)
        {
             fail_count ++;
             strcpy(msgbuf_fail,"     ���[%s]�L�@�γ������ɸ��\n",iendorse);
             strcat(tmpbuf1, msgbuf_fail);

             if (strncmp(opt_num,"1",1)==0)
             {
                 SQLCODE = 100;
                 strcpy(msgbuf, msgbuf_fail);
                 goto errexit;
             }

             $ROLLBACK WORK;
             $BEGIN    WORK;
             continue;
        }
        $DELETE FROM cm_pre_receive
          WHERE ipre_rcv = $iendorse
            AND iins_kind = $fcard_class
            AND ipre_end = ' ' 
            AND mprem = 0;

        del_count ++;
        sprintf_s(msgbuf_del, sizeof msgbuf_del,"     ���[%s]�w�R���ѵs�I�A�O�O�@[%d]��\n",iendorse,mprem);
        strcat(tmpbuf2, msgbuf_del);
        count_num ++;

        $COMMIT WORK;
        $BEGIN  WORK;
   }
   $CLOSE  cur_edr_1;
   $FREE   cur_edr_1;

   $COMMIT WORK;

   printf("���R������[%ld],�w�R������[%ld],���ѵ���[%ld]\n", total_count, del_count, fail_count);

   sprintf_s(msgbuf, sizeof msgbuf, "\n�����R������[%ld]\n���w�R������[%ld]\n�����ѵ���[%ld]\n",total_count, del_count, fail_count);
   strcat(msgbuf , "\n\n�w�R�������ӡG\n");
   strcat(msgbuf , tmpbuf2);
   strcat(msgbuf , "\n\n��楢�ѩ��ӡG\n");
   strcat(msgbuf , tmpbuf1);

   printf("msgbuf[%s]\n",msgbuf);

   EWRITE(userid,M_CM_OK,msgbuf);
   return M_CM_OK;
        
errexit:
   rc = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   sqlfatal();
   return rc;
}

long car414_chk_next(ipolicy_chk,nequip)
$char ipolicy_chk[21];
$char nequip[31];
{
   $WHENEVER SQLERROR GOTO errexit;
$int  t_cnt;
$long mlimit;
$char iequip[3];
$char iagent[2];
$char iassured[11];
$long dply_begin;
$char stmt[2000];
$char iengine[CA_ENGINE_NUM];
$char equipdecode[201];
$char ilast_ply[20], fulldbname[20],fulldbname1[20];
extern struct sEquip *IfirstEquip, *IcurrEquip, *IlastEquip, *IEquip_ptr;
long  rc;
int   iequip_flag;
char  sequip_str[201];
$int  iequip_remark;

   t_cnt  = 0;
   mlimit = 0;
   strcpy(equipdecode,equip_get(nequip));  
   printf("equipdecode[%s]\n",equipdecode);
  
   IEquip_ptr=IfirstEquip;
   while (IEquip_ptr)
   {
    strcpy(iequip,IEquip_ptr->sequip);
    printf("INTO struct iequip[%s]\n",iequip);

    iequip_remark = atoi(iequip);
   $SELECT unique mlimit,iagent
      INTO $mlimit,$iagent
      FROM ca_promote
     WHERE iremark = $iequip_remark;
        if (mlimit > 0)
        {
           t_cnt = 1;
           break;
        }
     IEquip_ptr=IEquip_ptr->next;
   }

   if (t_cnt == 0)  
   {
       return FALSE;
   }
 
   strcpy(fulldbname, get_car_full_db(ipolicy_chk));

   printf("fulldbname[%s]\n",fulldbname);
   iequip_flag = (atoi(iequip) - 1) % 30 + 1;
   strcpy(sequip_str,equip_instr(iequip));
   t_cnt = 0;
   sprintf_s(stmt, sizeof stmt,
  " SELECT b.iassured,a.dply_begin,b.iengine,ilast_ply "
  "    FROM %s:ply_relation a, %s:policy b "
  "   WHERE a.ipolicy = b.ipolicy        "
  "     AND b.nequipment[%d] in %s       "
  "     AND a.icar_flag = '2'            "
  "     AND a.iofficer[1] = '%s'         "
  "     AND a.fcard_class = '2'          "
  "     AND a.ipolicy = '%s'             "
  "     AND (a.mdmg_prem + a.mlia_prem) > %ld ",fulldbname, fulldbname,
       iequip_flag,sequip_str,iagent,ipolicy_chk,mlimit);
   printf("stmt[%s]\n",stmt);
  $PREPARE get_ip FROM $stmt;
  $EXECUTE get_ip
        INTO $iassured,$dply_begin,$iengine,$ilast_ply;
        if (SQLCODE == SQLNOTFOUND)
        {
 /***
           strcpy(msg_buf,"���O�椣�ŦX�M�צ۶O����O");
 ***/
           return FALSE;
        }
    printf("ilast_ply[%s]\n", ilast_ply); 

    strcpy(fulldbname1, get_car_full_db(ilast_ply));

    if(!IsBlankNull(ilast_ply))
    {
      sprintf_s(stmt, sizeof stmt,
      "SELECT count(*) "
      "   FROM %s:ply_relation "
      "  WHERE ipolicy = '%s'  "
      "    AND dply_end >= %ld "
      "    AND fcard_class = '2'",fulldbname1,ilast_ply, dply_begin);
      $PREPARE get_cntx FROM $stmt;

 printf("stmt[%s]\n",stmt);
      $EXECUTE get_cntx INTO $t_cnt;
      if (t_cnt == 0)
      {
          return FALSE;
      }

    }
    else
    {
 
    sprintf_s(stmt, sizeof stmt,
   " SELECT count(*)                                  "
   "    FROM %s:ply_relation a,%s:policy b,%s:ply_ins_type c    "
   "   WHERE a.ipolicy = b.ipolicy                     "
   "     AND a.ipolicy = c.ipolicy                     "
   "     AND c.iins_type in ('11','211')               "
   "     AND b.iengine = '%s'                          "
   "     AND b.iassured = '%s'                         "
   "     AND ( a.iofficer[1] = 'W'  OR a.iofficer[1] = 'N' "
   "           OR (a.iofficer[1,1] = 'H' and a.iofficer[1,2] not in ('H0','H1','H2'))) "
   "     AND a.dply_end >= %ld                         "
   "     AND a.fcard_class = '2'                       "
   "     AND c.mdamage_cover > 0 ",fulldbname,fulldbname,fulldbname,
        iengine,iassured,dply_begin);
  printf("stmt[%s]\n",stmt);
 $PREPARE get_cnt FROM $stmt;
 $EXECUTE get_cnt INTO $t_cnt;
         if (t_cnt == 0)
         {
 /***
            strcpy(msg_buf,"�L�k���h�~���ذeB��");
 ***/
            return FALSE;
         }
   }

   return TRUE;
errexit:
   printf("SQLCODE[%d]\n",SQLCODE);
   rc = SQLCODE;
   sqlfatal();
   return rc;
}

int IsBlankNull(str)
char *str;
{
    while (*str)
    {
        if (*str!=' ') return FALSE;
        str++;
    }
    return TRUE;
}

/*---------------------------------------------------------end program*/
