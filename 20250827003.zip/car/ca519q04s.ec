/*****************************---**************/
/*						                      */
/*   PROGRAM : ca519q04s.ec   (���l�H��q��)  */
 /*						                      */
/*   DATE    : 2021/10/12	                  */
/*						                      */
/**********************************************/
#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "sqlfatal.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "ca_field.h"
#include <locator.h>
#include "safeclib.h"

long car5194_email();
long car5194_get_db();


$char  DBName[5], userid[USER_ID], outputf[21], ddate1[11],sdgroup[11];
DBinfo  *list;
int     count_db = 0;
int     i;

$char   fname[100], filename[150], ftitle[1024], mbuf[9000], sApHome[30],
        msgbuf[1000];
$long   mdate;
int     flen;
FILE    *fp;

$loc_t ctxt;

/***************************************************************************/
main(argc, argv)
int argc;
char **argv;
{
    $char mbuf1[9000];

    int rc;

    batchinit();
    strcpy(DBName, isNULLstr(argv[1]));
    strcpy(userid, isNULLstr(argv[2]));
    strcpy(ddate1, isNULLstr(argv[3]));          /* �߮׷J�p�� (����CYY/MM/DD) */
    strcpy(outputf,isNULLstr(argv[4]));

    strcpy(sdgroup, cm_to_infdate(ddate1));

    rc = car5194_get_db();
    if (rc != SUCCESS)
        return rc;

    rc = car5194_init_data();
    if (rc != M_CM_OK) {
        printf("error on car5194_init_data\n");
        return rc;
    }

    rc=car5194_email();
    if (rc != M_CM_OK)
    {
        EWRITE(userid, rc, " ");
        return rc;
    }
    printf("[5194]:car5194_email ok!\n");

}
/***************************************************************************/
long car5194_email()
{
    $char stmt[3000],receiver_email[51], receiver_name[17];
    $char yy[4],mm[3],dd[3];
    $char ipolicy[21], iclaim[21], fcompensation[11], napplicant[100],
          nassured[100], iaccbank1[31], iaccbank2[31],iaccbank3[31],
          sNattachment[500],
		  iassured[12] = "", iassured_ext[2] = "" , itag[12] = "";

    $whenever sqlerror goto errexit;

    printf(" -- car5194_email start ----------- \n");

    for(i=0;i<count_db;i++)
    {
        sprintf_s(stmt,3000,
            "insert into tb5194 "
            "SELECT UNIQUE d.ipolicy, b.iclaim, "
            "       decode(fpart,'1','�{�����v', "
       		  "              decode(fcompensation,'1','�{�����v','2','�״_���v',fcompensation)), "
            "       e.iapplicant, e.napplicant, e.iassured, e.nassured, e.iassured_ext, e.itag, "
            "       max(CASE WHEN e.iassured = e.iapplicant THEN "
	    		  "                CASE WHEN (fcompensation = '1' OR fpart = '1') then "
	    			"	                    decode(f.sno,1,iaccount,'*******-*************') "
	    		  "                else  '*******-*************' end "
	    	    "           ELSE '*******-*************' END) AS iact1, "
	    	    " 	    max(CASE WHEN e.iassured = e.iapplicant THEN "
	    		  "                CASE WHEN (fcompensation = '1' OR fpart = '1') then "
	    			"                   	decode(f.sno,2,iaccount,' ') "
	    		  "                else  ' ' END "
	    	    "           ELSE ' ' END) AS iact2, "
	          " 	    max(CASE WHEN e.iassured = e.iapplicant THEN "
	    		  "                CASE WHEN (fcompensation = '1' OR fpart = '1') then "
	    			"                   	decode(f.sno,3,iaccount,' ') "
	    		  "                else  ' ' END "
	    	    "           ELSE ' ' END) AS iact3, "
            "       sum(CASE fclose WHEN  '1' then 0 ELSE 1 END) "
            "  FROM %s:app_ins_type b, insurance_type c, %s:appraisal d, %s:policy e, "
            "       outer (SELECT iclose, fstl, iclose_type, istl_obj, "
            "                     trim(ibank)||'-'||trim(iaccount) AS iaccount, "
            "                     dense_rank() over (PARTITION BY iclose, fstl, iclose_type, istl_obj "
            "                     ORDER BY istl_obj_ext) AS sno "
            "                FROM ao_stl_obj_close "
            "               WHERE dgroup between add_months(today,-12) and today-1 "
            "                 AND iclose[6] <> 'C' AND fstl = '1') as f "
            " WHERE b.iins_type = c.iins_type    AND b.iclaim = d.iclaim "
            "   AND d.ipolicy = e.ipolicy        AND c.fins_grp = '1'  "
            "   AND c.iri_ins IN ('01','11')     AND d.fpart IN ('1','2','3') "
            "   AND d.fcard_class = '2'          "
            "   AND d.iclaim = f.iclose     AND e.iapplicant = f.istl_obj    "
            "   AND b.iclaim IN  (SELECT UNIQUE a.iclaim      "
            "                       FROM %s:stl_ins_type a    "
		        "                      WHERE a.dgroup = '%s'	  "
		        "                        AND fstl = '1'           "
		        "                        AND a.iclaim[6] <> 'C' ) "
            "   GROUP BY 1,2,3,4,5,6,7,8,9 "
            "  HAVING sum(CASE fclose WHEN  '1' then 0 ELSE 1 END) = 0 ",
            list[i].dbname, list[i].dbname, list[i].dbname, list[i].dbname, sdgroup);
printf("stmt=[%s]\n\n",stmt);
            $PREPARE PRE_a1 FROM $stmt;
	        $EXECUTE PRE_a1;
    }

    memset(fname,0x00,sizeof(fname));
	memset(filename,0x00,sizeof(filename));

	cm_split_ymd_100(ddate1,yy,mm,dd);

	sprintf_s(fname,100,"%s%s%s_���l�z�߮ץ�q��",yy,mm,dd);
	sprintf_s(filename,150,"%s/rptftp/car_email/%s.csv",sApHome,fname);
	sprintf_s(sNattachment,500,"%s.csv",fname);
	printf("filename= %s \n",filename);
	
	$long daccident = 0;
	$char ibranch_in[5] = "", ipolicy_com1[21] = "", ipolicy_com2[21] = "", ipolicy_next[21] = "", ipolicy_vol2[21] = "";
	$char dply_end1[11] = "", dply_end2[11] = "", dply_end_vol2[11] = "";
	$char s1[10] = "", s2[10] = "", s3[10] = "";
	int i_tmp = 0;
	$char ipolicy_tmp[21] = "", dply_end_tmp[11] = "";
	
	fp=fopen(filename,"w");

	fprintf(fp,ftitle);
	sprintf_s(stmt,3000,
	    "select ipolicy,iclaim,fcompensation,napplicant,nassured,iaccbank1,iaccbank2,iaccbank3,iassured,iassured_ext,itag "
	    "  from tb5194 where 1=1 order by ipolicy;");
	$prepare pre_dtl from $stmt;
    $declare cur_dtl cursor for pre_dtl;
	$open cur_dtl ;
	while(1)
	{
		
	    $fetch cur_dtl
	      into $ipolicy, $iclaim, $fcompensation, $napplicant, $nassured, $iaccbank1, $iaccbank2, $iaccbank3, $iassured, $iassured_ext, $itag;
	    if (SQLCODE==SQLNOTFOUND) break;

	    strcpy(ipolicy, trim(ipolicy));
	    strcpy(iclaim, trim(iclaim));
	    strcpy(fcompensation, trim(fcompensation));
	    strcpy(napplicant, trim(napplicant));
	    strcpy(nassured, trim(nassured));
	    strcpy(iaccbank1, trim(iaccbank1));
		strcpy(iassured, trim(iassured));
		strcpy(iassured_ext, trim(iassured_ext));
		strcpy(itag, trim(itag));

printf("ipolicy : %s \n", ipolicy);
printf("iclaim : %s \n", iclaim);
		/* �ΫO�渹�P�߮׸���X�I�ɶ��P���ݰϰ� */
		stmt[0]='\0';
		sprintf_s(stmt,3000,
			"select date(daccident), ibranch_in "
			"from ca_clm_process where ipolicy = ? and iclaim = ? ");
		$prepare tmp_dt1 from $stmt;
		$execute tmp_dt1 
			into $daccident, $ibranch_in
            using $ipolicy, $iclaim;

		strcpy(ibranch_in, trim(ibranch_in));

		ipolicy_com1[0] = '\0';
		ipolicy_com2[0] = '\0';
		ipolicy_next[0] = '\0';
		ipolicy_vol2[0] = '\0';
		strcpy(dply_end1, '\0');
		strcpy(dply_end2, '\0');
		strcpy(dply_end_vol2, '\0');
		s1[0] = '\0';
		s2[0] = '\0';
		s3[0] = '\0';
printf("daccident : %d \n", daccident);
printf("ibranch_in : %s \n", ibranch_in);
		
		/* ��j��O�渹1�B�����B�U�@�i�O�� */
		stmt[0]='\0';
		sprintf_s(stmt,3000,
			"select ipolicy, dply_end , inext_ply "
			"from newa%s:ply_relation "
			"where ipolicy = (select irelative_ply from newa%s:ply_relation where ipolicy = ? ) "
			"and dply_end >= ? ", ibranch_in, ibranch_in);
		$prepare tmp_dt2 from $stmt;
		$execute tmp_dt2 
			into $ipolicy_com1, $dply_end1, $ipolicy_next
			using $ipolicy, $daccident;
				
		strcpy(ipolicy_com1, trim(ipolicy_com1));
		strcpy(dply_end1, trim(dply_end1));
		
		if(dply_end1[0] != '\0' && dply_end1 != "")
		{
			strcpy(s1, substring(dply_end1, 7, 4));
			strcpy(s2, substring(dply_end1, 1, 2));
			strcpy(s3, substring(dply_end1, 4, 2));
			strcpy(dply_end1, '\0');
			sprintf_s(dply_end1,11, "%s/%s/%s", s1, s2, s3);
		}
printf("stmt=[%s]\n",stmt);
printf("ipolicy_com1 : %s \n", ipolicy_com1);
printf("dply_end1 : %s \n\n", dply_end1);

		/* ���U�@�i�O��(�j��O�渹2)�A��j��O�渹2�������B���N�O�渹2 */
		if(ipolicy_next[0] != '\0' && ipolicy_next != "")
		{
			stmt[0]='\0';
			sprintf_s(stmt,3000,
				"select ipolicy, dply_end , irelative_ply "
				"from newa%s:ply_relation "
				"where ipolicy = ? "
				"and dply_end >= ? ", ibranch_in);
			$prepare tmp_dt2 from $stmt;
			$execute tmp_dt2 
				into $ipolicy_com2, $dply_end2, $ipolicy_vol2
				using $ipolicy_next, $daccident;
			
			if(dply_end2[0] != '\0' && dply_end2 != "")
			{
				strcpy(s1, substring(dply_end2, 7, 4));
				strcpy(s2, substring(dply_end2, 1, 2));
				strcpy(s3, substring(dply_end2, 4, 2));
				strcpy(dply_end2, '\0');
				sprintf_s(dply_end2,11, "%s/%s/%s", s1, s2, s3);
			}
printf("stmt=[%s]\n",stmt);
printf("ipolicy_com2 : %s \n", ipolicy_com2);
printf("dply_end2 : %s \n\n", dply_end2);

			/* �����N�O�渹2�A����N����� */
			stmt[0]='\0';
			sprintf_s(stmt,3000,
				"select ipolicy, dply_end "
				"from newa%s:ply_relation "
				"where ipolicy = ? "
				"and dply_end >= ? ", ibranch_in);
			$prepare tmp_dt2 from $stmt;
			$execute tmp_dt2 
				into $ipolicy_vol2, $dply_end_vol2
				using $ipolicy_vol2, $daccident;
				
			if(dply_end_vol2[0] != '\0' && dply_end_vol2 != "")
			{
				strcpy(s1, substring(dply_end_vol2, 7, 4));
				strcpy(s2, substring(dply_end_vol2, 1, 2));
				strcpy(s3, substring(dply_end_vol2, 4, 2));
				strcpy(dply_end_vol2, '\0');
				sprintf_s(dply_end_vol2,11, "%s/%s/%s", s1, s2, s3);
			}
printf("stmt=[%s]\n",stmt);
printf("ipolicy_vol2 : %s \n", ipolicy_vol2);
printf("dply_end_vol2 : %s \n", dply_end_vol2);
		}
		
		/* �p�j��O�渹1���šA��iassured�Biassured_ext�Bitag�A��@�� */
		if(ipolicy_com1[0] == '\0' || ipolicy_com1 == "")
		{
printf("�j��O��1���šA�ϥ�iassured�Biassured_ext�Bitag�A��@��\n");
			i_tmp = 0;
			stmt[0]='\0';
			sprintf_s(stmt,3000,
				" select ipolicy, dply_end "
				" from newa%s:ply_relation where ipolicy in ( select a.ipolicy "
														" from newa%s:ply_ins_type a, newa%s:policy b "
														" where a.ipolicy = b.ipolicy "
														" and a.iins_type = '21' "
														" and a.mdamage_cover > 0 "
														" and b.iassured = ? "
														" and b.iassured_ext = ? "
														" and b.itag = ? ) "
				" and dply_end >= ? "
				" order by dply_end ", ibranch_in, ibranch_in, ibranch_in);
printf("iassured : %s \n", iassured);
printf("iassured_ext : %s \n", iassured_ext);
printf("itag : %s \n", itag);
			$prepare pre_dt2 from $stmt;
			$declare cur_dt2 cursor for pre_dt2;
			$open cur_dt2 USING $iassured, $iassured_ext, $itag, $daccident;

			while(1)
			{
				$fetch cur_dt2
					into $ipolicy_tmp, $dply_end_tmp;
				if (SQLCODE==SQLNOTFOUND) break;

				if(i_tmp == 0)
				{
					strcpy(ipolicy_com1, trim(ipolicy_tmp));
					strcpy(dply_end1, trim(dply_end_tmp));
					if(dply_end1[0] != '\0' && dply_end1 != "")
					{
						strcpy(s1, substring(dply_end1, 7, 4));
						strcpy(s2, substring(dply_end1, 1, 2));
						strcpy(s3, substring(dply_end1, 4, 2));
						strcpy(dply_end1, '\0');
						sprintf_s(dply_end1,11, "%s/%s/%s", s1, s2, s3);
					}

				}
				else if(i_tmp == 1)
				{
					strcpy(ipolicy_com2, trim(ipolicy_tmp));
					strcpy(dply_end2, trim(dply_end_tmp));
					if(dply_end2[0] != '\0' && dply_end2 != "")
					{
						strcpy(s1, substring(dply_end2, 7, 4));
						strcpy(s2, substring(dply_end2, 1, 2));
						strcpy(s3, substring(dply_end2, 4, 2));
						strcpy(dply_end2, '\0');
						sprintf_s(dply_end2,11, "%s/%s/%s", s1, s2, s3);
					}
				}
				i_tmp++;
			}
			$close cur_dt2;
			$free cur_dt2;
			
			/* �Υ��N�O�渹1�A�H��U�@�i�O�檺�覡�A����N�O�渹2�B���N����� */
			stmt[0]='\0';
			sprintf_s(stmt,3000,
				"select ipolicy, dply_end "
				"from newa%s:ply_relation "
				"where ipolicy = (select inext_ply from ply_relation where ipolicy = ? ) "
				"and dply_end >= ? ", ibranch_in);
			$prepare tmp_dt2 from $stmt;
			$execute tmp_dt2 
				into $ipolicy_vol2, $dply_end_vol2
				using $ipolicy, $daccident;
				
			if(dply_end_vol2[0] != '\0' && dply_end_vol2 != "")
			{
				strcpy(s1, substring(dply_end_vol2, 7, 4));
				strcpy(s2, substring(dply_end_vol2, 1, 2));
				strcpy(s3, substring(dply_end_vol2, 4, 2));
				strcpy(dply_end_vol2, '\0');
				sprintf_s(dply_end_vol2,11, "%s/%s/%s", s1, s2, s3);
			}
printf("ipolicy_com1 : %s \n", ipolicy_com1);
printf("dply_end1 : %s \n", dply_end1);
printf("ipolicy_com2 : %s \n", ipolicy_com2);
printf("dply_end2 : %s \n", dply_end2);
printf("ipolicy_vol2 : %s \n", ipolicy_vol2);
printf("dply_end_vol2 : %s \n", dply_end_vol2);
		}
		
printf("-----------------------------------------------------------------------------\n\n");
	    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s \n",
	            ipolicy, iclaim, fcompensation, napplicant, nassured, iaccbank1,
	            iaccbank2, iaccbank3, ipolicy_com1, dply_end1, ipolicy_com2, dply_end2, ipolicy_vol2, dply_end_vol2);
    }
    $close cur_dtl;
	fclose(fp);
    $free  cur_dtl;

    /* ���H�Hmail -- �]�w�b car_code  kind = 'CL , detail = 'EMAIL_CAR519' */
    $DECLARE cur_B3 CURSOR FOR
	 SELECT email,chinese_name
	   FROM personal:asempl
	  WHERE empl_no in (select detail2 from car_code where kind = 'CL'
	                       and detail = 'EMAIL_CAR519');
    $OPEN cur_B3;
    while(1)
    {
        $FETCH cur_B3 INTO $receiver_email, $receiver_name;
        if( SQLCODE == SQLNOTFOUND ) break;

        strcpy(receiver_email,trim(receiver_email));
        strcat(receiver_email,"@tmnewa.com.tw");
        strcpy(receiver_name, trim(receiver_name));

        $INSERT INTO batchemail
            (project_id, mail_date, receiver_email, receiver_name, cc,
             content, key, mail_count, nsubject,nattachment)
        VALUES
            ('CAR5194', $mdate, $receiver_email, $receiver_name, ' ',
             $ctxt, $fname,  1, '���l�z�ߤΫO�I�h�O�@�֥I�ڧ@�~�q��', $sNattachment);

    }
    $CLOSE cur_B3;
    $FREE cur_B3;


 return M_CM_OK;

errexit:
  printf("errexit, SQLCODE=[%ld] \n", SQLCODE);
  return SQLCODE;

}

/* ------------------------------------------------------------------------- */
long car5194_get_db()
{
   int	rc;

   if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }

   return SUCCESS;

errexit:

   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/* ------------------------------------------------------------------------- */
long car5194_init_data()
{
    $whenever sqlerror goto errexit;
    $create temp table tb5194
    (
        ipolicy     char(20),   -- �O�渹
        iclaim      char(20),   -- �߮׸�
        fcompensation   char(10),    -- ���v�O
        iapplicant  char(10),   -- �n�O�H
        napplicant  char(100),  -- �n�O�H�W��
        iassured    char(100),  -- �Q�O�I�H
        nassured    char(100),  -- �Q�O�I�H�W��
		iassured_ext   char(100),  -- �Q�O�I�H����
		itag 		 char(100),  -- �P�Ӹ��X
        iaccbank1    char(30),   -- �״ڱb��
        iaccbank2    char(30),   -- �״ڱb��
        iaccbank3    char(30),   -- �״ڱb��
        icnt        int         -- ���M�I�حӼ�
    )with no log;

    /* ���Y */
    strcpy(ftitle, "�O�渹�X,�߮׽s��,���v�O,�n�O�H�m�W,�Q�O�H�m�W,�n/�Q�O�H�ȱb��1,");
    strcat(ftitle, "�n/�Q�O�H�ȱb��2,�n/�Q�O�H�ȱb��3,�j��O�渹1,�j������,�j��O�渹2,�j������,���N�O�渹2,���N����� \n");

    /* mail���e */
    sprintf_s(mbuf,9000,
        "1.�Щ�12:00�e������� <br>\n"
        "2.�ХߧY�n��smartflow�h�O�O�J�`�M�� <br>\n"
        "3.�Щ�15:00�e�q���]�ȳ��|�p�ߧY�B�z����]�ȳ��X�Ǭ����I�� <br>\n"
        "4.���v�O���״_���v�ɡA�Цۦ��v���t�άd�߭n�O�H�b��P���l�״_���v�T�{�� <br>\n"
        "5.�X�I�������I�B�ѵs�I�Ψ�X�I���[�I������z�פ�A�����h�O�O�C<br>\n");

    printf("************mbuf[%s]",mbuf);
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mbuf;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mbuf) + 1;
    mdate = cm_today();

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}