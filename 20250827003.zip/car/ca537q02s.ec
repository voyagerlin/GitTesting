/**********************************************************************/
/*   program id   : ca537p02s.ec                                      */
/*   program name : ���O�l�v���ɳ���                            */
/*   date written : 2018/12/18 by sylvia                              */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "safeclib.h"


char  outputf[21];
$char userid[11], sdate1[11], sdate2[11],idatano[13],proce_type[2];
$char DBName[5];
$char msgbuf[1000],sApHome[30];
char  opt[2],dbgn[11],dend[11];
char sTmp_db_name[31];
int rc;
DBinfo  *list;
int   count_db,k;
$int icnt;
    
main(argc, argv)
int argc;
char **argv;
{

	batchinit();

	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(opt,            isNULLstr(argv[3])); /* �d�����O:0:���ɧ帹 1:���ɤ�� */
	strcpy(idatano,        isNULLstr(argv[4])); /* ���ɧ帹 */
	strcpy(dbgn,           isNULLstr(argv[5])); /* ���ɤ��:�_�� */
	strcpy(dend,           isNULLstr(argv[6])); /* ���ɤ��:���� */
	strcpy(outputf,        isNULLstr(argv[7]));
	
	strcpy(sdate1,cm_to_infdate(dbgn));
	strcpy(sdate2,cm_to_infdate(dend));
	
	printf("opt=[%s]idatano=[%s]\n",opt,idatano);
	
	rc = car537_get_db();
    if (rc != M_CM_OK) {
        printf("error on car537_get_db\n");
        return rc;
    }
	
	rc = car537_prepare_data();
	if (rc != M_CM_OK) {
	    printf("error on car537_prepare_data\n");
		return rc;
    }
    
	rc = car537_build();
	if (rc != M_CM_OK) 
		return rc;
}
/* ------------------------------------------------------------------------- */
long car537_get_db()
{
    long	rc;
    
    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
    }

    if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;
    }

    rc = getApHome(sApHome);

    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }
    
   $create temp table tb537
    (
        iclaim			char(20)		,	-- �߮׸�
        ivictim     	char(12)        ,   -- �ƬG���`�HID    
        daccident		date			,	-- �X�I��
        dclose_ori  	date    		,	-- ��߮פ鵲��
        mstl			int     		,	-- �z�ߪ��B
        mhealth	    	int 			,	-- �������I
        qduty_adjuster  decimal(5,2)    ,   -- �i�D�v��v
        claim_amount    int         	, 	-- �i�D�v�������I���B
        mpay        	int             ,   -- �i�N����B
        idatano			char(20)		,	-- ���ɽs��
        iclose_type		int				,	-- �ߥI����
        icreate			char(10)		,	-- ���ɤH��
        dcreate			char(25)        ,	-- ���ɮɶ�
        dclose			date 			,	-- �鵲��
        iqserial		char(22)		,	-- �鵲�帹
        iupdate			char(10)		,	-- ��s�H��(�Y����鵲�H��)
        dupdate			char(25)        ,	-- ��s�ɶ�(�Y����鵲�ɶ�)
        dgroup          date                -- �J�p��
    )with no log;
    
    return M_CM_OK;
}
/* ------------------------------------------------------------------------- */
long car537_prepare_data()
{
	$WHENEVER SQLERROR GOTO errexit;

    $char  sTmp1[100],sTmp2[200],stmt1[3000];
    int i;
    
    
    /* ���ɧ帹 �� ���ɤ�� */
    if (opt[0] == '0') {
        sprintf_s(sTmp1,100,"and date(a.dcreate) between '%s' and '%s' ",sdate1,sdate2);
    }
    else if (opt[0] == '1') {
        sprintf_s(sTmp1,100,"and a.idatano matches '%s'",idatano);
    }
    else
        strcpy(sTmp1," ");
        
    for(k=0;k<count_db;k++)
    {
        sprintf_s(stmt1,3000, 
        "insert into tb537 \
	     select a.iclaim, a.ivictim, a.daccident, a.dclose_ori, a.mstl, a.mhealth, \
	            a.qduty_adjuster, a.claim_amount, a.mpay, a.idatano, a.iclose_type, \
	            a.icreate, a.dcreate, a.dclose,  chr(127)||trim(a.iqserial), a.iupdate, \
	            a.dupdate,   b.dgroup \
           from sysdb:ca_health_recovery a, %s:settlement b\
          where a.iclaim = b.iclaim and a.iclose_type = b.iclose_type\
            and b.fstl = '1' and b.ientry = 'car537' \
            and a.idatano = b.ipayno %s ", list[k].dbname, sTmp1 );
            
        printf("stmt1=[%s]\n",stmt1);
        $prepare pre1 from $stmt1;
        $execute pre1;
    }
    
    
    icnt = 0;
    
    $select count(*) into $icnt
      from tb537
     where 1=1; 
	
	/* �Y�d�L���,�g�@���T����USER���D */
	if (icnt == 0)
	{
	    $insert into tb537 (iclaim) values ('�d�L��ơA�Э��s�T�{');
	}
		
	return M_CM_OK;
	
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/


long car537_build()
{
    $char    sfilename[51], stitle[1000], stmt[1000];
    
	$WHENEVER SQLERROR GOTO errexit;

	strcpy(sfilename,"���O�l�v���ɳ���");
	if (opt[0] == '0')
	{
	    sprintf_s(stitle,1000,"���ɤ��:%s~%s\t",dbgn,dend);
	} else {
	    sprintf_s(stitle,1000,"���ɧ帹:%s\t",idatano);
	}
	strcat(stitle,"\n");
	strcat(stitle,"\t�߮׸�\t�ƬG���`�HID\t�X�I��\t��߮פ鵲��\t�z�ߪ��B");
	strcat(stitle,"\t�������I\t�i�D�v��v\t�i�D�v�������I���B\t�i�N����B");
	strcat(stitle,"\t���ɽs��\t�ߥI����\t���ɤH��\t���ɮɶ�\t�鵲��\t�鵲�帹");
	strcat(stitle,"\t�鵲�H��\t�鵲�ɶ�\t�J�p��\t");
	
	sprintf_s(stmt,1000,
	    "select * from tb537 order by 1 ");
	
	rc = unload_file(outputf," ",sfilename,stitle,stmt);
	
	if (rc != SUCCESS) 
	{
	    sprintf_s(msgbuf,1000," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}
