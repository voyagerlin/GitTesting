/**************************************************************/
/*   PROGRAM : ca139m01s.ec by Ealex                          */
/*   DATE    : 2003/05/20                                     */
/*             ������O�y�g��N�����~�N���ݾ��I�z�ܧ���@�@�~ */
/**************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
$include sqlca;

long car139(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    long rtncode;
    long car139_insert(),car139_single_query(),car139_multiple_query();
    long car139_update_exec();
    char option;

    cm_buf_init(command);
    cm_buf_get("%c",&option);
    switch(option)
    {
        case 'A': rtncode=car139_insert(reply);
                  break;
        case 'Q': rtncode=car139_single_query(reply);
                  break;
        case 'M': rtncode=car139_multiple_query(reply);
                  break;
        case 'D':
        case 'U': rtncode=car139_update_exec(reply,command,com_len);
                  break;
        case 'C': rtncode=car139_check(reply);     /* �g��N�������ˮ� (1110325007_SC2) */
                  break;
        default : 
                  return exitsub(reply,M_CM_WRONG_OPTION)?M_CM_WRONG_OPTION:apiRC;
    }
    return(rtncode);
}

/*-----------------------------------------------------------------*/
long car139_insert(reply)
serverReply reply;
{
    $char DBName[5];
    $char editor[11];
    $char cltIclass[3],cltIbigSales[11],cltOriIofficer[11],cltNewIofficer[11];
    $char cltPlyBgnYYMM[6],cltPlyEndYYMM[6];
    $date Today;
    int   tmp_len;
    long  MsgCode;

    cm_buf_get("%s ", DBName);
    cm_buf_get("%s ", editor);

    cm_buf_get("%s %s %s %s %s %s ",
               cltIclass,cltIbigSales,cltOriIofficer,cltNewIofficer,cltPlyBgnYYMM,cltPlyEndYYMM);

    rtoday(&Today);     /* get today's datetime */

    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    /* original */
    $SELECT *
       FROM officer
      WHERE iofficer = :cltOriIofficer;
    if(SQLCODE==SQLNOTFOUND)
    {
        return exitsub(reply,M_CMN_NOFFICER) ? M_CMN_NOFFICER : apiRC;
    }

    /* new */
    $SELECT *
       FROM officer
      WHERE iofficer = :cltNewIofficer;
    if(SQLCODE==SQLNOTFOUND)
    {
        return exitsub(reply,M_CMN_NOFFICER) ? M_CMN_NOFFICER : apiRC;
    }

    $BEGIN WORK;

    $INSERT INTO ca_change_office
            (iclass,ibig_sales,ori_iofficer,new_iofficer,plybgn_yymm,plyend_yymm,icreator,dcreate)
     VALUES (:cltIclass,:cltIbigSales,:cltOriIofficer,:cltNewIofficer,:cltPlyBgnYYMM,:cltPlyEndYYMM,:editor,:Today);

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);

    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return apiRC;
    }  

    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;
    return api_OKComplete;

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/*-----------------------------------------------------------------*/
long car139_single_query(reply)
serverReply reply;
{
    $char DBName[5];
    $char Iclass[3],Ibig_sales[11];
    $char tblIclass[3], tblIbig_sales[11];
    $char tblOri_iofficer[11], tblNew_iofficer[11];
    $char tblPlybgn_yymm[6],tblPlyend_yymm[6];

    $char lblIbigSalesName[41];
    $char lblOriIofficerName[11], lblNewIofficerName[11];
    $char lblOriIbusLocation[11], lblNewIbusLocation[11];
    $char icreate[7], dcreate[11],iupdate[7], dupdate[11];

    int   tmp_len;

    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s",Iclass,Ibig_sales);

    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    printf( "SELECT ca_change_office\n");

    $SELECT iclass, ibig_sales,
            ori_iofficer, new_iofficer,
            plybgn_yymm, plyend_yymm,
            icreator, dcreate, iupdate, dupdate
       INTO $tblIclass, $tblIbig_sales,
            $tblOri_iofficer, $tblNew_iofficer ,
            $tblPlybgn_yymm,$tblPlyend_yymm,
            $icreate, $dcreate,$iupdate, $dupdate
       FROM ca_change_office
      WHERE iclass     = $Iclass
        AND ibig_sales = $Ibig_sales;
    if(SQLCODE==SQLNOTFOUND)
        return exitsub(reply,M_CA_NBIG_OFFICE) ? M_CA_NBIG_OFFICE : apiRC;

    strcpy(tblIclass       , trim(tblIclass));
    strcpy(tblIbig_sales   , trim(tblIbig_sales));
    strcpy(tblOri_iofficer , trim(tblOri_iofficer));
    strcpy(tblNew_iofficer , trim(tblNew_iofficer));
    strcpy(tblPlybgn_yymm  , trim(tblPlybgn_yymm));
    strcpy(tblPlyend_yymm  , trim(tblPlyend_yymm));
    strcpy(icreate         , trim(icreate));
    strcpy(dcreate         , trim(dcreate));
    strcpy(iupdate         , trim(iupdate));
    strcpy(dupdate         , trim(dupdate));

    /* original */
    $SELECT nname, ibus_location
       INTO :lblOriIofficerName, :lblOriIbusLocation
       FROM officer
      WHERE iofficer = :tblOri_iofficer;
    if(SQLCODE==SQLNOTFOUND)
    {
        return exitsub(reply,M_CMN_NOFFICER) ? M_CMN_NOFFICER : apiRC;
    }

    /* new */
    $SELECT nname, ibus_location
       INTO :lblNewIofficerName, :lblNewIbusLocation
       FROM officer
      WHERE iofficer = :tblNew_iofficer;
    if(SQLCODE==SQLNOTFOUND)
    {
        return exitsub(reply,M_CMN_NOFFICER) ? M_CMN_NOFFICER : apiRC;
    }

    if (strcmp(tblIclass,"2")==0)  /* �~�N�N�� */
    {
        $SELECT nname
           INTO :lblIbigSalesName
           FROM ca_big_office
          WHERE fclass = '2'
            AND ibig_comp = :tblIbig_sales;

        if(SQLCODE==SQLNOTFOUND)
        {
            lblIbigSalesName[0] = '\0';
        }
    }
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l ", M_CM_OK);
    cm_buf_put("%s ",tblIclass);

    if ((strcmp(tblIclass,"1")==0) || (strcmp(tblIclass,"3")==0)) /* �g��N�� */
    {
        cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s",
                   tblOri_iofficer , lblOriIofficerName, lblOriIbusLocation,
                   tblNew_iofficer , lblNewIofficerName, lblNewIbusLocation,
                   tblPlybgn_yymm  , tblPlyend_yymm, 
                   icreate, dcreate, iupdate, dupdate);
    }
    else /* �~�N�N�� */
    {
        cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s %s",
                   tblIbig_sales   , lblIbigSalesName  ,
                   tblOri_iofficer , lblOriIofficerName, lblOriIbusLocation,
                   tblNew_iofficer , lblNewIofficerName, lblNewIbusLocation,
                   tblPlybgn_yymm  , tblPlyend_yymm, 
                   icreate, dcreate, iupdate, dupdate);
    }

    tmp_len = cm_buf_len(ReplyBuf);
    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}

/*-----------------------------------------------------------------*/
long car139_multiple_query(reply)
serverReply reply;
{
    $char DBName[5];
    $char Iclass[3], Ibig_sales[11], Ori_iofficer[11], New_iofficer[11];
    $char sIclass[3], sIbig_sales[11], sOri_iofficer[11], sNew_iofficer[11];

    char  tmpbuf[4000];
    int   count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int   i,total_count=0;

    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s %s %s",Iclass,Ibig_sales,Ori_iofficer,New_iofficer);

    $WHENEVER SQLERROR GOTO errexit;
    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    printf("Declare q_cur FOR ca_change_office \n");
    $DECLARE q_cur CURSOR FOR
      SELECT iclass, ibig_sales, ori_iofficer, new_iofficer
        INTO $sIclass, $sIbig_sales, $sOri_iofficer, $sNew_iofficer
        FROM ca_change_office
       WHERE iclass     matches $Iclass
         AND ibig_sales matches $Ibig_sales
         AND ori_iofficer matches $Ori_iofficer
         AND new_iofficer matches $New_iofficer
       ORDER BY iclass,ibig_sales,ori_iofficer,new_iofficer;

    $OPEN q_cur;

    for(;;)
    {
        $FETCH q_cur;
        if(SQLCODE != 0) break;

        cm_buf_init(tmpbuf);
        if( count == 0 )
        {
            cm_buf_res_msg();    /* reserve for MsgCode and count */
            cm_buf_res_count();
        }

        cm_buf_put("%s %s %s %s",sIclass,sIbig_sales,sOri_iofficer,sNew_iofficer);
        tmp_len = cm_buf_len(tmpbuf);

        if( tmp_len + repbuf_len < 3000 )
        {   /* buffer size less than 4K */
            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else
        {   /* more than 4K, send to client side */
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);

            if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {
                $CLOSE q_cur;
                return apiRC;
            }
            else
            {    /* clear ReplyBuf and count to start all over again */
                replycnt++;

                if(replycnt == 8)
                {    /* more than 30K, client cannot display,error */
                    cm_buf_init(ReplyBuf);
                    cm_buf_put("%l",M_CM_OUT_SPACE);
                    tmp_len = cm_buf_len(ReplyBuf);
                    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                        return apiRC;
                    return M_CM_OUT_SPACE;
                }

                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();    /* reserve for MsgCode and count */
                cm_buf_res_count();
                cm_buf_put("%s %s %s %s",sIclass,sIbig_sales,sOri_iofficer,sNew_iofficer);
                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
            }
        }
    } /* for loop */

    $CLOSE q_cur;
    if(count > 0)
    {    /* break out, at least one record is selected */
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
            return apiRC;
        return api_OKComplete;
    }
    else    /* break out, not any row is found */
    {
        return exitsub(reply,M_CA_NBIG_OFFICE) ? M_CA_NBIG_OFFICE : apiRC;
    }

errexit:
    return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}

/*-----------------------------------------------------------------*/
long car139_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    $char  Iclass[3],Ibig_sales[11];
    $char  tblIclass[3], tblIbig_sales[11];
    $char  tblOri_iofficer[11], tblNew_iofficer[11];
    $char  tblPlybgn_yymm[6],tblPlyend_yymm[6];

    $char  lblIbigSalesName[41];
    $char  lblOriIofficerName[11], lblNewIofficerName[11];
    $char  lblOriIbusLocation[11], lblNewIbusLocation[11];
    $char  icreate[7], dcreate[11],iupdate[7], dupdate[11];

    $char  curIclass[3],curIbig_sales[11];

    $char  cltIclass[3],cltIbigSales[11],cltOriIofficer[11],cltNewIofficer[11];
    $char  cltPlyBgnYYMM[6],cltPlyEndYYMM[6];

    char   option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
    int    tmp_len,raw_len;
    long   dummy;
    long   MsgCode;

    $char  DBName[5];
    $char  editor[11];
    $date  Today;

    comm = (char *) command;
    cm_buf_init(command);
    cm_buf_get("%c %s",&option,DBName);

    rtoday(&Today);     /* get today's datetime */
    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    /* compare old record and current record, if the record has not been changed
       since last request, update or delete the record, otherwise return errmsg
       to client side */

    /* get old record info from command buffer */

    /* raw_len = *(int *) &comm[com_len];
       memcpy(&raw_len,(void *)&command[com_len],sizeof(int));
    */
    memcpy(&raw_len,&comm[com_len],sizeof(int));
    pos = &comm[com_len+sizeof(int)];
    raw_ptr = malloc(raw_len);
    if(raw_ptr != (char*)0)
        memcpy(raw_ptr,pos,raw_len);
    else
    {
        if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
            return M_CM_NOT_MALLOC;
        else
            return apiRC;
    }

    cm_buf_init(raw_ptr);    /* get index key from old record */
    cm_buf_get("%l %s %s ",&dummy,curIclass,curIbig_sales);

    $BEGIN WORK;

    printf( "[UPDATE]:SELECT ca_change_office \n");

    $SELECT iclass, ibig_sales,
            ori_iofficer, new_iofficer,
            plybgn_yymm, plyend_yymm,
            icreator, dcreate, iupdate, dupdate
       INTO $tblIclass, $tblIbig_sales,
            $tblOri_iofficer, $tblNew_iofficer ,
            $tblPlybgn_yymm,$tblPlyend_yymm,
            $icreate, $dcreate, $iupdate, $dupdate
       FROM ca_change_office
      WHERE iclass     = $curIclass
        AND ibig_sales = $curIbig_sales;
    if(SQLCODE==SQLNOTFOUND)
        return exitsub(reply,M_CA_NBIG_OFFICE) ? M_CA_NBIG_OFFICE : apiRC;

    strcpy(tblIclass       , trim(tblIclass));
    strcpy(tblIbig_sales   , trim(tblIbig_sales));
    strcpy(tblOri_iofficer , trim(tblOri_iofficer));
    strcpy(tblNew_iofficer , trim(tblNew_iofficer));
    strcpy(tblPlybgn_yymm  , trim(tblPlybgn_yymm));
    strcpy(tblPlyend_yymm  , trim(tblPlyend_yymm));
    strcpy(icreate         , trim(icreate));
    strcpy(dcreate         , trim(dcreate));
    strcpy(iupdate         , trim(iupdate));
    strcpy(dupdate         , trim(dupdate));

    /* original */
    $SELECT nname, ibus_location
       INTO :lblOriIofficerName, :lblOriIbusLocation
       FROM officer
      WHERE iofficer = :tblOri_iofficer;

    /* new */
    $SELECT nname, ibus_location
       INTO :lblNewIofficerName, :lblNewIbusLocation
       FROM officer
      WHERE iofficer = :tblNew_iofficer;

    if (strcmp(tblIclass,"2")==0)  /* �~�N�N�� */
    {
        $SELECT nname
           INTO :lblIbigSalesName
           FROM ca_big_office
          WHERE fclass = '2'
            AND ibig_comp = :tblIbig_sales;

        if(SQLCODE==SQLNOTFOUND)
        {
            lblIbigSalesName[0] = '\0';
        }
    }

    /* if key value has been changed then SQLNOTFOUND,else put current value
       into cur_buf for comparison */

    if(SQLCODE == SQLNOTFOUND)
    {
        MsgCode = M_CM_NOT_FOUND;
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        if( SQLCODE != 0) MsgCode = SQLCODE;
        return exitsub(reply,MsgCode) ? MsgCode : apiRC;
    }

    cm_buf_init(cur_buf);
    cm_buf_put("%l ",dummy);
    cm_buf_put("%s ",tblIclass);

    if ((strcmp(tblIclass,"1")==0) || (strcmp(tblIclass,"3")==0)) /* �g��N�� */
    {
        cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s",
                   tblOri_iofficer , lblOriIofficerName, lblOriIbusLocation,
                   tblNew_iofficer , lblNewIofficerName, lblNewIbusLocation,
                   tblPlybgn_yymm  , tblPlyend_yymm,
                   icreate, dcreate,iupdate, dupdate);
    }
    else /* �~�N�N�� */
    {
        cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s %s",
                   tblIbig_sales   , lblIbigSalesName  ,
                   tblOri_iofficer , lblOriIofficerName, lblOriIbusLocation,
                   tblNew_iofficer , lblNewIofficerName, lblNewIbusLocation,
                   tblPlybgn_yymm  , tblPlyend_yymm,
                   icreate, dcreate,iupdate, dupdate);
    }

    printf("cur_buf[%s]\n",cur_buf);
    printf("raw_ptr[%s]\n",raw_ptr);

    if(memcmp(cur_buf,raw_ptr,raw_len) != 0)
    {   /* compare 2 records, not equal */
        MsgCode = M_CM_NOT_EQUAL;
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        if( SQLCODE != 0) MsgCode = SQLCODE;
        return exitsub(reply,MsgCode) ? MsgCode : apiRC;
    }

    /* equal, then exec DB operation */

    if( option == 'D' )
    {
        $DELETE FROM ca_change_office
          WHERE iclass     = $curIclass
            AND ibig_sales = $curIbig_sales;
        cm_buf_init(ReplyBuf);
        cm_buf_put("%l",M_CM_OK);
        tmp_len = cm_buf_len(ReplyBuf);
        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return apiRC;
        }

        $WHENEVER SQLERROR GOTO errexit;
        $COMMIT WORK;
        return api_OKComplete;
    }
    else if(option == 'U')
    {
        cm_buf_init(command);
        cm_buf_get("%c %s %s ", &option,DBName,editor);

        cm_buf_get("%s %s %s %s %s %s ",
                   cltIclass,cltIbigSales,cltOriIofficer,cltNewIofficer,cltPlyBgnYYMM,cltPlyEndYYMM);

        $UPDATE ca_change_office
            SET (ori_iofficer,new_iofficer,plybgn_yymm,plyend_yymm,iupdate,dupdate)
              = (:cltOriIofficer,:cltNewIofficer,:cltPlyBgnYYMM,:cltPlyEndYYMM,:editor,:Today)
          WHERE iclass     = $curIclass
            AND ibig_sales = $curIbig_sales;

        if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
        {
            $INSERT INTO ca_change_office
                    (iclass,ibig_sales,ori_iofficer,new_iofficer,plybgn_yymm,plyend_yymm,icreator,dcreate)
             VALUES (:cltIclass,:cltIbigSales,:cltOriIofficer,:cltNewIofficer,:cltPlyBgnYYMM,:cltPlyEndYYMM,:editor,:Today);
        }

        cm_buf_init(ReplyBuf);
        cm_buf_put("%l",M_CM_OK);
        tmp_len = cm_buf_len(ReplyBuf);
        
        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return apiRC;
        }

        $WHENEVER SQLERROR GOTO errexit;
        $COMMIT WORK;
        return api_OKComplete;
    }
    else
    {
        return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
    }

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/*-----------------------------------------------------------------*/

long car139_check(reply)
serverReply reply;
{
    $char DBName[5];
    $char sOri_iofficer[11], sNew_iofficer[11], sPlyBgn[6], sPlyEnd[6];
    $char sOri_bzfrom[3], sNew_bzfrom[3];
    $int  iPlyBgn, iPlyEnd, fchange, fdiff;
    int   tmp_len, rc;

    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s %s %s",sOri_iofficer,sNew_iofficer,sPlyBgn,sPlyEnd);

    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    iPlyBgn = atoi(sPlyBgn);
    iPlyEnd = atoi(sPlyEnd);
    
    /* �ˮ֭�g��N���O�_�Q�ഫ�L */
    $SELECT count(*)
       INTO $fchange
       FROM ca_change_office
      WHERE new_iofficer  = $sOri_iofficer
        AND ( $iPlyBgn BETWEEN plybgn_yymm::integer AND plyend_yymm::integer 
           or $iPlyEnd BETWEEN plybgn_yymm::integer AND plyend_yymm::integer 
           or plybgn_yymm::integer BETWEEN $iPlyBgn AND $iPlyEnd
           or plyend_yymm::integer BETWEEN $iPlyBgn AND $iPlyEnd );
    
    if(SQLCODE==SQLNOTFOUND) fchange = 0;
    
    /* �ˮ��ഫ�e��g��N���O�o�q�������O�_�@�P */
    rc = cm_get_bzfrom(sOri_iofficer,"","",sOri_bzfrom);
    rc = cm_get_bzfrom(sNew_iofficer,"","",sNew_bzfrom);
    
    if (sOri_bzfrom[0] == '4' || sNew_bzfrom[0] == '4') 
    {
    	if (sOri_bzfrom[0] == '4' &&�@sNew_bzfrom[0] == '4') fdiff = 0;
    	else fdiff = 1;
    }
    else if (sOri_bzfrom[1] == '0')
    {
    	if (sNew_bzfrom[1] == '0') fdiff = 0;
    	else fdiff = 1;
    }
    else if (sOri_bzfrom[1] == '1')
    {
    	if (sNew_bzfrom[1] == '1') fdiff = 0;
    	else fdiff = 1;
    }
    else
    	fdiff = 1;
    
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l ", M_CM_OK);
    cm_buf_put("%d %d",fchange,fdiff);
    
    tmp_len = cm_buf_len(ReplyBuf);
    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}
