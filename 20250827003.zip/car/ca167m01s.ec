/************************************************/
/*   �{���W�� : ca167m01s.ec                    */
/*   �ק��� : 2019/01/28                      */
/*   �@�~�W�� : ���ڶO�v�]�w                    */
/************************************************/

#include <stdio.h>
#include <string.h>
#include <decimal.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
$include sqlca;
#include "safeclib.h"

long MsgCode;

long car167(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car167_insert(),car167_single_query(),car167_multiple_query(),
      car167_update_exec(),car167_squery(),car167_insert_new_rate();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
           rtncode=car167_insert(reply);
           break;
  case 'Q':
           rtncode=car167_single_query(reply);
           break;
  case 'M':
           rtncode=car167_multiple_query(reply);
           break;
  case 'N':
           rtncode=car167_insert_new_rate(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car167_update_exec(reply,command,com_len);
           break;
  default :
        return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
 }
 return(rtncode);
}

long car167_insert(reply)
serverReply reply;
{
	$char DBName[5];
	$char c_iins_type[INSURANCE_TYPE],c_irate[5],c_iclass[2];
	$char c_cmp_provision[6],c_com_provision[6],c_iins_provision1[6],c_iins_provision2[6],c_iins_provision3[6];
	$char c_nremark[101];
	$char userid[11];

	int LiBufLen;
	cm_buf_get("%s",DBName);
	cm_buf_get("%s %s %s %s %s %s %s %s %s %s",
	           c_iins_type,c_irate,c_iclass,c_cmp_provision,c_com_provision,c_iins_provision1,c_iins_provision2,c_iins_provision3,c_nremark,userid);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	 return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
	
	$BEGIN WORK;
	$WHENEVER SQLERROR GOTO errexit;
	
	$INSERT INTO ca_prov_irate
	       (iins_type,irate,iclass,cmp_provision,com_provision,iins_provision1,iins_provision2,iins_provision3,nremark,icreate,dcreate,iupdate,dupdate)
	VALUES ($c_iins_type,$c_irate,$c_iclass,$c_cmp_provision,$c_com_provision,$c_iins_provision1,$c_iins_provision2,$c_iins_provision3,$c_nremark,$userid,current,$userid,current);
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	LiBufLen = cm_buf_len(ReplyBuf);   
	
	if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
	{
	$WHENEVER SQLERROR CONTINUE;
	$ROLLBACK WORK;
	return apiRC;
	}
	
	$WHENEVER SQLERROR GOTO errexit;
	$COMMIT WORK;
	return api_OKComplete;
	
	errexit:
	 printf(" sqlerrm = %s\n",sqlca.sqlerrm);
	 $WHENEVER SQLERROR CONTINUE;
	 MsgCode = SQLCODE;
	 $ROLLBACK WORK;
	 if (SQLCODE != 0) MsgCode = SQLCODE;
	 return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/*-----------------------------------------------------------------*/
            
long car167_delete(reply)
serverReply reply;
{
    $char icar_type[3],provision[2],iins_type[INSURANCE_TYPE],coefficient[10],mexpense[11],drate[11];
    $char DBName[5];
    $char stmt[512];
    int tmp_len;
    long MsgCode;
    int LiBufLen;

    cm_buf_get("%s %s %s %s %s",DBName,icar_type,provision,iins_type,drate);
    strcpy(drate,cm_to_infdate(drate));
    
    $WHENEVER SQLERROR GOTO errexit;
    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
        
    $WHENEVER SQLERROR GOTO errexit;
    $BEGIN WORK;    
      
    sprintf_s(stmt, sizeof stmt, "delete from ca_prov_irate "
           " where icar_type = '%s' "
           " and provision = '%s' "
           " and iins_type = '%s' "
           " and drate = '%s'",icar_type,provision,iins_type,drate);
             
    printf("stmt=[%s]\n",stmt) ;      
 	$EXECUTE IMMEDIATE $stmt ;      
 	
    if(SQLCODE != 0) goto errexit;
        
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);

    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return apiRC;
    }  

    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;
    return api_OKComplete;

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/*-----------------------------------------------------------------*/
long car167_single_query(reply)
serverReply reply;
{
 
 $char DBName[5];
 $char iins_type[INSURANCE_TYPE],irate[5],iclass[2];
 $char c_iins_type[INSURANCE_TYPE],c_irate[5],c_iclass[2];
 $char c_cmp_provision[6],c_com_provision[6],c_iins_provision1[6],c_iins_provision2[6],c_iins_provision3[6];
 $char c_nremark[101];
 $char c_icreate[11],c_ncreate[11],c_dcreate[20],c_iupdate[11],c_nupdate[11],c_dupdate[20];
 int tmp_len;
 
 cm_buf_get("%s %s %s %s",DBName,iins_type,irate,iclass);

 strcpy(iins_type,trim(iins_type));
 strcpy(irate,trim(irate));
 strcpy(iclass,trim(iclass));
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 
 $SELECT iins_type,irate,iclass,cmp_provision,com_provision,iins_provision1,iins_provision2,iins_provision3,nremark,icreate,dcreate,iupdate,dupdate
    INTO $c_iins_type,$c_irate,$c_iclass,$c_cmp_provision,$c_com_provision,$c_iins_provision1,$c_iins_provision2,$c_iins_provision3,$c_nremark,$c_icreate,$c_dcreate,$c_iupdate,$c_dupdate
    FROM ca_prov_irate
   WHERE iins_type = $iins_type
     AND irate = $irate
     AND iclass = $iclass;

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CM_NOT_FOUND) == True)
    return M_CM_NOT_FOUND;
  else
    return apiRC;
 }
 
 $SELECT nname INTO $c_ncreate
    FROM officer
   WHERE iofficer = $c_icreate;
 if(SQLCODE==SQLNOTFOUND) strcpy(c_ncreate," ");
 
 $SELECT nname INTO $c_nupdate
    FROM officer
   WHERE iofficer = $c_iupdate;
 if(SQLCODE==SQLNOTFOUND) strcpy(c_nupdate," ");

 cm_buf_init(ReplyBuf);
 cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
             M_CM_OK,c_iins_type,c_irate,c_iclass,c_cmp_provision,c_com_provision,c_iins_provision1,c_iins_provision2,c_iins_provision3,c_nremark,c_icreate,c_dcreate,c_iupdate,c_dupdate,c_ncreate,c_nupdate);


 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

 errexit:
   MsgCode = cm_show_sql_err("ca167_single_query", NULL);
  if(exitsub(reply,MsgCode) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car167_multiple_query(reply)
serverReply reply;
{
 $char DBName[5];
 $char iins_type[INSURANCE_TYPE],irate[5],iclass[2];
 $char stmt[1024],stmt1[128],stmt2[128],stmt3[128];
 $char c_iins_type[INSURANCE_TYPE],c_irate[5],c_iclass[2];

 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;

 cm_buf_get("%s %s %s %s",DBName,iins_type,irate,iclass);

 strcpy(iins_type,trim(iins_type));
 strcpy(irate,trim(irate));
 strcpy(iclass,trim(iclass));
 
 if ((strncmp(iins_type,"*",1)==0)){
     sprintf_s(stmt1, sizeof stmt1, "where iins_type matches '%s' ",iins_type);
 }else{
    sprintf_s(stmt1, sizeof stmt1, "where iins_type = '%s' ",iins_type);
  }   
 if ((strncmp(irate,"*",1)==0)){
    sprintf_s(stmt2, sizeof stmt2, "and irate matches '%s' ",irate);
 }else{
    sprintf_s(stmt2, sizeof stmt2, "and irate = '%s' ",irate);
  }   
   if ((strncmp(iclass,"*",1)==0)){
    sprintf_s(stmt3, sizeof stmt3, "and iclass matches '%s' ",iclass);
 }else{
    sprintf_s(stmt3, sizeof stmt3, "and iclass = '%s' ",iclass);
  }   

 printf("stmt1=[%s] stmt2=[%s] stmt3=[%s]\n",stmt1,stmt2,stmt3);
 
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

    sprintf_s(stmt, sizeof stmt, "SELECT iins_type, irate ,iclass "
                   " FROM ca_prov_irate "
                   " %s %s %s "
                " ORDER BY 1,2 desc",stmt1,stmt2,stmt3);
                
 $PREPARE rs FROM $stmt;
 $DECLARE q_cur CURSOR FOR rs;
 $OPEN q_cur;
 
 for(;;)
  {
    $FETCH q_cur INTO $c_iins_type,$c_irate,$c_iclass;
   
    if (SQLCODE != 0) break;
    
    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }


  /*  deccvasc( str_m_mprize, strlen(str_m_mprize), &dec_m_mprize);
    dectodbl( &dec_m_mprize, &d_m_mprize);   
    sprintf(str_m_mprize,"%.2f",d_m_mprize);*/
    cm_buf_put("%s %s %s",c_iins_type,c_irate,c_iclass);
    
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;

        if(replycnt > 5) sleep(3);
        else if(replycnt > 3) sleep(2);
        else if(replycnt > 1) sleep(1);

        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();

        /*sprintf(str_m_mprize,"%.2f",d_m_mprize);*/
        cm_buf_put("%s %s %s",c_iins_type,c_irate,c_iclass);

        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

 errexit:
   MsgCode = cm_show_sql_err("ca167_multiple_query", NULL);
   if(exitsub(reply,MsgCode) == True)
     return SQLCODE;
   else
     return apiRC;
}
/*-----------------------------------------------------------------*/

long car167_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
        
 $char DBName[5],userid[11];
 $char cur_iins_type[INSURANCE_TYPE],cur_irate[5],cur_iclass[2];
 $char cur_cmp_provision[6],cur_com_provision[6],cur_iins_provision1[6],cur_iins_provision2[6],cur_iins_provision3[6];
 $char cur_nremark[101];
 $char cur_icreate[11],cur_ncreate[11],cur_dcreate[20],cur_iupdate[11],cur_nupdate[11],cur_dupdate[20];
  
 $char u_iins_type[INSURANCE_TYPE],u_irate[5],u_iclass[5];
 $char u_cmp_provision[6],u_com_provision[6],u_iins_provision1[6],u_iins_provision2[6],u_iins_provision3[6];
 $char u_nremark[101];
 $char u_icreate[11],u_dcreate[20],u_iupdate[11],u_dupdate[20];
  
 $char q_iins_type[INSURANCE_TYPE],q_irate[5],q_iclass[5];
 /*$char q_cmp_provision[6],q_com_provision[6],q_iins_provision1[6],q_iins_provision2[6],q_iins_provision3[6];
 $char q_icreate[11],q_dcreate[20],q_iupdate[11],q_dupdate[20];*/
  
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len; long dummy;
 DBinfo *list;
 int i, j, is_del_fail=0, is_upd_fail=0;
 $char stmt_buf[300];

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

/*  if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
     return exitsub(reply,M_CM_NOT_DBLIST) ? M_CM_NOT_DBLIST : apiRC;  */

 memcpy(&raw_len,&comm[com_len],sizeof(int));
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)
  memcpy(raw_ptr,pos,raw_len);
 else
  { 
   return exitsub(reply,M_CM_NOT_MALLOC) ? M_CM_NOT_MALLOC : apiRC;
  }

 cm_buf_init(raw_ptr);          
 cm_buf_get("%l %s %s %s ",&dummy,q_iins_type,q_irate,q_iclass);

 $BEGIN WORK;
     
 $SELECT iins_type,irate,iclass,cmp_provision,com_provision,iins_provision1,iins_provision2,iins_provision3,nremark,icreate,dcreate,iupdate,dupdate
    INTO $cur_iins_type,$cur_irate,$cur_iclass,$cur_cmp_provision,$cur_com_provision,$cur_iins_provision1,$cur_iins_provision2,$cur_iins_provision3,$cur_nremark,$cur_icreate,$cur_dcreate,$cur_iupdate,$cur_dupdate
    FROM ca_prov_irate
   WHERE iins_type = $q_iins_type
     AND irate = $q_irate
     AND iclass = $q_iclass;

  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */

 if (SQLCODE == SQLNOTFOUND)
 {
   MsgCode = M_CM_NOT_FOUND;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
 }
 
 $SELECT nname INTO $cur_ncreate
    FROM officer
   WHERE iofficer = $cur_icreate;
 if(SQLCODE==SQLNOTFOUND) strcpy(cur_icreate," ");
 
 $SELECT nname INTO $cur_nupdate
    FROM officer
   WHERE iofficer = $cur_iupdate;
 if(SQLCODE==SQLNOTFOUND) strcpy(cur_nupdate," ");
 
 cm_buf_init(cur_buf);
 
 cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
             dummy,cur_iins_type,cur_irate,cur_iclass,cur_cmp_provision,cur_com_provision,cur_iins_provision1,cur_iins_provision2,cur_iins_provision3,cur_nremark,cur_icreate,cur_dcreate,cur_iupdate,cur_dupdate,cur_ncreate,cur_nupdate);

 write(1,raw_ptr,raw_len);
 write(1,"\n",1);
 write(1,cur_buf,raw_len);
 write(1,"\n",1);


 printf("cur_buf[%s]\n",cur_buf);
 printf("raw_ptr[%s]\n",raw_ptr);
 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
 {
   MsgCode = M_CM_NOT_EQUAL;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
 }

 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
 
    sprintf_s(stmt_buf, sizeof stmt_buf, "DELETE FROM ca_prov_irate "
                       " WHERE iins_type= ? AND irate = ? AND iclass = ?");
    $PREPARE d_id FROM $stmt_buf;

    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      
     }
    $EXECUTE d_id USING $q_iins_type,$q_irate,$q_iclass;
    
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      
     }

   if( is_del_fail ) goto errexit;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
   cm_buf_init(command);

   cm_buf_get("%c %s %s %s %s %s %s %s %s %s %s %s",
          &option,DBName,u_iins_type,u_irate,u_iclass,u_cmp_provision,u_com_provision,u_iins_provision1,u_iins_provision2,u_iins_provision3,u_nremark,userid);

   /* grasp old key */
   cm_buf_init(raw_ptr);

   cm_buf_get("%l %s %s %s ",&dummy,q_iins_type,q_irate,q_iclass);
   
   free(raw_ptr);

   $WHENEVER SQLERROR CONTINUE;

    sprintf_s(stmt_buf, sizeof stmt_buf,
               "UPDATE ca_prov_irate "
               "    SET (iins_type,irate,iclass,cmp_provision,com_provision,iins_provision1,iins_provision2,iins_provision3,nremark,iupdate,dupdate) "
               "    = (?,?,?,?,?,?,?,?,?,?,current) "
               "  WHERE iins_type = ? AND irate=? AND iclass=?"); 

    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
     
     }
                        
    $EXECUTE u_id USING  $u_iins_type,$u_irate,$u_iclass,$u_cmp_provision,$u_com_provision,$u_iins_provision1,$u_iins_provision2,$u_iins_provision3,$u_nremark,$userid,
                         $q_iins_type,$q_irate,$q_iclass;                        
                         
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      
     }
 
   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }
   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   MsgCode = M_CM_WRONG_OPTION;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
  }

errexit:
  MsgCode = SQLCODE;
  cm_show_sql_err("ca167_update_exec", stmt_buf);
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if(SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True)
   return MsgCode;
  else
   return apiRC;
}

long car167_insert_new_rate(reply)
serverReply reply;
{
$char DBName[5],DBName1[5];
$char LsBuffer0[1024],LsBuffer1[1024],LsBuffer2[1024],sFullName[20];
$char sFullName_sys[20];
$char old_irate[5],new_irate[5],userid[11];
$int cnt_pro = 0;
int LiBufLen;
	
	cm_buf_get("%s",DBName);
	cm_buf_get("%s %s %s ",old_irate,new_irate,userid);
	
	strcpy(old_irate,trim(old_irate));
	strcpy(new_irate,trim(new_irate));
	strcpy(userid,trim(userid));
	
	if (db_select(DBName) == False)
	return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
	
	$WHENEVER SQLERROR GOTO errexit;
	$BEGIN WORK;
	
	sprintf_s(LsBuffer1, sizeof LsBuffer1, "INSERT INTO ca_prov_irate "
			   " SELECT iins_type, '%s', iclass, cmp_provision, com_provision, iins_provision1, iins_provision2, iins_provision3, nremark, '%s',CURRENT,'%s',current,0 "
  			   " FROM ca_prov_irate "
			   " WHERE irate = '%s';",new_irate,userid,userid,old_irate);
	printf("i1[%s]\n\n",LsBuffer1);
	$PREPARE in_rate1 FROM $LsBuffer1;
	$EXECUTE in_rate1;

	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	LiBufLen = cm_buf_len(ReplyBuf);

	if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
	{
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		return apiRC;
	}
	
	$COMMIT WORK;
	return api_OKComplete;

	errexit:
	printf(" sqlerrm = %s\n",sqlca.sqlerrm);
	
$WHENEVER SQLERROR CONTINUE;
MsgCode = SQLCODE;
$ROLLBACK WORK;
if (SQLCODE != 0) MsgCode = SQLCODE;
return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}