/**********************************************************************/
/*   program id   : ca731q01s.ec                                      */
/*   program name : �~�Ȩӷ����Ӫ�                                    */
/*   date written : 2005/10/27                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : Jessie                                            */
/*   files        : ply_relation        i                             */
/*                  policy              i                             */
/*   temp table   : car731              io                            */
/*   Checked for ����100�~�M��                                        */
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"

/*--------------------------------------------------------------------*/
$char dbgn1[11], dend1[11], dbgn2[11], dend2[11], iins_type[7];
$char Ipolicy[21],Nassured[121],Icar_type[3],Ipolicy3[5],sIpolicy3[4];
$char Iofficer[11],Ileader[11],Ibig_office[10],sIlast_ply[21],sNequipment[9];
$long Dpolicy,Dply_begin,Dply_end;
$long mdmg_prem = 0,mlia_prem = 0,mdmg_disc = 0,mlia_disc = 0;
$double pdmg_disc,plia_disc;
$char Nbranch[40],Iquota[10],icode[11];
char  dtype[1],tit_dtype[8],ctype[1],paycheck[1];
$char iissue_ym[7],ipro_year[5],iengine[CA_ENGINE_NUM],ibrand[9],nbrand[31];
$char itag[CA_TAG_NUM],itel[21];
$char nofficer[11],ibig_comp[2];
char  fymark[90][2];
char  msgbuf[1000];
$char iassured[13];
$char iassured_ext[3];
$char tphone_con[21],imovephone[21];
$char Astmp[256];

$char iresource[2];
$char ileader[11],nname[11];
$char fedr_class[11],dendorse[11];
$char fassured[2];
$char ncode[30],F_ncode[30];
$char DBName[05],DBData[05];
char  outputf[N_FILE+1];
$char userid[11];
$char ibig_sales[11],s_name[21];
$char iins_cnt[3];
int   cnt;

/* AOI ao_chk_charge */
$int  ibatch_no = 0;
char  tmp_ibatch_no[3];
char  ao_policy1[POLICY_NUM_1], ao_policy2[CA_TARGET_NUM];
char  a0result[3], a0comment[31], a0date1[9], a0date2[9];
$char ao_note[2];
$char falldb[2];
$char stmt_tmp[2048];

/* for �q���ϥ� */
$char iroute[21];

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;
   int i,k,n;

   batchinit();
   strcpy(DBName,   isNULLstr(argv[1]));
   strcpy(userid,   isNULLstr(argv[2]));
   strcpy(dbgn2,    isNULLstr(argv[3]));
   strcpy(dend2,    isNULLstr(argv[4]));
   strcpy(dtype,    isNULLstr(argv[5]));
   strcpy(iins_cnt, isNULLstr(argv[6]));
   cnt = atoi(iins_cnt);

   for(i=0;i<90;i++)
      fymark[i][0]='\0'; 

   k=6;
   for(i=0;i<cnt;i++) {
      k++;
      strncpy(fymark[i],isNULLstr(argv[k]),1);
      fymark[i][1]='\0';
   }

   k++;
   strcpy(ctype,    isNULLstr(argv[k]));
   k++;
   strcpy(icode,    isNULLstr(argv[k]));
   k++;
   strcpy(paycheck, isNULLstr(argv[k]));
   k++;
   strcpy(DBData,   isNULLstr(argv[k])); /* ���Ū����DBName */
   k++;
   strcpy(outputf,  isNULLstr(argv[k]));

   printf("116  k = [%d] outputf=[%s]\n",k,outputf);
   strcpy(dbgn1, cm_to_infdate(dbgn2));
   strcpy(dend1, cm_to_infdate(dend2));

   rc = car731_get_db();
   if (rc != M_CM_OK)
       return rc;

   rc = car731_check_id();
   if (rc != M_CM_OK)
       return rc;

   rc = car731_accumulate();
   if (rc != M_CM_OK)
       return rc;

   rc = car731_build();
   if (rc != M_CM_OK)
       return rc;
}

/*--------------------------------------------------------------------*/
long car731_get_db()
{
    /* ��db_select�O��Ū���v�� */
    if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN; }

    return M_CM_OK;
}
/*--------------------------------------------------------------------*/
long car731_build()
{
 char  sfilename[41],stitle[1024],stmt[81];
 int rc;

    $whenever sqlerror goto errexit;

    strcpy(sfilename,"�~�Ȩӷ����Ӫ�");
    strcpy(stitle,"�{���N��:CAR731\t");
    strcat(stitle,sfilename);
    if (dtype[0]=='1') {
       strcat(stitle,"\t\tñ����:");
       strcat(stitle,dbgn1);
       strcat(stitle,"��");
       strcat(stitle,dend1);
       strcat(stitle,"\t\t\t�s�����:");
       strcat(stitle,cm_get_sysd());
       strcat(stitle,"\n");
       strcat(stitle,"\t");
    }
    else {
       strcat(stitle,"\t\t������:");
       strcat(stitle,dbgn1);
       strcat(stitle,"��");
       strcat(stitle,dend1);
       strcat(stitle,"\t\t\t�s�����:");
       strcat(stitle,cm_get_sysd());
       strcat(stitle,"\n");
       strcat(stitle,"\t");
    }
    strcat(stitle,"���N�X\t�e�O�渹\t���O\t�O�渹�X\t�Q�O�I�H\t����\t�g��H\t");
    strcat(stitle,"�g��W��\t�޲z�H\t�޲z�H�m�W\t��~���I\t�~�N�N��\t�~�N�m�W\t");
    strcat(stitle,"ñ����\t�_�O���\t������\t���l�O�O\t���d�O�O\t");
    strcat(stitle,"�~�Z���\t�o�Ӧ~��\t�s�y�~��\t�������X\t�P�Ӹ��X\t");
    strcat(stitle,"�t�P����\t�t���W��\t�~�Ȩӷ�\t�Ȥᨭ��\t�q��(��)\t");
    strcat(stitle,"�q��(�])\t�q��(���)\t���l�u�f�v\t���d�u�f�v\t");
    strcat(stitle,"������\t�����\tú�O���O\t�q���N��\t");
    
    strcpy(stmt,"select * from car731 order by ipolicy");
    rc = unload_file(outputf," ",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car731_accumulate()
{
$char stmpA[2048],stmpB[100],str[5],stmpC[512],stmpD[100];
int   rc,ply_cnt;
$int  flag,i,j,yy,kk;

    $whenever sqlerror goto errexit;

    if (db_select(DBData) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN; }

    rc = car731_create_temp();
    if (rc != M_CM_OK)
       return rc;

    printf("dtype[%s]\n",dtype);
    if (strncmp(dtype,"1",1)==0) {
        sprintf_s(stmpB, sizeof stmpB,"a.dpolicy >= '%s' and a.dpolicy <= '%s' ",
                dbgn1,dend1);
    }
    else {
        sprintf_s(stmpB, sizeof stmpB,"a.dply_end >= '%s' and a.dply_end <= '%s' ",
                dbgn1,dend1);
    }
    printf("ctype[%s]\n",ctype);
    if (strncmp(ctype,"1",1)==0)
        sprintf_s(stmpC, sizeof stmpC,"and a.iquota matches '%s*' ",trim(icode));
    else
        sprintf_s(stmpC, sizeof stmpC,"and a.iofficer matches '%s' %s ",icode,Astmp);

    /* �~�Ȩӷ����� */
    if (cnt ==0)
       strcpy(stmpD," ");
    else if (cnt==1)
       sprintf_s(stmpD, sizeof stmpD,"and a.iresource = '%s' ",fymark[0]);
    else {
       sprintf_s(stmpD, sizeof stmpD,"and a.iresource in ('%s'",fymark[0]);
       for(i=1;i<cnt;i++)
          sprintf_s(stmpD, sizeof stmpD,"%s,'%s'",rtrim(stmpD),fymark[i]);
       strcat(stmpD,")");
    }
    printf("stmpD[%s]\n",stmpD);
          
    ply_cnt=0;
    /*--- Ū���O���� ---*/
    sprintf_s(stmpA, sizeof stmpA,
        "select a.ipolicy,b.nassured[1,30],a.icar_type,  "
                "a.iofficer,a.ileader,a.ibig_office,a.dpolicy,  "
                "a.dply_begin,a.mdmg_prem,a.mlia_prem,a.mdmg_discount,  "
                "a.mlia_discount,a.iquota[1,4] || '00',dply_end,  "
                "to_char(dissue,'%%Y')::integer - 1911 || '/' || to_char(dissue,'%%m'),  "
                "ipro_year,iengine,ibrand,d.nname,a.ibig_sales,  "
                "fassured,iresource,decode(fedr_class,'1','���P', "
                "'2','�L��','4','�h���h�O','5','�@����', "
                "'6','���B���','9','����',' '),a.dendorse,  "
                "a.ibig_comp, ibatch_no,b.itag,b.itel,  "
                "b.iassured,b.iassured_ext,b.iroute,a.ipolicy[1,3],a.ilast_ply,  "
                "decode(b.nequipment[7],'2','��Oú��','3','��Oú��','6','��Oú��', "
                "'7','��Oú��',' ')  "
           "from ply_relation a,policy b,officer d  "
          "where %s %s %s  "
            "and a.fcard_class = '2'  "
            "and a.dply_close is not null  "
            "and a.ipolicy = b.ipolicy  "
            "and a.iofficer = d.iofficer ", stmpB, stmpC, stmpD);
    printf("stmpA[%s]\n",stmpA);
    $prepare preA from $stmpA;
    $declare curA cursor for preA;
    $open curA;
                
    while(1){
        $fetch curA
         into $Ipolicy,$Nassured,$Icar_type,
              $Iofficer,$Ileader,$Ibig_office,$Dpolicy,
              $Dply_begin,$mdmg_prem,$mlia_prem,$mdmg_disc,
              $mlia_disc,$Iquota,$Dply_end,
              $iissue_ym,$ipro_year,$iengine,$ibrand,$nofficer,
              $ibig_sales,$fassured,$iresource,$fedr_class,$dendorse,
              $ibig_comp,$ibatch_no,$itag,$itel,$iassured,$iassured_ext,$iroute,
              $sIpolicy3,$sIlast_ply,$sNequipment;
         if (SQLCODE==SQLNOTFOUND) break;
         
         strcpy(Ipolicy3, "�");
         strcat(Ipolicy3,trim(sIpolicy3));
         ply_cnt++;
         printf("ipolicy[%s] \n",Ipolicy);

         if (mdmg_prem==0)
             pdmg_disc=0;
         else
             pdmg_disc = (double)mdmg_disc / ((double)mdmg_prem +
                         (double)mdmg_disc) * 100;

         if (mlia_prem==0)
             plia_disc=0;
         else
             plia_disc = (double)mlia_disc / ((double)mlia_prem +
                         (double)mlia_disc) * 100;

         $SELECT tphone_con,imovephone
            INTO $tphone_con,$imovephone
            FROM cu_customer
           WHERE ifpce_id     = $iassured
             AND ifpce_id_ext = $iassured_ext;
              if (SQLCODE == SQLNOTFOUND) {
                 strcpy(tphone_con," ");
                 strcpy(imovephone," ");
              }

         $SELECT nbranch
            INTO $Nbranch
            FROM sa_branch_type
           WHERE ibranch = $Iquota;

        if (strncmp(ibig_sales," ",1)!=0) {
           if (strncmp(ibig_comp," ",1) != 0) {
              $select nname
                 into $s_name
                 from ca_big_office
                where ibig_comp = $ibig_sales 
                  and fclass = '2';
              if (SQLCODE == SQLNOTFOUND) 
                 strcpy(s_name," ");  
           }
           else {
              $select nchi_full[1,10]
                 into $s_name
                 from cu_customer
                where ifpce_id = $ibig_sales
                  and ifpce_id_ext = ' ';
              if (SQLCODE == SQLNOTFOUND) {
                 $select nsales
                    into $s_name
                    from cm_route_sales
                   where iroute = $iroute
                     and isales = $ibig_sales;
                 if (SQLCODE == SQLNOTFOUND) 
                    strcpy(s_name," ");  
              }
           }
        }
        else strcpy(s_name," ");

        /* �t�P�������� */
        $declare curA1 cursor for
         select ipro_year, nbrand
           into $str, $nbrand
           from ca_car_model
          where ibrand = $ibrand
          order by ipro_year desc;
        $open curA1;
        $fetch curA1;
        if (SQLCODE==SQLNOTFOUND) strcpy(nbrand,"*****");
        $close curA1;
        $free  curA1;

       /* �޲z�H���� */
        $SELECT nname
           INTO :nname
           FROM officer
          WHERE iofficer = :Ileader;
      
      /* �Ȥᨭ������ */
        $SELECT ncode
            INTO :F_ncode
            FROM cu_code_data
           WHERE itype='09'
             AND icode=:fassured;

      /* �~�Ȩӷ����� */
        $SELECT ncode
           INTO :ncode
           FROM cu_code_data
          WHERE itype='10'
            AND icode=:iresource;
        
        /* ���O���O */
        if (paycheck[0]=='1') {
        memset (tmp_ibatch_no, 0, sizeof (tmp_ibatch_no));
        if (ibatch_no == 0)
            strcpy(tmp_ibatch_no, " ");
        else
            sprintf_s(tmp_ibatch_no, sizeof tmp_ibatch_no,"%d",ibatch_no);
            
        rc = split_policy(Ipolicy, ao_policy1, ao_policy2);
        if ( rc != M_CM_OK )
           return rc;
             
        ao_chk_charge(DBName,'1',ao_policy1,ao_policy2,tmp_ibatch_no,
                      a0result, a0comment, a0date1, a0date2);

        printf("a0result[%s]\n",a0result);
        
        if( a0result[0] == 'R' )
            strcpy( ao_note , "Y" );
        else  
            strcpy( ao_note , "N" );
        }
        else
            strcpy( ao_note , " " );
          
        car731_insert_temp();
    }
    $close curA;
    $free  curA;
    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car731_insert_temp()
{
    $whenever sqlerror goto errexit;

    $insert into car731 values
    ($Ipolicy3,$sIlast_ply,$sNequipment,$Ipolicy,$Nassured,$Icar_type,
     $Iofficer,$nofficer,$Ileader,$nname,$Ibig_office,$ibig_sales,$s_name,
     $Dpolicy,$Dply_begin,$Dply_end,$mdmg_prem,$mlia_prem,
     $Nbranch,$iissue_ym,$ipro_year,$iengine,$itag,
     $ibrand,$nbrand,$ncode,$F_ncode,$itel,$tphone_con,
     $imovephone,$pdmg_disc,$plia_disc,$fedr_class,
     $dendorse,$ao_note,$iroute);
    
    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car731_create_temp()
{
    $whenever sqlerror goto errexit;

    sprintf_s(stmt_tmp, sizeof stmt_tmp,"create temp table car731 "
     "( "
      " ipolicy3     char(4), "
      " ilast_ply    char(20), "
      " nequipment   char(8), "
      " ipolicy      char(20), "
      " nassured     char(30), "
      " icar_type    char(2), "
      " iofficer     char(10), "
      " nofficer     char(10), "
      " ileader      char(10), "
      " nleader      char(10), "
      " ibig_office  char(9), "
      " ibig_sales   char(10), "
      " nbig_sales   char(10), "
      " dpolicy      date, "
      " dply_begin   date, "
      " dply_end     date, "
      " mdmg_prem    integer, "
      " mlia_prem    integer, "
      " nquota       char(40), "
      " iissue_ym    char(6), "
      " ipro_year    char(4), "
      " iengine      char(%d), "
      " itag         char(%d), "
      " ibrand       char(8), "
      " nbrand       char(40), "
      " iresource    char(20), "
      " fassured     char(20), "
      " tel_day      char(20), "
      " tel_night    char(20), "
      " tel_move     char(20), "
      " pdmg_disc    decimal(4,2), "
      " plia_disc    decimal(4,2), "
      " fedr_class   char(10), "
      " dendorse     date, "
      " ipay         char(1), "
      " iroute       char(20)) "
      " with no log;",CA_ENGINE_NUM-1,CA_TAG_NUM-1);
     $PREPARE stmp FROM $stmt_tmp;
     $EXECUTE stmp;


    $create unique index car731_ix on
     car731(ipolicy);

    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car731_check_id()
{
$char  user_iqu[7],group[4];
$int   fadu,cnt_iqu = 0;

   /* 
      �v���� -- privilege
      ���ٸ�Ʈw falldb =Y �i�d�Ӹ�Ʈw�Ҧ����,�B��������϶�
      �H�U������w���P�@�~��
      �d��       fadu   =0 �i�d�ϥΪ̸ӳ��
      �s�W       fadu   =1 �i�d�ϥΪ̤��Ұ�
      ��       fadu   =2 �i�d�Ӹ�Ʈw�Ҧ���� 
   */

   $whenever sqlerror goto errexit;

   strcpy(Astmp," ");

   $select falldb,fadu
      into $falldb,$fadu
      from privilege
     where iemp = $userid
       and ipgid = 'car731';
   if (SQLCODE==SQLNOTFOUND) {
      strcpy(falldb,"N");
      fadu = 0;
   }
   printf("falldb[%s]fadu[%d]\n",falldb,fadu);
   if (falldb[0]=='Y')  return M_CM_OK;
   if (strncmp(dbgn2,dend2,5)!=0) {
      strcpy(msgbuf,"����϶����w�P�@�Ӥ�,�Э��s��J���");
      EWRITE(userid,10,msgbuf);
      return 10;
   }
   if (fadu >= 2) return M_CM_OK;
   if (strncmp(icode,"*",1)==0) {
      strcpy(msgbuf,"�L�d�ߥ������v��,�п�J�S�w���θg��N��"); 
      EWRITE(userid,20,msgbuf);
      return 20;
   }
   $select iquota,group2
      into $user_iqu,$group
      from officer a,sa_branch_type b
     where iofficer = $userid
       and iquota = b.ibranch;
   if (SQLCODE==SQLNOTFOUND) {
      strcpy(msgbuf,"�ϥΪ̥N���D�g��N��,�L�k�d�߸��");
      EWRITE(userid,30,msgbuf);
      return 30;
   }
   if (fadu == 1) {
      if (ctype[0]=='1') {
         $select count(*) into $cnt_iqu
            from sa_branch_type
           where group2 = $group
             and ibranch matches $icode; 
         if (cnt_iqu ==0) {
            strcpy(msgbuf,"�L�v���d�ߨ�L��줧���");
            EWRITE(userid,40,msgbuf);
            return 40;
         }
      }
      else {
         sprintf_s(Astmp, sizeof Astmp,"and a.iquota in (select ibranch from sa_branch_type  "
                      " where group2 = '%s') ",group); 
      }
   }
   else {
      if (ctype[0]=='1') {
         if (strncmp(icode,user_iqu,4)!=0) {
            strcpy(msgbuf,"�L�v���d�ߨ�L��줧���");
            EWRITE(userid,40,msgbuf);
            return 40;
         }
      }
      else {
         sprintf_s(Astmp, sizeof Astmp,"and a.iquota[1,4] = '%s' ",substring(user_iqu,1,4));
      }
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*---------------------------------------------------------end program*/
