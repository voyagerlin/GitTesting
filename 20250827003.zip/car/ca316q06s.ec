/**********************************************************************/
/*   ���I��O�����έp��                              			      */
/*   PROGRAM : car316q06s.ec                       			          */
/*   DATE    : 102.01.22                 		            	      */
/**********************************************************************/
/*   �s�W�j���I�A�åi��ܨT�����O                                     */
/*       �U�������Y�s�W"(�j���I)"�r��                                 */
/*********************************************************************/

#include <stdio.h>
#include <string.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"

#define  head_line         1
#define  data_line         2

extern char RPTDIR[];

$char quota[6],type[2];
$char dclose[11],dclose_end[11],dopen[11],dopen_end[11];
$static char dbgn1[11], dend1[11];
$static char dbgn_inf[11], dend_inf[11];
$char itag_old[CA_TAG_NUM];
char  MsgCode[50];

$char DBName[5], iForm_Tp[3];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[N_FILE+1], userid[11];

$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;
char  fcar_type[2];
$char sTitle[11];

int  max_cnt;

long car316_build1();
long car316_build2();
long car316_build3();
long car316_build4();
long car316_build5();
long car316_build6();
long car316_build7();
long car316_build8();
long car316_body1();
long car316_body2();
long car316_body3();
long car316_body4();
long car316_body5();
long car316_body6();
long car316_body7();
long car316_body8();
long car316_accumulate();
double d45();
void car316_title();  
char *getdate();
char *setdate();

main(argc, argv)
int argc;
char **argv;
{
   int rc,str_len;

   batchinit();
   strcpy(DBName,  isNULLstr(argv[1]));
   strcpy(userid,  isNULLstr(argv[2]));
   strcpy(dbgn1,   isNULLstr(argv[3]));
   strcpy(dend1,   isNULLstr(argv[4]));
   strcpy(dopen,   isNULLstr(argv[5]));
   strcpy(dclose,  isNULLstr(argv[6]));
   strcpy(fcar_type,  isNULLstr(argv[7]));

   strcpy(outputf, isNULLstr(argv[8]));

   strcpy(dbgn_inf,   cm_to_infdate(dbgn1));
   strcpy(dend_inf,   cm_to_infdate(dend1));
   strcpy(dopen_end,  cm_to_infdate(dopen));
   strcpy(dclose_end, cm_to_infdate(dclose));

   rc = car316_accumulate();

   if ( rc != M_CM_OK)
   {
        EWRITE(userid, rc, " ");
        return rc;
   }

   max_cnt=0;
   if (fcar_type[0] == '1' ){             /* �T�� */
       strcpy(sTitle,"�T���j���I");
   }else if (fcar_type[0] == '2' ){      /* ���� */
   	   strcpy(sTitle,"�����j���I");
   }else{
   	   strcpy(sTitle,"�j���I");
   }
   strcpy(MsgCode," ");
   rc = car316_build1(); /****  �O�N�� ****/
   if (rc != M_CM_OK)
   {
       if (MsgCode[0]==' ')
           EWRITE(userid, rc, " ");
       else
           EWRITE(userid, rc, MsgCode);
       return rc;
   }

   strcpy(MsgCode," ");
   rc = car316_build2(); /**** �@��� ****/
   if (rc != M_CM_OK)
   {
       if (MsgCode[0]==' ')
           EWRITE(userid, rc, " ");
       else
           EWRITE(userid, rc, MsgCode);
       return rc;
   }

   strcpy(MsgCode," ");
   rc = car316_build3(); /**** �@��� + �O�N�� (�~�Ȩӷ�)****/
   if (rc != M_CM_OK)
   {
       if (MsgCode[0]==' ')
           EWRITE(userid, rc, " ");
       else
           EWRITE(userid, rc, MsgCode);
       return rc;
   }

   strcpy(MsgCode," ");
   rc = car316_build4(); /**** �^�k����� ****/
   if (rc != M_CM_OK)
   {
       if (MsgCode[0]==' ')
           EWRITE(userid, rc, " ");
       else
           EWRITE(userid, rc, MsgCode);
       return rc;
   }

   strcpy(MsgCode," ");
   rc = car316_build5(); /**** �@������ ****/
   if (rc != M_CM_OK)
   {
       if (MsgCode[0]==' ')
           EWRITE(userid, rc, " ");
       else
           EWRITE(userid, rc, MsgCode);
       return rc;
   }

   strcpy(MsgCode," ");
   rc = car316_build6(); /****�O�N����� ****/
   if (rc != M_CM_OK)
   {
       if (MsgCode[0]==' ')
           EWRITE(userid, rc, " ");
       else
           EWRITE(userid, rc, MsgCode);
       return rc;
   }

   /****�O�N����� 

   strcpy(MsgCode," ");
   rc = car316_build7();
   if (rc != M_CM_OK)
   {
       if (MsgCode[0]==' ')
           EWRITE(userid, rc, " ");
       else
           EWRITE(userid, rc, MsgCode);
       return rc;
   }
   ****/
   
   strcpy(MsgCode," ");
   rc = car316_build8();
   if (rc != M_CM_OK)
   {
       if (MsgCode[0]==' ')
           EWRITE(userid, rc, " ");
       else
           EWRITE(userid, rc, MsgCode);
       return rc;
   }
   
}

long car316_build1()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   int    rc;

   max_cnt = 0;

   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 316
       AND iForm_Tp = '1';

   strcpy(TitleFmt,rtrim(TitleFmt));
   sprintf(TitleFile,"%sA.ti",outputf);  
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf(BodyFile, "%sA.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car316_title();                        
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);

   rc = car316_body1(); /**** �O�N�� ****/

   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();


   create_sign_form("car316", BodyFile, Width);

   if ((rc=save_form_info(F_BLK1, "CA", 316, userid, iForm_Tp, max_cnt, outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }

   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

long car316_build2()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   int    rc;

   max_cnt = 0;

   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 316
       AND iForm_Tp = '2';

   strcpy(TitleFmt,rtrim(TitleFmt));
   sprintf(TitleFile,"%sB.ti",outputf);  
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf(BodyFile, "%sB.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car316_title();                        
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);

   rc = car316_body2(); /**** �@��� ****/

   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();


   create_sign_form("car316", BodyFile, Width);

   if ((rc=save_form_info(F_BLK1, "CA", 316, userid, iForm_Tp, max_cnt, outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }

   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

long car316_build3()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   int    rc;

   max_cnt = 0;

   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 316
       AND iForm_Tp = '3';

   strcpy(TitleFmt,rtrim(TitleFmt));
   sprintf(TitleFile,"%sC.ti",outputf);  
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf(BodyFile, "%sC.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car316_title();                        
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);

   rc = car316_body3(); /**** total ****/

   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();

   create_sign_form("car316", BodyFile, Width);

   if ((rc=save_form_info(F_BLK1, "CA", 316, userid, iForm_Tp, max_cnt, outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }

   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

long car316_build4()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   int    rc;

   max_cnt = 0;

   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 316
       AND iForm_Tp = '4';

   strcpy(TitleFmt,rtrim(TitleFmt));
   sprintf(TitleFile,"%sD.ti",outputf);  
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf(BodyFile, "%sD.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car316_title();                        
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);

   rc = car316_body4(); /**** �^�k�� ****/

   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();


   create_sign_form("car316", BodyFile, Width);

   if ((rc=save_form_info(F_BLK1, "CA", 316, userid, iForm_Tp, max_cnt, outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }

   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car316_build5()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   int    rc;

   max_cnt = 0;

   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 316
       AND iForm_Tp = '5';

   strcpy(TitleFmt,rtrim(TitleFmt));
   sprintf(TitleFile,"%sE.ti",outputf);  
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf(BodyFile, "%sE.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car316_title();                        
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);

   rc = car316_body5(); /**** �@��� ****/

   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();


   create_sign_form("car316", BodyFile, Width);

   if ((rc=save_form_info(F_BLK1, "CA", 316, userid, iForm_Tp, max_cnt, outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }

   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car316_build6()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   int    rc;

   max_cnt = 0;

   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 316
       AND iForm_Tp = '11';

   strcpy(TitleFmt,rtrim(TitleFmt));
   sprintf(TitleFile,"%sF.ti",outputf);
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf(BodyFile, "%sF.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car316_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);

   rc = car316_body6(); /**** �O�N�� ****/

   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();


   create_sign_form("car316", BodyFile, Width);

   if ((rc=save_form_info(F_BLK1, "CA", 316, userid, iForm_Tp, max_cnt, outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }

   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car316_build7()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   int    rc;

   max_cnt = 0;

   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 316
       AND iForm_Tp = '11';

   strcpy(TitleFmt,rtrim(TitleFmt));
   sprintf(TitleFile,"%sH.ti",outputf);
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf(BodyFile, "%sH.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car316_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);

   rc = car316_body7(); /**** �O�N�� ****/

   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();

   create_sign_form("car316", BodyFile, Width);

   if ((rc=save_form_info(F_BLK1, "CA", 316, userid, iForm_Tp, max_cnt, outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }

   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

long car316_build8()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];

   int    rc;

   max_cnt = 0;

   $WHENEVER SQLERROR GOTO errexit;

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt,  $StartRow,  $TitleRow,  $ItemRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 316
       AND iForm_Tp = '13';

   strcpy(TitleFmt,rtrim(TitleFmt));
   sprintf(TitleFile,"%sG.ti",outputf);  
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf(BodyFile, "%sG.bd",outputf);

   rgu_init_report(TitleFmt,TitleFile);
   car316_title();                        
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);

   rc = car316_body8(); /**** �@���b¾���u ****/

   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();


   create_sign_form("car316", BodyFile, Width);

   if ((rc=save_form_info(F_BLK1, "CA", 316, userid, iForm_Tp, max_cnt, outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   }

   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*-----------------------------------------------------------------*/
long car316_accumulate()
{
   $char tmp_fulldb[40], stmt[4096], db_ibranch[3], stmt1[4096], stmt2[4096];
   $char itop[2], idealer[4], iofficer[11], iresource[2], dissue[11];
   $char iresource_1[2], iresource_2[2], imgr[2], imgr_t[2];
   $char itop_t[2], idealer_t[4], iofficer_t[11], iresource_t[2], dissue_t[11];
   $char inext_ply[21], fcard_class[2], ins_type[INSURANCE_TYPE], fedr_class[2], tmp_year[4];
   $char iofficer_o[11], iofficer_n[11], idealer_n[4], iissue_yy[4], t_yy[5];
   $char iofficer_1[11], iofficer_2[11], dendorse[11], iedr_type[3];
   $char ipolicy[21], iquota[7], iquota_t[7], iquota_n[7], iofficer_old[11];
   $long prem_t, prem, con_cnt;
   $long mdamage_cover;
   $int  id1,id2,id3,id4, myear, mark, t_year, o_year, mark_edr;

   $char stmt3[4096], stmt4[4096];
   $char LHsIquota[7], LHsItop[2], LHsIofficer[11], LHsIresource[2];
   $char LHsIlast_ply[11], LHsIdealer[4];
   $char ori_dply_end[11];
   $char tmp_dply_end[11];
   $char deffect[11];
   $int  ricnt,clmcnt, dmove_type;
   $char move_date[11], move_type[3], id_no[11];
   $char next_dpolicy[11];
   $char iquota_1[7],iquota_2[7];
   $char iquota_old[7];
   $char iofficer_un[11];
   $char iengine[CA_ENGINE_NUM],iengine_t[CA_ENGINE_NUM],nassured[13];
   $char iassured_old[11],iassured_t[11],itag_t[CA_TAG_NUM],nassured_t[13];
   $char CD_iofficer[11];
   $char iofficer_next[11],ileader[11];
   $long duty_date, dstatic;
   $char char_duty_date[11], tmp_duty_date[11];
   $char dudate[11];
   $char ori_dply_begin[11],new_dply_begin[11],ori_dpolicy[11],new_dpolicy[11];
   $char ori_ibigsales[11],new_ibigsales[11];
  /* $char sequip_str[201];*/
   $char iexpire[3], iquota_tmp[10], ileader_ori[11];
   $long dperiod;   /* Modified by Julia in 2007/01/17 */
   $int  iPAflag;
   $int  iMotorflag;
   $char icode_tap[21];
   $char iroute[21];
   $char iroute_t[21];
   $char ibroker[11];
   $char ibroker_t[11];
   $char str_car_type[101];
   int   rtncode = 0, LiFlag = 0;
   int   k,count_db;
   DBinfo *list;
   iMotorflag = 0;

   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

   if (db_select(DBName) == False)
   {
       return M_CM_DB_NOTOPEN;
   }

   /**** �O�N��, �@��������� ****/

   $CREATE TEMP TABLE CAR316
    ( 
      iofficer          char(10) not null,
      iquota            char(6) not null,
      iresource         char(01) not null,
      ipolicy           char(20) not null,
      myear             integer default 0 not null,
      inext_ply         char(20),
      con_cnt           integer      default 0 not null,
      prem              decimal(10,0) default 0 not null,
      iexpire           char(2) default ' '
    ) WITH NO LOG;

   $CREATE TEMP TABLE CAR316_NEW
    ( 
      iofficer          char(10) not null,
      iquota            char(6) not null,
      iresource         char(01) not null,
      ibroker           char(10) ,
      iPAflag           integer  not null,
      iMotorflag        integer  not null,
      ipolicy           char(20) not null,
      myear             integer default 0 not null,
      inext_ply         char(20),
      con_cnt           integer      default 0 not null,
      prem              decimal(10,0) default 0 not null,
      iexpire           char(2) default ' '
    ) WITH NO LOG;

   /**** �^�k���� ****/

   $CREATE TEMP TABLE CAR316_TMP
    ( 
      iofficer          char(10) not null,
      iquota            char(6) not null,
      iofficer_t        char(10) not null,
      iquota_t          char(6) not null,
      ipolicy           char(20) not null,
      dissue            date default null,
      inext_ply         char(20),
      con_cnt           integer      default 0 not null,
      prem              decimal(10,0) default 0 not null
    ) WITH NO LOG;

   /**** �@����� ****/

   $CREATE TEMP TABLE CAR316_TMP1
    ( 
      iofficer          char(10) not null,
      iquota            char(6)  not null,
      iofficer_t        char(10) not null,
      iquota_t          char(6)  not null,
      iofficer_old      char(10) not null,
      iquota_old        char(6)  not null,
      ipolicy           char(20) not null,
      dissue            date default null,
      inext_ply         char(20),
      con_cnt           integer      default 0 not null,
      prem              decimal(10,0) default 0 not null,
      iresource         char(1),
      iresource_t       char(1),
      nassured          char(12),
      iengine           char(25),
      iengine_t         char(25),
      iexpire           char(2) default ' '
    ) WITH NO LOG;

   /**** �O�N���� ****/

   $CREATE TEMP TABLE CAR316_TMP2
    (
      iofficer          char(10) not null,
      iquota            char(6)  not null,
      dply_begin        char(10) not null,
      dpolicy           char(10) not null,
      ibig_sales        char(10) ,
      iofficer_t        char(10) not null,
      iquota_t          char(6)  not null,
      dply_begin_t      char(10) not null,
      dpolicy_t         char(10) not null,
      ibig_sales_t      char(10) ,
      iofficer_old      char(10) not null,
      iquota_old        char(6)  not null,
      itag_old          char(12)  default ' ',
      ipolicy           char(20) not null,
      dissue            date default null,
      inext_ply         char(20),
      con_cnt           integer      default 0 not null,
      prem              decimal(10,0) default 0 not null,
      iresource         char(1),
      iresource_t       char(1),
      nassured          char(12),
      iengine           char(25),
      iengine_t         char(25),
      itag_t            char(12),
      nassured_t        char(12),
      iassured_old      char(10),
      iassured_t        char(10)

    ) WITH NO LOG;

   $CREATE TEMP TABLE CAR316_TMP3
    (
      iofficer          char(10) default ' ',
      iquota            char(6)  default ' ',
      dply_begin        char(10) default ' ',
      dpolicy           char(10) default ' ',
      ibig_sales        char(10) default ' ',
      iofficer_t        char(10) default ' ',
      iquota_t          char(6)  default ' ',
      dply_begin_t      char(10) default ' ',
      dpolicy_t         char(10) default ' ',
      ibig_sales_t      char(10) default ' ',
      iofficer_old      char(10) default ' ',
      iquota_old        char(6)  default ' ',
      itag_old          char(12)  default ' ',
      ipolicy           char(20) default ' ',
      dissue            date     default null,
      inext_ply         char(20) default ' ',
      con_cnt           integer       default 0 ,
      prem              decimal(10,0) default 0 ,
      iresource         char(1),
      iresource_t       char(1),
      nassured          char(12),
      iengine           char(25),
      iengine_t         char(25),
      itag_t            char(12),
      nassured_t        char(12),
      iassured_old      char(10),
      iassured_t        char(10)
    ) WITH NO LOG;

   strcpy(fcard_class, "1");       /* �j���I */
   
   if (fcar_type[0] == '1' ){      /* �T�� */
   	   strcpy(str_car_type," AND a.icar_type not in ('01','02','32','34','35') ");
   }else if(fcar_type[0] == '2'){  /* ���� */
   	   strcpy(str_car_type," AND a.icar_type in ('01','02','32','34','35') ");
   }else if(fcar_type[0] == '3'){  /* ���� */
       strcpy(str_car_type," ");	
   }
   printf("trace fcar_type[%s]\n ",fcar_type); 
   printf("trace str_car_type[%s]\n ",str_car_type);
   id1 = 0;

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;

   }

   for(k=0;k<count_db;k++)
   {

     /****
      sprintf(stmt,
    "  SELECT count(*)                            \
         FROM %s:policy a,%s:reject_client b      \
        WHERE a.ilicense = b.ilicense             \
          AND NVL(b.ilicense,' ') != ' '          \
          AND b.freason = '1'                     \
          AND a.fassured IN ('1','3','5')         \
          AND a.ipolicy = ? ",list[k].dbname,list[k].dbname);
     $PREPARE ridv FROM $stmt;
      ****/

     sprintf(stmt,
     "  SELECT count(*)                \
         FROM reject_policy           \
        WHERE ipolicy = ?             \
          AND fins_grp = '3'  ");
     $PREPARE rpid FROM $stmt;

     sprintf(stmt,
     "  SELECT count(*)                 \
         FROM %s:appraisal             \
        WHERE ipolicy = ?              \
          AND fpart IN ('1','2','3') ",list[k].dbname);
     $PREPARE clmid FROM $stmt;

     sprintf(stmt,
     "  SELECT iquota          \
         FROM officer         \
        WHERE iofficer = ? ");
     $PREPARE ioffid FROM $stmt;

     /* 94.04.01 �X��,�]�����ݦX�֫e������ */
     sprintf(stmt,"SELECT unit_id, move_date, move_type  \
                     FROM personal:v_asexpr   \
                    WHERE empl_no = ?         \
                      AND move_date <= (case when ? <= '20050401' then '20050401' else ? end) \
                    ORDER BY 2 desc,3 ");
     $PREPARE per_unit FROM $stmt;
     $DECLARE unit_at CURSOR FOR per_unit;

     sprintf(stmt,"SELECT iquota, '04/01/2005', Case When dexpire IS NOT NULL then '59' Else '0' End   \
                     FROM officer                          \
                    WHERE iofficer = ?                     \
                    ORDER BY 2 DESC ");
     $PREPARE unit_at1 FROM $stmt;

     sprintf(stmt,"SELECT id_no FROM personal:asempl \
                    WHERE empl_no = ? ");
     $PREPARE getid FROM $stmt;

     sprintf(stmt,"SELECT empl_no, duty_date \
                     FROM personal:asempl \
                    WHERE id_no = ?       \
                      AND empl_no <> ?    \
                    ORDER BY 2 desc ");

     $PREPARE per_empl FROM $stmt;
     $DECLARE get_empl CURSOR FOR per_empl;
   
     sprintf(stmt,"SELECT Case When b.duty_date Is Null                                \
                               then '99999999' Else b.duty_date End                    \
                     FROM officer a,Outer personal:asempl b                            \
                    WHERE a.iofficer = b.empl_no                                       \
                      AND a.iofficer = ? ");
     $PREPARE duid1 FROM $stmt;

     sprintf(stmt, "SELECT ileader FROM officer  \
                     WHERE iofficer = ? ");
     $PREPARE get_lead FROM $stmt;
     
     sprintf(stmt,"SELECT deffect, iquota_old \
                     FROM officer_transact \
                    WHERE iofficer = ? \
                      AND deffect > ? \
                      AND deffect >= '04/01/2005' \
                    ORDER BY 1 ");
     
     $PREPARE pre_offt FROM $stmt;
     $DECLARE get_offt CURSOR for pre_offt;               
     
     sprintf(stmt,
     " SELECT iofficer_new      \
         FROM collate_officer   \
        WHERE iofficer_old = ? ");
     $PREPARE col_1 FROM $stmt;
     
     sprintf(stmt," SELECT ileader             \
                      FROM %s:ori_ply_relation \
                     WHERE ipolicy = ? ", list[k].dbname );
     $PREPARE ori_leader FROM $stmt;
     
     /*** 20110302 �H�U�P�_�]�ɮĬҤw�L�h�[��,�G�{���q�����R��
        ���دu�|��M��,�����ץ~�X�G�i�O��,�ҥH�����N�����O���O����Ʀ���
     strcpy(sequip_str,equip_instr("09"));
        Z63645B �s���u���O��,�ӽФ��p����O�v car_9411181
     by Jessie ***/

     sprintf(stmt," SELECT %s %s FROM %s:%s %s:%s WHERE %s %s %s %s %s %s %s %s %s %s %s",
                  " a.ipolicy,b.dissue,a.iofficer,a.iresource,nvl(a.inext_ply,' '),a.mdmg_prem+a.mlia_prem,a.dply_end,a.dply_begin,a.dpolicy,a.ibig_sales,b.itag,c.imgr,b.iengine,b.nassured[1,12],b.iassured, ",
                  " (a.dply_end - a.dply_begin), b.iroute, a.ibroker ",
                  list[k].dbname, "ply_relation a, ",
                  list[k].dbname, "policy b, officer c ",
                  " a.fcard_class = ? ",
                  " AND a.dpolicy <= ? ",
                  " AND a.dply_end >= ? ",
                  " AND a.dply_end <= ?  ",
                  " AND nvl(a.fedr_class,' ') <> '1' ",
                  " AND a.ipolicy = b.ipolicy ",
                  " AND a.iofficer != 'Z03555A' ", 
                  " AND a.iofficer[1,3] not in ('G98','F98') ",
                  " AND (a.iresource != 'E') ",
                  " AND a.iofficer = c.iofficer ",
                  str_car_type);

     printf("car316_accumulate:[%s]\n",stmt);
     $PREPARE pol_cur1 FROM $stmt;
     $DECLARE pol_cur CURSOR FOR pol_cur1;
     $OPEN pol_cur USING $fcard_class, $dopen_end, $dbgn_inf, $dend_inf;
     while(1)
     {
       $FETCH pol_cur INTO $ipolicy, $dissue,
                           $iofficer, $iresource, $inext_ply, $prem,
                           $ori_dply_end, $ori_dply_begin,$ori_dpolicy,
                           $ori_ibigsales,$itag_old, $imgr, $iengine,
                           $nassured, $iassured_old, $dperiod, $iroute,
                           $ibroker ;
       if(SQLCODE == SQLNOTFOUND) break;


       if (strncmp(iroute,"PA",2) == 0)
       {
          iPAflag = 1;
       }
       else
       {
          iPAflag = 0;
       }

       $select icode
          into $icode_tap
          from cu_code_data
         where ncode        = $iofficer
           and tcode_remark = $iroute
           and itype        = 'C9';
       if (SQLCODE == SQLNOTFOUND)
       {
          iMotorflag = 0;
       }
       else
       {
          iMotorflag = 1;
       }

       /***
       $EXECUTE ridv INTO $ricnt USING $ipolicy;
          printf("ricnt[%d]\n",ricnt);
       if (ricnt > 0) continue;
       ***/
 
       $EXECUTE rpid
           INTO $ricnt
          USING $ipolicy;
       if (ricnt > 0) 
       {
          if (strlen(trim(inext_ply)) != 0)
          {
             strcpy(tmp_fulldb,get_car_full_db(inext_ply));
             sprintf(stmt,
             " SELECT count(*)          \
                 FROM %s:ply_relation   \
                WHERE ipolicy = ?       \
                  AND dpolicy <= ?      \
                  AND nvl(fedr_class,' ') != '1' \
                  AND dply_close IS NOT NULL ",tmp_fulldb);
             $PREPARE rpne FROM $stmt;
             $EXECUTE rpne 
                 INTO $ricnt
             USING $inext_ply,$dclose_end;
             if (ricnt == 0) 
             {
                continue;
             }
          }
          else
          {
                continue;
          }
       }
       
      $EXECUTE clmid INTO $clmcnt USING $ipolicy;
      if (clmcnt > 0) continue;
      
      /* Modified by Julia - �Y�L��O�渹�B�O������273�ѫh���C�J��O�έp */
      if((inext_ply[0] == '\0' || inext_ply[0] == ' ') && dperiod < 273)
	  continue;
     
      /***20110302 �ɥN�w�[��,�BJ07�w�t�s�s�N���ϥ�
      if ((iofficer[0] == 'C') || (iofficer[0] == 'D') ||
	 (strncmp(iofficer,"J07",3)==0))
      {
           $EXECUTE col_1  
               INTO $CD_iofficer
              USING $iofficer;
            if (SQLCODE == SQLNOTFOUND)
            {
                strcpy(CD_iofficer,iofficer);
            } 

         strcpy(iofficer,CD_iofficer);
      }
      by Jessie ***/
      
      if(strncmp(ipolicy, "87296V9006203",13)==0)
      {
         printf("1-1 ipolicy = %s, iofficer = %s \n", ipolicy, iofficer);
      } 
      con_cnt = mark = 0;

      sprintf(stmt2," SELECT iins_type, fedr_status, nvl(dendorse,' '), mdamage_cover \
                        FROM %s:ply_ins_type \
                       WHERE ipolicy = ?", list[k].dbname);
      $PREPARE ins_cur1 FROM $stmt2;
      $DECLARE ins_cur CURSOR FOR ins_cur1;
      $OPEN ins_cur USING $ipolicy;
      while(1)
      {
         $FETCH ins_cur INTO $ins_type, $fedr_class, $dendorse, $mdamage_cover;

         if(SQLCODE == SQLNOTFOUND) break;
         
         mark_edr = 0;

         /* �I�جO�_���Ĩ̫O�I���B�ӧP�_ */
         if (mdamage_cover > 0)
         {
             mark = 1;
             break;
         }

         /* �ҥ~�G33�I�سQ�O�I�H���h�ɡAfedr_class����'1','2','3'���O�I���B��0*/
         if ((fedr_class[0] != '1' && fedr_class[0] != '2' &&
	      fedr_class[0] != '3') && (mdamage_cover > 0))
         {
             mark = 1;
             break;
         }
         else
         {
             if (dendorse != " ")
             {
                 sprintf(stmt3,"select iedr_type \
                                  from %s:edr_relation a,%s:edr_ins_type b \
                                 where a.ipolicy = ? \
                                   and a.dendorse <= ? \
                                   and a.iendorse = b.iendorse ",
                         list[k].dbname,list[k].dbname);
                 $prepare pre_edr from $stmt3;
                 $declare cur_edr cursor for pre_edr;
                 $open cur_edr using $ipolicy, $dopen_end;
                 while(1)
                 {
                     $fetch cur_edr into $iedr_type;
                     if (SQLCODE==SQLNOTFOUND) break;
                     if (strncmp(iedr_type,"01",2)==0 ||
                         strncmp(iedr_type,"02",2)==0 ||
                         strncmp(iedr_type,"03",2)==0)
                     {
                          mark_edr = 1;
                     }

                     if (strncmp(iedr_type,"50",2)==0)
                     {
                          mark_edr = 0;
                     }
                }

                if (mark_edr==0)
                {
                     mark = 1;
                     break;
                }
             }
         }
      }
      $CLOSE ins_cur;
      $FREE  ins_cur;

      if(mark == 0)
      {
            /****    This policy is cancelled    ****/
            /*printf("  mark == 0 ���� \n");*/
            continue;
      }
      else
      {
            mark = 0;
      }

      $EXECUTE ori_leader INTO $ileader_ori
                          USING $ipolicy;
      if (SQLCODE == SQLNOTFOUND)
      {
          printf("Can't find ipolicy's[%s] ileader \n",ipolicy );
          goto errexit;
      }
      
      if(inext_ply[0] == '\0' || inext_ply[0] == ' ')
      {
         /****    This policy is not continue ����O   ****/
         printf(" �S����O  ................... \n");
         strcpy(iresource_t, iresource);
         strcpy(iresource_1, iresource);
         strcpy(iresource_2, " ");
         strcpy(iofficer_t, iofficer);
         strcpy(iofficer_1, iofficer);
         strcpy(iofficer_2, " ");
         strcpy(iroute_t,  iroute);
         strcpy(ibroker_t, ibroker);
         strcpy(new_dply_begin," ");
         strcpy(new_dpolicy," ");
         strcpy(new_ibigsales," ");
         strcpy(iofficer_old,iofficer);
         strcpy(iengine_t," ");
         strcpy(imgr_t,imgr);
         strcpy(iassured_t,iassured_old);
         strcpy(itag_t,itag_old);
         strcpy(nassured_t,nassured);
         con_cnt = 0;
         prem = 0;
          
         if ( imgr[0] == '1' ){
               $EXECUTE ioffid 
                   INTO $iquota
                  USING $iofficer;
               
            if(strncmp(ipolicy, "87296V9006203",13)==0)
            {
               printf("1-2 ipolicy = %s, iofficer = %s, iquota = %s \n", ipolicy, iofficer,iquota);
            }      
                 if (SQLCODE == SQLNOTFOUND){
                     printf("Can't find iofficer's[%s] iquota\n",iofficer);
                     goto errexit; 
                 }
         }else{
  
           if ( (iofficer[0] >= '0' && iofficer[0] <= '9') && (iofficer[2] >= '0' && iofficer[2] <= '9') ){
                strcpy(tmp_dply_end,getdate(ori_dply_end));
                
                $EXECUTE get_lead
                    INTO $ileader
                   USING $iofficer;
                
                if (SQLCODE == SQLNOTFOUND)
                {
                        /* �YŪ����h���g��N���e6�X�A�����޲z�H */
                    strcpy(ileader,substring(iofficer,1,6));
                }
                     
                strcpy(iofficer_un, ileader);

                $OPEN unit_at USING $iofficer_un,$tmp_dply_end,$tmp_dply_end;
                $FETCH unit_at INTO $iquota,$move_date,$move_type;
                 if (SQLCODE == SQLNOTFOUND)
                 {
                     $EXECUTE unit_at1 INTO $iquota,$move_date,$move_type USING $iofficer_un;
                     if (SQLCODE == SQLNOTFOUND)
                     {
                     printf("Can't find iofficer's[%s] iquota in personal database\n",iofficer);
                     goto errexit;
                     }
                 }
                $CLOSE unit_at;
                if(strncmp(ipolicy, "87296V9006203",13)==0)
                {
                 printf("1-3 ipolicy = %s, iofficer = %s, iquota = %s \n", ipolicy, iofficer,iquota);
                }          
                
                dmove_type = atoi(move_type);
                
                printf("move_type = %d , iofficer_un = %s \n", dmove_type, iofficer_un);
                
                if( dmove_type >= 59 )
                {
                    $EXECUTE get_lead
                        INTO $ileader
                       USING $iofficer_un;
                       if (SQLCODE == SQLNOTFOUND)
                       {
                           strcpy(ileader,iofficer_un);
                       }

                    printf("ileader = %s \n", ileader);
                    $EXECUTE duid1
                        INTO $char_duty_date
                       USING $ileader;
                       
                       
                     if (strncmp(char_duty_date, "99999999", 8)==0)
                     {
                         printf("�L�k���޲z�H[%s]��¾��\n",ileader);
                         /*   goto errexit;   */
                         strcpy(char_duty_date,"99999999");
                         
                         $EXECUTE unit_at1 INTO $iquota,$move_date,$move_type USING $ileader;
                         
                         if (SQLCODE == SQLNOTFOUND)
                         {
                           printf("�����޲z�H = [%s] \n",ileader);
                           goto errexit;
                         }
                         printf("�����޲z�H = %s , iquota = %s \n",ileader, iquota);
                     }

                     printf("char_duty_date = %s, move_date = %s, dply_end = %s \n", char_duty_date, move_date, tmp_dply_end);
                     if (atoi(char_duty_date) > atoi(move_date))
                     {
                         if (atoi(tmp_dply_end) > atoi(char_duty_date))
                         {
                            $OPEN unit_at USING $ileader,$tmp_dply_end,$tmp_dply_end;
                            $FETCH unit_at INTO $iquota,$move_date,$move_type;
                             if (SQLCODE == SQLNOTFOUND)
                             {
                                 $EXECUTE unit_at1 INTO $iquota,$move_date,$move_type USING $ileader;
                                 if (SQLCODE == SQLNOTFOUND)
                                 {
                                 printf("Can't find iofficer's[%s] iquota in personal database\n",iofficer);
                                 goto errexit;
                                 }
                             }
                            $CLOSE unit_at;
                            if(strncmp(ipolicy, "87296V9006203",13)==0)
                            {
                              printf("1-4 ipolicy = %s, iofficer = %s, iquota = %s \n", ipolicy, iofficer,iquota);
                            }      
                         }
                         else
                         {
                            /* ���¸g�� */
                            if(strncmp(ipolicy, "87296V9006203",13)==0)
                            {
                              printf("1-4-1 ipolicy = %s, iofficer = %s, iquota = %s \n", ipolicy, iofficer,iquota);
                            }     
                         }
                     }
                     else
                     {
                         printf("char_duty_date = %s, move_date = %s, dply_end = %s \n", char_duty_date, move_date, tmp_dply_end);
                         if (atoi(tmp_dply_end) > atoi(move_date))
                         {
                            $OPEN unit_at USING $ileader,$tmp_dply_end,$tmp_dply_end;
                            $FETCH unit_at INTO $iquota,$move_date,$move_type;
                             if (SQLCODE == SQLNOTFOUND)
                             {
                                 $EXECUTE unit_at1 INTO $iquota,$move_date,$move_type USING $ileader;
                                 if (SQLCODE == SQLNOTFOUND)
                                 {
                                 printf("Can't find iofficer's[%s] iquota in personal database\n",iofficer);
                                 goto errexit;
                                 }
                             }
                            $CLOSE unit_at;
                            if(strncmp(ipolicy, "87296V9006203",13)==0)
                            {
                              printf("1-5 ipolicy = %s, iofficer = %s, iquota = %s \n", ipolicy, iofficer,iquota);
                            }      
                         }
                         else
                         {
                             /* ���¸g�� */
                             if(strncmp(ipolicy, "87296V9006203",13)==0)
                             {
                              printf("1-4-1 ipolicy = %s, iofficer = %s, iquota = %s \n", ipolicy, iofficer,iquota);
                             }    
                         }
                     }

                }/* end check move_type */

           }else{
           
               /* �D�@�����u�~�ȡAofficer_transact�����ʸ�ơA�Niquota_old �g�Jiquota */
               strcpy(tmp_dply_end, ori_dply_end );
               $OPEN get_offt using $iofficer, $tmp_dply_end;
               $FETCH get_offt INTO $deffect, $iquota;
               if( SQLCODE == SQLNOTFOUND )
               {
                   /* �L���ʡAŪofficer �ɸ�� */
                   $EXECUTE ioffid 
                       INTO $iquota
                      USING $iofficer;
                   if (SQLCODE == SQLNOTFOUND){
                       printf("Can't find iofficer's[%s] iquota\n",iofficer);
                       goto errexit; 
                   }
               }
               $CLOSE get_offt; 
               
           }
        }
        
        /*** �b¾/��¾���O ***/
        if( iresource[0] == '6' || iresource[0] == '8' )
        {
             strcpy( iexpire, " ");
        } 
        else if( ileader_ori[0] == '6' ) 
        {
             strcpy( iexpire,"Y" );   /** �����g��N���A�ӥ���¾���u **/
        }
        else
        {
             /** ����O�A�ϥκ޲z�H�P�O������P�_ **/
             strcpy(tmp_dply_end,getdate(ori_dply_end));
             $OPEN unit_at USING $ileader_ori, $tmp_dply_end, $tmp_dply_end;
             $FETCH unit_at INTO $iquota_tmp,$move_date,$move_type;
             if (SQLCODE == SQLNOTFOUND)
             {
                  $EXECUTE unit_at1 INTO $iquota_tmp,$move_date,$move_type USING $ileader_ori;
                  if (SQLCODE == SQLNOTFOUND)
                  {
                     printf("Can't find ileader's[%s] move_type in personal database\n",iofficer);
                     goto errexit;
                  }
             }
             $CLOSE unit_at;
             dmove_type = atoi(move_type);
             if( dmove_type >= 59 )
                 strcpy( iexpire,"Y" );
             else
                 strcpy( iexpire," ");
        }
        
        strcpy(iquota_1, iquota);
        strcpy(iquota_2, " ");
        strcpy(iquota_old,iquota);
      }
      else
      {
         /****    This policy is insured  again �w��O   ****/
         
         strcpy(tmp_fulldb,get_car_full_db(inext_ply));
         if (tmp_fulldb[0] == '\0' || tmp_fulldb[0] == ' ') continue;

         sprintf(stmt," SELECT iquota              \
                          FROM %s:ori_ply_relation \
                         WHERE ipolicy = ? ",tmp_fulldb);
         $PREPARE ori_id FROM $stmt;
         if(strncmp(ipolicy, "87296V9006203",13)==0) 
         {
                printf(" 8-1 ����O ipolicy = %s , iquota = %s \n", ipolicy, iquota);  
         }      
                  
         strcpy(iengine_t," ");
         sprintf(stmt,
         " SELECT iengine               \
             FROM %s:policy             \
            WHERE ipolicy = ? ",tmp_fulldb);
         $PREPARE polid1 FROM $stmt;
         $EXECUTE polid1 INTO $iengine_t USING $inext_ply;
         if (SQLCODE == SQLNOTFOUND)
         {
            strcpy(iengine_t," ");
         }

         sprintf(stmt1, "SELECT a.iofficer, b.imgr, \
                                iresource, mdmg_prem+mlia_prem, dissue, \
                                ilast_ply, dpolicy, dply_begin, dpolicy,  \
                                ibig_sales, iassured, nassured[1,12], itag, \
                                c.iroute, a.ibroker \
                           FROM %s:ply_relation a,officer b,%s:policy c \
                          WHERE a.ipolicy = ? \
                            AND dpolicy <= ? \
                            AND a.ipolicy = c.ipolicy \
                            AND nvl(fedr_class,' ') != '1' \
                            AND dply_close IS NOT NULL \
                            AND a.iofficer = b.iofficer ",tmp_fulldb,
                         tmp_fulldb);

         $PREPARE new_pol_1 FROM $stmt1;
         $DECLARE new_pol CURSOR FOR new_pol_1;
         $OPEN new_pol USING $inext_ply, $dclose_end;

         $FETCH new_pol INTO $iofficer_t, $imgr_t,
                             $iresource_t, $prem_t, $dissue_t,
                             $LHsIlast_ply, $next_dpolicy, $new_dply_begin,
                             $new_dpolicy, $new_ibigsales, $iassured_t,
                             $nassured_t, $itag_t, $iroute_t, $ibroker_t;

         if (SQLCODE == SQLNOTFOUND)
         { 
            
            /****    This policy is not continue    ****/
            strcpy(iresource_t, iresource);
            strcpy(iresource_1, iresource);
            strcpy(iresource_2, " ");
            strcpy(iofficer_t, iofficer);
            strcpy(iofficer_1, iofficer);
            strcpy(iofficer_2, " ");
            strcpy(iroute_t, iroute);
            strcpy(ibroker_t, ibroker);
            strcpy(new_dply_begin," ");
            strcpy(new_dpolicy," ");
            strcpy(new_ibigsales," ");
            strcpy(iofficer_old, iofficer);
            strcpy(imgr_t,imgr);
            strcpy(itag_t,itag_old);
            strcpy(iassured_t,iassured_old);
            strcpy(nassured_t,nassured);
            con_cnt = 0;
            prem = 0;

            if ( imgr[0] == '1' ){
                  $EXECUTE ioffid 
                      INTO $iquota
                     USING $iofficer;
                 if (SQLCODE == SQLNOTFOUND){
                     printf("Can't find iofficer's[%s] iquota\n",iofficer);
                     goto errexit; 
                 }
            }else{
  
               if ( (iofficer[0] >= '0' && iofficer[0] <= '9') &&
		    (iofficer[2] >= '0' && iofficer[2] <= '9')){
                    strcpy(tmp_dply_end,getdate(ori_dply_end)); 
                     
                    $EXECUTE get_lead
                        INTO $ileader
                       USING $iofficer;
                
                    if (SQLCODE == SQLNOTFOUND)
                    {
                        /* �YŪ����h���g��N���e6�X�A�����޲z�H */
                        strcpy(ileader,substring(iofficer,1,6));
                    }
                     
                    strcpy(iofficer_un, ileader);                   
                     
                    
                    $OPEN unit_at USING $iofficer_un,$tmp_dply_end,$tmp_dply_end;
                    $FETCH unit_at INTO $iquota,$move_date,$move_type;
                    if (SQLCODE == SQLNOTFOUND)
                    {
                       $EXECUTE unit_at1 INTO $iquota,$move_date,$move_type USING $iofficer_un;
                       if (SQLCODE == SQLNOTFOUND)
                       {
                       printf("Can't find iofficer's[%s] iquota in personal database\n",iofficer);
                       goto errexit;
                       }
                    }
                    $CLOSE unit_at;
                    
                  if(strncmp(ipolicy, "87296V9006203",13)==0) 
                  {
                        printf(" 8-2 ����O ipolicy = %s , iquota = %s \n", ipolicy, iquota);  
                  }     
                  
                  dmove_type = atoi(move_type);
                  if( dmove_type >= 59 )
                  {
                     $EXECUTE get_lead
                         INTO $ileader
                        USING $iofficer_un;
                        if (SQLCODE == SQLNOTFOUND)
                        {
                           strcpy(ileader,iofficer_un);
                        }

                     $EXECUTE duid1
                         INTO $char_duty_date
                        USING $ileader;
                        
                     if (strncmp(char_duty_date, "99999999", 8)==0)
                     {
                         printf("�L�k���޲z�H[%s]��¾��\n",ileader);
                         /*   goto errexit;   */
                         strcpy(char_duty_date,"99999999");
                         
                         $EXECUTE unit_at1 INTO $iquota,$move_date,$move_type USING $ileader;
                         
                         if (SQLCODE == SQLNOTFOUND)
                         {
                           printf("�����޲z�H = [%s] \n",ileader);
                           goto errexit;
                         }
                         printf("�����޲z�H = %s , iquota = %s \n",ileader, iquota);
                     }   
                     if(strncmp(ipolicy, "87296V9006203",13)==0)   
                     {
                        printf(" 8-3 ����O ipolicy = %s , iquota = %s \n", ipolicy, iquota);         
                     }
                     
                      if (atoi(char_duty_date) > atoi(move_date))
                      {
                         if (atoi(tmp_dply_end) > atoi(char_duty_date))
                         {
                            $OPEN unit_at USING $ileader,$tmp_dply_end,$tmp_dply_end;
                            $FETCH unit_at INTO $iquota,$move_date,$move_type;
                             if (SQLCODE == SQLNOTFOUND)
                             {
                                 $EXECUTE unit_at1 INTO $iquota,$move_date,$move_type USING $ileader;
                                 if (SQLCODE == SQLNOTFOUND)
                                 {
                                 printf("Can't find iofficer's[%s] iquota in personal database\n",iofficer);
                                 goto errexit;
                                 }
                             }
                            $CLOSE unit_at;
                         }
                         else
                         {
                            /* ���¸g�� */
                         }
                      }
                      else
                      {
                         if (atoi(tmp_dply_end) > atoi(move_date))
                         {
                            $OPEN unit_at USING $ileader,$tmp_dply_end,$tmp_dply_end;
                            $FETCH unit_at INTO $iquota,$move_date,$move_type;
                             if (SQLCODE == SQLNOTFOUND)
                             {
                                 $EXECUTE unit_at1 INTO $iquota,$move_date,$move_type USING $ileader;
                                 if (SQLCODE == SQLNOTFOUND)
                                 {
                                 printf("Can't find iofficer's[%s] iquota in personal database\n",iofficer);
                                 goto errexit;
                                 }
                             }
                            $CLOSE unit_at;
                         }
                         else
                         {
                             /* ���¸g�� */
                         }
                      }
                  }/* end check move_type */

               }else{
            
               /* �D�@�����u�~�ȡAofficer_transact�����ʸ�ơA�Niquota_old �g�Jiquota */
                  strcpy(tmp_dply_end, ori_dply_end );
                 
                  $OPEN get_offt using $iofficer, $tmp_dply_end;
                  $FETCH get_offt INTO $deffect, $iquota;
                  if( SQLCODE == SQLNOTFOUND )
                  {
                     /* �L���ʡAŪofficer �ɸ�� */
                     $EXECUTE ioffid 
                         INTO $iquota
                        USING $iofficer;
                     if (SQLCODE == SQLNOTFOUND){
                         printf("Can't find iofficer's[%s] iquota\n",iofficer);
                         goto errexit; 
                     }
                  }
                  $CLOSE get_offt;
               }
            }
            
            /*** �b¾/��¾���O ***/
            if( iresource[0] == '6' || iresource[0] == '8' )
            {
                strcpy( iexpire, " ");
            }
            else if( ileader_ori[0] == '6' ) 
            {
                 strcpy( iexpire,"Y" );   /** �����g��N���A�ӥ���¾���u **/
            }
            else
            {
                 /** ����O�A�ϥκ޲z�H�P�O������P�_ **/
                 strcpy(tmp_dply_end,getdate(ori_dply_end));
                 $OPEN unit_at USING $ileader_ori, $tmp_dply_end, $tmp_dply_end;
                 $FETCH unit_at INTO $iquota_tmp,$move_date,$move_type;
                 if (SQLCODE == SQLNOTFOUND)
                 {
                      $EXECUTE unit_at1 INTO $iquota_tmp,$move_date,$move_type USING $ileader_ori;
                      if (SQLCODE == SQLNOTFOUND)
                      {
                          printf("Can't find ileader's[%s] move_type in personal database\n",iofficer);
                          goto errexit;
                      }
                 }
                 $CLOSE unit_at;
                 dmove_type = atoi(move_type);
                 if( dmove_type >= 59 )
                     strcpy( iexpire,"Y" );
                 else
                     strcpy( iexpire," ");
            }
            
            strcpy(iquota_1, iquota);
            strcpy(iquota_2, " ");
            strcpy(iquota_old,iquota);
            strcpy(inext_ply," ");
            
            if(strncmp(ipolicy, "87296V9006203",13)==0)
            {
               printf("3-0 ipolicy = %s, iquota = %s, iquota_t = %s \n", ipolicy, iquota, iquota_t);
            }   
         }
         else
         {
            strcpy(dissue, trim(dissue));
            strcpy(dissue_t, trim(dissue_t));

            if(strcmp(dissue, dissue_t)!=0)
               strcpy(dissue, dissue_t);

            if ((iofficer_t[0] == 'C') || (iofficer_t[0] == 'D') || 
                (strncmp(iofficer_t,"J07",3)==0))
            {
                 $EXECUTE col_1
                     INTO $CD_iofficer
                    USING $iofficer_t;
                 if (SQLCODE == SQLNOTFOUND)
                 {
                     strcpy(CD_iofficer,iofficer_t);
                 }

                 strcpy(iofficer_t,CD_iofficer);
            }

            prem = prem_t;
            con_cnt = 1;
            /*** ��Ʀ^�k 90.02.16 by leng begin***/
            /*** �O�N��-->�O�NB, �@��A -->�@��B
            �@���<--�O�N��,�O�N��<--�@��� ***/
            LiFlag = 0;

            strcpy(iresource_1,iresource);
            strcpy(iresource_2,iresource_t);
            strcpy(iofficer_1,iofficer);
            strcpy(iofficer_2,iofficer_t);
            strcpy(iofficer_old,iofficer);

            if (strcmp(iofficer,iofficer_t)!=0) {
                       LiFlag = 1;
            }
                 
            if (imgr_t[0] == '2')
            {   /*�@���*/
                if (imgr[0] == '1')
                {   /*�O�N��*/
                    /*�O�N->�@�� */

                    /*���«O�N���g�������s�@��ɤ��̷s�~�Z���*/
                    $EXECUTE ioffid
                        INTO $iquota_1
                       USING $iofficer;
                    if (SQLCODE == SQLNOTFOUND){
                        printf("Can't find iofficer's[%s] iquota\n",iofficer);
                        goto errexit;
                    }

                    /*�̷s�@����l�O���ɤ��~�Z���*/
                    $EXECUTE ori_id
                        INTO $iquota_2
                       USING $inext_ply;
                    if (SQLCODE == SQLNOTFOUND){
                        printf("Can't not find ipolicy's[%s] iquota on ori_ply_relation\n",inext_ply);
                        goto errexit;
                    }

                    strcpy(iofficer_old,iofficer);
                    strcpy(iquota,iquota_1);
                    strcpy(iquota_old,iquota_1);
                    
                    if(strncmp(ipolicy, "87296V9006203",13)==0)
                    {
                       printf("3-9 ipolicy = %s, iquota_1 = %s, iquota_2, iquota_old = %s \n", ipolicy, iquota_1, iquota_2, iquota_old);
                    }   

                }
                else{                                           /*�@���*/
                    /* �@��->�@�� */                    
                    if ((iofficer[0] >= '0' && iofficer[0] <= '9') &&
			(iofficer[2] >= '0' && iofficer[2] <= '9'))
                    {
                        strcpy(tmp_dply_end,getdate(ori_dply_end));
                      /* bug�ץ�:���ӬO�«O��g�� modify by sylvia 106.02.17 */
                        $EXECUTE get_lead
                            INTO $ileader
                           USING $iofficer;
                
                        if (SQLCODE == SQLNOTFOUND)
                        {
                                /* �YŪ����h���g��N���e6�X�A�����޲z�H */
                            strcpy(ileader,substring(iofficer,1,6));
                        }
                     
                        strcpy(iofficer_un, ileader);
                         
                        
                       if(strncmp(ipolicy, "87296V9006203",13)==0)
                       {
                         printf("4-0-1 ipolicy = %s,iquota_1=%s,iquota_2=%s,iquota_old=%s,iofficer=%s\n", ipolicy, iquota_1, iquota_2, iquota_old,iofficer);
                       }        
                        
                        $OPEN unit_at USING $iofficer_un,$tmp_dply_end,$tmp_dply_end;
                        $FETCH unit_at INTO $iquota_1,$move_date,$move_type;
                        if (SQLCODE == SQLNOTFOUND)
                        {
                             $EXECUTE unit_at1 INTO $iquota_1,$move_date,$move_type USING $iofficer_un;
                             if (SQLCODE == SQLNOTFOUND)
                             {
                             printf("Can't find iofficer's[%s] iquota in personal database\n",iofficer);
                             goto errexit;
                             }
                        }
                        $CLOSE unit_at;
                        
                         
                       if(strncmp(ipolicy, "87296V9006203",13)==0)
                       {
                         printf("4-0-2 ipolicy = %s,iquota_1=%s,iquota_2=%s\n", ipolicy, iquota_1, iquota_2 );
                         printf("4-0-3 iquota_old=%s,iofficer=%s,move_type=%s \n", iquota_old,iofficer,move_type); 
                       }        
                        
                        dmove_type = atoi(move_type);
                        
                        if( dmove_type >= 59 )
                        {
                            $EXECUTE get_lead
                                INTO $ileader
                               USING $iofficer_un;
                               if (SQLCODE == SQLNOTFOUND)
                               {
                                   strcpy(ileader,iofficer_un);
                               }

                            $EXECUTE duid1
                                INTO $char_duty_date
                               USING $ileader;
                               
                            if(strncmp(ipolicy, "87296V9006203",13)==0)
                            {
                              printf("4-0-4 ipolicy = %s,iquota_1=%s,iquota_2=%s\n", ipolicy, iquota_1, iquota_2 );
                              printf("4-0-5 iquota_old=%s,ileader=%s,char_duty_date=%s\n", iquota_old,ileader,char_duty_date); 
                            }
                                   
                            if (strncmp(char_duty_date, "99999999", 8)==0)
                            {
                              printf("�L�k���޲z�H[%s]��¾��\n",ileader);
                              /*   goto errexit;   */
                              strcpy(char_duty_date,"99999999");
                         
                              $EXECUTE unit_at1 INTO $iquota_1,$move_date,$move_type USING $ileader;
                         
                              if (SQLCODE == SQLNOTFOUND)
                              {
                                printf("�����޲z�H = [%s] \n",ileader);
                                goto errexit;
                              }
                              printf("�����޲z�H = %s , iquota_1 = %s \n",ileader, iquota_1);
                            }   

                            if (atoi(char_duty_date) > atoi(move_date))
                            {
                                if (atoi(tmp_dply_end) > atoi(char_duty_date))
                                {
                                    $OPEN unit_at USING $ileader,$tmp_dply_end,$tmp_dply_end;
                                    $FETCH unit_at INTO $iquota_1,$move_date,$move_type;
                                    
                                    if(strncmp(ipolicy, "87296V9006203",13)==0)
                                    {
                                      printf("4-0-6 ipolicy = %s,iquota_1=%s,iquota_2=%s\n", ipolicy, iquota_1, iquota_2 );
                                      printf("4-0-7 iquota_old=%s,ileader=%s,char_duty_date=%s\n", iquota_old,ileader,char_duty_date); 
                                    }
                                    
                                    if (SQLCODE == SQLNOTFOUND)
                                    {
                                           $EXECUTE unit_at1 INTO $iquota_1,$move_date,$move_type USING $ileader;
                                           if (SQLCODE == SQLNOTFOUND)
                                           {
                                          printf("Can't find iofficer's[%s] iquota in personal database\n",iofficer);
                                          goto errexit;
                                           }
                                    }
                                    $CLOSE unit_at;
                                }
                                else
                                {
                                    /* ���¸g�� */
                                }
                            }
                            else
                            {
                                if (atoi(tmp_dply_end) > atoi(move_date))
                                {
                                    $OPEN unit_at USING $ileader,$tmp_dply_end,$tmp_dply_end;
                                    $FETCH unit_at INTO $iquota_1,$move_date,$move_type;
                                    
                                    if(strncmp(ipolicy, "87296V9006203",13)==0)
                                    {
                                      printf("4-0-8 ipolicy = %s,iquota_1=%s,iquota_2=%s\n", ipolicy, iquota_1, iquota_2 );
                                      printf("4-0-9 iquota_old=%s,ileader=%s,char_duty_date=%s\n", iquota_old,ileader,char_duty_date); 
                                    }
                                    
                                    dmove_type = atoi(move_type);
                        
                                               
                                    if (SQLCODE == SQLNOTFOUND || dmove_type >= 59)
                                    {
                                       $EXECUTE unit_at1 INTO $iquota_1,$move_date,$move_type USING $ileader;
                                       if (SQLCODE == SQLNOTFOUND)
                                       {
                                        printf("Can't find iofficer's[%s] iquota in personal database\n",iofficer);
                                        goto errexit;
                                       }
                                    }
                                    $CLOSE unit_at;
                                }
                                else
                                {
                                    /* ���¸g�� */
                                }
                            }
                        }/* end check move_type */

                        $EXECUTE ori_id
                            INTO $iquota_2
                           USING $inext_ply;
                        if (SQLCODE == SQLNOTFOUND){
                              printf("Can't not find ipolicy's[%s] iquota on ori_ply_relation\n",inext_ply);
                              goto errexit;
                        }
                        
                        if(strncmp(ipolicy, "87296V9006203",13)==0)
                        {
                           printf("4-0-10 inext_ply = %s,iquota_1=%s,iquota_2=%s\n", inext_ply, iquota_1, iquota_2 );
                           printf("4-0-11 iquota_old=%s,ileader=%s\n", iquota_old,ileader); 
                        }
                        
                    }
                    else
                    {

                        /* �D�@�����u�~�ȡAofficer_transact�����ʸ�ơA
                           �Niquota_old �g�Jiquota */
                        strcpy(tmp_dply_end, ori_dply_end );
                        
                        $OPEN get_offt using $iofficer, $tmp_dply_end;
                        $FETCH get_offt INTO $deffect, $iquota_1;
                        if( SQLCODE == SQLNOTFOUND )
                        {
                            /* �L���ʡAŪofficer �ɸ�� */
                            
                            $EXECUTE ioffid 
                                INTO $iquota_1
                               USING $iofficer;
                            if (SQLCODE == SQLNOTFOUND){
                                 printf("Can't find iofficer's[%s] iquota\n",iofficer);
                                 goto errexit; 
                            }
                            
                            if(strncmp(ipolicy, "87296V9006203",13)==0)
                            {
                              printf("4-0 ipolicy = %s, iquota_1 = %s, iquota_2=%s, iquota_old=%s, iofficer = %s \n", ipolicy, iquota_1, iquota_2, iquota_old,iofficer);
                            }   
                        }
                        $CLOSE get_offt;                                
                        
                        $EXECUTE ori_id
                            INTO $iquota_2
                           USING $inext_ply;
                        if (SQLCODE == SQLNOTFOUND){
                             printf("Can't not find ipolicy's[%s] iquota on ori_ply_relation\n",inext_ply);
                             goto errexit;
                        }
                    }

                    strcpy(iofficer, iofficer_t);
                    strcpy(iofficer_old,iofficer_t);
                    strcpy(iresource,iresource_t);
                    strcpy(iroute,  iroute_t);
                    strcpy(ibroker, ibroker_t);
                    strcpy(iquota,iquota_2);
                    strcpy(iquota_old,iquota_2);

                    if (strncmp(iroute_t,"PA",2) == 0)
                    {
                       iPAflag = 1;
                    }
                    else
                    {
                       iPAflag = 0;
                    }

                    $select icode
                       into $icode_tap
                       from cu_code_data
                      where ncode        = $iofficer_t
                        and tcode_remark = $iroute_t
                        and itype        = 'C9';
                    if (SQLCODE == SQLNOTFOUND)
                    {
                       iMotorflag = 0;
                    }
                    else
                    {
                       iMotorflag = 1;
                    }
                    
                    if(strncmp(ipolicy, "87296V9006203",13)==0)
                    {
                      printf("4-1 ipolicy = %s, iquota_1 = %s, iquota_2 = %s, iquota_old = %s \n", ipolicy, iquota_1, iquota_2, iquota_old);
                    }   
                }
            }
            else {                                            /*�O�N��*/
                if (imgr[0]=='1') 
                {   /*�O�N��*/
                    /*�O�N->�O�N*/

                    $EXECUTE ioffid
                        INTO $iquota_1
                       USING $iofficer;
                    if (SQLCODE == SQLNOTFOUND){
                         printf("Can't find iofficer's[%s] iquota\n",iofficer);
                         goto errexit;
                    }

                    $EXECUTE ori_id
                        INTO $iquota_2
                       USING $inext_ply;
                    if (SQLCODE == SQLNOTFOUND){
                         printf("Can't not find ipolicy's[%s] iquota on ori_ply_relation\n",inext_ply);
                         goto errexit;
                    }

                    strcpy(iofficer, iofficer_t);
                    strcpy(iresource,iresource_t);
                    strcpy(iroute,   iroute_t);
                    strcpy(ibroker,  ibroker_t);
                    strcpy(iofficer_old,iofficer_t);
                    strcpy(iquota,iquota_2);
                    strcpy(iquota_old,iquota_2);

                    if (strncmp(iroute_t,"PA",2) == 0)
                    {
                       iPAflag = 1;
                    }
                    else
                    {
                       iPAflag = 0;
                    }

                    $select icode
                       into $icode_tap
                       from cu_code_data
                      where ncode        = $iofficer_t
                        and tcode_remark = $iroute_t
                        and itype        = 'C9';
                    if (SQLCODE == SQLNOTFOUND)
                    {
                       iMotorflag = 0;
                    }
                    else
                    {
                       iMotorflag = 1;
                    }
                }
                else {
                    /*�@��->�O�N*/
                    if ( (iofficer[0] >= '0' && iofficer[0] <= '9') &&
			 (iofficer[2] >= '0' && iofficer[2] <= '9') ){
                         strcpy(tmp_dply_end,getdate(next_dpolicy));
                     
                         $EXECUTE get_lead
                             INTO $ileader
                            USING $iofficer;
                
                         if (SQLCODE == SQLNOTFOUND)
                         {
                                /* �YŪ����h���g��N���e6�X�A�����޲z�H */
                            strcpy(ileader,substring(iofficer,1,6));
                         }
                     
                         strcpy(iofficer_un, ileader);
                          
                         
                         $OPEN unit_at USING $iofficer_un,$tmp_dply_end,$tmp_dply_end;
                         $FETCH unit_at INTO $iquota_1,$move_date,$move_type;
                         if (SQLCODE == SQLNOTFOUND)
                         {
                            $EXECUTE unit_at1 INTO $iquota_1,$move_date,$move_type USING $iofficer_un;
                            if (SQLCODE == SQLNOTFOUND)
                            {
                             printf("Can't find iofficer's[%s] iquota in personal database\n",iofficer);
                             goto errexit;
                            }
                         }
                         $CLOSE unit_at;

                         dmove_type = atoi(move_type);
                         if( dmove_type >= 59 )
                         {
                             $EXECUTE get_lead
                                 INTO $ileader
                                USING $iofficer_un;
                             if (SQLCODE == SQLNOTFOUND)
                             {
                                 strcpy(ileader,iofficer_un);
                             }

                             $EXECUTE duid1
                                 INTO $char_duty_date
                                USING $ileader;
                             
                             if (strncmp(char_duty_date, "99999999", 8)==0)
                             {
                               printf("�L�k���޲z�H[%s]��¾��\n",ileader);
                               /*   goto errexit;   */
                               strcpy(char_duty_date,"99999999");
                         
                               $EXECUTE unit_at1 INTO $iquota_1,$move_date,$move_type USING $ileader;
                         
                               if (SQLCODE == SQLNOTFOUND)
                               {
                                 printf("�����޲z�H = [%s] \n",ileader);
                                 goto errexit;
                               }
                               printf("�����޲z�H = %s , iquota_1 = %s \n",ileader, iquota_1);
                             }

                             if (atoi(char_duty_date) > atoi(move_date))
                             {
                                  if (atoi(tmp_dply_end) > atoi(char_duty_date))
                                  {
                                     $OPEN unit_at USING $ileader,$tmp_dply_end,$tmp_dply_end;
                                     $FETCH unit_at INTO $iquota_1,$move_date,$move_type;
                                      if (SQLCODE == SQLNOTFOUND)
                                      {
                                          $EXECUTE unit_at1 INTO $iquota_1,$move_date,$move_type USING $ileader;
                                          if (SQLCODE == SQLNOTFOUND)
                                          {
                                          printf("Can't find iofficer's[%s] iquota in personal database\n",iofficer);
                                          goto errexit;
                                          }
                                      }
                                     $CLOSE unit_at;
                                  }
                                  else
                                  {
                                     /* ���¸g�� */
                                  }
                             }
                             else
                             {
                                  if (atoi(tmp_dply_end) > atoi(move_date))
                                  {
                                     $OPEN unit_at USING $ileader,$tmp_dply_end,$tmp_dply_end;
                                     $FETCH unit_at INTO $iquota_1,$move_date,$move_type;
                                      if (SQLCODE == SQLNOTFOUND)
                                      {
                                          $EXECUTE unit_at1 INTO $iquota_1,$move_date,$move_type USING $ileader;
                                          if (SQLCODE == SQLNOTFOUND)
                                          {
                                          printf("Can't find iofficer's[%s] iquota in personal database\n",iofficer);
                                          goto errexit;
                                          }
                                      }
                                     $CLOSE unit_at;
                                  }
                                  else
                                  {
                                      /* ���¸g�� */
                                      if(strncmp(ipolicy,"87296V9006203",13)==0)
                                      {
                                        printf("2-0 ipolicy = %s, iquota_1 = %s, iquota_2 = %s, iquota_old = %s \n", ipolicy, iquota_1, iquota_2, iquota_old);
                                      } 
                                  }
                             }

                         }/* end check move_type */

                         $EXECUTE ori_id
                             INTO $iquota_2
                            USING $inext_ply;
                         if (SQLCODE == SQLNOTFOUND){
                              printf("Can't not find ipolicy's[%s] iquota on ori_ply_relation\n",inext_ply);
                              goto errexit;
                         }
                    
                    }else{
                    
                        /* �D�@�����u�~�ȡAofficer_transact�����ʸ�ơA
                           �Niquota_old �g�Jiquota */
                        strcpy(tmp_dply_end, next_dpolicy );
                        
                        $OPEN get_offt using $iofficer, $tmp_dply_end;
                        $FETCH get_offt INTO $deffect, $iquota_1;

                        if( SQLCODE == SQLNOTFOUND )
                        {
                            /* �L���ʡAŪofficer �ɸ�� */
                            $EXECUTE ioffid 
                                INTO $iquota_1
                               USING $iofficer;
                            if (SQLCODE == SQLNOTFOUND){
                                 printf("Can't find iofficer's[%s] iquota\n",iofficer);
                                 goto errexit; 
                            }
                        }
                        $CLOSE get_offt;
                        
                        $EXECUTE ori_id
                            INTO $iquota_2
                           USING $inext_ply;
                        if (SQLCODE == SQLNOTFOUND){
                             printf("Can't not find ipolicy's[%s] iquota on ori_ply_relation\n",inext_ply);
                             goto errexit;
                        }
                    }
                    strcpy(iofficer_old,iofficer);
                    strcpy(iquota,iquota_1);
                    strcpy(iquota_old,iquota_1);
                    
                    if(strncmp(ipolicy, "87296V9006203",13)==0)
                    {
                      printf("2-1 ipolicy = %s, iquota-1 = %s, iquota_2 = %s, iquota_old=%s \n", ipolicy, iquota_1, iquota_2, iquota_old);
                    }   
                }
            }
            
            /*** �b¾/��¾���O ***/
            if( iresource[0] == '6' || iresource[0] == '8' )
            {
                 strcpy( iexpire, " ");
            }
            else if( ileader_ori[0] == '6' ) 
            {
                 strcpy( iexpire,"Y" );   /** �����g��N���A�ӥ���¾���u **/
            }
            else
            {
                 /** �w��O�A�ϥκ޲z�H�P�s��O�O��ñ���P�_ **/
                 strcpy(tmp_dply_end,getdate(next_dpolicy));
                 $OPEN unit_at USING $ileader_ori, $tmp_dply_end, $tmp_dply_end;
                 $FETCH unit_at INTO $iquota_tmp,$move_date,$move_type;
                 if (SQLCODE == SQLNOTFOUND)
                 {
                      $EXECUTE unit_at1 INTO $iquota_tmp,$move_date,$move_type USING $ileader_ori;
                      if (SQLCODE == SQLNOTFOUND)
                      {
                          printf("Can't find ileader's[%s] move_type in personal database\n",iofficer);
                          goto errexit;
                      }
                 }
                 $CLOSE unit_at;
                 dmove_type = atoi(move_type);
                 if( dmove_type >= 59 )
                     strcpy( iexpire,"Y" );
                 else
                     strcpy( iexpire," ");
            }

         }

         $CLOSE new_pol;
         $FREE  new_pol;
      }

      {
      char yy[5], mm[3], dd[3];
      cm_split_ymd( dissue, mm, dd, yy);
      t_year = atoi(yy);
      }

/**** ��~�s�¨����H�t�Τ鬰��¦, ��H��O��ñ��I��鬰��¦(��)
                          991126  �ץ����H�ӥ�i��O����鬰base
      strcpy(t_yy,cm_sysd_cyear_100(cm_get_sysd()));
****/

      strcpy(t_yy,ori_dply_end+6);
      o_year = atoi(t_yy);
      myear = o_year - t_year;

      if (myear > 1)
         myear = 2;
      else
         myear = 1;
 
      if(LiFlag == 1)
      {
           $INSERT INTO CAR316_TMP
                (iofficer, iquota, iofficer_t, iquota_t,
                 ipolicy, dissue, inext_ply, con_cnt, prem)
            VALUES
                ($iofficer_1, $iquota_1, $iofficer_2, $iquota_2,
                 $ipolicy, $dissue, $inext_ply, $con_cnt, $prem);
         
            LiFlag = 0; 
      }

      if (imgr[0]=='2')
      {  /*�@���*/
           if(strncmp(ipolicy, "87296V9006203",13)==0)
           {
              printf("2-2 ipolicy = %s, iquota_1 = %s, iquota_2 = %s, iquota_old = %s \n", ipolicy, iquota_1, iquota_2, iquota_old);
           }    
      
           $INSERT INTO CAR316_TMP1
                (iofficer, iquota, iofficer_t, iquota_t, iofficer_old, iquota_old,
                 ipolicy, dissue, inext_ply, con_cnt, prem, iresource, iresource_t,
                 nassured, iengine, iengine_t, iexpire )
            VALUES
                ($iofficer_1, $iquota_1, $iofficer_2, $iquota_2, $iofficer_old, $iquota_old,
                 $ipolicy, $dissue, $inext_ply, $con_cnt, $prem, $iresource_1, $iresource_2,
                 $nassured, $iengine, $iengine_t, $iexpire);
      }
      /* 101.11,�����O�N��u�C���סB���q�A��C�X�Ҧ��O�N�� 
      if ((strncmp(iofficer_1,"B",1)==0 || strncmp(iofficer_1,"J",1)==0) &&
          (myear == 1)) */
      if (imgr[0]=='1')
      {  /*�O�N��*/
           $INSERT INTO CAR316_TMP2
                (iofficer, iquota, dply_begin, dpolicy, ibig_sales, iofficer_t,
                 iquota_t, dply_begin_t,
                 dpolicy_t, ibig_sales_t, iofficer_old, iquota_old, itag_old,
                 ipolicy, dissue, inext_ply, con_cnt,
                 prem, iresource, iresource_t, nassured, iengine, iengine_t,
                 itag_t, nassured_t, iassured_old, iassured_t)
            VALUES
                ($iofficer_1, $iquota_1, $ori_dply_begin, $ori_dpolicy,
                 $ori_ibigsales, $iofficer_2, $iquota_2, 
                 $new_dply_begin, $new_dpolicy, $new_ibigsales, $iofficer_old,
                 $iquota_old, $itag_old,
                 $ipolicy, $dissue, $inext_ply, $con_cnt, $prem,
                 $iresource_1, $iresource_2,
                 $nassured, $iengine, $iengine_t,
                 $itag_t, $nassured_t, $iassured_old, $iassured_t);
      }
      /* 
      if (imgr[0]=='1')
      {  *�O�N��*
               printf("�Ҧ��O�N����iofficer_1[%s],iquota_1[%s]\n",iofficer_1,iquota_1);
               $INSERT INTO CAR316_TMP3
                    (iofficer, iquota, dply_begin, dpolicy, ibig_sales, iofficer_t, iquota_t, dply_begin_t,
                     dpolicy_t, ibig_sales_t, iofficer_old, iquota_old, itag_old,
                     ipolicy, dissue, inext_ply, con_cnt,
                     prem, iresource, iresource_t, nassured, iengine, iengine_t)
                VALUES
                    ($iofficer_1, $iquota_1, $ori_dply_begin, $ori_dpolicy, $ori_ibigsales, $iofficer_2, $iquota_2,
                     $new_dply_begin, $new_dpolicy, $new_ibigsales, $iofficer_old, $iquota_old, $itag_old,
                     $ipolicy, $dissue, $inext_ply, $con_cnt, $prem, $iresource_1, $iresource_2,
                     $nassured, $iengine, $iengine_t);
      }*/

      $INSERT INTO CAR316
          (iofficer, iquota, iresource,
           ipolicy, myear, inext_ply, con_cnt, prem, iexpire)
       VALUES
          ($iofficer, $iquota, $iresource,
           $ipolicy, $myear, $inext_ply, $con_cnt, $prem, $iexpire);


      $INSERT INTO CAR316_NEW
          (iofficer, iquota, iresource, ibroker, iPAflag, iMotorflag,
           ipolicy, myear, inext_ply, con_cnt, prem, iexpire)
       VALUES
          ($iofficer, $iquota, $iresource, $ibroker, $iPAflag, $iMotorflag,
           $ipolicy, $myear, $inext_ply, $con_cnt, $prem, $iexpire);

       if(SQLCODE == 0)
        {
         id1 = id1 + 1;
         printf("insert count[%d]\n",id1);
        }
       else
         printf("Insert error ipolicy[%s] iquota[%s] iofficer[%s]\n",ipolicy,iquota,iofficer);
     }   /*  End of pol_select cursor while  */
     $CLOSE pol_cur;
     $FREE  pol_cur;

   }

printf("Accumulate successfully End!!!\n");
   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

void car316_title()
{
      rgu_put_head();
}

long car316_body1()
{
 char  tmp_buf[16];
 int   rc,flag_first;
 $char iquota[7], itop[2], itop_t[2], idealer[4], idealer_t[4], iofficer[11];
 $char iofficer_t[11], ntop[10], ndealer[10], nname[21], nbranch[20];
 $char buf1[17], mcheck[2], iquota_t[7], iquota_n[7], ileader[10];
 $int  renew_cnt, con_cnt, renew_cnt1, con_cnt1, renew_cnt2, con_cnt2;
 $int  myear, id2;
 $long prem, prem1, prem2, qord, qord1;
 $char off13[4];
 $char qqord[20];


   $WHENEVER SQLERROR GOTO errexit;

   flag_first=1;
   id2 = 0;

   $CREATE TEMP TABLE AGENT
      (itop         char(2),
       idealer      char(3),
       iofficer     char(10),
       iquota       char(06),
       nofficer     char(10),
       renew_cnt    integer default 0 not null,
       con_cnt      integer default 0 not null,
       prem         decimal(10,0) default 0 not null,
       renew_cnt1   integer default 0 not null,
       con_cnt1     integer default 0 not null,
       prem1        decimal(10,0) default 0 not null
     )WITH NO LOG;


   $CREATE UNIQUE INDEX AG_ix1 ON AGENT (iofficer,iquota);

   $DECLARE agent_off CURSOR FOR
     SELECT UNIQUE a.iofficer, b.iquota[1,4] || '00', a.nname,
            a.imaker, a.idealer
       INTO $iofficer, $iquota, $nname, $itop, $idealer
       FROM officer a,CAR316 b
      WHERE a.imgr = '1'
        AND a.fprop != 'E'
        AND a.iofficer = b.iofficer
      ORDER BY a.iofficer;

   $OPEN agent_off;
   while(1)
    {
     $FETCH agent_off;
     if(SQLCODE == SQLNOTFOUND) break;

     $INSERT INTO AGENT
        (itop, idealer, iofficer, iquota, nofficer, renew_cnt,
         con_cnt, prem, renew_cnt1, con_cnt1, prem1)
      VALUES
        ($itop, $idealer, $iofficer, $iquota, $nname, 0, 0, 0,
         0, 0, 0);

     if(SQLCODE == 0)
      {
       id2 = id2 + 1;
       printf("Agent insert count[%d]\n",id2);
      }
     else
       printf("Agent error insert itop[%s] idealer[%s] iofficer[%s]\n",itop,idealer,iofficer);
    }
   $CLOSE agent_off;
   $FREE  agent_off;

   $DECLARE agent CURSOR FOR
     SELECT a.iofficer, a.iquota[1,4] || '00', myear, count(*), sum(con_cnt), sum(prem)
       INTO $iofficer, $iquota, $myear, $renew_cnt, $con_cnt, $prem
       FROM CAR316 a,officer b
      WHERE a.iofficer = b.iofficer
        AND b.imgr = '1'
      GROUP BY 1,2,3;

   $OPEN agent;
   while(1)
   {
       $FETCH agent;
       if(SQLCODE == SQLNOTFOUND) break;

       if(myear == 1)
       {
          $UPDATE AGENT
              SET renew_cnt = renew_cnt + $renew_cnt,
                  con_cnt   = con_cnt   + $con_cnt,
                  prem      = prem      + $prem
            WHERE iofficer  = $iofficer
              AND iquota    = $iquota;
       }
       else
       {
          $UPDATE AGENT
              SET renew_cnt1 = renew_cnt1 + $renew_cnt,
                  con_cnt1   = con_cnt1   + $con_cnt,
                  prem1      = prem1      + $prem
            WHERE iofficer   = $iofficer
              AND iquota     = $iquota;
       }
   }  /*  End of agent cursor while  */
   $CLOSE agent;
   $FREE  agent;

/******     Start to print report(Excel Format)  ******/
   $DECLARE agent_prn CURSOR FOR
     SELECT a.iquota, a.itop, a.idealer, a.iofficer, a.renew_cnt,
            a.con_cnt, a.prem ,b.qorder,b.ngroup,
            a.renew_cnt1, a.con_cnt1, a.prem1,a.nofficer
       INTO $iquota, $itop, $idealer, $iofficer, $renew_cnt,
            $con_cnt, $prem , $qord, $nbranch,
            $renew_cnt1, $con_cnt1, $prem1, $nname
       FROM AGENT a,sa_branch_type c,sa_frm_module b
      WHERE a.iquota = c.ibranch
        AND b.ifrm_module = '01'
        AND b.igroup = c.igroup
      ORDER BY qorder,iquota,itop,idealer,iofficer;

   $OPEN agent_prn;

   $FETCH agent_prn;
   if(SQLCODE == SQLNOTFOUND)
   {
       printf("Agent_prn fetch first failed!!!!!\n");
       goto errexit; 
   }

   strcpy(itop_t, " ");
   strcpy(idealer_t, " ");

   rgu_put_body_string(1, cm_get_sysd(), 1);
   rgu_put_body_string(1, sTitle,   1);     
   rgu_put_body_string(1, " ",      1);
   rgu_put_body_string(1, dbgn_inf, 1);
   rgu_put_body_string(1, dend_inf, 1);
   rgu_put_body(1);

   while(1)
   {

       $SELECT qorder,nlevel3,nlevel4
          INTO $qqord,$ntop,$ndealer
          FROM v_channel
         WHERE icode = $iofficer;

       rgu_put_body_string(data_line, qqord, 1);
       strcpy(nbranch, trim(nbranch));
       rgu_put_body_string(data_line, nbranch, 1);

       rgu_put_body_string(data_line, ntop, 1);
       rgu_put_body_string(data_line, ndealer, 1);

       strcpy(nname, trim(nname));
       rgu_put_body_string(data_line, nname, 1);
       rgu_put_body_string(data_line, iofficer, 1);
       rfmtlong(renew_cnt, "------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
       rfmtlong(con_cnt,   "------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
       rfmtlong(prem, "------------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
       rfmtlong(renew_cnt1, "------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
       rfmtlong(con_cnt1,   "------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
       rfmtlong(prem1, "------------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
       rgu_put_body(data_line);
       
       max_cnt = max_cnt + 1;

       strcpy(itop_t, itop);
       strcpy(idealer_t, idealer);
       strcpy(iofficer_t, iofficer);

     $FETCH agent_prn;
     if(SQLCODE == SQLNOTFOUND) break;
   }  /******  End of agent_prn cursor while  ******/
   $CLOSE agent_prn;
   $FREE  agent_prn;

   $DROP TABLE AGENT;

   return M_CM_OK;
   
errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

long car316_body2()
{
     $char  iquota[7], iquota_t[7], iquota_n[7], ngroup[21];
     $char  buf1[21], mcheck[2], ipolicy[21], igroup[6], igroup_t[6];
     $char  group1[20], group2[20];
     $char  ncode1[20], ncode2[20];
     $char  ibranch[6],nbranch[26];
     $char  ibranch_p[6],igroup_p[6];
     $char  iofficer[11],iofficer_t[11],iof_name[11];
     $int   renew_cnt, con_cnt, renew_cnt1, con_cnt1, renew_cnt2, con_cnt2;
     $int   myear, qorder;
     $long  prem, prem1, prem2;
     $char  iresource_tmp[2],icomm_obj[11];
     $char  DBName2[5], sFullName2[20];
     $char  stmt[1024];
     $char  inext_ply[21], dply_end[13], unit_in[6], dply_end_tmp[13];
     $long  lDplyend;
     $char  group3[20];
     $char  ileader[11];
     $char  nleader[11];
     $char  bzfrom[3],bzfrom1[2];
     $char  nbzfrom[21];
     $char  ibroker[11];
     $char  ibroker_top[11];
     $int   iPAflag;
     $int   iMotorflag;
     $int   fmontary, rc;
     $double p_renew_rate;
     $double p_avg_rate;

     $int   renew_cnt_1a,con_cnt_1a;
     $int   renew_cnt_2a,con_cnt_2a;
     $int   renew_cnt_3a,con_cnt_3a;
     $int   renew_cnt_1_all,con_cnt_1_all;
     $int   renew_cnt_2_all,con_cnt_2_all;
     $int   renew_cnt_1_2_all,con_cnt_1_2_all;
     $int   renew_cnt_3_all,con_cnt_3_all;

     $int   renew_cnt_1b,con_cnt_1b;
     $int   renew_cnt_2b,con_cnt_2b;
     $int   renew_cnt_3b,con_cnt_3b;

     $int   renew_cnt_4a,con_cnt_4a;
     $int   renew_cnt_5a,con_cnt_5a;
     $int   renew_cnt_6a,con_cnt_6a;
     $int   renew_cnt_7a,con_cnt_7a;

     $int   renew_cnt_route;
     $int   con_cnt_route;
     $long  prem_route;

     $int   renew_cnt_all;
     $int   con_cnt_all;
     $long  prem_all;

     $long  prem_1a,prem_1b, prem_1_all;
     $long  prem_2a,prem_2b, prem_2_all, prem_1_2_all;
     $long  prem_3a,prem_3b, prem_3_all;
     $long  prem_4a;
     $long  prem_5a;
     $long  prem_6a;
     $long  prem_7a;

     $long  p_avg_prem;

     int  ctotal=0;
 
     printf(" bef create non_agent \n");

     $CREATE TEMP TABLE NON_AGENT     
        (qorder        integer,
         igroup        char(6),
         ibranch       char(6),
         group1        char(20),
         group2        char(20),
         group3        char(20),     /*** new add  ***/
         nbranch       char(25),
         ngroup        char(20),
         nleader       char(10),     /*** new add ***/
         iofficer      char(10),

         renew_cnt_1a  integer default 0 not null,
         con_cnt_1a    integer default 0 not null,
         prem_1a       decimal(10,0) default 0 not null,      /***  �O�I�g���H  ����   ***/

         renew_cnt_1b  integer default 0 not null,
         con_cnt_1b    integer default 0 not null,
         prem_1b       decimal(10,0) default 0 not null,      /***  �O�I�g���H  �@��   ***/

         renew_cnt_2a  integer default 0 not null,
         con_cnt_2a    integer default 0 not null,
         prem_2a       decimal(10,0) default 0 not null,      /***  �O�I�N�z�H  ����   ***/

         renew_cnt_2b  integer default 0 not null,
         con_cnt_2b    integer default 0 not null,
         prem_2b       decimal(10,0) default 0 not null,      /***  �O�I�N�z�H  �@��   ***/

         renew_cnt_3a  integer default 0 not null,
         con_cnt_3a    integer default 0 not null,
         prem_3a       decimal(10,0) default 0 not null,      /***  �O�I�~�ȭ�  ���u�~�ȭ�   ***/

         renew_cnt_3b  integer default 0 not null,
         con_cnt_3b    integer default 0 not null,
         prem_3b       decimal(10,0) default 0 not null,      /***  �O�I�g���H  ����~�ȭ�   ***/

         renew_cnt_4a  integer default 0 not null,
         con_cnt_4a    integer default 0 not null,
         prem_4a       decimal(10,0) default 0 not null,      /***  �����~��   ***/


         renew_cnt_5a  integer default 0 not null,
         con_cnt_5a    integer default 0 not null,
         prem_5a       decimal(10,0) default 0 not null,      /***  ���Y���~  ***/

         renew_cnt_6a  integer default 0 not null,
         con_cnt_6a    integer default 0 not null,
         prem_6a       decimal(10,0) default 0 not null,      /***  ����~��   ***/

         renew_cnt_7a  integer default 0 not null,
         con_cnt_7a    integer default 0 not null,
         prem_7a       decimal(10,0) default 0 not null      /***  �����M��   ***/
        ) WITH NO LOG;

     printf(" bef create non_agent cursor \n");

     $DECLARE non_agent CURSOR FOR
       SELECT ipolicy, a.iofficer, a.iquota, iresource, inext_ply, con_cnt, prem,
              a.ibroker, a.iPAflag, a.iMotorflag
         INTO $ipolicy, $iofficer, $iquota, $iresource_tmp, $inext_ply,
              $con_cnt, $prem, $ibroker, $iPAflag, $iMotorflag
         FROM CAR316_NEW a,officer b
        WHERE a.iofficer = b.iofficer
          AND b.imgr = '2'
        ORDER BY 3,2;

     $OPEN non_agent;
     while(1)
     {
       $FETCH non_agent;
       if(SQLCODE == SQLNOTFOUND) break;
  
       printf("ipolicy[%s]\n",ipolicy);     
 
       $SELECT a.ngroup,a.igroup,b.group1,b.group2,b.ibranch,b.nbranch,a.qorder
         INTO $ngroup,$igroup,$group1,$group2,$ibranch,$nbranch,$qorder
         FROM sa_frm_module a, sa_branch_type b
        WHERE a.ifrm_module = '01'
          AND b.ibranch = $iquota
          AND a.igroup = b.igroup
          AND a.igroup not in ('YYY','ZZZ','XXX');
           
       $select ncode
       into $ncode1
       from cu_code_data
       where itype='18'
        AND   icode=$group1;
       
       $select ncode
       into $ncode2
       from cu_code_data
       where itype='19'
       and   icode=$group2;

       $select nlevel3
          into $group3
          from sysdb:v_quota
         where icode = $iquota;
       if (SQLCODE == SQLNOTFOUND)
       {
          strcpy(group3," ");
       }

       $select ileader
          into $ileader
          from officer
         where iofficer = $iofficer;
       if (SQLCODE == SQLNOTFOUND)
       {
          strcpy(ileader," ");
       }

       $select nname
          into $nleader
          from officer
         where iofficer = $ileader;
       if (SQLCODE == SQLNOTFOUND)
       {
          strcpy(nleader," ");
       }

       if (ibroker[0] == '\0' || ibroker[0] == ' ')
       {
           $select icar_broker
              into $ibroker
              from officer_broker
             where iofficer = $iofficer;
           if (SQLCODE == SQLNOTFOUND)
           {
              strcpy(ibroker," ");
           }
       }

       /* bzfrom ��H �g��N�����I����H�d�� modify by sylvia (1040224003_C3) */
       
       /* $select bzfrom, fmontary, ibroker_top
          into $bzfrom, $fmontary, $ibroker_top
          from broker_agent
         where ibroker = $ibroker
           and itype = '2';
       if (SQLCODE == SQLNOTFOUND)
       {
          $select bzfrom, fmontary, ibroker_top
             into $bzfrom, $fmontary, $ibroker_top
             from broker_agent
            where ibroker = $ibroker;

           if (SQLCODE == SQLNOTFOUND)
           {
              strcpy(bzfrom,"10");
              fmontary = 0;
           }
       }*/
       
       /* ���u�g�춷���d�I����H modify by sylvia 105.04.27 */
       $select icomm_obj into $icomm_obj from officer where iofficer =  $iofficer;
       $select fmontary, ibroker_top
          into $fmontary, $ibroker_top
          from broker_agent 
         where ibroker = $icomm_obj;
        if (SQLCODE == SQLNOTFOUND)
       {
            $select fmontary, ibroker_top
               into $fmontary, $ibroker_top
               from broker_agent
              where ibroker = (select ibroker_top from v_commission_obj where icomm_obj = $icomm_obj);
       }
       
       /* ��H�I�s cm_get_bzfrom ���obzfrom   modiby by sylvia 106.01.25 (1060111005_C3) */
       rc = cm_get_bzfrom(iofficer," "," ",bzfrom);
       strncpy(bzfrom1, bzfrom, 1);
       bzfrom1[1]='\0';
       
       printf("2748 ������ iofficer=[%s]bzfrom=[%s]\n",iofficer,bzfrom);
       sprintf(stmt,
       " select first 1 ncode      \
           from cu_code_data       \
          where itype   =   'C2'   \
            and tcode_remark[1,1] = ? \
            order by tcode_remark ");
       $prepare bzid from $stmt;
       $execute bzid
           into $nbzfrom
          using $bzfrom1;
       if (SQLCODE == SQLNOTFOUND)
       {
          strcpy(nbzfrom," ");
       }


/**
00          ���Ϥ�
10          �O�I�~�ȭ�
20          �O�I�N�z�H�B21�O�I�N�z�H(������O)
30          �O�I�g���H�B31�O�I�g���H(������O)
40          �����~�ȡB41(�����~��)
90          ��L�q��

fmontart 0  �D����
         1  ����



30          �O�I�g���H
20          �O�I�N�z�H

**/

/**
���j�q��->���Y���~->����~��->�����M��
**/

           if (iresource_tmp[0] == '8')
           {
            $INSERT INTO NON_AGENT
               (qorder,igroup,ibranch,group1,group2,group3,nbranch,ngroup,nleader,iofficer,
                renew_cnt_1a, con_cnt_1a, prem_1a,  renew_cnt_1b, con_cnt_1b, prem_1b,
                renew_cnt_2a, con_cnt_2a, prem_2a,  renew_cnt_2b, con_cnt_2b, prem_2b,
                renew_cnt_3a, con_cnt_3a, prem_3a,  renew_cnt_3b, con_cnt_3b, prem_3b,
                renew_cnt_4a, con_cnt_4a, prem_4a,  
                renew_cnt_5a, con_cnt_5a, prem_5a,
                renew_cnt_6a, con_cnt_6a, prem_6a,
                renew_cnt_7a, con_cnt_7a, prem_7a)
             VALUES
               ($qorder,$igroup,$ibranch,$ncode1,$ncode2,$group3,$nbranch,$ngroup,$nleader,$iofficer,
                0,0,0, 0,0,0,
                0,0,0, 0,0,0,
                0,0,0, 0,0,0,
                0,0,0,
                1,$con_cnt,$prem,
                0,0,0,
                0,0,0);
           }
           else if (iPAflag == 1)
           {
            $INSERT INTO NON_AGENT
               (qorder,igroup,ibranch,group1,group2,group3,nbranch,ngroup,nleader,iofficer,
                renew_cnt_1a, con_cnt_1a, prem_1a,  renew_cnt_1b, con_cnt_1b, prem_1b,
                renew_cnt_2a, con_cnt_2a, prem_2a,  renew_cnt_2b, con_cnt_2b, prem_2b,
                renew_cnt_3a, con_cnt_3a, prem_3a,  renew_cnt_3b, con_cnt_3b, prem_3b,
                renew_cnt_4a, con_cnt_4a, prem_4a,  
                renew_cnt_5a, con_cnt_5a, prem_5a,
                renew_cnt_6a, con_cnt_6a, prem_6a,
                renew_cnt_7a, con_cnt_7a, prem_7a)
             VALUES
               ($qorder,$igroup,$ibranch,$ncode1,$ncode2,$group3,$nbranch,$ngroup,$nleader,$iofficer,
                0,0,0, 0,0,0,
                0,0,0, 0,0,0,
                0,0,0, 0,0,0,
                0,0,0,
                0,0,0,
                1,$con_cnt,$prem,                
                0,0,0);
           }
           else if (iMotorflag == 1)
           {
            $INSERT INTO NON_AGENT
               (qorder,igroup,ibranch,group1,group2,group3,nbranch,ngroup,nleader,iofficer,
                renew_cnt_1a, con_cnt_1a, prem_1a,  renew_cnt_1b, con_cnt_1b, prem_1b,
                renew_cnt_2a, con_cnt_2a, prem_2a,  renew_cnt_2b, con_cnt_2b, prem_2b,
                renew_cnt_3a, con_cnt_3a, prem_3a,  renew_cnt_3b, con_cnt_3b, prem_3b,
                renew_cnt_4a, con_cnt_4a, prem_4a,  
                renew_cnt_5a, con_cnt_5a, prem_5a,
                renew_cnt_6a, con_cnt_6a, prem_6a,
                renew_cnt_7a, con_cnt_7a, prem_7a)
             VALUES
               ($qorder,$igroup,$ibranch,$ncode1,$ncode2,$group3,$nbranch,$ngroup,$nleader,$iofficer,
                0,0,0, 0,0,0,
                0,0,0, 0,0,0,
                0,0,0, 0,0,0,
                0,0,0,
                0,0,0,
                                0,0,0,
                1,$con_cnt,$prem);
           }
       else if ((strncmp(bzfrom,"30",2) == 0)||(strncmp(bzfrom,"31",2) == 0))
       {
                  if (fmontary == 1)
                  {
            $INSERT INTO NON_AGENT
               (qorder,igroup,ibranch,group1,group2,group3,nbranch,ngroup,nleader,iofficer,
                renew_cnt_1a, con_cnt_1a, prem_1a,  renew_cnt_1b, con_cnt_1b, prem_1b,
                renew_cnt_2a, con_cnt_2a, prem_2a,  renew_cnt_2b, con_cnt_2b, prem_2b,
                renew_cnt_3a, con_cnt_3a, prem_3a,  renew_cnt_3b, con_cnt_3b, prem_3b,
                renew_cnt_4a, con_cnt_4a, prem_4a,  
                renew_cnt_5a, con_cnt_5a, prem_5a,
                renew_cnt_6a, con_cnt_6a, prem_6a,
                renew_cnt_7a, con_cnt_7a, prem_7a)
             VALUES
               ($qorder,$igroup,$ibranch,$ncode1,$ncode2,$group3,$nbranch,$ngroup,$nleader,$iofficer,
                1,$con_cnt,$prem, 0,0,0,
                0,0,0, 0,0,0,
                0,0,0, 0,0,0,
                0,0,0, 
                0,0,0,
                0,0,0,
                0,0,0);   
                  }
                  else
                  {
            $INSERT INTO NON_AGENT
               (qorder,igroup,ibranch,group1,group2,group3,nbranch,ngroup,nleader,iofficer,
                renew_cnt_1a, con_cnt_1a, prem_1a,  renew_cnt_1b, con_cnt_1b, prem_1b,
                renew_cnt_2a, con_cnt_2a, prem_2a,  renew_cnt_2b, con_cnt_2b, prem_2b,
                renew_cnt_3a, con_cnt_3a, prem_3a,  renew_cnt_3b, con_cnt_3b, prem_3b,
                renew_cnt_4a, con_cnt_4a, prem_4a,  
                renew_cnt_5a, con_cnt_5a, prem_5a,
                renew_cnt_6a, con_cnt_6a, prem_6a,
                renew_cnt_7a, con_cnt_7a, prem_7a)
             VALUES
               ($qorder,$igroup,$ibranch,$ncode1,$ncode2,$group3,$nbranch,$ngroup,$nleader,$iofficer,
                0,0,0, 1,$con_cnt,$prem, 
                0,0,0, 0,0,0,
                0,0,0, 0,0,0,
                0,0,0, 
                0,0,0,
                0,0,0,
                0,0,0);
                  }
       }
       else if ((strncmp(bzfrom,"20",2) == 0)||(strncmp(bzfrom,"21",2) == 0))
       {
                  if (fmontary == 1)
                  {
            $INSERT INTO NON_AGENT
               (qorder,igroup,ibranch,group1,group2,group3,nbranch,ngroup,nleader,iofficer,
                renew_cnt_1a, con_cnt_1a, prem_1a,  renew_cnt_1b, con_cnt_1b, prem_1b,
                renew_cnt_2a, con_cnt_2a, prem_2a,  renew_cnt_2b, con_cnt_2b, prem_2b,
                renew_cnt_3a, con_cnt_3a, prem_3a,  renew_cnt_3b, con_cnt_3b, prem_3b,
                renew_cnt_4a, con_cnt_4a, prem_4a,  
                renew_cnt_5a, con_cnt_5a, prem_5a,
                renew_cnt_6a, con_cnt_6a, prem_6a,
                renew_cnt_7a, con_cnt_7a, prem_7a)
             VALUES
               ($qorder,$igroup,$ibranch,$ncode1,$ncode2,$group3,$nbranch,$ngroup,$nleader,$iofficer,
                0,0,0, 0,0,0,
                1,$con_cnt,$prem, 0,0,0,
                0,0,0, 0,0,0,
                0,0,0, 
                0,0,0,
                0,0,0,
                0,0,0);   
                  }
                  else
                  {
            $INSERT INTO NON_AGENT
               (qorder,igroup,ibranch,group1,group2,group3,nbranch,ngroup,nleader,iofficer,
                renew_cnt_1a, con_cnt_1a, prem_1a,  renew_cnt_1b, con_cnt_1b, prem_1b,
                renew_cnt_2a, con_cnt_2a, prem_2a,  renew_cnt_2b, con_cnt_2b, prem_2b,
                renew_cnt_3a, con_cnt_3a, prem_3a,  renew_cnt_3b, con_cnt_3b, prem_3b,
                renew_cnt_4a, con_cnt_4a, prem_4a,  
                renew_cnt_5a, con_cnt_5a, prem_5a,
                renew_cnt_6a, con_cnt_6a, prem_6a,
                renew_cnt_7a, con_cnt_7a, prem_7a)
             VALUES
               ($qorder,$igroup,$ibranch,$ncode1,$ncode2,$group3,$nbranch,$ngroup,$nleader,$iofficer,
                0,0,0, 0,0,0,
                0,0,0, 1,$con_cnt,$prem,
                0,0,0, 0,0,0,
                0,0,0, 
                0,0,0,
                0,0,0,
                0,0,0);
                  }
       }
           else if (strncmp(bzfrom,"10",2) == 0)
           {
                  if (ibroker_top[0] == '0')
                  {
            $INSERT INTO NON_AGENT
               (qorder,igroup,ibranch,group1,group2,group3,nbranch,ngroup,nleader,iofficer,
                renew_cnt_1a, con_cnt_1a, prem_1a,  renew_cnt_1b, con_cnt_1b, prem_1b,
                renew_cnt_2a, con_cnt_2a, prem_2a,  renew_cnt_2b, con_cnt_2b, prem_2b,
                renew_cnt_3a, con_cnt_3a, prem_3a,  renew_cnt_3b, con_cnt_3b, prem_3b,
                renew_cnt_4a, con_cnt_4a, prem_4a,  
                renew_cnt_5a, con_cnt_5a, prem_5a,
                renew_cnt_6a, con_cnt_6a, prem_6a,
                renew_cnt_7a, con_cnt_7a, prem_7a)
             VALUES
               ($qorder,$igroup,$ibranch,$ncode1,$ncode2,$group3,$nbranch,$ngroup,$nleader,$iofficer,
                0,0,0, 0,0,0,
                0,0,0, 0,0,0,
                1,$con_cnt,$prem, 0,0,0,
                0,0,0, 
                0,0,0,
                0,0,0,
                0,0,0);
                  }
                  else
                  {
            $INSERT INTO NON_AGENT
               (qorder,igroup,ibranch,group1,group2,group3,nbranch,ngroup,nleader,iofficer,
                renew_cnt_1a, con_cnt_1a, prem_1a,  renew_cnt_1b, con_cnt_1b, prem_1b,
                renew_cnt_2a, con_cnt_2a, prem_2a,  renew_cnt_2b, con_cnt_2b, prem_2b,
                renew_cnt_3a, con_cnt_3a, prem_3a,  renew_cnt_3b, con_cnt_3b, prem_3b,
                renew_cnt_4a, con_cnt_4a, prem_4a,  
                renew_cnt_5a, con_cnt_5a, prem_5a,
                renew_cnt_6a, con_cnt_6a, prem_6a,
                renew_cnt_7a, con_cnt_7a, prem_7a)
             VALUES
               ($qorder,$igroup,$ibranch,$ncode1,$ncode2,$group3,$nbranch,$ngroup,$nleader,$iofficer,
                0,0,0, 0,0,0,
                0,0,0, 0,0,0,
                0,0,0, 1,$con_cnt,$prem,
                0,0,0, 
                0,0,0,
                0,0,0,
                0,0,0);
          }
           }
           else if ((strncmp(bzfrom,"40",2) == 0)||(strncmp(bzfrom,"41",2) == 0))
           {
            $INSERT INTO NON_AGENT
               (qorder,igroup,ibranch,group1,group2,group3,nbranch,ngroup,nleader,iofficer,
                renew_cnt_1a, con_cnt_1a, prem_1a,  renew_cnt_1b, con_cnt_1b, prem_1b,
                renew_cnt_2a, con_cnt_2a, prem_2a,  renew_cnt_2b, con_cnt_2b, prem_2b,
                renew_cnt_3a, con_cnt_3a, prem_3a,  renew_cnt_3b, con_cnt_3b, prem_3b,
                renew_cnt_4a, con_cnt_4a, prem_4a,  
                renew_cnt_5a, con_cnt_5a, prem_5a,
                renew_cnt_6a, con_cnt_6a, prem_6a,
                renew_cnt_7a, con_cnt_7a, prem_7a)
             VALUES
               ($qorder,$igroup,$ibranch,$ncode1,$ncode2,$group3,$nbranch,$ngroup,$nleader,$iofficer,
                0,0,0, 0,0,0,
                0,0,0, 0,0,0,
                0,0,0, 0,0,0,
                1,$con_cnt,$prem,
                0,0,0,
                0,0,0,
                0,0,0);
           }
           else
           {
            printf("Another renew_cnt[%d]\n",1);
                        printf("        con_cnt[%d]\n",con_cnt);
                        printf("        prem   [%ld]\n",prem);
                        printf("ipolicy[%s]\n",ipolicy);
            /***   
                        $insert into renew_wk1 values ($ipolicy);
            ***/
           }

       ctotal++;
     }  /******  End of non_agent cursor while  *****/

     $CLOSE non_agent;
     $FREE  non_agent;

     printf("bef com_cur1v \n");

         $DECLARE com_cur1v CURSOR FOR 
           SELECT qorder, igroup, ibranch, group1, group2, group3, nbranch, ngroup, nleader, iofficer, 
                      sum(renew_cnt_1a) as renew_cnt_1a,
                      sum(con_cnt_1a)   as con_cnt_1a,
                      sum(prem_1a)      as prem_1a,

                      sum(renew_cnt_1b) as renew_cnt_1b,
                      sum(con_cnt_1b)   as con_cnt_1b,
                      sum(prem_1b)      as prem_1b,

       sum(renew_cnt_1a + renew_cnt_1b) as renew_cnt_1_all,
           sum(con_cnt_1a + con_cnt_1b) as con_cnt_1_all,
                 sum(prem_1a + prem_1b) as prem_1_all,

                      sum(renew_cnt_2a) as renew_cnt_2a,
                      sum(con_cnt_2a)   as con_cnt_2a,
                      sum(prem_2a)      as prem_2a,

                      sum(renew_cnt_2b) as renew_cnt_2b,
                      sum(con_cnt_2b)   as con_cnt_2b,
                      sum(prem_2b)      as prem_2b,
                      
       sum(renew_cnt_2a + renew_cnt_2b) as renew_cnt_2_all,
           sum(con_cnt_2a + con_cnt_2b) as con_cnt_2_all,
                 sum(prem_2a + prem_2b) as prem_2_all,                      

       sum(renew_cnt_1a + renew_cnt_1b + renew_cnt_2a + renew_cnt_2b) as renew_cnt_1_2_all,
           sum(con_cnt_1a + con_cnt_1b + con_cnt_2a + con_cnt_2b) as con_cnt_1_2_all,
                 sum(prem_1a + prem_1b + prem_2a + prem_2b) as prem_1_2_all,
                 
                      sum(renew_cnt_3a) as renew_cnt_3a,
                      sum(con_cnt_3a)   as con_cnt_3a,
                      sum(prem_3a)      as prem_3a,

                  sum(renew_cnt_3b) as renew_cnt_3b,
                      sum(con_cnt_3b)   as con_cnt_3b,
                      sum(prem_3b)      as prem_3b,

       sum(renew_cnt_3a + renew_cnt_3b) as renew_cnt_3_all,
           sum(con_cnt_3a + con_cnt_3b) as con_cnt_3_all,
                 sum(prem_3a + prem_3b) as prem_3_all, 
                 
                      sum(renew_cnt_4a) as renew_cnt_4a,
                      sum(con_cnt_4a)   as con_cnt_4a,
                      sum(prem_4a)      as prem_4a,

                      sum(renew_cnt_5a) as renew_cnt_5a,
                      sum(con_cnt_5a)   as con_cnt_5a,
                      sum(prem_5a)      as prem_5a,

                      sum(renew_cnt_6a) as renew_cnt_6a,
                      sum(con_cnt_6a)   as con_cnt_6a,
                      sum(prem_6a)      as prem_6a,

                      sum(renew_cnt_7a) as renew_cnt_7a,
                      sum(con_cnt_7a)   as con_cnt_7a,
                      sum(prem_7a)      as prem_7a,

                      sum(renew_cnt_1a + renew_cnt_1b + renew_cnt_2a + renew_cnt_2b + 
                      renew_cnt_3a + renew_cnt_3b + renew_cnt_4a) as renew_cnt_route,

                      sum(con_cnt_1a + con_cnt_1b + con_cnt_2a + con_cnt_2b +
                      con_cnt_3a + con_cnt_3b + con_cnt_4a) as con_cnt_route,

                      sum(prem_1a + prem_1b + prem_2a + prem_2b + 
                      prem_3a + prem_3b + prem_4a) as prem_route,

                      sum(renew_cnt_1a + renew_cnt_1b + renew_cnt_2a + renew_cnt_2b + 
                      renew_cnt_3a + renew_cnt_3b + renew_cnt_4a + renew_cnt_5a +
                      renew_cnt_6a + renew_cnt_7a) as renew_cnt_all,

                      sum(con_cnt_1a + con_cnt_1b + con_cnt_2a + con_cnt_2b +
                      con_cnt_3a + con_cnt_3b + con_cnt_4a + con_cnt_5a +
                      con_cnt_6a + con_cnt_7a) as con_cnt_all,

                      sum(prem_1a + prem_1b + prem_2a + prem_2b + 
                      prem_3a + prem_3b + prem_4a + prem_5a +
                      prem_6a + prem_7a) as prem_all

         INTO $qorder,$igroup,$ibranch,$group1,$group2,$group3,$nbranch,$ngroup,$nleader, $iofficer, 
              $renew_cnt_1a, $con_cnt_1a, $prem_1a,
              $renew_cnt_1b, $con_cnt_1b, $prem_1b,
              $renew_cnt_1_all, $con_cnt_1_all, $prem_1_all,
              $renew_cnt_2a, $con_cnt_2a, $prem_2a,
              $renew_cnt_2b, $con_cnt_2b, $prem_2b,
              $renew_cnt_2_all, $con_cnt_2_all, $prem_2_all,
              $renew_cnt_1_2_all, $con_cnt_1_2_all, $prem_1_2_all,
              $renew_cnt_3a, $con_cnt_3a, $prem_3a,
              $renew_cnt_3b, $con_cnt_3b, $prem_3b,
              $renew_cnt_3_all, $con_cnt_3_all, $prem_3_all,
              $renew_cnt_4a, $con_cnt_4a, $prem_4a,
              $renew_cnt_5a, $con_cnt_5a, $prem_5a,
              $renew_cnt_6a, $con_cnt_6a, $prem_6a,
              $renew_cnt_7a, $con_cnt_7a, $prem_7a,
              $renew_cnt_route,$con_cnt_route,$prem_route,
              $renew_cnt_all,$con_cnt_all,$prem_all
         FROM NON_AGENT
        GROUP BY 1,2,3,4,5,6,7,8,9,10
        ORDER BY qorder,ibranch,iofficer;
     $OPEN com_cur1v;
     $FETCH com_cur1v;
 
     printf("aft fetch\n");    
     if(SQLCODE == SQLNOTFOUND)
     {
       printf("Non_agent first fetch failed!!!\n");
       goto errexit;
     } 

     printf("flag 1\n");
     rgu_put_body_string(1, cm_get_sysd(), 1);
     rgu_put_body_string(1, sTitle,   1);        
     rgu_put_body_string(1, " ",      1);
     rgu_put_body_string(1, dbgn_inf, 1);
     rgu_put_body_string(1, dend_inf, 1);
     rgu_put_body(1);

     while(1)
     {
            $SELECT nname INTO $iof_name
               FROM officer
              WHERE iofficer = $iofficer;
            if(SQLCODE == SQLNOTFOUND) 
            {
               strcpy(iof_name," ");
            }
            strcpy(group1, trim(group1));         
            rgu_put_body_string(data_line, group1, 1);
            strcpy(group2, trim(group2));
            rgu_put_body_string(data_line, group2, 1);
            strcpy(group3, trim(group3));
            rgu_put_body_string(data_line, group3, 1);
            strcpy(ngroup, trim(ngroup));       
            rgu_put_body_string(data_line, ngroup, 1);
            rgu_put_body_string(data_line, nbranch, 1);
            rgu_put_body_string(data_line, nleader, 1);
            rgu_put_body_string(data_line, iofficer, 1);
            rgu_put_body_string(data_line, iof_name, 1);
            
            /****** �O�I�g���H  ���� ******/
            /*  �i��O���   */
            rfmtlong(renew_cnt_1a,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O���     */
            rfmtlong(con_cnt_1a,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O�v       */                        
            if (renew_cnt_1a == 0)
            {
               p_renew_rate = 0;
            }
            else
            {
               p_renew_rate = d45((double)con_cnt_1a/(double)renew_cnt_1a,2);
            }
            rfmtdouble(p_renew_rate,"---&.&&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ñ��O�O  */
            rfmtlong(prem_1a,"-----------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
 
            /*  �����O�O  */
            if (con_cnt_1a == 0)
            {
               p_avg_prem = 0;
            }
            else
            {
               p_avg_prem = d45((double)prem_1a / (double)con_cnt_1a, 0);
            }
            rfmtlong(p_avg_prem,"-----------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);
            
            /****** �O�I�g���H  �@�� ******/
            /*  �i��O���   */
            rfmtlong(renew_cnt_1b,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

                        /*  ��O���     */
            rfmtlong(con_cnt_1b,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O�v       */                        
            if (renew_cnt_1b == 0)
            {
               p_renew_rate = 0;
            }
            else
            {
               p_renew_rate = d45((double)con_cnt_1b/(double)renew_cnt_1b,2);
            }
            rfmtdouble(p_renew_rate,"---&.&&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ñ��O�O  */
            rfmtlong(prem_1b,"-----------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
 
            /*  �����O�O  */
            if (con_cnt_1b == 0)
            {
               p_avg_prem = 0;
            }
            else
            {
               p_avg_prem = d45((double)prem_1b / (double)con_cnt_1b, 0);
            }
            rfmtlong(p_avg_prem,"-----------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /****** �O�I�g���H  �X�p ******/
            /*  �i��O���   */
            rfmtlong(renew_cnt_1_all,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O���     */
            rfmtlong(con_cnt_1_all,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O�v       */                        
            if (renew_cnt_1_all == 0)
            {
               p_renew_rate = 0;
            }
            else
            {
               p_renew_rate = d45((double)con_cnt_1_all/(double)renew_cnt_1_all,2);
            }
            rfmtdouble(p_renew_rate,"---&.&&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ñ��O�O  */
            rfmtlong(prem_1_all,"-----------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
 
            /*  �����O�O  */
            if (con_cnt_1_all == 0)
            {
               p_avg_prem = 0;
            }
            else
            {
               p_avg_prem = d45((double)prem_1_all / (double)con_cnt_1_all, 0);
            }
            rfmtlong(p_avg_prem,"-----------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);
                        
            
            /****** �O�I�N�z�H  ���� ******/           
            /*  �i��O���   */
            rfmtlong(renew_cnt_2a,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O���     */
            rfmtlong(con_cnt_2a,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O�v       */                        
            if (renew_cnt_2a == 0)
            {
               p_renew_rate = 0;
            }
            else
            {
               p_renew_rate = d45((double)con_cnt_2a/(double)renew_cnt_2a,2);
            }
            rfmtdouble(p_renew_rate,"---&.&&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ñ��O�O  */
            rfmtlong(prem_2a,"-----------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
 
            /*  �����O�O  */
            if (con_cnt_2a == 0)
            {
               p_avg_prem = 0;
            }
            else
            {
               p_avg_prem = d45((double)prem_2a / (double)con_cnt_2a, 0);
            }
            rfmtlong(p_avg_prem,"-----------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /****** �O�I�N�z�H  �@�� ******/
            /*  �i��O���   */
            rfmtlong(renew_cnt_2b,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O���     */
            rfmtlong(con_cnt_2b,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O�v       */                        
            if (renew_cnt_2b == 0)
            {
               p_renew_rate = 0;
            }
            else
            {
               p_renew_rate = d45((double)con_cnt_2b/(double)renew_cnt_2b,2);
            }
            rfmtdouble(p_renew_rate,"---&.&&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ñ��O�O  */
            rfmtlong(prem_2b,"-----------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
 
            /*  �����O�O  */
            if (con_cnt_2b == 0)
            {
               p_avg_prem = 0;
            }
            else
            {
               p_avg_prem = d45((double)prem_2b / (double)con_cnt_2b, 0);
            }
            rfmtlong(p_avg_prem,"-----------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /****** �O�I�N�z�H  �X�p ******/
            /*  �i��O���   */
            rfmtlong(renew_cnt_2_all,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O���     */
            rfmtlong(con_cnt_2_all,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O�v       */                        
            if (renew_cnt_2_all == 0)
            {
               p_renew_rate = 0;
            }
            else
            {
               p_renew_rate = d45((double)con_cnt_2_all/(double)renew_cnt_2_all,2);
            }
            rfmtdouble(p_renew_rate,"---&.&&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ñ��O�O  */
            rfmtlong(prem_2_all,"-----------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
 
            /*  �����O�O  */
            if (con_cnt_2_all == 0)
            {
               p_avg_prem = 0;
            }
            else
            {
               p_avg_prem = d45((double)prem_2_all / (double)con_cnt_2_all, 0);
            }
            rfmtlong(p_avg_prem,"-----------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);
                        
            /****** �O�g�N  �X�p ******/
            /*  �i��O���   */
            rfmtlong(renew_cnt_1_2_all,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O���     */
            rfmtlong(con_cnt_1_2_all,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O�v       */                        
            if (renew_cnt_1_2_all == 0)
            {
               p_renew_rate = 0;
            }
            else
            {
               p_renew_rate = d45((double)con_cnt_1_2_all/(double)renew_cnt_1_2_all,2);
            }
            rfmtdouble(p_renew_rate,"---&.&&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ñ��O�O  */
            rfmtlong(prem_1_2_all,"-----------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
 
            /*  �����O�O  */
            if (con_cnt_1_2_all == 0)
            {
               p_avg_prem = 0;
            }
            else
            {
               p_avg_prem = d45((double)prem_1_2_all / (double)con_cnt_1_2_all, 0);
            }
            rfmtlong(p_avg_prem,"-----------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);
            
            /****** �O�I�~�ȭ�  ���u�~�ȭ� ******/            
            /*  �i��O���   */
            rfmtlong(renew_cnt_3a,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O���     */
            rfmtlong(con_cnt_3a,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O�v       */                        
            if (renew_cnt_3a == 0)
            {
               p_renew_rate = 0;
            }
            else
            {
               p_renew_rate = d45((double)con_cnt_3a/(double)renew_cnt_3a,2);
            }
            rfmtdouble(p_renew_rate,"---&.&&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ñ��O�O  */
            rfmtlong(prem_3a,"-----------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
 
            /*  �����O�O  */
            if (con_cnt_3a == 0)
            {
               p_avg_prem = 0;
            }
            else
            {
               p_avg_prem = d45((double)prem_3a / (double)con_cnt_3a, 0);
            }
            rfmtlong(p_avg_prem,"-----------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /****** �O�I�~�ȭ�  ����~�ȭ� ******/
            /*  �i��O���   */
            rfmtlong(renew_cnt_3b,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O���     */
            rfmtlong(con_cnt_3b,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O�v       */                        
            if (renew_cnt_3b == 0)
            {
               p_renew_rate = 0;
            }
            else
            {
               p_renew_rate = d45((double)con_cnt_3b/(double)renew_cnt_3b,2);
            }
            rfmtdouble(p_renew_rate,"---&.&&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ñ��O�O  */
            rfmtlong(prem_3b,"-----------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
 
            /*  �����O�O  */
            if (con_cnt_3b == 0)
            {
               p_avg_prem = 0;
            }
            else
            {
               p_avg_prem = d45((double)prem_3b / (double)con_cnt_3b, 0);
            }
            rfmtlong(p_avg_prem,"-----------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);


            /****** �O�I�~�ȭ�  �X�p ******/
            /*  �i��O���   */
            rfmtlong(renew_cnt_3_all,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O���     */
            rfmtlong(con_cnt_3_all,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O�v       */                        
            if (renew_cnt_3_all == 0)
            {
               p_renew_rate = 0;
            }
            else
            {
               p_renew_rate = d45((double)con_cnt_3_all/(double)renew_cnt_3_all,2);
            }
            rfmtdouble(p_renew_rate,"---&.&&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ñ��O�O  */
            rfmtlong(prem_3_all,"-----------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
 
            /*  �����O�O  */
            if (con_cnt_3_all == 0)
            {
               p_avg_prem = 0;
            }
            else
            {
               p_avg_prem = d45((double)prem_3_all / (double)con_cnt_3_all, 0);
            }
            rfmtlong(p_avg_prem,"-----------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);
            
            /****** �����~�� ******/
            /*  �i��O���   */
            rfmtlong(renew_cnt_4a,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O���     */
            rfmtlong(con_cnt_4a,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O�v       */                        
            if (renew_cnt_4a == 0)
            {
               p_renew_rate = 0;
            }
            else
            {
               p_renew_rate = d45((double)con_cnt_4a/(double)renew_cnt_4a,2);
            }
            rfmtdouble(p_renew_rate,"---&.&&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ñ��O�O  */
            rfmtlong(prem_4a,"-----------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
 
            /*  �����O�O  */
            if (con_cnt_4a == 0)
            {
               p_avg_prem = 0;
            }
            else
            {
               p_avg_prem = d45((double)prem_4a / (double)con_cnt_4a, 0);
            }
            rfmtlong(p_avg_prem,"-----------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /****** ���j�q���X�p ******/
            /*  �i��O���   */
            rfmtlong(renew_cnt_route,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O���     */
            rfmtlong(con_cnt_route,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O�v       */                        
            if (renew_cnt_route == 0)
            {
               p_renew_rate = 0;
            }
            else
            {
               p_renew_rate = d45((double)con_cnt_route/(double)renew_cnt_route,2);
            }
            rfmtdouble(p_renew_rate,"---&.&&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ñ��O�O  */
            rfmtlong(prem_route,"-----------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
 
            /*  �����O�O  */
            if (con_cnt_route == 0)
            {
               p_avg_prem = 0;
            }
            else
            {
               p_avg_prem = d45((double)prem_route / (double)con_cnt_route , 0);
            }
            rfmtlong(p_avg_prem,"-----------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /****** ���Y���~ ******/
            /*  �i��O���   */
            rfmtlong(renew_cnt_5a,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O���     */
            rfmtlong(con_cnt_5a,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O�v       */                        
            if (renew_cnt_5a == 0)
            {
               p_renew_rate = 0;
            }
            else
            {
               p_renew_rate = d45((double)con_cnt_5a/(double)renew_cnt_5a,2);
            }
            rfmtdouble(p_renew_rate,"---&.&&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ñ��O�O  */
            rfmtlong(prem_5a,"-----------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
 
            /*  �����O�O  */
            if (con_cnt_5a == 0)
            {
               p_avg_prem = 0;
            }
            else
            {
               p_avg_prem = d45((double)prem_5a / (double)con_cnt_5a, 0);
            }
            rfmtlong(p_avg_prem,"-----------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /****** ����~�� ******/
            /*  �i��O���   */
            rfmtlong(renew_cnt_6a,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O���     */
            rfmtlong(con_cnt_6a,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O�v       */                        
            if (renew_cnt_6a == 0)
            {
               p_renew_rate = 0;
            }
            else
            {
               p_renew_rate = d45((double)con_cnt_6a/(double)renew_cnt_6a,2);
            }
            rfmtdouble(p_renew_rate,"---&.&&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ñ��O�O  */
            rfmtlong(prem_6a,"-----------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
 
            /*  �����O�O  */
            if (con_cnt_6a == 0)
            {
               p_avg_prem = 0;
            }
            else
            {
               p_avg_prem = d45((double)prem_6a / (double)con_cnt_6a, 0);
            }
            rfmtlong(p_avg_prem,"-----------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /****** �����M�� ******/
            /*  �i��O���   */
            rfmtlong(renew_cnt_7a,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O���     */
            rfmtlong(con_cnt_7a,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O�v       */                        
            if (renew_cnt_7a == 0)
            {
               p_renew_rate = 0;
            }
            else
            {
               p_renew_rate = d45((double)con_cnt_7a/(double)renew_cnt_7a,2);
            }
            rfmtdouble(p_renew_rate,"---&.&&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ñ��O�O  */
            rfmtlong(prem_7a,"-----------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
 
            /*  �����O�O  */
            if (con_cnt_7a == 0)
            {
               p_avg_prem = 0;
            }
            else
            {
               p_avg_prem = d45((double)prem_7a / (double)con_cnt_7a, 0);
            }
            rfmtlong(p_avg_prem,"-----------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);


            /*  �i��O���   */
            rfmtlong(renew_cnt_all,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O���     */
            rfmtlong(con_cnt_all,"------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ��O�v       */                        
            if (renew_cnt_all == 0)
            {
               p_renew_rate = 0;
            }
            else
            {
               p_renew_rate = d45((double)con_cnt_all/(double)renew_cnt_all,2);
            }
            rfmtdouble(p_renew_rate,"---&.&&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            /*  ñ��O�O  */
            rfmtlong(prem_all,"-----------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
 
            /*  �����O�O  */
            if (con_cnt_all == 0)
            {
               p_avg_prem = 0;
            }
            else
            {
               p_avg_prem = d45((double)prem_all / (double)con_cnt_all , 0);
            }
            rfmtlong(p_avg_prem,"-----------&",buf1);
            rgu_put_body_string(data_line, buf1, 1);

            printf("end \n");

            rgu_put_body(data_line);
            max_cnt = max_cnt + 1;
            $FETCH com_cur1v;
            if(SQLCODE == SQLNOTFOUND) break;
     }  /****** End of com_cur cursor while  ******/
     $CLOSE com_cur1v;
     $FREE  com_cur1v;

     printf("non_agent End!!!\n");

     return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}


long car316_body3()
{
     $char  iresource[2], ngroup[21], iresource_t[2], iresource_n[2];
     $char  buf1[21], mcheck[2], ipolicy[21];
     $long  renew_cnt, con_cnt, renew_cnt1, con_cnt1, renew_cnt2, con_cnt2;
     $int   myear, qorder;
     $double  prem, prem1, prem2;

     $CREATE TEMP TABLE RESOURCE
        (qorder        integer,
         iresource     char(1),
         ngroup        char(20),
         renew_cnt     integer       default 0 not null,
         con_cnt       integer       default 0 not null,
         prem          decimal(12,0) default 0 not null,
         renew_cnt1    integer       default 0 not null,
         con_cnt1      integer       default 0 not null,
         prem1         decimal(12,0) default 0 not null
        )WITH NO LOG;

     $DECLARE resource CURSOR FOR
       SELECT igroup, qorder, ngroup
         INTO $iresource, $qorder, $ngroup
         FROM sa_frm_module
        WHERE ifrm_module = '03'
        ORDER BY 2;

     $OPEN resource;

     while(1)
     {
          $FETCH resource;
          if(SQLCODE == SQLNOTFOUND) break;

          strcpy(iresource, trim(iresource));

          $INSERT INTO RESOURCE
             (qorder, iresource, ngroup, renew_cnt, con_cnt, prem,
              renew_cnt1, con_cnt1, prem1)
           VALUES
             ($qorder, $iresource, $ngroup, 0, 0, 0, 0, 0, 0);
     }
     $CLOSE resource;
     $FREE  resource;

     $DECLARE res_cur CURSOR FOR
       SELECT iresource, myear, count(*), sum(con_cnt), sum(prem)
         INTO $iresource, $myear, $renew_cnt, $con_cnt, $prem
         FROM CAR316
        GROUP BY 1, 2;

     $OPEN res_cur;
     while(1)
     {
          $FETCH res_cur;
          if(SQLCODE == SQLNOTFOUND) break;

          if(myear == 1)
          {
             $UPDATE RESOURCE
                 SET renew_cnt = renew_cnt + $renew_cnt,
                     con_cnt = con_cnt + $con_cnt,
                     prem    = prem    + $prem
               WHERE iresource = $iresource;
          }
          else
          {
             $UPDATE RESOURCE
                 SET renew_cnt1 = renew_cnt1 + $renew_cnt,
                     con_cnt1 = con_cnt1 + $con_cnt,
                     prem1    = prem1    + $prem
               WHERE iresource = $iresource;
          }
     }  /******  End of resourec  cursor while  *****/
     $CLOSE res_cur;
     $FREE  res_cur;

    /*   mark by new resource
     $DECLARE res_cur1 CURSOR FOR
       SELECT iresource_t, myear, sum(con_cnt), sum(prem)
         INTO $iresource, $myear, $con_cnt, $prem
         FROM CAR316
        GROUP BY 1, 2;

     $OPEN res_cur1;
     while(1)
     {
          $FETCH res_cur1;
          if(SQLCODE == SQLNOTFOUND) break;

          if(myear == 1)
          {
             $UPDATE RESOURCE
                 SET con_cnt = con_cnt + $con_cnt,
                     prem    = prem    + $prem
               WHERE iresource = $iresource;
          }
          else
          {
             $UPDATE RESOURCE
                 SET con_cnt1 = con_cnt1 + $con_cnt,
                     prem1    = prem1    + $prem
               WHERE iresource = $iresource;
          }
     }
     $CLOSE res_cur1;
     $FREE  res_cur1;

     */
     printf("Resource Update End!!!\n");

     $DECLARE res_form CURSOR FOR
       SELECT qorder, iresource, ngroup, renew_cnt, con_cnt, prem,
              renew_cnt1, con_cnt1, prem1
         INTO $qorder, $iresource, $ngroup, $renew_cnt, $con_cnt, $prem,
              $renew_cnt1, $con_cnt1, $prem1
         FROM RESOURCE
        ORDER BY 1;

     $OPEN res_form;
     $FETCH res_form;
     if(SQLCODE == SQLNOTFOUND)
     {
          printf("Res_form first fetch failed!!!\n");
          goto errexit;
     }
    
     rgu_put_body_string(1, cm_get_sysd(), 1);
     rgu_put_body_string(1, sTitle,   1);        
     rgu_put_body_string(1, " ",      1);
     rgu_put_body_string(1, dbgn_inf, 1);
     rgu_put_body_string(1, dend_inf, 1);
     rgu_put_body(1);

     while(1)
     {
        strcpy(ngroup, trim(ngroup));
        rgu_put_body_string(data_line, ngroup, 1);

        rfmtlong(renew_cnt, "------&", buf1);
        rgu_put_body_string(data_line, buf1, 1);

        rfmtlong(con_cnt, "------&", buf1);
        rgu_put_body_string(data_line, buf1, 1);

        rfmtdouble(prem, "-----------&", buf1);
        rgu_put_body_string(data_line, buf1);

        rfmtlong(renew_cnt1, "------&", buf1);
        rgu_put_body_string(data_line, trim(buf1), 1);

        rfmtlong(con_cnt1, "------&", buf1);
        rgu_put_body_string(data_line, trim(buf1), 1);

        rfmtdouble(prem1, "-----------&", buf1);
        rgu_put_body_string(data_line, buf1);
        rgu_put_body(data_line);

        max_cnt = max_cnt + 1;
        $FETCH res_form;
        if(SQLCODE == SQLNOTFOUND) break;
     }  /****** End of com_cur cursor while  ******/
     $CLOSE res_form;
     $FREE  res_form;

    printf("Body3 Print Resource End!!!\n");

     return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

long car316_body4()
{
 char  tmp_buf[16];
 int   rc,flag_first;
 $char iquota[7], itop[2], itop_t[2], idealer[4], idealer_t[4], iofficer[11];
 $char iofficer_t[11], ntop[10], ndealer[10], nname[21], nbranch[31];
 $char nbranch_t[31],nname_t[21],ipolicy[21],inext_ply[21],dissue[11];
 $char buf1[17], mcheck[2], iquota_t[7], iquota_n[7], ileader[10];
 $int  renew_cnt, con_cnt, renew_cnt1, con_cnt1, renew_cnt2, con_cnt2;
 $int  myear, id2;
 $long prem, prem1, prem2, qord, qord1;
 $char off13[4];

   $WHENEVER SQLERROR GOTO errexit;

   flag_first=1;
   id2 = 0;

   $DECLARE ori_cur CURSOR FOR
     SELECT a.iquota,a.iofficer,a.ipolicy,a.iquota_t,
            a.iofficer_t,a.inext_ply,a.prem,b.nname,c.nname,
            (year(a.dissue)-1911) || TO_CHAR(a.dissue,'%m') 
       INTO $iquota,$iofficer,$ipolicy,$iquota_t,
            $iofficer_t,$inext_ply,$prem,$nname,$nname_t,
            $dissue
       FROM CAR316_TMP a,officer b,officer c
      WHERE a.iofficer = b.iofficer
        AND a.iofficer_t = c.iofficer
      ORDER BY 1,2,5,6;

   $OPEN ori_cur;

   rgu_put_body_string(1, cm_get_sysd(), 1);   
   rgu_put_body_string(1, "�^�k��", 1);
   rgu_put_body_string(1, sTitle,   1);         
   rgu_put_body_string(1, " ",      1);
   rgu_put_body_string(1, dbgn_inf, 1);
   rgu_put_body_string(1, dend_inf, 1);
   rgu_put_body(1);

   while(1) {
     $FETCH ori_cur;
     if(SQLCODE == SQLNOTFOUND) break;

     $SELECT nbranch INTO $nbranch
        FROM sa_branch_type
       WHERE ibranch = $iquota;
     if (SQLCODE == SQLNOTFOUND) 
        strcpy(nbranch,iquota);
     $SELECT nbranch INTO $nbranch_t
        FROM sa_branch_type
       WHERE ibranch = $iquota_t;
     if (SQLCODE == SQLNOTFOUND) 
        strcpy(nbranch_t," ");

       rgu_put_body_string(data_line, nbranch, 1);
       rgu_put_body_string(data_line, iofficer, 1);
       rgu_put_body_string(data_line, nname, 1);
       rgu_put_body_string(data_line, ipolicy, 1);
       rgu_put_body_string(data_line, nbranch_t, 1);
       rgu_put_body_string(data_line, iofficer_t, 1);
       rgu_put_body_string(data_line, nname_t, 1);
       rgu_put_body_string(data_line, inext_ply, 1);
       rfmtlong(prem, "------------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
       rgu_put_body_string(data_line, dissue, 1);
       rgu_put_body(data_line);
       
       max_cnt = max_cnt + 1;

   } 
   $CLOSE ori_cur;
   $FREE  ori_cur;

   return M_CM_OK;
   
errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
/**********************
long car316_body5()
{
     ���|�ا�k�G
    �z�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�s�w�w�w�w�w�w�w�w�w�w�w�w�w�w�{
    �x        ��            ��        �x       �~  �Z  �k  ��       �x
    �u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�q�w�w�w�w�w�w�w�w�w�w�w�w�w�w�t
    �x����O�B�g�쬰���u��            �x��O�����ɡA�Ӹg���H���ɢx
    �x                                �x�����                      �x
    �u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�q�w�w�w�w�w�w�w�w�w�w�w�w�w�w�t
    �x����O�B�g�줣�����u(���N��)    �x��O��g�줧�̷s�k�ݳ��    �x
    �u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�q�w�w�w�w�w�w�w�w�w�w�w�w�w�w�t
    �x�w��O�B�g�쬰�@���            �x��O���k�ݳ��            �x
    �u�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�q�w�w�w�w�w�w�w�w�w�w�w�w�w�w�t
    �x�w��O�B�g�쬰�O�N��            �x��O���X����ɡA��@���g�x
    �x                                �x����ݳ��                  �x
    �|�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�w�r�w�w�w�w�w�w�w�w�w�w�w�w�w�w�}
   
 char  tmp_buf[16];
 int   rc,flag_first;
 $char iquota[7], itop[2], itop_t[2], idealer[4], idealer_t[4], iofficer[11];
 $char iofficer_t[11], ntop[10], ndealer[10], nname[11], nbranch[31];
 $char nbranch_t[31],nname_t[11],ipolicy[21],inext_ply[21],dissue[11];
 $char buf1[17], mcheck[2], iquota_t[7], iquota_n[7], ileader[10];
 $char iquota_old[7],iofficer_old[11],nbranch_old[31],nname_old[11];
 $int  renew_cnt, con_cnt, renew_cnt1, con_cnt1, renew_cnt2, con_cnt2;
 $int  myear, id2;
 $long prem, prem1, prem2, qord, qord1;
 $char off13[4];
 $char iresource[2],iresource_t[2];
 $char iquota14[8];
 $char DBName2[5], sFullName2[20], stmt[1024];
 $char dply_end[13], dpolicy[13], dply_end_tmp[13], dpolicy_tmp[13];
 $long lDplyend, lDpolicy;

   $WHENEVER SQLERROR GOTO errexit;

printf("Agent part Start!!!\n");

   $DECLARE ori_cur1 CURSOR FOR
     SELECT b.iquota,a.iofficer,a.ipolicy,nvl(c.iquota,' '),
            a.iofficer_t,a.inext_ply,a.prem,b.nname,nvl(c.nname,' '),
            (year(a.dissue)-1911) || TO_CHAR(a.dissue,'%m'),a.iresource,a.iresource_t,a.iofficer_old
       INTO $iquota,$iofficer,$ipolicy,$iquota_t,
            $iofficer_t,$inext_ply,$prem,$nname,$nname_t,
            $dissue,$iresource,$iresource_t,$iofficer_old
       FROM CAR316_TMP1 a,outer officer b,outer officer c
      WHERE a.iofficer = b.iofficer
        AND a.iofficer_t = c.iofficer
      ORDER BY 1,2,5,6;

   $OPEN ori_cur1;

   rgu_put_body_string(1, cm_get_sysd(), 1);
   rgu_put_body_string(1, "�@���", 1);
   rgu_put_body_string(1, dbgn_inf, 1);
   rgu_put_body_string(1, dend_inf, 1);
   rgu_put_body(1);

   while(1) {
     $FETCH ori_cur1;
     if(SQLCODE == SQLNOTFOUND) break;

     if( inext_ply[0] == '\0' || inext_ply[0] == ' ' )
     {

         strcpy(sFullName2, get_car_full_db(ipolicy));

         sprintf(stmt,"SELECT dply_end FROM %s:ply_relation \
                        WHERE ipolicy = '%s'", sFullName2, ipolicy );
         $PREPARE pol_rel2 FROM $stmt;
         $EXECUTE pol_rel2 INTO $lDplyend;

         strcpy( dply_end_tmp , cm_edate_str( lDplyend ));
         dply_end[0] = dply_end_tmp[6];
         dply_end[1] = dply_end_tmp[7];
         dply_end[2] = dply_end_tmp[8];
         dply_end[3] = dply_end_tmp[9];
         dply_end[4] = dply_end_tmp[0];
         dply_end[5] = dply_end_tmp[1];
         dply_end[6] = dply_end_tmp[3];
         dply_end[7] = dply_end_tmp[4];
         dply_end[8] = '\0';

         sprintf(stmt,"SELECT unit_id, move_date FROM personal:v_asexpr \
                        WHERE empl_no = '%s' AND move_date <= '%s' \
                        ORDER BY 2 desc ", iofficer, dply_end );
         $PREPARE p_unit FROM $stmt;
         $DECLARE q_unit CURSOR FOR p_unit;
         $OPEN  q_unit;
         $FETCH q_unit INTO $iquota_old;
         if( SQLCODE == SQLNOTFOUND )
         {
            strcpy(iquota14,substring(iquota,1,4));
            strcat(iquota14,"00");
         }
         else
         {
            strcpy(iquota14,substring(iquota_old,1,4));
            strcat(iquota14,"00");
         }
         $CLOSE q_unit;
         $FREE  q_unit;
         printf("iquota[%s] \n",iquota14 );

         $SELECT nbranch INTO $nbranch_old
            FROM sa_branch_type
           WHERE ibranch = $iquota14;
         if (SQLCODE==SQLNOTFOUND) strcpy(nbranch_old," ");

         $SELECT nname INTO $nname_old
            FROM officer
           WHERE iofficer = $iofficer_old;

     }
     else
     {

            strcpy(sFullName2, get_car_full_db(inext_ply));

            sprintf(stmt,"SELECT dpolicy FROM %s:ply_relation \
                           WHERE ipolicy = '%s'", sFullName2, inext_ply );
            $PREPARE pol_rel3 FROM $stmt;
            $EXECUTE pol_rel3 INTO $lDpolicy;

            strcpy( dpolicy_tmp , cm_edate_str( lDpolicy ));
            dpolicy[0] = dpolicy_tmp[6];
            dpolicy[1] = dpolicy_tmp[7];
            dpolicy[2] = dpolicy_tmp[8];
            dpolicy[3] = dpolicy_tmp[9];
            dpolicy[4] = dpolicy_tmp[0];
            dpolicy[5] = dpolicy_tmp[1];
            dpolicy[6] = dpolicy_tmp[3];
            dpolicy[7] = dpolicy_tmp[4];
            dpolicy[8] = '\0';

            sprintf(stmt,"SELECT unit_id, move_date FROM personal:v_asexpr \
                           WHERE empl_no = '%s' AND move_date <= '%s' \
                           ORDER BY 2 desc ", iofficer_old, dpolicy );
            $PREPARE r_unit FROM $stmt;
            $DECLARE x_unit CURSOR FOR r_unit;
            $OPEN  x_unit;
            $FETCH x_unit INTO $iquota_old;
            if ( SQLCODE == SQLNOTFOUND )
            {

               $SELECT iquota[1,4] || '00'
                  INTO $iquota_old
                  FROM officer
                 WHERE iofficer = $iofficer_old;

            }
            $CLOSE x_unit;
            $FREE  x_unit;

            printf("iquota[%s]\n",iquota_old);
            strcpy(iquota14,substring(iquota_old,1,4));
            strcat(iquota14,"00");

            $SELECT nbranch INTO $nbranch_old
               FROM sa_branch_type
              WHERE ibranch = $iquota14;
            if (SQLCODE==SQLNOTFOUND) strcpy(nbranch_old," ");

            $SELECT nname INTO $nname_old
               FROM officer
              WHERE iofficer = $iofficer_old;


     }

      strcpy(iquota14,substring(iquota,1,4));
      strcat(iquota14,"00"); 

     $SELECT nbranch INTO $nbranch
        FROM sa_branch_type
       WHERE ibranch = $iquota14;

      strcpy(iquota14,substring(iquota_t,1,4));
      strcat(iquota14,"00"); 

     $SELECT nbranch INTO $nbranch_t
        FROM sa_branch_type
       WHERE ibranch = $iquota14;
     if (SQLCODE==SQLNOTFOUND) strcpy(nbranch_t," ");

       rgu_put_body_string(data_line, nbranch, 1);
       rgu_put_body_string(data_line, iofficer, 1);
       rgu_put_body_string(data_line, nname, 1);
       rgu_put_body_string(data_line, ipolicy, 1);
       rgu_put_body_string(data_line, nbranch_t, 1);
       rgu_put_body_string(data_line, iofficer_t, 1);
       rgu_put_body_string(data_line, nname_t, 1);
       rgu_put_body_string(data_line, inext_ply, 1);
       rfmtlong(prem, "------------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
       rgu_put_body_string(data_line, dissue, 1);
       rgu_put_body_string(data_line, trim(nbranch_old), 1);
       rgu_put_body_string(data_line, trim(nname_old), 1);
       rgu_put_body(data_line);
       
       max_cnt = max_cnt + 1;

   } 
   $CLOSE ori_cur1;
   $FREE  ori_cur1;


   return M_CM_OK;
   
errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

************************/
long car316_body5()
{
 char  tmp_buf[16];
 int   rc,flag_first;
 $char iquota[7], itop[2], itop_t[2], idealer[4], idealer_t[4], iofficer[11];
 $char iofficer_t[11], ntop[10], ndealer[10], nname[11], nbranch[31];
 $char nbranch_t[31],nname_t[11],ipolicy[21],inext_ply[21],dissue[11];
 $char buf1[17], mcheck[2], iquota_t[7], iquota_n[7], ileader[11];
 $char iquota_old[7],iofficer_old[11],nbranch_old[31],nname_old[11];
 $char nbranch_1[31],nbranch_t1[31],nbranch_old1[31];
 $int  renew_cnt, con_cnt, renew_cnt1, con_cnt1, renew_cnt2, con_cnt2;
 $int  myear, id2;
 $long prem, prem1, prem2, qord, qord1;
 $char off13[4];
 $char iresource[2],iresource_t[2];
 $char iquota14[8];
 $char iengine[CA_ENGINE_NUM],iengine_t[CA_ENGINE_NUM],nassured[13];
 $char ncode[16],ncode_t[16],iexpire[3];

   $WHENEVER SQLERROR GOTO errexit;

   $DECLARE ori_cur1 CURSOR FOR
     SELECT a.iquota,a.iofficer,a.ipolicy,nvl(a.iquota_t,' '),
            a.iofficer_t,a.inext_ply,a.prem,nvl(b.nname,' '),
            nvl(c.nname,' '),
            (year(a.dissue)-1911) || TO_CHAR(a.dissue,'%m'),a.iresource,a.iresource_t,a.iofficer_old,
            a.iquota_old,a.iengine,a.iengine_t,a.nassured,a.iexpire
       INTO $iquota,$iofficer,$ipolicy,$iquota_t,
            $iofficer_t,$inext_ply,$prem,$nname,$nname_t,
            $dissue,$iresource,$iresource_t,$iofficer_old,
            $iquota_old,$iengine,$iengine_t,$nassured,$iexpire
       FROM CAR316_TMP1 a,outer officer b,outer officer c
      WHERE a.iofficer = b.iofficer
        AND a.iofficer_t = c.iofficer
      ORDER BY 1,2,5,6;

   $OPEN ori_cur1;

   rgu_put_body_string(1, cm_get_sysd(), 1);      
   rgu_put_body_string(1, "�@���", 1);
   rgu_put_body_string(1, sTitle,   1);   
   rgu_put_body_string(1, dbgn_inf, 1);
   rgu_put_body_string(1, dend_inf, 1);
   rgu_put_body(1);

   while(1) {
     $FETCH ori_cur1;
     if(SQLCODE == SQLNOTFOUND) break;
     
     if(strncmp(ipolicy, "87296V9006203",13)==0)
     {
         printf("5-1 ipolicy = %s, iquota_1 = %s, iquota_t = %s, iquota_old = %s \n", ipolicy, iquota, iquota_t, iquota_old);
     }  
     
     $SELECT nname INTO $nname_old
        FROM officer
       WHERE iofficer=$iofficer_old;
     if(SQLCODE==SQLNOTFOUND)
      {strcpy(iquota_old," ");
       strcpy(nname_old," "); }

      strcpy(iquota14,substring(iquota,1,4));
      strcat(iquota14,"00"); 

     $SELECT nbranch INTO $nbranch
        FROM sa_branch_type
       WHERE ibranch = $iquota14;
     if (SQLCODE==SQLNOTFOUND) strcpy(nbranch,iquota14);

      strcpy(iquota14,substring(iquota_t,1,4));
      strcat(iquota14,"00"); 

     $SELECT nbranch INTO $nbranch_t
        FROM sa_branch_type
       WHERE ibranch = $iquota14;
     if (SQLCODE==SQLNOTFOUND) strcpy(nbranch_t," ");

      strcpy(iquota14,substring(iquota_old,1,4));
      strcat(iquota14,"00"); 

     $SELECT nbranch INTO $nbranch_old
        FROM sa_branch_type
       WHERE ibranch = $iquota14;
     if (SQLCODE==SQLNOTFOUND) strcpy(nbranch_old," ");

     $SELECT ncode INTO $ncode
        FROM cu_code_data
       WHERE itype = '10'
         AND icode = $iresource;
     if (SQLCODE==SQLNOTFOUND) strcpy(ncode," ");

     $SELECT ncode INTO $ncode_t
        FROM cu_code_data
       WHERE itype = '10'
         AND icode = $iresource_t;
     if (SQLCODE==SQLNOTFOUND) strcpy(ncode_t," ");

     if(strncmp(ipolicy, "87296V9006203",13)==0)
     {
         printf("5-2 ipolicy = %s, iquota = %s, iquota_t = %s , iquota_old = %s \n", ipolicy, iquota, iquota_t, iquota_old);
     }  

     if (strlen(trim(inext_ply)) == 0)
     {
       strcpy(nbranch_t," ");
       strcpy(iofficer_t," ");
       strcpy(nname_t," ");
       strcpy(iengine_t," ");
       strcpy(ncode_t," ");
       prem = 0;
     }
       rgu_put_body_string(data_line, trim(nbranch), 1);
       rgu_put_body_string(data_line, iofficer, 1);
       rgu_put_body_string(data_line, nname, 1);
       rgu_put_body_string(data_line, ipolicy, 1);
       rgu_put_body_string(data_line, rtrim(nassured), 1);
       rgu_put_body_string(data_line, rtrim(iengine), 1);
       rgu_put_body_string(data_line, ncode ,1 );
       rgu_put_body_string(data_line, trim(nbranch_t), 1);
       rgu_put_body_string(data_line, iofficer_t, 1);
       rgu_put_body_string(data_line, nname_t, 1);
       rgu_put_body_string(data_line, inext_ply, 1);
       rgu_put_body_string(data_line, rtrim(iengine_t), 1);
       rgu_put_body_string(data_line, ncode_t, 1);
       rfmtlong(prem, "------------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
       rgu_put_body_string(data_line, dissue, 1);
       rgu_put_body_string(data_line, trim(nbranch_old), 1);
       rgu_put_body_string(data_line, trim(nname_old), 1);
       rgu_put_body_string(data_line, trim(iexpire), 1);
       rgu_put_body(data_line);
       
       max_cnt = max_cnt + 1;

   } 
   $CLOSE ori_cur1;
   $FREE  ori_cur1;

   return M_CM_OK;
   
errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car316_body6()
{
 char  tmp_buf[16];
 int   rc,flag_first;
 $char iquota[7], itop[2], itop_t[2], iofficer[11];
 $char iofficer_t[11], ntop[10], ndealer[10], nname[11], nbranch[31];
 $char nbranch_t[31],nname_t[11],ipolicy[21],inext_ply[21],dissue[11];
 $char buf1[17], mcheck[2], iquota_t[7], iquota_n[7], ileader[11];
 $char iquota_old[7],iofficer_old[11],nbranch_old[31],nname_old[11];
 $char nbranch_1[31],nbranch_t1[31],nbranch_old1[31];
 $int  renew_cnt, con_cnt, renew_cnt1, con_cnt1, renew_cnt2, con_cnt2;
 $int  myear, id2;
 $long prem, prem1, prem2, qord, qord1;
 $char off13[4];
 $char iresource[2],iresource_t[2];
 $char iquota14[8];
 $char iengine[CA_ENGINE_NUM],iengine_t[CA_ENGINE_NUM],nassured[13];
 $char ncode[16],ncode_t[16];
 $char dply_begin[11],dply_begin_t[11],dpolicy[11],dpolicy_t[11];
 $char ibus[11],idealer[5],ibigcomp[2];
 $char ibus_t[11],idealer_t[5],ibigcomp_t[5];
 $char ibig_sales[11],ibig_sales_t[11],ibig_name[11],ibig_name_t[11];
 $char ncomp[21],ncomp_t[21],nzoon[21],nzoon_t[21];
 $char iassured_old[11],iassured_t[11],itag_t[CA_TAG_NUM],nassured_t[13];

   $WHENEVER SQLERROR GOTO errexit;

   $DECLARE ori_curX CURSOR FOR
     SELECT a.iquota,a.iofficer,a.ipolicy,nvl(a.iquota_t,' '),
            a.iofficer_t,a.inext_ply,a.prem,b.nname,nvl(c.nname,' '),
            (year(a.dissue)-1911) || TO_CHAR(a.dissue,'%m'),a.iresource,a.iresource_t,a.iofficer_old,
            a.iquota_old,a.iengine,a.iengine_t,a.nassured,
            a.dply_begin,a.dpolicy,a.ibig_sales,
            a.dply_begin_t,a.dpolicy_t,a.ibig_sales_t,a.itag_old,
            a.itag_t,a.nassured_t,a.iassured_old,a.iassured_t
       INTO $iquota,$iofficer,$ipolicy,$iquota_t,
            $iofficer_t,$inext_ply,$prem,$nname,$nname_t,
            $dissue,$iresource,$iresource_t,$iofficer_old,
            $iquota_old,$iengine,$iengine_t,$nassured,
            $dply_begin,$dpolicy,$ibig_sales,
            $dply_begin_t,$dpolicy_t,$ibig_sales_t,$itag_old,
            $itag_t,$nassured_t,$iassured_old,$iassured_t
       FROM CAR316_TMP2 a,outer officer b,outer officer c
      WHERE a.iofficer = b.iofficer
        AND a.iofficer_t = c.iofficer
      ORDER BY 1,2,5,6;

   $OPEN ori_curX;

   rgu_put_body_string(1, cm_get_sysd(), 1);   
   rgu_put_body_string(1, "�O�N��", 1);
   rgu_put_body_string(1, sTitle,   1);         
   rgu_put_body_string(1, dbgn_inf, 1);
   rgu_put_body_string(1, dend_inf, 1);
   rgu_put_body(1);

   while(1) {
     $FETCH ori_curX;
     if(SQLCODE == SQLNOTFOUND) break;
     $SELECT nname INTO $nname_old
        FROM officer
       WHERE iofficer=$iofficer_old;
     if(SQLCODE==SQLNOTFOUND)
      {strcpy(iquota_old," ");
       strcpy(nname_old," "); }

      strcpy(iquota14,substring(iquota,1,4));
      strcat(iquota14,"00");

     $SELECT nbranch INTO $nbranch
        FROM sa_branch_type
       WHERE ibranch = $iquota14;
     if (SQLCODE==SQLNOTFOUND) strcpy(nbranch," ");

      strcpy(iquota14,substring(iquota_t,1,4));
      strcat(iquota14,"00");

     $SELECT nbranch INTO $nbranch_t
        FROM sa_branch_type
       WHERE ibranch = $iquota14;
     if (SQLCODE==SQLNOTFOUND) strcpy(nbranch_t," ");

      strcpy(iquota14,substring(iquota_old,1,4));
      strcat(iquota14,"00");

     $SELECT nbranch INTO $nbranch_old
        FROM sa_branch_type
       WHERE ibranch = $iquota14;
     if (SQLCODE==SQLNOTFOUND) strcpy(nbranch_old," ");

     $SELECT ncode INTO $ncode
        FROM cu_code_data
       WHERE itype = '10'
         AND icode = $iresource;
     if (SQLCODE==SQLNOTFOUND) strcpy(ncode," ");

     $SELECT ncode INTO $ncode_t
        FROM cu_code_data
       WHERE itype = '10'
         AND icode = $iresource_t;
     if (SQLCODE==SQLNOTFOUND) strcpy(ncode_t," ");

     $SELECT nname INTO $ibig_name
        FROM ca_big_office
       WHERE fclass = '2'
         AND ibig_comp = $ibig_sales;
     if (SQLCODE==SQLNOTFOUND) strcpy(ibig_name," ");

     $SELECT nname INTO $ibig_name_t
        FROM ca_big_office
       WHERE fclass = '2'
         AND ibig_comp = $ibig_sales_t;
     if (SQLCODE==SQLNOTFOUND) strcpy(ibig_name_t," ");

     $SELECT nlevel3,nlevel4
        INTO $ncomp,$nzoon
        FROM v_channel
       WHERE icode = $iofficer;
     if (SQLCODE==SQLNOTFOUND) {
        strcpy(ncomp," ");
        strcpy(nzoon," ");
     }

     $SELECT nlevel3,nlevel4
        INTO $ncomp_t,$nzoon_t
        FROM v_channel
       WHERE icode = $iofficer_t;
     if (SQLCODE==SQLNOTFOUND) {
        strcpy(ncomp_t," ");
        strcpy(nzoon_t," ");
     }
     /************  ��Ūv_channel 94.12.20 by Jessie
     if( iofficer[0] == 'W' )
       {
         $SELECT ibus_location,idealer INTO $ibus ,$idealer
            FROM officer
           WHERE iofficer = $iofficer;
         if (SQLCODE==SQLNOTFOUND)
           { strcpy(ibus," ");
             strcpy(idealer," ");
           }
         $SELECT ngroup INTO $ncomp
            FROM sa_frm_module
           WHERE ifrm_module = '02'
             AND igroup = $ibus;
         if (SQLCODE== SQLNOTFOUND) strcpy(ncomp," ");

         $SELECT ngroup INTO $nzoon
            FROM sa_frm_module
           WHERE ifrm_module = '02'
             AND igroup = $idealer;
         if (SQLCODE== SQLNOTFOUND) strcpy(nzoon," ");

       }
     else
       {
          $SELECT ibigcomp,idealer INTO $ibigcomp ,$idealer
             FROM officer
            WHERE iofficer = $iofficer;
          if (SQLCODE==SQLNOTFOUND)
            { strcpy(ibigcomp," ");
              strcpy(idealer," ");
            }
          $SELECT ngroup INTO $ncomp
             FROM sa_frm_module
            WHERE ifrm_module = '02'
              AND igroup = $ibigcomp;
          if (SQLCODE== SQLNOTFOUND) strcpy(ncomp," ");

          if(strncmp(idealer,"F99",3)==0 || strncmp(idealer,"E02",3)==0)
           {
             $SELECT ngroup INTO $nzoon
                FROM sa_frm_module
               WHERE ifrm_module = '02'
                 AND igroup = 'X';
             if (SQLCODE== SQLNOTFOUND) strcpy(nzoon," ");
           }
          else
           {
               $SELECT ngroup INTO $nzoon
                 FROM sa_frm_module
                WHERE ifrm_module  = '02'
                  AND igroup = $idealer;
              if (SQLCODE== SQLNOTFOUND) strcpy(nzoon," ");
           }
       }

     if( iofficer_t[0] == 'W' )
       {
         $SELECT ibus_location,idealer INTO $ibus_t ,$idealer_t
            FROM officer
           WHERE iofficer = $iofficer_t;
         if (SQLCODE==SQLNOTFOUND)
           { strcpy(ibus_t," ");
             strcpy(idealer_t," ");
           }
         $SELECT ngroup INTO $ncomp_t
            FROM sa_frm_module
           WHERE ifrm_module = '02'
             AND igroup = $ibus_t;
         if (SQLCODE== SQLNOTFOUND) strcpy(ncomp_t," ");

         $SELECT ngroup INTO $nzoon_t
            FROM sa_frm_module
           WHERE ifrm_module = '02'
             AND igroup = $idealer_t;
         if (SQLCODE== SQLNOTFOUND) strcpy(nzoon_t," ");

       }
     else
       {
          $SELECT ibigcomp,idealer INTO $ibigcomp_t ,$idealer_t
             FROM officer
            WHERE iofficer = $iofficer_t;
          if (SQLCODE==SQLNOTFOUND)
            { strcpy(ibigcomp_t," ");
              strcpy(idealer_t," ");
            }
          $SELECT ngroup INTO $ncomp_t
             FROM sa_frm_module
            WHERE ifrm_module = '02'
              AND igroup = $ibigcomp_t;
          if (SQLCODE== SQLNOTFOUND) strcpy(ncomp_t," ");

          if(strncmp(idealer_t,"F99",3)==0 || strncmp(idealer_t,"E02",3)==0)
           {
             $SELECT ngroup INTO $nzoon_t
                FROM sa_frm_module
               WHERE ifrm_module  = '02'
                 AND igroup = 'X';
             if (SQLCODE== SQLNOTFOUND) strcpy(nzoon_t," ");
           }
          else
           {
               $SELECT ngroup INTO $nzoon_t
                 FROM sa_frm_module
                WHERE ifrm_module  = '02'
                  AND igroup = $idealer_t;
              if (SQLCODE== SQLNOTFOUND) strcpy(nzoon_t," ");
           }
       }
     **************/

     if (strlen(trim(inext_ply)) == 0)
     {
       strcpy(nbranch_t," ");
       strcpy(iofficer_t," ");
       strcpy(nname_t," ");
       strcpy(iengine_t," ");
       strcpy(ncode_t," ");
       strcpy(ibig_sales_t," ");
       strcpy(dpolicy_t," ");
       strcpy(ibig_name_t," ");
       strcpy(dply_begin_t," ");
       strcpy(ncomp_t," ");
       strcpy(nzoon_t," ");
       prem = 0;
     }
       rgu_put_body_string(data_line, trim(nbranch), 1);
       rgu_put_body_string(data_line, trim(ncomp), 1);
       rgu_put_body_string(data_line, trim(nzoon), 1);
       rgu_put_body_string(data_line, iofficer, 1);
       rgu_put_body_string(data_line, nname, 1);
       rgu_put_body_string(data_line, ibig_sales, 1);
       rgu_put_body_string(data_line, ibig_name, 1);
       rgu_put_body_string(data_line, dpolicy, 1);
       rgu_put_body_string(data_line, dply_begin, 1);
       rgu_put_body_string(data_line, ipolicy, 1);
       rgu_put_body_string(data_line, rtrim(nassured), 1);
       rgu_put_body_string(data_line, rtrim(iengine), 1);
       rgu_put_body_string(data_line, ncode ,1 );
       rgu_put_body_string(data_line, trim(nbranch_t), 1);
       rgu_put_body_string(data_line, trim(ncomp_t), 1);
       rgu_put_body_string(data_line, trim(nzoon_t), 1);
       rgu_put_body_string(data_line, iofficer_t, 1);
       rgu_put_body_string(data_line, nname_t, 1);
       rgu_put_body_string(data_line, ibig_sales_t, 1);
       rgu_put_body_string(data_line, ibig_name_t, 1);
       rgu_put_body_string(data_line, dpolicy_t, 1);
       rgu_put_body_string(data_line, dply_begin_t, 1);
       rgu_put_body_string(data_line, inext_ply, 1);
       rgu_put_body_string(data_line, rtrim(iengine_t), 1);
       rgu_put_body_string(data_line, ncode_t, 1);
       rfmtlong(prem, "------------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
       rgu_put_body_string(data_line, dissue, 1);
       rgu_put_body_string(data_line, trim(nbranch_old), 1);
       rgu_put_body_string(data_line, trim(nname_old), 1);
       rgu_put_body_string(data_line, trim(itag_old) , 1);
       rgu_put_body_string(data_line, trim(itag_t) , 1);
       rgu_put_body_string(data_line, trim(nassured_t) , 1);
       rgu_put_body_string(data_line, trim(iassured_old) , 1);
       rgu_put_body_string(data_line, trim(iassured_t) , 1);
       
       rgu_put_body(data_line);

       max_cnt = max_cnt + 1;

   }
   $CLOSE ori_curX;
   $FREE  ori_curX;

   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car316_body7()
{
 char  tmp_buf[16];
 int   rc,flag_first;
 $char iquota[7], itop[2], itop_t[2], iofficer[11];
 $char iofficer_t[11], ntop[10], ndealer[10], nname[11], nbranch[31];
 $char nbranch_t[31],nname_t[11],ipolicy[21],inext_ply[21],dissue[11];
 $char buf1[17], mcheck[2], iquota_t[7], iquota_n[7], ileader[11];
 $char iquota_old[7],iofficer_old[11],nbranch_old[31],nname_old[11];
 $char nbranch_1[31],nbranch_t1[31],nbranch_old1[31];
 $int  renew_cnt, con_cnt, renew_cnt1, con_cnt1, renew_cnt2, con_cnt2;
 $int  myear, id2;
 $long prem, prem1, prem2, qord, qord1;
 $char off13[4];
 $char iresource[2],iresource_t[2];
 $char iquota14[8];
 $char iengine[CA_ENGINE_NUM],iengine_t[CA_ENGINE_NUM],nassured[13];
 $char ncode[16],ncode_t[16];
 $char dply_begin[11],dply_begin_t[11],dpolicy[11],dpolicy_t[11];
 $char ibus[11],idealer[5],ibigcomp[2];
 $char ibus_t[11],idealer_t[5],ibigcomp_t[5];
 $char ibig_sales[11],ibig_sales_t[11],ibig_name[11],ibig_name_t[11];
 $char ncomp[21],ncomp_t[21],nzoon[21],nzoon_t[21];

$WHENEVER SQLERROR GOTO errexit;

   $DECLARE ori_curX1 CURSOR FOR
     SELECT a.iquota,a.iofficer,a.ipolicy,nvl(a.iquota_t,' '),
            a.iofficer_t,a.inext_ply,a.prem,b.nname,nvl(c.nname,' '),
            (year(a.dissue)-1911) || TO_CHAR(a.dissue,'%m'),a.iresource,a.iresource_t,a.iofficer_old,
            a.iquota_old,a.iengine,a.iengine_t,a.nassured,
            a.dply_begin,a.dpolicy,a.ibig_sales,
            a.dply_begin_t,a.dpolicy_t,a.ibig_sales_t,a.itag_old
       INTO $iquota,$iofficer,$ipolicy,$iquota_t,
            $iofficer_t,$inext_ply,$prem,$nname,$nname_t,
            $dissue,$iresource,$iresource_t,$iofficer_old,
            $iquota_old,$iengine,$iengine_t,$nassured,
            $dply_begin,$dpolicy,$ibig_sales,
            $dply_begin_t,$dpolicy_t,$ibig_sales_t,$itag_old
       FROM CAR316_TMP3 a,outer officer b,outer officer c
      WHERE a.iofficer = b.iofficer
        AND a.iofficer_t = c.iofficer
      ORDER BY 1,2,5,6;

   $OPEN ori_curX1;

   rgu_put_body_string(1, cm_get_sysd(), 1);     
   rgu_put_body_string(1, "�O�N��", 1);
   rgu_put_body_string(1, sTitle,   1);    
   rgu_put_body_string(1, dbgn_inf, 1);
   rgu_put_body_string(1, dend_inf, 1);
   rgu_put_body(1);

   while(1) {
     $FETCH ori_curX1;
     if(SQLCODE == SQLNOTFOUND) break;
     $SELECT nname INTO $nname_old
        FROM officer
       WHERE iofficer=$iofficer_old;
     if(SQLCODE==SQLNOTFOUND)
      {strcpy(iquota_old," ");
       strcpy(nname_old," "); }

      strcpy(iquota14,substring(iquota,1,4));
      strcat(iquota14,"00");

     $SELECT nbranch INTO $nbranch
        FROM sa_branch_type
       WHERE ibranch = $iquota14;
     if (SQLCODE==SQLNOTFOUND) strcpy(nbranch," ");

      strcpy(iquota14,substring(iquota_t,1,4));
      strcat(iquota14,"00");

     $SELECT nbranch INTO $nbranch_t
        FROM sa_branch_type
       WHERE ibranch = $iquota14;
     if (SQLCODE==SQLNOTFOUND) strcpy(nbranch_t," ");

      strcpy(iquota14,substring(iquota_old,1,4));
      strcat(iquota14,"00");

     $SELECT nbranch INTO $nbranch_old
        FROM sa_branch_type
       WHERE ibranch = $iquota14;
     if (SQLCODE==SQLNOTFOUND) strcpy(nbranch_old," ");

     $SELECT ncode INTO $ncode
        FROM cu_code_data
       WHERE itype = '10'
         AND icode = $iresource;
     if (SQLCODE==SQLNOTFOUND) strcpy(ncode," ");

     $SELECT ncode INTO $ncode_t
        FROM cu_code_data
       WHERE itype = '10'
         AND icode = $iresource_t;
     if (SQLCODE==SQLNOTFOUND) strcpy(ncode_t," ");

     $SELECT nname INTO $ibig_name
        FROM ca_big_office
       WHERE fclass = '2'
         AND ibig_comp = $ibig_sales;
     if (SQLCODE==SQLNOTFOUND) strcpy(ibig_name," ");

     $SELECT nname INTO $ibig_name_t
        FROM ca_big_office
       WHERE fclass = '2'
         AND ibig_comp = $ibig_sales_t;
     if (SQLCODE==SQLNOTFOUND) strcpy(ibig_name_t," ");

     $SELECT nlevel3,nlevel4
        INTO $ncomp,$nzoon
        FROM v_channel
       WHERE icode = $iofficer;
     if (SQLCODE==SQLNOTFOUND) {
        strcpy(ncomp," ");
        strcpy(nzoon," ");
     }

     $SELECT nlevel3,nlevel4
        INTO $ncomp_t,$nzoon_t
        FROM v_channel
       WHERE icode = $iofficer_t;
     if (SQLCODE==SQLNOTFOUND) {
        strcpy(ncomp_t," ");
        strcpy(nzoon_t," ");
     }
     /*************94.12.20
     if( iofficer[0] == 'W' )
       {
         $SELECT ibus_location,idealer INTO $ibus ,$idealer
            FROM officer
           WHERE iofficer = $iofficer;
         if (SQLCODE==SQLNOTFOUND)
           { strcpy(ibus," ");
             strcpy(idealer," ");
           }
         $SELECT ngroup INTO $ncomp
            FROM sa_frm_module
           WHERE ifrm_module = '02'
             AND igroup = $ibus;
         if (SQLCODE== SQLNOTFOUND) strcpy(ncomp," ");

         $SELECT ngroup INTO $nzoon
            FROM sa_frm_module
           WHERE ifrm_module = '02'
             AND igroup = $idealer;
         if (SQLCODE== SQLNOTFOUND) strcpy(nzoon," ");

       }
     else
       {
          $SELECT ibigcomp,idealer INTO $ibigcomp ,$idealer
             FROM officer
            WHERE iofficer = $iofficer;
          if (SQLCODE==SQLNOTFOUND)
            { strcpy(ibigcomp," ");
              strcpy(idealer," ");
            }
          $SELECT ngroup INTO $ncomp
             FROM sa_frm_module
            WHERE ifrm_module = '02'
              AND igroup = $ibigcomp;
          if (SQLCODE== SQLNOTFOUND) strcpy(ncomp," ");

          if(strncmp(idealer,"F99",3)==0 || strncmp(idealer,"E02",3)==0)
           {
             $SELECT ngroup INTO $nzoon
                FROM sa_frm_module
               WHERE ifrm_module = '02'
                 AND igroup = 'X';
             if (SQLCODE== SQLNOTFOUND) strcpy(nzoon," ");
           }
          else
           {
               $SELECT ngroup INTO $nzoon
                 FROM sa_frm_module
                WHERE ifrm_module  = '02'
                  AND igroup = $idealer;
              if (SQLCODE== SQLNOTFOUND) strcpy(nzoon," ");
           }
       }

     if( iofficer_t[0] == 'W' )
       {
         $SELECT ibus_location,idealer INTO $ibus_t ,$idealer_t
            FROM officer
           WHERE iofficer = $iofficer_t;
         if (SQLCODE==SQLNOTFOUND)
           { strcpy(ibus_t," ");
             strcpy(idealer_t," ");
           }
         $SELECT ngroup INTO $ncomp_t
            FROM sa_frm_module
           WHERE ifrm_module = '02'
             AND igroup = $ibus_t;
         if (SQLCODE== SQLNOTFOUND) strcpy(ncomp_t," ");

         $SELECT ngroup INTO $nzoon_t
            FROM sa_frm_module
           WHERE ifrm_module = '02'
             AND igroup = $idealer_t;
         if (SQLCODE== SQLNOTFOUND) strcpy(nzoon_t," ");

       }
     else
       {
          $SELECT ibigcomp,idealer INTO $ibigcomp_t ,$idealer_t
             FROM officer
            WHERE iofficer = $iofficer_t;
          if (SQLCODE==SQLNOTFOUND)
            { strcpy(ibigcomp_t," ");
              strcpy(idealer_t," ");
            }
          $SELECT ngroup INTO $ncomp_t
             FROM sa_frm_module
            WHERE ifrm_module = '02'
              AND igroup = $ibigcomp_t;
          if (SQLCODE== SQLNOTFOUND) strcpy(ncomp_t," ");

          if(strncmp(idealer_t,"F99",3)==0 || strncmp(idealer_t,"E02",3)==0)
           {
             $SELECT ngroup INTO $nzoon_t
                FROM sa_frm_module
               WHERE ifrm_module  = '02'
                 AND igroup = 'X';
             if (SQLCODE== SQLNOTFOUND) strcpy(nzoon_t," ");
           }
          else
           {
               $SELECT ngroup INTO $nzoon_t
                 FROM sa_frm_module
                WHERE ifrm_module  = '02'
                  AND igroup = $idealer_t;
              if (SQLCODE== SQLNOTFOUND) strcpy(nzoon_t," ");
           }
       }
     ****************/

     if (strlen(trim(inext_ply)) == 0)
     {
       strcpy(nbranch_t," ");
       strcpy(iofficer_t," ");
       strcpy(nname_t," ");
       strcpy(iengine_t," ");
       strcpy(ncode_t," ");
       strcpy(ibig_sales_t," ");
       strcpy(dpolicy_t," ");
       strcpy(ibig_name_t," ");
       strcpy(dply_begin_t," ");
       strcpy(ncomp_t," ");
       strcpy(nzoon_t," ");
       prem = 0;
     }
       rgu_put_body_string(data_line, trim(nbranch), 1);
       rgu_put_body_string(data_line, trim(ncomp), 1);
       rgu_put_body_string(data_line, trim(nzoon), 1);
       rgu_put_body_string(data_line, iofficer, 1);
       rgu_put_body_string(data_line, nname, 1);
       rgu_put_body_string(data_line, ibig_sales, 1);
       rgu_put_body_string(data_line, ibig_name, 1);
       rgu_put_body_string(data_line, dpolicy, 1);
       rgu_put_body_string(data_line, dply_begin, 1);
       rgu_put_body_string(data_line, ipolicy, 1);
       rgu_put_body_string(data_line, rtrim(nassured), 1);
       rgu_put_body_string(data_line, rtrim(iengine), 1);
       rgu_put_body_string(data_line, ncode ,1 );
       rgu_put_body_string(data_line, trim(nbranch_t), 1);
       rgu_put_body_string(data_line, trim(ncomp_t), 1);
       rgu_put_body_string(data_line, trim(nzoon_t), 1);
       rgu_put_body_string(data_line, iofficer_t, 1);
       rgu_put_body_string(data_line, nname_t, 1);
       rgu_put_body_string(data_line, ibig_sales_t, 1);
       rgu_put_body_string(data_line, ibig_name_t, 1);
       rgu_put_body_string(data_line, dpolicy_t, 1);
       rgu_put_body_string(data_line, dply_begin_t, 1);
       rgu_put_body_string(data_line, inext_ply, 1);
       rgu_put_body_string(data_line, rtrim(iengine_t), 1);
       rgu_put_body_string(data_line, ncode_t, 1);
       rfmtlong(prem, "------------&", buf1);
       rgu_put_body_string(data_line, buf1, 1);
       rgu_put_body_string(data_line, dissue, 1);
       rgu_put_body_string(data_line, trim(nbranch_old), 1);
       rgu_put_body_string(data_line, trim(nname_old), 1);
       rgu_put_body_string(data_line, trim(itag_old), 1);
       rgu_put_body(data_line);

       max_cnt = max_cnt + 1;

   }
   $CLOSE ori_curX1;
   $FREE  ori_curX1;

   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

long car316_body8()
{
     $char  iquota[7], iquota_t[7], iquota_n[7], ngroup[21];
     $char  buf1[21], mcheck[2], ipolicy[21], igroup[6], igroup_t[6];
     $char  group1[20], group2[20];
     $char  ncode1[20], ncode2[20];
     $char  ibranch[6],nbranch[26];
     $char  ibranch_p[6],igroup_p[6];
     $char  iofficer[11],iofficer_t[11],iof_name[11];
     $int   renew_cnt, con_cnt, renew_cnt1, con_cnt1, renew_cnt2, con_cnt2;
     $int   myear, qorder;
     $long  prem, prem1, prem2;
     $char  iresource_tmp[2];
     $char  DBName2[5], sFullName2[20];
     $char  stmt[1024];
     $char  inext_ply[21], dply_end[13], unit_in[6], dply_end_tmp[13];
     $long  lDplyend;
       int  ctotal=0;

     $CREATE TEMP TABLE NON_AGENT1
        (qorder        integer,
         igroup        char(6),
         ibranch       char(6),
         group1        char(20),
         group2        char(20),
         nbranch       char(25),
         ngroup        char(20),
         iofficer      char(10),
         renew_cnt     integer default 0 not null,
         con_cnt       integer default 0 not null,
         prem          decimal(10,0) default 0 not null,
         renew_cnt1    integer default 0 not null,
         con_cnt1      integer default 0 not null,
         prem1         decimal(10,0) default 0 not null,
         renew_cnt2    integer default 0 not null,
         con_cnt2      integer default 0 not null,
         prem2         decimal(10,0) default 0 not null
        )WITH NO LOG;
     
     $DECLARE non_agent1 CURSOR FOR
       SELECT ipolicy, a.iofficer, a.iquota, iresource, inext_ply, con_cnt, prem
         INTO $ipolicy, $iofficer, $iquota, $iresource_tmp, $inext_ply,
              $con_cnt, $prem
         FROM CAR316 a,officer b
        WHERE a.iofficer = b.iofficer AND b.imgr = '2'
          AND iexpire = ''
        ORDER BY 3,2;

     $OPEN non_agent1;
     while(1)
     {
       $FETCH non_agent1;
       if(SQLCODE == SQLNOTFOUND) break;

       $SELECT a.ngroup,a.igroup,b.group1,b.group2,b.ibranch,b.nbranch,a.qorder
         INTO $ngroup,$igroup,$group1,$group2,$ibranch,$nbranch,$qorder
         FROM sa_frm_module a, sa_branch_type b
        WHERE a.ifrm_module = '01'
          AND b.ibranch = $iquota
          AND a.igroup = b.igroup
          AND a.igroup not in ('YYY','ZZZ','XXX');
           
       $select ncode
       into $ncode1
       from cu_code_data
       where itype='18'
        AND   icode=$group1;
       
       $select ncode
       into $ncode2
       from cu_code_data
       where itype='19'
       and   icode=$group2;
       
       if (iresource_tmp[0] == '8')
       {
       
         $INSERT INTO NON_AGENT1
            (qorder,igroup,ibranch,group1,group2,nbranch,ngroup,iofficer,renew_cnt,con_cnt,prem,renew_cnt1,con_cnt1,prem1,renew_cnt2,con_cnt2,prem2)
          VALUES
            ($qorder,$igroup,$ibranch,$ncode1,$ncode2,$nbranch,$ngroup,$iofficer,1,$con_cnt,$prem,0,0,0,0,0,0);

       }
       else if(iresource_tmp[0] == '4' || iresource_tmp[0] == '6' || iresource_tmp[0] == 'G' ||
               iresource_tmp[0] == '5' || iresource_tmp[0] == '3' || iresource_tmp[0] == '9' )
       {
        
         $INSERT INTO NON_AGENT1
            (qorder,igroup,ibranch,group1,group2,nbranch,ngroup,iofficer,renew_cnt,con_cnt,prem,renew_cnt1,con_cnt1,prem1,renew_cnt2,con_cnt2,prem2)
          VALUES
            ($qorder,$igroup, $ibranch,$ncode1,$ncode2, $nbranch, $ngroup, $iofficer,0, 0, 0, 1, $con_cnt, $prem, 0, 0, 0);

       }
       else
       {
       
        $INSERT INTO NON_AGENT1
           (qorder,igroup,ibranch,group1,group2,nbranch,ngroup,iofficer,renew_cnt,con_cnt,prem,renew_cnt1,con_cnt1,prem1,renew_cnt2,con_cnt2,prem2)
         VALUES
           ($qorder,$igroup, $ibranch,$ncode1,$ncode2, $nbranch, $ngroup, $iofficer, 0, 0, 0, 0, 0, 0, 1, $con_cnt, $prem);

      }
       ctotal++;
     }  /******  End of non_agent cursor while  *****/

     $CLOSE non_agent1;
     $FREE  non_agent1;

     $DECLARE com_cur1 CURSOR FOR
       SELECT qorder,ngroup,igroup,group1,group2,nbranch,ibranch,iofficer, sum(renew_cnt), sum(con_cnt), sum(prem),
              sum(renew_cnt1), sum(con_cnt1), sum(prem1), sum(renew_cnt2), sum(con_cnt2), sum(prem2)
         INTO $qorder,$ngroup,$igroup,$group1,$group2,$nbranch,$ibranch,$iofficer, $renew_cnt, $con_cnt, $prem,
              $renew_cnt1, $con_cnt1, $prem1, $renew_cnt2, $con_cnt2, $prem2
         FROM NON_AGENT1
        GROUP BY 1,2,3,4,5,6,7,8
        ORDER BY 1,7,8;
     $OPEN com_cur1;
     $FETCH com_cur1;
     if(SQLCODE == SQLNOTFOUND)
     {
       goto errexit;
     }

     rgu_put_body_string(1, cm_get_sysd(), 1);
     rgu_put_body_string(1, sTitle,   1);        
     rgu_put_body_string(1, " ",      1);
     rgu_put_body_string(1, dbgn_inf, 1);
     rgu_put_body_string(1, dend_inf, 1);
     rgu_put_body(1);

     while(1)
     {
            $SELECT nname INTO $iof_name
               FROM officer
              WHERE iofficer = $iofficer;
            if(SQLCODE == SQLNOTFOUND) 
            {
               strcpy(iof_name," ");
            }
            strcpy(group1, trim(group1));         
            rgu_put_body_string(data_line, group1, 1);
            strcpy(group2, trim(group2));
            rgu_put_body_string(data_line, group2, 1);
            strcpy(ngroup, trim(ngroup));       
            rgu_put_body_string(data_line, ngroup, 1);
            rgu_put_body_string(data_line, nbranch, 1);
            rgu_put_body_string(data_line, iof_name, 1);
            rfmtlong(renew_cnt, "------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
            rfmtlong(con_cnt,   "------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
            rfmtlong(prem, "-----------&", buf1);
            rgu_put_body_string(data_line, buf1);
            rfmtlong(renew_cnt1, "------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
            rfmtlong(con_cnt1,   "------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
            rfmtlong(prem1, "-----------&", buf1);
            rgu_put_body_string(data_line, buf1);
            rfmtlong(renew_cnt2, "------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
            rfmtlong(con_cnt2,   "------&", buf1);
            rgu_put_body_string(data_line, buf1, 1);
            rfmtlong(prem2, "-----------&", buf1);
            rgu_put_body_string(data_line, buf1);
            rgu_put_body(data_line);
            max_cnt = max_cnt + 1;
            
            $FETCH com_cur1;
            if(SQLCODE == SQLNOTFOUND) break;
     }  /****** End of com_cur cursor while  ******/
     $CLOSE com_cur1;
     $FREE  com_cur1;

    printf("non_agent End!!!\n");

     return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*---------------------------------------------------------------------------*/
char *getdate(sDate)
char sDate[11];
{
char dply_end[9];

     dply_end[0] = sDate[6];
     dply_end[1] = sDate[7];
     dply_end[2] = sDate[8];
     dply_end[3] = sDate[9];
     dply_end[4] = sDate[0];
     dply_end[5] = sDate[1];
     dply_end[6] = sDate[3];
     dply_end[7] = sDate[4];
     dply_end[8] = '\0';

     return dply_end;   
}

char *setdate(sDate)
char sDate[11];
{
char duty_date[11];

     duty_date[0] = sDate[4];
     duty_date[1] = sDate[5];
     duty_date[2] = '/';
     duty_date[3] = sDate[6];
     duty_date[4] = sDate[7];
     duty_date[5] = '/';
     duty_date[6] = sDate[0];
     duty_date[7] = sDate[1];
     duty_date[8] = sDate[2];
     duty_date[9] = sDate[3];
     duty_date[10] = '\0';


     return duty_date;
}
/*******
*�N���k�ݳ���

����O�G
   *�O�N->����O           *�O�N  �G���«O�N���g�������s�@��ɤ��̷s�~�Z���
                            ����O�G�L

   *�@��]���u�^->����O   *�@��  �G���¤@�뤧�g����¤@�뤧�O������ɦb�H����
				    ���~�Z���
                            ����O�G�L

   *�@��]���N���^->����O *�@��  �G���¤@�뤧�g�������s�@��ɤ��̷s�~�Z���
                            ����O�G�L                              

��O�N�G
    �O�N->*�O�N            *�O�N  �G�̷s�O�N����l�O���ɤ��~�Z���
                            �O�N  �G���«O�N���g�������s�@��ɤ��̷s�~�Z���
                              
   *�O�N->�@��             *�O�N  �G���«O�N���g�������s�@��ɤ��̷s�~�Z���
                            �@��  �G�̷s�@����l�O���ɤ��~�Z���

�s�@��G
   *�@��]���u�^->�O�N     *�@��  �G���¤@�뤧�g���s�O�N��ñ���ɦb�H���ɤ��~
				    �Z���
                            �O�N  �G�̷s�O�N����l�O���ɤ��~�Z���
                            
   *�@��]���N���^->�O�N   *�@��  �G���¤@�뤧�g�������s�@��ɤ��̷s�~�Z���
                            �O�N  �G�̷s�O�N����l�O���ɤ��~�Z���
                            
    �@��(���u)->*�@��      *�@��  �G�̷s�@�뤧��l�O���ɤ��~�Z���
                            �@��  �G���¤@�뤧�g����¤@�뤧�����ɦb�H���ɤ��~
				    �Z���
         
    �@��(���N��)->*�@��    *�@��  �G�̷s�@�뤧��l�O���ɤ��~�Z���
                           �@��   �G���¤@�뤧�g�������s�@��ɤ��̷s�~�Z���                    
*******/

/*------------------------------------------------------end of program*/
