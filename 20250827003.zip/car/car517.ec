/************************************************/
/*   �l�v��d�ߦC�L                             */
/*   PROGRAM : car517.ec by forest              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#define SCOTT

char *get_car_full_db();
extern char  RPTDIR[];

/****** Global variables ******/

$char  DBName[5], DBName2[5], sFullName[80], sOption[2];
char   BodyFile[21];
char   TitleFile[21];
$char  outputf[21];
$int   max_count ,Width;
$char  FormTp[3];
$int   TotColumn;
$int   StartRow,TitleRow;
$int   PgLine , ItemRow;
static int errCode;
$int   tmp_len;
$char  GHsDsal[11];

$char  sStmt[2048];
$char  sStmt1[2048];
$char  stmt[2048];
$int   iSd, iEd, iSd2;
$int   iSdm, iEdm, iSd2m;
$int   fStat;
char   date_flag[2];

$char  frecov[2];
$char  GsFrecov_GsFsal[2];
char   GsFrecover_GsFsale[2];
$char  GsFreprocess[2];
$char  GsFrecovman[2];
$char  ibranch_flag[2];
$char  ibranch[3],iupbranch[3],ibranch_in[3];
$char  fcard_class[2];
$char  datebgn[11],dateend[11],datebgn_edate[11],dateend_edate[11];
$char  dclaimbgn[11],dclaimend[11],dclaim_ebgn[11],dclaim_eend[11];
char   userid[11];
char   GsOption[2];

/**** output to reportfile ****/

$char  Iclaim[CLAIM_NUM], Ipolicy[POLICY_NUM_1], Iquota[7];
$char  Nassured[21], Ibrand[9], Itag[CA_TAG_NUM], Iengine[CA_ENGINE_NUM];
$char  Nname[11], Lawgiver[11], Iacc_area[5];
$char  Daccident[21];
char   GsDaccident[10];
$char  fstl[2];
$char  Dclose_edate[11];
$char  Iins_type[INSURANCE_TYPE];
$int   Iclose_type;
$int   Msettle,  Mrec_done,  Msal_done, really_recovery, id1;
$int   TMsettle, TMrec_done, TMsal_done, TMmrecov, Treally_recovery;
$char  Drecov[11];
$char  GHsFrecov[2];
$char  GHsFrecover[2],daccept[11],dlaw[11];
$char  GHsFreprocess[2];
$char  Dprocess[11];
$char  compancy_name[11];
$char  recov_man[2],recov_comp[7],dprocess[11];
$char  recov_branch[21],recov_claim[16],recov_officer[11];
$char  recov_tel[17],recov_process[25],recov_out[2];
$char  qduty_adjuster[5],pduty_rec[5],itag_oth[CA_TAG_NUM],ndriver_oth[50];
$char  iofficer[11],up_nchi_full[40];
$char  iupbranch[3];
$int   GHiMmrecov;
/* $char  nchi_full[5]; */
$char  sIexec_type[2], sDexec_type[11], sDrecov_out[11], sDrecov_back[11],
       sFrecov_out2[4], sDrecov_out2[11], sDrecov_back2[11], sDclaim[11],
       sFlaw_recover[2];

int  count;

void car517_title();
long car517_build();

main(argc, argv)
int  argc;
char **argv;
{
    char scriptFile[120];
    int  rc=0;

        batchinit();

        strcpy(DBName,                  isNULLstr(argv[1]));
        strcpy(userid,                  isNULLstr(argv[2]));
        strcpy(GsOption,                isNULLstr(argv[3]));  /* 1-�l�v,2-���*/
        strcpy(GsFrecov_GsFsal,         isNULLstr(argv[4]));  /* �l�v���A */
        strcpy(GsFrecover_GsFsale,      isNULLstr(argv[5]));  /* �l�v�O */
        strcpy(GsFreprocess,            isNULLstr(argv[6]));  /* �l�v�i�� */
        strcpy(GsFrecovman,             isNULLstr(argv[7]));  /* �l�v��H */
        strcpy(ibranch_flag,            isNULLstr(argv[8]));  /* ���z�����O */
        strcpy(ibranch,                 isNULLstr(argv[9]));  /* ���z��� */
        strcpy(fcard_class,             isNULLstr(argv[10]));  /* V-���N,C-�j��*/
        strcpy(dclaimbgn,               isNULLstr(argv[11]));  /* ���z�_�� */
        strcpy(dclaimend,               isNULLstr(argv[12])); /* ���z�״� */
        strcpy(date_flag,               isNULLstr(argv[13])); /* ���פ�����O */
        strcpy(datebgn,                 isNULLstr(argv[14])); /* ���װ_�l��� */
        strcpy(dateend,                 isNULLstr(argv[15])); /* ���ײפ��� */
        strcpy(outputf,                 isNULLstr(argv[16]));

        if( dclaimbgn[0] =='*') strcpy(dclaimbgn, "87/01/01");
        if( dclaimend[0] == '*') strcpy(dclaimend, "199/12/30");

        if( datebgn[0] == '*') strcpy( datebgn, "87/01/01");
        if( dateend[0] == '*') strcpy( dateend, "199/12/30");
        if( dateend[0] == ' ') strcpy( dateend, datebgn);

        strcpy(dclaim_ebgn,cm_to_infdate(dclaimbgn));
        strcpy(dclaim_eend,cm_to_infdate(dclaimend));

        strcpy(datebgn_edate,cm_to_infdate(datebgn));
        strcpy(dateend_edate,cm_to_infdate(dateend));


        printf("*****car517_build BEGIN !!!!*****\n");

        if((rc=car517_build()) == SUCCESS)
        {
            printf("***** car517_build SUCCESS !!!!! \n");

            create_sign_form("car5171", BodyFile, Width);
            if((rc=save_form_info(F_BLK0,"CA",517,userid,FormTp,max_count,outputf))<0)
                  EWRITE(userid,rc,"save_form_info failed");
            else
                  printf("debugscott success on save_form_info!!\n\n");
        }

}

long car517_build()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
   int    b,BranchCnt;

   $WHENEVER SQLERROR GOTO errexit;

   if(db_select(DBName) == False)
   {
      EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
      return FAIL;
   }

   if(GsOption[0] == '1')
   {

        /**** �l�v�� report form ****/
        $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
                kTot_Col, kPgNum_Line, kWidth, iForm_Tp
           INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow,
                $TotColumn, $PgLine, $Width, $FormTp
           FROM Form
          WHERE ksys_grp="CA" AND kPgmID = 517 AND
                iForm_Tp = '1';
   }
   else
   {

        /**** ���� report form ****/
        $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
                kTot_Col, kPgNum_Line, kWidth, iForm_Tp
           INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow,
                $TotColumn, $PgLine, $Width, $FormTp
           FROM Form
          WHERE ksys_grp="CA" AND kPgmID = 517 AND
                iForm_Tp = '2';
   }

   strcpy( TitleFmt, rtrim(TitleFmt));
   strcpy( BodyFmt,  rtrim(BodyFmt));
   sprintf( TitleFile,"%s.ti",outputf);
   sprintf( BodyFile, "%s.bd",outputf);

   /******* �إߤ@�� TEMP TABLE ******/

   $WHENEVER SQLERROR GOTO errexit;
   $CREATE TEMP TABLE CAR517_TEMP
   (
       iclaim         char(21),
       ipolicy        char(21),
	   iquota         char(7),
       nassured       char(21),
       ibrand         char(9),
       itag           char(12),
       iengine        char(25),
       nname          char(11),
       lawgiver       char(11),
       iacc_area      char(4),
       daccident      char(21),
       fstl           char(2),
       dclose         date,
       iins_type      char(7),
       iclose_type    integer,
       msettle        integer DEFAULT 0,
       mrec_done      integer DEFAULT 0,
       msal_done      integer DEFAULT 0,
       drecov         char(10),
       dsal           char(10),
       frecov         char(2),
       frecover       char(2),
       daccept        date,
       dlaw           date,
       freprocess     char(2),
       dprocess       char(10),
       mmrecov        integer DEFAULT 0,
       really_recovery integer DEFAULT 0,
       mrecov_man     char(2),
       mrecov_comp    char(8),
       recov_branch   char(21),
       recov_claim    char(16),
       recov_officer  char(11),
       recov_tel      char(17),
       recov_process  char(25),
       recov_out      char(2),
       up_nchi_full   char(40),
       qduty_adjuster char(5),
       pduty_rec char(5),
       itag_oth	      char(12),
       ndriver_oth     char(50),
       iexec_type		char(1),		--���W����
       dexec_type	    date,	       	--���o���W�����ɶ�
       drecov_out		date,	        --�Ĥ@���e�~�ɶ�
       drecov_back	    date,	        --�Ĥ@���e�~�h�^�ɶ�
       frecov_out2		char(3),	    --�ĤG���e�~��H
       drecov_out2		date,	        --�ĤG���e�~�ɶ�
       drecov_back2	    date,		    --�ĤG���e�~�h�^�ɶ�
       dclaim           date,           -- ���z���
       flaw_recover     char(1)         -- �k�l�O
   )WITH NO LOG;

   /************* �B�z���Y ************/

   rgu_init_report( TitleFmt,TitleFile);
   car517_title();

   rgu_finish_report();

   /************* �B�z���� ************/

   rgu_init_report( BodyFmt,BodyFile);
   max_count=0;

   TMsettle = TMrec_done = TMsal_done = TMmrecov = Treally_recovery = 0;

   /****** �}�l��ƪ��B�z�οz�� *******/


   if(strcmp(trim(ibranch_flag),"4")!=0)
   {
   	car517_process();
   }
   else
   {
   	car517_process_all();
   }


   car517_data();
   if (max_count == 0)
   {
       EWRITE(userid, M_CM_NOT_FOUND, "�L��ƥi�B�z!!! ");
       exit(1);
   }

   if (GsOption[0] == '1')
   {
       car517_tot1();
   }
   else
   {
       car517_tot2();
   }

   rgu_finish_report();

   return SUCCESS;

 errexit:
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}

void car517_title()
{
   char yy[4],mm[3],dd[3];
   char SysTm[30];

   strcpy( SysTm, cm_get_sysd());
   rgu_put_head_string( 1, cm_sysd_cdate_100(SysTm));   /* get_currdt */

   if (strcmp(trim(date_flag),"1")==0)   /*** �z�ߵ��פ�� ***/
   {
       rgu_put_head_string(2, "�z�ߵ���");
   }
   else
   {
       rgu_put_head_string(2, "�l�v����");
   }

   cm_split_ymd_100(datebgn, yy, mm, dd);
     rgu_put_head_string(1, yy);
     rgu_put_head_string(1, mm);
     rgu_put_head_string(1, dd);
   cm_split_ymd_100(dateend, yy, mm, dd);
     rgu_put_head_string(1, yy);
     rgu_put_head_string(1, mm);
     rgu_put_head_string(1, dd);
   rgu_put_head();
}

car517_process()
{

   $char iclaim[CLAIM_NUM],ipolicy[POLICY_NUM_1],iquota[7];
   $char iclaim_tmp[CLAIM_NUM],ipolicy_tmp[POLICY_NUM_1];
   $char nassured[21], ibrand[9], itag[CA_TAG_NUM], iengine[CA_ENGINE_NUM];
   $char iadjuster[11], nname[11], lawgiver[11], iacc_area[5];
   $char daccident[21];
   $char dclose[11];
   $char iins_type[INSURANCE_TYPE];
   $int  msettle,mrec_done,msal_done,iclose_type,cnt;
   $char drecov[11];
   $char frecov[2],freprocess[2];
   $char LHsFrecover[2];
   $char sW1[1024];
   $char sW2[512];
   $char sW3[1024];
   $char branch_tmp[3];

   int   rtncode = 0;
   int   rc=0;
   $char LocalName[50];
   $char sFullName[20];     /*�߮ר��z��Ʈw*/
   $char sFullName1[20];    /*�O��Ҧb��Ʈw*/
   $char sFullName2[20];    /*�w���I�ة����ɩҦb��Ʈw*/
   count=0;

   $WHENEVER SQLERROR GOTO errexit;


   	sprintf(sStmt,"SELECT iupcomp   \
                    FROM branch \
                   WHERE ibranch = '%s' ",ibranch);

   	$PREPARE acursor_0 FROM $sStmt;
   	$DECLARE a_0 CURSOR FOR acursor_0;
   	$OPEN a_0;
   	while(1)
   	{
         	$FETCH a_0 INTO  $iupbranch;
         	if( SQLCODE == SQLNOTFOUND) break;
   	}
   	$CLOSE a_0;
   	$FREE a_0;

   	strcpy(sFullName, get_full_dbname(iupbranch));


   switch(ibranch_flag[0])
   {
       case '1': strcpy(sW1," ");
                 break;

       case '2': sprintf(sW1," AND a.ibranch = '%s' ",ibranch);
                 break;

       case '3': sprintf(sW1," AND a.ibranch in (select ibranch         \
                                                   from branch          \
                                                  where iupbranch = '%s') ",ibranch);
                 break;
       case '4': strcpy(sW1," ");
                 break;
   }

   sprintf(stmt,"select branch           \
                   from servertbl        \
                  where branch != 'S1'   \
                  order by branch ");

   $prepare ser_id1 from $stmt;
   $declare ser_cur1 cursor for ser_id1;
   $open ser_cur1;
   for(;;)
   {
   $fetch ser_cur1 into $branch_tmp;
   printf("branch_temp = %s\n",branch_tmp);
   if (SQLCODE == SQLNOTFOUND) break;

     strcpy(sFullName1, get_full_dbname(branch_tmp));
     printf("sFullName1 = %s\n",sFullName1);
     if (fcard_class[0] == '2')
     {
        sprintf(sStmt,
          " SELECT First 1 iins_type          \
              FROM %s:app_ins_type    \
             WHERE iclaim = ? ",sFullName1);
          $PREPARE iidd1 FROM $sStmt;

        sprintf(sStmt,
          " SELECT NVL(SUM(mins_stl),0)                  \
              FROM %s:stl_ins_type                       \
             WHERE iclaim = ?                            \
               AND dgroup is not null                    \
               AND fstl = '1' ",sFullName1);
          $PREPARE mid FROM $sStmt;

        sprintf(sW3," AND a.iclaim in               \
                      (SELECT t.iclaim              \
                         FROM %s:app_ins_type t     \
                        WHERE a.iclaim  =  t.iclaim ) " ,sFullName1);
     }
     else
     {
        sprintf(sW3," ");
     }

     msettle = mrec_done = msal_done = GHiMmrecov = really_recovery = 0;

     /****  1 �z�ߵ��פ�  2 �l�v��槹���� ****/
     /* �s�W���z����� add by sylvia 109.02.03 (1081005003_SC1) */
     if (strcmp(trim(date_flag),"1")==0)
     {
         /*** 1 �z�ߵ��פ� ***/
         sprintf(sStmt,"SELECT DISTINCT x.iclaim,x.ipolicy,x.dclose,x.msettle,x.mrecov, \
                               x.msal_done,x.frecov,x.drecov,x.lawgiver,x.frecover,date(x.daccept),date(x.dlaw), \
                               x.mmrecov,x.really_recovery,x.dsal,x.freprocess,NVL(x.dprocess,' '), \
                               x.recov_man,x.recov_comp,x.recov_branch,x.recov_claim,   \
                               x.recov_officer,x.recov_tel,x.recov_process,x.frecov_out, \
                               x.pduty_rec,x.itag_oth,x.ndriver_oth, \
                               x.iexec_type, x.dexec_type, x.drecov_out, x.drecov_back, \
                               x.frecov_out2, x.drecov_out2, x.drecov_back2, a.dclaim, x.flaw_recover \
                          FROM %s:recovery x, %s:settlement y, %s:ca_local_clm a, ca_clm_process b \
                         WHERE x.iclaim = y.iclaim            \
                           AND (x.dclose BETWEEN '%s' AND '%s' or x.dclose is null )    \
                           AND y.fcard_class = '%s'           \
                           AND a.iclaim = b.iclaim            \
                           AND a.iclaim = y.iclaim            \
                           AND b.ibranch_in = '%s'            \
                           AND a.dclaim >= '%s'               \
                           AND a.dclaim <= '%s' %s %s ",
        sFullName1,sFullName1,sFullName,datebgn_edate,dateend_edate,fcard_class,branch_tmp,dclaim_ebgn,dclaim_eend,sW1,sW3);
        printf("sStmt[%s]\n",sStmt);




     }
     else
     {
         if(GsOption[0] == '1')
         {
         /**** �l�v������ ****/
         sprintf(sStmt,"SELECT DISTINCT x.iclaim,x.ipolicy,x.dclose,x.msettle,x.mrecov, \
                               x.msal_done,x.frecov,x.drecov,x.lawgiver,x.frecover,date(x.daccept),date(x.dlaw), \
                               x.mmrecov, x.really_recovery, x.dsal, x.freprocess, NVL(x.dprocess,' '), \
                               x.recov_man,x.recov_comp,x.recov_branch,x.recov_claim, \
                               x.recov_officer,x.recov_tel,x.recov_process,x.frecov_out, \
                               x.pduty_rec,x.itag_oth,x.ndriver_oth, \
                               x.iexec_type, x.dexec_type, x.drecov_out, x.drecov_back, \
                               x.frecov_out2, x.drecov_out2, x.drecov_back2, a.dclaim, x.flaw_recover \
                          FROM %s:recovery x, %s:settlement y, %s:ca_local_clm a, ca_clm_process b \
                         WHERE x.iclaim = y.iclaim            \
                           AND x.drecov BETWEEN '%s' AND '%s' \
                           AND y.fcard_class = '%s'           \
                           AND a.iclaim = b.iclaim            \
                           AND a.iclaim = y.iclaim            \
                           AND b.ibranch_in = '%s'            \
                           AND a.dclaim >= '%s'               \
                           AND a.dclaim <= '%s' %s %s ",
        sFullName1,sFullName1,sFullName,datebgn_edate,dateend_edate,fcard_class,branch_tmp,dclaim_ebgn,dclaim_eend,sW1,sW3);
        printf("sStmt[%s]\n",sStmt);
         }
         else
         {
         /**** ��槹���� ****/
         sprintf(sStmt,"SELECT DISTINCT x.iclaim,x.ipolicy,x.dclose,x.msettle,x.mrecov, \
                               x.msal_done,x.frecov,x.drecov,x.lawgiver,x.frecover,date(x.daccept),date(x.dlaw),\
                               x.mmrecov, x.really_recovery, x.dsal, x.freprocess, NVL(x.dprocess,' '), \
                               x.recov_man,x.recov_comp,x.recov_branch,x.recov_claim, \
                               x.recov_officer,x.recov_tel,x.recov_process,x.frecov_out, \
                               x.pduty_rec,x.itag_oth,x.ndriver_oth, \
                               x.iexec_type, x.dexec_type, x.drecov_out, x.drecov_back, \
                               x.frecov_out2, x.drecov_out2, x.drecov_back2, a.dclaim, x.flaw_recover \
                          FROM %s:recovery x, %s:settlement y, %s:ca_local_clm a, ca_clm_process b \
                         WHERE x.iclaim = y.iclaim          \
                           AND x.dsal BETWEEN '%s' AND '%s' \
                           AND y.fcard_class = '%s'         \
                           AND a.iclaim = b.iclaim          \
                           AND a.iclaim = y.iclaim          \
                           AND b.ibranch_in = '%s'          \
                           AND a.dclaim >= '%s'             \
                           AND a.dclaim <= '%s' %s %s  ",
        sFullName1,sFullName1,sFullName,datebgn_edate,dateend_edate,fcard_class,branch_tmp,dclaim_ebgn,dclaim_eend,sW1,sW3);
        printf("sStmt[%s]\n",sStmt);
         }
     }

     if(GsOption[0] == '1')   /* �l�v */
     {
             if(strcmp(trim(GsFrecov_GsFsal),"0")==0)
                      strcat(sStmt," AND x.frecov ='0'");
             if(strcmp(trim(GsFrecov_GsFsal),"1")==0)
                      strcat(sStmt," AND x.frecov ='1'");
             if(strcmp(trim(GsFrecov_GsFsal),"2")==0)
                      strcat(sStmt," AND x.frecov ='2'");
             if(strcmp(trim(GsFrecov_GsFsal),"3")==0)
                      strcat(sStmt," AND x.frecov ='3'");
             if(strcmp(trim(GsFrecov_GsFsal),"4")==0)
                      strcat(sStmt," AND x.frecov ='4'");
             if(strcmp(trim(GsFrecov_GsFsal),"Z")==0)
                      strcat(sStmt," AND x.frecov matches '*'");

             if(strcmp(trim(GsFrecover_GsFsale),"1")==0)
                      strcat(sStmt," AND x.frecover ='1'");
             if(strcmp(trim(GsFrecover_GsFsale),"2")==0)
                      strcat(sStmt," AND x.frecover ='2'");
             if(strcmp(trim(GsFrecover_GsFsale),"3")==0)
                      strcat(sStmt," AND x.frecover ='3'");
             if(strcmp(trim(GsFrecover_GsFsale),"4")==0)
                      strcat(sStmt," AND x.frecover ='4'");
             if(strcmp(trim(GsFrecover_GsFsale),"5")==0)
                      strcat(sStmt," AND x.frecover ='5'");
             if(strcmp(trim(GsFrecover_GsFsale),"A")==0)
                      strcat(sStmt," AND x.frecover in ('1','2','3','4')");
             if(strcmp(trim(GsFrecover_GsFsale),"B")==0)
                      strcat(sStmt," AND x.frecover in ('1','2','3','4','5')");

             switch (GsFreprocess[0])
             {

                  case ' ':
                  case '0':
                  case '1':
                  case '2':
                  case '3':
                  case '4':
                  case '5':
                  case '6':
                  case '7':
                           sprintf(sStmt," %s AND x.freprocess = '%c' ",rtrim(sStmt),GsFreprocess[0]);
                           break;
                   default:
                           break;
             }

             if(strcmp(trim(GsFrecovman),"0")==0)
                      strcat(sStmt," AND x.recov_man ='0'");
             if(strcmp(trim(GsFrecovman),"1")==0)
                      strcat(sStmt," AND x.recov_man ='1'");
             if(strcmp(trim(GsFrecovman),"2")==0)
                      strcat(sStmt," AND x.recov_man ='2'");
             if(strcmp(trim(GsFrecovman),"3")==0)
                      strcat(sStmt," AND x.recov_man ='3'");
             if(strcmp(trim(GsFrecovman),"4")==0)
                      strcat(sStmt," AND x.recov_man ='4'");

     }
     else   /* ��� */
     {
             if(strcmp(trim(GsFrecov_GsFsal),"0")==0)
                      strcat(sStmt," AND x.fsal ='0'");
             if(strcmp(trim(GsFrecov_GsFsal),"1")==0)
                      strcat(sStmt," AND x.fsal ='1'");
             if(strcmp(trim(GsFrecov_GsFsal),"2")==0)
                      strcat(sStmt," AND x.fsal ='2'");
             if(strcmp(trim(GsFrecov_GsFsal),"3")==0)
                      strcat(sStmt," AND x.fsal ='3'");
             if(strcmp(trim(GsFrecov_GsFsal),"4")==0)
                      strcat(sStmt," AND x.fsal ='4'");
             if(strcmp(trim(GsFrecov_GsFsal),"Z")==0)
                      strcat(sStmt," AND x.fsal matches '*'");

             if(strcmp(trim(GsFrecover_GsFsale),"1")==0)
                      strcat(sStmt," AND x.fsale ='1'");
     }

     strcat(sStmt," ORDER BY x.iclaim");

     $PREPARE acursor_3 FROM $sStmt;
     $DECLARE a_3 CURSOR FOR acursor_3;
     $OPEN a_3;
     while(1)
     {
          /**** $iclose_type , $fstl ***/
          $FETCH a_3 INTO $iclaim ,$ipolicy, $dclose, $msettle, $mrec_done,
                          $msal_done, $frecov, $drecov, $lawgiver, $LHsFrecover,$daccept,$dlaw,
                          $GHiMmrecov, $really_recovery, $GHsDsal,$freprocess,$dprocess,$recov_man,
                          $recov_comp, $recov_branch,$recov_claim,$recov_officer,
                          $recov_tel, $recov_process,$recov_out,
                          $pduty_rec,$itag_oth,$ndriver_oth,
                          $sIexec_type, $sDexec_type, $sDrecov_out, $sDrecov_back,
                          $sFrecov_out2, $sDrecov_out2, $sDrecov_back2, $sDclaim, $sFlaw_recover;
          if (SQLCODE == SQLNOTFOUND)  break;

	  printf("daccept[%s],dlaw[%s]\n",daccept,dlaw);

          if (fcard_class[0] == '2')
          {
              $EXECUTE iidd1 INTO $iins_type USING $iclaim;

              $EXECUTE mid INTO $msettle USING $iclaim;
          }
		  
			sprintf(sStmt,
			  " SELECT iquota     \
				  FROM %s:ori_ply_relation    \
				 WHERE ipolicy = ? ",sFullName1);
			$PREPARE acursor_5 FROM $sStmt;
			$EXECUTE acursor_5 INTO $iquota USING $ipolicy;
			
			if(SQLCODE == SQLNOTFOUND){
				strcpy(iquota," ");
			}

          /*** �d�߽߮װ򥻸�� ***/
          sprintf(sStmt,"SELECT a.nassured, a.ibrand, a.itag, a.iengine, \
                                b.iadjuster, b.iacc_area, a.daccident    \
                          FROM %s:adjustment_ply a , %s:appraisal b      \
                         WHERE a.iclaim = '%s'                           \
                           AND b.iclaim = A.iclaim ",
                        sFullName1,sFullName1,iclaim);

          $PREPARE acursor_4 FROM $sStmt;
          $DECLARE a_4 CURSOR FOR acursor_4;
          $OPEN a_4;
          while(1)
          {
             $FETCH a_4 INTO $nassured, $ibrand, $itag, $iengine, $iadjuster,
                             $iacc_area,$daccident;
             if(SQLCODE==SQLNOTFOUND) break;

             if( strncmp(LHsFrecover,"1",1) == 0 || strncmp(LHsFrecover,"2",1) == 0) /* �l�v�O = 1. �ۦ�l�v */
             {
                 strcpy( iofficer, lawgiver );
             }
             else
             {
                 strcpy( iofficer , iadjuster );
             }

	     printf("iofficer = %s\n",iofficer)	;

             $SELECT (select nbranch from sa_branch_type
                 where ibranch = a.iquota),
                (select nchi_abv from v_branch
                 where ibranch = a.ibranch)
                INTO $up_nchi_full,$iacc_area     /*$nchi_full*/
                FROM officer a
               WHERE a.iofficer = $iofficer
               group by 1,2;

             if (strncmp(iofficer," ",1) == 0)
             {
                 strcpy(up_nchi_full," ");
                 strcpy(iacc_area," ");
             }

             /* Get �z�ߤH��'s name */
             $SELECT nname
                INTO $nname
                FROM officer
                WHERE iofficer = $iadjuster;

	     /*Get �����r�p�F�d*/
	     $SELECT First 1 a.qduty_adjuster
	     	INTO $qduty_adjuster
	     	FROM ca_clm_victim_data a,ca_ver_relation b
	     	WHERE b.iclaim=$iclaim
	     	AND a.iclaim=b.iverify
	     	AND a.fvictim_car='F';

	     	printf("qduty_adjuster = %s\n",qduty_adjuster);

		printf("up_nchi_full = %s\n",up_nchi_full);

               if (msettle >0 || (msettle == 0 && strcmp(trim(LHsFrecover),"2")==0))
               {
                     printf("Before INTO CAR517_TEMP[%s]\n",iclaim);
                     $INSERT INTO CAR517_TEMP
                             (iclaim, ipolicy, iquota, nassured, ibrand, itag, iengine, nname, lawgiver,
                             iacc_area, daccident, dclose, iins_type, msettle, mrec_done,
                             msal_done, drecov, dsal, frecov, frecover, daccept, dlaw,freprocess, dprocess,
                             mmrecov, really_recovery, mrecov_man, mrecov_comp, recov_branch, recov_claim,
                             recov_officer, recov_tel, recov_process, recov_out, up_nchi_full,
                             qduty_adjuster,pduty_rec,itag_oth,ndriver_oth,
                             iexec_type, dexec_type, drecov_out, drecov_back,
                             frecov_out2, drecov_out2, drecov_back2, dclaim, flaw_recover )
                     VALUES
                             ($iclaim, $ipolicy, $iquota, $nassured, $ibrand, $itag, $iengine, $nname, $lawgiver,
                             $iacc_area, $daccident, $dclose, $iins_type, $msettle,
                             $mrec_done, $msal_done, $drecov, $GHsDsal,  $frecov,
                             $LHsFrecover, $daccept, $dlaw, $freprocess,$dprocess, $GHiMmrecov, $really_recovery, $recov_man,
                             $recov_comp , $recov_branch, $recov_claim, $recov_officer,
                             $recov_tel, $recov_process, $recov_out, $up_nchi_full,
                             $qduty_adjuster,$pduty_rec,$itag_oth,$ndriver_oth,
                             $sIexec_type, $sDexec_type, $sDrecov_out, $sDrecov_back,
                             $sFrecov_out2, $sDrecov_out2, $sDrecov_back2, $sDclaim, $sFlaw_recover);

                             count ++;
               }
          }
          $CLOSE a_4;
          $FREE  a_4;
     }
     $CLOSE a_3;
     $FREE a_3;
   }
   $close ser_cur1;
   $free  ser_cur1;
   return SUCCESS;

errexit:
   printf( "*** SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
   rc = isEWRITE(SQLCODE,sqlca.sqlerrm);
   isfinish(rc);
} /* car517_process */


car517_process_all()
{

   $char iclaim[CLAIM_NUM],ipolicy[POLICY_NUM_1],iquota[7];
   $char iclaim_tmp[CLAIM_NUM],ipolicy_tmp[POLICY_NUM_1];
   $char nassured[21], ibrand[9], itag[CA_TAG_NUM], iengine[CA_ENGINE_NUM];
   $char iadjuster[11], nname[11], lawgiver[11], iacc_area[5];
   $char daccident[21];
   $char dclose[11];
   $char iins_type[INSURANCE_TYPE];
   $int  msettle,mrec_done,msal_done,iclose_type,cnt;
   $char drecov[11];
   $char frecov[2],freprocess[2];
   $char LHsFrecover[2];
   $char sW2[512];
   $char sW3[1024];
   $char branch_tmp[3],branch_tmp1[3];

   int   rtncode = 0;
   int   rc=0;
   $char LocalName[50];
   $char sFullName[20];     /*�߮ר��z��Ʈw*/
   $char sFullName1[20];    /*�O��Ҧb��Ʈw*/
   $char sFullName2[20];    /*�w���I�ة����ɩҦb��Ʈw*/
   $char fkind[4];
   count=0;

   $WHENEVER SQLERROR GOTO errexit;


   sprintf(stmt,"select branch           \
                   from servertbl        \
                  where branch != 'S1'   \
                  order by branch ");
   $prepare ser_id1_1 from $stmt;
   $declare ser_cur1_1 cursor for ser_id1_1;
   $open ser_cur1_1;
   for(;;)
   {
   $fetch ser_cur1_1 into $branch_tmp;
   if (SQLCODE == SQLNOTFOUND) break;

     strcpy(sFullName1, get_full_dbname(branch_tmp));

     if (fcard_class[0] == '2')
     {
        /* sprintf(sStmt,
          " SELECT First 1 iins_type          \
              FROM %s:app_ins_type    \
             WHERE iclaim = ? ",sFullName1); */
        sprintf(sStmt,
          " SELECT First 1 a.iins_type, \
                   decode(fkind,'1','1.0','4','1.1','2','2.0','6','2.1','3','3.0','D','3.1','5.0') \
              FROM %s:app_ins_type a, insurance_type b   \
             WHERE a.iins_type = b.iins_type \
               and a.iclaim = ? \
             order by 2 ",sFullName1);
          $PREPARE iidd1 FROM $sStmt;

        sprintf(sStmt,
          " SELECT NVL(SUM(mins_stl),0)                  \
              FROM %s:stl_ins_type                       \
             WHERE iclaim = ?                            \
               AND dgroup is not null                    \
               AND fstl = '1' ",sFullName1);
          $PREPARE mid FROM $sStmt;

        sprintf(sW3," AND b.iclaim in               \
                      (SELECT t.iclaim              \
                         FROM %s:app_ins_type t     \
                        WHERE b.iclaim  =  t.iclaim ) " ,sFullName1);
     }
     else
     {
        sprintf(sW3," ");
     }

     msettle = mrec_done = msal_done = GHiMmrecov = really_recovery = 0;

     /****  1 �z�ߵ��פ�  2 �l�v��槹���� ****/

     if (strcmp(trim(date_flag),"1")==0)
     {
         /*** 1 �z�ߵ��פ� ***/
         sprintf(sStmt,"SELECT DISTINCT x.iclaim,x.ipolicy,x.dclose,x.msettle,x.mrecov, \
                               x.msal_done,x.frecov,x.drecov,x.lawgiver,x.frecover,date(x.daccept),date(x.dlaw), \
                               x.mmrecov,x.really_recovery,x.dsal,x.freprocess,NVL(x.dprocess,' '), \
                               x.recov_man,x.recov_comp,x.recov_branch,x.recov_claim,   \
                               x.recov_officer,x.recov_tel,x.recov_process,x.frecov_out, \
                               x.pduty_rec,x.itag_oth,x.ndriver_oth, \
                               x.iexec_type, x.dexec_type, x.drecov_out, x.drecov_back, \
                               x.frecov_out2, x.drecov_out2, x.drecov_back2, b.dclaim, x.flaw_recover \
                          FROM %s:recovery x, %s:settlement y, ca_clm_process b \
                         WHERE x.iclaim = y.iclaim            \
                           AND (x.dclose BETWEEN '%s' AND '%s' or x.dclose is null )    \
                           AND y.fcard_class = '%s'           \
                           AND b.iclaim = y.iclaim            \
                           AND b.ibranch_in = '%s'            \
                           AND b.dclaim >= '%s'               \
                           AND b.dclaim <= '%s' %s ",
        sFullName1,sFullName1,datebgn_edate,dateend_edate,fcard_class,branch_tmp,dclaim_ebgn,dclaim_eend,sW3);
        printf("sStmt[%s]\n",sStmt);
     }
     else
     {
         if(GsOption[0] == '1')
         {
         /**** �l�v������ ****/
         sprintf(sStmt,"SELECT DISTINCT x.iclaim,x.ipolicy,x.dclose,x.msettle,x.mrecov, \
                               x.msal_done,x.frecov,x.drecov,x.lawgiver,x.frecover,date(x.daccept),date(x.dlaw), \
                               x.mmrecov, x.really_recovery, x.dsal, x.freprocess, NVL(x.dprocess,' '), \
                               x.recov_man,x.recov_comp,x.recov_branch,x.recov_claim, \
                               x.recov_officer,x.recov_tel,x.recov_process,x.frecov_out, \
                               x.pduty_rec,x.itag_oth,x.ndriver_oth, \
                               x.iexec_type, x.dexec_type, x.drecov_out, x.drecov_back, \
                               x.frecov_out2, x.drecov_out2, x.drecov_back2, b.dclaim, x.flaw_recover \
                          FROM %s:recovery x, %s:settlement y, ca_clm_process b \
                         WHERE x.iclaim = y.iclaim            \
                           AND x.drecov BETWEEN '%s' AND '%s' \
                           AND y.fcard_class = '%s'           \
                           AND b.iclaim = y.iclaim            \
                           AND b.ibranch_in = '%s'            \
                           AND b.dclaim >= '%s'               \
                           AND b.dclaim <= '%s' %s ",
        sFullName1,sFullName1,datebgn_edate,dateend_edate,fcard_class,branch_tmp,dclaim_ebgn,dclaim_eend,sW3);
        printf("sStmt[%s]\n",sStmt);
         }
         else
         {
         /**** ��槹���� ****/
         sprintf(sStmt,"SELECT DISTINCT x.iclaim,x.ipolicy,x.dclose,x.msettle,x.mrecov, \
                               x.msal_done,x.frecov,x.drecov,x.lawgiver,x.frecover,date(x.daccept),date(x.dlaw),\
                               x.mmrecov, x.really_recovery, x.dsal, x.freprocess, NVL(x.dprocess,' '), \
                               x.recov_man,x.recov_comp,x.recov_branch,x.recov_claim, \
                               x.recov_officer,x.recov_tel,x.recov_process,x.frecov_out, \
                               x.pduty_rec,x.itag_oth,x.ndriver_oth, \
                               x.iexec_type, x.dexec_type, x.drecov_out, x.drecov_back, \
                               x.frecov_out2, x.drecov_out2, x.drecov_back2, b.dclaim, x.flaw_recover \
                          FROM %s:recovery x, %s:settlement y, ca_clm_process b \
                         WHERE x.iclaim = y.iclaim          \
                           AND x.dsal BETWEEN '%s' AND '%s' \
                           AND y.fcard_class = '%s'         \
                           AND b.iclaim = y.iclaim          \
                           AND b.ibranch_in = '%s'          \
                           AND b.dclaim >= '%s'             \
                           AND b.dclaim <= '%s' %s  ",
        sFullName1,sFullName1,datebgn_edate,dateend_edate,fcard_class,branch_tmp,dclaim_ebgn,dclaim_eend,sW3);
        printf("sStmt[%s]\n",sStmt);
         }
     }

     if(GsOption[0] == '1')   /* �l�v */
     {
             if(strcmp(trim(GsFrecov_GsFsal),"0")==0)
                      strcat(sStmt," AND x.frecov ='0'");
             if(strcmp(trim(GsFrecov_GsFsal),"1")==0)
                      strcat(sStmt," AND x.frecov ='1'");
             if(strcmp(trim(GsFrecov_GsFsal),"2")==0)
                      strcat(sStmt," AND x.frecov ='2'");
             if(strcmp(trim(GsFrecov_GsFsal),"3")==0)
                      strcat(sStmt," AND x.frecov ='3'");
             if(strcmp(trim(GsFrecov_GsFsal),"4")==0)
                      strcat(sStmt," AND x.frecov ='4'");
             if(strcmp(trim(GsFrecov_GsFsal),"Z")==0)
                      strcat(sStmt," AND x.frecov matches '*'");

             if(strcmp(trim(GsFrecover_GsFsale),"1")==0)
                      strcat(sStmt," AND x.frecover ='1'");
             if(strcmp(trim(GsFrecover_GsFsale),"2")==0)
                      strcat(sStmt," AND x.frecover ='2'");
             if(strcmp(trim(GsFrecover_GsFsale),"3")==0)
                      strcat(sStmt," AND x.frecover ='3'");
             if(strcmp(trim(GsFrecover_GsFsale),"4")==0)
                      strcat(sStmt," AND x.frecover ='4'");
             if(strcmp(trim(GsFrecover_GsFsale),"5")==0)
                      strcat(sStmt," AND x.frecover ='5'");
             if(strcmp(trim(GsFrecover_GsFsale),"A")==0)
                      strcat(sStmt," AND x.frecover in ('1','2','3','4')");
             if(strcmp(trim(GsFrecover_GsFsale),"B")==0)
                      strcat(sStmt," AND x.frecover in ('1','2','3','4','5')");

             switch (GsFreprocess[0])
             {

                  case ' ':
                  case '0':
                  case '1':
                  case '2':
                  case '3':
                  case '4':
                  case '5':
                  case '6':
                  case '7':
                           sprintf(sStmt," %s AND x.freprocess = '%c' ",rtrim(sStmt),GsFreprocess[0]);
                           break;
                   default:
                           break;
             }

             if(strcmp(trim(GsFrecovman),"0")==0)
                      strcat(sStmt," AND x.recov_man ='0'");
             if(strcmp(trim(GsFrecovman),"1")==0)
                      strcat(sStmt," AND x.recov_man ='1'");
             if(strcmp(trim(GsFrecovman),"2")==0)
                      strcat(sStmt," AND x.recov_man ='2'");
             if(strcmp(trim(GsFrecovman),"3")==0)
                      strcat(sStmt," AND x.recov_man ='3'");
             if(strcmp(trim(GsFrecovman),"4")==0)
                      strcat(sStmt," AND x.recov_man ='4'");

     }
     else   /* ��� */
     {
             if(strcmp(trim(GsFrecov_GsFsal),"0")==0)
                      strcat(sStmt," AND x.fsal ='0'");
             if(strcmp(trim(GsFrecov_GsFsal),"1")==0)
                      strcat(sStmt," AND x.fsal ='1'");
             if(strcmp(trim(GsFrecov_GsFsal),"2")==0)
                      strcat(sStmt," AND x.fsal ='2'");
             if(strcmp(trim(GsFrecov_GsFsal),"3")==0)
                      strcat(sStmt," AND x.fsal ='3'");
             if(strcmp(trim(GsFrecov_GsFsal),"4")==0)
                      strcat(sStmt," AND x.fsal ='4'");
             if(strcmp(trim(GsFrecov_GsFsal),"Z")==0)
                      strcat(sStmt," AND x.fsal matches '*'");

             if(strcmp(trim(GsFrecover_GsFsale),"1")==0)
                      strcat(sStmt," AND x.fsale ='1'");
     }
	
     strcat(sStmt," ORDER BY x.iclaim");

     $PREPARE acursor_3_1 FROM $sStmt;
     $DECLARE a_3_1 CURSOR FOR acursor_3_1;
     $OPEN a_3_1;
     while(1)
     {
          /**** $iclose_type , $fstl ***/
          $FETCH a_3_1 INTO $iclaim ,$ipolicy, $dclose, $msettle, $mrec_done,
                          $msal_done, $frecov, $drecov, $lawgiver, $LHsFrecover,$daccept,$dlaw,
                          $GHiMmrecov, $really_recovery, $GHsDsal,$freprocess,$dprocess,$recov_man,
                          $recov_comp, $recov_branch,$recov_claim,$recov_officer,
                          $recov_tel, $recov_process,$recov_out,
                          $pduty_rec,$itag_oth,$ndriver_oth,
                          $sIexec_type, $sDexec_type, $sDrecov_out, $sDrecov_back,
                          $sFrecov_out2, $sDrecov_out2, $sDrecov_back2, $sDclaim, $sFlaw_recover;
          if (SQLCODE == SQLNOTFOUND)  break;

printf("daccept[%s],dlaw[%s]\n",daccept,dlaw);

          if (fcard_class[0] == '2')
          {
              $EXECUTE iidd1 INTO $iins_type, $fkind USING $iclaim;

              $EXECUTE mid INTO $msettle USING $iclaim;
          }

			sprintf(sStmt,
			  " SELECT iquota     \
				  FROM %s:ori_ply_relation    \
				 WHERE ipolicy = ? ",sFullName1);
			$PREPARE acursor_5_1 FROM $sStmt;
			$EXECUTE acursor_5_1 INTO $iquota USING $ipolicy;
			
			if(SQLCODE == SQLNOTFOUND){
				strcpy(iquota," ");
			}

          /*** �d�߽߮װ򥻸�� ***/
          sprintf(sStmt,"SELECT a.nassured, a.ibrand, a.itag, a.iengine, \
                                b.iadjuster, b.iacc_area, a.daccident    \
                          FROM %s:adjustment_ply a , %s:appraisal b      \
                         WHERE a.iclaim = '%s'                           \
                           AND b.iclaim = A.iclaim ",
                        sFullName1,sFullName1,iclaim);

          $PREPARE acursor_4_1 FROM $sStmt;
          $DECLARE a_4_1 CURSOR FOR acursor_4_1;
          $OPEN a_4_1;
          while(1)
          {
             $FETCH a_4_1 INTO $nassured, $ibrand, $itag, $iengine, $iadjuster,
                             $iacc_area,$daccident;
             if(SQLCODE==SQLNOTFOUND) break;

             if( strncmp(LHsFrecover,"1",1) == 0 || strncmp(LHsFrecover,"2",1) == 0) /* �l�v�O = 1. �ۦ�l�v */
             {
                 strcpy( iofficer, lawgiver );
             }
             else
             {
                 strcpy( iofficer , iadjuster );
             }

	     printf("iclaim = %s\n",iclaim);

             $SELECT (select nbranch from sa_branch_type
                 where ibranch = a.iquota),
                (select nchi_abv from v_branch
                 where ibranch = a.ibranch)
                INTO $up_nchi_full,$iacc_area     /*$nchi_full*/
                FROM officer a
               WHERE a.iofficer = $iofficer
               group by 1,2;

             if (strncmp(iofficer," ",1) == 0)
             {
                 strcpy(up_nchi_full," ");
                 strcpy(iacc_area," ");
             }

	     printf("up_nchi_full = %s\n",up_nchi_full);
	     printf("iacc_area = %s\n",iacc_area);

             /* Get �z�ߤH��'s name */
             $SELECT nname
                INTO $nname
                FROM officer
                WHERE iofficer = $iadjuster;
              printf("nname = %s\n",nname);


             /*Get �����r�p�F�d*/
	     $SELECT First 1 a.qduty_adjuster
	     	INTO $qduty_adjuster
	     	FROM ca_clm_victim_data a,ca_ver_relation b
	     	WHERE b.iclaim=$iclaim
	     	ANd a.iclaim=b.iverify
	     	AND a.fvictim_car='F';

		printf("qduty_adjuster = %s\n",qduty_adjuster);
		printf("up_nchi_full = %s\n",up_nchi_full);

               if (msettle >0 || (msettle == 0 && strcmp(trim(LHsFrecover),"2")==0))
               {
                     printf("Before INTO CAR517_TEMP[%s]\n",iclaim);
                     $INSERT INTO CAR517_TEMP
                             (iclaim, ipolicy, iquota, nassured, ibrand, itag, iengine, nname, lawgiver,
                             iacc_area, daccident, dclose, iins_type, msettle, mrec_done,
                             msal_done, drecov, dsal, frecov, frecover, daccept, dlaw,freprocess, dprocess,
                             mmrecov, really_recovery, mrecov_man, mrecov_comp, recov_branch, recov_claim,
                             recov_officer, recov_tel, recov_process, recov_out, up_nchi_full,
                             qduty_adjuster,pduty_rec,itag_oth,ndriver_oth,
                             iexec_type, dexec_type, drecov_out, drecov_back,
                             frecov_out2, drecov_out2, drecov_back2, dclaim, flaw_recover)
                     VALUES
                             ($iclaim, $ipolicy, $iquota, $nassured, $ibrand, $itag, $iengine, $nname, $lawgiver,
                             $iacc_area, $daccident, $dclose, $iins_type, $msettle,
                             $mrec_done, $msal_done, $drecov, $GHsDsal,  $frecov,
                             $LHsFrecover, $daccept, $dlaw, $freprocess,$dprocess, $GHiMmrecov, $really_recovery, $recov_man,
                             $recov_comp , $recov_branch, $recov_claim, $recov_officer,
                             $recov_tel, $recov_process, $recov_out, $up_nchi_full,
                             $qduty_adjuster,$pduty_rec,$itag_oth,$ndriver_oth,
                             $sIexec_type, $sDexec_type, $sDrecov_out, $sDrecov_back,
                             $sFrecov_out2, $sDrecov_out2, $sDrecov_back2, $sDclaim, $sFlaw_recover);

                             count ++;
               }
          }
          $CLOSE a_4_1;
          $FREE  a_4_1;
     }
     $CLOSE a_3_1;
     $FREE a_3_1;
   }
   $close ser_cur1_1;
   $free  ser_cur1_1;
   return SUCCESS;

errexit:
   printf( "*** SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
   rc = isEWRITE(SQLCODE,sqlca.sqlerrm);
   isfinish(rc);
}/* car517_process_all */

car517_tot1()
{
   char str[15];

   rgu_put_body(2);
   max_count+=1;
   sprintf( str, "%d", count);       rgu_put_body_string( 3, str, RIGHT);
   sprintf( str, "%d", TMsettle);    rgu_put_body_string( 3, str, RIGHT);
   sprintf( str, "%d", TMrec_done);  rgu_put_body_string( 3, str, RIGHT);
   sprintf( str, "%d", TMmrecov);  rgu_put_body_string( 3, str, RIGHT);
   sprintf( str, "%d", Treally_recovery);  rgu_put_body_string( 3, str, RIGHT);
   rgu_put_body(3);   max_count+=1;

   TMsettle = TMrec_done = TMsal_done = TMmrecov = Treally_recovery = 0;
}

car517_tot2()
{
   char str[15];

   rgu_put_body(4);
   max_count+=1;
   sprintf( str, "%d", count);       rgu_put_body_string( 2, str, RIGHT);
   sprintf( str, "%d", TMsettle);    rgu_put_body_string( 2, str, RIGHT);
   sprintf( str, "%d", TMrec_done);  rgu_put_body_string( 2, str, RIGHT);
   sprintf( str, "%d", TMmrecov);  rgu_put_body_string( 2, str, RIGHT);
   rgu_put_body(2);   max_count+=1;

   TMsettle = TMrec_done = TMsal_done = TMmrecov = 0;
}

car517_data()
{
   int   i;

   $WHENEVER SQLERROR GOTO errexit;
   printf("enter car517_data[%s]\n", outputf);

   $DECLARE Jcur CURSOR FOR
     SELECT distinct iclaim, ipolicy, iquota, nassured, ibrand, itag, iengine, nname, lawgiver,
                     iacc_area, daccident, dclose, iins_type, msettle, mrec_done, msal_done,
                     drecov, dsal, frecov, frecover, daccept, dlaw, freprocess, dprocess, mmrecov, really_recovery, mrecov_man,
                     mrecov_comp, recov_branch, recov_claim, recov_officer, recov_tel,
                     recov_process, recov_out, up_nchi_full,
                     qduty_adjuster,pduty_rec,itag_oth,ndriver_oth,
                     iexec_type, dexec_type, drecov_out, drecov_back,
                     frecov_out2, drecov_out2, drecov_back2, to_char(dclaim,'%Y/%m/%d'),
                     flaw_recover
       FROM CAR517_TEMP;
   $OPEN Jcur;

   while(1)
   {
       $FETCH Jcur
         INTO $Iclaim, $Ipolicy, $Iquota, $Nassured, $Ibrand, $Itag, $Iengine, $Nname, $Lawgiver,
              $Iacc_area, $Daccident, $Dclose_edate, $Iins_type, $Msettle, $Mrec_done,
              $Msal_done, $Drecov, $GHsDsal, $GHsFrecov, $GHsFrecover, $daccept, $dlaw, $GHsFreprocess,
              $Dprocess, $GHiMmrecov, $really_recovery:id1, $recov_man, $recov_comp, $recov_branch, $recov_claim,
              $recov_officer, $recov_tel, $recov_process, $recov_out, $up_nchi_full,
              $qduty_adjuster,$pduty_rec,$itag_oth,$ndriver_oth,
              $sIexec_type, $sDexec_type, $sDrecov_out, $sDrecov_back, $sFrecov_out2,
              $sDrecov_out2, $sDrecov_back2, $sDclaim, $sFlaw_recover;

       if( SQLCODE == SQLNOTFOUND) break;


        if(GsOption[0] == '1')
        {
                car517_body1();
        }
        else
        {
                car517_body2();
        }

   }
   $CLOSE Jcur;
   $FREE Jcur;

   return SUCCESS;

errexit:
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}

car517_body1()
{

   printf("---------------------------------------------------Key data to form --------------------------------\n");
   EXEC SQL BEGIN DECLARE SECTION;
       char LHsNname[11];
   EXEC SQL END DECLARE SECTION;

   $char str[21];

   EXEC SQL WHENEVER SQLERROR GOTO errexit;

   EXEC SQL SELECT nname
              INTO :LHsNname
              FROM officer
             WHERE iofficer = :Lawgiver;

   if(SQLCODE == SQLNOTFOUND)
   {
           memset(LHsNname, 0x00, sizeof(LHsNname));
   }
   rgu_put_body_string( 1,up_nchi_full, LEFT);    /** ��    �� **/
   printf("��� = %s \n",up_nchi_full);
   rgu_put_body_string( 1,Iacc_area, LEFT);       /** �X�I�a�� **/
   printf("�X�I�a�� = %s \n",Iacc_area);
   rgu_put_body_string( 1,Iclaim, LEFT);          /** �߮׸��X **/
   printf("�߮׸��X = %s \n",Iclaim);
   rgu_put_body_string( 1,Ipolicy, LEFT);         /** �O�渹�X **/
   printf("�O�渹�X = %s \n",Ipolicy);
   rgu_put_body_string( 1,Iquota, LEFT);         /** �~�Z���N�� **/
   printf("�~�Z���N�� = %s \n",Iquota);
   rgu_put_body_string( 1,Nassured, LEFT);        /** �Q�O�I�H **/
   printf("�Q�O�I�H = %s \n",Nassured);
   rgu_put_body_string( 1,qduty_adjuster,LEFT);   /**�����r�p�F�d**/
   printf("�����r�p�F�d = %s \n",qduty_adjuster);
   rgu_put_body_string( 1,Ibrand, LEFT);          /** �t�P���� **/
   printf("�t�P���� = %s \n",Ibrand);
   rgu_put_body_string( 1,Itag, LEFT);            /** �P�Ӹ��X **/
   printf("�P�Ӹ��X = %s \n",Itag);
   rgu_put_body_string( 1,Nname, LEFT);           /** �z�ߤH�� **/
   printf("�z�ߤH�� = %s \n",Nname);
   rgu_put_body_string( 1,LHsNname, LEFT);        /** �k�ȤH�� **/
      printf("�k�ȤH�� = %s \n",LHsNname);
   rgu_put_body_string( 1,sDclaim, LEFT);         /** ���z��� **/
   printf("���z��� = %s \n",sDclaim);
   memcpy(GsDaccident, ltrim(Daccident), 10);
   rgu_put_body_string( 1,GsDaccident, LEFT);     /** �X�I�ɶ� **/
   printf("�X�I��� = %s \n",GsDaccident);
   strcpy( str, ltrim(Dclose_edate));             /** ���פ�� **/
   rgu_put_body_string( 1,str, LEFT);
   printf("���פ�� = %s \n",str);

   rgu_put_body_string( 1,Iins_type, LEFT);       /** �I�اO   **/
   printf("�I�اO = %s \n",Iins_type);

   sprintf( str,"%d", Msettle);                   /** �ߥI���B **/
   rgu_put_body_string( 1,str, RIGHT);
   printf("�ߥI���B = %s\n",str);

   sprintf( str,"%d", Mrec_done);                 /** �l�v���B **/
   rgu_put_body_string( 1,str, RIGHT);
   printf("�l�v���B = %s \n",str);

   sprintf( str,"%d", GHiMmrecov);                /** ���l�v���B **/
   rgu_put_body_string( 1,str, RIGHT);
   printf("���l�v���B = %s \n",str);

   if (id1!=-1)
   {
       sprintf( str,"%d", really_recovery);           /** ��l�`�B **/
       rgu_put_body_string( 1,str, RIGHT);
   } else rgu_put_body_string( 1," ", RIGHT);
   printf("��l�v�`�B = %s\n",str);

   strcpy( str, ltrim(Drecov));
   rgu_put_body_string( 1,str, LEFT);		    /** �l�v��� **/
   printf("�l�v��� = %s \n",str);

   if(GHsFrecov[0] == '0')                          /** �l�v���A **/
       strcpy( str, "�����l�v");
   else if(GHsFrecov[0] == '1')
       strcpy( str, "�l�v��");
   else if(GHsFrecov[0] == '2')
       strcpy( str, "���l�v");
   else if(GHsFrecov[0] == '3')
       strcpy( str, "�����l�v");
   else if(GHsFrecov[0] == '4')
        strcpy( str, "�l�v�����l�v�z��");
   else
        strcpy( str, " ");

   rgu_put_body_string( 1,str, LEFT);			/** �l�v���A **/
   printf("�l�v���A = %s \n",str);

   if( GHsFrecover[0] == '0')                          /** �l�v�O   **/
       strcpy( str, "�����l�v");
   else if(GHsFrecover[0] == '1')
       strcpy( str, "�ۦ�l�v");
   else if(GHsFrecover[0] == '2')
       strcpy( str, "�w�ۦ�l�v");
   else if(GHsFrecover[0] == '3')
       strcpy( str, "�k�Ȱl�v");
   else if(GHsFrecover[0] == '4')
       strcpy( str, "�ۦ�l�v��k�Ȱl�v");
   else if(GHsFrecover[0] == '5')
       strcpy( str, "�j���I�u��");
   else
       strcpy( str, " ");

   rgu_put_body_string( 1,str, LEFT);			/** �l�v�O   **/
   printf("�l�v�O = %s \n",str);


   if( sFlaw_recover[0] == 'Y')                 /** �k�l�O   **/
       strcpy( str, "�P�~");
   else if( sFlaw_recover[0] == 'N')
       strcpy( str, "�D�P�~");
   else
       strcpy( str, " ");

   rgu_put_body_string( 1,str, LEFT);			/** �k�l�O   **/
   printf("�k�l�O = %s \n",str);

   rgu_put_body_string( 1,daccept, LEFT);		/** �k�ȹ��鱵�פ�� **/
   printf("�k�ȹ��鱵�פ�� = %s \n",daccept);

   strcpy( str, ltrim(dlaw));
   rgu_put_body_string( 1,dlaw, LEFT);			/** �P�N���z��� **/
   printf("�P�N���z��� = %s \n",dlaw);

   switch(GHsFreprocess[0]){

   case '0':
            strcpy( str,"�s��");
            break;
   case '1':
            strcpy( str,"�_�D");
            break;
   case '2':
            strcpy( str,"��I�R�O");
            break;
   case '3':
            strcpy( str,"�P�M�T�w");
            break;
   case '4':
            strcpy( str,"�e�~");
            break;
   case '5':
            strcpy( str,"��ưe�F");
            break;
   case '6':
            strcpy( str,"�w�M��");
            break;
   case '7':
            strcpy( str,"�ݱj�����");
            break;

   default :
            strcpy( str," ");
            break;
   }
   rgu_put_body_string( 1,str, LEFT);			/*�l�v�i��*/
   printf("�l�v�i�� = %s \n",str);


   switch(sIexec_type[0]){

       case '1':
                strcpy( str,"�P�M�T�w�νT��");
                break;
       case '2':
                strcpy( str,"�ոѵ���");
                break;
       case '3':
                strcpy( str,"��I�R�O�νT��");
                break;
       case '4':
                strcpy( str,"��L");
                break;

       default :
                strcpy( str," ");
                break;
   }

   rgu_put_body_string( 1,str, LEFT);			/*���o���W����*/
   printf("���o���W���� = %s \n",str);

   rgu_put_body_string( 1,sDexec_type, LEFT);	/*���o���W�����ɶ�*/
   printf("���o���W�����ɶ� = %s \n",str);

   printf("recov_out[%c]\n",recov_out[0]);

   $select ncode
      into $str
      from cu_code_data
     where itype = '94'
       and icode = $recov_out;

   if (SQLCODE == SQLNOTFOUND) strcpy(str," ");

   /**************************************************

   switch(recov_out[0])
   {

   case '1':
            strcpy( str,"�W��");
            break;
   case '2':
            strcpy( str,"���f");
            break;
   case '3':
            strcpy( str,"�d�B");
            break;
   default :
            strcpy( str," ");
            break;
   }

   **************************************************/

   strcpy(str, trim(str));
   rgu_put_body_string( 1,str, LEFT);                      /*�Ĥ@���e�~��H*/
   printf("�Ĥ@���e�~��H = %s \n",str);

   rgu_put_body_string( 1,sDrecov_out, LEFT);              /*�Ĥ@���e�~�ɶ�*/
   printf("�Ĥ@���e�~�ɶ� = %s \n",str);

   rgu_put_body_string( 1,sDrecov_back, LEFT);              /*�Ĥ@���h�^�ɶ�*/
   printf("�Ĥ@���h�^�ɶ� = %s \n",str);


   $select ncode
      into $str
      from cu_code_data
     where itype = '94'
       and icode = $sFrecov_out2;

   if (SQLCODE == SQLNOTFOUND) strcpy(str," ");

    strcpy(str, trim(str));
   rgu_put_body_string( 1,str, LEFT);                      /*�ĤG���e�~��H*/
   printf("�ĤG���e�~��H = %s \n",str);

   rgu_put_body_string( 1,sDrecov_out2, LEFT);              /*�ĤG���e�~�ɶ�*/
   printf("�ĤG���e�~�ɶ� = %s \n",str);

   rgu_put_body_string( 1,sDrecov_back2, LEFT);              /*�ĤG���h�^�ɶ�*/
   printf("�ĤG���h�^�ɶ� = %s \n",str);


   rgu_put_body_string( 1,Dprocess, LEFT);                 /*�l�v�i�פ��*/
   printf("�l�v�i�פ�� = %s\n",Dprocess);

   switch(recov_man[0]){

   case '1':
            strcpy( str , "�����Q�O�I�H�ξr�p�H");
            break;
   case '2':
            strcpy( str , "��y�Q�O�I�H�ξr�p�H");
            break;
   case '3':
            strcpy( str , "��y�O�I���q");
            break;
   case '4':
            strcpy( str , "��L");
            break;
   default :
            strcpy( str , " ");
            break;
   }

   rgu_put_body_string( 1,str, LEFT);                  /*�l�v��H*/
   printf("�l�v��H = %s\n",str);

   rgu_put_body_string( 1,pduty_rec,LEFT);	       /*�l�v�F�d*/
   printf("�l�v�F�d = %s \n",pduty_rec);

   rgu_put_body_string( 1,itag_oth,LEFT);		/*�l�v����*/
   printf("�l�v���� = %s \n",itag_oth);

   rgu_put_body_string( 1,ndriver_oth,LEFT);		/*�l�v���D*/
   printf("�l�v���D = %s \n",ndriver_oth);


   $SELECT nrin_abbre
      INTO $compancy_name
      FROM ri_ricom_info
     WHERE frin_attr = '2'
       AND irin_com = $recov_comp;

   if ( SQLCODE == SQLNOTFOUND ) strcpy( compancy_name , " ");

   rgu_put_body_string( 1,compancy_name, LEFT);		/*�P�~�W��*/
   printf("�P�~�W�� = %s \n",compancy_name);

   rgu_put_body_string( 1,recov_branch, LEFT);		/*�P�~���*/
   printf("�P�~��� = %s \n",recov_branch);

   rgu_put_body_string( 1,recov_claim, LEFT);		/*�P�~�׸�*/
   printf("�P�~�׸� = %s \n",recov_claim);

   rgu_put_body_string( 1,recov_officer, LEFT);		/*�P�~�g��*/
   printf("�P�~�g�� = %s \n",recov_officer);

   rgu_put_body_string( 1,recov_tel, LEFT);		/*�P�~�q��*/
   printf("�P�~�q�� = %s \n",recov_tel);

   rgu_put_body_string( 1,recov_process, LEFT);		/*�P�~�y�{*/
   printf("�P�~�y�{ = %s\n",recov_process);

   rgu_put_body( 1);
   max_count+=1;

   TMsettle   += Msettle;
   TMrec_done += Mrec_done;
   TMsal_done += Msal_done;
   TMmrecov   += GHiMmrecov;
   if (id1!=-1) Treally_recovery += really_recovery;

errexit:
   /* no return value , do nothing */
   printf(" ");

}

car517_body2()
{
   char str[21];

   rgu_put_body_string( 1,Iclaim, LEFT);          /** �߮׸��X **/
   rgu_put_body_string( 1,Ipolicy, LEFT);         /** �O�渹�X **/
   rgu_put_body_string( 1,Nassured, LEFT);        /** �Q�O�I�H **/
   rgu_put_body_string( 1,Ibrand, LEFT);          /** �t�P���� **/
   rgu_put_body_string( 1,Itag, LEFT);            /** �P�Ӹ��X **/
   rgu_put_body_string( 1,Nname, LEFT);           /** �z�ߤH�� **/
   rgu_put_body_string( 1,Iacc_area, LEFT);       /** �X�I�a�� **/
   rgu_put_body_string( 1,sDclaim, LEFT);         /** ���z��� **/
   memcpy(GsDaccident, Daccident, 10);
   rgu_put_body_string( 1,GsDaccident, LEFT);     /** �X�I�ɶ� **/
   strcpy( str, Dclose_edate);                    /** ���פ�� **/
   rgu_put_body_string( 1,str, LEFT);
   rgu_put_body_string( 1,Iins_type, LEFT);       /** �I�اO   **/
   sprintf( str,"%d", Msettle);                   /** �ߥI���B **/
   rgu_put_body_string( 1,str, RIGHT);
   sprintf( str,"%d", Msal_done);                 /** �����B **/
   rgu_put_body_string( 1,str, RIGHT);
   sprintf( str,"%d", GHiMmrecov);                /** �������B **/
   rgu_put_body_string( 1,str, RIGHT);
   strcpy( str, GHsDsal);                         /** ����� **/
   rgu_put_body_string( 1,str, LEFT);

   if(GHsFrecov[0] == '0')                        /** ��檬�A **/
       strcpy( str, "�������");
   else if(GHsFrecov[0] == '1')
       strcpy( str, "��椤");
   else if(GHsFrecov[0] == '2')
       strcpy( str, "�����");
   else if(GHsFrecov[0] == '3')
       strcpy( str, "�������");
   else if(GHsFrecov[0] == '4')
        strcpy( str, "�M�^�ծ�");
   else
        strcpy( str, " ");

   rgu_put_body_string( 1,str, LEFT);

   rgu_put_body( 1);
   max_count+=1;

   TMsettle   += Msettle;
   TMrec_done += Mrec_done;
   TMsal_done += Msal_done;
   TMmrecov   += GHiMmrecov;
}

char *get_car_full_db(sIpolicy)

char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, sTmpcomp);
  }
  return sTmp_db_name;
}

