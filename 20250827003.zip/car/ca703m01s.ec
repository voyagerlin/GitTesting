/************************************************/
/*                                              */
/*   PROGRAM : ca703m01s.ec                     */
/*   DATE:     2017/03/29    by 041090          */
/*                                              */
/************************************************/

#include <stdio.h>
#include <string.h>
#include <decimal.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"
$include sqlca;

int isalpha (int c);
int isascii (int c);

long MsgCode;

DBinfo  *list;
int  count_db, i;
static int max_cnt;

long car703(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car703_multiple_query();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'Q': rtncode=car703_single_query(reply);
                  break;
  case 'M':
           rtncode=car703_multiple_query(reply);
           break;
  default :
        return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
 }
 return(rtncode);
}



/* -------------------------------------------------------------------------- */
long car703_multiple_query(reply)
serverReply reply;
{
    $char   DBName[5], sFullName[21], sUser[10];
    $char   stmt[2048], sComb1[25];
    $char   sDetail[11], sChiname[11];
            
    char    tmpbuf[4000];
    int     count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int     i,icount1;

    cm_buf_get("%s %s ",DBName, sUser);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }

    sprintf_s(stmt, sizeof stmt, "select detail, chiname  "
                    " from car_code  "
                    "where kind = 'B3' and detail2 = '%s'", sUser);

    $PREPARE pre_m1 FROM $stmt;
    $DECLARE cur_m1 CURSOR FOR pre_m1;
    $OPEN cur_m1 ;
    icount1 = 0;
    for(;;)
    {
        $FETCH cur_m1 INTO $sDetail, $sChiname;
        if(SQLCODE==SQLNOTFOUND) break;
        
        icount1++;
        
        strcpy(sDetail, trim(sDetail));
        strcpy(sChiname,trim(sChiname));
        
        sprintf_s(sComb1, sizeof sComb1,"%10.10s %6.10s\n",sDetail,sChiname );
        
        cm_buf_init(tmpbuf);
        if ( count == 0 )
        {
            cm_buf_res_msg();             /* reserve for MsgCode and count */
            cm_buf_res_count();
        }

        cm_buf_put("%s",sComb1);
        tmp_len = cm_buf_len(tmpbuf);

        if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
        {
            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else                               /* more than 4K, send to client side */
        {
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);
            if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {
                $CLOSE cur_m1;
                return apiRC;
            }
            else               /* clear ReplyBuf and count to start all over again */
            {
                replycnt++;
                if (replycnt == 10)   /* more than 30K, client cannot display,error */
                {
                    cm_buf_init(ReplyBuf);
                    cm_buf_put("%l",M_CM_OUT_SPACE);
                    tmp_len = cm_buf_len(ReplyBuf);
                    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                        return apiRC;

                    return M_CM_OUT_SPACE;
                }

                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();           /* reserve for MsgCode and count */
                cm_buf_res_count();
                cm_buf_put("%s",sComb1);
                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
            }
        }
    } /* for loop */

    $CLOSE cur_m1;
    $FREE cur_m1;

    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
            return apiRC;

        return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
        if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
            return M_CM_NOT_FOUND;                               /*?*/
        else
            return apiRC;
    }

errexit:
    if(exitsub(reply,SQLCODE) == True)
        return SQLCODE;
    else
        return apiRC;
}
/* -------------------------------------------------------------------------- */
long car703_single_query(reply)
serverReply reply;
{
    $char DBName[5], sUser[10];
    
    $int  iseq, icount;
    int tmp_len;
    
    cm_buf_get("%s",DBName);
    cm_buf_get("%s",sUser);

    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    icount = 0;
    
    $SELECT count(*) into $icount
       FROM car_code
      WHERE kind = 'B3' and detail2 = $sUser;
      
    
    if (SQLCODE==SQLNOTFOUND){
	    if (exitsub(reply,M_CM_NOT_FOUND) == True)
	       return M_CM_NOT_FOUND;
	    else
	       return apiRC;
    }    

    cm_buf_init(ReplyBuf);

    cm_buf_put("%l %d", M_CM_OK, icount);
        
    tmp_len = cm_buf_len(ReplyBuf);    
    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
   return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}