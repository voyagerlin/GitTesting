/**********************************************************************
 *  Program ID: ca_assure_job �۰���O������p�Ȧs�ɦܥ���assured_vs_ply
 *
 *      Author: Johnny 07/22/1997
 *
 * Description:
 *     This program move data of local machine to anywhere you hope.
 *
 *    Function:
 *      1. get_all_system
 *      2. is_ply_assure
 *      3. is_edr_assure
 **********************************************************************/

#include <stdio.h>
#include <signal.h>
#include "commsgs.h"
#include "cmnmsg.h"
#include "comdata.h"
#include "globdata.h"
#include "safeclib.h"
/* *** Macro definition *** */
#define         SUCCESS  	0
#define         FAIL    	-1
#define         TRUE    	1
#define         FALSE   	0
#define		MAX_TIME 	480
#define		MIN_TIME	10

/* *** Message Definition *** */
#define		M_OK			1000
#define		M_E_ELAPSEDTIME		1001
#define		M_E_HOSTNAME		1002
#define		M_E_OPENDATABASE	1003
#define		M_E_OUTOFCONTROL	1004
#define		M_E_NODATA		1005
#define		M_E_NDATABASE		1006
#define		M_E_NSYSDB		1007

#define _CODE860804

/* *** Global variables *** */
 int	g_iElapsedTime, g_fExit;
 char	g_sLogFileName[81], g_sTmpBuf[254], g_sExeFileName[80];
$char   sHostName[81];
DBinfo  *list;

/* *** Function prototype *** */
void sig_proc();
void get_all_system();
void is_ply_assure();
void is_edr_assure();

main(argc, argv)
int argc;
char **argv;
{
  if (argc < 2){
    printf("Usage: ca_assure_job <time>\n"); exit(1);
  }

  strcpy(g_sExeFileName,IS_BaseName(argv[0]));
  sprintf_s(g_sLogFileName,sizeof g_sLogFileName,"%s/log/%s.log",getenv("APHOME"),g_sExeFileName);

# ifdef _CODE860804
  printf("&&& g_sLogFile:[%s]\n", g_sLogFileName);
# endif

  g_iElapsedTime = atoi(argv[1]);
  g_fExit = FALSE;
  printf("g_iElapsedTime[%d]\n",g_iElapsedTime);

  /* *** Set alarm *** */
  if(g_iElapsedTime > 0)
    alarm(g_iElapsedTime);
  else{
    sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf, "Error001: Elapsed Time(%d), it must be more than zero", 
            g_iElapsedTime);
    IS_WriteLog(g_sLogFileName, M_E_ELAPSEDTIME, g_sTmpBuf);
    exit(1);
  }
  sigset(SIGALRM, sig_proc);
  get_all_system();  

# ifdef _CODE860804
  printf("&&& elapsed time[%d]\n", g_iElapsedTime);
# endif

  if(g_iElapsedTime-10 < MIN_TIME)
    IS_UpdateConf(g_sExeFileName, MIN_TIME);
  else
    IS_UpdateConf(g_sExeFileName, g_iElapsedTime-10);
} /* main */

/* ********************************************************************* */
void sig_proc()
{
  g_fExit = TRUE;
}

/* ************************************************************************
 * get_all_system:
 *
 *     This function synchronize ca_ply_assured of local 
 *   database to each sysDB database.
 *
 ************************************************************************ */
void get_all_system()
{
  $char sFullName[80], sTmt[1024] ;
  $char sSysdb[50],sInit_branch[12]; 
  int   i, rc;

  $WHENEVER SQLERROR GOTO errexit;
  $SET LOCK MODE TO WAIT 5;

  /* *** Get hostname *** */
  if(gethostname(sHostName, 80) == FAIL){
    sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf, "Error002: The program can't get host name !");
    IS_WriteLog(g_sLogFileName, M_E_HOSTNAME, g_sTmpBuf);
    exit(1);
  }

  /* *** Get sysdb database name *** */
# ifdef _CODE860804
  rc = iGetProfileString("insurance.conf", "INIT", "sysdb", "sysdb",
                         sSysdb, 50);
  if(rc < 0){
    sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf, "Error002A: The program can't get sysdb name!");
    IS_WriteLog(g_sLogFileName, M_E_HOSTNAME, g_sTmpBuf);
    exit(1);
  }

  rc = iGetProfileString("insurance.conf", "INIT", "init_branch", "00", 
			 sInit_branch, 50);
  if(rc < 0){
    sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf, "Error002B: The program can't get sysdb name!");
    IS_WriteLog(g_sLogFileName, M_E_HOSTNAME, g_sTmpBuf);
    exit(1);
  }
# endif

/******�o�q�n�����I�_��*****/
# ifdef _CODE860804
  $DATABASE $sSysdb;
# else
  $DATABASE sysdb_ck;
# endif

/* Get all systems database list */
  if( (list=get_sysdb_list(&i, sInit_branch)) == (char*)0 ) {
      sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf, "Error003: The program can't dblist !");
      IS_WriteLog(g_sLogFileName, M_CM_NOT_DBLIST, g_sTmpBuf);
      exit(1);
  }

printf("g_sExeFileName[%s] sHostName[%s] \n",g_sExeFileName,sHostName);
printf("dbname[%s] dbchi[%s] dbbranch[%s]\n",list[0].dbname,list[0].dbchi,
 list[0].dbbranch);
printf("sysdb_count[%d] \n",i);

  is_ply_assure(i);   /*�O��Ȧs��*/
  is_edr_assure(i);   /*���Ȧs��*/
  return;

errexit:
# ifdef _CODE860804
   printf("get_all_system: SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrd);
# endif
   IS_WriteLog(g_sLogFileName, SQLCODE, sqlca.sqlerrm);
   exit(1);

} /* get_all_system */

/* *********************************************************************
 *    Insert Or Update assured_vs_ply Table for all System Database 
 ********************************************************************* */
void is_ply_assure(i)
int   i;
{
$char sBranch[12];
$char sFullName[80], sTmt[1024] ;
$int  icount, j, fNext;

$char Nassured[121], Itag[CA_TAG_NUM], Ibody[21], Iengine[CA_ENGINE_NUM], Ipolicy[19]; 
$char Icard[19], Fcard_class[2], Iassured[13], Ftrans[2];

   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT 5;

   icount=0;
   fNext=FALSE;  /* no error */

   $DECLARE brh_cur CURSOR WITH HOLD FOR
    SELECT branch INTO $sBranch 
      FROM servertbl
     WHERE hostname = $sHostName;
/*     AND (branch="00" OR branch="03" OR branch="08" OR branch="09"
	OR branch="10" OR branch="12" OR branch="13" OR branch="14"
	OR branch="15" OR branch="16");  */
   $OPEN brh_cur;
    for(;;)
    {
      $FETCH brh_cur;
      if(SQLCODE==SQLNOTFOUND) break;
      if(sBranch[0]=='S') continue;  /* no sysdb */

      printf("current process Host[%s]-Branch[%s]\n",sHostName,sBranch);

      strcpy(sFullName, get_full_dbname(sBranch));
      printf("------ FullName[%s]\n",sFullName);

      sprintf_s(sTmt,sizeof sTmt, "SELECT nassured, itag, ibody, iengine, ipolicy, \
			    icard, fcard_class,iassured, ftrans \
                       FROM %s:ca_ply_assured  \
                      WHERE ftrans != 'N' AND ftrans != ' ' ", sFullName);
      $PREPARE ply_ass FROM $sTmt;
      $DECLARE ply_ass_cur CURSOR WITH HOLD FOR ply_ass;
      $OPEN    ply_ass_cur;
      while(1) {
         $FETCH ply_ass_cur INTO $Nassured, $Itag,$Ibody, $Iengine,$Ipolicy, 
			         $Icard, $Fcard_class,$Iassured, $Ftrans;
         if(SQLCODE == SQLNOTFOUND) break;

         icount++;

         $WHENEVER SQLERROR CONTINUE;
         $BEGIN WORK;

printf("ply[%s],Ftrans[%s]\n",Ipolicy,Ftrans);

         if ((Ftrans[0]=='A')||(Ftrans[0]=='U')){
	   for(j=0; j<i; j++){
             sprintf_s(sTmt,sizeof sTmt, "INSERT INTO %s:assured_vs_ply \
		      	          (nassured, itag, ibody, iengine, ipolicy,\
				   icard,fcard_class,iassured)  \
                             VALUES (?,?,?,?,?,?,?,?)", list[j].dbname);   
             $PREPARE ply_a FROM $sTmt;
	     if(SQLCODE < 0)
	     {
		 sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error007:ipolicy(%s) %s,%s",
		         Ipolicy, sqlca.sqlerrm,sTmt);
	         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
		 fNext=TRUE;
		 break; /* next row */
              }
	     $EXECUTE ply_a USING $Nassured,$Itag,$Ibody,$Iengine,$Ipolicy,
				  $Icard, $Fcard_class,$Iassured;
	     if(SQLCODE == -239){
             sprintf_s(sTmt,sizeof sTmt, "UPDATE %s:assured_vs_ply  \
                               SET (nassured, itag, ibody, iengine, ipolicy,\
				    icard, fcard_class,iassured)  \
				 = (?, ?, ?, ?, ?, ?, ?,?) \
                             WHERE ipolicy = '%s'", list[j].dbname, Ipolicy); 
             $PREPARE ply_u FROM $sTmt;
	     if(SQLCODE < 0)
	     {
		 sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error008:ipolicy(%s) %s",
		         Ipolicy, sqlca.sqlerrm);
	         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
		 fNext=TRUE;
		 break; /* next row */
              }   
	     $EXECUTE ply_u USING $Nassured,$Itag,$Ibody,$Iengine,$Ipolicy,
				  $Icard, $Fcard_class,$Iassured;
             if(SQLCODE < 0)
	     {
		 sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error008U:ipolicy(%s) %s",
		         Ipolicy, sqlca.sqlerrm);
	         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
		 fNext=TRUE;
		 break; /* next row */
             }

             continue; /**next syshost**/

             }else if(SQLCODE < 0)
	     {
		 sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error007A:ipolicy(%s) %s",
		         Ipolicy, sqlca.sqlerrm);
	         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
		 fNext=TRUE;
		 break; /* next row */
             }
           }/*for ����sysdb*/
	   if(fNext==TRUE) { /*this row failure*/
	      $ROLLBACK WORK;
	      fNext=FALSE;
	      continue;  /*next row*/
           }

/**** Linda mark :�s�w�אּ�s�W����delete ca_ply_assured 
           /--Update ��l�ɮת��A--/
           sprintf_s(sTmt,sizeof sTmt, "UPDATE %s:ca_ply_assured  \
                             SET ftrans      = 'N' \
                           WHERE ipolicy = ?", sFullName); 
           $PREPARE u_plyass FROM $sTmt;
**********************************************************/
           /* Delete ca_ply_assured table */

           sprintf_s(sTmt,sizeof sTmt, "DELETE FROM %s:ca_ply_assured  \
                           WHERE ipolicy = ?", sFullName); 
           $PREPARE u_plyass FROM $sTmt;

           if(SQLCODE < 0)
	   {
		sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error009:ipolicy(%s) %s",
		        Ipolicy, sqlca.sqlerrm);
	        IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	        $ROLLBACK WORK;
		continue; /* next row */
           }
	   $EXECUTE u_plyass USING $Ipolicy;
           if(SQLCODE < 0)
	   {
		sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error009U:ipolicy(%s) %s",
		        Ipolicy, sqlca.sqlerrm);
	        IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	        $ROLLBACK WORK;
		continue; /* next row */
           }

	 }else if (Ftrans[0]=='D'){
	   for(j=0; j<i; j++){
             sprintf_s(sTmt,sizeof sTmt, "DELETE %s:assured_vs_ply \
                             WHERE ipolicy = %s", list[j].dbname, Ipolicy);
             $PREPARE ply_d FROM $sTmt;
	     if(SQLCODE < 0)
	     {
		 sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error010:ipolicy(%s) %s",
		         Ipolicy, sqlca.sqlerrm);
	         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
		 fNext=TRUE;
		 break; /* next row */
              }
	     /*$EXECUTE ply_d USING $Nassured,$Itag,$Ibody,$Iengine,$Ipolicy,
				  $Icard, $Fcard_class;*/
	     $EXECUTE ply_d ;

             if(SQLCODE < 0)
	     {
		 sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error010D:ipolicy(%s) %s",
		         Ipolicy, sqlca.sqlerrm);
	         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
		 fNext=TRUE;
		 break; /* next row */
             }
           }/*for ����sysdb*/
	   if(fNext==TRUE) { /*this row failure*/
	      $ROLLBACK WORK;
	      fNext=FALSE;
	      continue;  /*next row*/
           }

           /* Delete ��l�ɮ� */
           sprintf_s(sTmt,sizeof sTmt,
           "DELETE %s:ca_ply_assured  \
             WHERE ipolicy = ?", sFullName); 
           $PREPARE d_plyass FROM $sTmt;
           if(SQLCODE < 0)
	   {
		sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error011:ipolicy(%s) %s",
		        Ipolicy, sqlca.sqlerrm);
	        IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	        $ROLLBACK WORK;
		continue; /* next row */
           }
	   $EXECUTE d_plyass USING $Ipolicy;
           if(SQLCODE < 0)
	   {
		sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error011U:ipolicy(%s) %s",
		        Ipolicy, sqlca.sqlerrm);
	        IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	        $ROLLBACK WORK;
		continue; /* next row */
           }

	 }/*fTrans*/

         $COMMIT WORK; /*�����@��*/

	 printf("�����@��:Host[%s-%s] %s", sHostName,sBranch,Ipolicy );
	 sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"�����@��:Host[%s-%s] %s",sHostName,sBranch,Ipolicy );
         IS_WriteLog(g_sLogFileName, M_E_HOSTNAME, g_sTmpBuf);

         /**if(g_fExit){ 
            $CLOSE ply_ass_cur; $FREE ply_ass_cur; 
            $CLOSE brh_cur; $FREE brh_cur; 
            printf("time is up (%ld)... \n", g_iElapsedTime);
            sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf, "Error: time up(%s)", g_iElapsedTime);
            IS_WriteLog(g_sLogFileName, M_E_NODATA, g_sTmpBuf);
            if(g_iElapsedTime*2 > MAX_TIME)
               IS_UpdateConf(g_sExeFileName, MAX_TIME);
	    else
	       IS_UpdateConf(g_sExeFileName, g_iElapsedTime*2);
	       
	    exit(1);
         } *****/

      } /*next row*/
      $CLOSE   ply_ass_cur;
      $FREE    ply_ass_cur;
    } /*next db*/
    $CLOSE brh_cur;
    $FREE  brh_cur;

    printf("[1]�B�z����: Host(%s) =>%d\n", sHostName, icount);
    if(icount == 0){     /* No data, next database */
       sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf, "Error005: Host(%s) has no data", sHostName);
       IS_WriteLog(g_sLogFileName, M_E_NODATA, g_sTmpBuf);
       return;
    }

    return;
errexit:
# ifdef _CODE860804
   printf("is_ply_assure: SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrd);
# endif
   IS_WriteLog(g_sLogFileName, SQLCODE, sqlca.sqlerrm);
   printf("is_ply_assure: SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrd);
   exit(1);

} /* is_ply_assure */

/* *********************************************************************
 *    Insert Or Update assured_vs_ply Table for all System Database 
 ********************************************************************* */
void is_edr_assure(i)
int   i;
{
$char sBranch[12];
$char sFullName[80], sTmt[1024] ;
$int  icount, j, fNext;

$char Nassured[121], Itag[CA_TAG_NUM], Ibody[CA_BODY_NUM], Iengine[CA_ENGINE_NUM], Ipolicy[19]; 
$char Icard[19], Fcard_class[2],Iassured[13], Ftrans[2], Iendorse[15];

   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT 5;

   icount=0;
   fNext=FALSE;  /* no error */

   printf("enter is_edr_assure() process.\n");

   $DECLARE brh_cur2 CURSOR FOR
    SELECT branch INTO $sBranch 
      FROM servertbl
     WHERE hostname = $sHostName;

/*     AND (branch="00" OR branch="03" OR branch="08" OR branch="09"
	OR branch="10" OR branch="12" OR branch="13" OR branch="14"
	OR branch="15" OR branch="16"); */

   $OPEN brh_cur2;
    for(;;)
    {
      $FETCH brh_cur2;
      if(SQLCODE==SQLNOTFOUND) break;
      if(sBranch[0]=='S') continue;   /* no sysdb */ 

      printf("current process Host[%s]-Branch[%s]\n",sHostName,sBranch);
      strcpy(sFullName, get_full_dbname(sBranch));

      sprintf_s(sTmt,sizeof sTmt, "SELECT nassured, itag, ibody, iengine, ipolicy, \
			    iendorse, icard, fcard_class,iassured, ftrans \
                       FROM %s:ca_edr_assured  \
                      WHERE ftrans != 'N' AND ftrans != ' ' \
		      ORDER BY ipolicy, iendorse", sFullName);
      $PREPARE edr_ass FROM $sTmt;
      $DECLARE edr_ass_cur CURSOR WITH HOLD FOR edr_ass;
         $OPEN edr_ass_cur;

      while(1) {
         $FETCH edr_ass_cur INTO $Nassured, $Itag,$Ibody, $Iengine,$Ipolicy, 
			         $Iendorse, $Icard, $Fcard_class,
				 $Iassured,$Ftrans;
         if(SQLCODE == SQLNOTFOUND) break;

printf("ply[%s],edr[%s],Ftrans[%s]\n",Ipolicy,Iendorse,Ftrans);
         icount++;

         $WHENEVER SQLERROR CONTINUE;
         $BEGIN WORK;
printf("--------------1\n");

         if ((Ftrans[0]=='A')||(Ftrans[0]=='U')){
	   for(j=0; j<i; j++){
             sprintf_s(sTmt,sizeof sTmt, "INSERT INTO %s:assured_vs_ply \
		      	          (nassured, itag, ibody, iengine, ipolicy,\
				   icard, fcard_class,iassured)  \
                             VALUES (?,?,?,?,?,?,?,?)", list[j].dbname);   
             $PREPARE edr_a FROM $sTmt;
	     if(SQLCODE < 0)
	     {
		 sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error007:iendorse(%s) %s",
		         Iendorse, sqlca.sqlerrm);
	         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
		 fNext=TRUE;
		 break; /* next row */
              }   
	     $EXECUTE edr_a USING $Nassured,$Itag,$Ibody,$Iengine,$Ipolicy,
				   $Icard, $Fcard_class,$Iassured;
	     if(SQLCODE == -239){
             sprintf_s(sTmt,sizeof sTmt, "UPDATE %s:assured_vs_ply  \
                               SET (nassured, itag, ibody, iengine, ipolicy,\
				    icard, fcard_class,iassured)  \
				 = (?, ?, ?, ?, ?, ?, ?,?) \
                             WHERE ipolicy = '%s'", list[j].dbname, Ipolicy); 
             $PREPARE edr_u FROM $sTmt;
	     if(SQLCODE < 0)
	     {
		 sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error008:ply(%s) %s,%s",
		         Ipolicy, sqlca.sqlerrm,sTmt);
	         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
		 fNext=TRUE;
		 break; /* next row */
              }   
	     $EXECUTE edr_u USING $Nassured,$Itag,$Ibody,$Iengine,$Ipolicy,
				  $Icard, $Fcard_class,$Iassured;
             if(SQLCODE < 0)
	     {
		 sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error008U:ipolicy(%s) %s",
		         Ipolicy, sqlca.sqlerrm);
	         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
		 fNext=TRUE;
		 break; /* next row */
             }

             continue; /**next syshost**/

             }else if(SQLCODE < 0)
	     {
		 sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error007A:ipolicy(%s) %s",
		         Ipolicy, sqlca.sqlerrm);
	         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
		 fNext=TRUE;
		 break; /* next row */
             }
           }/*for ����sysdb*/
printf("--------------2\n");
	   if(fNext==TRUE) { /*this row failure*/
	      $ROLLBACK WORK;
	      fNext=FALSE;
	      continue;  /*next row*/
           }

printf("--------------3\n");
/*****Linda mark : �s�w�אּ�s�W��R�� ca_edr_assured

           /--Update ��l�ɮת��A--/
           sprintf_s(sTmt,sizeof sTmt, "UPDATE %s:ca_edr_assured  \
                             SET ftrans      = 'N' \
                           WHERE ipolicy = ?", sFullName); 
           $PREPARE u_edrass FROM $sTmt;
***********************************************************/
           /* �R��ca_edr_assured �Ȧs��  */

           sprintf_s(sTmt,sizeof sTmt, "DELETE FROM  %s:ca_edr_assured  \
                           WHERE ipolicy = ?", sFullName); 
           $PREPARE u_edrass FROM $sTmt;

           if(SQLCODE < 0)
	   {
		sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error009:ipolicy(%s) %s",
		        Ipolicy, sqlca.sqlerrm);
	        IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	        $ROLLBACK WORK;
		continue; /* next row */
           }
	   $EXECUTE u_edrass USING $Ipolicy;
           if(SQLCODE < 0)
	   {
		sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error009U:ipolicy(%s) %s",
		        Ipolicy, sqlca.sqlerrm);
	        IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	        $ROLLBACK WORK;
		continue; /* next row */
           }

printf("--------------4\n");
	 }else if (Ftrans[0]=='D'){
	   for(j=0; j<i; j++){
             sprintf_s(sTmt,sizeof sTmt, "DELETE %s:assured_vs_ply \
                             WHERE ipolicy = %s", list[j].dbname, Ipolicy);
             $PREPARE edr_d FROM $sTmt;
	     if(SQLCODE < 0)
	     {
		 sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error010:ipolicy(%s) %s",
		         Ipolicy, sqlca.sqlerrm);
	         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
		 fNext=TRUE;
		 break; /* next row */
              }
	     $EXECUTE edr_d USING $Nassured,$Itag,$Ibody,$Iengine,$Ipolicy,
				  $Icard, $Fcard_class,$Iassured;
             if(SQLCODE < 0)
	     {
		 sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error010D:ipolicy(%s) %s",
		         Ipolicy, sqlca.sqlerrm);
	         IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
		 fNext=TRUE;
		 break; /* next row */
             }
           }/*for ����sysdb*/
	   if(fNext==TRUE) { /*this row failure*/
	      $ROLLBACK WORK;
	      fNext=FALSE;
	      continue;  /*next row*/
           }

           /* Delete ��l�ɮ� */
           sprintf_s(sTmt,sizeof sTmt,
           "DELETE %s:ca_ply_assured  \
             WHERE ipolicy = ?", sFullName); 
           $PREPARE d_edrass FROM $sTmt;
           if(SQLCODE < 0)
	   {
		sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error011:ipolicy(%s) %s",
		        Ipolicy, sqlca.sqlerrm);
	        IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	        $ROLLBACK WORK;
		continue; /* next row */
           }
	   $EXECUTE d_edrass USING $Ipolicy;
           if(SQLCODE < 0)
	   {
		sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf,"Error011U:ipolicy(%s) %s",
		        Ipolicy, sqlca.sqlerrm);
	        IS_WriteLog(g_sLogFileName, SQLCODE, g_sTmpBuf);
	        $ROLLBACK WORK;
		continue; /* next row */
           }

	 }/*fTrans*/

         $COMMIT WORK; /*�����@��*/

         if(g_fExit){ /*** check time up ***/

            $CLOSE edr_ass_cur; $FREE edr_ass_cur; 
            $CLOSE brh_cur2; $FREE brh_cur2; 
            /**** Need more time to process next time ****/
            sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf, "Error2: time up(%s)", g_iElapsedTime);
            IS_WriteLog(g_sLogFileName, M_E_NODATA, g_sTmpBuf);
            if(g_iElapsedTime*2 > MAX_TIME)
               IS_UpdateConf(g_sExeFileName, MAX_TIME);
	    else
	       IS_UpdateConf(g_sExeFileName, g_iElapsedTime*2);
	       
	    exit(1);
         }

      } /*next row*/
      $CLOSE   edr_ass_cur;
      $FREE    edr_ass_cur;
    } /*next db*/
    $CLOSE brh_cur2;
    $FREE  brh_cur2;

    printf("[2]�B�z����: Host(%s) =>%d\n", sHostName, icount);
    if(icount == 0){     /* No data, next database */
       sprintf_s(g_sTmpBuf,sizeof g_sTmpBuf, "Error005: Host(%s) has no data", sHostName);
       IS_WriteLog(g_sLogFileName, M_E_NODATA, g_sTmpBuf);
       return;
    }

    return;
errexit:
# ifdef _CODE860804
   printf("is_edr_assure: SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrd);
# endif
   IS_WriteLog(g_sLogFileName, SQLCODE, sqlca.sqlerrm);
   printf("is_edr_assure: SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrd);
   exit(1);

} /* is_edr_assure */

