/********************************************/
/*                                          */
/*   program id   : ca166m01s.ec            */
/*   program name : �u���ѼƶO�v��ƺ��@    */
/*   date written : 2018/03/23              */
/*                                          */
/********************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include <decimal.h>
#include "safeclib.h"


long car166(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	long rtncode;
	long car166_insert(),car166_single_query(),car166_update_exec();
	long car166_multiple_query();
	char option;
	
	cm_buf_init(command);
	cm_buf_get("%c",&option);
	switch(option)
	{
		case 'A':
			rtncode=car166_insert(reply);
			break;
		case 'Q':
			rtncode=car166_single_query(reply);
			break;
		case 'M':
           rtncode=car166_multiple_query(reply);
           break;
        case 'D':
        case 'U':
        	rtncode=car166_update_exec(reply,command,com_len);
        	break;
        default :
        	if(exitsub(reply,M_CM_WRONG_OPTION) == True)
        	    return M_CM_WRONG_OPTION;
        	return apiRC;
    }
    return(rtncode);
}
/*-----------------------------------------------------------------*/
long car166_insert(reply)
serverReply reply;
{
	$char DBName[5];
	$char fclass[7],qperiod[5],pfactor[16],c_drate[8],drate[11],userid[11];
	
	int tmp_len;
	long MsgCode;
	DBinfo *list;
	int i, j, is_add_fail=0, api_f;
	$char stmt_buf[512];
	
	printf("-----insert-----\n");
	cm_buf_get("%s %s %s %s %s %s",DBName,fclass,qperiod,pfactor,c_drate,userid);
	strcpy(drate, cm_to_infdate(c_drate));
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
		    return M_CM_DB_NOTOPEN;
		else
		    return apiRC;
	}
	
	if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
	{
		if(exitsub(reply,M_CM_NOT_DBLIST) == True)
		    return M_CM_NOT_DBLIST;
		return apiRC;
	}
	
	$BEGIN WORK;
	
	for(j=0;j<i;j++)
	{
		sprintf_s(stmt_buf, sizeof stmt_buf, " INSERT INTO %s:short_period_day "
		                 " (fclass,qperiod,pfactor,drate,iupdate,dupdate) "
		                 "  VALUES (?,?,?,?,?,current)" ,list[j].dbname);
		   
		$PREPARE a_id FROM $stmt_buf;
		if(SQLCODE != 0)
		{
			is_add_fail = 1;
			break;
		}
		
		$EXECUTE a_id USING $fclass,$qperiod,$pfactor,$drate,$userid;
		if(SQLCODE != 0)
		{
			is_add_fail = 1;
			break;
		}
		
		cm_buf_init(ReplyBuf);
		cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
		tmp_len = cm_buf_len(ReplyBuf);
		if( j == i-1 )
		    api_f = api_OKComplete;
		else
		    api_f = api_OK;
		
		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
		{
			is_add_fail = 2;
			break;
		}
		
		#ifdef DEBUG 
		printf("INSERT %d\n", j+1);
		#endif
	} /* for loop */
	
	if( is_add_fail == 1 ) goto errexit;
	if( is_add_fail == 2 )
	{
		$ROLLBACK WORK;
		return apiRC;
	}
	
	$WHENEVER SQLERROR GOTO errexit;
	$COMMIT WORK;
	return api_OKComplete;

 errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
       return MsgCode;
   else
       return apiRC;
}
/*-----------------------------------------------------------------*/
long car166_single_query(reply)
serverReply reply;
{
	$char DBName[5];
	$char fclass[7],qperiod[4],pfactor[16],c_drate[10],drate[11];
	$char iupdate[11],nupdate[10],dupdate[20];
	int tmp_len;
	
	printf("-----single query-----\n");
	cm_buf_get("%s %s %s %s",DBName,fclass,qperiod,c_drate);
	strcpy(drate, cm_to_infdate(c_drate));
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
		    return M_CM_DB_NOTOPEN;
		else
		    return apiRC;
	}
	
	$SELECT pfactor,iupdate,dupdate
	   INTO $pfactor,$iupdate,$dupdate
       FROM short_period_day
      WHERE fclass = $fclass
        AND qperiod = $qperiod
        AND drate = $drate;
       
    if(SQLCODE==SQLNOTFOUND)
    {
    	if(exitsub(reply,M_CA_NSHORT_RATE) == True)
    	    return M_CA_NSHORT_RATE;
    	else
    	    return apiRC;
    }
    
    $SELECT nname
       INTO $nupdate
       FROM officer
      WHERE iofficer = $iupdate;
    
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s %s %s %s %s",M_CM_OK,fclass,qperiod,pfactor,drate,iupdate,nupdate,dupdate);
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

 errexit:
  if(exitsub(reply,SQLCODE) == True)
      return SQLCODE;
  else
      return apiRC;
}

/*-----------------------------------------------------------------*/
long car166_multiple_query(reply)
serverReply reply;
{
	$char DBName[5];
	$char fclass[7],qperiod[4],pfactor[16],c_drate[8],drate[11];
	$char stmt[512],stmt_fclass[64],stmt_qperiod[64],stmt_drate[64];
	
	char tmpbuf[4000];
	int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
	int i,total_count=0;
	
	printf("-----multiple query-----\n");
	cm_buf_get("%s %s %s %s" ,DBName,fclass,qperiod,c_drate);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
		    return M_CM_DB_NOTOPEN;
		else
		    return apiRC;
	}
	
	if (strcmp(trim(fclass),"*") == 0)
	    sprintf_s(stmt_fclass, sizeof stmt_fclass, " WHERE fclass matches '*' ");
	else
	    sprintf_s(stmt_fclass, sizeof stmt_fclass, " WHERE fclass = '%s'",fclass);
	    
	if (strcmp(trim(qperiod),"*") == 0)
	    sprintf_s(stmt_qperiod, sizeof stmt_qperiod, " ");
	else
	    sprintf_s(stmt_qperiod, sizeof stmt_qperiod, " AND qperiod = '%s'",qperiod);
	
	if (strcmp(trim(c_drate),"*") == 0)
	    sprintf_s(stmt_drate, sizeof stmt_drate, " ");
	else
	{
	    strcpy(drate,  cm_to_infdate(c_drate));
	    sprintf_s(stmt_drate, sizeof stmt_drate, " AND drate = '%s'",drate);
	}
	
	sprintf_s(stmt, sizeof stmt, " SELECT fclass,qperiod,pfactor,drate "
                 " FROM short_period_day "
                 " %s %s %s ORDER BY fclass,qperiod"
                  ,stmt_fclass,stmt_qperiod,stmt_drate);
                    
    $PREPARE ply_data FROM $stmt;
    $DECLARE ply_cur CURSOR FOR ply_data;
    $OPEN    ply_cur;
    printf("stmt[%s]\n", stmt);
    
    for(;;) 
    {
    	$FETCH ply_cur INTO $fclass,$qperiod,$pfactor,$drate;
    	if (SQLCODE == SQLNOTFOUND) break;
 
    	cm_buf_init(tmpbuf);
    	 
    	if ( count == 0 )
     	{
      	  cm_buf_res_msg();             /* reserve for MsgCode and count */
      	  cm_buf_res_count();          
     	}
     	
    	cm_buf_put("%s %s %s %s",fclass,qperiod,pfactor,drate);
    	
        tmp_len = cm_buf_len(tmpbuf);
    	if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
    	{
    		memcpy(&ReplyBuf[repbuf_len], tmpbuf, tmp_len);
    		repbuf_len += tmp_len;
    		count++;
    	}
    	else                               /* more than 4K, send to client side */ 
    	{
    		cm_buf_init(ReplyBuf);
    		cm_buf_put_msg(M_CM_OK);
    		cm_buf_put_count(count);
    		
    		if (SendSyncReply(reply, ReplyBuf, repbuf_len, api_OK)==False)
    		{
    			$CLOSE ply_cur;
    			return apiRC;
    		}
    		else               /* clear ReplyBuf and count to start all over again */
    		{
    			replycnt++;
    			if (replycnt == 10)   /* more than 30K, client cannot display,error */
    			{
    				cm_buf_init(ReplyBuf);
    				cm_buf_put("%l", M_CM_OUT_SPACE);
    				tmp_len = cm_buf_len(ReplyBuf);
    				if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    				    return apiRC;
    				return M_CM_OUT_SPACE; 
    			}
    			
    			ReplyBuf[0] = '\0';
    			count = 0;
    			cm_buf_init(ReplyBuf);
    			cm_buf_res_msg();           /* reserve for MsgCode and count */
    			cm_buf_res_count();    
    			cm_buf_put("%s %s %s %s",fclass,qperiod,pfactor,drate);
    			repbuf_len = cm_buf_len(ReplyBuf);
    			count++;
    		}
    	} 
   } /* for loop */
   $CLOSE ply_cur;
   $FREE  ply_cur;

   if (count > 0)   /* break out, at least one record is selected */
   {
   	cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    
    if (SendSyncReply(reply, ReplyBuf, repbuf_len, api_OKComplete)==False)
        return apiRC;
        
    return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
    	if(exitsub(reply, M_CM_NOT_FOUND) == True) 
    	    return M_CM_NOT_FOUND;
    	else
    	    return apiRC;
    }

 errexit:
  if(exitsub(reply,SQLCODE) == True)
      return SQLCODE;
  else
      return apiRC;
}
/*-----------------------------------------------------------------*/
long car166_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	$char DBName[5];
	$char old_dupdate[20],userid[11],nname[10];
	$char fclass[7],qperiod[5],pfactor[16],c_drate[10],drate[11];
	$char old_fclass[7],old_qperiod[5],old_pfactor[16],old_drate[11];
	
	char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
	int tmp_len,raw_len;
	long dummy;
	long MsgCode;
	DBinfo *list;
	int i, j, is_del_fail=0, is_upd_fail=0;
	$char stmt_buf[512];
	
	printf("-----update-----\n");
	comm = (char *) command;
	cm_buf_init(command);
	cm_buf_get("%c %s",&option,DBName);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
		    return M_CM_DB_NOTOPEN;
		else
		    return apiRC;
	}
	
	if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
	{
		if(exitsub(reply,M_CM_NOT_DBLIST) == True)
		    return M_CM_NOT_DBLIST;
		return apiRC;
	}
	
	memcpy(&raw_len,&comm[com_len],sizeof(int));
	pos = &comm[com_len+sizeof(int)];
	raw_ptr = malloc(raw_len);
	if (raw_ptr != (char*)0)
	    memcpy(raw_ptr,pos,raw_len);
	else
	{
		if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
		    return M_CM_NOT_MALLOC;
		else
		    return apiRC;
	}
	
	cm_buf_init(raw_ptr);          /* get index key from old record */
	cm_buf_get("%l %s %s %s %s",&dummy,old_fclass,old_qperiod,old_pfactor,old_drate);
	cm_buf_get("%s %s %s",userid,nname,old_dupdate);	
	
	free(raw_ptr);
	
	$BEGIN WORK;
	
	$SELECT pfactor
	   INTO $pfactor
	   FROM short_period_day 
	  WHERE fclass = $old_fclass
	    AND qperiod = $old_qperiod
	    AND drate = $old_drate
	    AND dupdate = $old_dupdate;
	    
	/* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */ 
    if (SQLCODE == SQLNOTFOUND)
    {
    	MsgCode = M_CM_NOT_FOUND;
    	$WHENEVER SQLERROR CONTINUE;
    	$ROLLBACK WORK;
    	if( SQLCODE != 0) MsgCode = SQLCODE;
    	if(exitsub(reply,MsgCode) == True)
    	    return MsgCode;
    	else
    	    return apiRC;
    }

    if ( option == 'D' )
    {
    	printf("-----update->delete-----\n");
    	for(j=0;j<i;j++)
    	{
    		sprintf_s(stmt_buf, sizeof stmt_buf, " DELETE FROM %s:short_period_day "
    		                 " WHERE fclass = ? "
    		                 " AND qperiod = ? "
    		                 " AND drate = ? ",list[j].dbname); 
    		$PREPARE d_id FROM $stmt_buf;
    		
    		if(SQLCODE != 0)
    		{
    			is_del_fail = 1; 
    			break;
    		}
	
    		$EXECUTE d_id USING $old_fclass,$old_qperiod,$old_drate;
    		if(SQLCODE != 0)
    		{
    			is_del_fail = 1; 
    			break;
    		}
    		
    		#ifdef DEBUG 
    		printf("Delete %d\n", j+1);
    		#endif
    	}/* for loop */
    	
    	if( is_del_fail ) goto errexit;
    	
    	cm_buf_init(ReplyBuf);
    	cm_buf_put("%l",M_CM_OK);
    	tmp_len = cm_buf_len(ReplyBuf);
    	
    	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    	{
    		$WHENEVER SQLERROR CONTINUE;
    		$ROLLBACK WORK;
    		return apiRC;
    	}
    	
    	$WHENEVER SQLERROR GOTO errexit;
    	$COMMIT WORK;
    	return api_OKComplete;
    }
    else if ( option == 'U' )
    {
    	printf("-----update->update-----\n");
    	cm_buf_init(command);
    	cm_buf_get("%c %s %s %s %s %s %s %s",&option,DBName,fclass,qperiod,pfactor,c_drate,old_dupdate,userid);
    	strcpy(drate, cm_to_infdate(c_drate));
    	
    	$WHENEVER SQLERROR GOTO errexit;
   
    	for(j=0;j<i;j++)
    	{
    		sprintf_s(stmt_buf, sizeof stmt_buf, " UPDATE %s:short_period_day "
    		                 " SET (fclass,qperiod,pfactor,drate,iupdate,dupdate) "
    		                 " = (?,?,?,?,?,current) "
    		                 " WHERE fclass = '%s' "
    		                 " AND qperiod = '%s' "
    		                 " AND drate = '%s' "
    		                 " AND dupdate = '%s' "
    		                 ,list[j].dbname,old_fclass,old_qperiod,old_drate,old_dupdate);
	  	 
    		$PREPARE u_id FROM $stmt_buf;
    		if(SQLCODE != 0)
    		{
    			is_upd_fail = 1;
    			break;
    		}
    		
    		$EXECUTE u_id USING $fclass,$qperiod,$pfactor,$drate,$userid;
    		if(SQLCODE != 0)
    		{
    			is_upd_fail = 1;
    			break;
    		}
    		
    		if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
    		{
    			sprintf_s(stmt_buf, sizeof stmt_buf, " INSERT INTO %s:short_period_day "
    			                 " (fclass,qperiod,pfactor,drate,iupdate,dupdate) "
    			                 " VALUES (?,?,?,?,?,current)",list[j].dbname);
    			
    			$PREPARE ua_id FROM $stmt_buf;
    			if(SQLCODE != 0)
    			{
    				is_upd_fail = 1; 
    				break;
    			}
    			
    			$EXECUTE ua_id USING $fclass,$qperiod,$pfactor,$drate,$userid;
    			if(SQLCODE != 0)
    			{
    				is_upd_fail = 1; 
    				break;
    			}
    		}
    		
    		#ifdef DEBUG 
    		printf("Update %d\n", j+1);
    		#endif
    	} /* for loop */
    	
    	if( is_upd_fail ) goto errexit;
    	
    	cm_buf_init(ReplyBuf);
    	cm_buf_put("%l",M_CM_OK);
    	tmp_len = cm_buf_len(ReplyBuf);
    	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    	{
    		$WHENEVER SQLERROR CONTINUE;
    		$ROLLBACK WORK;
    		return apiRC;
    	}
    	
    	$WHENEVER SQLERROR GOTO errexit;
    	$COMMIT WORK;
    	return api_OKComplete;
    }
    else
    {
    	if(exitsub(reply,M_CM_WRONG_OPTION) == True)
    	    return M_CM_WRONG_OPTION;
    	else
    	    return apiRC;
    }

 errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
}
/*-----------------------------------------------------------------*/
