/**********************************************************************/
/*   program id   : ca215q01s.ec                                      */
/*   program name : �����ʲz�j��O�I�Ҹ�ƶפJ/�ץX�@�~               */
/*   date written : 2014/06/18                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : Larry Liao                                        */                                       
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "safeclib.h"
/****************************************************************************/
$char DBName[05],userid[11],GetFile[128];
$char dcreate_bgn[11],dcreate_end[11];
$char sDcreate_bgn[11],sDcreate_end[11];
$char iissue_comp[3],iofficer[11];
$char date[11],dToday[11],nyy[4],nmm[3],ndd[3];
$char errmsg[10000],errmpt1[100];
int   errcnt;
FILE  *fp, *fp1, *sfp;
$char sdata[4][121];
char msgbuf[2048],sApHome[30];
/* char  actiontype[2], v_sMsg[1024]; */
char  actiontype[2], v_sMsg[1024], v_sMsg2[11024];
char  file_name[128], filename[200],outputf[N_FILE+1];
int   qcount,cnt_status,cnt_err,count_db,i,flen;
long  t = 0;
/****************************************************************************/
main(argc, argv)
int argc;
char **argv;
{  
	int rc;

	batchinit();
	strcpy(DBName, 		  isNULLstr(argv[1]));
	strcpy(userid, 		  isNULLstr(argv[2]));
	strcpy(actiontype,  isNULLstr(argv[3]));  /* 0�G�פJ�ɮ�, 1�G�ץX����(����϶�),2�G�ץX����(���j���Ҹ���), 
	                                             3 : �ץX����(�����ʲz����J����϶�) */	                                          
	strcpy(dcreate_bgn, isNULLstr(argv[4]));
	strcpy(dcreate_end, isNULLstr(argv[5]));
	strcpy(file_name,   isNULLstr(argv[6]));
	strcpy(GetFile,     isNULLstr(argv[7]));
	strcpy(iissue_comp,isNULLstr(argv[8]));
	strcpy(iofficer,   isNULLstr(argv[9]));
	strcpy(outputf,     isNULLstr(argv[10]));
	
	printf("-- actiontype[%s], GetFile[%s]\n",actiontype,GetFile);
	printf("-- ���:[%s] ~ [%s]\n",dcreate_bgn,dcreate_end);
	
	sfp =  (FILE *)STARTLOG();
		
	rc = car215_get_db();
	if (rc != M_CM_OK) {
		EWRITE(userid,rc,msgbuf);
		return rc;
	}
  
  if (strncmp(actiontype,"0",1) == 0)
  {
        errcnt = 0;
	    strcpy(errmsg,"\t���O\t�O�I�Ҹ�\t��J���\tñ�污��\t�s�w���ɤ��\n");	
        rc = car215_read_data();
        if (rc != M_CM_OK) 
        {
    		    EWRITE(userid, rc, "�ɮ���J���~!");
    		    return rc;
    	}
    	else
        {
            printf("=============================> RETURN SUCCESS\n");
            sprintf_s(v_sMsg, sizeof v_sMsg, "\n�ɮצW�١G%s\n"
                             "�����ʲz�j������J���ơG%d\n"
                             "�@�o���A�ॼ�X���ơG%d\n"
                             "�����ʲz�j���Ҳ��ʧO(�R��)�Υ��ѵ��ơG%d\n"
                             "�i���ɮפU���@�~(cmn202)�U�����ʧO(�R��)�Υ��ѩ���\n\n"
                             , file_name, qcount, cnt_status, cnt_err);
            if (errcnt > 0)
            {                                
                sprintf_s(v_sMsg2, sizeof v_sMsg2,"%s\n\n\n�U�C���D�����q�d��,�@ %d ��, �C�ܦp�U: \n\n %s",v_sMsg,errcnt,errmsg);
            }
            else
            {
                sprintf_s(v_sMsg2, sizeof v_sMsg2,"%s",v_sMsg);
            }
            /* WRITELOG( sfp, v_sMsg); */
            WRITELOG( sfp, v_sMsg2);
            ENDLOG(sfp);       
        }
    }
	else
	{
		/* 1.2 - �פJ���, 2 - ���(�j���ҥd��)�� �d�߱j���ҫO�d���A(���ʫe)���� */    
        rc = car215_init_data();
        if (rc != M_CM_OK) {
            printf("error on car215_init_data\n");
    		    EWRITE(userid,rc,"�إ� temp table ���~!");
    		    return rc;
    	}
		
        if (strncmp(actiontype,"2",1) == 0)
        {           	  		  
		    rc = car215_read_card();
            if (rc != M_CM_OK) {
      	        printf("error on car215_read_card\n");
		        EWRITE(userid, rc, "�ɮ���J���~!");
		        return rc;
	        }	   	    
		}
		
		rc = car215_query_detail();
        if (rc != M_CM_OK) {
    	  printf("error on car215_query_detail\n");
		    EWRITE(userid, rc, "�d�ߩ��Ӹ�Ʀ��~");
		    return rc;
	    }
	  
	    rc = car215_print_detail();
        if (rc != M_CM_OK) {
            printf("error on car215_print_detail\n");
            EWRITE(userid, rc, "�������Ӳ��s���~!");
            return rc;
        }    
	}
			
  return rc;
}
/******************************************************************************/
long car215_read_data()
{
    char  *bp;    
    char  fname[128], filepath[256];
    int   rc, i, j, k, m, n;
    
		printf("BEGIN TO READ DATA\n");    

    $WHENEVER SQLERROR GOTO errexit;
    
            
    sprintf_s(fname, sizeof fname,"car215_���ʧO�Υ��ѩ���[%s%s%s].txt",nyy,nmm,ndd);
    sprintf_s(filepath, sizeof filepath,"%s/rptftp/%s",sApHome,fname);
    printf("[%s]\n",filepath);
    fp1=fopen(filepath,"w");

    strcpy(GetFile, trim(GetFile));
    sprintf_s(filename, sizeof filename,"%s/dat/car/%s",sApHome,GetFile);
    flen=1024;
    if ((fp=fopen(filename,"r"))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���",filename);
       EWRITE(userid,FALSE,msgbuf);
       return FALSE;
    }
    if ((bp=malloc(flen))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"System malloc failed !");
       EWRITE(userid,FALSE,msgbuf);
       free(bp);
       return FALSE;
    }
     /* ��J�ɥ��s�W ñ�污��(fstatus:Y �wñ��, N ��ñ��) add by sylvia 106.05.18 (1060414006_C1�B1060505005_C1) */
	  qcount=cnt_status=cnt_err=0;	
	  for (i=0;(feof(fp)==0);i++) 
		{
		  memset(bp,0x00,flen);
		  fgets(bp,flen,fp);
		        
		  if (bp[0]==0x00)	break;
		  if (strlen(trim(bp))<10)	break;
		        	
		  for(j=0;j<4;j++)
		   sdata[j][0]='\0';
		            
		  strcpy(sdata[0],substring(bp,1,1));
		  strcpy(sdata[1],substring(bp,2,17));
		  strcpy(sdata[2],substring(bp,19,8));
		  strcpy(sdata[3],substring(bp,27,1));
		  
		  printf("sdata[%s][%s][%s][%s]\n",sdata[0],sdata[1],sdata[2],sdata[3]);
		  if (sdata[0][0]=='\0') continue;
		        
		  rc = car215_insert_data();
		  if (rc != M_CM_OK)
		  {
		  	 cnt_err++;
		  	 fprintf(fp1,"�j���Ҹ��G%s\t��J����\n", sdata[1]);		     
		     continue;
		  }
		  if (strncmp(sdata[0],"1",1) == 0) {
		  	 cnt_err++;
		  	 fprintf(fp1,"�j���Ҹ��G%s\t���ʧO���i�R���j\n", sdata[1]);
		  }
		  qcount++;		  
		}
		   	 	      
    fclose(fp);
    fclose(fp1);
    
    rc=rptftpinsert(userid,"car215",fname);
    if (rc != 0) return rc;
   
    return M_CM_OK;

errexit:
    printf("--car215_read_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car215_insert_data()
{
    $char ftype[2], icard[21], dentry[11];
    $char sDentry[11];
    $char ilast_card[21], flast_status[2];
    $char ilast_alter[11], dlast_alter[11], road_status[2], road_card[21],
          strans_date[25];
    
    $WHENEVER SQLERROR GOTO errexit; 
    
    $BEGIN WORK;
    strcpy(ftype,  trim(sdata[0]));
    strcpy(icard,  substring(trim(sdata[1]), 3, 15));
    strcpy(dentry, trim(sdata[2]));
        
    strcpy(sDentry, substring(dentry,5,2));
    strcat(sDentry,"/");
    strcat(sDentry, substring(dentry,7,2));
    strcat(sDentry,"/");
    strcat(sDentry, substring(dentry,1,4));
    
    strcpy(road_card,trim(sdata[1]));
    strcpy(road_status, trim(sdata[3]));
    
    printf("--> ftype[%s], icard[%s]\n", ftype, icard);
    printf("--> dentry[%s], sDentry[%s]\n", dentry, sDentry); 
    
    /* �ƫD�����q����ƦC�ܦbcmn201 add by sylvia 106.05.16  */
     strcpy(strans_date,cm_get_sysd( ));
        
    /* ���ʧO���i9:�s�W�j�A�N��Ʈw�O�d���A�@�o(3,4,8,A,B,C,D) -> ���X(5,6) */
    if (strncmp(ftype,"9",1) == 0)
    {   printf("252--- road_card=[%s][%d]\n",road_card,strncmp(road_card,"17",2));
        if (strncmp(road_card,"17",2) != 0)
        {
            strcpy(errmpt1,"");
            
            $INSERT INTO ca_card_road
              VALUES ($ftype, $road_card, $sDentry, 'w', ' ', null, $userid, current,$road_status);
              
            /*�O������ & �C�X���� add by sylvia 106.05.16  */
            errcnt = errcnt+1;
            sprintf_s(errmpt1, sizeof errmpt1,"\t %s\t %s\t %s\t %s\t\t%s\n",ftype,road_card,sDentry,road_status,strans_date);
            strcat(errmsg,errmpt1);
            printf("262:errcnt[%d]errmsg=[%s]\n",errcnt,errmsg);
        }
        else
        {
            $SELECT icard, fstatus, ialter, dalter
               INTO $ilast_card, $flast_status, $ilast_alter, $dlast_alter
               FROM compulsory_card
              WHERE icard = $icard;
            if (SQLCODE == SQLNOTFOUND){
                 /* ��藍���,�����D�����q�d��,�g�J�d�����X(�t���q�N��),�e�O�檬�A='w' 
                   modify by sylvia 106.05.18 (1060414006_C1�B1060505005_C1) */
                   
                /* $INSERT INTO ca_card_road
                  VALUES ($ftype, $icard, $sDentry, ' ', ' ', null, $userid, current); */
                  
                $INSERT INTO ca_card_road
                  VALUES ($ftype, $road_card, $sDentry, 'w', ' ', null, $userid, current,$road_status);
                  
                /*�O������ & �C�X���� add by sylvia 106.05.16  */
                errcnt = errcnt+1;
                sprintf_s(errmpt1, sizeof errmpt1,"\t %s\t %s\t %s\t %s\t\t%s\n",ftype,road_card,sDentry,road_status,strans_date);
                strcat(errmsg,errmpt1);
                printf("258:errcnt[%d]errmsg=[%s]\n",errcnt,errmsg);
            }
            else
            {   
            	  /* �O�d���A:�@�o�i3,A,B,C,D�j -> �@�o�ܥ��X�i5�j */
                if ((strncmp(flast_status,"3",1) == 0) || (strncmp(flast_status,"A",1) == 0) ||
                	  (strncmp(flast_status,"B",1) == 0) || (strncmp(flast_status,"C",1) == 0) ||
                	  (strncmp(flast_status,"D",1) == 0)){
                	  	
                	  printf("----- ����:�@�o[%s] -> �@�o�ܥ��X[5]\n", flast_status);
                	  
                	  cnt_status++;
                	  $UPDATE compulsory_card
                        SET (fstatus, ialter, dalter, fcancel, icard_repeat)
                          = ('5'    , $userid, current, 'Y', ' ')
                      WHERE icard = $ilast_card
                        AND fstatus in ('3','A','B','C','D')
                        AND trim(ipolicy) = '';                          	              	  	
                }
                else if ((strncmp(flast_status,"4",1) == 0) || (strncmp(flast_status,"8",1) == 0))
                {   
                    /* �O�d���A:�򥢡i4,8�j -> ���ܥ��X�i6�j */         	 
               	    printf("----- ����:��[%s] -> ���ܥ��X[6]\n", flast_status);
               	    
                	  cnt_status++;
                	  $UPDATE compulsory_card
                        SET (fstatus, ialter, dalter, fmiss)
                          = ('6'    , $userid , current, 'Y' )
                      WHERE icard = $ilast_card
                        AND fstatus in ('4','8')
                        AND trim(ipolicy) = '';                            	  
                }
                else
                {
                	  printf("----- �O�d���A[%s]\n", flast_status);
                    $INSERT INTO ca_card_road
                      VALUES ($ftype, $icard, $sDentry, ' ', ' ', null, $userid, current,$road_status);
                }
                
                /* �O���O�d���ʫe�����A(3,4,8,A,B,C,D), �g�Jca_card_road */
                if ((strncmp(flast_status,"0",1) != 0) && (strncmp(flast_status,"1",1) != 0) &&
                	  (strncmp(flast_status,"2",1) != 0) && (strncmp(flast_status,"5",1) != 0) &&
                	  (strncmp(flast_status,"6",1) != 0) && (strncmp(flast_status,"7",1) != 0)){
                	  
                    $INSERT INTO ca_card_road
                      VALUES ($ftype, $icard, $sDentry, $flast_status,
                              $ilast_alter, $dlast_alter, $userid, current,$road_status);
                    }            	            	            
            }
        }
    }
    else
    {
    	  /* ���ʧO���i1:�R���j�ɡA�����g�Jca_card_road, ��Ʈw�O�d���A�������󲧰� */
        $INSERT INTO ca_card_road
              VALUES ($ftype, $icard, $sDentry, ' ', ' ', null, $userid, current,$road_status);   	
    }
    
    $COMMIT WORK;
    		
    return M_CM_OK;

errexit:
    printf("--car215_insert_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    $rollback work;
    return SQLCODE; 
}
/******************************************************************************/
long car215_init_data()
{   
    $WHENEVER SQLERROR GOTO errexit;
         	  	   
	  $create temp table car215_tmp(
	  	  nchi_full         char(40),  /*���*/
	  	  icard             char(20),  /*�O�I����*/
	  	  dissue            char(9),   /*�ӻ��*/
	  	  ndissue           char(10),  /*�ӻ�H*/
	  	  dreceive          char(9),   /*�������*/
	  	  icar_type         char(2),   /*����*/
	  	  fstatus           char(20),  /*���ʪ��A*/
	  	  ipolicy           char(20),  /*�O�渹�X*/
	  	  ideliver          char(10),  /*�t�o�g��H*/
	  	  ndeliver          char(10),  /*�g��H*/
	  	  nleader           char(10),  /*�t�o�g��H�̷s�޲z�H*/
	  	  ileader           char(10),  /*�t�o�g��H�̷s�޲z�H�N��*/
	  	  ddeliver          char(9),   /*�t�o���*/
	  	  dalter            char(9),   /*���ʤ��*/
	  	  ialter            char(10),  /*���ʤH�N��*/
	  	  nalter            char(10),  /*���ʤH��*/
	  	  bh_ialter         char(40),  /*���ʤH�����*/
	  	  ftype             char(4),   /*���ʧO*/
	  	  dentry            char(11),  /*�����ʲz����J���*/
	  	  dcreate           char(11),   /*�s�w�פJ���*/
	  	  road_status       char(1)     /* ñ�污�� */
	  )with no log;
	  
	  if (strncmp(actiontype,"2",1) == 0)
	  {
	    $create temp table car215_card(
	        icard             char(20)   /* �j���Ҹ� */
	    )with no log;
	  }
	    
	  return M_CM_OK;

errexit:
    printf("--car215_init_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car215_read_card()
{
    char   *bp;
    int    rc,j,k,m,n,i;
    $int   iChkDays;
    $char  icard[21];
    
		printf("BEGIN TO READ DATA\n");    

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(GetFile, trim(GetFile));
    sprintf_s(filename, sizeof filename,"%s/dat/car/%s",sApHome,GetFile);
    flen=1024;
    if ((fp=fopen(filename,"r"))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���",filename);
       EWRITE(userid,FALSE,msgbuf);
       return FALSE;
    }
    if ((bp=malloc(flen))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"System malloc failed !");
       EWRITE(userid,FALSE,msgbuf);
       return FALSE;
    }

    for (i=0;(feof(fp)==0);i++) 
	  {
		    memset(bp,0x00,flen);
		    fgets(bp,flen,fp);
		    printf("bp[%s]\n",bp);
		    if (bp[0]==0x00)	break;
		    if (strlen(trim(bp)) < 10)	break;
	
		    for(j=0;j<10;j++)
		    sdata[j][0]='\0';
		            
		    k=m=n=0;
		    for (j=0;j<flen;j++) 
		    {
		        if (bp[j]=='\0' || bp[j]=='\n' || bp[j] == ',' || bp[j] == '\t') 
					  {
		            strncpy(sdata[k],bp+m,j-m);
		            sdata[k][j-m]='\0';
		            m=j+1;
		            k++;
		        }
		        if (bp[j]=='\n'|| bp[j]=='\n' || bp[j] == ',' || bp[j] == '\t')	break;
		        if (k > 0) break;
		    }      
		    strcpy(icard,trim(sdata[0]));

		    if (strlen(icard) == 0) break;

		    rc = car215_insert_card();
		    if (rc != M_CM_OK)  return M_CM_FORMAT;
		}
		    
    fclose(fp);	 
    return M_CM_OK;

errexit:
    printf("--car215_read_card-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car215_insert_card()
{
    $char sIcard[21],iIcard[21];
    $int  comp_cnt,card_cnt;
    
    $WHENEVER SQLERROR GOTO errexit;

	  strcpy(iIcard,sdata[0]);
	  if (strncmp(iIcard,"17",2) == 0)
	  {
	  	 strcpy(sIcard,substring(iIcard,3,18));
	  }
	  else
	  {
	  	 strcpy(sIcard,trim(iIcard));
	  }

	  printf("-- insert icard[%s]\n",sIcard);
	  $INSERT INTO car215_card VALUES($sIcard);
	 
	  return M_CM_OK;  
	  
errexit:
    printf("--car215_insert_card-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car215_query_detail()
{
   int	rc;
   $char sStmt[8000],sTmp[256];
   $varchar sNchi_full[41],sIalter_bh[41];
   $char sIcard[21],sDissue[11],sNdissue[21],sDreceive[11];
   $char sIcar_type[11],sFstatus[20],sIpolicy[21],sIdeliver[21],sNdeliver[21];
   $char sIleader[11],sNleader[21],sDdeliver[11],sDalter[11],sIalter[21];
   $char sNalter[21],sIbranch[3],fstatus[3];
   $char dissue[11],dreceive[11],ddeliver[11],dalter[11];
   $char dentry[11],dcreate[11],sDentry[11],sDcreate[11],sFtype[5];
   $char sIissue_comp[3],sIofficer[11], road_status[2];
   $int  sCover;
   
   $WHENEVER SQLERROR GOTO errexit;
   
   strcpy(sIissue_comp,trim(iissue_comp));
   strcpy(sIofficer,trim(iofficer));
   
   if (strncmp(actiontype,"1",1) == 0)
   {   	   
         strcpy(sDcreate_bgn, cm_to_infdate(dcreate_bgn));
    	 strcpy(sDcreate_end, cm_to_infdate(dcreate_end));
    	 printf("���:[%s]~[%s]\n", sDcreate_bgn, sDcreate_end);
    	 sprintf_s(sTmp, sizeof sTmp," AND date(b.dcreate) >= '%s' "
    	              " AND date(b.dcreate) <= '%s' "
    	              " AND (((SELECT ibranch FROM officer WHERE iofficer = a.ideliver) matches '%s') OR a.iissue_branch matches '%s')    "
    	              " AND a.iofficer matches '%s'  ", sDcreate_bgn, sDcreate_end,sIissue_comp,sIissue_comp,sIofficer);
   }
   else if (strncmp(actiontype,"3",1) == 0)
   {
   	 strcpy(sDcreate_bgn, cm_to_infdate(dcreate_bgn));
    	 strcpy(sDcreate_end, cm_to_infdate(dcreate_end));
    	 printf("�����ʲz����J���:[%s]~[%s]\n", sDcreate_bgn, sDcreate_end);
    	 sprintf_s(sTmp, sizeof sTmp," AND date(b.dentry) >= '%s' "
    	              " AND date(b.dentry) <= '%s' "
    	              " AND (((SELECT ibranch FROM officer WHERE iofficer = a.ideliver) matches '%s') OR a.iissue_branch matches '%s')   "
    	              " AND a.iofficer matches '%s' ", sDcreate_bgn, sDcreate_end,sIissue_comp,sIissue_comp,sIofficer);
   }
   else
   {
   	   strcpy(sTmp, " AND b.icard in (SELECT icard FROM car215_card)");
   }
   
   sprintf_s(sStmt, sizeof sStmt,"SELECT (SELECT nchi_full FROM branch WHERE ibranch = a.iissue_branch) as nchi_full,"
                "        a.icard, a.dissue, a.iofficer, a.dreceive, a.icar_type, "
                "        decode(b.flast_status,'3','�@�o','4','��','8','������', "
                "               'A','µ�����~�Φ��l','B','���Ƨ�O', "
                "               'C','�ܺʲz����ӥ��L','D','���ϥΧ@�o',' '), "
                "        a.ipolicy, a.ideliver, "
                "       (SELECT nname FROM officer WHERE iofficer = a.ideliver), "
                "       (SELECT ileader FROM officer WHERE iofficer = a.ideliver) as ileader, "
                "        a.ddeliver, b.dlast_alter, b.ilast_alter, "
                "       (SELECT nname FROM officer WHERE iofficer = b.ilast_alter), "
                "       (SELECT ibranch FROM officer WHERE iofficer = b.ilast_alter), "
                "        decode(b.ftype,'9','�s�W','1','�R��',' '), b.dentry, date(b.dcreate),b.fstatus "
                "  FROM compulsory_card a, ca_card_road b"
                " WHERE a.icard = b.icard %s", sTmp);
                
    printf("Query_detail - stmt[%s]\n",sStmt);
    $PREPARE tempcur FROM $sStmt;
    $DECLARE card_cur CURSOR FOR tempcur;
    $OPEN    card_cur;
    
    for(;;)
    {  
        $FETCH card_cur INTO $sNchi_full,$sIcard,$sDissue,$sNdissue,$sDreceive,
                             $sIcar_type,$sFstatus,$sIpolicy,$sIdeliver,$sNdeliver,
                             $sIleader,$sDdeliver,$sDalter,$sIalter,$sNalter,
                             $sIbranch,$sFtype,$sDentry,$sDcreate,$road_status;
        if (SQLCODE==SQLNOTFOUND) break;
        	
        strcpy(dissue,  cm_from_infdate_100(sDissue));
        strcpy(dreceive,cm_from_infdate_100(sDreceive));
        strcpy(ddeliver,cm_from_infdate_100(sDdeliver));
        strcpy(dalter,  cm_from_infdate_100(sDalter));
        strcpy(dentry,  cm_from_infdate_100(sDentry));
        strcpy(dcreate, cm_from_infdate_100(sDcreate));
        
        $SELECT nname INTO $sNleader
           FROM officer
          WHERE iofficer = $sIleader;
        if (SQLCODE == SQLNOTFOUND) strcpy(sNleader," ");
                       
        $SELECT nchi_full INTO $sIalter_bh
           FROM branch
          WHERE ibranch = $sIbranch;
        if (SQLCODE == SQLNOTFOUND) strcpy(sIalter_bh," ");
        	
        $INSERT INTO car215_tmp
            VALUES($sNchi_full,$sIcard,$dissue,$sNdissue,$dreceive,
                   $sIcar_type,$sFstatus,$sIpolicy,$sIdeliver,$sNdeliver,
                   $sNleader,$sIleader,$ddeliver,$dalter,$sIalter,$sNalter,
                   $sIalter_bh,$sFtype,$dentry,$dcreate,$road_status);
	
	  }
	  $CLOSE card_cur;
    $FREE  card_cur; 
    
    return M_CM_OK;
  
errexit:
    printf("--car215_query_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car215_print_detail()
{
    int     rc;
    char    sfilename[128],stitle[2048],stmt[2048];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"�����ʲz�j���ҧ@�o���A(���ʫe)���Ӫ�");
    strcpy(stitle,"�{���N��:CAR215\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t\t\t\t\t\t\t\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(sfilename,"[CAR215]");

    strcat(stitle,"\t���\t�O�I�Ҹ�\t�ӻ��\t�ӻ�H\t�������\t����\t");
    strcat(stitle,"���ʪ��A\t�O�渹�X\t�t�o�g��H\t�g��H\t�޲z�H\t");
    strcat(stitle,"�޲z�H�N��\t�t�o��\t���ʤ��\t���ʤH�N��\t���ʤH��\t");
    strcat(stitle,"���ʤH���\t���ʧO\t�����ʲz����J���\t�O�o�j���I��Ʈwñ�污��\t");
    strcat(stitle,"�s�w�פJ���\t");

    strcpy(stmt,"SELECT nchi_full,icard,dissue,ndissue,dreceive,icar_type, "
                "       fstatus,ipolicy,ideliver,ndeliver,nleader,ileader, "
	  	          "       ddeliver,dalter,ialter,nalter,bh_ialter,ftype,     "
	  	          "       dentry, road_status, dcreate " 
                "   FROM car215_tmp "
                "  ORDER BY icard ");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
    
errexit:
    printf("--car215_print_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car215_get_db()
{
	int return_code;
	
	$WHENEVER SQLERROR GOTO errexit;
	
	t = cm_today();
  strcpy(date,cm_edate_str(t));  
  strcpy(dToday,cm_from_infdate_100(date));
  cm_split_ymd_100(dToday,nyy,nmm,ndd);

	if (db_select(DBName) == False) {
		strcpy(msgbuf,"��Ʈw�L�k�}��");
		return M_CM_DB_NOTOPEN;
	}
	return_code = getApHome(sApHome);
	if (return_code < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return return_code;
  }  
  return M_CM_OK;

errexit:
   printf("--car215_get_db-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/