/**********************************************************************/
/*   program id   : ca608p01s.ec                                      */
/*   program name : �M�׾����O�@�~                                  */
/*   date written : 2004/04/23                                        */
/*   date modify  : 2004/04/30 �W�[�ѧK��ΥN���O�Ω���               */
/*   author       : Jessie Leng                                       */
/*   files        : policy              io                            */
/*   input        : car608_yymmdd.txt                                 */
/**********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "print.h"
#include "ISconstant.h"
#include "ISvar.h"
#include "safeclib.h"
/*--------------------------------------------------------------------*/
char    sApHome[30];
$char   fname[21];
char    filename[50];
char    msgbuf[1000];
$char   DBName[05];
char    userid[11],outputf[21];

$int    inote,itype,iply,iopt;
$char   ipolicy[21],cnote[3],dchk_date[11],ctype[2],cply[2],copt[2];
DBinfo *list;
int     count_db;

/*--------------------------------------------------------------------*/
main(argc,argv)
int   argc;
char  **argv;
{
int   rc;
long  sysdt;

   batchinit();

   strcpy(DBName,isNULLstr(argv[1]));
   strcpy(userid,isNULLstr(argv[2]));
   strcpy(cnote, isNULLstr(argv[3]));   /* ���O�N�� */
   strcpy(ctype, isNULLstr(argv[4]));   /* 0:�ˮֲM�� 1:���O�g�J 2:�ѧK��ΥN���O�Ω��� 3:�������O */
   strcpy(cply,  isNULLstr(argv[5]));   /* 0:�O�渹 1:�d�� */
   strcpy(copt,  isNULLstr(argv[6]));   /* 0:��� 1:�浧 */
   strcpy(ipolicy,  isNULLstr(argv[7]));    /* �浧�O�渹 */
   strcpy(outputf,isNULLstr(argv[8]));

   sysdt=cm_today();
   strcpy(dchk_date,cm_edate_str(sysdt));
   
printf("dchk_date[%s]\n",dchk_date);

   inote = atoi(cnote);
   itype = atoi(ctype);
   iply  = atoi(cply);
   iopt = atoi(copt);
   strcpy(ipolicy, trim(ipolicy));
   printf("-- 66 --- ipolicy=[%s]\n", ipolicy);
   
   rc=car608_get_db();
   if (rc!=M_CM_OK)
      return rc;

printf("before read_data\n");
   if (iopt == 0)
   {
        rc=car608_read_data();
   }
   else
   {
        rc=create_temp_table();
        rc=insert_temp_table();
   }
   if (rc!=M_CM_OK)
      return rc;
printf("after read data\n");      

   if (itype == 0) { /* �ˮֲM�� */
printf("before write_text\n");   
      rc=car608_write_text();
      if (rc!=M_CM_OK)
         return rc;
printf("after write_text\n");        
   }
   else if (itype == 1) { /* �g�J���O */
 printf("before update data\n"); 
      rc=car608_update_data();
      if (rc!=M_CM_OK)
         return rc;
printf("after update data\n");          
      EWRITE(userid,rc,msgbuf);      
   }
   else if (itype == 2) { /* �ѧK��ΥN���O�Ω��� */
printf("before data_for17\n");   
      rc=car608_data_for17();
      if (rc!=M_CM_OK)
         return rc;
printf("after data_for17\n");           
   }
   else if (itype == 3) { /* �������O */
printf("before clear_data\n");   
      rc=car608_clear_data();
      if (rc!=M_CM_OK)
         return rc;
printf("after clear_data\n");            
      EWRITE(userid,rc,msgbuf);
   }
      
   return rc;

}
/*--------------------------------------------------------------------*/
long car608_get_db()
{
int   rc;
char  s[15],s1[4],s2[3],s3[3];

   $whenever sqlerror goto errexit;

   rc = getApHome(sApHome);
   if (rc<0) {
      strcpy(msgbuf,"read Config file error!!-->getApHome\n");
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   strcpy(s,cm_from_infdate_100(dchk_date));
   cm_split_ymd_100(s,s1,s2,s3);
   sprintf_s(fname, sizeof fname,"car608_%s%s%s.txt",s1,s2,s3);
   strncpy(filename," ",40);
   sprintf_s(filename, sizeof filename,"%s/dat/car/", sApHome);
   strcat(filename,fname);

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ((list = get_db_list (&count_db, DBName)) == (char *) 0)
   {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == True)
          return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;

errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car608_read_data()
{
int   flen,fg,rc;
FILE  *fp;
char  *bp,scnt[5];
int   i,j,icnt,k,m,h = 0;

   flen=80;

   $whenever sqlerror goto errexit;
   
printf("step1,filename[%s]\n",filename);
   if ((fp=fopen(filename,"r"))==NULL) {
      sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���\n",filename); 
      EWRITE(userid,FALSE,msgbuf);      
      return FALSE;
   }
printf("step2\n");   
   if ((bp=malloc(flen))==NULL) {
      sprintf_s(msgbuf, sizeof msgbuf,"System malloc failed !");
      EWRITE(userid,FALSE,msgbuf);
      free(bp);
      return FALSE;
   }
printf("step3\n");
   rc=create_temp_table();
printf("step4\n");   
   for(i=0;(feof(fp)==0);i++) {
      memset(bp,0x00,flen);
      fgets(bp,flen,fp);
      if (bp[0]==0x00)
         break;
      null_alldata();
      k=m=0;
      for (j=0;j<flen;j++) {
          if (bp[j]=='\t' || bp[j]=='\0' || bp[j]=='\n') {
          	h = j - m; 
          	if(h < sizeof(ipolicy) && h >= 0)
          	{
			strncpy(ipolicy,bp+m,h);
			ipolicy[h]='\0';
			m=j+1;
			k++;
		}
          }
          if (bp[j]=='\n')
              break;
          if (k > 0) break;
      }      
      rtrim_alldata();
      if (ipolicy[0]=='\0') continue;
      rc=insert_temp_table();
      if (rc!=M_CM_OK)
         return rc;
   }
printf("step5\n");
        
   fclose(fp);
printf("step6\n");
   sprintf_s(msgbuf, sizeof msgbuf,"�B�z����[%d]",i);
   return M_CM_OK;
errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car608_update_data()
{
$char    stmt[200],full_db[41];
int      i;
$char    nequipment[31];
$char    nequipment_s[31];
$char    cnote[3];

   $whenever sqlerror goto errexit;
   $begin work;

   i=0;
   $declare cur1 cursor for
    select ipolicy
      into $ipolicy
      from car608;
   $open cur1;
   
   while(1) {
      $fetch cur1;
      if (SQLCODE==SQLNOTFOUND)
         break;
      i++;
      strcpy(full_db,get_car_full_db(ipolicy));
      sprintf_s(stmt, sizeof stmt,
      " select nequipment         "
      "   from %s:policy          "
      "where ipolicy = '%s' ",full_db,ipolicy);
      $prepare get_nequip from $stmt;
      $execute get_nequip into $nequipment;
      strcpy(cnote,itoa(inote));
      strcpy(nequipment_s,equip_insert(nequipment,cnote));

      sprintf_s(stmt, sizeof stmt,"update %s:policy set nequipment = '%s'  "
               "where ipolicy = ? ",full_db,nequipment_s);
       printf("--- 256 ---stmt=[%s]\n nequipment_s=[%s]\n ipolicy=[%s]\n",stmt,nequipment_s,ipolicy);
      $prepare pre_upd from $stmt; 
      $execute pre_upd using $ipolicy;
   }
   $close cur1;
   $free  cur1;

   sprintf_s(msgbuf, sizeof msgbuf,"%s,��ﵧ��[%d]",msgbuf,i);
   $commit work;
   return M_CM_OK;
errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   $whenever sqlerror continue;
   $rollback work;
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car608_write_text()
{
char  sfilename[41],stitle[200],stmt[1024];
$char stmt1[1024];
int   rc,j;
int   iflag;
char  n1[2],n2[2],n3[2],n4[2];

   $whenever sqlerror goto errexit;

   $create temp table car608_text
   (ipolicy    char(20),
    iengine    char(20),
    dpolicy    date,
    iofficer   char(10),
    nname      char(10),
    nequipment char(1))
    with no log;

   strcpy(sfilename,"���O�ˮ֩��Ӫ�");
   strcpy(stitle,"�O�渹�X\t�������X\tñ����\t�g��N��\t�g��W��\t���O\n");

   iflag = (inote - 1) % 30 + 1;
   if (inote <= 30)
   {
      strcpy(n1,"1");
      strcpy(n2,"3");
      strcpy(n3,"5");
      strcpy(n4,"7");
   }
   else if (inote <= 60)
   {
      strcpy(n1,"2");
      strcpy(n2,"3");
      strcpy(n3,"6");
      strcpy(n4,"7");
   }
   else
   {
      strcpy(n1,"4");
      strcpy(n2,"5");
      strcpy(n3,"6");
      strcpy(n4,"7");
   }

   for(j=0;j<count_db;j++) {
      sprintf_s(stmt1, sizeof stmt1,
     "insert into car608_text  "
     " select a.ipolicy,iengine,dpolicy,b.iofficer,d.nname,  "
     "decode(c.nequipment[%d],'%s',1,'%s',1,'%s',1,'%s',1,0)  "
     "from car608 a,%s:ply_relation b,%s:policy c,officer d  "
     "where a.ipolicy = b.ipolicy  "
     "and a.ipolicy = c.ipolicy and b.iofficer = d.iofficer ",
          iflag,n1,n2,n3,n4,list[j].dbname,list[j].dbname);
      $PREPARE pre_text FROM $stmt1;
      $EXECUTE pre_text;
   }

   strcpy(stmt,"select * from car608_text");

       rc = unload_file(outputf," ",sfilename,stitle,stmt);
       if (rc != SUCCESS)
       {
           sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
           EWRITE(userid, rc , msgbuf);
           return rc;
       }
   return M_CM_OK;
errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car608_data_for17()
{
char  sfilename[41],stitle[300],stmt[1024];
char  full_db[41];
int   rc;

   rc = create_temp_car608_17();
   if (rc != M_CM_OK)
      return rc;
   
   if (iply==1) { /*�H�d���d��*/
      $declare cur_17 cursor for
        select b.ipolicy into $ipolicy
          from car608 a,assured_vs_ply b
         where a.ipolicy = b.icard;
      $open cur_17;
      while(1) {
         $fetch cur_17;
         if (SQLCODE==SQLNOTFOUND) break;
         printf("ipolicy_1[%s]\n",ipolicy);
         rc = insert_car608_17();
         if (rc != M_CM_OK)
            return rc;
      }
      $close cur_17;
      $free  cur_17;
   }
   else { /*�H�O�渹�d��*/
      $declare cur_17b cursor for
        select ipolicy into $ipolicy
          from car608;
      $open cur_17b;
      while(1) {
         $fetch cur_17b;
         if (SQLCODE==SQLNOTFOUND) break;
         printf("ipolicy_0[%s]\n",ipolicy);
         rc = insert_car608_17();
         if (rc != M_CM_OK)
            return rc;
      }
      $close cur_17b;
      $free  cur_17b;
   }
   strcpy(sfilename,"�ѧK��ΥN���O���Ӫ�");
   strcpy(stitle,"�O�d���X\t�O�渹�X\t��渹�X1\t��渹�X2\t���I\t�~�N�N��\t�������X\t�Q�O�I�H\t�_�O���\t������\t�����\t���ͮĤ�\t�ѧK��O�O\t�N���O�O�O\t���O\t�n�O�HID\t�ѵs�I�O�O\t����\t���O���p\t���1��z�覡\t���2��z�覡\t���²v����\t�O�_�ӫO�����I\t�����I�I�إN��\n");
   strcpy(stmt,"select * from car608_17");
   rc = unload_file(outputf," ",sfilename,stitle,stmt);
   if (rc != SUCCESS) {
       sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
       EWRITE(userid, rc , msgbuf);
       return rc;
   }
   return M_CM_OK;
errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car608_clear_data()
{
$char    stmt[200],full_db[41];
int      i;
$char    cnote[3];
$char    nequipment[31];
$char    nequipment_s[31];

   $whenever sqlerror goto errexit;
   $begin work;

   i=0;
   $declare cur1a cursor for
    select ipolicy
      into $ipolicy
      from car608;
   $open cur1a;
   
   while(1) {
      $fetch cur1a;
      if (SQLCODE==SQLNOTFOUND)
         break;
      i++;
      strcpy(full_db,get_car_full_db(ipolicy));
      sprintf_s(stmt, sizeof stmt,
      " select nequipment         "
      "   from %s:policy          "
	" where ipolicy = '%s' ",full_db,ipolicy);
      $prepare get_equip from $stmt;
      $execute get_equip into $nequipment;

      strcpy(cnote,itoa(inote));
      strcpy(nequipment_s,equip_delete(nequipment,cnote));

      sprintf_s(stmt, sizeof stmt,"update %s:policy set nequipment = '%s'  "
               "where ipolicy = ? ",full_db,nequipment_s);

      $prepare pre_upd from $stmt; 
      $execute pre_upd using $ipolicy;
   }
   $close cur1a;
   $free  cur1a;

   sprintf_s(msgbuf, sizeof msgbuf,"%s,��������[%d]",msgbuf,i);
   $commit work;
   return M_CM_OK;
errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   $whenever sqlerror continue;
   $rollback work;
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long create_temp_table()
{
   $whenever sqlerror goto errexit;

   $create temp table car608
    (ipolicy      char(20))
   with no log;

   return M_CM_OK;
errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long create_temp_car608_17()
{
   $whenever sqlerror goto errexit;

   $create temp table car608_17
    (icard           char(20),
     ipolicy         char(20),
     iendorse1       char(20) default ' ',
     iendorse2       char(20) default ' ',
     ibig_office     char(10),
     ibig_sales      char(10),
     iengine         char(20),
     nassured        char(60),
     dply_begin      date,
     dply_end        date,
     dendorse        date,
     dedr_begin      date,
     mprem_17        integer,
     mprem_14        integer,
     cnote           char(1),
     iapplicant      char(12),
     mins_premium_11 integer,
     icar_type       char(2),
     paystatus       char(100),
     iedr_return1    char(100) default ' ',
     iedr_return2    char(100) default ' ',
     provision       char(6),
     fPD             char(1),
     iins_PD         char(6)
   ) with no log;

   return M_CM_OK;
errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long insert_temp_table()
{
   $whenever sqlerror goto errexit;
   
   $insert into car608 values
    ($ipolicy);

   return M_CM_OK;
errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long insert_car608_17()
{
char  full_db[41];
$char stmt[9000], stmt1[1024];
int   iflag,i,rc;
$char n1[2],n2[2],n3[2],n4[2];
$char iedr[21],iendorse[2][21];
$char dedr[11],dendorse[2][11];
$char dbgn[11],dedr_bgn[2][11];
/* ���O���A�d�� */
char payresult[5],paystatus[100],paydate[100],notedate[100];
char policy_1[POLICY_NUM_1],policy_2[POLICY_NUM_2], batch_no[21];



   iflag = (inote - 1) % 30 + 1;
   if (inote <= 30)
   {
      strcpy(n1,"1");
      strcpy(n2,"3");
      strcpy(n3,"5");
      strcpy(n4,"7");
   }
   else if (inote <= 60)
   {
      strcpy(n1,"2");
      strcpy(n2,"3");
      strcpy(n3,"6");
      strcpy(n4,"7");
   }
   else
   {
      strcpy(n1,"4");
      strcpy(n2,"5");
      strcpy(n3,"6");
      strcpy(n4,"7");
   }

   $whenever sqlerror goto errexit;
   strcpy(full_db,get_car_full_db(ipolicy));
   for(i=0;i<2;i++)
   {
      strcpy(iendorse[i]," ");
      strcpy(dendorse[i]," ");
      strcpy(dedr_bgn[i]," ");
   }
   
   sprintf_s(stmt, sizeof stmt,
      "select distinct a.iendorse,a.dendorse,a.dedr_begin  "
      "   from %s:edr_relation a,%s:edr_ins_type b  "
      "  where a.ipolicy = ? and a.iendorse = b.iendorse  "
      "    and b.iins_type in ('17','14','19') and a.iendorse not like '%%CVP%%' ",full_db,full_db);
   printf("stmt[%s]\n", stmt);
   $prepare edr_pre from $stmt;
   $declare edr_cur cursor for edr_pre;
   $open  edr_cur using $ipolicy;
   for(i=0;i<2;i++) {
      $fetch edr_cur into $iedr, $dedr, $dbgn;
      if (SQLCODE==SQLNOTFOUND)
          break;
      strcpy(iendorse[i],iedr);
      strcpy(dendorse[i],dedr);
      strcpy(dedr_bgn[i],dbgn);

      /* 1020111001_C2 ���O�X����@�~ */
      sprintf_s(stmt1, sizeof stmt1, "UPDATE %s:edr_relation  "
                     "   SET dlock = current year to fraction(3)  "
                     " WHERE iendorse = '%s'  "
                     "   AND dendorse is null  "
                     "   AND dedr_close is null  "
                     "   AND dlock is null ", full_db, iendorse[i]);
      printf("stmt[%s]\n", stmt1);
      $prepare pre1 from $stmt1;
      $execute pre1;
   }
   $close edr_cur;
         
   strncpy(policy_1,ipolicy,CAR_POLICY_LEN); policy_1[CAR_POLICY_LEN]=0;
   strcpy(policy_2,&ipolicy[CAR_POLICY_LEN]);

   strcpy(batch_no, " ");
   rc = ao_chk_charge(DBName, 'A', policy_1, policy_2, batch_no,
                      payresult, paystatus, paydate, notedate);

   sprintf_s(stmt, sizeof stmt,
      "insert into car608_17  "
      "select a.icard,a.ipolicy,'%s','%s',ibig_office,ibig_sales,iengine, "
      "       nassured[1,60],dply_begin,dply_end,'%s','%s',  "
      "       nvl(c.mins_premium,0),nvl(d.mins_premium,0),          "
      "       decode(nequipment[%d],'%s',1,'%s',1,'%s',1,'%s',1,0),  "
      "       b.iapplicant,  "
      "       (select mins_premium from %s:ply_ins_type where ipolicy = ? and iins_type = '11'), a.icar_type,'%s',  "
      "       CASE (select iedr_return FROM %s:edr_relation WHERE iendorse = '%s') WHEN '1' THEN '�Ȥ�˿�'  "
      "             WHEN '2' THEN '�z�L�O�N' ELSE ' ' END,  "
      "       CASE (select iedr_return FROM %s:edr_relation WHERE iendorse = '%s') WHEN '1' THEN '�Ȥ�˿�'  "
      "             WHEN '2' THEN '�z�L�O�N' ELSE ' ' END,  "
      "       case when icar_type in (select icode from car_type where fclass = '1' and fcar_class = '1') then   "
      "            case when nvl((select max(drate_ym+0) from %s:ply_ins_type  "
      "                            where ipolicy = a.ipolicy and mdamage_cover > 0  "
      "                              and iins_type IN  ('01','05','09','11','101','102','110','111','129','20','23','75','76','86','98','201','205','209','211')),0) >= 104  "
      "                 then (select min(unique case when trim(provision)||';' matches '*P;*' then 'P' when trim(provision)||';' matches '*Q;*' then 'Q' else 'X' end)  "
      "                         from %s:ply_ins_type where ipolicy = a.ipolicy and mdamage_cover > 0   "
      "                          and iins_type IN ('01','05','09','11','101','102','110','111','129','20','23','75','76','86','98','201','205','209','211'))   "
      "            else 'P' end  "
      "       when icar_type in ('4A','9A','2B') then  "
      "            case when nvl((select max(drate_ym+0) from %s:ply_ins_type  "
      "                            where ipolicy = a.ipolicy and mdamage_cover > 0  "
      "                              and iins_type IN  ('01','05','09','11','201','205','209','211')),0) >= 111  "
      "                 then (select min(unique case when trim(provision)||';' matches '*Z;*' then 'P' when trim(provision)||';' matches '*P;*' then 'P'  "
      "                                              when trim(provision)||';' matches '*Q;*' then 'Q' when trim(provision)||';' matches '*M;*' then 'M' else 'X' end )  "
      "                         from %s:ply_ins_type where ipolicy = a.ipolicy and mdamage_cover > 0  "
      "                          and iins_type IN ('01','05','09','11','201','205','209','211'))  "
      "            else nvl((select min(unique case when trim(provision)||';' matches '*Z;*' then 'P' else 'Q' end )  "
      "                        from %s:ply_ins_type where ipolicy = a.ipolicy and mdamage_cover > 0  "
      "                         and iins_type IN ('01','05','09','11','201','205','209','211')),'Q') end  "
      "       else  "
      "            case when nvl((select max(drate_ym+0) from %s:ply_ins_type  "
      "                            where ipolicy = a.ipolicy and mdamage_cover > 0  "
      "                              and iins_type IN  ('01','05','09','11','201','205','209','211')),0) >= 111  "
      "            then (select min(unique case when trim(provision)||';' matches '*Q;*' then 'Q' when trim(provision)||';' matches '*M;*' then 'M' else 'X' end )  "
      "                    from %s:ply_ins_type where ipolicy = a.ipolicy and mdamage_cover > 0  "
      "                     and iins_type IN ('01','05','09','11','201','205','209','211'))  "
      "       else 'Q' end end,  "
      "       case when (SELECT count(*) FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy  "
      "                     AND iins_type IN (SELECT iins_type FROM insurance_type WHERE iins_type =iins_ply  "
      "                     AND imain_ins=iins_type AND fins_grp = 1 AND iri_ins <> '11' AND dexpire IS null)) > 0 THEN 'Y' ELSE 'N' end,  "
      "       nvl((SELECT iins_type FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy AND mdamage_cover !=0  "
      "               AND iins_type IN (SELECT iins_type FROM insurance_type WHERE iins_type =iins_ply  "
      "               AND imain_ins=iins_type AND fins_grp =1 AND iri_ins <> '11' AND dexpire IS null)),'')  "
      "  from %s:ply_relation a,%s:policy b, "
      "       outer %s:ply_ins_type c,outer %s:ply_ins_type d  "
      " where a.ipolicy = ? and a.ipolicy = b.ipolicy  "
      "   and a.ipolicy = c.ipolicy and c.iins_type = '17'  "
      "   and c.mdamage_cover != 0  "
      "   and a.ipolicy = d.ipolicy and d.iins_type in ('14','19')  "
      "   and d.mdamage_cover != 0 " ,iendorse[0],iendorse[1],dendorse[0],dedr_bgn[0],
          iflag,n1,n2,n3,n4,full_db,paystatus,full_db,iendorse[0],full_db,iendorse[1],full_db,full_db,full_db,
          full_db,full_db,full_db,full_db,full_db,full_db,full_db,full_db,full_db,full_db);
   printf("stmt[%s]\n",stmt);
   $prepare pre_17a from $stmt;
   $execute pre_17a using $ipolicy,$ipolicy;

   return M_CM_OK;
errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
null_alldata()
{
   memset(ipolicy,0x00,21);
}
/*--------------------------------------------------------------------*/
rtrim_alldata()
{
   strcpy(ipolicy,rtrim(ipolicy));
}
/*---------------------------------------------------------end program*/
