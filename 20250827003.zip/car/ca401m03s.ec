/*********************************************************/
/*                                                       */
/*     PROGRAM : ca401m03s.ec      (delete function)     */
/*               ca416m01s.ec      (delete function)     */
/*     AUTHOR  : S.Y.HWANG.870605                        */
/*     new version                                       */
/*********************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "carmsgs.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
$include "ca401lib.h";
#include <rinmsgs.h>
$include sqlca;
$include decimal.h;
$include "ply_ins_cover.h";
$include "ply_ins_assured.h";
$include "var_length.h";
$include sqltypes;

#define TRUE 1
#define FALSE 0

#define _TONY860606
#define _CODE860612

#define _MSG860619

$extern char prep_stmt[4096];
$char stmt_buf[4096];
long bk_edr_last();

$char v_sMsg[1512];
long rtncode;
char sColumn[21], sTable[21], sDbname[21];

struct PLY_INS_COVER *get_ply_ins_cover();
struct PLY_INS_ASSURED *get_ply_ins_assured();

/****************************************************************************/
long car401_delete_exec(reply, command, com_len, option_d)
serverReply reply;
voidP command;
int com_len;
char option_d;
{
  long rtn_code;
  long rc;
  long lRtnCode;
  $char DBName[5], HeadDB[40];
  $char iendorse_tmp[20];
  $char stmt[4096];

  DBinfo *list;
  int j, k;

  /* table edr_relation */
  $char fcard_class[2], ipolicy[21], icard[21], irelative_ply[21];
  $char old_iendorse[21], iendorse[21];
  $char irelative_edr[21], iabn_type[2], fpass[2], fedr_class[2], fpay[2];
  $char ipay[20];
  $long dedr_begin, dedr_end, dendorse;
  char s_dedr_begin[11], s_dedr_end[11], s_dendorse[11];
  $char iedr_cashier[11];
  $char iofficer[12], ibroker[12];
  $char icashier[11], ibig_comp[2];
  $char iresource[13], ibig_branch[5], ibig_office[11], ibig_sales[11];
  $char itreaty[2], ibranch[3], fcomp_class[3], fcomp_class_last[3];
  $char iedr_area[11], iply_area[11], fdiscount[2], fcar_note[3], ipay_way[2];
  $long medrdmg_prem, medrlia_prem;
  long medr_prem;
  $int id;
  $char icar_flag[2];
  /* bis9901141 �q���M�� */
  $char iofficer_prmt[11], iquota_prmt[7], ileader_prmt[11];
  /* end of edr_relation */

  $char nbrand_abbr[14], ncar_abbr[14];
  $char flimit[2], fhuman[4], fcomp_24[4];

  /* table endorsement */
  $char iassured[11], iassured_ext[3], fassured[2], itel[21], iemail[51], itmp_policy[21];
  $char itel_night[21], mobil_phone[21];
  $char nassured[122], nuser[19], ibenef[11], nbenef[43], aassured[100];
  $long qply_period, dply_begin, dply_end;
  char s_dply_begin[11], s_dply_end[11];
  $char ipro_year[5], ibrand[9], icar_type[8];
  $char ncode[16];
  /*$long qcylinder;*/
  $char iengine[CA_ENGINE_NUM], ibody[CA_BODY_NUM], itag[CA_TAG_NUM], ilicense[11], fsex[2];
  $char fmarriage[2], nequipment[31];
  $long pdmg_align, pbrg_align, plia_align;
  $double mcar_price;
  char s_mcar_price[20];
  $double pdmg_factor_1st, pbrg_factor_1st;
  $double qpt, psex_age, plia_acc, pdmg_acc, psex_age_damage, qcylinder;
  $char fpt[2];
  $char lia_class[3];
  $int dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd;
  $int qnext_year;
  $char iinstall[11];
  /* bis9901141 �q���M�� */
  $char iroute[21];
  $char irate_type[2], bzfrom[3], iroute_comm[4], icomm_obj[11];

  /* 1000728003_C2 �ĤT�H�d���I���ŧאּ5��(���) */
  $long qlia_acc_sum, qdmg_acc_sum, qprovision;

  $char fapplicant[2], fsex_appl[2], dbirth_appl[11], itel_appl[21], ndeputy_appl[51], nrelation_appl[41], ndeputy_assured[51];

  /* end of endorsement */

  /* table edr_ins_type */
  $char iedr_type[3], iins_type[7];
  $long medrinj_cover, medrdea_cover, medrdmg_cover, mdeduct, medrins_prem;

  $long mprem;
  $char fcal_way[2];
  $long qserial;
  $int pcal = 0;
  char temp[5];
  /* end of edr_ins_type */

  /* standard defined data */
  char option, *pos, *raw_ptr, *malloc(), cur_buf[4000], *comm;
  int tmp_len, raw_len;
  long dummy = 0;
  long MsgCode;
  /* end of standard data */

  /* self defined data */
  $char dummystr[25], iabn[21];
  $char ffac[2], dbname_tp[20];
  $char tmpendorse[21];
  $long dclosing, iCount;
  $char ilast_ply[21];
  $char ilast_ply_tmp[21], dverify[11], dlock[31];
  char tmp_pdmg_factor_1st[20], tmp_pbrg_factor_1st[20];
  char tmp_pdmg_factor_2nd[20], tmp_pbrg_factor_2nd[20];
  long count;
  int ERR29, ERR30, ERR31, flag_exist = 0;
  $int tmp_qedr_serial;

  $struct edr_relation p;
  $struct ply_ins_type pp;
  $struct ca_pa_ply pa;

  int rtncode;

  $double pdiscount, pagent, pcommission;
  $long mdiscount, medrdmg_discount, medrlia_discount, magent, mcommission;
  $long mdmg_discount, mlia_discount;
  struct PLY_INS_COVER *IfirstPlyInsCover;
  $char introducer[21], sIinsType[7];

  char iestimate_r[21];
  $char transno[21], userid[11];

  $double punknown_acc;
  $char iquery_num_unknown[121];
  $long qunknown_acc_sum;
  $char dtply_begin[17], dtply_end[17], dtedr_begin[17], dtedr_end[17]; /* 1061108001_SC6_�t�X�s�еo�i���ߨt�λݨD���Ѭ����t�Υ\�� yyyy-mm-dd HH:MM */
  $char iscan_no_edr[26], iprog[11];                                    /* 1101018008_SC2 �q�lñ�ݱ��y�s������X�W��25�X */
  $char ftrans_third[2] = "";                                           /* 1110303014_SC2 �t�X���ظ�Ʀ@�ɡA�ӽШ��I�Φ����X��t�ηs�W��� */
  $char iquote[21];                                                     /* 1110607001_SC1 �ظmE�O�����t�� */  

  iendorse_tmp[0] = '\0';

  medrdmg_prem = 0;
  medrlia_prem = 0;
  medr_prem = 0;
  fpass[0] = 0;
  mdiscount = medrdmg_discount = medrlia_discount = 0;
  magent = mcommission = mdmg_discount = mlia_discount = 0;

  comm = (char *)command;
  cm_buf_init(command);
  cm_buf_get("%c %s %s", &option, DBName, userid);

  /* compare old record and current record, if the record has not been changed
   * since last request, update or delete the record, otherwise return errmsg
   * to client side */
  /* get old record info from command buffer */

  memcpy(&raw_len, &comm[com_len], sizeof(int));
  pos = &comm[com_len + sizeof(int)];
  raw_ptr = malloc(raw_len);
  if (raw_ptr != (char *)0)
    memcpy(raw_ptr, pos, raw_len);
  else
  {
    if (exitsub(reply, M_CM_NOT_MALLOC) == True)
      return M_CM_NOT_MALLOC;
    else
      return apiRC;
  }

  cm_buf_init(raw_ptr);
  cm_buf_get("%l", &dummy);
  cm_buf_get("%l", &count);
  cm_buf_get("%s %s %s %s %s", dummystr, dummystr, dummystr, dummystr, dummystr);
  cm_buf_get("%s", old_iendorse);

  $WHENEVER SQLERROR GOTO errexit;

  rtncode = getHeadBranch(HeadDB);
  free(raw_ptr);
  if (rtncode < 0)
  {
    exitsub(reply, M_CM_READ_CONFIG_ERR);
    return M_CM_READ_CONFIG_ERR;
  }

  strcpy(dbname_tp, get_full_dbname(HeadDB)); /* get TP's full DB name */

  if ((list = get_db_list(&j, DBName)) == (char *)0)
  {
    if (exitsub(reply, M_CM_NOT_DBLIST) == True)
      return M_CM_NOT_DBLIST;
    return apiRC;
  }

  if ((old_iendorse[CAR_EDR_ABN_POS - 1] != 'Y') ||
      (isalpha(old_iendorse[CAR_EDR_ABN_POS])))
  {
    ERR29 = M_CA_NREL_EDR;
    ERR30 = M_CA_NENDORSE;
    ERR31 = M_CA_NEDR_INS_TYPE;
    if (db_select(DBName) == False)
    {
      if (exitsub(reply, M_CM_DB_NOTOPEN) == True)
        return M_CM_DB_NOTOPEN;
      else
        return apiRC;
    }
  }
  else
  {
    ERR29 = M_CA_NABN_EDR_REL;
    ERR30 = M_CA_NABN_EDR;
    ERR31 = M_CA_NABN_EDR_INS;
  }

  strcpy(iquote," "); /* 1110607001_SC1 �ظmE�O�����t�� */

  if ((old_iendorse[CAR_EDR_ABN_POS - 1] != 'Y') ||
      (isalpha(old_iendorse[CAR_EDR_ABN_POS])))
  {
    $WHENEVER SQLERROR GOTO errexit;
    sprintf(stmt, "SELECT %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s FROM %s %s WHERE %s %s",
            "a.ipolicy, a.icard, a.irelative_ply,",
            "a.fedr_class, a.fpay, a.ipay, a.dedr_begin, a.dedr_end,",
            "a.ipro_year, a.ibrand, a.icar_type,",
            "a.medrdmg_prem, a.medrlia_prem,",
            "a.ibig_comp, a.ibig_branch, a.ibig_office, a.ibig_sales,",
            "a.iresource, a.ibroker, a.iofficer, a.iedr_area, a.iedr_cashier,",
            "a.dendorse, a.iabn_type, a.ffac, a.itreaty,",
            "a.ibranch, a.fcomp_class, a.fcomp_class_last, a.fdiscount, a.icar_flag,",
            "b.qply_period, b.dply_begin, b.dply_end, b.iassured, b.iassured_ext, b.fassured, b.nassured,",
            "b.ilicense, b.fsex, b.fmarriage,",
            "b.nuser, b.ibenef, b.nbenef, b.aassured, b.itel, b.itel_night, b.mobil_phone, b.iemail, b.iply_area,",
            "b.nbrand_abbr, b.ncar_abbr, b.fcar_note, b.qcylinder, b.iengine, b.ibody, b.itag,",
            "b.mcar_price, b.nequipment, b.flimit, b.pdmg_align, b.pbrg_align, b.plia_align,",
            "b.pdmg_factor, b.pbrg_factor, b.qpt, b.fpt, b.psex_age, b.psex_age_damage, b.plia_acc, b.pdmg_acc,",
            "b.lia_class, b.dmg_acc_1st, b.dmg_acc_2nd, b.dmg_acc_3rd,",
            "b.fhuman, b.fcomp_24, b.iroute, a.iofficer_prmt, a.iquota_prmt, a.ileader_prmt, a.irate_type,a.bzfrom,a.iroute_comm,a.icomm_obj, ",
            "b.qlia_acc_sum, b.qdmg_acc_sum, a.qprovision, b.fapplicant,b.fsex_appl,b.dbirth_appl,b.itel_appl,",
            "b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured, a.dverify, a.dlock, a.fcard_class, ",
            "b.punknown_acc, b.iquery_num_unknown, b.qunknown_acc_sum ,a.dtedr_begin, a.dtedr_end , b.dtply_begin, b.dtply_end, a.iscan_no, a.iquote ",
            "edr_relation a ,",
            "endorsement  b ",
            " a.iendorse = ? ",
            " AND a.iendorse = b.iendorse ");

    EXEC SQL PREPARE sel_old_edr FROM : stmt;
    EXEC SQL EXECUTE sel_old_edr INTO $ipolicy, $icard, $irelative_ply,
        $fedr_class, $fpay, $ipay, $dedr_begin, $dedr_end,
        $ipro_year, $ibrand, $icar_type,
        $medrdmg_prem, $medrlia_prem,
        $ibig_comp, $ibig_branch, $ibig_office, $ibig_sales,
        $iresource, $ibroker, $iofficer, $iedr_area, $iedr_cashier,
        $dendorse : id, $iabn_type, $ffac, $itreaty, $ibranch, $fcomp_class, $fcomp_class_last, $fdiscount, $icar_flag, 
        $qply_period, $dply_begin, $dply_end, $iassured, $iassured_ext, $fassured, $nassured, $ilicense, $fsex, $fmarriage,
        $nuser, $ibenef, $nbenef, $aassured, $itel, $itel_night, $mobil_phone, $iemail, $iply_area, $nbrand_abbr, 
        $ncar_abbr, $fcar_note, $qcylinder, $iengine, $ibody, $itag, $mcar_price, $nequipment, $flimit, $pdmg_align, 
        $pbrg_align, $plia_align, $pdmg_factor_1st, $pbrg_factor_1st, $qpt, $fpt, $psex_age, $psex_age_damage, $plia_acc, 
        $pdmg_acc, $lia_class, $dmg_acc_1st, $dmg_acc_2nd, $dmg_acc_3rd, $fhuman, $fcomp_24, $iroute, $iofficer_prmt, 
        $iquota_prmt, $ileader_prmt, $irate_type, $bzfrom, $iroute_comm, $icomm_obj, $qlia_acc_sum, $qdmg_acc_sum, 
        $qprovision, $fapplicant, $fsex_appl, $dbirth_appl, $itel_appl, $ndeputy_appl, $nrelation_appl, $ndeputy_assured, 
        $dverify, $dlock, $fcard_class, $punknown_acc, $iquery_num_unknown, $qunknown_acc_sum, $dtedr_begin, $dtedr_end, 
        $dtply_begin, $dtply_end, $iscan_no_edr, $iquote
  USING $old_iendorse;

    if (SQLCODE == SQLNOTFOUND)
    {
      if (exitsub(reply, ERR29) == True)
        return ERR29;
      else
        return apiRC;
    }
    if (id < 0)
      dendorse = 0;
    else
    {
      /* 1001003001_C1 ����������ᤣ�i�R����� */
      if (exitsub(reply, M_CA_NCANCEL_EDR) == True)
        return M_CA_NCANCEL_EDR;
      else
        return apiRC;
    }

    /* 1020111001_C2 ���O�X����@�~ */
    $SELECT COUNT(*)
        INTO $iCount
            FROM cm_pre_receive
                WHERE ipre_rcv = $old_iendorse
                    AND iins_kind = $fcard_class
                        AND ipre_end = ' ' AND(fstatus != '10' OR dprint_rcv IS NOT NULL);
    if (iCount != 0) /* �w�C�Lú�O���,���o�R����� */
    {
      if (exitsub(reply, M_CA_DEL_ERR1) == True)
        return M_CA_DEL_ERR1;
      else
        return apiRC;
    }

    $SELECT COUNT(*)
        INTO $iCount
            FROM sysdb : cm_tmp_receipt
                             WHERE ipre_rcv = $old_iendorse
                                 AND dprint IS NOT NULL;
    if (iCount != 0) /* �w�C�L�Ȧ��O�O���ڪ�,���o�R����� */
    {
      if (exitsub(reply, M_CA_DEL_ERR2) == True)
        return M_CA_DEL_ERR2;
      else
        return apiRC;
    }

    if (strlen(trim(dlock)) != 0) /* B2B����鵲�ɶ�����A���饼ú�O����椣�i�R�� */
    {
      if (exitsub(reply, M_CA_DEL_ERR3) == True)
        return M_CA_DEL_ERR3;
      else
        return apiRC;
    }

    $SELECT COUNT(*)
        INTO $iCount
            FROM cm_e_policy
                WHERE ipolicy = $ipolicy
                    AND iendorse = $old_iendorse
                                       AND fstatus >= 100;

    if (iCount != 0) /* �w���s�q�l���A���i�R����� */
    {
      if (exitsub(reply, M_CA_DEL_ERR4) == True)
        return M_CA_DEL_ERR4;
      else
        return apiRC;
    }

    $SELECT COUNT(*)  INTO $iCount
       FROM cm_e_policy a, edr_relation b, ply_relation_bak c 
      WHERE a.ipolicy  = $ipolicy 
        AND a.iendorse = $old_iendorse   /*1130216011_C01 �ץ�car401�q�l�O��P�_�O�_�w���s���W�h*/
        AND b.iendorse = ' ' 
        AND a.fstatus >= 100 
        AND a.ipolicy  = b.ipolicy 
        AND b.iendorse = c.iendorse 
        AND b.feply   != '0' 
        AND c.feply    = '0';

    if (iCount != 0) /* ���q�l�O��ﶵ(�L->��)�A�w���s�q�l�O��A���i�R����� */
    {
      if (exitsub(reply, M_CA_DEL_ERR5) == True)
        return M_CA_DEL_ERR5;
      else
        return apiRC;
    }
  }
  else
  {
    sprintf(prep_stmt, "SELECT %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s FROM %s:%s %s:%s WHERE %s %s",
            "a.fcard_class, a.ipolicy, a.icard, a.ilast_ply, a.irelative_ply,",
            "a.fedr_class, a.fpay, a.ipay, a.dedr_begin, a.dedr_end,",
            "a.ipro_year, a.ibrand, a.icar_type,",
            "a.medrdmg_prem, a.medrlia_prem, a.ibig_comp, a.ibig_branch,",
            "a.ibig_office, a.ibig_sales, a.iresource, a.ibroker, a.iofficer,",
            "a.iedr_area, a.iedr_cashier, a.ffac, a.itreaty, a.ibranch,",
            "a.fcomp_class, a.fcomp_class_last, a.fdiscount, a.icar_flag,",
            "b.iassured, b.iassured_ext, b.fassured, b.nassured, b.nuser, b.ibenef, b.nbenef, b.aassured,",
            "b.itel, b.itel_night, b.mobil_phone, b.iemail, b.qply_period, b.dply_begin, b.dply_end,",
            "b.qcylinder, b.iengine, b.ibody, b.itag, b.ilicense,",
            "b.fsex, b.fmarriage, b.pdmg_align, b.pbrg_align, b.plia_align,",
            "b.mcar_price, b.nequipment, b.pdmg_factor, b.pbrg_factor,",
            "b.qpt, b.fpt, b.psex_age, b.psex_age_damage, b.plia_acc, b.pdmg_acc,",
            "b.lia_class, b.dmg_acc_1st, b.dmg_acc_2nd, b.dmg_acc_3rd,",
            "b.nbrand_abbr, b.ncar_abbr, b.fhuman, b.fcomp_24,",
            "b.iroute, a.iofficer_prmt, a.iquota_prmt, a.ileader_prmt, a.irate_type,a.bzfrom,a.iroute_comm,a.icomm_obj, ",
            "b.qlia_acc_sum, b.qdmg_acc_sum, a.qprovision, b.fapplicant,b.fsex_appl,b.dbirth_appl,",
            "b.itel_appl,b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured, ",
            "b.punknown_acc, b.iquery_num_unknown, b.qunknown_acc_sum, a.dtedr_begin, a.dtedr_end , b.dtply_begin, b.dtply_end,a.iscan_no ",
            dbname_tp, "abn_edr_relation a ,",
            dbname_tp, "abnormal_edr b ",
            "a.iabnormal = ? ",
            "AND   a.iabnormal = b.iabnormal");

    $PREPARE STMT_CUR1 FROM $prep_stmt;
    $DECLARE cur1 CURSOR FOR STMT_CUR1;
    $OPEN cur1 USING $old_iendorse;
    $FETCH cur1
        INTO $fcard_class,
        $ipolicy, $icard, $ilast_ply, $irelative_ply,
        $fedr_class, $fpay, $ipay, $dedr_begin, $dedr_end,
        $ipro_year, $ibrand, $icar_type,
        $medrdmg_prem, $medrlia_prem, $ibig_comp, $ibig_branch,
        $ibig_office, $ibig_sales, $iresource, $ibroker, $iofficer,
        $iedr_area, $iedr_cashier, $ffac, $itreaty, $ibranch,
        $fcomp_class, $fcomp_class_last, $fdiscount, $icar_flag,
        $iassured, $iassured_ext, $fassured, $nassured, $nuser, $ibenef, $nbenef, $aassured,
        $itel, $itel_night, $mobil_phone, $iemail,
        $qply_period, $dply_begin, $dply_end,
        $qcylinder, $iengine, $ibody, $itag, $ilicense,
        $fsex, $fmarriage, $pdmg_align, $pbrg_align, $plia_align,
        $mcar_price, $nequipment, $pdmg_factor_1st, $pbrg_factor_1st,
        $qpt, $fpt, $psex_age, $psex_age_damage, $plia_acc, $pdmg_acc,
        $lia_class, $dmg_acc_1st, $dmg_acc_2nd, $dmg_acc_3rd,
        $nbrand_abbr, $ncar_abbr, $fhuman, $fcomp_24,
        $iroute, $iofficer_prmt, $iquota_prmt, $ileader_prmt,
        $irate_type, $bzfrom, $iroute_comm, $icomm_obj, $qlia_acc_sum, $qdmg_acc_sum, $qprovision,
        $fapplicant, $fsex_appl, $dbirth_appl, $itel_appl, $ndeputy_appl, $nrelation_appl, $ndeputy_assured,
        $punknown_acc, $iquery_num_unknown, $qunknown_acc_sum, $dtedr_begin, $dtedr_end, $dtply_begin, $dtply_end, $iscan_no_edr;

    if (SQLCODE == SQLNOTFOUND)
    {
      $CLOSE cur1;
      $FREE cur1;
      if (exitsub(reply, ERR29) == True)
        return ERR29;
      else
        return apiRC;
    }
    $CLOSE cur1;
    $FREE cur1;
  }

  $SELECT icashier
      INTO $icashier
          FROM ply_relation
              WHERE ipolicy = $ipolicy;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CA_NREL_PLY) == True)
      return M_CA_NREL_PLY;
    else
      return apiRC;
  }

  strcpy(s_dedr_begin, cm_cdate_str_100(dedr_begin));
  strcpy(s_dedr_end, cm_cdate_str_100(dedr_end));

  if ((old_iendorse[CAR_EDR_ABN_POS - 1] != 'Y') ||
      (isalpha(old_iendorse[CAR_EDR_ABN_POS])))
    strcpy(s_dendorse, cm_cdate_str_100(dendorse));
  else
  {
    s_dendorse[0] = 0;
    irelative_edr[0] = 0;
  }

  strcpy(s_dply_begin, cm_cdate_str_100(dply_begin));
  strcpy(s_dply_end, cm_cdate_str_100(dply_end));

  /* put data into cur_buf */
  $WHENEVER SQLERROR GOTO errexit;

  if (option_d == 'D')
  {
    if ((old_iendorse[CAR_EDR_ABN_POS - 1] != 'Y') ||
        (isalpha(old_iendorse[CAR_EDR_ABN_POS])))
    { /* �@��� */
      /**** �ˮ֦P�@�i�O�榳��i�H�W������,�Y���e�@�i��楼���A�h���i���R��@�i��� ****/
      $BEGIN WORK;

/*       EXEC SQL DECLARE bef_endorse CURSOR FOR
      SELECT iendorse
        FROM edr_relation
       WHERE ipolicy = $ipolicy
         AND iendorse not like '%CVP%' 
         AND dcreate > (select dcreate from edr_relation where iendorse = $old_iendorse);

      EXEC SQL OPEN bef_endorse;
      EXEC SQL FETCH bef_endorse INTO : iendorse_tmp;
      if (SQLCODE == SQLNOTFOUND)
      {
        printf("SQLNOTFOUND \n");
      }
      EXEC SQL CLOSE bef_endorse;
      EXEC SQL FREE bef_endorse;

      if (strlen(iendorse_tmp) > 0)
      {
        $ROLLBACK WORK;
        if (exitsub(reply, M_CA_NMAX_EDR) == True)
          return M_CA_NMAX_EDR;
        else
          return apiRC;
      } */

      dendorse = 0;

      $SELECT dendorse, ffac, ipolicy, irelative_ply INTO $dendorse : id, $ffac, $ipolicy, $irelative_ply FROM edr_relation WHERE iendorse = $old_iendorse;
      if (SQLCODE == SQLNOTFOUND)
      {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        if (exitsub(reply, M_CA_NENDORSE) == True)
          return M_CA_NENDORSE;
        else
          return apiRC;
      }
      $WHENEVER SQLERROR GOTO errexit;

      if (strncmp(old_iendorse + (6 - 1), "CVP", 3) == 0)
      {
        $DELETE FROM edr_relation WHERE iendorse = $old_iendorse;
        $DELETE FROM endorsement WHERE iendorse = $old_iendorse;
#ifdef CA_CONS
        $DELETE FROM edr_ins_cover WHERE iendorse = $old_iendorse;
#endif
#ifdef CA_ONE
        $DELETE FROM edr_ins_assured WHERE iendorse = $old_iendorse;
#endif
        $DELETE FROM edr_ins_type WHERE iendorse = $old_iendorse;
        $DELETE FROM endorsement_note WHERE iendorse = $old_iendorse;
        $DELETE FROM ca_pa_edr WHERE iendorse = $old_iendorse;
        /* car9903041 ���s�t�λP���O�B�ɨ�����s�� */
        $DELETE FROM ca_edr_bound WHERE iendorse = $old_iendorse;
      }
      else
      {
        EXEC SQL DECLARE bef_endorse CURSOR FOR
        SELECT iendorse
          FROM edr_relation
        WHERE ipolicy = $ipolicy
          AND iendorse not like '%CVP%' 
          AND dcreate > (select dcreate from edr_relation where iendorse = $old_iendorse);

        EXEC SQL OPEN bef_endorse;
        EXEC SQL FETCH bef_endorse INTO : iendorse_tmp;
        if (SQLCODE == SQLNOTFOUND)
        {
          printf("SQLNOTFOUND \n");
        }
        EXEC SQL CLOSE bef_endorse;
        EXEC SQL FREE bef_endorse;

        if (strlen(iendorse_tmp) > 0)
        {
          $ROLLBACK WORK;
          if (exitsub(reply, M_CA_NMAX_EDR) == True)
            return M_CA_NMAX_EDR;
          else
            return apiRC;
        }

        $DECLARE cur3 CURSOR FOR
            SELECT iendorse,
            qedr_serial
                FROM ply_relation_bak
                    WHERE ipolicy = $ipolicy
                        ORDER BY qedr_serial DESC;

        $OPEN cur3;
        $FETCH cur3 INTO $tmpendorse, $tmp_qedr_serial;

        if (SQLCODE == SQLNOTFOUND)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          if (exitsub(reply, M_CA_NPLYREL_BAK) == True)
            return M_CA_NPLYREL_BAK;
          else
            return apiRC;
        }

        strcpy(tmpendorse, trim(tmpendorse));
        strcpy(old_iendorse, trim(old_iendorse));

        if (strcmp(tmpendorse, old_iendorse) != 0)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          if (exitsub(reply, M_CA_NMAX_EDR) == True)
            return M_CA_NMAX_EDR;
          else
            return apiRC;
        }

        $WHENEVER SQLERROR GOTO errexit;

        if (ffac[0] != '\0' && ffac[0] != ' ')
        {
#ifdef _CODE860612
          rtn_code = ca_fac_edrcheck("", old_iendorse, NULL, NULL, 0, ffac,
                                     'D', iestimate_r);
#else
          if (ffac[0] == 'N')
            rtn_code = ca_fac_edrcheck(old_iendorse, "", NULL, NULL, 0, ffac,
                                       'D', iestimate_r);
          else
            rtn_code = ca_fac_edrcheck("", old_iendorse, NULL, NULL, 0, ffac,
                                       'D', iestimate_r);
#endif

          if (rtn_code != M_CA_FAC_CANCEL)
          {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            exitsub(reply, rtn_code);
            return rtn_code;
          }
          $WHENEVER SQLERROR GOTO errexit;

          sprintf(prep_stmt, "SELECT iabnormal FROM %s:abn_edr_relation "
                             "                     WHERE iendorse=?",
                  dbname_tp);

          $PREPARE sel_q FROM $prep_stmt;
          $DECLARE sel_id CURSOR FOR sel_q;
          $OPEN sel_id USING $old_iendorse;
          $FETCH sel_id INTO $iabn;
          $CLOSE sel_id;
          $FREE sel_id;

          sprintf(prep_stmt, "DELETE FROM %s:abn_edr_relation "
                             "               WHERE iabnormal=?",
                  dbname_tp);

          $PREPARE del_id4 FROM $prep_stmt;
          $EXECUTE del_id4 USING $iabn;

          {
            long iRtnCode;
            $char sTmpPolicy1[POLICY_NUM_1], sTmpPolicy2[POLICY_NUM_2];
            iRtnCode = split_policy(ipolicy, sTmpPolicy1, sTmpPolicy2);
            if (iRtnCode != M_CM_OK)
            {
              $WHENEVER SQLERROR CONTINUE;
              $ROLLBACK WORK;
              exitsub(reply, iRtnCode);
              return iRtnCode;
            }
            $WHENEVER SQLERROR GOTO errexit;
            iRtnCode = cm_credit_pay_delete_car(sTmpPolicy1, sTmpPolicy2, iabn);
            if (iRtnCode != M_CM_OK)
            {
              $WHENEVER SQLERROR CONTINUE;
              $ROLLBACK WORK;
              exitsub(reply, iRtnCode);
              return iRtnCode;
            }
          }

          $WHENEVER SQLERROR GOTO errexit;
          /*---delete abnormal_edr---*/
          sprintf(prep_stmt, "DELETE FROM %s:abnormal_edr "
                             "                     WHERE iabnormal=?",
                  dbname_tp);
          $PREPARE del_id5 FROM $prep_stmt;
          $EXECUTE del_id5 USING $iabn;

#ifdef CA_CONS
          sprintf(prep_stmt, "DELETE FROM %s:abn_edr_ins_cover "
                             "                WHERE iabnormal=?",
                  dbname_tp);
          $PREPARE del_id8 FROM $prep_stmt;
          $EXECUTE del_id8 USING $iabn;
#endif

#ifdef CA_ONE
          sprintf(prep_stmt, "DELETE FROM %s:abn_edr_ins_assured "
                             "                WHERE iabnormal=?",
                  dbname_tp);
          $PREPARE del_id9 FROM $prep_stmt;
          $EXECUTE del_id9 USING $iabn;
#endif

          /* car9903041 ���s�t�λP���O�B�ɨ�����s�� */
          sprintf(prep_stmt, "DELETE FROM %s:abn_ca_edr_bound "
                             "               WHERE iabnormal=?",
                  dbname_tp);
          $PREPARE del_id10 FROM $prep_stmt;
          $EXECUTE del_id10 USING $iabn;

          /*---delete abn_edr_ins_type---*/
          sprintf(prep_stmt, "DELETE FROM %s:abn_edr_ins_type "
                             "                     WHERE iabnormal=?",
                  dbname_tp);
          $PREPARE del_id6 FROM $prep_stmt;
          $EXECUTE del_id6 USING $iabn;

          /*---delete abn_ca_pa_edr---*/
          sprintf(prep_stmt, "DELETE FROM %s:abn_ca_pa_edr "
                             "                     WHERE iabnormal=?",
                  dbname_tp);
          $PREPARE del_id7 FROM $prep_stmt;
          $EXECUTE del_id7 USING $iabn;

          $delete from cm_risk_preview where iref_num = $iabn;
        }
        /********************************************************/

        $DELETE FROM ply_relation WHERE ipolicy = $ipolicy;
        $DELETE FROM policy WHERE ipolicy = $ipolicy;
#ifdef CA_CONS
        $DELETE FROM ply_ins_cover WHERE ipolicy = $ipolicy;
        printf("1:SQLCODE[%d]\n", SQLCODE);
#endif
#ifdef CA_ONE
        $DELETE FROM ply_ins_assured WHERE ipolicy = $ipolicy;
        printf("2:SQLCODE[%d]\n", SQLCODE);
#endif
        $DELETE FROM ply_ins_type WHERE ipolicy = $ipolicy;
        $DELETE FROM ca_pa_ply WHERE ipolicy = $ipolicy;

        /* car9903041 ���s�t�λP���O�B�ɨ�����s�� */
        $DELETE FROM ca_ply_bound WHERE ipolicy = $ipolicy;

        /***** ply_relation recovery *****/
        $SELECT ipolicy, icard, fcard_class, irelative_ply,
            ilast_card, ilast_ply, inext_ply,
            itreaty, qply_period, dply_begin, dply_end,
            ipro_year, ibrand, icar_type,
            mdmg_agent, mdmg_commi, mdmg_prem,
            mlia_agent, mlia_commi, mlia_prem,
            mdmg_pure_prem, mlia_pure_prem,
            ibig_comp, ibig_branch, ibig_office, ibig_sales, iresource,
            ibroker, iofficer, iarea, icashier, iexaminer, dexamine,
            ientry, dentry, dpolicy, dply_close, dapply, fprint,
            drenew_print, dtransfer, fedr_class, dendorse, ibranch,
            mready, mstable, mcompensation,
            madjcom_prem, mbusiness, mresearch, mcapital, mbus_rule, minvest, maintain,
            fcomp_class, fcomp_class_last, fdiscount,
            mdmg_discount, mlia_discount, ibatch_no, qedr_serial,
            icorps, ileader, iquota, icomp_in, ibranch_in,
            icomp_at, ibranch_at, itmp_policy, ipay_way, icar_flag, qnext_year, iinstall,
            iofficer_prmt, iquota_prmt, ileader_prmt,
            irate_type, bzfrom, iroute_comm, icomm_obj, qprovision, dtrans_b2b, dcreate,
            isecond_hand, icard_main, qdrunk_driving, isign,
            feply, aemail_eply, dcreate_eply, iscan_no, dtply_begin, dtply_end, tmobile_eply, ireg_no, dnotifyornot,
            fsign_status, funder_chk, feterms, iprog, ftrans_third, qviolate 
      INTO $p.ipolicy, $p.icard, $p.fcard_class, $p.irelative_ply,
            $p.ilast_card, $p.ilast_ply, $p.inext_ply,
            $p.itreaty, $p.qply_period, $p.dply_begin, $p.dply_end,
            $p.ipro_year, $p.ibrand, $p.icar_type,
            $p.mdmg_agent, $p.mdmg_commi, $p.mdmg_prem,
            $p.mlia_agent, $p.mlia_commi, $p.mlia_prem,
            $p.mdmg_pure_prem, $p.mlia_pure_prem,
            $p.ibig_comp, $p.ibig_branch, $p.ibig_office, $p.ibig_sales,
            $p.iresource, $p.ibroker, $p.iofficer, $p.iarea, $p.icashier,
            $p.iexaminer, $p.dexamine, $p.ientry, $p.dentry,
            $p.dpolicy, $p.dply_close, $p.dapply,
            $p.fprint, $p.drenew_print, $p.dtransfer, $p.fedr_class,
            $p.dendorse, $p.ibranch, $p.mready, $p.mstable, $p.mcompensate,
            $p.madjcom, $p.mbusiness, $p.mresearch, $p.mcapital, $p.mbus_rule, $p.minvest, $p.maintain,
            $p.fcomp_class, $p.fcomp_class_last,
            $p.fdiscount, $p.mdmg_discount, $p.mlia_discount, $p.ibatch_no,
            $p.qedr_serial, $p.icorps, $p.ileader, $p.iquota,
            $p.icomp_in, $p.ibranch_in, $p.icomp_at, $p.ibranch_at,
            $itmp_policy, $ipay_way, $p.icar_flag, $qnext_year, $iinstall,
            $p.iofficer_prmt, $p.iquota_prmt, $p.ileader_prmt,
            $p.irate_type, $p.bzfrom, $p.iroute_comm, $p.icomm_obj, $p.qprovision, $p.dtrans_b2b, $p.dcreate,
            $p.isecond_hand, $p.icard_main, $p.qdrunk_driving, $p.isign,
            $p.feply, $p.aemail_eply, $p.dcreate_eply, $p.iscan_no, $p.dtply_begin, $p.dtply_end, $p.tmobile_eply, $p.ireg_no, $p.dnotifyornot,
            $p.fsign_status_edr, $p.funder_chk_edr, $p.feterms, $iprog, $ftrans_third, $p.qviolate 
       FROM ply_relation_bak 
      WHERE iendorse = $old_iendorse;
        printf("--trace[%s] \n", p.dnotifyornot);
        if (SQLCODE == SQLNOTFOUND)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          if (exitsub(reply, M_CA_NPLYREL_BAK) == True)
            return M_CA_NPLYREL_BAK;
          else
            return apiRC;
        }

        $WHENEVER SQLERROR GOTO errexit;

        $INSERT INTO ply_relation(ipolicy, icard, fcard_class, irelative_ply,
                                  ilast_card, ilast_ply, inext_ply, itreaty,
                                  qply_period, dply_begin, dply_end,
                                  ipro_year, ibrand, icar_type,
                                  mdmg_agent, mdmg_commi, mdmg_prem,
                                  mlia_agent, mlia_commi, mlia_prem,
                                  mdmg_pure_prem, mlia_pure_prem,
                                  ibig_comp, ibig_branch, ibig_office, ibig_sales,
                                  iresource, ibroker, iofficer, iarea, icashier, iexaminer,
                                  dexamine, ientry, dentry, dpolicy, dply_close,
                                  dapply, fprint,
                                  drenew_print, dtransfer, fedr_class, dendorse,
                                  ibranch, mready, mstable, mcompensation, madjcom_prem,
                                  mbusiness, mresearch, mcapital, mbus_rule, minvest, maintain,
                                  fcomp_class, fcomp_class_last, fdiscount,
                                  mdmg_discount, mlia_discount, ibatch_no, icorps,
                                  ileader, iquota, icomp_in, ibranch_in, icomp_at,
                                  ibranch_at, itmp_policy, ipay_way, icar_flag, qnext_year, iinstall,
                                  iofficer_prmt, iquota_prmt, ileader_prmt,
                                  irate_type, bzfrom, iroute_comm, icomm_obj, qprovision, dtrans_b2b, dcreate, isecond_hand,
                                  icard_main, qdrunk_driving, isign, feply, aemail_eply, dcreate_eply, iscan_no, dtply_begin, dtply_end,
                                  tmobile_eply, ireg_no, dnotifyornot, fsign_status, funder_chk, feterms, iprog, ftrans_third, qviolate)
            VALUES($p.ipolicy, $p.icard, $p.fcard_class, $p.irelative_ply,
                   $p.ilast_card, $p.ilast_ply, $p.inext_ply, $p.itreaty,
                   $p.qply_period, $p.dply_begin, $p.dply_end,
                   $p.ipro_year, $p.ibrand, $p.icar_type,
                   $p.mdmg_agent, $p.mdmg_commi, $p.mdmg_prem,
                   $p.mlia_agent, $p.mlia_commi, $p.mlia_prem,
                   $p.mdmg_pure_prem, $p.mlia_pure_prem,
                   $p.ibig_comp, $p.ibig_branch, $p.ibig_office, $p.ibig_sales,
                   $p.iresource, $p.ibroker, $p.iofficer, $p.iarea, $p.icashier, $p.iexaminer,
                   $p.dexamine, $p.ientry, $p.dentry, $p.dpolicy, $p.dply_close,
                   $p.dapply, $p.fprint,
                   $p.drenew_print, $p.dtransfer, $p.fedr_class, $p.dendorse,
                   $p.ibranch, $p.mready, $p.mstable, $p.mcompensate, $p.madjcom,
                   $p.mbusiness, $p.mresearch, $p.mcapital, $p.mbus_rule, $p.minvest, $p.maintain,
                   $p.fcomp_class, $p.fcomp_class_last, $p.fdiscount,
                   $p.mdmg_discount, $p.mlia_discount, $p.ibatch_no, $p.icorps,
                   $p.ileader, $p.iquota, $p.icomp_in, $p.ibranch_in, $p.icomp_at,
                   $p.ibranch_at, $itmp_policy, $ipay_way, $icar_flag, $qnext_year, $iinstall,
                   $p.iofficer_prmt, $p.iquota_prmt, $p.ileader_prmt,
                   $p.irate_type, $p.bzfrom, $p.iroute_comm, $p.icomm_obj, $p.qprovision, $p.dtrans_b2b, $p.dcreate, $p.isecond_hand,
                   $p.icard_main, $p.qdrunk_driving, $p.isign, $p.feply, $p.aemail_eply, $p.dcreate_eply, $p.iscan_no, $p.dtply_begin, $p.dtply_end,
                   $p.tmobile_eply, $p.ireg_no, $p.dnotifyornot, $p.fsign_status_edr, $p.funder_chk_edr, $p.feterms, $iprog, $ftrans_third, $p.qviolate);

        printf("2:SQLCODE[%d]\n", SQLCODE);
        /***** policy recovery *****/
        printf("policy_bak1\n");
        $SELECT ipolicy, icard, ixxcard, fassured, iassured, iassured_ext, nassured,
            ilicense, fsex, fmarriage, nuser, ibenef,
            nbenef, aassured, itel, apayment, iply_area, nbrand_abbr,
            ncar_abbr, qcylinder, iengine, ibody, itag, mcar_price,
            nequipment, flimit, pdmg_align, pbrg_align, plia_align,
            iabn_type, fpass, ipass, dpass, ffac, dfac, fcut,
            fcal_way, pdmg_factor, pbrg_factor, qpt,
            fpt, psex_age, psex_age_damage, plia_acc, pdmg_acc, fhuman, fcomp_24, iemail,
            aassured_zip, apayment_zip,
            lia_class, dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd, itel_night, mobil_phone,
            iext_policy, qpro_month, mkilo_ply, mkilo_edr, irisk, irelative_ext,
            napplicant, dbirth, dissue,
            iextra_charge, gextra_charge, pextra_charge,
            iquery_num_damage, iquery_num, introducer, mequipment,
            survey_num, bound_num, abnormal_num, iapplicant, iroute, qlia_acc_sum, qdmg_acc_sum, itel_night,
            fapplicant, fsex_appl, dbirth_appl, itel_appl, ndeputy_appl, nrelation_appl, ndeputy_assured, idm_number,
            iroute_prop, iroute_accept, iins_kit, mcover_limit, iassured_cntry, iapplicant_cntry,
            fcharge_type, fequipment1, fequipment2, fequipment3, fequipment4, fequipment5, fequipment6, fequipment9, nequipment9,
            punknown_acc, iquery_num_unknown, qunknown_acc_sum, nassured_cntry, napplicant_cntry,
            foccup, noccup, applicant_foccup, applicant_noccup, iowner, nowner, dbirth_owner,
            tmobile_appl, aemail_appl,dinstall, isequence, ainstall_zip, ainstall
      INTO  $p.ipolicy, $p.icard, $p.ixxcard, $p.fassured, $p.iassured, $p.iassured_ext, $p.nassured,
            $p.ilicense, $p.fsex, $p.fmarriage, $p.nuser, $p.ibenef,
            $p.nbenef, $p.aassured, $p.itel, $p.apayment, $p.iply_area, $p.nbrand_abbr,
            $p.ncar_abbr, $p.qcylinder, $p.iengine, $p.ibody, $p.itag, $p.mcar_price,
            $p.nequipment, $p.flimit, $p.pdmg_align, $p.pbrg_align, $p.plia_align,
            $p.iabn_type, $p.fpass, $p.ipass, $p.dpass, $p.ffac, $p.dfac, $p.fcut,
            $p.fcal_way, $p.pdmg_factor, $p.pbrg_factor, $p.qpt,
            $p.fpt, $p.psex_age, $p.psex_age_damage, $p.plia_acc, $p.pdmg_acc, $p.fhuman,
            $p.fcomp_24, $iemail,
            $p.aassured_zip, $p.apayment_zip,
            $p.lia_class, $p.dmg_acc_1st, $p.dmg_acc_2nd, $p.dmg_acc_3rd, $p.itel_night, $p.mobil_phone,
            $p.iext_policy, $p.qpro_month, $p.mkilo_ply, $p.mkilo_edr, $p.irisk, $p.irelative_ext,
            $p.napplicant, $p.dbirth, $p.dissue,
            $p.iextra_charge, $p.gextra_charge, $p.pextra_charge,
            $p.iquery_num_damage, $p.iquery_num, $introducer, $p.mequipment,
            $p.survey_num, $p.bound_num, $p.abnormal_num, $p.iapplicant, $p.iroute, $p.qlia_acc_sum, $p.qdmg_acc_sum, $p.itel_night,
            $p.fapplicant, $p.fsex_appl, $p.dbirth_appl, $p.itel_appl, $p.ndeputy_appl, $p.nrelation_appl, $p.ndeputy_assured, $p.idm_number,
            $p.iroute_prop, $p.iroute_accept, $p.iins_kit, $p.mcover_limit, $p.iassured_cntry, $p.iapplicant_cntry,
            $p.fcharge_type, $p.fequipment1, $p.fequipment2, $p.fequipment3, $p.fequipment4, $p.fequipment5, $p.fequipment6, $p.fequipment9, $p.nequipment9,
            $p.punknown_acc, $p.iquery_num_unknown, $p.qunknown_acc_sum, $p.nassured_cntry, $p.napplicant_cntry,
            $p.foccup, $p.noccup, $p.applicant_foccup, $p.applicant_noccup, $p.iowner, $p.nowner, $p.dbirth_owner,
            $p.tmobile_appl, $p.aemail_appl,$p.dinstall, $p.isequence, $p.ainstall_zip, $p.ainstall 
       FROM policy_bak 
      WHERE iendorse = $old_iendorse;
        printf("policy_bak2\n");
        if (SQLCODE == SQLNOTFOUND)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          if (exitsub(reply, M_CA_NPLYREL_BAK) == True)
            return M_CA_NPLYREL_BAK;
          else
            return apiRC;
        }
        $WHENEVER SQLERROR GOTO errexit;

        if (risnull(SQLCHAR, p.itel_night) == 1)
          strcpy(p.itel_night, " ");
        if (risnull(SQLCHAR, p.mobil_phone) == 1)
          strcpy(p.mobil_phone, " ");

        $INSERT INTO policy(ipolicy, icard, ixxcard, fassured, iassured, nassured,
                            ilicense, fsex, fmarriage, nuser, ibenef, nbenef,
                            aassured, itel, apayment, iply_area, nbrand_abbr, ncar_abbr,
                            qcylinder, iengine, ibody, itag, mcar_price, nequipment,
                            flimit, pdmg_align, pbrg_align, plia_align,
                            iabn_type, fpass, ipass, dpass, ffac, dfac,
                            fcut, fcal_way, pdmg_factor, pbrg_factor,
                            qpt, fpt, psex_age, psex_age_damage, plia_acc, pdmg_acc, fhuman, fcomp_24, iemail,
                            aassured_zip, apayment_zip,
                            lia_class, dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd,
                            iext_policy, qpro_month, mkilo_ply, mkilo_edr, irisk, irelative_ext,
                            napplicant, dbirth, dissue,
                            iextra_charge, gextra_charge, pextra_charge,
                            iquery_num_damage, iquery_num, introducer, mequipment,
                            survey_num, bound_num, abnormal_num, iapplicant, iroute, qlia_acc_sum, qdmg_acc_sum, itel_night, mobil_phone,
                            fapplicant, fsex_appl, dbirth_appl, itel_appl, ndeputy_appl, nrelation_appl, ndeputy_assured, idm_number,
                            iroute_prop, iroute_accept, iins_kit, mcover_limit, iassured_cntry, iapplicant_cntry, fcharge_type,
                            fequipment1, fequipment2, fequipment3, fequipment4, fequipment5, fequipment6, fequipment9, nequipment9,
                            punknown_acc, iquery_num_unknown, qunknown_acc_sum, nassured_cntry, napplicant_cntry,
                            foccup, noccup, applicant_foccup, applicant_noccup, iowner, nowner, dbirth_owner,
                            tmobile_appl, aemail_appl, dinstall,isequence,ainstall_zip,ainstall)
            VALUES($p.ipolicy, $p.icard, $p.ixxcard, $p.fassured, $p.iassured,
                   $p.nassured, $p.ilicense, $p.fsex, $p.fmarriage,
                   $p.nuser, $p.ibenef, $p.nbenef, $p.aassured, $p.itel,
                   $p.apayment, $p.iply_area, $p.nbrand_abbr, $p.ncar_abbr,
                   $p.qcylinder, $p.iengine, $p.ibody, $p.itag, $p.mcar_price,
                   $p.nequipment, $p.flimit, $p.pdmg_align, $p.pbrg_align,
                   $p.plia_align, $p.iabn_type, $p.fpass, $p.ipass, $p.dpass,
                   $p.ffac, $p.dfac, $p.fcut, $p.fcal_way, $p.pdmg_factor,
                   $p.pbrg_factor, $p.qpt, $p.fpt, $p.psex_age, $p.psex_age_damage, $p.plia_acc,
                   $p.pdmg_acc, $p.fhuman, $p.fcomp_24, $iemail,
                   $p.aassured_zip, $p.apayment_zip,
                   $p.lia_class, $p.dmg_acc_1st, $p.dmg_acc_2nd, $p.dmg_acc_3rd,
                   $p.iext_policy, $p.qpro_month, $p.mkilo_ply, $p.mkilo_edr, $p.irisk, $p.irelative_ext,
                   $p.napplicant, $p.dbirth, $p.dissue,
                   $p.iextra_charge, $p.gextra_charge, $p.pextra_charge,
                   $p.iquery_num_damage, $p.iquery_num, $introducer, $p.mequipment,
                   $p.survey_num, $p.bound_num, $p.abnormal_num, $p.iapplicant, $p.iroute, $p.qlia_acc_sum, $p.qdmg_acc_sum, $p.itel_night,
                   $p.mobil_phone, $p.fapplicant, $p.fsex_appl, $p.dbirth_appl, $p.itel_appl, $p.ndeputy_appl,
                   $p.nrelation_appl, $p.ndeputy_assured, $p.idm_number,
                   $p.iroute_prop, $p.iroute_accept, $p.iins_kit, $p.mcover_limit, $p.iassured_cntry, $p.iapplicant_cntry,
                   $p.fcharge_type, $p.fequipment1, $p.fequipment2, $p.fequipment3, $p.fequipment4, $p.fequipment5, $p.fequipment6, $p.fequipment9, $p.nequipment9,
                   $p.punknown_acc, $p.iquery_num_unknown, $p.qunknown_acc_sum, $p.nassured_cntry, $p.napplicant_cntry,
                   $p.foccup, $p.noccup, $p.applicant_foccup, $p.applicant_noccup, $p.iowner, $p.nowner, $p.dbirth_owner,
                   $p.tmobile_appl, $p.aemail_appl,$p.dinstall, $p.isequence, $p.ainstall_zip, $p.ainstall );

        printf("3:SQLCODE[%d]\n", SQLCODE);
        $UPDATE assured_vs_ply
            set(nassured, itag, ibody, iassured, iengine) = ($p.nassured, $p.itag, $p.ibody, $p.iassured, $p.iengine)
                WHERE ipolicy = $p.ipolicy;

        printf("4:SQLCODE[%d]\n", SQLCODE);

        /*1101021003_SC2 �����������a�ȪA��P�t�θ���p����T
        => ��Ū���B����s �ȪA��*/
        /*
        lRtnCode = cu_add_upd_customer_phone_data(p.iassured,p.iassured_ext,
                                                  p.itel, p.itel_night, p.mobil_phone, p.iemail);
        if (lRtnCode != M_CM_OK)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          if (exitsub (reply, lRtnCode) == True)
            return lRtnCode;
          else
            return apiRC;
        }*/

        $WHENEVER SQLERROR GOTO errexit;

/***** ply_ins_type recovery *****/
#ifdef GCAR
        sprintf(prep_stmt, "SELECT ipolicy, iins_type, minjured_cover,"
                           "       mdeath_cover, mdamage_cover, mdeduct, mins_premium,"
                           "       qserial, fedr_status, dendorse, dedr_begin, dedr_end,"
                           "       iendorse_old, pcommission, mcommission, pagent, magent,"
                           "       mdiscount, drate_ym, pdiscount, mprem,"
                           "       mpure_prem , iproduct,"
                           "       qday, mexpense, mexp_disc, provision,"
                           "       irate, adjust_rate, mins_premium_n, mpure_prem_n, mprem_n,"
                           "       safe_rate, manage_rate, educated_rate, deviation_rate, "
                           "       pextra_charge, pbusiness, psex_age, pshipping, mdrunk_prem, mdrunk_pure_prem,"
                           "       pcar_price,dtedr_begin, dtedr_end,mviolate_prem, mviolate_pure_prem "
                           "  FROM ply_ins_type_bak"
                           " WHERE iendorse = '%s'",
                old_iendorse);
#else
        sprintf(prep_stmt, "SELECT ipolicy, iins_type, minjured_cover,"
                           "       mdeath_cover, mdamage_cover, mdeduct, mins_premium,"
                           "       qserial, fedr_status, dendorse, dedr_begin, dedr_end,"
                           "       iendorse_old, pcommission, mcommission, pagent, magent,"
                           "       mdiscount, drate_ym, pdiscount, mprem,"
                           "       mpure_prem , iproduct,"
                           "       qday, mexpense, mexp_disc, provision"
                           "  FROM ply_ins_type_bak"
                           " WHERE iendorse = '%s'",
                old_iendorse);
#endif

        $PREPARE prep1 FROM $prep_stmt;
        $DECLARE uply1 CURSOR FOR prep1;

        if (SQLCODE == SQLNOTFOUND)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          if (exitsub(reply, M_CA_NPLYREL_BAK) == True)
            return M_CA_NPLYREL_BAK;
          else
            return apiRC;
        }
        $WHENEVER SQLERROR GOTO errexit;
        $OPEN uply1;
        for (;;)
        {
#ifdef GCAR
          $FETCH uply1
              INTO $pp.ipolicy,
              $pp.iins_type, $pp.minjured_cover,
              $pp.mdeath_cover, $pp.mdamage_cover, $pp.mdeduct,
              $pp.mins_premium, $pp.qserial,
              $pp.fedr_status, $pp.dendorse, $pp.dedr_begin,
              $pp.dedr_end, $pp.iendorse,
              $pp.pcommission, $pp.mcommission, $pp.pagent, $pp.magent,
              $pp.mdiscount, $pp.drate_ym, $pp.pdiscount, $pp.mprem,
              $pp.mpure_prem, $pp.iproduct,
              $pp.qday, $pp.mexpense, $pp.mexp_disc, $pp.provision,
              $pp.irate, $pp.adjust_rate, $pp.mins_premium_n, $pp.mpure_prem_n, $pp.mprem_n,
              $pp.safe_rate, $pp.manage_rate, $pp.educated_rate, $pp.deviation_rate,
              $pp.pextra_charge, $pp.pbusiness, $pp.psex_age, $pp.pshipping, $pp.mdrunk_prem, $pp.mdrunk_pure_prem,
              $pp.pcar_price, $pp.dtedr_begin, $pp.dtedr_end, $pp.mviolate_prem, $pp.mviolate_pure_prem;
#else
          $FETCH uply1
              INTO $pp.ipolicy,
              $pp.iins_type, $pp.minjured_cover,
              $pp.mdeath_cover, $pp.mdamage_cover, $pp.mdeduct,
              $pp.mins_premium, $pp.qserial,
              $pp.fedr_status, $pp.dendorse, $pp.dedr_begin,
              $pp.dedr_end, $pp.iendorse,
              $pp.pcommission, $pp.mcommission, $pp.pagent, $pp.magent,
              $pp.mdiscount, $pp.drate_ym, $pp.pdiscount, $pp.mprem,
              $pp.mpure_prem, $pp.iproduct,
              $pp.qday, $pp.mexpense, $pp.mexp_disc, $pp.provision;
#endif

          if (SQLCODE != 0)
            break;

#ifdef GCAR
          $INSERT INTO ply_ins_type(ipolicy, iins_type, minjured_cover,
                                    mdeath_cover, mdamage_cover,
                                    mdeduct, mins_premium, qserial,
                                    fedr_status, dendorse, dedr_begin,
                                    dedr_end, iendorse, pcommission, mcommission,
                                    pagent, magent, mdiscount, drate_ym,
                                    pdiscount, mprem, mpure_prem, iproduct,
                                    qday, mexpense, mexp_disc, provision,
                                    irate, adjust_rate, mins_premium_n, mpure_prem_n, mprem_n,
                                    safe_rate, manage_rate, educated_rate, deviation_rate, pextra_charge, pbusiness,
                                    psex_age, pshipping, mdrunk_prem, mdrunk_pure_prem, pcar_price, dtedr_begin, dtedr_end,
                                    mviolate_prem, mviolate_pure_prem)
              VALUES($pp.ipolicy, $pp.iins_type, $pp.minjured_cover,
                     $pp.mdeath_cover, $pp.mdamage_cover,
                     $pp.mdeduct, $pp.mins_premium, $pp.qserial,
                     $pp.fedr_status, $pp.dendorse, $pp.dedr_begin,
                     $pp.dedr_end, $pp.iendorse, $pp.pcommission,
                     $pp.mcommission, $pp.pagent, $pp.magent, $pp.mdiscount,
                     $pp.drate_ym,
                     $pp.pdiscount, $pp.mprem, $pp.mpure_prem, $pp.iproduct,
                     $pp.qday, $pp.mexpense, $pp.mexp_disc, $pp.provision,
                     $pp.irate, $pp.adjust_rate, $pp.mins_premium_n, $pp.mpure_prem_n, $pp.mprem_n,
                     $pp.safe_rate, $pp.manage_rate, $pp.educated_rate, $pp.deviation_rate,
                     $pp.pextra_charge, $pp.pbusiness, $pp.psex_age, $pp.pshipping, $pp.mdrunk_prem, $pp.mdrunk_pure_prem,
                     $pp.pcar_price, $pp.dtedr_begin, $pp.dtedr_end, $pp.mviolate_prem, $pp.mviolate_pure_prem);
#else
          $INSERT INTO ply_ins_type(ipolicy, iins_type, minjured_cover,
                                    mdeath_cover, mdamage_cover,
                                    mdeduct, mins_premium, qserial,
                                    fedr_status, dendorse, dedr_begin,
                                    dedr_end, iendorse, pcommission, mcommission,
                                    pagent, magent, mdiscount, drate_ym,
                                    pdiscount, mprem, mpure_prem, iproduct,
                                    qday, mexpense, mexp_disc, provision)
              VALUES($pp.ipolicy, $pp.iins_type, $pp.minjured_cover,
                     $pp.mdeath_cover, $pp.mdamage_cover,
                     $pp.mdeduct, $pp.mins_premium, $pp.qserial,
                     $pp.fedr_status, $pp.dendorse, $pp.dedr_begin,
                     $pp.dedr_end, $pp.iendorse, $pp.pcommission,
                     $pp.mcommission, $pp.pagent, $pp.magent, $pp.mdiscount,
                     $pp.drate_ym,
                     $pp.pdiscount, $pp.mprem, $pp.mpure_prem, $pp.iproduct,
                     $pp.qday, $pp.mexpense, $pp.mexp_disc, $pp.provision);
#endif

          printf("5:SQLCODE[%d]\n", SQLCODE);
        }

/***** ply_ins_cover recovery *****/
#ifdef CA_CONS

        strcpy(sDbname, "");
        strcpy(sColumn, "iendorse");
        strcpy(sTable, "ply_ins_cover_bak");

        IfirstPlyInsCover = get_ply_ins_cover(sDbname, sTable, sColumn, old_iendorse, &rtncode, v_sMsg);

        if (rtncode != M_CM_OK)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          if (exitsub(reply, rtncode) == True)
            return rtncode;
          else
            return apiRC;
        }
        $WHENEVER SQLERROR GOTO errexit;

        strcpy(sColumn, "ipolicy");
        strcpy(sTable, "ply_ins_cover");
        strcpy(sIinsType, "");
        rtncode = insert_ply_ins_cover(sDbname, sTable, sColumn, ipolicy, IfirstPlyInsCover, sIinsType, v_sMsg);
        printf("6:SQLCODE[%d]\n", SQLCODE);
        if (rtncode != M_CM_OK)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          if (exitsub(reply, rtncode) == True)
            return rtncode;
          else
            return apiRC;
        }

#endif

        $WHENEVER SQLERROR GOTO errexit;
/***** ply_ins_assured recovery *****/
#ifdef CA_ONE

        strcpy(sDbname, "");
        strcpy(sColumn, "iendorse");
        strcpy(sTable, "ply_ins_assured_bak");

        IfirstPlyInsAssured = get_ply_ins_assured(sDbname, sTable, sColumn, old_iendorse, &rtncode, v_sMsg);

        if (rtncode != M_CM_OK)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          if (exitsub(reply, rtncode) == True)
            return rtncode;
          else
            return apiRC;
        }
        $WHENEVER SQLERROR GOTO errexit;

        strcpy(sColumn, "ipolicy");
        strcpy(sTable, "ply_ins_assured");
        strcpy(sIinsType, "");

        rtncode = insert_ply_ins_assured(sDbname, sTable, sColumn, ipolicy, IfirstPlyInsAssured, sIinsType, v_sMsg);
        printf("7:SQLCODE[%d]\n", SQLCODE);
        if (rtncode != M_CM_OK)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          if (exitsub(reply, rtncode) == True)
            return rtncode;
          else
            return apiRC;
        }

#endif

        /* car9903041 ���s�t�λP���O�B�ɨ�����s�� */
        $WHENEVER SQLERROR GOTO errexit;
        /***** ca_ply_bound recovery *****/
        strcpy(sColumn, "iendorse");
        strcpy(sTable, "ca_ply_bound_bak");

        rtncode = get_ca_ply_bound(sDbname, sTable, sColumn, old_iendorse, p.ibound, v_sMsg);
        if (rtncode != M_CM_OK)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          if (exitsub(reply, rtncode) == True)
            return rtncode;
          else
            return apiRC;
        }
        $WHENEVER SQLERROR GOTO errexit;

        strcpy(sColumn, "ipolicy");
        strcpy(sTable, "ca_ply_bound");

        rtncode = insert_ca_ply_bound(sDbname, sTable, sColumn, ipolicy, p.ibound, v_sMsg);
        if (rtncode != M_CM_OK)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          if (exitsub(reply, rtncode) == True)
            return rtncode;
          else
            return apiRC;
        }

        $WHENEVER SQLERROR GOTO errexit;
        /*** ca_pa_ply recovery ***/
        $DECLARE uply2 CURSOR FOR
            SELECT ipolicy,
            iins_type, iinsurant, ninsurant,
            dbirth, ainsurant, iins_scope, icareer,
            mins_amt, mins_premium, mpure_prem,
            pcommission, mcommission,
            pagent, magent,
            pdiscount, mdiscount,
            dpolicy,
            iendorse_old, dendorse, dedr_begin, dedr_end, fedr_status,
            napplicant, relation_appl,
            nbeneficiary, relation_bene,
            daily_pay, mr_ins_prem, mr_pure_prem, tbenef, abenef_zip, abenef INTO $pa.ipolicy, $pa.iins_type, $pa.cIinsurant, $pa.cNinsurant,
            $pa.lDbirth, $pa.cAinsurant, $pa.cIins_scope, $pa.cIcareer,
            $pa.lMins_amt, $pa.lMins_premium, $pa.lMpure_prem,
            $pa.dPcommission, $pa.lMcommission,
            $pa.dPagent, $pa.lMagent,
            $pa.dPdiscount, $pa.lMdiscount,
            $pa.dpolicy,
            $pa.iendorse_old, $pa.dendorse, $pa.dedr_begin, $pa.dedr_end, $pa.fedr_status,
            $pa.cNapplicant, $pa.cRelation_appl,
            $pa.cNbeneficiary, $pa.cRelation_bene,
            $pa.lDaily_pay, $pa.lMr_ins_prem, $pa.lMr_pure_prem, $pa.cTbenef, $pa.cAbenef_zip, $pa.cAbenef FROM ca_pa_ply_bak WHERE iendorse = $old_iendorse;

        if (SQLCODE == SQLNOTFOUND)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          if (exitsub(reply, M_CA_NPLYREL_BAK) == True)
            return M_CA_NPLYREL_BAK;
          else
            return apiRC;
        }
        $WHENEVER SQLERROR GOTO errexit;
        $OPEN uply2;
        for (;;)
        {
          $FETCH uply2;
          if (SQLCODE != 0)
            break;

          $INSERT INTO ca_pa_ply(ipolicy, iins_type, iinsurant, ninsurant,
                                 dbirth, ainsurant, iins_scope, icareer,
                                 mins_amt, mins_premium, mpure_prem,
                                 pcommission, mcommission,
                                 pagent, magent,
                                 pdiscount, mdiscount,
                                 dpolicy,
                                 iendorse, dendorse, dedr_begin, dedr_end, fedr_status,
                                 napplicant, relation_appl,
                                 nbeneficiary, relation_bene,
                                 daily_pay, mr_ins_prem, mr_pure_prem, tbenef, abenef_zip, abenef)
              VALUES($pa.ipolicy, $pa.iins_type, $pa.cIinsurant, $pa.cNinsurant,
                     $pa.lDbirth, $pa.cAinsurant, $pa.cIins_scope, $pa.cIcareer,
                     $pa.lMins_amt, $pa.lMins_premium, $pa.lMpure_prem,
                     $pa.dPcommission, $pa.lMcommission,
                     $pa.dPagent, $pa.lMagent,
                     $pa.dPdiscount, $pa.lMdiscount,
                     $pa.dpolicy,
                     $pa.iendorse_old, $pa.dendorse, $pa.dedr_begin, $pa.dedr_end, $pa.fedr_status,
                     $pa.cNapplicant, $pa.cRelation_appl,
                     $pa.cNbeneficiary, $pa.cRelation_bene,
                     $pa.lDaily_pay, $pa.lMr_ins_prem, $pa.lMr_pure_prem, $pa.cTbenef, $pa.cAbenef_zip, $pa.cAbenef);
        }
        printf("7:SQLCODE[%d]\n", SQLCODE);

        $DELETE FROM ao_prem_return WHERE iendorse = $old_iendorse;
        $DELETE FROM ao_stl_notes_info WHERE inum1 = $old_iendorse;
        $DELETE FROM ply_relation_bak WHERE iendorse = $old_iendorse;
        $DELETE FROM policy_bak WHERE iendorse = $old_iendorse;
#ifdef CA_CONS
        $DELETE FROM ply_ins_cover_bak WHERE iendorse = $old_iendorse;
#endif
#ifdef CA_ONE
        $DELETE FROM ply_ins_assured_bak WHERE iendorse = $old_iendorse;
#endif
        $DELETE FROM ply_ins_type_bak WHERE iendorse = $old_iendorse;
        $DELETE FROM ca_pa_ply_bak WHERE iendorse = $old_iendorse;
        /* car9903041 ���s�t�λP���O�B�ɨ�����s�� */
        $DELETE FROM ca_ply_bound_bak WHERE iendorse = $old_iendorse;

        $DELETE FROM edr_relation WHERE iendorse = $old_iendorse;

        /* 1020111001_C2 ���O�X����@�~ */
        /* �i�R�������A�ݧR���@�γ����ɸ�� */
        $DELETE FROM cm_pre_receive WHERE ipre_rcv = $old_iendorse AND iins_kind = $p.fcard_class AND ipre_end = ' ';

        $UPDATE ca_comp_return SET(iendorse, dendorse, note) = ('', NULL, 'A')
            WHERE ipolicy = : p.ipolicy
                                  AND iendorse = : old_iendorse;

        {
          long iRtnCode;
          $char sTmpPolicy1[POLICY_NUM_1], sTmpPolicy2[POLICY_NUM_2];
          iRtnCode = split_policy(p.ipolicy, sTmpPolicy1, sTmpPolicy2);
          if (iRtnCode != M_CM_OK)
          {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            exitsub(reply, iRtnCode);
            return iRtnCode;
          }
          $WHENEVER SQLERROR GOTO errexit;
          iRtnCode = cm_credit_pay_delete_car(sTmpPolicy1, sTmpPolicy2, old_iendorse);
          if (iRtnCode != M_CM_OK)
          {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            exitsub(reply, iRtnCode);
            return iRtnCode;
          }
        }
        $WHENEVER SQLERROR GOTO errexit;
        $DELETE FROM endorsement WHERE iendorse = $old_iendorse;
        $DELETE FROM endorsement_note WHERE iendorse = $old_iendorse;

        $DECLARE acur CURSOR FOR
            SELECT iendorse
                INTO $old_iendorse
                    FROM edr_ins_type
                        WHERE iendorse = $old_iendorse
                            AND iedr_type = "03";
        $OPEN acur;
        for (;;)
        {
          $FETCH acur;
          if (SQLCODE != 0)
            break;
          flag_exist = 1;
        }
        $CLOSE acur;
        $FREE acur;
        if (flag_exist == 1)
        {
          for (k = 0; k < j; k++)
          {
            sprintf(prep_stmt, "DELETE FROM %s:reject_client WHERE %s",
                    list[k].dbname, "iengine=? ");
            $PREPARE bcur from $prep_stmt;
            $EXECUTE bcur USING $iengine;
          }
        }

#ifdef CA_CONS
        $DELETE FROM edr_ins_cover WHERE iendorse = $old_iendorse;
#endif

#ifdef CA_ONE
        $DELETE FROM edr_ins_assured WHERE iendorse = $old_iendorse;
#endif

        /* car9903041 ���s�t�λP���O�B�ɨ�����s�� */
        $DELETE FROM ca_edr_bound WHERE iendorse = $old_iendorse;

        $DELETE FROM edr_ins_type WHERE iendorse = $old_iendorse;
        $DELETE FROM ca_pa_edr WHERE iendorse = $old_iendorse;
        if (fedr_class[0] == '7')
        {
          $UPDATE ca_change_tag_ori
              SET iendorse = '',
                  fstatus = 'N',
                  nerror = '',
                  dupdate = current year to second
                      WHERE ipolicy = $p.ipolicy
                                          AND iendorse = $old_iendorse
                          AND fstatus = 'Y';
        }
        $INSERT INTO reusible_num(dwritten, qwritten_num)
            VALUES($dendorse, $old_iendorse);

        printf("bef old_iendorse[%s]\n", old_iendorse);
        rc = bk_edr_last(old_iendorse);
        if (rc != TRUE)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          exitsub(reply, rc);
          return rc;
        }

        if (fedr_class[0] == '2' ||
            fedr_class[0] == '8') /* �L�� */
        {
          rc = update_reject_policy(p.ipolicy, userid);
          if (rc != M_CM_OK)
          {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            exitsub(reply, rc);
            return rc;
          }
        }

        /*1080730005_SC2 �q�lñ�p���ظm�@�~*/
        if (strlen(trim(iscan_no_edr)) > 0)
        {
          $UPDATE cm_esign_data
              SET fstatus = '0',
                  iendorse = '',
                  iupdate = $userid,
                  dupdate = current
                      WHERE iscan_no = $iscan_no_edr
                          AND iendorse = $old_iendorse;
        }
          
        /* 1110607001_SC1 �ظmE�O�����t�� */ 
        printf("--trace1 iquote[%s]\n ",iquote);
        
        if (iquote[0] !=' ' && iquote[0] != '\0')
        {
            printf("--trace CVR\n");
            /*100 (������) ; 405 (�w�n�O) */
            $Update newa00:endorse_master
                SET icurrent_state =  CASE WHEN iapproval_status  = '500' THEN 100
                                           WHEN iapproval_status  = '510' THEN 405
                                           ELSE icurrent_state
                                           END ,
                    iendorse = ' '
              Where iquote  = $iquote ;

        }  

        $WHENEVER SQLERROR GOTO errexit;
      }
    }
    else
    { /* end if (old_iendorse[5]!='Y') */
      $BEGIN WORK;

      $WHENEVER SQLERROR GOTO errexit;
      sprintf(prep_stmt, "SELECT fpass,ffac FROM %s:%s %s",
              dbname_tp, "abn_edr_relation",
              "WHERE iabnormal= ? ");
      $PREPARE STMT_CUR4 FROM $prep_stmt;
      $DECLARE cur4 CURSOR FOR STMT_CUR4;
      $OPEN cur4 USING $old_iendorse;
      $FETCH cur4 INTO $fpass, $ffac;
      if (SQLCODE == SQLNOTFOUND)
      {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        $CLOSE cur4;
        $FREE cur4;
        if (exitsub(reply, M_CA_NABN_EDR_REL) == True)
          return M_CA_NABN_EDR_REL;
        else
          return apiRC;
      }
      $CLOSE cur4;
      $FREE cur4;

      if (fpass[0] == 'P')
      {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        if (exitsub(reply, M_CA_EDR_DONE) == True)
          return M_CA_EDR_DONE;
        else
          return apiRC;
      }
      $WHENEVER SQLERROR GOTO errexit;
      if (ffac[0] != '\0' && ffac[0] != ' ')
      {
#ifdef _CODE860612
        rtn_code = ca_fac_edrcheck(old_iendorse, "", NULL, NULL, 0, ffac, 'D', iestimate_r);
#else
        if (ffac[0] == 'N')
          rtn_code = ca_fac_edrcheck(old_iendorse, "", NULL, NULL, 0, ffac, 'D', iestimate_r);
        else
          rtn_code = ca_fac_edrcheck("", old_iendorse, NULL, NULL, 0, ffac, 'D', iestimate_r);
#endif
        if (rtn_code != M_CA_FAC_CANCEL)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          exitsub(reply, rtn_code);
          return rtn_code;
        }
      }

      $WHENEVER SQLERROR GOTO errexit;
      /*-----------------------------*/
      /*   delete abn_edr_relation   */
      /*-----------------------------*/
      sprintf(prep_stmt, "DELETE FROM %s:abn_edr_relation "
                         "         WHERE iabnormal=?",
              dbname_tp);
      $PREPARE del_id1 FROM $prep_stmt;
      $EXECUTE del_id1 USING $old_iendorse;

      /*-----------------------------*/
      /*   delete abnormal_edr       */
      /*-----------------------------*/
      sprintf(prep_stmt, "DELETE FROM %s:abnormal_edr "
                         "         WHERE iabnormal=?",
              dbname_tp);
      $PREPARE del_id2 FROM $prep_stmt;
      $EXECUTE del_id2 USING $old_iendorse;

#ifdef CA_CONS
      sprintf(prep_stmt, "DELETE FROM %s:abn_edr_ins_cover "
                         "         WHERE iabnormal=?",
              dbname_tp);
      $PREPARE del_id21 FROM $prep_stmt;
      $EXECUTE del_id21 USING $old_iendorse;
#endif

#ifdef CA_ONE
      sprintf(prep_stmt, "DELETE FROM %s:abn_edr_ins_assured "
                         "         WHERE iabnormal=?",
              dbname_tp);
      $PREPARE del_id22 FROM $prep_stmt;
      $EXECUTE del_id22 USING $old_iendorse;
#endif

      /* car9903041 ���s�t�λP���O�B�ɨ�����s�� */
      sprintf(prep_stmt, "DELETE FROM %s:abn_ca_edr_bound "
                         "         WHERE iabnormal=?",
              dbname_tp);
      $PREPARE del_id23 FROM $prep_stmt;
      $EXECUTE del_id23 USING $old_iendorse;

      /*-----------------------------*/
      /*   delete abn_edr_ins_type   */
      /*-----------------------------*/
      sprintf(prep_stmt, "DELETE FROM %s:abn_edr_ins_type "
                         "         WHERE iabnormal=?",
              dbname_tp);
      $PREPARE del_id3 FROM $prep_stmt;
      $EXECUTE del_id3 USING $old_iendorse;

      /*-----------------------------*/
      /*   delete abn_edr_ins_type   */
      /*-----------------------------*/
      sprintf(prep_stmt, "DELETE FROM %s:abn_ca_pa_edr "
                         "         WHERE iabnormal=?",
              dbname_tp);
      $PREPARE del_id33 FROM $prep_stmt;
      $EXECUTE del_id33 USING $old_iendorse;

      $delete from cm_risk_preview where iref_num = $old_iendorse;

    } /* end of else if (old_iendorse[5]!='Y') */

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l", M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    {
      $WHENEVER SQLERROR CONTINUE;
      $ROLLBACK WORK;
      return apiRC;
    }

    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;
    return api_OKComplete;
  } /* end if option_d == D */
  else
  {
    if (exitsub(reply, M_CM_WRONG_OPTION) == True)
      return M_CM_WRONG_OPTION;
    else
      return apiRC;
  }

errexit:
  printf("{car401_delete_exec.0010}: SQLCODE:[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0)
    MsgCode = SQLCODE;
  if (exitsub(reply, MsgCode) == True)
    return MsgCode;
  else
    return apiRC;
} /* car401_delete_exec */
