/************************************************/
/*                                              */
/*   PROGRAM : car169m01s.ec			*/
/*   Author  : 061476   			*/
/*   Date    : 2020/11/02			*/
/*   Name    : �`�����q������ 		*/
/*                                              */
/************************************************/
     
#include <stdio.h>
#include <stdlib.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "ISvar.h"
#include "cmnmsgs.h" /* need to take off when create new error messages */
#include "safeclib.h"

int *iGetChinesePos();

time_t tstart;
float  tused=0;
long   msg_code;

long car169(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{printf("into car169\n");
 	long rtncode;
 	long car169_query(),car169_update();
 	char option;
 	msg_code = 0;

 	cm_buf_init_x(command);
 	cm_buf_get("%c",&option);

 	switch(option)
 	{
  		case 'A':
           		rtncode=car169_check_user(reply);
           		break;
  		case 'Q':
           		rtncode=car169_query(reply);
           		break;
           	case 'U':
           		rtncode=car169_update(reply,command,com_len);
           		break;
  		default :
           	if (exitsub(reply,M_CM_WRONG_OPTION) == True)
              	return M_CM_WRONG_OPTION;
           	return apiRC;
 	}
 	return(rtncode);
}
/******************************************************/
/*   check user iquota                                */
/******************************************************/
long car169_check_user(reply)
{printf("into car169_check_user\n");
    int    tmp_len;
    $char  DBName[DBNAME], userid[11], iupcomp[3];
    $int   cnt=0;

    cm_buf_get ("%s %s", DBName, userid);
    
    $WHENEVER SQLERROR GOTO errexit;
    
    if(db_select(DBName) == False)
	    return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $SELECT count(*) INTO $cnt
       FROM officer a, branch b 
      WHERE a.ibranch  = b.ibranch
        AND b.ibranch  = b.iaccount_branch
        AND a.iofficer = $userid;

    if (SQLCODE == SQLNOTFOUND)
        cnt = 0;
    
    $SELECT c.iupcomp
       INTO $iupcomp
       FROM officer a, sa_branch_type b, branch c
      WHERE a.iquota = b.ibranch
        AND b.iply_branch = c.ibranch
        AND a.iofficer = $userid;

    if (SQLCODE == SQLNOTFOUND) goto errexit;

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %d %s",M_CM_OK,cnt,iupcomp);
    
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False) 
        return apiRC;
    else 
        return api_OKComplete;

errexit:
  	if (exitsub(reply,SQLCODE) == True) 
     	    return SQLCODE;
  	else  
     	    return apiRC;
}
/******************************************************/
/*   Query                                            */
/******************************************************/
long car169_query(reply)
serverReply reply;
{printf("into car169_query\n");
	/* standard defined host variables */
	$char DBName[DBNAME], userid[11];
	/* end of standard host var */
	
	/* define table fields */
	$char database[3], iquote[4], dbegin[10], dend[10], dbegin_tmp[11], dend_tmp[11], 
	      fpolicy[2], fendorse[2], tmp_itag[CA_TAG_NUM], iassured[13], ientry[11], foffice[2];
	$char datebgn[25], dateend[25];
	$char iendorse[21], ipolicy2[21], ipolicy1[21], nassured[121], sNassured[20],
	      itag[CA_TAG_NUM], iofficer[11], nofficer[11], ileader[11], nleader[11],
 	      dedr_begin[11], dply1_begin[11], dply2_begin[11],
 	      icreate[11], ncreate[11], dcreate[11];
 	$int  fstatus=0;
 	$char fsurvey[2], fbound[2], funder_chk_p[2], funder_chk_e[2];
 	$char stmt[4096], stmt1[124], WhereSt1[124], WhereSt2[124], WhereSt3[124], WhereSt4[124];
 	int   iTmp=0;
 	$char yy1[5],mm1[3],dd1[3],yy2[5],mm2[3],dd2[3];
 	$char tmp_col[13], data_tmp[19];
	/* end of define */
	
	/* standard defined data */
	int   ttlen;
	/***********long  rc;**************/
	long  lnRecCountMain;
	int   rtcode = 0;
	char  sFileName[50];
	int   nMode;
	int   iTmpLen;
	char  FullDBName[20],tmp_fulldb[20];
	/* end of standard data */

	cm_buf_get("%s",DBName);
	cm_buf_get("%s %s %s %s %s",userid,database,iquote,dbegin,dend);
	cm_buf_get("%s %s %s %s %s %s",fpolicy,fendorse,tmp_itag,iassured,ientry,foffice);
 
 	$WHENEVER SQLERROR GOTO errexit;
 		
 	if(db_select(DBName) == False)
	    return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
 	
 	/* onload�{���|���P�ɦh�H����Atemp table�ݯS���R�W (1091021005_SC6) */
 	$select first 1 to_char(current,'car%H%M%S') into $tmp_col from systables;
 	strcpy(tmp_col,trim(tmp_col));
 	strcpy(data_tmp,tmp_col);
 	strcat(data_tmp,userid);
 	strcpy(data_tmp,trim(data_tmp));
 	printf("data_tmp[%s]\n",data_tmp);
 	
 	sprintf_s(stmt, sizeof stmt, "create temp table %s (        \n"
 	             " iendorse      char(20),      \n"
 	             " ipolicy       char(20),      \n"
 	             " nassured      varchar(120),  \n"
 	             " itag          char(12),      \n"
 	             " iofficer      char(10),      \n"
 	             " nofficer      char(10),      \n"
 	             " ileader       char(10),      \n"
 	             " nleader       char(10),      \n"
 	             " dedr_begin    date,          \n"
 	             " dply_begin    date,          \n"
 	             " ientry        char(10),      \n"
 	             " nentry        char(10),      \n"
 	             " dentry        date,          \n"
 	             " fsign_status  smallint,      \n"
 	             " fsurvey       char(1),       \n"
 	             " fbound        char(1),       \n"
 	             " funder_chk_p  char(1),       \n"
 	             " funder_chk_e  char(1)        \n"
 	             " )with no log;      \n", data_tmp);
 	             
 	printf("stmt[%s]\n",stmt);
        $prepare pre_tbl from $stmt;
        $execute pre_tbl;
        
        printf("stmt1[%s]\n",stmt1);
        sprintf_s(stmt1, sizeof stmt1, "DROP TABLE %s;",data_tmp);
        $prepare dt_tbl FROM $stmt1;
       	
 	strcpy(dbegin_tmp, cm_to_infdate(dbegin));
 	cm_split_ymd(dbegin_tmp, mm1, dd1, yy1);
 	sprintf_s(datebgn, sizeof datebgn, "%s-%s-%s 00:00:00",yy1,mm1,dd1);
 	strcpy(dend_tmp, cm_to_infdate(dend));
 	cm_split_ymd(dend_tmp, mm2, dd2, yy2);
 	sprintf_s(dateend, sizeof dateend, "%s-%s-%s 23:59:59",yy2,mm2,dd2);
 	
 	strcpy(FullDBName, get_full_dbname(database));
 		
 	/*****************************************************/
 	ttlen=0;
 	
 	cm_buf_init_x(ReplyBuf);
 	cm_buf_res_msg_x();
 	cm_buf_res_count_x();        /* for transfer mode code */
 	cm_buf_res_count_x();        /* for table count */
 	cm_buf_res_count_x();        /* for record count */
 	
 	cm_buf_res_string_x(50);
 	
 	time(&tstart);
 	$set lock mode to wait 5;
 	lnRecCountMain = 0;   
 	/*****************************************************/    	 		
 	if (strlen(trim(tmp_itag)) == 0)
 		strcpy(WhereSt2, " ");
 	else
 		sprintf_s(WhereSt2, sizeof WhereSt2, "AND a.itag = '%s' ", tmp_itag);
 	
 	if (strlen(trim(iassured)) == 0)
 		strcpy(WhereSt3, " ");
 	else
 		sprintf_s(WhereSt3, sizeof WhereSt3, "AND a.iassured = '%s' ", iassured); 		
 	 	
 	if (fpolicy[0]=='1')
 	{
 		if (strlen(trim(ientry)) == 0)
 		    strcpy(WhereSt4, " ");
 		else
 		    sprintf_s(WhereSt4, sizeof WhereSt4, "AND b.ientry = '%s' ", ientry);
 		    
 		if (strcmp(foffice,"Y") == 0)
 		    sprintf_s(WhereSt1, sizeof WhereSt1, "    AND b.fsign_status = 20 ");
 		else
 		    sprintf_s(WhereSt1, sizeof WhereSt1, "    AND b.fsign_status in (10,20) ");
 		
 		sprintf_s(stmt, sizeof stmt,
 		" insert into %s                                                         \n"
 		" SELECT '', a.ipolicy, a.nassured, a.itag,                              \n"
 		"        b.iofficer, c.nname, b.ileader, d.nname,                        \n"
 		"        '', b.dply_begin, b.ientry,                                     \n"
 		"        f.nname, DATE(b.dcreate), b.fsign_status,                       \n"
 		"        CASE WHEN a.survey_num = '' THEN 'N' ELSE 'Y' end,              \n"
 		"        CASE WHEN a.bound_num = '' THEN 'N' ELSE 'Y' end,               \n"
 		"        CASE WHEN b.funder_chk = 'Y' THEN 'V' ELSE '' end, '-'          \n"
 		"   FROM %s:policy a, %s:ply_relation b, officer c, officer d, officer f \n"
 		"  WHERE a.ipolicy = b.ipolicy                 \n"
 		"    AND b.iofficer = c.iofficer               \n"
 		"    AND b.ileader = d.iofficer                \n"
 		"    AND b.ientry = f.iofficer                 \n"
 		"    AND a.ipolicy[1,3] = '%s'                 \n"
 		"    AND b.dcreate between '%s' and '%s'       \n"
 		"    %s  %s  %s  %s                            \n"
 		"  ORDER BY a.ipolicy;                         \n",
 		data_tmp,FullDBName,FullDBName,
 		iquote,datebgn,dateend,WhereSt1,WhereSt2,WhereSt3,WhereSt4);
 		  		
 		$PREPARE inset_tmp1 FROM $stmt;
 		$EXECUTE inset_tmp1;
 	}
printf("ipolicy_stmt[%s]\n" , stmt);			
 	if (fendorse[0]=='1')
 	{
 		if (strlen(trim(ientry)) == 0)
 		    strcpy(WhereSt4, " ");
 		else
 		    sprintf_s(WhereSt4, sizeof WhereSt4, "AND b.iedr_examiner = '%s' ", ientry);
 		
 		if (strcmp(foffice,"Y") == 0)
 		    sprintf_s(WhereSt1, sizeof WhereSt1, "    AND b.fsign_status_edr = 20 ");
 		else
 		    sprintf_s(WhereSt1, sizeof WhereSt1, "    AND b.fsign_status_edr in (10,20) ");
 		    
 		sprintf_s(stmt, sizeof stmt,
 		" insert into %s                                                   \n"
 		" SELECT a.iendorse, b.ipolicy, a.nassured, a.itag,                \n"
 		"        b.iofficer, c.nname, b.ileader, d.nname,                  \n"
 		"        b.dedr_begin, a.dply_begin, b.iedr_examiner,              \n"
 		"        f.nname, DATE(b.dcreate), b.fsign_status_edr,             \n"
 		"        '-', '-', '-',                                            \n"
 		"        CASE WHEN b.funder_chk_edr = 'Y' THEN 'V' ELSE '' end     \n"
 		"   FROM %s:endorsement a, %s:edr_relation b, officer c, officer d, officer f \n"
 		"  WHERE a.iendorse = b.iendorse         \n"
 		"    AND b.iofficer = c.iofficer         \n"
 		"    AND b.ileader = d.iofficer          \n"
 		"    AND b.iedr_examiner = f.iofficer    \n"
 		"    AND a.iendorse[1,3] = '%s'          \n"
 		"    AND b.dcreate between '%s' and '%s' \n"
 		"    AND b.iendorse not like '%%CVP%%'   \n"
 		"    %s  %s  %s  %s                      \n"
 		"  ORDER BY a.iendorse;                  \n",
 		data_tmp,FullDBName,FullDBName,
 		iquote,datebgn,dateend,WhereSt1,WhereSt2,WhereSt3,WhereSt4);
 		  		
 		$PREPARE inset_tmp2 FROM $stmt;
 		$EXECUTE inset_tmp2;
 	}
printf("iendorse_stmt[%s]\n" , stmt);  		
 	sprintf_s(stmt, sizeof stmt, " SELECT first 200 * FROM %s WHERE 1=1; \n",data_tmp);
  	
 	$PREPARE cur_01 FROM $stmt;
 	$DECLARE cur_main CURSOR FOR cur_01;
 	$OPEN cur_main;        
        while(1)
        {
        	$FETCH cur_main
        	  INTO $iendorse, $ipolicy2, $nassured, $itag,
        	       $iofficer, $nofficer, $ileader, $nleader,
        	       $dedr_begin, $dply2_begin, $icreate,
        	       $ncreate, $dcreate, $fstatus,
        	       $fsurvey, $fbound, $funder_chk_p, $funder_chk_e;
 	        
 	        if (SQLCODE == SQLNOTFOUND) break;
  	        
 	        sprintf_s(stmt, sizeof stmt,
 		        " SELECT irelative_ply FROM %s:ply_relation \n"
 		        "  WHERE ipolicy = '%s' \n",FullDBName,ipolicy2);
 		$PREPARE get_ply1 FROM $stmt;
 		$EXECUTE get_ply1 INTO $ipolicy1;
 		 		
 		if (SQLCODE == SQLNOTFOUND) break;
 		
 		if (strlen(trim(ipolicy1)) != 0)
 		{
 			strcpy(tmp_fulldb, get_car_full_db(ipolicy1));
 						
 			sprintf_s(stmt, sizeof stmt,
 			        " SELECT dply_begin FROM %s:ply_relation \n"
 			        "  WHERE ipolicy = '%s' \n",tmp_fulldb,ipolicy1);
 			$PREPARE get_date FROM $stmt;
 			$EXECUTE get_date INTO $dply1_begin;
 			 			
 			if (SQLCODE == SQLNOTFOUND) break;
 			
 			strcpy(ipolicy1,    trim(ipolicy1));
 			strcpy(dply1_begin, cm_from_infdate_100(dply1_begin));
 		}
 		else
 		{
 			strcpy(ipolicy1,   " ");
 			strcpy(dply1_begin," ");
 		}

 	        strcpy(iendorse,    trim(iendorse));
 	        strcpy(ipolicy2,    trim(ipolicy2));
 	        
 	        iTmp = iGetChinesePos(nassured,14);
 	        strcpy(sNassured,"");
 	        strncpy(sNassured,nassured,iTmp+1);
 	        sNassured[iTmp+1] = '\0';
 	
 	        strcpy(itag,             trim(itag));
 	        strcpy(iofficer,         trim(iofficer));
 	        strcpy(nofficer,         trim(nofficer));
 	        strcpy(ileader,          trim(ileader));
 	        strcpy(nleader,          trim(nleader));
 	        strcpy(dedr_begin,       cm_from_infdate_100(dedr_begin));	        
 	        strcpy(dply2_begin,      cm_from_infdate_100(dply2_begin));
 	        strcpy(icreate,          trim(icreate));
 	        strcpy(ncreate,          trim(ncreate));
 	        strcpy(dcreate,          cm_from_infdate_100(dcreate));
 	        strcpy(fsurvey,          trim(fsurvey));
 	        strcpy(fbound,           trim(fbound));
 	        strcpy(funder_chk_p,     trim(funder_chk_p));
 	        strcpy(funder_chk_e,     trim(funder_chk_e));

 	        rtcode = cm_buf_put_x("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %d %s %s %s %s",
 	                 iendorse, ipolicy2, ipolicy1, sNassured, itag, iofficer, nofficer,
 	                 ileader, nleader, dedr_begin, dply1_begin, dply2_begin, 
 	                 icreate, ncreate, dcreate, fstatus, fsurvey, fbound, 
 	                 funder_chk_p, funder_chk_e);
 	        	        
 	        if(rtcode == M_CM_FILE_OVERFLOW)
 	        {
 	        	return exitsub(reply, M_CM_FILE_OVERFLOW) ? M_CM_FILE_OVERFLOW : apiRC;
 	        }
 	        
 	        lnRecCountMain++;
        }
        $CLOSE cur_main;
        $FREE cur_main;
          
        /* 1 New function to put record count on file begin 
        cm_buf_put_count_x(lnRecCount);*/
        
        printf("System use second is: %f\n", tused);
        printf("msg_code[%d]\n", msg_code);
        /* 1 New function write the lastest data to file and close it*/
        cm_buf_end_x();
        
        /* 1 New function to get file name */
        strcpy(sFileName, cm_get_ftp_filename());
        printf("transfer file name : [%s]\n", sFileName);
        
        /* 1 New function to get transfer mode */
        nMode = cm_get_mode();
        printf("transfer mode : nMode=[%d]\n", nMode);
        
        printf("record count[%ld] \n", lnRecCountMain);
        /* Message Code */
        if (lnRecCountMain == 0)
        {
        	cm_buf_put_msg(M_CM_NOT_FOUND);
        }
        else
        {
        	cm_buf_put_msg(M_CM_OK);
        	
        	/* Transfer mode */
        	cm_buf_put_count_seq(1, (long)nMode);
        	/* Table Count */
        	cm_buf_put_count_seq(2, 1L);
        	/* RecCount */
        	cm_buf_put_count_seq(3, lnRecCountMain);
        	/* 1 New function for file name */
        	cm_buf_put_string_x(sFileName);
        }
        iTmpLen = cm_buf_len(ReplyBuf);
        
        printf("drop table data_tmp[%s]\n",stmt1);
        $EXECUTE dt_tbl;
        
        if(SendSyncReply(reply, ReplyBuf, iTmpLen, api_OKComplete) == False)
            return apiRC;
        
        return api_OKComplete;
     
errexit:
  	$EXECUTE dt_tbl;
  	printf("errexit�Gdrop table data_tmp\n"); 
  	if (exitsub(reply,SQLCODE) == True) 
     	return SQLCODE;
  	else  
     	return apiRC;
}
/******************************************************/
/*  Update                                            */
/******************************************************/
long car169_update(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	/* standard defined host variables */
	$char DBName[DBNAME], userid[11];
	/* end of standard host var */
	$char fstatus[2], iendorse[21], ipolicy[21], iupdate[11];
	$int  cnt=0,fsign_status=0;
	char  FullDBName[20];
	$char stmt_buf[400];
	/* define table fields */
	
	/* end of define */
	
	/* standard defined data */
	char  *comm;
	long  MsgCode;
	int   tmp_len;
	long  lnBufLen;
	char  *pBuf;
	int   k,rows=0; 
	/* end of standard data */
	
	pBuf = NULL;	
	/*cm_buf_init(command); */
	
	cm_buf_get("%s",DBName);
	lnBufLen = cm_ftp_init_x(&pBuf);
	
	$WHENEVER SQLERROR GOTO errexit;
		
	if(db_select(DBName) == False)
	    return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
	
	$BEGIN WORK;
	
	cm_buf_get("%d %s %s", &rows, fstatus, iupdate);
	
	for (k = 0; k <rows; k++)
	{
		cm_buf_get("%s %s", iendorse, ipolicy);
				
		/* update ��� */
		/* update�e���T�{�ӵ���ƥ��Q���� (1091021005_SC6) */
		if (fstatus[0]=='1'){
			fsign_status = 30;  /* �f�ֳq�L */
			strcpy(FullDBName, get_car_full_db(ipolicy));
			
			if (strlen(trim(iendorse)) == 0){
				/* �O�� */ 
				sprintf_s(stmt_buf, sizeof stmt_buf,
				        " select count(*) from %s:ply_relation "
				        "  WHERE ipolicy = '%s' "
				        "    AND fsign_status = 20; ",FullDBName,ipolicy);
				        
				$PREPARE sel_ply1 FROM $stmt_buf;
				$EXECUTE sel_ply1 INTO $cnt;
				
				if (cnt == 0) continue;
				
				sprintf_s(stmt_buf, sizeof stmt_buf,
				        " UPDATE %s:ply_relation "
				        "    SET (fsign_status,isign,dapply) "
				        "      = ('%d','%s',current) "
				        "  WHERE ipolicy = '%s' "
				        "    AND fsign_status = 20; "
				        ,FullDBName,fsign_status,iupdate,ipolicy);      				
			}else{
				/* ��� */ 
				sprintf_s(stmt_buf, sizeof stmt_buf,
				        " select count(*) from %s:edr_relation "
				        "  WHERE iendorse = '%s' "
				        "    AND fsign_status_edr = 20; ",FullDBName,iendorse);
				        
				$PREPARE sel_edr1 FROM $stmt_buf;
				$EXECUTE sel_edr1 INTO $cnt;
				
				if (cnt == 0) continue;
				
				sprintf_s(stmt_buf, sizeof stmt_buf,
				        " UPDATE %s:edr_relation "
				        "    SET (fsign_status_edr,isign_edr,dsign_edr) "
				        "      = ('%d','%s',current) "
				        "  WHERE iendorse = '%s' "
				        "    AND fsign_status_edr = 20; "
				        ,FullDBName,fsign_status,iupdate,iendorse);
			}
		}else if (fstatus[0]=='2'){
			fsign_status = 10;  /* �h�� */
			strcpy(FullDBName, get_car_full_db(ipolicy));
			
			if (strlen(trim(iendorse)) == 0){
				/* �O�� */
				sprintf_s(stmt_buf, sizeof stmt_buf,
				        " select count(*) from %s:ply_relation "
				        "  WHERE ipolicy = '%s' "
				        "    AND fsign_status = 20; ",FullDBName,ipolicy);
				        
				$PREPARE sel_ply2 FROM $stmt_buf;
				$EXECUTE sel_ply2 INTO $cnt;
				
				if (cnt == 0) continue;
				
				sprintf_s(stmt_buf, sizeof stmt_buf,
				        " UPDATE %s:ply_relation "
				        "    SET (fsign_status,funder_chk) "
				        "      = ('%d','N') "
				        "  WHERE ipolicy = '%s' "
				        "    AND fsign_status = 20; "
				        ,FullDBName,fsign_status,ipolicy);
			}else{
				/* ��� */ 
				sprintf_s(stmt_buf, sizeof stmt_buf,
				        " select count(*) from %s:edr_relation "
				        "  WHERE iendorse = '%s' "
				        "    AND fsign_status_edr = 20; ",FullDBName,iendorse);
				        
				$PREPARE sel_edr2 FROM $stmt_buf;
				$EXECUTE sel_edr2 INTO $cnt;
				
				if (cnt == 0) continue;
				
				sprintf_s(stmt_buf, sizeof stmt_buf,
				        " UPDATE %s:edr_relation "
				        "    SET (fsign_status_edr,funder_chk_edr) "
				        "      = ('%d','N') "
				        "  WHERE iendorse = '%s' "
				        "    AND fsign_status_edr = 20; "
				        ,FullDBName,fsign_status,iendorse);
			}      	  
		}		
		$PREPARE up_status FROM $stmt_buf;
		$EXECUTE up_status;
printf("SQLCODE[%d]\n" , SQLCODE);		
		if (SQLCODE != 0) goto errexit;
				
		printf("UPDATE relation:sqlca.sqlerrd[2][%d]\n" , sqlca.sqlerrd[2]);
		if (sqlca.sqlerrd[2]==0){ /* �S����ƳQ��� */		
			SQLCODE=3524;
			goto errexit;
		}else{
			/* �h��t�~�g�Jlog�ɬ��� */
			if (fstatus[0]=='2'){
				$INSERT INTO ca_log
				(ipgid, itype, ilog_number1, ilog_number2, ncontent, iupdate, dupdate)
				VALUES
				('car169', 'A', $ipolicy, $iendorse, '�h��', $iupdate, current);     	  
			}
				
		}			
	}
	
	printf("after Updating ........\n");
	if (pBuf != NULL) free(pBuf);
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	tmp_len = cm_buf_len(ReplyBuf);
	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
	{
		printf("after SendSyncReply = false........\n");      	
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		return apiRC;
	}
	printf("after SendSyncReply  ........\n");      	
	$WHENEVER SQLERROR GOTO errexit;
	$COMMIT WORK;
	return api_OKComplete;

 errexit:
    MsgCode = SQLCODE;
    printf("go to errexit[%d]\n",SQLCODE);
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;              /* rollback fail */
    if(SQLCODE != 0) MsgCode = SQLCODE;
    if(exitsub(reply,MsgCode) == True)
        return MsgCode;
    else
        return apiRC;
}
/******************************************************/
/*  ���o���^���q�������T���嵲����m                  */
/******************************************************/
int *iGetChinesePos(sStrTmp,iPos)
char *sStrTmp;
int  iPos;
{
   int  iTrueLen;
   int  i,x;

   for(i = 0; i<= iPos; i++){
         if ((int)(sStrTmp[i]) >= 128){
                i++;
         }
   }
   return (i-1);
}