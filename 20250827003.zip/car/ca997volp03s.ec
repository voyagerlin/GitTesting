/* Copyright (C) 2001 Intellisys Corporation
 * Program : ca997volp03s.ec
 * ���N�I�����T���߲z�߸�� modify by sylvia 99.12.01
 ***********************************************************************************/

#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "sqlfatal.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
#include <time.h>

#define ONLINE_DATE "04/29/2007"        /* �e���T��Ʊj����N���ɤW�u�� */

/*--------------------------------------------------------------------*/
DBinfo  *list;
static int     i=0,count_db=0,rc=0;

char  userid[11],option[2],outputf[21];
char  goption[2];
$char DBName[05];
$char datebgn[11],dateend[11];
$char sApHome[31],tmp_dbname[20];
char  errmsg[200],msgbuf[128];
FILE  *errfpt;
FILE  *fptr;
FILE  *fptr1;
$int  number=0;
$long dbgn_long=0;

$char  errFile[30],errlog[300];

static char localdb[5];
static int  flag_check=0;

static  char sExpdate[10];
static  char sBgndate[10],sEnddate[10];
$static char  sDappraisal_bgn[11], sDappraisal_end[11];
long    rtncode;

$char   companyid[3],opt[3];
int     rtn=0;
$char   COMPANY[3];
$char   COMPANY_F[3];

/*static char sPrtstr[250]; */

$static char  sDgroup[11];
$static char  sTmt_buf[9900];

/* data  ca_trad_exam */
$long prem_total=0, cntrlrec=0;
$long minjure=0, mcripple=0, mdeath=0;
$long qcount=0,Tinjure=0, Tcripple=0, Tdeath=0,Tamount=0;
$long policy_day=0,max_dply_l=0;
$char max_dply_c[11];
$char iply_type[3], sIcar_type[3];

/* others data */
$char  sDappraisal_c[11],Tmp1[61],file0[81], sfilename[81];
$char  Tmp2[21];
$char  sDappraisal_c1[11];
$char  fcard_class[2],close_date_c[11];
char   day_yy[4],day_mm[3],day_dd[3];
char   day_yy1[4],day_mm1[3],day_dd1[3];
char   strlog[500],cntrlrec_c[7],prtstr[500];
$long  close_date=0, old_close_date=0;
$char  ibranch_in[5];
$char  company_flag;
$char  iclaim_flag, sWhere[128], sWhere1[128];
$int   count=0;
$char  infdaccident[11];

$char filename[20];
$long filecount=0;

$char filefulllast[200];
$char lastdwork[11];
int   itmpcnt=0;

$char sWhere9[5000];
$char sWhere99[5000];
$long dapp_end=0;
$char giclaim[21];
$char min_dapp[11];
$char hhminsec[7];
$char giclaim_tmp[21];
$char giclose_type_tmp[3];

time_t current_secs;
struct tm *tm_now;

char  strtmp[31];     /* �t�X101/3/1�_���N�I���T�ǿ�W�沧�� add by sylvia 101.01.02 */


$define  INJURE         "93";
$define  DEATH          "94";
$define  CRIPPLE        "95";
$define  COMPULSORY     "21";

static long App_ins();     /* ���N�w�� */
static long App_ins2();    /* ���N�w��(�s) *//* 101/03/01 �_�s�����N�I���T�ǿ�W�沧�� add by sylvia 101.01.02 */
static long lStl_ins();    /* ���N�w�M */
static long lStl_ins2();   /* ���N�w�M(�s) *//* 101/03/01 �_�s�����N�I���T�ǿ�W�沧�� add by sylvia 101.01.02 */
void GetLostAppData();     /* ���o�e�@�u�@�饼�ǰe���w����� */
long   car9973_get_db();
extern char *sformat_trade();
extern long split_policy();
extern int rptftpinsert();
long   check_if_exist();
long  today, online_date, online;
char *get_inf_date();

/*--------------------------------------------------------------------*/
main(argc,argv)
int   argc;
char  **argv;
{
   int   rc;
   long  t=0, date_1010301=0;
   int   dd=0,mm=0,ss=0;

   batchinit();

   strcpy(DBName,isNULLstr(argv[1]));
   strcpy(userid,isNULLstr(argv[2]));
   strcpy(option,isNULLstr(argv[3]));   /* 2:���N�I�z��, 4:���N�I�z�߭��e, 5:���N�I�z�߭簣���e Y:�������N�I���v��  car9973a A.�w���s�W B.�w���� C.�z��(�̽߰l���ơA�u���s�W) */
   strcpy(datebgn,isNULLstr(argv[4]));
   strcpy(dateend,isNULLstr(argv[5]));
   strcpy(giclaim,isNULLstr(argv[6]));  /*  car997a �ϥ� �浧���N�I�߮׭簣���e ,  car997 �T�w���ť� */
   strcpy(outputf,isNULLstr(argv[7]));

   strcpy(sDappraisal_bgn,cm_to_infdate(datebgn));
   strcpy(sDappraisal_end,cm_to_infdate(dateend));
   rstrdate(sDappraisal_bgn,&dbgn_long);
   rstrdate(sDappraisal_end,&dapp_end);

   if (option[0] == 'A' ||
       option[0] == 'B' ||
       option[0] == 'C')
   {
      strcpy(goption, option);
      strcpy(option, "5");

      current_secs=time(NULL);
      tm_now=localtime(&current_secs);

      dd = tm_now->tm_hour;
      mm = tm_now->tm_min;
      ss = tm_now->tm_sec;

      strcpy(hhminsec,itoa(dd));
      strcat(hhminsec,itoa(mm));
      strcat(hhminsec,itoa(ss));

      printf("option[%s]\n", option);
      printf("goption[%s]\n", goption);
      printf("giclaim[%s]\n", giclaim);

      printf("start hhminsec[%s]\n",hhminsec);
   }
   else
   {
      strcpy(goption," ");
      strcpy(hhminsec,"");
   }


   $WHENEVER SQLERROR GOTO errexit;

   rstrdate( ONLINE_DATE, &online_date);
   rtoday( &today);

   online = today >=online_date ? TRUE:FALSE;

   errfpt = (FILE *) STARTLOG();

   rc=car9973_get_db();
   if (rc!=M_CM_OK)
      return rc;

   itmpcnt = 0;
   printf("option[%s]\n",option);
   printf("1sDappraisal_end[%s]\n",sDappraisal_end);
   if (strcmp(option,"2") == 0)
   {
      GetLostAppData();
   }
   printf("2sDappraisal_end[%s]\n",sDappraisal_end);

   rtn = getCompanyId(companyid);
   
   t = cm_today();
   rstrdate( "03/01/2012", &date_1010301);

   printf(" ********** t=[%ld] date_1010301=[%ld] ***********\n", t,date_1010301);

   strcpy(sWhere, " ");

   if ( strcmp(option,"2") == 0 )
   {
      strcpy(opt,"bm");

      $select max(dpolicy)+1,max(dpolicy)+1
         into $max_dply_l,$max_dply_c
         from ca_trade_exam
        where iply_type = $opt and fcard_class = '2';

      if (dbgn_long > max_dply_l && risnull( 2, &max_dply_l) != 1)
      {
         printf("dbgn_long[%d] > max_dply_l[%d]\n", dbgn_long , max_dply_l);
         strcpy(sDappraisal_bgn,max_dply_c);
      }


      if (t >= date_1010301)
      {
         /*** ���N�w�� ***/
         rtncode=App_ins2();

         /*** ���N�w�M ***/
         if (rtncode==SUCCESS) rtncode=lStl_ins2();
      }
      else
      {
         /*** ���N�w�� ***/
         rtncode=App_ins();

         /*** ���N�w�M ***/
         if (rtncode==SUCCESS) rtncode=lStl_ins();
      }

      if (errfpt!=NULL) ENDLOG(errfpt);
   }
   else if ( strcmp(option,"4") == 0 ) /*�z�߭��e*/
   {
      msgbuf[0]='\0';

      strcpy(opt,"bm");

      if (t >= date_1010301)
      {
         /*** ���N�w�� ***/
         rtncode=App_ins2();
   
         /*** ���N�w�M ***/
         if (rtncode==SUCCESS) rtncode=lStl_ins2();
            else sprintf_s(msgbuf, sizeof msgbuf,"%s���N�z�߭��e�w��_error[%d] ",trim(msgbuf),rtncode);
      }
      else
      {
         /*** ���N�w�� ***/
         rtncode=App_ins();
   
         /*** ���N�w�M ***/
         if (rtncode==SUCCESS) rtncode=lStl_ins();
            else sprintf_s(msgbuf, sizeof msgbuf,"%s���N�z�߭��e�w��_error[%d] ",trim(msgbuf),rtncode);
      }

      if (errfpt!=NULL) ENDLOG(errfpt);
   }
   else if ( strcmp(option,"5") == 0 ) /*�z�߭簣���e,�� ca_tmp_no �����*/
   {
      msgbuf[0]='\0';

      strcpy(opt,"bm");

      if (goption[0] == 'A' || goption[0] == 'B' || goption[0] == 'C')
      {        
         if (t >= date_1010301)
         {
            if (goption[0] == 'A' || goption[0] == 'B')
            {
                /*** ���N�w�� ***/
                strcpy(giclaim,substring(giclaim,1,11));
                sprintf_s(sWhere, sizeof sWhere, " and a.iclaim = '%s' ", giclaim);
                printf("sWhere[%s]\n",sWhere);
                rtncode=App_ins2();
                if (rtncode!=SUCCESS) sprintf_s(msgbuf, sizeof msgbuf,"%s���N�z�߭簣���e�w��_error[%d] ",trim(msgbuf),rtncode);

                sprintf_s(sWhere, sizeof sWhere, " and 1 <> 1 "); 
                rtncode=lStl_ins2();
            }
            else
            {
                /*** ���N�w�M ***/              
                sprintf_s(sWhere, sizeof sWhere, " and 1 <> 1 ");   
                rtncode=App_ins2();
                if (rtncode!=SUCCESS) sprintf_s(msgbuf, sizeof msgbuf,"%s���N�z�߭簣���e�w��_error[%d] ",trim(msgbuf),rtncode);
                strcpy(giclaim_tmp, giclaim);
                strcpy(giclaim,substring(giclaim,1,11));
                /*  strcpy(giclose_type_tmp, giclaim[12]);   */
                printf("giclaim[%s]\n, 12->[%c]\n", giclaim, giclaim[12]);
                sprintf_s(sWhere, sizeof sWhere, " and a.iclaim = '%s' and a.fstl = '1' and a.iclose_type = %c ", giclaim, giclaim_tmp[12]);               
                printf("sWhere[%s]\n",sWhere);
                rtncode=lStl_ins2();
            }
         }
         else
         {
            if (goption[0] == 'A' || goption[0] == 'B')
            {
                /*** ���N�w�� ***/
                strcpy(giclaim,substring(giclaim,1,11));
                sprintf_s(sWhere, sizeof sWhere, " and a.iclaim = '%s' ", giclaim);
                printf("sWhere[%s]\n",sWhere);
                rtncode=App_ins();
                if (rtncode!=SUCCESS) sprintf_s(msgbuf, sizeof msgbuf,"%s���N�z�߭簣���e�w��_error[%d] ",trim(msgbuf),rtncode);

                sprintf_s(sWhere, sizeof sWhere, " and 1 <> 1 "); 
                rtncode=lStl_ins();
            }
            else
            {
                /*** ���N�w�M ***/
                sprintf_s(sWhere, sizeof sWhere, " and 1 <> 1 ");   
                rtncode=App_ins();
                if (rtncode!=SUCCESS) sprintf_s(msgbuf, sizeof msgbuf,"%s���N�z�߭簣���e�w��_error[%d] ",trim(msgbuf),rtncode);
                strcpy(giclaim_tmp,substring(giclaim,1,11));
                strcpy(giclose_type_tmp, giclaim[12]);
                sprintf_s(sWhere, sizeof sWhere, " and a.iclaim = '%s' and a.fstl = '1' and a.iclose_type = %s ", giclaim_tmp,giclose_type_tmp);                  
                printf("sWhere[%s]\n",sWhere);
                rtncode=lStl_ins();
            }
         }
      }
      else
      {
         strcpy(sWhere,
               " and a.iclaim in (select ipolicy from newa00:ca_tmp_no) ");

         if (t >= date_1010301)
         {
            /*** ���N�w�� ***/
            rtncode=App_ins2();
   
            /*** ���N�w�M ***/
            if (rtncode==SUCCESS) rtncode=lStl_ins2();
            else sprintf_s(msgbuf, sizeof msgbuf,"%s���N�z�߭簣���e�w��_error[%d] ",trim(msgbuf),rtncode);
         }
         else
         {
            /*** ���N�w�� ***/
            rtncode=App_ins();
   
            /*** ���N�w�M ***/
            if (rtncode==SUCCESS) rtncode=lStl_ins();
            else sprintf_s(msgbuf, sizeof msgbuf,"%s���N�z�߭簣���e�w��_error[%d] ",trim(msgbuf),rtncode);
         }
      }

      if (errfpt!=NULL) ENDLOG(errfpt);
   }
   else if ( strcmp(option,"Y") == 0 ) /* �������v�ɶǰe���*/
   {
      strcpy(opt,"bm");
      
      if (t >= date_1010301)
      {
         /*** ���N�w�� ***/
         rtncode=App_ins2();
   
         /*** ���N�w�M ***/
         if (rtncode==SUCCESS) rtncode=lStl_ins2();
      }
      else
      {
                  /*** ���N�w�� ***/
         rtncode=App_ins();
   
         /*** ���N�w�M ***/
         if (rtncode==SUCCESS) rtncode=lStl_ins();
      }
   
      if (errfpt!=NULL) ENDLOG(errfpt);
   }
   

   if (rtncode != SUCCESS )
   {
      rgetmsg(rtncode, errlog, sizeof(errlog));

      sprintf_s(strlog, sizeof strlog,"%s\n\n\t\t     ",errlog);

      printf("option [%s]\n",option);

      if ( strcmp(option,"2") == 0 )
      {
         strcat(strlog," ISBM");
         strcat(strlog,companyid);
         strcat(strlog,"_���N�I�z�߻s�@���� ");
      }
      else if ( strcmp(option,"Y") == 0 )
      {
         strcat(strlog," ISBM");
         strcat(strlog,companyid);
         strcat(strlog,"_�����I�z�߻s�@���� ");
      }
      else
      {
         strcat(strlog,msgbuf);
      }

      printf("strlog[%s]\n",strlog);

      EWRITE(userid,rc,strlog);

      exit(1);
   }

   /* �]���Τ@�����   �O�椽�q�O�� 16   �׸����q�O��17  */

   exit(0);

errexit:
    printf("car9973vol-main:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car9973_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   rc = getApHome(sApHome);
   if (rc < 0) {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
   }

   printf("sApHome[%s]\n",sApHome);

   $CREATE TEMP TABLE TRADE_COUNT
   (
      file_name char(50),
      policy_day int,
      qcount    int,
      Tamount   int,
      Tinjure   int,
      Tcripple  int,
      Tdeath    int,
      Tastype   char(1)    -- �O�_�w�����z��@�~(A:�w��,S:�z��) add by sylvia 101.03.27
   )WITH NO LOG;
   $create unique index trade_count_idx on trade_count(file_name);

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*-----------------���N�w��-------------------------------------------*/
/* 101/03/01�_, �]���s�����N�I���T�ǿ�W�椣�A�ϥ�,�אּ�ϥ�App_ins2() add by sylvia 101.01.02 */
long App_ins()
{
   $char  sIpolicy[POLICY_NUM_1],sObjno[CA_TARGET_NUM+1];
   $char  sIpolicy1[POLICY_NUM_1], sIpolicy2[POLICY_NUM_2];

   $char  sIclaim[CLAIM_NUM],sIins_type[INSURANCE_TYPE];
   $char  iins_type_rule[INSURANCE_TYPE];
   $char  sItag[CA_TAG_NUM],sDappraisal[11];
   $char  sIacc_license[11],sIacc_birth[8],sIacc_birth_yy[3],sIacc_birth_mm[3];
   $char  sIacc_birth_c[9];
   $char  sIacc_birth_dd[3],sNacc_driver[21],sFacc_sex[2],sFacc_marri[2];
   $char  sFacc_nation[2],sIacc_reason[3],sDaccident[14],sIacc_area[3];
   $char  sFpart[2],sFpart_A[2],sFacc_car[2],sFacc_duty[2];
   $char  sIacc_birth_yyyy[5];
   $char  stmt_buf5[512];
   $long  lQlia=0,lMins_app=0;
   $long  Dappraisal=0,oldDappraisal=0;
   char  sInjure[3],sDeath[3],sCripple[3],sMins_app[13];
   char  sInjure_1[3],sDeath_1[3],sCripple_1[3];
   char  sPrtstr[262];

   long  iRtnCode=0;
   int   iFetch=0,ilength=0;
   $char MIclaim[21], MIins_type[7], MIpolicy[21], MIacc_license[11], MIacc_birth[7];
   $char MNacc_driver[11], MFacc_sex[2], MFacc_marri[2], MFacc_nation[2];
   $char MIacc_reason[3], MDaccident[14], MIacc_area[3], MFpart[2];
   $char MFacc_car[2], MFacc_duty[2];
   $char fins_grp[2];
   $long MDappraisal=0;
   $long MQlia=0, MMins_app=0;
   $long MInj_qlia=0,MDea_qlia=0,MCri_qlia=0;
   $long lInj_qlia=0,lDea_qlia=0,lCri_qlia=0;
   $long l29_dappraisal=0;
   $long M0A_qlia=0,M0B_qlia=0,M0C_qlia=0;
   $long l0A_qlia=0,l0B_qlia=0,l0C_qlia=0;
   $long l30_dappraisal=0,tmp_cnt=0;
   $long lDbgn_u=0, lDbgn_s=0, lDend_u=0, lDend_s=0;
   $char sDbgn_s[11], sDend_s[11], facc_car[2], fsystem[2], fassured[2];
   long  year1=0,year2=0;
   $long date_1000901=0, ldpolicy=0, iCount=0;
   $char iins_type_tradevan[INSURANCE_TYPE], tmp_dbname[20], iins_ply[INSURANCE_TYPE];
   $char stmt_bufa[256], stmt_bufb[256], stmt_bufc[256], stmt_bufd[256];
   $char stmt_tmp[2048];
   $char chk_dpolicy[2];
   
   $WHENEVER SQLERROR GOTO errexit;

   rstrdate( "09/01/2011", &date_1000901);

   printf ("#####lApp_ins\n");
   
   if ( strcmp(option,"Y") == 0 )
   {
      /* �ˮ֩ҤU���_����O�_�W�L���� */
         lDbgn_u = cm_ymd_edate(datebgn);    /* �ϥΪ̿�J�_�� */
         lDend_u = cm_ymd_edate(dateend);    /* �ϥΪ̿�J�_�� */
         
         $select date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10])),
                 date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10]))
            into $lDbgn_s, $sDbgn_s
            from cu_code_data
           where itype = 'CA' and icode = '02';
        
         
         $select date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10])),
                 date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10]))  
            into $lDend_s, $sDend_s
            from cu_code_data
           where itype = 'CA' and icode = '03';
        
         printf("datebgn=[%s]lDbgn_u=[%ld]\n",datebgn,lDbgn_u);
         printf("dateend=[%s]lDend_u=[%ld]\n",dateend,lDend_u);
         printf("sDbgn_s=[%s]lDbgn_s=[%ld]\n",sDbgn_s,lDbgn_s);
         printf("sDend_s=[%s]lDend_s=[%ld]\n",sDend_s,lDend_s);
         
         if ((lDbgn_u < lDbgn_s) || (lDbgn_u > lDend_s))
         {
            sprintf_s(strlog, sizeof strlog,"���v�ɰ_�鶷���� %s ~ %s ����,�нT�{!", sDbgn_s, sDend_s);
            return 100;
         }
         
         if ((lDend_u > lDend_s) || (lDend_u < lDbgn_s))
         {
            sprintf_s(strlog, sizeof strlog,"���v�ɨ��鶷���� %s ~ %s ����,�нT�{!", sDbgn_s, sDend_s);
            return 100;
         }
      }
 
   memset(sTmt_buf,' ',sizeof(sTmt_buf));

   /************ �]�w��l�� ************/
   sIcar_type[0] = '\0';
   sItag[0]='\0';
   sDappraisal[0]= '\0';
   sIacc_license[0]= '\0';
   sIacc_birth[0]='\0';
   sIacc_birth_yy[0]='\0';
   sIacc_birth_mm[0]='\0';
   sIacc_birth_c[0]='\0';
   sIacc_birth_dd[0]='\0';
   sNacc_driver[0]='\0';
   sFacc_sex[0]='\0';
   sFacc_marri[0]= '\0';
   sFacc_nation[0]='\0';
   sIacc_reason[0]='\0';
   sDaccident[0]='\0';
   sIacc_area[0]='\0';
   sFpart[0]= '\0';
   sFpart_A[0]= '\0';
   sFacc_car[0]='\0';
   sFacc_duty[0]='\0';
   sIacc_birth_yyyy[0]='\0';
   lQlia= lMins_app = 0;
   MInj_qlia = MDea_qlia = MCri_qlia = 0;
   l29_dappraisal = 0;
   l30_dappraisal = 0;
   MDappraisal = 0;
   cntrlrec = 0;
   chk_dpolicy[0] = '\0';
   /************************************/

   sprintf_s(stmt_tmp, sizeof stmt_tmp,"CREATE TEMP TABLE APPINS\
   (\
      TIclaim     char(20),\
      TIins_type  char(6),\
      TQlia       int,\
      TMins_app   int,\
      TDappraisal date,\
      TIpolicy    char(20),\
      TIacc_license  char(10),\
      TIacc_birth    char(8),\
      TNacc_driver   char(10),\
      TFacc_sex    char(1),\
      TFacc_marri  char(1),\
      TFacc_nation char(1),\
      TIacc_reason char(2),\
      TDaccident   char(13),\
      TIacc_area   char(2),\
      TFpart      char(1),\
      TFacc_car   char(1),\
      TFacc_duty  char(1),\
      TInj_qlia   int default 0,\
      TDea_qlia   int default 0,\
      TCri_qlia   int default 0,\
      T_itag	   char(%d),\
      iins_type   char(6),\
      iins_ply    char(6)\
   )WITH NO LOG;",CA_TAG_NUM-1);
     $PREPARE stmp FROM $stmt_tmp;
     $EXECUTE stmp;

   $CREATE TEMP TABLE tmp_policy
      ( ipolicy char(20) ) WITH NO LOG;

   $CREATE TEMP TABLE del_50_policy
     ( ipolicy char(20) ) WITH NO LOG;

   for( i= 0;i<count_db;i++)
   {
      if ( strcmp(option,"Y") == 0 )
      {
         /* �ɾ����I�z�߾��v��� */
         sprintf_s(sTmt_buf, sizeof sTmt_buf, "SELECT a.iclaim, a.iins_type, a.qlia, (a.mins_app+a.mproc_app),"
                           "       a.dappraisal, c.ipolicy, c.iacc_license,"
                           "       c.iacc_birth, c.nacc_driver, c.facc_sex, c.facc_marri,"
                           "       c.facc_nation, c.iacc_reason, c.daccident, c.iacc_area,"
                           "       c.fpart, c.facc_rel, "
                           "       decode(d.fins_grp,'1',c.fdmg_duty,c.facc_duty),b.itag,"
                           "       decode(d.iins_type_rule,'21','23',d.iins_type_rule),d.fins_grp, c.facc_car, e.fsystem, f.fassured, "
                           "       d.iins_ply, b.icar_type, CASE WHEN g.dpolicy < '08/01/2016' THEN 'Y' ELSE 'N' END"
                           "  FROM %s:app_ins_type a, %s:adjustment_ply b, %s:appraisal c,insurance_type d, ca_clm_process e, %s:policy f, %s:ply_relation g"
                           " WHERE a.iclaim = b.iclaim AND a.iclaim = c.iclaim "
                           "   AND c.iclaim = e.iclaim "
                           "   AND c.ipolicy = e.ipolicy " 
                           "   AND c.ipolicy = f.ipolicy " 
                           "   AND c.ipolicy = g.ipolicy "
                           "   AND a.iins_type = d.iins_type "
                           "   AND date(c.daccident) BETWEEN  '%s' AND  '%s' "
         			         "   AND a.iclaim[6] <> 'W' "
         			         "   AND b.icar_type IN ('01','02','32','34') "
         			         "   AND f.ipolicy[6,7] not in ('VW','EB','TV') "
                           "ORDER BY 1,20,2,5",
                           list[i].dbname,list[i].dbname,list[i].dbname, list[i].dbname, list[i].dbname,
                           sDappraisal_bgn,sDappraisal_end);
   
         printf("�������v��:sTmt_buf[%s]\n",sTmt_buf);
      }
      else
      {
         /* car9901111 ���T���N�I���e������� */
         /* 1000413004_C1 �����I�]�n�e���T�@mark by sylvia 100.05.02 */
         sprintf_s(sTmt_buf, sizeof sTmt_buf, "SELECT a.iclaim, a.iins_type, a.qlia, (a.mins_app+a.mproc_app),"
                           "       a.dappraisal, c.ipolicy, c.iacc_license,"
                           "       c.iacc_birth, c.nacc_driver, c.facc_sex, c.facc_marri,"
                           "       c.facc_nation, c.iacc_reason, c.daccident, c.iacc_area,"
                           "       c.fpart, c.facc_rel, "
                           "       decode(d.fins_grp,'1',c.fdmg_duty,c.facc_duty),b.itag,"
                           "       decode(d.iins_type_rule,'21','23',d.iins_type_rule),d.fins_grp, c.facc_car, e.fsystem, f.fassured, "
                           "       d.iins_ply, b.icar_type, CASE WHEN g.dpolicy < '08/01/2016' THEN 'Y' ELSE 'N' END"
                           "  FROM %s:app_ins_type a, %s:adjustment_ply b, %s:appraisal c,insurance_type d, ca_clm_process e, %s:policy f, %s:ply_relation g"
                           " WHERE a.iclaim = b.iclaim AND a.iclaim = c.iclaim "
                           "   AND c.iclaim = e.iclaim "
                           "   AND c.ipolicy = e.ipolicy " 
                           "   AND c.ipolicy = f.ipolicy "
                           "   AND c.ipolicy = g.ipolicy " 
                           "   AND a.iins_type = d.iins_type "
                           "   AND a.dappraisal BETWEEN  '%s' AND  '%s' %s "
         			         "   AND a.iclaim[6] <> 'W' "
         			         "   AND f.ipolicy[6,7] not in ('VW','EB','TV') "
                           "ORDER BY 1,20,2,5",
                           list[i].dbname,list[i].dbname,list[i].dbname, list[i].dbname, list[i].dbname,
                           sDappraisal_bgn,sDappraisal_end, sWhere);
   
         printf("���`��:sTmt_buf[%s]\n",sTmt_buf);
      }
      $PREPARE STMT5 FROM $sTmt_buf;
      $DECLARE CUR_APP CURSOR FOR STMT5;

      $OPEN CUR_APP;
      while (1)
      {
         $FETCH CUR_APP INTO $MIclaim, $MIins_type, $MQlia, $MMins_app, $MDappraisal,
                             $MIpolicy, $MIacc_license, $MIacc_birth, $MNacc_driver,
                             $MFacc_sex,$MFacc_marri, $MFacc_nation, $MIacc_reason,
                             $MDaccident, $MIacc_area, $MFpart, $MFacc_car, $MFacc_duty, $sItag,
                             $iins_type_rule, $fins_grp, $facc_car, $fsystem, $fassured, $iins_ply, $sIcar_type, $chk_dpolicy;

         if( SQLCODE == SQLNOTFOUND ) break;
         
         /* 1061102009_C1 �ק�ǰe���T27���ؾ��񨮵P�W�h
         if (strcmp(sIcar_type,"27") == 0 && strcmp(chk_dpolicy) == "Y")
               strcpy(sItag, " "); */        /* ����27,���P���X�M�� modify by sylvia 101.02.24 (1001005007_C1) */
         
         if( fsystem[0] == 'N')
             strcpy( MFacc_car, facc_car);
         else
         {
			/*�r�p�H�ϧO*/
			switch (MFacc_car[0])
			{
				case '1':
					break;
				case '2':
					break;
				case '3':
					/*�P�Q�O�I�H���Y = "3 ���u"*/
					/*�r�p�H�ϧO = "4 �����k�H"*/
					MFacc_car[0] = '4';
					break;
				case '4':
					/*�P�Q�O�I�H���Y = "4 ����"*/
					/*�r�p�H�ϧO = "4 �����k�H"*/
					MFacc_car[0] = '4';
					break;
				case '5':
					/*�P�Q�O�I�H���Y = "5 ��L"*/
                                        if( fassured[0] == '1' || fassured[0] == '3' || fassured[0] == '5')
					    MFacc_car[0] = '2'; /*�r�p�H�ϧO = "2 �w���ɥL�H��"*/
                                        else
					    MFacc_car[0] = '4'; /*�r�p�H�ϧO = "4 �����k�H"*/
					break;
				default :
					MFacc_car[0] = '2';
					break;
			}
         }

         MInj_qlia = MDea_qlia = MCri_qlia = 0;

         strcpy(MIins_type,rtrim(MIins_type));
         ilength= strlen(MIins_type)-1;

         strcpy(tmp_dbname,get_car_full_db(MIpolicy));
         sprintf_s(stmt_bufb, sizeof stmt_bufb,"SELECT dpolicy FROM %s:ply_relation \
                             WHERE ipolicy = '%s' ",
                           tmp_dbname, MIpolicy );

         $PREPARE EXE_STMTb FROM $stmt_bufb;
         $EXECUTE EXE_STMTb INTO $ldpolicy;

         /**  �w���d���I�u���Ӥ��H�� **/
         if (fins_grp[0]=='2')
         {
            if (strncmp(MIins_type[ilength],"A",1) == 0 ||
                  strcmp(MIins_type,INJURE)==0)
               MInj_qlia = MQlia;

            if (strncmp(MIins_type[ilength],"B",1) == 0 ||
                  strcmp(MIins_type,DEATH)==0)
               MDea_qlia = MQlia;

            if (strncmp(MIins_type[ilength],"C",1) == 0 ||
                  strcmp(MIins_type,CRIPPLE)==0)
               MCri_qlia = MQlia;

            if ( ldpolicy < date_1000901 && 
                 strcmp( trim(iins_type_rule), "15") != 0 &&
                 strcmp( trim(iins_type_rule), "16") != 0 ) /* ñ���< 10/20/2010�A�ǰeinsurance_type.iins_type_rule */
                $UPDATE APPINS
                    SET (TMins_app,TDappraisal,
                         TInj_qlia,TDea_qlia,TCri_qlia)
                      = (TMins_app+$MMins_app,$MDappraisal,
                         TInj_qlia+$MInj_qlia,TDea_qlia+$MDea_qlia,
                         TCri_qlia+$MCri_qlia)
                  WHERE TIclaim    = $MIclaim
                    AND TIins_type = $iins_type_rule;
            else
                $UPDATE APPINS
                    SET (TMins_app,TDappraisal,
                         TInj_qlia,TDea_qlia,TCri_qlia)
                      = (TMins_app+$MMins_app,$MDappraisal,
                         TInj_qlia+$MInj_qlia,TDea_qlia+$MDea_qlia,
                         TCri_qlia+$MCri_qlia)
                  WHERE TIclaim    = $MIclaim
                    AND iins_ply = $iins_ply;

            if (sqlca.sqlerrd[2] == 0)
            {
               $INSERT INTO APPINS ( TIclaim, TIins_type, TQlia, TMins_app, TDappraisal,
                                     TIpolicy,TIacc_license, TIacc_birth, TNacc_driver,
                                     TFacc_sex, TFacc_marri, TFacc_nation, TIacc_reason,
                                     TDaccident, TIacc_area, TFpart, TFacc_car, TFacc_duty,
                                         TInj_qlia,TDea_qlia,TCri_qlia,T_itag, iins_type, iins_ply)
                VALUES ( $MIclaim, $iins_type_rule, $MQlia, $MMins_app, $MDappraisal,
                         $MIpolicy, $MIacc_license, $MIacc_birth, $MNacc_driver,
                         $MFacc_sex,$MFacc_marri, $MFacc_nation, $MIacc_reason,
                         $MDaccident, $MIacc_area, $MFpart, $MFacc_car, $MFacc_duty,
                         $MInj_qlia,$MDea_qlia,$MCri_qlia,$sItag, $MIins_type, $iins_ply);
            }
         }
         else
         {
            if ( ldpolicy < date_1000901 && 
                 strcmp( trim(iins_type_rule), "15") != 0 &&
                 strcmp( trim(iins_type_rule), "16") != 0 ) /* ñ���< 10/20/2010�A�ǰeinsurance_type.iins_type_rule */
                $UPDATE APPINS
                    SET (TMins_app,TDappraisal)
                      = (TMins_app+$MMins_app,$MDappraisal)
                  WHERE TIclaim    = $MIclaim
                    AND TIins_type = $iins_type_rule;
            else
                $UPDATE APPINS
                    SET (TMins_app,TDappraisal)
                      = (TMins_app+$MMins_app,$MDappraisal)
                  WHERE TIclaim    = $MIclaim
                    AND iins_ply = $iins_ply;

            if (sqlca.sqlerrd[2] == 0)
            {
               $INSERT INTO APPINS ( TIclaim, TIins_type, TQlia, TMins_app, TDappraisal,
                                     TIpolicy,TIacc_license, TIacc_birth, TNacc_driver,
                                     TFacc_sex, TFacc_marri, TFacc_nation, TIacc_reason,
                                     TDaccident, TIacc_area, TFpart, TFacc_car, TFacc_duty,
                                     TInj_qlia,TDea_qlia,TCri_qlia,T_itag, iins_type, iins_ply)
                VALUES ( $MIclaim, $iins_type_rule, $MQlia, $MMins_app, $MDappraisal,
                         $MIpolicy, $MIacc_license, $MIacc_birth, $MNacc_driver,
                         $MFacc_sex,$MFacc_marri, $MFacc_nation, $MIacc_reason,
                         $MDaccident, $MIacc_area, $MFpart, $MFacc_car, $MFacc_duty,
                         $MInj_qlia,$MDea_qlia,$MCri_qlia,$sItag, $MIins_type, $iins_ply);
            }
         }

         /* �N���N�O���J�Ȧstable�� */
         $INSERT INTO tmp_policy (ipolicy) VALUES ($MIpolicy);
      } /* end of while */
      $CLOSE CUR_APP;
      $FREE  CUR_APP;

      /* �P�_�Y�O����(01,02,32,34)�B���O(01,05,09,31,32,86,110,113,114)���@�I��,���e���T */
      /* 107.08.20 �W�[�ǰe149�I�� */
      if ( strcmp(option,"Y") == 0 )
      {
         sprintf_s(stmt_buf5, sizeof stmt_buf5,"insert into del_50_policy "
                           "select ipolicy from %s:ply_relation a "
                           " where ipolicy in (select ipolicy from tmp_policy) "
                           "   and icar_type in ('01','02','32','34') "
                           "   and ipolicy not in (select unique ipolicy from %s:ply_ins_type "
                           "                        where ipolicy = a.ipolicy "
                           "                          and iins_type in ('01','05','09','31','32','86','110','113','114','149','157','158','159','201','205','209','231','232','249')) ",
      	                  list[i].dbname,list[i].dbname);
         printf("���� stmt2[%s]\n",stmt_buf5);

         $PREPARE cur_tmp1 FROM  $stmt_buf5;
         $EXECUTE cur_tmp1;
      }
      else
      {
         /* car9901111 �P�_�Y�O��l�O��ȩӫO50�I�خ�,�h�ӫO�椣�e���T */
         /* �N�ŦX��ӫO50�O���Jtemp table, �ñqTABLE CAR9971�R�� */
         sprintf_s(stmt_buf5, sizeof stmt_buf5,"insert into del_50_policy "
      	                  "select ipolicy from %s:ori_ins_type a "
      	                  "where ipolicy in (select ipolicy from tmp_policy) "
      	                  "  and iins_type = '50' "
                           "  and not exists (select 1 from %s:ori_ins_type b where a.ipolicy = b.ipolicy "
                           "  and a.iins_type <> b.iins_type)",list[i].dbname,list[i].dbname);
         printf("stmt2[%s]\n",stmt_buf5);
   
         $PREPARE cur_tmp1 FROM  $stmt_buf5;
         $EXECUTE cur_tmp1;
      
         sprintf_s(stmt_buf5, sizeof stmt_buf5,"insert into del_50_policy "
                           "select ipolicy from %s:ori_ply_relation a "
                           " where ipolicy in (select ipolicy from tmp_policy) "
                           "   and icar_type in ('01','02','32','34') "
                           "   and ipolicy not in (select unique ipolicy from %s:ori_ins_type "
                           "                        where ipolicy = a.ipolicy "
                           "                          and iins_type in ('01','05','09','31','32','86','110','113','114','149','157','158','159','201','205','209','231','232','249')) ",
      	                  list[i].dbname,list[i].dbname);
         
         printf("���� stmt2[%s]\n",stmt_buf5);

         $PREPARE cur_tmp1 FROM  $stmt_buf5;
         $EXECUTE cur_tmp1;      	                  
      }
      
      $SELECT count(*) INTO $tmp_cnt FROM APPINS;
      printf("delete before APPINS count = [%d]\n",tmp_cnt);

      $DELETE FROM APPINS WHERE Tipolicy in (select ipolicy from del_50_policy);

      $SELECT count(*) INTO $tmp_cnt FROM APPINS;
      printf("delete after APPINS count = [%d]\n",tmp_cnt);

      $DELETE FROM del_50_policy WHERE 1=1;
      $DELETE FROM tmp_policy WHERE 1=1;

   } /* end of select db */


   iFetch  = True;
   lInj_qlia = lDea_qlia = lCri_qlia = 0;
   $DECLARE CUS4 CURSOR for
      SELECT *
        INTO $sIclaim, $sIins_type, $lQlia, $lMins_app, $sDappraisal,
             $sIpolicy, $sIacc_license, $sIacc_birth,  $sNacc_driver,
             $sFacc_sex,$sFacc_marri,   $sFacc_nation, $sIacc_reason,
             $sDaccident, $sIacc_area, $sFpart, $sFacc_car, $sFacc_duty,
             $lInj_qlia,$lDea_qlia,$lCri_qlia,$sItag, $MIins_type, $iins_ply
        FROM APPINS
       ORDER BY TDappraisal,TIclaim,TIins_type;

   $OPEN CUS4;
   while (1)
   {
      memset(sPrtstr,' ',sizeof(sPrtstr));

      $FETCH CUS4;

      if (SQLCODE == SQLNOTFOUND) break;

      printf("sDappraisal[%s]\n",sDappraisal);

      rstrdate( sDappraisal , &Dappraisal );

      if (risnull(2,&lQlia)==1) lQlia=0;
      if (risnull(2,&lMins_app)==1) lMins_app=0;

      iRtnCode = split_policy(sIpolicy, sIpolicy1, sIpolicy2);
      if (iRtnCode != M_CM_OK) break;

      company_flag=sIpolicy1[7];

      strcpy(COMPANY,companyid);
      strcpy(COMPANY_F,companyid);

      if(strcmp( companyid,"17")==0)
      {
         if(company_flag > 65 )
         {
            $select ipolicy_a
               into $sIpolicy1
               from conv_ipolicy
              where ipolicy_n = $sIpolicy1;

            strcpy(COMPANY,"16");
         }

         iclaim_flag=sIclaim[6];

         if(iclaim_flag > 65 )
         {
            $select distinct iclaim_a
               into $sIclaim
               from conv_iclaim
              where iclaim_n = $sIclaim;

            strcpy(COMPANY_F,"16");
         }
      }


      if(iFetch)
      {
         oldDappraisal = Dappraisal;
         iFetch = FALSE;

         if (strcmp(option,"4")==0 || strcmp(option,"5")==0)
         {
            cm_split_ymd_100(datebgn,day_yy,day_mm,day_dd);
         }
         else
         {
            strcpy( sDappraisal_c , cm_cdate_str_100( Dappraisal ));
            cm_split_ymd_100(sDappraisal_c,day_yy,day_mm,day_dd);
         }

         printf("sDappraisal_c [%s]\b",sDappraisal_c);

         if (strcmp(option,"Y")==0)
         {
            /* ���v�ɥH�~�׬��ɦW�����u���ͤ@���ɮ� */
            sprintf_s(Tmp1, sizeof Tmp1,"ISBM%s_2011h",companyid);
         }
         else
         { 
            sprintf_s(Tmp1, sizeof Tmp1,"ISBM%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
         }
         strcpy(iply_type,opt);
         strcpy(fcard_class, "2");

         sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);

         printf("file0[%s] Tmp1[%s]\n",file0,Tmp1);
         fptr=fopen(file0,"w");

         if (strcmp(option,"4")!=0 && strcmp(option,"5")!=0)
         {  
            if (strcmp(option,"Y") != 0)
            {
               rc = check_if_exist(iply_type,Dappraisal,fcard_class,0);
               if ( rc != M_CM_OK )
                  return rc;
            }
         }
      }

      if ( oldDappraisal != Dappraisal ) /* �����ثefile , open a new file*/
      {
         if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0) 
         { 
            if (strcmp(option,"Y") != 0)
            {
                /* ���e�έ簣���e&���v�ɤ����̤�������ɮ� */
               $INSERT INTO TRADE_COUNT
                  ( file_name, policy_day, qcount, Tastype )
                VALUES
                  ( $Tmp1, $oldDappraisal, $cntrlrec, 'A' );
   
               fclose(fptr);
   
               strcpy( sDappraisal_c , cm_cdate_str_100( Dappraisal ));
   
               cm_split_ymd_100(sDappraisal_c,day_yy,day_mm,day_dd);
   
               sprintf_s(Tmp1, sizeof Tmp1,"ISBM%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
               strcpy(iply_type,opt);
               strcpy(fcard_class, "2");
   
               sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
   
               printf("file0[%s] Tmp1[%s]\n",file0,Tmp1);
               fptr=fopen(file0,"w");
   
               rc = check_if_exist(iply_type,Dappraisal,fcard_class,0);
               if ( rc != M_CM_OK )
                  return rc;
   
               cntrlrec = 0;
            }
         }
      }

      oldDappraisal = Dappraisal;

      strcpy(tmp_dbname,get_car_full_db(sIpolicy));

      sprintf_s(stmt_bufd, sizeof stmt_bufd,"SELECT count(*) FROM %s:app_ins_type_hist \
                          WHERE iclaim = '%s' \
                            AND iins_type = '%s' \
                            AND dappraisal < '%s'",
                        tmp_dbname, sIclaim, MIins_type, sDappraisal );
 

      $PREPARE EXE_STMTd FROM $stmt_bufd;
      $EXECUTE EXE_STMTd INTO $iCount;
      
      if( iCount == 0)
      {   strcpy(sPrtstr,"9"); sPrtstr[1]='\0';}          /*C1:���ʧO 9:original */
      else
      {   strcpy(sPrtstr,"5"); sPrtstr[1]='\0';}          /*C1:���ʧO 5:replace */

      strcat(sPrtstr,"1"); sPrtstr[2]='\0';           /*C2:�w��*/
      strcat(sPrtstr,COMPANY_F); sPrtstr[4]='\0';       /*C3-1:���q�O*/
      strncat(sPrtstr,sIclaim,14); sPrtstr[18]='\0';  /*C3-2:�߮ר��z��*/
      strcat(sPrtstr,COMPANY_F); sPrtstr[20]='\0';      /*C4-1:���q�O*/
      strncat(sPrtstr,sIclaim,14); sPrtstr[34]='\0';  /*C4-2:�߮׸�*/
      strcat(sPrtstr, "     ");                       /*C5 ����     */
      strcat(sPrtstr, "        ");                    /*C6��� */
      sPrtstr[47]='\0';

      strcat(sPrtstr,COMPANY); sPrtstr[49]='\0';      /*C7-1:���q�O*/
      strcat(sPrtstr,sformat_trade(sIpolicy1,2 ,15));
      sPrtstr[64]='\0';                               /*C7-2:�O�渹*/

      if (strlen(rtrim(sIpolicy2))>0)                 /* ���j�O��*/
      {
         strcpy(sObjno, sformat_trade(sIpolicy2, 2, 4));
      }
      else
      {
         strcpy(sObjno,"0001");
      }
      /*** sObjno[CAR_TARGET_LEN+1]='\0';  ***/
      strcat(sPrtstr,sObjno); sPrtstr[68]='\0';               /*C8:�Ъ���*/

      if (strlen(trim(sItag))<=0)
         strcpy(sItag, "        ");
      strcat(sPrtstr,sItag); sPrtstr[76]='\0';                /*C9:�P�Ӹ�*/
      strcat(sPrtstr,sIacc_license); sPrtstr[86]='\0';        /*C10-1:�r��*/

      /*strncpy(sIacc_birth_yy,sIacc_birth,2);*/                  /*C10-2 �ͤ�*/
      /*sIacc_birth_yy[2] = '\0';
      sIacc_birth_mm[0]= sIacc_birth[2];
      sIacc_birth_mm[1]= sIacc_birth[3];
      sIacc_birth_mm[2]='\0';

      sIacc_birth_dd[0]= sIacc_birth[4];
      sIacc_birth_dd[1]= sIacc_birth[5];
      sIacc_birth_dd[2]='\0';

      strcpy(sIacc_birth_yyyy,itoa(1911+atoi(sIacc_birth_yy)));*/
      strncat(sPrtstr, sIacc_birth_yyyy,4);
      sPrtstr[90]='\0';
      strcat(sPrtstr,sIacc_birth_mm); sPrtstr[92]='\0';
      strcat(sPrtstr,sIacc_birth_dd);  sPrtstr[94]='\0';

      strcat(sPrtstr,sNacc_driver); sPrtstr[114]='\0';        /*C10-3:�m�W*/
      strcat(sPrtstr,sFacc_sex); sPrtstr[115]='\0';           /*C10-4:�ʧO*/
      strcat(sPrtstr,sFacc_marri); sPrtstr[116]='\0';         /*C10-5:�B��*/
      strcat(sPrtstr,sFacc_nation); sPrtstr[117]='\0';        /*C10-6:��O*/
      strcat(sPrtstr,sIacc_reason); sPrtstr[119]='\0';        /*C11:�X�I��]*/

      rfmtlong(lInj_qlia,"&&&",sInjure);
      rfmtlong(lDea_qlia,"&&&",sDeath);
      rfmtlong(lCri_qlia,"&&&",sCripple);
      strcat(sPrtstr,sInjure); sPrtstr[122]='\0';             /*���*/
      strcat(sPrtstr,sDeath); sPrtstr[125]='\0';              /*���`*/
      strcat(sPrtstr,sCripple); sPrtstr[128]='\0';            /*�ݼo*/

      strncat(sPrtstr,sDaccident,4); sPrtstr[132]='\0';       /*CCYY*/
      strncat(sPrtstr,(sDaccident+5),2); sPrtstr[134]='\0';   /*MM*/
      strncat(sPrtstr,(sDaccident+8),2); sPrtstr[136]='\0';   /*DD*/
      strncat(sPrtstr,(sDaccident+11),2); sPrtstr[138]='\0';  /*HH*/
      strcat(sPrtstr,"00"); sPrtstr[140]='\0';

      /* �N�{��u�a�ϥN�����v���R���N��42�u�x�����v�B�N��63�u�x�n���v�B�N��65�u�������v�C*/
      if( strcmp( sIacc_area, "42") == 0)
        	strcpy( sIacc_area, "41");
      else if( strcmp( sIacc_area, "63") == 0)
		strcpy( sIacc_area, "62");
      else if( strcmp( sIacc_area, "65") == 0)
		strcpy( sIacc_area, "64");

      strcat(sPrtstr,sIacc_area); sPrtstr[142]='\0';
      printf("sFpart[%s]\n", sFpart);
      if (*sFpart=='1' || *sFpart=='2' || *sFpart=='3')
         sFpart_A[0]='1';
      else
         sFpart_A[0]='2';

      strcat(sPrtstr,sFpart_A); sPrtstr[143]='\0';                  /* ���l�B���l�O�N */

      sprintf_s(stmt_bufa, sizeof stmt_bufa,"SELECT dpolicy FROM %s:ply_relation \
                          WHERE ipolicy = '%s' ",
                        tmp_dbname, sIpolicy );

      $PREPARE EXE_STMTa FROM $stmt_bufa;
      $EXECUTE EXE_STMTa INTO $ldpolicy;
      
             if ( ldpolicy < date_1000901 &&
                 strcmp( trim( sIins_type), "15") != 0 &&
                 strcmp( trim( sIins_type), "16") != 0) /* ñ���< 10/20/2010�A�ǰeinsurance_type.iins_type_rule */
             {
                 puts("ñ���<10/20/2010");
                 strcat(sPrtstr, sIins_type);                     /*C144-149:�����I�إN�X*/
             }
             else
             {
                 puts("ñ���>=10/20/2010");
                 strcat(sPrtstr, iins_ply);                     /*C144-149:�����I�إN�X*/
             }

             sPrtstr[149]='\0';

             rfmtlong(0,"&&&",sInjure_1);
             rfmtlong(0,"&&&",sDeath_1);
             rfmtlong(0,"&&&",sCripple_1);
             strcat(sPrtstr,sInjure_1); sPrtstr[152]='\0';  /*150-152:���*/
             strcat(sPrtstr,sDeath_1); sPrtstr[155]='\0';   /*153-155:���`*/
             strcat(sPrtstr,sCripple_1); sPrtstr[158]='\0'; /*156-158:�ݼo*/

             rfmtlong(lMins_app,"&&&&&&&&&&&&",sMins_app);
             strcat(sPrtstr,sMins_app); sPrtstr[170]='\0';  /*159-170:�w���l�����B */
             strcat(sPrtstr,"       ");                     /*171-177:�z�ߦۭt�B */
             sPrtstr[177]='\0';
             strcat(sPrtstr,"            ");                /*178-189:��ڲz�ߪ��B���l�v���B */
             sPrtstr[189]='\0';
             strcat(sPrtstr,"        ");                    /*190-197:��˲z�ߪ��B */
             sPrtstr[197]='\0';
             strcat(sPrtstr,"        ");                    /*198-205:���`�z�ߪ��B */
             sPrtstr[205]='\0';
             strcat(sPrtstr,"        ");                    /*206-213:�ݼo�z�ߪ��B */
             sPrtstr[213]='\0';
             strcat(sPrtstr,"            ");                /*214-225:�M�Ѫ��B */
             sPrtstr[225]='\0';
             strcat(sPrtstr,"       ");                     /*226-232:�z�߶O�� */
             sPrtstr[232]='\0';

             strncat(sPrtstr,(sDappraisal+6),4); sPrtstr[236]='\0'; /*233-240:�w����� */
             strncat(sPrtstr,sDappraisal,2); sPrtstr[238]='\0';
             strncat(sPrtstr,(sDappraisal+3),2); sPrtstr[240]='\0';

             strcat(sPrtstr,sFacc_car); sPrtstr[241]='\0';          /*241-241:�r�p�H�ϧO */
             strcat(sPrtstr,sFacc_duty); sPrtstr[242]='\0';         /*242-242:�F�d */
             strcat(sPrtstr,"                 ");                   /*243-259:�O�I�Ҹ� */
             sPrtstr[259]='\0';

             strcpy(iins_type_tradevan," ");
             $SELECT iins_type_tradevan
                INTO $iins_type_tradevan
                FROM insurance_type
               WHERE iins_type = $sIins_type;

             strcat(sPrtstr, iins_type_tradevan); sPrtstr[261]='\0';         /* 260-261:�F�d�I�إN�� */

             printf ("[%s]\n",sPrtstr);

             fprintf(fptr,"%s\n",sPrtstr);
             cntrlrec++;
   }
   $CLOSE CUS4;
   $FREE  CUS4;

   if ( cntrlrec > 0 )
   {
      $INSERT INTO TRADE_COUNT
         ( file_name, policy_day, qcount, Tastype )
       VALUES
         ( $Tmp1, $oldDappraisal, $cntrlrec, 'A' );

      fclose(fptr);
   }

   return(SUCCESS);

errexit:
     printf("car9973vol_app_ins:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
     EWRITE(userid,SQLCODE,sqlca.sqlerrm);
     return SQLCODE;
}
/*--------------------���N�w�M--------------------------------------------*/
/* 101/03/01�_, �]���s�����N�I���T�ǿ�W�椣�A�ϥ�,�אּ�ϥ�lStl_ins2() add by sylvia 101.01.02 */
long lStl_ins()
{
   $char  sIpolicy[POLICY_NUM_1],sObjno[CA_TARGET_NUM+1];

   $char  sIpolicy1[POLICY_NUM_1], sIpolicy2[POLICY_NUM_2];
   long  iRtnCode=0;
   int   iFetch=0,ilength=0;

   $char  sIclaim[CLAIM_NUM],sIins_type[INSURANCE_TYPE];
   $char  iins_type_rule[INSURANCE_TYPE],fins_grp[2];
   $char  sItag[CA_TAG_NUM],sDappraisal[11],sFstl[2],sFlast[2];
   $char  sIacc_license[11],sIacc_birth[7],sIacc_birth_yy[3],sIacc_birth_mm[3];
   $char  sIacc_birth_yyyy[5];
   $char  sIacc_birth_dd[3],sNacc_driver[21],sFacc_sex[2],sFacc_marri[2];
   $char  sFacc_nation[2],sIacc_reason[3],sDaccident[14],sIacc_area[3];
   $char  sFpart[2],sFpart_A[2], sFacc_car[2],sFacc_duty[2];
   $long  lDgroup=0,lQinjure=0,lQdeath=0,lMins_comp=0,lMins_dedu=0,lMins_stl=0,lMins_proc=0;
   $long  lIclose_type=0;
   $long Dappraisal=0,oldDappraisal=0;
   char  sQinjure[4],sQdeath[4],sQcripple[4],sIclose_type[6];
   char  sQinjure_1[4],sQdeath_1[4],sQcripple_1[4];
   char  sQinjure_stl[9],sQdeath_stl[9],sQcripple_stl[9];
   char  sMins_dedu[8],sMins_stl[13],sMins_comp[13],sMins_proc[8];
   char  sDgroup_yyyy[5], sDgroup_mm[3], sDgroup_dd[3];
   char sPrtstr[262];
   $char sDgroup[11],fcard_class[2],stmt_buf6[512];
   $char MIclaim[21], MFstl[2], MFlast[2], MIins_type[7];
   $char MIacc_license[11], MIacc_birth[7], MNacc_driver[11];
   $long MDgroup=0;
   $char MFacc_sex[2], MFacc_marri[2], MFacc_nation[2], MIacc_reason[3];
   $char MDaccident[14], MIacc_area[3], MFpart[2], MFacc_car[2], MFacc_duty[2], MIpolicy[21];
   $long MQinjure=0, MMins_comp=0, MMins_dedu=0, MMins_stl=0, MMins_proc=0;
   $int  MIclose_type=0;
   $long T9A_qlia=0,T9B_qlia=0,T9C_qlia=0;
   $long T9A_mstl=0,T9B_mstl=0,T9C_mstl=0;
   $long l29_dgroup=0, tmp_cnt = 0;
   $long lDbgn_u=0, lDbgn_s=0, lDend_u=0, lDend_s=0;
   $char sDbgn_s[11], sDend_s[11], sTmplog[100], facc_car[2], fsystem[2], fassured[2];
   long  year1=0, year2=0;
   $char chk_dpolicy[2];

     $long date_1000901, ldpolicy;
     $char iins_type_tradevan[INSURANCE_TYPE], tmp_dbname[20], iins_ply[INSURANCE_TYPE];
     $char stmt_bufb[256], stmt_bufc[256];

   $WHENEVER SQLERROR GOTO errexit;
   printf ("lStl_ins\n");
   
   if ( strcmp(option,"Y") == 0 )
   {
      /* �ˮ֩ҤU���_����O�_�W�L���� */
         lDbgn_u = cm_ymd_edate(datebgn);    /* �ϥΪ̿�J�_�� */
         lDend_u = cm_ymd_edate(dateend);    /* �ϥΪ̿�J�_�� */
         
         $select date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10])),
                 date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10]))
            into $lDbgn_s, $sDbgn_s
            from cu_code_data
           where itype = 'CA' and icode = '02';
        
         
         $select date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10])),
                 date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10]))  
            into $lDend_s, $sDend_s
            from cu_code_data
           where itype = 'CA' and icode = '03';
        
         printf("datebgn=[%s]lDbgn_u=[%ld]\n",datebgn,lDbgn_u);
         printf("dateend=[%s]lDend_u=[%ld]\n",dateend,lDend_u);
         printf("sDbgn_s=[%s]lDbgn_s=[%ld]\n",sDbgn_s,lDbgn_s);
         printf("sDend_s=[%s]lDend_s=[%ld]\n",sDend_s,lDend_s);
         
         if ((lDbgn_u < lDbgn_s) || (lDbgn_u > lDend_s))
         {
            sprintf_s(strlog, sizeof strlog,"���v�ɰ_�鶷���� %s ~ %s ����,�нT�{!", sDbgn_s, sDend_s);
            return 100;
         }
         
         if ((lDend_u > lDend_s) || (lDend_u < lDbgn_s))
         {
            sprintf_s(strlog, sizeof strlog,"���v�ɨ��鶷���� %s ~ %s ����,�нT�{!", sDbgn_s, sDend_s);
            return 100;
         }
   }

   sIcar_type[0] = '\0';
   sItag[0]='\0';
   sDappraisal[0]= '\0';
   sIacc_license[0]= '\0';
   sIacc_birth[0]='\0';
   sIacc_birth_yy[0]='\0';
   sIacc_birth_mm[0]='\0';
   sIacc_birth_dd[0]='\0';
   sNacc_driver[0]='\0';
   sFacc_sex[0]='\0';
   sFacc_marri[0]= '\0';
   sFacc_nation[0]='\0';
   sIacc_reason[0]='\0';
   sDaccident[0]='\0';
   sIacc_area[0]='\0';
   sFpart[0]= '\0';
   sFpart_A[0]= '\0';
   sFacc_car[0]='\0';
   sFacc_duty[0]='\0';
   sIacc_birth_yyyy[0]='\0';
   T9A_qlia=T9B_qlia=T9C_qlia=0;
   T9A_mstl=T9B_mstl=T9C_mstl=0;
   MDgroup = 0;
   l29_dgroup = 0;
   chk_dpolicy[0]='\0';

   rstrdate( "09/01/2011", &date_1000901);

   memset(sTmt_buf,' ',sizeof(sTmt_buf));

   $CREATE TEMP TABLE STLINS
   (
      TIclaim char(20),
      TFstl   char(1),
      TFlast  char(1),
      TIclose_type  int,
      TIins_type    char(6),
      TDgroup       date,
      TQinjure      int,
      TMins_comp    int,
      TMins_dedu    int,
      TMins_stl     int,
      TMins_proc    int,
      TIacc_license char(10),
      TIacc_birth   char(6),
      TNacc_driver  char(18),
      TFacc_sex     char(1),
      TFacc_marri   char(1),
      TFacc_nation  char(1),
      TIacc_reason  char(2),
      TDaccident    char(13),
      TIacc_area    char(2),
      TFpart      char(1),
      TFacc_car   char(1),
      TFacc_duty  char(1),
      TIpolicy    char(20),
      T9A_qlia    int default 0,
      T9B_qlia    int default 0,
      T9C_qlia    int default 0,
      T9A_mstl    int default 0,
      T9B_mstl    int default 0,
      T9C_mstl    int default 0,
      T_itag	  char(8),
      iins_type   char(6),
      iins_ply   char(6)
     )WITH NO LOG;

   $CREATE UNIQUE INDEX STLINS_IX ON
      STLINS( TIclaim, TFstl, TIclose_type, iins_ply);

   iFetch = True;
   for ( i=0;i<count_db;i++)
   {
      if ( strcmp(option,"Y") == 0 )
      {
         /* �ɾ����I�z�߾��v��� */
          sprintf_s(sTmt_buf, sizeof sTmt_buf,"SELECT a.iclaim,a.fstl,a.flast,a.iclose_type,a.iins_type, "
                          "a.dgroup,a.qlia,a.mins_comp,a.mins_dedu,a.mins_stl,a.mins_proc, "
                          "b.iacc_license,b.iacc_birth,b.nacc_driver,b.facc_sex,b.facc_marri, "
                          "b.facc_nation,b.iacc_reason,b.daccident,b.iacc_area, "
                          "b.fpart,b.facc_rel,"
                          "decode(d.fins_grp,'1',b.fdmg_duty,b.facc_duty), "
                          "b.ipolicy, c.itag,"
                          "decode(d.iins_type_rule,'21','23',d.iins_type_rule),"
                          "d.fins_grp, b.facc_car, e.fsystem, f.fassured, d.iins_ply, c.icar_type,"
                          "CASE WHEN g.dpolicy < '08/01/2016' THEN 'Y' ELSE 'N' END"
                          " FROM %s:stl_ins_type a,%s:appraisal b,%s:adjustment_ply c, "
                          "      insurance_type d, ca_clm_process e, %s:policy f, %s:ply_relation g"
                          "WHERE a.iclaim=b.iclaim AND b.iclaim=c.iclaim "
                          "   AND b.iclaim = e.iclaim "
                          "   AND b.ipolicy = e.ipolicy "
                          "   AND b.ipolicy = f.ipolicy "
                          "   AND b.ipolicy = g.ipolicy "
                          "  AND a.iins_type = d.iins_type "
                          "  AND date(b.daccident) BETWEEN  '%s' AND  '%s' "
                          "  AND a.dgroup  <= '%s' "
   		    		        "  AND a.iclaim[6] <> 'W' "
   		    		        "  AND c.icar_type IN ('01','02','32','34') "
   		    		        "  AND f.ipolicy[6,7] not in ('VW','EB','TV') "
                          "ORDER BY 1,2,4,26,5,6",list[i].dbname,
                          list[i].dbname,list[i].dbname, list[i].dbname, sDappraisal_bgn, 
                          sDappraisal_end, sDend_s);
   
         printf("�������v��:sTmt[%s]\n",sTmt_buf);
      }
      else
      {
         /* 1000413004_C1 �����I�]�n�e���T�@mark by sylvia 100.05.02 */
         sprintf_s(sTmt_buf, sizeof sTmt_buf,"SELECT a.iclaim,a.fstl,a.flast,a.iclose_type,a.iins_type, "
                          "a.dgroup,a.qlia,a.mins_comp,a.mins_dedu,a.mins_stl,a.mins_proc, "
                          "b.iacc_license,b.iacc_birth,b.nacc_driver,b.facc_sex,b.facc_marri, "
                          "b.facc_nation,b.iacc_reason,b.daccident,b.iacc_area, "
                          "b.fpart,b.facc_rel,"
                          "decode(d.fins_grp,'1',b.fdmg_duty,b.facc_duty), "
                          "b.ipolicy, c.itag,"
                          "decode(d.iins_type_rule,'21','23',d.iins_type_rule),"
                          "d.fins_grp, b.facc_car, e.fsystem, f.fassured, d.iins_ply, c.icar_type,"
                          "CASE WHEN g.dpolicy < '08/01/2016' THEN 'Y' ELSE 'N' END"
                          " FROM %s:stl_ins_type a,%s:appraisal b,%s:adjustment_ply c, "
                          "      insurance_type d, ca_clm_process e, %s:policy f, %s:ply_relation g"
                          "WHERE a.iclaim=b.iclaim AND b.iclaim=c.iclaim "
                          "   AND b.iclaim = e.iclaim "
                          "   AND b.ipolicy = e.ipolicy "
                          "   AND b.ipolicy = f.ipolicy "
                          "   AND b.ipolicy = g.ipolicy "
                          "  AND a.iins_type = d.iins_type "
                          "  AND a.dgroup  BETWEEN '%s' AND '%s' %s "
   		    		        "  AND a.iclaim[6] <> 'W' "
   		    		        "  AND f.ipolicy[6,7] not in ('VW','EB','TV') "
                          "ORDER BY 1,2,4,26,5,6", list[i].dbname, list[i].dbname,
                          list[i].dbname,list[i].dbname,sDappraisal_bgn,
                          sDappraisal_end, sWhere);
   
         printf("���`��:sTmt[%s]\n",sTmt_buf);
      }
      $PREPARE STMT3 FROM $sTmt_buf;
      $DECLARE CUSSTL CURSOR FOR STMT3;

      $OPEN CUSSTL;
      while(1)
      {
         $FETCH CUSSTL INTO $MIclaim,$MFstl,$MFlast,$MIclose_type,$MIins_type,
                            $MDgroup,$MQinjure,$MMins_comp,$MMins_dedu,
                            $MMins_stl,$MMins_proc,$MIacc_license,$MIacc_birth,
                            $MNacc_driver,$MFacc_sex,$MFacc_marri,$MFacc_nation,
                            $MIacc_reason,$MDaccident,$MIacc_area,$MFpart,
                            $MFacc_car,$MFacc_duty,$MIpolicy,$sItag,
                            $iins_type_rule,$fins_grp, $facc_car, $fsystem, $fassured, $iins_ply, $sIcar_type, $chk_dpolicy;

         if( SQLCODE == SQLNOTFOUND ) break;
         
         /* 1061102009_C1 �ק�ǰe���T27���ؾ��񨮵P�W�h
         if (strcmp(sIcar_type, "27") == 0 && strcmp(chk_dpolicy) == "Y")
            strcpy(sItag," "); */
         
			/*�r�p�H�ϧO*/
         if( fsystem[0] == 'N')
             strcpy( MFacc_car, facc_car);
         else
         {

			switch (MFacc_car[0])
			{
				case '1':
					break;
				case '2':
					break;
				case '3':
					/*�P�Q�O�I�H���Y = "3 ���u"*/
					/*�r�p�H�ϧO = "4 �����k�H"*/
					MFacc_car[0] = '4';
					break;
				case '4':
					/*�P�Q�O�I�H���Y = "4 ����"*/
					/*�r�p�H�ϧO = "4 �����k�H"*/
					MFacc_car[0] = '4';
					break;
				case '5':
					/*�P�Q�O�I�H���Y = "5 ��L"*/
                                        if( fassured[0] == '1' || fassured[0] == '3' || fassured[0] == '5')
					    MFacc_car[0] = '2'; /*�r�p�H�ϧO = "2 �w���ɥL�H��"*/
                                        else
					    MFacc_car[0] = '4'; /*�r�p�H�ϧO = "4 �����k�H"*/
					break;
				default :
					MFacc_car[0] = '2';
					break;
			}
         }

         T9A_qlia = T9B_qlia = T9C_qlia = 0;
         T9A_mstl = T9B_mstl = T9C_mstl = 0;

         strcpy(MIins_type,rtrim(MIins_type));
         ilength= strlen(MIins_type)-1;

         strcpy(tmp_dbname,get_car_full_db(MIpolicy));
         sprintf_s(stmt_bufc, sizeof stmt_bufc,"SELECT dpolicy FROM %s:ply_relation \
                             WHERE ipolicy = '%s' ",
                           tmp_dbname, MIpolicy );

         $PREPARE EXE_STMTc FROM $stmt_bufc;
         $EXECUTE EXE_STMTc INTO $ldpolicy;

         if (fins_grp[0]=='2')
         {
            if (strncmp(MIins_type[ilength],"A",1) == 0 ||
                strcmp(MIins_type,INJURE)==0)
            {
               T9A_qlia = MQinjure;
               T9A_mstl = MMins_stl;
            }

            if (strncmp(MIins_type[ilength],"B",1) == 0 ||
                strcmp(MIins_type,DEATH)==0)
            {
               T9B_qlia = MQinjure;
               T9B_mstl = MMins_stl;
            }

            if (strncmp(MIins_type[ilength],"C",1) == 0 ||
                strcmp(MIins_type,CRIPPLE)==0)
            {
               T9C_qlia = MQinjure;
               T9C_mstl = MMins_stl;
            }
         }

         if ( ldpolicy < date_1000901 &&
              strcmp( trim(iins_type_rule), "15") != 0 &&
              strcmp( trim(iins_type_rule), "16") != 0 ) /* ñ���< 10/20/2010�A�ǰeinsurance_type.iins_type_rule */
             $UPDATE STLINS
                SET (TDgroup,TMins_comp,TMins_dedu,TMins_stl,
                     TMins_proc,T9A_qlia,T9B_qlia,T9C_qlia,
                     T9A_mstl,T9B_mstl,T9C_mstl)
                  = ($MDgroup,TMins_comp+$MMins_comp,TMins_dedu+$MMins_dedu,
                     TMins_stl+$MMins_stl,TMins_proc+$MMins_proc,
                     T9A_qlia+$T9A_qlia,T9B_qlia+$T9B_qlia,T9C_qlia+$T9C_qlia,
                     T9A_mstl+$T9A_mstl,T9B_mstl+$T9B_mstl,T9C_mstl+$T9C_mstl)
              WHERE TIclaim      = $MIclaim
                AND TFstl        = $MFstl
                AND TIclose_type = $MIclose_type
                AND TIins_type   = $iins_type_rule;
        else
             $UPDATE STLINS
                SET (TDgroup,TMins_comp,TMins_dedu,TMins_stl,
                     TMins_proc,T9A_qlia,T9B_qlia,T9C_qlia,
                     T9A_mstl,T9B_mstl,T9C_mstl)
                  = ($MDgroup,TMins_comp+$MMins_comp,TMins_dedu+$MMins_dedu,
                     TMins_stl+$MMins_stl,TMins_proc+$MMins_proc,
                     T9A_qlia+$T9A_qlia,T9B_qlia+$T9B_qlia,T9C_qlia+$T9C_qlia,
                     T9A_mstl+$T9A_mstl,T9B_mstl+$T9B_mstl,T9C_mstl+$T9C_mstl)
              WHERE TIclaim      = $MIclaim
                AND TFstl        = $MFstl
                AND TIclose_type = $MIclose_type
                AND iins_ply   = $iins_ply;

         if (sqlca.sqlerrd[2] == 0)
         {
            $INSERT INTO STLINS ( TIclaim, TFstl, TFlast,
                                  TIclose_type, TIins_type,
                                  TDgroup, TQinjure, TMins_comp,
                                  TMins_dedu, TMins_stl,
                                  TMins_proc, TIacc_license,
                                  TIacc_birth, TNacc_driver,
                                  TFacc_sex, TFacc_marri,
                                  TFacc_nation, TIacc_reason,
                                  TDaccident,TIacc_area, TFpart,
                                  TFacc_car, TFacc_duty,
                                  TIpolicy,T9A_qlia,T9B_qlia,
                                  T9C_qlia,T9A_mstl,T9B_mstl,
                                  T9C_mstl,T_itag, iins_type, iins_ply)
             VALUES ( $MIclaim,$MFstl,$MFlast,
                      $MIclose_type,$iins_type_rule,
                      $MDgroup,$MQinjure,$MMins_comp,
                      $MMins_dedu,
                      $MMins_stl,$MMins_proc,
                      $MIacc_license,$MIacc_birth,
                      $MNacc_driver,$MFacc_sex,
                      $MFacc_marri,$MFacc_nation,
                      $MIacc_reason,$MDaccident,
                      $MIacc_area,$MFpart,
                      $MFacc_car,$MFacc_duty,$MIpolicy,
                      $T9A_qlia,$T9B_qlia,$T9C_qlia,
                      $T9A_mstl,$T9B_mstl,$T9C_mstl,$sItag, $MIins_type, $iins_ply);
         }

         /* �N���N�O���J�Ȧstable�� */
         $INSERT INTO tmp_policy (ipolicy) VALUES ($MIpolicy);
      } /* end of while */
      $CLOSE CUSSTL;
      $FREE  CUSSTL;

      if ( strcmp(option,"Y") == 0 )
      {
         /* �P�_�Y�O����(01,02,32,34)�B���O(01,05,09,31,32,86,110,113,114)���@�I��,���e���T */
         sprintf_s(stmt_buf6, sizeof stmt_buf6,"insert into del_50_policy "
                           "select ipolicy from %s:ply_relation a "
                           " where ipolicy in (select ipolicy from tmp_policy) "
                           "   and icar_type in ('01','02','32','34') "
                           "   and ipolicy not in (select unique ipolicy from %s:ply_ins_type "
                           "                        where ipolicy = a.ipolicy "
                           "                          and iins_type in ('01','05','09','31','32','86','110','113','114','149','157','158','159','201','205','209','231','232','249')) ",
      	                  list[i].dbname,list[i].dbname);
         printf("�������v stmt_buf6[%s]\n",stmt_buf6);
         $PREPARE cur_tmp1 FROM  $stmt_buf6;
         $EXECUTE cur_tmp1;
      }
      else
      {
         /* car9901111 �P�_�Y�O��l�O��ȩӫO50�I�خ�,�h�ӫO�椣�e���T */
         /* �N�ŦX��ӫO50�O���Jtemp table, �ñqTABLE CAR9971�R�� */
         sprintf_s(stmt_buf6, sizeof stmt_buf6,"insert into del_50_policy "
                           "select ipolicy from %s:ori_ins_type a "
                           "where ipolicy in (select ipolicy from tmp_policy) "
                           "  and iins_type = '50' "
                           "  and not exists (select 1 from %s:ori_ins_type b where a.ipolicy = b.ipolicy "
                           "  and a.iins_type <> b.iins_type)",list[i].dbname,list[i].dbname);
   
         printf("stmt2[%s]\n",stmt_buf6);
   
         $PREPARE cur_tmp1 FROM  $stmt_buf6;
         $EXECUTE cur_tmp1;
         
         /* �P�_�Y�O����(01,02,32,34)�B���O(01,05,09,31,32,86,110,113,114)���@�I��,���e���T */
         sprintf_s(stmt_buf6, sizeof stmt_buf6,"insert into del_50_policy "
                           "select ipolicy from %s:ori_ply_relation a "
                           " where ipolicy in (select ipolicy from tmp_policy) "
                           "   and icar_type in ('01','02','32','34') "
                           "   and ipolicy not in (select unique ipolicy from %s:ori_ins_type "
                           "                        where ipolicy = a.ipolicy "
                           "                          and iins_type in ('01','05','09','31','32','86','110','113','114','149','157','158','159','201','205','209','231','232','249')) ",
      	                  list[i].dbname,list[i].dbname);
         printf("���� stmt_buf6[%s]\n",stmt_buf6);
         $PREPARE cur_tmp1 FROM  $stmt_buf6;
         $EXECUTE cur_tmp1;
      }

      $SELECT count(*) INTO $tmp_cnt FROM STLINS;
      printf("delete before STLINS count = [%d]\n",tmp_cnt);

      $DELETE FROM STLINS WHERE Tipolicy in (select ipolicy from del_50_policy);

      $SELECT count(*) INTO $tmp_cnt FROM STLINS;
      printf("delete after STLINS count = [%d]\n",tmp_cnt);

      $DELETE FROM del_50_policy WHERE 1=1;
      $DELETE FROM tmp_policy WHERE 1=1;

   } /* end of select DB */

   prem_total = 0;
   cntrlrec = 0;
   qcount = Tamount = Tinjure = Tcripple = Tdeath = 0;

   $DECLARE CUS6 CURSOR for
       SELECT *
         INTO $sIclaim,$sFstl,$sFlast,$lIclose_type,$sIins_type,
              $sDgroup,$lQinjure,$lMins_comp,$lMins_dedu,
              $lMins_stl,$lMins_proc,$sIacc_license,$sIacc_birth,
              $sNacc_driver,$sFacc_sex,$sFacc_marri,$sFacc_nation,
              $sIacc_reason,$sDaccident,$sIacc_area,$sFpart,
              $sFacc_car,$sFacc_duty,$sIpolicy,$T9A_qlia,$T9B_qlia,$T9C_qlia,
              $T9A_mstl,$T9B_mstl,$T9C_mstl,$sItag, $MIins_type, $iins_ply
         FROM STLINS
        ORDER BY TDgroup;

   $OPEN CUS6;
   while (1)
   {
      memset(sPrtstr,' ',sizeof(sPrtstr));

      $FETCH CUS6;

      if (SQLCODE == SQLNOTFOUND) break;
      if (risnull(2,&lQinjure)==1) lQinjure=0;
      if (risnull(2,&lQdeath)==1) lQdeath=0;
      if (risnull(2,&lMins_comp)==1) lMins_comp=0;
      if (risnull(2,&lMins_dedu)==1) lMins_dedu=0;
      if (risnull(2,&lMins_stl)==1) lMins_stl=0;
      if (risnull(2,&lMins_proc)==1) lMins_proc=0;

      rstrdate( sDgroup , &close_date );

      sDgroup_mm[0]=sDgroup[0];
      sDgroup_mm[1]=sDgroup[1];
      sDgroup_mm[2]='\0';

      sDgroup_dd[0]=sDgroup[3];
      sDgroup_dd[1]=sDgroup[4];
      sDgroup_dd[2]='\0';

      sDgroup_yyyy[0]=sDgroup[6];
      sDgroup_yyyy[1]=sDgroup[7];
      sDgroup_yyyy[2]=sDgroup[8];
      sDgroup_yyyy[3]=sDgroup[9];
      sDgroup_yyyy[4]='\0';

      iRtnCode = split_policy(sIpolicy, sIpolicy1, sIpolicy2);
      if (iRtnCode != M_CM_OK) break;

      company_flag=sIpolicy1[7];

      strcpy(COMPANY,companyid);
      strcpy(COMPANY_F,companyid);

      if(strcmp( companyid,"17")==0)
      {
         if(company_flag > 65 )
         {
            $select ipolicy_a
               into $sIpolicy1
               from conv_ipolicy
              where ipolicy_n = $sIpolicy1;

            strcpy(COMPANY,"16");

         }

         iclaim_flag=sIclaim[6];

         if(iclaim_flag > 65 )
         {
            $select distinct iclaim_a
               into $sIclaim
               from conv_iclaim
              where iclaim_n = $sIclaim;

            strcpy(COMPANY_F,"16");

         }
      }

      if(iFetch)
      {
         old_close_date = close_date;
         iFetch = FALSE;

         if (strcmp(option,"4")==0 || strcmp(option,"5")==0)
         {
            cm_split_ymd_100(datebgn,day_yy,day_mm,day_dd);
         }
         else
         {
            strcpy( close_date_c , cm_cdate_str_100( close_date ));
            cm_split_ymd_100(close_date_c,day_yy,day_mm,day_dd);
         }

         if (strcmp(option,"Y")==0)
         {  /* ���v�ɥH�~�׬��ɦW, �u���ͤ@���� */
            sprintf_s(Tmp1, sizeof Tmp1,"is%s%s_2011h",opt,companyid);
         }
         else
         {
            sprintf_s(Tmp1, sizeof Tmp1,"ISBM%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
         }
         strcpy(iply_type,opt);
         strcpy(fcard_class, "2");

         printf("in iFetch fcard_class[%s]\n",fcard_class);

         sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);

         printf("file0[%s] Tmp1[%s]\n",file0,Tmp1);

         $SELECT qcount
            INTO $qcount
            FROM TRADE_COUNT
           WHERE file_name = $Tmp1;

         if ( SQLCODE == SQLNOTFOUND ) fptr=fopen(file0,"w");
         else  fptr=fopen(file0,"a+");
      }

      if ( old_close_date != close_date ) /* �����ثefile , open a new file*/
      {
         if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0) 
         {  
            /* ���e�έ簣���e&���v�ɤ����̤�������ɮ� */
            if (strcmp(option,"Y") != 0)
            {
               if (cntrlrec > 0)
               {
                  printf(" in stlins select \n");
   
                  $SELECT qcount
                     INTO $qcount
                     FROM TRADE_COUNT
                    WHERE file_name = $Tmp1;
   
                  qcount += cntrlrec;
   
                  $UPDATE TRADE_COUNT
                      SET ( qcount, Tamount, Tinjure, Tcripple, Tdeath, Tastype ) =
                          ( $qcount, $prem_total, $Tinjure, $Tcripple, $Tdeath, 'S' )
                    WHERE file_name = $Tmp1;
   
                  if ( sqlca.sqlerrd[2] == 0 )
                  {
                     printf("111:policy_day[%d]\n", old_close_date);
   
                     $INSERT INTO TRADE_COUNT
                        ( policy_day, file_name, qcount, Tamount, Tinjure, Tcripple, Tdeath, Tastype )
                      VALUES
                        ( $old_close_date, $Tmp1, $qcount, $prem_total, $Tinjure, $Tcripple, $Tdeath, 'S' );
                  }
   
                  strcpy(prtstr,"CNTRLREC");
                  rfmtlong(qcount,"&&&&&&",cntrlrec_c);
                  strcat(prtstr,cntrlrec_c);
                  fprintf(fptr, "%s\n", prtstr);
               }
   
               fclose(fptr);
   
               $SELECT policy_day, qcount, Tamount, Tinjure, Tcripple, Tdeath
                  INTO $policy_day, $qcount, $Tamount, $Tinjure, $Tcripple, $Tdeath
                  FROM TRADE_COUNT
                 WHERE file_name = $Tmp1;
    
   /*            rtncode = rptftpinsert( userid , "car9973" , Tmp1 );   */
   
               printf("before insert fcard_class[%s]\n",fcard_class);
   
               $insert into ca_trade_exam
                  (iply_type,dpolicy,fcard_class,itrans_type,
                   qcount,mamount,minjure,mcripple,mdeath)
                values
                  ($iply_type,$policy_day,$fcard_class,0,
                   $qcount,$Tamount,$Tinjure,$Tcripple,$Tdeath);
   
               sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%d",file0,qcount);
               WRITELOG(errfpt , strlog);
   
               strcpy( close_date_c , cm_cdate_str_100( close_date ));
   
               cm_split_ymd_100(close_date_c,day_yy,day_mm,day_dd);
   
               sprintf_s(Tmp1, sizeof Tmp1,"ISBM%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
               strcpy(iply_type,opt);
               strcpy(fcard_class, "2");
   
               sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
   
               $SELECT qcount
                  INTO $qcount
                  FROM TRADE_COUNT
                 WHERE file_name = $Tmp1;
   
               if ( SQLCODE == SQLNOTFOUND ) fptr=fopen(file0,"w");
               else  fptr=fopen(file0,"a+");
   
               cntrlrec = 0;
               prem_total = 0;
               qcount = Tamount = Tinjure = Tcripple = Tdeath = 0;
            }
         }
      }

      old_close_date = close_date;

      strcpy(sPrtstr,"9"); sPrtstr[1]='\0';           /*C1:���ʧO*/
      if (*sFstl=='1') strcat(sPrtstr,"2");           /*C2:��*/
      else  strcat(sPrtstr,"3");                      /*C2:�l*/
      sPrtstr[2]='\0';
      strcat(sPrtstr,COMPANY_F); sPrtstr[4]='\0';       /*C3-1:���q�O*/
      strncat(sPrtstr,sIclaim, 14);
      sPrtstr[18]='\0';                               /*C3-2:�߮ר��z��*/
      strcat(sPrtstr,COMPANY_F); sPrtstr[20]='\0';      /*C4-1:���q�O*/
      strncat(sPrtstr,sIclaim, 14); sPrtstr[34]='\0';    /*C4-2:�߮׸�*/
      printf("sPrtstr[%s]\n",sPrtstr);

      rfmtlong(lIclose_type,"&&&&&",sIclose_type);
      strcat(sPrtstr,sIclose_type); sPrtstr[39]='\0'; /*C5:�߰l����*/

      if (*sFlast=='1')
      {
         strcat(sPrtstr,sDgroup_yyyy);        /*C6-1:CCYY*/
         strcat(sPrtstr,sDgroup_mm);          /*C6-2:MM*/
         strcat(sPrtstr,sDgroup_dd);          /*C6-2:DD */
      }
      else
         strcat(sPrtstr,"        ");                 /*C6-1:CCYY*/

      sPrtstr[47]='\0';

      strcat(sPrtstr,COMPANY); sPrtstr[49]='\0';      /*C7-1:���q�O*/
      strcat(sPrtstr,sformat_trade(sIpolicy1 ,2 ,15));
      sPrtstr[64]='\0';                               /*C7-2:�O�渹*/

      if (strlen(rtrim(sIpolicy2)) > 0)           /* ���j�O��*/
      {
         strcpy(sObjno, sformat_trade(sIpolicy2, 2, 4));
      }
      else
      {
         strcpy(sObjno,"0001");
      }

      strcat(sPrtstr,sObjno); sPrtstr[68]='\0';       /*C8:�Ъ���*/

      if (strlen(trim(sItag))<=0)
         strcpy(sItag, "        ");

      strcat(sPrtstr,sItag); sPrtstr[76]='\0';                /*C9:�P�Ӹ�*/


      /* if (*sFstl=='1') { ��*/
      strcat(sPrtstr,sIacc_license); sPrtstr[86]='\0';/*C10-1:�r��*/
      strncpy(sIacc_birth_yy,sIacc_birth,2);          /*C10-2 �ͤ�*/
      sIacc_birth_yy[2] = '\0';
      sIacc_birth_mm[0]=sIacc_birth[2];
      sIacc_birth_mm[1]=sIacc_birth[3];
      sIacc_birth_mm[2]='\0';
      sIacc_birth_dd[0]=sIacc_birth[4];
      sIacc_birth_dd[1]=sIacc_birth[5];
      sIacc_birth_dd[2]='\0';
      strcpy(sIacc_birth_yyyy,itoa(1911+atoi(sIacc_birth_yy)));
      strncat(sPrtstr, sIacc_birth_yyyy,4);
      sPrtstr[90]='\0';
      strncat(sPrtstr,sIacc_birth_mm,2); sPrtstr[92]='\0';
      strncat(sPrtstr,sIacc_birth_dd,2);  sPrtstr[94]='\0';

      strcat(sPrtstr,sNacc_driver); sPrtstr[114]='\0';/*C10-3:�m�W*/
      strcat(sPrtstr,sFacc_sex); sPrtstr[115]='\0';   /*C10-4:�ʧO*/
      strcat(sPrtstr,sFacc_marri); sPrtstr[116]='\0'; /*C10-5:�B��*/
      strcat(sPrtstr,sFacc_nation); sPrtstr[117]='\0';/*C10-6:��O*/
      strcat(sPrtstr,sIacc_reason); sPrtstr[119]='\0'; /*C11:�X�I��]*/

      rfmtlong(0,"&&&",sQinjure_1);
      rfmtlong(0,"&&&",sQdeath_1);
      rfmtlong(0,"&&&",sQcripple_1);
      strcat(sPrtstr,sQinjure_1); sPrtstr[122]='\0';      /*C12:���*/
      strcat(sPrtstr,sQdeath_1); sPrtstr[125]='\0';       /*C12:���`*/
      strcat(sPrtstr,sQcripple_1); sPrtstr[128]='\0';     /*C12:�ݼo*/

      strncat(sPrtstr,sDaccident,4); sPrtstr[132]='\0';/*C13:�X�I����ɶ�*/
      strncat(sPrtstr,(sDaccident+5),2); sPrtstr[134]='\0';
      strncat(sPrtstr,(sDaccident+8),2); sPrtstr[136]='\0';
      strncat(sPrtstr,(sDaccident+11),2); sPrtstr[138]='\0';
      strcat(sPrtstr,"00"); sPrtstr[140]='\0';

      /* �N�{��u�a�ϥN�����v���R���N��42�u�x�����v�B�N��63�u�x�n���v�B�N��65�u�������v�C*/
      if( strcmp( sIacc_area, "42") == 0)
		strcpy( sIacc_area, "41");
      else if( strcmp( sIacc_area, "63") == 0)
		strcpy( sIacc_area, "62");
      else if( strcmp( sIacc_area, "65") == 0)
		strcpy( sIacc_area, "64");

      strcat(sPrtstr,sIacc_area); sPrtstr[142]='\0';   /*C14:�X�I�a�ϥN��*/

      if (*sFpart=='1' || *sFpart=='2' || *sFpart=='3')
         sFpart_A[0]='1';
      else
         sFpart_A[0]='2';

      strcat(sPrtstr,sFpart_A); sPrtstr[143]='\0';         /*C15:�����l�O*/

      sPrtstr[143]='\0';

           strcpy(tmp_dbname,get_car_full_db(sIpolicy));
           sprintf_s(stmt_bufb, sizeof stmt_bufb,"SELECT dpolicy FROM %s:ply_relation \
                               WHERE ipolicy = '%s' ",
                             tmp_dbname, sIpolicy );

           $PREPARE EXE_STMTb FROM $stmt_bufb;
           $EXECUTE EXE_STMTb INTO $ldpolicy;

           if ( ldpolicy < date_1000901  &&
                 strcmp( trim(sIins_type), "15") != 0 &&
                 strcmp( trim(sIins_type), "16") != 0) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
           {
               puts("ñ���<09/01/2011");
               strcat(sPrtstr, sIins_type);                     /*C144-149:�����I�إN�X*/
           }
           else
           {
               puts("ñ���>=09/01/2011");
               strcat(sPrtstr, iins_ply);                     /*C144-149:�����I�إN�X*/
           }

           sPrtstr[149]='\0';

              rfmtlong(T9A_qlia,"&&&",sQinjure);
              rfmtlong(T9A_mstl,"&&&&&&&&",sQinjure_stl);
              rfmtlong(T9B_qlia,"&&&",sQdeath);
              rfmtlong(T9B_mstl,"&&&&&&&&",sQdeath_stl);
              rfmtlong(T9C_qlia,"&&&",sQcripple);
              rfmtlong(T9C_mstl,"&&&&&&&&",sQcripple_stl);

      Tinjure  += T9A_mstl;
      Tdeath   += T9B_mstl;
      Tcripple += T9C_mstl;

              strcat(sPrtstr,sQinjure); sPrtstr[152]='\0';     /*C150-152:�����ˤH��*/
              strcat(sPrtstr,sQdeath); sPrtstr[155]='\0';      /*C153-155:��ڦ��`�H��*/
              strcat(sPrtstr,sQcripple); sPrtstr[158]='\0';    /*C156-158:��ڴݼo�H��*/
              strcat(sPrtstr, "            "); sPrtstr[170]='\0'; /*159-170:�w���l�����B */
              rfmtlong(lMins_dedu,"&&&&&&&",sMins_dedu);
              strcat(sPrtstr,sMins_dedu); sPrtstr[177]='\0';   /*C171-177:�z�ߦۭt�B*/
              rfmtlong(lMins_stl,"&&&&&&&&&&&&",sMins_stl);
              strcat(sPrtstr,sMins_stl); sPrtstr[189]='\0';    /*C178-189:��ڲz�ߪ��B*/

      prem_total += lMins_stl;

              strcat(sPrtstr,sQinjure_stl); sPrtstr[197]='\0'; /*C190-197:�����˪��B*/
              strcat(sPrtstr,sQdeath_stl); sPrtstr[205]='\0';  /*C198-205:��ڦ��`���B*/
              strcat(sPrtstr,sQcripple_stl); sPrtstr[213]='\0';/*C206-213:��ڴݼo���B*/
              rfmtlong(lMins_comp,"&&&&&&&&&&&&",sMins_comp);
              strcat(sPrtstr,sMins_comp); sPrtstr[225]='\0';   /*C214-225:�M�Ѫ��B*/
              rfmtlong(lMins_proc,"&&&&&&&",sMins_proc);
              strcat(sPrtstr,sMins_proc);                      /*C226-232:�z�߶O��*/
              sPrtstr[232]='\0';

              strcat(sPrtstr,sDgroup_yyyy);                /*233-240:�w����� */
              strcat(sPrtstr,sDgroup_mm);
              strcat(sPrtstr,sDgroup_dd);
              sPrtstr[240]='\0';
              strcat(sPrtstr,sFacc_car); sPrtstr[241]='\0';  /*241-241:�r�p�H�ϧO */
              strcat(sPrtstr,sFacc_duty); sPrtstr[242]='\0'; /*242-242:�F�d */
              strcat(sPrtstr,"                 ");           /*243-259:�O�I�Ҹ� */
              sPrtstr[259]='\0';

              strcpy(iins_type_tradevan," ");
              $SELECT iins_type_tradevan
                 INTO $iins_type_tradevan
                 FROM insurance_type
                WHERE iins_type = $sIins_type;

              strcat(sPrtstr, iins_type_tradevan); sPrtstr[261]='\0';         /* 260-261:�F�d�I�إN�� */

              fprintf(fptr,"%s\n",sPrtstr);
              cntrlrec++;

              printf("end this iclaim\n");

   }
   $CLOSE CUS6;
   $FREE CUS6;
   printf ("end_lStl_ins2 cntrlrec[%d]\n",cntrlrec);

   if (cntrlrec > 0)
   {
      $SELECT qcount
         INTO $qcount
         FROM TRADE_COUNT
        WHERE file_name = $Tmp1; if (SQLCODE == SQLNOTFOUND ) qcount=0;

      printf("Tmp1[%s] [%d] cntrlrec[%d]\n",Tmp1,qcount,cntrlrec);
      qcount += cntrlrec;

      $UPDATE TRADE_COUNT
          SET ( qcount, Tamount, Tinjure, Tcripple, Tdeath, Tastype ) =
              ( $qcount, $prem_total, $Tinjure, $Tcripple, $Tdeath, 'S' )
        WHERE file_name = $Tmp1;

      if ( sqlca.sqlerrd[2] == 0 )
      {
         printf("222:policy_day[%d]\n", close_date);

         $INSERT INTO TRADE_COUNT
            ( file_name, policy_day, qcount, Tamount, Tinjure, Tcripple, Tdeath, Tastype )
          VALUES
            ( $Tmp1, $close_date, $qcount, $prem_total, $Tinjure, $Tcripple, $Tdeath, 'S' );
      }

      printf("Tmp1[%s] [%d]\n",Tmp1,qcount);

      strcpy(prtstr,"CNTRLREC");
      rfmtlong(qcount,"&&&&&&",cntrlrec_c);
      strcat(prtstr,cntrlrec_c);
      fprintf(fptr, "%s\n", prtstr);

   }
   else if ( cntrlrec == 0 )
   {
      printf("sDappraisal_bgn[%s]\n", sDappraisal_bgn);
      rstrdate( sDappraisal_bgn , &close_date );
      
      if (strcmp(option,"Y") == 0)
      {  /* �������v�� */
         $SELECT file_name , qcount
            INTO $Tmp1, $cntrlrec
            FROM TRADE_COUNT
           WHERE file_name like 'ISBM%h';
             
         if( SQLCODE == SQLNOTFOUND )
         {
            /* �L���M�B�L�w�M */
            strcpy( close_date_c , cm_cdate_str_100( close_date ));
   
            cm_split_ymd_100(close_date_c,day_yy,day_mm,day_dd);
   
            sprintf_s(Tmp1, sizeof Tmp1,"ISBM%s_2011h",companyid);
            strcpy(iply_type,opt);
            strcpy(fcard_class, "2");
   
            sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,trim(Tmp1));
   
            printf("file0[%s]\n",file0);
   
            fptr=fopen(file0,"w");

            printf("���v:policy_day[%s]\n", cm_cdate_str_100( close_date ));
   
            $INSERT INTO TRADE_COUNT
               ( policy_day, file_name, qcount, Tamount, Tinjure, Tcripple, Tdeath, Tastype )
             VALUES
               ( $close_date, $Tmp1,0,0,0,0,0, 'S');
            printf(" ++++++++++++++++++++++++++++++++++ \n");
            strcpy(prtstr,"CNTRLREC");
   
            rfmtlong(0,"&&&&&&",cntrlrec_c);
            strcat(prtstr,cntrlrec_c);
            fprintf(fptr, "%s\n", prtstr);
   
         }
         else
         {
            /* �L�w�M�B�����M */
   
            $UPDATE TRADE_COUNT
                SET ( qcount, Tamount, Tinjure, Tcripple, Tdeath, Tastype ) =
                    ( $cntrlrec, 0, 0, 0, 0, 'S' )
              WHERE file_name = $Tmp1;
   
            strcpy( close_date_c , cm_cdate_str_100( close_date ));
   
            cm_split_ymd_100(close_date_c,day_yy,day_mm,day_dd);
            sprintf_s(Tmp1, sizeof Tmp1,"ISBM%s_2011h",companyid);
            strcpy(iply_type,opt);
            strcpy(fcard_class, "2");
   
            sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
   
            fptr=fopen(file0,"a+");
   
            strcpy(prtstr,"CNTRLREC");
            rfmtlong(cntrlrec,"&&&&&&",cntrlrec_c);
            strcat(prtstr,cntrlrec_c);
            fprintf(fptr, "%s\n", prtstr);
   
            printf("file0[%s]  prtstr[%s]\n",file0, prtstr);
         }    
      }
      else
      {
         $SELECT file_name , qcount
            INTO $Tmp1, $cntrlrec
            FROM TRADE_COUNT
           WHERE policy_day = $close_date
             AND file_name like 'ISBM%v';
             
         if( SQLCODE == SQLNOTFOUND )
         {
            /* �L���M�B�L�w�M */
            strcpy( close_date_c , cm_cdate_str_100( close_date ));
   
            cm_split_ymd_100(close_date_c,day_yy,day_mm,day_dd);
   
            sprintf_s(Tmp1, sizeof Tmp1,"ISBM%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
            strcpy(iply_type,opt);
            strcpy(fcard_class, "2");
   
            sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,trim(Tmp1));
   
            printf("file0[%s]\n",file0);
   
            fptr=fopen(file0,"w");
   
            rc = check_if_exist(iply_type,close_date,fcard_class,0);
   
            if ( rc != M_CM_OK )
               return rc;
   
            printf("333:policy_day[%d]\n", close_date);
   
            $INSERT INTO TRADE_COUNT
               ( policy_day, file_name, qcount, Tamount, Tinjure, Tcripple, Tdeath, Tastype )
             VALUES
               ( $close_date, $Tmp1,0,0,0,0,0, 'S');
   
            strcpy(prtstr,"CNTRLREC");
   
            rfmtlong(0,"&&&&&&",cntrlrec_c);
            strcat(prtstr,cntrlrec_c);
            fprintf(fptr, "%s\n", prtstr);
   
         }
         else
         {
            /* �L�w�M�B�����M */
   
            $UPDATE TRADE_COUNT
                SET ( qcount, Tamount, Tinjure, Tcripple, Tdeath, Tastype ) =
                    ( $cntrlrec, 0, 0, 0, 0, 'S' )
              WHERE file_name = $Tmp1;
   
            strcpy( close_date_c , cm_cdate_str_100( close_date ));
   
            cm_split_ymd_100(close_date_c,day_yy,day_mm,day_dd);
            sprintf_s(Tmp1, sizeof Tmp1,"ISBM%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
            strcpy(iply_type,opt);
            strcpy(fcard_class, "2");
   
            sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
   
            fptr=fopen(file0,"a+");
   
            rc = check_if_exist(iply_type,close_date,fcard_class,0);
            if ( rc != M_CM_OK )
               return rc;
   
            strcpy(prtstr,"CNTRLREC");
            rfmtlong(cntrlrec,"&&&&&&",cntrlrec_c);
            strcat(prtstr,cntrlrec_c);
            fprintf(fptr, "%s\n", prtstr);
   
            printf("file0[%s]  prtstr[%s]\n",file0, prtstr);
         }             
      }
   }

   printf("### cntrlrec=[%s]\n",cntrlrec_c);

   fclose(fptr);

/*   rtncode = rptftpinsert( userid , "car9973" , Tmp1 ); */

   $DECLARE ca997v3 CURSOR FOR
      SELECT unique file_name
        FROM TRADE_COUNT;
   $OPEN ca997v3;
   for(;;) 
   {
      $FETCH ca997v3 INTO $sfilename;

      if (SQLCODE == SQLNOTFOUND) break;
      
      rtncode = rptftpinsert( userid , "car9973" , sfilename );
      printf("rtncode[%d]\n",rtncode);
   }
   $CLOSE ca997v3;
   $FREE ca997v3;


   $SELECT policy_day, qcount, Tamount, Tinjure, Tcripple, Tdeath
         INTO $policy_day, $qcount, $Tamount, $Tinjure, $Tcripple, $Tdeath
         FROM TRADE_COUNT
        WHERE file_name = $Tmp1;

      if ( SQLCODE!=SQLNOTFOUND &&
            ( strcmp(option,"4") != 0 && strcmp(option,"5") != 0 ) &&
            (strcmp(option,"Y") != 0))
      /* �C��e�����, �Y����ca_tmp_no����ƫh����insert */
      {
         $insert into ca_trade_exam
            (iply_type,dpolicy,fcard_class,itrans_type,
             qcount,mamount,minjure,mcripple,mdeath)
          values
            ($iply_type,$policy_day,$fcard_class,0,
             $qcount,$Tamount,$Tinjure,$Tcripple,$Tdeath);
      }
      
      sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%d \n",file0,qcount);
      WRITELOG(errfpt , strlog);

   printf("errfpt[%s]\n",strlog);


   return(SUCCESS);

errexit:
   printf("car9973vol_lStl_ins:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   rc = SQLCODE;
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return rc;
}

/* -------------------------------------------------------------------------- */
long check_if_exist( iply_type, dpolicy, fcard_class, trans_type )
$char *iply_type;
$int dpolicy;
$char *fcard_class;
$int trans_type;
{

   $long trade_count=0, err_count=0, out_count=0;

   if ( strcmp(option,"4") == 0 || strcmp(option,"5") == 0)  /* �Y����ca_tmp_no����ƫh����check */
    return M_CM_OK;

   printf("iply_type[%s] dpolicy[%d]\n",iply_type,dpolicy);
   printf("fcard_class[%s] trans_type[%d]\n",fcard_class,trans_type);


   $SELECT qtradevan, qerr, qout
      INTO $trade_count, $err_count, $out_count
      FROM ca_trade_exam
     WHERE iply_type = $iply_type
       AND dpolicy = $dpolicy
       AND fcard_class = $fcard_class
       AND itrans_type = $trans_type;

   if ( SQLCODE == SQLNOTFOUND )  return M_CM_OK;

   printf("trade_count[%d] [%d] [%d]\n",trade_count,err_count,out_count);


   if ( trade_count==0 && err_count==0 && out_count==0 )
   {

       $DELETE FROM ca_trade_exam
         WHERE iply_type = $iply_type
           AND dpolicy = $dpolicy
           AND fcard_class = $fcard_class
           AND itrans_type = $trans_type;

        return M_CM_OK;

   }

   strcpy(sqlca.sqlerrm ,"�L�k���J�s�C - �b UNIQUE INDEX ��즳���Э�");

   return 239;

errexit:
    printf("check_if_exist:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    rc = SQLCODE;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return rc;

}
/* --------------���N�I�w��(�s)--------------------------------------------- */
long App_ins2()
{
   $char  sIpolicy[POLICY_NUM_1],sObjno[CA_TARGET_NUM+1];
   $char  sIpolicy1[POLICY_NUM_1], sIpolicy2[POLICY_NUM_2];

   $char  sIclaim[CLAIM_NUM],sIins_type[INSURANCE_TYPE];
   $char  iins_type_rule[INSURANCE_TYPE];
   $char  sItag[CA_TAG_NUM],sDappraisal[11];
   $char  sIacc_license[11],sIacc_birth[8],sIacc_birth_yy[4],sIacc_birth_mm[3];
   $char  sIacc_birth_c[9];
   $char  sIacc_birth_dd[3],sNacc_driver[21],sFacc_sex[2],sFacc_marri[2];
   $char  sFacc_nation[2],sIacc_reason[3],sDaccident[14],sIacc_area[3];
   $char  sFpart[2],sFpart_A[2],sFacc_car[2],sFacc_duty[2];
   $char  sIacc_birth_yyyy[5];
   $char  stmt_buf5[512];
   $char  stmt_buf8[4096];
   $long  lQlia=0,lMins_app=0;
   $long  Dappraisal=0,oldDappraisal=0;
   char  sInjure[3],sDeath[3],sCripple[3],sMins_app[13];
   char  sInjure_1[3],sDeath_1[3],sCripple_1[3];
   char  sPrtstr[1000];
   char  sPrtstr1[100];

   long  iRtnCode=0;
   int   iFetch=0,ilength=0;
   int   iFetch1=0;
   $char MIclaim[21], MIins_type[7], MIpolicy[21], MIacc_license[11], MIacc_birth[8];
   $char MNacc_driver[21], MFacc_sex[2], MFacc_marri[2], MFacc_nation[2];
   $char MIacc_reason[3], MDaccident[14], MIacc_area[3], MFpart[2];
   $char MFacc_car[2], MFacc_duty[2];
   $char fins_grp[2];
   $long MDappraisal;
   $long MQlia=0, MMins_app=0;
   $long MInj_qlia=0,MDea_qlia=0,MCri_qlia=0;
   $long lInj_qlia=0,lDea_qlia=0,lCri_qlia=0;
   $long l29_dappraisal=0;
   $long M0A_qlia=0,M0B_qlia=0,M0C_qlia=0;
   $long l0A_qlia=0,l0B_qlia=0,l0C_qlia=0;
   $long l30_dappraisal=0,tmp_cnt=0;
   $long lDbgn_u=0, lDbgn_s=0, lDend_u=0, lDend_s=0;
   $char sDbgn_s[11], sDend_s[11], facc_car[2], fsystem[2], fassured[2];
   long  year1=0,year2=0;
   $long date_1000901=0, ldpolicy=0, iCount=0;
   $char iins_type_tradevan[INSURANCE_TYPE], tmp_dbname[20], iins_ply[INSURANCE_TYPE];
   $char stmt_bufa[512], stmt_bufb[512], stmt_bufc[512], stmt_bufd[512];
   $int  aflag=0;
   $char TDapp_ori[11];
   $char chk_dpolicy[2];
   $char chk_157[2];
   $char iedr_tag[13];
   $char iedr_assured[11];
   $char iadj_assured[13];
   $char MIacc_birth_yyyy[5],MIacc_birth_mm[3],MIacc_birth_dd[3];


   $WHENEVER SQLERROR GOTO errexit;

   rstrdate( "09/01/2011", &date_1000901);

   printf ("#####lApp_ins2\n");
   
   if ( strcmp(option,"Y") == 0 )
   {
      /* �ˮ֩ҤU���_����O�_�W�L���� */
         lDbgn_u = cm_ymd_edate(datebgn);    /* �ϥΪ̿�J�_�� */
         lDend_u = cm_ymd_edate(dateend);    /* �ϥΪ̿�J�_�� */
         
         $select date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10])),
                 date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10]))
            into $lDbgn_s, $sDbgn_s
            from cu_code_data
           where itype = 'CA' and icode = '02';
        
         
         $select date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10])),
                 date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10]))  
            into $lDend_s, $sDend_s
            from cu_code_data
           where itype = 'CA' and icode = '03';
        
         printf("datebgn=[%s]lDbgn_u=[%ld]\n",datebgn,lDbgn_u);
         printf("dateend=[%s]lDend_u=[%ld]\n",dateend,lDend_u);
         printf("sDbgn_s=[%s]lDbgn_s=[%ld]\n",sDbgn_s,lDbgn_s);
         printf("sDend_s=[%s]lDend_s=[%ld]\n",sDend_s,lDend_s);
         
         if ((lDbgn_u < lDbgn_s) || (lDbgn_u > lDend_s))
         {
            sprintf_s(strlog, sizeof strlog,"���v�ɰ_�鶷���� %s ~ %s ����,�нT�{!", sDbgn_s, sDend_s);
            return 100;
         }
         
         if ((lDend_u > lDend_s) || (lDend_u < lDbgn_s))
         {
            sprintf_s(strlog, sizeof strlog,"���v�ɨ��鶷���� %s ~ %s ����,�нT�{!", sDbgn_s, sDend_s);
            return 100;
         }
      }
 
   memset(sTmt_buf,' ',sizeof(sTmt_buf));
   memset(strtmp, 0x00, sizeof(strtmp));
   /************ �]�w��l�� ************/
   sIcar_type[0] = '\0';
   sItag[0]='\0';
   sDappraisal[0]= '\0';
   sIacc_license[0]= '\0';
   sIacc_birth[0]='\0';
   sIacc_birth_yy[0]='\0';
   sIacc_birth_mm[0]='\0';
   sIacc_birth_c[0]='\0';
   sIacc_birth_dd[0]='\0';
   sNacc_driver[0]='\0';
   sFacc_sex[0]='\0';
   sFacc_marri[0]= '\0';
   sFacc_nation[0]='\0';
   sIacc_reason[0]='\0';
   sDaccident[0]='\0';
   sIacc_area[0]='\0';
   sFpart[0]= '\0';
   sFpart_A[0]= '\0';
   sFacc_car[0]='\0';
   sFacc_duty[0]='\0';
   sIacc_birth_yyyy[0]='\0';
   lQlia= lMins_app = 0;
   MInj_qlia = MDea_qlia = MCri_qlia = 0;
   l29_dappraisal = 0;
   l30_dappraisal = 0;
   MDappraisal = 0;
   cntrlrec = 0;
   chk_dpolicy[0]='\0';
   /************************************/

   $CREATE TEMP TABLE APPINS
   (
      TIclaim     char(20),
      TIins_type  char(6),
      TQlia       int,
      TMins_app   int,
      TDappraisal date,
      TIpolicy    char(20),
      TIacc_license  char(10),
      TIacc_birth    char(7),
      TNacc_driver   char(18),
      TFacc_sex    char(1),
      TFacc_marri  char(1),
      TFacc_nation char(1),
      TIacc_reason char(2),
      TDaccident   char(13),
      TIacc_area   char(2),
      TFpart      char(1),
      TFacc_car   char(1),
      TFacc_duty  char(1),
      TInj_qlia   int default 0,
      TDea_qlia   int default 0,
      TCri_qlia   int default 0,
      T_itag	   char(12),
      iins_type   char(6),
      iins_ply    char(6),
      TDapp_ori   date,
      TIacc_birth_yyyy  char(4),
      TIacc_birth_mm    char(2),
      TIacc_birth_dd    char(2)
   )WITH NO LOG;

   $CREATE TEMP TABLE tmp_policy
      ( ipolicy char(20) ) WITH NO LOG;

   $CREATE TEMP TABLE del_50_policy
     ( ipolicy char(20) ) WITH NO LOG;

   if (goption[0] == 'A' || goption[0] == 'B')
   {
       strcpy(sWhere99," ");
       $select ibranch_in
          into $ibranch_in
          from ca_clm_process
         where iclaim = $giclaim;
       if (SQLCODE == SQLNOTFOUND)
       {
           strcpy(ibranch_in,"00");
       }

       if (goption[0] == 'A')
       {
           sprintf_s(sTmt_buf, sizeof sTmt_buf," select min(dappraisal)       \
                                from %s:app_ins_type_hist  \
                               where iclaim  = ? ", get_full_dbname(ibranch_in));
       }
       else
       {
           sprintf_s(sTmt_buf, sizeof sTmt_buf," select max(dappraisal)       \
                                from %s:app_ins_type_hist  \
                               where iclaim  = ? and dappraisal < today ", get_full_dbname(ibranch_in));  
       }
 
       printf("sTmt_buf[%s]\n",sTmt_buf);

       $prepare get_min_dapp from $sTmt_buf;
       $execute get_min_dapp 
           into $min_dapp
          using $giclaim;

       strcpy(sDappraisal_bgn, min_dapp);
       strcpy(sDappraisal_end, min_dapp);
       rstrdate(sDappraisal_bgn,&dbgn_long);
       rstrdate(sDappraisal_end,&dapp_end);
       strcpy(datebgn, cm_from_infdate(min_dapp));
       strcpy(dateend, cm_from_infdate(min_dapp));
   }


   for( i= 0;i<count_db;i++)
   {
      if ( strcmp(option,"Y") == 0 )
      {
         /* �ɾ����I�z�߾��v��� */
         sprintf_s(sTmt_buf, sizeof sTmt_buf, "SELECT a.iclaim, a.iins_type, a.qlia, (a.mins_app+a.mproc_app),"
                           "       a.dappraisal, c.ipolicy, c.iacc_license,"
                           "       c.iacc_birth, c.nacc_driver, c.facc_sex, c.facc_marri,"
                           "       c.facc_nation, c.iacc_reason, c.daccident, c.iacc_area,"
                           "       c.fpart, c.facc_rel, "
                           "       decode(d.fins_grp,'1',c.fdmg_duty,c.facc_duty),b.itag,"
                           "       decode(d.iins_type_rule,'21','23',d.iins_type_rule),d.fins_grp, c.facc_car, e.fsystem, f.fassured, "
                           "       d.iins_ply, b.icar_type, a.dappraisal as TDapp_ori,"
                           "       CASE WHEN g.dpolicy < '08/01/2016' THEN 'Y' ELSE 'N' END,"
                           "       to_char(c.dacc_birth,'%%Y'),to_char(c.dacc_birth,'%%m'),to_char(c.dacc_birth,'%%d') "
                           "  FROM %s:app_ins_type a, %s:adjustment_ply b, %s:appraisal c,insurance_type d, ca_clm_process e, %s:policy f, %s:ply_relation g"
                           " WHERE a.iclaim = b.iclaim AND a.iclaim = c.iclaim "
                           "   AND c.iclaim = e.iclaim "
                           "   AND c.ipolicy = e.ipolicy " 
                           "   AND c.ipolicy = f.ipolicy "
                           "   AND c.ipolicy = g.ipolicy "  
                           "   AND a.iins_type = d.iins_type AND d.iins_ply not in ('171','172','173','174','175') "
                           "   AND date(c.daccident) BETWEEN  '%s' AND  '%s' "
         			         "   AND a.iclaim[6] <> 'W' "
         			         "   AND b.icar_type IN ('01','02','32','34') "
         			         "   AND f.ipolicy[6,7] not in ('VW','EB','TV') "
                           "ORDER BY 1,20,2,5",
                           list[i].dbname,list[i].dbname,list[i].dbname, list[i].dbname,
                           sDappraisal_bgn,sDappraisal_end);
   
         printf("�������v��:sTmt_buf[%s]\n",sTmt_buf);
      }
      else
      {
         if (itmpcnt > 0)
         {         
         sprintf_s(sWhere9, sizeof sWhere9, " UNION SELECT a.iclaim, a.iins_type, h.qlia, (h.mins_app+h.mproc_app),"
                           "       cast('%s' as date) dappraisal, c.ipolicy, c.iacc_license,"
                           "       c.iacc_birth, c.nacc_driver, c.facc_sex, c.facc_marri,"
                           "       c.facc_nation, c.iacc_reason, c.daccident, c.iacc_area,"
                           "       c.fpart, c.facc_rel, "
                           "       decode(d.fins_grp,'1',c.fdmg_duty,c.facc_duty),b.itag,"
                           "       decode(d.iins_type_rule,'21','23',d.iins_type_rule),d.fins_grp, c.facc_car, e.fsystem, f.fassured, "
                           "       d.iins_ply, b.icar_type, cast('%s' as date) as TDapp_ori," 
                           "       CASE WHEN g.dpolicy < '08/01/2016' THEN 'Y' ELSE 'N' END, "
                           "       to_char(c.dacc_birth,'%%Y'),to_char(c.dacc_birth,'%%m'),to_char(c.dacc_birth,'%%d') "
                         "  FROM %s:app_ins_type_hist a, %s:adjustment_ply b, %s:appraisal c,insurance_type d, ca_clm_process e, %s:policy f, %s:ply_relation g, %s:app_ins_type h "
                           " WHERE a.iclaim = b.iclaim AND a.iclaim = c.iclaim "
                           "   AND a.iclaim = h.iclaim AND a.iins_type = h.iins_type "
                           "   AND c.iclaim = e.iclaim "
                           "   AND c.ipolicy = e.ipolicy " 
                           "   AND c.ipolicy = f.ipolicy " 
                           "   AND c.ipolicy = g.ipolicy " 
                           "   AND a.iins_type = d.iins_type AND d.iins_ply not in ('171','172','173','174','175') "
                           "   AND ((a.dappraisal BETWEEN '%s' AND '%s') or (a.iclaim in (select iclaim from sysdb:ca_clm_upd_log where ifield in (1,2,5) and date(dcreate) between '%s' and '%s'))) "
         			         "   AND a.iclaim[6] <> 'W' "
         			         "   AND f.ipolicy[6,7] not in ('VW','EB','TV')  "
                                         "   AND not exists (select *    "
                                         "                     from t997_temp x, insurance_type z   "
                                         "                    where x.iclaim     = a.iclaim        "
                                         "                      and x.iins_type  = z.iins_type and z.iins_ply = d.iins_ply)    ",
                           sDappraisal_bgn,lastdwork,list[i].dbname,list[i].dbname,list[i].dbname, list[i].dbname, list[i].dbname, list[i].dbname,
                           lastdwork,lastdwork,lastdwork,lastdwork);

         }
         else
         {
            strcpy(sWhere9," ");
         }

         sprintf_s(sWhere99, sizeof sWhere99, " UNION SELECT a.iclaim, a.iins_type, a.qlia, (a.mins_app+a.mproc_app),"
                           "       v.dappraisal, c.ipolicy, c.iacc_license,"
                           "       c.iacc_birth, c.nacc_driver, c.facc_sex, c.facc_marri,"
                           "       c.facc_nation, c.iacc_reason, c.daccident, c.iacc_area,"
                           "       c.fpart, c.facc_rel, "
                           "       decode(d.fins_grp,'1',c.fdmg_duty,c.facc_duty),b.itag,"
                           "       decode(d.iins_type_rule,'21','23',d.iins_type_rule),d.fins_grp, c.facc_car, e.fsystem, f.fassured, "
                           "       d.iins_ply, b.icar_type, v.dappraisal as TDapp_ori,"
                           "       CASE WHEN g.dpolicy < '08/01/2016' THEN 'Y' ELSE 'N' END,"
                           "       to_char(c.dacc_birth,'%%Y'),to_char(c.dacc_birth,'%%m'),to_char(c.dacc_birth,'%%d') "
                           "  FROM %s:app_ins_type a, %s:adjustment_ply b, %s:appraisal c,insurance_type d, ca_clm_process e, %s:policy f, %s:ply_relation g, "
			   " ( select iclaim, max(date(dcreate)) as dappraisal from sysdb:ca_clm_upd_log where ifield in (1,2,5) and date(dcreate) between '%s' and '%s' group by 1 ) v "
                           " WHERE a.iclaim = b.iclaim AND a.iclaim = c.iclaim AND a.iclaim = v.iclaim "
                           "   AND c.iclaim = e.iclaim "
                           "   AND c.ipolicy = e.ipolicy " 
                           "   AND c.ipolicy = f.ipolicy " 
                           "   AND c.ipolicy = g.ipolicy " 
                           "   AND a.iins_type = d.iins_type AND d.iins_ply not in ('171','172','173','174','175') "
                           "    %s "
         			         "   AND a.iclaim[6] <> 'W' "
         			         "   AND f.ipolicy[6,7] not in ('VW','EB','TV') ",
                           list[i].dbname,list[i].dbname,list[i].dbname, list[i].dbname, list[i].dbname,
                           sDappraisal_bgn,sDappraisal_end, sWhere);

         if (goption[0] == 'A' || goption[0] == 'B')
         {
            strcpy(sWhere99," ");
         }
	 
         /* car9901111 ���T���N�I���e������� */
         /* 1000413004_C1 �����I�]�n�e���T�@mark by sylvia 100.05.02 */
         sprintf_s(sTmt_buf, sizeof sTmt_buf, "SELECT a.iclaim, a.iins_type, h.qlia, (h.mins_app+h.mproc_app),"
                           "       a.dappraisal, c.ipolicy, c.iacc_license,"
                           "       c.iacc_birth, c.nacc_driver, c.facc_sex, c.facc_marri,"
                           "       c.facc_nation, c.iacc_reason, c.daccident, c.iacc_area,"
                           "       c.fpart, c.facc_rel, "
                           "       decode(d.fins_grp,'1',c.fdmg_duty,c.facc_duty),b.itag,"
                           "       decode(d.iins_type_rule,'21','23',d.iins_type_rule),d.fins_grp, c.facc_car, e.fsystem, f.fassured, "
                           "       d.iins_ply, b.icar_type, a.dappraisal as TDapp_ori,"
                           "       CASE WHEN g.dpolicy < '08/01/2016' THEN 'Y' ELSE 'N' END,"
                           "       to_char(c.dacc_birth,'%%Y'),to_char(c.dacc_birth,'%%m'),to_char(c.dacc_birth,'%%d') "
                         "  FROM %s:app_ins_type_hist a, %s:adjustment_ply b, %s:appraisal c,insurance_type d, ca_clm_process e, %s:policy f, %s:ply_relation g, %s:app_ins_type h "
                           " WHERE a.iclaim = b.iclaim AND a.iclaim = c.iclaim "
                           "   AND a.iclaim = h.iclaim AND a.iins_type = h.iins_type "
                           "   AND c.iclaim = e.iclaim "
                           "   AND c.ipolicy = e.ipolicy " 
                           "   AND c.ipolicy = f.ipolicy " 
                           "   AND c.ipolicy = g.ipolicy " 
                           "   AND a.iins_type = d.iins_type AND d.iins_ply not in ('171','172','173','174','175') "
                           "   AND a.dappraisal BETWEEN  '%s' AND  '%s' %s "
         			         "   AND a.iclaim[6] <> 'W' "
         			         "   AND f.ipolicy[6,7] not in ('VW','EB','TV')  %s %s "
                           "ORDER BY 1,20,2,5",
                           list[i].dbname,list[i].dbname,list[i].dbname, list[i].dbname, list[i].dbname, list[i].dbname,
                           sDappraisal_bgn,sDappraisal_end, sWhere, sWhere9, sWhere99);
   
         printf("���`��:sTmt_buf[%s]\n",sTmt_buf);
      }
      $PREPARE STMT5 FROM $sTmt_buf;
      $DECLARE CUR_APP2 CURSOR FOR STMT5;

      $OPEN CUR_APP2;
      while (1)
      {
         $FETCH CUR_APP2 INTO $MIclaim, $MIins_type, $MQlia, $MMins_app, $MDappraisal,
                             $MIpolicy, $MIacc_license, $MIacc_birth, $MNacc_driver,
                             $MFacc_sex,$MFacc_marri, $MFacc_nation, $MIacc_reason,
                             $MDaccident, $MIacc_area, $MFpart, $MFacc_car, $MFacc_duty, $sItag,
                             $iins_type_rule, $fins_grp, $facc_car, $fsystem, $fassured, $iins_ply, $sIcar_type, 
                             $TDapp_ori, $chk_dpolicy,
                             $MIacc_birth_yyyy,$MIacc_birth_mm,$MIacc_birth_dd;

         if( SQLCODE == SQLNOTFOUND ) break;
         
         printf("TDapp_ori[%s]\n",TDapp_ori);

         /* 1061102009_C1 �ק�ǰe���T27���ؾ��񨮵P�W�h
         if (strcmp(sIcar_type,"27") == 0 && strcmp(chk_dpolicy) == "Y")
            strcpy(sItag, " ");  */      /* ����27,���P���X�M�� modify by sylvia 101.02.24 (1001005007_C1) */

         sprintf_s(stmt_buf8, sizeof stmt_buf8," select iassured               \
                               from %s:adjustment_ply      \
                              where iclaim = '%s' ",list[i].dbname, MIclaim);

         $prepare get_adj_assured from $stmt_buf8;
         $execute get_adj_assured
             into $iadj_assured;
         if (SQLCODE == SQLNOTFOUND)
         { 
             strcpy(iadj_assured,"");
         } 
         strcpy(iadj_assured,trim(iadj_assured));

         sprintf_s(stmt_buf8, sizeof stmt_buf8," select first 1 nvl(b.itag,' ') as itag, nvl(b.iassured,' ') as iassured  \
                               from %s:edr_relation a, %s:endorsement b    \
                              where a.iendorse      =  b.iendorse          \
                                and a.dedr_close    is not null            \
                                and a.ipolicy       =  '%s'                \
                                and a.dedr_begin   <=  today               \
                              order by dedr_begin desc, dedr_close desc, dcreate desc ", list[i].dbname, list[i].dbname, MIpolicy);

         $prepare get_itag_assured from $stmt_buf8;                
         $execute get_itag_assured
             into $iedr_tag, $iedr_assured; 
         if (SQLCODE != SQLNOTFOUND)
         {
            strcpy(iedr_tag,trim(iedr_tag));
            strcpy(iedr_assured,trim(iedr_assured));
            strcpy(sItag,trim(sItag));
            if (strcmp(iedr_tag,sItag)!=0)
            {
               /*  �p�G���L��A�B���P���X���P�A�����e�̷s�����P  */
               if (strcmp(iedr_assured, iadj_assured)!=0)
               {
                  strcpy(sItag,iedr_tag);  
               }            
               else
               {
                  strcpy(infdaccident, get_inf_date(MDaccident));
                  printf("infdaccident[%s]\n",infdaccident);
                  
	          sprintf_s(stmt_buf8, sizeof stmt_buf8," select first 1 nvl(b.itag,' ') as itag, nvl(b.iassured,' ') as iassured  \
	                                from %s:edr_relation a, %s:endorsement b    \
	                               where a.iendorse      =  b.iendorse          \
	                                 and a.dedr_close    is not null            \
	                                 and a.ipolicy       =  '%s'                \
	                                 and a.dedr_begin   <=  '%s'                \
	                               order by dedr_begin desc, dedr_close desc, dcreate desc ", list[i].dbname, list[i].dbname, MIpolicy, infdaccident );
	                               
	          printf("stmt_buf8[%s]\n",stmt_buf8);
	          $prepare get_itag_assured2 from $stmt_buf8;                
	          $execute get_itag_assured2
	              into $iedr_tag, $iedr_assured;     
	          if (SQLCODE != SQLNOTFOUND)	          
	          {
	             strcpy(iedr_tag,trim(iedr_tag));
	             if (strcmp(iedr_tag,sItag)!=0)
	             {
	                 strcpy(sItag,iedr_tag);
	             }
	          }              
               }
            }
         }

         /*�r�p�H�ϧO*/
         switch (MFacc_car[0])
         {
            case '1':  strcpy(MFacc_car,"1");  break;
            case 'A':  strcpy(MFacc_car,"2");  break;
            case 'B':  strcpy(MFacc_car,"2");  break;
            case 'C':  strcpy(MFacc_car,"2");  break;
            case 'D':  strcpy(MFacc_car,"2");  break;
            case 'E':  strcpy(MFacc_car,"4");  break;
            case 'F':  strcpy(MFacc_car,"4");  break;
            case 'G':  strcpy(MFacc_car,"4");  break;
            case '4':  strcpy(MFacc_car,"4");  break;
            case '5':  strcpy(MFacc_car,"4");  break;
            default :  strcpy(MFacc_car,"1");  break;
         }
         
         /*****************************************************
         if( fsystem[0] == 'N')
             strcpy( MFacc_car, facc_car);
         else
         {
			switch (MFacc_car[0])
			{
				case '1':
					break;
				case '2':
					break;
				case '3':
					MFacc_car[0] = '4';
					break;
				case '4':
					MFacc_car[0] = '4';
					break;
				case '5':
                                        if( fassured[0] == '1' || fassured[0] == '3' || fassured[0] == '5')
					    MFacc_car[0] = '2';
                                        else
					    MFacc_car[0] = '4';
					break;
				default :
					MFacc_car[0] = '2';
					break;
			}
         }
         ******************************************************/

         MInj_qlia = MDea_qlia = MCri_qlia = 0;

         strcpy(MIins_type,rtrim(MIins_type));
         ilength= strlen(MIins_type)-1;

         strcpy(tmp_dbname,get_car_full_db(MIpolicy));
         sprintf_s(stmt_bufb, sizeof stmt_bufb,"SELECT dpolicy FROM %s:ply_relation \
                             WHERE ipolicy = '%s' ",
                           tmp_dbname, MIpolicy );

         $PREPARE EXE_STMTb FROM $stmt_bufb;
         $EXECUTE EXE_STMTb INTO $ldpolicy;

         /**  �w���d���I�u���Ӥ��H�� **/
         if (fins_grp[0]=='2')
         {
            
            if (strncmp(MIins_type[ilength],"A",1) == 0 ||
                  strcmp(MIins_type,INJURE)==0)
               MInj_qlia = MQlia;

            if (strncmp(MIins_type[ilength],"B",1) == 0 ||
                  strcmp(MIins_type,DEATH)==0)
               MDea_qlia = MQlia;

            if (strncmp(MIins_type[ilength],"C",1) == 0 ||
                  strcmp(MIins_type,CRIPPLE)==0)
               MCri_qlia = MQlia;

            if ( ldpolicy < date_1000901 && 
                 strcmp( trim(iins_type_rule), "15") != 0 &&
                 strcmp( trim(iins_type_rule), "16") != 0 ) /* ñ���< 10/20/2010�A�ǰeinsurance_type.iins_type_rule */
                $UPDATE APPINS
                    SET (TMins_app,TDappraisal,
                         TInj_qlia,TDea_qlia,TCri_qlia)
                      = (TMins_app+$MMins_app,$MDappraisal,
                         TInj_qlia+$MInj_qlia,TDea_qlia+$MDea_qlia,
                         TCri_qlia+$MCri_qlia)
                  WHERE TIclaim    = $MIclaim
                    AND TIins_type = $iins_type_rule;
            else
            {
                $UPDATE APPINS
                    SET (TMins_app,TDappraisal,
                         TInj_qlia,TDea_qlia,TCri_qlia)
                      = (TMins_app+$MMins_app,$MDappraisal,
                         TInj_qlia+$MInj_qlia,TDea_qlia+$MDea_qlia,
                         TCri_qlia+$MCri_qlia)
                  WHERE TIclaim    = $MIclaim
                    AND iins_ply = $iins_ply;
                strcpy( iins_type_rule, trim(iins_ply));
            }

            if (sqlca.sqlerrd[2] == 0)
            {

               $INSERT INTO APPINS ( TIclaim, TIins_type, TQlia, TMins_app, TDappraisal,
                                     TIpolicy,TIacc_license, TIacc_birth, TNacc_driver,
                                     TFacc_sex, TFacc_marri, TFacc_nation, TIacc_reason,
                                     TDaccident, TIacc_area, TFpart, TFacc_car, TFacc_duty,
                                         TInj_qlia,TDea_qlia,TCri_qlia,T_itag, iins_type, iins_ply, TDapp_ori,
                                         TIacc_birth_yyyy,TIacc_birth_mm,TIacc_birth_dd)
                VALUES ( $MIclaim, $iins_type_rule, $MQlia, $MMins_app, $MDappraisal,
                         $MIpolicy, $MIacc_license, $MIacc_birth, $MNacc_driver,
                         $MFacc_sex,$MFacc_marri, $MFacc_nation, $MIacc_reason,
                         $MDaccident, $MIacc_area, $MFpart, $MFacc_car, $MFacc_duty,
                         $MInj_qlia,$MDea_qlia,$MCri_qlia,$sItag, $MIins_type, $iins_ply, $TDapp_ori,
                         $MIacc_birth_yyyy,$MIacc_birth_mm,$MIacc_birth_dd);
            }
            
         }
         else
         {
            
            if ( ldpolicy < date_1000901 && 
                 strcmp( trim(iins_type_rule), "15") != 0 &&
                 strcmp( trim(iins_type_rule), "16") != 0 ) /* ñ���< 10/20/2010�A�ǰeinsurance_type.iins_type_rule */
                $UPDATE APPINS
                    SET (TMins_app,TDappraisal)
                      = (TMins_app+$MMins_app,$MDappraisal)
                  WHERE TIclaim    = $MIclaim
                    AND TIins_type = $iins_type_rule;
            else
            {
               
                $UPDATE APPINS
                    SET (TMins_app,TDappraisal)
                      = (TMins_app+$MMins_app,$MDappraisal)
                  WHERE TIclaim    = $MIclaim
                    AND iins_ply = $iins_ply;
                strcpy( iins_type_rule, trim(iins_ply));
            }

            if (sqlca.sqlerrd[2] == 0)
            {
               
               $INSERT INTO APPINS ( TIclaim, TIins_type, TQlia, TMins_app, TDappraisal,
                                     TIpolicy,TIacc_license, TIacc_birth, TNacc_driver,
                                     TFacc_sex, TFacc_marri, TFacc_nation, TIacc_reason,
                                     TDaccident, TIacc_area, TFpart, TFacc_car, TFacc_duty,
                                     TInj_qlia,TDea_qlia,TCri_qlia,T_itag, iins_type, iins_ply, TDapp_ori,
                                     TIacc_birth_yyyy,TIacc_birth_mm,TIacc_birth_dd)
                VALUES ( $MIclaim, $iins_type_rule, $MQlia, $MMins_app, $MDappraisal,
                         $MIpolicy, $MIacc_license, $MIacc_birth, $MNacc_driver,
                         $MFacc_sex,$MFacc_marri, $MFacc_nation, $MIacc_reason,
                         $MDaccident, $MIacc_area, $MFpart, $MFacc_car, $MFacc_duty,
                         $MInj_qlia,$MDea_qlia,$MCri_qlia,$sItag, $MIins_type, $iins_ply, $TDapp_ori,
                         $MIacc_birth_yyyy,$MIacc_birth_mm,$MIacc_birth_dd);
            }
            
         }

         /* �N���N�O���J�Ȧstable�� */
         $INSERT INTO tmp_policy (ipolicy) VALUES ($MIpolicy);
      } /* end of while */
      $CLOSE CUR_APP2;
      $FREE  CUR_APP2;

      /* �P�_�Y�O����(01,02,32,34)�B���O(01,05,09,31,32,86,110,113,114)���@�I��,���e���T */
      if ( strcmp(option,"Y") == 0 )
      {
         sprintf_s(stmt_buf5, sizeof stmt_buf5,"insert into del_50_policy "
                           "select ipolicy from %s:ply_relation a "
                           " where ipolicy in (select ipolicy from tmp_policy) "
                           "   and icar_type in ('01','02','32','34') "
                           "   and ipolicy not in (select unique ipolicy from %s:ply_ins_type "
                           "                        where ipolicy = a.ipolicy "
                           "                          and iins_type in ('01','05','09','31','32','86','110','113','114','149','157','158','159','201','205','209','231','232','249')) ",
      	                  list[i].dbname,list[i].dbname);
         printf("���� stmt2[%s]\n",stmt_buf5);

         $PREPARE cur_tmp1 FROM  $stmt_buf5;
         $EXECUTE cur_tmp1;
      }
      else
      {
         /* car9901111 �P�_�Y�O��l�O��ȩӫO50�I�خ�,�h�ӫO�椣�e���T */
         /* �N�ŦX��ӫO50�O���Jtemp table, �ñqTABLE CAR9971�R�� */
         sprintf_s(stmt_buf5, sizeof stmt_buf5,"insert into del_50_policy "
      	                  "select ipolicy from %s:ori_ins_type a "
      	                  "where ipolicy in (select ipolicy from tmp_policy) "
      	                  "  and iins_type = '50' "
                           "  and not exists (select 1 from %s:ori_ins_type b where a.ipolicy = b.ipolicy "
                           "  and a.iins_type <> b.iins_type)",list[i].dbname,list[i].dbname);
         printf("stmt2[%s]\n",stmt_buf5);
   
         $PREPARE cur_tmp1 FROM  $stmt_buf5;
         $EXECUTE cur_tmp1;
      
         sprintf_s(stmt_buf5, sizeof stmt_buf5,"insert into del_50_policy "
                           "select ipolicy from %s:ori_ply_relation a "
                           " where ipolicy in (select ipolicy from tmp_policy) "
                           "   and icar_type in ('01','02','32','34') "
                           "   and ipolicy not in (select unique ipolicy from %s:ori_ins_type "
                           "                        where ipolicy = a.ipolicy "
                           "                          and iins_type in ('01','05','09','31','32','86','110','113','114','149','157','158','159','201','205','209','231','232','249')) ",
      	                  list[i].dbname,list[i].dbname);
         
         printf("���� stmt2[%s]\n",stmt_buf5);

         $PREPARE cur_tmp1 FROM  $stmt_buf5;
         $EXECUTE cur_tmp1;      	                  
      }
      
      $SELECT count(*) INTO $tmp_cnt FROM APPINS;
      printf("delete before APPINS count = [%d]\n",tmp_cnt);

      $DELETE FROM APPINS WHERE Tipolicy in (select ipolicy from del_50_policy);

      $SELECT count(*) INTO $tmp_cnt FROM APPINS;
      printf("delete after APPINS count = [%d]\n",tmp_cnt);

      $DELETE FROM del_50_policy WHERE 1=1;
      $DELETE FROM tmp_policy WHERE 1=1;

   } /* end of select db */


   iFetch  = True;
   iFetch1 = True; 

   lInj_qlia = lDea_qlia = lCri_qlia = 0;
   $DECLARE CUS42 CURSOR for
      SELECT *
        INTO $sIclaim, $sIins_type, $lQlia, $lMins_app, $sDappraisal,
             $sIpolicy, $sIacc_license, $sIacc_birth,  $sNacc_driver,
             $sFacc_sex,$sFacc_marri,   $sFacc_nation, $sIacc_reason,
             $sDaccident, $sIacc_area, $sFpart, $sFacc_car, $sFacc_duty,
             $lInj_qlia,$lDea_qlia,$lCri_qlia,$sItag, $MIins_type, $iins_ply, $TDapp_ori,
             $sIacc_birth_yyyy,$sIacc_birth_mm,$sIacc_birth_dd
        FROM APPINS
       ORDER BY TDappraisal,TIclaim,TIins_type;

   $OPEN CUS42;
   while (1)
   {
      memset(sPrtstr,' ',sizeof(sPrtstr));

      $FETCH CUS42;

      if (SQLCODE == SQLNOTFOUND) break;

      printf("TDapp_ori[%s\n",TDapp_ori);

      printf("sDappraisal[%s]\n",sDappraisal);

      rstrdate( sDappraisal , &Dappraisal );

      if (risnull(2,&lQlia)==1) lQlia=0;
      if (risnull(2,&lMins_app)==1) lMins_app=0;

      iRtnCode = split_policy(sIpolicy, sIpolicy1, sIpolicy2);
      if (iRtnCode != M_CM_OK) break;

      company_flag=sIpolicy1[7];

      strcpy(COMPANY,companyid);
      strcpy(COMPANY_F,companyid);

      if(strcmp( companyid,"17")==0)
      {
         if(company_flag > 65 )
         {
            $select ipolicy_a
               into $sIpolicy1
               from conv_ipolicy
              where ipolicy_n = $sIpolicy1;

            strcpy(COMPANY,"16");
         }

         iclaim_flag=sIclaim[6];

         if(iclaim_flag > 65 )
         {
            $select distinct iclaim_a
               into $sIclaim
               from conv_iclaim
              where iclaim_n = $sIclaim;

            strcpy(COMPANY_F,"16");
         }
      }
      
      if (iFetch1 && dapp_end == Dappraisal)
      {
         iFetch1 = FALSE;
         strcpy(sDappraisal_c1 , cm_cdate_str_100( Dappraisal ));
         cm_split_ymd_100(sDappraisal_c1,day_yy1,day_mm1,day_dd1);

         sprintf_s(Tmp2, sizeof Tmp2,"insISBM%s_%s%s%sv",companyid,day_yy1,day_mm1,day_dd1);

         sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp2);

         printf("file0[%s] Tmp1[%s]\n",file0,Tmp2);

         if (strcmp(option,"2") == 0)
            fptr1=fopen(file0,"w");
      }

      if(iFetch)
      {
         oldDappraisal = Dappraisal;
         iFetch = FALSE;

         if (strcmp(option,"4")==0 || strcmp(option,"5")==0)
         {
            cm_split_ymd_100(datebgn,day_yy,day_mm,day_dd);
         }
         else
         {
            strcpy( sDappraisal_c , cm_cdate_str_100( Dappraisal ));
            cm_split_ymd_100(sDappraisal_c,day_yy,day_mm,day_dd);
         }

         printf("sDappraisal_c [%s]\b",sDappraisal_c);

         if (strcmp(option,"Y")==0)
         {
            /* ���v�ɥH�~�׬��ɦW�����u���ͤ@���ɮ� */
            sprintf_s(Tmp1, sizeof Tmp1,"ISBM%s_2011h",companyid);
         }
         else
         { 
            sprintf_s(Tmp1, sizeof Tmp1,"ISBM%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
            
            if (goption[0] == 'A' || goption[0] == 'B')
            {
                strcat(Tmp1,"_");
                strcat(Tmp1,hhminsec);
            }
         }
         strcpy(iply_type,opt);
         strcpy(fcard_class, "2");

         sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);

         printf("file0[%s] Tmp1[%s]\n",file0,Tmp1);
         fptr=fopen(file0,"w");

         if (strcmp(option,"4")!=0 && strcmp(option,"5")!=0)
         {  
            if (strcmp(option,"Y") != 0)
            {
               rc = check_if_exist(iply_type,Dappraisal,fcard_class,0);
               if ( rc != M_CM_OK )
                  return rc;
            }
         }
      }

      if ( oldDappraisal != Dappraisal ) /* �����ثefile , open a new file*/
      {
         if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0) 
         { 
            if (strcmp(option,"Y") != 0)
            {
                /* ���e�έ簣���e&���v�ɤ����̤�������ɮ� */
               $INSERT INTO TRADE_COUNT
                  ( file_name, policy_day, qcount, Tastype )
                VALUES
                  ( $Tmp1, $oldDappraisal, $cntrlrec, 'A' );
   
               fclose(fptr);
   
               strcpy( sDappraisal_c , cm_cdate_str_100( Dappraisal ));
   
               cm_split_ymd_100(sDappraisal_c,day_yy,day_mm,day_dd);
   
               sprintf_s(Tmp1, sizeof Tmp1,"ISBM%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
               strcpy(iply_type,opt);
               strcpy(fcard_class, "2");
   
               sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
   
               printf("file0[%s] Tmp1[%s]\n",file0,Tmp1);
               fptr=fopen(file0,"w");
   
               rc = check_if_exist(iply_type,Dappraisal,fcard_class,0);
               if ( rc != M_CM_OK )
                  return rc;
   
               cntrlrec = 0;
            }
         }
      }

      oldDappraisal = Dappraisal;

      strcpy(tmp_dbname,get_car_full_db(sIpolicy));

      sprintf_s(stmt_bufd, sizeof stmt_bufd,"SELECT count(*) FROM %s:app_ins_type_hist \
                          WHERE iclaim = '%s' \
                            AND iins_type in (select iins_type from insurance_type where iins_ply = '%s') \
                            AND dappraisal < '%s' ",
                        tmp_dbname, sIclaim, iins_ply, TDapp_ori );
      printf("stmt_bufd[%s]\n",stmt_bufd);

      $PREPARE EXE_STMTd FROM $stmt_bufd;
      $EXECUTE EXE_STMTd INTO $iCount;
      
      /***   Start  Writing     ***/
      /***   1 - 11   iclaim    ***/
      strcpy(sPrtstr1, rtrim(sIclaim));
      /***   12 " "             ***/
      strcat(sPrtstr1," ");
      /***   13 - 15  iins_type ***/
      strcat(sPrtstr1, rtrim(MIins_type));
      /*if (strlen(rtrim(MIins_type)) == 2)
      {
         strcat(sPrtstr1," ");
      }*/
      
      if (strcmp(option,"2") == 0)
         fprintf(fptr1,"%s\n",sPrtstr1);

      if( iCount == 0)
      {   strcpy(sPrtstr, sformat_trade("9",4,1));}          /*C1-1:���ʧO 9:original */
      else
      {   strcpy(sPrtstr, sformat_trade("5", 4, 1));}        /*C1-1:���ʧO 5:replace */

      if (goption[0] == 'A') strcpy(sPrtstr, sformat_trade("9",4,1));
      if (goption[0] == 'B') strcpy(sPrtstr, sformat_trade("5", 4, 1));

      strcat(sPrtstr, sformat_trade("1", 4, 1));             /*C2-2:�w��*/
      
      
      /* strcat(sPrtstr,COMPANY_F); sPrtstr[4]='\0'; */      /*C3-1:���q�O*/
      /* strncat(sPrtstr,sIclaim,14); sPrtstr[18]='\0'; */ /*C3-2:�߮ר��z��*/
      strcpy(strtmp, COMPANY_F);
      strncat(strtmp,sIclaim,14); strtmp[16]='\0'; 
      strcat(sPrtstr, sformat_trade(strtmp, 4, 16));         /*C3-18:�߮ר��z��*/
      
      /* strcat(sPrtstr,COMPANY_F); sPrtstr[20]='\0'; */     /*C4-1:���q�O*/
      /* strncat(sPrtstr,sIclaim,14); sPrtstr[34]='\0'; */ /*C4-2:�߮׸�*/
      strcat(sPrtstr, sformat_trade(strtmp, 4, 16));         /*C19-34:�߮׸��X*/
      
      strcat(sPrtstr, sformat_trade("     ", 4, 5));         /*C35-39 ����     */
      strcat(sPrtstr, sformat_trade("        ", 4, 8));      /*C40-47 ��� */
      
      /* strcat(sPrtstr,COMPANY); sPrtstr[49]='\0'; */ /*C7-1:���q�O*/
      /* strcat(sPrtstr,sformat_trade(sIpolicy1,2 ,15)); 
      sPrtstr[64]='\0';                               */ /*C7-2:�O�渹*/
      strcpy(strtmp, COMPANY_F);
      strcat(strtmp,sformat_trade(sIpolicy1,2 ,15)); 
      strcat(sPrtstr, sformat_trade(strtmp, 4, 17));         /*C48-64:�O�渹*/
      

      if (strlen(rtrim(sIpolicy2))>0)                 /* ���j�O��*/
      {
         strcpy(sObjno, sformat_trade(sIpolicy2, 2, 4));
      }
      else
      {
         strcpy(sObjno,"0001");
      }
      strcat(sPrtstr, sformat_trade(sObjno, 4, 4));           /*C65-68:�Ъ���*/

      
      if (strlen(trim(sItag))<=0)
         strcpy(sItag, "        ");
         
      strcat(sPrtstr, sformat_trade(sItag, 4, 12));           /*C69-76:�P�Ӹ�*/
      
      strcat(sPrtstr, sformat_trade(sIacc_license, 4, 10));   /*C77-86:�r��*/

      /*strncpy(sIacc_birth_yy,sIacc_birth,3);*/                  /*C10-2 �ͤ�*/
      /*sIacc_birth_yy[2] = '\0';
      sIacc_birth_mm[0]= sIacc_birth[2];
      sIacc_birth_mm[1]= sIacc_birth[3];
      sIacc_birth_mm[2]='\0';

      sIacc_birth_dd[0]= sIacc_birth[4];
      sIacc_birth_dd[1]= sIacc_birth[5];
      sIacc_birth_dd[2]='\0';

      strcpy(sIacc_birth_yyyy,itoa(1911+atoi(sIacc_birth_yy)));*/
      strcpy(strtmp,sIacc_birth_yyyy);
      strcat(strtmp,sIacc_birth_mm);
      strcat(strtmp,sIacc_birth_dd);
      strcat(sPrtstr, sformat_trade(strtmp, 4, 8));           /*C87-94:�ͤ�*/ 

      strcat(sPrtstr, sformat_trade(sNacc_driver, 4, 20));    /*C95-114:�m�W*/
      strcat(sPrtstr, sformat_trade(sFacc_sex, 4, 1));        /*C115-115:�ʧO*/
      strcat(sPrtstr, sformat_trade(sFacc_marri, 4, 1));      /*C116-116:�B��*/
      strcat(sPrtstr, sformat_trade(sFacc_nation, 4, 1));     /*C117-117:��O*/
      strcat(sPrtstr, sformat_trade(sIacc_reason, 4, 2));     /*C118-119:�X�I��]*/

      /* rfmtlong(lInj_qlia,"&&&",sInjure); */
      sprintf_s(sInjure, sizeof sInjure, "%ld", lInj_qlia);
      /* rfmtlong(lDea_qlia,"&&&",sDeath); */
      sprintf_s(sDeath, sizeof sDeath, "%ld", lDea_qlia);
      /* rfmtlong(lCri_qlia,"&&&",sCripple); */
      sprintf_s(sCripple, sizeof sCripple, "%ld", lCri_qlia);
      
      strcat(sPrtstr, sformat_trade(sInjure, 4, 3));          /*C120-122���*/
      strcat(sPrtstr, sformat_trade(sDeath, 4, 3));           /*C123-125���`*/
      strcat(sPrtstr, sformat_trade(sCripple, 4, 3));         /*C126-128�ݼo*/

      memset(strtmp, 0x00, sizeof(strtmp));
      /* strncat(sPrtstr,sDaccident,4); sPrtstr[132]='\0'; */      /*CCYY*/
      strncpy(strtmp, sDaccident, 4);
      strtmp[4] = '\0';
      /* strncat(sPrtstr,(sDaccident+5),2); sPrtstr[134]='\0';*/   /*MM*/
      strncat(strtmp, (sDaccident+5),2);
      strtmp[6] = '\0';
      /* strncat(sPrtstr,(sDaccident+8),2); sPrtstr[136]='\0'; */  /*DD*/
      strncat(strtmp, (sDaccident+8),2);
      strtmp[8] = '\0';
      /* strncat(sPrtstr,(sDaccident+11),2); sPrtstr[138]='\0'; */ /*HH*/
      strncat(strtmp, (sDaccident+11),2);
      strtmp[10] = '\0';
      strcat(strtmp,"00");
      strcat(sPrtstr, sformat_trade(strtmp, 4, 12));           /*C129-140�X�I����ɶ� */

      /* �N�{}��u�a�ϥN�����v���R���N��42�u�x�����v�B�N��63�u�x�n���v�B�N��65�u�������v�C*/
      if( strcmp( sIacc_area, "42") == 0)
        	strcpy( sIacc_area, "41");
      else if( strcmp( sIacc_area, "63") == 0)
		strcpy( sIacc_area, "62");
      else if( strcmp( sIacc_area, "65") == 0)
		strcpy( sIacc_area, "64");

      strcat(sPrtstr, sformat_trade(sIacc_area, 4, 2));        /*C141-142*/
      
      printf("sFpart[%s]\n", sFpart);
      if (*sFpart=='1' || *sFpart=='2' || *sFpart=='3')
         sFpart_A[0]='1';
      else
         sFpart_A[0]='2';

      strcat(sPrtstr, sformat_trade(sFpart_A, 4, 1));          /*C143-143*/

      sprintf_s(stmt_bufa, sizeof stmt_bufa,"SELECT dpolicy,case when ipolicy[6,7] = 'V7' then 'Y' else 'N' end FROM %s:ply_relation \
                          WHERE ipolicy = '%s' ",
                        tmp_dbname, sIpolicy );

      $PREPARE EXE_STMTa FROM $stmt_bufa;
      $EXECUTE EXE_STMTa INTO $ldpolicy,$chk_157;
      
             if ( ldpolicy < date_1000901 &&
                 strcmp( trim( sIins_type), "15") != 0 &&
                 strcmp( trim( sIins_type), "16") != 0) /* ñ���< 10/20/2010�A�ǰeinsurance_type.iins_type_rule */
             {
                 puts("ñ���<10/20/2010");
                 strcat(sPrtstr, sformat_trade(sIins_type, 4, 6));  /*C144-149:�����I�إN�X*/
             }
             else
             {
                 puts("ñ���>=10/20/2010");
                 strcat(sPrtstr, sformat_trade(iins_ply, 4, 6));    /*C144-149:�����I�إN�X*/
             }

             /* rfmtlong(0,"&&&",sInjure_1); */
             strcpy(sInjure_1, "0");
             /* rfmtlong(0,"&&&",sDeath_1); */
             strcpy(sDeath_1, "0");
             /* rfmtlong(0,"&&&",sCripple_1); */
             strcpy(sCripple_1, "0");
             strcat(sPrtstr, sformat_trade(sInjure_1, 4, 3)); /*150-152:���*/
             strcat(sPrtstr, sformat_trade(sDeath_1, 4, 3));  /*153-155:���`*/
             strcat(sPrtstr, sformat_trade(sCripple_1, 4, 3));/*156-158:�ݼo*/

             /* rfmtlong(lMins_app,"&&&&&&&&&&&&",sMins_app); */
             sprintf_s(sMins_app, sizeof sMins_app, "%ld", lMins_app);
             strcat(sPrtstr, sformat_trade(sMins_app, 4, 12));  /*159-170:�w���l�����B */
             
             strcat(sPrtstr, sformat_trade("       ", 4, 12));  /*171-177:�z�ߦۭt�B */

             strcat(sPrtstr, sformat_trade("            ", 4, 12)); /*178-189:��ڲz�ߪ��B���l�v���B */
             
             strcat(sPrtstr, sformat_trade("        ", 4, 12));  /*190-197:��˲z�ߪ��B */
             
             strcat(sPrtstr, sformat_trade("        ", 4, 12));  /*198-205:���`�z�ߪ��B */
             
             strcat(sPrtstr, sformat_trade("        ", 4, 12));  /*206-213:�ݼo�z�ߪ��B */
             
             strcat(sPrtstr, sformat_trade("            ", 4, 12));  /*214-225:�M�Ѫ��B */
             
             strcat(sPrtstr, sformat_trade("       ", 4, 12));   /*226-232:�z�߶O�� */

             /* strncat(sPrtstr,(sDappraisal+6),4); sPrtstr[236]='\0';*//*233-240:�w����� */
             memset(strtmp, 0x00, sizeof(strtmp));
             strncpy(strtmp, (sDappraisal+6),4);
             strtmp[4] = '\0';
             
             /*strncat(sPrtstr,sDappraisal,2); sPrtstr[238]='\0'; */
             strncat(strtmp, sDappraisal, 2);
             strtmp[6] = '\0';
             
             /* strncat(sPrtstr,(sDappraisal+3),2); sPrtstr[240]='\0'; */
             strncat(strtmp, (sDappraisal+3), 2);
             strtmp[8] = '\0';
             strcat(sPrtstr, sformat_trade(strtmp, 4, 8));   /*C233-240:�w����� */

			 if (strncmp(chk_157,"Y",1) == 0)
			 strcat(sPrtstr, sformat_trade("1", 4, 1));
			 else
             strcat(sPrtstr, sformat_trade(sFacc_car, 4, 1)); /*241-241:�r�p�H�ϧO */
             strcat(sPrtstr, sformat_trade(sFacc_duty, 4, 1));/*242-242:�F�d */
             /* strcat(sPrtstr,"                 "); */ /*243-259:�O�I�Ҹ� *//*���A�ǰe  mark by sylvia 101.01.02 */
             
             strcpy(iins_type_tradevan," ");
             $SELECT iins_type_tradevan
                INTO $iins_type_tradevan
                FROM insurance_type
               WHERE iins_type = $iins_ply;

             strcat(sPrtstr, sformat_trade(iins_type_tradevan, 5, 2)); /* 260-261:�F�d�I�إN�� */

             printf ("------>[%s]\n",sPrtstr);

             fprintf(fptr,"%s\n",sPrtstr);
             cntrlrec++;
   }
   $CLOSE CUS42;
   $FREE  CUS42;

   printf("lApp_ins2------> cntrlrec[%d]\n",cntrlrec);
   if ( cntrlrec > 0 )
   {
      $INSERT INTO TRADE_COUNT
         ( file_name, policy_day, qcount, Tastype )
       VALUES
         ( $Tmp1, $oldDappraisal, $cntrlrec, 'A' );

      fclose(fptr);

      if (strcmp(option,"2")==0)
      {
         fclose(fptr1);
      }
   }

   return(SUCCESS);

errexit:
     printf("car9973vol_app_ins:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
     EWRITE(userid,SQLCODE,sqlca.sqlerrm);
     return SQLCODE;
}
/*--------------------���N�w�M(�s)--------------------------------------------*/
long lStl_ins2()
{
   $char  sIpolicy[POLICY_NUM_1],sObjno[CA_TARGET_NUM+1];

   $char  sIpolicy1[POLICY_NUM_1], sIpolicy2[POLICY_NUM_2];
   long  iRtnCode;
   int   iFetch=0,ilength=0;

   $char  sIclaim[CLAIM_NUM],sIins_type[INSURANCE_TYPE];
   $char  iins_type_rule[INSURANCE_TYPE],fins_grp[2];
   $char  sItag[CA_TAG_NUM],sDappraisal[11],sFstl[2],sFlast[2];
   $char  sIacc_license[11],sIacc_birth[8],sIacc_birth_yy[4],sIacc_birth_mm[3];
   $char  sIacc_birth_yyyy[5];
   $char  sIacc_birth_dd[3],sNacc_driver[21],sFacc_sex[2],sFacc_marri[2];
   $char  sFacc_nation[2],sIacc_reason[3],sDaccident[14],sIacc_area[3];
   $char  sFpart[2],sFpart_A[2], sFacc_car[2],sFacc_duty[2];
   $long  lDgroup,lQinjure,lQdeath,lMins_comp,lMins_dedu,lMins_stl,lMins_proc;
   $long  lIclose_type;
   $long Dappraisal,oldDappraisal;
   char  sQinjure[4],sQdeath[4],sQcripple[4],sIclose_type[6];
   char  sQinjure_1[4],sQdeath_1[4],sQcripple_1[4];
   char  sQinjure_stl[9],sQdeath_stl[9],sQcripple_stl[9];
   char  sMins_dedu[8],sMins_stl[13],sMins_comp[13],sMins_proc[8];
   char  sDgroup_yyyy[5], sDgroup_mm[3], sDgroup_dd[3];
   char sPrtstr[1000];
   $char sDgroup[11],fcard_class[2],stmt_buf6[512];
   $char MIclaim[21], MFstl[2], MFlast[2], MIins_type[7];
   $char MIacc_license[11], MIacc_birth[8], MNacc_driver[21];
   $long MDgroup=0;
   $char MFacc_sex[2], MFacc_marri[2], MFacc_nation[2], MIacc_reason[3];
   $char MDaccident[14], MIacc_area[3], MFpart[2], MFacc_car[2], MFacc_duty[2], MIpolicy[21];
   $long MQinjure=0, MMins_comp=0, MMins_dedu=0, MMins_stl=0, MMins_proc=0;
   $int  MIclose_type=0;
   $long T9A_qlia=0,T9B_qlia=0,T9C_qlia=0;
   $long T9A_mstl=0,T9B_mstl=0,T9C_mstl=0;
   $long l29_dgroup, tmp_cnt = 0;
   $long lDbgn_u, lDbgn_s, lDend_u, lDend_s;
   $char sDbgn_s[11], sDend_s[11], sTmplog[100], facc_car[2], fsystem[2], fassured[2];
   long  year1=0, year2=0;
   $char chk_dpolicy[2];

     $long date_1000901, ldpolicy;
     $char iins_type_tradevan[INSURANCE_TYPE], tmp_dbname[20], iins_ply[INSURANCE_TYPE];
     $char stmt_bufb[512], stmt_bufc[512];
   $char  stmt_buf8[4096];
   $char sTastype[2];
   $char iedr_tag[13];
   $char iedr_assured[11];
   $char iadj_assured[13];
   $char MIacc_birth_yyyy[5],MIacc_birth_mm[3],MIacc_birth_dd[3]; 


   $WHENEVER SQLERROR GOTO errexit;
   printf ("lStl_ins2\n");
   
   if ( strcmp(option,"Y") == 0 )
   {
      /* �ˮ֩ҤU���_����O�_�W�L���� */
         lDbgn_u = cm_ymd_edate(datebgn);    /* �ϥΪ̿�J�_�� */
         lDend_u = cm_ymd_edate(dateend);    /* �ϥΪ̿�J�_�� */
         
         $select date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10])),
                 date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10]))
            into $lDbgn_s, $sDbgn_s
            from cu_code_data
           where itype = 'CA' and icode = '02';
        
         
         $select date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10])),
                 date(mdy(tcode_remark[1,2],tcode_remark[4,5],tcode_remark[7,10]))  
            into $lDend_s, $sDend_s
            from cu_code_data
           where itype = 'CA' and icode = '03';
        
         printf("datebgn=[%s]lDbgn_u=[%ld]\n",datebgn,lDbgn_u);
         printf("dateend=[%s]lDend_u=[%ld]\n",dateend,lDend_u);
         printf("sDbgn_s=[%s]lDbgn_s=[%ld]\n",sDbgn_s,lDbgn_s);
         printf("sDend_s=[%s]lDend_s=[%ld]\n",sDend_s,lDend_s);
         
         if ((lDbgn_u < lDbgn_s) || (lDbgn_u > lDend_s))
         {
            sprintf_s(strlog, sizeof strlog,"���v�ɰ_�鶷���� %s ~ %s ����,�нT�{!", sDbgn_s, sDend_s);
            return 100;
         }
         
         if ((lDend_u > lDend_s) || (lDend_u < lDbgn_s))
         {
            sprintf_s(strlog, sizeof strlog,"���v�ɨ��鶷���� %s ~ %s ����,�нT�{!", sDbgn_s, sDend_s);
            return 100;
         }
   }
   
   memset(strtmp, 0x00, sizeof(strtmp));
   sIcar_type[0] = '\0';
   sItag[0]='\0';
   sDappraisal[0]= '\0';
   sIacc_license[0]= '\0';
   sIacc_birth[0]='\0';
   sIacc_birth_yy[0]='\0';
   sIacc_birth_mm[0]='\0';
   sIacc_birth_dd[0]='\0';
   sNacc_driver[0]='\0';
   sFacc_sex[0]='\0';
   sFacc_marri[0]= '\0';
   sFacc_nation[0]='\0';
   sIacc_reason[0]='\0';
   sDaccident[0]='\0';
   sIacc_area[0]='\0';
   sFpart[0]= '\0';
   sFpart_A[0]= '\0';
   sFacc_car[0]='\0';
   sFacc_duty[0]='\0';
   sIacc_birth_yyyy[0]='\0';
   T9A_qlia=T9B_qlia=T9C_qlia=0;
   T9A_mstl=T9B_mstl=T9C_mstl=0;
   MDgroup = 0;
   l29_dgroup = 0;
   chk_dpolicy[0]='\0';
   rstrdate( "09/01/2011", &date_1000901);

   memset(sTmt_buf,' ',sizeof(sTmt_buf));

   $CREATE TEMP TABLE STLINS
   (
      TIclaim char(20),
      TFstl   char(1),
      TFlast  char(1),
      TIclose_type  int,
      TIins_type    char(6),
      TDgroup       date,
      TQinjure      int,
      TMins_comp    int,
      TMins_dedu    int,
      TMins_stl     int,
      TMins_proc    int,
      TIacc_license char(10),
      TIacc_birth   char(7),
      TNacc_driver  char(18),
      TFacc_sex     char(1),
      TFacc_marri   char(1),
      TFacc_nation  char(1),
      TIacc_reason  char(2),
      TDaccident    char(13),
      TIacc_area    char(2),
      TFpart      char(1),
      TFacc_car   char(1),
      TFacc_duty  char(1),
      TIpolicy    char(20),
      T9A_qlia    int default 0,
      T9B_qlia    int default 0,
      T9C_qlia    int default 0,
      T9A_mstl    int default 0,
      T9B_mstl    int default 0,
      T9C_mstl    int default 0,
      T_itag	  char(12),
      iins_type   char(6),
      iins_ply   char(6),
      TIacc_birth_yyyy  char(4),
      TIacc_birth_mm    char(2),
      TIacc_birth_dd    char(2)
     )WITH NO LOG;

   $CREATE UNIQUE INDEX STLINS_IX ON
      STLINS( TIclaim, TFstl, TIclose_type, iins_ply);

      if (goption[0] == 'C')
      {
          $select ibranch_in
             into $ibranch_in
             from ca_clm_process
            where iclaim = $giclaim;
          if (SQLCODE == SQLNOTFOUND)
          {
             strcpy(ibranch_in,"00");
          }

          sprintf_s(sTmt_buf, sizeof sTmt_buf," select max(a.dgroup) \
                               from %s:stl_ins_type a  \
                              where 1=1 %s ", get_full_dbname(ibranch_in), sWhere);

          printf("sTmt_buf[%s]\n",sTmt_buf);

          $prepare get_max_dgro from $sTmt_buf;
          $execute get_max_dgro
              into $min_dapp;

          strcpy(sDappraisal_bgn, min_dapp);
          strcpy(sDappraisal_end, min_dapp);
          rstrdate(sDappraisal_bgn,&dbgn_long);
          rstrdate(sDappraisal_end,&dapp_end);
          strcpy(datebgn, cm_from_infdate(min_dapp));
          strcpy(dateend, cm_from_infdate(min_dapp));
      }


   iFetch = True;
   for ( i=0;i<count_db;i++)
   {
      if ( strcmp(option,"Y") == 0 )
      {
         /* �ɾ����I�z�߾��v��� */
          sprintf_s(sTmt_buf, sizeof sTmt_buf,"SELECT a.iclaim,a.fstl,a.flast,a.iclose_type,a.iins_type, "
                          "a.dgroup,a.qlia,a.mins_comp,a.mins_dedu,a.mins_stl,a.mins_proc, "
                          "b.iacc_license,b.iacc_birth,b.nacc_driver,b.facc_sex,b.facc_marri, "
                          "b.facc_nation,b.iacc_reason,b.daccident,b.iacc_area, "
                          "b.fpart,b.facc_rel,"
                          "decode(d.fins_grp,'1',b.fdmg_duty,b.facc_duty), "
                          "b.ipolicy, c.itag,"
                          "decode(d.iins_type_rule,'21','23',d.iins_type_rule),"
                          "d.fins_grp, b.facc_car, e.fsystem, f.fassured, d.iins_ply, c.icar_type,"
                          "CASE WHEN g.dpolicy < '08/01/2016' THEN 'Y' ELSE 'N' END,"
                          "to_char(b.dacc_birth,'%%Y'),to_char(b.dacc_birth,'%%m'),to_char(b.dacc_birth,'%%d') "
                          " FROM %s:stl_ins_type a,%s:appraisal b,%s:adjustment_ply c, "
                          "      insurance_type d, ca_clm_process e, %s:policy f, %s:ply_relation g "
                          "WHERE a.iclaim=b.iclaim AND b.iclaim=c.iclaim "
                          "   AND b.iclaim = e.iclaim "
                          "   AND b.ipolicy = e.ipolicy "
                          "   AND b.ipolicy = f.ipolicy "
                          "   AND b.ipolicy = g.ipolicy "
                          "  AND a.iins_type = d.iins_type AND d.iins_ply not in ('171','172','173','174','175') "
                          "  AND date(b.daccident) BETWEEN  '%s' AND  '%s' "
                          "  AND a.dgroup  <= '%s' "
   		    		        "  AND a.iclaim[6] <> 'W' "
   		    		        "  AND c.icar_type IN ('01','02','32','34') "
   		    		        "  AND f.ipolicy[6,7] not in ('VW','EB','TV') "
                          "ORDER BY 1,2,4,26,5,6",list[i].dbname,
                          list[i].dbname,list[i].dbname, list[i].dbname, list[i].dbname,sDappraisal_bgn, 
                          sDappraisal_end, sDend_s);
   
         printf("�������v��:sTmt[%s]\n",sTmt_buf);
      }
      else
      {
         /* 1000413004_C1 �����I�]�n�e���T�@mark by sylvia 100.05.02 */
         sprintf_s(sTmt_buf, sizeof sTmt_buf,"SELECT a.iclaim,a.fstl,a.flast,a.iclose_type,a.iins_type, "
                          "a.dgroup,a.qlia,a.mins_comp,a.mins_dedu,a.mins_stl,a.mins_proc, "
                          "b.iacc_license,b.iacc_birth,b.nacc_driver,b.facc_sex,b.facc_marri, "
                          "b.facc_nation,b.iacc_reason,b.daccident,b.iacc_area, "
                          "b.fpart,b.facc_rel,"
                          "decode(d.fins_grp,'1',b.fdmg_duty,b.facc_duty), "
                          "b.ipolicy, c.itag,"
                          "decode(d.iins_type_rule,'21','23',d.iins_type_rule),"
                          "d.fins_grp, b.facc_car, e.fsystem, f.fassured, d.iins_ply, c.icar_type,"
                          "CASE WHEN g.dpolicy < '08/01/2016' THEN 'Y' ELSE 'N' END,"
                          "to_char(b.dacc_birth,'%%Y'),to_char(b.dacc_birth,'%%m'),to_char(b.dacc_birth,'%%d') "
                          " FROM %s:stl_ins_type a,%s:appraisal b,%s:adjustment_ply c, "
                          "      insurance_type d, ca_clm_process e, %s:policy f, %s:ply_relation g "
                          "WHERE a.iclaim=b.iclaim AND b.iclaim=c.iclaim "
                          "   AND b.iclaim = e.iclaim "
                          "   AND b.ipolicy = e.ipolicy "
                          "   AND b.ipolicy = f.ipolicy "
                          "   AND b.ipolicy = g.ipolicy "
                          "  AND a.iins_type = d.iins_type AND d.iins_ply not in ('171','172','173','174','175') "
                          "  AND a.dgroup  BETWEEN '%s' AND '%s' %s "
   		    		        "  AND a.iclaim[6] <> 'W' "
   		    		        "  AND f.ipolicy[6,7] not in ('VW','EB','TV') "
                          "ORDER BY 1,2,4,26,5,6", list[i].dbname, list[i].dbname,
                          list[i].dbname,list[i].dbname,list[i].dbname,sDappraisal_bgn,
                          sDappraisal_end, sWhere);
   
         printf("���`��:sTmt[%s]\n",sTmt_buf);
      }

      $PREPARE STMT3 FROM $sTmt_buf;
      $DECLARE CUSSTL2 CURSOR FOR STMT3;

      $OPEN CUSSTL2;
      while(1)
      {
         $FETCH CUSSTL2 INTO $MIclaim,$MFstl,$MFlast,$MIclose_type,$MIins_type,
                            $MDgroup,$MQinjure,$MMins_comp,$MMins_dedu,
                            $MMins_stl,$MMins_proc,$MIacc_license,$MIacc_birth,
                            $MNacc_driver,$MFacc_sex,$MFacc_marri,$MFacc_nation,
                            $MIacc_reason,$MDaccident,$MIacc_area,$MFpart,
                            $MFacc_car,$MFacc_duty,$MIpolicy,$sItag,
                            $iins_type_rule,$fins_grp, $facc_car, $fsystem, $fassured, $iins_ply, $sIcar_type, $chk_dpolicy,
                            $MIacc_birth_yyyy,$MIacc_birth_mm,$MIacc_birth_dd;;

         if( SQLCODE == SQLNOTFOUND ) break;
         
         /* 1061102009_C1 �ק�ǰe���T27���ؾ��񨮵P�W�h
         if (strcmp(sIcar_type, "27") == 0 && strcmp(chk_dpolicy) == "Y")
            strcpy(sItag, " ");   */              /* ����27,���P���X�M�� modify by sylvia 101.02.24 (1001005007_C1) */

         sprintf_s(stmt_buf8, sizeof stmt_buf8," select iassured               \
                               from %s:adjustment_ply      \
                              where iclaim = '%s' ",list[i].dbname, MIclaim);

         $prepare get_adj_assured from $stmt_buf8;
         $execute get_adj_assured
             into $iadj_assured;
         if (SQLCODE == SQLNOTFOUND)
         { 
             strcpy(iadj_assured,"");
         } 
         strcpy(iadj_assured,trim(iadj_assured));

         sprintf_s(stmt_buf8, sizeof stmt_buf8," select first 1 nvl(b.itag,' ') as itag, nvl(b.iassured,' ') as iassured  \
                               from %s:edr_relation a, %s:endorsement b    \
                              where a.iendorse      =  b.iendorse          \
                                and a.dedr_close    is not null            \
                                and a.ipolicy       =  '%s'                \
                                and a.dedr_begin   <=  today               \
                              order by dedr_begin desc, dedr_close desc, dcreate desc ", list[i].dbname, list[i].dbname, MIpolicy);

         $prepare get_itag_assured from $stmt_buf8;                
         $execute get_itag_assured
             into $iedr_tag, $iedr_assured; 
         if (SQLCODE != SQLNOTFOUND)
         {
            strcpy(iedr_tag,trim(iedr_tag));
            strcpy(iedr_assured,trim(iedr_assured));
            strcpy(sItag,trim(sItag));
            if (strcmp(iedr_tag,sItag)!=0)
            {
               /*  �p�G���L��A�B���P���X���P�A�����e�̷s�����P  */
               if (strcmp(iedr_assured, iadj_assured)!=0)
               {
                  strcpy(sItag,iedr_tag);  
               }            
               else
               {
                  strcpy(infdaccident, get_inf_date(MDaccident));
                  printf("infdaccident[%s]\n",infdaccident);
                  
	          sprintf_s(stmt_buf8, sizeof stmt_buf8," select first 1 nvl(b.itag,' ') as itag, nvl(b.iassured,' ') as iassured  \
	                                from %s:edr_relation a, %s:endorsement b    \
	                               where a.iendorse      =  b.iendorse          \
	                                 and a.dedr_close    is not null            \
	                                 and a.ipolicy       =  '%s'                \
	                                 and a.dedr_begin   <=  '%s'                \
	                               order by dedr_begin desc, dedr_close desc, dcreate desc ", list[i].dbname, list[i].dbname, MIpolicy, infdaccident );
	                               
	          printf("stmt_buf8[%s]\n",stmt_buf8);
	          
	          $prepare get_itag_assured2 from $stmt_buf8;                
	          $execute get_itag_assured2
	              into $iedr_tag, $iedr_assured;     
	          if (SQLCODE != SQLNOTFOUND)	          
	          {
	             strcpy(iedr_tag,trim(iedr_tag));
	             if (strcmp(iedr_tag,sItag)!=0)
	             {
	                 strcpy(sItag,iedr_tag);
	             }
	          }              
               }
            }
         }
        
         /*�r�p�H�ϧO*/
         switch (MFacc_car[0])
         {
              case '1':  strcpy(MFacc_car,"1");  break;
              case 'A':  strcpy(MFacc_car,"2");  break;
              case 'B':  strcpy(MFacc_car,"2");  break;
              case 'C':  strcpy(MFacc_car,"2");  break;
              case 'D':  strcpy(MFacc_car,"2");  break;
              case 'E':  strcpy(MFacc_car,"4");  break;
              case 'F':  strcpy(MFacc_car,"4");  break;
              case 'G':  strcpy(MFacc_car,"4");  break;
              case '4':  strcpy(MFacc_car,"4");  break;
              case '5':  strcpy(MFacc_car,"4");  break;
              default :  strcpy(MFacc_car,"1");  break;
         }
            
         /*****************************************************
         if( fsystem[0] == 'N')
         {
            strcpy( MFacc_car, facc_car);   
         }
         else
         {
			switch (MFacc_car[0])
			{
				case '1':
					break;
				case '2':
					break;
				case '3':
					MFacc_car[0] = '4';
					break;
				case '4':
					MFacc_car[0] = '4';
					break;
				case '5':
                                        if( fassured[0] == '1' || fassured[0] == '3' || fassured[0] == '5')
					    MFacc_car[0] = '2'; 
                                        else
					    MFacc_car[0] = '4'; 
					break;
				default :
					MFacc_car[0] = '2';
					break;
			}
         }
         ******************************************************/

         T9A_qlia = T9B_qlia = T9C_qlia = 0;
         T9A_mstl = T9B_mstl = T9C_mstl = 0;

         strcpy(MIins_type,rtrim(MIins_type));
         ilength= strlen(MIins_type)-1;

         strcpy(tmp_dbname,get_car_full_db(MIpolicy));
         sprintf_s(stmt_bufc, sizeof stmt_bufc,"SELECT dpolicy FROM %s:ply_relation \
                             WHERE ipolicy = '%s' ",
                           tmp_dbname, MIpolicy );

         $PREPARE EXE_STMTc FROM $stmt_bufc;
         $EXECUTE EXE_STMTc INTO $ldpolicy;

         if (fins_grp[0]=='2')
         {
            if (strncmp(MIins_type[ilength],"A",1) == 0 ||
                strcmp(MIins_type,INJURE)==0)
            {
               T9A_qlia = MQinjure;
               T9A_mstl = MMins_stl;
            }

            if (strncmp(MIins_type[ilength],"B",1) == 0 ||
                strcmp(MIins_type,DEATH)==0)
            {
               T9B_qlia = MQinjure;
               T9B_mstl = MMins_stl;
            }

            if (strncmp(MIins_type[ilength],"C",1) == 0 ||
                strcmp(MIins_type,CRIPPLE)==0)
            {
               T9C_qlia = MQinjure;
               T9C_mstl = MMins_stl;
            }
         }

         if ( ldpolicy < date_1000901 &&
              strcmp( trim(iins_type_rule), "15") != 0 &&
              strcmp( trim(iins_type_rule), "16") != 0 ) /* ñ���< 10/20/2010�A�ǰeinsurance_type.iins_type_rule */
             $UPDATE STLINS
                SET (TDgroup,TMins_comp,TMins_dedu,TMins_stl,
                     TMins_proc,T9A_qlia,T9B_qlia,T9C_qlia,
                     T9A_mstl,T9B_mstl,T9C_mstl)
                  = ($MDgroup,TMins_comp+$MMins_comp,TMins_dedu+$MMins_dedu,
                     TMins_stl+$MMins_stl,TMins_proc+$MMins_proc,
                     T9A_qlia+$T9A_qlia,T9B_qlia+$T9B_qlia,T9C_qlia+$T9C_qlia,
                     T9A_mstl+$T9A_mstl,T9B_mstl+$T9B_mstl,T9C_mstl+$T9C_mstl)
              WHERE TIclaim      = $MIclaim
                AND TFstl        = $MFstl
                AND TIclose_type = $MIclose_type
                AND TIins_type   = $iins_type_rule;
        else
        {
             $UPDATE STLINS
                SET (TDgroup,TMins_comp,TMins_dedu,TMins_stl,
                     TMins_proc,T9A_qlia,T9B_qlia,T9C_qlia,
                     T9A_mstl,T9B_mstl,T9C_mstl)
                  = ($MDgroup,TMins_comp+$MMins_comp,TMins_dedu+$MMins_dedu,
                     TMins_stl+$MMins_stl,TMins_proc+$MMins_proc,
                     T9A_qlia+$T9A_qlia,T9B_qlia+$T9B_qlia,T9C_qlia+$T9C_qlia,
                     T9A_mstl+$T9A_mstl,T9B_mstl+$T9B_mstl,T9C_mstl+$T9C_mstl)
              WHERE TIclaim      = $MIclaim
                AND TFstl        = $MFstl
                AND TIclose_type = $MIclose_type
                AND iins_ply   = $iins_ply;
             strcpy( iins_type_rule, trim(iins_ply));
        }

         if (sqlca.sqlerrd[2] == 0)
         {
            $INSERT INTO STLINS ( TIclaim, TFstl, TFlast,
                                  TIclose_type, TIins_type,
                                  TDgroup, TQinjure, TMins_comp,
                                  TMins_dedu, TMins_stl,
                                  TMins_proc, TIacc_license,
                                  TIacc_birth, TNacc_driver,
                                  TFacc_sex, TFacc_marri,
                                  TFacc_nation, TIacc_reason,
                                  TDaccident,TIacc_area, TFpart,
                                  TFacc_car, TFacc_duty,
                                  TIpolicy,T9A_qlia,T9B_qlia,
                                  T9C_qlia,T9A_mstl,T9B_mstl,
                                  T9C_mstl,T_itag, iins_type, iins_ply,
                                  TIacc_birth_yyyy,TIacc_birth_mm,TIacc_birth_dd)
             VALUES ( $MIclaim,$MFstl,$MFlast,
                      $MIclose_type,$iins_type_rule,
                      $MDgroup,$MQinjure,$MMins_comp,
                      $MMins_dedu,
                      $MMins_stl,$MMins_proc,
                      $MIacc_license,$MIacc_birth,
                      $MNacc_driver,$MFacc_sex,
                      $MFacc_marri,$MFacc_nation,
                      $MIacc_reason,$MDaccident,
                      $MIacc_area,$MFpart,
                      $MFacc_car,$MFacc_duty,$MIpolicy,
                      $T9A_qlia,$T9B_qlia,$T9C_qlia,
                      $T9A_mstl,$T9B_mstl,$T9C_mstl,$sItag, $MIins_type, $iins_ply,
                      $MIacc_birth_yyyy,$MIacc_birth_mm,$MIacc_birth_dd);
         }

         /* �N���N�O���J�Ȧstable�� */
         $INSERT INTO tmp_policy (ipolicy) VALUES ($MIpolicy);
      } /* end of while */
      $CLOSE CUSSTL2;
      $FREE  CUSSTL2;

      if ( strcmp(option,"Y") == 0 )
      {
         /* �P�_�Y�O����(01,02,32,34)�B���O(01,05,09,31,32,86,110,113,114)���@�I��,���e���T */
         sprintf_s(stmt_buf6, sizeof stmt_buf6,"insert into del_50_policy "
                           "select ipolicy from %s:ply_relation a "
                           " where ipolicy in (select ipolicy from tmp_policy) "
                           "   and icar_type in ('01','02','32','34') "
                           "   and ipolicy not in (select unique ipolicy from %s:ply_ins_type "
                           "                        where ipolicy = a.ipolicy "
                           "                          and iins_type in ('01','05','09','31','32','86','110','113','114','149','157','158','159','201','205','209','231','232','249')) ",
      	                  list[i].dbname,list[i].dbname);
         printf("�������v stmt_buf6[%s]\n",stmt_buf6);
         $PREPARE cur_tmp1 FROM  $stmt_buf6;
         $EXECUTE cur_tmp1;
      }
      else
      {
         /* car9901111 �P�_�Y�O��l�O��ȩӫO50�I�خ�,�h�ӫO�椣�e���T */
         /* �N�ŦX��ӫO50�O���Jtemp table, �ñqTABLE CAR9971�R�� */
         sprintf_s(stmt_buf6, sizeof stmt_buf6,"insert into del_50_policy "
                           "select ipolicy from %s:ori_ins_type a "
                           "where ipolicy in (select ipolicy from tmp_policy) "
                           "  and iins_type = '50' "
                           "  and not exists (select 1 from %s:ori_ins_type b where a.ipolicy = b.ipolicy "
                           "  and a.iins_type <> b.iins_type)",list[i].dbname,list[i].dbname);
   
         printf("stmt2[%s]\n",stmt_buf6);
   
         $PREPARE cur_tmp1 FROM  $stmt_buf6;
         $EXECUTE cur_tmp1;
         
         /* �P�_�Y�O����(01,02,32,34)�B���O(01,05,09,31,32,86,110,113,114)���@�I��,���e���T */
         sprintf_s(stmt_buf6, sizeof stmt_buf6,"insert into del_50_policy "
                           "select ipolicy from %s:ori_ply_relation a "
                           " where ipolicy in (select ipolicy from tmp_policy) "
                           "   and icar_type in ('01','02','32','34') "
                           "   and ipolicy not in (select unique ipolicy from %s:ori_ins_type "
                           "                        where ipolicy = a.ipolicy "
                           "                          and iins_type in ('01','05','09','31','32','86','110','113','114','149','157','158','159','201','205','209','231','232','249')) ",
      	                  list[i].dbname,list[i].dbname);
         printf("���� stmt_buf6[%s]\n",stmt_buf6);
         $PREPARE cur_tmp1 FROM  $stmt_buf6;
         $EXECUTE cur_tmp1;
      }

      $SELECT count(*) INTO $tmp_cnt FROM STLINS;
      printf("delete before STLINS count = [%d]\n",tmp_cnt);

      $DELETE FROM STLINS WHERE Tipolicy in (select ipolicy from del_50_policy);

      $SELECT count(*) INTO $tmp_cnt FROM STLINS;
      printf("delete after STLINS count = [%d]\n",tmp_cnt);

      $DELETE FROM del_50_policy WHERE 1=1;
      $DELETE FROM tmp_policy WHERE 1=1;

   } /* end of select DB */

   prem_total = 0;
   cntrlrec = 0;
   qcount = Tamount = Tinjure = Tcripple = Tdeath = 0;

   $DECLARE CUS62 CURSOR for
       SELECT *
         INTO $sIclaim,$sFstl,$sFlast,$lIclose_type,$sIins_type,
              $sDgroup,$lQinjure,$lMins_comp,$lMins_dedu,
              $lMins_stl,$lMins_proc,$sIacc_license,$sIacc_birth,
              $sNacc_driver,$sFacc_sex,$sFacc_marri,$sFacc_nation,
              $sIacc_reason,$sDaccident,$sIacc_area,$sFpart,
              $sFacc_car,$sFacc_duty,$sIpolicy,$T9A_qlia,$T9B_qlia,$T9C_qlia,
              $T9A_mstl,$T9B_mstl,$T9C_mstl,$sItag, $MIins_type, $iins_ply
         FROM STLINS
        ORDER BY TDgroup;

   $OPEN CUS62;
   while (1)
   {
      memset(sPrtstr,' ',sizeof(sPrtstr));

      $FETCH CUS62;

      if (SQLCODE == SQLNOTFOUND) break;
      if (risnull(2,&lQinjure)==1) lQinjure=0;
      if (risnull(2,&lQdeath)==1) lQdeath=0;
      if (risnull(2,&lMins_comp)==1) lMins_comp=0;
      if (risnull(2,&lMins_dedu)==1) lMins_dedu=0;
      if (risnull(2,&lMins_stl)==1) lMins_stl=0;
      if (risnull(2,&lMins_proc)==1) lMins_proc=0;

      rstrdate( sDgroup , &close_date );

      sDgroup_mm[0]=sDgroup[0];
      sDgroup_mm[1]=sDgroup[1];
      sDgroup_mm[2]='\0';

      sDgroup_dd[0]=sDgroup[3];
      sDgroup_dd[1]=sDgroup[4];
      sDgroup_dd[2]='\0';

      sDgroup_yyyy[0]=sDgroup[6];
      sDgroup_yyyy[1]=sDgroup[7];
      sDgroup_yyyy[2]=sDgroup[8];
      sDgroup_yyyy[3]=sDgroup[9];
      sDgroup_yyyy[4]='\0';

      iRtnCode = split_policy(sIpolicy, sIpolicy1, sIpolicy2);
      if (iRtnCode != M_CM_OK) break;

      company_flag=sIpolicy1[7];

      strcpy(COMPANY,companyid);
      strcpy(COMPANY_F,companyid);

      if(strcmp( companyid,"17")==0)
      {
         if(company_flag > 65 )
         {
            $select ipolicy_a
               into $sIpolicy1
               from conv_ipolicy
              where ipolicy_n = $sIpolicy1;

            strcpy(COMPANY,"16");

         }

         iclaim_flag=sIclaim[6];

         if(iclaim_flag > 65 )
         {
            $select distinct iclaim_a
               into $sIclaim
               from conv_iclaim
              where iclaim_n = $sIclaim;

            strcpy(COMPANY_F,"16");

         }
      }

      if(iFetch)
      {
         old_close_date = close_date;
         iFetch = FALSE;

         if (strcmp(option,"4")==0 || strcmp(option,"5")==0)
         {
            cm_split_ymd_100(datebgn,day_yy,day_mm,day_dd);
         }
         else
         {
            strcpy( close_date_c , cm_cdate_str_100( close_date ));
            cm_split_ymd_100(close_date_c,day_yy,day_mm,day_dd);
         }

         if (strcmp(option,"Y")==0)
         {  /* ���v�ɥH�~�׬��ɦW, �u���ͤ@���� */
            sprintf_s(Tmp1, sizeof Tmp1,"ISBM%s_2011h",companyid);
         }
         else
         {
            sprintf_s(Tmp1, sizeof Tmp1,"ISBM%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
          
            if (goption[0] == 'C')
            {
               strcat(Tmp1,"_");
               strcat(Tmp1,hhminsec);
            }
         }
         strcpy(iply_type,opt);
         strcpy(fcard_class, "2");

         printf("in iFetch fcard_class[%s]\n",fcard_class);

         sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);

         printf("file0[%s] Tmp1[%s]\n",file0,Tmp1);

         $SELECT qcount
            INTO $qcount
            FROM TRADE_COUNT
           WHERE file_name = $Tmp1;

         if ( SQLCODE == SQLNOTFOUND ) fptr=fopen(file0,"w");
         else  fptr=fopen(file0,"a+");
      }

      if ( old_close_date != close_date ) /* �����ثefile , open a new file*/
      {
         if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0) 
         {  
            /* ���e�έ簣���e&���v�ɤ����̤�������ɮ� */
            if (strcmp(option,"Y") != 0)
            {
               if (cntrlrec > 0)
               {
                  printf(" in stlins select \n");
   
                  $SELECT qcount
                     INTO $qcount
                     FROM TRADE_COUNT
                    WHERE file_name = $Tmp1;
   
                  qcount += cntrlrec;
   
                  $UPDATE TRADE_COUNT
                      SET ( qcount, Tamount, Tinjure, Tcripple, Tdeath, Tastype ) =
                          ( $qcount, $prem_total, $Tinjure, $Tcripple, $Tdeath, 'S' )
                    WHERE file_name = $Tmp1;
   
                  if ( sqlca.sqlerrd[2] == 0 )
                  {
                     printf("3555:policy_day[%d]\n", old_close_date);
   
                     $INSERT INTO TRADE_COUNT
                        ( policy_day, file_name, qcount, Tamount, Tinjure, Tcripple, Tdeath, Tastype )
                      VALUES
                        ( $old_close_date, $Tmp1, $qcount, $prem_total, $Tinjure, $Tcripple, $Tdeath, 'S' );
                  }
   
                  strcpy(prtstr, sformat_trade("CNTRLREC", 4, 8));
                  /* rfmtlong(qcount,"&&&&&&",cntrlrec_c); */
                  sprintf_s(cntrlrec_c, sizeof cntrlrec_c, "%ld", qcount);
                  strcat(prtstr, sformat_trade(cntrlrec_c, 5, 6));
                  fprintf(fptr, "%s\n", prtstr);
               }
   
               fclose(fptr);
   
               $SELECT policy_day, qcount, Tamount, Tinjure, Tcripple, Tdeath
                  INTO $policy_day, $qcount, $Tamount, $Tinjure, $Tcripple, $Tdeath
                  FROM TRADE_COUNT
                 WHERE file_name = $Tmp1;
    
   /*            rtncode = rptftpinsert( userid , "car9973" , Tmp1 );   */
   
               printf("before insert fcard_class[%s]\n",fcard_class);
   
               $insert into ca_trade_exam
                  (iply_type,dpolicy,fcard_class,itrans_type,
                   qcount,mamount,minjure,mcripple,mdeath)
                values
                  ($iply_type,$policy_day,$fcard_class,0,
                   $qcount,$Tamount,$Tinjure,$Tcripple,$Tdeath);
   
               sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%d",file0,qcount);
               WRITELOG(errfpt , strlog);
   
               strcpy( close_date_c , cm_cdate_str_100( close_date ));
   
               cm_split_ymd_100(close_date_c,day_yy,day_mm,day_dd);
   
               sprintf_s(Tmp1, sizeof Tmp1,"ISBM%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
               strcpy(iply_type,opt);
               strcpy(fcard_class, "2");
   
               sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
   
               $SELECT qcount
                  INTO $qcount
                  FROM TRADE_COUNT
                 WHERE file_name = $Tmp1;
   
               if ( SQLCODE == SQLNOTFOUND ) fptr=fopen(file0,"w");
               else  fptr=fopen(file0,"a+");
   
               cntrlrec = 0;
               prem_total = 0;
               qcount = Tamount = Tinjure = Tcripple = Tdeath = 0;
            }
         }
      }

      old_close_date = close_date;

      strcpy(sPrtstr, sformat_trade("9", 4, 1));      /*C1-1:���ʧO*/
      
      if (*sFstl=='1') strcat(sPrtstr, sformat_trade("2", 4, 1));           /*C2-2:��*/
      else  strcat(sPrtstr, sformat_trade("3", 4, 1));                      /*C2-2:�l*/
      
      strcpy(strtmp,COMPANY_F);                       /*C3-1:���q�O*/
      strncat(strtmp,sIclaim, 14);
      strtmp[16]='\0';                                /*C3-2:�߮ר��z��*/
      strcat(sPrtstr, sformat_trade(strtmp, 4, 16));  /*C3-18:�߮ר��z��*/
      
      /* strcat(sPrtstr,COMPANY_F); sPrtstr[20]='\0'; */     /*C4-1:���q�O*/
      /* strncat(sPrtstr,sIclaim, 14); sPrtstr[34]='\0'; */   /*C4-2:�߮׸�*/
      strcat(sPrtstr, sformat_trade(strtmp, 4, 16));  /*C19-34:�߮׸�*/
      printf("sPrtstr[%s]\n",sPrtstr);

      /* rfmtlong(lIclose_type,"&&&&&",sIclose_type); */
      sprintf_s(sIclose_type, sizeof sIclose_type, "%ld", lIclose_type);
      strcat(sPrtstr, sformat_trade(sIclose_type, 4, 5)); /*C35-39:�߰l����*/

      if (*sFlast=='1')
      {
         strcpy(strtmp,sDgroup_yyyy);        /*C6-1:CCYY*/
         strcat(strtmp,sDgroup_mm);          /*C6-2:MM*/
         strcat(strtmp,sDgroup_dd);          /*C6-2:DD */
         strcat(sPrtstr, sformat_trade(strtmp, 4, 8));     /* C40-47:���פ�� */
      }
      else
         strcat(sPrtstr, sformat_trade("        ", 4, 8)); /* C40-47:���פ�� */

      strcpy(strtmp,COMPANY);                            /*C7-1:���q�O*/
      strcat(strtmp,sformat_trade(sIpolicy1 ,2 ,15));
      strcat(sPrtstr, sformat_trade(strtmp, 4, 17));     /*C48-64:�O�渹*/

      if (strlen(rtrim(sIpolicy2)) > 0)           /* ���j�O��*/
      {
         strcpy(sObjno, sformat_trade(sIpolicy2, 2, 4));
      }
      else
      {
         strcpy(sObjno,"0001");
      }

      strcat(sPrtstr, sformat_trade(sObjno, 4, 4)); /*C65-68:�Ъ���*/

      if (strlen(trim(sItag))<=0)
         strcpy(sItag, "        ");

      strcat(sPrtstr, sformat_trade(sItag, 4, 12)); /*C69-76:�P�Ӹ�*/

      strcat(sPrtstr, sformat_trade(sIacc_license, 4, 10)); /*C77-86:�r��*/
      strncpy(sIacc_birth_yy,sIacc_birth,2);          /*C10-2 �ͤ�*/
      sIacc_birth_yy[2] = '\0';
      sIacc_birth_mm[0]=sIacc_birth[2];
      sIacc_birth_mm[1]=sIacc_birth[3];
      sIacc_birth_mm[2]='\0';
      sIacc_birth_dd[0]=sIacc_birth[4];
      sIacc_birth_dd[1]=sIacc_birth[5];
      sIacc_birth_dd[2]='\0';
      strcpy(sIacc_birth_yyyy,itoa(1911+atoi(sIacc_birth_yy)));
      
      memset(strtmp, 0x00, sizeof(strtmp));
      strncpy(strtmp, sIacc_birth_yyyy,4);
      strtmp[4]='\0';
      strncat(strtmp,sIacc_birth_mm,2); strtmp[6]='\0';
      strncat(strtmp,sIacc_birth_dd,2);  strtmp[8]='\0';
      strcat(sPrtstr, sformat_trade(strtmp, 4, 8));      /*C87-94:�ͤ�*/

      strcat(sPrtstr, sformat_trade(sNacc_driver, 4, 20)); /*C95-114:�m�W*/
      strcat(sPrtstr, sformat_trade(sFacc_sex, 4, 1));     /*C115-115:�ʧO*/
      strcat(sPrtstr, sformat_trade(sFacc_marri, 4, 1));   /*C116-116:�B��*/
      strcat(sPrtstr, sformat_trade(sFacc_nation, 4, 1));  /*C117-117:�����O*/
      strcat(sPrtstr, sformat_trade(sIacc_reason, 4, 2));  /*C118-119:�X�I��]*/

      /* rfmtlong(0,"&&&",sQinjure_1);
      rfmtlong(0,"&&&",sQdeath_1);
      rfmtlong(0,"&&&",sQcripple_1); */
      strcpy(sQinjure_1, "0");
      strcpy(sQdeath_1, "0");
      strcpy(sQcripple_1, "0");
      
      strcat(sPrtstr, sformat_trade(sQinjure_1, 4, 3));   /*C120-122:���*/
      strcat(sPrtstr, sformat_trade(sQdeath_1, 4, 3));    /*C123-125:���`*/
      strcat(sPrtstr, sformat_trade(sQcripple_1, 4, 3));  /*C126-128:�ݼo*/

      memset(strtmp, 0x00, sizeof(strtmp));
      strncpy(strtmp,sDaccident,4); strtmp[4]='\0';       /*C13:�X�I����ɶ�*/
      strncat(strtmp,(sDaccident+5),2); strtmp[6]='\0';
      strncat(strtmp,(sDaccident+8),2); strtmp[8]='\0';
      strncat(strtmp,(sDaccident+11),2); strtmp[10]='\0';
      strcat(strtmp,"00"); 
      strcat(sPrtstr, sformat_trade(strtmp, 4, 12));      /*C129-140:�X�I����ɶ�*/

      /* �N�{��u�a�ϥN�����v���R���N��42�u�x�����v�B�N��63�u�x�n���v�B�N��65�u�������v�C*/
      if( strcmp( sIacc_area, "42") == 0)
		strcpy( sIacc_area, "41");
      else if( strcmp( sIacc_area, "63") == 0)
		strcpy( sIacc_area, "62");
      else if( strcmp( sIacc_area, "65") == 0)
		strcpy( sIacc_area, "64");

      strcat(sPrtstr, sformat_trade(sIacc_area, 4, 2));   /*C141-142:�X�I�a�ϥN��*/

      if (*sFpart=='1' || *sFpart=='2' || *sFpart=='3')
         sFpart_A[0]='1';
      else
         sFpart_A[0]='2';

      strcat(sPrtstr, sformat_trade(sFpart_A, 4, 1));     /*C143:�����l�O*/

           strcpy(tmp_dbname,get_car_full_db(sIpolicy));
           sprintf_s(stmt_bufb, sizeof stmt_bufb,"SELECT dpolicy FROM %s:ply_relation \
                               WHERE ipolicy = '%s' ",
                             tmp_dbname, sIpolicy );

           $PREPARE EXE_STMTb FROM $stmt_bufb;
           $EXECUTE EXE_STMTb INTO $ldpolicy;

           if ( ldpolicy < date_1000901  &&
                 strcmp( trim(sIins_type), "15") != 0 &&
                 strcmp( trim(sIins_type), "16") != 0) /* ñ���< 09/01/2011�A�ǰeinsurance_type.iins_type_rule */
           {
               puts("ñ���<09/01/2011");
               strcat(sPrtstr, sformat_trade(sIins_type, 4, 6)); /*C144-149:�����I�إN�X*/
           }
           else
           {
               puts("ñ���>=09/01/2011");
               strcat(sPrtstr, sformat_trade(iins_ply, 4, 6));   /*C144-149:�����I�إN�X*/
           }


              /* rfmtlong(T9A_qlia,"&&&",sQinjure);
              rfmtlong(T9A_mstl,"&&&&&&&&",sQinjure_stl);
              rfmtlong(T9B_qlia,"&&&",sQdeath);
              rfmtlong(T9B_mstl,"&&&&&&&&",sQdeath_stl);
              rfmtlong(T9C_qlia,"&&&",sQcripple);
              rfmtlong(T9C_mstl,"&&&&&&&&",sQcripple_stl);*/
              sprintf_s(sQinjure, sizeof sQinjure, "%ld", T9A_qlia);
              sprintf_s(sQinjure_stl, sizeof sQinjure_stl, "%ld", T9A_mstl);
              sprintf_s(sQdeath, sizeof sQdeath, "%ld", T9B_qlia);
              sprintf_s(sQdeath_stl, sizeof sQdeath_stl, "%ld", T9B_mstl);
              sprintf_s(sQcripple, sizeof sQcripple, "%ld", T9C_qlia);
              sprintf_s(sQcripple_stl, sizeof sQcripple_stl, "%ld", T9C_mstl);

               Tinjure  += T9A_mstl;
               Tdeath   += T9B_mstl;
               Tcripple += T9C_mstl;

              strcat(sPrtstr, sformat_trade(sQinjure, 4, 3));  /*C150-152:�����ˤH��*/
              strcat(sPrtstr, sformat_trade(sQdeath, 4, 3));   /*C153-155:��ڦ��`�H��*/
              strcat(sPrtstr, sformat_trade(sQcripple, 4, 3)); /*C156-158:��ڴݼo�H��*/
              strcat(sPrtstr, sformat_trade("            ", 4, 12)); /*159-170:�w���l�����B */
              
              /* rfmtlong(lMins_dedu,"&&&&&&&",sMins_dedu);*/
              sprintf_s(sMins_dedu, sizeof sMins_dedu, "%ld", lMins_dedu);
              strcat(sPrtstr, sformat_trade(sMins_dedu, 4, 12)); /*C171-177:�z�ߦۭt�B*/
              
              /* rfmtlong(lMins_stl,"&&&&&&&&&&&&",sMins_stl);*/
              sprintf_s(sMins_stl, sizeof sMins_stl, "%ld", lMins_stl);
              strcat(sPrtstr, sformat_trade(sMins_stl, 4, 12));  /*C178-189:��ڲz�ߪ��B*/

      prem_total += lMins_stl;

              strcat(sPrtstr, sformat_trade(sQinjure_stl, 4, 12));/*C190-197:�����˪��B*/
              strcat(sPrtstr, sformat_trade(sQdeath_stl, 4, 12)); /*C198-205:��ڦ��`���B*/
              strcat(sPrtstr, sformat_trade(sQcripple_stl, 4, 12)); /*C206-213:��ڴݼo���B*/
              
              /* rfmtlong(lMins_comp,"&&&&&&&&&&&&",sMins_comp);*/
              sprintf_s(sMins_comp, sizeof sMins_comp, "%ld", lMins_comp);
              strcat(sPrtstr, sformat_trade(sMins_comp, 4, 12)); /*C214-225:�M�Ѫ��B*/
              
              /* rfmtlong(lMins_proc,"&&&&&&&",sMins_proc); */
              sprintf_s(sMins_proc, sizeof sMins_proc, "%ld", lMins_proc);
              strcat(sPrtstr, sformat_trade(sMins_proc, 4, 12)); /*C226-232:�z�߶O��*/

              strcpy(strtmp,sDgroup_yyyy);                
              strcat(strtmp,sDgroup_mm);
              strcat(strtmp,sDgroup_dd);
              strcat(sPrtstr, sformat_trade(strtmp, 4, 8));    /*233-240:�w����� */
              strcat(sPrtstr, sformat_trade(sFacc_car, 4, 1)); /*241-241:�r�p�H�ϧO */
              strcat(sPrtstr, sformat_trade(sFacc_duty, 4, 1));/*242-242:�F�d */
              /* strcat(sPrtstr,"                 "); *//*243-259:�O�I�Ҹ� *//*���n�ǰe mark by sylvia 101.01.02*/

              strcpy(iins_type_tradevan," ");
              $SELECT iins_type_tradevan
                 INTO $iins_type_tradevan
                 FROM insurance_type
                WHERE iins_type = $iins_ply;

              strcat(sPrtstr, sformat_trade(iins_type_tradevan, 5, 2));  /* 260-261:�F�d�I�إN�� */

              fprintf(fptr,"%s\n",sPrtstr);
              cntrlrec++;

              printf("end this iclaim\n");

   }
   $CLOSE CUS62;
   $FREE CUS62;
   printf ("end_lStl_ins2 cntrlrec[%d]\n",cntrlrec);

   if (cntrlrec > 0)
   {
      $SELECT qcount
         INTO $qcount
         FROM TRADE_COUNT
        WHERE file_name = $Tmp1; if (SQLCODE == SQLNOTFOUND ) qcount=0;

      printf("Tmp1[%s] [%d] cntrlrec[%d]\n",Tmp1,qcount,cntrlrec);
      qcount += cntrlrec;

      $UPDATE TRADE_COUNT
          SET ( qcount, Tamount, Tinjure, Tcripple, Tdeath, Tastype ) =
              ( $qcount, $prem_total, $Tinjure, $Tcripple, $Tdeath, 'S' )
        WHERE file_name = $Tmp1;

      if ( sqlca.sqlerrd[2] == 0 )
      {
         printf("3834:policy_day[%d]\n", close_date);

         $INSERT INTO TRADE_COUNT
            ( file_name, policy_day, qcount, Tamount, Tinjure, Tcripple, Tdeath, Tastype )
          VALUES
            ( $Tmp1, $close_date, $qcount, $prem_total, $Tinjure, $Tcripple, $Tdeath, 'S' );
      }

      printf("Tmp1[%s] [%d]\n",Tmp1,qcount);

      strcpy(prtstr, sformat_trade("CNTRLREC", 4, 8));
      /* rfmtlong(qcount,"&&&&&&",cntrlrec_c); */
      sprintf_s(cntrlrec_c, sizeof cntrlrec_c, "%ld", qcount);
      strcat(prtstr, sformat_trade(cntrlrec_c, 5, 6));
      fprintf(fptr, "%s\n", prtstr);

   }
   else if ( cntrlrec == 0 )
   {
      printf("sDappraisal_bgn[%s]\n", sDappraisal_bgn);
      rstrdate( sDappraisal_bgn , &close_date );
      
      if (strcmp(option,"Y") == 0)
      {  /* �������v�� */
         $SELECT file_name , qcount
            INTO $Tmp1, $cntrlrec
            FROM TRADE_COUNT
           WHERE file_name like 'ISBM%h';
             
         if( SQLCODE == SQLNOTFOUND )
         {
            /* �L���M�B�L�w�M */
            strcpy( close_date_c , cm_cdate_str_100( close_date ));
   
            cm_split_ymd_100(close_date_c,day_yy,day_mm,day_dd);
   
            sprintf_s(Tmp1, sizeof Tmp1,"ISBM%s_2011h",companyid);
            strcpy(iply_type,opt);
            strcpy(fcard_class, "2");
   
            sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,trim(Tmp1));
   
            printf("file0[%s]\n",file0);
   
            fptr=fopen(file0,"w");

            printf("���v:policy_day[%s]\n", cm_cdate_str_100( close_date ));
   
            $INSERT INTO TRADE_COUNT
               ( policy_day, file_name, qcount, Tamount, Tinjure, Tcripple, Tdeath, Tastype )
             VALUES
               ( $close_date, $Tmp1,0,0,0,0,0, 'S');
            printf(" ++++++++++++++++++++++++++++++++++ \n");
            strcpy(prtstr, sformat_trade("CNTRLREC", 4, 8));
   
            /* rfmtlong(0,"&&&&&&",cntrlrec_c); */
            strcpy(cntrlrec_c, "0");
            strcat(prtstr, sformat_trade(cntrlrec_c, 5, 6));
            fprintf(fptr, "%s\n", prtstr);
   
         }
         else
         {
            /* �L�w�M�B�����M */
   
            $UPDATE TRADE_COUNT
                SET ( qcount, Tamount, Tinjure, Tcripple, Tdeath, Tastype ) =
                    ( $cntrlrec, 0, 0, 0, 0, 'S' )
              WHERE file_name = $Tmp1;
   
            strcpy( close_date_c , cm_cdate_str_100( close_date ));
   
            cm_split_ymd_100(close_date_c,day_yy,day_mm,day_dd);
            sprintf_s(Tmp1, sizeof Tmp1,"ISBM%s_2011h",companyid);
            strcpy(iply_type,opt);
            strcpy(fcard_class, "2");
   
            sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
   
            fptr=fopen(file0,"a+");
   
            strcpy(prtstr, sformat_trade("CNTRLREC", 4, 8));
            /* rfmtlong(cntrlrec,"&&&&&&",cntrlrec_c); */
            sprintf_s(cntrlrec_c, sizeof cntrlrec_c, "%ld", cntrlrec);
            strcat(prtstr, sformat_trade(cntrlrec_c, 5, 6));
            fprintf(fptr, "%s\n", prtstr);
   
            printf("file0[%s]  prtstr[%s]\n",file0, prtstr);
         }    
      }
      else
      {
         $SELECT file_name , qcount
            INTO $Tmp1, $cntrlrec
            FROM TRADE_COUNT
           WHERE policy_day = $close_date
             AND file_name like 'ISBM%v%';
             
         if( SQLCODE == SQLNOTFOUND )
         {
            /* �L���M�B�L�w�M */
            strcpy( close_date_c , cm_cdate_str_100( close_date ));
   
            cm_split_ymd_100(close_date_c,day_yy,day_mm,day_dd);
   
            sprintf_s(Tmp1, sizeof Tmp1,"ISBM%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);
            strcpy(iply_type,opt);
            strcpy(fcard_class, "2");
   
            sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,trim(Tmp1));
   
            printf("file0[%s]\n",file0);
   
            fptr=fopen(file0,"w");
   
            rc = check_if_exist(iply_type,close_date,fcard_class,0);
   
            if ( rc != M_CM_OK )
               return rc;
   
            printf("3954:policy_day[%d]\n", close_date);
   
            $INSERT INTO TRADE_COUNT
               ( policy_day, file_name, qcount, Tamount, Tinjure, Tcripple, Tdeath, Tastype )
             VALUES
               ( $close_date, $Tmp1,0,0,0,0,0, 'S');
   
            strcpy(prtstr, sformat_trade("CNTRLREC", 4, 8));
   
            /* rfmtlong(0,"&&&&&&",cntrlrec_c); */
            strcpy(cntrlrec_c, "0");
            strcat(prtstr, sformat_trade(cntrlrec_c, 5, 6));
            fprintf(fptr, "%s\n", prtstr);
   
         }
         else
         {
            /* �L�w�M�B�����M */
   
            $UPDATE TRADE_COUNT
                SET ( qcount, Tamount, Tinjure, Tcripple, Tdeath, Tastype ) =
                    ( $cntrlrec, 0, 0, 0, 0, 'S' )
              WHERE file_name = $Tmp1;
 
            printf("---------> Tmp1[%s]\n",Tmp1);
  
            strcpy( close_date_c , cm_cdate_str_100( close_date ));
   
            cm_split_ymd_100(close_date_c,day_yy,day_mm,day_dd);
            sprintf_s(Tmp1, sizeof Tmp1,"ISBM%s_%s%s%sv",companyid,day_yy,day_mm,day_dd);

            if (goption[0] == 'A' || goption[0] == 'B' || goption[0] == 'C')
            {
               strcat(Tmp1,"_");
               strcat(Tmp1,hhminsec);
            }

            strcpy(iply_type,opt);
            strcpy(fcard_class, "2");
   
            sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
   
            fptr=fopen(file0,"a+");
   
            rc = check_if_exist(iply_type,close_date,fcard_class,0);
            if ( rc != M_CM_OK )
               return rc;
   
            strcpy(prtstr, sformat_trade("CNTRLREC", 4, 8));
            /* rfmtlong(cntrlrec,"&&&&&&",cntrlrec_c); */
            sprintf_s(cntrlrec_c, sizeof cntrlrec_c, "%ld", cntrlrec);
            strcat(prtstr, sformat_trade(cntrlrec_c, 5, 6));
            fprintf(fptr, "%s\n", prtstr);
   
            printf("file0[%s]  prtstr[%s]\n",file0, prtstr);
         }             
      }
   }

   printf("### cntrlrec=[%s]\n",cntrlrec_c);

   fclose(fptr);

/*   rtncode = rptftpinsert( userid , "car9973" , Tmp1 ); */
/* ���F�ɨҰ���,���w��,�S���z�⪺��r���`���� modify by sylvia 101.03.27 */
   $DECLARE ca997v32 CURSOR FOR
      SELECT unique file_name, qcount, Tastype
        FROM TRADE_COUNT;
   $OPEN ca997v32;
   for(;;) 
   {
      $FETCH ca997v32 INTO $sfilename, $cntrlrec, $sTastype;

      if (SQLCODE == SQLNOTFOUND) break;
      strcpy(sfilename, rtrim(sfilename));
      printf("sfilename=[%s]Tmp1=[%s]cntrlrec=[%d]sTastype=[%s]\n",sfilename,Tmp1,cntrlrec, sTastype);
      /* �Y���t�����骺�϶�,���w���S�z��,�����w���ɮ׸ɤW�`����  modify by sylvia 101.03.27 */
      if ((strcmp(sfilename, Tmp1) != 0) && (strcmp(sTastype, "A") == 0))
      {
         sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,sfilename);
         printf("Tmp1=[%s] file0=[%s]\n",Tmp1,file0);
         fptr=fopen(file0,"a+");
         strcpy(prtstr, sformat_trade("CNTRLREC", 4, 8));
         sprintf_s(cntrlrec_c, sizeof cntrlrec_c, "%ld", cntrlrec);
         strcat(prtstr, sformat_trade(cntrlrec_c, 5, 6));
         fprintf(fptr, "%s\n", prtstr);
         printf("file0[%s]  prtstr[%s]\n",file0, prtstr);
         fclose(fptr);
      }
      rtncode = rptftpinsert( userid , "car9973" , sfilename );
      printf("rtncode[%d]\n",rtncode);
   }
   $CLOSE ca997v32;
   $FREE ca997v32;


   $SELECT policy_day, qcount, Tamount, Tinjure, Tcripple, Tdeath
         INTO $policy_day, $qcount, $Tamount, $Tinjure, $Tcripple, $Tdeath
         FROM TRADE_COUNT
        WHERE file_name = $Tmp1;

      if ( SQLCODE!=SQLNOTFOUND &&
            ( strcmp(option,"4") != 0 && strcmp(option,"5") != 0 ) &&
            (strcmp(option,"Y") != 0))
      /* �C��e�����, �Y����ca_tmp_no����ƫh����insert */
      {
         $insert into ca_trade_exam
            (iply_type,dpolicy,fcard_class,itrans_type,
             qcount,mamount,minjure,mcripple,mdeath)
          values
            ($iply_type,$policy_day,$fcard_class,0,
             $qcount,$Tamount,$Tinjure,$Tcripple,$Tdeath);
      }
      
      sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%d \n",file0,qcount);
      WRITELOG(errfpt , strlog);

   printf("errfpt[%s]\n",strlog);


   return(SUCCESS);

errexit:
   printf("car9973vol_lStl_ins:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   rc = SQLCODE;
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return rc;
}

char *get_inf_date(ssdate)
char *ssdate;
{
     char  sTmpDate[11];
     strcpy(sTmpDate,"");
     printf("ssdate[%s]\n",ssdate);
     strncat(sTmpDate,ssdate+5,2);
     sTmpDate[2] = '\0';
     strcat(sTmpDate,"/");

     strncat(sTmpDate,ssdate+8,2);
     sTmpDate[5] = '\0';
     strcat(sTmpDate,"/");

     strncat(sTmpDate,ssdate,4);
     sTmpDate[10] = '\0';

     printf("sTmpDate[%s]\n",sTmpDate);

     return sTmpDate;
}

void GetLostAppData()
{

char *bp;
char  filename[100];
char  filefull[200];
$char stmt[2048];
$char dwork[11];
$char yyyy[5];
$char yyy[4];
$char mm[3];
$char dd[3];
$char sDateTmp[11];
$char tiins_ply[3];
$char tiins_type[7];
$char tflag[2];
$char ticlaim[12];

FILE  *fp;
int   flen=0;
int   i=0,j=0,k=0;

int bp_len = 0;

   $WHENEVER SQLERROR GOTO errexit;

   printf("into GetLostAppData()\n");

   flen = 300;

   /*
   strcpy(DBName,"00");
   if (db_select(DBName) == FALSE) 
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }
   */

   sprintf_s(stmt, sizeof stmt,
    " select first 1 dwork   \
        from cm_wrktbl       \
       where dwork < '%s'    \
         and fwork = '0'     \
       order by dwork desc  ",sDappraisal_bgn); 
 
   printf("sDappraisal_bgn[%s]\n",sDappraisal_bgn);
 
   $prepare wrk_id from $stmt;
   $execute wrk_id 
       into $dwork;

   if (SQLCODE == SQLNOTFOUND)
   {
      strcpy(dwork,"");
      return(FALSE); 
   }
   strcpy(lastdwork,dwork);

   printf("SQLCODE[%d],dwork[%s]\n",SQLCODE,dwork);

   strncpy(mm,dwork,2);
   mm[2] = '\0';

   printf("mm[%s]\n",mm);

   strncpy(dd,dwork+3,2);
   dd[2] = '\0';

   printf("dd[%s]\n",dd);

   strncpy(yyyy,dwork+6,4);
   yyyy[4] = '\0';

   printf("yyyy[%s]\n",yyyy);

   strcpy(yyy,itoa( atoi(yyyy)-1911 ));

   printf("yyy[%s]\n",yyy);

   strcpy(sDateTmp,yyy);
   strcat(sDateTmp,mm);
   strcat(sDateTmp,dd);
 
   strcpy(filename,"insISBM17_");
   strcat(filename,sDateTmp);
   strcat(filename,"v");

   printf("filename[%s]\n",filename);

   sprintf_s(filefull, sizeof filefull,"%s/rptftp/%s",sApHome,filename);
   strcpy(filefulllast,filefull);
   
   printf("filefull[%s]\n",filefull);

   if ((fp=fopen(filefull,"r"))==NULL)
   {
       sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���\n",filefull);
       return(FALSE); 
   }

   if ((bp=malloc(flen))==NULL)
   {
       strcpy(msgbuf,"System malloc failed !\n");
       return(FALSE);
   }
 
   printf("filefull[%s]\n",filefull);


   $create temp table t997_temp
   (
      iclaim       char(20),
      iins_type    char(6),
      dappraisal   date
   )with no log;

   $create index t997_temp_ix1 on t997_temp(iclaim);


   j = 0; 
   k = 0;
   for(i=0;(feof(fp)==0);i++) 
   {
      memset(bp,0x00,flen);
      fgets(bp,flen,fp);
      if (bp[0]==0x00)
           break;
      printf("---------------flen[%d]\n---------------",flen);
      strcpy(bp,rtrim(bp));
      bp_len = strlen(bp);
      printf("---------------bp[%d]\n---------------",bp_len);
      memcpy(ticlaim,bp,11);
      ticlaim[11] = '\0';
      memset(tiins_type,' ',sizeof(tiins_type));
      memcpy(tiins_type,bp+12,(bp_len-13));
      tiins_type[4] = '\0';
      strcpy(tiins_type,trim(tiins_type));

      printf("ticlaim[%s],tiins_type[%s],dwork[%s]\n",ticlaim,tiins_type,dwork);
      $insert into t997_temp values ($ticlaim, $tiins_type, $dwork);
      itmpcnt++;
   }

   return(SUCCESS);

errexit:
   printf("car9973vol_GetLostAppData:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   rc = SQLCODE;
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return rc;
}
