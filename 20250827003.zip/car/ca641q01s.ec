/**********************************************************************/
/*   program id   : ca641q01s.ec                                      */
/*   program name : �妸�omail���@                                    */
/*   Temp table : car_mail_data                                       */
/*   create  table car_mail_data                                      */
/*        (content        text);                                      */
/*   date written : 2015/09/08                                        */
/*   temp table   : ca_mail, car_641                                  */
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <time.h>
#include <math.h>
#include "api_xsrv.h"
#include "safeclib.h"
$include datetime.h;

/*--------------------------------------------------------------------*/
$char itype[2], ddate[11], send_date[11], nproject[255], mail_text[2000],
      sContent[5000],sContentM[5000], pre_ileader[11], userid[11];
char  msgbuf[1000],sApHome[30];
$loc_t 	ctxt, ctxtM;
$char DBName[05], email[51], chinese_name[15], Porj_id[11], stmt[5000];
char  outputf[N_FILE+1] ;
DBinfo  *list;
int   count_db;
$char   fname[100],fnameM[100];
$char   nattachment[201];
$char   filename[150], filenameM[150];
$char	ftitle[1024], ftitleM[1024];
int     flen;
FILE    *fp;
$int mail_count, i, icount, sum_mail, mail_count_M;


/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;

    time_t tstart, tstop;
    float tused=0;

    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(ddate,   isNULLstr(argv[3]));    /* Email�o�e��� (CYY/MM/DD)*/
    strcpy(itype,   isNULLstr(argv[4]));    /* ����H: 1:�޲z�H  2:��D��  3:�޲z�H+��D�� */
    strcpy(outputf, isNULLstr(argv[5]));

    strcpy(send_date, cm_to_infdate(ddate));

    /***********************************************/
    time(&tstart);  /* �p�ɶ}�l */

    /***********************************************/
    printf("1.car641_get_db() \n");
    rc = car641_get_db();
    if (rc != M_CM_OK) {
        printf("error on car641_get_db\n");
        return rc;
    }

    printf("2.car641_init_data() \n");
    rc = car641_init_data();
    if (rc != M_CM_OK) {
        printf("error on car641_init_data\n");
        return rc;
    }

    strcpy(Porj_id,"CAR641");
    rc = car641_ply_data();
    if (rc != M_CM_OK) {
        printf("error on car641_ply_data()\n");
        return rc;
    }

    sum_mail = 0;
    if ((strcmp(itype,"1") == 0) || (strcmp(itype,"3") == 0))
    {
        /* �o�email���޲z�H */
        printf("4.car641_send_email() \n");
        rc=car641_send_email();
        if (rc != M_CM_OK) {
            printf("error on car641_send_email\n");
            return rc;
        }
    }
    
    if ((strcmp(itype,"2") == 0) || (strcmp(itype,"3") == 0))
    {
        /* �o�email����D�� */
        printf("5.car641_send_email_mgr() \n");
        rc=car641_send_email_mgr();
        if (rc != M_CM_OK) {
            printf("error on car641_send_email_mgr\n");
            return rc;
        }
    }
   

    /* �o�e���浲�G��mail���ϥΪ� (�Ƶ{�w�]��:�ӫO�� ���ɤ�(891510)) */
    printf("6.car641_final_email() \n");
    rc=car641_final_email();
    if (rc != M_CM_OK) {
        printf("error on car641_final_email\n");
        return rc;
    }

    /* �^������ƥi��cmn201�U�� */
    printf("7.car641_print() \n");
    rc=car641_print();
    if (rc != M_CM_OK) {
        printf("error on car641_print\n");
        return rc;
    }

    printf("[car641]:process ok!\n");
    /***********************************************/
        time(&tstop);  /* �p�ɵ��� */
        tused=difftime(tstop, tstart);
        printf("������� = %f  ��\n", tused);
    /***********************************************/

}

/*--------------------------------------------------------------------*/
long car641_get_db()
{
    int	rc;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
    }

    if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;

    }

    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }

    return M_CM_OK;
}
/*--------------------------------------------------------------------*/
long car641_init_data()
{
    $whenever sqlerror goto errexit;


    $create temp table tb_car641 (
        ipolicy         char(20),       -- �O�渹
        icard           char(20),       -- �d��
        iassured        char(10),       -- �Q�O�H�ע�
        nassured        varchar(40),    -- �Q�O�H�W��
        iengine         char(25),       -- ������
        itag            char(12),       -- ����
        icar_type       char(2),        -- ����
		dply_begin      date,           -- �_�O��
		dply_end        date,           -- ���O��
		dpolicy         date,           -- ñ���
        iofficer        char(10),       -- �g��N��
        ileader         char(10),       -- �޲z�H�N��
        iquota          char(10),       -- �~�Z���N��
        ileader_mgr     char(10),       -- �޲z�H����D��
        idays           int             -- �Ѽ�
    ) with no log;

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
/* �L���P�q��:1.���j���I�O�� 2.�����k�H�Φ۵M�H 3.�C�i�O�榳3���o��q�������|
    �Ĥ@���o�T��:��O��ͮĤ�+30����
    �ĤG���o�T��:��O��ͮĤ�+45����
    �ĤT���o�T��:��O������e100��
 */
long car641_ply_data()
{
    int	rc;
    $char   base_date[11];


    $whenever sqlerror goto errexit;

    printf("--- car641_ply_data start -------- \n");

    icount = 0;
    
    /* ���޲z�H:�C��check 
       ��1��:�O��ͮĤ�+30���� �� dply_begin = today-30
       ��2��:�O��ͮĤ�+45���� �� dply_begin = today-45
       ��3��:�O������-100���� �� dply_end = today+100
    */
    for (i=0; i<count_db; i++)
    {
        sprintf_s(stmt, sizeof stmt, 
            " insert into tb_car641  "
             "select a.ipolicy, a.icard, b.iassured,  "
             "      case when b.fassured in ('1','3','5') then b.nassured[1,2]||'�ݢ�' else b.nassured end,  "
             "      b.iengine, nvl(b.itag,' '), a.icar_type, a.dply_begin,  "
             "      a.dply_end, a.dpolicy, a.iofficer, c.ileader,  "
             "      (select d.iquota from officer d where d.iofficer = d.ileader  "
             "         and d.iofficer = c.ileader ), ' ', abs(today-a.dply_begin)  "
             " from %s:ply_relation a, %s:policy b, officer c, %s:ply_ins_type e  "
             "where a.ipolicy = b.ipolicy and a.iofficer  = c.iofficer  "
             "  and a.ipolicy = e.ipolicy  and a.fcard_class = '1'  "
             "  and a.icar_type not in ('01','02','32','34','35','27','51','T1','T2')  "
             "  and a.dpolicy is not null  and a.dply_close is not null  "
             "  and a.fedr_class <> '1'  and b.itag = ' ' and e.iins_type = '21'  "
             "  and e.mdamage_cover > 0  and a.dply_begin in (today-30,today-45)  "
             "  and a.dply_end > today", list[i].dbname, list[i].dbname, list[i].dbname);
        $prepare pre_ply_11 from $stmt;    
            
        sprintf_s(stmt, sizeof stmt, 
            " insert into tb_car641  "
            "select a.ipolicy, a.icard, b.iassured,  "
            "       case when b.fassured in ('1','3','5') then b.nassured[1,2]||'�ݢ�' else b.nassured end,  "
            "       b.iengine, nvl(b.itag,' '), a.icar_type, a.dply_begin,  "
            "       a.dply_end, a.dpolicy, a.iofficer, c.ileader,  "
            "       (select d.iquota from officer d where d.iofficer = d.ileader  "
            "           and d.iofficer = c.ileader ), ' ', abs(today-a.dply_end)  "
            " from %s:ply_relation a, %s:policy b, officer c, %s:ply_ins_type e  "
            " where a.ipolicy = b.ipolicy and a.iofficer  = c.iofficer  "
            "   and a.ipolicy = e.ipolicy  and a.fcard_class = '1'  "
            "   and a.icar_type not in ('01','02','32','34','35','27','51','T1','T2')  "
            "   and a.dpolicy is not null  and a.dply_close is not null  "
            "   and a.fedr_class <> '1'  and b.itag = ' ' and e.iins_type = '21'  "
            "   and e.mdamage_cover > 0  and a.dply_end = (today+100) ", 
                 list[i].dbname, list[i].dbname, list[i].dbname);
	    printf("stmt[%s]  \n",stmt);
	    $prepare pre_ply_12 from $stmt;        
	    
	    if ((strcmp(itype,"1") == 0)||(strcmp(itype,"3") == 0))
        {
            $execute pre_ply_11;
            $execute pre_ply_12;
        }
    }
    
    /* ����D��:�C�g�o�@�� 
       ��1��:dply_begin between (today-30) and (today-(30+7))
 	   ��2��:dply_begin between (today-45) and (today-(45+7))
	   ��3��:dply_end between (today+100) and (today+(100-7))
    */
    for (i=0; i<count_db; i++)
    {
        sprintf_s(stmt, sizeof stmt,
            "insert into tb_car641  "
            "select a.ipolicy, a.icard, b.iassured,  "
            "       case when b.fassured in ('1','3','5') then b.nassured[1,2]||'�ݢ�' else b.nassured end,  "
            "       b.iengine, nvl(b.itag,' '), a.icar_type, a.dply_begin,  "
            "       a.dply_end, a.dpolicy, a.iofficer, c.ileader,  "
            "       (select d.iquota from officer d where d.iofficer = d.ileader  "
            "          and d.iofficer = c.ileader ),  "
            "       (select resp_name from sa_branch_type g, personal:unitid2ef f, officer h  "
            "         where g.ibranch = f.code_no  and  g.dexpire is null  "
            "           and g.ibranch not in ('110100','110200')  "
            "           and g.ibranch = h.iquota and h.iofficer = c.ileader  "
            "           and h.iofficer = c.ileader), abs(today - a.dply_begin)  "
            "  from %s:ply_relation a, %s:policy b, officer c, %s:ply_ins_type e  "
            " where a.ipolicy = b.ipolicy and a.iofficer  = c.iofficer  "
            "   and a.ipolicy = e.ipolicy  and a.fcard_class = '1'  "
            "   and a.icar_type not in ('01','02','32','34','35','27','51','T1','T2')  "
            "   and a.dpolicy is not null  and a.dply_close is not null  "
            "   and a.fedr_class <> '1'  and b.itag = ' ' and e.iins_type = '21'  "
            "   and e.mdamage_cover > 0  and a.dply_end > today  "
            "   and a.dply_begin between (today-52) and (today-30)",
                list[i].dbname, list[i].dbname, list[i].dbname);
        
        $prepare pre_ply_21 from $stmt;
                
        sprintf_s(stmt, sizeof stmt,
            "insert into tb_car641  "
            " select a.ipolicy, a.icard, b.iassured,  "
            "        case when b.fassured in ('1','3','5') then b.nassured[1,2]||'�ݢ�' else b.nassured end,  "
            "        b.iengine, nvl(b.itag,' '), a.icar_type, a.dply_begin,  "
            "        a.dply_end, a.dpolicy, a.iofficer, c.ileader,  "
            "        (select d.iquota from officer d where d.iofficer = d.ileader  "
            "            and d.iofficer = c.ileader ),  "
            "        (select resp_name from sa_branch_type g, personal:unitid2ef f, officer h  "
            "          where g.ibranch = f.code_no  and  g.dexpire is null  "
            "            and g.ibranch not in ('110100','110200')  "
            "            and g.ibranch = h.iquota and h.iofficer = c.ileader  "
            "            and h.iofficer = c.ileader), abs(today - a.dply_end)  "
            "  from %s:ply_relation a, %s:policy b, officer c, %s:ply_ins_type e  "
            " where a.ipolicy = b.ipolicy and a.iofficer  = c.iofficer  "
            "   and a.ipolicy = e.ipolicy  and a.fcard_class = '1'  "
            "   and a.icar_type not in ('01','02','32','34','35','27','51','T1','T2')  "
            "   and a.dpolicy is not null  and a.dply_close is not null  "
            "   and a.fedr_class <> '1'  and b.itag = ' ' and e.iins_type = '21'  "
            "   and e.mdamage_cover > 0  and a.dply_end between (today+93) and (today+100); ",
                list[i].dbname, list[i].dbname, list[i].dbname);

	    printf("stmt[%s]  \n",stmt);
	    $prepare pre_ply_22 from $stmt;
	    
	    if ((strcmp(itype,"2") == 0)||(strcmp(itype,"3") == 0))
        {
            $execute pre_ply_21;
            $execute pre_ply_22;
        }
    }

    /* if (strcmp(itype,"1") == 0)
    {
        $execute pre_ply_11;
        $execute pre_ply_12;
    }
    else if (strcmp(itype,"2") == 0)
    {
        $execute pre_ply_21;
        $execute pre_ply_22;
    }
    else
    {
        $execute pre_ply_11;
        $execute pre_ply_12;
        $execute pre_ply_21;
        $execute pre_ply_22;
    } */

    $select count(*) into $icount
        from tb_car641 ;

    printf("�@ %d ��\n",icount);

	return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* -------------------------------------------------------------------------------- */
long car641_send_email()
{
	int	rc;

	$char ipolicy[21],iassured[10], nassured[30], dply_begin[11], dply_end[11],
		  dpolicy[11], iengine[CA_ENGINE_NUM], icar_type[4], iofficer[12], nofficer[11],
		  nbranch[11], ileader[12], nleader[11], mark1[100] ;
    $int  idays = 0;
    $char yy[4],mm[3],dd[3];

	$whenever sqlerror goto errexit;

    /* mail�D�� */
    strcpy(nproject,"�j���I�O��L���P����");
    
    /* mail���e */
    sprintf_s(sContent, sizeof sContent,"%s %s %s %s",
        "�z�n�A</P>\n",
        "����O�Ҹg��j���I�~�Ȥ��|����J���P���~��,���קK�]�L���P��ƭP�j�~�j���I��O�O�O���~,</P>\n",
        "�кɳt�V���D�γq���d�ߨ��P��ƫ��[�ɤW�C</P></P>\n",
        "�@�@�@�@�@�@�ӫO���~�Ȧ�F��@�q�� </P></P>\n");
    
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = sContent;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(sContent) + 1;
    
    /* ���Y */
    strcpy(ftitle,
        "�O�渹,�Q�O�HID,�Q�O�H�W��,�_�O��,���O��,ñ���,������,����,�g��N��, "
        "�g��W��,�~�Z���W��,�޲z�H�N��,�޲z�H�W��,�Ƶ�\n");
    
	cm_split_ymd_100(ddate,yy,mm,dd);
	printf("yy=[%s], mm=[%s], dd=[%s] \n",yy,mm,dd);

	strcpy(stmt,
        "select a.ipolicy, a.iassured, a.nassured, a.dply_begin, a.dply_end, "
		"	    a.dpolicy, a.iengine, ''||a.icar_type, ''||a.iofficer, b.nname,  "
		"       d.nbranch, ''||a.ileader, c.nname, a.idays  "
        "  from tb_car641 a, officer b, officer c, sa_branch_type d  "
	    " where a.iofficer = b.iofficer and a.ileader = c.iofficer  "
	    "   and c.iofficer = c.ileader and a.iquota = d.ibranch  "
	    "   and a.idays in ('30','45','100')  "
	    "   and a.ileader_mgr = ' '  and a.ileader = ?  order by ipolicy;");

    printf("stmt[%s]\n",stmt);
    $prepare pre_dtl from $stmt;
    $declare cur_dtl cursor for pre_dtl;

    $declare cur_temp cursor for
      select distinct ileader
		into $ileader
		from tb_car641
	   where ileader_mgr = ' '
       order by ileader;
    $open cur_temp;
    $fetch cur_temp;

    strcpy(pre_ileader,ileader);

    mail_count=0;
    while(1)
    {
	    if (SQLCODE==SQLNOTFOUND) break;

		if (strcmp(ileader,pre_ileader)!=0)
		{
	        rc = car641_write_email();
	    	if (rc!=M_CM_OK) {
					printf("error on car641_write_email\n");
					return rc;
	    	}
	    	mail_count=0;
	    	sum_mail++;

		}

		strcpy(pre_ileader,ileader);
        mail_count++;

		/* printf("ileader[%s]\n",ileader); */

		memset(fname,0x00,sizeof(fname));
		memset(nattachment,0x00,sizeof(nattachment));
		memset(filename,0x00,sizeof(filename));

		sprintf_s(fname, sizeof fname,"%s%s%s_�j���I���P�ť�_%s",yy,mm,dd,trim(ileader));
		sprintf_s(nattachment, sizeof nattachment,"%s%s%s_�j���I���P�ť�_%s.csv",yy,mm,dd,trim(ileader));
		sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);

		/* printf("filename[%s]\n",filename); */
		fp=fopen(filename,"w");

		fprintf(fp,ftitle);

		$open cur_dtl using $ileader;

		while(1)
		{
		    $fetch cur_dtl
		      into $ipolicy, $iassured, $nassured, $dply_begin, $dply_end,
		           $dpolicy, $iengine, $icar_type, $iofficer, $nofficer,
		           $nbranch, $ileader, $nleader, $idays;
		    if (SQLCODE==SQLNOTFOUND) break;
		    
		    if (idays == 30)
		        strcpy(mark1,"��1���q��:�O��ͮĤ��30��");
		    else if(idays == 45)
		        strcpy(mark1,"��2���q��:�O��ͮĤ��45��");
		    else if(idays == 100)
		        strcpy(mark1,"��3���q��:�O������e100��");
		    else
                strcpy(mark1," ");
                
		    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
		                ipolicy, iassured, nassured, dply_begin, dply_end,
		                dpolicy, iengine, icar_type, iofficer, nofficer,
		                nbranch, ileader, nleader, mark1);
		        printf("idays=[%d]mark1=[%s]\n",idays,mark1);

        }

        $close cur_dtl;

		fclose(fp);

		$fetch cur_temp;
    }
    $free  cur_dtl;
    $close cur_temp;
    $free  cur_temp;

    if (mail_count!=0)
    {
        rc = car641_write_email();
        if (rc!=M_CM_OK) {
		    printf("error on car641_write_email\n");
			return rc;
		}
        sum_mail++;
    }

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/* ------------------------------------------------------------------------- */
long car641_write_email()
{
    $int  icount2;

    $whenever sqlerror goto errexit;

    $select email,chinese_name
       into $email,$chinese_name
       from personal:asempl
      where empl_no = $pre_ileader;

    strcpy(email,trim(email));
    strcat(email,"@tmnewa.com.tw");
    /* printf("email[%s]\n",email);
    
        printf("506:Porj_id=[%s]send_date=[%s]email=[%s]\n",Porj_id,send_date,email);
        printf("chinese_name=[%s]fname=[%s]mail_count=[%s]nproject=[%s]\n",chinese_name,fname,mail_count,nproject); */

    icount2 = 0;

    $select count(*) into $icount2 from batchemail
      where project_id = $Porj_id
        and mail_date = $send_date
        and receiver_email = $email
        and receiver_name = $chinese_name
        and key = $fname
        and mail_count = $mail_count
        and nsubject = $nproject;

    if (icount2 > 0)
    {
        $delete from batchemail
          where project_id = $Porj_id
            and mail_date = $send_date
            and receiver_email = $email
            and receiver_name = $chinese_name
            and key = $fname
            and mail_count = $mail_count
            and nsubject = $nproject;
            
    }


    $INSERT INTO batchemail
		(project_id, mail_date, receiver_email, receiver_name, cc,
		 content, key, mail_count, nsubject, nattachment)
     VALUES
		($Porj_id, $send_date, $email, $chinese_name, " ",
		 $ctxt, $fname, $mail_count, $nproject, $nattachment);

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car641_final_email()
{
    $char mmsg[1000];
    $int icount3;

    $whenever sqlerror goto errexit;

    $select email,chinese_name
       into $email,$chinese_name
       from personal:asempl
      where empl_no = $userid;

    strcpy(email,trim(email));
    strcat(email,"@tmnewa.com.tw");
    /* printf("email[%s]\n",email); */
    
    
    if (strcmp(itype,"1") == 0)
    {
        $select count(*) into $mail_count_M
           from tb_car641
          where ileader_mgr = ' ';
        
        /* mail�D�� */  
        strcpy(nproject,"�j���I�O��L���P����(�޲z�H_����)");   
        
        
        sprintf_s(mmsg, sizeof mmsg,"�L�������j���I�O����ӧ妸email�q���̷s�޲z�H�@�~�w���槹���A</P>\n "
     	�@�@	     "�ԲӸ�ƽжi���I�t��cmn201�d��(car6411)�C</P>\n",mail_count_M);
    }
    else if (strcmp(itype,"2") == 0)
    {
        $select count(*) into $mail_count_M
           from tb_car641
          where ileader_mgr <> ' '
            and (idays <= 37  or idays >= 45) ;
        
        /* mail�D�� */    
        strcpy(nproject,"�j���I�O��L���P����(��D��_����)");
        
        /* mail���e */
        sprintf_s(mmsg, sizeof mmsg,"�L�������j���I�O����ӧ妸email�q����D�ާ@�~�w���槹���A</P>\n "
     	�@�@	     "�ԲӸ�ƽжi���I�t��cmn201�d��(car6411)�C</P>\n",mail_count_M);
    }
    else 
    {
        $select count(*) into $mail_count_M
           from tb_car641
         where 1=1;
        
        /* mail�D�� */    
        strcpy(nproject,"�j���I�O��L���P����(�޲z�H+��D��_����)");
        
        /* mail���e */
        sprintf_s(mmsg, sizeof mmsg,"�L�������j���I�O����ӧ妸email�w�U�O�q���޲z�H�ά�D�ޡA</P>\n "
     	�@�@	     "�ԲӸ�ƽжi���I�t��cmn201�d��(car6411)�C</P>\n",mail_count_M);
     	
    }
    
    /* mail���e */
    

    strcpy(mmsg,rtrim(mmsg));
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mmsg;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mmsg) + 1;


    icount3 = 0;

    $select count(*) into $icount3 from batchemail
      where project_id = $Porj_id
        and mail_date = $send_date
        and receiver_email = $email
        and receiver_name = $chinese_name
        and mail_count = 0
        and nsubject = $nproject;

    if (icount3 > 0)
    {
        $delete from batchemail
          where project_id = $Porj_id
            and mail_date = $send_date
            and receiver_email = $email
            and receiver_name = $chinese_name
            and mail_count = 0
            and nsubject = $nproject;
    }

    $INSERT INTO batchemail
		(project_id, mail_date, receiver_email,	receiver_name, cc,
		 content, key, mail_count, nsubject)
     VALUES
		($Porj_id, $send_date, $email, $chinese_name, " ",
		 $ctxt, " ", 0, $nproject);


    sum_mail++;

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car641_print()
{
    int     rc, icount;
    char    sfilename[100],stitle[1024],stmt2[8000];
    $char   stmt[2000], tmp_mark[300],tmp_days[300];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"car641�妸�o�eEmail(�t�Ȥ����h)");
    strcpy(stitle,"�{���N��:CAR6411");


    strcpy(sfilename,"���P�ť�email����");
    strcpy(stitle,"�{���N��:CAR6411\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t\t\t\t\t\t\t\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(sfilename,"[CAR6411]");


    strcat(stitle,"\t�O�渹\t�Q�O�HID\t�Q�O�H�W��\t�_�O��\t���O��\t");
    strcat(stitle,"ñ���\t������\t����\t�g��N��\t�g��W��\t�~�Z���W��\t");
    strcat(stitle,"�޲z�H�N��\t �޲z�H�W��\t �Ƶ�\t ��D��\t");

    if (strcmp(itype,"1") == 0)
    {
        /* �޲z�H */
        strcpy(tmp_mark,"case when idays = 30 then '��1���q��:�O��ͮĤ��30��'  "
		    "            when idays = 45 then '��2���q��:�O��ͮĤ��45��'  "
		    "            when idays = 100 then '��3���q��:�O������e100��' else ' ' end ");
	    strcpy(tmp_days," and idays in ('30','45','100') and ileader_mgr = ' ' ");
	    /* printf("688:tmp_mark=[%s]tmp_days=[%s]\n",tmp_mark,tmp_days); */
	    
    }
    else if (strcmp(itype,"2") == 0)
    {
        /* ��D�� */
        strcpy(tmp_mark,"' ' ");
        strcpy(tmp_days," and (idays <=37 or idays >= 45) and ileader_mgr <> ' ' ");
        /* printf("697:tmp_mark=[%s]tmp_days=[%s]\n",tmp_mark,tmp_days); */
    }
    else
    {
        /* �޲z�H+��D�� */
        strcpy(tmp_mark,"case when a.ileader_mgr = ' ' then   "
                        "     case when idays = 30 then '��1���q��:�O��ͮĤ��30��'  "
                        "          when idays = 45 then '��2���q��:�O��ͮĤ��45��'  "
                        "          when idays = 100 then '��3���q��:�O������e100��' else ' ' end   "
                        "else ' ' end ");
		strcpy(tmp_days," and (idays <=37 or idays >= 45) ");
	    /* printf("709:tmp_mark=[%s]tmp_days=[%s]\n",tmp_mark,tmp_days); */
    }
    
    
    sprintf_s(stmt2, sizeof stmt2,
	        "select a.ipolicy, a.iassured, a.nassured, a.dply_begin, a.dply_end, "
		    "	    a.dpolicy, a.iengine, ''||a.icar_type, ''||a.iofficer, b.nname,  "
		    "      d.nbranch, ''||a.ileader, c.nname, %s , ''||a.ileader_mgr   "
            " from tb_car641 a, officer b, officer c, sa_branch_type d  "
	        "where a.iofficer = b.iofficer and a.ileader = c.iofficer   "
	        "  and c.iofficer = c.ileader and a.iquota = d.ibranch %s  "
	        "  order by a.ileader_mgr, a.ileader, a.iofficer, a.iengine, a.ipolicy;",
	           tmp_mark,tmp_days);

    rc = unload_file(outputf," ",sfilename,stitle,stmt2);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
errexit:
    sqlfatal();
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

/* �o�eemail����D�� */
long car641_send_email_mgr()
{
	int	rc;

	$char ipolicy[21],iassured[10], nassured[30], dply_begin[11], dply_end[11],
		  dpolicy[11], iengine[CA_ENGINE_NUM], icar_type[4], iofficer[12], nofficer[11],
		  nbranch[11], ileader[12], nleader[11], mark1[100], ileader_mgr[11] ;
    $int  idays;
    $char yy[4],mm[3],dd[3];

	$whenever sqlerror goto errexit;
	
	
	/* mail�D�� */
    strcpy(nproject,"�j���I�O��L���P����(��)");
	
	sprintf_s(sContent, sizeof sContent,"%s %s %s",
        "�����H�󬰨t�Φ۰ʵo�X�A�ФŪ����^�H�A�Y�������ðݥi�q���ӤH�O�I���C</P>\n",
        "�������Ƭ��L�������j���I�O����ӡA���קK�]�L���P��ƭP�j�~�j���I��O�O�O���~�A�󪾷|�O��̷s�g��N���޲z�H�A�@�ֶg���U��D�ޡA�ѱz�Ѱu</P></P>\n",
        "�@�@�@�@�@�@�ӫO���~�Ȧ�F��@�@�q�� </P></P>\n");
	

    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = sContent;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(sContent) + 1;
	
	/* ���Y */
    strcpy(ftitle,
        "�O�渹,�Q�O�HID,�Q�O�H�W��,�_�O��,���O��,ñ���,������,����,�g��N��, "
        "�g��W��,�~�Z���W��,�޲z�H�N��,�޲z�H�W��\n");
        
        
    cm_split_ymd_100(ddate,yy,mm,dd);
	printf("yy=[%s], mm=[%s], dd=[%s] \n",yy,mm,dd);    
	
	sprintf_s(stmt, sizeof stmt, 
        "select a.ipolicy, a.iassured, a.nassured, a.dply_begin, a.dply_end, "
		"	    a.dpolicy, a.iengine, ''||a.icar_type, ''||a.iofficer, b.nname,  "
		"       d.nbranch, ''||a.ileader, c.nname, a.idays  "
        "  from tb_car641 a, officer b, officer c, sa_branch_type d  "
	    " where a.iofficer = b.iofficer and a.ileader = c.iofficer  "
	    "   and c.iofficer = c.ileader and a.iquota = d.ibranch  "
	    "   and (a.idays <= 37 or a.idays >= 45) and ileader_mgr <> ' '  "
	    "   and a.ileader_mgr = ?  order by a.ileader, a.ipolicy;");
    printf("stmt[%s]\n",stmt);
    $prepare pre_mgr_dtl from $stmt;
    $declare cur_mgr_dtl cursor for pre_mgr_dtl;
	
    $declare cur_mgr_temp cursor for
        select distinct ileader_mgr
		  into $ileader_mgr
	  	  from tb_car641
		 where ileader_mgr <> ''
		   and (idays <= 37 or idays >= 45) 
         order by ileader_mgr;
    $open cur_mgr_temp; 
    $fetch cur_mgr_temp;

    strcpy(pre_ileader,ileader_mgr);
    
    mail_count_M=0;
    while(1) 
    {
	    if (SQLCODE==SQLNOTFOUND) break;

		if (strcmp(ileader_mgr,pre_ileader)!=0) {
	        rc = car641_write_email();
	        if (rc!=M_CM_OK) {
		        printf("error on car641_write_email\n");
				return rc;
            }
	        mail_count_M=0;
        }
		strcpy(pre_ileader,ileader_mgr);
	
        
		printf("��D��ileader[%s]\n",ileader_mgr);
		memset(fname,0x00,sizeof(fname));
		memset(nattachment,0x00,sizeof(nattachment));
		memset(filename,0x00,sizeof(filename));
			
		sprintf_s(fname, sizeof fname,"%s%s%s_�j���I���P�ť�_M%s",yy,mm,dd,trim(ileader_mgr));
		sprintf_s(nattachment, sizeof nattachment,"%s%s%s_�j���I���P�ť�_M%s.csv",yy,mm,dd,trim(ileader_mgr));
		sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
		printf("filename[%s]\n",filename);
		fp=fopen(filename,"w");
		
		fprintf(fp,ftitle);
			
		$open cur_mgr_dtl using $ileader_mgr;
	
		while(1) {
		    $fetch cur_mgr_dtl
		      into $ipolicy, $iassured, $nassured, $dply_begin, $dply_end,
		           $dpolicy, $iengine, $icar_type, $iofficer, $nofficer,
		           $nbranch, $ileader, $nleader, $idays;
		    if (SQLCODE==SQLNOTFOUND) break;
		    
		    mail_count_M++;    
		    fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
		                ipolicy, iassured, nassured, dply_begin, dply_end,
		                dpolicy, iengine, icar_type, iofficer, nofficer,
		                nbranch, ileader, nleader);
        }
		$close cur_mgr_dtl;
		fclose(fp);
		$fetch cur_mgr_temp;
    }
    $free  cur_mgr_dtl;
    $close cur_mgr_temp;
    $free  cur_mgr_temp;
	    
    if (mail_count_M!=0) {
        rc = car641_write_email();
        if (rc!=M_CM_OK) {
            printf("error on car641_write_email\n");
			return rc;
        }
    }
           
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}