/************************************************/
/*                                              */
/*   PROGRAM : ca158p01s.ec                     */
/*   PURPOSE : �ƫ�浧�ĳq�]�w                 */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
$include sqlca;
$include decimal;
#include "safeclib.h"

long car158(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car158_single_query(),car158_update_exec(),car158_single_query_log();
 long car158_multiple_query();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'M':
           rtncode=car158_multiple_query(reply);
           break;
  case 'Q':
	   rtncode=car158_single_query(reply);
	   break;
  case 'q':
	   rtncode=car158_single_query_log(reply);
	   break;
  case 'P':
	   rtncode=car158_update_exec(reply,command,com_len);
	   break;
  default :
	   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
	    return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

/*******************************************************************/
long car158_multiple_query(reply)
serverReply reply;
{
 $char DBName[3];

 $char type1[2],ply_edr_type[2],fpass[21];
 $char ipre_rcv[21],iins_kind[2],ipre_end[21],ftype_pol[3],ftype_sp[3],iupdate[7];
 $char ply_edr[21],dupdate_bgn1[11],dupdate_end1[11],dupdate_bgn[11],dupdate_end[11];
 $char tmp_fpass[21];
 $char sWhere[256];
 char  tmpbuf[4000],stmt_receive[200];
 int   count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int   i,total_count=0;
 char  tIpolicy1[POLICY_NUM_1] , tIpolicy2[POLICY_NUM_2];
 int   flag=0;
 $char stmt[1000];
 int   rc;


 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s %s %s %s %s ",type1,ply_edr_type,ply_edr,iupdate,dupdate_bgn1,dupdate_end1);

 if (db_select(DBName) == False) {
     if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
        return M_CM_DB_NOTOPEN;
     else
        return apiRC;
 }
 	
 	if (strcmp(trim(type1),"1") == 0)
 	{
 		if( strcmp(trim(ply_edr_type),"1") == 0)
 		{
 			split_policy(ply_edr, tIpolicy1, tIpolicy2);
            		sprintf_s( sWhere, sizeof sWhere, " and a.ipolicy1 = '%s' and a.ipolicy2 = '%s'",tIpolicy1,tIpolicy2);
            	}
        	else
            		sprintf_s( sWhere, sizeof sWhere, " and a.iendorse = '%s' ",ply_edr);
 	}
 	else
 	{
 		strcpy(dupdate_bgn,cm_to_infdate(dupdate_bgn1));
   		strcpy(dupdate_end,cm_to_infdate(dupdate_end1));
   		sprintf_s( sWhere, sizeof sWhere, " and b.iupdate = '%s' and date(b.dupdate) between '%s' and '%s' ",iupdate,dupdate_bgn,dupdate_end);
 	}
	

printf("dupdate_bgn=[%s]dupdate_end[%s]\n",dupdate_bgn,dupdate_end);
printf("sWhere=[%s]\n",sWhere);

	 sprintf_s(stmt, sizeof stmt, 
  		"select b.ipre_rcv,b.iins_kind ,b.ipre_end,b.ftype_pol,b.ftype_sp,b.iupdate "
                " from cm_pre_receive a,ca_permit_after_log b "
                " where a.ipre_rcv = b.ipre_rcv   "
                "  and a.iins_kind = b.iins_kind "
                "  and a.ipre_end = b.ipre_end %s ",sWhere);

printf("stmt[%s]\n", stmt);

 	$PREPARE CUR_CAID FROM $stmt;
   	$DECLARE IDcur CURSOR FOR CUR_CAID;
   	$OPEN IDcur;
   	

   for(;;)
   {

     	$FETCH IDcur INTO $ipre_rcv,$iins_kind,$ipre_end,$ftype_pol,$ftype_sp,$iupdate;

     if (SQLCODE != 0) break;

     cm_buf_init(tmpbuf);

     if ( count == 0 )
     {
       cm_buf_res_msg();             /* reserve for MsgCode and count */
       cm_buf_res_count();
     }



     cm_buf_put("%s %s %s %s %s %s ", ipre_rcv,iins_kind,ipre_end,ftype_pol,ftype_sp,iupdate);
     tmp_len = cm_buf_len(tmpbuf);
     if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
       memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
       repbuf_len += tmp_len;
       count++;
     }
     else                               /* more than 4K, send to client side */
     {
       cm_buf_init(ReplyBuf);
       cm_buf_put_msg(M_CM_OK);
       cm_buf_put_count(count);
       if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
         $CLOSE IDcur;
         return apiRC;
       }
       else               /* clear ReplyBuf and count to start all over again */
       {
         replycnt++;
         if (replycnt == 10)   /* more than 30K, client cannot display,error */
         {
           cm_buf_init(ReplyBuf);
           cm_buf_put("%l",M_CM_OUT_SPACE);
           tmp_len = cm_buf_len(ReplyBuf);
           if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
               return apiRC;
           return M_CM_OUT_SPACE;
         }
         ReplyBuf[0] = '\0';
         count = 0;
         cm_buf_init(ReplyBuf);
         cm_buf_res_msg();           /* reserve for MsgCode and count */
         cm_buf_res_count();
         cm_buf_put("%s %s %s %s %s %s ", ipre_rcv,iins_kind,ipre_end,ftype_pol,ftype_sp,iupdate);
         repbuf_len = cm_buf_len(ReplyBuf);
         count++;
       }
     }
  } /* for loop */

  $CLOSE IDcur;
  if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
  else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }


errexit:
  if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
  else
     return apiRC;
}


/***********************************************************************/
long car158_single_query(reply)
serverReply reply;
{
 $char DBName[3];
 char  tmpbuf[4000];
 int   count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int   i,total_count=0;
 $char userid[11],ipolicy[25],iendorse[21],ipolicy1[21],ipolicy2[6];
 $char option1[2];
 $char tmp_ipolicy1[21],tmp_ipolicy2[6],tmp_iendorse[21],tmp_icard[21],tmp_ipre_rcv[21],tmp_ftype_pol[3],tmp_paydate[11],tmp_ftype_sp[3];
 $char tmp_iins_kind[2],tmp_iins_kind_ply[3],tmp_iassured[11],tmp_nassured[41],tmp_iapplicant[11],tmp_napplicant[41];
 $char tmp_itag[CA_TAG_NUM],tmp_iengine[CA_ENGINE_NUM],tmp_deffect[11],tmp_iedr_return[20],tmp_iofficer[11],tmp_ileader[11];
 $char tmp_iroute[21],tmp_iroute_main[13],tmp_ientry[11],tmp_dentry[11],tmp_dbegin[11],tmp_dend[11],tmp_ipre_end[21],pass_dentry[11];
 $char dpolicy[11],nequipment[31],equipdecode[2],croute[21],dexpire[11],icreate[11],fprint_note[2];
 $int  tmp_mprem = 0;
 int   flag=0;
 $char stmt[1000];
 $char Full_DBName[31];
 int   rc;

  cm_buf_get("%s %s %s %s %s",DBName,userid,option1,ipolicy,iendorse);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
     if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
       return M_CM_DB_NOTOPEN;
     else
       return apiRC;
  }

  if (strcmp(trim(option1),"1") == 0)
  {
  	strncpy(ipolicy1,trim(ipolicy),CAR_POLICY_LEN);
  	ipolicy1[CAR_POLICY_LEN]=0;
  	strcpy(ipolicy2,&ipolicy[CAR_POLICY_LEN]);

printf("[%s][%s]\n",ipolicy1,ipolicy2);


         if( strcmp(ipolicy2,"") != 0)
         {
printf("ipolicy2!=''\n");
            $SELECT ipolicy1,ipolicy2,iendorse,icard,ipre_rcv,ftype_pol,nvl(year(paydate)-1911||to_char(paydate,'/%m/%d'),''),ftype_sp,iins_kind,iins_kind_ply,iassured,
                    nassured,iapplicant,napplicant,itag,iengine,nvl(year(deffect)-1911||to_char(deffect,'/%m/%d'),''),
                    CASE WHEN iedr_return='1' THEN '�Ȥ�˿�' WHEN iedr_return = '2' THEN '�z�L�O�N' ELSE '�䥦' END ,
                    mprem,iofficer,ileader,iroute,(SELECT iroute_main FROM cm_route WHERE iroute = a.iroute),ientry,nvl(year(dentry)-1911||to_char(dentry,'/%m/%d'),''),
                    nvl(year(dbegin)||to_char(dbegin,'/%m/%d'),''),nvl(year(dend)-1911||to_char(dend,'/%m/%d'),''),ipre_end,fprint_note
               INTO $tmp_ipolicy1,$tmp_ipolicy2,$tmp_iendorse,$tmp_icard,$tmp_ipre_rcv,$tmp_ftype_pol,$tmp_paydate,$tmp_ftype_sp,$tmp_iins_kind,$tmp_iins_kind_ply,$tmp_iassured,
                    $tmp_nassured,$tmp_iapplicant,$tmp_napplicant,$tmp_itag,$tmp_iengine,$tmp_deffect,$tmp_iedr_return,$tmp_mprem,$tmp_iofficer,$tmp_ileader,$tmp_iroute,$tmp_iroute_main,$tmp_ientry,
                    $tmp_dentry,$tmp_dbegin,$tmp_dend,$tmp_ipre_end,$fprint_note
               FROM cm_pre_receive a
              WHERE iendorse = ' '
                AND iins_cat = 'C'
                AND ipolicy1 = $ipolicy1
                AND ipolicy2 = $ipolicy2
                AND ipre_end = '';
         }
         else
         {
printf("ipolciy2=''\n");
            $SELECT ipolicy1,ipolicy2,iendorse,icard,ipre_rcv,ftype_pol,nvl(year(paydate)-1911||to_char(paydate,'/%m/%d'),''),ftype_sp,iins_kind,iins_kind_ply,iassured,
                    nassured,iapplicant,napplicant,itag,iengine,nvl(year(deffect)-1911||to_char(deffect,'/%m/%d'),''),
                    CASE WHEN iedr_return='1' THEN '�Ȥ�˿�' WHEN iedr_return = '2' THEN '�z�L�O�N' ELSE '�䥦' END ,
                    mprem,iofficer,ileader,iroute,(SELECT iroute_main FROM cm_route WHERE iroute = a.iroute),ientry,nvl(year(dentry)-1911||to_char(dentry,'/%m/%d'),''),
                    nvl(year(dbegin)||to_char(dbegin,'/%m/%d'),''),nvl(year(dend)-1911||to_char(dend,'/%m/%d'),''),ipre_end,fprint_note
               INTO $tmp_ipolicy1,$tmp_ipolicy2,$tmp_iendorse,$tmp_icard,$tmp_ipre_rcv,$tmp_ftype_pol,$tmp_paydate,$tmp_ftype_sp,$tmp_iins_kind,$tmp_iins_kind_ply,$tmp_iassured,
                    $tmp_nassured,$tmp_iapplicant,$tmp_napplicant,$tmp_itag,$tmp_iengine,$tmp_deffect,$tmp_iedr_return,$tmp_mprem,$tmp_iofficer,$tmp_ileader,$tmp_iroute,$tmp_iroute_main,$tmp_ientry,
                    $tmp_dentry,$tmp_dbegin,$tmp_dend,$tmp_ipre_end,$fprint_note
               FROM cm_pre_receive a
              WHERE iendorse = ' '
                AND iins_cat = 'C'
                AND ipolicy1 = $ipolicy1
                AND ipre_end = '';
         }

   }
   else
   {

   	strcpy(iendorse,trim(iendorse));

   	    $SELECT ipolicy1,ipolicy2,iendorse,icard,ipre_rcv,ftype_pol,nvl(year(paydate)-1911||to_char(paydate,'/%m/%d'),''),ftype_sp,iins_kind,iins_kind_ply,iassured,
                    nassured,iapplicant,napplicant,itag,iengine,nvl(year(deffect)-1911||to_char(deffect,'/%m/%d'),''),
                    CASE WHEN iedr_return='1' THEN '�Ȥ�˿�' WHEN iedr_return = '2' THEN '�z�L�O�N' ELSE '�䥦' END ,
                    mprem,iofficer,ileader,iroute,(SELECT iroute_main FROM cm_route WHERE iroute = a.iroute),ientry,nvl(year(dentry)-1911||to_char(dentry,'/%m/%d'),''),
                    nvl(year(dbegin)||to_char(dbegin,'/%m/%d'),''),nvl(year(dend)-1911||to_char(dend,'/%m/%d'),''),ipre_end,fprint_note
               INTO $tmp_ipolicy1,$tmp_ipolicy2,$tmp_iendorse,$tmp_icard,$tmp_ipre_rcv,$tmp_ftype_pol,$tmp_paydate,$tmp_ftype_sp,$tmp_iins_kind,$tmp_iins_kind_ply,$tmp_iassured,
                    $tmp_nassured,$tmp_iapplicant,$tmp_napplicant,$tmp_itag,$tmp_iengine,$tmp_deffect,$tmp_iedr_return,$tmp_mprem,$tmp_iofficer,$tmp_ileader,$tmp_iroute,$tmp_iroute_main,$tmp_ientry,
                    $tmp_dentry,$tmp_dbegin,$tmp_dend,$tmp_ipre_end,$fprint_note
               FROM cm_pre_receive a
              WHERE iins_cat = 'C'
                AND iendorse = $iendorse
                AND ipre_end = '';
   }



  if(SQLCODE==SQLNOTFOUND)
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }

    /*ú�O���*/
    $select year(dentry)||to_char(dentry,'/%m/%d')
       into $pass_dentry
       from ao_prercv_pass
      where ipre_rcv = $tmp_ipre_rcv
        and iins_kind = $tmp_iins_kind
	and ipre_end = $tmp_ipre_end ;

    if(SQLCODE==SQLNOTFOUND) strcpy(pass_dentry," ");

    /*** ���O ***/

    if (strcmp(trim(option1),"1") == 0)
    {
    	strcpy(Full_DBName,get_car_full_db(ipolicy));

    	sprintf_s(stmt, sizeof stmt, "select nequipment "
                       " from %s:policy  "
                       " where ipolicy = '%s' "
                    ,Full_DBName,ipolicy);

    	$PREPARE cur1 FROM $stmt;
        $EXECUTE cur1 INTO $nequipment;

    	if(SQLCODE==SQLNOTFOUND) strcpy(nequipment," ");

    	sprintf_s(stmt, sizeof stmt, "select substr(dpolicy,7,4)|| '/' || substr(dpolicy,1,2) || '/' || substr(dpolicy,4,2) "
                       " from %s:ply_relation  "
                       " where ipolicy = '%s' "
                    ,Full_DBName,ipolicy);

    	$PREPARE cur2 FROM $stmt;
        $EXECUTE cur2 INTO $dpolicy;

    	if(SQLCODE==SQLNOTFOUND) strcpy(dpolicy," ");
    }
    else
    {
    	strcpy(Full_DBName,get_car_full_db(iendorse));

    	sprintf_s(stmt, sizeof stmt, "select nequipment "
                       " from %s:endorsement  "
                       " where iendorse = '%s' "
                    ,Full_DBName,iendorse);

    	$PREPARE cur3 FROM $stmt;
        $EXECUTE cur3 INTO $nequipment;

    	if(SQLCODE==SQLNOTFOUND) strcpy(nequipment," ");

    	sprintf_s(stmt, sizeof stmt, "select substr(dendorse,7,4)|| '/' || substr(dendorse,1,2) || '/' || substr(dendorse,4,2) "
                       " from %s:edr_relation  "
                       " where iendorse = '%s' "
                    ,Full_DBName,iendorse);

    	$PREPARE cur4 FROM $stmt;
        $EXECUTE cur4 INTO $dpolicy;

    	if(SQLCODE==SQLNOTFOUND) strcpy(dpolicy," ");
    }
printf("Full_DBName[%s]\n",Full_DBName);

    /*strcpy(equipdecode,equip_get(nequipment));*/
    if (equip_cmp(nequipment,"97") == TRUE)
    	strcpy(equipdecode,"Y");
    else
    	strcpy(equipdecode,"N");

    /*** �q���N���O�_�ݩ󦬶O�X��ĳq�]�w�ɤ��D�q���N�� ***/
    $select icode,nvl(substr(dexpire,7,4)|| "/" ||substr(dexpire,1,2)|| "/" ||substr(dexpire,4,2)," ")
       into $croute,$dexpire
       FROM ca_permit
      WHERE iclass = '05'
        AND ftype_sp = '20'
        AND icode = $tmp_iroute_main;

    if(SQLCODE==SQLNOTFOUND)
    {
    	strcpy(croute," ");
    	strcpy(dexpire," ");
    }

    /*** ���O�X��ĳq�]�w�ɫ��ɤ� ***/
    $select nvl(substr(min(date(dupdate)),7,4)|| "/" ||substr(min(date(dupdate)),1,2)|| "/" ||substr(min(date(dupdate)),4,2)," ")
       into $icreate
       FROM ca_permit_log
      WHERE update_mode = 'I'
        AND icode = $tmp_iroute_main;

    if(SQLCODE==SQLNOTFOUND) strcpy(icreate," ");



printf("dpolicy[%s]\n",dpolicy);
printf("nequipment[%s]equipdecode[%s]\n",nequipment,equipdecode);

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s %s %s %s %s %s",M_CM_OK,tmp_ipolicy1,tmp_ipolicy2,tmp_iendorse,tmp_icard,tmp_ipre_rcv,tmp_ftype_pol,tmp_paydate,tmp_ftype_sp);
    cm_buf_put("%s %s %s %s %s %s %s %s %s",tmp_iins_kind,tmp_iins_kind_ply,tmp_iassured,tmp_nassured,tmp_iapplicant,tmp_napplicant,tmp_itag,tmp_iengine,tmp_deffect);
    cm_buf_put("%s %l %s %s %s %s %s %s %s %s %s",tmp_iedr_return,tmp_mprem,tmp_iofficer,tmp_ileader,tmp_iroute,tmp_ientry,tmp_dentry,tmp_dbegin,tmp_dend,tmp_ipre_end,pass_dentry);
    cm_buf_put("%s %s %s %s %s %s ",dpolicy,equipdecode,croute,dexpire,icreate,fprint_note);
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
    else
       return api_OKComplete;



errexit:
  printf("SQLCODE:%d errmsg:%s\n",SQLCODE,sqlca.sqlerrm);
  if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
  else
     return apiRC;
}

long car158_single_query_log(reply)
serverReply reply;
{
 $char DBName[3];
 char  tmpbuf[4000];
 int   count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 $char userid[11],ipolicy[26],iendorse[21],icard[21],ipre_rcv[21],iins_kind[2],ipre_end[21];
 $char old_ftype_pol[3],old_ftype_sp[3],new_ftype_pol[3],new_ftype_sp[3];
 $char paydate[11],iassured[11],nassured[41],itag[CA_TAG_NUM],iengine[CA_ENGINE_NUM],deffect[11];
 $char iofficer[11],ileader[11],iroute[21];
 $char iupdate[7],dupdate[11],dbegin[11],dend[11],iroute_main[13],croute[21],pass_dentry[11],nnote[81];
 $char stmt[1000];
 $char Full_DBName[31];
 int   rc;

  cm_buf_get("%s %s %s %s %s",DBName,userid,ipre_rcv,iins_kind,ipre_end);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
     if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
       return M_CM_DB_NOTOPEN;
     else
       return apiRC;
  }


            $SELECT (a.ipolicy1 || a.ipolicy2),a.iendorse,a.icard,b.ipre_rcv,
                    b.ftype_pol,b.ftype_sp,a.ftype_pol,a.ftype_sp,
                    nvl(year(b.paydate)-1911||to_char(b.paydate,'/%m/%d'),''),
                    a.iassured,a.nassured,a.itag,a.iengine,
                    nvl(year(a.deffect)-1911||to_char(a.deffect,'/%m/%d'),''),
                    a.iofficer,a.ileader,a.iroute,b.iupdate,
                    nvl(year(date(b.dupdate))-1911||to_char(date(b.dupdate),'/%m/%d'),''),
                    nvl(year(a.dbegin)-1911||to_char(a.dbegin,'/%m/%d'),''),
                    nvl(year(a.dend)-1911||to_char(a.dend,'/%m/%d'),''),
                    (SELECT iroute_main FROM cm_route WHERE iroute = a.iroute),b.nnote
               INTO $ipolicy,$iendorse,$icard,$ipre_rcv,$old_ftype_pol,$old_ftype_sp,
                    $new_ftype_pol,$new_ftype_sp,$paydate,$iassured,$nassured,$itag,$iengine,
                    $deffect,$iofficer,$ileader,$iroute,$iupdate,$dupdate,$dbegin,$dend,$iroute_main,$nnote
               FROM cm_pre_receive a , ca_permit_after_log b
 	      WHERE a.ipre_rcv = b.ipre_rcv
                AND a.iins_kind = b.iins_kind
                AND a.ipre_end = b.ipre_end
                AND a.ipre_rcv = $ipre_rcv
                AND a.iins_kind = $iins_kind
                AND a.ipre_end = $ipre_end;

		if(SQLCODE==SQLNOTFOUND)
  		{
    		  if(exitsub(reply,M_CM_NOT_FOUND) == True)
      			return M_CM_NOT_FOUND;
    		  else
      			return apiRC;
  		}

   $select icode
      INTO $croute
      FROM ca_permit
     WHERE iclass = '05'
       AND ftype_sp = '20'
       AND icode = $iroute_main;

    if(SQLCODE==SQLNOTFOUND)
    {
    	strcpy(croute," ");
    }
    
    /*ú�O���*/
    $select nvl((year(dentry)-1911 ||to_char(dentry,'/%m/%d')),'')
       into $pass_dentry
       from ao_prercv_pass
      where ipre_rcv = $ipre_rcv
        and iins_kind = $iins_kind
	and ipre_end = $ipre_end ;

    if(SQLCODE==SQLNOTFOUND) strcpy(pass_dentry," ");




    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s %s %s %s %s %s ",M_CM_OK,ipolicy,iendorse,icard,ipre_rcv,old_ftype_pol,old_ftype_sp,new_ftype_pol,new_ftype_sp);
    cm_buf_put("%s %s %s %s %s %s %s %s %s ",paydate,iassured,nassured,itag,iengine,deffect,iofficer,ileader,iroute);
    cm_buf_put("%s %s %s %s %s %s %s ",iupdate,dupdate,dbegin,dend,croute,pass_dentry,nnote);


    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
    else
       return api_OKComplete;



errexit:
  printf("SQLCODE:%d errmsg:%s\n",SQLCODE,sqlca.sqlerrm);
  if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
  else
     return apiRC;
}


/******************************************************************/
long car158_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 $char DBName[3];

 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int raw_len;
 long dummy=0;
 long MsgCode;
 $char userid[11],ipre_rcv[21],iins_kind[2],ipre_end[21],last_ftype_pol[3],last_ftype_sp[3],paydate[11],ftype_pol[3],ftype_sp[3],nnote[82];
 $char stmt[1000];
 int   rc,is_upd_fail=0;
 $char stmt_buf[300];

 comm = (char *) command;
 cm_buf_init(command);
printf("123456789\n");
 cm_buf_get("%c %s",&option,DBName);

printf("0000000011111122222\n");

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

 if (option == 'P')
  {

    $BEGIN WORK;
   cm_buf_init(command);
   cm_buf_get("%c %s",&option,DBName);
   cm_buf_get("%s %s %s %s %s %s %s %s %s %s ",userid,ipre_rcv,iins_kind,ipre_end,last_ftype_pol,last_ftype_sp,paydate,ftype_pol,ftype_sp,nnote);

   $WHENEVER SQLERROR CONTINUE;


   if(strcmp(ftype_pol,"NA")!=0 && strcmp(ftype_pol,"SP")!=0 )
   {
   	goto errexit;
   }

   if(strcmp(ftype_sp,"01")!=0 && strcmp(ftype_sp,"10")!=0 && strcmp(ftype_sp,"20")!=0 && strcmp(ftype_sp,"AP")!=0 && strcmp(ftype_sp,"RN")!=0)
   {
   	goto errexit;
   }

   if(strlen(nnote) == 0)
   {
   	strcpy(nnote," ");
   }

strcpy(paydate,cm_to_infdate(paydate));
printf("%s %s %s %s %s %s %s %s %s \n",ipre_rcv,iins_kind,ipre_end,last_ftype_pol,last_ftype_sp,paydate,ftype_pol,ftype_sp,nnote);

         sprintf_s(stmt_buf, sizeof stmt_buf, "UPDATE cm_pre_receive SET "
                            "    (ftype_pol,ftype_sp,paydate) "
                            "          = (?,?,NULL) "
                            "       WHERE iins_cat = 'C' "
                            "         AND ipre_rcv=? AND iins_kind=? AND ipre_end=?");

                $PREPARE u_id FROM $stmt_buf;
                $EXECUTE u_id USING $ftype_pol,$ftype_sp,$ipre_rcv,$iins_kind,$ipre_end;

                $insert into ca_permit_after_log values($ipre_rcv,$iins_kind,$ipre_end,$last_ftype_pol,$last_ftype_sp,$paydate,$userid,current,$nnote);

                if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     		{
                  printf("391391391391\n");
     		}

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     tmp_len = cm_buf_len(ReplyBuf);
     if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
     {
       $WHENEVER SQLERROR CONTINUE;
       $ROLLBACK WORK;
       return apiRC;
     }
     $WHENEVER SQLERROR GOTO errexit;
     $COMMIT WORK;
     return api_OKComplete;
  }
  else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
    return M_CM_WRONG_OPTION;
   else
    return apiRC;
  }

errexit:
  printf("SQLCODE:%d errmsg:%s\n",SQLCODE,sqlca.sqlerrm);
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True)
   return MsgCode;
  else
   return apiRC;
}

