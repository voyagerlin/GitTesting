/********************************************
 *   CAR736    ��������                     *
 *   PROGRAM : ca736q01s.ec                 *
 *                                          *
 *   DATE    : 11/26/2010                   *
 *                                          *
 *   UPDATE  :                              *
 *   VERSION :                              *
 ********************************************/
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <decimal.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "is_def.h"
#include "aoimsgs.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "aoimsgs.h"
#include "commsgs.h"

#include "bfsmsgs.h"
#include "notmsgs.h"
#include "safeclib.h"

char  outputf[ N_FILE+1];
char  OutFile[ N_FILE+1];
int  max_count=0;
int page_count = 0;
$char  userid[11];
$int PgLine;
$char DBName[5],username[11];
$char FormTp[3];
$char cdquote_bgn[12],cdquote_end[12],dquote_bgn[12],dquote_end[12];
$char iquota[7],iroute[21],iexaminer[11];

long car736_build1();

main(argc, argv)
int argc;
char **argv;
{
    int rc;
	int i;

    batchinit();

	strcpy(DBName, isNULLstr(argv[1]));
	strcpy(userid, isNULLstr(argv[2]));
	strcpy(cdquote_bgn, isNULLstr(argv[3]));
	strcpy(cdquote_end, isNULLstr(argv[4]));
	strcpy(iquota, isNULLstr(argv[5]));
	strcpy(iroute, isNULLstr(argv[6]));
	strcpy(iexaminer, isNULLstr(argv[7]));
	strcpy(outputf,isNULLstr(argv[8]));

    if (cdquote_bgn[0] == '*')
        strcpy(dquote_bgn,"03/01/1999");
    else
        strcpy(dquote_bgn , cm_to_infdate(cdquote_bgn));

    if (cdquote_end[0] == '*')
        strcpy(dquote_end,"12/31/2220");
    else
        strcpy(dquote_end , cm_to_infdate(cdquote_end));

	rc=car736_build1();
	if((rc != M_CM_OK))
		return FAIL;
	else return M_CM_OK;

    if ((rc=save_form_info(F_FREE, "CA", 736, userid, FormTp,
         max_count, outputf))<0)
         EWRITE(userid, rc, "save_form_info failed");

}

long car736_build1()
{
	int rc;
	long lMsgcode;
	$char sDB_str[3];
	char sTmp_aa[2], sTmp_bb[21];
	$char stitle[2048];
	$int sub_qprem, preson1_qprem, iTmp = 0;
	$char site[5];
	$char   sErrmsg[200];
	char sFullDataFile[200];
	$char stmt[20000], totstmt[120000];
	FILE *fp;

	if (db_select(DBName) == False)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return 0;
    }
	$WHENEVER SQLERROR GOTO errexit;
	$SET LOCK MODE TO WAIT;
/*���� Temp Table*/
	sprintf_s(stmt, sizeof stmt, " select dentry,'' tentry,iestimate,a.ientry, (select nname from officer where iofficer = a.ientry) nentry,  "
		"(select nroute from cm_route where iroute = (select iroute_main from cm_route where iroute = a.iroute)) nbank,  "
		"(select nroute from cm_route where iroute = a.iroute) nsubbank, case when trim(NVL(ilast_ply,'')) = '' then '�s�O' else '��O' end continue_ply, ilast_ply,  "
		"case when trim(NVL(iofficer1,'')) = '' then iofficer2 else iofficer1 end iofficer,  "
		"case when trim(NVL(iofficer1,'')) = '' then (select nname from officer where iofficer = a.iofficer2) else (select nname from officer where iofficer = a.iofficer1) end nofficer,  "
		"a.iroute,  "
		"case when trim(NVL(iofficer1,'')) = '' then (select nname from officer where iofficer = (select ileader from officer where iofficer = a.iofficer2)) else (select nname from officer where iofficer = (select ileader from officer where iofficer = a.iofficer1)) end nleader,  "
		"case when trim(NVL(iofficer1,'')) = '' then (select nbranch from sa_branch_type where ibranch = (select iquota from officer where iofficer = a.iofficer2)) else (select nbranch from sa_branch_type where ibranch = (select iquota from officer where iofficer = a.iofficer1)) end nquota,  "
		"a.itag, case when trim(NVL(icar_type1,'')) = '' then a.icar_type2 || '/' || (select ncode from car_type where icode = a.icar_type2 and fclass = '1') else a.icar_type1 || '/' || (select ncode from car_type where icode = a.icar_type1 and fclass = '1') end ncar_type,  "
		"mpremium1, mpremium2, (mpremium1+mpremium2) tot_mpremium,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
		"	NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')),'')  "
		"	else NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')),'') end ipolicy1_1,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
		"	NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')),'')  "
		"	else NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')),'') end ipolicy1_2,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
		"	(select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')))  "
		"	else (select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1'))) end dins_bgn_1,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
		"	(select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')))  "
		"	else (select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1'))) end dins_end_1,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
		"	(select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')))  "
		"	else (select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2'))) end dins_bgn_2,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
		"	(select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')))  "
		"	else (select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2'))) end dins_end_2,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
		"	NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) and iendorsement = ''),0)  "
		"	else NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) and iendorsement = ''),0) end  "
		"	+  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
		"	NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) and iendorsement = ''),0)  "
		"	else NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) and iendorsement = ''),0) end tot_macct_prem,  "
		"a.nuser,a.dply2_begin,a.dply2_end,a.nbrand_abbr,a.ibrand, CASE WHEN (select max(icar_series) FROM ca_car_model WHERE ibrand = a.ibrand) = '10' THEN '�겣' ELSE '�i�f' END icar_series,"
		"(a.ipro_year ||'/'|| qpro_month) as dpro,CASE WHEN iissue_ym IS NULL OR TRIM(iissue_ym) = '' THEN '' WHEN SUBSTR(iissue_ym, 1, 2) BETWEEN '00' AND '50' THEN '1' || SUBSTR(iissue_ym, 1, 2) || SUBSTR(iissue_ym, 3, 3) ELSE iissue_ym END iissue_ym,a.qpt,a.qcylinder,a.iengine,(a.mcar_price-a.mequipment) as mcar_price,a.mequipment,"
	    "(SELECT mdamage_cover/10000 FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('05','01','09','201','205','209')) as mdamage_cover,"
		"a.idmg_rate,a.ibrg_rate,"
		"(SELECT mins_premium FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('01','201')) AS mins_premium_01,"
		"(SELECT mins_premium FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('05','205')) AS mins_premium_05,"
		"(SELECT mins_premium FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('09','209')) AS mins_premium_09,"
		"(SELECT mins_premium FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('10')) AS mins_premium_10,"
		"(SELECT mins_premium FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('02')) AS mins_premium_02,"
		"(SELECT mins_premium FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('176')) AS mins_premium_176,"
		"(SELECT mins_premium FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('177')) AS mins_premium_177,"
		"(SELECT mins_premium FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('11','211')) AS mins_premium_11,"
		"(SELECT mins_premium FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('17')) AS mins_premium_17,"
		"(SELECT mins_premium FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('28')) AS mins_premium_28,"
		"(SELECT mins_premium FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('31','231')) AS mins_premium_31,"
		"(SELECT mins_premium FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('32','232')) AS mins_premium_32,"
		"(SELECT mins_premium FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('55')) AS mins_premium_55,"
		"(SELECT mins_premium FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('56')) AS mins_premium_56,"
		"(SELECT mins_premium FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('30')) AS mins_premium_30,"
		"(SELECT mins_premium FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('178')) AS mins_premium_178,"
		"(SELECT mins_premium FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('27')) AS mins_premium_27,"
		"(SELECT mins_premium FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('34')) AS mins_premium_34,"
		"(SELECT mins_premium FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('238')) AS mins_premium_238,"
		"(SELECT sum(mins_premium) FROM newa00:est_ins_type WHERE iestimate = a.iestimate AND iins_type NOT IN ('01','201','05','205','09','209','10','02','176','177','11','211','17','28','31','231','32','232','55','56','30','178','27','34','238','21')) AS mins_premium_else,"
		"case when (SELECT count(*) FROM newa00:est_ins_type b WHERE b.iestimate = a.iestimate AND b.iins_type IN ('55','56')) > 0 THEN 1 ELSE 0 END cnt  "
	"from officer c inner join newa00:estimate a on c.iofficer = a.ientry  "
	"where c.iquota = '%s' and c.ileader = c.iofficer  "
	"and dentry between '%s' and '%s'  "
	"and a.iroute matches '%s' and a.iexaminer matches '%s' and a.itag <> '' into temp quote_tmp;  ",iquota, dquote_bgn, dquote_end, iroute, iexaminer);
	strcpy(totstmt,stmt);

	$PREPARE qto_tmp FROM $stmt;
    $EXECUTE qto_tmp;

	sprintf_s(stmt, sizeof stmt, "insert into quote_tmp select dentry,'' tentry,iestimate,a.ientry, (select nname from officer where iofficer = a.ientry) nentry,  "
		"(select nroute from cm_route where iroute = (select iroute_main from cm_route where iroute = a.iroute)) nbank,  "
		"(select nroute from cm_route where iroute = a.iroute) nsubbank, case when trim(NVL(ilast_ply,'')) = '' then '�s�O' else '��O' end continue_ply, ilast_ply,  "
		"case when trim(NVL(iofficer1,'')) = '' then iofficer2 else iofficer1 end iofficer,  "
		"case when trim(NVL(iofficer1,'')) = '' then (select nname from officer where iofficer = a.iofficer2) else (select nname from officer where iofficer = a.iofficer1) end nofficer,  "
		"a.iroute,  "
		"case when trim(NVL(iofficer1,'')) = '' then (select nname from officer where iofficer = (select ileader from officer where iofficer = a.iofficer2)) else (select nname from officer where iofficer = (select ileader from officer where iofficer = a.iofficer1)) end nleader,  "
		"case when trim(NVL(iofficer1,'')) = '' then (select nbranch from sa_branch_type where ibranch = (select iquota from officer where iofficer = a.iofficer2)) else (select nbranch from sa_branch_type where ibranch = (select iquota from officer where iofficer = a.iofficer1)) end nquota,  "
		"a.itag, case when trim(NVL(icar_type1,'')) = '' then a.icar_type2 || '/' || (select ncode from car_type where icode = a.icar_type2 and fclass = '1') else a.icar_type1 || '/' || (select ncode from car_type where icode = a.icar_type1 and fclass = '1') end ncar_type,  "
		"mpremium1, mpremium2, (mpremium1+mpremium2) tot_mpremium,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
		"	NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')),'')  "
		"	else NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')),'') end ipolicy1_1,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
		"	NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')),'')  "
		"	else NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')),'') end ipolicy1_2,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
		"	(select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')))  "
		"	else (select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1'))) end dins_bgn_1,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
		"	(select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')))  "
		"	else (select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1'))) end dins_end_1,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
		"	(select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')))  "
		"	else (select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2'))) end dins_bgn_2,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
		"	(select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')))  "
		"	else (select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2'))) end dins_end_2,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
		"	NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) and iendorsement = ''),0)  "
		"	else NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) and iendorsement = ''),0) end  "
		"	+  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
		"	NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) and iendorsement = ''),0)  "
		"	else NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) and iendorsement = ''),0) end tot_macct_prem,  "
		"a.nuser,a.dply2_begin,a.dply2_end,a.nbrand_abbr,a.ibrand, CASE WHEN (select max(icar_series) FROM ca_car_model WHERE ibrand = a.ibrand) = '10' THEN '�겣' ELSE '�i�f' END icar_series,"
		"(a.ipro_year ||'/'|| qpro_month) as dpro,CASE WHEN iissue_ym IS NULL OR TRIM(iissue_ym) = '' THEN '' WHEN SUBSTR(iissue_ym, 1, 2) BETWEEN '00' AND '50' THEN '1' || SUBSTR(iissue_ym, 1, 2) || SUBSTR(iissue_ym, 3, 3) ELSE iissue_ym END iissue_ym,a.qpt,a.qcylinder,a.iengine,(a.mcar_price-a.mequipment) as mcar_price,a.mequipment,"
	    "(SELECT mdamage_cover/10000 FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('05','01','09','201','205','209')) as mdamage_cover,"
		"a.idmg_rate,a.ibrg_rate,"
		"(SELECT mins_premium FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('01','201')) AS mins_premium_01,"
		"(SELECT mins_premium FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('05','205')) AS mins_premium_05,"
		"(SELECT mins_premium FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('09','209')) AS mins_premium_09,"
		"(SELECT mins_premium FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('10')) AS mins_premium_10,"
		"(SELECT mins_premium FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('02')) AS mins_premium_02,"
		"(SELECT mins_premium FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('176')) AS mins_premium_176,"
		"(SELECT mins_premium FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('177')) AS mins_premium_177,"
		"(SELECT mins_premium FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('11','211')) AS mins_premium_11,"
		"(SELECT mins_premium FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('17')) AS mins_premium_17,"
		"(SELECT mins_premium FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('28')) AS mins_premium_28,"
		"(SELECT mins_premium FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('31','231')) AS mins_premium_31,"
		"(SELECT mins_premium FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('32','232')) AS mins_premium_32,"
		"(SELECT mins_premium FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('55')) AS mins_premium_55,"
		"(SELECT mins_premium FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('56')) AS mins_premium_56,"
		"(SELECT mins_premium FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('30')) AS mins_premium_30,"
		"(SELECT mins_premium FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('178')) AS mins_premium_178,"
		"(SELECT mins_premium FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('27')) AS mins_premium_27,"
		"(SELECT mins_premium FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('34')) AS mins_premium_34,"
		"(SELECT mins_premium FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('238')) AS mins_premium_238,"
		"(SELECT sum(mins_premium) FROM newa22:est_ins_type WHERE iestimate = a.iestimate AND iins_type NOT IN ('01','201','05','205','09','209','10','02','176','177','11','211','17','28','31','231','32','232','55','56','30','178','27','34','238','21')) AS mins_premium_else,"
		"case when (SELECT count(*) FROM newa22:est_ins_type b WHERE b.iestimate = a.iestimate AND b.iins_type IN ('55','56')) > 0 THEN 1 ELSE 0 END cnt  "
	"from officer c inner join newa22:estimate a on c.iofficer = a.ientry  "
	"where c.iquota = '%s' and c.ileader = c.iofficer  "
	"and dentry between '%s' and '%s'  "
	"and a.iroute matches '%s' and a.iexaminer matches '%s' and a.itag <> ''  ",iquota, dquote_bgn, dquote_end, iroute, iexaminer);
	strcat(totstmt,stmt);

	$PREPARE qto_tmp FROM $stmt;
    $EXECUTE qto_tmp;

	sprintf_s(stmt, sizeof stmt, "insert into quote_tmp select dentry,'' tentry,iestimate,a.ientry, (select nname from officer where iofficer = a.ientry) nentry,  "
		"(select nroute from cm_route where iroute = (select iroute_main from cm_route where iroute = a.iroute)) nbank,  "
		"(select nroute from cm_route where iroute = a.iroute) nsubbank, case when trim(NVL(ilast_ply,'')) = '' then '�s�O' else '��O' end continue_ply, ilast_ply,  "
		"case when trim(NVL(iofficer1,'')) = '' then iofficer2 else iofficer1 end iofficer,  "
		"case when trim(NVL(iofficer1,'')) = '' then (select nname from officer where iofficer = a.iofficer2) else (select nname from officer where iofficer = a.iofficer1) end nofficer,  "
		"a.iroute,  "
		"case when trim(NVL(iofficer1,'')) = '' then (select nname from officer where iofficer = (select ileader from officer where iofficer = a.iofficer2)) else (select nname from officer where iofficer = (select ileader from officer where iofficer = a.iofficer1)) end nleader,  "
		"case when trim(NVL(iofficer1,'')) = '' then (select nbranch from sa_branch_type where ibranch = (select iquota from officer where iofficer = a.iofficer2)) else (select nbranch from sa_branch_type where ibranch = (select iquota from officer where iofficer = a.iofficer1)) end nquota,  "
		"a.itag, case when trim(NVL(icar_type1,'')) = '' then a.icar_type2 || '/' || (select ncode from car_type where icode = a.icar_type2 and fclass = '1') else a.icar_type1 || '/' || (select ncode from car_type where icode = a.icar_type1 and fclass = '1') end ncar_type,  "
		"mpremium1, mpremium2, (mpremium1+mpremium2) tot_mpremium,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
		"	NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')),'')  "
		"	else NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')),'') end ipolicy1_1,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
		"	NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')),'')  "
		"	else NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')),'') end ipolicy1_2,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
		"	(select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')))  "
		"	else (select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1'))) end dins_bgn_1,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
		"	(select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')))  "
		"	else (select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1'))) end dins_end_1,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
		"	(select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')))  "
		"	else (select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2'))) end dins_bgn_2,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
		"	(select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')))  "
		"	else (select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2'))) end dins_end_2,  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
		"	NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) and iendorsement = ''),0)  "
		"	else NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) and iendorsement = ''),0) end  "
		"	+  "
		"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
		"	NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) and iendorsement = ''),0)  "
		"	else NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) and iendorsement = ''),0) end tot_macct_prem,  "
	    "a.nuser,a.dply2_begin,a.dply2_end,a.nbrand_abbr,a.ibrand, CASE WHEN (select max(icar_series) FROM ca_car_model WHERE ibrand = a.ibrand) = '10' THEN '�겣' ELSE '�i�f' END icar_series,"
		"(a.ipro_year ||'/'|| qpro_month) as dpro,CASE WHEN iissue_ym IS NULL OR TRIM(iissue_ym) = '' THEN '' WHEN SUBSTR(iissue_ym, 1, 2) BETWEEN '00' AND '50' THEN '1' || SUBSTR(iissue_ym, 1, 2) || SUBSTR(iissue_ym, 3, 3) ELSE iissue_ym END iissue_ym,a.qpt,a.qcylinder,a.iengine,(a.mcar_price-a.mequipment) as mcar_price,a.mequipment,"
	    "(SELECT mdamage_cover/10000 FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('05','01','09','201','205','209')) as mdamage_cover,"
		"a.idmg_rate,a.ibrg_rate,"
		"(SELECT mins_premium FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('01','201')) AS mins_premium_01,"
		"(SELECT mins_premium FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('05','205')) AS mins_premium_05,"
		"(SELECT mins_premium FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('09','209')) AS mins_premium_09,"
		"(SELECT mins_premium FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('10')) AS mins_premium_10,"
		"(SELECT mins_premium FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('02')) AS mins_premium_02,"
		"(SELECT mins_premium FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('176')) AS mins_premium_176,"
		"(SELECT mins_premium FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('177')) AS mins_premium_177,"
		"(SELECT mins_premium FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('11','211')) AS mins_premium_11,"
		"(SELECT mins_premium FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('17')) AS mins_premium_17,"
		"(SELECT mins_premium FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('28')) AS mins_premium_28,"
		"(SELECT mins_premium FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('31','231')) AS mins_premium_31,"
		"(SELECT mins_premium FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('32','232')) AS mins_premium_32,"
		"(SELECT mins_premium FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('55')) AS mins_premium_55,"
		"(SELECT mins_premium FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('56')) AS mins_premium_56,"
		"(SELECT mins_premium FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('30')) AS mins_premium_30,"
		"(SELECT mins_premium FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('178')) AS mins_premium_178,"
		"(SELECT mins_premium FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('27')) AS mins_premium_27,"
		"(SELECT mins_premium FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('34')) AS mins_premium_34,"
		"(SELECT mins_premium FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('238')) AS mins_premium_238,"
		"(SELECT sum(mins_premium) FROM newa33:est_ins_type WHERE iestimate = a.iestimate AND iins_type NOT IN ('01','201','05','205','09','209','10','02','176','177','11','211','17','28','31','231','32','232','55','56','30','178','27','34','238','21')) AS mins_premium_else,"
		"    case when (SELECT count(*) FROM newa33:est_ins_type b WHERE b.iestimate = a.iestimate AND b.iins_type IN ('55','56')) > 0 THEN 1 ELSE 0 END cnt  "
	"from officer c inner join newa33:estimate a on c.iofficer = a.ientry  "
	"where c.iquota = '%s' and c.ileader = c.iofficer   "
	"and dentry between '%s' and '%s'  "
	"and a.iroute matches '%s' and a.iexaminer matches '%s' and a.itag <> ''  ",iquota, dquote_bgn, dquote_end, iroute, iexaminer);
	strcat(totstmt,stmt);
	$PREPARE qto_tmp FROM $stmt;
    $EXECUTE qto_tmp;	

		sprintf_s(stmt, sizeof stmt, "insert into quote_tmp select dentry,'' tentry,iestimate,a.ientry, (select nname from officer where iofficer = a.ientry) nentry,  "
			"(select nroute from cm_route where iroute = (select iroute_main from cm_route where iroute = a.iroute)) nbank,  "
			"(select nroute from cm_route where iroute = a.iroute) nsubbank, case when trim(NVL(ilast_ply,'')) = '' then '�s�O' else '��O' end continue_ply, ilast_ply,  "
			"case when trim(NVL(iofficer1,'')) = '' then iofficer2 else iofficer1 end iofficer,  "
			"case when trim(NVL(iofficer1,'')) = '' then (select nname from officer where iofficer = a.iofficer2) else (select nname from officer where iofficer = a.iofficer1) end nofficer,  "
			"a.iroute,  "
			"case when trim(NVL(iofficer1,'')) = '' then (select nname from officer where iofficer = (select ileader from officer where iofficer = a.iofficer2)) else (select nname from officer where iofficer = (select ileader from officer where iofficer = a.iofficer1)) end nleader,  "
			"case when trim(NVL(iofficer1,'')) = '' then (select nbranch from sa_branch_type where ibranch = (select iquota from officer where iofficer = a.iofficer2)) else (select nbranch from sa_branch_type where ibranch = (select iquota from officer where iofficer = a.iofficer1)) end nquota,  "
			"a.itag, case when trim(NVL(icar_type1,'')) = '' then a.icar_type2 || '/' || (select ncode from car_type where icode = a.icar_type2 and fclass = '1') else a.icar_type1 || '/' || (select ncode from car_type where icode = a.icar_type1 and fclass = '1') end ncar_type,  "
			"mpremium1, mpremium2, (mpremium1+mpremium2) tot_mpremium,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
			"	NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')),'')  "
			"	else NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')),'') end ipolicy1_1,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
			"	NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')),'')  "
			"	else NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')),'') end ipolicy1_2,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
			"	(select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')))  "
			"	else (select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1'))) end dins_bgn_1,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
			"	(select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')))  "
			"	else (select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1'))) end dins_end_1,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
			"	(select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')))  "
			"	else (select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2'))) end dins_bgn_2,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
			"	(select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')))  "
			"	else (select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2'))) end dins_end_2,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
			"	NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) and iendorsement = ''),0)  "
			"	else NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) and iendorsement = ''),0) end  "
			"	+  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
			"	NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) and iendorsement = ''),0)  "
			"	else NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) and iendorsement = ''),0) end tot_macct_prem,  "
		    "a.nuser,a.dply2_begin,a.dply2_end,a.nbrand_abbr,a.ibrand, CASE WHEN (select max(icar_series) FROM ca_car_model WHERE ibrand = a.ibrand) = '10' THEN '�겣' ELSE '�i�f' END icar_series,"
			"(a.ipro_year ||'/'|| qpro_month) as dpro,CASE WHEN iissue_ym IS NULL OR TRIM(iissue_ym) = '' THEN '' WHEN SUBSTR(iissue_ym, 1, 2) BETWEEN '00' AND '50' THEN '1' || SUBSTR(iissue_ym, 1, 2) || SUBSTR(iissue_ym, 3, 3) ELSE iissue_ym END iissue_ym,a.qpt,a.qcylinder,a.iengine,(a.mcar_price-a.mequipment) as mcar_price,a.mequipment,"
			"(SELECT mdamage_cover/10000 FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('05','01','09','201','205','209')) as mdamage_cover,"
			"a.idmg_rate,a.ibrg_rate,"
			"(SELECT mins_premium FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('01','201')) AS mins_premium_01,"
			"(SELECT mins_premium FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('05','205')) AS mins_premium_05,"
			"(SELECT mins_premium FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('09','209')) AS mins_premium_09,"
			"(SELECT mins_premium FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('10')) AS mins_premium_10,"
			"(SELECT mins_premium FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('02')) AS mins_premium_02,"
			"(SELECT mins_premium FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('176')) AS mins_premium_176,"
			"(SELECT mins_premium FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('177')) AS mins_premium_177,"
			"(SELECT mins_premium FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('11','211')) AS mins_premium_11,"
			"(SELECT mins_premium FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('17')) AS mins_premium_17,"
			"(SELECT mins_premium FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('28')) AS mins_premium_28,"
			"(SELECT mins_premium FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('31','231')) AS mins_premium_31,"
			"(SELECT mins_premium FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('32','232')) AS mins_premium_32,"
			"(SELECT mins_premium FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('55')) AS mins_premium_55,"
			"(SELECT mins_premium FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('56')) AS mins_premium_56,"
			"(SELECT mins_premium FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('30')) AS mins_premium_30,"
			"(SELECT mins_premium FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('178')) AS mins_premium_178,"
			"(SELECT mins_premium FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('27')) AS mins_premium_27,"
			"(SELECT mins_premium FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('34')) AS mins_premium_34,"
			"(SELECT mins_premium FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('238')) AS mins_premium_238,"
			"(SELECT sum(mins_premium) FROM newa40:est_ins_type WHERE iestimate = a.iestimate AND iins_type NOT IN ('01','201','05','205','09','209','10','02','176','177','11','211','17','28','31','231','32','232','55','56','30','178','27','34','238','21')) AS mins_premium_else,"
			"    case when (SELECT count(*) FROM newa40:est_ins_type b WHERE b.iestimate = a.iestimate AND b.iins_type IN ('55','56')) > 0 THEN 1 ELSE 0 END cnt  "
		"from officer c inner join newa40:estimate a on c.iofficer = a.ientry  "
		"where c.iquota = '%s' and c.ileader = c.iofficer  "
		"and dentry between '%s' and '%s'  "
		"and a.iroute matches '%s' and a.iexaminer matches '%s' and a.itag <> ''  ",iquota, dquote_bgn, dquote_end, iroute, iexaminer);
	strcat(totstmt,stmt);
	$PREPARE qto_tmp FROM $stmt;
    $EXECUTE qto_tmp;

		sprintf_s(stmt, sizeof stmt, "insert into quote_tmp select dentry,'' tentry,iestimate,a.ientry, (select nname from officer where iofficer = a.ientry) nentry,  "
			"(select nroute from cm_route where iroute = (select iroute_main from cm_route where iroute = a.iroute)) nbank,  "
			"(select nroute from cm_route where iroute = a.iroute) nsubbank, case when trim(NVL(ilast_ply,'')) = '' then '�s�O' else '��O' end continue_ply, ilast_ply,  "
			"case when trim(NVL(iofficer1,'')) = '' then iofficer2 else iofficer1 end iofficer,  "
			"case when trim(NVL(iofficer1,'')) = '' then (select nname from officer where iofficer = a.iofficer2) else (select nname from officer where iofficer = a.iofficer1) end nofficer,  "
			"a.iroute,  "
			"case when trim(NVL(iofficer1,'')) = '' then (select nname from officer where iofficer = (select ileader from officer where iofficer = a.iofficer2)) else (select nname from officer where iofficer = (select ileader from officer where iofficer = a.iofficer1)) end nleader,  "
			"case when trim(NVL(iofficer1,'')) = '' then (select nbranch from sa_branch_type where ibranch = (select iquota from officer where iofficer = a.iofficer2)) else (select nbranch from sa_branch_type where ibranch = (select iquota from officer where iofficer = a.iofficer1)) end nquota,  "
			"a.itag,case when trim(NVL(icar_type1,'')) = '' then a.icar_type2 || '/' || (select ncode from car_type where icode = a.icar_type2 and fclass = '1') else a.icar_type1 || '/' || (select ncode from car_type where icode = a.icar_type1 and fclass = '1') end ncar_type,  "
			"mpremium1, mpremium2, (mpremium1+mpremium2) tot_mpremium,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
			"	NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')),'')  "
			"	else NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')),'') end ipolicy1_1,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
			"	NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')),'')  "
			"	else NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')),'') end ipolicy1_2,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
			"	(select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')))  "
			"	else (select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1'))) end dins_bgn_1,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
			"	(select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')))  "
			"	else (select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1'))) end dins_end_1,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
			"	(select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')))  "
			"	else (select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2'))) end dins_bgn_2,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
			"	(select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')))  "
			"	else (select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2'))) end dins_end_2,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
			"	NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) and iendorsement = ''),0)  "
			"	else NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) and iendorsement = ''),0) end  "
			"	+  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
			"	NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) and iendorsement = ''),0)  "
			"	else NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) and iendorsement = ''),0) end tot_macct_prem,  "
			"a.nuser,a.dply2_begin,a.dply2_end,a.nbrand_abbr,a.ibrand, CASE WHEN (select max(icar_series) FROM ca_car_model WHERE ibrand = a.ibrand) = '10' THEN '�겣' ELSE '�i�f' END icar_series,"
		"(a.ipro_year ||'/'|| qpro_month) as dpro,CASE WHEN iissue_ym IS NULL OR TRIM(iissue_ym) = '' THEN '' WHEN SUBSTR(iissue_ym, 1, 2) BETWEEN '00' AND '50' THEN '1' || SUBSTR(iissue_ym, 1, 2) || SUBSTR(iissue_ym, 3, 3) ELSE iissue_ym END iissue_ym,a.qpt,a.qcylinder,a.iengine,(a.mcar_price-a.mequipment) as mcar_price,a.mequipment,"
	    "(SELECT mdamage_cover/10000 FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('05','01','09','201','205','209')) as mdamage_cover,"
		"a.idmg_rate,a.ibrg_rate,"
		"(SELECT mins_premium FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('01','201')) AS mins_premium_01,"
		"(SELECT mins_premium FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('05','205')) AS mins_premium_05,"
		"(SELECT mins_premium FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('09','209')) AS mins_premium_09,"
		"(SELECT mins_premium FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('10')) AS mins_premium_10,"
		"(SELECT mins_premium FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('02')) AS mins_premium_02,"
		"(SELECT mins_premium FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('176')) AS mins_premium_176,"
		"(SELECT mins_premium FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('177')) AS mins_premium_177,"
		"(SELECT mins_premium FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('11','211')) AS mins_premium_11,"
		"(SELECT mins_premium FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('17')) AS mins_premium_17,"
		"(SELECT mins_premium FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('28')) AS mins_premium_28,"
		"(SELECT mins_premium FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('31','231')) AS mins_premium_31,"
		"(SELECT mins_premium FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('32','232')) AS mins_premium_32,"
		"(SELECT mins_premium FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('55')) AS mins_premium_55,"
		"(SELECT mins_premium FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('56')) AS mins_premium_56,"
		"(SELECT mins_premium FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('30')) AS mins_premium_30,"
		"(SELECT mins_premium FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('178')) AS mins_premium_178,"
		"(SELECT mins_premium FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('27')) AS mins_premium_27,"
		"(SELECT mins_premium FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('34')) AS mins_premium_34,"
		"(SELECT mins_premium FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('238')) AS mins_premium_238,"
		"(SELECT sum(mins_premium) FROM newa66:est_ins_type WHERE iestimate = a.iestimate AND iins_type NOT IN ('01','201','05','205','09','209','10','02','176','177','11','211','17','28','31','231','32','232','55','56','30','178','27','34','238','21')) AS mins_premium_else,"
			"case when (SELECT count(*) FROM newa66:est_ins_type b WHERE b.iestimate = a.iestimate AND b.iins_type IN ('55','56')) > 0 THEN 1 ELSE 0 END cnt  "
		"from officer c inner join newa66:estimate a on c.iofficer = a.ientry  "
		"where c.iquota = '%s' and c.ileader = c.iofficer  "
		"and dentry between '%s' and '%s'  "
		"and a.iroute matches '%s' and a.iexaminer matches '%s' and a.itag <> ''  ",iquota, dquote_bgn, dquote_end, iroute, iexaminer);
	strcat(totstmt,stmt);
		$PREPARE qto_tmp FROM $stmt;
    	$EXECUTE qto_tmp;

		sprintf_s(stmt, sizeof stmt, "insert into quote_tmp select dentry,'' tentry,iestimate,a.ientry, (select nname from officer where iofficer = a.ientry) nentry,  "
			"(select nroute from cm_route where iroute = (select iroute_main from cm_route where iroute = a.iroute)) nbank,  "
			"(select nroute from cm_route where iroute = a.iroute) nsubbank, case when trim(NVL(ilast_ply,'')) = '' then '�s�O' else '��O' end continue_ply, ilast_ply,  "
			"case when trim(NVL(iofficer1,'')) = '' then iofficer2 else iofficer1 end iofficer,  "
			"case when trim(NVL(iofficer1,'')) = '' then (select nname from officer where iofficer = a.iofficer2) else (select nname from officer where iofficer = a.iofficer1) end nofficer,  "
			"a.iroute,  "
			"case when trim(NVL(iofficer1,'')) = '' then (select nname from officer where iofficer = (select ileader from officer where iofficer = a.iofficer2)) else (select nname from officer where iofficer = (select ileader from officer where iofficer = a.iofficer1)) end nleader,  "
			"case when trim(NVL(iofficer1,'')) = '' then (select nbranch from sa_branch_type where ibranch = (select iquota from officer where iofficer = a.iofficer2)) else (select nbranch from sa_branch_type where ibranch = (select iquota from officer where iofficer = a.iofficer1)) end nquota,  "
			"a.itag, case when trim(NVL(icar_type1,'')) = '' then a.icar_type2 || '/' || (select ncode from car_type where icode = a.icar_type2 and fclass = '1') else a.icar_type1 || '/' || (select ncode from car_type where icode = a.icar_type1 and fclass = '1') end ncar_type,  "
			"mpremium1, mpremium2, (mpremium1+mpremium2) tot_mpremium,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
			"	NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')),'')  "
			"	else NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')),'') end ipolicy1_1,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
			"	NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')),'')  "
			"	else NVL((select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')),'') end ipolicy1_2,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
			"	(select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')))  "
			"	else (select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1'))) end dins_bgn_1,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
			"	(select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')))  "
			"	else (select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1'))) end dins_end_1,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
			"	(select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')))  "
			"	else (select dins_bgn from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2'))) end dins_bgn_2,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
			"	(select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')))  "
			"	else (select dins_end from dwsdb:policy_new b where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2'))) end dins_end_2,  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) > 0 then  "
			"	NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) and iendorsement = ''),0)  "
			"	else NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply1_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C1')) and iendorsement = ''),0) end  "
			"	+  "
			"case when (select count(*) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) > 0 then  "
			"	NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.ichannel[1] = 'I' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) and iendorsement = ''),0)  "
			"	else NVL((select macct_prem from dwsdb:policy_main where ipolicy1 = (select max(ipolicy1) from dwsdb:policy_new b where b.fstatus <> 'C' and b.fstatus <> 'D' and b.itarget1 = a.itag and year(b.dins_bgn) = year(a.dply2_begin) and b.ipolicy1[6,7] = (select iins_kind from sa_insurance where insure_type = 'C' and b.ipolicy1[6,7] = iins_kind and iins_level = 'C2')) and iendorsement = ''),0) end tot_macct_prem,  "
			"a.nuser,a.dply2_begin,a.dply2_end,a.nbrand_abbr,a.ibrand, CASE WHEN (select max(icar_series) FROM ca_car_model WHERE ibrand = a.ibrand) = '10' THEN '�겣' ELSE '�i�f' END icar_series,"
			"(a.ipro_year ||'/'|| qpro_month) as dpro,CASE WHEN iissue_ym IS NULL OR TRIM(iissue_ym) = '' THEN '' WHEN SUBSTR(iissue_ym, 1, 2) BETWEEN '00' AND '50' THEN '1' || SUBSTR(iissue_ym, 1, 2) || SUBSTR(iissue_ym, 3, 3) ELSE iissue_ym END iissue_ym,a.qpt,a.qcylinder,a.iengine,(a.mcar_price-a.mequipment) as mcar_price,a.mequipment,"
			"(SELECT mdamage_cover/10000 FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('05','01','09','201','205','209')) as mdamage_cover,"
			"a.idmg_rate,a.ibrg_rate,"
			"(SELECT mins_premium FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('01','201')) AS mins_premium_01,"
			"(SELECT mins_premium FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('05','205')) AS mins_premium_05,"
			"(SELECT mins_premium FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('09','209')) AS mins_premium_09,"
			"(SELECT mins_premium FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('10')) AS mins_premium_10,"
			"(SELECT mins_premium FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('02')) AS mins_premium_02,"
			"(SELECT mins_premium FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('176')) AS mins_premium_176,"
			"(SELECT mins_premium FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('177')) AS mins_premium_177,"
			"(SELECT mins_premium FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('11','211')) AS mins_premium_11,"
			"(SELECT mins_premium FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('17')) AS mins_premium_17,"
			"(SELECT mins_premium FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('28')) AS mins_premium_28,"
			"(SELECT mins_premium FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('31','231')) AS mins_premium_31,"
			"(SELECT mins_premium FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('32','232')) AS mins_premium_32,"
			"(SELECT mins_premium FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('55')) AS mins_premium_55,"
			"(SELECT mins_premium FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('56')) AS mins_premium_56,"
			"(SELECT mins_premium FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('30')) AS mins_premium_30,"
			"(SELECT mins_premium FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('178')) AS mins_premium_178,"
			"(SELECT mins_premium FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('27')) AS mins_premium_27,"
			"(SELECT mins_premium FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('34')) AS mins_premium_34,"
			"(SELECT mins_premium FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type IN ('238')) AS mins_premium_238,"
			"(SELECT sum(mins_premium) FROM newa70:est_ins_type WHERE iestimate = a.iestimate AND iins_type NOT IN ('01','201','05','205','09','209','10','02','176','177','11','211','17','28','31','231','32','232','55','56','30','178','27','34','238','21')) AS mins_premium_else,"
			"case when (SELECT count(*) FROM newa70:est_ins_type b WHERE b.iestimate = a.iestimate AND b.iins_type IN ('55','56')) > 0 THEN 1 ELSE 0 END cnt  "
		"from officer c inner join newa70:estimate a on c.iofficer = a.ientry  "
		"where c.iquota = '%s' and c.ileader = c.iofficer  "
		"and dentry between '%s' and '%s'  "
		"and a.iroute matches '%s' and a.iexaminer matches '%s' and a.itag <> '' ",iquota, dquote_bgn, dquote_end, iroute, iexaminer);
	strcat(totstmt,stmt);
	printf("totstmt==>[%s]\n",totstmt);
    $PREPARE qto_tmp FROM $stmt;
    $EXECUTE qto_tmp;

/*�`�� Temp Table*/
	$select case when ncar_type like '%����%' then '����' else '�T��' end nncar_type,* from quote_tmp into temp quote_tmp1;
	$select year(dentry) dentry_year,max(tot_mpremium) tot_mpremium,nbank, nncar_type, nentry, itag, ipolicy1_1, ipolicy1_2, dins_bgn_1, dins_bgn_2, dins_end_1, dins_end_2, tot_macct_prem,cnt
	from quote_tmp1 group by 1,3,4,5,6,7,8,9,10,11,12,13,14 into temp gen_quote_tmp;	
/*���ͩ��ӳ���*/
    iTmp = 65;
	sprintf_s(sTmp_bb, sizeof sTmp_bb, "�������檬�p���Ӫ�");
	sprintf_s(stmt, sizeof stmt, "SELECT dentry,tentry,iestimate,ientry,nentry,nbank,nsubbank,continue_ply,ilast_ply,iofficer,nofficer,iroute,nleader,nquota,itag,ncar_type,mpremium1,mpremium2,tot_mpremium,ipolicy1_1,ipolicy1_2,dins_bgn_1,dins_end_1,dins_bgn_2,dins_end_2,tot_macct_prem,nuser,dply2_begin,dply2_end,nbrand_abbr,'=\"'||ibrand||'\"', icar_series,dpro, iissue_ym,qpt,qcylinder,iengine,mcar_price,mequipment,mdamage_cover,idmg_rate,'=\"'||ibrg_rate||'\"',mins_premium_01,mins_premium_05,mins_premium_09,mins_premium_10,mins_premium_02,mins_premium_176,mins_premium_177,mins_premium_11,mins_premium_17,mins_premium_28,mins_premium_31,mins_premium_32,mins_premium_55,mins_premium_56,mins_premium_30,mins_premium_178,mins_premium_27,mins_premium_34,mins_premium_238,mins_premium_else,mpremium2 FROM quote_tmp;");
	strcpy(stitle,"�������\t�����ɶ�\t�����渹\t�����H���s\t�����H��\t�Ȧ�O\t����O\t�s��O\t��O�渹\t�g��N��\t�g��W��\t�q���N��\t�޲z�H\t���W��\t���P\t����\t�����j��O�O\t�������N�O�O\t�����`�O�O\t�j��O�渹\t���N�O�渹\t�j��O���_��\t�j��O������\t���N�O���_��\t���N�O������\t�����`�O�O\t�ϥΤH\t�������N�O���_��\t�������N�O������\t�t�P\t�t�P�N��\t�i�f/�겣\t�s�y�~��\t�o�Ӧ~��\t��������\t�Ʈ�q\t�������X\t����\t�t�ƪ��B\t�����I�O�I���B\t����O�v�N��\t�ѵs�O�v�N��\t01/201\t05/205\t09/209\t10\t=\"02\"\t176\t177\t11/211\t17\t28\t31/231\t32/232\t55\t56\t30(�t����)\t178\t27\t34\t238\t��L\t���N�`�O�O\t");
	sTmp_aa[0] = iTmp++;
	sTmp_aa[1] = '\0';
	rc = unload_file(outputf,sTmp_aa,sTmp_bb,stitle,stmt);
	if (rc != SUCCESS)
	{
		strcpy(sErrmsg,"�ɮ׵L�k���͡C ");
		EWRITE(userid, rc , sErrmsg);
		exit(1);
	}

/*���ͻȦ�O�J�`����*/
	sprintf_s(sTmp_bb, sizeof sTmp_bb, "�q���O�����J�`��");
	sprintf_s(stmt, sizeof stmt, "select nbank, nncar_type, count(*), sum(tot_mpremium),  "
				"(select count(*) from quote_tmp1 where nbank = a.nbank and nncar_type = a.nncar_type and (ipolicy1_1 <> '' or ipolicy1_2 <> '')),  "
				"(select sum(tot_macct_prem) from quote_tmp1 where nbank = a.nbank and nncar_type = a.nncar_type and (ipolicy1_1 <> '' or ipolicy1_2 <> '')),  "
				"(select count(*) from gen_quote_tmp where nbank = a.nbank and nncar_type = a.nncar_type),  "
				"(select sum(tot_mpremium) from gen_quote_tmp where nbank = a.nbank and nncar_type = a.nncar_type),  "
				"(select count(*) from gen_quote_tmp where nbank = a.nbank and nncar_type = a.nncar_type and (ipolicy1_1 <> '' or ipolicy1_2 <> '')),  "
				"(select sum(tot_macct_prem) from gen_quote_tmp where nbank = a.nbank and nncar_type = a.nncar_type and (ipolicy1_1 <> '' or ipolicy1_2 <> ''))  "
				"from quote_tmp1 a group by 1,2,5,6,7,8,9,10;");
	strcpy(stitle,"�Ȧ�O\t�T�����O\t�������\t�����O�O\t������\t����O�O\t���ĳ������\t���ĳ����O�O\t���Ħ�����\t���Ħ���O�O\t");
	sTmp_aa[0] = iTmp++;
	sTmp_aa[1] = '\0';
	rc = unload_file(outputf,sTmp_aa,sTmp_bb,stitle,stmt);
	if (rc != SUCCESS)
	{
		strcpy(sErrmsg,"�ɮ׵L�k���͡C ");
		EWRITE(userid, rc , sErrmsg);
		exit(1);
	}

/*���ͤH���O�J�`����*/
	sprintf_s(sTmp_bb, sizeof sTmp_bb, "�H���O�����J�`��");
	sprintf_s(stmt, sizeof stmt, "select nentry, nncar_type, count(*), sum(tot_mpremium),  "
				"(select count(*) from quote_tmp1 where nentry = a.nentry and nncar_type = a.nncar_type and (ipolicy1_1 <> '' or ipolicy1_2 <> '')),  "
				"(select sum(tot_macct_prem) from quote_tmp1 where nentry = a.nentry and nncar_type = a.nncar_type and (ipolicy1_1 <> '' or ipolicy1_2 <> '')),  "
				"(select count(*) from gen_quote_tmp where nentry = a.nentry and nncar_type = a.nncar_type),  "
				"(select sum(tot_mpremium) from gen_quote_tmp where nentry = a.nentry and nncar_type = a.nncar_type),  "
				"(select count(*) from gen_quote_tmp where nentry = a.nentry and nncar_type = a.nncar_type and (ipolicy1_1 <> '' or ipolicy1_2 <> '')),  "
				"(select sum(tot_macct_prem) from gen_quote_tmp where nentry = a.nentry and nncar_type = a.nncar_type and (ipolicy1_1 <> '' or ipolicy1_2 <> '')),  "
				"sum(cnt),  "
		   		"(select sum(cnt) from quote_tmp1 where nentry = a.nentry and nncar_type = a.nncar_type and ipolicy1_2 <> ''),  "
		   		"(select sum(cnt) from gen_quote_tmp where nentry = a.nentry and nncar_type = a.nncar_type),  "
		   		"(select sum(cnt) from gen_quote_tmp where nentry = a.nentry and nncar_type = a.nncar_type and ipolicy1_2 <> '')  "
				"from quote_tmp1 a group by 1,2,5,6,7,8,9,10;");
	strcpy(stitle,"�����H��\t�T�����O\t�������\t�����O�O\t������\t����O�O\t���ĳ������\t���ĳ����O�O\t���Ħ�����\t���Ħ���O�O\t55�B56�������\t55�B56������\t55�B56���ĳ������\t55�B56���Ħ�����\t");
	sTmp_aa[0] = iTmp++;
	sTmp_aa[1] = '\0';
	rc = unload_file(outputf,sTmp_aa,sTmp_bb,stitle,stmt);
	if (rc != SUCCESS)
	{
		strcpy(sErrmsg,"�ɮ׵L�k���͡C ");
		EWRITE(userid, rc , sErrmsg);
		exit(1);
	}

    return M_CM_OK;

errexit:
   lMsgcode = SQLCODE;
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, lMsgcode, sqlca.sqlerrm);
   return lMsgcode;
}
