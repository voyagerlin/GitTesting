/*******************************************/
/*          �j�v�����վ��ƺ��@           */
/*   PROGRAM : car418m01s.ec               */
/*                                         */
/*   DATE    : 910407                      */
/*                                         */
/*******************************************/
#include <stdio.h>
#include <math.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "rinmsgs.h"
#include "rinmsg.h"
#include <stdlib.h>
$include sqlca;
$include "rindata.h";
#include <decimal.h>
$include "safeclib.h";

$char DBName[5];
long GetLastYearDate();
long GetNextYearDate();
char v_sMsg[1512];

/***************************************************************************/

long car418(reply, command, com_len)
serverReply reply;
voidP command;
int com_len;
{
   static long rtncode;
   long car418_M(),car418_get_irisk_no(),car418_E();
   long car418_C(), car418_D();
   char option;

   cm_buf_init(command);
   cm_buf_get("%c", &option);

   switch(option) {
      case 'M':     
         rtncode = car418_M(reply);
         break;

      case 'E':
         rtncode = car418_E(reply);
         break;

      case 'D':
         rtncode = car418_D(reply);
         break;

      case 'C':
         rtncode = car418_C(reply);
         break;

      default :
         if (exitsub(reply, M_CM_WRONG_OPTION) == True)
           {
            return M_CM_WRONG_OPTION;
           }
         else
           {
            return apiRC;
           }
   }
   return(rtncode);
}

/************************************************************************/
long car418_M(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /*----declare------*/ 
 $char dtransfer[11], ftransit[2];
 $char dtransfer_bgn[11],dtransfer_end[11]; /*�褸�~*/ 
 $char nvessel[41],nvoyage[16],dsail_date[11],dsail_cdate[11],dsail_edate[11];
 $char irisk_no[21],ito[6],fin_out[2];  

 $char ipolicy[21],ipolicy_ext[4],iendorsement[21];
 $char ifrom[6],fins_type[3];
  
 $char opt[2],argv1[50],argv2[50];
 $char wherestr[150], stmt[1024]; 
 $double mins_amount,mprem_cur;
 $char mins_amount_s[18],mprem_cur_s[18]; 
  double sum_mins_amount,sum_mprem_cur;
  char sum_mins_amount_s[18],sum_mprem_cur_s[18];

 /* standard defined data */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;
 /* end of standard data */
 $char dbgn[11],dend[11];
 $char ileader[11],aassured[121],iofficer[11],dply_end[11];
 $char nassured[61],ibig_sales[11],nname[21],ibig_nname[21];   
 $long total_len;
 $long total_cnt;
 $char iofficer1[11],iofficer2[11];
 $char iquota[5];
 $long ldbgn1,ldend1,ldbgn1_n,ldend1_n;
 $char offname[11];
 $long last_dply_end;
 $char sdply_end[11];
 $long dply_begin;
 $char userid[11];
 $int  offcnt;
 $char aassured_zip[CA_ZIP];

 $char iprocess[21],ibroker[11],dpolicy_bgn[11],dpolicy_end[11],iins_type[7];
 $double pcomm=0.0,pagent=0.0;
 $int mdeal=0,mcomm_diff=0,magent_diff=0,mdeal_diff=0;
 $char fstatus[2];
 $char iroute[21], irate_type[2], iroute_comm[4];
 $char buf1[50],buf2[50];
 $char sTmp_pcomm[6],sTmp_agent[6];

    total_len = 0;
    total_cnt = 0;
    cm_buf_get("%s",DBName);
    cm_buf_get("%s",userid);
    cm_buf_get("%s",iprocess);
    cm_buf_get("%s %s",ipolicy,iins_type);

   printf("iprocess[%s]\n",iprocess);
   printf("ipolicy[%s]\n",ipolicy);
   printf("iins_type[%s]\n",iins_type);

   if(strcmp(trim(ipolicy),"*")==0)
   { sprintf_s(buf1, sizeof buf1," "); }
   else
   { sprintf_s(buf1, sizeof buf1,"and ipolicy matches '%s' ",ipolicy); }

    if(strcmp(trim(iins_type),"*")==0)
    { sprintf_s(buf2, sizeof buf2," "); }
    else
    { sprintf_s(buf2, sizeof buf2,"and iins_type = '%s' ",iins_type); }

    printf("buf1[%s]\n",buf1);
    printf("buf2[%s]\n",buf2);


    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
           return M_CM_DB_NOTOPEN;
        else
           return apiRC;
    }

    sprintf_s(stmt, sizeof stmt,
     " SELECT iprocess,ibroker,dpolicy_bgn,dpolicy_end,ipolicy,iins_type, "
     "         pcomm,pagent,mdeal,mcomm_diff,magent_diff,mdeal_diff,fstatus,  "
     "         iroute, irate_type, iroute_comm "
     "    FROM ca_comm_balance "
     "   WHERE iprocess = '%s' %s %s  "
     "   ORDER BY ipolicy,iins_type ",iprocess,buf1,buf2);

     printf("stmt[%s]\n",stmt);
    $PREPARE m_1 FROM $stmt;
    $DECLARE M_CUR CURSOR FOR m_1;
    $OPEN M_CUR;
    for(;;)
    {
        $FETCH M_CUR INTO $iprocess,$ibroker,$dpolicy_bgn,$dpolicy_end,$ipolicy,$iins_type,
                          $pcomm,$pagent,$mdeal,$mcomm_diff,$magent_diff,$mdeal_diff,
                          $fstatus, $iroute, $irate_type, $iroute_comm;

        if (SQLCODE == SQLNOTFOUND) break;

        total_cnt++;

          strcpy(iprocess,trim(iprocess));
          strcpy(ibroker,trim(ibroker));
          strcpy(dpolicy_bgn,trim(dpolicy_bgn));
          strcpy(dpolicy_end,trim(dpolicy_end));
          strcpy(ipolicy,trim(ipolicy));
          strcpy(iins_type,trim(iins_type));
          strcpy(dpolicy_bgn,cm_from_infdate_100(dpolicy_bgn));
          strcpy(dpolicy_end,cm_from_infdate_100(dpolicy_end));
          strcpy(iroute,trim(iroute));
          strcpy(irate_type,trim(irate_type));
          strcpy(iroute_comm,trim(iroute_comm));

          sprintf_s(sTmp_pcomm, sizeof sTmp_pcomm, "%3.2f", pcomm);
          sprintf_s(sTmp_agent, sizeof sTmp_agent, "%3.2f", pagent);


        cm_buf_init(tmpbuf);
        if (count == 0 )
        {
            cm_buf_res_msg();             /* reserve for MsgCode and count */
            cm_buf_res_count();
        }

         cm_buf_put("%s %s %s %s",
                     iprocess,ibroker,dpolicy_bgn,dpolicy_end);

         printf(" ************************************** \n");

         cm_buf_put("%s %s %s",
                     iroute,irate_type,iroute_comm);

        cm_buf_put("%s %s %s %s %d %d %d %d %s",
                    ipolicy,iins_type,
                    sTmp_pcomm,sTmp_agent,mdeal,mcomm_diff,magent_diff,mdeal_diff,fstatus);

        tmp_len = cm_buf_len(tmpbuf);
        if (tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
        {
            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else                        /* more than 4K, send to client side */
        {
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);/*�`�@���X��data*/
            if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
             {
              $CLOSE M_CUR;
              $FREE M_CUR;
              return apiRC;
             }
            else      /* clear ReplyBuf and count to start all over again */
             {
              replycnt++;
              if(replycnt > 1) sleep(1);    
              if(replycnt == 500)
               {
                /* more than 30K, client cannot display,error */
                cm_buf_init(ReplyBuf);
                cm_buf_put("%l",M_CM_OUT_SPACE);
                tmp_len = cm_buf_len(ReplyBuf);
                if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                  return apiRC;
                return M_CM_OUT_SPACE;
             }

        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();

           cm_buf_put("%s %s %s %s",
                       iprocess,ibroker,dpolicy_bgn,dpolicy_end);

           printf(" ************************************** \n");

         cm_buf_put("%s %s %s",
                     iroute,irate_type,iroute_comm);

          cm_buf_put("%s %s %s %s %d %d %d %d %s",
                      ipolicy,iins_type,
                      sTmp_pcomm,sTmp_agent,mdeal,mcomm_diff,magent_diff,mdeal_diff,fstatus);

        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
        }
       }

    } /* for loop */

    $CLOSE M_CUR;
    $FREE M_CUR;

    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
           return apiRC;
        return api_OKComplete;
    }
    else         /* break out, not any row is found */
    {
        if(exitsub(reply,M_CM_NOT_FOUND) == True) return M_CM_NOT_FOUND;
        else   
           return apiRC;
    }

errexit:
   if (exitsub(reply,SQLCODE) == True)
     return SQLCODE;
   else
     return apiRC;
}

/*---------------------------------------------------------*/
long car418_C(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 int tmp_len;
 $char aassured[121];

 /* self defined variable */
 $short id1, id2 ;
 $char ipolicy[21];
 $char nname[11];

    cm_buf_get(" %s ",DBName);
    cm_buf_get(" %s ",ipolicy);

    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
           return M_CM_DB_NOTOPEN;
        else
           return apiRC;
    }

    $WHENEVER SQLERROR GOTO errexit;

    $SELECT aassured
       INTO $aassured
       FROM policy_loss
      WHERE ipolicy = $ipolicy;
      if (SQLCODE == SQLNOTFOUND) strcpy(aassured," ");

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l ",M_CM_OK);
    cm_buf_put("%s ", rtrim(aassured));

    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
   if (exitsub(reply, SQLCODE) == True)
      return SQLCODE;
   else
      return apiRC;
}
       
long car418_D(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 int tmp_len;
 $char aassured[121];

 /* self defined variable */
 $short id1, id2 ;
 $char ipolicy[21];
 $char nname[11],ileader[11];

    cm_buf_get(" %s ",DBName);
    cm_buf_get(" %s ",ileader);

    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
           return M_CM_DB_NOTOPEN;
        else
           return apiRC;
    }

    $WHENEVER SQLERROR GOTO errexit;

    $SELECT nname
       INTO $nname
       FROM officer
      WHERE iofficer = $ileader;
      if (SQLCODE == SQLNOTFOUND) strcpy(nname," ");

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l ",M_CM_OK);
    cm_buf_put("%s ", rtrim(nname));

    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
   if (exitsub(reply, SQLCODE) == True)
      return SQLCODE;
   else
      return apiRC;
}
    
/*---------------------------------------------------------*/
long car418_E(reply)
serverReply reply;
{
 $char DBName[5];
 $char count1[7];
 int count2,i;  /* irisk_no have changed data's count*/
 int tmp_len, rc;
 long MsgCode;
 $char ipolicy[21],aassured[121];
 $char idel[2],sWhere[200];
 $char stmt[2000] ;
 $char aassured_zip[CA_ZIP];
 $char ileader[11],nname[11];
 $char userid[10];
 $char iins_type[7];
 $char pcomm[10],pagent[10],mdeal[10],mcomm_diff[10],magent_diff[10],mdeal_diff[10];
 $dec_t  dec_pcomm,dec_pagent;
 $double d_pcomm=0.0,d_pagent=0.0;
 $int int_mdeal=0,int_mcomm_diff=0,int_magent_diff=0,int_mdeal_diff=0;
 $char iprocess[21];
 $char ibroker[10],dpolicy_bgn[11],dpolicy_end[11],dpolicy_sys[11];
 $char dpolicy_bgn_1[11],dpolicy_end_1[11],dpolicy_sys_1[11];
 $char   sCCC1[101], sCCC2[101], sCCC3[101], f980401[2], drate_ym[5];
 double rCCC1, rCCC2, rCCC3;
 char  sIupcompShort[2], policyDB[21], policyDBname[41];
 $double pbusiness_new, pdiscount_new, pextra_charge_new;
 $char iroute[21], irate_type[2], iroute_comm[4];


 /* self definded variable */

    $WHENEVER SQLERROR GOTO errexit;

    cm_buf_get("%s %s %s %s %s %s %s",DBName,userid,iprocess,ibroker,dpolicy_bgn,dpolicy_end,count1);

    cm_buf_get("%s %s %s ", iroute,irate_type,iroute_comm);

    if(db_select(DBName) == False)
    { 
       return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN: apiRC; 
    }

    count2=atoi(count1);
    printf(" count2*******************[%d]\n",count2);
    for(i=0;i<count2;i++)
    {
        cm_buf_get("%s %s %s %s %s %s %s %s %s",idel,ipolicy,iins_type,pcomm,pagent,
                       mdeal,mcomm_diff,magent_diff,mdeal_diff);

        deccvasc( pcomm, strlen(pcomm), &dec_pcomm);
        dectodbl( &dec_pcomm, &d_pcomm);

        deccvasc( pagent, strlen(pagent), &dec_pagent);
        dectodbl( &dec_pagent, &d_pagent);

        int_mdeal = atoi(mdeal);
        int_mcomm_diff = atoi(mcomm_diff);
        int_magent_diff = atoi(magent_diff);
        int_mdeal_diff = atoi(mdeal_diff);

        strcpy(dpolicy_bgn_1,cm_to_infdate(dpolicy_bgn));
        strcpy(dpolicy_end_1,cm_to_infdate(dpolicy_end));
        strcpy(dpolicy_sys,cm_sysd_cdate_100(cm_get_sysd()));
        strcpy(dpolicy_sys_1,cm_to_infdate(dpolicy_sys));
        printf(" dpolicy_bgn[%s]\n",dpolicy_bgn);
        printf(" dpolicy_end[%s]\n",dpolicy_end);
        printf(" dpolicy_sys[%s]\n",dpolicy_sys);

        printf("idel [%s]\n",idel);
        printf("ipolicy--------[%s]\n",ipolicy);

        $WHENEVER SQLERROR CONTINUE;

        if (idel[0] == 'A' || idel[0] == 'U')
        {
            if( strcmp( trim( iins_type), "21") != 0) /* ���N�I */
            {
                sIupcompShort[0] = ipolicy[2]; /* �O�渹�ĤT�X */
                sIupcompShort[1] = '\0';
                strcpy( policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
                strcpy( policyDBname, get_full_dbname(policyDB));

                sprintf_s(stmt, sizeof stmt,
                " SELECT pbusiness, drate_ym, pdiscount, pextra_charge  "
                "    FROM %s:ply_ins_type     "
                "   WHERE ipolicy = ?         "
                "     AND iins_type = ? ", policyDBname);
                $PREPARE get_new_com FROM $stmt;
                $EXECUTE get_new_com
                    INTO $pbusiness_new, $drate_ym, $pdiscount_new, $pextra_charge_new
                   USING $ipolicy, $iins_type;
                if( SQLCODE == SQLNOTFOUND)
                    return exitsub(reply, M_CA_NINSTYPE) ? M_CA_NINSTYPE: apiRC; 

                $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
                   INTO $f980401
                   FROM ca_rate_date
                  WHERE icode  = $drate_ym
                    AND itable = 'cm_extra_charge';
        
                if( SQLCODE == SQLNOTFOUND)
                    return exitsub(reply, M_CA_EXTRA_CHARGE_DRATE) ? M_CA_EXTRA_CHARGE_DRATE: apiRC; 

                /* �O�v�ۥѤƤ��� */
                if( f980401[0] == '1')
                {
                    printf("pdiscount_new[%f]\n", pdiscount_new);
                    if( pdiscount_new != 0) /* �O�v�ۥѤƤ��ᤣ�i������ */
                        return exitsub(reply, M_CA_PDISCOUNT_ERR) ? M_CA_PDISCOUNT_ERR: apiRC;
        
                    sprintf_s(sCCC1, sizeof sCCC1 ,"%f", (double)(pdiscount_new + d_pcomm + d_pagent));
                    sprintf_s(sCCC2, sizeof sCCC2 ,"%f", (double)( (pextra_charge_new - pbusiness_new) * 100.0));
        
                    rCCC1 = atof( sCCC1);
                    rCCC2 = atof( sCCC2);
        
                    printf("��+�N+�u[%-3.20f]\n", rCCC1);
                    printf("��-�~   [%-3.20f]\n", rCCC2);
        
                    if ( rCCC1 > rCCC2 )
                        return exitsub(reply, M_CA_COMMI_ERR) ? M_CA_COMMI_ERR: apiRC; 
                }
            }
        }

        if (idel[0] == 'V')
        {
           sprintf_s(stmt, sizeof stmt,
            " DELETE FROM ca_comm_balance   "
            "   WHERE iprocess  = '%s'      "
            "   AND   ipolicy = '%s'        "
            "   AND   iins_type = '%s' ",iprocess,ipolicy,iins_type );
           printf("stmt[%s]\n",stmt);
           $PREPARE id1 FROM $stmt;
           $EXECUTE id1;

        }
        else if (idel[0] == 'A')
        {

         sprintf_s(stmt, sizeof stmt,"INSERT INTO ca_comm_balance               "
                 " (iprocess,ibroker,dpolicy_bgn,dpolicy_end,ipolicy,iins_type, "
                 " pcomm,pagent,mdeal,mcomm_diff,magent_diff,mdeal_diff,        "
                 " fstatus,dadjust,iendorse,ientry,dentry, iroute, irate_type, iroute_comm) "
                 " VALUES ('%s','%s','%s','%s','%s','%s',%f,%f,%d,%d,%d,%d,'%s','%s','%s','%s','%s')", 
                 iprocess,ibroker,dpolicy_bgn_1,dpolicy_end_1,ipolicy,iins_type,  
                 d_pcomm,d_pagent,int_mdeal,int_mcomm_diff,int_magent_diff,int_mdeal_diff, 
                 ' ',' ',' ',userid,dpolicy_sys_1, iroute, irate_type, iroute_comm);

         printf("stmt[%s]\n",stmt);
         $PREPARE id3 FROM $stmt;
         $EXECUTE id3;


        }
        else if (idel[0] == 'U')
        {
            sprintf_s(stmt, sizeof stmt,
             " UPDATE ca_comm_balance      "
             "     SET (pcomm,pagent,mdeal,mcomm_diff,magent_diff,mdeal_diff,ientry,dentry)   "
             "       = (?,?,?,?,?,?,?,?)    "
             "   WHERE iprocess = ?     "
             "     AND ipolicy = ?      "
             "     AND iins_type = ? ");
            printf("stmt[%s]\n",stmt);
            $PREPARE id2 FROM $stmt;
            $EXECUTE id2 USING $d_pcomm,$d_pagent,$int_mdeal,$int_mcomm_diff,$int_magent_diff,
                               $int_mdeal_diff,$userid,$dpolicy_sys_1,
                               $iprocess,$ipolicy,$iins_type;

         }

    }

       cm_buf_init(ReplyBuf);
       cm_buf_put("%l",M_CM_OK);
       tmp_len = cm_buf_len(ReplyBuf);
       if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
       else
          return api_OKComplete;

 errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply, MsgCode) ? MsgCode: apiRC;
}

long GetLastYearDate(pdate)
long pdate;
{
long ndate;
short mdy[3];

    rjulmdy(pdate,mdy);
    mdy[2]--;   /* mdy[2] is the year data */
    rmdyjul(mdy,&ndate);
    return ndate;
}

long GetNextYearDate(pdate)
long pdate;
{
long ndate;
short mdy[3];

    rjulmdy(pdate,mdy);
    mdy[2]++;   /* mdy[2] is the year data */
    rmdyjul(mdy,&ndate);
    return ndate;
}

