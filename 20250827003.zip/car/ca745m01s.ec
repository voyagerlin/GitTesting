/**************************************************************/
/*   PROGRAM : ca745m01s.ec                                   */
/*   DATE    : 2025/02/27                                     */
/*             ca_log �@�~�@�ά����d��-�{���N���d��             */
/**************************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
$include sqlca;
$include datetime.h;

long car745(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    long rtncode;
    long query_car745_ipgid();
    char option;
    
    cm_buf_init(command);
    cm_buf_get("%c", &option);
    switch (option)
    {
        case 'l':
            rtncode = query_car745_ipgid(reply);
            break;
        default:
            return exitsub(reply, M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
    }
    return rtncode;
}

long query_car745_ipgid(reply)
serverReply reply;
{
    $char DBName[5];
    $char cstartDate[11], cendDate[11];
    $char startDate[11], endDate[11];
    $char startDate2[16], endDate2[16];
    $char startDate3[20], endDate3[20];
    $char ipgid[9];
    char tmpbuf[4000];
    int count = 0, repbuf_len = 0, tmp_len = 0, replycnt = 0;

    cm_buf_get("%s", DBName);
    cm_buf_get("%s %s", cstartDate, cendDate);

    printf("131775 cstartDate=%s, cendDate=%s\n", cstartDate, cendDate);

    strcpy(startDate, cm_to_infdate(cstartDate)); 
    strcpy(startDate2,cm_from_infdate_100(startDate));	/* CYY/MM/DD */
    strcat(startDate2,"/00:00");			/* CYY/MM/DD/hh:mm */
    strcpy(startDate3,cm_sysd_edatetime(startDate2));	/* YYYY-MM-DD hh:mm */
    strcat(startDate3,":00");				/* YYYY-MM-DD hh:mm:ss */

    strcpy(endDate, cm_to_infdate(cendDate));
    strcpy(endDate2,cm_from_infdate_100(endDate));	/* CYY/MM/DD */
    strcat(endDate2,"/23:59");			/* CYY/MM/DD/hh:mm */
    strcpy(endDate3,cm_sysd_edatetime(endDate2));	/* YYYY-MM-DD hh:mm */
    strcat(endDate3,":59");				/* YYYY-MM-DD hh:mm:ss */

    printf("131775 startDate3=%s, endDate3=%s\n", startDate3, endDate3);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
        return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $DECLARE q_cur CURSOR FOR
      SELECT DISTINCT ipgid
        INTO $ipgid
        FROM ca_log
       WHERE dupdate BETWEEN $startDate3 AND $endDate3;

    $OPEN q_cur;

    for (;;)
    {
        $FETCH q_cur;
        if (SQLCODE != 0) break;

        cm_buf_init(tmpbuf);
        if (count == 0)
        {
            cm_buf_res_msg();    /* reserve for MsgCode and count */
            cm_buf_res_count();
        }

        cm_buf_put("%s", ipgid);
        tmp_len = cm_buf_len(tmpbuf);

        if (tmp_len + repbuf_len < 3000)
        {
            memcpy(&ReplyBuf[repbuf_len], tmpbuf, tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else
        {
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);

            if (SendSyncReply(reply, ReplyBuf, repbuf_len, api_OK) == False)
            {
                $CLOSE q_cur;
                return apiRC;
            }
            else
            {
                replycnt++;

                if (replycnt == 8)
                {
                    cm_buf_init(ReplyBuf);
                    cm_buf_put("%l", M_CM_OUT_SPACE);
                    tmp_len = cm_buf_len(ReplyBuf);
                    if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
                        return apiRC;
                    return M_CM_OUT_SPACE;
                }

                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();
                cm_buf_res_count();
                cm_buf_put("%s", ipgid);
                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
            }
        }
    }

    $CLOSE q_cur;
    if (count > 0)
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply, ReplyBuf, repbuf_len, api_OKComplete) == False)
            return apiRC;
        return api_OKComplete;
    }
    else
    {
        return exitsub(reply, M_CA_NBIG_OFFICE) ? M_CA_NBIG_OFFICE : apiRC;
    }

errexit:
    return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}