/*******************************************/
/*   �M�׽дک���--���رM��                */
/*   PROGRAM : ca626q05s.ec                */
/*   DATE    : 2005/01/26                  */
/*   MODIFY  : yyyy/mm/dd                  */
/*******************************************/
#include <stdio.h>
#include <unistd.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "carmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <math.h>
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"

#define head_line         1
#define desc_line         2
#define data_line         2

extern  char RPTDIR[];

$char   dbgn1[11], dend1[11],iprmt[11];
$char   dbgn_inf[11], dend_inf[11];
char    MsgCode[50],fply_close[2],qnext_year[2];
$char   Igroup[7],Ngroup[21];
int     date_i;

$char   iquota[7],icard[21],ipolicy[21],iendorse[21],iassured[18];
$char   nassured[25],dpolicy[11],dply_begin[11],ibrand[9],ori_dpolicy[11];
$char   iengine[21],iissue_ym[7],ibig_office[10],ibig_office_c[11];
$char   itag[CA_TAG_NUM],nbrand_abbr[13],dendorse[11],ioff1[2];
$char   ibig_sales[11],nsales[11],iins_type[7],ioff_sales[4];
$char   ncomp[11],nbig[21],dedr_close[11],fedr_class[2],d_today[11];
$char   iply_comp[21],icard_comp[21],ncar_abbr[13];
$long   mprem,mprem_ori,mprem_21, mins_prem_01,mins_damage;
$long   mins_prem_14,mins_prem_17,mins_prem_31, mins_prem_51;
$double pdisc;
$char   iassured1[13],iassured2[3],ipro_year[5],nbrand[31];
$char   nprmt[31],iofficer_1[2],ioff_chk[11],iagent[11];
$char   dprmt_bgn[11],dprmt_end[11],iprmt[11],iins_type_prmt[11];
$int    lofficer,iremark,ioff_chk_bgn,ioff_chk_len;
$int    qfield_all,qfield_chk,qyear;
$char   fanother[2],iofficera_1[2],ioff_chka[11];
$int    lofficera,iremarka,ioff_chk_bgna,ioff_chk_lena;
$char   iofficer[10], iofficer_c[11];
$char   bufA[80];
$long   mexpense, mprem_09, mprem_dmg, mprem_dmg1, medr_dmg;
$long   medr_09, medr_exp, mprem1, mexp_09;

$static char ipro_year_old[5];

$double mcar_price ,qpassenger;
$char   frate[4], icar_type_1[3], fcar_class[2];
$char   fuse_type[2] ,icar_series[3];
$char   dply_begin_1[11];
$char   car_type[3];
$char   icar_type[3];
$char   frate_ym[4];

$long   ply2_begin;
$long   cover_01_tmp, cover_01_11;
$long   cover_01, thousand_cover_01,damage_cover_01;
$int    car_age, car_age_mth;
$int    mdeduct;
$double year_dep, pdepreciate, brg_factor, car_price , s5_factor;
$char   fcar_class2[2], fcal_way[2] , ibrg_rate[3];

/* ca_rate */
$double prate_1, rate_prem, pextra_charge;
$char   ical_ins[INSURANCE_TYPE], fcal_class[2];

/* premium */
int     adj_age , int_ply_yr , tmp_cover_dep , thousand_cover_dep;
int     cover_dep , cover_dep_11;
double  adj_yr_dep;

/* car9805211 �s�W�n�O�H�H�Φw��/�޲z���I�[��T�� */
$char   napplicant[25],iapplicant[13],iins_type_safe[INSURANCE_TYPE];
$double rSafe_dmg, rSafe_17, rSafe_11, rSafe_31, rSafe_51, rSafe_14, rSafe_09;
$double rMgmt_dmg, rMgmt_17, rMgmt_11, rMgmt_31, rMgmt_51, rMgmt_14, rMgmt_09;
$double tmp_safe = 0, tmp_manage = 0;

struct struct_prem
{
    long  mins_premium;
    long  mprem;
};

struct  struct_prem  yprem[10];

DBinfo  *list;
int     count_db;
$char   DBName[05], iForm_Tp[03],fulldb[41];
char    BodyFile[ N_FILE+1];
char    TitleFile[ N_FILE+1];
char    outputf[N_FILE+1], userid[11];

char    msgbuf[100];
$int    ItemRow, TotColumn;
$int    StartRow,TitleRow;
$int    PgLine, Width;
$char   check1[2],check2[2];

int     max_cnt,iins;

long car6265_build1();
long car6265_build2();
long car6265_body1();
long car6265_body2();
long car6265_accumulate();
long car6265_iins11_prem();
static float MyPower();
double dbl_len8();
static char *get_car_full_db();

/*--------------------------------------------------------------------*/
car6265(DBName_h,userid_h,iprmt_h,dbgn1_h,dend1_h,check1_h,check2_h,
        date_h,fclose_h,qnext_year_h,outputf_h)
char *DBName_h,*userid_h,*iprmt_h,*dbgn1_h,*dend1_h;
char *check1_h,*check2_h,*fclose_h,*date_h;
char *qnext_year_h,*outputf_h;
{
    int rc;
    batchinit();

printf("begin car6265\n");
    
    strcpy(DBName,  DBName_h);
    strcpy(userid,  userid_h);
    strcpy(iprmt,   iprmt_h);
    strcpy(dbgn1,   dbgn1_h);
    strcpy(dend1,   dend1_h);
    strcpy(check1,  check1_h);
    strcpy(check2,  check2_h);
    strcpy(fply_close,  fclose_h);
    date_i=atoi(date_h);
    strcpy(qnext_year, qnext_year_h);
    strcpy(outputf, outputf_h);

    strcpy(dbgn_inf, cm_to_infdate(dbgn1));
    strcpy(dend_inf, cm_to_infdate(dend1));

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False) {
        return M_CM_DB_NOTOPEN;
    }

    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
        if (EWRITE(userid, M_CM_NOT_DBLIST) == True)
                return M_CM_NOT_DBLIST;
        return M_CM_OK;
        }
         
        rc = car6265_read_prmt();
        if (rc != M_CM_OK) {
        EWRITE(userid, rc,msgbuf);
        return rc;
        }

        max_cnt=0;
        if(strncmp(check1,"1",1)==0) {
        rc = car6265_build1();
        if ( rc != M_CM_OK)  {
                EWRITE(userid, rc, " ");
                return rc;
        }
        }

        max_cnt=0;
        if(strncmp(check2,"1",1)==0) {
        rc = car6265_build2();
        if ( rc != M_CM_OK)  {
                EWRITE(userid, rc, " ");
                return rc;
        }
        }
        return M_CM_OK;

errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car6265_read_prmt()
{
        $char  stmt[4096];
        
        $select nprmt,iofficer_1,lofficer,iremark,ioff_chk_bgn,
            ioff_chk_len,ioff_chk,iagent,qfield_all,qfield_chk,
            dprmt_bgn,dprmt_end,qyear,iins_type,fanother,
            iofficera_1,lofficera,iremarka,ioff_chk_bgna,
            ioff_chk_lena,ioff_chka
       into $nprmt,$iofficer_1,$lofficer,$iremark,$ioff_chk_bgn,
            $ioff_chk_len,$ioff_chk,$iagent,$qfield_all,$qfield_chk,
            $dprmt_bgn,$dprmt_end,$qyear,$iins_type_prmt,$fanother,
            $iofficera_1,$lofficera,$iremarka,$ioff_chk_bgna,
            $ioff_chk_lena,$ioff_chka
       from ca_promote
      where iprmt = $iprmt;

        if (SQLCODE==SQLNOTFOUND) {
        strcpy(msgbuf,"�d�L�M�׸��");
        return SQLCODE;
        }
        
        

        sprintf(stmt,"SELECT nbrand_abbr,nbrand,ipro_year\
                  FROM ca_car_model \
                  WHERE ibrand = ?\
                  ORDER BY ipro_year ");
        $PREPARE B_id FROM $stmt;
        $DECLARE curBX CURSOR FOR B_id;

        sprintf(stmt,"SELECT nname FROM officer WHERE iofficer = ? ");
        $PREPARE pre_name FROM $stmt;

        sprintf(stmt,"SELECT nname FROM officer WHERE ibus_location = ? ");
        $PREPARE pre_bigo FROM $stmt;

        sprintf(stmt,"SELECT nname[1,10] FROM ca_big_office \
                  WHERE fclass = '2' AND ibig_comp = ? ");
        $PREPARE pre_nsales FROM $stmt;

        sprintf(stmt,"SELECT nbranch FROM sa_branch_type \
                  WHERE ibranch = ? ");
        $PREPARE pre_nbranch FROM $stmt;

        sprintf(stmt,"SELECT ncode FROM car_type \
                  WHERE fclass = '1' AND icode = ? ");
        $PREPARE pre_type FROM $stmt;

        return M_CM_OK;

errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car6265_build1()
{
        $char  sfilename[81],stitle[1024],stmt[1024];
        int    rc,i;
        $WHENEVER SQLERROR GOTO errexit;

        rc = car6265_body1();
        if (rc != M_CM_OK)
           return rc;
 
        sprintf(sfilename,"%s�M�׽дک���(�̷s�O��)[%s]",
               rtrim(nprmt),cm_get_sysd());
        strcpy(stitle,
        "���N�X\t���\t�O�d��\t�O�渹\t�Q�O�I�H�N��\t�Q�O�I�H�W��\t�n�O�H�N��\t�n�O�H�W��\tñ���\t\
�ͮĤ�\t���إN��\t���ئW��\t�t�P�����N��\t�t�P\t����\t�������X\t�o�Ӧ~��\t\
�g��N��\t�g�줤��\t���I�N��\t���I�W��\t�~�N�N��\t�~�N�m�W\t\
�P�Ӹ��X\t���������I�O�O\t����ɯūO�O\t�ѧK��O�O\t�d���I�O�O\t�����I�O�O\t\
�N���O�O�O\t�j���Ҹ�\t�j��O�渹\t�j��O�O\t");
        if (qyear < 2)
           strcat(stitle,"�ѵs�I�O�O\t�����v(�H)\t��e�O�O\t");
        else {
           for(i=1;i<=qyear;i++) 
              sprintf(stitle,"%s(%d)�ѵs�I�O�O\t(%d)�����v(�H)\t(%d)��e�O�O\t",                      stitle,i,i,i);
        }
        
        sprintf(stitle,"%s���������I�w�����I�[��T��\t�ѧK��w�����I�[��T��\t�d���I�w�����I�[��T��\t\
                        �����I�w�����I�[��T��\t�N���O�w�����I�[��T��\t�ѵs�I�w�����I�[��T��\t\
                        ���������I�޲z���I�[��T��\t�ѧK��޲z���I�[��T��\t�d���I�޲z���I�[��T��\t\
                        �����I�޲z���I�[��T��\t�N���O�޲z���I�[��T��\t�ѵs�I�޲z���I�[��T��\t",stitle);

        strcpy(stmt,"select * from car6265");    
        if (strncmp(check2,"1",1)==0)
           unload_file(outputf,"A",sfilename,stitle,stmt);
        else
           unload_file(outputf," ",sfilename,stitle,stmt);

        if (rc != SUCCESS) {
           sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
           return rc;
        }

        return M_CM_OK;
errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6265_build2()
{
        $char  sfilename[81],stitle[1024],stmt[1024];
        int    rc;
        
        $WHENEVER SQLERROR GOTO errexit;

        rc = car6265_body2();
        if (rc != M_CM_OK)
           return rc;

        sprintf(sfilename,"%s�M�׽дک���(���P���)[%s]",
               rtrim(nprmt),cm_get_sysd());
        strcpy(stitle,
        "���N�X\t���\t�O�d��\t�O�渹\t��渹\t�Q�O�I�H�N��\t�Q�O�I�H�W��\t����\t\
�ͮĤ�\t���إN��\t���ئW��\t�t�P�����N��\t�t�P\t����\t�������X\t�o�Ӧ~��\t\
�g��N��\t�g�줤��\t���I�N��\t���I�W��\t�~�N�N��\t�~�N�m�W\t�P�Ӹ��X\t�����I�O�O\t\
�ѧK��O�O\t�d���I�O�O\t�����I�O�O\t�N���O�O�O\t�O��ñ���\t�ѵs�I�O�O\t�����v(�H)\t��e�O�O\t\
�����I�w�����I�[��T��\t�ѧK��w�����I�[��T��\t�d���I�w�����I�[��T��\t\
�����I�w�����I�[��T��\t�N���O�w�����I�[��T��\t�ѵs�I�w�����I�[��T��\t\
�����I�޲z���I�[��T��\t�ѧK��޲z���I�[��T��\t�d���I�޲z���I�[��T��\t\
�����I�޲z���I�[��T��\t�N���O�޲z���I�[��T��\t�ѵs�I�޲z���I�[��T��\t");

        strcpy(stmt,"select * from car6265_1");
        if (strncmp(check1,"1",1)==0)
           unload_file(outputf,"B",sfilename,stitle,stmt);
        else
           unload_file(outputf," ",sfilename,stitle,stmt);

        if (rc != SUCCESS) {
           sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
           return rc;
        }

        return M_CM_OK;
errexit:
        sqlfatal();
        EWRITE(userid, SQLCODE, sqlca.sqlerrm);
        return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car6265_body1()
{
        int   j, rc, i;
        $char stmt[4096],stmt1[4096],stmt2[512],stmt3[512],stmt4[81],stmt_qnextyear[128];
        $char stmt_safe[1024];
        $char tmp_ipro_year[5],stmt5[1024],stmt6[256];
        char  tit[41],h_tit[14];
        char  sequip_str[21];
        char  iequip_tmp[3];
        int   iequip_flag;

        $WHENEVER SQLERROR GOTO errexit;

        strcpy(stmt5,"create temp table car6265 (iquota char(10), ngroup char(20),\
                      icard char(20),ipolicy char(20),iassured char(10),\
                      nassured char(24),iapplicant char(12),napplicant char(24),\
                      dpolicy date,dply_begin date,icar_type char(2),\
                      ncar_abbr char(12),ibrand char(8),nbrand_abbr char(10),nbrand char(20),\
                      iengine char(20),iissue_ym char(6),iofficer char(10),nofficer char(10),\
                      ibig_office char(10),nbig_office char(10),ibig_sales char(10),\
                      nsales char(10),itag char(8),mprem_09 integer, mprem_damg integer, mprem_17 integer, \
                      mprem_31 integer, mprem_51 integer, mprem_14 integer,\
                      icard_comp char(20),iply_comp char(20),mprem_21 integer");
        for (i=1;i<qyear;i++)
            sprintf(stmt5,"%s,mprem_11%d integer,pdisc%d decimal(6,2),mori_11%d integer",stmt5,i,i,i);
        sprintf(stmt5,"%s,mprem_11%d integer,pdisc%d decimal(6,2),mori_11%d integer,\
                       rSafe_09 decimal(9,7),rSafe_17 decimal(9,7),rSafe_31 decimal(9,7),\
                       rSafe_51 decimal(9,7),rSafe_14 decimal(9,7),rSafe_11 decimal(9,7),\
                       rMgmt_09 decimal(9,7),rMgmt_17 decimal(9,7),rMgmt_31 decimal(9,7),\
                       rMgmt_51 decimal(9,7),rMgmt_14 decimal(9,7),rMgmt_11 decimal(9,7)) with no log",stmt5,i,i,i);
                       
printf("376 qyear=[%d] stmt5=[%s]\n",qyear,stmt5);
        $prepare pre_tmp from $stmt5;
        $execute pre_tmp;

        if (strncmp(fply_close,"1",1)==0) 
        strcpy(stmt2," AND a.dply_close is not null ");
        else
        strcpy(stmt2," ");
        
        if (date_i == 0)
            sprintf(stmt4,"dpolicy >= '%s' and dpolicy <= '%s' ",dbgn_inf,dend_inf);   /* ñ��� */
        else if (date_i == 1)
            sprintf(stmt4,"dply_end >= '%s' and dply_end <= '%s' ",dbgn_inf,dend_inf); /* ����� */
        else
            sprintf(stmt4,"dentry >= '%s' and dentry <= '%s' ",dbgn_inf,dend_inf);     /* ��J�� */
        
        /* �P�_�����O��/�s�O��/��O�� Modified by Julia Han in 2007/04/30 */
   	  /* "A"�������O��,"0"���s�O��,"1"����O�� */
   	  if (strncmp(qnext_year,"0",1)==0) {
   			strcpy(stmt_qnextyear,"AND a.qnext_year = 0");
   	  } else if (strncmp(qnext_year,"1",1)==0) {
   			strcpy(stmt_qnextyear,"AND a.qnext_year > 0");
   	  } else {
   			strcpy(stmt_qnextyear,"");
   	  }

        for(j=0;j<count_db;j++) 
        {
        /* sprintf(stmt,
             "SELECT a.ipolicy,a.icard,a.dply_begin,a.ibrand,\
                     to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'),\
                     a.ibig_office,a.iquota[1,4]||'00',a.dpolicy, a.ipro_year,\
                     nvl(mins_premium,0),nvl(pdiscount,0),nvl(mins_premium+mdiscount,0),\
                     b.iassured,b.iassured_ext,b.nassured[1,24],b.iapplicant,b.napplicant[1,24],\
                     b.iengine,b.itag,nvl(a.dendorse,' '),ibig_sales,\
                     a.fedr_class,today,icar_type, \
                     c.drate_ym, c.mdeduct, b.mcar_price, a.iofficer, \
                     NVL((SELECT sum(mins_premium) FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type in ('01','05','08','09')),0), \
                     NVL((SELECT mins_premium FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type = '14'),0),\
                     NVL((SELECT mins_premium FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type = '17'),0),\
                     NVL((SELECT sum(mins_premium) FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type in ('31','32')),0), \
                     NVL((SELECT mins_premium FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type = '51'),0) \
              FROM %s:ply_relation a, %s:policy b, outer %s:ply_ins_type c \
              WHERE %s AND a.ipolicy = b.ipolicy %s \
              AND a.ipolicy = c.ipolicy \
              AND c.iins_type = '11' \
              AND a.iofficer[1] = '%s' \
              AND a.iofficer[%d,%d] = '%s' \
              AND length(a.iofficer) = %d %s",
             list[j].dbname, list[j].dbname, list[j].dbname, list[j].dbname, list[j].dbname,
             list[j].dbname, list[j].dbname, list[j].dbname, stmt4, stmt2,
             iofficer_1, ioff_chk_bgn, ioff_chk_bgn+ioff_chk_len-1,
             ioff_chk, lofficer,stmt_qnextyear);*/
             
             sprintf(stmt,
             "SELECT a.ipolicy,a.icard,a.dply_begin,a.ibrand,\
                     to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'),\
                     a.ibig_office,a.iquota[1,4]||'00',a.dpolicy, a.ipro_year,\
                     nvl(mins_premium,0),nvl(pdiscount,0),nvl(mins_premium+mdiscount,0),\
                     b.iassured,b.iassured_ext,b.nassured[1,24],b.iapplicant,b.napplicant[1,24],\
                     b.iengine,b.itag,nvl(a.dendorse,' '),ibig_sales,\
                     a.fedr_class,today,icar_type, \
                     c.drate_ym, c.mdeduct, b.mcar_price, a.iofficer, \
                     NVL((SELECT sum(mins_premium) FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type in ('01','05','08','09')),0), \
                     NVL((SELECT mins_premium FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type = '14'),0),\
                     NVL((SELECT mins_premium FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type = '17'),0),\
                     NVL((SELECT sum(mins_premium) FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type in ('31','32')),0), \
                     NVL((SELECT mins_premium FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type = '51'),0) \
              FROM %s:ply_relation a, %s:policy b, outer %s:ply_ins_type c \
              WHERE %s AND a.ipolicy = b.ipolicy %s \
              AND a.ipolicy = c.ipolicy \
              AND c.iins_type = '11' \
              AND a.iofficer in (select unique iofficer_ori from ca_promote_officer where iprmt = '%s') %s",
             list[j].dbname, list[j].dbname, list[j].dbname, list[j].dbname, list[j].dbname,
             list[j].dbname, list[j].dbname, list[j].dbname, stmt4, stmt2, iprmt, stmt_qnextyear);
             
printf("body1.stmt[%s]\n",stmt); 
        $PREPARE a_id1 FROM $stmt;
        $DECLARE cur_A CURSOR FOR a_id1;
        $OPEN cur_A;
        for(;;) 
        {
                mprem=pdisc=mprem_ori=0;
                mins_prem_01=mins_prem_14=mins_prem_17=0;
                mins_prem_31= mins_prem_51=mins_damage=0;
                
                $FETCH cur_A
                  INTO $ipolicy,   $icard,       $dply_begin, $ibrand,
                   $iissue_ym, $ibig_office, $iquota,     $dpolicy,
                   $ipro_year, $mprem,       $pdisc,      $mprem_ori,
                   $iassured1, $iassured2,   $nassured,   $iapplicant, $napplicant,
                   $iengine,   $itag,        $dendorse,   $ibig_sales,
                   $fedr_class,$d_today,     $icar_type,
                   $frate_ym,  $mdeduct,     $car_price,  $iofficer,
                   $mins_prem_01, $mins_prem_14, $mins_prem_17, $mins_prem_31, $mins_prem_51;

                if (SQLCODE == SQLNOTFOUND) break;

                if (strcmp(dendorse,d_today)!=0 && strncmp(fedr_class,"1",1)==0)
                continue;
         
                strcpy( frate ,  frate_ym);
                
                $EXECUTE pre_name INTO $iofficer_c USING $iofficer;
                if(SQLCODE == SQLNOTFOUND)
                  strcpy(iofficer_c, " ");
         
                if (ibig_office[0]!=' ') {
                  
                $EXECUTE pre_bigo INTO $ibig_office_c USING $ibig_office;
                if(SQLCODE == SQLNOTFOUND)
                        strcpy(ibig_office_c,ibig_office);
                }
                else strcpy(ibig_office_c," ");

                
                $EXECUTE pre_nsales INTO $nsales USING $ibig_sales;
                if (SQLCODE==SQLNOTFOUND)
                strcpy(nsales," ");

                $EXECUTE pre_type INTO $ncar_abbr USING $icar_type;
                if (SQLCODE==SQLNOTFOUND)
                strcpy(ncar_abbr," ");

                if (strlen(trim(iassured1)) == 0 && strlen(trim(iassured2))==0)
                iassured[0] ='\0';
                else 
                {
                strcpy(iassured,rtrim(iassured1));
                strcat(iassured,rtrim(iassured2));  
                }

                $OPEN curBX USING $ibrand;
                $FETCH curBX INTO $nbrand_abbr,$nbrand,$tmp_ipro_year;
                if(SQLCODE == SQLNOTFOUND) 
                {
                nbrand_abbr[0]='\0';
                nbrand[0]='\0';
                }
                $CLOSE curBX;

                $EXECUTE pre_nbranch INTO $Ngroup USING $iquota;
                if(SQLCODE ==SQLNOTFOUND) Ngroup[0]='\0';

                /* �p��n�~�ѵs�I�O�O */
                rc = car6265_iins11_prem();
                if ( rc != M_CM_OK )
                {
                return rc;
                }
                /*-- Ū�j��O���� --*/
                $declare cur_comp cursor for
                 select ipolicy,icard into $iply_comp, $icard_comp
                   from assured_vs_ply
                  where iengine = $iengine
                    and fcard_class = '1'
                    and ipolicy[6,7] in ('ZJ','ZB');
                $open cur_comp;
                while(1) {
                   $fetch cur_comp;
                   if (SQLCODE==SQLNOTFOUND) break;
                   strcpy(fulldb,get_car_full_db(iply_comp));
                   sprintf(stmt6,
                   "select mlia_prem from %s:ply_relation \
                     where ipolicy = ? and fedr_class != '1'",fulldb); 
                   $prepare pre_comp from $stmt6;
                   $execute pre_comp into $mprem_21 using $iply_comp;
                   if (SQLCODE==SQLNOTFOUND) {
                      strcpy(iply_comp," ");
                      strcpy(icard_comp," ");
                      mprem_21=0;
                   }
                   else break;
                }
                $close cur_comp;
                mprem_dmg = mins_prem_01;              
                
                /*-- �p������O�O --*/
                if (strncmp(fedr_class,"1",1)==0) {
                sprintf(stmt1,"select iins_type,medr_expense \
                                 from %s:edr_relation a,%s:edr_ins_type b \
                                where a.ipolicy = ? \
                                  and a.fedr_class = '1' \
                                  and a.dendorse is not null \
                                  and a.iendorse = b.iendorse \
                                  and iins_type in ('01','05','08','09') \
                                  and medrdmg_cover != 0 ",
                        list[j].dbname,list[j].dbname);
                }
                else {
                   sprintf(stmt1,"select iins_type,mexpense from %s:ply_ins_type \
                                   where ipolicy = ? and mdamage_cover != 0 \
                                     and iins_type in ('01','05','08','09') ", 
                           list[j].dbname);
                }

                $prepare a_id11 from $stmt1;
                $declare cur_A1 cursor for a_id11;
                $open cur_A1 using $ipolicy;
                $fetch cur_A1 into $iins_type,$mexpense;
                if (SQLCODE == SQLNOTFOUND) strcpy(iins_type,"00");
                $close cur_A1;                
                
                medr_dmg=medr_09=medr_exp=0;

                strcpy(iendorse," ");
                if (strncmp(dendorse," ",1)!=0) {
                   sprintf(stmt1,
                          "SELECT a.iendorse, b.medrins_prem, nvl(dedr_close,' ')\
                            FROM %s:edr_relation a,%s:edr_ins_type b\
                           WHERE ipolicy = ? \
                             AND dendorse is not null \
                             AND b.iins_type in ('01','05','08','09') \
                             AND a.iendorse = b.iendorse",
                          list[j].dbname,list[j].dbname);

                   $PREPARE a_id2 FROM $stmt1;
                   $DECLARE cur_B CURSOR FOR a_id2;
                   $OPEN cur_B USING $ipolicy;
                   for(;;) {
                      mprem_dmg1=0;
                      $FETCH cur_B
                        INTO $iendorse, $mprem_dmg1, $dedr_close;
                      if (SQLCODE == SQLNOTFOUND) break;
                      
                      if (strncmp(dedr_close," ",1)==0) {
                         mprem_dmg -= mprem_dmg1;
                      }
                      else {
                         medr_dmg   += mprem_dmg1;
                      }
                      
                      mprem1=medr_exp=0;
                      sprintf(stmt3,
                         "select medrins_prem,medr_expense from %s:edr_ins_type \
                           where iendorse = ? and iins_type = '09' \
                             and iedr_type != '02' ",list[j].dbname);
                      $prepare pre_BB from $stmt3; 
                      $execute pre_BB into $mprem1,$medr_exp 
                                     using $iendorse;
                      medr_09 += mprem1;
                      mexp_09 += medr_exp;
                   }
                   $CLOSE cur_B;
                }
                
                if (strcmp(trim(iins_type),"09")==0) 
                   mprem_09 = mprem_dmg - mexpense;
                else
                   mprem_09 = mprem_dmg - medr_dmg + medr_09 - medr_exp;                
                
                mins_damage = mins_prem_01 - mprem_09;
                
                /* ����w��/�޲z���I�[��T�� */
                strcpy(fulldb,get_car_full_db(ipolicy));
                   sprintf(stmt_safe,"select iins_type,safe_rate,manage_rate from %s:ply_ins_type \
                                  where ipolicy = ? order by iins_type desc",fulldb);
                                  
                   $prepare pre_1d from $stmt_safe;
                   $declare cur_1d cursor for pre_1d;
                   $open    cur_1d using $ipolicy;
                   while(1) {
                        $fetch cur_1d into $iins_type_safe,$tmp_safe,$tmp_manage;
                        
                        if (SQLCODE==SQLNOTFOUND) break;
            
                        strcpy(iins_type_safe, trim(iins_type_safe));
                        iins=atoi(iins_type_safe);
                        switch(iins) {
                             case 9:
                                  rSafe_09 = tmp_safe;
                                  rMgmt_09 = tmp_manage;                                  
                                  break;
                             case 11:
                                 rSafe_11 = tmp_safe;
                                 rMgmt_11 = tmp_manage;
                                 break; 
                             case 14:
                                  rSafe_14 = tmp_safe;
                                  rMgmt_14 = tmp_manage;
                                  break;                             
                             case 17:
                                 rSafe_17 = tmp_safe;
                                 rMgmt_17 = tmp_manage;
                                 break;                               
                             case 31: case 32:
                                 rSafe_31 = tmp_safe;
                                 rMgmt_31 = tmp_manage;
                                 break;        
                             case 51: case 55:
                                 rSafe_51 = tmp_safe;
                                 rMgmt_51 = tmp_manage;
                                 break;                                                                                       
                         }
                    }
                    $close cur_1d;
                    $free cur_1d;
                 /* end of ����w��/�޲z���I�[��T�� */
                
                strcpy(stmt5,"insert into car6265 values (");
                sprintf(stmt5,"%s'%s', \
                '%s','%s','%s','%s','%s',\
                '%s','%s', '%s','%s','%s', \
                '%s','%s', '%s','%s','%s', \
                '%s','%s','%s','%s','%s', \
                '%s','%s','%s',%d,%d, \
                %d,%d,%d,%d,'%s', \
                '%s',%d, %d,%f,%d",
                stmt5,iquota,
                Ngroup,icard,ipolicy,iassured,nassured,\
                iassured, nassured,dpolicy,dply_begin,icar_type, \
                ncar_abbr,ibrand,nbrand_abbr,nbrand,iengine,\
                iissue_ym,iofficer,iofficer_c,ibig_office,ibig_office_c,\
                ibig_sales,nsales,itag,mprem_09,mins_damage,\
                mins_prem_17, mins_prem_31,mins_prem_51,mins_prem_14,icard_comp,
                iply_comp,mprem_21,mprem,pdisc,mprem_ori);
                for(i=1;i<qyear;i++)
                   sprintf(stmt5,"%s,%d,%f,%d",stmt5,
                   yprem[i].mins_premium,pdisc,yprem[i].mprem);
                   
                sprintf(stmt5,"%s,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f,%f",stmt5,
                        rSafe_09,rSafe_17,rSafe_31,rSafe_51,rSafe_14,rSafe_11,
                        rMgmt_09,rMgmt_17,rMgmt_31,rMgmt_51,rMgmt_14,rMgmt_11);
                strcat(stmt5,")");
                
               printf("--- 705 qyear=[%d]stmt5=[%s]\n",qyear,stmt5);
                $PREPARE pre_ins from $stmt5;
                $EXECUTE pre_ins;

        }
        $CLOSE cur_A;

        if (fanother[0]=='Y') 
        {
                sprintf(stmt,
                "SELECT a.ipolicy,a.icard,a.dply_begin,a.ibrand,\
                        to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'),\
                        a.ibig_office,a.iquota[1,4]||'00',a.dpolicy,\
                        a.ipro_year,                                            \
                        nvl(mins_premium,0),                                    \
                        nvl(pdiscount,0),             \
                        nvl(mins_premium+mdiscount,0),\
                        b.iassured,b.iassured_ext,b.nassured[1,24],b.iapplicant,b.napplicant[1,24],\
                        b.iengine,b.itag,nvl(a.dendorse,' '),ibig_sales,\
                        a.fedr_class,today,icar_type, \
                        c.drate_ym, c.mdeduct, b.mcar_price, a.iofficer, \
                        NVL((SELECT sum(mins_premium) FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type in ('01','05','08','09')),0), \
                        NVL((SELECT mins_premium FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type = '14'),0), \
                        NVL((SELECT mins_premium FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type = '17'),0), \
                        NVL((SELECT sum(mins_premium) FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type in ('31','32')),0), \
                        NVL((SELECT mins_premium FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type = '51'),0)  \
                   FROM %s:ply_relation a, %s:policy b,outer %s:ply_ins_type c \
                   WHERE %s AND a.ipolicy = b.ipolicy %s \
                   AND a.ipolicy = c.ipolicy \
                   AND c.iins_type = '11' \
                   AND a.iofficer[1] = '%s' \
                   AND a.iofficer[%d,%d] = '%s' \
                   AND length(a.iofficer) = %d %s",
                list[j].dbname, list[j].dbname, list[j].dbname, list[j].dbname, list[j].dbname,
                list[j].dbname, list[j].dbname, list[j].dbname, stmt4, stmt2,
                iofficera_1, ioff_chk_bgna, ioff_chk_bgna+ioff_chk_lena-1,
                ioff_chka, lofficera, stmt_qnextyear);
printf("body1.stmt[%s]\n",stmt);
                $PREPARE a_ida FROM $stmt;
                $DECLARE cur_Aa CURSOR FOR a_ida;
                $OPEN cur_Aa;
                for(;;) 
                {
                        mprem=pdisc=mprem_ori=0;
                        mins_prem_01=mins_prem_14=mins_prem_17=0;
                        mins_prem_31=mins_prem_51=mins_damage=0;
                        
                        $FETCH cur_Aa
                          INTO $ipolicy,   $icard,       $dply_begin, $ibrand,
                       $iissue_ym, $ibig_office, $iquota,     $dpolicy,
                       $ipro_year, $mprem,       $pdisc,      $mprem_ori,
                       $iassured1, $iassured2,   $nassured,   $iapplicant, $napplicant,
                       $iengine,   $itag,        $dendorse,   $ibig_sales,
                       $fedr_class,$d_today,     $icar_type,
                       $frate_ym,  $mdeduct,     $car_price,  $iofficer,
                       $mins_prem_01, $mins_prem_14, $mins_prem_17, $mins_prem_31, $mins_prem_51;

                        if (SQLCODE == SQLNOTFOUND) break;

                        if (strcmp(dendorse,d_today)!=0 && strncmp(fedr_class,"1",1)==0)
                        continue;
         
                        strcpy( frate ,  frate_ym);

                        $EXECUTE pre_name INTO $iofficer_c    USING $iofficer;
                        if(SQLCODE == SQLNOTFOUND)
                        strcpy(iofficer_c, " ");
         
                        if (ibig_office[0]!=' ') {
                        $EXECUTE pre_bigo INTO $ibig_office_c
                                          USING $ibig_office;
                        if(SQLCODE == SQLNOTFOUND)
                                strcpy(ibig_office_c,ibig_office);
                        }
                        else strcpy(ibig_office_c," ");

                        $EXECUTE pre_nsales INTO $nsales USING $ibig_sales;
                        if (SQLCODE==SQLNOTFOUND)
                        strcpy(nsales," ");

                        $EXECUTE pre_type INTO $ncar_abbr USING $icar_type;
                        if (SQLCODE==SQLNOTFOUND)
                        strcpy(ncar_abbr," ");

                        if (strlen(trim(iassured1)) == 0 && strlen(trim(iassured2))==0)
                        iassured[0] ='\0';
                        else 
                        {
                        strcpy(iassured,rtrim(iassured1));
                        strcat(iassured,rtrim(iassured2));  
                        }

                        $OPEN curBX USING $ibrand;
                        $FETCH curBX INTO $nbrand_abbr,$nbrand,$tmp_ipro_year;
                        if(SQLCODE == SQLNOTFOUND) {
                        nbrand_abbr[0]='\0';
                        nbrand[0]='\0';
                        }
                        $CLOSE curBX;

                        $EXECUTE pre_nbranch INTO $Ngroup USING $iquota;
                        if(SQLCODE ==SQLNOTFOUND) Ngroup[0]='\0';

                        /* �p��n�~�ѵs�I�O�O */
                        rc = car6265_iins11_prem();
                        if ( rc != M_CM_OK )
                        {
                        return rc;
                        }
                        
                        /*-- Ū�j��O���� --*/                     
                        $declare cur_comp1 cursor for
                         select ipolicy,icard into $iply_comp,$icard_comp
                           from assured_vs_ply
                          where iengine = $iengine
                            and fcard_class = '1'
                            and ipolicy[6,7] in ('ZJ','ZB');
                        $open cur_comp1;
                        while(1) {
                           $fetch cur_comp1;
                           if (SQLCODE==SQLNOTFOUND) break;
                           strcpy(fulldb,get_car_full_db(iply_comp));
                           sprintf(stmt6,
                           "select mlia_prem from %s:ply_relation \
                             where ipolicy = ? and fedr_class != '1'",fulldb); 

                           $prepare pre_comp1 from $stmt6;
                           $execute pre_comp1 into $mprem_21 using $iply_comp;
                           if (SQLCODE==SQLNOTFOUND) {
                              strcpy(iply_comp," ");
                              strcpy(icard_comp," ");
                              mprem_21=0;
                           }
                           else break;
                        }
                        $close cur_comp1;
                        
                        
                        mprem_dmg = mins_prem_01;
                        
                        medr_dmg=medr_09=medr_exp=0;
                               
                        /*-- �p������O�O --*/
                        if (strncmp(fedr_class,"1",1)==0) {
                        sprintf(stmt1,"select iins_type,medr_expense \
                                         from %s:edr_relation a,%s:edr_ins_type b \
                                        where a.ipolicy = ? \
                                          and a.fedr_class = '1' \
                                          and a.dendorse is not null \
                                          and a.iendorse = b.iendorse \
                                          and iins_type in ('01','05','08','09') \
                                          and medrdmg_cover != 0 ",
                                list[j].dbname,list[j].dbname);
                        }
                        else {
                           sprintf(stmt1,"select iins_type,mexpense from %s:ply_ins_type \
                                           where ipolicy = ? and mdamage_cover != 0 \
                                             and iins_type in ('01','05','08','09') ", 
                                   list[j].dbname);
                        }
                        $prepare a_id11 from $stmt1;
                        $declare cur_A1a cursor for a_id11;
                        $open cur_A1a using $ipolicy;
                        $fetch cur_A1a into $iins_type,$mexpense;
                        if (SQLCODE == SQLNOTFOUND) strcpy(iins_type,"00");
                        $close cur_A1a;
                   
                        strcpy(iendorse," ");
                        if (strncmp(dendorse," ",1)!=0) {
                           sprintf(stmt1,
                                  "SELECT a.iendorse, b.medrins_prem, nvl(dedr_close,' ')\
                                    FROM %s:edr_relation a,%s:edr_ins_type b\
                                   WHERE ipolicy = ? \
                                     AND dendorse is not null \
                                     AND b.iins_type in ('01','05','08','09') \
                                     AND a.iendorse = b.iendorse",
                                  list[j].dbname,list[j].dbname);

                           $PREPARE a_id2 FROM $stmt1;
                           $DECLARE cur_Ba CURSOR FOR a_id2;
                           $OPEN cur_Ba USING $ipolicy;
                           for(;;) {
                              mprem_dmg1=0;
                              $FETCH cur_Ba
                                INTO $iendorse, $mprem_dmg1, $dedr_close;
                              if (SQLCODE == SQLNOTFOUND) break;
                              if (strncmp(dedr_close," ",1)==0) {
                                 mprem_dmg -= mprem_dmg1;
                              }
                              else {
                                 medr_dmg   += mprem_dmg1;
                              }
                              mprem1=medr_exp=0;
                              sprintf(stmt3,
                                 "select medrins_prem,medr_expense from %s:edr_ins_type \
                                   where iendorse = ? and iins_type = '09' \
                                     and iedr_type != '02' ",list[j].dbname);
                              $prepare pre_BBa from $stmt3; 
                              $execute pre_BBa into $mprem1,$medr_exp 
                                             using $iendorse;
                              medr_09 += mprem1;
                              mexp_09 += medr_exp;
                           }
                           $CLOSE cur_Ba;
                        }
                        if (strcmp(trim(iins_type),"09")==0) 
                           mprem_09 = mprem_dmg - mexpense;
                        else
                           mprem_09 = mprem_dmg - medr_dmg + medr_09 - medr_exp;
                           
                        mins_damage = mins_prem_01 - mprem_09;
                        
                        /* ����w��/�޲z���I�[��T�� */
                         sprintf(stmt_safe,"select iins_type,safe_rate,manage_rate from %s:ply_ins_type \
                                           where ipolicy = ? order by iins_type desc",fulldb);
                         $prepare pre_2d from $stmt_safe;
                         $declare cur_2d cursor for pre_2d;
		                   $open    cur_2d using $ipolicy;
		                   while(1) {
		                        $fetch cur_2d into $iins_type_safe,$tmp_safe,$tmp_manage;
		                        
		                        if (SQLCODE==SQLNOTFOUND) break;
		            
		                        strcpy(iins_type_safe, trim(iins_type_safe));
		                        iins=atoi(iins_type_safe);
		                        switch(iins) {
		                             case 9:
		                                  rSafe_09 = tmp_safe;
		                                  rMgmt_09 = tmp_manage;                                  
		                                  break;
		                             case 11:
		                                 rSafe_11 = tmp_safe;
		                                 rMgmt_11 = tmp_manage;
		                                 break; 
		                             case 14:
		                                  rSafe_14 = tmp_safe;
		                                  rMgmt_14 = tmp_manage;
		                                  break;                             
		                             case 17:
		                                 rSafe_17 = tmp_safe;
		                                 rMgmt_17 = tmp_manage;
		                                 break;                               
		                             case 31: case 32:
		                                 rSafe_31 = tmp_safe;
		                                 rMgmt_31 = tmp_manage;
		                                 break;        
		                             case 51: case 55:
		                                 rSafe_51 = tmp_safe;
		                                 rMgmt_51 = tmp_manage;
		                                 break;                                                                                       
		                         }
		                    }
                          $close cur_2d;
                          $free cur_2d;
                         /* end of ����w��/�޲z���I�[��T�� */
         
                        strcpy(stmt5,"insert into car6265 values (");
                        sprintf(stmt5,"%s '%s', \
                        '%s','%s','%s','%s','%s', \
                        '%s','%s','%s', '%s','%s', \
                        '%s','%s','%s','%s','%s', \
                        '%s', '%s','%s','%s','%s', \
                        '%s','%s','%s',%d,%d, \
                        %d,%d,%d,%d,'%s',\
                        '%s',%d,%d,%f,%d",
                        stmt5,iquota,
                        Ngroup, icard, ipolicy, iassured, nassured, 
                        iapplicant, napplicant, dpolicy, dply_begin, icar_type,
                        ncar_abbr,ibrand, nbrand_abbr,nbrand,iengine,
                        iissue_ym,iofficer,iofficer_c,ibig_office,ibig_office_c,
                        ibig_sales, nsales,itag,mprem_09,mins_damage,
                        mins_prem_17, mins_prem_31,mins_prem_14,mins_prem_51, icard_comp,
                        iply_comp,mprem_21,mprem,pdisc,mprem_ori);
                        
                        
                        for(i=1;i<qyear;i++)
                           sprintf(stmt5,"%s,%d,%f,%d",
                                   stmt5, yprem[i].mins_premium, pdisc, yprem[i].mprem);
                           
                        sprintf(stmt5,"%s, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f, %f",
                        stmt5, rSafe_09,rSafe_17,rSafe_31,rSafe_51,rSafe_14,rSafe_11,
                        rMgmt_09,rMgmt_17,rMgmt_31,rMgmt_51,rMgmt_14,rMgmt_11);
                        
                        strcat(stmt5,")");

                        $PREPARE pre_ins1 from $stmt5;
                        $EXECUTE pre_ins1;

                }
                $CLOSE cur_Aa;
        }
        } 
        $FREE  cur_A;
        $FREE  cur_Aa;

        return M_CM_OK;
   
errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE; 
}

/*--------------------------------------------------------------------*/
long car6265_body2()
{
        int   j;
        $char stmt1[4096],stmt[4096],stmt2[512],stmt_qnextyear[512],stmt_safe[1024];
        char  tit[41];
        char  sequip_str[21];
        char  iequip_tmp[3];
        int   iequip_flag;

        $WHENEVER SQLERROR GOTO errexit;

        $create temp table car6265_1
         (iquota char(10), ngroup char(20),icard char(20),ipolicy char(20),
          iendorse char(20),iassured char(10),nassured char(24),iapplicant char(12),napplicant char(24),
          dpolicy date,dply_begin date,icar_type char(2),
          ncar_abbr char(12),ibrand char(8),nbrand_abbr char(10),
          nbrand char(20),iengine char(20),iissue_ym char(6),
          iofficer char(10),nofficer char(10),ibig_office char(10),
          nbig_office char(10),ibig_sales char(10),nsales char(10),
          itag char(12),mprem_01 integer,mprem_17 integer, mprem_31 integer,
          mprem_51 integer, mprem_14 integer, dpolicy_ply date,mprem_11 integer,
          pdisc decimal(6,2),mori_11 integer,rSafe_dmg decimal(9,7),rSafe_17 decimal(9,7),
          rSafe_31 decimal(9,7),rSafe_51 decimal(9,7),rSafe_14 decimal(9,7),
          rSafe_11 decimal(9,7),rMgmt_dmg decimal(9,7),rMgmt_17 decimal(9,7),
          rMgmt_31 decimal(9,7),rMgmt_51 decimal(9,7),rMgmt_14 decimal(9,7),rMgmt_11 decimal(9,7)) with no log;

        if (strncmp(fply_close,"1",1)==0) 
        strcpy(stmt2," AND a.dedr_close is not null ");
        else
        strcpy(stmt2," ");

        for(j=0;j<count_db;j++) 
        {
        /* sprintf(stmt,
             "SELECT a.ipolicy,a.icard,b.dply_begin,a.ibrand,\
                     to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'),\
                     a.ibig_office,a.iquota[1,4]||'00',a.dendorse, a.ipro_year,\
                     e.medrins_prem,d.pdiscount,e.medrins_prem+e.medr_discount,\
                     b.iassured,b.iassured_ext,b.nassured[1,24],b.iapplicant,b.napplicant[1,24],\
                     b.iengine,b.itag,a.dendorse,a.ibig_sales,c.dpolicy,a.iendorse,a.iofficer, \
                     NVL((SELECT sum(medrins_prem) FROM %s:edr_ins_type WHERE iendorse = a.iendorse and iins_type in ('01','05','08','09')),0), \
                     NVL((SELECT medrins_prem FROM %s:edr_ins_type WHERE iendorse = a.iendorse and iins_type = '14'),0), \
                     NVL((SELECT medrins_prem FROM %s:edr_ins_type WHERE iendorse = a.iendorse and iins_type = '17'),0), \
                     NVL((SELECT sum(medrins_prem) FROM %s:edr_ins_type WHERE iendorse = a.iendorse and iins_type in ('31','32')),0), \
                     NVL((SELECT medrins_prem FROM %s:edr_ins_type WHERE iendorse = a.iendorse and iins_type = '51'),0), \
                     a.icar_type \
                FROM %s:edr_relation a, %s:endorsement b, \
                     %s:ply_relation c, %s:ply_ins_type d, \
                     %s:edr_ins_type e \
               WHERE a.dendorse>= ? AND a.dendorse<= ? %s \
               AND   a.iendorse = b.iendorse \
               AND   a.ipolicy  = c.ipolicy \
               AND   a.ipolicy  = d.ipolicy \
               AND   a.iendorse = e.iendorse \
               AND   d.iins_type= e.iins_type \
               AND   e.iins_type= '11' \
               AND   a.fedr_class = '1' \
               AND   a.iofficer[1] = '%s' \
               AND   a.iofficer[%d,%d] = '%s' \
               AND   length(a.iofficer) = %d",
             list[j].dbname, list[j].dbname, list[j].dbname, list[j].dbname, list[j].dbname,
             list[j].dbname, list[j].dbname, list[j].dbname, list[j].dbname, list[j].dbname,
             stmt2, iofficer_1, ioff_chk_bgn,
             ioff_chk_bgn+ioff_chk_len-1, ioff_chk, lofficer); */
        sprintf(stmt,
             "SELECT a.ipolicy,a.icard,b.dply_begin,a.ibrand,\
                     to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'),\
                     a.ibig_office,a.iquota[1,4]||'00',a.dendorse, a.ipro_year,\
                     e.medrins_prem,d.pdiscount,e.medrins_prem+e.medr_discount,\
                     b.iassured,b.iassured_ext,b.nassured[1,24],b.iapplicant,b.napplicant[1,24],\
                     b.iengine,b.itag,a.dendorse,a.ibig_sales,c.dpolicy,a.iendorse,a.iofficer, \
                     NVL((SELECT sum(medrins_prem) FROM %s:edr_ins_type WHERE iendorse = a.iendorse and iins_type in ('01','05','08','09')),0), \
                     NVL((SELECT medrins_prem FROM %s:edr_ins_type WHERE iendorse = a.iendorse and iins_type = '14'),0), \
                     NVL((SELECT medrins_prem FROM %s:edr_ins_type WHERE iendorse = a.iendorse and iins_type = '17'),0), \
                     NVL((SELECT sum(medrins_prem) FROM %s:edr_ins_type WHERE iendorse = a.iendorse and iins_type in ('31','32')),0), \
                     NVL((SELECT medrins_prem FROM %s:edr_ins_type WHERE iendorse = a.iendorse and iins_type = '51'),0), \
                     a.icar_type \
                FROM %s:edr_relation a, %s:endorsement b, \
                     %s:ply_relation c, %s:ply_ins_type d, \
                     %s:edr_ins_type e \
               WHERE a.dendorse>= ? AND a.dendorse<= ? %s \
               AND   a.iendorse = b.iendorse \
               AND   a.ipolicy  = c.ipolicy \
               AND   a.ipolicy  = d.ipolicy \
               AND   a.iendorse = e.iendorse \
               AND   d.iins_type= e.iins_type \
               AND   e.iins_type= '11' \
               AND   a.fedr_class = '1' \
               AND   a.iofficer in (select unique iofficer_ori from ca_promote_officer where iprmt = '%s') ",
             list[j].dbname, list[j].dbname, list[j].dbname, list[j].dbname, list[j].dbname,
             list[j].dbname, list[j].dbname, list[j].dbname, list[j].dbname, list[j].dbname,
             stmt2,iprmt );
                
        $PREPARE a_id3 FROM $stmt;
        $DECLARE cur_C CURSOR FOR a_id3;
        $OPEN cur_C USING $dbgn_inf,$dend_inf;
        for(;;) 
        {
                mprem=pdisc=mprem_ori=0;
                mins_prem_01=mins_prem_14=mins_prem_17=0;
                mins_prem_31=mins_prem_51=0;
                
                $FETCH cur_C
                  INTO $ipolicy,$icard,$dply_begin,$ibrand,$iissue_ym,
                   $ibig_office,$iquota,$dpolicy,$ipro_year,
                   $mprem,$pdisc,$mprem_ori,
                   $iassured1,$iassured2,$nassured,$iapplicant,$napplicant,$iengine,
                   $itag,$dendorse,$ibig_sales,$ori_dpolicy,
                   $iendorse,$iofficer, $mins_prem_01,
                   $mins_prem_14, $mins_prem_17, $mins_prem_31, $mins_prem_51, $icar_type;
                if (SQLCODE == SQLNOTFOUND) break;

                $EXECUTE pre_name INTO $iofficer_c USING $iofficer;
                if(SQLCODE == SQLNOTFOUND)
                strcpy(iofficer_c,iofficer);

                $EXECUTE pre_bigo INTO $ibig_office_c USING $ibig_office;
                if(SQLCODE == SQLNOTFOUND)
                strcpy(ibig_office_c,ibig_office);

                $EXECUTE pre_nsales into $nsales USING $ibig_sales;
                if (SQLCODE==SQLNOTFOUND)
                strcpy(nsales," ");

                $EXECUTE pre_type INTO $ncar_abbr USING $icar_type;
                if (SQLCODE==SQLNOTFOUND)
                strcpy(ncar_abbr," ");

                if (strlen(trim(iassured1)) == 0 && strlen(trim(iassured2))==0)
                iassured[0] ='\0';
                else
                { 
                        strcpy(iassured,rtrim(iassured1));
                strcat(iassured,rtrim(iassured2));  
            }

                $OPEN curBX USING $ibrand;
                $FETCH curBX INTO $nbrand_abbr,$nbrand,$ipro_year;
                if(SQLCODE == SQLNOTFOUND)
                {
                        nbrand_abbr[0]='\0';
                nbrand[0]='\0'; 
            }
                $CLOSE curBX;

                $EXECUTE pre_nbranch INTO $Ngroup USING $iquota;
                if(SQLCODE ==SQLNOTFOUND) Ngroup[0]='\0';
                
                /* ����w��/�޲z���I�[��T�� */                
                    sprintf(stmt_safe,"select iins_type,safe_rate,manage_rate from %s:ply_ins_type \
                                       where ipolicy = ? order by iins_type desc",fulldb);
                    $prepare pre_3d from $stmt_safe;
                    $declare cur_3d cursor for pre_3d;
		              $open    cur_3d using $ipolicy;
		               while(1) {
		                        $fetch cur_3d into $iins_type_safe,$tmp_safe,$tmp_manage;
		                        
		                        if (SQLCODE==SQLNOTFOUND) break;
		            
		                        strcpy(iins_type_safe, trim(iins_type_safe));
		                        iins=atoi(iins_type_safe);
		                        switch(iins) {
		                             case 1: case 5: case 8: case 9:
		                                  rSafe_dmg = tmp_safe;
		                                  rMgmt_dmg = tmp_manage;                                  
		                                  break;
		                             case 11:
		                                 rSafe_11 = tmp_safe;
		                                 rMgmt_11 = tmp_manage;
		                                 break; 
		                             case 14:
		                                  rSafe_14 = tmp_safe;
		                                  rMgmt_14 = tmp_manage;
		                                  break;                             
		                             case 17:
		                                 rSafe_17 = tmp_safe;
		                                 rMgmt_17 = tmp_manage;
		                                 break;                               
		                             case 31: case 32:
		                                 rSafe_31 = tmp_safe;
		                                 rMgmt_31 = tmp_manage;
		                                 break;        
		                             case 51: case 55:
		                                 rSafe_51 = tmp_safe;
		                                 rMgmt_51 = tmp_manage;
		                                 break;                                                                                       
		                         }
		               }
                     $close cur_3d;
                     $free cur_3d;
                /* end of ����w��/�޲z���I�[��T�� */

                $INSERT INTO car6265_1 VALUES (
                 $iquota,$Ngroup,$icard,$ipolicy,$iendorse,$iassured,$nassured,
                 $iapplicant,$napplicant,
                 $dpolicy,$dply_begin,$icar_type,$ncar_abbr,$ibrand,
                 $nbrand_abbr,$nbrand,$iengine,$iissue_ym,$iofficer,
                 $iofficer_c,$ibig_office,$ibig_office_c,$ibig_sales,
                 $nsales,$itag,$mins_prem_01,$mins_prem_17,$mins_prem_31,
                 $mins_prem_51,$mins_prem_14,$ori_dpolicy,
                 $mprem,$pdisc,$mprem_ori,
                 $rSafe_dmg,$rSafe_17,$rSafe_31,$rSafe_51,$rSafe_14,$rSafe_11,
                 $rMgmt_dmg,$rMgmt_17,$rMgmt_31,$rMgmt_51,$rMgmt_14,$rMgmt_11);

        }
        $CLOSE cur_C;

        if (fanother[0]=='Y') 
        {
                sprintf(stmt,
                    "SELECT a.ipolicy,a.icard,b.dply_begin,a.ibrand,\
                            to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'),\
                            a.ibig_office,a.iquota[1,4]||'00',a.dendorse, a.ipro_year,\
                            e.medrins_prem,d.pdiscount,e.medrins_prem+e.medr_discount,\
                            b.iassured,b.iassured_ext,b.nassured[1,24],iapplicant,napplicant[1,24],\
                            b.iengine,b.itag,a.dendorse,a.ibig_sales,c.dpolicy,a.iendorse,a.iofficer, \
                            NVL((SELECT sum(medrins_prem) FROM %s:edr_ins_type WHERE iendorse = a.iendorse and iins_type in ('01','05','08','09')),0), \
                            NVL((SELECT medrins_prem FROM %s:edr_ins_type WHERE iendorse = a.iendorse and iins_type = '14'),0), \
                            NVL((SELECT medrins_prem FROM %s:edr_ins_type WHERE iendorse = a.iendorse and iins_type = '17'),0), \
                            NVL((SELECT sum(medrins_prem) FROM %s:edr_ins_type WHERE iendorse = a.iendorse and iins_type in ('31','32')),0), \
                            NVL((SELECT medrins_prem FROM %s:edr_ins_type WHERE iendorse = a.iendorse and iins_type = '51'),0),a.icar_type \
                       FROM %s:edr_relation a, %s:endorsement b, \
                            %s:ply_relation c, %s:ply_ins_type d, \
                            %s:edr_ins_type e \
                      WHERE a.dendorse>= ? AND a.dendorse<= ? %s \
                      AND   a.iendorse = b.iendorse \
                      AND   a.ipolicy  = c.ipolicy \
                      AND   a.ipolicy  = d.ipolicy \
                      AND   a.iendorse = e.iendorse \
                      AND   d.iins_type= e.iins_type \
                      AND   e.iins_type= '11' \
                      AND   a.fedr_class = '1' \
                      AND   a.iofficer[1] = '%s' \
                      AND   a.iofficer[%d,%d] = '%s' \
                      AND   length(a.iofficer) = %d ",
                    list[j].dbname,list[j].dbname,list[j].dbname,list[j].dbname,list[j].dbname,
                    list[j].dbname,list[j].dbname,list[j].dbname,list[j].dbname,
                    list[j].dbname,stmt2,iofficera_1,ioff_chk_bgna,
                    ioff_chk_bgna+ioff_chk_lena-1,ioff_chka,lofficera);
                        
                $PREPARE a_id3a FROM $stmt;
                $DECLARE cur_Ca CURSOR FOR a_id3a;
                $OPEN cur_Ca USING $dbgn_inf,$dend_inf;
                for(;;) 
                {
                        mprem=pdisc=mprem_ori=0;
                        mins_prem_01=mins_prem_14=mins_prem_17=0;
                        mins_prem_31=mins_prem_51=0;
                        
                        $FETCH cur_Ca
                          INTO $ipolicy,$icard,$dply_begin,$ibrand,$iissue_ym,
                       $ibig_office,$iquota,$dpolicy,$ipro_year,
                       $mprem,$pdisc,$mprem_ori,
                       $iassured1,$iassured2,$nassured,$iapplicant,$napplicant,$iengine,
                       $itag,$dendorse,$ibig_sales,$ori_dpolicy,
                       $iendorse,$iofficer,$mins_prem_01,
                       $mins_prem_14,$mins_prem_17,$mins_prem_31,$mins_prem_51,$icar_type;
                        if (SQLCODE == SQLNOTFOUND) break;

                        $EXECUTE pre_name INTO $iofficer_c USING $iofficer;
                        if(SQLCODE == SQLNOTFOUND)
                             strcpy(iofficer_c,iofficer);

                        $EXECUTE pre_bigo INTO $ibig_office_c USING $ibig_office;
                        if(SQLCODE == SQLNOTFOUND)
                             strcpy(ibig_office_c,ibig_office);

                        $EXECUTE pre_nsales into $nsales USING $ibig_sales;
                        if (SQLCODE==SQLNOTFOUND)
                             strcpy(nsales," ");

                        $EXECUTE pre_type INTO $ncar_abbr USING $icar_type;
                        if (SQLCODE==SQLNOTFOUND)
                             strcpy(ncar_abbr," ");

                        if (strlen(trim(iassured1)) == 0 && strlen(trim(iassured2))==0)
                             iassured[0] ='\0';
                        else
                        { 
                             strcpy(iassured,rtrim(iassured1));
                             strcat(iassured,rtrim(iassured2));  
                        }

                        $OPEN curBX USING $ibrand;
                        $FETCH curBX INTO $nbrand_abbr,$nbrand,$ipro_year;
                        if(SQLCODE == SQLNOTFOUND)
                        {
                                nbrand_abbr[0]='\0';
                                nbrand[0]='\0'; 
                        }
                        $CLOSE curBX;

                        $EXECUTE pre_nbranch INTO $Ngroup USING $iquota;
                        if(SQLCODE ==SQLNOTFOUND) Ngroup[0]='\0';
                        
                         /* ����w��/�޲z���I�[��T�� */                
                            sprintf(stmt_safe,"select iins_type,safe_rate,manage_rate from %s:ply_ins_type \
                                               where ipolicy = ? order by iins_type desc",fulldb);
                            $prepare pre_4d from $stmt_safe;
                            $declare cur_4d cursor for pre_4d;
		                      $open    cur_4d using $ipolicy;
		                      while(1) {
		                            $fetch cur_4d into $iins_type_safe,$tmp_safe,$tmp_manage;
		                            
		                            if (SQLCODE==SQLNOTFOUND) break;
		            
		                            strcpy(iins_type_safe, trim(iins_type_safe));
		                            iins=atoi(iins_type_safe);
		                            switch(iins) {
		                             case 1: case 5: case 8: case 9:
		                                  rSafe_dmg = tmp_safe;
		                                  rMgmt_dmg = tmp_manage;                                  
		                                  break;
		                             case 11:
		                                 rSafe_11 = tmp_safe;
		                                 rMgmt_11 = tmp_manage;
		                                 break; 
		                             case 14:
		                                  rSafe_14 = tmp_safe;
		                                  rMgmt_14 = tmp_manage;
		                                  break;                             
		                             case 17:
		                                 rSafe_17 = tmp_safe;
		                                 rMgmt_17 = tmp_manage;
		                                 break;                               
		                             case 31: case 32:
		                                 rSafe_31 = tmp_safe;
		                                 rMgmt_31 = tmp_manage;
		                                 break;        
		                             case 51: case 55:
		                                 rSafe_51 = tmp_safe;
		                                 rMgmt_51 = tmp_manage;
		                                 break;                                                                                       
		                         }
		                     }
                           $close cur_4d;
                           $free cur_4d;
                        /* end of ����w��/�޲z���I�[��T�� */
                        

                        $INSERT INTO car6265_1 VALUES (
                           $iquota,$Ngroup,$icard,$ipolicy,$iendorse,$iassured,
                           $nassured,$iapplicant,$napplicant,$dpolicy,$dply_begin,$icar_type,
                           $ncar_abbr,$ibrand,$nbrand_abbr,$nbrand,
                           $iengine,$iissue_ym,$iofficer,$iofficer_c,
                           $ibig_office,$ibig_office_c,$ibig_sales,
                           $nsales,$itag,$mins_prem_01,$mins_prem_17,
                           $mins_prem_31,$mins_prem_51,$mins_prem_14,
                           $ori_dpolicy,$mprem,$pdisc,$mprem_ori,
                           $rSafe_dmg,$rSafe_17,$rSafe_31,$rSafe_51,$rSafe_14,$rSafe_11,
                           $rMgmt_dmg,$rMgmt_17,$rMgmt_31,$rMgmt_51,$rMgmt_14,$rMgmt_11);

                }
                $CLOSE cur_Ca;
        }
    }
    $FREE cur_C;
    $FREE cur_Ca;
    $FREE  curBX;

    return M_CM_OK;

errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car6265_iins11_prem()
{
        char dyy[4],dmm[3],ddd[3];
        int  code,i;
        double ins_premium , pure_ins_premium , short_prate ; 
        double cal_ins_premium , cal_discount , mins_discount , mins_premium;
        $int dyy1, model_year, t_ipro_year , cal_pro_year;
        $char s5_iproyear[6];
   
        $WHENEVER sqlerror goto errexit;   
   
        /** �M�� struct ���� **/
        for(i=0;i<qyear;i++)
        {
        yprem[i].mins_premium = 0;
        yprem[i].mprem = 0;
        }
   
        if( mdeduct <= 0 )
        {
        /* ��h�A���p��O�O�F */
        /* ���U��n�~���O�O����0 */
        return M_CM_OK;
        }
   
        short_prate = 1.0;        
        /* Step 1 SELECT �t�P������ */ 
   
        $SELECT mcar_price  ,icar_type    ,fuse_type  ,qpassenger  ,icar_series
       INTO $mcar_price ,$icar_type_1 ,$fuse_type ,$qpassenger ,$icar_series
       FROM ca_car_model
      WHERE ibrand    = $ibrand
        AND ipro_year = $ipro_year
        AND drate     = (SELECT drate
                           FROM ca_rate_date
                          WHERE icode  = $frate
                            AND itable = 'ca_car_model'); 
    if (SQLCODE==SQLNOTFOUND)
    {
        $DECLARE CA_OPT1_3A CURSOR FOR
          SELECT mcar_price  ,icar_type    ,fuse_type  ,qpassenger  ,icar_series  ,ipro_year
            INTO $mcar_price ,$icar_type_1 ,$fuse_type ,$qpassenger ,$icar_series
            FROM ca_car_model
           WHERE ibrand    = $ibrand
             AND ipro_year > $ipro_year
             AND drate     = (SELECT drate
                                FROM ca_rate_date
                               WHERE icode  = $frate
                                 AND itable = 'ca_car_model')
           ORDER BY ipro_year;
        $OPEN  CA_OPT1_3A;
        $FETCH CA_OPT1_3A;
        if (SQLCODE==SQLNOTFOUND) 
        {
            $DECLARE CA_OPT3B_305 CURSOR FOR
              SELECT mcar_price  ,icar_type,   fuse_type  ,qpassenger  ,icar_series  ,ipro_year
                INTO $mcar_price ,$icar_type_1,$fuse_type ,$qpassenger ,$icar_series
                FROM ca_car_model
               WHERE ibrand    = $ibrand
                 AND ipro_year < $ipro_year
                 AND drate     = (SELECT drate
                                    FROM ca_rate_date
                                   WHERE icode  = $frate
                                     AND itable = 'ca_car_model')
               ORDER BY ipro_year DESC;
            $OPEN  CA_OPT3B_305;
            $FETCH CA_OPT3B_305;
            if (SQLCODE==SQLNOTFOUND)
            {
                return M_CA_NBRAND;
                $CLOSE CA_OPT3B_305;
                $FREE  CA_OPT3B_305;
            }
            $CLOSE CA_OPT3B_305;
        }
        $CLOSE CA_OPT1_3A;
        $FREE  CA_OPT1_3A;
    }

        /* Step 2 check �ۥ���~���O */
        $SELECT fcar_class
       INTO $fcar_class2
       FROM car_type
      WHERE fclass='1'
        AND icode=$icar_type_1; 
    
    /*** STEP 3 check insurance 11 ***/
    /*** STEP 4 ���w�����j���ؤ��@
                ���ѵs�O�v�N������ѵs�I�O�v�N���Y��   ***/ 
    
    $SELECT ibrg_rate  , ipro_year
       INTO $ibrg_rate , $cal_pro_year
       FROM ca_car_model
      WHERE ibrand    = $ibrand
        AND ipro_year = $ipro_year
        AND drate     = (SELECT drate
                           FROM ca_rate_date
                          WHERE icode  = $frate
                            AND itable = 'ca_car_model');
    if(SQLCODE==SQLNOTFOUND)
    {
        $DECLARE CA_OPT11 CURSOR FOR
          SELECT ibrg_rate  , ipro_year
            INTO $ibrg_rate , $cal_pro_year
            FROM ca_car_model
           WHERE ibrand    = $ibrand
             AND ipro_year > $ipro_year
             AND drate     = (SELECT drate
                                FROM ca_rate_date
                               WHERE icode  = $frate
                                 AND itable = 'ca_car_model')
           ORDER BY ipro_year;

        $OPEN  CA_OPT11;
        $FETCH CA_OPT11;
        if (SQLCODE==SQLNOTFOUND)
        {
            $DECLARE CA_OPT11_1 CURSOR FOR
              SELECT ibrg_rate  , ipro_year
                INTO $ibrg_rate , $cal_pro_year
                FROM ca_car_model
               WHERE ibrand    = $ibrand
                 AND ipro_year < $ipro_year
                 AND drate     = (SELECT drate
                                    FROM ca_rate_date
                                   WHERE icode  = $frate
                                     AND itable = 'ca_car_model')
               ORDER BY ipro_year DESC;

               $OPEN  CA_OPT11_1;
               $FETCH CA_OPT11_1;
               if (SQLCODE==SQLNOTFOUND)
               {
                   $CLOSE CA_OPT11_1;
                   $FREE  CA_OPT11_1;
                   return M_CA_NBRAND;
               }
               $CLOSE CA_OPT11_1;
        }
        $CLOSE CA_OPT11;
        $FREE  CA_OPT11;
    }
    
    /*** STEP 5 �إ� car_model_factor EX:�O�v07 ***/
    /*** ��Table:
         2003   2002    2001    2000    <=1999
         1.00   0.76    0.56    0.38    0.22
         �إ�Temp Table 
         2003   2004    2005    2006    2007
         1.00   0.76    0.56    0.38    0.22  ***/
    
    $CREATE TEMP TABLE temp_model_factor
    (
       ipro_year  char(4) default ' ',
       pfactor    decimal(7,4)  default 0.0000
    )
    WITH NO LOG;
    
    $CREATE INDEX model_factor_ix1 ON temp_model_factor( ipro_year );
    
    strcpy(dply_begin_1 , cm_from_infdate_100(dply_begin));
    cm_split_ymd_100(dply_begin_1,dyy,dmm,ddd);
    dyy1=atoi(dyy)+1911;
    
    $DECLARE cur_model CURSOR for
      SELECT ipro_year, pfactor
        FROM car_model_factor
       WHERE fdmg_brg  = '2'
         AND irate     = $ibrg_rate
         AND drate     = (SELECT drate
                            FROM ca_rate_date
                           WHERE icode  = $frate
                            AND itable = 'car_model_factor')
       ORDER BY ipro_year DESC;
     
    $OPEN cur_model;
    for( model_year = dyy1 ; ; model_year++ )
    {
        $FETCH cur_model INTO $t_ipro_year, $brg_factor;
        if( SQLCODE == SQLNOTFOUND ) break;                
        
        $INSERT INTO temp_model_factor( ipro_year, pfactor )
         VALUES ($model_year, $brg_factor );
    }
    $CLOSE cur_model;
    $FREE  cur_model;
    
   /* 6 ~ 10 years */
    if (qyear > 5) {
    for(i=1;i<6;i++)
    {
        model_year = model_year + i;

        $INSERT INTO temp_model_factor( ipro_year, pfactor )
         VALUES ($model_year, $brg_factor );

    }
    }

    /*** STEP 6 get �򥻫O�O,�p��v,�p���I��,������� ***/
    $SELECT prate, mprem, ical_ins, fcal_class, pextra_charge/100
       INTO $prate_1, $rate_prem, $ical_ins, $fcal_class, $pextra_charge
       FROM ca_rate
      WHERE icar_type = $icar_type_1
        AND iins_type = '11'
        AND mdeduct   = $mdeduct
        AND qpt_bgn  <= 0
        AND qpt_end  >= 0
        AND drate     = (SELECT drate
                           FROM ca_rate_date
                          WHERE icode  = $frate
                            AND itable = 'ca_rate');
                            
    if (SQLCODE==SQLNOTFOUND) return M_CA_NRATE;
    
    prate_1=prate_1/100.0;        
    
    /*** �}�l�p�Ⱶ�U�Ӫ�n�~�O�O ***/
    
    for( i = 1 ; i < qyear ; i ++ )
    {
       /* �s�@�ӫO�_�� */
       strcpy(dply_begin_1 , cm_from_infdate_100(dply_begin));
       cm_split_ymd_100(dply_begin_1,dyy,dmm,ddd);
       
       dply_begin_1[0] = dmm[0];
       dply_begin_1[1] = dmm[1];
       dply_begin_1[2] = '/';
       dply_begin_1[3] = ddd[0];
       dply_begin_1[4] = ddd[1];
       dply_begin_1[5] = '/';
       
       dyy1=atoi(dyy);
       dyy1=dyy1+1911+i;
       strcpy( dyy , itoa(dyy1) );
       
       dply_begin_1[6] = dyy[0];
       dply_begin_1[7] = dyy[1];
       dply_begin_1[8] = dyy[2];
       dply_begin_1[9] = dyy[3];
       
       rstrdate( dply_begin_1, &ply2_begin );
       
       /** Step 1 SetCarAge **/
       code = SetCarAge();
       
       /** Step 2 Ū���ӫO�_���~�ת� brg_factor **/
       
       $SELECT pfactor
          INTO $brg_factor
          FROM temp_model_factor
         WHERE ipro_year = $dyy1;
       
       /** Step 3 �p��M�I�O�O **/
       {
          adj_age = int_ply_yr - atoi(ipro_year);
          if (adj_age > 4) adj_age = 4;
          adj_yr_dep = MyPower(0.75, adj_age);

          tmp_cover_dep = (int)(car_price*10000.0*adj_yr_dep);
          thousand_cover_dep = tmp_cover_dep % 1000;
          
          if (thousand_cover_dep != 0)
          {
              cover_dep    = (tmp_cover_dep)-(thousand_cover_dep)+1000;
              cover_dep_11 = tmp_cover_dep - thousand_cover_dep;
          }
          else
          {
              cover_dep    = tmp_cover_dep;
              cover_dep_11 = tmp_cover_dep;
          }
          
          /*printf("\n");
          printf("11@@@@@ car_price[%f] brg_factor[%f]\n",car_price,brg_factor);
          printf("11@@@@@ cover_01_11[%ld], cover_dep_11[%ld]\n",cover_01_11,cover_dep_11);
          printf("PREM=car_price*prate_1*short_prate*brg_factor\n");
          printf("                      *(cover_01_11/cover_dep_11)\n");*/
          

          /* �«O�O(���p���I) */
          ins_premium     = car_price*10000.0*prate_1*short_prate*brg_factor
                            *((double)cover_01_11/(double)cover_dep_11);
          
       }              
       
       /** Step 4 �p��W���O�O **/
       {
          /* �«O�O(�|�ˤ��J) */
          pure_ins_premium   = (long)(ins_premium+0.5);
          
          /* �W���O�O(�|�ˤ��J) */
          cal_ins_premium = (long)(dbl_len8(ins_premium)/(1.0-pextra_charge)+0.5);                    
       }
       
       /** Step 5 �p��������B�Añ��O�O **/
       {
          
          cal_discount = 32.75;
          
          mins_discount = (long)( cal_ins_premium*cal_discount/100 + 0.5 );
          
          mins_premium = cal_ins_premium - mins_discount;
          
       }
      
       /** �p��X���O�O�g�J struct ���A�C�L��... **/ 
       yprem[i].mins_premium = mins_premium;
       yprem[i].mprem = cal_ins_premium;
       
    }
    
    
    $DROP TABLE temp_model_factor;
    
    return M_CM_OK;
    
errexit:
    printf("error in car6265_iins11_prem \n");
    printf("ERROR CODE = [%d] \n", SQLCODE );
    return SQLCODE;
}

/*****************************************************************/
static int SetCarAge()
{
    char   iissue_ymd[12];         /* extend CY/MM to CY/MM/DD */
    char   datestring[16], yy[4], mm[3], dd[3], yy2[4], mm2[3];
    int    yy1,mm1,yy3,mm3;
    long   iissue_date;
    $int   count_x=0;
    

    /*** STEP 3 -- a. ; here we calculate car_age, year_dep ...etc.  ***/
    
    /*** STEP 3.2 -- b. ***/
    sprintf(iissue_ymd,"%s/01",iissue_ym);
    iissue_date=cm_ymd_cdate(iissue_ymd);
    car_age=DiffMonth(ply2_begin,iissue_date);
    car_age_mth=car_age % 12;

    

    /** for flag_new **/
    strcpy(datestring,cm_cdate_str_100(ply2_begin));
    cm_split_ymd_100(datestring,yy,mm,dd);
    yy1=atoi(yy);
    int_ply_yr=yy1+1911; /* int_ply_yr for iins_type 11 */
    mm1=atoi(mm);

    strncpy(yy2,iissue_ym,2);
    yy2[2]='\0';
    strncpy(mm2,&iissue_ym[3],2);
    mm2[2]='\0';
    yy3=atoi(yy2);
    mm3=atoi(mm2);
    
    /*
    if (yy3-yy1>0 || (yy3-yy1==0 && mm3-mm1>=0))
         flag_new=TRUE;
    else flag_new=FALSE;  */

    /*** STEP 3.3 �~���� ***/
    
    if (fcar_class2[0]=='1') /* �ۥΨ� */  
        year_dep=MyPower(0.75, car_age/12);
    else
        year_dep=MyPower(0.70, car_age/12);

    /*** SETP 3.4 ����� ***/
    
    pdepreciate=0.0;
    
    /*** SETP 3.5 �p��O�I���B�B����«᪺�O�I���B ***/
    cover_01_tmp = car_price*10000.0*year_dep*(1.0-pdepreciate);
    thousand_cover_01 = cover_01_tmp % 1000;
    if (thousand_cover_01 != 0)
    {
        cover_01 = (cover_01_tmp)-(thousand_cover_01);
        cover_01_11 = cover_01_tmp - thousand_cover_01;
    }
    else
    {
        cover_01 = cover_01_tmp;
        cover_01_11 = cover_01_tmp;
    }

    return SUCCESS;
}

/*****************************************************************/
static int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
    short mdy1[3], mdy2[3];
    int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
    return datediff;
}

/*****************************************************************/
static float MyPower(f1, i1)
float f1;
int i1;
{
    int i;
    float ff=1.0;

    for (i=0; i<i1; i++)
    {
        ff=ff*f1;
    }
    return ff;
}
/*******************/
