/**********************************************************
 *
 *   car_fun.ec
 *
 **********************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include <carmsgs.h>
#include "rinmsgs.h"
#include <stdlib.h>
#include <decimal.h>
#include "globdata.h"  
#include <math.h>
#include <time.h>
#include "safeclib.h"
$include sqlca;

long  bk_edr_last();
long  update_edr_last();
long  chk_upd_edr_last();

long update_edr_last(iopt,i_ipolicy,i_iendorse,fedr_face,user)
$int  iopt;
$char i_ipolicy[21];
$char i_iendorse[21];
$char fedr_face[2];
$char user[11];
{
time_t current_secs;
struct tm *tm_now;
$char curtime[30];
$int  SQLCODE_TMP;
$char Errmsg[200];
$char fulldbname[31];
$char stmt[4096];
$char p_ipolicy[21];
$char p_ilast_ply_ori[21];
$char p_ilast_card_ori[21];
$char p_inext_ply_ori[21];
$char p_ilast_ply[21];
$char p_ilast_card[21];
$char p_inext_ply[21];

$char new_ipolicy[21];
$char ori_ipolicy[21];
$int  p_qnext_year_ori;
$int  p_qnext_year = 0;

$int  i_rtn = 0;
$int  i_cnt = 0;

$char a_inext_ply[21];
$int  a_qnext_year = 0;

$char b_inext_ply[21];
$int  b_qnext_year = 0;

$char c_ilast_ply[21];
$char c_inext_ply[21];
$int  c_qnext_year;

$char sp[2];
$int  izero;

$int  qseq;
$char fnewest[2];

   $SET LOCK MODE TO WAIT;
   $WHENEVER SQLERROR GOTO errexit;

   strcpy(sp," ");
   izero = 0;
   qseq = 0;
   strcpy(fnewest,"Y");
   printf("INTO function\n");
   printf("i_ipolicy[%s]\n",i_ipolicy);

/*******************************************************************
iopt = 1 ���ܥu�w���@���A�p�u���O���ܧ�Τw���������X���P���ܧ�C
iopt = 2 ���ܰw��G���A�p�������X�ܧ�A�εL�������X���P�Ӹ��X�ܧ�C
********************************************************************/
   printf("i_ipolicy[%s]\n",i_ipolicy);
   strcpy(p_ipolicy,i_ipolicy);
   strcpy(new_ipolicy,i_ipolicy);    /*  �s�������X���_�I�A�ݳv����ŦX��O�渹 */
   strcpy(ori_ipolicy," ");
   i_cnt = 0;

   $SELECT NVL(MAX(qseq),0)
      INTO $qseq
      FROM ply_next_year
     WHERE iendorse = $i_iendorse;

   /* �Y�������X����ʩεP���ܧ�ΫO���ܧ�A���N�����p�������� */
   for(;;)
   {
      printf("p_ipolicy[%s]\n",p_ipolicy);
      i_cnt++;
      if (p_ipolicy[0] == ' ' || p_ipolicy[0] == '\0') break;
      printf("i_cnt[%d],p_ipolicy[%s]\n",i_cnt,p_ipolicy);
      strcpy(fulldbname,get_car_full_db(p_ipolicy));
      sprintf_s(stmt,sizeof stmt,
       "SELECT NVL(ilast_ply,' '), NVL(ilast_card,' '), NVL(inext_ply,' '), qnext_year    \
          FROM %s:ply_relation                                       \
         WHERE ipolicy = '%s' ",fulldbname,p_ipolicy);
      printf("stmt[%s]\n",stmt);
      $PREPARE n_id_1 FROM $stmt;
      $EXECUTE n_id_1 INTO $p_ilast_ply_ori, $p_ilast_card_ori, $p_inext_ply_ori, 
                           $p_qnext_year_ori;
       if (SQLCODE == SQLNOTFOUND) break;

       if (i_cnt == 1)
       {
          strcpy(ori_ipolicy,p_ilast_ply_ori);   /* �¤������X���_�I�A�ݳv����ŦX��O�渹 */
       }

      sprintf_s(stmt,sizeof stmt,
       "EXECUTE PROCEDURE %s:update_ilast_ply('%s') ",fulldbname,p_ipolicy);
        printf("stmt[%s]\n",stmt);
      $PREPARE n_id_2 FROM $stmt;
      $EXECUTE n_id_2 INTO $i_rtn;
       printf("i_rtn[%d]\n",i_rtn);
       if (i_rtn == 0)
       {
          if (p_inext_ply_ori[0] == ' ' || p_inext_ply_ori[0] == '\0')
          {
              break;      /* �^�� 0 ���ܦp���O�������ŦX���� */
          }
          else
          {
              strcpy(p_ipolicy,p_inext_ply_ori);
              continue;   /* �Y������O�渹�A�����s�p���O�椧�~�� */
          }
       }

      printf("000:p_ipolicy[%s]\n", p_ipolicy);
      $EXECUTE n_id_1 INTO $p_ilast_ply, $p_ilast_card, $p_inext_ply, $p_qnext_year;
       if (SQLCODE == SQLNOTFOUND) break;
      printf("111:p_ipolicy[%s]\n", p_ipolicy);
      sprintf_s(stmt,sizeof stmt,
       " UPDATE ply_next_year    \
            SET fnewest  = 'N'   \
          WHERE iendorse = '%s'  \
            AND ipolicy  = '%s' ",i_iendorse,p_ipolicy);
      printf("stmt[%s]\n",stmt);
       $PREPARE n_id_4 FROM $stmt;
       $EXECUTE n_id_4;
       printf("SQLCODE[%d]\n", SQLCODE);

      current_secs=time(NULL);
      tm_now=localtime(&current_secs);
      strcpy(curtime,datetime_string(tm_now));

      sprintf_s(stmt,sizeof stmt,
       " INSERT INTO ply_next_year                                                        \
           (iendorse, ipolicy, qseq, ilast_card_ori, ilast_ply_ori, qnext_year_ori,       \
            fedr_face, ilast_card, ilast_ply, qnext_year, dentry, ientry, fnewest)        \
          VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
      printf("stmt[%s]\n",stmt);

      qseq++;
      $PREPARE n_id_5 FROM $stmt;
      $EXECUTE n_id_5
         USING $i_iendorse, $p_ipolicy, $qseq, $p_ilast_card_ori, $p_ilast_ply_ori, $p_qnext_year_ori,
               $fedr_face, $p_ilast_card, $p_ilast_ply, $p_qnext_year, $curtime, $user, $fnewest;
       printf("SQLCODE[%d]\n", SQLCODE);

      strcpy(p_ipolicy,p_inext_ply);
   }

   if (iopt == 2)
   {
      /* ���H�¤������X���_�I  ori_ipolicy */
      printf("\n\n\n\n\n");
      for(;;)
      {
         printf("ori_ipolicy[%s]\n",ori_ipolicy);
         if ((ori_ipolicy[0] == ' ') || (ori_ipolicy[0] == '\0')) break;
         strcpy(fulldbname,get_car_full_db(ori_ipolicy));
         sprintf_s(stmt,sizeof stmt,
          " SELECT NVL(inext_ply,' '),qnext_year           \
              FROM %s:ply_relation                         \
             WHERE ipolicy = '%s' ",fulldbname,ori_ipolicy);
          $PREPARE o_id1 FROM $stmt;
          $EXECUTE o_id1 INTO $a_inext_ply, $a_qnext_year;
                if (SQLCODE == SQLNOTFOUND) break;

         sprintf_s(stmt,sizeof stmt,
          " EXECUTE PROCEDURE %s:get_inext_ply('%s') ",fulldbname,ori_ipolicy);
           $PREPARE o_id2 FROM $stmt;
           $EXECUTE o_id2 INTO $b_inext_ply,$b_qnext_year;
            printf("rtn ori b_inext_ply[%s]\n",b_inext_ply);
            if (b_inext_ply[0] == ' ' || b_inext_ply[0] == '\0')
            {
               break;
            }

            if ((strcmp(a_inext_ply,b_inext_ply) == 0) &&
                (a_qnext_year == b_qnext_year - 1))
            {
               break;
            }

        strcpy(fulldbname,get_car_full_db(b_inext_ply));
        sprintf_s(stmt,sizeof stmt,
         "SELECT NVL(ilast_ply,' '), NVL(ilast_card,' '), NVL(inext_ply,' '), qnext_year    \
            FROM %s:ply_relation                                       \
           WHERE ipolicy = '%s' ",fulldbname,b_inext_ply);
        $PREPARE o_id3 FROM $stmt;
        $EXECUTE o_id3 INTO $p_ilast_ply_ori, $p_ilast_card_ori, $p_inext_ply_ori, 
                            $p_qnext_year_ori;
         if (SQLCODE == SQLNOTFOUND) break;

        sprintf_s(stmt,sizeof stmt,
         " EXECUTE PROCEDURE %s:update_ilast_ply('%s') ",fulldbname,b_inext_ply);
           printf("stmt[%s]\n",stmt);
          $PREPARE o_id4 FROM $stmt;
          $EXECUTE o_id4 INTO $i_rtn;
           printf("i_rtn[%d]\n",i_rtn);
           if (i_rtn == 0) break;  /* �^�� 0 ���ܦp���O�������ŦX���� */

        $EXECUTE o_id3 INTO $p_ilast_ply, $p_ilast_card, $p_inext_ply, $p_qnext_year;
         if (SQLCODE == SQLNOTFOUND) break;

         sprintf_s(stmt,sizeof stmt,
          " UPDATE ply_next_year    \
               SET fnewest  = 'N'   \
             WHERE iendorse = '%s'  \
               AND ipolicy  = '%s' ",i_iendorse,b_inext_ply);
          $PREPARE o_id6 FROM $stmt;
          $EXECUTE o_id6;

          current_secs=time(NULL);
          tm_now=localtime(&current_secs);
          strcpy(curtime,datetime_string(tm_now));

          sprintf_s(stmt,sizeof stmt,
           " INSERT INTO ply_next_year                                                        \
               (iendorse, ipolicy, qseq, ilast_card_ori, ilast_ply_ori, qnext_year_ori,       \
                fedr_face, ilast_card, ilast_ply, qnext_year, dentry, ientry, fnewest)                    \
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");

          qseq++;
          $PREPARE o_id7 FROM $stmt;
          $EXECUTE o_id7
             USING $i_iendorse, $b_inext_ply, $qseq, $p_ilast_card_ori, $p_ilast_ply_ori, $p_qnext_year_ori,
                   $fedr_face, $p_ilast_card, $p_ilast_ply, $p_qnext_year, $curtime, $user, $fnewest;
          strcpy(ori_ipolicy,b_inext_ply);
      }

         printf("\n\n\n\n\n");
      /* �A�H�s�������X���_�I  */
      for(;;)
      {
         printf("new_ipolicy[%s]\n",new_ipolicy);
         if ((new_ipolicy[0] == ' ') || (new_ipolicy[0] == '\0')) break;
         strcpy(fulldbname,get_car_full_db(new_ipolicy));
         sprintf_s(stmt,sizeof stmt,
          " SELECT NVL(inext_ply,' '),qnext_year           \
              FROM %s:ply_relation                         \
             WHERE ipolicy = '%s' ",fulldbname,new_ipolicy);
          $PREPARE p_id1 FROM $stmt;
          $EXECUTE p_id1 INTO $a_inext_ply, $a_qnext_year;
                if (SQLCODE == SQLNOTFOUND) break;

         sprintf_s(stmt,sizeof stmt,
          " EXECUTE PROCEDURE %s:get_inext_ply('%s') ",fulldbname,new_ipolicy);
           $PREPARE p_id2 FROM $stmt;
           $EXECUTE p_id2 INTO $b_inext_ply,$b_qnext_year;
            printf("rtn new b_inext_ply[%s]\n",b_inext_ply);
            if (b_inext_ply[0] == ' ' || b_inext_ply[0] == '\0')
            {
               break;
            }

            if ((strcmp(a_inext_ply,b_inext_ply) == 0) &&
                (a_qnext_year == b_qnext_year - 1))
            {
               break;
            }

        strcpy(fulldbname,get_car_full_db(b_inext_ply));
        sprintf_s(stmt,sizeof stmt,
         "SELECT NVL(ilast_ply,' '), NVL(ilast_card,' '), NVL(inext_ply,' '), qnext_year    \
            FROM %s:ply_relation                                       \
           WHERE ipolicy = '%s' ",fulldbname,b_inext_ply);
        $PREPARE p_id2 FROM $stmt;
        $EXECUTE p_id2 INTO $p_ilast_ply_ori, $p_ilast_card_ori, $p_inext_ply_ori, 
                            $p_qnext_year_ori;
         if (SQLCODE == SQLNOTFOUND) break;

        sprintf_s(stmt,sizeof stmt,
         " EXECUTE PROCEDURE %s:update_ilast_ply('%s') ",fulldbname,b_inext_ply);
           printf("stmt[%s]\n",stmt);
          $PREPARE p_id3 FROM $stmt;
          $EXECUTE p_id3 INTO $i_rtn;
           printf("i_rtn[%d]\n",i_rtn);
           if (i_rtn == 0) break;  /* �^�� 0 ���ܦp���O�������ŦX���� */

        $EXECUTE p_id2 INTO $p_ilast_ply, $p_ilast_card, $p_inext_ply, $p_qnext_year;
         if (SQLCODE == SQLNOTFOUND) break;

         sprintf_s(stmt,sizeof stmt,
          " UPDATE ply_next_year    \
               SET fnewest  = 'N'   \
             WHERE iendorse = '%s'  \
               AND ipolicy  = '%s' ",i_iendorse,b_inext_ply);
          $PREPARE p_id6 FROM $stmt;
          $EXECUTE p_id6;

          current_secs=time(NULL);
          tm_now=localtime(&current_secs);
          strcpy(curtime,datetime_string(tm_now));

          sprintf_s(stmt,sizeof stmt,
           " INSERT INTO ply_next_year                                                        \
               (iendorse, ipolicy, qseq, ilast_card_ori, ilast_ply_ori, qnext_year_ori,       \
                fedr_face, ilast_card, ilast_ply, qnext_year, dentry, ientry, fnewest)                    \
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?) ");
          qseq++;
          $PREPARE p_id7 FROM $stmt;
          $EXECUTE p_id7
             USING $i_iendorse, $b_inext_ply, $qseq, $p_ilast_card_ori, $p_ilast_ply_ori, $p_qnext_year_ori,
                   $fedr_face, $p_ilast_card, $p_ilast_ply, $p_qnext_year, $curtime, $user, $fnewest;
          strcpy(new_ipolicy,b_inext_ply);
      }
   }

   return TRUE;
errexit:
   printf("SQLCODE=%d,errmsg=%s\n,Errmsg = [%s]",SQLCODE,sqlca.sqlerrm,Errmsg);
   SQLCODE_TMP = SQLCODE;
   return SQLCODE_TMP;
}

long bk_edr_last(i_iendorse)
$char i_iendorse[21];
{
$int  SQLCODE_TMP = 0;
$char Errmsg[200];
$char fulldbname[31];
$char ipolicy[21],ilast_ply_ori[21],inext_ply_ori[21];
$char ilast_card_ori[21];
$int  qseq,qnext_year_ori = 0,qnext_year;
$char dentry[11];
$char tentry[31];
$char stmt[3000];
$int  i_cnt = 0,cnt;
$char ilast_ply[21];

   $SET LOCK MODE TO WAIT;
   $WHENEVER SQLERROR GOTO errexit;

   cnt = 0;
   $DECLARE bk_n_cur CURSOR FOR 
     SELECT ipolicy, qseq, ilast_card_ori, ilast_ply_ori, qnext_year_ori, ilast_ply, qnext_year,
            DATE(dentry), dentry
       FROM ply_next_year
      WHERE iendorse = $i_iendorse
      ORDER BY 2 DESC;
   $OPEN bk_n_cur;
   for(;;)
   {
   $FETCH bk_n_cur 
     INTO $ipolicy, $qseq, $ilast_card_ori, $ilast_ply_ori, $qnext_year_ori, $ilast_ply, $qnext_year,
          $dentry, $tentry;
       if (SQLCODE == SQLNOTFOUND) break;
       printf("ipolicy[%s]\n",ipolicy);

       cnt++;
       sprintf_s(stmt,sizeof stmt,
              " SELECT count(*)              \
                  FROM ply_next_year         \
                 WHERE ipolicy = ?           \
                   AND iendorse != ?         \
                   AND DATE(dentry) = ?      \
                   AND dentry > ?   ");
              $PREPARE get_same_edr FROM $stmt;
              $EXECUTE get_same_edr
                  INTO $i_cnt
                 USING $ipolicy, $i_iendorse, $dentry, $tentry;
              if (i_cnt > 0) return M_CA_EXIST_NEXT;

       printf("ipolicy[%s]\n",ipolicy);
              if (ilast_ply[0] != ' ' && ilast_ply[0] != '\0')
              {
                 strcpy(fulldbname,get_car_full_db(ilast_ply));
                 sprintf_s(stmt,sizeof stmt,
                       " UPDATE %s:ply_relation     \
                            SET inext_ply = ' '     \
                          WHERE ipolicy   = ?       \
                            AND inext_ply = ? ",fulldbname);
                       $PREPARE up_0 FROM $stmt;
                       $EXECUTE up_0 
                          USING $ilast_ply,$ipolicy;
              }

       strcpy(fulldbname,get_car_full_db(ipolicy));
       sprintf_s(stmt,sizeof stmt,
              " UPDATE %s:ply_relation   \
                   SET ilast_card = ?,   \
                       ilast_ply  = ?,   \
                       qnext_year = ?    \
                 WHERE ipolicy    = ? ",fulldbname); 
              $PREPARE up_1 FROM $stmt;
              $EXECUTE up_1 
                 USING $ilast_card_ori, $ilast_ply_ori, $qnext_year_ori, $ipolicy;

       /*  �_�� ��^ �h�O�A���^��e�O�渹 */
       if ((ilast_ply_ori[0] != ' ' && ilast_ply_ori[0] != '\0' && qnext_year_ori != 0))
       {
          strcpy(fulldbname,get_car_full_db(ilast_ply_ori));
          sprintf_s(stmt,sizeof stmt,
                 " UPDATE %s:ply_relation   \
                      SET inext_ply = ?     \
                    WHERE ipolicy   = ? ",fulldbname);
                 $PREPARE up_2 FROM $stmt;
                 $EXECUTE up_2
                    USING $ipolicy, $ilast_ply_ori;
       }
   }
   $CLOSE bk_n_cur;
   $FREE  bk_n_cur;
   printf("cnt[%d]\n",cnt);
   $DELETE FROM ply_next_year WHERE iendorse = $i_iendorse;

   return TRUE;
errexit:
   printf("SQLCODE=%d,errmsg=%s\n,Errmsg = [%s]",SQLCODE,sqlca.sqlerrm,Errmsg);
   return SQLCODE_TMP;
}

long chk_upd_edr_last(i_iendorse)
$char i_iendorse[21];
{
$int  SQLCODE_TMP;
$char Errmsg[200];
$char fulldbname[31];
$char stmt[4096];
$char fedr_class[2];
$char ipolicy[21];
$int  iopt;
 long rc;
$char p_iengine[21],p_itag[21];
$char a_iengine[21],a_itag[21];
$int  i_cnt = 0;

$long p_dply_begin = 0,p_dply_end = 0;
$long a_dply_begin = 0,a_dply_end = 0;
$char ientry[11], fedr_face[2];

   $SET LOCK MODE TO WAIT;
   $WHENEVER SQLERROR GOTO errexit;

   iopt = 0;
   /* �ͮīO�����P�h�����P�����p�O�渹 */

   $SELECT a.ipolicy, a.fedr_class, NVL(b.iengine,' '), NVL(b.itag,' '), a.iedr_examiner
      INTO $ipolicy, $fedr_class, $p_iengine, $p_itag, $ientry
      FROM edr_relation a,endorsement b
     WHERE a.iendorse = $i_iendorse
       AND a.iendorse = b.iendorse;
        if (SQLCODE == SQLNOTFOUND) return FALSE;

   $SELECT dply_begin,dply_end
      INTO $p_dply_begin, $p_dply_end
      FROM ply_relation_bak
     WHERE iendorse = $i_iendorse;
        if (SQLCODE == SQLNOTFOUND) return FALSE;

   $SELECT dply_begin,dply_end
      INTO $a_dply_begin, $a_dply_end
      FROM ply_relation
     WHERE ipolicy = $ipolicy; 
       if (SQLCODE == SQLNOTFOUND) return FALSE;

   $SELECT NVL(iengine,' '), NVL(itag,' ')
      INTO $a_iengine, $a_itag
      FROM policy_bak
     WHERE iendorse = $i_iendorse;
        if (SQLCODE == SQLNOTFOUND) return FALSE;

        if (fedr_class[0] == '1')
        {
           iopt = 2;
        }
        else
        {
           $SELECT count(*)
              INTO $i_cnt
              FROM ply_ins_type
             WHERE ipolicy = $ipolicy
               AND mdamage_cover <> 0;
           if (i_cnt == 0)
           {
               iopt = 2;
           }
           else 
           {
               $SELECT count(*)
                  INTO $i_cnt
                  FROM ply_ins_type_bak
                 WHERE iendorse = $i_iendorse
                   AND mdamage_cover <> 0;
               if (i_cnt == 0)
               {
                   iopt = 2;
               }
               else
               {
                   if (p_iengine[0] != ' ' && p_iengine[0] != '\0')
                   {
                      if (strcmp(p_iengine,a_iengine) != 0)
                      {
                         iopt = 2;
                      }
                      else
                      {
                         if ((p_dply_begin != a_dply_begin) || (p_dply_end != a_dply_end))
                         {
                            iopt = 2;
                         }
                         else
                         {
                            iopt = 0;
                         }
                      }
                   }
                   else
                   {
                      if (strcmp(p_itag,a_itag) != 0)
                      {
                         iopt = 2;
                      }
                      else
                      {
                         if ((p_dply_begin != a_dply_begin) || (p_dply_end != a_dply_end))
                         {
                            iopt = 2;
                         }
                         else
                         {
                            iopt = 0;
                         }
                      }
                   }
               }
           }
        }
        printf("iopt[%d]\n",iopt);
        if (iopt > 0)
        {
           strcpy( fedr_face, "1");
           rc = update_edr_last(iopt,ipolicy,i_iendorse,fedr_face,ientry);
        }
   return TRUE;
errexit:
   printf("SQLCODE=%d,errmsg=%s\n,Errmsg = [%s]",SQLCODE,sqlca.sqlerrm,Errmsg);
   SQLCODE_TMP = SQLCODE;
   return SQLCODE_TMP;
}
