/**********************************************************************/
/*   program id   : ca215m01s.ec                                      */
/*   program name : �����ʲz�j��O�I�Ҹ�ƶפJ�@�~                    */
/*   date written : 2014/06/17                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : Larry Liao                                        */                                       
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "cmnmsgs.h"
#include <math.h>
#include "safeclib.h"

long car215(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
  long rtncode;
  long car215_single_new();
  long car215_single_query();
  long car215_multiple_query();
  char option;
  
  cm_buf_init(command);
  cm_buf_get("%c",&option);
  switch(option)
  {     
    case 'Q':
           rtncode=car215_single_query(reply);
           break;
    case 'M':
           rtncode=car215_multiple_query(reply);
           break;
    case 'N':
           rtncode=car215_single_new(reply);
           break;
    default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
            return M_CM_WRONG_OPTION;
           return apiRC;
  }
    return(rtncode);                   
}
/******************************************************************************/
long car215_single_new(reply)
serverReply reply;
{
	  $char DBName[DBNAME];
	  $char icard[21], ftype[2], dentry[11], dcreate[11];
	  $char sFtype[5], sDentry[10], sDcreate[10], fstatus[2];
	  int tmp_len;
    
    cm_buf_get("%s %s", DBName, icard);
    
    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False) 
    {
       if(exitsub(reply,M_CM_DB_NOTOPEN) == True)  return M_CM_DB_NOTOPEN;
       else  return apiRC;
    }
	  
	  $SELECT first 1 icard, ftype, dentry, date(dcreate), fstatus
	     INTO $icard, $ftype, $dentry, $dcreate, $fstatus
	     FROM ca_card_road
	    WHERE icard = $icard
      ORDER BY dcreate desc;
	  if (SQLCODE == SQLNOTFOUND)
    {
        if(exitsub(reply,M_CM_NOT_FOUND) == True) return M_CM_NOT_FOUND;
        else return apiRC;
    }
    
    strcpy(ftype, trim(ftype));
    if (strcmp(ftype,"9") == 0) 
    	strcpy(sFtype,"�s�W");
    else if(strcmp(ftype,"1") == 0)
    	strcpy(sFtype,"�R��");
    	 
    strcpy(sDentry,  cm_from_infdate_100(dentry));
    strcpy(sDcreate, cm_from_infdate_100(dcreate));
    
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    cm_buf_put("%s %s %s %s %s",icard, sFtype, sDentry, sDcreate, fstatus);  
	
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)  return apiRC;
    else return api_OKComplete;

errexit:
printf("--car215_single_new-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    if(exitsub(reply,SQLCODE) == True) return SQLCODE;
    else return apiRC;
}
/******************************************************************************/
long car215_single_query(reply)
serverReply reply;
{
	  $char DBName[DBNAME];
	  $char icard[21], ftype[2], dentry[11], dcreate[11];
	  $char sFtype[5], sDentry[10], sDcreate[10], fstatus[2];
	  $char cDentry[10];
	  int tmp_len;
    
    cm_buf_get("%s %s %s %s", DBName, icard, ftype, cDentry);
    
    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False) 
    {
       if(exitsub(reply,M_CM_DB_NOTOPEN) == True)  return M_CM_DB_NOTOPEN;
       else  return apiRC;
    }
    
	  strcpy(dentry, cm_to_infdate(cDentry));	  
	  $SELECT icard, ftype, dentry, date(dcreate), fstatus
	     INTO $icard, $ftype, $dentry, $dcreate, $fstatus
	     FROM ca_card_road
	    WHERE icard = $icard
	      AND ftype = $ftype
	      AND dentry = $dentry;
	  if (SQLCODE == SQLNOTFOUND)
    {
        if(exitsub(reply,M_CM_NOT_FOUND) == True) return M_CM_NOT_FOUND;
        else return apiRC;
    }
    
    strcpy(ftype, trim(ftype));
    if (strcmp(ftype,"9") == 0) 
    	strcpy(sFtype,"�s�W");
    else if(strcmp(ftype,"1") == 0)
    	strcpy(sFtype,"�R��");
    	 
    strcpy(sDentry,  cm_from_infdate_100(dentry));
    strcpy(sDcreate, cm_from_infdate_100(dcreate));
    
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    cm_buf_put("%s %s %s %s %s",icard, sFtype, sDentry, sDcreate, fstatus);  
	
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)  return apiRC;
    else return api_OKComplete;

errexit:
printf("--car215_single_query-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    if(exitsub(reply,SQLCODE) == True) return SQLCODE;
    else return apiRC;
}
/******************************************************************************/
long car215_multiple_query(reply)
serverReply reply;
{
    $char DBName[DBNAME];
    $char input_date[10], cDate[11];
    $char icard[21], ftype[2], dentry[11], dcreate[11];
    $char sFtype[5], sDentry[10], sDcreate[10];
    $char sStmt[1000], stmp[128], fstatus[2];
    
    char tmpbuf[4000];
    int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    
    cm_buf_get("%s %s %s", DBName, input_date, icard);
    
    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True) return M_CM_DB_NOTOPEN;
        else return apiRC;
    }
   
    if (strncmp(input_date,"*",1) != 0){
        strcpy(cDate,cm_to_infdate(input_date));
        sprintf_s(stmp, sizeof stmp, " AND date(dcreate) = '%s' ", cDate);
    }
    else {
    	  strcpy(stmp," ");
    }
    printf("------------stmp[%s]\n",stmp);
    sprintf_s(sStmt, sizeof sStmt,"SELECT DISTINCT icard, ftype, dentry, date(dcreate), fstatus "
                    " FROM ca_card_road "
                    "WHERE icard MATCHES '%s' %s", icard, stmp);
                                       
    $PREPARE ca_road FROM $sStmt;                
    $DECLARE q_cur CURSOR FOR ca_road;    
    $OPEN q_cur;
    
    for(;;) { 
     	
    	$FETCH q_cur INTO $icard, $ftype, $dentry, $dcreate, $fstatus;
    	if (SQLCODE != 0) break;
    		
    	strcpy(ftype,trim(ftype));
    	if (strcmp(ftype,"9") == 0)
    		strcpy(sFtype,"�s�W");
    	else if (strcmp(ftype,"1") == 0)
    		strcpy(sFtype,"�R��");
    	
    	strcpy(sDentry,  cm_from_infdate_100(dentry));
      strcpy(sDcreate, cm_from_infdate_100(dcreate));
 
    	cm_buf_init(tmpbuf); 
    	if ( count == 0 )
     	{
      	  cm_buf_res_msg();             /* reserve for MsgCode and count */
      	  cm_buf_res_count();          
     	}
    	  cm_buf_put("%s %s %s %s %s", icard, sFtype, sDentry, sDcreate, fstatus);
        tmp_len = cm_buf_len(tmpbuf);
    	if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
        {
      	  memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      	  repbuf_len += tmp_len;
      	  count++;
     	}
   	else                               /* more than 4K, send to client side */ 
     	{ 
      	  cm_buf_init(ReplyBuf);
      	  cm_buf_put_msg(M_CM_OK);
      	  cm_buf_put_count(count);
      	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
        {
	        $CLOSE q_cur;
          return apiRC;
        }
      	else               /* clear ReplyBuf and count to start all over again */
        {
          replycnt++;
          if (replycnt == 10)   /* more than 30K, client cannot display,error */
          {
	  	      cm_buf_init(ReplyBuf);
          	cm_buf_put("%l",M_CM_OUT_SPACE);
          	tmp_len = cm_buf_len(ReplyBuf);
          	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
            	return apiRC;
            	return M_CM_OUT_SPACE; 
          }
	        ReplyBuf[0] = '\0';
	        count = 0;
	        cm_buf_init(ReplyBuf);
          cm_buf_res_msg();           /* reserve for MsgCode and count */
          cm_buf_res_count();    
          cm_buf_put("%s %s %s %s %s", icard, sFtype, sDentry, sDcreate, fstatus);
	        repbuf_len = cm_buf_len(ReplyBuf);
	        count++;
       }
     } 
  } /* for loop */

  $CLOSE q_cur;
  $FREE  q_cur;              
    	
  if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CM_NOT_FOUND) == True) 
    return M_CM_NOT_FOUND;
   else  
    return apiRC;
  } 

errexit:
printf("--car215_multiple_query-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  if(exitsub(reply,SQLCODE) == True)  return SQLCODE;
  else return apiRC;
}
/**********************************THE END*************************************/