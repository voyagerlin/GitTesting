#include <stdio.h>
#include <string.h>
#include <memory.h>
#include "api_xsrv.h"
#include <sys/stat.h>
$include sqlca;
$include datetime.h;
$include "crinc.h";
#include "sql.h"
$include "ISvar.h";
#include "is_def.h"
#include "aoimsgs.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include <math.h>
#include "carmsgs.h"
#include "commsgs.h"
#include <time.h>
#include "cmnmsgs.h"
#include <sys/time.h>
$include "ao_split.h";
$include sqlca;
$include sqlda;
$include sqltypes;
$include sqlstype;
$include datetime.h;

int   rc;
int i;
char *substring();
long update_edr_last();
char *get_car_full_db();
long get_product_code1();
char *datetime_string();
int   check_id();

$char Errmsg[60];
$char stmt[3000];

time_t current_secs;
struct tm *tm_now;
$char curtime[30];

char  outputf[20];
void aa();
$char filename[10];
int   counter;

main(argc, argv)
int argc;
char **argv;
{
long rc;
$char iclaim[21];
$char fstl[2];
$char sclose_type[3];
$char close_type[3];
$short  iclose_type;
$char ipolicy[21];
$char full[21];
$char sfull[31];
$char filename[12];
int   count;
int   miy;
int   rtn;
DBinfo  *list;
int     count_db , k;
$char   DBName[3];

  $WHENEVER SQLERROR goto errexit;
  $SET LOCK MODE TO WAIT;

  $database sysdb;

  $delete from stlflow1;
  $delete from stlflow2;
  $delete from stlflow3;
  $delete from stlflow4;
  $delete from stlflow5;
  $delete from stlflow6;
  $delete from stlflow7;

  printf("ok\n");
  exit(0);

errexit:
   printf("MAIN FUNCTION FALSE\n");
   printf("SQLCODE=%d,errmsg=%s\n,Errmsg = [%s]",SQLCODE,sqlca.sqlerrm,Errmsg);
/*
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
*/
exit(1);
}
