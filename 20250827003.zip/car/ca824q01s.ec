/************************************************/
/*                                              */
/*   PROGRAM : ca824q01s.ec by PETER SUN        */
/*           �i�߮ץI�ڳt�ש��Ӫ��j             */
/*   DATE    : 89.07.21                         */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"

EXEC SQL include datetime.h;
EXEC SQL include decimal.h;
EXEC SQL include sqlca;

EXEC SQL define PETER;

static int max_count , errCode;

/*** batchinit() ***/
char  DBName[5] , userid[11];
char  ibranch[3] ;
char  option_flag[2],option_flag1[2];
char  fspeed[2] , temp[2];
char  ipayment[11] , id_ext[2];
char  outputf[N_FILE+1];

char  cls_datebgn[15], cls_dateend[15];
char  pay_datebgn[15], pay_dateend[15];
char  Full_Name[50];
char  str_Ivictim[71];
/*******************/

EXEC SQL BEGIN DECLARE SECTION;
	char   FormTp[3];
	char   FormFmt[N_FILE+1];
	char   TitleFmt[21] , BodyFmt[21];
	int    StartRow , TitleRow;
	int    TotColumn;
	int    PgLine , Width;
	char   TitleFile[21];
	char   FormFile[N_FILE+1];

	char   stmt_buf[6000];

	char   clsdatebgn[11] , clsdateend[11];
	char   paydatebgn[11] , paydateend[11];
	char   Iclaim[CLAIM_NUM];
	long   Dclose , Dgroup;
	long   Dentry;
	char   Iadjuster[11];
	char   Ipayment[11] , Ifpce_id_ext[3] , Nchi_full[41];
	long   Mpayment,mlabor_fee,mmater_fee,mpaint_fee, mdmgpri_fee, mequip_fee;
	long   mphoto_fee,mtraffic_fee,mmail_fee,mlaw_fee,mplace_fee,mvision_fee,mother_fee;
	char   Mpayment_C[12];
	long   mplate, mremove, mpart, mvarnish, mdeduct, mdmgpri, mequip, mtotal;
	char   iins_type[7] , nins_type[29];
	long   mshort;
	char   Property_tag[134];
	int    qserial;
	char   Nfactor_type[21];
	char   Nmodel_type[21];

	char   Fspeed[2] , Pay_kind[2];
	long   Dreceiver , Dpaperwork ;
	char   Iadjuster_name[11];
	char   Ipolicy[POLICY_NUM_1];

	long   Dclaim;
	char   isurveyor[11] , nsurveyor_name[11];
	long   Dpay;
	double M_stl;
	char   M_stl_C[12];
	char   Fstl[2];
	int    Iclose_type;
	char   Iclose_type_C[6];

	char   Ngroup[13];
	char   Claim_Paper[11];
	char   Paper_Settle[11];
	char   Paper_next_Settle[11];
	char   Paper_next_Pay[11];
	char   Settle_Close[11];
	char   Close_Pay[11];

	long   Claim_Paper_lg;
	long   Paper_Settle_lg;
	long   Paper_next_Settle_lg;
	long   Paper_next_Pay_lg;
	long   Settle_Close_lg;
	long   Close_Pay_lg;

	int    dpaperwork_check;
	int    dpay_check;
	int    m_stl_check;
	int    dreceiver_check;
	char   stac_flag[2];
	char   ffsettle[2];
	char   sNchi_full[5];
	long   ldcnt;
	char Xsettle_type[2];
	char Nassured[21];
	char itag[9];
	char Daccident[21];
	char nacc_driver[20];
	char Iacc_license[11];
	char Iassured[11];
	char Ivictim[11];
	char fcard_class[2];
	char Frecover[2];
	char Note[2];
	char fins_type[2];
	 char manufactor[9],ngroup1[13];
	char fsystem[2];
	char nquota1[21], nquota2[31];

	long Cpaper_next_Pay;
	long Cpaper_next_Settle;
	char Cpaperwork_next[11];
	char Centry[11];
	char CPay[11];
	int maxadj;

EXEC SQL END DECLARE SECTION;



static char *get_car_full_db();  /*   �ǤJ�O�渹��X���O�檺�k�ݸ��*/
long car824_build();
long car824_build1();
long car824_title();
long car824_body();
long car824_body1();
double d45();


main(argc, argv)
int argc;
char **argv;
{
	int rc;

	batchinit();
	strcpy(DBName      , isNULLstr(argv[1]));
	strcpy(userid      , isNULLstr(argv[2]));
	strcpy(ibranch     , isNULLstr(argv[3]));    /* �`�����q�O */
	strcpy(option_flag , isNULLstr(argv[4]));    /* A:fspeed B:ipayment */

	EXEC SQL ifdef PETER;
		printf("##[car824]:option_flag[%s]\n",option_flag);
	EXEC SQL endif;

	if (option_flag[0] == 'A')   /*** �ߥI�t�� ***/
	{
		strcpy(fspeed , isNULLstr(argv[5]));
		strcpy(temp   , isNULLstr(argv[6]));
	}

	if (option_flag[0] == 'B')   /*** �ߥI��H ***/
	{
		strcpy(ipayment , isNULLstr(argv[5]));
		strcpy(id_ext   , isNULLstr(argv[6]));
	}

	strcpy(option_flag1, isNULLstr(argv[7]));
	if (option_flag1[0] == 'A')  /*** �z�ߵ��פ�� ***/
	{
		strcpy(clsdatebgn  , isNULLstr(argv[8]));
		strcpy(clsdateend  , isNULLstr(argv[9]));
		if(clsdatebgn[0] == '*') strcpy(clsdatebgn, "88/01/01");
		if(clsdateend[0] == '*') strcpy(clsdateend, "199/12/31");
		if(clsdateend[0] == ' ') strcpy(clsdateend, clsdatebgn);
		strcpy(cls_datebgn,clsdatebgn);
		strcpy(cls_dateend,clsdateend);

		strcpy(clsdatebgn, cm_to_infdate(clsdatebgn));
		strcpy(clsdateend, cm_to_infdate(clsdateend));

		EXEC SQL ifdef PETER;
			printf("clsdatebgn[%s]\n",clsdatebgn);
			printf("clsdateend[%s]\n",clsdateend);
		EXEC SQL endif;
	}
	else if (option_flag1[0] == 'B')     /*** �z�ߥI�ڤ�� ***/
	{
		strcpy(paydatebgn  , isNULLstr(argv[8]));
		strcpy(paydateend  , isNULLstr(argv[9]));
		if(paydatebgn[0] == '*') strcpy(paydatebgn, "88/01/01");
		if(paydateend[0] == '*') strcpy(paydateend, "199/12/31");
		if(paydateend[0] == ' ') strcpy(paydateend, clsdatebgn);
		strcpy(pay_datebgn,paydatebgn);
		strcpy(pay_dateend,paydateend);

		strcpy(paydatebgn, cm_to_infdate(paydatebgn));
		strcpy(paydateend, cm_to_infdate(paydateend));

		EXEC SQL ifdef PETER;
			printf("paydatebgn[%s]\n",paydatebgn);
			printf("paydateend[%s]\n",paydateend);
		EXEC SQL endif;
	}

	strcpy(ffsettle    , isNULLstr(argv[10]));
	strcpy(stac_flag   , isNULLstr(argv[11]));    /* 0:����   1:�έp     */
	strcpy(outputf     , isNULLstr(argv[12]));

	EXEC SQL ifdef PETER;
		printf("######[car824] outputf[%s] \n",outputf);
	EXEC SQL endif;

	max_count = 0;

	printf("stac_flag[%s]\n",stac_flag);
	if (stac_flag[0] == '0')
	{
		rc = car824_build();
	}
	else
	{
		rc = car824_build1();
	}

	rgu_finish_report();

	EXEC SQL ifdef PETER;
		printf("####### outputf[%s]\n",outputf);
	EXEC SQL endif;

	if(rc == api_OKComplete)
	{
		printf("max_count------[%d]\n",max_count);
		if((rc=save_form_info(F_FREE,"CA",824,userid,FormTp,max_count,outputf))<0)
		{
			EWRITE(userid,rc,"save_form_info failed");
		}
	}
}

/*******************************************************************/
long car824_build()
{
	EXEC SQL BEGIN DECLARE SECTION;
		char   where_stat[100];
		char   iclaim1_3[4];
		char  sIquota[7];
		char  sBranch[3];
		char  sWhere1[1024];
		char  sWhere2[1024];
		char  sWhere9[1024];
		char  sWhere3[1024];

	EXEC SQL END DECLARE SECTION;

	EXEC SQL WHENEVER SQLERROR GOTO errexit;
	EXEC SQL SET LOCK MODE TO WAIT;


	EXEC SQL ifdef PETER;
		printf("############ �����`�����q�O ibranch[%s]\n",ibranch);
	EXEC SQL endif;

	if (db_select(DBName) == False)
	{
	   EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
	   return FAIL;
	}

	EXEC SQL SELECT nform_file , ntitle_fmt  , nbody_fmt , kstart_row , ktitle_row ,
				    ktot_col   , kpgnum_line , kwidth    , iform_tp
			   INTO :FormFmt   , :TitleFmt   , :BodyFmt  , :StartRow  , :TitleRow  ,
				    :TotColumn , :PgLine     , :Width    , :FormTp
			   FROM Form
			  WHERE ksys_grp = "CA" AND kPgmID = 824 AND iform_tp = '1';

	strcpy(FormFmt   , rtrim(FormFmt));
	sprintf(FormFile , "%s.tx", outputf);

	EXEC SQL ifdef PETER;
		printf("FormFile[%s] \n",FormFile);
	EXEC SQL endif;

	rgu_init_report(FormFmt,FormFile);
	car824_title();

	mlabor_fee=mmater_fee=mpaint_fee=mdmgpri_fee=mequip_fee=0;
	mphoto_fee = mtraffic_fee = mmail_fee = mlaw_fee = mplace_fee = mvision_fee = mother_fee = 0;

	if (option_flag[0] == 'A')
	{
		if (fspeed[0] == 'A')
		{
			strcpy(where_stat,"AND b.dspeed IN ('1','2','3','4') ");
		}
		else if (fspeed[0] == '*')
		{
			sprintf(where_stat,"AND b.dspeed between '1' and '9' ");
		}
		else
		{
			sprintf(where_stat,"AND b.dspeed = '%s' ",fspeed);
		}
		
		EXEC SQL ifdef PETER;
			printf("option_flag[%s],where_stat[%s]\n",option_flag,where_stat);
		EXEC SQL endif;
	}

	if (option_flag[0] == 'B')
	{
		sprintf(where_stat,"AND b.istl_obj matches '%s' AND b.istl_obj_ext = '%s' ",ipayment,id_ext);
		EXEC SQL ifdef PETER;
			printf("option_flag[%s],where_stat[%s]\n",option_flag,where_stat);
		EXEC SQL endif;
	}

	if (option_flag1[0] == 'A')
	{
		sprintf(sWhere3,"WHERE a.dclose >= '%s' AND a.dclose <= '%s' ", clsdatebgn, clsdateend);
		EXEC SQL ifdef PETER;
			printf("option_flag1[%s],sWhere3[%s]\n", option_flag1, sWhere3);
		EXEC SQL endif;
	}
	else if (option_flag1[0] == 'B')
	{
		sprintf(sWhere3,"WHERE b.dpay >= '%s' AND b.dpay <= '%s' ", paydatebgn, paydateend);
		EXEC SQL ifdef PETER;
			printf("option_flag1[%s],sWhere3[%s]\n", option_flag1, sWhere3);
		EXEC SQL endif;
	}

	EXEC SQL WHENEVER SQLERROR GOTO errexit;

	if (ibranch[0] == '*')
	{
		strcpy(sWhere1," ");
		strcpy(sWhere9," ");
	}
	else
	{
		sprintf(sWhere1," AND branch = '%s' ",ibranch);
		sprintf(sWhere9," AND a.icls_dept = '%s' ",ibranch);
	}

	if (ffsettle[0] == '3')
	{
		strcpy(sWhere2," ");
	}
	else
	{
		sprintf(sWhere2," AND a.fstl = '%s' ",ffsettle);
	}

	$select * from v_channel
	   into temp tmp_channel;

	$create index tmp_ch_ix1 on tmp_channel(icode);
	str_Ivictim[0]='\0';
	sprintf(stmt_buf,
			" SELECT branch        \
				FROM servertbl     \
			   WHERE branch = '00' \
			   ORDER BY 1 ");
	printf("max flag6\n");
    printf("stmt_buf[%s]\n",stmt_buf);
	$PREPARE dbid FROM $stmt_buf;
	$DECLARE db_cur CURSOR FOR dbid;
    $OPEN db_cur ;
    for(;;)
	{
		$FETCH db_cur INTO $sBranch;
		if (SQLCODE == SQLNOTFOUND) break;

		sprintf(stmt_buf,
				" SELECT UNIQUE a.iclose, a.ipolicy1, a.fstl, a.iclose_type, b.istl_obj, b.istl_obj_ext "
				"   FROM ao_stl_close a "
				"  INNER JOIN ao_stl_obj_close b "
				"          ON a.iclose = b.iclose "
				"         AND a.fstl = b.fstl "
				"         AND a.iclose_type = b.iclose_type "
				" %s %s %s %s "
				"    AND a.insure_type = 'C' "
				" ORDER BY a.iclose ", sWhere3,sWhere2,where_stat,sWhere9);
		printf("stmt_buf[%s]\n",stmt_buf);
		EXEC SQL PREPARE pr1  FROM :stmt_buf;
		EXEC SQL DECLARE Mcur1 CURSOR FOR pr1;
		EXEC SQL OPEN Mcur1;

		while (1)
		{
			EXEC SQL FETCH Mcur1 INTO :Iclaim, :Ipolicy, :Fstl, :Iclose_type_C, :Ipayment, :Ifpce_id_ext;
			
			if (SQLCODE == SQLNOTFOUND) break;

			/* �O��B�߮׸�Ʈw */
			strcpy(Full_Name,get_car_full_db(Ipolicy));
			printf("Full_Name[%s]\n",Full_Name);

			sprintf(stmt_buf,
					" SELECT a.iclaim    , a.dclose       , a.dgroup ,  \
						     a.iadjuster , a.ipolicy      , \
						     b.ipayment  , b.ifpce_id_ext , b.nchi_full[1,40] ,\
						     b.mpayment  , b.fspeed       , b.pay_kind  ,\
						     b.dreceiver , b.dpaperwork   , date(b.dpaperwork)+1 ,\
						     a.fstl      , a.iclose_type  ,   \
							 case when date(a.dupdate) is null then date(a.dentry)   \
								  else case when date(a.dupdate) > a.dclose then date(a.dentry)   \
									        else date(a.dupdate)  \
									   end  \
							 end , \
							 b.xsettle_type, \
							 a.frecover  , a.mlabor_fee   , a.mmater_fee, a.mpaint_fee, \
							 a.mphoto_fee, a.mtraffic_fee , a.mmail_fee , a.mlaw_fee, \
							 a.mplace_fee, a.mvision_fee  , a.mother_fee, b.qserial , \
							 trim('''' || G.iins_type) , G.nins_type , '''' || G.isurveyor , G.nname , G.property_tag, \
							 a.mdmgpri_fee, a.mequip_fee \
					    FROM %s:settlement a \
					   INNER JOIN %s:payment b ON a.iclaim = b.iclaim AND a.fstl = b.fstl AND a.iclose_type = b.iclose_type \
					   INNER JOIN sysdb:ca_sign_receipt c ON b.iclaim = c.iclaim AND  c.ifpce_id_ext = b.ifpce_id_ext AND c.ifpce_id = b.ipayment AND c.qserial = b.qserial \
					    LEFT OUTER JOIN ( SELECT i.iclaim , i.isign , i.iins_type , i.isurveyor , i.mamount , \
											     o.nname , s.nins_type , TRIM(p.npro) ||' '|| TRIM(p.itag) AS property_tag\
									        FROM sysdb:ca_pro_ins i	\
									        LEFT JOIN sysdb:insurance_type s ON s.iins_type = i.iins_type \
									        LEFT JOIN sysdb:officer o ON o.iofficer = isurveyor \
											LEFT JOIN sysdb:ca_property p ON i.iverify = p.iverify AND i.ipro_no = p.ipro_no \
									       WHERE  i.mamount = (SELECT MAX(mamount) FROM ca_pro_ins p WHERE p.iclaim = i.iclaim AND p.isign = i.isign AND p.iins_type = i.iins_type and p.iclaim = '%s') and i.iclaim = '%s'  \
									    ) G ON G.iclaim = c.iclaim  AND c.isign = G.isign AND c.isign <> ''	\
					   WHERE a.iclaim='%s' AND a.fstl='%s' AND a.iclose_type=%s \
					     AND b.ipayment='%s' AND b.ifpce_id_ext='%s' ", Full_Name, Full_Name, Iclaim, Iclaim , Iclaim, Fstl, Iclose_type_C, Ipayment, Ifpce_id_ext);
			 
			printf("stmt_buf[%s]\n",stmt_buf);
			EXEC SQL PREPARE Acursor  FROM :stmt_buf;
			EXEC SQL DECLARE Acursor1 CURSOR FOR Acursor;
			EXEC SQL OPEN Acursor1;

			while (1)
			{
				dpaperwork_check = dpay_check = m_stl_check = 0;
				M_stl = 0;
				Property_tag[0] = '\0';

				EXEC SQL FETCH Acursor1 INTO :Iclaim    , :Dclose       , :Dgroup     ,
											:Iadjuster  , :Ipolicy      ,
											:Ipayment   , :Ifpce_id_ext , :Nchi_full  ,
											:Mpayment   , :Fspeed       , :Pay_kind   ,
											:Dreceiver:dreceiver_check  , :Dpaperwork:dpaperwork_check, :Cpaperwork_next ,
											:Fstl       , :Iclose_type  ,
											:Dentry     , :Xsettle_type , :Frecover   ,
											:mlabor_fee , :mmater_fee   , :mpaint_fee ,
											:mphoto_fee , :mtraffic_fee , :mmail_fee  , :mlaw_fee ,
											:mplace_fee , :mvision_fee  , :mother_fee , :qserial  , :iins_type , :nins_type , :isurveyor , :nsurveyor_name , :Property_tag ,
											:mdmgpri_fee, :mequip_fee;

				if (SQLCODE == SQLNOTFOUND) break;

				strncpy(iclaim1_3,Iclaim,3);
				iclaim1_3[3] = '\0';

				/*��W���l�I�P�_(���t�ѵs)*/
				sprintf(stmt_buf,
						 "SELECT count(*)         \
							FROM ca_clm_process a \
						   WHERE a.fins = 30      \
							 AND (SELECT count(*)                            \
									FROM %s:app_ins_type x,insurance_type y  \
								   WHERE x.iins_type = y.iins_type           \
									 AND x.iclaim = a.iclaim                 \
									 AND y.fkind = '2') = 0                  \
							 AND a.iclaim = '%s' ",Full_Name,Iclaim);

				printf("stmt_buf[%s]\n",stmt_buf);

				EXEC SQL PREPARE pre1  FROM :stmt_buf;
				EXEC SQL DECLARE cur_pre1 CURSOR FOR pre1;
				EXEC SQL OPEN cur_pre1;

				while (1)
				{
					EXEC SQL FETCH cur_pre1 INTO :maxadj;

					if (SQLCODE == SQLNOTFOUND) break;

					if(maxadj==1)
					{
						strcpy(fins_type,"Y");
					}
					else
					{
						strcpy(fins_type,"N");
					}
				}

				/*
				if (strcmp(trim(Pay_kind),"1") != 0)
				{   mlabor_fee=mmater_fee=mpaint_fee=0;   }
				*/

				/*�g�P�� and �ϳ�*/
				sprintf(stmt_buf,"select NVL(b.nlevel3,' '),NVL(b.nlevel4,' ') \
									from %s:ply_relation a left join tmp_channel b \
															 on a.iofficer = b.icode \
								   where a.ipolicy = '%s' ",Full_Name,Ipolicy);
				printf("stmt_buf[%s]\n",stmt_buf);
				$PREPARE sid010 FROM $stmt_buf;
				$EXECUTE sid010 INTO $manufactor,$ngroup1;

				/* �Q�O�I�H */
				sprintf(stmt_buf,
						" SELECT iassured,nassured[1,20],itag \
							FROM %s:adjustment_ply       \
						   WHERE iclaim = ? ",Full_Name );
				$PREPARE sid011 FROM $stmt_buf;
				$EXECUTE sid011 INTO $Iassured,$Nassured,$itag USING $Iclaim;

				printf(" stmt_buf[%s]\n",stmt_buf);

				/* �X�I���  */
				sprintf(stmt_buf,
						" SELECT date(daccident),iacc_license,fcard_class  \
							FROM %s:appraisal            \
						   WHERE iclaim  = ?  ",Full_Name);
				$PREPARE sid012 FROM $stmt_buf;
				$EXECUTE sid012 INTO $Daccident,$Iacc_license,$fcard_class USING $Iclaim;

				if(strcmp(fcard_class,"1")==0)
				{
					/* ���`�H  */
					if(strcmp(Frecover,"5")!=0)
					{
						sprintf(stmt_buf,"select unique ivictim    \
										    from %s:ca_stl_victim \
										   where iclaim = ?          \
										     and fstl  = ?           \
										     and iclose_type = ?  ",Full_Name);
						EXEC SQL PREPARE Acursor  FROM :stmt_buf;
						EXEC SQL DECLARE Acursor4 CURSOR FOR Acursor;
						EXEC SQL OPEN Acursor4 USING :Iclaim,:Fstl,:Iclose_type;
						while (1)
						{
							EXEC SQL FETCH Acursor4 INTO :Ivictim;

							if (SQLCODE == SQLNOTFOUND) break;

							strcpy(Ipayment,trim(Ipayment));
							strcpy(Iassured,trim(Iassured));
							strcpy(Iacc_license,trim(Iacc_license));
							strcpy(Ivictim,trim(Ivictim));

							if((strcmp(Ipayment,Iassured)==0) || (strcmp(Ipayment,Iacc_license)==0) || (strcmp(Ipayment,Ivictim)==0))
							{
								strcpy(Note," ");
								strcat(str_Ivictim,Ivictim);
								break;
							}
							else
							{
								strcpy(Note,"N");
							}

							strcat(str_Ivictim,Ivictim);
							strcat(str_Ivictim,"  ");
						}  /* end while */
					}
					else
					{
						strcpy(Note," ");
					}   /* end frecover */
				}
				else
				{   strcpy(Note," ");   }  /* end fcard_class */


				/*** �z�ߤH������W�� ***/
				EXEC SQL SELECT nname,iquota[1,4]
						   INTO :Iadjuster_name , :sIquota
						   FROM officer
						  WHERE iofficer = :Iadjuster;

				/*** �߮ר��z��� ***/
				/* �s�W�z�߳��(nquota1), �z�߬�O(nquota2) add by sylvia 107.06.29 (1070613003_SC1) */
				EXEC SQL SELECT dclaim, fsystem,
								(select nchi_full from branch where ibranch = 
								  (select iapp_unit from cm_clm_adjuster where empl_no = a.adjustment)),
								(select nbranch  from sa_branch_type where ibranch = 
								  (select iquota from officer where iofficer = a.adjustment))
						   INTO :Dclaim, :fsystem, :nquota1, :nquota2
						   FROM ca_clm_process a
						  WHERE iclaim = :Iclaim;

				/*** ��I����Τ�I���B ***/
				sprintf(stmt_buf,
					    " SELECT dpay ,m_stl             \
						    FROM ao_stl_obj_close        \
						   WHERE iclose       = ?        \
						     AND iclose_type  = ?        \
						     AND fstl         = ?        \
						     AND istl_obj     = ?        \
						     AND istl_obj_ext = ?        \
						     AND dspeed       = ? ");

				$PREPARE sid01 FROM $stmt_buf;
				$EXECUTE sid01
					INTO $Dpay:dpay_check , $M_stl:m_stl_check
				   USING $Iclaim,$Iclose_type_C,$Fstl,$Ipayment,$Ifpce_id_ext,$Fspeed;

				if (SQLCODE == SQLNOTFOUND)
				{
					dpay_check = -1;
					m_stl_check = -1;
				}
				strcpy(sIquota,rtrim(sIquota));
				strcat(sIquota,"00");

				$SELECT nbranch
				   INTO $Ngroup
				   FROM sa_branch_type
				  WHERE ibranch = $sIquota;
				if (SQLCODE == SQLNOTFOUND) strcpy(Ngroup," ");

				/*** ���z��ñ����� ***/
				if (dpaperwork_check == -1)
				{
					strcpy(Claim_Paper," ");
				}
				else
				{
					Claim_Paper_lg = Dpaperwork - Dclaim;
					rfmtlong(Claim_Paper_lg,"-##,##&",Claim_Paper);
				}

				/*** ñ���ܲz����(�u�@��) ***/

				if (dpaperwork_check == -1)
				{
					strcpy(Paper_Settle," ");
					strcpy(Paper_next_Settle," ");
				}
				else
				{

					strcpy( Centry , cm_edate_str(Dentry));   /*�NDentry�ഫ�����*/

					EXEC SQL Select  count(dwork)             /*����u�@��*/
							   into  :Cpaper_next_Settle
							   from  cm_wrktbl
							  where  fwork = '0'
							    and  dwork between :Cpaperwork_next and :Centry;

				    Paper_Settle_lg = Dentry - Dpaperwork;
				    rfmtlong(Paper_Settle_lg,"-##,##&",Paper_Settle);
				    Paper_next_Settle_lg = Cpaper_next_Settle ;
				    rfmtlong(Paper_next_Settle_lg,"-##,##&",Paper_next_Settle);
				}

				/*** �z��ܤ鵲��� ***/
				Settle_Close_lg = Dclose - Dentry;
				rfmtlong(Settle_Close_lg,"-##,##&",Settle_Close);

				EXEC SQL ifdef PETER;
				printf("Dpay[%ld]\n",Dpay);
				EXEC SQL endif;

				/*** �鵲�ܤ�I��� ***/
				if (dpay_check == -1)
				{
				   strcpy(Close_Pay," ");
				}
				else
				{
				   Close_Pay_lg = Dpay - Dclose;
				   rfmtlong(Close_Pay_lg,"-##,##&",Close_Pay);
				}


				/*** ñ���ܤ�I���(�u�@��) ***/
				if (dpaperwork_check == -1 || dpay_check == -1)
				{
					strcpy(Paper_next_Pay," ");
				}
				else
				{
					strcpy( CPay , cm_edate_str(Dpay));        /*�NDpay�ഫ�����*/

					EXEC SQL Select count(dwork)               /*����u�@��*/
							   into :Cpaper_next_Pay
							   from cm_wrktbl
							  where fwork = '0'
								and dwork between :Cpaperwork_next and :CPay;

					Paper_next_Pay_lg = Cpaper_next_Pay;
					rfmtlong(Paper_next_Pay_lg,"-##,##&",Paper_next_Pay);
				}

				EXEC SQL ifdef PETER;
					printf("Claim_Paper[%s],Paper_Settle[%s],Settle_Close[%s],Close_Pay[%s] \n",
						    Claim_Paper  ,  Paper_Settle  ,  Settle_Close  ,  Close_Pay);
				EXEC SQL endif;

				/* �z���B��u */
				mplate = mremove = mpart = mvarnish = mdeduct = mdmgpri = mequip = 0;
				
				mshort = 0;
				if(strcmp(fcard_class,"2")==0)
				{
					sprintf(stmt_buf,
							" SELECT NVL(SUM(c.mplate), 0), "
							"        NVL(SUM(c.mremove), 0), "
							"        NVL(SUM(c.mpart), 0), "
							"        NVL(SUM(c.mvarnish), 0), "
							"        NVL(SUM(c.mdeduct), 0), "
							"        NVL(SUM(c.mdmgpri), 0), "
							"        NVL(SUM(c.mequip), 0),"
							"        NVL(SUM(c.mshort), 0) "
							"   FROM %s:payment a, %s:ca_sign_receipt b, ca_pro_ins c "
							"  WHERE a.iclaim = b.iclaim "
							"    AND a.ipayment = b.ifpce_id "
							"    AND a.ifpce_id_ext = b.ifpce_id_ext "
							"    AND a.qserial = b.qserial "
							"    AND b.iclaim = c.iclaim "
							"    AND b.isign = c.isign AND b.isign <> ' ' "
							"    AND a.iclaim = ? AND a.fstl = ? AND a.iclose_type = ? "
							"    AND a.ipayment = ? AND a.ifpce_id_ext = ? AND a.qserial = ? ", Full_Name, Full_Name);
					printf("stmt_buf[%s]\n",stmt_buf);
					$PREPARE pr2 FROM $stmt_buf;
					$EXECUTE pr2
						INTO $mplate, $mremove, $mpart, $mvarnish, $mdeduct, $mdmgpri, $mequip, $mshort
					   USING $Iclaim, $Fstl, $Iclose_type, $Ipayment, $Ifpce_id_ext, $qserial;

					printf("iclaim[%s], fstl[%s], iclose_type[%d], ipayment[%s], ifpce_id_ext[%s], qserial[%d]\n", Iclaim, Fstl, Iclose_type, Ipayment, Ifpce_id_ext, qserial);

					sprintf(stmt_buf,
							" select (select trim(icode) || '.' || trim(ncode)            \
									    from cu_code_data                                 \
									   where itype = 'DQ'                                 \
									     and icode =  b.ffactory_type) as ffactory_type,  \
									 (select trim(icode) || '.' || trim(ncode)            \
										from cu_code_data                                 \
									   where itype = 'DR'                                 \
										 and icode =  b.fmodel_type) as fmodel_type       \
							    from %s:payment a, ca_sign_receipt b     \
							   where a.iclaim       =   b.iclaim         \
							     and a.ipayment     =   b.ifpce_id       \
							     and a.ifpce_id_ext =   b.ifpce_id_ext   \
							     and a.qserial      =   b.qserial        \
							     and a.iclose_type  =   b.iclose_type    \
							     and b.isign       <>   ' '              \
							     and a.iclaim       =   ?                \
							     and a.fstl         =   ?                \
							     and a.iclose_type  =   ?                \
							     and a.ipayment     =   ?                \
							     and a.ifpce_id_ext =   ?                \
							     and a.qserial      =   ? ", Full_Name);
					
				    $prepare pr3 from $stmt_buf;
				    $execute pr3
					    into $Nfactor_type, $Nmodel_type
					   using $Iclaim, $Fstl, $Iclose_type, $Ipayment, $Ifpce_id_ext, $qserial;
					if (SQLCODE == SQLNOTFOUND)
					{
						strcpy(Nfactor_type," ");
						strcpy(Nmodel_type," ");
					}
				}
				car824_body();
			}
			$CLOSE Acursor1;
			$FREE Acursor1;
			printf("END Acursor1\n");

		}
		$CLOSE Mcur1;
		$FREE Mcur1;
		printf("END Mcur1\n");
	}
	$CLOSE db_cur;
	$FREE  db_cur;

    printf("END db_cur\n");

	if (max_count == 0)
	{
		EWRITE(userid, M_CM_NOT_FOUND, "no data found in [car824] !!");
		return FAIL;
	}
	return SUCCESS;

errexit:
	printf("build:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	exit(FAIL);
}

long car824_title()
{
char yy[4], mm[3], dd[3], buf[11];

	if (option_flag1[0] == 'A')  /*** �z�ߵ��פ�� ***/
	{
		rgu_put_body_string(5,"�鵲",1);

		cm_split_ymd_100(cls_datebgn, yy, mm, dd);
		rgu_put_body_string(5,yy,1);
		rgu_put_body_string(5,mm,1);
		rgu_put_body_string(5,dd,1);

		cm_split_ymd_100(cls_dateend, yy, mm, dd);
		rgu_put_body_string(5,yy,1);
		rgu_put_body_string(5,mm,1);
		rgu_put_body_string(5,dd,1);
	}
	else
	{
		rgu_put_body_string(5,"�I��",1);

		cm_split_ymd_100(pay_datebgn, yy, mm, dd);
		rgu_put_body_string(5,yy,1);
		rgu_put_body_string(5,mm,1);
		rgu_put_body_string(5,dd,1);

		cm_split_ymd_100(pay_dateend, yy, mm, dd);
		rgu_put_body_string(5,yy,1);
		rgu_put_body_string(5,mm,1);
		rgu_put_body_string(5,dd,1);
	}

	rgu_put_body_string(5,cm_get_sysd(),1);

	rgu_put_body(1);
	rgu_put_body(2);
	rgu_put_body(3);
	rgu_put_body(4);
	rgu_put_body(5);
	rgu_put_body(6);
	rgu_put_body(7);
	rgu_put_body(8);

	max_count += 8;
}

long car824_body()
{
char mlabor_fee_C[12], mmater_fee_C[12], mpaint_fee_C[12], mdmgpri_fee_C[12], mequip_fee_C[12];
char mphoto_fee_C[12], mtraffic_fee_C[12], mmail_fee_C[12], mlaw_fee_C[12], mplace_fee_C[12], mvision_fee_C[12], mother_fee_C[12];

	rgu_put_body_string(9,manufactor,1);             /*** �g�P�� ***/
	rgu_put_body_string(9,ngroup1,1);                /*** �ϳ� ***/
	rgu_put_body_string(9,Ngroup,1);                 /*** ��� ***/
	rgu_put_body_string(9,Nchi_full,1);              /*** �ߥI��H�W�� ***/

	if (strcmp(trim(Fspeed),"1") == 0)               /*** �ߥI�t�� ***/
	{
		rgu_put_body_string(9,"�ӤH",1);
	}
	else if (strcmp(trim(Fspeed),"2") == 0)
	{
		rgu_put_body_string(9,"�s�w�j���I�u��",1);
	}
	else if (strcmp(trim(Fspeed),"3") == 0)
	{
		rgu_put_body_string(9,"���O�׼t",1);
	}
	else if (strcmp(trim(Fspeed),"4") == 0)
	{
		rgu_put_body_string(9,"��L�O�׼t",1);
	}
	else if (strcmp(trim(Fspeed),"5") == 0)
	{
		rgu_put_body_string(9,"�������O��",1);
	}
	else if (strcmp(trim(Fspeed),"6") == 0)
	{
		rgu_put_body_string(9,"�@�O�p��",1);
	}
	else if (strcmp(trim(Fspeed),"7") == 0)
	{
		rgu_put_body_string(9,"�O��",1);
	}
	else if (strcmp(trim(Fspeed),"8") == 0)
	{
		rgu_put_body_string(9,"�g�P�Ӥ�I�O��",1);
	}
	else if (strcmp(trim(Fspeed),"9") == 0)
	{
		rgu_put_body_string(9,"�N�B���O��",1);
	}
	else
	{
		rgu_put_body_string(9," ",1);
	}


	if (strcmp(trim(Xsettle_type),"1") == 0)               /*** �ߥI��H���O ***/
	{
		rgu_put_body_string(9,"���q",1);
	}
	else if (strcmp(trim(Xsettle_type),"2") == 0)
	{
		rgu_put_body_string(9,"�ӤH",1);
	}
	else if (strcmp(trim(Xsettle_type),"3") == 0)
	{
		rgu_put_body_string(9,"�߮v",1);
	}
	else if (strcmp(trim(Xsettle_type),"4") == 0)
	{
		rgu_put_body_string(9,"�Ȧ�",1);
	}
	else if (strcmp(trim(Xsettle_type),"5") == 0)
	{
		rgu_put_body_string(9,"���u",1);
	}
	else if (strcmp(trim(Xsettle_type),"6") == 0)
	{
		rgu_put_body_string(9,"�ר��t",1);
	}
	else
	{
		rgu_put_body_string(9," ",1);
	}

	rgu_put_body_string(9,Iclaim,1);                 /*** �߮׸��X ***/
	rgu_put_body_string(9,Property_tag,1);           /*** ���l�Ъ����W��/���P���X ***/
	rgu_put_body_string(9,iins_type,1);              /***�I�إN�� ***/
	rgu_put_body_string(9,nins_type,1);              /***�I�ئW�� ***/

	if (strcmp(trim(Pay_kind),"1") == 0)             /*** �ߥI���O ***/
	{
		rgu_put_body_string(9,"���l",1);
	}
	else if (strcmp(trim(Pay_kind),"2") == 0)
	{
		rgu_put_body_string(9,"�ѵs",1);
	}
	else if (strcmp(trim(Pay_kind),"3") == 0)
	{
		rgu_put_body_string(9,"�]�l",1);
	}
	else if (strcmp(trim(Pay_kind),"4") == 0)
	{
		rgu_put_body_string(9,"�O��",1);
	}
	else if (strcmp(trim(Pay_kind),"5") == 0)
	{
		rgu_put_body_string(9,"�ˤ`",1);
	}
	else if (strcmp(trim(Pay_kind),"6") == 0)
	{
		rgu_put_body_string(9,"�N�B���O��",1);
	}
	else
	{
		rgu_put_body_string(9,"  ",1);
	}

	if (strcmp(trim(Frecover),"0") == 0)             /*** �l�v�O ***/
	{	
		rgu_put_body_string(9,"���ݰl�v",1);
	}
	else if (strcmp(trim(Frecover),"1") == 0)
	{
		rgu_put_body_string(9,"�ۦ�l�v",1);
	}
	else if (strcmp(trim(Frecover),"2") == 0)
	{
		rgu_put_body_string(9,"�w�ۦ�l�v",1);
	}
	else if (strcmp(trim(Frecover),"3") == 0)
	{
		rgu_put_body_string(9,"�k�Ȱl�v",1);
	}
	else if (strcmp(trim(Frecover),"4") == 0)
	{
		rgu_put_body_string(9,"�ۦ�l�v��k�Ȱl�v",1);
	}
	else if (strcmp(trim(Frecover),"5") == 0)
	{
		rgu_put_body_string(9,"�j���I�u��",1);
	}
	else if (strcmp(trim(Frecover),"6") == 0)
	{
		rgu_put_body_string(9,"�j���I�N���u�^",1);
	}
	else if (strcmp(trim(Frecover),"7") == 0)
	{
		rgu_put_body_string(9,"�\\�i�K�l�v",1);
	}
	else
	{
		rgu_put_body_string(9,"   ",1);
	}

	mtotal = mplate+mremove+mpart+mvarnish-mdeduct+mdmgpri+mequip-mshort;

	printf("mtotal[%ld]\n",mtotal);

	/*     if ((mtotal)>0)    */
	if (fsystem[0] == 'N')
	{
		/* �s�t�Φ��ɮָ�Ʈ� */
		if (mtotal > 0)
		{
			if(Mpayment == (mtotal))
			{
				mlabor_fee = mplate + mremove;  /* �u�� = �z�� + ��u */
				mmater_fee = mpart;
				mpaint_fee = mvarnish;
				mdmgpri_fee = mdmgpri;
				mequip_fee = mequip;
			}
			else
			{
				mlabor_fee = Mpayment * ((mplate + mremove)*1.0 / (mtotal));
				mmater_fee = Mpayment * ((mpart)*1.0 / (mtotal));
				mpaint_fee = Mpayment * ((mvarnish)*1.0 / (mtotal));
				mplate = Mpayment * ((mplate)*1.0 / (mtotal));
				mdmgpri_fee = Mpayment * ((mdmgpri)*1.0 / (mtotal));
				mequip_fee = Mpayment * ((mequip)*1.0 / (mtotal));
			}
		}
		else
		{
			mlabor_fee = mmater_fee = mpaint_fee = mplate = mdmgpri_fee = mequip_fee = 0;
		}
	}
	else
	{
		/* �¨t�ΨS���ɮָ�Ʈ� */
		mplate = 0;
		mremove = 0;
		mpart = 0;
		mvarnish = 0;
		mdmgpri = 0;
		mequip = 0;

		/* �P�_�ߥI��H�� �u��B�z���B��u */
		if(Mpayment == mlabor_fee)
		{
			printf("iclaim = %s, step 1\n",Iclaim);
			mmater_fee = 0;
			mpaint_fee = 0;
		}
		else if(Mpayment == mmater_fee)
		{
			printf("iclaim = %s, step 2\n",Iclaim);
			mlabor_fee = 0;
			mpaint_fee = 0;
		}
		else if(Mpayment ==  mpaint_fee)
		{
			printf("iclaim = %s, step 3\n",Iclaim);
			mlabor_fee = 0;
			mmater_fee = 0;
		}
		else if(Mpayment == (mlabor_fee+mmater_fee))
		{
			printf("iclaim = %s, step 4\n",Iclaim);
			mpaint_fee = 0;
		}
		else if(Mpayment == (mlabor_fee+mpaint_fee))
		{
			printf("iclaim = %s, step 5\n",Iclaim);
			mmater_fee = 0;
		}
		else if(Mpayment == (mmater_fee+mpaint_fee))
		{
			printf("iclaim = %s, step 6\n",Iclaim);
			mlabor_fee = 0;
		}
		else if(Mpayment != (mmater_fee+mpaint_fee+mlabor_fee))
		{
			mlabor_fee = Mpayment * ((mlabor_fee)*1.0 / (mmater_fee+mpaint_fee+mlabor_fee));
			mmater_fee = Mpayment * ((mmater_fee)*1.0 / (mmater_fee+mpaint_fee+mlabor_fee));
			mpaint_fee = Mpayment * ((mpaint_fee)*1.0 / (mmater_fee+mpaint_fee+mlabor_fee));
			mplate = 0;
		}
	}

	rfmtlong(mlabor_fee,"-##,###,##&",mlabor_fee_C);     /*** �u�� ***/
	rgu_put_body_string(9,mlabor_fee_C,1);

	rfmtlong(mplate,"-##,###,##&",mlabor_fee_C);         /* �z�� */
	rgu_put_body_string(9,mlabor_fee_C,1);
	rfmtlong(mremove,"-##,###,##&",mlabor_fee_C);        /* ��u */
	rgu_put_body_string(9,mlabor_fee_C,1);

	rfmtlong(mmater_fee,"-##,###,##&",mmater_fee_C);     /*** ���� ***/
	rgu_put_body_string(9,mmater_fee_C,1);
	rfmtlong(mpaint_fee,"-##,###,##&",mpaint_fee_C);     /*** ��� ***/
	rgu_put_body_string(9,mpaint_fee_C,1);

	/*rfmtlong(mphoto_fee, "-##,###,##&", mphoto_fee_C);*/              /*** �ۤ��O�� ***/
	/*rgu_put_body_string(9, mphoto_fee_C, 1);*/
	/*User�b�s�W ����l���ΥN�B���� ���ݨD���n�D�����ۤ��O�ΡA�]�~�ȤW�w�L�ϥ�
	���User���ЬG�ȯd�ӷ��{���X 2025/02�A����ݨDí�w�i�����]�tSQL�ӷ� */

	rfmtlong(mdmgpri_fee, "-##,###,##&", mdmgpri_fee_C);     /*** ����l���ΥN�B���� ***/
	rgu_put_body_string(9, mdmgpri_fee_C, 1);

	/*rfmtlong(mtraffic_fee, "-##,###,##&", mtraffic_fee_C);*/  /*** ��q�O�� ***/
	/*rgu_put_body_string(9, mtraffic_fee_C, 1);*/
	/*User�b�s�W ����l���ΥN�B���� ���ݨD���n�D������q�O�ΡA�ô����t�Ƥu��
	���User���ЬG�ȯd�ӷ��{���X 2025/02�A����ݨDí�w�i�����]�tSQL�ӷ� */

	rfmtlong(mequip_fee, "-##,###,##&", mequip_fee_C);     /*** �t�Ƥu�ƪ��B ***/
	rgu_put_body_string(9, mequip_fee_C, 1);

	rfmtlong(mmail_fee,"-##,###,##&",mmail_fee_C);                /*** �l��O�� ***/
	rgu_put_body_string(9,mmail_fee_C,1);
	rfmtlong(mlaw_fee,"-##,###,##&",mlaw_fee_C);                  /*** �D�^�O�� ***/
	rgu_put_body_string(9,mlaw_fee_C,1);
	rfmtlong(mplace_fee,"-##,###,##&",mplace_fee_C);              /*** �N�B���O�� ***/
	rgu_put_body_string(9,mplace_fee_C,1);
	rfmtlong(mvision_fee,"-##,###,##&",mvision_fee_C);    /*** ���T�O�� ***/
	rgu_put_body_string(9,mvision_fee_C,1);
	rfmtlong(mother_fee,"-##,###,##&",mother_fee_C);              /*** ��L�O�� ***/
	rgu_put_body_string(9,mother_fee_C,1);

	rfmtlong(Mpayment,"-##,###,##&",Mpayment_C);     /*** �ߥI���B ***/
	rgu_put_body_string(9,Mpayment_C,1);
	rgu_put_body_string(9,Ipolicy,1);                /*** �O�渹�X ***/
	rgu_put_body_string(9,trim(Nassured),1);         /*** �Q�O�I�H ***/
	rgu_put_body_string(9,trim(itag),1);                         /*** ���P���X ***/
	rgu_put_body_string(9,trim(isurveyor),1);                         /*** �ɨ��H�����s ***/
	rgu_put_body_string(9,nsurveyor_name,1);                         /*** �ɨ��H�m�W ***/
	rgu_put_body_string(9,Iadjuster_name,1);         /*** �z�ߤH������W�� ***/
	rgu_put_body_string(9,nquota1,1);         /*** �߮׳�� ***/
	rgu_put_body_string(9,nquota2,1);         /*** �z�߬�O ***/
	rgu_put_body_string(9,trim(Daccident),1);        /*** �X�I��� ***/

	if (Dclaim == -1)                            /*** ���z��� ***/
	{
		rgu_put_body_string(9," ",1);
	}
	else
	{
		rgu_put_body_string(9,cm_edate_str(Dclaim),1);
	}

	if (dpaperwork_check == -1)                      /*** ñ����� ***/
	{
	   rgu_put_body_string(9," ",1);
	}
	else
	{
		rgu_put_body_string(9,cm_edate_str(Dpaperwork),1);
	}

	if (dreceiver_check == -1)                       /*** �o����� ***/
	{
		rgu_put_body_string(9," ",1);
	}
	else
	{
		rgu_put_body_string(9,cm_edate_str(Dreceiver),1);
	}

	if ( Dentry == -1)                               /*** �z���� ***/
	{
		rgu_put_body_string(9," ",1);
	}
	else
	{
		rgu_put_body_string(9,cm_edate_str(Dentry),1);
	}

	if ( Dclose == -1)                               /*** �鵲��� ***/
	{
		rgu_put_body_string(9," ",1);
	}
	else
	{
		rgu_put_body_string(9,cm_edate_str(Dclose),1);
	}

	if ( Dgroup == -1)                               /*** �J�p��� ***/
	{
		rgu_put_body_string(9," ",1);
	}
	else
	{
		rgu_put_body_string(9,cm_edate_str(Dgroup),1);
	}

	if (dpay_check == -1 || strlen(cm_edate_str(Dpay)) == 0)             /*** �I�ڤ� ***/
	{
		rgu_put_body_string(9," ",1);
	}
	else
	{
		rgu_put_body_string(9,cm_edate_str(Dpay),1);
	}

	rgu_put_body_string(9,Paper_next_Settle,1);      /*** ñ���馸��ܲz���(�u�@��) ***/
	rgu_put_body_string(9,Paper_next_Pay,1);         /*** ñ���馸��ܥI�ڤ�(�u�@��) ***/
	rgu_put_body_string(9,Claim_Paper,1);            /*** ���z��ñ����� ***/
	rgu_put_body_string(9,Paper_Settle,1);           /*** ñ���ܲz���� ***/
	rgu_put_body_string(9,Settle_Close,1);           /*** �z��ܤ鵲��� ***/
	rgu_put_body_string(9,Close_Pay,1);              /*** �鵲�ܥI�ڤ�� ***/

	rfmtdouble(M_stl,"-##,###,###",M_stl_C);         /*** �]�Ȥ�I���B ***/
	rgu_put_body_string(9,M_stl_C,1);

	if (strcmp(trim(Fstl),"1") == 0)
	{
		rgu_put_body_string(9,"�ߥI",1);
	}
	else
	{
		rgu_put_body_string(9,"�l�v",1);
	}

	rgu_put_body_string(9,Ipayment,1);
	rgu_put_body_string(9,Iassured,1);
	rgu_put_body_string(9,Iacc_license,1);
	rgu_put_body_string(9,str_Ivictim,1);
	str_Ivictim[0]='\0';

	rgu_put_body_string(9,Note,1);
	rgu_put_body_string(9,fins_type,1);		    /*** ��W���l���O ***/

	rgu_put_body_string(9,Nfactor_type,1);     /*** ���t���O ***/
	rgu_put_body_string(9,Nmodel_type,1);      /*** ���t�t�P ***/

	rgu_put_body(9);

	max_count += 1 ;
}

long car824_build1()
{
	EXEC SQL BEGIN DECLARE SECTION;
		char  where_stat[100];
		char  iclaim1_3[4];
		char  sIquota[7];
		char  sBranch[3];
		char  sWhere1[1024];
		char  sWhere2[1024];
		char  ssIbranch[3];
		int   iRow;
		int   iRow_tmp;
		int   dmg,dmg_30,lia,lia_45,stl,stl_40;
		int   first;
	EXEC SQL END DECLARE SECTION;

	EXEC SQL WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return FAIL;
	}

	$CREATE TEMP TABLE c824
	(	
		iquota     char(6),
		iadjuster  char(11),
		dmg        int      default 0,
		dmg_30     int      default 0,
		lia        int      default 0,
		lia_45     int      default 0,
		stl        int      default 0,
		stl_40     int      default 0
	);


	EXEC SQL ifdef PETER;
		printf("############ �����`�����q�O ibranch[%s]\n",ibranch);
	EXEC SQL endif;

	if (db_select(DBName) == False)
	{
	   EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
	   return FAIL;
	}

	EXEC SQL SELECT nform_file , ntitle_fmt  , nbody_fmt , kstart_row , ktitle_row ,
				    ktot_col   , kpgnum_line , kwidth    , iform_tp
			   INTO :FormFmt   , :TitleFmt   , :BodyFmt  , :StartRow  , :TitleRow  ,
				    :TotColumn , :PgLine     , :Width    , :FormTp
			   FROM Form
			  WHERE ksys_grp = "CA" AND kPgmID = 824 AND iform_tp = '2';

	strcpy(FormFmt   , rtrim(FormFmt));
	sprintf(FormFile , "%s.tx", outputf);

	EXEC SQL ifdef PETER;
		printf("FormFile[%s] \n",FormFile);
	EXEC SQL endif;

	rgu_init_report(FormFmt,FormFile);
	car824_title();

	if (option_flag[0] == 'A')
	{
		if (fspeed[0] == 'A')
			strcpy(where_stat," ");
		else
			sprintf(where_stat,"AND b.fspeed = '%s' ",fspeed);

		EXEC SQL ifdef PETER;
		   printf("option_flag[%s],where_stat[%s]\n",option_flag,where_stat);
		EXEC SQL endif;
	}

	if (option_flag[0] == 'B')
	{
	    sprintf(where_stat,"AND b.ipayment matches '%s' AND b.ifpce_id_ext = '%s' ",ipayment,id_ext);
		EXEC SQL ifdef PETER;
		   printf("option_flag[%s],where_stat[%s]\n",option_flag,where_stat);
		EXEC SQL endif;
	}

	EXEC SQL WHENEVER SQLERROR GOTO errexit;

	if (ibranch[0] == '*')
	{
		strcpy(sWhere1," ");
	}
	else
	{
		sprintf(sWhere1," AND branch = '%s' ",ibranch);
	}

	if (ffsettle[0] == '3')
	{
		strcpy(sWhere2," ");
	}
	else
	{
		sprintf(sWhere2," AND a.fstl = '%s' ",ffsettle);
	}

	sprintf(stmt_buf,
			" SELECT branch         \
				FROM servertbl      \
			   WHERE branch != 'S1' \
				  %s                \
			   ORDER BY 1 ",sWhere1);

	$PREPARE dbid1 FROM $stmt_buf;
	$DECLARE db_cur1 CURSOR FOR dbid1;
	$OPEN db_cur1 ;
	for(;;){
		$FETCH db_cur1 INTO $sBranch;
		if (SQLCODE == SQLNOTFOUND) break;

		dmg = dmg_30 = lia = lia_45 = stl = stl_40 = 0;
		sprintf(stmt_buf,
				 "SELECT a.iclaim  , a.dclose    , \
						 a.iadjuster , a.ipolicy   , \
						 b.ipayment  , b.ifpce_id_ext , \
						 b.mpayment  , b.fspeed       , b.pay_kind  , \
						 a.fstl      , a.iclose_type  \
					FROM %s:settlement a, %s:payment b \
				   WHERE a.iclaim      = b.iclaim \
					 AND a.fstl        = b.fstl \
					 AND a.iclose_type = b.iclose_type \
					 AND a.dclose >= ? AND a.dclose <= ? %s %s \
				   ORDER BY a.iclaim ",
						 get_full_dbname(sBranch),get_full_dbname(sBranch),sWhere2,where_stat);
		printf("stmt_buf[%s]\n",stmt_buf);
		EXEC SQL PREPARE Acursora  FROM :stmt_buf;
		EXEC SQL DECLARE Acursor1a CURSOR FOR Acursora;
		EXEC SQL OPEN Acursor1a USING :clsdatebgn , :clsdateend;

		while (1)
		{
			dpaperwork_check = dpay_check = m_stl_check = 0;
			M_stl = 0;

			EXEC SQL FETCH Acursor1a INTO :Iclaim    , :Dclose       ,
										  :Iadjuster , :Ipolicy      ,
										  :Ipayment  , :Ifpce_id_ext ,
										  :Mpayment  , :Fspeed       , :Pay_kind ,
										  :Fstl      , :Iclose_type  ;

			if (SQLCODE == SQLNOTFOUND) break;

			strcpy(Iclose_type_C,itoa(Iclose_type));

			strncpy(iclaim1_3,Iclaim,3);
			iclaim1_3[3] = '\0';

			/*** �z�ߤH������W�� ***/
			EXEC SQL SELECT iquota[1,4]
					   INTO :sIquota
					   FROM officer
					  WHERE iofficer = :Iadjuster;

			/*** �߮ר��z��� ***/
			EXEC SQL SELECT dclaim
					   INTO :Dclaim
					   FROM ca_clm_process
					  WHERE iclaim = :Iclaim;

			/*** ��I����Τ�I���B ***/
			M_stl = Mpayment;

			/*** �߮ר��z��� ***/
			strcpy(sIquota,rtrim(sIquota));
			strcat(sIquota,"00");

			/*** �z��ܤ鵲��� ***/
			ldcnt = Dclose - Dclaim;

			switch(Pay_kind[0]){

				case '1':
					if (Fstl[0] == '1'){
						if (M_stl <= 50000){
							dmg++;
							if (ldcnt <= 30){
								dmg_30++;
							}
						}
					}else{
						dmg++;
						if (ldcnt <= 30){
							dmg_30++;
						}
					}
					break;
				case '2':
					stl++;
					if (ldcnt <= 40){
						stl_40++;
					}
					break;
				case '3':
					if (Fstl[0] == '1'){
						if (M_stl <= 50000){
							lia++;
							if (ldcnt <= 45){
								lia_45++;
							}
						}
					}else{
						lia++;
						if (ldcnt <= 45){
							lia_45++;
						}
					}
					break;
				default:
					break;
			}

			$INSERT INTO c824 VALUES
			   ($sIquota,$Iadjuster,$dmg,$dmg_30,$lia,$lia_45,$stl,$stl_40);
			dmg = dmg_30 = lia = lia_45 = stl = stl_40 = 0;

		}
		$CLOSE Acursor1a;
		$FREE Acursor1a;

	}
	$CLOSE db_cur1;
	$FREE  db_cur1;

	car824_body1();

	if (max_count == 0)
	{
		EWRITE(userid, M_CM_NOT_FOUND, "no data found in [car824] !!");
		return FAIL;
	}
	return SUCCESS;

errexit:
	printf("build:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	exit(FAIL);
}



long car824_body1()
{
$char iquota[7];
$char iadjuster[11];
$int  dmg,dmg_30,lia,lia_45,stl,stl_40;
$char nname[21];
$char ssIbranch[3];
$char sNchi_full[5];
$char Ngroup[21];
$int  sumall,sumday;
$double pratio,dtmp;
$char   sTmp[15];

	$WHENEVER SQLERROR GOTO errexit;

	$DECLARE bod_cur CURSOR FOR
	  SELECT iquota,iadjuster,sum(dmg),sum(dmg_30),
		     sum(lia),sum(lia_45),sum(stl),sum(stl_40),sum(dmg+lia+stl),
		     sum(dmg_30+lia_45+stl_40)
	    INTO $iquota,$iadjuster,$dmg,$dmg_30,$lia,$lia_45,
		     $stl,$stl_40,$sumall,$sumday
	    FROM c824
	   GROUP BY 1,2
	   order by 1,2;
	$OPEN bod_cur;
	for(;;){
		$FETCH bod_cur;
		if (SQLCODE == SQLNOTFOUND) break;

		$SELECT nname,ibranch
		   INTO $nname,$ssIbranch
		   FROM officer
		  WHERE iofficer = $iadjuster;
		if (SQLCODE == SQLNOTFOUND){
			strcpy(nname," ");
			strcpy(ssIbranch," ");
		}

		$SELECT nchi_full[1,4]
		   INTO $sNchi_full
		   FROM branch
		  WHERE ibranch = $ssIbranch;

		if (SQLCODE == SQLNOTFOUND) strcpy(sNchi_full," ");

		$SELECT nbranch
		   INTO $Ngroup
		   FROM sa_branch_type
		  WHERE ibranch = $iquota;
		if (SQLCODE == SQLNOTFOUND) strcpy(Ngroup," ");

		rgu_put_body_string(9,rtrim(Ngroup),1);                 /*** ���� ***/
		rgu_put_body_string(9,rtrim(sNchi_full),1);             /*** ��� ***/
		rgu_put_body_string(9,rtrim(nname),1);                  /* �z�߭� */
		rgu_put_body_string(9,itoa(dmg),1);
		rgu_put_body_string(9,itoa(dmg_30),1);
		rgu_put_body_string(9,itoa(lia),1);
		rgu_put_body_string(9,itoa(lia_45),1);
		rgu_put_body_string(9,itoa(stl),1);
		rgu_put_body_string(9,itoa(stl_40),1);
		rgu_put_body_string(9,itoa(sumall),1);
		rgu_put_body_string(9,itoa(sumday),1);

		if (sumall == 0){
			pratio = 0;
		}else{
			dtmp = 100 * (double)sumday / (double)sumall;
			pratio = d45(dtmp);
		}

		rfmtdouble(pratio,"-----&",sTmp);

		strcat(sTmp," %");
		rgu_put_body_string(9,rtrim(sTmp),1);
		rgu_put_body(9);

		max_count += 1 ;
	}
	$CLOSE bod_cur;
	$FREE  bod_cur;

	return TRUE;
errexit:
	printf("build:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	exit(FAIL);
}

double d45(num)
double num;
{
long tmplong;
double var1;

     if (num >= 0) var1 = 0.5;
     else var1 = (-0.5);

     num = num + var1;
     tmplong = num;
     num = tmplong;

     return(num);

}

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
	char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
	char sTmp_db_name[21];

	sTmp_db_name[0]='\0';
	if (*sIpolicy != '\0' && *sIpolicy !=' ')
	{
		sTmp_db_name[0]='\0';
		strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
		strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
			  USE_BRANCH_ID));
		strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
	}
	return sTmp_db_name;
}

