/**********************************************************************/
/*   program id   : ca847q01s.ec                                      */
/*   program name : �ƬG�{���B�z�O�γ���                              */
/*   date written : 2018/02/21 by sylvia                              */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "safeclib.h"


char  outputf[21];
$char userid[11], sdate1[11], sdate2[11],ipayno[13],proce_type[2];
$char DBName[5];
$char msgbuf[1000],sApHome[30];
char  opt[2],dbgn[11],dend[11];
int rc;
DBinfo  *list;
int   count_db;
$int icnt;
    
main(argc, argv)
int argc;
char **argv;
{

	batchinit();

	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(opt,            isNULLstr(argv[3])); /* �d�����O:0:�w������ 1:���ɤ�� */
	strcpy(ipayno,         isNULLstr(argv[4])); /* �w�����渹 */
	strcpy(dbgn,           isNULLstr(argv[5])); /* ���ɤ��:�_�� */
	strcpy(dend,           isNULLstr(argv[6])); /* ���ɤ��:���� */
	strcpy(proce_type,     isNULLstr(argv[7])); /* �B�z�H�����O:0���� 1�s�w�z�� 2����H�� 3���ӤH�� 4����*/
	strcpy(outputf,        isNULLstr(argv[8]));
	
	strcpy(sdate1,cm_to_infdate(dbgn));
	strcpy(sdate2,cm_to_infdate(dend));
	
	printf("opt=[%s]ipayno=[%s]\n",opt,ipayno);
	
	rc = car847_get_db();
    if (rc != M_CM_OK) {
        printf("error on car847_get_db\n");
        return rc;
    }
	
	rc = car847_prepare_data();
	if (rc != M_CM_OK) {
	    printf("error on car847_prepare_data\n");
		return rc;
    }
    
	rc = car847_build();
	if (rc != M_CM_OK) 
		return rc;
}
/* ------------------------------------------------------------------------- */
long car847_get_db()
{
    long	rc;
    
    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
    }

    if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;
    }

    rc = getApHome(sApHome);

    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }
    
    $create temp table tb847
    (
        iclaim          char(20),   --�߮׸�
        itag            char(20),   --����
        iproce_type     char(20),   --�B�z�H�����O
        nchi_full       char(20),   --�B�z�H���W��
        mpayment        int,        --���B
        ipayno          char(20),   --�w�����渹
        nbranch         char(30),   --���ݳ��
        nadjuster       char(20),   --�z�ߤH��
        dentry          char(30),   --���ɤ��
        vouch_state     char(20),   --�z��Ѫ��A
        dclose          date,       --�鵲��
        fspeed          char(1),    --�t�קO
        dgroup          date        --�J�p��
    )with no log;
    
    return M_CM_OK;
}
/* ------------------------------------------------------------------------- */
long car847_prepare_data()
{
	$WHENEVER SQLERROR GOTO errexit;

    $char  sTmp1[100],sTmp2[200],stmt1[3000];
    int i;
    
    
    /* �w�����渹 �� ���ɤ�� */
    if (opt[0] == '0') {
        sprintf_s(sTmp1,100,"and a.ipayno matches '%s'",ipayno);
    }
    else if (opt[0] == '1') {
        sprintf_s(sTmp1,100,"and date(a.dentry) between '%s' and '%s' ",sdate1,sdate2);
    }
    else
        strcpy(sTmp1," ");
   
   printf("--132--sTmp1=[%s]\n",sTmp1);
        
    /* �B�z�H�����O */
    /* ��Ūpaymnet.iprocess-type modify by sylvia 107.05.04 (1070403001_SC1, 1070413006_SC1) */
    if (proce_type[0] == '1') {
        /* sprintf_s(sTmp2,200,"and b.fspeed = 'B' and b.ipayment <> '16784078' "); */
        sprintf_s(sTmp2,200,"and b.iprocess_type = 'A' ");
    }
    else if (proce_type[0] == '2') {
        /* sprintf_s(sTmp2,200,"and b.fspeed = 'A' and b.ipayment <> '16784078' "); */
        sprintf_s(sTmp2,200,"and b.iprocess_type = 'B' ");
    }
    else if (proce_type[0] == '3') {
        /* sprintf_s(sTmp2,200,"and b.ipayment = '16784078' "); */
        sprintf_s(sTmp2,200,"and b.iprocess_type in ('C','D') ");
    }
	else if (proce_type[0] == '4') {
        /* sprintf_s(sTmp2,200,"and b.ipayment = '83446817' "); */
        sprintf_s(sTmp2,200,"and b.iprocess_type = 'E' ");
    }
    else
        strcpy(sTmp2," ");
    
    printf("--147--sTmp2=[%s]\n",sTmp2);
    
	icnt = 0;
	for (i=0; i<count_db; i++)
    {
        /* sprintf_s(stmt1,3000,
            "insert into tb847 \
             select trim(a.iclaim)||'-'||a.iclose_type as iclaim, ''||trim(c.itag) as itag, \
                    case when b.ipayment = '16784078' then '���ӤH��' \
                         when b.ipayment <> '16784078' and fspeed = 'A' then '����H��' \
                         when b.ipayment <> '16784078' and fspeed = 'B' then '�s�w�z�ߤH��' \
                    else '  ' end as iproce_type, b.nchi_full, b.mpayment, \
                    a.ipayno, (select nbranch from sa_branch_type where ibranch = \
                    (select iquota from officer where iofficer = a.iadjuster)) as nbranch, \
                    (select nname from officer where iofficer = a.iadjuster) as nadjuster, \
                    a.dentry, decode(a.vouch_state,100,a.vouch_state||':��ñ��', \
                    110,a.vouch_state||':ñ�֤�',130,a.vouch_state||':ñ�֧���',90, \
                    a.vouch_state||':�h��',80,a.vouch_state||':�h�^ñ��',\
                    a.vouch_state||' ') as vouch_state, \
                    a.dclose, b.fspeed, a.dgroup \
             from %s:settlement a, %s:payment b, %s:adjustment_ply c \
            where a.iclaim = b.iclaim and a.iclaim = c.iclaim \
              and a.fstl = b.fstl and a.iclose_type = b.iclose_type \
              and a.fstl = '1' \
              and a.dentry >= '2018-01-01 00:00:00' \
              and a.ientry = 'car539' %s %s ", 
              list[i].dbname, list[i].dbname, list[i].dbname, sTmp1, sTmp2); */
              
        sprintf_s(stmt1,3000,
            "insert into tb847 \
             select trim(a.iclaim)||'-'||a.iclose_type as iclaim, ''||trim(c.itag) as itag, \
                    case when b.iprocess_type in ('C','D') then '���ӤH��' \
                         when b.iprocess_type = 'B'  then '����H��' \
                         when b.iprocess_type = 'A'  then '�s�w�z�ߤH��' \
						 when b.iprocess_type = 'E'  then '����' \
                    else '  ' end as iproce_type, b.nchi_full, b.mpayment, \
                    a.ipayno, (select nbranch from sa_branch_type where ibranch = \
                    (select iquota from officer where iofficer = a.iadjuster)) as nbranch, \
                    (select nname from officer where iofficer = a.iadjuster) as nadjuster, \
                    a.dentry, decode(a.vouch_state,100,a.vouch_state||':��ñ��', \
                    110,a.vouch_state||':ñ�֤�',130,a.vouch_state||':ñ�֧���',90, \
                    a.vouch_state||':�h��',80,a.vouch_state||':�h�^ñ��',\
                    a.vouch_state||' ') as vouch_state, \
                    a.dclose, b.fspeed, a.dgroup \
             from %s:settlement a, %s:payment b, %s:adjustment_ply c \
            where a.iclaim = b.iclaim and a.iclaim = c.iclaim \
              and a.fstl = b.fstl and a.iclose_type = b.iclose_type \
              and a.fstl = '1' \
              and a.dentry >= '2018-01-01 00:00:00' \
              and a.ientry = 'car539' %s %s ", \
              list[i].dbname, list[i].dbname, list[i].dbname, sTmp1, sTmp2);      
        printf("stmt1=[%s]\n",stmt1);
        $prepare ins_tb847 from $stmt1;
        $execute ins_tb847;
    }
    
    $select count(*) into $icnt
      from tb847
     where 1=1; 
	
	/* �Y�d�L���,�g�@���T����USER���D */
	if (icnt == 0)
	{
	    $insert into tb847 (iclaim) values ('�d�L��ơA�Э��s�T�{');
	}
		
	return M_CM_OK;
	
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/


long car847_build()
{
    $char    sfilename[51], stitle[1000], stmt[1000];
    
	$WHENEVER SQLERROR GOTO errexit;

	strcpy(sfilename,"�ƬG�{���B�z�O�γ���");
	if (opt[0] == '0')
	{
	    sprintf_s(stitle,1000,"�w�����渹:%s\t",ipayno);
	} else {
	    sprintf_s(stitle,1000,"���ɤ��:%s~%s\t",dbgn,dend);
	}
	strcat(stitle,"\n");
	strcat(stitle,"\t�߮׸�\t����\t�B�z�H�����O\t�B�z�H���W��\t���B\t�w�����渹\t");
	strcat(stitle,"���ݳ��\t�z�ߤH��\t���ɤ��\t�z��Ѫ��A\t�鵲��\t�t�קO\t�J�p��\t");
	
	sprintf_s(stmt,1000,
	    "select * from tb847 order by 1 ");
	
	rc = unload_file(outputf," ",sfilename,stitle,stmt);
	
	if (rc != SUCCESS) 
	{
	    sprintf_s(msgbuf,1000," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}
