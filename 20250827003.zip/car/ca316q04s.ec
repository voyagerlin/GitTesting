/**********************************************************************/
/*   ���I��O�����έp��                    			      */
/*   �O�N�S����O�v�έp                    			      */
/*   PROGRAM : car316q04s.ec               			      */
/*   Modify  : 94.12.08 by Jessie          			      */
/**********************************************************************/
/*                             MODIFICATION LOG                        *
 *                                                                     *
 *   DATE         SE                         DESCRIPTION               *
 * --------  -------------  ----------------------------------------   *
 * 20110302  Jessie         �g�P�Ӥ��^�k�έp�W�h�ק�                   *
 **********************************************************************/


#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
$include sqltypes.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"

#define  head_line         1
#define  data_line         2

extern char RPTDIR[];

$char stmt[5000];
$char quota[6],type[2];
$char dclose[11],dclose_end[11],dopen[11],dopen_end[11];
$static char dbgn1[11], dend1[11];
$static char dbgn_inf[11], dend_inf[11];
char  MsgCode[50],msgbuf[100];

$char DBName[5], iForm_Tp[3];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[N_FILE+1], userid[11];

$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;

int  max_cnt;

long car316_build1();
long car316_build7();
long car316_body1();
long car316_body7();
long car316_accumulate();

main(argc, argv)
int argc;
char **argv;
{
   int rc,str_len;

   batchinit();
   strcpy(DBName,  isNULLstr(argv[1]));
   strcpy(userid,  isNULLstr(argv[2]));
   strcpy(dbgn1,   isNULLstr(argv[3]));
   strcpy(dend1,   isNULLstr(argv[4]));
   strcpy(dopen,   isNULLstr(argv[5]));
   strcpy(dclose,  isNULLstr(argv[6]));

   strcpy(outputf, isNULLstr(argv[7]));

   strcpy(dbgn_inf,   cm_to_infdate(dbgn1));
   strcpy(dend_inf,   cm_to_infdate(dend1));
   strcpy(dopen_end,  cm_to_infdate(dopen));
   strcpy(dclose_end, cm_to_infdate(dclose));

   printf("dopen_end[%s]\n",dopen_end);

   rc = car316_accumulate();

   if ( rc != M_CM_OK)
   {
        EWRITE(userid, rc, " ");
        return rc;
   }

   max_cnt=0;

   strcpy(MsgCode," ");
   rc = car316_build1(); /****  �O�N�� ****/
   if (rc != M_CM_OK)
   {
       if (MsgCode[0]==' ')
           EWRITE(userid, rc, " ");
       else
           EWRITE(userid, rc, MsgCode);
       return rc;
   }

   max_cnt=0;
   strcpy(MsgCode," ");
   rc = car316_build7(); /****�O�N����� ****/
   if (rc != M_CM_OK)
   {
       if (MsgCode[0]==' ')
           EWRITE(userid, rc, " ");
       else
           EWRITE(userid, rc, MsgCode);
       return rc;
   }
}

long car316_build1()
{
   int    rc;

   max_cnt = 0;
   printf("build1 start\n");
   $WHENEVER SQLERROR GOTO errexit;

   rc = car316_body1(); /**** �O�N�� ****/
   if (rc != M_CM_OK)
       return rc;

   return M_CM_OK;

errexit:
   sqlfatal();
   return SQLCODE;
}

long car316_build7()
{
   int    rc;

   max_cnt = 0;
   printf("build7 start\n");
   $WHENEVER SQLERROR GOTO errexit;

   rc = car316_body7(); /**** �O�N�� ****/

   if (rc != M_CM_OK)
       return rc;

   return M_CM_OK;

errexit:
   sqlfatal();
   return SQLCODE;
}

/*-----------------------------------------------------------------*/
long car316_accumulate()
{
   $char tmp_fulldb[40], stmt[4096], db_ibranch[3], stmt1[4096], stmt2[4096];
   $char itop[2], idealer[4], iofficer[11], iresource[2], dissue[11];
   $char iresource_1[2], iresource_2[2],itag[CA_TAG_NUM],itag_t[CA_TAG_NUM];
   $char itop_t[2], idealer_t[4], iofficer_t[11], iresource_t[2], dissue_t[11];
   $char inext_ply[21], fcard_class[2], ins_type[INSURANCE_TYPE], fedr_class[2], tmp_year[4];
   $char iofficer_o[11], iofficer_n[11], idealer_n[4], iissue_yy[4], t_yy[5];
   $char iofficer_1[11], iofficer_2[11], dendorse[11], iedr_type[3];
   $char ipolicy[21], iquota[7], iquota_t[7], iquota_n[7], iofficer_old[11];
   $long prem_t, prem, con_cnt;
   $long mdamage_cover;
   $int  id1,id2,id3,id4, myear, mark, t_year, o_year, mark_edr;
   $int  qrenew;

   $char stmt3[4096], stmt4[4096], stmt5[1024];
   $char LHsIquota[7], LHsItop[2], LHsIofficer[11], LHsIresource[2];
   $char LHsIlast_ply[11], LHsIdealer[4];
   $char ori_dply_end[11];
   $char tmp_dply_end[11];
   $char deffect[11];
   $int  ricnt,clmcnt, dmove_type;
   $char move_date[11], move_type[3], id_no[11];
   $char next_dpolicy[11];
   $char iquota_1[7],iquota_2[7];
   $char iquota_old[7];
   $char iofficer_un[11];
   $char iengine[CA_ENGINE_NUM],iengine_t[CA_ENGINE_NUM],nassured[13];
   $char CD_iofficer[11];
   $char iofficer_next[11],ileader[11];
   $long duty_date, dstatic;
   $char char_duty_date[11], tmp_duty_date[11];
   $char dudate[11];
   $char ori_dply_begin[11],new_dply_begin[11],ori_dpolicy[11],new_dpolicy[11];
   $char ori_ibigsales[11],new_ibigsales[11];
  /* $char sequip_str[201];*/
   $long dperiod;   /* Modified by Julia in 2007/01/17 */
   
   long  dbgn_long,dend_long,dw_bgn,dw_end;

   int   rtncode = 0, LiFlag = 0;
   int   k,count_db;
   DBinfo *list;

   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

   if (db_select(DBName) == False)
   {
       return M_CM_DB_NOTOPEN;
   }

   /**** �O�N�������� ****/
   $CREATE TEMP TABLE CAR316
    (
      iofficer          char(10) not null,
      iquota            char(6) not null,
      iofficer_t        char(10) default ' ',
      iquota_t          char(6)  default ' ',
      iresource         char(01) not null,
      iresource_t       char(01) not null,
      ipolicy           char(20) not null,
      myear             integer default 0 not null,
      inext_ply         char(20),
      con_cnt           integer      default 0 not null,
      prem              decimal(10,0) default 0 not null,
      qrenew            integer not null
    ) WITH NO LOG;

   $CREATE TEMP TABLE CAR316_TMP3
    (
      iofficer          char(10) default ' ',
      iquota            char(6)  default ' ',
      dply_begin        char(10) default ' ',
      dpolicy           char(10) default ' ',
      ibig_sales        char(10) default ' ',
      iofficer_t        char(10) default ' ',
      iquota_t          char(6)  default ' ',
      dply_begin_t      char(10) default ' ',
      dpolicy_t         char(10) default ' ',
      ibig_sales_t      char(10) default ' ',
      ipolicy           char(20) default ' ',
      dissue            date default null,
      inext_ply         char(20) default ' ',
      con_cnt           integer       default 0 ,
      prem              decimal(10,0) default 0 ,
      iresource         char(1),
      iresource_t       char(1),
      nassured          char(12),
      iengine           char(25),
      iengine_t         char(25),
      itag              char(12),
      itag_t            char(12),
      qrenew            integer,
      iofficer_s        char(10),
      iquota_s          char(6)
    ) WITH NO LOG;

   strcpy(fcard_class, "2");
   id1 = 0;

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   /* ���دu�|��M��,�����ץ~�X�G�i�O��,�ҥH�����N�����O���O����Ʀ��� */
   /******** 20110302 �ɶ��w�[��,���ݦA�P�_--����
   rstrdate(dbgn_inf,&dbgn_long);
   rstrdate(dend_inf,&dend_long);
   rstrdate("05/01/2003",&dw_bgn);
   rstrdate("08/15/2003",&dw_end);
   if ((dbgn_long <= dw_bgn && dend_long >= dw_bgn) ||
       (dbgn_long >= dw_bgn && dbgn_long <= dw_end)) { 
       strcpy(sequip_str,equip_instr("09"));
       sprintf_s(stmt5, sizeof stmt5,"AND NOT (b.nequipment[9] in %s  "
                          "AND a.iofficer[1] in ('C','D','K')  "
                          "AND a.dply_end between '05/01/2003' AND '08/15/2003' "
                          "AND a.icar_flag = '1')",sequip_str);
   }
   else
   by Jessie ********/
       strcpy(stmt5," ");

   for(k=0;k<count_db;k++)
   {
     sprintf_s(stmt, sizeof stmt,
     " SELECT count(*)                 "
        " FROM reject_policy            "
        "WHERE ipolicy = ?              "
        "  AND fins_grp = '3'  ");
     $PREPARE rpid FROM $stmt;

     sprintf_s(stmt, sizeof stmt,
     "  SELECT count(*)                  "
        " FROM %s:appraisal              "
        "WHERE ipolicy = ?               "
        "  AND fpart IN ('1','2','3') ",list[k].dbname);
     $PREPARE clmid FROM $stmt;
     
     /****** 20110302
     sprintf_s(stmt, sizeof stmt,
     " SELECT iofficer_new       "
        " FROM collate_officer    "
        "WHERE iofficer_old = ? ");
     $PREPARE col_1 FROM $stmt;
     *******/

     sprintf_s(stmt, sizeof stmt,
     " SELECT iquota[1,4] || '00'           "
        " FROM %s:ori_ply_relation           "
        "WHERE ipolicy = ? ",list[k].dbname);
     $PREPARE ori_id_old FROM $stmt;
     
     sprintf_s(stmt, sizeof stmt," SELECT a.ipolicy,b.dissue,a.iofficer,a.iresource, "
                           "a.inext_ply,a.mdmg_prem+a.mlia_prem,a.dply_end, "
                           "a.dply_begin,a.dpolicy,a.ibig_sales,itag, "
                           "iengine,nassured[1,12],(a.dply_end - a.dply_begin)  "
                    " FROM %s:ply_relation a,%s:policy b,officer c  "
                    "WHERE a.fcard_class = ?  "
                    "  AND a.dpolicy <= ?  "
                    "  AND a.dply_end >= ?  "
                    "  AND a.dply_end <= ?  "
                    "  AND a.fedr_class <> '1'  "
                    "  AND a.ipolicy = b.ipolicy  "
                    "  AND a.iofficer = c.iofficer  "
                    "  AND c.imgr = '1'  "
                    "  AND a.iofficer[1,3] not in ('G98','F98')  "
                    "  AND a.iresource != 'E' %s",
                   list[k].dbname,list[k].dbname,stmt5);

     $PREPARE pol_cur1 FROM $stmt;
     $DECLARE pol_cur CURSOR FOR pol_cur1;
     $OPEN pol_cur USING $fcard_class, $dopen_end, $dbgn_inf, $dend_inf;
     while(1)
     {
       $FETCH pol_cur INTO $ipolicy, $dissue,
                           $iofficer, $iresource, $inext_ply, $prem,
                           $ori_dply_end,
                           $ori_dply_begin,$ori_dpolicy,$ori_ibigsales,
                           $itag,$iengine,$nassured,$dperiod;
       if(SQLCODE == SQLNOTFOUND) break;

       /* �ګO�Ȥ� */
       $EXECUTE rpid
           INTO $ricnt
          USING $ipolicy;
       if (ricnt > 0) 
       {
          if (strlen(trim(inext_ply)) != 0) /*�ګO�Ȥ�Y�w��O,���C�J���ƭp��*/
          {
             strcpy(tmp_fulldb,get_car_full_db(inext_ply));
             sprintf_s(stmt, sizeof stmt,
             " SELECT count(*)           "
                " FROM %s:ply_relation    "
                "WHERE ipolicy = ?        "
                "  AND dpolicy <= ?       "
                "  AND fedr_class != '1'  "
                "  AND dply_close IS NOT NULL ",tmp_fulldb);
             $PREPARE rpne FROM $stmt;
             $EXECUTE rpne 
                 INTO $ricnt
             USING $inext_ply,$dclose_end;
             if (ricnt == 0) 
             {
                /*printf("ipolicy[%s],inext_ply[%s] continue \n",ipolicy,inext_ply);*/
                continue;
             }
          }
          else
          {
                /*printf("ipolicy[%s],inext_ply[%s] continue \n",ipolicy,inext_ply);*/
                continue;
          }
       }
      /* ���l�� */
      $EXECUTE clmid INTO $clmcnt USING $ipolicy;
      if (clmcnt > 0) continue;
      
      /* Modified by Julia - �Y�L��O�渹�B�O������273�ѫh���C�J��O�έp */
      if((inext_ply[0] == '\0' || inext_ply[0] == ' ') && dperiod < 273) 
      {  printf("dperiod and inext_ply[%ld][%s]\n",dperiod,inext_ply);
	 continue; }

      /* �¶��q(C)���µؤ�(D)�ιL�״�(J07)�ഫ���s���q�N�� */
      /***20110302 by Jessie �ɥN�w�[��,�BJ07�w�t�s�s�N���ϥ�
      if ((iofficer[0] == 'C') || (iofficer[0] == 'D') ||
          (strncmp(iofficer,"J07",3)==0))
      {
           $EXECUTE col_1  
               INTO $CD_iofficer
              USING $iofficer;
            if (SQLCODE == SQLNOTFOUND)
            {
                strcpy(CD_iofficer,iofficer);
            } 

         strcpy(iofficer,CD_iofficer);
      }
      **********/

      con_cnt = mark = 0;

      sprintf_s(stmt2, sizeof stmt2," SELECT iins_type, fedr_status, nvl(dendorse,' '), mdamage_cover  "
                       " FROM %s:ply_ins_type  "
                       "WHERE ipolicy = ?", list[k].dbname);
      $PREPARE ins_cur1 FROM $stmt2;
      $DECLARE ins_cur CURSOR FOR ins_cur1;
      $OPEN ins_cur USING $ipolicy;
      while(1)
      {
         $FETCH ins_cur INTO $ins_type, $fedr_class, $dendorse, $mdamage_cover;

         if(SQLCODE == SQLNOTFOUND) break;

         mark_edr = 0;

         /* �I�جO�_���Ĩ̫O�I���B�ӧP�_ */
         if (mdamage_cover > 0)
         {
             mark = 1;
             break;
         }

         /*�ҥ~�G33�I�سQ�O�I�H���h�ɡAfedr_class����'1','2','3'���O�I���B��0*/
         if ((fedr_class[0] != '1' && fedr_class[0] != '2' &&
              fedr_class[0] != '3') && (mdamage_cover > 0))
         {
             mark = 1;
             break;
         }
         else
         {
             if (dendorse != " ")
             {
                 sprintf_s(stmt3, sizeof stmt3,"select iedr_type  "
                                " from %s:edr_relation a,%s:edr_ins_type b  "
                                "where a.ipolicy = ?  "
                                "  and a.dendorse <= ?  "
                                "  and a.iendorse = b.iendorse ",
                         list[k].dbname,list[k].dbname);
                 $prepare pre_edr from $stmt3;
                 $declare cur_edr cursor for pre_edr;
                 $open cur_edr using $ipolicy, $dopen_end;
                 while(1)
                 {
                     $fetch cur_edr into $iedr_type;
                     if (SQLCODE==SQLNOTFOUND) break;
                     if (strncmp(iedr_type,"01",2)==0 ||
                         strncmp(iedr_type,"02",2)==0 ||
                         strncmp(iedr_type,"03",2)==0)
                     {
                          mark_edr = 1;
                     }

                     if (strncmp(iedr_type,"50",2)==0)
                     {
                          mark_edr = 0;
                     }
                }

                if (mark_edr==0)
                {
                     mark = 1;
                     break;
                }
             }
         }
      }
      $CLOSE ins_cur;
      $FREE  ins_cur;

      if(mark == 0)
      {
            /****    This policy is cancelled    ****/
            /*printf("  mark == 0 ���� \n");*/
            continue;
      }
      else
      {
            mark = 0;
      }

      if (inext_ply[0] == '\0' || inext_ply[0] == ' ')
      {
         /****    This policy is not continue ����O   ****/
         printf(" �S����O  ................... \n");
         strcpy(iresource_t, iresource);
         strcpy(iresource_1, iresource);
         strcpy(iresource_2, " ");
         strcpy(iofficer_t, iofficer);
         strcpy(iofficer_1, iofficer);
         strcpy(iofficer_2, " ");
         strcpy(new_dply_begin," ");
         strcpy(new_dpolicy," ");
         strcpy(new_ibigsales," ");
         strcpy(iengine_t," ");
         strcpy(itag_t," ");
         con_cnt = 0;
         prem = 0;
          
         $EXECUTE ori_id_old
             INTO $iquota
            USING $ipolicy;
         if (SQLCODE == SQLNOTFOUND)
         {
              printf("Can't find iofficer's[%s] iquota\n",iofficer);
              goto errexit;
         }
         strcpy(iquota_1, iquota);
         strcpy(iquota_2, " ");
         qrenew = 0;
      }
      else
      {
         /****    This policy is insured  again �w��O   ****/
         strcpy(tmp_fulldb,get_car_full_db(inext_ply));

         sprintf_s(stmt, sizeof stmt," SELECT iquota[1,4] || '00'  "
                        " FROM %s:ori_ply_relation  "
                        "WHERE ipolicy = ? ",tmp_fulldb);
         $PREPARE ori_id FROM $stmt;

         sprintf_s(stmt1, sizeof stmt1, "SELECT iofficer, iengine,itag,  "
                                "iresource, mdmg_prem+mlia_prem, dissue,  "
                                "ilast_ply, dpolicy, dply_begin, dpolicy, ibig_sales  "
                          " FROM %s:ply_relation a,%s:policy b "
                          "WHERE a.ipolicy = ?  "
                          "  AND dpolicy <= ?  "
                          "  AND fedr_class != '1'  "
                          "  AND dply_close IS NOT NULL  "
                          "  AND a.ipolicy = b.ipolicy ",tmp_fulldb,tmp_fulldb);

         $PREPARE new_pol_1 FROM $stmt1;
         $DECLARE new_pol CURSOR FOR new_pol_1;
         $OPEN new_pol USING $inext_ply, $dclose_end;

         $FETCH new_pol INTO $iofficer_t,   $iengine_t,    $itag_t,
                             $iresource_t,  $prem_t,       $dissue_t,
                             $LHsIlast_ply, $next_dpolicy, $new_dply_begin,
                             $new_dpolicy,  $new_ibigsales;

         if (SQLCODE == SQLNOTFOUND)
         { 
            /****    This policy is not continue    ****/
            strcpy(iresource_t, iresource);
            strcpy(iresource_1, iresource);
            strcpy(iresource_2, " ");
            strcpy(iofficer_t, iofficer);
            strcpy(iofficer_1, iofficer);
            strcpy(iofficer_2, " ");
            strcpy(new_dply_begin," ");
            strcpy(new_dpolicy," ");
            strcpy(new_ibigsales," ");
            strcpy(iengine_t," ");
            strcpy(itag_t," ");
            con_cnt = 0;
            prem = 0;

            $EXECUTE ori_id_old
                INTO $iquota
               USING $ipolicy;
            if (SQLCODE == SQLNOTFOUND)
            {
                 printf("Can't find ipolicy's[%s] iquota\n",ipolicy);
                 goto errexit;
            }

            strcpy(iquota_1, iquota);
            strcpy(iquota_2, " ");
            strcpy(inext_ply," ");
            qrenew = 0;
         }
         else
         {
              /* ���ƭn�t�Ҧ��g�P���q�� 94.12.08 */

            strcpy(dissue, trim(dissue));
            strcpy(dissue_t, trim(dissue_t));

            if (strcmp(dissue, dissue_t)!=0)
                strcpy(dissue, dissue_t);

	    /*** 20110302 by Jessie �µؤ����¶��q�X��,�~�N�w�[��,���A�ഫ�N��
            if ((iofficer_t[0] == 'C') || (iofficer_t[0] == 'D') || 
                (strncmp(iofficer_t,"J07",3)==0))
            {
                 $EXECUTE col_1
                     INTO $CD_iofficer
                    USING $iofficer_t;
                 if (SQLCODE == SQLNOTFOUND)
                 {
                     strcpy(CD_iofficer,iofficer_t);
                 }

                 strcpy(iofficer_t,CD_iofficer);
            }
	    ********/

            prem = prem_t;
            con_cnt = 1;
            /*** �S���^�k94.12.09 ***/
            /*** �O�NB,C,D,J,K �u�n�ۦP�O�N�Y������O ==>����@�g�P���q
                 ��L�O�N�h�n�g��e�T�X�ۦP�~������O ***/

            strcpy(iresource_1,iresource);
            strcpy(iresource_2,iresource_t);
            strcpy(iofficer_1,iofficer);
            strcpy(iofficer_2,iofficer_t);
            qrenew = 0;

            $EXECUTE ori_id_old
                INTO $iquota_1
               USING $ipolicy;
            if (SQLCODE == SQLNOTFOUND)
            {
                 printf("Can't find ipolicy's[%s] iquota\n",ipolicy);
                 goto errexit;
            }

            $EXECUTE ori_id
                INTO $iquota_2
               USING $inext_ply;
            if (SQLCODE == SQLNOTFOUND)
            {
                 printf("Can't not find ipolicy's[%s] iquota on ori_ply_relation\n",inext_ply);
                 goto errexit;
            }

            strcpy(iquota,iquota_1);
            if (strcmp(iofficer,iofficer_t)==0)
            {
               strcpy(iofficer, iofficer_t);
               strcpy(iresource,iresource_t);
               strcpy(iquota,iquota_2);
               qrenew = 1;
            }
            else {
               if (strncmp(iofficer,iofficer_t,1)==0) {
                  if ((strncmp(iofficer,"B",1)>=0 &&
                       strncmp(iofficer,"D",1)<=0) ||
                      (strncmp(iofficer,"J",1)>=0 &&
                       strncmp(iofficer,"K",1)<=0)) {
                     strcpy(iofficer, iofficer_t);
                     strcpy(iresource,iresource_t);
                     strcpy(iquota,iquota_2);
                     qrenew = 1;
                  }
                  else {
                     if (strncmp(iofficer,iofficer_t,3)==0) {
                        strcpy(iofficer, iofficer_t);
                        strcpy(iresource,iresource_t);
                        strcpy(iquota,iquota_2);
                        qrenew = 1;
                     }
                  }
               }
            }
         }
         $CLOSE new_pol;
         $FREE  new_pol;
      }

      {
      char yy[5], mm[3], dd[3];
      cm_split_ymd( dissue, mm, dd, yy);
      t_year = atoi(yy);
      }

      /***20110302 ��~�s�¨��H�ӥ�i��O����鬰��¦ 
      memcpy(t_yy, dclose, 3);
      ***/

      strcpy(t_yy,ori_dply_end+6);
      o_year = atoi(t_yy);
      myear = o_year - t_year;

      if (myear > 1)
         myear = 2;
      else
         myear = 1;
 
      /* ���Ӹ�� */
      $INSERT INTO CAR316_TMP3
           (iofficer, iquota, dply_begin, dpolicy, ibig_sales, iofficer_t,
            iquota_t, dply_begin_t,
            dpolicy_t, ibig_sales_t, ipolicy, dissue, inext_ply, con_cnt,
            prem, iresource, iresource_t, nassured, iengine, iengine_t,
            itag, itag_t, qrenew, iofficer_s, iquota_s)
       VALUES
           ($iofficer_1, $iquota_1, $ori_dply_begin, $ori_dpolicy,
            $ori_ibigsales, $iofficer_2, $iquota_2,
            $new_dply_begin, $new_dpolicy, $new_ibigsales,
            $ipolicy, $dissue, $inext_ply, $con_cnt, $prem,
            $iresource_1, $iresource_2,
            $nassured, $iengine, $iengine_t,$itag,$itag_t,$qrenew,
            $iofficer, $iquota);

      $INSERT INTO CAR316
          (iofficer, iquota, iofficer_t, iquota_t, iresource, iresource_t,
           ipolicy, myear, inext_ply, con_cnt, prem, qrenew)
       VALUES
          ($iofficer, $iquota, $iofficer_t, $iquota_t, $iresource, $iresource_t,
           $ipolicy, $myear, $inext_ply, $con_cnt, $prem, $qrenew);

       if (SQLCODE == 0)
       {
         id1 = id1 + 1;
       }
       else
       {
         printf("Insert error ipolicy[%s] iquota[%s] iofficer[%s]\n",ipolicy,iquota,iofficer);
       }
     }   /*  End of pol_select cursor while  */
     $CLOSE pol_cur;
     $FREE  pol_cur;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   return SQLCODE;
}

long car316_body1()
{
 char  tmp_buf[16];
 int   rc,flag_first;
 char  sfilename[41],stitle[1024],stmt[1024];
 $char iquota[7], itop[2], itop_t[2], idealer[4], idealer_t[4], iofficer[11];
 $char iofficer_t[11], ntop[10], ndealer[10], nname[21], nbranch[20];
 $char buf1[17], mcheck[2], iquota_t[7], iquota_n[7], ileader[10];
 $int  renew_cnt, con_cnt, renew_cnt1, con_cnt1, renew_cnt2, con_cnt2;
 $int  myear, id2, qrenew, cnt;
 $long prem, prem1, prem2, qord, qord1;
 $char off13[4];
 $int  qqord;
 $char iofficer13[4];
 $int  qorder,qorder_t;
 $long lZero;
 $long lOne;
 $char ngroup[31];

 $int  qorder_tmp;

 $long same_con_cnt1,  same_renew_cnt1,  same_mprem1;
 $long nsame_con_cnt1, nsame_renew_cnt1, nsame_mprem1;
 $long same_con_cnt2,  same_renew_cnt2,  same_mprem2;
 $long nsame_con_cnt2, nsame_renew_cnt2, nsame_mprem2;

 $int  icnt;

   $WHENEVER SQLERROR GOTO errexit;

   printf("Agent part Start!!!\n");
   flag_first=1;
   id2   = 0;
   lZero = 0;
   lOne  = 1;
   icnt  = 0;

   $CREATE TEMP TABLE BIGTABLE
   (
     iquota           char(6)   default ' ',
     iofficer         char(10)  default ' ',

     same_con_cnt1    integer   default 0,
     same_renew_cnt1  integer   default 0,
     same_mprem1      integer   default 0,
     nsame_renew_cnt1 integer   default 0,
     nsame_mprem1     integer   default 0,

     same_con_cnt2    integer   default 0,
     same_renew_cnt2  integer   default 0,
     same_mprem2      integer   default 0,
     nsame_renew_cnt2 integer   default 0,
     nsame_mprem2     integer   default 0
   )WITH NO LOG;

   sprintf_s(stmt, sizeof stmt,
   " INSERT INTO BIGTABLE                              "
     " VALUES (?,?,?,?,?,?,?,?,?,?,?,?) ");
   $PREPARE ins_big FROM $stmt;

   $DECLARE big_cur CURSOR FOR
     SELECT iofficer,iquota,iofficer_t,iquota_t,myear,count(*),
            sum(con_cnt),sum(prem),sum(qrenew)
       FROM CAR316
      GROUP BY 1,2,3,4,5;

   $OPEN big_cur;
   for(;;)
   {
   $FETCH big_cur
     INTO $iofficer,$iquota,$iofficer_t,$iquota_t,$myear,
          $cnt, $con_cnt,$prem,$qrenew;
       if (SQLCODE == SQLNOTFOUND) break;

      if (myear == 1)
      {
          if (strcmp(iofficer,iofficer_t)==0)
          {
             $EXECUTE ins_big
                USING $iquota,$iofficer,
                      $cnt,$qrenew,$prem,$lZero,$lZero,
                      $lZero,$lZero,$lZero,$lZero,$lZero;
          }
          else
          {
             $EXECUTE ins_big
                USING $iquota,$iofficer,
                      $cnt,$lZero,$lZero,$con_cnt,$prem,
                      $lZero,$lZero,$lZero,$lZero,$lZero;
          }
      }
      else
      {
          if (strcmp(iofficer,iofficer_t)==0)
          {
             $EXECUTE ins_big
                USING $iquota,$iofficer,
                      $lZero,$lZero,$lZero,$lZero,$lZero,
                      $cnt,$qrenew,$prem,$lZero,$lZero;
          }
          else
          {
             $EXECUTE ins_big
                USING $iquota,$iofficer,
                      $lZero,$lZero,$lZero,$lZero,$lZero,
                      $cnt,$lZero,$lZero,$con_cnt,$prem;

          }
      }
   }
   $CLOSE big_cur;
   $FREE  big_cur;

   strcpy(sfilename,"�O�N��S����O�v�έp��");
   strcpy(stitle,"����\t���W��\t�g�P���q�W��\t�ϩҦW��\t���I�W��\t���I�N��");
   strcat(stitle,"\t�ĤG�~���¨�\t\t\t\t\t�G�~�H�W�¨�\t\t\t\t\t\t\t\n");
   strcat(stitle,"\t\t\t\t\t\t\t�i��O���\t��g�P���q\t\t�D��g�P���q\t\t");
   strcat(stitle,"�i��O���\t��g�P���q\t\t�D��g�P���q\t\t\n");
   strcat(stitle,"\t\t\t\t\t\t\t\t��O���\tñ��O�O\t��O���\tñ��O�O\t");
   strcat(stitle,"\t��O���\tñ��O�O\t��O���\tñ��O�O\n");
   strcat(stitle,"\t\t������:");
   strcat(stitle,dbgn_inf);
   strcat(stitle,"��");
   strcat(stitle,dend_inf);
   strcat(stitle,"\t\t\t�s�����:");
   strcat(stitle,cm_get_sysd());
   strcat(stitle,"\t");
   strcpy(stmt,
    "SELECT b.qorder,c.nbranch,b.nlevel3,b.nlevel4, "
           "b.ncode,a.iofficer, "
           "SUM(same_con_cnt1),SUM(same_renew_cnt1),SUM(same_mprem1), "
           "SUM(nsame_renew_cnt1),SUM(nsame_mprem1), "
           "SUM(same_con_cnt2),SUM(same_renew_cnt2),SUM(same_mprem2), "
           "SUM(nsame_renew_cnt2),SUM(nsame_mprem2) "
     " FROM BIGTABLE a,v_channel b,sa_branch_type c "
     "WHERE a.iquota      = c.ibranch "
     "  AND a.iofficer    = b.icode "
     "GROUP BY 1,2,3,4,5,6 "
     "ORDER BY 1");
   rc = unload_file(outputf,"A",sfilename,stitle,stmt);
   if (rc != SUCCESS) {
       sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
       EWRITE(userid, rc , msgbuf);
       return rc;
   }

   return M_CM_OK;
   
errexit:
   sqlfatal();
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car316_body7()
{
 char  sfilename[41],stitle[1024],stmt[2048];
 int   rc;

printf("car316_body7 Start!!!\n");

   strcpy(sfilename,"�O�N��S����O�v���Ӹ��");
   strcpy(stitle,"��X����\t��g�P���q\t��g�P�ϩ�\t��g��N��\t��g��W��\t");
   strcat(stitle,"��~�N�N��\t��~�N�W��\t��ñ����\t��ͮĤ��\t��O�渹\t");
   strcat(stitle,"��Q�O�I�H\t��������X\t��P�Ӹ��X\t��~�Ȩӷ�\t");
   strcat(stitle,"�s�X����\t�s�g�P���q\t�s�g�P�ϩ�\t�s�g��N��\t�s�g��W��\t");
   strcat(stitle,"�s�~�N�N��\t�s�~�N�W��\t�sñ����\t�s�ͮĤ��\t�s�O�渹\t");
   strcat(stitle,"�s�������X\t�s�P�Ӹ��X\t�s�~�Ȩӷ�\t");
   strcat(stitle,"ñ��O�O\t�o�Ӧ~��\t��O���\t�k�ݸg��\t�k�ݳ��\t");
   strcpy(stmt,
    "SELECT (select nbranch from sa_branch_type where ibranch = a.iquota), "
           "b.nlevel3,b.nlevel4,a.iofficer,b.ncode,a.ibig_sales, "
           "(select nname from ca_big_office where fclass = '2' and  "
           "ibig_comp = a.ibig_sales),a.dpolicy,a.dply_begin,a.ipolicy, "
           "a.nassured,a.iengine,a.itag,(select ncode from cu_code_data  "
           "where itype = '10' and icode = a.iresource), "
           "(select nbranch from sa_branch_type where ibranch = a.iquota_t), "
           "c.nlevel3,c.nlevel4,a.iofficer_t,c.ncode,a.ibig_sales_t, "
           "(select nname from ca_big_office where fclass = '2' and  "
           "ibig_comp = a.ibig_sales_t),a.dpolicy_t,a.dply_begin_t,a.inext_ply, "
           "a.iengine_t,a.itag_t,(select ncode from cu_code_data  "
           "where itype = '10' and icode = a.iresource_t), "
           "a.prem,(year(a.dissue)-1911) || TO_CHAR(a.dissue,'%m'),a.qrenew,a.iofficer_s,a.iquota_s  "
     " FROM CAR316_TMP3 a,outer v_channel b,outer v_channel c  "
     "WHERE a.iofficer = b.icode  "
     "  AND a.iofficer_t = c.icode  "
     "ORDER BY 1,2,5,6");
   rc = unload_file(outputf,"B",sfilename,stitle,stmt);
   if (rc != SUCCESS) {
       sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
       EWRITE(userid, rc , msgbuf);
       return rc;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
