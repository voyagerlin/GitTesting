/************************************************/
/*                                              */
/*   PROGRAM : ca103m01s.ec by Pei-Chow Chen    */
/*   MODIFIER: Johnny Kuo 04/10/1997            */
/*   PURPOSE : server side standard program     */
/*                                              */
/***********************************************************************
 *                             MODIFICATION LOG                        *
 *                                                                     *
 *   DATE         SE                         DESCRIPTION               *
 * --------  -------------  ----------------------------------------   *
 * 20110609  Jessie         check_brand�W�[�O�v�ͮĤ�Ѽ�              *
 *                          �W�[check_expire�����ˮ��ഫ�t��           *
 **********************************************************************/
#include <stdio.h>
#include <string.h>
#include <decimal.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
$include sqlca;
#include "safeclib.h"

long MsgCode;

long car103(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car103_insert();
 long car103_single_query();
 long car103_check_brand();
 long car103_check_expire();
 long car103_multiple_query();
 long car103_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
           rtncode=car103_insert(reply);
           break;
  case 'Q':
           rtncode=car103_single_query(reply);
           break;
  case 'C':
           rtncode=car103_check_brand(reply);
           break;
  case 'E':
           rtncode=car103_check_expire(reply);
           break;
  case 'B':
  	       rtncode=car103_check_dmg_brg(reply);
  	       break;
  case 'G':
           rtncode=car103_check_style(reply);
           break;        
  case 'M':
           rtncode=car103_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car103_update_exec(reply,command,com_len);
           break;                     
  default :
        return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
 }
 return(rtncode);
}

long car103_insert(reply)
serverReply reply;
{
 $char fpt[2];	
 $char DBName[5],brand[9],name1[13],name2[31],name3[21];
 $dec_t price;
 $char cartype[3];
 $double  cylinder;/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/ 
 $double loadno;
 $long altdt;
 $char use[2],carseries[3];
 $char ipro_year[5], idmg_rate[3], idmg_rate_ori[3], ibrg_rate[3],ibrg_rate_ori[3];
 $long drate=0;
 $char sports_car[2];
 $char str_drate[12];
 $char cur_drate[10];
 char str_price[30],str_cylinder[20];
 dec_t dec_cylinder;
 $double dbl_price;
 $char str_altdt[12];
 int result;
 $char carname[11],sername[11];
 $char class[2];
 $char str_dexpire[11], brand_new[9], iupdate[11],istyle[11],name4[41];
 /*1121117004_C02_BIS���w�q����*/
 $char brand_c[5];

 int tmp_len;
   DBinfo *list;
   int i, j, is_add_fail=0, api_f;
   $char stmt_buf[1024];

 cm_buf_get("%s %s %s %s %s %s %s %s %s %e %s %s %s %s %s %s %s %s",DBName,
             brand,ipro_year,name1,name2,name3,cartype,carseries,str_cylinder,&loadno,fpt, use,str_price,str_altdt,cur_drate, idmg_rate,ibrg_rate,sports_car);
 cm_buf_get("%s %s %s %s %s %s %s", str_dexpire, brand_new, iupdate, idmg_rate_ori, ibrg_rate_ori,istyle,name4);

 if (db_select(DBName) == False)
  {
   MsgCode = M_CM_DB_NOTOPEN;
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
  }

 result=deccvasc(str_price, strlen(str_price), &price);
 dectodbl(&price, &dbl_price);
 
 deccvasc(str_cylinder,strlen(str_cylinder),&dec_cylinder);/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/ 
 dectodbl(&dec_cylinder,&cylinder);  

/*
 fscanf(str_cylinder,"%d",&cylinder);

 fscanf(str_loadno,"%d",&int_loadno);
 loadno = (short int) int_loadno;  */     /* explicit type convert */

 /* convert  chinese date string str_altdt to western date altdt */
 strcpy(str_altdt, cm_to_infdate(str_altdt));
 strcpy(str_drate,cm_to_infdate(cur_drate));
 strcpy(str_dexpire,cm_to_infdate(str_dexpire));
printf("cur_drate[%s]\n",cur_drate);
printf("str_drate[%s]\n",str_drate);
printf("str_dexpire[%s]\n",str_dexpire);
 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
     return exitsub(reply,M_CM_NOT_DBLIST) ? M_CM_NOT_DBLIST : apiRC;

 /* grasp another 2 field data from car_type table */
 strcpy(carname," ");
 if(cartype[0]!=' ')
 {
    strcpy(class, "1");
    $SELECT ncode
     INTO   $carname
     FROM   car_type
     WHERE  fclass=$class AND icode=$cartype;
   
    if(SQLCODE==SQLNOTFOUND)
    {
     if(exitsub(reply,M_CA_NCARTYPE) == True)     
       return M_CA_NCARTYPE;                      
     else
       return apiRC;
    }
 }

 strcpy(sername," ");
 if(carseries[0]!=' ' && strcmp(carseries,"99")!=0)
 {
    strcpy(class, "2");
    $SELECT ncode
     INTO   $sername
     FROM   car_type
     WHERE  fclass=$class AND icode=$carseries;
   
    if(SQLCODE==SQLNOTFOUND)
    {
     if(exitsub(reply,M_CA_NCAR_SERIES) == True)       
       return M_CA_NCAR_SERIES;                       
     else
       return apiRC;
    }
 }
 
 strcpy(brand_c,"");
 strncpy(brand_c,brand,4);
 strcpy(brand_c,trim(brand_c));
 printf("brand_c = [%s]\n",brand_c);
 $SELECT icode 
  FROM	 cm_group
  WHERE  igroup = '04' AND ilevel = '4' AND icode = $brand_c;
 if(SQLCODE==SQLNOTFOUND)
 {
     if(exitsub(reply,M_CA_NCARTYPE) == True)     
       return M_CA_NCARTYPE;                      
     else
       return apiRC;
 } 	 
 
 $WHENEVER SQLERROR GOTO errexit;
 $BEGIN WORK;
 for(j=0;j<i;j++)
 {
  sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:ca_car_model "
       " (ibrand,nbrand_abbr,nbrand,nbrand_eng,mcar_price,icar_type,qcylinder, "
	" qpassenger,fpt,dalter,fuse_type,icar_series,ipro_year,idmg_rate,ibrg_rate, "
	" drate,sports_car,dexpire,ibrand_new,iupdate,idmg_rate_ori,ibrg_rate_ori,istyle,nbrand_label) "
	" VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",list[j].dbname);

  $PREPARE a_id FROM $stmt_buf;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  $EXECUTE a_id USING $brand,$name1,$name2,$name3,$dbl_price,$cartype,
	$cylinder,$loadno,$fpt,$str_altdt,$use,$carseries,$ipro_year,$idmg_rate,
	$ibrg_rate,$str_drate,$sports_car,$str_dexpire,$brand_new,$iupdate,$idmg_rate_ori,$ibrg_rate_ori,$istyle,$name4;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
   
  if (strlen(trim(str_dexpire))>0)
  {
      sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE %s:ca_car_model "
                          " SET dexpire=?, ibrand_new=?, iupdate=?, dalter=? "
                         " WHERE ibrand=? AND ipro_year!=? AND drate=? ", list[j].dbname);
      $PREPARE a_id1 FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_add_fail = 1;
        break;
       }
      $EXECUTE a_id1 USING $str_dexpire, $brand_new, $iupdate, $str_altdt, $brand, $ipro_year, $str_drate;
      if(SQLCODE != 0)
       {
        is_add_fail = 1;
        break;
       }
  }
   
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  tmp_len = cm_buf_len(ReplyBuf);
  if( j == i-1 )
     api_f = api_OKComplete;
  else
     api_f = api_OK;

  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    {
     is_add_fail = 2;
     break;
    }  
#ifdef DEBUG 
printf("INSERT %d\n", j+1);
#endif
 } /* for loop */

 if( is_add_fail == 1 ) goto errexit;

 if( is_add_fail == 2 ) 
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   return apiRC;
  }


 $WHENEVER SQLERROR GOTO errexit;

 $COMMIT WORK;
 return api_OKComplete;

errexit:
   MsgCode = SQLCODE;
   cm_show_sql_err("car103_insert", stmt_buf);
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;		/* ROLLBACK fail */
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

long car103_single_query(reply)
serverReply reply;
{
 $char fpt[2];
 $char DBName[5],brand[9],name1[13],name2[31],name3[21];
 $char ipro_year[5],cur_ipro_year[5], idmg_rate[3], idmg_rate_ori[3], ibrg_rate[3],ibrg_rate_ori[3];
 $char k_drate[10],str_drate[12],sports_car[2];
 $dec_t price;
 $char cartype[3];
 $double cylinder = 0.0;/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/ 
 $double loadno = 0.0;
 $long altdt = 0;
 $char use[2],carseries[3];
 $long drate=0;
 $char sTmpcylinder[9];/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/ 

 $char carname[11],sername[11],istyle[11],name4[41],stylename[41];

 $char class[2];
 double dbl_price;
 char str_altdt[12];
 $char str_dexpire[11], brand_new[9], iupdate[11];

 int tmp_len;

 cm_buf_get("%s %s %s %s",DBName,brand,ipro_year,k_drate);
 strcpy(str_drate,cm_to_infdate(k_drate));

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $SELECT  ibrand,ipro_year,nbrand_abbr,nbrand,nbrand_eng,mcar_price,
          icar_type,qcylinder,qpassenger,fpt,
          dalter,fuse_type,icar_series,idmg_rate,ibrg_rate,drate,sports_car,
          dexpire, ibrand_new, iupdate,idmg_rate_ori,ibrg_rate_ori,istyle,nbrand_label
  INTO    $brand,$ipro_year,$name1,$name2,$name3,$price,$cartype,$cylinder,$loadno,$fpt,
          $altdt,$use,$carseries,$idmg_rate,$ibrg_rate,$str_drate,$sports_car,
          $str_dexpire, $brand_new, $iupdate,$idmg_rate_ori,$ibrg_rate_ori,$istyle,$name4
  FROM    ca_car_model
  WHERE   ibrand=$brand and ipro_year=$ipro_year and drate=$str_drate;

 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CM_NOT_FOUND) == True)       /*?*/
    return M_CM_NOT_FOUND;                        /*?*/
  else
    return apiRC;
 }

 printf("istyle=[%s]\n",istyle);

 strcpy(stylename," ");
 if(istyle[0]!=' ')
 {    
    $SELECT ncode
       INTO $stylename
       FROM cm_group
      WHERE igroup = '23' AND ilevel = 2 AND icode=$istyle;
    printf("stylename=[%s]\n",stylename);
 }

 /* grasp another 2 field data from car_type table */
 strcpy(carname," ");
 if(cartype[0]!=' ')
 {
    strcpy(class, "1");
    $SELECT ncode
     INTO   $carname
     FROM   car_type
     WHERE  fclass=$class AND icode=$cartype;
   
    if(SQLCODE==SQLNOTFOUND)
    {
     strcpy(carname, " ");
     /*
     if(exitsub(reply,M_CA_NCARTYPE) == True)     
       return M_CA_NCARTYPE;                      
     else
       return apiRC;
     */
    }
 }

 strcpy(sername," ");
 if(carseries[0]!=' ' && strcmp(carseries,"99")!=0)
 {
    strcpy(class, "2");
    $SELECT ncode
     INTO   $sername
     FROM   car_type
     WHERE  fclass=$class AND icode=$carseries;
   
    if(SQLCODE==SQLNOTFOUND)
    {
     strcpy(sername, " ");
     /*
     if(exitsub(reply,M_CA_NCAR_SERIES) == True)       
       return M_CA_NCAR_SERIES;                       
     else
       return apiRC;
     */
    }
 }

 /* convert dec_t type (price) to double type (dbl_price) for buffer put */
 dectodbl(&price, &dbl_price);

 /* convert long type altdt to string type str_altdt for buffer put */
 strcpy(str_altdt, cm_cdate_str_100(altdt));
 strcpy(str_dexpire, cm_from_infdate_100(str_dexpire));

 cm_buf_init(ReplyBuf);
 strcpy(sTmpcylinder,"");/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
 sprintf_s(sTmpcylinder, sizeof sTmpcylinder,"%8.2f",cylinder);
 strcpy(sTmpcylinder,trim(sTmpcylinder));
 cm_buf_put("%l %s %s %s %s %s %f %s %s %e %s %s %s %s %s %s %s %s %s %s",
             M_CM_OK, brand,ipro_year,name1,name2,name3,dbl_price,cartype,sTmpcylinder,loadno,fpt,use,str_altdt,carseries,carname,sername,idmg_rate, ibrg_rate,k_drate,sports_car);
 cm_buf_put("%s %s %s %s %s %s %s %s", str_dexpire, brand_new, iupdate,idmg_rate_ori,ibrg_rate_ori,istyle,name4,stylename);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

 errexit:
   MsgCode = cm_show_sql_err("ca103_single_query", NULL);
  if(exitsub(reply,MsgCode) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car103_multiple_query(reply)
serverReply reply;
{
 $char DBName[5],brand[9],name1[11],str_drate_bgn[12], k_drate[10],sports_car[2];
 $char sTmp_nbrand[31], sTmp_name1_nbrand[41];
 $char key_brand[9],ipro_year[5],idmg_rate[3],ibrg_rate[3],str_ipro_year[5],ibrg_rate_ori[3];
 $long drate=0;
 $char str_drate_end[12];
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;
 int OPEN_STAR;
 cm_buf_get("%s %s %s %s",DBName,key_brand,str_ipro_year,k_drate);

 $WHENEVER SQLERROR GOTO errexit;
 
 drate = 0;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

if(k_drate[0]=='*')
{
 strcpy(str_drate_bgn,"01/01/1980");
 strcpy(str_drate_end,"12/31/2999");
}
else
{ 
  strcpy(str_drate_bgn,cm_to_infdate(k_drate));
  strcpy(str_drate_end,cm_to_infdate(k_drate));
}
 $DECLARE q_cur2 CURSOR FOR
   SELECT ibrand, nbrand_abbr, nbrand, ipro_year,drate 
     INTO $brand, $name1, $sTmp_nbrand, $ipro_year, $drate
     FROM ca_car_model
    WHERE ibrand matches $key_brand and ipro_year matches $str_ipro_year
          and drate BETWEEN $str_drate_bgn AND $str_drate_end
    ORDER BY ibrand,drate,ipro_year;
    $OPEN q_cur2;
 
 for(;;)
  {
    $FETCH q_cur2;
    strcpy(sTmp_name1_nbrand, trim(name1));
    strcat(sTmp_name1_nbrand, trim(sTmp_nbrand));

    if (SQLCODE != 0) break;
    strcpy(k_drate, cm_cdate_str_100(drate));
    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    cm_buf_put("%s %s %s %s", brand, ipro_year, sTmp_name1_nbrand, k_drate);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;

        if(replycnt > 5) sleep(3);
        else if(replycnt > 3) sleep(2);
        else if(replycnt > 1) sleep(1);

        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s %s",brand,ipro_year, sTmp_name1_nbrand, k_drate);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur2;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

 errexit:
   MsgCode = cm_show_sql_err("ca103_multiple_query", NULL);
   if(exitsub(reply,MsgCode) == True)
     return SQLCODE;
   else
     return apiRC;
}

long car103_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 $char fpt[2];	
 $char DBName[5],brand[9],name1[13],name2[31],name3[21];
 $dec_t price;
 $char cartype[3];
 $double cylinder;/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/ 
 $double loadno;
 $char altdt[16];
 $char use[2],carseries[3];
 $char ipro_year[5],idmg_rate[3],idmg_rate_ori[3],ibrg_rate[3],ibrg_rate_ori[3];
 $char drate[16], sports_car[2];

 char str_price[30],str_cylinder[20];
 dec_t dec_cylinder;
 char str_altdt[12];
 char str_drate[12];

 $char cur_fpt[2];	
 $char cur_name1[13],cur_name2[31],cur_name3[21];
 $dec_t cur_price;
 $char cur_cartype[3];
 $double cur_cylinder = 0.0;/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/ 
 $char   dy2[9];/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/ 
 $double cur_loadno = 0.0;
 $long cur_altdt = 0;
 $char cur_use[2],cur_carseries[3];
 $double cur_dbl_price,dy1;
 $char cur_ipro_year[5],cur_idmg_rate[3],cur_ibrg_rate[3],tmp_drate[12], cur_sports_car[2];
 $long cur_drate = 0;
 $char sTmpcylinder[9];/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/ 
 $char carname[11],sername[11],class[2];
 $char old_brand[9],old_ipro_year[5],old_drate[12],dy[50],tmp_old_drate[16], old_sports_car[2];
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len; long dummy;
   DBinfo *list;
   int i, j, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[1024];
 $char str_dexpire[11], brand_new[9], iupdate[11];
 $char old_str_dexpire[11], old_brand_new[9],istyle[11],name4[41],stylename[41],cur_istyle[11],cur_name4[41];

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
     return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
     return exitsub(reply,M_CM_NOT_DBLIST) ? M_CM_NOT_DBLIST : apiRC;

 

 /* compare old record and current record, if the record has not been changed
    since last request, update or delete the record, otherwise return errmsg
    to client side */

 /* get old record info from command buffer */

/*
 raw_len = *(int *) &comm[com_len];
 memcpy(&raw_len,(void *)&command[com_len],sizeof(int));
*/
 memcpy(&raw_len,&comm[com_len],sizeof(int));
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)
  memcpy(raw_ptr,pos,raw_len);
 else
  { /* malloc fail */
   return exitsub(reply,M_CM_NOT_MALLOC) ? M_CM_NOT_MALLOC : apiRC;
  }
 
 cm_buf_init(raw_ptr);          /* get index key from old record */
 cm_buf_get("%l %s %s",&dummy,brand,cur_ipro_year);
 cm_buf_get("%s %s %s %e %s %s %e %s %s %s %s %s %s %s %s %s %s",
   dy,dy,dy,&dy1,dy,dy2,&dy1,dy,
   dy,dy,dy,dy,dy,dy,dy,tmp_drate,sports_car);

 printf("drate[%s]\n",tmp_drate);
 strcpy(drate,cm_to_infdate(tmp_drate));

  $SELECT nbrand_abbr,nbrand,nbrand_eng,mcar_price,icar_type,
          qcylinder,qpassenger,fpt,dalter,fuse_type,icar_series,
    idmg_rate,ibrg_rate,drate,sports_car,
          dexpire, ibrand_new, iupdate,idmg_rate_ori,ibrg_rate_ori,istyle,nbrand_label
      INTO $cur_name1,$cur_name2,$cur_name3,$cur_price,$cur_cartype,
          $cur_cylinder,$cur_loadno,$cur_fpt,$cur_altdt,$cur_use,$cur_carseries,
    $cur_idmg_rate,$cur_ibrg_rate,$cur_drate,$cur_sports_car,
          $old_str_dexpire, $old_brand_new, $iupdate,$idmg_rate_ori,$ibrg_rate_ori,$cur_istyle,$cur_name4
      FROM ca_car_model
    WHERE ibrand=$brand AND ipro_year=$cur_ipro_year AND drate=$drate; 


    /* if key value has been changed then SQLNOTFOUND,else put current value
      into cur_buf for comparison */

  if (SQLCODE == SQLNOTFOUND)
  {
     MsgCode = M_CM_NOT_FOUND;
     /*$WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;*/
     if(SQLCODE != 0) MsgCode = SQLCODE;
     return exitsub(reply,MsgCode) ? MsgCode : apiRC;
  }

  if(0) /* car103�u����"�O���t�d���@�t�����ּƤH"�|�ϥ�car103���ʸ�ơA���i�H���ݭn���,���q������ */
  {
    $BEGIN WORK;      

    $WHENEVER SQLERROR GOTO errexit;

    /* convert dec_t type cur_price to double type dbl_cur_price */
    dectodbl(&cur_price, &cur_dbl_price);

    /* convert long altdt to string str_altdt */
    strcpy(str_altdt, cm_cdate_str_100(cur_altdt));
    strcpy(str_drate,cm_cdate_str_100(cur_drate));
    strcpy(str_dexpire, cm_from_infdate_100(old_str_dexpire));

    printf("cur_istyle=[%s]\n",cur_istyle);

    strcpy(stylename," ");
    if(cur_istyle[0]!=' ')
    {    
        $SELECT ncode
          INTO $stylename
          FROM cm_group
          WHERE igroup = '23' AND ilevel = 2 AND icode=$cur_istyle;
        printf("stylename=[%s]\n",stylename);
    }

    /* grasp another 2 field data from car_type table */
    strcpy(carname," ");
    if(cur_cartype[0]!=' ')
    {
        strcpy(class, "1");
        $SELECT ncode
          INTO $carname
          FROM car_type
          WHERE fclass=$class AND icode=$cur_cartype;
      
        if(SQLCODE==SQLNOTFOUND)
        strcpy(carname," ");
    }

    strcpy(sername," ");
    if(cur_carseries[0]!=' ' && strcmp(cur_carseries,"99")!=0)
    {
        strcpy(class, "2");
        $SELECT ncode
          INTO $sername
          FROM car_type
          WHERE fclass=$class AND icode=$cur_carseries;
      
        if(SQLCODE==SQLNOTFOUND)
          strcpy(sername," ");
    }

    printf("660--cur_cylinder[%f]\n",cur_cylinder);
    cm_buf_init(cur_buf);
    
    strcpy(sTmpcylinder,""); /*1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
    sprintf_s(sTmpcylinder, sizeof sTmpcylinder,"%8.2f",cur_cylinder); 
    strcpy(sTmpcylinder,trim(sTmpcylinder));

    cm_buf_put("%l %s %s %s %s %s %e %s %s %e %s %s %s %s %s %s %s %s %s %s %s %s",
                dummy,brand,cur_ipro_year,cur_name1,cur_name2,cur_name3,
                cur_dbl_price,cur_cartype,sTmpcylinder,cur_loadno,cur_fpt,
                cur_use,str_altdt,cur_carseries,carname,sername,
          cur_idmg_rate,cur_ibrg_rate,str_drate,sports_car);
    cm_buf_put("%s %s %s %s %s", str_dexpire, old_brand_new, iupdate,idmg_rate_ori,ibrg_rate_ori);
    printf("cur[%s]\n", cur_buf);
    printf("raw[%s]\n", raw_ptr);
    printf("raw_len[%d]\n", raw_len);
    if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
    {
      MsgCode = M_CM_NOT_EQUAL;
      $WHENEVER SQLERROR CONTINUE;
      $ROLLBACK WORK;
      if(SQLCODE != 0) MsgCode = SQLCODE;
      return exitsub(reply,MsgCode) ? MsgCode : apiRC;
    }

 }/* end of if(0) */

 $WHENEVER SQLERROR GOTO errexit;

 /* equal, then exec DB operation */

 if ( option == 'D' )
 {
   for(j=0;j<i;j++)
   {

    printf("brand[%s]\n",brand);
    printf("cur_ipro_year[%s]\n",cur_ipro_year);
    printf("cur_drate[%s]\n",cur_drate);
    sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM %s:ca_car_model WHERE ibrand= ? "
	                    " AND ipro_year=? AND drate=?",list[j].dbname); 
    $PREPARE d_id FROM $stmt_buf;
    /* if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }*/
    $EXECUTE d_id USING $brand,$cur_ipro_year,$cur_drate;
    printf("SQLCODE[%d]\n", SQLCODE); 
    printf("sqlca.sqlerrd[2][%d]\n", sqlca.sqlerrd[2]); 
         
    is_del_fail = 0; 
    if(SQLCODE != 0)
     {
        is_del_fail = 1; 
        break;
     }
     #ifdef DEBUG 
     printf("Delete %d\n", j+1);
     #endif
   }/* for loop */

   if( is_del_fail ) goto errexit;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     /* �u�� delete ca_car_model, ���ݭn transaction 
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     */
     return apiRC;
   }
   /* �u�� delete ca_car_model, ���ݭn transaction 
   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   */
   return api_OKComplete;
 }
 else if (option == 'U')
 {

   $BEGIN WORK;  

   cm_buf_init(command);

   cm_buf_get("%c %s %s %s %s %s %s %s %s %s %e %s %s %s %s %s %s %s %s",
               &option,DBName,brand,ipro_year,name1,name2,name3,
               str_price,cartype,str_cylinder,&loadno,fpt,
               use,str_altdt,carseries,idmg_rate,
	       ibrg_rate,str_drate,sports_car);
   cm_buf_get("%s %s %s %s %s %s %s", str_dexpire, brand_new, iupdate,idmg_rate_ori,ibrg_rate_ori,istyle,name4);
   printf("str_altdt[%s]\n",str_altdt);
   printf("str_drate[%s]\n",str_drate);
   printf("str_dexpire[%s]\n",str_dexpire);
   deccvasc(str_cylinder,strlen(str_cylinder),&dec_cylinder);/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/ 
   dectodbl(&dec_cylinder,&cylinder);  

   strcpy(stylename," ");
   if(istyle[0]!=' ')
   {    
      $SELECT ncode
         INTO $stylename
         FROM cm_group
        WHERE igroup = '23' AND ilevel = 2 AND icode=$istyle;
      printf("stylename=[%s]\n",stylename);
   }
  
   strcpy(carname," ");
   if(cartype[0]!=' ')
   {
      strcpy(class, "1");
      $SELECT ncode
         INTO $carname
         FROM car_type
        WHERE fclass=$class AND icode=$cartype;
     
      if(SQLCODE==SQLNOTFOUND)
      {
       strcpy(carname," ");
       
       MsgCode = M_CA_NCARTYPE;
       $WHENEVER SQLERROR CONTINUE;
       $ROLLBACK WORK;
       if(SQLCODE != 0) MsgCode = SQLCODE;
       return exitsub(reply,MsgCode) ? MsgCode : apiRC;
       
      }
   }
   $WHENEVER SQLERROR GOTO errexit;
  
   strcpy(sername," ");
   if(carseries[0]!=' ' && strcmp(carseries,"99")!=0)
   {
      strcpy(class, "2");
      $SELECT ncode
         INTO $sername
         FROM car_type
        WHERE fclass=$class AND icode=$carseries;
     
      if(SQLCODE==SQLNOTFOUND)
      {
         strcpy(sername," ");
         
         MsgCode = M_CA_NCAR_SERIES;
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         if(SQLCODE != 0) MsgCode = SQLCODE;
         return exitsub(reply,MsgCode) ? MsgCode : apiRC;
        
      }
   }
   $WHENEVER SQLERROR GOTO errexit;

   deccvasc(str_price, strlen(str_price), &price);

   /* convert string str_altdt to altdt */
   strcpy(altdt, cm_to_infdate(str_altdt));
   strcpy(drate, cm_to_infdate(str_drate));
   strcpy(str_dexpire, cm_to_infdate(str_dexpire));

   /* grasp old key */
   cm_buf_init(raw_ptr);
   cm_buf_get("%l %s %s %s %s %s %e %s %d %e %s %s %s %s %s %s %s %s %s %s",&dummy,
	old_brand,old_ipro_year,dy,dy,dy,&dy1,dy,&dy2,&dy1,dy,
	dy,dy,dy,dy,dy,dy,dy,old_drate,old_sports_car);

   strcpy(tmp_old_drate,cm_to_infdate(old_drate));
   
   free(raw_ptr);

   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf,
		"UPDATE %s:ca_car_model "
    		   " SET (ibrand,nbrand_abbr,nbrand,nbrand_eng,mcar_price, "
			" icar_type,qcylinder,qpassenger,fpt, dalter,fuse_type, "
			" icar_series,ipro_year,idmg_rate,ibrg_rate,drate,sports_car, "
			" dexpire,ibrand_new,iupdate,idmg_rate_ori,ibrg_rate_ori,istyle,nbrand_label) "
		    "  = (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
		 " WHERE ibrand = ? AND ipro_year=? AND drate=?",
	   list[j].dbname);
     printf("stmt_buf[%s]\n", stmt_buf);

     $PREPARE u_id FROM $stmt_buf;
     /*
     if(SQLCODE != 0)
     {
        is_upd_fail = 1;
        break;
     }*/
     printf("old_brand[%s]\n", old_brand);
     printf("old_ipro_year[%s]\n", old_ipro_year);
     printf("tmp_old_drate[%s]\n", tmp_old_drate);

    $EXECUTE u_id USING $brand,$name1,$name2,$name3,$price,
			$cartype,$cylinder,$loadno,$fpt,$altdt,$use,
			$carseries,$ipro_year,$idmg_rate,$ibrg_rate,$drate,$sports_car,
			$str_dexpire, $brand_new, $iupdate, $idmg_rate_ori, $ibrg_rate_ori,$istyle,$name4,
			$old_brand,$old_ipro_year,$tmp_old_drate;
    printf("SQLCODE[%d]\n", SQLCODE); 
    printf("sqlca.sqlerrd[2][%d]\n", sqlca.sqlerrd[2]); 
     
    is_upd_fail = 0;
    if(SQLCODE != 0)
    {
       is_upd_fail = 1;
       break;
    }
    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
    {
        sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:ca_car_model "
                         " (ibrand,nbrand_abbr,nbrand,nbrand_eng,mcar_price,icar_type,qcylinder, "
                         " qpassenger,fpt,dalter,fuse_type,icar_series,ipro_year,idmg_rate, "
                         " ibrg_rate,drate,sports_car,dexpire,ibrand_new,iupdate,idmg_rate_ori,ibrg_rate_ori,istyle,nbrand_label) "
                         " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)",list[j].dbname);

        $PREPARE ua_id FROM $stmt_buf;
        /*if(SQLCODE != 0)
        {
          is_upd_fail = 1; 
          break;
        }*/
        $EXECUTE ua_id USING $brand,$name1,$name2,$name3,$price,$cartype,
                $cylinder,$loadno,$fpt,$altdt,$use,$carseries,$ipro_year,$idmg_rate,
                $ibrg_rate,$drate,$sports_car,$str_dexpire,$brand_new,$iupdate,$idmg_rate_ori,$ibrg_rate_ori,$istyle,$name4;
        if(SQLCODE != 0)
        {
            is_upd_fail = 1; 
            break;
        }
     }
     #ifdef DEBUG 
     printf("Update %d\n", j+1);
     #endif

     if (strlen(trim(brand_new))==0 && brand_new[0]==' ') strcpy(brand_new, "        ");
     printf("str_dexpire[%s]old_str_dexpire[%s]\n", str_dexpire, old_str_dexpire);
     printf("brand_new[%s]old_brand_new[%s]\n", brand_new, old_brand_new);
     /* ���Τ鲧�ʩ��ഫ�t�P�������� */
     if (strcmp(str_dexpire, old_str_dexpire)!=0 || strcmp(brand_new, old_brand_new)!=0)
     {
         sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE %s:ca_car_model "
                             " SET dexpire=?, ibrand_new=?, iupdate=?, dalter=? "
                            " WHERE ibrand=? AND ipro_year!=? AND drate=? ", list[j].dbname);
         $PREPARE u_id1 FROM $stmt_buf;
         /* 
         if(SQLCODE != 0)
         {
             is_upd_fail = 1;
             break;
         }*/
         $EXECUTE u_id1 USING $str_dexpire, $brand_new, $iupdate, $altdt, $brand, $old_ipro_year, $tmp_old_drate;
         is_upd_fail = 0;
         if(SQLCODE != 0)
         {
           is_upd_fail = 1;
           break;
         }
     }

   } /* for loop */

   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }
   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
 }
 else
 {
   MsgCode = M_CM_WRONG_OPTION;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
 }

errexit:
  MsgCode = SQLCODE;
  cm_show_sql_err("ca103_update_exec", stmt_buf);
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if(SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True)
   return MsgCode;
  else
   return apiRC;
}

long car103_check_brand(reply)
serverReply reply;
{
 $char DBName[5], brand[9], str_drate[11];
 char userid[11];
 int tmp_len;
 $int cnt = 0;

 cm_buf_get("%s %s %s %s", DBName, userid, brand, str_drate);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 strcpy(str_drate,cm_to_infdate(str_drate));

 $SELECT  COUNT(*)
  INTO    $cnt
  FROM    ca_car_model
  WHERE   ibrand=$brand 
  AND	  drate=$str_drate
  AND     dexpire IS NULL;

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %d", M_CM_OK, cnt);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

 errexit:
   MsgCode = cm_show_sql_err("car103_check_brand", NULL);
  if(exitsub(reply,MsgCode) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car103_check_expire(reply)
serverReply reply;
{
$char DBName[5], brand[9], str_drate[11];
$char ibrand1[9];
char  userid[11];
int   tmp_len,i;
$int  cnt = 0;

 cm_buf_get("%s %s %s %s", DBName, userid, brand, str_drate);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 strcpy(str_drate,cm_to_infdate(str_drate));

 $DECLARE cur_exp_brand CURSOR FOR
   SELECT distinct ibrand
     FROM ca_car_model
    WHERE ibrand_new=$brand 
      AND drate=$str_drate;
 $OPEN cur_exp_brand;

 cm_buf_init(ReplyBuf);
 cm_buf_res_msg();
 cm_buf_res_count();

 for(i=0;;i++) {
     $FETCH cur_exp_brand INTO $ibrand1;
     if (SQLCODE==SQLNOTFOUND) break;

     cm_buf_put("%s",ibrand1);
 }

 if (i > 0) {
     cm_buf_put_msg(M_CM_OK);
     cm_buf_put_count(i);
     tmp_len = cm_buf_len(ReplyBuf);

     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;
 }
 else {
        if (exitsub(reply,M_CMN_NO_DATA_FOUND) == True)
            return M_CMN_NO_DATA_FOUND;
        else
            return apiRC;
 }

errexit:
  MsgCode = cm_show_sql_err("car103_check_expire", NULL);
  if(exitsub(reply,MsgCode) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car103_check_dmg_brg(reply)
serverReply reply;
{
 $char DBName[5], kind[3], brand2[3], detail2[5];
 char userid[11];
 int tmp_len;


 cm_buf_get("%s %s %s", DBName, kind, brand2);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 
 printf("kind=[%s]brand2=[%s]\n",kind,brand2);

 $SELECT  detail2
  INTO    $detail2
  FROM    car_code
  WHERE   kind = $kind 
  AND	  detail = $brand2;
  
  if(SQLCODE==SQLNOTFOUND) strcpy(detail2,"0");

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s", M_CM_OK, detail2);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

 errexit:
   MsgCode = cm_show_sql_err("car103_check_dmg_brg", NULL);
  if(exitsub(reply,MsgCode) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car103_check_style(reply)
serverReply reply;
{
 $char DBName[5], istyle[11], ncode[41];
 char userid[11];
 int tmp_len;


 cm_buf_get("%s %s %s", DBName, userid, istyle);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 
 printf("istyle=[%s]\n",istyle);  
 strcpy(ncode,"--"); /* ��client�ݧP�_�䤣���Ʈ� */
 $SELECT  ncode
    INTO  $ncode
    FROM  cm_group
   WHERE  igroup = '23'
     AND  ilevel = 2
     AND	icode  = $istyle;
    
 printf("ncode=[%s]\n",ncode);    
 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s", M_CM_OK, ncode);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

 errexit:
   MsgCode = cm_show_sql_err("car103_check_style", NULL);
  if(exitsub(reply,MsgCode) == True)
   return SQLCODE;
  else
   return apiRC;
}
