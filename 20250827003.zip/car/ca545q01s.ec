/**********************************************************************/
/*   program id   : ca545q01s.ec                                      */
/*   program name : �z�����h���Ʋ��s�@�~                            */
/*   date written : 2015/10/21                                        */
/*   date modify  : yyyy/mm/dd                                        */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"

#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"

$include decimal;
char delimiter;
int   count_db,k;
$char chkComp[2];
char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];
$char option[2];
$char falldb[2];
int offset;
char   sApHome[50];
FILE   *fp;
static char  *bp;
long   rtncode;
char   cdate[11], cdate_s[11];
char   dgroupBgn[11], dgroupEnd[11];
int rc;
char   ioption[2];
DBinfo *list;
$char   fulldb[31];

main(argc, argv)
int argc;
char **argv;
{

    batchinit();
    strcpy(DBName,    isNULLstr(argv[1]));
    strcpy(userid,    isNULLstr(argv[2]));
    strcpy(cdate,     isNULLstr(argv[3]));   /* cyy/mm/dd */
    strcpy(cdate_s,   isNULLstr(argv[4]));   /* cyy/mm/dd */

    strcpy(dgroupBgn, isNULLstr(argv[5]));
    strcpy(dgroupEnd, isNULLstr(argv[6]));

    strcpy(ioption,   isNULLstr(argv[7]));

    strcpy(outputf,   isNULLstr(argv[8]));

    printf("cdate[%s]\n",cdate);

    rc = car545_get_db();
    if (rc != M_CM_OK)
       return rc;

    rtncode = getApHome(sApHome);
    if (rtncode < 0)
    {
        EWRITE(userid, M_CM_READ_CONFIG_ERR, "read Config file error!!");
        return FAIL;
    }

    if (ioption[0] == '1')
    {
	/* Create table car545_tmp1 */
	rc = ca545_create_temp();
	if (rc != M_CM_OK)
	    return rc;

	printf("falldb=[%s]\n",falldb);

	rc = car545_prepare_data();
	if (rc != M_CM_OK)
	    return rc;

	/*build report - ����*/
	rc = car545_build();
	if (rc != M_CM_OK)
      	    return rc;
    }
    else
    {
	/* Create table car545_tmp2 */
	rc = ca545_create_temp2();
	if (rc != M_CM_OK)
	    return rc;

	printf("falldb=[%s]\n",falldb);

	rc = car545_prepare_data2();
	if (rc != M_CM_OK)
	    return rc;

	/*build report - ����*/
	rc = car545_build2();
	if (rc != M_CM_OK)
      	    return rc;
    }
}

/*--------------------------------------------------------------------*/
long car545_get_db()
{
   int	rc,k;
   $char stmt[4096];

   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

   if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
         return M_CM_NOT_DBLIST;
   }

    $create temp table claim_app_dtl_2
    (
         iclaim1           char(20),
         insure_type       char(1),
         insure_instype    char(6),
         mclaim_app        decimal(12,0)
    )with no log;

    $create unique index claim_app_dtl_2_ix1
         on claim_app_dtl_2(iclaim1, insure_type, insure_instype);

    $create temp table claim_app_dtl_h_2
    (
         iclaim1           char(20),
         insure_type       char(1),
         insure_instype    char(6),
         mclaim_app        decimal(12,0),
         dappraisal        date
    )with no log;

    $create unique index claim_app_dtl_h_2_ix1
         on claim_app_dtl_h_2(iclaim1, insure_type, insure_instype, dappraisal);

    $create index claim_app_dtl_h_2_ix2
         on claim_app_dtl_h_2(dappraisal);

    $create temp table claim_stl_dtl_2
    (
         iclaim1           char(20),
         fstl              char(1),
         iclose_type       char(4),
         insure_type       char(1),
         insure_instype    char(6),
         dgroup            date,
         msettle           decimal(12,0),
         mfee              decimal(8,0)
    )with no log;

    $create unique index claim_stl_dtl_2_ix1
         on claim_stl_dtl_2(iclaim1,fstl,iclose_type,insure_type,insure_instype);

    $create index claim_stl_dtl_2_ix2 on claim_stl_dtl_2(dgroup);

    for(k=0;k<count_db;k++)
    {
       strcpy(fulldb,list[k].dbname);

       sprintf_s(stmt,4096,
       " insert into claim_app_dtl_2    \
           select iclaim, 'C', iins_type, mins_app   \
             from %s:app_ins_type ", fulldb);

       printf("stmt[%s]\n",stmt);

       $prepare getapp2 from $stmt;
       $execute getapp2;

       sprintf_s(stmt,4096,
       " insert into claim_app_dtl_h_2    \
           select iclaim, 'C', iins_type, mins_app, dappraisal   \
             from %s:app_ins_type_hist ", fulldb);

       printf("stmt[%s]\n",stmt);

       $prepare getapph2 from $stmt;
       $execute getapph2;

       sprintf_s(stmt,4096,
       " insert into claim_stl_dtl_2    \
           select iclaim, fstl, cast(iclose_type as char(4)), 'C', iins_type, dgroup,    \
                  decode(fstl,'2',mins_stl*(-1),mins_stl)+mins_proc, mins_proc    \
             from %s:stl_ins_type ", fulldb);

       printf("stmt[%s]\n",stmt);

       $prepare getstl2 from $stmt;
       $execute getstl2;
    }

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car545_prepare_data()
{
    $char sNzip[CA_ZIP], sIpolicy[21], sIclaim[21], sDclaim[11], sNadjust[11];
    $varchar sNassured[121], sNaddress[101], sItag[CA_TAG_NUM], sIadjtel[103];
    $varchar sDriver_nassured[121],sDriver_tel[21];
    $varchar sNtel1[21],sNtel2[21],sNtel3[21];
    $char    sDdate[11],sDdate_s[11];
    $char stmt[4096], sCarDbName[21],sTmpSQL[500];

   strcpy(sDdate,cm_to_infdate(cdate));
   strcpy(sDdate_s,cm_to_infdate(cdate_s));

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == FALSE)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   }

printf("prepared data, cdate[%s]\n",cdate);


	 /* �d�߱���G��W�ӫO�����I(�ư���ˡB�]�l���ѵs)�Φ۵M�H */
	 sprintf_s(stmt,4096,"SELECT UNIQUE a.nassured, b.nzip, b.naddress, \
		         b.ntel1, b.ntel2, b.ntel3, a.ipolicy, \
                         a.iclaim, a.itag, a.dclaim, \
                         (SELECT nassured FROM ca_clm_victim_data \
                           WHERE iclaim = a.iclaim \
                             AND fvictim_car = 'F') AS driver_nassured, \
                         (SELECT itel FROM ca_clm_victim_data \
                           WHERE iclaim = a.iclaim \
                             AND fvictim_car = 'F') AS driver_tel, \
                         (SELECT nname FROM officer \
                           WHERE iofficer = (case when e.dexpire <= today then  \
                                              (select administrator from personal:asempl where empl_no = a.adjustment)  \
                                             else   a.adjustment \
                                              end )) AS nadjust, \
                         (SELECT rtrim(branch_tel) \
                            FROM cm_emp_ext \
                           WHERE empl_no = (case when e.dexpire <= today then  \
                                             (select administrator from personal:asempl where empl_no = a.adjustment)  \
                                            else   a.adjustment \
                                             end )) AS iadjtel \
	                  FROM ca_clm_process a, policy_new b, \
                         (SELECT iclaim1, insure_type, insure_instype, min(dappraisal) AS dappraisal \
                            FROM claim_app_dtl_h_2 \
                           WHERE insure_type = 'C' \
                             AND iclaim1 IN (SELECT iclaim1 \
                                               FROM claim_app_dtl_h_2 \
                                              WHERE dappraisal BETWEEN Date('%s') AND Date('%s')) \
                        GROUP BY iclaim1, insure_type, insure_instype) AS c, cu_customer d, officer e  \
	                 WHERE a.ipolicy[1,13]  = b.ipolicy1 \
	                   AND a.ipolicy[14,20] = b.ipolicy2 \
                           AND a.adjustment     = e.iofficer \
	                   AND a.iclaim         = c.iclaim1  \
	                   AND c.insure_type    = 'C' \
	                   AND c.insure_instype IN (SELECT icode FROM cu_code_data WHERE itype = 'DA') \
	                   AND a.iassured       = d.ifpce_id  \
	                   AND d.fassured       IN ('1','3','5') \
	                   AND d.ifpce_id[1,1] BETWEEN 'A' AND 'Z' \
	                   AND length(trim(d.ifpce_id)) = 10 \
	                   AND c.dappraisal     >= Date('%s') \
	                   AND c.dappraisal     <= Date('%s') \
	                   AND 1 = (SELECT max(CASE WHEN \
	                                   (SELECT count(*) \
	                                      FROM insurance_type \
	                                     WHERE iins_type = x.insure_instype \
	                                       AND fins_grp = '2' \
	                                       AND fkind <> '3') > 0 THEN 4 \
	                                   WHEN \
	                                   (SELECT count(*) \
	                                      FROM insurance_type \
	                                     WHERE iins_type = x.insure_instype \
	                                       AND fkind     = '3') > 0 THEN 3 \
	                                   WHEN \
	                                   (SELECT count(*) \
	                                      FROM insurance_type \
	                                     WHERE iins_type = x.insure_instype \
	                                       AND fkind     = '2') > 0 THEN 2 \
	                                   ELSE 1 END) AS maxadj \
	                              FROM claim_app_dtl_2 x \
	                             WHERE x.iclaim1 = a.iclaim \
	                               AND x.insure_type = 'C') ",sDdate,sDdate_s,sDdate,sDdate_s);

printf("stmt[%s]\n", stmt);

          $PREPARE pre1_1 FROM $stmt;
          $DECLARE cur_pre1_1 CURSOR for pre1_1;
      	  $OPEN cur_pre1_1;

      	while(1)
      	{
         	$FETCH cur_pre1_1 INTO $sNassured,$sNzip,$sNaddress,$sNtel1,$sNtel2,$sNtel3,$sIpolicy,$sIclaim,
         	                       $sItag,$sDclaim,$sDriver_nassured,$sDriver_tel,$sNadjust,$sIadjtel;

         		if(SQLCODE == SQLNOTFOUND) break;

					/* ------------------------------------------------------------------ */
		      /* �t�X�ݨD,�N�a�}�ζl���ϸ������z�߮׮ɯd�U����ơC
		      				add by sylvia 108.06.26 (1080618014_SC1)  */
		      printf("1. sNzip = [%s], sNaddress=[%s] \n",sNzip, sNaddress);
		      strcpy(sCarDbName,get_car_full_db(sIpolicy));
		      sprintf_s(sTmpSQL,500,"select aassured_zip, aassured \
		                         from %s:adjustment_ply \
		                        where iclaim = '%s' \
		                          and aassured_zip <> ' ' and aassured <> ' ' ",
		                          sCarDbName,sIclaim);

		      $PREPARE chg_aasured FROM $sTmpSQL;
		  		$DECLARE chg_aasured_CUR CURSOR FOR chg_aasured;
	    		$OPEN    chg_aasured_CUR;
	    		$FETCH   chg_aasured_CUR INTO $sNzip, $sNaddress;
	    		$CLOSE chg_aasured_CUR;
	    		$FREE  chg_aasured_CUR;
	    		printf("2. sNzip = [%s], sNaddress=[%s] \n",sNzip, sNaddress);
		      /* ------------------------------------------------------------------ */

		$INSERT INTO car545_tmp
          		     (nassured,nzip,naddress,ntel1,ntel2,ntel3,ipolicy,iclaim,
          		      itag,dclaim,driver_nassured,driver_tel,nadjust,iadjtel)
		      	VALUES
          		     ($sNassured,$sNzip,$sNaddress,$sNtel1,$sNtel2,$sNtel3,$sIpolicy,$sIclaim,
         	              $sItag,$sDclaim,$sDriver_nassured,$sDriver_tel,$sNadjust,$sIadjtel);

	}
        $CLOSE cur_pre1_1;
        $FREE cur_pre1_1;



     return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}


long car545_prepare_data2()
{
    $char sNzip[CA_ZIP], sIpolicy[21], sIclaim[21], sDclaim[11], sNadjust[11];
    $varchar sNassured[121], sNaddress[101], sItag[CA_TAG_NUM], sIadjtel[103];
    $varchar sDriver_nassured[121],sDriver_tel[21];
    $varchar sNtel1[21],sNtel2[21],sNtel3[21];
    $char    sDdate[11],sDdate_s[11];
    $char stmt[4096];

    strcpy(sDdate,cm_to_infdate(dgroupBgn));
    strcpy(sDdate_s,cm_to_infdate(dgroupEnd));

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == FALSE)
    {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return FAIL;
    }

		/* �s�W�a�}�ζl���ϸ� add by sylvia 108.06.26 (1080618014_SC1) */
    $create temp table clmtmp
     (
        iclaim         char(20),
        iclose_type    int,
        aassured_zip	 char(6),
        aassured			 char(120)
     )with no log;

    $create unique index axi1 on clmtmp(iclaim);

    for(k=0;k<count_db;k++)
    {
       strcpy(fulldb,list[k].dbname);

       sprintf_s(stmt,4096,
       " insert into clmtmp                                        \
         select a.iclaim, max(a.iclose_type) as iclose_type,       \
                x.aassured_zip, x.aassured                         \
           from %s:stl_ins_type a, %s:adjustment_ply x             \
          where a.iclaim = x.iclaim                                \
            and a.dgroup between Date('%s') and Date('%s')         \
            and a.fstl = '1'                                       \
            and a.iins_type in (select d.iins_type from cu_code_data c, insurance_type d \
                                 where d.iins_type_tradevan = c.icode \
                                   and c.itype = 'H2' and d.iins_type not in ('86','110')) \
            and a.flast = '1'                                      \
            and a.iclaim not in (select iclaim from sysdb:ca_edm where dgroup < Date('%s')) \
            and a.iclaim not in (select b.iclaim                        \
                                   from %s:stl_ins_type b               \
                                  where a.iclaim   =  b.iclaim          \
                                    and b.fstl     =  '1'               \
                                    and b.iins_type in \
                                        (select f.iins_type from cu_code_data e, insurance_type f \
                                          where f.iins_type_tradevan = e.icode \
                                            and e.itype = 'H2' and f.iins_type not in ('86','110')) \
                                    and b.iclose_type < a.iclose_type   \
                                    and b.flast    =  '1'               \
                                    and b.mins_stl >   0                \
                                    and b.dgroup < Date('%s') ) group by 1,3,4 ",
                                    fulldb, fulldb, sDdate, sDdate_s, sDdate, fulldb, sDdate);

       printf("stmt[%s]\n",stmt);

       $prepare geticlaim from $stmt;
       $execute geticlaim;
    }


    sprintf_s(stmt,4096,
    " INSERT INTO car545_tmp2      \
       SELECT unique a.nassured, decode(trim(d.aassured_zip),'',b.nzip,d.aassured_zip), \
              decode(trim(d.aassured),'',b.naddress,d.aassured), \
              b.ntel1, b.ntel2, b.ntel3, a.ipolicy, a.iclaim, a.itag, a.dclaim,  \
       (SELECT max(nassured) FROM ca_clm_victim_data  \
         WHERE iclaim = a.iclaim   \
           AND fvictim_car = 'F') AS driver_nassured, \
       (SELECT max(itel) FROM ca_clm_victim_data      \
         WHERE iclaim = a.iclaim      \
           AND fvictim_car = 'F') AS driver_tel,      \
       nvl((SELECT nname FROM officer                 \
             WHERE iofficer = a.adjustment                \
               AND (dexpire IS NULL or dexpire > today)),' ') AS nadjust,   \
       (SELECT rtrim(branch_tel) || ' #' ||rtrim(ext_tel)  \
          FROM cm_emp_ext         \
         WHERE empl_no = a.adjustment) AS iadjtel,  \
       (select sum(x.msettle - x.mfee)           \
          from claim_stl_dtl_2 x                   \
         where c.iclaim1      = x.iclaim1        \
           and x.insure_instype in (select d.iins_type from cu_code_data c, insurance_type d  \
                                     where d.iins_type_tradevan = c.icode   \
                                       and c.itype = 'H2' and d.iins_type not in ('86','110'))  \
           and x.fstl         = '1'              \
           and x.iclose_type <= d.iclose_type    \
       ) AS msettle,   \
       c.dgroup    \
         FROM ca_clm_process a, policy_new b, claim_stl_dtl_2 c, clmtmp d   \
        WHERE a.ipolicy[1,13]  = b.ipolicy1   \
          AND a.ipolicy[14,20] = b.ipolicy2   \
          AND c.dgroup         between Date('%s') and Date('%s') \
          AND a.iclaim         = c.iclaim1    \
          AND c.insure_instype IN (select f.iins_type from cu_code_data e, insurance_type f \
                                    where f.iins_type_tradevan = e.icode \
                                      and e.itype = 'H2' and f.iins_type not in ('86','110'))  \
          AND c.fstl = '1'    \
          AND c.iclaim1        =  d.iclaim        \
          AND c.iclose_type    =  d.iclose_type ", sDdate, sDdate_s);

       printf(" stmt[%s]\n",stmt);

     $PREPARE ins5452 FROM $stmt;
     $EXECUTE ins5452;



    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car545_build()
{
   int rc;
    char    sfilename[81],stitle[2048],stmt[2048];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"�z�����h���[CAR545]");

    strcpy(stitle,"\t�{���N��:CAR545\t�z�����h���\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(stitle,"\n");

    strcat(stitle,"\t�Q�O�I�H�m�W\t�l���ϸ�\t�a�}\t�q��1\t�q��2\t�q��3\t");
    strcat(stitle,"�O�渹�X\t�߮׸��X\t���P���X\t���z���\t�r�p�H�m�W\t�r�p�H�q��\t�z�ߤH��\t�z�ߤH���q��\t");

    strcpy(stmt,"select nassured,nzip,naddress,ntel1,ntel2,ntel3,ipolicy,iclaim,"
          	"	itag,dclaim,driver_nassured,driver_tel,nadjust,iadjtel "
    		"  from car545_tmp"
    		"  order by ipolicy");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
        sprintf_s(msgbuf,128," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;

}

long car545_build2()
{
   int rc;
    char    sfilename[81],stitle[2048],stmt[2048];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"�O�I�z���v�q�q��[CAR545]");

    strcpy(stitle,"\t�{���N��:CAR545\t�O�I�z���v�q�q��\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(stitle,"\n");

    strcat(stitle,"\t�Q�O�I�H�m�W\t�l���ϸ�\t�a�}\t�q��1\t�q��2\t�q��3\t");
    strcat(stitle,"�O�渹�X\t�߮׸��X\t���P���X\t���z���\t�r�p�H�m�W\t�r�p�H�q��\t�z�ߤH��\t�z�ߤH���q��\t�z�ߪ��B�X�p\t���׷J�p���\t");


    $update car545_tmp2
        set nadjust = (select c.nname
                         from ca_clm_process a, personal:asempl b, officer c
                        where car545_tmp2.iclaim =  a.iclaim
                          and a.adjustment       =  b.empl_no
                          and b.administrator    =  c.iofficer),
            iadjtel = (select rtrim(z.branch_tel) || ' #' ||rtrim(z.ext_tel)
                         from ca_clm_process x, personal:asempl y, cm_emp_ext z
                        where car545_tmp2.iclaim =  x.iclaim
                          and x.adjustment       =  y.empl_no
                          and y.administrator    =  z.empl_no)
      where nadjust = ' ';


    strcpy(stmt,"select nassured,nzip,naddress,ntel1,ntel2,ntel3,ipolicy,iclaim,"
          	"	itag,dclaim,driver_nassured,driver_tel,nadjust,iadjtel,msettle,dgroup "
    		"  from car545_tmp2"
                " where msettle > 0 "
    		"  order by ipolicy");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
        sprintf_s(msgbuf,128," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;

}



long ca545_create_temp()
{
   /* Create table car545_tmp */
   $create temp table car545_tmp
	(
	 nassured   		varchar(120),
	 nzip			char(6),
	 naddress		varchar(120),
	 ntel1			varchar(20),
	 ntel2			varchar(20),
	 ntel3			varchar(20),
	 ipolicy    		char(20),
	 iclaim			char(20),
	 itag			varchar(12),
	 dclaim			date,
	 driver_nassured 	varchar(120),
	 driver_tel		varchar(20),
	 nadjust		varchar(120),
	 iadjtel		char(30)
	)with no log;

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}


long ca545_create_temp2()
{
   /* Create table car545_tmp */
   $create temp table car545_tmp2
	(
	 nassured   		varchar(120),
	 nzip			char(6),
	 naddress		varchar(120),
	 ntel1			varchar(20),
	 ntel2			varchar(20),
	 ntel3			varchar(20),
	 ipolicy    		char(20),
	 iclaim			char(20),
	 itag			varchar(12),
	 dclaim			date,
	 driver_nassured 	varchar(120),
	 driver_tel		varchar(20),
	 nadjust		varchar(120),
	 iadjtel		char(30),
	 msettle                integer,
	 dgroup                 date
	)with no log;

    return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
