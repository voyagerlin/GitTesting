/**********************************************************************/
/*   program id   : ca659q01s.ec                                      */
/*   program name : ���I�ˮ`�I���ӳ���                                */
/*   date written : 2021/08/24 by 101314                              */
/*   files        :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "safeclib.h"
$char iquota[10];
$char dbgn[11],dbgn2[21],dbgn_q[21];
$char dend[11],dend2[21],dend_q[21];
$char stmpx[128];

int   count_db,k; 
char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];

$char  iins48[2],iins56[2],iins57[2],iins59[2],iins60[2],iins166[2],iins266[2];

DBinfo *list;

main(argc, argv)
int argc;
char **argv;
{
	int rc;
	
	batchinit();
	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(iquota,         isNULLstr(argv[3]));  /*���*/
	strcpy(dbgn,           isNULLstr(argv[4]));  /*�e�~����϶�*/
	strcpy(dend,           isNULLstr(argv[5]));
	strcpy(iins48,         isNULLstr(argv[6]));
	strcpy(iins56,         isNULLstr(argv[7]));
	strcpy(iins57,         isNULLstr(argv[8]));
	strcpy(iins59,         isNULLstr(argv[9]));
	strcpy(iins60,         isNULLstr(argv[10]));
	strcpy(iins166,        isNULLstr(argv[11]));
	strcpy(iins266,        isNULLstr(argv[12]));
	strcpy(outputf,        isNULLstr(argv[13]));
	
	rc = car659_get_db();
	if (rc != M_CM_OK)
		return rc;
	
	rc = car659_prepare_data();
	if (rc != M_CM_OK)
		return rc;
	
	rc = car659_build();
	if (rc != M_CM_OK) 
		return rc;
}

long car659_get_db()
{
	$whenever sqlerror goto errexit;
	
	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	
	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car659_prepare_data()
{
	$char igroup[11],ngroup[21],fcard_class[2],imgr[2],iroute[21],iclass[2];
	$int  qorder = 0,cnt = 0;
	$char stmt[4096],stmt2[4096];
	$char tmp_table1[2048],stmp1[128],stmp2[128],stmp3[128];
	$char sFullName[21];
	$char db_tmp[3];
	$char iins_tmp1[100],iins_tmp[100];
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == FALSE)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return FAIL;
	}
	
	printf("iins48=[%s]\n",iins48);
	printf("iins56=[%s]\n",iins56);
	printf("iins57=[%s]\n",iins57);
	printf("iins59=[%s]\n",iins59);
	printf("iins60=[%s]\n",iins60);
	printf("iins166=[%s]\n",iins166);
	printf("iins266=[%s]\n",iins266);
	
	strcpy(iins_tmp1,"");
	if (iins48[0] == '1')  strcat(iins_tmp1,"'48',");
	if (iins56[0] == '1')  strcat(iins_tmp1,"'56',");
	if (iins57[0] == '1')  strcat(iins_tmp1,"'57',");
	if (iins59[0] == '1')  strcat(iins_tmp1,"'59',");
	if (iins60[0] == '1')  strcat(iins_tmp1,"'60',");
	if (iins166[0] == '1') strcat(iins_tmp1,"'166',");
	if (iins266[0] == '1') strcat(iins_tmp1,"'266',");
	strcat(iins_tmp1,"last");
	
	$SELECT FIRST 1 replace($iins_tmp1,',last','')
	   INTO $iins_tmp
	   FROM systables;
	
	strcpy(iins_tmp,trim(iins_tmp));
	printf("iins_tmp=[%s]\n",iins_tmp);
	
	strcpy(dbgn_q,cm_to_infdate(dbgn));
	strcpy(dend_q,cm_to_infdate(dend));
	
	if(strlen(iquota) < 6)
	{
		sprintf_s(stmp1, sizeof stmp1,"AND a.iquota MATCHES '%s'",iquota);
	}
	else
	{
		sprintf_s(stmp1, sizeof stmp1,"AND a.iquota = '%s'",iquota);
	}
	/*�ץ��L���إN��icar_type�B�����ʤ֨��P�N���C112.08.30 by 120957()*/
	sprintf_s(tmp_table1, sizeof tmp_table1,"create temp table ply_out_tmp  "
	                   "(  "
	                   "   iins_type       char(6),    "
	                   "   ipolicy         char(20),   "
	                   "   iendorse        char(20),   "
	                   "   icard           char(20),   "
	                   "   iassured        char(12),   "
	                   "   icar_type       char(2),    "
	                   "   itag            char(%d),   "
	                   "   iofficer        char(10),   "
	                   "   nofficer        char(10),   "
	                   "   ileader         char(10),   "
	                   "   nleader         char(10),   "
	                   "   iroute          char(20),   "
	                   "   nroute          char(40),   "
	                   "   dpolicy         DATE,       "
	                   "   dendorse        DATE,       "
	                   "   dply_begin      DATE,       "
	                   "   dply_end        DATE,       "
	                   "   dedr_begin      DATE,       "
	                   "   dedr_end        DATE,       "
	                   "   mr_ins_prem     decimal(32,0),  "
	                   "   mdeath_ins_prem decimal(32,0),  "
	                   "   mins_premium    int,        "
	                   "   minjured_cover  INT,        "
	                   "   mdeath_cover    INT,        "
	                   "   mdamage_cover   INT,        "
	                   "   iquota          char(10),   "
	                   "   ilast_ply       char(20)    "
	                   ") with no log;",CA_TAG_NUM-1);
	printf("tmp_table1=[%s]\n",tmp_table1);
	$PREPARE tmp_table FROM $tmp_table1;
	$EXECUTE tmp_table;
			
	for(k=0;k<count_db;k++)
	{
		/* SQL���� chr(127), �i�H�b��EXCEL����0�������,���|���@�Ů�,�p���s�ɻݨD, ���V�ΡC*/
		sprintf_s(stmt, sizeof stmt,"INSERT INTO ply_out_tmp  "
		            " SELECT c.iins_type,a.ipolicy,'',a.icard,b.iassured,a.icar_type,b.itag,  "
		            "        chr(127)||a.iofficer,(SELECT nname FROM officer WHERE iofficer = a.iofficer),  "
		            "        chr(127)||a.ileader,(SELECT nname FROM officer WHERE iofficer = a.ileader),  "
		            "        b.iroute,(SELECT nroute FROM cm_route WHERE iroute = b.iroute),  "
		            "        a.dpolicy,'',a.dply_begin,a.dply_end,'','',  "
		            "        NVL((SELECT sum(mr_ins_prem) FROM %s:ca_pa_ori WHERE ipolicy = a.ipolicy AND iins_type = c.iins_type),0),  "
		            "        NVL((SELECT sum(mins_premium) - sum(mr_ins_prem) FROM %s:ca_pa_ori WHERE ipolicy = a.ipolicy AND iins_type = c.iins_type),0),  "
		            "        c.mins_premium,c.minjured_cover,c.mdeath_cover,c.mdamage_cover,a.iquota,NVL(a.ilast_ply,' ')   "
		            "   FROM %s:ori_ply_relation a ,%s:original_ply b, %s:ori_ins_type c  "
		            "  WHERE a.ipolicy = b.ipolicy  "
		            "    AND a.ipolicy = c.ipolicy  "
		            "    AND a.dpolicy BETWEEN '%s' AND '%s' %s  "
		            "    AND c.iins_type IN (%s)",list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,dbgn_q,dend_q,stmp1,iins_tmp);
		printf("stmt[%s]\n",stmt);
		$PREPARE ply_out_1 FROM $stmt;
		$EXECUTE ply_out_1;
		
		sprintf_s(stmt2, sizeof stmt2,"INSERT INTO ply_out_tmp  "
		            " SELECT c.iins_type,a.ipolicy,a.iendorse,a.icard,b.iassured,a.icar_type,b.itag,  "
		            "        chr(127)||a.iofficer,(SELECT nname FROM officer WHERE iofficer = a.iofficer),  "
		            "        chr(127)||a.ileader,(SELECT nname FROM officer WHERE iofficer = a.ileader),  "
		            "        b.iroute,(SELECT nroute FROM cm_route WHERE iroute = b.iroute),  "
		            "        '',a.dendorse,b.dply_begin,b.dply_end,a.dedr_begin,a.dedr_end,  "
		            "        NVL((SELECT sum(medr_mr_ins_prem) FROM %s:ca_pa_edr WHERE iendorse = a.iendorse AND iins_type = c.iins_type),0),  "
		            "        NVL((SELECT sum(medrins_prem) - sum(medr_mr_ins_prem) FROM %s:ca_pa_edr WHERE iendorse = a.iendorse AND iins_type = c.iins_type),0),  "
		            "        c.medrins_prem,c.medrinj_cover,c.medrdea_cover,c.medrdmg_cover,a.iquota,   "
		            "        NVL((SELECT ilast_ply FROM %s:ply_relation WHERE ipolicy = a.ipolicy),' ')  "
		            "   FROM %s:edr_relation a ,%s:endorsement b, %s:edr_ins_type c  "
		            "  WHERE a.iendorse = b.iendorse  "
		            "    AND a.iendorse = c.iendorse  "
		            "    AND a.dendorse BETWEEN '%s' AND '%s' %s  "
		            "    AND c.iins_type IN (%s)",list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,dbgn_q,dend_q,stmp1,iins_tmp);
		printf("stmt2[%s]\n",stmt2);
		$PREPARE edr_out_1 FROM $stmt2;
		$EXECUTE edr_out_1;
	}

	return M_CM_OK;
	
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/


long car659_build()
{
	int rc;
	$char sfilename[256],stitle[2048],stmt1[4096],stmt11[8192];

	$WHENEVER SQLERROR GOTO errexit;
	
	sprintf_s(sfilename, sizeof sfilename,"���I�ˮ`�I���ӳ���[%s]\n",stmpx);
	
	/*stitle�ɶq�@��d�w�A�קK���D����*/
	sprintf_s(stitle, sizeof stitle,"�I�إN��\t�O�渹�X\t��渹\t�O�d��\t�Q�O�I�H\t���إN��\t���P���X\t�g��H�N��\t�g��H�W��\t�޲z�H�N��\t�޲z�H�W��\t�q���N��\t�q���W��\tñ���\t����\t�O�I�ͮĤ�\t�O�I�����\t���ͮĤ�\t�������\t��˫O�O\t���`����O�O\t�I�ثO�O\t�O�B�@(��˫O�B)\t�O�B�G(���`�O�B)\t�O�B�T(�ƬG�O�B)\t�~�Z���N��\t��O�渹\t");
	
	strcpy(stmt1,"SELECT * FROM ply_out_tmp");
	
	rc = unload_file(outputf," ",sfilename,stitle,stmt1);
	$DROP TABLE ply_out_tmp;	
	
	if (rc != SUCCESS) 
	{
	    sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	printf("done. return M_CM_OK\n");	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}
