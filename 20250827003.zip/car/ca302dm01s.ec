/*--------------------------------------------------*/
/*   PROGRAM : ca302dm01s.ec                        */
/*   MODIFIER: sylvia                               */
/*   DATE    : 2017/03/17                           */
/*--------------------------------------------------*/
     
#include <stdio.h>
#include <stdlib.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include <decimal.h>
#include "safeclib.h"

typedef struct
{
    char   type;
    long   mcover_ori;
    long   mcover_new1;
    long   mcover_new2;
    char   dplybgn_yymm[6];
    char   dplyend_yymm[6];
    char   dupdate[21];
    long   old_mcover_ori;
    long   old_mcover_new1;
    long   old_mcover_new2;
    char   old_dplybgn_yymm[6];
    char   old_dplyend_yymm[6];
    char   old_dupdate[21];
} car302d_t;

/*--------------------------------------------------*/
long car302d(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    long rtncode;
    long car302d_insert(),car302d_single_query(),car302d_multiple_query(),car302d_update_exec();
    char option;

    cm_buf_init(command);
    cm_buf_get("%c",&option);

    switch(option)
    {
        case 'A':
                rtncode=car302d_insert(reply);
            break;
        case 'Q':
            rtncode=car302d_single_query(reply);
            break;
        case 'M':
            rtncode=car302d_multiple_query(reply);
            break;
        case 'D':
        case 'U':
            rtncode=car302d_update_exec(reply,command,com_len);
            break;
        default :
            if(exitsub(reply,M_CM_WRONG_OPTION) == True)
                return M_CM_WRONG_OPTION;
        return apiRC;
    }
    return(rtncode);
}

/*--------------------------------------------------*/
long car302d_insert(reply)  /* �s�W */
serverReply reply;
{
    $char    DBName[5];
    $char    icar_type[4],limit[4],dplybgn_yymm[6],dplyend_yymm[6],userid[11],
             idealer[4];
    $long    mcover_ori,mcover_new1,mcover_new2;
    $int     imultiple;
    int      tmp_len;
    long     MsgCode;

    DBinfo   *list;
    int      k, j, is_add_fail=0, api_f;
    $char    stmt_buf[500];

    int      rows, i;
    car302d_t *alist;

    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s %s %s %l",userid, idealer, icar_type,limit, &rows);

    strcpy(idealer,trim(idealer));
    strcpy(icar_type,trim(icar_type));
    strcpy(limit,trim(limit));
    imultiple = atoi(limit);

    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
                return M_CM_DB_NOTOPEN;
        else
                return apiRC;
    }

    alist = (car302d_t *) malloc (rows * sizeof (car302d_t));

    for (k=0;k<rows;k++)
    {
        cm_buf_get("%l %l %l %s %s", 
                   &mcover_ori,&mcover_new1,&mcover_new2, dplybgn_yymm,dplyend_yymm);
        alist[k].mcover_ori    = mcover_ori;
        alist[k].mcover_new1    = mcover_new1;
        alist[k].mcover_new2       = mcover_new2;

        strcpy(alist[k].dplybgn_yymm,dplybgn_yymm);
        strcpy(alist[k].dplyend_yymm,dplyend_yymm);
    }

    if((list=get_sysdb_list(&i,DBName)) == (char*)0)
    {
        if(exitsub(reply,M_CM_NOT_DBLIST) == True)
                return M_CM_NOT_DBLIST;
        return apiRC;
    }

    $WHENEVER SQLERROR CONTINUE;
    $BEGIN WORK;

    for(j=0;j<i;j++)
    {
        sprintf_s(stmt_buf,sizeof stmt_buf,"INSERT INTO %s:ca_change_ins \
                          (idealer, icar_type,imultiple,mcover_ori,mcover_new1,mcover_new2, \
                           dplybgn_yymm,dplyend_yymm,icreate,dcreate,iupdate,dupdate) \
                          VALUES (?, ?,?,?,?,?,?,?,?,current,?,current)",
                          list[j].dbname);
        for(k=0;k<rows;k++)
        {
            $PREPARE b_id FROM $stmt_buf;
            if(SQLCODE != 0)
            {
                is_add_fail = 3;
                break;
            }
            mcover_ori    = alist[k].mcover_ori;
            mcover_new1    = alist[k].mcover_new1;
            mcover_new2       = alist[k].mcover_new2;
            strcpy(dplybgn_yymm,alist[k].dplybgn_yymm);
            strcpy(dplyend_yymm,alist[k].dplyend_yymm);

            $EXECUTE b_id USING $idealer, $icar_type,$imultiple,$mcover_ori,
                                $mcover_new1,$mcover_new2,$dplybgn_yymm,
                                $dplyend_yymm,$userid,$userid;
            if(SQLCODE != 0)
            {
                is_add_fail = 3;
                break;
            }
        }

        if (is_add_fail == 3)
        {
            is_add_fail = 1;
            break;
        }

        cm_buf_init(ReplyBuf);
        cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);

        tmp_len = cm_buf_len(ReplyBuf);

        if(j == i-1)
            api_f = api_OKComplete;
        else
            api_f = api_OK;

        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
        {
            is_add_fail = 2;
            break;
        }
    } /* for loop */

    free ((char *) alist);

    if(is_add_fail == 1)
        goto errexit;

    if(is_add_fail == 2)
    {
        $ROLLBACK WORK;
        return apiRC;
    }

    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;

    return api_OKComplete;

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;

    if(SQLCODE != 0)
        MsgCode = SQLCODE;

    if(exitsub(reply,MsgCode) == True)
        return MsgCode;
    else
        return apiRC;
}

/*--------------------------------------------------*/
long car302d_single_query(reply)
serverReply reply;
{
    /* standard defined host variables */
    $char DBName[5];
    /* end of standard host var */

    /* table  */
    $char   icar_type[4], dplybgn_yymm[6], dplyend_yymm[6], icreate[11], 
            iupdate[11], car_type[4],limit[3], dplybgn[6], dplyend[6], dupdate[20],
            idealer[4], dealer[4];
    
    $int    imultiple, ilimit;
    $long   mcover_ori, mcover_new1, mcover_new2;
    /* end of  */

    /* standard defined data */
    char tmpbuf[4000];
    int  count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int  i,total_count=0;
    /* end of standard data */

    strcpy(idealer," "); strcpy(dealer, " ");
    strcpy(car_type," "); strcpy(limit," "); strcpy(dplybgn, " "); 
    strcpy(dplyend, " "); strcpy(dupdate," ");
    strcpy(icar_type," "); strcpy(dplybgn_yymm," "); strcpy(dplyend_yymm, " ");
    imultiple = 0;  mcover_ori = 0;  mcover_new1 = 0;  mcover_new2 = 0; 

    cm_buf_get("%s",DBName);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
                return M_CM_DB_NOTOPEN;
        else
                return apiRC;
    }

    cm_buf_get("%s %s %s %s %s",dealer, car_type, limit, dplybgn, dplyend);
    ilimit = atoi(limit);
    
    $DECLARE q_cur CURSOR FOR
        SELECT mcover_ori, mcover_new1, mcover_new2, dplybgn_yymm, dplyend_yymm,
               dupdate  
          INTO $mcover_ori, $mcover_new1, $mcover_new2, $dplybgn_yymm, $dplyend_yymm,
               $dupdate
          FROM ca_change_ins
         WHERE idealer = $dealer 
           AND icar_type = $car_type  
           AND imultiple = $ilimit
           AND dplybgn_yymm = $dplybgn
           AND dplyend_yymm = $dplyend
         ORDER BY 1,2,3;
    $OPEN q_cur;

    cm_buf_init(ReplyBuf);
    cm_buf_res_msg();             /* reserve for MsgCode and count */
    cm_buf_res_count();
    cm_buf_put("%s %s %s", dealer, car_type, limit);

    for(;;)
    {
        $FETCH q_cur;
        if (SQLCODE != 0) break;
printf("dupdate=[%s] \n",dupdate);
        cm_buf_put("%l %l %l %s %s %s ",
                    mcover_ori, mcover_new1, mcover_new2, dplybgn_yymm, 
                    dplyend_yymm, dupdate);
        count++;

    } /* for loop */

    $CLOSE q_cur;
    $FREE  q_cur;

    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        tmp_len = cm_buf_len(ReplyBuf);
        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                return apiRC;
        return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
        if(exitsub(reply,M_CA_NCOVER_PREM) == True)
                return M_CA_NCOVER_PREM;
        else
                return apiRC;
    }

errexit:
    if(exitsub(reply,SQLCODE) == True)
        return SQLCODE;
    else
        return apiRC;
}

/****************************************************************************/
long car302d_multiple_query(reply)
serverReply reply;
{
    /* standard defined host variables */
    $char   DBName[5], stmt[1024], sWhere[256], sTmp[51];
    /* end of standard host var */

    /* table  */
    $char   idealer[4], icar_type[4], dplybgn_yymm[6], dplyend_yymm[6], icreate[11], 
            iupdate[11], dealer[4], car_type[4],limit[3], dplybgn[6], dplyend[6];
    
    $int    imultiple, ilimit;
    $long   mcover_ori, mcover_new1, mcover_new2;
    /* end of  */

    /* standard defined data */
    char tmpbuf[4000];
    int  count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int  i,total_count=0;
    /* end of standard data */
    
    strcpy(car_type," "); strcpy(limit," "); strcpy(dplybgn, " "); 
    strcpy(dplyend, " "); strcpy(idealer," "); strcpy(dealer, " ");
    strcpy(icar_type," "); strcpy(dplybgn_yymm," "); strcpy(dplyend_yymm, " ");
    imultiple = 0;  mcover_ori = 0;  mcover_new1 = 0;  mcover_new2 = 0; 
    
    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s %s %s %s",dealer, car_type, limit, dplybgn, dplyend);
     
    $WHENEVER SQLERROR GOTO errexit;
    
    strcpy(sWhere, " ");
     
    /* ���� */ 
    if (strcmp(limit,"*") == 0)
    {
        ilimit = 0;
        sprintf_s(sWhere,sizeof sWhere,"and imultiple >= %d ",ilimit);
    }
    else
    {
        ilimit = atoi(limit);
        sprintf_s(sWhere,sizeof sWhere,"and imultiple = %d ", ilimit);
    }
   
    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }

    sprintf_s( stmt, sizeof stmt,
        "SELECT unique idealer, icar_type, imultiple, dplybgn_yymm, dplyend_yymm "
        "  FROM ca_change_ins "
        " WHERE idealer matches '%s' and icar_type matches '%s' "
        "   AND dplybgn_yymm matches '%s' "
        "   AND dplyend_yymm matches '%s' %s "
        " ORDER BY idealer, icar_type,imultiple,dplybgn_yymm, dplyend_yymm ", 
        dealer, car_type, dplybgn, dplyend, sWhere);

    printf("stmt[%s]\n", stmt);
    $PREPARE pre_m1 FROM $stmt; 
    $DECLARE cur_m1 CURSOR FOR pre_m1;
    $OPEN cur_m1;
    for(;;)
    {
        $FETCH cur_m1 INTO $idealer, $icar_type, $imultiple,  $dplybgn_yymm, $dplyend_yymm;

        if (SQLCODE != 0) break;

        cm_buf_init(tmpbuf);

        if (count == 0)
        {
            cm_buf_res_msg();             /* reserve for MsgCode and count */
            cm_buf_res_count();
        }

        cm_buf_put("%s %s %l %s %s ",
                    idealer, icar_type, imultiple, dplybgn_yymm, dplyend_yymm);
        
        tmp_len = cm_buf_len(tmpbuf);
        if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K, ���i�A��j�A�|�����D */
        {

            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else                               /* more than 4K, send to client side */
        {

            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);
            if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {
                $CLOSE cur_m1;
                return apiRC;
            }
            else               /* clear ReplyBuf and count to start all over again */
            {
                replycnt++;
                if (replycnt == 10)   /* ���i�A��j�A�|�����D */
                {
                        cm_buf_init(ReplyBuf);
                        cm_buf_put("%l",M_CM_OUT_SPACE);
                        tmp_len = cm_buf_len(ReplyBuf);
                        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                                return apiRC;
                        return M_CM_OUT_SPACE;
                }
                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();           /* reserve for MsgCode and count */
                cm_buf_res_count();
                cm_buf_put("%s %s %l %s %s ",
                            idealer, icar_type, imultiple, dplybgn_yymm, dplyend_yymm);
                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
            }
        }
    }/* for loop */
    $CLOSE cur_m1;
    $FREE cur_m1;
    

    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
                return apiRC;
        return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
        if(exitsub(reply,M_CA_NCOVER_PREM) == True)
                return M_CA_NCOVER_PREM;
        else
                return apiRC;
    }

errexit:
    if(exitsub(reply,SQLCODE) == True)
        return SQLCODE;
    else
        return apiRC;
}

/*--------------------------------------------------*/



long car302d_multiple_query_bak(reply)
serverReply reply;
{
    /* standard defined host variables */
    $char   DBName[5], stmt[1024], sWhere[256], sTmp[51];
    /* end of standard host var */

    /* table  */
    $char   icar_type[4], dplybgn_yymm[6], dplyend_yymm[6], icreate[11], 
            iupdate[11], car_type[4],limit[3], dplybgn[6], dplyend[6],
            idealer[4], dealer[4];
    
    $int    imultiple, ilimit;
    $long   mcover_ori, mcover_new1, mcover_new2;
    /* end of  */

    /* standard defined data */
    char tmpbuf[4000];
    int  count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int  i,total_count=0;
    /* end of standard data */
    
    strcpy(car_type," "); strcpy(limit," "); strcpy(dplybgn, " "); 
    strcpy(dplyend, " "); strcpy(dealer," "); strcpy(idealer, " ");
    strcpy(icar_type," "); strcpy(dplybgn_yymm," "); strcpy(dplyend_yymm, " ");
    imultiple = 0;  mcover_ori = 0;  mcover_new1 = 0;  mcover_new2 = 0; 
    
    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s %s %s %s",dealer, car_type, limit, dplybgn, dplyend);
     
    $WHENEVER SQLERROR GOTO errexit;
    
    strcpy(sWhere, " ");
     
    /* ���� */ 
    if (strcmp(limit,"*") == 0)
    {
        ilimit = 0;
        sprintf_s(sWhere,sizeof sWhere,"and imultiple >= %d ",ilimit);
    }
    else
    {
        ilimit = atoi(limit);
        sprintf_s(sWhere,sizeof sWhere,"and imultiple = %d ", ilimit);
    }
   
    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }

    sprintf_s( stmt,sizeof stmt, 
        "SELECT idealer, icar_type, imultiple, mcover_ori, mcover_new1, "
        "       mcover_new2, dplybgn_yymm, dplyend_yymm "
        "  FROM ca_change_ins "
        " WHERE idealer matches '%s' and icar_type matches '%s' "
        "   AND dplybgn_yymm matches '%s' "
        "   AND dplyend_yymm matches '%s' %s "
        " ORDER BY idealer, icar_type,imultiple,mcover_ori, mcover_new1 ", 
        dealer, car_type, dplybgn, dplyend, sWhere);

    printf("stmt[%s]\n", stmt);
    $PREPARE pre_m1x FROM $stmt; 
    $DECLARE cur_m1x CURSOR FOR pre_m1x;
    $OPEN cur_m1x;
    for(;;)
    {
        $FETCH cur_m1x INTO $idealer, $icar_type, $imultiple, $mcover_ori, $mcover_new1, 
                           $mcover_new2, $dplybgn_yymm, $dplyend_yymm;

        if (SQLCODE != 0) break;

        cm_buf_init(tmpbuf);

        if (count == 0)
        {
            cm_buf_res_msg();             /* reserve for MsgCode and count */
            cm_buf_res_count();
        }

        cm_buf_put("%s %s %l %l %l %l %s %s ",
                    idealer, icar_type, imultiple, mcover_ori, mcover_new1, mcover_new2, 
                    dplybgn_yymm, dplyend_yymm);
        
        tmp_len = cm_buf_len(tmpbuf);
        if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K, ���i�A��j�A�|�����D */
        {

            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else                               /* more than 4K, send to client side */
        {

            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);
            if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {
                $CLOSE cur_m1;
                return apiRC;
            }
            else               /* clear ReplyBuf and count to start all over again */
            {
                replycnt++;
                if (replycnt == 10)   /* ���i�A��j�A�|�����D */
                {
                        cm_buf_init(ReplyBuf);
                        cm_buf_put("%l",M_CM_OUT_SPACE);
                        tmp_len = cm_buf_len(ReplyBuf);
                        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                                return apiRC;
                        return M_CM_OUT_SPACE;
                }
                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();           /* reserve for MsgCode and count */
                cm_buf_res_count();
                cm_buf_put("%s %s %l %l %l %l %s %s ",
                            idealer, icar_type, imultiple, mcover_ori, mcover_new1, mcover_new2, 
                            dplybgn_yymm, dplyend_yymm);
                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
            }
        }
    }/* for loop */
    $CLOSE cur_m1x;
    $FREE cur_m1x;
    

    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
                return apiRC;
        return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
        if(exitsub(reply,M_CA_NCOVER_PREM) == True)
                return M_CA_NCOVER_PREM;
        else
                return apiRC;
    }

errexit:
    if(exitsub(reply,SQLCODE) == True)
        return SQLCODE;
    else
        return apiRC;
}

/* ----------------------------------------------------------------------------- */
long car302d_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    /* standard defined host variables */
    $char DBName[5];
    /* end of standard host var */

    $char old_car_type[4], old_limit[4],old_dplybgn_yymm[6],old_dplyend_yymm[6],
          old_dupdate[22],userid[11], old_dealer[4];
    $long old_mcover_ori,old_mcover_new1,old_mcover_new2;
    
    $char dealer[4], car_type[4], limit[4], dplybgn_yymm[6], dplyend_yymm[6], dupdate[22];
    $long mcover_ori, mcover_new1, mcover_new2;
    /* standard defined data */
    char option,*pos,*raw_ptr,cur_buf[180000],*comm;
    long  tmp_len,raw_len;
    long dummy=0,dum_cnt=0;
    long dummy_tmp=0;
    long MsgCode;
    int  count=0, rows,i;
    DBinfo *list;
    int k, j, is_del_fail=0, is_upd_fail=0;
    $char stmt_buf[1024];
    /* end of standard data */

    /* self defined data */
    char rflag;
    car302d_t *alist;


    comm = (char *) command;
    cm_buf_init(command);
    cm_buf_get("%c %s",&option,DBName);
printf("--663- option = [%c] \n",option);
    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
                return M_CM_DB_NOTOPEN;
        return apiRC;
    }

    if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
    {
        if(exitsub(reply,M_CM_NOT_DBLIST) == True)
                return M_CM_NOT_DBLIST;
        return apiRC;
    }
    /* compare old record and current record, if the record has not been changed
       since last request, update or delete the record, otherwise return errmsg
       to client side */
    /* get old record info from command buffer */

    memcpy(&raw_len,&comm[com_len],sizeof(int));
    pos = &comm[com_len+sizeof(int)];
    raw_ptr = malloc(raw_len);
    if (raw_ptr != (char*)0)
        memcpy(raw_ptr,pos,raw_len);
    else
    {
        if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
                return M_CM_NOT_MALLOC;
        else
                return apiRC;
    }

    cm_buf_init(raw_ptr);          /* get index key from old record */
    cm_buf_get("%l %l",&dummy,&dum_cnt);
    cm_buf_get("%s %s %s %l %l %l %s %s %s",
                old_dealer, old_car_type, old_limit, &old_mcover_ori, &old_mcover_new1, 
                &old_mcover_new2, old_dplybgn_yymm, old_dplyend_yymm, old_dupdate);
   
    $BEGIN WORK;

    $WHENEVER SQLERROR GOTO errexit;
    
        $DECLARE q1_curX CURSOR FOR
          SELECT mcover_ori, mcover_new1, mcover_new2, dplybgn_yymm, dplyend_yymm,
               dupdate  
          INTO $mcover_ori, $mcover_new1, $mcover_new2, $dplybgn_yymm, $dplyend_yymm,
               $dupdate
          FROM ca_change_ins
         WHERE idealer = $old_dealer 
           AND icar_type = $old_car_type
           AND imultiple = $old_limit
           AND dplybgn_yymm = $old_dplybgn_yymm
           AND dplyend_yymm = $old_dplyend_yymm
         ORDER BY 1,2,3;
        $OPEN q1_curX;
    

    /* reserve for MsgCode and count */
    cm_buf_init(cur_buf);
    cm_buf_res_msg();
    cm_buf_res_count();
    cm_buf_put("%s %s %s ", old_dealer, old_car_type, old_limit);

    for(;;)
    {
        $FETCH q1_curX;
        if (SQLCODE != 0) break;

        cm_buf_put("%l %l %l %s %s %s ",
                    &mcover_ori, &mcover_new1, &mcover_new2, dplybgn_yymm, 
                    dplyend_yymm, dupdate);

        count++;
    }

    /* if key value has been changed then SQLNOTFOUND,else put current value
       into cur_buf for comparison */

    if (count == 0)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;

        $CLOSE q1_curX;

        if(exitsub(reply,M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
        else
            return apiRC;
    }

    $CLOSE q1_curX;
    $WHENEVER SQLERROR GOTO errexit;

    cm_buf_init(cur_buf); 
    cm_buf_put_msg(dummy);
    cm_buf_put_count(count);

    /* equal, then exec DB operation */
printf("--773- option = [%c]\n",option);
    if ( option == 'D' )
    {
        for(j=0;j<i;j++)
        {
            sprintf_s(stmt_buf,sizeof stmt_buf, 
                "DELETE FROM %s:ca_change_ins WHERE idealer = ? and icar_type=? and imultiple = ? \
                        AND dplybgn_yymm=? AND dplyend_yymm=? ",list[j].dbname);
            $PREPARE d_id FROM $stmt_buf;
            if(SQLCODE != 0)
            {
                is_del_fail = 1;
                break;
            }
            $EXECUTE d_id USING $old_dealer, $old_car_type,$old_limit,$old_dplybgn_yymm,$old_dplyend_yymm;
            if(SQLCODE != 0)
            {
                is_del_fail = 1;
                break;
            }
        }/* for loop */
        if( is_del_fail ) goto errexit;

        cm_buf_init(ReplyBuf);
        cm_buf_put("%l",M_CM_OK);
        tmp_len = cm_buf_len(ReplyBuf);
        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return apiRC;
        }

        $WHENEVER SQLERROR GOTO errexit;
        $COMMIT WORK;
        return api_OKComplete;
    }
    else if (option == 'U')
    {
        printf("--812- option = [%c] \n",option);
        cm_buf_init(command);
        cm_buf_get("%c %s",&option,DBName);
        cm_buf_get("%s %s %s %s %l",userid, dealer, car_type, limit, &rows);

        strcpy(userid,trim(userid));
        strcpy(dealer,trim(dealer));
        strcpy(car_type,trim(car_type));
        strcpy(limit,trim(limit));

        alist = (car302d_t *) malloc (rows * sizeof (car302d_t));
        for (k=0;k<rows;k++)
        {
            cm_buf_get("%c %l %l %l %s %s %s",
                        &rflag,
                        &old_mcover_ori,&old_mcover_new1,&old_mcover_new2,
                        old_dplybgn_yymm,old_dplyend_yymm,old_dupdate);

            cm_buf_get("%l %l %l %s %s %s",
                        &mcover_ori,&mcover_new1,&mcover_new2,
                        dplybgn_yymm,dplyend_yymm,dupdate);
                        
            alist[k].type          = rflag;
            alist[k].old_mcover_ori = old_mcover_ori;
            alist[k].old_mcover_new1 = old_mcover_new1;
            alist[k].old_mcover_new2    = old_mcover_new2;
            strcpy(alist[k].old_dplybgn_yymm , old_dplybgn_yymm);
            strcpy(alist[k].old_dplyend_yymm , old_dplyend_yymm);
            strcpy(alist[k].old_dupdate , old_dupdate);
            alist[k].mcover_ori    = mcover_ori;
            alist[k].mcover_new1    = mcover_new1;
            alist[k].mcover_new2       = mcover_new2;

            strcpy(alist[k].dplybgn_yymm , dplybgn_yymm);
            strcpy(alist[k].dplyend_yymm , dplyend_yymm);
            strcpy(alist[k].dupdate  , dupdate);
        }

        $WHENEVER SQLERROR CONTINUE;

        for(j=0;j<i;j++)
        {
            for (k = 0; k < rows && is_upd_fail != 3; k++)
            {
                old_mcover_ori = alist[k].old_mcover_ori;
                old_mcover_new1 = alist[k].old_mcover_new1;
                old_mcover_new2 = alist[k].old_mcover_new2;
                strcpy(old_dplybgn_yymm, alist[k].old_dplybgn_yymm);
                strcpy(old_dplyend_yymm, alist[k].old_dplyend_yymm);
                strcpy(old_dupdate, alist[k].old_dupdate);
                
                mcover_ori = alist[k].mcover_ori;
                mcover_new1 = alist[k].mcover_new1;
                mcover_new2 = alist[k].mcover_new2;
    
                strcpy(dplybgn_yymm, alist[k].dplybgn_yymm);
                strcpy(dplyend_yymm, alist[k].dplyend_yymm);
                strcpy(dupdate, alist[k].dupdate);

                switch(alist[k].type)
                {
                    printf("-- 872 --- alist[k].type=[%c]\n",alist[k].type);
                    case 'A':
                        sprintf_s(stmt_buf,sizeof stmt_buf, "INSERT INTO %s:ca_change_ins \
                                          (idealer, icar_type,imultiple,mcover_ori,mcover_new1,mcover_new2, \
                                           dplybgn_yymm, dplyend_yymm, icreate, dcreate, iupdate, dupdate) \
                                          VALUES (?,?,?,?,?,?,?,?,'%s',current,'%s',current)",list[j].dbname,userid,userid);
                        $PREPARE u1_id FROM $stmt_buf;
                        if(SQLCODE != 0)
                        {
                            is_upd_fail = 3;
                            break;
                        }
                        $EXECUTE u1_id USING $dealer, $car_type,$limit,$mcover_ori,$mcover_new1,$mcover_new2,
                                             $dplybgn_yymm,$dplyend_yymm;
                        if(SQLCODE != 0)
                             is_upd_fail = 3;
                        break;
                    case 'D':
                        sprintf_s(stmt_buf,sizeof stmt_buf,"DELETE FROM %s:ca_change_ins \
                                           WHERE idealer= ? and icar_type=? AND imultiple=? \
                                             AND mcover_ori=? AND mcover_new1=? \
                                             AND mcover_new2=? AND dplybgn_yymm = ? \
                                             AND dplyend_yymm = ? AND dupdate = ?",list[j].dbname);
                        $PREPARE u2_id FROM $stmt_buf;
                        if(SQLCODE != 0)
                        {
                            is_upd_fail = 3;
                            break;
                        }
                        $EXECUTE u2_id USING $dealer, $car_type,$limit,
                                             $old_mcover_ori,$old_mcover_new1,$old_mcover_new2,
                                             $old_dplybgn_yymm,$old_dplyend_yymm,$old_dupdate;
                        if(SQLCODE != 0)
                             is_upd_fail = 3;
                        break;
                        
                    case 'U':
                         sprintf_s(stmt_buf, sizeof stmt_buf,
                            "update %s:ca_change_ins "
                            "   set (mcover_ori,mcover_new1,mcover_new2,dplybgn_yymm, dplyend_yymm,"
                            "       iupdate, dupdate) = (?,?,?,?,?,?,current) "
                            " where idealer = ? and icar_type = ? and imultiple = ? "
                            "   and mcover_ori = ? and mcover_new1 = ? "
                            "   and mcover_new2 = ? and dplybgn_yymm = ? "
                            "   and dplyend_yymm = ? and dupdate = ? ",list[j].dbname);

                        $PREPARE u3_id FROM $stmt_buf;
                        $EXECUTE u3_id USING $mcover_ori,$mcover_new1,$mcover_new2, $dplybgn_yymm,$dplyend_yymm,$userid,
                                             $dealer, $car_type,$limit,
                                             $old_mcover_ori,$old_mcover_new1,$old_mcover_new2,
                                             $old_dplybgn_yymm,$old_dplyend_yymm,$old_dupdate;
                        if(SQLCODE != 0)
                            is_upd_fail = 3;
                            break;

                    default:
                        $WHENEVER SQLERROR CONTINUE;
                        $ROLLBACK WORK;
                        if(exitsub(reply,M_CM_WRONG_OPTION) == True)
                           return M_CM_WRONG_OPTION;
                        else
                           return apiRC;
                }
            } /* end for (k = 0... */

            if (is_upd_fail == 3)
            {
                is_upd_fail = 1;
                break;
            }
        } /* for loop */

        free((char *) alist);
        if( is_upd_fail ==1) goto errexit;

        cm_buf_init(ReplyBuf);
        cm_buf_put("%l",M_CM_OK);
        tmp_len = cm_buf_len(ReplyBuf);
        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return apiRC;
        }

        $WHENEVER SQLERROR GOTO errexit;
        $COMMIT WORK;
        return api_OKComplete;
    }
    else
    {
        if(exitsub(reply,M_CM_WRONG_OPTION) == True)
           return M_CM_WRONG_OPTION;
        else
           return apiRC;
    }

errexit:
    $WHENEVER SQLERROR CONTINUE;
    MsgCode = SQLCODE;
    $ROLLBACK WORK;
    if (SQLCODE != 0) MsgCode = SQLCODE;
    if(exitsub(reply,MsgCode) == True)
        return MsgCode;
    else
        return apiRC;
}