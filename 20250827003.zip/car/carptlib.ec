/***********************************************************************
*	program id   : carptlib.ec                                     *
*	program name : �����C�Lon_line�@��function                     *
*	date written : 2011/05/20                                      *
*	editor       : Jessie                                          *
************************************************************************
*			MODIFICATION LOG			       *
*                                                                      *
*    DATE         SE           DESCRIPTION                             *
*  --------  -------------  ----------------------------------------   *
*                                                                      *
***********************************************************************/

#include <stdio.h> 
#include <string.h>
#include <decimal.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "cusmsgs.h"
#include "sqlfatal.h"
$include sqlca;
$include carest.h;
#include "safeclib.h"

/* *** Message block *** */
#define SUCCESS                 1
#define TURE                    1
#define true                    1
#define FALSE                   0
#define FAIL                    0
#define FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND
#define EQUAL(s1,s2)            !strcmp(s1,s2)
#define NOT_EQUAL(s1,s2)        strcmp(s1,s2)
FILE *fptr;
FILE  *fp0;
FILE  *fp1;
FILE  *fp2; 
FILE  *fp3;
FILE  *fp4;
FILE  *sfp;

char  sPlinetxt[3000+1];
static  char  *bp;
int	itype;
char equip97[2];
$char  sPassPrint[2];	/* �����I����i�_�C�L */
$int iCountDeny=0;
/* ��O�B�n */
$int ProtectData=0,Check_EB=0;
$char iassured_pt[13],iapplicant_pt[13],itel_pt[21],itel_night_pt[21];
$char itel_appl_pt[21],mobil_phone_pt[21],itag_pt[CA_TAG_NUM],nleader[11];

$char fequipment1[2],fequipment2[2],fequipment3[2],fequipment4[2],fequipment5[2];
$char fequipment6[2],fequipment9[2],nequipment9[101],outfit_nequipment[101];

$double  punknown_acc=0;
$char 	 iquery_num_unknown[121];

int   count_db=0,k=0;
DBinfo *list;

$char tablePly[64], tableRelation[64], tableInsType[64], tablePaPly[64], tableAssured[64];

int IsFcomp24();
int IsFcomp55();
$int deduct_30=0;
$int deduct_301=0;
$char tmp_deduct_30[20],str_ins_30[200];
$char tmp_deduct_301[20];
/*1060426011_C1_CAR320,CAR322 �ק�30��301�I�ئC�L�n�O�ѳ������r*/
$char iins_type30_301[7],iins_type24[7],iins_type55[7];
int flag30_301=0,flag24=0,flag55=0,flag255=0,flag49117=0,flag555=0;
/*****************************************************************/

$int provision_J=0;
$char feply[2],aemail_eply[51],fecard[2],feterms[2];

/* 1120316006_SC5_�L��-���N�I���e�{�s�W���@�������������O�N��05�ή��s�X��t�ηs�W���@�����O */
$int  flag_ambulance55=0;
$char fambulance_55[2];

/* 1120927002_C12_�R�q�ΰӫ~�}�o(�L��) */
$char dinstall[11],isequence[31],ainstall_zip[7],ainstall[91];

long carptlib(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
   long	rtncode;
   long	select_estimate_data();			/* A1 */
   /* long	select_estins_data();*/		/* A2 */
   long	select_estins_data_1();			/* A2 */
   long	select_ori_data();				/* B1 */
   /* long	select_ori_ins_data();*/	/* B2 */
   long	select_ori_ins_data_1();		/* B2 */
   long	select_ply_data();				/* C1 */
   long	select_ply_ins_data_1();		/* C2 */
   long select_autoply_data();			/* E1 */
   long select_autoply_ins_data_1();
   char	option[3];

	
   cm_buf_init(command);
   cm_buf_get("%s",&option);

   itype = *(option+1)-'0';
   ProtectData = 0;
   Check_EB = 0;

   printf("option[0][%c]\n",option[0]);

   switch(*option)
   {
	case 'A':	/* �n�O�Ѹ��(�q�պ��ɨ��o) */
	   switch(itype)
	   {
    		case 1:
    		case 3:
    		       rtncode=select_estimate_data(reply);   /* �n�O�ѥD�� */
    		       $drop table tmp_estimate;
                break;

    		case 2:
    		       rtncode=select_estins_data_1(reply);     /* �n�O���I���� */
    		break;
    	    }
	break;   /* end case A */

	case 'B':   /* ��O�n�O�Ѹ��(�q��l�O���ɨ��o) */
	   switch(itype)
	   {
		case 1:
            		rtncode=select_ori_data(reply);             /* �n�O�ѥD�� */
                        $drop table tmp_policy;
		break;

		case 2:
 		        rtncode=select_ori_ins_data_1(reply);    /* �n�O���I���� */
                break;
	   }
	break;    /* end case B */

	case 'C':  /* ��O�n�O�Ѹ��(�q�̷s�O���ɨ��o) */
			
	   switch(itype)
	   {
		case 1:
            	        rtncode=select_ply_data(reply);             /* �n�O�ѥD�� */
                        $drop table tmp_policy;
		break;

		case 2:
 		        rtncode=select_ply_ins_data_1(reply);    /* �n�O���I���� */
                break;
	   }
	break;    /* end case C */
	      	    
	case 'E':  /* �۰ʥX����O�n�O�Ѹ��(�q�̷s�O���ɨ��o) */
			
	   switch(itype)
	   {
		case 1:
			Check_EB = 0;
            	        rtncode=select_autoply_data(reply);      /* �۰ʥX��n�O�ѥD��(�DEB) */
                        $drop table tmp_policy;
		break;

		case 2:
			Check_EB = 1;
 		        rtncode=select_autoply_data(reply);	 /* �۰ʥX��n�O�ѥD��(EB) */
 		        $drop table tmp_policy;
                break;
	   }
	break;    /* end case E */

	case 'R':   /* ��O�n�O�Ѹ��(�q��O�J�p�ɨ��o) */
                rtncode=select_ply302_data(reply);             /* �n�O�ѥD�� */
                $drop table tmp_policy;
                $drop table tmp_policy2;
	break;

	default :
		if (exitsub(reply,M_CM_WRONG_OPTION) == True)
		   return M_CM_WRONG_OPTION;

		   return apiRC;
   }
   printf("=== rtncode=[%d] === \n",rtncode);
   return(rtncode);
}
/***********************************************************************
*   Name : select_estimate_data                                        *
*                                                                      *
*   Description : Select estimate      �Ѽ�:iestimate �պ⸹           *
***********************************************************************/
long select_estimate_data(reply)
serverReply reply;
{
   $char	DBName[5],iest_bgn[21],iest_end[21], sTmpProv[2], sNprovD[101];
   $char	stmt[5000],stmt1[2048],stmt2[2048],stmt3[1024],stmt4[500],stmt5[1000],stmt6[2000],stmt7[2000],stmt8[2000],stmt9[1000];
   $char	stmt_last[1024],FullDB[41],sTmpDB[41];
   $struct	estimate	Est;
   $struct	est_ins_assured	Assured;
   $char        tmobile_appl[21],aemail_appl[51];
   $char	iestimate_list[21],iins_type_list[7],iinsurant_list[11],ninsurant_list[31],dbirth_list[11],nbeneficiary_list[31],relation_bene_list[2],tbenef_list[21],abenef_list[91];
   $char	Fcar_class[2],Ncode[11],Nname[11],Nchi_abv[13];
   $char	Nquota[11],Fcard_class[2],LastOff1[21],LastOff2[21];
   $char        tmp_est1[21], tmp_officer[11], sBarcode_type[9];
   int	        i=0,rc=0, icount1=0, rc1=0;
   int	        tmp_len=0;
   time_t       now;
   char         FullGetName[101], filename[31];
   char         sTmp0[71], sTmp1[71], sTmp2[71], file0[71], file1[71], file2[71], file4[71],sTmp3[71],sTmp4[71];
   char         rptstr_main[10000], rptstr_dtl[10000];
   char         sApHome[31], sGetFileName[101], sFullFileName[201], sTmpTableName[101];
   char         sUserid[11];
   char         *token, *s1;
   $int         iCount2=0, Count_01=0, Count_05=0, Count_85=0;
   $double      dblDdmg_acc=0, dblDdmg_acc2=0, dblDdmg_acc3=0;
   $int         iQdmg_acc_sum=0, iQdmg_acc_sum2=0, iQdmg_acc_sum3=0;
   $char        Squery_num_damage[121], Squery_num_damage2[121], Squery_num_damage3[121];
   $char        sDmgNumber[121],sMsg[100];
   long         rtn=0;

   $char        sIroute4[5], Remind[128], Remind1[41], Remind2[41];
   $int         CntIroute=0, mprem=0, polciy302_ori_mprem=0;
   $char        sIcomm_obj[11];
   $char        ninsType[19], sNins_type[128];
   $char        chk_today[2],fchk_dbegin[2];
   $char        dmgflag_A[2],dmgflag_B[2],dmgflag_C[2],dmgflag_D[2],dmgflag_38[2],dmgflag_39[2];
   $char        dmgflag_302_A[2],dmgflag_302_B[2],dmgflag_302_C[2],dmgflag_302_D[2],dmgflag_302_38[2],dmgflag_302_39[2];
   $int         tmpCount=0;
   
   $char        sIply_302_V[21], sIinsType_302[7];
   $int         count_plicy302=0, countCheck_302=0, v_ori_prem=0, cnt_diff=0;
   $int         sMcover_limit=0;
   $char        sIassured_cntry[2], sIapplicant_cntry[2];
   $char        Funknown_dmg[2];
   $char        sIleader[11];
   $char        sFapplicant[2];
   $char        bound[255];
   $char        stmt_iregno[1024],Nreg_no[11],Nreg_no2[22];
   $char        stmt_occup1[1024],stmt_occup2[1024],noccup_fullname[126],applicant_noccup_fullname[126];
   $char        fchk_24[2];
   $char        iLastRelative_ply1[21],iLastRelative_ply2[21];
   $char        *ptr1;
   $int         qviolate = 0;
   $char        f20230601[2];
   
   strcpy(fchk_24," ");
   strcpy(f20230601," ");
   
   /*���[���ڴڻ�����r*/
   $char iprov_all[200],iprov[10],sprov[5],sprov_all[500],sprov_note[50],sprov_note_all[500],iins_prov[7];

   cm_buf_get("%s %s %s %s %s",DBName,iest_bgn, iest_end, sGetFileName, sUserid);
   int     recLen=1024;
   $int  iCount1;
   
   /* 1071107007_SC2_UBI�{���W�u */
   $double nmile_ubi = 0.0,pubi_acc = 0.0;
   
   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
   {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
         return M_CM_DB_NOTOPEN;
      else
         return apiRC;
   }

   rc = getApHome(sApHome);
   if (rc < 0)
   {
      printf("read Config file error!!\n");
      return exitsub(reply,M_CM_READ_CONFIG_ERR) ? M_CM_READ_CONFIG_ERR : apiRC;
   }
   printf("sGetFileName=[%s]\n",sGetFileName);
   
   /* �B�n�P�_ A3*/
   if (itype == 3)
   	ProtectData = 1;
   else 
   	ProtectData = 0;

   printf("ProtectData[%d]\n",ProtectData);


   /* �إ�tmp table */
   $select iestimate, iofficer1
         from estimate where 1=0 into temp tmp_estimate with no log;

   /* ���ǤJ�ɮ�,Ū���ɮפ��e */
   if (strlen(trim(sGetFileName)) > 0)
   {

       /* Ū�ɨüg�Jtmp table */
       sprintf_s(sFullFileName, sizeof sFullFileName, "%s/dat/car/%s", sApHome, sGetFileName);

       printf("sFullFileName=[%s]\n",sFullFileName);




       if ((fptr=fopen(sFullFileName,"rt"))==NULL)
       {
           return 0;
       }

       if ((bp=malloc(recLen))==NULL)
       {
           printf("System malloc failed  !\n");
           free(bp);
           return FAIL;
       }

       while(fgets(bp,recLen,fptr))
       {

           if (feof(fptr)) break;
           i = 0;
           /* ��l�ưѼ� ---------------------------------------------------- */
           memset(tmp_est1, 0x00, sizeof(tmp_est1));
           memset(tmp_officer, 0x00, sizeof(tmp_officer));
           /* --------------------------------------------------------------- */
           token = strtok(bp,"\t");
           printf("token=[%s],strlen(token)=[%d]\n",token,strlen(token));
           while (token != NULL)
           {
               i ++;
               printf("The token[%d] is:[%s]\n", i, token);

               if (i == 1)
               {
                  printf("---- �պ⸹ ---- \n");
                  strcpy(tmp_est1, rtrim(token));    /* �պ⸹ */
                  printf("tmp_est1=[%s]\n",tmp_est1);
               }
               else if(i==2)
               {
                  printf("---- �g��N�� ---- \n");
                  strcpy(tmp_officer, rtrim(token));     /* �g��N�� */
                  printf("1:tmp_officer=[%s]strlen(token)=[%d]\n",tmp_officer,strlen(token));
                  if (strstr(tmp_officer, "\r\n") == NULL)
                  {
                        printf("2:tmp_officer=[%s]\n",tmp_officer);
                  }
                  else
                  {
                        printf("3:tmp_officer=[%s]\n",tmp_officer);
                        tmp_officer[strlen(tmp_officer)-2]='\0';
                        printf("4:tmp_officer=[%s]\n",tmp_officer);
                  }
                  printf("5:tmp_officer=[%s]\n",tmp_officer);
               }
               else
               {
                  printf("---- other ---- \n");
               }
               token = strtok(NULL,"\t");
           }

           if (i < 2)
           {
               $drop table tmp_estimate;
               fclose(fptr);
               SQLCODE = -846;
               return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
           }
           /* �g�J����table */
           printf(" �g�J����table === start \n");
           $insert into tmp_estimate
            ( iestimate, iofficer1)
            values
            ( $tmp_est1, $tmp_officer);
           printf("tmp_est1=[%s]tmp_officer=[%s]\n",tmp_est1,tmp_officer);
           printf(" �g�J����table === end sqlcode=[%d] \n",SQLCODE);
       }
       fclose(fptr);

       printf("Ū�ɧ���!! \n");
   }

   iCount1 = 0;
   Count_01 = Count_05 = Count_85 = 0;
   CntIroute = mprem = polciy302_ori_mprem = 0;
   $select count(*) into $iCount1 from tmp_estimate ;

   printf("-------iCount1=[%d]\n",iCount1);

   time(&now);
   sprintf_s(sTmp0, sizeof sTmp0,"application_%s%s%ld.txt",DBName,sUserid,now);
   sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,sTmp0);
   fp0=fopen(file0,"w");

   sprintf_s(sTmp1, sizeof sTmp1,"application_%s%s%ld_dtl.txt",DBName,sUserid,now);
   sprintf_s(file1, sizeof file1,"%s/rptftp/%s",sApHome,sTmp1);
   fp1=fopen(file1,"w");

   sprintf_s(sTmp2, sizeof sTmp2,"application_%s%s%ld_provD.txt",DBName,sUserid,now);
   sprintf_s(file2, sizeof file2,"%s/rptftp/%s",sApHome,sTmp2);
   fp2=fopen(file2,"w");

   sprintf_s(sTmp4, sizeof sTmp4,"application_%s%s%ld_list.txt",DBName,sUserid,now);
   sprintf_s(file4, sizeof file4,"%s/rptftp/%s",sApHome,sTmp4);
   fp4=fopen(file4,"w");
   
	 /* �s�W�C�L[�Q�O�I�H���k�H�N���H]�B[�n�O�H���k�H�N���H]�B[�n�O�H�P�Q�O�I�H���Y]
	    �B[�n�O�H�ʧO]�B[�n�O�HID]�B[�n�O�H�ͤ�]�B[�n�O�H�q��]������ơC
	    add by sylvia 101.08.21 (1010810004_C1) */

   if (strncmp(iest_bgn+6,"X",1)==0) /* ���`�� */
   { 
	strcpy(stmt1,
	       "select a.iabnormal,a.iins_card,a.icomp_card,a.irelative_ply, "
	             " a.ilast_ply,a.ilast_card,a.irelative_card,a.ixxcard, "
                     " a.dbegin,a.dend,a.dcomp_begin,a.dcomp_end, "
	             " a.fassured,a.iassured,a.iassured_ext,a.nassured, "
                     " a.ilicense,a.dbirth,a.fsex,a.fmarriage, "
                     " a.nuser,a.ibenef,a.nbenef,a.aassured, "
	             " a.aassured_zip,a.itel,a.itel_night,a.mobil_phone, "
                     " a.apayment,a.apayment_zip,a.iply_area,a.dissue, "
                     " a.ipro_year || '/' || a.qpro_month::CHAR(2),a.ibrand,a.nbrand_abbr,a.icar_type2, "
                     " a.icar_type1,a.ncar_abbr,a.fcar_note2,a.qcylinder, "
                     " a.iengine,a.ibody,a.itag,a.mcar_price, "
                     " a.pdmg_align,a.pbrg_align,a.plia_align,a.mdali_prem, "
                     " a.mcomp_prem,a.ibig_comp,a.ibig_branch,a.ibig_office, nvl(a.qprovision,0), "
                     " a.feply,a.fecard,a.aemail_eply, case when a.dbegin < '07/01/2019' then 'Y' else 'N' end,"
                     " case when a.dbegin >= '06/01/2023' then 'Y' else 'N' end, ");

        if (strlen(trim(sGetFileName)) > 0)
        {
            sprintf_s(stmt4, sizeof stmt4, "where a.iabnormal in \
                            (select upper(iestimate) from tmp_estimate) \
                            and decode(trim(a.iofficer2),'',a.iofficer1,a.iofficer2) = \
                            (select upper(iofficer1) from tmp_estimate where upper(iestimate) = a.iabnormal) " );
        }
        else
        {
            sprintf_s(stmt4, sizeof stmt4, "where a.iabnormal between '%s' and '%s' ",
                           iest_bgn, iest_end);
        }

        sprintf_s(stmt3, sizeof stmt3,"%s %s %s %s %s %s %s %s",
	              " from newa00:abnormal_ply a,outer car_type b,outer officer c, ",
                      " outer broker_agent d, outer broker_agent e ", stmt4,
                      " and a.icar_type2 = b.icode ",
                      " and b.fclass = '1' ",
                      " and a.iofficer2 = c.iofficer ",
                      " and a.icomm_obj2 = d.ibroker ",
                      " and a.ibroker2 = e.ibroker;");

        /* �����p�O�W�U�ɸ�� add by sylvia 101.06.21 */
        strcpy(stmt5,"select iabnormal, iins_type, provision, iassured, nassured,\
                             dbirth, nbenef, rel_benef, iserial \
                      from newa00:abn_ply_ins_assured where iabnormal = ? ");
   }
   else /* �պ��� */
   {	
   	
        strcpy(stmt1,
	      "select a.iestimate,a.icard2,a.icard1,a.irelative_ply, "
                    " a.ilast_ply,a.ilast_card,a.irelative_card,a.ixxcard, "
                    " a.dply2_begin,a.dply2_end,a.dply1_begin,a.dply1_end, "
                    " a.fassured,a.iassured,a.iassured_ext,a.nassured, "
                    " a.ilicense,a.dbirth,a.fsex,a.fmarriage, "
                    " a.nuser,a.ibenef,a.nbenef,a.aassured, "
                    " a.aassured_zip,a.itel,a.itel_night,a.mobil_phone, "
                    " a.apayment,a.apayment_zip,a.iply_area,a.dissue, "
                    " a.ipro_year || '/' || a.qpro_month::CHAR(2),a.ibrand,a.nbrand_abbr,a.icar_type2, "
                    " a.icar_type1,a.ncar_abbr,a.fcar_note2,a.qcylinder, "
                    " a.iengine,a.ibody,a.itag,a.mcar_price, "
                    " a.pdmg_align,a.pbrg_align,a.plia_align,a.mpremium2, "
                    " a.mpremium1,a.ibig_comp,a.ibig_branch,a.ibig_office, nvl(a.qprovision,0), "
                    " a.feply,a.fecard,a.aemail_eply, case when a.dply2_begin < '07/01/2019' then 'Y' else 'N' end,"
                    " case when a.dply2_begin >= '06/01/2023' then 'Y' else 'N' end,");
        if (strlen(trim(sGetFileName)) > 0)
        {
            sprintf_s(stmt4, sizeof stmt4, "where a.iestimate in \
                           (select upper(iestimate) from tmp_estimate) \
                           and decode(trim(a.iofficer2),'',a.iofficer1,a.iofficer2) = \
                           (select upper(iofficer1) from tmp_estimate where upper(iestimate) = a.iestimate) " );
        }
        else
        {
            sprintf_s(stmt4, sizeof stmt4, "where a.iestimate between '%s' and '%s' ",
                           iest_bgn, iest_end);
        }

        sprintf_s(stmt3, sizeof stmt3, "%s %s %s %s %s %s %s %s",
                       " from estimate a,outer car_type b,outer officer c, ",
                       "outer broker_agent d, outer broker_agent e ", stmt4,
                       "  and a.icar_type2 = b.icode ",
                       "  and b.fclass = '1' ",
                       "  and a.iofficer2 = c.iofficer ",
                       "  and a.icomm_obj2 = d.ibroker ",
                       "  and a.ibroker2 = e.ibroker;");

        strcpy(stmt5,"select iestimate, iins_type, provision, iassured, nassured,\
                             year(dbirth)-1911||to_char(dbirth,'/%m/%d'), \
                             nbenef, rel_benef, iserial \
                        from est_ins_assured where iestimate = ? ");
 
   }

   strcpy(stmt2,
	       " a.ibig_sales,a.iresource,a.fdiscount,a.ibroker2, "
               " a.ibroker1,a.iofficer2,a.iofficer1,a.icorps, "
               " a.iarea,a.icashier,a.iexaminer,a.dexamine, "
               " (select m.nname from officer m where m.iofficer = a.ientry), "
               " a.dentry,a.dapply,a.fcal_way, "
               " a.ipolicy1,a.ipolicy2 ,a.idmg_rate,a.pdmg_factor, "
               " a.ibrg_rate,a.pbrg_factor,a.ibranch,a.qpt, "
               " a.fpt,a.psex_age2,a.psex_age1,a.psex_age_damage,a.lia_class, "
               " a.plia_acc2,a.plia_acc1,a.dmg_acc_1st,a.dmg_acc_2nd, "
               " a.dmg_acc_3rd, a.fhuman,a.fcomp_24, "
               " a.mbus_rule,a.mbusiness,a.fcomp_class,a.fcomp_class_last, "
               " a.iemail,a.iquery_num_c,a.iquery_num , "
               " b.fcar_class,b.ncode,c.nname,nvl(d.nchi_abv,e.nchi_abv), "
               " a.napplicant,a.mequipment,a.iroute, a.iroute_prop, "
               " a.iroute_comm2, a.qlia_acc_sum,  "
               " a.ndeputy_assured, a.ndeputy_appl, a.nrelation_appl, a.fsex_appl, "
               " a.fapplicant, a.iapplicant, a.dbirth_appl, a.itel_appl, a.qdrunk_driving, "
               " a.nequipment, a.fuw_status, a.iaccept, a.iroute[1,4], a.icomm_obj1, "
               " a.icomm_obj2, a.mcover_limit, a.iassured_cntry, a.iapplicant_cntry, "
               " a.fequipment1,a.fequipment2,a.fequipment3,a.fequipment4, "
               " a.fequipment5,a.fequipment6,a.fequipment9,a.nequipment9, "
               " CASE WHEN a.funknown_dmg = '4' THEN a.punknown_acc WHEN a.funknown_dmg = '5' THEN a.punknown_acc2 ELSE 0.00 END , "
               " CASE WHEN a.funknown_dmg = '4' THEN a.iquery_num_unknown WHEN a.funknown_dmg = '5' THEN a.iquery_num_unknown2 ELSE ' ' END, "
               " a.foccup,a.noccup,a.applicant_foccup,a.applicant_noccup,a.nmile_ubi,a.pubi_acc,a.tmobile_eply,a.tmobile_appl,a.aemail_appl,a.feterms,a.qviolate, "
               " dinstall,isequence,ainstall_zip,ainstall ");

   strcpy(stmt,rtrim(stmt1));
   strcat(stmt,rtrim(stmt2));
   strcat(stmt,rtrim(stmt3));

   printf("[%d]stmt1=[%s]\n\n", strlen(stmt1),stmt1);
   printf("[%d]stmt2=[%s]\n\n", strlen(stmt2),stmt2);
   printf("[%d]stmt3=[%s]\n\n", strlen(stmt3),stmt3);
   printf("[%d]stmt=[%s]\n\n", strlen(stmt),stmt);


   icount1 = 0;
   $PREPARE  per1 FROM $stmt;
   $DECLARE  cur1 CURSOR FOR per1;
   $OPEN     cur1;
   while(1)
   {
       printf("--------------------------------4427-----------------------\n");
       $FETCH cur1 INTO
            $Est.iestimate,$Est.icard2,$Est.icard1,$Est.irelative_ply,
            $Est.ilast_ply,$Est.ilast_card,$Est.irelative_card,$Est.ixxcard,
            $Est.dply2_begin,$Est.dply2_end,$Est.dply1_begin,$Est.dply1_end,
            $Est.fassured,$Est.iassured,$Est.iassured_ext,$Est.nassured,
            $Est.ilicense,$Est.dbirth,$Est.fsex,$Est.fmarriage,
            $Est.nuser,$Est.ibenef,$Est.nbenef,$Est.aassured,
            $Est.aassured_zip,$Est.itel,$Est.itel_night,$Est.mobil_phone,
            $Est.apayment,$Est.apayment_zip,$Est.iply_area,$Est.dissue,
            $Est.ipro_year,$Est.ibrand,$Est.nbrand_abbr,$Est.icar_type2,
            $Est.icar_type1,$Est.ncar_abbr,$Est.fcar_note2,$Est.qcylinder,
            $Est.iengine,$Est.ibody,$Est.itag,$Est.mcar_price,
            $Est.pdmg_align,$Est.pbrg_align,$Est.plia_align,$Est.mpremium2,
            $Est.mpremium1,$Est.ibig_comp,$Est.ibig_branch,$Est.ibig_office, $Est.qprovision,
            $feply,$fecard,$aemail_eply,$fchk_24,$f20230601,
            $Est.ibig_sales,$Est.iresource,$Est.fdiscount,$Est.ibroker2,
            $Est.ibroker1,$Est.iofficer2,$Est.iofficer1,$Est.icorps,
            $Est.iarea,$Est.icashier,$Est.iexaminer,$Est.dexamine,
            $Nquota,$Est.dentry,$Est.dapply,$Est.fcal_way,
            $Est.ipolicy1,$Est.ipolicy2 ,$Est.idmg_rate,$Est.pdmg_factor,
            $Est.ibrg_rate,$Est.pbrg_factor,$Est.ibranch,$Est.qpt,
            $Est.fpt,$Est.psex_age2,$Est.psex_age1,$Est.psex_age_damage,
            $Est.lia_class,$Est.plia_acc2,$Est.plia_acc1,$Est.dmg_acc_1st,
            $Est.dmg_acc_2nd,$Est.dmg_acc_3rd,$Est.fhuman,
            $Est.fcomp_24,$Est.mbus_rule,$Est.mbusiness,$Est.fcomp_class,
            $Est.fcomp_class_last,$Est.iemail,$Est.iquery_num_c,
            $Est.iquery_num ,
            $Fcar_class,$Ncode,$Nname,$Nchi_abv,
            $Est.napplicant,$Est.mequipment,$Est.iroute, $Est.iroute_prop,
            $Est.iroute_comm2,$Est.qlia_acc_sum,
            $Est.ndeputy_assured, $Est.ndeputy_appl, $Est.nrelation_appl, $Est.fsex_appl,
            $sFapplicant, $Est.iapplicant, $Est.dbirth_appl, $Est.itel_appl, $Est.qdrunk_driving,
            $Est.nequipment, $Est.fuw_status, $Est.iaccept, $sIroute4,
            $Est.icomm_obj1, $Est.icomm_obj2, $sMcover_limit , $sIassured_cntry, $sIapplicant_cntry,
            $fequipment1, $fequipment2, $fequipment3, $fequipment4,
            $fequipment5, $fequipment6, $fequipment9, $nequipment9,
            $punknown_acc, $iquery_num_unknown, 
            $Est.foccup, $Est.noccup, $Est.applicant_foccup, $Est.applicant_noccup,
            $Est.nmile_ubi, $Est.pubi_acc, $Est.tmobile_eply, $tmobile_appl, $aemail_appl, $feterms, $qviolate,
            $dinstall, $isequence, $ainstall_zip, $ainstall;
            
       if(SQLCODE == SQLNOTFOUND)
          break;
      
       /*** 1050711006_C1_�ק�CAR320�w�ﭭ�O�~�Ȥ��ˮ� ***/
       /*** �����O����B01�B���q�L�֫O�T�{�A���i�C�L�n�O�� ***/
       if (strncmp(iest_bgn+6,"X",1)!=0)
       {
      	   rc = chk_car_bound( Est.iestimate, bound);
      	   if( rc != M_CM_OK) return rc;
      
      	   printf("bound[%s]\n",bound);
      	   if((strstr(bound,"B01") != NULL) && Est.fuw_status < 500)
      	       continue;
       }



       /* �s�W�Ӹ��ˮ�   add by sylvia 103.02.14 (1020924002_C2) */
       iCountDeny=0;
       $select count(*) into $iCountDeny
          from cm_personal_deny
         where iassured = $Est.iassured
           and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
           and ddeny <= today
           and (dexpire is null or dexpire >= today);
       if(iCountDeny > 0)
           continue;
         
       if(strlen(trim(Est.iofficer2))!=0)
       {
           $SELECT b.nname,a.ileader
	      INTO $nleader,$sIleader
	      FROM officer a,officer b
             WHERE b.iofficer = a.ileader
               AND a.iofficer = $Est.iofficer2;
	        
	      if(SQLCODE == SQLNOTFOUND)
	      		strcpy(nleader," ");
       }
       else
       {
	   $SELECT b.nname,a.ileader
	      INTO $nleader,$sIleader
	      FROM officer a,officer b
	     WHERE b.iofficer = a.ileader
	       AND a.iofficer = $Est.iofficer1;
	        
	   if(SQLCODE == SQLNOTFOUND)
	       strcpy(nleader," ");
       }
         
/*
      if(strlen(trim(Est.ipolicy1))!=0)
      {
      	$select ileader
      	   into $sIleader
      	   from officer
      	  where iofficer = $Est.iofficer1;
      	
      	if(SQLCODE == SQLNOTFOUND)	strcpy(sIleader," ");
      	
      	strcpy(sIleader,trim(sIleader));      	  

      	/* �O�������ˮ�(�j��) 
      	if (strcmp(sIleader,sUserid) != 0)
      	{
      		rtn = chk_spec_deny( Est.ipolicy1, Est.icard1, Est.iassured, Est.iapplicant, Est.itag, Est.iengine, sMsg);
      		if (rtn == M_CA_SPEC_DENY)
         		continue;
        }
      }

      if(strlen(trim(Est.ipolicy2))!=0)
      {
      	$select ileader
      	   into $sIleader
      	   from officer
      	  where iofficer = $Est.iofficer2;
      	
      	if(SQLCODE == SQLNOTFOUND)	strcpy(sIleader," ");
      	
      	strcpy(sIleader,trim(sIleader));

      	/* �O�������ˮ�(���N) 
      	if (strcmp(sIleader,sUserid) != 0)
      	{
      		rtn = chk_spec_deny( Est.ipolicy2, Est.icard2, Est.iassured, Est.iapplicant, Est.itag, Est.iengine, sMsg);
      		if (rtn == M_CA_SPEC_DENY)
         		continue;	
      	}
      }
*/

       printf("--------------------------------464-----------------------\n");
       icount1++;
       /*-----------------*/
       /* �����¦����s�A�������I�����{���]�w(137�B138�B139�B141�B142�I��) (1100311005_SC6)*/
       /* ���`�� */
       if (strncmp(Est.iestimate+6,"X",1)==0)
       {
           $select pdmg_acc, pdmg_acc2, pdmg_acc3,
      	           qdmg_acc_sum, qdmg_acc_sum2, qdmg_acc_sum3,
      	           iquery_num_damage, iquery_num_damage2, iquery_num_damage3,
      	           funknown_dmg,
      	           (select count(iins_type) from newa00:abn_ply_ins_type x
      	         	  where x.iabnormal = w.iabnormal and iins_type in ('01','08','122','201')),
      	           (select count(iins_type) from newa00:abn_ply_ins_type y
      	         	  where y.iabnormal = w.iabnormal and iins_type in ('05','09','120','125','126','205','209')),
      	           (select count(iins_type) from newa00:abn_ply_ins_type z
      	         	  where z.iabnormal = w.iabnormal and iins_type in ('85','105','118'))
      	      into $dblDdmg_acc, $dblDdmg_acc2, $dblDdmg_acc3,
      	           $iQdmg_acc_sum, $iQdmg_acc_sum2, $iQdmg_acc_sum3,
      	           $Squery_num_damage, $Squery_num_damage2, $Squery_num_damage3,
      	           $Funknown_dmg,
      	           $Count_01,$Count_05,$Count_85
      	      from newa00:abnormal_ply w
      	     where w.iabnormal = $Est.iestimate;
       }
       else
       {
      	   $select pdmg_acc, pdmg_acc2, pdmg_acc3,
      	           qdmg_acc_sum, qdmg_acc_sum2, qdmg_acc_sum3,
      	           iquery_num_damage, iquery_num_damage2, iquery_num_damage3,
      	           funknown_dmg,
      	           (select count(iins_type) from est_ins_type x
      	         	  where x.iestimate = w.iestimate and iins_type in ('01','08','122','201')),
      	          (select count(iins_type) from est_ins_type y
      	         	  where y.iestimate = w.iestimate and iins_type in ('05','09','120','125','126','205','209')),
      	           (select count(iins_type) from est_ins_type z
      	         	  where z.iestimate = w.iestimate and iins_type in ('85','105','118'))
      	      into $dblDdmg_acc, $dblDdmg_acc2, $dblDdmg_acc3,
      	           $iQdmg_acc_sum, $iQdmg_acc_sum2, $iQdmg_acc_sum3,
      	           $Squery_num_damage, $Squery_num_damage2, $Squery_num_damage3,
      	           $Funknown_dmg,
      	           $Count_01,$Count_05,$Count_85
      	      from estimate w
      	     where w.iestimate = $Est.iestimate;
       }

       if (strlen(trim(Funknown_dmg)) != 0)
       {
      	   if (strcmp(Funknown_dmg,"4") == 0 || strcmp(Funknown_dmg,"5") == 0)
      	   {
	       Est.pdmg_acc = dblDdmg_acc2;
	       Est.qdmg_acc_sum = iQdmg_acc_sum2;
	       strcpy(Est.iquery_num_damage, trim(Squery_num_damage2));
      	   }
      	   else
      	   {
      	       if (strcmp(Funknown_dmg,"1") == 0)
	       {
	           printf("--------558 Funknown_dmg[%s] ------ \n",Funknown_dmg);
		   Est.pdmg_acc = dblDdmg_acc;
		   Est.qdmg_acc_sum = iQdmg_acc_sum;
		   strcpy(Est.iquery_num_damage, trim(Squery_num_damage));
	       }
	       else if (strcmp(Funknown_dmg,"2") == 0)
	       {
		   printf("--------565 Funknown_dmg[%s] ------ \n",Funknown_dmg);
		   Est.pdmg_acc = dblDdmg_acc2;
		   Est.qdmg_acc_sum = iQdmg_acc_sum2;
		   strcpy(Est.iquery_num_damage, trim(Squery_num_damage2));
	       }
	       else if (strcmp(Funknown_dmg,"3") == 0)
	       {
		   printf("--------572 Funknown_dmg[%s] ------ \n",Funknown_dmg);
		   Est.pdmg_acc = dblDdmg_acc3;
		   Est.qdmg_acc_sum = iQdmg_acc_sum3;
		   strcpy(Est.iquery_num_damage, trim(Squery_num_damage3));
	       }
	       else
	       {
		   printf("--------579 Funknown_dmg[%s] ------ \n",Funknown_dmg);
		   Est.pdmg_acc = 0.0;
		   Est.qdmg_acc_sum = 0;
		   strcpy(Est.iquery_num_damage, "���d��");
	       }
      	   }
       }
       else
       {
	   if (Count_01 > 0)
	   {
	       printf("-------- Count_01 ------ \n");
	       Est.pdmg_acc = dblDdmg_acc;
	       Est.qdmg_acc_sum = iQdmg_acc_sum;
	       strcpy(Est.iquery_num_damage, trim(Squery_num_damage));
	   }
	   else if (Count_05 > 0)
	   {
	       printf("-------- Count_05 ------ \n");
	       Est.pdmg_acc = dblDdmg_acc2;
	       Est.qdmg_acc_sum = iQdmg_acc_sum2;
	       strcpy(Est.iquery_num_damage, trim(Squery_num_damage2));
	   }
	   else if (Count_85 > 0)
	   {
	       printf("-------- Count_85 ------ \n");
	       Est.pdmg_acc = dblDdmg_acc3;
	       Est.qdmg_acc_sum = iQdmg_acc_sum3;
	       strcpy(Est.iquery_num_damage, trim(Squery_num_damage3));
	   }
	   else
	   {
	       printf("-------- Count_00 ------ \n");
	       Est.pdmg_acc = 0.0;
	       Est.qdmg_acc_sum = 0;
	       strcpy(Est.iquery_num_damage, "���d��");
	   }
       }
       /*-----------------*/
       printf("--427--Est.icar_type2=[%s]Est.icar_type1=[%s]\n",Est.icar_type2,Est.icar_type1);
       printf("--427--Est.Ncode=[%s]\n",Ncode);
       if (strlen(trim(Est.icar_type2)) == 0)
       {
           strcpy(Est.icar_type2, Est.icar_type1);
      	   $select ncode into $Ncode
      	      from car_type
             where fclass = '1'
      	       and icode = $Est.icar_type1;
       }
       printf("--435--Est.icar_type2=[%s]Est.icar_type1=[%s]\n",Est.icar_type2,Est.icar_type1);
       printf("--435--Est.Ncode=[%s]\n",Ncode);
       
       
       /* �e��j��Υ��N�g�� */
       strcpy(Fcard_class," ");
       strcpy(LastOff1," ");
       strcpy(LastOff2," ");

       if (strlen(rtrim(Est.ilast_ply))!=0) 
       {
           strcpy(FullDB,get_dtl_full_db(Est.ilast_ply));
   	   sprintf_s(stmt_last, sizeof stmt_last,
		   	    "select x.fcard_class,trim(x.iofficer) || y.nname, "
		            "       (select trim(a.iofficer)||b.nname "
		            "          from %s:ply_relation a, officer b "
		            "         where a.iofficer = b.iofficer "
		            "           and x.irelative_ply = a.ipolicy ) "
		            "  from %s:ply_relation x, outer officer y "
		            " where x.ipolicy = ? "
		            "   and x.iofficer = y.iofficer", FullDB,FullDB);

	   printf("stmt_last=[%s]\n", stmt_last);

	   $prepare pre_last from $stmt_last;
	   $execute pre_last
	       into $Fcard_class,$LastOff1,$LastOff2
	      using $Est.ilast_ply;
	   if (NOT_FOUND) 
	   {
	       strcpy(Fcard_class," ");
	       strcpy(LastOff1," ");
	       strcpy(LastOff2," ");
	       break;
	   }
       }
      
       /*�e��j����N�O�渹*/
       strcpy(iLastRelative_ply1,"");
       strcpy(iLastRelative_ply2,"");
       strcpy(stmt_last,"");
       if (strlen(rtrim(Est.ilast_ply))!=0) 
       {
           strcpy(FullDB,get_dtl_full_db(Est.ilast_ply));
   	   sprintf_s(stmt_last, sizeof stmt_last,
		   	    "select (CASE WHEN fcard_class ='1' THEN  ipolicy ELSE nvl(irelative_ply,'') end),"
		   	    "       (CASE WHEN fcard_class ='1' THEN nvl(irelative_ply,'')  ELSE ipolicy end)"
		            "  from %s:ply_relation  "
		            " where ipolicy = ? ", FullDB);

	   printf("stmt_last=[%s]\n", stmt_last);

	   $prepare pre_LastRelative1 from $stmt_last;
	   $execute pre_LastRelative1
	       into $iLastRelative_ply1,$iLastRelative_ply2 using $Est.ilast_ply;
	   if (NOT_FOUND) 
           {
	       strcpy(iLastRelative_ply1," ");
	       strcpy(iLastRelative_ply2," ");
	       break;
           }
      }
      
      
      provision_J = 0;
      $SELECT COUNT(*)
         INTO $provision_J
         FROM est_ins_type
        WHERE iestimate = $Est.iestimate
          and trim(nvl(provision,' '))||';' like '%J;%';

      /* �^�����w�r�p�H����(D���ڡ^�W�U  add by sylvia 101.06.21 */
      sNprovD[0]= '\0';
      if (Est.qprovision > 0 || provision_J > 0)
      {
          strcat(stmt5, " and (trim(nvl(provision,' '))||';' like '%D;%' or trim(nvl(provision,' '))||';' like '%J;%') ");
      	  /*strcpy(sNprovD, "���w�r�p�H�G");*/
      	  printf("stmt5=[%s]\n",stmt5);
      	  printf("Est.iestimate=[%s]\n",Est.iestimate);

      	  iCount2 = 0;
      	  strcpy(ninsType, "");
      	  strcpy(sNins_type, "");
      	  sprintf_s(stmt6, sizeof stmt6, "SELECT trim(a.iins_type)||(SELECT nins_abbr FROM insurance_type WHERE iins_type = a.iins_type) \
      	                    FROM est_ins_type a \
      	                   WHERE a.iestimate = '%s' \
      	                     AND (trim(nvl(a.provision,' '))||';' like '%%D;%%' or trim(nvl(a.provision,' '))||';' like '%%J;%%') ", Est.iestimate);
          $PREPARE  preProvD FROM $stmt6;
          $DECLARE  cur_provD CURSOR FOR preProvD;
          $OPEN     cur_provD;

          for(;;)
          {
              $FETCH cur_provD INTO $ninsType;
              if(SQLCODE == SQLNOTFOUND)  break;

              iCount2++;

              if (iCount2 == 1)
              {
            	  strcpy(sNins_type, trim(ninsType));
              }
              else
              {
            	  strcat(sNins_type, ";");
            	  strcat(sNins_type, trim(ninsType));
              }
          }
      	  $CLOSE  cur_provD;
	  $FREE   cur_provD;

	  $PREPARE  pre_provD FROM $stmt5;
	  $DECLARE  cur_provDE CURSOR FOR pre_provD;
	  $OPEN     cur_provDE USING $Est.iestimate;
	  while(1)
	  {
	      $FETCH cur_provDE INTO
	             $Assured.iestimate, $Assured.iins_type, $Assured.provision,
	             $Assured.iassured, $Assured.nassured, $Assured.dbirth,
	             $Assured.nbenef, $Assured.rel_benef, $Assured.iserial;
	      if(SQLCODE == SQLNOTFOUND)  break;
	            /*iCount2 ++;
	            strcat(sNprovD, rtrim(Assured.nassured));
	            if (iCount2 < Est.qprovision)
	            	strcat(sNprovD,"�B");
	            else
	            	strcat(sNprovD,"�C");*/
	      fprintf(fp2,"%s\t%s\t%s\t%s\t%s\n", trim(sNins_type),Assured.nassured,Assured.iassured,Assured.dbirth,Assured.iestimate);
	  }
	  $close     cur_provDE;
	  $free     cur_provDE;
      }/* �^�����w�r�p�H����(D���ڡ^�W�U  end ----------------------- */


      /* �^���r�p�H�ˮ`�W�U  1090221006_SC4_��_56�r�p�H�W�U */
      
      /* ���`�� */
      if (strncmp(Est.iestimate+6,"X",1)==0)
      {

          strcpy(stmt9,/* "SELECT a.iabnormal,a.iins_type,a.iassured,a.nassured,"
      	                "       CASE b.fassured WHEN '2' THEN '' WHEN '4' THEN '' WHEN '6' THEN ''  ELSE to_char(year(a.dbirth)-1911)||'/'||to_char(a.dbirth,'%m/%d') END ,"
      	                "       a.nbenef,a.rel_benef,a.tbenef,a.abenef "
                        "  FROM abn_ply_ins_assured a,abnormal_ply b "
                        " WHERE a.iabnormal=? AND a.iabnormal=b.iabnormal AND a.iins_type IN ('50') "
                        " UNION "*/
      	                "SELECT a.iabnormal,a.iins_type,a.iinsurant,a.ninsurant, "
      	                "       CASE b.fassured WHEN '2' THEN '' WHEN '4' THEN '' WHEN '6' THEN ''  ELSE to_char(year(a.dbirth)-1911)||'/'||to_char(a.dbirth,'%m/%d') END , "
      	                "       a.nbeneficiary,a.relation_bene,a.tbenef,a.abenef "
                        "  FROM newa00:abn_ca_pa_ply a,newa00:abnormal_ply b "
                        " WHERE a.iabnormal=? AND a.iabnormal=b.iabnormal AND a.iins_type IN ('56','136','266')"
                        " UNION "
                        "SELECT a.iabnormal,a.iins_type,a.iassured,a.nassured, "
                        "       CASE b.fassured WHEN '2' THEN '' WHEN '4' THEN '' WHEN '6' THEN ''  ELSE to_char(year(a.dbirth)-1911)||'/'||to_char(a.dbirth,'%m/%d') END , "
                        "       a.nbenef,a.rel_benef,a.tbenef,a.abenef "
                        "  FROM newa00:abn_ply_ins_assured a,newa00:abnormal_ply b "
                        " WHERE a.iabnormal=? AND a.iabnormal=b.iabnormal AND a.iins_type IN ('147','561') ");
      	  printf("stmt9=[%s]\n",stmt9);
      }
      else
      {
      	  strcpy(stmt9, /*"SELECT a.iestimate,a.iins_type,a.iassured,a.nassured,"
      	                "       CASE b.fassured WHEN '2' THEN '' WHEN '4' THEN '' WHEN '6' THEN ''  ELSE to_char(year(a.dbirth)-1911)||'/'||to_char(a.dbirth,'%m/%d') END ,"
      	                "       a.nbenef,a.rel_benef,a.tbenef,a.abenef "
                        "  FROM est_ins_assured a,estimate b "
                        " WHERE a.iestimate=? AND a.iestimate=b.iestimate AND a.iins_type IN ('50') "
                        " UNION "*/
      	                "SELECT a.iestimate,a.iins_type,a.iinsurant,a.ninsurant, "
      	                "       CASE b.fassured WHEN '2' THEN '' WHEN '4' THEN '' WHEN '6' THEN ''  ELSE to_char(year(a.dbirth)-1911)||'/'||to_char(a.dbirth,'%m/%d') END , "
      	                "       a.nbeneficiary,a.relation_bene,a.tbenef,a.abenef "
                        "  FROM ca_pa_est a,estimate b "
                        " WHERE a.iestimate=? AND a.iestimate=b.iestimate AND a.iins_type IN ('56','136','266')"
                        " UNION "
                        "SELECT a.iestimate,a.iins_type,a.iassured,a.nassured, "
                        "       CASE b.fassured WHEN '2' THEN '' WHEN '4' THEN '' WHEN '6' THEN ''  ELSE to_char(year(a.dbirth)-1911)||'/'||to_char(a.dbirth,'%m/%d') END , "
                        "       a.nbenef,a.rel_benef,a.tbenef,a.abenef "
                        "  FROM est_ins_assured a,estimate b "
                        " WHERE a.iestimate=? AND a.iestimate=b.iestimate AND a.iins_type IN ('147','561') ");
      	  printf("stmt9=[%s]\n",stmt9);
      	
      }

      $PREPARE  pre_list_est FROM $stmt9;
      $DECLARE  cur_list_est CURSOR FOR pre_list_est;
      $OPEN     cur_list_est using $Est.iestimate,$Est.iestimate;
      while(1)
      {
          $FETCH cur_list_est INTO $iestimate_list,$iins_type_list,$iinsurant_list,
	                           $ninsurant_list,$dbirth_list,$nbeneficiary_list,
	                           $relation_bene_list,$tbenef_list,$abenef_list;

	  if(SQLCODE == SQLNOTFOUND)  break;

	  fprintf(fp4,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n", iestimate_list,iins_type_list,iinsurant_list,ninsurant_list,dbirth_list,nbeneficiary_list,relation_bene_list,tbenef_list,abenef_list);
      }
      $close    cur_list_est;
      $free     cur_list_est;
	
      /* �^���r�p�H�ˮ`�W�U  end ----------------------- */
      
      /* 97���O�n�O�ѤW��ܡi�䲼ú�ڡj104.04.23 (1040407003_C2) */
      if (equip_cmp(Est.nequipment,"97") == TRUE)
          strcpy(equip97,"Y");
      else
      	  strcpy(equip97,"N");
      	  
      strcpy(Est.dply1_begin, trim(Est.dply1_begin));
      if (strlen(Est.dply1_begin) != 0)
          strcpy(sIcomm_obj, trim(Est.icomm_obj1));
      else
      	  strcpy(sIcomm_obj, trim(Est.icomm_obj2));

      /* �O�g/�N������r(�s/��O��) car_code.kind = '47' (1040909001_C1) */
      strcpy(sIroute4, trim(sIroute4));
      strcpy(sIcomm_obj, trim(sIcomm_obj));
      strcpy(Remind, "");
      $SELECT chiname, engname, count(*)
         INTO $Remind1, $Remind2, $CntIroute
         FROM car_code
        WHERE kind = '47'
          AND (detail = $sIroute4
           OR detail = $sIcomm_obj)
        GROUP BY chiname, engname;
      
      strcpy(Remind1, trim(Remind1));
      strcpy(Remind2, trim(Remind2));
      strcpy(sBarcode_type, " ");
      strcpy(sIply_302_V, " ");
      count_plicy302 = 0;
      v_ori_prem = 0;
      strcpy(Est.ilast_ply, trim(Est.ilast_ply));
      if (strlen(Est.ilast_ply) != 0)
      {
          printf("***** ilast_ply[%s] *****\n", Est.ilast_ply);
      	  /* ��O�ɡi���N�O��j */
          $SELECT NVL(CASE WHEN a.fcard_class = '1' THEN a.irelative_ply
                      ELSE a.ipolicy END , ' '), 
                  NVL(CASE WHEN a.fcard_class = '1' THEN (SELECT v_ori_prem FROM policy_302 
                                                           WHERE ipolicy = a.irelative_ply)
                  	  ELSE a.v_ori_prem END , 0), count(*)
             INTO $sIply_302_V, $v_ori_prem, $count_plicy302
             FROM policy_302 a
            WHERE a.ipolicy = $Est.ilast_ply
              AND a.iapplicant = $Est.iapplicant
              AND a.iengine = $Est.iengine
            GROUP BY 1, 2;
          
          if (count_plicy302 > 0)
          {
              countCheck_302 = 0;
              cnt_diff = 0;
              strcpy(sIply_302_V, trim(sIply_302_V));
              if (strlen(sIply_302_V) != 0)
              {
              	  printf("***** ilast_ply_V[%s] *****\n", sIply_302_V);
              	  $DECLARE cur_plyInsType_302 CURSOR for
              	  
                    SELECT iins_type
                      FROM ply_ins_type_302
                     WHERE ipolicy = $sIply_302_V
                       AND ori_premium > 0;
                   
                  $OPEN cur_plyInsType_302;
                  
                  for(;;)
                  {
                      $FETCH cur_plyInsType_302 INTO $sIinsType_302;
                 	   
                      if (SQLCODE == SQLNOTFOUND) break;
                 	   	
                      /* �����O�渹�PCP�պ⸹�`�O�O */
                      if (v_ori_prem != Est.mpremium2)
                      {
                          cnt_diff = 1;
                          break;
                      }
                 	   
                      /* �����O�渹���i���O�j�I�ثO�O�PCP�պ⸹���I�ثO�O(���N�I) */
                      /* ���O�O�ۦP�ɡA�����u��O��v�A�O�O���ۦP�ɡA�����u�s�O��v*/
                      /* �u��O��v��ܡi���O�j�r�� (1041027001_C1) */
                      $SELECT count(*) INTO $countCheck_302
                 	 FROM est_ins_type a, ply_ins_type_302 b
                 	WHERE a.iins_type = b.iins_type
                 	  AND a.mins_premium = b.ori_premium
                 	  AND a.iestimate = $Est.iestimate
                 	  AND b.ipolicy = $sIply_302_V
                 	  AND b.iins_type = $sIinsType_302
                 	  AND b.ori_premium > 0;
                 	       
                      if (countCheck_302 > 0)
                      {
                          continue;
                      }
                      else
                      {
                 	  cnt_diff = 1;
                 	  break;
                      }
                 	   
                  }
                  $CLOSE cur_plyInsType_302;
                  $FREE cur_plyInsType_302;
                                   
                  /* ��ܧ�O�զX�r�� */
                  if (cnt_diff == 0)
                  {
                      printf("***** compare mins_premium same *****\n");
                      if (CntIroute > 0) strcpy(Remind, "�����ץ󬰡i��O��j���� :ú�O���");
                      strcpy(sBarcode_type, "���O");
                  }
                  else
                  {
                      printf("***** compare mins_premium different *****\n");
                      if (CntIroute > 0)
                      {
                          strcpy(Remind, "�����ץ󬰡i�s��O��j���� :");
                          strcat(Remind, Remind1);
                          if (strlen(trim(Est.dply2_begin)) != 0)
                          {
                              if (strlen(Remind2) != 0)
                              {
                                  strcat(Remind, "+");
                     	          strcat(Remind, Remind2);
                              }
                          }
                      }
                  }
              }
              else
              {
                  strcpy(Est.dply2_begin, trim(Est.dply2_begin));
                  if (strlen(Est.dply2_begin) != 0)
                  {
                      printf("***** ��j�[�O���N ***** \n");
                      if (CntIroute > 0)
                      {
                          strcpy(Remind, "�����ץ󬰡i�s��O��j���� :");
                          strcat(Remind, Remind1);
                          if (strlen(Remind2) != 0)
                          {
                              strcat(Remind, "+");
                     	      strcat(Remind, Remind2);
                          }
                      }
                  }
                  else
                  {
                      printf("***** ��j *****\n");
                      /* �h�~��O�j���I,���~�]��O�j���I�@�߬��i��O��j*/
              	      if (CntIroute > 0) strcpy(Remind, "�����ץ󬰡i��O��j���� :ú�O���");                   
                      strcpy(sBarcode_type, "���O");
                  }
              }
          }
          else
          {
          	  /* �d������O��� */
              if (CntIroute > 0)
      	      {
                  strcpy(Remind, "�����ץ󬰡i�s��O��j���� :");
                  strcat(Remind, Remind1);
                  if (strlen(trim(Est.dply2_begin)) != 0)
                  {
                      if (strlen(Remind2) != 0)
                      {
                         strcat(Remind, "+");
                         strcat(Remind, Remind2);
                      }
                  }
              }
          }
      }
      else
      {
      	  if (CntIroute > 0)
      	  {
              strcpy(Remind, "�����ץ󬰡i�s��O��j���� :");
              strcat(Remind, Remind1);
              if (strlen(trim(Est.dply2_begin)) != 0)
              {
                  if (strlen(Remind2) != 0)
                  {
                      strcat(Remind, "+");
                      strcat(Remind, Remind2);
                  }
              }
          }
      }

      /***** 1041026001_C2 �����I����������i�C�L�n�O���ˮ�(BEGIN) *****/
      /*   �ŦX�H�U����϶�����A��i���ˮ֡G
	   8/15 �� �t�Τ� �� 11/14 ��
           11/15 �� �t�Τ� �B  8/15�إͮĤ��11/14
      */

      printf("�����I�P�_BEGIN\n");

      strcpy(sPassPrint,"0");			/* client�ݥΨӧP�_�����I����C�L(�n�O��) */

	if (strlen(trim(Est.dply2_begin)) != 0 && strncmp(iest_bgn+6,"X",1) != 0)	/* ���`���ˮ� */
	{

	    $SELECT case WHEN today <= '08/14/2015' THEN 'X'
		         WHEN today between '08/15/2015' and '11/15/2015' THEN 'Y'
		         WHEN today >= '11/16/2015' THEN 'Z'
		         else 'N' END as chk_today,
	            case WHEN dply2_begin between '08/15/2015' and '11/15/2015' THEN 'Y' ELSE 'N' END as chk_dbegin
               INTO $chk_today,$fchk_dbegin
               FROM estimate
              WHERE iestimate = $Est.iestimate ;

	    if ((chk_today[0]=='Y') ||
	        (chk_today[0]=='Z' && fchk_dbegin[0]=='Y'))
	    {
	        strcpy(Est.ilast_ply , trim(Est.ilast_ply));
	        printf("-- trace Est.ilast_ply[%s]\n ",Est.ilast_ply);

	    	strcpy(dmgflag_A , " "); strcpy(dmgflag_B , " ");
	    	strcpy(dmgflag_C , "N"); strcpy(dmgflag_D , "N"); strcpy(dmgflag_38 , "N"); strcpy(dmgflag_39 , "N");
			$SELECT
		          max(CASE WHEN iins_type IN ('09','98','126','209')     THEN 'A'
			               WHEN iins_type IN ('120')                     THEN 'B'
			               WHEN iins_type IN ('85')                      THEN 'C'
			               WHEN iins_type IN ('05','125','205')          THEN 'D'
			               WHEN iins_type IN ('105')                     THEN 'E'
			               WHEN iins_type IN ('118')                     THEN 'F'
			               WHEN iins_type IN ('01','201')                THEN 'G'
			               WHEN iins_type IN ('122')                     THEN 'H'
		              ELSE ' ' END) AS dmgflag_A,
		          max(CASE WHEN iins_type IN ('15')            THEN 'A'
			               WHEN iins_type IN ('67')            THEN 'B'
			               WHEN iins_type IN ('106')           THEN 'C'
			               WHEN iins_type IN ('66')            THEN 'D'
		              ELSE ' ' END) AS dmgflag_B,
		          max(CASE WHEN iins_type IN ('04','06','18','23','75','81','83','86','110') THEN 'Y' ELSE 'N' END) AS dmgflag_C,
		          max(CASE WHEN iins_type IN ('02','03','07','10','61','62','63','64','65','69','107','108','119','121','123','127') THEN 'Y' ELSE 'N' END) AS dmgflag_D,
		          max(CASE WHEN iins_type IN ('38') THEN 'Y' ELSE 'N' END) AS dmgflag_38,
		          max(CASE WHEN iins_type IN ('39') THEN 'Y' ELSE 'N' END) AS dmgflag_39
		       INTO $dmgflag_A ,$dmgflag_B ,$dmgflag_C ,$dmgflag_D ,$dmgflag_38 ,$dmgflag_39
	           FROM est_ins_type
	          WHERE iestimate = $Est.iestimate ;
		    printf("-- trace dmgflag_A[%s] ,dmgflag_B [%s]\n ",dmgflag_A ,dmgflag_B);
		    printf("-- trace dmgflag_C[%s] ,dmgflag_D [%s]\n ",dmgflag_C ,dmgflag_D);
		    printf("-- trace dmgflag_38[%s],dmgflag_39[%s]\n ",dmgflag_38,dmgflag_39);

	        /* �S���ӫO�����I */
	        if ((dmgflag_A[0]==' ')&&(dmgflag_B[0]==' ')&&(dmgflag_C[0]=='N')&&(dmgflag_D[0]=='N')&&(dmgflag_38[0]=='N')&&(dmgflag_39[0]=='N'))
	        {
	        	/* �ŦX�u�����I��O��v���� */
	        }
	        else/* ���ӫO�����I */
	        {
	        	if (strlen(Est.ilast_ply)==0)
	        	{   /* �S���e�O�渹 */
	        		/* ���ŦX�u�����I��O��v����*/
				        strcpy(sPassPrint,"1");
	            }
	            else
	            {   /*  ���e�O�渹 */
	            	/*  �����O�D�ɡG�Q�O�I�HID�B�������B�ͮĤ� */
	                strcpy(Est.iassured  , trim(Est.iassured));
	                strcpy(Est.iengine   , rtrim(Est.iengine)); /* ���������i��t�ť� */
	                printf("-- trace Est.iassured  [%s]\n ",Est.iassured);
	                printf("-- trace Est.iengine   [%s]\n ",Est.iengine);

	            	tmpCount = 0;
		        	$select count(*) into $tmpCount
		        	   from policy_302
		        	  where ipolicy    = $Est.ilast_ply
		        	    and ilicense   = $Est.iassured
		        	    and iengine    = $Est.iengine;
		        	    /*and dply_begin >= $dply_begin ; */

	        	    if (tmpCount==0) /* �S����O��� �� �Q�O�I�HID�B�������B�ͮĤ� ���@���ŦX */
	        	    {
		        	    	/* ���ŦX�u�����I��O��v����*/
					strcpy(sPassPrint,"1");
	        	    }else{  /* ����O��� �B �Q�O�I�HID�B�������ҲŦX */

	        	    	/*1040828005_C1 �Y�ϲ��`��A�_�O�������\�L�� */
		            	tmpCount = 0;
			        	$select count(*) into $tmpCount
			        	   from policy_302
			        	  where ipolicy    = $Est.ilast_ply
			        	    and dply_begin >= $Est.dply2_begin ;
			        	if (tmpCount==0) {
				            strcpy(sPassPrint,"1");
					    }
	        	    }

	        	        /*�u���`��v���ˮ� */
	        	        /* �P�_�O�_�X�j�ӫO�d�� => �����O������ */
	        	        strcpy(dmgflag_302_A , " "); strcpy(dmgflag_302_B , " ");
	        	        strcpy(dmgflag_302_C , "N"); strcpy(dmgflag_302_D , "N");strcpy(dmgflag_302_38 , "N");strcpy(dmgflag_302_39 , "N");
						$select
					          max(CASE WHEN iins_type IN ('09','98','126','209')   THEN 'A'
						               WHEN iins_type IN ('120')                   THEN 'B'
						               WHEN iins_type IN ('85')                    THEN 'C'
						               WHEN iins_type IN ('05','125','205')        THEN 'D'
						               WHEN iins_type IN ('105')                   THEN 'E'
						               WHEN iins_type IN ('118')                   THEN 'F'
						               WHEN iins_type IN ('01','201')              THEN 'G'
						               WHEN iins_type IN ('122')                   THEN 'H'
					              ELSE ' ' END) AS dmgflag_302_A,
					          max(CASE WHEN iins_type IN ('15')            THEN 'A'
						               WHEN iins_type IN ('67')            THEN 'B'
						               WHEN iins_type IN ('106')           THEN 'C'
						               WHEN iins_type IN ('66')            THEN 'D'
					              ELSE ' ' END) AS dmgflag_302_B,
			                  max(CASE WHEN iins_type IN ('04','06','18','23','75','81','83','86','110') THEN 'Y' ELSE 'N' END) AS dmgflag_302_C,
			                  max(CASE WHEN iins_type IN ('02','03','07','10','61','62','63','64','65','69','107','108','119','121','123','127') THEN 'Y' ELSE 'N' END) AS dmgflag_302_D,
			                  max(CASE WHEN iins_type IN ('38') THEN 'Y' ELSE 'N' END) AS dmgflag_302_38,
			                  max(CASE WHEN iins_type IN ('39') THEN 'Y' ELSE 'N' END) AS dmgflag_302_39
					       INTO $dmgflag_302_A ,$dmgflag_302_B ,$dmgflag_302_C ,$dmgflag_302_D ,$dmgflag_302_38, $dmgflag_302_39
					       from ply_ins_type_302
					      where ipolicy = $Est.ilast_ply
					        and ori_premium >0 ;
	  					printf("-- trace dmgflag_302_A [%s],dmgflag_302_B [%s]\n ",dmgflag_302_A ,dmgflag_302_B);
	  					printf("-- trace dmgflag_302_C [%s],dmgflag_302_D [%s]\n ",dmgflag_302_C ,dmgflag_302_D);
	  					printf("-- trace dmgflag_302_38[%s],dmgflag_302_39[%s]\n ",dmgflag_302_38,dmgflag_302_39);

	  					/* ��O�ɵL��� �� �S���������I */
	  					if ((dmgflag_302_A[0]==' ')&&(dmgflag_302_B[0]==' ')&&(dmgflag_302_C[0]=='N')&&(dmgflag_302_D[0]=='N')&&(dmgflag_302_38[0]=='N')&&(dmgflag_302_39[0]=='N'))
	  					{
		        	    			/* ���ŦX�u�����I��O��v����*/
				            		strcpy(sPassPrint,"1");
	  					}
	  					else /* ��O�ɡu���O�զX�v�������I */
	  					{
		        	    	if (dmgflag_A[0]> dmgflag_302_A[0]) /* ����D�I�u�X�j�ӫO�d��v */
		        	    	{
			        	    	/* ���ŦX�u�����I��O��v����*/
					        strcpy(sPassPrint,"1");
		        	    	}
		        	    	else if (dmgflag_A[0]==' ')
		        	    	{
		        	    		if (dmgflag_39[0]=='Y' &&  dmgflag_302_39[0]=='N')
		        	    		{
				        	    	/* ���ŦX�u�����I��O��v����*/
						        strcpy(sPassPrint,"1");
		        	    		}
		        	    		if (dmgflag_38[0]=='Y' && (dmgflag_302_38[0]=='N' && dmgflag_302_39[0]=='N'))   /* �D���ϴ��]�D�I�ʽ�^�u�X�j�ӫO�d��v */
		        	    		{
				        	    	/* ���ŦX�u�����I��O��v����*/
						        strcpy(sPassPrint,"1");
		        	    		}
		        	    		if(dmgflag_B[0] > dmgflag_302_B[0] )                                             /* �N�B��  �]�D�I�ʽ�^�u�X�j�ӫO�d��v */
		        	    		{
				        	    	/* ���ŦX�u�����I��O��v����*/
						        strcpy(sPassPrint,"1");
		        	    		}
		        	    	}
		        	    	else if (dmgflag_C[0]=='Y')         /* ��L����D�I���: �ӫO�I�إ����s�b����O��u���O�զX�v�� */
		        	    	{
		        	    		if (dmgflag_302_C[0]=='Y')
		        	    		{
		        	    			tmpCount = 0;
		        	    			$SELECT count(*) Into $tmpCount
		        	    			   FROM est_ins_type a ,ply_ins_type_302 b
		        	    			  WHERE a.iestimate   = $Est.iestimate
		        	    			    and b.ipolicy   = $Est.ilast_ply
		        	    			    and a.iins_type = b.iins_type
		        	    			    and b.ori_premium >0
		        	    			    and a.iins_type IN ('04','06','18','23','75','81','83','86','110');

		        	    			if (tmpCount==0)
		        	    			{
					        	    	/* ���ŦX�u�����I��O��v����*/
							        strcpy(sPassPrint,"1");
		        	    			}
		        	    		}
		        	    		else
		        	    		{
				        	    	/* ���ŦX�u�����I��O��v����*/
						        strcpy(sPassPrint,"1");
		        	    		}
		        	    	}
	        	    	}
	    	    }
		    }
	    }
	}
printf("�����I�P�_END\n");
      /******************* �����I����������i�C�L�n�O���ˮ�(END) *******************/
      
      /******************* 30�I�ةӫO�d�򻡩����e(BEGIN) *******************/
printf("30�I�ةӫO�d�򻡩����eBEGIN\n");

	$SELECT iins_type,mdeduct
	   INTO $iins_type30_301,$deduct_30
 	   FROM est_ins_type
	  WHERE iestimate = $Est.iestimate
	    AND iins_type in ( '30', '301', '302', '530' );
	    
	if(SQLCODE == SQLNOTFOUND)
	{
		strcpy(str_ins_30," ");
	}
	else
	{
		/*�P�_��O���O30�I���٬O301�I��*/
		strcpy(iins_type30_301,trim(iins_type30_301));
		if( strcmp(iins_type30_301,"30") == 0 )
		{
			flag30_301 = 30;
		}
		else if( strcmp(iins_type30_301,"301") == 0 )
		{
			flag30_301 = 301;
		}
		else if( strcmp(iins_type30_301,"302") == 0 )
		{
			flag30_301 = 302;
		}
        else
        {
        	flag30_301 = 530;
        }
		/*�T�{���[�O24*/    
		$SELECT iins_type
		   INTO $iins_type24
		   FROM est_ins_type
		  WHERE iestimate = $Est.iestimate
		    AND iins_type = '24';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��24�I��*/
		{
			flag24=0;
		}
		else
		{
			flag24=1;
		}	
		/*�T�{���[�O55*/
		$SELECT iins_type
		   INTO $iins_type55
		   FROM est_ins_type
		  WHERE iestimate = $Est.iestimate
		    AND iins_type = '55';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
		{
			flag55=0;
		}
		else
		{
			flag55=1;
		}
		/*�T�{���[�O255*/
		$SELECT iins_type
		   INTO $iins_type55
		   FROM est_ins_type
		  WHERE iestimate = $Est.iestimate
		    AND iins_type = '255';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
		{
			flag255=0;
		}
		else
		{
			flag255=1;
		}
		/*�T�{���[�O49 or 177*/
		$SELECT iins_type
		   FROM est_ins_type
		  WHERE iestimate = $Est.iestimate
		    AND iins_type IN ('49','117');
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��49 or 117�I��*/
		{
			flag49117=0;
		}
		else
		{
			flag49117=1;
		}
        /*�T�{���[�O555*/
		$SELECT iins_type
           INTO $iins_type55
           FROM est_ins_type
          WHERE iestimate = $Est.iestimate
            AND iins_type = '555';
        if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��555�I��*/
        {
            flag555=0;
        }
        else
        {
            flag555=1;
        }
		
		strcpy(tmp_deduct_30,itoa(deduct_30));
		/* 1080311008_SC4_�ͮĤ��71�_����s�v�I */
		if( (flag30_301 == 302) && (flag55 == 1) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d��]�t:������˳d�����[���ڡC");
            }
            else
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d�򤣥]�t:������˳d�����[���ڡC");
            }
		}
		else if( (flag30_301 == 302) && (flag255 == 1) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d��]�t:������˳d���I�C");
            }
            else
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d�򤣥]�t:������˳d���I�C");
            }
		}
		
		if( (flag30_301 == 301) && (flag55 == 1) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d���I���[����-��D���W���ӫO�d��]�t:������˳d�����[���ڡC");
            }
	        else
            {
            	strcpy(str_ins_30,"�W�B�d���I���[����-��D���W���ӫO�d�򤣥]�t:������˳d�����[���ڡC");
            }
		}
		else if( (flag30_301 == 301) && (flag255 == 1) )
		{
			strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d�򤣥]�t:������˳d���I�C");
		}
		
		if( (flag30_301 == 30) && (flag24 == 1) && (flag55 == 1) && (strncmp(fchk_24,"Y",1)==0))
		{
			if ((IsFcomp24(tmp_deduct_30)) && (IsFcomp55(tmp_deduct_30)))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:�ĤT�H�d�����s���v�T�έ�����˳d�����[���ڡC");
            }
			else if (IsFcomp24(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:�ĤT�H�d�����s���v�T���[���ڤ��]�t������˳d�����[���ڡC");
            }
			else if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:������˳d�����[���ڤ��]�t�ĤT�H�d�����s���v�T���[���ڡC");
            }
			else
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:�ĤT�H�d�����s���v�T�έ�����˳d�����[���ڡC");
            }
		}
		else if( (flag30_301 == 30) && (flag24 == 1) && (strncmp(fchk_24,"Y",1)==0))
		{
			if (IsFcomp24(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:�ĤT�H�d�����s���v�T���[���ڡC");
            }
			else
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:�ĤT�H�d�����s���v�T���[���ڡC");
            }		
		}
		else if( (flag30_301 == 30) && ((flag55 == 1) ||(flag49117 == 1) ))
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:������˳d�����[���ڡC");
            }
			else
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:������˳d�����[���ڡC");
            }		
		}
		else if( (flag30_301 == 30) && ((flag255 == 1) ||(flag49117 == 1) ))
		{
			strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:������˳d���I�C");
		}

        if((flag30_301 == 530) && (flag555 == 1))
        {
            if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�r�V�Z�W�B�d���I�ӫO�d��]�t�G�r�V�Z������˳d���I�C");
            }
            else
            {
            	strcpy(str_ins_30,"�r�V�Z�W�B�d���I�ӫO�d�򤣥]�t�G�r�V�Z������˳d���I�C");
            }
        }
	}

printf("30�I�ةӫO�d�򻡩����eEND\n");
      /******************* 30�I�ةӫO�d�򻡩����e(END) *********************/
      
      /* 1120316006_SC5_�L��-���N�I���e�{�s�W���@�������������O�N��05�ή��s�X��t�ηs�W���@�����O */
      flag_ambulance55 = 0;
      $SELECT iins_type
		 INTO $iins_type55
		 FROM est_ins_type
		WHERE iestimate = $Est.iestimate
		  AND iins_type = '55';
      if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
      {
          flag_ambulance55=0;
      }
      else
      {
          flag_ambulance55=1;
      }
      
      if (flag_ambulance55 > 0 && strncmp(Est.icar_type2,"11",2) == 0 && (equip_cmp(Est.nequipment,"115") == true) && f20230601[0] == 'Y')
      {
      	 if (str_ins_30[0] == '' || str_ins_30[0] == '\0' ) strcat(str_ins_30," ");
      	 strcat(str_ins_30,"�����I�ӫO�d�򤣧t�˱w");
      }
      else 
      {
          
      }
      
      /******************* �t�Ʃ���(BEGIN) ***********************/
      strcpy(outfit_nequipment," ");
      if(strcmp(fequipment1,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B���T");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"���T");
      	}
      }
      
      if(strcmp(fequipment2,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B���c");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"���c");
      	}
      }
      
      if(strcmp(fequipment3,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B�N�����");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"�N�����");
      	}
      }
      
      if(strcmp(fequipment4,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B���ءB����");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"���ءB����");
      	}
      }
      
      if(strcmp(fequipment5,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B�@���t��");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"�@���t��");
      	}
      }
      
      if(strcmp(fequipment6,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B�q�ʨ��q��");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"�q�ʨ��q��");
      	}
      }
      
      if(strcmp(fequipment9,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B");
      		strcat(outfit_nequipment,nequipment9);
      	}
      	else
      	{
      		strcpy(outfit_nequipment,nequipment9);
      	}
      }
      
      printf("outfit_nequipment[%s]\n",outfit_nequipment);

      /******************* �t�Ʃ���(END) ***********************/
      
      /*** �Ӹ�B�n ***/
      if (ProtectData == 1)
      {
      		if (strlen(trim(Est.iassured)) != 0)
		{
	      	    	strcpy(iassured_pt, Est.iassured);
			strcpy(Est.iassured,substring(iassured_pt,1,4));
			strcat(Est.iassured,"****");
			strcat(Est.iassured,substring(iassured_pt,9,4));
		}
		
		if (strlen(trim(Est.iapplicant)) != 0)
		{
			strcpy(iapplicant_pt, Est.iapplicant);
			strcpy(Est.iapplicant,substring(iapplicant_pt,1,4));
			strcat(Est.iapplicant,"****");
			strcat(Est.iapplicant,substring(iapplicant_pt,9,4));
		}
		
		if (strlen(trim(Est.itel)) != 0)
		{
			strcpy(itel_pt, Est.itel);
			strcpy(Est.itel,substring(itel_pt,1,3));
			strcat(Est.itel,"XXXX");
			strcat(Est.itel,substring(itel_pt,8,13));
		}
		
		if (strlen(trim(Est.itel_night)) != 0)
		{
			strcpy(itel_night_pt, Est.itel_night);
			strcpy(Est.itel_night,substring(itel_night_pt,1,3));
			strcat(Est.itel_night,"XXXX");
			strcat(Est.itel_night,substring(itel_night_pt,8,13));
		}
		
		if (strlen(trim(Est.itel_appl)) != 0)
		{
			strcpy(itel_appl_pt, Est.itel_appl);
			strcpy(Est.itel_appl,substring(itel_appl_pt,1,3));
			strcat(Est.itel_appl,"XXXX");
			strcat(Est.itel_appl,substring(itel_appl_pt,8,13));
		}
		
		if (strlen(trim(Est.mobil_phone)) != 0)
		{
			strcpy(mobil_phone_pt, Est.mobil_phone);
			strcpy(Est.mobil_phone,substring(mobil_phone_pt,1,3));
			strcat(Est.mobil_phone,"XXXX");
			strcat(Est.mobil_phone,substring(mobil_phone_pt,8,13));
		}
		
		if (strlen(trim(Est.itag)) != 0)
		{
			strcpy(itag_pt, Est.itag);
			if(strcmp(Est.icar_type1,"27") == 0 || strcmp(Est.icar_type2,"27") == 0)
			{
				strcpy(Est.itag,"****");
				strcat(Est.itag,substring(itag_pt,5,CA_TAG_NUM-5));
			}
			else
			{
				strcpy(Est.itag,"***");
				strcat(Est.itag,substring(itag_pt,4,CA_TAG_NUM-4));
		        }
		}
      }
      
      /* �j+�� -> ���N�g��H;���  -> ���N�g��H;��j  -> ���N�g��H */
      strcpy(Est.iofficer2,trim(Est.iofficer2));
      if (strlen(Est.iofficer2) == 0)
      {
      	$SELECT nname
      	   INTO $Nname
      	   FROM officer
      	  WHERE iofficer = $Est.iofficer1;
      }
      
      /*1050601008_C2_�s�Wka�q����O��۰ʥN�X�~�ȭ��n���r��*/
	/* ���n���Ҧr��_KA */
	sprintf_s(stmt_iregno, sizeof stmt_iregno, " SELECT ilicence \
			  FROM cm_salesman_log \
			 WHERE ileader = ? and icomm_obj = ileader ");
	$PREPARE prep_iregno_KA_est FROM $stmt_iregno;
	printf("stmt_iregno[%s]\n",stmt_iregno);
        strcpy(Nreg_no2," ");
        printf("prep_iregno_KA_est \n");
        if (strncmp(Est.iroute,"KA",2) == 0 && Est.ilast_ply[0] != 0)
        {
		/* �O��q���N����KA*��, �n�]�n�^���n���Ҧr�� */
		$EXECUTE prep_iregno_KA_est into $Nreg_no using $sIleader;
        	if (SQLCODE == SQLNOTFOUND) strcpy(Nreg_no," "); 
        	strcpy(Nreg_no2,trim(Nreg_no));
        	strcat(Nreg_no2," ");
        	strcat(Nreg_no2,nleader);	
        }
        else
        	strcpy(Nreg_no2," ");
        	
      /*�����I¾�~*/
      sprintf_s(stmt_occup1, sizeof stmt_occup1, "SELECT (trim(imember)||' '||trim(nmember)) FROM cm_risk_member WHERE itype = 'P' AND fmember = 'P' AND imember = '%s' ",Est.noccup);
      $PREPARE prep_occup_est1 FROM $stmt_occup1;
      $EXECUTE prep_occup_est1 into $noccup_fullname;
      if (SQLCODE == SQLNOTFOUND) strcpy(noccup_fullname," "); 
      
      sprintf_s(stmt_occup2, sizeof stmt_occup2, "SELECT (trim(imember)||' '||trim(nmember)) FROM cm_risk_member WHERE itype = 'P' AND fmember = 'P' AND imember = '%s' ",Est.applicant_noccup);
      $PREPARE prep_occup_est2 FROM $stmt_occup2;
      $EXECUTE prep_occup_est2 into $applicant_noccup_fullname;
      if (SQLCODE == SQLNOTFOUND) strcpy(applicant_noccup_fullname," "); 
      
      printf("noccup_fullname[%s] applicant_noccup_fullname[%s] \n",noccup_fullname,applicant_noccup_fullname);

      /******���[���ڤ�r����(BEGIN)******/
      
      strcpy(iprov_all," ");
      strcpy(sprov_all," ");
      strcpy(iprov," ");
      strcpy(iins_prov," ");
      strcpy(sprov," ");
      strcpy(sprov_note," ");
      strcpy(sprov_note_all," ");    
      if (strncmp(Est.iestimate+6,"X",1)==0)  /* ���`�� */  
          sprintf_s(stmt7, sizeof stmt7, "SELECT trim(nvl(provision,' '))||';',iins_type FROM newa00:abn_ply_ins_type WHERE iabnormal = '%s'" , Est.iestimate);
      else 
          sprintf_s(stmt7, sizeof stmt7, "SELECT trim(nvl(provision,' '))||';',iins_type FROM est_ins_type WHERE iestimate = '%s'" , Est.iestimate);
      	               
      $PREPARE  preProvision3 FROM $stmt7;
      $DECLARE  cur_provision3 CURSOR FOR preProvision3;
      $OPEN     cur_provision3;

      for(;;)
      {
            $FETCH cur_provision3 INTO $iprov,$iins_prov;
            if(SQLCODE == SQLNOTFOUND)  break;
            
            if (strstr(trim(iprov),"P;") != NULL)
            {
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0) )

					$SELECT first 1 replace($iprov,'P;','')
		       		   INTO $iprov
		       		   FROM systables;
            }
            else if (strstr(trim(iprov),"Q;") != NULL)
            {
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

					$SELECT first 1 replace($iprov,'Q;','')
					   INTO $iprov
					   FROM systables;	
            }
            else if (strstr(trim(iprov),"M;") != NULL)
            {
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) && 
                    (strcmp(trim(iins_prov),"181")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'M;','')
		       INTO $iprov
		       FROM systables;		
            } 
            else if (strstr(trim(iprov),"Y;") != NULL)
            {
            	/* 1130827011_C04_�s�W�s�t��W�B���[����(Y)(�L��) */
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) && 
                    (strcmp(trim(iins_prov),"198")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'Y;','')
		       INTO $iprov
		       FROM systables;		
            } 
            
            strcat(iprov_all, iprov);

      }
      $CLOSE  cur_provision3;
      $FREE   cur_provision3;
      printf("�����[����:iprov_all[%s]\n",trim(iprov_all));
      strcpy(iprov_all,trim(iprov_all));
      
      if (strcmp(iprov_all,";")!=0 && strcmp(iprov_all,"")!=0)
      {
          ptr1 = strtok(iprov_all,";");
	  while(ptr1 != NULL)
	  {
      	      sprintf_s(sprov, sizeof sprov,"'%s',",ptr1);  
      	      strcat(sprov_all,sprov);	  				
	      ptr1 = strtok(NULL, ";");
	  }
				

          strcat(sprov_all,"''");
      		
          printf("�����[����:sprov_all[%s]\n",trim(sprov_all));
      	
      	  sprintf_s(stmt8, sizeof stmt8, "SELECT trim(nprint)||'�B' FROM ca_provision_main WHERE iprovision NOT IN ('C','E','S') AND iprovision IN (%s)" , trim(sprov_all));
          $PREPARE  preProvision4 FROM $stmt8;
          $DECLARE  cur_provision4 CURSOR FOR preProvision4;
          $OPEN     cur_provision4;   
          
          for(;;)
          {
              $FETCH cur_provision4 INTO $sprov_note;
              if(SQLCODE == SQLNOTFOUND)  break;

              strcat(sprov_note_all, trim(sprov_note));

          }
          $CLOSE  cur_provision4;
          $FREE   cur_provision4;   
          printf("�����[���ڤ���:sprov_note_all[%s]\n",trim(sprov_note_all));
          strcpy(sprov_note_all,trim(sprov_note_all));	  
      	  
      }


      /******���[���ڤ�r����(END)******/

	  Est.psex_age_damage = 0;
	  if (strncmp(Est.iestimate+6,"X",1)==0) 
	  {
	      $SELECT NVL(max(psex_age),0) 
	         INTO $Est.psex_age_damage
	         FROM newa00:abn_ply_ins_type 
	        WHERE iabnormal = $Est.iestimate
              AND iins_type IN (SELECT iins_type FROM insurance_type WHERE fins_grp = '1' AND iins_type = iins_ply AND iri_ins <> '11');
	  }
	  else 
	  {
		  $SELECT NVL(max(psex_age),0)
		     INTO $Est.psex_age_damage
		     FROM est_ins_type 
	        WHERE iestimate = $Est.iestimate
	          AND iins_type IN (SELECT iins_type FROM insurance_type WHERE fins_grp = '1' AND iins_type = iins_ply AND iri_ins <> '11');
	  }


      /* �g�J��r��,�`�N��춶�Ƕ��Pclient�ݤ@�P ----------------------------- */
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
               Est.iestimate,Est.iestimate,Est.icard2,Est.icard1,Est.irelative_ply);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
                  Est.ilast_ply,Est.ilast_card,Est.irelative_card,Est.ixxcard);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
                  Est.dply2_begin,Est.dply2_end,Est.dply1_begin,Est.dply1_end);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
                  Est.fassured,Est.iassured,Est.iassured_ext,Est.nassured);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	          Est.ilicense,Est.dbirth,Est.fsex,Est.fmarriage);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
      	          Est.nuser,Est.ibenef,Est.nbenef,Est.aassured);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	          Est.aassured_zip,Est.itel,Est.itel_night,Est.mobil_phone);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	          Est.apayment,Est.apayment_zip,Est.iply_area,Est.dissue);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	          Est.ipro_year,Est.ibrand,Est.nbrand_abbr,Est.icar_type2);
      fprintf(fp0,"%s\t%s\t%s\t%.2f\t",
       	          Est.icar_type1,Est.ncar_abbr,Est.fcar_note2,Est.qcylinder);
      fprintf(fp0,"%s\t%s\t%s\t%.1f\t",
       	          Est.iengine,Est.ibody,Est.itag,Est.mcar_price);
      fprintf(fp0,"%d\t%d\t%d\t%d\t",
       	          Est.pdmg_align,Est.pbrg_align,Est.plia_align,Est.mpremium2);
      fprintf(fp0,"%d\t%s\t%s\t%s\t%d\t",
       	          Est.mpremium1,Est.ibig_comp,Est.ibig_branch,Est.ibig_office,Est.qprovision);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	          Est.ibig_sales,Est.iresource,Est.fdiscount,Est.ibroker2);
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
      	          Est.ibroker1,Est.iofficer2,Est.iofficer1,Est.icorps,Nreg_no2);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
      	          Est.iarea,Est.icashier,Est.iexaminer,Est.dexamine);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	          Nquota,Est.dentry,Est.dapply,Est.fcal_way);
      fprintf(fp0,"%s\t%s\t%s\t%.4f\t",
      	          Est.ipolicy1,Est.ipolicy2 ,Est.idmg_rate,Est.pdmg_factor);
      fprintf(fp0,"%s\t%.4f\t%s\t%.1f\t",
      	          Est.ibrg_rate,Est.pbrg_factor,Est.ibranch,Est.qpt);
      fprintf(fp0,"%s\t%f\t%f\t%f\t",
      	          Est.fpt,Est.psex_age2,Est.psex_age1,Est.psex_age_damage);
      fprintf(fp0,"%s\t%.2f\t%.2f\t%d\t",
                  Est.lia_class,Est.plia_acc2,Est.plia_acc1,Est.dmg_acc_1st);
      fprintf(fp0,"%d\t%d\t%.2f\t%s\t",
   	              Est.dmg_acc_2nd,Est.dmg_acc_3rd,Est.pdmg_acc,Est.fhuman);
      fprintf(fp0,"%s\t%f\t%f\t%s\t",
                  Est.fcomp_24,Est.mbus_rule,Est.mbusiness,Est.fcomp_class);
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
                  Est.fcomp_class_last,Est.iemail,Est.iquery_num_c,
                  Est.iquery_num ,Est.iquery_num_damage);
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t%f\t%s\t",
                  Fcar_class,Ncode,Nname,Nchi_abv,
       	          Est.napplicant,Est.mequipment,Est.iroute);
      fprintf(fp0,"%s\t%s\t%d\t%d\t",
                  Est.iroute_prop, Est.iroute_comm2, Est.qlia_acc_sum,
                  Est.qdmg_acc_sum );
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%d\t%s\t%d\t%s\t%s\t%s\t%s\t%d\t",
                  Est.ndeputy_assured, Est.ndeputy_appl, Est.nrelation_appl, Est.fsex_appl,
                  sFapplicant, Est.iapplicant, Est.dbirth_appl, Est.itel_appl, Est.qdrunk_driving ,sBarcode_type,
                  Est.fuw_status, Est.iaccept, equip97, Remind, sPassPrint,sMcover_limit);
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
      		      sIassured_cntry, sIapplicant_cntry,nleader,str_ins_30,outfit_nequipment);
      
      if (strcmp(Fcard_class,"1") == 0)
         fprintf(fp0,"%s\t%s\t",LastOff1,LastOff1);   /* �e�欰�j���I */
      else
         fprintf(fp0,"%s\t%s\t",LastOff2,LastOff1);   /* �e�欰���N�I */
         
      fprintf(fp0,"%s\t%s\t%s\t%.2f\t%s\t",
      		      feply,fecard,aemail_eply,punknown_acc,iquery_num_unknown);

      fprintf(fp0,"%s\t%s\t%s\t%s\t",
      		      Est.foccup, noccup_fullname,Est.applicant_foccup,applicant_noccup_fullname);
      		      
      fprintf(fp0,"%f\t%f\t%s\t%s\t%s\t%s\t",Est.nmile_ubi, Est.pubi_acc, Est.tmobile_eply,sprov_note_all, tmobile_appl, aemail_appl);

      fprintf(fp0,"%s\t%s\t%s\t%d\t", iLastRelative_ply1, iLastRelative_ply2, feterms, qviolate);
      
      fprintf(fp0,"%s\t%s\t%s\t%s\n", dinstall, isequence, ainstall_zip, ainstall);  /* 1120927002_C12_�R�q�ΰӫ~�}�o(�L��) */
      
      /* �I�ة����� */
      rc1 = select_estins_data_1(Est.iestimate, Est.icar_type2, DBName);

      if (rc1 != SUCCESS)
      {

         break;
      }
   }

   $close cur1;
   $free cur1;

   fclose(fp0);
   fclose(fp1);
   fclose(fp2);
   fclose(fp4);
   $drop table tmp_estimate;


   if (rc1 != SUCCESS)
       return rc1;


   if (icount1 == 0)
   {
      if(exitsub(reply,M_CM_NOT_FOUND) == True)
         return M_CM_NOT_FOUND;
      else
         return apiRC;
   }


   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   cm_buf_put("%s %s %s %s",sTmp0, sTmp1, sTmp2, sTmp4);

   tmp_len = cm_buf_len(ReplyBuf);
   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
   else
         return api_OKComplete;

errexit:

   fclose(fp0);
   fclose(fp1);
   fclose(fp2);
   fclose(fp4);
   sqlfatal();

   return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
} /* end of select_estimate_data */


/***********************************************************************
*   Name : select_estins_data_1                                        *
*                                                                      *
*   Description : Select est_ins_type  �Ѽ�:iestimate �պ⸹           *
***********************************************************************/
long select_estins_data_1(fiestimate, ficar_type, fdbname)
char *fiestimate, *ficar_type, *fdbname;
{
   $char	DBName[5],iest[21],icar_type[3];
   $char	stmt[8192],stmt1[2048],stmt2[2048],stmt3[1024];
   $struct	est_ins_type   *EstIns;
   int	i=0, rc=0;
   int	tmp_len=0;
   char FullGetName[101], filename[31];
   char sTmp0[71], sTmp1[71], sTmp2[71], file0[71], file1[71];
   char rptstr_main[10000], rptstr_dtl[10000];
   char sApHome[31];

   $WHENEVER SQLERROR GOTO errexit;

   strcpy(DBName, fdbname);

   if (db_select(DBName) == False)
         return M_CM_DB_NOTOPEN;

   memset(&EstIns,0, sizeof(EstIns));
   EstIns=(struct est_ins_type *)malloc(sizeof(struct est_ins_type));

   strcpy(iest, fiestimate);
   strcpy(icar_type, ficar_type);
   $WHENEVER SQLERROR GOTO errexit;
   printf(" ------ iest=[%s] icar_type=[%s]\n",iest, icar_type);
   if (strncmp(iest+6,"X",1)==0) { /* ���`�� */
	   strcpy(stmt2,
         " case when a.iins_type in ('56','136','166','266') then (select max(daily_pay) "
         "      from newa00:abn_ca_pa_ply d where a.iabnormal = d.iabnormal "
         "       and a.iins_type = d.iins_type) else 0 end as daily_pay, "
         " case when a.iins_type in ('56','136','166','35','266') then (select distinct iins_scope "
         "      from newa00:abn_ca_pa_ply f where a.iabnormal = f.iabnormal "
         "       and a.iins_type = f.iins_type) else '0' end as iins_scope, "
         " (select count(*) from insurance_cover e "
         "   where a.iins_type = e.iins_type) as insurance_cover, a.iabnormal, a.fproject ");
	   strcpy(stmt3,
	      " from newa00:abn_ply_ins_type a, outer insurance_type b "
         "where iabnormal = ? "
         "  and a.iins_type = b.iins_type "
         "order by qserial ");
   }
   else {	/* �պ��� */
      strcpy(stmt2,
         " case when a.iins_type in ('56','136','166','266') then (select max(daily_pay) "
         "      from ca_pa_est d where a.iestimate = d.iestimate "
         "       and a.iins_type = d.iins_type) else 0 end as daily_pay, "
         " case when a.iins_type in ('56','136','166','35','266') then (select distinct iins_scope "
         "      from ca_pa_est f where a.iestimate = f.iestimate "
         "       and a.iins_type = f.iins_type) else '0' end as iins_scope, "
         " (select count(*) from insurance_cover e "
         "   where a.iins_type = e.iins_type) as insurance_cover, a.iestimate, a.fproject ");
      strcpy(stmt3,
         " from est_ins_type a, outer insurance_type b "
         "where iestimate = ? "
         "  and a.iins_type = b.iins_type "
         "order by qserial ");
   }

   strcpy(stmt1,
      "select a.iins_type,a.minjured_cover,a.mdeath_cover,a.mdamage_cover, "
      "       a.mdeduct,a.mins_premium,a.mpure_prem,a.qserial, "
      "       a.pcommission,a.mcommission,a.pagent,a.magent, "
      "       a.pdiscount,a.mdiscount,a.drate_ym,a.mprem, "
      "       a.iproduct,a.qday,a.mexpense,a.mexp_disc, "
      "       a.provision,a.irate,a.adjust_rate,a.mins_premium_n, "
      "       a.mpure_prem_n,a.mprem_n,a.safe_rate,a.manage_rate, "
      "       a.educated_rate,a.deviation_rate,b.nins_type, "
      "       case when a.iins_type in ('01','05','08','09','120','122','125','126','131','132','201','205','209','331','332') then "
      "            (select prn_deduct from ca_dmg_mdeduct c "
      "              where c.icar_type = ? and c.ideduct = a.mdeduct) "
      "            when b.fdeduct = '0' then '�L' "
      "       else a.mdeduct::varchar(20) end as prn_deduct, "
      "       b.qcoverage, b.cover_print, b.fdeduct, b.deduct_print, ");

   strcpy(stmt,rtrim(stmt1));
   strcat(stmt,rtrim(stmt2));
   strcat(stmt,rtrim(stmt3));

   printf("2:stmt=[%s]\n",stmt);

   $prepare pre_stmt from $stmt;
   $declare cur_ins1 cursor for pre_stmt;
   $open    cur_ins1 using $icar_type,$iest;

   /* �g�J��r��,�`�N��춶�Ƕ��Pclient�ݤ@�P ----------------------------- */
   for(i=0;;i++)
   {
      printf("----------i=[%d] ----------\n ",i);
      $WHENEVER SQLERROR GOTO errexit;
      $fetch cur_ins1 into
            $EstIns->iins_type,$EstIns->minjured_cover,
            $EstIns->mdeath_cover,$EstIns->mdamage_cover,
            $EstIns->mdeduct,$EstIns->mins_premium,
            $EstIns->mpure_prem, $EstIns->qserial,
            $EstIns->pcommission,$EstIns->mcommission,
            $EstIns->pagent,$EstIns->magent,$EstIns->pdiscount,
            $EstIns->mdiscount,$EstIns->drate_ym,$EstIns->mprem,
            $EstIns->iproduct,$EstIns->qday,$EstIns->mexpense,
            $EstIns->mexp_disc,$EstIns->provision,$EstIns->irate,
            $EstIns->adjust_rate,$EstIns->mins_premium_n,
            $EstIns->mpure_prem_n,$EstIns->mprem_n,
            $EstIns->safe_rate,
            $EstIns->manage_rate,$EstIns->educated_rate,
            $EstIns->deviation_rate,$EstIns->Nins_type,
            $EstIns->Prn_deduct, $EstIns->qcoverage, $EstIns->cover_print,
            $EstIns->fdeduct, $EstIns->deduct_print, $EstIns->Daily_pay,$EstIns->Iins_scope,
            $EstIns->Ins_cover, $EstIns->iestimate, $EstIns->fproject;
      if (NOT_FOUND) break;

   	printf("EstIns->iins_type=[%s]\n",EstIns->iins_type);

   	printf("EstIns->Iins_scope=[%s]\n",EstIns->Iins_scope);

   	fprintf(fp1,"%s\t%d\t%d\t%d\t",
         EstIns->iins_type,EstIns->minjured_cover,
   	   EstIns->mdeath_cover,EstIns->mdamage_cover);

      fprintf(fp1,"%d\t%d\t%f\t%d\t%f\t%d\t",
   	   EstIns->mdeduct,EstIns->mins_premium,EstIns->mpure_prem,
   	   EstIns->qserial,EstIns->pcommission,EstIns->mcommission);

      fprintf(fp1,"%f\t%d\t%f\t%d\t%s\t%d\t",
   	   EstIns->pagent,EstIns->magent,EstIns->pdiscount,
   	   EstIns->mdiscount,EstIns->drate_ym,EstIns->mprem);

      fprintf(fp1,"%s\t%d\t%d\t%d\t%s\t%d\t",
   	   EstIns->iproduct,EstIns->qday,EstIns->mexpense,
   	   EstIns->mexp_disc,EstIns->provision,EstIns->irate);

      fprintf(fp1,"%f\t%d\t%d\t%d\t%f\t",
   	   EstIns->adjust_rate,EstIns->mins_premium_n,
   	   EstIns->mpure_prem_n,EstIns->mprem_n,EstIns->safe_rate);

      fprintf(fp1,"%f\t%f\t%f\t%s\t%s\t%d\t%s\t%d\t%s\t%s\n",
   	   EstIns->manage_rate,EstIns->educated_rate,
   	   EstIns->deviation_rate,EstIns->Nins_type,
   	   EstIns->Prn_deduct,EstIns->Daily_pay,EstIns->Iins_scope,
   	   EstIns->Ins_cover,EstIns->iestimate,EstIns->fproject);
   	   printf("EstIns->iins_type=[%s]\n",EstIns->iins_type);
   	   printf("SQL=[%d]\n",SQLCODE);
   }

   if (SQLCODE < 0 ) return SQLCODE;


   $close cur_ins1;
   $free  cur_ins1;

   return SUCCESS;

errexit:
   printf(" est_ins_data_1 errexit = [%d]\n ",SQLCODE);
    sqlfatal();
    return SQLCODE;
} /* end of select_estins_data_1 */

/* ------------------------------------------------------------------------- */
long select_ori_data(reply)
serverReply reply;
{
   $char	DBName[5],iest_bgn[21],iest_end[21],sTmpProv[2],sNprovD[101];
   $char	stmt[8192],stmt1[2048],stmt2[2048],stmt3[1024],stmt4[4096];
   $char        stmt7[1024],stmt8[1024],stmt9[1000];
   $char	stmt_last[1024],FullDB[41],stmtc[8192];
   $struct	estimate	Est;
   $struct	est_ins_assured	Assured;
   $char        tmobile_appl[21],aemail_appl[51];
   $char	ipolicy_list[21],iins_type_list[7],iinsurant_list[11],ninsurant_list[31],dbirth_list[11],nbeneficiary_list[31],relation_bene_list[2],tbenef_list[21],abenef_list[91];
   $char	Fcar_class[2],Ncode[11],Nname[11],Nchi_abv[13];
   $char	Nquota[11],Fcard_class[2],LastOff1[21],LastOff2[21];
   $char tmp_ply[21], tmp_officer[11], sIestimate_c[21], tmp_iestimate[21];
   int	i=0,rc=0, icount1=0, rc1=0, tmp_len=0, icount2=0;
   int   recLen=1024;
   char FullGetName[101], filename[31];
   char sTmp0[71], sTmp1[71], sTmp2[71], file0[71], file1[71],file2[71],sTmp3[71], file4[71],sTmp4[71];
   char rptstr_main[10000], rptstr_dtl[10000];
   char sApHome[31], sGetFileName[101], sFullFileName[201], sTmpTableName[101];
   char *token, *s1;
   time_t now;
   char sUserid[11];
   $int iCount2=0;
   long rtn;
   char sMsg[100];
   $char ninsType[19], sNins_type[128];
   $int  sMcover_limit;
   $char sIassured_cntry[2], sIapplicant_cntry[2];
   $char sIleader[11];
   $char sFapplicant[2];
   $char stmt_iregno[1024],Nreg_no[11],Nreg_no2[22];
   $char stmt_occup1[1024],stmt_occup2[1024],noccup_fullname[126],applicant_noccup_fullname[126];
   $char iprov_all[200],iprov[10],sprov[5],sprov_all[500],sprov_note[50],sprov_note_all[500],iins_prov[7];
   $char fchk_24[2];
   strcpy(fchk_24," ");
   $char *ptr1;
   $char iLastRelative_ply1[21],iLastRelative_ply2[21];
   $int  qviolate = 0;
   $char f20230601[2];
   strcpy(f20230601," ");

   cm_buf_get("%s %s %s %s %s",DBName,iest_bgn, iest_end, sGetFileName,sUserid);

   printf("DBName=[%s],iest_bgn=[%s], iest_end=[%s], sGetFileName=[%s] \n",DBName,iest_bgn, iest_end, sGetFileName);
   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
   {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
         return M_CM_DB_NOTOPEN;
      else
         return apiRC;
   }

   rc = getApHome(sApHome);
   if (rc < 0)
   {
      printf("read Config file error!!\n");
      return exitsub(reply,M_CM_READ_CONFIG_ERR) ? M_CM_READ_CONFIG_ERR : apiRC;
   }
   printf("sGetFileName=[%s]\n",sGetFileName);

   /* �إ�tmp table */
   $select ipolicy, iofficer
      from ori_ply_relation where 1=0 into temp tmp_policy with no log;

   /* ���ǤJ�ɮ�,Ū���ɮפ��e */
   if (strlen(trim(sGetFileName)) > 0)
   {

      /* Ū�ɨüg�Jtmp table */
       sprintf_s(sFullFileName, sizeof sFullFileName, "%s/dat/car/%s", sApHome, sGetFileName);

       printf("sFullFileName=[%s]\n",sFullFileName);

       if ((fptr=fopen(sFullFileName,"rt"))==NULL)
       {
           return 0;
       }

       if ((bp=malloc(recLen))==NULL)
       {
           printf("System malloc failed  !\n");
           free(bp);
           return FAIL;
       }

       while(fgets(bp,recLen,fptr))
       {
           if (feof(fptr)) break;
           i = 0;
           /* ��l�ưѼ� ---------------------------------------------------- */
           memset(tmp_ply, 0x00, sizeof(tmp_ply));
           memset(tmp_officer, 0x00, sizeof(tmp_officer));
           /* --------------------------------------------------------------- */
           token = strtok(bp,"\t");
           printf("token=[%s],strlen(token)=[%d]\n",token,strlen(token));
           while (token != NULL)
           {
               i ++;
               printf("The token[%d] is:[%s]\n", i, token);

               if (i == 1)
               {
                  strcpy(tmp_ply, rtrim(token));    /* �O�渹 */
                  printf("tmp_ply=[%s]\n",tmp_ply);
               }
               else if(i==2)
               {
                 printf("---- �g��N�� ---- \n");
                  strcpy(tmp_officer, rtrim(token));     /* �g��N�� */
                  printf("p1:tmp_officer=[%s]strlen(token)=[%d]\n",tmp_officer,strlen(token));
                  if (strstr(tmp_officer, "\r\n") == NULL)
                  {
                        printf("p2:tmp_officer=[%s]\n",tmp_officer);
                  }
                  else
                  {
                        tmp_officer[strlen(tmp_officer)-2]='\0';
                        printf("p4:tmp_officer=[%s]\n",tmp_officer);
                  }
                  printf("p5:tmp_officer=[%s]\n",tmp_officer);
               }
               else
               {
                  printf("---- other ---- \n");
               }
               token = strtok(NULL,"\t");
           }

           if (i < 2)
           {
               $drop table tmp_policy;
               fclose(fptr);
               SQLCODE = -846;
               return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
           }
           /* �g�J����table */
           printf(" �g�Jtmp table === start \n");
           $insert into tmp_policy
            ( ipolicy, iofficer)
            values
            ( $tmp_ply, $tmp_officer);
           printf(" �g�Jtmp table === end sqlcode=[%d] \n",SQLCODE);
       }
       fclose(fptr);
       printf("Ū�ɧ���!! \n");
   }

   time(&now);
   sprintf_s(sTmp0, sizeof sTmp0,"application_%s%s%ld.txt",DBName,sUserid,now);
   sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,sTmp0);
   fp0=fopen(file0,"w");

   sprintf_s(sTmp1, sizeof sTmp1,"application_%s%s%ld_dtl.txt",DBName,sUserid,now);
   sprintf_s(file1, sizeof file1,"%s/rptftp/%s",sApHome,sTmp1);
   fp1=fopen(file1,"w");

   sprintf_s(sTmp2, sizeof sTmp2,"application_%s%s%ld_provD.txt",DBName,sUserid,now);
   sprintf_s(file2, sizeof file2,"%s/rptftp/%s",sApHome,sTmp2);
   fp2=fopen(file2,"w");

   sprintf_s(sTmp4, sizeof sTmp4,"application_%s%s%ld_list.txt",DBName,sUserid,now);
   sprintf_s(file4, sizeof file4,"%s/rptftp/%s",sApHome,sTmp4);
   fp4=fopen(file4,"w");

/* �s�W�C�L[�Q�O�I�H���k�H�N���H]�B[�n�O�H���k�H�N���H]�B[�n�O�H�P�Q�O�I�H���Y]
	    �B[�n�O�H�ʧO]�B[�n�O�HID]�B[�n�O�H�ͤ�]�B[�n�O�H�q��]������ơC
	    add by sylvia 101.08.21 (1010810004_C1) */
   /* ���N+�j��B��� */
   sprintf_s(stmt, sizeof stmt,
      "select a.itmp_policy, a.icard, ' ', a.irelative_ply, \
              a.ilast_ply, a.ilast_card, ' ', b.ixxcard, \
              a.dply_begin, a.dply_end, ' ',' ', \
              b.fassured, b.iassured, b.iassured_ext, b.nassured, \
              b.ilicense, b.dbirth, b.fsex, b.fmarriage, \
              b.nuser, b.ibenef, b.nbenef, b.aassured, \
              b.aassured_zip, b.itel, f.itel_night, f.mobil_phone, \
              b.apayment, b.apayment_zip, b.iply_area, b.dissue, \
              a.ipro_year||'/'||b.qpro_month::CHAR(2), a.ibrand, b.nbrand_abbr, a.icar_type, \
              ' ', b.ncar_abbr, b.fcar_note, b.qcylinder, \
              b.iengine, b.ibody, b.itag, b.mcar_price, \
              nvl(b.pdmg_align,0), nvl(b.pbrg_align,0), nvl(b.plia_align,0), \
              nvl((nvl(a.mdmg_prem,0) + nvl(a.mlia_prem,0)),0), \
              ' ', a.ibig_comp, a.ibig_branch, a.ibig_office, a.qprovision, \
              a.ibig_sales, a.iresource, a.fdiscount, a.ibroker, \
              ' ', a.iofficer, ' ', a.icorps, \
              a.iarea, a.icashier, a.iexaminer, a.dexamine, \
              (select m.nname from officer m where m.iofficer = a.ientry), \
              f.dentry, a.dapply, b.fcal_way, \
              ' ', a.ipolicy , b.idmg_rate, b.pdmg_factor, \
              b.ibrg_rate, nvl(b.pbrg_factor,0), a.ibranch, b.qpt, \
              b.fpt, b.psex_age, ' ', \
              NVL((SELECT max(psex_age) FROM ori_ins_type WHERE ipolicy = a.ipolicy AND iins_type IN (SELECT iins_type FROM insurance_type WHERE fins_grp = '1' AND iins_type = iins_ply AND iri_ins <> '11')),0),  \
              b.lia_class, \
              nvl(b.plia_acc,' '), ' ', b.dmg_acc_1st, b.dmg_acc_2nd, \
              b.dmg_acc_3rd, nvl(b.pdmg_acc,' '), b.fhuman, b.fcomp_24, \
              a.mbus_rule, a.mbusiness, a.fcomp_class, a.fcomp_class_last, \
              b.iemail, ' ', b.iquery_num ,b.iquery_num_damage, \
              c.fcar_class, c.ncode, d.nname, nvl(e.nchi_abv,g.nchi_abv), \
              b.napplicant, b.mequipment, b.iroute, b.iroute_prop, \
              a.iroute_comm, nvl(b.qlia_acc_sum,0), nvl(b.qdmg_acc_sum,0), \
              b.ndeputy_assured, b.ndeputy_appl, b.nrelation_appl, b.fsex_appl, \
              b.fapplicant, b.iapplicant, b.dbirth_appl, b.itel_appl, a.qdrunk_driving, \
              b.nequipment, nvl(f.fuw_status,500), b.iroute_accept, b.mcover_limit, \
              b.iassured_cntry, b.iapplicant_cntry, a.ileader, \
              b.fequipment1,b.fequipment2,b.fequipment3,b.fequipment4, \
              b.fequipment5,b.fequipment6,b.fequipment9,b.nequipment9, \
              a.feply,a.aemail_eply , b.punknown_acc, b.iquery_num_unknown, \
              b.foccup,b.noccup,b.applicant_foccup,b.applicant_noccup, \
              b.nmile_ubi,b.pubi_acc , \
              case when a.dply_begin < '07/01/2019' then 'Y' else 'N' end, \
              a.tmobile_eply ,b.tmobile_appl,b.aemail_appl,a.feterms,a.qviolate, \
              case when a.dply_begin >= '06/01/2023' then 'Y' else 'N' end \
         from ori_ply_relation a, original_ply b, outer car_type c, \
              outer officer d, outer broker_agent e, outer estimate f, outer broker_agent g \
        where a.ipolicy in (select upper(ipolicy) from tmp_policy) \
          and a.ipolicy = b.ipolicy \
          and a.icar_type = c.icode  \
          and c.fclass = '1' \
          and a.iofficer = d.iofficer \
          and a.icomm_obj = e.ibroker \
          and a.ibroker = g.ibroker \
          and a.ipolicy = f.ipolicy2 \
          and a.fcard_class = '2' \
          and a.ipolicy = f.ipolicy2 \
          and a.iofficer = (select upper(iofficer1) from tmp_policy where upper(ipolicy) = a.ipolicy)  ");

   printf("stmt=[%s]\n", stmt);

   icount1 = 0;
   $PREPARE  perB1 FROM $stmt;
   $DECLARE  curB1 CURSOR FOR perB1;
   $OPEN     curB1;
   while(1)
   {
      $FETCH curB1 INTO
            $Est.iestimate,$Est.icard2,$Est.icard1,$Est.irelative_ply,
            $Est.ilast_ply,$Est.ilast_card,$Est.irelative_card,$Est.ixxcard,
            $Est.dply2_begin,$Est.dply2_end,$Est.dply1_begin,$Est.dply1_end,
            $Est.fassured,$Est.iassured,$Est.iassured_ext,$Est.nassured,
            $Est.ilicense,$Est.dbirth,$Est.fsex,$Est.fmarriage,
            $Est.nuser,$Est.ibenef,$Est.nbenef,$Est.aassured,
            $Est.aassured_zip,$Est.itel,$Est.itel_night,$Est.mobil_phone,
            $Est.apayment,$Est.apayment_zip,$Est.iply_area,$Est.dissue,
            $Est.ipro_year,$Est.ibrand,$Est.nbrand_abbr,$Est.icar_type2,
            $Est.icar_type1,$Est.ncar_abbr,$Est.fcar_note2,$Est.qcylinder,
            $Est.iengine,$Est.ibody,$Est.itag,$Est.mcar_price,
            $Est.pdmg_align,$Est.pbrg_align,$Est.plia_align,$Est.mpremium2,
            $Est.mpremium1,$Est.ibig_comp,$Est.ibig_branch,$Est.ibig_office, $Est.qprovision,
            $Est.ibig_sales,$Est.iresource,$Est.fdiscount,$Est.ibroker2,
            $Est.ibroker1,$Est.iofficer2,$Est.iofficer1,$Est.icorps,
            $Est.iarea,$Est.icashier,$Est.iexaminer,$Est.dexamine,
            $Nquota,$Est.dentry,$Est.dapply,$Est.fcal_way,
            $Est.ipolicy1,$Est.ipolicy2 ,$Est.idmg_rate,$Est.pdmg_factor,
            $Est.ibrg_rate,$Est.pbrg_factor,$Est.ibranch,$Est.qpt,
            $Est.fpt,$Est.psex_age2,$Est.psex_age1,$Est.psex_age_damage,
            $Est.lia_class,$Est.plia_acc2,$Est.plia_acc1,$Est.dmg_acc_1st,
            $Est.dmg_acc_2nd,$Est.dmg_acc_3rd,$Est.pdmg_acc,$Est.fhuman,
            $Est.fcomp_24,$Est.mbus_rule,$Est.mbusiness,$Est.fcomp_class,
            $Est.fcomp_class_last,$Est.iemail,$Est.iquery_num_c,
            $Est.iquery_num ,$Est.iquery_num_damage,
            $Fcar_class,$Ncode,$Nname,$Nchi_abv,
            $Est.napplicant,$Est.mequipment,$Est.iroute, $Est.iroute_prop,
            $Est.iroute_comm2,$Est.qlia_acc_sum,$Est.qdmg_acc_sum,
            $Est.ndeputy_assured, $Est.ndeputy_appl, $Est.nrelation_appl, $Est.fsex_appl,
            $sFapplicant, $Est.iapplicant, $Est.dbirth_appl, $Est.itel_appl, $Est.qdrunk_driving,
            $Est.nequipment, $Est.fuw_status, $Est.iaccept, $sMcover_limit,
            $sIassured_cntry, $sIapplicant_cntry, $sIleader, 
            $fequipment1,$fequipment2,$fequipment3,$fequipment4,
            $fequipment5,$fequipment6,$fequipment9,$nequipment9,
            $feply,$aemail_eply,$punknown_acc,$iquery_num_unknown,
            $Est.foccup, $Est.noccup, $Est.applicant_foccup, $Est.applicant_noccup,
            $Est.nmile_ubi, $Est.pubi_acc,$fchk_24,$Est.tmobile_eply,$tmobile_appl,$aemail_appl,$feterms,$qviolate,$f20230601;

      if(SQLCODE == SQLNOTFOUND)
         break;


      /* �s�W�Ӹ��ˮ�   add by sylvia 103.02.14 (1020924002_C2) */
      iCountDeny=0;
        $select count(*) into $iCountDeny
            from cm_personal_deny
           where iassured = $Est.iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today);
      if(iCountDeny > 0)
         continue;
         
      strcpy(sIleader,trim(sIleader));
	      $SELECT nname
	         INTO $nleader
	         FROM officer
	        WHERE iofficer = $sIleader;
	        
	      if(SQLCODE == SQLNOTFOUND)
	      		strcpy(nleader," ");

/*         
      strcpy(sIleader,trim(sIleader));
         
      if (strcmp(sIleader,sUserid) != 0)
      {
      		/* �O�������ˮ�(�j��) 
      		rtn = chk_spec_deny( Est.ipolicy1, Est.icard1, Est.iassured, Est.iapplicant, Est.itag, Est.iengine, sMsg);
      		if (rtn == M_CA_SPEC_DENY)
         		continue;

      		/* �O�������ˮ�(���N) 
      		rtn = chk_spec_deny( Est.ipolicy2, Est.icard2, Est.iassured, Est.iapplicant, Est.itag, Est.iengine, sMsg);
      		if (rtn == M_CA_SPEC_DENY)
         		continue;
      }
*/
      

      /* 103.04.30 fix*/
      /* ��պ��ɸ�� */
      if (strlen(trim(Est.iestimate)) > 0){

	      $select iestimate, itel_night, mobil_phone, dentry
	         into $tmp_iestimate, $Est.itel_night, $Est.mobil_phone, $Est.dentry
	         from estimate
	        where iestimate = $Est.iestimate;
      }else{

	      $select first 1 iestimate, itel_night, mobil_phone, dentry
	         into $tmp_iestimate, $Est.itel_night, $Est.mobil_phone, $Est.dentry
	         from estimate
	        where ipolicy2 = $Est.ipolicy2 order by dentry desc;
	  }

      if(SQLCODE == SQLNOTFOUND)
      {
          strcpy(tmp_iestimate, " ");
          strcpy(Est.itel_night, " ");
          strcpy(Est.mobil_phone, " ");
          strcpy(Est.dentry, " ");
      }else{
      	  strcpy(Est.iestimate, tmp_iestimate);
      }

      printf("Est.iestimate=[%s]Est.irelative_ply=[%s]\n",Est.iestimate,Est.irelative_ply);
      printf("Est.ipolicy1=[%s]Est.ipolicy2=[%s]\n",Est.ipolicy1,Est.ipolicy2);
      icount1++;

      /* �����s���j���I��� */
      strcpy(Est.irelative_ply, trim(Est.irelative_ply));
      if (strlen(Est.irelative_ply) > 1 )
      {
         $select a.icard, a.icard, a.dply_begin, a.dply_end,
                 a.icar_type, nvl(a.mlia_prem,0), a.ibroker, a.iofficer,
                 a.ipolicy, b.psex_age, nvl(b.plia_acc,' '), b.iquery_num,
                 a.itmp_policy,a.feply
            into $Est.icard1, $Est.irelative_card, $Est.dply1_begin,$Est.dply1_end,
                 $Est.icar_type1, $Est.mpremium1, $Est.ibroker1, $Est.iofficer1,
                 $Est.ipolicy1, $Est.psex_age1, $Est.plia_acc1, $Est.iquery_num_c,
                 $sIestimate_c,$fecard
            from ori_ply_relation a, original_ply b
           where a.ipolicy = b.ipolicy
             and a.fcard_class = '1'
             and a.ipolicy = $Est.irelative_ply;

         if (strlen(trim(sIestimate_c)) == 0)
         {
	     $select first 1 iestimate into $sIestimate_c
	        from estimate  where ipolicy1 = $Est.irelative_ply
	       order by dentry desc;

	     if(SQLCODE == SQLNOTFOUND)
             {
	         strcpy(sIestimate_c, " ");
		 printf(" ********** sIestimate_c=[%s] Est.irelative_ply=[%s]\n", sIestimate_c,Est.irelative_ply);
	     }
       	 }
       	 
       	 if (strcmp(feply,"0")==0)
       	 {
       	     /*���N�Y�O�ȥ����A������p���j���I�H�e����BEmail*/
       	     /*�Y���p���j���I�]�O�ȥ����N��ť�*/
             $SELECT case when feply='1' then aemail_eply else ' ' end,case when feply='1' then tmobile_eply else ' ' end
                INTO $aemail_eply,$Est.tmobile_eply
                FROM ori_ply_relation 
               WHERE ipolicy = $Est.irelative_ply;	
       	 	
       	 }
      }
      else
      {
         strcpy(Est.icard1, " ");
         strcpy(Est.irelative_card, " ");
         strcpy(Est.dply1_begin, " ");
         strcpy(Est.dply1_end, " ");
         strcpy(Est.icar_type1, " ");
         Est.mpremium1 = 0;
         strcpy(Est.ibroker1, " ");
         strcpy(Est.iofficer1, " ");
         strcpy(Est.ipolicy1, " ");
         Est.psex_age1 = 0;
         Est.plia_acc1 = 0.00;
         strcpy(Est.iquery_num_c, " ");
         strcpy(sIestimate_c, " ");
         strcpy(fecard, " ");
      }

      /* �e��j��Υ��N�g�� */
      strcpy(Fcard_class," ");
      strcpy(LastOff1," ");
      strcpy(LastOff2," ");
      if (strlen(rtrim(Est.ilast_ply))!=0) {
   	   strcpy(FullDB,get_dtl_full_db(Est.ilast_ply));
   	   sprintf_s(stmt_last, sizeof stmt_last,
   	      "select x.fcard_class,trim(x.iofficer) || y.nname, "
            "       (select trim(a.iofficer)||b.nname "
            "          from %s:ply_relation a, officer b "
            "         where a.iofficer = b.iofficer "
            "           and x.irelative_ply = a.ipolicy ) "
            "  from %s:ply_relation x, outer officer y "
            " where x.ipolicy = ? "
            "   and x.iofficer = y.iofficer", FullDB,FullDB);

         printf("stmt_last=[%s]\n", stmt_last);

         $prepare pre_lastB1 from $stmt_last;
   	   $execute pre_lastB1
   	       into $Fcard_class,$LastOff1,$LastOff2
            using $Est.ilast_ply;
         if (NOT_FOUND) {
            strcpy(Fcard_class," ");
            strcpy(LastOff1," ");
            strcpy(LastOff2," ");
         }
      }

      strcpy(Est.iestimate, trim(Est.iestimate));
      strcpy(sIestimate_c, trim(sIestimate_c));
      printf("-----sIestimate_c=[%s] Est.irelative_ply=[%s]\n",sIestimate_c,Est.irelative_ply);
      printf("-----Est.qprovision=[%d]\n",Est.qprovision);
      
      /*�e��j����N�O�渹*/
      strcpy(iLastRelative_ply1,"");
      strcpy(iLastRelative_ply2,"");
      strcpy(stmt_last,"");
      if (strlen(rtrim(Est.ilast_ply))!=0) 
      {
		strcpy(FullDB,get_dtl_full_db(Est.ilast_ply));
   	   	sprintf_s(stmt_last, sizeof stmt_last,
		   	    "select (CASE WHEN fcard_class ='1' THEN  ipolicy ELSE nvl(irelative_ply,'') end),"
		   	    "       (CASE WHEN fcard_class ='1' THEN nvl(irelative_ply,'')  ELSE ipolicy end)"
		            "  from %s:ori_ply_relation  "
		            " where ipolicy = ? ", FullDB);

		printf("stmt_last=[%s]\n", stmt_last);

		$prepare pre_LastRelative2_1 from $stmt_last;
		$execute pre_LastRelative2_1
		    into $iLastRelative_ply1,$iLastRelative_ply2 using $Est.ilast_ply;
		if (NOT_FOUND) 
		{
		    strcpy(iLastRelative_ply1," ");
		    strcpy(iLastRelative_ply2," ");
		    break;
		}
      }
      
      provision_J = 0;
      $SELECT COUNT(*)
         INTO $provision_J
         FROM ori_ins_type
        WHERE ipolicy = $Est.ipolicy2
          AND trim(nvl(provision,' '))||';' like '%J;%';
      
      /* �^�����w�r�p�H����(D���ڡ^�W�U  add by sylvia 101.06.21 */
      sNprovD[0]='\0';
      if (Est.qprovision > 0 || provision_J > 0)
      {
      	/*strcpy(sNprovD, "���w�r�p�H�G");*/
      	iCount2 = 0;
      	strcpy(ninsType, "");
      	strcpy(sNins_type, "");
      	sprintf_s(stmt8, sizeof stmt8, "SELECT trim(a.iins_type)||(SELECT nins_abbr FROM insurance_type WHERE iins_type = a.iins_type) \
      	                  FROM ori_ins_type a \
      	                 WHERE a.ipolicy = '%s' \
      	                   AND (trim(nvl(a.provision,' '))||';' like '%%D;%%' or trim(nvl(a.provision,' '))||';' like '%%J;%%') ", Est.ipolicy2);
        $PREPARE  preOriProvD FROM $stmt8;
        $DECLARE  cur_ori_provD CURSOR FOR preOriProvD;
        $OPEN     cur_ori_provD;

        for(;;)
        {
            $FETCH cur_ori_provD INTO $ninsType;
            if(SQLCODE == SQLNOTFOUND)  break;

            iCount2++;

            if (iCount2 == 1)
            {
            	strcpy(sNins_type, trim(ninsType));
            }
            else
            {
            	strcat(sNins_type, ";");
            	strcat(sNins_type, trim(ninsType));
            }
        }
      	$CLOSE  cur_ori_provD;
	$FREE   cur_ori_provD;

	printf("-----sNins_type=[%s], Est.ipolicy2=[%s]\n",sNins_type,Est.ipolicy2);
	strcpy(stmt4, "");
      	sprintf_s(stmt4, sizeof stmt4,"SELECT ipolicy, iins_type, provision, iassured, nassured,\
                              year(dbirth)-1911||to_char(dbirth,'/%%m/%%d') AS dbirth, \
                              nbenef, rel_benef, iserial \
                         FROM ori_ins_assured \
                        WHERE ipolicy = ? \
                          AND (trim(nvl(provision,' '))||';' like '%%D;%%' or trim(nvl(provision,' '))||';' like '%%J;%%')");

	$PREPARE  pre_DP FROM $stmt4;
	$DECLARE  cur_DP CURSOR FOR pre_DP;
	$OPEN     cur_DP USING $Est.ipolicy2;

	for(;;)
	{
	    $FETCH cur_DP INTO
	           $Assured.iestimate, $Assured.iins_type, $Assured.provision,
	           $Assured.iassured, $Assured.nassured, $Assured.dbirth,
	           $Assured.nbenef, $Assured.rel_benef, $Assured.iserial;
	    if(SQLCODE == SQLNOTFOUND)  break;
	            /*iCount2 ++;
	            strcat(sNprovD, rtrim(Assured.nassured));
	            if (iCount2 < Est.qprovision)
	            	strcat(sNprovD,"�B");
	            else
	            	strcat(sNprovD,"�C");*/
	    printf("provD nassured=[%s], iassured[%s], dbirth[%s]\n", Assured.nassured, Assured.iassured, Assured.dbirth);
	    fprintf(fp2,"%s\t%s\t%s\t%s\t%s\n", trim(sNins_type),Assured.nassured,Assured.iassured,Assured.dbirth,Assured.iestimate);
	}
	$close    cur_DP ;
	$free     cur_DP ;
      }/* �^�����w�r�p�H����(D���ڡ^�W�U  end ----------------------- */
      
      
      /* �^���r�p�H�ˮ`�W�U  1090221006_SC4_��_56�r�p�H�W�U */
      	strcpy(stmt9, /*"SELECT a.ipolicy,a.iins_type,a.iassured,a.nassured, "
                      "       CASE b.fassured WHEN '2' THEN '' WHEN '4' THEN '' WHEN '6' THEN ''  ELSE to_char(year(a.dbirth)-1911)||'/'||to_char(a.dbirth,'%m/%d') END ,"
                      "       a.nbenef,a.rel_benef,a.tbenef,a.abenef "
                      "  FROM ori_ins_assured a,original_ply b "
                      " WHERE a.ipolicy=? AND a.ipolicy=b.ipolicy AND a.iins_type IN ('50') "
                      " UNION "*/
                      "SELECT a.ipolicy,a.iins_type,a.iinsurant,a.ninsurant, "
                      "       CASE b.fassured WHEN '2' THEN '' WHEN '4' THEN '' WHEN '6' THEN ''  ELSE to_char(year(a.dbirth)-1911)||'/'||to_char(a.dbirth,'%m/%d') END , "
                      "       a.nbeneficiary,a.relation_bene,a.tbenef,a.abenef "
                      "  FROM ca_pa_ori a,original_ply b "
                      " WHERE a.ipolicy=? AND a.ipolicy=b.ipolicy AND a.iins_type IN ('56','136','266')"
                      " UNION "
                      "SELECT a.ipolicy,a.iins_type,a.iassured,a.nassured, "
                      "       CASE b.fassured WHEN '2' THEN '' WHEN '4' THEN '' WHEN '6' THEN ''  ELSE to_char(year(a.dbirth)-1911)||'/'||to_char(a.dbirth,'%m/%d') END , "
                      "       a.nbenef,a.rel_benef,a.tbenef,a.abenef "
                      "  FROM ori_ins_assured a,original_ply b "
                      " WHERE a.ipolicy=? AND a.ipolicy=b.ipolicy AND a.iins_type IN ('147','561')");
      	printf("stmt9=[%s]\n",stmt9);
 


        $PREPARE  pre_list_ori FROM $stmt9;
	$DECLARE  cur_list_ori CURSOR FOR pre_list_ori;
	$OPEN     cur_list_ori using $Est.ipolicy2,$Est.ipolicy2;
	while(1)
	{
	    $FETCH cur_list_ori INTO $ipolicy_list,$iins_type_list,$iinsurant_list,
	                         $ninsurant_list,$dbirth_list,$nbeneficiary_list,
	                         $relation_bene_list,$tbenef_list,$abenef_list;

	    if(SQLCODE == SQLNOTFOUND)  break;

	    fprintf(fp4,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n", ipolicy_list,iins_type_list,iinsurant_list,ninsurant_list,dbirth_list,nbeneficiary_list,relation_bene_list,tbenef_list,abenef_list);
	}
	$close    cur_list_ori;
	$free     cur_list_ori;
      /* �^���r�p�H�ˮ`�W�U  end ----------------------- */      
      

      /* 97���O�n�O�ѤW��ܡi�䲼ú�ڡj104.04.23 (1040407003_C2) */
      if (equip_cmp(Est.nequipment,"97") == TRUE)
          strcpy(equip97,"Y");
      else
      	  strcpy(equip97,"N");
      	  
      	/******************* 30�I�ةӫO�d�򻡩����e(BEGIN) *******************/
printf("30�I�ةӫO�d�򻡩����eBEGIN\n");

	$SELECT iins_type,mdeduct
	   INTO $iins_type30_301,$deduct_30
	   FROM ori_ins_type
	  WHERE ipolicy = $Est.ipolicy2 
	    AND iins_type in ( '30', '301', '302', '530' );
	    
	if(SQLCODE == SQLNOTFOUND)
	{
		strcpy(str_ins_30," ");
	}
	else
	{
		strcpy(iins_type30_301,trim(iins_type30_301));
		/*�P�_��O���O30�I���٬O301�I��*/
		if( strcmp(iins_type30_301,"30") == 0 )
		{
			flag30_301 = 30;
		}
		else if( strcmp(iins_type30_301,"301") == 0 )
		{
			flag30_301 = 301;
		}
		else if( strcmp(iins_type30_301,"302") == 0 )
		{
			flag30_301 = 302;
		}
        else
        {
            flag30_301 = 530;
        }
		/*�T�{���[�O24*/    
		$SELECT iins_type
		   INTO $iins_type24
		   FROM ori_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type = '24';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��24�I��*/
		{
			flag24=0;
		}
		else
		{
			flag24=1;
		}	
		/*�T�{���[�O55*/
		$SELECT iins_type
		   INTO $iins_type55
		   FROM ori_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type = '55';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
		{
			flag55=0;
		}
		else
		{
			flag55=1;
		}
		/*�T�{���[�O255*/
		$SELECT iins_type
		   INTO $iins_type55
		   FROM ori_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type = '255';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
		{
			flag255=0;
		}
		else
		{
			flag255=1;
		}
		/*�T�{���[�O49 or 177*/
		$SELECT iins_type
		   FROM ori_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type IN ('49','117');
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��49 or 117�I��*/
		{
			flag49117=0;
		}
		else
		{
			flag49117=1;
		}
        /*�T�{���[�O555*/
        $SELECT iins_type
           INTO $iins_type55
           FROM ori_ins_type
          WHERE ipolicy = $Est.ipolicy2
            AND iins_type = '555';
        if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��555�I��*/
        {
            flag555=0;
        }
        else
        {
            flag555=1;
        }

		strcpy(tmp_deduct_30,itoa(deduct_30));
		/* 1080311008_SC4_�ͮĤ��71�_����s�v�I */
		if( (flag30_301 == 302) && (flag55 == 1) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d��]�t:������˳d�����[���ڡC");
            }
            else
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d�򤣥]�t:������˳d�����[���ڡC");
            }
			
		}
		else if( (flag30_301 == 302) && (flag255 == 1) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d��]�t:������˳d���I�C");
            }
            else
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d�򤣥]�t:������˳d���I�C");
            }
			
		}
		
		if( (flag30_301 == 301) && (flag55 == 1) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d���I���[����-��D���W���ӫO�d��]�t:������˳d�����[���ڡC");
            }
            else
            {
            	strcpy(str_ins_30,"�W�B�d���I���[����-��D���W���ӫO�d�򤣥]�t:������˳d�����[���ڡC");
            }
			
		}
		else if( (flag30_301 == 301) && (flag255 == 1) )
		{
            strcpy(str_ins_30,"�W�B�d���I���[����-��D���W���ӫO�d�򤣥]�t:������˳d���I�C");
		}
		
		if( (flag30_301 == 30) && (flag24 == 1) && (flag55 == 1) && (strncmp(fchk_24,"Y",1)==0))
		{
			if ((IsFcomp24(tmp_deduct_30)) && (IsFcomp55(tmp_deduct_30)))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:�ĤT�H�d�����s���v�T�έ�����˳d�����[���ڡC");
            }
			else if (IsFcomp24(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:�ĤT�H�d�����s���v�T���[���ڤ��]�t������˳d�����[���ڡC");
            }
			else if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:������˳d�����[���ڤ��]�t�ĤT�H�d�����s���v�T���[���ڡC");
            }
			else
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:�ĤT�H�d�����s���v�T�έ�����˳d�����[���ڡC");
            }
		}
		else if( (flag30_301 == 30) && (flag24 == 1) && (strncmp(fchk_24,"Y",1)==0))
		{
			if (IsFcomp24(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:�ĤT�H�d�����s���v�T���[���ڡC");
            }
			else
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:�ĤT�H�d�����s���v�T���[���ڡC");
            }		
		}
		else if( (flag30_301 == 30) && ((flag55 == 1)||(flag49117 == 1) ))
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:������˳d�����[���ڡC");
            }
			else
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:������˳d�����[���ڡC");
            }		
		}
		else if( (flag30_301 == 30) && ((flag255 == 1)||(flag49117 == 1) ))
		{
            strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:������˳d���I�C");	
		}

        if((flag30_301 == 530) && (flag555 == 1))
        {
            if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�r�V�Z�W�B�d���I�ӫO�d��]�t�G�r�V�Z������˳d���I�C");
            }
            else
            {
            	strcpy(str_ins_30,"�r�V�Z�W�B�d���I�ӫO�d�򤣥]�t�G�r�V�Z������˳d���I�C");
            }
        }
	}

printf("30�I�ةӫO�d�򻡩����eEND\n");
      /******************* 30�I�ةӫO�d�򻡩����e(END) *********************/
      
      /* 1120316006_SC5_�L��-���N�I���e�{�s�W���@�������������O�N��05�ή��s�X��t�ηs�W���@�����O */
      flag_ambulance55 = 0;
      $SELECT iins_type
         INTO $iins_type55
         FROM ori_ins_type
        WHERE ipolicy = $Est.ipolicy2
          AND iins_type = '55';
      if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
      {
          flag_ambulance55=0;
      }
      else
      {
          flag_ambulance55=1;
      }
      
      if (flag_ambulance55 > 0 && strncmp(Est.icar_type2,"11",2) == 0 && equip_cmp(Est.nequipment,"115") == true && f20230601[0] == 'Y')
      {
      	 if (str_ins_30[0] == '' || str_ins_30[0] == '\0' ) strcat(str_ins_30," ");
      	 strcat(str_ins_30,"�����I�ӫO�d�򤣧t�˱w");
      }
      else 
      {
          
      }
      
      /******************* �t�Ʃ���(BEGIN) ***********************/
      strcpy(outfit_nequipment," ");
      if(strcmp(fequipment1,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B���T");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"���T");
      	}
      }
      
      if(strcmp(fequipment2,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B���c");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"���c");
      	}
      }
      
      if(strcmp(fequipment3,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B�N�����");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"�N�����");
      	}
      }
      
      if(strcmp(fequipment4,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B���ءB����");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"���ءB����");
      	}
      }
      
      if(strcmp(fequipment5,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B�@���t��");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"�@���t��");
      	}
      }
      
      if(strcmp(fequipment6,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B�q�ʨ��q��");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"�q�ʨ��q��");
      	}
      }
      
      if(strcmp(fequipment9,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B");
      		strcat(outfit_nequipment,nequipment9);
      	}
      	else
      	{
      		strcpy(outfit_nequipment,nequipment9);
      	}
      }
      
      printf("outfit_nequipment[%s]\n",outfit_nequipment);
      
      /*1050601008_C2_�s�Wka�q����O��۰ʥN�X�~�ȭ��n���r��*/
	/* ���n���Ҧr��_KA */
	sprintf_s(stmt_iregno, sizeof stmt_iregno, " SELECT ilicence \
			  FROM cm_salesman_log \
			 WHERE ileader = ? and icomm_obj = ileader ");
	$PREPARE prep_iregno_KA_ori FROM $stmt_iregno;
	printf("stmt_iregno[%s]\n",stmt_iregno);
        strcpy(Nreg_no2," ");
        printf("prep_iregno_KA_ori \n");
        if (strncmp(Est.iroute,"KA",2) == 0 && Est.ilast_ply[0] != 0)
        {
		/* �O��q���N����KA*��, �n�]�n�^���n���Ҧr�� */
		$EXECUTE prep_iregno_KA_ori into $Nreg_no using $sIleader;
        	if (SQLCODE == SQLNOTFOUND) strcpy(Nreg_no," "); 
        	strcpy(Nreg_no2,trim(Nreg_no));
        	strcat(Nreg_no2," ");
        	strcat(Nreg_no2,nleader);	
        }
        else
        	strcpy(Nreg_no2," ");

      /******************* �t�Ʃ���(END) ***********************/
      
      /*�����I¾�~*/
      sprintf_s(stmt_occup1, sizeof stmt_occup1, "SELECT (trim(imember)||' '||trim(nmember)) FROM cm_risk_member WHERE itype = 'P' AND fmember = 'P' AND imember = '%s' ",Est.noccup);
      $PREPARE prep_occup_est1 FROM $stmt_occup1;
      $EXECUTE prep_occup_est1 into $noccup_fullname;
      if (SQLCODE == SQLNOTFOUND) strcpy(noccup_fullname," "); 
      
      sprintf_s(stmt_occup2, sizeof stmt_occup2, "SELECT (trim(imember)||' '||trim(nmember)) FROM cm_risk_member WHERE itype = 'P' AND fmember = 'P' AND imember = '%s' ",Est.applicant_noccup);
      $PREPARE prep_occup_est2 FROM $stmt_occup2;
      $EXECUTE prep_occup_est2 into $applicant_noccup_fullname;
      if (SQLCODE == SQLNOTFOUND) strcpy(applicant_noccup_fullname," "); 
      
      printf("noccup_fullname[%s] applicant_noccup_fullname[%s] \n",noccup_fullname,applicant_noccup_fullname); 

     /******���[���ڤ�r����(BEGIN)******/
      
      strcpy(iprov_all," ");
      strcpy(sprov_all," ");
      strcpy(iprov," ");
      strcpy(iins_prov," ");
      strcpy(sprov," ");
      strcpy(sprov_note," ");
      strcpy(sprov_note_all," ");    

      sprintf_s(stmt7, sizeof stmt7, "SELECT trim(nvl(provision,' '))||';',iins_type FROM ori_ins_type WHERE ipolicy = '%s' " , Est.ipolicy2);
      	               
      $PREPARE  preProvision5 FROM $stmt7;
      $DECLARE  cur_provision5 CURSOR FOR preProvision5;
      $OPEN     cur_provision5;

      for(;;)
      {
            $FETCH cur_provision5 INTO $iprov,$iins_prov;
            if(SQLCODE == SQLNOTFOUND)  break;

            if (strstr(trim(iprov),"P;") != NULL)
            {
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'P;','')
		       INTO $iprov
		       FROM systables;
		       	
        	
            }
            else if (strstr(trim(iprov),"Q;") != NULL)
            {
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'Q;','')
		       INTO $iprov
		       FROM systables;	
            }
            else if (strstr(trim(iprov),"M;") != NULL)
            {
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) && 
                    (strcmp(trim(iins_prov),"181")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'M;','')
		       INTO $iprov
		       FROM systables;		
            } 
            else if (strstr(trim(iprov),"Y;") != NULL)
            {
            	/* 1130827011_C04_�s�W�s�t��W�B���[����(Y)(�L��) */
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) && 
                    (strcmp(trim(iins_prov),"198")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'Y;','')
		       INTO $iprov
		       FROM systables;		
            }           
            
              

            strcat(iprov_all, iprov);

      }
      $CLOSE  cur_provision5;
      $FREE   cur_provision5;
      printf("�����[����:iprov_all[%s]\n",trim(iprov_all));
      strcpy(iprov_all,trim(iprov_all));
      
      if (strcmp(iprov_all,";")!=0 && strcmp(iprov_all,"")!=0)
      {
          ptr1 = strtok(iprov_all,";");
	  while(ptr1 != NULL)
	  {
      	      sprintf_s(sprov, sizeof sprov,"'%s',",ptr1);  
      	      strcat(sprov_all,sprov);	  				
	      ptr1 = strtok(NULL, ";");
	  }
				
          strcat(sprov_all,"''");
          
          
          printf("�����[����:sprov_all[%s]\n",trim(sprov_all));
      	
      	  sprintf_s(stmt8, sizeof stmt8, "SELECT trim(nprint)||'�B' FROM ca_provision_main WHERE iprovision NOT IN ('C','E','S') AND iprovision IN (%s)" , trim(sprov_all));
          $PREPARE  preProvision6 FROM $stmt8;
          $DECLARE  cur_provision6 CURSOR FOR preProvision6;
          $OPEN     cur_provision6;   
          
          for(;;)
          {
              $FETCH cur_provision6 INTO $sprov_note;
              if(SQLCODE == SQLNOTFOUND)  break;

              strcat(sprov_note_all, trim(sprov_note));

          }
          $CLOSE  cur_provision6;
          $FREE   cur_provision6;   
          printf("�����[���ڤ���:sprov_note_all[%s]\n",trim(sprov_note_all));	  
      	  strcpy(sprov_note_all,trim(sprov_note_all));
      }


      /******���[���ڤ�r����(END)******/

      /* �g�J��r��,�`�N��춶�Ƕ��Pclient�ݤ@�P ----------------------------- */
      fprintf(fp0,"%s��\t%s��\t%s\t%s\t%s\t",
               Est.iestimate,sIestimate_c,Est.icard2,Est.icard1,Est.irelative_ply);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
                  Est.ilast_ply,Est.ilast_card,Est.irelative_card,Est.ixxcard);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
                  Est.dply2_begin,Est.dply2_end,Est.dply1_begin,Est.dply1_end);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
                  Est.fassured,Est.iassured,Est.iassured_ext,Est.nassured);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	         Est.ilicense,Est.dbirth,Est.fsex,Est.fmarriage);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
      	         Est.nuser,Est.ibenef,Est.nbenef,Est.aassured);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	         Est.aassured_zip,Est.itel,Est.itel_night,Est.mobil_phone);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	         Est.apayment,Est.apayment_zip,Est.iply_area,Est.dissue);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	         Est.ipro_year,Est.ibrand,Est.nbrand_abbr,Est.icar_type2);
      fprintf(fp0,"%s\t%s\t%s\t%.2f\t",
       	         Est.icar_type1,Est.ncar_abbr,Est.fcar_note2,Est.qcylinder);
      fprintf(fp0,"%s\t%s\t%s\t%.1f\t",
       	         Est.iengine,Est.ibody,Est.itag,Est.mcar_price);
      fprintf(fp0,"%d\t%d\t%d\t%d\t",
       	         Est.pdmg_align,Est.pbrg_align,Est.plia_align,Est.mpremium2);
      fprintf(fp0,"%d\t%s\t%s\t%s\t%d\t",
       	         Est.mpremium1,Est.ibig_comp,Est.ibig_branch,Est.ibig_office,Est.qprovision);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	         Est.ibig_sales,Est.iresource,Est.fdiscount,Est.ibroker2);
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
      	         Est.ibroker1,Est.iofficer2,Est.iofficer1,Est.icorps,Nreg_no2);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
      	         Est.iarea,Est.icashier,Est.iexaminer,Est.dexamine);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	         Nquota,Est.dentry,Est.dapply,Est.fcal_way);
      fprintf(fp0,"%s\t%s\t%s\t%.4f\t",
      	         Est.ipolicy1,Est.ipolicy2 ,Est.idmg_rate,Est.pdmg_factor);
      fprintf(fp0,"%s\t%.4f\t%s\t%.1f\t",
      	         Est.ibrg_rate,Est.pbrg_factor,Est.ibranch,Est.qpt);
      fprintf(fp0,"%s\t%f\t%f\t%f\t",
      	         Est.fpt,Est.psex_age2,Est.psex_age1,Est.psex_age_damage);
      fprintf(fp0,"%s\t%.2f\t%.2f\t%d\t",
                  Est.lia_class,Est.plia_acc2,Est.plia_acc1,Est.dmg_acc_1st);
      fprintf(fp0,"%d\t%d\t%.2f\t%s\t",
   	            Est.dmg_acc_2nd,Est.dmg_acc_3rd,Est.pdmg_acc,Est.fhuman);
      fprintf(fp0,"%s\t%f\t%f\t%s\t",
                  Est.fcomp_24,Est.mbus_rule,Est.mbusiness,Est.fcomp_class);
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
                  Est.fcomp_class_last,Est.iemail,Est.iquery_num_c,
                  Est.iquery_num ,Est.iquery_num_damage);
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t%f\t%s\t",
                  Fcar_class,Ncode,Nname,Nchi_abv,
       	         Est.napplicant,Est.mequipment,Est.iroute);
      fprintf(fp0,"%s\t%s\t%d\t%d\t",
                  Est.iroute_prop, Est.iroute_comm2, Est.qlia_acc_sum,
                  Est.qdmg_acc_sum );
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%d\t%s\t%d\t%s\t%s\t%s\t%s\t%d\t",
                  Est.ndeputy_assured, Est.ndeputy_appl, Est.nrelation_appl, Est.fsex_appl,
                  sFapplicant, Est.iapplicant, Est.dbirth_appl, Est.itel_appl, Est.qdrunk_driving, " ",
                  Est.fuw_status, Est.iaccept, equip97, " ","0",sMcover_limit);
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
                  sIassured_cntry, sIapplicant_cntry,nleader,str_ins_30,outfit_nequipment);

      if (strcmp(Fcard_class,"1") == 0)
         fprintf(fp0,"%s\t%s\t",LastOff1,LastOff1);   /* �e�欰�j���I */
      else
         fprintf(fp0,"%s\t%s\t",LastOff2,LastOff1);   /* �e�欰���N�I */
		
	  fprintf(fp0,"%s\t%s\t%s\t%.2f\t%s\t",
                  feply, fecard, aemail_eply, punknown_acc, iquery_num_unknown);
      
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
      		      Est.foccup, noccup_fullname,Est.applicant_foccup,applicant_noccup_fullname);  
      		      
      fprintf(fp0,"%f\t%f\t%s\t%s\t%s\t%s\t",Est.nmile_ubi, Est.pubi_acc, Est.tmobile_eply,sprov_note_all, tmobile_appl, aemail_appl);
      
      fprintf(fp0,"%s\t%s\t%s\t%d\t", iLastRelative_ply1, iLastRelative_ply2, feterms, qviolate);
      
      fprintf(fp0,"%s\t%s\t%s\t%s\n"," "," "," "," "); /* 1120927002_C12_�R�q�ΰӫ~�}�o(�L��)�A�ȸպ⦳ */
                  
      /* �I�ة����� */
      rc1 = select_ori_ins_data_1(Est.ipolicy1, Est.ipolicy2, Est.icar_type2, DBName);
      if (rc1 != SUCCESS)
         break;
   }
   $close curB1;
   $free curB1;

   icount2 = 0;
   /* ��j */
   sprintf_s(stmtc, sizeof stmtc,
      "select a.itmp_policy, ' ', a.icard, ' ', \
              a.ilast_ply, a.ilast_card, ' ', b.ixxcard, \
              ' ',' ', a.dply_begin, a.dply_end, \
              b.fassured, b.iassured, b.iassured_ext, b.nassured, \
              b.ilicense, b.dbirth, b.fsex, b.fmarriage, \
              b.nuser, b.ibenef, b.nbenef, b.aassured, \
              b.aassured_zip, b.itel, f.itel_night, f.mobil_phone, \
              b.apayment, b.apayment_zip, b.iply_area, b.dissue, \
              a.ipro_year||'/'||b.qpro_month::CHAR(2), a.ibrand, b.nbrand_abbr, a.icar_type, \
              a.icar_type, b.ncar_abbr, b.fcar_note, b.qcylinder, \
              b.iengine, b.ibody, b.itag, b.mcar_price, \
              nvl(b.pdmg_align,0), nvl(b.pbrg_align,0), nvl(b.plia_align,0), '0', \
              nvl((nvl(a.mdmg_prem,0) + nvl(a.mlia_prem,0)),0), \
              a.ibig_comp, a.ibig_branch, a.ibig_office, a.qprovision, \
              a.ibig_sales, a.iresource, a.fdiscount, ' ', \
              a.ibroker, a.iofficer, a.iofficer, a.icorps, \
              a.iarea, a.icashier, a.iexaminer, a.dexamine, \
              (select m.nname from officer m where m.iofficer = a.ientry), \
              f.dentry, a.dapply, b.fcal_way, \
              a.ipolicy, ' ', b.idmg_rate, b.pdmg_factor, \
              b.ibrg_rate, nvl(b.pbrg_factor,0), a.ibranch, b.qpt, \
              b.fpt, ' ', b.psex_age, b.psex_age_damage, nvl(b.lia_class,0), \
              '0', nvl(b.plia_acc,'0'), nvl(b.dmg_acc_1st,'0'), nvl(b.dmg_acc_2nd,'0'), \
              nvl(b.dmg_acc_3rd,' '), nvl(b.pdmg_acc,' '), b.fhuman, b.fcomp_24, \
              a.mbus_rule, a.mbusiness, a.fcomp_class, a.fcomp_class_last, \
              b.iemail, b.iquery_num ,' ', b.iquery_num_damage, \
              c.fcar_class, c.ncode, d.nname, nvl(e.nchi_abv,g.nchi_abv), \
              b.napplicant, b.mequipment, b.iroute, b.iroute_prop, \
              a.iroute_comm, nvl(b.qlia_acc_sum,0), nvl(b.qdmg_acc_sum,0), \
              b.ndeputy_assured, b.ndeputy_appl, b.nrelation_appl, b.fsex_appl, \
              b.fapplicant, b.iapplicant, b.dbirth_appl, b.itel_appl, a.qdrunk_driving, \
              b.nequipment, 500, b.iroute_accept, b.mcover_limit, \
              b.iassured_cntry, b.iapplicant_cntry, a.ileader, \
              b.fequipment1,b.fequipment2,b.fequipment3,b.fequipment4, \
              b.fequipment5,b.fequipment6,b.fequipment9,b.nequipment9, \
              a.feply,a.aemail_eply, b.punknown_acc, b.iquery_num_unknown, \
              b.foccup,b.noccup,b.applicant_foccup,b.applicant_noccup, \
              b.nmile_ubi, b.pubi_acc , \
              case when a.dply_begin < '07/01/2019' then 'Y' else 'N' end, \
              a.tmobile_eply ,b.tmobile_appl,b.aemail_appl,a.qviolate \
         from ori_ply_relation a, original_ply b, outer car_type c, \
              outer officer d, outer broker_agent e, outer estimate f, outer broker_agent g \
        where a.ipolicy in (select upper(ipolicy) from tmp_policy)  \
          and a.ipolicy = b.ipolicy \
          and a.icar_type = c.icode  \
          and c.fclass = '1' \
          and a.iofficer = d.iofficer \
          and a.icomm_obj = e.ibroker \
          and a.ibroker = g.ibroker \
          and a.ipolicy = f.ipolicy1 \
          and a.fcard_class = '1' \
          and a.iofficer = (select upper(iofficer1) from tmp_policy where upper(ipolicy) = a.ipolicy)  ");
   printf("stmtc=[%s]\n", stmtc);
   $PREPARE  perC1 FROM $stmtc;
   $DECLARE  curC1 CURSOR FOR perC1;
   $OPEN     curC1;
   while(1)
   {
      $FETCH curC1 INTO
            $sIestimate_c,$Est.icard2,$Est.icard1,$Est.irelative_ply,
            $Est.ilast_ply,$Est.ilast_card,$Est.irelative_card,$Est.ixxcard,
            $Est.dply2_begin,$Est.dply2_end,$Est.dply1_begin,$Est.dply1_end,
            $Est.fassured,$Est.iassured,$Est.iassured_ext,$Est.nassured,
            $Est.ilicense,$Est.dbirth,$Est.fsex,$Est.fmarriage,
            $Est.nuser,$Est.ibenef,$Est.nbenef,$Est.aassured,
            $Est.aassured_zip,$Est.itel,$Est.itel_night,$Est.mobil_phone,
            $Est.apayment,$Est.apayment_zip,$Est.iply_area,$Est.dissue,
            $Est.ipro_year,$Est.ibrand,$Est.nbrand_abbr,$Est.icar_type2,
            $Est.icar_type1,$Est.ncar_abbr,$Est.fcar_note2,$Est.qcylinder,
            $Est.iengine,$Est.ibody,$Est.itag,$Est.mcar_price,
            $Est.pdmg_align,$Est.pbrg_align,$Est.plia_align,$Est.mpremium2,
            $Est.mpremium1,$Est.ibig_comp,$Est.ibig_branch,$Est.ibig_office, $Est.qprovision,
            $Est.ibig_sales,$Est.iresource,$Est.fdiscount,$Est.ibroker2,
            $Est.ibroker1,$Est.iofficer2,$Est.iofficer1,$Est.icorps,
            $Est.iarea,$Est.icashier,$Est.iexaminer,$Est.dexamine,
            $Nquota,$Est.dentry,$Est.dapply,$Est.fcal_way,
            $Est.ipolicy1,$Est.ipolicy2 ,$Est.idmg_rate,$Est.pdmg_factor,
            $Est.ibrg_rate,$Est.pbrg_factor,$Est.ibranch,$Est.qpt,
            $Est.fpt,$Est.psex_age2,$Est.psex_age1,$Est.psex_age_damage,
            $Est.lia_class,$Est.plia_acc2,$Est.plia_acc1,$Est.dmg_acc_1st,
            $Est.dmg_acc_2nd,$Est.dmg_acc_3rd,$Est.pdmg_acc,$Est.fhuman,
            $Est.fcomp_24,$Est.mbus_rule,$Est.mbusiness,$Est.fcomp_class,
            $Est.fcomp_class_last,$Est.iemail,$Est.iquery_num_c,
            $Est.iquery_num ,$Est.iquery_num_damage,
            $Fcar_class,$Ncode,$Nname,$Nchi_abv,
            $Est.napplicant,$Est.mequipment,$Est.iroute, $Est.iroute_prop,
            $Est.iroute_comm2,$Est.qlia_acc_sum,$Est.qdmg_acc_sum,
            $Est.ndeputy_assured, $Est.ndeputy_appl, $Est.nrelation_appl, $Est.fsex_appl,
            $sFapplicant, $Est.iapplicant, $Est.dbirth_appl, $Est.itel_appl, $Est.qdrunk_driving,
            $Est.nequipment, $Est.fuw_status, $Est.iaccept, $sMcover_limit,
            $sIassured_cntry, $sIapplicant_cntry, $sIleader,
            $fequipment1,$fequipment2,$fequipment3,$fequipment4,
            $fequipment5,$fequipment6,$fequipment9,$nequipment9,
            $fecard,$aemail_eply,$punknown_acc,$iquery_num_unknown,
            $Est.foccup, $Est.noccup, $Est.applicant_foccup, $Est.applicant_noccup,
            $Est.nmile_ubi, $Est.pubi_acc,$fchk_24,$Est.tmobile_eply,$tmobile_appl,$aemail_appl,$qviolate;

      if(SQLCODE == SQLNOTFOUND)
         break;

      /* �s�W�Ӹ��ˮ�   add by sylvia 103.02.14 (1020924002_C2) */
      iCountDeny=0;
        $select count(*) into $iCountDeny
            from cm_personal_deny
           where iassured = $Est.iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today);
      if(iCountDeny > 0)
         continue; 
         
      strcpy(sIleader,trim(sIleader));
	      $SELECT nname
	         INTO $nleader
	         FROM officer
	        WHERE iofficer = $sIleader;
	        
	      if(SQLCODE == SQLNOTFOUND)
	      		strcpy(nleader," ");
/*
      strcpy(sIleader,trim(sIleader));
      
      /* �O�������ˮ�(�j��) 
      rtn = chk_spec_deny( Est.ipolicy1, Est.icard1, Est.iassured, Est.iapplicant, sMsg);
      if (rtn == M_CA_SPEC_DENY)
         continue;

      /* �O�������ˮ�(���N) 
      rtn = chk_spec_deny( Est.ipolicy2, Est.icard2, Est.iassured, Est.iapplicant, sMsg);
      if (rtn == M_CA_SPEC_DENY)
         continue;
*/
 			printf("----1302 Est.ipolicy1=[%s]sIestimate_c=[%s]\n",Est.ipolicy1,sIestimate_c);


      /* 103.04.30 fix*/
      /* ��պ��ɸ�� */
      if (strlen(trim(sIestimate_c)) > 0){

	      $select iestimate, itel_night, mobil_phone, dentry
	         into $tmp_iestimate, $Est.itel_night, $Est.mobil_phone, $Est.dentry
	         from estimate
	        where iestimate = $sIestimate_c;
      }else{

	      $select first 1 iestimate, itel_night, mobil_phone, dentry
	         into $tmp_iestimate, $Est.itel_night, $Est.mobil_phone, $Est.dentry
	         from estimate
	        where ipolicy1 = $Est.ipolicy1 order by dentry desc;
	  }

      if(SQLCODE == SQLNOTFOUND)
      {
         strcpy(tmp_iestimate, " ");
         strcpy(Est.itel_night, " ");
         strcpy(Est.mobil_phone, " ");
         strcpy(Est.dentry, " ");
      }else{
      	  strcpy(sIestimate_c, tmp_iestimate);
      }

      printf("sIestimate_c=[%s]Est.irelative_ply=[%s]\n",sIestimate_c,Est.irelative_ply);
      printf("----1320 Est.ipolicy1=[%s]\n",Est.ipolicy1);
      icount2++;


      printf("----1302 Est.ipolicy1=[%s]\n",Est.ipolicy1);

      printf("----1302 Est.ipolicy1=[%s]\n",Est.ipolicy1);
      strcpy(Est.iestimate, trim(Est.iestimate));
      strcpy(sIestimate_c, trim(sIestimate_c));
      printf("-----sIestimate_c=[%s] Est.irelative_ply=[%s]\n",sIestimate_c,Est.irelative_ply);

      strcpy(sNprovD," ");  /* 103.04.30,fix ��j��sNprovD���Q��l�� */

      /* 97���O�n�O�ѤW��ܡi�䲼ú�ڡj104.04.23 (1040407003_C2) */
      if (equip_cmp(Est.nequipment,"97") == TRUE)
          strcpy(equip97,"Y");
      else
      	  strcpy(equip97,"N");
      	  
      /******************* 30�I�ةӫO�d�򻡩����e(BEGIN) *******************/
printf("30�I�ةӫO�d�򻡩����eBEGIN\n");

	$SELECT iins_type,mdeduct
	   INTO $iins_type30_301,$deduct_30
	   FROM ori_ins_type
	  WHERE ipolicy = $Est.ipolicy2
	    AND iins_type in ( '30', '301', '302', '530' );
	    
	if(SQLCODE == SQLNOTFOUND)
	{
		strcpy(str_ins_30," ");
	}
	else
	{
		strcpy(iins_type30_301,trim(iins_type30_301));
		/*�P�_��O���O30�I���٬O301�I��*/
		if( strcmp(iins_type30_301,"30") == 0 )
		{
			flag30_301 = 30;
		}
		else if( strcmp(iins_type30_301,"301") == 0 )
		{
			flag30_301 = 301;
		}
		else if( strcmp(iins_type30_301,"302") == 0 )
		{
			flag30_301 = 302;
		}
        else
        {
            flag30_301 = 530;
        }		
		/*�T�{���[�O24*/    
		$SELECT iins_type
		   INTO $iins_type24
		   FROM ori_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type = '24';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��24�I��*/
		{
			flag24=0;
		}
		else
		{
			flag24=1;
		}
		/*�T�{���[�O255*/
		$SELECT iins_type
		   INTO $iins_type55
		   FROM ori_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type = '255';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��255�I��*/
		{
			flag255=0;
		}
		else
		{
			flag255=1;
		}
		/*�T�{���[�O55*/
		$SELECT iins_type
		   INTO $iins_type55
		   FROM ori_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type = '55';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
		{
			flag55=0;
		}
		else
		{
			flag55=1;
		}
		/*�T�{���[�O49 or 177*/
		$SELECT iins_type
		   FROM ori_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type IN ('49','117');
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��49 or 117�I��*/
		{
			flag49117=0;
		}
		else
		{
			flag49117=1;
		}
        /*�T�{���[�O555*/
		$SELECT iins_type
           INTO $iins_type55
           FROM ori_ins_type
          WHERE ipolicy = $Est.ipolicy2
            AND iins_type = '555';
        if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��555�I��*/
        {
            flag555=0;
        }
        else
        {
            flag555=1;
        }
		strcpy(tmp_deduct_30,itoa(deduct_30));
		/* 1080311008_SC4_�ͮĤ��71�_����s�v�I */
		if( (flag30_301 == 302) && (flag55 == 1) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d��]�t:������˳d�����[���ڡC");
            }
            else
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d�򤣥]�t:������˳d�����[���ڡC");
            }
			
		}
		else if( (flag30_301 == 302) && (flag255 == 1) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d��]�t:������˳d���I�C");
            }
            else
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d�򤣥]�t:������˳d���I�C");
            }
			
		}
		
		if( (flag30_301 == 301) && (flag55 == 1) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d���I���[����-�ӫO�d��]�t:������˳d�����[���ڡC");
            }
            else
            {
            	strcpy(str_ins_30,"�W�B�d���I���[����-�ӫO�d�򤣥]�t:������˳d�����[���ڡC");
            }
			
		}else if( (flag30_301 == 301) && (flag255 == 1) )
		{
            strcpy(str_ins_30,"�W�B�d���I���[����-��D���W���ӫO�d�򤣥]�t:������˳d���I�C");
		}
		
		
		if( (flag30_301 == 30) && (flag24 == 1) && (flag55 == 1) && (strncmp(fchk_24,"Y",1)==0))
		{
			if ((IsFcomp24(tmp_deduct_30)) && (IsFcomp55(tmp_deduct_30)))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:�ĤT�H�d�����s���v�T�έ�����˳d�����[���ڡC");
            }
			else if (IsFcomp24(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:�ĤT�H�d�����s���v�T���[���ڤ��]�t������˳d�����[���ڡC");
            }
			else if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:������˳d�����[���ڤ��]�t�ĤT�H�d�����s���v�T���[���ڡC");
            }
			else
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:�ĤT�H�d�����s���v�T�έ�����˳d�����[���ڡC");
            }
		}
		else if( (flag30_301 == 30) && (flag24 == 1) && (strncmp(fchk_24,"Y",1)==0))
		{
			if (IsFcomp24(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:�ĤT�H�d�����s���v�T���[���ڡC");
            }
			else
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:�ĤT�H�d�����s���v�T���[���ڡC");
            }		
		}
	    else if( (flag30_301 == 30) && ((flag55 == 1)||(flag49117 == 1)) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:������˳d�����[���ڡC");
            }
			else
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:������˳d�����[���ڡC");
            }		
		}
		else if( (flag30_301 == 30) && ((flag255 == 1)||(flag49117 == 1) ))
		{
            strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:������˳d���I�C");	
		}

        if((flag30_301 == 530) && (flag555 == 1))
        {
            if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�r�V�Z�W�B�d���I�ӫO�d��]�t�G�r�V�Z������˳d���I�C");
            }
            else
            {
            	strcpy(str_ins_30,"�r�V�Z�W�B�d���I�ӫO�d�򤣥]�t�G�r�V�Z������˳d���I�C");
            }
        }
	}

printf("30�I�ةӫO�d�򻡩����eEND\n");
      /******************* 30�I�ةӫO�d�򻡩����e(END) *********************/
      	  
      /******************* �t�Ʃ���(BEGIN) ***********************/
      strcpy(outfit_nequipment," ");
      if(strcmp(fequipment1,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B���T");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"���T");
      	}
      }
      
      if(strcmp(fequipment2,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B���c");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"���c");
      	}
      }
      
      if(strcmp(fequipment3,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B�N�����");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"�N�����");
      	}
      }
      
      if(strcmp(fequipment4,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B���ءB����");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"���ءB����");
      	}
      }
      
      if(strcmp(fequipment5,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B�@���t��");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"�@���t��");
      	}
      }
      
      if(strcmp(fequipment6,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B�q�ʨ��q��");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"�q�ʨ��q��");
      	}
      }
      
      if(strcmp(fequipment9,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B");
      		strcat(outfit_nequipment,nequipment9);
      	}
      	else
      	{
      		strcpy(outfit_nequipment,nequipment9);
      	}
      }
      
      printf("outfit_nequipment[%s]\n",outfit_nequipment);

      /******************* �t�Ʃ���(END) ***********************/
      
      /* �j+�� -> ���N�g��H;���  -> ���N�g��H;��j  -> ���N�g��H */
      strcpy(Est.iofficer2,trim(Est.iofficer2));
      if (strlen(Est.iofficer2) == 0)
      {
      	$SELECT nname
      	   INTO $Nname
      	   FROM officer
      	  WHERE iofficer = $Est.iofficer1;
      }
      
      /*�����I¾�~*/
      sprintf_s(stmt_occup1, sizeof stmt_occup1, "SELECT (trim(imember)||' '||trim(nmember)) FROM cm_risk_member WHERE itype = 'P' AND fmember = 'P' AND imember = '%s' ",Est.noccup);
      $PREPARE prep_occup_est1 FROM $stmt_occup1;
      $EXECUTE prep_occup_est1 into $noccup_fullname;
      if (SQLCODE == SQLNOTFOUND) strcpy(noccup_fullname," "); 
      
      sprintf_s(stmt_occup2, sizeof stmt_occup2, "SELECT (trim(imember)||' '||trim(nmember)) FROM cm_risk_member WHERE itype = 'P' AND fmember = 'P' AND imember = '%s' ",Est.applicant_noccup);
      $PREPARE prep_occup_est2 FROM $stmt_occup2;
      $EXECUTE prep_occup_est2 into $applicant_noccup_fullname;
      if (SQLCODE == SQLNOTFOUND) strcpy(applicant_noccup_fullname," "); 
      
      printf("noccup_fullname[%s] applicant_noccup_fullname[%s] \n",noccup_fullname,applicant_noccup_fullname); 


     /******���[���ڤ�r����(BEGIN)******/
      
      strcpy(iprov_all," ");
      strcpy(sprov_all," ");
      strcpy(iprov," ");
      strcpy(iins_prov," ");
      strcpy(sprov," ");
      strcpy(sprov_note," ");
      strcpy(sprov_note_all," ");    

      sprintf_s(stmt7, sizeof stmt7, "SELECT trim(nvl(provision,' '))||';',iins_type FROM ori_ins_type WHERE ipolicy = '%s' " , Est.ipolicy2);
      	               
      $PREPARE  preProvision7 FROM $stmt7;
      $DECLARE  cur_provision7 CURSOR FOR preProvision7;
      $OPEN     cur_provision7;

      for(;;)
      {
            $FETCH cur_provision7 INTO $iprov,$iins_prov;
            if(SQLCODE == SQLNOTFOUND)  break;

            if (strstr(trim(iprov),"P;") != NULL)
            {
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'P;','')
		       INTO $iprov
		       FROM systables;
		       	
        	
            }
            else if (strstr(trim(iprov),"Q;") != NULL)
            {
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'Q;','')
		       INTO $iprov
		       FROM systables;	
            }
            else if (strstr(trim(iprov),"M;") != NULL)
            {
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) && 
                    (strcmp(trim(iins_prov),"181")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'M;','')
		       INTO $iprov
		       FROM systables;		
            }   
            else if (strstr(trim(iprov),"Y;") != NULL)
            {
            	/* 1130827011_C04_�s�W�s�t��W�B���[����(Y)(�L��) */
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) && 
                    (strcmp(trim(iins_prov),"198")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'Y;','')
		       INTO $iprov
		       FROM systables;		
            }        

            strcat(iprov_all, iprov);

      }
      $CLOSE  cur_provision7;
      $FREE   cur_provision7;
      printf("�����[����:iprov_all[%s]\n",trim(iprov_all));
      strcpy(iprov_all,trim(iprov_all));
      
      if (strcmp(iprov_all,";")!=0 && strcmp(iprov_all,"")!=0)
      {
          ptr1 = strtok(iprov_all,";");
	  while(ptr1 != NULL)
	  {
      	      sprintf_s(sprov, sizeof sprov,"'%s',",ptr1);  
      	      strcat(sprov_all,sprov);	  				
	      ptr1 = strtok(NULL, ";");
	  }
				
          strcat(sprov_all,"''");
          printf("�����[����:sprov_all[%s]\n",trim(sprov_all));
      	
      	  sprintf_s(stmt8, sizeof stmt8, "SELECT trim(nprint)||'�B' FROM ca_provision_main WHERE iprovision NOT IN ('C','E','S') AND iprovision IN (%s)" , trim(sprov_all));
          $PREPARE  preProvision8 FROM $stmt8;
          $DECLARE  cur_provision8 CURSOR FOR preProvision8;
          $OPEN     cur_provision8;   
          
          for(;;)
          {
              $FETCH cur_provision8 INTO $sprov_note;
              if(SQLCODE == SQLNOTFOUND)  break;

              strcat(sprov_note_all, trim(sprov_note));

          }
          $CLOSE  cur_provision8;
          $FREE   cur_provision8;   
          printf("�����[���ڤ���:sprov_note_all[%s]\n",trim(sprov_note_all));	  
      	  strcpy(sprov_note_all,trim(sprov_note_all));
      }


      /******���[���ڤ�r����(END)******/
      
      
      /*�e��j����N�O�渹*/
      strcpy(iLastRelative_ply1,"");
      strcpy(iLastRelative_ply2,"");
      strcpy(stmt_last,"");
      if (strlen(rtrim(Est.ilast_ply))!=0) 
      {
		strcpy(FullDB,get_dtl_full_db(Est.ilast_ply));
   	   	sprintf_s(stmt_last, sizeof stmt_last,
		   	    "select (CASE WHEN fcard_class ='1' THEN  ipolicy ELSE nvl(irelative_ply,'') end),"
		   	    "       (CASE WHEN fcard_class ='1' THEN nvl(irelative_ply,'')  ELSE ipolicy end)"
		            "  from %s:ori_ply_relation  "
		            " where ipolicy = ? ", FullDB);

		printf("stmt_last=[%s]\n", stmt_last);

		$prepare pre_LastRelative2 from $stmt_last;
		$execute pre_LastRelative2
		    into $iLastRelative_ply1,$iLastRelative_ply2 using $Est.ilast_ply;
		if (NOT_FOUND) 
		{
		    strcpy(iLastRelative_ply1," ");
		    strcpy(iLastRelative_ply2," ");
		    break;
		}
      }

      printf("----1302 Est.ipolicy1=[%s]\n",Est.ipolicy1);
      /* �g�J��r��,�`�N��춶�Ƕ��Pclient�ݤ@�P ----------------------------- */
      fprintf(fp0,"%s��\t%s��\t%s\t%s\t%s\t",
               sIestimate_c,sIestimate_c,Est.icard2,Est.icard1,Est.irelative_ply);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
                  Est.ilast_ply,Est.ilast_card,Est.irelative_card,Est.ixxcard);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
                  Est.dply2_begin,Est.dply2_end,Est.dply1_begin,Est.dply1_end);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
                  Est.fassured,Est.iassured,Est.iassured_ext,Est.nassured);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	         Est.ilicense,Est.dbirth,Est.fsex,Est.fmarriage);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
      	         Est.nuser,Est.ibenef,Est.nbenef,Est.aassured);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	         Est.aassured_zip,Est.itel,Est.itel_night,Est.mobil_phone);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	         Est.apayment,Est.apayment_zip,Est.iply_area,Est.dissue);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	         Est.ipro_year,Est.ibrand,Est.nbrand_abbr,Est.icar_type2);
      fprintf(fp0,"%s\t%s\t%s\t%.2f\t",
       	         Est.icar_type1,Est.ncar_abbr,Est.fcar_note2,Est.qcylinder);
      fprintf(fp0,"%s\t%s\t%s\t%.1f\t",
       	         Est.iengine,Est.ibody,Est.itag,Est.mcar_price);
      fprintf(fp0,"%d\t%d\t%d\t%d\t",
       	         Est.pdmg_align,Est.pbrg_align,Est.plia_align,Est.mpremium2);
      fprintf(fp0,"%d\t%s\t%s\t%s\t%d\t",
       	         Est.mpremium1,Est.ibig_comp,Est.ibig_branch,Est.ibig_office,0);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	         Est.ibig_sales,Est.iresource,Est.fdiscount,Est.ibroker2);
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
      	         Est.ibroker1,Est.iofficer2,Est.iofficer1,Est.icorps," ");
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
      	         Est.iarea,Est.icashier,Est.iexaminer,Est.dexamine);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	         Nquota,Est.dentry,Est.dapply,Est.fcal_way);
  		printf("----1471 Est.ipolicy1=[%s]\n",Est.ipolicy1);
      fprintf(fp0,"%s\t%s\t%s\t%.4f\t",
      	         Est.ipolicy1,Est.ipolicy2 ,Est.idmg_rate,Est.pdmg_factor);
      fprintf(fp0,"%s\t%.4f\t%s\t%.1f\t",
      	         Est.ibrg_rate,Est.pbrg_factor,Est.ibranch,Est.qpt);
      fprintf(fp0,"%s\t%f\t%f\t%f\t",
      	         Est.fpt,0.0,Est.psex_age1,Est.psex_age_damage);
      fprintf(fp0,"%s\t%.2f\t%.2f\t%d\t",
                  Est.lia_class,Est.plia_acc2,Est.plia_acc1,Est.dmg_acc_1st);
      fprintf(fp0,"%d\t%d\t%.2f\t%s\t",
   	            Est.dmg_acc_2nd,Est.dmg_acc_3rd,Est.pdmg_acc,Est.fhuman);
      fprintf(fp0,"%s\t%f\t%f\t%s\t",
                  Est.fcomp_24,Est.mbus_rule,Est.mbusiness,Est.fcomp_class);
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
                  Est.fcomp_class_last,Est.iemail,Est.iquery_num_c,
                  Est.iquery_num ,Est.iquery_num_damage);
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t%f\t%s\t",
                  Fcar_class,Ncode,Nname,Nchi_abv,
       	         Est.napplicant,Est.mequipment,Est.iroute);
      fprintf(fp0,"%s\t%s\t%d\t%d\t",
                  Est.iroute_prop, Est.iroute_comm2, Est.qlia_acc_sum,
                  Est.qdmg_acc_sum );
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%d\t%s\t%d\t%s\t%s\t%s\t%s\t%d\t",
                  Est.ndeputy_assured, Est.ndeputy_appl, Est.nrelation_appl, Est.fsex_appl,
                  sFapplicant, Est.iapplicant, Est.dbirth_appl, Est.itel_appl, Est.qdrunk_driving, " ",
                  Est.fuw_status, Est.iaccept, equip97, " ","0",sMcover_limit);
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
                  sIassured_cntry, sIapplicant_cntry,nleader,str_ins_30,outfit_nequipment);

      if (strcmp(Fcard_class,"1") == 0)
         fprintf(fp0,"%s\t%s\t",LastOff1,LastOff1);   /* �e�欰�j���I */
      else
         fprintf(fp0,"%s\t%s\t",LastOff2,LastOff1);   /* �e�欰���N�I */
	
      fprintf(fp0,"%s\t%s\t%s\t%.2f\t%s\t",
      		      " ",fecard, aemail_eply, punknown_acc, iquery_num_unknown);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
      		      Est.foccup, noccup_fullname,Est.applicant_foccup,applicant_noccup_fullname);
      		      
      fprintf(fp0,"%f\t%f\t%s\t%s\t%s\t%s\t",Est.nmile_ubi, Est.pubi_acc, Est.tmobile_eply," ", tmobile_appl, aemail_appl);
      
      fprintf(fp0,"%s\t%s\t%s\t%d\t", iLastRelative_ply1, iLastRelative_ply2, "0",qviolate);	
      
      fprintf(fp0,"%s\t%s\t%s\t%s\n"," "," "," "," "); /* 1120927002_C12_�R�q�ΰӫ~�}�o(�L��)�A�ȸպ⦳ */     
      		      
      /* �I�ة����� */
      rc1 = select_ori_ins_data_1(Est.ipolicy1, ' ', Est.icar_type1, DBName);
      if (rc1 != SUCCESS)
         break;
   }
   $close curC1;
   $free curC1;

   fclose(fp0);
   fclose(fp1);
   fclose(fp2);
   fclose(fp4);
   $drop table tmp_policy;


   if (rc1 != SUCCESS)
       return rc1;

   if ((icount1+icount2) == 0)
   {
      if(exitsub(reply,M_CM_NOT_FOUND) == True)
         return M_CM_NOT_FOUND;
      else
         return apiRC;
   }

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   cm_buf_put("%s %s %s %s",sTmp0,sTmp1,sTmp2, sTmp4);

   tmp_len = cm_buf_len(ReplyBuf);
   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
   else
         return api_OKComplete;

errexit:
   printf(" AAAAAAAAAAAAAAAAAAa = [%d]\n ",SQLCODE);
   fclose(fp0);
   fclose(fp1);
   fclose(fp2);
   fclose(fp4);
   sqlfatal();

   return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
} /* end of select_estimate_data */

/* -------------------------------------------------------------------------- */

long select_ori_ins_data_1(fipolicy1, fipolicy2, ficar_type, fdbname)
char *fipolicy1, *fipolicy2, *ficar_type, *fdbname;
{
   $char	DBName[5],iest1[21],iest2[21],icar_type[3];
   $char	stmt[8192],stmt1[2048],stmt2[2048],stmt3[1024];
   $struct	est_ins_type   *EstIns;
   int	i=0, rc=0;
   int	tmp_len=0;
   char FullGetName[101], filename[31];
   char sTmp0[71], sTmp1[71], sTmp2[71], file0[71], file1[71];
   char rptstr_main[10000], rptstr_dtl[10000];
   char sApHome[31];


   $WHENEVER SQLERROR GOTO errexit;
   strcpy(DBName, fdbname);

   if (db_select(DBName) == False)
         return M_CM_DB_NOTOPEN;

   memset(&EstIns,0, sizeof(EstIns));
   EstIns=(struct est_ins_type *)malloc(sizeof(struct est_ins_type));

   strcpy(iest1, fipolicy1);
   strcpy(iest2, fipolicy2);
   strcpy(icar_type, ficar_type);

   printf(" ------ iest1=[%s] iest2=[%s] icar_type=[%s]\n",iest1, iest2, icar_type);

      strcpy(stmt2,
         " case when a.iins_type in ('56','136','166','266') then (select max(daily_pay) "
         "      from ca_pa_ori d where a.ipolicy = d.ipolicy "
         "       and a.iins_type = d.iins_type) else 0 end as daily_pay, "
         " case when a.iins_type in ('56','136','166','35','266') then (select distinct iins_scope "
         "      from ca_pa_ori f where a.ipolicy = f.ipolicy "
         "       and a.iins_type = f.iins_type) else '0' end as iins_scope, "
         " (select count(*) from insurance_cover e "
         "   where a.iins_type = e.iins_type) as insurance_cover, a.ipolicy, ' ' ");
      strcpy(stmt3,
         " from ori_ins_type a, outer insurance_type b "
         "where (ipolicy = ? or ipolicy = ?) "
         "  and a.iins_type = b.iins_type "
         "order by qserial ");


   strcpy(stmt1,
      "select a.iins_type,a.minjured_cover,a.mdeath_cover,a.mdamage_cover, "
      "       a.mdeduct,a.mins_premium,a.mpure_prem,a.qserial, "
      "       a.pcommission,a.mcommission,a.pagent,a.magent, "
      "       a.pdiscount,a.mdiscount,a.drate_ym,a.mprem, "
      "       a.iproduct,a.qday,a.mexpense,a.mexp_disc, "
      "       a.provision,a.irate,a.adjust_rate,a.mins_premium_n, "
      "       a.mpure_prem_n,a.mprem_n,a.safe_rate,a.manage_rate, "
      "       a.educated_rate,a.deviation_rate,b.nins_type, "
      "       case when a.iins_type in ('01','05','08','09','120','122','125','126','131','132','201','205','209','331','332') then "
      "            (select prn_deduct from ca_dmg_mdeduct c "
      "              where c.icar_type = ? and c.ideduct = a.mdeduct) "
      "            when b.fdeduct = '0' then '�L' "
      "       else a.mdeduct::varchar(20) end as prn_deduct, "
      "       b.qcoverage, b.cover_print, b.fdeduct, b.deduct_print, ");

   strcpy(stmt,rtrim(stmt1));
   strcat(stmt,rtrim(stmt2));
   strcat(stmt,rtrim(stmt3));

   printf("2:stmt=[%s]\n",stmt);

   $prepare pre_stmt from $stmt;
   $declare cur_insB1 cursor for pre_stmt;
   $open    cur_insB1 using $icar_type,$iest1,$iest2;

   /* �g�J��r��,�`�N��춶�Ƕ��Pclient�ݤ@�P ----------------------------- */
   for(i=0;;i++)
   {
      $fetch cur_insB1 into
            $EstIns->iins_type,$EstIns->minjured_cover,
            $EstIns->mdeath_cover,$EstIns->mdamage_cover,
            $EstIns->mdeduct,$EstIns->mins_premium,
            $EstIns->mpure_prem, $EstIns->qserial,
            $EstIns->pcommission,$EstIns->mcommission,
            $EstIns->pagent,$EstIns->magent,$EstIns->pdiscount,
            $EstIns->mdiscount,$EstIns->drate_ym,$EstIns->mprem,
            $EstIns->iproduct,$EstIns->qday,$EstIns->mexpense,
            $EstIns->mexp_disc,$EstIns->provision,$EstIns->irate,
            $EstIns->adjust_rate,$EstIns->mins_premium_n,
            $EstIns->mpure_prem_n,$EstIns->mprem_n,
            $EstIns->safe_rate,
            $EstIns->manage_rate,$EstIns->educated_rate,
            $EstIns->deviation_rate,$EstIns->Nins_type,
            $EstIns->Prn_deduct, $EstIns->qcoverage, $EstIns->cover_print,
            $EstIns->fdeduct, $EstIns->deduct_print, $EstIns->Daily_pay,$EstIns->Iins_scope,
            $EstIns->Ins_cover, $EstIns->iestimate, $EstIns->fproject;
      if (NOT_FOUND) break;

   	printf("EstIns->iins_type=[%s]\n",EstIns->iins_type);

   	fprintf(fp1,"%s\t%d\t%d\t%d\t",
         EstIns->iins_type,EstIns->minjured_cover,
   	   EstIns->mdeath_cover,EstIns->mdamage_cover);

      fprintf(fp1,"%d\t%d\t%f\t%d\t%f\t%d\t",
   	   EstIns->mdeduct,EstIns->mins_premium,EstIns->mpure_prem,
   	   EstIns->qserial,EstIns->pcommission,EstIns->mcommission);

      fprintf(fp1,"%f\t%d\t%f\t%d\t%s\t%d\t",
   	   EstIns->pagent,EstIns->magent,EstIns->pdiscount,
   	   EstIns->mdiscount,EstIns->drate_ym,EstIns->mprem);

      fprintf(fp1,"%s\t%d\t%d\t%d\t%s\t%d\t",
   	   EstIns->iproduct,EstIns->qday,EstIns->mexpense,
   	   EstIns->mexp_disc,EstIns->provision,EstIns->irate);

      fprintf(fp1,"%f\t%d\t%d\t%d\t%f\t",
   	   EstIns->adjust_rate,EstIns->mins_premium_n,
   	   EstIns->mpure_prem_n,EstIns->mprem_n,EstIns->safe_rate);


	  if (strlen(trim(iest2)) > 0 )
	  {
	  		fprintf(fp1,"%f\t%f\t%f\t%s\t%s\t%d\t%s\t%d\t%s\t%s\n",
   	   EstIns->manage_rate,EstIns->educated_rate,
   	   EstIns->deviation_rate,EstIns->Nins_type,
   	   EstIns->Prn_deduct,EstIns->Daily_pay,EstIns->Iins_scope,
   	 EstIns->Ins_cover,iest2,EstIns->fproject);}
	  else
	  	{
   		fprintf(fp1,"%f\t%f\t%f\t%s\t%s\t%d\t%s\t%d\t%s\t%s\n",
   	   EstIns->manage_rate,EstIns->educated_rate,
   	   EstIns->deviation_rate,EstIns->Nins_type,
   	   EstIns->Prn_deduct,EstIns->Daily_pay,EstIns->Iins_scope,
   	 EstIns->Ins_cover,iest1,EstIns->fproject);}

   	   printf("EstIns->iins_type=[%s]\n",EstIns->iins_type);
   }
   $close cur_insB1;
   $free  cur_insB1;

   return SUCCESS;

errexit:
   printf(" BBBBBBBBBBBBBBBBBBB = [%d]\n ",SQLCODE);
    sqlfatal();
    return SQLCODE;
} /* end of select_estins_data_1 */


/* ------------------------------------------------------------------------ */
long select_ply_data(reply)
serverReply reply;
{
   $char	DBName[5],iest_bgn[21],iest_end[21],sTmpProv[2],sNprovD[101];
   $char	stmt[8192],stmt1[2048],stmt2[2048],stmt3[1024],stmt4[500],stmt5[1000];
   $char        stmt6[1024],stmt7[1024],stmt8[1024],stmt9[1000];
   $char	stmt_last[1024],FullDB[41],stmtc[8192],sFcard_class[2];
   $struct	estimate	Est;
   $struct	est_ins_assured	Assured;
   $char        tmobile_appl[21],aemail_appl[51];
   $char	ipolicy_list[21],iins_type_list[7],iinsurant_list[11],ninsurant_list[31],dbirth_list[11],nbeneficiary_list[31],relation_bene_list[2],tbenef_list[21],abenef_list[91];
   $char	Fcar_class[2],Ncode[11],Nname[11],Nchi_abv[13];
   $char	Nquota[11],Fcard_class[2],LastOff1[21],LastOff2[21];
   $char tmp_ply[21], tmp_officer[11], sIestimate_c[21], tmp_iestimate[21];
   $char sIsys[2], sIpolicy[21], sBarcode_type[9];
   int	i=0,rc=0, icount1=0, rc1=0, tmp_len=0, icount2=0;
   int   recLen=1024;
   char FullGetName[101], filename[31];
   char sTmp0[71], sTmp1[71], sTmp2[71],sTmp3[71],sTmp4[71], file0[71], file1[71],file2[71],file3[71],file4[71];
   char rptstr_main[10000], rptstr_dtl[10000];
   char sApHome[31], sGetFileName[101], sFullFileName[201], sTmpTableName[101];
   char *token, *s1;
   time_t now;
   char sUserid[11];
   $int iCount2=0;
   long rtn=0;
   char sMsg[100];
   $char ninsType[19], sNins_type[128];
   $int  sMcover_limit=0;
   $char sIassured_cntry[2], sIapplicant_cntry[2];
   $char sIleader[11];
   $char sFapplicant[2];
   $char stmt_iregno[1024],Nreg_no[22],Nreg_no2[25];
   $char stmt_occup1[1024],stmt_occup2[1024],noccup_fullname[126],applicant_noccup_fullname[126];
   $char iprov_all[200],iprov[10],sprov[5],sprov_all[500],sprov_note[50],sprov_note_all[500],iins_prov[7];
   $char fchk_24[2];
   $char *ptr1;
   strcpy(fchk_24," ");
   $char iLastRelative_ply1[21],iLastRelative_ply2[21];
   $int  qviolate = 0;
   $char f20230601[2];
   strcpy(f20230601," ");

   printf("------- select_ply_data strat ------------------------------ \n");

   cm_buf_get("%s %s %s %s %s",DBName,iest_bgn, iest_end, sGetFileName,sUserid);

   printf("DBName=[%s],iest_bgn=[%s], iest_end=[%s], sGetFileName=[%s] \n",DBName,iest_bgn, iest_end, sGetFileName);
   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
   {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
         return M_CM_DB_NOTOPEN;
      else
         return apiRC;
   }

   rc = getApHome(sApHome);
   if (rc < 0)
   {
      printf("read Config file error!!\n");
      return exitsub(reply,M_CM_READ_CONFIG_ERR) ? M_CM_READ_CONFIG_ERR : apiRC;
   }
   printf("sGetFileName=[%s]\n",sGetFileName);



   /* �إ�tmp table */
   $select ipolicy, iofficer
      from ply_relation where 1=0 into temp tmp_policy with no log;

   /* ���ǤJ�ɮ�,Ū���ɮפ��e */
   if (strlen(trim(sGetFileName)) > 0)
   {

      /* Ū�ɨüg�Jtmp table */
       sprintf_s(sFullFileName, sizeof sFullFileName, "%s/dat/car/%s", sApHome, sGetFileName);

       printf("sFullFileName=[%s]\n",sFullFileName);

       if ((fptr=fopen(sFullFileName,"rt"))==NULL)
       {
           return 0;
       }

       if ((bp=malloc(recLen))==NULL)
       {
           printf("System malloc failed  !\n");
           free(bp);
           return FAIL;
       }

       while(fgets(bp,recLen,fptr))
       {
           if (feof(fptr)) break;
           i = 0;
           /* ��l�ưѼ� ---------------------------------------------------- */
           memset(tmp_ply, 0x00, sizeof(tmp_ply));
           memset(tmp_officer, 0x00, sizeof(tmp_officer));
           /* --------------------------------------------------------------- */
           token = strtok(bp,"\t");
           printf("token=[%s],strlen(token)=[%d]\n",token,strlen(token));
           while (token != NULL)
           {
               i ++;
               printf("The token[%d] is:[%s]\n", i, token);

               if (i == 1)
               {
                  strcpy(tmp_ply, rtrim(token));    /* �O�渹 */
                  printf("tmp_ply=[%s]\n",tmp_ply);
               }
               else if(i==2)
               {
                 printf("---- �g��N�� ---- \n");
                  strcpy(tmp_officer, rtrim(token));     /* �g��N�� */
                  printf("p1:tmp_officer=[%s]strlen(token)=[%d]\n",tmp_officer,strlen(token));
                  if (strstr(tmp_officer, "\r\n") == NULL)
                  {
                        printf("p2:tmp_officer=[%s]\n",tmp_officer);
                  }
                  else
                  {
                        tmp_officer[strlen(tmp_officer)-2]='\0';
                        printf("p4:tmp_officer=[%s]\n",tmp_officer);
                  }
                  printf("p5:tmp_officer=[%s]\n",tmp_officer);
               }
               else
               {
                  printf("---- other ---- \n");
               }
               token = strtok(NULL,"\t");
           }

           if (i < 2)
           {
               $drop table tmp_policy;
               fclose(fptr);
               SQLCODE = -846;
               return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
           }
           /* �g�J����table */
           printf(" �g�Jtmp table === start \n");
           $insert into tmp_policy
            ( ipolicy, iofficer)
            values
            ( $tmp_ply, $tmp_officer);
           printf(" �g�Jtmp table === end sqlcode=[%d] \n",SQLCODE);
       }
       fclose(fptr);
       printf("Ū�ɧ���!! \n");
   }

   time(&now);
   sprintf_s(sTmp0, sizeof sTmp0,"application_%s%s%ld.txt",DBName,sUserid,now);
   sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,sTmp0);
   fp0=fopen(file0,"w");

   sprintf_s(sTmp1, sizeof sTmp1,"application_%s%s%ld_dtl.txt",DBName,sUserid,now);
   sprintf_s(file1, sizeof file1,"%s/rptftp/%s",sApHome,sTmp1);
   fp1=fopen(file1,"w");

   sprintf_s(sTmp2, sizeof sTmp2,"application_%s%s%ld_provD.txt",DBName,sUserid,now);
   sprintf_s(file2, sizeof file2,"%s/rptftp/%s",sApHome,sTmp2);
   fp2=fopen(file2,"w");

   sprintf_s(sTmp4, sizeof sTmp4,"application_%s%s%ld_list.txt",DBName,sUserid,now);
   sprintf_s(file4, sizeof file4,"%s/rptftp/%s",sApHome,sTmp4);
   fp4=fopen(file4,"w");
   
   /* �ɤWitel_night�Bmobil_phone (1101201016_SC1) */
   sprintf_s(stmt, sizeof stmt,
      "select a.itmp_policy, decode(a.fcard_class,'2',a.icard,' '), \
              decode(a.fcard_class,'1',a.icard,' '), a.irelative_ply, \
              a.ilast_ply, a.ilast_card, ' ', b.ixxcard, \
              decode(a.fcard_class,'2',to_char(a.dply_begin),' '), \
              decode(a.fcard_class,'2',to_char(a.dply_end),' '), \
              decode(a.fcard_class,'1',to_char(a.dply_begin),' '), \
              decode(a.fcard_class,'1',to_char(a.dply_end),' '), \
              b.fassured, b.iassured, b.iassured_ext, b.nassured, \
              b.ilicense, b.dbirth, b.fsex, b.fmarriage, \
              b.nuser, b.ibenef, b.nbenef, b.aassured, \
              b.aassured_zip, b.itel, b.itel_night, b.mobil_phone, \
              b.apayment, b.apayment_zip, b.iply_area, b.dissue, \
              a.ipro_year||'/'||b.qpro_month::CHAR(2), a.ibrand, b.nbrand_abbr, \
              decode(a.fcard_class,'2',a.icar_type,' '), \
              decode(a.fcard_class,'1',a.icar_type,' '), \
              b.ncar_abbr, b.fcar_note, b.qcylinder, \
              b.iengine, b.ibody, b.itag, b.mcar_price, \
              nvl(b.pdmg_align,0), nvl(b.pbrg_align,0), nvl(b.plia_align,0), \
              decode(a.fcard_class,'2',(a.mdmg_prem + a.mlia_prem),0), \
              decode(a.fcard_class,'1',(a.mdmg_prem + a.mlia_prem),0), \
              a.ibig_comp, a.ibig_branch, a.ibig_office, a.qprovision, \
              a.ibig_sales, a.iresource, a.fdiscount, \
              decode(a.fcard_class,'2',a.ibroker,' '), \
              decode(a.fcard_class,'1',a.ibroker,' '), \
              decode(a.fcard_class,'2',a.iofficer,' '), \
              decode(a.fcard_class,'1',a.iofficer,' '), a.icorps, \
              a.iarea, a.icashier, a.iexaminer, a.dexamine, \
              (select m.nname from officer m where m.iofficer = a.ientry), \
              ' ', a.dapply, b.fcal_way, \
              decode(a.fcard_class,'1',a.ipolicy,' '), \
              decode(a.fcard_class,'2',a.ipolicy,' '), b.idmg_rate, b.pdmg_factor, \
              b.ibrg_rate, nvl(b.pbrg_factor,0), a.ibranch, b.qpt, \
              b.fpt, decode(a.fcard_class,'2',to_char(b.psex_age),' '), \
              decode(a.fcard_class,'1',to_char(b.psex_age),' '), \
              NVL((SELECT max(psex_age) FROM ply_ins_type WHERE ipolicy = a.ipolicy AND iins_type IN (SELECT iins_type FROM insurance_type WHERE fins_grp = '1' AND iins_type = iins_ply AND iri_ins <> '11')),0), \
              b.lia_class, \
              decode(a.fcard_class,'2',nvl(b.plia_acc,' '),' '), \
              decode(a.fcard_class,'1',nvl(b.plia_acc,' '),' '), \
              b.dmg_acc_1st, b.dmg_acc_2nd, \
              b.dmg_acc_3rd, nvl(b.pdmg_acc,' '), b.fhuman, b.fcomp_24, \
              a.mbus_rule, a.mbusiness, a.fcomp_class, a.fcomp_class_last, \
              b.iemail, decode(a.fcard_class,'1',b.iquery_num,' '), \
              decode(a.fcard_class,'2',b.iquery_num,' ') ,b.iquery_num_damage, \
              c.fcar_class, c.ncode, d.nname, nvl(e.nchi_abv,f.nchi_abv), \
              b.napplicant, b.mequipment, b.iroute, b.iroute_prop, \
              decode(a.fcard_class,'2',a.iroute_comm,' '), \
              nvl(b.qlia_acc_sum,0), nvl(b.qdmg_acc_sum,0), \
              b.ndeputy_assured, b.ndeputy_appl, b.nrelation_appl, b.fsex_appl, \
              b.fapplicant, b.iapplicant, b.dbirth_appl, b.itel_appl, a.fcard_class, a.qdrunk_driving,  \
              a.transno, b.nequipment, 500, b.iroute_accept, b.mcover_limit, \
              b.iassured_cntry, b.iapplicant_cntry ,a.ileader, \
              b.fequipment1,b.fequipment2,b.fequipment3,b.fequipment4, \
              b.fequipment5,b.fequipment6,b.fequipment9,b.nequipment9, \
              CASE WHEN a.fcard_class = '2' THEN a.feply ELSE nvl((SELECT feply FROM ply_relation WHERE ipolicy = a.irelative_ply),' ') END, \
              CASE WHEN a.fcard_class = '1' THEN a.feply ELSE nvl((SELECT feply FROM ply_relation WHERE ipolicy = a.irelative_ply),' ') END, \
              CASE WHEN a.fcard_class = '2' THEN (CASE WHEN trim(a.aemail_eply) <>'' THEN a.aemail_eply ELSE nvl((SELECT trim(aemail_eply) FROM ply_relation WHERE ipolicy=a.irelative_ply),'') END ) \
              ELSE (CASE nvl((SELECT trim(aemail_eply) FROM ply_relation WHERE ipolicy=a.irelative_ply),'') WHEN '' THEN (case trim(a.aemail_eply) when '' then '' else trim(a.aemail_eply) end  ) else (SELECT trim(aemail_eply) FROM ply_relation WHERE ipolicy=a.irelative_ply) END) END,  \
              b.punknown_acc, b.iquery_num_unknown, \
              b.foccup,b.noccup,b.applicant_foccup,b.applicant_noccup, \
              b.nmile_ubi, b.pubi_acc, \
              case when a.dply_begin < '07/01/2019' then 'Y' else 'N' end, \
              CASE WHEN a.fcard_class = '2' THEN (CASE WHEN trim(a.tmobile_eply) <>'' THEN a.tmobile_eply ELSE nvl((SELECT trim(tmobile_eply) FROM ply_relation WHERE ipolicy=a.irelative_ply),'') END ) \
              ELSE (CASE nvl((SELECT trim(tmobile_eply) FROM ply_relation WHERE ipolicy=a.irelative_ply),'') WHEN '' THEN (case trim(a.tmobile_eply) when '' then '' else trim(a.tmobile_eply) end  ) else (SELECT trim(tmobile_eply) FROM ply_relation WHERE ipolicy=a.irelative_ply) END) END, \
              b.tmobile_appl,b.aemail_appl,CASE WHEN a.fcard_class = '2' THEN a.feterms ELSE nvl((SELECT feterms FROM ply_relation WHERE ipolicy = a.irelative_ply),'0') END, \
              a.qviolate,case when a.dply_begin >= '06/01/2023' then 'Y' else 'N' end \
         from ply_relation a, policy b, outer car_type c, \
              outer officer d, outer broker_agent e, outer broker_agent f \
        where a.ipolicy in (select upper(ipolicy) from tmp_policy) \
          and a.ipolicy = b.ipolicy \
          and a.icar_type = c.icode  \
          and c.fclass = '1' \
          and a.iofficer = d.iofficer \
          and a.icomm_obj = e.ibroker \
          and a.ibroker = f.ibroker \
          and a.iofficer = (select upper(iofficer) from tmp_policy where upper(ipolicy) = a.ipolicy)  ");


   printf("stmt=[%s]\n", stmt);

   icount1 = 0;
   $PREPARE  perD1 FROM $stmt;
   $DECLARE  curD1 CURSOR FOR perD1;
   $OPEN     curD1;
   while(1)
   {
      $FETCH curD1 INTO
            $Est.iestimate,$Est.icard2,$Est.icard1,$Est.irelative_ply,
            $Est.ilast_ply,$Est.ilast_card,$Est.irelative_card,$Est.ixxcard,
            $Est.dply2_begin,$Est.dply2_end,$Est.dply1_begin,$Est.dply1_end,
            $Est.fassured,$Est.iassured,$Est.iassured_ext,$Est.nassured,
            $Est.ilicense,$Est.dbirth,$Est.fsex,$Est.fmarriage,
            $Est.nuser,$Est.ibenef,$Est.nbenef,$Est.aassured,
            $Est.aassured_zip,$Est.itel,$Est.itel_night,$Est.mobil_phone,
            $Est.apayment,$Est.apayment_zip,$Est.iply_area,$Est.dissue,
            $Est.ipro_year,$Est.ibrand,$Est.nbrand_abbr,$Est.icar_type2,
            $Est.icar_type1,$Est.ncar_abbr,$Est.fcar_note2,$Est.qcylinder,
            $Est.iengine,$Est.ibody,$Est.itag,$Est.mcar_price,
            $Est.pdmg_align,$Est.pbrg_align,$Est.plia_align,$Est.mpremium2,
            $Est.mpremium1,$Est.ibig_comp,$Est.ibig_branch,$Est.ibig_office, $Est.qprovision,
            $Est.ibig_sales,$Est.iresource,$Est.fdiscount,$Est.ibroker2,
            $Est.ibroker1,$Est.iofficer2,$Est.iofficer1,$Est.icorps,
            $Est.iarea,$Est.icashier,$Est.iexaminer,$Est.dexamine,
            $Nquota,$Est.dentry,$Est.dapply,$Est.fcal_way,
            $Est.ipolicy1,$Est.ipolicy2 ,$Est.idmg_rate,$Est.pdmg_factor,
            $Est.ibrg_rate,$Est.pbrg_factor,$Est.ibranch,$Est.qpt,
            $Est.fpt,$Est.psex_age2,$Est.psex_age1,$Est.psex_age_damage,
            $Est.lia_class,$Est.plia_acc2,$Est.plia_acc1,$Est.dmg_acc_1st,
            $Est.dmg_acc_2nd,$Est.dmg_acc_3rd,$Est.pdmg_acc,$Est.fhuman,
            $Est.fcomp_24,$Est.mbus_rule,$Est.mbusiness,$Est.fcomp_class,
            $Est.fcomp_class_last,$Est.iemail,$Est.iquery_num_c,
            $Est.iquery_num ,$Est.iquery_num_damage,
            $Fcar_class,$Ncode,$Nname,$Nchi_abv,
            $Est.napplicant,$Est.mequipment,$Est.iroute, $Est.iroute_prop,
            $Est.iroute_comm2,$Est.qlia_acc_sum,$Est.qdmg_acc_sum,
            $Est.ndeputy_assured, $Est.ndeputy_appl, $Est.nrelation_appl, $Est.fsex_appl,
            $sFapplicant, $Est.iapplicant, $Est.dbirth_appl, $Est.itel_appl, $sFcard_class, $Est.qdrunk_driving,
            $Est.transno,$Est.nequipment,$Est.fuw_status, $Est.iaccept, $sMcover_limit,
            $sIassured_cntry, $sIapplicant_cntry, $sIleader, 
            $fequipment1,$fequipment2,$fequipment3,$fequipment4,
            $fequipment5,$fequipment6,$fequipment9,$nequipment9,
            $feply,$fecard,$aemail_eply,$punknown_acc,$iquery_num_unknown,
            $Est.foccup, $Est.noccup, $Est.applicant_foccup, $Est.applicant_noccup,
            $Est.nmile_ubi, $Est.pubi_acc,$fchk_24,$Est.tmobile_eply,$tmobile_appl,$aemail_appl,$feterms,$qviolate,$f20230601;

      if(SQLCODE == SQLNOTFOUND)
         break;

      /* �s�W�Ӹ��ˮ�   add by sylvia 103.02.14 (1020924002_C2) */
      iCountDeny=0;
        $select count(*) into $iCountDeny
            from cm_personal_deny
           where iassured = $Est.iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today);
      if(iCountDeny > 0)
         continue; 
         
      strcpy(sIleader,trim(sIleader));
	      $SELECT nname
	         INTO $nleader
	         FROM officer
	        WHERE iofficer = $sIleader;
	        
	      if(SQLCODE == SQLNOTFOUND)
	      		strcpy(nleader," ");
/*         
      strcpy(sIleader,trim(sIleader));

      if (strcmp(sIleader,sUserid) != 0)
      {

      		/* �O�������ˮ�(�j��) 
      		rtn = chk_spec_deny( Est.ipolicy1, Est.icard1, Est.iassured, Est.iapplicant, Est.itag, Est.iengine, sMsg);
      		if (rtn == M_CA_SPEC_DENY)
         		continue;

      		/* �O�������ˮ�(���N) 
      		rtn = chk_spec_deny( Est.ipolicy2, Est.icard2, Est.iassured, Est.iapplicant, Est.itag, Est.iengine, sMsg);
      		if (rtn == M_CA_SPEC_DENY)
         		continue;
      }
*/
      printf("-----transno[%s],nequipment[%s]\n",Est.transno,Est.nequipment);
      /* 104.01.20 �ק���O�K�Q�ө���P�_�覡�]9100�N��104.2��O�J�p�ɨ����^ */
      /* �P�Obarcode�󬰡i��Ϋ�ĳ�j��O�զX add by larry 103.07.14 (1030710004_C1) */
      /*if ((strncmp(Est.transno,"9100",4) == 0) && (equip_cmp(Est.nequipment,"37") == TRUE))*/
      if (equip_cmp(Est.nequipment,"37") == TRUE)
      {
      	 if (strncmp(sFcard_class,"1",1) == 0)
      	   strcpy(sIpolicy,Est.ipolicy1);
      	 else
      	 	 strcpy(sIpolicy,Est.ipolicy2);

      	 $SELECT first 1 isys INTO $sIsys
      	    FROM cm_pre_receive
      	   WHERE ipolicy1 = $sIpolicy;
      	  if(SQLCODE == SQLNOTFOUND) strcpy(sIsys," ");

      	  if (strncmp(sIsys,"4",1) == 0)
      	    strcpy(sBarcode_type,"���O");
      	  else if (strncmp(sIsys,"5",1) == 0)
      	    strcpy(sBarcode_type,"��ĳ��O");
      	  else
      	    strcpy(sBarcode_type," ");

      }
      else
      {
      	   strcpy(sBarcode_type," ");
      }

      /* ��պ��ɸ�� */

      $select first 1 dentry into $Est.dentry
         from cm_pre_receive
        where ipre_rcv = $Est.iestimate;

      if(SQLCODE == SQLNOTFOUND)
       		strcpy(Est.dentry, " ");

      /*strcpy(Est.itel_night, " ");
      strcpy(Est.mobil_phone, " ");*/

      printf("Est.iestimate=[%s]Est.irelative_ply=[%s]\n",Est.iestimate,Est.irelative_ply);
      printf("Est.ipolicy1=[%s]Est.ipolicy2=[%s]\n",Est.ipolicy1,Est.ipolicy2);
      icount1++;

      /* �����s���O���� */
      strcpy(Est.irelative_ply, trim(Est.irelative_ply));
      if (strlen(Est.irelative_ply) > 1 )
      {
      		strcpy(tmp_iestimate, " ");
					if (strcmp(sFcard_class,"2") == 0)
					{	 /* ���p�O��O�j���I�O�� */
		         $select a.icard, a.icard, a.dply_begin, a.dply_end,
		                 a.icar_type, nvl(a.mlia_prem,0), a.ibroker, a.iofficer,
		                 a.ipolicy, b.psex_age, nvl(b.plia_acc,' '), b.iquery_num,
		                 a.itmp_policy
		            into $Est.icard1, $Est.irelative_card, $Est.dply1_begin,$Est.dply1_end,
		                 $Est.icar_type1, $Est.mpremium1, $Est.ibroker1, $Est.iofficer1,
		                 $Est.ipolicy1, $Est.psex_age1, $Est.plia_acc1, $Est.iquery_num_c,
		                 $tmp_iestimate
		            from ply_relation a, policy b
		           where a.ipolicy = b.ipolicy
		             and a.fcard_class = '1'
		             and a.ipolicy = $Est.irelative_ply;

		             if ((strlen(trim(sIestimate_c)) == 0) && (strlen(trim(tmp_iestimate)) > 0))
		             			strcpy(sIestimate_c, tmp_iestimate);

		           printf("sIestimate_c=[%s],tmp_iestimate=[%s]\n ",sIestimate_c,tmp_iestimate);

		       }
		       else
		       { /* ���p�O��O���N�I�O�� */
		       	 strcpy(sIestimate_c, Est.iestimate);

		         $select a.icard, a.icard, a.dply_begin, a.dply_end,
		                 a.icar_type, nvl(a.mlia_prem,0), a.ibroker, a.iofficer,
		                 a.ipolicy, b.psex_age, nvl(b.plia_acc,' '), b.iquery_num,
		                 a.itmp_policy
		            into $Est.icard2, $Est.irelative_card, $Est.dply2_begin,$Est.dply2_end,
		                 $Est.icar_type2, $Est.mpremium2, $Est.ibroker2, $Est.iofficer2,
		                 $Est.ipolicy2, $Est.psex_age2, $Est.plia_acc2, $Est.iquery_num,
		                 $Est.iestimate
		            from ply_relation a, policy b
		           where a.ipolicy = b.ipolicy
		             and a.fcard_class = '2'
		             and a.ipolicy = $Est.irelative_ply;
		           printf("sIestimate_c=[%s],tmp_iestimate=[%s]\n ",sIestimate_c,tmp_iestimate);
		       }

      }
      else
      {
					if (strcmp(sFcard_class,"2") == 0)
      		{	/* ���p�O��O�j���I�O�� */
		         strcpy(Est.icard1, " ");
		         strcpy(Est.irelative_card, " ");
		         strcpy(Est.dply1_begin, " ");
		         strcpy(Est.dply1_end, " ");
		         strcpy(Est.icar_type1, " ");
		         Est.mpremium1 = 0;
		         strcpy(Est.ibroker1, " ");
		         strcpy(Est.iofficer1, " ");
		         strcpy(Est.ipolicy1, " ");
		         Est.psex_age1 = 0;
		         Est.plia_acc1 = 0.00;
		         strcpy(Est.iquery_num_c, " ");
		         strcpy(sIestimate_c, " ");
       		}
       		else
       		{	/* ���p�O��O���N�I�O�� */
		         strcpy(Est.icard2, " ");
		         strcpy(Est.irelative_card, " ");
		         strcpy(Est.dply2_begin, " ");
		         strcpy(Est.dply2_end, " ");
		         strcpy(Est.icar_type2, Est.icar_type1);
		         Est.mpremium2 = 0;
		         strcpy(Est.ibroker2, Est.ibroker1);
		         strcpy(Est.iofficer2, Est.iofficer1);
		         strcpy(Est.ipolicy2, " ");
		         Est.psex_age2 = 0;
		         Est.plia_acc2 = 0.00;
		         strcpy(Est.iquery_num, " ");
		         strcpy(sIestimate_c, Est.iestimate);
		         strcpy(Est.iestimate, " ");
       		}
      }

      /* �e��j��Υ��N�g�� */
      strcpy(Fcard_class," ");
      strcpy(LastOff1," ");
      strcpy(LastOff2," ");
      if (strlen(rtrim(Est.ilast_ply))!=0) {
   	   strcpy(FullDB,get_dtl_full_db(Est.ilast_ply));
   	   sprintf_s(stmt_last, sizeof stmt_last,
   	      "select x.fcard_class,trim(x.iofficer) || y.nname, "
            "       (select trim(a.iofficer)||b.nname "
            "          from %s:ply_relation a, officer b "
            "         where a.iofficer = b.iofficer "
            "           and x.irelative_ply = a.ipolicy ) "
            "  from %s:ply_relation x, outer officer y "
            " where x.ipolicy = ? "
            "   and x.iofficer = y.iofficer", FullDB,FullDB);

         printf("stmt_last=[%s]\n", stmt_last);

         $prepare pre_lastC1 from $stmt_last;
   	   $execute pre_lastC1
   	       into $Fcard_class,$LastOff1,$LastOff2
            using $Est.ilast_ply;
         if (NOT_FOUND) {
            strcpy(Fcard_class," ");
            strcpy(LastOff1," ");
            strcpy(LastOff2," ");
         }
      }

      strcpy(Est.iestimate, trim(Est.iestimate));
      strcpy(sIestimate_c, trim(sIestimate_c));
      printf("-----sIestimate_c=[%s] Est.irelative_ply=[%s]\n",sIestimate_c,Est.irelative_ply);
      
      /*�e��j����N�O�渹*/
      strcpy(iLastRelative_ply1,"");
      strcpy(iLastRelative_ply2,"");
      strcpy(stmt_last,"");
      if (strlen(rtrim(Est.ilast_ply))!=0) 
      {
		strcpy(FullDB,get_dtl_full_db(Est.ilast_ply));
   	   	sprintf_s(stmt_last, sizeof stmt_last,
		   	    "select (CASE WHEN fcard_class ='1' THEN  ipolicy ELSE nvl(irelative_ply,'') end),"
		   	    "       (CASE WHEN fcard_class ='1' THEN nvl(irelative_ply,'')  ELSE ipolicy end)"
		            "  from %s:ply_relation  "
		            " where ipolicy = ? ", FullDB);

		printf("stmt_last=[%s]\n", stmt_last);

		$prepare pre_LastRelative3 from $stmt_last;
		$execute pre_LastRelative3
		    into $iLastRelative_ply1,$iLastRelative_ply2 using $Est.ilast_ply;
		if (NOT_FOUND) 
		{
		    strcpy(iLastRelative_ply1," ");
		    strcpy(iLastRelative_ply2," ");
		    break;
		}
      }
      
      provision_J = 0;
      $SELECT COUNT(*)
         INTO $provision_J
         FROM ply_ins_type
        WHERE ipolicy = $Est.ipolicy2
          AND trim(nvl(provision,' '))||';' like '%J;%';

      /* �^�����w�r�p�H����(D���ڡ^�W�U  add by sylvia 101.06.21 */
      sNprovD[0]='\0';
      if (Est.qprovision > 0 || provision_J > 0)
      {
      	/*strcpy(sNprovD, "���w�r�p�H�G");*/
      	iCount2 = 0;
      	strcpy(ninsType, "");
      	strcpy(sNins_type, "");
      	sprintf_s(stmt6, sizeof stmt6, "SELECT trim(a.iins_type)||(SELECT nins_abbr FROM insurance_type WHERE iins_type = a.iins_type) \
      	                  FROM ply_ins_type a \
      	                 WHERE a.ipolicy = '%s' \
      	                   AND (trim(nvl(a.provision,' '))||';' like '%%D;%%' or trim(nvl(a.provision,' '))||';' like '%%J;%%')", Est.ipolicy2);
        $PREPARE  preplyProvD FROM $stmt6;
        $DECLARE  cur_ply_provD CURSOR FOR preplyProvD;
        $OPEN     cur_ply_provD;

        for(;;)
        {
            $FETCH cur_ply_provD INTO $ninsType;
            if(SQLCODE == SQLNOTFOUND)  break;

            iCount2++;

            if (iCount2 == 1)
            {
            	strcpy(sNins_type, trim(ninsType));
            }
            else
            {
            	strcat(sNins_type, ";");
            	strcat(sNins_type, trim(ninsType));
            }
        }
      	$CLOSE  cur_ply_provD;
				$FREE   cur_ply_provD;

      	sprintf_s(stmt5, sizeof stmt5,"select ipolicy, iins_type, provision, iassured, nassured,\
                           year(dbirth)-1911||to_char(dbirth,'/%%m/%%d') AS dbirth,\
                           nbenef, rel_benef, iserial \
                      from ply_ins_assured where ipolicy = ? \
                       and (trim(nvl(provision,' '))||';' like '%%D;%%' or trim(nvl(provision,' '))||';' like '%%J;%%')");

	$PREPARE  pre_EP FROM $stmt5;
	$DECLARE  cur_EP CURSOR FOR pre_EP;
	$OPEN     cur_EP USING $Est.ipolicy2;
	while(1)
	{
	    $FETCH cur_EP INTO
	            	$Assured.iestimate, $Assured.iins_type, $Assured.provision,
	            	$Assured.iassured, $Assured.nassured, $Assured.dbirth,
	            	$Assured.nbenef, $Assured.rel_benef, $Assured.iserial;
	    if(SQLCODE == SQLNOTFOUND)  break;
	            /*iCount2 ++;
	            strcat(sNprovD, rtrim(Assured.nassured));
	            if (iCount2 < Est.qprovision)
	            	strcat(sNprovD,"�B");
	            else
	            	strcat(sNprovD,"�C");*/
	    printf("provD nassured=[%s], iassured[%s], dbirth[%s]\n", Assured.nassured, Assured.iassured, Assured.dbirth);
	    fprintf(fp2,"%s\t%s\t%s\t%s\t%s\n", trim(sNins_type),Assured.nassured,Assured.iassured,Assured.dbirth,Assured.iestimate);
	}
	$close    cur_EP ;
	$free     cur_EP ;
      }/* �^�����w�r�p�H����(D���ڡ^�W�U  end ----------------------- */

      /* �^���r�p�H�ˮ`�W�U  1090221006_SC4_��_56�r�p�H�W�U */
      

      	strcpy(stmt9, /*"SELECT a.ipolicy,a.iins_type,a.iassured,a.nassured,"
      	              "       CASE b.fassured WHEN '2' THEN '' WHEN '4' THEN '' WHEN '6' THEN ''  ELSE to_char(year(a.dbirth)-1911)||'/'||to_char(a.dbirth,'%m/%d') END ,"
      	              "       a.nbenef,a.rel_benef,a.tbenef,a.abenef "
                      "  FROM ply_ins_assured a,policy b "
                      " WHERE a.ipolicy=? AND a.ipolicy=b.ipolicy AND a.iins_type IN ('50') "
                      " UNION "*/
      	              "SELECT a.ipolicy,a.iins_type,a.iinsurant,a.ninsurant, "
      	              "       CASE b.fassured WHEN '2' THEN '' WHEN '4' THEN '' WHEN '6' THEN ''  ELSE to_char(year(a.dbirth)-1911)||'/'||to_char(a.dbirth,'%m/%d') END , "
      	              "       a.nbeneficiary,a.relation_bene,a.tbenef,a.abenef "
                      "  FROM ca_pa_ply a,policy b "
                      " WHERE a.ipolicy=? AND a.ipolicy=b.ipolicy AND a.iins_type IN ('56','136','266')"
                      " UNION "
                      "SELECT a.ipolicy,a.iins_type,a.iassured,a.nassured, "
                      "       CASE b.fassured WHEN '2' THEN '' WHEN '4' THEN '' WHEN '6' THEN ''  ELSE to_char(year(a.dbirth)-1911)||'/'||to_char(a.dbirth,'%m/%d') END , "
                      "       a.nbenef,a.rel_benef,a.tbenef,a.abenef "
                      "  FROM ply_ins_assured a,policy b "
                      " WHERE a.ipolicy=? AND a.ipolicy=b.ipolicy AND a.iins_type IN ('147','561')");
      	printf("stmt9=[%s]\n",stmt9);
 


        $PREPARE  pre_list_ply FROM $stmt9;
	$DECLARE  cur_list_ply CURSOR FOR pre_list_ply;
	$OPEN     cur_list_ply using $Est.ipolicy2,$Est.ipolicy2;
	while(1)
	{
	    $FETCH cur_list_ply INTO $ipolicy_list,$iins_type_list,$iinsurant_list,
	                         $ninsurant_list,$dbirth_list,$nbeneficiary_list,
	                         $relation_bene_list,$tbenef_list,$abenef_list;

	    if(SQLCODE == SQLNOTFOUND)  break;

	    fprintf(fp4,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n", ipolicy_list,iins_type_list,iinsurant_list,ninsurant_list,dbirth_list,nbeneficiary_list,relation_bene_list,tbenef_list,abenef_list);
	}
	$close    cur_list_ply;
	$free     cur_list_ply;
      /* �^���r�p�H�ˮ`�W�U  end ----------------------- */


      /* 97���O�n�O�ѤW��ܡi�䲼ú�ڡj104.04.23 (1040407003_C2) */
      if (equip_cmp(Est.nequipment,"97") == TRUE)
          strcpy(equip97,"Y");
      else
      	  strcpy(equip97,"N");
      	  
      /******************* 30�I�ةӫO�d�򻡩����e(BEGIN) *******************/
printf("30�I�ةӫO�d�򻡩����eBEGIN\n");

	$SELECT iins_type,mdeduct
	   INTO $iins_type30_301,$deduct_30
	   FROM ply_ins_type
	  WHERE ipolicy = $Est.ipolicy2
	    AND iins_type in ( '30', '301','302', '530' );
	
	if(SQLCODE == SQLNOTFOUND)
	{
		strcpy(str_ins_30," ");
	}
	else
	{
		strcpy(iins_type30_301,trim(iins_type30_301));
		/*�P�_��O���O30�I���٬O301�I��*/
		if( strcmp(iins_type30_301,"30") == 0 )
		{
			flag30_301 = 30;
		}
		else if( strcmp(iins_type30_301,"301") == 0 )
		{
			flag30_301 = 301;
		}
		else if( strcmp(iins_type30_301,"302") == 0 )
		{
			flag30_301 = 302;
		}
        else
        {
            flag30_301 = 530;
        }
		/*�T�{���[�O24*/    
		$SELECT iins_type
		   INTO $iins_type24
		   FROM ply_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type = '24';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��24�I��*/
		{
			flag24=0;
		}
		else
		{
			flag24=1;
		}	
		/*�T�{���[�O55*/
		$SELECT iins_type
		   INTO $iins_type55
		   FROM ply_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type = '55';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
		{
			flag55=0;
		}
		else
		{
			flag55=1;
		}
		/*�T�{���[�O255*/
		$SELECT iins_type
		   INTO $iins_type55
		   FROM ply_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type = '255';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
		{
			flag255=0;
		}
		else
		{
			flag255=1;
		}
		/*�T�{���[�O49 or 177*/
		$SELECT iins_type
		   FROM ply_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type IN ('49','117');
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��49 or 117�I��*/
		{
			flag49117=0;
		}
		else
		{
			flag49117=1;
		}
        /*�T�{���[�O55*/
		$SELECT iins_type
           INTO $iins_type55
           FROM ply_ins_type
          WHERE ipolicy = $Est.ipolicy2
            AND iins_type = '555';
        if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
        {
            flag555=0;
        }
        else
        {
            flag555=1;
        }

		strcpy(tmp_deduct_30,itoa(deduct_30));
		
		if( (flag30_301 == 302) && (flag55 == 1) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d��]�t:������˳d�����[���ڡC");
            }
            else
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d�򤣥]�t:������˳d�����[���ڡC");
            }
		}
		else if( (flag30_301 == 302) && (flag255 == 1) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d��]�t:������˳d���I�C");
            }
            else
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d�򤣥]�t:������˳d���I�C");
            }
		}
		
		if( (flag30_301 == 301) && (flag55 == 1) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d���I���[����-��D���W���ӫO�d��]�t:������˳d�����[���ڡC");
            }
            else
            {
            	strcpy(str_ins_30,"�W�B�d���I���[����-��D���W���ӫO�d�򤣥]�t:������˳d�����[���ڡC");
            }
		}
		else if( (flag30_301 == 301) && (flag255 == 1) )
		{
            strcpy(str_ins_30,"�W�B�d���I���[����-��D���W���ӫO�d�򤣥]�t:������˳d���I�C");
		}
		
		/* 1080311008_SC4_�ͮĤ��71�_����s�v�I */
		if( (flag30_301 == 30) && (flag24 == 1) && (flag55 == 1) && (strncmp(fchk_24,"Y",1)==0))
		{
			if ((IsFcomp24(tmp_deduct_30)) && (IsFcomp55(tmp_deduct_30)))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:�ĤT�H�d�����s���v�T�έ�����˳d�����[���ڡC");
            }
			else if (IsFcomp24(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:�ĤT�H�d�����s���v�T���[���ڤ��]�t������˳d�����[���ڡC");
            }
			else if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:������˳d�����[���ڤ��]�t�ĤT�H�d�����s���v�T���[���ڡC");
            }
			else
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:�ĤT�H�d�����s���v�T�έ�����˳d�����[���ڡC");
            }
		}
		else if( (flag30_301 == 30) && (flag24 == 1) && (strncmp(fchk_24,"Y",1)==0))
		{
			if (IsFcomp24(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:�ĤT�H�d�����s���v�T���[���ڡC");
            }
			else
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:�ĤT�H�d�����s���v�T���[���ڡC");
            }	
		}
		else if( (flag30_301 == 30) && ((flag55 == 1)||(flag49117 == 1)) )
		{
			if (IsFcomp55(tmp_deduct_30))
	        {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:������˳d�����[���ڡC");
            }
			else
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:������˳d�����[���ڡC");
            }		
		}
		else if( (flag30_301 == 30) && ((flag255 == 1)||(flag49117 == 1)) )
		{
	    	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:������˳d���I�C");
		}
        
        if((flag30_301 == 530) && (flag555 == 1))
        {
            if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�r�V�Z�W�B�d���I�ӫO�d��]�t�G�r�V�Z������˳d���I�C");
            }
            else
            {
            	strcpy(str_ins_30,"�r�V�Z�W�B�d���I�ӫO�d�򤣥]�t�G�r�V�Z������˳d���I�C");
            }
        }
	}

printf("30�I�ةӫO�d�򻡩����eEND\n");
      /******************* 30�I�ةӫO�d�򻡩����e(END) *********************/
      
      /* 1120316006_SC5_�L��-���N�I���e�{�s�W���@�������������O�N��05�ή��s�X��t�ηs�W���@�����O */
      flag_ambulance55 = 0;
      $SELECT iins_type
		 INTO $iins_type55
		 FROM ply_ins_type
	    WHERE ipolicy = $Est.ipolicy2
		  AND iins_type = '55';
      if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
      {
          flag_ambulance55=0;
      }
      else
      {
          flag_ambulance55=1;
      }
      
      if (flag_ambulance55 > 0 && strncmp(Est.icar_type2,"11",2) == 0 && equip_cmp(Est.nequipment,"115") == true && f20230601[0] == 'Y')
      {
      	 if (str_ins_30[0] == '' || str_ins_30[0] == '\0' ) strcat(str_ins_30," ");
      	 strcat(str_ins_30,"�����I�ӫO�d�򤣧t�˱w");
      }
      else 
      {
          
      }
      
      /******************* �t�Ʃ���(BEGIN) ***********************/
      strcpy(outfit_nequipment," ");
      if(strcmp(fequipment1,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B���T");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"���T");
      	}
      }
      
      if(strcmp(fequipment2,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B���c");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"���c");
      	}
      }
      
      if(strcmp(fequipment3,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B�N�����");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"�N�����");
      	}
      }
      
      if(strcmp(fequipment4,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B���ءB����");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"���ءB����");
      	}
      }
      
      if(strcmp(fequipment5,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B�@���t��");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"�@���t��");
      	}
      }
      
      if(strcmp(fequipment6,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B�q�ʨ��q��");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"�q�ʨ��q��");
      	}
      }
      
      if(strcmp(fequipment9,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B");
      		strcat(outfit_nequipment,nequipment9);
      	}
      	else
      	{
      		strcpy(outfit_nequipment,nequipment9);
      	}
      }
      
      printf("outfit_nequipment[%s]\n",outfit_nequipment);

      /******************* �t�Ʃ���(END) ***********************/   
      
      /* �j+�� -> ���N�g��H;���  -> ���N�g��H;��j  -> ���N�g��H */
      strcpy(Est.iofficer2,trim(Est.iofficer2));
      if (strlen(Est.iofficer2) == 0)
      {
      	$SELECT nname
      	   INTO $Nname
      	   FROM officer
      	  WHERE iofficer = $Est.iofficer1;
      }   

      /*1050601008_C2_�s�Wka�q����O��۰ʥN�X�~�ȭ��n���r��*/
	/* ���n���Ҧr��_KA */
	sprintf_s(stmt_iregno, sizeof stmt_iregno, " SELECT ilicence \
			  FROM cm_salesman_log \
			 WHERE ileader = ? and icomm_obj = ileader ");
	$PREPARE prep_iregno_KA_ply FROM $stmt_iregno;
	printf("stmt_iregno[%s]\n",stmt_iregno);
        strcpy(Nreg_no2," ");
        printf("prep_iregno_KA_ply \n");
        if (strncmp(Est.iroute,"KA",2) == 0 && Est.ilast_ply[0] != 0)
        {
		/* �O��q���N����KA*��, �n�]�n�^���n���Ҧr�� */
		$EXECUTE prep_iregno_KA_ply into $Nreg_no using $sIleader;
        	if (SQLCODE == SQLNOTFOUND) strcpy(Nreg_no," "); 
        	strcpy(Nreg_no2,trim(Nreg_no));
        	strcat(Nreg_no2," ");
        	strcat(Nreg_no2,nleader);	
        }
        else
        	strcpy(Nreg_no2," ");
        	
      /*�����I¾�~*/
      sprintf_s(stmt_occup1, sizeof stmt_occup1, "SELECT (trim(imember)||' '||trim(nmember)) FROM cm_risk_member WHERE itype = 'P' AND fmember = 'P' AND imember = '%s' ",Est.noccup);
      $PREPARE prep_occup_est1 FROM $stmt_occup1;
      $EXECUTE prep_occup_est1 into $noccup_fullname;
      if (SQLCODE == SQLNOTFOUND) strcpy(noccup_fullname," "); 
      
      sprintf_s(stmt_occup2, sizeof stmt_occup2, "SELECT (trim(imember)||' '||trim(nmember)) FROM cm_risk_member WHERE itype = 'P' AND fmember = 'P' AND imember = '%s' ",Est.applicant_noccup);
      $PREPARE prep_occup_est2 FROM $stmt_occup2;
      $EXECUTE prep_occup_est2 into $applicant_noccup_fullname;
      if (SQLCODE == SQLNOTFOUND) strcpy(applicant_noccup_fullname," "); 
      
      printf("noccup_fullname[%s] applicant_noccup_fullname[%s] \n",noccup_fullname,applicant_noccup_fullname); 

      /******���[���ڤ�r����(BEGIN)******/
      
      strcpy(iprov_all," ");
      strcpy(sprov_all," ");
      strcpy(iprov," ");
      strcpy(iins_prov," ");
      strcpy(sprov," ");
      strcpy(sprov_note," ");
      strcpy(sprov_note_all," ");    

      sprintf_s(stmt7, sizeof stmt7, "SELECT trim(nvl(provision,' '))||';',iins_type FROM ply_ins_type WHERE ipolicy = '%s' " , Est.ipolicy2);
      	               
      $PREPARE  preProvision9 FROM $stmt7;
      $DECLARE  cur_provision9 CURSOR FOR preProvision9;
      $OPEN     cur_provision9;

      for(;;)
      {
            $FETCH cur_provision9 INTO $iprov,$iins_prov;
            if(SQLCODE == SQLNOTFOUND)  break;
            
            if (strstr(trim(iprov),"P;") != NULL)
            {
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'P;','')
		       INTO $iprov
		       FROM systables;
		       	
        	
            }
            else if (strstr(trim(iprov),"Q;") != NULL)
            {
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'Q;','')
		       INTO $iprov
		       FROM systables;	
            }
            else if (strstr(trim(iprov),"M;") != NULL)
            {
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) && 
                    (strcmp(trim(iins_prov),"181")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'M;','')
		       INTO $iprov
		       FROM systables;		
            }  
            else if (strstr(trim(iprov),"Y;") != NULL)
            {
            	/* 1130827011_C04_�s�W�s�t��W�B���[����(Y)(�L��) */
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) && 
                    (strcmp(trim(iins_prov),"198")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'Y;','')
		       INTO $iprov
		       FROM systables;		
            }        

            strcat(iprov_all, iprov);

      }
      $CLOSE  cur_provision9;
      $FREE   cur_provision9;
      printf("�����[����:iprov_all[%s]\n",trim(iprov_all));
      strcpy(iprov_all,trim(iprov_all));
      
      if (strcmp(iprov_all,";")!=0 && strcmp(iprov_all,"")!=0)
      {
          ptr1 = strtok(iprov_all,";");
	  while(ptr1 != NULL)
	  {
      	      sprintf_s(sprov, sizeof sprov,"'%s',",ptr1);  
      	      strcat(sprov_all,sprov);	  				
	      ptr1 = strtok(NULL, ";");
	  }
				
          strcat(sprov_all,"''");
          printf("�����[����:sprov_all[%s]\n",trim(sprov_all));
      	
      	  sprintf_s(stmt8, sizeof stmt8, "SELECT trim(nprint)||'�B' FROM ca_provision_main WHERE iprovision NOT IN ('C','E','S') AND iprovision IN (%s)" , trim(sprov_all));
          $PREPARE  preProvision10 FROM $stmt8;
          $DECLARE  cur_provision10 CURSOR FOR preProvision10;
          $OPEN     cur_provision10;   
          
          for(;;)
          {
              $FETCH cur_provision10 INTO $sprov_note;
              if(SQLCODE == SQLNOTFOUND)  break;

              strcat(sprov_note_all, trim(sprov_note));

          }
          $CLOSE  cur_provision10;
          $FREE   cur_provision10;   
          printf("�����[���ڤ���:sprov_note_all[%s]\n",trim(sprov_note_all));	  
      	  strcpy(sprov_note_all,trim(sprov_note_all));
      }


      /******���[���ڤ�r����(END)******/

      /* �g�J��r��,�`�N��춶�Ƕ��Pclient�ݤ@�P ----------------------------- */
      fprintf(fp0,"%s.\t%s.\t%s\t%s\t%s\t",
               Est.iestimate,sIestimate_c,Est.icard2,Est.icard1,Est.irelative_ply);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
                  Est.ilast_ply,Est.ilast_card,Est.irelative_card,Est.ixxcard);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
                  Est.dply2_begin,Est.dply2_end,Est.dply1_begin,Est.dply1_end);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
                  Est.fassured,Est.iassured,Est.iassured_ext,Est.nassured);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	         Est.ilicense,Est.dbirth,Est.fsex,Est.fmarriage);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
      	         Est.nuser,Est.ibenef,Est.nbenef,Est.aassured);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	         Est.aassured_zip,Est.itel,Est.itel_night,Est.mobil_phone);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	         Est.apayment,Est.apayment_zip,Est.iply_area,Est.dissue);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	         Est.ipro_year,Est.ibrand,Est.nbrand_abbr,Est.icar_type2);
      fprintf(fp0,"%s\t%s\t%s\t%.2f\t",
       	         Est.icar_type1,Est.ncar_abbr,Est.fcar_note2,Est.qcylinder);
      fprintf(fp0,"%s\t%s\t%s\t%.1f\t",
       	         Est.iengine,Est.ibody,Est.itag,Est.mcar_price);
      fprintf(fp0,"%d\t%d\t%d\t%d\t",
       	         Est.pdmg_align,Est.pbrg_align,Est.plia_align,Est.mpremium2);
      fprintf(fp0,"%d\t%s\t%s\t%s\t%d\t",
       	         Est.mpremium1,Est.ibig_comp,Est.ibig_branch,Est.ibig_office,Est.qprovision);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	         Est.ibig_sales,Est.iresource,Est.fdiscount,Est.ibroker2);
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
      	         Est.ibroker1,Est.iofficer2,Est.iofficer1,Est.icorps,Nreg_no2);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
      	         Est.iarea,Est.icashier,Est.iexaminer,Est.dexamine);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
       	         Nquota,Est.dentry,Est.dapply,Est.fcal_way);
      fprintf(fp0,"%s\t%s\t%s\t%.4f\t",
      	         Est.ipolicy1,Est.ipolicy2 ,Est.idmg_rate,Est.pdmg_factor);
      fprintf(fp0,"%s\t%.4f\t%s\t%.1f\t",
      	         Est.ibrg_rate,Est.pbrg_factor,Est.ibranch,Est.qpt);
      fprintf(fp0,"%s\t%f\t%f\t%f\t",
      	         Est.fpt,Est.psex_age2,Est.psex_age1,Est.psex_age_damage);
      fprintf(fp0,"%s\t%.2f\t%.2f\t%d\t",
                  Est.lia_class,Est.plia_acc2,Est.plia_acc1,Est.dmg_acc_1st);
      fprintf(fp0,"%d\t%d\t%.2f\t%s\t",
   	            Est.dmg_acc_2nd,Est.dmg_acc_3rd,Est.pdmg_acc,Est.fhuman);
      fprintf(fp0,"%s\t%f\t%f\t%s\t",
                  Est.fcomp_24,Est.mbus_rule,Est.mbusiness,Est.fcomp_class);
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
                  Est.fcomp_class_last,Est.iemail,Est.iquery_num_c,
                  Est.iquery_num ,Est.iquery_num_damage);
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t%f\t%s\t",
                  Fcar_class,Ncode,Nname,Nchi_abv,
       	         Est.napplicant,Est.mequipment,Est.iroute);
      fprintf(fp0,"%s\t%s\t%d\t%d\t",
                  Est.iroute_prop, Est.iroute_comm2, Est.qlia_acc_sum,
                  Est.qdmg_acc_sum );
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%d\t%s\t%d\t%s\t%s\t%s\t%s\t%d\t",
                  Est.ndeputy_assured, Est.ndeputy_appl, Est.nrelation_appl, Est.fsex_appl,
                  sFapplicant, Est.iapplicant, Est.dbirth_appl, Est.itel_appl, Est.qdrunk_driving,
                  sBarcode_type, Est.fuw_status, Est.iaccept, equip97, " ", "0",sMcover_limit);
      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
                  sIassured_cntry, sIapplicant_cntry,nleader,str_ins_30,outfit_nequipment);

      if (strcmp(Fcard_class,"1") == 0)
         fprintf(fp0,"%s\t%s\t",LastOff1,LastOff1);   /* �e�欰�j���I */
      else
         fprintf(fp0,"%s\t%s\t",LastOff2,LastOff1);   /* �e�欰���N�I */
         
      fprintf(fp0,"%s\t%s\t%s\t%.2f\t%s\t",
      		      feply, fecard, aemail_eply, punknown_acc, iquery_num_unknown);
      fprintf(fp0,"%s\t%s\t%s\t%s\t",
      		      Est.foccup, noccup_fullname,Est.applicant_foccup,applicant_noccup_fullname); 
      		      
      fprintf(fp0,"%f\t%f\t%s\t%s\t%s\t%s\t",Est.nmile_ubi, Est.pubi_acc, Est.tmobile_eply,sprov_note_all, tmobile_appl, aemail_appl);
      
      fprintf(fp0,"%s\t%s\t%s\t%d\t", iLastRelative_ply1, iLastRelative_ply2, feterms, qviolate);
      
      fprintf(fp0,"%s\t%s\t%s\t%s\n"," "," "," "," "); /* 1120927002_C12_�R�q�ΰӫ~�}�o(�L��)�A�ȸպ⦳ */

      /* �I�ة����� */
      rc1 = select_ply_ins_data_1(Est.ipolicy1, Est.ipolicy2, Est.icar_type2, DBName);
      if (rc1 != SUCCESS)
         break;

   }
   $close curD1;
   $free curD1;

   fclose(fp0);
   fclose(fp1);
   fclose(fp2);
   fclose(fp4);
   icount2 = 0;

   $drop table tmp_policy;

   if (rc1 != SUCCESS)
       return rc1;

   if ((icount1+icount2) == 0)
   {
      if(exitsub(reply,M_CM_NOT_FOUND) == True)
         return M_CM_NOT_FOUND;
      else
         return apiRC;
   }

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   cm_buf_put("%s %s %s %s",sTmp0,sTmp1,sTmp2,sTmp4);

   tmp_len = cm_buf_len(ReplyBuf);
   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
   else
         return api_OKComplete;

errexit:
   printf(" AAAAAAAAAAAAAAAAAAa = [%d]\n ",SQLCODE);
   fclose(fp0);
   fclose(fp1);
   fclose(fp2);
   fclose(fp4);
   sqlfatal();

   return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
} /* end of select_ply_data */

/* -------------------------------------------------------------------------- */

long select_ply_ins_data_1(fipolicy1, fipolicy2, ficar_type, fdbname)
char *fipolicy1, *fipolicy2, *ficar_type, *fdbname;
{
   $char	DBName[5],iest1[21],iest2[21],icar_type[3];
   $char	stmt[8192],stmt1[2048],stmt2[2048],stmt3[1024];
   $struct	est_ins_type   *EstIns;
   int	i=0, rc=0;
   int	tmp_len=0;
   char FullGetName[101], filename[31];
   char sTmp0[71], sTmp1[71], sTmp2[71], file0[71], file1[71];
   char rptstr_main[10000], rptstr_dtl[10000];
   char sApHome[31];

   printf("------- select_ply_ins_data_1 strat ------------------------------ \n");
   $WHENEVER SQLERROR GOTO errexit;
   strcpy(DBName, fdbname);

   if (db_select(DBName) == False)
         return M_CM_DB_NOTOPEN;

   memset(&EstIns,0, sizeof(EstIns));
   EstIns=(struct est_ins_type *)malloc(sizeof(struct est_ins_type));

   strcpy(iest1, fipolicy1);
   strcpy(iest2, fipolicy2);
   strcpy(icar_type, ficar_type);

   printf(" ------ iest1=[%s] iest2=[%s] icar_type=[%s]\n",iest1, iest2, icar_type);

      strcpy(stmt2,
         " case when a.iins_type in ('56','136','166','266') then (select max(daily_pay) "
         "      from ca_pa_ply d where a.ipolicy = d.ipolicy "
         "       and a.iins_type = d.iins_type) else 0 end as daily_pay, "
         " case when a.iins_type in ('56','136','166','35','266') then (select distinct iins_scope "
         "      from ca_pa_ply f where a.ipolicy = f.ipolicy "
         "       and a.iins_type = f.iins_type) else '0' end as iins_scope, "
         " (select count(*) from insurance_cover e "
         "   where a.iins_type = e.iins_type) as insurance_cover, a.ipolicy, ' ' ");
      strcpy(stmt3,
         " from ply_ins_type a, outer insurance_type b "
         "where (ipolicy = ? or ipolicy = ?) "
         "  and a.iins_type = b.iins_type "
         "order by qserial ");


   strcpy(stmt1,
      "select a.iins_type,a.minjured_cover,a.mdeath_cover,a.mdamage_cover, "
      "       a.mdeduct,a.mins_premium,a.mpure_prem,a.qserial, "
      "       a.pcommission,a.mcommission,a.pagent,a.magent, "
      "       a.pdiscount,a.mdiscount,a.drate_ym,a.mprem, "
      "       a.iproduct,a.qday,a.mexpense,a.mexp_disc, "
      "       a.provision,a.irate,a.adjust_rate,a.mins_premium_n, "
      "       a.mpure_prem_n,a.mprem_n,a.safe_rate,a.manage_rate, "
      "       a.educated_rate,a.deviation_rate,b.nins_type, "
      "       case when a.iins_type in ('01','05','08','09','120','122','125','126','131','132','201','205','209','331','332') then "
      "            (select prn_deduct from ca_dmg_mdeduct c "
      "              where c.icar_type = ? and c.ideduct = a.mdeduct) "
      "            when b.fdeduct = '0' then '�L' "
      "       else a.mdeduct::varchar(20) end as prn_deduct, "
      "       b.qcoverage, b.cover_print, b.fdeduct, b.deduct_print, ");

   strcpy(stmt,rtrim(stmt1));
   strcat(stmt,rtrim(stmt2));
   strcat(stmt,rtrim(stmt3));

   printf("2:stmt=[%s]\n",stmt);

   $prepare pre_stmt from $stmt;
   $declare cur_insC1 cursor for pre_stmt;
   $open    cur_insC1 using $icar_type,$iest1,$iest2;

   /* �g�J��r��,�`�N��춶�Ƕ��Pclient�ݤ@�P ----------------------------- */
   for(i=0;;i++)
   {
      $fetch cur_insC1 into
            $EstIns->iins_type,$EstIns->minjured_cover,
            $EstIns->mdeath_cover,$EstIns->mdamage_cover,
            $EstIns->mdeduct,$EstIns->mins_premium,
            $EstIns->mpure_prem, $EstIns->qserial,
            $EstIns->pcommission,$EstIns->mcommission,
            $EstIns->pagent,$EstIns->magent,$EstIns->pdiscount,
            $EstIns->mdiscount,$EstIns->drate_ym,$EstIns->mprem,
            $EstIns->iproduct,$EstIns->qday,$EstIns->mexpense,
            $EstIns->mexp_disc,$EstIns->provision,$EstIns->irate,
            $EstIns->adjust_rate,$EstIns->mins_premium_n,
            $EstIns->mpure_prem_n,$EstIns->mprem_n,
            $EstIns->safe_rate,
            $EstIns->manage_rate,$EstIns->educated_rate,
            $EstIns->deviation_rate,$EstIns->Nins_type,
            $EstIns->Prn_deduct, $EstIns->qcoverage, $EstIns->cover_print,
            $EstIns->fdeduct, $EstIns->deduct_print, $EstIns->Daily_pay,$EstIns->Iins_scope,
            $EstIns->Ins_cover, $EstIns->iestimate, $EstIns->fproject;
      if (NOT_FOUND) break;

   	printf("EstIns->iins_type=[%s]\n",EstIns->iins_type);

   	fprintf(fp1,"%s\t%d\t%d\t%d\t",
         EstIns->iins_type,EstIns->minjured_cover,
   	   EstIns->mdeath_cover,EstIns->mdamage_cover);

      fprintf(fp1,"%d\t%d\t%f\t%d\t%f\t%d\t",
   	   EstIns->mdeduct,EstIns->mins_premium,EstIns->mpure_prem,
   	   EstIns->qserial,EstIns->pcommission,EstIns->mcommission);

      fprintf(fp1,"%f\t%d\t%f\t%d\t%s\t%d\t",
   	   EstIns->pagent,EstIns->magent,EstIns->pdiscount,
   	   EstIns->mdiscount,EstIns->drate_ym,EstIns->mprem);

      fprintf(fp1,"%s\t%d\t%d\t%d\t%s\t%d\t",
   	   EstIns->iproduct,EstIns->qday,EstIns->mexpense,
   	   EstIns->mexp_disc,EstIns->provision,EstIns->irate);

      fprintf(fp1,"%f\t%d\t%d\t%d\t%f\t",
   	   EstIns->adjust_rate,EstIns->mins_premium_n,
   	   EstIns->mpure_prem_n,EstIns->mprem_n,EstIns->safe_rate);


	  if (strlen(trim(iest2)) > 0 )
	  {
	  		fprintf(fp1,"%f\t%f\t%f\t%s\t%s\t%d\t%s\t%d\t%s\t%s\n",
   	   EstIns->manage_rate,EstIns->educated_rate,
   	   EstIns->deviation_rate,EstIns->Nins_type,
   	   EstIns->Prn_deduct,EstIns->Daily_pay,EstIns->Iins_scope,
   	 EstIns->Ins_cover,iest2,EstIns->fproject);}
	  else
	  	{
   		fprintf(fp1,"%f\t%f\t%f\t%s\t%s\t%d\t%s\t%d\t%s\t%s\n",
   	   EstIns->manage_rate,EstIns->educated_rate,
   	   EstIns->deviation_rate,EstIns->Nins_type,
   	   EstIns->Prn_deduct,EstIns->Daily_pay,EstIns->Iins_scope,
   	 EstIns->Ins_cover,iest1,EstIns->fproject);}

   	   printf("EstIns->iins_type=[%s]\n",EstIns->iins_type);
   }
   $close cur_insC1;
   $free  cur_insC1;

   return SUCCESS;

errexit:
   printf(" BBBBBBBBBBBBBBBBBBB = [%d]\n ",SQLCODE);
    sqlfatal();
    return SQLCODE;
} /* end of select_estins_data_1 */

/* ------------------------------------------------------------------------------- */
long select_ply302_data(reply)
serverReply reply;
{
	
    $char	DBName[5],iest_bgn[21],iest_end[21],sTmpProv[2],sNprovD[101];
    $char	stmt[8192],stmt1[2048],stmt2[2048],stmt3[1024],stmt4[500],stmt5[1000],stmt6[500],stmt7[1024],stmt8[1024],stmt9[2048],stmt9_1[128];
    $char	stmt_last[1024],FullDB[41],stmtc[8192],sFcard_class[2], icomm_obj[11],stmt_feply[3072];
    $struct	estimate	Est;
    $struct	est_ins_assured	Assured;
    $char        tmobile_appl[21],aemail_appl[51];
    $char	Fcar_class[2],Ncode[11],Nname[11],Nchi_abv[13];
    $char	Nquota[11],Fcard_class[2],LastOff1[21],LastOff2[21];
    $char tmp_ply[21], tmp_officer[11], sIestimate_c[21], tmp_iestimate[21],tmp_fcard_class[2];
    $char sIsys[2], sIpolicy[21], sBarcode_type[9],tmp_icar_type[3];
    int	i=0,j=0,k=0,rc=0, icount1=0, rc1=0, tmp_len=0, icount2=0;
    int   recLen=1024;
    char FullGetName[101], filename[31];
    char sTmp0[71], sTmp1[71], sTmp2[71], file0[71], file1[71],file3[71],file4[71],sTmp3[71],sTmp4[71];
    $char	ipolicy_list[21],iins_type_list[7],iinsurant_list[11],ninsurant_list[31],dbirth_list[11],nbeneficiary_list[31],relation_bene_list[2],tbenef_list[21],abenef_list[91];
    char rptstr_main[10000], rptstr_dtl[10000];
    char sApHome[31], sGetFileName[101], sFullFileName[201], sTmpTableName[101];
    char *token, *s1;
    time_t now;
    char sUserid[11];
    $int iCount2=0,fuw_status=0, isys=0, iCnt21=0, iCount3=0, iCnt47=0;
    long rtn=0;
    char sMsg[100], sTmpx[2];
    $char stp_officer[11], sdentry1[11], sdentry2[11], sTmpx2[11], cdate[11];
    $char sIassured_cntry[2], sIapplicant_cntry[2];
    $char sIleader[11];
    $char sFapplicant[2];
    $char stmt_iregno[1024],Nreg_no[22],Nreg_no2[25];
    $char stmt_occup1[1024],stmt_occup2[1024],noccup_fullname[126],applicant_noccup_fullname[126];
    $char iprov_all[200],iprov[10],sprov[5],sprov_all[500],sprov_note[50],sprov_note_all[500],iins_prov[7];
    $char fchk_24[2];
    $char iLastRelative_ply1[21],iLastRelative_ply2[21];
    $char *ptr1;
    $int  qviolate = 0;
    strcpy(fchk_24," ");
    $char f20230601[2];
    strcpy(f20230601," ");

    printf("------- select_ply302_data strat ------------------------------ \n");
    cm_buf_get("%s %s %s %s %s",DBName,iest_bgn, iest_end, sGetFileName,sUserid);

    printf("DBName=[%s],iest_bgn=[%s], iest_end=[%s], sGetFileName=[%s] \n",DBName,iest_bgn, iest_end, sGetFileName);
    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }

    rc = getApHome(sApHome);
    if (rc < 0)
    {
        return exitsub(reply,M_CM_READ_CONFIG_ERR) ? M_CM_READ_CONFIG_ERR : apiRC;
    }
    strcpy(sTmpx," ");

    /* �إ�tmp table -------------------------------------------------------- */
    $create temp table tmp_policy
     (
      iestimate  char(20),
      isys       char(1)
     )with no log ;
    $create temp table tmp_policy2
     (
      iestimate  char(20),
      isys       char(1)
     )with no log ;

    /* ���ǤJ�ɮ�,Ū���ɮפ��e */
    if (itype == 3)
    {
        if (strlen(trim(sGetFileName)) > 0)
        {
          /* Ū�ɨüg�Jtmp table */
           sprintf_s(sFullFileName, sizeof sFullFileName, "%s/dat/car/%s", sApHome, sGetFileName);
           printf("sFullFileName=[%s]\n",sFullFileName);
           if ((fptr=fopen(sFullFileName,"rt"))==NULL)
           {
               return 0;
           }

           if ((bp=malloc(recLen))==NULL)
           {
               printf("System malloc failed  !\n");
               free(bp);
               return FAIL;
           }

           while(fgets(bp,recLen,fptr))
           {
               if (feof(fptr)) break;
               i = 0;
               /* ��l�ưѼ� ---------------------------------------------------- */
               memset(stp_officer, 0x00, sizeof(stp_officer));
               memset(sdentry1, 0x00, sizeof(sdentry1));
               memset(sdentry2, 0x00, sizeof(sdentry2));
               /* --------------------------------------------------------------- */
               token = strtok(bp,"\t");
               while (token != NULL)
               {
                   i ++;
                   if (i == 1)
                   {
                      strcpy(stp_officer, rtrim(token));    /* �g��N�� */
                   }
                   else if(i==2)
                   {
                      strcpy(sTmpx2, rtrim(token));    /* �d�߰_�� */
                      printf("sTmpx2=[%s]\n",sTmpx2);
                      memset(sdentry1, 0x00, sizeof(sdentry1));
                      memset(cdate, 0x00, sizeof(cdate));
                      strncpy(cdate, sTmpx2, 3);
                      cdate[3]='\0';
                      strcat(cdate,"/");
                      strncat(cdate, &sTmpx2[3], 2);
                      cdate[6]='\0';
                      strcat(cdate,"/");
                      strncat(cdate, &sTmpx2[5], 2);
                      cdate[9]='\0';
                      printf("cdate=[%s]\n",cdate);
                      strcpy(sdentry1, cm_to_infdate(cdate));
                      printf("sdentry1=[%s]\n",sdentry1);

                   }
                   else if(i==3)
                   {
                      strcpy(sTmpx2, rtrim(token));    /* �d�ߨ��� */
                      printf("sTmpx2=[%s]\n",sTmpx2);
                      memset(sdentry2, 0x00, sizeof(sdentry2));
                      memset(cdate, 0x00, sizeof(cdate));
                      strncpy(cdate, sTmpx2, 3);
                      cdate[3]='\0';
                      strcat(cdate,"/");
                      strncat(cdate, &sTmpx2[3], 2);
                      cdate[6]='\0';
                      strcat(cdate,"/");
                      strncat(cdate, &sTmpx2[5], 2);
                      cdate[9]='\0';
                      printf("cdate=[%s]\n",cdate);
                      strcpy(sdentry2, cm_to_infdate(cdate));
                      printf("sdentry2=[%s]\n",sdentry2);
                   }
                   else
                   {
                      printf("---- other ---- \n");
                   }
                   token = strtok(NULL,"\t");
               }

               if (i < 3)
               {
                   $drop table tmp_policy;
                   $drop table tmp_policy2;
                   fclose(fptr);
                   SQLCODE = -846;
                   return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
               }
               /* �g�J����table */
               $insert into tmp_policy2
                select unique  a.ipre_rcv, a.isys
                  from cm_pre_receive a, ao_prercv_pass b
                 where a.ipre_rcv = b.ipre_rcv
                   and a.iins_kind = b.iins_kind
                   and a.ipre_end = b.ipre_end
                   and a.iins_cat = 'C'
                   and a.ftype = 'P'
                   and a.ipre_rcv[6,7] = 'CR'
                   and a.fstatus >=  50  and a.fstatus <  90
                   and a.iofficer = $stp_officer
                   and a.isys in ('4','5')
                   and a.isub = $DBName
                   and a.dclose is null
                   and b.dentry between extend(date($sdentry1)) and extend(date($sdentry2)+1)
                   and a.dentry >= add_months(today,-7);
                
                /*$insert into tmp_policy2
                select unique b.ipre_rcv, 
                       (select isys from cm_pre_receive 
                         where ipre_rcv = b.ipre_rcv 
                           and iins_kind = b.iins_kind 
                           and ipre_end = b.ipre_end)
                  from ao_prercv_pass b
                 where b.dentry between extend(date($sdentry1)) and extend(date($sdentry2)+1)
                   and b.iins_cat = 'C'
                   and b.ipre_rcv[6,7] = 'CR'
                   and b.ipre_end = ' '
                   and exists (select ipre_rcv,iins_kind,ipre_end 
                                 from cm_pre_receive 
                                where ipre_rcv = b.ipre_rcv and iins_kind = b.iins_kind
                                  and ipre_end = b.ipre_end and ftype = 'P'
                                  and iofficer = $stp_officer
                                  and isub = $DBName
                                  and isys in ('4','5')
                                  and dclose is null
                                  and dentry >= add_months(today,-7)
                                  and fstatus >=  50  and fstatus <  90);*/
           }
           fclose(fptr);
           printf("Ū�ɧ���!! \n");
        }

        sprintf_s(stmt1, sizeof stmt1, "select a.ipolicy, b.iestimate, b.isys , a.icar_type\
                          from policy_302 a, tmp_policy2 b \
                         where a.iestimate_ori = b.iestimate \
                           and b.isys = '4' \
                         union \
                         select a.ipolicy, b.iestimate, b.isys , a.icar_type\
                          from policy_302 a, tmp_policy2 b \
                         where a.iestimate_sug = b.iestimate \
                           and b.isys = '5' ");

        $PREPARE  preR31 FROM $stmt1;
        $DECLARE  curR31 CURSOR FOR preR31;
        $OPEN     curR31;
        k=0;
        while(1)
        {
            $FETCH curR31 INTO $sIpolicy,$tmp_iestimate,$sIsys,$tmp_icar_type;
            if(SQLCODE == SQLNOTFOUND)  break;

            iCount2     = 0;
            /*car322���C�L�A�@���P�q�ʦۦ樮����}�C�L*/
 	    if ((strcmp(iest_bgn,"A") == 0) && (strcmp(tmp_icar_type,"51")==0))
 	    	continue;
 	    else if ((strcmp(iest_bgn,"A") != 0) && (strcmp(tmp_icar_type,"51")!=0))
 	    	continue;

	    strcpy(FullDB,get_dtl_full_db(sIpolicy));
            		sprintf_s(stmt2, sizeof stmt2, "select count(ipolicy) from %s:ply_relation where ipolicy = '%s' \
                               and (trim(inext_ply)= '' or inext_ply is null)",FullDB, sIpolicy);

            $PREPARE  preR32 FROM $stmt2;
            $DECLARE  curR32 CURSOR FOR preR32;
            $OPEN     curR32;
            $FETCH curR32 INTO $iCount2;
            if (iCount2 > 0)
            {
                k++;
                $insert into tmp_policy (iestimate, isys) values ($tmp_iestimate,$sIsys);
            }
            $CLOSE curR32;
            $FREE curR32;
        }
        $CLOSE curR31;
        $FREE curR31;

        if (k == 0)
        {
            if (exitsub(reply,M_CM_NOT_FOUND) == True)
                    return M_CM_NOT_FOUND;     /* ��O�J�p�ɬd�L��� */
                else
                    return apiRC;
        }
    }
    else
    {
        iCount2 = fuw_status = 0;
        memset(tmp_iestimate,0,sizeof(tmp_iestimate));
        strcpy(iest_bgn, trim(iest_bgn));
        
        if (itype == 1)
        	ProtectData = 1;
        else
        	ProtectData = 0;

printf("ProtectData[%d]\n",ProtectData);

        if (itype == 0 || itype == 1)   /* ��O�J�p�����渹 */
        {
            /* �O�_����O�J�p��B�O�浧(��j�γ��)�٬O�j+�� */
            $select count(*) into $iCount2 from policy_302 where iestimate_ori = $iest_bgn;
            if (iCount2 > 0)
            {
                strcpy(sIsys,"4");  /* ���O�զX */
                itype = 4;
            }
            else
            {
                $select count(*) into $iCount2 from policy_302 where iestimate_sug = $iest_bgn;
                if (iCount2 > 0)
                {
                    strcpy(sIsys,"5");  /* ��ĳ��O�զX */
                    itype = 5;
                }
            }
            strcpy(tmp_iestimate,iest_bgn);

        }
        else if (itype == 4)   /* ��O�O�渹--���O�զX */
        {
            strcpy(sIsys,"4");
            /* �O�_����O�J�p��B�O�浧(��j�γ��)�٬O�j+�� */
            $select iestimate_ori, count(*)
               into $tmp_iestimate, $iCount2
               from policy_302
              where iestimate_ori =
                    (select iestimate_ori from policy_302 where ipolicy = $iest_bgn)
                and fuw_status_ori >= 500
                and iestimate_ori <> ' '
              group by 1;

            if(SQLCODE == SQLNOTFOUND)
                iCount2 = 0;

            $select nvl(fuw_status_ori,0) into $fuw_status
               from policy_302
              where ipolicy = $iest_bgn;
        }
        else if (itype == 5)   /* ��O�O�渹--��ĳ��O�զX */
        {
            strcpy(sIsys,"5");
            /* �O�_����O�J�p��B�O�浧(��j�γ��)�٬O�j+�� */
            $select iestimate_sug, count(*)
               into $tmp_iestimate, $iCount2
               from policy_302
              where iestimate_sug =
                    (select iestimate_sug from policy_302 where ipolicy = $iest_bgn)
               and fuw_status_sug >= 500
                and iestimate_sug <> ' '
              group by 1;

            if(SQLCODE == SQLNOTFOUND)
                iCount2 = 0;

            $select nvl(fuw_status_sug,0) into $fuw_status
               from policy_302
              where ipolicy = $iest_bgn;
        }
        $insert into tmp_policy (iestimate, isys) values ($tmp_iestimate,$sIsys); /*�g�J�Ȧs�� */
        if (iCount2 == 0)
        {
            if (fuw_status > 0 && fuw_status < 500)
            {
                if (exitsub(reply,M_CA_REPLY_UNPASS) == True)
                    return M_CA_REPLY_UNPASS;     /* ��O�J�p�������H�u�֫O */
                else
                    return apiRC;
            }

            if (exitsub(reply,M_CM_NOT_FOUND) == True)
                return M_CM_NOT_FOUND;     /* ��O�J�p�ɬd�L��� */
            else
                return apiRC;
        }
    }

    time(&now);
    sprintf_s(sTmp0, sizeof sTmp0,"application_%s%s%ld.txt",DBName,sUserid,now);
    sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,sTmp0);
    fp0=fopen(file0,"w");

    sprintf_s(sTmp1, sizeof sTmp1,"application_%s%s%ld_dtl.txt",DBName,sUserid,now);
    sprintf_s(file1, sizeof file1,"%s/rptftp/%s",sApHome,sTmp1);
    fp1=fopen(file1,"w");
    
    sprintf_s(sTmp4, sizeof sTmp4,"application_%s%s%ld_list.txt",DBName,sUserid,now);
    sprintf_s(file4, sizeof file4,"%s/rptftp/%s",sApHome,sTmp4);
    fp4=fopen(file4,"w");

    sprintf_s(stmt1, sizeof stmt1, "select unique iestimate, isys from tmp_policy");
    $PREPARE  preRA1 FROM $stmt1;
    $DECLARE  curRA1 CURSOR FOR preRA1;
    $OPEN     curRA1;
    while(1)
    {
        $FETCH curRA1 INTO $tmp_iestimate,$isys;
        if(SQLCODE == SQLNOTFOUND)  break;
        
        strcpy(sIsys,itoa(isys));
        
printf("3389---sIsys[%s]\n",sIsys);

	/*�j+���ɡA��O�O��ݩ���N��O�O�渹*/
	if (isys == 4) /* ���O�զX */
        {
	   $select fcard_class
	      into $tmp_fcard_class
              from policy_302
             where iestimate_ori = $tmp_iestimate
               and fuw_status_ori >= 500
	       and iestimate_ori <> ' '
	       and fcard_class = '2';

           if(SQLCODE == SQLNOTFOUND)
         	strcpy(tmp_fcard_class,"1");
        }
        else     /* ��ĳ��O�զX */
        {
           $select fcard_class
              into $tmp_fcard_class
              from policy_302 a
             where iestimate_sug = $tmp_iestimate
               and fuw_status_sug >= 500
	       and iestimate_sug <> ' '
	       and fcard_class = '2';

	   if(SQLCODE == SQLNOTFOUND)
         	strcpy(tmp_fcard_class,"1");
	}

        if (isys == 4) /* ���O�զX */
        {
            sprintf_s(stmt5, sizeof stmt5, " a.iestimate_ori, decode(a.fcard_class,'2',nvl(v_ori_prem,0),0),  \
                             decode(a.fcard_class,'1',nvl(comp_prem,0),0), decode(nvl(a.pdmg_acc,''),'','0.0',a.pdmg_acc)::float, \
                             iquery_num_damage,qdmg_acc_sum,itransno_ori,fuw_status_ori, \
                             punknown_acc_ori,iquery_num_unknown_ori " );

            sprintf_s(stmt4, sizeof stmt4, " and iestimate_ori = '%s' and a.fcard_class matches '%s' ", tmp_iestimate,tmp_fcard_class);
        }
        else     /* ��ĳ��O�զX */
        {
            sprintf_s(stmt5, sizeof stmt5, " a.iestimate_sug, decode(a.fcard_class,'2',nvl(tot_prem,0),0),  \
                             decode(a.fcard_class,'1',nvl(mcomp_prem_sug,0),0), decode(nvl(a.pdmg_acc_sug,''),'','0.0',a.pdmg_acc_sug)::float, \
                             iquery_num_damage_sug, qdmg_acc_sum_sug, itransno_sug, fuw_status_sug, \
                             punknown_acc_sug, iquery_num_unknown_sug ");

            sprintf_s(stmt4, sizeof stmt4, " and iestimate_sug = '%s' and a.fcard_class matches '%s' ", tmp_iestimate,tmp_fcard_class);
        }

        sprintf_s(stmt, sizeof stmt,
            "select first 1 ' ', ' ', a.irelative_ply, a.ipolicy, a.icard, \
                    ' ', ' ', \
                    decode(a.fcard_class,'2',to_char(a.dply_begin),' '), \
                    decode(a.fcard_class,'2',to_char(a.dply_end),' '), \
                    decode(a.fcard_class,'1',to_char(a.dply_bgn_comp),' '), \
                    decode(a.fcard_class,'1',to_char(a.dply_end_comp),' '), \
                    a.fassured, a.ilicense, ' ', a.nassured, ' ', \
                    a.dbirth, a.fsex, a.fmarriage, a.nuser, ' ', \
                    a.nbenef, a.aassured, a.aassured_zip, a.itel, a.tphone_con , \
                    a.imovephone , a.apayment, a.apayment_zip, a.iply_area, a.dissue, \
                    a.ipro_year || '/' || a.qpro_month::CHAR(2), a.ibrand, a.nbrand_abbr, decode(a.fcard_class,'2',a.icar_type,' '), \
                    decode(a.fcard_class,'1',a.icar_type,' '), a.ncar_type, ' ' , a.qcylinder, \
                    a.iengine, a.ibody, a.itag, replace(a.mcar_price,',','')/10000, nvl(a.pdmg_align,0), \
                    nvl(a.pbrg_align,0), nvl(a.plia_align,0), a.ibig_comp, a.ibig_branch, \
                    a.ibig_office, 0, a.ibig_sales, ' ', ' ', \
                    ' ',' ', decode(a.fcard_class,'2',a.iofficer,' '), \
                    decode(a.fcard_class,'1',a.iofficer,' '), a.icorps, ' ', ' ', ' ', \
                    date(a.dupdate) , ' ', date(a.dupdate), ' ', 'M', \
                    decode(a.fcard_class,'1',ipolicy,' '), decode(a.fcard_class,'2',ipolicy,' '),  \
                    a.ipolicy[1,2], a.qpt, a.fpt, \
                    to_char(a.psex_age), \
                    to_char(a.psex_age_c), \
                    a.psex_age_damage, a.lia_class, nvl(a.plia_acc,' '), \
                    nvl(a.plia_acc_c,' '), \
                    nvl(a.dmg_ac_cnt1,0), nvl(a.dmg_ac_cnt2,0), nvl(a.dmg_ac_cnt3,0),  ' ', a.fcomp_24, \
                    a.mbusiness, a.mbusiness, a.fcomp_class, a.fcomp_class_last, a.iemail, \
                    nvl(a.iquery_num_c,' '), \
                    nvl(a.iquery_num,' ') , \
                    a.fcar_class, a.ncar_type, d.nname, d.icomm_obj, \
                    a.napplicant, 0, a.iroute, a.iroute_prop, \
                    decode(a.fcard_class,'2',a.iroute_comm,' '), nvl(a.qlia_acc_sum,0), \
                    a.ndeputy_assured, a.ndeputy_appl, a.nrelation_appl, a.fsex_appl, \
                    a.fapplicant, a.iapplicant, a.dbirth_appl, a.itel_appl, a.fcard_class, a.qdrunk_driving, \
                    a.nequipment, ' ', a.iassured_cntry, a.iapplicant_cntry, a.ileader,%s, \
                    a.foccup,a.noccup,a.applicant_foccup,a.applicant_noccup, \
                    0.0,0.0, \
                    case when a.dply_begin < '07/01/2019' then 'Y' else 'N' end, \
                    a.tmobile_eply,a.tmobile_appl,a.aemail_appl,a.feterms,a.qviolate, \
                    case when a.dply_begin >= '06/01/2023' then 'Y' else 'N' end \
               from policy_302 a, officer d \
                    where a.iofficer = d.iofficer %s ", stmt5, stmt4);

        printf("stmt=[%s]\n", stmt);

        icount1 = 0;
        $PREPARE  perR2 FROM $stmt;
        $DECLARE  curR2 CURSOR FOR perR2;
        $OPEN     curR2;
        while(1)
        {
            $FETCH curR2 INTO
                    $Est.icard2,$Est.icard1,$Est.irelative_ply, $Est.ilast_ply,$Est.ilast_card,
                    $Est.irelative_card,$Est.ixxcard,
                    $Est.dply2_begin,
                    $Est.dply2_end,
                    $Est.dply1_begin,
                    $Est.dply1_end,
                    $Est.fassured,$Est.iassured,$Est.iassured_ext,$Est.nassured,$Est.ilicense,
                    $Est.dbirth,$Est.fsex,$Est.fmarriage, $Est.nuser,$Est.ibenef,
                    $Est.nbenef,$Est.aassured, $Est.aassured_zip,$Est.itel,$Est.itel_night,
                    $Est.mobil_phone,$Est.apayment,$Est.apayment_zip,$Est.iply_area,$Est.dissue,
                    $Est.ipro_year,$Est.ibrand,$Est.nbrand_abbr,$Est.icar_type2,
                    $Est.icar_type1,$Est.ncar_abbr,$Est.fcar_note2,$Est.qcylinder,
                    $Est.iengine,$Est.ibody,$Est.itag,$Est.mcar_price,$Est.pdmg_align,
                    $Est.pbrg_align,$Est.plia_align,$Est.ibig_comp,$Est.ibig_branch,
                    $Est.ibig_office, $Est.qprovision, $Est.ibig_sales,$Est.iresource,$Est.fdiscount,
                    $Est.ibroker2, $Est.ibroker1,$Est.iofficer2,
                    $Est.iofficer1,$Est.icorps, $Est.iarea,$Est.icashier,$Est.iexaminer,
                    $Est.dexamine, $Nquota,$Est.dentry,$Est.dapply,$Est.fcal_way,
                    $Est.ipolicy1,$Est.ipolicy2 ,
                    $Est.ibranch,$Est.qpt, $Est.fpt,
                    $Est.psex_age2,
                    $Est.psex_age1,
                    $Est.psex_age_damage, $Est.lia_class,$Est.plia_acc2,
                    $Est.plia_acc1,
                    $Est.dmg_acc_1st,$Est.dmg_acc_2nd,$Est.dmg_acc_3rd,$Est.fhuman,$Est.fcomp_24,
                    $Est.mbus_rule,$Est.mbusiness,$Est.fcomp_class,$Est.fcomp_class_last,$Est.iemail,
                    $Est.iquery_num_c,
                    $Est.iquery_num ,
                    $Fcar_class,$Ncode,$Nname,
                    $icomm_obj,
                    $Est.napplicant,$Est.mequipment,$Est.iroute, $Est.iroute_prop,
                    $Est.iroute_comm2,$Est.qlia_acc_sum,
                    $Est.ndeputy_assured, $Est.ndeputy_appl, $Est.nrelation_appl, $Est.fsex_appl,
                    $sFapplicant, $Est.iapplicant, $Est.dbirth_appl, $Est.itel_appl, $sFcard_class, $Est.qdrunk_driving,
                    $Est.nequipment,$Est.iaccept, $sIassured_cntry, $sIapplicant_cntry,$sIleader,
                    $Est.iestimate,$Est.mpremium2,$Est.mpremium1,$Est.pdmg_acc,$Est.iquery_num_damage,
                    $Est.qdmg_acc_sum,$Est.transno,$Est.fuw_status,$punknown_acc,$iquery_num_unknown,
                    $Est.foccup, $Est.noccup, $Est.applicant_foccup, $Est.applicant_noccup,
                    $Est.nmile_ubi, $Est.pubi_acc,$fchk_24,$Est.tmobile_eply,$tmobile_appl,$aemail_appl,$feterms,$qviolate,$f20230601;

            if(SQLCODE == SQLNOTFOUND)
                break;

            /* �s�W�Ӹ��ˮ�   add by sylvia 103.02.14 (1020924002_C2) */
            iCountDeny=0;
            $select count(*) into $iCountDeny
            from cm_personal_deny
           where iassured = $Est.iassured
             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
             and ddeny <= today
             and (dexpire is null or dexpire >= today);
            if(iCountDeny > 0)
            continue;
            
            strcpy(sIleader,trim(sIleader));
	      $SELECT nname
	         INTO $nleader
	         FROM officer
	        WHERE iofficer = $sIleader;
	        
	      if(SQLCODE == SQLNOTFOUND)
	      		strcpy(nleader," "); 
/*
	strcpy(sIleader,trim(sIleader));

      if (strcmp(sIleader,sUserid) != 0)
      {
      		/* �O�������ˮ�(�j��) 
      		rtn = chk_spec_deny( Est.ipolicy1, Est.icard1, Est.iassured, Est.iapplicant, Est.itag, Est.iengine, sMsg);
      		if (rtn == M_CA_SPEC_DENY)
         		continue;

      		/* �O�������ˮ�(���N) 
      		rtn = chk_spec_deny( Est.ipolicy2, Est.icard2, Est.iassured, Est.iapplicant, Est.itag, Est.iengine, sMsg);
      		if (rtn == M_CA_SPEC_DENY)
         		continue;
      }
*/
            /* �g���H�W�� */
            $select nchi_abv into $Nchi_abv
               from broker_agent where
               ibroker = (select ibroker_top from v_commission_obj where icomm_obj = $icomm_obj);

            /* �q�O���ɨ���O�J�p�S������� */
            strcpy(Est.idmg_rate,"00");
            Est.pdmg_factor = 0;
            strcpy(Est.ibrg_rate,"00");
            Est.pbrg_factor = 0;
            
            if (strcmp(sFcard_class,"2") == 0)
            {
            	sprintf_s(stmt3, sizeof stmt3,"select a.idmg_rate, a.dmg_factor, a.ibrg_rate, a.brg_factor \
                             from policy_302 a where ipolicy = '%s'",Est.ilast_ply);
            }
            else
            {
            	sprintf_s(stmt3, sizeof stmt3,"select a.idmg_rate, a.dmg_factor, a.ibrg_rate, a.brg_factor \
                             from policy_302 a where ipolicy = '%s'", Est.irelative_ply);
            }

            $PREPARE  perR4 FROM $stmt3;
            $DECLARE  curR4 CURSOR FOR perR4;
            $OPEN     curR4;
            $FETCH curR4 INTO $Est.idmg_rate,$Est.pdmg_factor,$Est.ibrg_rate,$Est.pbrg_factor;
            $CLOSE     curR4;
            $FREE      curR4;

            if(SQLCODE == SQLNOTFOUND)
            {
            	strcpy(Est.idmg_rate,"00");
            	Est.pdmg_factor = 0;
            	strcpy(Est.ibrg_rate,"00");
            	Est.pbrg_factor = 0;
            	
            }

            if (strncmp(sIsys,"4",1) == 0)
          	strcpy(sBarcode_type,"���O");
            else if (strncmp(sIsys,"5",1) == 0)
          	strcpy(sBarcode_type,"��ĳ��O");

            /*strcpy(Est.itel_night, " ");
            strcpy(Est.mobil_phone, " ");*/
            
            /*�q�l�j���ҡB�q�l�O����O�B�q�l���ڵ��O*/
            /*�q�l���ڵ��O
              1.�e��J���< 07/01/2021�B�J�p��< 07/01/2021�A�����q���@�߹w�]���ȥ����ڡC
              2.�e��O���ͮĤ�< 09/01/2021�A�����q���@�߹w�]���q�l���ڡC
              3.�e��O���ͮĤ�� 09/01/2021�A�����q���u�Ϋe�椧�̷s�O���ɵ��O�C
            */
            strcpy(FullDB,get_dtl_full_db(Est.ilast_ply));
       	    sprintf_s(stmt_feply, sizeof stmt_feply,
                   "SELECT case WHEN a.fcard_class = '2' THEN a.feply ELSE nvl((SELECT feply FROM %s:ply_relation WHERE ipolicy = a.irelative_ply),'0') END, "
	           "       case WHEN a.fcard_class = '1' THEN a.feply ELSE nvl((SELECT feply FROM %s:ply_relation WHERE ipolicy = a.irelative_ply),'0') END, "
              	   "       case WHEN a.fcard_class = '2' THEN (CASE WHEN trim(a.aemail_eply) <>'' THEN a.aemail_eply ELSE nvl((SELECT trim(aemail_eply) FROM %s:ply_relation WHERE ipolicy=a.irelative_ply),'') END ) "
                   "       else (CASE nvl((SELECT trim(aemail_eply) FROM %s:ply_relation WHERE ipolicy=a.irelative_ply),'') WHEN '' THEN (case trim(a.aemail_eply) when '' then '' else trim(a.aemail_eply) end  ) else (SELECT trim(aemail_eply) FROM %s:ply_relation WHERE ipolicy=a.irelative_ply) END) END, "
                   "       case WHEN a.fcard_class = '2' THEN (CASE WHEN trim(a.tmobile_eply) <>'' THEN a.tmobile_eply ELSE nvl((SELECT trim(tmobile_eply) FROM %s:ply_relation WHERE ipolicy=a.irelative_ply),'') END ) "
                   "       else (CASE nvl((SELECT trim(tmobile_eply) FROM %s:ply_relation WHERE ipolicy=a.irelative_ply),'') WHEN '' THEN (case trim(a.tmobile_eply) when '' then '' else trim(a.tmobile_eply) end  ) else (SELECT trim(tmobile_eply) FROM %s:ply_relation WHERE ipolicy=a.irelative_ply) END) END, "
                   "       case WHEN a.fcard_class = '1' THEN '0' ELSE (CASE WHEN DATE(a.dcreate)<'07/01/2021' AND DATE(b.dupdate)<'07/01/2021' THEN '0' ELSE (CASE WHEN a.dply_begin<'09/01/2021' THEN '1' ELSE a.feterms END)END)END"
                   "  FROM %s:ply_relation a,policy_302 b"
                   " WHERE a.ipolicy=? AND a.ipolicy=b.ipolicy ", FullDB, FullDB, FullDB, FullDB, FullDB, FullDB, FullDB, FullDB, FullDB);

            printf("stmt_feply=[%s]\n", stmt_feply);
                
            $prepare pre_eply from $stmt_feply;
       	    $execute pre_eply
       	        into $feply, $fecard, $aemail_eply,$Est.tmobile_eply,$feterms
               using $Est.ilast_ply;
            if (NOT_FOUND) {
                strcpy(feply," ");
                strcpy(fecard," ");
                strcpy(aemail_eply," ");
                strcpy(Est.tmobile_eply," ");
                strcpy(feterms," ");
            }
            
            
            
            

            printf("Est.iestimate=[%s]Est.irelative_ply=[%s]\n",Est.iestimate,Est.irelative_ply);
            printf("Est.ipolicy1=[%s]Est.ipolicy2=[%s]\n",Est.ipolicy1,Est.ipolicy2);
            icount1++;

            /* �����s���O���� */
            strcpy(Est.irelative_ply, trim(Est.irelative_ply));
            $select count(*) into $iCount2
              from cm_pre_receive
             where iins_cat = 'C'
               and ipre_rcv = $Est.iestimate
               and ftype = 'P';

            if(SQLCODE == SQLNOTFOUND)
                iCount2 = 0;

            printf("iCount2=[%d]\n",iCount2);
            if (iCount2 > 1 )
            {
                    if (strcmp(sFcard_class,"2") == 0)
    		    {	 /* ���p�O��O�j���I�O�� */
    		        if (isys == 4) /* ���O�զX */
    		        {
        		        $select ' ', ' ', a.dply_bgn_comp, a.dply_end_comp,
        		                a.icar_type, nvl(a.comp_prem,0), ' ', a.iofficer,
        		                ipolicy, a.psex_age, nvl(a.plia_acc_c,' '), a.iquery_num_c,
        		                a.iestimate_ori, a.fcomp_class
                                   into $Est.icard1, $Est.irelative_card, $Est.dply1_begin,$Est.dply1_end,
        		                $Est.icar_type1, $Est.mpremium1, $Est.ibroker1, $Est.iofficer1,
        		                $Est.ipolicy1, $Est.psex_age1, $Est.plia_acc1, $Est.iquery_num_c,
        		                $tmp_iestimate, $Est.fcomp_class
        		           from policy_302 a
        		          where a.fcard_class = '1'
        		            and a.iestimate_ori = $Est.iestimate;
    		        }
    		        else
    		        {   /* ��ĳ��O�զX */
    		                $select ' ', ' ', a.dply_bgn_comp, a.dply_end_comp,
        		                a.icar_type, nvl(a.mcomp_prem_sug,0), ' ', a.iofficer,
        		                ipolicy, a.psex_age, nvl(a.plia_acc_c,' '), a.iquery_num_c,
        		                a.iestimate_sug, a.fcomp_class
                                   into $Est.icard1, $Est.irelative_card, $Est.dply1_begin,$Est.dply1_end,
        		                $Est.icar_type1, $Est.mpremium1, $Est.ibroker1, $Est.iofficer1,
        		                $Est.ipolicy1, $Est.psex_age1, $Est.plia_acc1, $Est.iquery_num_c,
        		                $tmp_iestimate, $Est.fcomp_class
        		           from policy_302 a
        		          where a.fcard_class = '1'
        		            and a.iestimate_sug = $Est.iestimate;

        		          if (SQLCODE == SQLNOTFOUND)
        		          {
            		              /* �����㨮���ѥ��N�|��ĳ�j�� */
                  	              $select count(*) into $iCnt21 from ply_ins_type_302
                  	                where ipolicy = $Est.ilast_ply
                  	                  and iins_type = '21' and pre_dam_cover = 0 and mdamage_cover > 0;
                  	              if ((iCnt21 > 0) && (isys == 5))
                  	              {
                                          strcpy(Est.icard1, " ");
                		          strcpy(Est.irelative_card, " ");
                		          strcpy(Est.dply1_begin, Est.dply2_begin);
                		          strcpy(Est.dply1_end, Est.dply2_end);
                		          strcpy(Est.icar_type1, Est.icar_type2);

                		          strcpy(Est.ibroker1,Est.ibroker2);
                		          strcpy(Est.iofficer1,Est.iofficer2);
                		          strcpy(Est.ipolicy1, " ");
                		          strcpy(Est.iquery_num_c, " ");
                		          strcpy(sIestimate_c, Est.iestimate);
                		          Est.plia_acc1 = 0.00;
                		          Est.pdmg_acc = 0.0;

                		          $select psex_age, mcomp_prem_sug
                		             into $Est.psex_age1, $Est.mpremium1
                		             from policy_302
                		            where ipolicy = $Est.ilast_ply;
                                      }
                                  }
    		        }
                        strcpy(sIestimate_c, tmp_iestimate);
                    }
    		    else
                    { /* ���p�O��O���N�I�O�� */
                        strcpy(sIestimate_c, Est.iestimate);
                        if (isys == 4)
                        {
        		        $select ' ', ' ', a.dply_begin, a.dply_end,
        		                a.icar_type, nvl(a.v_ori_prem,0), ' ', a.iofficer,
        		                ipolicy, a.psex_age, nvl(a.plia_acc,0), a.iquery_num,
        		                a.iestimate_ori, nvl(a.lia_class,0),
        		                decode(a.pdmg_acc,' ','0',nvl(a.pdmg_acc,0)),a.iquery_num_damage
        		           into $Est.icard2, $Est.irelative_card, $Est.dply2_begin,$Est.dply2_end,
        		                $Est.icar_type2, $Est.mpremium2, $Est.ibroker2, $Est.iofficer2,
        		                $Est.ipolicy2, $Est.psex_age2, $Est.plia_acc2, $Est.iquery_num,
        		                $Est.iestimate,$Est.lia_class,$Est.pdmg_acc,$Est.iquery_num_damage
        		           from policy_302 a
        		          where a.fcard_class = '2'
        		            and a.iestimate_ori = $Est.iestimate;
                        }
                        else
                        {
                                $select ' ', ' ', a.dply_begin, a.dply_end,
        		                a.icar_type, nvl(a.tot_prem,0), ' ', a.iofficer,
        		                ipolicy, a.psex_age, nvl(a.plia_acc,0), a.iquery_num,
        		                a.iestimate_sug,nvl(a.lia_class,0),
        		                decode(a.pdmg_acc_sug,' ','0',nvl(a.pdmg_acc_sug,0)),a.iquery_num_damage
        		           into $Est.icard2, $Est.irelative_card, $Est.dply2_begin,$Est.dply2_end,
        		                $Est.icar_type2, $Est.mpremium2, $Est.ibroker2, $Est.iofficer2,
        		                $Est.ipolicy2, $Est.psex_age2, $Est.plia_acc2, $Est.iquery_num,
        		                $Est.iestimate,$Est.lia_class,$Est.pdmg_acc,$Est.iquery_num_damage
        		           from policy_302 a
        		          where a.fcard_class = '2'
        		            and a.iestimate_sug = $Est.iestimate;

        		             if (SQLCODE == SQLNOTFOUND)
        		             {
            		                 /* �����ˮ`�j��|��ĳ���N */
                  	                 $select count(*) into $iCnt47 from ply_ins_type_302
                  	                   where ipolicy = $Est.ilast_ply
                  	                     and iins_type <> '21' and mdamage_cover > 0;

                  	                 if ((iCnt47 > 0) && (isys == 5))
                  	                 {
                                             strcpy(Est.dply2_begin, Est.dply1_begin);
                                             strcpy(Est.dply2_end, Est.dply1_end);
                                         }
                                     }
                        }
                    }
    		    strcpy(Est.irelative_ply, " "); /* �]���O��O�J�p���,�o�̪����p�O�渹�O�h�~�O�檺���p�O�渹,�����M�� */
            }
            else
            {
                    printf("iCnt21=[%d] isys=[%d]\n",iCnt21,isys);
                    strcpy(Est.irelative_ply, " ");
                    if (strcmp(sFcard_class,"2") == 0)
          	    {
          	        /* �����㨮���ѥ��N�|��ĳ�j�� */
          	        $select count(*) into $iCnt21 from ply_ins_type_302
          	          where ipolicy = $Est.ilast_ply
          	            and iins_type = '21' and pre_dam_cover = 0 and mdamage_cover > 0;
          	        if ((iCnt21 > 0) && (isys == 5))
          	        {
                                strcpy(Est.icard1, " ");
        		        strcpy(Est.irelative_card, " ");
        		        strcpy(Est.dply1_begin, Est.dply2_begin);
        		        strcpy(Est.dply1_end, Est.dply2_end);
        		        strcpy(Est.icar_type1, Est.icar_type2);

        		        strcpy(Est.ibroker1,Est.ibroker2);
        		        strcpy(Est.iofficer1,Est.iofficer2);
        		        strcpy(Est.ipolicy1, " ");
        		        strcpy(Est.iquery_num_c, " ");
        		        strcpy(sIestimate_c, Est.iestimate);
        		        Est.plia_acc1 = 0.00;
        		        Est.pdmg_acc = 0.0;

        		        $select psex_age, mcomp_prem_sug
        		           into $Est.psex_age1, $Est.mpremium1
        		          from policy_302
        		          where ipolicy = $Est.ilast_ply;
                        }
                        else
                        {
          	                 /* ���p�O��O�j���I�O�� */
        		         strcpy(Est.icard1, " ");
        		         strcpy(Est.irelative_card, " ");
        		         strcpy(Est.dply1_begin, " ");
        		         strcpy(Est.dply1_end, " ");
        		         strcpy(Est.icar_type1, " ");
        		         Est.mpremium1 = 0;
        		         strcpy(Est.ibroker1, " ");
        		         strcpy(Est.iofficer1, " ");
        		         strcpy(Est.ipolicy1, " ");
        		         Est.psex_age1 = 0;
        		         Est.plia_acc1 = 0.00;
        		         strcpy(Est.iquery_num_c, " ");
        		         strcpy(sIestimate_c, " ");
    		        }
           	    }
           	    else
           	    {	
           	       /* ���p�O��O���N�I�O�� */
                       $select count(*) into $iCnt47 from ply_ins_type_302
                  	 where ipolicy = $Est.ilast_ply
                  	   and iins_type <> '21' and mdamage_cover > 0;

                  	if ((iCnt47 > 0) && (isys == 5))
                  	{
                            strcpy(Est.dply2_begin, Est.dply1_begin);
                            strcpy(Est.dply2_end, Est.dply1_end);
                        }
                        else
                        {
                    	    strcpy(Est.dply2_begin, " ");
    		            strcpy(Est.dply2_end, " ");
                        }
    		        strcpy(Est.icard2, " ");
    		        strcpy(Est.irelative_card, " ");
    		        strcpy(Est.icar_type2, Est.icar_type1);
    		        Est.mpremium2 = 0;
    		        strcpy(Est.ibroker2, Est.ibroker1);
    		        strcpy(Est.iofficer2, Est.iofficer1);
    		        strcpy(Est.ipolicy2, " ");
    		        Est.psex_age2 = 0;
    		        Est.plia_acc2 = 0.00;
    		        strcpy(Est.iquery_num, " ");
    		        strcpy(sIestimate_c, Est.iestimate);
    		        strcpy(Est.iestimate, " ");
           	    }
            }
            /* �e��j��Υ��N�g�� */
            strcpy(Fcard_class," ");
            strcpy(LastOff1," ");
            strcpy(LastOff2," ");
            if (strlen(rtrim(Est.ilast_ply))!=0)
            {
       	        strcpy(FullDB,get_dtl_full_db(Est.ilast_ply));
       	        sprintf_s(stmt_last, sizeof stmt_last,
       	                    "select x.fcard_class,trim(x.iofficer) || y.nname, "
                            "       (select trim(a.iofficer)||b.nname "
                            "          from %s:ply_relation a, officer b "
                            "         where a.iofficer = b.iofficer "
                            "           and x.irelative_ply = a.ipolicy ) "
                            "  from %s:ply_relation x, outer officer y "
                            " where x.ipolicy = ? "
                            "   and x.iofficer = y.iofficer", FullDB,FullDB);

                printf("stmt_last=[%s]\n", stmt_last);

                $prepare pre_lastR3 from $stmt_last;
       	        $execute pre_lastR3
       	            into $Fcard_class,$LastOff1,$LastOff2
                   using $Est.ilast_ply;
                if (NOT_FOUND) {
                    strcpy(Fcard_class," ");
                    strcpy(LastOff1," ");
                    strcpy(LastOff2," ");
                }
            }

            strcpy(Est.iestimate, trim(Est.iestimate));
            strcpy(sIestimate_c, trim(sIestimate_c));
            printf("-----sIestimate_c=[%s] Est.irelative_ply=[%s]\n",sIestimate_c,Est.irelative_ply);
            printf("3155---iquery_num_damage[%s]\n",Est.iquery_num_damage);
            
            /*�e��j����N�O�渹*/
            strcpy(iLastRelative_ply1,"");
            strcpy(iLastRelative_ply2,"");
            strcpy(stmt_last,"");
            if (strlen(rtrim(Est.ilast_ply))!=0) 
            {
		strcpy(FullDB,get_dtl_full_db(Est.ilast_ply));
   	        sprintf_s(stmt_last, sizeof stmt_last,
		   	    "select (CASE WHEN fcard_class ='1' THEN  ipolicy ELSE nvl(irelative_ply,'') end),"
		   	    "       (CASE WHEN fcard_class ='1' THEN nvl(irelative_ply,'')  ELSE ipolicy end) "
		            "  from %s:ply_relation  "
		            " where ipolicy = ? ", FullDB);

		printf("stmt_last=[%s]\n", stmt_last);

		$prepare pre_LastRelative5 from $stmt_last;
		$execute pre_LastRelative5
		    into $iLastRelative_ply1,$iLastRelative_ply2 using $Est.ilast_ply;
		if (NOT_FOUND) 
		{
		    strcpy(iLastRelative_ply1," ");
		    strcpy(iLastRelative_ply2," ");
		    break;
		}
            }
            
            /* ��O�J�p�S��D���� */
            sNprovD[0]='\0';
            
            /* �^���r�p�H�ˮ`�W�U  1090221006_SC4_��_56�r�p�H�W�U */
      
		strcpy(FullDB,get_dtl_full_db(Est.ilast_ply));
					 /*"SELECT a.ipolicy,a.iins_type,a.iassured,a.nassured,"
			          "       CASE b.fassured WHEN '2' THEN '' WHEN '4' THEN '' WHEN '6' THEN ''  ELSE to_char(year(a.dbirth)-1911)||'/'||to_char(a.dbirth,'%m/%d') END ,"
			          "       a.nbenef,a.rel_benef,a.tbenef,a.abenef "
			          "  FROM ply_assured_302 a,policy_302 b "
			          " WHERE a.ipolicy=? AND a.ipolicy=b.ipolicy AND a.iins_type IN ('50') "
			          " UNION "*/

printf("--6130 %s \n",FullDB);  
		strcpy(stmt9_1," CASE b.fassured WHEN '2' THEN '' WHEN '4' THEN '' WHEN '6' THEN ''  ELSE to_char(year(a.dbirth)-1911)||'/'||to_char(a.dbirth,'%m%d') END");
  	    sprintf_s(stmt9, sizeof stmt9,"SELECT a.ipolicy,a.iins_type,a.iinsurant,a.ninsurant, "
  	                  "       %s , "
  	                  "       a.nbeneficiary,a.relation_bene,a.tbenef,a.abenef "
                      "  FROM ca_pa_ply_302 a,policy_302 b "
                      " WHERE a.ipolicy=? AND a.ipolicy=b.ipolicy AND a.iins_type IN ('56','136','266') "
                      " UNION "
		              "SELECT a.ipolicy,a.iins_type,a.iassured,a.nassured, "
		              "       %s, " 
		              "       a.nbenef,a.rel_benef,a.tbenef,a.abenef "
		              "  FROM %s:ply_ins_assured a,%s:policy b "
		              " WHERE a.ipolicy=? AND a.ipolicy=b.ipolicy AND a.iins_type IN ('147','561') ",stmt9_1,stmt9_1,FullDB,FullDB);
      	printf("stmt9=[%s]\n",stmt9);

        $PREPARE  pre_list_302 FROM $stmt9;
	    $DECLARE  cur_list_302 CURSOR FOR pre_list_302;
	    $OPEN     cur_list_302 using $Est.ilast_ply,$Est.ilast_ply;
	    while(1)
	    {
	        $FETCH cur_list_302 INTO $ipolicy_list,$iins_type_list,$iinsurant_list,
	                             $ninsurant_list,$dbirth_list,$nbeneficiary_list,
	                             $relation_bene_list,$tbenef_list,$abenef_list;

	        if(SQLCODE == SQLNOTFOUND)  break;

	        fprintf(fp4,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n", ipolicy_list,iins_type_list,iinsurant_list,ninsurant_list,dbirth_list,nbeneficiary_list,relation_bene_list,tbenef_list,abenef_list);
	    }
	    $close    cur_list_302;
	    $free     cur_list_302;
            /* �^���r�p�H�ˮ`�W�U  end ----------------------- */
            

            /* 97���O�n�O�ѤW��ܡi�䲼ú�ڡj104.04.23 (1040407003_C2) */
            if (equip_cmp(Est.nequipment,"97") == TRUE)
                strcpy(equip97,"Y");
            else
      	        strcpy(equip97,"N");
      	        
      	/******************* 30�I�ةӫO�d�򻡩����e(BEGIN) *******************/
printf("30�I�ةӫO�d�򻡩����eBEGIN\n");

	if (strcmp(sIsys,"4") == 0)
    {

		$SELECT iins_type,mdeduct
		   INTO $iins_type30_301,$deduct_30
		   FROM ply_ins_type_302
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type in ( '30','301','302', '530' )
		    AND ori_dam_cover > 0;
	}
	else
	{
		$SELECT iins_type,mdeduct
		   INTO $iins_type30_301,$deduct_30
		   FROM ply_ins_type_302
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type in ( '30','301','302', '530' )
		    AND mdamage_cover > 0;
	}
	    
	if(SQLCODE == SQLNOTFOUND)
	{
		strcpy(str_ins_30," ");
	}
	else
	{
		strcpy(iins_type30_301,trim(iins_type30_301));
		/*�P�_��O���O30�I���٬O301�I��*/
		if( strcmp(iins_type30_301,"30") == 0 )
		{
			flag30_301 = 30;
		}
		else if( strcmp(iins_type30_301,"301") == 0 )
		{
			flag30_301 = 301;
		}
		else if( strcmp(iins_type30_301,"302") == 0 )
		{
			flag30_301 = 302;
		}
        else
        {
            flag30_301 = 530;
        }
		/*�T�{���[�O24*/    
		$SELECT iins_type
		   INTO $iins_type24
		   FROM ply_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type = '24';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��24�I��*/
		{
			flag24=0;
		}
		else
		{
			flag24=1;
		}	
		/*�T�{���[�O55*/
		$SELECT iins_type
		   INTO $iins_type55
		   FROM ply_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type = '55';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
		{
			flag55=0;
		}
		else
		{
			flag55=1;
		}
		/*�T�{���[�O255*/
		$SELECT iins_type
		   INTO $iins_type55
		   FROM ply_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type = '255';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
		{
			flag255=0;
		}
		else
		{
			flag255=1;
		}
		/*�T�{���[�O49 or 177*/
		$SELECT iins_type
		   FROM ply_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type IN ('49','117');
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��49 or 117�I��*/
		{
			flag49117=0;
		}
		else
		{
			flag49117=1;
		}
        /*�T�{���[�O55*/
		$SELECT iins_type
           INTO $iins_type55
           FROM ply_ins_type
          WHERE ipolicy = $Est.ipolicy2
            AND iins_type = '555';
        if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
        {
            flag555=0;
        }
        else
        {
            flag555=1;
        }
		strcpy(tmp_deduct_30,itoa(deduct_30));
		if( (flag30_301 == 302) && (flag55 == 1) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d��]�t:������˳d�����[���ڡC");
            }
            else
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d�򤣥]�t:������˳d�����[���ڡC");
            }
		}
		else if( (flag30_301 == 302) && (flag255 == 1) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d��]�t:������˳d���I�C");
            }
            else
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d�򤣥]�t:������˳d���I�C");
            }
		}
		
		if( (flag30_301 == 301) && (flag55 == 1) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d���I���[����-��D���W���ӫO�d��]�t:������˳d�����[���ڡC");
            }
            else
            {
            	strcpy(str_ins_30,"�W�B�d���I���[����-��D���W���ӫO�d�򤣥]�t:������˳d�����[���ڡC");
            }	
		}
		else if( (flag30_301 == 301) && (flag255 == 1) )
		{
            strcpy(str_ins_30,"�W�B�d���I���[����-��D���W���ӫO�d�򤣥]�t:������˳d���I�C");
		}
		
		/* 1080311008_SC4_�ͮĤ��71�_����s�v�I */
		if( (flag30_301 == 30) && (flag24 == 1) && (flag55 == 1) && (strncmp(fchk_24,"Y",1)==0))
		{
			if ((IsFcomp24(tmp_deduct_30)) && (IsFcomp55(tmp_deduct_30)))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:�ĤT�H�d�����s���v�T�έ�����˳d�����[���ڡC");
            }
			else if (IsFcomp24(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:�ĤT�H�d�����s���v�T���[���ڤ��]�t������˳d�����[���ڡC");
            }
			else if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:������˳d�����[���ڤ��]�t�ĤT�H�d�����s���v�T���[���ڡC");
            }
			else
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:�ĤT�H�d�����s���v�T�έ�����˳d�����[���ڡC");
            }
		}
		else if( (flag30_301 == 30) && (flag24 == 1) && (strncmp(fchk_24,"Y",1)==0))
		{
			if (IsFcomp24(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:�ĤT�H�d�����s���v�T���[���ڡC");
            }
			else
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:�ĤT�H�d�����s���v�T���[���ڡC");
            }		
		}
	    else if( (flag30_301 == 30) && ((flag55 == 1)||(flag49117 == 1)) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:������˳d�����[���ڡC");
            }
			else
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:������˳d�����[���ڡC");
            }		
		}
		else if( (flag30_301 == 30) && ((flag255 == 1)||(flag49117 == 1)) )
		{
	     	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:������˳d���I�C");	
		}

        if((flag30_301 == 530) && (flag555 == 1))
        {
            if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�r�V�Z�W�B�d���I�ӫO�d��]�t�G�r�V�Z������˳d���I�C");
            }
            else
            {
            	strcpy(str_ins_30,"�r�V�Z�W�B�d���I�ӫO�d�򤣥]�t�G�r�V�Z������˳d���I�C");
            }
        }
	}

printf("30�I�ةӫO�d�򻡩����eEND\n");
      /******************* 30�I�ةӫO�d�򻡩����e(END) *********************/

      /* 1120316006_SC5_�L��-���N�I���e�{�s�W���@�������������O�N��05�ή��s�X��t�ηs�W���@�����O */
      flag_ambulance55 = 0;
      $SELECT iins_type
		 INTO $iins_type55
		 FROM ply_ins_type
	    WHERE ipolicy = $Est.ipolicy2
		  AND iins_type = '55';
      if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
      {
          flag_ambulance55=0;
      }
      else
      {
          flag_ambulance55=1;
      }
      
      if (flag_ambulance55 > 0 && strncmp(Est.icar_type2,"11",2) == 0 && equip_cmp(Est.nequipment,"115") == true && f20230601[0] == 'Y')
      {
      	 if (str_ins_30[0] == '' || str_ins_30[0] == '\0' ) strcat(str_ins_30," ");
      	 strcat(str_ins_30,"�����I�ӫO�d�򤣧t�˱w");
      }
      else 
      {
          
      }
      	        
      	    if (ProtectData == 1)
      	    {
      	    	if (strlen(trim(Est.iassured)) != 0)
		{
	      	    	strcpy(iassured_pt, Est.iassured);
			strcpy(Est.iassured,substring(iassured_pt,1,4));
			strcat(Est.iassured,"****");
			strcat(Est.iassured,substring(iassured_pt,9,4));
		}
		
		if (strlen(trim(Est.iapplicant)) != 0)
		{
			strcpy(iapplicant_pt, Est.iapplicant);
			strcpy(Est.iapplicant,substring(iapplicant_pt,1,4));
			strcat(Est.iapplicant,"****");
			strcat(Est.iapplicant,substring(iapplicant_pt,9,4));
		}
		
		if (strlen(trim(Est.itel)) != 0)
		{
			strcpy(itel_pt, Est.itel);
			strcpy(Est.itel,substring(itel_pt,1,3));
			strcat(Est.itel,"XXXX");
			strcat(Est.itel,substring(itel_pt,8,13));
		}
		
		if (strlen(trim(Est.itel_night)) != 0)
		{
			strcpy(itel_night_pt, Est.itel_night);
			strcpy(Est.itel_night,substring(itel_night_pt,1,3));
			strcat(Est.itel_night,"XXXX");
			strcat(Est.itel_night,substring(itel_night_pt,8,13));
		}
		
		if (strlen(trim(Est.itel_appl)) != 0)
		{
			strcpy(itel_appl_pt, Est.itel_appl);
			strcpy(Est.itel_appl,substring(itel_appl_pt,1,3));
			strcat(Est.itel_appl,"XXXX");
			strcat(Est.itel_appl,substring(itel_appl_pt,8,13));
		}
		
		if (strlen(trim(Est.mobil_phone)) != 0)
		{
			strcpy(mobil_phone_pt, Est.mobil_phone);
			strcpy(Est.mobil_phone,substring(mobil_phone_pt,1,3));
			strcat(Est.mobil_phone,"XXXX");
			strcat(Est.mobil_phone,substring(mobil_phone_pt,8,13));
		}
		
		if (strlen(trim(Est.itag)) != 0)
		{
			strcpy(itag_pt, Est.itag);
			if(strcmp(Est.icar_type1,"27") == 0 || strcmp(Est.icar_type2,"27") == 0)
			{
				strcpy(Est.itag,"****");
				strcat(Est.itag,substring(itag_pt,5,CA_TAG_NUM-5));
			}
			else
			{
				strcpy(Est.itag,"***");
				strcat(Est.itag,substring(itag_pt,4,CA_TAG_NUM-4));
		        }
		}
      	    }
      	    
      /* �j+�� -> ���N�g��H;���  -> ���N�g��H;��j  -> ���N�g��H */
      strcpy(Est.iofficer2,trim(Est.iofficer2));
      if (strlen(Est.iofficer2) == 0)
      {
      	$SELECT nname
      	   INTO $Nname
      	   FROM officer
      	  WHERE iofficer = $Est.iofficer1;
      }
      
      /*1050601008_C2_�s�Wka�q����O��۰ʥN�X�~�ȭ��n���r��*/
	/* ���n���Ҧr��_KA */
	sprintf_s(stmt_iregno, sizeof stmt_iregno, " SELECT ilicence \
			  FROM cm_salesman_log \
			 WHERE ileader = ? and icomm_obj = ileader ");
	$PREPARE prep_iregno_KA_302 FROM $stmt_iregno;
	printf("stmt_iregno[%s]\n",stmt_iregno);
        strcpy(Nreg_no2," ");
        printf("prep_iregno_KA_302 \n");
        if (strncmp(Est.iroute,"KA",2) == 0 && Est.ilast_ply[0] != 0)
        {
		/* �O��q���N����KA*��, �n�]�n�^���n���Ҧr�� */
		$EXECUTE prep_iregno_KA_302 into $Nreg_no using $sIleader;
        	if (SQLCODE == SQLNOTFOUND) strcpy(Nreg_no," "); 
        	strcpy(Nreg_no2,trim(Nreg_no));
        	strcat(Nreg_no2," ");
        	strcat(Nreg_no2,nleader);	
        }
        else
        	strcpy(Nreg_no2," ");
        	
        	
		/*�����I¾�~*/
	      sprintf_s(stmt_occup1, sizeof stmt_occup1, "SELECT (trim(imember)||' '||trim(nmember)) FROM cm_risk_member WHERE itype = 'P' AND fmember = 'P' AND imember = '%s' ",Est.noccup);
	      $PREPARE prep_occup_est1 FROM $stmt_occup1;
	      $EXECUTE prep_occup_est1 into $noccup_fullname;
	      if (SQLCODE == SQLNOTFOUND) strcpy(noccup_fullname," "); 
	      
	      sprintf_s(stmt_occup2, sizeof stmt_occup2, "SELECT (trim(imember)||' '||trim(nmember)) FROM cm_risk_member WHERE itype = 'P' AND fmember = 'P' AND imember = '%s' ",Est.applicant_noccup);
	      $PREPARE prep_occup_est2 FROM $stmt_occup2;
	      $EXECUTE prep_occup_est2 into $applicant_noccup_fullname;
	      if (SQLCODE == SQLNOTFOUND) strcpy(applicant_noccup_fullname," "); 
	      
	      
      /******���[���ڤ�r����(BEGIN)******/
      
      strcpy(iprov_all," ");
      strcpy(sprov_all," ");
      strcpy(iprov," ");
      strcpy(iins_prov," ");
      strcpy(sprov," ");
      strcpy(sprov_note," ");
      strcpy(sprov_note_all," ");    

      sprintf_s(stmt7, sizeof stmt7, "SELECT trim(nvl(provision,' '))||';',iins_type FROM ply_ins_type_302 WHERE ipolicy = '%s' " , Est.ipolicy2);
      	               
      $PREPARE  preProvision11 FROM $stmt7;
      $DECLARE  cur_provision11 CURSOR FOR preProvision11;
      $OPEN     cur_provision11;

      for(;;)
      {
            $FETCH cur_provision11 INTO $iprov,$iins_prov;
            if(SQLCODE == SQLNOTFOUND)  break;

            if (strstr(trim(iprov),"P;") != NULL)
            {
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'P;','')
		       INTO $iprov
		       FROM systables;
		       	
        	
            }
            else if (strstr(trim(iprov),"Q;") != NULL)
            {
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'Q;','')
		       INTO $iprov
		       FROM systables;	
            }
            else if (strstr(trim(iprov),"M;") != NULL)
            {
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) && 
                    (strcmp(trim(iins_prov),"181")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'M;','')
		       INTO $iprov
		       FROM systables;		
            }  
            else if (strstr(trim(iprov),"Y;") != NULL)
            {
            	/* 1130827011_C04_�s�W�s�t��W�B���[����(Y)(�L��) */
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) && 
                    (strcmp(trim(iins_prov),"198")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'Y;','')
		       INTO $iprov
		       FROM systables;		
            }        

            strcat(iprov_all, iprov);

      }
      $CLOSE  cur_provision11;
      $FREE   cur_provision11;
      printf("�����[����:iprov_all[%s]\n",trim(iprov_all));
      strcpy(iprov_all,trim(iprov_all));
      
      if (strcmp(iprov_all,";")!=0 && strcmp(iprov_all,"")!=0)
      {
          ptr1 = strtok(iprov_all,";");
	  while(ptr1 != NULL)
	  {
      	      sprintf_s(sprov, sizeof sprov,"'%s',",ptr1);  
      	      strcat(sprov_all,sprov);	  				
	      ptr1 = strtok(NULL, ";");
	  }
				
          strcat(sprov_all,"''");
          printf("�����[����:sprov_all[%s]\n",trim(sprov_all));
      	
      	  sprintf_s(stmt8, sizeof stmt8, "SELECT trim(nprint)||'�B' FROM ca_provision_main WHERE iprovision NOT IN ('C','E','S') AND iprovision IN (%s)" , trim(sprov_all));
          $PREPARE  preProvision12 FROM $stmt8;
          $DECLARE  cur_provision12 CURSOR FOR preProvision12;
          $OPEN     cur_provision12;   
          
          for(;;)
          {
              $FETCH cur_provision12 INTO $sprov_note;
              if(SQLCODE == SQLNOTFOUND)  break;

              strcat(sprov_note_all, trim(sprov_note));

          }
          $CLOSE  cur_provision12;
          $FREE   cur_provision12;   
          printf("�����[���ڤ���:sprov_note_all[%s]\n",trim(sprov_note_all));	  
      	  strcpy(sprov_note_all,trim(sprov_note_all));
      }


      /******���[���ڤ�r����(END)******/

            /* �g�J��r��,�`�N��춶�Ƕ��Pclient�ݤ@�P ----------------------------- */
            fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
                   Est.iestimate,sIestimate_c,Est.icard2,Est.icard1,Est.irelative_ply);
            fprintf(fp0,"%s\t%s\t%s\t%s\t",
                      Est.ilast_ply,Est.ilast_card,Est.irelative_card,Est.ixxcard);
            fprintf(fp0,"%s\t%s\t%s\t%s\t",
                      Est.dply2_begin,Est.dply2_end,Est.dply1_begin,Est.dply1_end);
            fprintf(fp0,"%s\t%s\t%s\t%s\t",
                      Est.fassured,Est.iassured,Est.iassured_ext,Est.nassured);
            fprintf(fp0,"%s\t%s\t%s\t%s\t",
                     Est.ilicense,Est.dbirth,Est.fsex,Est.fmarriage);
            fprintf(fp0,"%s\t%s\t%s\t%s\t",
                     Est.nuser,Est.ibenef,Est.nbenef,Est.aassured);
            fprintf(fp0,"%s\t%s\t%s\t%s\t",
                     Est.aassured_zip,Est.itel,Est.itel_night,Est.mobil_phone);
            fprintf(fp0,"%s\t%s\t%s\t%s\t",
                     Est.apayment,Est.apayment_zip,Est.iply_area,Est.dissue);
            fprintf(fp0,"%s\t%s\t%s\t%s\t",
                     Est.ipro_year,Est.ibrand,Est.nbrand_abbr,Est.icar_type2);
            fprintf(fp0,"%s\t%s\t%s\t%.2f\t",
                     Est.icar_type1,Est.ncar_abbr,Est.fcar_note2,Est.qcylinder);
            fprintf(fp0,"%s\t%s\t%s\t%.1f\t",
                     Est.iengine,Est.ibody,Est.itag,Est.mcar_price);
            fprintf(fp0,"%d\t%d\t%d\t%d\t",
                     Est.pdmg_align,Est.pbrg_align,Est.plia_align,Est.mpremium2);
            fprintf(fp0,"%d\t%s\t%s\t%s\t%d\t",
                     Est.mpremium1,Est.ibig_comp,Est.ibig_branch,Est.ibig_office,0);
            fprintf(fp0,"%s\t%s\t%s\t%s\t",
                     Est.ibig_sales,Est.iresource,Est.fdiscount,Est.ibroker2);
            fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
                     Est.ibroker1,Est.iofficer2,Est.iofficer1,Est.icorps,Nreg_no2);
            fprintf(fp0,"%s\t%s\t%s\t%s\t",
                     Est.iarea,Est.icashier,Est.iexaminer,Est.dexamine);
            fprintf(fp0,"%s\t%s\t%s\t%s\t",
                     Nquota,Est.dentry,Est.dapply,Est.fcal_way);
            fprintf(fp0,"%s\t%s\t%s\t%.4f\t",
                     sTmpx,sTmpx ,Est.idmg_rate,Est.pdmg_factor);
            fprintf(fp0,"%s\t%.4f\t%s\t%.1f\t",
                     Est.ibrg_rate,Est.pbrg_factor,Est.ibranch,Est.qpt);
            fprintf(fp0,"%s\t%f\t%f\t%f\t",
                     Est.fpt,Est.psex_age2,Est.psex_age1,Est.psex_age_damage);
            fprintf(fp0,"%s\t%.2f\t%.2f\t%d\t",
                      Est.lia_class,Est.plia_acc2,Est.plia_acc1,Est.dmg_acc_1st);
            fprintf(fp0,"%d\t%d\t%.2f\t%s\t",
                    Est.dmg_acc_2nd,Est.dmg_acc_3rd,Est.pdmg_acc,Est.fhuman);
            fprintf(fp0,"%s\t%f\t%f\t%s\t",
                      Est.fcomp_24,Est.mbus_rule,Est.mbusiness,Est.fcomp_class);
            fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
                      Est.fcomp_class_last,Est.iemail,Est.iquery_num_c,
                      Est.iquery_num ,Est.iquery_num_damage);
            fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t%f\t%s\t",
                      Fcar_class,Ncode,Nname,Nchi_abv,
                     Est.napplicant,Est.mequipment,Est.iroute);
            fprintf(fp0,"%s\t%s\t%d\t%d\t",
                      Est.iroute_prop, Est.iroute_comm2, Est.qlia_acc_sum,
                      Est.qdmg_acc_sum );
            fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%d\t%s\t%d\t%s\t%s\t%s\t%s\t%d\t",
                      Est.ndeputy_assured, Est.ndeputy_appl, Est.nrelation_appl, Est.fsex_appl,
                      sFapplicant, Est.iapplicant, Est.dbirth_appl, Est.itel_appl, Est.qdrunk_driving,
                      sBarcode_type, Est.fuw_status, Est.iaccept, equip97, " ", "0",0);		/*��O�ɤ��|�����ը���ơA�ҥH���B��0*/
            fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
      		      sIassured_cntry, sIapplicant_cntry,nleader,str_ins_30, " ");	/* �Q�O�I�H�B�n�O�H��O���O */

            if (strcmp(Fcard_class,"1") == 0)
                fprintf(fp0,"%s\t%s\t",LastOff1,LastOff1);   /* �e�欰�j���I */
            else
                fprintf(fp0,"%s\t%s\t",LastOff2,LastOff1);   /* �e�欰���N�I */
                
            fprintf(fp0,"%s\t%s\t%s\t%.2f\t%s\t",
      		        feply,fecard, aemail_eply,punknown_acc,iquery_num_unknown);
      	    fprintf(fp0,"%s\t%s\t%s\t%s\t",
      		      Est.foccup, noccup_fullname,Est.applicant_foccup,applicant_noccup_fullname);   
      		      
      	    fprintf(fp0,"%f\t%f\t%s\t%s\t%s\t%s\t",Est.nmile_ubi, Est.pubi_acc, Est.tmobile_eply,sprov_note_all, tmobile_appl, aemail_appl);
      		
      	    fprintf(fp0,"%s\t%s\t%s\t%d\t", iLastRelative_ply1, iLastRelative_ply2, feterms, qviolate);
      	    
      	    fprintf(fp0,"%s\t%s\t%s\t%s\n"," "," "," "," "); /* 1120927002_C12_�R�q�ΰӫ~�}�o(�L��)�A�ȸպ⦳ */


            /* �I�ة����� */
            if (strlen(Est.iestimate) > 5 )
                rc1 = select_ply_ins_302_1(Est.ipolicy1, Est.ipolicy2, Est.iestimate, Est.icar_type2, sIsys, DBName);
            else
                rc1 = select_ply_ins_302_1(Est.ipolicy1, Est.ipolicy2, sIestimate_c, Est.icar_type2, sIsys, DBName);

            if (rc1 != SUCCESS)
                break;
        }
        $close curR2;
        $free curR2;
    }
    $close curRA1;
    $free curRA1;

    fclose(fp0);
    fclose(fp1);
    fclose(fp4);

    icount2 = 0;
printf("-----2967---icount1[%d]\n",icount1);


    if (rc1 != SUCCESS)
       return rc1;

    if ((icount1+icount2) == 0)
    {
        if(exitsub(reply,M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
        else
            return apiRC;
    }

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    cm_buf_put("%s %s",sTmp0,sTmp1);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
    else
         return api_OKComplete;

errexit:
   printf(" select_ply302_data = [%d]\n ",SQLCODE);
   fclose(fp0);
   fclose(fp1);
   fclose(fp4);
   sqlfatal();
   return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
} /* end of select_ply302_data */

/* -------------------------------------------------------------------------- */
long select_ply_ins_302_1(fipolicy1, fipolicy2, fiestimate, ficar_type, fsys, fdbname)
char *fipolicy1, *fipolicy2, *fiestimate, *ficar_type, *fsys, *fdbname;
{
    $char	DBName[5],iest1[21],iest2[21],icar_type[3],sIestimatex[21];
    $char	stmt[8192],stmt1[2048],stmt2[2048],stmt3[1024];
    $struct	est_ins_type   *EstIns;
    int	i=0, rc=0;
    int	tmp_len=0;
    char FullGetName[101], filename[31];
    char sTmp0[71], sTmp1[71], sTmp2[71], file0[71], file1[71];
    char rptstr_main[10000], rptstr_dtl[10000];
    char sApHome[31],sIsys[2];

    printf("------- select_ply_ins_302_1 strat ------------------------------ \n");
    $WHENEVER SQLERROR GOTO errexit;
    strcpy(DBName, fdbname);

    if (db_select(DBName) == False)
         return M_CM_DB_NOTOPEN;

    memset(&EstIns,0, sizeof(EstIns));
    EstIns=(struct est_ins_type *)malloc(sizeof(struct est_ins_type));

    strcpy(iest1, fipolicy1);
    strcpy(iest2, fipolicy2);
    strcpy(sIestimatex, trim(fiestimate));
    strcpy(icar_type, ficar_type);
    strcpy(sIsys, fsys); /* 4:���O�զX 5:��ĳ��O�զX */

    printf(" ------ iest1=[%s] iest2=[%s] icar_type=[%s]sIsys=[%s]\n",iest1, iest2, icar_type,sIsys);
    if (strcmp(sIsys,"4") == 0)
    {
        strcpy(stmt2,
            " case when a.iins_type in ('56','136','166','266') then (select max(ori_daily_pay) "
            "      from ca_pa_ply_302 d where a.ipolicy = d.ipolicy "
            "       and a.iins_type = d.iins_type) else 0 end as daily_pay, "
            " case when a.iins_type in ('56','136','166','35','266') then (select distinct iins_scope "
            "      from ca_pa_ply_302 f where a.ipolicy = f.ipolicy "
            "       and a.iins_type = f.iins_type) else '0' end as iins_scope, "
            " (select count(*) from insurance_cover e "
            "   where a.iins_type = e.iins_type) as insurance_cover, a.ipolicy, ' ' ");
        strcpy(stmt3,
            " from ply_ins_type_302 a, outer insurance_type b "
            "where (ipolicy = ? or ipolicy = ?) "
            "  and a.iins_type = b.iins_type and a.ori_dam_cover > 0 "
            "order by qserial ");
        strcpy(stmt1,
            "select a.iins_type,a.ori_inj_cover,a.ori_dea_cover,a.ori_dam_cover, "
            "       a.ori_deduct,a.ori_premium,0,a.qserial, "
            "       0.0,0,0.0,0, "
            "       0.0,a.mdiscount,a.drate_ym,a.ori_premium, "
            "       ' ',a.qday,a.mexpense,a.mexp_disc, "
            "       a.provision, 0, 0.0,a.ori_premium, "
            "       0,a.ori_premium,0.0,0.0, "
            "       0.0,0.0,b.nins_type, "
            "       case when a.iins_type in ('01','05','08','09','120','122','125','126','131','132','201','205','209','331','332') then "
            "            (select prn_deduct from ca_dmg_mdeduct c "
            "              where c.icar_type = ? and c.ideduct = a.mdeduct) "
            "            when b.fdeduct = '0' then '�L' "
            "       else a.mdeduct::varchar(20) end as prn_deduct, "
            "       b.qcoverage, b.cover_print, b.fdeduct, b.deduct_print, ");
    }
    else
    {
        strcpy(stmt2,
            " case when a.iins_type in ('56','136','166','266') then (select max(daily_pay) "
            "      from ca_pa_ply_302 d where a.ipolicy = d.ipolicy "
            "       and a.iins_type = d.iins_type) else 0 end as daily_pay, "
            " case when a.iins_type in ('56','136','166','35','266') then (select distinct iins_scope "
            "      from ca_pa_ply_302 f where a.ipolicy = f.ipolicy "
            "       and a.iins_type = f.iins_type) else '0' end as iins_scope, "
            " (select count(*) from insurance_cover e "
            "   where a.iins_type = e.iins_type) as insurance_cover, a.ipolicy, ' ' ");
        strcpy(stmt3,
            " from ply_ins_type_302 a, outer insurance_type b "
            "where (ipolicy = ? or ipolicy = ?) "
            "  and a.iins_type = b.iins_type and a.mdamage_cover > 0 "
            "order by a.qserial ");
        strcpy(stmt1,
            "select a.iins_type,a.minjured_cover,a.mdeath_cover,a.mdamage_cover, "
            "       a.mdeduct,a.mins_premium,0,a.qserial, "
            "       0.0,0,0.0,0, "
            "       0.0,a.mdiscount,a.drate_ym,a.mins_premium, "
            "       ' ',a.qday,a.mexpense,a.mexp_disc, "
            "       a.provision, 0, 0.0,a.mins_premium, "
            "       0,a.mins_premium,0.0,0.0, "
            "       0.0,0.0,b.nins_type, "
            "       case when a.iins_type in ('01','05','08','09','120','122','125','126','131','132','201','205','209','331','332') then "
            "            (select prn_deduct from ca_dmg_mdeduct c "
            "              where c.icar_type = ? and c.ideduct = a.mdeduct) "
            "            when b.fdeduct = '0' then '�L' "
            "       else a.mdeduct::varchar(20) end as prn_deduct, "
            "       b.qcoverage, b.cover_print, b.fdeduct, b.deduct_print, ");
    }

    strcpy(stmt,rtrim(stmt1));
    strcat(stmt,rtrim(stmt2));
    strcat(stmt,rtrim(stmt3));

    printf("2:stmt=[%s]\n",stmt);

    $prepare pre_stmt from $stmt;
    $declare cur_insR1 cursor for pre_stmt;
    $open    cur_insR1 using $icar_type,$iest1,$iest2;

    /* �g�J��r��,�`�N��춶�Ƕ��Pclient�ݤ@�P ----------------------------- */
    for(i=0;;i++)
    {
        $fetch cur_insR1 into
            $EstIns->iins_type,$EstIns->minjured_cover,
            $EstIns->mdeath_cover,$EstIns->mdamage_cover,
            $EstIns->mdeduct,$EstIns->mins_premium,
            $EstIns->mpure_prem, $EstIns->qserial,
            $EstIns->pcommission,$EstIns->mcommission,
            $EstIns->pagent,$EstIns->magent,$EstIns->pdiscount,
            $EstIns->mdiscount,$EstIns->drate_ym,$EstIns->mprem,
            $EstIns->iproduct,$EstIns->qday,$EstIns->mexpense,
            $EstIns->mexp_disc,$EstIns->provision,$EstIns->irate,
            $EstIns->adjust_rate,$EstIns->mins_premium_n,
            $EstIns->mpure_prem_n,$EstIns->mprem_n,
            $EstIns->safe_rate,
            $EstIns->manage_rate,$EstIns->educated_rate,
            $EstIns->deviation_rate,$EstIns->Nins_type,
            $EstIns->Prn_deduct, $EstIns->qcoverage, $EstIns->cover_print,
            $EstIns->fdeduct, $EstIns->deduct_print, $EstIns->Daily_pay,$EstIns->Iins_scope,
            $EstIns->Ins_cover, $EstIns->iestimate, $EstIns->fproject;
        if (NOT_FOUND) break;

        printf("EstIns->iins_type=[%s]\n",EstIns->iins_type);

   	    fprintf(fp1,"%s\t%d\t%d\t%d\t",
                    EstIns->iins_type,EstIns->minjured_cover,
   	                EstIns->mdeath_cover,EstIns->mdamage_cover);

        fprintf(fp1,"%d\t%d\t%f\t%d\t%f\t%d\t",
   	                EstIns->mdeduct,EstIns->mins_premium,EstIns->mpure_prem,
   	                EstIns->qserial,EstIns->pcommission,EstIns->mcommission);

        fprintf(fp1,"%f\t%d\t%f\t%d\t%s\t%d\t",
   	                EstIns->pagent,EstIns->magent,EstIns->pdiscount,
   	                EstIns->mdiscount,EstIns->drate_ym,EstIns->mprem);

        fprintf(fp1,"%s\t%d\t%d\t%d\t%s\t%d\t",
   	                EstIns->iproduct,EstIns->qday,EstIns->mexpense,
   	                EstIns->mexp_disc,EstIns->provision,EstIns->irate);

        fprintf(fp1,"%f\t%d\t%d\t%d\t%f\t",
   	                EstIns->adjust_rate,EstIns->mins_premium_n,
   	                EstIns->mpure_prem_n,EstIns->mprem_n,EstIns->safe_rate);

        if (strlen(trim(iest2)) > 0 )
	    {
	  	    fprintf(fp1,"%f\t%f\t%f\t%s\t%s\t%d\t%s\t%d\t%s\t%s\n",
   	                    EstIns->manage_rate,EstIns->educated_rate,
   	                    EstIns->deviation_rate,EstIns->Nins_type,
   	                    EstIns->Prn_deduct,EstIns->Daily_pay,EstIns->Iins_scope,
   	                    EstIns->Ins_cover,sIestimatex,EstIns->fproject);
   	    }
        else
	  	{
   		    fprintf(fp1,"%f\t%f\t%f\t%s\t%s\t%d\t%s\t%d\t%s\t%s\n",
   	                    EstIns->manage_rate,EstIns->educated_rate,
   	                    EstIns->deviation_rate,EstIns->Nins_type,
   	                    EstIns->Prn_deduct,EstIns->Daily_pay,EstIns->Iins_scope,
   	                    EstIns->Ins_cover,sIestimatex,EstIns->fproject);
        }
   	    printf("EstIns->iins_type=[%s]\n",EstIns->iins_type);
    }
    $close cur_insR1;
    $free  cur_insR1;

    return SUCCESS;

errexit:
    printf(" select_ply_ins_302_1 = [%d]\n ",SQLCODE);
    sqlfatal();
    return SQLCODE;
} /* end of select_ply_ins_302_1 */

/* ------------------------------------------------------------------------ */
long select_autoply_data(reply)
serverReply reply;
{
   $char	DBName[5],iest_bgn[21],iest_end[21],sTmpProv[2],sNprovD[101],chk_JB[2];
   $char	stmt[8192],stmt1[2048],stmt2[2048],stmt3[1024],stmt4[500],stmt5[1000];
   $char        stmt6[1024],stmt_iregno[1024],Condition[48],stmt7[1024],stmt8[1024],stmt9[1000],stmt9_1[140];
   $char	stmt_last[1024],FullDB[41],stmtc[8192],sFcard_class[2],FullDB2[41];
   $struct	estimate	Est;
   $struct	est_ins_assured	Assured;
   $char    tmobile_appl[21],aemail_appl[51];
   $char	ipolicy_list[21],iins_type_list[7],iinsurant_list[11],ninsurant_list[31],dbirth_list[11],nbeneficiary_list[31],relation_bene_list[2],tbenef_list[21],abenef_list[91];
   $char	Fcar_class[2],Ncode[11],Nname[11],Nchi_abv[13];
   $char	Nquota[11],Fcard_class[2],LastOff1[21],LastOff2[21];
   $char tmp_ply[21], tmp_officer[11], sIestimate_c[21], tmp_iestimate[21];
   $char sIsys[2], sIpolicy[21], sBarcode_type[9];
   int	i=0,rc=0, icount1=0, rc1=0, tmp_len=0, icount2=0;
   int   recLen=1024;
   char FullGetName[101], filename[31];
   char sTmp0[71], sTmp1[71], sTmp2[71],sTmp3[71],sTmp4[71], file0[71], file1[71],file2[71],file3[71],file4[71];
   char rptstr_main[10000], rptstr_dtl[10000];
   char sApHome[31], sGetFileName[101], sFullFileName[201], sTmpTableName[101];
   char *token, *s1;
   time_t now;
   char sUserid[11];
   $int iCount2=0;
   long rtn=0;
   char sMsg[100];
   $char ninsType[19], sNins_type[128];
   $int  sMcover_limit=0;
   $char sIassured_cntry[2], sIapplicant_cntry[2];
   $char sIleader[11];
   $char itmp_policy[21];
   $int  kyc_cnt=0,count_50=0;
   $char sFapplicant[2];
   $char stmt_occup1[1024],stmt_occup2[1024],noccup_fullname[126],applicant_noccup_fullname[126];
   $char iprov_all[200],iprov[10],sprov[5],sprov_all[500],sprov_note[50],sprov_note_all[500],iins_prov[7];
   $char fchk_24[2];
   $char iLastRelative_ply1[21],iLastRelative_ply2[21];
   $char *ptr1;
   $int  qviolate = 0;
   $char f20230601[2];
   
   strcpy(fchk_24," ");
   strcpy(f20230601," ");

   kyc_cnt = 0;
   
   printf("------- select_autoply_data strat ------------------------------ \n");

   cm_buf_get("%s %s %s %s %s %s",DBName, iest_bgn, iest_end, sGetFileName, sUserid, chk_JB);

   printf("DBName=[%s],iest_bgn=[%s], iest_end=[%s], sGetFileName=[%s] \n",DBName,iest_bgn, iest_end, sGetFileName);
   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
   {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
         return M_CM_DB_NOTOPEN;
      else
         return apiRC;
   }


   if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(sUserid, M_CM_NOT_DBLIST) == TRUE)
         return M_CM_NOT_DBLIST;
   }

   rc = getApHome(sApHome);
   if (rc < 0)
   {
      printf("read Config file error!!\n");
      return exitsub(reply,M_CM_READ_CONFIG_ERR) ? M_CM_READ_CONFIG_ERR : apiRC;
   }
   printf("sGetFileName=[%s]\n",sGetFileName);

   if(strcmp(trim(sGetFileName),"1") == 0)		/* �C�L�鬰�t�Τ�A����̷s�O���ơC */
   {
   	strcpy(tableRelation,"ply_relation");
   	strcpy(tablePly,"policy");
   	strcpy(tableInsType,"ply_ins_type");
   	strcpy(tablePaPly,"ca_pa_ply");
   	strcpy(tableAssured,"ply_ins_assured");
   }
   else
   {
   	strcpy(tableRelation,"ori_ply_relation");
   	strcpy(tablePly,"original_ply");
   	strcpy(tableInsType,"ori_ins_type");
   	strcpy(tablePaPly,"ca_pa_ori");
   	strcpy(tableAssured,"ori_ins_assured");
   }
   
   if (Check_EB == 0)
   	strcpy(stmt4,"and a.icar_type != '51' ");
   else
   	strcpy(stmt4,"and a.icar_type = '51' ");
   	
   if (strcmp(trim(chk_JB),"1") == 0)
   {
   	strcpy(Condition, "AND b.iroute matches 'JB*' ");
   }
   else
   {
   	strcpy(Condition, "AND b.iroute NOT matches 'JB*' ");
   }

   /* �إ�tmp table */
   $select ipolicy
      from ply_relation where 1=0 into temp tmp_policy with no log;
   
   /* 1060928006_C1 */   /*1060817004-C1 �q�lñ�p �ˬdcm_esign_data.iunder*/
   sprintf_s(stmt, sizeof stmt,"insert into tmp_policy \
                 select a.ipolicy \
                   from %s a,%s b \
                  where a.ipolicy = b.ipolicy \
                    and a.dentry = '%s'      \
	            and a.ibranch_in = '%s'  \
	            %s %s                    \
	            and (b.nequipment[12] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.') \
	             or (a.itmp_policy like '17N%%' and a.isign = 'system') \
	             or (a.iofficer = 'Z32018N' and b.iroute = 'JZ' and b.nequipment[12] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.'))) \
	            and (a.fcard_class = '2' or (a.fcard_class = '1' and (a.irelative_ply is null or a.irelative_ply = ' '))) \
                AND NOT EXISTS (SELECT d.iscan_no FROM cm_esign_data d WHERE trim(d.iunder) <> '' AND d.iscan_no = a.iscan_no) ",tableRelation,tablePly,iest_bgn,iest_end,stmt4,Condition);
              /*AND a.iscan_no not in (select d.iscan_no from cm_esign_data d where trim(d.iunder) <> '')"*/
  printf("stmt=[%s]\n", stmt);
  /*$EXECUTE IMMEDIATE $stmt;*/
  
  $prepare preDD FROM $stmt;
  $execute preDD;

   time(&now);
   sprintf_s(sTmp0, sizeof sTmp0,"application_%s%s%ld.txt",DBName,sUserid,now);
   sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,sTmp0);
   fp0=fopen(file0,"w");

   sprintf_s(sTmp1, sizeof sTmp1,"application_%s%s%ld_dtl.txt",DBName,sUserid,now);
   sprintf_s(file1, sizeof file1,"%s/rptftp/%s",sApHome,sTmp1);
   fp1=fopen(file1,"w");

   sprintf_s(sTmp2, sizeof sTmp2,"application_%s%s%ld_provD.txt",DBName,sUserid,now);
   sprintf_s(file2, sizeof file2,"%s/rptftp/%s",sApHome,sTmp2);
   fp2=fopen(file2,"w");

   sprintf_s(sTmp3, sizeof sTmp3,"application_%s%s%ld_kyc.txt",DBName,sUserid,now);
   sprintf_s(file3, sizeof file3,"%s/rptftp/%s",sApHome,sTmp3);
   fp3=fopen(file3,"w");

   sprintf_s(sTmp4, sizeof sTmp4,"application_%s%s%ld_list.txt",DBName,sUserid,now);
   sprintf_s(file4, sizeof file4,"%s/rptftp/%s",sApHome,sTmp4);
   fp4=fopen(file4,"w");

   icount1 = 0;

	   sprintf_s(stmt, sizeof stmt,
	      "select a.itmp_policy, decode(a.fcard_class,'2',a.icard,' '), \
	              decode(a.fcard_class,'1',a.icard,' '), a.irelative_ply, \
	              a.ilast_ply, a.ilast_card, ' ', b.ixxcard, \
	              decode(a.fcard_class,'2',to_char(a.dply_begin),' '), \
	              decode(a.fcard_class,'2',to_char(a.dply_end),' '), \
	              decode(a.fcard_class,'1',to_char(a.dply_begin),' '), \
	              decode(a.fcard_class,'1',to_char(a.dply_end),' '), \
	              b.fassured, b.iassured, b.iassured_ext, b.nassured, \
	              b.ilicense, b.dbirth, b.fsex, b.fmarriage, \
	              b.nuser, b.ibenef, b.nbenef, b.aassured, \
	              b.aassured_zip, b.itel, ' ', ' ', \
	              b.apayment, b.apayment_zip, b.iply_area, b.dissue, \
	              a.ipro_year||'/'||b.qpro_month::CHAR(2), a.ibrand, b.nbrand_abbr, \
	              decode(a.fcard_class,'2',a.icar_type,' '), \
	              decode(a.fcard_class,'1',a.icar_type,' '), \
	              b.ncar_abbr, b.fcar_note, b.qcylinder, \
	              b.iengine, b.ibody, b.itag, b.mcar_price, \
	              nvl(b.pdmg_align,0), nvl(b.pbrg_align,0), nvl(b.plia_align,0), \
	              decode(a.fcard_class,'2',(a.mdmg_prem + a.mlia_prem),0), \
	              decode(a.fcard_class,'1',(a.mdmg_prem + a.mlia_prem),0), \
	              a.ibig_comp, a.ibig_branch, a.ibig_office, a.qprovision, \
	              a.ibig_sales, a.iresource, a.fdiscount, \
	              decode(a.fcard_class,'2',a.ibroker,' '), \
	              decode(a.fcard_class,'1',a.ibroker,' '), \
	              decode(a.fcard_class,'2',a.iofficer,' '), \
	              decode(a.fcard_class,'1',a.iofficer,' '), a.icorps, \
	              a.iarea, a.icashier, a.iexaminer, a.dexamine, \
	              (select m.nname from officer m where m.iofficer = a.ientry), \
	              ' ', a.dapply, b.fcal_way, \
	              decode(a.fcard_class,'1',a.ipolicy,' '), \
	              decode(a.fcard_class,'2',a.ipolicy,' '), b.idmg_rate, b.pdmg_factor, \
	              b.ibrg_rate, nvl(b.pbrg_factor,0), a.ibranch, b.qpt, \
	              b.fpt, decode(a.fcard_class,'2',to_char(round(b.psex_age,2)),' '), \
	              decode(a.fcard_class,'1',to_char(round(b.psex_age,2)),' '), \
	              NVL((SELECT max(psex_age) FROM %s WHERE ipolicy = a.ipolicy AND iins_type IN (SELECT iins_type FROM insurance_type WHERE fins_grp = '1' AND iins_type = iins_ply AND iri_ins <> '11')),0), \
	              b.lia_class, \
	              decode(a.fcard_class,'2',nvl(b.plia_acc,' '),' '), \
	              decode(a.fcard_class,'1',nvl(b.plia_acc,' '),' '), \
	              b.dmg_acc_1st, b.dmg_acc_2nd, \
	              b.dmg_acc_3rd, nvl(b.pdmg_acc,' '), b.fhuman, b.fcomp_24, \
	              a.mbus_rule, a.mbusiness, a.fcomp_class, a.fcomp_class_last, \
	              b.iemail, decode(a.fcard_class,'1',b.iquery_num,' '), \
	              decode(a.fcard_class,'2',b.iquery_num,' ') ,b.iquery_num_damage, \
	              c.fcar_class, c.ncode, d.nname, nvl(e.nchi_abv,f.nchi_abv), \
	              b.napplicant, b.mequipment, b.iroute, b.iroute_prop, \
	              decode(a.fcard_class,'2',a.iroute_comm,' '), \
	              nvl(b.qlia_acc_sum,0), nvl(b.qdmg_acc_sum,0), \
	              b.ndeputy_assured, b.ndeputy_appl, b.nrelation_appl, b.fsex_appl, \
	              b.fapplicant, b.iapplicant, b.dbirth_appl, b.itel_appl, a.fcard_class, a.qdrunk_driving,  \
	              a.transno, b.nequipment, 500, b.iroute_accept, b.mcover_limit, \
	              b.iassured_cntry, b.iapplicant_cntry ,a.ileader, \
	              b.fequipment1,b.fequipment2,b.fequipment3,b.fequipment4, \
	              b.fequipment5,b.fequipment6,b.fequipment9,b.nequipment9, \
	              CASE WHEN a.fcard_class = '2' THEN a.feply ELSE nvl((SELECT feply FROM ply_relation WHERE ipolicy = a.irelative_ply),'0') END, \
	              CASE WHEN a.fcard_class = '1' THEN a.feply ELSE nvl((SELECT feply FROM ply_relation WHERE ipolicy = a.irelative_ply),'0') END, \
              	  case WHEN a.fcard_class = '2' THEN (CASE WHEN trim(a.aemail_eply) <>'' THEN a.aemail_eply ELSE nvl((SELECT trim(aemail_eply) FROM ply_relation WHERE ipolicy=a.irelative_ply),'') END ) \
                  else (CASE nvl((SELECT trim(aemail_eply) FROM ply_relation WHERE ipolicy=a.irelative_ply),'') WHEN '' THEN (case trim(a.aemail_eply) when '' then '' else trim(a.aemail_eply) end  ) else (SELECT trim(aemail_eply) FROM ply_relation WHERE ipolicy=a.irelative_ply) END) END, \
              	  b.punknown_acc, b.iquery_num_unknown, \
              	  b.foccup,b.noccup,b.applicant_foccup,b.applicant_noccup, \
              	  b.nmile_ubi,b.pubi_acc,  \
              	  case when a.dply_begin < '07/01/2019' then 'Y' else 'N' end, \
                  case WHEN a.fcard_class = '2' THEN (CASE WHEN trim(a.tmobile_eply) <>'' THEN a.tmobile_eply ELSE nvl((SELECT trim(tmobile_eply) FROM ply_relation WHERE ipolicy=a.irelative_ply),'') END ) \
                  else (CASE nvl((SELECT trim(tmobile_eply) FROM ply_relation WHERE ipolicy=a.irelative_ply),'') WHEN '' THEN (case trim(a.tmobile_eply) when '' then '' else trim(a.tmobile_eply) end  ) else (SELECT trim(tmobile_eply) FROM ply_relation WHERE ipolicy=a.irelative_ply) END) END, \
              	  b.tmobile_appl,b.aemail_appl,CASE WHEN a.fcard_class = '2' THEN a.feterms ELSE nvl((SELECT feterms FROM ply_relation WHERE ipolicy = a.irelative_ply),'0') END, \
              	  a.qviolate,case when a.dply_begin >= '06/01/2023' then 'Y' else 'N' end \
	         from %s a, %s b, outer car_type c, \
	              outer officer d, outer broker_agent e, outer broker_agent f \
	        where a.ipolicy = b.ipolicy \
	          and a.ipolicy in (select upper(ipolicy) from tmp_policy) \
	          and a.icar_type = c.icode  \
	          and c.fclass = '1' \
	          and a.iofficer = d.iofficer \
	          and a.icomm_obj = e.ibroker \
	          and a.ibroker = f.ibroker ",tableInsType,tableRelation,tablePly);

	   printf("stmt=[%s]\n", stmt);

	   $PREPARE  perD2 FROM $stmt;
	   $DECLARE  curD2 CURSOR FOR perD2;
	   $OPEN     curD2;
	   while(1)
	   {
	      $FETCH curD2 INTO
	            $Est.iestimate,$Est.icard2,$Est.icard1,$Est.irelative_ply,
	            $Est.ilast_ply,$Est.ilast_card,$Est.irelative_card,$Est.ixxcard,
	            $Est.dply2_begin,$Est.dply2_end,$Est.dply1_begin,$Est.dply1_end,
	            $Est.fassured,$Est.iassured,$Est.iassured_ext,$Est.nassured,
	            $Est.ilicense,$Est.dbirth,$Est.fsex,$Est.fmarriage,
	            $Est.nuser,$Est.ibenef,$Est.nbenef,$Est.aassured,
	            $Est.aassured_zip,$Est.itel,$Est.itel_night,$Est.mobil_phone,
	            $Est.apayment,$Est.apayment_zip,$Est.iply_area,$Est.dissue,
	            $Est.ipro_year,$Est.ibrand,$Est.nbrand_abbr,$Est.icar_type2,
	            $Est.icar_type1,$Est.ncar_abbr,$Est.fcar_note2,$Est.qcylinder,
	            $Est.iengine,$Est.ibody,$Est.itag,$Est.mcar_price,
	            $Est.pdmg_align,$Est.pbrg_align,$Est.plia_align,$Est.mpremium2,
	            $Est.mpremium1,$Est.ibig_comp,$Est.ibig_branch,$Est.ibig_office, $Est.qprovision,
	            $Est.ibig_sales,$Est.iresource,$Est.fdiscount,$Est.ibroker2,
	            $Est.ibroker1,$Est.iofficer2,$Est.iofficer1,$Est.icorps,
	            $Est.iarea,$Est.icashier,$Est.iexaminer,$Est.dexamine,
	            $Nquota,$Est.dentry,$Est.dapply,$Est.fcal_way,
	            $Est.ipolicy1,$Est.ipolicy2 ,$Est.idmg_rate,$Est.pdmg_factor,
	            $Est.ibrg_rate,$Est.pbrg_factor,$Est.ibranch,$Est.qpt,
	            $Est.fpt,$Est.psex_age2,$Est.psex_age1,
	            $Est.psex_age_damage,
	            $Est.lia_class,$Est.plia_acc2,$Est.plia_acc1,$Est.dmg_acc_1st,
	            $Est.dmg_acc_2nd,$Est.dmg_acc_3rd,$Est.pdmg_acc,$Est.fhuman,
	            $Est.fcomp_24,$Est.mbus_rule,$Est.mbusiness,$Est.fcomp_class,
	            $Est.fcomp_class_last,$Est.iemail,$Est.iquery_num_c,
	            $Est.iquery_num ,$Est.iquery_num_damage,
	            $Fcar_class,$Ncode,$Nname,$Nchi_abv,
	            $Est.napplicant,$Est.mequipment,$Est.iroute, $Est.iroute_prop,
	            $Est.iroute_comm2,$Est.qlia_acc_sum,$Est.qdmg_acc_sum,
	            $Est.ndeputy_assured, $Est.ndeputy_appl, $Est.nrelation_appl, $Est.fsex_appl,
	            $sFapplicant, $Est.iapplicant, $Est.dbirth_appl, $Est.itel_appl, $sFcard_class, $Est.qdrunk_driving,
	            $Est.transno,$Est.nequipment,$Est.fuw_status, $Est.iaccept, $sMcover_limit,
	            $sIassured_cntry, $sIapplicant_cntry, $sIleader,
	            $fequipment1,$fequipment2,$fequipment3,$fequipment4,
	            $fequipment5,$fequipment6,$fequipment9,$nequipment9,
	            $feply,$fecard,$aemail_eply,$punknown_acc,$iquery_num_unknown,
		        $Est.foccup, $Est.noccup, $Est.applicant_foccup, $Est.applicant_noccup,
	            $Est.nmile_ubi, $Est.pubi_acc, $fchk_24, $Est.tmobile_eply, $tmobile_appl, $aemail_appl, $feterms, $qviolate, $f20230601;
				
	      if(SQLCODE == SQLNOTFOUND)
	         break;
	
	      /* �s�W�Ӹ��ˮ�   add by sylvia 103.02.14 (1020924002_C2) */
	      iCountDeny=0;
	        $select count(*) into $iCountDeny
	            from cm_personal_deny
	           where iassured = $Est.iassured
	             and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
	             and ddeny <= today
	             and (dexpire is null or dexpire >= today);
	      if(iCountDeny > 0)
	         continue; 
	         
	      strcpy(sIleader,trim(sIleader));
	      $SELECT nname
	         INTO $nleader
	         FROM officer
	        WHERE iofficer = $sIleader;
	        
	      if(SQLCODE == SQLNOTFOUND)
	      		strcpy(nleader," ");
	         
	/*         
	      strcpy(sIleader,trim(sIleader));
	
	      if (strcmp(sIleader,sUserid) != 0)
	      {
	
	      		/* �O�������ˮ�(�j��) 
	      		rtn = chk_spec_deny( Est.ipolicy1, Est.icard1, Est.iassured, Est.iapplicant, Est.itag, Est.iengine, sMsg);
	      		if (rtn == M_CA_SPEC_DENY)
	         		continue;
	
	      		/* �O�������ˮ�(���N) 
	      		rtn = chk_spec_deny( Est.ipolicy2, Est.icard2, Est.iassured, Est.iapplicant, Est.itag, Est.iengine, sMsg);
	      		if (rtn == M_CA_SPEC_DENY)
	         		continue;
	      }
	*/
	      printf("-----transno[%s],nequipment[%s]\n",Est.transno,Est.nequipment);

	      	 if (strncmp(sFcard_class,"1",1) == 0)
	      	   strcpy(sIpolicy,Est.ipolicy1);
	      	 else
	      	   strcpy(sIpolicy,Est.ipolicy2);
	
	      	 $SELECT first 1 isys INTO $sIsys
	      	    FROM cm_pre_receive
	      	   WHERE ipolicy1 = $sIpolicy;
	      	  if(SQLCODE == SQLNOTFOUND) strcpy(sIsys," ");
	
	      	  if (strncmp(sIsys,"4",1) == 0)
	      	    strcpy(sBarcode_type,"���O");
	      	  else if (strncmp(sIsys,"5",1) == 0)
	      	    strcpy(sBarcode_type,"��ĳ��O");
	      	  else
	      	    strcpy(sBarcode_type," ");
	
	      /* ��պ��ɸ�� */
	
	      $select first 1 dentry into $Est.dentry
	         from cm_pre_receive
	        where ipre_rcv = $Est.iestimate;
	
	      if(SQLCODE == SQLNOTFOUND)
	       		strcpy(Est.dentry, " ");
	
	      strcpy(Est.itel_night, " ");
	      strcpy(Est.mobil_phone, " ");
	
	      printf("Est.iestimate=[%s]Est.irelative_ply=[%s]\n",Est.iestimate,Est.irelative_ply);
	      printf("Est.ipolicy1=[%s]Est.ipolicy2=[%s]\n",Est.ipolicy1,Est.ipolicy2);
	      icount1++;
	
	      /* �����s���O���� */
	      strcpy(Est.irelative_ply, trim(Est.irelative_ply));
	      if (strlen(Est.irelative_ply) > 1 )
	      {
	      	  strcpy(tmp_iestimate, " ");
	          if (strcmp(sFcard_class,"2") == 0)
		  {	 /* ���p�O��O�j���I�O�� */
		      strcpy(sIestimate_c, " ");

		      sprintf_s(stmt1, sizeof stmt1,"select a.icard, a.icard, a.dply_begin, a.dply_end, "
			            "       a.icar_type, nvl(a.mlia_prem,0), a.ibroker, a.iofficer, "
			            "       a.ipolicy, b.psex_age, nvl(b.plia_acc,' '), b.iquery_num, "
			            "       a.itmp_policy "
	                	    "  FROM %s a, %s b  "
	                            " WHERE a.ipolicy = b.ipolicy "
	                            "   and a.fcard_class = '1'"
	                            "   and a.ipolicy = '%s' ;",tableRelation,tablePly,Est.irelative_ply);
					
		      printf("stmt1=[%s]\n", stmt1);

           	      $prepare pre1_1 FROM $stmt1;
           	      $execute pre1_1 INTO $Est.icard1, $Est.irelative_card, $Est.dply1_begin,$Est.dply1_end,
			                   $Est.icar_type1, $Est.mpremium1, $Est.ibroker1, $Est.iofficer1,
			                   $Est.ipolicy1, $Est.psex_age1, $Est.plia_acc1, $Est.iquery_num_c,
			                   $tmp_iestimate;
	
		      if ((strlen(trim(sIestimate_c)) == 0) && (strlen(trim(tmp_iestimate)) > 0))
		          strcpy(sIestimate_c, tmp_iestimate);
	
		      printf("sIestimate_c=[%s],tmp_iestimate=[%s]\n ",sIestimate_c,tmp_iestimate);
	
		  }
		  else
		  { 
		      /* ���p�O��O���N�I�O�� */
		      strcpy(sIestimate_c, Est.iestimate);
			             
		      sprintf_s(stmt1, sizeof stmt1,"select a.icard, a.icard, a.dply_begin, a.dply_end, "
			            "       a.icar_type, nvl(a.mlia_prem,0), a.ibroker, a.iofficer, "
			            "       a.ipolicy, b.psex_age, nvl(b.plia_acc,' '), b.iquery_num, "
			            "       a.itmp_policy "
	                	    "  FROM %s a, %s b  "
	                            " WHERE a.ipolicy = b.ipolicy "
	                            "   and a.fcard_class = '2'"
	                            "   and a.ipolicy = '%s' ;",tableRelation,tablePly,Est.irelative_ply);

		      printf("stmt1=[%s]\n", stmt1);
					
           	      $prepare pre1_2 FROM $stmt1;
           	      $execute pre1_2 INTO $Est.icard2, $Est.irelative_card, $Est.dply2_begin,$Est.dply2_end,
			                   $Est.icar_type2, $Est.mpremium2, $Est.ibroker2, $Est.iofficer2,
			                   $Est.ipolicy2, $Est.psex_age2, $Est.plia_acc2, $Est.iquery_num,
			                   $Est.iestimate;     

		      printf("sIestimate_c=[%s],tmp_iestimate=[%s]\n ",sIestimate_c,tmp_iestimate);

		  }
	
	      }
	      else
	      {
	          if (strcmp(sFcard_class,"2") == 0)
	      	  {	
	      	      /* ���p�O��O�j���I�O�� */
		      strcpy(Est.icard1, " ");
		      strcpy(Est.irelative_card, " ");
		      strcpy(Est.dply1_begin, " ");
		      strcpy(Est.dply1_end, " ");
		      strcpy(Est.icar_type1, " ");
		      Est.mpremium1 = 0;
		      strcpy(Est.ibroker1, " ");
		      strcpy(Est.iofficer1, " ");
		      strcpy(Est.ipolicy1, " ");
		      Est.psex_age1 = 0;
	              Est.plia_acc1 = 0.00;
		      strcpy(Est.iquery_num_c, " ");
		      strcpy(sIestimate_c, " ");
	       	  }
	       	  else
	       	  {	
	       	      /* ���p�O��O���N�I�O�� */
		      strcpy(Est.icard2, " ");
		      strcpy(Est.irelative_card, " ");
		      strcpy(Est.dply2_begin, " ");
		      strcpy(Est.dply2_end, " ");
		      strcpy(Est.icar_type2, Est.icar_type1);
		      Est.mpremium2 = 0;
		      strcpy(Est.ibroker2, Est.ibroker1);
		      strcpy(Est.iofficer2, Est.iofficer1);
		      strcpy(Est.ipolicy2, " ");
		      Est.psex_age2 = 0;
		      Est.plia_acc2 = 0.00;
		      strcpy(Est.iquery_num, " ");
		      strcpy(sIestimate_c, Est.iestimate);
		      strcpy(Est.iestimate, " ");
	       	  }
	      }
	
	      /* �e��j��Υ��N�g�� */
	      strcpy(Fcard_class," ");
	      strcpy(LastOff1," ");
	      strcpy(LastOff2," ");
	      if (strlen(rtrim(Est.ilast_ply))!=0) {
	   	   strcpy(FullDB,get_dtl_full_db(Est.ilast_ply));
	   	   sprintf_s(stmt_last, sizeof stmt_last,
	   	      "select x.fcard_class,trim(x.iofficer) || y.nname, "
	            "       (select trim(a.iofficer)||b.nname "
	            "          from %s:%s a, officer b "
	            "         where a.iofficer = b.iofficer "
	            "           and x.irelative_ply = a.ipolicy ) "
	            "  from %s:%s x, outer officer y "
	            " where x.ipolicy = ? "
	            "   and x.iofficer = y.iofficer", FullDB,tableRelation,FullDB,tableRelation);
	
	         printf("stmt_last=[%s]\n", stmt_last);
	
	         $prepare pre_lastC2 from $stmt_last;
	   	   $execute pre_lastC2
	   	       into $Fcard_class,$LastOff1,$LastOff2
	            using $Est.ilast_ply;
	         if (NOT_FOUND) {
	            strcpy(Fcard_class," ");
	            strcpy(LastOff1," ");
	            strcpy(LastOff2," ");
	         }
	      }
	
	      strcpy(Est.iestimate, trim(Est.iestimate));
	      strcpy(sIestimate_c, trim(sIestimate_c));
	      printf("-----sIestimate_c=[%s] Est.irelative_ply=[%s]\n",sIestimate_c,Est.irelative_ply);
		  
              /*�e��j����N�O�渹*/
              strcpy(iLastRelative_ply1,"");
              strcpy(iLastRelative_ply2,"");
              strcpy(stmt_last,"");
              if (strlen(rtrim(Est.ilast_ply))!=0) 
              {
		  strcpy(FullDB,get_dtl_full_db(Est.ilast_ply));
   	   	  sprintf_s(stmt_last, sizeof stmt_last,
		   	    "select (CASE WHEN fcard_class ='1' THEN  ipolicy ELSE nvl(irelative_ply,'') end),"
		   	    "       (CASE WHEN fcard_class ='1' THEN nvl(irelative_ply,'')  ELSE ipolicy end)"
		            "  from %s:%s  "
		            " where ipolicy = ? ", FullDB, tableRelation);

		  printf("stmt_last=[%s]\n", stmt_last);

		  $prepare pre_LastRelative4 from $stmt_last;
		  $execute pre_LastRelative4
		      into $iLastRelative_ply1,$iLastRelative_ply2 using $Est.ilast_ply;
		  if (NOT_FOUND) 
		  {
		      strcpy(iLastRelative_ply1," ");
		      strcpy(iLastRelative_ply2," ");
		      break;
		  }
              }
		  
	      provision_J = 0;
              sprintf_s(stmt3, sizeof stmt3,
	   	      "select count(*) "
	          "  from %s "
	          " where ipolicy = ? "
	          "   and trim(nvl(provision,' '))||';' like '%%J;%%' ",tableInsType);
	
	         $prepare pre_pro_J from $stmt3;
	   	     $execute pre_pro_J into $provision_J using $Est.ipolicy2;
        
	      /* �^�����w�r�p�H����(D���ڡ^�W�U  add by sylvia 101.06.21 */
	      sNprovD[0]='\0';
	      if (Est.qprovision > 0 || provision_J > 0)
	      {
	      	/*strcpy(sNprovD, "���w�r�p�H�G");*/
	      	iCount2 = 0;
	      	strcpy(ninsType, "");
	      	strcpy(sNins_type, "");
	      	sprintf_s(stmt6, sizeof stmt6, "SELECT trim(a.iins_type)||(SELECT nins_abbr FROM insurance_type WHERE iins_type = a.iins_type) \
	      	                  FROM %s a \
	      	                 WHERE a.ipolicy = '%s' \
	      	                   AND (trim(nvl(a.provision,' '))||';' like '%%D;%%' or trim(nvl(a.provision,' '))||';' like '%%J;%%') ",tableInsType,Est.ipolicy2);
	        $PREPARE  preplyProvD2 FROM $stmt6;
	        $DECLARE  cur_ply_provD2 CURSOR FOR preplyProvD2;
	        $OPEN     cur_ply_provD2;
	
	        for(;;)
	        {
	            $FETCH cur_ply_provD2 INTO $ninsType;
	            if(SQLCODE == SQLNOTFOUND)  break;
	
	            iCount2++;
	
	            if (iCount2 == 1)
	            {
	            	strcpy(sNins_type, trim(ninsType));
	            }
	            else
	            {
	            	strcat(sNins_type, ";");
	            	strcat(sNins_type, trim(ninsType));
	            }
	        }
	      	$CLOSE  cur_ply_provD2;
		$FREE   cur_ply_provD2;
	
	      	sprintf_s(stmt5, sizeof stmt5,"select ipolicy, iins_type, provision, iassured, nassured,\
	                           year(dbirth)-1911||to_char(dbirth,'/%%m/%%d') AS dbirth,\
	                           nbenef, rel_benef, iserial \
	                      from %s where ipolicy = ? \
	                       and (trim(nvl(provision,' '))||';' like '%%D;%%' or trim(nvl(provision,' '))||';' like '%%J;%%')",tableAssured);
	
		$PREPARE  pre_EP2 FROM $stmt5;
		$DECLARE  cur_EP2 CURSOR FOR pre_EP2;
		$OPEN     cur_EP2 USING $Est.ipolicy2;
		while(1)
		{
		     $FETCH cur_EP2 INTO
		            $Assured.iestimate, $Assured.iins_type, $Assured.provision,
		            $Assured.iassured, $Assured.nassured, $Assured.dbirth,
		            $Assured.nbenef, $Assured.rel_benef, $Assured.iserial;
		     if(SQLCODE == SQLNOTFOUND)  break;
		            /*iCount2 ++;
		            strcat(sNprovD, rtrim(Assured.nassured));
		            if (iCount2 < Est.qprovision)
		            	strcat(sNprovD,"�B");
		            else
		            	strcat(sNprovD,"�C");*/
		     printf("provD nassured=[%s], iassured[%s], dbirth[%s]\n", Assured.nassured, Assured.iassured, Assured.dbirth);
		     fprintf(fp2,"%s\t%s\t%s\t%s\t%s\n", trim(sNins_type),Assured.nassured,Assured.iassured,Assured.dbirth,Assured.iestimate);
		}
		$close    cur_EP2 ;
		$free     cur_EP2 ;
	      }/* �^�����w�r�p�H����(D���ڡ^�W�U  end ----------------------- */
	      
	      
              /* �^���r�p�H�ˮ`�W�U  1090221006_SC4_��_56�r�p�H�W�U */
              strcpy(stmt9_1,"CASE b.fassured WHEN '2' THEN '' WHEN '4' THEN '' WHEN '6' THEN ''  ELSE to_char(year(a.dbirth)-1911)||'/'||to_char(a.dbirth,'%m/%d') END");
      	      sprintf_s(stmt9, sizeof stmt9,/*"SELECT a.ipolicy,a.iins_type,a.iassured,a.nassured,"
      	                    "       %s ,"
      	                    "       a.nbenef,a.rel_benef,a.tbenef,a.abenef "
                            "  FROM %s a,%s b "
                            " WHERE a.ipolicy=? AND a.ipolicy=b.ipolicy AND a.iins_type IN ('50') "
                            " UNION "*/
      	                    "SELECT a.ipolicy,a.iins_type,a.iinsurant,a.ninsurant, "
      	                    "       %s , "
      	                    "       a.nbeneficiary,a.relation_bene,a.tbenef,a.abenef "
                            "  FROM %s a,%s b "
                            " WHERE a.ipolicy=? AND a.ipolicy=b.ipolicy AND a.iins_type IN ('56','136','266') "
                            " UNION "
                            "SELECT a.ipolicy,a.iins_type,a.iassured,a.nassured, "
                            "       %s , "
                            "       a.nbenef,a.rel_benef,a.tbenef,a.abenef "
                            "  FROM %s a,%s b "
                            " WHERE a.ipolicy=? AND a.ipolicy=b.ipolicy AND a.iins_type IN ('147''561')",stmt9_1,tablePaPly,tablePly,stmt9_1,tableAssured,tablePly);
      	      printf("stmt9=[%s]\n",stmt9);
      	      
              $PREPARE  pre_list_auto FROM $stmt9;
	      $DECLARE  cur_list_auto CURSOR FOR pre_list_auto;
	      $OPEN     cur_list_auto using $Est.ipolicy2,$Est.ipolicy2;
	      while(1)
	      {
	          $FETCH cur_list_auto INTO $ipolicy_list,$iins_type_list,$iinsurant_list,
	                               $ninsurant_list,$dbirth_list,$nbeneficiary_list,
	                               $relation_bene_list,$tbenef_list,$abenef_list;

	          if(SQLCODE == SQLNOTFOUND)  break;

	          fprintf(fp4,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\n", ipolicy_list,iins_type_list,iinsurant_list,ninsurant_list,dbirth_list,nbeneficiary_list,relation_bene_list,tbenef_list,abenef_list);
	      }
	      $close    cur_list_auto;
	      $free     cur_list_auto;
              /* �^���r�p�H�ˮ`�W�U  end ----------------------- */
	      
	      
	
	      /* 97���O�n�O�ѤW��ܡi�䲼ú�ڡj104.04.23 (1040407003_C2) */
	      if (equip_cmp(Est.nequipment,"97") == TRUE)
	          strcpy(equip97,"Y");
	      else
	      	  strcpy(equip97,"N");
	      	  
	      /******************* 30�I�ةӫO�d�򻡩����e(BEGIN) *******************/
printf("30�I�ةӫO�d�򻡩����eBEGIN\n");

	sprintf_s(stmt3, sizeof stmt3,"SELECT iins_type,mdeduct \
	                 FROM %s where ipolicy = ? \
	                  AND iins_type in ( '30','301','302','530' );",tableInsType);

	$PREPARE pre_ins30 FROM $stmt3;
	$EXECUTE pre_ins30 INTO $iins_type30_301,$deduct_30 using $Est.ipolicy2;
	    
	if(SQLCODE == SQLNOTFOUND)
	{
		strcpy(str_ins_30," ");
	}
	else
	{
		strcpy(iins_type30_301,trim(iins_type30_301));
		/*�P�_��O���O30�I���٬O301�I��*/
		if( strcmp(iins_type30_301,"30") == 0 )
		{
			flag30_301 = 30;
		}
		else if( strcmp(iins_type30_301,"301") == 0 )
		{
			flag30_301 = 301;
		}
		else if( strcmp(iins_type30_301,"302") == 0 )
		{
			flag30_301 = 302;
		}
        else
        {
            flag30_301 = 530;
        }
		/*�T�{���[�O24*/    
		$SELECT iins_type
		   INTO $iins_type24
		   FROM ply_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type = '24';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��24�I��*/
		{
			flag24=0;
		}
		else
		{
			flag24=1;
		}	
		/*�T�{���[�O55*/
		$SELECT iins_type
		   INTO $iins_type55
		   FROM ply_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type = '55';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
		{
			flag55=0;
		}
		else
		{
			flag55=1;
		}
		/*�T�{���[�O55*/
		$SELECT iins_type
		   INTO $iins_type55
		   FROM ply_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type = '255';
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
		{
			flag255=0;
		}
		else
		{
			flag255=1;
		}
		/*�T�{���[�O49 or 177*/
		$SELECT iins_type
		   FROM ply_ins_type
		  WHERE ipolicy = $Est.ipolicy2
		    AND iins_type IN ('49','117');
		if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��49 or 117�I��*/
		{
			flag49117=0;
		}
		else
		{
			flag49117=1;
		}
        /*�T�{���[�O555*/
		$SELECT iins_type
           INTO $iins_type55
           FROM ply_ins_type
          WHERE ipolicy = $Est.ipolicy2
            AND iins_type = '555';
        if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��555�I��*/
        {
            flag555=0;
        }
        else
        {
            flag555=1;
        }
		strcpy(tmp_deduct_30,itoa(deduct_30));
		/* 1080311008_SC4_�ͮĤ��71�_����s�v�I */
		if( (flag30_301 == 302) && (flag55 == 1) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d��]�t:������˳d�����[���ڡC");
            }
            else
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d�򤣥]�t:������˳d�����[���ڡC");
            }
			
		}
		else if ( (flag30_301 == 302) && (flag255 == 1) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d��]�t:������˳d���I�C");
            }
            else
            {
            	strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d�򤣥]�t:������˳d���I�C");
            }
			
		}
		
		if( (flag30_301 == 301) && (flag55 == 1) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d���I���[����-��D���W���ӫO�d��]�t:������˳d�����[���ڡC");
            }
            else
            {
            	strcpy(str_ins_30,"�W�B�d���I���[����-��D���W���ӫO�d�򤣥]�t:������˳d�����[���ڡC");
            }
			
		}
		else if( (flag30_301 == 301) && (flag255 == 1) )
		{
			strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-��D���W���ӫO�d�򤣥]�t:������˳d���I�C");
		}
		
		if( (flag30_301 == 30) && (flag24 == 1) && (flag55 == 1) && (strncmp(fchk_24,"Y",1)==0))
		{
			if ((IsFcomp24(tmp_deduct_30)) && (IsFcomp55(tmp_deduct_30)))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:�ĤT�H�d�����s���v�T�έ�����˳d�����[���ڡC");
            }
			else if (IsFcomp24(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:�ĤT�H�d�����s���v�T���[���ڤ��]�t������˳d�����[���ڡC");
            }
			else if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:������˳d�����[���ڤ��]�t�ĤT�H�d�����s���v�T���[���ڡC");
            }
			else
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:�ĤT�H�d�����s���v�T�έ�����˳d�����[���ڡC");
            }
		}
		else if( (flag30_301 == 30) && (flag24 == 1) && (strncmp(fchk_24,"Y",1)==0))
		{
			if (IsFcomp24(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:�ĤT�H�d�����s���v�T���[���ڡC");
            }
			else
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:�ĤT�H�d�����s���v�T���[���ڡC");
            }		
		}
	    else if( (flag30_301 == 30) && ((flag55 == 1)||(flag49117 == 1)) )
		{
			if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d��]�t:������˳d�����[���ڡC");
            }
			else
            {
            	strcpy(str_ins_30,"�W�B�d�����[����-�O�٫��ӫO�d�򤣥]�t:������˳d�����[���ڡC");
            }		
		}
		else if( (flag30_301 == 30) && ((flag255 == 1)||(flag49117 == 1)) )
		{
			strcpy(str_ins_30,"�ĤT�H�W�B�d���I�O�I-�O�٫��ӫO�d�򤣥]�t:������˳d���I�C");		
		}
        
        if((flag30_301 == 530) && (flag555 == 1))
        {
            if (IsFcomp55(tmp_deduct_30))
            {
            	strcpy(str_ins_30,"�r�V�Z�W�B�d���I�ӫO�d��]�t�G�r�V�Z������˳d���I�C");
            }
            else
            {
            	strcpy(str_ins_30,"�r�V�Z�W�B�d���I�ӫO�d�򤣥]�t�G�r�V�Z������˳d���I�C");
            }
        }
	}

printf("30�I�ةӫO�d�򻡩����eEND\n");
      /******************* 30�I�ةӫO�d�򻡩����e(END) *********************/
    
      /* 1120316006_SC5_�L��-���N�I���e�{�s�W���@�������������O�N��05�ή��s�X��t�ηs�W���@�����O */
      flag_ambulance55 = 0;
      $SELECT iins_type
		 INTO $iins_type55
		 FROM ply_ins_type
		WHERE ipolicy = $Est.ipolicy2
		  AND iins_type = '55';
      if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
      {
          flag_ambulance55=0;
      }
      else
      {
          flag_ambulance55=1;
      }
      
      if (flag_ambulance55 > 0 && strncmp(Est.icar_type2,"11",2) == 0 && equip_cmp(Est.nequipment,"115") == true && f20230601[0] == 'Y')
      {
      	 if (str_ins_30[0] == '' || str_ins_30[0] == '\0' ) strcat(str_ins_30," ");
      	 strcat(str_ins_30,"�����I�ӫO�d�򤣧t�˱w");
      }
      else 
      {
          
      }  

      /******************* �t�Ʃ���(BEGIN) ***********************/
      strcpy(outfit_nequipment," ");
      if(strcmp(fequipment1,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B���T");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"���T");
      	}
      }
      
      if(strcmp(fequipment2,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B���c");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"���c");
      	}
      }
      
      if(strcmp(fequipment3,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B�N�����");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"�N�����");
      	}
      }
      
      if(strcmp(fequipment4,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B���ءB����");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"���ءB����");
      	}
      }
      
      if(strcmp(fequipment5,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B�@���t��");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"�@���t��");
      	}
      }
      
      if(strcmp(fequipment6,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B�q�ʨ��q��");
      	}
      	else
      	{
      		strcpy(outfit_nequipment,"�q�ʨ��q��");
      	}
      }
      
      if(strcmp(fequipment9,"1") == 0)
      {
      	if (strlen(trim(outfit_nequipment)) != 0)
      	{
      		strcat(outfit_nequipment,"�B");
      		strcat(outfit_nequipment,nequipment9);
      	}
      	else
      	{
      		strcpy(outfit_nequipment,nequipment9);
      	}
      }
      
      printf("outfit_nequipment[%s]\n",outfit_nequipment);

      /******************* �t�Ʃ���(END) ***********************/
      
      /* �j+�� -> ���N�g��H;���  -> ���N�g��H;��j  -> ���N�g��H */
      strcpy(Est.iofficer2,trim(Est.iofficer2));
      if (strlen(Est.iofficer2) == 0)
      {
      	$SELECT nname
      	   INTO $Nname
      	   FROM officer
      	  WHERE iofficer = $Est.iofficer1;
      }
      
      /**/
	/*1060316009_C1_CAR322�n�O�ѦC�L�M�L �۰ʥX��W�[�C�L�~�ȭ��n�J�Ҹ�*/
	/* ���n���Ҧr�� */
	sprintf_s(stmt_iregno, sizeof stmt_iregno, " SELECT ireg_no \
			  FROM ca_big_office \
			 WHERE fclass = '2' and ibig_comp = ?");
	$PREPARE prep_iregno FROM $stmt_iregno;
  
	/* ���n���Ҧr��_KA */
	sprintf_s(stmt_iregno, sizeof stmt_iregno, " SELECT ilicence \
			  FROM cm_salesman_log \
			 WHERE ileader = ? and icomm_obj = ileader ");
	$PREPARE prep_iregno_KA FROM $stmt_iregno;
	
	/* Z32018N/JZ */
	strcpy(FullDB2,get_dtl_full_db(sIpolicy));
	sprintf_s(stmt_iregno, sizeof stmt_iregno, " SELECT ireg_no \
			  FROM %s:%s \
			 WHERE ipolicy = '%s' ",FullDB2,tableRelation,sIpolicy);
	$PREPARE prep_iregno_JZ FROM $stmt_iregno;
	
	printf("stmt_iregno[%s] \n",stmt_iregno);
	printf("Est.iroute[%s]  Est.iofficer2[%s] Est.iofficer1[%s] \n",Est.iroute,Est.iofficer2,Est.iofficer1);
	
	/* J*�MB*�g��N��, ���C�L��~�����n���Ҧr��,��l�ť� */
        strcpy(Est.ireg_no," ");

        if ((Est.iofficer2[0] == 'J') || (Est.iofficer2[0] == 'B'))
        {
		$EXECUTE prep_iregno into $Est.ireg_no using $Est.ibig_sales;
		if (SQLCODE == SQLNOTFOUND) strcpy(Est.ireg_no," ");
        }
        else if (strncmp(Est.iroute,"KA",2) == 0)
        {
		/* �O��q���N����KA*��, �n�]�n�^���n���Ҧr�� */
		$EXECUTE prep_iregno_KA	into $Est.ireg_no using $sIleader;
        	if (SQLCODE == SQLNOTFOUND) strcpy(Est.ireg_no," ");
        }
        else if ((strncmp(Est.iroute,"JZ",2) == 0) && (strcmp(trim(Est.iofficer2),"Z32018N")==0 || strcmp(trim(Est.iofficer1),"Z32018N")==0))
        {
        	$EXECUTE prep_iregno_JZ	into $Est.ireg_no;
        	if (SQLCODE == SQLNOTFOUND) strcpy(Est.ireg_no," ");
        	 	
        }
        printf("Est.ireg_no[%s] \n",Est.ireg_no);
	/*------------------------------------------------------------------*/
	
      /*�����I¾�~*/
      sprintf_s(stmt_occup1, sizeof stmt_occup1, "SELECT (trim(imember)||' '||trim(nmember)) FROM cm_risk_member WHERE itype = 'P' AND fmember = 'P' AND imember = '%s' ",Est.noccup);
      $PREPARE prep_occup_est1 FROM $stmt_occup1;
      $EXECUTE prep_occup_est1 into $noccup_fullname;
      if (SQLCODE == SQLNOTFOUND) strcpy(noccup_fullname," "); 
      
      sprintf_s(stmt_occup2, sizeof stmt_occup2, "SELECT (trim(imember)||' '||trim(nmember)) FROM cm_risk_member WHERE itype = 'P' AND fmember = 'P' AND imember = '%s' ",Est.applicant_noccup);
      $PREPARE prep_occup_est2 FROM $stmt_occup2;
      $EXECUTE prep_occup_est2 into $applicant_noccup_fullname;
      if (SQLCODE == SQLNOTFOUND) strcpy(applicant_noccup_fullname," "); 
      
      printf("noccup_fullname[%s] applicant_noccup_fullname[%s] \n",noccup_fullname,applicant_noccup_fullname);	


      /******���[���ڤ�r����(BEGIN)******/
      
      strcpy(iprov_all," ");
      strcpy(sprov_all," ");
      strcpy(iprov," ");
      strcpy(iins_prov," ");
      strcpy(sprov," ");
      strcpy(sprov_note," ");
      strcpy(sprov_note_all," ");    

      sprintf_s(stmt7, sizeof stmt7, "SELECT trim(nvl(provision,' '))||';',iins_type FROM %s WHERE ipolicy = '%s' " ,tableInsType, Est.ipolicy2);
      	               
      $PREPARE  preProvision13 FROM $stmt7;
      $DECLARE  cur_provision13 CURSOR FOR preProvision13;
      $OPEN     cur_provision13;

      for(;;)
      {
            $FETCH cur_provision13 INTO $iprov,$iins_prov;
            if(SQLCODE == SQLNOTFOUND)  break;

            if (strstr(trim(iprov),"P;") != NULL)
            {
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0) )

                    $SELECT first 1 replace($iprov,'P;','')
		       INTO $iprov
		       FROM systables;
		       	
        	
            }
            else if (strstr(trim(iprov),"Q;") != NULL)
            {
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'Q;','')
		       INTO $iprov
		       FROM systables;	
            }
            else if (strstr(trim(iprov),"M;") != NULL)
            {
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) && 
                    (strcmp(trim(iins_prov),"181")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'M;','')
		       INTO $iprov
		       FROM systables;		
            }  
            else if (strstr(trim(iprov),"Y;") != NULL)
            {
            	/* 1130827011_C04_�s�W�s�t��W�B���[����(Y)(�L��) */
                if ((strcmp(trim(iins_prov),"01")!=0)  && (strcmp(trim(iins_prov),"05")!=0)  && (strcmp(trim(iins_prov),"09")!=0)  && (strcmp(trim(iins_prov),"11")!=0) && 
                    (strcmp(trim(iins_prov),"198")!=0) &&
                    (strcmp(trim(iins_prov),"201")!=0) && (strcmp(trim(iins_prov),"205")!=0) && (strcmp(trim(iins_prov),"209")!=0) && (strcmp(trim(iins_prov),"211")!=0))

                    $SELECT first 1 replace($iprov,'Y;','')
		       INTO $iprov
		       FROM systables;		
            }         

            strcat(iprov_all, iprov);

      }
      $CLOSE  cur_provision13;
      $FREE   cur_provision13;
      printf("�����[����:iprov_all[%s]\n",trim(iprov_all));
      strcpy(iprov_all,trim(iprov_all));
      
      if (strcmp(iprov_all,";")!=0 && strcmp(iprov_all,"")!=0)
      {
          ptr1 = strtok(iprov_all,";");
	  while(ptr1 != NULL)
	  {
      	      sprintf_s(sprov, sizeof sprov,"'%s',",ptr1);  
      	      strcat(sprov_all,sprov);	  				
	      ptr1 = strtok(NULL, ";");
	  }
				
          strcat(sprov_all,"''");
          printf("�����[����:sprov_all[%s]\n",trim(sprov_all));
      	
      	  sprintf_s(stmt8, sizeof stmt8, "SELECT trim(nprint)||'�B' FROM ca_provision_main WHERE iprovision NOT IN ('C','E','S') AND iprovision IN (%s)" , trim(sprov_all));
          $PREPARE  preProvision14 FROM $stmt8;
          $DECLARE  cur_provision14 CURSOR FOR preProvision14;
          $OPEN     cur_provision14;   
          
          for(;;)
          {
              $FETCH cur_provision14 INTO $sprov_note;
              if(SQLCODE == SQLNOTFOUND)  break;

              strcat(sprov_note_all, trim(sprov_note));

          }
          $CLOSE  cur_provision14;
          $FREE   cur_provision14;   
          printf("�����[���ڤ���:sprov_note_all[%s]\n",trim(sprov_note_all));	  
      	  strcpy(sprov_note_all,trim(sprov_note_all));
      }


      /******���[���ڤ�r����(END)******/



	      /* �g�J��r��,�`�N��춶�Ƕ��Pclient�ݤ@�P ----------------------------- */
	      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
	               Est.iestimate,sIestimate_c,Est.icard2,Est.icard1,Est.irelative_ply);
	      fprintf(fp0,"%s\t%s\t%s\t%s\t",
	                  Est.ilast_ply,Est.ilast_card,Est.irelative_card,Est.ixxcard);
	      fprintf(fp0,"%s\t%s\t%s\t%s\t",
	                  Est.dply2_begin,Est.dply2_end,Est.dply1_begin,Est.dply1_end);
	      fprintf(fp0,"%s\t%s\t%s\t%s\t",
	                  Est.fassured,Est.iassured,Est.iassured_ext,Est.nassured);
	      fprintf(fp0,"%s\t%s\t%s\t%s\t",
	       	         Est.ilicense,Est.dbirth,Est.fsex,Est.fmarriage);
	      fprintf(fp0,"%s\t%s\t%s\t%s\t",
	      	         Est.nuser,Est.ibenef,Est.nbenef,Est.aassured);
	      fprintf(fp0,"%s\t%s\t%s\t%s\t",
	       	         Est.aassured_zip,Est.itel,Est.itel_night,Est.mobil_phone);
	      fprintf(fp0,"%s\t%s\t%s\t%s\t",
	       	         Est.apayment,Est.apayment_zip,Est.iply_area,Est.dissue);
	      fprintf(fp0,"%s\t%s\t%s\t%s\t",
	       	         Est.ipro_year,Est.ibrand,Est.nbrand_abbr,Est.icar_type2);
	      fprintf(fp0,"%s\t%s\t%s\t%.2f\t",
	       	         Est.icar_type1,Est.ncar_abbr,Est.fcar_note2,Est.qcylinder);
	      fprintf(fp0,"%s\t%s\t%s\t%.1f\t",
	       	         Est.iengine,Est.ibody,Est.itag,Est.mcar_price);
	      fprintf(fp0,"%d\t%d\t%d\t%d\t",
	       	         Est.pdmg_align,Est.pbrg_align,Est.plia_align,Est.mpremium2);
	      fprintf(fp0,"%d\t%s\t%s\t%s\t%d\t",
	       	         Est.mpremium1,Est.ibig_comp,Est.ibig_branch,Est.ibig_office,Est.qprovision);
	      fprintf(fp0,"%s\t%s\t%s\t%s\t",
	       	         Est.ibig_sales,Est.iresource,Est.fdiscount,Est.ibroker2);
	      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
	      	         Est.ibroker1,Est.iofficer2,Est.iofficer1,Est.icorps,Est.ireg_no);
	      fprintf(fp0,"%s\t%s\t%s\t%s\t",
	      	         Est.iarea,Est.icashier,Est.iexaminer,Est.dexamine);
	      fprintf(fp0,"%s\t%s\t%s\t%s\t",
	       	         Nquota,Est.dentry,Est.dapply,Est.fcal_way);
	      fprintf(fp0,"%s\t%s\t%s\t%.4f\t",
	      	         Est.ipolicy1,Est.ipolicy2 ,Est.idmg_rate,Est.pdmg_factor);
	      fprintf(fp0,"%s\t%.4f\t%s\t%.1f\t",
	      	         Est.ibrg_rate,Est.pbrg_factor,Est.ibranch,Est.qpt);
	      fprintf(fp0,"%s\t%f\t%f\t%f\t",
	      	         Est.fpt,Est.psex_age2,Est.psex_age1,Est.psex_age_damage);
	      fprintf(fp0,"%s\t%.2f\t%.2f\t%d\t",
	                  Est.lia_class,Est.plia_acc2,Est.plia_acc1,Est.dmg_acc_1st);
	      fprintf(fp0,"%d\t%d\t%.2f\t%s\t",
	   	            Est.dmg_acc_2nd,Est.dmg_acc_3rd,Est.pdmg_acc,Est.fhuman);
	      fprintf(fp0,"%s\t%f\t%f\t%s\t",
	                  Est.fcomp_24,Est.mbus_rule,Est.mbusiness,Est.fcomp_class);
	      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
	                  Est.fcomp_class_last,Est.iemail,Est.iquery_num_c,
	                  Est.iquery_num ,Est.iquery_num_damage);
	      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t%f\t%s\t",
	                  Fcar_class,Ncode,Nname,Nchi_abv,
	       	         Est.napplicant,Est.mequipment,Est.iroute);
	      fprintf(fp0,"%s\t%s\t%d\t%d\t",
	                  Est.iroute_prop, Est.iroute_comm2, Est.qlia_acc_sum,
	                  Est.qdmg_acc_sum );
	      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%d\t%s\t%d\t%s\t%s\t%s\t%s\t%d\t",
	                  Est.ndeputy_assured, Est.ndeputy_appl, Est.nrelation_appl, Est.fsex_appl,
	                  sFapplicant, Est.iapplicant, Est.dbirth_appl, Est.itel_appl, Est.qdrunk_driving,
	                  sBarcode_type, Est.fuw_status, Est.iaccept, equip97, " ", "0",sMcover_limit);
	      fprintf(fp0,"%s\t%s\t%s\t%s\t%s\t",
	                  sIassured_cntry, sIapplicant_cntry,nleader,str_ins_30,outfit_nequipment);
	
	      if (strcmp(Fcard_class,"1") == 0)
	         fprintf(fp0,"%s\t%s\t",LastOff1,LastOff1);   /* �e�欰�j���I */
	      else
	         fprintf(fp0,"%s\t%s\t",LastOff2,LastOff1);   /* �e�欰���N�I */
	         
	      fprintf(fp0,"%s\t%s\t%s\t%.2f\t%s\t",
      		      feply, fecard, aemail_eply, punknown_acc, iquery_num_unknown);
              fprintf(fp0,"%s\t%s\t%s\t%s\t",
      		      Est.foccup, noccup_fullname,Est.applicant_foccup,applicant_noccup_fullname);
      		      
      	      fprintf(fp0,"%f\t%f\t%s\t%s\t%s\t%s\t",Est.nmile_ubi, Est.pubi_acc, Est.tmobile_eply,sprov_note_all, tmobile_appl, aemail_appl);      
      	  
      	      fprintf(fp0,"%s\t%s\t%s\t%d\t", iLastRelative_ply1, iLastRelative_ply2, feterms, qviolate);
      	      
      	      fprintf(fp0,"%s\t%s\t%s\t%s\n"," "," "," "," "); /* 1120927002_C12_�R�q�ΰӫ~�}�o(�L��)�A�ȸպ⦳ */

	      /* �I�ة����� */
	      rc1 = select_autoply_ins_data_1(Est.ipolicy1, Est.ipolicy2, Est.icar_type2, DBName);
	      if (rc1 != SUCCESS)
	         break;
	
	   }
	   $close curD2;
	   $free curD2;

   fclose(fp0);
   fclose(fp1);
   fclose(fp2);
   fclose(fp4);
   icount2 = 0;

   if (rc1 != SUCCESS)
       return rc1;

   if ((icount1+icount2) == 0)
   {
      if(exitsub(reply,M_CM_NOT_FOUND) == True)
         return M_CM_NOT_FOUND;
      else
         return apiRC;
   }
   
   /* �۰ʥX��C�LKYC */
   
 sprintf_s(stmt, sizeof stmt,
 "select unique a.itmp_policy, \
         (SELECT count(*) FROM %s d WHERE d.ipolicy = a.ipolicy AND d.iins_type NOT IN ('50','47')) \
    from %s a, %s b, cm_pre_receive c \
   where a.ipolicy = b.ipolicy \
     and a.itmp_policy = c.ipre_rcv \
     and a.fcard_class = c.iins_kind \
     and c.ipre_end = ' ' \
     and c.isys = '5'     \
     and a.fcard_class = '2' \
     %s                   \
     and a.ipolicy in (select upper(ipolicy) from tmp_policy) ",tableInsType,tableRelation,tablePly,stmt4);

printf("stmt[%s]\n",stmt);

     	$PREPARE  perkyc FROM $stmt;
	$DECLARE  curkyc CURSOR FOR perkyc;
	$OPEN     curkyc;
	while(1)
	{
   		$FETCH curkyc INTO $itmp_policy,$count_50;
   		
   		if(SQLCODE == SQLNOTFOUND)
      		break;
      		
      		if(count_50 == 0)
      			continue;

      		kyc_cnt = kyc_cnt +1;
		fprintf(fp3,"%s\n",trim(itmp_policy));
	}
	$close curkyc;
	$free curkyc;
	
	$drop table tmp_policy;
   
   fclose(fp3);

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   cm_buf_put("%s %s %s",sTmp0,sTmp1,sTmp2);
   cm_buf_put("%s %d %s",sTmp3,kyc_cnt,sTmp4);
 

   tmp_len = cm_buf_len(ReplyBuf);
   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
   else
         return api_OKComplete;

errexit:
   printf(" AAAAAAAAAAAAAAAAAAa = [%d]\n ",SQLCODE);
   fclose(fp0);
   fclose(fp1);
   fclose(fp2);
   fclose(fp4);
   sqlfatal();

   return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
} /* end of select_autoply_data */

/* -------------------------------------------------------------------------- */

long select_autoply_ins_data_1(fipolicy1, fipolicy2, ficar_type, fdbname)
char *fipolicy1, *fipolicy2, *ficar_type, *fdbname;
{
   $char	DBName[5],iest1[21],iest2[21],icar_type[3],ipolicy1[21],ipolicy2[21];
   $char	stmt[8192],stmt1[2048],stmt2[2048],stmt3[1024];
   $struct	est_ins_type   *EstIns;
   int	i=0, rc=0;
   int	tmp_len=0;
   char FullGetName[101], filename[31];
   char sTmp0[71], sTmp1[71], sTmp2[71], file0[71], file1[71];
   char rptstr_main[10000], rptstr_dtl[10000];
   char sApHome[31];

   printf("------- select_autoply_ins_data_1 strat ------------------------------ \n");
   $WHENEVER SQLERROR GOTO errexit;
   strcpy(DBName, fdbname);

   if (db_select(DBName) == False)
         return M_CM_DB_NOTOPEN;

   memset(&EstIns,0, sizeof(EstIns));
   EstIns=(struct est_ins_type *)malloc(sizeof(struct est_ins_type));
	
   strcpy(ipolicy1, fipolicy1);
   strcpy(ipolicy2, fipolicy2);
   strcpy(icar_type, ficar_type);
   strcpy(iest1,"");
   strcpy(iest2,"");
   
   printf(" ------ ipolicy1=[%s] ipolicy2=[%s] icar_type=[%s] \n",ipolicy1, ipolicy2, icar_type);
   printf(" ------ iest1=[%s] iest2=[%s] \n",iest1, iest2);
      
      
   sprintf_s(stmt, sizeof stmt,
      "select a.iins_type,a.minjured_cover,a.mdeath_cover,a.mdamage_cover, "
      "       a.mdeduct,a.mins_premium,a.mpure_prem,a.qserial, "
      "       a.pcommission,a.mcommission,a.pagent,a.magent, "
      "       a.pdiscount,a.mdiscount,a.drate_ym,a.mprem, "
      "       a.iproduct,a.qday,a.mexpense,a.mexp_disc, "
      "       a.provision,a.irate,a.adjust_rate,a.mins_premium_n, "
      "       a.mpure_prem_n,a.mprem_n,a.safe_rate,a.manage_rate, "
      "       a.educated_rate,a.deviation_rate,b.nins_type, "
      "       case when a.iins_type in ('01','05','08','09','120','122','125','126','131','132','201','205','209','331','332') then "
      "            (select prn_deduct from ca_dmg_mdeduct c "
      "              where c.icar_type = ? and c.ideduct = a.mdeduct) "
      "            when b.fdeduct = '0' then '�L' "
      "       else a.mdeduct::varchar(20) end as prn_deduct, "
      "       b.qcoverage, b.cover_print, b.fdeduct, b.deduct_print, "
      " case when a.iins_type in ('56','136','166','266') then (select max(daily_pay) "
      "      from %s d where a.ipolicy = d.ipolicy "
      "       and a.iins_type = d.iins_type) else 0 end as daily_pay, "
      " case when a.iins_type in ('56','136','166','35','266') then (select distinct iins_scope "
      "      from %s f where a.ipolicy = f.ipolicy "
      "       and a.iins_type = f.iins_type) else '0' end as iins_scope, "
      " (select count(*) from insurance_cover e "
      "   where a.iins_type = e.iins_type) as insurance_cover, a.ipolicy, ' '"
      " from %s a, outer insurance_type b "
      "where (ipolicy = ? or ipolicy = ?) "
      "  and a.iins_type = b.iins_type "
      "order by qserial ",tablePaPly,tablePaPly,tableInsType);


   printf("2:stmt=[%s]\n",stmt);

   $prepare pre_stmt2 from $stmt;
   $declare cur_insC2 cursor for pre_stmt2;
   $open    cur_insC2 using $icar_type,$ipolicy1,$ipolicy2;

   /* �g�J��r��,�`�N��춶�Ƕ��Pclient�ݤ@�P ----------------------------- */
   for(i=0;;i++)
   {
      $fetch cur_insC2 into
            $EstIns->iins_type,$EstIns->minjured_cover,
            $EstIns->mdeath_cover,$EstIns->mdamage_cover,
            $EstIns->mdeduct,$EstIns->mins_premium,
            $EstIns->mpure_prem, $EstIns->qserial,
            $EstIns->pcommission,$EstIns->mcommission,
            $EstIns->pagent,$EstIns->magent,$EstIns->pdiscount,
            $EstIns->mdiscount,$EstIns->drate_ym,$EstIns->mprem,
            $EstIns->iproduct,$EstIns->qday,$EstIns->mexpense,
            $EstIns->mexp_disc,$EstIns->provision,$EstIns->irate,
            $EstIns->adjust_rate,$EstIns->mins_premium_n,
            $EstIns->mpure_prem_n,$EstIns->mprem_n,
            $EstIns->safe_rate,
            $EstIns->manage_rate,$EstIns->educated_rate,
            $EstIns->deviation_rate,$EstIns->Nins_type,
            $EstIns->Prn_deduct, $EstIns->qcoverage, $EstIns->cover_print,
            $EstIns->fdeduct, $EstIns->deduct_print, $EstIns->Daily_pay,$EstIns->Iins_scope,
            $EstIns->Ins_cover, $EstIns->iestimate, $EstIns->fproject;
      if (NOT_FOUND) break;

   	printf("EstIns->iins_type=[%s]\n",EstIns->iins_type);
   	
   	if(strcmp(icar_type,"51") == 0)
   	{
   		sprintf_s(stmt2, sizeof stmt2,"select itmp_policy "
	                      "  FROM %s "
	                      " WHERE ipolicy = '%s'; ",tableRelation,ipolicy2);
					
		printf("stmt2=[%s]\n", stmt2);

           	$prepare pre_stmt3 FROM $stmt2;
           	$execute pre_stmt3 INTO $iest2;

		strcpy(iest1," ");
		strcpy(iest2,trim(iest2));
   	}
   	else
   	{
   		strcpy(iest1, fipolicy1);
   		strcpy(iest2, fipolicy2);
   	}
   	
   	fprintf(fp1,"%s\t%d\t%d\t%d\t",
         EstIns->iins_type,EstIns->minjured_cover,
   	   EstIns->mdeath_cover,EstIns->mdamage_cover);

      fprintf(fp1,"%d\t%d\t%f\t%d\t%f\t%d\t",
   	   EstIns->mdeduct,EstIns->mins_premium,EstIns->mpure_prem,
   	   EstIns->qserial,EstIns->pcommission,EstIns->mcommission);

      fprintf(fp1,"%f\t%d\t%f\t%d\t%s\t%d\t",
   	   EstIns->pagent,EstIns->magent,EstIns->pdiscount,
   	   EstIns->mdiscount,EstIns->drate_ym,EstIns->mprem);

      fprintf(fp1,"%s\t%d\t%d\t%d\t%s\t%d\t",
   	   EstIns->iproduct,EstIns->qday,EstIns->mexpense,
   	   EstIns->mexp_disc,EstIns->provision,EstIns->irate);

      fprintf(fp1,"%f\t%d\t%d\t%d\t%f\t",
   	   EstIns->adjust_rate,EstIns->mins_premium_n,
   	   EstIns->mpure_prem_n,EstIns->mprem_n,EstIns->safe_rate);


	  if (strlen(trim(iest2)) > 0 )
	  {
	  		fprintf(fp1,"%f\t%f\t%f\t%s\t%s\t%d\t%s\t%d\t%s\t%s\n",
   	   EstIns->manage_rate,EstIns->educated_rate,
   	   EstIns->deviation_rate,EstIns->Nins_type,
   	   EstIns->Prn_deduct,EstIns->Daily_pay,EstIns->Iins_scope,
   	 EstIns->Ins_cover,iest2,EstIns->fproject);}
	  else
	  	{
   		fprintf(fp1,"%f\t%f\t%f\t%s\t%s\t%d\t%s\t%d\t%s\t%s\n",
   	   EstIns->manage_rate,EstIns->educated_rate,
   	   EstIns->deviation_rate,EstIns->Nins_type,
   	   EstIns->Prn_deduct,EstIns->Daily_pay,EstIns->Iins_scope,
   	 EstIns->Ins_cover,iest1,EstIns->fproject);}

   	   printf(" ------ iest1=[%s] iest2=[%s] icar_type=[%s]\n",iest1, iest2, icar_type);
   }
   $close cur_insC2;
   $free  cur_insC2;

   return SUCCESS;

errexit:
   printf(" BBBBBBBBBBBBBBBBBBB = [%d]\n ",SQLCODE);
    sqlfatal();
    return SQLCODE;
} /* end of select_autoply_ins_data_1 */

int IsFcomp24(str)
char *str;
{
    while (*str)
    {
        if (*str == '2')
        {
           str++;
           if (*str == '4')
           {
              return TRUE;
           }
           else
           {
              str--;
           }
        }
        str++;
    }
    return FALSE;
}

int IsFcomp55(str)
char *str;
{
    while (*str)
    {
        if (*str == '5')
        {
           str++;
           if (*str == '5') /* original version is if (*str == '1') */
           {
              return TRUE;
           }
           else
           {
              str--;
           }
        }
        str++;
    }
    return FALSE;
}
