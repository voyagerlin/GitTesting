/************************************************/
/*                                              */
/*   PROGRAM : ca128m01s.ec by Pei-Chow Chen    */
/*                                              */
/*   Modified by Julia Han in 2006/11/10        */
/*						*/
/*   PURPOSE : server side standard program     */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h" 
$include sqlca;
#include "safeclib.h"


long car128(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car128_insert(),car128_single_query(),car128_multiple_query(),
      car128_update_exec(),car128_check_rate();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
           rtncode=car128_insert(reply);
           break;
  case 'Q':
           rtncode=car128_single_query(reply);
           break;
  case 'M':
           rtncode=car128_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car128_update_exec(reply,command,com_len);
           break;
  case '1':
  	   rtncode=car128_check_rate(reply);
  	   break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
             return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

long car128_insert(reply)
serverReply reply;
{
  $char DBName[5], icode[4], code_flag[2], fcard_class[2];
  $char deffect_bgn[11],deffect_end[11];
  $char strdeffect_bgn[11],strdeffect_end[11];
  $char tmpdeffect_bgn[11],tmpdeffect_end[11];
  $char icode1[4],icode2[4],icode3[4],user[11];
  $int  iym_bgn, iym_end;
  $int  tmp_iym_bgn, tmp_iym_end, cnt;
  int tmp_len;
  DBinfo *list;
  int i, j, is_add_fail=0, api_f;
  $char stmt_buf[300];
  long MsgCode;

  cm_buf_get("%s %s %s %s %s %s %s %s %s %d %d %s",DBName, strdeffect_bgn, strdeffect_end,
  		 icode, fcard_class, code_flag, icode1, icode2, icode3, &iym_bgn, &iym_end,user);
  		
  strcpy(deffect_bgn,cm_to_infdate(strdeffect_bgn));
  strcpy(deffect_end,cm_to_infdate(strdeffect_end));

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
     if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
        return M_CM_DB_NOTOPEN;
     else
        return apiRC;
  }


  if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
     if(exitsub(reply,M_CM_NOT_DBLIST) == True)
       return M_CM_NOT_DBLIST;
     return apiRC;
  }

  $BEGIN WORK;

  cnt = 0;
  for(j=0;j<i;j++) {
    sprintf_s(stmt_buf, sizeof stmt_buf, "SELECT deffect_bgn, deffect_end "
                        " FROM %s:ca_rate_renew "
                        " WHERE fcard_class = ? "
                        " AND ( deffect_bgn BETWEEN ? AND ? "
                        "    OR deffect_end BETWEEN ? AND ? ) ", list[j].dbname); 
    $PREPARE b_id FROM $stmt_buf;
    $DECLARE proc_acur CURSOR FOR b_id;
    $OPEN proc_acur  USING $fcard_class, $deffect_bgn, $deffect_end, $deffect_bgn, $deffect_end;
    while(1) {
       $FETCH proc_acur INTO $tmpdeffect_bgn, $tmpdeffect_end;
       if(SQLCODE == SQLNOTFOUND) break;
       cnt = cnt + 1;    
    }
    $CLOSE proc_acur;

  }

  if (cnt != 0) {
    $COMMIT WORK;
    if(exitsub(reply,M_CA_NPERIOD) == True)       
       return M_CA_NPERIOD;                      
    else
       return apiRC;
  }

  for(j=0;j<i;j++)
  {
     sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO %s:ca_rate_renew "
                              " (icode, deffect_bgn, deffect_end, fcard_class, "
                              " code_flag, icode1, icode2, icode3, iym_bgn, iym_end,icreate,dcreate,iupdate,dupdate ) "
	               " VALUES (?,?,?,?,?,?,?,?,?,?,?,current year to second,?,current year to second)",list[j].dbname);

     $PREPARE a_id FROM $stmt_buf;
     if(SQLCODE != 0)
     {
        is_add_fail = 1;
        break;
     }
     $EXECUTE a_id USING $icode, $deffect_bgn, $deffect_end, $fcard_class, 
     			$code_flag, $icode1, $icode2, $icode3, $iym_bgn, $iym_end,
     			$user,$user;
     if(SQLCODE != 0)
     {
        is_add_fail = 1;
        break;
     }
     cm_buf_init(ReplyBuf);
     cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
     tmp_len = cm_buf_len(ReplyBuf);
     if( j == i-1 )
         api_f = api_OKComplete;
     else
         api_f = api_OK;

     if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
     {
        is_add_fail = 2;
        break;
     }  

#ifdef DEBUG
printf("Insert %d\n", j+1);
#endif

  } /* for loop */

  if( is_add_fail == 1 ) goto errexit;

  if( is_add_fail == 2 ) 
  {
     $ROLLBACK WORK;
     return apiRC;
  }


  $WHENEVER SQLERROR GOTO errexit;

  $COMMIT WORK;
  return api_OKComplete;

errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,MsgCode) ==	True)
     return SQLCODE;
   else
     return apiRC;
}

long car128_single_query(reply)
serverReply reply;
{
  $char DBName[5], icode[4], code_flag[2], fcard_class[2];
  $char deffect_bgn[11],deffect_end[11];
  $char strdeffect_bgn[11],strdeffect_end[11];
  $int  iym_bgn, iym_end;
  $char icode1[4],icode2[4],icode3[4];
  $char icreate[10],dcreate[20],iupdate[10],dupdate[20];

  int tmp_len;

  cm_buf_get("%s %s %s %s %s %d %d",DBName, strdeffect_bgn, strdeffect_end,
  			fcard_class, icode, &iym_bgn, &iym_end);
  			

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
     if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
       return M_CM_DB_NOTOPEN;
     else
       return apiRC;
  }
  
  strcpy(deffect_bgn,cm_to_infdate(strdeffect_bgn));
  strcpy(deffect_end,cm_to_infdate(strdeffect_end));
  
  $SELECT code_flag, icode1, icode2, icode3,icreate,dcreate,iupdate,dupdate
     INTO $code_flag, $icode1, $icode2, $icode3,$icreate,$dcreate,$iupdate,$dupdate
     FROM ca_rate_renew
    WHERE deffect_bgn = $deffect_bgn
      And deffect_end = $deffect_end
      AND fcard_class = $fcard_class
      AND icode = $icode
      AND iym_bgn = $iym_bgn
      AND iym_end = $iym_end;
     
  if(SQLCODE==SQLNOTFOUND)
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)       /*?*/
      return M_CM_NOT_FOUND;                        /*?*/
    else
      return apiRC;
  }
  
  /* Convert Era Date to Chinese Date */
     strcpy(strdeffect_bgn, cm_from_infdate(deffect_bgn));
     strcpy(strdeffect_end, cm_from_infdate(deffect_end));

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s %s %s %s %s %s %s %d %d %s %s %s %s",M_CM_OK, strdeffect_bgn, strdeffect_end,
  		icode, code_flag, fcard_class, icode1, icode2, icode3, iym_bgn, iym_end,
  		icreate, dcreate, iupdate, dupdate);
  tmp_len = cm_buf_len(ReplyBuf);
  if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car128_multiple_query(reply)
serverReply reply;
{
  $char DBName[5], icode[4], fcard_class[2];
  $char strdeffect_bgn[11],strdeffect_end[11];
  $char deffect_bgn[11],deffect_end[11];
  $int  iym_bgn = 0, iym_end = 0;

  char tmpbuf[4000];
  int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
  int i,total_count=0;

  cm_buf_get("%s %s %s",DBName, strdeffect_bgn, strdeffect_end);
  
  strcpy(deffect_bgn,cm_to_infdate(strdeffect_bgn));
  strcpy(deffect_end,cm_to_infdate(strdeffect_end));
  
  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  $DECLARE q_cur CURSOR FOR
    SELECT deffect_bgn, deffect_end, icode, fcard_class,  iym_bgn,  iym_end 
      INTO $deffect_bgn, $deffect_end, $icode, $fcard_class, $iym_bgn, $iym_end
      FROM ca_rate_renew
     WHERE (deffect_bgn BETWEEN $deffect_bgn AND $deffect_end)
        OR (deffect_end BETWEEN $deffect_bgn And $deffect_end)
     ORDER BY deffect_bgn, deffect_end, fcard_class;

  $OPEN q_cur;

  for(;;)
  {
     $FETCH q_cur;
     if (SQLCODE != 0) break;

     cm_buf_init(tmpbuf);
     if ( count == 0 )
     {
       cm_buf_res_msg();             /* reserve for MsgCode and count */
       cm_buf_res_count();
     }
     
     /* Convert Era Date to Chinese Date */
     strcpy(strdeffect_bgn, cm_from_infdate(deffect_bgn));
     strcpy(strdeffect_end, cm_from_infdate(deffect_end));
     
     cm_buf_put("%s %s %s %s %d %d ", strdeffect_bgn, strdeffect_end, 
     		fcard_class, icode, iym_bgn, iym_end);
     tmp_len = cm_buf_len(tmpbuf);
     if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
       memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
       repbuf_len += tmp_len;
       count++;
     }
     else                               /* more than 4K, send to client side */
     {
       cm_buf_init(ReplyBuf);
       cm_buf_put_msg(M_CM_OK);
       cm_buf_put_count(count);
       if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
         $CLOSE q_cur;
         return apiRC;
       }
       else               /* clear ReplyBuf and count to start all over again */
       {
         replycnt++;
         if (replycnt == 10)   /* more than 30K, client cannot display,error */
         {
           cm_buf_init(ReplyBuf);
           cm_buf_put("%l",M_CM_OUT_SPACE);
           tmp_len = cm_buf_len(ReplyBuf);
           if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
               return apiRC;
           return M_CM_OUT_SPACE;
         }
         ReplyBuf[0] = '\0';
         count = 0;
         cm_buf_init(ReplyBuf);
         cm_buf_res_msg();           /* reserve for MsgCode and count */
         cm_buf_res_count();
         cm_buf_put("%s %s %s %s %d %d ", strdeffect_bgn, strdeffect_end, 
     		fcard_class, icode, iym_bgn, iym_end);
         repbuf_len = cm_buf_len(ReplyBuf);
         count++;
       }
     }
  } /* for loop */

  $CLOSE q_cur;
  if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
  else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

errexit:
   if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
   else
     return apiRC;
}

long car128_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
  $char DBName[5], icode[4], code_flag[2], fcard_class[2];
  $char deffect_bgn[11],deffect_end[11];
  $char sdeffect_bgn[11],sdeffect_end[11];
  $int  iym_bgn, iym_end;
  $char icode1[4],icode2[4],icode3[4];
  
  $char old_icode[4],old_deffect_bgn[11],old_deffect_end[11];
  $char old_sdeffect_bgn[11],old_sdeffect_end[11];
  $char old_icode1[4],old_icode2[4],old_icode3[4];
  $char old_fcard_class[2], old_flag[2];
  $int  old_iym_bgn, old_iym_end, count = 0;
  $char icreate[10],dcreate[20],iupdate[10],dupdate[20];
  $char old_icreate[10],old_dcreate[20],old_iupdate[10],old_dupdate[20],user[11];
  char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
   int tmp_len,raw_len;
  long dummy;
  long MsgCode;
  DBinfo *list;
   int i, j, is_del_fail=0, is_upd_fail=0;
  $char stmt_buf[1024];

  comm = (char *) command;
  cm_buf_init(command);
  cm_buf_get("%c %s",&option,DBName);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
    if(exitsub(reply,M_CM_NOT_DBLIST) == True)
      return M_CM_NOT_DBLIST;
    return apiRC;
  }
  
  /* compare old record and current record, if the record has not been changed
     since last request, update or delete the record, otherwise return errmsg
     to client side */

  /* get old record info from command buffer */

  /*
     raw_len = *(int *) &comm[com_len];
     memcpy(&raw_len,(void *)&command[com_len],sizeof(int));
  */
 
  memcpy(&raw_len,&comm[com_len],sizeof(int));
  pos = &comm[com_len+sizeof(int)];
  raw_ptr = malloc(raw_len);
  if (raw_ptr != (char*)0)
     memcpy(raw_ptr,pos,raw_len);
  else
  {
    if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
       return M_CM_NOT_MALLOC;
    else
      return apiRC;
  }

  cm_buf_init(raw_ptr);          /* get index key from old record */
  cm_buf_get("%l %s %s %s %s %s %s %s %s %d %d %s %s %s %s",&dummy, old_sdeffect_bgn, old_sdeffect_end, old_icode, 
  			old_flag, old_fcard_class, old_icode1, old_icode2, old_icode3,
  			&old_iym_bgn, &old_iym_end,old_icreate,old_dcreate,old_iupdate,old_dupdate);
  			
  strcpy(old_deffect_bgn,cm_to_infdate(old_sdeffect_bgn));
  strcpy(old_deffect_end,cm_to_infdate(old_sdeffect_end));
  free(raw_ptr);
  printf("1.\n");  
   $SELECT dupdate
          INTO $dupdate
          FROM ca_rate_renew
	  WHERE deffect_bgn = $old_deffect_bgn 
	  AND deffect_end = $old_deffect_end
	  AND fcard_class = $old_fcard_class
	  AND icode = $old_icode
	  AND iym_bgn = $old_iym_bgn
	  AND iym_end = $old_iym_end;
	  
  if (strcmp(old_dupdate,dupdate) != 0)
 {
    if(exitsub(reply,M_CM_NOT_EQUAL) == True)
	return M_CM_NOT_EQUAL;/*��Ƥ��۵�*/
    else
	return apiRC;
 } 
 
 printf("old_dupdate[%s],dupdate[%s]\n",old_dupdate,dupdate);
 
$BEGIN WORK;
  printf("3.\n");  
  if ( option == 'D' )
  {
     for(j=0;j<i;j++)
     {
        sprintf_s(stmt_buf, sizeof stmt_buf, "DELETE FROM %s:ca_rate_renew "
    	        " WHERE deffect_bgn=? AND deffect_end=? "
    	        " AND icode = ? AND fcard_class = ? " ,list[j].dbname); 
        $PREPARE d_id FROM $stmt_buf;
        if(SQLCODE != 0)
        {
           is_del_fail = 1; 
           break;
        }
        $EXECUTE d_id USING $old_deffect_bgn, $old_deffect_end, $old_icode, $old_fcard_class;
        if(SQLCODE != 0)
        {
           is_del_fail = 1; 
           break;
        }
        #ifdef DEBUG
        printf("Delete %d\n", j+1);
        #endif
     }/* for loop */

     if( is_del_fail ) goto errexit;
   
     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     tmp_len = cm_buf_len(ReplyBuf);
     if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
     {
       $WHENEVER SQLERROR CONTINUE;
       $ROLLBACK WORK;
       return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     $COMMIT WORK;
     return api_OKComplete;
  }
  else if (option == 'U')
  {
     cm_buf_init(command);
     cm_buf_get("%c %s %s %s %s %s %s %s %s %s %d %d %s",&option, DBName, sdeffect_bgn, 
     		 sdeffect_end, icode, code_flag, fcard_class, icode1, icode2, icode3,
     		 &iym_bgn, &iym_end,user);
     		 
     strcpy(deffect_bgn,cm_to_infdate(sdeffect_bgn));
     strcpy(deffect_end,cm_to_infdate(sdeffect_end));
     
     if (strcmp(old_deffect_bgn,deffect_bgn) != 0 || strcmp(old_deffect_end,deffect_end) != 0 ||
     		strcmp(old_fcard_class,fcard_class) != 0 || strcmp(old_icode,icode) != 0)
     	{
     	    /* Check if index exists or not */
       		$SELECT count(*)
          	INTO $count
          	FROM ca_rate_renew
         	WHERE icode = $icode
         	AND fcard_class = $fcard_class
         	AND deffect_bgn between $deffect_bgn and $deffect_end
         	AND deffect_end between $deffect_bgn and $deffect_end;
         
       		if (count != 0) {
			printf("data exists!!\n");
    			$COMMIT WORK;
       			if(exitsub(reply,M_CA_NPERIOD) == True)       
       		    		return M_CA_NPERIOD;                      
       			else
       		    		return apiRC;
       		}
       		/* End of Checking */
       	}  

     $WHENEVER SQLERROR CONTINUE;
     for(j=0;j<i;j++)
     {
        sprintf_s(stmt_buf, sizeof stmt_buf, "UPDATE %s:ca_rate_renew "
   	         " SET (icode, deffect_bgn, deffect_end, iym_bgn, iym_end, "
   	         "    fcard_class, code_flag, icode1, icode2, icode3, iupdate, dupdate) "
	         " = (?,?,?,?,?,?,?,?,?,?,?,current year to second) WHERE deffect_bgn = ? AND deffect_end = ? "
	         "  AND fcard_class = ? AND icode = ?",list[j].dbname);

        $PREPARE u_id FROM $stmt_buf;
        if(SQLCODE != 0)
        {
           is_upd_fail = 1;
           break;
        }
        $EXECUTE u_id USING $icode, $deffect_bgn, $deffect_end, $iym_bgn, $iym_end,
        		    $fcard_class, $code_flag, $icode1, $icode2, $icode3,$user,
        		    $old_deffect_bgn, $old_deffect_end, $old_fcard_class, $old_icode;
        if(SQLCODE != 0)
        {
           is_upd_fail = 1;
           break;
        }
        
#ifdef DEBUG
printf("Update %d\n", j+1);
#endif
     } /* for loop */

     if( is_upd_fail ) goto errexit;

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     puts("test1");
     tmp_len = cm_buf_len(ReplyBuf);
     puts("test2");
     if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
     {
     	puts("test3");
       $WHENEVER SQLERROR CONTINUE;
       $ROLLBACK WORK;
       return apiRC;
     }
     puts("test4");
     $WHENEVER SQLERROR GOTO errexit;
     $COMMIT WORK;
     return api_OKComplete;
  }
  else
  {
     MsgCode = M_CM_WRONG_OPTION;
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     if (SQLCODE != 0) MsgCode = SQLCODE;		/* rollback fail */
     if(exitsub(reply,MsgCode) ==	True)
       return MsgCode;
     else
       return apiRC;
  }

errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if (SQLCODE != 0) MsgCode = SQLCODE;		/* rollback fail */
   if(exitsub(reply,MsgCode) ==	True)
     return MsgCode;
   else
     return apiRC;
}


/******************************************************/
/*  Check irate Validation                            */
/******************************************************/
long car128_check_rate(reply)
serverReply reply;
{
   /* variables using for db */
   $char DBName[DBNAME];
   $char fcard_class[2], icode[4];
   $int count = 0;
   /* variables using for db ends */
   
   /* Local variables */
   int tmp_len;
   long MsgCode;
   /* Local variables ends */

   cm_buf_get("%s %s %s", DBName, fcard_class, icode);
   
   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
      {
      if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
         return M_CM_DB_NOTOPEN;
      else
         return apiRC;
      }

       $SELECT count(*)
          INTO $count
          FROM ca_rate_renew
         WHERE icode = $icode
         AND fcard_class = $fcard_class;
         
     if (count > 0) 
       MsgCode = M_CM_OK;
     else
       MsgCode = M_CA_NRATE;    

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l", MsgCode);
   tmp_len = cm_buf_len(ReplyBuf);
   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False) 
      return apiRC;
    else 
      return api_OKComplete;

errexit:
   if (exitsub(reply,SQLCODE) == True)
      return SQLCODE;
   else
      return apiRC;
}
