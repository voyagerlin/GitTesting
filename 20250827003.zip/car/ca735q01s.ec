#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "safeclib.h"


extern char RPTDIR[];

$char dbgn1[11], dend1[11];

$char DBName[05], FormTp[03], sMsg[256];
char  outputf[N_FILE+1], userid[06];

static int max_cnt=0;
DBinfo  *list;
int     count_db;

long car735_build();
long car735_detail();

/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;

   batchinit();
   strcpy(DBName,  isNULLstr(argv[1]));
   strcpy(userid,  isNULLstr(argv[2]));
   strcpy(dbgn1,   isNULLstr(argv[3]));
   strcpy(dend1,   isNULLstr(argv[4]));
   strcpy(outputf, isNULLstr(argv[5]));

   rc = car735_build();
  
   if (rc != M_CM_OK) 
   {
       EWRITE(userid, rc, sMsg);
       return rc;
   }
   if ((rc=save_form_info(F_FREE, "CA", 735, userid, FormTp, max_cnt, outputf))<0)
       EWRITE(userid, rc, "save_form_info failed");
}

/*----------------------------------------------------------------------------*/
long car735_build()
{
   $char  FormFmt[N_FILE+1];
   $int   StartRow, TitleRow, TotColumn, PgLine, Width;

   char   FormFile[N_FILE+1];
   int    i, rc;

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False) {
      sprintf_s(sMsg, sizeof sMsg, "[%s],��Ʈw�L�k�}��\n", DBName);
      return M_CM_DB_NOTOPEN;
   }
   if ( ( list = get_db_list(&count_db, DBName)) == (char*)0 )
   {
       sprintf_s(sMsg, sizeof sMsg, "Cannot get DB LIST \n");
       return M_CM_NOT_DBLIST;
   }

   $SELECT nForm_File, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $FormFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 735;
   strcpy(FormFmt, rtrim(FormFmt));
   sprintf_s(FormFile, sizeof FormFile, "%s.tx", outputf);

   rc = car735_get_data();

   if (rc != M_CM_OK)
      return rc;

   /* build report */
   rgu_init_report(FormFmt, FormFile);
   rc = car735_detail();
   if (rc != M_CM_OK)
      return rc;
   rgu_finish_report();

   if (max_cnt == 0) {
      sprintf_s(sMsg, sizeof sMsg, "��Ƨ䤣��\n");
      return M_CM_NOT_FOUND;
   }

   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return FAIL;
}
/*----------------------------------------------------------------------------*/
long car735_get_data()
{
   $char stmt[10240], sql[1224];
   $int  i;
   $char nclass[21], ientry[11], nname[11], iquota[11], nbranch[21];
   $char fcard_class[2],iofficer[11], nrenew[5], itmp_policy[21];
   $long icount = 0;


   $WHENEVER SQLERROR GOTO errexit;

   /****************************** �n���H����Ʋέp ******************************/
   $CREATE TEMP TABLE t735a
   (
      nclass        char(20),
      ientry        char(10),
      nname         char(10),
      iquota        char(10),
      nbranch       char(20),
      icount        int 
   )with no log;

   stmt[0] = '\0';
   /* �M�ץ�P�_�s�WH�g����ư�H0-H2  modify by sylvia 102.12.12 (1021122001_C1)
                �s�WN�g��A�~�Ȩӷ���E (1030630002_C4) */
   for (i=0;i<count_db;i++)
   {
       sprintf_s(sql, sizeof sql, "SELECT CASE WHEN a.iofficer[1] = 'W' then '�M�ץ�O��' "
                     "            when a.iofficer[1,1] = 'H' and a.iofficer[2,2] not in ('0','1','2') then '�M�ץ�O��' "
                     "            when a.iofficer[1,1] = 'N' and a.iresource = 'E' then '�M�ץ�O��' "
                     "       else '�D�M�ץ�O��' end, a.ientry, b.nname, b.iquota, c.nbranch, count(*) "
      		     "  FROM %s:ply_relation a, officer b, sa_branch_type c "
		     " WHERE a.dpolicy between '%s' AND '%s' "
		     "   AND a.ientry = b.iofficer"
                     "   AND b.iquota = c.ibranch"
		     "   AND a.dply_close is not null"
                     " GROUP BY 1,2,3,4,5 "
                     " UNION \n "
                     "SELECT '���', a.iedr_examiner, b.nname, b.iquota, c.nbranch, count(*) "
      		     "  FROM %s:edr_relation a, officer b, sa_branch_type c "
		     " WHERE a.dendorse between '%s' AND '%s' "
		     "   AND a.iedr_examiner = b.iofficer"
                     "   AND b.iquota = c.ibranch"
		     "   AND a.dedr_close is not null"
                     " GROUP BY 1,2,3,4,5 "
                     , list[i].dbname, dbgn1, dend1
                     , list[i].dbname, dbgn1, dend1);
       if( i!=count_db-1) strcat( sql, " union \n");
       strcat( stmt, sql);
   }

   printf("stmt[%s]\n", stmt);

   $PREPARE prep1 FROM $stmt;
   $DECLARE curs1 CURSOR FOR prep1;
   $OPEN curs1;
   while(1)
   {
       $FETCH curs1 INTO $nclass, $ientry, $nname, $iquota, $nbranch, $icount;
       if(SQLCODE == SQLNOTFOUND) break;
       $INSERT INTO t735a VALUES ( $nclass, $ientry, $nname, $iquota, $nbranch, $icount);
   }
   $FREE prep1;
   $CLOSE curs1;
   $FREE curs1;

   /****************************** �O���Ʋέp�]���tW�}�Y�g��N���^***************************** */
   $CREATE TEMP TABLE t735b
   (
      iquota        char(2),
      nbranch       char(20),
      nclass        char(20),
      icount        int
   )with no log;

   stmt[0] = '\0';
   /* �M�ץ�P�_�s�WH�g����ư�H0-H2  modify by sylvia 102.12.12 (1021122001_C1)
                �s�WN�g��A�~�Ȩӷ���E (1030630002_C4) */
   for (i=0;i<count_db;i++)
   {
       sprintf_s(sql, sizeof sql, "SELECT a.fcard_class, a.iofficer, a.ipolicy[1,2], "
                     "       case when nvl(ilast_ply,'')='' then '�s�O' else '��O' end, "
                     "       a.itmp_policy "
      		     "  FROM %s:ply_relation a"
		     " WHERE a.dpolicy between '%s' AND '%s' "
		     "   AND a.dply_close is not null"
                     "   AND ( (a.iofficer[1] != 'W') and  "
                     "        not (a.iofficer[1,1] = 'H' and iofficer[2,2] not in ('0','1','2')) and "
                     "        not (a.iofficer[1,1] = 'N' and a.iresource = 'E')) "
                     , list[i].dbname, dbgn1, dend1);

       printf("sql[%s]\n", sql);

       $PREPARE prep2 FROM $sql;
       $DECLARE curs2 CURSOR FOR prep2;
       $OPEN curs2;
       while(1)
       {
           $FETCH curs2 INTO $fcard_class, $iofficer, $iquota, $nrenew, $itmp_policy;
           if(SQLCODE == SQLNOTFOUND) break;
           if( iofficer[0] == 'B' || iofficer[0] == 'J')
           {
               if( fcard_class[0] == '1')
                   sprintf_s(nclass, sizeof nclass, "B2B�j���I");
               else
                   sprintf_s(nclass, sizeof nclass, "B2B/B2C���N�I");
           }
           else if( strncmp( itmp_policy, "17N", 3) == 0)
           {
               if( fcard_class[0] == '1')
                   sprintf_s(nclass, sizeof nclass, "B2C�j���I");
               else
                   sprintf_s(nclass, sizeof nclass, "B2B/B2C���N�I");
           }
           else
           {
               if( fcard_class[0] == '1')
                   sprintf_s(nclass, sizeof nclass, "�@��j���I%s", nrenew);
               else
                   sprintf_s(nclass, sizeof nclass, "�@����N�I%s", nrenew);
           }
           $SELECT nchi_full
              INTO $nbranch
              FROM branch
             WHERE ibranch = $iquota;
    
           if(SQLCODE == SQLNOTFOUND)
               strcpy( nbranch, " ");
    
           $INSERT INTO t735b VALUES ( $iquota, $nbranch, $nclass, 1);
       }
   }
   $FREE prep2;
   $CLOSE curs2;
   $FREE curs2;

   return M_CM_OK;

errexit:
   sprintf_s(sMsg, sizeof sMsg, "car735_get_data:SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   printf("[%s]\n", sMsg);
   return SQLCODE;
}

/*----------------------------------------------------------------------------*/
long car735_detail()
{
   $char nclass[21], ientry[11], nname[11], iquota[11], nbranch[21];
   $char tmp_buf[21];
   $long icount = 0;

   /****************************** �n���H����Ʋέp ***************************** */
   rgu_put_body_string(1, dbgn1 ,1);
   rgu_put_body_string(1, dend1 ,1);
   rgu_put_body_string(1, cm_sysd_edatetime(cm_sysd_cdatetime_100(cm_get_sysd())));
   rgu_put_body(1); max_cnt += 3; 
   rgu_put_body(2); max_cnt += 3;  /* ���W�� */

   $WHENEVER SQLERROR GOTO errexit;
   $DECLARE cursor CURSOR FOR
     SELECT nclass, ientry, nname, iquota, nbranch, SUM(icount)
       FROM t735a
      GROUP BY 1,2,3,4,5
      ORDER BY iquota,ientry, nclass, ientry;

   $OPEN cursor;
   while(1)
    {
       $FETCH cursor INTO $nclass, $ientry, $nname, $iquota, $nbranch, $icount;
       if(SQLCODE == SQLNOTFOUND) break;

       rgu_put_body_string(3, nclass, 1);
       rgu_put_body_string(3, ientry, 1);
       rgu_put_body_string(3, nname, 1);
       rgu_put_body_string(3, iquota, 1);
       rgu_put_body_string(3, nbranch, 1);
       rfmtlong( icount, "------&", tmp_buf);
       rgu_put_body_string(3, tmp_buf, 2);
       rgu_put_body(3); max_cnt++;
    }
    $CLOSE cursor;
    $FREE  cursor;

   /****************************** �O���Ʋέp ***************************** */
   rgu_put_body(4); max_cnt += 1; 
   rgu_put_body(5); max_cnt += 3;  /* ���W�� */

   $WHENEVER SQLERROR GOTO errexit;
   $DECLARE curs3 CURSOR FOR
     SELECT iquota, nbranch, nclass, SUM(icount)
       FROM t735b
      GROUP BY 1,2,3
      ORDER BY 1,2,3;

   $OPEN curs3;
   while(1)
    {
       $FETCH curs3 INTO $iquota, $nbranch, $nclass, $icount;
       if(SQLCODE == SQLNOTFOUND) break;

       sprintf_s(tmp_buf, sizeof tmp_buf, "'%s", iquota);
       rgu_put_body_string(6, tmp_buf, 2);
       rgu_put_body_string(6, nbranch, 1);
       rgu_put_body_string(6, nclass, 1);
       rfmtlong( icount, "------&", tmp_buf);
       rgu_put_body_string(6, tmp_buf, 2);
       rgu_put_body(6); max_cnt++;
    }
    $CLOSE curs3;
    $FREE  curs3;
    return M_CM_OK;
   
errexit:
   sprintf_s(sMsg, sizeof sMsg, "car735_detail:SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   printf("[%s]\n", sMsg);
   return SQLCODE;
}
/*----------------------------------------------------------------------------*/
