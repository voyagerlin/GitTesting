/*                                                 */
/*      PROGRAM : sa_car_quota.ec                  */
/*      Date    : 01/21/1999                       */
/***************************************************/
#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
$char outputf[21];
/************************************************************************/
main(argc, argv)
int argc;
char **argv;
{
   int rc;
   char sIdbname[DBNAME];
   char sDpolicy[YYYYMMDD];

   strcpy(sIdbname, isNULLstr(argv[1]));
   strcpy(sDpolicy, isNULLstr(argv[2]));
   /*---------------------------------------------*/
   if ((strlen(rtrim(sDpolicy))) == 0) strcpy(sDpolicy, "*");
   if ((rc=car_quota_build(sIdbname, sDpolicy)) == M_CM_OK)
      printf("------> PROGRAM COMPLETE------>\n");
}
/**************************************************************************/
long car_quota_build(sIdbname, spDpolicy)
char *sIdbname, *spDpolicy;
{
   $char  sIofficer[EMPLOYEE_ID], sDpolicy[YYYYMMDD];
   $char  sIissue_ym[YYMMDD], sFclass[2], sFnew[2], sFtype[2], sIcar_type[3];
   $char  sIbigcomp[2], sIpolicy[POLICY_NUM_1];
   $long  lDply_begin;
   $long  q01,q05,q06,q99,q11,q31,q51,q21,qpolicy;
   $long  m01,m05,m06,m99,m11,m31,m51,m21,mpolicy;
  $short  iId;
    long  lTmp_iissue_ym;
    long  iRtnCode;

   if (db_select(sIdbname) == False) return M_CM_DB_NOTOPEN;

   $WHENEVER SQLERROR GOTO errexit;

   $DECLARE PLY_REL_CUR CURSOR FOR 
     SELECT iofficer, dpolicy, iissue_ym, dply_begin,
            fcard_class, icar_type, ibig_comp, ipolicy,
            (mdmg_prem+mlia_prem)
       FROM ori_ply_relation  
      ORDER BY iofficer;
   $OPEN PLY_REL_CUR;


   while(1)
   {
     $FETCH PLY_REL_CUR INTO $sIofficer, $sDpolicy, $sIissue_ym, $lDply_begin,
                             $sFclass, $sIcar_type, $sIbigcomp, 
                             $sIpolicy, $mpolicy;
     if (SQLCODE == SQLNOTFOUND) break;
     strcpy(sIissue_ym, rtrim(sIissue_ym));
     strcat(sIissue_ym, "/01");


     if ((iRtnCode =
          rstrdate(cm_to_infdate(sIissue_ym), &lTmp_iissue_ym)) != 0);
        lTmp_iissue_ym=0;
     if (lDply_begin < lTmp_iissue_ym) strcpy(sFnew, "1");
     else strcpy(sFnew, "0");

     if (strcmp(sIcar_type, "01") == 0 || strcmp(sIcar_type, "02") == 0)
        strcpy(sFtype, "2");
     else strcpy(sFtype, "1");

     /*�Ҧ����lñ����*/
     $SELECT COUNT(*) 
        INTO $q01:iId
        FROM ori_ins_type 
       WHERE ipolicy=$sIpolicy
         AND iins_type="01";
     if (iId == -1) q01=0;

     /*�Ҧ����lñ��O�O*/
     $SELECT SUM(a.mins_premium)
        INTO $m01:iId
        FROM ori_ins_type a, insurance_type b
       WHERE a.iins_type=b.iins_type
         AND a.ipolicy=$sIpolicy
         AND b.imain_ins="01";
     if (iId == -1) m01=0;

     /*�A�����lñ����*/
     $SELECT COUNT(*) 
        INTO $q05:iId
        FROM ori_ins_type 
       WHERE ipolicy=$sIpolicy
         AND iins_type="05";
     if (iId == -1) q05=0;

     /*�A�����lñ��O�O*/
     $SELECT SUM(a.mins_premium)
        INTO $m05:iId
        FROM ori_ins_type a, insurance_type b
       WHERE a.iins_type=b.iins_type
         AND a.ipolicy=$sIpolicy
         AND b.imain_ins="05";
     if (iId == -1) m05=0;

     /*�������lñ����*/
     $SELECT COUNT(*) 
        INTO $q06:iId
        FROM ori_ins_type 
       WHERE ipolicy=$sIpolicy
         AND iins_type="06";
     if (iId == -1) q06=0;

     /*�������lñ��O�O*/
     $SELECT SUM(a.mins_premium)
        INTO $m06:iId
        FROM ori_ins_type a, insurance_type b
       WHERE a.iins_type=b.iins_type
         AND a.ipolicy=$sIpolicy
         AND b.imain_ins="06";
     if (iId == -1) m06=0;
     
     q99=0; m99=0;   /*�Ȯɿ�J0*/


     /*�ѵs�Iñ����*/
     $SELECT COUNT(*) 
        INTO $q11:iId
        FROM ori_ins_type 
       WHERE ipolicy=$sIpolicy
         AND iins_type="11";
     if (iId == -1) q11=0;

     /*�ѵs�Iñ��O�O*/
     $SELECT SUM(a.mins_premium)
        INTO $m11:iId
        FROM ori_ins_type a, insurance_type b
       WHERE a.iins_type=b.iins_type
         AND a.ipolicy=$sIpolicy
         AND b.imain_ins="11";
     if (iId == -1) m11=0;

     /*���N�T�dñ����*/
     $SELECT COUNT(*) 
        INTO $q31:iId
        FROM ori_ins_type 
       WHERE ipolicy=$sIpolicy
         AND iins_type="31";
     if (iId == -1) q31=0;

     /*���N�T�dñ��O�O*/
     $SELECT SUM(a.mins_premium)
        INTO $m31:iId
        FROM ori_ins_type a, insurance_type b
       WHERE a.iins_type=b.iins_type
         AND a.ipolicy=$sIpolicy
         AND b.imain_ins IN ("31", "32");
     if (iId == -1) m31=0;

     /*�����Iñ����*/
     $SELECT COUNT(*) 
        INTO $q51:iId
        FROM ori_ins_type 
       WHERE ipolicy=$sIpolicy
         AND iins_type="51";
     if (iId == -1) q51=0;

     /*�����Iñ��O�O*/
     $SELECT SUM(a.mins_premium)
        INTO $m51:iId
        FROM ori_ins_type a, insurance_type b
       WHERE a.iins_type=b.iins_type
         AND a.ipolicy=$sIpolicy
         AND b.imain_ins IN ("51", "53");
     if (iId == -1) m51=0;

     /*�j��T�dñ����*/
     $SELECT COUNT(*) 
        INTO $q21:iId
        FROM ori_ins_type 
       WHERE ipolicy=$sIpolicy
         AND iins_type="21";
     if (iId == -1) q21=0;

     /*���N�T�dñ��O�O*/
     $SELECT SUM(a.mins_premium)
        INTO $m21:iId
        FROM ori_ins_type a, insurance_type b
       WHERE a.iins_type=b.iins_type
         AND a.ipolicy=$sIpolicy
         AND b.imain_ins="21";
     if (iId == -1) m21=0;


     $UPDATE sa_car_quota
         SET q01=q01+$q01, m01=m01+$m01, q05=q05+$q05, m05=m05+$m05,
             q06=q06+$q06, m06=m06+$m06, q99=q99+$q99, m99=m99+$m99,
             q11=q11+$q11, m11=m11+$m11, q31=q31+$q31, m31=m31+$m31,
             q51=q51+$q51, m51=m51+$m51, q21=q21+$q21, m21=m21+$m21,
             qpolicy=qpolicy+1, mpolicy=mpolicy+$mpolicy
       WHERE iofficer=$sIofficer 
         AND Dpolicy=$sDpolicy
         AND Fnew=$sFnew
         AND Ftype=$sFtype
         AND Fclass=$sFclass;


     if (sqlca.sqlerrd[2] == 0)
        $INSERT INTO sa_car_quota VALUES
                ($sIofficer, $sDpolicy, 1, $mpolicy,
                 $q01, $m01, $q05, $m05, $q06, $m06, $q99, $m99, $q11, $m11,
                 $q31, $m31, $q51, $m51, $q21, $m21, $sFnew, $sFclass,
                 $sFtype, $sIbigcomp);

                   
   }
   $CLOSE PLY_REL_CUR;
   $FREE PLY_REL_CUR;
   
   return M_CM_OK;

errexit:
   printf("sa_car_quota: SQLCODE[%ld], err[%s]\n", SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

