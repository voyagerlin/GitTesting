/************************************************/
/*                                              */
/*   PROGRAM : car115.ec
/*                                              */
/************************************************/
     
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include "safeclib.h"

long car115(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car115_insert(),car115_single_query(),car115_multiple_query(),car115_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
	   rtncode=car115_insert(reply);
	   break;
  case 'Q':
	   rtncode=car115_single_query(reply);
	   break;
  case 'M':
           rtncode=car115_multiple_query(reply);
	   break;
  case 'D':
  case 'U':
	   rtncode=car115_update_exec(reply,command,com_len);
	   break;
  default :
	   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
	    return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

long car115_insert(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table adjustment_code */
 $char class,code[4],descrip[41],abbr[13];
 $char key_class,old_class;
 /* end of adjustment_code */

 /* standard defined data */
 int tmp_len;
   DBinfo *list;
   int i, j, is_add_fail=0, api_f;
   $char stmt_buf[300];
 /* end of standard data */

 /* self defined data */
 long MsgCode;
 /* end of self data */

 cm_buf_get("%s",DBName);
 cm_buf_get("%c %s %s %s",&class,code,descrip,abbr);

 if (db_select(DBName) == False) 
  { 
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }
 
 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }

 $BEGIN WORK;
 for(j=0;j<i;j++)
 {
  sprintf_s(stmt_buf,300,"INSERT INTO %s:adjustment_code \
		   (fclass,icode,ncode,nabbr) VALUES (?,?,?,?)",
		   list[j].dbname);

  $PREPARE a_id FROM $stmt_buf;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  $EXECUTE a_id USING  $class,$code,$descrip,$abbr;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  tmp_len = cm_buf_len(ReplyBuf);
  if( j == i-1 )
     api_f = api_OKComplete;
  else
     api_f = api_OK;

  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    {
     is_add_fail = 2;
     break;
    }  
#ifdef DEBUG 
printf("INSERT %d\n", j+1);
#endif
 } /* for loop */

 if( is_add_fail == 1 ) goto errexit;

 if( is_add_fail == 2 ) 
  {
   $ROLLBACK WORK;
   return apiRC;
  }


 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

 errexit:
  $WHENEVER SQLERROR CONTINUE;    
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}

long car115_single_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table adjustment_code */
 $char class,code[4],descrip[41],abbr[13];
 $char key_class,old_class;
 /* end of adjustment_code */

 /* standard defined data */
 int tmp_len;
 /* end of standard data */

 /* self defined data */
 /* end of self data */
 cm_buf_get("%s",DBName);
 cm_buf_get("%c %s",&class,code);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

  $SELECT ncode,nabbr
  INTO $descrip, $abbr
  FROM adjustment_code
  WHERE fclass=$class AND icode=$code; 

 if(SQLCODE==SQLNOTFOUND) 
  {
   if(exitsub(reply,M_CA_NCODE) == True) 
    return M_CA_NCODE; 
   else  
    return apiRC;
  }

 cm_buf_init(ReplyBuf); 
 cm_buf_put("%l",M_CM_OK);
 cm_buf_put("%c %s %s %s",class,code,descrip,abbr);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}

long car115_multiple_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table adjustment_code */
 $char class[2],code[4],descrip[41],abbr[13];
 $char key_class,key_code[4],old_class;
 /* end of adjustment_code */

 /* standard defined data */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0; 
 /* end of standard data */

 /* self defined data */
 /* end of self data */

 cm_buf_get("%s",DBName);
 cm_buf_get("%c %s",&key_class,key_code);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 $DECLARE q_cur CURSOR FOR
  SELECT fclass,icode,ncode,nabbr
  INTO $class,$code,$descrip, $abbr
  FROM adjustment_code
  WHERE fclass matches $key_class AND icode matches $key_code
  ORDER BY fclass; 

 $OPEN q_cur;

 for(;;)
  {
    $FETCH q_cur;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf); 
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();          
     }
/*    cm_buf_put("%c %s %s %s",class,code,descrip,abbr);*/
    cm_buf_put("%c %s %s",class[0],code,abbr);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */ 
     { 
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
	$CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
	 cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE; 
        }
	ReplyBuf[0] = '\0';
	count = 0;
	cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();    
/*        cm_buf_put("%c %s %s %s",class,code,descrip,abbr);*/
        cm_buf_put("%c %s %s",class,code,abbr);
	repbuf_len = cm_buf_len(ReplyBuf);
	count++;
       }
     } 
  } /* for loop */

 $CLOSE q_cur;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CA_NCODE) == True) 
    return M_CA_NCODE;
   else  
    return apiRC;
  } 

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}


long car115_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table adjustment_code */
 $char class,code[4],descrip[41],abbr[13];
 $char key_class,old_class,old_code[4];
 /* end of adjustment_code */

 /* standard defined data */
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len;
 long dummy=0;
   DBinfo *list;
   int i, j, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[300];
 /* end of standard data */

 /* self defined data */
 long MsgCode;
 /* end of self data */

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }
 /* compare old record and current record, if the record has not been changed  
    since last request, update or delete the record, otherwise return errmsg
    to client side */

 /* get old record info from command buffer */ 

 memcpy(&raw_len,&comm[com_len],sizeof(int));   
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)  
  memcpy(raw_ptr,pos,raw_len);
 else
  {
   if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */ 
    return M_CM_NOT_MALLOC;
   else  
    return apiRC;
  }
    
 cm_buf_init(raw_ptr);          /* get index key from old record */
 cm_buf_get("%l",&dummy);
 cm_buf_get("%c %s",&old_class,old_code);

 $BEGIN WORK;                

 $SELECT ncode,nabbr
  INTO $descrip, $abbr
  FROM adjustment_code
  WHERE fclass=$old_class AND icode=$old_code; 

  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */ 

 if (SQLCODE == SQLNOTFOUND)
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CM_NOT_FOUND) == True) 
    return M_CM_NOT_FOUND;
   else  
    return apiRC;
  }

 cm_buf_init(cur_buf);
 cm_buf_put("l",dummy);
 cm_buf_put("%c %s %s %s",old_class,old_code,descrip,abbr);

 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
  {
   $ROLLBACK WORK;
   if(exitsub(reply,M_CM_NOT_EQUAL) == True) 
    return M_CM_NOT_EQUAL;
   else  
    return apiRC;
  }
  $WHENEVER SQLERROR GOTO errexit;
  
 /* equal, then exec DB operation */
	free(raw_ptr);
 if ( option == 'D' )
  {
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf,300,"DELETE FROM %s:adjustment_code WHERE fclass=? \
		     AND icode=?" ,list[j].dbname); 
    $PREPARE d_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
    $EXECUTE d_id USING $old_class,$old_code;  
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
#ifdef DEBUG 
printf("Delete %d\n", j+1);
#endif
   }/* for loop */

   if( is_del_fail ) goto errexit;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
   cm_buf_init(command);
   cm_buf_get("%c %s",&option,DBName);
   cm_buf_get("%c %s %s %s",&class,code,descrip,abbr);
                             
   $WHENEVER SQLERROR CONTINUE;
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf,300,"UPDATE %s:adjustment_code SET \
		     (fclass,icode,ncode,nabbr) = (?,?,?,?) WHERE fclass=? \
		     AND icode=?",list[j].dbname);

    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    $EXECUTE u_id USING $class,$code,$descrip,$abbr,$old_class,$old_code; 
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {
  	sprintf_s(stmt_buf,300,"INSERT INTO %s:adjustment_code \
			 (fclass,icode,ncode,nabbr) VALUES (?,?,?,?)",
			 list[j].dbname);

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }
      $EXECUTE ua_id USING $class,$code,$descrip,$abbr; 
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }
     }
#ifdef DEBUG 
printf("Update %d\n", j+1);
#endif
   } /* for loop */

   if( is_upd_fail ) goto errexit;


   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True) 
    return M_CM_WRONG_OPTION;
   else  
    return apiRC;
  } 

 errexit:
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else
    return apiRC;
}

