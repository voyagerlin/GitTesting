/*-------------------------------------------------------------------
 * Program: ca315q01s.ec
 * Date   : 03/01/2004
 *-------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include <time.h>
#include <math.h>
#include "safeclib.h"

$include datetime.h;
$include "ca3xxlib.h";
$include sqlca;
$include sqltypes;

#define  FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define  NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND

/* #define  PRINTF_FLAG;  */

/*****************************************************************/

int     checktime = 0;

$char   choice[2],bigcomp[3],nname[21],nchi_full[31],office[11];
$char   plyyear[4],plymonth[3],db[3],officer_rec[EMPLOYEE_ID];
$char   upcomp[3],pre_ply[3][20],pre_comp[3][20];
$char   dbbgn[3],dbend[3],officerbgn[11], officerend[11];
char    s_today[11], s_cur_yr[4], s_cur_mth[3];
$char   iquota_tmp[10],remark1[101],remark2[141];
$char   sfins[2];

$char   iofficer_a[11];
$char   stmt[8192],stmt_buf[1024];
$char   tmp_relative_ply[POLICY_NUM_1];
$int    t_count,ricnt;
char    lia_flag,dmg_flag;

char    err_buf[150];
$int    iplyyear,iplymonth,linnum,periodcnt;
$char   cy_type[3],cy_fpt[2];
$long   cy_qpt,man_qty,t_date;
$long   sug_qpt;
$char   iquota_tc[11];
char    inextflag[2];
$char   icar_flag[2];
$double main_discount;
$char   lia_class[3];
$int    dmg_acc_1st,dmg_acc_2nd,dmg_acc_3rd;
$int    bqdmg[3];
$date   dpolicy;
char    dmg_flag_p;
$int    iseq_tmp;
$char   dclaim_tmp[11],dprocess_tmp[11],drescue_tmp[11];
$char   qday_tmp[11];
int     itp;
$char   sclmdb[21];
$int    tmp_iym_end;
$char   renew_icode[3];

/*****************************************************************/
int     rec_count, max_count,rec_count_1=0,label1=0;
$char   DBName[5];
$char   FormTp[3];
char    outputf0[50];
char    outputf[50];
char    outputf1[50];
char    option[2];
char    userid[11];
char    opflag[2];
$int    fg1,y = 0;
int     rtcn;
$char   clmply[21],clm_db[3];
$int    clmcnt = 0 ;
int     dtlint;
$char   str_deduct[9];
$char   tmp_cIins_scope[2];
$char   tmp_cIcareer[2];

$char    sDplyEndBgn[11],sDplyEndEnd[11];
$long    lDplyEndBgn    ,lDplyEndEnd;
$int     iYY,iMM;
$char    sYY[4],sMM[3];

char    rdmg,rlia,rvkind;

/*****  unload data   *****/
$char  ripolicy[21], ricard[21], rfcard_class[2], rirelative_ply[21];
$char  rdply_end[13], riissue_ym[11], rnassured[120], ritel[14], riengine[21];
$char  ribig_comp[3], ribig_office[10], ribig_sales[11], ritag[10],riofficer[11];
$char  riassured[11], riassured_ext[3], rtphone_con[21], rimovephone[21];
$char  rnbig_sales[40], tmp_dply_end[13], tmp_iissue_ymd[13];
$long  rmprem;
char   tmp_iissue[6];
int    int_iissue;

char   sApHome[30];
FILE   *fptr;
char   prtfile[80],file[40],msgbuf[200];
char   prtstr[501], errmsg[200];

int    tot_count = 0;
/***************/
$char  dply_end_i[11];
$char  nsecond_hand[41];

/*****************************************************************/
int     sPrepare();
double  d45();
char*   splace();
long    car315_build1();
char*   get_car_full_db();
int     getdmgacc();

main(argc,argv)
int argc;
char **argv;
{
    long  src;
    char  tmpopt[2];

    strcpy(DBName   , isNULLstr(argv[1]));
    strcpy(userid   , isNULLstr(argv[2]));
    strcpy(plyyear  , isNULLstr(argv[3]));
    strcpy(plymonth , isNULLstr(argv[4]));
    strcpy(iofficer , isNULLstr(argv[5]));
    strcpy(option   , isNULLstr(argv[6]));
    strcpy(outputf  , isNULLstr(argv[7]));

    iplyyear = atoi(plyyear);
    iplyyear += 1911;
    iplymonth = atoi(plymonth);

    /***********************************************/
    /***********************************************/
    /* begin */
    sprintf_s(sDplyEndBgn, sizeof sDplyEndBgn,"%s/%s/01",plyyear,plymonth);
    lDplyEndBgn = cm_ymd_cdate(sDplyEndBgn);

    /* end   */
    if (strcmp(trim(plymonth),"12")==0)
    {
        iYY = atoi(plyyear) + 1;
        strcpy(sYY, itoa(iYY));
        sprintf_s(sDplyEndEnd, sizeof sDplyEndEnd,"%s/01/01",sYY);
    }
    else
    {
        iMM = atoi(plymonth) + 1;
        strcpy(sMM, itoa(iMM));
        sprintf_s(sDplyEndEnd, sizeof sDplyEndEnd,"%s/%s/01",plyyear,sMM);
    }
    lDplyEndEnd = cm_ymd_cdate(sDplyEndEnd)-1;

    printf("lDplyEndBgn[%ld]\n",lDplyEndBgn);
    printf("lDplyEndEnd[%ld]\n",lDplyEndEnd);

    /***********************************************/
    /***********************************************/

    src = car315_build1();
    if (src != M_CM_OK) goto errexit;

    printf("before EWRITE msgbuf=[%s]\n", msgbuf );
    printf("userid = [%s]  src = [%d]\n", userid, src );
    EWRITE(userid,src,msgbuf);

/**
    return M_CM_OK;
**/
    exit(0);

errexit:
    printf("------car315_err: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    exit(1);
}

long car315_build1()
{
    $int     PgLine,t_count;
    $char    FullDBName[20],TpDBName[20];
    $char    stmt_buf[8192],buf1[2000];
    $char    office[10];
    $char    tmp_ibig_policy[POLICY_NUM_1];
    long     rtncode;
    int      count;
    int      rc,x,rt;
    int      cur_yr, cur_mth;
    $int     big_cnt;
    char     sTmpMsg[80];
    char	 temp_ribig_office[10];
    $char     sfile_iofficer[20];
    

    long     i;
    $char    plyYYMM[6];
    $int    tmp_iym_end;
    $char   tmp_YYMM[6];

    batchinit();

    $WHENEVER SQLERROR GOTO car315_err;

    if (db_select(DBName) == False)
    {
        EWRITE(userid,M_CM_DB_NOTOPEN,DBName);
        return M_CM_DB_NOTOPEN;
    }

    strcpy(tmp_YYMM,trim(plyyear));

    if ((atoi(plymonth) >= 1) && (atoi(plymonth) <= 9))
    {
         strcat(tmp_YYMM, "0");
         strcat(tmp_YYMM, trim(plymonth));
    }
    else
    {
         strcat(tmp_YYMM, trim(plymonth));
    }

    tmp_iym_end=atoi(tmp_YYMM);

    #ifdef PRINTF_FLAG
    printf("tmp_iym_end[%d]\n",tmp_iym_end);
    #endif

    strcpy(plyYYMM, trim(tmp_YYMM));

    #ifdef PRINTF_FLAG
    printf("plyYYMM[%s]\n",plyYYMM);
    #endif

    
    /***********************************************/
    /*strcpy(officer_rec,"*");*/
    strcpy(upcomp,"*");
    strcpy(office,"*");
    /*strcpy(db,"00");
    strcpy(option,"1");
    strcpy(inextflag,"1");*/

    if (officer_rec[0]=='*')
    {
        strcpy(officerbgn," ");
        strcpy(officerend,"~");
    }
    else
    {
        strcpy(officerbgn,officer_rec);
        strcpy(officerend,officer_rec);
    }

    rtoday(&Today);     /* get today's datetime */
    strcpy(s_today,cm_cdate_str_100(Today));
    strncpy(s_cur_yr,s_today,3);
    strncpy(s_cur_mth,&s_today[4],2);
    cur_yr = atoi(s_cur_yr);
    cur_yr += 1911;
    cur_mth = atoi(s_cur_mth);

    /** �إ�Temp Table **/
    rc = sTable();
    if (rc != TRUE)
    {
        printf("sTable() FALSE \n");
        goto car315_err ;
    };
    

    printf("before sPrepare \n");
    /*  ��z���   policy -> policy_last  */
    rc = sPrepare();
    if (rc != TRUE)
    {
        printf("sPrepare() FALSE \n");
        goto car315_err ;
    };
    printf("End sPrepare \n");

    sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s WHERE %s",
                 " fins_grp ",
                 " reject_policy ",
                 " ipolicy = ? ");
    $PREPARE fins1 FROM $stmt;
    $DECLARE fins_cur CURSOR FOR fins1;

    #ifdef PRINTF_FLAG
    printf("1.----- plyyear[%s] plymonth[%s]\n",plyyear,plymonth);
    #endif

    $WHENEVER SQLERROR GOTO car315_err;
    $SET LOCK MODE TO WAIT;

    /* initialize data to blank or 0 */
    InitData();
    memset(remark1, 0x00, sizeof(remark1));
    memset(remark2, 0x00, sizeof(remark2));

    /**linnum ply_ins_type_302,policy_302 sequential�P�B ***/
    rtncode=1,rec_count=0,rec_count_1=0,linnum=0;

    rtncode = getHeadBranch(taipei_db);
    if (rtncode < 0)
    {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
    }
    strcpy(TpDBName,get_full_dbname(taipei_db));

    if (TpDBName[0]=='\0')
    {
        EWRITE(userid,M_CM_DB_NOTOPEN,"00");
        return M_CM_DB_NOTOPEN;
    }
    bigcomp[0]=upcomp[0];
    if(bigcomp[0] == '*')
       bigcomp[1] = '\0';
    else
    {
       bigcomp[1]='*';
       bigcomp[2]='\0';
    }

    #ifdef PRINTF_FLAG
    printf("3.>>>> yr[%d] mth[%d]\n",iplyyear,iplymonth);
    printf("3.>>>> bigcomp[%s],office[%s]\n",bigcomp,office);
    #endif

    /* 102.09.11 Ū��car_code�]�w�� (���j���ӦW��)*/
    sprintf_s(stmt, sizeof stmt, "SELECT chiname  "
                 " FROM car_code  "
                 "WHERE kind = ? AND detail = ? ");   
    $PREPARE pre_second_hand FROM $stmt;
  
    sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT DISTINCT %s %s FROM %s:%s %s:%s %s WHERE %s %s %s %s %s %s %s %s %s ",
                     "a.ipolicy,irelative_ply,a.fcard_class,a.ibig_office, ",
                     "a.ibig_sales,c.ibigcomp,a.dply_end,a.iofficer,a.isecond_hand ",
                     TpDBName,"renew_ply_last a,",
                     TpDBName,"renew_ins_last b,",
                     "officer c ",
                     " a.ipolicy= b.ipolicy ", 
                     " AND a.iofficer = c.iofficer ",
                     " AND YEAR(a.dply_end)=? AND MONTH(a.dply_end)=? ",
                     " AND a.ibig_comp MATCHES ? AND a.ibig_office MATCHES ?",
                     " AND c.ibigcomp <> ' ' AND c.ibigcomp is not null ",
                     " AND b.fedr_status not in ('1','2','3') ",
                     " AND mdamage_cover <> 0  ",
                     " AND a.iofficer[1] matches '[A-Z]' ",
                     " ORDER BY a.fcard_class ");

    #ifdef PRINTF_FLAG
    printf("CURSOR CA302_4stmt_buf[%s]\n",stmt_buf);
    #endif
    $PREPARE CUR_STMT2 FROM $stmt_buf;
    $DECLARE CA302_4 CURSOR WITH HOLD FOR CUR_STMT2;
    $OPEN CA302_4 USING $iplyyear,$iplymonth,$bigcomp,$office;
    while (1)
    {
         #ifdef PRINTF_FLAG
         printf("3.0 >>>>option2[%s]\n",option);
         #endif

         $FETCH CA302_4 INTO $last_ply,$tmp_relative_ply,$fcard_class,
                             $big_office,$big_sales,$ibigcomp,$dply_end_i,$iofficer_a,$isecond_hand;

         if (SQLCODE != 0) break;

         #ifdef PRINTF_FLAG
         printf("lastply[%s],big_office[%s]\n",last_ply,big_office);
         printf("�O�N�� check �O�_��O�j��\n");
         #endif

         /*  �ګO�󤣲���  */
         rdmg = 'N';
         rlia = 'N';
         rvkind = 'N';

         $OPEN fins_cur USING $last_ply;
         for(;;)
         {
               $FETCH fins_cur INTO $sfins;
               if (SQLCODE == SQLNOTFOUND) break;

               if (sfins[0] == '1')
               {
                   rdmg = 'Y';
               }

               if (sfins[0] == '2')
               {
                   rlia = 'Y';
               }

               if ((sfins[0] == '3') || (sfins[0] == '4'))
               {
                    rvkind = 'Y';
               }
         }
         $CLOSE fins_cur;

         if (rvkind == 'Y') continue;

         if (fcard_class[0] == '2')
         {
              /* �B�z���Ѩ���������O */
              strcpy(clmply,last_ply);
         }
         else
         {
              /* �B�z���Ѩ���������O */
              strcpy(clmply,tmp_relative_ply);
         }

         if (strlen(trim(clmply)) >= 13)
         {
              #ifdef PRINTF_FLAG
              printf("clmply[%s]\n",clmply);
              #endif
              strcpy(clm_db,get_car_full_db(clmply));
              #ifdef PRINTF_FLAG
              printf("clm_db [%s]\n",clm_db);
              #endif

              sprintf_s(stmt, sizeof stmt, "SELECT %s FROM %s:%s WHERE %s %s",
                            " count(*) ",
                            get_full_dbname(clm_db),
                            "appraisal ",
                            " ipolicy = ? ",
                            " AND fpart IN ('1','2','3') ");

              $PREPARE clmid1 FROM $stmt;
              $EXECUTE clmid1 INTO $clmcnt USING $clmply;
              if (clmcnt > 0) continue;
         }

         #ifdef PRINTF_FLAG
         printf("after lastply[%s],big_office[%s]\n",last_ply,big_office);
         printf("3.0>>>last_ply[%s],ibig_comp[%s]\n",ibig_comp,last_ply);
         #endif
         dmg_flag = 'N';
         lia_flag = 'N';
         rec_count++;
         
         /** ��Ƽg�J renew_ply_last�Brenew_policy_last **/
         printf("Insert into renew_ply_302 ipolicy[%s]\n", last_ply );
         $INSERT INTO renew_ply_302
          SELECT * FROM renew_ply_last
           WHERE ipolicy = $last_ply;
         
         printf("Insert into renew_policy_302 ipolicy[%s]\n", last_ply );
         $INSERT INTO renew_policy_302
          SELECT * FROM renew_policy_last
           WHERE ipolicy = $last_ply;

         InitData1();

                  
    }  /* end of while */
    $CLOSE CA302_4;
    $FREE CA302_4;

    /** Start make file�Grenew_ply_record **/
    /* mark by 071004 (1101118007_SC1_����CAR3022.CAR311�A�ק�CAR3151.CAR315��Ƥ���CUS201)*/
    /*sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s WHERE %s",
                 " tphone_con, imovephone ",
                 " cu_customer ",
                 " ifpce_id = ? AND ifpce_id_ext = ? ");
    $PREPARE rphone_id FROM $stmt;*/
 
    sprintf_s(stmt, sizeof stmt,"SELECT nname FROM ca_big_office WHERE %s",
                 " fclass = '2' AND ibig_comp = ? " );
    $PREPARE get_name FROM $stmt;
    
    
    /*1110420004_SC1_�ק�car315�����ɦW�W�h*/
    /*�p�G����U*���A��*�令�}�Y��Ӧr*/
    strcpy(sfile_iofficer,"");
    sprintf_s(stmt, sizeof stmt,"select first 1 replace('%s','*','�}�Y') from car_code ",trim(iofficer));
    $PREPARE trans_filename FROM $stmt;
    $EXECUTE trans_filename INTO $sfile_iofficer;
    strcpy(sfile_iofficer,trim(sfile_iofficer));
    
    
    sprintf_s(outputf1, sizeof outputf1,"car315_%s_%s%s",sfile_iofficer,plyyear,plymonth);
    rt = getApHome(sApHome);
    if (rt < 0)
    {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
    }
    
    sprintf_s(file, sizeof file,"%s/rptftp/%s",sApHome,rtrim(outputf1));

    rt = rptftpinsert(userid,"car315",outputf1);
    if (rt != 0)
    {
        printf("rptftp error \n");
        goto car315_err;
    }
    printf("ca315 file == [%s]\n",file);
    
    if ((fptr=fopen(file,"w")) == NULL){
        sprintf_s(errmsg, sizeof errmsg,"Cannot open print file: %s",file);
        return M_CM_OPEN_FILE_FAIL;
    }
    
    printf("\nprepare in car315 file \n");
    tot_count=0;
    $WHENEVER SQLERROR GOTO car315_err;
    $DECLARE cur315_a CURSOR for
     SELECT a.ipolicy, a.icard, a.fcard_class, a.irelative_ply, a.dply_end,
             a.dissue, b.nassured, b.itel, b.iengine,
             ( a.mdmg_prem + a.mlia_prem ) mprem, a.ibig_comp, a.ibig_office,
             a.ibig_sales, b.itag, b.iassured, b.iassured_ext , a.iofficer, a.isecond_hand,
             b.tphone_con, b.imovephone
        FROM renew_ply_302 a , renew_policy_302 b
       WHERE a.ipolicy = b.ipolicy 
       ORDER BY a.iofficer, a.ibig_office,a.ipolicy ;
    $OPEN cur315_a;
    while(1)
    {
    	$FETCH cur315_a INTO $ripolicy, $ricard, $rfcard_class, $rirelative_ply,
    	                     $rdply_end, $riissue_ym, $rnassured, $ritel, $riengine,
    	                     $rmprem, $ribig_comp, $ribig_office, $ribig_sales, $ritag,
    	                     $riassured, $riassured_ext,$riofficer,$isecond_hand,
    	                     $rtphone_con, $rimovephone;
    	
    	if( SQLCODE == SQLNOTFOUND ) break;
    	
    	
    	printf("ripolicy[%s] rdply_end[%s]\n", ripolicy, rdply_end);

    	strcpy(ribig_comp, trim(ribig_comp));
    	if(strcmp(ribig_comp, "B")==0)
    	{
    	   strcpy( ribig_comp, "F");
    	   strcpy( temp_ribig_office, "FMC");
    	   strcat( temp_ribig_office,trim(ribig_office));
    	   strcpy( ribig_office,temp_ribig_office);
		}
    	else if(strcmp(ribig_comp, "J")==0)
    	   strcpy( ribig_comp, "S");
    	else if(strcmp(ribig_comp, "E")==0)
    	   strcpy( ribig_comp, "Y");
    	else if(strcmp(ribig_comp, "F")==0)
    	   strcpy( ribig_comp, "L");
    	else if(strcmp(ribig_comp, "A")==0)
    	   strcpy( ribig_comp, "Y");
    	else
    	   strcpy( ribig_comp, "N");
    	
    	/** get tphone_con, imovephone **/
    	/* mark by 071004 (1101118007_SC1_����CAR3022.CAR311�A�ק�CAR3151.CAR315��Ƥ���CUS201)
    	$EXECUTE rphone_id INTO $rtphone_con, $rimovephone 
    	                   using $riassured, $riassured_ext;
    	if(SQLCODE == SQLNOTFOUND) 
    	{
    	   strcpy( rtphone_con, " ");
    	   strcpy( rimovephone, " ");
    	} */  
    	
    	/** get nbig_sales_name **/
    	$EXECUTE get_name INTO $rnbig_sales using $ribig_sales;
    	if(SQLCODE == SQLNOTFOUND) 
    	{
    	   strcpy( rnbig_sales, " ");
    	}   
    	
         /* 102.09.11 ���j���ӦW�� */
         strcpy(isecond_hand,trim(isecond_hand));
         strcpy(nsecond_hand," ");
         printf("trace isecond_hand[%s]\n ",isecond_hand);         
         if ( (isecond_hand[0] != '\0') && (isecond_hand[0] != ' ') ){         	          	
             $EXECUTE pre_second_hand INTO $nsecond_hand USING "B2",$isecond_hand;
             printf("trace nsecond_hand[%s]\n ",nsecond_hand);
         }  	
    	
    	/** �_�O��B�o�Ӥ� **/
    	tmp_dply_end[0] = rdply_end[6];
    	tmp_dply_end[1] = rdply_end[7];
    	tmp_dply_end[2] = rdply_end[8];
    	tmp_dply_end[3] = rdply_end[9];
    	tmp_dply_end[4] = '/';
    	tmp_dply_end[5] = rdply_end[0];
    	tmp_dply_end[6] = rdply_end[1];
    	tmp_dply_end[7] = '/';
    	tmp_dply_end[8] = rdply_end[3];
    	tmp_dply_end[9] = rdply_end[4];
    	tmp_dply_end[10] = '\0';
    	
        /* �褸06/24/2009��X��(06)�A��(24)�A�~(2009) */
        {
        char  yy[5], mm[3], dd[3];
        cm_split_ymd( riissue_ym, mm, dd, yy);
        sprintf_s(tmp_iissue_ymd, sizeof tmp_iissue_ymd, "%s/%s/%s", yy, mm, dd);
        }

    	strcpy(prtstr,trim(ripolicy));
        strcat(prtstr, "|");
        strcat(prtstr,trim(ricard));
        strcat(prtstr, "|");
    	strcat(prtstr,trim(rfcard_class));
        strcat(prtstr, "|");
        strcat(prtstr,trim(rirelative_ply));
        strcat(prtstr, "|");
        strcat(prtstr,trim(tmp_dply_end));
        strcat(prtstr, "|");
        strcat(prtstr,trim(tmp_iissue_ymd));
        strcat(prtstr, "|");
        strcat(prtstr,trim(rnassured));
        strcat(prtstr, "|");
        strcat(prtstr,trim(ritel));
        strcat(prtstr, "|");
        strcat(prtstr,trim(rtphone_con));
        strcat(prtstr, "|");
        strcat(prtstr,trim(rimovephone));
        strcat(prtstr, "|");
        strcat(prtstr,trim(riengine));
        strcat(prtstr, "|");
        strcat(prtstr,itoa(rmprem));
        strcat(prtstr, "|");
        strcat(prtstr,trim(ribig_comp));
        strcat(prtstr, "|");
        strcat(prtstr,trim(ribig_office));
        strcat(prtstr, "|");
        strcat(prtstr,trim(ribig_sales));
        strcat(prtstr, "|");
        strcat(prtstr,trim(rnbig_sales));
        strcat(prtstr, "|");
        strcat(prtstr, " ");
        strcat(prtstr, "|");
        strcat(prtstr,trim(ribig_office));
        strcat(prtstr, "|");
        strcat(prtstr, " ");
        strcat(prtstr, "|");
        strcat(prtstr,trim(ribig_sales));
        strcat(prtstr, "|");
        strcat(prtstr,trim(rnbig_sales));
        strcat(prtstr, "|");
        
        for(x=0; x<16; x++)
          strcat(prtstr, "|");
        
        strcat(prtstr,"0");
        strcat(prtstr,"|");  
        strcat(prtstr,trim(ritag));
        strcat(prtstr, "|");
        strcat(prtstr, " ");
        strcat(prtstr, "|");
        strcat(prtstr,trim(ribig_office));
        strcat(prtstr, "|");
        strcat(prtstr, " ");
        strcat(prtstr, "|");
        strcat(prtstr,trim(ribig_sales));
        strcat(prtstr, "|");
        strcat(prtstr,trim(rnbig_sales));
        strcat(prtstr, "|");
        strcat(prtstr,trim(nsecond_hand));
        strcat(prtstr, "|");
    	fprintf(fptr,"%s\n",prtstr);
    	tot_count++;
    	
    }
    $CLOSE cur315_a;
    $FREE  cur315_a;
    
    
    fclose(fptr);
    
    sprintf_s(msgbuf, sizeof msgbuf,"\n����O���������X�@�~\n");
    sprintf_s(msgbuf, sizeof msgbuf,"%s�@�E�O�����~��G%s%s \n",msgbuf,plyyear,plymonth,iofficer);
    sprintf_s(msgbuf, sizeof msgbuf,"%s�@�E�g��N���@�@�G%s \n", msgbuf,iofficer);
    sprintf_s(msgbuf, sizeof msgbuf,"%s�@�E��X�ɮצW�١G%s (�Цܡucmn202�ɮפU���@�~�v�U��)\n",msgbuf, rtrim(outputf1));
    sprintf_s(msgbuf, sizeof msgbuf,"%s�@�E��X��Ƶ��ơG%s ��",msgbuf, itoa(tot_count));
    
    $drop table renew_ply_last;
    $drop table renew_policy_last;
    $drop table renew_ins_last;
    $drop table renew_ply_302;
    $drop table renew_policy_302;
    
    return M_CM_OK;

car315_err:
    printf("in car315_err\n");
    $WHENEVER SQLERROR CONTINUE;     /* reset error handling */
    printf("------car315_err: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

int sPrepare()
{
     $date   Today;
     $char   FullDBName[30], stmt_buf[8192];
     char    dbsite1[3], FullDBName1[20];
     char    remotedb[5];
     $char   wk_ipolicy[POLICY_NUM_1];
     $char   wk_iendorse[ENDORSE_NUM];

     $char   xBranch[3];

     int     i;

     $char   tmp_ipolicy[21];
     $date   tmp_dply_begin, tmp_dply_end;
     $char   tmp_nequipment[31];
     $char   tmp_iresource[3];
     $char   tmp_iofficer[11];
     $char   tmp_icar_flag[3];
     $long   count_num;

     $WHENEVER SQLERROR GOTO errexit;
     $SET LOCK MODE TO WAIT ;

     rtoday(&Today);     /* get today's datetime */

     printf("in Prepare\n");

     $DECLARE sdb_cur CURSOR WITH HOLD FOR
       SELECT branch
         INTO $xBranch
         FROM servertbl
        WHERE branch <> 'S1';  
     $OPEN sdb_cur;

     for(;;)
     {
          $FETCH sdb_cur;
          if (SQLCODE == SQLNOTFOUND) break;

          printf("in servertbl xBranch[%s]\n", xBranch);

          $CREATE TEMP TABLE Iply
           (
                ipolicy   char(20)
           ) WITH NO LOG ;
          $CREATE UNIQUE INDEX tmp_ix ON Iply(ipolicy);
          printf("done Iply\n");

          strcpy(FullDBName,get_full_dbname(xBranch));

          stmt_buf[0] = '\0';
          sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO Iply (ipolicy) VALUES (?)");
          $PREPARE a_id FROM  $stmt_buf;
          printf("done a_id\n");

          stmt_buf[0] = '\0';
          sprintf_s(stmt_buf, sizeof stmt_buf, " INSERT INTO renew_ply_last SELECT a.ipolicy ,a.icard , a.fcard_class, a.irelative_ply , a.dply_begin, a.dply_end ,  "
                              "b.dissue ,a.ipro_year,a.ibrand ,a.icar_type ,a.mdmg_prem ,a.mlia_prem ,a.ibig_comp,  "
                              "a.ibig_branch,a.ibig_office,a.ibig_sales ,a.iresource ,a.ibroker ,a.iofficer,a.ileader,  "
                              "a.icorps ,a.iarea ,a.dpolicy,a.ibranch,a.iquota ,a.icar_flag,a.isecond_hand   "
                              "FROM %s:ply_relation a, %s:policy b WHERE a.ipolicy = b.ipolicy AND a.ipolicy = ? ",FullDBName, FullDBName);
          $PREPARE ins_re FROM $stmt_buf;
          printf("done ins_re\n");

          stmt_buf[0] = '\0';
          sprintf_s(stmt_buf, sizeof stmt_buf, " INSERT INTO renew_policy_last SELECT ipolicy ,icard ,fassured,iassured ,iassured_ext,nassured ,ilicense ,dbirth ,fsex ,fmarriage,  "
                              "nuser ,aassured ,aassured_zip ,itel ,iemail ,iply_area ,nbrand_abbr,ncar_abbr ,fcar_note , "
                              "qcylinder ,iengine ,ibody ,itag ,mcar_price ,nequipment ,fcal_way ,idmg_rate,pdmg_factor , "
                              "ibrg_rate ,pbrg_factor,qpt ,fpt ,psex_age ,lia_class,plia_acc ,pdmg_acc ,fhuman ,fcomp_24, "
                              "itel_night ,mobil_phone "
                              "FROM %s:policy WHERE ipolicy = ? ",FullDBName);
          $PREPARE ins_po FROM $stmt_buf;
          printf("done ins_po\n");
          
          stmt_buf[0] = '\0';
          sprintf_s(stmt_buf, sizeof stmt_buf, " INSERT INTO renew_ins_last SELECT ipolicy ,iins_type ,minjured_cover ,mdeath_cover ,mdamage_cover,mdeduct ,mins_premium,  "
                              "mpure_prem ,qserial ,fedr_status ,dendorse ,dedr_begin ,dedr_end ,iendorse ,pcommission,  "
                              "mcommission ,pagent ,magent ,pdiscount ,mdiscount ,drate_ym ,mprem ,iproduct ,ipaid_base,  "
                              "qday  ,mexpense  ,mexp_disc  FROM %s:ply_ins_type WHERE ipolicy = ? ",FullDBName);
          $PREPARE ins_type FROM $stmt_buf;
          printf("done ins_type\n");

          $BEGIN WORK;
          printf("Preparing ipolicy Please Wait .....\n");

          /* �z�糧����O�J�p�@�~�ŦX����϶����O�� */
          count_num = 0;
          stmt_buf[0] = '\0';
          sprintf_s(stmt_buf, sizeof stmt_buf, " SELECT %s FROM %s:%s %s:%s WHERE %s %s %s ",
                            " a.ipolicy, a.dply_begin, a.dply_end, b.nequipment, a.iresource, a.iofficer, a.icar_flag ",
                            FullDBName,"ply_relation a,",
                            FullDBName,"policy b ",
                            " a.dply_end between ? and ? ",
                            " AND a.iofficer matches ? ",
                            " AND a.ipolicy = b.ipolicy ");
                            
          printf("[%s]\n",stmt_buf);
          printf("lDplyEndBgn[%ld] ",lDplyEndBgn);
          printf("lDplyEndEnd[%ld]\n",lDplyEndEnd);
          printf("iofficer[%s]\n", iofficer );
          $PREPARE ins_ply_tmp FROM $stmt_buf;
          $DECLARE ins_ply     CURSOR WITH HOLD FOR ins_ply_tmp;
          $OPEN    ins_ply     USING  $lDplyEndBgn, $lDplyEndEnd, $iofficer;
          while(1)
          {
              $FETCH ins_ply INTO $tmp_ipolicy, $tmp_dply_begin, $tmp_dply_end, $tmp_nequipment, $tmp_iresource, $tmp_iofficer, $tmp_icar_flag;
              if (SQLCODE == SQLNOTFOUND) break;

              printf("tmp_ipolicy[%s]\n", tmp_ipolicy);
              
              /*  iresource != 'E' */
              if (strncmp(tmp_iresource,"E",1)==0)
                   continue;

              /*  iofficer[1,3] != 'G98' */
              if (strncmp(tmp_iofficer,"G98",3)==0)
                   continue;

              /*  (iofficer[1] != 'W' AND  iofficer[7,8] not in ('JT','IS','IF','BE','YF','YI'))  */
              if ((tmp_iofficer[0] == 'W') || (tmp_iofficer[0] == 'H' && (tmp_iofficer[1]!='0' && tmp_iofficer[1]!='1' && tmp_iofficer[1]!='2') ))
              {
              	   /*
                   if((strncmp(tmp_iofficer+(7-1),"BE",2)==0) ||
                      (strncmp(tmp_iofficer+(7-1),"JT",2)==0) ||
                      (strncmp(tmp_iofficer+(7-1),"YF",2)==0) ||
                      (strncmp(tmp_iofficer+(7-1),"IF",2)==0) ||
                      (strncmp(tmp_iofficer+(7-1),"IS",2)==0) ||
                      (strncmp(tmp_iofficer+(7-1),"YI",2)==0) )
                   {*/
                        continue;
                   /*}*/
              }

              /*  C�BD�� JT �M�ױư�nequipment[9] = '1' ���� */
              /*  �w�t���ĳ�I��11                           */
              /*  (nequipment[9] = '1' AND  iofficer[1] IN ('C','D','K')
                   AND  dply_end between '05/01/2003' AND '08/15/2003' AND  icar_flag = '1' )  */

              if ((equip_cmp(tmp_nequipment,"09") == TRUE) &&
                  (strncmp(tmp_icar_flag,"1",1)==0) &&
                  ((tmp_dply_end >= cm_ymd_cdate("92/05/01")) && (tmp_dply_end <= cm_ymd_cdate("92/08/15"))) &&
                  ((strncmp(tmp_iofficer,"C",1)==0) || (strncmp(tmp_iofficer,"D",1)==0) || (strncmp(tmp_iofficer,"K",1)==0)))
              {
                   continue;
              }

              printf("INSERTING Iply\n");
              $EXECUTE a_id USING $tmp_ipolicy;

              printf("INSERTING renew_ply_last\n");
              $EXECUTE ins_re USING $tmp_ipolicy;

              printf("INSERTING renew_policy_last\n");
              $EXECUTE ins_po USING $tmp_ipolicy;
 
              printf("INSERTING renew_ins_last\n");
              $EXECUTE ins_type USING $tmp_ipolicy;

              /**
              printf("INSERTING ca_pa_ply_last\n");
              $EXECUTE pa_type USING $tmp_ipolicy;
              **/

              count_num ++;

              if (count_num == 500)
              {
                   $COMMIT WORK;
                   $BEGIN WORK;
                   count_num = 0;
              }
          }
          $CLOSE ins_ply;
          $FREE  ins_ply;

          $COMMIT WORK;
          
          $DROP TABLE Iply;
          
     }
     $CLOSE sdb_cur;
     $FREE  sdb_cur;
     
     printf("finish s_Prepare() \n");

     return TRUE;
errexit:
     $ROLLBACK WORK;
     printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
     return SQLCODE;
}

double d45(num)
double num;
{
     long tmplong;
     double var1;

     if (num >= 0) var1 = 0.5;
     else var1 = (-0.5);

     num = num + var1;
     tmplong = num;
     num = tmplong;

     return(num);
}


char* splace(cStr,iLen,iDir)
char cStr[100];
int  iLen;
int  iDir;
{
     int  iTmplen;
     int  iSpc,i;
     char cSpc[100];
     char cRtn[100];

     strcpy(cStr,trim(cStr));
     iTmplen = strlen(cStr);
     iSpc = iLen - iTmplen;

     for(i=0;i<iSpc;i++)
     {
         cSpc[i] = ' ';
     }
         cSpc[iSpc] = '\0';

     if (iDir == 1)
     {
         strcpy(cRtn,cStr);
         strcat(cRtn,cSpc);
     }
     else
     {
         strcpy(cRtn,cSpc);
         strcat(cRtn,cStr);
     }
         printf("cRtn[%s]\n",cRtn);
         return cRtn;
}

long sTable()
{
    
    printf("Begin Create sTable \n"); 

    $CREATE TEMP TABLE renew_ply_last
    (
      ipolicy char(20)
          default ' ',
      icard char(20)
          default ' ',
      fcard_class char(1)
          default ' ',
      irelative_ply char(20)
          default ' ',
      dply_begin date,
      dply_end date,
      dissue date 
          default null,
      ipro_year char(4)
          default ' ',
      ibrand char(8)
          default ' ',
      icar_type char(2)
          default ' ',
      mdmg_prem integer
          default 0,
      mlia_prem integer
          default 0,
      ibig_comp char(1)
          default ' ',
      ibig_branch char(4)
          default ' ',
      ibig_office char(9)
          default ' ',
      ibig_sales char(10)
          default ' ',
      iresource char(1)
          default ' ',
      ibroker char(10)
          default ' ',
      iofficer char(10)
          default ' ',
      ileader char(10)
          default ' ',
      icorps char(10)
          default ' ',
      iarea char(10)
          default ' ',
      dpolicy date,
      ibranch char(2)
          default ' ',
      iquota char(7)
          default ' ',
      icar_flag char(1) not null,
      isecond_hand char(6) 
          default ' '
    )WITH NO LOG;
    $CREATE INDEX renew_ply_1 ON renew_ply_last(ipolicy);
    $CREATE INDEX renew_ply_2 ON renew_ply_last(icard);
    
    $CREATE TEMP TABLE renew_policy_last
    (
      ipolicy char(20)
          default ' ',
      icard char(20)
          default ' ',
      fassured char(1)
          default ' ',
      iassured char(12)
          default ' ',
      iassured_ext char(2)
          default ' ',
      nassured char(120)
          default ' ',
      ilicense char(10)
          default ' ',
      dbirth date 
          default null,
      fsex char(1)
          default ' ',
      fmarriage char(1)
          default ' ',
      nuser char(18)
          default ' ',
      aassured char(90)
          default ' ',
      aassured_zip char(6)
          default ' ',
      itel char(13)
          default ' ',
      iemail char(50)
          default ' ',
      iply_area char(10)
          default ' ',
      nbrand_abbr char(12)
          default ' ',
      ncar_abbr char(12)
          default ' ',
      fcar_note char(2)
          default ' ',
      qcylinder decimal(7,2)
          default 0.00,
      iengine char(20)
          default ' ',
      ibody char(20)
          default ' ',
      itag char(8)
          default ' ',
      mcar_price decimal(5,1)
          default 0.0,
      nequipment char(30)
          default ' ',
      fcal_way char(1)
          default ' ',
      idmg_rate char(2)
          default ' ',
      pdmg_factor decimal(6,4)
          default 0.0000,
      ibrg_rate char(2)
          default ' ',
      pbrg_factor decimal(6,4)
          default 0.0000,
      qpt decimal(4,1)
          default 0.0,
      fpt char(1)
          default ' ',
      psex_age decimal(15,12)
          default 0.00,
      lia_class char(2)
          default '4',
      plia_acc decimal(5,2)
          default 0.00,
      pdmg_acc decimal(5,2)
          default 0.00,
      fhuman char(1)
          default '1',
      fcomp_24 char(1)
          default ' ',
      tphone_con char(20)
          default ' ',
      imovephone char(20)
          default ' '

    )WITH NO LOG;
    
    $create unique index renew_ix_1 on renew_policy_last(icard);
    $create unique index renew_ix_2 on renew_policy_last(ipolicy);
    
    $CREATE TEMP TABLE renew_ins_last
    (
      ipolicy char(20)
          default ' ',
      iins_type char(6)
          default ' ',
      minjured_cover integer
          default 0,
      mdeath_cover integer
          default 0,
      mdamage_cover integer
          default 0,
      mdeduct integer
          default 0,
      mins_premium integer
          default 0,
      mpure_prem decimal(10,3)
          default 0,
      qserial smallint
          default 0,
      fedr_status char(1)
          default ' ',
      dendorse date,
      dedr_begin date,
      dedr_end date,
      iendorse char(20)
          default ' ',
      pcommission decimal(4,2)
          default 0,
      mcommission integer
          default 0,
      pagent decimal(4,2)
          default 0,
      magent integer
          default 0,
      pdiscount decimal(4,2)
          default 0,
      mdiscount integer
          default 0,
      drate_ym char(4)
          default ' ',
      mprem integer
          default 0,
      iproduct char(12)
          default ' ',
      ipaid_base char(1)
          default 'A',
      qday  integer
          default 0,
      mexpense  integer
          default 0,
      mexp_disc integer
          default 0
    )WITH NO LOG;
    
    $create unique index renew_ins_ix_1 on renew_ins_last (ipolicy,iins_type);
    $create index renew_ins_ix_2 on renew_ins_last(ipolicy);
    
    $CREATE TEMP TABLE renew_ply_302
    (
      ipolicy char(20)
          default ' ',
      icard char(20)
          default ' ',
      fcard_class char(1)
          default ' ',
      irelative_ply char(20)
          default ' ',
      dply_begin date,
      dply_end date,
      dissue date 
          default null,
      ipro_year char(4)
          default ' ',
      ibrand char(8)
          default ' ',
      icar_type char(2)
          default ' ',
      mdmg_prem integer
          default 0,
      mlia_prem integer
          default 0,
      ibig_comp char(1)
          default ' ',
      ibig_branch char(4)
          default ' ',
      ibig_office char(9)
          default ' ',
      ibig_sales char(10)
          default ' ',
      iresource char(1)
          default ' ',
      ibroker char(10)
          default ' ',
      iofficer char(10)
          default ' ',
      ileader char(10)
          default ' ',
      icorps char(10)
          default ' ',
      iarea char(10)
          default ' ',
      dpolicy date,
      ibranch char(2)
          default ' ',
      iquota char(7)
          default ' ',
      icar_flag char(1) not null,
      isecond_hand char(6) 
          default ' '      
    )WITH NO LOG;
    $CREATE INDEX renew_ply_302_1 ON renew_ply_302(ipolicy);
    $CREATE INDEX renew_ply_302_2 ON renew_ply_302(icard);
    
    $CREATE TEMP TABLE renew_policy_302
    (
      ipolicy char(20)
          default ' ',
      icard char(20)
          default ' ',
      fassured char(1)
          default ' ',
      iassured char(12)
          default ' ',
      iassured_ext char(2)
          default ' ',
      nassured char(120)
          default ' ',
      ilicense char(10)
          default ' ',
      dbirth date 
          default null,
      fsex char(1)
          default ' ',
      fmarriage char(1)
          default ' ',
      nuser char(18)
          default ' ',
      aassured char(90)
          default ' ',
      aassured_zip char(6)
          default ' ',
      itel char(13)
          default ' ',
      iemail char(50)
          default ' ',
      iply_area char(10)
          default ' ',
      nbrand_abbr char(12)
          default ' ',
      ncar_abbr char(12)
          default ' ',
      fcar_note char(2)
          default ' ',
      qcylinder decimal(7,2)
          default 0.00,
      iengine char(20)
          default ' ',
      ibody char(20)
          default ' ',
      itag char(8)
          default ' ',
      mcar_price decimal(5,1)
          default 0.0,
      nequipment char(30)
          default ' ',
      fcal_way char(1)
          default ' ',
      idmg_rate char(2)
          default ' ',
      pdmg_factor decimal(6,4)
          default 0.0000,
      ibrg_rate char(2)
          default ' ',
      pbrg_factor decimal(6,4)
          default 0.0000,
      qpt decimal(4,1)
          default 0.0,
      fpt char(1)
          default ' ',
      psex_age decimal(15,12)
          default 0.00,
      lia_class char(2)
          default '4',
      plia_acc decimal(5,2)
          default 0.00,
      pdmg_acc decimal(5,2)
          default 0.00,
      fhuman char(1)
          default '1',
      fcomp_24 char(1)
          default ' ',
      tphone_con char(20)
          default ' ',
      imovephone char(20)
          default ' '

    )WITH NO LOG;
    
    $create unique index renew_ix_302_1 on renew_policy_302(icard);
    $create unique index renew_ix_302_2 on renew_policy_302(ipolicy);
    
    printf("End Create sTable \n");

    return TRUE;
     
errexit:
     $ROLLBACK WORK;
     printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
     return SQLCODE;
}
InitData()
{
    memset(estimatei,0,sizeof(estimatei));
    memset(irelative_ply,0,sizeof(irelative_ply));
    memset(last_ply,0,sizeof(last_ply));
    memset(policy1,0,sizeof(last_ply));
    memset(policy2,0,sizeof(last_ply));

    memset(tagnum,0,sizeof(tagnum));
    memset(relative_card,0,sizeof(relative_card));
    memset(card2,0,sizeof(card2));
    memset(card1,0,sizeof(card1));

    memset(xxcard,0,sizeof(xxcard));
    memset(last_card,0,sizeof(last_card));
    memset(abn_type,0,sizeof(abn_type));
    memset(assuredi,0,sizeof(assuredi));
    memset(assuredf,0,sizeof(assuredf));
    memset(cutf,0,sizeof(cutf));
    memset(assuredn,0,sizeof(assuredn));
    memset(user,0,sizeof(user));
    memset(benefi,0,sizeof(benefi));
    memset(benefn,0,sizeof(benefn));
    memset(assureda,0,sizeof(assureda));
    memset(paymenta,0,sizeof(paymenta));
    memset(tel,0,sizeof(tel));
    memset(passf,0,sizeof(passf));
    memset(issue_ym,0,sizeof(issue_ym));
    memset(pro_year,0,sizeof(pro_year));
    memset(brandi,0,sizeof(brandi));
    memset(brandn,0,sizeof(brandn));
    memset(car_typei,0,sizeof(car_typei));
    memset(car_typen,0,sizeof(car_typen));
    memset(engine,0,sizeof(engine));
    memset(body,0,sizeof(body));
    memset(cal_way,0,sizeof(cal_way));
    memset(license,0,sizeof(license));
    memset(birth,0,sizeof(birth));
    memset(sex,0,sizeof(sex));
    memset(marriage,0,sizeof(marriage));
    memset(acc_align,0,sizeof(acc_align));
    memset(limit,0,sizeof(limit));
    memset(officer,0,sizeof(officer));
    memset(broker,0,sizeof(broker));
    memset(cashier,0,sizeof(cashier));
    memset(resource,0,sizeof(resource));
    memset(big_branch,0,sizeof(big_branch));
    memset(big_office,0,sizeof(big_office));
    memset(big_sales,0,sizeof(big_sales));
    memset(equipment,0,sizeof(equipment));
    memset(ins_type,0,sizeof(ins_type));
    memset(facf,0,sizeof(facf));
    memset(treaty,0,sizeof(treaty));
    memset(passi,0,sizeof(passi));


    memset(drate_ym,0,sizeof(drate_ym));
    memset(fcar_class,0,sizeof(fcar_class));
    memset(fpt,0,sizeof(fpt)); /* 850624-mag */
    memset(fhuman,0,sizeof(fhuman)); 
    memset(comp_class_last,0,sizeof(comp_class_last)); 
    memset(comp_class,0,sizeof(comp_class)); 
    memset(specom,0,sizeof(specom));

    /*memset(remark,0,sizeof(remark));*/
    /*memset(ibig_policy,0,sizeof(ibig_policy));*/

    ply2_period=ply1_period=0;
    rows=cylinder=dmg_align=lia_align=0; 
    dmg_align_1=lia_align_1=0;

    brg_align=brg_align_1=0; /* 850624-mag */

    ply2_begin=ply2_end=ply1_begin=ply1_end=DATENULL; /* DATENULL ?? */
    bef_ply2_begin=bef_ply2_end=bef_ply1_begin=bef_ply1_end=DATENULL; 
    passd=facd=0;   /* DATENULL ?? */
    drnw_print_1=DATENULL;

    ddate_1st=DATENULL;
    ddate_2nd=DATENULL;

    car_price=0;
    injured_cover=death_cover=damage_cover=deduct=ins_premium=0;

    premium2=0;premium1=0;
    premium=0;

    mdmg_prem=mlia_prem=0;
    qserial=qcoverage=0;

    qday      = 0;
    mexpense  = 0;
    mexp_disc = 0;

    damage_add_flag = 0;
    thief_add_flag  = 0;

    qpt=psex_age=plia_acc=pdmg_acc=0; /* 850624-mag */
    psex_age_notfound=0;
/* crystal-861229 */
    premium1_bef=0;
    comprem1=diff_prem=0;
    readyrate=comprate=stablerate=investrate=0;
}
InitData1()
{
    /* can not initialize last_ply */
 
    memset(estimatei,0,sizeof(estimatei));
    memset(irelative_ply,0,sizeof(irelative_ply));
    memset(policy1,0,sizeof(last_ply));
    memset(policy2,0,sizeof(last_ply));

    memset(tagnum,0,sizeof(tagnum));
    memset(relative_card,0,sizeof(relative_card));
    memset(card2,0,sizeof(card2));
    memset(card1,0,sizeof(card1));
    memset(icard_1,0,sizeof(card1));

    memset(xxcard,0,sizeof(xxcard));
    memset(last_card,0,sizeof(last_card));
    memset(abn_type,0,sizeof(abn_type));
    memset(assuredi,0,sizeof(assuredi));
    memset(assuredf,0,sizeof(assuredf));
    memset(cutf,0,sizeof(cutf));
    memset(assuredn,0,sizeof(assuredn));
    memset(user,0,sizeof(user));
    memset(benefi,0,sizeof(benefi));
    memset(benefn,0,sizeof(benefn));
    memset(assureda,0,sizeof(assureda));
    memset(paymenta,0,sizeof(paymenta));
    memset(tel,0,sizeof(tel));
    memset(passf,0,sizeof(passf));
    memset(issue_ym,0,sizeof(issue_ym));
    memset(pro_year,0,sizeof(pro_year));
    memset(brandi,0,sizeof(brandi));
    memset(brandn,0,sizeof(brandn));
    memset(car_typei,0,sizeof(car_typei));
    memset(car_typen,0,sizeof(car_typen));
    memset(engine,0,sizeof(engine));
    memset(body,0,sizeof(body));
    memset(cal_way,0,sizeof(cal_way));
    memset(license,0,sizeof(license));
    memset(birth,0,sizeof(birth));
    memset(sex,0,sizeof(sex));
    memset(marriage,0,sizeof(marriage));
    memset(acc_align,0,sizeof(acc_align));
    memset(acc_align_t,0,sizeof(acc_align));

    memset(limit,0,sizeof(limit));
    memset(officer,0,sizeof(officer));
    memset(broker,0,sizeof(broker));
    memset(cashier,0,sizeof(cashier));
    memset(resource,0,sizeof(resource));
    memset(big_branch,0,sizeof(big_branch));
    memset(big_office,0,sizeof(big_office));
    memset(big_sales,0,sizeof(big_sales));
    memset(equipment,0,sizeof(equipment));
    memset(ins_type,0,sizeof(ins_type));
    memset(facf,0,sizeof(facf));
    memset(treaty,0,sizeof(treaty));
    memset(passi,0,sizeof(passi));

    memset(drate_ym,0,sizeof(drate_ym));
    memset(fcar_class,0,sizeof(fcar_class));
    memset(fpt,0,sizeof(fpt)); /* 850624-mag */
    memset(fhuman,0,sizeof(fhuman)); 
    memset(comp_class_last,0,sizeof(comp_class_last)); 
    memset(comp_class,0,sizeof(comp_class)); 
    memset(specom,0,sizeof(specom)); 

    /*memset(remark,0,sizeof(remark));*/
    /*memset(ibig_policy,0,sizeof(ibig_policy));*/

    ply2_period=ply1_period=0;
    rows=cylinder=dmg_align=lia_align=0;
    dmg_align_1=lia_align_1=0;

    brg_align=brg_align_1=0; /* 850624-mag */

    ply2_begin=ply2_end=ply1_begin=ply1_end=DATENULL; /* DATENULL ?? */
    bef_ply2_begin=bef_ply2_end=bef_ply1_begin=bef_ply1_end=DATENULL;
    passd=facd=0;   /* DATENULL ?? */
    drnw_print_1=DATENULL;

    ddate_1st=DATENULL;
    ddate_2nd=DATENULL;

    car_price=0;
    injured_cover=death_cover=damage_cover=deduct=ins_premium=0;

    premium2=0;premium1=0;
    premium=0;

    qday      = 0;
    mexpense  = 0;
    mexp_disc = 0;

    damage_add_flag = 0;
    thief_add_flag  = 0;

    mdmg_prem=mlia_prem=0;
    qserial=qcoverage=0;

    qpt=psex_age=plia_acc=pdmg_acc=0; /* 850624-mag */
    psex_age_notfound=0;
/* crystal-861229 */
    premium1_bef=0;
    comprem1=diff_prem=0;
    readyrate=comprate=stablerate=investrate=0;

}

char *get_car_full_db(sIpolicy)

char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, sTmpcomp);
  }
  return sTmp_db_name;
}
