/**********************************************************************/
/*   program id   : ca307p02s.ec                                      */
/*   program name : �i�妸�j- ���I�e�~�O��L�s�@�~                    */
/*   date written : 2014/03/10                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : Larry Liao                                        */
/*   shell        : car_out                                           */
/*   exec time    :(�@~�� �U�ȤT�I)                                     */
/**********************************************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"
#include "carmsgs.h"
#include "ISvar.h"
#include "safeclib.h"

char  	outputf[ N_FILE+1];
$char  	userid[11],sDdate[11],sDdate0[16],sDdate1[20],sDdate2[20];
char    cdate[11],sDpolicy_Year[5];
$char   cdate1[11],cdate2[11],cdate_3018[11];
char	syy[4],smm[3],sdd[3],sdate[11];
$char   dtoday1[11],sdate2[11],syy2[4],smm2[3],sdd2[3];
$int    PgLine=0,cnt_err=0;
char    OutFile[31];
long    t=0;

$char	  DBName[5];
DBinfo  *list;
$char	  mmsg[1024];
$char 	tbuf[501];
$char 	mbuf[9000];
$loc_t 	ctxt;
    
int     flen=0, count_db=0, i=0, j=0, k=0 , countp=0, sIout_length=0;
FILE    *fp, *fp0, *fp1, *fp2;
char    sApHome[30];
$char   Fname_1[128], Fname_2[128], Fname_3[128], Fname_4[128];
$char   FileName_1[128], FileName_2[128], FileName_3[128],FileName_4[128];
$char	ftitle[1024];

$char	v_sMsg[1024],sErrMsg[1024];
char	msgbuf[100];
$long	dsys=0;
$char	email[51],chinese_name[15],nsubject[128];
$char sIemp[11],sNname[11],sIout[6];
$char itmp_policy[21],iroute[21];
$int    out_cnt=0,iins_count=0,cnt_getnum=0;
$char sWhere[512];
char cmd_stmt[1024],cmd_stmt2[1024];

$int c_holiday = 0, sqlnf=0 ,c_2033 = 0;
$char ck_holiday_year[4],ck_now[21],ck_holiday[11];

int iTryCnt=0,res1=0,iTryCnt2=0,res2=0;

int result=0;
char tar[1024], gzip[1024], cp[1024], rm[1024];
$char tar1[512],tar2[512];
char command1[1024],command2[1024],command3[1024],command4[1024];

int ireceipt1 = 0;
int ireceipt2 = 0;

static char *get_car_full_db();
/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
	int rc=0;
	  
	batchinit();
	strcpy(DBName,  isNULLstr(argv[1]));
	strcpy(userid,  isNULLstr(argv[2]));
	strcpy(cdate,   isNULLstr(argv[3])); /* cyy/mm/dd */
	strcpy(outputf, isNULLstr(argv[4]));
	
	rc = car_get_db();
	if (rc != M_CM_OK) {
		printf("error on car_get_db\n");
		return rc;
	}

	strcpy(ck_holiday_year,"");
	strcpy(ck_holiday,"");
	strcpy(ck_holiday_year,cm_get_sysd());
	strcpy(ck_holiday_year,cm_sysd_cyear_100(ck_holiday_year));
	strcpy(ck_holiday,cm_get_sysd());
	strcpy(ck_holiday,cm_sysd_cdate_100(ck_holiday));
	strcpy(ck_holiday,cm_to_infdate(ck_holiday));
	/*strcpy(ck_holiday,"05/28/2016");*/
	printf("-----ck_holiday_year = [%s]-----\n",ck_holiday_year);
	printf("-----ck_holiday = [%s]-----\n",ck_holiday);
	$SELECT count(*)
	   INTO $c_holiday 
	   FROM ca_holiday  
	  WHERE cyear = $ck_holiday_year
	    AND $ck_holiday BETWEEN holiday_bgn AND holiday_end; 
	    
	$SELECT count(*)
	   INTO $c_2033
	   FROM cu_code_data
	  WHERE itype = 'OT'
	    AND icode = '2033'
	    AND ncode = 'Y';
	    
	/* �ƥ� */
	sprintf_s(cp, sizeof cp,"cp %s/rptftp/car_out/* %s/rptftp/car_out/bk",sApHome,sApHome);
	printf("cp[%s]\n", cp);
	sprintf_s(command3, sizeof command3, "%s", cp);
	result = system(command3);	
	printf("cp-result[%d]\n", result);
	
	/* �R�� */
	sprintf_s(rm, sizeof rm,"rm -f %s/rptftp/car_out/* ",sApHome);
	printf("rm[%s]\n", rm);
	sprintf_s(command4, sizeof command4, "%s", rm);
	result = system(command4);
	printf("rm-result[%d]\n", result);
          
	if(c_holiday == 0 )
	{    
		if(c_2033 > 0)
		{
			/*�������*/
			rc = create_provision();
			if ( rc != M_CM_OK ) {
			 	printf("error on create_provision\n");
			 	EWRITE(userid, rc, sErrMsg);
				return rc;	
			}
			/* �d�ߩe�~�O��� */
			rc = Query_policy();
			if ( rc != M_CM_OK ) 
			{
				printf("error on Query_policy\n");
				EWRITE(userid, rc, sErrMsg);
			    	return rc;
			}    
			/* ���]�����Y�ɮ� */
			rc = tar_policy();
			if ( rc != M_CM_OK ) 
			{
				printf("error tar_policy\n");
				EWRITE(userid, rc, "���]�����Y�ɮצ��~!");
				return rc;
			}
			/*���I�e�~�O����Ӳ��s*/
			strcpy(cdate_3018,cm_cdate_str_100(cm_today()));
			sprintf_s(cmd_stmt2, sizeof cmd_stmt2,"%s/exec/runbatch 00 100533 car3018 E 1 %s",sApHome,cdate_3018);
			printf("[%s]\n", cmd_stmt2);
			rc = system(cmd_stmt2);    
			if ( rc != M_CM_OK) {
				printf("error on Query\n");
				EWRITE(userid, rc, "���I�e�~�O����Ӳ��s!");
				return rc; 
			}
			c_holiday = 1;
		}
	    else
		{
			/*car2033�����槹�� �o�eMAIL�q���t�d�H*/
			sprintf_s(cmd_stmt, sizeof cmd_stmt, "mailx -r \"ipisnew@tmnewa.com.tw\" -s \"$(echo \"��Ʈw%sCAR2033�����槹��\"\"\\nContent-Type: text/plain; charset=\\\"big5\\\"\")\" -c \" \" brian.wang@tmnewa.com.tw",DBName);
			/*sprintf_s(cmd_stmt, sizeof cmd_stmt, "mail -s ��Ʈw%sCAR2033�����槹�� brian.wang@tmnewa.com.tw ",DBName);*/
			printf("[%s]\n", cmd_stmt);
			rc = system(cmd_stmt);
		}
	}
	printf("-----THE END-----\n");

errexit:
	printf("-- Query_card -- SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
	return SQLCODE;     
}
/*----------------------------------------------------------------------------*/
long car_get_db()
{
	int rc=0;
	
	if (db_select(DBName) == False) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
		return M_CM_DB_NOTOPEN;
	}
	
	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
	 	return rc;
	}
	
	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}
	
	return M_CM_OK;
}
/*----------------------------------------------------------------------------*/
long Query_policy()
{
$char FormFile[N_FILE+1];
$char sIpolicy[21],sIofficer[11],sIassured[13],sIendorse[21],sIout_number[12];
$char stmt[2048], sStmt1[512], sStmt2[512],stmt1[2048],stmt2[2048],stmt3[1024],sStmt3[512], sStmt4[512],stmt9[101];
$char stmp_rec[1024],stmt_ins[2048],stmp[512],stmt_pro[2048],stmt_com[2048],stmt_cu[2048],stmt_cu2[1024],stmt_npost[1024];
$char stmt_ins_eb[2048],stmt_cu_eb[1024],stmt_pro_eb[256],stmt_com_eb[256],stmt_cmp[2048],stmt_comp[2048];
$int  rc=0,sIbatch_no=0,iCountDeny=0,out_draw=0,out_temp=0,out_temp2=0;
char  errmsg[201]; 
$char fcard_class[2],npost_recipient[140],apost_zip[CA_ZIP],apost_address[91],irelative_ply[21],dply_close[11];
$char sFullName[21];
$char eb_ipolicy[21],eb_ipolicy1[6],eb_ipolicy2[11],eb_ilast_ply[21],eb_ilast_ply1[6],eb_ilast_ply2[11],eb_itmp_policy[21],eb_nassured[121],eb_iassured[13],eb_apayment[91],eb_apost_address[91],eb_aassured[91];
$char eb_ibrand[9],eb_iengine[21],eb_dply_begin[11],eb_dply_end[11],eb_npost_recipient[121];
$char eb_apost_zip[CA_ZIP],eb_napplicant[121],eb_iroute[21];
$char co_place[2],eb_nchi_abv[21],eb_nchi_abv1[5],eb_nchi_abv2[5],eb_npresident[11],eb_iofficer[11],eb_dply_close[11],eb_nequipment[31],eb_fmail_type[2],eb_ileader[11];
$char eb_iins_type[7],eb_nins_type[29],eb_dcreate[24],sDateTime[22];
$float eb_mcar_price=0;
$int eb_mdml_prem=0,eb_mdml_prem1=0,eb_mdeduct=0,eb_minjured_cover=0,eb_mdamage_cover=0,eb_mins_premium=0,eb_irate_ym,eb_idb=0;
$char sToday[21],sToday1[21],sToday2[21],eb_ireceipt[20],m2[251],m13[80],m18[20],eb_mcar_price_char[10],eb_drate_ym[5];
$char eb_minjured_tmp[6],eb_mdamage_tmp[6],eb_mdeduct_tmp[19],eb_mins_premium_tmp[19];
$char sIrouteNote[3],outNote[16];
$char ipolicy1[21],ipolicy2[21],sIpolicy1[21],sIpolicy2[21],itype[1],dreceipt[11],idb[3],eb_chk_pr[4],chk_cpcr[4],chk_cpcr2[4];
$int  cntIroute=0,mdiscount=0,count_ply=0,count_ply2=0,cnt_out=0,cnt_cpcr=0,cnt_cpcr2=0;
$char iins_type[7],icar_type[3],dpolicy[11],drate[5],fcar_class[2],eb_dpolicy[11];
$char cmp_provision[6],com_provision[6],iins_provision1[6],iins_provision2[6],iins_provision3[6];
$char dbegin0_yy[4],dbegin0_mm[3],dbegin0_dd[3],dbegin1_yy[4],dbegin1_mm[3],dbegin1_dd[3];
$char dbegin2_yy[4],dbegin2_mm[3],dbegin2_dd[3],dbegin3_yy[4],dbegin3_mm[3],dbegin3_dd[3],dbegin4_yy[4],dbegin4_mm[3],dbegin4_dd[3];
$char dbegin0[11],dbegin1[11],dbegin2[11],dbegin3[11],dbegin4[11];
$char dbegin00[11],dbegin11[11],dbegin22[11],dbegin33[11],dbegin44[11];
$char iprovision1[6],drate1[4],iclass1[2],dbegin[11];
$char iins_provision_add[22],provision_add[6],iprovision_add[6],nprovision_add[6];
$char fins_grp[2],fkind[2],icomp[3];
$int qserial=0,cnt_cmp=0,cnt_com=0,cnt_pro=0,cnt_pro_cmp=0,cnt_pro_cmp2=0;
$int cnt_cmp2=0,cnt_com2=0,err_cmp=0,err_com=0;
$char ireceipt_bgn[11],ireceipt_end[11],ireceipt1_final[11];
$char fp0_tmp[1024],fp0_tmp2[512];
$char chk_rate_8788[3],chk_eb_rate_8788[3];
$char stmt_ncont[1024],ncontract[21],viins_type[7],ncontent1[81],eb_dply_begin_W[11];
$char stmt_feterms[1024],feterms[2];
$char iabn_type[2],fout_note[2];
$char sIrouteNote2[3];
$int cntIroute2=0;
$int cnt_prov=0,cnt_prov_chk=0;

$char nequipment[31];
$int f20230601=0,cnt55=0;

	$WHENEVER SQLERROR GOTO errexit;
	$SET LOCK MODE TO WAIT;
	$BEGIN WORK;
	
	$SELECT kPgNum_Line, nForm_File
	   INTO $PgLine, $FormFile
	   FROM Form
	  WHERE ksys_grp="CA" AND kPgmID = 306;
	
	$UPDATE cu_code_data
	    SET ncode = 'N'
	  WHERE itype = 'OT'
	    AND icode = '3072';
	
	if(strlen(trim(cdate)) == 0 )
	{
		strcpy(cdate1,cm_cdate_str(cm_today()));
		sprintf_s(sWhere, sizeof sWhere, " AND a.dout_trans is null ");
		strcpy(sDdate,cm_to_infdate(cdate1));
	}
	else
	{
	    strcpy(sDdate,cm_to_infdate(cdate));
	    strcpy(sDdate,trim(sDdate));
		
	    strcpy(sDdate0,cm_from_infdate_100(sDdate));	/* CYY/MM/DD */
	    strcat(sDdate0,"/00:00");			/* CYY/MM/DD/hh:mm */
	    strcpy(sDdate1,cm_sysd_edatetime(sDdate0));	/* YYYY-MM-DD hh:mm */
	    strcat(sDdate1,":00");				/* YYYY-MM-DD hh:mm:ss */
		
	    printf("sDdate1[%s]\n",sDdate1);
		
	    strcpy(sDdate0,cm_from_infdate_100(sDdate));	
	    strcat(sDdate0,"/23:59");
	    strcpy(sDdate2,cm_sysd_edatetime(sDdate0));
	    strcat(sDdate2,":59");
		
	    printf("sDdate2[%s]\n",sDdate2);
		
	    sprintf_s(sWhere, sizeof sWhere, " AND a.dout_trans between '%s' and '%s' ",sDdate1,sDdate2);
	
	    $SELECT first 1 dwork
	       INTO $cdate2
	       FROM cm_wrktbl
	      WHERE dwork < $sDdate
	      ORDER BY 1 desc;
	    strcpy(cdate1,cm_from_infdate_100(cdate2));
	    printf("172---sDdate[%s]\n",sDdate);        
            strcpy(sDdate,cdate2);
	    printf("174---sDdate[%s]\n",sDdate);
	}
	printf("-----ñ���� : [%s]\n-----",sDdate);
	strcpy(sDpolicy_Year,substring(sDdate,7,4));
	printf("-----sDpolicy_Year[%s]\n",sDpolicy_Year);
	printf("-----cdate1 = [%s]-----\n",cdate1);
	
	/*
	dsys = cm_ymd_cdate(cdate);
	cm_char_split_3ymd(cdate,syy,smm,sdd);
	*/
	
	cm_char_split_3ymd(cdate1,syy,smm,sdd);
	sprintf_s(sdate, sizeof sdate,"%s%s%s",syy,smm,sdd);
	printf("-----sdate = [%s]-----\n",sdate);
	
	strcpy(FormFile,rtrim(FormFile));
	sprintf_s(OutFile, sizeof OutFile,"%s_policy.tx",sdate);
	
	rgu_init_report(FormFile,OutFile);
	
	strcpy(FileName_1," ");
	strcpy(Fname_1," ");
	sprintf_s(Fname_1, sizeof Fname_1,"�e�~�O��C�L���~����[%s].txt",sdate);
	sprintf_s(FileName_1, sizeof FileName_1,"%s/rptftp/%s",sApHome,Fname_1);
	printf("--FileName_1--[%s]\n",FileName_1);
	fp=fopen(FileName_1,"w");
	
	strcpy(FileName_2," ");
	strcpy(Fname_2," ");
	sprintf_s(Fname_2, sizeof Fname_2,"%s_outnumber.txt",sdate);
	sprintf_s(FileName_2, sizeof FileName_2,"%s/batchfile/%s",sApHome,Fname_2);
	printf("--FileName_2--[%s]\n",FileName_2);
	fp0=fopen(FileName_2,"w");
	
	strcpy(FileName_3," ");
	strcpy(Fname_3," ");
	sprintf_s(Fname_3, sizeof Fname_3,"%s_EB.txt",sdate);
	sprintf_s(FileName_3, sizeof FileName_3,"%s/batchfile/%s",sApHome,Fname_3);
	printf("--FileName_3--[%s]\n",FileName_3);
	fp1=fopen(FileName_3,"w");    
	
	cnt_err = 0;
	countp = 0;
	cnt_getnum = 0;
	sqlnf = 0;
	cnt_out = 0;

	/*��ӱ���*/
	$create temp table ca3072_cmp_tmp
	(
	  ipolicy      char(20),
	  iprovision   char(5),
	  qserial      int
	) with no log;
	$create index ca3072_cmp_ix1 on ca3072_cmp_tmp(ipolicy);
	/*�@�P����*/
	$create temp table ca3072_com_tmp
	(
	  ipolicy      char(20),
	  iprovision   char(5),
	  qserial      int
	) with no log;
	$create index ca3072_com_ix1 on ca3072_com_tmp(ipolicy);
	/*�I�ر���*/
	$create temp table ca3072_pro_tmp
	(
	  ipolicy      char(20),
	  iprovision   char(5),
	  qserial      int
	) with no log;
	$create index ca3072_pro_ix1 on ca3072_pro_tmp(ipolicy);
 
	/****************/
	/**  �e�~�z��  **/
	/****************/
	
	sprintf_s(stmt, sizeof stmt," SELECT ipolicy, iassured, fcard_class, itmp_policy, iroute FROM ca_out_temp ");
	$PREPARE out_policy_all FROM $stmt;
	$DECLARE PLY_CUR_ALL CURSOR FOR out_policy_all;
	$OPEN    PLY_CUR_ALL;
	printf("-----> into PLY_CUR \n");
	printf("stmt[%s]\n\n\n",stmt);
	for(;;)
	{
		$FETCH PLY_CUR_ALL INTO $sIpolicy, $sIassured, $fcard_class, $itmp_policy, $iroute;
		if (SQLCODE == SQLNOTFOUND) break;
		strcpy(itmp_policy,trim(itmp_policy));
		strcpy(iroute,trim(iroute));
		strcpy(sFullName, get_car_full_db(sIpolicy));
		  	
		printf("-----210 ipolicy:[%s]-----\n",sIpolicy);
		printf("-----211 itmp_policy:[%s]-----\n",itmp_policy);
		printf("-----212 iroute:[%s]-----\n",iroute);
		
		/*** B2C������O�A�ݦ�����n�O�Ѥ���~���H�e�ʧ@ ***/	    	
		if(strncmp(itmp_policy,"17N",3) == 0 && strncmp(iroute, "JB",2) == 0)
		{
		    sprintf_s(stmt, sizeof stmt,"SELECT count(*) "
		             "  FROM %s:ca_quotation "
		             " WHERE iquote = '%s' "
		             "   AND dcust_apply is not null ",sFullName,itmp_policy);
			$PREPARE est_pre FROM $stmt;
			$EXECUTE est_pre INTO $out_cnt;
			printf("out_cnt[%d]\n",out_cnt); 
			if(out_cnt == 0) 
			{
			    $DELETE 
			       FROM ca_out_temp 
			      WHERE ipolicy = $sIpolicy;		
			    continue;
			}
		}
		
		/*** ���P�_:�p�G���]�w��ca_out_draw��(car344)�A�åBfout_type = '0'�A�h�����H�e�ʰ� ***/
		out_draw = 0;
		$SELECT count(*)
		   INTO $out_draw
		   FROM ca_out_draw 
		  WHERE ipolicy = $sIpolicy
		AND fout_type = '0';
		printf("out_draw[%d]\n",out_draw);
		if(out_draw > 0 ) 
		{
		    $DELETE 
			   FROM ca_out_temp
			  WHERE ipolicy = $sIpolicy;
			continue;
		}
	    
		/* �ˮ֭Ӹ�O�_�w����ϥ� */
		if(fcard_class[0]=='2')
		{
		    iCountDeny = 0;
			$SELECT count(*) INTO $iCountDeny
			   FROM cm_personal_deny
			  WHERE iassured = $sIassured
			    AND (funrenew_ins[1,1] = '1' OR funquery_ins[1,1] = '1' OR fdelete_ins[1,1] = '1')
			    AND ddeny <= today 
			    AND (dexpire is null or dexpire >= today);
			if (iCountDeny > 0)
			{		
			    cnt_err++;
			    fprintf(fp,"�O�渹�G%s\t�Ӹ�w����\n",sIpolicy);
			    $DELETE 
			       FROM ca_out_temp
			      WHERE ipolicy = $sIpolicy;
			        continue;
			}
		}
	}   
	$CLOSE PLY_CUR_ALL;
	$FREE  PLY_CUR_ALL;
	$COMMIT WORK;
	$BEGIN WORK;
	
	/************************/
	/**  ���ڽs��������  **/
	/************************/
	$SELECT count(*) 
	   INTO $cnt_out 
	   FROM ca_out_temp
	  WHERE fcard_class = '2';
	printf("---cnt_out[%d]\n",cnt_out);
	strcpy(sToday, cm_cdate_str_100(cm_today()));
	iTryCnt = 0;
	AGAIN:
	res1 = cm_mget_serial_num("CM", "R1", "0", "00", sToday, &cnt_out, ireceipt_bgn, ireceipt_end);
	printf("-------ireceipt_bgn[%s] ireceipt_end[%s]\n\n",ireceipt_bgn,ireceipt_end);

	if (res1 != 0)
	{
		iTryCnt++;
		if (iTryCnt > 20)  
		{
		    fprintf(fp,"���������~\n");
		    sprintf_s(cmd_stmt, sizeof cmd_stmt, "mailx -r \"ipisnew@tmnewa.com.tw\" -s \"$(echo \"��Ʈw%sCAR3072���������~\"\"\\nContent-Type: text/plain; charset=\\\"big5\\\"\")\" -c \" \" stevechiang@tmnewa.com.tw,changyintsun@tmnewa.com.tw",DBName);
		    /*sprintf_s(cmd_stmt, sizeof cmd_stmt, "mail -s ��Ʈw%sCAR3072���������~ stevechiang@tmnewa.com.tw changyintsun@tmnewa.com.tw ",DBName);*/
		    printf("[%s]\n", cmd_stmt);
		    rc = system(cmd_stmt);
		    $COMMIT WORK;
		    $ROLLBACK WORK;
		    return res1;
		}
		sleep(1);
		goto  AGAIN;
	}
	
	ireceipt1 = atoi(ireceipt_bgn);
	printf("-------ireceipt1[%d]\n\n",ireceipt1);
	ireceipt2 = atoi(ireceipt_end);
	printf("-------ireceipt2[%d]\n\n",ireceipt2);

	/**************************/
	/**  �@���e�~�ɮײ��s  **/
	/**************************/
	/*--------------------------------------------------------------------------------------------------------------------------------------*/
	/* dpolicy >= '01/11/2016' 1041228004_C1_B2C²�T��׵o�e�y�{�ק� */
	/*105.05.13 �]�e�~�C�L�Ƶ{�ѭ��00:45�אּ�C��15:00 ���P�_�w�鵲������l�O���ɤΥ��鵲�O��h�����̷s�O���ɸ�� */
	/*---------------------------------------------------------------------------------------------------------------------------------------------------*/
	sprintf_s(stmt, sizeof stmt," SELECT ipolicy, ibatch_no, iofficer, iassured, "
	                            "       CASE WHEN ((date('%s')) - date(to_char((date('%s')),'01/01/%%Y'))) < 9 THEN "
	                            "       'Z'||to_char((date('%s')),'%%y')||'00'||((date('%s')) - date(to_char((date('%s')),'01/01/%%Y')))+1 "
	                            "       ELSE CASE WHEN ((date('%s')) - date(to_char((date('%s')),'01/01/%%Y'))) < 99 THEN "
	                            "       'Z'||to_char((date('%s')),'%%y')||'0'||((date('%s')) - date(to_char((date('%s')),'01/01/%%Y')))+1 "
	                            "       ELSE 'Z'||to_char((date('%s')),'%%y')||((date('%s')) - date(to_char((date('%s')),'01/01/%%Y')))+1 END END ,"
	                            "       fcard_class, irelative_ply ,"
	                            "       case when trim(apost_address)=''   then apayment_zip else apost_zip end,"
	                            "       case when trim(apost_address)=''   then apayment     else apost_address end,"
	                            "       itmp_policy ,iroute, dply_close, icar_type, pdate, drate_ym, "
	                            "       case when (drate_ym <= '87' and dply_begin between '01/01/2017' and '12/31/2017' and pdate > '01/08/2018') then 'N1' "
	                            "            when (drate_ym = '88' and dply_begin between '01/01/2018' and '12/31/2018' and pdate > '12/31/2017') then 'N2' "
	                            "            else 'Y' end,"
	                            "       iabn_type , fout_note, nequipment,"
	                            "       case when (dply_begin >= '06/01/2023' and pdate >= '06/01/2023') then 1 else 0 end"
	                            "   FROM ca_out_temp "
	                            "  WHERE ipolicy[6,7] != 'EB'",sDdate,sDdate,sDdate,sDdate,sDdate,sDdate,sDdate,sDdate,sDdate,sDdate,sDdate,sDdate,sDdate);
	$PREPARE out_policy FROM $stmt;
	$DECLARE PLY_CUR CURSOR WITH HOLD FOR out_policy;
	$OPEN    PLY_CUR;
	printf("-----> into PLY_CUR \n");
	printf("stmt[%s]\n\n\n",stmt);
	for(;;)
	{
		$FETCH PLY_CUR INTO $sIpolicy, $sIbatch_no, $sIofficer, $sIassured, $sIout_number,
		                    $fcard_class, $irelative_ply, $apost_zip, $apost_address,
		                    $itmp_policy, $iroute, $dply_close , $icar_type, $dpolicy, $drate, $chk_rate_8788, 
		                    $iabn_type, $fout_note, $nequipment, $f20230601;
		                     
		if (SQLCODE == SQLNOTFOUND)  break;
		
		strcpy(itmp_policy,trim(itmp_policy));
		strcpy(iroute,trim(iroute));
		strcpy(dply_close,trim(dply_close));
		strcpy(sFullName, get_car_full_db(sIpolicy));
		strcpy(apost_zip      , rtrim(apost_zip));
		strcpy(apost_address  , rtrim(apost_address));
		
		if(chk_rate_8788[0] != 'Y' && iabn_type[0] != "S") 
		{
		    cnt_err++;
		    if(chk_rate_8788[1] == '1')
		    fprintf(fp,"�O�渹�G%s\t 2017�ͮġA�O�v��87�Añ��I�20180108 \t\n",sIpolicy);
		    else 
		    fprintf(fp,"�O�渹�G%s\t 2018�ͮġA�O�v88�Añ��I���20171231 \t\n",sIpolicy);
		    continue;
		}
		
		if(fout_note[0] == 'N' ) 
		{
		    fprintf(fp,"�O�渹�G%s\t �j���I�P���N�I�ݦP�ɲ��s�L�� \t\n",sIpolicy);
		    continue;
		}
		
		/* 131775 ���OE�W�L2�Ӥ뤣�e�~ (1120111003_C01)*/
		if(fout_note[0] == 'S' || fout_note[0] == 'E')
		{
		    fprintf(fp,"�O�渹�G%s\t �j���Iñ��W�L��Ӥ를������N�I�X��A�����e�~ \t\n",sIpolicy);
		    continue;
		}
		
		printf("--552 countp[%d] \n",countp);
            
		if (fcard_class[0]=='2')
		{
			printf("--------ireceipt1[%d]",ireceipt1);
			printf("--------ireceipt2[%d]",ireceipt2);
			countp++;
			strcpy(sIout, itoa(countp));
			sIout_length = strlen(trim(sIout));
			printf("------sIout[%s],sIout_length[%d]\n",sIout,sIout_length);
			strcpy(sIout_number,trim(sIout_number));
			for(k = sIout_length; k < 5; k++)
			strcat(sIout_number,"0");
			
			strcat(sIout_number,trim(sIout));
			strcpy(sIout_number,trim(sIout_number));
			printf("-----�e�~�O��Ǹ�:[%s]-----\n",sIout_number);
		}
		else
			strcpy(sIout_number," ");

		printf("--571countp[%d] \n",countp);
                
		/*�P�_�ۥΡB��~*/
		$SELECT case when fcar_class = '1' then 'C' else 'S' end
		   INTO $fcar_class
		   FROM car_type
		  WHERE icode = $icar_type AND fclass = '1';
		
		if(SQLCODE == SQLNOTFOUND) strcpy( fcar_class, " ");
		
		strcpy(drate,trim(drate));
		strcpy(fcar_class,trim(fcar_class));
		printf("drate[%s],dpolicy[%s] \n\n",drate,dpolicy);
		
	        stmp[0] = '\0';
		sprintf_s(stmp, sizeof stmp," AND a.drate_ym = '%s' AND (a.iclass = '%s' OR a.iclass = 'A') AND a.dbegin <= '%s' "
		                            " AND (a.dend >= '%s' OR a.dend is null OR a.dend = ' ') "
		                            " AND (a.dexpire is null or a.dexpire = ' ' or dexpire >= today)",drate,fcar_class,dpolicy,dpolicy);
	        printf("stmp[%s]\n\n",stmp);
	        
	        strcpy(npost_recipient, "");
		if(strlen(dply_close)>0)
		{
			sprintf_s(stmt, sizeof stmt,"SELECT count(*)"
			                            "  FROM %s:ori_ins_type "
			                            " WHERE ipolicy= '%s' " ,sFullName,sIpolicy);
			                            
			sprintf_s(stmt_npost, sizeof stmt,"SELECT CASE WHEN trim(npost_recipient)='' then "
			                                  "            CASE WHEN fsex_appl IN ('1','2') THEN napplicant|| '�@�g�v��'"
			                                  "            ELSE napplicant|| '�@�v��' END"
			                                  "       ELSE npost_recipient END"
			                                  "  FROM %s:original_ply "
			                                  " WHERE ipolicy= '%s' " ,sFullName,sIpolicy);
			                            
			sprintf_s(stmt_ins, sizeof stmt_ins,"SELECT a.iins_type,b.fins_grp,b.fkind,trim(nvl(a.provision,' '))||';' , "
			                                    "       nvl(c.cmp_provision,' '),"
			                                    "       nvl(c.com_provision,' '),"
			                                    "       nvl(c.iins_provision1,' '),"
			                                    "       nvl(c.iins_provision2,' '),"
			                                    "       nvl(c.iins_provision3,' '),"
			                                    "       b.qserial"
			                                    "  FROM %s:ori_ins_type a,insurance_type b,outer ca_prov_irate c"
			                                    " WHERE a.iins_type = b.iins_type AND a.iins_type = c.iins_type AND a.drate_ym = c.irate AND (c.iclass = '%s' OR c.iclass = 'A') AND a.ipolicy= '%s' " ,sFullName,fcar_class,sIpolicy);
		}
		else
		{
			sprintf_s(stmt, sizeof stmt,"SELECT count(*)"
			                            "  FROM %s:ply_ins_type "
			                            " WHERE ipolicy= '%s' " ,sFullName,sIpolicy);
			                            
			sprintf_s(stmt_npost, sizeof stmt,"SELECT CASE WHEN trim(npost_recipient)='' then "
			                                  "            CASE WHEN fsex_appl IN ('1','2') THEN napplicant|| '�@�g�v��'"
			                                  "            ELSE napplicant|| '�@�v��' END"
			                                  "       ELSE npost_recipient END"
			                                  "  FROM %s:policy "
			                                  " WHERE ipolicy= '%s' " ,sFullName,sIpolicy);
			                            
			sprintf_s(stmt_ins, sizeof stmt_ins,"SELECT a.iins_type,b.fins_grp,b.fkind,trim(nvl(a.provision,' '))||';' , "
			                                    "       nvl(c.cmp_provision,' '),"
			                                    "       nvl(c.com_provision,' '),"
			                                    "       nvl(c.iins_provision1,' '),"
			                                    "       nvl(c.iins_provision2,' '),"
			                                    "       nvl(c.iins_provision3,' '),"
			                                    "       b.qserial"
			                                    "  FROM %s:ply_ins_type a,insurance_type b,outer ca_prov_irate c"
			                                    " WHERE a.iins_type = b.iins_type AND a.iins_type = c.iins_type AND a.drate_ym = c.irate AND (c.iclass = '%s' OR c.iclass = 'A') AND a.ipolicy= '%s'" ,sFullName,fcar_class,sIpolicy);
		}
		$PREPARE iins_cnt FROM $stmt;
		$EXECUTE iins_cnt INTO $iins_count;
		
		$PREPARE npost FROM $stmt_npost;
		$EXECUTE npost INTO $npost_recipient;	
		strcpy(npost_recipient, rtrim(npost_recipient));
		
	        sprintf_s(fp0_tmp, sizeof fp0_tmp,"17%s\t%s\t%s\t%s\t%s\t%d\t",sIpolicy,sIout_number,npost_recipient,apost_zip,apost_address,iins_count);
	    
		cnt_prov_chk = 0;
		if(fcard_class[0]=='2')
		{
			/* �������������������������������������������� �ھ��I�ؼ����������ڥN�� �������������������������������������������� */
			printf("stmt_ins[%s]\n",stmt_ins);
			cnt_cmp = 0;
			cnt_com = 0;
			$PREPARE iins FROM $stmt_ins;
			$DECLARE iins_cur CURSOR FOR iins;
			$OPEN    iins_cur;
			for(;;)
			{
				$FETCH iins_cur INTO $iins_type,$fins_grp,$fkind,$iins_provision_add,
				                     $cmp_provision,$com_provision,$iins_provision1,$iins_provision2,$iins_provision3,$qserial;
				if (SQLCODE == SQLNOTFOUND) break;
				strcpy(iins_provision_add,trim(iins_provision_add));
				strcpy(iins_type,trim(iins_type));
				
				strcpy(cmp_provision,trim(cmp_provision));
				strcpy(com_provision,trim(com_provision));
				strcpy(iins_provision1,trim(iins_provision1));
				strcpy(iins_provision2,trim(iins_provision2));
				strcpy(iins_provision3,trim(iins_provision3));
				
				cnt_prov = 0;
				$SELECT count(*) INTO $cnt_prov FROM ca_prov_irate WHERE iins_type = $iins_type AND irate = $drate AND (iclass = $fcar_class OR iclass = 'A') ;
				
				printf("cnt_prov[%d]cnt_prov_chk[%d] sIpolicy[%s]\n",cnt_prov,cnt_prov_chk,sIpolicy);
				if (cnt_prov == 0) 
				{
					fprintf(fp,"�O�渹�G%s\t�ӶO�v���I�صL�]�w��������!\t�O�v[%s]�I�إN��[%s]\n",sIpolicy,drate,iins_type);
					printf("�O�渹�G%s\t�ӶO�v���I�صL�]�w��������!\t�O�v[%s]�I�إN��[%s]\n",sIpolicy,drate,iins_type);
					cnt_prov_chk++;
					continue;
				}

				/* ���[���� */
				sprintf_s(stmt_cu, sizeof stmt_cu,"select trim(iprovision)||';',iprovision from ca_provision_main where iprovision not in ('C','E')");
				printf("stmt_cu[%s]\n",stmt_cu);
				$PREPARE ins_cu FROM $stmt_cu;
				$DECLARE ins_cucode CURSOR FOR ins_cu;	 
				$OPEN    ins_cucode;
				for(;;)
				{
					$FETCH ins_cucode INTO $iprovision_add,$nprovision_add;
					strcpy(iprovision_add,trim(iprovision_add));
					strcpy(nprovision_add,trim(nprovision_add));
					if (SQLCODE == SQLNOTFOUND) break; 
					printf("iins_provision_add[%s] iprovision_add[%s] nprovision_add[%s]\n",iins_provision_add,iprovision_add,nprovision_add);
					if(strstr(iins_provision_add,iprovision_add) != NULL)
					{
						printf("--IN\n");
						strcpy(nprovision_add,trim(nprovision_add));
						printf("--iprovision_add[%s]\n",iprovision_add);
						printf("--nprovision_add[%s]\n",nprovision_add);
						/* 1071226006_SC4_�w���ƫ����վ�(���²v+�ĤT�H�d��) */
						if (strcmp(iprovision_add,"P;") ==0 || strcmp(iprovision_add,"Q;") ==0 || strcmp(iprovision_add,"M;") ==0)
						{
							/* �w��D�I01�B05�B09�B11�B181�P�_����P�BQ�BM���� */
							/* 1130510009_C06_�s�W�q�ʨ��M�ݰӫ~(�L��) */
							if (strcmp(iins_type,"01") == 0  || strcmp(iins_type,"05") == 0  || strcmp(iins_type,"09") == 0  || strcmp(iins_type,"11") == 0  || strcmp(iins_type,"181") == 0 ||
						        strcmp(iins_type,"201") == 0 || strcmp(iins_type,"205") == 0 || strcmp(iins_type,"209") == 0 || strcmp(iins_type,"211") == 0)
							{
								$INSERT INTO ca3072_pro_tmp (ipolicy,iprovision,qserial) VALUES($sIpolicy,$nprovision_add,100);
							}
							else 
								printf("Do Nothing \n");
						}
						else if (strcmp(iprovision_add,"V;") ==0)
						{
							/* V���� 09�n�վ㬰V1  31�B32��V2 */
							/* 1130510009_C06_�s�W�q�ʨ��M�ݰӫ~(�L��) */
							if (strcmp(iins_type,"09") == 0 || strcmp(iins_type,"209") == 0) strcpy(nprovision_add,"V1");
							else if (strcmp(iins_type,"31") == 0 || strcmp(iins_type,"32") == 0 || strcmp(iins_type,"231") == 0 || strcmp(iins_type,"232") == 0) strcpy(nprovision_add,"V2");
							$INSERT INTO ca3072_pro_tmp (ipolicy,iprovision,qserial) VALUES($sIpolicy,$nprovision_add,100);
						}
						else 
							$INSERT INTO ca3072_pro_tmp (ipolicy,iprovision,qserial) VALUES($sIpolicy,$nprovision_add,100);

						printf("iins_type[%s] nprovision_add[%s] \n",iins_type,nprovision_add);
					}

			    }
				$CLOSE ins_cucode;
				$FREE  ins_cucode;	
	
				/*��ӱ���*/	
				if(strlen(cmp_provision) != 0)
				{
					$INSERT INTO ca3072_cmp_tmp (ipolicy,iprovision,qserial) VALUES($sIpolicy,$cmp_provision,1);
					cnt_cmp++;
				}
				
				/*�@�P����*/
				if(strlen(com_provision) != 0)
				{
					$INSERT INTO ca3072_com_tmp (ipolicy,iprovision,qserial) VALUES($sIpolicy,$com_provision,1);
					cnt_com++;
				}
				
				/*���ڤ@*/
				if(strlen(iins_provision1) != 0 )
					$INSERT INTO ca3072_pro_tmp (ipolicy,iprovision,qserial) VALUES($sIpolicy,$iins_provision1,$qserial);
				
				/*���ڤG*/
				if(strlen(iins_provision2) != 0 )
					$INSERT INTO ca3072_pro_tmp (ipolicy,iprovision,qserial) VALUES($sIpolicy,$iins_provision2,$qserial);
				
				/*���ڤT*/
				if(strlen(iins_provision3) != 0 )
					$INSERT INTO ca3072_pro_tmp (ipolicy,iprovision,qserial) VALUES($sIpolicy,$iins_provision3,$qserial);  
	
				printf("iins_provision_add[%s] cmp_provision[%s] com_provision[%s] iins_provision1[%s] iins_provision2[%s] iins_provision3[%s] \n",
				iins_provision_add,cmp_provision,com_provision,iins_provision1,iins_provision2,iins_provision3);   
			}
			$CLOSE iins_cur;
			$FREE  iins_cur;

			/*��ӱ���*/
			iprovision1[0] = '\0';
			drate1[0] = '\0';
			iclass1[0] = '\0';
			dbegin1[0] = '\0';
			dbegin00[0] = '\0';
	
			cnt_cmp2 = 0;
			sprintf_s(stmt_cmp, sizeof stmt_cmp,"SELECT unique a.iprovision,a.drate_ym,a.iclass,a.dbegin,max(b.qserial),count(*) "
			                                    "  FROM ca_provision a, ca3072_cmp_tmp b"
			                                    " WHERE a.iprovision = b.iprovision "
			                                    "   AND b.ipolicy= '%s' %s"
			                                    " GROUP BY 1,2,3,4"
			                                    " ORDER BY 5,1" ,sIpolicy,stmp);
			$PREPARE cp FROM $stmt_cmp;
			printf("stmt_cmp[%s]",stmt_cmp);
			$DECLARE cmp_cur CURSOR FOR cp; 
			$OPEN    cmp_cur;
			for(;;)
			{
				printf("IN--stmt_cmp\n");
				iprovision1[0] = '\0';
				drate1[0] = '\0';
				iclass1[0] = '\0';
				dbegin00[0] = '\0';
				fp0_tmp2[0] = '\0';
				
				$FETCH cmp_cur INTO $iprovision1,$drate1,$iclass1,$dbegin,$cnt_cmp2;
				
				if (SQLCODE == SQLNOTFOUND) break;
				strcpy(dbegin0,cm_from_infdate_100(dbegin));
				cm_char_split_3ymd(dbegin0,dbegin0_yy,dbegin0_mm,dbegin0_dd);
				sprintf_s(dbegin00, sizeof dbegin00,"%s%s%s",dbegin0_yy,dbegin0_mm,dbegin0_dd);
				strcpy(iprovision1,trim(iprovision1));
				strcpy(drate1,trim(drate1));
				strcpy(iclass1,trim(iclass1));
				strcpy(dbegin00,trim(dbegin00));
				printf("iprovision1[%s] drate1[%s] iclass1[%s] dbegin00[%s]\n",iprovision1,drate1,iclass1,dbegin00);
				sprintf_s(fp0_tmp2, sizeof fp0_tmp2,"%s_%s_%s_%s,",iprovision1,drate1,iclass1,dbegin00);
				strcat(fp0_tmp,fp0_tmp2);
			}      
			/*$DELETE FROM ca3072_cmp_tmp;*/
			$CLOSE cmp_cur;
			$FREE  cmp_cur;

			/*�@�P����*/
			cnt_com2 = 0;
			sprintf_s(stmt_com, sizeof stmt_com,"SELECT unique a.iprovision,a.drate_ym,a.iclass,a.dbegin,max(b.qserial),count(*) "
			                                    "  FROM ca_provision a, ca3072_com_tmp b"
			                                    " WHERE a.iprovision = b.iprovision "
			                                    "   AND b.ipolicy= '%s' %s"
			                                    " GROUP BY 1,2,3,4"
			                                    " ORDER BY 5,1" ,sIpolicy,stmp);
			$PREPARE co FROM $stmt_com;
			printf("stmt_com[%s]",stmt_com);
			$DECLARE com_cur CURSOR FOR co; 
			$OPEN    com_cur;
			for(;;)
			{
				printf("IN--stmt_com\n");
				iprovision1[0] = '\0';
				drate1[0] = '\0';
				iclass1[0] = '\0';
				dbegin00[0] = '\0';
				fp0_tmp2[0] = '\0';
				
				$FETCH com_cur INTO $iprovision1,$drate1,$iclass1,$dbegin,$cnt_com2;
				
				if (SQLCODE == SQLNOTFOUND) break;
				strcpy(dbegin0,cm_from_infdate_100(dbegin));
				cm_char_split_3ymd(dbegin0,dbegin0_yy,dbegin0_mm,dbegin0_dd);
				sprintf_s(dbegin00, sizeof dbegin00,"%s%s%s",dbegin0_yy,dbegin0_mm,dbegin0_dd);
				strcpy(iprovision1,trim(iprovision1));
				strcpy(drate1,trim(drate1));
				strcpy(iclass1,trim(iclass1));
				strcpy(dbegin00,trim(dbegin00));
				printf("iprovision1[%s] drate1[%s] iclass1[%s] dbegin00[%s]\n",iprovision1,drate1,iclass1,dbegin00);
				sprintf_s(fp0_tmp2, sizeof fp0_tmp2,"%s_%s_%s_%s,",iprovision1,drate1,iclass1,dbegin00);
				strcat(fp0_tmp,fp0_tmp2);
			}
			/*$DELETE FROM ca3072_com_tmp;*/
			$CLOSE com_cur;
			$FREE  com_cur;
		    
			/*���ڤ@�B���ڤG�B���ڤT�B���[����*/
			cnt_pro_cmp = 0;
			$SELECT count(UNIQUE iprovision) INTO $cnt_pro_cmp FROM ca3072_pro_tmp WHERE ipolicy = $sIpolicy;
			
			/* 1120316006_SC5_�L��-���N�I���e�{�s�W���@�������������O�N��05�ή��s�X��t�ηs�W���@�����O */
			printf("--737 icar_type[%s],nequipment[%s] \n",icar_type,nequipment);
			if((strncmp(icar_type,"11",2) == 0) && (equip_cmp(nequipment,"115") == TRUE) && f20230601 > 0)
			{
				cnt55 = 0;
				sprintf_s(stmt, sizeof stmt,"SELECT count(*) FROM %s:ori_ins_type WHERE ipolicy= '%s' AND iins_type = '55'" ,sFullName,sIpolicy);
				$PREPARE iins55_cnt FROM $stmt;
				$EXECUTE iins55_cnt INTO $cnt55;
				printf("--744 cnt55[%d]\n",cnt55);
				if(cnt55 >0) 
				{
					$INSERT INTO ca3072_pro_tmp (ipolicy,iprovision,qserial) VALUES($sIpolicy,'DD',999);
					cnt_pro_cmp++;
				}
			}
			cnt_pro = cnt_pro_cmp;
			printf("--cnt_pro[%d]\n",cnt_pro);
			
			cnt_pro_cmp2 = 0;
			sprintf_s(stmt_pro, sizeof stmt_pro,"SELECT unique a.iprovision,a.drate_ym,a.iclass,a.dbegin,max(b.qserial) "
			                                    "  FROM ca_provision a, ca3072_pro_tmp b"
			                                    " WHERE a.iprovision = b.iprovision "
			                                    "   AND b.ipolicy= '%s' %s "
			                                    " GROUP BY 1,2,3,4"
			                                    " ORDER BY 5,1" ,sIpolicy,stmp);
			$PREPARE pr FROM $stmt_pro;
			$DECLARE pr_cur CURSOR FOR pr;
			$OPEN    pr_cur;
			for(;;)
			{
				iprovision1[0] = '\0';
				drate1[0] = '\0';
				iclass1[0] = '\0';
				dbegin00[0] = '\0';
				fp0_tmp2[0] = '\0';
				
				$FETCH pr_cur INTO $iprovision1,$drate1,$iclass1,$dbegin;
				
				if (SQLCODE == SQLNOTFOUND) break; 
				cnt_pro_cmp2++;
				strcpy(dbegin0,cm_from_infdate_100(dbegin));
				cm_char_split_3ymd(dbegin0,dbegin0_yy,dbegin0_mm,dbegin0_dd);
				sprintf_s(dbegin00, sizeof dbegin00,"%s%s%s",dbegin0_yy,dbegin0_mm,dbegin0_dd);
				strcpy(iprovision1,trim(iprovision1));
				strcpy(drate1,trim(drate1));
				strcpy(iclass1,trim(iclass1));
				strcpy(dbegin00,trim(dbegin00));
				printf("iprovision1[%s] drate1[%s] iclass1[%s] dbegin00[%s]\n",iprovision1,drate1,iclass1,dbegin00);
				sprintf_s(fp0_tmp2, sizeof fp0_tmp2,"%s_%s_%s_%s",iprovision1,drate1,iclass1,dbegin00); 
				strcat(fp0_tmp,fp0_tmp2);
				if(cnt_pro >1)
				{
					strcat(fp0_tmp,",");
					cnt_pro--;
				}
				else
					strcat(fp0_tmp,"");
			}
			/*$DELETE FROM ca3072_pro_tmp;*/
			$CLOSE pr_cur;
			$FREE  pr_cur;
	
			/*���~>1  CONTINUE*/
			if((cnt_cmp+cnt_cmp2) == 1 )
			{
				cnt_err++;
				fprintf(fp,"�O�渹�G%s\t���s��ӱ��妳�~!\t%s\n",sIpolicy,fp0_tmp);
				printf("�O�渹�G%s���s��ӱ��妳�~!%s\n",sIpolicy,fp0_tmp);
				countp--;
				strcpy(fp0_tmp,"");
				continue;
			}
			if((cnt_com+cnt_com2) == 1 )
			{
				cnt_err++;
				fprintf(fp,"�O�渹�G%s\t���s�@�P���ڦ��~!\t%s\n",sIpolicy,fp0_tmp);
				printf("�O�渹�G%s���s�@�P���ڦ��~!%s\n",sIpolicy,fp0_tmp);
				countp--;
				strcpy(fp0_tmp,"");
				continue;
			}
		
			if(cnt_pro_cmp != cnt_pro_cmp2)
			{
				cnt_err++;
				fprintf(fp,"�O�渹�G%s\t���s���ڤ��e���~!\t%s\n",sIpolicy,fp0_tmp);
				printf("�O�渹�G%s���s���ڤ��e���~!%s\n",sIpolicy,fp0_tmp);
				countp--;
				strcpy(fp0_tmp,"");
				continue;
			}
			
			if(cnt_prov_chk > 0)
			{
				cnt_err++;
				/*fprintf(fp,"�O�渹�G%s\�ӶO�v���I�صL�]�w��������!\t�O�v[%s]�I�إN��[%s]\n",sIpolicy,drate,iins_type);*/
				printf("�O�渹�G%scar167�L��������!%s\n",sIpolicy,fp0_tmp);
				countp--;
				strcpy(fp0_tmp,"");
				continue;
			}
			/* �������������������������������������������� �ھ��I�ؼ����������ڥN�� �������������������������������������������� */
	    	
			/*105.05.13 �e�~�O��P�_�鵲�Υ��鵲*/printf("--845 countp[%d] \n",countp);
			/*�O��i��L�s�⭶ �]��ireceipt1_final���^�ǳ̫��  �Yfinal > end �N����帹�X�w�g�Χ������^��ӳ浧����*/
			if(strlen(dply_close)>0)
			{
				if(ireceipt1 > ireceipt2)
					rc = ca_rpt_policy(sIpolicy, "", sIbatch_no, "1", FALSE, 0, " ", "", userid, "1", "1", DBName, "2", "", "", "", "0");
				else
					rc = ca_rpt_policy(sIpolicy, "", sIbatch_no, "1", FALSE, 0, " ", "", userid, "1", "1", DBName, "2", itoa(ireceipt1), ireceipt_end, ireceipt1_final, "0");
			}
			else
			{
				if(ireceipt1 > ireceipt2)
					rc = ca_rpt_policy(sIpolicy, "", sIbatch_no, "1", FALSE, 0, " ", "", userid, "1", "1", DBName, "3", "", "", "", "0");
				else
					rc = ca_rpt_policy(sIpolicy, "", sIbatch_no, "1", FALSE, 0, " ", "", userid, "1", "1", DBName, "3", itoa(ireceipt1), ireceipt_end, ireceipt1_final, "0");
			}
			
			printf("--------ireceipt1_final[%s]",ireceipt1_final);
			ireceipt1 = atoi(ireceipt1_final);
			printf("--863 countp[%d] \n",countp);
			
			if (rc != M_CM_OK) 
			{	             
				cnt_err++;
				fprintf(fp,"�O�渹�G%s\t�C�L��Ʀ��~!\n",sIpolicy);
				ireceipt1++;
				continue;
			}

			/* �^���i�e�~�O��Ǹ��j�B�i�L�����A�j�B�i�e�~���ɤ�j��O�����p�ɤέ�l�O�����p�� 103.05.16 add by larry (1030415003_C1)*/
			sprintf_s(sStmt1, sizeof sStmt1, " UPDATE %s:ply_relation "
			                                 "    SET iout_number = '%s',fprint = '1' , dout_trans = CURRENT "
			                                 "  WHERE ipolicy = '%s' ",sFullName,sIout_number,sIpolicy );
			$PREPARE update1 FROM $sStmt1;
			$EXECUTE update1;
			
			sprintf_s(sStmt2, sizeof sStmt2, " UPDATE %s:ori_ply_relation "
			                                 "    SET iout_number = '%s',fprint = '1' , dout_trans = CURRENT "
			                                 "  WHERE ipolicy = '%s' ",sFullName,sIout_number,sIpolicy );
			$PREPARE update2 FROM $sStmt2;
			$EXECUTE update2;
				
			ireceipt1++;
			printf("--------ireceipt11[%d]\n",ireceipt1);
		}
		else
		{
			/*** �^���j���I�L�����A�B�e�~���ɤ� ***/ 
			sprintf_s(stmt, sizeof stmt,"UPDATE %s:ply_relation "
			                            "   SET fprint = '1' , dout_trans = CURRENT "
			                            " WHERE ipolicy= '%s' " ,sFullName,sIpolicy);
			$PREPARE up_fprint FROM $stmt;
			$EXECUTE up_fprint;
			
			sprintf_s(stmt, sizeof stmt,"UPDATE %s:ori_ply_relation " 
			                            "   SET fprint = '1' , dout_trans = CURRENT "
			                            " WHERE ipolicy= '%s' " ,sFullName,sIpolicy);
			$PREPARE up_fprint1 FROM $stmt;
			$EXECUTE up_fprint1;
		}
		
		fprintf(fp0,fp0_tmp);
		if(err_cmp <= 0 && err_com <= 0)
			fprintf(fp0,"\t\n");
		
		DELE:
		$DELETE 
		   FROM ca_out_temp 
		  WHERE ipolicy = $sIpolicy;
		
		count_ply = 0;
		
		$SELECT count(*)
		   INTO $count_ply
		   FROM ca_out_temp
		  WHERE ipolicy = $sIpolicy;
		
		printf("--------count_ply[%d] sIpolicy[%s] \n",count_ply,sIpolicy);
		
		if(count_ply != 0)  goto  DELE;
		
		/* 10��commit �@�� */
		cnt_getnum++;
		if (cnt_getnum > 10)
		{
		    printf("cnt_getnum[%d]\n",cnt_getnum);
			$COMMIT WORK;
			sleep(1);
			cnt_getnum = 0;
			$BEGIN WORK;
		}
	}
	$CLOSE PLY_CUR;
	$FREE  PLY_CUR;
	
	$COMMIT WORK;
	$BEGIN WORK; 
	/********************************/
	/**  �q�ʦۦ樮��e�~�ɮײ��s  **/
	/********************************/
   /*1050510004_C1_�q�ʦۦ樮�~�ȩe�~�O��~�L�s�@�~ 1050609�s�W�q�ʦۦ樮�e�~�C�L  */     
	sprintf_s(stmt2, sizeof stmt2,"SELECT ipolicy,17||ipolicy[1,3],ipolicy[4,13],17||ilast_ply[1,3],ilast_ply[4,13],itmp_policy,iroute,nassured,iassured,apayment,aassured,"
	                              "       ibrand,iengine,mcar_price,dply_begin,dply_end,mdml_prem,"
	                              "       case when trim(npost_recipient)='' then napplicant"
	                              "            else npost_recipient end, "
	                              "       case when trim(apost_address)='' then apayment_zip else apost_zip end,"
	                              "       case when trim(apost_address)='' then apayment else apost_address end,"
	                              "       napplicant,iofficer,dply_close,nequipment,drate_ym,fmail_type,ileader,dcreate,idb,"
	                              "       case when itmp_policy[5,7] = 'CVQ' then itmp_policy[5,7] else itmp_policy[6,7] end,pdate"
	                              "  FROM ca_out_temp  "
	                              " WHERE ipolicy[6,7] = 'EB' ");
	                 
	$PREPARE out_policy_eb FROM $stmt2;
	$DECLARE PLY_CUR_EB CURSOR FOR out_policy_eb;
	$OPEN    PLY_CUR_EB;
	printf("-----> into PLY_CUR_EB \n");
	printf("stmt2[%s]\n\n\n",stmt2);
	for(;;)
	{
		strcpy(eb_iofficer,"");	
		$FETCH PLY_CUR_EB INTO $eb_ipolicy,$eb_ipolicy1,$eb_ipolicy2,$eb_ilast_ply1,$eb_ilast_ply2,$eb_itmp_policy,$eb_iroute,$eb_nassured,$eb_iassured,
		                       $eb_apayment,$eb_aassured,$eb_ibrand,$eb_iengine,$eb_mcar_price,$eb_dply_begin,$eb_dply_end,$eb_mdml_prem,$eb_npost_recipient,
		                       $eb_apost_zip,$eb_apost_address,$eb_napplicant,$eb_iofficer,$eb_dply_close,$eb_nequipment,$eb_drate_ym,$eb_fmail_type,$eb_ileader,
		                       $eb_dcreate,$eb_idb,$eb_chk_pr,$eb_dpolicy;
	
		if (SQLCODE == SQLNOTFOUND) break;

		strcpy(eb_ipolicy,trim(eb_ipolicy));
		strcpy(eb_ipolicy1,trim(eb_ipolicy1));
		strcpy(eb_ipolicy2,trim(eb_ipolicy2));
		strcpy(eb_ilast_ply1,trim(eb_ilast_ply1));
		strcpy(eb_ilast_ply2,trim(eb_ilast_ply2));
		strcpy(eb_itmp_policy,trim(eb_itmp_policy));
		strcpy(eb_nassured,trim(eb_nassured));
		strcpy(eb_iassured,trim(eb_iassured));
		strcpy(eb_apayment,trim(eb_apayment));
		strcpy(eb_aassured,trim(eb_aassured));
		strcpy(eb_ibrand,trim(eb_ibrand));
		strcpy(eb_iengine,trim(eb_iengine));
		strcpy(eb_apayment,trim(eb_apayment));
		strcpy(eb_apost_zip,trim(eb_apost_zip));
		strcpy(eb_apost_address,trim(eb_apost_address));
		strcpy(eb_napplicant,trim(eb_napplicant));
		strcpy(eb_dply_begin_W,eb_dply_begin);
		strcpy(eb_dply_begin,cm_from_infdate_100(eb_dply_begin));
		strcpy(eb_dply_end,cm_from_infdate_100(eb_dply_end));
		strcpy(eb_iofficer,trim(eb_iofficer));
		strcpy(eb_iroute,trim(eb_iroute));	
		strcpy(eb_ileader,trim(eb_ileader));
		strcpy(eb_chk_pr,trim(eb_chk_pr));
		strcpy(eb_dpolicy,trim(eb_dpolicy));
		
		strcpy(sFullName, get_car_full_db(eb_ipolicy));
		strcpy(eb_dply_close,trim(eb_dply_close));
		strcpy(eb_nequipment,trim(eb_nequipment));	   
		
		printf("-----210 eb_ipolicy:[%s]-----\n",eb_ipolicy);
		printf("-----211 eb_itmp_policy:[%s]-----\n",eb_itmp_policy);
		printf("-----212 eb_iroute:[%s]-----\n",eb_iroute);
		
		/*���ڽs��*/
		strncpy(co_place,eb_ipolicy+2,1);
		co_place[1]=0x0;
		printf("*****--------co_place[%s]\n",co_place);
		$SELECT nchi_abv,nchi_abv[1,2],nchi_abv[3,4],npresident 
		   INTO $eb_nchi_abv,$eb_nchi_abv1,$eb_nchi_abv2,$eb_npresident 
		   FROM branch
		  WHERE ibranch_abbr = $co_place;
		strcpy(eb_nchi_abv,trim(eb_nchi_abv));
		strcpy(eb_nchi_abv1,trim(eb_nchi_abv1));
		strcpy(eb_nchi_abv2,trim(eb_nchi_abv2));
		strcpy(eb_npresident,trim(eb_npresident));
	
		/*���ڽs������ �YLOCK�h���]�ܦh4��*/         
		strcpy(sToday1,cm_edate_str(cm_today()));
		strcpy(sToday2, cm_cdate_str_100(cm_today()));
		iTryCnt2 =0;
		if(ireceipt1 > ireceipt2)
		{
			RETRY:
			res2 = cm_get_serial_num_dwritten("CM","R1","0","00",sToday1,sToday2,eb_ireceipt);
			if (res2 != 0) 
			{
				iTryCnt2++;
				if (iTryCnt2 > 3)  
				{
					fprintf(fp,"�O�渹�G%s\t�C�L��Ʀ��~!\n",eb_ipolicy);
					ireceipt1++;
					continue;	
				}	
				sleep(1);
				goto  RETRY;
			}
			printf("res2=[%d]sToday1=[%s]sToday2=[%s]eb_ireceipt=[%s]\n",res2,sToday1,sToday2,eb_ireceipt); 
		}
		else
			strcpy(eb_ireceipt,itoa(ireceipt1));
		printf("--------ireceipt1[%d]\n",ireceipt1);
	
		printf("!!!!eb_iroute[%s]  eb_iofficer[%s]\n",eb_iroute,eb_iofficer);
		cntIroute = 0;
		strcpy(sIrouteNote," ");
		$SELECT chiname, count(*)
		   INTO $sIrouteNote, $cntIroute
		   FROM car_code
		  WHERE kind = 'SR'
		    AND detail = $eb_iroute
		    AND detail2 = $eb_iofficer
		  GROUP BY chiname;
		printf("!!!!sIrouteNote[%s]  cntIroute[%d]\n",sIrouteNote,cntIroute);
		
		cnt_cpcr = 0;
		chk_cpcr[0] = '\0';
		$SELECT count(*),nvl(chiname,' ')
		   INTO $cnt_cpcr,$chk_cpcr
		   FROM car_code
		  WHERE kind = 'O1'
		    AND detail =  $eb_iroute
		    AND detail2 =$eb_iofficer
		  GROUP BY 2;
		strcpy(chk_cpcr,trim(chk_cpcr));
		printf("!!!!cnt_cpcr[%d]  chk_cpcr[%s]\n",cnt_cpcr,chk_cpcr);  
		printf("!!!!              eb_chk_pr[%s]\n",eb_chk_pr);
		
		cntIroute2 = 0;
		strcpy(sIrouteNote2," ");
		$SELECT chiname, count(*)
		   INTO $sIrouteNote2, $cntIroute2
		   FROM car_code
		  WHERE kind = 'O4'
		    AND detail = $eb_iroute
		    AND detail2 = $eb_iofficer
		  GROUP BY chiname;
		printf("!!!!sIrouteNote2[%s]  cntIroute2[%d]\n",sIrouteNote2,cntIroute2);
	
		strcpy(outNote,"");
		if ( cntIroute > 0 && (equip_cmp(eb_nequipment,"37") != TRUE)){ 	
			strcat(outNote,"A");
		}
		else if ( cntIroute2 > 0 ){ 	
			strcat(outNote,"A");
		}
		else if(cnt_cpcr > 0 && (strcmp(chk_cpcr,eb_chk_pr)==0 || strlen(chk_cpcr) == 0 )){
			printf("!!!!inchkcpcr11\n");
			strcat(outNote,"A");
		}
		else if(cnt_cpcr > 0 && strcmp(chk_cpcr,"CVQ")==0 && strcmp(eb_chk_pr,"CP")==0){
			printf("!!!!inchkcpcr12\n");
			strcat(outNote,"A");
		}
		else{
			strcat(outNote,trim(eb_fmail_type));     /* ��4�X�G�l�H�覡 */
		}
		strcat(outNote,"3");                         /* ��5�X�G���� */
		/* 1130321003_C02_�e�~���H�R�q�K�ȳW�h�A�վ��6�X �O��A�ȥd->�R�q�K�� (131775) */
		/*strcat(outNote,"0");                          ���6�X�G�O��A�ȥd */
		if(strlen(eb_ilast_ply2) == 0)				/* ��6�X�G�R�q�K�� 0�G(��O)�����[ 1�G(�s��)���[ */
		{
			strcat(outNote,"1");                         /* �s�� */
		}
		else
		{
			strcat(outNote,"0");                         /* ��O */
		}
		
		if (strncmp(eb_iroute,"JB",2) == 0){         /* ��7�X�G�q���O */
			strcat(outNote,"1"); /* ���� */
		}
		else{
			/* �S�w�q������]�w��kind = 'SR' (�ư���Oú�ڥ�)*/
			if (cntIroute > 0 && (equip_cmp(eb_nequipment,"37") != TRUE) ) {
				strcat(outNote, trim(sIrouteNote));/* �F����� */
			}
			else if ( cntIroute2 > 0 ){ 	
				strcat(outNote,trim(sIrouteNote2));
			}
			else {
				strcat(outNote,"0");
			}
		}
		/*strcat(outNote,"4"); */                     /* ��8�X�G���H���� */
		/*sprintf_s(stmt_feterms, sizeof stmt_feterms,"SELECT feterms FROM %s:ply_relation \n" 
		                     " WHERE ipolicy = '%s'", sFullName, eb_ipolicy);
		$PREPARE sfterms FROM $stmt_feterms;
		$EXECUTE sfterms INTO $feterms;*/
		/*if (strcmp(feterms,"1")==0)
		    strcat(outNote,"0");
		else*/
		    strcat(outNote,"1");
	    
		eb_irate_ym = atoi(eb_drate_ym);      
		if(eb_irate_ym >= 79) strcat(outNote,"8");       /* ��9�X�G�s�±��� */
		else strcat(outNote,"9");  
		
		cnt_cpcr2 = 0;
		chk_cpcr2[0] = '\0';
		$SELECT count(*),nvl(chiname,' ')
		   INTO $cnt_cpcr2,$chk_cpcr2
		   FROM car_code
		  WHERE kind = 'O2'
		    AND detail = $eb_iroute
		    AND detail2 = $eb_iofficer
		  GROUP BY 2;
		strcpy(chk_cpcr2,trim(chk_cpcr2));               /* ��10�X�G�O���v�q������r */
		printf("!!!!cnt_cpcr2[%d]  chk_cpcr2[%s]\n",cnt_cpcr2,chk_cpcr2);
		if(cnt_cpcr2 > 0 && (strcmp(chk_cpcr2,eb_chk_pr)==0 || strlen(chk_cpcr2) == 0 )){
			printf("!!!!inchkcpcr21\n");
			strcat(outNote,"1");
		}
		else if(cnt_cpcr > 0 && strcmp(chk_cpcr,"CVQ")==0 && strcmp(eb_chk_pr,"CP")==0){
			printf("!!!!inchkcpcr22\n");
			strcat(outNote,"1");
		}
		else
			strcat(outNote,"0");
     		
		strcat(outNote,"000000");
		           
		eb_mdml_prem1 = eb_mdml_prem;
		fprintf(fp1,"~~|%s",outNote);
		fprintf(fp1,"\n");
 
		sprintf_s(stmt_ncont, sizeof stmt_ncont,"SELECT max(ncontract ),a.iins_type "
		                                        " FROM  ca_terms a, %s:ply_ins_type b"
		                                        " WHERE a.iins_type = b.iins_type"
		                                        "  AND  b.ipolicy = '%s' "
		                                        "  AND  deffect <= '%s' "
		                                        "  AND  dcreate <= '%s' "
		                                        " GROUP BY a.iins_type "
		                                        " ORDER BY 1 DESC ",sFullName,eb_ipolicy,eb_dply_begin_W,eb_dpolicy);
		$PREPARE term FROM $stmt_ncont;
		printf("stmt_ncont[%s]\n",stmt_ncont);
		$DECLARE term_ncon CURSOR FOR term;
		$OPEN term_ncon;
		$FETCH term_ncon INTO $ncontract,$viins_type;
		$CLOSE term_ncon;
		$FREE  term_ncon;
	
		$SELECT ncontent1
		   INTO $m2
		   FROM ca_terms
		  WHERE ncontract = $ncontract
		    AND iins_type = $viins_type;
	
		strcpy(m2,trim(m2));
		printf("\n---ncontent1[%s]\n",m2);
		
		strcpy(m2,trim(m2));
		strcpy(m13,"�x�W�B���B�����B�����άF���Ϊv�v�ҤΤ���L�a��");
		strcpy(m18,cm_cdate_str_100(cm_today()));
		rfmtdouble(eb_mcar_price,"<<<<<.<",eb_mcar_price_char); 	             
		printf("--0\n");
		fprintf(fp1,"M|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s�U��|%s|%s|%d|%s|%s|%s|%s|%s|%s|%s",eb_ipolicy,m2,eb_ipolicy1,eb_ipolicy2,eb_ilast_ply1,eb_ilast_ply2,eb_nassured,eb_iassured,eb_apayment,
		        eb_aassured,eb_ibrand,eb_iengine,m13,eb_mcar_price_char,eb_dply_begin,eb_dply_end,eb_mdml_prem,m18,eb_nchi_abv,eb_apost_zip,eb_apost_address,eb_npost_recipient,eb_iofficer,eb_drate_ym);
		fprintf(fp1,"\n");
		printf("--1\n");
		if( cntIroute > 0 && (equip_cmp(eb_nequipment,"37") != TRUE)){/*�F����Ĥ��L����*/
		fprintf(fp1,"R|||||");
		}
		else{    
		fprintf(fp1,"R|%s|%s|%s|%s|%s",eb_napplicant,eb_ireceipt,eb_nchi_abv1,eb_nchi_abv2,eb_npresident);
		}
		fprintf(fp1,"\n");
	
		printf("--2\n"); 
		/*���ڲզX-------------------------------------------------------------------------------------------------------*/         
		strcpy(eb_drate_ym,trim(eb_drate_ym));
		printf("eb_drate[%s],eb_dpolicy[%s] \n\n",eb_drate_ym,eb_dpolicy);
		stmp[0] = '\0';
		sprintf_s(stmp, sizeof stmp," AND a.drate_ym = '%s' AND (a.iclass = 'E' or a.iclass = 'A') AND a.dbegin <= '%s' "
		                            " AND (a.dend >= '%s' OR a.dend is null OR a.dend = ' ') "
		                            " AND (a.dexpire is null or a.dexpire = ' ' or dexpire >= today)",eb_drate_ym,eb_dpolicy,eb_dpolicy);
		printf("stmp[%s]\n\n",stmp);
		if(strlen(eb_dply_close)>0)
		{
			sprintf_s(stmt3, sizeof stmt3,"SELECT a.iins_type,(SELECT nins_type from insurance_type WHERE iins_type = a.iins_type),a.mdeduct,a.minjured_cover,a.mdamage_cover,a.mins_premium"
			                              "  FROM %s:ori_ins_type a"
			                              " WHERE a.ipolicy= '%s' " 
			                              " order by 1" ,sFullName,eb_ipolicy);
			sprintf_s(stmt_ins_eb, sizeof stmt_ins_eb,"SELECT a.iins_type,b.fins_grp,b.fkind,trim(nvl(a.provision,' '))||';', "
			                                          "       c.cmp_provision,"
			                                          "       c.com_provision," 
			                                          "       c.iins_provision1,"
			                                          "       c.iins_provision2,"
			                                          "       c.iins_provision3,b.qserial"
			                                          "  FROM %s:ori_ins_type a,insurance_type b,outer ca_prov_irate c"
			                                          " WHERE a.iins_type = b.iins_type AND a.iins_type = c.iins_type AND a.drate_ym = c.irate AND (c.iclass = 'E' or c.iclass = 'A') AND a.ipolicy= '%s' ",sFullName,eb_ipolicy);
		}
		else
		{
			sprintf_s(stmt3, sizeof stmt3,"SELECT a.iins_type,(SELECT nins_type from insurance_type WHERE iins_type = a.iins_type),a.mdeduct,a.minjured_cover,a.mdamage_cover,a.mins_premium"
			                              "  FROM %s:ply_ins_type a"
			                              " WHERE a.ipolicy= '%s' " 
			                              " order by 1" ,sFullName,eb_ipolicy);
			sprintf_s(stmt_ins_eb, sizeof stmt_ins_eb,"SELECT a.iins_type,b.fins_grp,b.fkind,trim(nvl(a.provision,' '))||';', "
			                                          "       c.cmp_provision,"
			                                          "       c.com_provision," 
			                                          "       c.iins_provision1,"
			                                          "       c.iins_provision2,"
			                                          "       c.iins_provision3,b.qserial"
			                                          "  FROM %s:ply_ins_type a,insurance_type b,outer ca_prov_irate c"
			                                          " WHERE a.iins_type = b.iins_type AND a.iins_type = c.iins_type AND a.drate_ym = c.irate AND (c.iclass = 'E' or c.iclass = 'A') AND a.ipolicy= '%s' " ,sFullName,eb_ipolicy);
		}      
		$PREPARE eb_policy_ins FROM $stmt3;
		$DECLARE EB_INS CURSOR FOR eb_policy_ins;
		$OPEN EB_INS;
		printf("stmt3[%s]\n",stmt3);
		cnt_prov_chk = 0;
		for(;;)
		{
			$FETCH EB_INS INTO $eb_iins_type,$eb_nins_type,$eb_mdeduct,$eb_minjured_cover,$eb_mdamage_cover,$eb_mins_premium;	
			if (SQLCODE == SQLNOTFOUND) break;
			strcpy(eb_iins_type,trim(eb_iins_type));
			strcpy(eb_nins_type,trim(eb_nins_type));
			cnt_prov = 0;
			$SELECT count(*) INTO $cnt_prov FROM ca_prov_irate WHERE iins_type = $eb_iins_type AND irate = $eb_drate_ym AND (iclass = 'E' OR iclass = 'A') ;
			if (cnt_prov <= 0) 
			{
				fprintf(fp,"�O�渹�G%s\�ӶO�v���I�صL�]�w��������!\t�O�v[%s]�I�إN��[%s]\n",eb_dpolicy,eb_drate_ym,eb_iins_type);
				cnt_prov_chk++;
				continue;
			}
			
			if(strcmp(eb_iins_type,"103") == 0)
			{
				eb_minjured_cover = eb_minjured_cover / 10000;
				eb_mdamage_cover = eb_mdamage_cover / 10000;
				rfmtlong(eb_minjured_cover,"<,<<<",eb_minjured_tmp);     
				rfmtlong(eb_mdamage_cover,"<,<<<",eb_mdamage_tmp);
				strcpy(stmt9,trim(eb_minjured_tmp));
				strcat(stmt9,"�U");
				strcat(stmt9,"/");
				strcat(stmt9,trim(eb_mdamage_tmp));
				strcat(stmt9,"�U");
			}
			else
			{
				rfmtlong(eb_mdamage_cover,"<<,<<<,<<<,<<<,<<<",stmt9);
			}
			if(eb_mdeduct == 0)
				strcpy(eb_mdeduct_tmp,"");
			else
				rfmtlong(eb_mdeduct,"<<,<<<,<<<,<<<,<<<",eb_mdeduct_tmp);
				
			rfmtlong(eb_mins_premium,"<<,<<<,<<<,<<<,<<<",eb_mins_premium_tmp); 
			fprintf(fp1,"D|%s|%s|%s|%s|%s",eb_iins_type,eb_nins_type,eb_mdeduct_tmp,stmt9,eb_mins_premium_tmp);	
			fprintf(fp1,"\n");
		}
		$CLOSE EB_INS;
		$FREE  EB_INS;

		/*--------------------------------------------------���ڥN��------------------------------------------------------------------*/
		$PREPARE eb_iins FROM $stmt_ins_eb;
		$DECLARE eb_iins_cur CURSOR FOR eb_iins;	 
		$OPEN    eb_iins_cur;
		for(;;)
		{
			$FETCH eb_iins_cur INTO $iins_type,$fins_grp,$fkind,$iins_provision_add,
			                        $cmp_provision,$com_provision,$iins_provision1,$iins_provision2,$iins_provision3,$qserial;
			        
			if (SQLCODE == SQLNOTFOUND) break; 
			strcpy(iins_provision_add,trim(iins_provision_add));	
			strcpy(iins_type,trim(iins_type));		
			strcpy(cmp_provision,trim(cmp_provision));
			strcpy(com_provision,trim(com_provision));
			strcpy(iins_provision1,trim(iins_provision1));
			strcpy(iins_provision2,trim(iins_provision2)); 
			strcpy(iins_provision3,trim(iins_provision3));  
			
			/*���[����*/
			sprintf_s(stmt_cu, sizeof stmt_cu,"select trim(iprovision)||';',iprovision from ca_provision_main ");
			printf("stmt_cu[%s]\n",stmt_cu);
			$PREPARE eb_ins_cu FROM $stmt_cu;
			$DECLARE eb_ins_cucode CURSOR FOR eb_ins_cu;	 
			$OPEN    eb_ins_cucode;
			for(;;)
			{
				$FETCH eb_ins_cucode INTO $iprovision_add,$nprovision_add;
				strcpy(iprovision_add,trim(iprovision_add));
				strcpy(nprovision_add,trim(nprovision_add));
				if (SQLCODE == SQLNOTFOUND) break; 
				printf("iins_provision_add[%s] iprovision_add[%s] nprovision_add[%s]\n",iins_provision_add,iprovision_add,nprovision_add);
				if(strstr(iins_provision_add,iprovision_add) != NULL)
				{
					strcpy(nprovision_add,trim(nprovision_add));
					$INSERT INTO ca3072_pro_tmp (ipolicy,iprovision,qserial) VALUES($eb_ipolicy,$nprovision_add,100);
				}
			}	
			$CLOSE eb_ins_cucode;
			$FREE  eb_ins_cucode;	 
			
			if(strlen(cmp_provision) != 0)
				$INSERT INTO ca3072_cmp_tmp (ipolicy,iprovision,qserial) VALUES($eb_ipolicy,$cmp_provision,1);
			if(strlen(com_provision) != 0)
				$INSERT INTO ca3072_com_tmp (ipolicy,iprovision,qserial) VALUES($eb_ipolicy,$com_provision,1);
			if(strlen(iins_provision1) != 0 )
				$INSERT INTO ca3072_pro_tmp (ipolicy,iprovision,qserial) VALUES($eb_ipolicy,$iins_provision1,$qserial);
			if(strlen(iins_provision2) != 0 )
				$INSERT INTO ca3072_pro_tmp (ipolicy,iprovision,qserial) VALUES($eb_ipolicy,$iins_provision2,$qserial);
			if(strlen(iins_provision3) != 0 )
				$INSERT INTO ca3072_pro_tmp (ipolicy,iprovision,qserial) VALUES($eb_ipolicy,$iins_provision3,$qserial);  
			printf("iins_provision_add[%s] cmp_provision[%s] com_provision[%s] iins_provision1[%s] iins_provision2[%s] iins_provision3[%s] \n",
			        iins_provision_add,cmp_provision,com_provision,iins_provision1,iins_provision2,iins_provision3); 	 	         	 	
		}
		$CLOSE eb_iins_cur;
		$FREE  eb_iins_cur;

		/*��ӱ���*/
		iprovision1[0] = '\0';
		drate1[0] = '\0';
		iclass1[0] = '\0';
		dbegin1[0] = '\0';
		dbegin00[0] = '\0';

		/*��ӱ���*/
		stmt_cmp[0] = '\0';
		sprintf_s(stmt_cmp, sizeof stmt_cmp,"SELECT unique a.iprovision,a.drate_ym,a.iclass,a.dbegin,max(b.qserial) \
		                                       FROM ca_provision a, ca3072_cmp_tmp b \
		                                      WHERE a.iprovision = b.iprovision \
		                                        AND b.ipolicy= '%s' %s \
		                                      GROUP BY 1,2,3,4 \
		                                      ORDER BY 5,1 ", eb_ipolicy,stmp);
		printf("stmt_cmp[%s]\n",stmt_cmp);
		$PREPARE eb_cp FROM $stmt_cmp;
		$DECLARE eb_cmp_cur CURSOR FOR eb_cp; 
		$OPEN    eb_cmp_cur;
		for(;;)
		{
			iprovision1[0] = '\0';
			drate1[0] = '\0';
			iclass1[0] = '\0';
			dbegin00[0] = '\0';
			$FETCH eb_cmp_cur INTO $iprovision1,$drate1,$iclass1,$dbegin;
			if (SQLCODE == SQLNOTFOUND) break;
			strcpy(dbegin0,cm_from_infdate_100(dbegin));
			cm_char_split_3ymd(dbegin0,dbegin0_yy,dbegin0_mm,dbegin0_dd);
			sprintf_s(dbegin00, sizeof dbegin00,"%s%s%s",dbegin0_yy,dbegin0_mm,dbegin0_dd);
			strcpy(iprovision1,trim(iprovision1));
			strcpy(drate1,trim(drate1));
			strcpy(iclass1,trim(iclass1));
			strcpy(dbegin00,trim(dbegin00));
			printf("iprovision1[%s] drate1[%s] iclass1[%s] dbegin00[%s]\n",iprovision1,drate1,iclass1,dbegin00);
			fprintf(fp1,"P|%s_%s_%s_%s\n",iprovision1,drate1,iclass1,dbegin00);
		}
		$DELETE FROM ca3072_cmp_tmp;
		$CLOSE eb_cmp_cur;
		$FREE  eb_cmp_cur;
		
		/*�@�P����*/
		stmt_com[0] = '\0';
		sprintf_s(stmt_com, sizeof stmt_com,"SELECT unique a.iprovision,a.drate_ym,a.iclass,a.dbegin,max(b.qserial) \
		                                       FROM ca_provision a, ca3072_com_tmp b \
		                                      WHERE a.iprovision = b.iprovision \
		                                        AND b.ipolicy= '%s' %s \
		                                      GROUP BY 1,2,3,4 \
		                                      ORDER BY 5,1 ", eb_ipolicy,stmp);
		printf("stmt_com[%s]\n",stmt_com);
		$PREPARE eb_co FROM $stmt_com;
		$DECLARE eb_com_cur CURSOR FOR eb_co; 
		$OPEN    eb_com_cur;
		for(;;)
		{
			iprovision1[0] = '\0';
			drate1[0] = '\0';
			iclass1[0] = '\0';
			dbegin00[0] = '\0';
			$FETCH eb_com_cur INTO $iprovision1,$drate1,$iclass1,$dbegin;
			if (SQLCODE == SQLNOTFOUND) break; 
			strcpy(dbegin0,cm_from_infdate_100(dbegin));
			cm_char_split_3ymd(dbegin0,dbegin0_yy,dbegin0_mm,dbegin0_dd);
			sprintf_s(dbegin00, sizeof dbegin00,"%s%s%s",dbegin0_yy,dbegin0_mm,dbegin0_dd);
			strcpy(iprovision1,trim(iprovision1));
			strcpy(drate1,trim(drate1));
			strcpy(iclass1,trim(iclass1));
			strcpy(dbegin00,trim(dbegin00));
			printf("iprovision1[%s] drate1[%s] iclass1[%s] dbegin00[%s]\n",iprovision1,drate1,iclass1,dbegin00);
			fprintf(fp1,"P|%s_%s_%s_%s\n",iprovision1,drate1,iclass1,dbegin00);
		}
		$DELETE FROM ca3072_com_tmp;
		$CLOSE eb_com_cur;
		$FREE  eb_com_cur;
		
		/*���ڤ��e*/
		stmt_pro[0] = '\0';
		sprintf_s(stmt_pro, sizeof stmt_pro,"SELECT unique a.iprovision,a.drate_ym,a.iclass,a.dbegin,max(b.qserial) \
		                                       FROM ca_provision a, ca3072_pro_tmp b \
		                                      WHERE a.iprovision = b.iprovision \
		                                        AND b.ipolicy= '%s' %s \
		                                      GROUP BY 1,2,3,4 \
		                                      ORDER BY 5,1 ", eb_ipolicy,stmp);
		printf("stmt_pro[%s]\n",stmt_pro);
		$PREPARE eb_pr FROM $stmt_pro;
		$DECLARE eb_pr_cur CURSOR FOR eb_pr;
		$OPEN    eb_pr_cur;
		for(;;)
		{
			iprovision1[0] = '\0';
			drate1[0] = '\0';
			iclass1[0] = '\0';
			dbegin00[0] = '\0';
			$FETCH eb_pr_cur INTO $iprovision1,$drate1,$iclass1,$dbegin;
			if (SQLCODE == SQLNOTFOUND) break; 
			strcpy(dbegin0,cm_from_infdate_100(dbegin));
			cm_char_split_3ymd(dbegin0,dbegin0_yy,dbegin0_mm,dbegin0_dd);
			sprintf_s(dbegin00, sizeof dbegin00,"%s%s%s",dbegin0_yy,dbegin0_mm,dbegin0_dd);
			strcpy(iprovision1,trim(iprovision1));
			strcpy(drate1,trim(drate1));
			strcpy(iclass1,trim(iclass1));
			strcpy(dbegin00,trim(dbegin00));
			printf("iprovision1[%s] drate1[%s] iclass1[%s] dbegin00[%s]\n",iprovision1,drate1,iclass1,dbegin00);
			fprintf(fp1,"P|%s_%s_%s_%s\n",iprovision1,drate1,iclass1,dbegin00);
		}
		$DELETE FROM ca3072_pro_tmp;
		$CLOSE eb_pr_cur;
		$FREE  eb_pr_cur;
		fprintf(fp1,"\n");
		/*----------------------------------------------------------------------------------------------------------------------------*/
		strcpy(dreceipt,cm_cdate_estr_100(cm_today()));
		if(strlen(eb_dply_close)>0)
			strcpy(itype,"P");
		else 
			strcpy(itype,"N");             
		
		strcpy(ipolicy1, trim(eb_ipolicy));      
		if (strlen(ipolicy1) > 13)
		{
			strncpy(sIpolicy1, ipolicy1, 13);    
			sIpolicy1[13] = '\0';
			strncpy(sIpolicy2, ipolicy1+13, 4);
			sIpolicy2[20] = '\0';
			if (sIpolicy2[0]=='\0' || sIpolicy2[0]==' ') strcpy(sIpolicy2," ");
		}
		else
		{
			strcpy(sIpolicy1,eb_ipolicy);
			strcpy(sIpolicy2," ");
		}

		/* �p�G�O�̷s�O��A�����[�`�Ҧ��ӫO�渹(��l�O��B���)���h�O���B*/
		mdiscount = 0;
		if(strlen(eb_dply_close)==0)
		{
			$SELECT nvl(sum(pay_mnt),0) Into $mdiscount 
			   FROM ao_reward_policy
			  WHERE ipolicy1 = $sIpolicy1
			    AND ipolicy2 = $sIpolicy2;
		}
		else
		{
			$SELECT nvl(pay_mnt,0) Into $mdiscount 
			   FROM ao_reward_policy
			  WHERE ipolicy1 = $sIpolicy1
			    AND ipolicy2 = $sIpolicy2
			    AND iendorse = $sIendorse;    	
		}
		eb_mdml_prem1 = eb_mdml_prem - mdiscount;
	
		if(eb_idb == 0)
			strcpy(idb,"00");
		else if(eb_idb == 1)   
			strcpy(idb,"22");
		else if(eb_idb == 2)   
			strcpy(idb,"33");
		else if(eb_idb == 3)   
			strcpy(idb,"40");
		else if(eb_idb == 4)   
			strcpy(idb,"66");
		else   
			strcpy(idb,"70");

		strcpy(sDateTime,"'");
		strcat(sDateTime,substring(eb_dcreate,1,19));
		strcat(sDateTime,"'");
		printf("sDateTime[%s]\n",sDateTime);
		strcpy(dreceipt,cm_to_infdate(dreceipt));
		strcpy(eb_dply_begin,cm_to_infdate(eb_dply_begin));
		strcpy(eb_dply_end,cm_to_infdate(eb_dply_end));

		strcpy(stmp_rec," ");
		/*�^�����ڽs��*/
		sprintf_s(stmp_rec, sizeof stmp_rec, "insert into cm_receipt_log \
		                                      (ireceipt, iins_cat, ipolicy, iendorse, itype,iversion, \
		                                      idb, iprint, dprint,remark,dreceipt,nassured,napplicant, \
		                                      dbegin,dend,curr,mprem_cur,mpremium,ileader,azip,aaddress) \
		                                      values \
		                                      ( '%s' , 'C' , '%s', ' ', '%s', 'A' , \
		                                       '%s' , '%s' , %s, '�e�~�L�s' , '%s' , '%s' , '%s' , \
		                                       '%s' , '%s' , 'NT' , %d , %d , '%s' , '%s' , '%s')",eb_ireceipt,eb_ipolicy,itype,idb,userid,sDateTime,dreceipt,eb_nassured,
		                                      eb_napplicant,eb_dply_begin,eb_dply_end,eb_mdml_prem1,eb_mdml_prem1,eb_ileader,eb_apost_zip,eb_apost_address);
		printf("stmp_rec=[%s]\n",stmp_rec);
		
		$PREPARE re1 FROM $stmp_rec;
		$EXECUTE re1;
		strcpy(stmp_rec," ");
	
		/*1060818001_C1_cmn134a-���I*/
		/*�W�[�g�J���ک��ӤΦC�L�O��*/
		sprintf_s(stmp_rec, sizeof stmp_rec, "insert into cm_receipt_log_dtl \
		                                     (ireceipt,ipolicy,iendorse,ftype,curr,pexchg_rate,mprem_cur) \
		                                     values('%s','%s',' ','N','NT',1.0000,'%d') ",eb_ireceipt,eb_ipolicy,eb_mdml_prem1);
		printf("stmp_rec=[%s]\n",stmp_rec);
		$PREPARE re2 FROM $stmp_rec;
		$EXECUTE re2;
		strcpy(stmp_rec," ");
		
		sprintf_s(stmp_rec, sizeof stmp_rec, "insert into cm_receipt_log_prt \
		                                      (ireceipt,fformal,fversion,fnote,iprint,dprint,isource) \
		                                      values('%s','F','A',' ','%s',current,'car3072') ",eb_ireceipt,userid);
		printf("stmp_rec=[%s]\n",stmp_rec);
		$PREPARE re3 FROM $stmp_rec;
		$EXECUTE re3;
		strcpy(stmp_rec," ");

		/* �^���i�L�����A�j�B�i�e�~���ɤ�j��O�����p�ɤέ�l�O�����p�� */
		sprintf_s(sStmt3, sizeof sStmt3, " UPDATE %s:ply_relation "
		"    SET fprint = '1' , dout_trans = CURRENT "
		"  WHERE ipolicy = '%s' ",sFullName ,eb_ipolicy );
		$PREPARE update3 FROM $sStmt3;
		$EXECUTE update3;
		
		sprintf_s(sStmt4, sizeof sStmt4, " UPDATE %s:ori_ply_relation "
		"    SET fprint = '1' , dout_trans = CURRENT "
		"  WHERE ipolicy = '%s' ",sFullName, eb_ipolicy );
		$PREPARE update4 FROM $sStmt4;
		$EXECUTE update4;  
		
		DELE2: 
		$DELETE 
		FROM ca_out_temp 
		WHERE ipolicy = $eb_ipolicy;
		
		count_ply2 = 0;
		
		$SELECT count(*)
		INTO $count_ply2
		FROM ca_out_temp 
		WHERE ipolicy = $eb_ipolicy;
		
		printf("--------count_ply2[%d]\n",count_ply2);  
		if(count_ply2 != 0) goto  DELE2; 
		ireceipt1++;		       	         
	}
	$CLOSE PLY_CUR_EB;
	$FREE  PLY_CUR_EB; 

	fclose(fp);
	fclose(fp0);
	fclose(fp1);
	
	$COMMIT WORK;
	$BEGIN WORK;

	char cmd_email1[200],cmd_email2[200],cmd_email3[200];
	strcpy(cmd_email1,"");strcpy(cmd_email2,"");strcpy(cmd_email3,"");
	/*sprintf_s(cmd_email1, sizeof cmd_email1,"uuencode /TEST/IPIS/rptftp/%s /TEST/IPIS/rptftp/%s ",Fname_1,Fname_1);/*���ե�*/
	/*sprintf_s(cmd_email2, sizeof cmd_email2,"cat /mis/mis1/071004/car3072_message.txt /TEST/IPIS/rptftp/%s > /TEST/IPIS/rptftp/combined_car3072.txt",Fname_1);/*���ե�*/
	/*strcpy(cmd_email3,"mail -s '[����]�e�~�O��C�L��Ʀ��~�q��' celialiu@tmnewa.com.tw,chun.ni.chu@tmnewa.com.tw,chiatsen.kao@tmnewa.com.tw,brian.wang@tmnewa.com.tw < /TEST/IPIS/rptftp/combined_car3072.txt");/*���ե�*/
	/*strcpy(cmd_email3,"mailx -r \"ipisnew@tmnewa.com.tw\" -s \"$(echo \"[����]�e�~�O��C�L��Ʀ��~�q��\"\"\\nContent-Type: text/plain; charset=\\\"big5\\\"\")\" -c \" \" Christine.Chen@tmnewa.com.tw,chun.ni.chu@tmnewa.com.tw,chiatsen.kao@tmnewa.com.tw,stevechiang@tmnewa.com.tw < /TEST/IPIS/rptftp/combined_car3072.txt");/*���ե�*/
	
	sprintf_s(cmd_email1, sizeof cmd_email1,"uuencode /PROD/IPISNEW/rptftp/%s /PROD/IPISNEW/rptftp/%s ",Fname_1,Fname_1);/*������*/
	sprintf_s(cmd_email2, sizeof cmd_email2,"cat /MIS/071004/car3072_message.txt /PROD/IPISNEW/rptftp/%s > /PROD/IPISNEW/rptftp/combined_car3072.txt",Fname_1);/*������*/
	/*strcpy(cmd_email3,"mail -s '�e�~�O��C�L��Ʀ��~�q��' celialiu@tmnewa.com.tw,chun.ni.chu@tmnewa.com.tw,chiatsen.kao@tmnewa.com.tw,stevechiang@tmnewa.com.tw < /PROD/IPISNEW/rptftp/combined_car3072.txt");/*������*/
	strcpy(cmd_email3,"mailx -r \"ipisnew@tmnewa.com.tw\" -s \"$(echo \"�e�~�O��C�L��Ʀ��~�q��\"\"\\nContent-Type: text/plain; charset=\\\"big5\\\"\")\" -c \" \" Christine.Chen@tmnewa.com.tw,chun.ni.chu@tmnewa.com.tw,chiatsen.kao@tmnewa.com.tw,stevechiang@tmnewa.com.tw < /PROD/IPISNEW/rptftp/combined_car3072.txt");/*������*/
	rc = system(cmd_email1);
	rc = system(cmd_email2);
	rc = system(cmd_email3);

	
	rc=rptftpinsert(userid,"car3072",Fname_1);
	if (rc != 0){
		sprintf_s(sErrMsg, sizeof sErrMsg,"%s�g�Jrptftplist���~",Fname_1);
		$ROLLBACK WORK;
		return rc;
	}

	$UPDATE cu_code_data
	    SET ncode = 'Y'
	  WHERE itype = 'OT'
	    AND icode = '3072';

	$COMMIT WORK;
	rgu_finish_report(); 
	return M_CM_OK;
	
errexit:
	fclose(fp);
	fclose(fp0);
	fclose(fp1);
	printf("-- Query_policy -- SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
	$ROLLBACK WORK;
	return SQLCODE;
}    
/*----------------------------------------------------------------------------*/
long tar_policy()
{
	$char stmtt[512],drate1[5];
	
	/* ���]�O��B�O�I���ɤΩe�~�O��Ǹ��H�ιq�ʦۦ樮�O�� */
	sprintf_s(tar, sizeof tar,"tar -cvf %s/rptftp/car_out/%s_car.tar %s/batchfile/%s %s/batchfile/%s_card.tx %s/batchfile/%s_EB.txt"
	                          " %s/batchfile/%s_outnumber.txt %s/batchfile/provision_%s.txt ",
	                          sApHome,sdate,sApHome,OutFile,sApHome,sdate,sApHome,sdate,sApHome,sdate,sApHome,sdate2);
	sprintf_s(command1, sizeof command1, "%s", tar);
	result = system(command1);	
	printf("tar-result[%d]\n", result);
	
	/* ���Y���]�n���ɮ�.gz */
	sprintf_s(gzip, sizeof gzip,"gzip %s/rptftp/car_out/%s_car.tar",sApHome,sdate);
	printf("gzip[%s]\n", gzip);
	sprintf_s(command2, sizeof command2, "%s", gzip);
	result = system(command2);
	printf("gzip-result[%d]\n", result);
	
	return M_CM_OK;
		
errexit:
	printf("-- Query_policy -- SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
	$ROLLBACK WORK;
	return SQLCODE;
}
/*----------------------------------------------------------------------------*/
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
	char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
	char sTmp_db_name[21];
	
	sTmp_db_name[0]='\0';
	if (*sIpolicy != '\0' && *sIpolicy !=' ')
	{
	    sTmp_db_name[0]='\0';
	    strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
	    strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
	           USE_BRANCH_ID));
	    strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
	}        
	return sTmp_db_name;
}
/*----------------------------------------------------------------------------*/
long create_provision()
{
	
	$char drate[4],stmt3[1024],stmt4[1024],stmt5[2048];
	$char iprovision_in[6],drate_ym_in[4],iclass_in[2],dbegin_in[11];
	$char iprovision[6],drate_ym[4],iclass[2],dbegin[11],nprovision[256],nnumber[256],fcont1[2],fcont2[2],narticle[256],ncontent[256],nnumber2[256],nprovision2[256],dbegin2[11];
	$char dbegin2_yy[4],dbegin2_mm[3],dbegin2_dd[3],nprovision_fcont[2],nnumber_fcont[2],ncontent2[256];
	$int iarticle=0,icontent=0;
	$char chn[5];
	$char *ptr,*ptr2;
	$WHENEVER SQLERROR GOTO errexit;
	$SET LOCK MODE TO WAIT;
	$BEGIN WORK;
	
	strcpy(dtoday1,cm_cdate_str(cm_today()));
	cm_char_split_3ymd(dtoday1,syy2,smm2,sdd2);
	sprintf_s(sdate2, sizeof sdate2,"%s%s%s",syy2,smm2,sdd2);
	printf("-----sdate2 = [%s]-----\n",sdate2);
	
	strcpy(FileName_4," ");
	strcpy(Fname_4," ");
	sprintf_s(Fname_4, sizeof Fname_4,"provision_%s.txt",sdate2);
	sprintf_s(FileName_4, sizeof FileName_4,"%s/batchfile/%s",sApHome,Fname_4);
	printf("--FileName_4--[%s]\n",FileName_4);
	fp2=fopen(FileName_4,"w");
	
	sprintf_s(stmt3, sizeof stmt3,"SELECT distinct drate_ym as drate FROM ca_out_temp into temp ca_drate with no log;");
	$PREPARE drate0 FROM $stmt3;
	$EXECUTE drate0;
	
	sprintf_s(stmt4, sizeof stmt4,"SELECT distinct a.iprovision,a.drate_ym,a.iclass,a.dbegin \
	                                 FROM ca_provision a\
	                                WHERE a.drate_ym in (SELECT unique drate FROM ca_drate);");
	$PREPARE odrate FROM $stmt4;
	$DECLARE outdrate CURSOR FOR odrate;  
	$OPEN    outdrate;	
	printf("-----> into drate_ym \n");
	printf("stmt4[%s]\n\n\n",stmt4);
	for(;;)
	{
		$FETCH outdrate INTO $iprovision_in,$drate_ym_in,$iclass_in,$dbegin_in;
		if (SQLCODE == SQLNOTFOUND) break;		
		sprintf_s(stmt5, sizeof stmt5,"SELECT a.iprovision,a.drate_ym,a.iclass,a.dbegin,cast(a.iarticle as int),a.fcont,a.narticle,b.icontent,b.fcont,b.ncontent \
		                                 FROM ca_provision a , ca_prov_content b  \
		                                WHERE a.iprovision = b.iprovision \
		                                  AND a.drate_ym = b.drate_ym \
		                                  AND a.iclass = b.iclass \
		                                  AND a.dbegin = b.dbegin \
		                                  AND a.iarticle = b.iarticle \
		                                  AND a.iprovision = '%s' \
		                                  AND a.drate_ym = '%s' \
		                                  AND a.iclass = '%s' \
		                                  AND a.dbegin = '%s' \
		                                  AND (a.dexpire IS NULL OR a.dexpire = '' OR a.dexpire >= today) \
		                                ORDER BY 1,2,3,5,8 ",iprovision_in,drate_ym_in,iclass_in,dbegin_in);
		$PREPARE pro FROM $stmt5;
		$DECLARE pro1 CURSOR FOR pro;  
		$OPEN    pro1;
		printf("stmt5[%s]\n\n\n",stmt5);
		for(;;)
		{
			$FETCH pro1 INTO $iprovision,$drate_ym,$iclass,$dbegin,$iarticle,$fcont1,$narticle,$icontent,$fcont2,$ncontent; 
			if (SQLCODE == SQLNOTFOUND) break;
			strcpy(iprovision,trim(iprovision));
			strcpy(drate_ym,trim(drate_ym));
			strcpy(iclass,trim(iclass));
			strcpy(dbegin2,cm_from_infdate_100(dbegin));
			cm_char_split_3ymd(dbegin2,dbegin2_yy,dbegin2_mm,dbegin2_dd);
			strcpy(ncontent2,trim(ncontent));
			/* CAR162���ڲ��s�ץ��A�h���h�l���ť� (1140304006_C01) */
			strcpy(ncontent,rtrim(ncontent));
			strcpy(narticle,rtrim(narticle));
			if(iarticle ==1 && icontent ==1)
			{
				$SELECT fcont,narticle
				   INTO $nprovision_fcont,$nprovision
				   FROM ca_provision
				  WHERE iprovision = $iprovision
				    AND drate_ym = $drate_ym
				    AND iclass = $iclass
				    AND dbegin = $dbegin
				    AND iarticle = 'P';
				
				$SELECT fcont,narticle
				   INTO $nnumber_fcont,$nnumber
				   FROM ca_provision
				  WHERE iprovision = $iprovision
				    AND drate_ym = $drate_ym
				    AND iclass = $iclass
				    AND dbegin = $dbegin
				    AND iarticle = 'N';
			
				fprintf(fp2,"~~%s_%s_%s_%s%s%s\n",iprovision,drate_ym,iclass,dbegin2_yy,dbegin2_mm,dbegin2_dd);
				ptr = strtok(nprovision,",");
				while(ptr)
				{
					nprovision2[0] = '\0';
					strcpy(nprovision2,ptr);
					strcpy(nprovision2,trim(nprovision2));
					if(strlen(nprovision2) == 0)
						break;
					fprintf(fp2,"%s%s\n",nprovision_fcont,nprovision2);
					ptr = strtok(NULL, ",");
				}
				ptr2 = strtok(nnumber,",");
				while(ptr2)
				{
					nnumber2[0] = '\0';
					strcpy(nnumber2,ptr2);
					strcpy(nnumber2,rtrim(nnumber2));
					if(strlen(nnumber2) == 0)
						break;
					fprintf(fp2,"%s%s\n",nnumber_fcont,nnumber2);
					ptr2 = strtok(NULL, ",");
				}					
				fprintf(fp2,"%s%s\n%s%s\n",fcont1,narticle,fcont2,ncontent);
			}
			else if(iarticle !=1 && icontent ==1) 
			{
				if(strlen(ncontent2)==0)
					fprintf(fp2,"%s%s\n",fcont1,narticle);
				else
					fprintf(fp2,"%s%s\n%s%s\n",fcont1,narticle,fcont2,ncontent);	
			}
			else
				fprintf(fp2,"%s%s\n",fcont2,ncontent);
		}
		$CLOSE pro1;
		$FREE  pro1;	
	}
	$CLOSE outdrate;
	$FREE  outdrate;
	fclose(fp2);
	$COMMIT WORK;
	return M_CM_OK;

errexit:
	fclose(fp2);
	printf("-- Query_policy -- SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
	$ROLLBACK WORK;
	return SQLCODE;
}
/*-------------------------------THE END--------------------------------------*/


