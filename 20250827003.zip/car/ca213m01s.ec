/************************************************/
/*                                              */
/*   PROGRAM : car213m01s.ec			            */
/*   Author  : Julia Han 			               */
/*   Date    : 2006/09/08			               */
/*   Name    : �����O�T�D�O����@�{��		      */
/*                                              */
/************************************************/
     
#include <stdio.h>
#include <stdlib.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "ISvar.h"
#include "cmnmsgs.h" /* need to take off when create new error messages */
#include "safeclib.h"

/*#define AGENT_RATE              6+1     /* �N�z�v               */
/*#define COMMENT                 10+1    /* �Ƶ�                 */
/*#define COMMISS_RATE            6+1     /* �����v               */
/*#define DISCOUNT_RATE           10+1    /* �����v               */
/*#define PROFIT_COMM_RATE        6+1     /* �զ��v               */
/*#define TYPE_DESCRIPTION        10+1    /* ���O����             */
/*#define MSERVICE_RATE           10+1    /* ����O               */

typedef struct {
    char   irisk[2];
    int    qcar_age;
    int    qmiles_limit;
    int    mprem;
} car213_dtl;

typedef struct {
    char   ikits[4];
} car213_kits;

long car213(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 	long rtncode;
 	long car213_insert(),car213_single_query(),car213_multiple_query(),car213_update_exec();
 	long car213_check_compId(),car213_check_jobtype(),car213_check_irate();
 	long car213_check_zipcode(),car213_print();
 	char option;

 	cm_buf_init(command);
 	cm_buf_get("%c",&option);

 	switch(option)
 	{
  		case 'A':
           		rtncode=car213_insert(reply);
           		break;
  		case 'Q':
           		rtncode=car213_single_query(reply);
           		break;
  		case 'M':
           		rtncode=car213_multiple_query(reply);
           		break;
  		case 'D':
  		case 'U':
           		rtncode=car213_update_exec(reply,command,com_len);
           		break;
           	case '1':
           		rtncode = car213_check_compId(reply);
           		break;
           	case '2':
           		rtncode = car213_check_jobtype(reply);
           		break;
           	case '3':
           		rtncode = car213_check_irate(reply);
           		break;
           	case '4':
           		rtncode = car213_check_zipcode(reply);
           		break;
           	case '5':
                	rtncode = car213_check_iroute(reply);
                	break;
                case '6':
                	rtncode = car213_check_ikits(reply);
                	break;
           	case 'S':
                	rtncode = car213_print(reply,command,com_len);
                	break;
           	case 'P':
                	rtncode = car213_pdf_print(reply,command,com_len);
                	break;
  		default :
           	if (exitsub(reply,M_CM_WRONG_OPTION) == True)
              	return M_CM_WRONG_OPTION;
           	return apiRC;
 	}
 	return(rtncode);
}

/******************************************************/
/*  Insert					      */
/******************************************************/
long car213_insert(reply)
serverReply reply;
{
	/* standard defined host variables */
	$char DBName[DBNAME];
	/* end of standard host var */
	
	/* define table fields */
	$char ipolicy_prv[21];
	$char ipolicy[21],iassured[11],nassured[121],icareer[8];
	$char dply_begin[11],dply_end[11],dpolicy[11];
	$char strdply_begin[11],strdply_end[11];
	$char aassured_zip[CA_ZIP],aassured[91],abusiness_zip[CA_ZIP],abusiness[91];
	$int  qperiod_ori,qmiles_ori;
	$char icar_flag[2],iparts[2];
	$int  qperiod,qmiles,iply_seq;
	$char irate[11],nmodule[41],ientry[11];
	$long mcover1,mcover2,mdeduct,dcreate;
	$char nrepresent[121];
	$char creator[11],sTmpIbranch[3],sTmpIcomp[2];
	$char iins_type_dmg[21],iins_type_brg[21],itel[21],itel_night[21],mobil_phone[21];
	$char iroute[21],iofficer[11],strdexpire[8],dexpire[11];
	$char dupdate[11],iupdate[11];
	$char str_rows1[3],str_rows2[3];
	$char ikits[4],irisk[2],num1[6],num2[6],num3[6];
	$int  qcar_age=0,qmiles_limit=0,mprem=0;
	/* end of define */
	
	/* standard defined data */
	int tmp_len,rows1,rows2;
	DBinfo *list;
	int i, j, k, is_add_fail=0, api_f = 0;
	$char stmt_buf[4096],stmt[2048];
	/* end of standard data */
	
	/* self defined data */
	long MsgCode;
	char strqperiod_ori[5],strqmiles_ori[20];
	char strqperiod[5],strqmiles[20];
	char strmcover1[20],strmcover2[20],strmdeduct[20];
	long code,idate;
    	char ymd[12];
    	char estimatei[21];
    	
    	/*int rows1,rows2,tmp_len,i;*/
   	car213_kits *alist_kits;
   	car213_dtl  *alist_dtl;
	/* end of self data */

 	cm_buf_get("%s",DBName);
 	cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
 	            ipolicy_prv,strdply_begin,strdply_end,iassured,nassured,icareer,
 	            aassured_zip,aassured,abusiness_zip,abusiness,strqperiod_ori,strqmiles_ori,
 	            icar_flag,iparts,strqperiod,strqmiles,irate,
 	            nmodule,strmcover1,strmcover2,strmdeduct,creator,nrepresent,
 	            sTmpIbranch,sTmpIcomp,iins_type_dmg,iins_type_brg,itel,itel_night,mobil_phone,
 	            iroute,iofficer,strdexpire);
	strcpy(dply_begin,cm_to_infdate(strdply_begin));
        strcpy(dply_end,cm_to_infdate(strdply_end));
        strcpy(dexpire,cm_to_infdate(strdexpire));

	qperiod_ori=atoi(strqperiod_ori);
	qmiles_ori=atoi(strqmiles_ori);
	qperiod=atoi(strqperiod);
	qmiles=atoi(strqmiles);
	mcover1=atol(strmcover1);
	mcover2=atol(strmcover2);
	mdeduct=atol(strmdeduct);
	dcreate = cm_today();
	
	strcpy(iins_type_dmg, trim(iins_type_dmg));
	strcpy(iins_type_brg, trim(iins_type_brg));
	strcpy(itel, trim(itel));
	strcpy(itel_night, trim(itel_night));
	strcpy(mobil_phone, trim(mobil_phone));
	if (strlen(iins_type_dmg) == 0) strcpy(iins_type_dmg,"  ");
	if (strlen(iins_type_brg) == 0) strcpy(iins_type_brg,"");
	if (strlen(itel) == 0) strcpy(itel," ");
	if (strlen(itel_night) == 0) strcpy(itel_night," ");
	if (strlen(mobil_phone) == 0) strcpy(mobil_phone," ");
	
	cm_buf_get("%s",str_rows1);
   	rows1 = atoi(str_rows1);
   	
   	alist_kits= (car213_kits *) malloc(rows1 * sizeof (car213_kits));

   	for (k=0; k<rows1; k++)
   	{
   		cm_buf_get("%s",ikits);
   		strcpy(ikits,trim(ikits));
   		 
   		 		
   		strcpy(alist_kits[k].ikits,ikits);
   	}
   	
   	cm_buf_get("%s",str_rows2);
   	rows2 = atoi(str_rows2);
 	
   	alist_dtl = (car213_dtl *) malloc(rows2 * sizeof (car213_dtl));

   	for (k=0; k<rows2; k++)
   	{
   		cm_buf_get("%s %s %s %s",irisk,num1,num2,num3);
   		
   		strcpy(irisk,trim(irisk));
   		qcar_age = atoi(num1);
   		qmiles_limit = atoi(num2);
   		mprem = atoi(num3);

   		strcpy(alist_dtl[k].irisk,irisk);
   		alist_dtl[k].qcar_age=qcar_age;
   		alist_dtl[k].qmiles_limit=qmiles_limit;
   		alist_dtl[k].mprem=mprem;
   	}

 	if (db_select(DBName) == False) 
        { 
    		if (exitsub(reply,M_CM_DB_NOTOPEN) == True) 
       			return M_CM_DB_NOTOPEN;
    		else  
       			return apiRC;
    	}

 	if ( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
    	{
    		if (exitsub(reply,M_CM_NOT_DBLIST) == True)
       			return M_CM_NOT_DBLIST;
    		return apiRC;
    	}
    	
    	/* Get Policy Number by Using Function [cm_get_serial_num] */
        rtoday(&idate);     /* get today's datetime */ /*�۰ʵ���*/
    	strcpy(ymd,cm_cdate_str_100(idate));
    	
	$WHENEVER SQLERROR GOTO errexit;

	$BEGIN WORK;
	
	/* Check sTmpIcomp and sTmpIbranch is in the right db */    	
	if (IS_branch_upcomp_match(sTmpIbranch, DEFAULT_USE_BRANCH_ID, sTmpIcomp,
                                  USE_SHORT_BRANCH_ID) == False)
            { $ROLLBACK WORK; return M_CM_UPCOMP_NOT_MATCH;}
           
        if (strncmp(sTmpIcomp, get_upcomp(DBName, USE_BRANCH_ID,
                                         USE_SHORT_BRANCH_ID), 1) != 0)
            { $ROLLBACK WORK; return M_CM_DB_ERROR;}

    	code=cm_get_serial_num("C1", "VW", sTmpIcomp, sTmpIbranch,
                           ymd, estimatei);
                           
    	if (code==1 || code==2)  { $ROLLBACK WORK; return M_CM_DB_NOTOPEN;}
    	else if (code==3) { $ROLLBACK WORK; return M_CMN_NAUTONUMBERING;}
    	else if (code!=0) { $ROLLBACK WORK; return code;}
    	
    	printf("estimate = policy number => [%s]",estimatei);
    	/* End of Get Policy Number */
    
    	strcpy(ipolicy,estimatei);
    	iply_seq = 0;
    	strcpy(dpolicy,NULL);
    	strcpy(dupdate,NULL);
    	strcpy(iupdate,NULL);
   	
    	/* Prepare Insert Statement begins */
     	sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO ca_ply_ext  "
                "(ipolicy,dpolicy,dply_begin,dply_end,iassured,nassured,  "
                " icareer,aassured_zip,aassured,abusiness_zip,abusiness,  "
                " qperiod_ori,qmiles_ori,  "
                " icar_flag,iparts,qperiod,qmiles,irate,nmodule,mcover1,  "
                " mcover2,mdeduct,iply_seq,dentry,ientry,dupdate,iupdate,  "
                " ipolicy_prv,ipolicy_nxt,nrepresent,  "
                " iins_type_dmg,iins_type_brg,itel,itel_night,mobil_phone,  "
                " iroute,iofficer,dexpire)  "
                "VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,  "
                "current,?,'',?,?,'',?,?,?,?,?,?,?,?,?)");
                
		/*#ifdef DEBUG
		     printf("dbbranch[%d]=%s\n",j,list[j].dbbranch);
		     printf("dbname[%d]=%s\n",j,list[j].dbname);
		     printf("dbchi[%d]=%s\n",j,list[j].dbchi);
		#endif*/		
	$PREPARE a_id FROM $stmt_buf;
     	$EXECUTE a_id USING $ipolicy,$dpolicy,$dply_begin,$dply_end,$iassured,$nassured,
                            $icareer,$aassured_zip,$aassured,$abusiness_zip,$abusiness,
                            $qperiod_ori,$qmiles_ori,
                            $icar_flag,$iparts,$qperiod,$qmiles,$irate,$nmodule,$mcover1,
			    $mcover2,$mdeduct,$iply_seq,$creator,$iupdate,$ipolicy_prv,$nrepresent,
			    $iins_type_dmg,$iins_type_brg,$itel,$itel_night,$mobil_phone,
			    $iroute,$iofficer,$dexpire;
		    
     	if (SQLCODE != 0)  { is_add_fail = 1; }
     	$FREE a_id;

     	/* Update new ipolicy number in [ipolicy_nxt] field */
     	if (strcmp(ipolicy_prv,NULL) == 0 || strlen(ipolicy_prv) > 1) {
     	   $UPDATE ca_ply_ext
	    SET ipolicy_nxt = $ipolicy
	    WHERE ipolicy = $ipolicy_prv;
	 }
	/* Update new ipolicy number in [ipolicy_nxt] field ends */
	
	/* ��T�M��[�ظm�T�������O�T�I�����κި�t��](1090508001_SC2) */		
	for(j=0;j<i;j++)
 	{
 		sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO ca_ply_ext_kits  "
 		       "(ipolicy,ikits,dcreate) VALUES (?,?,current)");
		       
 		for (k=0; k<rows1; k++)
 		{
 			$PREPARE a_kits FROM $stmt_buf;
	 		strcpy(ikits,alist_kits[k].ikits);
  	        		
        		$EXECUTE a_kits using $ipolicy,$ikits;
  
        		if(SQLCODE != 0)
        		{
        			is_add_fail = 3;
        			break;
        		}
        	}
        	
        	if (is_add_fail == 3)
        	{
        		is_add_fail = 1;
        		break;
        	}

		/*cm_buf_init(ReplyBuf);
  		cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  		tmp_len = cm_buf_len(ReplyBuf);
  		if( j == i-1 )
    		api_f = api_OKComplete;
  		else
    		api_f = api_OK;

  		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
  		{
  			is_add_fail = 2;
  			break;
  		}*/
 	} /* for loop */ 
 	free(alist_kits);
     	$FREE a_kits;
   	
     	for(j=0;j<i;j++)
 	{
 		sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO ca_limitprem_ext  "
 		      "(ipolicy,irisk,qcar_age,qmiles_limit,mprem,dcreate)  "
 		      "VALUES (?,?,?,?,?,current)");
 		       	       
 		for (k=0; k<rows2; k++)
 		{  	
 			$PREPARE a_dtl FROM $stmt_buf;
	 		strcpy(irisk,alist_dtl[k].irisk);
	 		qcar_age=alist_dtl[k].qcar_age;
        		qmiles_limit=alist_dtl[k].qmiles_limit;
        		mprem=alist_dtl[k].mprem;
   	  		  		        		
        		$EXECUTE a_dtl using $ipolicy,$irisk,$qcar_age,$qmiles_limit,$mprem;
        		
        		if(SQLCODE != 0)
        		{
        			is_add_fail = 3;
        			break;
        		}   
        	}
	
        	if (is_add_fail == 3)
        	{
        		is_add_fail = 1;
        		break;
        	}
		/*cm_buf_init(ReplyBuf);
  		cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  		tmp_len = cm_buf_len(ReplyBuf);
  		if( j == i-1 )
    		api_f = api_OKComplete;
  		else
    		api_f = api_OK;

  		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
  		{
  			is_add_fail = 2;
  			break;
  		}*/
 	} /* for loop */ 
 	free(alist_dtl);
     	$FREE a_dtl;
	
	cm_buf_init(ReplyBuf);
     	/*cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);*/
     	
     	cm_buf_put("%l",M_CM_OK);
     	/* try out */
     	cm_buf_put("%s",ipolicy);
     	/* try out ends */
     	
     	tmp_len = cm_buf_len(ReplyBuf);
     	
     	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
        { is_add_fail = 2; } 

 	if( is_add_fail == 1 ) goto errexit;
 	if( is_add_fail == 2 ) 
   	{
   		$WHENEVER SQLERROR CONTINUE;
   		$ROLLBACK WORK;
   		return apiRC;
   	}

 	$WHENEVER SQLERROR GOTO errexit;
 	$COMMIT WORK;
 	return api_OKComplete;

errexit:
  	$WHENEVER SQLERROR CONTINUE;    
  	MsgCode = SQLCODE;
  	$ROLLBACK WORK;
  	if (SQLCODE != 0) MsgCode = SQLCODE;
  	if (exitsub(reply,MsgCode) == True) 
     	return MsgCode;
  	else  
     	return apiRC;
}

/******************************************************/
/*  Single Query                                      */
/******************************************************/
long car213_single_query(reply)
serverReply reply;
{
	/* standard defined host variables */
	$char DBName[DBNAME];
	/* end of standard host var */
	
	/* define table fields */
	$char ipolicy_prv[21];
	$char ipolicy[21],iassured[11],nassured[121],icareer[8];
	$long dpolicy = 0,dply_begin = 0,dply_end = 0;
	$char dcreate[30];
	/*$long dcreate;*/
	$char sdpolicy[11],sdply_begin[11],sdply_end[11];
	$char sdcreate[11];
	$char aassured_zip[CA_ZIP],aassured[91],abusiness_zip[CA_ZIP],abusiness[91];
	$int qperiod_ori = 0,qmiles_ori = 0;
	$char icar_flag[2],iparts[2];
	$int qperiod = 0,qmiles = 0,iply_seq = 0;
	$char irate[11],nmodule[41],ientry[11];
	$long mcover1 = 0,mcover2 = 0,mdeduct = 0;
	$char creator[11];
	$char iupdate[11],dupdate[30];
	$char creatorName[11],iupdateName[11];
	$char nrepresent[121];
	$char iins_type_dmg[21],iins_type_brg[21],itel[21],itel_night[21],mobil_phone[21];
	$char iroute[21],iofficer[11],dexpire[11],sdexpire[11];
	$char ikits[4],irisk[2];
	$int  qcar_age=0,qmiles_limit=0,mprem=0;
	/* end of define */
	
	/* standard defined data */
	int tmp_len;
	int rows1=0,rows2=0;
	/* end of standard data */

	cm_buf_get("%s",DBName);
	cm_buf_get("%s",ipolicy); 

 	$WHENEVER SQLERROR GOTO errexit;

 	if (db_select(DBName) == False) 
    {
    	if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
       		return M_CM_DB_NOTOPEN;
    	else
       		return apiRC;
    }
 	$SELECT dpolicy,dply_begin,dply_end,iassured,nassured,icareer,
 		 aassured_zip,aassured,abusiness_zip,abusiness,qperiod_ori,qmiles_ori,
 		 icar_flag,iparts,qperiod,qmiles,irate,nmodule,mcover1,mcover2,mdeduct,
 		 iply_seq,dentry,ientry,ipolicy_prv,dupdate,iupdate,nrepresent,
 		 iins_type_dmg,iins_type_brg,itel,itel_night,mobil_phone,iroute,iofficer,dexpire
         INTO $dpolicy,$dply_begin,$dply_end,$iassured,$nassured,$icareer,
       	    $aassured_zip,$aassured,$abusiness_zip,$abusiness,$qperiod_ori,$qmiles_ori,
       	    $icar_flag,$iparts,$qperiod,$qmiles,$irate,$nmodule,$mcover1,$mcover2,
       	    $mdeduct,$iply_seq,$dcreate,$creator,$ipolicy_prv,$dupdate,$iupdate,$nrepresent,
       	    $iins_type_dmg,$iins_type_brg,$itel,$itel_night,$mobil_phone,$iroute,$iofficer,$dexpire
         FROM ca_ply_ext
   	 WHERE ipolicy = $ipolicy;

printf("select ipolicy[%s]\n",ipolicy);
 	if (SQLCODE==SQLNOTFOUND)
    {
    	if (exitsub(reply,M_CM_NOT_FOUND) == True)
       		return M_CM_NOT_FOUND;
    	else
       		return apiRC;
    }       
       
 	strcpy(sdply_begin, cm_cdate_str_100(dply_begin));
 	strcpy(sdply_end, cm_cdate_str_100(dply_end));
 	strcpy(sdpolicy, cm_cdate_str_100(dpolicy));
 		
 	strcpy(dexpire, trim(dexpire));
 	if (strlen(dexpire) > 0)
 	    strcpy(sdexpire, cm_from_infdate_100(dexpire));
 	else
 	    strcpy(sdexpire, "");
	
 	/* Find the names of creator and iupdate */
 	 if (strlen(creator) > 3) { /* make sure creator has data */
 	  $SELECT nname
 	   INTO $creatorName
 	   FROM officer
 	   WHERE iofficer = $creator;
 	} else {
 		strcpy(creatorName,NULL);
 	}
 	 if (strlen(iupdate) > 3) { /* make sure iupdate has data */
 	  $SELECT nname
 	   INTO $iupdateName
 	   FROM officer
 	   WHERE iofficer = $iupdate;
 	} else {
 		strcpy(iupdateName,NULL);
 	}
 	/* End of finding */
printf("========================================\n");
printf("ipolicy=[%s]\n",ipolicy);
printf("ipolicy_prv=[%s]\n",ipolicy_prv);
printf("sdply_begin=[%s]\n",sdply_begin);
printf("sdply_end=[%s]\n",sdply_end);
printf("iassured=[%s]\n",iassured);
printf("nassured=[%s]\n",nassured);
printf("icareer=[%s]\n",icareer);
printf("aassured_zip=[%s]\n",aassured_zip);
printf("aassured=[%s]\n",aassured);
printf("abusiness_zip=[%s]\n",abusiness_zip);
printf("abusiness=[%s]\n",abusiness);
printf("qperiod_ori=[%s]\n",qperiod_ori);
printf("qmiles_ori=[%s]\n",qmiles_ori);
printf("icar_flag=[%s]\n",icar_flag);
printf("iparts=[%s]\n",iparts);
printf("qperiod=[%s]\n",qperiod);
printf("qmiles=[%s]\n",qmiles);
printf("irate=[%s]\n",irate);
printf("nmodule=[%s]\n",nmodule);
printf("mcover1=[%s]\n",mcover1);
printf("mcover2=[%s]\n",mcover2);
printf("mdeduct=[%s]\n",mdeduct);
printf("iply_seq=[%s]\n",iply_seq);
printf("nrepresent=[%s]\n",nrepresent);
printf("dcreate=[%s]\n",dcreate);
printf("creator=[%s]\n",creator);
printf("iupdate=[%s]\n",iupdate);
printf("iins_type_dmg",iins_type_dmg);
printf("iins_type_brg=[%s]\n",iins_type_brg);
printf("itel=[%s]\n",itel);
printf("itel_night=[%s]\n",itel_night);
printf("mobil_phone=[%s]\n",mobil_phone);
printf("iroute=[%s]\n",iroute);
printf("iofficer=[%s]\n",iofficer);
printf("sdexpire=[%s]\n",sdexpire);
printf("========================================\n");
 	
 	cm_buf_init(ReplyBuf);
        cm_buf_res_msg();  
        cm_buf_res_count();
        cm_buf_res_count();
 	/*cm_buf_put("%l",M_CM_OK);*/
 	cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %d %d %s %s %d %d %s %s %l %l %l %d %s %s %s %s %s %s %s %s %s %s %s",
 			ipolicy_prv,ipolicy,sdply_begin,sdply_end,iassured,nassured,icareer,
 			aassured_zip,aassured,abusiness_zip,abusiness,qperiod_ori,qmiles_ori,icar_flag,
 			iparts,qperiod,qmiles,irate,nmodule,mcover1,mcover2,mdeduct,iply_seq,
 			dcreate,creator,nrepresent,iins_type_dmg,iins_type_brg,itel,
 			itel_night,mobil_phone,iroute,iofficer,sdexpire);
 			
 	/* 1090508001_SC2_��T�M��[�ظm�T�������O�T�I�����κި�t��] */
 	$DECLARE cur_kits CURSOR for
    	  SELECT ikits
    	    INTO $ikits
    	    FROM ca_ply_ext_kits
    	   WHERE ipolicy = $ipolicy;
    	
    	$OPEN cur_kits;
    	
    	for(;;)
    	{
    		$FETCH cur_kits;
    		if (SQLCODE != 0) break;
    		
    		cm_buf_put("%s",ikits);
    		rows1++;
	}	
	$CLOSE cur_kits;
	$FREE cur_kits;
	
	cm_buf_put_count_seq(1,rows1);
	
	$DECLARE cur_ext CURSOR for
    	  SELECT irisk, qcar_age, qmiles_limit, mprem
    	    INTO $irisk, $qcar_age, $qmiles_limit, $mprem
    	    FROM ca_limitprem_ext
    	   WHERE ipolicy = $ipolicy;
    	
    	$OPEN cur_ext;
    	
    	for(;;)
    	{
    		$FETCH cur_ext;
    		if (SQLCODE != 0) break;
    		
    		cm_buf_put("%s %d %d %d",irisk,qcar_age,qmiles_limit,mprem);
    		rows2++;
	}
	
	$CLOSE cur_ext;
	$FREE cur_ext;
	
	cm_buf_put_count_seq(2,rows2);

 	cm_buf_put("%s %s %s %s %s",sdpolicy,iupdate,dupdate,creatorName,iupdateName);

 	cm_buf_put_msg(M_CM_OK);
 	tmp_len = cm_buf_len(ReplyBuf);
 	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    	return apiRC;
 	else
    	return api_OKComplete;

errexit:
  	if (exitsub(reply,SQLCODE) == True) 
     	return SQLCODE;
  	else  
     	return apiRC;
}

/******************************************************/
/* Multiple Query                                     */
/******************************************************/
long car213_multiple_query(reply)
serverReply reply;
{
	/* standard defined host variables */
	$char DBName[DBNAME];
	/* end of standard host var */
	
	/* table commission_agent */
	$char ipolicy[21],sdply_begin[11],nassured[121];
	$char dply_begin[11];
	$char iparts[2],irate[11];
	$int qperiod,qmiles;
	$char sqperiod[5],sqmiles[20];
	$char stmt_dplybegin[128],stmt_qperiod[128],stmt_qmiles[128];
	$char stmt[1024];
	/* end of commission_agent */
	
	/* standard defined data */
	char tmpbuf[4000];
	int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
	int i,total_count=0; 
	/* end of standard data */

	cm_buf_get("%s",DBName);
	cm_buf_get("%s %s %s %s %s %s %s",ipolicy,sdply_begin,nassured,
			iparts,sqperiod,sqmiles,irate); 

	if (strcmp(sdply_begin,"*")!=0) 
	{
printf("sdate[%s]\n",sdply_begin);		
		strcpy(dply_begin,cm_to_infdate(sdply_begin));
		sprintf_s(stmt_dplybegin, sizeof stmt_dplybegin,"AND dply_begin = '%s'",dply_begin);
printf("date[%s]\n",dply_begin);		
	}
	
	if (strcmp(sqperiod,"*")!=0)
	{
		qperiod=atoi(sqperiod);
		sprintf_s(stmt_qperiod, sizeof stmt_qperiod,"AND qperiod = %d",qperiod);
	}
	
	if (strcmp(sqmiles,"*")!=0)
	{
		qmiles=atoi(sqmiles);
		sprintf_s(stmt_qmiles, sizeof stmt_qmiles,"AND qmiles = %d",qmiles);
	}
			
printf("multi-selected ipolicy[%s];;sdply_begin[%s];;\n",ipolicy,dply_begin);
printf("nassured[%s];;iparts[%s];;qperiod[%d];;qmiles[%d];;\n",nassured,iparts,qperiod,qmiles);
printf("irate[%s]\n",irate);

 	$WHENEVER SQLERROR GOTO errexit;

 	if (db_select(DBName) == False) 
        {
    	   if (exitsub(reply,M_CM_DB_NOTOPEN) == True) 
       		return M_CM_DB_NOTOPEN;
    	   else  
       		return apiRC;
        }
 
        sprintf_s(stmt, sizeof stmt,"SELECT ipolicy FROM ca_ply_ext  "
        	     "WHERE ipolicy matches '%s'  "
        	     "  AND nassured matches '%s'  "
        	     "  AND iparts matches '%s'  "
        	     "  AND irate matches '%s' %s %s %s  "
        	     "  ORDER BY ipolicy",ipolicy,nassured,iparts,irate,
        	        stmt_dplybegin,stmt_qperiod,stmt_qmiles);
 
printf("stmt=[%s]\n",stmt);  	
   	
        $PREPARE CUR_STMT FROM $stmt;
        $DECLARE q_cur CURSOR FOR CUR_STMT;
   	
 	$OPEN q_cur;

 	for (;;)
    {
    	$FETCH q_cur
    	  INTO $ipolicy;
    	  
    	if (SQLCODE != 0) break;

    	cm_buf_init(tmpbuf); 
    	if ( count == 0 )
       	{
       		cm_buf_res_msg();             /* reserve for MsgCode and count */
       		cm_buf_res_count();          
       	}
    	cm_buf_put("%s",ipolicy);

    	tmp_len = cm_buf_len(tmpbuf);
    	if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
       	{
       		memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
       		repbuf_len += tmp_len;
       		count++;
       	}
    	else                               /* more than 4K, send to client side */ 
       	{   
       		cm_buf_init(ReplyBuf);
       		cm_buf_put_msg(M_CM_OK);
       		cm_buf_put_count(count);
       		if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
          	{	
          		$CLOSE q_cur; $FREE q_cur;
          		return apiRC;
          	}
       		else               /* clear ReplyBuf and count to start all over again */
          	{
          		replycnt++;
          		if (replycnt == 10)   /* more than 30K, client cannot display,error */
             	{
             		cm_buf_init(ReplyBuf);
             		cm_buf_put("%l",M_CM_OUT_SPACE);
             		tmp_len = cm_buf_len(ReplyBuf);
             		if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                		return apiRC;
             		return M_CM_OUT_SPACE; 
             	}
          		ReplyBuf[0] = '\0';
          		count = 0;
          		cm_buf_init(ReplyBuf);
          		cm_buf_res_msg();           /* reserve for MsgCode and count */
          		cm_buf_res_count();    
          		cm_buf_put("%s",ipolicy);
          		repbuf_len = cm_buf_len(ReplyBuf);
          		count++;
          	}
       	} 
    } /* for loop */

 	$CLOSE q_cur;  $FREE q_cur;
 	if (count > 0)   /* break out, at least one record is selected */
    {
    	cm_buf_init(ReplyBuf);
    	cm_buf_put_msg(M_CM_OK);
    	cm_buf_put_count(count);
    	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
       		return apiRC;
    	return api_OKComplete;
    }
 	else            /* break out, not any row is found */
    {
    	if (exitsub(reply,M_CM_NOT_FOUND) == True) 
       		return M_CM_NOT_FOUND;
    	else  
       		return apiRC;
    } 

errexit:
  	if (exitsub(reply,SQLCODE) == True)
     	return SQLCODE;
  	else  
     	return apiRC;
}

/******************************************************/
/*  Update Execute                                    */
/******************************************************/
long car213_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	/* standard defined host variables */
	$char DBName[DBNAME];
	/* end of standard host var */
	
	/* define table fields */
	$char ipolicy_prv[21],ipolicy_nxt[21];
	$char dentry[41],db_dentry[41],fulldentry[41];
	$char old_ipolicy[21],ipolicy[21];
	$char sdply_begin[11],sdply_end[11],sdpolicy[11];
	$char udply_begin[11],udply_end[11];
	$long dply_begin,dply_end,dpolicy;
	$char iassured[11],nassured[121],icareer[8];
	$char aassured_zip[CA_ZIP],aassured[91],abusiness_zip[CA_ZIP],abusiness[91];
	$char iins_type_dmg[21],iins_type_brg[21],iroute[21],iofficer[11];
	$int  qperiod_ori,qmiles_ori;
	$char icar_flag[2],iparts[2];
	$int  qperiod,qmiles,iply_seq;
	$char irate[11],nmodule[41];
	$long mcover1,mcover2,mdeduct;
	$char ientry[11];
	$char iupdate[11];
	$char del_dplybegin[11];
	$char nrepresent[121];
	$char itel[21],itel_night[21],mobil_phone[21];
	$char sdexpire[8],dexpire[11];
	$char str_rows1[3],str_rows2[3];
	$char ikits[4],irisk[2],num1[6],num2[6],num3[6];
	$int  qcar_age=0,qmiles_limit=0,mprem=0;
	/* end of define */
	
	/* standard defined data */
	char  option,*pos,*raw_ptr,cur_buf[4000],*comm;
	int   tmp_len,raw_len,rows1,rows2;
	long  dummy=0;
	DBinfo *list;
	int   i, j, k, is_del_fail=0, is_upd_fail=0;
	$char stmt_buf[500],stmt_insert[500];
	/* end of standard data */
	
	/* self defined data */
	long MsgCode;
	char sqperiod_ori[5],sqmiles_ori[5];
	char sqperiod[5],sqmiles[20];
	char smcover1[20],smcover2[20],smdeduct[20];
	char siply_seq[5];
	
	car213_kits *alist_kits;
   	car213_dtl  *alist_dtl;
	/* end of self data */
	
	comm = (char *) command;
	cm_buf_init(command);
	cm_buf_get("%c %s",&option,DBName);

	$WHENEVER SQLERROR GOTO errexit;

 	if (db_select(DBName) == False)
    	{
    		if (exitsub(reply,M_CM_DB_NOTOPEN) == True) return M_CM_DB_NOTOPEN;
    		else	return apiRC;
    	}

 	if ( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
    	{
    		if (exitsub(reply,M_CM_NOT_DBLIST) == True)	return M_CM_NOT_DBLIST;
    		return apiRC;
    	}
	
	/* get old record info from command buffer */

	memcpy(&raw_len,&comm[com_len],sizeof(int));
	pos = &comm[com_len+sizeof(int)];
	raw_ptr = malloc(raw_len);

 	if (raw_ptr != (char*)0) {
    		memcpy(raw_ptr,pos,raw_len);
	}
 	else
    	{
    		if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
    		{	
    			free(raw_ptr);
    			return M_CM_NOT_MALLOC;
    		}	
    		else	
    		{
    			free(raw_ptr);
    			return apiRC;
    		}
    	}
   
 	cm_buf_init(raw_ptr);          /* get index key from old record */
 	cm_buf_get("%l",&dummy);
 	cm_buf_res_count();
        cm_buf_res_count();
 	cm_buf_get("%s",ipolicy_prv);
	/* comparing data set */
	cm_buf_get("%s",old_ipolicy);
	cm_buf_get("%s %s %s %s %s %s",sdply_begin,sdply_end,iassured,nassured,icareer,aassured_zip);
	cm_buf_get("%s %s %s %s %s",aassured,abusiness_zip,abusiness,sqperiod_ori,sqmiles_ori);
	cm_buf_get("%s %s %s",icar_flag,iparts,sqperiod);
	cm_buf_get("%s %s %s %s %s %s",sqmiles,irate,nmodule,smcover1,smcover2,smdeduct);
	cm_buf_get("%s",siply_seq); 
	cm_buf_get("%s",dentry);
	cm_buf_get("%s",ientry);
	cm_buf_get("%s",nrepresent);
	/* comparing data set */
		
 	$BEGIN WORK;
 	$WHENEVER SQLERROR GOTO errexit;
 	/* table lock is necessary to avoid concurrent update problems */

 	$LOCK TABLE ca_ply_ext IN SHARE MODE;

 	$SELECT dply_begin,dpolicy,dentry,ipolicy_nxt,
 	        iins_type_dmg,iins_type_brg,iroute,iofficer
           INTO $del_dplybegin,$sdpolicy,$db_dentry,$ipolicy_nxt,
                $iins_type_dmg,$iins_type_brg,$iroute,$iofficer
           FROM ca_ply_ext
           WHERE ipolicy = $old_ipolicy;
  
 	if (SQLCODE == SQLNOTFOUND)
        {
    		$WHENEVER SQLERROR CONTINUE;
    		$ROLLBACK WORK;
    		if (exitsub(reply,M_CM_NOT_FOUND) == True)
        		return M_CM_NOT_FOUND;
    		else
        		return apiRC;
    	}
    	
    	strcpy(dentry,trim(dentry));
    	strcpy(db_dentry,trim(db_dentry));

 	if (strcmp(dentry,db_dentry) != 0)
        {
    		$WHENEVER SQLERROR CONTINUE;
    		$ROLLBACK WORK;
    		if(exitsub(reply,M_CM_NOT_EQUAL) == True)
        		return M_CM_NOT_EQUAL;
    		else
        		return apiRC;
    	}
    	
 	$WHENEVER SQLERROR GOTO errexit;

 	/* equal, then exec DB operation */

 	if ( option == 'D' )
 	{
 		for (j=0;j<i;j++)
 		{
printf("delete function => ipolicy = [%s]",old_ipolicy);
 			
 			sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM ca_ply_ext WHERE ipolicy= ?");
 			$PREPARE d_id FROM $stmt_buf;
 			if (SQLCODE != 0)       { is_del_fail = 1;      break; }
 			$EXECUTE d_id USING $old_ipolicy;
 			if (SQLCODE != 0)       { is_del_fail = 1;      break; }
 			$FREE d_id;
 			
 			sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM ca_ply_ext_kits WHERE ipolicy= ?");
 			$PREPARE d1_id FROM $stmt_buf;
 			if (SQLCODE != 0)       { is_del_fail = 1;      break; }
 			$EXECUTE d1_id USING $old_ipolicy;
 			if (SQLCODE != 0)       { is_del_fail = 1;      break; }
 			$FREE d1_id;
 			
 			sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM ca_limitprem_ext WHERE ipolicy= ?");
 			$PREPARE d2_id FROM $stmt_buf;
 			if (SQLCODE != 0)       { is_del_fail = 1;      break; }
 			$EXECUTE d2_id USING $old_ipolicy;
 			if (SQLCODE != 0)       { is_del_fail = 1;      break; }
 			$FREE d2_id;
 			
 			/* �N�R���O�檺�e��O��M�� */
 			$UPDATE ca_ply_ext
 			SET ipolicy_prv = NULL
 			WHERE ipolicy = $ipolicy_nxt;
 			
 			$UPDATE ca_ply_ext
 			SET ipolicy_nxt = NULL
 			WHERE ipolicy = $ipolicy_prv;
 			/* ends process */
 			
printf("put in re-usable table => dplybegin[%s],ipolicy[%s]",del_dplybegin,old_ipolicy);  	
 			$INSERT INTO reusible_num (dwritten,qwritten_num)
 			VALUES ($del_dplybegin, $old_ipolicy);
 		}/* for loop */

   		if( is_del_fail ) goto errexit;

   		cm_buf_init(ReplyBuf);
   		cm_buf_put("%l",M_CM_OK);
   		tmp_len = cm_buf_len(ReplyBuf);
   		if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   		{
   			$WHENEVER SQLERROR CONTINUE;
   			$ROLLBACK WORK;
   			return apiRC;
   		}

   		$WHENEVER SQLERROR GOTO errexit;
   		$COMMIT WORK;
   		return api_OKComplete;
   	} /* end if option == 'D' */
 	else if (option == 'U')
   	{
   		cm_buf_init(command);
   		cm_buf_get("%c",&option);
		cm_buf_get("%s",DBName);
		cm_buf_get("%s",ipolicy);
   		cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s %s %s",ipolicy_prv,sdply_begin,sdply_end,
   				iassured,nassured,icareer,aassured_zip,aassured,abusiness_zip,
   				abusiness,sqperiod_ori,sqmiles_ori,icar_flag,iparts);

   		cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",sqperiod,sqmiles,
   		                irate,nmodule,smcover1,smcover2,smdeduct,siply_seq,nrepresent,dentry,
   		                ientry,iupdate,iins_type_dmg,iins_type_brg,itel,itel_night,mobil_phone,
   		                iroute,iofficer,sdexpire);
   				
		strcpy(udply_begin,cm_to_infdate(sdply_begin));
		strcpy(udply_end,cm_to_infdate(sdply_end));
		strcpy(dexpire,cm_to_infdate(sdexpire));

		qperiod_ori=atoi(sqperiod_ori);
		qmiles_ori=atoi(sqmiles_ori);
		qperiod=atoi(sqperiod);
		qmiles=atoi(sqmiles);
		mcover1=atol(smcover1);
		mcover2=atol(smcover2);
		mdeduct=atol(smdeduct);
		iply_seq=atoi(siply_seq);
		
		cm_buf_get("%s",str_rows1);
		rows1 = atoi(str_rows1);
		
		alist_kits= (car213_kits *) malloc(rows1 * sizeof (car213_kits));
		
		for (k=0; k<rows1; k++)
		{
			cm_buf_get("%s",ikits);
			strcpy(ikits,trim(ikits));
			
			strcpy(alist_kits[k].ikits,ikits);
		}
		
		cm_buf_get("%s",str_rows2);
		rows2 = atoi(str_rows2);
		
		alist_dtl = (car213_dtl *) malloc(rows2 * sizeof (car213_dtl));
		
		for (k=0; k<rows2; k++)
		{
			cm_buf_get("%s %s %s %s",irisk,num1,num2,num3);
			
			strcpy(irisk,trim(irisk));
			qcar_age = atoi(num1);
			qmiles_limit = atoi(num2);
			mprem = atoi(num3);
			
			strcpy(alist_dtl[k].irisk,irisk);
			alist_dtl[k].qcar_age=qcar_age;
			alist_dtl[k].qmiles_limit=qmiles_limit;
			alist_dtl[k].mprem=mprem;
		}
		
		if(ipolicy ==' '){
			strcpy(ipolicy,trim(ipolicy_prv));
			strcpy(ipolicy_prv,'');
		}
		
printf("========================================\n");
printf("&option=[%c]\n",&option);
printf("DBName=[%s]\n",DBName);
printf("ipolicy=[%s]\n",ipolicy);
printf("ipolicy_prv=[%s]\n",ipolicy_prv);
strcpy(sdply_begin,cm_to_infdate(sdply_begin));
printf("sdply_begin=[%s]\n",sdply_begin);
strcpy(sdply_end,cm_to_infdate(sdply_end));
printf("sdply_end=[%s]\n",sdply_end);
printf("iassured=[%s]\n",iassured);
printf("nassured=[%s]\n",nassured);
printf("icareer=[%s]\n",icareer);
printf("aassured_zip=[%s]\n",aassured_zip);
printf("aassured=[%s]\n",aassured);
printf("abusiness_zip=[%s]\n",abusiness_zip);
printf("abusiness=[%s]\n",abusiness);
printf("sqperiod_ori=[%s]\n",sqperiod_ori);
printf("sqmiles_ori=[%s]\n",sqmiles_ori);
printf("icar_flag=[%s]\n",icar_flag);
printf("iparts=[%s]\n",iparts);
printf("sqperiod=[%s]\n",sqperiod);
printf("sqmiles=[%s]\n",sqmiles);
printf("irate=[%s]\n",irate);
printf("nmodule=[%s]\n",nmodule);
printf("smcover1=[%s]\n",smcover1);
printf("smcover2=[%s]\n",smcover2);
printf("smdeduct=[%s]\n",smdeduct);
printf("siply_seq=[%s]\n",siply_seq);
printf("nrepresent=[%s]\n",nrepresent);
printf("dentry=[%s]\n",dentry);
printf("ientry=[%s]\n",ientry);
printf("iupdate=[%s]\n",iupdate);
printf("iins_type_dmg=[%s]\n",iins_type_dmg);
printf("iins_type_brg=[%s]\n",iins_type_brg);
printf("itel=[%s]\n",itel);
printf("itel_night=[%s]\n",itel_night);
printf("mobil_phone=[%s]\n",mobil_phone);
printf("iroute=[%s]\n",iroute);
printf("iofficer=[%s]\n",iofficer);
printf("dexpire=[%s]\n",dexpire);
printf("========================================\n");
		

	printf("update data ==> ipolicy[%s]\n",ipolicy);

		/* Prepare statement */
		sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE ca_ply_ext  "
                                "SET (ipolicy_prv,dply_begin,dply_end,iassured,nassured,icareer,  "
                                    " aassured_zip,aassured,abusiness_zip,abusiness,  "
                                    " qperiod_ori,qmiles_ori,  "
                                    " icar_flag,iparts,qperiod,qmiles,irate,nmodule,  "
                                    " mcover1,mcover2,mdeduct,iply_seq,dupdate,iupdate,nrepresent,  "
                                    " iins_type_dmg,iins_type_brg,itel,itel_night,mobil_phone,   "
                                    " iroute,iofficer,dexpire) "
                                 " = (?,?,?,?,?,?,  "
                                    " ?,?,?,?,  "
                                    " ?,?,  "
                                    " ?,?,?,?,?,?,  "
                                    " ?,?,?,?,current,?,?,  "
                                    " ?,?,?,?,?,   "
                                    " ?,?,?)  "
                              " WHERE ipolicy= ?");
              	$PREPARE u_id FROM $stmt_buf;
    
              	/* �]�O�T�X��ᰣ�򥻸�ƨ�l���o�ק�A�G���A�����ܾ��v�� mark by 061476 (1100204004_SC1) */
              	if(0)
              	{
              	sprintf_s(stmt_insert, sizeof stmt_insert,"INSERT INTO ca_ply_ext_hist  "
              		"(ipolicy,dpolicy,dply_begin,dply_end,iassured,nassured,  "
                  	"icareer,aassured_zip,aassured,abusiness_zip,abusiness,  "
                  	"qperiod_ori,qmiles_ori,  "
                  	"icar_flag,iparts,qperiod,qmiles,irate,nmodule,mcover1,  "
                  	"mcover2,mdeduct,iply_seq,dentry,ientry,dupdate,iupdate,ipolicy_prv,ipolicy_nxt,nrepresent,  "
                  	"iins_type_dmg,iins_type_brg,itel,itel_night,mobil_phone,iroute,iofficer,dexpire)  "
                	"VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,  "
                	"?,?,current,?,?,?,?,?,?,?,?,?,?,?,?)");
                $PREPARE a_id FROM $stmt_insert;
                }
              	
printf("========================================\n");
              	
   		$WHENEVER SQLERROR CONTINUE;
   		for (j=0;j<i;j++)
       		{
      			
       			if (SQLCODE != 0)        { is_upd_fail = 1;      break; }
       			$EXECUTE u_id USING $ipolicy_prv,$udply_begin,$udply_end,$iassured,$nassured,$icareer,
       				            $aassured_zip,$aassured,$abusiness_zip,$abusiness,
       				            $qperiod_ori,$qmiles_ori,
       				            $icar_flag,$iparts,$qperiod,$qmiles,$irate,$nmodule,
       				            $mcover1,$mcover2,$mdeduct,$iply_seq,$iupdate,$nrepresent,
       				            $iins_type_dmg,$iins_type_brg,$itel,$itel_night,$mobil_phone,
       				            $iroute,$iofficer,$dexpire,$ipolicy;
       				    
       			if (SQLCODE != 0)        { is_upd_fail = 1;      break; }
      		
       		
       			/*$FREE u_id;*/ 
       			
       			/* �]�O�T�X��ᰣ�򥻸�ƨ�l���o�ק�A�G���A�����ܾ��v�� mark by 061476 (1100204004_SC1) */
       			/*if (strcpy(sdpolicy,NULL) != 0) {
       			$EXECUTE a_id using $ipolicy,$sdpolicy,$udply_begin,
       				    $udply_end,$iassured,$nassured,$icareer,$aassured_zip,
       				    $aassured,$abusiness_zip,$abusiness,$qperiod_ori,$qmiles_ori,
       				    $icar_flag,$iparts,$qperiod,$qmiles,$irate,$nmodule,$mcover1,
       				    $mcover2,$mdeduct,$iply_seq,$dentry,$ientry,$iupdate,
       				    $ipolicy_prv,$ipolicy_nxt,$nrepresent,
       				    $iins_type_dmg,$iins_type_brg,$itel,$itel_night,$mobil_phone,
       				    $iroute,$iofficer,$dexpire;

       			}*/
       			
       			
       			if(iply_seq == 0)
       			{
       				sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM ca_ply_ext_kits WHERE ipolicy= ?");
       				$PREPARE d1_id FROM $stmt_buf;
       				if (SQLCODE != 0)       { is_del_fail = 1;      break; }
       				$EXECUTE d1_id USING $ipolicy;
       				if (SQLCODE != 0)       { is_del_fail = 1;      break; }
       				$FREE d1_id;
       				
       				sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM ca_limitprem_ext WHERE ipolicy= ? ");
       				$PREPARE d2_id FROM $stmt_buf;
       				if (SQLCODE != 0)       { is_upd_fail = 1;      break; }
       				$EXECUTE d2_id USING $ipolicy;
       				if (SQLCODE != 0)       { is_upd_fail = 1;      break; }
       				$FREE d2_id;
       			
       				sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO ca_ply_ext_kits  "
       					        "(ipolicy,ikits,dcreate) VALUES (?,?,current)");
       					
       				for (k=0; k<rows1; k++)
       				{
       					$PREPARE a_kits FROM $stmt_buf;
       					strcpy(ikits,alist_kits[k].ikits);
       						
       					$EXECUTE a_kits using $ipolicy,$ikits;
       						
       					if(SQLCODE != 0) { is_upd_fail = 1; break; }
       				}
       				$FREE a_kits;
       				
       				sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO ca_limitprem_ext  "
       					         "(ipolicy,irisk,qcar_age,qmiles_limit,mprem,dcreate)  "
       					         "VALUES (?,?,?,?,?,current)");
       					
       				for (k=0; k<rows2; k++)
       				{
       					$PREPARE a_dtl FROM $stmt_buf;
       					strcpy(irisk,alist_dtl[k].irisk);
       					qcar_age=alist_dtl[k].qcar_age;
       					qmiles_limit=alist_dtl[k].qmiles_limit;
       					mprem=alist_dtl[k].mprem;
       						
       					$EXECUTE a_dtl using $ipolicy,$irisk,$qcar_age,$qmiles_limit,$mprem;
       						
       					if(SQLCODE != 0) { is_upd_fail = 1; break; }
       				}
       				$FREE a_dtl;
       			}
	
       		} /* for loop */
       		$CLOSE u_id;
       		free(alist_kits);
       		free(alist_dtl);
       		$FREE u_id;
       		/*$CLOSE a_id;*/
       		/*$FREE a_id;*/
 
   		if( is_upd_fail ) goto errexit;
 
   		cm_buf_init(ReplyBuf);
   		cm_buf_put("%l",M_CM_OK);
   		tmp_len = cm_buf_len(ReplyBuf);
   		if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   		{
   			$WHENEVER SQLERROR CONTINUE;
   			$ROLLBACK WORK;
   			return apiRC;
   		}

   		$WHENEVER SQLERROR GOTO errexit;
   		$COMMIT WORK;
   		return api_OKComplete;
   	} /* end if option == 'U' */
 	else
   	{
   		$WHENEVER SQLERROR CONTINUE;
   		$ROLLBACK WORK;

   		if (exitsub(reply,M_CM_WRONG_OPTION) == True)
      		return M_CM_WRONG_OPTION;
   		else
      		return apiRC;
   	}

errexit:
  	$WHENEVER SQLERROR CONTINUE;
  	MsgCode = SQLCODE;
  	$ROLLBACK WORK;
  	if (SQLCODE != 0) MsgCode = SQLCODE;
  	if(exitsub(reply,MsgCode) == True)
   		return MsgCode;
  	else
   		return apiRC;
}

/******************************************************/
/*  Check Company Id Validation                       */
/******************************************************/
long car213_check_compId(reply)
serverReply reply;
{
   $char DBName[DBNAME], compid[11];
   char  err_sMsg[512];
   int   rc;
   
   char RtnCode[50];
   int tmp_len;
   long MsgCode;

   cm_buf_get("%s %s", DBName, compid);
   
   strcpy(err_sMsg,"");

   /*check_company(compid,RtnCode);*/
   rc = cm_chk_id(compid);
   if( rc != M_CM_OK) 
   {
       MsgCode = M_CMN_FIDERROR;
   }
   else
   {
       MsgCode = M_CM_OK;
   }


       

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l", MsgCode);
   tmp_len = cm_buf_len(ReplyBuf);
   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False) 
      return apiRC;
    else 
      return api_OKComplete;

errexit:
   if (exitsub(reply,SQLCODE) == True)
      return SQLCODE;
   else
      return apiRC;
}

/******************************************************/
/*  Check Job Type Validation                         */
/******************************************************/
long car213_check_jobtype(reply)
serverReply reply;
{
   $char DBName[DBNAME], jobtype[8];
   int tmp_len;
   long MsgCode;
   $int count = 0;


   cm_buf_get("%s %s", DBName, jobtype);

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
      {
      if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
         return M_CM_DB_NOTOPEN;
      else
         return apiRC;
      }

       $SELECT count(*)
          INTO $count
          FROM ot_career
         WHERE icareer = $jobtype;
          
     if (count > 0) 
       MsgCode = M_CM_OK;
     else
       MsgCode = M_CMN_NJOB_TITLE; /* �ݭק� error code */

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l", MsgCode);
   tmp_len = cm_buf_len(ReplyBuf);
   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False) 
      return apiRC;
    else 
      return api_OKComplete;

errexit:
   if (exitsub(reply,SQLCODE) == True)
      return SQLCODE;
   else
      return apiRC;
}

/******************************************************/
/*  Check irate Validation                            */
/******************************************************/
long car213_check_irate(reply)
serverReply reply;
{
   /* variables using for db */
   $char DBName[DBNAME], irate[11];
   $int qmiles, qperiod;
   $char iparts[2],icar_flag[2];
   $int count = 0;
   /* variables using for db ends */
   
   /* Local variables */
   int tmp_len;
   long MsgCode;
   char strqmiles[5],strqperiod[10];
   /* Local variables ends */

   cm_buf_get("%s %s %s %s", DBName, irate, strqmiles, strqperiod);
   cm_buf_get("%s %s", icar_flag, iparts);
   
   qmiles = atoi(strqmiles);
   qperiod = atoi(strqperiod);

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
      {
      if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
         return M_CM_DB_NOTOPEN;
      else
         return apiRC;
      }

       $SELECT count(*)
          INTO $count
          FROM ca_rate_ext
         WHERE irate = $irate
         AND qmiles = $qmiles
         AND qperiod = $qperiod
         AND iparts = $iparts
         AND icar_flag = $icar_flag;
         
     if (count > 0) 
       MsgCode = M_CM_OK;
     else
       MsgCode = M_CA_NRATE;    /* �w�ק� */

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l", MsgCode);
   tmp_len = cm_buf_len(ReplyBuf);
   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False) 
      return apiRC;
    else 
      return api_OKComplete;

errexit:
   if (exitsub(reply,SQLCODE) == True)
      return SQLCODE;
   else
      return apiRC;
}

/******************************************************/
/*  Check Zip Code Validation                         */
/******************************************************/
long car213_check_zipcode(reply)
serverReply reply;
{
   $char DBName[DBNAME], zipcode[CA_ZIP];
   int tmp_len;
   long MsgCode;
   $int count = 0;


   cm_buf_get("%s %s", DBName, zipcode);

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
      {
      if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
         return M_CM_DB_NOTOPEN;
      else
         return apiRC;
      }

       $SELECT count(*)
          INTO $count
          FROM zipcode
         WHERE izipcode = $zipcode;
          
     if (count > 0) 
       MsgCode = M_CM_OK;
     else
       MsgCode = M_CMN_NZIPCODE; /* �w�ק� */

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l", MsgCode);
   tmp_len = cm_buf_len(ReplyBuf);
   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False) 
      return apiRC;
    else 
      return api_OKComplete;

errexit:
   if (exitsub(reply,SQLCODE) == True)
      return SQLCODE;
   else
      return apiRC;
}
/******************************************************/
/*  Check iroute                                       */
/******************************************************/
long car213_check_iroute(reply)
serverReply reply;
{
	$char DBName[DBNAME],iroute[21],nroute[41],dexpire[11];
	int tmp_len;
	long MsgCode;
	
	cm_buf_get("%s %s", DBName, iroute);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
		    return M_CM_DB_NOTOPEN;
		else
		    return apiRC;
	}
	
	$SELECT nroute, dexpire
	   INTO $nroute, $dexpire
	   FROM cm_route
	  WHERE iroute = $iroute;
	
	if (SQLCODE == SQLNOTFOUND)
	{
		strcpy(nroute, " ");
		strcpy(dexpire, " ");
		MsgCode = M_CMN_NROUTE;
	}
	else
	        MsgCode = M_CM_OK;
	        
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l %s %s", MsgCode,nroute,dexpire);
	tmp_len = cm_buf_len(ReplyBuf);
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False) 
	    return apiRC;
	else 
	    return api_OKComplete;

errexit:
   if (exitsub(reply,SQLCODE) == True)
      return SQLCODE;
   else
      return apiRC;
}
/******************************************************/
/*  Check ikits                                       */
/******************************************************/
long car213_check_ikits(reply)
serverReply reply;
{
	$char DBName[DBNAME],ikits[21];
	$int count=0;
	int tmp_len;
	long MsgCode;
	
	cm_buf_get("%s %s", DBName, ikits);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
		    return M_CM_DB_NOTOPEN;
		else
		    return apiRC;
	}
	
	$SELECT count(*)
	   INTO $count
	   FROM ca_kits_ext
	  WHERE ikits = $ikits;
	
	if (SQLCODE == SQLNOTFOUND)
		MsgCode = M_CMN_NO_DATA_FOUND;
	else
	        MsgCode = M_CM_OK;
	        
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l %d", MsgCode,count);
	tmp_len = cm_buf_len(ReplyBuf);
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False) 
	    return apiRC;
	else 
	    return api_OKComplete;

errexit:
   if (exitsub(reply,SQLCODE) == True)
      return SQLCODE;
   else
      return apiRC;
}
/******************************************************/
/*  Print Function                                    */
/******************************************************/
long car213_print(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
     
    /* update iply_seq in table [ca_ply_ext] */
	$char DBName[DBNAME];
	$char ipolicy[21],print_type[3];
	$int iply_seq = 0;
	$char dpolicy[11],dpolicy_sys[11];
	
	long dpolicy_tmp;
	int  rtncode;
    	rtncode = 0;
        
        strcpy(dpolicy_sys,cm_sysd_cdate_100(cm_get_sysd()));
        strcpy(dpolicy,cm_to_infdate(dpolicy_sys));
	
	cm_buf_get("%s",DBName);
	cm_buf_get("%s",print_type);
	cm_buf_get("%s",ipolicy); 
	
	$WHENEVER SQLERROR GOTO errexit;

 	if (db_select(DBName) == False)
    	{
    		if (exitsub(reply,M_CM_DB_NOTOPEN) == True) return M_CM_DB_NOTOPEN;
    		else	return apiRC;
    	}

	$SELECT iply_seq 
	 INTO $iply_seq
	 FROM ca_ply_ext
	 WHERE ipolicy = $ipolicy;


printf("update dpolicy => iply_seq = [%d]",iply_seq);
	$UPDATE ca_ply_ext
	 SET dpolicy = $dpolicy
	 WHERE ipolicy = $ipolicy
	 AND dpolicy IS NULL;

	 if (iply_seq == 0) {
		$UPDATE ca_ply_ext
	 	SET iply_seq = 1
	 	WHERE ipolicy = $ipolicy;
	}

    rtncode=car213_laser_policy_VW(reply,command,com_len);
   
    
    return(rtncode);
    
errexit:
   if (exitsub(reply,SQLCODE) == True)
      return SQLCODE;
   else
      return apiRC;
}

/******************************************************/
/*  Print Function                                    */
/******************************************************/
long car213_pdf_print(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
     
    /* update iply_seq in table [ca_ply_ext] */
	$char DBName[DBNAME];
	$char ipolicy[21],print_type[3];
	$int iply_seq = 0;
	$char dpolicy[11],dpolicy_sys[11];
	
	long dpolicy_tmp;
	int  rtncode;
    	rtncode = 0;
        
        strcpy(dpolicy_sys,cm_sysd_cdate_100(cm_get_sysd()));
        strcpy(dpolicy,cm_to_infdate(dpolicy_sys));
	
	cm_buf_get("%s",DBName);
	cm_buf_get("%s",ipolicy); 
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False)
	{
		if (exitsub(reply,M_CM_DB_NOTOPEN) == True) return M_CM_DB_NOTOPEN;
		else	return apiRC;
	}
	$SELECT iply_seq 
	   INTO $iply_seq
	   FROM ca_ply_ext
	  WHERE ipolicy = $ipolicy;
	
	printf("update dpolicy => iply_seq = [%d]",iply_seq);
		$UPDATE ca_ply_ext
		    SET dpolicy = $dpolicy
		  WHERE ipolicy = $ipolicy
		    AND dpolicy IS NULL;

   	if (iply_seq == 0) {
        	$UPDATE ca_ply_ext
        	    SET iply_seq = 1
        	  WHERE ipolicy = $ipolicy;
	}

    	rtncode=car213_print_policy(reply,command,com_len);
   
    
    	return(rtncode);
    
errexit:
   	if (exitsub(reply,SQLCODE) == True)
      		return SQLCODE;
   	else
      		return apiRC;
}