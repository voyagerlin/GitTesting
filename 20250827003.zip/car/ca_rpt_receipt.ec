/* ****************************************************************************
 * Program ID: ca_rpt_receipt.ec
 *
 * Description:
 *   ���C�L, �p�G�ק怜�ڲĤT�p�����O�a�},�q��,�g���H(��Ƨ���),
 *   �{�� Block endorse_item �]�n�ק�
 *
 * Author:   Tony96, S.Y.HWANG.870609
 *
 * ****************************************************************************/
#include <malloc.h>

#include <api_xsrv.h>
#include "comdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "globdata.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "gls_array.h"
#include "gls_const.h"
#include "print.h"

$include datetime.h;
$include decimal.h;

/* *** Global variables *** */
$static char g_sIendorse[ENDORSE_NUM], g_sFedr_class[2], g_sIedr_field[9];
$static long g_lMprem_total, g_lMedrdmg_prem, g_lMedrlia_prem;
$static char g_sNassured[124], g_sNuser[19], g_sNbenef[43], *g_pData[128];
$static char *g_pEedr_item[128], g_sDendorse[11], g_sOutFile[21];
$static char g_sFile[33];
$static int  g_iMax_count, g_iPgLine;
$int  ibatch_no;
$char batch_no[3];

/* *** Message block *** */
#define _M860718
/* ********************* */

char *pwformat();
#define BASE_LINE       8       /* ���ʽ�Ĥ@�� */
#define EDR_BASE_LINE   18      /* ���Ĥ@��     */
#define MAX_EDR_ROW     9       /* ���ʽ���   */
#define MAX_ROW         34
#define MAX_COLUMN      20      /* �̪�����     */

/* *** Function prototype *** */
long ca_rpt_endorse();
long ca401_data1();
long ca401_data2();
long ca401_data3();
long drop_temp_table();
long insert_tmp_table();
long data_report();
long car401_body_receipt();


/************************************************************************/
long ca_rpt_endorse (p_sIendorse, p_lMprem_total)
char *p_sIendorse;
long *p_lMprem_total;
{
  int   iRtnCode;
  $char sTmt[1024], sTmpBuf[512];

  $WHENEVER SQLERROR GOTO errexit;

  printf("--------------------- g_sFile[%s]\n", g_sFile);
  sprintf(g_sFile,"%d",rand(0) % 100000 );
  printf("--------------------- g_sFile[%s]\n", g_sFile);
  sprintf(sTmt,
    "CREATE TEMP TABLE tmp%s \
        (rpt_pg int, rpt_row int, rpt_col int, str char(510)) \
     WITH NO LOG", g_sFile);
  printf("--------------------- stmt[%s]\n", sTmt);
  $PREPARE c_temp FROM $sTmt;
  $EXECUTE c_temp;
  sprintf(sTmt,"CREATE UNIQUE INDEX tmpx%s ON tmp%s(rpt_pg,rpt_row,rpt_col)",
               g_sFile,g_sFile);
  printf("--------------------- stmt[%s]\n", sTmt);
  $PREPARE create_i FROM $sTmt;
  $EXECUTE create_i;


# ifdef _M860718
printf("{ca_rpt_endorse.0010}: call ca401_data1[%s]\n", p_sIendorse);
# endif

  /* �C�L�O���򥻸�� */
  if((iRtnCode=ca401_data1(p_sIendorse)) != M_CM_OK)
  {
# ifdef _M860718
printf("{ca_rpt_endorse.0010}: rtncode[%d]", iRtnCode);
# endif
      drop_temp_table();
      return iRtnCode;
  }

# ifdef _M860718
printf("{ca_rpt_endorse.0020}: call ca401_data2[%s]\n", p_sIendorse);
# endif

  /* �C�L�I�ة��Ӹ�� */
  if((iRtnCode=ca401_data2(p_sIendorse)) != M_CM_OK)
  {
# ifdef _M860718
printf("{ca_rpt_endorse.0020}: rtncode[%d]", iRtnCode);
# endif
      drop_temp_table();
      return iRtnCode;
  }


# ifdef _M860718
printf("{ca_rpt_endorse.0030}: call ca401_data3[%s]\n", p_sIendorse);
# endif

  /* �C�L��Ѹ�� */
  if((iRtnCode=ca401_data3(p_sIendorse)) != M_CM_OK){

# ifdef _M860718
printf("{ca_rpt_endorse.0030}: rtncode[%d]", iRtnCode);
# endif
   
      drop_temp_table();
      return iRtnCode;
  }


  *p_lMprem_total = g_lMprem_total;


  return M_CM_OK;

errexit:
  printf("{ca_rpt_endorse}: SQLCODE=[%d] sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
  return SQLCODE;
} /* ca_rpt_endorse */


/* ************************************************************************
 * Function: ca401_data1
 *
 * Description:
 *   �C�L�O���򥻸��.
 *
 * ************************************************************************/
long ca401_data1 (p_sIendorse)
$char *p_sIendorse;
{
  /* ------------------------ edr_relation ----------------------------- */
  $char sIpolicy[POLICY_NUM_1], sIcard[CARD_NUM], sIrelative_ply[POLICY_NUM_1];
  $char sFedr_class[2];
  $char sFpay[2], sIpay[20], sIedr_field[9], sIofficer[16];
  $char sIedr_cashier[14], sIbroker[BROKER], sDendorse[11];
  $char sDedr_begin[11], sDedr_end[11];
  $long lMedrdmg_prem, lMedrlia_prem;
  $char sFcard_class[2], sIbranch[4];
  /* --------------------------------------------------------------------- */

  /* ------------------------ edr_relation ----------------------------- */
  $char sDvp_code[3], sDvp_abbr[11];
  $char sNbranch[41], sNpresident[41], sNtitle[21];
  /* --------------------------------------------------------------------- */

  /* -------------------------- policy_bak ------------------------------- */
  $char   sNassured[ASSURED_NAME], sNbenef[43], sAassured[92], sIlicense[11];
  $char   sIbirth[11];
  $char   sFsex[2], sFmarriage[2], sItel[12], sIissue_ym[7], sIpro_year[5];
  $char   sIcar_type[3];
  $long   lQcylinder;
  $char   sIengine[21], sIbody[21], sItag[9], sIbrand[9];
  $double dblPdmg_align, dblPbrg_align, dblPlia_align, dblQpt;
  $char   sFpt[2];
  $double dblPsex_age, dblPlia_acc, dblPdmg_acc;
  $char   sNbrand_abbr[20], sNcar_abbr[20];
  /* --------------------------------------------------------------------- */

  /* -------------------------- endorsement ------------------------------- */
  $char sNuser[19];
  /* ---------------------------------------------------------------------- */

  $char   sYEdrBgn[4], sMEdrBgn[3], sDEdrBgn[3];
  $char   sYEdrEnd[4], sMEdrEnd[3], sDEdrEnd[3];
   char   birthyy[4], birthmm[3], birthdd[3];
  $char   sIissue_year[4], sIissue_month[3];
  $char   sTmpBuf[254], sTmpBuf1[80], sTaxName[11], sTaxArea[11];

  /* 861226-mag */
  int     iPg;

  $WHENEVER SQLERROR GOTO errexit;

printf("$$$$$$$$$$$$ into ca401_data1()\n");

  iPg = 1;


  $SELECT ipolicy, icard, irelative_ply, fedr_class, fpay, ipay, 
          iedr_field, dedr_begin, dedr_end, iofficer, iedr_cashier, 
          ibroker, dendorse, medrdmg_prem, medrlia_prem, fcard_class
     INTO $sIpolicy, $sIcard, $sIrelative_ply, $sFedr_class, $sFpay, $sIpay,
          $sIedr_field, $sDedr_begin, $sDedr_end, $sIofficer, $sIedr_cashier,
          $sIbroker, $sDendorse, $lMedrdmg_prem, $lMedrlia_prem,$sFcard_class
     FROM edr_relation
    WHERE iendorse = $p_sIendorse;
  if(SQLCODE == SQLNOTFOUND)
    return M_CA_NREL_EDR;

  $SELECT dply_begin, dply_end 
     INTO $sDedr_begin, $sDedr_end
     FROM ply_relation_bak
    WHERE iendorse = $p_sIendorse;
  if(SQLCODE == SQLNOTFOUND)
    return M_CA_NREL_EDR;


# ifdef _M860718
printf("{ca401_data1.0010}:policy[%s],icard[%s],relative_ply[%s],pay[%s],officer[%s],edr_cashier[%s],broker[%s]\n", sIpolicy, sIcard, sIrelative_ply, sIpay, sIofficer, sIedr_cashier, sIbroker);
# endif


  strcpy(sIpolicy,       rtrim(sIpolicy));
  strcpy(sIcard,         rtrim(sIcard));
  strcpy(sIrelative_ply, rtrim(sIrelative_ply));
  strcpy(sIpay,          rtrim(sIpay));
  strcpy(sIofficer,      rtrim(sIofficer));
  strcpy(sIedr_cashier,  rtrim(sIedr_cashier));
  strcpy(sIbroker,       rtrim(sIbroker));


# ifdef _M860718
printf("{ca401_data1.0020}: medrdmg_prem[%d],medrlia_prem[%d]\n", lMedrdmg_prem, lMedrlia_prem);
# endif


  g_lMedrdmg_prem = lMedrdmg_prem;
  g_lMedrlia_prem = lMedrlia_prem;


# ifdef _M860718
printf("{ca401_data1.0030}: dendorse[%s],fedr_class[%s]\n", sDendorse, sFedr_class);
# endif


  strcpy(g_sDendorse,   sDendorse);
  strcpy(g_sFedr_class, sFedr_class);
  strcpy(g_sIedr_field, sIedr_field);
  g_lMprem_total = lMedrdmg_prem + lMedrlia_prem;

  strncpy(sIbranch, sIpolicy, 3); sIbranch[3] = '\0';
  /* *** �O��e�T�X(���) *** */
  sprintf(sTmpBuf, "17%s", sIbranch);
  insert_tmp_table(iPg, 1, 9, sTmpBuf);       /* peter 12.10 */

  /* *** �O��(�~��,�r�y,�Ǹ�) *** */
  if(strlen(sIpolicy) >= CAR_POLICY_LEN){
    strncpy(sTmpBuf,  sIpolicy, CAR_POLICY_LEN); sTmpBuf[CAR_POLICY_LEN] = '\0';
     strcpy(sTmpBuf1, sIpolicy+CAR_POLICY_LEN);
  }else{
    strcpy(sTmpBuf, sIpolicy); sTmpBuf[CAR_POLICY_LEN] = '\0';
    strcpy(sTmpBuf1, "");
  }
  insert_tmp_table(iPg, 1, 10, sTmpBuf+3);       /* peter 12.10 */

  /* *** ���e��X(���), �P�O����ۦP *** */
  sprintf(sTmpBuf, "17%s", sIbranch);
  insert_tmp_table(iPg, 1, 11, sTmpBuf);         /* peter 12.10 */

  /* *** ���(�~��,�r�y,�Ǹ�) *** */
  insert_tmp_table(iPg, 1, 12, p_sIendorse+3);   /*peter 12.10*/
/*
  insert_tmp_table(iPg, 1, 17, p_sIendorse);
  insert_tmp_table(iPg, 17, 9, p_sIendorse);
*/
  /* *** ���ͮĩl��(�~,��,��) *** */
  cm_split_ymd(cm_from_infdate(sDedr_begin), sYEdrBgn, sMEdrBgn, sDEdrBgn);
  insert_tmp_table(iPg, 3, 1, sYEdrBgn);
  insert_tmp_table(iPg, 3, 2, sMEdrBgn);
  insert_tmp_table(iPg, 3, 3, sDEdrBgn);

  /* *** ���ͮĲ״�(�~,��,��) *** */
  cm_split_ymd(cm_from_infdate(sDedr_end), sYEdrEnd, sMEdrEnd, sDEdrEnd);
  insert_tmp_table(iPg, 3, 4, sYEdrEnd);
  insert_tmp_table(iPg, 3, 5, sMEdrEnd);
  insert_tmp_table(iPg, 3, 6, sDEdrEnd);
  insert_tmp_table(iPg, 3, 7, sIofficer);
  insert_tmp_table(iPg, 34, 5, sIofficer);   /*** �C�L�ӿ�H ***/

  /* *** ??? nassured, nbenef selected by policy_bak *** */
  $SELECT  nassured,   nuser,   nbenef
     INTO $sNassured, $sNuser, $sNbenef
     FROM endorsement
    WHERE iendorse = $p_sIendorse;

  if(SQLCODE == SQLNOTFOUND)
    return M_CA_NENDORSE;


# ifdef _M860718
printf("{ca401_data1.0040}: sNassured[%s],sNuser[%s],sNbenef[%s]\n", sNassured, sNuser, sNbenef);
# endif


  strcpy(g_sNassured, rtrim(sNassured));
  strcpy(g_sNuser,    rtrim(sNuser));
  strcpy(g_sNbenef,   rtrim(sNbenef));


          /* $sIissue_ym, $sIpro_year, $sIcar_type */

printf("{ca401_data1.0041}:before select policy_bak\n");
  $SELECT nassured, nbenef, aassured, ilicense, ibirth, fsex, 
          fmarriage, itel, qcylinder, iengine, ibody, 
          itag, pdmg_align, pbrg_align, plia_align, 
          qpt, fpt, psex_age, plia_acc, pdmg_acc,
          nbrand_abbr,ncar_abbr
     INTO $sNassured, $sNbenef, $sAassured, $sIlicense, $sIbirth, $sFsex, 
          $sFmarriage, $sItel, $lQcylinder, $sIengine, $sIbody, 
          $sItag, $dblPdmg_align, $dblPbrg_align, $dblPlia_align, 
          $dblQpt,$sFpt,$dblPsex_age, $dblPlia_acc, $dblPdmg_acc, 
          $sNbrand_abbr, $sNcar_abbr
     FROM policy_bak
    WHERE iendorse = $p_sIendorse;
  if(SQLCODE == SQLNOTFOUND) {
printf("{ca401_data1.0041}:select policy_bak not found!!\n"); 
printf("{ca401_data1.0041}:select original_ply !!\n"); 
  $SELECT nassured, nbenef, aassured, ilicense, ibirth, fsex,

          fmarriage, itel, qcylinder, iengine, ibody, 
          itag, pdmg_align, pbrg_align, plia_align, 
          qpt, fpt, psex_age, plia_acc, pdmg_acc,
          nbrand_abbr
     INTO $sNassured, $sNbenef, $sAassured, $sIlicense, $sIbirth, $sFsex,
          $sFmarriage, $sItel, $lQcylinder, $sIengine, $sIbody,
          $sItag, $dblPdmg_align, $dblPbrg_align, $dblPlia_align,
          $dblQpt, $sFpt, $dblPsex_age, $dblPlia_acc, $dblPdmg_acc, 
          $sNbrand_abbr
     FROM original_ply
  WHERE ipolicy=(SELECT ipolicy FROM edr_relation WHERE iendorse=$p_sIendorse);
  if (SQLCODE == SQLNOTFOUND)
    return M_CA_NENDORSE;
  }


printf("{ca401_data1.0041}:before select ply_relation_bak\n"); 
  $SELECT iissue_ym, ipro_year, ibrand, icar_type 
     INTO $sIissue_ym, $sIpro_year, $sIbrand, $sIcar_type
     FROM ply_relation_bak
    WHERE iendorse = $p_sIendorse;
  if(SQLCODE == SQLNOTFOUND) {
printf("{ca401_data1.0041}:select ply_relation_bak not found!!\n"); 
printf("{ca401_data1.0041}:select ori_ply_relation !!\n");
  $SELECT iissue_ym, ipro_year, ibrand, icar_type 
     INTO $sIissue_ym, $sIpro_year, $sIbrand , $sIcar_type
     FROM ori_ply_relation
  WHERE ipolicy=(SELECT ipolicy FROM edr_relation WHERE iendorse=$p_sIendorse);
  if (SQLCODE == SQLNOTFOUND)
    return M_CA_NENDORSE;
  }

 /* *** ���ئW�� *** */
  $SELECT  ncode
      INTO  $sNcar_abbr
      FROM car_type
      WHERE icode = $sIcar_type AND fclass = '1';
  if(SQLCODE == SQLNOTFOUND)  strcpy( sNcar_abbr, " ");

# ifdef _M860718
printf("{ca401_data1.0050}: nassured[%s],nbenef[%s],assured[%s],licendse[%s],birth[%s],tel[%s],issue_ym[%s],pro_year[%s],car_type[%s],iengine[%s]\n", sNassured, sNbenef, sAassured,sIlicense, sIbirth, sItel, sIissue_ym, sIpro_year, sIcar_type, sIengine);
printf("{ca401_data1.0050}: ibody[%s],itag[%s],ibrand[%s],nbrand_abbr[%s],ncar_abbr[%s]\n", sIbody, sItag, sIbrand, sNbrand_abbr, sNcar_abbr);
# endif


  strcpy(sNassured,    rtrim(sNassured));
  strcpy(sNbenef,      rtrim(sNbenef));
  strcpy(sAassured,    rtrim(sAassured));
  strcpy(sIlicense,    rtrim(sIlicense));
  strcpy(sIbirth,      rtrim(sIbirth));
  strcpy(sItel,        rtrim(sItel));
  strcpy(sIissue_ym,   rtrim(sIissue_ym));
  strcpy(sIpro_year,   rtrim(sIpro_year));
  strcpy(sIcar_type,   rtrim(sIcar_type));
  strcpy(sIengine,     rtrim(sIengine));
  strcpy(sIbody,       rtrim(sIbody)); 
  strcpy(sItag,        rtrim(sItag));
  strcpy(sIbrand,      rtrim(sIbrand));
  strcpy(sNbrand_abbr, rtrim(sNbrand_abbr));
  strcpy(sNcar_abbr,   rtrim(sNcar_abbr));

  /* *** �ʧO�~�֫Y�� *** */
  sprintf(sTmpBuf, "%6.2f", dblPsex_age);
  insert_tmp_table(iPg, 7, 1, sTmpBuf);

  /* *** �ߴڬ����Y��(�d��) *** */
  sprintf(sTmpBuf, "%6.2f", dblPlia_acc);
  insert_tmp_table(iPg, 7, 3, sTmpBuf);               /* peter 12.10 */

  /* *** �ߴڬ����Y��(����) *** */
  sprintf(sTmpBuf, "%6.2f", dblPdmg_acc);
  insert_tmp_table(iPg, 7, 2, sTmpBuf);                /* peter 12.10 */

  /* *** �h�����u��(����) *** */
  sprintf(sTmpBuf, "%4.1f", dblPdmg_align);
  strcat(sTmpBuf," %");
  insert_tmp_table(iPg, 7, 4, sTmpBuf);

  /* *** �h�����u��(�ѵs) *** */
  sprintf(sTmpBuf, "%4.1f", dblPlia_align);
  strcat(sTmpBuf," %");
  insert_tmp_table(iPg, 7, 5, sTmpBuf);

  /* *** �h�����u��(�d��) *** */
  sprintf(sTmpBuf, "%4.1f", dblPbrg_align);
  strcat(sTmpBuf," %");
  insert_tmp_table(iPg, 7, 6, sTmpBuf);

  strncpy(sIissue_year, sIissue_ym, 2); sIissue_year[2] = '\0';
  strncpy(sIissue_month, sIissue_ym+3, 2); sIissue_month[2] = '\0';

  /* *** �o�Ӧ~�� *** */
  insert_tmp_table(iPg, 5, 1, sIissue_year);

  /* *** �o�Ӥ�� *** */
  insert_tmp_table(iPg, 5, 2, sIissue_month);

  /* *** �t�P�����W�� *** */
  insert_tmp_table(iPg, 4, 2, sNbrand_abbr);

  if(strlen(sNcar_abbr) > 8){
    strncpy(sTmpBuf, sNcar_abbr, 8); sTmpBuf[8] = '\0';
  }else
    strcpy(sTmpBuf, sNcar_abbr);
  insert_tmp_table(iPg, 4, 3, sTmpBuf);

  /* *** �p�G�������X > 14 �X, �L��� *** */
  if(strlen(sIengine) > 14){
    insert_tmp_table(iPg, 5, 5, sIengine+14);
  }

  /* *** ���ȸ��������� *** */
  insert_tmp_table(iPg, 5, 6, (*sFpt=='P') ? "�H" : "��");

  /* *** �Q�O�I�H�����Ҹ� *** */
  insert_tmp_table(iPg, 6, 1, sIlicense);

    /* *** �X�ͦ~��� *** */
  cm_split_ymd(sIbirth,birthyy,birthmm,birthdd);
  insert_tmp_table(iPg, 6, 2, birthyy);
  insert_tmp_table(iPg, 6, 3, birthmm);
  insert_tmp_table(iPg, 6, 4, birthdd);


  /* *** �ʧO *** */
  if  (*sFsex == '1')
     insert_tmp_table(iPg, 6, 5, "�k");
  else if (*sFsex == '2')
     insert_tmp_table(iPg, 6, 5, "�k");
  else
     insert_tmp_table(iPg, 6, 5, "  ");


  /* *** �B�� *** */
  if  (*sFmarriage == '1')
     insert_tmp_table(iPg, 6, 6, "�w�B");
  else if (*sFmarriage == '2')
     insert_tmp_table(iPg, 6, 6, "���B");
  else
     insert_tmp_table(iPg, 6, 6, "  ");

  /* *** �Q�O�I�H�W�� *** */
  if(strlen(sNassured) <= 70)
  {
      if(*sFsex == '1')
      {
          strcat(sNassured," ����");
          insert_tmp_table(iPg, 2 ,1 ,sNassured);
      }
      else if(*sFsex == '2')
      {
          strcat(sNassured," �p�j");
          insert_tmp_table(iPg, 2 ,1 ,sNassured);
      }
      else
      {
          insert_tmp_table(iPg, 2, 1, sNassured);
      }
  }
  else { /* *** temporary block add by tony96.861210 *** */
    int  i;
    char buf[80];

    i = cc_split_chinese(sNassured, buf, 70);
    insert_tmp_table(iPg, 2, 1, buf);
 /* cc_split_chinese(sNassured+i, buf, 70);
    insert_tmp_table(iPg, 2, 2, buf); */
  }
  /****�� �}**********/
  insert_tmp_table(iPg, 2, 2, sAassured);

  /* *** �s�y�~�� *** */
  insert_tmp_table(iPg, 4, 1, sIpro_year);

  /* *** �t�P�����N�� *** */
  insert_tmp_table(iPg, 5, 3, sIbrand);

  /* *** ���إN�� *** */

  insert_tmp_table(iPg, 5, 4, sIcar_type);

  /* *** �Ʈ�q *** */
  sprintf(sTmpBuf, "%d", lQcylinder);
  insert_tmp_table(iPg, 4, 4, sTmpBuf);

  /* *** �������X *** */
  if(strlen(sIengine) > 14){
    strncpy(sTmpBuf, sIengine, 14); sTmpBuf[14] = '\0';
  }else
    strcpy(sTmpBuf, sIengine);
  insert_tmp_table(iPg, 4, 5, sTmpBuf);

  /* *** �P�Ӹ� *** */
  insert_tmp_table(iPg, 4, 6, sItag);
  if(sItag[0]!='\0' && sItag[0]!=' ') {                /* peter 12.10 */
    sprintf(sTmpBuf,"�P�Ӹ�:%s",sItag);
    sTmpBuf[25]='\0';
  }else if(sIengine[0]!='\0' && sIengine[0]!=' ') {
    sprintf(sTmpBuf,"������:%s",sIengine);
    sTmpBuf[25]='\0';
  }else sTmpBuf[0]='\0';
  insert_tmp_table(iPg, 7, 9, sTmpBuf);

  /* *** ���ȸ������� *** */
  sprintf(sTmpBuf, "%.1f", dblQpt);
  insert_tmp_table(iPg, 4, 7, sTmpBuf);

  $SELECT dvp_code, dvp_abbr,nbranch,npresident,ntitle,tax_name,tax_area
     INTO $sDvp_code, $sDvp_abbr,$sNbranch,$sNpresident,$sNtitle,
          $sTaxName,$sTaxArea
     FROM ca_area_code
    WHERE sk_code = $sIbranch;
  if(SQLCODE == SQLNOTFOUND){
    strcpy(sDvp_code,   "");
    strcpy(sDvp_abbr,   "");
    strcpy(sNbranch,    "");
    strcpy(sNpresident, "");
    strcpy(sNtitle,     "");
    strcpy(sTaxName,    "");
    strcpy(sTaxArea,    "");
  }
  strcpy(sDvp_code,   rtrim(sDvp_code));
  strcpy(sDvp_abbr,   rtrim(sDvp_abbr));
  strcpy(sNbranch,    rtrim(sNbranch));
  strcpy(sNpresident, rtrim(sNpresident));
  strcpy(sNtitle,     rtrim(sNtitle));
  strcpy(sTaxName,    rtrim(sTaxName));
  strcpy(sTaxArea,    rtrim(sTaxArea));


  /* *** �ӫO�a�ϥN�X *** */
  insert_tmp_table(iPg, 1, 13, sDvp_code);       /* peter 12.10 */

  /* *** �ӫO�a��²�� *** */
  if (p_sIendorse[2] == '0')
     insert_tmp_table(iPg, 34, 4, "�x�_");
  else if (p_sIendorse[2] == '1')
     insert_tmp_table(iPg, 34, 4, "�x��");
  else if (p_sIendorse[2] == '2')
     insert_tmp_table(iPg, 34, 4, "����");

  /* *** �����W�� *** */
  insert_tmp_table(iPg, 32, 3, sNbranch);        /* peter 12.10 */

  /* *** �a�ϥD��¾�� *** */
  insert_tmp_table(iPg, 32, 4, sNtitle);         /* peter 12.10 */

  /* *** �a�ϥD�ަW�r *** */
  sprintf(sTmpBuf, "%c%c%s%c%c", 27, 24, sNpresident, 27, 12);
  insert_tmp_table(iPg, 32, 5, sTmpBuf);         /* peter 12.10 */

  return M_CM_OK;

errexit:
  printf("{ca401_data1}: SQLCODE = %d sqlerrm=%s\n", SQLCODE, sqlca.sqlerrm);
  return SQLCODE;
} /* ca401_data1 */


/* ************************************************************************
 * Function: ca401_data2
 *
 * Description:
 *   �C�L�I�ة��Ӹ��.
 *
 * ************************************************************************/
long ca401_data2 (p_sIendorse)
$char *p_sIendorse;
{
  $int   iMedrdmg_cover, iMedrinj_cover, iMedrdea_cover, iMdeduct;
  $int   iPcal, iQserial, iMedrins_prem;

  /* 861224-mag */
  $int   iMedr_prem;
  $char  sIcar_type[3],sDeduct[13],tmpDeduct[9],tmp1Deduct[9];
  $long  tot_Medr_prem;
  $int   ins_cnt;
  int    iPg_init, iPg;

  $char  sIins_type[INSURANCE_TYPE], sIedr_type[3], sFcal_way[2], sDrate_ym[5];
  $char  sFprint[2], sFins_grp[2], sNins_type[19];
  $int   iQcoverage, iLineCount;
  $char  sTmpBuf[512];

printf("$$$$$$$$$$$$ into ca401_data2()\n");

  $WHENEVER SQLERROR GOTO errexit;

  iPg_init = 1; /* 861224-mag, keep initial value */
  iPg = 1;
  iLineCount = 0;
  tot_Medr_prem = 0;  /* 861224-mag */

  $DECLARE x3 CURSOR FOR
    SELECT iins_type, iedr_type, medrdmg_cover, medrinj_cover, 
           medrdea_cover, mdeduct, medrins_prem, fcal_way, pcal, 
           qserial, drate_ym,
           medr_prem, icar_type  /* 861224-mag */
      INTO $sIins_type, $sIedr_type, $iMedrdmg_cover, $iMedrinj_cover,
           $iMedrdea_cover, $iMdeduct, $iMedrins_prem, $sFcal_way, 
           $iPcal, $iQserial, $sDrate_ym,
           $iMedr_prem, $sIcar_type
      FROM edr_ins_type a, edr_relation b
     WHERE a.iendorse = $p_sIendorse
       AND a.iendorse=b.iendorse
  ORDER BY qserial;
  $OPEN x3;
  while(1){
    $FETCH x3;
    if(SQLCODE == SQLNOTFOUND) break;

    strcpy(sIins_type, trim(sIins_type));

    $SELECT  nins_type,   qcoverage,   fprint,   fins_grp
       INTO $sNins_type, $iQcoverage, $sFprint, $sFins_grp
       FROM insurance_type
      WHERE iins_type = $sIins_type;
      

printf("############ data2() iLineCount[%d] MAX_EDR_ROW[%d]\n",iLineCount,MAX_EDR_ROW);

    if(iLineCount == MAX_EDR_ROW){
       iLineCount = 0;
       iPg++;
       printf("-----------------------> data2() iPg[%d]\n",iPg);
    }


    /* *** ���ʽ� *** */
    insert_tmp_table(iPg, BASE_LINE+iLineCount, 1, sIedr_type);

    /* *** �O�I�����N�� *** */
    insert_tmp_table(iPg, BASE_LINE+iLineCount, 2, sIins_type); 

    /* *** �O�I�����W�� *** */
    if(iQcoverage == 3){
      sprintf(sTmpBuf, "%s%s", sNins_type, "  ���");
      insert_tmp_table(iPg, BASE_LINE+iLineCount, 3, sNins_type); 
      insert_tmp_table(iPg, BASE_LINE+iLineCount, 10, "        ���`"); 
      insert_tmp_table(iPg, BASE_LINE+iLineCount+1, 3, "        �`�B");
    } else if(iQcoverage == 2){
      sprintf(sTmpBuf, "%s%s", sNins_type, "  ���");
      insert_tmp_table(iPg, BASE_LINE+iLineCount, 3, sNins_type); 
      insert_tmp_table(iPg, BASE_LINE+iLineCount, 10, "        �`�B");
    } else if(strcmp(sIins_type,"88")==0){
      insert_tmp_table(iPg, BASE_LINE+iLineCount, 3, "�Ҧ������I");
      insert_tmp_table(iPg, BASE_LINE+iLineCount, 10, "���[�w�v�ۭt�B");
    } else{ 
      insert_tmp_table(iPg, BASE_LINE+iLineCount, 3, sNins_type); 
   }

    /* *** �O�B��[/����O *** */
    if(iMedrins_prem > 0) strcpy(sTmpBuf, "+");
    else if(iMedrins_prem == 0) strcpy(sTmpBuf, " ");
    else strcpy(sTmpBuf, "-");

    if(iQcoverage == 3){
      insert_tmp_table(iPg, BASE_LINE+iLineCount, 4, sTmpBuf);
      insert_tmp_table(iPg, BASE_LINE+iLineCount, 11, sTmpBuf);
      insert_tmp_table(iPg, BASE_LINE+iLineCount+1, 4, sTmpBuf);
    }else if(iQcoverage == 2){
      insert_tmp_table(iPg, BASE_LINE+iLineCount, 4, sTmpBuf);
      insert_tmp_table(iPg, BASE_LINE+iLineCount, 11, sTmpBuf);
    }else
      insert_tmp_table(iPg, BASE_LINE+iLineCount, 4, sTmpBuf);

    /* *** �O�I���B *** */
    if(iQcoverage == 3){ /* ���,���`,�`�B */
      iMedrinj_cover = labs(iMedrinj_cover);
      rfmtlong(iMedrinj_cover, "-,---,---,--&", sTmpBuf);
      insert_tmp_table(iPg, BASE_LINE+iLineCount, 5, sTmpBuf); 
      iMedrdea_cover = labs(iMedrdea_cover);
      rfmtlong(iMedrdea_cover, "-,---,---,--&", sTmpBuf);
      insert_tmp_table(iPg, BASE_LINE+iLineCount, 12, sTmpBuf); 
      iMedrdmg_cover = labs(iMedrdmg_cover);
      rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
      insert_tmp_table(iPg, BASE_LINE+iLineCount+1, 5, sTmpBuf); 
    } else if(iQcoverage == 2){ /* ���,�`�B */
      iMedrinj_cover = labs(iMedrinj_cover);
      rfmtlong(iMedrinj_cover, "-,---,---,--&", sTmpBuf);
      insert_tmp_table(iPg, BASE_LINE+iLineCount, 5, sTmpBuf); 
      iMedrdmg_cover = labs(iMedrdmg_cover);
      rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
      insert_tmp_table(iPg, BASE_LINE+iLineCount, 12, sTmpBuf); 
    } else if(iQcoverage == 1){ /* �`�B */
      iMedrdmg_cover = labs(iMedrdmg_cover);
      rfmtlong(iMedrdmg_cover, "-,---,---,--&", sTmpBuf);
      insert_tmp_table(iPg, BASE_LINE+iLineCount, 5, sTmpBuf); 
    }

    /* *** �ۭt�B *** */
printf("{ca401_data2.0010}:iMdeduct[%d]\n",iMdeduct);
    if (iMdeduct != 0)
    {
        if (strcmp(sIins_type, "01")==0 || strcmp(sIins_type, "05")==0) 
        {
            if (iMdeduct<0) 
            {
               memset(tmpDeduct,0,sizeof(tmpDeduct));
               iMdeduct=labs(iMdeduct);
               sprintf(tmpDeduct,"%d",iMdeduct);
               $SELECT prn_deduct INTO $tmpDeduct
                  FROM ca_dmg_mdeduct
                 WHERE icar_type=$sIcar_type
                   AND ideduct=$tmpDeduct;
               strcpy(sDeduct,"-");
               strcat(sDeduct,tmpDeduct);
            }
            else 
            {
               $SELECT prn_deduct INTO $sDeduct
                  FROM ca_dmg_mdeduct
                 WHERE icar_type=$sIcar_type
                   AND ideduct=$iMdeduct;  
            }
        } else {
            rfmtlong(iMdeduct, "--,---,--&", sDeduct);
        }

printf("{ca401_data2.0030}:sIcar_type[%s],iMdeduct[%d],tmpDeduct[%s],sDeduct[%s]\n",sIcar_type,iMdeduct,tmpDeduct,sDeduct);

        insert_tmp_table(iPg, BASE_LINE+iLineCount, 6, sDeduct);
    }

    /* *** �O�O��[/����O *** */
    if(iMedrins_prem > 0) strcpy(sTmpBuf, "+");
    else if(iMedrins_prem == 0) strcpy(sTmpBuf, " ");
    else strcpy(sTmpBuf, "-");

    insert_tmp_table(iPg, BASE_LINE+iLineCount, 7, sTmpBuf);

    /* *** �O�O *** */
    iMedrins_prem = labs(iMedrins_prem);
    rfmtlong(iMedrins_prem, "--,---,--&", sTmpBuf);
    insert_tmp_table(iPg, BASE_LINE+iLineCount, 8, sTmpBuf); 

    if(iQcoverage > 2) iQcoverage = 2;
    else iQcoverage = 1;

    iLineCount += iQcoverage;

    /* 861224-mag �u�ݫe�O�O�[�`*/
    tot_Medr_prem += iMedr_prem;
  }
  $CLOSE x3; $FREE x3;

  if(g_lMprem_total > 0) strcpy(sTmpBuf, "+");
  else if(g_lMprem_total < 0) strcpy(sTmpBuf, "-");
  else strcpy(sTmpBuf, " ");
  insert_tmp_table(iPg_init, 17, 1, sTmpBuf);

  /* *** �h�����u�ݫ��`�O�O *** */
  /* 861226-mag, �C�i��檺�Ĥ@���~�ݦC�L */
  g_lMprem_total = labs(g_lMprem_total);
  rfmtlong(g_lMprem_total, "---,---,--&", sTmpBuf);
  insert_tmp_table(iPg_init, 17, 2, sTmpBuf);

  /* *** �h�����u�ݫe�`�O�O *** */
  /* 861226-mag, �C�i��檺�Ĥ@���~�ݦC�L */
  $SELECT SUM(medr_prem)  /* 861224-mag */
      INTO $tot_Medr_prem
      FROM edr_ins_type
     WHERE iendorse = $p_sIendorse;
  rfmtlong(tot_Medr_prem, "---,---,--&", sTmpBuf);
  insert_tmp_table(iPg_init, 17, 3, sTmpBuf);

  return M_CM_OK;

errexit:
  printf("{ca401_data2}: SQLCODE=[%d] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
  return SQLCODE;
} /* ca401_data2 */


/**************************************************************************
 * Function: ca401_data3
 *
 * Description:
 *   �C�L��Ѹ��.
 *
 **************************************************************************/
long ca401_data3 (p_sIendorse)
$char *p_sIendorse;
{
  /* *** �����ܧ󪺰򥻸��, ���I�ة��� *** */
  $struct _icode {
      char icode[3];                    /* endorsement_code.icode */
      char iins_type[INSURANCE_TYPE];   /* ins_type */
      char fins_grp[2];                 /* fins_grp */
       int fclass;                      /* 1: �I�ا��, 2: �򥻸�Ƨ�� */
  } recEdrChg[60];

  int   idx=0, i, j, iDeflag;
  char  *psFieldStatus; /* �C�@�ܰʸ�Ƭ����b g_sIedr_field's bit */
  $int  iQserial, iQcoverage;
  $char sIedr_type[3], sIins_type[INSURANCE_TYPE], sFins_grp[2], sFclass[2];
  short flag_02, flag_03, flag_05;
  $char sIedr_item[3];
  $long lQserial;
  $char sEedr_item[69], sNtable[31], sNcolumn[31], sFdatatype[2];
  $char sTmt[1024], sTmpBuf[512];
  $char sTmpDate[11], sYY[3], sMM[3], sDD[3];
  $char sTmpData[512], sFcal_way[2], sTmpBuf1[512], sTmpBuf2[512];
  $int  iTmp, iLine;
  $long lMedrinj_cover, lMedrdea_cover, lMedrdmg_cover, lMdeduct, lMedrins_prem;
  $long lMinjured_cover, lMdeath_cover, lMdamage_cover, lMins_premium;
  $long lTot_prem, lEdrItemCount;

  int   iPg_init, iPg;  /* 861226-mag */

  $WHENEVER SQLERROR GOTO errexit;

printf("$$$$$$$$$$$$ into ca401_data3()\n");

  iPg_init = 1; /* 861226-mag, keep initial value */
  iPg = 1;     
  lEdrItemCount = 0;    /* ��鷺�e���Ӽ� */

  switch(*g_sFedr_class){
    case '1':   /* ���P */
      strcpy(recEdrChg[idx].icode, "01");
      recEdrChg[idx].fclass = 1; idx++;
      break;
    case '2':   /* �L�� */
      strcpy(recEdrChg[idx].icode, "30");
      recEdrChg[idx].fclass = 1; idx++;
      break;
    case '3':   /* ��g��H */
      strcpy(recEdrChg[idx].icode, "80");
      recEdrChg[idx].fclass = 1; idx++;
      break;
    case '4':   /* �h���h�O */
      strcpy(recEdrChg[idx].icode, "60");
      recEdrChg[idx].fclass = 1; idx++;
      break;
  } /* switch */

  if((*g_sFedr_class=='2') || (*g_sFedr_class=='5') || (*g_sFedr_class=='9')){
    for(i=0; i < 7; i++){
      iDeflag = 1;
      psFieldStatus = g_sIedr_field + i;
      for(j=0; j < 8; j++){     /* �w�� psFieldStatus 8 �� bits */
        if(*psFieldStatus&iDeflag){
          sprintf(recEdrChg[idx].icode, "%02d", i*8+j);
          recEdrChg[idx].fclass = 2; idx++;
        }
        iDeflag <<= 1;
      }
    }
  }

  flag_02 = flag_03 = flag_05 = 0;
  if((*g_sFedr_class=='4') || (*g_sFedr_class=='6') || (*g_sFedr_class=='9')){
    $DECLARE x1 CURSOR FOR
      SELECT  iedr_type,   iins_type,   qserial
        INTO $sIedr_type, $sIins_type, $iQserial
        FROM edr_ins_type
       WHERE iendorse = $p_sIendorse
    ORDER BY qserial;
    $OPEN x1;
    while(1){
      $FETCH x1;
      if(SQLCODE == SQLNOTFOUND) break;

      if(strcmp(sIedr_type, "02") == 0){
        if(flag_02 == 0) flag_02 = 1;
        else continue;
      }
      if(strcmp(sIedr_type, "03") == 0){
        if(flag_03 == 0) flag_03 = 1;
        else continue;
      }
      if(strcmp(sIedr_type, "05") == 0){
        if(flag_05 == 0) flag_05 = 1;
        else continue;
      }

      strcpy(sFins_grp, " ");
      if((strcmp(sIedr_type, "04")==0) || (strcmp(sIedr_type, "40")==0)){
        $SELECT  fins_grp,   qcoverage 
           INTO $sFins_grp, $iQcoverage
           FROM insurance_type 
          WHERE iins_type = $sIins_type;
        strcpy(recEdrChg[idx].icode, sIedr_type);
        strcpy(recEdrChg[idx].iins_type, sIins_type);
        strcpy(recEdrChg[idx].fins_grp, sFins_grp);
        recEdrChg[idx].fclass = 1;
        idx++;
      }else{
        strcpy(recEdrChg[idx].icode, sIedr_type);
        strcpy(recEdrChg[idx].iins_type, sIins_type);
        strcpy(recEdrChg[idx].fins_grp, sFins_grp);
        recEdrChg[idx].fclass = 1;
        idx++;
      }
    }
    $CLOSE x1; $FREE x1;
  }

  if((*g_sFedr_class=='4') || (*g_sFedr_class=='6') || (*g_sFedr_class=='9'))
  {
    if(g_lMedrdmg_prem + g_lMedrlia_prem > 0){
        strcpy(recEdrChg[idx].icode, "98");
        recEdrChg[idx].fclass = 2;
       idx++;
     } else if(g_lMedrdmg_prem + g_lMedrlia_prem < 0){
       strcpy(recEdrChg[idx].icode, "97");
       recEdrChg[idx].fclass = 2;
       idx++;
    }
  }
  strcpy(recEdrChg[idx].icode, "99");  /* �S���[�� */
  recEdrChg[idx].fclass = 2;
  idx++;

  for(i=0; i < idx; i++)
  {
    sprintf(sFclass, "%d", recEdrChg[i].fclass);

/********
# ifdef _M860718
printf("{ca401_data3.0010}: edr_class[%s], sFclass[%s]\n", g_sFedr_class, sFclass);
# endif
********/

    if(*g_sFedr_class=='2' && strcmp(sFclass, "2")==0 && 
       strcmp(recEdrChg[i].icode, "02")==0)
       continue;
    if((*g_sFedr_class=='5' || *g_sFedr_class=='2') &&
       strcmp(sFclass, "2")==0 && strcmp(recEdrChg[i].icode, "03")==0)
       if(*g_sNuser == ' ' || *g_sNuser == '\0')
          strcpy(recEdrChg[i].icode, "70");

    if((*g_sFedr_class=='5' || *g_sFedr_class=='2') &&
       strcmp(sFclass, "2")==0 && strcmp(recEdrChg[i].icode, "05")==0)
       if(*g_sNbenef== ' ' || *g_sNbenef=='\0')
          strcpy(recEdrChg[i].icode, "71");

/********
# ifdef _M860718
printf("{ca401_data3.0020}: select endorsement_code(icode=%s,fclass=%s)\n", recEdrChg[i].icode, sFclass);
# endif
********/

    $SELECT  iedr_item 
       INTO $sIedr_item 
       FROM endorsement_code
      WHERE icode = $recEdrChg[i].icode AND fclass = $sFclass;
    if(SQLCODE == SQLNOTFOUND)
       continue;

/********
# ifdef _M860718
printf("{ca401_data3.0030}: select endorsement_item(iedr_item=%s)\n", sIedr_item);
# endif
********/

    $DECLARE x2 CURSOR FOR
      SELECT  qserial,   eedr_item,   ntable,   ncolumn,   fdatatype
        INTO $lQserial, $sEedr_item, $sNtable, $sNcolumn, $sFdatatype
        FROM endorsement_item
       WHERE iedr_item = $sIedr_item
    ORDER BY qserial;
    $OPEN x2;
    for(j=0;;j++){
      $FETCH x2;
      if(SQLCODE == SQLNOTFOUND) break;
      strcpy(sEedr_item, rtrim(sEedr_item));
      strcpy(sNtable,    rtrim(sNtable));
      strcpy(sNcolumn,   rtrim(sNcolumn));
      strcpy(sFdatatype, rtrim(sFdatatype));

      if((g_pEedr_item[j]=calloc(1, strlen(sEedr_item)+1)) == NULL){
        int ii;
        for(ii=0; ii < j; ii++){
          free(g_pEedr_item[ii]);
          free(g_pData[ii]);
        }
        return M_CM_NOT_MALLOC;
      }
      strcpy(g_pEedr_item[j], sEedr_item);

      if(strncmp(sNtable, "edr_relation", 12) == 0){
        if(strncmp(sNcolumn, "total", 5) == 0){
          $SELECT medrdmg_prem + medrlia_prem 
             INTO $lTot_prem
             FROM edr_relation
            WHERE iendorse = $p_sIendorse;
/********
# ifdef _M860718
printf("{ca401_data3.0040}: (edr_relation.total)medrdmg_prem+medrlia_prem=%d\n", lTot_prem);
# endif
********/
          lTot_prem = labs(lTot_prem);
          rfmtlong(lTot_prem, "****,***,**&", sTmpData);
        } else{
          if(*sFdatatype=='4' || *sFdatatype=='1'){

            sprintf(sTmt,"SELECT %s FROM %s WHERE iendorse='%s'",
                sNcolumn, sNtable, p_sIendorse);
/********
# ifdef _M860718
printf("{ca401_data3.0050}: (edr_relation.datatype=1, 4)stmt[%s]\n", sTmt);
# endif
********/
            $PREPARE q1   FROM $sTmt;
            $DECLARE q1_1 CURSOR FOR q1;
               $OPEN q1_1;
              $FETCH q1_1 INTO $sTmpBuf;
              $CLOSE q1_1; $FREE q1_1;

            strcpy(sTmpBuf, rtrim(sTmpBuf));

            if(*sFdatatype == '4')
              strcpy(sTmpData, cm_from_infdate(sTmpBuf));
            else {
              if(strncmp(sNcolumn, "itreaty", 7) == 0){
                if(strncmp(sTmpBuf, "6", 1) == 0)
                  strcpy(sTmpBuf, "�s�j��d���I�X��");
              }
              strcpy(sTmpData, sTmpBuf);
            }
          } else {
            sprintf(sTmt, "SELECT %s FROM %s WHERE iendorse = '%s'",
                sNcolumn, sNtable, p_sIendorse);
/********
# ifdef _M860718
printf("{ca401_data3.0060}: (edr_relation.datatype!=1, 4)stmt[%s]\n", sTmt);
# endif
********/
            $PREPARE q5 FROM $sTmt;
            $DECLARE q5_1 CURSOR FOR q5;
            $OPEN q5_1;
            $FETCH q5_1 INTO $iTmp;
            $CLOSE q5_1; $FREE q5_1;
            rfmtlong(iTmp, "***&", sTmpData);
          }
        }
      } else if(strncmp(sNtable, "endorsement", 11) == 0){
        if(strncmp(sNcolumn, "nassured30", 10) == 0){
          sprintf (sTmt, "SELECT nassured FROM %s WHERE iendorse = '%s'",
              sNtable, p_sIendorse);
/********
# ifdef _M860718
printf("{ca401_data3.0070}: (endorsement.nassured30)stmt[%s]\n", sTmt);
# endif
********/
          $PREPARE q8 FROM $sTmt;
          $DECLARE q8_1 CURSOR FOR q8;
          $OPEN q8_1;
          $FETCH q8_1 INTO $sTmpBuf;
          $CLOSE q8_1; $FREE q8_1;

          strcpy(sTmpBuf, rtrim(sTmpBuf));

          sprintf(sTmpData, "      %s", sTmpBuf);
        } else if(strncmp(sNcolumn, "total", 5) == 0){
          $SELECT medrdmg_prem + medrlia_prem 
             INTO $lTot_prem
             FROM edr_relation
            WHERE iendorse = $p_sIendorse;
          lTot_prem = labs(lTot_prem);
/********
# ifdef _M860718
printf("{ca401_data3.0080}: (endorsement.total)medrdmg_prem+medrlia_prem=%d\n", lTot_prem);
# endif
********/
          rfmtlong(lTot_prem, "****,***,**&", sTmpData);
        } else {
          sprintf(sTmt, "SELECT %s FROM %s WHERE iendorse='%s'",
              sNcolumn, sNtable, p_sIendorse);
/********
# ifdef _M860718
printf("{ca401_data3.0090}: (endorsement.[not total])stmt[%s]\n", sTmt);
# endif
********/
          $PREPARE q7 FROM $sTmt;
          $DECLARE q7_1 CURSOR FOR q7;
          $OPEN q7_1;
          $FETCH q7_1 INTO $sTmpBuf;
          $CLOSE q7_1; $FREE q7_1;

          strcpy(sTmpBuf, rtrim(sTmpBuf));
          if(*sFdatatype == '4')        /* data type is 'date' */
            strcpy(sTmpData, cm_from_infdate (sTmpBuf));
          else {
            if(strncmp(sNcolumn, "fassured", 8) == 0){
              if(strncmp(sTmpBuf, "1", 1) == 0)
                strcpy(sTmpBuf, "�۵M�H");
              if(strncmp(sTmpBuf, "2", 1) == 0)
                strcpy(sTmpBuf, "�k�H");
              if(strncmp(sTmpBuf, "3", 1) == 0)
                strcpy(sTmpBuf, "�~��H");
            } else if(strncmp(sNcolumn, "fsex", 4) == 0) {
              if(strncmp(sTmpBuf, "1", 1) == 0)
                strcpy(sTmpBuf, "�k");
              if(strncmp(sTmpBuf, "2", 1) == 0)
                strcpy(sTmpBuf, "�k");
            } else if(strncmp(sNcolumn, "fmarriage", 9) == 0) {
              if(strncmp(sTmpBuf, "1", 1) == 0)
                strcpy(sTmpBuf, "�w�B");
              if(strncmp(sTmpBuf, "2", 1) == 0)
                strcpy(sTmpBuf, "���B");
            } else if(strncmp(sNcolumn, "flimit", 6) == 0) { 
              if(strncmp(sTmpBuf, "1", 1) == 0)
                strcpy(sTmpBuf, "���w�r�p�H");
              if(strncmp(sTmpBuf, "2", 1) == 0)
                strcpy(sTmpBuf, "�����w�r�p�H");
            } else if(strncmp(sNcolumn, "fpt", 3) == 0) {
              if(strncmp(sTmpBuf, "P", 1) == 0)
                strcpy(sTmpBuf, "���ȼ�");
              if(strncmp(sTmpBuf, "T", 1) == 0)
                strcpy(sTmpBuf, "����");
            } else if(strncmp(sNcolumn, "ibrand", 6) == 0)
              sTmpBuf[8] = '\0';
            strcpy(sTmpData, sTmpBuf);
          }
        }
      } else if(strncmp(sNtable, "edr_ins_type", 12) == 0) {
        strcpy(sIins_type, recEdrChg[i].iins_type);

        if(strncmp(sNcolumn, "pcal", 4) == 0){
          if(strcmp(sIins_type, "21") == 0)
            strcpy(sTmpData, "");
          else {
/********
# ifdef _M860718
printf("{ca401_data3.0100}: (edr_ins_type.ins_type!=21 ins[%s]\n", sIins_type);
# endif
********/
            $SELECT  fcal_way,   pcal 
               INTO $sFcal_way, $iTmp
               FROM edr_ins_type
              WHERE iendorse = $p_sIendorse AND iins_type = $sIins_type;

            rfmtlong(iTmp, "***&", sTmpData);
            if(*sFcal_way == 'M')
              strcat(sTmpData, "% ");
            else
              strcat(sTmpData, "��");
          }
        }
        else
        {
/********
# ifdef _M860718
printf("{ca401_data3.0110}: (edr_ins_type ins[%s]\n", sIins_type);
# endif
********/
          $SELECT  medrinj_cover, medrdea_cover, medrdmg_cover, 
                   mdeduct, medrins_prem
             INTO $lMedrinj_cover, $lMedrdea_cover, $lMedrdmg_cover, 
                  $lMdeduct, $lMedrins_prem
             FROM edr_ins_type
            WHERE iendorse = $p_sIendorse AND iins_type = $sIins_type;

/********
# ifdef _M860718
printf("{ca401_data3.0120}: (edr_ins_type ins[%s]\n", sIins_type);
# endif
********/
          $SELECT minjured_cover, mdeath_cover, mdamage_cover,
                  mins_premium
             INTO $lMinjured_cover, $lMdeath_cover, $lMdamage_cover,
                  $lMins_premium
             FROM ply_ins_type_bak
            WHERE iendorse = $p_sIendorse AND iins_type = $sIins_type;

          if(strncmp(sNcolumn, "coverage", 8) == 0)
            rfmtlong(lMdamage_cover + lMedrdmg_cover, "****,***,**&", sTmpData);
          else if(strncmp(sNcolumn, "medrins_prem1", 13) == 0)
            rfmtlong(lMins_premium + lMedrins_prem, "****,***,**&", sTmpData);
          else if(strncmp(sNcolumn, "mdeduct1", 8) == 0) {
            if(strcmp(sIins_type, "11") == 0){
              if(lMdeduct == 10)
                strcpy(sTmpData, " �ʤ����Q");
              if(lMdeduct == 20)
                strcpy(sTmpData, " �ʤ����G�Q");
            } else {
              rfmtlong(lMdeduct, "****,***,**&", sTmpData);
              strcat(sTmpData, "����");
            }
          } else if(strncmp(sNcolumn, "medrdmg_cover", 13) == 0)
            cm_double_cstr((double) lMedrdmg_cover, sTmpData, 50);
        }
      }
      else if(strncmp(sNtable, "ins_type", 8) == 0){
        strcpy(sIins_type, recEdrChg[i].iins_type);
        if(strcmp(sIins_type, "53") == 0)
          strcpy(sTmpData, "(�t�����I) ");
        else
          strcpy(sTmpData, " ");
      } else if(strncmp(sNtable, "insurance_type", 14) == 0) {
        strcpy(sIins_type, recEdrChg[i].iins_type);
        strcpy(sFins_grp, recEdrChg[i].fins_grp);

        sprintf(sTmt, "SELECT %s FROM %s WHERE iins_type='%s'",
            sNcolumn, sNtable, sIins_type);
/********
# ifdef _M860718
printf("{ca401_data3.0130}: (ins_type stmt[%s]\n", sTmt);
# endif
********/
        $PREPARE q2 FROM $sTmt;
        $DECLARE q2_1 CURSOR FOR q2;
        $OPEN q2_1;
        $FETCH q2_1 INTO $sTmpBuf;
        $CLOSE q2_1; $FREE q2_1;

        strcpy(sTmpBuf, rtrim(sTmpBuf));

        if(*sFins_grp != '\0' && *sFins_grp != ' ') {
          lMedrinj_cover = lMedrdmg_cover = lMedrins_prem = 0;
/********
# ifdef _M860718
printf("{ca401_data3.0140}: select edr_ins_type[%s]\n", sIins_type);
# endif
********/
          $SELECT medrinj_cover, medrdmg_cover, medrins_prem
             INTO $lMedrinj_cover, $lMedrdmg_cover, $lMedrins_prem
             FROM edr_ins_type
            WHERE iendorse = $p_sIendorse AND iins_type = $sIins_type;

          if(strcmp(sIedr_item, "04") == 0){

            /*if(*sFins_grp == '2'){
              if(lMedrdmg_cover >= 0)
                strcat(sTmpBuf, "�W�[�`�B");
              else
                strcat(sTmpBuf, "����`�B");
            } else if(*sFins_grp == '1') {
              if(lMedrdmg_cover >= 0)
                strcat(sTmpBuf, "�W�[�O�B");
              else
                strcat(sTmpBuf, "��֫O�B");
            }*/
          } else if(strcmp(sIedr_item, "40") == 0) {
            if(lMedrins_prem >= 0)
              strcat(sTmpBuf, "�W�[�O�O");
            else
              strcat(sTmpBuf, "��֫O�O");
          }
          strcpy(sTmpData, sTmpBuf);
        } else
          strcpy(sTmpData, sTmpBuf);
      } else if(strncmp(sNtable, "ply_ins_type_bak", 16) == 0){
        strcpy(sIins_type, recEdrChg[i].iins_type);

        if(strncmp(sNcolumn, "coverage", 8) == 0) {
          strcpy(sNcolumn, "mdamage_cover");

          sprintf(sTmt, "SELECT %s FROM %s WHERE %s",
              sNcolumn, sNtable, "iendorse=? AND iins_type=?");
/********
# ifdef _M860718
printf("{ca401_data3.0150}: ply_ins_type_bak.coverage stmt[%s]\n", sTmt);
# endif
********/
          $PREPARE q6 FROM $sTmt;
          $DECLARE q6_1 CURSOR FOR q6;
             $OPEN q6_1 USING $p_sIendorse, $sIins_type;
            $FETCH q6_1 INTO $lTot_prem; 
            $CLOSE q6_1; $FREE q6_1;

          rfmtlong(lTot_prem, "****,***,**&", sTmpData);
        } else {
          sprintf(sTmt, "SELECT %s FROM %s WHERE %s",
              sNcolumn, sNtable, "iendorse=? AND iins_type=?");
/********
# ifdef _M860718
printf("{ca401_data3.0160}: ply_ins_type_bak.coverage stmt[%s]\n", sTmt);
# endif
********/
          $PREPARE q3 FROM $sTmt;
          $DECLARE q3_1 CURSOR FOR q3;
          $OPEN q3_1 USING $p_sIendorse, $sIins_type;
          $FETCH q3_1 INTO $lTot_prem;
          $CLOSE q3_1; $FREE q3_1;

          if(strcmp(sIedr_item, "20") == 0) {
            if(strcmp(sIins_type, "11") == 0) {
              strcpy(sTmpData, " ");
              if(lTot_prem == 10)
                strcpy(sTmpData, " �ʤ����Q");
              if(lTot_prem == 20)
                strcpy(sTmpData, " �ʤ����G�Q");
            } else {
              rfmtlong(lTot_prem, "****,***,**&", sTmpData);
              strcat(sTmpData, "��");
            }
          } else
            rfmtlong(lTot_prem, "****,***,**&", sTmpData);
        }
      }
      else if(*sNtable == '\0' || *sNtable == ' ') {
        sTmpData[0]='\0'; 
        /*strcpy(sTmpData, " ");*/
      } else {
        sprintf(sTmt, "SELECT %s FROM %s WHERE iendorse='%s'",
            sNcolumn, sNtable, p_sIendorse);
/********
# ifdef _M860718
printf("{ca401_data3.0170}: else stmt[%s]\n", sTmt);
# endif
********/
        $PREPARE q4 FROM $sTmt;
        $DECLARE x CURSOR FOR q4;
        $OPEN x;
        $FETCH x INTO $sTmpBuf;
        $CLOSE x; $FREE x;

        strcpy(sTmpBuf, rtrim(sTmpBuf));
        if(*sFdatatype == '4')
          strcpy(sTmpData, cm_from_infdate(sTmpBuf));
        else
          strcpy(sTmpData, sTmpBuf);
      }
      if((g_pData[j]=calloc(1, strlen(sTmpData)+1)) == NULL){
        int ii;
        for(ii=0; ii < j; ii++){
          free(g_pEedr_item[ii]);
          free(g_pData[ii]);
        }
        return M_CM_NOT_MALLOC;
      }
      strcpy(g_pData[j], sTmpData);
    } /* end of for */
    $CLOSE x2; $FREE x2;

# ifdef _M860718
printf("{ca401_data3.0040}: j[%d]\n", j);
# endif


    if(j != 0)
    {
      char *p;
      int  xx;

      strcpy(sTmpBuf, pwformat(j, g_pEedr_item, g_pData, 4, &iLine));

# ifdef _M860718
printf("{ca401_data3.0050}: iLine[%d] i[%d] sTmpBuf[%s]\n", iLine, i, sTmpBuf);
# endif

      if(lEdrItemCount == 14) { /* 861226-mag, ���@���̦h�L14�� */
         lEdrItemCount = 0;
         iPg++;
         printf("-----------------------> data3() iPg[%d]\n",iPg);
      }


      /* 861226-mag, ��XsTmpBuf���Ĥ@�Ӵ���Ÿ�����}p */
      p = strchr(sTmpBuf, '\n');
      if(p == NULL) {  /* 861226-mag, sTmpBuf���L����Ÿ� */
        insert_tmp_table(iPg, EDR_BASE_LINE+lEdrItemCount, 1, sTmpBuf);
        lEdrItemCount++;
      } else {
        /* *** Block endorse_item *** */
        strncpy(sTmpBuf1, sTmpBuf, p-sTmpBuf);sTmpBuf1[p-sTmpBuf] = '\0';


        insert_tmp_table(iPg, EDR_BASE_LINE+lEdrItemCount, 1, sTmpBuf1);
        lEdrItemCount++;

        insert_tmp_table(iPg, EDR_BASE_LINE+lEdrItemCount, 1, p+1);
        lEdrItemCount++;
      }

    }

        { /* *** Temporary block for free memory  - tony96.860825 - *** */
          short ii;
          for(ii=0; ii < j; ii++){
              free(g_pEedr_item[ii]);
              free(g_pData[ii]);
          }
        }
  } /* end of for */

  /* 861226-mag, �C�i��檺�Ĥ@���~�ݦC�L */
  strcpy(sTmpDate, cm_from_infdate(g_sDendorse));
  cm_split_ymd(sTmpDate, sYY, sMM, sDD);
  insert_tmp_table(iPg_init, 34, 1, sYY);
  insert_tmp_table(iPg_init, 34, 2, sMM);
  insert_tmp_table(iPg_init, 34, 3, sDD);

  return M_CM_OK;

errexit:
  printf("{ca401_data3}: SQLCODE=[%d] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
  return SQLCODE;
} /* ca401_data3 */


/************************************************************************/
long drop_temp_table ()
{
  $char sTmt[1024];

  $WHENEVER SQLERROR GOTO errexit;

  printf("--------------------- g_sFile[%s]\n", g_sFile);
  sprintf(sTmt,
    "DROP TABLE tmp%s", g_sFile);
  printf("--------------------- stmt[%s]\n", sTmt);
  $PREPARE dtt_1 FROM $sTmt;
  $EXECUTE dtt_1;

/************
  sprintf(sTmt,
    "DROP INDEX tmpx%s", g_sFile);
  $PREPARE dtt_2 FROM $sTmt;
  $EXECUTE dtt_2;
************/

  return M_CM_OK;

errexit:
  printf("{drop_temp_table}: SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  return SQLCODE;
} /* drop_temp_table */


/*************************************************************************/
long insert_tmp_table (p_pg, p_row, p_col, p_str)
$int  p_pg; /* 861226-mag */
$int  p_row, p_col;
$char *p_str;
{
  $char sTmt[1024];

  $WHENEVER SQLERROR GOTO errexit;

  sprintf(sTmt,
    "INSERT INTO tmp%s VALUES(?, ?, ?, ?)", g_sFile);
  $PREPARE i_tmptbl FROM $sTmt;
  $EXECUTE i_tmptbl USING $p_pg, $p_row, $p_col, $p_str;

/********
# ifdef _M860718
printf("{insert_tmp_table}: insert row[%d],col[%d],str[%s]\n", p_row, p_col, p_str);
# endif
********/

  return M_CM_OK;

errexit:
  printf("{insert_tmp_table}:SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  return SQLCODE;
} /* insert_tmp_table */


/*************************************************************************/
long data_report (p_piMaxCount)
int *p_piMaxCount;
{
  $int   i, j, k, tmp_pg ,tmp_row, tmp_col;
  $int   old_row, old_col;  /* 870209-mag */
  $char  sTmt[1024], sBuf[511];
  $int   p_Pg, n, m; /* 861226-mag */
  

  $WHENEVER SQLERROR GOTO errexit;

printf("==============================> into data_report()\n");
printf("==g_sFile[%s] =======into data_report()\n",g_sFile);

  /* 861226-mag */
  sprintf(sTmt, "SELECT rpt_pg FROM tmp%s ORDER BY rpt_pg DESC", g_sFile);
  $PREPARE s_temp_1 FROM $sTmt;
  $DECLARE sel_t_cur1 CURSOR FOR s_temp_1;
  $OPEN sel_t_cur1;
  $FETCH sel_t_cur1 INTO $p_Pg;
  $CLOSE sel_t_cur1; 
  $FREE sel_t_cur1;

  if (p_Pg > 1) {
      for (n=1; n<p_Pg; n++)
      {
           insert_tmp_table(n, 17, 8, "(��U��)");
      }
      insert_tmp_table(p_Pg, 17, 8, "(��W��)");
  }

printf("*--------------after FETCH !!\n");

        sprintf(sTmt,
          "SELECT str,rpt_pg, rpt_row, rpt_col \
             FROM tmp%s %s ORDER BY rpt_pg,rpt_row,rpt_col", g_sFile, 
           "WHERE rpt_pg= ? ");

printf("@@@@ stmt[%s]\n",sTmt);

        $PREPARE s_temp FROM $sTmt;
        $DECLARE sel_t_cur CURSOR FOR s_temp;

printf("begin for loop\n");


        for(m=1; m<=p_Pg; m++)
        {
          old_row=1;
          old_col=0;

          $OPEN sel_t_cur USING $m;
          while(1)
          {
              $FETCH sel_t_cur INTO $sBuf, $tmp_pg, $tmp_row, $tmp_col;
              if(SQLCODE == SQLNOTFOUND) break;
              strcpy(sBuf, rtrim(sBuf));
              old_col++;

/**************************
# ifdef _M860718
**************************/
  printf("{data_report}: page[%d] row[%d] col[%d] str[%s]\n", tmp_pg, tmp_row, tmp_col, sBuf);
/**************************
# endif
**************************/

              while(tmp_row > old_row)                   /* ���C */
              {
                    for(n=old_col+1; n<=MAX_COLUMN; n++) /* 870209-mag */
                    {
                        rgu_put_body_string(old_row, " ", LEFT);
                    }

                    rgu_put_body(old_row);
                    (*p_piMaxCount)++;
                    old_row++;
                    old_col=1;
              }

              while(tmp_col > old_col)     /* 870209-mag,�C�C���@�w�C�泣�L */
              {
                    for(n=old_col; n<tmp_col; n++)           /* 870209-mag */
                    {
                        rgu_put_body_string(tmp_row, " ", LEFT);
                    }
                    old_col=tmp_col;
              }
        
              rgu_put_body_string(tmp_row, rtrim(sBuf), LEFT);
 
          }
          rgu_put_body(tmp_row);
          (*p_piMaxCount)++;
        }
        $CLOSE sel_t_cur;
        $FREE sel_t_cur;



printf("*--------------after loop !!\n");
        sprintf(sTmt,"DELETE FROM tmp%s",g_sFile);
        $PREPARE s_temp FROM $sTmt;
        $EXECUTE s_temp;

printf("=after  delete=======> into data_report()\n");

  return M_CM_OK;

errexit:
  printf("{data_report}: SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  return SQLCODE;
} /* data_report */

 
/***********************************************************************/
/*
 * ���ڦC�L
 *
 ***********************************************************************/
long car401_body_receipt (p_sIendorse)
$char *p_sIendorse;
{
  $char sIpolicy[POLICY_NUM_1], sIofficer[11], sIbroker[11], sDendorse[11];
  $long lMedrdmg_prem, lMedrlia_prem, lMedrdmg_commi, lMedrlia_commi;
  $long lMdiscount;
  $long lDedr_begin, lDedr_end;
  $char sNassured[122], sAassured[92], sIlicense[12], sItel[12], sNbenef[43];
  $char sIbranch[3], sSite[3], sNpresident[12], sToday[11];
  $date dToday;
  $char sYY[3], sMM[3], sDD[3], sIpolicy1[POLICY_NUM_1],sIpolicy2[POLICY_NUM_2];
  $char sPayResult[3], sPayStatus[32], sPayDate[11], sNoteDate[11];
  $long lMprem_total, lMdisc_total, lMcomm_total, lMreal_total;
  short fStatus;
  $char sTmpBuf[254], sTmpBuf1[81], sTmpBuf2[81], sTmpBuf3[81], sAddress[91];
  $char sTmpBuf1_tmp[81];
  $char sTaxName[11], sTaxArea[11];

  /* 861226-mag */
  int   iPg;

  iPg = 1;


  $WHENEVER SQLERROR GOTO errexit;

  $SELECT ipolicy, iofficer, ibroker, dendorse, dedr_begin, 
          dedr_end, medrdmg_prem, medrlia_prem, medrdmg_commi, 
          medrlia_commi
    INTO  $sIpolicy, $sIofficer, $sIbroker, $sDendorse, $lDedr_begin,
          $lDedr_end, $lMedrdmg_prem, $lMedrlia_prem, $lMedrdmg_commi,
          $lMedrlia_commi
     FROM edr_relation
    WHERE iendorse = $p_sIendorse;
  if(SQLCODE == SQLNOTFOUND)
    return M_CA_NREL_EDR;

  strcpy(sIpolicy,    rtrim(sIpolicy));
  strcpy(sIofficer,   rtrim(sIofficer));
  strcpy(sIbroker,    rtrim(sIbroker));
  strcpy(sDendorse,   rtrim(sDendorse));

  /* *** �O�渹�X *** */
/* ***************************************************************************
 * sprintf(sTmpBuf, "02%s", sIpolicy);
 * if(strlen(sTmpBuf) > 14)
 *   sTmpBuf[14] = '\0';
 * ***************************************************************************/
  sprintf(sTmpBuf, "%s/%s", sIpolicy,p_sIendorse);
  sTmpBuf[37]='\0';
  insert_tmp_table(iPg, 1, 17, sTmpBuf);
  insert_tmp_table(iPg, 17, 9, sTmpBuf);
/***
  insert_tmp_table(iPg, 1, 17, p_sIendorse);
  insert_tmp_table(iPg, 17, 9, p_sIendorse);
****/
  /*** FROM edr_ins_type OR FROM edr_raltion ***/
  lMdiscount=0;
  $SELECT SUM(medr_discount)
     INTO $lMdiscount
     FROM edr_ins_type
    WHERE iendorse = $p_sIendorse;

  $SELECT  nassured,   aassured,   ilicense,   itel,   nbenef
     INTO $sNassured, $sAassured, $sIlicense, $sItel, $sNbenef
     FROM endorsement
    WHERE iendorse = $p_sIendorse;
  if(SQLCODE == SQLNOTFOUND)
    return M_CA_NENDORSE;
  strncpy(sIbranch, p_sIendorse, 2); sIbranch[2] = '\0';
  strcpy(sNassured, rtrim(sNassured));
  strcpy(sAassured, rtrim(sAassured));
  strcpy(sIlicense, rtrim(sIlicense));
  strcpy(sItel,     rtrim(sItel));

  /* *** �O��W�� *** */
  insert_tmp_table(iPg, 3, 7, sNassured);
  insert_tmp_table(iPg, 20, 2, sNassured);

  /* *** ���O�a�} *** */
  if(strlen(sAassured) <= 72) {
    insert_tmp_table(iPg, 5, 9, sAassured);
    insert_tmp_table(iPg, 26, 2, sAassured);
  } else { /* *** temporary block add by mag-870209 *** */
    int  i;
    char buf[80];

    i = cc_split_chinese(sAassured, buf, 72);
    insert_tmp_table(iPg, 5, 8, buf);
    insert_tmp_table(iPg, 25, 2, buf);
    cc_split_chinese(sAassured+i, buf, 72);
    insert_tmp_table(iPg, 5, 9, buf);
    insert_tmp_table(iPg, 26, 2, buf);
  }

  /* *** ��U�Ȧ� *** */
  insert_tmp_table(iPg, 7, 7, sNbenef);
  insert_tmp_table(iPg, 29, 2, sNbenef);

  /* *** �q�� *** */
  insert_tmp_table(iPg, 7, 11, sItel);
  insert_tmp_table(iPg, 32, 1, sItel);



  if(strlen(sIpolicy) > CAR_POLICY_LEN){
    strncpy(sIpolicy1,sIpolicy,CAR_POLICY_LEN); 
    sIpolicy1[CAR_POLICY_LEN] = '\0';
    strcpy(sIpolicy2, sIpolicy+CAR_POLICY_LEN);
  }else{
    strcpy(sIpolicy1, sIpolicy);
    strcpy(sIpolicy2, "");
  }

  strncpy(sSite, sIpolicy, 2); sSite[2] = '\0';
  ao_chk_charge(sSite, '1', sIpolicy1,sIpolicy2, "",
                             sPayResult, sPayStatus,
                             sPayDate, sNoteDate);
if (sPayResult[0]=='X') {
$SELECT ibatch_no INTO $ibatch_no FROM ply_relation WHERE ipolicy=$sIpolicy;
memset (batch_no, 0, sizeof (batch_no));
sprintf(batch_no,"%d",ibatch_no);
printf("{ca_rpt_endorse.0010}:ibatch_no[%d]\n",ibatch_no);
printf("{ca_rpt_endorse.0020}:batch_no[%s]\n",batch_no);

   /*ao_chk_charge (sSite, '1', sIpolicy1,sIpolicy2,batch_no,
                  sPayResult, sPayStatus, sPayDate, sNoteDate);*/

   ao_chk_charge (sSite, '1', sIpolicy1,sIpolicy2,"",
                  sPayResult, sPayStatus, sPayDate, sNoteDate);
printf("payresult[%s]\n",sPayResult);
if (sPayResult[0] == 'X')
   ao_chk_charge (sSite, '1', sIpolicy1,"",batch_no,
                       sPayResult, sPayStatus, sPayDate, sNoteDate);
}
printf("&&&& sPayStatus[%s]\n", sPayStatus);
  strcpy(sPayStatus, rtrim(sPayStatus));
printf("&&&& sPayStatus[%s]\n", sPayStatus);
  lMprem_total = lMedrdmg_prem + lMedrlia_prem;
  lMdisc_total = lMdiscount;
  lMcomm_total = lMedrdmg_commi + lMedrlia_commi;
  lMreal_total = lMprem_total - lMdisc_total;

/* fStatus=0 ���h�O, =1 �����O */
  fStatus = (lMprem_total<0) ? 0 : 1;

  strncpy(sIbranch, sIpolicy, 2); sIbranch[2] = '\0';
  $SELECT tax_name, tax_area, address
     INTO $sTaxName, $sTaxArea, $sAddress
     FROM ca_area_code
    WHERE sk_code = $sIbranch;
  if(SQLCODE == SQLNOTFOUND){
    strcpy(sTaxName, "");
    strcpy(sTaxArea, "");
    strcpy(sAddress, "");
  }else{
    strcpy(sTaxName, rtrim(sTaxName));
    strcpy(sTaxArea, rtrim(sTaxArea));
    strcpy(sAddress, rtrim(sAddress));
  }

  if(fStatus == 0){
    insert_tmp_table(iPg, 1, 2, "===================");
    /* *** Esc+FontSize+string+Esc+FontSize *** */
    sprintf(sTmpBuf, "%c%c(�h�O)%c%c", 27, 24, 27, 12);
    insert_tmp_table(iPg, 1, 1, sTmpBuf);
    insert_tmp_table(iPg, 14, 13, sTmpBuf);
    insert_tmp_table(iPg, 1, 3, "===================");
    insert_tmp_table(iPg, 1, 5, "===================");
   
    insert_tmp_table(iPg, 1, 4, "�����ڪ��B�Ы��d�����|�K���L��w�V�����q");
    insert_tmp_table(iPg, 1, 6, "�]�ȳB��z��ڤ���(250���H�U�K�K�L��)");
    insert_tmp_table(iPg, 1, 7, " ");
    sprintf(sTmpBuf, "�O�O%s", sPayStatus);
    if(sTmpBuf[strlen(sTmpBuf)-1] == ';') 
      sTmpBuf[strlen(sTmpBuf)-1] = '\0';
    insert_tmp_table(iPg, 1, 8, sTmpBuf);
    insert_tmp_table(iPg, 6, 7, "�����Ҹ� (�Ц۶�)");
    insert_tmp_table(iPg, 27, 2, "�����Ҹ� (�Ц۶�)");
    insert_tmp_table(iPg, 6, 8, "���ڤH");
    insert_tmp_table(iPg, 24, 3, "�g���H");

    insert_tmp_table(iPg, 7, 8, "ñ  ��");

    /* *** �s���� *** */
    dToday = cm_today();
    strcpy(sToday , cm_cdate_str(dToday));
    cm_split_ymd(sToday, sYY, sMM, sDD);
    sprintf(sTmpBuf, "�s���� %s �~ %s �� %s ��", sYY, sMM, sDD);
    insert_tmp_table(iPg, BASE_LINE, 9, sTmpBuf);
    insert_tmp_table(iPg, 33, 1, sTmpBuf);

    /* *** �g���H *** */
    if(strncmp(sIbroker, "ZZZZZ", 5) == 0)
      sprintf(sTmpBuf, "��������%s", sIbroker);
    else
      strcpy(sTmpBuf, sIbroker);
    insert_tmp_table(iPg, 7, 10, sTmpBuf);
    insert_tmp_table(iPg, 32, 2, sTmpBuf);

  } else {

    insert_tmp_table(iPg, 1, 2, " ");
    sprintf(sTmpBuf, "%c%c(���O)%c%c", 27, 24, 27, 12);
    insert_tmp_table(iPg, 1, 1, sTmpBuf);
    insert_tmp_table(iPg, 14, 13, sTmpBuf);
    /* *** �ƥ���r���� *** */
    sprintf(sTmpBuf, "%c%c�ƥ�%c%c", 27, 24, 27, 12);
    insert_tmp_table(iPg, 13, 13, sTmpBuf);
    insert_tmp_table(iPg, 14, 14, "�������ڦL��w�`ú");
    /* *** �L��|�a�� *** */
    if(strlen(sTaxArea) > 0){
      strncpy(sTmpBuf1, sTaxArea, 2); sTmpBuf1[2] = '\0';
      strncpy(sTmpBuf2, sTaxArea+2, 2); sTmpBuf2[2] = '\0';
      sprintf(sTmpBuf, "%s               %s", sTmpBuf1, sTmpBuf2);
      insert_tmp_table(iPg, 1, 3, sTmpBuf);
    }else
      insert_tmp_table(iPg, 1, 3, " ");
    /* *** �L��|�a�ϭt�d�H *** */
    sprintf(sTmpBuf, "     %s", sTaxName);
    insert_tmp_table(iPg, 1, 5, sTmpBuf);

    insert_tmp_table(iPg, 16, 9, "    ��  �Q��󦬨쥻�O�I�O�b��ɧY�V");
    sprintf(sTmpBuf, "    %s", sAddress);
    insert_tmp_table(iPg, 16, 13, sTmpBuf);
    insert_tmp_table(iPg, 17, 4, "    ��I�O�I�O���o�������ڥH��������");
    insert_tmp_table(iPg, 1, 8, " ");

    /* *** �g���H *** */
    if(strncmp(sIbroker, "ZZZZZ", 5) == 0)
      sprintf(sTmpBuf, "������O����%s", sIbroker);
    else
      strcpy(sTmpBuf, sIbroker);
    insert_tmp_table(iPg, 7, 10, sTmpBuf);
  }

  lMprem_total=labs(lMprem_total);
  lMdiscount=labs(lMdiscount);
  lMcomm_total=labs(lMcomm_total);
  lMreal_total=labs(lMreal_total);

  if(lMdiscount > 0  && fStatus==1){
    strcpy(sTmpBuf1, refmtamt(lMprem_total, MILLIONTH));
    strcpy(sTmpBuf2, refmtamt(lMdiscount,   MILLIONTH));
    strcpy(sTmpBuf3, refmtamt(lMreal_total, MILLIONTH));
    sprintf(sTmpBuf, "�O�ONT$%s - ����NT$%s = �ꦬNT%s",
            sTmpBuf1, sTmpBuf2, sTmpBuf3);
  } else {
    num_to_chinese(sTmpBuf1, lMreal_total);
    strcpy(sTmpBuf1_tmp,rtrim(sTmpBuf1));
    strcpy(sTmpBuf2, refmtamt(lMreal_total, MILLIONTH));
    sprintf(sTmpBuf, "%s����       NT$%s", sTmpBuf1_tmp, sTmpBuf2);
  }

  /* *** ��ú(�h)�O�O *** */
  insert_tmp_table(iPg, 3, 8, sTmpBuf);
  insert_tmp_table(iPg, 23, 2, sTmpBuf);

  /* *** ���_�l��� *** */
  strcpy(sTmpBuf, cm_cdate_str(lDedr_begin));
  cm_split_ymd(sTmpBuf, sYY, sMM, sDD);
  insert_tmp_table(iPg, 1, 14, sYY);
  insert_tmp_table(iPg, 1, 15, sMM);
  insert_tmp_table(iPg, 1, 16, sDD);
  insert_tmp_table(iPg, 17, 5, sYY);
  insert_tmp_table(iPg, 17, 6, sMM);
  insert_tmp_table(iPg, 17, 7, sDD);
 
  /* *** ���פ��� *** */
  strcpy(sTmpBuf, cm_cdate_str(lDedr_end));
  cm_split_ymd(sTmpBuf, sYY, sMM, sDD);
  insert_tmp_table(iPg, 1, 18, sYY);
  insert_tmp_table(iPg, 1, 19, sMM);
  insert_tmp_table(iPg, 1, 20, sDD);
  insert_tmp_table(iPg, 17,10, sYY);
  insert_tmp_table(iPg, 17,11, sMM);
  insert_tmp_table(iPg, 17,12, sDD);

  return M_CM_OK;

errexit:
  printf("{car401_body_receipt}:SQLCODE=[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  return SQLCODE;
} /* car401_body_receipt */

