/************************************************/
/*   PROGRAM : ca836q01s.ec                     */
/*   MODIFY  : cyrus                            */
/*   DATE    : 103.06.16                        */
/*   NOTE    : �ˮ`�I�M�ѷl�����Ӫ�             */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
$include datetime.h;
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"

$char DBName[05], iForm_Tp[03], outputf[N_FILE+1];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  userid[11];

char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;
$int  PERIOD;

static int  max_count;

DBinfo  *list;
int     count_db;

$char sIbranch[BRANCH_ID], sIofficer[EMPLOYEE_ID];
$char sNname[EMPLOYEE_NAME];
$char sIclaim[CLAIM_NUM], sFcard_class[2], sDclaim[YYYYMMDD];
$char sYearMonth[7];
$char sIadjuster[EMPLOYEE_ID], sFclose[2], sIins_type[INSURANCE_TYPE];
$char sDclose[13], victim[11], flast[2];
$char sDgroup[11];
$char sNgroup[5],sNadjuster[11];
$char sIupbranch[3], sNupgroup[11];
$char sFins_grp[2];
$char sBgnDate_e[11], sEndDate_e[11], sBgnDate[11], sEndDate[11];
$long lBgnDate, lEndDate;
$long iQorder, qmonth, lMins_stl;
$long qdmg_claim, qdmg_close, qdmg_nopay;       /** ���l **/
$long qlia_claim, qlia_close, qlia_nopay;       /** �d�� **/
$long qburg_claim, qburg_close, qburg_nopay;    /** �W�[�ѵs�����Ѩ��l�������X **/
$long qcomp_claim, qcomp_close, qcomp_nopay;    /** �j�� **/
$long qwea_claim, qwea_close, qwea_nopay;       /** �]�� **/
$date lDclaim;
$int  iclose_type;
$char stmt[2000];

$char iins_item[INSURANCE_TYPE];

int qlia, qburg, qdmg, qwea;
$int iTmp;
$int iMaxCnt;
$int id1;
$int iMonthDiff;

long car836_build();
void car836_title();
long car836_body();
long car836_print();
void car836_print2();
int DiffMonth();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;

   batchinit();
   strcpy(DBName  , isNULLstr(argv[1]));
   strcpy(userid  , isNULLstr(argv[2]));
   strcpy(sBgnDate, isNULLstr(argv[3]));
   strcpy(sEndDate, isNULLstr(argv[4]));
   strcpy(outputf , isNULLstr(argv[5]));

   strcpy(sBgnDate_e, cm_to_infdate(sBgnDate));
   strcpy(sEndDate_e, cm_to_infdate(sEndDate));

   rstrdate(sBgnDate_e, &lBgnDate);
   rstrdate(sEndDate_e, &lEndDate);

   printf("sBgnDate_e[%s] sEndDate_e[%s]\n",sBgnDate_e , sEndDate_e);

   rc=car836_get_db();
   if (rc!=M_CM_OK)
      return rc;

   rc = car836_build();
   if (rc != M_CM_OK)
       return rc;

   return M_CM_OK;

errexit:
   printf("main :SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/

long car836_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;

   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;

   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   rc = car836_body();
   if (rc != M_CM_OK)
       return rc;

   rc = car836_print();
   if (rc != M_CM_OK)
       return rc;

   return M_CM_OK;

errexit:
   EWRITE(userid,rc,sqlca.sqlerrm);
   return SQLCODE;
}

long car836_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car836_body()
{
    int i;
    long rc;
    $char sStmt[8192],sStmt1[1024],sStmt2[1024],sStmt3[1024],sStmt4[1024];
    $char  stmt[1024];

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    strcpy(sStmt,
     "  select a.iclaim1, a.insure_instype, min(a.dappraisal) as dappraisal  \
          from claim_app_dtl_h a    \
         where a.fdecide = '1'      \
           and a.insure_type = 'C'  \
           and a.insure_instype in ('93','94','95','193','194','195')  \
         group by a.iclaim1,a.insure_instype         \
          into temp car836_tmp1 with no log ");
    printf("sStmt[%s]\n",sStmt);
    $prepare main_id1 from $sStmt;
    $execute main_id1;

    strcpy(sStmt,
     " select *            \
         from car836_tmp1  \
        where dappraisal between ? and ?   \
         into temp car836_tmp2 with no log ");
    $prepare main_id2 from $sStmt;
    $execute main_id2 using $sBgnDate_e, $sEndDate_e;

    $create index car836_tmp2_ix1 on car836_tmp2(iclaim1, insure_instype, dappraisal);


    strcpy(sStmt,
     " select *,                       \
           (select max(iclose_type)    \
              from claim_stl_dtl c     \
             where a.iclaim1         =  c.iclaim1          \
               and a.insure_instype  =  c.insure_instype   \
               and a.dappraisal      =  c.dgroup           \
               and (c.msettle - c.mfee)   <>  0) as iclose_type   \
      from car836_tmp2 a     \
     where exists (select *  \
                     from claim_stl_dtl b   \
                    where a.iclaim1         =  b.iclaim1   \
                      and b.fstl            =  '1'         \
                      and a.insure_instype  =  b.insure_instype   \
                      and a.dappraisal      =  b.dgroup    \
                      and (b.msettle - b.mfee)   <>  0)    \
      into temp bbb with no log ");

    $prepare main_id3 from $sStmt;
    $execute main_id3;

    $create index bbb_ix_1 on bbb(iclaim1, insure_instype, dappraisal);
    $create index bbb_ix_2 on bbb(iclaim1);
    $create index bbb_ix_3 on bbb(iclaim1, iclose_type);

    strcpy(sStmt,
     " select a.iclaim, \
              date(a.dclaim) as dclaim, \
              (select min(x.dgroup) \
                 from dwsdb:claim_stl_dtl x,bbb y \
                where x.iclaim1        = y.iclaim1 \
                  and x.insure_instype = y.insure_instype \
                  and x.dgroup         = y.dappraisal \
                  and x.iclaim1        = a.iclaim \
                  and x.insure_instype in ('93','94','95')) as dgroup, \
              a.adjustment, \
              (select nname from officer where iofficer = a.adjustment) as nname, \
              (select ww.nbranch from sa_branch_type ww,officer kk where          \
               kk.iofficer = a.adjustment and kk.iquota = ww.ibranch) as nbranch, \
              (select a2.nchi_full from cm_clm_adjuster a1, branch a2 \
                where a1.iapp_unit = a2.ibranch and a1.empl_no = a.adjustment ) as napp_unit, \
              b.ivictim, \
              b.iatone, \
              (select nname from officer where iofficer = b.iatone) as natone, \
              (select ww1.nbranch from sa_branch_type ww1, officer kk1 where      \
               kk1.iofficer = b.iatone and kk1.iquota = ww1.ibranch) as nbranch1, \
              b.datone_victim, \
              date(b.destimate) as destimate, \
              date(b.dapprove) as dapprove,  \
              (select sum(x.msettle-x.mfee)  \
                 from dwsdb:claim_stl_dtl x,bbb y \
                where x.iclaim1        = y.iclaim1 \
                  and x.insure_instype = y.insure_instype \
                  and x.dgroup        <= y.dappraisal     \
                  and x.iclaim1        = a.iclaim         \
                  and x.insure_instype in ('93','94','95','193','194','195')) as msettle, \
              b.mupper_limit + (select mamount \
                                  from sysdb:ca_human_arb \
                                 where iitem = 'I060' \
                                   and ihuman_est = b.ihuman_est) as mupper, \
              (select sum(mamount) from ca_human_ins where ihuman_est = b.ihuman_est \
                 and iins_type in ('93','94','95','193','194','195')) as ins_mamount, \
              b.qpa_daily, \
              b.ihuman_est,  \
              (select case i.fvictim_car \
                       when 'A' then i.fvictim_car || '����' \
                       when 'B' then i.fvictim_car || '��訮' \
                       when 'C' then i.fvictim_car || '���~' when 'D' then i.fvictim_car || '��訮�W����' \
                       when 'E' then i.fvictim_car || '��訮�W�r�p' \
                       when 'F' then i.fvictim_car || '�����W�r�p' \
                       when 'G' then i.fvictim_car || '�������D-�D���ȫD�r�p' \
                       when 'H' then i.fvictim_car || '��訮���D-�D���ȫD�r�p' \
                       else '' \
                        end \
                 from ca_clm_victim_data i \
                where i.iclaim  = b.iverify  \
                  and i.ivictim = b.ivictim) as fcar, \
              (select max(date(dpaperwork)) from ca_sign_receipt \
                where iclaim = a.iclaim \
                  and isign in  (select isign \
                                   from ca_human_ins \
                                  where ihuman_est = b.ihuman_est \
                                    and iins_type in ('93','94','95','193','194','195') \
                                    and isign = ca_sign_receipt.isign) \
                  and nvl(isign,'')!='') as dpaper, \
              (select max(s.dpay) \
                 from ca_sign_receipt r, newa00:ao_stl_obj_close s \
                where r.iclaim      = s.iclose \
                  and r.iclaim      = a.iclaim \
                  and cast(r.iclose_type as char(5)) = s.iclose_type \
                  and s.fstl        = '1' \
                  and r.ifpce_id    = s.istl_obj \
                  and r.isign      in ( select isign \
                                          from ca_human_ins \
                                         where ihuman_est = b.ihuman_est \
                                           and iins_type in ('93','94','95','193','194','195') \
                                           and isign = r.isign) \
                  and nvl(r.isign,'')!='' \
                  and r.pay_kind = '5') as dpay, \
              (select sum(t.mestimate_ori) from ca_human_arb t where t.ihuman_est = b.ihuman_est and t.iitem <> 'I060') as mest_ori,  \
              (select max(iins_type) from ca_human_ins mmm where mmm.ihuman_est = b.ihuman_est and mmm.iins_type in ('93','94','95','193','194','195')) as iins_type,   \
              (case (select flevel from cm_clm_adjuster where empl_no = b.iatone) when '1' then '����' when '2' then '���' when '3' then '����' when '4' then '����' else ' ' end) as flevel, \
              (case when b.iapprove = 'NA' then 'Y' else 'N' end) as item, \
              decode(b.fhurt,'1','���','2','���`',' ') as fhurt \
         from sysdb:ca_clm_process a,sysdb:ca_human_est b \
        where a.iclaim = b.iclaim \
          and a.iclaim in (select iclaim1 from bbb) \
          and b.ihuman_est in (select zz.ihuman_est         \
                                 from sysdb:ca_human_ins zz, sysdb:ca_sign_receipt rr \
                                where zz.ihuman_est = b.ihuman_est \
                                  and zz.iins_type in ('93','94','95','193','194','195') \
                                  and zz.isign = rr.isign   \
                                  and rr.iclaim = a.iclaim  \
                                  and exists (select *      \
                                                from bbb    \
                                               where iclaim1 = rr.iclaim   \
                                                 and iclose_type = rr.iclose_type)  \
                              )    \
         into temp car836_tmp3 with no log ");
    $prepare main_id4 from $sStmt;
    $execute main_id4;

    return M_CM_OK;

errexit:
   printf("car836_body ==> SQLCODE:[%ld][%s] \n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   printf("   end EWRITE \n");
   return SQLCODE;
}

long car836_print()
{
   $char stmt[4096], stmt1[1024], stmt2[1024];
   $long qorder;
   int i,x,j,k;
   $int COUNT;
   $char sfilename[31];
   $char stitle[10000];
   $char ssql[10000];
   $char dyearmonth_tmp[7];
   $char title_tmp[101];
   $char title_tmp0[101];
   $char title_tmp1[101];
   $char title_tmp2[101];
   $char filed[20][15];
   $char sqltmp[1024];
   $char filed_tmp[200];
   $char sErrmsg[100];
   $int  rc;

   $WHENEVER ERROR goto errexit;
   $SET LOCK MODE TO WAIT;


   strcpy(sfilename,"�ˮ`�I�M�ѷl�����Ӫ�");

   strcpy(stitle,"�έp����G");
   strcat(stitle, sBgnDate_e);
   strcat(stitle, " ~ ");
   strcat(stitle, sEndDate_e);
   strcat(stitle,"\n\t�߮׸��X\t���z���\t�J�p���\t�z�ߤH��ID\t�z�ߤH��\t�z�ߤH�����\t�Ҧb�a\t���`�HID\t�M�Ѳz�ߤH��ID\t�M�Ѳz�ߤH��\t�M�Ѳz�ߤH�����\t�P���`�H�M�Ѥ��\t�l��������\t�D�ޮ֭��\t�ߴڪ��B\t�t�]�l�l�����B(�t�j���I)\t�I�ؤ��t���B\t���|�Ѽ�\t�l���s��\t�����O\tñ�����\t��I���\t���t�]�l��l�l�����B\t�I��\t�z�ߤH���h��\t�L�׼з�\t�ˤ`�O\t");

   strcpy(ssql, " select * from car836_tmp3 order by 1 ");

   rc = unload_file(outputf," ",sfilename,stitle,ssql);

   if (rc != SUCCESS)
   {
       if (rc == 3501)
       {
          sprintf_s(sErrmsg,100," ��J���^������䤣���� ",sfilename);
       }
       else
       {
          sprintf_s(sErrmsg,100," %s �ɮ׵L�k���� ",sfilename);
       }

       EWRITE(userid, rc , sErrmsg);
       exit(1);
   }

   return M_CM_OK;

errexit:
  printf("SQL=[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(1);

}

int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
short mdy1[3], mdy2[3];
int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
    return datediff;
}

