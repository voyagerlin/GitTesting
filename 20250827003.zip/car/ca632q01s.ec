/**********************************************************************/
/*   program id   : ca632q01s.ec                                      */
/*   program name : ���w�r�p�H����                                    */
/*   date written : 2012/09/27                                        */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "globdata.h"

int   count_db;
$char dbgn[11], dend[11];
$char iofficer[11],nequipment[31],chkopt[2];
char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];
char opt_rpt[2],sdate1[11], sdate2[11];
char opt_cnt1[3], opt_cnt2[3], opt_cnt3[3], opt_cnt4[3];
char opt_getchk1[41], opt_getchk2[41], opt_getchk3[41], opt_getchk4[41],opt_getchk5[41];
int  iopt_rpt;
$char sDate_bgn[11], sDate_end[11];
int iopt_cnt1,iopt_cnt2,iopt_cnt3,iopt_cnt4, i,k;
$char sTmpstr[8000], sTmpsql1[1000], sTmpsqlB[2000],sTmpsqlC[1000],
      sTmpsqlR[1000], sTmpsqlN[1000], sBranch[3], sopt_Cartype[200], 
      sopt_Brand[200], sopt_Route[200];
DBinfo *list;

$char stmt_tmp[2048];
/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;

    batchinit();
    strcpy(DBName,    		isNULLstr(argv[1]));
    strcpy(userid,    		isNULLstr(argv[2]));
    strcpy(opt_rpt,   		isNULLstr(argv[3]));	/* �����O 0:���Ӫ�, 1:�Ұϲέp�� 2:�g�P�Ӳέp�� */
    strcpy(sdate1,    		isNULLstr(argv[4]));	/* �d�߰_�� CYY/MM/DD */
    strcpy(sdate2,    		isNULLstr(argv[5]));	/* �d�ߨ��� CYY/MM/DD */
    strcpy(opt_cnt1,    	isNULLstr(argv[6]));	/* �ҰϧO�Ӽ� */
    strcpy(opt_getchk1,   isNULLstr(argv[7]));	/* �ҰϧO�N�� */
    strcpy(opt_cnt2,    	isNULLstr(argv[8]));	/* �t�P�O�Ӽ� */
    strcpy(opt_getchk2,   isNULLstr(argv[9]));	/* �t�P�O�N�� */
    strcpy(opt_cnt3,    	isNULLstr(argv[10]));	/* ���اO�Ӽ� */
    strcpy(opt_getchk3,   isNULLstr(argv[11]));	/* ���اO�N�� */
    strcpy(opt_cnt4,    	isNULLstr(argv[12]));	/* �q���O�Ӽ� */
    strcpy(opt_getchk4,   isNULLstr(argv[13]));	/* �q���O�N�� */
    strcpy(opt_getchk5,   isNULLstr(argv[14]));	/* �I�اO�N�� */
    strcpy(outputf,   		isNULLstr(argv[15]));	

    rc = car632_get_db();
    if (rc != M_CM_OK)
       return rc;
       
    rc = car632_temp_table();
    if (rc != M_CM_OK)
       return rc;
       
    iopt_rpt = atoi(opt_rpt);    

    rc = car632_Condition();
    if (rc != M_CM_OK)
       return rc;
      
		switch (iopt_rpt)
		{
			case 0:
				/* ���Ӫ� */
				printf("--------- ���Ӫ� ------------------\n");
				rc = car632_prepare_data_0();
    		if (rc != M_CM_OK)  return rc;

    		rc = car632_build_0();
    		if (rc != M_CM_OK)  return rc;
				break;
				
			case 1:
				/* �Ұϲέp�� */
				printf("--------- �Ұϲέp�� ------------------\n");
				rc = car632_prepare_data_1();
    		if (rc != M_CM_OK)  return rc;

    		rc = car632_build_1();
    		if (rc != M_CM_OK)  return rc;
				break;
				
			case 2:
				/* �g�P�Ӳέp�� */
				printf("--------- �g�P�Ӳέp�� ------------------\n");
				rc = car632_prepare_data_2();
    		if (rc != M_CM_OK)  return rc;

    		rc = car632_build_2();
    		if (rc != M_CM_OK)  return rc;
				break;
			
		}
}
/*--------------------------------------------------------------------*/
long car632_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
         return M_CM_NOT_DBLIST;
   }
   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car632_temp_table()
{
		$whenever sqlerror goto errexit;
		/*	group2		char(10),		-- �ҰϥN��\
			nlevel2		char(20),		-- �ҰϦW��\
			group3		char(10),		-- ���(��)�N��\
			nlevel4		char(20),		-- ���(��)\
			iquota		char(10),		-- ���O\
			nbranch		char(10),		-- ���O�W��\
			iofficer	char(10),		-- �g��N��\
			nname1    char(20),		-- �g��W��\
			ileader 	char(10),		-- �޲z�H�N��\
			nname2		char(20),		-- �޲z�H�W��\
			dpolicy		char(10),		-- ñ���\
			ipolicy		char(20),		-- �O�渹\
			itag			char(%d),		-- ����\
			ibrand		char(10),		-- �t�P�����N��\
			nbrand		char(60),		-- �t�P�W��\
			nfclass		char(10),		-- ���t\
			nassured	char(120),	-- �Q�O�I�H\
			icar_type	char(3),		-- ����\
			dply_begin	char(10),	-- �O�I�_��\
			dply_end		char(10),	-- �O�I����\
			iins_type	char(6),		-- �I�إN��\
			provision	char(10),		-- ���ڥN��\
			qprovision	int,			-- ���w�r�p�H��\
			minjured_cover  int,	-- ��˫O�B\
			mdeath_cover		int,	-- ���`�O�B\
			mdamage_cover   int,	-- �ƬG�O�B\
			mins_premium		int,	-- ñ��O�O\
			iroute		char(10),		-- �q���N��\
			nroute		char(20)		-- �q���W��\*/
            /* 1081225006-SC1-���ά�-�X�R���[���ڥN�X */
		sprintf(stmt_tmp,"create temp table tb_6321\
		(\
			group2		char(10),	\
			nlevel2		char(20),	\
			group3		char(10),	\
			nlevel4		char(20),	\
			iquota		char(10),	\
			nbranch		char(10),	\
			iofficer	char(10),	\
			nname1          char(20),	\
			ileader 	char(10),	\
			nname2		char(20),	\
			dpolicy		char(10),	\
			ipolicy		char(20),	\
			itag		char(%d),	\
			ibrand		char(10),	\
			nbrand		char(60),	\
			nfclass		char(10),	\
			nassured	char(120),	\
			icar_type	char(3),	\
			dply_begin	char(10),	\
			dply_end	char(10),	\
			iins_type	char(6),	\
			provision	char(20),	\
			qprovision	int,		\
			minjured_cover  int,		\
			mdeath_cover	int,		\
			mdamage_cover   int,		\
			mins_premium	int,		\
			iroute		char(10),	\
			nroute		char(20),	\
			nlast_ply       char(5)        \
		)with no log;",CA_TAG_NUM-1);
                $PREPARE stmp FROM $stmt_tmp;
                $EXECUTE stmp;
		
		$create temp table tb_6322
		(
			group2		char(10),		-- �ҰϥN��
			nlevel2		char(20),		-- �Ұ�
			group3		char(10),		-- ���(��)�N��
			nlevel4		char(20),		-- ���(��)
			premium1		int,			-- ñ��O�O(�A��+D)
			ply_cnt1		int, 			-- ���(�A��+D)
			premium2		int,			-- ñ��O�O(�A��)
			ply_cnt2		int, 			-- ���(�A��)
			rate_prem		decimal(5,2),	-- ��O�v(�O�O)
			rate_cnt		decimal(5,2),	-- ��O�v(���)
			seq					char(2)					-- �Ǹ�
			)with no log; 
			
		
		$create temp table tb_6323
		(
			iroute1			char(12),		-- �g�P�ӥN��
			niroute1		char(20),		-- �g�P�ӦW��
			iroute2			char(12),		-- �g�P�Ӱϳ��N��
			niroute2		char(20),		-- �g�P�Ӱϳ��W��
			iroute3			char(10),		-- �g�P�Ӿ��I�N��
			niroute3		char(20),		-- �g�P�Ӿ��I�W��
			premium1		int,				-- ñ��O�O(�A��+D)
			ply_cnt1		int, 				-- ���(�A��+D)
			premium2		int,				-- ñ��O�O(�A��)
			ply_cnt2		int, 				-- ���(�A��)
			rate_prem		decimal(5,2),	-- ��O�v(�O�O)
			rate_cnt		decimal(5,2),	-- ��O�v(���)
			seq					char(2)	default ' '				-- �Ǹ�
			)with no log; 

   $delete from tb_6321 where 1=1;
   $delete from tb_6322 where 1=1;
   $delete from tb_6323 where 1=1;
   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/* --------------------------------------------------------------------- */
/*--------------------------------------------------------------------*/
long car632_Condition()
{
		$whenever sqlerror goto errexit;
		
		strcpy(sDate_bgn,cm_to_infdate(sdate1));	/* �d�߰_�� */
  	strcpy(sDate_end,cm_to_infdate(sdate2));	/* �d�ߨ��� */
		printf("sDate_bgn=[%s] sDate_end=[%s] \n",sDate_bgn,sDate_end);	
		
		/* �t�P�O --------------------------------------------------------------- */
		iopt_cnt2 = atoi(opt_cnt2);
		sTmpsqlB[0] = '\0';
		printf("iopt_cnt2=[%d]opt_getchk2=[%s]\n",iopt_cnt2,opt_getchk2);
  	for(i=0;i<iopt_cnt2;i++)
		{
			if (i == 0)
				strcpy(sopt_Brand, "'");
			else
				strcat(sopt_Brand, ",'");
		
			strcat(sopt_Brand, substring(opt_getchk2,(1+2*i),2));
			strcat(sopt_Brand, "'");
		}
		printf("sopt_Brand[%s]\n", sopt_Brand);
	
		if (strstr(sopt_Brand,"BZ"))
		{
			sprintf(sTmpsqlB, 
			"select unique ibrand,nbrand_eng,icar_series from ca_car_model a \
        where a.ipro_year = (select max(ipro_year) from ca_car_model \
                              where ibrand = a.ibrand) \
          and ((a.ibrand[1,2] in (select detail2 from car_code where kind = 'DB' \
                 and detail in (%s)) or a.ibrand[1,4] in (select detail2 \
                 from car_code where kind = 'DB' and detail in (%s))) \
            or ( a.ibrand[1,2] not in (select detail2 from car_code where kind = 'DB' \
                 and detail <> 'BZ') and a.ibrand[1,4] not in (select detail2 from \
                 car_code where kind = 'DB' and detail <> 'BZ'))) \
          into temp tmp_brand	", sopt_Brand,sopt_Brand);             
		}
		else
		{
			sprintf(sTmpsqlB,
			"select unique ibrand,nbrand_eng,icar_series from ca_car_model a \
        where a.ipro_year = (select max(ipro_year) from ca_car_model \
                            where ibrand = a.ibrand) \
		      and (( a.ibrand[1,2] in (select detail2 from car_code where kind = 'DB' \
	               and detail in (%s)) or a.ibrand[1,4] in (select detail2 \
	               from car_code where kind = 'DB' and detail in (%s)))) \
				 into temp tmp_brand",sopt_Brand,sopt_Brand);
		}
		printf("sTmpsqlB=[%s]\n",sTmpsqlB);
		$PREPARE pre_brand0 FROM $sTmpsqlB;
		$EXECUTE pre_brand0;
	
		/* ���اO ----------------------------------------------------------------- */
		iopt_cnt3 = atoi(opt_cnt3);
		sTmpsqlC[0] = '\0';
		printf("iopt_cnt3=[%d]opt_getchk3=[%s]\n",iopt_cnt3,opt_getchk3);
  	for(i=0;i<iopt_cnt3;i++)
		{
			if (i == 0)
				strcpy(sopt_Cartype, "'");
			else
				strcat(sopt_Cartype, ",'");

			strcat(sopt_Cartype, substring(opt_getchk3,(1+2*i),2));
			strcat(sopt_Cartype, "'");
		}
		printf("sopt_Cartype[%s]\n", sopt_Cartype);
		if (strstr(sopt_Cartype,"CZ"))
		{
			sprintf(sTmpsqlC,
	   	"select icode,ncode from car_type a where fclass = '1' \
	       and (a.icode in (select detail2 from car_code where kind = 'DC' \
	               and detail in (%s)) \
	            or a.icode not in (select detail2 from car_code \
	                where kind = 'DC' and detail <> 'CZ')) \
	      into temp tmp_car_type",sopt_Cartype);
		}
		else
		{
			sprintf(sTmpsqlC,
	   	"select icode,ncode from car_type a where fclass = '1' \
	       and ( a.icode in (select detail2 from car_code where kind = 'DC' \
	           and detail in (%s))) into temp tmp_car_type ",sopt_Cartype);         
		}
		printf("sTmpsqlC=[%s]\n",sTmpsqlC);
		$PREPARE pre_crtype0 FROM $sTmpsqlC;
		$EXECUTE pre_crtype0;
	
		/* �q���O ----------------------------------------------------------------- */
		iopt_cnt4 = atoi(opt_cnt4);
		sTmpsqlR[0] = '\0';
		printf("iopt_cnt4=[%d]opt_getchk4=[%s]\n",iopt_cnt4,opt_getchk4);
		
		for(i=0;i<iopt_cnt4;i++)
		{
			if (i == 0)
				strcpy(sopt_Route, "'");
			else
				strcat(sopt_Route, ",'");
			
			strcat(sopt_Route, substring(opt_getchk4,(1+2*i),2));
			strcat(sopt_Route, "'");
		}
		printf("sopt_Route[%s]\n", sopt_Route);
		
		if (iopt_rpt == 2)
		{
			/* �g�P�� */
			if (strstr(sopt_Route,"RZ"))
			{
				sprintf(sTmpsqlR,
			   "select x1.iroute_dim2 as iroute_dim2, x2.ncode as nroute_dim2, \
		             CASE  WHEN (x1.iroute = 'CAC0F' )  THEN 'CAC0G'  ELSE x1.iroute END as iroute1, \
		             x1.nroute as nroute1, \
		             CASE WHEN (NVL (x5.iorganize ,' ' )= ' ' ) THEN x5.iroute ELSE x5.iorganize  END as iroute2, \
		             CASE WHEN (NVL (x5.iorganize ,' ' )= ' ' )  THEN x5.nroute  ELSE x4.ncode  END  as nroute2, \
		             x5.iroute as iroute3, x5.nroute as nroute3 \
		        from cm_route x1 , cu_code_data x2 ,cu_code_data x4 ,cm_route x5 \
		       where x2.icode = x1.iroute_dim2 AND x4.icode = x5.iorganize \
		         AND x1.iroute = x5.iroute_main  AND x1.fmain = 'Y' \
		         AND x2.itype = 'E1'  AND x4.itype = 'E3' \
		         AND (x1.iroute_dim2 in \
		             (select detail2 from car_code where kind = 'DR' and detail in (%s)) \
		                  or x1.iroute_dim2 not in \
		             (select detail2 from car_code where kind = 'DR' and detail <> 'RZ')) \
			               into temp tmp_route ",sopt_Route);
			}
			else
			{
			  sprintf(sTmpsqlR,
			  "select x1.iroute_dim2 as iroute_dim2, x2.ncode as nroute_dim2, \
		             CASE  WHEN (x1.iroute = 'CAC0F' )  THEN 'CAC0G'  ELSE x1.iroute END as iroute1, \
		             x1.nroute as nroute1, \
		             CASE WHEN (NVL (x5.iorganize ,' ' )= ' ' ) THEN x5.iroute ELSE x5.iorganize  END as iroute2, \
		             CASE WHEN (NVL (x5.iorganize ,' ' )= ' ' )  THEN x5.nroute  ELSE x4.ncode  END  as nroute2, \
		             x5.iroute as iroute3, x5.nroute as nroute3 \
		        from cm_route x1 , cu_code_data x2 ,cu_code_data x4 ,cm_route x5  \
		       where x2.icode = x1.iroute_dim2  AND x4.icode = x5.iorganize \
		         AND x1.iroute = x5.iroute_main  AND x1.fmain = 'Y'  \
		         AND x2.itype = 'E1'  AND x4.itype = 'E3' \
		         and ( x1.iroute_dim2 in (select detail2 from car_code where kind = 'DR' \
			             and detail in (%s))) into temp tmp_route ",sopt_Route);
			}
		}
		else
		{
			if (strstr(sopt_Route,"RZ"))
			{
				sprintf(sTmpsqlR,
		   	" select a.iroute, a.nroute from cm_route a, cm_route b where 1=1 \
		        and a.iroute_main = b.iroute and (b.iroute_dim2 in \
		               (select detail2 from car_code where kind = 'DR' and detail in (%s)) \
		             or b.iroute_dim2 not in \
		               (select detail2 from car_code where kind = 'DR' and detail <> 'RZ')) \
		       into temp tmp_route ",sopt_Route);
			}
			else
			{
		  	sprintf(sTmpsqlR,
		   	" select a.iroute, a.nroute from cm_route a, cm_route b where 1=1 \
		        and a.iroute_main = b.iroute \
		        and ( b.iroute_dim2 in (select detail2 from car_code where kind = 'DR' \
		              and detail in (%s))) into temp tmp_route ",sopt_Route);
			}
		}
		printf("sTmpsqlR=[%s]\n",sTmpsqlR);
		$PREPARE pre_route0 FROM $sTmpsqlR;
		$EXECUTE pre_route0;
	
		/* �I�إN�� ------------------------------------------------------------*/
		strcpy(opt_getchk5, trim(opt_getchk5));
		if (strcmp(opt_getchk5, "NZ") == 0)
			strcpy(sTmpsqlN, "");
		else
			sprintf(sTmpsqlN, " and c.iins_type in (select detail2 from car_code \
			                    where kind = 'DN' and detail = '%s') ", opt_getchk5); 
		
   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car632_prepare_data_0()
{

	printf("-------- start car632_prepare_data_0() --------------------------- \n");  
	$whenever sqlerror goto errexit;

	iopt_cnt1 = atoi(opt_cnt1); 	
	for(k=0;k<iopt_cnt1;k++)
	{
		strcpy(sBranch, substring(opt_getchk1,(1+2*k),2));
		printf("sBranch=[%s]\n",sBranch);
        /* 1081225006-SC1-���ά�-�X�R���[���ڥN�X �ɤW�������� */
    sprintf(sTmpstr,
			" insert into tb_6321 \
				select g.group2, (select ncode from cu_code_data where itype = '19' \
				       and icode = g.group2), g.group3, (select ncode from cu_code_data \
				       where itype = '20' and icode = g.group3), a.iquota, g.nbranch, a.iofficer, \
				       e.nname, a.ileader, f.nname, a.dpolicy, a.ipolicy, b.itag, \
				       a.ibrand, h.nbrand_eng, decode(h.icar_series,'10','�겣','�i�f'), \
               b.nassured, a.icar_type, a.dply_begin, a.dply_end, c.iins_type, \
               c.provision, a.qprovision, c.minjured_cover, c.mdeath_cover, c.mdamage_cover, \
               c.mins_premium, b.iroute, d.nroute ,\
               case when length(trim(a.ilast_ply)) > 0 then '��O' else '�s�O' end \
				  from %s:ply_relation a, %s:policy b, %s:ply_ins_type c, \
               tmp_route d, officer e, officer f,  sa_branch_type g, \
               tmp_brand h, tmp_car_type m \
         where a.ipolicy = b.ipolicy and a.ipolicy = c.ipolicy \
           and b.ipolicy = c.ipolicy and b.iroute = d.iroute \
           and a.iofficer = e.iofficer and a.ileader = f.iofficer \
           and a.iquota = g.ibranch  and a.ibrand = h.ibrand and a.icar_type = m.icode \
           and a.dpolicy between '%s' and '%s' \
           and a.dply_close is not null \
           and a.fcard_class = '2' and trim(c.provision)||';' matches '*D;*' %s ", 
           get_full_dbname(sBranch), get_full_dbname(sBranch), 
           get_full_dbname(sBranch), sDate_bgn, sDate_end, sTmpsqlN);
          
			printf("sTmpstr=[%s]\n",sTmpstr);
		 
			$PREPARE pre_0 FROM $sTmpstr;
			$EXECUTE pre_0;
	 }
		return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car632_build_0()
{
		int rc;
    char    sfilename[81],stitle[1024],stmt[1024];
    
    $WHENEVER SQLERROR GOTO errexit;

		printf("-------- start car632_build_0() --------------------------- \n");  
    strcpy(sfilename,"���w�r�p�H����_���Ӫ�[CAR632]");
    strcpy(stitle,"\t�{���N��:CAR632\t���w�r�p�H����_���Ӫ�\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    
    strcat(stitle,"\tñ����:");
    strcat(stitle,sdate1);
    strcat(stitle,"��");
    strcat(stitle,sdate2);
    strcat(stitle,"\n");

    strcat(stitle,"\t�Ұ�\t���(��)\t�g��N��\t�g��W��\t�޲z�H�N��\t");
    strcat(stitle,"�޲z�H�W��\tñ���\t�O�渹\t����\t�t�P�����N��\t�t�P�W��\t");
    strcat(stitle,"���t\t�Q�O�I�H\t����\t�O�I�_��\t�O�I����\t�I�إN��\t");
    strcat(stitle,"���ڥN��\t���r�H��\t��˫O�B\t���`�O�B\t�ƬG�O�B\tñ��O�O\t�q���N��\t");
    strcat(stitle,"�q���W��\t�s��O�O\t");
    
    sprintf(stmt,"select nlevel2, nlevel4, iofficer, nname1, ileader, \
                        nname2, dpolicy, ipolicy, itag, ibrand, nbrand, nfclass, \
                        nassured, icar_type, dply_begin, dply_end, iins_type, \
                        provision, qprovision, minjured_cover, mdeath_cover, mdamage_cover, \
                        mins_premium, iroute, nroute, nlast_ply from tb_6321 \
                        where 1=1 order by group2, group3, iquota, iofficer ");
  
    rc = unload_file(outputf," ",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
        sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
/* �Ұϲέp */
long car632_prepare_data_1()
{
  printf("-------- car632_prepare_data_1 --------------------------- \n");  

	$whenever sqlerror goto errexit;
	
	iopt_cnt1 = atoi(opt_cnt1); 	
	for(k=0;k<iopt_cnt1;k++)
	{
		strcpy(sBranch, substring(opt_getchk1,(1+2*k),2));
		printf("sBranch=[%s]\n",sBranch);
    sprintf(sTmpstr,
			" insert into tb_6321 \
				select g.group2, (select ncode from cu_code_data where itype = '19' \
				       and icode = g.group2), g.group3, (select ncode from cu_code_data \
				       where itype = '20' and icode = g.group3), a.iquota, g.nbranch, a.iofficer, \
				       e.nname, a.ileader, f.nname, a.dpolicy, a.ipolicy, b.itag, \
				       a.ibrand, h.nbrand_eng, decode(h.icar_series,'10','�겣','�i�f'), \
               b.nassured, a.icar_type, a.dply_begin, a.dply_end, c.iins_type, \
               c.provision, a.qprovision, c.minjured_cover, c.mdeath_cover, c.mdamage_cover, \
               c.mins_premium, b.iroute, d.nroute, \
               case when length(trim(a.ilast_ply)) > 0 then '��O' else '�s�O' end \
				  from %s:ply_relation a, %s:policy b, %s:ply_ins_type c, \
               tmp_route d, officer e, officer f,  sa_branch_type g, \
               tmp_brand h, tmp_car_type m \
         where a.ipolicy = b.ipolicy and a.ipolicy = c.ipolicy \
           and b.ipolicy = c.ipolicy and b.iroute = d.iroute \
           and a.iofficer = e.iofficer and a.ileader = f.iofficer \
           and a.iquota = g.ibranch  and a.ibrand = h.ibrand and a.icar_type = m.icode \
           and a.dpolicy between '%s' and '%s'  %s \
           and a.dply_close is not null and a.fcard_class = '2' ", 
           get_full_dbname(sBranch), get_full_dbname(sBranch), 
           get_full_dbname(sBranch), sDate_bgn, sDate_end,sTmpsqlN);
          
			printf("sTmpstr=[%s]\n",sTmpstr);
		 
			$PREPARE pre_1 FROM $sTmpstr;
			$EXECUTE pre_1;
	 }
	
	/* �έp�� */
	/* $insert into tb_6322 */
	printf("------- insert into tb_6322 ----------------------------- \n");
     /*  1081225006-SC1-���ά�-�X�R���[���ڥN�X �ɤW��������*/
  $insert into tb_6322
    select group2, nlevel2, group3, nlevel4, 
          sum(case when trim(provision)||';' matches '*D;*' then mins_premium else 0 end),
          sum(case when trim(provision)||';' matches '*D;*' and mdamage_cover > 0 then 1 else 0 end),
          sum(mins_premium), 
          sum(case when mdamage_cover > 0 then 1 else 0 end),
          case when sum(mins_premium) = 0 then 0 else
          	round((sum(case when trim(provision)||';' matches '*D;*' then mins_premium else 0 end)/sum(mins_premium)) * 100,2) end ,
          case when sum(case when mdamage_cover > 0 then 1 else 0 end) = 0 then 0 else
          	round(((sum(case when trim(provision)||';' matches '*D;*' and mdamage_cover > 0 then 1 else 0 end)/sum(case when mdamage_cover > 0 then 1 else 0 end)) * 100),2) end , '1' 
     from tb_6321
     group by group2, nlevel2,	group3, nlevel4;
	
	printf("------- insert into tb_6322 (group by �X�p)----------------------------- \n");
	$insert into tb_6322
   select group2, nlevel2,	' ', ' ',
          sum(premium1),
          sum(ply_cnt1),
          sum(premium2), 
          sum(ply_cnt2),
          case when sum(premium2) = 0 then 0 else
          	round((sum(premium1)/sum(premium2)*100),2) end,
          case when sum(ply_cnt2) = 0 then 0 else
          	round((sum(ply_cnt1)/sum(ply_cnt2)*100),2) end ,'9'
     from tb_6322
     group by group2,nlevel2;
     
	return M_CM_OK;


errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car632_build_1()
{
   	int rc;
    char    sfilename[81],stitle[1024],stmt[1024];
    
    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"���w�r�p�H����_�Ұϲέp��[CAR632]");
    strcpy(stitle,"\t�{���N��:CAR632\t���w�r�p�H����_�Ұϲέp��\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    
    strcat(stitle,"\tñ����:");
    strcat(stitle,sdate1);
    strcat(stitle,"��");
    strcat(stitle,sdate2);
    strcat(stitle,"\n");

    strcat(stitle,"\t�Ұ�\t���(��)\t�I�ثO�O(�A+D)\t�I�إ��(�A+D)\t�I�ثO�O(�A)\t");
    strcat(stitle,"�I�إ��(�A)\t��O�v(%)_�I�ثO�O\t��O�v(%)_�I�إ��\t");
    sprintf(stmt,"select decode(seq,'9',trim(nlevel2)||' �X�p',nlevel2),nlevel4, \
                         premium1,ply_cnt1,premium2,ply_cnt2,rate_prem,rate_cnt \
                   from tb_6322 order by group2,seq,group3 ");
  
    rc = unload_file(outputf," ",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
        sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
/* �g�P�Ӳέp */
long car632_prepare_data_2()
{
	$whenever sqlerror goto errexit;

	iopt_cnt1 = atoi(opt_cnt1); 	
	for(k=0;k<iopt_cnt1;k++)
	{
		strcpy(sBranch, substring(opt_getchk1,(1+2*k),2));
		printf("sBranch=[%s]\n",sBranch);
    sprintf(sTmpstr,
			" insert into tb_6321 \
				select d.iroute1, d.nroute1, d.iroute2, d.nroute2, d.iroute3, d.nroute3,\
				       a.iofficer, e.nname, a.ileader, f.nname, a.dpolicy, a.ipolicy, b.itag, \
				       a.ibrand, h.nbrand_eng, decode(h.icar_series,'10','�겣','�i�f'), \
               b.nassured, a.icar_type, a.dply_begin, a.dply_end, c.iins_type, \
               c.provision, a.qprovision, c.minjured_cover, c.mdeath_cover, c.mdamage_cover, \
               c.mins_premium, b.iroute, d.nroute3 ,\
               case when length(trim(a.ilast_ply)) > 0 then '��O' else '�s�O' end \
				  from %s:ply_relation a, %s:policy b, %s:ply_ins_type c, \
               tmp_route d, officer e, officer f,  sa_branch_type g, \
               tmp_brand h, tmp_car_type m \
         where a.ipolicy = b.ipolicy and a.ipolicy = c.ipolicy \
           and b.ipolicy = c.ipolicy and b.iroute = d.iroute3 \
           and a.iofficer = e.iofficer and a.ileader = f.iofficer \
           and a.iquota = g.ibranch  and a.ibrand = h.ibrand and a.icar_type = m.icode \
           and a.dpolicy between '%s' and '%s' %s \
           and a.dply_close is not null and a.fcard_class = '2' ", 
           get_full_dbname(sBranch), get_full_dbname(sBranch), 
           get_full_dbname(sBranch), sDate_bgn, sDate_end, sTmpsqlN);
          
			printf("sTmpstr=[%s]\n",sTmpstr);
		 
			$PREPARE pre_2 FROM $sTmpstr;
			$EXECUTE pre_2;
	 }
	printf("------- insert into tb_6323  ----------------------------- \n");
  $insert into tb_6323
    select group2, nlevel2,	group3,  nlevel4, iquota, nbranch,
          sum(case when trim(provision)||';' matches '*D;*' then mins_premium else 0 end), 
          sum(case when trim(provision)||';' matches '*D;*' and mdamage_cover > 0 then 1 else 0 end), 
          sum(mins_premium),  
          sum(case when mdamage_cover > 0 then 1 else 0 end), 
          case when sum(mins_premium) = 0 then 0 else
          	round((sum(case when trim(provision)||';' matches '*D;*' then mins_premium else 0 end)/sum(mins_premium)) * 100,2) end, 
          case when sum(case when mdamage_cover > 0 then 1 else 0 end) = 0 then 0 else
          	round(((sum(case when trim(provision)||';' matches '*D;*' and mdamage_cover > 0 then 1 else 0 end)/sum(case when mdamage_cover > 0 then 1 else 0 end)) * 100),2) end, '1' 
     from tb_6321
     group by group2, nlevel2,	group3, nlevel4, iquota, nbranch ;
  
  printf("------- insert into tb_6323  (group by �g�P�Ӥp�p)----------------------------- \n");
	$insert into tb_6323
   select iroute1, niroute1,iroute2, niroute2, ' ', ' ',
          sum(premium1),
          sum(ply_cnt1),
          sum(premium2), 
          sum(ply_cnt2),
          case when sum(premium2) = 0 then 0 else
          	round((sum(premium1)/sum(premium2)*100),2) end,
          case when sum(ply_cnt2) = 0 then 0 else
          	round((sum(ply_cnt1)/sum(ply_cnt2)*100),2) end,'5'
     from tb_6323
     group by iroute1,niroute1, iroute2, niroute2;
     
	printf("------- insert into tb_6323  (group by �X�p)----------------------------- \n");
	$insert into tb_6323
   select iroute1, niroute1, "Z"||iroute1, ' ', ' ', ' ',
          sum(premium1),
          sum(ply_cnt1),
          sum(premium2), 
          sum(ply_cnt2),
          case when sum(premium2) = 0 then 0 else
          	round((sum(premium1)/sum(premium2)*100),2) end,
          case when sum(ply_cnt2) = 0 then 0 else
          	round((sum(ply_cnt1)/sum(ply_cnt2)*100),2) end,'9'
     from tb_6323
    where seq = '1'
     group by iroute1,niroute1,3;
     
	return M_CM_OK;


errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car632_build_2()
{
		int rc;
    char    sfilename[81],stitle[1024],stmt[1024];
    
    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"���w�r�p�H����_�g�P�Ӳέp��[CAR632]");
    strcpy(stitle,"\t�{���N��:CAR632\t���w�r�p�H����_�g�P�Ӳέp��\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    
    strcat(stitle,"\tñ����:");
    strcat(stitle,sdate1);
    strcat(stitle,"��");
    strcat(stitle,sdate2);
    strcat(stitle,"\n");

    strcat(stitle,"\t�g�P��\t�ϳ�\t���I�O\t�I�ثO�O(�A+D)\t�I�إ��(�A+D)\t�I�ثO�O(�A)\t");
    strcat(stitle,"�I�إ��(�A)\t��O�v(%)_�I�ثO�O\t��O�v(%)_�I�إ��\t");
    
    strcpy(stmt, "select case when seq = '9' then trim(niroute1)||' �X�p' else niroute1 end, \
                         case when seq = '5' then trim(niroute2)||' �p�p' \
                              when seq = '9' then ' ' else niroute2 end, \
                         niroute3,premium1,ply_cnt1,premium2,ply_cnt2, rate_prem,rate_cnt \
                   from tb_6323 order by iroute1,iroute2,seq, iroute3 ");
                   
    /* strcpy(stmt,"select decode(seq,'9',trim(niroute1)||' �X�p',niroute1),\
                        niroute2,niroute3,premium1,ply_cnt1,premium2,ply_cnt2, \
                        rate_prem,rate_cnt \
                   from tb_6323 order by iroute1,seq,iroute2,iroute3 "); */
  
    rc = unload_file(outputf," ",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
        sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}
/* 
------ ���� -----------------------------------------------------------------------------------
select icode,ncode from car_type where fclass = '1'
and ( icode in (select detail2 from car_code where kind = 'DC' and detail in ('CZ','CZ'))
     or icode not in
        (select detail2 from car_code where kind = 'DC' and detail <> 'CZ'));
       
------ �t�P -----------------------------------------------------------------------------------
select unique ibrand[1,4] from ca_car_model where 1=1
and (( ibrand[1,2] in (select detail2 from car_code where kind = 'DB' and detail in ('B1','BZ'))
        or ibrand[1,4] in (select detail2 from car_code where kind = 'DB' and detail in ('B1','BZ')))
  or ( ibrand[1,2] not in (select detail2 from car_code where kind = 'DB' and detail <> 'BZ')
       and ibrand[1,4] not in (select detail2 from car_code where kind = 'DB' and detail <> 'BZ')))

------ �q���O -----------------------------------------------------------------------------------
select level2, nlevel2, count(*) from v_route where 1=1 
   and (level2 in (select detail2 from car_code where kind = 'DR' and detail in ('R1','R2','RZ'))
     or level2 not in
        (select detail2 from car_code where kind = 'DR' and detail <> 'RZ')); 
        
----- �g�P�� -----------------------------------------------------------------------
select x1.iroute_dim2, 
       x2.ncode, 
       CASE  WHEN (x1.iroute = 'CAC0F' )  THEN 'CAC0G'  ELSE x1.iroute END ,
       x1.nroute, 
       CASE WHEN (NVL (x5.iorganize ,' ' )= ' ' ) THEN x5.iroute ELSE x5.iorganize  END ,
       CASE WHEN (NVL (x5.iorganize ,' ' )= ' ' )  THEN x5.nroute  ELSE x4.ncode  END ,
       x5.iroute, 
       x5.nroute
  from cm_route x1 , cu_code_data x2 ,cu_code_data x4 ,cm_route x5 
 where x2.icode = x1.iroute_dim2
   AND x4.icode = x5.iorganize
   AND x1.iroute = x5.iroute_main
   AND x1.fmain = 'Y' 
   AND x2.itype = 'E1'
   AND x4.itype = 'E3'
   AND x1.iroute_dim2 = 'CA01'
   
iroute_dim2   CA01
ncode         ��t������
(expression)  CAA0B
nroute        ����
(expression)  CAB02
(expression)  �_�ϤG
iroute        CAA0B01012
nroute        ���ץx�_
*/
