/* Copyright (C) 2001 Intellisys Corporation
 * Program : ca997comp03s.ec
 * �j����O�O�d�ߤ��߲z�߸��
 * Author�GNeo Chen
 * Time �G90/10/12
 * Modify : 2006/05/16 by Jessie
 * Modify by Julia (98.07.15 �t�X�z�߱M��,�F�d��������򨮳d,�����T�õL�Ϥ����騮�d,
 *                  �ҥH�Y�O���騮�d���F�d�����@��"1",�h�ǰe���T�F�d��"1"�C�Y����
 *                  ���F�d����"1"���ɭ�,�h�ǰe���d���F�d)
 ***********************************************************************************/
 
#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "sqlfatal.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"

#include "safeclib.h"

#define ONLINE_DATE "04/29/2007"        /* �e���T��Ʊj����N���ɤW�u�� */

/*--------------------------------------------------------------------*/
DBinfo  *list;
int     i=0,count_db=0,rc=0;

char  userid[11],option[2],outputf[21];
$char DBName[05];
$char datebgn[11],dateend[11];
$char sApHome[31],tmp_dbname[20];
char  errmsg[200],msgbuf[128];
FILE  *errfpt;
FILE  *fptr;
$int  number;
$long dbgn_long;

$char  errFile[30],errlog[300];

static char localdb[5];
static int  i,flag_check=0;

static  char sExpdate[10];
static  char sBgndate[10],sEnddate[10];
$static char  sDappraisal_bgn[11], sDappraisal_end[11];
long    rtncode;

$char   companyid[3],opt[3];
int     rtn;
$char   COMPANY[3];
$char   COMPANY_F[3];

/*static char sPrtstr[250]; */

$static char  sDgroup[11];
$static char  sTmt_buf[1024];

/* data  ca_trad_exam */
$long prem_total=0, cntrlrec=0;
$long minjure=0, mcripple=0, mdeath=0;
$long qcount=0,Tinjure=0, Tcripple=0, Tdeath=0,Tamount=0;
$long policy_day=0,max_dply_l=0;
$char max_dply_c[11];
$char iply_type[3];

/* others data */
$char  sDappraisal_c[11],Tmp1[20],file0[51];    
$char  fcard_class[2],close_date_c[11];
char   day_yy[4],day_mm[3],day_dd[3];
char   strlog[500],cntrlrec_c[7],prtstr[500];
$long  close_date, old_close_date;
$char  ibranch_in[5];
$char  company_flag;
$char  iclaim_flag, sWhere[128], sWhere1[128], sIcar_type[3];
$int   count;

$char filename[20];
$long filecount;

$char filefulllast[200];
$char lastdwork[11];
int   itmpcnt;
$char sWhere9[1024];
$char sWhere99[1024];


$define  INJURE         "93";
$define  DEATH          "94";
$define  CRIPPLE        "95";
$define  COMPULSORY     "21";

static long lApp_comp();   /* �j��w�� */
static long lStl_comp();   /* �j��w�M */
void GetLostAppData();     /* ���o�e�@�u�@�饼�ǰe���w����� */
long   car9973_get_db();
extern char *sformat_trade();
extern long split_policy();
extern int rptftpinsert();
long   check_if_exist();
long  today, online_date, online;

/*--------------------------------------------------------------------*/
main(argc,argv)
int   argc;
char  **argv;
{
int   rc;

   batchinit();

   strcpy(DBName,isNULLstr(argv[1]));
   strcpy(userid,isNULLstr(argv[2]));
   strcpy(option,isNULLstr(argv[3]));       /* 1:�j��T���z��, 3:�j������z�� 4:�z�߭��e, 5:�z�߭簣���e */
   strcpy(datebgn,isNULLstr(argv[4]));
   strcpy(dateend,isNULLstr(argv[5]));
   strcpy(outputf,isNULLstr(argv[6]));

   strcpy(sDappraisal_bgn,cm_to_infdate(datebgn));
   strcpy(sDappraisal_end,cm_to_infdate(dateend));
   rstrdate(sDappraisal_bgn,&dbgn_long);
   
   $WHENEVER SQLERROR GOTO errexit;
   
   rstrdate( ONLINE_DATE, &online_date);
   rtoday( &today);

   online = today >=online_date ? TRUE:FALSE;

   errfpt = (FILE *) STARTLOG();   

   rc=car9973_get_db();
   if (rc!=M_CM_OK)
      return rc;
     
   itmpcnt = 0;
   rtn = getCompanyId(companyid);

   strcpy(sWhere, " ");
   strcpy(sWhere9, " ");
   
   if( strcmp(option,"1") == 0 )
   {
        strcpy(sWhere1," AND a.icar_type not in ('01','02','32','34','35')");
        strcpy(opt,"cm");
        /** �]�z�߰����i�঳���,�G�P�_�W�@���ǰe���+1,�P��J���� **/
        $select max(dpolicy)+1,max(dpolicy)+1
           into $max_dply_l,$max_dply_c
           from ca_trade_exam
          where iply_type = $opt and fcard_class = '1';
        if (dbgn_long > max_dply_l)
            strcpy(sDappraisal_bgn,max_dply_c);
            
printf("sDappraisal_bgn[%s],end[%s]\n",sDappraisal_bgn,sDappraisal_end); 
    
        GetLostAppData();
    
        /*** �j��w�� ***/
        rtncode=lApp_comp();
        
        strcpy(sWhere1," AND b.icar_type not in ('01','02','32','34','35')");
        /*** �j��w�M ***/
        if (rtncode==SUCCESS) rtncode=lStl_comp();
        if (errfpt!=NULL) ENDLOG(errfpt); 
   }
   else if ( strcmp(option,"3") == 0 )
   {
        strcpy(sWhere1," AND a.icar_type in ('01','02','32','34','35')");
        strcpy(opt,"mm");
        $select max(dpolicy)+1,max(dpolicy)+1
           into $max_dply_l,$max_dply_c
           from ca_trade_exam
          where iply_type = $opt and fcard_class = '1';
        if (dbgn_long > max_dply_l)
            strcpy(sDappraisal_bgn,max_dply_c);

        GetLostAppData();       

        /*** �����w�� ***/
        rtncode=lApp_comp();
        
        strcpy(sWhere1," AND b.icar_type in ('01','02','32','34','35')");
        /*** �����w�M ***/
        if (rtncode==SUCCESS) rtncode=lStl_comp();
        
        if (errfpt!=NULL) ENDLOG(errfpt); 
   }
   else if ( strcmp(option,"4") == 0 ) /*�z�߭��e*/
   {
        msgbuf[0]='\0';
        strcpy(sWhere1," AND a.icar_type not in ('01','02','32','34','35')");
        strcpy(opt,"cm");
        /*** �j��w�� */
        rtncode=lApp_comp();

        strcpy(sWhere1," AND b.icar_type not in ('01','02','32','34','35')");
        /* �j��w�M */
        if (rtncode==SUCCESS) rtncode=lStl_comp();
        else sprintf_s(msgbuf, sizeof msgbuf,"�j��w��_error[%d] ",rtncode);

        strcpy(sWhere1," AND a.icar_type in ('01','02','32','34','35')");
        strcpy(opt,"mm");
        /*** �����w�� ***/
        if (rtncode==SUCCESS) rtncode=lApp_comp();
        else sprintf_s(msgbuf, sizeof msgbuf,"%s�j��w�M_error[%d] ",trim(msgbuf),rtncode);
        
        strcpy(sWhere1," AND b.icar_type in ('01','02','32','34','35')");
        /*** �����w�M ***/
        if (rtncode==SUCCESS) rtncode=lStl_comp();
        else sprintf_s(msgbuf, sizeof msgbuf,"%s�����w��_error[%d] ",trim(msgbuf),rtncode);

        if (errfpt!=NULL) ENDLOG(errfpt); 
   }
   else if ( strcmp(option,"5") == 0 ) /*�z�߭簣���e,�� ca_tmp_no �����*/
   {
        msgbuf[0]='\0';

        strcpy(sWhere,
               " and iclaim in (select ipolicy from newa00:ca_tmp_no) ");

        strcpy(sWhere1," AND a.icar_type not in ('01','02','32','34','35')");
        strcpy(opt,"cm");
        /*** �j��w�� */
        rtncode=lApp_comp();

        strcpy(sWhere1," AND b.icar_type not in ('01','02','32','34','35')");
        /* �j��w�M */
        if (rtncode==SUCCESS) rtncode=lStl_comp();
        else sprintf_s(msgbuf, sizeof msgbuf,"�j��w��_error[%d] ",rtncode);

        strcpy(sWhere,
               " and iclaim in (select ipolicy from newa00:ca_tmp_no) ");
        strcpy(sWhere1," AND a.icar_type in ('01','02','32','34','35')");
        strcpy(opt,"mm");
        /*** �����w�� ***/
        if (rtncode==SUCCESS) rtncode=lApp_comp();
        else sprintf_s(msgbuf, sizeof msgbuf,"%s�j��w�M_error[%d] ",trim(msgbuf),rtncode);
        
        strcpy(sWhere1," AND b.icar_type in ('01','02','32','34','35')");
        /*** �����w�M ***/
        if (rtncode==SUCCESS) rtncode=lStl_comp();
        else sprintf_s(msgbuf, sizeof msgbuf,"%s�����w��_error[%d] ",trim(msgbuf),rtncode);

        if (errfpt!=NULL) ENDLOG(errfpt); 
   }

   if (rtncode != SUCCESS )
   {
        
        rgetmsg(rtncode, errlog, sizeof(errlog));
        
        sprintf_s(strlog, sizeof strlog,"%s\n\n\t\t     ",errlog);
        
        printf("option [%s]\n",option);
        
        if( strcmp(option,"1") == 0 )
        {
         
         strcat(strlog," iscm");
         strcat(strlog,companyid);
         strcat(strlog,"_�j��T���z�߻s�@���� ");
                 
        }
        else if ( strcmp(option,"3") == 0 ) 
        {
        
         strcat(strlog," ismm");
         strcat(strlog,companyid);
         strcat(strlog,"_�j������z�߻s�@���� ");
        
        }
        else
        {
         strcat(strlog,msgbuf);
        }
        
        printf("strlog[%s]\n",strlog); 
        
        EWRITE(userid,rc,strlog);
        
        exit(1);
   }
   
   /* �]���Τ@�����   �O�椽�q�O�� 16   �׸����q�O��17  */
   
   exit(0);
   
errexit:
    printf("car9973-main:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE; 
}
/*--------------------------------------------------------------------*/
long car9973_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   rc = getApHome(sApHome);
   if (rc < 0) {
        printf("read Config file error!!\n");
        return M_CM_READ_CONFIG_ERR;
   } 
   
   /*sApHome[31] = '\0';*/
   
   printf("sApHome[%s]\n",sApHome);
   
   $CREATE TEMP TABLE TRADE_COUNT
   (
      file_name char(20),
      policy_day int,
      qcount    int,
      Tamount   int,
      Tinjure   int,
      Tcripple  int,
      Tdeath    int
   )WITH NO LOG;
  $create unique index trade_count_idx on trade_count(file_name);

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*------------------�j��w��------------------------------------------*/
long lApp_comp()
{
     $char  sIpolicy[POLICY_NUM_1],sObjno[CA_TARGET_NUM+1];

     $char  sIpolicy1[POLICY_NUM_1], sIpolicy2[POLICY_NUM_2];
     long   iRtnCode;
     int    iFetch; 

     $char  sIclaim[CLAIM_NUM],sIins_type[INSURANCE_TYPE];
     $char  sItag[CA_TAG_NUM],sDappraisal[11],sIcard[POLICY_NUM_1];
     $char  sIacc_license[11],sIacc_birth[7],sIacc_birth_yy[3];
     $char  sIacc_birth_mm[3];
     $char  sIacc_birth_yyyy[5];
     $char  sIacc_birth_dd[3],sNacc_driver[21],sFacc_sex[2];
     $char  sFacc_marri[2];
     $char  sFacc_nation[2],sIacc_reason[3],sDaccident[14];
     $char  sIacc_area[3];
     $char  sFpart_A[2],sFpart[2],sFacc_car[2],sFacc_duty[2]; 
     $long  lQlia,lMins_app,lInjure,lDeath,lCripple,Mmins_app;
     char   sInjure[3],sDeath[3],sCripple[3],sMins_app[12];
     char   sInjure_1[3],sDeath_1[3],sCripple_1[3];
     char   drate_yy[4],drate_mm[3],drate_dd[3];

     $long  Dappraisal=0,oldDappraisal=0, iCount=0;
     $char  stmt_buf1[1000],stmt_buf2[200],Tstmt[5000];
     char   sPrtstr[437];
     $char  Mclaim[21],Mappraisal[11];     
     $char  facc_car[2], fsystem[2], fassured[2], stmt_bufd[256];
     $char  TDapp_ori[11],chk_dpolicy[2];
     $char  sWhere77[2000];
     
     $char sNacc_driver_tmp[201];

     printf ("lApp_comp\n");

     sIcar_type[0] = '\0';
     sItag[0]='\0';
     sIcard[0]='\0';
     sDappraisal[0]= '\0';
     sIacc_license[0]= '\0';
     sIacc_birth[0]='\0';
     sIacc_birth_yy[0]='\0';
     sIacc_birth_mm[0]='\0';
     sIacc_birth_dd[0]='\0';
     sNacc_driver[0]='\0';
     sFacc_sex[0]='\0';
     sFacc_marri[0]= '\0';
     sFacc_nation[0]='\0';
     sIacc_reason[0]='\0';
     sDaccident[0]='\0';
     sIacc_area[0]='\0';
     sFpart[0]= '\0';
     sFpart_A[0]= '\0';
     sFacc_car[0]='\0';
     sFacc_duty[0]='\0';
     sIacc_birth_yyyy[0]='\0';
     lQlia= lMins_app=0;
     iFetch=TRUE;
     cntrlrec=0;

     memset(sTmt_buf,' ',sizeof(sTmt_buf));
     
     $WHENEVER SQLERROR GOTO errexit;

     $CREATE TEMP TABLE APPCOMP
     (
        Ticlaim    char(20),
        Tappraisal char(11),
        Tmins_app  int,
        TDapp_ori  char(11)
     )WITH NO LOG;


     for( i=0; i<count_db; i++)
     {
        if (itmpcnt > 0)
        {
           sprintf_s(sWhere9, sizeof sWhere9,"UNION SELECT iclaim,cast('%s' as date) dappraisal,SUM(mapp_cover+mapp_fee),max(dappraisal) "
                           "  FROM %s:ca_app_victim "
                           " WHERE ((dappraisal BETWEEN '%s' AND '%s') or (iclaim in (select iclaim from sysdb:ca_clm_upd_log where ifield in (1,2,5) and date(dcreate) between '%s' and '%s'))) %s "
                           "   AND iclaim not in (select iclaim from t997_temp) "
                           " GROUP BY iclaim ",sDappraisal_bgn, list[i].dbname,
                           lastdwork, lastdwork, lastdwork, lastdwork, sWhere );
        }

        sprintf_s(sWhere99, sizeof sWhere99,"UNION SELECT a.iclaim, max(b.dappraisal), SUM(a.mapp_cover+a.mapp_fee), max(b.dappraisal) "
                         "        FROM %s:ca_app_victim a, ( select iclaim, max(date(dcreate)) as dappraisal from sysdb:ca_clm_upd_log where ifield in (1,2,5) and date(dcreate) between '%s' and '%s' group by 1 ) b  "
                         "       WHERE a.iclaim  =  b.iclaim   "
                         "       GROUP BY iclaim ", list[i].dbname, sDappraisal_bgn, sDappraisal_end);

        sprintf_s(Tstmt, sizeof Tstmt,"SELECT iclaim,max(dappraisal),SUM(mapp_cover+mapp_fee),max(dappraisal) "
                      "  FROM %s:ca_app_victim "
                      " WHERE dappraisal BETWEEN '%s' AND '%s' %s "
                      " GROUP BY iclaim %s %s ",list[i].dbname,
                      sDappraisal_bgn, sDappraisal_end, sWhere, sWhere9, sWhere99 );
        
        printf("Tstmt[%s]\n",Tstmt);
        
        $PREPARE TSTMT FROM $Tstmt;
        $DECLARE CUSTSTMT CURSOR for TSTMT;
        
        $OPEN CUSTSTMT;
        while(1)
        {
            $FETCH CUSTSTMT INTO $Mclaim, $Mappraisal, $Mmins_app, $TDapp_ori;
            
            if( SQLCODE == SQLNOTFOUND ) break;
            
            $INSERT INTO APPCOMP ( Ticlaim, Tappraisal, Tmins_app , TDapp_ori)
                          VALUES ( $Mclaim, $Mappraisal, $Mmins_app ,$TDapp_ori);
                          
        }
        $CLOSE CUSTSTMT;
        $FREE  CUSTSTMT;
        
     }
    
     $DECLARE CUS2 CURSOR for
       SELECT Ticlaim, Tappraisal,  Tmins_app ,TDapp_ori
         INTO $sIclaim,$sDappraisal,$lMins_app, $TDapp_ori
         FROM APPCOMP
        ORDER BY Tappraisal;
        
     $OPEN CUS2;
     while (1)
     {
            
           memset(sPrtstr,' ',sizeof(sPrtstr));
           
           $FETCH CUS2;
           
           if (SQLCODE == SQLNOTFOUND) break;
           if (risnull(2,&lMins_app)==1) lMins_app=0;
           
           rstrdate( sDappraisal , &Dappraisal );
           
printf("iclaim[%s],date[%s],mins_app[%d]\n",sIclaim,sDappraisal,lMins_app);
           
           /* ��X�߮ש��ݸ�Ʈw */
           $SELECT ibranch_in , fsystem
              INTO $ibranch_in, $fsystem
              FROM ca_clm_process
             WHERE iclaim = $sIclaim;
             
           if( SQLCODE == SQLNOTFOUND ) continue;
           
           strcpy( tmp_dbname , get_full_dbname( ibranch_in ));

           sprintf_s(stmt_buf1, sizeof stmt_buf1,"SELECT b.ipolicy,b.iacc_license,b.iacc_birth,b.nacc_driver,"
                             "b.facc_sex,b.facc_marri,b.facc_nation,b.iacc_reason,"
                             "b.daccident,b.iacc_area,b.fpart,b.facc_rel,"
                             "b.facc_duty,"
                             "(b.qacar_death+b.qbcar_death+b.qccar_death),"
                             "(b.qacar_injure+b.qbcar_injure+b.qccar_injure),"
                             "(b.qacar_cripple+b.qbcar_cripple+b.qccar_cripple), a.itag, b.icard, b.facc_car, c.fassured, a.icar_type,"
                             "CASE WHEN d.dpolicy < '08/01/2016' THEN 'Y' ELSE 'N' END,"
                             "to_char(b.dacc_birth,'%%Y'),to_char(b.dacc_birth,'%%m'),to_char(b.dacc_birth,'%%d') "
                             "  FROM %s:adjustment_ply a, %s:appraisal b, %s:policy c, %s:ply_relation d"
                             " WHERE a.iclaim = ? AND a.iclaim = b.iclaim %s"
                             "   AND b.ipolicy = c.ipolicy "
                             "   AND b.ipolicy = d.ipolicy",
                             tmp_dbname,tmp_dbname,tmp_dbname,tmp_dbname,sWhere1);
           
           $PREPARE CUS_CLAIM from $stmt_buf1;
           $EXECUTE CUS_CLAIM INTO $sIpolicy,$sIacc_license,$sIacc_birth,$sNacc_driver,
                                   $sFacc_sex,$sFacc_marri,$sFacc_nation,$sIacc_reason,
                                   $sDaccident,$sIacc_area,$sFpart,$sFacc_car,$sFacc_duty,
                                   $lDeath,$lInjure,$lCripple,$sItag,$sIcard, $facc_car, $fassured, $sIcar_type, $chk_dpolicy,
                                   $sIacc_birth_yyyy,$sIacc_birth_mm,$sIacc_birth_dd
                             USING $sIclaim;
               
           if (SQLCODE == SQLNOTFOUND) continue;
           if( fsystem[0] == 'N')
               strcpy( sFacc_car, facc_car);
           else
           {
           /*�r�p�H�ϧO*/
                        switch (sFacc_car[0])
                        {
                                case '1':
                                        break;
                                case '2':
                                        break;
                                case '3':
                                        /*�P�Q�O�I�H���Y = "3 ���u"*/
                                        /*�r�p�H�ϧO = "4 �����k�H"*/
                                        sFacc_car[0] = '4';
                                        break;
                                case '4':
                                        /*�P�Q�O�I�H���Y = "4 ����"*/
                                        /*�r�p�H�ϧO = "4 �����k�H"*/
                                        sFacc_car[0] = '4';
                                        break;
                                case '5':
                                        /*�P�Q�O�I�H���Y = "5 ��L"*/
                                        if( fassured[0] == '1' || fassured[0] == '3' || fassured[0] == '5')
                                            sFacc_car[0] = '2'; /*�r�p�H�ϧO = "2 �w���ɥL�H��"*/
                                        else
                                            sFacc_car[0] = '4'; /*�r�p�H�ϧO = "4 �����k�H"*/

                                        break;
                                default :
                                        sFacc_car[0] = '2';
                                        break;
                        }                    
           }
           if (risnull(2,&lDeath)==1) lDeath=0;
           if (risnull(2,&lInjure)==1) lInjure=0;
           if (risnull(2,&lCripple)==1) lInjure=0;

/*printf("->lDeath[%ld]->lInjure[%ld]->lCripple[%ld]\n",lDeath,lInjure,lCripple);*/

           iRtnCode = split_policy(sIpolicy, sIpolicy1, sIpolicy2);
           if (iRtnCode != M_CM_OK) break;
           

           
           company_flag=sIpolicy1[7];
           
printf(" sIpolicy1[%s]\n",sIpolicy1);
       
           strcpy(COMPANY,companyid);
           strcpy(COMPANY_F,companyid);

           if(strcmp( companyid,"17")==0)
           {
               if(company_flag > 65 )
               {  
                $select ipolicy_a
                  into $sIpolicy1
                  from conv_ipolicy
                 where ipolicy_n = $sIpolicy1;                                  
              
                 strcpy(COMPANY,"16");
               }
           
               iclaim_flag=sIclaim[6];
                          
               if(iclaim_flag > 65 )
               {  
                $select distinct iclaim_a
                  into $sIclaim
                  from conv_iclaim
                 where iclaim_n = $sIclaim;
                 
printf(" ***** sIclaim[%s]\n",sIclaim);
          
                strcpy(COMPANY_F,"16");
               }
           }
           
           if(iFetch)/* �Ĥ@�� */
           {
                iFetch = FALSE;
                oldDappraisal = Dappraisal; /* �e�B��@������Ƥ�� */
                prem_total = 0; /* �`���B */

             if (strcmp(option,"4")==0 || strcmp(option,"5")==0) {
                cm_split_ymd_100(datebgn,day_yy,day_mm,day_dd);
          
                sprintf_s(Tmp1, sizeof Tmp1,"is%s%s_%s%s%sc",opt,companyid,day_yy,day_mm,
                        day_dd);
                strcpy(iply_type,opt);
                strcpy(fcard_class, "1");
          
                sprintf_s(file0, sizeof file0,"%s/rptftp/%s",trim(sApHome),Tmp1);
   
                printf("file0[%s] Tmp1[%s]\n",file0,Tmp1);
                fptr=fopen(file0,"w");
             }
             else {
                strcpy( sDappraisal_c , cm_cdate_str_100( Dappraisal ));                
          
                cm_split_ymd_100(sDappraisal_c,day_yy,day_mm,day_dd);
          
                sprintf_s(Tmp1, sizeof Tmp1,"is%s%s_%s%s%sc",opt,companyid,day_yy,day_mm,
                        day_dd);
                strcpy(iply_type,opt);
                strcpy(fcard_class, "1");
          
                sprintf_s(file0, sizeof file0,"%s/rptftp/%s",trim(sApHome),Tmp1);
   
                printf("file0[%s] Tmp1[%s]\n",file0,Tmp1);
                fptr=fopen(file0,"w");
                
                rc = check_if_exist(iply_type,Dappraisal,fcard_class,0);
                if ( rc != M_CM_OK )
                    return rc;
              }
           }
           
           if ( oldDappraisal != Dappraisal ) /* �����ثefile , open a new file*/
           {            
               if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0)
               {  /* ���e�έ簣���e�����̤�������ɮ� */                              
                     $INSERT INTO TRADE_COUNT  /* �g�Jca_trade_exam����ơA�HTemp-Table�Ȧs*/
                            (policy_day, file_name, qcount, Tamount, Tinjure, Tcripple, Tdeath)
                      VALUES
                            ($oldDappraisal, $Tmp1, $cntrlrec, 0, 0, 0, 0);
                                                                        
                      fclose(fptr);  
                            
                      /* ���P����Aopen a new file */               
                      strcpy( sDappraisal_c , cm_cdate_str_100( Dappraisal ));                         
          
                      cm_split_ymd_100(sDappraisal_c,day_yy,day_mm,day_dd);
          
                      sprintf_s(Tmp1, sizeof Tmp1,"is%s%s_%s%s%sc",opt,companyid,day_yy,day_mm,
                               day_dd);
                      strcpy(iply_type,opt);
                      strcpy(fcard_class, "1");
          
                      sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
   
printf("APP file0[%s] Tmp1[%s]\n",file0,Tmp1);
                      fptr=fopen(file0,"w");                           
               
                      rc = check_if_exist(iply_type,Dappraisal,fcard_class,0);
                      if ( rc != M_CM_OK ) return rc;
         
                      cntrlrec = 0;
               }
           }

           oldDappraisal = Dappraisal;
           

           sprintf_s(stmt_bufd, sizeof stmt_bufd,"SELECT count(*) FROM %s:ca_app_victim_hist \
                               WHERE iclaim = '%s' \
                                 AND dappraisal < '%s'",
                             tmp_dbname, sIclaim, TDapp_ori );

           $PREPARE EXE_STMTd FROM $stmt_bufd;
           $EXECUTE EXE_STMTd INTO $iCount;
           if( iCount == 0)
           {   strcpy(sPrtstr,"9"); sPrtstr[1]='\0';}                    /*C1-C1:���ʧO 1:original*/
           else
           {   strcpy(sPrtstr,"5"); sPrtstr[1]='\0';}                    /*C1-C1:���ʧO 5:replace*/
           
           strcat(sPrtstr,"1"); sPrtstr[2]='\0';                    /*C2-C2:�߮שʽ�N��*/
           strcat(sPrtstr,COMPANY_F); sPrtstr[4]='\0';              
           strncat(sPrtstr,sIclaim, 14); sPrtstr[18]='\0';          /*C3-C18:���q�O + �߮ר��z��*/
           strcat(sPrtstr,COMPANY_F); sPrtstr[20]='\0';             
           strncat(sPrtstr,sIclaim, 14); sPrtstr[34]='\0';          /*C19-C34:���q�O + �߮׸�*/
        
           strcat(sPrtstr, "     ");                                /*C35-C39:�ߥI/�l�v����*/
           strcat(sPrtstr, "        ");                             /*C40-C47:���פ��*/
           sPrtstr[47]='\0';

           strcat(sPrtstr,COMPANY); sPrtstr[49]='\0';              

           strcat(sPrtstr,sformat_trade(sIpolicy1 ,2 ,15));
           sPrtstr[64]='\0';                                        /*C48-C64:���q�O + �O�渹*/
        
           if (strlen(rtrim(sIpolicy2)) > 0)                        /* ���j�O��*/
           {
               strcpy(sObjno, sformat_trade(sIpolicy2, 2, 4));
           }
           else
           {
               strcpy(sObjno,"0001"); 
           }

           strcat(sPrtstr,sObjno); sPrtstr[68]='\0';                /*C65-C68:�Ъ���*/
 
 
           /* ����27,���P���X�M�� modify by sylvia 101.02.24 (1001005007_C1)
           if ((strlen(sItag)<=0) || ((strcmp(sIcar_type,"27") == 0) && strcmp(chk_dpolicy,"Y") == 0)) */

           /* 1061102009_C1 �ק�ǰe���T27���ؾ��񨮵P�W�h */
           if (strlen(sItag)<=0)
              strcpy(sItag, "            ");                        
           strcat(sPrtstr,sItag); sPrtstr[80]='\0';                 /*C69-80:�P�Ӹ�*/

           strcat(sPrtstr,sIacc_license); sPrtstr[90]='\0';         /*C81-90:�r��*/
           /*strncpy(sIacc_birth_yy,sIacc_birth,2);*/                   /*C91-98:�ͤ�*/
           /*sIacc_birth_yy[2]='\0';
           sIacc_birth_mm[0]=sIacc_birth[2];
           sIacc_birth_mm[1]=sIacc_birth[3];
           sIacc_birth_mm[2]='\0';
           sIacc_birth_dd[0]=sIacc_birth[4];
           sIacc_birth_dd[1]=sIacc_birth[5];
           sIacc_birth_dd[2]='\0';
           strcpy(sIacc_birth_yyyy,itoa(1911+atoi(sIacc_birth_yy)));*/
           strncat(sPrtstr,sIacc_birth_yyyy,4); sPrtstr[94]='\0';
           strncat(sPrtstr,sIacc_birth_mm,2); sPrtstr[96]='\0';
           strncat(sPrtstr,sIacc_birth_dd,2);  sPrtstr[98]='\0';


		   sprintf_s(sNacc_driver_tmp, sizeof sNacc_driver_tmp,"%-200.200s",rtrim(sNacc_driver));
           strcat(sPrtstr,sNacc_driver_tmp); sPrtstr[298]='\0';     /*C99-118:�m�W*/
           strcat(sPrtstr,sFacc_sex); sPrtstr[299]='\0';            /*C119-119:�ʧO*/
           strcat(sPrtstr,sFacc_marri); sPrtstr[300]='\0';          /*C120-120:�B��*/
           strcat(sPrtstr,sFacc_nation); sPrtstr[301]='\0';         /*C121-121:��O*/
           strcat(sPrtstr,sIacc_reason); sPrtstr[303]='\0';         /*C122-123:�X�I��]*/

		   sprintf_s(sNacc_driver_tmp, sizeof sNacc_driver_tmp,"%-200.200s",rtrim(sNacc_driver));
           strcat(sPrtstr,sNacc_driver_tmp); sPrtstr[298]='\0';     /*C99-118:�m�W*/
           strcat(sPrtstr,sFacc_sex); sPrtstr[299]='\0';            /*C119-119:�ʧO*/
           strcat(sPrtstr,sFacc_marri); sPrtstr[300]='\0';          /*C120-120:�B��*/
           strcat(sPrtstr,sFacc_nation); sPrtstr[301]='\0';         /*C121-121:��O*/
           strcat(sPrtstr,sIacc_reason); sPrtstr[303]='\0';         /*C122-123:�X�I��]*/

           rfmtlong(lInjure,"&&&",sInjure);
           rfmtlong(lDeath,"&&&",sDeath);  
           rfmtlong(lCripple,"&&&",sCripple);
           strcat(sPrtstr,sInjure); sPrtstr[306]='\0';              /*C124-126:���*/
           strcat(sPrtstr,sDeath); sPrtstr[309]='\0';               /*C127-129:���`*/
           strcat(sPrtstr,sCripple); sPrtstr[312]='\0';             /*C130-132:�ݼo*/

           strncat(sPrtstr,sDaccident,4); sPrtstr[316]='\0';        /*C133-144:�X�I����ɶ�(YYYYMMDDHHMM)*/
           strncat(sPrtstr,(sDaccident+5),2); sPrtstr[318]='\0';    /*MM*/
           strncat(sPrtstr,(sDaccident+8),2); sPrtstr[320]='\0';    /*DD*/
           strncat(sPrtstr,(sDaccident+11),2); sPrtstr[322]='\0';   /*HH*/
           strcat(sPrtstr,"00"); sPrtstr[324]='\0';                 /*MM*/

           /* �N�{��u�a�ϥN�����v���R���N��42�u�x�����v�B�N��63�u�x�n���v�B�N��65�u�������v�C*/
           if( strcmp( sIacc_area, "42") == 0)
               strcpy( sIacc_area, "41");
           else if( strcmp( sIacc_area, "63") == 0)
               strcpy( sIacc_area, "62");
           else if( strcmp( sIacc_area, "65") == 0)
               strcpy( sIacc_area, "64");

           strcat(sPrtstr,sIacc_area); sPrtstr[326]='\0';           /*C145-146:�X�I�a�ϥN��*/
           if (*sFpart=='1' || *sFpart=='2' || *sFpart=='3')
               sFpart_A[0]='1';
           else
               sFpart_A[0]='2';
           strcat(sPrtstr,sFpart_A); sPrtstr[327]='\0';             /*C147-147:���l���l�O�N��*/
      
 
           strcat(sPrtstr,COMPULSORY); sPrtstr[329]='\0';           /*C148-149:�O�I�����N��*/
 
           rfmtlong(0,"&&&",sInjure_1);
           rfmtlong(0,"&&&",sDeath_1);  
           rfmtlong(0,"&&&",sCripple_1);
           strcat(sPrtstr,sInjure_1); sPrtstr[332]='\0';            /*C150-152:���*/
           strcat(sPrtstr,sDeath_1); sPrtstr[335]='\0';             /*C153-155:���`*/
           strcat(sPrtstr,sCripple_1); sPrtstr[338]='\0';           /*C156-158:�ݼo*/
           rfmtlong(lMins_app,"&&&&&&&&&&&&",sMins_app);
           strcat(sPrtstr,sMins_app); sPrtstr[350]='\0';            /*C159-170:�w���l�����B*/

           strcat(sPrtstr,"       ");           
           sPrtstr[357]='\0';                                       /*C171-177:�z�ߦۭt�B*/
           strcat(sPrtstr,"            ");           
           sPrtstr[369]='\0';                                       /*C178-189:��ڲz�ߪ��B/�l�v���B*/
           strcat(sPrtstr,"       ");           
           sPrtstr[376]='\0';                                       /*C190-196:��˲z�ߪ��B*/
           strcat(sPrtstr,"       ");           
           sPrtstr[383]='\0';                                       /*C197-203:���`�z�ߪ��B*/
           strcat(sPrtstr,"       ");
           sPrtstr[390]='\0';                                       /*C204-210:�ݼo�z�ߪ��B*/
           strcat(sPrtstr,"            ");           
           sPrtstr[402]='\0';                                       /*C211-222:�M�Ѫ��B*/
           strcat(sPrtstr,"            ");           
           sPrtstr[409]='\0';                                       /*C223-229:�z�߶O��*/
           
           strncat(sPrtstr,(sDappraisal+6),4); sPrtstr[413]='\0';   /*C230-237:�w�����YYYYMMDD*/
           strncat(sPrtstr,sDappraisal,2); sPrtstr[415]='\0';
           strncat(sPrtstr,(sDappraisal+3),2); sPrtstr[417]='\0';

           strcat(sPrtstr,sFacc_car); sPrtstr[418]='\0';            /*C238-238:�r�p�H�ϧO*/
           strcat(sPrtstr,sFacc_duty); sPrtstr[419]='\0';           /*C239-239:�F�d*/
           strcat(sPrtstr,COMPANY); sPrtstr[421]='\0';
           strcat(sPrtstr,sIcard); sPrtstr[436]='\0';               /*C240-256:���q�O + �j��O�I����*/
           
           fprintf(fptr,"%s\n",sPrtstr);
           cntrlrec++;
           
        } 
printf ("end lApp_comp[%s]\n",Tmp1);
        
        $CLOSE CUS2;
        $FREE  CUS2;
        
        $DROP TABLE APPCOMP;
         
        if ( cntrlrec > 0 )
        {               
          $INSERT INTO TRADE_COUNT
                         (policy_day, file_name, qcount, Tamount, Tinjure, Tcripple, Tdeath)
                         VALUES
                         ($oldDappraisal, $Tmp1, $cntrlrec, 0, 0, 0, 0);
                                   
printf("cntrlrec[%d] > 0 && insert table \n",cntrlrec);
          
          fclose(fptr);
        
        }
 
     return(SUCCESS);

errexit:
     return(SQLCODE);
}

/*--------------   �j��w�M  -----------------------------------------*/
long lStl_comp()
{
  $char  sIpolicy[POLICY_NUM_1],sObjno[CA_TARGET_NUM+1];

  $char  sIpolicy1[POLICY_NUM_1], sIpolicy2[POLICY_NUM_2];
   long  iRtnCode;
   int   iFetch;

  $char  sIclaim[CLAIM_NUM],sIins_type[INSURANCE_TYPE];
  $char  sIclaim_n[CLAIM_NUM];
  $char  sItag[CA_TAG_NUM],sDappraisal[11],sFstl[2],sFlast[2],sIcard[POLICY_NUM_1];
  $char  sIacc_license[11],sIacc_birth[8],sIacc_birth_yy[4];
  $char  sIacc_birth_mm[3];
  $char  sIacc_birth_dd[3],sNacc_driver[21],sFacc_sex[2],sFacc_marri[2];
  $char  sFacc_nation[2],sIacc_reason[3],sDaccident[14],sIacc_area[3];
  $char  sFpart[2],sFpart_A[2],sFacc_car[2],sFacc_duty[2],sIins_item[7];
  $long  lDgroup,lMins_comp,lMins_dedu,lMins_stl,lMins_proc;
  $long  lIclose_type, lCount;
  $long  Dappraisal,oldDappraisal;
   char  sQinjure[4],sQdeath[4],sQcripple[4],sIclose_type[5];
   char  sQinjure_1[4],sQdeath_1[4],sQcripple_1[4];
   char  sQinjure_stl[8],sQdeath_stl[8],sQcripple_stl[8];
   char  sMins_stl[9],sMins_proc[8],sMins_dedu[8],sMins_comp[9];
  $char  sDgroup[11];
  $char  sIacc_birth_yyyy[5]; 
   char  sDgroup_yyyy[5], sDgroup_mm[3], sDgroup_dd[3];
   char  sPrtstr[437]; 
  $char  stmt_buf3[1024],stmt_buf4[200],Tstmt1[5000];
  $char  Mclaim[21], Mfstl[2], Miclose_type[5], Mflast[2];
  $char  pre_Mclaim[21], pre_Mfstl[2], pre_Miclose_type[5];
  $char  Miins_item[7], Mdclose[11];
  $char  ibranch_in[5];
  $long  Mmins_stl, Mmins_comp, Mmins_proc, Mqcount, Mcnt;
  $long  lQinjure,lQdeath,lQcripple,lMinjure,lMdeath,lMcripple;
  $long  ldclose,Tdclose;
  $long  tmp_date,cnt;
  $char  facc_car[2], fsystem[2], fassured[2] ,chk_dpolicy[2];
  
  $char sNacc_driver_tmp[201];
 
  int count=0;
  
  $WHENEVER SQLERROR GOTO errexit;

  sIcar_type[0] = '\0';
  sItag[0]='\0';
  sIcard[0]='\0';
  sDappraisal[0]= '\0';
  sIacc_license[0]= '\0';
  sIacc_birth[0]='\0';
  sIacc_birth_yy[0]='\0';
  sIacc_birth_mm[0]='\0';
  sIacc_birth_dd[0]='\0';
  sNacc_driver[0]='\0';
  sFacc_sex[0]='\0';
  sFacc_marri[0]= '\0';
  sFacc_nation[0]='\0';
  sIacc_reason[0]='\0';
  sDaccident[0]='\0'; 
  sIacc_area[0]='\0';
  sFpart[0]= '\0';
  sFpart_A[0]= '\0';
  sFacc_car[0]='\0';
  sFacc_duty[0]='\0';
  sIacc_birth_yyyy[0]='\0';
  
  memset(sTmt_buf,' ',sizeof(sTmt_buf));
     
printf("CREATE TEMP TABLE STLCOMP\n");   
     $CREATE TEMP TABLE STLCOMP
     (
        Ticlaim char(20),
        Tfstl   char(2),
        Ticlose_type char(5),
        Tqinjure   int,
        Tqdeath    int,
        Tqcripple  int,
        Tminjure   int,
        Tmdeath    int,
        Tmcripple  int,
        Tmins_comp int,
        Tmins_proc int,
        Tdclose    date
     )WITH NO LOG;
     
     for( i=0; i<count_db; i++)
     {
        sprintf_s(Tstmt1, sizeof Tstmt1,"SELECT iclaim,fstl,iclose_type, "
                       "iins_item[1],count(unique ivictim), "
                       "sum(mins_stl),sum(mins_proc),sum(mins_comp), "
                       "max(dgroup) "
                       " FROM %s:ca_stl_victim "
                       "WHERE dgroup BETWEEN '%s' AND '%s' %s "
                       "GROUP BY 1,2,3,4 ORDER BY 1,2,3,4",
                       list[i].dbname,
                       sDappraisal_bgn, sDappraisal_end, sWhere );
        
        $PREPARE TSTMT1 FROM $Tstmt1;
        $DECLARE CUSTSTMT1 CURSOR for TSTMT1;
        
        $OPEN CUSTSTMT1;
        Mcnt=0;
        pre_Mclaim[0]='\0';
        pre_Mfstl[0]='\0';
        pre_Miclose_type[0]='\0';
        lMinjure=lMdeath=lMcripple=0;
        lQinjure=lQdeath=lQcripple=0;
        lMins_proc=lMins_comp=0;
        Tdclose=0;
        while(1)
        {
            
            $FETCH CUSTSTMT1 INTO $Mclaim, $Mfstl, $Miclose_type,
                                  $Miins_item,$Mqcount,
                                  $Mmins_stl, $Mmins_proc, $Mmins_comp,
                                  $ldclose;
            
            if( SQLCODE == SQLNOTFOUND ) break;
            if (Mcnt!=0 && (strcmp(Mclaim,pre_Mclaim)!=0 ||
                strcmp(Mfstl,pre_Mfstl)!=0 ||
                strcmp(Miclose_type,pre_Miclose_type)!=0)) {
            
                $INSERT INTO STLCOMP ( Ticlaim, Tfstl, Ticlose_type,
                             Tqinjure,Tqdeath,Tqcripple,
                             Tminjure,Tmdeath,Tmcripple,
                             Tmins_comp,Tmins_proc,Tdclose )
                              VALUES ( $pre_Mclaim, $pre_Mfstl,
                             $pre_Miclose_type,
                             $lQinjure,$lQdeath,$lQcripple,
                             $lMinjure,$lMdeath,$lMcripple,
                             $lMins_comp, $lMins_proc, $Tdclose );
                lMinjure=lMdeath=lMcripple=0;
                lQinjure=lQdeath=lQcripple=0;
                lMins_proc=lMins_comp=0;
                Tdclose=0;
            }
            Mcnt++;
            strcpy(pre_Mclaim,Mclaim);
            strcpy(pre_Mfstl,Mfstl);
            strcpy(pre_Miclose_type,Miclose_type);
            if (strncmp(Miins_item,"A",1)==0) {
                lQinjure += Mqcount;
                lMinjure += Mmins_stl;
            }
            if (strncmp(Miins_item,"B",1)==0) {
                lQdeath  += Mqcount;
                lMdeath  += Mmins_stl;
            }
            if (strncmp(Miins_item,"C",1)==0) {
                lQcripple += Mqcount;
                lMcripple += Mmins_stl;
            }
            lMins_comp += Mmins_comp;
            lMins_proc += Mmins_proc;
            
            if (Tdclose < ldclose)
               Tdclose = ldclose;
                          
        }
        $CLOSE CUSTSTMT1;
        $FREE  CUSTSTMT1;
        if (Mcnt!=0) {
                $INSERT INTO STLCOMP ( Ticlaim, Tfstl, Ticlose_type,
                             Tqinjure,Tqcripple,Tqdeath,
                             Tminjure,Tmcripple,Tmdeath,
                             Tmins_comp,Tmins_proc,Tdclose )
                              VALUES ( $pre_Mclaim, $pre_Mfstl,
                             $pre_Miclose_type,
                             $lQinjure,$lQcripple,$lQdeath,
                             $lMinjure,$lMcripple,$lMdeath,
                             $lMins_comp, $lMins_proc, $Tdclose );
       }
        
     }
printf("stl_count[%d]\n",Mcnt);

        cntrlrec = prem_total = 0;
        qcount = Tamount = Tinjure = Tcripple = Tdeath = 0;
        
        iFetch = True;
        $DECLARE CUS3 CURSOR for
          SELECT Ticlaim, Tfstl, Ticlose_type,
                 Tqinjure,Tqcripple,Tqdeath,
                 Tminjure,Tmcripple,Tmdeath,
                 Tmins_comp,Tmins_proc,Tdclose             
            FROM STLCOMP           
            ORDER BY 12,1;
        
        $OPEN CUS3;
        while(1)
        {

           memset(sPrtstr,' ',sizeof(sPrtstr));
           
           $FETCH CUS3 INTO $sIclaim_n,$sFstl,$lIclose_type,$lQinjure,$lQcripple,$lQdeath,
                            $lMinjure,$lMcripple,$lMdeath,$lMins_comp, $lMins_proc,$sDgroup;
                            
printf("iclaim[%s],date[%s]\n",sIclaim_n,sDgroup);                            
           
           if (SQLCODE == SQLNOTFOUND) break;
         
           rstrdate ( sDgroup , &close_date);
           
           $SELECT ibranch_in , fsystem
              INTO $ibranch_in, $fsystem
              FROM ca_clm_process
             WHERE iclaim = $sIclaim_n;
             
           if( SQLCODE == SQLNOTFOUND ) continue;
           
           strcpy( tmp_dbname , get_full_dbname( ibranch_in ));
           
           sprintf_s(stmt_buf3, sizeof stmt_buf3,"SELECT a.iacc_license, a.iacc_birth, a.nacc_driver, a.facc_sex,"
                             "       a.facc_marri, a.facc_nation, a.iacc_reason, a.daccident,"
                             "       a.iacc_area, a.fpart, a.facc_rel, "
                             "       a.facc_duty,"
                             "       a.ipolicy, b.itag, a.icard, a.facc_car, c.fassured, b.icar_type,"
                             "       CASE WHEN d.dpolicy < '08/01/2016' THEN 'Y' ELSE 'N' END,"
                             "       to_char(a.dacc_birth,'%%Y'),to_char(a.dacc_birth,'%%m'),to_char(a.dacc_birth,'%%d') "
                             "  FROM %s:appraisal a, %s:adjustment_ply b, %s:policy c, %s:ply_relation d"
                             " WHERE a.iclaim = b.iclaim AND b.iclaim = ? %s "
                             "   AND a.ipolicy = c.ipolicy "
                             "   AND a.ipolicy = d.ipolicy",
                             tmp_dbname,tmp_dbname,tmp_dbname,tmp_dbname,sWhere1);

           /**printf("stmt_buf3[%s]\n", stmt_buf3);**/
           
           $PREPARE CUS_APPRAISAL from $stmt_buf3;
           $EXECUTE CUS_APPRAISAL INTO $sIacc_license, $sIacc_birth, $sNacc_driver, $sFacc_sex, 
                         $sFacc_marri, $sFacc_nation, $sIacc_reason, $sDaccident, $sIacc_area, 
                         $sFpart, $sFacc_car, $sFacc_duty, $sIpolicy, $sItag , $sIcard, $facc_car, $fassured, $sIcar_type, $chk_dpolicy,
                         $sIacc_birth_yyyy, $sIacc_birth_mm, $sIacc_birth_dd
                    USING $sIclaim_n;
                
           if (SQLCODE == SQLNOTFOUND) continue;
           /*�r�p�H�ϧO*/
         if( fsystem[0] == 'N')
             strcpy( sFacc_car, facc_car);
         else
         {

           switch (sFacc_car[0])
           {
                case '1':
                        break;
                case '2':
                        break;
                case '3':
                        /*�P�Q�O�I�H���Y = "3 ���u"*/
                        /*�r�p�H�ϧO = "4 �����k�H"*/
                        sFacc_car[0] = '4';
                        break;
                case '4':
                        /*�P�Q�O�I�H���Y = "4 ����"*/
                        /*�r�p�H�ϧO = "4 �����k�H"*/
                        sFacc_car[0] = '4';
                        break;
                case '5':
                        /*�P�Q�O�I�H���Y = "5 ��L"*/
                        if( fassured[0] == '1' || fassured[0] == '3' || fassured[0] == '5')
                            sFacc_car[0] = '2'; /*�r�p�H�ϧO = "2 �w���ɥL�H��"*/
                        else
                            sFacc_car[0] = '4'; /*�r�p�H�ϧO = "4 �����k�H"*/
                        break;
                default :
                        sFacc_car[0] = '2';
                        break;
            }
          }


           /* �w�M�P�Ө̷̳s�O�� -- �]���X�I��|���P�� */
           /********
           sprintf_s(stmt_buf4, sizeof stmt_buf4,"SELECT itag FROM %s:policy "
                             " WHERE ipolicy = ?",tmp_dbname);
                             
           $PREPARE CUS_ITAG1 from $stmt_buf4;
           $EXECUTE CUS_ITAG1 INTO $sItag USING $sIpolicy;
           *********/

printf("count[%d]\n",count++);

           sDgroup_mm[0]=sDgroup[0];
           sDgroup_mm[1]=sDgroup[1];
           sDgroup_mm[2]='\0';

           sDgroup_dd[0]=sDgroup[3];
           sDgroup_dd[1]=sDgroup[4];
           sDgroup_dd[2]='\0';

           sDgroup_yyyy[0]=sDgroup[6];
           sDgroup_yyyy[1]=sDgroup[7];
           sDgroup_yyyy[2]=sDgroup[8];
           sDgroup_yyyy[3]=sDgroup[9];
           sDgroup_yyyy[4]='\0';

           iRtnCode = split_policy(sIpolicy, sIpolicy1, sIpolicy2);
           if (iRtnCode != M_CM_OK) break;
           
           
           company_flag=sIpolicy1[7];
       
           strcpy(COMPANY,companyid);
           strcpy(COMPANY_F,companyid);

           strcpy( sIclaim, sIclaim_n);

           if(strcmp( companyid,"17")==0)
           {
               
               if(company_flag > 65 )
               {  
                    $select ipolicy_a
                      into $sIpolicy1
                      from conv_ipolicy
                     where ipolicy_n = $sIpolicy1;
                 
                    strcpy(COMPANY,"16");
               }
           
               iclaim_flag=sIclaim_n[6];
           
               if(iclaim_flag > 65 )
               {  
                    $select distinct iclaim_a
                      into $sIclaim
                      from conv_iclaim
                     where iclaim_n = $sIclaim_n;
          
                    strcpy(COMPANY_F,"16");
               }
             }
                
           if(iFetch)
           {
                old_close_date = close_date;
                iFetch = FALSE;
          
             if (strcmp(option,"4")==0 || strcmp(option,"5")==0) {
                cm_split_ymd_100(datebgn,day_yy,day_mm,day_dd);
          
                sprintf_s(Tmp1, sizeof Tmp1,"is%s%s_%s%s%sc",opt,companyid,day_yy,day_mm,
                        day_dd);
                strcpy(iply_type,opt);
                strcpy(fcard_class, "1");
          
                sprintf_s(file0, sizeof file0,"%s/rptftp/%s",trim(sApHome),Tmp1);
printf("in Fetch-1, option=4 or 5, filename[%s]\n",file0);
printf("file0[%s] Tmp1[%s]\n",file0,Tmp1);
                fptr=fopen(file0,"a+");
             }
             else {
                strcpy( close_date_c , cm_cdate_str_100( close_date ));
                
                printf("close_date_c [%s]\n",close_date_c);
          
                cm_split_ymd_100(close_date_c,day_yy,day_mm,day_dd);
          
                sprintf_s(Tmp1, sizeof Tmp1,"is%s%s_%s%s%sc",opt,companyid,day_yy,day_mm,
                        day_dd);
                strcpy(iply_type,opt);
                strcpy(fcard_class, "1");
          
                sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);

printf("in Fetch-2, option=4 or 5, filename[%s]\n",file0);   
printf("STL in iFetch file0[%s] Tmp1[%s]\n",file0,Tmp1);
                
                $SELECT qcount
                   INTO $qcount
                   FROM TRADE_COUNT 
                  WHERE file_name = $Tmp1;
                
                if ( SQLCODE == SQLNOTFOUND ) fptr=fopen(file0,"w");
                else  fptr=fopen(file0,"a+");
             }
           }
           if ( old_close_date != close_date ) /* �����ثefile , open a new file*/
           {
           if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0)
           {  /* ���e�έ簣���e�����̤�������ɮ� */
                if (cntrlrec > 0)
                {
                    /* ���w�M�Acheck�O�_�����M */                      
                    $SELECT qcount 
                       INTO $qcount
                       FROM TRADE_COUNT 
                      WHERE file_name = $Tmp1;
                    
                    if ( SQLCODE == SQLNOTFOUND ) qcount=0;
                    
                    qcount += cntrlrec;
                    
printf("���w�M�B�����M,Tmp1[%s]\n",Tmp1);               
                    $UPDATE TRADE_COUNT /* ���w�M�B�����M*/
                     SET ( qcount, Tamount, Tinjure, Tcripple, Tdeath ) =
                         ( $qcount, $prem_total, $Tinjure, $Tcripple, $Tdeath )
                     WHERE file_name = $Tmp1;  
                     
                    if ( sqlca.sqlerrd[2] == 0 )
                    {    /* ���w�M�B�L���M */
printf("���w�M�B�L���M,Tmp1[%s]\n",Tmp1);                     
                         $INSERT INTO TRADE_COUNT
                                 ( file_name, policy_day, qcount, Tamount, 
                                   Tinjure, Tcripple, Tdeath )
                          VALUES
                                 ( $Tmp1, $old_close_date, $qcount, $prem_total, 
                                   $Tinjure, $Tcripple, $Tdeath );
                    }                     
                 }
        
               fclose(fptr);
                        
               /*rtncode = rptftpinsert( userid , "car9973" , Tmp1 );
     
               $SELECT policy_day, qcount, Tamount, Tinjure, Tcripple, Tdeath
                  INTO $policy_day, $qcount, $Tamount, $Tinjure, $Tcripple, $Tdeath
                  FROM TRADE_COUNT
                 WHERE file_name = $Tmp1;
               
               printf("prepare insert ca_trade_exam[%d] \n",policy_day);
               
               $insert into ca_trade_exam
                        (iply_type,dpolicy,fcard_class,itrans_type,
                         qcount,mamount,minjure,mcripple,mdeath)
                  values
                        ($iply_type,$policy_day,$fcard_class,0,
                         $qcount,$Tamount,$Tinjure,$Tcripple,$Tdeath);
               
               sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%d",file0,qcount);
               WRITELOG(errfpt , strlog);*/

               strcpy( close_date_c , cm_cdate_str_100( close_date ));
          
               cm_split_ymd_100(close_date_c,day_yy,day_mm,day_dd);
          
               sprintf_s(Tmp1, sizeof Tmp1,"is%s%s_%s%s%sc",opt,companyid,day_yy,day_mm,
                       day_dd);
               strcpy(iply_type,opt);
               strcpy(fcard_class, "1");
          
               sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
   
printf("in Fetch-3, option=4 or 5, filename[%s]\n",file0);
printf("in change file0[%s] Tmp1[%s]\n",file0,Tmp1);
               
               $SELECT qcount
                   INTO $qcount
                   FROM TRADE_COUNT 
                  WHERE file_name = $Tmp1;
                
                if ( SQLCODE == SQLNOTFOUND ) fptr=fopen(file0,"w");
                else  fptr=fopen(file0,"a+");
         
               cntrlrec = 0;
               prem_total = 0;
               qcount = Tamount = Tinjure = Tcripple = Tdeath = 0;

           }
           }

           old_close_date = close_date;
           
           strcpy(sPrtstr,"9"); sPrtstr[1]='\0';                    /*C1-C1:���ʧO*/
           if (*sFstl=='1') strcat(sPrtstr,"2");                    /*C2-C2:�߮שʽ�N��*/
           else  strcat(sPrtstr,"3");                               
           sPrtstr[2]='\0';
           strcat(sPrtstr,COMPANY_F); sPrtstr[4]='\0';              /*C3-C18:���q�O + �߮ר��z��*/
           strncat(sPrtstr,sIclaim,14);
           sPrtstr[18]='\0';                              
           strcat(sPrtstr,COMPANY_F); sPrtstr[20]='\0';             /*C19-C34:���q�O + �߮׸�*/
           strncat(sPrtstr,sIclaim,14); sPrtstr[34]='\0';

           rfmtlong(lIclose_type,"&&&&&",sIclose_type);
           strcat(sPrtstr,sIclose_type); sPrtstr[39]='\0';          /*C35-C39:�߰l����*/

           strcat(sPrtstr,sDgroup_yyyy);                            /*C40-C47:���פ��*/
           strcat(sPrtstr,sDgroup_mm);                  
           strcat(sPrtstr,sDgroup_dd);                  
           sPrtstr[47]='\0';

           strcat(sPrtstr,COMPANY); sPrtstr[49]='\0';               /*C48-C64:���q�O + �O�渹*/

           strcat(sPrtstr,sformat_trade(sIpolicy1 ,2 ,15));
           sPrtstr[64]='\0';                               

printf("sPrtstr[%s]\n",sPrtstr);

           if (strlen(rtrim(sIpolicy2)) > 0)                        /* ���j�O��*/
           {
               strcpy(sObjno, sformat_trade(sIpolicy2, 2, 4));
           }
           else
           {
               strcpy(sObjno,"0001");
           }
           strcat(sPrtstr,sObjno); sPrtstr[68]='\0';                /*C65-C68:�Ъ���*/

           /* ����27,���P���X�M�� modify by sylvia 101.02.24 (1001005007_C1)
           if ((strlen(sItag)<=0) || ((strcmp(sIcar_type, "27") == 0) && strcmp(chk_dpolicy,"Y") == 0)) */

           /* 1061102009_C1 �ק�ǰe���T27���ؾ��񨮵P�W�h */
           if (strlen(sItag)<=0)
              strcpy(sItag, "        ");                            
              
           strcat(sPrtstr,sItag); sPrtstr[80]='\0';                 /*C69-80:�P�Ӹ�*/

              strcat(sPrtstr,sIacc_license); sPrtstr[90]='\0';      /*C81-90:�r��*/
              /*strncpy(sIacc_birth_yy,sIacc_birth,2);                /*C91-98:�ͤ�
              sIacc_birth_yy[2]='\0';
              sIacc_birth_mm[0]=sIacc_birth[2];
              sIacc_birth_mm[1]=sIacc_birth[3];
              sIacc_birth_mm[2]='\0';
              sIacc_birth_dd[0]=sIacc_birth[4];
              sIacc_birth_dd[1]=sIacc_birth[5];
              sIacc_birth_dd[2]='\0';
              strcpy(sIacc_birth_yyyy, itoa(1911+atoi(sIacc_birth_yy)));*/
              strncat(sPrtstr,sIacc_birth_yyyy, 4);  sPrtstr[94]='\0';   
              strcat(sPrtstr,sIacc_birth_mm); sPrtstr[96]='\0';
              strcat(sPrtstr,sIacc_birth_dd);  sPrtstr[98]='\0';
              
              sprintf_s(sNacc_driver_tmp, sizeof sNacc_driver_tmp,"%-200.200s",rtrim(sNacc_driver));
              strcat(sPrtstr,sNacc_driver_tmp); sPrtstr[298]='\0';      /*C99-118:�m�W*/
              strcat(sPrtstr,sFacc_sex); sPrtstr[299]='\0';         /*C119-119:�ʧO*/
              strcat(sPrtstr,sFacc_marri); sPrtstr[300]='\0';       /*C120-120:�B��*/
              strcat(sPrtstr,sFacc_nation); sPrtstr[301]='\0';      /*C121-121:��O*/
              strcat(sPrtstr,sIacc_reason); sPrtstr[303]='\0';      /*C122-123:�X�I��]*/

              rfmtlong(0,"&&&",sQinjure_1);
              rfmtlong(0,"&&&",sQdeath_1);
              rfmtlong(0,"&&&",sQcripple_1);
              strcat(sPrtstr,sQinjure_1); sPrtstr[306]='\0';        /*C124-126:���*/
              strcat(sPrtstr,sQdeath_1); sPrtstr[309]='\0';         /*C127-129:���`*/
              strcat(sPrtstr,sQcripple_1); sPrtstr[312]='\0';       /*C130-132:�ݼo*/

              strncat(sPrtstr,sDaccident,4); sPrtstr[316]='\0';     /*C133-144:�X�I����ɶ�(YYYYMMDDHHMM)*/
              strncat(sPrtstr,(sDaccident+5),2); sPrtstr[318]='\0';
              strncat(sPrtstr,(sDaccident+8),2); sPrtstr[320]='\0';
              strncat(sPrtstr,(sDaccident+11),2); sPrtstr[322]='\0';
              strcat(sPrtstr,"00"); sPrtstr[324]='\0';

              /* �N�{��u�a�ϥN�����v���R���N��42�u�x�����v�B�N��63�u�x�n���v�B�N��65�u�������v�C*/
              if( strcmp( sIacc_area, "42") == 0)
                  strcpy( sIacc_area, "41");
              else if( strcmp( sIacc_area, "63") == 0)
                  strcpy( sIacc_area, "62");
              else if( strcmp( sIacc_area, "65") == 0)
                  strcpy( sIacc_area, "64");

              strcat(sPrtstr,sIacc_area); sPrtstr[326]='\0';        /*C145-146:�X�I�a�ϥN��*/

              if (*sFpart=='1' || *sFpart=='2' || *sFpart=='3')
                  sFpart_A[0]='1';
              else
                  sFpart_A[0]='2';

             strcat(sPrtstr,sFpart_A);                                      /*C147-147:���l���l�O�N��*/
             sPrtstr[327]='\0';

             strcat(sPrtstr,COMPULSORY); sPrtstr[329]='\0';         /*C148-149:�O�I�����N��*/

              rfmtlong(lQinjure,"&&&",sQinjure);
              rfmtlong(lQdeath,"&&&",sQdeath);
              rfmtlong(lQcripple,"&&&",sQcripple);
              rfmtlong(lMinjure,"&&&&&&&",sQinjure_stl);
              rfmtlong(lMdeath,"&&&&&&&",sQdeath_stl);
              rfmtlong(lMcripple,"&&&&&&&",sQcripple_stl);
              lMins_stl = lMinjure + lMdeath + lMcripple;

              Tinjure  += lMinjure;
              Tdeath   += lMdeath;
              Tcripple += lMcripple;
              prem_total += lMins_stl;
              
              strcat(sPrtstr,sQinjure);  sPrtstr[332]='\0';         /*C150-152:���*/
              strcat(sPrtstr,sQdeath);   sPrtstr[335]='\0';         /*C153-155:���`*/
              strcat(sPrtstr,sQcripple); sPrtstr[338]='\0';         /*C156-158:�ݼo*/              
              strcat(sPrtstr,"            "); sPrtstr[350]='\0';    /*C159-170:�w���l�����B*/
              
              rfmtlong(0,"&&&&&&&",sMins_dedu);
              strcat(sPrtstr,sMins_dedu); sPrtstr[357]='\0';        /*C171-177:�z�ߦۭt�B*/
              
              rfmtlong(lMins_stl,"&&&&&&&&&&&&",sMins_stl);
              strcat(sPrtstr,sMins_stl); sPrtstr[369]='\0';         /*C178-189:��ڲz�ߪ��B/�l�v���B*/     
              
              
              strcat(sPrtstr,sQinjure_stl); sPrtstr[376]='\0';      /*C190-196:��˲z�ߪ��B*/
              strcat(sPrtstr,sQdeath_stl); sPrtstr[383]='\0';       /*C197-203:���`�z�ߪ��B*/
              strcat(sPrtstr,sQcripple_stl); sPrtstr[390]='\0';     /*C204-210:�ݼo�z�ߪ��B*/
              
              rfmtlong(lMins_comp,"&&&&&&&&&&&&",sMins_comp);
              strcat(sPrtstr,sMins_comp); sPrtstr[402]='\0';        /*C211-222:�M�Ѫ��B*/
              rfmtlong(lMins_proc,"&&&&&&&",sMins_proc);
              strcat(sPrtstr,sMins_proc);  sPrtstr[409]='\0';       /*C223-229:�z�߶O��*/
              
              strcat(sPrtstr,sDgroup_yyyy);                         /*C230-237:�w�����YYYYMMDD*/
              strcat(sPrtstr,sDgroup_mm);                  
              strcat(sPrtstr,sDgroup_dd);                  
              sPrtstr[417]='\0';
              
              strcat(sPrtstr,sFacc_car); sPrtstr[418]='\0';         /*C238-238:�r�p�H�ϧO*/ 
              strcat(sPrtstr,sFacc_duty); sPrtstr[419]='\0';        /*C239-239:�F�d*/
              strcat(sPrtstr,COMPANY); sPrtstr[421]='\0';
              strcat(sPrtstr,sIcard); sPrtstr[436]='\0';            /*C240-256:���q�O + �j��O�I����*/
              
              fprintf(fptr,"%s\n",sPrtstr);
              cntrlrec++;
       }  
       $CLOSE CUS3;
       $FREE  CUS3;
     
       $DROP TABLE STLCOMP;
printf ("RElstl_comp[%ld]\n",cntrlrec);
       
       fclose(fptr);

     
     if (cntrlrec > 0)
     {
        
        $SELECT qcount
           INTO $qcount
           FROM TRADE_COUNT 
          WHERE file_name = $Tmp1;
                
         if( SQLCODE == SQLNOTFOUND )  qcount=0;
         
         qcount += cntrlrec;          
                
        $UPDATE TRADE_COUNT 
            SET ( qcount, Tamount, Tinjure, Tcripple, Tdeath ) =
                ( $qcount, $prem_total, $Tinjure, $Tcripple, $Tdeath )
          WHERE file_name = $Tmp1;
        
        if ( sqlca.sqlerrd[2] == 0 )
        {
           $INSERT INTO TRADE_COUNT
                      ( policy_day, file_name, qcount, Tamount, Tinjure, Tcripple, Tdeath )
                 VALUES
                      ( $close_date, $Tmp1, $qcount, $prem_total, $Tinjure, $Tcripple, $Tdeath );
        }
      }
          

     /* �ΨӲέp�ɮ׳̫᪺���� */            
        rstrdate( sDappraisal_bgn , &tmp_date ); 
printf("dappraisal_begin[%s]\n",sDappraisal_bgn);

        $SELECT COUNT(*) INTO $cnt
         from trade_count  
         WHERE policy_day >= $tmp_date;
         
printf("count[%d]\n",cnt);                                                         
                      
        $DECLARE CUS_FILE CURSOR for 
         SELECT policy_day, file_name, sum(qcount)
           FROM TRADE_COUNT
          WHERE policy_day >= $tmp_date
          GROUP BY 1,2
          ORDER BY 1,2;  
          
        $OPEN CUS_FILE;
        while(1)
        {         
            $FETCH CUS_FILE INTO $close_date, $Tmp1, $cntrlrec;                        
            
            if( SQLCODE == SQLNOTFOUND )
            {
               if (cnt < 1)
               {
                /* cnt < 1�N���L��� */

		   printf("into cursor option[%s]\n",option);
		  if (strcmp(option,"4") != 0 && strcmp(option,"5") != 0)
		  {
                       $insert into ca_trade_exam
                             (iply_type,dpolicy,fcard_class,itrans_type,
                              qcount,mamount,minjure,mcripple,mdeath)
                        values
                             ($opt,$sDappraisal_end,'1',0,
                              0,0,0,0,0);  
                        sprintf_s(strlog, sizeof strlog,"���ɧ���:%d��",cnt);
                        WRITELOG(errfpt , strlog);                    
		  }
               }               
               break;
            }
             
             strcpy( close_date_c , cm_cdate_str_100( close_date ));
             strcpy(Tmp1,trim(Tmp1));
printf("Final step 1 date[%s], rec[%d]\n",close_date_c,cntrlrec);
printf("tmp1[%s]\n",Tmp1);
                                              
           cm_split_ymd_100(close_date_c,day_yy,day_mm,day_dd);
           /*sprintf_s(Tmp1, sizeof Tmp1,"is%s%s_%s%s%sc",opt,companyid,day_yy,day_mm,day_dd);*/
           
           sprintf_s(file0, sizeof file0,"%s/rptftp/%s",sApHome,Tmp1);
           
           fptr=fopen(file0,"a+");
printf("see if it passes...part 1[%s]\n",file0);           
                
           rc = check_if_exist(iply_type,close_date,fcard_class,0);
           if ( rc != M_CM_OK )
                return rc;
printf("see if it passes...part 2\n");                
               
           strcpy(prtstr,"CNTRLREC");
           rfmtlong(cntrlrec,"&&&&&&",cntrlrec_c);
           strcat(prtstr,cntrlrec_c);
           fprintf(fptr, "%s\n", prtstr);
           
printf("file0[%s]  prtstr[%s]\n",file0, prtstr);
printf("### cntrlrec=[%s]\n",cntrlrec_c);          
        
           fclose(fptr);
     
           rtncode = rptftpinsert( userid , "car9973" , Tmp1 );
printf("Tmp1==>[%s]\n",Tmp1);
     
           $SELECT policy_day, qcount, Tamount, Tinjure, Tcripple, Tdeath
              INTO $policy_day, $qcount, $Tamount, $Tinjure, $Tcripple, $Tdeath
              FROM TRADE_COUNT
             WHERE file_name = $Tmp1;
               
printf("last--dpolicy[%d]file[%s]count[%d]\n",policy_day,Tmp1,qcount);
           if ( SQLCODE!=SQLNOTFOUND &&
                ( strcmp(option,"4") != 0 && strcmp(option,"5") != 0 ))
           /* �C��e�����, �Y����ca_tmp_no����ƫh����insert */ 
           {
                $insert into ca_trade_exam
                       (iply_type,dpolicy,fcard_class,itrans_type,
                        qcount,mamount,minjure,mcripple,mdeath)
                 values
                       ($iply_type,$policy_day,$fcard_class,0,
                        $qcount,$Tamount,$Tinjure,$Tcripple,$Tdeath);   
            }
     
            sprintf_s(strlog, sizeof strlog,"���ɧ���:%s ���:%d",file0,qcount);
            WRITELOG(errfpt , strlog);
        } 
        $CLOSE CUS_FILE;
        $FREE CUS_FILE;  
        
        $DELETE FROM TRADE_COUNT WHERE 1=1;
     
     printf("errfpt[%s]\n",strlog);
          
     return(SUCCESS);
     
     
errexit:
    
    printf("car9973comp_stl_ins:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    rc = SQLCODE;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    
    return rc;
}

long check_if_exist( iply_type, dpolicy, fcard_class, trans_type )
$char *iply_type;
$int dpolicy;
$char *fcard_class;
$int trans_type;
{
   
   $long trade_count, err_count, out_count;
   
   if ( strcmp(option,"4") == 0 || strcmp(option,"5") == 0)  /* �Y����ca_tmp_no����ƫh����check */ 
       return M_CM_OK;

   printf("iply_type[%s] dpolicy[%d]\n",iply_type,dpolicy);
   printf("fcard_class[%s] trans_type[%d]\n",fcard_class,trans_type);
   
   
   $SELECT qtradevan, qerr, qout
      INTO $trade_count, $err_count, $out_count
      FROM ca_trade_exam 
     WHERE iply_type = $iply_type
       AND dpolicy = $dpolicy
       AND fcard_class = $fcard_class 
       AND itrans_type = $trans_type;
  
    if ( SQLCODE == SQLNOTFOUND )  return M_CM_OK;      
    
   printf("trade_count[%d] [%d] [%d]\n",trade_count,err_count,out_count);
   
        
   if ( trade_count==0 && err_count==0 && out_count==0 )
   {
       
       $DELETE FROM ca_trade_exam 
         WHERE iply_type = $iply_type
           AND dpolicy = $dpolicy
           AND fcard_class = $fcard_class 
           AND itrans_type = $trans_type;
           
        return M_CM_OK; 
   
   }
   
   strcpy(sqlca.sqlerrm ,"�L�k���J�s�C - �b UNIQUE INDEX ��즳���Э�");
   
   return 239;
   
errexit:
    printf("check_if_exist:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    rc = SQLCODE;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return rc;  
   
}





void GetLostAppData()
{

char *bp;
char  filename[100];
char  filefull[200];
$char stmt[2048];
$char dwork[11];
$char yyyy[5];
$char yyy[4];
$char mm[3];
$char dd[3];
$char sDateTmp[11];
$char tiins_ply[3];
$char tiins_type[3];
$char tflag[2];
$char ticlaim[12];

FILE  *fp;
int   flen;
int   i,j,k;


   $WHENEVER SQLERROR GOTO errexit;

   printf("into GetLostAppData()\n");

   flen = 300;

   sprintf_s(stmt, sizeof stmt,
    " select first 1 dwork   \
        from cm_wrktbl       \
       where dwork < '%s'    \
         and fwork = '0'     \
       order by dwork desc  ",sDappraisal_bgn); 
 
   printf("sDappraisal_bgn[%s]\n",sDappraisal_bgn);
 
   $prepare wrk_id from $stmt;
   $execute wrk_id 
       into $dwork;

   if (SQLCODE == SQLNOTFOUND)
   {
      strcpy(dwork,"");
      return(FALSE); 
   }
   strcpy(lastdwork,dwork);

   printf("SQLCODE[%d],dwork[%s]\n",SQLCODE,dwork);

   strncpy(mm,dwork,2);
   mm[2] = '\0';

   printf("mm[%s]\n",mm);

   strncpy(dd,dwork+3,2);
   dd[2] = '\0';

   printf("dd[%s]\n",dd);

   strncpy(yyyy,dwork+6,4);
   yyyy[4] = '\0';

   printf("yyyy[%s]\n",yyyy);

   strcpy(yyy,itoa( atoi(yyyy)-1911 ));

   printf("yyy[%s]\n",yyy);

   strcpy(sDateTmp,yyy);
   strcat(sDateTmp,mm);
   strcat(sDateTmp,dd);
 
   strcpy(filename,"is");
   strcat(filename,opt);
   strcat(filename,"17_");

   strcat(filename,sDateTmp);
   strcat(filename,"c");

   printf("filename[%s]\n",filename);

   sprintf_s(filefull, sizeof filefull,"%s/rptftp/%s",sApHome,filename);
   strcpy(filefulllast,filefull);
   
   printf("filefull[%s]\n",filefull);

   if ((fp=fopen(filefull,"r"))==NULL)
   {
       sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���\n",filefull);
       return(FALSE); 
   }

   if ((bp=malloc(flen))==NULL)
   {
       strcpy(msgbuf,"System malloc failed !\n");
       return(FALSE);
   }
 
   printf("filefull[%s]\n",filefull);


   $create temp table t997_temp
   (
      iclaim       char(20)
   )with no log;

   $create index t997_temp_ix1 on t997_temp(iclaim);


   j = 0; 
   k = 0;
   for(i=0;(feof(fp)==0);i++) 
   {
      memset(bp,0x00,flen);
      fgets(bp,flen,fp);
      if (bp[0]==0x00)
           break;

      memcpy(tflag,bp+1,1);
      tflag[1] = '\0';

      printf("tflag[%s]\n",tflag);

      if (tflag[0] == '1')
      {
         memcpy(ticlaim,bp+4,11);
         ticlaim[11] = '\0';

         printf("ticlaim[%s]\n",ticlaim);
         $insert into t997_temp values ($ticlaim);
         itmpcnt++;
      }
   }

   return(SUCCESS);

errexit:
   printf("car9973comp_GetLostAppData:sqlcode=%d, sqlmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   rc = SQLCODE;
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return rc;
}

