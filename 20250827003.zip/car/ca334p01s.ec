/*-------------------------------------------------------------------
 * Program: ca334p01s.ec
 * �x�sñ������ 
 *-------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
$include sqlca;
$include sqltypes;
$include "ca334.h";

#define FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND
#define SPACE                   " "
#define HAVE_DELIMITER
#define DELIMITER		"|"

/*****************************************************************/

$char  DBName[5];
$char  userid[11];
char   sBegin[11], sEnd[11];
char   sOpt[1];
char   sOfficer[11];
char   outputf[50];

FILE   *fptr1, *fptr2, *sfp;

int    rc = 0;

$char  BodyFile[21],TitleFile[21],BodyFmt[21],FormTp[3];
$char  TitleFmt[21],prtstr[10000];
$char  FormFmt[N_FILE+1];
char   FormFile[N_FILE+1], OutFile[20];
$int   ItemRow, TotColumn;
$int   StartRow,TitleRow;
$int   PgLine, Width;
$char  sMsg[512];
$char  sPERIOD2[3];
$char  sIroute_main[21], sIroute_prop[3], sTmpstr[41];

/* �s�¶O�v�P�_ */
int flag_new = 0;

/*****************************************************************/
void init_column();

main(argc,argv)
int  argc;
char **argv;
{
    long src;

    batchinit();
    strcpy( DBName,  isNULLstr(argv[1]));
    strcpy( userid,  isNULLstr(argv[2]));
    strcpy( sOpt,    isNULLstr(argv[3])); /* 0:�x�s����ñ�������; 1:�x�s�@���ñ������� */
    strcpy( sBegin,  isNULLstr(argv[4])); /* ñ����_ */ 
    strcpy( sEnd,    isNULLstr(argv[5])); /* ñ���騴 */
    strcpy( sOfficer,isNULLstr(argv[6])); /* �g��H�N�� */
    /*strcpy( sIroute_main,isNULLstr(argv[7])); /* �D�q���N�� */
    /*strcpy( sIroute_prop,isNULLstr(argv[8])); /* �q���ۭq�~�ȱ��� */
    strcpy( outputf, isNULLstr(argv[7]));




    printf("DBName[%s]\n", DBName);
    printf("userid[%s]\n", userid);
    printf("sOpt[%s]\n", sOpt);
    printf("sBegin[%s]\n", sBegin);
    printf("sEnd[%s]\n", sEnd);
    printf("sofficer[%s]sIroute_main=[%s]sIroute_prop=[%s]\n", sOfficer,sIroute_main,sIroute_prop);
    printf("outputf[%s]\n", outputf);

    $WHENEVER SQLERROR GOTO errexit;

    sfp = STARTLOG();
    puts("End STARTLOG");
    if (db_select(DBName) == False)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }
    puts("End db_select");
    
    if(strcmp(sOpt,"0")==0) /*����*/
    {
    	src = get_TS();
    }
    else                    /*�@���*/
    {
    	src = get_TS1(); 
    }

      
    if (src != M_CM_OK)
    {
        EWRITE(userid, src, sMsg);
        return src;
    }

    WRITELOG( sfp, "���槹�� ");
    ENDLOG(sfp);
    return M_CM_OK;

errexit:
    printf("------car334_err: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    exit(1);
}

char writeStr   [4096];
char writeStrDtl[4096];

/***********************************************************************/
void init_column()
{
    int iTmp = 0;

    flag_new = 0;
    sCOMPANY     [0]='\0';     /* 1. ���q�O                       */
    sPRODUCT     [0]='\0';     /* 2. �O�I���~�O                   */
    sTARGET      [0]='\0';     /* 3. �O�I�Ъ�                     */
    sSERIAL      [0]='\0';     /* 4. �Ǹ�                         */
    sPOLICY      [0]='\0';     /* 5. �O�渹�X                     */
    sENDORSE     [0]='\0';     /* 6. ��渹�X                     */
    sASSURED     [0]='\0';     /* 7. �Q�O�I�H�����Ҧr��           */
    sNASSURED    [0]='\0';     /* 8. �Q�O�H�m�W                   */
    sBIRTHDAY    [0]='\0';     /* 9. �Q�O�I�H�X�ͤ��             */
    sPAY         [0]='\0';     /* 10.�I�ڤH�m�W                   */
    sPAY_ID      [0]='\0';     /* 11.�I�ڤH�����Ҧr��             */
    sCARD        [0]='\0';     /* 12.�I�ڤH�d��                   */
    sEFFECT      [0]='\0';     /* 13.�H�Υd���Ĵ���               */
    sACCOUNT     [0]='\0';     /* 14.�I�ڤH�b��                   */
    sBEGIN       [0]='\0';     /* 15.�O�I�l��                     */
    sEND         [0]='\0';     /* 16.�O�I�״�                     */
    sPERIOD      [0]='\0';     /* 17.��O�~��(�O�I����)           */
    sAREA        [0]='\0';     /* 18.�a�ϧO�N�X                   */
    sPAY_WAY     [0]='\0';     /* 19.ú�O�覡                     */
    sPAY_TYPE    [0]='\0';     /* 20.ú�O�O                       */
    sPAY_PERIOD  [0]='\0';     /* 21.ú�O����                     */
    sREL         [0]='\0';     /* 22.�I�ڤH�P�Q�O�H���Y           */
    sZIP         [0]='\0';     /* 23.�l���ϸ�                     */
    sADDRESS     [0]='\0';     /* 24.�q�T�a�}                     */
    sTEL_O_1     [0]='\0';     /* 25.���q�q�ܰϽX                 */
    sTEL_O       [0]='\0';     /* 26.���q�q��                     */
    sTEL_H_1     [0]='\0';     /* 27.���a�q�ܰϽX                 */
    sTEL_H       [0]='\0';     /* 28.���a�q��                     */
    sCELL_PHONE  [0]='\0';     /* 29.��ʹq��                     */
    sEMAIL       [0]='\0';     /* 30.E-Mail�H�c                   */
    sBIRTHDAY_PAY[0]='\0';     /* 31.�I�ڤH�X�ͦ~���(���d�H�ͤ�) */
    sINSURANT    [0]='\0';     /* 32.�n�O�H�m�W                   */
    sINSURANT_ID [0]='\0';     /* 33.�n�O�HID                     */
    sINSURANT_REL[0]='\0';     /* 34.�n�O�H�P�Q�O�H���Y�N�X       */
    sPREM_ORI    [0]='\0';     /* 35.��l�O�O(��)                 */
    sPREM        [0]='\0';     /* 36.�馩��O�O(��)               */
    sDISC_M      [0]='\0';     /* 37.�馩���B                     */
    sDISC_P      [0]='\0';     /* 38.�馩�v                       */
    sPAY_DAY     [0]='\0';     /* 39.�Ĥ@��ú�O���(�w����)       */
    sDPOLICY     [0]='\0';     /* 39.ñ���                       */
    sPAY_AMT     [0]='\0';     /* 40.�Ĥ@��ú�O���B               */
    sDUE         [0]='\0';     /* 41.�Ĥ@��ú�O�䲼�����         */
    sCOMMI_P     [0]='\0';     /* 42.�����v                       */
    sCOMMI_M     [0]='\0';     /* 43.����                         */
    sISSUE       [0]='\0';     /* 44.�o�Ӥ��                     */
    sTAG         [0]='\0';     /* 45.�P�Ӹ��X                     */
    sCANCEL      [0]='\0';     /* 46.�h�O���                     */
    sEDR_TYPE    [0]='\0';     /* 47.���ƥ�                     */
    sEDR_CONTENT [0]='\0';     /* 48.���ק鷺�e                 */
    sREMARK      [0]='\0';     /* 49.�Ƶ�                         */
    sTARGET_ADD  [0]='\0';     /* 50.�Ъ����Ҧb�a�}               */
    sLAST_PLY    [0]='\0';     /* 51.�e�@�~�׫O�渹�X             */
    
    
    /*sSALES_CODE  [0]='\0';      ���ˤHSOURCE CODE            
    sSALES_NAME  [0]='\0';     /* ���ˤH�m�W                   
    sSALES_ID    [0]='\0';     /* ���ˤH���s/ID                
    sACCEPT      [0]='\0';     /* RMS�s��(����s��)            
    sSALE_SERIAL [0]='\0';     /* ��P�Ǹ�                     */
            
    sCOMPANY_1   [0]='\0';     /* ���q�O                       */
    sPRODUCT_1   [0]='\0';     /* �O�I���~�O                   */
    sPOLICY_1    [0]='\0';     /* �O�渹�X                     */
    sENDORSE_1   [0]='\0';     /* ��渹�X                     */
    sBEGIN_1     [0]='\0';     /* ��O�l��                     */
    sPAY_DAY_1   [0]='\0';     /* �Ĥ@��ú�O���               */
    sPAY_AMT_1   [0]='\0';     /* �Ĥ@��ú�O���B               */
    sDUE_1       [0]='\0';     /* �Ĥ@��ú�O�䲼�����         */
    sPAY_PERIOD_1[0]='\0';     /* ú�O���O                     */
    sPAY_WAY_1   [0]='\0';     /* ú�O�覡                     */
    sPAY_TYPE_1  [0]='\0';     /* ú�O�O                       */
    
    /* ���������� */                         
    sIAPPLICANT  [0]='\0';     /* �n�O�HID 		       */                     
    sNAPPLICANT  [0]='\0';     /* �n�O�H�m�W                   */ 
    sDINVITE     [0]='\0';     /* ������   		       */
    sRECOMMEND   [0]='\0';     /* ���ˤH�N��(�x�s����) 	       */ 

}
/*--------------------------------------------------------------------*/
int iColumn, len;
/*--------------------------------------------------------------------*/
print_delimiter(int iDetail)
{
/*
    #ifdef HAVE_DELIMITER

        if( iDetail == 0)
            len = len + sprintf_s(writeStr + len, sizeof writeStr + len, "%s", "!");
        else
            len = len + sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len, "%s", "!");

    #endif
*/
}
/*--------------------------------*/
/* �x�s����ñ�������         */ 
/*--------------------------------*/
long get_TS()
{
    char  sFileName[51], sFullFileName[121];
    char  sFileNameDtl[51], sFullFileNameDtl[121];
    long  jdate;
    short mdy_begin[3], mdy_end[3];
    DBinfo  *list;
    int     i, count_db, tmp_period;

    long   rtncode, iWriteCount;
    char   sApHome[51], sDbName[51], sTmp[51];
    $char  sQuery[4096], sTmp1[101], stmt_disc[1024],stmt_dinvite[1024];
    $int   iStart, iLens, iTmp, iCount, iRows;
    $long  iSum = 0;
    
    
   
    /* �����פj��DC�w�q��,�λ��ഫ�̦b���ŧi */

    $char sNassured[121], sAassured[91], sImovephone[21], sIemail[51], sFcard_class[2], sIcar_type[3], sIofficer[11];
    $char sDendorse[9], ply1[POLICY_NUM_1], ply2[POLICY_NUM_2], sRemark[2048], sProduct[11];
    $char temp[21], sIbroker[11], sNassured_t[121], sAassured_t[91], sIemail_t[51], sRemark_t[2048], dInvite[10], sNapplicant[121], sNapplicant_t[121];

    /* �Ʀr���b���ŧi */

    $long   iPrem = 0, iDiscount = 0, iCommi = 0, iPrem_ori, iPeriod;
    $double rPdiscount, rPcommission;

    /* other */    
    $char   taipei_db[11], dbname_tp[20];
    $char   str_comm[10],spayway[2];
    
    /* �s�¶O�v�P�_ */
    $char   f980401[2],drate_ym[5];  
    
    /* �H�Υd����ഫ */
    $char   first_4[5],first_6[7],last_4[5],cred_no[17],first_8[9]; 
    $char   str_effect[7],first_2[3],last_2[3];
    int     int_effect=0;    

    long iLength;
    $WHENEVER SQLERROR GOTO errexit;

    rtncode = getApHome(sApHome);
    if (rtncode < 0)
    {
        sprintf_s(sMsg, sizeof sMsg, "read Config file error !!\n");
        return M_CM_READ_CONFIG_ERR;
    }

    if ( ( list = get_db_list(&count_db, DBName)) == (char*)0 )
    {
        sprintf_s(sMsg, sizeof sMsg, "Cannot get DB LIST \n");
        return M_CM_NOT_DBLIST;
    }

    rtncode = getHeadBranch(taipei_db);
    if (rtncode < 0)
    {
        sprintf_s(sMsg, sizeof sMsg, "getHeadBranch error !!\n");
        return M_CM_READ_CONFIG_ERR;
    }

    /* get TAIPEI's full DB name for abnormal policy */
    strcpy(dbname_tp,get_full_dbname(taipei_db));


    rstrdate( sBegin, &jdate);
    rjulmdy( jdate, mdy_begin);
    rstrdate( sEnd, &jdate);
    rjulmdy( jdate, mdy_end);

    puts("End rjulmdy");

    sprintf_s(sFileName, sizeof sFileName, "car334_%02d%02d_%02d%02d_�����.txt", mdy_begin[0], mdy_begin[1], mdy_end[0], mdy_end[1]);
    sprintf_s(sFullFileName, sizeof sFullFileName, "%s/rptftp/%s", sApHome, sFileName);    

    sprintf_s(sFileNameDtl, sizeof sFileNameDtl, "car334_dtl_%02d%02d_%02d%02d_�����.txt", mdy_begin[0], mdy_begin[1], mdy_end[0], mdy_end[1]);
    sprintf_s(sFullFileNameDtl, sizeof sFullFileNameDtl, "%s/rptftp/%s", sApHome, sFileNameDtl);    

    if ((fptr1=fopen(sFullFileName,"w"))==NULL)
    {
        sprintf_s(sMsg, sizeof sMsg, "Cannot open Output file: %s\n", sFullFileName);
        return M_CM_OPEN_FILE_FAIL;
    }

    if ((fptr2=fopen(sFullFileNameDtl,"w"))==NULL)
    {
        sprintf_s(sMsg, sizeof sMsg, "Cannot open Output file: %s\n", sFullFileNameDtl);
        return M_CM_OPEN_FILE_FAIL;
    }
    
    puts("End open fptr2");

    iWriteCount = 0;

   /* �t�X�q���ĤG���q�i��U�C�ק�:modifyb by sylvia 100.06.03
          �g���H[ibroker ]��H[�D�q���N��(I812)+�q���ۭq�~�ȱ���(06)]���N   
          ��{��:   and a.ibroker[] = 'RZF0016A01' */
   for (i=0;i<count_db;i++)
   {
      
       sprintf_s(sQuery, sizeof sQuery, 
             "select b.itag, a.ipolicy, ' ', b.iassured, b.nassured, to_char(b.dbirth,'%%Y%%m%%d'),"             
             "       TO_CHAR(a.dply_begin, '%%Y%%m%%d'), TO_CHAR(a.dply_end, '%%Y%%m%%d'), "
             "       lpad(case when a.qply_period <= 12 then '1' else '2' end,3,' ')::char(3) as qply_period, "             
             "       b.aassured_zip, b.aassured, b.itel, d.tphone_con, d.imovephone, "
             "       d.iemail, a.mlia_prem + a.mdmg_prem, "
             "       a.mlia_commi + a.mdmg_commi, to_char(b.dissue,'%%Y%%m') || '01',"             
             "       a.ilast_ply, e.nsales, a.ibig_sales, ' ', a.fcard_class, a.icar_type, a.iofficer, a.ibroker, "
             "       a.qply_period ,b.iapplicant, b.napplicant, TO_CHAR(a.dpolicy, '%%Y%%m%%d')  "
             "  from %s:ori_ply_relation a, %s:original_ply b, cm_route_data f, cm_route g, "
             "       outer cu_customer d, outer cm_route_sales e "
             " where a.ipolicy      = b.ipolicy "             
             "   and b.iassured     = d.ifpce_id "
             "   and b.iassured_ext = d.ifpce_id_ext "
             "   and a.ibig_office  = e.iroute "
             "   and a.ibig_sales   = e.isales "
             "   and a.ipolicy[1,13] = f.ipolicy1 "
             "   and a.ipolicy[14,20] = f.ipolicy2 "
             "   and b.iroute = g.iroute "
             "   and g.iroute_main = 'I812' "
             "   and dpolicy between '%s' and '%s' and f.column_10 in ('05','06')  "
             "   and dply_close is not null "
             "   and a.iofficer matches '%s' "
             " union "
             "select b.itag, a.ipolicy, a.iendorse, b.iassured, b.nassured, to_char(b.dbirth,'%%Y%%m%%d'),"             
             "       TO_CHAR(b.dply_begin, '%%Y%%m%%d'), "
             "       TO_CHAR(b.dply_end, '%%Y%%m%%d'), "             
             "       lpad(case when b.qply_period <= 12 then '1' else '2' end,3,' ')::char(3) as qply_period, "
             "       b.aassured_zip, b.aassured, b.itel, d.tphone_con, d.imovephone, "
             "       d.iemail, a.medrlia_prem + a.medrdmg_prem, "
             "       a.medrlia_commi + a.medrdmg_commi, to_char(b.dissue,'%%Y%%m') || '01',"             
             "       (select ilast_ply from ori_ply_relation where ipolicy = a.ipolicy), "
             "       e.nsales, a.ibig_sales, TO_CHAR( a.dendorse, '%%Y%%m%%d') , "
             "       a.fcard_class, a.icar_type, a.iofficer, a.ibroker ,b.qply_period ,b.iapplicant ,b.napplicant, TO_CHAR(c.dpolicy, '%%Y%%m%%d') "
             "  from %s:edr_relation a, %s:endorsement b, %s:ply_relation c, cm_route_data f, cm_route g, "
             "       outer cu_customer d, outer cm_route_sales e "
             " where a.iendorse     = b.iendorse "                          
             "   and b.iassured     = d.ifpce_id "
             "   and b.iassured_ext = d.ifpce_id_ext "
             "   and a.ibig_office  = e.iroute "
             "   and a.ibig_sales   = e.isales "
             "   and a.ipolicy      = c.ipolicy "
             "   and a.ipolicy[1,13] = f.ipolicy1 "
             "   and a.ipolicy[14,20] = f.ipolicy2 "
             "   and b.iroute = g.iroute "
             "   and g.iroute_main = 'I812' "
             "   and a.dendorse between '%s' and '%s' and f.column_10 in ('05','06')  "
             "   and a.iofficer matches '%s' "
             "   and dedr_close is not null ", list[i].dbname, list[i].dbname, sBegin, sEnd, sOfficer,
                                               list[i].dbname, list[i].dbname, list[i].dbname,  sBegin, sEnd, sOfficer);
             /* "   and a.ibroker in ('RD','RDA')"    ����X�w���� */
printf("sQuery[%s]\n",sQuery);
       $prepare prep11 from $sQuery;
       $declare cur11 cursor for prep11;
       $open cur11;
       while(1)
       {   
           init_column();
           strcpy(cred_no,"");
           strcpy(str_effect,"");

           $fetch cur11   into $sTARGET,      $sPOLICY,        $sENDORSE,      $sASSURED,    $sNassured,
                               $sBIRTHDAY,    $sBEGIN,         $sEND,
                               $sPERIOD,      $sZIP,           $sAassured,     $sTEL_O,
                               $sTEL_H,       $sImovephone,    $sIemail,       $iPrem,       
                               $iCommi,       $sISSUE,         $sLAST_PLY,     $sSALES_NAME,
                               $sSALES_ID,    $sDendorse,      $sFcard_class,  $sIcar_type,  $sIofficer, $sIbroker,
                               $sPERIOD2,     $sINSURANT_ID,   $sNapplicant,   $sDPOLICY;

           if (SQLCODE==SQLNOTFOUND) break;
        
           strncpy(ply1, sPOLICY, CAR_POLICY_LEN);
           ply1[CAR_POLICY_LEN]='\0';

           strncpy(ply2, sPOLICY+CAR_POLICY_LEN, CAR_TARGET_LEN);
           ply2[CAR_TARGET_LEN]='\0';

           $SELECT TO_CHAR( dpay, '%Y%m%d')
              INTO $sPAY_DAY 
              FROM policy_main
             WHERE ipolicy1 = $ply1 
               AND ipolicy2 = $ply2
               AND iendorsement = $sENDORSE;

           if (risnull(SQLCHAR, sPAY_DAY) == 1) strcpy(sPAY_DAY, " ");

           sprintf_s(sQuery, sizeof sQuery, "select sum( minjured_cover + mdeath_cover +  mdamage_cover)" 
                            "  from %s:ply_ins_type"
                            " where ipolicy = '%s'", list[i].dbname, sPOLICY);

           printf("sQuery[%s]\n",sQuery);
           $prepare prep33 from $sQuery;
           $execute prep33 into $iSum;
           $free prep33;                     
        
           if( iSum == 0)
               strcpy( sCANCEL, sDendorse); 

           if (risnull(SQLCHAR, sCANCEL) == 1) strcpy(sCANCEL, " ");
           
            /* ���H�Υd��� */
           sprintf_s(sQuery, sizeof sQuery, "select first 1 nvl(a.icreditno,' '), nvl(a.deffect,' ')" 
                            "  from %s:ao_prem_credit a, %s:ao_prem_crd_detail b "
                            "  where b.ipolicy1 = '%s' and b.ipolicy2 = '%s'"
                            "    and b.iendorse = '%s' and a.iserno = b.iserno", 
                            list[i].dbname, list[i].dbname, ply1, ply2, sENDORSE);

           printf("sQuery[%s]\n",sQuery);
           $prepare prep44 from $sQuery;
           $execute prep44 into $cred_no, $str_effect;
           $free prep44;

          
           if (cred_no[0]=='\0' || cred_no[0]==' ')
           {
           	if(iPrem == 0 && strlen(sENDORSE) > 0)
           	{
            		strcpy(sPAY_WAY,"2");
           		strcpy(sCARD,"");
           		strcpy(sEFFECT,"");               		          
                
                }    
           	else
           	{	
           		strcpy(spayway,"");
           		sprintf_s(sQuery, sizeof sQuery, "SELECT first 1 CASE WHEN b.itype_prem IN('2','6') THEN '3' " 
                                	 "             WHEN b.itype_prem = '7' THEN '1'  "
                                	 "             ELSE '2' END  "
                                	 "  FROM  cm_pre_receive  a, %s:ao_prercv_detail b "
                                	 " WHERE  a.ipolicy1 = '%s' AND  a.ipolicy2 = '%s' "
                                	 "        AND  a.iins_kind = '%s' AND  a.iendorse = '%s' "
                                	 "        AND  a.ipre_rcv = b.ipre_rcv AND a.iins_kind = b.iins_kind "
                                 	 "        AND   a.ipre_end = b.ipre_end  group by b.itype_prem ", list[i].dbname, ply1, ply2, sFcard_class, sENDORSE);
                	$prepare prep441 from $sQuery;
                	$execute prep441 into $spayway;
                	$free prep441;  
                	
                	if(strcmp( spayway, "1") == 0 )  /*�H�Υd*/
                	{       	                   
           	     	    strcpy(sPAY_WAY,"1");
           	     	    strcpy(sCARD,"");
           		    strcpy(sEFFECT,"");    	
                	}
                	else
                	{
                	    strcpy(sPAY_WAY,spayway);
           		    strcpy(sCARD,"");
           		    strcpy(sEFFECT,""); 
                	}
           	}
          		
           } 
           else
           {       	                   
           	strcpy(sPAY_WAY,"1");   
                
           }           
           /* end of ���H�Υd��� */

           sprintf_s(sQuery, sizeof sQuery, "select trim( a.iins_type) || trim( b.nins_type),drate_ym "
                            "  from %s:ply_ins_type a, insurance_type b"
                            " where ipolicy = '%s'" 
                            "   and a.iins_type = b.iins_type", list[i].dbname, sPOLICY);
	   printf("sQuery[%s]\n",sQuery);

           $prepare prep44 from $sQuery;
           $declare curs44 cursor for prep44;
           $open curs44;
           sRemark[0] = '\0';
           for(;;)
           {
               $fetch curs44 into $sTmp1,$drate_ym;
   
               if( NOT_FOUND)
                   break;
                   
                $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
                   INTO $f980401
                   FROM ca_rate_date
                  WHERE icode  = $drate_ym
                    AND itable = 'cm_extra_charge';
 
                 if (NOT_FOUND)
                 {
                       sprintf_s(sMsg, sizeof sMsg,"�O�渹[%s]�O�v�N��[%s]���s�b\r\n",sPOLICY,drate_ym);
                       break;
                 }
                 /* �O�v�ۥѤ� */
                 if( f980401[0] == '1') flag_new = 1;

                 strcat( sRemark, trim(sTmp1));
                 strcat( sRemark, " ");
           }
           $free prep44;

           if( sFcard_class[0] == '1')  /*�j��*/
           {               
               if( strncmp( sIcar_type, "01", 2) == 0 ||strncmp( sIcar_type, "02", 2) == 0 ||strncmp( sIcar_type, "32", 2) == 0 ||strncmp( sIcar_type, "34", 2) == 0 )
               {      
                   if (atoi(sPERIOD2)>12) 
                       strcpy( sProduct , "1702");  /*�����j��O�I(�G�~)*/
                   else
                       strcpy( sProduct , "1701");  /*�����j��O�I(�@�~)*/
	       }
               else
               {
               	   strcpy( sProduct , "1705");  /*�T���j��O�I*/
               	
               }       
               
           }
           else      /*���N*/
           {               
               if( strncmp( sIcar_type, "01", 2) == 0 ||strncmp( sIcar_type, "02", 2) == 0 ||strncmp( sIcar_type, "32", 2) == 0 ||strncmp( sIcar_type, "34", 2) == 0 )
               {
                   if (atoi(sPERIOD2)>12) 
                       strcpy( sProduct , "1704");  /*�����r�p�H�ˮ`�O�I(�G�~)*/
                   else
                       strcpy( sProduct , "1703");  /*�����r�p�H�ˮ`�O�I(�@�~)*/	
               }
               else
               {
                   strcpy( sProduct , "1706");  /*�T���r�p�H�ˮ`(��@��q�ƬG)*/
               }
           }
           
           strcpy( sTAG, sTARGET);

           
           /* �줽�q�ܰϸ� */
           if(strncmp(sTEL_O+2, "-",1) == 0)
           {
           	 strncpy(sTEL_O_1, sTEL_O, 2);
           	 sTEL_O_1[2] = 0x0;
           	 
           	 strcpy(temp, sTEL_O+3);
           	 
           	 strcpy(sTEL_O, temp);
           }
           else if (strncmp(sTEL_O+3, "-",1) == 0)
           {
           	 strncpy(sTEL_O_1, sTEL_O, 3);
           	 sTEL_O_1[3] = 0x0;
           	 
           	 strcpy(temp, sTEL_O+4);
           	 
           	 strcpy(sTEL_O, temp);
           }	
           
           	/* ���a�q�ܰϸ� */
           if(strncmp(sTEL_H+2, "-",1) == 0)
           {
           	 strncpy(sTEL_H_1, sTEL_H, 2);
           	 sTEL_H_1[2] = 0x0;
           	 
           	 strcpy(temp, sTEL_H+3);
           	 
           	 strcpy(sTEL_H, temp);
           }
           else if (strncmp(sTEL_H+3, "-",1) == 0)
           {
           	 strncpy(sTEL_H_1, sTEL_H, 3);
           	 sTEL_H_1[3] = 0x0;
           	 
           	 strcpy(temp, sTEL_H+4);
           	 
           	 strcpy(sTEL_H, temp);
           }
           
           /* �B�z�馩���B,�j���I���馩���B�O�~�ȶO��(mbusiness)��W���~�ȶO��(mbus_rule),
              ���N�h���O������馩����� */
           if (strncmp(sFcard_class,"1",1) == 0)
           {
           	  sprintf_s(stmt_disc, sizeof stmt_disc, "select (mbus_rule - mbusiness) "
                                 "  from %s:ori_ply_relation"
                                 " where ipolicy = '%s'" , list[i].dbname, sPOLICY);              
            } else
            {
              sprintf_s(stmt_disc, sizeof stmt_disc, "select (mlia_discount + mdmg_discount) "
                                 "  from %s:ori_ply_relation"
                                 " where ipolicy = '%s'" , list[i].dbname, sPOLICY); 
            }
        
            $prepare prep5 from $stmt_disc;
            $execute prep5 into $iDiscount;
            $free prep5;
           /* end of �B�z�馩���B */
       
           
           /*������*/
           
           sprintf_s(stmt_dinvite, sizeof stmt_dinvite,"SELECT  first 1 case when b.dexamine > c.dcreate then to_char(c.dcreate, '%%Y%%m%%d') "
                                "             when b.dexamine < c.dcreate then to_char(b.dexamine, '%%Y%%m%%d') "
                                "         else to_char(b.dexamine, '%%Y%%m%%d') end "
                   	        "  FROM  cm_pre_receive a,%s:estimate b,%s:ca_quotation c "
                   	        " WHERE  a.ipolicy1 = '%s' AND a.ftype ='P' AND a.ipre_rcv=b.iestimate AND c.iquote=a.ipre_rcv AND iins_kind='%s' "
                   	        , list[i].dbname, list[i].dbname, sPOLICY,sFcard_class);
            $prepare prep51 from $stmt_dinvite;
            $execute prep51 into $dInvite;
            $free prep51;
            strcpy(sDINVITE, dInvite);           
           
         
           
                   
           iColumn = 1;
           writeStr[0] = '\0';
           len = 0;

           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", COMPANY     , COMPANY     , "17"        ); /* ���q�O*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", PRODUCT     , PRODUCT     , sProduct    ); /* �O�I���~�O*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", TARGET      , TARGET      , sTARGET     ); /* �O�I�Ъ�*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", SERIAL      , SERIAL      , " "     );     /* �Ǹ�*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", POLICY      , POLICY      , sPOLICY     ); /* �O�渹�X*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", ENDORSE     , ENDORSE     , sENDORSE    ); /* ��渹�X*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", ASSURED     , ASSURED     , sASSURED    ); /* �Q�O�I�H�����Ҧr��*/
           print_delimiter(  0);                                               
           iLength=cc_split_chinese( sNassured, sNassured_t, NASSURED);
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", NASSURED    , NASSURED    , sNassured_t ); /* �Q�O�H�m�W*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", BIRTHDAY    , BIRTHDAY    , sBIRTHDAY   ); /* �Q�O�I�H�X�ͤ��*/
           print_delimiter(  0);                                               
           iLength=cc_split_chinese( sNassured, sNassured_t, PAY);
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", PAY         , PAY         , sNassured_t   ); /* �I�ڤH�m�W
                                                                                                   (�P�Q�O�H�m�W)*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", PAY_ID      , PAY_ID      , sASSURED    ); /* �I�ڤH�����Ҹ�
                                                                                                   (�P�Q�O�I�Hid)*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", CARD        , CARD        , " "       ); /* �I�ڤH�d��*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", EFFECT      , EFFECT      , sEFFECT     ); /* �H�Υd���Ĵ���*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", ACCOUNT     , ACCOUNT     , " "         ); /* �I�ڤH�b��*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", BEGIN       , BEGIN       , sBEGIN      ); /* �O�I�l��*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", DEND        , DEND        , sEND        ); /* �O�I�״�*/
           print_delimiter(  0);            
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", PERIOD      , PERIOD      , sPERIOD     ); /* ��O�~��(�O�I����)*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", AREA        , AREA        , " "         ); /* �a�ϧO�N�X*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", PAY_WAY     , PAY_WAY     , sPAY_WAY    ); /* ú�O�覡*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", PAY_TYPE    , PAY_TYPE    , "1"         ); /* ú�O�O (1���B)*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", PAY_PERIOD  , PAY_PERIOD  , "1"         ); /* ú�O����*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", REL         , REL         , "01"        ); /* �I�ڤH�P�Q�O�H���Y
                                                                                                   (01���H)*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", ZIP         , ZIP         , sZIP        ); /* �l���ϸ�*/
           print_delimiter(  0);                                               
           iLength=cc_split_chinese( sAassured, sAassured_t, ADDRES);
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", ADDRES      , ADDRES      , sAassured_t ); /* �q�T�a�}*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", TEL_O_1     , TEL_O_1     , sTEL_O_1    ); /* ���q�q�ܰϽX*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", TEL_O       , TEL_O       , sTEL_O      ); /* ���q�q��*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", TEL_H_1     , TEL_H_1     , sTEL_H_1    ); /* ���a�q�ܰϽX*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", TEL_H       , TEL_H       , sTEL_H      ); /* ���a�q��*/
           print_delimiter(  0);                                               
           sImovephone[ CELL_PHONE] = '\0';                                    
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", CELL_PHONE  , CELL_PHONE  , sImovephone ); /* ��ʹq��*/
           print_delimiter(  0);                                               
           iLength=cc_split_chinese( sIemail, sIemail_t, EMAIL);
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", EMAIL       , EMAIL       , sIemail_t   ); /* E-Mail�H�c */
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", BIRTHDAY_PAY, BIRTHDAY_PAY, sBIRTHDAY   ); /* �I�ڤH�X�ͦ~���
                                                                                                   (�P�Q�O�H)*/
           print_delimiter(  0);                                               
           iLength=cc_split_chinese( sNapplicant, sNapplicant_t, INSURANT);
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", INSURANT    , INSURANT    , sNapplicant_t );  /* �n�O�H�m�W */
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", IAPPLICANT  , IAPPLICANT  , sINSURANT_ID   ); /* �n�O�HID*/
           print_delimiter(  0);
           if (strcmp(sASSURED,sINSURANT_ID) == 0)
               len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", INSURANT_REL, INSURANT_REL, "01"       ); /* �n�O�H�P�Q�O�H���Y*/
           else 
               len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", INSURANT_REL, INSURANT_REL, "02"       ); /* �n�O�H�P�Q�O�H���Y*/

           print_delimiter(  0);
           iPrem_ori = iPrem + iDiscount;
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%0*d",PREM_ORI       , iPrem_ori   ); /* ��l�O�O(��)*/
           print_delimiter(  0);                             
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%0*d",PREM           , iPrem       ); /* �馩��O�O(��)*/
           print_delimiter(  0);                             
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%0*d",DISC_M         , iDiscount   ); /* �馩���B*/
           print_delimiter(  0);                             
           if( iDiscount == 0)
               rPdiscount = 0.0; 
           else if( iPrem_ori == 0)
               rPdiscount = 0.0; 
           else
               rPdiscount = (double)iDiscount / (double)iPrem_ori;               
           if( rPdiscount < 0)
               rPdiscount*=(-1);
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s",   DISC_P, DISC_P, gcvt(rPdiscount, COMMI_P, sTmp)  ); /* �馩�v*/
           print_delimiter(  0);

           #if 0  /* car9904121 �x�s���ȲĤ@��ú�O����אּñ���A�Ĥ@��ú�O���B�אּ�馩��O�O */
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", PAY_DAY, PAY_DAY   , sPAY_DAY    ); /* �Ĥ@��ú�O���*/
           print_delimiter(  0);                                     
           if( sPAY_DAY[0] == ' ')
               len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", PAY_AMT, PAY_AMT   , " "         ); /* �Ĥ@��ú�O���B*/
           else
               len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%0*d", PAY_AMT, iPrem         );             /* �Ĥ@��ú�O���B*/
           #endif
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", DPOLICY, DPOLICY   , sDPOLICY    ); /* ñ��� */
           print_delimiter(  0);                                     
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%0*d",PREM           , iPrem       ); /* �馩��O�O(��)*/
           print_delimiter(  0);                                     
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", DUE    , DUE       , " "         ); /* �Ĥ@��ú�O�䲼�����*/
           print_delimiter(  0);
           if( iCommi == 0)
               rPcommission = 0.0;
           else if( iPrem == 0)
               rPcommission = 0.0;
           else
               rPcommission = ((double)iCommi / (double)iPrem) * 100;
           if( rPcommission < 0)
               rPcommission*=(-1);               
           sprintf_s(str_comm, sizeof str_comm,"%f",rPcommission);
               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s",   COMMI_P, COMMI_P, str_comm); /* �����v*/
           print_delimiter(  0);                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%0*d", COMMI_M       , iCommi      ); /* ����*/
           print_delimiter(  0);
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", ISSUE  , ISSUE      , sISSUE      ); /* �o�Ӥ��*/
           print_delimiter(  0);                                    
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", TAG    , TAG        , sTAG        ); /* �P�Ӹ��X(�P�Ъ���)*/
           print_delimiter(  0);                                    
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", CANCEL , CANCEL     , sCANCEL     ); /* �h�O���*/
           print_delimiter(  0); 
           strcpy(sENDORSE,trim(sENDORSE));
           if( iPrem > 0 && strlen(sENDORSE) > 0)
               strcpy( sEDR_TYPE, "1");
           else if( iPrem < 0 && strlen(sENDORSE) > 0)
               strcpy( sEDR_TYPE, "2");
           else if (strlen(sENDORSE) > 0)
               strcpy( sEDR_TYPE, "3");
           else
               strcpy( sEDR_TYPE, " ");
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", EDR_TYPE   , EDR_TYPE    , sEDR_TYPE   ); /* ���ƥ�*/
           print_delimiter(  0);                                             
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", EDR_CONTENT, EDR_CONTENT , " "         ); /* ���ק鷺�e*/
           print_delimiter(  0);                                             
           iLength=cc_split_chinese( sRemark, sRemark_t, REMARK);
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", REMARK     , REMARK      , sRemark_t   ); /* �Ƶ�*/
           print_delimiter(  0);                                             
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", TARGET_ADD , TARGET_ADD  , " "         ); /* �Ъ����Ҧb�a��*/
           print_delimiter(  0);                                             
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", LAST_PLY   , LAST_PLY    , sLAST_PLY   ); /* �e�@�~�׫O�渹�X*/
           print_delimiter(  0);                                             
           /*len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", SALES_CODE , SALES_CODE  , sSALES_CODE );  ���ˤHSOURCE CODE
           print_delimiter(  0);                                             
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", SALES_NAME , SALES_NAME  , sSALES_NAME ); /* ���ˤH�m�W
           print_delimiter(  0);                                             
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", SALES_ID   , SALES_ID    , sSALES_ID   ); /* ���ˤH���s/ID
           print_delimiter(  0);                                             
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", ACCEPT     , ACCEPT      , sACCEPT     ); /* RMS�s��(����s��)
           print_delimiter(  0);
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", SALE_SERIAL, SALE_SERIAL , sSALE_SERIAL); /* ��P�Ǹ� 
           print_delimiter(  0); */

           /*-------------------------------------------------------------------------------*/
           len = 0;
           iColumn = 1;
           writeStrDtl[0] = '\0';
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", COMPANY_2     , COMPANY_2     , "17"        ); /* ���q�O*/
           print_delimiter(  1);                                                  
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", PRODUCT_2     , PRODUCT_2     , sProduct    ); /* �O�I���~�O*/
           print_delimiter(  1);                                                  
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", TARGET_2      , TARGET_2      , sTARGET     ); /* �P�Ӹ��X*/
           print_delimiter(  1);                                                  
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", ASSURED_2     , ASSURED_2     , sASSURED    ); /* �Q�O�I�H�����Ҧr��*/
           print_delimiter(  1);
           iLength=cc_split_chinese( sNassured, sNassured_t, NASSURED_2);
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", NASSURED_2    , NASSURED_2    , sNassured_t ); /* �Q�O�H�m�W*/
           print_delimiter(  1);                                                  
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", NAPPLICANT    , NAPPLICANT    , sNAPPLICANT ); /* �n�O�H�m�W*/
           print_delimiter(  1);                                                  
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", IAPPLICANT    , IAPPLICANT    , sIAPPLICANT ); /* �n�O�HID*/
           print_delimiter(  1);
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", BEGIN_2       , BEGIN_2       , sBEGIN      ); /* �O�I�l��*/
           print_delimiter(  1);                                                  
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", DEND_2        , DEND_2        , sEND        ); /* �O�I�״�*/
           print_delimiter(  1);                                                  
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%0*d"  , PREM_2                        , iPrem       ); /* �馩��O�O(��)*/
           print_delimiter(  1);                                                  
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", DINVITE       , DINVITE       , sDINVITE     ); /* ������*/
           print_delimiter(  1);                                                  
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", RECOMMEND     , RECOMMEND     , "ON17"      ); /* ���ˤH�N��(�x�s����)*/
           /* print_delimiter(  1); */

           fprintf( fptr1, "%s\n", writeStr);
           fprintf( fptr2, "%s\n", writeStrDtl);
           iWriteCount++;   
        } /* end of while */
        $close cur11;
        $free  cur11;
   } /* end for of db list */

   sprintf_s(sMsg, sizeof sMsg, "��X %d ��", iWriteCount);
   WRITELOG( sfp, sMsg);

   fclose(fptr1);
   fclose(fptr2);

   rtncode=rptftpinsert(userid, "car334", sFileName);
printf("rptftpinsert rc[%d]\n", rc);
   if (rc!=0)
   {
       sprintf_s(sMsg, sizeof sMsg,"[%s]�g�Jrptftplist���~\r\n", sFileName);
       return rc;
   }

   sprintf_s(sMsg, sizeof sMsg,"�d�ߧ���,���I���ɮפU���@�~�d��[Q],�U��[%s] \r\n", sFileName);
   WRITELOG( sfp, sMsg);

   rtncode=rptftpinsert(userid, "car334", sFileNameDtl);
printf("rptftpinsert rc[%d]\n", rc);
   if (rc!=0)
   {
       sprintf_s(sMsg, sizeof sMsg,"[%s]�g�Jrptftplist���~\r\n", sFileNameDtl);
       return rc;
   }

   sprintf_s(sMsg, sizeof sMsg,"�d�ߧ���,���I���ɮפU���@�~�d��[Q],�U��[%s] \r\n", sFileNameDtl);
   WRITELOG( sfp, sMsg);

   return M_CM_OK;

errexit:
   printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   sprintf_s(sMsg, sizeof sMsg, "sqlerrcode=%d, sqlerrmsg=%s\n ",SQLCODE,sqlca.sqlerrm);
   fclose(fptr1);
   fclose(fptr2);
   return SQLCODE;
}

/*--------------------------------*/
/* �x�s�@���ñ����           */ 
/*--------------------------------*/
long get_TS1()
{
    char  sFileName[51], sFullFileName[121];
    char  sFileNameDtl[51], sFullFileNameDtl[121];
    long  jdate;
    short mdy_begin[3], mdy_end[3];
    DBinfo  *list;
    int     i, count_db, tmp_period;

    long   rtncode, iWriteCount;
    char   sApHome[51], sDbName[51], sTmp[51];
    $char  sQuery[6000], sTmp1[101], stmt_disc[1024];
    $int   iStart, iLens, iTmp, iCount, iRows;
    $long  iSum = 0;
   
    /* �����פj��DC�w�q��,�λ��ഫ�̦b���ŧi */

    $char sNassured[121], sAassured[91], sImovephone[21], sIemail[51], sFcard_class[2], sIcar_type[3], sIofficer[11];
    $char sDendorse[9], ply1[POLICY_NUM_1], ply2[POLICY_NUM_2], sRemark[2048], sProduct[11];
    $char temp[21], sIbroker[11], sNassured_t[121], sAassured_t[91], sIemail_t[51], sRemark_t[2048];
    $char sNapplicant[121], sNapplicant_t[121], sIapplicant[13];

    /* �Ʀr���b���ŧi */

    $long   iPrem = 0, iDiscount = 0, iCommi = 0, iPrem_ori, iPeriod;
    $double rPdiscount, rPcommission;

    /* other */    
    $char   taipei_db[11], dbname_tp[20];
    $char   str_comm[10],spayway[2];
    
    /* �s�¶O�v�P�_ */
    $char   f980401[2],drate_ym[5];  
    
    /* �H�Υd����ഫ */
    $char   first_4[5],first_6[7],last_4[5],cred_no[17],first_8[9]; 
    $char   str_effect[7],first_2[3],last_2[3];
    int     int_effect=0;    

    long iLength;
    $WHENEVER SQLERROR GOTO errexit;

    rtncode = getApHome(sApHome);
    if (rtncode < 0)
    {
        sprintf_s(sMsg, sizeof sMsg, "read Config file error !!\n");
        return M_CM_READ_CONFIG_ERR;
    }

    if ( ( list = get_db_list(&count_db, DBName)) == (char*)0 )
    {
        sprintf_s(sMsg, sizeof sMsg, "Cannot get DB LIST \n");
        return M_CM_NOT_DBLIST;
    }

    rtncode = getHeadBranch(taipei_db);
    if (rtncode < 0)
    {
        sprintf_s(sMsg, sizeof sMsg, "getHeadBranch error !!\n");
        return M_CM_READ_CONFIG_ERR;
    }

    /* get TAIPEI's full DB name for abnormal policy */
    strcpy(dbname_tp,get_full_dbname(taipei_db));


    rstrdate( sBegin, &jdate);
    rjulmdy( jdate, mdy_begin);
    rstrdate( sEnd, &jdate);
    rjulmdy( jdate, mdy_end);

    puts("End rjulmdy");

    sprintf_s(sFileName, sizeof sFileName, "car334_%02d%02d_%02d%02d_�@���.txt", mdy_begin[0], mdy_begin[1], mdy_end[0], mdy_end[1]);
    sprintf_s(sFullFileName, sizeof sFullFileName, "%s/rptftp/%s", sApHome, sFileName);    

    sprintf_s(sFileNameDtl, sizeof sFileNameDtl, "car334_dtl_%02d%02d_%02d%02d_�@���.txt", mdy_begin[0], mdy_begin[1], mdy_end[0], mdy_end[1]);
    sprintf_s(sFullFileNameDtl, sizeof sFullFileNameDtl, "%s/rptftp/%s", sApHome, sFileNameDtl);    

    if ((fptr1=fopen(sFullFileName,"w"))==NULL)
    {
        sprintf_s(sMsg, sizeof sMsg, "Cannot open Output file: %s\n", sFullFileName);
        return M_CM_OPEN_FILE_FAIL;
    }

    if ((fptr2=fopen(sFullFileNameDtl,"w"))==NULL)
    {
        sprintf_s(sMsg, sizeof sMsg, "Cannot open Output file: %s\n", sFullFileNameDtl);
        return M_CM_OPEN_FILE_FAIL;
    }
    
    puts("End open fptr2");

    iWriteCount = 0;

   /* �t�X�q���ĤG���q�i��U�C�ק�:modifyb by sylvia 100.06.03
          �g���H[ibroker ]��H[�D�q���N��(I812)+�q���ۭq�~�ȱ���(06)]���N   
          ��{��:   and a.ibroker[] = 'RZF0016A01' */
   for (i=0;i<count_db;i++)
   {
      
       sprintf_s(sQuery, sizeof sQuery, 
             "select b.itag, a.ipolicy, ' ', b.iassured, b.nassured, to_char(b.dbirth,'%%Y%%m%%d'),"             
             "       TO_CHAR(a.dply_begin, '%%Y%%m%%d'), TO_CHAR(a.dply_end, '%%Y%%m%%d'), "
             "       lpad(case when a.qply_period <= 12 then '1' else '2' end,3,' ')::char(3) as qply_period, "             
             "       b.aassured_zip, b.aassured, b.itel, d.tphone_con, d.imovephone, "
             "       d.iemail, a.mlia_prem + a.mdmg_prem, "
             "       a.mlia_commi + a.mdmg_commi, to_char(b.dissue,'%%Y%%m') || '01',"             
             "       a.ilast_ply, e.nsales, a.ibig_sales, ' ', a.fcard_class, a.icar_type, a.iofficer, a.ibroker, "
             "       b.iapplicant ,b.napplicant,TO_CHAR(a.dpolicy, '%%Y%%m%%d') "
             "         "
             "  from %s:ori_ply_relation a, %s:original_ply b, cm_route_data f, cm_route g, "
             "       outer cu_customer d, outer cm_route_sales e "
             " where a.ipolicy      = b.ipolicy "             
             "   and b.iassured     = d.ifpce_id "
             "   and b.iassured_ext = d.ifpce_id_ext "
             "   and a.ibig_office  = e.iroute "
             "   and a.ibig_sales   = e.isales "
             "   and a.ipolicy[1,13] = f.ipolicy1 "
             "   and a.ipolicy[14,20] = f.ipolicy2 "
             "   and b.iroute = g.iroute "
             "   and g.iroute_main = 'I812' "
             "   and dpolicy between '%s' and '%s' and f.column_10 in ('05','06') "
             "   and dply_close is not null "
             "   and a.iofficer matches '%s' "
             " union "
             "select b.itag, a.ipolicy, a.iendorse, b.iassured, b.nassured, to_char(b.dbirth,'%%Y%%m%%d'),"             
             "       TO_CHAR(b.dply_begin, '%%Y%%m%%d'), "
             "       TO_CHAR(b.dply_end, '%%Y%%m%%d'), "             
             "       lpad(case when b.qply_period <= 12 then '1' else '2' end,3,' ')::char(3) as qply_period, "
             "       b.aassured_zip, b.aassured, b.itel, d.tphone_con, d.imovephone, "
             "       d.iemail, a.medrlia_prem + a.medrdmg_prem, "
             "       a.medrlia_commi + a.medrdmg_commi, to_char(b.dissue,'%%Y%%m') || '01',"             
             "       (select ilast_ply from ori_ply_relation where ipolicy = a.ipolicy), "
             "       e.nsales, a.ibig_sales, TO_CHAR( a.dendorse, '%%Y%%m%%d') , "
             "       a.fcard_class, a.icar_type, a.iofficer, a.ibroker,b.iapplicant ,b.napplicant, TO_CHAR(c.dpolicy, '%%Y%%m%%d')  "
             "        "
             "  from %s:edr_relation a, %s:endorsement b, %s:ply_relation c, cm_route_data f, cm_route g, "
             "       outer cu_customer d, outer cm_route_sales e "
             " where a.iendorse     = b.iendorse "                          
             "   and b.iassured     = d.ifpce_id "
             "   and b.iassured_ext = d.ifpce_id_ext "
             "   and a.ibig_office  = e.iroute "
             "   and a.ibig_sales   = e.isales "
             "   and a.ipolicy      = c.ipolicy "
             "   and a.ipolicy[1,13] = f.ipolicy1 "
             "   and a.ipolicy[14,20] = f.ipolicy2 "
             "   and b.iroute = g.iroute "
             "   and g.iroute_main = 'I812' "
             "   and a.dendorse between '%s' and '%s' and f.column_10 in ('05','06') "
             "   and a.iofficer matches '%s' "
             "   and dedr_close is not null ", list[i].dbname, list[i].dbname, sBegin, sEnd, sOfficer,
                                               list[i].dbname, list[i].dbname, list[i].dbname, sBegin, sEnd, sOfficer);
             /* "   and a.ibroker in ('RD','RDA')"    ����X�w���� */
printf("sQuery[%s]\n",sQuery);
       $prepare prep22 from $sQuery;
       $declare cur22 cursor for prep22;
       $open cur22;
       while(1)
       {   
           init_column();
           strcpy(cred_no,"");
           strcpy(str_effect,"");

           $fetch cur22   into $sTARGET,      $sPOLICY,        $sENDORSE,      $sASSURED,    $sNassured, $sBIRTHDAY,   
                               $sBEGIN,       $sEND,
                               $sPERIOD,      $sZIP,           $sAassured,     $sTEL_O,
                               $sTEL_H,       $sImovephone,    $sIemail,       $iPrem,       
                               $iCommi,       $sISSUE,         $sLAST_PLY,     $sSALES_NAME,
                               $sSALES_ID,    $sDendorse,      $sFcard_class,  $sIcar_type,  $sIofficer, $sIbroker,
                               $sINSURANT_ID, $sNapplicant    ,$sDPOLICY;
 
           if (SQLCODE==SQLNOTFOUND) break;
           
           strncpy(ply1, sPOLICY, CAR_POLICY_LEN);
           ply1[CAR_POLICY_LEN]='\0';

           strncpy(ply2, sPOLICY+CAR_POLICY_LEN, CAR_TARGET_LEN);
           ply2[CAR_TARGET_LEN]='\0';

           $SELECT TO_CHAR( dpay, '%Y%m%d')
              INTO $sPAY_DAY 
              FROM policy_main
             WHERE ipolicy1 = $ply1 
               AND ipolicy2 = $ply2
               AND iendorsement = $sENDORSE;

           if (risnull(SQLCHAR, sPAY_DAY) == 1) strcpy(sPAY_DAY, " ");

           sprintf_s(sQuery, sizeof sQuery, "select sum( minjured_cover + mdeath_cover +  mdamage_cover)" 
                            "  from %s:ply_ins_type"
                            " where ipolicy = '%s'", list[i].dbname, sPOLICY);

           printf("sQuery[%s]\n",sQuery);
           $prepare prep33 from $sQuery;
           $execute prep33 into $iSum;
           $free prep33;                     
        
           if( iSum == 0)
               strcpy( sCANCEL, sDendorse); 

           if (risnull(SQLCHAR, sCANCEL) == 1) strcpy(sCANCEL, " ");
           
            /* ���H�Υd��� */
           sprintf_s(sQuery, sizeof sQuery, "select first 1 nvl(a.icreditno,' '), nvl(a.deffect,' ')" 
                            "  from %s:ao_prem_credit a, %s:ao_prem_crd_detail b "
                            "  where b.ipolicy1 = '%s' and b.ipolicy2 = '%s'"
                            "    and b.iendorse = '%s' and a.iserno = b.iserno", 
                            list[i].dbname, list[i].dbname, ply1, ply2, sENDORSE);

           printf("sQuery[%s]\n",sQuery);
           $prepare prep44 from $sQuery;
           $execute prep44 into $cred_no, $str_effect;
           $free prep44;

          
           if (cred_no[0]=='\0' || cred_no[0]==' ')
           {
           	if(iPrem == 0 && strlen(sENDORSE) > 0)
           	{
            		
            		strcpy(sPAY_WAY,"2");
           		strcpy(sCARD,"");
           		strcpy(sEFFECT,"");               		          
                
                }    
           	else
           	{	
           		strcpy(spayway,"");
           		sprintf_s(sQuery, sizeof sQuery, "SELECT first 1 CASE WHEN b.itype_prem IN('2','6') THEN '3' " 
                                	 "             WHEN b.itype_prem = '7' THEN '1'  "
                                	 "             ELSE '2' END  "
                                	 "  FROM  cm_pre_receive  a, %s:ao_prercv_detail b "
                                	 " WHERE  a.ipolicy1 = '%s' AND  a.ipolicy2 = '%s' "
                                	 "        AND  a.iins_kind = '%s' AND  a.iendorse = '%s' "
                                	 "        AND  a.ipre_rcv = b.ipre_rcv AND a.iins_kind = b.iins_kind "
                                 	 "        AND   a.ipre_end = b.ipre_end  group by b.itype_prem ", list[i].dbname, ply1, ply2, sFcard_class, sENDORSE);
          
                	$prepare prep441 from $sQuery;
                	$execute prep441 into $spayway;
                	$free prep441;  
                	
                	if(strcmp( spayway, "1") == 0 )  /*�H�Υd*/
                	{
                		
                		sprintf_s(sQuery, sizeof sQuery, "select  first 1 nvl(b.icreditno[1,6]||'**',' '), nvl(b.deffect,' ')" 
                            			 "  from  cm_pre_receive  a, %s:ao_prercv_detail b "
                            			 " where  a.ipre_rcv = b.ipre_rcv AND a.iins_kind = b.iins_kind "
                            			 "    AND a.ipolicy1 = '%s' "
                            			 "    AND a.ipolicy2 = '%s' "
                            			 "    AND a.iendorse = '%s' AND b.itype_prem !='6'"
                            			 , list[i].dbname, ply1, ply2, sENDORSE);

           			printf("sQuery[%s]\n",sQuery);
           			$prepare prep442 from $sQuery;
           			$execute prep442 into $cred_no, $str_effect;
           		        $free prep442;
                		
                		
                		
                		if(sOpt[0]=='0'){         	                   
           	     			strcpy(sPAY_WAY,"1");   
                 			/* �x�s���Ȧ^�X�ɫH�Υd�榡�H�e���X���,��l�r���h��X�N�� */
                 			strncpy(first_8, cred_no, 8);
                 			first_8[8]='\0';

                 			strcpy(sCARD,first_8);
                 			strcat(sCARD,"XXXXXXXX");
               			}
               			else{
               	 			strcpy(sPAY_WAY,"1");   
                 			/* �H�Υd�榡�H�e�|�X��|�X���,��l�r���h��X�N�� */
                 			strncpy(first_4, cred_no, 4);
                 			first_4[4]='\0';

                 			strncpy(last_4, cred_no+12, 4);
                 			last_4[4]='\0';
                 			strcpy(sCARD,first_4);
                 			strcat(sCARD,"XXXXXXXX");
                 			strcat(sCARD,last_4);
               			}
               			
               			/* ���Ĵ������榡��YYMM(�褸�~+���),�G���ഫ��YYYYMM */
               			strcpy(str_effect,trim(str_effect));
               			strncpy(first_2, str_effect, 2);
               			first_2[2]='\0';
               			int_effect = atoi(first_2) + 2000;
               
               			strncpy(last_2, str_effect+2, 2);
               			last_2[2]='\0';
               			sprintf_s(sEFFECT, sizeof sEFFECT,"%ld",int_effect);
               			strcat(sEFFECT,last_2); 
                	}
                	else
                	{
                		strcpy(sPAY_WAY,spayway);
           			strcpy(sCARD,"");
           			strcpy(sEFFECT,""); 
                	}
                	
                	
                	

           	}
           	

           	          		
           } else
           {
           	   if(sOpt[0]=='0'){         	                   
           	     strcpy(sPAY_WAY,"1");   
                 /* �x�s���Ȧ^�X�ɫH�Υd�榡�H�e���X���,��l�r���h��X�N�� */
                 strncpy(first_8, cred_no, 8);
                 first_8[8]='\0';

                 strcpy(sCARD,first_8);
                 strcat(sCARD,"XXXXXXXX");
               }
               else{
               	 strcpy(sPAY_WAY,"1");   
                 /* �H�Υd�榡�H�e�|�X��|�X���,��l�r���h��X�N�� */
                 strncpy(first_4, cred_no, 4);
                 first_4[4]='\0';

                 strncpy(last_4, cred_no+12, 4);
                 last_4[4]='\0';
                 strcpy(sCARD,first_4);
                 strcat(sCARD,"XXXXXXXX");
                 strcat(sCARD,last_4);
               }
               /* ���Ĵ������榡��YYMM(�褸�~+���),�G���ഫ��YYYYMM */
               strcpy(str_effect,trim(str_effect));
               strncpy(first_2, str_effect, 2);
               first_2[2]='\0';
               int_effect = atoi(first_2) + 2000;
               
               strncpy(last_2, str_effect+2, 2);
               last_2[2]='\0';
               sprintf_s(sEFFECT, sizeof sEFFECT,"%ld",int_effect);
               strcat(sEFFECT,last_2); 
            }
            /*1121124004_C01_���s�t��car334�����ק�_�����H�Υd���Ĥ�h���ť�*/
            if(strcmp(str_effect,"") == 0)
            {
            	strcpy(sEFFECT,"");	
            }     
                  
           /* end of ���H�Υd��� */

           sprintf_s(sQuery, sizeof sQuery, "select trim( a.iins_type) || trim( b.nins_type),drate_ym "
                            "  from %s:ply_ins_type a, insurance_type b"
                            " where ipolicy = '%s'" 
                            "   and a.iins_type = b.iins_type", list[i].dbname, sPOLICY);
printf("sQuery[%s]\n",sQuery);

           $prepare prep55 from $sQuery;
           $declare curs55 cursor for prep55;
           $open curs55;
           sRemark[0] = '\0';
           for(;;)
           {
               $fetch curs55 into $sTmp1,$drate_ym;
   
               if( NOT_FOUND)
                   break;
                   
                $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
                   INTO $f980401
                   FROM ca_rate_date
                  WHERE icode  = $drate_ym
                    AND itable = 'cm_extra_charge';
 
                 if (NOT_FOUND)
                 {
                       sprintf_s(sMsg, sizeof sMsg,"�O�渹[%s]�O�v�N��[%s]���s�b\r\n",sPOLICY,drate_ym);
                       break;
                 }
                 /* �O�v�ۥѤ� */
                 if( f980401[0] == '1') flag_new = 1;

                 strcat( sRemark, trim(sTmp1));
                 strcat( sRemark, " ");
           }
           $free prep55;

           if( sFcard_class[0] == '1')
           {               
               if( strncmp( sIcar_type, "01", 2) == 0 ||
                   strncmp( sIcar_type, "02", 2) == 0 ||
                   strncmp( sIcar_type, "32", 2) == 0 ||
                   strncmp( sIcar_type, "34", 2) == 0 )
                   strcpy( sProduct , "MTM");
               else
                   strcpy( sProduct , "MTC");
               
           }
           else
           {               
               if( strncmp( sIcar_type, "01", 2) == 0 ||
                   strncmp( sIcar_type, "02", 2) == 0 ||
                   strncmp( sIcar_type, "32", 2) == 0 ||
                   strncmp( sIcar_type, "34", 2) == 0 )
               {
                  	if (flag_new == 1) strcpy( sProduct , "MTL1");
                     else strcpy( sProduct , "MTL");
               }
               else
               {
                   if (flag_new == 1) strcpy( sProduct , "MTA1");
                   else strcpy( sProduct , "MTA");
               }
           }
           
           strcpy( sTAG, sTARGET);
 
           
           /* �줽�q�ܰϸ� */
           if(strncmp(sTEL_O+2, "-",1) == 0)
           {
           	 strncpy(sTEL_O_1, sTEL_O, 2);
           	 sTEL_O_1[2] = 0x0;
           	 
           	 strcpy(temp, sTEL_O+3);
           	 
           	 strcpy(sTEL_O, temp);
           }
           else if (strncmp(sTEL_O+3, "-",1) == 0)
           {
           	 strncpy(sTEL_O_1, sTEL_O, 3);
           	 sTEL_O_1[3] = 0x0;
           	 
           	 strcpy(temp, sTEL_O+4);
           	 
           	 strcpy(sTEL_O, temp);
           }	
           
           	/* ���a�q�ܰϸ� */
           if(strncmp(sTEL_H+2, "-",1) == 0)
           {
           	 strncpy(sTEL_H_1, sTEL_H, 2);
           	 sTEL_H_1[2] = 0x0;
           	 
           	 strcpy(temp, sTEL_H+3);
           	 
           	 strcpy(sTEL_H, temp);
           }
           else if (strncmp(sTEL_H+3, "-",1) == 0)
           {
           	 strncpy(sTEL_H_1, sTEL_H, 3);
           	 sTEL_H_1[3] = 0x0;
           	 
           	 strcpy(temp, sTEL_H+4);
           	 
           	 strcpy(sTEL_H, temp);
           }
           
           /* �B�z�馩���B,�j���I���馩���B�O�~�ȶO��(mbusiness)��W���~�ȶO��(mbus_rule),
              ���N�h���O������馩����� */
           if (strncmp(sFcard_class,"1",1) == 0)
           {
           	  sprintf_s(stmt_disc, sizeof stmt_disc, "select (mbus_rule - mbusiness) "
                                 "  from %s:ori_ply_relation"
                                 " where ipolicy = '%s'" , list[i].dbname, sPOLICY);              
            } else
            {
              sprintf_s(stmt_disc, sizeof stmt_disc, "select (mlia_discount + mdmg_discount) "
                                 "  from %s:ori_ply_relation"
                                 " where ipolicy = '%s'" , list[i].dbname, sPOLICY); 
            }
        
            $prepare prep5 from $stmt_disc;
            $execute prep5 into $iDiscount;
            $free prep5;
           /* end of �B�z�馩���B */
   
           iColumn = 1;
           writeStr[0] = '\0';
           len = 0;

           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", COMPANY     , COMPANY     , "17"        ); /* ���q�O*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", PRODUCT     , PRODUCT     , sProduct    ); /* �O�I���~�O*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", TARGET      , TARGET      , sTARGET     ); /* �O�I�Ъ�*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", SERIAL      , SERIAL      , " "     );     /* �Ǹ�*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", POLICY      , POLICY      , sPOLICY     ); /* �O�渹�X*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", ENDORSE     , ENDORSE     , sENDORSE    ); /* ��渹�X*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", ASSURED     , ASSURED     , sASSURED    ); /* �Q�O�I�H�����Ҧr��*/
           print_delimiter(  0);                                               
           iLength=cc_split_chinese( sNassured, sNassured_t, NASSURED);
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", NASSURED    , NASSURED    , sNassured_t ); /* �Q�O�H�m�W*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", BIRTHDAY    , BIRTHDAY    , sBIRTHDAY   ); /* �Q�O�I�H�X�ͤ��*/
           print_delimiter(  0);                                               
           iLength=cc_split_chinese( sNassured, sNassured_t, PAY);
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", PAY         , PAY         , sNassured_t   ); /* �I�ڤH�m�W
                                                                                                   (�P�Q�O�H�m�W)*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", PAY_ID      , PAY_ID      , sASSURED    ); /* �I�ڤH�����Ҹ�
                                                                                                   (�P�Q�O�I�Hid)*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", CARD        , CARD        , sCARD       ); /* �I�ڤH�d��*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", EFFECT      , EFFECT      , sEFFECT     ); /* �H�Υd���Ĵ���*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", ACCOUNT     , ACCOUNT     , " "         ); /* �I�ڤH�b��*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", BEGIN       , BEGIN       , sBEGIN      ); /* �O�I�l��*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", DEND        , DEND        , sEND        ); /* �O�I�״�*/
           print_delimiter(  0);            
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", PERIOD      , PERIOD      , sPERIOD     ); /* ��O�~��(�O�I����)*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", AREA        , AREA        , " "         ); /* �a�ϧO�N�X*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", PAY_WAY     , PAY_WAY     , sPAY_WAY    ); /* ú�O�覡*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", PAY_TYPE    , PAY_TYPE    , "1"         ); /* ú�O�O (1���B)*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", PAY_PERIOD  , PAY_PERIOD  , "1"         ); /* ú�O����*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", REL         , REL         , "01"        ); /* �I�ڤH�P�Q�O�H���Y
                                                                                                   (01���H)*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", ZIP         , ZIP         , sZIP        ); /* �l���ϸ�*/
           print_delimiter(  0);                                               
           iLength=cc_split_chinese( sAassured, sAassured_t, ADDRES);
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", ADDRES      , ADDRES      , sAassured_t ); /* �q�T�a�}*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", TEL_O_1     , TEL_O_1     , sTEL_O_1    ); /* ���q�q�ܰϽX*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", TEL_O       , TEL_O       , sTEL_O      ); /* ���q�q��*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", TEL_H_1     , TEL_H_1     , sTEL_H_1    ); /* ���a�q�ܰϽX*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", TEL_H       , TEL_H       , sTEL_H      ); /* ���a�q��*/
           print_delimiter(  0);                                               
           sImovephone[ CELL_PHONE] = '\0';                                    
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", CELL_PHONE  , CELL_PHONE  , sImovephone ); /* ��ʹq��*/
           print_delimiter(  0);                                               
           iLength=cc_split_chinese( sIemail, sIemail_t, EMAIL);
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", EMAIL       , EMAIL       , sIemail_t   ); /* E-Mail�H�c */
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", BIRTHDAY_PAY, BIRTHDAY_PAY, sBIRTHDAY   ); /* �I�ڤH�X�ͦ~���(�P�Q�O�H)*/
           
           /* 1110921004_SC1_���sCAR334�{���վ� */
           print_delimiter(  0);
           iLength=cc_split_chinese( sNapplicant, sNapplicant_t, INSURANT);
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", INSURANT    , INSURANT    , sNapplicant_t); /* �n�O�H�m�W(�P�Q�O�H)*/
           print_delimiter(  0);                                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", IAPPLICANT  , IAPPLICANT  , sINSURANT_ID ); /* �n�O�HID(�P�Q�O�H)*/
           print_delimiter(  0);
           
           printf("sASSURED[%s] \n",trim(sASSURED));
           printf("sINSURANT_ID[%s]\n",trim(sINSURANT_ID));
           printf("[%d]\n",strcmp(sASSURED,sINSURANT_ID));
           
           if (strcmp(sASSURED,sINSURANT_ID) == 0)
           		len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", INSURANT_REL, INSURANT_REL, "01"    ); /* �n�O�H�P�Q�O�H���Y�N�X*/
           else
           		len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", INSURANT_REL, INSURANT_REL, "02"    ); /* �n�O�H�P�Q�O�H���Y�N�X*/
           		
           print_delimiter(  0);
           iPrem_ori = iPrem + iDiscount;
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%0*d",PREM_ORI       , iPrem_ori   ); /* ��l�O�O(��)*/
           print_delimiter(  0);                             
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%0*d",PREM           , iPrem       ); /* �馩��O�O(��)*/
           print_delimiter(  0);                             
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%0*d",DISC_M         , iDiscount   ); /* �馩���B*/
           print_delimiter(  0);                             
           if( iDiscount == 0)
               rPdiscount = 0.0; 
           else if( iPrem_ori == 0)
               rPdiscount = 0.0; 
           else
               rPdiscount = (double)iDiscount / (double)iPrem_ori;               
           if( rPdiscount < 0)
               rPdiscount*=(-1);
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s",   DISC_P, DISC_P, gcvt(rPdiscount, COMMI_P, sTmp)  ); /* �馩�v*/
           print_delimiter(  0);

           #if 0  /* car9904121 �x�s���ȲĤ@��ú�O����אּñ���A�Ĥ@��ú�O���B�אּ�馩��O�O */
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", PAY_DAY, PAY_DAY   , sPAY_DAY    ); /* �Ĥ@��ú�O���*/
           print_delimiter(  0);                                     
           if( sPAY_DAY[0] == ' ')
               len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", PAY_AMT, PAY_AMT   , " "         ); /* �Ĥ@��ú�O���B*/
           else
               len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%0*d", PAY_AMT, iPrem         );             /* �Ĥ@��ú�O���B*/
           #endif
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", DPOLICY, DPOLICY   , sDPOLICY    ); /* ñ��� */
           print_delimiter(  0);                                     
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%0*d",PREM           , iPrem       ); /* �馩��O�O(��)*/
           print_delimiter(  0);                                     
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", DUE    , DUE       , " "         ); /* �Ĥ@��ú�O�䲼�����*/
           print_delimiter(  0);
           if( iCommi == 0)
               rPcommission = 0.0;
           else if( iPrem == 0)
               rPcommission = 0.0;
           else
               rPcommission = ((double)iCommi / (double)iPrem) * 100;
           if( rPcommission < 0)
               rPcommission*=(-1);               
           sprintf_s(str_comm, sizeof str_comm,"%f",rPcommission);
               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s",   COMMI_P, COMMI_P, str_comm); /* �����v*/
           print_delimiter(  0);                               
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%0*d", COMMI_M       , iCommi      ); /* ����*/
           print_delimiter(  0);
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", ISSUE  , ISSUE      , sISSUE      ); /* �o�Ӥ��*/
           print_delimiter(  0);                                    
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", TAG    , TAG        , sTAG        ); /* �P�Ӹ��X(�P�Ъ���)*/
           print_delimiter(  0);                                    
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", CANCEL , CANCEL     , sCANCEL     ); /* �h�O���*/
           print_delimiter(  0); 
           strcpy(sENDORSE,trim(sENDORSE));
           if( iPrem > 0 && strlen(sENDORSE) > 0)
               strcpy( sEDR_TYPE, "1");
           else if( iPrem < 0 && strlen(sENDORSE) > 0)
               strcpy( sEDR_TYPE, "2");
           else if (strlen(sENDORSE) > 0)
               strcpy( sEDR_TYPE, "3");
           else
               strcpy( sEDR_TYPE, " ");
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", EDR_TYPE   , EDR_TYPE    , sEDR_TYPE   ); /* ���ƥ�*/
           print_delimiter(  0);                                             
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", EDR_CONTENT, EDR_CONTENT , " "         ); /* ���ק鷺�e*/
           print_delimiter(  0);                                             
           iLength=cc_split_chinese( sRemark, sRemark_t, REMARK);
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", REMARK     , REMARK      , sRemark_t   ); /* �Ƶ�*/
           print_delimiter(  0);                                             
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", TARGET_ADD , TARGET_ADD  , " "         ); /* �Ъ����Ҧb�a��*/
           print_delimiter(  0);                                             
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", LAST_PLY   , LAST_PLY    , sLAST_PLY   ); /* �e�@�~�׫O�渹�X*/
           print_delimiter(  0);                                             
           /*len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", SALES_CODE , SALES_CODE  , sSALES_CODE );  ���ˤHSOURCE CODE
           print_delimiter(  0);                                             
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", SALES_NAME , SALES_NAME  , sSALES_NAME ); /* ���ˤH�m�W
           print_delimiter(  0);                                             
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", SALES_ID   , SALES_ID    , sSALES_ID   ); /* ���ˤH���s/ID
           print_delimiter(  0);                                             
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", ACCEPT     , ACCEPT      , sACCEPT     ); /* RMS�s��(����s��)
           print_delimiter(  0);
           len += sprintf_s(writeStr + len, sizeof writeStr + len ,"%-*.*s", SALE_SERIAL, SALE_SERIAL , sSALE_SERIAL); /* ��P�Ǹ� 
           print_delimiter(  0); */

           /*-------------------------------------------------------------------------------*/
           len = 0;
           iColumn = 1;
           writeStrDtl[0] = '\0';
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", COMPANY_1   , COMPANY_1   , "17"        ); /* ���q�O*/
           print_delimiter(  1);                                                  
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", PRODUCT_1   , PRODUCT_1   , sProduct    ); /* �O�I���~�O*/
           print_delimiter(  1);                                                  
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", POLICY_1    , POLICY_1    , sPOLICY     ); /* �O�渹�X*/
           print_delimiter(  1);                                                  
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", ENDORSE_1   , ENDORSE_1   , sENDORSE    ); /* ��渹�X*/
           print_delimiter(  1);                                                  
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", BEGIN_1     , BEGIN_1     , sBEGIN      ); /* ��O�l��*/
           print_delimiter(  1);                                                  
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", PAY_DAY_1   , PAY_DAY_1   , sPAY_DAY    ); /* �Ĥ@��ú�O���*/
           print_delimiter(  1);                                                  
           if( sPAY_DAY[0] == ' ')
               len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", PAY_AMT, PAY_AMT_1   , " "         ); /* �Ĥ@��ú�O���B*/
           else
               len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%0*d", PAY_AMT_1   , iPrem         ); /* �Ĥ@��ú�O���B*/
           print_delimiter(  1);                                                  
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", DUE_1       , DUE_1       , " "         ); /* �Ĥ@��ú�O�䲼�����*/
           print_delimiter(  1);                                                  
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", PAY_PERIOD_1, PAY_PERIOD_1, sPAY_PERIOD ); /* ú�O���O*/
           print_delimiter(  1);                                                  
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", PAY_WAY_1   , PAY_WAY_1   , sPAY_WAY    ); /* ú�O�覡*/
           print_delimiter(  1);                                                  
           len += sprintf_s(writeStrDtl + len, sizeof writeStrDtl + len ,"%-*.*s", PAY_TYPE_1  , PAY_TYPE_1  , " "         ); /* ú�O�O*/
           /* print_delimiter(  1); */

           fprintf( fptr1, "%s\n", writeStr);
           fprintf( fptr2, "%s\n", writeStrDtl);
           iWriteCount++;   
        } /* end of while */
        $close cur22;
        $free  cur22;
   } /* end for of db list */

   sprintf_s(sMsg, sizeof sMsg, "��X %d ��", iWriteCount);
   WRITELOG( sfp, sMsg);

   fclose(fptr1);
   fclose(fptr2);

   rtncode=rptftpinsert(userid, "car334", sFileName);
printf("rptftpinsert rc[%d]\n", rc);
   if (rc!=0)
   {
       sprintf_s(sMsg, sizeof sMsg,"[%s]�g�Jrptftplist���~\r\n", sFileName);
       return rc;
   }

   sprintf_s(sMsg, sizeof sMsg,"�d�ߧ���,���I���ɮפU���@�~�d��[Q],�U��[%s] \r\n", sFileName);
   WRITELOG( sfp, sMsg);

   rtncode=rptftpinsert(userid, "car334", sFileNameDtl);
printf("rptftpinsert rc[%d]\n", rc);
   if (rc!=0)
   {
       sprintf_s(sMsg, sizeof sMsg,"[%s]�g�Jrptftplist���~\r\n", sFileNameDtl);
       return rc;
   }

   sprintf_s(sMsg, sizeof sMsg,"�d�ߧ���,���I���ɮפU���@�~�d��[Q],�U��[%s] \r\n", sFileNameDtl);
   WRITELOG( sfp, sMsg);

   return M_CM_OK;

errexit:
   printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   sprintf_s(sMsg, sizeof sMsg, "sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
   fclose(fptr1);
   fclose(fptr2);
   return SQLCODE;
}
