/**********************************************************************/
/*   program id   : ca916p01s.ec                                      */
/*   program name : ���׹q�l��������J�@�~                            */
/*   date written : 2012/08/13                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : chungchua                                         */
/*   input        : car916.txt                                        */
/**********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "print.h"
#include "sqlfatal.h"
#include "time.h"
#include <locator.h>
#include "safeclib.h"

/*--------------------------------------------------------------------*/
char    sApHome[30];
char    filename[150];
char	logname[150];
char    msgbuf[9000];
$char   DBName[05],localdb[6];
char    userid[11],outputf[41];
$char   tbname[50];
$char   tbname1[50];
char   fdate[10];
char   Tdate[10];
long     rc;
$int  cnt = 0;
$char  stmt[2048];
char  cmd_str[2048];
char  errbuf[128];
long   stmt_len;
time_t current_secs;
struct tm *tm_now;
$char  curtime[30];
$char  thh[3];


/*--------------------------------------------------------------------*/
main(argc,argv)
int   argc;
char  **argv;
{
long  sysdt;
char  fn[100];
char  ftime[5];

	batchinit();
	strcpy(DBName, isNULLstr(argv[1]));
	strcpy(userid, isNULLstr(argv[2]));
	strcpy(fdate,  isNULLstr(argv[3])); 
        strcpy(ftime,  isNULLstr(argv[4]));
	strcpy(outputf,isNULLstr(argv[5]));

	strcpy(Tdate,trim(fdate));

	strcpy(localdb,"sysdb");

        current_secs=time(NULL);
        tm_now=localtime(&current_secs);
        strcpy(curtime,datetime_string(tm_now));
        strncpy(thh,curtime+11,2);
        thh[2] = '\0';

        printf("curtime[%s]\n",curtime);

        printf("thh[%s]\n",thh);

        printf("ftime[%s]\n",ftime);

        strcpy(fn,"ca_cb_est");
        strcat(fn,"_");
        strcat(fn,rtrim(fdate));
        strcat(fn,".");

        if (ftime[0] != '' && ftime[0] != '\0')
        {
           strcat(fn,ftime);
        }
        else
        {
           strcat(fn,thh);
           strcat(fn,"30");
        }
        strcat(fn,".txt");

        printf("fn main [%s]\n",fn);

	rc=car916_get_db(fn);
	if (rc!=M_CM_OK)
		return rc;

	rc=car916_est_h_data();
	if (rc!=M_CM_OK)
		return rc;

        strcpy(fn,"ca_cb_est_dtl");
        strcat(fn,"_");
        strcat(fn,rtrim(fdate));
        strcat(fn,".");

        if (ftime[0] != '' && ftime[0] != '\0')
        {
           strcat(fn,ftime);
        }
        else
        {
           strcat(fn,thh);
           strcat(fn,"30");
        }
        strcat(fn,".txt");

        printf("fn dtl [%s]\n",fn);

	rc=car916_get_db(fn);
	if (rc!=M_CM_OK)
		return rc;

        rc=car916_dtl_h_data();
	if (rc!=M_CM_OK)
		return rc;

        /*****************************
	rc=car916_get_db("cc");
	if (rc!=M_CM_OK)
		return rc;

	rc=car916_acc_h_data();
	if (rc!=M_CM_OK)
		return rc;
        *****************************/


	rc=car916_tran_data();
	if (rc!=M_CM_OK)
		return rc;

	EWRITE(userid,3500,msgbuf);

	return rc;
}

long car916_get_db(char txtname[2])
{
$char ntmp[1024];
FILE  *fp;

   rc = getApHome(sApHome);
   if (rc<0) {
      strcpy(msgbuf,"read Config file error!!-->getApHome\n");
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }
   strcpy(filename," ");
   strcpy(logname," ");
   sprintf_s(filename,150,"%s/tmp/%s", sApHome,txtname);
 
   printf("before fopen filename[%s]\n",filename);
   if ((fp=fopen(filename,"rt"))==NULL)
   {
      printf(" into fopen \n");
      sprintf_s(ntmp,1024,"�L���ɮ�: %s",filename);
      strcpy(ntmp,rtrim(ntmp));
      EWRITE(userid, 0, ntmp);
      return 0;
   }

   sprintf_s(logname,150,"%s/rptftp/car916_%s_log.txt",sApHome,txtname);
   return M_CM_OK;
}

long car916_est_h_data()
{
	$whenever sqlerror goto errexit;

	strcpy(tbname,"ca_cb_est_h");
	strcpy(tbname1,"ca_cb_est");
	strcpy(stmt," ");
	sprintf_s(stmt,2048,"select count(*) from %s ",tbname1);
	$prepare pre_cnt1 from $stmt;
	$execute pre_cnt1 into $cnt;
	strcpy(msgbuf,"\n�즳�D�ɸ��:");
	sprintf_s(msgbuf,9000,"%s[%d]\n",trim(msgbuf),cnt);

	stmt_len = 0;
	stmt_len += sprintf_s(stmt+stmt_len,2048+stmt_len,
		"select iclaim,iestimate,fstatus,             \
                 cast(destimate as char(8)) as destimate ,    \
                 iest_rep_id,                                 \
	  	 itag,iengine,qmeter,ncust_name,              \
                 cast(dreceive as char(8)) as dreceive,       \
                 nbrand,ivision,nnote                         \
		 from %s where 1=0 into temp temp1 with no log;\r\n",
		 tbname);
	stmt_len += sprintf_s(stmt+stmt_len,2048+stmt_len,
		"load from %s delimiter '\t' insert into temp1; \r\n",
		filename);
	stmt_len += sprintf_s(stmt+stmt_len,2048+stmt_len,
		"insert into %s \
		(iclaim,iestimate,fstatus,destimate, \
		iest_rep_id,itag,iengine,qmeter,ncust_name,dreceive,nbrand,dupdate,ivision,nnote) \
		select iclaim[1,11],iestimate,fstatus,     \
                destimate[5,6] || '/' || destimate[7,8] || '/' || destimate[1,4] ,  \
		iest_rep_id,itag,iengine,qmeter,nvl(ncust_name,' ') as ncust_name ,  \
                dreceive[5,6] || '/' || dreceive[7,8] || '/' || dreceive[1,4],   \
                nbrand,current,ivision,nvl(nnote,' ') as nnote \
		from temp1 where iclaim is not null and iclaim <> '' and iclaim <> 'null' ;\r\n",
		tbname);
	sprintf_s(cmd_str,2048,"dbaccess %s > %s 2>&1 << !\r\n"
		"%s\r\n!",
		localdb,logname,stmt);
	printf("cmd_str[%s]\n",cmd_str);
	rc = system(cmd_str);
	
	if (rc != 0) 
	{
		sprintf_s(errbuf,128,"load file error[%s]\n"
			"���I���ɮפU���@�~�d��[Q],�T�{���~��]",
			logname);
		EWRITE(userid,rc,errbuf);
		return rc;
	} 	
	
	rc=rptftpinsert(userid,"car916","car916_log.txt");
	if (rc!=0)
	{
			EWRITE(userid,rc,"�g�Jrptftplist���~\r\n");
			return rc;
        }

	return M_CM_OK;

errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}

long car916_dtl_h_data()
{
	$whenever sqlerror goto errexit;

	strcpy(tbname,"ca_cb_est_dtl_h");
	strcpy(tbname1,"ca_cb_est_dtl");
	strcpy(stmt," ");

	sprintf_s(stmt,2048,"select count(*) from %s ",tbname1);
	$prepare pre_cnt2 from $stmt;
	$execute pre_cnt2 into $cnt;
	sprintf_s(msgbuf,9000,"%s�즳���Ӹ��:",trim(msgbuf));
	sprintf_s(msgbuf,9000,"%s[%d]\n",trim(msgbuf),cnt);

	stmt_len = 0;
	stmt_len += sprintf_s(stmt+stmt_len,2048+stmt_len,
		"select iclaim,iestimate,iserial,nvl(ipnc_id,' ') as ipnc_id, \
		irepair_type,irepair_type_n,iitem_name, \
		qplate_hour,mplate,mplate_n, \
		qvarnish_hour,mvarnish,mvarnish_n, \
		qremove_hour,mremove,mremove_n, \
		ipart_no,mpart_unit,qpart,qpart_n,mpart,mpart_n, \
		iinvest,  \
                cast(dinvest as char(8)) as dinvest   \
		from %s where 1=0 into temp temp2 with no log;\r\n",
		tbname);
	stmt_len += sprintf_s(stmt+stmt_len,2048+stmt_len,
		"load from %s delimiter '\t' insert into temp2; \r\n",
		filename);
	stmt_len += sprintf_s(stmt+stmt_len,2048+stmt_len,
		"insert into %s \
		(iclaim,iestimate,iserial,ipnc_id, \
		irepair_type,irepair_type_n,iitem_name, \
		qplate_hour,mplate,mplate_n, \
		qvarnish_hour,mvarnish,mvarnish_n, \
		qremove_hour,mremove,mremove_n, \
		ipart_no,mpart_unit,qpart,qpart_n,mpart,mpart_n, \
		iinvest,dinvest,dupdate) \
		select iclaim[1,11],iestimate,iserial,nvl(ipnc_id,' ') as ipnc_id, \
		irepair_type,irepair_type_n,iitem_name, \
		qplate_hour,mplate,mplate_n, \
		qvarnish_hour,mvarnish,mvarnish_n, \
		qremove_hour,mremove,mremove_n, \
		nvl(ipart_no,'') as ipart_no,mpart_unit,qpart,qpart_n,mpart,mpart_n, \
		iinvest,     \
                dinvest[5,6] || '/' || dinvest[7,8] || '/' || dinvest[1,4],   \
                current      \
		from temp2 where iclaim is not null and iclaim <> '' and iclaim <> 'null' ;\r\n",
		tbname);
        printf("stmt[%s]\n",stmt);
	sprintf_s(cmd_str,2048,"dbaccess %s > %s 2>&1 << !\r\n"
		"%s\r\n!",
		localdb,logname,stmt);
	printf("cmd_str[%s]\n",cmd_str);
	rc = system(cmd_str);
	
	if (rc != 0) 
	{
		sprintf_s(errbuf,128,"load file error[%s]\n"
			"���I���ɮפU���@�~�d��[Q],�T�{���~��]",
			logname);
		EWRITE(userid,rc,errbuf);
		return rc;
	} 	

        rc=rptftpinsert(userid,"car916","car916_log.txt");
        if (rc!=0) 
        {
                EWRITE(userid,rc,"�g�Jrptftplist���~\r\n");
                return rc;
        }

	return M_CM_OK;

errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}

long car916_acc_h_data()
{
	$whenever sqlerror goto errexit;	

	strcpy(tbname,"ca_cb_est_acc_h");
	strcpy(tbname1,"ca_cb_est_acc");
	strcpy(stmt," ");

	sprintf_s(stmt,2048,"select count(*) from %s ",tbname1);
	$prepare pre_cnt3 from $stmt;
	$execute pre_cnt3 into $cnt;
	sprintf_s(msgbuf,9000,"%s�즳���b���:",trim(msgbuf));
	sprintf_s(msgbuf,9000,"%s[%d]\n",trim(msgbuf),cnt);

	stmt_len = 0;
	stmt_len += sprintf_s(stmt+stmt_len,2048+stmt_len,
		"select iclaim,iestimate,invoice,  \
                 cast(dreceive as char(8)) as dreceive,  \
		 mwork,mpart,mamount  \
		 from %s where 1=0 into temp temp3 with no log;\r\n",
		 tbname);
	stmt_len += sprintf_s(stmt+stmt_len,2048+stmt_len,
		"load from %s delimiter '\t' insert into temp3; \r\n",
		filename);
	stmt_len += sprintf_s(stmt+stmt_len,2048+stmt_len,
		"insert into %s \
		(iclaim,iestimate,invoice,dreceive, \
		mwork,mpart,mamount,dupdate) \
		select iclaim[1,11],iestimate,invoice,dreceive, \
		mwork,mpart,mamount,current \
		from temp3 where iclaim is not null and iclaim <> '' and iclaim <> 'null'; \r\n",
		tbname);
	sprintf_s(cmd_str,2048,"dbaccess %s > %s 2>&1 << !\r\n"
		"%s\r\n!",
		localdb,logname,stmt);
	printf("cmd_str[%s]\n",cmd_str);
	rc = system(cmd_str);
	
	if (rc != 0) 
	{
		sprintf_s(errbuf,128,"load file error[%s]\n"
			"���I���ɮפU���@�~�d��[Q],�T�{���~��]",
			logname);
		EWRITE(userid,rc,errbuf);
		return rc;
	} 	

   rc=rptftpinsert(userid,"car916","car916_log.txt");
        if (rc!=0) {
                EWRITE(userid,rc,"�g�Jrptftplist���~\r\n");
                return rc;
        }

	return M_CM_OK;

errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}

long car916_tran_data()
{

$char iclaim[20],iestimate[20],fstatus[3],fstatus_h[3];
$char project_id[10],receiver_email[50];
$char content[9000],nsubject[100];
$loc_t ctxt;
$long mdate;

int sendmail;
$char dupdate[20];

	$whenever sqlerror goto errexit;

       $SELECT max(dupdate)
         INTO $dupdate
         FROM ca_cb_est_h;
	
	printf("���%s",dupdate);

	strcpy(content,"\n");
	sendmail=0;

    $DECLARE estA CURSOR FOR
      SELECT  iclaim, iestimate, fstatus
        INTO $iclaim,$iestimate,$fstatus_h
        FROM ca_cb_est_h
       WHERE dupdate=$dupdate
         AND dtrans is null 
     ORDER BY iclaim;

    $OPEN estA;
    while(1)
	{
	    $FETCH estA;
	    if(SQLCODE == SQLNOTFOUND) break;

		$select fstatus
  		   into $fstatus
		   from ca_cb_est
          where iclaim = $iclaim
			and iestimate = $iestimate;

		if (strstr(fstatus,"20") ==0 || SQLCODE == SQLNOTFOUND)
		{

			$delete from ca_cb_est
	          where iclaim = $iclaim
				and iestimate = $iestimate;

			$delete from ca_cb_est_dtl
	          where iclaim = $iclaim
				and iestimate = $iestimate;

			$delete from ca_cb_est_acc
	          where iclaim = $iclaim
				and iestimate = $iestimate;

			$insert into ca_cb_est 
				select iclaim,iestimate,fstatus,destimate,iest_rep_id,
					   itag,iengine,qmeter,ncust_name,dreceive,nbrand,
					   0,current,ivision,nnote
				  from ca_cb_est_h
 	             where iclaim = $iclaim
				       and iestimate = $iestimate
					   and dupdate=$dupdate; 

			$insert into ca_cb_est_dtl 
				select iclaim,iestimate,iserial,ipnc_id,
					   irepair_type,irepair_type_n,iitem_name,
				       qplate_hour,mplate,mplate_n,
        			   qvarnish_hour,mvarnish,mvarnish_n,
				       qremove_hour,mremove,mremove_n,
  				       ipart_no,mpart_unit,qpart,qpart_n,mpart,mpart_n,
				       iinvest,dinvest
				  from ca_cb_est_dtl_h
 	             where iclaim = $iclaim
				       and iestimate = $iestimate
					   and dupdate=$dupdate; 

			$insert into ca_cb_est_acc
				select iclaim,iestimate,invoice,dreceive,
				   	   mwork,mpart,mamount
				  from ca_cb_est_acc_h
                 where iclaim = $iclaim
				       and iestimate = $iestimate
					   and dupdate=$dupdate; 

			$update ca_cb_est_h
			    set dtrans =today 			
		      where iclaim = $iclaim 
  		        and iestimate = $iestimate;
		}
		else
		{
			sendmail = sendmail+1;
			sprintf_s(content,9000,"%s<tr><td>\n",content);
			sprintf_s(content,9000,"%s�߮׸��X�G %s\n",content,iclaim);
			sprintf_s(content,9000,"%s������s���G %s\n",content,iestimate);
			if(strstr(fstatus_h,"10") >0)
			{
				sprintf_s(content,9000,"%s������J�����檬�A(10) < ������檬�A(20)�C\n\n",content);
			}
			if(strstr(fstatus_h,"20") >0)
			{
				sprintf_s(content,9000,"%s���~��]�G������J�����檬�A(20)�A������檬�A(20)�A��Ƥw������J�C\n\n",content);
			}
			sprintf_s(content,9000,"%s</td></tr>\n",content);
		}
	}
	$close estA;
	$free  estA;

        printf("content[%s]\n",content);

	strcpy(project_id,"CAR916");
	strcpy(receiver_email,"cyrus@tmnewa.com.tw");
	strcpy(nsubject,"���׹q�l����J������");
        ctxt.loc_loctype = LOCMEMORY;
        ctxt.loc_buffer = content;
        ctxt.loc_size =  strlen(content) + 1; 
	mdate = cm_today()+1;

	$execute pre_cnt1 into $cnt;
	strcat(msgbuf,"�{���D�ɸ��:");
	sprintf_s(msgbuf,9000,"%s[%d]\n",trim(msgbuf),cnt);
	
	$execute pre_cnt2 into $cnt;
	sprintf_s(msgbuf,9000,"%s�{�����Ӹ��:",trim(msgbuf));
	sprintf_s(msgbuf,9000,"%s[%d]\n",trim(msgbuf),cnt);
	
        /*****************************************************
	$execute pre_cnt3 into $cnt;
	sprintf_s(msgbuf,9000,"%s�{�����b���:",trim(msgbuf));
	sprintf_s(msgbuf,9000,"%s[%d]\n",trim(msgbuf),cnt);
        ******************************************************/

	sprintf_s(msgbuf,9000,"%s�@��%d����ƥ���J�Χ�s",trim(msgbuf),sendmail);

	if (sendmail != 0)
	{
		$INSERT INTO batchemail 
			(project_id, mail_date, receiver_email, content,nsubject)
             VALUES
            ($project_id,$mdate,   $receiver_email, $ctxt,$nsubject);
	}

	return M_CM_OK;

errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
