/**********************************************************************/
/*                                                                    */
/*   program id   : ca330q01s.ec                                      */
/*   program name : �����M�ץ���O�X��@�~                            */
/*   date written : 2004/06/28                                        */
/*   date modify  : 2006/11/08 �W�[�ѨϥΪ̨M�w�O�v�N�� by Jessie     */
/*   author       : Neo Chen                                          */
/**********************************************************************/
 
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"
$include "ca301lib.h";
#include <math.h>
$include "cmnroute.h";
$include "car_common.h";

/*--------------------------------------------------------------------*/
$char  pro_no[5], dbgn[11], dend[11];

/** read file **/
$char  sdata[10][121];
 FILE  *fp;
 int   flen,cnt;

/** cal_prem **/
$char   ipolicyA[21], ipolicyB[21], last_ply_A1[21];
$char   A_dbegin[13], itreaty[3];
$char   ibrand[10], iresource[3];
$long   dissue = 0;
$char   ibroker[11], ileader[11], icashier[11], iarea[3];
$char   iquota[8], icomp_in[3], ibranch_in[3], icomp_at[3], ibranch_at[3], frate[4];
$char   ical_ins[INSURANCE_TYPE], fcal_class[2];
$char   dply_begin_a[20], dply_end_a[20];

$double  mcar_price_1;
$double  rate_prem;
$int     i_drate_ym,icnt302;
$double  cal_ins_premium , cal_discount , mins_discount , mins_premium;
$long    t_zero;
$double  d_zero;
$char    c_zero[2], no_char[2], c_ipaid_base[2];

/* SetCarage*/
$long   tmp_cover_dep, thousand_cover_dep;
$long   cover_dep,cover_dep_11;
$int    adj_age;
$double adj_yr_dep;
$double pdep_rate_year;

$char ymd_Today[12];
$char tmp_icardyear[5];
$char sTmpIbranchCard[BRANCH_ID], sTmpIcompCard[BRANCH_ID];

/** policy A **/
$char   ibig_office[11], ibig_sales[11], ixxcard[21];
$char   iquota14[5], itel[21], mobile[21], feply[2], aemail_eply[51], tmobile_eply[21], feterms[2];
$char   ftrans_third[2];
$char   iply_area[11], apayment[90], apayment_zip[CA_ZIP], aassured[90], aassured_zip[CA_ZIP];
$char   nequipment_A[31], ientry_A[11], ipro_year[5];
$int    qpro_month = 0;
$double pdmg_factor = 0, psex_age, plia_acc = 0;

/** policy B **/
$char   fassured[2], iassured[13], iassured_ext[3];
$char   fmarriage[2], nuser[20], ibenef[11], nbenef[42];
$char   nbrand_abbr[13], ncar_abbr[13];
$char   nequipment[31], fcal_way[2], N_sales[11];
$char   ilast_card[21], iofficerB[11], iquotaB14[5], tmp_itag[CA_TAG_NUM];
$double qcylinder = 0;   /* �Ʈ�q�X�ܤp���I2�� (1080902001_SC3) */

/** ply_ins_type **/
$int   mdeduct;
/*
$long  mdmg_agent_2, mdmg_commi_2, mdmg_disco_2, mdmg_prem, mdmg_pure_prem;
$long  mlia_agent_2, mlia_commi_2, mlia_disco_2, mlia_prem, mlia_pure_prem;
*/
$char  fins_grp_1[2];

/* ca_promote */
$char  iprmt[11], nprmt[31], iagent[11], iofficer_1[2], ioff_chk[11], str_iagent[21];
$char  fanother[2], iofficera_1[2], ioff_chka[11], ioff_chk_B[6], iins_list[21];
$int   iremark, iofficer_len, ioff_ck_bgn, ioff_ck_len, ioff_ck_end;
$long  mlimit, lMdeduct, lminjured_cover, lmdeath_cover, lmdamage_cover;

$int   lofficera , ioff_chk_bgna, ioff_chk_lena, ioff_ch_enda;

$char  sIinsType[INSURANCE_TYPE];
$char  tmp_iins_list;

/** ======  **/
$char  off_name[15], big_name[15], tmp_buf[20], s_mins_prem[20];
int    get_officer;
$char   errmsg[201];
int    cnt_car330_tmp;


$char DBName[05], iForm_Tp[03];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
$char userid[11],choice[2];

char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  Width;
static int  max_cnt,num;
char  v_sMsg[1024];
char  ideviation[3];
$double deviation_rate;    /* �«O�O�����v */

/* 97.11�J�O�v�ۥѤ� */
$char f980101[2];          /*1:cm_extra_charge�O�v�ͮĤ�>=980401,�O�v�ۥѤƫ�
                             0:cm_extra_charge�O�v�ͮĤ�< 980401,�O�v�ۥѤƫe */
$char iextra_charge[11]=" ";
$double pbusiness;         /* �~�޶O�βv */

/* 980520,�j�v�~�Ȫ��[����*/
char   chkProvision[2];    /* �j�v�~�Ȫ��[���� */
char   tmpProvisionType[2];/* �j�v�~�Ȫ��[ A���ک�B���� */
char   imanage[7];         /* �޲z���I�[��O�T�� */
char   isafe[7];           /* �w�����I�[��O�T�� */
char   ieducated[7];       /* �g��ץ��]�l */

int     IsProvision;       /* �O�_���A�Ϊ��[���� */
char    sProvisionType[2]; /* �j�v�~�Ȫ��[ A���ک�B���کΨ������[����(F����) */
$double pmanage_rate;      /* �޲z���I�[��O�T�� */
$double psafe_rate;        /* �w�����I�[��O�T�� */
$double peducated_rate= 1.0;    /* �g��ץ��]�l */

$double dbl_safe_rate = 0.0,dbl_manage_rate=0.0,dbl_educated_rate=1.0; /* �s ply_ins_type���� */
$char   chr_provision[21]="";
$double plia_acc2_ori, pdmg_acc_ori;
$int    irate_1 = 0;
$double adjust_rate = 0.0;
$double mins_premium_n;
$double mpure_prem_n;
$long   mprem_n;

long car330_build();
long car330_read_file();
void car330_title();
static double MyPower();
static int SetCarAge();
static char *get_car_full_db();  /*   �ǤJ�O�渹��X���O�檺�k�ݸ�Ʈw */
static double dbl_len8();
double d45();
int  strSearchReplace();
long get_ca_id_officer();
char* trimx();
DBinfo  *dbList;
DBinfo  *list;
DBinfo  *get_sysdb_list();
int     count_db;

$double v_iAge; /* 970908,�אּdouble*/
$char   fsex[2],nequipment_s[31];

$char   irate_type_A[2] , icomm_obj_A[11] , iroute_comm_A[4] , iroute_prop_A[3];
$char   irate_type_B[2] , icomm_obj_B[11] , iroute_comm_B[4] , iroute_prop_B[3];
int     chkFrate;
$char   ftype_pol[3],ftype_sp[3]; /* �t�X���O�X��104.01.01�W�u, �s�W ftype_sp ��� add by sylvia 103.12.02 (1031111001_C3) */
$char   execItem[2], sFcommit[2];
$char   iassured_cntry[2], iapplicant_cntry[2];
$char   foccup[2], noccup[6], applicant_foccup[2], applicant_noccup[6], 
        fsame_one[2], fHiRBA[2];/* RBA�ק� add by sylvia 106.08.11 (1060606002_C5) */
$char   foffice[2];
int     rtncode;



/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;

   batchinit();
   $WHENEVER SQLERROR GOTO errexit;
   strcpy(DBName, isNULLstr(argv[1]));
   strcpy(userid, isNULLstr(argv[2]));
   strcpy(pro_no, isNULLstr(argv[3]));
   strcpy(execItem, isNULLstr(argv[4]));
   strcpy(frate,  isNULLstr(argv[5]));
   strcpy(chkProvision,  isNULLstr(argv[6]));
   strcpy(tmpProvisionType,isNULLstr(argv[7]));
   strcpy(imanage     ,  isNULLstr(argv[8]));
   strcpy(isafe       ,  isNULLstr(argv[9]));
   strcpy(ieducated   ,  isNULLstr(argv[10]));
   strcpy(outputf,isNULLstr(argv[11]));

   /* �J��H���B�պ�H���@�ߧ�^�PA��H��(1091021005_SC1) */
   /*strcpy(entry,  userid);*/  
   rtoday(&Today);     /* get today's datetime */
   /*deviation_rate = atof(ideviation);   */
   pdiscount      = 0.0;
   deviation_rate = 0.0 ;
   IsProvision    = atoi(chkProvision);     /* 980520, 0:�D�j�v�~�� 1:�j�v�~�� */
   strcpy(sProvisionType,tmpProvisionType); /* 980520, �j�v�~�Ȫ��[ A���ک�B����, "0"���ܵL�j�v�~�Ȫ��[���� */
   pmanage_rate   = atof(imanage);          /* 980520, �޲z���I�[��O�T�� -10 ~ 10 */
   psafe_rate     = atof(isafe);            /* 980520, �w�����I�[��O�T�� -10 ~ 10 */
   peducated_rate = atof(ieducated);        /* 980520, �g��ץ��]�l ,�ثe�T�w�� 1 */

   printf(" execItem = [%s]\n " , execItem);
   printf(" IsProvision    = [%d]\n " , IsProvision);
   printf(" sProvisionType = [%s]\n " , sProvisionType);
   printf(" pmanage_rate   = [%f]\n " , pmanage_rate);
   printf(" psafe_rate     = [%f]\n " , psafe_rate);
   printf(" peducated_rate = [%f]\n " , peducated_rate);

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }



   if ((list = get_db_list (&count_db, DBName)) == (char *) 0)
   {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == True)
            return M_CM_NOT_DBLIST;
      return M_CM_OK;
   }
   printf("frate=[%s]\n", frate );
   printf("atoi(frate)=[%d]\n", atoi(frate) );
   /* 101.07.05 */
   if (atoi(frate) < 0){
       chkFrate  = 1;   /* ����O�ͮĤ��O�v�ɤ��O�v�N�� (frate = -1)*/
   }else{
   	   chkFrate  = 0;   /* �ѨϥΪ̪�����J�O�v�N�� (=frate )*/
   }

   /* 980520,�����O�v�ۥѤƧP�_ , �@�ߥu��ϥηs�O�v�X�� */
   /* 97.11�J�O�v�ۥѤ�
   $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
     INTO $f980101
     FROM ca_rate_date
    WHERE icode  = $frate
      AND itable = 'cm_extra_charge';
   if (NOT_FOUND)  return M_CA_EXTRA_CHARGE_DRATE;
   */
/*
   if (atoi(frate)<22) {
       EWRITE(userid, M_CA_NEW_RATE, "98/05/01��Шϥηs�O�v�X��");
       return M_CA_NEW_RATE;   "ñ��鬰98/05/01(�t)�H��, �����H�s�O�v�X��A�Ь��ӫO��"
   }
*/
   strcpy(f980101,"1");
   printf("f980101[%s]\n", f980101);


   rc = get_ca_promote();
   if( rc != M_CM_OK )
   {
      return rc;
   }

   rc =  car330_read_file();
   if( rc != M_CM_OK )
   {
    	return rc;
   }
   rc = car330_build();
   if( rc != M_CM_OK )
        return rc;

   printf("car330_build success \n");
   printf("Trace -- userid = [%s] \n",  userid);
   if ((rc=save_form_info(F_BLK0, "CA", 330, userid, iForm_Tp, max_cnt, outputf))<0) {
           strcpy(msgbuf,"save_form_info failed");
           return rc;
       }
   printf("save form ok\n");

   return ;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;

}
/*--------------------------------------------------------------------*/

long car330_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1], tmpcard[21]  ;
   int    rc;
   $char  stmt[500], remark[201];
   $int   cnt_car330_tmp1 = 0;

   printf("--------------------\ncar330_build start\n");
   printf("outputf[%s]\n",outputf);

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth ,iform_tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width ,$iForm_Tp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 330;

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
   sprintf_s(BodyFile, sizeof BodyFile,"%s.bd",outputf);

   printf("@@@@@@@@@@@@@@@@@@ titlefmt = [%s]\n",TitleFile);


   rgu_init_report(TitleFmt,TitleFile);
   car330_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);

   /** Body Form �e�X����B�z **/
   if (execItem[0]=='0'){
   	   rgu_put_body_string(1, "����",1);
   }else if (execItem[0]=='1'){
   	   rgu_put_body_string(1, "�X��",1);
   }

   rgu_put_body_string(1, cm_get_sysd(),1);
   rgu_put_body(1);
   max_cnt += 5;

   rc = car330_cal_prem();

   printf("=====> exit car330_cal_prem \n");
   printf("=====> rc[%d] \n", rc);

   $SELECT count(*)
      INTO $cnt_car330_tmp1
      FROM CAR330_TEMP1;

   printf("cnt_car330_tmp1=[%d]\n", cnt_car330_tmp1 );

   if( cnt_car330_tmp1 > 0 )
   {
       $DECLARE car330_cur1 CURSOR FOR
   	   SELECT *
   	   INTO $iofficer, $off_name, $ibig_office, $big_name,
                $ply_num2, $dply_begin_a, $dply_end_a, $iengine,
                $itag, $nassured, $s_mins_prem, $remark,$iapplicant,$napplicant,
                $tmpcard, $iassured_cntry, $iapplicant_cntry, $foccup, $noccup,
                $applicant_foccup, $applicant_noccup
   	   FROM CAR330_TEMP1;
       $OPEN car330_cur1;
       while(1)
       {
       	   $FETCH car330_cur1;
       	   if(SQLCODE == SQLNOTFOUND) break;

       	   printf("ply_num2=[%s] iofficer=[%s]\n", ply_num2, iofficer);

       	   rgu_put_body_string(2,trim(iofficer),	LEFT);
           rgu_put_body_string(2,trim(off_name),	LEFT);
           rgu_put_body_string(2,trim(ibig_office),	LEFT);
           rgu_put_body_string(2,trim(big_name),	LEFT);
           rgu_put_body_string(2,trim(ply_num2),	LEFT);
           rgu_put_body_string(2,trim(dply_begin_a),LEFT);
           rgu_put_body_string(2,trim(dply_end_a),	LEFT);
           rgu_put_body_string(2,trim(iengine),	    LEFT);
           rgu_put_body_string(2,trim(itag),    	LEFT);
           rgu_put_body_string(2,trim(nassured),	LEFT);

           /*rgu_put_body_string(2,trim(tmp_buf),	        LEFT);*/
           rgu_put_body_string(2,trim(s_mins_prem), LEFT);
           rgu_put_body_string(2,trim(remark),	    LEFT);
           rgu_put_body_string(2,trim(iapplicant),	LEFT);
           rgu_put_body_string(2,trim(napplicant),	LEFT);

           /* if(iofficer[0] == 'N')
           {
               strncpy(card2,tmpcard,9);
               card2[9] = '\0';
           }
           else */
               strcpy(card2,tmpcard);

           rgu_put_body_string(2,trim(card2),	  LEFT);
           rgu_put_body_string(2,iassured_cntry,  LEFT);  /* �Q�O�I�H��O���O(RBA) add by sylvia 105.03.03 (1050105008_C4) */
           rgu_put_body_string(2,iapplicant_cntry,LEFT);  /* �n�O�H��O���O(RBA) add by sylvia 105.03.03 (1050105008_C4) */
           rgu_put_body_string(2,feply,	          LEFT);  /* �q�l�O����O add by 061476 107.11.12 (1070809006_SC4) */             
           rgu_put_body(2);
           max_cnt++;
       }
       $CLOSE car330_cur1;
       $FREE  car330_cur1;


   }
   else if( rc != M_CM_OK )
   {
    	/* sqlfatal(); */

        EWRITE(userid,rc,"");

        /* EWRITE(userid,rc,sqlca.sqlerrm);  */
    	return FAIL;
   }

   rgu_finish_report();

   printf( " next is M_CM_OK \n");
   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return FAIL;
}

/*--------------------------------------------------------------------*/
long car330_read_file()
{
    char   *bp;
    int    rc,i,j,k,m,n;
    char   filename[50], sApHome[30];
    $char  ipolicy[21];


    $whenever sqlerror goto errexit;

    printf("car330 read file start\n");

    rc = car330_create_table();

    rc = getApHome(sApHome);
    if (rc < 0) {
       strcpy(msgbuf,"read Config file error!!-->getApHome\n");
       EWRITE(userid,rc,msgbuf);
       return rc;
    }


    sprintf_s(filename, sizeof filename,"%s/dat/car/car330.txt",sApHome);
    printf("filename[%s]\n",filename);
    flen=1024;

    if ((fp=fopen(filename,"r"))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���\n",filename);
       return 1;
    }
    if ((bp=malloc(flen))==NULL) {
       strcpy(msgbuf,"System malloc failed !\n");
       return 1;
    }

    $begin work;
    for (i=0;(feof(fp)==0);i++) {
        memset(bp,0x00,flen);
        fgets(bp,flen,fp);
        if (bp[0]==0x00) break;

        if (execItem[0]=='0'){ /* �����ɡA�ɻ�6�����(�w���������@�~) */
           strcat(bp,"\t\t ");
        }
        for(j=0;j<9;j++)
           memset(sdata[j],0x00,121);

        k=m=n=0;
        for (j=0;j<flen;j++) {
            if (bp[j]=='\t' || bp[j]=='\0' || bp[j]=='\n') {
                strncpy(sdata[k],bp+m,j-m);
                sdata[k][j-m]='\0';
                m=j+1;
                k++;
            }
            if (bp[j]=='\n')
                break;
            if (k > 8) break;
        }

        if (sdata[0][0]=='\0' || strlen(trim(sdata[0]))==0) continue;
        rtrim_alldata2();

        /* ipolicyA,ipolicyB,iengine,itag,iofficerB2,iestimateB */
        $insert into CAR330_PLY
         values ($sdata[0], $sdata[1], $sdata[2], $sdata[3], $sdata[4], $sdata[5]);
    }
    $commit work;

    printf("car330 read file end\n");

    return M_CM_OK;
errexit:
    sqlfatal();
    return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car330_create_table()
{
   $whenever sqlerror goto errexit;

   /* 101.08.24 ,�M�ץ���O�X��n�O�H�@�ߧ� ca_dealer_appl(car152)*/
   $CREATE TEMP TABLE CAR330_PLY
   (

      ipolicyA   char(20)  default ' ',
      ipolicyB   char(20)  default ' ',
      iengine    char(25)  default ' ',
      itag       char(12)  default ' ',
      iofficerB2 char(10)  default ' ', /* �i��O�X�椧B��g��N�� */
      iestimateB char(20)  default ' '
   )
   WITH NO LOG;

   $CREATE TEMP TABLE CAR330_TEMP
   (
      iofficer      char(10),
      off_name      char(12),
      ibig_office   char(10),
      big_name      char(12),
      ply_num2      char(17),
      dply_begin_a  char(10),
      dply_end_a    char(10),
      iengine       char(25),
      itag          char(12),
      nassured      varchar(60),
      s_mins_prem   char(14),
      remark        varchar(200) default ' ',
      iapplicant    char(12),
      napplicant    varchar(120),
      icard         varchar(20),
      iassured_cntry    char(1),
      iapplicant_cntry  char(1),
      foccup        char(1),
      noccup        varchar(5),
      applicant_foccup  char(1),
      applicant_noccup  varchar(5)
   )with no log;


   $CREATE TEMP TABLE CAR330_TEMP1
   (
      iofficer      char(10),
      off_name      char(12),
      ibig_office   char(10),
      big_name      char(12),
      ply_num2      char(17),
      dply_begin_a  char(10),
      dply_end_a    char(10),
      iengine       char(25),
      itag          char(12),
      nassured      varchar(60),
      s_mins_prem   char(14),
      remark        varchar(200) default ' ',
      iapplicant    char(12),
      napplicant    varchar(120),
      icard         varchar(20),
      iassured_cntry    char(1),
      iapplicant_cntry  char(1),
      foccup        char(1),
      noccup        varchar(5),
      applicant_foccup  char(1),
      applicant_noccup  varchar(5)
   )with no log;

   cnt_car330_tmp=0;

   return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/*--------------------------------------------------------------------*/
rtrim_alldata2()
{
    int  x;
    for(x=0;x<9;x++)
       strcpy(sdata[x],trimx(sdata[x]));
}
/*--------------------------------------------------------------------*/

long car330_cal_prem()
{
   $char  stmt[4096];
   $char  car_dbnameB[21], car_dbnameA[21], inext_ply_B[21];
   $char  Biofficer_emp[11],estr[2], cdply_begin_a[20], iassured[13];
   int    code,rc, i,j;
   int    ins_cnt=0, tmp_ins;
   $long  i_rtn;
   $int   iCount;
   $int   qyear_A;
   char   flg_NoPolicyB='N';
   $long  ldbgn,ldend;
   $char  iissue_ym_A[7];
   long   lng_iissue_ym_A;
   $char  tmp_ply_B[21], iissue_ymd[11];
   $long  dbirth;
   $int   cnt_chk = 0;
   $int   flg_chk = 0;
   $char  sTable[25], sDbirth[11];
   $char  fcomm_agent[2];
   $int   kk = 0;
   $char  iofficer_A[11];
   char   fnext_plyb;
   $char  sFstart[2]=" ", sFauth[2]=" ";
   $struct cm_route_comm o_stcomm;
   int    o_qrec = 0;
   $char  bzfrom_B[3]=" ";

   $char idealer[4]=" ";      	    /*�g�P�ӥN��		*/
   $char fapplicant[2]=" ";         /*�n�O�H�ʽ�	1:�ꤺ�۵M�H 2:�ꤺ�k�H 3:��~�۵M�H4:��~�k�H 5:�ꤺ�۵M�HID���~6:�ꤺ�k�HID���~	*/
   $char iapplicant[13]=" ";   	    /*�n�O�H������/�νs		*/
   $char fsex_appl[2]=" ";	    /*�n�O�H�ʧO 1:�k  2:�k 	�ť�:�k�H*/
   $date dbirth_appl;               /*�n�O�H�X�ͤ��		*/
   $char napplicant[121]=" ";	    /*�n�O�H�W��	        */
   $char itel_appl[21]=" ";	    /*�n�O�H�q��		*/
   $char apayment_zip[CA_ZIP]=" ";  /*�n�O�H�a�}�l���ϸ�        */
   $char apayment[91]=" ";	    /*�n�O�H�a�}	        */
   $char ndeputy_appl[51]=" ";	    /*�n�O�H���k�H�N���H	*/
   $char nrelation_appl[41]=" ";    /*�n�O�H�P�Q�O�I�H���Y	*/
   $char ndeputy_assured[51]=" ";   /*�Q�O�I�H���k�H�N���H	*/
   $char iestimateB[21] = " ";      /*�����渹                  */
   $char isub[3] = " " , iroute_B[21];
   $double dbl_mins_premium;
   $int  estimate_fstatus;
   $double dbl_estimate_prem;
   $char itmp_plyB[21];
   $char iofficerB2[11],iins_kind_ply[3],chk11B[2], explicyb[21];
   $char sIins_cat[2];  /* �����������I�O add by sylvia 103.11.14 (1031103007_C2) */
   $char cm_iassured[11], cm_iroute12[3], cm_iroute[21],cm_ipolcy1[21];
   $char funder_chk[2]=" ";
   $int  fsign_status = 0;

   /* N�g�����  (1030630002_C1) */
   $char sIquotaA[11],sIquotaB[11];
   $char sRtype[3];  /* ���d������:NA�BNB�BCP */
   $int icount_10,icount_20,icount_RN;
   $int f1040301,f1040101,icnt;
   $char sPaydate[11];
   $char isign[11];
   $char isign_iupcomp[2],ply_iupcomp[2];

   $char rba_cty[2],rba_noccup[7];
   $char iassured_rba[2],iapplicant_rba[2],nassured[121],fresult[2],nresult[121];
   $char ddate1[11],ddate2[11];
   $char ichk_A[3],ichk_last[2]; /*PQ���ڨϥΪ��ܼ� add by 061476 (1071226006_SC9) */
   $char tmp_provision[22];

   char  fGetNumErr = 'N';

   printf("==========================\ncar330_cal_prem start\n");

   printf("~~~iins_list=[%s]\n", iins_list);



   $whenever sqlerror goto errexit;

   /* 102.03 �s�W/��s cm_pre_receive  */
   /* Insert �w���@�γ����� (cm_pre_receive)  */
   /* �I�O	�����渹	�I��	���O���A	�t�B���	�Q�O�HID	�Q�O�H�W��	�n�O�HID	�n�O�H�W��	���P���X	�������X	�w�w�ͮİ_��	ú�O����	������ú�O�O	�����q�O	�g��N��	�޲z�H	�~�Z���	�I����H	�q���N��	�����O	��J�H��	��J���	�t�ΧO	�Ȥ�̫�ú�ڤ�	�̫�J�b��	�H�uú�O�帹	���A	��s�H��	��s���	�O�渹�X1	�O�渹�X2	��渹�X	�O�d���X	�L��ɶ�	ú�ڳ�C�L�ɶ�	��z�覡 �O�����O */
   sprintf_s(stmt, sizeof stmt, "INSERT INTO cm_pre_receive  "
                       "(iins_cat,ipre_rcv,iins_kind,iins_kind_ply,ftype,ipre_end,iassured,nassured,iapplicant,napplicant,itag,iengine,deffect,paydate,mprem,isub,iofficer,ileader,iquota,icomm_obj,iroute,fcommit, ientry,dentry , isys,igroup,fstatus,iupdate,dupdate,ipolicy1,ipolicy2,iendorse,icard,dprint,dprint_rcv,iedr_return,ftype_pol,ftype_sp,dbegin,dend )  "
                "VALUES ('C'     ,   ?    ,   ?     ,    ?        ,'P' ,  ' '   ,    ?   ,    ?   ,     ?    ,    ?     ,  ? ,   ?   ,   ?   ,   ?   ,  ?  ,  ? ,    ?   ,   ?   ,   ?  ,    ?    ,   ?  ,   ?   ,  ?    ,current,   ? , ' '  ,  10   ,   ?  ,current,  ' '   ,  ' '   ,  ' '   , ' ' , NULL , NULL  ,   '9'      ,    ?        , ?      , ?    ,?    ) ") ;
   $PREPARE prep_receive FROM $stmt;

   /* Update �w���@�γ����� (cm_pre_receive) */
   /* �t�X���O�X��104/01/01�W�u,�M�ץ�J�渹,���Hcar327�C�O��,�G���{���������^��ñ���,�����ܫO�檬�A modify by sylvia 103.12.10(1031111001_C3) */
   /* sprintf_s(stmt, sizeof stmt, "UPDATE cm_pre_receive Set fstatus = 60, dupdate = current, ipolicy1 = ?, icard = ?, dprint=current, ftype_pol = ?, ftype_sp = ?  "
                   "WHERE iins_cat='C' and ipre_rcv = ? and iins_kind = '2' and ipre_end = ' ' ") ;          */
   sprintf_s(stmt, sizeof stmt, "UPDATE cm_pre_receive Set dupdate = current, ipolicy1 = ?, icard = ?, fcommit = ?, ftype_pol = ?, ftype_sp = ?, dbegin = ?, dend = ?, iupdate = 'CAR330'   "
                   "WHERE iins_cat='C' and ipre_rcv = ? and iins_kind = '2' and ipre_end = ' ' ") ;
   $PREPARE prep_upd_receive FROM $stmt;

   /* Update �w���@�γ����� (cm_pre_receive) modify by sylvia 103.11.04 (�]��N�g��N��, ���car301�^��cm_pre_receive������*/
   /* �t�X���O�X��104/01/01�W�u,�M�ץ�J�渹,���Hcar327�C�O��,�G���{���������^��ñ���,�����ܫO�檬�A modify by sylvia 103.12.10(1031111001_C3) */
   /* sprintf_s(stmt, sizeof stmt, "UPDATE cm_pre_receive Set fstatus = 60, dupdate = current, ipolicy1 = ?, icard = ?, dprint=current,  "
                        "iofficer = ?, ileader = ?, iquota = ?, icomm_obj = ?, iroute = ?, fcommit = ?,  "
                        "ftype_pol = ?, ftype_sp = ?  "
                  "WHERE iins_cat='C' and ipre_rcv = ? and iins_kind = '2' and ipre_end = ' ' ") ; */

  sprintf_s(stmt, sizeof stmt, "UPDATE cm_pre_receive Set dupdate = current, ipolicy1 = ?, icard = ?,   "
                        "iofficer = ?, ileader = ?, iquota = ?, icomm_obj = ?, iroute = ?, fcommit = ?,  "
                        "ftype_pol = ?, ftype_sp = ?, dbegin = ? , dend = ?, paydate=?, iupdate = 'CAR330'   "
                  "WHERE iins_cat='C' and ipre_rcv = ? and iins_kind = '2' and ipre_end = ' ' ") ;
   $PREPARE prep_upd2_receive FROM $stmt;

   sprintf_s(stmt, sizeof stmt, "SELECT fstatus,mprem,ipolicy1,ftype_pol, ftype_sp, iassured, iroute[1,2], iroute  "
                  " FROM cm_pre_receive  "
                  "WHERE iins_cat='C' and ipre_rcv = ? and iins_kind = '2' and ipre_end = ' ' ") ;
   $PREPARE prep_sta_receive FROM $stmt;

   strcpy(ymd_Today, cm_cdate_str_100(Today));
   strcpy(estr," ");

   adjust_rate =0.0;
   irate_1 = 0 ;

   /* 101.08.24 ,�M�ץ���O�X��n�O�H�@�ߧ� ca_dealer_appl(car152)*/
   $BEGIN WORK;
   ins_cnt=0;
   $DECLARE cur_tmp_ply CURSOR WITH HOLD for
     SELECT ipolicyA, ipolicyB, iengine, nvl(itag,' '), iofficerB2, iestimateB
       FROM CAR330_PLY;
   $OPEN cur_tmp_ply;
   while(1)
   {
      if( ins_cnt == 10 )
      {
      	  /** 10 ����� commit �@�� **/
      	  $INSERT INTO CAR330_TEMP1
      	   SELECT * FROM CAR330_TEMP;
      	  $DELETE FROM CAR330_TEMP where 1=1;
      	  $COMMIT WORK;
      	  ins_cnt = 0;
      	  $BEGIN WORK;
      }
      fGetNumErr = 'N';
      printf("--->fetch cur_tmp_ply\n");
      $FETCH cur_tmp_ply INTO $ipolicyA, $ipolicyB, $iengine, $itag, $iofficerB2, $iestimateB ;
      if( SQLCODE == SQLNOTFOUND ) break;

      strcpy(iassured_cntry, " ");
      strcpy(iapplicant_cntry," ");
      strcpy(foccup, " ");              /* �Q�O�H¾�~�O Y:�D�@�� N:�@�� */
      strcpy(noccup, " ");              /* �Q�O�H¾�~�N�X */
      strcpy(applicant_foccup, " ");    /* �n�O�H¾�~�O Y:�D�@�� N:�@�� */
      strcpy(applicant_noccup, " ");    /* �n�O�H¾�~�N�X */
      strcpy(fsame_one," ");    /* �n�Q�O�H�O�_�P�@�H */
      strcpy(fHiRBA,"N");       /* �O�_�����I */

      /* �H�O��e�T�X�P�O���`�����q->�����q�L�A�ΪA�Ȥ���->�i���{��(car169) add by 061476 (1091021005_SC3) */
      if ((strncmp(ipolicyA,"000",3) == 0)||(strncmp(ipolicyA,"020",3) == 0)||(strncmp(ipolicyA,"225",3) == 0)||
          (strncmp(ipolicyA,"336",3) == 0)||(strncmp(ipolicyA,"401",3) == 0)||(strncmp(ipolicyA,"667",3) == 0)||
          (strncmp(ipolicyA,"702",3) == 0))
      {
          strcpy(foffice,"Y");       /* �O�_�`�����q */
      }else{
      	  strcpy(foffice,"N");
      }
      
      /* B��g��N���ˮ� */
      if( strlen(trim(iofficerB2)) == 0 ){
	      sprintf_s(errmsg, sizeof errmsg,"��J���u�i��O�X�椧B��g��N���v���ť�(��OA�渹[%s],������[%s])",ipolicyA, iengine );
	      printf("errmsg[%s]\n", errmsg);
	      $INSERT INTO CAR330_TEMP VALUES
	      ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
	      cnt_car330_tmp++;
	      continue;
      }else{
      	  cnt_chk = 0 ;
      	  $Select count(*) Into $cnt_chk From Officer Where iofficer = $iofficerB2;
      	  if (cnt_chk == 0){
		      sprintf_s(errmsg, sizeof errmsg,"��J���u�i��O�X�椧B��g��N��[%s]�v�b�g��H�ɤ����s�b(��OA�渹[%s],������[%s])",iofficerB2, ipolicyA, iengine );
		      printf("errmsg[%s]\n", errmsg);
		      $INSERT INTO CAR330_TEMP VALUES
		      ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
		      cnt_car330_tmp++;
		      continue;
	      }
      }
      
      /* B�������O�_�w���O�渹���L�� */
      strcpy(cm_ipolcy1," ");
      cnt_chk = 0;
      $Select ipolicy1, case when dprint is null then 0 else 1 end
         Into $cm_ipolcy1, $cnt_chk
         From cm_pre_receive
        Where iins_cat = 'C' and iins_kind = '2' and ipre_rcv = $iestimateB ;


      if (strlen(trim(cm_ipolcy1)) > 0)
      {
         if (cnt_chk == 0)
         {
            sprintf_s(errmsg, sizeof errmsg,"��J�������渹[%s]�w���O�渹[%s]���L��(��OA��[%s]����[%s]������[%s])",
                              iestimateB, cm_ipolcy1,ipolicyA,itag,iengine);
         }
         else
         {
            sprintf_s(errmsg, sizeof errmsg,"��J�������渹[%s]�w���O�渹[%s]�w�L��(��OA��[%s]����[%s]������[%s])",
                              iestimateB, cm_ipolcy1,ipolicyA,itag,iengine);
         }
	      printf("errmsg[%s]\n", errmsg);
	      $INSERT INTO CAR330_TEMP VALUES
	      ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
	      cnt_car330_tmp++;
	      continue;
      }

      strcpy(errmsg," ");
      /* 102.03�A����X��A���T�{�O�_�w���O�B���X��(�����檬�A��=50) */
      /* �]��b2c�T����������ݨD,������s�W���A40(ú�O��(�����w)), �G���אּ fstatus < 45 (1030915002_C1) */
      if (execItem[0]=='1'){
	      estimate_fstatus = -1;  dbl_estimate_prem =0.0; strcpy(itmp_plyB," ");
	      $EXECUTE prep_sta_receive Into $estimate_fstatus , $dbl_estimate_prem, $itmp_plyB ,$ftype_pol, $ftype_sp,
	               $cm_iassured, $cm_iroute12, $cm_iroute
	         USING $iestimateB ;
			
			printf("B2C_check dbl_estimate_prem = [%ld]", (long)dbl_estimate_prem);
			
	      /* [102.07.01] �w�����W�u�G�@�ߵ����ĳq��A���\���X��᦬�O */
	      /* �t�X���O�X��104/01/01�W�u, car330�u�t�d���O�渹,���^��ñ���,�]�����ެO�_�w���O... modify by sylvia 103.12.16 (1031111001_C3) */
         $select first 1 case when today >= '03/01/2015' then 1 else 0 end,
                         case when today >= '01/01/2015' then 1 else 0 end
            into $f1040301,$f1040101
            from policy_302;

	      strcpy(ftype_pol,trim(ftype_pol));
	      strcpy(ftype_sp,trim(ftype_sp));

	      /* ********************************************************************* */
	      /* �ˮ֬O�_��104/01-02�������O�� */

	      /* RN�w�q�קאּ--�L����O��,�䤺�e�t(103.12.25���e�{�ɷ|�Mĳ)(103.12.27 modify by sylvia):
	            (1)ñ��� < 104/01/01
                (2)�ͮĤ� < 104/01/01�A�B��104/02/28�e�����X��鵲�C
                (3)�ͮĤ鬰 104/01/01~104/02/28 ���¨��A�B��104/02/28�e�����X��鵲�C
                    �¨��w�q�G�]�ͮĦ~�� - �o�Ӥ�~��^ >   1 �Ӥ�   (�u�ݤ��)
          ************************************************************************* */
	      icount_RN = 0;
	      /* $select count(*) into $icount_RN
           from policy_302
          where dply_begin between '01/01/2015' and '02/28/2015'
            and iofficer[1,1] in ('W','N','H')
            and ipolicy not like '%-B'
            and (iestimate_ori = $iestimateB or iestimate_sug = $iestimateB); */
         $select count(*) into $icount_RN
           from policy_302
          where dply_begin <= '02/28/2015'
            and iofficer[1,1] in ('W','N','H')
            and (iestimate_ori = $iestimateB or iestimate_sug = $iestimateB);

         /* RN��(�L�����)�w�q�ק�,�DRN��@�߬����O�X��� add by sylvia 103.12.17 (1031111001_C3)(103.12.27 */
         /* if ((icount_RN > 0) && (f1040301 == 0)) */
         /* if ((f1040101 == 0) || ((f1040301 == 0) && (icount_RN > 0))) */
         if ((f1040301 == 0) && (icount_RN > 0))
         {
             strcpy(ftype_pol,"NA");
	         /* strcpy(ftype_sp,"RN");  */
	         strcpy(ftype_sp,"OT");  /* 1040424�q���ק�,�����Τ��� */
         }
	     else
	     {
       	      icount_20 = 0;       /* �O�g�N�ĳq */

       	      strcpy(cm_iassured, trim(cm_iassured));
       	      strcpy(cm_iroute, trim(cm_iroute));

       	      if (iofficerB2[0] != 'W')
       	      {
          	      $select count(*) into $icount_20
          	         from ca_permit
                     WHERE (dexpire IS NULL OR dexpire > today)
                       AND ftype_sp = '20'
                       AND ((iclass = '01' AND icode = $cm_iassured ) OR
                            (iclass = '02' AND icode = $itag ) OR
                            (iclass = '03' AND icode = $iengine ) OR
                            (iclass = '04' AND icode = $cm_iroute12) OR
                            (iclass = '05' AND icode = (SELECT iroute_main FROM cm_route WHERE iroute =
                               (select iroute from officer where iofficer = $iofficerB2) )));

          	      if (icount_20 > 0)
          	      {
          	         strcpy(ftype_pol,"SP");
          	         strcpy(ftype_sp,"20");
          	      }
       	      }

       	      /* �D�O�g�N�ĳq��W�g��,��@���,�A��ݬݬO�_�����q�ĳq�� sylvia 103.12.09 */
       	      if ((icount_20 == 0) || (iofficerB2[0] == 'W'))
       	      {
       	         printf("--812--- cm_iassured=[%s]itag=[%s]iengine=[%s]cm_iroute12=[%s]cm_iroute=[%s] ------ \n",icount_20,cm_iassured,itag,iengine,cm_iroute12,cm_iroute);
       	         icount_10 = 0;
          	      $select count(*) into $icount_10
          	         from ca_permit
                     WHERE (dexpire IS NULL OR dexpire > today)
                       AND ftype_sp = '10'
                       AND ((iclass = '01' AND icode = $cm_iassured ) OR
                         (iclass = '02' AND icode = $itag ) OR
                         (iclass = '03' AND icode = $iengine ) OR
                         (iclass = '04' AND icode = $cm_iroute12) OR
                         (iclass = '05' AND icode = (SELECT iroute_main FROM cm_route WHERE iroute =
                            (select iroute from officer where iofficer = $iofficerB2) )));

                   if (icount_10 > 0)
                   {
                      strcpy(ftype_pol,"SP");
       	            strcpy(ftype_sp,"10");
       	         }
       	         else
       	         {
                      strcpy(ftype_pol," ");
       	            strcpy(ftype_sp,"PA");
       	         }
                }
         }

	      /* if (estimate_fstatus < 50){ */
	      /* �P�Y���B���۽T�{,�Yfstatus=40���ܽдڤ�,�����i��Ф���ڶ�,�G�Y�n�P�_�w���O, �����Hfstatus < 50 �ӧP�_ (modify by sylvia 103.12.02) */
	      /* if (estimate_fstatus < 50){
	          if (estimate_fstatus == -1){
	              sprintf_s(errmsg, sizeof errmsg,"�����渹:[%s] ������[%s]�d�L���", iestimateB , iengine);
	          }else{ */
	                  /* 104/01/01���O�X��W�u,���{������B��O�_�w���O... */
	          	      /* if (strcmp(ftype_pol,"SP")!=0){
	                     sprintf_s(errmsg, sizeof errmsg,"�����渹:[%s](���A��[%d])�|�����O", iestimateB , estimate_fstatus);
	                  } */
/*	          }
	      }
	      if (estimate_fstatus > 50){
		      if (estimate_fstatus == 90){
		          sprintf_s(errmsg, sizeof errmsg,"�����渹:[%s](���A��[%d])�w�@�o", iestimateB , estimate_fstatus );
		      }else{
		      	  sprintf_s(errmsg, sizeof errmsg,"�����渹:[%s](���A��[%d])�w�X��(�O�渹�G[%s])�A", iestimateB , estimate_fstatus, itmp_plyB );
		      }
	      }      */
	      /* �]�����O�X��104/01/01�W�u,��g���A�P�_����(���A�P�_�O�_�w��)... */
	      strcpy(cm_ipolcy1," ");
	      $Select ipolicy1
             Into $cm_ipolcy1
             From cm_pre_receive
            Where iins_cat = 'C' and iins_kind = '2' and ipre_rcv = $iestimateB ;

	      if (estimate_fstatus == -1){
	            sprintf_s(errmsg, sizeof errmsg,"�����渹:[%s] ������[%s]�d�L���", iestimateB , iengine);
	      }else if(estimate_fstatus == 30){
	            sprintf_s(errmsg, sizeof errmsg,"�����渹:[%s](���A��[%d][%s])�w�X�楼���O", iestimateB , estimate_fstatus,cm_ipolcy1);
	      }else if(estimate_fstatus == 60){
	            sprintf_s(errmsg, sizeof errmsg,"�����渹:[%s](���A��[%d][%s])�w�X��w���O", iestimateB , estimate_fstatus,cm_ipolcy1);
	      }else if(estimate_fstatus == 90){
	            sprintf_s(errmsg, sizeof errmsg,"�����渹:[%s](���A��[%d])�w�@�o", iestimateB , estimate_fstatus );
	      }

	      /*if (estimate_fstatus != 50){*/
	      
	      if (strlen(trim(errmsg))>0){
	          $INSERT INTO CAR330_TEMP VALUES
	          ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
	          cnt_car330_tmp++;
	          continue;
	      }	      
	      
      }
      printf("----- 840 ftype_pol=[%s]ftype_sp=[%s]-----\n",ftype_pol,ftype_sp);
      flg_NoPolicyB ='N'; /* flag for �S��B�� */

      /** 990510, ���ظU�o�ֱM��(C17)�Ĥ@�~�LB��,�HA���ƥXB��**/
      /** 970813, �s�߶R�@�e�|�M��(P01)�Ĥ@�~�LB��         **/
	   /** 960227, �U�o�ֱM��(C15)�Ĥ@�~�LB��,�HA���ƥXB��**/
      /*  102.02.08, ISPROJ_NO_FST_PLY_B()����,�w�q��car_common.h *//*1020805:�s�WY45*/
	   if( strlen(trim(ipolicyB)) == 0 ){
		   if (ISPROJ_NO_FST_PLY_B(pro_no)){
 		      strcpy(ipolicyB,ipolicyA);
              printf("ipolicyA[%s]\n", ipolicyA);
              printf("ipolicyB[%s]\n", ipolicyB);
		   }
		   flg_NoPolicyB ='Y';
	   }
      strcpy( car_dbnameB, get_car_full_db(ipolicyB));
      strcpy( car_dbnameA, get_car_full_db(ipolicyA));

      printf("trace ipolicyA[%s] ipolicyB[%s] \n ",ipolicyA,ipolicyB);
      printf("trace iengine[%s] itag[%s] \n ",iengine,itag);
      printf("trace flg_NoPolicyB[%c]\n ",flg_NoPolicyB);

      Icurr = Ifirst = Ilast = NULL;
      printf("----- 891 ftype_pol=[%s]ftype_sp=[%s]-----\n",ftype_pol,ftype_sp);
      printf("car_dbnameB[%s] car_dbnameA[%s]\n", car_dbnameB, car_dbnameA);
      printf("ipolicyA[%s] ipolicyB[%s]\n",ipolicyA, ipolicyB );
      /** Step1.1 �s�XB�椧�O���H�s�X��A��O������ **/
      /* 991224, iply_area,aassured_zip,aassured,apayment_zip,apayment ��qA���*/
      /* 971112,��ibig_office �޿�,�ζ��� ibig_office = A��iofficer; �D�ζ��� ibig_office = A�� ibig_office*/
      /* RBA�t�Ϋظm add by sylvia 105.03.03 (1050105008_C4)  */
      /* 1070622 itel��qA���B�W�[mobil_phone��� (1070308010_SC1) */
      /* 1071112 �W�[feply,aemail_eply���(1070809006_SC4) */
      /* 1080618 �s�W�q�l�O����²�T��� (1080417001_SC3) */
      /* 1091207 �s�Wnequipment,ientry,ipro_year,qpro_month��� (1091021005_SC3) */
      /* 1100607 �s�W�ȥ��O��u�q�l���ڡv���O��� (1100419003_SC4) */
      /* 1110324 �s�W�ĤT��ǿ���O��� (1110303014_SC1) */
      sprintf_s(stmt, sizeof stmt,"SELECT dply_begin,dply_end,qply_period,  "
                          "case  "
                          "  when iofficer[1] = 'A' then iofficer  "
                          "else ibig_office end as ibig_office, ibig_sales,  "
                          "a.icard, idmg_rate,pdmg_factor,qpt,fpt,psex_age,lia_class,  "
                          "plia_acc, dmg_acc_1st,dmg_acc_2nd,dmg_acc_3rd,pdmg_acc, iquota[1,4], "
                          "icomp_in, ibranch_in, icomp_at, ibranch_at, iarea, ibranch,  "
                          "ilast_ply, iassured, to_char(dissue,'%%Y')::integer - 1911 || '/' || to_char(dissue,'%%m'),iofficer,  "
                          "b.iply_area,b.aassured_zip,b.aassured,b.apayment_zip,b.apayment,b.ndeputy_assured,  "
                          "b.fapplicant,b.iapplicant,b.fsex_appl,b.dbirth_appl,b.napplicant,b.itel_appl,b.ndeputy_appl,b.nrelation_appl,  "
                          "case when b.iassured_cntry = ' ' and b.fassured in ('1','2') then '9' else b.iassured_cntry end,  "
                          "case when b.iapplicant_cntry = ' ' and b.fapplicant in ('1','2') then '9' else b.iapplicant_cntry end,  "
                          "b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup,  "
                          "case when b.iassured = b.iapplicant then 'Y' else 'N' end,  "
                          "decode(b.iassured_cntry,'1','Y','N'),decode(b.iapplicant_cntry,'1','Y','N'),nassured,dbirth,  "
                          "itel,mobil_phone,feply,aemail_eply,tmobile_eply,nequipment,ientry,ipro_year,qpro_month,  "
                          "feterms,ftrans_third  "
                    " FROM %s:ply_relation a, %s:policy b  "
                    "WHERE a.ipolicy = '%s' AND a.ipolicy = b.ipolicy ",
                     car_dbnameA, car_dbnameA, ipolicyA );

      printf("car330_cal_prem stmt1[%s]\n", stmt);
      $PREPARE get_dply_date FROM $stmt;
      $EXECUTE get_dply_date INTO $dply_begin_a, $dply_end_a, $qply_period, $ibig_office, $ibig_sales,
                                  $ixxcard, $idmg_rate, $pdmg_factor, $qpt, $fpt, $psex_age, $lia_class,
                                  $plia_acc2, $dmg_acc_1st, $dmg_acc_2nd, $dmg_acc_3rd, $pdmg_acc, $iquota14,
                                  $icomp_in, $ibranch_in, $icomp_at, $ibranch_at,$iarea,$ibranch,
                                  $last_ply_A1, $iassured,$iissue_ym_A,$iofficer_A,
                                  $iply_area,$aassured_zip,$aassured,$apayment_zip,$apayment,$ndeputy_assured,
                                  $fapplicant,$iapplicant,$fsex_appl,$dbirth_appl,$napplicant,$itel_appl,$ndeputy_appl,$nrelation_appl,
                                  $iassured_cntry, $iapplicant_cntry,
                                  $foccup, $noccup, $applicant_foccup, 
                                  $applicant_noccup,$fsame_one,
                                  $iassured_rba,$iapplicant_rba,$nassured,$dbirth,
                                  $itel,$mobile,$feply,$aemail_eply,$tmobile_eply,$nequipment_A,$ientry_A,$ipro_year,$qpro_month,
                                  $feterms,$ftrans_third;
      if( SQLCODE == SQLNOTFOUND )
      {
          sprintf_s(errmsg, sizeof errmsg,"�O�渹:[%s]�d�L���",ipolicyA );
          $INSERT INTO CAR330_TEMP VALUES
          ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
          cnt_car330_tmp++;

          continue;
      }
      else
      { /* RBA�ˮ֡G s�����������o�X�� add by 061476 107.05.22 (1061012002_SC5) */
          strcpy(ddate1,cm_edate_str(dbirth));
          strcpy(ddate2,cm_edate_str(dbirth_appl));
          
          rtncode = cm_check_simple_RBA(iassured, nassured, ddate1, iassured_rba, fresult, nresult);
          
          if (strcmp(fresult,"S") == 0) continue;
          
          if (strcmp(fsame_one,"N") == 0) /* �n�B�Q�O���P�H */
          {
              rtncode = cm_check_simple_RBA(iapplicant, napplicant, ddate2, iapplicant_rba, fresult, nresult);
              
              if (strcmp(fresult,"S") == 0) continue;
          }
		
      }
      
      printf("999������ ibranch = [%s]\n",ibranch);
      printf("@@@iins_list=[%s]\n", iins_list);
      printf("@@@str_iagent[%s]\n", str_iagent);
      printf("----- 931 ftype_pol=[%s]ftype_sp=[%s]-----\n",ftype_pol,ftype_sp);
      /* N*�g��N�������I�N��(ibig_office),������ca_promote_officer ���o add by sylvia 103.09.17 (1030630002_C1) */
      if (strncmp(iofficerB2,"N",1) == 0)
      {
         
         $select ibig_office, 'N'||iofficer[1,1],
                 nvl((select engname from car_code where kind = 'RN' 
                     and detail = 'N_SALES' and detail2 = a.ibig_office[1,2]),'--')
            into $ibig_office, $sRtype, $N_sales
            from ca_promote_officer a
           where iofficer_ori = $iofficerB2;
         strcpy(N_sales, trim(N_sales));
         if (strcmp(N_sales,"--") == 0)
         {
            /* �d�L�T�w�~�N,������ A��~�N */
         }
         else
         {
            strcpy(ibig_sales, N_sales);
         }
      }
      else
      {
         strcpy(sRtype,"CP"); /* �DN*�g����N�d������ */
      }

      if (execItem[0]=='1'){  /* �X�� �G���ɪ�A�欰�w��O��A��*/
         rstrdate( dply_begin_a, &ply2_begin );
         rstrdate( dply_end_a  , &ply2_end );

      }else if (execItem[0]=='0'){ /* 102.03 ���� �G���ɪ�A�欰�e�@�~A��*/

       	  /* B������檺�O������O�O�� */
	      rstrdate( dply_begin_a, &ldbgn );
	      rstrdate( dply_end_a  , &ldend );
	      ply2_begin = ldend;
	      ply2_end   = GetNextYearDate(ldend);

	      /* ��A�檺�O���[�@�~�æ^�� */
          rfmtdate(ply2_begin,"mm/dd/yyyy",dply_begin_a);
          rfmtdate(ply2_end  ,"mm/dd/yyyy",dply_end_a);
      }
      printf("trace dply_begin_a[%s]\n ",dply_begin_a);
      printf("trace dply_end_a[%s]\n ",dply_end_a);
      
      strcpy(iissue_ym_A, trim(iissue_ym_A));
      lng_iissue_ym_A = cm_build_date_ym(iissue_ym_A,1); /* ������~��((y)yy/mm)���뭺 */

      /*960724, �H(�O��_��-�o�Ӧ~��)�p��M�׬��ĴX�~��,�Y�ĤG�~��O, qyear_A==1 */
      qyear_A = (int)floor((ply2_begin - lng_iissue_ym_A)/365.0 ); /* �L����˥h */
      printf("qyear_A[%d] \n ", qyear_A);
      printf(" ------- ply2_begin = [%ld]\n " , ply2_begin);
      printf(" ------- lng_iissue_ym_A = [%ld]\n " , lng_iissue_ym_A);
      strcpy(A_dbegin, cm_from_infdate_100(dply_begin_a));

      /** Step 2.1 get data from ipolicy B  **/
      /** 990510, ���ظU�o�ֱM��(C17)�Ĥ@�~�LB��*/
      /** 970813, �s�߶R�@�e�|�M�ײĤ@�~�LB�� **/
      /** 960725, �U�o�ֱM��(C15)�Ĥ@�~�LB��,�Hiengine + iofficer + dply_begin + dply_end ��B��, �T�{B��O�_�w��O*/
      printf("step 2.1 get data from ipolicy B\n");

      /*************            check ��B��O�_�w��O             ************* */
      printf("----- 981 ftype_pol=[%s]ftype_sp=[%s]-----\n",ftype_pol,ftype_sp);
      /* �Y���Ĥ@�~�LB�椧�M�ץB���s�� */
      if ((ISPROJ_NO_FST_PLY_B(pro_no))&&(qyear_A==1)&&(flg_NoPolicyB =='Y'))
      {
         printf(" ------- ioff_chk = [%s]\n " , ioff_chk);
      	tmp_ply_B[0]='\0';

	      sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy  "
	                    " FROM %s:ply_relation a, %s:policy b  "
	                    "WHERE a.ipolicy = b.ipolicy AND b.iengine = '%s'  "
	                    "  AND (a.iofficer[1] = 'W' or (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2'))  "
	                    "       or a.iofficer in (select iofficer_ori from ca_promote_officer where iofficer_ori[1,1] = 'N')) "
	                    "  AND a.iofficer[%d,%d]='%s'  "
	                    "  AND a.dply_begin=%d AND a.dply_end=%d AND nvl(a.fedr_class,' ') <> '1'",
	                     car_dbnameB, car_dbnameB, iengine,
	                     ioff_ck_bgn, (ioff_ck_bgn+ioff_ck_len-1),ioff_chk,
	                     ply2_begin,ply2_end );
         printf("car_dbnameB[%s] car_dbnameA[%s]\n", car_dbnameB, car_dbnameA);
		   printf("iengine[%s] \n", iengine);
         printf(" ------- stmt = [%s]\n " , stmt);
	      $PREPARE get_plyb FROM $stmt;
	      $EXECUTE get_plyb INTO $tmp_ply_B;

	      if( SQLCODE != SQLNOTFOUND )
	      {
	          sprintf_s(errmsg, sizeof errmsg,"A��O�渹:[%s]��B��w��O:[%s]", ipolicyA,tmp_ply_B);
	          printf("errmsg[%s]\n", errmsg);
	          $INSERT INTO CAR330_TEMP VALUES
	          ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
	          cnt_car330_tmp++;
	          continue;
	      }
	      else
	      {
	         /* �Acheck �O�_�b��L�����q�w��O */
	      	fnext_plyb = 'N';
	         for( i=0; i< count_db; i++){
		         tmp_ply_B[0]='\0';

			      sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy  "
			                    " FROM %s:ply_relation a, %s:policy b  "
			                    "WHERE a.ipolicy = b.ipolicy AND b.iengine = '%s'  "
			                    "  AND (a.iofficer[1] = 'W' or (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2'))  "
			                    "        or a.iofficer in (select iofficer_ori from ca_promote_officer where iofficer_ori[1,1] = 'N'))  "
			                    "  AND a.iofficer[%d,%d]='%s'  "
			                    "  AND a.dply_begin=%d AND a.dply_end=%d AND nvl(a.fedr_class,' ') <> '1'",
			                     list[i].dbname, list[i].dbname, iengine,
			                     ioff_ck_bgn, (ioff_ck_bgn+ioff_ck_len-1),ioff_chk,
			                     ply2_begin,ply2_end );

		         printf(" ------- stmt = [%s]\n " , stmt);
			      $PREPARE get_plyb FROM $stmt;
			      $EXECUTE get_plyb INTO $tmp_ply_B;
		         printf(" ------- SQLCODE = [%d]\n " , SQLCODE);
		         printf(" ------- SQLNOTFOUND = [%d]\n " , SQLNOTFOUND);
			      if( SQLCODE != SQLNOTFOUND ){
			          fnext_plyb = 'Y';
			          break;
	            }
	         }
	         if (fnext_plyb=='Y'){
		          sprintf_s(errmsg, sizeof errmsg,"A��O�渹:[%s]��B��w��O:[%s]", ipolicyA,tmp_ply_B);
		          printf("errmsg[%s]\n", errmsg);
		          $INSERT INTO CAR330_TEMP VALUES
		          ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
		          cnt_car330_tmp++;
	          	  continue;
	         }
	      }
      }

      /* �e�@�~��B�� */
      strcpy(sIquotaB,"");
      strcpy(sIins_cat," ");
      sprintf_s(stmt, sizeof stmt,"SELECT itreaty, dissue, ibrand, icar_type, iresource,  "
                          "mcar_price, a.icard, a.iofficer, a.iquota[1,4], a.fdiscount, a.inext_ply, a.iquota,  "
                          "nvl((select ncode from cu_code_data where itype = '97' and  icode = a.icar_type),' ')  "
                    " FROM %s:ply_relation a, %s:policy b  "
                    "WHERE a.ipolicy = b.ipolicy AND a.ipolicy = '%s'",
                     car_dbnameB, car_dbnameB, ipolicyB );
      printf("stmt[%s]\n", stmt );
      $PREPARE get_plyb FROM $stmt;
      $EXECUTE get_plyb INTO $itreaty, $dissue, $ibrand, $icar_type, $iresource,
                             $car_price, $ilast_card, $iofficerB, $iquotaB14, $fdiscount, $inext_ply_B, $sIquotaB,
                             $sIins_cat;

      if( SQLCODE == SQLNOTFOUND )
      {
          sprintf_s(errmsg, sizeof errmsg,"B��O�渹:[%s]�d�L���",ipolicyB );
          $INSERT INTO CAR330_TEMP VALUES
          ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
          cnt_car330_tmp++;

          continue;
      }

      if( strlen(trim(inext_ply_B)) > 0 )
      {
		  if ((ISPROJ_NO_FST_PLY_B(pro_no))&&(qyear_A==1)&&(flg_NoPolicyB =='Y'))
		  {
		  	   /** 990510, ���ظU�o�ֱM��(C17)�Ĥ@�~�LB��*/
		  	   /** 970813, �s�߶R�@�e�|�M�ײĤ@�~�LB�� **/
		  	   /** 960227, �U�o�ֱM��(C15)�Ĥ@�~�LB��,�HA��(�O�渹)��ƥXB��
		  	      �� inext_ply_B ��ڬ�A�椧��O�渹�A�GB��|����O
		  	   **/
		  }
		  else
		  {
	          sprintf_s(errmsg, sizeof errmsg,"B��O�渹:[%s]�w��O:[%s]",ipolicyB, inext_ply_B );
	          printf("errmsg[%s]\n", errmsg);
	          $INSERT INTO CAR330_TEMP VALUES
	          ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
	          cnt_car330_tmp++;

	          continue;
        }
      }
    printf("----- 1098 ftype_pol=[%s]ftype_sp=[%s]-----\n",ftype_pol,ftype_sp);
      /* 101.07.05, Ū���O�v�ͮĥN�� **/
      /* chkFrate = 1 => �H�O��ͮĤ�d�O�v�ɡF  chkFrate = 0 => ��user �ۦ��Jfrate */
      if (chkFrate==1)
      {
	      /* ���N�I��O�O�v�N�� */
	      /*
	      $SELECT icode
	         INTO $frate
	         FROM ca_rate_renew
	        WHERE deffect_bgn <= $ply2_begin
	          AND deffect_end >= $ply2_begin
	          AND fcard_class = '2';
          */
          /* 103.02 �אּ�ϥ���O�J�p���ɪ��O�v�N�� */
         $SELECT max(drate_ym) INTO $frate
		      FROM ply_ins_type_302
		     WHERE ipolicy in ( SELECT ipolicy FROM policy_302
		                        WHERE iestimate_ori = $iestimateB);

         if (SQLCODE == SQLNOTFOUND)
		   {
	          /*sprintf_s(errmsg, sizeof errmsg,"�O�渹[%s]����O�ͮĤ�[%s]�L�k���o�O�v�N��",ipolicyB, dply_begin_a );*/
	          sprintf_s(errmsg, sizeof errmsg,"�����渹[%s]�L�k���o��O�J�p���ɤ��O�v�N��",iestimateB);
	          printf("errmsg[%s]\n", errmsg);
	          $INSERT INTO CAR330_TEMP VALUES
	          ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
	          cnt_car330_tmp++;
	          continue;
		   }
      }
      printf("Trace -- �O�v�N��[%s] \n", frate);

      /* 100.06,�q���ĤG���q
         officer A:�i�O�v�O irate_type�j�B�i�I����H icomm_obj�j�B�i�~�ȱ���N�� iroute_comm�j�B�i�q���ۭq�~�ȥN��  iroute_prop�j
      */
      /* 990319 ���s���oA��(�^�k)���g��N���B�޲z�H�N���B�~�Z���N���B�q���N�� */
      iofficer_prmt[0] = '\0';  ileader_prmt[0] = '\0'; iquota_prmt[0]   = '\0'; iroute[0]        = '\0';
      irate_type_A[0]  = '\0';  icomm_obj_A[0]  = '\0'; iroute_comm_A[0] = '\0'; iroute_prop_A[0] = '\0';

      $SELECT iofficer    , iquota      ,ileader       , iroute  ,
              irate_type  , icomm_obj   , iroute_comm  , iroute_prop
         INTO $iofficer_prmt, $iquota_prmt , $ileader_prmt  , $iroute ,
              $irate_type_A , $icomm_obj_A , $iroute_comm_A , $iroute_prop_A
         FROM officer
        WHERE iofficer = $iofficer_A;

      /** 970131,get �g��H��� ���e����o�� **/
      /** Step 4.0 get �g��H���**/ /*1020805:�s�WY45*/
      printf("----- 1147 ftype_pol=[%s]ftype_sp=[%s]-----\n",ftype_pol,ftype_sp);
      /*  103.02, �i��O�X�椧B��g��N���]iofficerB2�^�w����J���ɮ״��ѡA�����n�A�P�_�έ��s���o�g�� */
      if(0)
      {
	      get_officer = 0;
	      if(( strcmp( iquota14, iquotaB14 ) != 0 )||
			  ((ISPROJ_NO_FST_PLY_B(pro_no))&&(qyear_A==1)&&(flg_NoPolicyB =='Y')))
			{
	      	  /** 990510, ���ظU�o�ֱM��(C17)�Ĥ@�~�LB��*/
	      	  /** 960726, �U�o�ֱM��(C15)�Ĥ@�~�LB��,�HA��(�O�渹)��ƥXB��, ���g�춷���� **/
	      	  /** ����X��A�������s�g��N�� **/
	      	  get_officer = 1;
	      }
	      else
	      {
	          /** �L����X��A���P�_�O�_�i�����ϥ� **/
	          get_officer = 0;
	      }

	      if( get_officer == 0 )
	      {
	      	  strcpy(ioff_chk,trim(ioff_chk));
	      	  strcpy(ioff_chk_B,trim(ioff_chk_B));
	          strcpy(iofficerB, trim(iofficerB));
	          strncpy(ioff_chk_B, iofficerB + ioff_ck_bgn -1 , ioff_ck_len);
	          if( (strlen(iofficerB) == iofficer_len) && ( strcmp(ioff_chk_B, ioff_chk)==0) && (iofficerB[0]==iofficer_1[0]) )
	          {
	      	      printf("step 4.1 compare success \n");
	      	      /** ��令�\�A�έ�g��X�� **/
	      	      strcpy( iofficer, iofficerB);
	          }
	          else if( (fanother[0] == 'Y') && (strlen(iofficerB) == lofficera) &&
	                   ( strcmp(ioff_chk_B, ioff_chka)==0))
	          {
	              printf("step 4.2 compare success \n");
	              /** ��令�\�A�έ�g��X�� **/
	      	      strcpy( iofficer, iofficerB);
	          }
	          else
	          {
	              get_officer = 1;
	          }
	      }

	      /**
		   if ((strcmp( pro_no, "C15") == 0)&&(qyear_A==1)){
	           960227, �U�o�ֱM��(C15)�Ĥ@�~�LB��,�HA���ƥXB��
	           printf("--�U�o�ֱM��(C15)�Ĥ@�~�LB��\n");
	           get_officer = 0;
	           strcpy(iofficerB, trim(iofficerB));
	           strcpy( iofficer, iofficerB);
	      }  */
	      if( get_officer == 1 )
	      {
	      	   /* 990119,�e�@B��B��OA�椧�~�Z��줣�P�Ϋe�@�LB��
	      	      => ���s�H��OA�椧�g��N���ܸg��H�ɨ��o�̷s�~�Z���A
	      	         �A�H�̷s�~�Z���+�M�ץN�X��B�椧�g��N�� */

	      	   printf("Trace -- iquota14 old = [%s] \n",  iquota14);
	           $SELECT iquota[1,4] INTO $iquota14 FROM officer 
	             WHERE iofficer = $iofficer_A;
	           printf("Trace -- iquota14 new = [%s] \n",  iquota14);

	      	   printf("step 4.3 get officer \n");
	      	   /** ��異�ѡA�� officer ���� **/
	           sprintf_s(stmt, sizeof stmt, "SELECT iofficer FROM officer  "
	                          "WHERE iquota[1,4] = '%s' AND iofficer[1] = '%s'  "
	                            "AND iofficer[%d,%d] = '%s'  "
	                            "AND length(iofficer) = %d   "
	                            "AND sbus_source = '%s'",
	           iquota14, iofficer_1, ioff_ck_bgn, ioff_ck_end, trim(ioff_chk), iofficer_len, iprmt );

	           printf("stmt=[%s]\n", stmt);

	           $PREPARE cur_getoff FROM $stmt;
	           $DECLARE cur_getoff1 CURSOR for cur_getoff;
	           $OPEN cur_getoff1;
	           $FETCH cur_getoff1 INTO $iofficer;

	           printf("iofficer=[%s] SQLCODE =[%d]\n", iofficer, SQLCODE );

	           if(SQLCODE == SQLNOTFOUND)
	           {
	               strcpy(Biofficer_emp, iofficer_1);
	               strcat(Biofficer_emp,"*");
	               strcat(Biofficer_emp,trim(ioff_chk));
	               Biofficer_emp[ioff_ck_end] = '\0';

	               sprintf_s(errmsg, sizeof errmsg,"�O�渹:[%s]�L�����g��N���AA��~�Z��쬰[%s]�}�Y�AB��g��N����[%s]",
	                       trim(ipolicyA), iquota14, Biofficer_emp );

	               $INSERT INTO CAR330_TEMP VALUES
	               ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
	               cnt_car330_tmp++;

	               continue;
	           }
	           $CLOSE cur_getoff1;
	      }
      }

      strcpy(iofficer, iofficerB2);

      if (execItem[0]=='1'){ /* �X�� */
      	
      	printf("step 4.4 check B��O�_��������A��g�� => ca_promote_officer \n ");
      	kk = 0;

	TRY_AGAIN:
         cnt_chk = 0 ;
         $SELECT count(*) INTO $cnt_chk
            FROM ca_promote_officer
           WHERE iofficer_ori = $iofficer
             AND  ibig_office = $ibig_office;
         if (cnt_chk==0)
         {
         	if (kk == 0 )
         	{
         		kk =1 ;
         		$WHENEVER SQLERROR CONTINUE;
         		
         		/* 981230,���s���� update officer �ʧ@,�Ϩ�Ĳ�o trigger �g�J ca_promote_officer */
         		$UPDATE officer SET iofficer = $iofficer
         		  WHERE iofficer = $iofficer ;
         		
         		$WHENEVER SQLERROR GOTO errexit;
         		goto TRY_AGAIN;
         	}
         	sprintf_s(errmsg, sizeof errmsg,"�O�渹:[%s]�M�ץ��A��g��N���䤣��B��g��N����[%s],B����I�N����[%s]",
         	        trim(ipolicyB), iofficer, ibig_office );
         	
         	$INSERT INTO CAR330_TEMP VALUES
         	($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
         	
         	cnt_car330_tmp++;
         	continue;
         }
      }
      
      /* �s�W�ˮֶ���90�n�O�Ѧ��^���O add by 061476 (1091021005_SC3) */
      if (equip_cmp(nequipment_A,"90") != TRUE)
      {
      	sprintf_s(errmsg, sizeof errmsg,"������[%s]A��L�Ŀ�90���O",iengine);
      	
      	$INSERT INTO CAR330_TEMP VALUES
      	($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
      	
      	cnt_car330_tmp++;
      	continue;
      }

	  /* 103.02 �אּ�ϥΤw��OA�椧�n�O�H��� */
     /* 101.08.24 ,�M�ץ���O�X��n�O�H�@�ߧ� ca_dealer_appl(car152)
     $SELECT d.idealer,
	          d.fapplicant,d.iapplicant,d.fsex_appl,d.dbirth_appl,d.napplicant,
	          d.itel_appl,d.apayment_zip,d.apayment,d.ndeputy_appl,d.nrelation_appl
	     INTO $idealer,$fapplicant,$iapplicant,$fsex_appl,$dbirth_appl,$napplicant,
              $itel_appl,$apayment_zip,$apayment,$ndeputy_appl,$nrelation_appl
	     FROM ca_promote_officer b,ca_promote c, ca_dealer_appl d
	    WHERE b.iofficer_ori = $iofficer
	      AND b.ibig_office  = $ibig_office
	      AND b.iprmt        = c.iprmt
	      AND (CASE WHEN c.imodule ='2' THEN b.iofficer[1,3]
	           ELSE b.iofficer[1]
	           END ) = d.idealer ;

	  printf("idealer[%s]  iapplicant[%s]  napplicant[%s]\n ", idealer, iapplicant, napplicant );

     if (SQLCODE == SQLNOTFOUND){
           sprintf_s(errmsg, sizeof errmsg,"�O�渹:[%s]�M�ץ��n�O�H���(car152)�䤣��,B��g��N����[%s],B����I�N����[%s])",
                   trim(ipolicyB), iofficer, ibig_office );

           $INSERT INTO CAR330_TEMP VALUES
           ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr);
           cnt_car330_tmp++;
           continue;
     } */

      /* 100.06,�q���ĤG���q
         officer B:�i�O�v�O irate_type�j�B�i�I����H icomm_obj�j�B�i�~�ȱ���N�� iroute_comm�j�B�i�q���ۭq�~�ȥN��  iroute_prop�j
      */
      
      ibranch2[0]  = '\0'; ibig_comp2[0]  = '\0'; sIquota2[0]  = '\0'; sIleader2[0]  = '\0';
      irate_type_B[0]  = '\0';  icomm_obj_B[0]  = '\0'; iroute_comm_B[0] = '\0'; iroute_prop_B[0] = '\0';

      $SELECT ibranch, ibigcomp, iquota, ileader,
              irate_type  , icomm_obj   , iroute_comm  , iroute_prop ,iroute
         INTO $ibranch2, $ibig_comp2, $sIquota2, $sIleader2,
              $irate_type_B , $icomm_obj_B , $iroute_comm_B , $iroute_prop_B, $iroute_B
         FROM officer
        WHERE iofficer = $iofficer;
printf("1409������ ibranch=[%s] ibranch2 = [%s]\n",ibranch, ibranch2);
      printf("Trace1 -- sIquota2 = [%s] \n",  sIquota2);
	   /*--------------------- [�X���ˮ�]  ----------------------------------------------

	   �ˮ����O                                       �ݶǤJ�Ѽ�
	   ==========  ============================     =============
		�@		�g��N���O�_����                (���ˮ�)
		�G		�~�Z���O�_����				4.�~�Z���(B��)
		�|		�I����H�O�_����X��			5.�I����H�N��(B��)
		��		�I����H���L�X����			5.�I����H�N��(B��) ; 6.�I�O(=��C��)
		�C		�y�q���N���z�P�y�q���M�ε��O�z	7.�q���N��(A��)     ; 8.�q���ۭq�~�ȥN��(A��)
		        �������Y�O�_���T

      rc = cm_chk_policy(v_opt, v_iofficer, v_ileader, v_iquota, v_icomm_obj, v_insure_type,
                       v_iroute, v_iroute_prop);
	    ----------------------------------------------------------------------- **/

	   /* �G		�~�Z���O�_���� */
      rc = cm_chk_policy("2", " " , "", sIquota2, "", "", "", "");
      printf("Trace -- TEST �~�Z���O�_���� rc = [%d] \n",  rc);
      printf("Trace2 -- sIquota2 = [%s] \n",  sIquota2);
	   if (rc != M_CM_OK)
	   {
           sprintf_s(errmsg, sizeof errmsg,"���~�Z���[%s]�w���ΡG�O�渹��[%s] �g��N����[%s]",
                   sIquota2, ipolicyB, iofficer );
           $INSERT INTO CAR330_TEMP VALUES
           ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
           cnt_car330_tmp++;
           continue;
	   }

	   /* �|		�I����H�O�_����X�� */
      rc = cm_chk_policy("4", "" , "", "", icomm_obj_B, "", "", "");
      printf("Trace -- �I����H�O�_����X�� rc = [%d] \n",  rc);
	   if (rc != M_CM_OK)
	   {
           sprintf_s(errmsg, sizeof errmsg,"���I����H[%s]�w����X��G�O�渹��[%s] �g��N����[%s]",
                   icomm_obj_B, ipolicyB, iofficer );
           $INSERT INTO CAR330_TEMP VALUES
           ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
           cnt_car330_tmp++;
           continue;
	   }

	   /* ��		�I����H���L�X���� */
      rc = cm_chk_policy("6", "" , "", "", icomm_obj_B, "C", "", "");
      printf("Trace -- �I����H���L�X���� rc = [%d] \n",  rc);
	   if (rc != M_CM_OK)
	   {
           sprintf_s(errmsg, sizeof errmsg,"���I����H[%s]�L�X����G�O�渹��[%s] �g��N����[%s]",
                   icomm_obj_B, ipolicyB, iofficer );
           $INSERT INTO CAR330_TEMP VALUES
           ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
           cnt_car330_tmp++;
           continue;
	   }

	   /* �C		�y�q���N���z�P�y�q���M�ε��O�z�������Y�O�_���T */
      rc = cm_chk_policy("7", "" , "", "", "", "", iroute, iroute_prop_A);
      printf("Trace -- �y�q���N���z�P�y�q���M�ε��O�z�������Y�O�_���T rc = [%d] \n",  rc);
	   if (rc != M_CM_OK)
	   {
           sprintf_s(errmsg, sizeof errmsg,"A��q���N��[%s]�PA��q���M�ε��O[%s]�������Y�����T�G�O�渹��[%s] �g��N����[%s]",
                   iroute,iroute_prop_A, ipolicyB, iofficer );
           $INSERT INTO CAR330_TEMP VALUES
           ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
           cnt_car330_tmp++;
           continue;
	   }


      /* �֫O�H���ˮ�  add by sylvia 104.05.26 (1020226003_C4) ------------------------------ */
      strcpy(isign, " ");
      $select engname into $isign
         from car_code
        where kind = 'RN'
          and detail = 'USIGN'
          and detail2 = substr($sIquota2,1,4)
          and trim(engname) <> '';
      if(SQLCODE == SQLNOTFOUND)
      {
           sprintf_s(errmsg, sizeof errmsg,"�~�Z���[%s]�d�L�֫O�H�����, �L�k�X��!! �O�渹[%s] �g��N��[%s]",sIquota2,ipolicyB,iofficer);

           printf("1437:errmsg=[%s]\n",errmsg);

           $INSERT INTO CAR330_TEMP VALUES
           ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
           cnt_car330_tmp++;
           continue;
      }

      strcpy(isign_iupcomp," ");
      strcpy(ply_iupcomp," ");
      $select iupcomp into $isign_iupcomp
         from sa_branch_type
        where ibranch  = (select iquota  from officer where iofficer = $isign); /* �֫O�H�������Ұ� */


      $select iupcomp into $ply_iupcomp
         from sa_branch_type
        where ibranch    = $sIquota2;   /* �O������Ұ� */

      if (strcmp(isign_iupcomp,ply_iupcomp) != 0)
      {
         sprintf_s(errmsg, sizeof errmsg,"�~�Z���[%s]�P�֫O�H��[%s]���P�Ұ�, �L�k�X��!! �O�渹[%s] �g��N��[%s]",sIquota2,isign,ipolicyB,iofficer);

           printf("1456:errmsg=[%s]\n",errmsg);

           $INSERT INTO CAR330_TEMP VALUES
           ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
           cnt_car330_tmp++;
           continue;
      }

      icnt = 0;
      $select count(*) into $icnt
         from officer
        where iofficer = $iofficer
          and ileader = $isign;

      if(icnt > 0)
      {
           sprintf_s(errmsg, sizeof errmsg,"�֫O�H��[%s]���i���g��N��[%s]���޲z�H�I�I",isign,iofficer);
           printf("1454:errmsg=[%s]\n",errmsg);
           $INSERT INTO CAR330_TEMP VALUES
           ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
           cnt_car330_tmp++;
           continue;
      }

      icnt = 0;
      $select count(*) into $icnt
         from cm_signatory
        where isign = $isign
          and fsign = 'U'
          and iins_cat = 'C'
          and deffect <= today
          and (dexpire is null or dexpire > today);
      if(icnt == 0)
      {
           sprintf_s(errmsg, sizeof errmsg,"�֫O�H��[%s]�D���Į֫O�H���A�L�k�X��I�I",isign);
           printf("1472:errmsg=[%s]\n",errmsg);
           $INSERT INTO CAR330_TEMP VALUES
           ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
           cnt_car330_tmp++;
           continue;
      }

      /* ------------------------------------------------------------------------------------ */

      pextra_charge = 0.00;
      pbusiness     = 0.00;

	  /*---------------- �P�_�X��~�ȱ���ϥΡu�¨�v�Ρu�s��v---------------- */
      printf("step 4.x iofficerB[%s] iofficer[%s]\n", iofficerB, iofficer );

      rc = cm_get_route_auth("C", iroute, iofficer_A, sFstart, sFauth);
      if (rc != M_CM_OK)
      {
           sprintf_s(errmsg, sizeof errmsg,"���~�G�P�_�O�_�ҥγq���~�ȱ���GA��q���N����[%s] A��g��N����[%s] ���~�X��[%d]",
                   iroute,iofficer_A, rc );
           $INSERT INTO CAR330_TEMP VALUES
           ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
           cnt_car330_tmp++;
           continue;
      }

      /*************************************************************************************/
      /** Step1.1.1 �s�X��B�檺pdmg_acc�Aplia_acc�H�P��������A����O�欰�ǡA�]B��q�`�^�kA�� **/
      /*if( strncmp( iins_list, "11", 2) != 0)  �D�ѵs�I */
      if ((strSearchReplace(iins_list,"11","11")==0) && (strSearchReplace(iins_list,"211","211")==0)) /* �D�ѵs�I */
      {
          sprintf_s(stmt, sizeof stmt, "SELECT COUNT(*)"
                         "  FROM policy_302"
                         " WHERE iengine = '%s'"
                         "   AND iofficer[1] IN %s"
                         "   AND fcard_class = '2'"
                         "   AND ilicense = '%s'" , iengine, str_iagent, iassured);

          printf("!!!str_iagent[%s]\n", str_iagent);

          printf("car330_cal_prem stmt21[%s]\n", stmt);

          $PREPARE get_acc1 FROM $stmt;
          $EXECUTE get_acc1 INTO $iCount;

          if( iCount == 1)
          {
              sprintf_s(stmt, sizeof stmt, "SELECT pdmg_acc, plia_acc"
                             "  FROM policy_302"
                             " WHERE iengine = '%s'"
                             "   AND iofficer[1] IN %s"
                             "   AND fcard_class = '2'"
                             "   AND ilicense = '%s'" , iengine, str_iagent, iassured);

              printf("car330_cal_prem stmt22[%s]\n", stmt);

              $PREPARE get_acc2 FROM $stmt;
              $EXECUTE get_acc2 INTO $pdmg_acc, $plia_acc2;
              printf("###str_iagent[%s]\n", str_iagent);
          }
          else if( iCount == 0)
          {
              $SELECT pdmg_acc, plia_acc
                 INTO $pdmg_acc, $plia_acc2
                 FROM policy_302
                WHERE ipolicy = $ipolicyB;

              if( SQLCODE == SQLNOTFOUND )
              {
                  sprintf_s(errmsg, sizeof errmsg,"�H������[%s],�Q�O�HID[%s]����O�ɬdA��ߴګY�Ƨ䤣��,�A��B��[%s]�]�䤣��",
                                  iengine, iassured, ipolicyB );
                  $INSERT INTO CAR330_TEMP VALUES
                  ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
                  cnt_car330_tmp++;

                  continue;
              }
          }
          else if( iCount > 1)
          {
              sprintf_s(errmsg, sizeof errmsg,"�H������[%s],�Q�O�HID[%s]����O�ɬdA��ߴګY�Ƨ��[%d]�����",
                              iengine, iassured, iCount );
              $INSERT INTO CAR330_TEMP VALUES
             ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
              cnt_car330_tmp++;

              continue;
          }

      }
      /* 980520,���N�F�Ƭ����O�s */
	   plia_acc2_ori = plia_acc2;
	   pdmg_acc_ori  = pdmg_acc;

      /*************************************************************************************/

      printf("====>start ply_ins_type\n");
      sprintf_s(stmt, sizeof stmt,"SELECT mdeduct, minjured_cover, mdeath_cover, mdamage_cover,provision,safe_rate,manage_rate FROM %s:ply_ins_type  "
                    "WHERE ipolicy = '%s' and iins_type = ? ",
                    car_dbnameB, ipolicyB );

      $PREPARE get_insb FROM $stmt;

      printf("==>policy\n");
      sprintf_s(stmt, sizeof stmt,"SELECT fassured,iassured,iassured_ext,nassured,ilicense,dbirth,fsex,fmarriage,nuser, "
                   "ibenef,nbenef,iemail,  "
                   "nbrand_abbr,ncar_abbr,fcar_note,qcylinder,ibody,nvl(itag,' '),nequipment,fcal_way, fassured  "
                   "FROM %s:policy WHERE ipolicy = '%s'", car_dbnameB, ipolicyB  );

      $PREPARE get_polb FROM $stmt;
      $EXECUTE get_polb INTO $fassured, $iassured, $iassured_ext, $nassured, $ilicense, $dbirth, $fsex,
                    $fmarriage, $nuser, $ibenef, $nbenef, $iemail,
                    $nbrand_abbr, $ncar_abbr, $fcar_note, $qcylinder,
                    $ibody, $tmp_itag, $nequipment, $fcal_way, $assuredf;
      strcpy( sDbirth,     cm_cdate_str_100(dbirth));
      strcpy(A_dbegin,trim(A_dbegin));
      printf(" ------- sDbirth = [%s]\n " , sDbirth);

      /*100.01.10, 0991004008_C1, �N�l���K��(10�αM�׾��Ҥv�H�o(75) �G���O����*/

      strcpy(nequipment_s,equip_delete(nequipment,"10"));
      printf("Trace -- nequipment_s = [%s] \n",  nequipment_s);
      strcpy(nequipment,equip_delete(nequipment_s,"75"));
      printf("Trace -- nequipment = [%s] \n",  nequipment);

      rc = get_age( sDbirth, A_dbegin, &v_iAge, v_sMsg); /* sDbirth, A_dbegin is CY/MM/DD */
      if( rc != M_CM_OK)
      {
          $ROLLBACK WORK;
          return rc;
      }

      /* 980304,�O�v�ۥѤ� */
      psex_age1       = 0.0;
      psex_age2       = 0.0;
      psex_age_damage = 0.0;

      if ((assuredf[0]=='1' || assuredf[0]=='3' || assuredf[0]=='5'))
      {
	      /*rc = get_sex_age_factor( &v_iAge, fsex, frate, &psex_age1, &psex_age2, v_sMsg);*/
         /* �j�� psex_age1 , car330�S���j���I*/

	      /* ���d */
	      rc = get_sex_age_factor( "2", &v_iAge, fsex, frate, &psex_age2, v_sMsg);
	      if( rc != M_CM_OK)
	      {
	          $ROLLBACK WORK;
	          return rc;
	      }
	      /* ���� 990601,by �����I�� */
	      /*
	      rc = get_sex_age_factor( "3", &v_iAge, fsex, frate, &psex_age_damage, v_sMsg);
	      if( rc != M_CM_OK)
	      {
	          $ROLLBACK WORK;
	          return rc;
	      }*/
      }
      /* Step 2.2 SELECT �t�P������ */
      printf("step 2.2 select ca_car_model\n");
      printf("trace ibrand[%s]\n ",ibrand);
      printf("trace ipro_year[%s]\n ",ipro_year);
      printf("trace frate[%s]\n ",frate);

      /* �אּ����<ipro_year ���̤j�~��, �A�䤣��~�� >ipro_year ���̤p�~��
         ��: ��J���s�y�~����2014, �Y�d�L2014�~�������, �h���� <2014����1�� (2013), �A�d����h�� >2014����@��(2015)
         modify by sylvia 104.09.15  (1040714001_C3)
      */
      $SELECT mcar_price  ,icar_type    ,fuse_type  ,qpassenger  ,icar_series
         INTO $mcar_price_1 ,$icar_type_1 ,$fuse_type ,$qpassenger ,$icar_series
         FROM ca_car_model
        WHERE ibrand    = $ibrand
          AND ipro_year = $ipro_year
          AND drate     = (SELECT drate
                             FROM ca_rate_date
                            WHERE icode  = $frate
                              AND itable = 'ca_car_model');
      if (SQLCODE==SQLNOTFOUND)
      {
          $DECLARE CA_OPT1_3A CURSOR FOR
            SELECT mcar_price  ,icar_type    ,fuse_type  ,qpassenger  ,icar_series  ,ipro_year
              INTO $mcar_price_1 ,$icar_type_1 ,$fuse_type ,$qpassenger ,$icar_series
              FROM ca_car_model
             WHERE ibrand    = $ibrand
               AND ipro_year < $ipro_year
               AND drate     = (SELECT drate
                                  FROM ca_rate_date
                                 WHERE icode  = $frate
                                   AND itable = 'ca_car_model')
            ORDER BY ipro_year desc;
          $OPEN  CA_OPT1_3A;
          $FETCH CA_OPT1_3A;
          if (SQLCODE==SQLNOTFOUND)
          {
              $DECLARE CA_OPT3B_305 CURSOR FOR
                SELECT mcar_price  ,icar_type,   fuse_type  ,qpassenger  ,icar_series  ,ipro_year
                  INTO $mcar_price_1 ,$icar_type_1,$fuse_type ,$qpassenger ,$icar_series
                  FROM ca_car_model
                 WHERE ibrand    = $ibrand
                   AND ipro_year > $ipro_year
                   AND drate     = (SELECT drate
                                      FROM ca_rate_date
                                     WHERE icode  = $frate
                                       AND itable = 'ca_car_model')
                ORDER BY ipro_year;
              $OPEN  CA_OPT3B_305;
              $FETCH CA_OPT3B_305;
              if (SQLCODE==SQLNOTFOUND)
              {
                  $ROLLBACK WORK;
                  $CLOSE CA_OPT3B_305;
                  $FREE  CA_OPT3B_305;
                  return M_CA_NBRAND;
              }
              $CLOSE CA_OPT3B_305;
          }
          $CLOSE CA_OPT1_3A;
          $FREE  CA_OPT1_3A;
      }

      if( (strcmp(trim(itag), trim(tmp_itag)) != 0) && (trim(tmp_itag) > 0) )
          strcpy( itag, tmp_itag );

      /* Step 2.3 check �ۥ���~���O */
      /* $SELECT fcar_class  INTO $fcar_class2
         FROM car_type
        WHERE fclass='1'
          AND icode=$icar_type_1;  */
      /* �����O�J�p�����إN��   modify by sylvia 104.02.17 */
      $SELECT fcar_class  INTO $fcar_class2
         FROM car_type
        WHERE fclass='1'
          AND icode=$icar_type;

      /*** STEP 2.3 ���w�����j���ؤ��@
       ���ѵs�O�v�N������ѵs�I�O�v�N���Y��   ***/
      printf("step 2.3 select ibrg_rate \n");

      /* �אּ����<ipro_year ���̤j�~��, �A�䤣��~�� >ipro_year ���̤p�~��
         ��: ��J���s�y�~����2014, �Y�d�L2014�~�������, �h���� <2014����1�� (2013), �A�d����h�� >2014����@��(2015)
         modify by sylvia 104.09.15  (1040714001_C3)
      */
      $SELECT ibrg_rate  , ipro_year, idmg_rate
         INTO $ibrg_rate , $cal_pro_year, $idmg_rate
         FROM ca_car_model
        WHERE ibrand    = $ibrand
          AND ipro_year = $ipro_year
          AND drate     = (SELECT drate
                             FROM ca_rate_date
                            WHERE icode  = $frate
                              AND itable = 'ca_car_model');
      if(SQLCODE==SQLNOTFOUND)
      {
          $DECLARE CA_OPT11 CURSOR FOR
            SELECT ibrg_rate  , ipro_year, idmg_rate
              INTO $ibrg_rate , $cal_pro_year, $idmg_rate
              FROM ca_car_model
             WHERE ibrand    = $ibrand
               AND ipro_year < $ipro_year
               AND drate     = (SELECT drate
                                  FROM ca_rate_date
                                 WHERE icode  = $frate
                                   AND itable = 'ca_car_model')
           ORDER BY ipro_year desc;
          $OPEN  CA_OPT11;
          $FETCH CA_OPT11;
          if (SQLCODE==SQLNOTFOUND)
          {
              $DECLARE CA_OPT11_1 CURSOR FOR
                SELECT ibrg_rate  , ipro_year, idmg_rate
                  INTO $ibrg_rate , $cal_pro_year, $idmg_rate
                  FROM ca_car_model
                 WHERE ibrand    = $ibrand
                   AND ipro_year > $ipro_year
                   AND drate     = (SELECT drate
                                      FROM ca_rate_date
                                     WHERE icode  = $frate
                                       AND itable = 'ca_car_model')
               ORDER BY ipro_year ;
              $OPEN  CA_OPT11_1;
              $FETCH CA_OPT11_1;
              if (SQLCODE==SQLNOTFOUND)
              {
                 $ROLLBACK WORK;
                 $CLOSE CA_OPT11_1;
                 $FREE  CA_OPT11_1;
                 return M_CA_NBRAND;
              }
              $CLOSE CA_OPT11_1;
          }
          $CLOSE CA_OPT11;
          $FREE  CA_OPT11;
      }

      printf("step 2.4 select car_model_factor \n");

      $SELECT pfactor
         INTO $dmg_factor
         FROM car_model_factor
        WHERE fdmg_brg  = '1'
          AND ipro_year = $ipro_year
          AND irate     = $idmg_rate
          AND drate     = (SELECT drate
                             FROM ca_rate_date
                            WHERE icode  = $frate
                              AND itable = 'car_model_factor');
      if (NOT_FOUND)
      {
           $DECLARE curs1 CURSOR FOR
             SELECT pfactor, ipro_year
               INTO $dmg_factor
               FROM car_model_factor
              WHERE fdmg_brg  = '1'
                AND irate     = $idmg_rate
                AND ipro_year > $ipro_year
                AND drate     = (SELECT drate
                                  FROM ca_rate_date
                                 WHERE icode  = $frate
                                   AND itable = 'car_model_factor')
             ORDER BY ipro_year;
           $OPEN  curs1;
           $FETCH curs1;

          if (NOT_FOUND)
          {
               $ROLLBACK WORK;
               return M_CA_NCAR_MODEL_FACTOR;
          }
      }

      $SELECT pfactor
         INTO $brg_factor
         FROM car_model_factor
        WHERE fdmg_brg  = '2'
          AND ipro_year = $ipro_year
          AND irate     = $ibrg_rate
          AND drate     = (SELECT drate
                             FROM ca_rate_date
                            WHERE icode  = $frate
                              AND itable = 'car_model_factor');
      if (NOT_FOUND)
      {
           $DECLARE curs2 CURSOR FOR
             SELECT pfactor, ipro_year
              INTO $brg_factor
              FROM car_model_factor
             WHERE fdmg_brg  = '2'
               AND irate     = $ibrg_rate
               AND ipro_year > $ipro_year
               AND drate     = (SELECT drate
                                  FROM ca_rate_date
                                 WHERE icode  = $frate
                                   AND itable = 'car_model_factor')
             ORDER BY ipro_year;

            $OPEN  curs2;
            $FETCH curs2;

          if (NOT_FOUND)
          {
               $ROLLBACK WORK;
               return M_CA_NCAR_MODEL_FACTOR;
          }
      }
      
      /* ���²v�վ�(P/Q����) add by 061476 108.02.13 (1071226006_SC9) */
      /* ���[�����X�R�A�վ��^���W�h modify by 061476 (1081225006_SC4) */
      strcpy(fProvision_P, "N");strcpy(fProvision_Q, "N");
      strcpy(ichk_A, " ");strcpy(ichk_last, " ");
      if ((atoi(frate)>=104) && (fcar_class2[0]=='1'))
      {      	
      	sprintf_s(stmt, sizeof stmt," SELECT \n"
      	             "        CASE WHEN nvl((SELECT max(drate_ym+0) FROM %s:ply_ins_type \n"
      	             "                        WHERE ipolicy = a.ipolicy  AND mdamage_cover > 0 \n"
      	             "                          AND iins_type IN  ('01','05','09','11','75','76','98','211')),0) >= 104 \n"
      	             "             THEN (SELECT UNIQUE CASE WHEN trim(provision)||';' matches '*P;*' THEN 'P' \n"
      	             "                                      WHEN trim(provision)||';' matches '*Q;*' THEN 'Q' \n"
      	             "                                 ELSE 'X' END \n"
      	             "                     FROM %s:ply_ins_type \n"
      	             "                    WHERE ipolicy = a.ipolicy  AND mdamage_cover > 0 \n"
      	             "                      AND iins_type IN ('01','05','09','11','75','76','98','211')) \n"
      	             "        ELSE \n"
      	             "              CASE WHEN nvl((SELECT max(drate_ym+0) FROM %s:ply_ins_type \n"
      	             "                              WHERE ipolicy = a.ipolicy  AND mdamage_cover > 0 \n"
      	             "                                AND iins_type IN  ('01','05','09','11','75','76','98','211')),0) = 0 \n"
      	             "              THEN 'Z' ELSE 'P2' END\n"
      	             "        END AS chk_pq \n"
      	             "   FROM %s:ply_relation a WHERE a.ipolicy = '%s'; \n", car_dbnameA, car_dbnameA, car_dbnameA, car_dbnameA, ipolicyA);
      	
      	printf("car330_check_PQ stmt[%s]\n", stmt);
      	$PREPARE check_A FROM $stmt;
      	$EXECUTE check_A INTO $ichk_A;
      	
      	strcpy(ichk_A,trim(ichk_A));
      	printf("ichk_A[%s]\n",ichk_A);
      	if (strncmp(ichk_A,"Z",1) == 0) 
      	{
      		sprintf_s(stmt, sizeof stmt," SELECT CASE WHEN trim(provision)||';' matches '*P;*' THEN 'P' \n"
      		             "             WHEN trim(provision)||';' matches '*Q;*' THEN 'Q' \n"
      		             "        ELSE 'X' end \n"
      		             "   FROM policy_302 a, ply_ins_type_302 b \n"
      		             "  WHERE a.ipolicy = b.ipolicy \n"
      		             "    AND (iestimate_ori = '%s' or iestimate_sug = '%s') \n ", iestimateB, iestimateB);
      		$PREPARE check_last FROM $stmt;
      		$EXECUTE check_last INTO $ichk_last;
      		
      		if (strncmp(ichk_last,"P",1) == 0)
      		{
      			strcpy(fProvision_P, "Y");
      		} 
      		else if (strncmp(ichk_last,"Q",1) == 0)
      		{
      			strcpy(fProvision_Q, "Y");
      		}
      		else
      		{
      			/* ichk_last=X ���ܵL���[P/Q����(25%����) */
      		}
      		    
      	}
      	else if(strncmp(ichk_A,"P",1)== 0)
      	{
      		strcpy(fProvision_P, "Y");
      	}
      	else if(strncmp(ichk_A,"Q",1)== 0)
      	{
      		strcpy(fProvision_Q, "Y");
      	}
      	else 
      	{
      		/* ichk_A=X ���ܵL���[P/Q����(25%����) */
      	}
      	printf("--P[%s]Q[%s]\n", fProvision_P, fProvision_Q);    
      }
      
      /*** Step 3 �p��O�O ***/

      /** Step 3.2 SetCarAge **/
      code = SetCarAge(frate);

      if (*fcal_way=='M')
      {

          $SELECT prate INTO $short_prate
             FROM short_period_rate
             WHERE qperiod=$qply_period;
          if (SQLCODE == SQLNOTFOUND)
          {
              $ROLLBACK WORK;
              return M_CA_NSHORT_RATE;
          }

          short_prate=short_prate/100.0;
      }
      else
      {
          short_prate=(double)(ply2_end-ply2_begin)/lGetOneYearDays(ply2_end);
      }

      printf("Trace -- sFstart = [%s] \n",  sFstart);
      printf("Trace -- sFauth = [%s] \n",  sFauth);

      strcpy (ibroker, " ");
      if (strncmp(sFstart, "Y", 1 ) != 0){      /* �|���ҥ�   */

	      $SELECT icar_broker
	         INTO $ibroker
	         FROM officer_broker
	        WHERE iofficer=$iofficer;


	      /*************************************************************************************/
	      /* 970131, �s�W�g���N���B�~�Z���O�_�����ˮ� */
	      printf("step 4.x iofficerB[%s] iofficer[%s]\n", iofficerB, iofficer );

	      printf(" ------- ibroker = [%s]\n " , ibroker);

	      rc = chk_ibroker_expire( ibroker, v_sMsg);
	      if( rc != M_CM_OK){
	               sprintf_s(errmsg, sizeof errmsg,"���g���N��[%s]�w���ΡG�O�渹��[%s] �g��N����[%s]",
	                       ibroker, ipolicyB, iofficer );
	               $INSERT INTO CAR330_TEMP VALUES
	               ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
	               cnt_car330_tmp++;
	               continue;
	      }

	      /* 97.11�J�O�v�ۥѤ�                                         */
	      /*        �g��N�� => �g���N�� => �g���s�եN�� => ���[�O�βv */
	      /*-----------------------------------------------------------*/


	      printf("iofficer[%s],ibroker=[%s]\n", iofficer,ibroker );

	      /* 980413,�¶O�v iextra_charge����٬O�n�� */
	  	  /* ���[�O�βv�N��(iextra_charge) */
	  	  /*
	      rc = get_broker_agent( ibroker, iextra_charge, v_sMsg);
	      if( rc != M_CM_OK){
	          sprintf_s(errmsg, sizeof errmsg,"���g���N��[%s]�L���������[�O�βv�N���G�O�渹��[%s] �g��N����[%s]",
	                   ibroker, ipolicyB, iofficer );
	          $INSERT INTO CAR330_TEMP VALUES
	          ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr);
	          cnt_car330_tmp++;
	          continue;
		  } */
      }

      /* 100.06 �q���ĤG���q */
      /* ���MB��O���Ƥw��bzfrom(��C15..���M�ײĤ@�~�S��B��),�G���s���o�O�o�q���N�� */
      rc = cm_get_bzfrom(iofficer,"","",bzfrom_B);
      if (rc != M_CM_OK)
      {
           sprintf_s(errmsg, sizeof errmsg,"���~�G���o�O�o�q���N���GB��g��N����[%s] ���~�X��[%d]",iofficer, rc );
           $INSERT INTO CAR330_TEMP VALUES
           ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
           cnt_car330_tmp++;
           continue;
      }
      printf("Trace -- TEST bzfrom_B = [%s] \n",  bzfrom_B);

      /*�ثe�u���[�O�βv�N��(iextra_charge)�v �Y�� �u�O�o�q���N�� (bzfrom)�v*/
      strcpy(iextra_charge, bzfrom_B);

      /* get ���[�O�βv */
      /* �t�Xget_cm_extra_charge_car()�s�W�G�ӰѼ�:�I�O(tmp_ins)�B�O��(qply_period)
            modify by sylvia 103.05.21 (1030407005_C4) */
      /* get_cm_extra_charge_car()�s�W�@�ӰѼ�:�q���N��(iroute) modify by 061476 (1090916003_SC5) */
      tmp_ins = 11; /* �Ȯɥ��T�w��11�I�� */
	  strcpy(ibrand, trim(ibrand));
	  if(strncmp(ibrand+6, "01", 2) == 0) /* �p�G���q�ʨ�(�t�N��2�X��01) �]��211�I��*/
	  {
		  printf("�q�ʨ��A�ȮɩT�w��211�I��\n");
		  tmp_ins = 211; 
	  }
      rc = get_cm_extra_charge_car( iextra_charge, frate, &pextra_charge, &pbusiness, qply_period, tmp_ins, iroute, v_sMsg);
      if( rc != M_CM_OK){
          sprintf_s(errmsg, sizeof errmsg,"�����[�O�βv�N��[%s]�L���������[�O�βv�G�O�渹��[%s]",
                   iextra_charge, ipolicyB);
          $INSERT INTO CAR330_TEMP VALUES
          ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
          cnt_car330_tmp++;
          continue;
	   }

      printf("pextra_charge[%f], pbusiness=[%f]\n", pextra_charge, pbusiness );
      strcpy( fdiscount ,"N");

      strcpy( sIinsType, "");
      printf("===iins_list=[%s]\n", iins_list);

      j=0;
      t_zero=0;
      d_zero=0.0;
      strcpy(c_zero, "0");
      strcpy(no_char,"2");
      strcpy(c_ipaid_base,"A");
      flg_chk = 0;

      /** Step 3.3 �s�@�I��list **/
      /* 100.06,�q���ĤG���q*/
      if (strncmp(sFstart, "Y", 1 ) == 0){      /* �w�ҥ� */

	      flg_chk = 0;
	      for( i=0 ; i < strlen(iins_list); i++ )
	      {
	      	  tmp_iins_list = iins_list[i];
	      	  printf("tmp_iins_list=[%c] j=[%d]\n", tmp_iins_list,j );
	      	  if( tmp_iins_list == ',' )
	      	  {
	      	      sIinsType[j] = '\0';

	              /*** check �~�ȱ��󤺮e �O�_OK ***/
		          /* �ǤJ�Ѽ�:
		           1.	�q���N��    2.	�O�v�O           3.	�~�ȱ���N��     4.	�X�@�j�I�O
		           5.	�����I�O    6.	�I��(���I��)     7.	�~��
		          */
		          memset(&o_stcomm, 0x00, sizeof(o_stcomm));
		          o_qrec = 0;

		          /* �T���I�������������� modify by sylvia 103.11.14 (1031103007_C2) */
		          /* rc = cm_get_insure_comm(iroute, irate_type_B, iroute_comm_B, "C", "C",
		                 sIinsType, "0", &o_qrec, &o_stcomm, " ");      	  */
		          rc = cm_get_insure_comm(iroute, irate_type_B, iroute_comm_B, "C", sIins_cat,
		                 sIinsType, "0", &o_qrec, &o_stcomm, " ");

		          if( rc != M_CM_OK||o_qrec==0){
		          	   flg_chk = 1;
		          	   break;
		          }

                  pagent		= o_stcomm.pagent   * 100;
                  pcommission	= o_stcomm.pcommiss * 100;

	      	      $EXECUTE get_insb INTO $lMdeduct, $lminjured_cover, $lmdeath_cover, $lmdamage_cover,$chr_provision,$dbl_safe_rate,$dbl_manage_rate
	      	         USING $sIinsType;

	      	      printf("sIinsType=[%s] lMdeduct=[%d] frate=[%s]\n", sIinsType, lMdeduct, frate );
	      	      printf("1:lminjured_cover[%d] lmdeath_cover[%d] lmdamage_cover[%d]\n",
	                      lminjured_cover, lmdeath_cover, lmdamage_cover );

	              /* 980520, �j�v�~�Ȫ��[���� */
	              /*dbl_educated_rate = peducated_rate; */ /* 981222, ���צ��L�j�v�ثe���T�w�� 1    */
	              if (IsProvision){
	                  strcpy(chr_provision,sProvisionType); /* 980520, �̨ϥΪ̿�J�����D*/
	                  dbl_safe_rate     = psafe_rate;       /* 980520, �� user ��J     */
	                  dbl_manage_rate   = pmanage_rate;     /* 980520, �� user ��J     */
	                  /*dbl_educated_rate = peducated_rate;    980520, �ثe�T�w�� 1     */
	              }else{
		              strcpy(chr_provision," ");
		              dbl_safe_rate     = d_zero;
		              dbl_manage_rate   = d_zero;
		              /*dbl_educated_rate = d_zero;*/
	              }

	              if (! Insert_INS_TYPE( sIinsType,
	      	                             lminjured_cover, lmdeath_cover, lmdamage_cover,
	      	                             lMdeduct,
	      	                             t_zero, t_zero,
	      	                             pagent, pcommission,  pdiscount,
	      	                             frate,
	      	                             t_zero,
	                                     d_zero, d_zero,  pdiscount,
	                                     c_zero, c_zero, c_zero,
	                                     c_ipaid_base, d_zero,
	                                     t_zero, t_zero, chr_provision, no_char, t_zero,dbl_safe_rate,dbl_manage_rate,peducated_rate,deviation_rate,pextra_charge, pbusiness))
	              {
	                  printf("malloc fail in struct INS_TYPE allocation!\n");
	                  $ROLLBACK WORK;
	                  return M_CM_NOT_MALLOC;   /* malloc fail */
	              }

	              strcpy( sIinsType, "");
	              j=0;
	      	  }
	      	  else if(i == (strlen(iins_list) -1) )
	      	  {
	      	      sIinsType[j] = tmp_iins_list;
	      	      sIinsType[j+1] = '\0';

	              /*** check �~�ȱ��󤺮e �O�_OK ***/
		          /* �ǤJ�Ѽ�:
		           1.	�q���N��    2.	�O�v�O           3.	�~�ȱ���N��     4.	�X�@�j�I�O
		           5.	�����I�O    6.	�I��(���I��)     7.	�~��
		          */
		          memset(&o_stcomm, 0x00, sizeof(o_stcomm));
		          o_qrec = 0;

		          /* �T���I�������������� modify by sylvia 103.11.14 (1031103007_C2) */
		          /* rc = cm_get_insure_comm(iroute, irate_type_B, iroute_comm_B, "C", "C",
		                 sIinsType, "0", &o_qrec, &o_stcomm, " ");      	  */

		          rc = cm_get_insure_comm(iroute, irate_type_B, iroute_comm_B, "C", sIins_cat,
		                 sIinsType, "0", &o_qrec, &o_stcomm, " ");

		          if( rc != M_CM_OK||o_qrec==0){
		          	   flg_chk = 1;
		          	   break;
		          }
                  pagent		= o_stcomm.pagent   * 100;
                  pcommission	= o_stcomm.pcommiss * 100;

	      	      $EXECUTE get_insb INTO $lMdeduct, $lminjured_cover, $lmdeath_cover, $lmdamage_cover,$chr_provision,$dbl_safe_rate,$dbl_manage_rate
	      	         USING $sIinsType;

	      	      printf("sIinsType=[%s] lMdeduct=[%d] frate=[%s]\n", sIinsType, lMdeduct, frate );
	      	      printf("2:lminjured_cover[%d] lmdeath_cover[%d] lmdamage_cover[%d]\n",
	                      lminjured_cover, lmdeath_cover, lmdamage_cover );

	              /* 990208, �������[���� */
	              /* 980520, �j�v�~�Ȫ��[���� */
	              /*dbl_educated_rate = peducated_rate; */ /* 981222, ���צ��L�j�v�ثe���T�w�� 1    */
	              if (IsProvision){
	                  strcpy(chr_provision,sProvisionType); /* 980520, �̨ϥΪ̿�J�����D*/
	                  dbl_safe_rate     = psafe_rate;       /* 980520, �� user ��J     */
	                  dbl_manage_rate   = pmanage_rate;     /* 980520, �� user ��J     */
	                  /*dbl_educated_rate = peducated_rate;    980520, �ثe�T�w�� 1     */
	              }else{
		              strcpy(chr_provision," ");
		              dbl_safe_rate     = d_zero;
		              dbl_manage_rate   = d_zero;
		              /*dbl_educated_rate = d_zero; */
	              }
	      	      if (! Insert_INS_TYPE( sIinsType,
	      	                             lminjured_cover, lmdeath_cover, lmdamage_cover,
	      	                             lMdeduct,
	      	                             t_zero, t_zero,
	      	                             pagent, pcommission,  pdiscount,
	      	                             frate,
	      	                             t_zero,
	                                     d_zero, d_zero,  pdiscount,
	                                     c_zero, c_zero, c_zero,
	                                     c_ipaid_base, d_zero,
	                                     t_zero, t_zero, chr_provision, no_char, t_zero,dbl_safe_rate,dbl_manage_rate,peducated_rate,deviation_rate,pextra_charge, pbusiness))
	              {
	                  printf("malloc fail in struct INS_TYPE allocation!\n");
	                  $ROLLBACK WORK;
	                  return M_CM_NOT_MALLOC;   /* malloc fail */
	              }

	      	  }
	      	  else
	      	  {
	      	      sIinsType[j] = tmp_iins_list;
	      	      j++;
	      	  }

	      }
	      if (flg_chk==1){
	          while (Ifirst != NULL){
	             Icurr=Ifirst;
	             Ifirst=Icurr->next;
	             free(Icurr);
	          }
	          sprintf_s(errmsg, sizeof errmsg,"���o�~�ȱ��󤺮e�ɿ��~�GA��q���N��[%s] B��O�v�O[%s] B��~�ȱ���N��[%s] �I��[%s] �����I�O[%s]���~�X��[%d]",
	                  iroute,irate_type_B,iroute_comm_B,sIinsType,sIins_cat, rc );
	          $INSERT INTO CAR330_TEMP VALUES
	          ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
	          cnt_car330_tmp++;
	          continue;
	      }

      }
      else
      {

	      /* 980520, �@�ߨϥηs�O�v
	      /* 980310,�s�W�ˮ֦����N�z��
	      $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
	         INTO $fcomm_agent
	         FROM ca_rate_date
	        WHERE icode  = $frate
	          AND itable = 'commission_agent';

	      if(SQLCODE==SQLNOTFOUND) {
	     	   strcpy(fcomm_agent,"1");
	      }

	      if( fcomm_agent[0] == '1'){
	           strcpy( sTable, "commission_agent");
	      }else if( fcomm_agent[0] == '0'){
	           strcpy( sTable, "commission_agent_old");
	      }*/
	      strcpy( sTable, "commission_agent");
		  sprintf_s(stmt, sizeof stmt,"select icheck_busi,mservice,mother_busi,icheck_disc,pdiscount*100,pcommiss*100 from %s %s %s %s %s",
		                     sTable,
			                 " where ibroker= ? ",
			                 "  and iins_cat = ?",
			                 "  and iyear = ? " ,
			                 "  and iins_type = ?");
	      $PREPARE chk_broker_discount FROM $stmt;
	      printf("chk_broker_discount[%s]\n", stmt);


	      for( i=0 ; i < strlen(iins_list); i++ )
	      {
	      	  tmp_iins_list = iins_list[i];
	      	  printf("tmp_iins_list=[%c] j=[%d]\n", tmp_iins_list,j );
	      	  if( tmp_iins_list == ',' )
	      	  {
	      	      sIinsType[j] = '\0';

		          /* 980310,�s�W�ˮ֦����N�z��*/
			   	  $EXECUTE chk_broker_discount
			      /*  INTO $icheck_busi,$mservice,$mother_busi,$icheck_disc ,$pdiscount_broker,$pcommiss_broker*/
				     USING $ibroker,"C","0",$sIinsType;
				  printf(" ------- SQLCODE = [%d]\n " , SQLCODE);
			      if(SQLCODE == SQLNOTFOUND){
			      	   flg_chk = 1;
			           break;
			      }

	      	      $EXECUTE get_insb INTO $lMdeduct, $lminjured_cover, $lmdeath_cover, $lmdamage_cover,$chr_provision,$dbl_safe_rate,$dbl_manage_rate
	      	         USING $sIinsType;

	      	      printf("sIinsType=[%s] lMdeduct=[%d] frate=[%s]\n", sIinsType, lMdeduct, frate );
	      	      printf("1:lminjured_cover[%d] lmdeath_cover[%d] lmdamage_cover[%d]\n",
	                      lminjured_cover, lmdeath_cover, lmdamage_cover );

	              /* 980520, �j�v�~�Ȫ��[���� */
	              /*dbl_educated_rate = peducated_rate; */ /* 981222, ���צ��L�j�v�ثe���T�w�� 1    */
	              if (IsProvision){
	                  strcpy(chr_provision,sProvisionType); /* 980520, �̨ϥΪ̿�J�����D*/
	                  dbl_safe_rate     = psafe_rate;       /* 980520, �� user ��J     */
	                  dbl_manage_rate   = pmanage_rate;     /* 980520, �� user ��J     */
	                  /*dbl_educated_rate = peducated_rate;    980520, �ثe�T�w�� 1     */
	              }else{
		              strcpy(chr_provision," ");
		              dbl_safe_rate     = d_zero;
		              dbl_manage_rate   = d_zero;
		              /*dbl_educated_rate = d_zero;*/
	              }

	              if (! Insert_INS_TYPE( sIinsType,
	      	                             lminjured_cover, lmdeath_cover, lmdamage_cover,
	      	                             lMdeduct,
	      	                             t_zero, t_zero,
	      	                             d_zero, d_zero,  pdiscount,
	      	                             frate,
	      	                             t_zero,
	                                     d_zero, d_zero,  pdiscount,
	                                     c_zero, c_zero, c_zero,
	                                     c_ipaid_base, d_zero,
	                                     t_zero, t_zero, chr_provision, no_char, t_zero,dbl_safe_rate,dbl_manage_rate,peducated_rate,deviation_rate,pextra_charge, pbusiness))
	              {
	                  printf("malloc fail in struct INS_TYPE allocation!\n");
	                  $ROLLBACK WORK;
	                  return M_CM_NOT_MALLOC;   /* malloc fail */
	              }

	              strcpy( sIinsType, "");
	              j=0;
	      	  }
	      	  else if(i == (strlen(iins_list) -1) )
	      	  {
	      	      sIinsType[j] = tmp_iins_list;
	      	      sIinsType[j+1] = '\0';


		          /* 980310,�s�W�ˮ֦����N�z��*/
			   	  $EXECUTE chk_broker_discount
			      /*  INTO $icheck_busi,$mservice,$mother_busi,$icheck_disc ,$pdiscount_broker,$pcommiss_broker*/
				     USING $ibroker,"C","0",$sIinsType;
				  printf(" ------- SQLCODE = [%d]\n " , SQLCODE);
			      if(SQLCODE == SQLNOTFOUND){
			      	   flg_chk = 1;
			           break;
			      }

	      	      $EXECUTE get_insb INTO $lMdeduct, $lminjured_cover, $lmdeath_cover, $lmdamage_cover,$chr_provision,$dbl_safe_rate,$dbl_manage_rate
	      	         USING $sIinsType;

	      	      printf("sIinsType=[%s] lMdeduct=[%d] frate=[%s]\n", sIinsType, lMdeduct, frate );
	      	      printf("2:lminjured_cover[%d] lmdeath_cover[%d] lmdamage_cover[%d]\n",
	                      lminjured_cover, lmdeath_cover, lmdamage_cover );

	              /* 990208, �������[���� */
	              /* 980520, �j�v�~�Ȫ��[���� */
	              /*dbl_educated_rate = peducated_rate; */ /* 981222, ���צ��L�j�v�ثe���T�w�� 1    */
	              if (IsProvision){
	                  strcpy(chr_provision,sProvisionType); /* 980520, �̨ϥΪ̿�J�����D*/
	                  dbl_safe_rate     = psafe_rate;       /* 980520, �� user ��J     */
	                  dbl_manage_rate   = pmanage_rate;     /* 980520, �� user ��J     */
	                  /*dbl_educated_rate = peducated_rate;    980520, �ثe�T�w�� 1     */
	              }else{
		              strcpy(chr_provision," ");
		              dbl_safe_rate     = d_zero;
		              dbl_manage_rate   = d_zero;
		              /*dbl_educated_rate = d_zero; */
	              }
	      	      if (! Insert_INS_TYPE( sIinsType,
	      	                             lminjured_cover, lmdeath_cover, lmdamage_cover,
	      	                             lMdeduct,
	      	                             t_zero, t_zero,
	      	                             d_zero, d_zero,  pdiscount,
	      	                             frate,
	      	                             t_zero,
	                                     d_zero, d_zero,  pdiscount,
	                                     c_zero, c_zero, c_zero,
	                                     c_ipaid_base, d_zero,
	                                     t_zero, t_zero, chr_provision, no_char, t_zero,dbl_safe_rate,dbl_manage_rate,peducated_rate,deviation_rate,pextra_charge, pbusiness))
	              {
	                  printf("malloc fail in struct INS_TYPE allocation!\n");
	                  $ROLLBACK WORK;
	                  return M_CM_NOT_MALLOC;   /* malloc fail */
	              }

	      	  }
	      	  else
	      	  {
	      	      sIinsType[j] = tmp_iins_list;
	      	      j++;
	      	  }

	      }
	      if (flg_chk==1){
	          while (Ifirst != NULL){
	             Icurr=Ifirst;
	             Ifirst=Icurr->next;
	             free(Icurr);
	          }
	          sprintf_s(errmsg, sizeof errmsg," �I�O[C]�g���N��[%s]�I��[%s]�~��[0], �����N�z�v�ɸ�Ƨ䤣��,�O�渹[%s] ",
	                                   ibroker, sIinsType, ipolicyB);
	          $INSERT INTO CAR330_TEMP VALUES
	         ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
	          cnt_car330_tmp++;

		      continue ;
	      }
      }
      strncpy(sTmpIcomp,   ipolicyA+2,1);
      sTmpIcomp[1] = '\0';
      strcpy(sTmpIbranch, ibranch_in);
      strcpy(officer2,    iofficer);
      strcpy(car_typei2,  icar_type);

      code=Cal_ins_premium(INS_ptr);      
      if (code != SUCCESS) {
      	    errmsg[0]='\0';
            if(code==M_CA_CA_ID_OFFICER_W){
		         sprintf_s(errmsg, sizeof errmsg,"�M�ץ�j�v���[���ڳ]�w���@���H�W��ơJ�O�渹[%s],�n�O�HID[%s],�g��N��[%s](�Ц�car144�T�{) ",
		                           ipolicyB, iapplicant,officer2);
            }else if (code==M_CA_CA_ID_OFFICER){
		         sprintf_s(errmsg, sizeof errmsg,"�M�ץ�j�v���[���ڳ]�w�����ɡJ�O�渹[%s],�n�O�HID[%s],�g��N��[%s](�Ц�car144�T�{) ",
		                           ipolicyB, iapplicant,officer2);
            }else if(code==M_CA_ADJ_PURE_RATE){
		         sprintf_s(errmsg, sizeof errmsg,"�«O�O�[��T�ץ����ɥ����ɡJ�O�渹[%s],�n�O�HID[%s],�g��N��[%s](�Ц�car145�T�{) ",
		                           ipolicyB, iapplicant,officer2);
            }
            if (errmsg[0]!='\0'){
		         $INSERT INTO CAR330_TEMP VALUES
		         ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
		          cnt_car330_tmp++;
		          continue ;
            }else{
            	 $ROLLBACK WORK;
            	 return M_CM_NOT_MALLOC;   /* malloc fail */
            }
      }

      if (execItem[0]=='1'){ /* �X�� */

	      /** Step 4.2 get �O�渹 **/
	      fGetNumErr = 'N';
	      for (i=0; i<3; i++)  /* try 3 �� ( cm_get_serial_num_dwritten()���w��lock mode wait 2sec )*/
	      {
	      	  strcpy(ply_num2, " ");
	      	  if ((strncmp(iofficer,"N",1) == 0) && (strncmp(ibig_comp2,"A",1) == 0))
	      	  { /* �Ϳ��O��--�O��r�y(VA) add by sylvia 104.06.10 (1040505003_C2) */
	      	    code=cm_get_serial_num_dwritten("C1", "CVA", sTmpIcomp, sTmpIbranch, ymd_Today, ymd_Today, ply_num2);
	      	  }
	      	  else
	      	  {
	      	    /* �D�Ϳ��O�� */
	            code=cm_get_serial_num_dwritten("C1", "CB", sTmpIcomp, sTmpIbranch, ymd_Today, ymd_Today, ply_num2);
	          }
	          if (code==0){
	          	 ply_num2[CAR_POLICY_LEN]='\0';
	             break;
	          }
	      }

	      /* try 3 �� �ᤴ�����츹�A�h�C�����D�� */
	      /* ���ݭn ROLLBACK WORK �A�]���٨S���}�linsert ��� */
	      if (code==1 || code==2)
	      {
	      	  fGetNumErr = 'Y';
	          /*$ROLLBACK WORK;
	          return M_CM_DB_NOTOPEN;*/
	      }
	      else if (code==3)
	      {
	      	  fGetNumErr = 'Y';
	          /*$ROLLBACK WORK;
	          return M_CMN_NAUTONUMBERING;*/
	      }
	      else if (code!=0)
	      {
	      	  fGetNumErr = 'Y';
	          /*$ROLLBACK WORK;
	          return code;*/
	      }

	      printf("ply_num2 = [%s]\n", ply_num2 );

	      /* 102.08.12 �������ѮɡA�~�����U�@�� */
	      if (fGetNumErr == 'Y'){
		      sprintf_s(errmsg, sizeof errmsg,"�i�X�楢�ѡj��]�G���u�O�渹�v���ѡF������[%s]�A����[%s]", iengine, itag );
		      $INSERT INTO CAR330_TEMP VALUES
		      ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
		      cnt_car330_tmp++;
		      continue;
	      }

	      /** Step 4.1 ��get ���N�d�� **/
	      fGetNumErr = 'N';
	      for (i=0; i<3; i++)  /* try 3 �� ( cm_get_serial_num_dwritten()���w��lock mode wait 2sec )*/
	      {
	      	  strcpy(card2, " ");
	      	  /* �t�XN�g�춷�P�_NA��NB, ��L�OCP, �b�e���N���P�_,��bsRtype��,�BN�g�춷�T�w������c,�����q�O */
	          /* code=cm_get_serial_num_dwritten("C1", "CP", sTmpIcomp, sTmpIbranch, ymd_Today, ymd_Today, card2); */
	          printf("2114--sRtype=[%s]card2=[%s]sTmpIcomp=[%s]sTmpIbranch=[%s]",sRtype,card2,sTmpIcomp,sTmpIbranch);
	          if (strcmp(sRtype,"CP") == 0)
	               code=cm_get_serial_num_dwritten("C1", sRtype, sTmpIcomp, sTmpIbranch, ymd_Today, ymd_Today, card2);
	          else
	               code=cm_get_serial_num_dwritten("C1", sRtype, " ", " ", ymd_Today, ymd_Today, card2);

	          if (code==0) break;
	      }

          /* try 3 �� �ᤴ�����츹�A�h�C�����D�� */
	      if (code==1 || code==2)
	      {
	          fGetNumErr = 'Y';
	          /* $ROLLBACK WORK;
	          return M_CM_DB_NOTOPEN;*/
	      }

	      else if (code==3)
	      {
	          fGetNumErr = 'Y';
	          /* $ROLLBACK WORK;
	          return M_CMN_NAUTONUMBERING;*/
	      }
	      else if (code!=0)
	      {
	          fGetNumErr = 'Y';
	          /*$ROLLBACK WORK;
	          return code;*/
	      }

	      /* 102.08.12 �������ѮɡA�~�����U�@�� */
	      if (fGetNumErr == 'Y'){
		      sprintf_s(errmsg, sizeof errmsg,"�i�X�楢�ѡj��]�G���u���N�d���v���ѡF������[%s]�A����[%s]", iengine, itag );
		      $INSERT INTO CAR330_TEMP VALUES
		      ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
		      cnt_car330_tmp++;
		      continue;
	      }
	   }


      mdmg_agent_2= mdmg_commi_2= mdmg_disco_2= mdmg_prem = mdmg_pure_prem = 0;
      mlia_agent_2= mlia_commi_2= mlia_disco_2= mlia_prem = mlia_pure_prem = 0;

      Icurr=Ifirst;

      while (Icurr)
      {

          if (EQUAL(trim(Icurr->ins_type),"**"))
          { /* deleted element */
              Icurr=Icurr->next;
              continue;
          }
		  
		  if((memcmp(trim(Icurr->ins_type),"11",2)==0) && (strncmp(ibrand+6, "01", 2) == 0))
		  {
			  printf("!!!Electric Car with iins 11, next!!!\n");
			  Icurr=Icurr->next;
              continue;
		  }
		  else if((memcmp(trim(Icurr->ins_type),"211",3)==0) && (strncmp(ibrand+6, "01", 2) != 0))
		  {
			  printf("!!!Non Electric Car with iins 211, next!!!\n");
			  Icurr=Icurr->next;
              continue;
		  }

          printf("Trace -- Icurr->ins_type = [%s] \n",  Icurr->ins_type);
          printf("Trace -- Icurr->provision = [%s] \n",  Icurr->provision);
          strcpy(ins_type,trim(Icurr->ins_type));
          strcpy(provision,Icurr->provision);
          strcpy(tmp_provision,"");
          sprintf_s(tmp_provision, sizeof tmp_provision,"%s;",trim(Icurr->provision)); /* ���� */
          printf("Trace -- ins_type = [%s]\n", ins_type );
          printf("Trace -- provision = [%s] \n",  provision);
          printf("Trace -- tmp_provision = [%s] \n",  tmp_provision);
          

          /* �O�I���B�d���H�U�L����˥h */
          /* 15�B16�I�ئܦʦ�*/
          if (strcmp(trim(ins_type),"15")==0 || strcmp(trim(ins_type),"16")==0)
          {
              injured_cover = ((Icurr->injured_cover)/100)*100;
              death_cover   = ((Icurr->death_cover)/100)*100;
              damage_cover  = ((Icurr->damage_cover)/100)*100;
          }
          else
          {

              injured_cover = ((Icurr->injured_cover)/1000)*1000;
              death_cover   = ((Icurr->death_cover)/1000)*1000;
              damage_cover  = ((Icurr->damage_cover)/1000)*1000;

          }

          deduct      = Icurr->deduct;
          pcommission = Icurr->pcommission;
          mcommission = Icurr->mcommission;

          pagent      = Icurr->pagent;
          magent      = Icurr->magent;

          pdiscount   = Icurr->pdiscount;
          mdiscount   = Icurr->mdiscount;

          qday        = Icurr->qday;
          mexpense    = Icurr->mexpense;
          mexp_disc   = Icurr->mexp_disc;

          dbl_safe_rate    = Icurr->safe_rate;
          dbl_manage_rate  = Icurr->manage_rate;
          dbl_educated_rate  = Icurr->educated_rate;

          irate_1     = Icurr->irate ;
          adjust_rate = Icurr->adjust_rate;
          mins_premium_n = Icurr->mins_premium_n;
          mpure_prem_n   = Icurr->mpure_prem_n;
          mprem_n        = Icurr->mprem_n;

          if ((strcmp(trim(ins_type),"01") != 0) &&
              (strcmp(trim(ins_type),"05") != 0) &&
              (strcmp(trim(ins_type),"08") != 0) &&
              (strcmp(trim(ins_type),"09") != 0) &&
              (strcmp(trim(ins_type),"85") != 0) &&
              (strcmp(trim(ins_type),"11") != 0))
          {
               /* �[�ȥN�B���O�� */
               mexpense  = 0;
               mexp_disc = 0;
          }

          if ((strcmp(trim(ins_type),"31")==0) && (injured_cover > 0))
          {
               qday = (long)(damage_cover / injured_cover) ;
          }

          strcpy(ipaid_base, trim(Icurr->ipaid_base));

          ins_premium      = (long)Icurr->ins_premium;
          bef_ins_premium  = (long)Icurr->bef_ins_premium;
          pure_ins_premium = (long)Icurr->pure_ins_premium;

          $SELECT fins_grp
             INTO $fins_grp_1
             FROM insurance_type
            WHERE iins_type=$ins_type;
          if (NOT_FOUND)
          {
              $ROLLBACK WORK;
              return M_CA_NINS_TYPE;
          }

          if (fins_grp_1[0]=='1')
          {
              printf("INS_ptr->ins_premium[%lf]\n",INS_ptr->ins_premium);
              printf("In 305 CA305_Step11 pdiscount1=%lf\n",INS_ptr->pdiscount);

              /* ���l�����N�z�O�[�` */
              mdmg_agent_2=mdmg_agent_2+ magent;
              mdmg_commi_2=mdmg_commi_2+ mcommission;
              mdmg_disco_2=mdmg_disco_2+ mdiscount;

              mdmg_prem      = mdmg_prem      + ins_premium;
              mdmg_pure_prem = mdmg_pure_prem + pure_ins_premium;

              printf("mdmg_disco_2=[%d] mdiscount=[%d]\n", mdmg_disco_2, mdiscount );

          }
          else if (fins_grp_1[0]=='2')
          {
              printf("In 305 CA305_Step11 pdiscount2=%lf\n",INS_ptr->pdiscount);

              /* ���d�����N�z�O�[�` */
              mlia_agent_2=mlia_agent_2+ magent;
              mlia_commi_2=mlia_commi_2+ mcommission;
              mlia_disco_2=mlia_disco_2+ mdiscount;

              mlia_prem      = mlia_prem      + ins_premium;
              mlia_pure_prem = mlia_pure_prem + pure_ins_premium;
          }

          if (execItem[0]=='1'){ /* �X�� */

	          strcpy(drate_ym,Icurr->frate);

	          $SELECT qserial
	             INTO $qserial
	             FROM insurance_type
	            WHERE iins_type=$ins_type;
	          if (NOT_FOUND)
	          {
	              $ROLLBACK WORK;
	              return M_CA_NINS_TYPE;
	          }

	          rc = get_iproduct_car(ins_type,car_typei2,iproduct, provision);
	          if (rc != M_CM_OK)
	          {
	              $ROLLBACK WORK;
	              return M_CA_NON_PRODUCT;
	          }
	          
	          /* �۰ʥ[�WP/Q���� add by 061476 (1071226006_SC9)*/
	          /* ���[�����X�R�A�վ�����y�k�W�h modify by 061476 (1081225006_SC4) */
	          if (fProvision_P[0]=='Y')
	          {
	          	if (ISINS_PROV_P(ins_type))
	          	{
	          		if(strstr(tmp_provision,"P;") == NULL)
	          		{
	          			if (strlen(trim(provision)) == 0){
	          				strcpy(provision,trim(provision));
	          				strcat(provision,"P");
	          			}else{
	          				strcpy(provision,trim(provision));
	          				strcat(provision,";P");
	          			}
	          		}
	          	}
	          }
	          if (fProvision_Q[0]=='Y')
	          {
	          	if (ISINS_PROV_QM(ins_type))
	          	{
	          		if(strstr(tmp_provision,"Q;") == NULL)
	          		{
	          			if (strlen(trim(provision)) == 0){
	          				strcpy(provision,trim(provision));
	          				strcat(provision,"Q");
	          			}else{
	          				strcpy(provision,trim(provision));
	          				strcat(provision,";Q");
	          			}
	          		}
	          	}
	          }

	          sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ply_ins_type (ipolicy,iins_type,minjured_cover,mdeath_cover,  "
	                       "mdamage_cover,mdeduct,mins_premium,mpure_prem,pcommission,mcommission,  "
	                       "pagent,magent,pdiscount,mdiscount,qserial,drate_ym,mprem,iproduct,ipaid_base,qday,  "
	                       "mexpense,mexp_disc,provision,deviation_rate,pextra_charge,pbusiness,safe_rate, manage_rate,educated_rate,irate,adjust_rate,  "
	                       "mins_premium_n, mpure_prem_n, mprem_n, mdrunk_prem, mdrunk_pure_prem ) VALUES (?,?,?,?,?, ?,?,?,?,?,?,?,?,?,?,  "
	                       "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,0.0 )", car_dbnameA );

	          printf("----------------------------------\n");
	          printf("stmt[%s]\n", stmt );

	          $PREPARE InsPins_x2 FROM $stmt;
	          $EXECUTE InsPins_x2 using   $ply_num2, $ins_type,$injured_cover,
	                         $death_cover,$damage_cover,$deduct,
	                         $ins_premium,$pure_ins_premium,$pcommission,$mcommission,
	                         $pagent,$magent,$pdiscount,$mdiscount,
	                         $qserial,$drate_ym,$bef_ins_premium,$iproduct,$ipaid_base,
	                         $qday,$mexpense,$mexp_disc,$provision,$deviation_rate,$pextra_charge,$pbusiness,
	                         $dbl_safe_rate,$dbl_manage_rate,$dbl_educated_rate,$irate_1,$adjust_rate,$mins_premium_n, $mpure_prem_n, $mprem_n;
	            printf(" ------- SQLCODE = [%d]\n " , SQLCODE);

          }

          Icurr=Icurr->next;
      }

      printf("trace mins_premium[%d]\n ",mins_premium);
      mins_premium = mdmg_prem + mlia_prem;
      rfmtdouble(mins_premium, "---,--&", s_mins_prem);
      dbl_mins_premium = 1.0 * mins_premium;

      printf("----------------------------------\n");

      $SELECT nname INTO $off_name FROM officer
        WHERE iofficer = $iofficer;
      if(SQLCODE == SQLNOTFOUND) strcpy( off_name, " ");

      printf("trace off_name[%s]\n ",off_name);

      printf("----------------------------------\n");
      /* 971112,�ק����I�W�ٳW�h */
	   $SELECT nname INTO $big_name FROM officer
	     WHERE iofficer = (SELECT iofficer FROM ca_promote_officer
                            WHERE iofficer_ori = $iofficer
                              AND ibig_office = $ibig_office);
      if(SQLCODE == SQLNOTFOUND) strcpy( big_name, " ");

	   printf("trace big_name[%s]\n ",big_name);


      /*----- ���� ------*/
      if (execItem[0]=='0')
      {
      	   printf("trace ����\n ");

	       fGetNumErr = 'N';
	       printf("sTmpIcomp=[%s] sTmpIbranch=[%s] ymd_Today=[%s]\n",sTmpIcomp, sTmpIbranch, ymd_Today);
	       for (i=0; i<3; i++)  /* try 3 �� ( cm_get_serial_num()���w��lock mode wait 2sec )*/
	       {
	      	   strcpy(iestimateB, " ");
	           code = cm_get_serial_num("C1", "CK", sTmpIcomp, sTmpIbranch, ymd_Today, iestimateB);
	           if (code==0) break;
	       }
           /* try 3 �� �ᤴ�����츹�A�h�C�����D�� */
	       printf("trace code[%ld]\n ",code);
	       if (code!=0){
		       /*$ROLLBACK WORK;
		       return code;*/
		       fGetNumErr = 'Y';
		   }

	       /* 102.08.12 �������ѮɡA�~�����U�@�� */
	       if (fGetNumErr == 'Y'){
		       sprintf_s(errmsg, sizeof errmsg,"�i�������ѡj��]�G���u�����渹�v���ѡF������[%s]�A����[%s]", iengine, itag );
		       $INSERT INTO CAR330_TEMP VALUES
		       ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
		       cnt_car330_tmp++;
		       continue;
	       }

      	   strcpy(isub ," ");
		   $SELECT iupcomp INTO $isub FROM branch WHERE ibranch = $sTmpIbranch ;    /* �����q   */

		   printf("EXECUTE prep_receive:iestimateB  [%s]\n ",iestimateB);

	      printf("trace itag[%s]\n ",itag);
	      printf("trace iengine[%s]\n ",iengine);

           /* [102.07.01] �w�����W�u�G�@�ߵ����ĳq��A���\���X��᦬�O */
         strcpy(ftype_pol," ") ;
	 	   #if _VERSION == _VER_PRE
	 	      strcpy(ftype_pol,"SP") ;
         #endif

		   $EXECUTE prep_receive
		      using $iestimateB, "2", "C2", $iassured, $nassured, $iapplicant, $napplicant, $itag, $iengine,
		            $ply2_begin, $ply2_begin, $dbl_mins_premium, $isub, $officer2, $sIleader2,
		            $sIquota2, $icomm_obj_B, $iroute_B, "N", $userid , "1", "car330", $ftype_pol, $ftype_sp,
		            $ply2_begin,$ply2_end;
          printf("trace SQLCODE[%d]\n ",SQLCODE);



           printf("INSERT INTO CAR330_TEMP:officer2  [%s]\n ",officer2);
	       $INSERT INTO CAR330_TEMP VALUES ($officer2,$off_name,$ibig_office,$big_name,$iestimateB,
	          $dply_begin_a,$dply_end_a,$iengine,$itag,$nassured,$s_mins_prem,'',$iapplicant,$napplicant,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
            printf("trace SQLCODE[%d]\n ",SQLCODE);
	       cnt_car330_tmp++;

      }/*----- ���� END ------*/
      else if (execItem[0]=='1')
      {  /* �X�� */
		  printf("dbl_estimate_prem = [%ld], dbl_mins_premium = [%ld]\n", (long)dbl_mins_premium, (long)dbl_estimate_prem);
      	  if ((long)dbl_estimate_prem != (long)dbl_mins_premium){
		       sprintf_s(errmsg, sizeof errmsg,"�X��O�O[%ld]�P�����O�O[%ld]���۵�(������[%s],�����渹[%s])",
		                (long)dbl_mins_premium, (long)dbl_estimate_prem ,iengine ,iestimateB );

		       $INSERT INTO CAR330_TEMP VALUES
		        ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
		        cnt_car330_tmp++;
		       
		       /* �]�e���w�����üg�Jply_ins_type�A�ݧR���ñN�O�渹�g�J�Ÿ��� (1071226006_SC9)*/ 
		       sprintf_s(stmt, sizeof stmt, " DELETE FROM %s:ply_ins_type WHERE ipolicy = '%s'; ",car_dbnameA ,ply_num2);
		       $PREPARE del_ins_type FROM $stmt;
		       $EXECUTE del_ins_type;
		             
		       sprintf_s(stmt, sizeof stmt, " INSERT INTO %s:reusible_num (dwritten,qwritten_num) VALUES (?,?);",car_dbnameA);
		       $PREPARE Inser_reusible FROM $stmt;
		       $EXECUTE Inser_reusible using $Today, $ply_num2;
		       
		       continue ;
           }
     	  /* �]���ѵs�I����, �t�Τ�b103/08/01-108/08/31�ΫO���b103/08/01-108/08/31�~�|�ˮ� */
     	  icnt302 = 0;
     	  strcpy(explicyb, ipolicyB);   /* ��B�檺�e�O�渹�d�U�� */

     	  $select count(ipolicy) into $icnt302
            from policy_302
           where 1=1
             and iestimate_ori = $iestimateB
             and (today < '09/01/2014' or dply_begin between '08/01/2014' and '08/31/2014');
         printf("------2399 icnt302=[%d]\n ",icnt302);
         if (icnt302 > 0)
         {
            printf("------2400 ipolicyA=[%s]explicyb=[%s] iestimateB=[%s]\n ",ipolicyA,explicyb,iestimateB);
        	  	/* B��S���e�O�渹,�H��O�J�p�ɤ�������B��g�J add by sylvia 103.08.05 */
        	  	strcpy(ipolicyA, trim(ipolicyA));
        	  	strcpy(explicyb, trim(explicyb));

   	      if ((strlen(trim(explicyb)) == 0)||( strcmp(explicyb,ipolicyA) == 0))
   	      {
   	         $select ipolicy into $explicyb
                 from policy_302
                where iestimate_ori =$iestimateB;

               if(SQLCODE == SQLNOTFOUND)
               {
                  /* �b��O�J�p�ɭ��O�զX�䤣�� */
                  sprintf_s(errmsg, sizeof errmsg,"�������渹[%s]�b��O�J�p�ɭ��O�զX�䤣��)",iestimateB );
                  printf("-- 2412 -- errmsg=[%s]\n",errmsg);
                  $INSERT INTO CAR330_TEMP VALUES
      		           ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
      		         cnt_car330_tmp++;
      		         continue ;
               }
   	      }
   	      
   	      /* �s�W�ˮ�:�ˮֶ��P��O�J�p�ɤ��������B�Q�O�I�HID�B�O���۲�
                  add by sylvia 103.08.04 (1030724002_C3) -----------------------------------*/
            icnt302 = 0;
            $select count(*) into $icnt302
               from policy_302
              where iestimate_ori =$iestimateB
                and dply_begin = $dply_begin_a
                and dply_end = $dply_end_a;

            if (icnt302 == 0)
            {  /* �P��O�J�p�O������ */
               sprintf_s(errmsg, sizeof errmsg,"���O��[%s]~[%s]�P��O�J�p�ɤ��۵�(�����渹[%s])",
   		                dply_begin_a, dply_end_a ,iestimateB );
   		      printf("-- 2434 -- errmsg=[%s]\n",errmsg);
               $INSERT INTO CAR330_TEMP VALUES
   		           ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
   		         cnt_car330_tmp++;
   		         continue ;
   	    }
   	    
   	    icnt302 = 0;
            $select count(*) into $icnt302
               from policy_302
              where iestimate_ori =$iestimateB
                and ilicense = $iassured;

            if (icnt302 == 0)
            {  /* �P��O�J�p�O������ */
               sprintf_s(errmsg, sizeof errmsg,"��O�Q�O�I�H[%s]�P��O�J�p�ɤ��۵�(�����渹[%s])",
   		                iassured ,iestimateB );
   		      printf("-- 2451 -- errmsg=[%s]\n",errmsg);
               $INSERT INTO CAR330_TEMP VALUES
   		           ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
   		         cnt_car330_tmp++;
   		         continue ;
   	    }

   	    icnt302 = 0;
            $select count(*) into $icnt302
               from policy_302
              where iestimate_ori =$iestimateB
                and iengine = $iengine;

            if (icnt302 == 0)
            {  /* �P��O�J�p�O������ */
               sprintf_s(errmsg, sizeof errmsg,"��O������[%s]�P��O�J�p�ɤ��۵�(�����渹[%s])",
   		                iengine ,iestimateB );
   		      printf("-- 2468 -- errmsg=[%s]\n",errmsg);
               $INSERT INTO CAR330_TEMP VALUES
   		           ($estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$errmsg,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr,$estr);
   		         cnt_car330_tmp++;
   		         continue ;
   	    }
   	 }
	 /* --�ѵs�I�����ˮ�end------------------------------------------------------------------------------------ */


	      {
	      int icardYear;
	      cm_long_split_3ymd( ply2_begin, sTmpyyB, sTmpmmB, sTmpddB);
	      icardYear = atoi( sTmpyyB);  /* ����098�ର98 */
	      sprintf_s(tmp_icardyear, sizeof tmp_icardyear, "%d", icardYear);
	      }

	      $SELECT b.ibranch, b.iupbranch
	         INTO $sTmpIbranchCard, $sTmpIcompCard
	         FROM officer a , branch b
	        WHERE a.ibranch = b.ibranch
	          and a.iofficer = :officer2;
	      if (SQLCODE==SQLNOTFOUND)
	      {
	          sTmpIbranchCard[0] = '\0';
	          sTmpIcompCard[0] = '\0';
	      }
	      
	      printf("Trace -- card2 = [%s] \n",  card2);
	      $INSERT INTO card
	              (icard,iofficer,ioffice,icardyear,dissue,fstatus,ialter,
	               icar_type,iissue_branch,iissue_comp,iquota,
	               ireceive,ideliver,ideliver_old,dreceive,ddeliver)
	       VALUES ($card2,$officer2,$ibranch2,$tmp_icardyear,$Today,"0", $ientry_A,
	               $car_typei2,$sTmpIbranchCard,$sTmpIcompCard,$sIquota2,
	               $officer2,$officer2,$officer2,$Today,$Today);
	      printf("Trace -- card2 = [%s] \n",  card2);
	      printf("Trace -- INSERT INTO card SQLCODE= [%d] \n",  SQLCODE);



	      /** Step 4.3 �s�W��Ʀ� ply_relation  **/
	      /* 990319, �s�W iofficer_prmt,iquota_prmt,ileader_prmt */
	      /* 102.03  �s�Witmp_policy (iestimateB) */
	      /* 1101013 �s�Wiprog add by 061476 (1091215005_SC3) */
	      /* 1110324 �s�Wftrans_third  (1110303014_SC1)*/
	      printf("---------------------------------\n");
	      printf("step 4.3 insert into ply_relation\n");
	      if (strcmp(sRtype,"CP") == 0)
	         strcpy(ibig_comp2," ");

	      /* �t�X���O�X��104/01/01�W�u,�M�ץ�J�渹,���Hcar327�C�O��,�G���{���������^��ñ���(dprint),�L�����A(fprint) modify by sylvia 103.12.10(1031111001_C3) */
	      
	      /* �t�X�A�Ȥ��ߩ�����A�W�[�g�J�����Τ��e modify by 061476 (1091021005_SC3) */
	      if (strcmp(foffice,"Y") == 0) /* �`�����q */
	      {
	      	   strcpy(funder_chk,"N");
	      	   fsign_status = 40;
	      }
	      else  /* �A�Ȥ��� */
	      {
	      	   strcpy(funder_chk,"Y");
	      	   fsign_status = 20;
	      }	      

	      sprintf_s(stmt, sizeof stmt," INSERT INTO %s:ply_relation (ipolicy,icard,fcard_class,ilast_card,ilast_ply, "
	             "itreaty,qply_period,dply_begin,dply_end,ipro_year,  "
	             "ibrand,icar_type,mdmg_agent,mdmg_commi,mdmg_discount,  "
	             "mdmg_prem,mdmg_pure_prem,mlia_agent,mlia_commi,mlia_discount,  "
	             "mlia_prem,mlia_pure_prem,ibig_office,ibig_sales,iresource,  "
	             "ibroker,iofficer,ileader,iarea,icashier,  "
	             "iexaminer,dexamine,ientry,dentry,dpolicy,  "
	             "fprint,ibranch,iquota,icomp_in,ibranch_in,  "
	             "icomp_at,ibranch_at,fdiscount,icar_flag,fcomp_class,  "
	             "fcomp_class_last,iofficer_prmt,iquota_prmt,ileader_prmt,irate_type, "
	             "bzfrom,iroute_comm,icomm_obj,dcreate,itmp_policy,  "
	             "icard_main,qdrunk_driving,ibig_comp,feply,aemail_eply,  "
	             "tmobile_eply,fsign_status,funder_chk,feterms,iprog,   "
	             "ftrans_third) VALUES  "
	             "(?,?,?,?,?,  ?,?,?,?,?,  ?,?,?,?,?,  ?,?,?,?,?,  ?,?,?,?,?,        "
	             " ?,?,?,?,?,  ?,?,?,?,?,  ?,?,?,?,?,  ?,?,?,?,0,  0,?,?,?,?,   "
	             " ?,?,?,current,?,  ?,0,?,?,?, ?,?,?,?,'car330', 'N' )",car_dbnameA );

	      printf("stmt[%s]\n", stmt );
	      printf("2525--- ply_num2=[%s]\n",ply_num2);
	      printf("2916������ ibranch = [%s]\n",ibranch);	      	      
	      
	      $PREPARE Insertply_x1 FROM $stmt;
	      $EXECUTE Insertply_x1 using $ply_num2, $card2, "2", $ilast_card, $explicyb,
	               "1", $qply_period, $dply_begin_a, $dply_end_a, $ipro_year,
	               $ibrand, $icar_type, $mdmg_agent_2, $mdmg_commi_2, $mdmg_disco_2,
	               $mdmg_prem, $mdmg_pure_prem, $mlia_agent_2, $mlia_commi_2, $mlia_disco_2,
	               $mlia_prem, $mlia_pure_prem, $ibig_office, $ibig_sales, "E",
	               $ibroker, $iofficer, $sIleader2, $iarea, $iofficer,
	               $ientry_A, $Today, $ientry_A, $Today, "",
	               "0", $ibranch, $sIquota2, $icomp_in, $ibranch_in,
	               $icomp_at, $ibranch_at, "Y", "2",
	               $iofficer_prmt, $iquota_prmt, $ileader_prmt, $irate_type_B,
	               $bzfrom_B, $iroute_comm_B,$icomm_obj_B, $iestimateB,
	               $ixxcard, $ibig_comp2, $feply, $aemail_eply,
	               $tmobile_eply, $fsign_status, $funder_chk, $feterms;
	      printf(" ------- SQLCODE = [%d]\n " , SQLCODE);

	      /* �`�����q��update�֫O�H���Τ�� add by 061476 (1091021005_SC3) */
	      if (strcmp(foffice,"Y") == 0)
	      {
	      	   sprintf_s(stmt, sizeof stmt,"UPDATE %s:ply_relation SET isign=?, dapply=? WHERE ipolicy = '%s'", car_dbnameA, ply_num2 );
	      	   
	      	   printf("stmt[%s]\n", stmt);
	      	   $PREPARE up_ply FROM $stmt;
	      	   $EXECUTE up_ply USING $isign, $Today;
	      }	      
	      
	      /** Step 4.5 �s�W��Ʀ� policy **/
	      /*990319, �s�W iroute           */
	      /*100.11.01, �s�W qlia_acc_sum ,qdmg_acc_sum , ���B�������w�]�� 0     */
	      /*107.06.26 �s�Wmobil_phone��� (1070308010_SC1)*/
	      /*109.12.16 �s�Wqpro_month��� (1091021005_SC3)*/
	      printf("----------------------------------\n");
	      printf("step 4.5 INSERT INTO policy\n");
	      sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:policy (ipolicy,icard,ixxcard,fassured,iassured,iassured_ext,nassured, "
	                   "ilicense,fsex,fmarriage,nuser,ibenef,nbenef,aassured,aassured_zip,itel,iemail, "
	                   "apayment,apayment_zip,iply_area,nbrand_abbr,ncar_abbr,fcar_note,qcylinder,iengine,ibody, "
	                   "itag,mcar_price,nequipment,pdmg_align,pbrg_align,plia_align,fcal_way,idmg_rate, "
	                   "pdmg_factor,ibrg_rate,pbrg_factor,qpt,fpt,psex_age,psex_age_damage,lia_class,plia_acc,dmg_acc_1st, "
	                   "dmg_acc_2nd,dmg_acc_3rd,pdmg_acc,fhuman,fcomp_24,dbirth,dissue,iextra_charge,iapplicant,napplicant,iroute,iroute_prop,qlia_acc_sum,qdmg_acc_sum, "
	                   "fapplicant,fsex_appl,dbirth_appl,itel_appl,ndeputy_appl,nrelation_appl,ndeputy_assured,  "
	                   "iassured_cntry, iapplicant_cntry, foccup, noccup, applicant_foccup, applicant_noccup, mobil_phone, qpro_month )  "
	                   "VALUES (?,?,?,?,?,?,?, ?,?,?,?,?,?,?,?,?,?, ?,?,?,?,?,?,?,?,?, "
	                   "?,?,?,0,0,0,?,?, ?,?,?,?,?,?,?,?,?,?, ?,?,?,?,?,?,?,?,?,?,?,?,0,0, ?,?,?,?,?,?,?, ?,?,?,?,?,?,?,?)",car_dbnameA );

	      printf("stmt[%s]\n", stmt );
	      $PREPARE Insertply_x3 FROM $stmt;
	      $EXECUTE Insertply_x3 using $ply_num2, $card2, $ixxcard, $fassured, $iassured, $iassured_ext, $nassured,
	                    $ilicense, $fsex, $fmarriage, $nuser, $ibenef, $nbenef, $aassured, $aassured_zip,
	                    $itel, $iemail, $apayment, $apayment_zip, $iply_area, $nbrand_abbr, $ncar_abbr, $fcar_note,
	                    $qcylinder, $iengine, $ibody, $itag, $car_price,$nequipment,$fcal_way, $idmg_rate,
	                    $pdmg_factor,$ibrg_rate, $brg_factor, $qpt, $fpt, $psex_age2, $psex_age_damage, $lia_class, $plia_acc2,
	                    $dmg_acc_1st, $dmg_acc_2nd, $dmg_acc_3rd, $pdmg_acc, "1", "N", $dbirth, $dissue,$iextra_charge,$iapplicant,$napplicant,$iroute,$iroute_prop_A,
	                    $fapplicant,$fsex_appl,$dbirth_appl,$itel_appl,$ndeputy_appl,$nrelation_appl,$ndeputy_assured,
	                    $iassured_cntry, $iapplicant_cntry,$foccup, $noccup, $applicant_foccup, $applicant_noccup, $mobile, $qpro_month;

	      printf(" ------- SQLCODE = [%d]\n " , SQLCODE);

          /* �ˮ֬O�_�������I��a�B��¾�~ add by sylvia 106.08.11 (1060606002_C5) */
          /*printf("������ ply_num2=[%s]foccup=[%s]noccup=[%s]applicant_foccup=[%s]applicant_noccup=[%s]\n",ply_num2,foccup,noccup,applicant_foccup,applicant_noccup);
          if (strcmp(foccup,"Y") == 0)
          {
             * ��a�O *
             if(strcmp(iassured_cntry,"1") == 0)
                strcpy(rba_cty,"Y");
             else
                strcpy(rba_cty,"N");
             
             * �p�~�N�� *
             if(strcmp(noccup," ") == 0)
                strcpy(rba_noccup,"999");
             else
                strcpy(rba_noccup,noccup);
             
             * �Q�O�H�ʽ� *
             if(strcmp(fassured,"5") == 0)
                strcpy(fassured,"1");
             else if (strcmp(fassured,"6") == 0)
                strcpy(fassured,"2");
             
                
             if (strcmp(fsame_one,"Y") == 0)
             {
                rtncode = cm_preview_rba_noisid("3"," ",ply_num2," "," ",iassured,nassured,fassured,dbirth,rba_cty,bzfrom_B,iroute,mdmg_prem+mlia_prem,foccup,rba_noccup,fHiRBA);
             }
             else
                rtncode = cm_preview_rba_noisid("2"," ",ply_num2," "," ",iassured,nassured,fassured,dbirth,rba_cty,bzfrom_B,iroute,mdmg_prem+mlia_prem,foccup,rba_noccup,fHiRBA);
            
            
            printf("---- 2979 rba_cty=[%s]rba_noccup=[%s]fHiRBA=[%s]---- \n",rba_cty,rba_noccup,fHiRBA);
          }
          
          if ((strcmp(applicant_foccup,"Y") == 0) && (strcmp(fsame_one,"N") == 0))
          {
             * ��a�O *
             if(strcmp(iapplicant_cntry,"1") == 0)
                strcpy(rba_cty,"Y");
             else
                strcpy(rba_cty,"N");
             
             * �p�~�N�� *
             if(strcmp(applicant_noccup," ") == 0)
                strcpy(rba_noccup,"999");
             else
                strcpy(rba_noccup,applicant_noccup);
                
             * �n�O�H�ʽ� *
             if(strcmp(fapplicant,"5") == 0)
                strcpy(fapplicant,"1");
             else if (strcmp(fapplicant,"6") == 0)
                strcpy(fapplicant,"2");
                
             rtncode = cm_preview_rba_noisid("1"," ",ply_num2," "," ",iapplicant,napplicant,fapplicant,dbirth_appl,rba_cty,bzfrom_B,iroute,mdmg_prem+mlia_prem,applicant_foccup,rba_noccup,fHiRBA);
             
             printf("---- 2998 rba_cty=[%s]rba_noccup=[%s]fHiRBA=[%s]---- \n",rba_cty,rba_noccup,fHiRBA);
          }*/

	      strcpy(fstatus,"1");

	      sprintf_s(stmt, sizeof stmt,"UPDATE %s:card SET fstatus=?,ialter=?,dalter=?,ipolicy=? WHERE icard = '%s'", car_dbnameB, card2 );

	      printf("stmt[%s]\n", stmt );
	      $PREPARE k2 FROM $stmt;
	      $EXECUTE k2 USING $fstatus,$ientry_A,$Today,$ply_num2;




	      /* 102.03 ��s cm_pre_receive ���A */
	      /* $EXECUTE prep_upd_receive using $ply_num2, $card2, $iestimateB; */
	      /* �t�X�ഫN�g��,���car301�X��ɦ^���@�γ������ɸg��H���������  modify by sylvia 103.11.04 */
	      if (strncmp(iofficer,"N",1) == 0)
	      {
	         strcpy(sFcommit,"1");
	         /* $EXECUTE prep_upd2_receive using $ply_num2, $card2, $iofficer, $sIleader2, $sIquota2, $icomm_obj_B, $iroute, $sFcommit,
	                                          $ftype_pol, $ftype_sp, $dply_begin_a, $dply_end_a, $iestimateB; */
	      }
	      else
	      {
	         strcpy(sFcommit,"N");
	         /* $EXECUTE prep_upd_receive using $ply_num2, $card2, $sFcommit, $ftype_pol, $ftype_sp, $dply_begin_a, $dply_end_a, $iestimateB; */
	      }

	      if (strcmp(ftype_sp,"PA") == 0)
	      {
	         strcpy(sPaydate,dply_begin_a);
	      }
	      else
	      {
	         strcpy(sPaydate,"");
	      }
	      printf("----- 840 ftype_pol=[%s]ftype_sp=[%s]-----\n",ftype_pol,ftype_sp);

	      $EXECUTE prep_upd2_receive using $ply_num2, $card2, $iofficer, $sIleader2, $sIquota2, $icomm_obj_B, $iroute, $sFcommit,
	                                          $ftype_pol, $ftype_sp, $dply_begin_a, $dply_end_a, $sPaydate, $iestimateB;


	      /* ��GA���e�O�渹���@B�̡A�N�����p���� */
	      strcpy( last_ply_A1 , trim(last_ply_A1));
	      strcpy( ipolicyB    , trim(ipolicyB));
	      if( strcmp(last_ply_A1,ipolicyB) == 0 )
	      {
	      	 sprintf_s(stmt, sizeof stmt, "UPDATE %s:ply_relation SET ilast_ply = ' ' WHERE ipolicy = '%s'",car_dbnameA , ipolicyA );
	      	 printf("stmt[%s]\n", stmt );
	      	 $PREPARE upd_lastply FROM $stmt;
	      	 $EXECUTE upd_lastply;
	      }
	printf("----- 2817 ftype_pol=[%s]ftype_sp=[%s]-----\n",ftype_pol,ftype_sp);
	      /** �w�X�槹���A�̷s��O����g�J��O�渹��� **/
	      sprintf_s(stmt, sizeof stmt,
	             " EXECUTE PROCEDURE %s:update_ilast_ply('%s') ",car_dbnameA,ply_num2);
	      $PREPARE up_stor_1 FROM $stmt;
	      $EXECUTE up_stor_1 INTO $i_rtn;


	      /* update_ilast_ply() �|�\�� inext_ply ,����̫�update */
	      /** Step 4.6 �^�g card �ɡBply_relation ��O�渹 **/
	      /* 101.08.15 fix �Ĥ@�~�S��B��̡A���ݭn update "�eB��" �� inext_ply (�ƹ�W�]�S���eB��) */
		  if(flg_NoPolicyB !='Y'){
	          sprintf_s(stmt, sizeof stmt,"UPDATE %s:ply_relation SET inext_ply = '%s' WHERE ipolicy = '%s'",car_dbnameB, ply_num2, ipolicyB );
		      printf("stmt[%s]\n",stmt);
		      $PREPARE Updnext_ply FROM $stmt;
		      $EXECUTE Updnext_ply;
		      printf("Updnext_ply SQLCODE = [%d]\n " , SQLCODE);
		      printf("Updnext_ply sqlca.sqlerrd[2] = [%d] \n",  sqlca.sqlerrd[2]);


	      }

	      /* �t�X�ѵs�I����,B��n��ilast_ply�H����B��^�� add by sylvia 103.08.06 */
	      if (strlen(explicyb) > 13)
	      {
		      sprintf_s(stmt, sizeof stmt,"UPDATE %s:ply_relation SET ilast_ply = '%s' WHERE ipolicy = '%s'",car_dbnameB,explicyb, ply_num2);
		      printf("2606stmt[%s]\n",stmt);
		      $PREPARE Upilast_ply FROM $stmt;
		      $EXECUTE Upilast_ply;
		      printf("Upilast_ply SQLCODE = [%d]\n " , SQLCODE);
		      printf("Upilast_ply sqlca.sqlerrd[2] = [%d] \n",  sqlca.sqlerrd[2]);
         }
	      $INSERT INTO CAR330_TEMP VALUES
	      ($iofficer,$off_name,$ibig_office,$big_name,$ply_num2,
	       $dply_begin_a,$dply_end_a,$iengine,$itag,$nassured,
	       $s_mins_prem,'',$iapplicant,$napplicant,$card2,$iassured_cntry,$iapplicant_cntry,
	       $foccup, $noccup, $applicant_foccup, $applicant_noccup);

	       cnt_car330_tmp++;
      }
      ins_cnt++;

   }

   $CLOSE cur_tmp_ply;
   $COMMIT WORK;

   ins_cnt = 0;
   $INSERT INTO CAR330_TEMP1
    SELECT * FROM CAR330_TEMP
     WHERE 1=1;

   return M_CM_OK;

errexit:
    rc = SQLCODE;
    $ROLLBACK WORK;
    return rc;
}
/*--------------------------------------------------------------------*/
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}
/*--------------------------------------------------------------------*/

/* 102.07.01 */
/* static int SetCarAge() */
static int SetCarAge(frate2)
char *frate2;
{
    char   iissue_ymd[12];         /* extend CY/MM to CY/MM/DD */
    char   datestring[16], yy[4], mm[3], dd[3], yy2[4], mm2[3];
    int    yy1,mm1,yy3,mm3;
    long   iissue_date;
    $int   count_x=0;
    $double pdepreciate_year = 0.0;
    $char  v_frate2[4];
    $WHENEVER SQLERROR GOTO errexit;

    printf("trace frate2[%s]\n ",frate2);
    strcpy(v_frate2,frate2);

    printf("SetCarAge start\n");
    /*** STEP 7.2 -- a. ; here we calculate car_age, year_dep ...etc.  ***/

    /*** STEP 7.2.1 -- b. ***/
    cm_long_split_3ymd(dissue,yy,mm,dd);   /* Date(long)�ন����~�B��B��(yyy,mm,dd) */
    sprintf_s(iissue_ymd, sizeof iissue_ymd,"%s/%s/01",yy,mm);
    iissue_date=cm_ymd_cdate(iissue_ymd);

    yy3=atoi(yy);
    mm3=atoi(mm);

    car_age=DiffMonth(ply2_begin,iissue_date);
    car_age_mth=car_age % 12;

    /** STEP 7.2.2 for flag_new **/
    strcpy(datestring,cm_cdate_str_100(ply2_begin));
    cm_split_ymd(datestring,yy,mm,dd);
    yy1=atoi(yy);
    int_ply_yr=yy1+1911; /* int_ply_yr for iins_type 11 */
    mm1=atoi(mm);

    printf("trace icar_type_1[%s]\n ",icar_type_1);
    /*** STEP 7.2.3 �~���� ***/
    /* 102.07.01, ���o�Ө��ؤ� "�~���²v", ��� car116�]�w */
    /* 108.02.11 �w���ƫ����W�[P/Q���� add by 061476(1071226006_SC9) */
    if (fProvision_P[0]=='Y')
    {
    	$SELECT a.pdepreciate/100.0 Into $pdepreciate_year
    	   FROM depreciation_rate a
    	  WHERE a.fcar_class = '6'
    	    AND a.qperiod_end = 12
    	    AND a.drate = (SELECT drate FROM ca_rate_date
    	                    WHERE itable = 'depreciation_rate' AND icode = $v_frate2);
    }
    else if (fProvision_Q[0]=='Y')
    {
    	$SELECT a.pdepreciate/100.0 Into $pdepreciate_year
    	   FROM depreciation_rate a
    	  WHERE a.fcar_class = '7'
    	    AND a.qperiod_end = 12
    	    AND a.drate = (SELECT drate FROM ca_rate_date
    	                    WHERE itable = 'depreciation_rate' AND icode = $v_frate2);
    }
    else
    {
    	$SELECT a.pdepreciate/100.0 Into $pdepreciate_year
    	   FROM depreciation_rate a ,car_type b
    	  WHERE a.fcar_class =
    	        ( CASE WHEN b.icar_grp = '1' then '3'
    	          ELSE b.fcar_class END )
    	    AND b.fclass = '1' AND b.icode =  $icar_type_1
    	    AND a.qperiod_end = 12
    	    AND a.drate = (SELECT drate FROM ca_rate_date
    	                    WHERE itable = 'depreciation_rate' AND icode = $v_frate2);
    }
    
    printf("trace SQLCODE[%d]\n ",SQLCODE);
    if (SQLCODE==SQLNOTFOUND) return M_CA_NDEPRE_RATE;
    printf("trace pdepreciate_year[%f]\n ",pdepreciate_year);
    
    pdep_rate_year = pdepreciate_year;
    year_dep = MyPower(1-pdepreciate_year, car_age/12);
    /*
    if (fcar_class2[0]=='1') * �ۥΨ� *
        year_dep=MyPower(0.75, car_age/12);
    else
        year_dep=MyPower(0.70, car_age/12);
    */
    printf("########## car_age[%d] car_age_mth[%d]\n",car_age,car_age_mth);
    printf("########## fcar_class2[%s] year_dep[%f]\n",fcar_class2,year_dep);

    /*** SETP 7.2.4 ����� ***/
    if (car_age_mth==0)
    {
        pdepreciate=0;
    }
    else
    {
    	if (fProvision_P[0]=='Y')
    	{
    		$SELECT MAX(a.pdepreciate), count(*)
    		   INTO $pdepreciate, $count_x
    		   FROM depreciation_rate a ,car_type b
    		  WHERE a.fcar_class = '6'
    		    AND b.fclass = '1' AND b.icode = $icar_type_1
    		    AND a.qperiod_end >= $car_age_mth AND a.qperiod_bgn < $car_age_mth
    		    AND a.drate = (SELECT drate FROM ca_rate_date
    		                    WHERE itable = 'depreciation_rate' AND icode = $v_frate2 ) ;
    		
    	}
    	else if (fProvision_Q[0]=='Y')
    	{
    		$SELECT MAX(a.pdepreciate), count(*)
    		   INTO $pdepreciate, $count_x
    		   FROM depreciation_rate a ,car_type b
    		  WHERE a.fcar_class = '7'
    		    AND b.fclass = '1' AND b.icode = $icar_type_1
    		    AND a.qperiod_end >= $car_age_mth AND a.qperiod_bgn < $car_age_mth
    		    AND a.drate = (SELECT drate FROM ca_rate_date
    		                    WHERE itable = 'depreciation_rate' AND icode = $v_frate2 ) ;
    	}
    	else
    	{
    		/*102.07.01 ����²v�G*/
    		$SELECT MAX(a.pdepreciate), count(*)
    		   INTO $pdepreciate, $count_x
    		   FROM depreciation_rate a ,car_type b
    		  WHERE a.fcar_class =
    		        ( CASE WHEN b.icar_grp = '1' then  '3'
    		          ELSE b.fcar_class END )
    		    AND b.fclass = '1' AND b.icode = $icar_type_1
    		    AND a.qperiod_end >= $car_age_mth AND a.qperiod_bgn < $car_age_mth
    		    AND a.drate = (SELECT drate FROM ca_rate_date
    		                    WHERE itable = 'depreciation_rate' AND icode = $v_frate2 ) ;
    	}
                        
	/*
        $SELECT MAX(pdepreciate), count(*)
           INTO $pdepreciate, $count_x
           FROM depreciation_rate, car_type
          WHERE depreciation_rate.fcar_class=car_type.fcar_class
            AND fclass='1' AND icode=$icar_type
            AND qperiod_end>=$car_age_mth AND qperiod_bgn<$car_age_mth;
        */
        if (count_x == 0)  return M_CA_NDEPRE_RATE;
        pdepreciate=pdepreciate/100.0;
    }

    /*** SETP 7.2.5 �p��O�I���B�B����«᪺�O�I���B ***/
    printf("########## year_dep[%f] pdepreciate[%f]\n",year_dep,pdepreciate);
    printf("car_price*10000*year_dep*(1-pdepreciate)\n");
    printf("trace car_price[%f]\n ",car_price);

    /* cover_01_tmp = car_price*10000.0*year_dep*(1.0-pdepreciate); */
    /* cover_01_tmp = (long)d45(car_price*10000.0*year_dep*(1.0-pdepreciate),0); *//*�t�X�e�u�ק� modify by sylvia 104.06.16*/
    cover_01_tmp = (long)floor(car_price*10000.0*year_dep*(1.0-pdepreciate)+0.000000001); /* �t�X�e�u�h�W�[�j���i�� modify by 061476 107.11.26 (1061205001_SC3) */
    printf("trace cover_01_tmp[%ld]\n ",cover_01_tmp);
    thousand_cover_01 = cover_01_tmp % 1000;
    printf("trace thousand_cover_01[%ld]\n ",thousand_cover_01);
    if (thousand_cover_01 != 0)
    {
        cover_01 = (cover_01_tmp)-(thousand_cover_01);
        cover_01_11 = cover_01_tmp - thousand_cover_01;
    }
    else
    {
        cover_01 = cover_01_tmp;
        cover_01_11 = cover_01_tmp;
    }
    printf("########## cover_01[%d] cover_01_11[%d]   \n",cover_01, cover_01_11);


    return SUCCESS;

errexit:
    return FAIL;
}

/*--------------------------------------------------------------------*/
static int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
    short mdy1[3], mdy2[3];
    int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
    return datediff;
}

/*--------------------------------------------------------------------*/
double MyPower(f1, i1)
double f1;
int i1;
{
    int i;
    double ff=1.0;

    for (i=0; i<i1; i++)
    {
        ff=ff*f1;
    }
    return ff;
}

/*--------------------------------------------------------------------*/
double dbl_len8(fulldbl)
double fulldbl;
{

     int chk_flag;
     if (fulldbl < 0)
          chk_flag = 1;
     else
          chk_flag = 0;

     fulldbl = fabs(fulldbl);

     fulldbl = (floor(fulldbl*pow(10,8)))/pow(10,8);

     if (chk_flag == 1)
         return -1 * fulldbl;
     else
         return fulldbl;
}
/*--------------------------------------------------------------------*/
void car330_title()
{

   rgu_put_head_string(1," ");
   rgu_put_head_string(1," ");
   rgu_put_head();

}
/*--------------------------------------------------------------------*/
long lGetOneYearDays(lDate)
long lDate;
{
     short mdy[3];
     long  lLastYearDate, lOneYearDays, lRtnCode;

     printf("---lGetOneYearDays-----This Year [%s]\n", cm_edate_str(lDate));

     if (rjulmdy(lDate, mdy) != 0) return 365;

     mdy[2]--;

     if (mdy[0] == 2 && mdy[1] == 29) mdy[1] = 28;

     if (rmdyjul(mdy, &lLastYearDate) != 0) return 365;
     lOneYearDays = lDate - lLastYearDate;

     printf("---lGetOneYearDays-----Last Year [%s]\n", cm_edate_str(lLastYearDate));
     printf("---lGetOneYearDays-----Days [%d]\n", lOneYearDays);

     return lOneYearDays;
}
/*--------------------------------------------------------------------*/
long get_ca_promote()
{
   int iTmp;
   char sTmp[11];

   $whenever sqlerror goto errexit;

   printf("===== start  get_ca_promote \n");
   printf("===== pro_no [%s] \n", pro_no );

   $SELECT iprmt, nprmt, iremark, trim(iagent), iofficer_1, lofficer,
           ioff_chk_bgn, ioff_chk_len, ioff_chk, mlimit, fanother,
           iofficera_1, lofficera , ioff_chk_bgna, ioff_chk_lena, ioff_chka,
           iins_type
      INTO $iprmt, $nprmt, $iremark, $iagent, $iofficer_1, $iofficer_len,
           $ioff_ck_bgn, $ioff_ck_len, $ioff_chk, $mlimit, $fanother,
           $iofficera_1, $lofficera , $ioff_chk_bgna, $ioff_chk_lena, $ioff_chka,
           $iins_list
      FROM ca_promote
     WHERE iprmt = $pro_no;

   printf("!!!iins_list=[%s]\n", iins_list);
   strcpy(iins_list,trim(iins_list));
   if(SQLCODE != SQLNOTFOUND )
   {
      strcpy(ioff_chk, trim(ioff_chk));
      ioff_ck_end = ioff_ck_bgn + ioff_ck_len -1;

      strcpy( iofficer_1, trim(iofficer_1));
      printf("===== finish get_ca_promote \n");

      if( fanother[0] == 'Y' )
      {
          ioff_ch_enda = ioff_chk_bgna + ioff_chk_lena -1;
          strcpy( iofficera_1, trim(iofficera_1));
      }
      else
          ioff_ch_enda=0;

      printf("iagent[%s]\n", iagent);

      strcpy( str_iagent, "(" );
      for( iTmp=0; iTmp < 10 ; iTmp++)
      {
          if( iagent[iTmp] == ',')
          {
              strcat( str_iagent, ",");
          }
          else if( iagent[iTmp] != '\0' && iagent[iTmp] != ' ' )
          {

              strcat( str_iagent, "'" );

              sTmp[0] = iagent[iTmp];
              sTmp[1] = '\0';

              strcat( str_iagent, sTmp);
              strcat( str_iagent, "'" );

              printf("iTmp[%d], str_iagent[%s]\n", iTmp, str_iagent);
          }
      }
      strcat( str_iagent, ")" );

      printf("str_iagent[%s]\n", str_iagent);

      return M_CM_OK;
   }

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);
}

int Cal_ins_premium(INS_ptr)
struct INS_TYPE *INS_ptr;
{
    int     code, flag_car, flag_dam;
    $char   stmt[1024];
    $char   fcal_way[2], fins_grp[2], ical_ins[INSURANCE_TYPE];

    $char   isame_ins[INSURANCE_TYPE], fcal_class[2];
    $char   frate[4];
    $char   fagent[2];
    $char   FullDBName_rel[20];
    $char   Tmp_policy1[21];
    $char   Tmp_xxcard[21];
    $char   Tmp_policy2[21];
    $char   FullDBName_xxcard[21];
    $char   iins_scope_tmp[2], icareer_tmp[2];

    $date   max_drate=DATENULL;
    $long   drate_long;
    char    TMP_MSG[200];

    long    org_ins_premium;
    long    pprice;
    double  fprice;

    long    lMins_amt_33;
    $long   lMins_amt_48;
    $long   lMins_amt_35;

    $double wk_qpt;
    $double cal_pagent,cal_pcommission,cal_pdiscount;
    $double lTmp_mbusiness;
    $long   cal_prem;
    $double prate_icareer, prate_add_med;
    $char   icar_series[3];

    $char   tmp_ipaid_base[3], ibroker_24[11];

    $long   prem_47_2; /** 47�I�زĤG�~�`�O�O **/

    /* �p��j��s�O�O */
    $char    car_type_24[3], fassured_24[2], drate_ym_24[5];
    $date    dply_begin_24 , dply_end_24;
    $long    qply_period_24;
    $char    ipro_year_24[5], ibrand_24[9];
    $double  qpt_24, psex_age_24, plia_acc_24;
    $char    fcar_class_24[2];
    $char    fuse_type_24[2];

    $long    LngDummy_24 = 0;
    $double  DblDummy_24 = 0.00;
    $double  mbusiness_24 = 0.00;
    $char    StrDummy_24[2];
    $long    Tmp_mlia_prem;

    $long    LngMexpensePrem;    /* ���[�N�B��ñ��O�O */
    $long    LngMexpensePremOri; /* ���[�N�B���W���O�O */
    $long    LngMexpenseDisc;    /* ���[�N�B���u�f�O�O */
    $long    LngQday;

    $double  prate_dailypay, prate_mprem;
    $long    lDaily_pay_33, lDaily_pay_48;
    char     cal_deduct_c[21];
    $char    cal_itype_disc[2];
    double   cal_mdiscount;
    double   t_car_price, t_mcar_price;

    char     CompanyId[3];
    $long    mdeduct_33;
    $char    max_rate[6];
    long     lChk_12_prem;
    $char    tmp_provision[22];
    
    $double  provision_P = 1.0;
    $double  provision_Q = 1.0;

    printf("\n\n\n################################################################ \n");
    printf("################################################################ \n");
    printf("INTO Cal_ins_prem()\n");

    mdmg_prem       = mlia_prem       = 0;
    mdmg_pure_prem  = mlia_pure_prem  = 0;
    mdmg_discount   = mlia_discount   = 0;
    mdmg_agent      = mdmg_commission = 0;
    mlia_agent      = mlia_commission = 0;
    premium_3132    = 0;
    damage_cover_01 = 0;
    flag_car        = 0;
    disc_last       = 0;

    rc = getCompanyId(CompanyId);
    if (rc < 0)
        return rc;

    /*
    if (*fuse_type=='1') *** �ȳf��ε��O 1:�O 2:�_ ***
    {
        if (strcmp(fcar_note2,"98")==0)     *** 98:�f�� ***
             strcpy(cal_car_id,"04");
        else if(strcmp(fcar_note2,"99")==0) *** 99:�Ȩ� ***
             strcpy(cal_car_id,"03");
    }
    */

    strcpy(cal_car_id, icar_type );
    printf("Cal_ins_prem()####### �p�⨮�� cal_car_id[%s]\n",cal_car_id);

    /********** Scan through every iins_type ****************/
    INS_ptr      = Ifirst;
    bef_premium  = 0;
    pure_premium = 0;

    while (INS_ptr)
    {
        printf("\n\n\nCal_ins_prem()####### ------- IINS_TYPE [%s]\n",INS_ptr->ins_type);

        if (memcmp(trim(INS_ptr->ins_type),"**",2)==0)
        {
            INS_ptr = INS_ptr->next;
            continue;
        }
		
		
		if((memcmp(trim(INS_ptr->ins_type),"11",2)==0) && (strncmp(ibrand+6, "01", 2) == 0))
		{
			printf("!!!Electric Car with iins 11, next!!!\n");
			INS_ptr = INS_ptr->next;
            continue;
		}
		else if((memcmp(trim(INS_ptr->ins_type),"211",3)==0) && (strncmp(ibrand+6, "01", 2) != 0))
		{
			printf("!!!Non Electric Car with iins 211, next!!!\n");
			INS_ptr = INS_ptr->next;
            continue;
		}
		
        strcpy(ins_type , trim(INS_ptr->ins_type));
        strcpy(cal_itype_disc, trim(INS_ptr->itype_disc));

        iins            = atoi(rtrim(ins_type));
        cal_deduct      = 0;
        cal_deduct      = INS_ptr->deduct;

        if( iins == 11  )
        {
            cal_deduct = 10;
            INS_ptr->deduct = 10;
        }

        switch(iins)
        {
            case 11: case 211:
                cal_deduct = 10;
                INS_ptr->deduct = 10;
                break;
            case 14: case 17:
                cal_deduct = 0;
                INS_ptr->deduct = 0;
                break;
            default:
                break;
        }

        printf("cal_deduct = [%d]\n", cal_deduct );

        org_ins_premium = INS_ptr->ins_premium;  /* �O�����`�O�O */
/*
        strcpy(tmp_ipaid_base    , trim(INS_ptr->ipaid_base));
        strcpy(tmp_provision     , trim(INS_ptr->provision));
*/
        strcpy(frate,INS_ptr->frate);
        strcpy(frate,trim(frate));

        /*-------------------------------------------------------------------*/
        /*** �O�O�p���k[fcal_way] : 1�O�v��   2�O�B�O�O��                ***/
        /*** �ۭt�B�O[fdeduct]      : 1���ۭt�B 0�L�ۭt�B                  ***/
        /*** �l���d���O[fins_grp]   : 1���l�I   2���d�I   3�j��d���I      ***/
        /*** �P�I�N��[isame_ins] , �C�L�Ǹ�[qserial] , �O�B�Ӽ�[qcoverage] ***/
        /*-------------------------------------------------------------------*/
        $SELECT fcal_way,  isame_ins,  qserial,  qcoverage,  fdeduct,  fins_grp
           INTO $fcal_way, $isame_ins, $qserial, $qcoverage, $fdeduct, $fins_grp
           FROM insurance_type
          WHERE iins_type = $ins_type;
        if (NOT_FOUND)  return M_CA_NINS_TYPE;

        printf("fcal_way[%s],ins_type[%s] \n",fcal_way,ins_type);
        printf("cal_deduct[%d] ���N�I�O�v�ͮĥN��==>frate[%s]\n",cal_deduct,frate);
        printf("�쨮��mcar_price[%lf],�s�ʨ���car_price[%lf]\n",mcar_price,car_price);

        /* 990208, �������[����,�۶O��̳Q�O�I�HID�B�M�ץ�̭n�O�HID���o�«O�O�W����*/
        /* 980520, �j�v���[����,�̭n�O�HID���o�«O�O�W���� */
        if(IsProvision)
        {
            /* �M�ץ󤣦A�p��F���� modify by sylvia 104.11.09 (1041020003_C3) */
        	/* if (sProvisionType[0]=='B' || sProvisionType[0]=='F'){
	            rc = get_ca_id_officer( iapplicant, officer2, car_typei2, ins_type, cm_edate_str(ply2_begin)," ",
	                                    &INS_ptr->irate, &INS_ptr->adjust_rate, v_sMsg);
	            if( rc != M_CM_OK) return rc;

	            plia_acc2 = 0;
            }else{ */
	            plia_acc2 = plia_acc2_ori;
	            INS_ptr->irate = 0;
	            INS_ptr->adjust_rate = 0;
            /* } */
        }else{
            plia_acc2 = plia_acc2_ori;
            INS_ptr->irate = 0;
            INS_ptr->adjust_rate = 0;
        }

        /*�j��s,�u���b���ӫO24�I�خɤ~���p�� premium1_24*/
        premium1_24=0;

        printf("�j��s premium1_24[%ld]\n",premium1_24);

        if (iins == 12) /*** �s��Q�ѷl���I ***/
        {
            INS_ptr->injured_cover = 0;
            INS_ptr->death_cover   = 0;
            INS_ptr->damage_cover  = 0;
            INS_ptr->deduct        = 0;
            cal_deduct             = INS_ptr->deduct;

            /* �s��Q�ѷl���I�̨��t�M�w�O�I�O */
            $SELECT icar_series
               INTO $icar_series
               FROM ca_car_model
              WHERE ibrand    = $brandi
                AND ipro_year = $ipro_year
                AND drate     = (SELECT drate
                                   FROM ca_rate_date
                                  WHERE icode  = $frate
                                    AND itable = 'ca_car_model');
            if (NOT_FOUND)
            {
                  $SELECT icar_series
                     INTO $icar_series
                     FROM ca_car_model
                    WHERE ibrand    = $brandi
                      AND ipro_year = (SELECT MAX(ipro_year)
                                         FROM ca_car_model
                                        WHERE ibrand = $brandi)
                      AND drate     = (SELECT drate
                                         FROM ca_rate_date
                                        WHERE icode  = $frate
                                          AND itable = 'ca_car_model');
                  if (NOT_FOUND)  return M_CA_NBRAND;
            }

            printf("���t�N��icar_series[%s],cal_deduct[%d]\n",icar_series,cal_deduct);

            $SELECT drate
               INTO $drate_long
               FROM ca_rate_date
              WHERE icode  = $frate
                AND itable = 'ca_rate';
            if (NOT_FOUND)  return M_CA_NRATE_DATE;

            $SELECT prate, pextra_charge/100
               INTO $prate_1, $pextra_charge
               FROM ca_rate
              WHERE icar_type = $icar_series
                AND iins_type = $ins_type
                AND mdeduct   = $cal_deduct
                AND drate     = $drate_long;

            if (NOT_FOUND) return M_CA_NRATE;

            /* 97.11�J�O�v�ۥѤ� */
            if( f980101[0] == '1')
                pextra_charge = INS_ptr->pextra_charge;
            else
                INS_ptr->pextra_charge = pextra_charge;

            prate_1=prate_1/100.0;

            printf("Cal_ins_prem()#######12 �ѵs�I�O�Bpremium_12[%ld] prate_1[%f] series[%s]\n",
                                                      premium_12,     prate_1,    icar_series);

            /*INS_ptr->ins_premium = ((float)premium_12*prate_1);*/   /**** round ****/
            INS_ptr->ins_premium = ((float)premium_12*prate_1) * ( 1 + INS_ptr->deviation_rate/100.0);

            lChk_12_prem = 1000 * (1.0 - pextra_charge);

            if (strcmp(icar_series,"10") == 0)                  /* �s���I�̧C�O�O */
            {
                if (INS_ptr->ins_premium < lChk_12_prem)
                    INS_ptr->ins_premium = lChk_12_prem;
            }
            else
            {
                if (INS_ptr->ins_premium < lChk_12_prem * 2)
                    INS_ptr->ins_premium = lChk_12_prem * 2;
            }
            /* 990903 */
            INS_ptr->mpure_prem_n = INS_ptr->ins_premium;

            INS_ptr->bef_ins_premium = INS_ptr->ins_premium;

            printf("IINS_TYPE:[12] ins_premium[%lf]\n",INS_ptr->ins_premium);

            goto step_9_e_iii;
        }
       /*970708*/

        printf("Cal_ins_prem()###### fcal_way[%s]\n",fcal_way);

        /*** get ���[���ڶO�v ***/
        /* �W�[P/Q���[���ڶO�v add by 061476 108.02.13 (1071226006_SC9) */
        provision_H = 1.0;
        
        if (fProvision_P[0]=='Y')
        {
        	$SELECT coefficient
        	   INTO $provision_P
        	   FROM ca_add_provision
        	  WHERE icar_type = (SELECT fcar_class FROM car_type 
        	                      WHERE fclass = '1' AND icode = $cal_car_id)
        	    AND provision = 'P'
        	    AND iins_type = $ins_type
        	    AND drate     = (SELECT drate
        	                       FROM ca_rate_date
        	                      WHERE icode  = $frate
        	                        AND itable = 'ca_add_provision');
        	                        
        	if (NOT_FOUND) provision_P = 1.0;
        }
        else
        	provision_P = 1.0;
        
        if (fProvision_Q[0]=='Y')
        {
        	$SELECT coefficient
        	   INTO $provision_Q
        	   FROM ca_add_provision
        	  WHERE icar_type = (SELECT fcar_class FROM car_type 
        	                      WHERE fclass = '1' AND icode = $cal_car_id)
        	    AND provision = 'Q'
        	    AND iins_type = $ins_type
        	    AND drate     = (SELECT drate
        	                       FROM ca_rate_date
        	                      WHERE icode  = $frate
        	                        AND itable = 'ca_add_provision');
        	                        
        	 if (NOT_FOUND) provision_Q = 1.0;
        }
        else
        	provision_Q = 1.0;
        

        switch (fcal_way[0])   /***�O�O�p���k 1:�O�v��   2:�O�B�O�O�� ***/
        {
            case '1':   /* fcal_way 1:�O�v�ɭp��O�O */

                  /******* BEGIN:�̶O�v�ɭp��O�O **********/
                  if ((iins==1) || (iins==5) || (iins==9) || (iins==8) || iins==85)
                  {
                      if (strcmp(cal_car_id,"05")==0 ||
                          strcmp(cal_car_id,"06")==0 ||
                          strcmp(cal_car_id,"09")==0 ||
                          strcmp(cal_car_id,"10")==0 ||
                          strcmp(cal_car_id,"20")==0)
                          wk_qpt=qpt;
                      else
                          wk_qpt=0;
                  }
                  else
                      wk_qpt=0;

                  printf("Cal_ins_prem()####### fpt[%s] qpt[%f] wk_qpt[%f] cal_deduct=[%d]\n",fpt,qpt,wk_qpt, cal_deduct);

                  /* get �򥻫O�O,�p��v,�p���I��,������� */
                  if (fpt[0]=='P')
                  {
                      printf("---------------->over here\n");

                      $SELECT drate
                         INTO $drate_long
                         FROM ca_rate_date
                        WHERE icode  = $frate
                          AND itable = 'ca_rate';
                      if (NOT_FOUND)  return M_CA_NRATE_DATE;

                      printf("===================>over here\n");

                      $SELECT prate, mprem, ical_ins, fcal_class, pextra_charge/100
                         INTO $prate_1, $mprem, $ical_ins, $fcal_class, $pextra_charge
                         FROM ca_rate
                        WHERE icar_type = $cal_car_id
                          AND iins_type = $ins_type
                          AND mdeduct   = $cal_deduct
                          AND qpt_bgn  <= $wk_qpt
                          AND qpt_end  >= $wk_qpt
                          AND drate     = $drate_long;

                      printf("0010:cal_car_id[%s],ins_type[%s],cal_deduct[%d],SQLCODE[%d]\n",
                                   cal_car_id,    ins_type,    cal_deduct,    SQLCODE);
                  }
                  else
                  {
                      if ((strcmp(cal_car_id,"06")==0 ||
                           strcmp(cal_car_id,"10")==0 ||
                           strcmp(cal_car_id,"20")==0 )
                           && (iins==1 || iins==5) )
                      {
                          printf("SELECT prate_1...frate[%s]\n",frate);

                          $SELECT drate
                             INTO $drate_long
                             FROM ca_rate_date
                            WHERE icode=$frate
                              AND itable='ca_rate';
                          if (NOT_FOUND)  return M_CA_NRATE_DATE;

                          $SELECT prate, mprem, ical_ins, fcal_class, pextra_charge/100
                             INTO $prate_1, $mprem, $ical_ins, $fcal_class, $pextra_charge
                             FROM ca_rate
                            WHERE icar_type = $cal_car_id
                              AND iins_type = $ins_type
                              AND mdeduct   = $cal_deduct
                              AND qpt_bgn   < $wk_qpt
                              AND qpt_end  >= $wk_qpt
                              AND drate     = $drate_long;
                      }
                      else
                      {
                          $SELECT drate
                             INTO $drate_long
                             FROM ca_rate_date
                            WHERE icode  = $frate
                              AND itable = 'ca_rate';
                          if (NOT_FOUND)  return M_CA_NRATE_DATE;

                          $SELECT prate   , mprem , ical_ins , fcal_class , pextra_charge/100
                             INTO $prate_1, $mprem, $ical_ins, $fcal_class , $pextra_charge
                             FROM ca_rate
                            WHERE icar_type = $cal_car_id
                              AND iins_type = $ins_type
                              AND mdeduct   = $cal_deduct
                              AND qpt_bgn  <= $wk_qpt
                              AND qpt_end  >= $wk_qpt
                              AND drate     = $drate_long;
                      }
                  }

                  if (NOT_FOUND) return M_CA_NRATE;

                  prate_1=prate_1/100.0;

                  printf("Cal_ins_prem()### iins_type[%d],prate_1[%f]\n",iins,prate_1);

                  /* ical_ins:�p���I��, fcal_class:�O�B�O�O�O */
                  code = Calculate_cover_prem(INS_ptr,ical_ins,fcal_class,iins);
                  if (code != SUCCESS) return code;
                  /******* END:�̶O�v�ɭp��O�O **********/
                  break;

            case '2':    /* fcal_way 2:�O�B�O�O�ɱo��O�O */

                  /******* BEGIN:�̫O�B�O�O�ɭp��O�O **********/
                  /* �ѳ��'��'�אּ���'�d' */
                  injured_cover = INS_ptr->injured_cover;
                  death_cover   = INS_ptr->death_cover;
                  damage_cover  = INS_ptr->damage_cover;

                  printf("Cal_ins_prem():CASE 2  inj[%ld] dea[%ld] dam[%ld]\n", injured_cover, death_cover, damage_cover);

                  if (!IsBlankNull(isame_ins))
                  {   /* 31,32,71,72,29,30 */
                      $SELECT drate
                         INTO $drate_long
                         FROM ca_rate_date
                        WHERE icode=$frate
                          AND itable='cover_vs_premium';
                      if (NOT_FOUND)  return M_CA_NRATE_DATE;

                      if (iins==71 || iins==72)
                      {
                      	 /*
                          $SELECT mpremium, pextra_charge/100
                             INTO $mpremium, $pextra_charge
                             FROM cover_vs_premium
                            WHERE icar_type=$cal_car_id
                              AND iins_type=$ins_type
                              AND mcoverage2=$damage_cover
                              AND drate=$drate_long;  */
                          if (iins==72 && !Scan_INS_TYPE(71))  return M_CA_71;

                          $SELECT mpremium, pextra_charge/100
                             INTO $mpremium, $pextra_charge
                             FROM cover_vs_premium
                            WHERE icar_type=$cal_car_id
                              AND iins_type=$ins_type
                              AND mcoverage2=$damage_cover
                              AND mdeduct = $cal_deduct
                              AND drate=$drate_long;

                      }
                      else if (iins==29 || iins==30)
                      {
                          /**
                          if (iins==30)
                          {
                             if (!Scan_INS_TYPE(31))  return M_CA_INS31;

                             strcpy(cal_deduct_c,itoa(cal_deduct));

                             if (IsFcomp24(cal_deduct_c))
                             {
                                if (!Scan_INS_TYPE(24))  return M_CA_INS24;
                             }

                             if (IsFcomp51(cal_deduct_c))
                             {
                                if (!Scan_INS_TYPE(51))  return M_CA_INS51;
                             }
                          }

                          $SELECT mpremium, pextra_charge/100
                             INTO $mpremium, $pextra_charge
                             FROM cover_vs_premium
                            WHERE icar_type  = $cal_car_id
                              AND iins_type  = $ins_type
                              AND mcoverage2 = $damage_cover
                              AND mdeduct    = $cal_deduct
                              AND drate      = $drate_long;
                          **/

                      }
                      else  /* 31,32 */
                      {
                          printf("Cal_ins_prem()#######3132 ins_tp[%s]\n",ins_type);
                          printf("Cal_ins_prem()#######3132 cal_car_id[%s] inj[%ld] dam[%ld]\n",
                                                            cal_car_id,injured_cover,damage_cover);

                          $SELECT mpremium, pextra_charge/100
                             INTO $mpremium, $pextra_charge
                             FROM cover_vs_premium
                            WHERE icar_type  = $cal_car_id
                              AND iins_type  = $ins_type
                              AND mcoverage1 = $injured_cover
                              AND mcoverage2 = $damage_cover
                              AND drate      = $drate_long;
                      }

                      if (NOT_FOUND)  return M_CA_NCOVER_PREM;

                      printf("Cal_ins_prem()#######iins[%d] mpremium[%lf]\n",iins, mpremium);

                      if (iins==31 || iins==32)
                      {
                          if (fcar_class2[0]=='1')  /* �ۥΨ� */
                          {
                              if (strcmp(cal_car_id,"03")==0 ||
                                  strcmp(cal_car_id,"04")==0 ||
                                  strcmp(cal_car_id,"22")==0)
                              {
                                  if (assuredf[0]=='1' ||
                                      assuredf[0]=='3' ||
                                      assuredf[0]=='5')
                                  {
                                      INS_ptr->ins_premium     = mpremium*(psex_age2+plia_acc2)*short_prate*provision_H;   /* round */
                                      INS_ptr->bef_ins_premium = mpremium*(psex_age2+plia_acc2)*short_prate*provision_H;   /* round */

                                      /* ���s�I�O�O�p���¦ */
                                      premium_3132 = premium_3132 + dbl_len8(mpremium*(psex_age2+plia_acc2)*provision_H);  /* round */
                                  }
                                  else
                                  {
                                      INS_ptr->ins_premium     = mpremium*(1.0+plia_acc2)*short_prate*provision_H;   /* round */
                                      INS_ptr->bef_ins_premium = mpremium*(1.0+plia_acc2)*short_prate*provision_H;   /* round */

                                      /* ���s�I�O�O�p���¦ */
                                      premium_3132 = premium_3132 + dbl_len8(mpremium*(1.0+plia_acc2)*provision_H);  /* round */
                                  }
                              }
                              else
                              {
                                  INS_ptr->ins_premium     = mpremium*(1.0+plia_acc2)*short_prate*provision_H;  /* round */
                                  INS_ptr->bef_ins_premium = mpremium*(1.0+plia_acc2)*short_prate*provision_H;  /* round */

                                  /* ���s�I�O�O�p���¦ */
                                  premium_3132 = premium_3132 + dbl_len8(mpremium*(1.0+plia_acc2)*provision_H); /* round */
                              }
                          }
                          else /** fcar_class2[0]=='2' **/
                          {   /* ��~�� */
                              INS_ptr->ins_premium     = mpremium*(1+plia_acc2)*short_prate*provision_H;  /* round */
                              INS_ptr->bef_ins_premium = mpremium*(1+plia_acc2)*short_prate*provision_H;  /* round */

                              /* ���s�I�O�O�p���¦ */
                              premium_3132 = premium_3132 + dbl_len8(mpremium*(1+plia_acc2)*provision_H);  /* round */
                          }

                          printf("31,32@@@@@ fcar_class2[%s],cal_car_id[%s],assuredf[%s]\n",fcar_class2,cal_car_id,assuredf);
                          printf("31,32@@@@@ ins_premium[%lf]\n",INS_ptr->ins_premium);
                          printf("31,32@@@@@ bef_ins_premium[%lf]\n",INS_ptr->bef_ins_premium);
                          printf("31,32@@@@@ premium_3132[%lf]\n",premium_3132);
                      }
                      else  /* iins != 31,32 */
                      {
                          INS_ptr->ins_premium     = mpremium*short_prate;  /*** round ***/
                          INS_ptr->bef_ins_premium = mpremium*short_prate;  /*** round ***/

                          printf("71,72@@@@@ ins_premium[%lf]\n",INS_ptr->ins_premium);
                      }
                  }
                  else
                  {   /* 14,61,65,68,69,25,51,52,47 */

                      /**************************************************/
                      /*  CKI 25 �I�ت�insurance_type.fcal_way='1'      */
                      /*  means�H�O�v�p��O�O,�ҥH�H�U���޿�w���A��    */
                      /**************************************************/

                      $SELECT drate
                         INTO $drate_long
                         FROM ca_rate_date
                        WHERE icode  = $frate
                          AND itable = 'cover_vs_premium';
                      if (NOT_FOUND)  return M_CA_NRATE_DATE;

                      if (iins==25)   /*** ���ĶO�� ***/
                      {
                          $SELECT mpremium, pextra_charge/100
                             INTO $mpremium, $pextra_charge
                             FROM cover_vs_premium
                            WHERE icar_type  = $cal_car_id
                              AND iins_type  = $ins_type
                              AND mcoverage1 = $injured_cover
                              AND drate      = $drate_long;
                          if (NOT_FOUND)  return M_CA_NCOVER_PREM;

                          printf("25@@@@@ basic prem[%lf] short_prate[%lf]\n",mpremium,short_prate);

                          INS_ptr->ins_premium     = ((float)damage_cover/(float)injured_cover)*mpremium*short_prate; /*** round ***/
                          INS_ptr->bef_ins_premium = ((float)damage_cover/(float)injured_cover)*mpremium*short_prate; /*** round ***/

                      }
                      else if (iins == 14 || iins == 61 || iins == 65 ||
                               iins == 68 || iins == 69 || iins == 19)
                      {
                          /*** 14,61,65,68,69,19 �N���O ***/

                          $SELECT mpremium, pextra_charge/100
                             INTO $mpremium, $pextra_charge
                             FROM cover_vs_premium
                            WHERE icar_type  = $cal_car_id
                              AND iins_type  = $ins_type
                              AND mcoverage2 = $damage_cover
                              AND drate      = $drate_long;
                          if (NOT_FOUND)  return M_CA_NCOVER_PREM;

                          INS_ptr->ins_premium     = mpremium*short_prate;   /*** round ***/
                          INS_ptr->bef_ins_premium = mpremium*short_prate;   /*** round ***/

                      }
                      else if (iins == 15 || iins == 16)
                      {
                          /*** 15,16 �N�B���O�I ***/
                          $SELECT mpremium, pextra_charge/100, mcoverage2/mcoverage1
                             INTO $mpremium, $pextra_charge, $qday
                             FROM cover_vs_premium
                            WHERE icar_type  = $cal_car_id
                              AND iins_type  = $ins_type
                              AND mcoverage1 = $injured_cover
                              AND mcoverage2 = $damage_cover
                              AND drate      = $drate_long;
                          if (NOT_FOUND)  return M_CA_NCOVER_PREM;

                          INS_ptr->ins_premium     = mpremium*short_prate;   /*** round ***/
                          INS_ptr->bef_ins_premium = mpremium*short_prate;   /*** round ***/
                      }
                      else if (iins==62 || iins==63 || iins==64)
                      {
                          printf("INTO 62 damage_cover[%ld],cal_deduct[%ld]\n",damage_cover,cal_deduct);
                          $SELECT mpremium, pextra_charge/100
                             INTO $mpremium, $pextra_charge
                             FROM cover_vs_premium
                            WHERE icar_type  = $cal_car_id
                              AND iins_type  = $ins_type
                              AND mcoverage2 = $damage_cover
                              AND mdeduct    = $cal_deduct
                              AND drate      = $drate_long;

                          INS_ptr->ins_premium     = mpremium*short_prate;   /*** round ***/
                          INS_ptr->bef_ins_premium = mpremium*short_prate;   /*** round ***/
                      }
                      else  /**** �I��:51,47,52 ****/
                      {
			              if (iins==51)
						  {
						      printf("death_cover[%d], damage_cover[%d], car_typei2[%s]\n",
			                                      death_cover, damage_cover, car_typei2);

						      if ((death_cover == damage_cover) &&
						          ((strcmp(car_typei2,"03")==0) || (strcmp(car_typei2,"04")==0) ||
			                                   (strcmp(car_typei2,"19")==0) || (strcmp(car_typei2,"21")==0) ||
			                                   (strcmp(car_typei2,"22")==0)))
						      {
			                                  sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s WHERE %s %s %s %s %s %s %s %s",
			                                               "mpremium, pextra_charge/100 ",
			                                               "cover_vs_premium ",
			                                               "icar_type  = ? ",
			                                               "AND iins_type  = ? ",
			                                               "AND mcoverage1 = ? ",
			                                               "AND mcoverage2 = ? AND mdeduct = 1",
			                                               "AND drate=(SELECT drate ",
			                                               "             FROM ca_rate_date ",
			                                               "            WHERE icode  = ? ",
			                                               "              AND itable = 'cover_vs_premium')");

			                                  printf("stmt[%s]\n", stmt);

			                                  EXEC SQL PREPARE CUR_51_stmta FROM   :stmt;
			                                  EXEC SQL DECLARE cur_51a      CURSOR FOR CUR_51_stmta;
			                                  EXEC SQL OPEN    cur_51a      USING  :cal_car_id , :ins_type ,
			                                                                   :injured_cover , :death_cover , :frate;
			                                  EXEC SQL FETCH   cur_51a INTO :mpremium ,:pextra_charge;
			                                  if (NOT_FOUND)
			                                  {
			                                      printf("M_CA_NCOVER_PREM\n");
			                                      return M_CA_NCOVER_PREM;
			                                  }

			                                  EXEC SQL CLOSE   cur_51a;
			                                  EXEC SQL FREE    cur_51a;
						      }
						      else
						      {
			                                  sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s WHERE %s %s %s %s %s %s %s %s",
			                                               "mpremium, pextra_charge/100 ",
			                                               "cover_vs_premium ",
			                                               "icar_type  = ? ",
			                                               "AND iins_type  = ? ",
			                                               "AND mcoverage1 = ? ",
			                                               "AND mcoverage2 = ? AND mdeduct = 0",
			                                               "AND drate=(SELECT drate ",
			                                               "             FROM ca_rate_date ",
			                                               "            WHERE icode  = ? ",
			                                               "              AND itable = 'cover_vs_premium')");

			                                  EXEC SQL PREPARE CUR_51_stmtb FROM   :stmt;
			                                  EXEC SQL DECLARE cur_51b      CURSOR FOR CUR_51_stmtb;
			                                  EXEC SQL OPEN    cur_51b      USING  :cal_car_id , :ins_type ,
			                                                                   :injured_cover , :death_cover , :frate;
			                                  EXEC SQL FETCH   cur_51b INTO :mpremium ,:pextra_charge;
			                                  if (NOT_FOUND)
			                                      return M_CA_NCOVER_PREM;
			                                  EXEC SQL CLOSE   cur_51b;
			                                  EXEC SQL FREE    cur_51b;
						      }
						  }
						  else
						  {
                               sprintf_s(stmt, sizeof stmt,"SELECT %s FROM %s WHERE %s %s %s %s %s %s %s %s",
                                            "mpremium, pextra_charge/100 ",
                                            "cover_vs_premium ",
                                            "icar_type  = ? ",
                                            "AND iins_type  = ? ",
                                            "AND mcoverage1 = ? ",
                                            "AND mcoverage2 = ? ",
                                            "AND drate=(SELECT drate ",
                                            "             FROM ca_rate_date ",
                                            "            WHERE icode  = ? ",
                                            "              AND itable = 'cover_vs_premium')");

                               EXEC SQL PREPARE CUR_51_stmt FROM   :stmt;
                               EXEC SQL DECLARE cur_51      CURSOR FOR CUR_51_stmt;
                               EXEC SQL OPEN    cur_51      USING  :cal_car_id , :ins_type ,
                                                                   :injured_cover , :death_cover , :frate;
                               EXEC SQL FETCH   cur_51 INTO :mpremium ,:pextra_charge;
                               if (NOT_FOUND)
                                   return M_CA_NCOVER_PREM;
                               EXEC SQL CLOSE   cur_51;
                               EXEC SQL FREE    cur_51;
                          }

                          {
                              if (iins==51)
                              {
                                  if (damage_cover==0)
                                  {
                                      damage_cover=qpassenger*death_cover;

                                      INS_ptr->damage_cover=qpassenger*death_cover;
                                  }
                                  else
                                  {
                                      if (death_cover==0)
                                          return M_CA_51DEATH_COVER_BIG0;

                                      flag_dam = damage_cover % death_cover;
                                      if (flag_dam != 0)
                                          return M_CA_NDEATHCOVER_TIMES;
                                  }
                              }
		                      if (iins==55)
		                      {
		                         if (damage_cover==0)
		                         {
		                             damage_cover=(qpassenger-1)*death_cover;
		                             INS_ptr->damage_cover=(qpassenger-1)*death_cover;
		                             /*  crystal-861107,prevent devied zero */
		                             if (death_cover==0) death_cover=1;
		                         }
		                         else
		                         {
		                             if (death_cover==0)
		                                 return M_CA_NCOVER_PREM;

		                             flag_dam = damage_cover % death_cover;
		                             printf("flag_dam=[%d]\n", flag_dam );
		                             if (flag_dam != 0)
		                                 return M_CA_NCOVER_PREM;
		                         }
		                      }
                              printf("####51,53 frate[%s],car_type[%s],ins_type[%s]\n", frate, cal_car_id, ins_type);

                              printf("####51,53 short_prate[%f] mpremium[%f]\n",short_prate,mpremium);
                              printf("####51,53 injure [%d] death[%d] damage[%d]\n",injured_cover,death_cover,damage_cover);
                              printf("####51,53 (damage/death)*mpremium*short_prate\n");

                              if (iins!=47)
                              {
                                   INS_ptr->ins_premium     = ((float)damage_cover/(float)death_cover)*mpremium*short_prate; /* round */
                                   INS_ptr->bef_ins_premium = ((float)damage_cover/(float)death_cover)*mpremium*short_prate; /* round */
                                   printf("iins[%d]@@@@@ ins_premium[%lf]\n",iins,INS_ptr->ins_premium);
                              }
                              else /* iins==47 */
                              {
                                   /**** 47:�����j���I���[�r�p�H�ˮ`�O�I ***/
                                   /* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
                                   /*INS_ptr->ins_premium     = (long)(mpremium*short_prate+0.5);
                                   INS_ptr->bef_ins_premium = (long)(mpremium*short_prate+0.5);

                                   INS_ptr->pure_ins_premium = (long)((float)(349.0)*short_prate+0.5);*/
                                   
                                   INS_ptr->ins_premium     = (long)(d45((mpremium*short_prate),0));
                                   INS_ptr->bef_ins_premium = (long)(d45((mpremium*short_prate),0));

                                   INS_ptr->pure_ins_premium = (long)(d45((349.0 * short_prate),0));

                                   if (iSecondYear2 > 0)
                                   {
                                        if ((iSecondYear2 == 12) &&
                                            (strcmp(sTmpmmB, sTmpmmE) == 0) &&
                                            (strcmp(sTmpddB, sTmpddE) == 0))
                                        {
                                            prem_47_2 = 349;

                                            INS_ptr->pure_ins_premium += (prem_47_2);
                                            
                                            /* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
                                            /* INS_ptr->ins_premium     += (long)(((349.0+75.0)/(1-0.03+0.01458))*(1/(1+0.06))+0.5);
                                            INS_ptr->bef_ins_premium += (long)(((349.0+75.0)/(1-0.03+0.01458))*(1/(1+0.06))+0.5); */
                                            INS_ptr->ins_premium     += (long)(d45((((349.0+75.0)/(1-0.03+0.01458))*(1/(1+0.06))),0));
                                            INS_ptr->bef_ins_premium += (long)(d45((((349.0+75.0)/(1-0.03+0.01458))*(1/(1+0.06))),0));
                                        }
                                        else if (strcmp(sTmpddB, sTmpddE) == 0)
                                        {
                                            /* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
                                            /* prem_47_2 = ((349.0)/(1-0.03+0.01458))*((iSecondYear2+0.5)/12)*(1/(1+0.06))+0.5;*/
                                            prem_47_2 = d45(((349.0/(1-0.03+0.01458))*((iSecondYear2+0.5)/12)*(1/(1+0.06))),0);

                                            INS_ptr->pure_ins_premium += (prem_47_2);
                                            
                                            /* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
                                            /* INS_ptr->ins_premium     += (long)(((349.0+75.0)/(1-0.03+0.01458))*((iSecondYear2+0.5)/12)*(1/(1+0.06))+0.5);
                                               INS_ptr->bef_ins_premium += (long)(((349.0+75.0)/(1-0.03+0.01458))*((iSecondYear2+0.5)/12)*(1/(1+0.06))+0.5); */
                                            INS_ptr->ins_premium     += (long)(d45((((349.0+75.0)/(1-0.03+0.01458))*((iSecondYear2+0.5)/12)*(1/(1+0.06))),0));
                                            INS_ptr->bef_ins_premium += (long)(d45((((349.0+75.0)/(1-0.03+0.01458))*((iSecondYear2+0.5)/12)*(1/(1+0.06))),0));
                                        }
                                        else
                                        {
                                            /* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
                                            /* prem_47_2 = ((349.0)/(1-0.03+0.01458))*((iSecondYear2-0.5)/12)*(1/(1+0.06))+0.5; */
                                            prem_47_2 = d45(((349.0 /(1-0.03+0.01458))*((iSecondYear2-0.5)/12)*(1/(1+0.06))),0);

                                            INS_ptr->pure_ins_premium += (prem_47_2);
                                            
                                            /* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
                                            /*INS_ptr->ins_premium     += (long)(((349.0+75.0)/(1-0.03+0.01458))*((iSecondYear2-0.5)/12)*(1/(1+0.06))+0.5);
                                              INS_ptr->bef_ins_premium += (long)(((349.0+75.0)/(1-0.03+0.01458))*((iSecondYear2-0.5)/12)*(1/(1+0.06))+0.5); */
                                            INS_ptr->ins_premium     += (long)(d45((((349.0+75.0)/(1-0.03+0.01458))*((iSecondYear2-0.5)/12)*(1/(1+0.06))),0));
                                            INS_ptr->bef_ins_premium += (long)(d45((((349.0+75.0)/(1-0.03+0.01458))*((iSecondYear2-0.5)/12)*(1/(1+0.06))),0));
                                        }
                                   }
                                   printf("iins[%d],ins_premium[%lf],pure_premium[%lf]\n",
                                           iins , INS_ptr->ins_premium , INS_ptr->pure_ins_premium);
                              }  /* END of iins == 47 */
                          }
                      }
                  }
                  /******* END : �̫O�B�O�O�ɭp��O�O **********/
                  break;
        }

        /*** step_9_e_iii ***/
        step_9_e_iii:

        /* �«O�O�����v 47���A��,12,33,35,48,56�b���e�w�g�p��L�F, */

        /*if( iins != 47 && iins != 33 && iins != 35 && iins != 48 && iins != 56 && iins != 12 )*/

        if( iins != 47 && iins != 12 && iins != 17)
       {
        	printf(" ------- test1 =\n " );
        	printf(" ------- INS_ptr->deviation_rate = [%f]\n " , INS_ptr->deviation_rate);
        	printf(" ------- INS_ptr->ins_premium  = [%lf]\n " , INS_ptr->ins_premium );
           INS_ptr->ins_premium     *= ( 1 + INS_ptr->deviation_rate/100.0);
           INS_ptr->bef_ins_premium *= ( 1 + INS_ptr->deviation_rate/100.0);
           printf(" ------- test2=\n " );
           printf(" ------- INS_ptr->ins_premium  = [%lf]\n " , INS_ptr->ins_premium );
        }

        printf("Cal_ins_premium:iins[%d]\n",iins);

        /* 97.11�J�O�v�ۥѤ� */
        if( f980101[0] == '1')
            pextra_charge = INS_ptr->pextra_charge;
        else
            INS_ptr->pextra_charge = pextra_charge;

        /* 990903 */
        /* 33,35,48,56�I�� INS_ptr->ins_premium �Oñ��O�O , ply_ins_cover���I�� INS_ptr->ins_premium �O�W���O�O */
        if( iins != 33 && iins != 35 && iins != 48 && iins != 56 )
            INS_ptr->mpure_prem_n = INS_ptr->ins_premium;


        /* 990208, �������[���� => safe_rate=0; manage_rate = 0; educated_rate =1 */
        /* car9610231��~�βĤT�H�f�B�~���[���� */
        /* car9804233�j�v���[���� */
        if(IsProvision) {
           if( iins != 47 && iins != 33 && iins != 35 && iins != 48 && iins != 56 &&
               iins != 57 && iins != 58 && iins != 59 && iins != 60)
           {
                /* �M�ץ󤣦A�p��F���� modify by sylvia 104.11.09 (1041020003_C3) */
           	   /* if (sProvisionType[0]=='B'||sProvisionType[0]=='F'){
	               INS_ptr->ins_premium     *= ( 1 + INS_ptr->adjust_rate);
	               INS_ptr->bef_ins_premium *= ( 1 + INS_ptr->adjust_rate);
               } */

               INS_ptr->ins_premium     *= ( 1 + (INS_ptr->safe_rate/100.0) + (INS_ptr->manage_rate/100.0) );
               INS_ptr->bef_ins_premium *= ( 1 + (INS_ptr->safe_rate/100.0) + (INS_ptr->manage_rate/100.0) );

               INS_ptr->ins_premium     *= ( INS_ptr->educated_rate );
               INS_ptr->bef_ins_premium *= ( INS_ptr->educated_rate );
           }
        }

        switch(iins)
        {
             case 47:
                      bef_premium  = bef_premium  + (long)INS_ptr->bef_ins_premium;
                      pure_premium = pure_premium + (long)INS_ptr->pure_ins_premium;
                      /* 990903 */
                      INS_ptr->mpure_prem_n = (long)INS_ptr->pure_ins_premium;
                      INS_ptr->mins_premium_n = INS_ptr->bef_ins_premium;
                      INS_ptr->mprem_n        = INS_ptr->bef_ins_premium;


                      printf("47:INS_ptr->ins_premium [%lf]\n",INS_ptr->ins_premium);
                      printf("47:INS_ptr->pure_ins_premium [%lf]\n",INS_ptr->pure_ins_premium);
                      break;
             case 17:
             case 24:
                      printf("INTO iins[%d] pextra_charge [%f]\n",iins,pextra_charge);
                      printf("INS_ptr->ins_premium [%ld]\n",INS_ptr->ins_premium);
                      
                      /* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
                      /* INS_ptr->pure_ins_premium = (long)((double)INS_ptr->ins_premium*(1.0-pextra_charge)+0.5); *//* round */
                      INS_ptr->pure_ins_premium = (long)(d45(((double)INS_ptr->ins_premium*(1.0-pextra_charge)),0));
                      bef_premium  = bef_premium  + (long)INS_ptr->bef_ins_premium;
                      pure_premium = pure_premium + (long)INS_ptr->pure_ins_premium;
                      break;
             case 26:
                      break;
             case 33:
             case 48:
             case 35:
                      bef_premium  = bef_premium  + (long)INS_ptr->bef_ins_premium;
                      pure_premium = pure_premium + (long)INS_ptr->pure_ins_premium;
                      break;
             case 56:
                      bef_premium  = bef_premium  + (long)INS_ptr->bef_ins_premium;
                      break;
             default:
                      /*** ����,�ѵs,�d���h���u�� ***/
                      switch(iins)
                      {
                           case 1: case 5: case 8: case 9:
                                   ee_tmp = ee1;
                                   break;
                           case 31: case 32:
                                   ee_tmp = ee2;
                                   break;
                           case 11: case 211:
                                   ee_tmp = ee3;
                                   /* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
                                   /* premium_17 = (long)(dbl_len8(INS_ptr->bef_ins_premium)/(1.0-pextra_charge)+0.5); */
                                   premium_17 = (long)(d45((INS_ptr->bef_ins_premium/(1.0-pextra_charge)),0));
                                   break;
                           default:
                                   ee_tmp = 0.0;
                      }

                      printf("Cal_ins_prem()#######---------�h���u��ee_tmp[%f]\n",ee_tmp);
                      printf("Cal_ins_prem()#######---------���[�O�βvpextra_charge[%f]\n",pextra_charge);
                      printf("Cal_ins_prem()#######---------�M�I�O�O[%lf]\n",INS_ptr->ins_premium);
                      printf("Cal_ins_prem()#######---------�M�I�O�O[%lf]\n",INS_ptr->bef_ins_premium);
                      printf("Cal_ins_prem()#######---------premium_17[%d]\n",premium_17);
                      
                      /* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
                      /* INS_ptr->bef_ins_premium   = (long)(dbl_len8(INS_ptr->bef_ins_premium)/(1.0-pextra_charge)*(1.0+(double)ee_tmp)+0.5); */ /* round */
                      /* �s�WP/Q���ڥ[�O�Y�� modify by 061476 (1071226006_SC9) */
                      INS_ptr->bef_ins_premium   = (long)(d45((INS_ptr->bef_ins_premium*provision_P*provision_Q/(1.0-pextra_charge)*(1.0+(double)ee_tmp)),0));
                      bef_premium  = bef_premium + (long)INS_ptr->bef_ins_premium;

                      /* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
                      INS_ptr->pure_ins_premium   = (long)(d45(INS_ptr->ins_premium*provision_P*provision_Q,0));
                      pure_premium = pure_premium + (long)INS_ptr->pure_ins_premium;

                      printf("ins_prem[%lf]\n",dbl_len8(INS_ptr->ins_premium));
                      
                      /* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
                      /* INS_ptr->ins_premium = (long)(dbl_len8(INS_ptr->ins_premium)/(1.0-pextra_charge)*(1.0+(double)ee_tmp)+0.5); *//* round */
                      INS_ptr->ins_premium = (long)(d45((INS_ptr->ins_premium*provision_P*provision_Q/(1.0-pextra_charge)*(1.0+(double)ee_tmp)),0));

                      printf("�W��INS_ptr->ins_premium[%lf]\n",INS_ptr->ins_premium);

                      /* 990903 */
                      /* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
                      /* INS_ptr->mins_premium_n = (long)(dbl_len8(INS_ptr->mpure_prem_n) /
                                                (1.0-pextra_charge)*(1.0+(double)ee_tmp)+0.5); *//* round */
                      INS_ptr->mins_premium_n = (long)(d45((INS_ptr->mpure_prem_n / (1.0-pextra_charge)*(1.0+(double)ee_tmp)),0));
                      INS_ptr->mprem_n        = INS_ptr->mins_premium_n;
                      
                      /* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
                      /* INS_ptr->mpure_prem_n   = (long)(INS_ptr->mpure_prem_n + 0.5); */
                      INS_ptr->mpure_prem_n   = (long)(d45(INS_ptr->mpure_prem_n , 0));
                      break;
        }

        printf("-------->INS_ptr->pcommission[%4.2f]\n",INS_ptr->pcommission);
        printf("-------->INS_ptr->pagent[%4.2f]\n",INS_ptr->pagent);
        printf("-------->INS_ptr->pdiscount[%4.2f]\n",INS_ptr->pdiscount);
        printf("-------->pextra_charge[%4.2f]\n",pextra_charge*100);

        if( INS_ptr->pdiscount > pextra_charge * 100 )
            INS_ptr->pdiscount = pextra_charge * 100;

        printf("-------->INS_ptr->pdiscount[%4.2f]\n",INS_ptr->pdiscount);
        printf("-------->pextra_charge[%4.2f]\n",pextra_charge*100);

        /************************/
        /* �u�f���B�p��         */
        /* �Y�H�W���O�O�p��o�� */
        /************************/

        if (cal_itype_disc[0] == '2')    /*  �̤�v�]�w  */
        {
            cal_pdiscount = INS_ptr->pdiscount;
            if (cal_pdiscount >= 0)
            {
               disc_last = 0.5;
            }
            else
            {
               disc_last = -0.5;
            }

            cal_prem      = INS_ptr->ins_premium;   /* �W���O�O */

            if (fins_grp[0]=='1')  /*���l*/
            {
                if (fdiscount[0] !='Y')
                {
                     INS_ptr->mdiscount = 0;
                     INS_ptr->pdiscount = 0.0;
                     INS_ptr->mdiscount_n = 0;  /* 990903 */
                }
                else
                {
                     printf("-------->cal_pdiscount[%4.2f]\n",cal_pdiscount);
                     printf("-------->cal_prem[%ld]\n",cal_prem);

                     INS_ptr->mdiscount   = (long)((float)cal_prem*cal_pdiscount/100.0+disc_last);
                     INS_ptr->mdiscount_n = (long)((float)cal_prem*cal_pdiscount/100.0+disc_last);

                     printf("INS_ptr->mdiscount[%ld]\n",INS_ptr->mdiscount);
                }
            }
            else /* if (*fins_grp=='2')  ���d*/
            {
                if (fdiscount[0] !='Y')
                {
                     INS_ptr->mdiscount = 0;
                     INS_ptr->pdiscount = 0.0;
                     INS_ptr->mdiscount_n = 0;  /* 990903 */
                }
                else
                {
                     INS_ptr->mdiscount   = (long)((float)cal_prem*cal_pdiscount/100.0+disc_last);
                     INS_ptr->mdiscount_n = (long)((float)cal_prem*cal_pdiscount/100.0+disc_last);  /* 990903 */
                     printf("INS_ptr->mdiscount[%ld]\n",INS_ptr->mdiscount);
                }
            }
        }
        else
        {
            printf("INTO itype_disc == '1' \n");
            cal_mdiscount = INS_ptr->mdiscount;
            cal_prem      = INS_ptr->ins_premium;   /* �W���O�O */

            cal_pdiscount = d45(cal_mdiscount /cal_prem * 100.0 , 2);

            INS_ptr->pdiscount = cal_pdiscount;
            printf("cal_pdiscount[%f]\n",cal_pdiscount);
            printf("fins_grp[%s] fdiscount[%s]\n",fins_grp, fdiscount);

            if (fins_grp[0] =='1')  /*���l*/
            {
                printf("--------111111111111\n");

                if (fdiscount[0] !='Y')
                {
                     printf("--------2222222222222222\n");

                     INS_ptr->mdiscount = 0;
                     INS_ptr->pdiscount = 0.0;
                     INS_ptr->mdiscount_n = 0;  /* 990903 */
                }
                else
                {
                     printf("-------->cal_pdiscount[%4.2f]\n",cal_pdiscount);
                     printf("-------->cal_prem[%ld]\n",cal_prem);

                     INS_ptr->mdiscount   = cal_mdiscount;
                     INS_ptr->mdiscount_n = cal_mdiscount;  /* 990903 */
                     printf("INS_ptr->mdiscount[%ld]\n",INS_ptr->mdiscount);
                }
            }
            else /* if (*fins_grp=='2')  ���d*/
            {
                if (fdiscount[0] !='Y')
                {
                     INS_ptr->mdiscount = 0;
                     INS_ptr->pdiscount = 0.0;
                     INS_ptr->mdiscount_n = 0;  /* 990903 */
                }
                else
                {
                     INS_ptr->mdiscount   = cal_mdiscount;
                     INS_ptr->mdiscount_n = cal_mdiscount;  /* 990903 */
                     printf("INS_ptr->mdiscount[%ld]\n",INS_ptr->mdiscount);
                }
            }
        }

        /* �I��33�B48�w�����U�Ӷ��Q�O�I�H���u�f �A�w��ñ��O�O */
        /* �p��ñ��O�O */
        if((iins != 33) && (iins != 48) && (iins != 35)){
              INS_ptr->ins_premium = INS_ptr->ins_premium - INS_ptr->mdiscount;

              INS_ptr->mins_premium_n = INS_ptr->mprem_n  - INS_ptr->mdiscount_n;
        }

        premium2_disc += INS_ptr->ins_premium;

        INS_ptr->qday      = 0;
        INS_ptr->mexp_disc = 0;
        INS_ptr->mexpense  = 0;

        premium2 += INS_ptr->ins_premium;   /* ñ��O�O */
        /* �I��12:�s��Q�ѷl���I�O�I���B=[ñ��O�O]*6:�d��H�U�L����˥h */
        if (iins == 12)
        {
            INS_ptr->damage_cover  = (long)((INS_ptr->ins_premium*6)/1000)*1000;
        }


        /* �����N�z�v�ϥ�ñ��O�O����v�p�� */
        /**  �M�ץ�L�����B�N�z�v���D
        INS_ptr->magent = 0;
        INS_ptr->mcommission = 0;
         **/

        cal_pagent      = INS_ptr->pagent;
        cal_pcommission = INS_ptr->pcommission;
        cal_prem        = INS_ptr->ins_premium;

        /* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
        /* INS_ptr->magent      = (long)((float)cal_prem*cal_pagent/100.0+0.5);
        INS_ptr->mcommission = (long)((float)cal_prem*cal_pcommission/100.0+0.5); */
        INS_ptr->magent      = (long)(d45(((float)cal_prem*cal_pagent/100.0),0));
        INS_ptr->mcommission = (long)(d45(((float)cal_prem*cal_pcommission/100.0),0));


        printf("INS_ptr->ins_premium = [%lf]\n", INS_ptr->ins_premium);

        /* �ˮ֭p�⤧�O�O���o�p��ε���0 */
        if (INS_ptr->ins_premium <= 0)
             return M_CA_PREMIUM_0;

        printf("--------------------mmmmmmmmmmmmmmmmmm\n");

        rec_ins_qcvg:
        /*** keep every insurance type's fdeduct & qcoverage.. ***/
        *(INS_ptr->fdeduct)  = *fdeduct;
        *(INS_ptr->fins_grp) = *fins_grp;
        INS_ptr->qcoverage   = qcoverage;
        INS_ptr->qserial     = qserial;

        INS_ptr=INS_ptr->next;
    }   /** end while-INS_ptr **/

    /* 101.06.25 */
    /*if( strncmp( INS_ptr->provision, "F", 1) == 0 || strncmp( INS_ptr->provision, "B", 1) == 0) */
    /* G���ڤ��F���� add by sylvia 105.08.06 (1050705002_C3) */
    /*if(strstr(Icurr->provision,"F") != NULL || strstr(Icurr->provision,"B") != NULL ||
       strstr(Icurr->provision,"G") != NULL)*/
    /* ���[�����X�R�A�վ��^���W�h modify by 061476 (1081225006_SC4) */
    strcpy(tmp_provision,"");
    sprintf_s(tmp_provision, sizeof tmp_provision,"%s;",trim(Icurr->provision));
    if(strstr(tmp_provision,"F;") != NULL || strstr(tmp_provision,"B;") != NULL ||
       strstr(tmp_provision,"G;") != NULL)
    {
       /* �������[���ڤ��p��F�Ƭ����A�٭�F�Ƭ��� */
       /* 980520,�j�v���[����,���Ҽ{�F�Ƭ����A�٭�F�Ƭ��� */

       plia_acc2 = plia_acc2_ori; /* �٭�F�Ƭ��� */
    }

    printf("####### END OF Cal_ins_prem()####### qpt[%f]\n\n\n",qpt);
    printf("################################################################ \n");

    return SUCCESS;

errexit:
    return FAIL;
}

static int Calculate_cover_prem(ins_ptr,ical_ins,fcal_class,iins)
struct INS_TYPE *ins_ptr;
char *ical_ins, *fcal_class;
int iins;
{
    long   int_cover, tmp_dmg, low_dmg_cover, high_dmg_cover;
    int    adj_age;
    double adj_yr_dep;
    long   tmp_cover_dep, cover_dep, thousand_cover_dep;
    long   cover_dep_11;
    char   s_ins[INSURANCE_TYPE];
    $char  tmp_provision[22];

    /* �������[���ڤ��Ҽ{�F�Ƭ����A���k�s�A���}function�A�٭� */
    /*980520, �j�v���[����,���Ҽ{�F�Ƭ����A���k�s�A���}function�A�٭� */
    /* 101.06.25 */
    /*if( strncmp( ins_ptr->provision, "F", 1) == 0 || strncmp( ins_ptr->provision, "B", 1) == 0) */
    /*if(strstr(Icurr->provision,"F") != NULL || strstr(Icurr->provision,"B") != NULL ||
       strstr(Icurr->provision,"G") != NULL)*/
    /* ���[�����X�R�A�վ��^���W�h modify by 061476 (1081225006_SC4) */
    strcpy(tmp_provision,"");
    sprintf_s(tmp_provision, sizeof tmp_provision,"%s;",trim(Icurr->provision));  
    if ( strstr(tmp_provision,"F;") != NULL || strstr(tmp_provision,"B;") != NULL ||
         strstr(tmp_provision,"G;") != NULL )
        /* pdmg_acc = 0; */ /* �M�ץ󤣦A�p��F���� modify by sylvia 104.11.09 (1041020003_C3) */
        pdmg_acc = pdmg_acc_ori;
    else
        pdmg_acc = pdmg_acc_ori;


    printf("####### Calculate_cover_prem:ical_ins[%s] , iins[%d]\n",ical_ins,iins);
    if (IsBlankNull(ical_ins))  /*** �����D�I ***/
    {
        /*---------------------------------------------*/
        low_dmg_cover  = (long)cover_01*0.9;
        high_dmg_cover = (long)cover_01*1.1;
        /*---------------------------------------------*/

        if (iins==1 || iins==5 || iins==9 || iins==8 || iins==85) /*** ����l���I ***/
        {
            /* �O�B */
            ins_ptr->injured_cover = 0;
            ins_ptr->death_cover   = 0;
            if (flag_new==TRUE)
            {
                ins_ptr->damage_cover = cover_01;
            }
            else
            {
                if (ins_ptr->damage_cover==0)
                {
                    ins_ptr->damage_cover = cover_01;
                }
                else
                {
                    if (ins_ptr->damage_cover < low_dmg_cover ||
                        ins_ptr->damage_cover > high_dmg_cover )
                        ins_ptr->damage_cover = cover_01;
                }
            }
            damage_cover_01=ins_ptr->damage_cover;

            if(damage_cover_01<=1200000)
               high_coef=1.00;
            else if((damage_cover_01>=1200001) && (damage_cover_01<=1800000))
               high_coef=0.95;
            else if(damage_cover_01>=1800001)
               high_coef=0.90;

            /***** ??????? *****/
            prem0203=damage_cover_01*0.00045;

            /* �O�O */
            printf("01@@@@@ mprem[%f] dmg_factor[%f]\n",mprem,dmg_factor);
            printf("01@@@@@ psex_age2[%f] pdmg_acc[%f]\n",psex_age2,pdmg_acc);
            printf("01@@@@@ prate_1[%f] short_prate[%f]\n",prate_1,short_prate);
            printf("01@@@@@ ���ִ�O�Y��[%f] ee1[%f]\n",aa,ee1);
            printf("01@@@@@ car_price[%f] bb11[%f]\n",car_price,bb11);
            printf("01@@@@@ high_coef[%f],prem0203[%d], fcar_class2[%s]\n",high_coef,prem0203, fcar_class2);
            printf("01@@@@@ cal_car_id[%s],assuredf[%s]\n",cal_car_id,assuredf);

            /* 1. 4A,2B,9A���ئۥ�==>��~
               2. �t�t�X�e�u,�վ��²�ƫO�O�p��{��,��{���ƥ���U��
                  ²�Ƨ@�k:
                  ����:03,04,21,22,2C,19,9B(�ۥ�)�B07,08,14,15,2A,8A,4A,2B,9A(��~) ==> �򥻫O�Ox�O�v�N���Y��x (�ʧO�~�֫Y��+�ߴڬ����Y��)
                                                                                        (�Y�� ��~�� �� �k�H,  �ʧO�~�֫Y�� = 1 )
                  ��L����: ���m���� �� �򥻶O�v �� ( 1 + �t�P���t�[��O�Y��) �� ( 1 + ���ִ�O�Y�� + �ߴڬ����Y�� )

                modify by sylvia 105.01.12 (1041221009_C3) */

            if ((fcar_class2[0]=='2')||(strcmp(cal_car_id,"19")==0)||(strcmp(cal_car_id,"9A")==0)||(strcmp(cal_car_id,"9B")==0))
            {
               psex_age_damage = 1.0;   /* ��~����19���ج��� */
            }
            else
            {
                /* �ۥΨ� */
                if (assuredf[0]=='1' || assuredf[0]=='3' || assuredf[0]=='5')             /*** �۵M�H ***/
                {
                    /* if (iins==1 || iins==5 || iins==9 || iins==8){
    			        s_ins[0] = '0'; s_ins[1] = '\0';
    			        strcat(s_ins, itoa(iins));
                    }else if (iins==85){
                        strcpy(s_ins, "85");
                    } */
                    sprintf_s(s_ins, sizeof s_ins,"%02d",iins);
                    strcpy(s_ins,trim(s_ins));
                    rc = get_sex_age_factor( s_ins, &v_iAge, fsex, frate, &psex_age_damage, v_sMsg);
    				if( rc != M_CM_OK)
    				{
    				    return rc;
                    }
                    printf("4544:�۵M�H psex_age_damage[%f]\n",psex_age_damage);
                    printf("provision_H[%f]\n", provision_H);
                }
                else if (assuredf[0]=='2' || assuredf[0]=='4' || assuredf[0]=='6') /*** �k�H ***/
                {
                    psex_age_damage = 1.0;
                    printf("4550:�k�H psex_age_damage=[%f]\n",psex_age_damage);
                }
            }
            printf(" psex_age_damage=[%f]\n",psex_age_damage);

            if (strcmp(cal_car_id,"03")==0 || strcmp(cal_car_id,"04")==0 ||
                strcmp(cal_car_id,"21")==0 || strcmp(cal_car_id,"22")==0 ||
                strcmp(cal_car_id,"19")==0 || (ISNEW_CAR1(cal_car_id))   ||
                strcmp(cal_car_id,"07")==0 || strcmp(cal_car_id,"08")==0 ||
                strcmp(cal_car_id,"14")==0 || strcmp(cal_car_id,"15")==0 ||
                (ISNEW_CAR2(cal_car_id)))
            {
                ins_ptr->ins_premium     = mprem*dmg_factor*(psex_age_damage+pdmg_acc)*short_prate*provision_H; /*** round ***/
                ins_ptr->bef_ins_premium = mprem*dmg_factor*(psex_age_damage+pdmg_acc)*short_prate*provision_H; /*** round ***/
            }
            else
            {
                ins_ptr->ins_premium     = car_price*10000.0*prate_1*(1.0+bb11)*(1.0+aa+pdmg_acc)*short_prate*provision_H; /*** round ***/
                ins_ptr->bef_ins_premium = car_price*10000.0*prate_1*(1.0+bb11)*(1.0+aa+pdmg_acc)*short_prate*provision_H; /*** round ***/
            }


            /* �U�C����{���ƥ� bake up by sylvia 105.01.12 ==================== */
            /* if (fcar_class2[0]=='1')
            {
                if (strcmp(cal_car_id,"03")==0 ||
                    strcmp(cal_car_id,"04")==0 ||
                    strcmp(cal_car_id,"21")==0 ||
                    strcmp(cal_car_id,"4A")==0 || strcmp(cal_car_id,"2B")==0 || strcmp(cal_car_id,"2C")==0 ||
                    strcmp(cal_car_id,"22")==0)
                {
                   if (assuredf[0]=='1' || assuredf[0]=='3' || assuredf[0]=='5')
                   {
			          if (iins==1 || iins==5 || iins==9 || iins==8){
			        	  s_ins[0] = '0'; s_ins[1] = '\0';
			              strcat(s_ins, itoa(iins));
			          }else if (iins==85){
			        	  strcpy(s_ins, "85");
			          }
			          strcpy(s_ins,trim(s_ins));
				      rc = get_sex_age_factor( s_ins, &v_iAge, fsex, frate, &psex_age_damage, v_sMsg);
				      if( rc != M_CM_OK)
				      {
				          return rc;
				      }
                   	  printf("01@@@@@ psex_age_damage[%f]\n",psex_age_damage);

                      printf("provision_H[%f]\n", provision_H);
                      ins_ptr->ins_premium     = mprem*dmg_factor*(psex_age_damage+pdmg_acc)*short_prate*provision_H;
                      ins_ptr->bef_ins_premium = mprem*dmg_factor*(psex_age_damage+pdmg_acc)*short_prate*provision_H;
                   }
                   else if (assuredf[0]=='2' || assuredf[0]=='4' || assuredf[0]=='6')
                   {
                      ins_ptr->ins_premium     = mprem*dmg_factor*(1+pdmg_acc)*short_prate*provision_H;
                      ins_ptr->bef_ins_premium = mprem*dmg_factor*(1+pdmg_acc)*short_prate*provision_H;
                   }
                }
                else if ((strcmp(cal_car_id,"19")==0) || (strcmp(cal_car_id,"9A")==0) || (strcmp(cal_car_id,"9B")==0))
                {
                   ins_ptr->ins_premium     = mprem*dmg_factor*(1.0+pdmg_acc) *short_prate*provision_H;
                   ins_ptr->bef_ins_premium = mprem*dmg_factor*(1.0+pdmg_acc) *short_prate*provision_H;
                }
                else
                {
                   ins_ptr->ins_premium     = car_price*10000.0*prate_1*(1.0+bb11)*(1.0+aa+pdmg_acc)*short_prate*provision_H;
                   ins_ptr->bef_ins_premium = car_price*10000.0*prate_1*(1.0+bb11)*(1.0+aa+pdmg_acc)*short_prate*provision_H;
                }
            }
            else
            {
                if (strcmp(cal_car_id,"07")==0 ||
                    strcmp(cal_car_id,"08")==0 ||
                    strcmp(cal_car_id,"14")==0 ||
                    strcmp(cal_car_id,"15")==0 || (ISNEW_CAR2(cal_car_id)))
                {
                   ins_ptr->ins_premium     = mprem*dmg_factor*(1.0+pdmg_acc)*short_prate*provision_H;
                   ins_ptr->bef_ins_premium = mprem*dmg_factor*(1.0+pdmg_acc)*short_prate*provision_H;
                }
                else
                {
                   ins_ptr->ins_premium     = car_price*10000.0*prate_1*(1.0+bb11)*(1.0+aa+pdmg_acc)*short_prate*provision_H;
                   ins_ptr->bef_ins_premium = car_price*10000.0*prate_1*(1.0+bb11)*(1.0+aa+pdmg_acc)*short_prate*provision_H;
                }
            } ================================================================ */

            printf("IINS_TYPE[01,05,08,09]:pure_premium[%lf]\n",ins_ptr->ins_premium);
        }
        else if (iins==11 || iins==211)  /*** �ѵs�l���I ***/
        {
            /* �O�B */
            ins_ptr->injured_cover = 0;
            ins_ptr->death_cover   = 0;
            /* damage_cover of '11' always equal to damage_cover of '01' */
             printf("trace ins11/211 damage_cover_01[%ld]\n ",damage_cover_01);
             printf("trace ins11/211 low_dmg_cover[%ld]\n ",low_dmg_cover);
             printf("trace ins11/211 high_dmg_cover[%ld]\n ",high_dmg_cover);

            if (damage_cover_01==0)
            {
            	/* 102.07.01 fix
                if (ins_ptr->damage_cover < low_dmg_cover ||
                    ins_ptr->damage_cover > high_dmg_cover )
                {*/
                    ins_ptr->damage_cover=cover_01;
                /*}*/
            }
            else
            {
                ins_ptr->damage_cover=damage_cover_01;
            }
            printf("trace ins11/211 ins_ptr->damage_cover[%ld]\n ",ins_ptr->damage_cover);

            /* �O�O */
            printf("11@@@@@ prate_1[%f] short_prate[%f] pro_year[%s]\n",prate_1,short_prate, ipro_year);
            printf("11@@@@@ bb12[%f] ee3[%f]\n",bb12,ee3);

            /**********************************************************/
            /* 11�I�ت��O�O�p��H(cover_01_tmp/tmp_cover_dep)         */
            /* �ӫD(cover_01/cover_dep)-->for other insurance company */
            /**********************************************************/
            /* �ۥΨ� */
            if (fcar_class2[0]=='1')
            {
                if (strcmp(cal_car_id,"03")==0 ||
                    strcmp(cal_car_id,"04")==0 ||
                    strcmp(cal_car_id,"19")==0 ||
                    strcmp(cal_car_id,"21")==0 ||
                    strcmp(cal_car_id,"22")==0 || (ISNEW_CAR1(cal_car_id)))
                {
                    adj_age = int_ply_yr - atoi(ipro_year);
                    if (adj_age > 4) adj_age = 4;

                    adj_yr_dep = MyPower(1-pdep_rate_year, adj_age);

                    printf("11@@@@@, adj_age[%d] adj_yr_dep[%f]\n",adj_age,adj_yr_dep);

                    /* tmp_cover_dep = (int)(car_price*10000.0*adj_yr_dep); */
                    tmp_cover_dep = (long)(car_price*10000.0*adj_yr_dep + 0.000000001);
                    thousand_cover_dep = tmp_cover_dep % 1000;
                    if (thousand_cover_dep != 0)
                    {
                        cover_dep    = (tmp_cover_dep)-(thousand_cover_dep)+1000;
                        cover_dep_11 = tmp_cover_dep - thousand_cover_dep;
                    }
                    else
                    {
                        cover_dep    = tmp_cover_dep;
                        cover_dep_11 = tmp_cover_dep;
                    }
                    printf("11@@@@@ car_price[%f] brg_factor[%f] short_prate[%f]\n",car_price,brg_factor,short_prate);
                    printf("11@@@@@ cover_01_11[%ld], cover_dep_11[%ld]\n",cover_01_11,cover_dep_11);
                    printf("PREM=car_price*prate_1*short_prate*brg_factor\n");
                    printf("                      *(cover_01_11/cover_dep_11)\n");

                    ins_ptr->ins_premium     = car_price*10000.0*prate_1*short_prate*brg_factor
                                               *((double)cover_01_11/(double)cover_dep_11);
                    ins_ptr->bef_ins_premium = car_price*10000.0*prate_1*short_prate*brg_factor
                                               *((double)cover_01_11/(double)cover_dep_11);

                    printf("11----- ins_premium[%lf]\n",ins_ptr->ins_premium);
                    printf("11----- bef_ins_premium[%lf]\n",ins_ptr->bef_ins_premium);

                }
                else
                {
                    printf("�ۥΨ�[%s]\n",cal_car_id);
                    printf("11@@@@@ damage[%d]\n",ins_ptr->damage_cover);
                    printf("damage*prate_1*short_prate*(1+bb12)\n");

                    ins_ptr->ins_premium     = (double)(ins_ptr->damage_cover)*prate_1
                                               *short_prate*(1.0+bb12);
                    ins_ptr->bef_ins_premium = (double)(ins_ptr->damage_cover)*prate_1
                                               *short_prate*(1.0+bb12);
                }
            }
            else
            {   /* ��~�� */
                if (strcmp(cal_car_id,"07")==0 ||
                    strcmp(cal_car_id,"08")==0 ||
                    strcmp(cal_car_id,"14")==0 ||
                    strcmp(cal_car_id,"15")==0 || (ISNEW_CAR2(cal_car_id)))
                {
                    adj_age = int_ply_yr - atoi(ipro_year);
                    if (adj_age > 4) adj_age = 4;

                    adj_yr_dep = MyPower(1-pdep_rate_year, adj_age);

                    /* tmp_cover_dep = (int)(car_price*10000.0*adj_yr_dep); */
                    tmp_cover_dep = (long)(car_price*10000.0*adj_yr_dep + 0.000000001);
                    thousand_cover_dep = tmp_cover_dep % 1000;
                    if (thousand_cover_dep != 0)
                    {
                        cover_dep = (tmp_cover_dep)-(thousand_cover_dep)+1000;
                        cover_dep_11 = tmp_cover_dep - thousand_cover_dep;
                    }
                    else
                    {
                        cover_dep = tmp_cover_dep;
                        cover_dep_11 = tmp_cover_dep;
                    }

                    printf("11@@@@@ car_price[%f] brg_factor[%f]\n",car_price,brg_factor);
                    printf("11@@@@@ cover_01_11[%ld], cover_dep_11[%ld]\n",cover_01_11,cover_dep_11);
                    printf("11@@@@@ adj_yr_dep[%f]\n",adj_yr_dep);
                    printf("PREM=car_price*prate_1*short_prate*brg_factor\n");
                    printf("                      *(cover_01_11/cover_dep_11)\n");

                    ins_ptr->ins_premium     = car_price*10000.0*prate_1*short_prate*brg_factor
                                               *((double)cover_01_11/(double)cover_dep_11);
                    ins_ptr->bef_ins_premium = car_price*10000.0*prate_1*short_prate*brg_factor
                                               *((double)cover_01_11/(double)cover_dep_11);

                }
                else
                {
                    ins_ptr->ins_premium     = (double)(ins_ptr->damage_cover)*prate_1*short_prate*(1.0+bb12);
                    ins_ptr->bef_ins_premium = (double)(ins_ptr->damage_cover)*prate_1*short_prate*(1.0+bb12);
                }
            }

            printf("11@@@@@ ins_premium[%lf]\n",ins_ptr->ins_premium);
            printf("11@@@@@ bef_ins_premium[%lf]\n",ins_ptr->bef_ins_premium);

            premium_11 = ins_ptr->damage_cover*short_prate+0.005;
            premium_12 = ins_ptr->damage_cover+0.005;

            printf("11@@@@@ premium_11[%d],premium_12[%d] FOR iins 12\n",premium_11,premium_12);

        }
        else if (iins==18)   /*   940210  */
        {
            /* �O�B */
            ins_ptr->injured_cover = 0;
            ins_ptr->death_cover   = 0;
            /* damage_cover of '11' always equal to damage_cover of '01' */
            if (damage_cover_01==0)
            {
                if (ins_ptr->damage_cover < low_dmg_cover ||
                    ins_ptr->damage_cover > high_dmg_cover )
                {
                    ins_ptr->damage_cover=cover_01;
                }
            }
            else
            {
                ins_ptr->damage_cover=damage_cover_01;
            }

            ins_ptr->ins_premium     = (double)(ins_ptr->damage_cover)*prate_1*short_prate;
            ins_ptr->bef_ins_premium = (double)(ins_ptr->damage_cover)*prate_1*short_prate;

            printf("18@@@@@ ins_premium[%lf]\n",ins_ptr->ins_premium);
            printf("18@@@@@ bef_ins_premium[%lf]\n",ins_ptr->bef_ins_premium);

            /* for calculate premium of iins_type='12' */
            premium_11 = ins_ptr->damage_cover*short_prate+0.005;
            premium_12 = ins_ptr->damage_cover+0.005;

            printf("18@@@@@ premium_11[%d],premium_12[%d] FOR iins 12\n",premium_11,premium_12);
        }
        else if (iins==25)
        {
            printf("25@@@@@ prate_1[%f] short_prate[%f]\n",prate_1,short_prate);

            ins_ptr->death_cover=0;

            ins_ptr->ins_premium     = (double)ins_ptr->injured_cover*prate_1
                                       *((double)ins_ptr->damage_cover/(double)ins_ptr->injured_cover)
                                       *short_prate;           /*** round ***/

            ins_ptr->bef_ins_premium = (double)ins_ptr->injured_cover*prate_1
                                       *((double)ins_ptr->damage_cover/(double)ins_ptr->injured_cover)
                                       *short_prate;           /*** round ***/

            printf("25@@@@@ ins_premium[%lf]\n",ins_ptr->ins_premium);
        }
        else
        {
            ins_ptr->injured_cover   = 0;
            ins_ptr->death_cover     = 0;

            ins_ptr->ins_premium     = (double)ins_ptr->damage_cover*prate_1*short_prate;  /*** round ***/
            ins_ptr->bef_ins_premium = (double)ins_ptr->damage_cover*prate_1*short_prate;  /*** round ***/
        }
    }
    else if (memcmp(ical_ins,"01",2)==0)
    {   /* �̨����I�p��           */
        /* 02,03,04               */
        /* 07    �����I���l�K���� 940210 */

        /********************************/
        /* �䭷�x���a�_�I               */
        /* �t�X���بT��JT�~�P�M�פ���� */
        /* ���ˮ֫O�d��91.08.05         */
        /* ���O�ĤE�쬰1:����JT�M��     */
        /********************************/
        /******************************************
            (strncmp(equipment+8,"1",1) == 0) &&
        *******************************************/

        if ((iins == 2) &&
            (equip_cmp(equipment,"9") == TRUE) &&
            ((strncmp(officer2, "C", 1) == 0) || (strncmp(officer2, "D", 1) == 0)) &&
            (dwritten <= cm_ymd_cdate("91/08/15")))
        {
            Scan_INS_TYPE(11);
        }
        else
        {
            if (! Scan_INS_TYPE(1))
            {
                 if (! Scan_INS_TYPE(5))
                 {
                      if(! Scan_INS_TYPE(9))
                            if (!Scan_INS_TYPE(8))
                                 return M_CA_INS01;
                 }
            }
        }

        printf("iins[%d],mdamage_cover[%ld]\n",iins, Icurr->damage_cover);
        ins_ptr->injured_cover = Icurr->injured_cover;
        ins_ptr->death_cover   = Icurr->death_cover;
        ins_ptr->damage_cover  = Icurr->damage_cover;
        ins_ptr->deduct        = 0;

        if (*fcal_class=='2')
        {    /* �̨����I�O�O�p��    */
             /* 07.�����I���l�K���� */
             printf("INTO 07\n");
             printf("Icurr->ins_premium[%f]\n",Icurr->ins_premium);
             printf("prate_1[%f]\n",prate_1);

             if (iins==7)
             {
                /* �����A���H�u���O�v�A�]�����I�«O�O�w�t */
                ins_ptr->ins_premium     = (double)Icurr->pure_ins_premium*prate_1*provision_H;  /*** round ***/
                ins_ptr->bef_ins_premium = (double)Icurr->pure_ins_premium*prate_1*provision_H;  /*** round ***/
             }
             else
             {
                ins_ptr->ins_premium     = (double)Icurr->ins_premium*prate_1*provision_H;  /*** round ***/
                ins_ptr->bef_ins_premium = (double)Icurr->ins_premium*prate_1*provision_H;  /*** round ***/
             }
        }
        else
        {    /* �̨����I�O�B�p�� */
             if (iins==2)
             {  /* �䭷�x���a�_�I */
                ins_ptr->ins_premium     = (double)Icurr->damage_cover*prate_1*provision_H; /*** round ***/
                ins_ptr->bef_ins_premium = (double)Icurr->damage_cover*prate_1*provision_H; /*** round ***/
             }
             else
             {
                ins_ptr->ins_premium     = (double)Icurr->damage_cover*prate_1*short_prate*provision_H; /*** round ***/
                ins_ptr->bef_ins_premium = (double)Icurr->damage_cover*prate_1*short_prate*provision_H; /*** round ***/
             }
        }
    }
    else if (memcmp(ical_ins,"11",2)==0)
    {   /* 13:�r�p�V�m�ѵs�I 17:�ѵs�I���l�K���� */
        if (!Scan_INS_TYPE(11)) return M_CA_INS11;

        ins_ptr->injured_cover = Icurr->injured_cover;
        ins_ptr->death_cover   = Icurr->death_cover;
        ins_ptr->damage_cover  = Icurr->damage_cover;
        ins_ptr->deduct=0;

        if (*fcal_class=='2')
        {   /* �̥D�I:�ѵs�I11���u�ݫe�O�O�p�� */
            /* 17:�ѵs�I���l�K���� */
            /* 17:�ѵs�I���l�K���ª����p��W����ñ��O�O,�A����«O�O */
            printf("premium_17=[%d] prate_1=[%f]\n", premium_17, prate_1);

            /* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
            /* ins_ptr->ins_premium     = (long)((double)premium_17*prate_1+0.5);
            ins_ptr->bef_ins_premium = (long)((double)premium_17*prate_1+0.5); */
            ins_ptr->ins_premium     = (long)(d45(((double)premium_17*prate_1),0));
            ins_ptr->bef_ins_premium = (long)(d45(((double)premium_17*prate_1),0));
        }
        else
        {
            ins_ptr->ins_premium     = (double)Icurr->damage_cover*prate_1*short_prate; /* round */
            ins_ptr->bef_ins_premium = (double)Icurr->damage_cover*prate_1*short_prate; /* round */
        }

        /* for calculate premium of iins_type = '12' */
        premium_11 = ins_ptr->damage_cover*short_prate+0.005;
        premium_12 = ins_ptr->damage_cover+0.005;
    }
    else if (memcmp(ical_ins,"31",2)==0)
    {   /* 24,26 */
        if (! Scan_INS_TYPE(31))  return M_CA_INS31;

        injured_cover   = Icurr->injured_cover;
        death_cover     = Icurr->injured_cover;
        damage_cover    = Icurr->damage_cover;
        deduct          = Icurr->deduct;
        ins_premium     = Icurr->ins_premium;
        bef_ins_premium = Icurr->bef_ins_premium;

        if (! Scan_INS_TYPE(32));
        injured_cover   = injured_cover   + Icurr->injured_cover;
        death_cover     = death_cover     + Icurr->injured_cover;
        damage_cover    = damage_cover    + Icurr->damage_cover;
        deduct          = deduct          + Icurr->deduct;
        ins_premium     = ins_premium     + Icurr->ins_premium;
        bef_ins_premium = bef_ins_premium + Icurr->bef_ins_premium;

        ins_ptr->injured_cover = injured_cover;
        ins_ptr->death_cover   = death_cover;
        ins_ptr->damage_cover  = damage_cover;
        ins_ptr->deduct        = deduct;

        printf("24@@@@@ premium_3132[%lf] prate_1[%f] short_prate[%f]\n",premium_3132,prate_1,short_prate);
        printf("24@@@@@ premium1_24[%ld]",premium1_24);

        if (fcal_class[0]=='2')
        {
	        /* 97.11�J�O�v�ۥѤ� */
	        if( f980101[0] == '1')
	            pextra_charge = ins_ptr->pextra_charge;
	        else
	            ins_ptr->pextra_charge = pextra_charge;

        	/* 24�I�ةҺ�X���O�O�O�W���O�O�ӫD���«O�O */
             ins_ptr->ins_premium     =  premium_3132*prate_1*short_prate;                         /*** round ***/
             
             /* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
             /* ins_ptr->ins_premium     =  (long)(dbl_len8(ins_ptr->ins_premium)/(1-pextra_charge)+0.5); */
             ins_ptr->ins_premium     =  (long)(d45((ins_ptr->ins_premium /(1-pextra_charge)),0));

             /* premium1_24 �w���u���O�O[�Y���N�I���u����] */
             /* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
             /* ins_ptr->ins_premium     += ((long)((double)premium1_24*prate_1+0.5)); */
             ins_ptr->ins_premium     += (long)(d45(((double)premium1_24*prate_1),0));

             ins_ptr->bef_ins_premium =  premium_3132*prate_1*short_prate;                         /*** round ***/
             
             /* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
             /* ins_ptr->bef_ins_premium =  (long)(dbl_len8(ins_ptr->bef_ins_premium)/(1-pextra_charge)+0.5); */
             ins_ptr->bef_ins_premium =  (long)(d45((ins_ptr->bef_ins_premium/(1-pextra_charge)),0));

             /* premium1_24 �w���u���O�O[�Y���N�I���u����] */
             /* ���A�ϥ�+0.5,�אּ�I�sd45() modify by sylvia (1060126001_C3) */
             /* ins_ptr->bef_ins_premium += ((long)((double)premium1_24*prate_1+0.5)); */   /*** round ***/
             ins_ptr->bef_ins_premium += (long)(d45(((double)premium1_24*prate_1),0));
        }
        else
        {
             ins_ptr->ins_premium     = (double)damage_cover*prate_1*short_prate;  /* round */
             ins_ptr->bef_ins_premium = (double)damage_cover*prate_1*short_prate;  /* round */
        }
        printf("{Calculate_cover_prem}:24 ins_premium[%lf]\n",ins_ptr->ins_premium);
    }

    /* 101.06.25 */
    /*if( strncmp( ins_ptr->provision, "F", 1) == 0 || strncmp( ins_ptr->provision, "B", 1) == 0) */
    /*if(strstr(Icurr->provision,"F") != NULL || strstr(Icurr->provision,"B") != NULL ||
       strstr(Icurr->provision,"G") != NULL)*/
    /* ���[�����X�R�A�վ��^���W�h modify by 061476 (1081225006_SC4) */
    if(strstr(tmp_provision,"F;") != NULL || strstr(tmp_provision,"B;") != NULL ||
       strstr(tmp_provision,"G;") != NULL)       
    {
       /* �������[���ڤ��p��F�Ƭ����A�٭�F�Ƭ��� */
       /* 980520,�j�v���[����,���Ҽ{�F�Ƭ����A�٭�F�Ƭ��� */
       pdmg_acc = pdmg_acc_ori;
    }


    return SUCCESS;
}

static int Insert_INS_TYPE(s1,
                           p1,p2,p3,
                           p4,
                           p5,p9,
                           p6,p7,p8,
                           s2,
                           p10,
                           p11,p12,p13,
                           s4, s5, s6,
                           s3,p14,
                           p15,p16, s7, s8, p17, safe_rate, manage_rate, educated_rate,
                           deviation_rate, pextra_charge, pbusiness)
char   *s1,*s2;
char   *s3;
char   *s4, *s5, *s6, *s7, *s8;
long   p1,p2,p3,p4;
long   p5,p9,p10;
double p6,p7,p8;
double p11,p12,p13,p14;
long   p15,p16,p17;
double safe_rate, manage_rate, educated_rate, deviation_rate;
double pextra_charge, pbusiness;
{

    /*** use a link list ***/
    printf("into Insert_INS_TYPE s1=[%s], s2=[%s] p4=[%d]\n", s1, s2, p4 );

    Icurr=(struct INS_TYPE *)malloc(sizeof(struct INS_TYPE));
    if (Icurr==NULL) return FAIL;
    if (Ifirst==NULL)
    {     /* if it's first element?! */
        Ifirst=Ilast=Icurr;
        Icurr->next=NULL;
    }
    else  if (strcmp(trim(s1),"01")==0 || strcmp(trim(s1),"11")==0 ||
              strcmp(trim(s1),"31")==0 || strcmp(trim(s1),"32")==0 ||
              strcmp(trim(s1),"36")==0 || strcmp(trim(s1),"37")==0 ||
              strcmp(trim(s1),"77")==0 || strcmp(trim(s1),"78")==0 ||
              strcmp(trim(s1),"05")==0 || strcmp(trim(s1),"09")==0 ||
              strcmp(trim(s1),"08")==0 || strcmp(trim(s1),"85")==0 ||
              strcmp(trim(s1),"211")==0)
    {
        Icurr->next=Ifirst;
        Ifirst=Icurr;
    }
    else
    {
        Ilast->next=Icurr;
        Ilast=Icurr;
        Icurr->next=NULL;
    }

    strcpy(Icurr->ins_type,s1);
    strcpy(Icurr->frate,s2);

    Icurr->injured_cover    = p1;
    Icurr->death_cover      = p2;
    Icurr->damage_cover     = p3;

    Icurr->deduct           = p4;

    Icurr->ins_premium      = p5;
    Icurr->bef_ins_premium  = p9;
    Icurr->pure_ins_premium = p10;

    Icurr->pagent           = p6;
    Icurr->pcommission      = p7;
    Icurr->pdiscount        = p8;

    Icurr->broker_pagent    = p11;
    Icurr->broker_pcommi    = p12;
    Icurr->broker_pdisc     = p13;

    strcpy(Icurr->icheck_agent, s4);
    strcpy(Icurr->icheck_commi, s5);
    strcpy(Icurr->icheck_disc,  s6);

    strcpy(Icurr->ipaid_base,   s3);

    Icurr->pfix_agent       = p14;

    Icurr->qday             = p15;
    Icurr->mexpense         = p16;
    strcpy(Icurr->provision,  s7);
    strcpy(Icurr->itype_disc, s8);
    Icurr->mdiscount        = p17;

    /* 'car9610231��~�βĤT�H�f�B�~���[���� */
    Icurr->safe_rate        = safe_rate;
    Icurr->manage_rate      = manage_rate;
    Icurr->educated_rate    = educated_rate;

    /* �«O�O�����v */
    Icurr->deviation_rate    = deviation_rate;

    Icurr->pextra_charge    = pextra_charge;
    Icurr->pbusiness        = pbusiness;
    rows++;

    printf("Icurr->frate=[%s], Icurr->deduct =[%d]\n", Icurr->frate, Icurr->deduct  );

    printf("end Insert_INS_TYPE \n");
    printf("====================\n");

    return SUCCESS;
}

static int Scan_INS_TYPE(itype)        /* return data in Icurr */
int itype;
{
    Icurr=Ifirst;
    while (Icurr)
    {
        if (atoi(trim(Icurr->ins_type))==itype) return SUCCESS;
        Icurr=Icurr->next;
    }
    return FAIL;
}

int IsBlankNull(str)
char *str;
{
    while (*str)
    {
        if (*str!=' ') return FALSE;
        str++;
    }
    return TRUE;
}


double d45(num,num1)
double num;
int num1;
{
    long tmplong;
    double var1;
    double ten;
    int i;

    ten = 1;
    for(i = 1 ;i<=num1;i++)
    ten *= 10;

    num *= ten;
    
    /* �|�ˤ��J+0.5 �אּ +0.500000000001 modify by sylvia 106.02.02 (1060126001_C3) */
    if (num >= 0) var1 = 0.500000000001;
    else var1 = (-0.500000000001);

    num = num + var1;
    tmplong = num;

    num = tmplong/ten;
    return(num);
}


/* �Y searchString = replaceString      => �^�� searchString �b string�����Ӽ� */
/* �Y searchString != replaceString     => �N�b string����searchString ���N�� replaceString ,�æ^�Ǩ��N���Ӽ� */
/* �Y�j�M����εL����searchString�Q���N => �^�� 0 */
int strSearchReplace(char *string,char *searchString,char *replaceString)
 {
 char *currP, *baseStr;
 int  count = 0;

 currP = baseStr = NULL;

 while (*string)
      {
      currP = strstr (!currP ? string : baseStr, searchString);

      if (currP)
           {
           count++;
           baseStr = (currP + strlen (replaceString));
           strcpy (currP, (currP + strlen (searchString)));
           memmove (currP + strlen (replaceString),
                      currP, strlen (currP) + 1);
           memcpy (currP, replaceString, strlen (replaceString));
           }
      else
           break;
      }

 return count;
 }


/*980520,trim() �[�j��, �R���r���Y���H�Ϊ��������� ' ', '\f' , '\n' , '\r' ,'\t' , '\v' ���r�� */
 char* trimx (char *str)
{
      char *ibuf, *obuf;

      if (str)
      {
            for (ibuf = obuf = str; *ibuf; )
            {
                  while (*ibuf && (isspace (*ibuf)))
                        ibuf++;
                  if (*ibuf && (obuf != str))
                        *(obuf++) = ' ';
                  while (*ibuf && (!isspace (*ibuf)))
                        *(obuf++) = *(ibuf++);
            }
            *obuf = '\0';
      }
      return (str);
}

long GetNextYearDate(pdate)
long pdate;
{
long ndate;
short mdy[3];

    rjulmdy(pdate,mdy);
    mdy[2]++;   /* mdy[2] is the year data */
    if ((mdy[0] == 2) && (mdy[1] == 29))
       mdy[1] = 28;

    rmdyjul(mdy,&ndate);
    return ndate;
}