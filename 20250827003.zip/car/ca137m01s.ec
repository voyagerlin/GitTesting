/************************************************/
/*                                              */
/*   PROGRAM : ca137m01s.ec                     */
/*                                              */
/*   DATE:     2002/10/29                       */
/*                                              */
/************************************************/

#include <stdio.h>
#include <string.h>
#include <decimal.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"

$include sqlca;

int isalpha (int c);
int isascii (int c);

long MsgCode;

DBinfo  *list;
int  count_db, i;
static int max_cnt;

long car137(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car137_insert(),car137_single_query(),car137_multiple_query(),
      car137_update_exec(),car137_squery(),car137_query2();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'P':rtncode=car157_get_ipolicy(reply);
           break;          
  case 'A':
           rtncode=car137_insert(reply);
           break;
  case 'Q':
           rtncode=car137_single_query(reply);
           break;
  case 'M':
           rtncode=car137_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car137_update_exec(reply,command,com_len);
           break;  
  default :
        return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
 }
 return(rtncode);
}

long car157_get_ipolicy(reply)
serverReply reply;
{
    $char DBName[5], sFullName[21], stmt[1024];
    int tmp_len;
    $char userid[11];
    $char ipolicy[21];
    $char dply_begin[11],dply_end[11],dtransfer[11],iofficer[11],iroute[21],ileader[11],nofficer[11],nleader[11];
    $char iquota[7],nquota[41];	  
    cm_buf_get("%s %s ",DBName,ipolicy);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
        return M_CM_DB_NOTOPEN;
      else
        return apiRC; 
    }	
	
    if( strlen( trim(ipolicy)) == 0)
        return exitsub(reply, M_CA_NOT_PLY) ? M_CA_NOT_PLY : apiRC;

    strcpy(sFullName, get_car_full_db(ipolicy));

    sprintf_s(stmt, sizeof stmt, "SELECT  a.dply_begin,a.dply_end,dtransfer,a.iofficer,(select nname from officer d where d.iofficer = a.iofficer),"
                    " b.iroute,a.ileader,(select nname from officer d where d.iofficer = a.ileader),"
                    " a.iquota,(select nbranch from sa_branch_type e where e.ibranch = a.iquota)"
                    " FROM %s:ply_relation a, %s:policy b "
                    " WHERE a.ipolicy = b.ipolicy "
                    " AND a.ipolicy = '%s' " , sFullName, sFullName, ipolicy );                  
    printf("stmt[%s]\n", stmt); 
    
    $PREPARE prep2 FROM $stmt;
    $EXECUTE prep2 INTO $dply_begin ,$dply_end ,$dtransfer ,$iofficer ,$nofficer ,$iroute ,$ileader ,$nleader ,$iquota ,$nquota ;
    
    strcpy(dply_begin, cm_from_infdate_100(dply_begin));
    strcpy(dply_end, cm_from_infdate_100(dply_end));
    strcpy(dtransfer, cm_from_infdate_100(dtransfer));
   
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s ",
                M_CM_OK, dply_begin, dply_end, dtransfer, iofficer, nofficer, iroute, ileader, nleader ,iquota ,nquota);

    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long car137_insert(reply)
serverReply reply;
{
     $char DBName[5],DBName1[5];
     $char LsBuffer[1024], sFullName[20];
     $char sFullName_sys[20];
     $char c_ipolicy[21],c_fins_grp[2],c_remark[31],c_dexpire[11],c_userid[11];
     $char check[2];
     $int check_fins_grp = 0;

     int LiBufLen;
     cm_buf_get("%s",DBName);

     cm_buf_get("%s %s %s %s %s %s", c_ipolicy,c_fins_grp,c_remark,c_dexpire,c_userid,check);
     
     strcpy(c_dexpire,cm_to_infdate(c_dexpire));
     
     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     $BEGIN WORK;
     $WHENEVER SQLERROR GOTO errexit;
      
     if(strcmp(trim(check),"1")==0)
     {
     $SELECT distinct(select count(*) from reject_policy where ipolicy = a.ipolicy and Ascii(fins_grp) >= 65)
       INTO $check_fins_grp
       FROM reject_policy a
      WHERE ipolicy = $c_ipolicy;
     }
     else
     {
     $SELECT distinct(select count(*) from reject_policy where ipolicy = a.ipolicy and Ascii(fins_grp) <= 57)
       INTO $check_fins_grp
       FROM reject_policy a
      WHERE ipolicy = $c_ipolicy;
     }
     
     if(check_fins_grp>0)
     {
      $ROLLBACK WORK;	
      return exitsub(reply,M_CA_DUPDATA) ? M_CA_DUPDATA : apiRC;
     }
          
     sprintf_s(LsBuffer, sizeof LsBuffer, "INSERT INTO reject_policy "
            " (ipolicy,fins_grp,remark,dexpire,iupdate,dupdate,icreate,dcreate) "
      "VALUES (?,?,?,?,?,current,?,current)");
  
     $PREPARE a_id FROM $LsBuffer;
     $EXECUTE a_id USING $c_ipolicy,$c_fins_grp,$c_remark,$c_dexpire,$c_userid,$c_userid;
  
     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     LiBufLen = cm_buf_len(ReplyBuf);   

     if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
     {
       $WHENEVER SQLERROR CONTINUE;
       $ROLLBACK WORK;
       return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     $COMMIT WORK;
     return api_OKComplete;

     errexit:
         printf(" sqlerrm = %s\n",sqlca.sqlerrm);
         $WHENEVER SQLERROR CONTINUE;
         MsgCode = SQLCODE;
         $ROLLBACK WORK;
         if (SQLCODE != 0) MsgCode = SQLCODE;
         return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

long car137_single_query(reply)
serverReply reply;
{
 $char DBName[5], sFullName[21], stmt[1024];
 $char m_ipolicy[21], m_fins_grp[2],m_dplyend1[11],m_dplyend2[11];
 $char q_ipolicy[21],q_fins_grp[2],q_remark[31],q_dexpire[11];
 $char q_dply_begin[11],q_dply_end[11],q_dtransfer[11],q_iofficer[11],q_iroute[21],q_ileader[11],q_nofficer[11],q_nleader[11];
 $char q_iquota[7],q_nquota[41],q_iupdate[11],q_dupdate[21],q_icreate[11],q_dcreate[21];
 int tmp_len;
 
 cm_buf_get("%s %s %s ",DBName,m_ipolicy,m_fins_grp);
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
     
    strcpy(sFullName, get_car_full_db(m_ipolicy));

    sprintf_s(stmt, sizeof stmt, "SELECT c.ipolicy,c.fins_grp,c.remark,c.dexpire, "
                   " a.dply_begin,a.dply_end,dtransfer,a.iofficer,(select nname from officer d where d.iofficer = a.iofficer),"
                   " b.iroute,a.ileader,(select nname from officer d where d.iofficer = a.ileader),"
                   " a.iquota,(select nbranch from sa_branch_type e where e.ibranch = a.iquota),"
                   " c.iupdate,c.dupdate,c.icreate,c.dcreate "
                   " FROM %s:ply_relation a, %s:policy b ,reject_policy c"
                   " WHERE a.ipolicy = b.ipolicy "
                   " AND a.ipolicy = c.ipolicy "
                   " AND a.ipolicy = '%s' "
                   " AND c.fins_grp matches '%s' ", sFullName, sFullName, m_ipolicy , m_fins_grp);                  
    printf("stmt[%s]\n", stmt); 
    
    $PREPARE prep2 FROM $stmt;
    $EXECUTE prep2 INTO $q_ipolicy,$q_fins_grp,$q_remark,$q_dexpire,$q_dply_begin ,$q_dply_end ,$q_dtransfer ,$q_iofficer ,$q_nofficer ,$q_iroute ,$q_ileader ,$q_nleader ,$q_iquota ,$q_nquota ,$q_iupdate ,$q_dupdate ,$q_icreate ,$q_dcreate;
    
    strcpy(q_dexpire, cm_from_infdate_100(q_dexpire));
    strcpy(q_dply_begin, cm_from_infdate_100(q_dply_begin));
    strcpy(q_dply_end, cm_from_infdate_100(q_dply_end));
    strcpy(q_dtransfer, cm_from_infdate_100(q_dtransfer));
         
 if(SQLCODE==SQLNOTFOUND)
 {
  if(exitsub(reply,M_CM_NOT_FOUND) == True)       /*?*/
    return M_CM_NOT_FOUND;                        /*?*/
  else
    return apiRC;
 } 
 
 cm_buf_init(ReplyBuf);
 
 cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
             M_CM_OK, q_ipolicy,q_fins_grp,q_remark,q_dexpire,q_dply_begin,q_dply_end,q_dtransfer,q_iofficer,q_nofficer,q_iroute,q_ileader,q_nleader,q_iquota,q_nquota,q_iupdate,q_dupdate,q_icreate,q_dcreate);
 
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
   return apiRC;
 else
   return api_OKComplete;

 errexit:
   MsgCode = cm_show_sql_err("ca137_single_query", NULL);
  if(exitsub(reply,MsgCode) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car137_multiple_query(reply)
serverReply reply;
{
 $char DBName[5], sFullName[21], stmt[1024];
 $char c_ipolicy[21],c_fins_grp[2],c_dplyend1[11],c_dplyend2[11];
 $char m_ipolicy[21],m_fins_grp[2],m_dplyend1[11],m_dplyend2[11];
 $char ipolicy[21], fins_grp[2], remark[31], dexpire[11];
 $char dply_begin[11], dply_end[11], dtransfer[11], iofficer[11], iroute[21], ileader[11], nofficer[11], nleader[11];
 $char iquota[7], nquota[41];
 
 /* $char sFullName_sys[20];  */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0,k;
 int OPEN_STAR;
 cm_buf_get("%s %s %s %s %s",DBName,c_ipolicy,c_fins_grp,c_dplyend1,c_dplyend2);
 strcpy(c_dplyend1,cm_to_infdate(c_dplyend1));
 strcpy(c_dplyend2,cm_to_infdate(c_dplyend2));
 
 $WHENEVER SQLERROR GOTO errexit;
 
 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 
 }

 if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
         printf("get_db_list error accur \n");
         return SQLCODE;
      }
 
 for(k=0 ; k<count_db ; k++)
{   
 sprintf_s(stmt, sizeof stmt, "SELECT c.ipolicy,c.fins_grp,c.dexpire, "
                     " a.dply_begin,a.dply_end,a.dtransfer,a.iofficer,(select nname from officer d where d.iofficer = a.iofficer),"
                     " b.iroute,a.ileader,(select nname from officer d where d.iofficer = a.ileader),"
                     " a.iquota,(select nbranch from sa_branch_type e where e.ibranch = a.iquota) "
                " FROM %s:ply_relation a, %s:policy b , reject_policy c "
                " WHERE a.ipolicy = b.ipolicy "
                " AND a.ipolicy = c.ipolicy "
                " AND a.ipolicy matches '%s' "
                " AND c.fins_grp matches '%s' "
                " AND a.dply_end BETWEEN '%s' AND '%s' ", list[k].dbname ,list[k].dbname ,c_ipolicy ,c_fins_grp ,c_dplyend1 ,c_dplyend2);
 
        printf("stmt[%s]\n",stmt);

        $PREPARE cur_2 FROM $stmt;
        $DECLARE q_cur2 CURSOR FOR cur_2; 
       
    $OPEN q_cur2;
 
 for(;;)
  {
    $FETCH q_cur2 INTO $ipolicy,$fins_grp,$dexpire,$dply_begin,$dply_end,$dtransfer,$iofficer,$nofficer,$iroute,$ileader,$nleader,$iquota,$nquota;
   
    if (SQLCODE != 0) break;
    
    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }

    cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s ",
              ipolicy,fins_grp,dexpire,dply_begin,dply_end,dtransfer,iofficer,nofficer,iroute,ileader,nleader,iquota,nquota);

    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
       	$CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;

        if(replycnt > 5) sleep(3);
        else if(replycnt > 3) sleep(2);
        else if(replycnt > 1) sleep(1);

        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();

        cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s ",
              ipolicy,fins_grp,dexpire,dply_begin,dply_end,dtransfer,iofficer,nofficer,iroute,ileader,nleader,iquota,nquota);
              
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
   /* for loop */
  }
}

 $CLOSE q_cur2;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

 errexit:
   MsgCode = cm_show_sql_err("ca137_multiple_query", NULL);
   if(exitsub(reply,MsgCode) == True)
     return SQLCODE;
   else
     return apiRC;
}

long car137_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
        
 $char DBName[5] , sFullName[21], stmt[1024];
 $char cur_ipolicy[21],cur_fins_grp[2],cur_remark[31],cur_dexpire[11];
 $char cur_iupdate[11],cur_dupdate[21],cur_icreate[11],cur_dcreate[21];
 $char u_ipolicy[21],u_fins_grp[2],u_remark[31],u_dexpire[11];
 $char q_ipolicy[21],q_fins_grp[2],q_remark[31],q_dexpire[11]; 
 $char u_iupdate[11],u_dupdate[21],u_icreate[11],u_dcreate[21]; 
 $char q_iupdate[11],q_dupdate[21],q_icreate[11],q_dcreate[21];
 
 $char cur_dply_begin[11],cur_dply_end[11],cur_dtransfer[11],cur_iofficer[11],cur_iroute[21],cur_ileader[11],cur_nofficer[11],cur_nleader[11];
 $char cur_iquota[7],cur_nquota[41];
 
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len; long dummy;
   DBinfo *list;
   int i, j, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[300];

 comm = (char *) command;
 cm_buf_init(command);

 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
     return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

/*  if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
     return exitsub(reply,M_CM_NOT_DBLIST) ? M_CM_NOT_DBLIST : apiRC;  */

 memcpy(&raw_len,&comm[com_len],sizeof(int));
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)
  memcpy(raw_ptr,pos,raw_len);
 else
  { 
   return exitsub(reply,M_CM_NOT_MALLOC) ? M_CM_NOT_MALLOC : apiRC;
  }

 cm_buf_init(raw_ptr);          /* get index key from old record */
 cm_buf_get("%l %s %s %s %s ",
             &dummy,q_ipolicy,q_fins_grp,q_remark,q_dexpire);
              
 $BEGIN WORK;

strcpy(sFullName, get_car_full_db(q_ipolicy));

    sprintf_s(stmt, sizeof stmt, "SELECT c.ipolicy,c.fins_grp,c.remark,c.dexpire, "
                   " a.dply_begin,a.dply_end,dtransfer,a.iofficer,(select nname from officer d where d.iofficer = a.iofficer),"
                   " b.iroute,a.ileader,(select nname from officer d where d.iofficer = a.ileader),"
                   " a.iquota,(select nbranch from sa_branch_type e where e.ibranch = a.iquota),"
                   " c.iupdate,c.dupdate,c.icreate,c.dcreate "
                   " FROM %s:ply_relation a, %s:policy b ,reject_policy c"
                   " WHERE a.ipolicy = b.ipolicy "
                   " AND a.ipolicy = c.ipolicy "
                   " AND a.ipolicy = '%s' "
                   " AND c.fins_grp matches '%s' ", sFullName, sFullName, q_ipolicy , q_fins_grp);                  
    /*printf("stmt[%s]\n", stmt); */
    
    $PREPARE prep2 FROM $stmt;
    $EXECUTE prep2 INTO $cur_ipolicy,$cur_fins_grp,$cur_remark,$cur_dexpire,$cur_dply_begin,$cur_dply_end,$cur_dtransfer,$cur_iofficer,$cur_nofficer,$cur_iroute,$cur_ileader,$cur_nleader,$cur_iquota,$cur_nquota,$cur_iupdate,$cur_dupdate,$cur_icreate,$cur_dcreate;   

strcpy(cur_dexpire,cm_from_infdate_100(cur_dexpire));
strcpy(cur_dply_begin, cm_from_infdate_100(cur_dply_begin));
strcpy(cur_dply_end, cm_from_infdate_100(cur_dply_end));
strcpy(cur_dtransfer, cm_from_infdate_100(cur_dtransfer));

  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */

 if (SQLCODE == SQLNOTFOUND)
 {
   MsgCode = M_CM_NOT_FOUND;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
 }

 cm_buf_init(cur_buf);

 cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
             dummy,cur_ipolicy,cur_fins_grp,cur_remark,cur_dexpire,cur_dply_begin,cur_dply_end,cur_dtransfer,cur_iofficer,cur_nofficer,cur_iroute,cur_ileader,cur_nleader,cur_iquota,cur_nquota,cur_iupdate,cur_dupdate,cur_icreate,cur_dcreate);            

 write(1,cur_buf,raw_len);
 write(1,"\n",1);
 write(1,raw_ptr,raw_len);
 write(1,"\n",1);

 printf("cur_buf[%s]\n",cur_buf);
 printf("raw_ptr[%s]\n",raw_ptr);
 
 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
 {
   MsgCode = M_CM_NOT_EQUAL;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
 }

 /* equal, then exec DB operation */

 if ( option == 'D' )
  {

    sprintf_s(stmt_buf, sizeof stmt_buf, "DELETE FROM reject_policy WHERE ipolicy=? "
        " AND fins_grp=?");
    $PREPARE d_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      
     }
    $EXECUTE d_id USING $cur_ipolicy,$cur_fins_grp;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      
     }

   if( is_del_fail ) goto errexit;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
   else if (option == 'U')
  {
   cm_buf_init(command);

   cm_buf_get("%c %s %s %s %s %s %s %s %s %s ",
               &option,DBName,u_ipolicy,u_fins_grp,u_remark,u_dexpire,u_iupdate,u_dupdate,u_icreate,u_dcreate);
   
   strcpy(u_dexpire,cm_to_infdate(u_dexpire));
   printf("u_ipolicy[%s]\n",u_ipolicy);

   /* grasp old key */
   cm_buf_init(raw_ptr);
   cm_buf_get("%l %s %s %s %s %s %s %s %s",&dummy,
        q_ipolicy,q_fins_grp,q_remark,q_dexpire,q_iupdate,q_dupdate,q_icreate,q_dcreate);
   
   $WHENEVER SQLERROR CONTINUE;
    free(raw_ptr);
    sprintf_s(stmt_buf, sizeof stmt_buf,
                "UPDATE reject_policy "
                "    SET (ipolicy,fins_grp,remark,dexpire,iupdate,dupdate)"
                "     = (?,?,?,?,?,current ) "
                " WHERE ipolicy = ? AND fins_grp=?");

    $PREPARE u_id FROM $stmt_buf;
    
    printf(" stmt_buf[%s] \n",stmt_buf);
    
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
     
     }
    
    $EXECUTE u_id USING $u_ipolicy,$u_fins_grp,$u_remark,$u_dexpire,$u_iupdate,$q_ipolicy,$q_fins_grp;
    printf(" sqlca.sqlerrd[2]=[%d] \n",sqlca.sqlerrd[2]);

    if(SQLCODE != 0)
     {
      is_upd_fail = 1;    
     }

     if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {  
        sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO reject_policy "
         " (ipolicy,fins_grp,remark,dexpire,iupdate,dupdate,icreate,dcreate)"
         " VALUES (?,?,?,?,?,current,?,current)");

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        
       }
      $EXECUTE ua_id USING $u_ipolicy,$u_fins_grp,$u_remark,$u_dexpire,$u_iupdate,$u_icreate;

      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        
       }
     }
 
   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }
   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   MsgCode = M_CM_WRONG_OPTION;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
  }

errexit:
  MsgCode = SQLCODE;
  cm_show_sql_err("ca544_update_exec", stmt_buf);
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if(SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True)
   return MsgCode;
  else
   return apiRC;
}