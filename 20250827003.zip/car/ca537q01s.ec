/***********************************************************************/
/*   program id   : ca537p01s.ec                                       */
/*   program name : �z�߰��O�l�v��J�@�~                               */
/*   date written : 05/30/2013                                         */
/*   date modify  : yyyy/mm/dd                                         */
/***********************************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>

#define TRUE 1
#define FALSE 0

$char  DBName[5];
$char  DBName1[5];
$char  errMsg[2048];
$char  errMsg1[2048];
$char  stmp[2048];
char   sApHome[50];
long   rtncode;
FILE   *sfp,*fp;
static char  *bp;
static int   recLen=1024;
$char userid[11];
$char txtfile[101];
$char txtfile1[101];
$char txtfile2[101];
$char ffname[101];
$char outputf[21];
int offset;
$char getfile[300];
$char getfile1[300];
$char getfile2[300];
char delimiter;
$char sStmt[2048];
$char option[2];
$int  ioption;
int i;
long rc;
$date Today;
$char ncode[101];
$char sDaccident[11], sItransno[21], sNadjustment[13];
DBinfo  *list;
int     count_db , k;

long car537_exec();
long car537_outpatient_exec();
long car537_hospital_exec();
long split_policy();
int  unload1();
/*char *trimSymbol();*/

void car537_rollback_rpt();

main(argc, argv)
int argc;
char **argv;
{
    long rc;

    batchinit();
    strcpy(DBName       ,isNULLstr(argv[1]));
    strcpy(userid       ,isNULLstr(argv[2]));
    strcpy(txtfile      ,isNULLstr(argv[3]));    /*�`��*/
    strcpy(txtfile1     ,isNULLstr(argv[4]));    /*�������E�O��*/
    strcpy(txtfile2     ,isNULLstr(argv[5]));    /*�������|�O��*/
    strcpy(option       ,isNULLstr(argv[6]));    /***  1.���ֹͮ���Ӫ�  2.�����J�@�~  ***/
    strcpy(ffname       ,isNULLstr(argv[7]));
    strcpy(sItransno    ,isNULLstr(argv[8]));   /* �{�ǰ���Ǹ� add by sylvia 107.07.18 (1070402002_SC1) */
    strcpy(outputf      ,isNULLstr(argv[9]));

    printf("txtfile[%s]\n",txtfile);
    printf("txtfile1[%s]\n",txtfile1);
    printf("txtfile2[%s]\n",txtfile2);

    rtoday(&Today);     /* get today's datetime */

    ioption = atoi(option);

    if (db_select(DBName) == False)
    {
        EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
        return 0;
    }

    if (option[0] == '2')
    {
       $select ncode
          into $ncode
          from cu_code_data
         where itype = 'CS'
           and icode = 'FILE';
       strcpy(ncode, trim(ncode));
       strcpy(ffname, trim(ffname));

       if (strcmp(ncode,ffname) != 0)
       {
          sprintf(stmp,"�����ɮצW��[%s]�P�W���ֹ蠟�ɮצW��[%s]���P",ffname,ncode);
          EWRITE(userid,FAIL,stmp);
          return FAIL;
       }
    }

    rtncode = getApHome(sApHome);
    if (rtncode < 0)
    {
        EWRITE(userid, M_CM_READ_CONFIG_ERR, "read Config file error!!");
        return FAIL;
    }

    rc=car537_exec();

    $WHENEVER SQLERROR CONTINUE;

    if (rc != M_CM_OK)
    {
        printf("[���楢��]\n");
        strcpy(stmp,"car537_exec ���楢�� ");
        strcat(stmp,errMsg);
        EWRITE(userid,rc,stmp);
        return rc;
    }

    printf("return success\n");
    EWRITE(userid,M_CM_OK,"���O�l�v���B�z�@�~����!");

    return SUCCESS;
}

void GetData(data, maxlen, delimiter)
char *data, delimiter;
int maxlen;
{
int fori, pre_offset, cnt=0;

    data[0]='\0';
    pre_offset = offset;

    for (fori=pre_offset; bp[fori]!=0x00&&bp[fori]!=0x0d&&bp[fori]!=0x0a&&bp[fori]!=delimiter; fori++)
    {
        offset++;
        if (cnt < maxlen-1)
        {
            data[cnt]=bp[fori];
            cnt++;
        }
    }

    offset++; /* ���ܤU�@�� */
    if (cnt==0) data[cnt++]=0x20; /* �L��Ƶ��ť� */
    data[cnt]=0x00;
    printf("pre_offset[%d]offset[%d]len[%d]data[%s]\n", pre_offset, offset, cnt, data);
}

/* ------------------------------------------------------------------------------------------------------- */
long car537_exec()
{
$char iclaim[21];
$char id[11];
/*$long mpay;*/
$char dacc_tmp[15];
$char dclose_tmp[15];
$char mstl_tmp[15];
$char mheal_tmp[15];
$char mpay_tmp[15];
$long lMpay;
$long lMpay_total;
/*$long mpay_total;*/
$int  icnt;
char  sIunit[6], sIbranch_in[BRANCH_ID];
$char ipolicy[21];
$char icard[21];
char  sFullName[20];
$char sIpolicy1[POLICY_NUM_1] , sIpolicy2[POLICY_NUM_2];
$char iverify[21];
$char stmt[4096];
$int  iclose_type_tmp;
$int  iclose_type_last;
$int  iclose_type_heal;
$long mstl_heal;
$char dclose_heal[11];
$char daccident[11];
$char dedr_begin_tmp[11];
$char dedr_end_tmp[11];
$char fedr_status_tmp[3];
$char dendorse_tmp[11];
$long minjured_cover;
$int id1;
$char iadjuster[11];
$int  iself_duty, ioth_duty, ianoth_duty;
$int  qserial;
$char fassured[2];
$char nchi_full[101];
$char aperm_con[121];
$char tstl_remark[61];
$char isettle_type[2];
$char fpay_cond[2];
$char ibank[8];
$char iaccount[15];
$char affiliated[7];
$char iclm_upcomp[3];
$long icount;
$int  ipflag;
$long mstl_heal_total;
$long claim_tmp;
$int  iclose_type_bef;
$char ihealth[2];
$char fvictim_nation[2];
$char fvictim_nation_txt[21];
$char frecover[2];
$char frecover_txt[21];
$char dentry_last[11];
$char dexpire[11];
$char iquota[11];
$char nname[11];
$char dentry_ch[11];
$char unit_id[11];
$char nbranch[31];
$char move_date[11];
$char nbranch_ori[31];
$int  tmp_cnt;
$char qduty_adjuster[4];
$char fsubrogation[2];
$char qduty_adjuster_tmp[4];
$char claim_amount_tmp[15];
/*$long mstl_tmp1;*/
/*$long claim_amount_tmp1;*/
/*$long mpay_tmp1;*/
$char iclaim12[3];

$char sIdatano_tmp[21],sIdatano[21], sYY[5], sMM[3], sDD[3],
      sNnote_claim[100],tmp_dtrans[100];
$int  icnt2, icnt3, rtn, icnt1;
$char sToday[11], sYN[2], iportfolio[11], igroup_profit[21], ibranch[6],
      sfulldb[25], sIcar_type[3], fapply[2], kreserve[6], icohort[5], fterm[2];
$char sTpSQL[500], sMsg[200];


    EXEC SQL WHENEVER SQLERROR GOTO errexit0;
    $SET LOCK MODE TO WAIT 30;

    ipflag = 0;

    printf("sApHome[%s]\n",sApHome);
    printf("txtfile[%s]\n",txtfile);
    sprintf(getfile,"%s/dat/car/%s",sApHome,txtfile);
    printf("getfile[%s]\n",getfile);

    if ((fp=fopen(getfile,"rt"))==NULL)
    {
        return FAIL;
    }

    if ((bp=malloc(recLen))==NULL)
    {
        printf("System malloc failed  !\n");
        return FAIL;
    }

    /* ���j�Ÿ� */
    /* delimiter = '|'; */

    delimiter=''; /* �`�N:���j�Ÿ��� ascii(127) */

    $CREATE TEMP table car537_temp
    (
        iclaim      char(20),
        id          char(10),
        mpay        integer
    )with no log;
    $create index car537_temp_ix_1 on car537_temp(iclaim,id);

    $CREATE TEMP table car537_success
    (
        iclaim     char(20),
        nadjustment char(12),
        ivictim    char(10),
        mpay       integer
    )with no log;

    $CREATE TEMP table car537_success_final
    (
        iclaim        char(20),
        fstl          char(1),
        iclose_type   integer,
        nadjustment char(12),
        ivictim       char(10),
        mpay          integer
    )with no log;


    $CREATE TEMP table car537_check
    (
        iclaim      char(20),
        nadjustment char(12),
        ivictim     char(10),
        ichkno      char(3),
        errmsg      char(800)
    )with no log;


    $CREATE TEMP table car537_errlog
    (
        iclaim      char(20),
        nadjustment char(12),
        ivictim     char(10),
        ierrno      char(3),
        errmsg      char(800)
    )with no log;


    $create temp table car537_chk1
    (
        iclaim			char(20)		not null,	-- �߮׸�
        ivictim     	char(12)        not null,   -- �ƬG���`�HID
        idatano			char(20)		not null	-- ���ɽs��
    )with no log;

    $create temp table car537_temp2
    (
        iclaim			char(20)		not null,	-- �߮׸�
        ivictim     	char(12)        not null,   -- �ƬG���`�HID
        daccident		date			not null,	-- �X�I��
        dclose_ori  	date    		not null,	-- ��߮פ鵲��
        mstl			int     		not null,	-- �z�ߪ��B
        mhealth	    	int 			not null,	-- �������I
        qduty_adjuster  decimal(5,2)    not null,   -- �i�D�v��v
        claim_amount    int         	not null, 	-- �i�D�v�������I���B
        mpay        	int             not null,   -- �i�N����B
        idatano			char(20)		not null,	-- ���ɽs��
        iflag           int                         -- flag�P�_
    )with no log;


    $create temp table car537
     (
        iclaim        char(20),
        dgroup        date,
        ivictim       char(20),
        nvictim       char(20),
        mstl          integer,
        mstl_health   integer
     )with no log;

    $create index car537_ix_1 on car537(iclaim);


    /* 1.1 IFRS�ˮֶ}�� */
    $select first 1 today into $sToday
       from car_code
      where 1=1;

    printf("sToday=[%s]\n",sToday);
    rtn = cm_get_IFRS_DATE(sToday, sYN);
    printf("sToday=[%s], sYN=[%s]\n",sToday,sYN);

    sprintf(stmt,
    " select to_char(daccident,'%%Y%%m%%d') \
        from ca_clm_process    \
       where iclaim  =  ? ");

    $prepare get_dacc from $stmt;

    icnt = 0;
    while(fgets(bp,recLen,fp))
    {
       if (feof(fp)) break;
       offset = 0;


            /* ��ƨ��o���Ǥ��i�ܰ� */
            GetData(iclaim,              sizeof(iclaim)  ,            delimiter);      /*�׸�*/
            GetData(id,                  sizeof(id)      ,            delimiter);      /*���`�H*/
            GetData(dacc_tmp,            sizeof(dacc_tmp),            delimiter);      /*�X�I��*/
            GetData(dclose_tmp,          sizeof(dclose_tmp),          delimiter);      /*�鵲��*/
            GetData(mstl_tmp,            sizeof(mstl_tmp),            delimiter);      /*�z�ߪ��B*/
            GetData(mheal_tmp,           sizeof(mheal_tmp),           delimiter);      /*�������I*/
            GetData(qduty_adjuster_tmp,  sizeof(qduty_adjuster_tmp),  delimiter);      /*�i�D�v��v*/
            GetData(claim_amount_tmp,    sizeof(claim_amount_tmp),    delimiter);      /*�i�D�v�������I���B*/
            GetData(mpay_tmp,            sizeof(mpay_tmp),            delimiter);      /*�i�N����B*/
            GetData(sIdatano_tmp,        sizeof(sIdatano_tmp),        delimiter);      /*���ɽs��*/

            strcpy(iclaim, trim(iclaim));
     printf("��365��iclaim=[%s]\n",iclaim);
            if (strcmp(iclaim,"�׸�") == 0)
            {
               memset(bp, ' ', recLen);
               continue;
            }

            strcpy(id, trim(id));
            strcpy(mstl_tmp,trim(mstl_tmp));
            strcpy(mheal_tmp,trim(mheal_tmp));
            strcpy(qduty_adjuster_tmp, trim(qduty_adjuster_tmp));
            strcpy(claim_amount_tmp, trim(claim_amount_tmp));
            strcpy(mpay_tmp, trim(mpay_tmp));
            strcpy(sIdatano_tmp, trim(sIdatano_tmp));

            printf("iclaim [%s], id [%s], dacc_tmp [%s], dclose_tmp [%s], mstl_tmp [%s], mheal_tmp [%s],qduty_adjuster_tmp[%s] ,claim_amount_tmp[%s],mpay_tmp [%s],sIdatano_tmp[%s]\n",
                    iclaim,id,dacc_tmp,dclose_tmp,mstl_tmp,mheal_tmp,qduty_adjuster_tmp,claim_amount_tmp,mpay_tmp,sIdatano_tmp);


            /* ��z�߸g��W�� */
            $select b.nname, a.ibranch_in, a.ipolicy
               into $sNadjustment, $ibranch, $ipolicy
               from ca_clm_process a, officer b
              where a.adjustment = b.iofficer
                and a.iclaim = $iclaim;

            if (SQLCODE == SQLNOTFOUND)
                strcpy(sNadjustment, "�d�L�z�߸g��");

            ipflag = 0;

            for(i=0;i<strlen(mpay_tmp);i++)
            {
               if (mpay_tmp[i] == ',')
               {
                  ipflag = 1;
                  sprintf(errMsg,"�N����B[%s]���i�H���d����Ÿ�", mpay_tmp);
                  if (ioption != 1) goto errexit0;
                  $insert into car537_errlog(iclaim, nadjustment, ivictim, ierrno,errmsg) values ($iclaim, $sNadjustment, $id, 'E01',$errMsg);
                  break;
               }

               if (!isdigit(mpay_tmp[i]))
               {
                  ipflag = 1;
                  sprintf(errMsg,"�N����B[%s]�����Ʀr", mpay_tmp);
                  if (ioption != 1) goto errexit0;
                  $insert into car537_errlog(iclaim, nadjustment, ivictim, ierrno, errmsg) values ($iclaim, $sNadjustment, $id, 'E02',$errMsg);
                  break;
               }
            }


            /*******************************�ˮֻF�d�ʤ���*********************************************/

              $SELECT a.ibranch_in, b.nname
                 INTO $ibranch, $sNadjustment
                 FROM ca_clm_process a, officer b
                WHERE a.adjustment = b.iofficer
                  AND a.iclaim = $iclaim;

                printf("ibranch=[%s]\n",ibranch);

              strcpy(fsubrogation,"");
              icnt3 = 0;
              sprintf(stmt, "SELECT b.qduty_adjuster, b.fsubrogation, \
                                    (select count(*) from newa%s:settlement where iclaim = c.iclaim \
                                        and fstl = '1' and frecover in ('1','2', '3')) \
                               FROM ca_ver_relation a, ca_clm_victim_data b, newa%s:appraisal c \
                              WHERE a.iverify = b.iclaim \
                                AND b.fvictim_car = 'F' \
                                AND a.iclaim  = c.iclaim \
                                AND c.iacc_license = b.ivictim \
                                AND c.iclaim  = ? ",ibranch, ibranch);

              $prepare b1 from $stmt;
              $execute b1
                  INTO $qduty_adjuster,$fsubrogation,$icnt3
                 using $iclaim;

              printf("stmt=%s\n",stmt);

                 strcpy(qduty_adjuster, trim(qduty_adjuster));
                 printf("qduty_adjuster = [%s]\n",qduty_adjuster);
                 printf("qduty_adjuster_tmp = [%s]\n",qduty_adjuster_tmp);

             if (SQLCODE != SQLNOTFOUND)
             {
                if (qduty_adjuster[0] == '0')
                {
                    sprintf(errMsg,"�߮׸�[%s]�����L�F�d",iclaim);
                    $insert into car537_check (iclaim, nadjustment, ivictim, ichkno, errmsg) values ($iclaim, $sNadjustment, $id, 'E03', $errMsg);
                }

                if ((fsubrogation[0] != 'N') && (strcmp(qduty_adjuster_tmp,qduty_adjuster) != 0))
     	        {
                    ipflag = 1;
                    sprintf(errMsg,"�߮׸�[%s]�A�β�29���N�챡�� ���`�H�N��[%s]�A�����F�d�ʤ���[%s]�P���O�����ѻF�d�ʤ���[%s]���@�P", iclaim, id, qduty_adjuster, qduty_adjuster_tmp);
                    printf("errMsg=[%s]\n",errMsg);
                    $insert into car537_errlog (iclaim, nadjustment, ivictim, ierrno, errmsg) values ($iclaim, $sNadjustment, $id, 'E04', $errMsg);
                }
                else if (fsubrogation[0] != 'N')
                {
                    sprintf(errMsg,"�߮׸�[%s] ���`�H[%s]�A�β�29���N�챡��, �нT�{�O�_�ݽߥI���O��", iclaim, id);
                    $insert into car537_check (iclaim, nadjustment, ivictim, ichkno, errmsg) values ($iclaim, $sNadjustment, $id, 'C01', $errMsg);
                }

                /* ���۰l/�k�l/�۰l��k�l �O�� add by sylvia 111.02.16 (1110121004_SC1) */
                if ((fsubrogation[0] == 'N') && (icnt3 > 0))
                {
                    sprintf(errMsg,"�߮׸�[%s] ���`�H[%s] �߮״����l�v�O��", iclaim, id);
                    $insert into car537_check (iclaim, nadjustment, ivictim, ichkno, errmsg) values ($iclaim, $sNadjustment, $id, 'C17', $errMsg);
                }
             }

         /********************************************************************************************/

            /* ���ɤ��e���ˮ� add by sylvia 107.07.20 */
            if (strlen(sIdatano_tmp) < 2 )
            {
                ipflag = 1;
                sprintf(errMsg,"�߮׸�[%s] ���`�H�N��[%s]�A�ӵ���ƵL�e���ɽs���f�I�I", iclaim, id);
                printf("errMsg=[%s]\n",errMsg);
                $insert into car537_errlog (iclaim, nadjustment, ivictim, ierrno, errmsg) values ($iclaim, $sNadjustment, $id, 'E17', $errMsg);
            }

            /* �]���O�D�v�P�@�׸����P�@���`�H�i��|���h���ӽШD�����p(���O�l�v�L���w���٬G�A���ӨD�v)
               �w�ﭫ�����ɪ��ˮ�, �אּ�i���ˮ֡j�������ܰT��, ���n�����簣�C�G���ˮ֩�G����:
                �������ɭ���,���簣;���e���ɪ��i�H�O�d  modify by sylvia (1081127005_SC1) 109.01.16 */

            icnt2 = 0;
            $select count(*) into $icnt2
              from sysdb:ca_health_recovery
             where iclaim = $iclaim
               and ivictim = $id
               and idatano = $sIdatano_tmp;
            if(icnt2 > 0)
            {
                ipflag = 1;
                sprintf(errMsg,"�߮׸�[%s] ���`�H�N��[%s]�A�������ɦ��G���A�Э��s�T�{�I�I", iclaim, id);
                printf("errMsg=[%s]\n",errMsg);
                $insert into car537_errlog (iclaim, nadjustment, ivictim, ierrno, errmsg) values ($iclaim, $sNadjustment, $id, 'E17', $errMsg);
            }

            icnt2 = 0;
            $select count(*) into $icnt2
              from sysdb:ca_health_recovery
             where iclaim = $iclaim
               and ivictim = $id;
            if(icnt2 > 0)
            {
                $select unique replace(replace(replace(replace(replace( multiset (select date(dcreate) from sysdb:ca_health_recovery
                  where iclaim=$iclaim and ivictim = $id and idatano <> $sIdatano_tmp order by date(dcreate) )::lvarchar, 'MULTISET{',''), 'ROW(''',''),''')',''),'}',''),',','�B')
                   into $tmp_dtrans
                   from sysdb:ca_health_recovery  WHERE iclaim=$iclaim and ivictim = $id and idatano <> $sIdatano_tmp;

                sprintf(errMsg,"�߮׸�[%s] ���`�H�N��[%s]�A���ɽs��[%s] ��[%s]�����ɹL,�Э��s�T�{�I�I", iclaim, id, sIdatano_tmp, trim(tmp_dtrans));
                printf("errMsg=[%s]\n",errMsg);
                $insert into car537_check (iclaim, nadjustment, ivictim, ichkno, errmsg) values ($iclaim, $sNadjustment, $id, 'C16', $errMsg);
            }

            /*----------------------------------------------------------------*/
            /* IFRS�����ˮ� add by sylvia 111.10.18 (1110303007��SC3) */
            /*----------------------------------------------------------------*/
            printf("----- 559 sYN=[%s]-------- \n",sYN);

            /*   1120914001_A01_IFRS17 �t�X��Ʀ^�ɬ����ק�   */
            strcpy(sYN,"N");
            if (strcmp(sYN,"Y") == 0)
            {
                printf("----- 562 -------- \n");
                strcpy(iportfolio, " ");
                strcpy(igroup_profit, " ");

                rc = chk_IFRS_claim("1", ipolicy, iclaim, "21", iportfolio, igroup_profit, &icnt1, sMsg);
                printf("icnt1=[%d]sMsg=[%s]\n",icnt1,sMsg);
                if (icnt1 > 0)
                {
                    ipflag = 1;
                    strcpy(errMsg, sMsg);
                    $insert into car537_errlog (iclaim, nadjustment, ivictim, ierrno, errmsg) values ($iclaim, $sNadjustment, $id, 'E18', $errMsg);
                }
             }

            /*----------------------------------------------------------------*/

            if (ipflag == 0)
            {
               printf("iclaim[%s],id[%s],lMpay[%ld]\n",iclaim,id,mpay_tmp);
               lMpay = atol(mpay_tmp);
               $INSERT INTO car537_temp (iclaim, id, mpay)
                  VALUES ($iclaim, $id, $lMpay);

            }

            /* �g�Jcar537_temp2�ѫ���@�~�ϥ�add by sylvia 107.07.18 ------- */
                strncpy(sYY, &dacc_tmp[0], 4); sYY[4]='\0';
                strncpy(sMM, &dacc_tmp[4], 2); sMM[2]='\0';
                strncpy(sDD, &dacc_tmp[6], 2); sDD[2]='\0';
                sprintf(dacc_tmp,"%s/%s/%s",sMM,sDD,sYY);

                strncpy(sYY, &dclose_tmp[0], 4); sYY[4]='\0';
                strncpy(sMM, &dclose_tmp[4], 2); sMM[2]='\0';
                strncpy(sDD, &dclose_tmp[6], 2); sDD[2]='\0';
                sprintf(dclose_tmp,"%s/%s/%s",sMM,sDD,sYY);

                $insert into car537_temp2
                   (iclaim, ivictim, daccident, dclose_ori, mstl,
                    mhealth, qduty_adjuster, claim_amount, mpay, idatano,iflag)
                 values
                   ($iclaim, $id, $dacc_tmp, $dclose_tmp, $mstl_tmp,
                    $mheal_tmp, $qduty_adjuster_tmp, $claim_amount_tmp, $mpay_tmp, $sIdatano_tmp, $ipflag);

            /* -------------------------------------------------------------- */

            memset(bp, ' ', recLen);
            icnt++;
    }
    printf("--------------607---------\n");

    if (icnt == 0)
    {
        EWRITE(userid, M_CM_NOT_FOUND, "�ɮפ��L���!!");
        return FAIL;
    }

    fclose(fp);

    printf("------- 548 ---------- \n");

    EXEC SQL WHENEVER SQLERROR GOTO errexit;


    printf("------- 553 ---------- \n");
    rc=car537_outpatient_exec();
    printf("------- 556  car537_outpatient_exec , rc = [%d]  iclaim=[%s]---------- \n",rc, iclaim);
    if (rc != M_CM_OK)
    {
        printf("[558 ���楢��]\n");
        strcpy(stmp,"car537_outpatient_exec ���楢�� ");
        strcat(stmp,errMsg);
        EWRITE(userid,rc,stmp);
        return rc;
    }
    printf("------- 564 ---------- \n");
    rc=car537_hospital_exec();
    printf("------- 566  car537_hospital_exec , rc = [%d] iclaim=[%s]---------- \n",rc, iclaim);
    if (rc != M_CM_OK)
    {
        printf("[569���楢��]\n");
        strcpy(stmp,"car537_hospital_exec ���楢�� ");
        strcat(stmp,errMsg);
        EWRITE(userid,rc,stmp);
        return rc;
    }

    printf("------- 576 ---------- \n");

    if ((list=get_db_list(&count_db,DBName)) == (char*)0)
    {
       EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
       return M_CM_NOT_DBLIST;
    }

    /* �����ɤ��e���s�Ӯת��ߥI�b�B����(���car917) add by sylvia 111.02.16 (1110121004_SC1) */
    for(k=0;k<count_db;k++)
    {
        sprintf(stmt,
            "insert into car537 \
             select a.iclaim, max(a.dgroup), a.ivictim, \
                    (select max(b.nchi_full) as nchi_full from cu_customer b \
                      where a.ivictim = b.ifpce_id) ,   \
                    sum(decode(a.fstl,'2',(-1)*(a.mins_stl),a.mins_stl)) as mstl, \
                    sum(decode(a.fstl,'2',(-1)*(a.mstl_health),a.mstl_health)) as mstl_health \
               from %s:ca_stl_victim a, car537_temp c, %s:settlement b  \
              where a.iclaim  = c.iclaim       and a.ivictim = c.id \
                and a.iins_item[1] = 'A'       and a.dgroup is not null  \
                and a.iclaim = b.iclaim        and a.fstl = b.fstl \
                and a.iclose_type = b.iclose_type     and b.istl_flag not in ('7','A') \
              group by 1,3,4 ", list[k].dbname,list[k].dbname);

       printf("stmt[%s]\n",stmt);
       $prepare vic_id2 from $stmt;
       $execute vic_id2;
    }

    $BEGIN WORK;

    icount=0;
    ipflag = 0;
    $DECLARE c_cur CURSOR FOR
      SELECT iclaim, sum(mpay) as mpay
        FROM car537_temp
       GROUP BY iclaim
       ORDER BY iclaim;

    $OPEN c_cur;

    for(;;)
    {
      $FETCH c_cur INTO $iclaim, $lMpay_total;
       if (SQLCODE == SQLNOTFOUND) break;

       ipflag = 0;

       icount++;

       strcpy(sNadjustment, " ");
        sprintf(stmt,
        " select ipolicy, adjustment, date(daccident), affiliated,      \
                 (select nname from officer where iofficer = a.adjustment) \
            from ca_clm_process a                                       \
           where iclaim = ? ");
        $prepare get_base_info from $stmt;
        $execute get_base_info
            into $ipolicy, $iadjuster, $daccident, $affiliated, $sNadjustment
           using $iclaim;
        if (SQLCODE == SQLNOTFOUND)
        {
           strcpy(errMsg,"ca_clm_process �߮׬y�{}�ɸ�Ƨ䤣��");
           $insert into car537_errlog(iclaim, nadjustment, ivictim, ierrno, errmsg) values ($iclaim, ' ', ' ', 'E05', $errMsg);
           ipflag = 1;
           if (ioption != 1) goto errexit;
        }

        strcpy(iclaim12, substring(iclaim,1,2));

        $select iupcomp
           into $iclm_upcomp
           from branch
          where ibranch = $iclaim12;
          if (SQLCODE == SQLNOTFOUND)
          {
             sprintf(errMsg," branch �L�k���z�ߤW�h�����q�N���A�z�߭����s[%s]", iadjuster);
             $insert into car537_errlog(iclaim, nadjustment, ivictim, ierrno, errmsg) values ($iclaim, $sNadjustment, ' ', 'E06',$errMsg);
             ipflag = 1;
             if (ioption != 1) goto errexit;
          }

/*****
        $select a.iupcomp
           into $iclm_upcomp
           from branch a,officer b
          where a.ibranch = b.iapp_unit
            and b.iofficer = $iadjuster;
          if (SQLCODE == SQLNOTFOUND)
          {
             sprintf(errMsg," branch �L�k���z�ߤW�h�����q�N���A�z�߭����s[%s]", iadjuster);
             $insert into car537_errlog(iclaim, ivictim, errmsg) values ($iclaim, ' ', $errMsg);
             ipflag = 1;
             if (ioption != 1) goto errexit;
          }
*****/


        if ((rtncode = split_policy(ipolicy, sIpolicy1, sIpolicy2)) != M_CM_OK)
        {
           sprintf(errMsg, "�O�渹�X[%s]�������O�渹�X�@�B�O�渹�X�G���~", ipolicy);
           $insert into car537_errlog(iclaim, nadjustment, ivictim, ierrno, errmsg) values ($iclaim, $sNadjustment, ' ', 'E07', $errMsg);
           ipflag = 1;
           if (ioption != 1) goto errexit;
        }

        rtncode = cm_get_unit_in(sIpolicy1, DBName,  " ", sIunit,"C3",DBName1,
                                 sIbranch_in);
        if(rtncode != M_CM_OK)
        {
           sprintf(errMsg, "cm_get_unit_in ���o�O���즳�~�A�O�渹�X�G[%s]",ipolicy);
           $insert into car537_errlog(iclaim, nadjustment, ivictim, ierrno, errmsg) values ($iclaim, $sNadjustment, ' ', 'E08', $errMsg);
           ipflag = 1;
           if (ioption != 1) goto errexit;
        }
        /*** �O��(�Y�߮��k��)��Ʈw ***/
        DBName1[2]='\0';
        strcpy(sFullName, get_full_dbname(DBName1));
        printf("sFullName=[%s]\n",sFullName);
        iclose_type_tmp = 0;

        /*** �ˮ֫e�@���z��Y���鵲�A���o���U�@�����z�� ***/
        sprintf(stmt,
        " select first 1 iclose_type, dclose      \
            from %s:settlement                    \
           where iclaim = ?                       \
             and fstl   = '1'                     \
           order by iclose_type desc ", sFullName);

        printf("stmt[%s]\n",stmt);

        $prepare get_last_dclose from $stmt;
        $execute get_last_dclose
            into $iclose_type_tmp, $dclose_tmp:id1
           using $iclaim;

        if (id1 < 0)
        {
           sprintf(errMsg, "�߮׸��X:[%s] �e�@���z��|���鵲�A�e�@���z�ߦ���[%d]", iclaim, iclose_type_tmp);
           $insert into car537_errlog(iclaim, nadjustment, ivictim, ierrno, errmsg) values ($iclaim, $sNadjustment, ' ', 'E09', $errMsg);
           ipflag = 1;
           if (ioption != 1) goto errexit;
        }

        iclose_type_last = iclose_type_tmp;

        if (SQLCODE == SQLNOTFOUND)
        {
           iclose_type_tmp = 1;
        }
        else
        {
           iclose_type_tmp += 1;
        }

         $select iverify
            into $iverify
            from ca_ver_relation
           where iclaim = $iclaim;
        if (SQLCODE == SQLNOTFOUND) strcpy(iverify, iclaim);

        /**** �g�J�p��ѹ�y������ ****/

        sprintf(stmt,
        " select * from %s:stl_oth_dtl where iclaim = ? and fstl = '1' and iclose_type = ?     \
            into temp stl_oth_tmp1 with no log ",sFullName);

        printf("stmt[%s]\n",stmt);

        $prepare get_stl_oth from $stmt;
        $execute get_stl_oth
           using $iclaim, $iclose_type_last;

        sprintf(stmt,
        " update stl_oth_tmp1                       \
             set iclose_type = iclose_type + 1      \
           where iclaim = ? ");

        printf("stmt[%s]\n",stmt);

        $prepare upd_stl_oth from $stmt;
        $execute upd_stl_oth
           using $iclaim;

        if (sqlca.sqlerrd[2] > 0)
        {
           sprintf(stmt,
            " insert into %s:stl_oth_dtl            \
               select * from stl_oth_tmp1 ",sFullName);

           printf("stmt[%s]\n",stmt);

           $prepare ins_stl_oth from $stmt;
           $execute ins_stl_oth;
        }

        $drop table stl_oth_tmp1;

        /****  �g�J�p�����  ****/

        sprintf(stmt,
        " select icard             \
            from %s:ply_relation   \
           where ipolicy = ? ",sFullName);
        printf("stmt[%s]\n",stmt);
        $prepare get_icard from $stmt;
        $execute get_icard
            into $icard
           using $ipolicy;
        if (SQLCODE == SQLNOTFOUND)
        {
           sprintf(errMsg, "ply_relation �̷s�O���ɸ�Ƥ��s�b�A�O�渹�X�G[%s]",ipolicy);
           $insert into car537_errlog(iclaim, nadjustment, ivictim, ierrno, errmsg) values ($iclaim, $sNadjustment, ' ', 'E10', $errMsg);
           ipflag = 1;
           if (ioption != 1) goto errexit;
        }

        iself_duty = 0;
        ioth_duty  = 0;
        ianoth_duty = 0;

        sprintf(stmt,
        " select iself_duty, ioth_duty, ianoth_duty      \
            from %s:settlement                           \
           where iclaim      =  ?                        \
             and fstl        = '1'                       \
             and iclose_type =  ? ",sFullName);
        printf("stmt[%s]\n",stmt);

        printf("777 iclaim[%s] iclose_type_last=[%d]\n",iclaim,iclose_type_last);
        $prepare get_set_duty from $stmt;
        $execute get_set_duty
            into $iself_duty, $ioth_duty, $ianoth_duty
           using $iclaim, $iclose_type_last;

        /* �����ɽs�� add by sylvia 107.07.19 (1070403002_SC1) ------------- */
        $select first 1 idatano into $sIdatano_tmp
           from car537_temp2
          where iclaim = $iclaim
            and iflag = '0';

        strcpy(sNnote_claim," ");
        sprintf(sNnote_claim,"���O�l�v�����J(���ɽs��: %s )�C",sIdatano_tmp);
        printf("791 sIdatano_tmp=[%s]\n",sIdatano_tmp);
        /* ------------------------------------------------------------------ */

        /* �t�X�קאּ���ɫ᪽���鵲,�Gñ�ְ_����,�z��Ѫ��A,ipayno�����n�@����J modify by sylvia 107.07.19 (1070402002_SC1) */
        /* sprintf(stmt,
        " insert into %s:settlement (iclaim, fstl, iclose_type, fcard_class, ipolicy, icard, minj_stl, msettle, ientry, dentry, \
                                     iadjuster, frecover, fsale, istl_recover, ihealth, istl_flag, iself_duty, ioth_duty, ianoth_duty, nnote_claim, freject) \
            values (?, '1', ?, '1', ?, ?, ?, ?, 'car537', current, ?, '0', '0', '1', '3', '4', ?, ?, ?, ' ', 'N') ", sFullName); */

        sprintf(stmt,
            " insert into %s:settlement \
                (iclaim, fstl, iclose_type, fcard_class, ipolicy, \
                  icard, minj_stl, msettle, ientry, dentry, \
                  iadjuster, frecover, fsale, istl_recover, ihealth, \
                  istl_flag, iself_duty, ioth_duty, ianoth_duty, nnote_claim, \
                  freject, ipayno, dvouch_bgn, dvouch_end, vouch_state) \
              values (?, '1', ?, '1', ?, \
                      ?, ?, ?, 'car537', current, \
                      ?, '0', '0', '1', '3', \
                      '4', ?, ?, ?, ?, \
                      'N',  ?, today, today, '130') ", sFullName);
        printf("766:stmt settlement[%s]\n", stmt);
        $prepare ins_settle from $stmt;
        $execute ins_settle
           using $iclaim, $iclose_type_tmp, $ipolicy, $icard, $lMpay_total, $lMpay_total, $iadjuster,
                 $iself_duty, $ioth_duty, $ianoth_duty, $sNnote_claim, $sIdatano_tmp;

       /* �g��Ʀ�ca_health_recovery�A�H�Q����鵲�@�~ add by sylvia 107.07.19 (1070402002_SC1) */
       sprintf(stmt, " insert into sysdb:ca_health_recovery \
                         (iclaim, ivictim, daccident, dclose_ori, mstl, \
                          mhealth, qduty_adjuster, claim_amount, mpay, idatano, \
                          itransno, iclose_type, icreate, dcreate, iqserial, iupdate) \
                       select iclaim, ivictim, daccident, dclose_ori, mstl, \
                          mhealth, qduty_adjuster, claim_amount, mpay, idatano, \
                          '%s', %d, '%s', current, ' ', ' ' \
                         from car537_temp2 where iclaim = '%s' and iflag = '0'",
                    sItransno,iclose_type_tmp,userid,iclaim);
        printf("782:stmt=[%s]\n ",stmt);
        $prepare insert_ca_health_recovery from $stmt;
        $execute insert_ca_health_recovery;
        /* ------------------------------------------------------------------------------------- */

       $select a.fassured, a.nchi_full, b.tstl_remark,
               b.isettle_type, b.fpay_cond, b.ibank, b.iaccount,
               a.aperm_con
          into $fassured, $nchi_full, $tstl_remark,
               $isettle_type, $fpay_cond, $ibank, $iaccount,
               $aperm_con
          from cu_customer a,cu_stl_obj b
         where a.ifpce_id      =   b.ifpce_id
           and a.ifpce_id_ext  =   b.ifpce_id_ext
           and a.ifpce_id      =   '08628407';


        /****  �g�Jñ����  ****/

        sprintf(stmt,
        " select nvl(max(qserial),0) + 1    \
            from ca_sign_receipt        \
           where iclaim = ?             \
             and ifpce_id = '08628407'  \
             and ifpce_id_ext = ' ' ");
        printf("stmt[%s]\n",stmt);
        $prepare get_max_qser from $stmt;
        $execute get_max_qser
            into $qserial
           using $iclaim;

        printf("ca_sign_receipt qserial [%d]\n",qserial);

        sprintf(stmt,
        " insert into ca_sign_receipt (iclaim,ifpce_id,ifpce_id_ext,qserial,mpayment, \
                                       invoice,dreceive,dpaperwork,dentry,dsettle,isign_type,ideliver,   \
                                       pay_kind, fspeed, xfpay_cond, iclose_type, ientry, iupdate, dupdate, icntry, iemail, imobile,tfax,itel,izipcode_con,aperm_con,izip,aperm,ffactory_type) \
            values (?,'08628407',' ',?,?,'','',today,CURRENT,today,'2','',    \
                                       '5', '5', ?, ?, 'car537','car537',current,'9',' ',' ',' ',' ',' ',' ',' ',' ','11' ) ");
        printf("821stmt[%s]\n",stmt);
        $prepare ins_sign from $stmt;
        $execute ins_sign
           using $iclaim, $qserial, $lMpay_total, $fpay_cond, $iclose_type_tmp;

        /****  �g�J�ߥI��H��  ****/

        sprintf(stmt,
        " insert into %s:payment                                     \
            (iclaim, fstl ,iclose_type, ipayment,                    \
             ifpce_id_ext, irepair_shop, fassured,                   \
             nchi_full,npayment,xsettle_type, ipay_area, xptax,      \
             xfpay_cond, xibank, xiaccount, aperm_con,               \
             xastl_obj_c, mpayment, fspeed, pay_kind,                \
             dpaperwork, qserial, iemail, imobile, tfax, izipcode_con)                \
            values                               \
            (?, '1', ?, '08628407',              \
             ' ',' ', ?,                         \
             ?, ?, ?, ?, 0,                      \
             ?, ?, ?, ?,                         \
             ' ', ?, '5','5',                    \
             today, 1, ' ', ' ', ' ', ' ') ",sFullName);

        printf("stmt[%s]\n",stmt);
        $prepare ins_payment from $stmt;
        $execute ins_payment
           using $iclaim, $iclose_type_tmp, $fassured,
                 $nchi_full, $tstl_remark, $isettle_type, $iclm_upcomp,
                 $fpay_cond, $ibank, $iaccount, $aperm_con,
                 $lMpay_total;

        sprintf(stmt,
        " update %s:appraisal                    \
             set minj_stl = minj_stl + ?,        \
                 msettle  = msettle  + ?         \
           where iclaim   = ? ",sFullName);
        printf("stmt[%s]\n",stmt);
        $prepare upd_apprai from $stmt;
        $execute upd_apprai
           using $lMpay_total,$lMpay_total,$iclaim;

        printf("iclaim[%s], iclose_type[%d]\n",iclaim, iclose_type_tmp);

        /* �t�X���ɫ᪽���鵲�Aca_local_stl���A����Ʈw�g�J�@modify by sylvia 107.07.19 (1070403002_SC1) */
        sprintf(stmt,
        " select count(*)                     \
            from ca_local_stl              \
           where iclaim = ?                   \
             and fstl   = '1'                 \
             and iclose_type = ?              \
             and dclose is null ");
        $prepare get_local_cnt from $stmt;
        $execute get_local_cnt into $tmp_cnt using $iclaim, $iclose_type_tmp;
        if (tmp_cnt > 0)
        {
           sprintf(stmt,
            " delete from ca_local_stl     \
               where iclaim = ?               \
                 and fstl = '1'               \
                 and iclose_type = ?          \
                 and dclose is null ");
            $prepare del_local_cnt from $stmt;
            $execute del_local_cnt using $iclaim, $iclose_type_tmp;
        }

        /****   ientry ����car537����H��id  ****/
        /* �t�X���ɫ᪽���鵲,�@�ּg�Jfchoose=1 modify by sylvia 107.07.20 */
        sprintf(stmt,
        " insert into ca_local_stl                              \
             (dentry, ipolicy, icard, iclaim, fstl, iclose_type,   \
              ientry, ibranch, fchoose, userid)                                     \
           values                                                  \
             (today, ?, ?, ?, '1', ?, ?, ?, '1', ?) ");

        printf("stmt[%s]\n",stmt);
        $prepare ins_local_stl from $stmt;
        $execute ins_local_stl
           using $ipolicy, $icard, $iclaim, $iclose_type_tmp, $userid, $iclm_upcomp, $userid;

        $update ca_clm_process
            set re_state = ' '
          where iclaim   = $iclaim;

        /***  �ˮָӽ߮׬O�_���O�����׵L���O�l�v����  ***/
        sprintf(stmt,
        " select first 1 iclose_type, ihealth, frecover   \
            from %s:settlement                \
           where iclaim      = ?             \
             and iclose_type < ?             \
           order by iclose_type desc ",sFullName);
        printf("stmt[%s]\n",stmt);
        $prepare get_last_ihealth from $stmt;
        $execute get_last_ihealth
            into $iclose_type_bef, $ihealth, $frecover
           using $iclaim, $iclose_type_tmp;
        if (SQLCODE != SQLNOTFOUND)
        {
           if (ihealth[0] == '1')
           {
              sprintf(errMsg,"�߮׸� [%s] �W���z��O�����߮׵L���O�l�v���ΡA�W���߰l���� [%d] ", iclaim, iclose_type_bef);
              $insert into car537_check (iclaim, nadjustment, ivictim, ichkno, errmsg) values ($iclaim, $sNadjustment, '', 'C02', $errMsg);
           }

           if ((frecover[0] == '5') || (frecover[0] == '6'))
           {
              if (frecover[0] == '5')
                 strcpy(frecover_txt,"5:�j���I�u��");
              else
                 strcpy(frecover_txt,"6:�j���I�N���u�^");

              sprintf(errMsg,"�߮׸� [%s] �W���z��O�����߮װl�v�O���G[%s]�A�W���߰l���� [%d] ",iclaim, frecover_txt, iclose_type_bef);
              $insert into car537_check (iclaim, nadjustment, ivictim, ichkno, errmsg) values ($iclaim, $sNadjustment, '', 'C03', $errMsg);
           }
        }

        /***  �ˮֲz�߭���W�����z���J��ܤ��A�O�_������¾�ν�¾  ***/
        sprintf(stmt,
        " select first 1 dentry    \
            from %s:settlement     \
           where iclaim = ?        \
           order by dentry desc ", sFullName);

        printf("stmt[%s]\n",stmt);
        $prepare get_last_dentry from $stmt;
        $execute get_last_dentry
            into $dentry_last:id1
           using $iclaim;

        if (id1 >= 0)
        {
           /* sprintf(stmt,
           " select a.dexpire, a.iquota, a.nname, b.nbranch    \
               from officer a, sa_branch_type b     \
              where a.iofficer = ?   \
                and a.iquota   = b.ibranch   \
                and a.dexpire  is not null "); */
           sprintf(stmt,
           " select nvl(a.dexpire,'XXX'), a.iquota, a.nname, b.nbranch    \
               from officer a, sa_branch_type b     \
              where a.iofficer = ?   \
                and a.iquota   = b.ibranch   ");
           printf("stmt[%s]\n",stmt);
           $prepare get_off_quota from $stmt;
           $execute get_off_quota
               into $dexpire, $iquota, $nname, $nbranch_ori
              using $iadjuster;
           if (SQLCODE != SQLNOTFOUND)
           {
           		if(strncmp(dexpire,"XXX",3) == 0)
           		{
           			if (strncmp(iquota,"36",2) != 0 && strncmp(iquota,"L1",2) != 0 && strncmp(iquota,"L2",2) != 0)
           			{
	           			strcpy(dentry_ch,dentry_last+6);
	              	strncat(dentry_ch,dentry_last,2);
	              	dentry_ch[6] = '\0';
	              	strncat(dentry_ch,dentry_last+3,2);
	              	dentry_ch[8] = '\0';
		              sprintf(stmt,
		               " select first 1 a.unit_id, b.nbranch, a.move_date    \
		                   from personal:v_asexpr a,sa_branch_type b    \
		                  where a.empl_no   = ?          \
		                    and a.move_date > ?          \
		                    and a.unit_id  != ?          \
		                    and a.unit_id   = b.ibranch   \
		                  order by move_date desc ");
	              	printf("���� 981:stmt[%s]\n",stmt);
	              	$prepare chk_adj_unit from $stmt;
	              	$execute chk_adj_unit
	                	  into $unit_id, $nbranch, $move_date
	                 	using $iadjuster, $dentry_ch, $iquota;

	              	if (SQLCODE != SQLNOTFOUND)
	              	{
	                	 /* sprintf(errMsg,"�߮׸� [%s] �z�߭� [%s][%s] �� [%s] ����¾�A���e��쬰[%s],�ثe��쬰[%s]",
	                                 iclaim,iadjuster,nname,move_date,nbranch,nbranch_ori); */
	                  sprintf(errMsg,"�߮׸� [%s] �z�߭� [%s][%s] �� [%s] ����¾�A�ثe��쬰[%s]",
	                                 iclaim,iadjuster,nname,move_date,nbranch_ori);
	                 	/* $insert into car537_check (iclaim, nadjustment, ivictim, ichkno, errmsg) values ($iclaim, $sNadjustment, '', 'C05', $errMsg); */
	                 	$insert into car537_errlog (iclaim, nadjustment, ivictim, ierrno, errmsg) values ($iclaim, $sNadjustment, '', 'E16', $errMsg);
	                 	ipflag = 1;
	                 	if (ioption != 1) goto errexit;
	              	}
              	}
           		}
							else
							{
								sprintf(errMsg,"�߮׸� [%s] �z�߭� [%s][%s] �� [%s] ��¾ ",iclaim, iadjuster, nname, dexpire);

	              /* �t�Xcar537���ɫ�Y�ɤ鵲,�G��/��¾�אּ error �� modify by sylvia 107.07.18 (1070402002_SC1)  */
	              /* $insert into car537_check (iclaim, nadjustment, ivictim, ichkno, errmsg) values ($iclaim, $sNadjustment, '', 'C04', $errMsg); */
	              $insert into car537_errlog (iclaim, nadjustment, ivictim, ierrno, errmsg) values ($iclaim, $sNadjustment, '', 'E16', $errMsg);
	              ipflag = 1;
	              if (ioption != 1) goto errexit;
							}
           }
        }


        sprintf(stmt,
        " select id, sum(mpay)            \
            from car537_temp              \
           where iclaim = ?               \
           group by id ");
        printf("stmt[%s]\n",stmt);
        $prepare ivicid from $stmt;
        $declare d_cur cursor for ivicid;
        $open d_cur using $iclaim;
        for(;;)
        {
           $fetch d_cur into $id, $lMpay:id1;
           if (SQLCODE == SQLNOTFOUND) break;
           if ((id1 < 0) || (lMpay == 0))
           {
              lMpay = 0;
              strcpy(errMsg,"���`�H�����i�N����B�� 0");
              $insert into car537_errlog(iclaim, nadjustment, ivictim, ierrno, errmsg) values ($iclaim, $sNadjustment, $id, 'E11', $errMsg);
              ipflag = 1;
              if (ioption != 1) goto errexit;
           }

           /*** �ˮָӨ��`�H�O�_�D����H(���ݰ��O) ***/
           sprintf(stmt,
           " select fvictim_nation        \
               from ca_clm_victim_data    \
              where iclaim  = ?           \
                and ivictim = ? ");
              printf("stmt[%s]\n",stmt);
           $prepare get_nation from $stmt;
           $execute get_nation
               into $fvictim_nation
              using $iverify, $id;

           if (SQLCODE != SQLNOTFOUND)
           {
              if (fvictim_nation[0] != '1')
              {
                 if (fvictim_nation[0] == '2')
                    strcpy(fvictim_nation_txt,"2:�~��H");
                 else if (fvictim_nation[0] == '3')
                    strcpy(fvictim_nation_txt,"3:�k�H");
                 else
                    strcpy(fvictim_nation_txt,"8:����H(ID���~)");

                 sprintf(errMsg,"�߮׸�[%s] ���`�H[%s] ���y�P�_��[%s]", iclaim, id, fvictim_nation_txt);
                 $insert into car537_check (iclaim, nadjustment, ivictim, ichkno, errmsg) values ($iclaim, $sNadjustment, $id, 'C06', $errMsg);
              }
           }
           else
           {
              strcpy(errMsg,"���߮ר��`�H�ɵL�����`�H��ơA���ˬd�d�ҧ@�~");
              $insert into car537_errlog(iclaim, nadjustment, ivictim, ierrno, errmsg) values ($iclaim, $sNadjustment, $id, 'E12', $errMsg);
              ipflag = 1;
              if (ioption != 1) goto errexit;
           }

           /*** �Y ca_app_victim �L�Ө��`�HID �h�s�W�@�� A029 �I�� �ߴڪ��B�� 10 �� ***/
           sprintf(stmt,
           " select count(*)                \
               from %s:ca_app_victim        \
              where iclaim    = ?           \
                and ivictim   = ?           \
                and iins_item = 'A029' ",sFullName);
           printf("stmt[%s]\n",stmt);
           $prepare get_a029_cnt from $stmt;
           $execute get_a029_cnt
               into $icnt
              using $iclaim, $id;

           if (icnt == 0)
           {
              /** ���o��˫O�B ply_ins_type_hist **/

              sprintf(stmt,
              " select first 1 dedr_begin, dedr_end, fedr_status, dendorse, minjured_cover   \
                  from %s:ply_ins_type_hist        \
                 where ipolicy      =  ?           \
                   and iins_type    = '21'         \
                   and fedr_status  <  80          \
                   and dedr_begin  <=  ?           \
                   and dedr_end    >=  ?           \
                 order by dedr_begin DESC, dendorse DESC, fedr_status DESC ",sFullName);

              printf("stmt[%s]\n",stmt);
              $prepare get_cover from $stmt;
              $execute get_cover
                  into $dedr_begin_tmp, $dedr_end_tmp, $fedr_status_tmp, $dendorse_tmp, $minjured_cover
                 using $ipolicy,$daccident,$daccident;
              if (SQLCODE == SQLNOTFOUND)
              {
                 sprintf(errMsg,"ply_ins_type_hist �O����v����ɧ䤣��O�B���,�O�渹�X�G[%s]",ipolicy);
                 $insert into car537_errlog(iclaim, nadjustment, ivictim, ierrno, errmsg) values ($iclaim, $sNadjustment,  $id, 'E13', $errMsg);
                 ipflag = 1;
                 if (ioption != 1) goto errexit;
              }

              sprintf(stmt,
              " insert into %s:ca_app_victim (iclaim, iins_item, ivictim, mcoverage, mapp_cover, mapp_fee, fclose, dappraisal)   \
                  values (?, 'A029', ?, ?, 10, 0, '1', today) ",sFullName);
              printf("stmt[%s]\n",stmt);
              $prepare ins_app_id from $stmt;
              $execute ins_app_id
                 using $iclaim, $id, $minjured_cover;

              sprintf(stmt,
              " insert into %s:ca_app_victim_hist (iclaim, iins_item, ivictim, mcoverage, mapp_cover, mapp_fee, dappraisal,    \
                                                   iupdate, dupdate) \
                  values (?, 'A029', ?, ?, 10, 0, today, ?, today) ",sFullName);
              printf("stmt[%s]\n",stmt);
              $prepare ins_app_hid from $stmt;
              $execute ins_app_hid
                 using $iclaim, $id, $minjured_cover, $userid;
           }
           else
           {
              sprintf(stmt,
              " update %s:ca_app_victim      \
                   set fclose    = '1'       \
                 where iclaim    =  ?        \
                   and iins_item = 'A029'    \
                   and ivictim   =  ? ",sFullName);
              printf("stmt[%s]\n",stmt);
              $prepare upd_fclose from $stmt;
              $execute upd_fclose
                 using $iclaim,$id;
           }

           sprintf(stmt,
           " insert into %s:ca_stl_victim (iclaim, fstl, iclose_type, iins_item, ivictim, mins_stl, flast, mins_proc, mstl_health)  \
               values (?, '1', ?, 'A029', ?, 0, '2', 0, ?) ", sFullName);
              printf("stmt[%s]\n",stmt);
           $prepare ins_stl_id from $stmt;
           $execute ins_stl_id
              using $iclaim, $iclose_type_tmp, $id, $lMpay;

           sprintf(stmt,
           " update ca_clm_victim_data   \
                set fhealth = 'Y'        \
              where iclaim  =  ?         \
                and ivictim =  ? ");
              printf("stmt[%s]\n",stmt);
           $prepare upd_vdata from $stmt;
           $execute upd_vdata
              using $iverify, $id;

           if (ipflag == 0)
           {
              if (ioption != 2)
              {
                 $insert into car537_success(iclaim, nadjustment, ivictim, mpay) values ($iclaim, $sNadjustment, $id, $lMpay);
              }
              else
              {
                 $insert into car537_success_final (iclaim, fstl, iclose_type, nadjustment, ivictim, mpay)
                    values ($iclaim, '1', $iclose_type_tmp, $sNadjustment, $id, $lMpay);
              }
           }

           /***  �ˮ֬O�_�Ө��`�H�W�L20�U,�t�w�鵲�Υ��鵲  ***/
           /* ���ư� settlement.istl_flag = '7' ����� modify by sylvia 108.07.10 (1080710004_SC1)*/
           /* ���ư� settlement.istl_flag = 'A' �j���I�F�d���u�u�^����� modify by sylvia 110.11.11 (1101008002_SC1)*/
           /* sprintf(stmt,
           " select nvl(sum(decode(fstl,'2',(-1)*(mins_stl+mstl_health),mins_stl+mstl_health)),0)    \
               from %s:ca_stl_victim                        \
              where iclaim       =  ?                       \
                and ivictim      =  ?                       \
                and iins_item[1] = 'A'  ", sFullName); */
           sprintf(stmt,
           	"select nvl(sum(decode(a.fstl,'2',(-1)*(a.mins_stl+a.mstl_health),a.mins_stl+a.mstl_health)),0) \
               from %s:ca_stl_victim a, %s:settlement b \
              where a.iclaim = b.iclaim \
                and a.fstl = b.fstl \
                and a.iclose_type = b.iclose_type \
                and a.iclaim       =  ? \
                and a.ivictim      =  ? \
                and a.iins_item[1] = 'A' \
                and b.istl_flag not in ('7','A')   ", sFullName, sFullName);

           printf("stmt[%s]\n",stmt);
           $prepare get_more_20 from $stmt;
           $execute get_more_20
               into $mstl_heal_total
              using $iclaim, $id;
           if (mstl_heal_total > 200000)
           {
              sprintf(errMsg,"�߮׸�[%s] ���`�H[%s] �ߥI���B+�������O�N����B��[%ld],�W�L200,000",iclaim,id,mstl_heal_total);


              /* �쬰check , 108/02/21�K�����իỡ�n�אּ���~ add by sylvia 108.02.21 */
              /* ���ˮֶ��ؤ�"�ߥI���B+�������O�N����B�W�L200,000"�������A�Эקאּ��m���ˮֶ��� add by sylvia 110.07.26 (1100708002_SC1) */
              $insert into car537_check (iclaim, nadjustment, ivictim, ichkno, errmsg) values ($iclaim, $sNadjustment, $id, 'C07', $errMsg);
           }

           /***  �ˮ֬O�_���e���@�L���O�l�v   ***/
           sprintf(stmt,
           " select first 1 iclose_type, dclose,  mstl_health       \
               from %s:ca_stl_victim   \
              where iclaim      = ?    \
                and ivictim     = ?    \
                and iclose_type < ?    \
                and mstl_health > 0    \
              order by iclose_type desc ", sFullName);
              printf("stmt[%s]\n",stmt);
           $prepare get_last_heal from $stmt;
           $execute get_last_heal
               into $iclose_type_heal, $dclose_heal, $mstl_heal
              using $iclaim, $id, $iclose_type_tmp;
           if (SQLCODE != SQLNOTFOUND)
           {
              sprintf(errMsg,"�߮׸�[%s] ���`�H[%s] ���@�L���O�l�v,�鵲��[%s] �N����B[%ld]",iclaim,id,dclose_heal,mstl_heal);
              /* �쬰check , 108/02/21�K�����իỡ�n�אּ���~ add by sylvia 108.02.21 */
              /* 109/01/10�K���q���n�אּcheck  modify by sylvia 109.01.16 */
              $insert into car537_check  (iclaim, nadjustment, ivictim, ichkno, errmsg) values ($iclaim, $sNadjustment, $id, 'C08', $errMsg);
           }

           claim_tmp = 0;
           /***  �ˮָӽ߮׸Ө��`�H�O�_�L�ߴڪ��B  ***/
           sprintf(stmt,
           " select nvl(sum(decode(fstl,'2',mins_stl*(-1),mins_stl)),0)      \
               from %s:ca_stl_victim                  \
              where iclaim      = ?                   \
                and ivictim     = ?  \
                and iins_item[1] = 'A'",sFullName);
              printf("stmt[%s]\n",stmt);
           $prepare get_zero_claim from $stmt;
           $execute get_zero_claim
               into $claim_tmp
              using $iclaim, $id;

           if (claim_tmp == 0)
           {
              sprintf(errMsg,"�߮׸�[%s] ���`�H[%s] ��˳����������L�ߴڪ��B�νߴڪ��B��0",iclaim,id);
              $insert into car537_check (iclaim, nadjustment, ivictim, ichkno, errmsg) values ($iclaim, $sNadjustment, $id, 'C09', $errMsg);
           }
        }
        $close d_cur;
        $free d_cur;

        $update ca_clm_process
            set dsettle = today
          where iclaim  = $iclaim;
    }
    $CLOSE c_cur;
    $FREE  c_cur;

    car537_create_rpt();

    if (ioption != 2)
    {
        printf("ROLLBACK\n");
        $ROLLBACK WORK;

        car537_rollback_rpt();

        $update cu_code_data
            set ncode = $ffname
          where itype = 'CS'
            and icode = 'FILE';
    }
    else
    {
        printf("COMMIT WORK\n");
        $COMMIT WORK;
        EWRITE(userid,M_CM_OK,"���ɧ���!! �нT�{�鵲���G!!");

        printf("�������� car539_call_car5083 �������������� \n");
        /* �I�s�鵲�{�H�����鵲�@�~ add by sylvia 107.05.01 */
        rc = car537_call_car5083();
        printf("rc = [%d]\n");
        printf("*******************************************************");


        $update cu_code_data
            set ncode = ''
          where itype = 'CS'
            and icode = 'FILE';

    }

    return M_CM_OK;

errexit0:
    printf("------> errexit: iclaim[%s] \n", iclaim);
    printf("sStmt[%s]\n",sStmt);
    strcpy(errMsg1, errMsg);
    sprintf(errMsg," �߮׸��X: [%s], ���`�Hid: [%s], errMsg: [%s]\n", iclaim, id, errMsg1);
    rc = cm_show_sql_err("ca537", "");
    return rc;

errexit:
    printf("------> errexit: iclaim[%s] \n", iclaim);
    printf("sStmt[%s]\n",sStmt);
    strcpy(errMsg1, errMsg);
    sprintf(errMsg," �߮׸��X: [%s], ���`�Hid: [%s], errMsg: [%s]\n", iclaim, id, errMsg1);
    rc = cm_show_sql_err("ca537", "");
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}

long split_policy(sIpolicy, sIpolicy1, sIpolicy2)
char *sIpolicy, *sIpolicy1, *sIpolicy2;
{
     strcpy(sIpolicy, trim(sIpolicy));
     printf("begin split_policy\n");

     if (strlen(sIpolicy) > CAR_POLICY_LEN)
     {
        strncpy(sIpolicy1, sIpolicy, CAR_POLICY_LEN);
        sIpolicy1[CAR_POLICY_LEN] = '\0';
        strncpy(sIpolicy2, sIpolicy+CAR_POLICY_LEN, CAR_TARGET_LEN);
        sIpolicy2[CAR_TARGET_LEN] = '\0';
        if (sIpolicy2[0]=='\0' || sIpolicy2[0]==' ') strcpy(sIpolicy2," ");
     }
     else
     {
        strcpy(sIpolicy1,sIpolicy);
        strcpy(sIpolicy2," ");
     }

     printf("---after split_policy -> sIpolicy[%s]\n", sIpolicy);
     printf("---after split_policy -> sIpolicy1[%s]\n", sIpolicy1);
     printf("---after split_policy -> sIpolicy2[%s]\n", sIpolicy2);

     return M_CM_OK;
}

/*****************************�ˮ��������E�O�Τ��e�f�N�X*******************************************/
long car537_outpatient_exec()
{
    $char iclaim[21];
    $char id[11];
    $char data[2];
    $char institutions_tmp[20];
    $char dmedical_tmp[10];
    $char temporary_tmp[50];
    $char diseases[5][10];
    $char sYY[5], sMM[3], sDD[3];
    $int  fchkdate;

    $int icnt;
    static int   recLen=1024;

    printf("sApHome[%s]\n",sApHome);
    printf("txtfile1[%s]\n",txtfile1);
    sprintf(getfile1,"%s/dat/car/%s",sApHome,txtfile1);
    printf("getfile1[%s]\n",getfile1);

    if ((fp=fopen(getfile1,"rt"))==NULL)
    {
        return FAIL;
    }

    if ((bp=malloc(recLen))==NULL)
    {
        printf("System malloc failed  !\n");
        return FAIL;
    }

    /* ���j�Ÿ� */
   /*  delimiter = '|'; */
    delimiter=''; /* �`�N:���j�Ÿ��� ascii(127) */

    icnt = 0;
    while(fgets(bp,recLen,fp))
    {
       if (feof(fp)) break;
       offset = 0;

       /* ��ƨ��o���Ǥ��i�ܰ� */
       GetData(iclaim,            sizeof(iclaim),            delimiter);     /*�߮׸��X*/
       GetData(id,                sizeof(id),                delimiter);     /*���`�H�N��*/
       GetData(data,              sizeof(data),              delimiter);     /*��ƨӷ�*/
       GetData(institutions_tmp,  sizeof(institutions_tmp),  delimiter);     /*��ƾ��c�N��*/
       GetData(dmedical_tmp,      sizeof(dmedical_tmp),      delimiter);     /*�N����*/
       GetData(diseases[0],       sizeof(diseases[0]),       delimiter);     /*�e�f�N��*/
       GetData(diseases[1],       sizeof(diseases[1]),       delimiter);     /*�e�f�N��*/
       GetData(diseases[2],       sizeof(diseases[2]),       delimiter);     /*�e�f�N��*/
       GetData(diseases[3],       sizeof(diseases[3]),       delimiter);     /*�e�f�N��*/
       GetData(diseases[4],       sizeof(diseases[4]),       delimiter);     /*�e�f�N��*/

       strcpy(iclaim, trim(iclaim));
printf("��1404��iclaim=[%s]\n",iclaim);
       if (strcmp(iclaim,"�߮׸��X") == 0)
       {
          memset(bp, ' ', recLen);
          continue;
       }

       strcpy(id, trim(id));
       strcpy(institutions_tmp, trim(institutions_tmp));
       strcpy(dmedical_tmp, trim(dmedical_tmp));

       printf("iclaim [%s], id [%s], data [%s], institutions_tmp [%s], dmedical_tmp [%s], diseases[0] [%s],diseases[1][%s] ,diseases[2][%s],diseases[3] [%s] ,diseases[4] [%s]\n",
                    iclaim,id,data,institutions_tmp,dmedical_tmp,diseases[0],diseases[1],diseases[2],diseases[3],diseases[4]);

       /* ��z�߸g��W�� */
        $select b.nname into $sNadjustment
           from ca_clm_process a, officer b
          where a.adjustment = b.iofficer
            and a.iclaim = $iclaim;

        if (SQLCODE == SQLNOTFOUND)
            strcpy(sNadjustment, "�d�L�z�߸g��");

 printf("��1469�� sNadjustment=[%s]\n",sNadjustment);
       /* �ˮ֤J�|�ɶ��O�_�����`���X�I��ε��פ餤�� */
       strncpy(sYY, &dmedical_tmp[0], 4); sYY[4]='\0';
       strncpy(sMM, &dmedical_tmp[4], 2); sMM[2]='\0';
       strncpy(sDD, &dmedical_tmp[6], 2); sDD[2]='\0';

printf("��1474��iclaim=[%s]dmedical_tmp=[%s]sYY=[%s]sMM=[%s]sDD=[%s]\n",iclaim,dmedical_tmp,sYY,sMM,sDD);

       fchkdate = 1;
       $select case when ((mdy($sMM,$sDD,$sYY) < daccident ) or (mdy($sMM,$sDD,$sYY) > dclose_ori))
               then '1' else '0' end
          into $fchkdate
          from car537_temp2
         where iclaim = $iclaim
           and ivictim = $id;

       if (SQLCODE == SQLNOTFOUND)
            continue;       /* �b�`���䤣���ƴN�����ˮ� add by sylvia 108.02.22 */

printf("��1487��iclaim=[%s]\n",iclaim);

       if (fchkdate == 1)
       {
            sprintf(errMsg,"�������E�O��:�߮׸�[%s] ���`�H�N��[%s] �N����[%s] ���b�X�I��ܵ��פ�϶�",
                    iclaim, id, dmedical_tmp) ;
            $insert into car537_check (iclaim, nadjustment, ivictim, ichkno, errmsg) values ($iclaim, $sNadjustment, $id, 'C14', $errMsg);
       }


	   for (i = 0; i <= 4; i++)
	   {
		   strcpy(diseases[i], trim(diseases[i]));

		   if (diseases[i][0] != ' ' && diseases[i][0] != '\0')
		   {
               /* (1140120002_A01) 1.�̴N�����P�_�N�X�ˮ֭n��2014�~���٬O2023�~�� 2.�N�N�X�qcu_code_data���� ca_clm_code */
               $SELECT icode1
                   FROM ca_clm_code
                   WHERE itype = '09'
                   AND icode1 = $diseases[i]
                   AND icode2 = CASE WHEN CAST($sYY AS INT)  <= '2024' THEN '2014' ELSE '2023' END;

			   printf("diseases[%d]=[%s]\n", i, diseases[i]);

			   if (SQLCODE == SQLNOTFOUND)
			   {
				   sprintf(errMsg, "�������E�O��:�߮׸�[%s]���`�H�N��[%s]��ƨӷ�[%s]��ƾ��c�N��[%s]�N����[%s]�A�e�f�N��[%s]���s�b", iclaim, id, data, institutions_tmp, dmedical_tmp, diseases[i]);
				   $insert into car537_errlog(iclaim, nadjustment, ivictim, ierrno, errmsg) values($iclaim, $sNadjustment, $id, 'E14', $errMsg);

				   printf("errMsg:[%s]\n", errMsg);

				   $delete from car537_temp
					   Where iclaim = $iclaim
					   and id = $id;
			   }
			   else
			   {
                   $SELECT icode1
                       FROM ca_clm_code
                       WHERE itype = '10'
                       AND icode1 = $diseases[i]
                       AND icode2 = CASE WHEN CAST($sYY AS INT) <= '2024' THEN '2014' ELSE '2023' END;

				   if (SQLCODE != SQLNOTFOUND)
				   {
					   $execute get_dacc into $sDaccident using $iclaim;
					   if (SQLCODE == SQLNOTFOUND) strcpy(sDaccident," ");

					   strcpy(sDaccident, trim(sDaccident));

					   sprintf(errMsg,"�������E�O��:�߮׸�[%s]�X�I���[%s]���`�H�N��[%s]��ƨӷ�[%s]��ƾ��c\
�N��[%s]�N����[%s]�A�e�f�N��[%s]��384���P�N�S�˦������e�f�N�X�A����\
�d�O�_�P�߮׬����δN�����O�_���X�I����P���פ���϶��C", iclaim, sDaccident, id, data, institutions_tmp, dmedical_tmp, diseases[i]);

					   $insert into car537_check(iclaim, nadjustment, ivictim, ichkno, errmsg) values($iclaim, $sNadjustment, $id, 'C10', $errMsg);

				   }

                   $SELECT icode1
                       FROM ca_clm_code
                       WHERE itype = '11'
                       AND icode1 = $diseases[i]
                       AND icode2 = CASE WHEN CAST($sYY AS INT) <= '2024' THEN '2014' ELSE '2023' END;

				   if (SQLCODE != SQLNOTFOUND)
				   {
					   $execute get_dacc into $sDaccident using $iclaim;
					   if (SQLCODE == SQLNOTFOUND) strcpy(sDaccident," ");

					   strcpy(sDaccident, trim(sDaccident));

					   sprintf(errMsg, "�������E�O��:�߮׸�[%s]�X�I���[%s]���`�H�N��[%s]��ƨӷ�[%s]��ƾ��c\
�N��[%s]�N����[%s]�A�e�f�N��[%s]��136���P���ץ��㷥���]�G���Y���e�f\
�N�X�A���ˬd�O�_�P�߮׬����δN�����O�_���X�I����P���פ���϶��C", iclaim, sDaccident, id, data, institutions_tmp, dmedical_tmp, diseases[i]);

					   $insert into car537_check (iclaim, nadjustment, ivictim, ichkno, errmsg) values($iclaim, $sNadjustment, $id, 'C11', $errMsg);

				   }
			   }
		   }
	   }

       memset(bp, ' ', recLen);
       icnt++;
    }
printf("��1569��icnt=[%d]\n",icnt);
    if (icnt == 0
)    {
    	  printf("��1572��icnt=[%d]\n",icnt);
        EWRITE(userid, M_CM_NOT_FOUND, "�ɮפ��L���!!");
        return FAIL;
    }
    printf("��1575��icnt=[%d]\n",icnt);
    return M_CM_OK;
    printf("��1577��icnt=[%d]\n",icnt);


    errexit0:
    printf("------> errexit: iclaim[%s] \n", iclaim);
    printf("sStmt[%s]\n",sStmt);
    sprintf(errMsg," �߮׸��X: [%s], ���`�Hid: [%s] ", iclaim, id);
    rc = cm_show_sql_err("ca537_outpatient_exec", "");
    return rc;

}

/*****************************�ˮ��������|�O�Τ��e�f�N�X*******************************************/
long car537_hospital_exec()
{
    $char iclaim[21];
    $char id[11];
    $char data[2];
    $char institutions_tmp[20];
    $char dadmission_tmp[10];
    $char dappearances_tmp[10];
    $char dreport_end_tmp[10];
    $char temporary_tmp[50];
    $char diseases[5][10];
    $char sYY[5], sMM[3], sDD[3];
    $int  fchkdate;

    $int icnt;
    static int   recLen=1024;

    printf("sApHome[%s]\n",sApHome);
    printf("txtfile1[%s]\n",txtfile1);
    sprintf(getfile2,"%s/dat/car/%s",sApHome,txtfile2);
    printf("getfile2[%s]\n",getfile2);

    if ((fp=fopen(getfile2,"rt"))==NULL)
    {
        return FAIL;
    }

    if ((bp=malloc(recLen))==NULL)
    {
        printf("System malloc failed  !\n");
        return FAIL;
    }

    /* ���j�Ÿ� */
    /* delimiter = '|'; */
    delimiter=''; /* �`�N:���j�Ÿ��� ascii(127) */

    icnt = 0;
    while(fgets(bp,recLen,fp))
    {
       if (feof(fp)) break;
       offset = 0;

       /* ��ƨ��o���Ǥ��i�ܰ� */
       GetData(iclaim,            sizeof(iclaim),            delimiter);     /*�߮׸��X*/
       GetData(id,                sizeof(id),                delimiter);     /*���`�H�N��*/
       GetData(data,              sizeof(data),              delimiter);     /*��ƨӷ�*/
       GetData(institutions_tmp,  sizeof(institutions_tmp),  delimiter);     /*��ƾ��c�N��*/
       GetData(dadmission_tmp,    sizeof(dadmission_tmp),    delimiter);     /*�J�|�ɶ�*/
       GetData(dappearances_tmp,  sizeof(dappearances_tmp),  delimiter);     /*�X�|�ɶ�*/
       GetData(dreport_end_tmp,   sizeof(dreport_end_tmp),   delimiter);     /*�ӳ�����*/
       GetData(diseases[0],       sizeof(diseases[0]),       delimiter);     /*�e�f�N��*/
       GetData(diseases[1],       sizeof(diseases[1]),       delimiter);     /*�e�f�N��*/
       GetData(diseases[2],       sizeof(diseases[2]),       delimiter);     /*�e�f�N��*/
       GetData(diseases[3],       sizeof(diseases[3]),       delimiter);     /*�e�f�N��*/
       GetData(diseases[4],       sizeof(diseases[4]),       delimiter);     /*�e�f�N��*/

       strcpy(iclaim, trim(iclaim));
        printf("����iclaim=[%s]\n",iclaim);
       if (strcmp(iclaim,"�߮׸��X") == 0)
       {
          memset(bp, ' ', recLen);
          continue;
       }


       strcpy(id, trim(id));
       strcpy(institutions_tmp, trim(institutions_tmp));
       strcpy(dadmission_tmp,   trim(dadmission_tmp));

       if(strcmp(dappearances_tmp,' ') !=0 )
       {
          strcpy(dappearances_tmp, trim(dappearances_tmp));
       }

       if (strcmp(dreport_end_tmp, ' ') != 0)
       {
           strcpy(dreport_end_tmp, trim(dreport_end_tmp));
       }

       printf("iclaim [%s], id [%s], data [%s], institutions_tmp [%s], dadmission_tmp [%s],dappearances_tmp [%s],dreport_end_tmp [%s]  ,diseases[0] [%s],diseases[1][%s] ,diseases[2][%s],diseases[3] [%s] ,diseases[4] [%s]\n",
                    iclaim,id,data,institutions_tmp,dadmission_tmp,dappearances_tmp, dreport_end_tmp,diseases[0],diseases[1],diseases[2],diseases[3],diseases[4]);

       /* ��z�߸g��W�� */
        $select b.nname into $sNadjustment
           from ca_clm_process a, officer b
          where a.adjustment = b.iofficer
            and a.iclaim = $iclaim;

        if (SQLCODE == SQLNOTFOUND)
            strcpy(sNadjustment, "�d�L�z�߸g��");

       /* �ˮ֤J�|�ɶ��O�_�����`���X�I��ε��פ餤�� */
       strncpy(sYY, &dadmission_tmp[0], 4); sYY[4]='\0';
       strncpy(sMM, &dadmission_tmp[4], 2); sMM[2]='\0';
       strncpy(sDD, &dadmission_tmp[6], 2); sDD[2]='\0';

       fchkdate = 1;
       $select case when ((mdy($sMM,$sDD,$sYY) < daccident ) or (mdy($sMM,$sDD,$sYY) > dclose_ori))
               then '1' else '0' end
          into $fchkdate
          from car537_temp2
         where iclaim = $iclaim
           and ivictim = $id;
       if (SQLCODE == SQLNOTFOUND)
            continue;       /* �b�`���䤣���ƴN�����ˮ� add by sylvia 108.02.22 */

       if (fchkdate == 1)
       {
            sprintf(errMsg,"�������|�O��:�߮׸�[%s] ���`�H�N��[%s] �J�|�ɶ�[%s] ���b�X�I��ܵ��פ�϶�",
                    iclaim, id, dadmission_tmp) ;
            $insert into car537_check (iclaim, nadjustment, ivictim, ichkno, errmsg) values ($iclaim, $sNadjustment, $id, 'C15', $errMsg);
       }


       for(i = 0 ; i <= 4 ; i++)
       {
       	 strcpy(diseases[i], trim(diseases[i]));
	     if(diseases[i][0] != ' ' && diseases[i][0] != '\0')
         {
             /* (1140120002_A01) 1.�̴N�����P�_�N�X�ˮ֭n��2014�~���٬O2023�~�� 2.�N�N�X�qcu_code_data���� ca_clm_code */
             strncpy(sYY, &dreport_end_tmp[0], 4); sYY[4] = '\0';

             $SELECT icode1
                 FROM ca_clm_code
                 WHERE itype = '09'
                 AND icode1 = $diseases[i]
                 AND icode2 = CASE WHEN CAST($sYY AS INT) <= '2024' THEN '2014' ELSE '2023' END;

               printf("diseases[%d]=[%s]\n",i,diseases[i]);

               if (SQLCODE == SQLNOTFOUND)
               {
                 sprintf(errMsg,"�������|�O��:�߮׸�[%s]���`�H�N��[%s]��ƨӷ�[%s]��ƾ��c�N��[%s]�J�|�ɶ�[%s]�X�|�ɶ�[%s]�ӳ�����[%s]�A�e�f�N��[%s]���s�b ", iclaim , id , data , institutions_tmp, dadmission_tmp, dappearances_tmp, dreport_end_tmp, diseases[i]);
                 $insert into car537_errlog(iclaim, nadjustment, ivictim, ierrno, errmsg) values ($iclaim, $sNadjustment, $id, 'E15', $errMsg);

                  printf("1552:errMsg=[%s]\n",errMsg);

                  $delete from car537_temp
                    Where iclaim = $iclaim
                      and id = $id;
               }
               else
               {
                   $SELECT icode1
                       FROM ca_clm_code
                       WHERE itype = '10'
                       AND icode1 = $diseases[i]
                       AND icode2 = CASE WHEN CAST($sYY AS INT) <= '2024' THEN '2014' ELSE '2023' END;

                  if (SQLCODE != SQLNOTFOUND)
                  {
                      $execute get_dacc into $sDaccident using $iclaim;
                      if (SQLCODE == SQLNOTFOUND) strcpy(sDaccident," ");

                      strcpy(sDaccident, trim(sDaccident));

                      sprintf(errMsg,"�������|�O��:�߮׸�[%s]�X�I���[%s]���`�H�N��[%s]��ƨӷ�[%s]��ƾ��c\
�N��[%s]�J�|�ɶ�[%s]�X�|�ɶ�[%s]�ӳ�����[%s]�A�e�f�N��[%s]��384���P�N�S�˦������e\
�f�N�X�A���ˬd�O�_�P�߮׬����Φ��|�ɶ��O�_���X�I����P���פ���϶��C", iclaim, sDaccident, id , data , institutions_tmp, dadmission_tmp, dappearances_tmp, dreport_end_tmp, diseases[i]);

                      $insert into car537_check (iclaim, nadjustment, ivictim, ichkno, errmsg) values ($iclaim, $sNadjustment, $id, 'C12', $errMsg);

                  }

                  $SELECT icode1
                      FROM ca_clm_code
                      WHERE itype = '11'
                      AND icode1 = $diseases[i]
                      AND icode2 = CASE WHEN CAST($sYY AS INT) <= '2024' THEN '2014' ELSE '2023' END;

                  if (SQLCODE != SQLNOTFOUND)
                  {
                      $execute get_dacc into $sDaccident using $iclaim;
                      if (SQLCODE == SQLNOTFOUND) strcpy(sDaccident," ");

                      strcpy(sDaccident, trim(sDaccident));

                      sprintf(errMsg,"�������|�O��:�߮׸�[%s]�X�I���[%s]���`�H�N��[%s]��ƨӷ�[%s]��ƾ��c\
�N��[%s]�J�|�ɶ�[%s]�X�|�ɶ�[%s]�ӳ�����[%s]�A�e�f�N��[%s]��136���P���ץ��㷥���]\
�G���Y���e�f�N�X�A���ˬd�O�_�P�߮׬����Φ��|�ɶ��O�_���X�I����P���פ���϶��C", iclaim, sDaccident, id , data , institutions_tmp, dadmission_tmp, dappearances_tmp, dreport_end_tmp, diseases[i]);

                      $insert into car537_check (iclaim, nadjustment, ivictim, ichkno, errmsg) values ($iclaim, $sNadjustment, $id, 'C13',$errMsg);

                  }
               }
          }
        }

       memset(bp, ' ', recLen);
       icnt++;
    }

    if (icnt == 0)
    {
        EWRITE(userid, M_CM_NOT_FOUND, "�ɮפ��L���!!");
        return FAIL;
    }


    return M_CM_OK;

    errexit0:
    printf("------> errexit: iclaim[%s] \n", iclaim);
    printf("sStmt[%s]\n",sStmt);
    sprintf(errMsg," �߮׸��X: [%s], ���`�Hid: [%s] \n", iclaim, id);
    rc = cm_show_sql_err("car537_hospital_exec", "");
    return rc;

}

long car537_create_rpt()
{
  $char sfilename[41];
  $char stitle[512];
  $char sErrmsg[200];
  $char stmt[512];

  $WHENEVER SQLERROR GOTO errexit;

  if (ioption == 1)
  {
     strcpy(sfilename,"���OK�ֹ���Ӫ�");
     strcpy(stitle,"�߮׸��X\t�z�߸g��\t���`�H�N��\t�i�N����B\t");
     strcpy(stmt," select * from car537_success order by iclaim,ivictim ");
  }
  else
  {
     strcpy(sfilename,"��JOK���Ӫ�");
     strcpy(stitle,"�߮׸��X\t�ߥI�l�v�O\t�߰l����\t�z�߸g��\t���`�H�N��\t�i�N����B\t");
     strcpy(stmt," select * from car537_success_final order by iclaim,fstl,iclose_type,ivictim ");
  }

  rc = unload_file(outputf,"A",sfilename,stitle,stmt);

  if (rc != SUCCESS)
  {
     sprintf(errMsg,"��Ʀ��\�ֹ���Ӫ����ͥ��ѡA���~�T���G%s", sqlca.sqlerrm);
  }

  strcpy(sfilename,"���ˮֹ֮���Ӫ�");
  strcpy(stitle,"�߮׸��X\t�z�߸g��\t���`�H�N��\t���~�N��\t���~�T��\t");

  strcpy(stmt," select * from car537_check order by iclaim,ivictim ");

  rc = unload_file(outputf,"B",sfilename,stitle,stmt);

  if (rc != SUCCESS)
  {
     sprintf(errMsg,"���ˮֹ֮���Ӫ����ͥ��ѡA���~�T���G%s", sqlca.sqlerrm);
  }

  if (ioption == 1)
     strcpy(sfilename,"��ƥ��Ѯֹ���Ӫ�");
  else
     strcpy(sfilename,"��J���ѩ��Ӫ�");

  strcpy(stitle,"�߮׸��X\t�z�߸g��\t���`�H�N��\t���~�N��\t���~�T��\t");

  strcpy(stmt," select * from car537_errlog order by iclaim,ivictim ");

  rc = unload_file(outputf,"C",sfilename,stitle,stmt);

  if (rc != SUCCESS)
  {
     sprintf(errMsg,"��ƥ��Ѯֹ���Ӫ����ͥ��ѡA���~�T���G%s", sqlca.sqlerrm);
  }

  printf(" 1921 *********************************************** \n");

  /* �����ɤ��e���s�Ӯת��ߥI�b�B����(���car917) add by sylvia 111.02.16 (1110121004_SC1) */
  printf(" 1939 *********************************************** \n");
  strcpy(sfilename,"�߰l�b�B���Ӫ�");

  strcpy(stitle,"�߮׸��X\t�J�p���\t���`�HID\t���`�H�m�W\t�z�ߪ��B\t�ߥI���O���B\n");

  strcpy(stmt,"select * from car537 order by iclaim ");

  rc = unload_file(outputf,"D",sfilename,stitle,stmt);

  if (rc != SUCCESS)
  {
     sprintf(errMsg,"�߰l�b�B���Ӫ��G%s", sqlca.sqlerrm);
  }

  printf("1950 ***********************************************\n");

  strcpy(sfilename,"�e�@���z��|���鵲���Ӫ�");

  strcpy(stitle,"�߮׸��X\t�z�߸g��\t���`�H�N��\t���~�T��\t");

  strcpy(stmt," select * from car537_errlog where ierrno = 'E09' order by iclaim,ivictim ");

  rc = unload_file(outputf,"E",sfilename,stitle,stmt);

  if (rc != SUCCESS)
  {
     sprintf(errMsg,"�e�@���z��|���鵲���Ӫ����ͥ��ѡA���~�T���G%s", sqlca.sqlerrm);
  }

  printf(" 1936 *********************************************** \n");



  return SUCCESS;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}

void car537_rollback_rpt()
{
$long kpid;
$char nuserid[11];
$char SysTm[21];
$char filen[31];

  $WHENEVER SQLERROR GOTO errexit;

   kpid = atoi(outputf);

   $SELECT nuserid
      INTO $nuserid
      FROM gb_schedulelog
     WHERE kpid = $kpid;

  strcpy(SysTm, cm_get_sysd());

  strcpy(filen,outputf);
  strcat(filen,"A");
  $INSERT INTO SearchList
          (nuserid,kpid,iform_tp,ksys_grp,
           kpgmid,kform_grp,iprn_type,
           ktot_rows, dcreate, noutfile)
   VALUES ($nuserid,$kpid,"A"," ",
           NULL," "," ",
           0,$SysTm,$filen);

  strcpy(filen,outputf);
  strcat(filen,"B");
  $INSERT INTO SearchList
          (nuserid,kpid,iform_tp,ksys_grp,
           kpgmid,kform_grp,iprn_type,
           ktot_rows, dcreate, noutfile)
   VALUES ($nuserid,$kpid,"B"," ",
           NULL," "," ",
           0,$SysTm,$filen);

  strcpy(filen,outputf);
  strcat(filen,"C");
  $INSERT INTO SearchList
          (nuserid,kpid,iform_tp,ksys_grp,
           kpgmid,kform_grp,iprn_type,
           ktot_rows, dcreate, noutfile)
   VALUES ($nuserid,$kpid,"C"," ",
           NULL," "," ",
           0,$SysTm,$filen);

  strcpy(filen,outputf);
  strcat(filen,"D");
  $INSERT INTO SearchList
          (nuserid,kpid,iform_tp,ksys_grp,
           kpgmid,kform_grp,iprn_type,
           ktot_rows, dcreate, noutfile)
   VALUES ($nuserid,$kpid,"D"," ",
           NULL," "," ",
           0,$SysTm,$filen);

  return;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}

/* ------------------------------------------------------------------------ */
long car537_call_car5083()
{
	int result;
	char p0[201];
	char sApHome[31],command[512],ch_dwritten[11];

	result = getApHome(sApHome);
	if(result < 0)
	{
		printf("read Config file error!!\n");
		return M_CM_READ_CONFIG_ERR;
	}

	strcpy(ch_dwritten , cm_sysd_cdate(cm_get_sysd( )));
    printf("���������� DBName=[%s]userid=[%s]ch_dwritten=[%s]sItransno=[%s]\n",DBName,userid,ch_dwritten,sItransno);

	/* sprintf( p0,"runbatch %s %s car5083 P 4 'A' '%s' '%s' '%s' >/dev/null &", DBName,userid,ch_dwritten,userid,sItransno); */
	sprintf( p0,"runbatch %s %s car5083 P 4 'B' '%s' '%s' '%s' ", DBName,userid,ch_dwritten,userid,sItransno);

	sprintf(command, "%s", p0);
	result = system(command);
	printf("result[%d]\n", result);
	puts("test_data ok");
	return M_CM_OK;

}
/* ------------------------------------------------------------------------- */
