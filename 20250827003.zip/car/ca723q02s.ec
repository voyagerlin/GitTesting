/************************************************************************************/
/*                                                                                  */
/*      PROGRAM : ca723q02s.ec                                                      */
/*      Modify  :                                                                   */
/************************************************************************************/

#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "cmprint.h"
$include sqlca;
$include sqltypes;
#include <decimal.h>
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"
$char   DBName[05];
$char   userid[11];
$char   msgbuf[128];

$char   cdate_tmp1[11],cdate_tmp2[11];
$char   cdate1[11],cdate2[11];
$char   dply_begin[11],dply_end[11],iply_next[21],ipolicy[21];
$char   iapplicant[11],napplicant[121],iassured[11],napplicant[121];
$char   iapplicant_tmp[11],iassured_tmp[11];
$char   napplicant_tmp[123],nassured_tmp[123];
$char   itag[CA_TAG_NUM],ntype[11];
$char   dply_begin_100[11],dply_end_100[11];

$char   stmt[3000];
$char   Full_DBName[31],stmp1[1024];
$int    cnt_next = 0; 

long    rc;
char    outputf[21];
int     count_db = 0,i;
char    sApHome[30];
DBinfo  *list = NULL;

$char stmt_tmp[1024],stmt_tmp2[1024];
       
main (argc, argv)
int argc;
char **argv;
{
	int rtc;
	
	batchinit();
	
	strcpy(DBName,     isNULLstr(argv[1]));
	strcpy(userid,     isNULLstr(argv[2]));
	strcpy(cdate_tmp1, isNULLstr(argv[3]));
	strcpy(cdate_tmp2, isNULLstr(argv[4]));
	strcpy(outputf,    isNULLstr(argv[5]));
	
	printf("cdate_tmp1[%s] cdate_tmp2[%s] \n",cdate_tmp1,cdate_tmp2);
	/*�N����~�ର�褸�~*/
	strcpy(cdate1,cm_to_infdate(cdate_tmp1));
	strcpy(cdate2,cm_to_infdate(cdate_tmp2));
	printf("cdate1[%s] cdate2[%s] \n",cdate1,cdate2);

	rtc = car723_get_db();
	if (rtc != M_CM_OK) 
	{
		EWRITE(userid,rtc,msgbuf);
		return rtc;
	}
	
	if ((rtc=car723_init()) != SUCCESS)
	{
		EWRITE(userid,rtc,msgbuf);
		return rtc;
	}
	if ((rtc=car723_cacul()) != SUCCESS)
	{
		EWRITE(userid, rtc, msgbuf);
		return rtc;
	}
	
	rtc=car723_dtl_rptA();
	if (rtc != SUCCESS)
	{
		EWRITE(userid,rtc,msgbuf);
		return rtc;
	}
}

car723_init()
{
	$WHENEVER SQLERROR goto errexit;

	if(db_select(DBName) == False)
	{
		strcpy(msgbuf,"DB [%s] : is not opened",DBName);
		return M_CM_DB_NOTOPEN;
	}

	sprintf_s(stmt_tmp, sizeof stmt_tmp,"CREATE TEMP TABLE car7232_tmp  "
                      "( "
	                  "  dply_begin    char(10)     ,  "
	                  "  dply_end      char(10)     ,  "
	                  "  iply_next     char(20)     ,  "
	                  "  ipolicy       char(20)     ,  "
	                  "  iapplicant    char(10)     ,  "
	                  "  napplicant    varchar(123) ,  "
	                  "  iassured      char(10)     ,  "
	                  "  nassured      varchar(123) ,  "
	                  "  itag          varchar(%d)  ,  "
	                  "  ntype         char(10)        "
                      ")WITH NO LOG;",CA_TAG_NUM-1);
	$PREPARE stmp FROM $stmt_tmp;
	$EXECUTE stmp;
	
	sprintf_s(stmt_tmp2, sizeof stmt_tmp2,"CREATE TEMP TABLE ply_x  "
                      "( "
	                  "  ipolicy    char(20) ,  "
	                  "  iply_next  char(20)    "
                      ")WITH NO LOG;");
	$PREPARE stmp2 FROM $stmt_tmp2;
	$EXECUTE stmp2;
	
	return SUCCESS;

errexit:
	printf("err[%ld][%s]\n",SQLCODE,sqlca.sqlerrm);
	sprintf_s(msgbuf, sizeof msgbuf,"%s",sqlca.sqlerrm);
	return SQLCODE;
}

car723_cacul()
{

    $WHENEVER SQLERROR goto errexit;
    
	for(i=0;i<count_db;i++) 
	{
		sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy,nvl(a.inext_ply,' ')   "
		               " FROM %s:ply_relation a,%s:policy b,cm_route c  "
		               "WHERE a.ipolicy = b.ipolicy  "
		               "  AND a.fcard_class = '1'  "
		               "  AND a.iofficer = 'R61025F014'  "
		               "  AND b.iroute = c.iroute  "
		               "  AND c.iroute_main = 'I812'  "
		               "  AND a.dply_end >= '%s'  "
		               "  AND a.dply_end <  '%s' ",list[i].dbname,list[i].dbname,cdate1,cdate2);
		printf("--stmt[%s] \n", stmt);
		$PREPARE ply_x1 FROM $stmt;
		$DECLARE ply_x cursor for ply_x1;
		$OPEN ply_x;
	
	    for(;;)
	    {
	    	$FETCH ply_x INTO $ipolicy,$iply_next;
	    	if (SQLCODE==SQLNOTFOUND) break;
	    	
	    	if (strcmp(trim(iply_next),"")!=0)
	    	{
		    	strcpy(Full_DBName,get_car_full_db(iply_next));
		    	sprintf_s(stmp1, sizeof stmp1,"SELECT count(*) FROM %s:ply_relation WHERE ipolicy = '%s' AND iofficer = 'R61025F014';",Full_DBName,iply_next);
		    	$PREPARE ply_next FROM $stmp1;
				$EXECUTE ply_next INTO $cnt_next;
				
				if (cnt_next > 0)
				{ 
					/* Do nothing */	
				}  
				else
				{
					strcpy(iply_next," ");
				}
			}

	    	$INSERT INTO ply_x VALUES ($ipolicy,$iply_next);
	    }
	    $CLOSE ply_x;
	    $FREE ply_x;
	}
    
    for(i=0;i<count_db;i++) 
	{
		sprintf_s(stmt, sizeof stmt, " SELECT a.dply_begin,a.dply_end,a.ipolicy,c.ipolicy,  "
		                "       b.iapplicant,substr(b.napplicant,1,1) || '��' || substr(b.napplicant,3),  "
		                "       b.iassured,substr(b.nassured,1,1) || '��' || substr(b.nassured,3),b.itag,  "
		                "       CASE WHEN a.icar_type IN ('01','02','32','34','35') THEN '�����j���I' ELSE '�T���j���I' END  "
		                "  FROM %s:ply_relation a,%s:policy b,ply_x c  "
		                " WHERE a.ipolicy = b.ipolicy  "
		                "   AND a.fcard_class = '1'  "
		                "   AND a.ipolicy = c.iply_next  "
		                "   AND a.iofficer = 'R61025F014'  "
		                " UNION ALL  "
		                "SELECT a.dply_begin,a.dply_end,' ',a.ipolicy,  "
		                "       b.iapplicant,substr(b.napplicant,1,1) || '��' || substr(b.napplicant,3),  "
		                "       b.iassured,substr(b.nassured,1,1) || '��' || substr(b.nassured,3),b.itag,  "
		                "       CASE WHEN a.icar_type IN ('01','02','32','34','35') THEN '�����j���I' ELSE '�T���j���I' END  "
		                "  FROM %s:ply_relation a,%s:policy b,ply_x c  "
		                " WHERE a.ipolicy = b.ipolicy  "
		                "   AND a.fcard_class = '1'  "
		                "   AND (a.ipolicy = c.ipolicy AND c.iply_next = ' ') ",list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname);             
		printf("--stmt[%s] \n", stmt);

	    $PREPARE ply_data1 FROM $stmt;
	    $DECLARE ply_data cursor for ply_data1;
	    $OPEN ply_data;
	
	    for(;;)
	    {
			$FETCH ply_data INTO $dply_begin,$dply_end,$iply_next,$ipolicy,
			                     $iapplicant,$napplicant_tmp,$iassured,$nassured_tmp,$itag,$ntype;
			       
			if (SQLCODE==SQLNOTFOUND) break;
			
			printf("--dply_begin[%s] \n", dply_begin);
			printf("--dply_end[%s] \n", dply_end);
			strcpy(dply_begin_100,cm_from_infdate_100(dply_begin));
			strcpy(dply_end_100,cm_from_infdate_100(dply_end));
			printf("--dply_begin_100[%s] \n", dply_begin_100);
			printf("--dply_end_100[%s] \n", dply_end_100);
			
			strcpy(iapplicant_tmp,substring(iapplicant,1,4));
    		strcat(iapplicant_tmp,"****");
    		strcat(iapplicant_tmp,substring(iapplicant,9,2));
			
			strcpy(iassured_tmp,substring(iassured,1,4));
    		strcat(iassured_tmp,"****");
    		strcat(iassured_tmp,substring(iassured,9,2));
    		
    		printf("dply_begin[%s],dply_end[%s],iply_next[%s],ipolicy[%s],iapplicant_tmp[%s],napplicant_tmp[%s],iassured_tmp[%s],nassured_tmp[%s],itag[%s],ntype[%s] \n",
    		        dply_begin,dply_end,iply_next,ipolicy,iapplicant_tmp,napplicant_tmp,iassured_tmp,nassured_tmp,itag,ntype);

			$INSERT INTO car7232_tmp
			 VALUES ($dply_begin_100,$dply_end_100,$iply_next,$ipolicy,$iapplicant_tmp,$napplicant_tmp,$iassured_tmp,$nassured_tmp,$itag,$ntype);
	
	    }
	    $CLOSE ply_data;
	    $FREE ply_data;
    }

    return SUCCESS;

errexit:
  printf("err[%ld][%s]\n",SQLCODE,sqlca.sqlerrm);
  sprintf_s(msgbuf, sizeof msgbuf,"%s",sqlca.sqlerrm);
  return SQLCODE;
}

car723_dtl_rptA()
{
    $char sfilename[256],stitle[2048];

    strcpy(sfilename,"�x�s���먮�I��O���\n");

    memset(stmt, 0x00, sizeof(stmt));
   
    sprintf_s(stmt, sizeof stmt," SELECT dply_begin,dply_end,iply_next,ipolicy,iapplicant,napplicant,iassured,nassured,itag,ntype "
                 "   FROM car7232_tmp ");
                 
    sprintf_s(stitle, sizeof stitle,"�_�O��\t�O������\t�s�O�渹\t��O�渹\t�n�O�HID\t�n�O�H\t�Q�O�I�HID\t�Q�O�I�H\t�O�I�Ъ�\t�I�ئW��\t");
    
    rc = unload_file(outputf," ",sfilename,stitle,stmt);
 
    if (rc != SUCCESS)
    {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        exit(1);
    }
    
    $DROP TABLE ply_x;
    $DROP TABLE car7232_tmp;

    return SUCCESS;
      
errexit:
  printf("err[%ld][%s]\n",SQLCODE,sqlca.sqlerrm);
  sprintf_s(msgbuf, sizeof msgbuf,"%s",sqlca.sqlerrm);
  return SQLCODE;
}

long car723_get_db()
{
	int rtc;
	
	if (db_select(DBName) == False) 
	{
		strcpy(msgbuf,"M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	rtc = getApHome(sApHome);
	if (rtc < 0) 
	{
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return rtc;
	}
	
	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) 
	{
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}
	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}