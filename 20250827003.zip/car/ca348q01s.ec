/**********************************************************************/
/*                                                                    */
/*   program id   : ca348q01s.ec                                      */
/*   program name : �Τ@�F�ʹq�l�O��ǿ�@�~                          */
/*                                                                    */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
$include decimal.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "othmsgs.h"
#include "glscom.h"
#include "carmsgs.h"
#include "safeclib.h"

long   rtncode;
int   count_db;
char sApHome[30], errbuf[2048], err[128];
FILE   *fp;
static int   recLen=1024;
static char  *bp;
char delimiter;
int offset;
int  tmp_len;
$int rc, cnt, is_upd_fail = 0;

$char DBName[5], userid[11], file_name[256], type[2];
char outputf[N_FILE+1];
/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;

    batchinit();
    strcpy(DBName,    isNULLstr(argv[1]));
    strcpy(userid,    isNULLstr(argv[2]));
    strcpy(file_name, isNULLstr(argv[3]));
    strcpy(type,      isNULLstr(argv[4]));
    strcpy(outputf,   isNULLstr(argv[5]));
     
    rc = car348_get_db();
    if (rc != M_CM_OK)
       return rc;
    
    rc = getApHome(sApHome);
    if (rc < 0)
    {
    	EWRITE(userid, M_CM_READ_CONFIG_ERR, "read Config file error!!");
        return FAIL;
    }

    rc = car348_insert_batch();
    if (rc != M_CM_OK) {
         printf("error on car348_insert_batch\n");
         EWRITE(userid, rc, errbuf);
         return rc;
     }

     return rc;  
}
/*--------------------------------------------------------------------*/
long car348_get_db()
{
   $whenever sqlerror goto errexit;
   
   if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }
   return M_CM_OK;
   
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car348_insert_batch()
{
	char filename[101], getfile[300];
	$char iyymm[6], ipolicy[21], frenew[3], dftp[20];
	$char tmp_fulldb[64], stmt1[2048], stmt_buf[256], stmt[468];
	$char Dftp[20], Ipolicy[21];
	
	sprintf_s(err,sizeof err, "\n");
	strcat(errbuf, err);
	
	$WHENEVER SQLERROR CONTINUE;

	sprintf_s(filename,sizeof filename, "%s/dat/car/%s", sApHome, file_name); 
	printf("filename[%s]\n", filename);
	sprintf_s(getfile,sizeof getfile, "%s/dat/car/%s", sApHome, file_name);
	
	if ((fp = fopen(getfile, "rt")) == NULL)
  {
  	return SQLCODE;
  }

  if ((bp = malloc(recLen)) == NULL)
  {
  	printf("System malloc failed  !\n");
  	free(bp);
  	return SQLCODE;
  }
	
	delimiter = '\t';  /* ���j�Ÿ� */
	
	$CREATE TEMP table tmp_car348
	(
	iyymm	char(5),
    ipolicy char(20),
    frenew char(1)
    )with no log;
    
    while(fgets(bp, recLen, fp))
    {
    	if (feof(fp)) break;
    	offset = 0;
    	
    	/* ��ƨ��o���Ǥ��i�ܰ� */
    	GetData(iyymm, sizeof(iyymm), delimiter);
    	GetData(ipolicy, sizeof(ipolicy), delimiter);
    	GetData(frenew, sizeof(frenew), delimiter);
    	
    	printf("iyymm[%s],ipolicy[%s],frenew[%s]\n", iyymm, ipolicy, frenew);
    	
    	strcpy(ipolicy, ltrim(ipolicy));printf("\n ipolicy[%s]",ipolicy);
    	strcpy(frenew, trim(frenew));printf("frenew[%s]\n",frenew);
    	
    	$insert into tmp_car348(iyymm, ipolicy, frenew)
    	values ($iyymm, $ipolicy, $frenew);
    }
    fclose(fp);
    
    $BEGIN WORK;
    sprintf_s(stmt1,sizeof stmt1,
  		"select iyymm, ipolicy, frenew from tmp_car348 " );
  		
  		$PREPARE CUR_CAID FROM $stmt1;
  		$DECLARE IDcur_1 CURSOR FOR CUR_CAID;
  		$OPEN IDcur_1;
  		
  		printf("stmt1=[%s]\n",stmt1);
  		printf("iyymm[%s], ipolicy[%s], frenew[%s]\n",iyymm, ipolicy, frenew);
  		
  		for(;;)
  		{
  			$FETCH IDcur_1 INTO $iyymm, $ipolicy, $frenew;
  			
  			if (SQLCODE != 0) break;
  			if(strcmp(type,"2") == 0) /*�R��*/
  			{
  				sprintf_s(stmt,sizeof stmt,
  				   " SELECT dftp "
  				   "   FROM ca_eply_ftp "
  				   "  WHERE ipolicy = '%s' ", ipolicy);
  				   
  				printf("stmt[%s]\n",stmt);
  				
  				$PREPARE Acursora FROM :stmt;
  				$DECLARE bcur CURSOR FOR Acursora;
  				$OPEN bcur;
  				
  				while (1)
  				{
  					$FETCH bcur INTO $Dftp;
  					
  					if(SQLCODE == SQLNOTFOUND) break;
  					if(strcmp(Dftp, "") == 0)
  					{
  						sprintf_s(stmt_buf,sizeof stmt_buf,"DELETE FROM ca_eply_ftp where ipolicy = ? " ); 
  						$PREPARE u_id FROM $stmt_buf;
  						$EXECUTE u_id using $ipolicy;
  					}
  					else
  					{
  						sprintf_s(err,sizeof err, "%s �wFTP����R��\n", ipolicy); printf("err1---%s\n",err);
  						strcat(errbuf, err);
  						continue;
  					}
  					
  					if(SQLCODE == SQLNOTFOUND)
  					{
  						sprintf_s(err,sizeof err , "%s SQLCODE ERROR=[%d]\n", ipolicy, SQLCODE); printf("err2---%s\n",err);
  						strcat(errbuf, err);
  						continue;
  					}
  				}
  				$CLOSE bcur;
  				$FREE bcur;
  			}
  			else /*�s�W*/
  			{
  				printf("----- 650 --- \n");
  				strcpy(tmp_fulldb, get_car_full_db(ipolicy));
  				
  				if (strcmp(tmp_fulldb,"") == 0)
  				{
  					sprintf_s(err,sizeof err, "%s �O��䤣��\n", ipolicy); printf("err1---%s\n",err);
  					strcat(errbuf, err);
  					continue;
  				}
  				printf("******frenew[%s]\n",trim(frenew));
  				if (strcmp(trim(frenew),"0") != 0 && strcmp(trim(frenew),"1") != 0 && strcmp(trim(frenew),"2") != 0)
  				{
  					sprintf_s(err,sizeof err, "%s �s��O��J���~\n", ipolicy); printf("err1�s��---%s\n",err);
  					strcat(errbuf, err);
  					continue;
  				}
  				
  				sprintf_s(stmt,sizeof stmt,
  				" SELECT ipolicy "
  				" FROM %s:ply_relation "
  				" WHERE ipolicy = '%s' ", tmp_fulldb, ipolicy);
  				printf("stmt[%s]\n", stmt);
  				
  				$PREPARE Acursor FROM :stmt;
  				$DECLARE ccur CURSOR FOR Acursor;
  				$OPEN ccur;
  				$FETCH ccur INTO $Ipolicy;
  				
  				if (SQLCODE == SQLNOTFOUND)
  				{
  					sprintf_s(err,sizeof err, "%s �O��䤣��\n", ipolicy); printf("err2---%s\n",err);
  					strcat(errbuf, err);
  					continue;
  				}
  				$CLOSE ccur;
  				$FREE ccur; 
  				
  				sprintf_s(stmt_buf,sizeof stmt_buf,
  				" INSERT INTO ca_eply_ftp "
  				"(iyymm, ipolicy, frenew, icreate, dcreate, iupdate, dupdate) "
  				"VALUES ('%s', '%s', '%s', '%s', current, '%s', current)",
  				iyymm, ipolicy, frenew, userid, userid );
  				printf("688:stmt_buf[%s]\n", stmt_buf);
  				
  				$PREPARE insply FROM $stmt_buf;
  				$EXECUTE insply ;
  				printf("692:ipolicy=[%s]SQLCODE=[%d]\n",ipolicy, SQLCODE);
  				
  				if(SQLCODE != 0)
  				{
  					sprintf_s(err,sizeof err, "%s SQLCODE ERROR=[%d]\n", ipolicy, SQLCODE); printf("err3---%s\n",err);
  					strcat(errbuf, err);
  					continue;
  				}
  			}
  		}
  		$CLOSE IDcur_1;
  		$FREE IDcur_1;
  		printf("errbuf-[%s] \n",errbuf);
  		$COMMIT WORK;
  		
  		$DROP TABLE tmp_car348;
  		strcat(errbuf, "���槹��\n");
  		
  		EWRITE(userid,M_CM_OK,errbuf);
  		return M_CM_OK;

errexit:
     $WHENEVER SQLERROR CONTINUE;
     sprintf_s(errbuf,sizeof errbuf,"SQLCODE[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
	 printf("714:errbuf=[%s]\n",errbuf);
     $ROLLBACK WORK;
     $DROP TABLE tmp_car348;
     sprintf_s(errbuf,sizeof errbuf,"717:SQLCODE[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
     return SQLCODE;
}

long GetData(data, maxlen, delimiter)
char *data, delimiter;
int maxlen;
{
int fori, pre_offset, cnt=0;

    data[0] = '\0';
    pre_offset = offset;

    for (fori = pre_offset; bp[fori]!=0x00&&bp[fori]!=0x0d&&bp[fori]!=0x0a&&bp[fori]!=delimiter; fori++)
    {
        offset++;
        if (cnt < maxlen-1)
        {
            data[cnt] = bp[fori];
            cnt++;
        }
    }

    offset++; /* ���ܤU�@�� */
    if (cnt == 0) data[cnt++]=0x20; /* �L��Ƶ��ť� */
    data[cnt]=0x00;
    printf("pre_offset[%d]offset[%d]len[%d]data[%s]\n", pre_offset, offset, cnt, data);
}
