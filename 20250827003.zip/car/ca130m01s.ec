/************************************************/
/*   PROGRAM : ca130m01s.ec by Ealex            */
/*   DATE    : 2004/03/20                       */
/*             �P�P�M�׸�ƺ��@                 */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"
$include sqlca;

long car130(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    long rtncode;
    long car130_insert(),car130_single_query(),car130_multiple_query();
    long car130_update_exec();
    char option;

    cm_buf_init(command);
    cm_buf_get("%c",&option);
    switch(option)
    {
        case 'A': rtncode=car130_insert(reply);
                  break;
        case 'Q': rtncode=car130_single_query(reply);
                  break;
        case 'M': rtncode=car130_multiple_query(reply);
                  break;
        case 'D': rtncode=car130_delete(reply);
                  break;
        case 'U': rtncode=car130_update(reply);
                  break;         
        case 'B': rtncode=car130_build_officer_N(reply);
                  break;         
/*        case 'D':
        case 'U': rtncode=car130_update_exec(reply,command,com_len);
                  break; */
        default : 
                  return exitsub(reply,M_CM_WRONG_OPTION)?M_CM_WRONG_OPTION:apiRC;
    }
    return(rtncode);
}

/*-----------------------------------------------------------------*/
long car130_insert(reply)
serverReply reply;
{
    $char DBName[5];
    $char iprmt[11],nprmt[31],iins_type[11],iofficer_1[2],ioff_chk[11],dprmt_bgn[11];
    $char dprmt_end[11],iagent[11],fanother[2],iofficera_1[2],ioff_chka[11],fengine[2];
    $int  qins_type,lofficer,iremark,ioff_chk_bgn,ioff_chk_len,qfield_all;
    $int  qfield_chk,qyear,lofficera,iremarka,ioff_chk_bgna,ioff_chk_lena;  
    $char iremark_s[5],cdprmt_bgn[11],cdprmt_end[11], imodule[2], iupgrade[2];
    $long mlimit;
    $char nprmt_full[51],nins_type[65],iins_desc[256] ,iins_wording1[361],flaw[2];
    $char fmail_to[2];
    int tmp_len;
    long MsgCode;
    cm_buf_get("%s",DBName);            
    cm_buf_get("%s %s %d %s %s %d",iprmt,nprmt,&qins_type,iins_type,iofficer_1,&lofficer);
    cm_buf_get("%d %d %d %s %s %s",&iremark,&ioff_chk_bgn,&ioff_chk_len,ioff_chk,dprmt_bgn,dprmt_end);
    cm_buf_get("%s %d %d %d %s %s",iagent,&qfield_all,&qfield_chk,&qyear,fanother,iofficera_1);
    cm_buf_get("%d %d %d %d %s %s",&lofficera,&iremarka,&ioff_chk_bgna,&ioff_chk_lena,ioff_chka,fengine);
    cm_buf_get("%d %s %s",&mlimit, imodule, iupgrade );
    cm_buf_get("%s %s %s %s %s %s",nprmt_full, nins_type, iins_desc, iins_wording1, flaw, fmail_to);
 
    strcpy(dprmt_bgn,cm_to_infdate(dprmt_bgn));
    strcpy(dprmt_end,cm_to_infdate(dprmt_end));


    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $BEGIN WORK;

    $INSERT INTO ca_promote
            (iprmt,nprmt,qins_type,iins_type,iofficer_1,lofficer,iremark,ioff_chk_bgn,
             ioff_chk_len,ioff_chk,dprmt_bgn,dprmt_end,iagent,qfield_all,qfield_chk,qyear,
             fanother,iofficera_1,lofficera,iremarka,ioff_chk_bgna,ioff_chk_lena,ioff_chka,
             fengine,imodule,mlimit,iupgrade,nprmt_full,nins_type,iins_desc ,iins_wording1, flaw,
             fmail_to)
     VALUES ($iprmt,$nprmt,$qins_type,$iins_type,$iofficer_1,$lofficer,$iremark,$ioff_chk_bgn,
             $ioff_chk_len,$ioff_chk,$dprmt_bgn,$dprmt_end,$iagent,$qfield_all,$qfield_chk,$qyear,
             $fanother,$iofficera_1,$lofficera,$iremarka,$ioff_chk_bgna,$ioff_chk_lena,$ioff_chka,
             $fengine,$imodule,$mlimit,$iupgrade,$nprmt_full,$nins_type,$iins_desc,$iins_wording1 ,$flaw,
             $fmail_to);

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);

    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return apiRC;
    }  

    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;
    return api_OKComplete;

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/*-----------------------------------------------------------------*/
long car130_update(reply)
serverReply reply;
{
    $char iprmt[11],nprmt[31],iins_type[11],iofficer_1[2],ioff_chk[11],dprmt_bgn[11];
    $char dprmt_end[11],iagent[11],fanother[2],iofficera_1[2],ioff_chka[11],fengine[2];
    $int  qins_type,lofficer,iremark,ioff_chk_bgn,ioff_chk_len,qfield_all;
    $int  qfield_chk,qyear,lofficera,iremarka,ioff_chk_bgna,ioff_chk_lena;  
    $char iremark_s[5],cdprmt_bgn[11],cdprmt_end[11], imodule[2], iupgrade[2];
    $char DBName[5];
    $char sql_stmt[1024],fmail_to[2];
    $long mlimit;
    $char nprmt_full[51],nins_type[65],iins_desc[256] ,iins_wording1[361] ,flaw[2];
    
    int tmp_len;
    long MsgCode;
    
    cm_buf_get("%s",DBName);            
    cm_buf_get("%s %s %d %s %s %d ",iprmt,nprmt,&qins_type,iins_type,iofficer_1,&lofficer);
    printf("iins_type=[%s] lofficer=[%d]\n", iins_type, lofficer );

    cm_buf_get("%d %d %d %s %s %s ",&iremark,&ioff_chk_bgn,&ioff_chk_len,ioff_chk,dprmt_bgn,dprmt_end);
    printf("dprmt_end=[%s]\n", dprmt_end);

    cm_buf_get("%s %d %d %d %s %s ",iagent,&qfield_all,&qfield_chk,&qyear,fanother,iofficera_1);
    cm_buf_get("%d %d %d %d %s %s ",&lofficera,&iremarka,&ioff_chk_bgna,&ioff_chk_lena,ioff_chka,fengine);
    printf("lofficera=[%d] fengine=[%s]\n", lofficera, fengine );

    cm_buf_get("%d %s %s",&mlimit, imodule, iupgrade);
    
    cm_buf_get("%s %s",nprmt_full, nins_type );
    cm_buf_get("%s",iins_desc );
    cm_buf_get("%s",iins_wording1 );
    cm_buf_get("%s %s",flaw, fmail_to );
 
    strcpy(dprmt_bgn,cm_to_infdate(dprmt_bgn));
    strcpy(dprmt_end,cm_to_infdate(dprmt_end));
    $WHENEVER SQLERROR GOTO errexit;

    printf("mlimit=[%d] imodule=[%s] iupgrade[%s] \n", mlimit, imodule, iupgrade );

/*
    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

*/

    $BEGIN WORK;   
      /*      
	  sprintf_s(sql_stmt, sizeof sql_stmt,"UPDATE dwsdb:spc_proj \
               SET (nprmt,qins_type,iins_type,iofficer_1,lofficer,iremark,ioff_chk_bgn,ioff_chk_len, \
                    ioff_chk,dprmt_bgn,dprmt_end,iagent,qfield_all,qfield_chk,qyear,fanother, \
                    iofficera_1,lofficera,iremarka,ioff_chk_bgna,ioff_chk_lena,ioff_chka,fengine,mlimit, imodule, iupgrade, \
                    nprmt_full,nins_type,iins_desc ,iins_wording1, flaw ) \
            = (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) \
       WHERE iprmt = ? ");*/

	  sprintf_s(sql_stmt, sizeof sql_stmt,"UPDATE ca_promote "
           "    SET (nprmt,qins_type,iins_type,iofficer_1,lofficer,iremark,ioff_chk_bgn,ioff_chk_len, "
           "        ioff_chk,dprmt_bgn,dprmt_end,iagent,qfield_all,qfield_chk,qyear,fanother, "
           "        iofficera_1,lofficera,iremarka,ioff_chk_bgna,ioff_chk_lena,ioff_chka,fengine,mlimit, imodule, iupgrade, "
           "        nprmt_full,nins_type,iins_desc ,iins_wording1, flaw, fmail_to ) "
           " = (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) "
           " WHERE iprmt = ? ");
    	
	  $PREPARE prepU FROM $sql_stmt;
	  $EXECUTE prepU USING 
           $nprmt,$qins_type,$iins_type,$iofficer_1,$lofficer,$iremark,$ioff_chk_bgn,$ioff_chk_len,
           $ioff_chk,$dprmt_bgn,$dprmt_end,$iagent,$qfield_all,$qfield_chk,$qyear,$fanother,
           $iofficera_1,$lofficera,$iremarka,$ioff_chk_bgna,$ioff_chk_lena,$ioff_chka,$fengine,$mlimit,$imodule,$iupgrade,
           $nprmt_full,$nins_type,$iins_desc,$iins_wording1,$flaw,$fmail_to,$iprmt;
          
/*    
    sprintf_s(sql_stmt, sizeof sql_stmt,
           "UPDATE ca_promote \
               SET (nprmt,qins_type,iins_type,iofficer_1,lofficer,iremark,ioff_chk_bgn,ioff_chk_len, \
                    ioff_chk,dprmt_bgn,dprmt_end,iagent,qfield_all,qfield_chk,qyear,fanother, \
                    iofficera_1,lofficera,iremarka,ioff_chk_bgna,ioff_chk_lena,ioff_chka,fengine,mlimit, imodule, iupgrade \
                    nprmt_full,nins_type,iins_desc ,iins_wording1, flaw ) \
                 = ('%s',%d,'%s','%s',%d,%d,%d,%d,'%s','%s','%s','%s',%d,%d,%d,'%s','%s',%d,%d,%d,%d,'%s','%s',%d,'%s','%s','%s','%s','%s','%c','%s') \
             WHERE iprmt='%s'",
           nprmt,qins_type,iins_type,iofficer_1,lofficer,iremark,ioff_chk_bgn,ioff_chk_len,ioff_chk,
           dprmt_bgn,dprmt_end,iagent,qfield_all,qfield_chk,qyear,fanother,iofficera_1,
           lofficera,iremarka,ioff_chk_bgna,ioff_chk_lena,ioff_chka,fengine,mlimit,imodule,iupgrade,
           nprmt_full,nins_type,iins_desc ,iins_wording1, flaw,iprmt);
           
    printf("sql_stmt=[%s]\n",sql_stmt) ;      
        $PREPARE prepU FROM $sql_stmt;
        $EXECUTE prepU;
*/
 	/* $EXECUTE IMMEDIATE $sql_stmt ;    */
 	
    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
       {
        SQLCODE = M_CM_NOT_FOUND;
        goto errexit;
    }
       
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);

    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        
        return apiRC;
    }  

    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;
    return api_OKComplete;
    
   
errexit:
    printf("in errexit car130_update\n");
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
           
/*-----------------------------------------------------------------*/
            
long car130_delete(reply)
serverReply reply;
{
    $char iprmt[11],nprmt[31];	
    $int  iremark;
    $char DBName[5];
    $char sql_stmt[1024];
    int tmp_len;
    long MsgCode;


    cm_buf_get("%s",DBName);
    cm_buf_get("%s",iprmt);
/*    cm_buf_get("%d",&iremark);  */

    $WHENEVER SQLERROR GOTO errexit;
    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
        
    $WHENEVER SQLERROR GOTO errexit;
    $BEGIN WORK;    
      
/*    sprintf_s(sql_stmt, sizeof sql_stmt,"delete from ca_promote \
           where iprmt = '%s' \
             and iremark = %d ",iprmt,iremark); */
    sprintf_s(sql_stmt, sizeof sql_stmt,"delete from ca_promote "
          " where iprmt = '%s'",iprmt);
             
    printf("sql_stmt=[%s]\n",sql_stmt) ;      
 	$EXECUTE IMMEDIATE $sql_stmt ;      
        
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);

    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return apiRC;
    }  

    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;
    return api_OKComplete;

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/*-----------------------------------------------------------------*/

long car130_single_query(reply)
serverReply reply;
{
    $char DBName[5];
    
    $char iprmt[11],nprmt[31],iins_type[11],iofficer_1[2],ioff_chk[11],dprmt_bgn[11];
    $char dprmt_end[11],iagent[11],fanother[2],iofficera_1[2],ioff_chka[11],fengine[2];
    $char lofficer[5],qfield_all[5],iremark_s[5],cdprmt_bgn[11],cdprmt_end[11];
    $char qins_type[5],ioff_chk_bgn[5],ioff_chk_len[5],qfield_chk[5];
    $char qyear[5],lofficera[5],iremarka[5],ioff_chk_bgna[5],ioff_chk_lena[5],imodule[2];
    $char iupgrade[2], fmail_to[2];
    $int  iremark;
    $long mlimit = 0;
    $char nprmt_full[51],nins_type[65],iins_desc[256] ,iins_wording1[361] ,flaw[2];
    $char sql_stmt[2000], sIofficer_ori[11], sNname[11], sIquota[7], sIbus_location[11],
          sIofficerA[11], sIroute[11], sIbigcomp[2],sIcomm_obj[11], sDexpire[11];
    $int  iseq, icount = 0;
    int tmp_len;
    
    cm_buf_get("%s",DBName);
    cm_buf_get("%s",iprmt);
/*    cm_buf_get("%d",&iremark); */

printf(" ------- test1 \n ");
    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

printf(" ------- test2 \n ");
    $SELECT iprmt,nprmt,qins_type,iins_type,iofficer_1,lofficer,iremark,ioff_chk_bgn,ioff_chk_len,ioff_chk,
            dprmt_bgn,dprmt_end,iagent,qfield_all,qfield_chk,qyear,fanother,iofficera_1,
            lofficera,iremarka,ioff_chk_bgna,ioff_chk_lena,ioff_chka,fengine,imodule,mlimit,iupgrade,
            nprmt_full,nins_type,iins_desc ,iins_wording1, flaw, fmail_to
       INTO $iprmt,$nprmt,$qins_type,$iins_type,$iofficer_1,$lofficer,$iremark_s,$ioff_chk_bgn,$ioff_chk_len,
            $ioff_chk,$dprmt_bgn,$dprmt_end,$iagent,$qfield_all,$qfield_chk,$qyear,
            $fanother,$iofficera_1,$lofficera,$iremarka,$ioff_chk_bgna,$ioff_chk_lena,
            $ioff_chka,$fengine,$imodule,$mlimit,$iupgrade,
            $nprmt_full,$nins_type,$iins_desc,$iins_wording1,$flaw, $fmail_to
       FROM ca_promote
      WHERE iprmt = $iprmt;
printf(" ------- test3 \n ");
    if (SQLCODE==SQLNOTFOUND){
	    if (exitsub(reply,M_CM_NOT_FOUND) == True)
	       return M_CM_NOT_FOUND;
	    else
	       return apiRC;
    }    
        

    cm_buf_init(ReplyBuf);

    strcpy(cdprmt_bgn,cm_from_infdate(dprmt_bgn));
    strcpy(cdprmt_end,cm_from_infdate(dprmt_end));
    cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s ",
		M_CM_OK,iprmt,nprmt,qins_type,iins_type,iofficer_1,lofficer,iremark_s,ioff_chk_bgn,
		ioff_chk_len,ioff_chk,cdprmt_bgn,cdprmt_end,iagent,qfield_all,qfield_chk,qyear,fanother,
		iofficera_1,lofficera,iremarka,ioff_chk_bgna,ioff_chk_lena,ioff_chka,fengine);
    cm_buf_put("%l %s %s", mlimit, imodule, iupgrade );
    
    cm_buf_put("%s %s %s %s %s", nprmt_full,nins_type,iins_desc ,iins_wording1, flaw);
    cm_buf_put("%s", fmail_to);
    
    $select count(*) into $icount 
       from ca_promote_officer 
      where iprmt = $iprmt;
        
    cm_buf_put("%d", icount);
    
    
    sprintf_s(sql_stmt, sizeof sql_stmt,"select decode(a.iofficer_ori[1,1],'N',1,'H',2,3), "
                     "        a.iprmt, a.iofficer_ori, b.nname, b.iquota, "
                     "        b.ibus_location,a.iofficer, b.iroute, b.ibigcomp, "
                     "        b.icomm_obj, b.dexpire "
                     "   from ca_promote_officer a, officer b "
                     "  where a.iofficer_ori = b.iofficer "
                     "    and a.iprmt = '%s' "
                     "  order by 1,2,3",iprmt);
                       
    $PREPARE preAB FROM $sql_stmt;
    $DECLARE curAB CURSOR for preAB;            
    $OPEN curAB ;
    printf("sql_stmt=[%s]",sql_stmt);
    for(;;)
    {
        $FETCH curAB INTO $icount, $iprmt, $sIofficer_ori, $sNname, $sIquota,
                          $sIbus_location, $sIofficerA, $sIroute, $sIbigcomp,
                          $sIcomm_obj, $sDexpire;
        if(SQLCODE == SQLNOTFOUND) break;	
        
        cm_buf_put("%s %s %s %s %s ", iprmt,sIofficer_ori,sNname,sIquota,sIbus_location);
        cm_buf_put("%s %s %s %s %s ", sIofficerA,sIroute,sIbigcomp,sIcomm_obj,sDexpire);
    }
    cm_buf_put("%s","OfficerEnd");
    
    tmp_len = cm_buf_len(ReplyBuf);    
    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
   return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}

/*-----------------------------------------------------------------*/


long car130_multiple_query(reply)
serverReply reply;
{
    $char DBName[5];
    $char iprmt[11],nprmt[31],iremark[5];
    $char stmt[1024],bufA[50];
    
    char tmpbuf[4000];
    int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int i,total_count=0;

    cm_buf_get("%s",DBName);
    cm_buf_get("%s",iprmt);
    cm_buf_get("%s",iremark);

    $WHENEVER SQLERROR GOTO errexit;
    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
    
/*    if (iremark[0]!='*') 
       sprintf_s(bufA, sizeof bufA, and iremark = '%d' \n",iremark);   
    else
       strcpy(bufA," ");     */
       
    printf("iremark=[%s] \n",iremark);
     
    if ((strncmp(iremark,"*",1)==0)|(strncmp(iremark," ",1)==0))
       strcpy(bufA," ");
    else
       sprintf_s(bufA, sizeof bufA,"AND iremark = %s ",iremark);
     
    printf("bufA=[%s] \n",bufA);
        
    sprintf_s(stmt, sizeof stmt,"SELECT iprmt,nprmt,iremark "
               "    FROM ca_promote "
               "    WHERE iprmt matches ? %s "
               " ORDER BY iprmt",bufA);
printf("     stmt[%s] \n",stmt);         
    $PREPARE a_id FROM $stmt;
    $DECLARE q_cur CURSOR for a_id;            
    $OPEN q_cur USING $iprmt;
 
printf("iprmt=[%s],iremark=[%s],nprmt=[%s]\n",iprmt,iremark,nprmt);

    for(;;)
    {
        $FETCH q_cur INTO $iprmt,$nprmt,$iremark;
        if(SQLCODE != 0) break;

        cm_buf_init(tmpbuf);
        if( count == 0 )
        {
             cm_buf_res_msg();    /* reserve for MsgCode and count */
             cm_buf_res_count();
        }

printf("iprmt=[%s],iremark=[%s],nprmt=[%s]\n",iprmt,iremark,nprmt);
        cm_buf_put("%s %s %s",iprmt,nprmt,iremark);
        tmp_len = cm_buf_len(tmpbuf);

        if( tmp_len + repbuf_len < 3000 )
        {    /* buffer size less than 4K */
            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else
        {    /* more than 4K, send to client side */
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);

            if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {
                $CLOSE q_cur;
                return apiRC;
            }
            else
            {    /* clear ReplyBuf and count to start all over again */
                replycnt++;

                if(replycnt == 8)
                {    /* more than 30K, client cannot display,error */
                    cm_buf_init(ReplyBuf);
                    cm_buf_put("%l",M_CM_OUT_SPACE);
                    tmp_len = cm_buf_len(ReplyBuf);
                    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                        return apiRC;
                    return M_CM_OUT_SPACE;
                }

                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();    /* reserve for MsgCode and count */
                cm_buf_res_count();
/*printf("[%s][%s]\n",Fclass,Ibigcomp);*/
                cm_buf_put("%s %s %s",iprmt,nprmt,iremark);
                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
            }
        }
    } /* for loop */

    $CLOSE q_cur;
    if(count > 0)
    {    /* break out, at least one record is selected */
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
            return apiRC;
         return api_OKComplete;
    }
    else    /* break out, not any row is found */
    {
        /*return exitsub(reply,M_CA_NBIG_OFFICE) ? M_CA_NBIG_OFFICE : apiRC;*/
          return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND : apiRC;
    }

errexit:
    return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}

/*-----------------------------------------------------------------*/

/* car130_update_exec() not used now*/
long car130_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    $char Fclass[2],Ibigcomp[11],Ibigbranch[21],Ibigoffice[15],Nname[41],Itel[15];
    $char email[41];
    $char cur_Fclass[2],cur_Ibigcomp[11],cur_Ibigbranch[21],cur_Ibigoffice[15],cur_Nname[41],cur_Itel[15];
    $char cur_email[41];
    char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
    int tmp_len,raw_len;
    long dummy;
    long MsgCode;

    $char DBName[5];

    comm = (char *) command;
    cm_buf_init(command);
    cm_buf_get("%c %s",&option,DBName);

    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    /* compare old record and current record, if the record has not been changed
       since last request, update or delete the record, otherwise return errmsg
       to client side */

    /* get old record info from command buffer */

    /* raw_len = *(int *) &comm[com_len];
       memcpy(&raw_len,(void *)&command[com_len],sizeof(int));
    */
    memcpy(&raw_len,&comm[com_len],sizeof(int));
    pos = &comm[com_len+sizeof(int)];
    raw_ptr = malloc(raw_len);
    if(raw_ptr != (char*)0)
        memcpy(raw_ptr,pos,raw_len);
    else
    {
        if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
            return M_CM_NOT_MALLOC;
        else
            return apiRC;
    }

    cm_buf_init(raw_ptr);    /* get index key from old record */
    cm_buf_get("%l %s %s ",&dummy,cur_Fclass,cur_Ibigcomp);
/*printf("[%s][%s]\n",cur_Fclass,cur_Ibigcomp);*/

    $BEGIN WORK;

    printf( "[UPDATE]:SELECT ca_big_office \n");
    $SELECT fclass,ibig_comp,ibig_branch,ibig_office,nname,itel,email
       INTO $Fclass,$Ibigcomp,$Ibigbranch,$Ibigoffice,$Nname,$Itel,$email
       FROM ca_big_office
      WHERE fclass = $cur_Fclass
        AND ibig_comp = $cur_Ibigcomp;

    /* if key value has been changed then SQLNOTFOUND,else put current value
       into cur_buf for comparison */

    if(SQLCODE == SQLNOTFOUND)
    {
        MsgCode = M_CM_NOT_FOUND;
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        if( SQLCODE != 0) MsgCode = SQLCODE;
        return exitsub(reply,MsgCode) ? MsgCode : apiRC;
    }

    cm_buf_init(cur_buf);
/*printf("[%s][%s][%s][%s][%s][%s]\n",Fclass,Ibigcomp,Ibigbranch,Ibigoffice,Nname,Itel);*/
    cm_buf_put("%l %s %s %s %s %s %s %s",dummy,Fclass,Ibigcomp,Ibigbranch,Ibigoffice,Nname,Itel,email);

    if(memcmp(cur_buf,raw_ptr,raw_len) != 0)
    {    /* compare 2 records, not equal */
        MsgCode = M_CM_NOT_EQUAL;
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        if( SQLCODE != 0) MsgCode = SQLCODE;
        return exitsub(reply,MsgCode) ? MsgCode : apiRC;
    }

    /* equal, then exec DB operation */

    if( option == 'D' )
    {
        $DELETE FROM ca_big_office
          WHERE fclass = $cur_Fclass
            AND ibig_comp = $cur_Ibigcomp; 
        cm_buf_init(ReplyBuf);
        cm_buf_put("%l",M_CM_OK);
        tmp_len = cm_buf_len(ReplyBuf);
        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return apiRC;
        }

        $WHENEVER SQLERROR GOTO errexit;
        $COMMIT WORK;
        return api_OKComplete;
    }
    else if(option == 'U')
    {
        cm_buf_init(command);
        cm_buf_get("%c %s %s %s %s %s %s %s %s",
	            &option,DBName,Fclass,Ibigcomp,Ibigbranch,Ibigoffice,Nname,Itel,email);

        $UPDATE ca_big_office
            SET (fclass,ibig_comp,ibig_branch,ibig_office,nname,itel,email)
              = ($Fclass,$Ibigcomp,$Ibigbranch,$Ibigoffice,$Nname,$Itel,$email)
          WHERE fclass = $cur_Fclass
            AND ibig_comp = $cur_Ibigcomp;
 
        if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
        {
            $INSERT INTO ca_big_office
                    (fclass,ibig_comp,ibig_branch,ibig_office,nname,itel,email)
             VALUES ($Fclass,$Ibigcomp,$Ibigbranch,$Ibigoffice,$Nname,$Itel,$email);
        }

        cm_buf_init(ReplyBuf);
        cm_buf_put("%l",M_CM_OK);
        tmp_len = cm_buf_len(ReplyBuf);
        
        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return apiRC;
        }

        $WHENEVER SQLERROR GOTO errexit;
        $COMMIT WORK;
        return api_OKComplete;
    }
    else
    {
        return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
    }

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/*-----------------------------------------------------------------*/
/* ���sN�g��N�� (���s��r�ɴ��ѤU��) add by sylvia 103.09.25 (1030630002_C1) */
long car130_build_officer_N(reply)
serverReply reply;
{
   $char DBName[5], msgbuf[200];
   $char userid[7], iprmt[5], iagent[2], iofficerA13[200], iofficerB13[10],sTmp1[2000];
   $char iofficer[11], nname[11], ibranch[3], iupcomp[2], ibigcomp[2], iquota[7], 
         imgr[2], fprop[2], iapp_unit[3], iins_cat[2], ibus_location[11], 
         ileader[11], fadjuster[2], sbus_source[21], fnotes_take[2],icreator[11], 
         dcreate[11], iupdate[11], dupdate[11], dexpire[11], imaker[3], idealer[4], 
         remark[21], fcalc[2], fedr_m[2], fcredit[2], iroute[21], comm_cond[2], 
         froute[2], fletter[2], iquota_letter[7], ftax[2], froute_auto[2], 
         icomm_obj[11], irate_type[2], iroute_comm[4], iroute_prop[3], fenterprise[2];
   $int qover, row_guid, icount;
   $double pagent_commit, pbusi_commit;
   $int  rc;
   int tmp_len;
   char sApHome[30];
   char  filename[50],fname[50],errmsg[81];
   FILE   *fp;
   
   cm_buf_get("%s",DBName);            
   cm_buf_get("%s %s %s %s ",userid, iprmt,iofficerB13,iofficerA13);

   strcpy(iprmt, trim(iprmt));   /* �M�ץN�� */
   strcpy(iofficerB13, trim(iofficerB13));  /* B* �g��N�� */
   strcpy(iofficerA13, trim(iofficerA13));  /* A* �g��N�� */

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
   		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
         
   rc = getApHome(sApHome);
   if (rc < 0) 
   {
	   strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return rc;
   }
         
   /* �g��N�����Ȧs�� */   
   $select * from officer where 1=0 into temp tmp_officer;     

   printf("---731---\n");
   strcpy(sTmp1," ");
   /* --- B* �g��N�� -------------------------------------------------- */
   if (strlen(iofficerB13) > 0)
   {
      printf("B* �g��N��---736---\n");
      sprintf_s(sTmp1, sizeof sTmp1,"insert into tmp_officer "
                  "  select case when iofficer[6,6] < 6 then "
                  "         'N'||iofficer[2,5]||round(iofficer[6,6]+4)||'%s' else "
                  "         'N'||iofficer[2,5]||round(iofficer[6,6]-6)||'%s' end, "
                  "         nname, ibranch, iupcomp, ibigcomp, iquota, imgr, 'E', "
                  "         iapp_unit, iins_cat, trim(ibus_location)||'%s', "
                  "         '881803', fadjuster, '%s', qover, ' ', pagent_commit, "
                  "         pbusi_commit, '990389', today, '990389', today, dexpire, "
                  "         imaker, idealer, iofficer, fcalc, fedr_m, fcredit, iroute, "
                  "         comm_cond, froute, '1', '320102', ftax, froute_auto, "
                  "         'NB01', irate_type, iroute_comm, iroute_prop, 'N', 0 "
                  "    from officer "
                  "   where iofficer[1,1] = 'B' and imgr = '1' and dexpire is null; ",
                      iprmt, iprmt, iprmt, iprmt);
                      
      printf("B*:sTmp1=[%s]\n",sTmp1);
      $PREPARE pre_budB FROM $sTmp1;
      $EXECUTE pre_budB;
      
      $select count(*) into $icount
         from tmp_officer
        where remark[1,1] = 'B';
      
      printf("B*�@ %d �� \n",icount);
   }
   
   if (strlen(iofficerA13) > 0)
   {
      /* --- A* �g��N�� -------------------------------------------------- */
      sprintf_s(sTmp1, sizeof sTmp1,"insert into tmp_officer "
                 "   select case when iofficer[6,6] = 9 then "
                 "          'N'||iofficer[2,5]||'0'||'%s' else "
                 "          'N'||iofficer[2,5]||round(iofficer[6,6]+1)||'%s' end, "
                 "          nname, ibranch, iupcomp, ibigcomp, iquota, imgr, 'E', "
                 "          iapp_unit, iins_cat, trim(ibus_location)||'%s', "
                 "          '881803', fadjuster, '%s', qover, ' ', pagent_commit, "
                 "          pbusi_commit,'990389', today, '990389', today, dexpire, "
                 "          imaker, idealer, iofficer, fcalc, fedr_m, fcredit, "
                 "          iroute, comm_cond, froute, '1', '320102', ftax, "
                 "          froute_auto, 'NA01', irate_type, iroute_comm, iroute_prop, 'N', 0 "
                 "     from officer "
                 "    where iofficer[1,3] in (%s) and dexpire is null and imgr = '1';",
                      iprmt, iprmt, iprmt, iprmt, iofficerA13);
      
      printf("A*:sTmp1=[%s]\n",sTmp1);
      $PREPARE pre_budA FROM $sTmp1;
      $EXECUTE pre_budA;
      
      $select count(*) into $icount
         from tmp_officer
        where remark[1,1] = 'A';
      
      printf("A*�@ %d �� \n",icount);
   }
   
   $select count(*) into $icount
     from tmp_officer
    where 1=1;
   
   printf("�ظmN�g��@�� %d ��\n",icount);
   if (icount == 0)
   {
         $drop table tmp_officer;
	      cm_buf_init(ReplyBuf);
         cm_buf_put("%l %d", M_CM_OK, icount);
         tmp_len = cm_buf_len(ReplyBuf);    
      
         if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
              return apiRC;
         else
              return api_OKComplete;
   }
   
   printf("--- 801 --- \n");
   strcpy(filename," ");
   sprintf_s(fname, sizeof fname,"�ظm %s �M��N�g��N��.txt",iprmt);
   sprintf_s(filename, sizeof filename,"%s/rptftp/%s",sApHome,fname);
   fp=fopen(filename,"w");
   
   sprintf_s(sTmp1, sizeof sTmp1,"select * from tmp_officer ");
   
   $PREPARE pri_buld2 FROM $sTmp1;
   $DECLARE cur_buld2 CURSOR FOR pri_buld2;
   $OPEN cur_buld2;
   
   for(;;)
   {
       $FETCH cur_buld2 INTO $iofficer, $nname, $ibranch, $iupcomp, $ibigcomp, 
                             $iquota, $imgr,$fprop, $iapp_unit, $iins_cat, 
                             $ibus_location, $ileader, $fadjuster, $sbus_source, 
                             $qover, $fnotes_take, $pagent_commit, $pbusi_commit,
                             $icreator, $dcreate, $iupdate, $dupdate, $dexpire, 
                             $imaker, $idealer, $remark, $fcalc, $fedr_m, $fcredit, 
                             $iroute, $comm_cond, $froute, $fletter, $iquota_letter, 
                             $ftax, $froute_auto, $icomm_obj, $irate_type, 
                             $iroute_comm, $iroute_prop, $fenterprise, $row_guid;
                             
       if (SQLCODE == SQLNOTFOUND) break;

       fprintf(fp,"%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%d|%s|%.4f|%.4f|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%s|%d|\n",
                             iofficer, nname, ibranch, iupcomp, ibigcomp, 
                             iquota, imgr, fprop, iapp_unit, iins_cat, 
                             ibus_location, ileader, fadjuster, sbus_source,
                             qover, fnotes_take, pagent_commit, pbusi_commit, 
                             icreator, dcreate, iupdate, dupdate, dexpire,
                             imaker, idealer, remark, fcalc, fedr_m, fcredit,
                             iroute, comm_cond, froute, fletter, iquota_letter, 
                             ftax, froute_auto, icomm_obj, irate_type, 
                             iroute_comm, iroute_prop, fenterprise, row_guid);
   }
   $CLOSE cur_buld2;
   $FREE  cur_buld2;
   fclose(fp);

   rc=rptftpinsert(userid,"car130",fname);
   if (rc!=0) {
      sprintf_s(errmsg, sizeof errmsg,"%s�g�Jrptftplist���~",fname);
      EWRITE(userid,rc,errmsg);
      return rc;
   }
   $drop table tmp_officer;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l %d", M_CM_OK, icount);
   tmp_len = cm_buf_len(ReplyBuf);    

   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
   else
        return api_OKComplete;


errexit:
   return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}

long get_officer_A(reply)
serverReply reply;
{
    $char DBName[5];
    $char sIofficer[11], sChiname[11];
    $int  iCount;
    int tmp_len;
    cm_buf_get("%s",DBName);

    $WHENEVER SQLERROR GOTO errexit;
    
		if (db_select(DBName) == False)
   		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $SELECT count(unique iofficer[1,3])	INTO $iCount
       FROM officer
      WHERE iofficer[1,1] = 'A'
        AND iofficer[1,2] <> 'A5'
        AND iofficer[1,3] not in ('A00','A20','A27') 
        AND dexpire is null; 

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    cm_buf_put("%d",iCount);
    
    $DECLARE cusor_a CURSOR FOR
     SELECT unique iofficer[1,3], iofficer[1,3]||' '||nname[1,4]
       INTO $sIofficer, $sChiname
       FROM officer
      WHERE iofficer[1,1] = 'A'
        AND iofficer[1,2] <> 'A5'
        AND iofficer[1,3] not in ('A00','A20','A27')
        AND dexpire is null;

    $OPEN cusor_a;
    for(;;)
    {
        $FETCH cusor_a;
        if(SQLCODE==SQLNOTFOUND) break;
        cm_buf_put("%s",sIofficer);
        cm_buf_put("%s",sChiname);
        
    }
    $CLOSE cusor_a;
    $FREE cusor_a;
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;
   
errexit:
    if(exitsub(reply,SQLCODE) == True) 
        return SQLCODE;
    else  
        return apiRC;
}