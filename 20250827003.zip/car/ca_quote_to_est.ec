/*
   Name       : ca_quote_to_est
   Input      : v_iestima       �����渹
   return code: M_CM_OK         ���\
   Output     : v_fstate        ���A
                v_sMsg          �T��
*/
#include "globdata.h"

#include "commsgs.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"


/* �պ��� (estimate) */
$char 	 sIestimate[21], sIcard2[21], sIcard1[21], ilast_ply[21], sIlast_ply[21], sIlast_card[21];
$char 	 sIrelative_card[21],irelative_card[21], sIbroker2[11], sIbroker1[11], sBzfrom1[3];
$char 	 sBzfrom2[3], sIxxcard[21], sDply2_begin[11], sDply2_end[11];
$char 	 sDply1_begin[11], sDply1_end[11], sFassured[2], sIassured[13];
$char 	 sIlicense[11], sIbirth[9], sFsex[2], sFmarriage[2], sNuser[19];
$char 	 sIbenef[11], sAassured_zip[CA_ZIP], sItel[21],sItel_night[21],sMobil_phone[21];/* 1090525004-SC1-�]�y��-�s���l���ϸ�3+3   ZIP_CODE 5+1->CA_ZIP 6+1*/
$char 	 sApayment_zip[CA_ZIP], sIply_area[11], sIissue_ym[6], sIpro_year[5],sIbrand[9];/* 1090525004-SC1-�]�y��-�s���l���ϸ�3+3   ZIP_CODE 5+1->CA_ZIP 6+1*/
$char 	 sNbrand_abbr[13], sIcar_type2[3], sIcar_type1[3], sNcar_abbr[13];
$char 	 sIengine[CA_ENGINE_NUM], sIbody[CA_BODY_NUM], sItag[CA_TAG_NUM], sNequipment[31], sIbig_comp[2];
$char 	 sIbig_office[10], sIbig_sales[11], sIresource[2], sIofficer2[11];
$char 	 sIofficer1[11], sIcorps[11], sIarea[11], sIcashier[11], sIexaminer[11];
$char 	 sDexamine[11],sIentry[11],sDentry[11],sDapply[11],sFprint[2],sFcal_way[2];
$char 	 sIdmg_rate[3], sIbrg_rate[3], sIbranch[3], sFpt[2], sLia_class[3];
$char 	 sFcomp_24[2], sAbnormal_est[21], sIabn_type[2], sFcomp_class[3];
$char 	 sFcomp_class_last[3], sIquery_num_c[15], sIcar_flag1[2], sIcar_flag2[2];
$char 	 sTransno[21], sIaccept[21], sIapplicant[13], sDbirth[11], sDissue[11];
$char 	 sIextra_charge[11], sIroute_prop[3], sIrate_type1[2], sIrate_type2[2];
$char 	 sIroute_comm1[4], sIroute_comm2[4], sIcomm_obj1[12], sIcomm_obj2[12];
$char 	 sFapplicant[2], sFsex_appl[2], sDbirth_appl[11], sIuw_first[11];
$char 	 sDuw_first[20], sDcomp_lastdend[11], sIcomp_cartype_last[3];
$char 	 sIins_kind_ply[3], idmg_rate[3], ibrg_rate[3], sLia_class_V[3];
$char 	 sDsign[11],sIassured_cntry[2],sIapplicant_cntry[2],sNassured_cntry[51],sNapplicant_cntry[51];
$char	 sFunknown_dmg[2],funknown_dmg[2];
$char 	 sFequipment1[2],sFequipment2[2],sFequipment3[2],sFequipment4[2],sFequipment5[2],sFequipment6[2];
$char 	 sFequipment9[2],sNequipment9[101];
$varchar sNassured[121], sNbenef[43], sAassured[91], sApayment[91], sIemail[51];
$varchar sIquery_num[121], sIquery_num_damage[121], sNapplicant[121];
$varchar sSurvey_num[121], sBound_num[121], sIroute[21], sIofficer_prmt[11];
$varchar sIquota_prmt[7], sIleader_prmt[11], sNfax_cus[51], sNemail_cus[101];
$varchar sNroute_cus[41], sNname_cus[41], sItel_cus[41], sMobil_phone_cus[41];
$varchar sNnote_cus[121], sNnote_leader[121], sItel_appl[21], sNdeputy_appl[51],sTmobile_appl[21], sAemail_appl[51];
$varchar sNrelation_appl[41], sNdeputy_assured[51], sIquery_num_damage2[121];
$varchar sIquery_num_damage3[121],iquery_num_damage[121];
$varchar iquery_num_damage2[121],iquery_num_damage3[121];
$int     sQply1_period, sQply2_period,  sMpremium2, sMpremium1;

$double  sQcylinder; /* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
$int     sQlia_acc_sum, sQdmg_acc_sum, qprovision, sQprovision, sFuw_status, sQdmg_acc_sum2;
$int     sQdrunk_driving, sQviolate, sQpro_month, sQdmg_acc_sum3, qdmg_acc_sum2=0;
$int     qdmg_acc_sum3=0, sQlia_acc_sum_V, sQdmg_acc_sum_V;
$double  sMcar_price, sPdmg_factor, sPbrg_factor, sQpt, sPsex_age2, sPsex_age1, mcar_price;
$double  sPlia_acc2, sPlia_acc1, sPdmg_acc, sMready, sMstable, sMcompensation;
$double  sMresearch, sMinvest, sMbus_rule, sMbusiness, sMadjcom_prem, sMcapital;
$double  sMaintain, sMequipment, sPdmg_acc2, sPdmg_acc3, sPsex_age_damage,mequipment;
$double  pdmg_factor, pbrg_factor, pdmg_acc, pdmg_acc2, pdmg_acc3;
$char    feply[2], aemail_eply[51], sFeply[2], sAemail_eply[51];
$double  punknown_acc,sPunknown_acc,punknown_acc2,sPunknown_acc2;
$int     qunknown_acc_sum,sQunknown_acc_sum,qunknown_acc_sum2,sQunknown_acc_sum2;
$varchar iquery_num_unknown[121],sIquery_num_unknown[121];
$varchar iquery_num_unknown2[121],sIquery_num_unknown2[121];
$char    fout_print[2],fmail_type[2],sFout_print[2],sFmail_type[2];
$varchar npost_recipient[121],sNpost_recipient[121];
$char    apost_zip[CA_ZIP],sApost_zip[CA_ZIP];/* 1090525004-SC1-�]�y��-�s���l���ϸ�3+3   ZIP_CODE 5+1->CA_ZIP 6+1*/
$varchar apost_address[91],sApost_address[91];
$char    tmobile_eply[21],sTmobile_eply[51];/*1080417001-SC1-���ά�-�s�W�q�l�O��H²�T�覡�o�e */
$varchar iquery_num_last_brg[121],sIquery_num_last_brg[121];
$char    dply_end_last_brg[11], ipolicy_last_brg[21],dcust_apply[20],ipay_way[2];
$char    sDply_end_last_brg[11], sIpolicy_last_brg[21],sDcust_apply[20],sIpay_way[2];

$char    foccup[2],noccup[6],applicant_foccup[2],applicant_noccup[6],fbatch_b2c[2];
$char    sfoccup[2],snoccup[6],sapplicant_foccup[2],sapplicant_noccup[6],sfbatch_b2c[2];
$char    sIreg_no[21];			/* 1080408005-SC1-��ã��-�j���һ{�ҷs�W�q����Ƥεn���Ҹ� */


/* 1070125001_SC5_�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o */
/* 107/07/17�W�[�q�l���j���� */
$char    sFecard[2],fecard[2];
$int sIest_cnt;/* 1070125001-SC7-�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o*/

$int sIest_cnt_c1 = 0,sIest_cnt_c2 = 0;

/*  1090508001-SC1-��౻T-��T�M��[�ظm�T�������O�T�I�����κި�t��
    �O�T�D�O�渹iext_policy�ӫO�ɨ��e��mkilo_ply���I����irisk�����O�T���p�渹irelative_ext���DIDiowner���Dnowner���D�X�ͦ~dbirth_owner
    �e�����渹ilast_quote
*/
$char   sIext_policy[21],sIrisk[2],sIrelative_ext[21],sIowner[13],sNowner[121],sDbirth_owner[11],sIlast_quote[21];
$double mkilo_ply;
$char sDnotifyornot[24];/*1090831006-SC1-���ʱo-�{�ҥ��x�j��q�l���ҥ���g�����mail�ˮ�*/

$int iDmg_acc_sum_5y ;  /* 1090803002-SC1-�ӽ�HCC�֫O�ҫ�          �e���~�����I�߮ץB�ߴڪ��B��0���߮ץ��  */
$int iLia_acc_sum_5y ;  /* 1090803002-SC1-�ӽ�HCC�֫O�ҫ�          �e���~�ĤT�H�d���I���߮ץ��  */
$int iDuty_acc_sum_5y;  /* 1090803002-SC1-�ӽ�HCC�֫O�ҫ�          �e���~���F�d���p�����߮ץ��  */
$char sDfirst_ply1[11];/* 1090803002-SC1-�ӽ�HCC�֫O�ҫ�          ���N�I�̦���O��   */
$char sDfirst_ply2[11];/* 1090803002-SC1-�ӽ�HCC�֫O�ҫ�          �j���I�̦���O��   */
$char sDfirst_ply[11];
$char feterms[2],sFeterms[2];/*1100419003-SC1-���I�O�����QR Code�q�l��*/
$char sIsecond_hand[7];/* 1101012001-SC1-���ά�-�W�[�B�z���j�������  �t�XB2B�睊�g�J�B�z*/
$int  qacc_sum_5y;         /*�e���~�߮ץ�� (1120220002_SC1)*/
$char fhave_newa_c_2y[2];  /*�L�h2�~�O�_�b�s�w��O�L�T���I(1120220002_SC1)*/
$char sDinstall[11],sIsequence[31],sAinstall_zip[CA_ZIP],sAinstall[91]; /*1120927002_C01_�R�q�ΰӫ~�}�o*/



/* �պ��I�ة����� (est_ins_type) */
$char    sIins_type[7], sDrate_ym[5], sIproduct[13], sFproject[2];
$varchar sProvision[21];
$int     sMinjured_cover, sMdeath_cover, sMdamage_cover, sMdeduct,sMins_premium;
$int     sQserial, sMcommission, sMagent, sMdiscount, sMprem, sQday, sMexpense;
$int     sMexp_disc, sIrate, sMins_premium_n, sMprem_n, sMdrunk_prem, sMviolate_prem;
$double  sMpure_prem, sPcommission, sPagent, sPdiscount, sAdjust_rate;
$double  sMpure_prem_n, sSafe_rate, sManage_rate, sEducated_rate;
$double  sDeviation_rate, sPextra_charge, sPbusiness, sPsex_age, sPshipping;
$double  sMdrunk_pure_prem, sMviolate_pure_prem;
/* �պ�O���I�ثO�B�O�O�� (est_ins_cover)  */
$char	 sIcover_type[4];
$int 	 sMcover;

/* �պ�ˮ`�I�W�U (est_ins_assured) */
$char	 sIins_type_pa[7], sIassured_a[13], sDbirth_a[11], sRel_benef[2];
$char	 sProvision_a[7], iassured_a[11], sNassured_a[31], sNbenef_a[31];/*  1081225006-SC1-���ά�-�X�R���[���ڥN�X  provision ->6�X*/

/* �ˮ`�I�պ������ (ca_pa_est) */
$char 	 sIinsurant[11], sNinsurant[31], sDbirth_pa[11], sIins_scope[2];
$char 	 sNbeneficiary[31], sRelation_bene[2];
$int     sMins_amt_pa, sMins_premium_pa, sMcommission_pa, sMagent_pa;
$int     sMdiscount_pa, sDaily_pay, sMr_ins_prem;
$double  sMpure_prem_pa, sPcommission_pa, sPagent_pa, sPdiscount_pa;
$double  sMr_pure_prem;

$char  	 sIcard[21], sDins_bgn[11], sDins_end[11], sIcar_type[3], sIofficer[11];
$char	 sIrate_type[2];
$char	 sIlia_query_num[21], sIcar_flag[2], sIdmg_query_num[21], sBzfrom[3];
$char	 sIroute_comm[4], sIcomm_obj[12], sFprop[2],sIcar_broker[11];
$char 	 ilast_card1[21], ilast_card2[21], irelative_card1[21],irelative_card2[21];
$int  	 sQply_period, sMpremium,sTransPrem ;
$double  sPsex_age_e, sPlia_acc;
$char	 localdb[3];
int  	 count;
/*1080411005-SC2-��奰-�����~�ȧ�O���x�W����*/
$int	iDirect;
$int    iDirectErr;

void end_ca_quote_to_est();
void ca_estimate_init();

long ca_quote_to_est(v_iestimate, v_localdb, v_fstate, v_sMsg)
$char    *v_iestimate, *v_localdb ,*v_sMsg;
$int     *v_fstate;
{
	$int  rtncode;

    $WHENEVER SQLERROR GOTO errexit;

    puts("");
    puts("***********************************");
    puts(" begin ca_quote_to_est ");
    printf(" v_iestimate = [%s]\n", v_iestimate);

    strcpy(sIestimate, trim(v_iestimate));
    strcpy(localdb,trim(v_localdb));
    printf(" sIestimate = [%s]\n", sIestimate);
    printf(" localdb = [%s]\n", localdb);
    sIest_cnt = 0;  /* 1070125001-SC7-�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o*/
    *v_fstate = 0;
    sIest_cnt = 0;
    /*1060224008_C2 B2B������ɦ�e�O�����I����*/
    /* �P�_�O�_���s�t�γ����渹(�r�y[5,7] = CVQ) */
    /*if (strncmp(sIestimate+4,"CVQ",3) == 0)*/
    if (strncmp(sIestimate+5,"CP",2)!=0 && strncmp(sIestimate+5,"CR",2)!=0)
    {
    	printf("*****ca_quotation.iquote = [%s]*****\n", sIestimate);
    	/* �P�_�s�t�γ����渹�O�_�w�s�b���s�պ��� */

        $BEGIN WORK;

        $SELECT count(iestimate) INTO $sIest_cnt
           FROM estimate
          WHERE iestimate = $sIestimate;
        if (sIest_cnt > 0)
        {
           *v_fstate = 2;
           sprintf_s( v_sMsg, 250,"�s�t�γ����渹[%s]�w�s�b���s�պ���", sIestimate);
        }
        else
        {
            /* �p��RBA=Y:�ݮ֫O�f�֡A���o�a�J�A�åBĵ�� */
            printf("�ݮ֫O�f�֡A���o�a�J�A�åBĵ��\n");
            $SELECT count(*) into $sIest_cnt
               FROM quotation_master
              WHERE fcheck_rba ="Y"
                AND iquote = $sIestimate;
            if (sIest_cnt >0)
            {
                /* �s�t�γ������ �]RBA�S���f�ֳq�L */
                rtncode = M_CA_NCHK_RBA ;
                printf("�s�t�γ������[%s]�]RBA�S���f�ֳq�L\n", sIestimate);
                $ROLLBACK WORK;
                return rtncode;
            }

			
            ca_estimate_init();

            /* Source:���I������(ca_quotation)�γ����D��(quotation_master)
                 Into:�պ�����(estimate) */
            rtncode = ca_insert_to_estimate();
            if (rtncode != M_CM_OK)
            {
                /*if (rtncode == M_CA_QT_TRANS_FAILED || rtncode == M_CM_NOT_FOUND) */
                $ROLLBACK WORK;
                printf("*****ca_insert_to_estimate() error or not found \n");
                return rtncode;
            }
			
			/*1080411005-SC2-��奰-�����~�ȧ�O���x�W����	*/
			iDirect = 0;
			iDirectErr = 0;
            $SELECT count(*)
			   into $iDirect
               FROM quotation_master a ,  car_code b
              WHERE a.iquote = $sIestimate
			    AND a.iroute = b.detail 
				and b.kind='63'
				AND a.iquote[5,7]='CVQ';
			
			printf("1.iroute=car140.kind=63�A�P�_�������~�ȥ��x�� iDirect[%f]\n",iDirect);
			if (iDirect > 0)
			{
				
				$SELECT (CASE WHEN today > min(a.dins_bgn) THEN '4663' ELSE '4664' end),
	 				   nvl(sum((CASE WHEN b.faction='5' THEN 1 ELSE 0 END)),-1)
	 			  into $iDirectErr,$iDirect
	 		      FROM quotation_master a, ca_direct_business b
                  WHERE a.iquote = b.iquote
                    AND a.iquote = $sIestimate;	
		 		printf("2.�����~�ȥ��x��A����faction=5=>OTP���� �i�H�a�Jcar301����iDirect[%d]\n",iDirect);
				if (iDirect > 0)
				{
					/*2. �����~�ȥ��x�����ɪ��A��faction=5.�T�{OTP�A
					     �h�i�H�a�Jcar301����/car305�X��e��
						 E�O�����ˮֻݧ����֫O(500)+OTP�~�|faction=5*/
				}
				else 
				{
					/* ���`::������O���x�ɵL��������Ae�O���n�T�{*/
					printf("3.������O��(�H�j��/���N��������P�_) iDirectErr[%d]\n",iDirectErr);
					rtncode = iDirectErr ;
					printf("faction <> 5\n");
					$ROLLBACK WORK;
					return rtncode;
					
				}
				
			
			}
			
			
            /* Source:���I�����I�ة�����(ca_quotation_ins)
                 Into:�պ��I�ة�����(est_ins_type)
                      �պ�O���I�ثO�B�O�O��(est_ins_cover)*/
            rtncode = ca_insert_to_est_ins();
            if (rtncode != M_CM_OK)
            {
            	  /*if (rtncode == M_CA_QT_TRANS_FAILED)*/ $ROLLBACK WORK;
                printf("*****ca_insert_to_est_ins() error\n");
                return rtncode;
            }

            /* Source:���I�����ˮ`�I�W�U��(ca_quotation_assured)
                      ���I�����ˮ`�I������(ca_quotation_assured_dtl)
                 Into:�պ�ˮ`�I�W�U(est_ins_assured)
                      �ˮ`�I�պ������(ca_pa_est) */
        	  rtncode = ca_insert_to_est_ins_assured();
        	  if (rtncode != M_CM_OK)
            {
            	  /*if (rtncode == M_CA_QT_TRANS_FAILED) */$ROLLBACK WORK;
                printf("*****ca_insert_to_est_ins_assured() error\n");
                return rtncode;
            }
            
            /* ���O���� */
            rtncode = ca_insert_to_bound_dtl();
        	if (rtncode != M_CM_OK)
            {
            	  /*if (rtncode == M_CA_QT_TRANS_FAILED) */$ROLLBACK WORK;
                printf("*****ca_insert_to_bound_dtl() error\n");
                return rtncode;
            }


            *v_fstate = 3;
            sprintf_s( v_sMsg,250, "�s�t�γ����渹[%s]��J���s�պ���SUCCESS", sIestimate);
        }
        $COMMIT WORK;
 
    }
    else
    {
        *v_fstate = 1;
        sprintf_s( v_sMsg,250, "���s�����渹[%s]" , sIestimate);
    }

	/* fState = 1 , �����渹�r�y[5,7] != CCQ (�D�s�t�γ����渹) */
	/* fState = 2 , �s�t�γ����渹�w�s�b���s�պ��� */
	/* fState = 3 , �s�t�γ�����Ƥw���\��J���s�պ��� */
    if ( v_fstate == 0 )
    {
        sprintf_s( v_sMsg,250,"�s�t�γ����渹[%s]��J���s�t�Φ��~", sIestimate);
	end_ca_quote_to_est( v_sMsg);
	return rtncode;
    }
    else
    {
	end_ca_quote_to_est( v_sMsg);
	return M_CM_OK;
    }

errexit:
    printf("SQLCODE:1[%d]\n", SQLCODE);
    rtncode = SQLCODE;
    $ROLLBACK WORK;
    printf("SQLCODE:2[%d]\n", SQLCODE);
    sprintf_s( v_sMsg,250, "SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",rtncode,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    end_ca_quote_to_est( v_sMsg);
    return rtncode;
}
/*************************************************************************************************/
long ca_insert_to_estimate()
{
    int i;
    $char sStmt[10000], v_sMsg[256], tmp_iofficer[11];

    $WHENEVER SQLERROR GOTO errexit;
    sIest_cnt = 0; /* 1070125001-SC7-�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o*/
    sprintf_s(sStmt,sizeof sStmt,"SELECT a.iins_kind_ply, a.icard, b.iply_last, a.ilast_card, "
                    "       a.irelative_card, a.ixxcard,a.qply_period,b.dins_bgn,"
                    "       b.dins_end, b.fassured, b.iassured, b.nassured, "
                    "       a.ilicense, year(b.dassured_dbirth)-1911||"
                    "       to_char(b.dassured_dbirth,'/%%m/%%d') as dassured_dbirth, "
                    "       decode(b.fassured_sex,'M','1','F','2',' '), "
                    "       a.fmarriage, a.nuser, a.ibenef,"
                    "       a.nbenef[1,42], b.aassured[1,90], b.aassured_zip, "
                    "       b.tassured_day, b.tassured_night, b.tassured_mobile, "
                    "       b.aapplicant[1,90], b.aapplicant_zip, a.iply_area, "
                    "       a.dissue, a.ipro_year, a.ibrand, a.nbrand_abbr, "
                    "       a.icar_type, a.ncar_abbr, a.qcylinder, a.iengine, "
                    "       a.ibody, a.itag,a.mcar_price,a.nequipment,a.mpremium,"
                    "       a.ibig_comp, a.ibig_office, a.ibig_sales, b.iofficer,"
                    "       a.icorps, a.iarea, a.icashier, a.icreate, "
                    "       date(a.dcreate), a.dapply, a.fprint2, a.fcal_way, "
                    "       a.idmg_rate,a.pdmg_factor,a.ibrg_rate, a.pbrg_factor,"
                    "       a.ibranch,a.qpt,a.fpt,a.psex_age_lia,a.psex_age_dmg, "
                    "       a.plia_acc, a.pdmg_acc, a.abnormal_est, "
                    "       a.mready, a.mstable, a.mcompensation, a.mresearch, "
                    "       a.minvest, a.mbus_rule, a.mbusiness, a.madjcom_prem, "
                    "       a.mcapital, a.maintain, a.lia_class,a.lia_class_last,"
                    "       b.aassured_email, a.ilia_query_num, a.icar_flag, "
                    "       b.transno, a.qpro_month, b.iroute_accept, "
                    "       a.idmg_query_num, b.iapplicant, b.napplicant, "
                    "       b.dassured_dbirth, a.mequipment, a.isurvey_num, "
                    "       a.ibound_num, NVL(b.iroute,' '),"
                    "       NVL(a.iofficer_prmt,' '),NVL(a.iquota_prmt,' '),"
                    "       NVL(a.ileader_prmt,' '),NVL(a.nfax_cus,' '),"
                    "       NVL(a.nemail_cus,' '),NVL(a.nroute_cus,' '),"
                    "       NVL(a.nname_cus,' '),NVL(a.itel_cus,' '),"
                    "       NVL(a.mobile_phone_cus,' '),NVL(a.nnote_cus,' '),"
                    "       NVL(a.nnote_leader,' '),NVL(b.irate_type,' '),"
                    "       NVL(b.ibusiness_from,' '),NVL(b.iroute_comm,' '),"
                    "       NVL(b.icomm_obj,' '),NVL(a.qlia_acc_sum,'0'),"
                    "       NVL(a.qdmg_acc_sum,'0'),NVL(a.qprovision,'0'), "
                    "       NVL(b.fapplicant,' '),"
                    "       decode(b.fapplicant_sex,'M','1','F','2',' '),"
                    "       b.dapplicant_birth,NVL(b.tapplicant_day,' '),"
                    "       NVL(b.napplicant_deputy,' '), "
                    "       CASE fapplicant_rel WHEN '1' THEN '���H' WHEN '2' THEN '����' WHEN '3' THEN '�t��' WHEN '4' THEN '�l�k' WHEN '5' THEN '�S�̩j�f' WHEN '6' THEN '���q�t�d�H' WHEN '7' THEN '���q���u' WHEN '8' THEN '�������Y' WHEN 'A' THEN '���Y���~' else napplicant_relation END, "
                    "       NVL(b.nassured_deputy,' '), "
                    "       NVL(b.iapproval_status,'0'),"
                    "       a.iuw_first, to_char(a.duw_first,'%%Y-%%m-%%d %%H:%%M:%%S'), "
                    "       a.pdmg_acc2, NVL(a.qdmg_acc_sum2,'0'),"
                    "       a.idmg_query_num2, "
                    "       a.pdmg_acc3, NVL(a.qdmg_acc_sum3,'0'),"
                    "       a.idmg_query_num3, "
                    "       a.dcomp_lastdend, a.qdrunk_driving,"
                    "       a.icomp_cartype_last, "
                    "       (SELECT iroute_prop FROM officer "
                    "       WHERE iofficer = b.iofficer) as iroute_prop,"
                    "       CASE WHEN year(a.dissue)-1911 >= 100 "
                    "       THEN substr(year(a.dissue)-1911||to_char(a.dissue,'/%%m'),2,6) "
                    "       ELSE year(a.dissue)-1911||to_char(a.dissue,'/%%m') END, "
                    "       (SELECT NVL(icar_broker,' ') FROM officer_broker "
                    "       WHERE iofficer = b.iofficer), "
                    "       NVL(b.ibusiness_from,' '), "
                    "       b.dsign,b.iassured_cntry,b.iapplicant_cntry,b.nassured_cntry,b.napplicant_cntry,a.funknown_dmg, "
                    "       a.fequipment1,a.fequipment2,a.fequipment3,a.fequipment4, "
                    "       a.fequipment5,a.fequipment6,a.fequipment9,a.nequipment9 , "
                    "       a.feply,a.feterms, a.aemail_eply, a.tmobile_eply,b.ireg_no,"
                    "       a.punknown_acc, NVL(a.qunknown_acc_sum,'0'), a.iquery_num_unknown, "
                    "       a.punknown_acc2, NVL(a.qunknown_acc_sum2,'0'), a.iquery_num_unknown2, "
                    "       a.fout_print,a.fmail_type,a.npost_recipient,a.apost_zip,a.apost_address, "
                    "       a.iquery_num_last_brg, a.dply_end_last_brg, a.ipolicy_last_brg, a.dcust_apply, b.ipay_way, "
                    "       b.foccup,b.noccup,b.applicant_foccup,b.applicant_noccup,a.fbatch_b2c,b.tapplicant_mobile,b.aapplicant_email, "
                    "       (select count(*) from ca_quotation where iquote = a.iquote and iins_kind_ply = 'C1'), "
                    "       (select count(*) from ca_quotation where iquote = a.iquote and iins_kind_ply = 'C2'), "
                    "       a.iext_policy,a.irisk,a.iowner,a.nowner,a.dbirth_owner,a.mkilo_ply,"
                    "       nvl((SELECT c.ipolicy1 FROM cm_pre_receive c WHERE c.ipre_rcv = a.ilast_quote AND c.ipre_end = '' AND c.iins_kind='2' AND c.dclose IS NOT null),''),"
                    "       a.dnotifyornot,nvl(a.dfirst_ply,''),nvl(c.q3_dmg_acc_sum_5y_value,'0'),"
                    "       nvl(c.q4_lia_acc_sum_5y_value,'0'),nvl(c.q5_duty_acc_sum_5y_value,'0'), a.isecond_hand, a.qviolate, "
                    "       nvl(c.q17_acc_sum_5y_value,'0'),nvl(c.f18_have_newa_c_2y_value,'0'), "
                    "       a.dinstall,a.isequence,a.ainstall_zip,a.ainstall "
                    "  FROM ca_quotation a, quotation_master b,outer ca_quotation_hcc c "
                    " WHERE a.iquote = b.iquote "
                    "   AND a.iquote = c.iquote "
                    "   AND a.iins_kind_ply = b.iins_kind_ply "
                    "   AND a.iquote = '%s' "
                    "   AND a.iarea = '%s' "
                    "   AND (b.iapproval_status <> 200 "
                    "    OR b.iapproval_status IS NULL) "
                    "   AND b.icurrent_state not in ('700','799') "
                    " ORDER BY a.iins_kind_ply DESC ", sIestimate,localdb);
                    /* 1070125001-SC7-�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o  700->�X��  799->�鵲*/
                    
                    /*1090508001-SC1-��౻T-��T�M��[�ظm�T�������O�T�I�����κި�t��  
                    58�O�T  ��������(�t�f��)���A->iapproval_status>=500
                            �O�T�D�O�渹�渹���ݦ��渹�C(ca_quotation.iext_policy)
                            �����sV9��������Ȧsca_quotation.ilast_quote->�ର�O�渹��sestimate.sIrelative_ext
                            �ݧP�_�����鵲�~��a�J�ѥX��
                    */
                    
    $PREPARE ca_estimate FROM $sStmt;
    $DECLARE est_cur CURSOR FOR ca_estimate;
    $OPEN    est_cur;
    printf("*****Query ca_quotation*****\n");
    /*printf("sStmt[%s]\n", sStmt);*/
    count = 0;

    for(;;)
    {
        $FETCH est_cur INTO $sIins_kind_ply, $sIcard, $ilast_ply, $sIlast_card,
                            $irelative_card, $sIxxcard, $sQply_period,
                            $sDins_bgn, $sDins_end, $sFassured, $sIassured,
                            $sNassured, $sIlicense, $sIbirth, $sFsex,
                            $sFmarriage,$sNuser, $sIbenef, $sNbenef, $sAassured,
                            $sAassured_zip, $sItel, $sItel_night, $sMobil_phone,
                            $sApayment, $sApayment_zip, $sIply_area, $sDissue,
                            $sIpro_year, $sIbrand, $sNbrand_abbr, $sIcar_type,
                            $sNcar_abbr, $sQcylinder, $sIengine,$sIbody,$sItag,
                            $mcar_price, $sNequipment, $sMpremium, $sIbig_comp,
                            $sIbig_office, $sIbig_sales, $sIofficer, $sIcorps,
                            $sIarea, $sIcashier, $sIentry, $sDentry, $sDapply,
                            $sFprint, $sFcal_way, $idmg_rate, $pdmg_factor,
                            $ibrg_rate, $pbrg_factor, $sIbranch, $sQpt, $sFpt,
                            $sPsex_age_e,$sPsex_age_damage, $sPlia_acc,
                            $pdmg_acc, $sAbnormal_est, $sMready,
                            $sMstable, $sMcompensation, $sMresearch,
                            $sMinvest, $sMbus_rule, $sMbusiness, $sMadjcom_prem,
                            $sMcapital, $sMaintain, $sLia_class,
                            $sFcomp_class_last, $sIemail, $sIlia_query_num,
                            $sIcar_flag, $sTransno, $sQpro_month, $sIaccept,
                            $iquery_num_damage,$sIapplicant,$sNapplicant,$sDbirth,
                            $mequipment, $sSurvey_num, $sBound_num, $sIroute,
                            $sIofficer_prmt, $sIquota_prmt, $sIleader_prmt,
                            $sNfax_cus, $sNemail_cus, $sNroute_cus, $sNname_cus,
                            $sItel_cus, $sMobil_phone_cus, $sNnote_cus,
                            $sNnote_leader,$sIrate_type,$sBzfrom, $sIroute_comm,
                            $sIcomm_obj, $sQlia_acc_sum, $sQdmg_acc_sum,
                            $qprovision,$sFapplicant,$sFsex_appl,$sDbirth_appl,
                            $sItel_appl,$sNdeputy_appl, $sNrelation_appl,
                            $sNdeputy_assured, $sFuw_status,$sIuw_first,
                            $sDuw_first, $pdmg_acc2, $qdmg_acc_sum2,
                            $iquery_num_damage2, $pdmg_acc3, $qdmg_acc_sum3,
                            $iquery_num_damage3, $sDcomp_lastdend,
                            $sQdrunk_driving,$sIcomp_cartype_last,$sIroute_prop,
                            $sIissue_ym,$sIcar_broker,$sIextra_charge,
                            $sDsign,$sIassured_cntry,$sIapplicant_cntry,$sNassured_cntry,$sNapplicant_cntry,$funknown_dmg,
                            $sFequipment1,$sFequipment2,$sFequipment3,$sFequipment4,
                            $sFequipment5,$sFequipment6,$sFequipment9,$sNequipment9,
                            $feply,$feterms,$aemail_eply,$tmobile_eply,$sIreg_no,
                            $punknown_acc, $qunknown_acc_sum,$iquery_num_unknown,
                            $punknown_acc2, $qunknown_acc_sum2,$iquery_num_unknown2,
                            $fout_print,$fmail_type,$npost_recipient,$apost_zip,$apost_address,
                            $iquery_num_last_brg, $dply_end_last_brg, $ipolicy_last_brg, $dcust_apply, $ipay_way,
                            $foccup, $noccup, $applicant_foccup, $applicant_noccup,$fbatch_b2c,$sTmobile_appl,$sAemail_appl,
                            $sIest_cnt_c1,$sIest_cnt_c2,
                            $sIext_policy,$sIrisk,$sIowner,$sNowner,$sDbirth_owner,$mkilo_ply,$sIlast_quote,
                            $sDnotifyornot,$sDfirst_ply,$iDmg_acc_sum_5y,$iLia_acc_sum_5y,$iDuty_acc_sum_5y,$sIsecond_hand,$sQviolate,
                            $qacc_sum_5y,$fhave_newa_c_2y,
                            $sDinstall, $sIsequence, $sAinstall_zip, $sAinstall;
                        
        if (SQLCODE == SQLNOTFOUND) break;

        count++;

        strcpy(sIengine , rtrim(sIengine));
        strcpy(sIbody   , rtrim(sIbody));
        printf("sIext_policy[%s]sIlast_quote[%s][%d]sFuw_status[%d]\n",sIext_policy,sIlast_quote,strlen(trim(sIlast_quote)),sFuw_status);
        /* �վ�y�~�ȩʽ�z��ƳB�z�覡 modify by 061476 (1070426001_SC1) */
        strcpy(sFprop,"0"); /* �w�]�� */
        $SELECT fproperty
	   INTO $sFprop
	   FROM cm_code20
	  WHERE iclass = '04'
	    AND icode  = $sIassured
	    AND (dexpire is null or dexpire > today);

	if (SQLCODE==SQLNOTFOUND) strcpy(sFprop,"0");

	/* (���Y���~��W)���I�n�P�_�g��N�������N���~�O���Y���~*/
	if (strncmp(sFprop,"9",1)==0 && strncmp(sFprop,"Z",1)==0)
		strcpy(sFprop,"8");
		
	if (strncmp(sFprop,"7",1)==0 || strncmp(sFprop,"8",1)==0 || strncmp(sFprop,"G",1)==0)
	{
	}else
	{
		if (strlen(trim(sIcorps))!=0) strcpy(tmp_iofficer, trim(sIcorps));
		else strcpy(tmp_iofficer, trim(sIofficer));
		
		$SELECT fprop
		   INTO $sFprop
		   FROM officer
		  WHERE iofficer = $tmp_iofficer;
		  
		if (SQLCODE==SQLNOTFOUND) strcpy(sFprop,"0");
	}
	if (strncmp(sFprop,"0",1)==0) strcpy(sFprop,"3");    
        
        if (strncmp(substring(sIext_policy,6,2),"VW",2) ==0) /*1090508001-SC1-��౻T-��T�M��-�ظm�T�������O�T�I�����κި�t��*/
        {
            if (sFuw_status < 500)    return  M_CA_IQUOTATION_Q;         /* 4420 ���������i�X�� M_CA_IQUOTATION_Q */
            if (strlen(trim(sIlast_quote))== 0) return M_CA_IREL_EXT_NCLS;   /*   4668 �O�T���p�椧���N�I�O��|���鵲�C */
        }
        else
        {
            strcpy(sIext_policy,"");
            strcpy(sIlast_quote,"");
        }
        
        if (count == 1)  /* ���P�_�|�P�W�� "ORDER BY a.iins_kind_ply DESC" ���� */
        {
        	/* �j+�� �H���N�I��Ƭ��D */
        	/*if(strncmp(sIins_kind_ply,"C1",2) == 0)*/
			       	
        	strcpy(sAemail_eply			,aemail_eply);
			strcpy(sTmobile_eply		,tmobile_eply);	/*1080417001-SC1-���ά�-�s�W�q�l�O��H²�T�覡�o�e */
        	strcpy(sFout_print			,fout_print);
        	strcpy(sFmail_type			,fmail_type);
        	strcpy(sNpost_recipient		,npost_recipient);
        	strcpy(sApost_zip			,apost_zip);
        	strcpy(sApost_address		,apost_address);
        	strcpy(sDcust_apply			,dcust_apply);
        	strcpy(sIpay_way			,ipay_way);
        	strcpy(sIrelative_card		,irelative_card);
        	strcpy(sFunknown_dmg		,funknown_dmg);
        	strcpy(sfoccup		        ,foccup);
        	strcpy(snoccup		        ,noccup);
        	strcpy(sapplicant_foccup	,applicant_foccup);
        	strcpy(sapplicant_noccup	,applicant_noccup);
        	strcpy(sfbatch_b2c	        ,fbatch_b2c);
        	
        		
        	sQprovision = qprovision;
        	
        	printf("sFunknown_dmg[%s]\n",sFunknown_dmg);
        	printf("sQprovision[%d]\n",sQprovision);

        	sMequipment                = mequipment;
        	sMcar_price                = mcar_price;
        	
        	strcpy(sIlast_ply		,ilast_ply);
        	
        }

        strcpy(sIins_kind_ply,trim(sIins_kind_ply));
        if(strncmp(sIins_kind_ply,"C1",2) == 0)
        {
           printf("*****�j��*****[%s]\n", sIins_kind_ply);
           sIest_cnt=1; /* 1070125001-SC7-�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o �j����N�P�@�����渹�A�j��۰ʥX��A���N�n�i�H�b���s�X��*/
           strcpy(sIcard1				,sIcard);
           strcpy(sDply1_begin			,sDins_bgn);
           strcpy(sDply1_end			,sDins_end);
           strcpy(sIcar_type1			,sIcar_type);
           strcpy(sIbroker1				,sIcar_broker);
           strcpy(sIofficer1			,sIofficer);
           strcpy(sIquery_num_c			,substring(sIlia_query_num,1,14));
           strcpy(sIcar_flag1			,sIcar_flag);
           strcpy(sIrate_type1			,sIrate_type);
           strcpy(sBzfrom1				,sBzfrom);
           strcpy(sIroute_comm1			,sIroute_comm);
           strcpy(sIcomm_obj1			,sIcomm_obj);
           strcpy(ilast_card1			,sIlast_card);
           strcpy(irelative_card1		,sIrelative_card);
           strcpy(sFcomp_class			,sLia_class);
           strcpy(sFecard			    ,feply);
           strcpy(sDfirst_ply1           ,sDfirst_ply);/* 1090803002-SC1-�ӽ�HCC�֫O�ҫ� */
           if(sIest_cnt_c2 == 0) strcpy(sFeply,"0");  /*�Y����j�h���N�q�l�O����O��쵹0*/
           if(sIest_cnt_c2 == 0) strcpy(sFeterms,"0"); /*1100419003-���I�O�����QR Code�q�l��-�ȥ��O��u�q�l���ڡv  feterms feply =1�ɡA�����O�@�v��0�A�j���I�@�߬�0*/
           sQply1_period               = sQply_period;
           sMpremium1                  = sMpremium;
           sPsex_age1                  = sPsex_age_e;
           sPlia_acc1                  = sPlia_acc;
        }
        else
        {
           printf("*****���N*****[%s]\n", sIins_kind_ply);

           strcpy(sIcard2				,sIcard);
           strcpy(sDply2_begin			,sDins_bgn);
           strcpy(sDply2_end			,sDins_end);
           strcpy(sIcar_type2			,sIcar_type);
           strcpy(sIbroker2				,sIcar_broker);
           strcpy(sIofficer2			,sIofficer);
           strcpy(sIquery_num			,sIlia_query_num);
           strcpy(sIcar_flag2			,sIcar_flag);
           strcpy(sIrate_type2			,sIrate_type);
           strcpy(sBzfrom2				,sBzfrom);
           strcpy(sIroute_comm2			,sIroute_comm);
           strcpy(sIcomm_obj2			,sIcomm_obj);
           strcpy(ilast_card2			,sIlast_card);
           strcpy(irelative_card2		,sIrelative_card);
           strcpy(sIdmg_rate			,idmg_rate);
           strcpy(sIbrg_rate			,ibrg_rate);
           strcpy(sLia_class_V			,sLia_class);
           strcpy(sIquery_num_damage	,iquery_num_damage);
           strcpy(sIquery_num_damage2	,iquery_num_damage2);
           strcpy(sIquery_num_damage3	,iquery_num_damage3);
           strcpy(sIquery_num_unknown	,iquery_num_unknown);
           strcpy(sIquery_num_unknown2	,iquery_num_unknown2);
           strcpy(sIquery_num_last_brg	,iquery_num_last_brg);
           strcpy(sDply_end_last_brg	,dply_end_last_brg);
           strcpy(sIpolicy_last_brg		,ipolicy_last_brg);
		   strcpy(sFeply			    ,feply);
           strcpy(sFeterms              ,feterms); /*1100419003-���I�O�����QR Code�q�l��-�ȥ��O��u�q�l���ڡv  feterms feply =1�ɡA�����O�@�v��0�A�j���I�@�߬�0*/
           strcpy(sDfirst_ply2          ,sDfirst_ply);/* 1090803002-SC1-�ӽ�HCC�֫O�ҫ� */
		   if(sIest_cnt_c1 == 0) strcpy(sFecard,"0"); /*�Y������h�j��q�l���ҵ��O��쵹0*/
           
           sQlia_acc_sum_V             = sQlia_acc_sum;
           sQdmg_acc_sum_V             = sQdmg_acc_sum;
           sQply2_period               = sQply_period;
           sMpremium2                  = sMpremium;
           sPsex_age2                  = sPsex_age_e;
           sPlia_acc2                  = sPlia_acc;
           sPdmg_factor                = pdmg_factor;
           sPbrg_factor                = pbrg_factor;
           sPdmg_acc                   = pdmg_acc;
           sPdmg_acc2                  = pdmg_acc2;
           sQdmg_acc_sum2              = qdmg_acc_sum2;
           sPdmg_acc3                  = pdmg_acc3;
           sQdmg_acc_sum3              = qdmg_acc_sum3;
           sPunknown_acc               = punknown_acc;
           sQunknown_acc_sum           = qunknown_acc_sum;
           sPunknown_acc2              = punknown_acc2;
           sQunknown_acc_sum2          = qunknown_acc_sum2;
        }
    }

    $CLOSE est_cur;
    $FREE  est_cur;

    if (count == 0) return M_CM_NOT_FOUND;

    /* ��O�Ҹ�����O�d�����ȮɡA�a�J��O�d�� */
    strcpy(ilast_card1, trim(ilast_card1));
    strcpy(ilast_card2, trim(ilast_card2));
    if (strlen(ilast_card1) != 0 && strlen(ilast_card2) != 0)
    {
    	strcpy(sIlast_card, ilast_card2);
    }
    else if (strlen(ilast_card1) != 0)
    {
    	strcpy(sIlast_card, ilast_card1);
    }
    else if (strlen(ilast_card2) != 0)
    {
    	strcpy(sIlast_card, ilast_card2);
    }
    else
    {
    	strcpy(sIlast_card, " ");
    }

    /* ���p�Ҹ������p�d�����ȮɡA�a�J���p�Ҹ�
    strcpy(irelative_card1, trim(irelative_card1));
    strcpy(irelative_card2, trim(irelative_card2));
    if (strlen(irelative_card1) != 0 && strlen(irelative_card2) != 0)
        strcpy(sIrelative_card, irelative_card1);
    else
    	  strcpy(sIrelative_card, " ");
     */
    printf("iestimate[%s],     icard2[%s]\n", sIestimate, sIcard2);
    printf("icard1[%s],        aassured[%s]\n", sIcard1 ,trim(sAassured));
    printf("ilast_ply[%s],     ilast_card[%s]\n",trim(sIlast_ply),sIlast_card);
    printf("irelative_card[%s],ixxcard[%s]\n",sIrelative_card, trim(sIxxcard));
    printf("qply2_period[%d],  dply2_begin[%s]\n",sQply2_period, sDply2_begin);
    printf("dply2_end[%s],     qply1_period[%d]\n",sDply2_end, sQply1_period);
    printf("dply1_begin[%s],   dply1_end[%s]\n",sDply1_begin, sDply1_end);
    printf("fassured[%s],      iassured[%s]\n",sFassured, sIassured);
    printf("nassured[%s],      ilicense[%s]\n",sNassured, sIlicense);
    printf("ibirth[%s],        fsex[%s]\n",sIbirth, sFsex);
    printf("fmarriage[%s],     nuser[%s]\n",sFmarriage, sNuser);
    printf("ibenef[%s],        nbenef[%s]\n",sIbenef, sNbenef);
    printf("aassured_zip[%s],  itel[%s]\n",sAassured_zip, sItel);
    printf("itel_night[%s],    mobil_phone[%s]\n",sItel_night, sMobil_phone);
    printf("apayment[%s],      apayment_zip[%s]\n",sApayment, sApayment_zip);
    printf("iply_area[%s],     iissue_ym[%s]\n", sIply_area, sIissue_ym);
    printf("ipro_year[%s],     ibrand[%s]\n",sIpro_year, sIbrand);
    printf("nbrand_abbr[%s],   icar_type2[%s]\n", sNbrand_abbr, sIcar_type2);
    printf("icar_type1[%s],    ncar_abbr[%s]\n",sIcar_type1, sNcar_abbr);
    printf("qcylinder[%f],     iengine[%s]\n", sQcylinder, sIengine);
    printf("ibody[%s],         itag[%s]\n", trim(sIbody), trim(sItag));
    printf("iexaminer[%s],     dexamine[%s]\n",trim(sIentry), sDentry);
    printf("ientry[%s],        dentry[%s]\n", trim(sIentry), sDentry);
    printf("iroute[%s],        iofficer_prmt[%s]\n",sIroute,sIofficer_prmt);
    printf("iquota_prmt[%s],   ileader_prmt[%s]\n",sIquota_prmt,sIleader_prmt);
    printf("nfax_cus[%s],      nemail_cus[%s]\n",sNfax_cus, sNemail_cus);
    printf("psex_age_damage[%f],qpro_month[%d]\n",sPsex_age_damage,sQpro_month);
    printf("iroute_prop[%s],   fuw_status[%d]\n", sIroute_prop, sFuw_status);
    printf("duw_first[%s]\n",  sDuw_first);
    printf("sDnotifyornot[%s]\n",sDnotifyornot);
    printf("iDmg_acc_sum_5y[%d]\n",iDmg_acc_sum_5y);
    printf("iLia_acc_sum_5y[%d]\n",iLia_acc_sum_5y);
    printf("iDuty_acc_sum_5y[%d]\n",iDuty_acc_sum_5y);
    printf("qacc_sum_5y[%d]\n",qacc_sum_5y);
    printf("fhave_newa_c_2y[%s]\n",fhave_newa_c_2y);
    printf("sDinstall[%s]\n",sDinstall);
    printf("sIsequence[%s]\n",sIsequence);
    printf("sAinstall_zip[%s]\n",sAinstall_zip);
    printf("sAinstall[%s]\n",sAinstall);
    
    printf("sDfirst_ply1[%s]\n",sDfirst_ply1);
    printf("sDfirst_ply2[%s]\n",sDfirst_ply2);
    
    /*1090508001-SC1-��౻T-��T�M��[�ظm�T�������O�T�I�����κި�t�� */
    printf("sIext_policy[%s]\n",sIext_policy ); 
    printf("sIrisk[%s]\n", sIrisk); 
    printf("sIlast_quote[%s]\n", sIlast_quote); 
    printf("sIowner[%s]\n",sIowner ); 
    printf("sNowner[%s]\n", sNowner); 
    printf("sDbirth_owner[%s]\n",sDbirth_owner ); 
    
    if (sIofficer_prmt[0]=='\0') strcpy(sIofficer_prmt," ");
    if (sIquota_prmt[0]=='\0')   strcpy(sIquota_prmt," ");
    if (sIleader_prmt[0]=='\0')  strcpy(sIleader_prmt," ");
    if (sNfax_cus[0]=='\0')      strcpy(sNfax_cus," ");
    if (sNemail_cus[0]=='\0')    strcpy(sNemail_cus," ");
    if (sNroute_cus[0]=='\0')    strcpy(sNroute_cus," ");
    if (sNname_cus[0]=='\0')     strcpy(sNname_cus," ");
    if (sItel_cus[0]=='\0')      strcpy(sItel_cus," ");
    if (sMobil_phone_cus[0]=='\0') strcpy(sMobil_phone_cus," ");
    if (sNnote_cus[0]=='\0')     strcpy(sNnote_cus," ");
    if (sNnote_leader[0]=='\0')  strcpy(sNnote_leader," ");
    if (sIrate_type1[0]=='\0')   strcpy(sIrate_type1," ");
    if (sIrate_type2[0]=='\0')   strcpy(sIrate_type2," ");
    if (sBzfrom1[0]=='\0')       strcpy(sBzfrom1," ");
    if (sBzfrom2[0]=='\0')       strcpy(sBzfrom2," ");
    if (sIroute_comm1[0]=='\0')  strcpy(sIroute_comm1," ");
    if (sIroute_comm2[0]=='\0')  strcpy(sIroute_comm2," ");
    if (sIcomm_obj1[0]=='\0')    strcpy(sIcomm_obj1," ");
    if (sIcomm_obj2[0]=='\0')    strcpy(sIcomm_obj2," ");
    if (sFapplicant[0]=='\0')    strcpy(sFapplicant," ");
    if (sFsex_appl[0]=='\0')     strcpy(sFsex_appl," ");
    if (sItel_appl[0]=='\0')     strcpy(sItel_appl," ");
    if (sNdeputy_appl[0]=='\0')  strcpy(sNdeputy_appl," ");
    if (sDbirth_appl[0]=='\0')   strcpy(sDbirth_appl," ");
    if (sNrelation_appl[0]=='\0') strcpy(sNrelation_appl," ");
    if (sNdeputy_assured[0]=='\0') strcpy(sNdeputy_assured," ");

    if (sIquery_num_damage[0]=='\0') 	strcpy(sIquery_num_damage," ");
    if (sIquery_num_damage2[0]=='\0') 	strcpy(sIquery_num_damage2," ");
    if (sIquery_num_damage3[0]=='\0') 	strcpy(sIquery_num_damage3," ");
    if (sIquery_num_unknown[0]=='\0') 	strcpy(sIquery_num_unknown," ");
    if (sIquery_num_unknown2[0]=='\0') 	strcpy(sIquery_num_unknown2," ");

    if (sNpost_recipient[0]=='\0') 	strcpy(sNpost_recipient," ");
    if (sApost_zip[0]=='\0') 		strcpy(sApost_zip," ");
    if (sApost_address[0]=='\0') 	strcpy(sApost_address," ");
    
    if (sIquery_num_last_brg[0]=='\0') strcpy(sIquery_num_last_brg," ");
    if (sIpolicy_last_brg[0]=='\0') strcpy(sIpolicy_last_brg," ");
    if (sIpay_way[0]=='\0') strcpy(sIpay_way," ");
   	if (sIrelative_card[0]=='\0') strcpy(sIrelative_card," ");
   	
   	if (sNassured_cntry[0]=='\0') strcpy(sNassured_cntry," ");
   	if (sNapplicant_cntry[0]=='\0') strcpy(sNapplicant_cntry," ");
   	
   	if (sfoccup[0]=='\0') strcpy(sfoccup," ");
   	if (snoccup[0]=='\0') strcpy(snoccup," ");
   	if (sapplicant_foccup[0]=='\0') strcpy(sapplicant_foccup," ");
   	if (sapplicant_noccup[0]=='\0') strcpy(sapplicant_noccup," ");
    if (sfbatch_b2c[0]=='\0')       strcpy(sfbatch_b2c," ");
   	
   	if (sTmobile_appl[0]=='\0')     strcpy(sTmobile_appl," ");
    if (sAemail_appl[0]=='\0')      strcpy(sAemail_appl," ");

    /*1090508001-SC1-��౻T-��T�M��[�ظm�T�������O�T�I�����κި�t�� */
    if(sIext_policy[0]=='\0')    strcpy(sIext_policy ," ");
    if(sIrisk[0]=='\0')          strcpy(sIrisk," ");
    if(sIlast_quote[0]=='\0')    strcpy(sIlast_quote," ");
    if(sIowner[0]=='\0')         strcpy(sIowner ," ");
    if(sNowner[0]=='\0')         strcpy(sNowner," ");
    if(sDbirth_owner[0]=='\0')   strcpy(sDbirth_owner ," ");
    if(sIengine[0]=='\0')   strcpy(sIengine ," ");
    if(sIsecond_hand[0]=='\0')   strcpy(sIsecond_hand ," "); /*1101012001-SC1-���ά�-�W�[�B�z���j�������*/
    
	sTransPrem =  sMpremium1 + sMpremium2;
  
    if (count > 0)
    {
      $INSERT INTO estimate
         (iestimate, icard2, icard1, ilast_ply, ilast_card, irelative_card,
          ixxcard, qply2_period, dply2_begin, dply2_end, qply1_period,
          dply1_begin, dply1_end, fassured, iassured, nassured, ilicense,
          ibirth, fsex, fmarriage, nuser, ibenef, nbenef, aassured,
          aassured_zip, itel, itel_night, mobil_phone, apayment, apayment_zip,
          iply_area, iissue_ym, ipro_year, ibrand, nbrand_abbr, icar_type2,
          icar_type1, ncar_abbr, qcylinder, iengine, ibody, itag, mcar_price,
          nequipment, mpremium2, mpremium1, ibig_comp, ibig_office, ibig_sales,
          iresource, fdiscount, ibroker2, ibroker1, iofficer2, iofficer1,
          icorps, iarea, icashier, iexaminer, dexamine, ientry, dentry, dapply,
          fprint, fcal_way, idmg_rate, pdmg_factor, ibrg_rate, pbrg_factor,
          ibranch, qpt, fpt, psex_age2, psex_age1, psex_age_damage, lia_class,
          plia_acc2, plia_acc1, pdmg_acc, abnormal_est, mready,
          mstable, mcompensation, mresearch, minvest, mbus_rule, mbusiness,
          madjcom_prem, mcapital, maintain, fcomp_class, fcomp_class_last,
          iemail, iquery_num_c, iquery_num, icar_flag1, icar_flag2, transno,
          qpro_month,iaccept,flag_list,iquery_num_damage,iapplicant, napplicant,
          dbirth, dissue, iextra_charge, mequipment, survey_num, bound_num,
          iroute_prop, iroute, iofficer_prmt, iquota_prmt, ileader_prmt,
          nfax_cus, nemail_cus, nroute_cus, nname_cus, itel_cus,
          mobil_phone_cus, nnote_cus, nnote_leader, irate_type1, irate_type2,
          bzfrom1, bzfrom2, iroute_comm1, iroute_comm2, icomm_obj1, icomm_obj2,
          qlia_acc_sum, qdmg_acc_sum, qprovision, fapplicant, fsex_appl,
          dbirth_appl, itel_appl, ndeputy_appl, nrelation_appl,
          ndeputy_assured, fuw_status, iuw_first, duw_first, pdmg_acc2,
          qdmg_acc_sum2, iquery_num_damage2, pdmg_acc3, qdmg_acc_sum3,
          iquery_num_damage3, dcomp_lastdend, qdrunk_driving,
          icomp_cartype_last,dsign,iassured_cntry,iapplicant_cntry,nassured_cntry,napplicant_cntry,funknown_dmg,
          fequipment1,fequipment2,fequipment3,fequipment4,fequipment5,fequipment6,
          fequipment9,nequipment9,feply,feterms,aemail_eply,tmobile_eply,ireg_no,
          punknown_acc,qunknown_acc_sum,iquery_num_unknown,punknown_acc2,qunknown_acc_sum2,iquery_num_unknown2,
          fout_print,fmail_type,npost_recipient,apost_zip,apost_address,
          iquery_num_last_brg, dply_end_last_brg, ipolicy_last_brg, dcust_apply, ipay_way,trans_prem,fcomp_24,
          foccup,noccup,applicant_foccup,applicant_noccup,fbatch_b2c,tmobile_appl,aemail_appl,fecard,
          iext_policy,  mkilo_ply, irisk, irelative_ext, iowner,nowner,dbirth_owner,dnotifyornot,
          idmg_acc_sum_5y,ilia_acc_sum_5y,iduty_acc_sum_5y,dfirst_ply1,dfirst_ply2,isecond_hand,qviolate,
          qacc_sum_5y,fhave_newa_c_2y,dinstall,isequence,ainstall_zip,ainstall)
        VALUES
         ($sIestimate, $sIcard2, $sIcard1, $sIlast_ply, $sIlast_card,
          $sIrelative_card, $sIxxcard, $sQply2_period, $sDply2_begin,
          $sDply2_end, $sQply1_period, $sDply1_begin, $sDply1_end, $sFassured,
          $sIassured, $sNassured, $sIlicense, $sIbirth, $sFsex, $sFmarriage,
          $sNuser, $sIbenef, $sNbenef, $sAassured, $sAassured_zip, $sItel,
          $sItel_night, $sMobil_phone, $sApayment, $sApayment_zip, $sIply_area,
          $sIissue_ym, $sIpro_year, $sIbrand, $sNbrand_abbr, $sIcar_type2,
          $sIcar_type1, $sNcar_abbr, $sQcylinder, $sIengine, $sIbody, $sItag,
          $sMcar_price, $sNequipment, $sMpremium2, $sMpremium1, $sIbig_comp,
          $sIbig_office, $sIbig_sales, $sFprop, "N", $sIbroker2, $sIbroker1,
          $sIofficer2, $sIofficer1, $sIcorps, $sIarea, $sIcashier, $sIentry,
          $sDentry, $sIentry, $sDentry, $sDapply, $sFprint, $sFcal_way,
          $sIdmg_rate, $sPdmg_factor, $sIbrg_rate, $sPbrg_factor, $sIbranch,
          $sQpt, $sFpt, $sPsex_age2, $sPsex_age1, $sPsex_age_damage,
          $sLia_class_V, $sPlia_acc2, $sPlia_acc1,$sPdmg_acc,$sAbnormal_est,
          $sMready, $sMstable, $sMcompensation, $sMresearch,
          $sMinvest, $sMbus_rule, $sMbusiness, $sMadjcom_prem, $sMcapital,
          $sMaintain, $sFcomp_class, $sFcomp_class_last, $sIemail,
          $sIquery_num_c, $sIquery_num, $sIcar_flag1, $sIcar_flag2, $sTransno,
          $sQpro_month, $sIaccept,' ', $sIquery_num_damage, $sIapplicant,
          $sNapplicant, $sDbirth, $sDissue, $sIextra_charge, $sMequipment,
          $sSurvey_num, $sBound_num, $sIroute_prop, $sIroute, $sIofficer_prmt,
          $sIquota_prmt, $sIleader_prmt, $sNfax_cus, $sNemail_cus, $sNroute_cus,
          $sNname_cus, $sItel_cus, $sMobil_phone_cus, $sNnote_cus, $sNnote_leader,
          $sIrate_type1, $sIrate_type2, $sBzfrom1, $sBzfrom2, $sIroute_comm1,
          $sIroute_comm2, $sIcomm_obj1, $sIcomm_obj2, $sQlia_acc_sum_V,
          $sQdmg_acc_sum_V, $sQprovision, $sFapplicant, $sFsex_appl,$sDbirth_appl,
          $sItel_appl, $sNdeputy_appl, $sNrelation_appl, $sNdeputy_assured,
          $sFuw_status , $sIuw_first, $sDuw_first, $sPdmg_acc2, $sQdmg_acc_sum2,
          $sIquery_num_damage2, $sPdmg_acc3, $sQdmg_acc_sum3,
          $sIquery_num_damage3, $sDcomp_lastdend, $sQdrunk_driving,
          $sIcomp_cartype_last,$sDsign,$sIassured_cntry,$sIapplicant_cntry,$sNassured_cntry,$sNapplicant_cntry,$sFunknown_dmg,
          $sFequipment1,$sFequipment2,$sFequipment3,$sFequipment4,$sFequipment5,$sFequipment6,
          $sFequipment9,$sNequipment9,$sFeply,$sFeterms,$sAemail_eply,$sTmobile_eply,$sIreg_no,
          $sPunknown_acc,$sQunknown_acc_sum,$sIquery_num_unknown,$sPunknown_acc2,$sQunknown_acc_sum2,$sIquery_num_unknown2,
          $sFout_print,$sFmail_type,$sNpost_recipient,$sApost_zip,$sApost_address,
          $sIquery_num_last_brg, $sDply_end_last_brg, $sIpolicy_last_brg, $sDcust_apply, $sIpay_way, $sTransPrem,"N",
          $sfoccup, $snoccup, $sapplicant_foccup, $sapplicant_noccup,$sfbatch_b2c,$sTmobile_appl,$sAemail_appl,$sFecard,
          $sIext_policy,$mkilo_ply,$sIrisk,$sIlast_quote,$sIowner,$sNowner,$sDbirth_owner,$sDnotifyornot,
          $iDmg_acc_sum_5y,$iLia_acc_sum_5y,$iDuty_acc_sum_5y,$sDfirst_ply1,$sDfirst_ply2,$sIsecond_hand,$sQviolate,
          $qacc_sum_5y,$fhave_newa_c_2y,$sDinstall,$sIsequence,$sAinstall_zip,$sAinstall);

          if( sqlca.sqlerrd[2] == 0) return M_CA_QT_TRANS_FAILED;
          printf("*****insert into estimate SUCCESS*****\n");
    }

    return M_CM_OK;

errexit:
    sprintf_s( v_sMsg, 250,"SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d", SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    /*$ROLLBACK WORK;*/
    end_ca_quote_to_est( v_sMsg);
    return SQLCODE;
}
/*************************************************************************************************/
long ca_insert_to_est_ins()
{
	  int i;
    $char sStmt[2048], v_sMsg[256];

	  $WHENEVER SQLERROR GOTO errexit;

    sprintf_s(sStmt,sizeof sStmt,"SELECT iins_type,minjured_cover,mdeath_cover,mdamage_cover, "
                                 "       mdeduct, mins_premium,mpure_prem,qserial,pcommission,"
                                 "       mcommission, pagent, magent, pdiscount, mdiscount, "
                                 "       drate_ym, mprem, iproduct, qday, mexpense, mexp_disc,"
                                 "       provision, irate, adjust_rate, mins_premium_n, "
                                 "       mpure_prem_n, mprem_n, safe_rate, manage_rate,"
                                 "       educated_rate, deviation_rate, pextra_charge, "
                                 "       pbusiness, psex_age, pshipping,fproject, mdrunk_prem,"
                                 "       mdrunk_pure_prem, mviolate_prem, mviolate_pure_prem "
                                 "  FROM ca_quotation_ins "
                                 " WHERE iquote = '%s';", sIestimate);

    $PREPARE ca_est_ins_type FROM $sStmt;
    $DECLARE est_ins_cur CURSOR FOR ca_est_ins_type;
    $OPEN    est_ins_cur;
    printf("*****Query ca_quotation_ins*****\n");
    printf("sStmt[%s]\n", sStmt);
    for(;;)
    {
        $FETCH est_ins_cur INTO $sIins_type, $sMinjured_cover, $sMdeath_cover,
                               $sMdamage_cover, $sMdeduct, $sMins_premium,
                               $sMpure_prem,$sQserial, $sPcommission,
                               $sMcommission, $sPagent, $sMagent,$sPdiscount,
                               $sMdiscount, $sDrate_ym, $sMprem, $sIproduct,
                               $sQday, $sMexpense, $sMexp_disc, $sProvision,
                               $sIrate, $sAdjust_rate, $sMins_premium_n,
                               $sMpure_prem_n, $sMprem_n,$sSafe_rate,
                               $sManage_rate, $sEducated_rate, $sDeviation_rate,
                               $sPextra_charge, $sPbusiness, $sPsex_age,
                               $sPshipping, $sFproject, $sMdrunk_prem,
                               $sMdrunk_pure_prem,$sMviolate_prem ,$sMviolate_pure_prem;

        if (SQLCODE == SQLNOTFOUND) break;
        if (sIest_cnt == 0 && strcmp(trim(sIins_type),"21") == 0) continue; /* 1070125001-SC7-�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o*/
        $INSERT INTO est_ins_type
            (iestimate, iins_type, minjured_cover, mdeath_cover, mdamage_cover,
             mdeduct, mins_premium, mpure_prem, qserial, pcommission,
             mcommission, pagent, magent, pdiscount, mdiscount, drate_ym,mprem,
             iproduct, qday, mexpense, mexp_disc, provision, irate,adjust_rate,
             mins_premium_n, mpure_prem_n, mprem_n, safe_rate, manage_rate,
             educated_rate, deviation_rate, pextra_charge, pbusiness, psex_age,
             pshipping, fproject, mdrunk_prem, mdrunk_pure_prem, mviolate_prem,
             mviolate_pure_prem)
         VALUES
            ($sIestimate, $sIins_type, $sMinjured_cover, $sMdeath_cover,
             $sMdamage_cover, $sMdeduct, $sMins_premium, $sMpure_prem,
             $sQserial, $sPcommission, $sMcommission, $sPagent, $sMagent,
             $sPdiscount, $sMdiscount, $sDrate_ym, $sMprem, $sIproduct,
             $sQday, $sMexpense, $sMexp_disc, $sProvision, $sIrate,
             $sAdjust_rate, $sMins_premium_n, $sMpure_prem_n, $sMprem_n,
             $sSafe_rate, $sManage_rate, $sEducated_rate, $sDeviation_rate,
             $sPextra_charge, $sPbusiness, $sPsex_age, $sPshipping,
             $sFproject, $sMdrunk_prem, $sMdrunk_pure_prem, $sMviolate_prem,
             $sMviolate_pure_prem);

       if( sqlca.sqlerrd[2] == 0) return M_CA_QT_TRANS_FAILED;

       strcpy(sIins_type, trim(sIins_type));
       if( strcmp(sIins_type,"34") == 0 || strcmp(sIins_type,"87") == 0 ||
        	 strcmp(sIins_type,"115") == 0 )
       {
           for(i = 1; i <= 4; i++)
           {
           	   strcpy(sIcover_type, "00");
           	   strcat(sIcover_type, itoa(i));
               if ( i == 1)
                   sMcover = sMinjured_cover;
               else if ( i == 2)
                   sMcover = sMinjured_cover*2;
               else if ( i == 3)
               	   sMcover = sMdeath_cover;
               else
               	   sMcover = sMdamage_cover;

               strcpy(sIcover_type, trim(sIcover_type));
               printf("icover_type[%s],mcover[%d]\n", sIcover_type,sMcover);
               $INSERT INTO est_ins_cover
                      (iestimate, iins_type, icover_type,mcover, mcover_prem,
                       mdiscount, mprem, mpure_prem)
                VALUES($sIestimate, $sIins_type, $sIcover_type, $sMcover, 0, 0, 0, 0);

               if( sqlca.sqlerrd[2] == 0) return M_CA_QT_TRANS_FAILED;

           }
       }
    }
    printf("*****insert into est_ins_type SUCCESS*****\n");
    $CLOSE est_ins_cur;
    $FREE  est_ins_cur;

    return M_CM_OK;

errexit:
    sprintf_s( v_sMsg, 250,"SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    /*$ROLLBACK WORK;*/
    end_ca_quote_to_est( v_sMsg);
    return SQLCODE;
}
/*************************************************************************************************/
long ca_insert_to_est_ins_assured()
{
	  int i;
    $char sStmt[2048], v_sMsg[256];
    $char tmp_pure_prem[12], tmp_commission[6];
    $char tmp_agent[6],  tmp_discount[6], tmp_mr_pure_prem[12];

	  $WHENEVER SQLERROR GOTO errexit;

    /* �s�W147�I�ئW�U (1110310005_SC1) */
    sprintf_s(sStmt,sizeof sStmt,"INSERT INTO est_ins_assured "
                                 "SELECT a.iquote, CASE WHEN b.iins_type = 'D' OR b.iins_type = 'J' THEN ' ' "
                                 "       ELSE b.iins_type END, "
                                 "       CASE WHEN b.iins_type = 'D' THEN 'D' WHEN b.iins_type = 'J' THEN 'J' ELSE ' ' END, "
                                 "       a.iassured, a.nassured[1,30], a.dbirth, "
                                 "       a.nbenef[1,30], a.rel_benef, a.tbenef, a.abenef_zip, a.abenef, 0 "
                                 "  FROM ca_quotation_assured a, ca_quotation_assured_dtl b "
                                 " WHERE a.iquote = b.iquote "
                                 "   AND a.iassured = b.iassured "
                                 "   AND a.iquote = ? "
                                 "   AND NOT (len(trim(a.iassured)) = 1 AND (trim(a.iassured)) = 'A' ) "
                                 "   AND b.iins_type in ('50','80','D','J','147','561');");

    $PREPARE pre_estInsAassured FROM $sStmt;
    $EXECUTE pre_estInsAassured using $sIestimate;

    printf("*****into est_ins_assured SUCCESS *****\n");
    /* 1090221006-SC1-��ã��-��_56�r�p�H�W�U�Aebp�|�g�@���N��=A������ơA���n�a�J*/
    sprintf_s(sStmt,sizeof sStmt,"INSERT INTO ca_pa_est "
                                 "SELECT a.iquote, b.iins_type, a.iassured[1,10], a.nassured[1,30],"
                                 "       a.dbirth, ' ', b.iins_scope, ' ', "
                                 "       b.mins_amt,b.mins_premium, b.mpure_prem,b.pcommission, "
                                 "       b.mcommission, b.pagent, b.magent, b.pdiscount, "
                                 "       b.mdiscount, CASE WHEN b.iins_type = '21' THEN "
                                 "       (SELECT napplicant FROM quotation_master "
                                 "        WHERE iquote = a.iquote AND iins_kind_ply = 'C1') "
                                 "       ELSE (SELECT napplicant FROM quotation_master "
                                 "              WHERE iquote = a.iquote AND iins_kind_ply = 'C2') END, "
                                 "       a.frel_assured, a.nbenef[1,30], a.rel_benef, "
                                 "       b.daily_pay,b.mr_ins_prem,b.mr_pure_prem,a.tbenef, a.abenef_zip, a.abenef[1,90] "
                                 "  FROM ca_quotation_assured a, ca_quotation_assured_dtl b "
                                 " WHERE a.iquote = b.iquote "
                                 "   AND a.iassured = b.iassured "
                                 "   AND a.iquote = ? "
                                 "   AND NOT (len(trim(a.iassured)) = 1 AND (trim(a.iassured)) = 'A' ) "
                                 "   AND b.iins_type in ('35','48','56','136','166','266');");
    /*1080225007-SC-�s�W166�I��*/ /*1110308005_SC1_�s�W266�I��*/
    $PREPARE pre_caPaEst FROM $sStmt;
    $EXECUTE pre_caPaEst using $sIestimate;

    printf("*****into ca_pa_est SUCCESS *****\n");

    return M_CM_OK;

errexit:
    sprintf_s( v_sMsg, 250,"SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    /*$ROLLBACK WORK;*/
    end_ca_quote_to_est( v_sMsg);
    return SQLCODE;
}
/*************************************************************************************************/
long ca_insert_to_bound_dtl()
{
    int i;
    $char sStmt[2048], v_sMsg[256];

    $WHENEVER SQLERROR GOTO errexit;

    sprintf_s(sStmt,sizeof sStmt,"INSERT INTO ca_est_bound "
                  "SELECT unique a.iquote, b.ibound "
                  "  FROM ca_quotation a, ca_bound_dtl b "
                  " WHERE a.ibound_num = b.ibound_num "
                  "   AND a.iquote = ? ;");

    $PREPARE pre_BoundDtl FROM $sStmt;
    $EXECUTE pre_BoundDtl using $sIestimate;

    printf("*****into ca_est_bound SUCCESS *****\n");

    return M_CM_OK;

errexit:
    sprintf_s( v_sMsg, 250,"SQLCODE=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    /*$ROLLBACK WORK;*/
    end_ca_quote_to_est( v_sMsg);
    return SQLCODE;
}
/*************************************************************************************************/
void end_ca_quote_to_est(v_sMsg)
char *v_sMsg;
{
    printf(" v_sMsg[%s]\n", v_sMsg);
    puts("end ca_quote_to_est function");
    puts("*********************************");
    puts("");
}
/*************************************************************************************************/
void ca_estimate_init()
{
    printf("***** init data *****\n");
    strcpy(sIins_kind_ply," "); strcpy(sIcard," "); strcpy(sIcar_type," ");
    strcpy(sIofficer," "); strcpy(sIlast_card," "); strcpy(sIassured," ");
    strcpy(sIcard2," "); strcpy(sIcard1," "); strcpy(ilast_ply," "); strcpy(sIlast_ply," ");
    strcpy(sIrelative_card," "); strcpy(sIxxcard," "); strcpy(sFassured," ");
    strcpy(sIlicense," "); strcpy(sIbirth," "); strcpy(sFsex," ");
    strcpy(sFmarriage," ");  strcpy(sIexaminer," "); strcpy(sItel_night," ");
    strcpy(sNuser," "); strcpy(sIissue_ym," "); strcpy(sItag," ");
    strcpy(sIbenef," "); strcpy(sAassured_zip,""); strcpy(sItel," ");
    strcpy(sMobil_phone," "); strcpy(sApayment_zip," "); strcpy(sIply_area," ");
    strcpy(sIbrg_rate," "); strcpy(sIbody," "); strcpy(sIengine," ");
    strcpy(sIpro_year, " "); strcpy(sIbrand," "); strcpy(sNbrand_abbr," ");
    strcpy(sIcar_type2," "); strcpy(sIcar_type1," "); strcpy(sNcar_abbr," ");
    strcpy(sNequipment," "); strcpy(sIbig_comp," "); strcpy(sIbig_office," ");
    strcpy(sIbig_sales," "); strcpy(sIresource," "); strcpy(sIbroker2," ");
    strcpy(sIbroker1," "); strcpy(sIofficer2," "); strcpy(sIofficer1," ");
    strcpy(sIcorps," "); strcpy(sIarea," "); strcpy(sIcashier," ");
    strcpy(sIentry," "); strcpy(sFprint," "); strcpy(sFcal_way," ");
    strcpy(sIdmg_rate," "); strcpy(sIbranch," "); strcpy(sFpt," ");
    strcpy(sLia_class," "); strcpy(sFcomp_24," "); strcpy(sAbnormal_est," ");
    strcpy(sIabn_type," "); strcpy(sFcomp_class,"4"); strcpy(sLia_class_V,"4");
    strcpy(sFcomp_class_last," "); strcpy(sIquery_num_c," ");
    strcpy(sIcar_flag1," "); strcpy(sIcar_flag2," "); strcpy(sTransno," ");
    strcpy(sIaccept," "); strcpy(sIapplicant," ");
    strcpy(sIextra_charge," "); strcpy(sIroute_prop," ");
    strcpy(sIrate_type1," "); strcpy(sIrate_type2," "); strcpy(sBzfrom1," ");
    strcpy(sBzfrom2," "); strcpy(sIroute_comm," "); strcpy(sIroute_comm1," ");
    strcpy(sIroute_comm2," "); strcpy(sIcomm_obj1," "); strcpy(sIcomm_obj2," ");
    strcpy(sFapplicant," "); strcpy(sFsex_appl," "); strcpy(sIuw_first,"");
    strcpy(sIcomp_cartype_last," "); strcpy(sNassured," "); strcpy(sNbenef," ");
    strcpy(sAassured," "); strcpy(sApayment," "); strcpy(sIemail," ");
    strcpy(sIquery_num," "); strcpy(sIquery_num_damage," ");
    strcpy(sNapplicant," "); strcpy(sSurvey_num," ");
    strcpy(sBound_num," "); strcpy(sIroute," "); strcpy(sIofficer_prmt," ");
    strcpy(sIquota_prmt," "); strcpy(sIleader_prmt," "); strcpy(sNfax_cus," ");
    strcpy(sNemail_cus," "); strcpy(sNroute_cus," "); strcpy(sNname_cus," ");
    strcpy(sItel_cus," "); strcpy(sMobil_phone_cus," "); strcpy(sNnote_cus," ");
    strcpy(sNnote_leader," "); strcpy(sItel_appl," ");strcpy(sNdeputy_appl," ");
    strcpy(sNrelation_appl," "); strcpy(sNdeputy_assured," ");
    strcpy(sIquery_num_damage2," "); strcpy(sIquery_num_damage3," ");
    strcpy(sIcar_flag," "); strcpy(sIrate_type," "); strcpy(sBzfrom," ");
    strcpy(sIcomm_obj," "); strcpy(sIlia_query_num,"");
    strcpy(ilast_card1," ");
    strcpy(ilast_card2," "); strcpy(irelative_card1," "); strcpy(idmg_rate," ");
    strcpy(ibrg_rate," "); strcpy(iquery_num_damage2," ");
    strcpy(irelative_card2," "); strcpy(iquery_num_damage3," ");
    strcpy(iquery_num_damage," ");
    strcpy(iquery_num_unknown," ");strcpy(sIquery_num_unknown," ");
    strcpy(iquery_num_unknown2," ");strcpy(sIquery_num_unknown2," ");
    strcpy(feply," ");strcpy(aemail_eply," ");strcpy(sFeply," ");strcpy(sAemail_eply," ");
    strcpy(feterms," "); strcpy(sFeterms," "); /*1100419003-���I�O�����QR Code�q�l��-�ȥ��O��u�q�l���ڡv  feterms feply =1�ɡA�����O�@�v��0�A�j���I�@�߬�0*/
	strcpy(tmobile_eply," ");strcpy(sTmobile_eply," ");/*1080417001-SC1-���ά�-�s�W�q�l�O��H²�T�覡�o�e */
    strcpy(fout_print," ");strcpy(fmail_type," ");strcpy(sFout_print," ");strcpy(sFmail_type," ");
    strcpy(npost_recipient," ");strcpy(sNpost_recipient," ");
    strcpy(apost_zip," ");strcpy(sApost_zip," ");
    strcpy(apost_address," ");strcpy(sApost_address," "); strcpy(sTmobile_appl," "); strcpy(sAemail_appl," ");
    strcpy(sFecard,"0");strcpy(fecard,"0");
	strcpy(sIreg_no," ");/* 1080408005-SC1-��ã��-�j���һ{�ҷs�W�q����Ƥεn���Ҹ� */
	strcpy(sDnotifyornot," ");/*1090831006-SC1-���ʱo-�{�ҥ��x�j��q�l���ҥ���g�����mail�ˮ�*/
    sDins_bgn[0]=sDins_end[0]=0;
    sDply2_begin[0]=sDply2_end[0]=sDply1_begin[0]=sDply1_end[0]=sDexamine[0]=0;
    sDentry[0]=sDapply[0]=sDbirth[0]=sDissue[0]=sDbirth_appl[0]=sDuw_first[0]=0;
    sDcomp_lastdend[0]=0;
    sQply_period=sMpremium=sPsex_age_e=sPlia_acc=0;
    sQply1_period=sQply2_period=sQcylinder=sMpremium2=sMpremium1=sQpro_month=0;
    sQdrunk_driving=sQviolate=sQlia_acc_sum=sQdmg_acc_sum=qprovision=sQprovision=sFuw_status=0;
    sQdmg_acc_sum2=sQdmg_acc_sum3=sPsex_age_damage=0;
    sMcar_price=mcar_price=sPdmg_factor=sPbrg_factor=sQpt=sPsex_age2=sPsex_age1=0;
    pdmg_factor=pbrg_factor=sQlia_acc_sum_V=sQdmg_acc_sum_V=0;
    sPlia_acc2=sPlia_acc1=pdmg_acc=sPdmg_acc=sMready=sMstable=sMcompensation=0;
    sMresearch=sMinvest=sMbus_rule=sMbusiness=sMadjcom_prem=sMcapital=0;
    sMaintain=sMequipment=mequipment=pdmg_acc2=sPdmg_acc2=pdmg_acc3=sPdmg_acc3=0;
    qdmg_acc_sum2=qdmg_acc_sum3==0;
    punknown_acc=sPunknown_acc=punknown_acc2=sPunknown_acc2=0;
    qunknown_acc_sum=sQunknown_acc_sum=qunknown_acc_sum2=sQunknown_acc_sum2=0;


    strcpy(sIins_type," "); strcpy(sDrate_ym," "); strcpy(sIproduct," ");
    strcpy(sProvision," "); strcpy(sFproject," ");
    sMinjured_cover=sMdeath_cover=sMdamage_cover=sMdeduct=sMins_premium=0;
    sQserial=sMcommission=sMagent=sMdiscount=sMprem=sQday=sMexpense=0;
    sMexp_disc=sIrate=sMins_premium_n=sMprem_n=sMdrunk_prem=sMviolate_prem=sMpure_prem=0;
    sPcommission=sPagent=sPdiscount=sAdjust_rate=sMpure_prem_n=sSafe_rate=0;
    sManage_rate=sEducated_rate=sDeviation_rate=0;
    sPextra_charge=sPbusiness=sPsex_age=sPshipping=sMdrunk_pure_prem=sMviolate_pure_prem=0;

    strcpy(sIcover_type," ");
    sMcover=0;

    strcpy(sIins_type_pa," "); strcpy(iassured_a," "); strcpy(sIassured_a," ");
    strcpy(sNassured_a," "); strcpy(sNbenef_a," "); strcpy(sRel_benef," ");
    strcpy(sProvision_a," ");
    sDbirth_a[0]=0;

    strcpy(sIinsurant,""); strcpy(sNinsurant,""); strcpy(sIins_scope," ");
    strcpy(sRelation_bene," "); strcpy(sNbeneficiary," ");
    sDbirth_pa[0]=0;
    sMins_amt_pa=sMins_premium_pa=sMcommission_pa=sMagent_pa=sMdiscount_pa=0;
    sDaily_pay=sMr_ins_prem=sMpure_prem_pa=sPcommission_pa=sPagent_pa=0;
    sPdiscount_pa=sMr_pure_prem=sTransPrem=0;

    strcpy(funknown_dmg," ");strcpy(sFunknown_dmg," ");
    
    strcpy(foccup," ");strcpy(noccup," ");
    strcpy(applicant_foccup," ");strcpy(applicant_noccup," ");
    strcpy(sfoccup," ");strcpy(snoccup," ");
    strcpy(sapplicant_foccup," ");strcpy(sapplicant_noccup," ");
    strcpy(fbatch_b2c," ");strcpy(sfbatch_b2c," ");
    
    /* 1090508001-SC1-��౻T-��T�M��[�ظm�T�������O�T�I�����κި�t��*/
    strcpy(sIrisk," ");  strcpy(sIrelative_ext," ");  
    strcpy(sIowner," ");  strcpy(sNowner," ");  strcpy(sDbirth_owner," ");  
    strcpy(sIlast_quote," ");  
    mkilo_ply = 0.0;
    
    iDmg_acc_sum_5y = 0;          /* 1090803002-SC1-�ӽ�HCC�֫O�ҫ�   ����e���~�߮צ��� */
    iLia_acc_sum_5y = 0;          /* 1090803002-SC1-�ӽ�HCC�֫O�ҫ�   ���d�e���~�߮צ��� */
    iDuty_acc_sum_5y    = 0;      /* 1090803002-SC1-�ӽ�HCC�֫O�ҫ�   �e���~���F�d�p������(����+���d) */
    strcpy(sDfirst_ply1," ");     /* 1090803002-SC1-�ӽ�HCC�֫O�ҫ�   �j���I�̦���O�� */
    strcpy(sDfirst_ply2," ");     /* 1090803002-SC1-�ӽ�HCC�֫O�ҫ�   ���N�I�̦���O�� */
    qacc_sum_5y = 0;              /* �e���~�߮ץ��(1120220002_SC1)*/
    strcpy(fhave_newa_c_2y,"0");  /* �L�h2�~�O�_�b�s�w��O�L�T���I(1120220002_SC1)*/
    
    strcpy(sDinstall," ");     /* 1120927002_C01_�R�q�ΰӫ~�}�o */
    strcpy(sIsequence," ");    /* 1120927002_C01_�R�q�ΰӫ~�}�o */
    strcpy(sAinstall_zip," "); /* 1120927002_C01_�R�q�ΰӫ~�}�o */
    strcpy(sAinstall," ");     /* 1120927002_C01_�R�q�ΰӫ~�}�o */

    
    printf("***** finish init *****\n");
}
