/*--------------------------------------------------*/
/*   PROGRAM : ca109m01s.ec                         */
/*   MODIFIER: Alex 04/10/2002                      */
/*   DATE    : 1993/09/02                           */
/*--------------------------------------------------*/
     
#include <stdio.h>
#include <stdlib.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include <decimal.h>
$include sqltypes;
#include "safeclib.h"

typedef struct
{
    char   type;
    long   oldmcoverage1;
    long   oldmcoverage2;
    long   oldmdeduct;
    long   mcoverage1;
    long   mcoverage2;
    long   mdeduct;
    double mpremium;
    double pextra_charge;
    long   msi_coverage;
    double   msi_premium;
    char   olddrate[12];
    char   drate[12];
} car109_t;

/*--------------------------------------------------*/
long car109(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    long rtncode;
    long car109_insert(),car109_single_query(),car109_multiple_query(),car109_update_exec();
    char option;

    cm_buf_init(command);
    cm_buf_get("%c",&option);

    switch(option)
    {
        case 'A':
                rtncode=car109_insert(reply);
            break;
        case 'Q':
            rtncode=car109_single_query(reply);
            break;
        case 'M':
            rtncode=car109_multiple_query(reply);
            break;
        case 'D':
        case 'U':
            rtncode=car109_update_exec(reply,command,com_len);
            break;
        default :
            if(exitsub(reply,M_CM_WRONG_OPTION) == True)
                return M_CM_WRONG_OPTION;
        return apiRC;
    }
    return(rtncode);
}

/*--------------------------------------------------*/
long car109_insert(reply)  /* �s�W */
serverReply reply;
{
    $char    DBName[5];
    $char    icar_type[3],iins_type[7],isame_ins[7],drate[10],drate_e[12];
    $long    mcoverage1,mcoverage2;
    $long    mdeduct;
    $char    cDeduct[10];
    $long    msi_coverage;
    $double  msi_premium;
    $char    tmp_isame_ins[7];
    $double  mpremium,pextra_charge;
    dec_t    dec_mpremium,dec_pextra_charge;
    char     tmp_mpremium[12],tmp_pextra_charge[9];
    int      tmp_len;
    long     MsgCode;

    DBinfo   *list;
    int      k, j, is_add_fail=0, api_f;
    $char    stmt_buf[300];

    int      rows, i;
    car109_t *alist;

    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s %s %l",icar_type,iins_type,isame_ins, &rows);

    strcpy(icar_type,trim(icar_type));
    strcpy(iins_type,trim(iins_type));
    strcpy(isame_ins,trim(isame_ins));

    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
                return M_CM_DB_NOTOPEN;
        else
                return apiRC;
    }

    $SELECT isame_ins
       INTO $tmp_isame_ins
       FROM insurance_type
      WHERE iins_type=$iins_type;
    if(SQLCODE==SQLNOTFOUND)
    {
        if(exitsub(reply,M_CA_NINS_TYPE) == True)
                return M_CA_NINS_TYPE;
        else
                return apiRC;
    }

    trim_tail_white(isame_ins);
    trim_tail_white(tmp_isame_ins);

    if(strcmp(isame_ins,tmp_isame_ins)!=0)
    {
        if(exitsub(reply,M_CA_SAME_INS) == True)
                return M_CA_SAME_INS;
        else
                return apiRC;
    }

    alist = (car109_t *) malloc (rows * sizeof (car109_t));

    for (k=0;k<rows;k++)
    {
        cm_buf_get("%l %l %l   %s %s   %l %e   %s",
                    &mcoverage1,&mcoverage2,&mdeduct,
                    tmp_mpremium,tmp_pextra_charge,
                    &msi_coverage,&msi_premium,
                    drate);
        deccvasc(tmp_mpremium, strlen(tmp_mpremium), &dec_mpremium);
        dectodbl(&dec_mpremium, &mpremium);
        deccvasc(tmp_pextra_charge, strlen(tmp_pextra_charge), &dec_pextra_charge);
        dectodbl(&dec_pextra_charge, &pextra_charge);
        alist[k].mcoverage1    = mcoverage1;
        alist[k].mcoverage2    = mcoverage2;
        alist[k].mdeduct       = mdeduct;
        alist[k].mpremium      = mpremium;
        alist[k].pextra_charge = pextra_charge;
        alist[k].msi_coverage  = msi_coverage;
        alist[k].msi_premium   = msi_premium;
        strcpy(alist[k].drate,cm_to_infdate(drate));
        strcpy(cDeduct, ltoa(mdeduct));

        if (strcmp(trim(iins_type),"29")==0)
        {
             /* �I�ج�29�ɡA���ˮֶW�B�O�I����h�O�B�N���O�_�v��ca_dmg_mdeduct���إ߸�� */
             $SELECT *
                FROM ca_dmg_mdeduct
               WHERE icar_type = "I29"
                 AND ideduct   = :cDeduct;
             if(SQLCODE==SQLNOTFOUND)
             {
                  /* �W�B�d���I�L��������h�O�B���,�Ц�car126�إ߬������ */
                  if(exitsub(reply,M_CA_29_NODEDUCT) == True)
                       return M_CA_29_NODEDUCT;
                  else
                       return apiRC;
             }
        }
    }

    if((list=get_sysdb_list(&i,DBName)) == (char*)0)
    {
        if(exitsub(reply,M_CM_NOT_DBLIST) == True)
                return M_CM_NOT_DBLIST;
        return apiRC;
    }

    $WHENEVER SQLERROR CONTINUE;
    $BEGIN WORK;

    for(j=0;j<i;j++)
    {
        sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:cover_vs_premium "
                          " (icar_type,iins_type,isame_ins,mcoverage1,mcoverage2,mdeduct, "
                          " mpremium,pextra_charge,msi_coverage,msi_premium,drate) "
                          " VALUES (?,?,?,?,?,?,?,?,?,?,?)",
                          list[j].dbname);
        for(k=0;k<rows;k++)
        {
            $PREPARE b_id FROM $stmt_buf;
            if(SQLCODE != 0)
            {
                is_add_fail = 3;
                break;
            }
            mcoverage1    = alist[k].mcoverage1;
            mcoverage2    = alist[k].mcoverage2;
            mdeduct       = alist[k].mdeduct;
            mpremium      = alist[k].mpremium;
            pextra_charge = alist[k].pextra_charge;
            msi_coverage  = alist[k].msi_coverage;
            msi_premium   = alist[k].msi_premium;
            strcpy(drate_e,alist[k].drate);
            if( risnull(SQLCHAR, isame_ins) == 1) strcpy( isame_ins, " ");

            $EXECUTE b_id USING $icar_type,$iins_type,$isame_ins,
                                $mcoverage1,$mcoverage2,$mdeduct,
                                $mpremium,$pextra_charge,
                                $msi_coverage,$msi_premium,
                                $drate_e;
            if(SQLCODE != 0)
            {
                is_add_fail = 3;
                break;
            }
        }

        if (is_add_fail == 3)
        {
            is_add_fail = 1;
            break;
        }

        cm_buf_init(ReplyBuf);
        cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);

        tmp_len = cm_buf_len(ReplyBuf);

        if(j == i-1)
            api_f = api_OKComplete;
        else
            api_f = api_OK;

        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
        {
            is_add_fail = 2;
            break;
        }
    } /* for loop */

    free ((char *) alist);

    if(is_add_fail == 1)
        goto errexit;

    if(is_add_fail == 2)
    {
        $ROLLBACK WORK;
        return apiRC;
    }

    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;

    return api_OKComplete;

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;

    if(SQLCODE != 0)
        MsgCode = SQLCODE;

    if(exitsub(reply,MsgCode) == True)
        return MsgCode;
    else
        return apiRC;
}

/*--------------------------------------------------*/
long car109_single_query(reply)
serverReply reply;
{
    /* standard defined host variables */
    $char DBName[5];
    /* end of standard host var */

    /* table  */
    $char   icar_type[3],iins_type[7],isame_ins[7],drate[11],drate_c[11],drate_e[12];
    $char   fclass[2],ncode[11],tmpinsname[29],tmpconame[29];
    $long   drate_l = 0;
    $long   mcoverage1 = 0,mcoverage2 = 0,mdeduct = 0;
    $char   str_mcoverage1[21],str_mcoverage2[21],str_mdeduct[21];
    $long   msi_coverage = 0;
    $double msi_premium = 0.0;
    $double mpremium = 0.0,pextra_charge = 0.0;
    /* end of  */

    /* standard defined data */
    char tmpbuf[4000];
    int  count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int  i,total_count=0;
    /* end of standard data */

    /* self defined data */
    dec_t dec_mpremium,dec_pextra_charge;
    char  tmp_mpremium[12],tmp_pextra_charge[9];
    char  strtmp0[50],strtmp1[50];
    /* end of self data */

    cm_buf_get("%s",DBName);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
                return M_CM_DB_NOTOPEN;
        else
                return apiRC;
    }

    cm_buf_get("%s %s %s %s",icar_type,iins_type,drate_c, str_mcoverage1);
    printf("str_mcoverage1[%s], str_mcoverage2[%s], str_mdeduct[%s]\n", 
            str_mcoverage1,str_mcoverage2,str_mdeduct);
    strcpy(drate_e,cm_to_infdate(drate_c));
    strcpy(fclass,"1");

    strcpy( ncode,"");

    $SELECT nins_abbr,isame_ins
       INTO $tmpinsname,$isame_ins
       FROM insurance_type
      WHERE iins_type=$iins_type;
    if(SQLCODE==SQLNOTFOUND)
    {
        if(exitsub(reply,M_CA_NINS_TYPE) == True)
                return M_CA_NINS_TYPE;
        else
                return apiRC;
    }

    strcpy(tmpconame," ");

    if (isame_ins[0] != ' ' && isame_ins[0] !='\0')
    {
        $SELECT nins_abbr
           INTO $tmpconame
           FROM insurance_type
          WHERE iins_type=$isame_ins;
        if(SQLCODE==SQLNOTFOUND)
        {
           if(exitsub(reply,M_CA_NINS_TYPE) == True)
                return M_CA_NINS_TYPE;
           else
                return apiRC;
        }
    }

    if (isame_ins[0] == ' ' || isame_ins[0]=='\0')
    {
        $DECLARE q_cur CURSOR FOR
          SELECT mcoverage1,mcoverage2,mdeduct,mpremium,pextra_charge,
                 msi_coverage,msi_premium,drate
            INTO $mcoverage1,$mcoverage2,$mdeduct,$mpremium,$pextra_charge,
                 $msi_coverage,$msi_premium,$drate_l
            FROM cover_vs_premium
           WHERE icar_type = $icar_type
             AND iins_type = $iins_type
             AND drate = $drate_e
             AND mcoverage1 = $str_mcoverage1
             AND (isame_ins[1]=' ' or isame_ins IS NULL);
        $OPEN q_cur;
    }
    else
    {
        $DECLARE q_curX CURSOR FOR
          SELECT mcoverage1,mcoverage2,mdeduct,mpremium,pextra_charge,
                 msi_coverage,msi_premium,drate
            INTO $mcoverage1,$mcoverage2,$mdeduct,$mpremium,$pextra_charge,
                 $msi_coverage,$msi_premium,$drate_l
            FROM cover_vs_premium
           WHERE icar_type = $icar_type
             AND iins_type = $iins_type
             AND drate = $drate_e
             AND mcoverage1 = $str_mcoverage1;
        $OPEN q_curX;
    }
    /*strcpy(drate_c,cm_from_infdate(drate_c));*/
    cm_buf_init(ReplyBuf);
    cm_buf_res_msg();             /* reserve for MsgCode and count */
    cm_buf_res_count();
    cm_buf_put("%s %s %s %s %s %s %s",
               icar_type,ncode,iins_type,drate_c,tmpinsname,isame_ins,tmpconame);

    for(;;)
    {
        if (isame_ins[0] == ' ' || isame_ins[0]=='\0')
                $FETCH q_cur;
        else
                $FETCH q_curX;

        if (SQLCODE != 0) break;

        strcpy(drate, cm_cdate_str_100(drate_l));

        sprintf_s(strtmp0, sizeof strtmp0,"%.3f",mpremium);
        sprintf_s(strtmp1, sizeof strtmp1,"%.4f",pextra_charge);

        cm_buf_put("%l %l %l   %s %s   %l %e %s",
                   (mcoverage1),(mcoverage2),(mdeduct),
                   strtmp0,strtmp1,
                   msi_coverage,msi_premium,drate);
        count++;

    } /* for loop */

    if (isame_ins[0] == ' ' || isame_ins[0] == '\0')
        $CLOSE q_cur;
    else
        $CLOSE q_curX;

    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        tmp_len = cm_buf_len(ReplyBuf);
        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                return apiRC;
        return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
        if(exitsub(reply,M_CA_NCOVER_PREM) == True)
                return M_CA_NCOVER_PREM;
        else
                return apiRC;
    }

errexit:
    if(exitsub(reply,SQLCODE) == True)
        return SQLCODE;
    else
        return apiRC;
}

/****************************************************************************/
long car109_multiple_query(reply)
serverReply reply;
{
    /* standard defined host variables */
    $char   DBName[5], stmt[1024], sWhere[256], sTmp[51];
    /* end of standard host var */

    /* table  */
    $char   icar_type[3],iins_type[7],isame_ins[7],drate_c[11],str_drate_bgn[11],str_drate_end[11];
    $long   mcoverage1 = 0,mcoverage2,mdeduct,msi_coverage;
    $double msi_premium, mpremium;
    $char   fclass[2],ncode[11],drate[11];
    $char   nins_type[29], str_mcoverage1[21], str_mcoverage2[21], str_mdeduct[21];
    /* end of  */

    /* standard defined data */
    char tmpbuf[4000];
    int  count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int  i,total_count=0;
    /* end of standard data */

    /* self defined data */
    $char oldicar_type[3],oldiins_type[7],oldisame_ins[7];
    $char tmpisame_ins[10];
    $char tmpinsname[29], tmpconame[29];
    /* end of self data */

    strcpy(fclass,"1");
    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s %s %s %s %s",icar_type,iins_type,drate_c, str_mcoverage1, str_mcoverage2, str_mdeduct);
     
    $WHENEVER SQLERROR GOTO errexit;
     
    if(drate_c[0] == '*')
    {
        strcpy(str_drate_bgn,"01/01/1980");
        strcpy(str_drate_end,"12/31/2999");
    }
    else
    { 
        strcpy(str_drate_bgn,cm_to_infdate(drate_c));
        strcpy(str_drate_end,cm_to_infdate(drate_c));
    }
    if(str_mcoverage1[0] != '*')
    {
        sprintf_s(sTmp, sizeof sTmp, " AND mcoverage1 = %s", str_mcoverage1 );
        strcat( sWhere, sTmp);
    }
    if(str_mcoverage2[0] != '*')
    {
        sprintf_s(sTmp, sizeof sTmp, " AND mcoverage2 = %s", str_mcoverage2 );
        strcat( sWhere, sTmp);
    }
    if(str_mdeduct[0] != '*')
    {
        sprintf_s(sTmp, sizeof sTmp, " AND mdeduct = %s", str_mdeduct );
        strcat( sWhere, sTmp);
    }

    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }

    sprintf_s(stmt, sizeof stmt, "SELECT DISTINCT icar_type,iins_type,isame_ins,drate, mcoverage1 "
                    "  FROM cover_vs_premium"
                    " WHERE icar_type matches '%s'"
                    "  AND iins_type matches  '%s'"
                    "  AND (drate >= '%s' AND drate <= '%s' )"
                    " %s "
                    " ORDER BY icar_type,drate,mcoverage1 ", 
                    icar_type, iins_type, str_drate_bgn, str_drate_end, sWhere);

    printf("stmt[%s]\n", stmt);
    $PREPARE prep1 FROM $stmt; 
    $DECLARE q_cur2 CURSOR FOR prep1;
    $OPEN q_cur2;
    for(;;)
    {
        strcpy(tmpconame," ");
        puts("before fetch");
        $FETCH q_cur2 INTO $icar_type,$iins_type,$isame_ins,$drate, $mcoverage1;
        puts("after fetch");

        if (SQLCODE != 0) break;

        cm_buf_init(tmpbuf);

        if (count == 0)
        {
            cm_buf_res_msg();             /* reserve for MsgCode and count */
            cm_buf_res_count();
        }

        strcpy( ncode,"");
        /*
        $SELECT ncode
           INTO $ncode
           FROM car_type
          WHERE icode=$icar_type
            AND fclass=$fclass;
        if(SQLCODE==SQLNOTFOUND)
        {       
           if(exitsub(reply,M_CA_NCARTYPE) == True)
                return M_CA_NCARTYPE;
           else
                return apiRC;
        }
        */

        $SELECT nins_abbr
           INTO $tmpinsname
           FROM insurance_type
          WHERE iins_type=$iins_type;
        if(SQLCODE==SQLNOTFOUND)
        {
           if(exitsub(reply,M_CA_NINS_TYPE) == True)
                return M_CA_NINS_TYPE;
           else
                return apiRC;
        }

        if (isame_ins[0] != ' ' && isame_ins[0] != '\0')
        {
            $SELECT nins_abbr
               INTO $tmpconame
               FROM insurance_type
              WHERE iins_type=$isame_ins;
            if(SQLCODE==SQLNOTFOUND)
            {
                if(exitsub(reply,M_CA_NINS_TYPE) == True)
                        return M_CA_NINS_TYPE;
                else
                        return apiRC;
            }
        }
        strcpy(drate_c,cm_from_infdate_100(drate));
        puts("before put");
        cm_buf_put("%s %s %s %s %s %s %s %l",
                    icar_type,ncode,iins_type,tmpinsname,isame_ins,tmpconame,drate_c,mcoverage1);
        puts("after put");
        tmp_len = cm_buf_len(tmpbuf);
        if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K, ���i�A��j�A�|�����D */
        {
            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else                               /* more than 4K, send to client side */
        {
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);
            if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {
                $CLOSE q_cur2;
                return apiRC;
            }
            else               /* clear ReplyBuf and count to start all over again */
            {
                replycnt++;
                if (replycnt == 10)   /* ���i�A��j�A�|�����D */
                {
                        cm_buf_init(ReplyBuf);
                        cm_buf_put("%l",M_CM_OUT_SPACE);
                        tmp_len = cm_buf_len(ReplyBuf);
                        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                                return apiRC;
                        return M_CM_OUT_SPACE;
                }
                strcpy(drate_c,cm_from_infdate_100(drate));
                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();           /* reserve for MsgCode and count */
                cm_buf_res_count();
                cm_buf_put("%s %s %s %s %s %s %s %l",
                            icar_type,ncode,iins_type,tmpinsname,isame_ins,tmpconame,drate_c,mcoverage1);
                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
            }
                }
    }/* for loop */

    $FREE prep1;
    $CLOSE q_cur2;
    $FREE q_cur2;

    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
                return apiRC;
        return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
        if(exitsub(reply,M_CA_NCOVER_PREM) == True)
                return M_CA_NCOVER_PREM;
        else
                return apiRC;
    }

errexit:
    if(exitsub(reply,SQLCODE) == True)
        return SQLCODE;
    else
        return apiRC;
}

/*--------------------------------------------------*/
long car109_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    /* standard defined host variables */
    $char DBName[5];
    /* end of standard host var */

    /* table  */
    $char   icar_type[3],iins_type[7],isame_ins[7],drate[10],olddrate[10];
    $char   drate_e[12],olddrate_e[12];
    $long   mcoverage1,mcoverage2,mdeduct,msi_coverage, drate_l = 0;
    $double msi_premium;
    $char   cDeduct[10];
    $char   oldicar_type[3],oldiins_type[7],oldisame_ins[7], oldtmpinsname[29];
    $char   fclass[2],ncode[11],tmpinsname[29],drate_a[11],tmpconame[29], oldtmpconame[29];
    $double mpremium,pextra_charge;

    $char   oldinsname[29],oldconame[29];
    $long   oldmcoverage1,oldmcoverage2,oldmdeduct,oldmpremium,oldmsi_coverage;
    $double oldmsi_premium;
    $double cur_mpremium = 0.0,cur_pextra_charge = 0.0;
    /* end of  */

    /* standard defined data */
    char option,*pos,*raw_ptr,cur_buf[180000],*comm;
    long  tmp_len,raw_len;
    long dummy=0,dum_cnt=0;
    long dummy_tmp=0;
    long MsgCode;
    int  count=0, rows,i;
    DBinfo *list;
    int k, j, is_del_fail=0, is_upd_fail=0;
    $char stmt_buf[1024];
    /* end of standard data */

    /* self defined data */
    char rflag;
    car109_t *alist;
    dec_t dec_mpremium,dec_pextra_charge;
    char  tmp_mpremium[12],tmp_pextra_charge[9];
    char  strtmp0[50],strtmp1[50];
    /* end of self data */

    comm = (char *) command;
    cm_buf_init(command);
    cm_buf_get("%c %s",&option,DBName);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
                return M_CM_DB_NOTOPEN;
        return apiRC;
    }

    if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
    {
        if(exitsub(reply,M_CM_NOT_DBLIST) == True)
                return M_CM_NOT_DBLIST;
        return apiRC;
    }
    /* compare old record and current record, if the record has not been changed
       since last request, update or delete the record, otherwise return errmsg
       to client side */
    /* get old record info from command buffer */

    memcpy(&raw_len,&comm[com_len],sizeof(int));
    pos = &comm[com_len+sizeof(int)];
    raw_ptr = malloc(raw_len);
    if (raw_ptr != (char*)0)
        memcpy(raw_ptr,pos,raw_len);
    else
    {
        if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
                return M_CM_NOT_MALLOC;
        else
                return apiRC;
    }

    cm_buf_init(raw_ptr);          /* get index key from old record */
    cm_buf_get("%l %l",&dummy,&dum_cnt);
    cm_buf_get("%s %s %s %s %s %s %s %l %l %l",
                oldicar_type,ncode,oldiins_type,drate_a,oldtmpinsname,oldisame_ins,oldtmpconame,
                &oldmcoverage1,&oldmcoverage2,&oldmdeduct);

    strcpy(drate_e,cm_to_infdate(drate_a));
    
    $BEGIN WORK;

    strcpy(fclass,"1");

    strcpy( ncode,"");
    /*
    $SELECT ncode
       INTO $ncode
       FROM car_type
      WHERE icode  = $oldicar_type
        AND fclass = $fclass;

    if(SQLCODE==SQLNOTFOUND)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        if(exitsub(reply,M_CA_NCARTYPE) == True)
                return M_CA_NCARTYPE;
        else
                return apiRC;
    }
    */

    $WHENEVER SQLERROR GOTO errexit;

    $SELECT nins_abbr,isame_ins
       INTO $tmpinsname,$oldisame_ins
       FROM insurance_type
      WHERE iins_type=$oldiins_type;
    if(SQLCODE==SQLNOTFOUND)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        if(exitsub(reply,M_CA_NINS_TYPE) == True)
                return M_CA_NINS_TYPE;
        else
                return apiRC;
    }

    strcpy(tmpconame," ");

    $WHENEVER SQLERROR GOTO errexit;

    if (oldisame_ins[0]!=' ' && oldisame_ins[0] != '\0')
    {
        $SELECT nins_abbr
           INTO $tmpconame
           FROM insurance_type
          WHERE iins_type=$oldisame_ins;

        if(SQLCODE==SQLNOTFOUND)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            if(exitsub(reply,M_CA_NINS_TYPE) == True)
                return M_CA_NINS_TYPE;
            else
                return apiRC;
        }
    }

    $WHENEVER SQLERROR GOTO errexit;

    if (oldisame_ins[0]==' ' || oldisame_ins[0]=='\0')
    {
        $DECLARE q1_cur CURSOR FOR
          SELECT mcoverage1,mcoverage2,mdeduct,mpremium,pextra_charge,msi_coverage,msi_premium,drate
            INTO $mcoverage1,$mcoverage2,$mdeduct,$cur_mpremium,$cur_pextra_charge,$msi_coverage,$msi_premium,$drate_l
            FROM cover_vs_premium
           WHERE icar_type = $oldicar_type
             AND iins_type = $oldiins_type
             AND drate     = $drate_e
             AND mcoverage1 = $oldmcoverage1
             AND (isame_ins[1]=' ' or isame_ins IS NULL);
        $OPEN q1_cur;
    }
    else
    {
        $DECLARE q1_curX CURSOR FOR
          SELECT mcoverage1,mcoverage2,mdeduct,mpremium,pextra_charge,msi_coverage,msi_premium,drate
            INTO $mcoverage1,$mcoverage2,$mdeduct,$cur_mpremium,$cur_pextra_charge,$msi_coverage,$msi_premium,$drate_l
            FROM cover_vs_premium
           WHERE icar_type = $oldicar_type
             AND iins_type = $oldiins_type
             AND drate     = $drate_e
             AND mcoverage1 = $oldmcoverage1
             AND isame_ins = $oldisame_ins;
        $OPEN q1_curX;
    }
    strcpy(drate_a,cm_from_infdate_100(drate_e));

    /* reserve for MsgCode and count */
    cm_buf_init(cur_buf);
    cm_buf_res_msg();
    cm_buf_res_count();
    cm_buf_put("%s %s %s %s %s %s %s",
                oldicar_type,ncode,oldiins_type,drate_a,tmpinsname,oldisame_ins,tmpconame);

    for(;;)
    {
        if (oldisame_ins[0]==' ' || oldisame_ins[0]=='\0')
            $FETCH q1_cur;
        else
            $FETCH q1_curX;
        if (SQLCODE != 0) break;

        strcpy(drate,cm_cdate_str_100(drate_l));
        sprintf_s(strtmp0, sizeof strtmp0,"%.3f",cur_mpremium);
        sprintf_s(strtmp1, sizeof strtmp1,"%.4f",cur_pextra_charge);
        cm_buf_put("%l %l %l %s %s %l %e %s",
                   (mcoverage1), (mcoverage2), (mdeduct),strtmp0,strtmp1,(msi_coverage),(msi_premium),drate);

        count++;
    }

    /* if key value has been changed then SQLNOTFOUND,else put current value
       into cur_buf for comparison */

    if (count == 0)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;

        if (oldisame_ins[0]==' ' || oldisame_ins[0]=='\0')
                $CLOSE q1_cur;
        else
                $CLOSE q1_curX;

        if(exitsub(reply,M_CM_NOT_FOUND) == True)
            return M_CM_NOT_FOUND;
        else
            return apiRC;
    }

    if (oldisame_ins[0]==' ' || oldisame_ins[0]=='\0')
        $CLOSE q1_cur;
    else
        $CLOSE q1_curX;

    $WHENEVER SQLERROR GOTO errexit;


    cm_buf_init(cur_buf); 
    cm_buf_put_msg(dummy);
    cm_buf_put_count(count);

    printf("cur_buf[%s]\n",cur_buf);
    printf("raw_ptr[%s]\n",raw_ptr);

    write(1, cur_buf, raw_len);
    printf("\n");
    write(1, raw_ptr, raw_len);

    printf("cur_buf[%s]\n",cur_buf);
    printf("raw_ptr[%s]\n",raw_ptr);

    if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
		
        if(exitsub(reply,M_CM_NOT_EQUAL) == True)
            return M_CM_NOT_EQUAL;
        else
            return apiRC;
    }
    $WHENEVER SQLERROR GOTO errexit;
	
	free(raw_ptr);

    /* equal, then exec DB operation */

    if ( option == 'D' )
    {
        for(j=0;j<i;j++)
        {
            sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM %s:cover_vs_premium WHERE icar_type=? AND iins_type=? AND drate=? "
                             " AND mcoverage1 = ? ",list[j].dbname);
            $PREPARE d_id FROM $stmt_buf;
            if(SQLCODE != 0)
            {
                is_del_fail = 1;
                break;
            }
            $EXECUTE d_id USING $oldicar_type,$oldiins_type,$drate_e,$oldmcoverage1;
            if(SQLCODE != 0)
            {
                is_del_fail = 1;
                break;
            }
        }/* for loop */
        if( is_del_fail ) goto errexit;

        cm_buf_init(ReplyBuf);
        cm_buf_put("%l",M_CM_OK);
        tmp_len = cm_buf_len(ReplyBuf);
        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return apiRC;
        }

        $WHENEVER SQLERROR GOTO errexit;
        $COMMIT WORK;
        return api_OKComplete;
    }
    else if (option == 'U')
    {
        cm_buf_init(command);
        cm_buf_get("%c %s",&option,DBName);
        cm_buf_get("%s %s %s %l",icar_type,iins_type,isame_ins, &rows);

        strcpy(icar_type,trim(icar_type));
        strcpy(iins_type,trim(iins_type));
        strcpy(isame_ins,trim(isame_ins));

        alist = (car109_t *) malloc (rows * sizeof (car109_t));
        for (k=0;k<rows;k++)
        {
            cm_buf_get("%c  %l %l %l",
                        &rflag,
                        &oldmcoverage1,&oldmcoverage2,&oldmdeduct);

            cm_buf_get("%l %l %l  %s %s  %l %e  %s %s",
                        &mcoverage1,&mcoverage2,&mdeduct,
                        tmp_mpremium,tmp_pextra_charge,
                        &msi_coverage, &msi_premium,
                        olddrate,drate);

            deccvasc(tmp_mpremium, strlen(tmp_mpremium), &dec_mpremium);
            dectodbl(&dec_mpremium, &mpremium);
            deccvasc(tmp_pextra_charge, strlen(tmp_pextra_charge), &dec_pextra_charge);
            dectodbl(&dec_pextra_charge, &pextra_charge);

            alist[k].type          = rflag;
            alist[k].oldmcoverage1 = oldmcoverage1;
            alist[k].oldmcoverage2 = oldmcoverage2;
            alist[k].oldmdeduct    = oldmdeduct;

            alist[k].mcoverage1    = mcoverage1;
            alist[k].mcoverage2    = mcoverage2;
            alist[k].mdeduct       = mdeduct;

            alist[k].mpremium      = mpremium;
            alist[k].pextra_charge = pextra_charge;
            alist[k].msi_coverage  = msi_coverage;
            alist[k].msi_premium   = msi_premium;
            strcpy(alist[k].olddrate,cm_to_infdate(olddrate));
            strcpy(alist[k].drate,cm_to_infdate(drate));

            strcpy(cDeduct, ltoa(mdeduct));

            if (strcmp(trim(iins_type),"29")==0)
            {
                 /* �I�ج�29�ɡA���ˮֶW�B�O�I����h�O�B�N���O�_�v��ca_dmg_mdeduct���إ߸�� */
                 $SELECT *
                    FROM ca_dmg_mdeduct
                   WHERE icar_type = "I29"
                     AND ideduct   = :cDeduct;
                 if(SQLCODE==SQLNOTFOUND)
                 {
                      /* �W�B�d���I�L��������h�O�B���,�Ц�car126�إ߬������ */
                      if(exitsub(reply,M_CA_29_NODEDUCT) == True)
                           return M_CA_29_NODEDUCT;
                      else
                           return apiRC;
                 }
            }
        }

        $WHENEVER SQLERROR CONTINUE;

        for(j=0;j<i;j++)
        {
            for (k = 0; k < rows && is_upd_fail != 3; k++)
            {
                oldmcoverage1 = alist[k].oldmcoverage1;
                oldmcoverage2 = alist[k].oldmcoverage2;
                oldmdeduct    = alist[k].oldmdeduct;
                mcoverage1    = alist[k].mcoverage1;
                mcoverage2    = alist[k].mcoverage2;
                mdeduct       = alist[k].mdeduct;
                mpremium      = alist[k].mpremium;
                pextra_charge = alist[k].pextra_charge;
                msi_coverage  = alist[k].msi_coverage;
                msi_premium   = alist[k].msi_premium;
                strcpy(olddrate_e,alist[k].olddrate);
                strcpy(drate_e,alist[k].drate);

                switch(alist[k].type)
                {
                    case 'A':
                        sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:cover_vs_premium "
                                          " (icar_type,iins_type,isame_ins,mcoverage1,mcoverage2,mdeduct, "
                                          " mpremium,pextra_charge,msi_coverage,msi_premium,drate) "
                                          " VALUES (?,?,?,?,?,?,?,?,?,?,?)",list[j].dbname);
                        $PREPARE u1_id FROM $stmt_buf;
                        if(SQLCODE != 0)
                        {
                            is_upd_fail = 3;
                            break;
                        }
                        if( risnull(SQLCHAR, isame_ins) == 1) strcpy( isame_ins, " ");
                        $EXECUTE u1_id USING $icar_type,$iins_type,$isame_ins,$mcoverage1,$mcoverage2,$mdeduct,
                                             $mpremium,$pextra_charge,$msi_coverage,$msi_premium,$drate_e;
                        if(SQLCODE != 0)
                             is_upd_fail = 3;
                        break;
                    case 'D':
                        sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM %s:cover_vs_premium "
                                            " WHERE icar_type=? AND iins_type=? AND mcoverage1=? AND "
                                            "   mcoverage2=? AND mdeduct=? AND drate = ?",list[j].dbname);
                        $PREPARE u2_id FROM $stmt_buf;
                        if(SQLCODE != 0)
                        {
                            is_upd_fail = 3;
                            break;
                        }
                        $EXECUTE u2_id USING $oldicar_type,$oldiins_type,
                                             $oldmcoverage1,$oldmcoverage2,$oldmdeduct,
                                             $olddrate_e;
                        if(SQLCODE != 0)
                             is_upd_fail = 3;
                        break;
                    case 'U':
                        if(olddrate_e[0]=='\0')
                             sprintf_s(stmt_buf, sizeof stmt_buf, "UPDATE %s:%s SET (%s %s)=(%s) %s %s",
                                               list[j].dbname,
                                               "cover_vs_premium",
                                               "icar_type,iins_type,isame_ins,mcoverage1,mcoverage2,mdeduct,",
                                               "mpremium,pextra_charge,msi_coverage,msi_premium,drate",
                                               "?,?,?,?,?,?,?,?,?,?,?",
                                               "WHERE icar_type=? AND iins_type=? AND",
                                               "mcoverage1=? AND mcoverage2=? AND mdeduct=? AND drate IS NULL");
                        else
                             sprintf_s(stmt_buf, sizeof stmt_buf, "UPDATE %s:%s SET (%s %s)=(%s) %s %s",
                                               list[j].dbname,
                                               "cover_vs_premium",
                                               "icar_type,iins_type,isame_ins,mcoverage1,mcoverage2,mdeduct,",
                                               "mpremium,pextra_charge,msi_coverage,msi_premium,drate",
                                               "?,?,?,?,?,?,?,?,?,?,?",
                                               "WHERE icar_type=? AND iins_type=? AND",
                                               "mcoverage1=? AND mcoverage2=? AND mdeduct=? AND drate=?");

                        $PREPARE u3_id FROM $stmt_buf;
                        if(SQLCODE != 0)
                        {
                            is_upd_fail = 3;
                            break;
                        }

                        if( risnull(SQLCHAR, isame_ins) == 1) strcpy( isame_ins, " ");

                        if(olddrate_e[0]=='\0')
                                $EXECUTE u3_id USING $icar_type,$iins_type,$isame_ins,
                                                     $mcoverage1,$mcoverage2,$mdeduct,$mpremium,$pextra_charge,
                                                     $msi_coverage,$msi_premium,$drate_e,
                                                     $oldicar_type,$oldiins_type,
                                                     $oldmcoverage1,$oldmcoverage2,$oldmdeduct;
                        else
                                $EXECUTE u3_id USING $icar_type,$iins_type,$isame_ins,
                                                     $mcoverage1,$mcoverage2,$mdeduct,$mpremium,$pextra_charge,
                                                     $msi_coverage,$msi_premium,$drate_e,
                                                     $oldicar_type,$oldiins_type,
                                                     $oldmcoverage1,$oldmcoverage2,$oldmdeduct,$olddrate_e;

                        if(SQLCODE != 0)
                            is_upd_fail = 3;

                        break;

                    default:
                        $WHENEVER SQLERROR CONTINUE;
                        $ROLLBACK WORK;
                        if(exitsub(reply,M_CM_WRONG_OPTION) == True)
                           return M_CM_WRONG_OPTION;
                        else
                           return apiRC;
                }
            } /* end for (k = 0... */

            if (is_upd_fail == 3)
            {
                is_upd_fail = 1;
                break;
            }
        } /* for loop */

        free((char *) alist);
        if( is_upd_fail ==1) goto errexit;

        cm_buf_init(ReplyBuf);
        cm_buf_put("%l",M_CM_OK);
        tmp_len = cm_buf_len(ReplyBuf);
        if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
        {
            $WHENEVER SQLERROR CONTINUE;
            $ROLLBACK WORK;
            return apiRC;
        }

        $WHENEVER SQLERROR GOTO errexit;
        $COMMIT WORK;
        return api_OKComplete;
    }
    else
    {
        if(exitsub(reply,M_CM_WRONG_OPTION) == True)
           return M_CM_WRONG_OPTION;
        else
           return apiRC;
    }

errexit:
    $WHENEVER SQLERROR CONTINUE;
    MsgCode = SQLCODE;
    $ROLLBACK WORK;
    if (SQLCODE != 0) MsgCode = SQLCODE;
    if(exitsub(reply,MsgCode) == True)
        return MsgCode;
    else
        return apiRC;
}

