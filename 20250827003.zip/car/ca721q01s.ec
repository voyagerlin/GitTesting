/*******************************************/
/*                                         */
/*   �h���O�ٲĤT�H�d���I�έp��            */
/*                                         */
/*   PROGRAM : ca721q01s.ec                */
/*   Modify  : 2006/10/04 �W�[����         */
/*             �@���w�q�P�g�P���q��      */
/*******************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include <math.h>
#include "sqlfatal.h"


extern char RPTDIR[];


$char   dbgn1[11], dend1[11];
$char   dpaybgn[11], dpayend[11];

$long   lDpaybgn,lDpayend;
$long   lDpay;

$char   injure_c[11],damage_c[11];
$char   prate_c[11];
$char   rich_c[11];
$long   injure,damage;
$long   prate;
$long   rich;
$char   itype[2];


$char   igroup[6];
$long   qorder;
$char   ngroup[21];
$char   sDate_between[51];
long    rc;
$char check1[2],check2[2],check3[2],check4[2];
$char flag_3132[2];
int   first=0;
int   flag_cnt=6,flag=0;
char  array[7][2];

$long page=1;
$long Sum_qcount=0;
$double Sum = 0;
$long any_qcount=0, car_count;
$char DBName[05];
char  outputf[N_FILE+1], userid[11];

static  int fHasData=0, fFindData=0, fFirstData=1;
static  int max_cnt=0;

double dbl45();
long car721_accumulate();
long car721_detail_noncar();
/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;

   batchinit();
   strcpy(DBName,       isNULLstr(argv[1]));
   strcpy(userid,       isNULLstr(argv[2]));
   strcpy(injure_c,     isNULLstr(argv[3]));
   strcpy(damage_c,     isNULLstr(argv[4]));
   strcpy(rich_c  ,     isNULLstr(argv[5]));
   strcpy(prate_c ,     isNULLstr(argv[6]));
   strcpy(dbgn1,        isNULLstr(argv[7]));
   strcpy(dend1,        isNULLstr(argv[8]));
   strcpy(dpaybgn,      isNULLstr(argv[9]));
   strcpy(dpayend,      isNULLstr(argv[10]));
   strcpy(check1,       isNULLstr(argv[11]));  /* ���Ӳέp�� */
   strcpy(check2,       isNULLstr(argv[12]));  /* �D���Ӳέp�� */
   strcpy(check3,       isNULLstr(argv[13]));  /* ���ө��Ӫ� */
   strcpy(check4,       isNULLstr(argv[14]));  /* �D���ө��Ӫ� */
   strcpy(flag_3132,    isNULLstr(argv[15]));  /* �I�ج�31�Ϊ̬O31+32 */
   strcpy(outputf,      isNULLstr(argv[16]));

   injure = atoi(injure_c);
   damage = atoi(damage_c);
   rich   = atoi(rich_c);
   prate  = atoi(prate_c);

   if (dpaybgn[0] == '*')
   {
      strcpy(dpaybgn,"088/01/01");
   }

   if (dpayend[0] == '*')
   {
      strcpy(dpayend,"199/12/31");
   }

   lDpaybgn = cm_ymd_cdate(dpaybgn);
   printf("dpaybgn[%s]\n",dpaybgn);
   printf("lDpaybgn[%ld]\n",lDpaybgn);
   lDpayend = cm_ymd_cdate(dpayend);
   printf("dpayend[%s]\n",dpayend);
   printf("lDpayend[%ld]\n",lDpayend);

printf("check4[%s],flag_3132[%s]\n",check4,flag_3132);
 
 
    flag = 0;
    /******************************
       ���Ӳέp�����G������
       1.�s��
       2.�¨�
     ******************************/
    if (strncmp(check1,"Y",1)==0)
    {
       flag++;
       flag++;
    }
    /******************************
       �D���Ӳέp��
       1.���y���o���`�� (���� 2006.10.04)
       2.���O�έp��
     ******************************/
    if (strncmp(check2,"Y",1)==0)
    {
     /*flag++;*/
       flag++;
    }

    /******************************
      ���ө��Ӫ�
     ******************************/
    if (strncmp(check3,"Y",1)==0)
    {
       flag++;
    }

    /******************************
     �D���ө��Ӫ�
     1.���y���o����� (���� 2006.10.04)
     2.�h���O�٩��Ӫ�
     ******************************/
    if (strncmp(check4,"Y",1)==0)
    {
     /*flag++;*/
       flag++;
    }

    if (flag == 1)
    {
       strcpy(array[0]," ");
    }
    else
    {
       strcpy(array[0],"A");
       strcpy(array[1],"B");
       strcpy(array[2],"C");
       strcpy(array[3],"D");
       strcpy(array[4],"E");
       strcpy(array[5],"F");
       strcpy(array[6],"G");
    }

    sprintf(sDate_between," ��ư϶� %s ~ %s ",dbgn1,dend1);
    strcpy(dbgn1, cm_to_infdate(dbgn1));
    strcpy(dend1, cm_to_infdate(dend1));
   
    if (db_select(DBName) == False)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }

    /* ���ӻP�@���榡�אּ�@�P 2006.10.04 */
    rc = car721_accumulate();
/*********
    if ((strncmp(check1,"Y",1) == 0) || (strncmp(check3,"Y",1) == 0))
    {
        rc = car721_accumulate();
    }

    if ((strncmp(check2,"Y",1) == 0) || (strncmp(check4,"Y",1) == 0))
    {
        rc=car721_detail_noncar();
    }
***********/

}

/*----------------------------------------------------------------------------*/
long car721_accumulate()
{
 $char branch[3],fulldb[41];
 $char ipolicy[21];
 $char iquota[7];
 $char iofficer[11],imgr[2],ileader[11],icar_type[3];
 $char icar_flag[2];
 $char ibig_sales[11];
 $char sales_name[21];
 $char policy_1[21];
 $char policy_2[21];
 $char payresult[3], paystatus[32], paydate[10], notedate[10];

  int  flag31,flag32;
 $char iins_type[INSURANCE_TYPE];
 $long mpremium;
 $long mprem;
 $long minjured_cover,mdamage_cover;
  int  flag31_equal;
  int  flag32_equal;
 $long qcount_A,qcount_B;
 $long mprem_A,mprem_B;
 $char stmt[2000],stmt1[81],stmt_3132[1024];
 $char batchno[4];
 $int  ibatch_no;
 $char ipay_flag[2];

 $char igroup[6];
 $char ngroup[21];
 $char nname[11];
 $char ntop[21];
 $char itop[2];
 $char tmp_igroup[21];
 $char branch_name[21],branch_group[21];
 $char iquota14[7];
 $int  id,i;

 $long qorder;
 $int  qindent;

 $long sub_qcount_A;
 $long sub_mprem_A;
 $long sub_qcount_B;
 $long sub_mprem_B;

 $long all_qcount_A;
 $long all_mprem_A;
 $long all_qcount_B;
 $long all_mprem_B;

 $long tot_qcount_A;
 $long tot_mprem_A;
 $long tot_qcount_B;
 $long tot_mprem_B;

 $long mcover1_31;
 $long mcover3_31;
 $long mcover3_32;

 $char sfilename[41];
 $char stitle[1000];
 $char sErrmsg[200];
 $char dpolicy[11];

 $long mprem_31;
 $long mprem_32;

 $long mpremium_31;
 $long mpremium_32;

   $WHENEVER SQLERROR GOTO errexit;

   sub_qcount_A = 0;
   sub_mprem_A  = 0;
   sub_qcount_B = 0;
   sub_mprem_B  = 0;

   all_qcount_A = 0;
   all_mprem_A  = 0;
   all_qcount_B = 0;
   all_mprem_B  = 0;

   tot_qcount_A = 0;
   tot_mprem_A  = 0;
   tot_qcount_B = 0;
   tot_mprem_B  = 0;

   mcover1_31   = 0;
   mcover3_31   = 0;
   mcover3_32   = 0;

   mprem_31     = 0;
   mprem_32     = 0;

   mpremium_31  = 0;
   mpremium_32  = 0;


   $CREATE TEMP TABLE car721_quota
    (
      qorder            decimal(14) default 0 not null,
      ntop              char(20) default ' ',
      ngroup            char(20) default ' ',
      qcount_A          integer  default 0  ,    /* �M�ץ��     */
      mprem_A           integer  default 0  ,    /* �M�׫O�O     */

      qcount_B          integer  default 0  ,    /* �D�M�ץ��   */
      mprem_B           integer  default 0       /* �D�M�׫O�O   */

    )WITH NO LOG;

   $CREATE TEMP TABLE car721_officer
    (
      qorder            decimal(14) default 0 not null,
      ntop              char(20) default ' ',
      ndealer           char(20) default ' ',
      ngroup            char(20) default ' ',
      iofficer          char(20) default ' ',

      qcount_A          integer  default 0  ,    /* �M�ץ��     */
      mprem_A           integer  default 0  ,    /* �M�׫O�O     */

      qcount_B          integer  default 0  ,    /* �D�M�ץ��   */
      mprem_B           integer  default 0       /* �D�M�׫O�O   */

    )WITH NO LOG;

   $CREATE TEMP TABLE car721_dtl
    (
      iquota            char(7)  default ' ',
      iofficer          char(10) default ' ',
      icar_flag         char(2)  default ' ',
      qcount_A          integer  default 0  ,
      mprem_A           integer  default 0  ,

      qcount_B          integer  default 0  ,
      mprem_B           integer  default 0  ,
      imgr              char(1)  default ' '

    )WITH NO LOG;

    $CREATE INDEX car721_ix_1 ON car721_dtl(iquota);
    $CREATE INDEX car721_ix_2 ON car721_dtl(iofficer);

   $CREATE TEMP TABLE car721_detail
   (
      branch_group      char(20) default ' ',
      branch_name       char(20) default ' ',
      ntop              char(20) default ' ',
      ngroup            char(20) default ' ',
      nname             char(10) default ' ',
      icar_flag         char(2)  default ' ',
      nbig_sales        char(20) default ' ',
      ibig_sales        char(11) default ' ',
      ipolicy           char(20) default ' ',
      dpolicy           date,
      minjured_cover    integer  default 0,
      mdamage_cover     integer  default 0,
      mrich_cover       integer  default 0,
      mpremium          integer  default 0,
      mprem             integer  default 0,
      ipay_flag         char(1)  default 'N',
      imgr              char(1)  default ' ',
      ileader           char(10) default ' ',
      iquota            char(10) default ' ',
      iofficer          char(10) default ' ',
      icar_type         char(2)  default ' '
   )WITH NO LOG;

    sprintf(stmt,
    " INSERT INTO car721_dtl   \
        VALUES (?,?,?,?,?,?,?,?) ");
    $PREPARE ins_dtl FROM $stmt;

    sprintf(stmt,
    " INSERT INTO car721_detail \
        VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");
    $PREPARE ins_detail FROM $stmt;

    sprintf(stmt,
    " SELECT First 1 nname    \
        FROM ca_big_office    \
       WHERE fclass = '2'     \
         AND ibig_comp = ? ");
    $PREPARE get_sales FROM $stmt;

   /* ���ӫO�N & �@��� */
   if ((strncmp(check1,"Y",1) == 0 || strncmp(check3,"Y",1) == 0) &&
       (strncmp(check2,"Y",1) == 0 || strncmp(check4,"Y",1) == 0))
        strcpy(stmt1," ");
   else if (strncmp(check1,"Y",1) == 0 || strncmp(check3,"Y",1) == 0)
        strcpy(stmt1,"and imgr = '1' ");
   else if (strncmp(check2,"Y",1) == 0 || strncmp(check4,"Y",1) == 0)
        strcpy(stmt1,"and imgr = '2' "); 
        
   /* �̷�flag_3132�M�w��X31�I�ةΪ̬O31+32�I�� */
   if (strncmp(flag_3132,"I",1) == 0)
   	strcpy(stmt_3132,"AND iins_type in ('31')");
   else
   	strcpy(stmt_3132,"AND iins_type in ('31','32')");

   $DECLARE s_cur CURSOR FOR
     SELECT branch,trim(dbname)
       FROM servertbl
      WHERE branch != 'S1'
      ORDER BY 1;
     $OPEN s_cur;
     for(;;)
     {
     $FETCH s_cur
       INTO $branch,$fulldb;
         if (SQLCODE == SQLNOTFOUND) break;

         sprintf(stmt,
          " SELECT iins_type,mins_premium,mprem,minjured_cover/10000,\
                   mdamage_cover/10000       \
              FROM %s:ply_ins_type          \
             WHERE ipolicy = ?              \
               AND mdamage_cover <> 0 %s ",fulldb,stmt_3132);
          $PREPARE pins_id FROM $stmt;
          $DECLARE pins_cur CURSOR FOR pins_id;

         /* �W�[����04,19,22 2006.10.04 */
         sprintf(stmt,
          " SELECT a.ipolicy,a.iquota,a.iofficer,a.icar_flag,a.ibig_sales,\
                   a.ibatch_no,a.dpolicy,b.imgr,a.ileader,a.icar_type  \
              FROM %s:ply_relation a,officer b                \
             WHERE a.dpolicy BETWEEN '%s' AND '%s'   \
               AND a.dply_close IS NOT NULL          \
               AND a.fcard_class = '2'               \
               AND a.icar_type in ('03','04','19','22')   \
               AND a.fedr_class <> '1'               \
               AND a.iofficer = b.iofficer %s ",
               fulldb,dbgn1,dend1,stmt1);
           printf("stmt[%s]\n",stmt);
          $PREPARE ply_id FROM $stmt;
          $DECLARE ply_cur CURSOR FOR ply_id;
          $OPEN ply_cur;
          for(;;)
          {
          $FETCH ply_cur
            INTO $ipolicy,$iquota,$iofficer,$icar_flag,$ibig_sales,
                 $ibatch_no,$dpolicy,$imgr,$ileader,$icar_type;
              if (SQLCODE == SQLNOTFOUND) break;

              flag31 = 0;
              flag32 = 0;
              flag31_equal = 0;
              flag32_equal = 0;
              mcover1_31   = 0;
              mcover3_31   = 0;
              mcover3_32   = 0;

              mprem_31     = 0;
              mprem_32     = 0;
              mpremium_31  = 0;
              mpremium_32  = 0;

              $OPEN  pins_cur USING $ipolicy;
              for(;;)
              {
              $FETCH pins_cur
                INTO $iins_type,$mpremium,$mprem,$minjured_cover,$mdamage_cover;
                  if (SQLCODE == SQLNOTFOUND) break;

              printf("ipolicy[%s]iins_type[%s][%d][%d][%d][%d]\n",ipolicy,
                      iins_type,mpremium,mprem,minjured_cover,mdamage_cover);
       
                  if (strcmp(trim(iins_type),"31") == 0)
                  {
                      flag31 = 1;
                      mcover1_31 = minjured_cover;
                      mcover3_31 = mdamage_cover;
                      mpremium_31 = mpremium;
                      mprem_31    = mprem;
                      if ((minjured_cover >= injure) && (mdamage_cover >= damage))
                      {
                         if (minjured_cover != 0)
                         {
                             if (((double)mdamage_cover/(double)minjured_cover) >= (double)prate)
                             { 
                                flag31_equal = 1;
                             }
                         }
                      } 
                  }
       
                  if (strcmp(trim(iins_type),"32") == 0)
                  {
                      flag32 = 1;
                      mcover3_32 = mdamage_cover;
                      mpremium_32 = mpremium;
                      mprem_32    = mprem;
                      if (mdamage_cover >= rich)
                      {
                          flag32_equal = 1;
                      }
                  }
              }
              $CLOSE   pins_cur;
              mpremium = mpremium_31 + mpremium_32;
              mprem    = mprem_31    + mprem_32;
              
              if ((flag31 == 1) || (flag32 == 1))
              {
                 if ((flag31_equal == 1) && (flag32_equal == 1 || strncmp(flag_3132,"I",1) == 0))
                 {
                    qcount_A = 1;
                    mprem_A  = mpremium;
                    qcount_B = 0;
                    mprem_B  = 0;
                     if(strncmp(check3,"Y",1)==0 || strncmp(check4,"Y",1)==0)
                    {
                       if (ibig_sales[0]!=' ') {
                           $EXECUTE get_sales
                               INTO $sales_name
                              USING $ibig_sales;
                           if (SQLCODE == SQLNOTFOUND)
                               strcpy(sales_name," ");
                       }
                       else strcpy(sales_name," ");

                       strcpy(batchno,itoa(ibatch_no));

                       policy_1[0]='\0';
                       policy_2[0]='\0';

                       strncpy(policy_1, ipolicy, CAR_POLICY_LEN);
                       policy_1[CAR_POLICY_LEN]=0;

                       if (strlen(trim(ipolicy))>CAR_POLICY_LEN)
                           strcpy(policy_2,&ipolicy[CAR_POLICY_LEN]);
                       else
                           strcpy(policy_2," ");

                       strcpy(ipay_flag," ");
                       /*******
                        ao_chk_charge(branch, '3', policy_1, policy_2, batchno,
                                      payresult, paystatus, paydate, notedate);

                        if (payresult[0] == 'R')
                        {
                            strcpy(ipay_flag,"Y");
                        }
                        else
                        {
                            strcpy(ipay_flag,"N");
                        }
                       ********/
                        $SELECT ncode, nlevel4, nlevel3
                           INTO $nname,$ngroup,$ntop
                           FROM v_channel 
                          WHERE icode = $iofficer
                            AND level1 = '1';
                             if (SQLCODE == SQLNOTFOUND)
                             {
                                 strcpy(nname," ");
                                 strcpy(ngroup," ");
                                 strcpy(ntop," ");
                             }
                         strcpy(iquota14,substring(iquota,1,4));
                         strcat(iquota14,"00");

                         $SELECT nlevel4,nlevel2
                            INTO $branch_name,$branch_group
                            FROM sysdb:v_quota
                           WHERE icode = $iquota;
                              if (SQLCODE == SQLNOTFOUND)
                              {
                                 strcpy(branch_name," ");
                                 strcpy(branch_group," ");
                              }
                        $EXECUTE ins_detail
                           USING $branch_group,$branch_name,$ntop,$ngroup,
                                 $nname,$icar_flag,$sales_name,$ibig_sales,
                                 $ipolicy,$dpolicy,$mcover1_31,$mcover3_31,
                                 $mcover3_32,$mpremium,$mprem,$ipay_flag,
                                 $imgr,$ileader,$iquota,$iofficer,$icar_type;
                    }
                 }
                 else
                 {
                    qcount_A = 0;
                    mprem_A  = 0;
                    qcount_B = 1;
                    mprem_B  = mpremium;
                 }
                 if (strncmp(check1,"Y",1)==0 || strncmp(check2,"Y",1)==0)
                 {
                 $EXECUTE ins_dtl
                    USING $iquota,$iofficer,$icar_flag,$qcount_A,$mprem_A,
                          $qcount_B,$mprem_B,$imgr;
                 }
              }
          }
          $CLOSE ply_cur;
          $FREE  ply_cur;
     }
     $CLOSE s_cur;
     $FREE  s_cur;

     /* ���Ӳέp�� */
     printf("check1\n");
     if (strncmp(check1,"Y",1)==0)
     {
       for(i=1 ; i<=2 ; i++)
       {
          $INSERT INTO car721_officer
           SELECT a.qorder,a.nlevel3,a.nlevel4,a.ncode,c.iofficer,
                  SUM(qcount_A),SUM(mprem_A),
                  SUM(qcount_B),SUM(mprem_B)
             FROM car721_dtl c,v_channel a
            WHERE a.icode    = c.iofficer
              AND c.icar_flag = $i
              AND c.imgr = '1'
            GROUP BY 1,2,3,4,5;

          printf("i[%d]\n",i);
          if (i == 1)    /* �s��  */
          {
              strcpy(sfilename,"���Ӧh���O�ٲέp��-�s��");
              strcpy(stitle,"�ƧǥN��\t���ӦW��\t�ϩҦW��\t���I�W��\t���I�N��\t�M�ץ��\t�M�׫O�O\t�M�ץ����O�O\t");
              strcat(stitle,"���ŦX�h���O�٥��\t���ŦX�h���O�٫O�O\t���ŦX�h���O�٥����O�O\t");
              strcat(stitle,"�X�p���\t�X�p�O�O\t�X�p�����O�O\t\n");
              strcat(stitle,sDate_between);
              strcat(stitle,"  (�s��) ");
              strcat(stitle,"\n");

             strcpy(stmt,"select qorder,ntop,ndealer,ngroup,iofficer,qcount_A,mprem_A,' ' saver1,  \
                                 qcount_B,mprem_B,' ' saver2,                                      \
                                 qcount_A+qcount_B, mprem_A+mprem_B,' ' saver3                     \
                            from car721_officer order by qorder ");

             rc = unload_file(outputf,array[first++],sfilename,stitle,stmt);
             if (rc != SUCCESS)
             {
                 sprintf(sErrmsg," %s �ɮ׵L�k���͡A���~�N��[%ld] ",sfilename,rc);
                 EWRITE(userid, rc , sErrmsg);
                 exit(1);
             }
          }
          else           /* �¨�  */
          {
              strcpy(sfilename,"���Ӧh���O�ٲέp��-�¨�");
              strcpy(stitle,"�ƧǥN��\t���ӦW��\t�ϩҦW��\t���I�W��\t���I�N��\t�M�ץ��\t�M�׫O�O\t�M�ץ����O�O\t");
              strcat(stitle,"���ŦX�h���O�٥��\t���ŦX�h���O�٫O�O\t���ŦX�h���O�٥����O�O\t");
              strcat(stitle,"�X�p���\t�X�p�O�O\t�X�p�����O�O\t\n");
              strcat(stitle,sDate_between);
              strcat(stitle,"  (�¨�) ");
              strcat(stitle,"\n");

             strcpy(stmt,"select qorder,ntop,ndealer,ngroup,iofficer,qcount_A,mprem_A,' ' saver1,  \
                                 qcount_B,mprem_B,' ' saver2,                                      \
                                 qcount_A+qcount_B, mprem_A+mprem_B,' ' saver3                     \
                            from car721_officer order by qorder ");

             rc = unload_file(outputf,array[first++],sfilename,stitle,stmt);
             if (rc != SUCCESS)
             {
                 sprintf(sErrmsg," %s �ɮ׵L�k���͡A���~�N��[%ld] ",sfilename,rc);
                 EWRITE(userid, rc , sErrmsg);
                 exit(1);
             }
          }
          $DELETE FROM car721_officer WHERE 0 = 0;
       }
     }

     /* ���ө��Ӫ� */
     printf("check3");
     if (strncmp(check3,"Y",1)==0)
     {
          strcpy(sfilename,"���Ӧh���O�٩��Ӫ�");
          strcpy(stitle,"���W��\t�g�P���q\t�ϩҦW��\t���I�W��\t�s�¨��O\t�~�N�W��\t�~�N�N��\t");
          strcat(stitle,"�O�渹�X\tñ����\t�C�@�H���(�U��)\t�C�@�ƬG(�U��)\t�C�@�]�l�ƬG(�U��)\t");
          strcat(stitle,"�O�I�O(ñ��)\t�O�I�O(�u�f�e)\t���إN��\t\n");
          strcat(stitle,sDate_between);
          strcat(stitle,"\n");
          strcpy(stmt,
                "select branch_name,ntop,ngroup,nname,icar_flag,nbig_sales,\
                        ibig_sales,ipolicy,dpolicy,minjured_cover,\
                        mdamage_cover,mrich_cover,mpremium,mprem,icar_type \
                   from car721_detail where imgr = '1' ");

         rc = unload_file(outputf,array[first++],sfilename,stitle,stmt);
         if (rc != SUCCESS)
         {
             sprintf(sErrmsg," %s �ɮ׵L�k���͡A���~�N��[%ld] ",sfilename,rc);
             EWRITE(userid, rc , sErrmsg);
             exit(1);
         }
     }

     /* �@���έp�� */
     printf("check2");
     if (strncmp(check2,"Y",1)==0)
     {
         $INSERT INTO car721_quota
          SELECT a.qorder,a.nlevel2,a.nlevel4,
                 SUM(qcount_A),SUM(mprem_A),SUM(qcount_B),SUM(mprem_B)
            FROM car721_dtl c,sysdb:v_quota a
           WHERE a.icode = c.iquota[1,4]||'00'
             AND c.imgr = '2'
           GROUP BY 1,2,3;
         strcpy(sfilename,"�@���h���O�ٲέp��-���O");
         strcpy(stitle,"�ƧǥN��\t�Ұ�\t���W��\t�h���O�٥��\t�h���O�٫O�O\t");
         strcat(stitle,"���ŦX�h���O�٥��\t���ŦX�h���O�٫O�O\t");
         strcat(stitle,"�X�p���\t�X�p�O�O\t�X�p�����O�O\t\n");
         strcat(stitle,sDate_between);
         strcat(stitle,"\n");

        strcpy(stmt,
        "select qorder,ntop,ngroup,qcount_A,mprem_A,qcount_B,mprem_B,\
                qcount_A+qcount_B,mprem_A+mprem_B,\
                decode(qcount_A+qcount_B,0,0,round(((mprem_A+mprem_B)/\
                (qcount_A+qcount_B) * 100),0))  \
           from car721_quota order by qorder ");

        rc = unload_file(outputf,array[first++],sfilename,stitle,stmt);
        if (rc != SUCCESS)
        {
            sprintf(sErrmsg," %s �ɮ׵L�k���͡A���~�N��[%ld] ",sfilename,rc);
            EWRITE(userid, rc , sErrmsg);
            exit(1);
        }
    }

    printf("check4");
    if (strncmp(check4,"Y",1) == 0)
    {
        strcpy(sfilename,"�@���h���O�٩��Ӫ�");
        strcpy(stitle,"�Ұ�\t���\t�O�渹�X\tñ����\t�ˮ`�I�O�B�@\t");
        strcat(stitle,"�ˮ`�I�O�B�G\t�]�l�O�B\t�O�I�O(ñ��)\t�O�I�O(�u�f�e)\t");
        strcat(stitle,"�g��H\t�g��H�W��\t�޲z�H\t�޲z�H�m�W\t���إN��\t\n");
        strcat(stitle,sDate_between);
        strcat(stitle,"\n");
        strcpy(stmt,
        "select branch_group,branch_name,ipolicy,dpolicy,minjured_cover,\
                mdamage_cover,mrich_cover,mpremium,mprem,\
                iofficer,nname,ileader,(select nname from officer \
                where iofficer = car721_detail.iofficer),icar_type \
           from car721_detail where imgr = '2' ");
        rc = unload_file(outputf,array[first++],sfilename,stitle,stmt);
        if (rc != SUCCESS)
        {
            sprintf(sErrmsg," %s �ɮ׵L�k���͡A���~�N��[%ld] ",sfilename,rc);
            EWRITE(userid, rc , sErrmsg);
            exit(1);
        }
    }
   return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(1);
}

long car721_detail_noncar()
{
        
 $char branch[3];
 $char ipolicy[21];
 $char iquota[7];
 $char iofficer[11];
 $char icar_flag[2];
 $char ibig_sales[11];
 $char sales_name[21];
 $char policy_1[21];
 $char policy_2[21];
 $char payresult[3], paystatus[32], paydate[10], notedate[10];

  int  flag31,flag32;
 $char iins_type[INSURANCE_TYPE];
 $long mpremium;
 $long mprem;
 $long minjured_cover,mdamage_cover;
  int  flag31_equal;
  int  flag32_equal;
 $long qcount_A,qcount_B;
 $long mprem_A,mprem_B;
 $char stmt[2000];
 $char batchno[4];
 $int  ibatch_no;
 $char ipay_flag[2];

 $char igroup[6];
 $char ngroup[21];
 $char nname[11];
 $char ntop[21];
 $char itop[2];
 $char tmp_igroup[21];
 $char branch_name[21];
 $char iquota14[7];
 $int  id,i;

 $long qorder;
 $int  qindent;

 $long sub_qcount_A;
 $long sub_mprem_A;
 $long sub_qcount_B;
 $long sub_mprem_B;

 $long all_qcount_A;
 $long all_mprem_A;
 $long all_qcount_B;
 $long all_mprem_B;

 $long tot_qcount_A;
 $long tot_mprem_A;
 $long tot_qcount_B;
 $long tot_mprem_B;

 $long mcover1_31;
 $long mcover3_31;
 $long mcover3_32;

 $char sfilename[41];
 $char stitle[1000];
 $char sErrmsg[200];
 $char dpolicy[11];

 $long mprem_31;
 $long mprem_32;

 $long mpremium_31;
 $long mpremium_32;
 

$double pdiscount;
$char sdiscount[6];
$char dply_begin[11],dply_end[11];
$char iresource[2];
$char iissue_ym[7];
$char ipro_year[5];
$char icar_type[3];
$char ileader[11];
$char nassured[41];
$char fedr_class[11];
$char dendorse[11];
$char officername[11];
$char leadername[11];
$char ncode[20];  
$char iengine[CA_ENGINE_NUM];
$char itag[CA_TAG_NUM];
$char ibrand[13];
$char nbrand[26];
$int  icnt;
$double mpay;
$char fstatus[21];
$char dpay[11];
$char stmt_tmp1[2048],stmt_tmp2[2048];

$WHENEVER SQLERROR GOTO errexit;

   icnt = 0;
   mpay = 0;
   sub_qcount_A = 0;
   sub_mprem_A  = 0;
   sub_qcount_B = 0;
   sub_mprem_B  = 0;

   all_qcount_A = 0;
   all_mprem_A  = 0;
   all_qcount_B = 0;
   all_mprem_B  = 0;

   tot_qcount_A = 0;
   tot_mprem_A  = 0;
   tot_qcount_B = 0;
   tot_mprem_B  = 0;

   mcover1_31   = 0;
   mcover3_31   = 0;
   mcover3_32   = 0;

   mprem_31     = 0;
   mprem_32     = 0;

   mpremium_31  = 0;
   mpremium_32  = 0;

   $WHENEVER SQLERROR GOTO errexit;
   /* ���O�έp���e�m���Ӫ� */
   $CREATE TEMP TABLE car721_dtl_1
    (
      iquota            char(7)  default ' ',
      qcount_A          integer  default 0  ,    /* �h���O�٥�� */
      mprem_A           integer  default 0  ,    /* �h���O�٫O�O */

      qcount_B          integer  default 0  ,    /* �ĤT�H�d���I�X�p��� */
      mprem_B           integer  default 0       /* �ĤT�H�d���I�X�p�O�O */

    )WITH NO LOG;

   /* ���O�έp�� */
   $CREATE TEMP TABLE car721_quota_1
   (
      qorder            integer  default 0 not null,
      ngroup            char(20) default ' ',
      qcount_A          integer  default 0  ,    /* �h���O�٥��     */
      mprem_A           integer  default 0  ,    /* �h���O�٫O�O     */

      qcount_B          integer  default 0  ,    /* �ĤT�H�d���I�X�p���   */
      mprem_B           integer  default 0       /* �ĤT�H�d���I�X�p�O�O   */

   )WITH NO LOG;

   /* �D���Ӽ��y���o����Ӫ� */
   sprintf(stmt_tmp1,"CREATE TEMP TABLE car721_detail_1\
   (\
      ipolicy           char(20) default ' ',\
      nassured          char(40) default ' ',\
      icar_type         char(3)  default ' ',\
      dply_begin        date,\
      dply_end          date,\
      minjured_cover    integer  default 0,\
      mdamage_cover     integer  default 0,\
      mrich_cover       integer  default 0,\
      mpremium          integer  default 0,\
      pdiscount         decimal(4,1) default 0,\
      mpay              integer  default 0,\
      dpolicy           date,\
      dpay              date,\
      paystatus         char(30),\
      ipay_flag         char(1)   default 'N',\
      fedr_class        char(20)  default ' ',\
      dendorse          date,\
      ncode             char(20) default ' ',\
      branch_name       char(20) default ' ',\
      iofficer          char(10) default ' ',\
      officername       char(15) default ' ',\
      ileader           char(10) default ' ',\
      leadername        char(15) default ' ',\
      iissue_ym         char(6)  default ' ',\
      ipro_year         char(4)  default ' ',\
      iengine           char(%d) default ' ',\
      itag              char(%d) default ' ',\
      ibrand            char(12) default ' ',\
      nbrand            char(25) default ' '\
   )WITH NO LOG;",CA_ENGINE_NUM-1,CA_TAG_NUM-1);
     $PREPARE stmp1 FROM $stmt_tmp1;
     $EXECUTE stmp1;

   /* �D���Ӧh���O�٩��Ӫ� */
   sprintf(stmt_tmp2,"CREATE TEMP TABLE car721_detail_2\
   (\
      ipolicy           char(20) default ' ',\
      nassured          char(40) default ' ',\
      icar_type         char(3) default ' ',\
      dpolicy           date,\
      dply_begin        date,\
      dply_end          date,\
      minjured_cover    integer  default 0,\
      mdamage_cover     integer  default 0,\
      mrich_cover       integer  default 0,\
      mpremium          integer  default 0,\
      pdiscount         decimal(4,1) default 0,\
      fedr_class        char(20)  default ' ',\
      dendorse          date,\
      dpay              date,\
      paystatus         char(30),\
      ipay_flag         char(1)  default 'N',\
      ncode             char(20) default ' ',\
      branch_name       char(20) default ' ',\
      iofficer          char(10) default ' ',\
      officername       char(15) default ' ',\
      ileader           char(10) default ' ',\
      leadername        char(15) default ' ',\
      iissue_ym         char(6)  default ' ',\
      ipro_year         char(4)  default ' ',\
      iengine           char(%d) default ' ',\
      itag              char(%d) default ' ',\
      ibrand            char(12) default ' ',\
      nbrand            char(25) default ' '\
   )WITH NO LOG;",CA_ENGINE_NUM-1,CA_TAG_NUM-1);
     $PREPARE stmp2 FROM $stmt_tmp2;
     $EXECUTE stmp2;

   /* ���y���o���`�� */
   $CREATE TEMP TABLE car721_pay_sum
   (
      branch_name       char(20)      default ' ',
      ileader           char(10)      default ' ',
      leadername        char(15)      default ' ',
      mpremium          integer       default 0,
      pdiscount         decimal(17,4) default 0,
      icnt              integer       default 0,
      mpay              integer       default 0
   )WITH NO LOG;

   sprintf(stmt,
   " INSERT INTO car721_detail_1  \
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");
   $PREPARE ins_detail_1 FROM $stmt;

   sprintf(stmt,
   " INSERT INTO car721_detail_2               \
       VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");
   $PREPARE ins_detail_2 FROM $stmt;

   sprintf(stmt,
   " INSERT INTO car721_pay_sum   \
       VALUES (?,?,?,?,?,?,?) ");
   $PREPARE ins_pay  FROM  $stmt;

   sprintf(stmt,
   " INSERT INTO car721_dtl_1     \
       VALUES (?,?,?,?,?)  ");
   $PREPARE ins_dtl_1 FROM $stmt;

   $DECLARE s_cur1 CURSOR FOR
     SELECT branch
       FROM servertbl
      WHERE branch != 'S1'
      ORDER BY 1;
    $OPEN s_cur1;
    for(;;)
    {
    $FETCH s_cur1
      INTO $branch;
        if (SQLCODE == SQLNOTFOUND) break;

        sprintf(stmt,
         " SELECT iins_type,mins_premium,mprem,minjured_cover/10000,mdamage_cover/10000,pdiscount  \
             FROM %s:ori_ins_type          \
            WHERE ipolicy = ?              \
              AND iins_type IN ('31','32') \
              AND mdamage_cover <> 0 ",get_full_dbname(branch));
         $PREPARE pins_id1 FROM $stmt;
         $DECLARE pins_cur1 CURSOR FOR pins_id1;

        sprintf(stmt,
         " SELECT a.ipolicy,a.iquota,a.iofficer,a.icar_flag,a.ibig_sales,    \
                  a.ibatch_no,a.dpolicy,a.dply_begin,a.dply_end,             \
                  a.iresource,to_char(a.dissue,'%%Y')::integer - 1911 || '/' || to_char(a.dissue,'%%m'), \
                  a.ipro_year,a.icar_type,a.ileader, \
                  b.nassured[1,40],a.ibrand,b.iengine,b.itag                 \
             FROM %s:ori_ply_relation a,%s:original_ply b,officer c          \
            WHERE a.dpolicy BETWEEN '%s' AND '%s'   \
              AND a.ipolicy = b.ipolicy             \
              AND a.dply_close IS NOT NULL          \
              AND a.fcard_class = '2'               \
              AND a.icar_type = '03'                \
              AND a.fedr_class <> '1'               \
              AND a.iofficer = c.iofficer           \
              AND c.imgr = '2' ",get_full_dbname(branch),get_full_dbname(branch),dbgn1,dend1);
          printf("stmt[%s]\n",stmt);
         $PREPARE ply_id1 FROM $stmt;
         $DECLARE ply_cur1 CURSOR FOR ply_id1;
         $OPEN ply_cur1;
         for(;;)
         {
         $FETCH ply_cur1
           INTO $ipolicy,$iquota,$iofficer,$icar_flag,$ibig_sales,$ibatch_no,$dpolicy,
                $dply_begin,$dply_end,$iresource,$iissue_ym,$ipro_year,$icar_type,
                $ileader,$nassured,$ibrand,$iengine,$itag;

                if (SQLCODE == SQLNOTFOUND) break;

                sprintf(stmt,"select distinct fedr_class,dendorse  \
                                from %s:edr_relation               \
                               where ipolicy = '%s'                \
                                 and dedr_close is not null        \
                               order by dendorse desc ",get_full_dbname(branch),ipolicy);

                $PREPARE edr_id1 FROM $stmt;
                $DECLARE ply_cur11 CURSOR FOR edr_id1;
                $OPEN ply_cur11;
                $FETCH ply_cur11 INTO $fedr_class,$dendorse;

                if (SQLCODE == SQLNOTFOUND)
                {
                   strcpy(fedr_class," ");
                   strcpy(dendorse," ");
                   strcpy(fstatus," ");
                }
                else
                {
                   if (fedr_class[0] == '1')
                   {
                       strcpy(fstatus,"���P");
                   }
                   else if (fedr_class[0] == '2')
                   {
                       strcpy(fstatus,"�L��");
                   }
                   else if (fedr_class[0] == '4')
                   {
                       strcpy(fstatus,"�h���h�O");
                   }
                   else if (fedr_class[0] == '5')
                   {
                       strcpy(fstatus,"�@����");
                   }
                   else if (fedr_class[0] == '8') /* car9602053 ���s�W���N�I�L�����O */
                   {
                       strcpy(fstatus,"���N�I�L��(���ʫO�O)");
                   }
                   else if (fedr_class[0] == '9')
                   {
                       strcpy(fstatus,"����");
                   }
                   else
                   {
                       strcpy(fstatus," ");
                   }
                }

                flag31 = 0;
                flag32 = 0;
                flag31_equal = 0;
                flag32_equal = 0;
                mcover1_31   = 0;
                mcover3_31   = 0;
                mcover3_32   = 0;

                mprem_31     = 0;
                mprem_32     = 0;
                mpremium_31  = 0;
                mpremium_32  = 0;

                $OPEN  pins_cur1 USING $ipolicy;
                for(;;)
                {
                $FETCH pins_cur1
                  INTO $iins_type,$mpremium,$mprem,$minjured_cover,$mdamage_cover,$pdiscount;
                    if (SQLCODE == SQLNOTFOUND) break;

                    if (strcmp(trim(iins_type),"31") == 0)
                    {
                        flag31 = 1;
                        mcover1_31 = minjured_cover;
                        mcover3_31 = mdamage_cover;
                        mpremium_31 = mpremium;
                        mprem_31    = mprem;
                        if ((minjured_cover >= injure) && (mdamage_cover >= damage))
                        {
                           if (minjured_cover != 0)
                           {
                               if (((double)mdamage_cover/(double)minjured_cover) >= (double)prate)
                               {
                                  flag31_equal = 1;
                               }
                           }
                        }
                    }
                    if (strcmp(trim(iins_type),"32") == 0)
                    {
                        flag32 = 1;
                        mcover3_32 = mdamage_cover;
                        mpremium_32 = mpremium;
                        mprem_32    = mprem;
                        if (mdamage_cover >= rich)
                        {
                            flag32_equal = 1;
                        }
                    }
                }
                $CLOSE   pins_cur1;
                mpremium = mpremium_31 + mpremium_32;
                mprem    = mprem_31    + mprem_32;
                if ((flag31 == 1) || (flag32 == 1))
                {
                   if ((flag31_equal == 1) && (flag32_equal == 1))
                   {
                      qcount_A = 1;
                      mprem_A  = mpremium;
                      qcount_B = 1;
                      mprem_B  = mpremium;

                      strcpy(batchno,itoa(ibatch_no));

                      policy_1[0]='\0';
                      policy_2[0]='\0';

                      strncpy(policy_1, ipolicy, CAR_POLICY_LEN);
                      policy_1[CAR_POLICY_LEN]=0;

                      if (strlen(trim(ipolicy))>CAR_POLICY_LEN)
                          strcpy(policy_2,&ipolicy[CAR_POLICY_LEN]);
                      else
                          strcpy(policy_2," ");

                      ao_chk_charge(branch, '1', policy_1, policy_2, batchno,
                                     payresult, paystatus, paydate, notedate);

                      if (payresult[0] == 'R')
                      {
                          strcpy(ipay_flag,"Y");
                      }
                      else
                      {
                          strcpy(ipay_flag,"N");
                      }

                      sprintf(stmt,
                      " SELECT dpay                  \
                          FROM %s:ao_plyedr_prem     \
                         WHERE ipolicy1 = '%s'       \
                           AND ipolicy2 = '%s'       \
                           AND iendorse = ' ' ",get_full_dbname(branch),policy_1,policy_2);
                      printf("stmt[%s]\n",stmt);
                      $PREPARE get_dpay FROM $stmt;
                      $EXECUTE get_dpay
                          INTO $dpay;
                            if (SQLCODE == SQLNOTFOUND)
                            {
                               strcpy(dpay," ");
                            }
                      lDpay = cm_ymd_cdate(cm_from_infdate(dpay));

                      strcpy(iquota14,substring(iquota,1,4));
                      strcat(iquota14,"00");

                      $SELECT a.ngroup
                         INTO $branch_name
                         FROM sa_frm_module a,sa_branch_type b
                        WHERE a.igroup = b.igroup
                          AND a.ifrm_module = '01'
                          AND b.ibranch = $iquota14;
                           if (SQLCODE == SQLNOTFOUND)
                           {
                              strcpy(branch_name," ");
                           }

                      $select nname
                         into $officername
                         from officer
                        where iofficer = $iofficer;

                      $select nname
                         into $leadername
                         from officer
                        where iofficer = $ileader;

                      $select ncode
                         into $ncode
                         from cu_code_data
                        where icode = $iresource
                          and itype = '10';

                      sprintf(stmt,
                        "select distinct nbrand  \
                           from ca_car_model     \
                          where ibrand = '%s' ",ibrand);

                      $PREPARE mod_id1 FROM $stmt;
                      $DECLARE ply_cur111 CURSOR FOR mod_id1;
                      $OPEN ply_cur111;
                      $FETCH ply_cur111 INTO $nbrand;

                      mpay = (1.0 - (pdiscount / 100.0));
                      mpay = 100.0 * mpay;
                      mpay = dbl45(mpay,0);

                      /* �ŦX�h�����ĤT�H�d���I�A���y�����Ӫ� */
                      if (strncmp(check4,"Y",1)==0)
                      {
                          /* �w��D���P��Τw���O */
                          if ((fedr_class[0] != '1') && (ipay_flag[0] == 'Y'))
                          {
                             printf("lDpaybgn[%ld]\n",lDpaybgn);
                             printf("lDpayend[%ld]\n",lDpayend);
                             printf("lDpay[%ld]\n",lDpay);

                             if ((lDpay >= lDpaybgn) && (lDpay <= lDpayend))
                             {
                                $EXECUTE ins_detail_1
                                   USING $ipolicy,$nassured,$icar_type,$dply_begin,$dply_end,$mcover1_31,
                                         $mcover3_31,$mcover3_32,$mpremium,$pdiscount,$mpay,$dpolicy,$dpay,$paystatus,
                                         $ipay_flag,$fstatus,$dendorse,$ncode,
                                         $branch_name,$iofficer,$officername,$ileader,$leadername ,$iissue_ym,$ipro_year,
                                         $iengine,$itag,$ibrand,$nbrand;
                             }
                          }
                              printf("bef into ins_dtl_2\n");
                             $EXECUTE ins_detail_2
                                USING $ipolicy,$nassured,$icar_type,$dpolicy,$dply_begin,$dply_end,$mcover1_31,
                                      $mcover3_31,$mcover3_32,$mpremium,$pdiscount,$fstatus,$dendorse,
                                      $dpay,$paystatus,$ipay_flag,$ncode,
                                      $branch_name,$iofficer,$officername,$ileader,$leadername,$iissue_ym,$ipro_year,$iengine,$itag,$ibrand,$nbrand;
                      }

                      /* �ŦX�h�����ĤT�H�d���I�A���y���`�� */
                      if (strncmp(check2,"Y",1)==0)
                      {
                          icnt = 1;
                          /* �w��D���P��Τw���O */
                          if ((fedr_class[0] != '1') && (ipay_flag[0] == 'Y'))
                          {
                             if ((lDpay >= lDpaybgn) && (lDpay <= lDpayend))
                             {
                             $EXECUTE ins_pay
                                USING $branch_name,$ileader,$leadername,$mpremium,$pdiscount,$icnt,$mpay;
                             }
                          }
                      }
                   }
                   else
                   {
                          qcount_A = 0;
                          mprem_A  = 0;
                          qcount_B = 1;
                          mprem_B  = mpremium;
                   }
                   /* �D���ӳ��O�`�� */
                   if (strncmp(check2,"Y",1)==0)
                   { 
                       printf("bef_ins_dtl_1 \n");
                       $EXECUTE ins_dtl_1
                          USING $iquota,$qcount_A,$mprem_A,$qcount_B,$mprem_B;
                   }
                }
         }
         $CLOSE ply_cur1;
         $FREE  ply_cur1;
    }
    $CLOSE s_cur1;
    $FREE  s_cur1;

    if (strncmp(check2,"Y",1)==0 )
    {
         printf("   2222222 check2  \n");
         strcpy(sfilename,"�D���Ӧh���O�ټ��y���o���`��");
         strcpy(stitle,"�~�Z���\t�޲z�H\t�޲z�H�m�W\t�h���O�٫O�O\t�ˮ`�I�����u�f�v\t�o����\t�o����B\t\n");
         strcat(stitle,sDate_between);
         strcpy(stmt," select branch_name,ileader,leadername,sum(mpremium),       \
                              round(sum(pdiscount)/sum(icnt),0),                  \
                              sum(icnt),sum(mpay)                                 \
                         from car721_pay_sum group by 1,2,3 order by 1,2,3");
         rc = unload_file(outputf,array[first++],sfilename,stitle,stmt);
         if (rc != SUCCESS)
         {
             sprintf(sErrmsg," %s �ɮ׵L�k���͡A���~�N��[%ld] ",sfilename,rc);
             EWRITE(userid, rc , sErrmsg);
             exit(1);
         }
        $DECLARE cur00 CURSOR FOR
          SELECT qorder, igroup, ngroup, qindent
            FROM sa_frm_module
           WHERE ifrm_module = '01'
           ORDER BY qorder;
        $OPEN cur00;
        for(;;)
        {
        $FETCH cur00 INTO $qorder, $igroup, $ngroup, $qindent;
            if (SQLCODE == SQLNOTFOUND) break;

          if (strncmp(igroup,"YYY",3)==0 )
          {
              if (qindent != 1)
              {
                $INSERT INTO car721_quota_1
                  VALUES ($qorder,$ngroup,$sub_qcount_A,$sub_mprem_A,
                          $sub_qcount_B,$sub_mprem_B);
              }
              sub_qcount_A = 0;
              sub_mprem_A  = 0;
              sub_qcount_B = 0;
              sub_mprem_B  = 0;
          }
          else if (strncmp(trim(igroup),"ZZZ",3)==0)
          {
              if (qindent != 1)
              {
                $INSERT INTO car721_quota_1
                  VALUES ($qorder,$ngroup,$all_qcount_A,$all_mprem_A,
                          $all_qcount_B,$all_mprem_B);
              }
              all_qcount_A = 0;
              all_mprem_A  = 0;
              all_qcount_B = 0;
              all_mprem_B  = 0;
          }
          else
          {
              $SELECT NVL(SUM(qcount_A),0),NVL(SUM(mprem_A),0),NVL(SUM(qcount_B),0),NVL(SUM(mprem_B),0)
                 INTO $qcount_A, $mprem_A, $qcount_B, $mprem_B
                 FROM sa_branch_type a,outer car721_dtl_1 b
                WHERE a.ibranch = b.iquota[1,4] || '00'
                  AND a.igroup = $igroup;

              $INSERT INTO car721_quota_1
                VALUES ($qorder,$ngroup,$qcount_A,$mprem_A,
                        $qcount_B,$mprem_B);

              sub_qcount_A += qcount_A;
              sub_mprem_A  += mprem_A;
              sub_qcount_B += qcount_B;
              sub_mprem_B  += mprem_B;

              all_qcount_A += qcount_A;
              all_mprem_A  += mprem_A;
              all_qcount_B += qcount_B;
              all_mprem_B  += mprem_B;

              tot_qcount_A += qcount_A;
              tot_mprem_A  += mprem_A;
              tot_qcount_B += qcount_B;
              tot_mprem_B  += mprem_B;
          }
        }
        $CLOSE cur00;
        $FREE  cur00;

        $INSERT INTO car721_quota_1
           VALUES (99999,'�����q�X�p',$tot_qcount_A,$tot_mprem_A,$tot_qcount_B,$tot_mprem_B);

         strcpy(sfilename,"�D���Ӧh���O�ٲέp��-���O");
         strcpy(stitle,"�ƧǥN��\t���W��\t�h���O�٥��\t�h���O�٫O�O\t");
         strcat(stitle,"�ĤT�H�d���I���\t�ĤT�H�d���I�O�O\t�h���O�٧�O�v\t\n");
         strcat(stitle,sDate_between);
         strcat(stitle,"\n");

        strcpy(stmt,"select qorder,ngroup,qcount_A,mprem_A,                      \
                            qcount_B,mprem_B,decode(qcount_A,0,0,round((qcount_A/qcount_B * 100),1))  \
                       from car721_quota_1  \
                      order by qorder ");

        rc = unload_file(outputf,array[first++],sfilename,stitle,stmt);
        if (rc != SUCCESS)
        {
            sprintf(sErrmsg," %s �ɮ׵L�k���͡A���~�N��[%ld] ",sfilename,rc);
            EWRITE(userid, rc , sErrmsg);
            exit(1);
        }
    }
    if (strncmp(check4,"Y",1) == 0)
    {
        printf("   1111111 check4 check4 check4check4 check4 \n");
        strcpy(sfilename,"�D���Ӧh���O�ټ��y�����Ӫ�");
        strcpy(stitle,"�O�渹�X\t�Q�O�I�H\t����\t�_�O���\t������\t�ˮ`�I�O�B�@\t");
        strcat(stitle,"�ˮ`�I�O�B�G\t�]�l�O�B\t�h���O�٫O�O\t�u�f�v\t�o����B\t");
        strcat(stitle,"ñ����\t���O���\t���O���A\t���O���O\t��窱�p\t�����\t�~�Ȩӷ�\t�~�Z���\t�g��H\t");
        strcat(stitle,"�g��H�m�W\t�޲z�H\t�޲z�H�m�W\t�o�Ӧ~��\t�s�y�~��\t");
        strcat(stitle,"�������X\t�P�Ӹ��X\t�t�P����\t�t�P�����W��\t\n");

        strcat(stitle,sDate_between);
        strcat(stitle,"\n");
        strcpy(stmt," select * from car721_detail_1 ");
        rc = unload_file(outputf,array[first++],sfilename,stitle,stmt);
        if (rc != SUCCESS)
        {
            sprintf(sErrmsg," %s �ɮ׵L�k���͡A���~�N��[%ld] ",sfilename,rc);
            EWRITE(userid, rc , sErrmsg);
            exit(1);
        }

        strcpy(sfilename,"�D���Ӧh���O�٩��Ӫ�");
        strcpy(stitle,"�O�渹�X\t�Q�O�I�H\t����\tñ����\t�_�O���\t������\t�ˮ`�I�O�B�@\t");
        strcat(stitle,"�ˮ`�I�O�B�G\t�]�l�O�B\t�h���O�٫O�O\t�u�f�v\t��窱�p\t�����\t");
        strcat(stitle,"���O���\t���O���A\t���O���O\t�~�Ȩӷ�\t�~�Z���\t�g��H\t");
        strcat(stitle,"�g��H�m�W\t�޲z�H\t�޲z�H�m�W\t�o�Ӧ~��\t�s�y�~��\t");
        strcat(stitle,"�������X\t�P�Ӹ��X\t�t�P����\t�t�P�����W��\t\n");

        strcat(stitle,sDate_between);
        strcat(stitle,"\n");
        strcpy(stmt," select * from car721_detail_2 ");
        rc = unload_file(outputf,array[first++],sfilename,stitle,stmt);
        if (rc != SUCCESS)
        {
            sprintf(sErrmsg," %s �ɮ׵L�k���͡A���~�N��[%ld] ",sfilename,rc);
            EWRITE(userid, rc , sErrmsg);
            exit(1);
        }
    }
    return SUCCESS;
  
errexit:
printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
EWRITE(userid, SQLCODE, sqlca.sqlerrm);
exit(1);
}

double dbl45(num,num1)
double num;
int num1;
{
   double tmpdbl;
   int    minus_flag;

   if (num < 0)
       minus_flag = 1;
   else
       minus_flag = 0;

   num = fabs(num);

   tmpdbl = floor(num * pow(10,num1) + 0.5) / pow(10,num1) ;

   if (minus_flag == 1) tmpdbl *= -1;

   return tmpdbl;
}

