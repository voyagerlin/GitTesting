/**********************************************************************/
/*   program id   : ca652q01s.ec                                      */
/*   program name : ��O�ɦ�ʹq�ܩ���                                */
/*   date written : 2017/06/22 by sylvia                              */
/*   files        :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "safeclib.h"


char  outputf[21];
$char userid[11], sdate1[11], sdate2[11];
$char DBName[05];
$char msgbuf[128];
char dbgn[11],dend[11];
int rc;
    
main(argc, argv)
int argc;
char **argv;
{

	batchinit();

	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(dbgn,           isNULLstr(argv[3]));
	strcpy(dend,           isNULLstr(argv[4]));
	strcpy(outputf,        isNULLstr(argv[5]));
	
	strcpy(sdate1,cm_to_infdate(dbgn));
	strcpy(sdate2,cm_to_infdate(dend));
	
	rc = car652_prepare_data();
	if (rc != M_CM_OK)
		return rc;

	rc = car652_build();
	if (rc != M_CM_OK) 
		return rc;
}

long car652_prepare_data()
{
 
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == FALSE)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return FAIL;
	}
	
	printf("--- start ���O�զX������ -- \n");
    /* ���O�զX������ */
    $select a.ipolicy, a.fcard_class, b.ipre_rcv, a.dply_begin, b.nassured, 
            b.iassured, b.mobile_phone, b.itag, 
            (case when fcard_class = '1' then comp_prem else v_ori_prem end) as mprem,
            (select sum(mprem) from cm_pre_receive where ipre_rcv = b.ipre_rcv) as sum_mprem,
            b.iofficer, b.ileader, b.iquota
       from policy_302 a, cm_pre_receive b
      where a.iestimate_ori = b.ipre_rcv
        and a.fcard_class = b.iins_kind
        and b.ipre_end = ' ' and b.iins_cat = 'C'
        and b.fsend_msg in ('1','2','3','Y')
        and a.dply_begin between $sdate1 and $sdate2
        and a.iestimate_ori <> ' ' into temp tmp_6521 with no log;

    printf("--- start ��ĳ��O�զX������ -- \n");
    /* ��ĳ��O�զX������ */
    $insert into tmp_6521
     select a.ipolicy, a.fcard_class, b.ipre_rcv, a.dply_begin, b.nassured, 
            b.iassured, b.mobile_phone, b.itag,   
            (case when fcard_class = '1' then mcomp_prem_sug+v_prem else v_prem end) as mprem,
            (select sum(mprem) from cm_pre_receive where ipre_rcv = b.ipre_rcv) as sum_mprem,
            b.iofficer, b.ileader, b.iquota
       from policy_302 a, cm_pre_receive b 
      where a.iestimate_sug = b.ipre_rcv 
        and a.fcard_class = b.iins_kind 
        and b.ipre_end = ' ' and b.iins_cat = 'C' 
        and b.fsend_msg in ('1','2','3','Y') 
        and a.dply_begin between $sdate1 and $sdate2
        and a.iestimate_sug <> ' ' ;

    $create index tmp_6521_idx on tmp_6521(ipre_rcv);
    $create index tmp_6521_idx2 on tmp_6521(iofficer);
    $create index tmp_6521_idx3 on tmp_6521(ileader);
    $create index tmp_6521_idx4 on tmp_6521(iquota);

    $update tmp_6521 set iassured[4,6] = 'XXX' where 1=1;
	
		
	return M_CM_OK;
	
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/


long car652_build()
{
    $char    sfilename[51], stitle[1000], stmt[1000];
    
	$WHENEVER SQLERROR GOTO errexit;

	strcpy(sfilename,"��O�ɦ�ʹq�ܩ���");
	sprintf_s(stitle, sizeof stitle,"�O������϶�:%s~%s\t",dbgn,dend);
	strcat(stitle,"\n");
	strcat(stitle,"\t�O�渹\t�j/���I\t�����渹\t�_�O��\t�Q�O�H�W��\t�Q�O�HID\t");
	strcat(stitle,"��ʹq��\t����\t�O�O(��j/���)\t�`�O�O(�j+��)\t�g��N��\t");
	strcat(stitle,"�g��W��\t�޲z�H�W��\t�~�Z���");
	
	  /* �`�N:�U�CSQL����''�OASCII��127�X,�b�S�w�r���~�ݱo��,�������@�Ӧr��,
       ���i�H�b��Excel�ɮɥi�H��ܧ��㪺�Ʀr, ���|�y�������D,���V��.. */

	sprintf_s(stmt, sizeof stmt,
	    "select ipolicy, fcard_class, ipre_rcv, dply_begin,  "
        "       replace(replace(nassured,'����'),'�p�j'), iassured, ''||trim(mobile_phone),  "
        "       ''||trim(itag), mprem, sum_mprem, ''||iofficer,  "
        "       (select nname from officer where iofficer = a.iofficer),  "
        "       (select nname from officer where iofficer = a.ileader  "
        "           and iofficer = ileader),  "
        "       (select nbranch from sa_branch_type where ibranch = a.iquota)  "
        "  from tmp_6521 a  order by ipre_rcv, fcard_class ");
	
	rc = unload_file(outputf," ",sfilename,stitle,stmt);
	
	if (rc != SUCCESS) 
	{
	    sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}
