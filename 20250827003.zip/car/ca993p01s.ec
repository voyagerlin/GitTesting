/**********************************************************************/
/*   program id   : ca993p01s.ec                                      */
/*   program name : ���I�O��s�P��ƳB�z�@�~                          */
/*   date written : 2022/07/07                                        */
/*   author       : 071004                                            */    
/*   �Ƶ{�ɶ�     : �C��01:00AM                                       */                                     
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <decimal.h>
#include <math.h>
#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "carmsg.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "sql.h"
$include sqlca;
#include "sqlfatal.h"
#include "car_common.h"
#include "ISvar.h"
#include "safeclib.h"

char *cm_eyear_str();
char *get_car_full_dbname();
long  get_ply_ins_dtl();
long  get_next_iendorse();
/****************************************************************************/
$char   DBName[05],userid[11];
$char   fclass[2],fkind[2],date1[10],date2[10],dbgn[11],dend[11];
int     count_db = 0, k, count_unload = 0;

char    msgbuf[2048],sApHome[30];
char    outputf[N_FILE+1];
char    cmd1[1000],cmd2[1000];
long    t;
DBinfo  *list = NULL;

$char   stmt1[3048];

FILE  *sfp;

$long   dtoday;
$char   stoday[13],syesterday[13];
char    v_sMsg[1000];
char    sdclose[11],dclose[11];
$char   ipolicy[21];
char    swhere[50]; 
int     freview;
$char   start_date[11];

/* For cm_ply_passbook_dtl */
$int   iins_sno,rtn = 0;
$char  iins_type[7],nins_type[121],edomain[81];
$char  cover_print1[51],cover_print2[51],cover_print3[51],cover_print4[51];
$char  ndeduct[30],ncover1[30],ncover2[30],ncover3[30],ncover4[30],n_ins_premium[30];
$char  niins_name[251],nins_type_tmp1[101],nins_type_tmp2[101],nins_type_tmp3[101],nins_type_tmp4[101],niins_cont[501];
$char  fmark0[2],fmark1[2],fmark2[2],fmark3[2];
$int   cnt_ins_dollor=0;

long car993_get_db();
long insert_cm_ply_passbook_dtl();
/****************************************************************************/
main(argc, argv)
int argc;
char **argv;
{  
	int   rc;
	$int  t_count=0;
	$char stmt[1024];
	$char email[100];
	$char receiver_IT[2000],receiver_PL[2000];    
	long  itmp;
	           
	batchinit();
	strcpy(DBName, isNULLstr(argv[1]));
	strcpy(userid, isNULLstr(argv[2]));
	strcpy(fkind,  isNULLstr(argv[3]));  /* A:���s�ǰe��� B:�w�鵲���ǰe�d��*/
	strcpy(fclass, isNULLstr(argv[4]));  /* 1�G�O�� 2�G��� 3:�O��+��� */
	strcpy(date1,  isNULLstr(argv[5]));  /* �n���檺�_�l��*/
	strcpy(date2,  isNULLstr(argv[6]));  /* �n���檺������*/
	strcpy(outputf,isNULLstr(argv[7]));
	
	printf("-- fkind:[%s] \n",fkind);
	printf("-- fclass:[%s] \n",fclass);

	dtoday = cm_today();
	strcpy(stoday , cm_edate_str(dtoday));
	printf("-- �t�Τ�:[%s] \n",stoday);	

	rc = car993_get_db();
	if (rc != M_CM_OK)
	{
		EWRITE(userid,rc,msgbuf);
		return rc;
	}

	rc = car993_createtmp();
	if (rc != M_CM_OK)
	    return rc;	

	strcpy(stmt,"SELECT today-1 \n"
	            "  FROM cm_code_data   \n"
	            " WHERE itype='11' AND icode1='CMN5136T' AND icode2='C'; \n");
	$PREPARE get_yesterday FROM $stmt;
	$EXECUTE get_yesterday INTO $syesterday;
        
	strcpy(syesterday,trim(syesterday));
	printf("-- �t�Τ�e�@��:[%s] \n",syesterday);	

	strcpy(stmt,"SELECT detail2 \n"
	            "  FROM car_code   \n"
	            " WHERE kind='PB' AND detail='001'; \n");
		
	$PREPARE get_startdate FROM $stmt;
	$EXECUTE get_startdate INTO $start_date;
        
	strcpy(start_date,trim(start_date));
	printf("-- �ҥΤ�:[%s] \n",start_date);

	/*�P�_�ҥΤ�*/
	t_count = 0;
	strcpy(stmt,"SELECT count(*) \n"
	            "  FROM car_code   \n"
	            " WHERE kind='PB' AND detail='001' AND today>=DATE(detail2); \n");
	
	$PREPARE chk_dstart FROM $stmt;
	$EXECUTE chk_dstart INTO $t_count;
		        
	if (t_count > 0)	        
	{
		t_count = 0 ;
		freview = 0 ; /*�O�_�O�^�ɸ�� 0:���O(�w�])  1:�O*/
		
		/*�Y��J���_��A����O��s�P�ҥΤ�A�����O�n�^�ɺI�ܱҥΤ鬰����īO���ơA�W�[�P�_�̷s�O������n>=�O��s�P�ҥΤ�*/	
		sprintf_s(stmt, sizeof stmt,"SELECT count(*) \n"
		             "  FROM car_code \n"
		             " WHERE kind='PB' AND detail='001' AND DATE('%s')>=DATE(detail2); \n",dbgn);
		
		$PREPARE chk_dstart FROM $stmt;
		$EXECUTE chk_dstart INTO $t_count;
	        
		if(t_count == 0)
		{
			sprintf_s(swhere, sizeof swhere," AND c.dply_end >= '%s' ",start_date);
			freview = 1 ;
		}
		else
		{
			strcpy(swhere," ");	
		}    
	    
		if (strcmp(fkind,"A") == 0)
		{
			strcpy(dbgn, cm_to_infdate(date1));
			strcpy(dend, cm_to_infdate(date2));
			printf("-- ����϶�(�褸):[%s] ~ [%s]\n",dbgn,dend);
			
			sfp =  (FILE *)STARTLOG();

			if (strcmp(fclass,"1") == 0 || strcmp(fclass,"3") == 0)
			{
				rc = car993_policy();
				if (rc != M_CM_OK)
				return rc;
				
				WRITELOG( sfp, " �O�����ɧ��� "); 
				
				/*�Y����_������D�P�@�ѩΰ����D�t�Τ�-1�A�������A��s*/
				if (strcmp(dbgn,dend) == 0 && strcmp(dbgn,syesterday) == 0)
				{	
					rc = car993_statusC1();
					if (rc != M_CM_OK)
					return rc;
					
					WRITELOG( sfp, " cmn522/11/C1���A��s���� ");   
				}
			}

			if (strcmp(fclass,"2") == 0 || strcmp(fclass,"3") == 0)
			{		
				rc = car993_endorse();
				if (rc != M_CM_OK)
				return rc;
				
				WRITELOG( sfp, " ������ɧ��� ");
				
				/*�Y����_������D�P�@�ѩΰ����D�t�Τ�-1�A�������A��s*/
				if (strcmp(dbgn,dend) == 0 && strcmp(dbgn,syesterday) == 0)
				{	
					rc = car993_statusC2();
					if (rc != M_CM_OK)
					return rc;
					
					WRITELOG( sfp, " cmn522/11/C2���A��s���� ");   
				}
			}

			ENDLOG(sfp);
	        
			if (strcmp(dbgn,dend) == 0 && strcmp(dbgn,syesterday) == 0 )
			{	
				strcpy(receiver_IT,"");
				strcpy(receiver_PL,"");

				/*�Ƶ{���浲����A���浲�GEmail�q����T*/
				
				strcpy(stmt,"SELECT trim(email)||'@tmnewa.com.tw,' \n"
				            "  FROM asempl \n"
				            " WHERE empl_no IN (SELECT detail2 FROM car_code WHERE kind='PB' AND detail='002')\n");

				$PREPARE get_receiver_IT FROM $stmt;
				$DECLARE cur_email_IT CURSOR FOR get_receiver_IT;
				$OPEN cur_email_IT ;
		
				while (1)
				{
					$FETCH cur_email_IT INTO $email;

					if (SQLCODE == SQLNOTFOUND) break;
					strcat(receiver_IT,email);
				}
				$CLOSE cur_email_IT;
				$FREE cur_email_IT;
	            
				strcpy(receiver_IT,trim(receiver_IT));
				itmp = strlen(receiver_IT);
				
				receiver_IT[itmp-1]='\0';
				printf("receiver_IT[%s]\n",receiver_IT);
			
				if( strncmp(sApHome,"/DEV/IPIS",9) == 0 )
				{
					sprintf_s(cmd1, sizeof cmd1,"uuencode /DEV/IPIS/tmp/%s.err /DEV/IPIS/tmp/%s.err ",outputf,outputf);/*DEV����*/
					/*sprintf_s(cmd2, sizeof cmd2,"mail -s '(�������իH��)���I�O��s�P���浲�G�q�� %s' %s < /DEV/IPIS/tmp/%s.err",date1,receiver_IT,outputf);/*DEV����*/
					sprintf_s(cmd2, sizeof cmd2,"mailx -r \"ipisnew@tmnewa.com.tw\" -s \"$(echo \"(�������իH��)���I�O��s�P���浲�G�q�� %s\"\"\\nContent-Type: text/plain; charset=\\\"big5\\\"\")\" -c \" \" %s < /DEV/IPIS/tmp/%s.err",date1,receiver_IT,outputf);
				}
				else if( strncmp(sApHome,"/TEST/IPIS",10) == 0 )
				{
					sprintf_s(cmd1, sizeof cmd1,"uuencode /TEST/IPIS/tmp/%s.err /TEST/IPIS/tmp/%s.err ",outputf,outputf);/*TEST����*/
					/*sprintf_s(cmd2, sizeof cmd2,"mail -s '(�������իH��)���I�O��s�P���浲�G�q�� %s' %s < /TEST/IPIS/tmp/%s.err",date1,receiver_IT,outputf);/*TEST����*/
					sprintf_s(cmd2, sizeof cmd2,"mailx -r \"ipisnew@tmnewa.com.tw\" -s \"$(echo \"(�������իH��)���I�O��s�P���浲�G�q�� %s\"\"\\nContent-Type: text/plain; charset=\\\"big5\\\"\")\" -c \" \" %s < /TEST/IPIS/tmp/%s.err",date1,receiver_IT,outputf);                    	
				}
				else if( strncmp(sApHome,"/PROD/IPISNEW",13) == 0 )
				{
					sprintf_s(cmd1, sizeof cmd1,"uuencode /PROD/IPISNEW/tmp/%s.err /PROD/IPISNEW/tmp/%s.err ",outputf,outputf);/*PROD����*/
					/*sprintf_s(cmd2, sizeof cmd2,"mail -s '���I�O��s�P���浲�G�q�� %s' %s < /PROD/IPISNEW/tmp/%s.err",date1,receiver_IT,outputf);/*PROD����*/
					sprintf_s(cmd2, sizeof cmd2,"mailx -r \"ipisnew@tmnewa.com.tw\" -s \"$(echo \"���I�O��s�P���浲�G�q�� %s\"\"\\nContent-Type: text/plain; charset=\\\"big5\\\"\")\" -c \" \" %s < /PROD/IPISNEW/tmp/%s.err",date1,receiver_IT,outputf);	
				}

				rc = system(cmd1);
				rc = system(cmd2);

				/*�W�L�ѼƵo�H�q��-�q����T�η~�޳��*/
				
				/*�H�󤺮e*/
				rc = car993_check_unload();
				if (rc != M_CM_OK)
				return rc;
	            
	            if (count_unload != 0)
	            {
					strcpy(stmt,"SELECT  trim(email)||'@tmnewa.com.tw,' \n"
					            "  FROM asempl \n"
					            " WHERE empl_no IN (SELECT detail2 FROM car_code  WHERE kind='PB' AND detail IN ('002','003'))\n");
					            
					$PREPARE get_receiver_PL FROM $stmt;
					$DECLARE cur_email_PL CURSOR FOR get_receiver_PL;
					$OPEN cur_email_PL ;
					
					while (1)
					{
						$FETCH cur_email_PL INTO $email;

						if (SQLCODE == SQLNOTFOUND) break;
						strcat(receiver_PL,email);
					}
					$CLOSE cur_email_PL;
					$FREE cur_email_PL;
	            
					strcpy(receiver_PL,trim(receiver_PL));
					itmp = strlen(receiver_PL);
					
					receiver_PL[itmp-1]='\0';
					printf("receiver_PL[%s]\n",receiver_PL);
					
					if( strncmp(sApHome,"/DEV/IPIS",9) == 0 )
					{
						strcpy(cmd1,"uuencode /DEV/IPIS/rptftp/car993_check_unload.txt /DEV/IPIS/rptftp/car993_check_unload.txt");/*DEV����*/
						/*sprintf_s(cmd2, sizeof cmd2,"mail -s '(�������իH��)���I�O��s�P�O5�饼�W�ǳq���A�Ц�car993�d��' %s < /DEV/IPIS/rptftp/car993_check_unload.txt",receiver_PL);/*DEV����*/
						sprintf_s(cmd2, sizeof cmd2,"mailx -r \"ipisnew@tmnewa.com.tw\" -s \"$(echo \"(�������իH��)���I�O��s�P�O5�饼�W�ǳq���A�Ц�car993�d�� \"\"\\nContent-Type: text/plain; charset=\\\"big5\\\"\")\" -c \" \" %s < /DEV/IPIS/rptftp/car993_check_unload.txt",receiver_PL);
						
					}
					else if( strncmp(sApHome,"/TEST/IPIS",10) == 0 )
					{
						strcpy(cmd1,"uuencode /TEST/IPIS/rptftp/car993_check_unload.txt /TEST/IPIS/rptftp/car993_check_unload.txt");/*TEST����*/
						/*sprintf_s(cmd2, sizeof cmd2,"mail -s '(�������իH��)���I�O��s�P�O5�饼�W�ǳq���A�Ц�car993�d��' %s < /TEST/IPIS/rptftp/car993_check_unload.txt",receiver_PL);/*TEST����*/
						sprintf_s(cmd2, sizeof cmd2,"mailx -r \"ipisnew@tmnewa.com.tw\" -s \"$(echo \"(�������իH��)���I�O��s�P�O5�饼�W�ǳq���A�Ц�car993�d�� \"\"\\nContent-Type: text/plain; charset=\\\"big5\\\"\")\" -c \" \" %s < /TEST/IPIS/rptftp/car993_check_unload.txt",receiver_PL);                    	
					}
					else if( strncmp(sApHome,"/PROD/IPISNEW",13) == 0 )
					{
						strcpy(cmd1,"uuencode /PROD/IPISNEW/rptftp/car993_check_unload.txt /PROD/IPISNEW/rptftp/car993_check_unload.txt");/*PROD����*/
						/*sprintf_s(cmd2, sizeof cmd2,"mail -s '���I�O��s�P�O5�饼�W�ǳq���A�Ц�car993�d��' %s < /PROD/IPISNEW/rptftp/car993_check_unload.txt",receiver_PL);/*PROD����*/
						sprintf_s(cmd2, sizeof cmd2,"mailx -r \"ipisnew@tmnewa.com.tw\" -s \"$(echo \"���I�O��s�P�O5�饼�W�ǳq���A�Ц�car993�d�� \"\"\\nContent-Type: text/plain; charset=\\\"big5\\\"\")\" -c \" \" %s < /PROD/IPISNEW/rptftp/car993_check_unload.txt",receiver_PL);	
					}

					rc = system(cmd1);
					rc = system(cmd2);        	
				}
			} 	        
		}
		else if(strcmp(fkind,"B") == 0)
		{
			strcpy(sdclose, cm_to_infdate(date1));
			rc = car993_query();
			if (rc != M_CM_OK) 
			{
				EWRITE(userid, rc, "�d�L���!");
				return rc;
			}
		}		
	}
	else
	{
		EWRITE(userid, rc, "�|���ҥΡA�L������!");	
	}
	return rc;
}
/******************************************************************************/
long car993_policy()
{
	$char  ipolicy[21],ftype[2];
	$char  fapplicant_n[2],iapplicant_n[11],napplicant_n[121];
	$char  fassured_n[2],iassured_n[11],nassured_n[121];
	$date  dbgn_n,dend_n,dpolicy;
	$char  fprocess[2],isys_source[4],ntprop_cont[21],icar_type[3];
	int   rc;
	printf("BEGIN TO car993_policy\n");    

	/*�B�z����鵲�����N�I�۵M�H�O��*/
	for(k=0;k<count_db;k++)
	{
		sprintf_s(stmt1, sizeof stmt1,"SELECT a.ipolicy, CASE b.feply WHEN '1' THEN 'E' ELSE 'P' END ,\n"
		              "       CASE WHEN a.fapplicant IN ('2','4','6') THEN '4' \n"
		              "            WHEN a.fapplicant IN ('1') THEN '1' \n"
		              "            WHEN a.fapplicant IN ('3') THEN (CASE WHEN a.iapplicant[2] IN ('0','1','2','3','4','5','6','7','8','9') THEN '3' ELSE '2' END) \n"
		              "            ELSE '5' END , \n"
		              "       a.iapplicant,a.napplicant, \n"
		              "       CASE WHEN a.fassured IN ('2','4','6') THEN '4' \n"
		              "            WHEN a.fassured IN ('1') THEN '1' \n"
		              "            WHEN a.fassured IN ('3') THEN (CASE WHEN a.iassured[2] IN ('0','1','2','3','4','5','6','7','8','9') THEN '3' ELSE '2' END) \n"
		              "       ELSE '5' END ,  \n"
		              "       a.iassured,a.nassured, \n"
		              "       b.dply_begin,b.dply_end,'A',\n"
		              "       CASE b.fcard_class WHEN '1' THEN 'CAL' ELSE 'CAR' END ,\n"
		              "       CASE WHEN nvl(trim(a.itag),'')='' THEN '' ELSE (CASE b.fcard_class WHEN '1' THEN 'CAL&'||trim(a.itag) ELSE 'CAR&'||trim(a.itag) END) END ,\n"
		              "       b.dpolicy,b.icar_type \n"
		              "  FROM %s:original_ply a, %s:ori_ply_relation b, %s:ply_relation c \n"
		              " WHERE a.ipolicy = b.ipolicy AND c.ipolicy = b.ipolicy \n"
		              "   AND b.dply_close between ? and ? \n"
		              "   AND b.dpolicy between ? and ? \n"
		              /*"   AND a.ipolicy = '87211V9016891' \n"*/
		              "   AND a.fassured IN ('1','3','5') AND b.fcard_class = '2' %s \n" ,list[k].dbname,list[k].dbname,list[k].dbname,swhere);
		              /*"   AND a.fassured IN ('1','3','5') AND b.fcard_class = '2' \n" ,list[k].dbname,list[k].dbname,list[k].dbname);*/
		              
		printf("stmt1[%s], dbgn[%s], dend[%s], dbgn[%s], dend[%s]\n",stmt1, dbgn, dend, dbgn, dend);
		$PREPARE CUR_PLY FROM $stmt1;
		$DECLARE cur_ply1 CURSOR FOR CUR_PLY;
		$OPEN cur_ply1 USING $dbgn, $dend, $dbgn, $dend;

		while (1)
		{
			$FETCH cur_ply1 INTO $ipolicy,$ftype,
			                     $fapplicant_n,$iapplicant_n,$napplicant_n,
			                     $fassured_n,$iassured_n,$nassured_n,
			                     $dbgn_n,$dend_n,$fprocess,
			                     $isys_source,
			                     $ntprop_cont,$dpolicy,$icar_type;

			if (SQLCODE == SQLNOTFOUND) break;
			strcpy(icar_type,TRANS_CAR_TYPE(icar_type));
			
			$INSERT INTO sysdb:cm_ply_passbook
			             (iins_cat,ipolicy,iendorse,iserno,ftype,fassured_o,iassured_o,dbgn_o,
			              fapplicant_n,iapplicant_n,napplicant_n,fassured_n,iassured_n,nassured_n,
			              dbgn_n,dend_n,fprocess,isys_source,ntprop_cont,dwritten,dentry,nremark,nfile_batch,fstatus,iresult,nresult,nedr_reason,iupdate,dupdate)
			             VALUES
			             ('C',$ipolicy,'','01',$ftype,$fassured_n,$iassured_n,$dbgn_n,
			              $fapplicant_n,$iapplicant_n,$napplicant_n,$fassured_n,$iassured_n,$nassured_n,
			              $dbgn_n,$dend_n,$fprocess,$isys_source,$ntprop_cont,$dpolicy,CURRENT,'','',100,'','',' ','car993',CURRENT);
		
			if(SQLCODE!=0)
			{
				if(SQLCODE==-239)
				{
					printf("�O���Ƥw�s�b[%s]\n",ipolicy);
					sprintf_s(v_sMsg, sizeof v_sMsg,"�O���Ƥw�s�b[%s]",ipolicy);
					WRITELOG( sfp, v_sMsg);
					continue;
				}
				else
				{
					printf("�O�渹��Ʋ��s���~[%s][%d][%s]\n",ipolicy,SQLCODE, sqlca.sqlerrm);
					sprintf_s(v_sMsg, sizeof v_sMsg,"�O�渹��Ʋ��s���~[%s][%d][%s]",ipolicy,SQLCODE, sqlca.sqlerrm);
					WRITELOG( sfp, v_sMsg);
					continue;
				}
			}
			else
			{
				/* 1111104007_SC1_�s�W�O��s�P�ǰe���γW�h */
				rc = insert_cm_ply_passbook_dtl(list[k].dbname,ipolicy," ","01",iassured_n,icar_type,"0");
				if (rc != M_CM_OK) return rc;

				printf("�O�渹[%s]�B�z����\n",ipolicy);	
				printf("�O�渹[%s]�s�W�I�ة���\n",ipolicy);	
			}
		}
		$CLOSE cur_ply1;
		$FREE cur_ply1;

	}
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE; 
}
/******************************************************************************/
long car993_endorse()
{
	$char   ipolicy[21],iendorse[21];	
	$int    t_count,fFirstInsert;
	$char   sFullDB[21];
	int     rc;
	$int    inumber;                                                    
	$char   snumber[5];                                                     	
	
	$char   fcitizen[2],fchgID[2],fnoINS[2];
	$char   new_fassured[2],new_iassured[11],new_dbgn[11];
	$char   iedr_last[21],iedr_newest[23],icar_type[3];                
	                
	$char   iassured_dtl[11];
	$char   iendorse_next[21],itype_dtl[2];
	printf("BEGIN TO car993_endorse\n");    
	
	/*�B�z����鵲�����N�I�۵M�H���*/ 
	for(k=0;k<count_db;k++)
	{
		sprintf_s(stmt1, sizeof stmt1,"SELECT a.ipolicy,a.iendorse,a.icar_type \n"
		              "  FROM %s:edr_relation a,%s:ply_relation c  \n"
		              " WHERE a.dedr_close BETWEEN ? AND ? AND a.dendorse BETWEEN ? AND ?  AND a.ipolicy = c.ipolicy \n"
		              "   AND a.iendorse NOT LIKE '%%CVP%%' AND a.fcard_class='2' %s \n"
		              /*"   And a.iendorse IN ('00011V9E10334') "*/
		              " ORDER BY a.ipolicy ASC,a.dcreate ASC  \n" ,list[k].dbname,list[k].dbname,swhere);
	
		$PREPARE CUR_EDR FROM $stmt1;
		$DECLARE cur_edr1 CURSOR FOR CUR_EDR;
		$OPEN cur_edr1 USING $dbgn, $dend, $dbgn, $dend;
		
		while (1)
		{
			
			$FETCH cur_edr1 INTO $ipolicy,$iendorse,$icar_type;
			if (SQLCODE == SQLNOTFOUND) break;
			strcpy(icar_type,TRANS_CAR_TYPE(icar_type));
			
			strcpy(ipolicy,trim(ipolicy));
			strcpy(iendorse,trim(iendorse));

			strcpy(sFullDB, get_car_full_dbname(ipolicy));

			/***************************************************************************************/
			/*  �P�_�O��w����J�ɶ��ߩ�ӱi��檺�t�@�i���s�bcm_ply_passbook�A�h�����������B�z  */
			/***************************************************************************************/
			t_count = 0;
			sprintf_s(stmt1, sizeof stmt1,"SELECT count(*) FROM cm_ply_passbook WHERE isys_source IN ('CAR','CAL') \n"
			              "   AND ipolicy='%s' \n"
			              "   AND iendorse IN  \n"
			              "   (SELECT b.iendorse FROM %s:edr_relation a,%s:edr_relation b \n"
			              "     WHERE a.ipolicy='%s'  \n"
			              "       AND a.iendorse='%s' AND a.ipolicy=b.ipolicy  \n"
			              "       AND b.dcreate > a.dcreate AND b.iendorse NOT LIKE '%%CVP%%') \n" ,ipolicy,sFullDB,sFullDB,ipolicy,iendorse);

			$PREPARE chk_other_edr FROM $stmt1;
			$EXECUTE chk_other_edr INTO $t_count;
			
			if(t_count > 0)/*�s�b*/
			{
				sprintf_s(v_sMsg, sizeof v_sMsg,"��渹[%s]���B�z�A�]���w����J�ɶ��ߩ󥻱i��檺�t�@�i���s�b",iendorse);
				WRITELOG( sfp, v_sMsg);
				continue;	
			}

			/***********************************************************************************/    
			/*  �P�_����J�ɶ�����ӱi��檺�t�@�i���|���g�Jcm_ply_passbook�A�����]�Ȥ��g�J  */
			/***********************************************************************************/
			strcpy(iedr_last,"");
			
			$DELETE FROM car993_tmp1 WHERE 1=1;
			rc = car993_prepare(ipolicy);
			if (rc != M_CM_OK){
				sprintf_s(v_sMsg, sizeof v_sMsg,"�O�渹[%s]car993_prepare���~1[%d][%s]",ipolicy, SQLCODE, sqlca.sqlerrm);
				WRITELOG( sfp, v_sMsg);
				continue;
			}
			
	   		/*�P�_��ƬO�_�s�bcar993_tmp1*/
    		fFirstInsert = 0;
			
			sprintf_s(stmt1, sizeof stmt1,"SELECT count(*) \n"
			              "  FROM car993_tmp1   \n"
			              " WHERE ipolicy = '%s' \n" ,ipolicy);
			
			$PREPARE chk_in_tmp FROM $stmt1;
			$EXECUTE chk_in_tmp INTO $fFirstInsert;
 			
			if(fFirstInsert != 0)
			{
				/*��W�@�����*/
				sprintf_s(stmt1, sizeof stmt1,"SELECT FIRST 1 b.iendorse FROM %s:edr_relation a,%s:edr_relation b \n"
				              " WHERE a.ipolicy='%s' \n"
				              "   AND a.iendorse='%s' AND a.ipolicy=b.ipolicy  \n"
				              "   AND b.dcreate < a.dcreate AND b.iendorse NOT LIKE '%%CVP%%' ORDER BY b.dcreate DESC \n" ,sFullDB,sFullDB,ipolicy,iendorse);

				$PREPARE get_last_edr FROM $stmt1;
				$EXECUTE get_last_edr INTO $iedr_last;
				
				strcpy(iedr_last,trim(iedr_last));
				
				/*�����W�@�����*/
				if (strcmp(iedr_last,"") != 0 )
				{
					t_count = 0;
					/*�P�_�W�@�����O�_�O�۵M�H*/
					sprintf_s(stmt1, sizeof stmt1,"SELECT count(*) FROM %s:endorsement a,%s:policy_bak b,%s:edr_relation c  \n"
					              " WHERE a.iendorse = '%s'  \n"
					              "   AND a.iendorse=b.iendorse AND b.iendorse=c.iendorse \n"
					              "   AND (a.fassured IN ('1','3','5') OR b.fassured IN ('1','3','5')) \n" ,sFullDB,sFullDB,sFullDB,iedr_last);

					$PREPARE chk_last_edr FROM $stmt1;
					$EXECUTE chk_last_edr INTO $t_count;
					
					/*�W�@�����O�۵M�H*/
					if(t_count > 0)
					{
						/*�P�_�e�@�i���O�_�s�bcm_ply_passbook*/
						t_count = 0 ;
						sprintf_s(stmt1, sizeof stmt1,"SELECT count(*) FROM cm_ply_passbook \n"
						              " WHERE ipolicy = '%s' \n"
						              "   AND iendorse = '%s'  \n" ,ipolicy,iedr_last);
						
						$PREPARE chk_edr_exist FROM $stmt1;
						$EXECUTE chk_edr_exist INTO $t_count;
						
						/*���s�bcm_ply_passbook*/
						if(t_count == 0)
						{
							sprintf_s(v_sMsg, sizeof v_sMsg,"��渹[%s]�A�]������J�ɶ����󥻱i��檺�t�@�i���[%s]�|���g�J�A�нT�{",iendorse,iedr_last);
							WRITELOG( sfp, v_sMsg);
							continue;
						}
					}
				}
			}
 			
			/**********************/
			/*  �}�l�B�z���g�J  */
			/**********************/

 			/*�P�_���e�O�_���۵M�H*/
			t_count = 0;
			
			sprintf_s(stmt1, sizeof stmt1,"SELECT count(*) \n"
			              "  FROM %s:policy_bak   \n"
			              " WHERE iendorse = '%s' \n"
			              "   AND fassured IN ('1','3','5')\n",sFullDB,iendorse);
			
			$PREPARE chk_fassured_bf FROM $stmt1;
			$EXECUTE chk_fassured_bf INTO $t_count;
			
			if (t_count > 0 ) /*���e���۵M�H*/
			{
				if ( fFirstInsert == 0 ) /*���s�bcar993_tmp1*/
				{
					/*�ɼg�J�@�����e�O�污�p*/
					$SELECT nvl(max(CAST (iserno AS INTEGER )),0)+1
					   INTO $inumber
					   FROM sysdb:cm_ply_passbook
					  WHERE ipolicy = $ipolicy;
					
					sprintf_s(snumber, sizeof snumber, "%02d", inumber); 
/*A*/
					sprintf_s(stmt1, sizeof stmt1,"INSERT INTO sysdb:cm_ply_passbook \n"
					              "SELECT 'C',a.ipolicy,'','%s', CASE a.feply WHEN '1' THEN 'E' ELSE 'P' END ,\n"
					              "       CASE WHEN b.fassured IN ('2','4','6') THEN '4' \n"
					              "            WHEN b.fassured IN ('1') THEN '1' \n"
					              "            WHEN b.fassured IN ('3') THEN (CASE WHEN b.iassured[2] IN ('0','1','2','3','4','5','6','7','8','9') THEN '3' ELSE '2' END)\n"
					              "            ELSE '5' END , \n" 
					              "       b.iassured,a.dply_begin,\n" 
					              "       CASE WHEN b.fapplicant IN ('2','4','6') THEN '4' \n"
					              "            WHEN b.fapplicant IN ('1') THEN '1' \n"
					              "            WHEN b.fapplicant IN ('3') THEN (CASE WHEN b.iapplicant[2] IN ('0','1','2','3','4','5','6','7','8','9') THEN '3' ELSE '2' END)\n"
					              "            ELSE '5' END , \n"
					              "       b.iapplicant,b.napplicant,\n"
					              "       CASE WHEN b.fassured IN ('2','4','6') THEN '4' \n"
					              "            WHEN b.fassured IN ('1') THEN '1' \n"
					              "            WHEN b.fassured IN ('3') THEN (CASE WHEN b.iassured[2] IN ('0','1','2','3','4','5','6','7','8','9') THEN '3' ELSE '2' END)\n"
					              "            ELSE '5' END , \n" 
					              "       b.iassured,b.nassured,\n" 
					              "       a.dply_begin,a.dply_end,'A',\n"
					              "       CASE a.fcard_class WHEN '1' THEN 'CAL' ELSE 'CAR' END ,\n"
					              "       CASE WHEN nvl(trim(b.itag),'')='' THEN '' ELSE (CASE a.fcard_class WHEN '1' THEN 'CAL&'||trim(b.itag) ELSE 'CAR&'||trim(b.itag) END) END ,\n"
					              "       a.dpolicy,CURRENT,'','',100,DATE(''),DATE(''),'','','',DATE(''),'car993',CURRENT\n"
					              "  FROM %s:ply_relation_bak a,%s:policy_bak b \n"
					              " WHERE a.iendorse='%s' AND a.iendorse=b.iendorse \n" ,snumber,sFullDB,sFullDB,iendorse);
					
					$PREPARE INSERT_A_1 FROM $stmt1;
					$EXECUTE INSERT_A_1 ;

					if(SQLCODE!=0)
					{
						sprintf_s(v_sMsg, sizeof v_sMsg,"��渹[%s]�^�ɧ��e�̷s�O���Ʈɦ��~[%d][%s]",iendorse,SQLCODE, sqlca.sqlerrm);
						WRITELOG( sfp, v_sMsg);
						continue;
					}
					else 
					{
						/* 1111104007_SC1_�s�W�O��s�P�ǰe���γW�h */
						/* ��e�O�檬�p */
						sprintf_s(stmt1, sizeof stmt1,"SELECT iassured FROM %s:policy_bak WHERE iendorse = '%s'",sFullDB,iendorse);
						$PREPARE dtl_iass1 FROM $stmt1;
						$EXECUTE dtl_iass1 INTO $iassured_dtl;
	
						rc = insert_cm_ply_passbook_dtl(sFullDB,ipolicy," ",snumber,iassured_dtl,icar_type,"0");
						if (rc != M_CM_OK) return rc;
					}
				}

				$DELETE FROM car993_tmp1 WHERE 1=1;
				rc = car993_prepare(ipolicy);
				if (rc != M_CM_OK){
					sprintf_s(v_sMsg, sizeof v_sMsg,"�O�渹[%s]car993_prepare���~2[%d][%s]",ipolicy, SQLCODE, sqlca.sqlerrm);
					WRITELOG( sfp, v_sMsg);
					continue;
				}

				strcpy(fcitizen,""); /*1:���i���O�۵M�H 2:���i���O�k�H*/
				strcpy(fchgID,"");   /*1:�L�� 2:�D�L��D���P 3:���P*/			    
				strcpy(fnoINS,"");   /*1:���h 2:�D���h*/
			    
				sprintf_s(stmt1, sizeof stmt1,"SELECT CASE WHEN a.fassured IN ('1','3','5') THEN '1' ELSE '2' END ,\n"
				              "       CASE WHEN c.fedr_class IN ('2','8') THEN '1' WHEN c.fedr_class IN ('1') THEN '3' ELSE '2' END, \n"
				              "       CASE WHEN  nvl((SELECT SUM(mdamage_cover) FROM %s:ply_ins_type_bak WHERE iendorse=a.iendorse),0) + \n"
				              "                  nvl((SELECT SUM(medrdmg_cover) FROM %s:edr_ins_type WHERE iendorse=a.iendorse),0) = 0   \n"
				              "            THEN '1' ELSE '2' END"
				              "  FROM %s:endorsement a,%s:policy_bak b,%s:edr_relation c \n"
				              " WHERE a.iendorse='%s'\n"
				              "   AND a.iendorse=b.iendorse AND a.iendorse=c.iendorse \n" ,sFullDB,sFullDB,sFullDB,sFullDB,sFullDB,iendorse);
				
				$PREPARE chk_diff FROM $stmt1;
				$EXECUTE chk_diff INTO $fcitizen,$fchgID,$fnoINS;
		            
				/*�o�i���O�۵M�H(�L��)*/
				if (strcmp(fcitizen,"1")==0 && strcmp(fchgID,"1")==0 )
				{
		            	
					/*�P�@�ѹL��ӹL��h�����p�P�_(�L��g�JA�e�A���P�_�O�_�PID�P�ͮĤ骺��Ƥw�s�bcar993_tmp1�A�Y�����ɤ@��D)*/
					strcpy(new_fassured,"");
					strcpy(new_iassured,"");
					strcpy(new_dbgn,"");
		            	
 			        sprintf_s(stmt1, sizeof stmt1,"SELECT CASE WHEN b.fassured IN ('2','4','6') THEN '4' \n"
 			                      "            WHEN b.fassured IN ('1') THEN '1' \n"
 			                      "            WHEN b.fassured IN ('3') THEN (CASE WHEN b.iassured[2] IN ('0','1','2','3','4','5','6','7','8','9') THEN '3' ELSE '2' END) \n"
			                      "       ELSE '5' END , \n"
			                      "       b.iassured,a.dedr_begin \n"
			                      "  FROM %s:edr_relation a,%s:endorsement b \n"
			                      " WHERE a.iendorse='%s' AND a.iendorse=b.iendorse \n" ,sFullDB,sFullDB,iendorse);
			                      
					$PREPARE get_new_iassured FROM $stmt1;
					$EXECUTE get_new_iassured INTO $new_fassured,$new_iassured,$new_dbgn;

					/*�P�_�O�_�PID�P�ͮĤ骺��Ƥw�s�bcar993_tmp1*/
					t_count = 0;
					
					sprintf_s(stmt1, sizeof stmt1,"SELECT count(*) \n"
					              "  FROM car993_tmp1   \n"
					              " WHERE ipolicy = '%s' \n"
					              "   AND fassured_n = '%s' \n"
					              "   AND iassured_n = '%s' \n"
					              "   AND dbgn_n = '%s' \n" ,ipolicy,new_fassured,new_iassured,new_dbgn);
					
					$PREPARE chk_ID_in_tmp FROM $stmt1;
					$EXECUTE chk_ID_in_tmp INTO $t_count;
					
					if(t_count > 0)
					{
						/*�s�b�A���g�J�@��D*/
						strcpy(iedr_newest,"");
						
						sprintf_s(stmt1, sizeof stmt1,"SELECT first 1 trim(iendorse)||'-D' \n"
						              "  FROM car993_tmp1   \n"
						              " WHERE ipolicy = '%s' \n"
						              "   AND fassured_n = '%s' \n"
						              "   AND iassured_n = '%s' \n"
						              "   AND dbgn_n = '%s' \n" ,ipolicy,new_fassured,new_iassured,new_dbgn);
						
						$PREPARE get_newest_iedr FROM $stmt1;
						$EXECUTE get_newest_iedr INTO $iedr_newest;

						$SELECT nvl(max(CAST (iserno AS INTEGER )),0)+1
						   INTO $inumber
						   FROM sysdb:cm_ply_passbook
						  WHERE ipolicy = $ipolicy;
						
						sprintf_s(snumber, sizeof snumber, "%02d", inumber); 
/*D*/
						sprintf_s(stmt1, sizeof stmt1,"INSERT INTO sysdb:cm_ply_passbook \n"
						              "SELECT 'C',c.ipolicy,'%s','%s',c.ftype ,\n"
						              "       c.fassured_n,\n"
						              "       c.iassured_n,\n"
						              "       c.dbgn_n, \n"
						              "       '','',\n"
						              "       '', \n"
						              "       '','',\n"
						              "       '', \n"
						              "       c.dbgn_n,c.dend_n,'D',\n"
						              "       c.isys_source ,\n"
						              "       c.ntprop_cont,\n"
						              "       d.dendorse,CURRENT,\n"
						              "       '', \n"
						              "       '',100,DATE(''),DATE(''),'','','',DATE(''),'car993',CURRENT\n"
						              "  FROM car993_tmp1 c,%s:edr_relation d \n"
						              " WHERE c.ipolicy='%s' AND d.iendorse='%s' AND c.ipolicy=d.ipolicy \n"
						              "   AND c.fassured_n='%s' \n"
						              "   AND c.iassured_n='%s' \n"
						              "   AND c.dbgn_n='%s' \n" ,iedr_newest,snumber,sFullDB,ipolicy,iendorse,new_fassured,new_iassured,new_dbgn);
						
						$PREPARE INSERT_D_2 FROM $stmt1;
						$EXECUTE INSERT_D_2 ;

						if(SQLCODE!=0)
						{
							sprintf_s(v_sMsg, sizeof v_sMsg,"��渹[%s]�L��R���w�s�b��Ʀ��~[%d][%s]",iendorse,SQLCODE, sqlca.sqlerrm);
							WRITELOG( sfp, v_sMsg);
							continue;
						}
						
						/*D���g�J cm_ply_passbook_dtl*/
					}

					/*�s���Q�O�H�A�g�@��A�i�h*/
					$SELECT nvl(max(CAST (iserno AS INTEGER )),0)+1
					   INTO $inumber
					   FROM sysdb:cm_ply_passbook
					  WHERE ipolicy = $ipolicy;

					sprintf_s(snumber, sizeof snumber, "%02d", inumber); 
/*A*/
					sprintf_s(stmt1, sizeof stmt1,"INSERT INTO sysdb:cm_ply_passbook \n"
					              "SELECT 'C',a.ipolicy,a.iendorse,'%s',CASE d.feply WHEN '1' THEN 'E' ELSE 'P' END ,\n"
					              "       CASE WHEN e.fassured IN ('2','4','6') THEN '4' \n"
					              "            WHEN e.fassured IN ('1') THEN '1' \n"
					              "            WHEN e.fassured IN ('3') THEN (CASE WHEN e.iassured[2] IN ('0','1','2','3','4','5','6','7','8','9') THEN '3' ELSE '2' END)\n"
					              "            ELSE '5' END , \n"
					              "       e.iassured,d.dedr_begin,\n"
					              "       CASE WHEN e.fapplicant IN ('2','4','6') THEN '4' \n"
					              "            WHEN e.fapplicant IN ('1') THEN '1' \n"
					              "            WHEN e.fapplicant IN ('3') THEN (CASE WHEN e.iapplicant[2] IN ('0','1','2','3','4','5','6','7','8','9') THEN '3' ELSE '2' END)\n"
					              "            ELSE '5' END , \n"
					              "       e.iapplicant,e.napplicant,\n"
					              "       CASE WHEN e.fassured IN ('2','4','6') THEN '4' \n"
					              "            WHEN e.fassured IN ('1') THEN '1' \n"
					              "            WHEN e.fassured IN ('3') THEN (CASE WHEN e.iassured[2] IN ('0','1','2','3','4','5','6','7','8','9') THEN '3' ELSE '2' END)\n"
					              "            ELSE '5' END , \n"
					              "       e.iassured,e.nassured,\n"
					              "       d.dedr_begin,d.dedr_end,'A',\n"
					              "       CASE d.fcard_class WHEN '1' THEN 'CAL' ELSE 'CAR' END ,\n"
					              "       CASE WHEN nvl(trim(e.itag),'')='' THEN '' ELSE (CASE d.fcard_class WHEN '1' THEN 'CAL&'||trim(e.itag) ELSE 'CAR&'||trim(e.itag) END) END,\n"
					              "       d.dendorse,CURRENT,\n"
					              "       '�L����:'||to_char(d.dedr_begin,'%%Y')||'�~'||to_char(d.dedr_begin,'%%m')||'��'||to_char(d.dedr_begin,'%%d')||'��', \n"
					              "       '',100,DATE(''),DATE(''),'','','�L��',d.dedr_begin,'car993',CURRENT\n"
					              "  FROM %s:ply_relation_bak a,%s:policy_bak b,%s:edr_relation d,%s:endorsement e \n"
					              " WHERE a.iendorse='%s' AND a.iendorse=b.iendorse \n"
					              "   AND d.iendorse=e.iendorse AND d.iendorse=a.iendorse \n" ,snumber,sFullDB,sFullDB,sFullDB,sFullDB,iendorse);
					
					$PREPARE INSERT_A_2 FROM $stmt1;
					$EXECUTE INSERT_A_2 ;
					
					if(SQLCODE!=0)
					{
						sprintf_s(v_sMsg, sizeof v_sMsg,"��渹[%s]�L��s�W�s���D��Ʀ��~[%d][%s]",iendorse,SQLCODE, sqlca.sqlerrm);
						WRITELOG( sfp, v_sMsg);
						continue;
					}
					else 
					{
						/* 1111104007_SC1_�s�W�O��s�P�ǰe���γW�h */
						/* �s���Q�O�H */
						sprintf_s(stmt1, sizeof stmt1,"SELECT iassured FROM %s:endorsement WHERE iendorse = '%s'",sFullDB,iendorse);
						$PREPARE dtl_iass2 FROM $stmt1;
						$EXECUTE dtl_iass2 INTO $iassured_dtl;
						
						rc = insert_cm_ply_passbook_dtl(sFullDB,ipolicy,iendorse,snumber,iassured_dtl,icar_type,"0");
						if (rc != M_CM_OK) return rc;
					}
					
					/*�ª��Q�O�H�A�g�@��U�i�h�A��s��O������*/
					$SELECT nvl(max(CAST (iserno AS INTEGER )),0)+1
					   INTO $inumber
					   FROM sysdb:cm_ply_passbook
					  WHERE ipolicy = $ipolicy;

					sprintf_s(snumber, sizeof snumber, "%02d", inumber); 
/*U*/
					sprintf_s(stmt1, sizeof stmt1,"INSERT INTO sysdb:cm_ply_passbook \n"
					              "SELECT 'C',a.ipolicy,a.iendorse,'%s', c.ftype ,\n"
					              "       c.fassured_n , \n"
					              "       c.iassured_n,c.dbgn_n,\n"
					              "       c.fapplicant_n, \n"
					              "       c.iapplicant_n,c.napplicant_n,\n"
					              "       c.fassured_n , \n"
					              "       c.iassured_n,c.nassured_n,\n"
					              "       c.dbgn_n,d.dedr_begin,'U',\n"
					              "       c.isys_source ,\n"
					              "       c.ntprop_cont,d.dendorse,CURRENT,\n"
					              "       '�L����:'||to_char(d.dedr_begin,'%%Y')||'�~'||to_char(d.dedr_begin,'%%m')||'��'||to_char(d.dedr_begin,'%%d')||'��', \n"
					              "       '',100,DATE(''),DATE(''),'','','�L��',d.dedr_begin,'car993',CURRENT\n"
					              "  FROM %s:ply_relation_bak a,%s:policy_bak b,car993_tmp1 c ,%s:edr_relation d,%s:endorsement e \n"
					              " WHERE a.iendorse='%s' AND a.iendorse=b.iendorse AND c.ipolicy=a.ipolicy AND c.iassured_n= b.iassured \n"
					              "   AND d.iendorse=e.iendorse AND d.iendorse=a.iendorse \n"
					              "   AND c.linnum=(SELECT max(linnum) FROM car993_tmp1 WHERE ipolicy=a.ipolicy)" ,snumber,sFullDB,sFullDB,sFullDB,sFullDB,iendorse);
					
					$PREPARE INSERT_U_2 FROM $stmt1;
					$EXECUTE INSERT_U_2 ;
					
					if(SQLCODE!=0)
					{
						sprintf_s(v_sMsg, sizeof v_sMsg,"��渹[%s]�L�Ყ�ʭ쨮�D��Ʀ��~[%d][%s]",iendorse,SQLCODE, sqlca.sqlerrm);
						WRITELOG( sfp, v_sMsg);
						continue;
					}
					else
					{
						printf("��渹[%s]�B�z����\n",iendorse);
						/* 1111104007_SC1_�s�W�O��s�P�ǰe���γW�h */
/* �L���A�ª��Q�O�I�H�A�O�B��0 */
						sprintf_s(stmt1, sizeof stmt1,"SELECT iassured FROM %s:policy_bak WHERE iendorse = '%s'",sFullDB,iendorse);
						$PREPARE dtl_iass3 FROM $stmt1;
						$EXECUTE dtl_iass3 INTO $iassured_dtl;
						
						rc = insert_cm_ply_passbook_dtl(sFullDB,ipolicy,iendorse,snumber,iassured_dtl,icar_type,"1");
						if (rc != M_CM_OK) return rc;
					}	
				}
				/*�o�i���O�۵M�H(�h�O)*/
				else if(strcmp(fcitizen,"1")==0 && strcmp(fnoINS,"1")==0)
				{
					/*�g�@��U�i�h*/
					$SELECT nvl(max(CAST (iserno AS INTEGER )),0)+1
					   INTO $inumber
					   FROM sysdb:cm_ply_passbook
					 WHERE ipolicy = $ipolicy;
					
					sprintf_s(snumber, sizeof snumber, "%02d", inumber); 
/*U*/
					sprintf_s(stmt1, sizeof stmt1,"INSERT INTO sysdb:cm_ply_passbook \n"
					              "SELECT 'C',a.ipolicy,a.iendorse,'%s', c.ftype ,\n"
					              "       c.fassured_n , \n"
					              "       c.iassured_n,c.dbgn_n,\n"
					              "       c.fapplicant_n, \n"
					              "       c.iapplicant_n,c.napplicant_n,\n"
					              "       c.fassured_n , \n"
					              "       c.iassured_n,c.nassured_n,\n"
					              "       c.dbgn_n,d.dedr_begin,'U',\n"
					              "       c.isys_source ,\n"
					              "       c.ntprop_cont,d.dendorse,CURRENT,\n"
					              "       '�h�O���:'||to_char(d.dedr_begin,'%%Y')||'�~'||to_char(d.dedr_begin,'%%m')||'��'||to_char(d.dedr_begin,'%%d')||'��', \n"
					              "       '',100,DATE(''),DATE(''),'','','�h�O',d.dedr_begin,'car993',CURRENT\n"
					              "  FROM %s:ply_relation_bak a,%s:policy_bak b,car993_tmp1 c ,%s:edr_relation d,%s:endorsement e \n"
					              " WHERE a.iendorse= '%s' AND a.iendorse=b.iendorse AND c.ipolicy=a.ipolicy AND c.iassured_n= b.iassured \n"
					              "   AND d.iendorse=e.iendorse AND d.iendorse=a.iendorse \n"
					              "   AND c.linnum=(SELECT max(linnum) FROM car993_tmp1 WHERE ipolicy=a.ipolicy)" ,snumber,sFullDB,sFullDB,sFullDB,sFullDB,iendorse);
					
					$PREPARE INSERT_U_3 FROM $stmt1;
					$EXECUTE INSERT_U_3 ;
					
					if(SQLCODE!=0)
					{ 
						sprintf_s(v_sMsg, sizeof v_sMsg,"��渹[%s]�h�O���ʭ��Ʀ��~[%d][%s]",iendorse,SQLCODE, sqlca.sqlerrm);
						WRITELOG( sfp, v_sMsg);
						continue;
					}
					else
					{
						printf("��渹[%s]�B�z����\n",iendorse);
						/* 1111104007_SC1_�s�W�O��s�P�ǰe���γW�h */
/* �h�O�A�ª��Q�O�I�H�A�O�B��0 */
						sprintf_s(stmt1, sizeof stmt1,"SELECT iassured FROM %s:policy_bak WHERE iendorse = '%s'",sFullDB,iendorse);
						$PREPARE dtl_iass4 FROM $stmt1;
						$EXECUTE dtl_iass4 INTO $iassured_dtl;
						
						rc = insert_cm_ply_passbook_dtl(sFullDB,ipolicy,iendorse,snumber,iassured_dtl,icar_type,"1");
						if (rc != M_CM_OK) return rc;
					}
				}
				/*�o�i���O�۵M�H(�D�L��D�h�O�D���P)*/
				else if(strcmp(fcitizen,"1")==0 && strcmp(fchgID,"1")!=0 && strcmp(fchgID,"3")!=0 && strcmp(fnoINS,"1")!=0)
				{
					/*�g�@��U�i�h*/
					$SELECT nvl(max(CAST (iserno AS INTEGER )),0)+1
					   INTO $inumber
					   FROM sysdb:cm_ply_passbook
					  WHERE ipolicy = $ipolicy;
					
					sprintf_s(snumber, sizeof snumber, "%02d", inumber);
/*U*/
					sprintf_s(stmt1, sizeof stmt1,"INSERT INTO sysdb:cm_ply_passbook \n"
					              "SELECT 'C',a.ipolicy,a.iendorse,'%s', CASE d.feply WHEN '1' THEN 'E' ELSE 'P' END  ,\n"
					              "       c.fassured_n , \n"
					              "       c.iassured_n,c.dbgn_n,\n"
					              "       CASE WHEN e.fapplicant IN ('2','4','6') THEN '4' \n"
					              "            WHEN e.fapplicant IN ('1') THEN '1' \n"
					              "            WHEN e.fapplicant IN ('3') THEN (CASE WHEN e.iapplicant[2] IN ('0','1','2','3','4','5','6','7','8','9') THEN '3' ELSE '2' END)\n"
					              "            ELSE '5' END , \n"
					              "       e.iapplicant,e.napplicant,\n"
					              "       CASE WHEN e.fassured IN ('2','4','6') THEN '4' \n"
					              "            WHEN e.fassured IN ('1') THEN '1' \n"
					              "            WHEN e.fassured IN ('3') THEN (CASE WHEN e.iassured[2] IN ('0','1','2','3','4','5','6','7','8','9') THEN '3' ELSE '2' END)\n"
					              "            ELSE '5' END , \n"
					              "       e.iassured,e.nassured,\n"
					              "       c.dbgn_n,e.dply_end,'U',\n"
					              "       CASE d.fcard_class WHEN '1' THEN 'CAL' ELSE 'CAR' END ,\n"
					              "       CASE WHEN nvl(trim(e.itag),'')='' THEN '' ELSE (CASE d.fcard_class WHEN '1' THEN 'CAL&'||trim(e.itag) ELSE 'CAR&'||trim(e.itag) END) END ,\n"
					              "       d.dendorse,CURRENT,\n"
					              "       '', \n"
					              "       '',100,DATE(''),DATE(''),'','',CASE d.fedr_class WHEN '6' THEN '���B���' WHEN '5' THEN '�@����' ELSE '���' END ,c.dbgn_n,\n"
					              "       'car993',CURRENT\n"
					              "  FROM %s:ply_relation_bak a,%s:policy_bak b,car993_tmp1 c ,%s:edr_relation d,%s:endorsement e \n"
					              " WHERE a.iendorse='%s' AND a.iendorse=b.iendorse AND c.ipolicy=a.ipolicy AND c.iassured_n= b.iassured \n"
					              "   AND d.iendorse=e.iendorse AND d.iendorse=a.iendorse \n"
					              "   AND c.linnum=(SELECT max(linnum) FROM car993_tmp1 WHERE ipolicy=a.ipolicy)" ,snumber,sFullDB,sFullDB,sFullDB,sFullDB,iendorse);
				
					$PREPARE INSERT_U_4 FROM $stmt1;
					$EXECUTE INSERT_U_4 ;
					
					if(SQLCODE!=0)
					{
						sprintf_s(v_sMsg, sizeof v_sMsg,"��渹[%s]���ʭ��Ʀ��~[%d][%s]",iendorse,SQLCODE, sqlca.sqlerrm);
						WRITELOG( sfp, v_sMsg);
						continue;
					}
					else
					{
						printf("��渹[%s]�B�z����\n",iendorse);
						/* 1111104007_SC1_�s�W�O��s�P�ǰe���γW�h */
/* �@���� */
						sprintf_s(stmt1, sizeof stmt1,"SELECT iassured FROM %s:policy_bak WHERE iendorse = '%s'",sFullDB,iendorse);
						$PREPARE dtl_iass5 FROM $stmt1;
						$EXECUTE dtl_iass5 INTO $iassured_dtl;
						
						rc = insert_cm_ply_passbook_dtl(sFullDB,ipolicy,iendorse,snumber,iassured_dtl,icar_type,"0");
						if (rc != M_CM_OK) return rc;
					}
				}
				/*�o�i���O�k�H(�@�w�O�L��)*/
				else if(strcmp(fcitizen,"2")==0)
				{
					/*�g�@��U�i�h�A��s��O������*/
					$SELECT nvl(max(CAST (iserno AS INTEGER )),0)+1
					INTO $inumber
					FROM sysdb:cm_ply_passbook
					WHERE ipolicy = $ipolicy;
					
					sprintf_s(snumber, sizeof snumber, "%02d", inumber); 
/*U*/
					sprintf_s(stmt1, sizeof stmt1,"INSERT INTO sysdb:cm_ply_passbook \n"
					              "SELECT 'C',a.ipolicy,a.iendorse,'%s', c.ftype ,\n"
					              "       c.fassured_n , \n"
					              "       c.iassured_n,c.dbgn_n,\n"
					              "       c.fapplicant_n, \n"
					              "       c.iapplicant_n,c.napplicant_n,\n"
					              "       c.fassured_n , \n"
					              "       c.iassured_n,c.nassured_n,\n"
					              "       c.dbgn_n,d.dedr_begin,'U',\n"
					              "       c.isys_source ,\n"
					              "       c.ntprop_cont,d.dendorse,CURRENT,\n"
					              "       '�L����:'||to_char(d.dedr_begin,'%%Y')||'�~'||to_char(d.dedr_begin,'%%m')||'��'||to_char(d.dedr_begin,'%%d')||'��', \n"
					              "       '',100,DATE(''),DATE(''),'','','�L��',d.dedr_begin,'car993',CURRENT\n"
					              "  FROM %s:ply_relation_bak a,%s:policy_bak b,car993_tmp1 c ,%s:edr_relation d,%s:endorsement e \n"
					              " WHERE a.iendorse='%s' AND a.iendorse=b.iendorse AND c.ipolicy=a.ipolicy AND c.iassured_n= b.iassured \n"
					              "   AND d.iendorse=e.iendorse AND d.iendorse=a.iendorse \n"
					              "   AND c.linnum=(SELECT max(linnum) FROM car993_tmp1 WHERE ipolicy=a.ipolicy)" ,snumber,sFullDB,sFullDB,sFullDB,sFullDB,iendorse);
					
					$PREPARE INSERT_U_5 FROM $stmt1;
					$EXECUTE INSERT_U_5 ;
					
					if(SQLCODE!=0)
					{
						sprintf_s(v_sMsg, sizeof v_sMsg,"��渹[%s]�۵M�H�L�ᵹ�k�H���ʭ쨮�D��Ʀ��~[%d][%s]n",iendorse,SQLCODE, sqlca.sqlerrm);
						WRITELOG( sfp, v_sMsg);
						continue;
					}
					else
					{
						printf("��渹[%s]�B�z����\n",iendorse);
						/* 1111104007_SC1_�s�W�O��s�P�ǰe���γW�h */
/* �L��AU�A�O�B��0 */
						sprintf_s(stmt1, sizeof stmt1,"SELECT iassured FROM %s:policy_bak WHERE iendorse = '%s'",sFullDB,iendorse);
						$PREPARE dtl_iass6 FROM $stmt1;
						$EXECUTE dtl_iass6 INTO $iassured_dtl;
						
						rc = insert_cm_ply_passbook_dtl(sFullDB,ipolicy,iendorse,snumber,iassured_dtl,icar_type,"1");
						if (rc != M_CM_OK) return rc;
					}
				} 
				/*�o�i���O�۵M�H(���P)*/
				else if(strcmp(fcitizen,"1")==0 && strcmp(fchgID,"3")==0)
				{
					/*�g�@��U�i�h*/
					$SELECT nvl(max(CAST (iserno AS INTEGER )),0)+1
					   INTO $inumber
					   FROM sysdb:cm_ply_passbook
					  WHERE ipolicy = $ipolicy;
					
					sprintf_s(snumber, sizeof snumber, "%02d", inumber); 
/*U*/
					sprintf_s(stmt1, sizeof stmt1,"INSERT INTO sysdb:cm_ply_passbook \n"
					              "SELECT 'C',a.ipolicy,a.iendorse,'%s', c.ftype ,\n"
					              "       c.fassured_n , \n"
					              "       c.iassured_n,c.dbgn_n,\n"
					              "       c.fapplicant_n, \n"
					              "       c.iapplicant_n,c.napplicant_n,\n"
					              "       c.fassured_n , \n"
					              "       c.iassured_n,c.nassured_n,\n"
					              "       c.dbgn_n,d.dedr_begin,'U',\n"
					              "       c.isys_source ,\n"
					              "       c.ntprop_cont,d.dendorse,CURRENT,\n"
					              "       '', \n"
					              "       '',100,DATE(''),DATE(''),'','','���P',d.dedr_begin,'car993',CURRENT\n"
					              "  FROM %s:ply_relation_bak a,%s:policy_bak b,car993_tmp1 c ,%s:edr_relation d,%s:endorsement e \n"
					              " WHERE a.iendorse= '%s' AND a.iendorse=b.iendorse AND c.ipolicy=a.ipolicy AND c.iassured_n= b.iassured \n"
					              "   AND d.iendorse=e.iendorse AND d.iendorse=a.iendorse \n"
					              "   AND c.linnum=(SELECT max(linnum) FROM car993_tmp1 WHERE ipolicy=a.ipolicy)" ,snumber,sFullDB,sFullDB,sFullDB,sFullDB,iendorse);
					
					$PREPARE INSERT_U_6 FROM $stmt1;
					$EXECUTE INSERT_U_6 ;
					
					if(SQLCODE!=0)
					{ 
						sprintf_s(v_sMsg, sizeof v_sMsg,"��渹[%s]���P���ʭ��Ʀ��~[%d][%s]",iendorse,SQLCODE, sqlca.sqlerrm);
						WRITELOG( sfp, v_sMsg);
						continue;
					}
					else
					{
						/* 1111104007_SC1_�s�W�O��s�P�ǰe���γW�h */
/* ���A���P�A�O�B���ӭn��0 */
						sprintf_s(stmt1, sizeof stmt1,"SELECT iassured FROM %s:policy_bak WHERE iendorse = '%s'",sFullDB,iendorse);
						$PREPARE dtl_iass7 FROM $stmt1;
						$EXECUTE dtl_iass7 INTO $iassured_dtl;
						
						rc = insert_cm_ply_passbook_dtl(sFullDB,ipolicy,iendorse,snumber,iassured_dtl,icar_type,"1");
						if (rc != M_CM_OK) return rc;	
					}
				}
			}
			else /*���e�O�k�H*/
			{
				/*�}�l�B�z�ӵ����*/
				strcpy(fcitizen,""); /*1:���i���O�۵M�H 2:���i���O�k�H*/
				
				sprintf_s(stmt1, sizeof stmt1,"SELECT CASE WHEN a.fassured IN ('1','3','5') THEN '1' ELSE '2' END \n"
				              "  FROM %s:endorsement a,%s:policy_bak b\n"
				              " WHERE a.iendorse='%s'\n"
				              "   AND a.iendorse=b.iendorse\n" ,sFullDB,sFullDB,iendorse);
			
				$PREPARE chk_diff2 FROM $stmt1;
				$EXECUTE chk_diff2 INTO $fcitizen;

				/*�o�i���O�k�H*/
				if (strcmp(fcitizen,"2")==0 )
				{
					printf("��渹[%s]�k�H��椣�B�z\n",iendorse);
					continue;
				}
				/*�o�i���O�۵M�H(�@�w�O�L��)*/
				else if(strcmp(fcitizen,"1")==0)
				{
					/*�g�@��A�i�h*/
					$SELECT nvl(max(CAST (iserno AS INTEGER)),0)+1
					   INTO $inumber
					   FROM sysdb:cm_ply_passbook
					  WHERE ipolicy = $ipolicy;

					sprintf_s(snumber, sizeof snumber, "%02d", inumber); 
/*A*/
					sprintf_s(stmt1, sizeof stmt1,"INSERT INTO sysdb:cm_ply_passbook \n"
					              "SELECT 'C',a.ipolicy,a.iendorse,'%s',CASE d.feply WHEN '1' THEN 'E' ELSE 'P' END ,\n"
					              "       CASE WHEN e.fassured IN ('2','4','6') THEN '4' \n"
					              "            WHEN e.fassured IN ('1') THEN '1' \n"
					              "            WHEN e.fassured IN ('3') THEN (CASE WHEN e.iassured[2] IN ('0','1','2','3','4','5','6','7','8','9') THEN '3' ELSE '2' END)\n"
					              "            ELSE '5' END , \n"
					              "       e.iassured,d.dedr_begin,\n"
					              "       CASE WHEN e.fapplicant IN ('2','4','6') THEN '4' \n"
					              "            WHEN e.fapplicant IN ('1') THEN '1' \n"
					              "            WHEN e.fapplicant IN ('3') THEN (CASE WHEN e.iapplicant[2] IN ('0','1','2','3','4','5','6','7','8','9') THEN '3' ELSE '2' END)\n"
					              "            ELSE '5' END , \n"
					              "       e.iapplicant,e.napplicant,\n"
					              "       CASE WHEN e.fassured IN ('2','4','6') THEN '4' \n"
					              "            WHEN e.fassured IN ('1') THEN '1' \n"
					              "            WHEN e.fassured IN ('3') THEN (CASE WHEN e.iassured[2] IN ('0','1','2','3','4','5','6','7','8','9') THEN '3' ELSE '2' END)\n"
					              "            ELSE '5' END , \n"
					              "       e.iassured,e.nassured,\n"
					              "       d.dedr_begin,d.dedr_end,'A',\n"
					              "       CASE d.fcard_class WHEN '1' THEN 'CAL' ELSE 'CAR' END ,\n"
					              "       CASE WHEN nvl(trim(e.itag),'')='' THEN '' ELSE (CASE d.fcard_class WHEN '1' THEN 'CAL&'||trim(e.itag) ELSE 'CAR&'||trim(e.itag) END) END,\n"
					              "       d.dendorse,CURRENT,\n"
					              "       '�L����:'||to_char(d.dedr_begin,'%%Y')||'�~'||to_char(d.dedr_begin,'%%m')||'��'||to_char(d.dedr_begin,'%%d')||'��', \n"
					              "       '',100,DATE(''),DATE(''),'','','�L��',d.dedr_begin,'car993',CURRENT\n"
					              "  FROM %s:ply_relation_bak a,%s:policy_bak b,%s:edr_relation d,%s:endorsement e \n"
					              " WHERE a.iendorse='%s' AND a.iendorse=b.iendorse \n"
					              "   AND d.iendorse=e.iendorse AND d.iendorse=a.iendorse \n" ,snumber,sFullDB,sFullDB,sFullDB,sFullDB,iendorse);
					      
					$PREPARE INSERT_A_2 FROM $stmt1;
					$EXECUTE INSERT_A_2 ;
					
					if(SQLCODE!=0)
					{
						sprintf_s(v_sMsg, sizeof v_sMsg,"��渹[%s]�k�H�L�ᵹ�۵M�H�s�W�s���D��Ʀ��~[%d][%s]",iendorse,SQLCODE, sqlca.sqlerrm);
						WRITELOG( sfp, v_sMsg);
						continue;
					}
					else
					{
						printf("��渹[%s]�B�z����\n",iendorse);
						/* 1111104007_SC1_�s�W�O��s�P�ǰe���γW�h */
/* �s�L��A */
						sprintf_s(stmt1, sizeof stmt1,"SELECT iassured FROM %s:endorsement WHERE iendorse = '%s'",sFullDB,iendorse);
						$PREPARE dtl_iass8 FROM $stmt1;
						$EXECUTE dtl_iass8 INTO $iassured_dtl;
						
						rc = insert_cm_ply_passbook_dtl(sFullDB,ipolicy,iendorse,snumber,iassured_dtl,icar_type,"0");
						if (rc != M_CM_OK) return rc;	
					}
				}
			}

			/*�M��temp table*/
			$DELETE FROM car993_tmp1 WHERE 1=1;
			
			/*�A�T�{�@���g�J��A��ƬO�_����*/
			rc = car993_prepare(ipolicy);
			if (rc != M_CM_OK)
			{
				sprintf_s(v_sMsg, sizeof v_sMsg,"��渹[%s]�O�渹[%s]�A�ݤH�u�B�z�A�нT�{[%d][%s]",iendorse,ipolicy, SQLCODE, sqlca.sqlerrm);
				WRITELOG( sfp, v_sMsg);
				
				$DELETE FROM cm_ply_passbook WHERE ipolicy = $ipolicy AND iendorse = $iendorse AND isys_source IN ('CAR','CAL');
				continue;
			}

			/*�M��temp table*/
			$DELETE FROM car993_tmp1 WHERE 1=1;
			
		}
		$CLOSE cur_edr1;
		$FREE cur_edr1;
	}
	return M_CM_OK;
	
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE; 
}
/******************************************************************************/
long car993_statusC1()
{
	printf("BEGIN TO car993_status\n");    
	$BEGIN WORK;
	$WHENEVER SQLERROR GOTO errexit;
	
	$char stmt[600];
	
	sprintf_s(stmt, sizeof stmt,"UPDATE cm_code_data SET ncode1= to_char(year('%s')-1911)||to_char(date('%s'),'%%m%%d'), dupdate = current, iupdate = 'car993' \n"
	             " WHERE itype = '11' AND icode1 = 'CMN5136T' AND icode2 = 'C1'\n",dbgn,dbgn);

	$PREPARE upd_statusC1 FROM $stmt;
	$EXECUTE upd_statusC1;

	$COMMIT WORK;
	return M_CM_OK;

errexit:
    sqlfatal();
    $ROLLBACK WORK;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE; 
}
/******************************************************************************/
long car993_statusC2()
{
	printf("BEGIN TO car993_status\n");    
	$BEGIN WORK;
	$WHENEVER SQLERROR GOTO errexit;

	$char stmt[600];
	
	sprintf_s(stmt, sizeof stmt,"UPDATE cm_code_data SET ncode1= to_char(year('%s')-1911)||to_char(date('%s'),'%%m%%d'), dupdate = current, iupdate = 'car993' \n"
	             " WHERE itype = '11' AND icode1 = 'CMN5136T' AND icode2 = 'C2' \n",dbgn,dbgn);
	
	$PREPARE upd_statusC2 FROM $stmt;
	$EXECUTE upd_statusC2;
	
	$COMMIT WORK;
	return M_CM_OK;

errexit:
    sqlfatal();
    $ROLLBACK WORK;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE; 
}
/******************************************************************************/
long car993_get_db()
{
	int return_code;
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	if ( (list = get_db_list(&count_db,DBName)) == (char*)0 )
	{
		EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
		return M_CM_NOT_DBLIST;
	}
	
	return_code = getApHome(sApHome);
	if (return_code < 0) 
	{
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return return_code;	
	}  
  return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}
/******************************************************************************/
int IsBlankNull(str)
char *str;
{
    while (*str)
    {
		if (*str!=' ') return FALSE;
		str++;
    }
    return TRUE;
}
/******************************************************************************/
char *get_car_full_dbname(sIpolicy)
char *sIpolicy;
{
	char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
	char sTmp_db_name[31];
	
	sTmp_db_name[0]='\0';
	if (*sIpolicy != '\0' && *sIpolicy !=' ')
	{
		sTmp_db_name[0]='\0';
		strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
		strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
		strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
	}
	return sTmp_db_name;
}
/******************************************************************************/
long car993_query()
{
    
	$char stmt1[6000];
	int rc;
	char sfilename[256],stitle[2048],stmt[500],swhere2[40];
	
	$WHENEVER SQLERROR GOTO errexit;

	$create temp table car993_tmp2(
		ipolicy     char(20), /*�O��渹*/
		dclose      date,     /*�鵲��*/
		nremark     char(100)
	)with no log;
	
	if(freview == 1)
	{
		/*���I�ܱҥΤ鬰��Ī��O��*/
		sprintf_s(swhere2, sizeof swhere2,"AND d.dply_end >= '%s'",start_date);
	}
	else
	{
		strcpy(swhere2,"");
	}
 
    for(k=0;k<count_db;k++)
    {
    	
		/*���s�bcm_ply_passbook ���O��*/
		sprintf_s(stmt1, sizeof stmt1,"INSERT INTO car993_tmp2 \n"
		              "SELECT a.ipolicy,a.dply_close,'0 : �����s�ǰe���' \n"      
		              "  FROM %s:ori_ply_relation a,%s:original_ply b,%s:ply_relation d\n"
		              " WHERE a.dply_close ='%s'      \n"
		              "   AND a.ipolicy=b.ipolicy AND a.ipolicy=d.ipolicy  %s \n"
		              "   AND a.fcard_class='2' AND b.fassured IN ('1','3','5') \n"
		              "   AND (SELECT count(*) FROM cm_ply_passbook WHERE ipolicy=a.ipolicy AND isys_source IN ('CAR','CAL'))=0 \n"
		              ,list[k].dbname,list[k].dbname,list[k].dbname,sdclose,swhere2);
				          
		$PREPARE report_1 FROM $stmt1;
		$EXECUTE report_1 ;
		printf("%s\n",stmt1);	                
		
		/*�s�b��������300���O��*/
		sprintf_s(stmt1, sizeof stmt1,"INSERT INTO car993_tmp2 \n"
		              "SELECT a.ipolicy,a.dply_close,CASE c.fstatus WHEN 100 THEN '100 : �ݶǰe' WHEN 200 THEN '200 : �ǰe��' WHEN 350 THEN '350 : ��Ʀ��~' END  \n"  
		              "  FROM %s:ori_ply_relation a,%s:original_ply b , cm_ply_passbook c,%s:ply_relation d \n" 
		              " WHERE a.dply_close ='%s'  AND c.isys_source IN ('CAR','CAL') \n" 
		              "   AND a.ipolicy=b.ipolicy AND c.ipolicy=a.ipolicy AND a.ipolicy=d.ipolicy %s \n" 
		              "   AND a.fcard_class='2' AND b.fassured IN ('1','3','5') AND c.iendorse = '' \n" 
		              "   AND c.fstatus<>300 \n" 
		              ,list[k].dbname,list[k].dbname,list[k].dbname,sdclose,swhere2);
		
		$PREPARE report_2 FROM $stmt1;
		$EXECUTE report_2 ;
		printf("%s\n",stmt1);
	
		/*���s�bcm_ply_passbook �����*/
		sprintf_s(stmt1, sizeof stmt1,"INSERT INTO car993_tmp2 \n"
		              "SELECT a.iendorse,a.dedr_close,'0 : �����s�ǰe���'\n"
		              "  FROM %s:edr_relation a,%s:endorsement b ,%s:policy_bak c ,%s:ply_relation d \n" 
		              " WHERE a.dedr_close ='%s'  \n"
		              "   AND d.dply_end >= (SELECT detail2 FROM car_code WHERE kind='PB' AND detail='001')\n"
		              "   AND a.iendorse=b.iendorse AND a.iendorse=c.iendorse AND a.ipolicy=c.ipolicy AND a.ipolicy=d.ipolicy %s   \n"
		              "   AND a.fcard_class='2' AND b.fassured IN ('1','3','5')  \n"
		              "   AND (SELECT count(*) FROM cm_ply_passbook WHERE iendorse=a.iendorse AND ipolicy=a.ipolicy)=0 \n"
		              "   AND c.fassured NOT IN ('2','4','6') \n" /*�ư����e�O�k�H��*/
		              "   AND (SELECT count(*) FROM %s:edr_relation \n" /*�w�����ߪ����s�bcm_ply_passbook�A�h�ư�*/
		              "         WHERE ipolicy=a.ipolicy AND dcreate>a.dcreate \n"
		              "           AND iendorse IN (SELECT iendorse FROM cm_ply_passbook\n" 
		              "                             WHERE ipolicy=a.ipolicy AND iendorse<>'' \n"
		              "                               AND isys_source IN ('CAR','CAL') ))=0\n"
		              ,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,sdclose,swhere2,list[k].dbname);
		
		$PREPARE report_3 FROM $stmt1;
		$EXECUTE report_3 ;
		printf("%s\n",stmt1);
	
		/*�L�������2���A�u��1�����]�n�C�X*/
		sprintf_s(stmt1, sizeof stmt1,"INSERT INTO car993_tmp2 \n"
		              "SELECT a.iendorse,a.dedr_close,'0 : �۵M�H�L���ǰe��Ưʺ|' \n"
		              "  FROM %s:edr_relation a,%s:endorsement b ,%s:policy_bak c,%s:ply_relation d  \n"
		              " WHERE a.dedr_close ='%s' \n" 
		              "   AND a.iendorse=b.iendorse AND a.iendorse=c.iendorse AND a.ipolicy=c.ipolicy AND a.ipolicy=d.ipolicy %s  \n" 
		              "   AND a.fcard_class='2' AND b.fassured IN ('1','3','5') \n"
		              "   AND (SELECT count(*) FROM cm_ply_passbook WHERE iendorse=a.iendorse AND ipolicy=a.ipolicy)=1 \n"
		              "   AND c.fassured NOT IN ('2','4','6') \n" /*�ư����e�O�k�H��*/
		              "   AND a.fedr_class IN ('2','8') \n" 
		              ,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,sdclose,swhere2);
		
		$PREPARE report_4 FROM $stmt1;
		$EXECUTE report_4 ;
		printf("%s\n",stmt1);
	
		/*�s�b��������300�����*/
		sprintf_s(stmt1, sizeof stmt1,"INSERT INTO car993_tmp2 \n"
		              "SELECT a.iendorse,a.dedr_close,CASE c.fstatus WHEN 100 THEN '100 : �ݶǰe' WHEN 200 THEN '200 : �ǰe��' WHEN 350 THEN '350 : ��Ʀ��~' END   \n" 
		              "  FROM %s:edr_relation a,%s:endorsement b , cm_ply_passbook c ,%s:ply_relation d \n" 
		              " WHERE a.dedr_close ='%s' AND a.ipolicy=c.ipolicy AND c.isys_source IN ('CAR','CAL') \n" 
		              "   AND a.iendorse=b.iendorse AND c.iendorse=a.iendorse  AND a.ipolicy=d.ipolicy %s  \n" 
		              "   AND a.fcard_class='2' AND b.fassured IN ('1','3','5') \n" 
		              "   AND c.fstatus<>300 \n" 
		              ,list[k].dbname,list[k].dbname,list[k].dbname,sdclose,swhere2);
		              
		$PREPARE report_5 FROM $stmt1;
		$EXECUTE report_5 ;
		printf("%s\n",stmt1);

	}
	
	strcpy(stmt,"SELECT * FROM car993_tmp2;");
	strcpy(sfilename,"�w�鵲���ǰe�ܫO��s�P���x���[car993]");	
	
	sprintf_s(stitle, sizeof stitle,"�w�鵲���ǰe�ܫO��s�P���x���[car993]\n\t%s\t",dclose);
	strcat(stitle,"\n");
	strcat(stitle,"\t�O��渹\t�鵲��\t���A\t");
	
	rc = unload_file(outputf," ",sfilename,stitle,stmt);
	
	if (rc != SUCCESS) 
	{
		sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
		EWRITE(userid, rc , msgbuf);
		return rc;
	}
	
	return M_CM_OK;
   
errexit:
    printf("--car993_query-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car993_prepare(v_ipolicy)
$char *v_ipolicy;
{
	$char   ipolicy_tmp[21],iendorse_tmp[21],ftype_tmp[2],fassured_o_tmp[2],iassured_o_tmp[11],dbgn_o_tmp[11];
	$char   fapplicant_n_tmp[2],iapplicant_n_tmp[11],napplicant_n_tmp[121],fassured_n_tmp[2],iassured_n_tmp[11],nassured_n_tmp[121];
	$char   dbgn_n_tmp[11],dend_n_tmp[11],fprocess_tmp[2],isys_source_tmp[4];
	$char   ntprop_cont_tmp[21],dpolicy_tmp[11],nremark_tmp[210];
	$int    linnum = 0;
	
	strcpy(ipolicy_tmp,"");
	strcpy(iendorse_tmp,"");
	strcpy(ftype_tmp,"");
	strcpy(fassured_o_tmp,"");
	strcpy(iassured_o_tmp,"");
	strcpy(dbgn_o_tmp,"");
	strcpy(fapplicant_n_tmp,"");
	strcpy(iapplicant_n_tmp,"");
	strcpy(napplicant_n_tmp,"");
	strcpy(fassured_n_tmp,"");
	strcpy(iassured_n_tmp,"");
	strcpy(nassured_n_tmp,"");
	strcpy(dbgn_n_tmp,"");
	strcpy(dend_n_tmp,"");
	strcpy(fprocess_tmp,"");
	strcpy(isys_source_tmp,"");
	strcpy(ntprop_cont_tmp,"");
	strcpy(dpolicy_tmp,"");
	strcpy(nremark_tmp,"");
    
    /*�g�Jcar993_tmp1*/
			    
	sprintf_s(stmt1, sizeof stmt1,"SELECT ipolicy,replace(iendorse,'-D',''),ftype,fassured_o,iassured_o,dbgn_o, \n"
	              "       fapplicant_n,iapplicant_n,napplicant_n, \n"
	              "       fassured_n,iassured_n,nassured_n, \n"
	              "       dbgn_n,dend_n,fprocess,isys_source, \n"
	              "       ntprop_cont,dwritten,nremark \n"
	              "  FROM sysdb:cm_ply_passbook \n"
	              " WHERE ipolicy = '%s' ORDER BY CAST (iserno AS INTEGER) \n" ,v_ipolicy);
    
    $PREPARE CUR_NEWEST FROM $stmt1;
    $DECLARE cur_edr2 CURSOR FOR CUR_NEWEST;
    $OPEN cur_edr2 ;
		
	while (1)
	{
		$FETCH cur_edr2 INTO $ipolicy_tmp,      $iendorse_tmp,     $ftype_tmp,        $fassured_o_tmp,   $iassured_o_tmp, $dbgn_o_tmp,
		                     $fapplicant_n_tmp, $iapplicant_n_tmp, $napplicant_n_tmp, 
		                     $fassured_n_tmp,   $iassured_n_tmp,   $nassured_n_tmp,
		                     $dbgn_n_tmp,       $dend_n_tmp,       $fprocess_tmp,     $isys_source_tmp,
		                     $ntprop_cont_tmp,  $dpolicy_tmp,      $nremark_tmp;

		if (SQLCODE == SQLNOTFOUND) break;
		
		if (strcmp(fprocess_tmp,"A") == 0)
		{
			$SELECT CASE count(*) WHEN 0 THEN 1 ELSE max(linnum)+1 END
			   INTO $linnum
			   FROM car993_tmp1
			  WHERE ipolicy = $v_ipolicy;
	
			$INSERT INTO car993_tmp1
			      VALUES ($ipolicy_tmp,      $iendorse_tmp,     $ftype_tmp,
			              $fapplicant_n_tmp, $iapplicant_n_tmp, $napplicant_n_tmp, 
			              $fassured_n_tmp,   $iassured_n_tmp,   $nassured_n_tmp,
			              $dbgn_n_tmp,       $dend_n_tmp,       $isys_source_tmp,
			              $ntprop_cont_tmp,  $dpolicy_tmp,      $nremark_tmp,      $linnum);
		}
		else if (strcmp(fprocess_tmp,"U") == 0)
		{
			$UPDATE car993_tmp1
			    SET iendorse = $iendorse_tmp,
			        ftype = $ftype_tmp,
			        fapplicant_n = $fapplicant_n_tmp,
			        iapplicant_n = $iapplicant_n_tmp,
			        napplicant_n = $napplicant_n_tmp,
			        fassured_n = $fassured_n_tmp,
			        iassured_n = $iassured_n_tmp,
			        nassured_n = $nassured_n_tmp,
			        dbgn_n = $dbgn_n_tmp, 
			        dend_n = $dend_n_tmp,
			        isys_source = $isys_source_tmp,
			        ntprop_cont = $ntprop_cont_tmp, 
			        dpolicy = $dpolicy_tmp,
			        nremark = $nremark_tmp
			  WHERE ipolicy    = $ipolicy_tmp
			    AND fassured_n = $fassured_o_tmp
			    AND iassured_n = $iassured_o_tmp
			    AND dbgn_n     = $dbgn_o_tmp;
		}
		else if(strcmp(fprocess_tmp,"D") == 0)
		{
			$DELETE FROM car993_tmp1
			  WHERE ipolicy    = $ipolicy_tmp
			    AND fassured_n = $fassured_o_tmp
			    AND iassured_n = $iassured_o_tmp
			    AND dbgn_n     = $dbgn_o_tmp;
		}
	}
	$CLOSE cur_edr2;
	$FREE cur_edr2;

   return M_CM_OK;
  
errexit:
    /*printf("--car993_prepare-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;*/
}
/******************************************************************************/
long car993_createtmp()
{   
	$WHENEVER SQLERROR GOTO errexit;
	     	  	   
	$create temp table car993_tmp1(
	    ipolicy      char(20), /*�O�渹*/
	    iendorse     char(20), /*��渹*/
	    ftype        char(1),  /*P:�ȥ� E:�q�l*/
	    fapplicant_n char(1),     
	    iapplicant_n char(10),
	    napplicant_n varchar(120),
	    fassured_n   char(1),    
	    iassured_n   char(10),
	    nassured_n   varchar(120),
	    dbgn_n       date,
	    dend_n       date,
	    isys_source  char(3),
	    ntprop_cont  char(20),
	    dpolicy      date,
	    nremark      char(210),
	    linnum       int
	)with no log;
	$create unique index car993_tmp1_ix_1 on car993_tmp1(fassured_n,iassured_n,dbgn_n);   
	    
	return M_CM_OK;

errexit:
    printf("--car993_createtmp-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}   

/******************************************************************************/
long car993_check_unload()
{
    
	$char stmt1[6000];
	int   rc,rt;
	char  sfilename[256],stmt[500];
	FILE  *fptr1;
	$char ipolicy[21],dclose[11],nremark[100];
	char  sTitle[300],file1[500],outputf1[100],errmsg[100],prtstr1[500];
	
	$WHENEVER SQLERROR GOTO errexit;
	
	$create temp table car993_tmp2( 
	    dclose      date,     /*�鵲��*/
	    nremark     char(10)
	)with no log;

	for(k=0;k<count_db;k++)
	{
    	/*���s�bcm_ply_passbook ���O��*/
		sprintf_s(stmt1, sizeof stmt1,"INSERT INTO car993_tmp2 \n"
		              "SELECT a.dply_close,count(*) \n"      
		              "  FROM %s:ori_ply_relation a,%s:original_ply b, %s:ply_relation c\n"
		              " WHERE a.dply_close >= (SELECT detail2 FROM car_code WHERE kind='PB' AND detail='001')  \n"
		              "   AND a.dply_close >= today-45 AND a.dpolicy>= today-45"
		              "   AND c.dply_end >= (SELECT detail2 FROM car_code WHERE kind='PB' AND detail='001')"
		              "   AND a.dply_close < today-5"
		              "   AND a.ipolicy=b.ipolicy AND a.ipolicy=c.ipolicy \n"
		              "   AND a.fcard_class='2' AND b.fassured IN ('1','3','5') \n"
		              "   AND (SELECT count(*) FROM cm_ply_passbook WHERE iins_cat='C' AND ipolicy=a.ipolicy)=0 \n"
		              " GROUP BY 1 \n"
		              ,list[k].dbname,list[k].dbname,list[k].dbname);
                      
		printf("[1]���s�bcm_ply_passbook ���O��:%s\n",stmt1);			          
		$PREPARE check_1 FROM $stmt1;
		$EXECUTE check_1 ;
		                

        /*�s�b��������300���O��*/
		sprintf_s(stmt1, sizeof stmt1,"INSERT INTO car993_tmp2 \n"
		              "SELECT a.dply_close,count(*)  \n"  
		              "  FROM %s:ori_ply_relation a,%s:original_ply b , cm_ply_passbook c \n" 
		              " WHERE a.dply_close >= (SELECT detail2 FROM car_code WHERE kind='PB' AND detail='001') \n" 
		              "   AND a.dply_close >= today-45 AND a.dpolicy>= today-45 "
		              "   AND a.dply_close < today-5"
		              "   AND a.ipolicy=b.ipolicy AND c.ipolicy=a.ipolicy AND c.iendorse=''\n" 
		              "   AND a.fcard_class='2' AND b.fassured IN ('1','3','5') \n" 
		              "   AND c.fstatus<>300 AND iins_cat='C'\n" 
		              " GROUP BY 1"
		              ,list[k].dbname,list[k].dbname);
                      
		printf("[2]�s�b��������300���O��:%s\n",stmt1);
		$PREPARE check_2 FROM $stmt1;
		$EXECUTE check_2 ;

        /*���s�bcm_ply_passbook �����*/
		sprintf_s(stmt1, sizeof stmt1,"INSERT INTO car993_tmp2 \n"
		              "SELECT a.dedr_close,count(*) \n"
		              "  FROM %s:edr_relation a,%s:endorsement b ,%s:policy_bak c ,%s:ply_relation d \n" 
		              " WHERE a.dedr_close >= (SELECT detail2 FROM car_code WHERE kind='PB' AND detail='001') \n"
		              "   AND a.dedr_close >= today-45 AND a.dendorse >= today-45"
		              "   AND d.dply_end >= (SELECT detail2 FROM car_code WHERE kind='PB' AND detail='001') \n"
		              "   AND a.dedr_close < today-5"
		              "   AND a.iendorse=b.iendorse AND a.iendorse=c.iendorse AND a.ipolicy=d.ipolicy \n"
		              "   AND a.fcard_class='2' AND b.fassured IN ('1','3','5') \n"
		              "   AND (SELECT count(*) FROM cm_ply_passbook WHERE iins_cat='C' AND ipolicy=c.ipolicy AND iendorse=a.iendorse)=0 \n"
		              "   AND c.fassured NOT IN ('2','4','6') \n" /*�ư����e�O�k�H��*/
		              "   AND a.fedr_class NOT IN ('2','8') "
		              " GROUP BY 1"
		              ,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname);

		printf("[3]���s�bcm_ply_passbook �����:%s\n",stmt1);
		$PREPARE check_3 FROM $stmt1;
		$EXECUTE check_3 ;

		/*�L�������2���A�u��1�����]�n�C�X*/
		sprintf_s(stmt1, sizeof stmt1,"INSERT INTO car993_tmp2 \n"
		              "SELECT a.dedr_close,count(*) \n"
		              "  FROM %s:edr_relation a,%s:endorsement b ,%s:policy_bak c  \n"
		              " WHERE a.dedr_close >= (SELECT detail2 FROM car_code WHERE kind='PB' AND detail='001') \n"
		              "   AND a.dedr_close >= today-45 AND a.dendorse >= today-45"
		              "   AND a.dedr_close < today-5"
		              "   AND a.iendorse=b.iendorse AND a.iendorse=c.iendorse \n" 
		              "   AND a.fcard_class='2' AND b.fassured IN ('1','3','5') \n"
		              "   AND (SELECT count(*) FROM cm_ply_passbook WHERE iins_cat='C' AND ipolicy=a.ipolicy AND iendorse=a.iendorse)<2 \n"
		              "   AND c.fassured NOT IN ('2','4','6') \n" /*�ư����e�O�k�H��*/
		              "   AND a.fedr_class IN ('2','8') \n" 
		              " GROUP BY 1"
		              ,list[k].dbname,list[k].dbname,list[k].dbname);

		printf("[4]�L�������2���A�u��1�����]�n�C�X:%s\n",stmt1);
		$PREPARE check_4 FROM $stmt1;
		$EXECUTE check_4 ;

		/*�s�b��������300�����*/
		sprintf_s(stmt1, sizeof stmt1,"INSERT INTO car993_tmp2 \n"
		              "SELECT a.dedr_close,count(*)   \n" 
		              "  FROM %s:edr_relation a,%s:endorsement b , cm_ply_passbook c \n" 
		              " WHERE a.dedr_close >= (SELECT detail2 FROM car_code WHERE kind='PB' AND detail='001') \n" 
		              "   AND a.dedr_close >= today-45 AND a.dendorse >= today-45 "
		              "   AND a.dedr_close < today-5 "
		              "   AND a.iendorse=b.iendorse AND c.iendorse=a.iendorse  AND a.ipolicy=c.ipolicy\n" 
		              "   AND a.fcard_class='2' AND b.fassured IN ('1','3','5') \n" 
		              "   AND c.fstatus<>300 AND c.iins_cat='C'\n" 
		              " GROUP BY 1"
		              ,list[k].dbname,list[k].dbname);
                    
		printf("[5]�s�b��������300�����:%s\n",stmt1);  
		$PREPARE check_5 FROM $stmt1;
		$EXECUTE check_5 ;
	}
    
    
	sprintf_s(sTitle, sizeof sTitle,"%s","�鵲��\t���W�ǵ���");
	
	strcpy(outputf1,"car993_check_unload.txt");
	sprintf_s(file1, sizeof file1,"%s/rptftp/%s",sApHome,outputf1);
	rt = rptftpinsert(userid,"car993",outputf1);
	if (rt != 0){
		printf("rptftp error\n");
		goto errexit;
	}
	printf("file1=[%s]\n", file1 );
	if ((fptr1=fopen(file1,"w")) == NULL){
		sprintf_s(errmsg, sizeof errmsg,"Cannot open print file: %s",file1);
		return M_CM_OPEN_FILE_FAIL;
	}

	fprintf(fptr1,"%s\n",sTitle);
	count_unload=0;
	
	strcpy(stmt1,"SELECT dclose ,sum(CAST (nremark AS integer))  FROM car993_tmp2 GROUP BY 1 ORDER BY dclose;");
	
	$PREPARE  pre_chk_unload FROM $stmt1;
	$DECLARE  cur_chk_unload CURSOR FOR pre_chk_unload;
	$OPEN     cur_chk_unload ;
	
	while (1)
	{
		$FETCH cur_chk_unload INTO $dclose, $nremark;
		
		if(SQLCODE == SQLNOTFOUND) break;
		
		strcpy(prtstr1,"");
		
		strcat(prtstr1,rtrim(dclose));
		strcat(prtstr1,"\t");
		strcat(prtstr1,rtrim(nremark));
		
		fprintf(fptr1,"%s\n",prtstr1);
		
		count_unload++;
	}
	$CLOSE cur_chk_unload;
	$FREE  cur_chk_unload;
	
	fclose(fptr1);
	
	return M_CM_OK;
   

errexit:
	printf("--car993_query-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

/* 1111104007_SC1_�s�W�O��s�P�ǰe���γW�h */
long insert_cm_ply_passbook_dtl(v_sDB,v_ipolicy,v_iendorse,v_iserno,v_iassured,v_icar_type,fcover)
$char *v_sDB,*v_ipolicy,*v_iendorse,*v_iserno,*v_iassured,*v_icar_type,*fcover;
{
	$int  iins_sno,rc;
	$char iendorse_next[21],itype_dtl[2];
	/* ���S���U�@�i��� */
	strcpy(iendorse_next, " ");
	if (strcmp(trim(v_iendorse),"") == 0)
		strcpy(itype_dtl,"1");
	else 
	{
		rc = get_next_iendorse(v_sDB,v_ipolicy,v_iendorse,iendorse_next,itype_dtl);
		if (rc != M_CM_OK) return rc;

		if (iendorse_next[0] == '\0' || iendorse_next[0] == ' ') strcpy(iendorse_next, " ");
	}
	
	if (itype_dtl[0] == '1')
	{
		sprintf_s(stmt1, sizeof stmt1,"SELECT iins_type FROM %s:ori_ins_type WHERE ipolicy = '%s' ",v_sDB,v_ipolicy);
	}
	else if (itype_dtl[0] == '2')
	{
		sprintf_s(stmt1, sizeof stmt1,"SELECT iins_type FROM %s:ply_ins_type_bak WHERE ipolicy = '%s' AND iendorse = '%s' ",v_sDB,v_ipolicy,iendorse_next);
	}
	else if (itype_dtl[0] == '3')
	{
		sprintf_s(stmt1, sizeof stmt1,"SELECT iins_type FROM %s:ply_ins_type WHERE ipolicy = '%s' ",v_sDB,v_ipolicy);
	}
	printf("stmt1[%s]\n",stmt1);
	$PREPARE CUR_PLY_DTL FROM $stmt1;
	$DECLARE cur_ply_dtl1 CURSOR FOR CUR_PLY_DTL;
	$OPEN cur_ply_dtl1;
	
	printf("v_iserno[%s]\n",v_iserno);
	
	iins_sno = 1;
	while(1)
	{
		$FETCH cur_ply_dtl1 INTO $iins_type;
		if (SQLCODE == SQLNOTFOUND) break;

		rtn = get_ply_ins_dtl(itype_dtl, v_ipolicy, iendorse_next, v_icar_type, iins_type, nins_type, edomain, cover_print1, ncover1, ndeduct, cover_print2, ncover2, cover_print3, ncover3, cover_print4, ncover4, n_ins_premium, v_sMsg);
		
		printf(" rtn[%d]\n ",rtn);
		strcpy(fmark0," ");
		strcpy(fmark1," ");
		strcpy(fmark2," ");
		strcpy(fmark3," ");
		printf("iins_sno[%d] \n",iins_sno);
		printf("nins_type[%s], edomain[%s], cover_print1[%s], ncover1[%s], ndeduct[%s], cover_print2[%s], ncover2[%s], cover_print3[%s], ncover3[%s], cover_print4[%s], ncover4[%s] \n",
		        nins_type, edomain, cover_print1, ncover1, ndeduct, cover_print2, ncover2, cover_print3, ncover3, cover_print4, ncover4);

		/* �I�ئW�٩ΰӫ~�W�� */
		strcpy(iins_type,trim(iins_type));
		strcpy(nins_type,trim(nins_type));
		sprintf_s(niins_name, sizeof niins_name,"%s %s",iins_type,nins_type);
		
		/* �I�ؤ��e���� */
		strcpy(cover_print1,trim(cover_print1));
		strcpy(cover_print2,trim(cover_print2));
		strcpy(cover_print3,trim(cover_print3));
		strcpy(cover_print4,trim(cover_print4));
		strcpy(ndeduct,trim(ndeduct));
		strcpy(ncover1,trim(ncover1));
		strcpy(ncover2,trim(ncover2));
		strcpy(ncover3,trim(ncover3));
		strcpy(ncover4,trim(ncover4));
		
		cnt_ins_dollor = 0;
		$SELECT count(*) 
		   INTO $cnt_ins_dollor 
		   FROM insurance_type
		  WHERE iins_type = $iins_type 
		    AND iins_type NOT IN ('15','38','39','238');
		
		printf("fcover[%s] \n",fcover);
		
		/* cover_print1 */
		strcpy(fmark0,";");
		if (cover_print1[0] == '' || cover_print1[0] == '\0')
		{
			if (ncover1[0] == '' || ncover1[0] == '\0')
			{
				strcpy(cover_print1,"");
				strcpy(ncover1,"");
				strcpy(fmark0,"");
			}
			else
			{ 
				if (fcover[0] == '1') strcpy(ncover1,"0");
				strcpy(cover_print1,"�O�B: ");
			}
		}
		else  
		{
			strcat(cover_print1," ");
			if (fcover[0] == '1') strcpy(ncover1,"0");
		}
		
		/* cover_print2 */
		if (cover_print2[0] == '' || cover_print2[0] == '\0')
		{
			if (ncover2[0] == '' || ncover2[0] == '\0')
			{
				strcpy(cover_print2,"");
				strcpy(ncover2,"");
			}
			else
			{
				if (fcover[0] == '1') strcpy(ncover2,"0");
				strcpy(cover_print2,"�O�B: ");
			}
		}
		else 
		{
			strcat(cover_print2," ");
			if (fcover[0] == '1') strcpy(ncover2,"0");
		}

		
		/* cover_print3 */
		if (cover_print3[0] == '' || cover_print3[0] == '\0')
		{
			if (ncover3[0] == '' || ncover3[0] == '\0')
			{
				strcpy(cover_print3,"");
				strcpy(ncover3,"");
			}
			else 
			{
				if (fcover[0] == '1') strcpy(ncover3,"0");
				strcpy(cover_print3,"�O�B: ");
			}
		}
		else 
		{
			strcat(cover_print3," ");
			if (fcover[0] == '1') strcpy(ncover3,"0");
		}

		/* cover_print4 */
		if (cover_print4[0] == '' || cover_print4[0] == '\0')
		{
			if (ncover4[0] == '' || ncover4[0] == '\0')
			{
				sprintf_s(cover_print4, sizeof cover_print4,"");
				sprintf_s(ncover4, sizeof ncover4,"");
			}
			else 
			{
				if (fcover[0] == '1') strcpy(ncover4,"0");
				strcpy(cover_print4,"�O�B: ");
			}
		}
		else 
		{
			strcat(cover_print4," ");
			if (fcover[0] == '1') strcpy(ncover4,"0");
		}

		printf("cnt_ins_dollor[%d]",cnt_ins_dollor);
		if (ncover1[0] == '' || ncover1[0] == '\0') {}
		else  
		{
			if (cnt_ins_dollor > 0) strcat(ncover1,"��");
		}
		
		if (ncover2[0] == '' || ncover2[0] == '\0') {}
		else  
		{
			strcpy(fmark1,"!");
			if (cnt_ins_dollor > 0) strcat(ncover2,"��");
		}
		
		if (ncover3[0] == '' || ncover3[0] == '\0') {}
		else  
		{
			strcpy(fmark2,"!");
			if (cnt_ins_dollor > 0) strcat(ncover3,"��");
		}
		
		if (ncover4[0] == '' || ncover4[0] == '\0') {}
		else  
		{
			strcpy(fmark3,"!");
			if (cnt_ins_dollor > 0) strcat(ncover4,"��");
		}
		
		printf("ncover1[%s] \n ",ncover1);
		printf("ncover2[%s] \n ",ncover2);
		printf("ncover3[%s] \n ",ncover3);
		printf("ncover4[%s] \n ",ncover4);
		
		if (ndeduct[0] == '' || ndeduct[0] == '\0')
			sprintf_s(nins_type_tmp1, sizeof nins_type_tmp1,"%s%s%s",cover_print1,ncover1,fmark0,ndeduct);
		else 
			sprintf_s(nins_type_tmp1, sizeof nins_type_tmp1,"%s%s%s�ۭt�B:%s",cover_print1,ncover1,fmark0,ndeduct);
		sprintf_s(nins_type_tmp2, sizeof nins_type_tmp2,"%s%s",cover_print2,ncover2);
		sprintf_s(nins_type_tmp3, sizeof nins_type_tmp3,"%s%s",cover_print3,ncover3);
		sprintf_s(nins_type_tmp4, sizeof nins_type_tmp4,"%s%s",cover_print4,ncover4);
		
		printf("nins_type_tmp1[%s] \n ",nins_type_tmp1);
		printf("nins_type_tmp2[%s] \n ",nins_type_tmp2);
		printf("nins_type_tmp3[%s] \n ",nins_type_tmp3);
		printf("nins_type_tmp4[%s] \n ",nins_type_tmp4);

		sprintf_s(niins_cont, sizeof niins_cont,"%s%s%s%s%s%s%s",nins_type_tmp1,fmark1,nins_type_tmp2,fmark2,nins_type_tmp3,fmark3,nins_type_tmp4);

		$INSERT INTO sysdb:cm_ply_passbook_dtl 
		             (iins_cat,  ipolicy,   iendorse,    iserno,    iassured_o, iins_sno, niins_name, niins_cont)
		       VALUES('C',    $v_ipolicy,$v_iendorse, $v_iserno, $v_iassured  ,$iins_sno,$niins_name,$niins_cont);
		
		printf(" INNNNNN\n ");	
		iins_sno ++;
	}
	
	return M_CM_OK;
	
errexit:
    printf("--insert dtl-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

long get_next_iendorse(v_sDB,v_ipolicy,v_iendorse,v_iendorse_next,v_itype)
$char *v_sDB,*v_ipolicy,*v_iendorse,*v_iendorse_next,*v_itype;
{
	$char iendorse_next_tmp[20];
	
	sprintf_s(stmt1, sizeof stmt1,"SELECT first 1 NVL(iendorse,' ') \
	                 FROM %s:edr_relation \
	                WHERE ipolicy = '%s' AND iendorse <> '%s' \
	                  AND dcreate > (SELECT dcreate FROM %s:edr_relation WHERE iendorse = '%s') \
	                  AND iendorse NOT LIKE '%%CVP%%' AND fcard_class = '2' \
	                ORDER BY dcreate",v_sDB,v_ipolicy,v_iendorse,v_sDB,v_iendorse);
	printf("stmt1[%s]\n",stmt1);
	$PREPARE edr_next FROM $stmt1;
	$EXECUTE edr_next INTO $iendorse_next_tmp;
	
	if (SQLCODE == SQLNOTFOUND)
	{
		strcpy(v_iendorse_next," ");
		strcpy(v_itype,"3");
	}
	else 
	{
		strcpy(v_iendorse_next,iendorse_next_tmp);
		strcpy(v_itype,"2");
	}

	return M_CM_OK;
	
errexit:
    printf("--insert dtl-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}