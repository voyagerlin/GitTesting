/**********************************************************************/
/*   program id   : ca354q01s.ec                                      */
/*   program name : ����w��O�����J�@�~                            */
/*   date written : 2021/03/17                                        */
/*   author       : 061476                                            */                                     
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "safeclib.h"

/*--------------------------------------------------------------------*/
char   msgbuf[1024];
char   sApHome[30];
$char  DBName[05];
$char  userid[11];
$char  ply_ym[6],dyear[4],dmonth[3],del_ym[6];
$int   iplyyear,iplymonth;
char   filename[200];
int    flen;
FILE   *fp;
$char  sdata[2][61];
int    qcnt,qcnt1;
$char  GetFileName[80];
char   outputf[N_FILE+1];
/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{  
	int 	return_code,rc;

	batchinit();
	strcpy(DBName, 		  isNULLstr(argv[1]));
	strcpy(userid, 		  isNULLstr(argv[2]));
	strcpy(dyear,             isNULLstr(argv[3]));
	strcpy(dmonth,            isNULLstr(argv[4]));
	strcpy(GetFileName,       isNULLstr(argv[5]));
	strcpy(del_ym,            isNULLstr(argv[6]));
	strcpy(outputf,		  isNULLstr(argv[7]));
	
	printf("GetFileName[%s]\n",GetFileName);
	
	strcpy(dyear,trim(dyear));
	iplyyear = atoi(dyear);
	iplyyear += 1911;
	iplymonth = atoi(dmonth);
	sprintf_s(ply_ym, sizeof ply_ym,"%s%02d",dyear,iplymonth);
	
	return_code = car354_get_db();
	if (return_code != M_CM_OK) {
		EWRITE(userid,return_code,msgbuf);
		return return_code;
	}
	
	/* create tmp table */
	return_code = car354_create_tmp_table();
	if (return_code != M_CM_OK) 
	{
		rc = return_code;   	
		EWRITE(userid,return_code,msgbuf);
		return rc;
	}
		
	/* �U��policy_302f����� */
	return_code = car354_get302f();
	if (return_code != M_CM_OK) 
	{
		rc = return_code;   	
		EWRITE(userid,return_code,msgbuf);
		return rc;
	}
	
	/* Ū����J�ɮ׸�� */
	return_code = car354_read_data();
	if (return_code != M_CM_OK) 
	{
		rc = return_code;   	
		EWRITE(userid,return_code,msgbuf);
		return rc;
	}
	
	/* �g�Jca_renew_jb */	
	return_code = car354_insert_data();
	if (return_code != M_CM_OK) 
	{
		rc = return_code;   	
		EWRITE(userid,return_code,msgbuf);
		return rc;
	}
	
	/* �M�ɡG�R���W�L�@�~����� */		
	return_code = car354_delete_data();
	if (return_code != M_CM_OK) 
	{
		rc = return_code;   	
		EWRITE(userid,return_code,msgbuf);
		return rc;
	}
	
	/* ���Ϳ��~���� */			
	return_code = car354_unload();
	if (return_code != M_CM_OK) 
	{
		rc = return_code;   	
		EWRITE(userid,return_code,msgbuf);
		return rc;
	}
	
	return return_code;
}
/*--------------------------------------------------------------------*/
long car354_read_data()
{
    char   *bp;
    FILE   *fp;
    int    i,j,k,m;
    int    flen,rc;

    printf("BEGIN TO READ DATA\n");    

    $whenever sqlerror goto errexit;

    strcpy(GetFileName, trim(GetFileName));
    sprintf_s(filename, sizeof filename,"%s/dat/car/%s",sApHome,GetFileName);
    flen = 1024;
        
    if ((fp=fopen(filename,"r"))==NULL) {
    	sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���",filename);
    	EWRITE(userid,FALSE,msgbuf);
    	return FALSE;
    }
    if ((bp=malloc(flen))==NULL) {
    	sprintf_s(msgbuf, sizeof msgbuf,"System malloc failed !");
    	EWRITE(userid,FALSE,msgbuf);
    	return FALSE;
    }
    		
    for(i=0;(feof(fp)==0);i++) {
    	memset(bp,0x00,flen);
    	fgets(bp,flen,fp);
    	if (bp[0] == 0x00) break;
    	for(j=0;j<2;j++) sdata[j][0]='\0';
    	k = m = 0;
    	
    	for (j=0;j<flen;j++) {
    		if (bp[j] == '\t' || bp[j] == '\0' || bp[j] == '\n') {
    			strncpy(sdata[k],bp+m,j-m);
    			sdata[k][j-m]='\0';
    			m = j+1;
    			k++;
    		}
    		if (bp[j] == '\n') break;
    		if (k > 2) break;
    	} 
   	
    	rc = car354_insert_tmp_table();
    	if (rc != M_CM_OK)
    		return rc;
   }
          
   fclose(fp);
    free(bp);

   sprintf_s(msgbuf, sizeof msgbuf,"�B�z����[%d]",i);
   return M_CM_OK;
	  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;        
}
/*--------------------------------------------------------------------*/
long car354_create_tmp_table()
{
	$whenever sqlerror goto errexit;
	
	$create temp table car354
	(dply_ym        char(5),
	 ipolicy        char(20),
	 irelative_ply  char(20),
	 itag           char(12)
	)with no log;
	
	$create temp table car354_302f
	(ipolicy        char(20),
	 irelative_ply  char(20),
	 itag           char(12)
	)with no log;
	
	$create temp table car354_err
	(ipolicy        char(20)
	)with no log;
	
	return M_CM_OK;
errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car354_get302f()
{
	$char  sdate1[11],sdate2[11];
	$char  stmt1[256];
	
	$whenever sqlerror goto errexit;
	
	/* �̰_���~���_����� */
	$select first 1 MDY($iplymonth,'01',$iplyyear),add_months(MDY($iplymonth,'01',$iplyyear),1)-1
	   into $sdate1, $sdate2
	   from car_code;
	printf("sdate1[%s]sdate2[%s]\n",sdate1,sdate2);
	
	$insert into car354_302f
	 select ipolicy, irelative_ply, itag
	   from policy_302f
	  where iroute = 'JB'
	    and dply_begin between $sdate1 and $sdate2; 
	
	return M_CM_OK;
	
errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car354_insert_tmp_table()
{
	$char ipolicy[21], itag[CA_TAG_NUM];
	$char irelative_ply[21];
	
	$whenever sqlerror goto errexit;

	strcpy(ipolicy       ,trim(sdata[0]));
	strcpy(itag          ,trim(sdata[1]));
	
	$select nvl(irelative_ply,'')
	   into $irelative_ply
	   from car354_302f
	  where ipolicy = $ipolicy;
	
	if (SQLCODE == SQLNOTFOUND) strcpy(irelative_ply,"");
	
	$insert into car354 values ($ply_ym,$ipolicy,$irelative_ply,$itag);
	
	return M_CM_OK;
	
errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car354_insert_data()
{
	$int   cnt=0, i=0, no_del=0;
	$char  stmt[1024], stmt1[256], stmt2[256], stmt3[256], sMsg[256];
	$char  dym[6], sipolicy[21], sirelative_ply[21], sitag[CA_TAG_NUM];
	$char  tmpid[16];
	
	$whenever sqlerror goto errexit;	
	$BEGIN WORK;
	
	sprintf_s(stmt, sizeof stmt, " select dply_ym, ipolicy, irelative_ply, itag from car354; \n");
	$prepare cur_01 from $stmt;
 	$declare cur_main CURSOR FOR cur_01;
 	$OPEN cur_main;        
        while(1)
        {
        	$FETCH cur_main INTO $dym, $sipolicy, $sirelative_ply, $sitag;
        	strcpy(dym,trim(dym));
        	strcpy(sipolicy,trim(sipolicy));
        	strcpy(sirelative_ply,trim(sirelative_ply));
        	strcpy(sitag,trim(sitag));
	        
 	        if (SQLCODE == SQLNOTFOUND) break;       
 	        
 	        sprintf_s(stmt1, sizeof stmt1, " select count(*)       \n"
 	                       "   from car354_302f    \n"
 	                       "  where ipolicy = '%s' \n"
 	                       "    and itag = '%s';   \n",sipolicy,sitag);
 	        
 	        $prepare cnt_ply from $stmt1;
 	        $execute cnt_ply into $cnt;
 
 	        if (cnt > 0){	        	
 	        	$select count(*) into $cnt
 	        	   from ca_renew_jb
 	        	  where ipolicy = $sipolicy;
 	        	
 	        	if (cnt == 0)
 	        	{
 	        		sprintf_s(stmt2, sizeof stmt2, " INSERT INTO ca_renew_jb (dply_ym, ipolicy, icreate, dcreate) \n"
 	        		               " VALUES ('%s', '%s', '%s', current); \n",dym,sipolicy,userid);
 	        		
 	        		$prepare insert_ply from $stmt2;
 	        		$execute insert_ply;
 	        		
 	        		if (strlen(trim(sirelative_ply))>0)
 	        		{
 	        			$select count(*) into $cnt
 	        			   from ca_renew_jb
 	        			  where ipolicy = $sirelative_ply;
 	        			  
 	        			if (cnt == 0)
 	        			{
 	        			    sprintf_s(stmt3, sizeof stmt3, " INSERT INTO ca_renew_jb (dply_ym, ipolicy, icreate, dcreate) \n"
 	        			                   " VALUES ('%s', '%s', '%s', current); \n",dym,sirelative_ply,userid);
 	        			   
 	        			    $prepare insert_ply2 from $stmt3;
 	        			    $execute insert_ply2;
 	        			}
 	        		}
 	        	}       	       			
 	        }else
 	        	$insert into car354_err values ($sipolicy);
 	            
        }
        $CLOSE cur_main;
        $FREE cur_main;
	
	$select count(*) into $no_del
	   from car354_302f
	  where ipolicy not in (select ipolicy from ca_renew_jb 
	                         where dply_ym = $dym);
	
	sprintf_s(sMsg, sizeof sMsg,"�@%d������O",no_del);
	$insert into car354_err values ($sMsg);
	
		
	$COMMIT WORK; 
	return M_CM_OK;
	
errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   $ROLLBACK WORK;
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car354_delete_data()
{
	$whenever sqlerror goto errexit;
	
	$delete from ca_renew_jb where dply_ym = $del_ym;
	
	return M_CM_OK;
	
errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car354_unload()
{
	char  sfilename[41],stitle[200],stmt[1024];
	$char stmt1[1024];
	int   rc,j;
	int   iflag;
	char  n1[2],n2[2],n3[2],n4[2];
	
	$whenever sqlerror goto errexit;
	
	strcpy(sfilename,"��J��ƵL��O�J�p���Ӫ�");
	strcpy(stitle,"�O�渹�X");
	 	
	strcpy(stmt,"select ipolicy from car354_err; ");
	
	rc = unload_file(outputf," ",sfilename,stitle,stmt);
	if (rc != SUCCESS)
	{
		sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
		EWRITE(userid, rc , msgbuf);
		return rc;
	}
	return M_CM_OK;
	
errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car354_get_db()
{
	int return_code;

	if (db_select(DBName) == False) {
		strcpy(msgbuf,"M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	return_code = getApHome(sApHome);
	if (return_code < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return return_code;
  }

  return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/