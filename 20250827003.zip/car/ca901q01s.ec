/************************************************************************/
/*                                                                      */   
/*   program id   : ca901q01s.ec                                        */
/*   program name : ���ץ�Ƥ��R��                                      */
/*   date written : 2002/10/16                                          */
/*   author       : neo                                                 */
/************************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"

/*--------------------------------------------------------------------*/
DBinfo  *list;
int  count_db, i;
static int max_cnt;

$char DBName[05], iForm_Tp[03];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1]; 
char  outputf[N_FILE+1], userid[11];

char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;
$char FormTp[3];

$char dbgn[7], dend[7];
$char dbgn_yy[4], dbgn_mm[3], dend_yy[4], dend_mm[3];
$long l_dbgn, l_dend;

$char Total_sum_c[8], option[2];
$int  Total_sum;


$char   Iclaim_3[4], Iclaim[20], Iins_type[7], Fcard_class[2];
$char   Iacc_reason[3], Iadjuster[10], Iadjuster_name[12], Icoclaim[2];

$int    check_01, check_32, check_93, check_21, check_11, check_12, check_with_21;

$int    with_21_tot=0;
$int    check_21_tot=0;
$int    check_with_21_tot=0;

$int    only_01,  only_11,  only_12,  only_21,  only_32,  only_93,  dam01_lia32;
$long   only_01_app,  only_11_app,  only_12_app,  only_21_app,  only_32_app,  only_93_app,  dam01_lia32_app;
$long   only_01_stl,  only_11_stl,  only_12_stl,  only_21_stl,  only_32_stl,  only_93_stl,  dam01_lia32_stl;
$int    other_iins;
$long   other_iins_app;
$long   other_iins_stl;
$int    only_93_rel;
$int    only_93_rel_app;
$long   only_93_rel_stl;
$int    dam01_inj93, dam01_lia32_inj93, dam01_lia32_inj21, lia32_inj93, lia32_inj21;
$long   dam01_inj93_app, dam01_lia32_inj93_app, dam01_lia32_inj21_app, lia32_inj93_app, lia32_inj21_app;
$long   dam01_inj93_stl, dam01_lia32_inj93_stl, dam01_lia32_inj21_stl, lia32_inj93_stl, lia32_inj21_stl;
$int    with_21;
$long   with_21_app;
$long   with_21_stl;
$long   Mins_app_tot;
$long   Mins_stl_tot;
$char Iclaim_2[3];
$char iclaim_2[3] , iadjuster[11] , iclaim[21];
$int  iclose_type=0;
$char xfpay_cond[2],xsettle_type[2],nchi_full[23];

$long   TEST_COUNT = 0;
$long   Mins_app;
$int    tmp_count;

long car901_build();
long car901_title();
long car901_body();
void car901_print();
long car901_build1();
long car901_body1();

/*--------------------------------------------------------------------*/

main(argc,argv)
int  argc;
char **argv;
{  
   
   int rc;
   batchinit();
   strcpy(DBName,   isNULLstr(argv[1]));
   strcpy(userid,   isNULLstr(argv[2]));
   strcpy(option,   isNULLstr(argv[3]));
   strcpy(dbgn,     isNULLstr(argv[4]));
   strcpy(dend,     isNULLstr(argv[5]));
   strcpy(outputf,  isNULLstr(argv[6]));

   cm_char_split_3ym(dbgn, dbgn_yy, dbgn_mm);
   cm_char_split_3ym(dend, dend_yy, dend_mm);

   printf(" dbgn_yy[%s] dbgn_mm[%s]\n",dbgn_yy, dbgn_mm);
   printf(" dend_yy[%s] dend_mm[%s]\n",dend_yy, dend_mm);

   l_dbgn = cm_build_date_ym(dbgn, 1);
   l_dend = cm_build_date_ym(dend, 2);

   printf("dbgn[%s]\n", cm_edate_str(l_dbgn));
   printf("dend[%s]\n", cm_edate_str(l_dend));
   
   max_cnt=0;

   if( strcmp(option,"1") == 0 )
   {
      rc = car901_build();
   }
   else
   {
      rc = car901_build1();
   }

   if ((option[0] == '1') || (option[0] == '2'))
   {
    if ( rc != FAIL)
    {
      if ((rc=save_form_info(F_BLK1, "CA", 901, userid, iForm_Tp, max_cnt, outputf))<0)
      {
        strcpy(msgbuf,"save_form_info failed");
        return rc;

      }
    }
   }

   printf("after save form\n");

}
/*--------------------------------------------------------------------*/

long car901_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;
   
   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 901 AND iForm_Tp = "1";

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf_s( TitleFile,N_FILE+1,"%s.ti",outputf);
   sprintf_s( BodyFile,N_FILE+1,"%s.bd",outputf);
   

   $CREATE TEMP TABLE pay_way
   (
      iclaim        char(4),
      xsettle_type  char(2),
      xfpay_cond    char(2),
      total_sum     int default 0
   ) WITH NO LOG;

   rgu_init_report(TitleFmt,TitleFile);
   car901_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);
   rc = car901_body();
   if (rc != M_CM_OK)
       return rc;
   rgu_finish_report();
   
   $DROP TABLE pay_way;

   return M_CM_OK;

errexit:
 /*  sqlfatal();  */
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}


long car901_title()
{
   rgu_put_head_string(1, cm_sysd_cdatetime_100(cm_get_sysd()));  /* get_currdt */

   rgu_put_head_string(1, dbgn_yy);
   rgu_put_head_string(1, dbgn_mm);

   rgu_put_head_string(1, dend_yy);
   rgu_put_head_string(1, dend_mm);

   rgu_put_head();
   
}

long car901_body()
{
     
   $char stmt[5000];
   $char tmp_buf[15], Nchi_full[23], iapp_unit[3];
    char str[8];
    int  k;
   $char nname[20],tmp[10];
   $char dbnamek[100];
   
   $WHENEVER SQLERROR goto errexit;

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
         printf("get_db_list error accur \n");
         return SQLCODE;
      }

    /*** �I�ڤ覡:1.�{�� 2.�}�� 3.�״� ***/
    for(k=0 ; k<count_db ; k++)
    {
	    strcpy(dbnamek, list[k].dbname);

        stmt[0] = '\0';
        sprintf_s(stmt,5000,"SELECT B.iclaim[1,2] , A.iadjuster , B.iclaim , \
                             B.iclose_type , B.xfpay_cond , B.xsettle_type, \
                             B.nchi_full[1,22] \
                        FROM %s:settlement A , %s:payment B           \
                       WHERE A.iclaim = B.iclaim                      \
                         AND A.iclose_type = B.iclose_type            \
                         AND A.fstl = B.fstl                          \
                         AND B.fstl = '1'                             \
                         AND A.dgroup >= %ld and A.dgroup <= %ld      \
                       ORDER BY 1,2,5,3,4 ", dbnamek,dbnamek,l_dbgn, l_dend);

        printf("stmt[%s]\n",stmt);

        $PREPARE CUR_1 FROM $stmt;
        $DECLARE STL_CUR CURSOR FOR CUR_1;
        $OPEN    STL_CUR;
        for(;;)
        {
             $FETCH STL_CUR INTO $iclaim_2 , $iadjuster , $iclaim ,
                                 $iclose_type,$xfpay_cond, $xsettle_type,
                                 $nchi_full;

             if(SQLCODE == SQLNOTFOUND) break;

                  $SELECT  b.nname ,a.iapp_unit
                     INTO  $nname, $iapp_unit
                     FROM  cm_clm_adjuster a,officer b
                    WHERE  empl_no = $iadjuster
                      AND  empl_no = iofficer;


                  /*$SELECT  nchi_full[1,4]*/
                  $SELECT  nchi_full
                     INTO  $Nchi_full
                     FROM  branch
                    WHERE  ibranch = $iapp_unit;
                                
                  rgu_put_body_string(1, Nchi_full, LEFT);

                  rgu_put_body_string(1, nname, LEFT);

                  rgu_put_body_string(1, iclaim, LEFT);

                  rfmtlong(iclose_type,"--&",tmp);
                  rgu_put_body_string(1, tmp, LEFT);


                  switch( xfpay_cond[0] )
                  {
                     case  '1':  strcpy( str, "�{��" );
                                 break;
                     case  '2':  strcpy( str, "�}��" );
                                 break;
                     case  '3':  strcpy( str, "�״�" );
                                 break;
                     default : break;
                  }

                  rgu_put_body_string(1, trim(str), LEFT );

                   switch( xsettle_type[0] )
                   {
                      case  '1':  strcpy( str, "���q" );
                                  break;
                      case  '2':  strcpy( str, "�ӤH" );
                                  break;
                      case  '3':  strcpy( str, "�߮v" );
                                  break;
                      case  '4':  strcpy( str, "�Ȧ�" );
                                  break;
                      case  '5':  strcpy( str, "���u" );
                                  break;
                      case  '6':  strcpy( str, "�ר��t" );
                                  break;
                      default : break;
                   }

                  rgu_put_body_string(1, trim(str), LEFT );

                  rgu_put_body_string(1, nchi_full, LEFT );
                  rgu_put_body(1);
                  max_cnt++;

        }
        $CLOSE STL_CUR;
        $FREE  STL_CUR;
    }


   return M_CM_OK;
   
errexit:
   
   printf("body :SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;   
   
}

long car901_build1()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;
   
   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if (option[0] == '2')
   {
   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $iForm_Tp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 901 AND iForm_Tp = "2";

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf_s( TitleFile,N_FILE+1,"%s.ti",outputf);
   sprintf_s( BodyFile,N_FILE+1,"%s.bd",outputf);
   }

   $CREATE TEMP TABLE iins_count_dtl
   (
        nowbranch                char(40),
        nadjuster                char(10),
        iclaim                   char(20),
        dclaim                   date,
        nupcomp                  char(3),
        nbranch                  char(40),
        nquota                   char(40),
        only_01                  int default 0,
        only_01_app              int default 0,
        only_01_stl              int default 0,
        only_32                  int default 0,
        only_32_app              int default 0,
        only_32_stl              int default 0,
        only_93                  int default 0,
        only_93_app              int default 0,
        only_93_stl              int default 0,
        only_93_rel              int default 0,
        only_93_rel_app          int default 0,
        only_93_rel_stl          int default 0,
        only_21                  int default 0,
        only_21_app              int default 0,
        only_21_stl              int default 0,
        dam01_lia32              int default 0,
        dam01_lia32_app          int default 0,
        dam01_lia32_stl          int default 0,
        dam01_inj93              int default 0,
        dam01_inj93_app          int default 0,
        dam01_inj93_stl          int default 0,
        dam01_lia32_inj93        int default 0,
        dam01_lia32_inj93_app    int default 0,
        dam01_lia32_inj93_stl    int default 0,
        dam01_lia32_inj21        int default 0,
        dam01_lia32_inj21_app    int default 0,
        dam01_lia32_inj21_stl    int default 0,
        lia32_inj93              int default 0,
        lia32_inj93_app          int default 0,
        lia32_inj93_stl          int default 0,
        lia32_inj21              int default 0,
        lia32_inj21_app          int default 0,
        lia32_inj21_stl          int default 0,
        only_12                  int default 0,
        only_12_app              int default 0,
        only_12_stl              int default 0,
        only_11                  int default 0,
        only_11_app              int default 0,
        only_11_stl              int default 0,
        with_21                  int default 0,
        with_21_app              int default 0,
        with_21_stl              int default 0,
        other_iins               int default 0,
        other_iins_app           int default 0,
        other_iins_stl           int default 0
   ) WITH NO LOG;

   $CREATE TEMP TABLE iins_count
   (
        iclaim_2                 char(3),
        iadjuster                char(10),
        only_01                  int default 0,
        only_01_app              int default 0,
        only_01_stl              int default 0,
        only_32                  int default 0,
        only_32_app              int default 0,
        only_32_stl              int default 0,
        only_93                  int default 0,
        only_93_app              int default 0,
        only_93_stl              int default 0,
        only_93_rel              int default 0,
        only_93_rel_app          int default 0,
        only_93_rel_stl          int default 0,
        only_21                  int default 0,
        only_21_app              int default 0,
        only_21_stl              int default 0,
        dam01_lia32              int default 0,
        dam01_lia32_app          int default 0,
        dam01_lia32_stl          int default 0,
        dam01_inj93              int default 0,
        dam01_inj93_app          int default 0,
        dam01_inj93_stl          int default 0,
        dam01_lia32_inj93        int default 0,
        dam01_lia32_inj93_app    int default 0,
        dam01_lia32_inj93_stl    int default 0,
        dam01_lia32_inj21        int default 0,
        dam01_lia32_inj21_app    int default 0,
        dam01_lia32_inj21_stl    int default 0,
        lia32_inj93              int default 0,
        lia32_inj93_app          int default 0,
        lia32_inj93_stl          int default 0,
        lia32_inj21              int default 0,
        lia32_inj21_app          int default 0,
        lia32_inj21_stl          int default 0,
        only_12                  int default 0,
        only_12_app              int default 0,
        only_12_stl              int default 0,
        only_11                  int default 0,
        only_11_app              int default 0,
        only_11_stl              int default 0,
        with_21                  int default 0,
        with_21_app              int default 0,
        with_21_stl              int default 0,
        other_iins               int default 0,
        other_iins_app           int default 0,
        other_iins_stl           int default 0
   ) WITH NO LOG;

   $CREATE UNIQUE INDEX iins_count_tmp_1 on iins_count (iclaim_2 , iadjuster);

   if (option[0] == '2')
   {
      rgu_init_report(TitleFmt,TitleFile);
      car901_title();
      rgu_finish_report();

      rgu_init_report(BodyFmt,BodyFile);
      rc = car901_body1();
      if (rc != M_CM_OK)
         return rc;
      rgu_finish_report();
   
      $DROP TABLE iins_count;
   }
   else
   {
      rc = car901_body1();
   }

   return M_CM_OK;

errexit:
 /*  sqlfatal();  */
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;  
}

long car901_body1()
{
   $char stmt[1024];
   $char tmp_buf[15], Nchi_full[23],iapp_unit[3];
    char str[8];
    int  k;
   $char nupcomp[3], nbranch[41], nquota[41];
   $char Iclaim12[3];
   $char sfilename[31];
   $char stitle[10000];
   $char sErrmsg[100];
   $char tempbuf[100];
   $int  rc;
   $long dclaim;
   $char dbnamek[100];


   $WHENEVER SQLERROR goto errexit;

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
         printf("get_db_list error accur \n");
         return SQLCODE;
      }

    $DECLARE BRANCH_CUR CURSOR FOR
      SELECT ibranch
        FROM branch
       ORDER BY ibranch;
    $OPEN BRANCH_CUR;
    for(;;)
    {
        $FETCH BRANCH_CUR INTO $Iclaim_2;
        if (SQLCODE==SQLNOTFOUND) break;

        strcpy(Iclaim_2,trim(Iclaim_2));

        $INSERT INTO iins_count
                     (iclaim_2)
              VALUES ($Iclaim_2);
    }
    $CLOSE BRANCH_CUR;
    $FREE  BRANCH_CUR;

    for(k=0 ; k<count_db ; k++)
    {
	    strcpy(dbnamek, list[k].dbname);

        stmt[0] = '\0';

        sprintf_s(stmt,1024," select nvl(sum(mapp_cover) ,0)   \
                         from %s:ca_app_victim        \
                        where iclaim      = ?   ", dbnamek); 
        $prepare vicapp from $stmt;

	sprintf_s(stmt,1024," select nvl(sum(decode(fstl,'2',mins_stl*(-1),mins_stl)) ,0)    \
	                 from %s:stl_ins_type                                       \
                        where iclaim     = ?                                        \
                          and dgroup is not null ",dbnamek );  
        $prepare stlins from $stmt;

	sprintf_s(stmt,1024," select nvl(sum(decode(fstl,'2',(mins_stl+mstl_health)*(-1), mins_stl+mstl_health)) ,0)  \
	                 from %s:ca_stl_victim    \
                        where iclaim     = ?      \
                          and dgroup is not null ",dbnamek );
        $prepare vicstl from $stmt;

        sprintf_s(stmt,1024,"SELECT iclaim , icoclaim , fcard_class , iacc_reason , iadjuster , date(dclaim) as dclaim  \
                        FROM %s:appraisal \
                       WHERE date(dclaim) >= %ld and date(dclaim) <= %ld \
                         AND dapp_entry is not null",
                      dbnamek, l_dbgn, l_dend );
        printf("stmt[%s]\n",stmt);

        $PREPARE CUR_4 FROM :stmt;
        $DECLARE app_cur CURSOR FOR CUR_4;
        $OPEN    app_cur;
        for(;;)
        {
             $FETCH app_cur INTO $Iclaim, $Icoclaim, $Fcard_class, $Iacc_reason,
                                          $Iadjuster, $dclaim;

             if(SQLCODE == SQLNOTFOUND) break;
 
             printf("start app cur iclaim=[%s]\n",Iclaim);

             strcpy(Iclaim , trim(Iclaim));
             strcpy(Iadjuster , trim(Iadjuster));

             check_01               = 0;
             check_32               = 0;
             check_93               = 0;
             check_21               = 0;
             check_11               = 0;
             check_12               = 0;
             check_with_21          = 0;

             only_01                = 0;
             only_01_app            = 0;
             only_01_stl            = 0;

             only_32                = 0;
             only_32_app            = 0;
             only_32_stl            = 0;

             only_93                = 0;
             only_93_app            = 0;
             only_93_stl            = 0;
			 
             only_93_rel            = 0;
             only_93_rel_app        = 0;
             only_93_rel_stl        = 0;
			 
             only_21                = 0;
             only_21_app            = 0;
             only_21_stl            = 0;

             dam01_lia32            = 0;
             dam01_lia32_app        = 0;
             dam01_lia32_stl        = 0;

             dam01_inj93            = 0;
             dam01_inj93_app        = 0;
             dam01_inj93_stl        = 0;

             dam01_lia32_inj93      = 0;
             dam01_lia32_inj93_app  = 0;
             dam01_lia32_inj93_stl  = 0;

             dam01_lia32_inj21      = 0;
             dam01_lia32_inj21_app  = 0;
             dam01_lia32_inj21_stl  = 0;

             lia32_inj93            = 0;
             lia32_inj93_app        = 0;
             lia32_inj93_stl        = 0;

             lia32_inj21            = 0;
             lia32_inj21_app        = 0;
             lia32_inj21_stl        = 0;

             only_12                = 0;
             only_12_app            = 0;
             only_12_stl            = 0;

             only_11                = 0;
             only_11_app            = 0;
             only_11_stl            = 0;

             with_21                = 0;
             with_21_app            = 0;
             with_21_stl            = 0;

             other_iins             = 0;
             other_iins_app         = 0;
             other_iins_stl         = 0;

             Mins_app_tot           = 0;
             Mins_stl_tot           = 0;

             if (strcmp(trim(Fcard_class),"1") == 0 && strcmp(trim(Icoclaim),"N") == 0)  /** ��W�j���I **/
             {
                 check_21 = 1;
                 check_21_tot = check_21_tot + check_21;

                 $execute vicapp into $Mins_app_tot using $Iclaim;
		 $execute vicstl into $Mins_stl_tot using $Iclaim;
             }
             else if (strcmp(trim(Fcard_class),"2") == 0)
             {
                 stmt[0] = '\0';

		 $execute stlins into $Mins_stl_tot using $Iclaim;

                 printf(" stlins Mins_stl_tot[%ld]\n",Mins_stl_tot);
                 printf(" Iclaim[%s]\n",Iclaim);
                 printf(" dbnamek[%s]\n", dbnamek);

                 sprintf_s(stmt,1024,"SELECT iins_type , mins_app \
                                 FROM %s:app_ins_type                \
                                WHERE iclaim      = '%s' ",dbnamek, Iclaim);
                 printf("stmt [%s]\n",stmt);
                 $PREPARE CUR_5 FROM $stmt;
                 $DECLARE app_ins_cur CURSOR FOR CUR_5;
                 $OPEN    app_ins_cur;
                 for(;;)
                 {
                     EXEC SQL FETCH app_ins_cur INTO $Iins_type , $Mins_app;
                     if (SQLCODE == SQLNOTFOUND) break;

                     printf("app_ins_cur start Mins_app[%ld]\n", Mins_app);

                     Mins_app_tot += Mins_app;

                     strcpy(Iins_type , trim(Iins_type));

                     sprintf_s(stmt,1024," select count(*) from cu_code_data where itype = 'CT' and icode = ? ");
                     $prepare get_dmg_insv from $stmt;
                     $execute get_dmg_insv into $tmp_count using $Iins_type;

                     printf(" end cu_code_data \n");

                     /*** ���l�I ***/
                     if (tmp_count > 0)
                     {
                          check_01         = 1;
                     }

                     /*** �]�l�I ***/
                     if (strcmp(Iins_type , "32") == 0)
                     {
                          check_32         = 1;
                     }

                     /*** ����I ***/
                     if (strcmp(Iins_type , "93") == 0 ||
                         strcmp(Iins_type , "94") == 0 ||
                         strcmp(Iins_type , "95") == 0)
                     {
                          check_93         = 1;
                     }

                     /*** �s���I ***/
                     if (strcmp(Iins_type , "12") == 0)
                     {
                          check_12         = 1;
                     }

                     /*** �ѵs�I ***/
                     if (strcmp(Iins_type , "11") == 0)
                     {
                          check_11         = 1;
                     }
                 }
                 EXEC SQL CLOSE app_ins_cur;
             }
             else if(strcmp(trim(Fcard_class),"1") == 0 && strcmp(trim(Icoclaim),"Y") == 0)  /** �P�ɨ��z�j���I **/
             {
                 /*****  �j��M���N�P�ɨ��z fcard_class = '1' and icoclaim = 'Y' *****/
                 
                 check_with_21 = 1;
                 check_with_21_tot = check_with_21_tot + check_with_21;

                 $execute vicapp into $Mins_app_tot using $Iclaim;   
		 $execute vicstl into $Mins_stl_tot using $Iclaim;
             }


             /*** ��W���l ***/
             if (check_01 == 1 &&
                 check_32 == 0 &&
                 check_93 == 0 &&
                 check_21 == 0 &&
                 check_11 == 0 &&
                 check_12 == 0)
             {
                 only_01 = 1;
                 only_01_app = Mins_app_tot;
                 only_01_stl = Mins_stl_tot;
             }
             /*** ��W�]�l ***/
             else if (check_01 == 0 &&
                      check_32 == 1 &&
                      check_93 == 0 &&
                      check_21 == 0 &&
                      check_11 == 0 &&
                      check_12 == 0)
             {
                      only_32 = 1;
                      only_32_app = Mins_app_tot;
                      only_32_stl = Mins_stl_tot;
             }
             /*** ��W���[���N](�L���p) ***/
             else if (check_01 == 0 &&
                      check_32 == 0 &&
                      check_93 == 1 &&
                      check_21 == 0 &&
                      check_11 == 0 &&
                      check_12 == 0 &&
                      strcmp(trim(Icoclaim),"N") == 0)
             {
                      only_93      = 1;
                      only_93_app = Mins_app_tot;
                      only_93_stl = Mins_stl_tot;
             }
             /*** ��W���[���N](�����p) ***/
             else if (check_01 == 0 &&
                      check_32 == 0 &&
                      check_93 == 1 &&
                      check_21 == 0 &&
                      check_11 == 0 &&
                      check_12 == 0 &&
                      strcmp(trim(Icoclaim),"Y") == 0)
             {
                      only_93_rel      = 1;
                      only_93_rel_app = Mins_app_tot;
                      only_93_rel_stl = Mins_stl_tot;
             }
             /*** ��W�j�� ***/
             else if (check_01 == 0 &&
                      check_32 == 0 &&
                      check_93 == 0 &&
                      check_21 == 1 &&
                      check_11 == 0 &&
                      check_12 == 0 &&
                      strcmp(trim(Icoclaim),"N") == 0)
             {
                      only_21      = 1;
                      only_21_app = Mins_app_tot;
                      only_21_stl = Mins_stl_tot;
             }
             /*** ���B�]�l ***/
             else if (check_01 == 1 &&
                      check_32 == 1 &&
                      check_93 == 0 &&
                      check_21 == 0 &&
                      check_11 == 0 &&
                      check_12 == 0)
             {
                      dam01_lia32 = 1;
                      dam01_lia32_app = Mins_app_tot;
                      dam01_lia32_stl = Mins_stl_tot;
             }
             /*** ���l�B��� ***/
             else if (check_01 == 1 &&
                      check_32 == 0 &&
                      check_93 == 1 &&
                      check_21 == 0 &&
                      check_11 == 0 &&
                      check_12 == 0)
             {
                      dam01_inj93 = 1;
                      dam01_inj93_app = Mins_app_tot;
                      dam01_inj93_stl = Mins_stl_tot;
             }
             /*** ���B�]�B���[���N] ***/
             else if (check_01 == 1 &&
                      check_32 == 1 &&
                      check_93 == 1 &&
                      check_21 == 0 &&
                      check_11 == 0 &&
                      check_12 == 0 )
              {
                      dam01_lia32_inj93 = 1;
                      dam01_lia32_inj93_app = Mins_app_tot;
                      dam01_lia32_inj93_stl = Mins_stl_tot;
              }

             /*** ���B�]�B���[�j��] ***/
             else if (check_01 == 1 &&
                      check_32 == 1 &&
                      check_93 == 0 &&
                      check_21 == 0 &&
                      check_11 == 0 &&
                      check_12 == 0 &&
                      strcmp(trim(Icoclaim),"Y") == 0)
             {
                      dam01_lia32_inj21 = 1;
                      dam01_lia32_inj21_app = Mins_app_tot;
                      dam01_lia32_inj21_stl = Mins_stl_tot;
             }
             /*** �]�B���[���N] ***/
             else if (check_01 == 0 &&
                      check_32 == 1 &&
                      check_93 == 1 &&
                      check_21 == 0 &&
                      check_11 == 0 &&
                      check_12 == 0 )
             {
                      lia32_inj93 = 1;
                      lia32_inj93_app = Mins_app_tot;
                      lia32_inj93_stl = Mins_stl_tot;
             }
             /*** �]�B���[�j��] ***/
             else if (check_01 == 0 &&
                      check_32 == 1 &&
                      check_93 == 0 &&
                      check_21 == 0 &&
                      check_11 == 0 &&
                      check_12 == 0 &&
                      strcmp(trim(Icoclaim),"Y") == 0)
             {
                      lia32_inj21 = 1;
                      lia32_inj21_app = Mins_app_tot;
                      lia32_inj21_stl = Mins_stl_tot;
             }
             /*** �s���� ***/
             else if (check_01 == 0 &&
                      check_32 == 0 &&
                      check_93 == 0 &&
                      check_21 == 0 &&
                      check_11 == 0 &&
                      check_12 == 1)
             {
                      only_12 = 1;
                      only_12_app = Mins_app_tot;
                      only_12_stl = Mins_stl_tot;
             }
             /*** �㨮���� ***/
             else if (check_01 == 0 &&
                      check_32 == 0 &&
                      check_93 == 0 &&
                      check_21 == 0 &&
                      check_11 == 1 &&
                      check_12 == 0)
		     {
                       only_11 = 1;
					   only_11_app = Mins_app_tot;
					   only_11_stl = Mins_stl_tot;
			 }
             else if(check_with_21 == 1)
                     check_with_21 = 1;
             else
             {
                  other_iins = 1;
                  other_iins_app = Mins_app_tot;
                  other_iins_stl = Mins_stl_tot;
             }

             if (check_21==1)
             {
                 printf("1111111111111111111111111check_21[%d]\n",check_21);
             }

             if (check_with_21==1)
             {
                 printf("222222222222222222222check_with_21[%d]\n",check_with_21);
             }
             
             if (check_21 == 1 || check_with_21 == 1)
             {
                 if (check_21==1)
                 {
                    printf("1111111111111111111111111check_21[%d]\n",check_21);
                 }

                 if (check_with_21==1)
                 {
                    printf("222222222222222222222check_with_21[%d]\n",check_with_21);
                 }
        
                 with_21 = 1;
                 with_21_app = Mins_app_tot;
                 with_21_stl = Mins_stl_tot;
                 with_21_tot = with_21_tot + with_21;
             }

             printf("bef cm_clm_adjuster Iadjuster[%s]\n", Iadjuster);

             $SELECT  b.nname ,a.iapp_unit
                INTO  $Iadjuster_name,$iapp_unit
                FROM  cm_clm_adjuster a,officer b
               WHERE  empl_no = $Iadjuster
                 AND  empl_no = iofficer;

              printf("bef branch iapp_unit [%s]\n", iapp_unit);

             /*$SELECT nchi_full[1,4]*/
             $SELECT nchi_full
                INTO  $Nchi_full
                FROM  branch
               WHERE  ibranch = $iapp_unit;

              printf("bef trans Iclaim[%s]\n",Iclaim);

              strncpy(Iclaim_2, Iclaim, 2);
              Iclaim_2[2] = '\0';

              strcpy(Iclaim12, Iclaim_2);
              printf("bef Iclaim12[%s]\n",Iclaim12);
              if (Iclaim12[1] == 'A')
              {
                 if (Iclaim12[0] == '0')
                     strcpy(Iclaim12, "00");
                 else if (Iclaim12[0] == '4')    
                     strcpy(Iclaim12, "40");
                 else if (Iclaim12[0] == '7')    
                     strcpy(Iclaim12, "70");
                 else if (Iclaim12[0] == '2')    
                     strcpy(Iclaim12, "22");
                 else if (Iclaim12[0] == '3')
                     strcpy(Iclaim12, "33");
                 else if (Iclaim12[0] == '6')
                     strcpy(Iclaim12, "66");
                 else
                     strcpy(Iclaim12, Iclaim_2);
              }
              printf("aft Iclaim12[%s]\n",Iclaim12);
                 
              strcpy(nupcomp,"");
              strcpy(nbranch,"");
              strcpy(nquota,"");

              printf("bef clm_process Iclaim12[%s] Iclaim[%s]\n", Iclaim12, Iclaim);

              sprintf_s(stmt,1024,
              "  select (select iupcomp from branch where ibranch = '%s') as nupcomp,                   \
                        (select nchi_full from branch where ibranch = '%s') as nbranch,                 \
                        (select nbranch from sa_branch_type where ibranch = a.affiliated) as nquota     \
               from ca_clm_process a      \
              where iclaim = '%s' ", Iclaim12, Iclaim12, Iclaim);

              printf("clm_process stmt[%s]\n",stmt);
 
              $prepare get_main from $stmt;
              $execute get_main into $nupcomp, $nbranch, $nquota;

              printf("bef int iins_count_dtl iclaim=[%s]\n", Iclaim);

              $INSERT INTO iins_count_dtl
                         ( nowbranch, nadjuster, iclaim, dclaim, nupcomp, nbranch, nquota, 
                           only_01, only_01_app, only_01_stl, 
			   only_32, only_32_app, only_32_stl,
                           only_93, only_93_app, only_93_stl,
			   only_93_rel, only_93_rel_app, only_93_rel_stl,
                           only_21, only_21_app, only_21_stl,
			   dam01_lia32, dam01_lia32_app, dam01_lia32_stl,
                           dam01_inj93, dam01_inj93_app, dam01_inj93_stl,
			   dam01_lia32_inj93, dam01_lia32_inj93_app, dam01_lia32_inj93_stl,
                           dam01_lia32_inj21, dam01_lia32_inj21_app, dam01_lia32_inj21_stl,
			   lia32_inj93, lia32_inj93_app, lia32_inj93_stl,
                           lia32_inj21, lia32_inj21_app, lia32_inj21_stl,
			   only_12, only_12_app, only_12_stl,
                           only_11, only_11_app, only_11_stl,
			   with_21, with_21_app, with_21_stl,
                           other_iins, other_iins_app, other_iins_stl)
                  VALUES ($Nchi_full, $Iadjuster_name, $Iclaim, $dclaim, $nupcomp, $nbranch, $nquota, 
                          $only_01, $only_01_app, $only_01_stl,
			  $only_32, $only_32_app, $only_32_stl,
                          $only_93, $only_93_app, $only_93_stl,
			  $only_93_rel, $only_93_rel_app, $only_93_rel_stl,
                          $only_21, $only_21_app, $only_21_stl,
			  $dam01_lia32, $dam01_lia32_app, $dam01_lia32_stl,
                          $dam01_inj93, $dam01_inj93_app, $dam01_inj93_stl,
			  $dam01_lia32_inj93, $dam01_lia32_inj93_app, $dam01_lia32_inj93_stl,
                          $dam01_lia32_inj21, $dam01_lia32_inj21_app, $dam01_lia32_inj21_stl,
			  $lia32_inj93, $lia32_inj93_app, $lia32_inj93_stl,
                          $lia32_inj21, $lia32_inj21_app, $lia32_inj21_stl,
			  $only_12, $only_12_app, $only_12_stl,
                          $only_11, $only_11_app, $only_11_stl,
			  $with_21, $with_21_app, $with_21_stl,
                          $other_iins, $other_iins_app, $other_iins_stl );

              printf("bef upd iins_count iclaim[%s]\n", Iclaim);

             $UPDATE iins_count
                 SET only_01           = only_01           +$only_01,
                     only_01_app       = only_01_app       +$only_01_app,
                     only_01_stl       = only_01_stl       +$only_01_stl,
                     only_32           = only_32           +$only_32,
                     only_32_app       = only_32_app       +$only_32_app,
                     only_32_stl       = only_32_stl       +$only_32_stl,
                     only_93           = only_93           +$only_93,
                     only_93_app       = only_93_app       +$only_93_app,
                     only_93_stl       = only_93_stl       +$only_93_stl,
                     only_93_rel       = only_93_rel       +$only_93_rel,
                     only_93_rel_app   = only_93_rel_app   +$only_93_rel_app,
                     only_93_rel_stl   = only_93_rel_stl   +$only_93_rel_stl,
                     only_21           = only_21           +$only_21,
                     only_21_app       = only_21_app       +$only_21_app,
                     only_21_stl       = only_21_stl       +$only_21_stl,
                     dam01_lia32       = dam01_lia32       +$dam01_lia32,
                     dam01_lia32_app   = dam01_lia32_app   +$dam01_lia32_app,
                     dam01_lia32_stl   = dam01_lia32_stl   +$dam01_lia32_stl,
                     dam01_inj93       = dam01_inj93       +$dam01_inj93,
                     dam01_inj93_app   = dam01_inj93_app   +$dam01_inj93_app,
                     dam01_inj93_stl   = dam01_inj93_stl   +$dam01_inj93_stl,
                     dam01_lia32_inj93 = dam01_lia32_inj93 +$dam01_lia32_inj93,
                     dam01_lia32_inj93_app = dam01_lia32_inj93_app +$dam01_lia32_inj93_app,
                     dam01_lia32_inj93_stl = dam01_lia32_inj93_stl +$dam01_lia32_inj93_stl,
                     dam01_lia32_inj21 = dam01_lia32_inj21 +$dam01_lia32_inj21,
                     dam01_lia32_inj21_app = dam01_lia32_inj21_app +$dam01_lia32_inj21_app,
                     dam01_lia32_inj21_stl = dam01_lia32_inj21_stl +$dam01_lia32_inj21_stl,
                     lia32_inj93       = lia32_inj93       +$lia32_inj93,
                     lia32_inj93_app   = lia32_inj93_app   +$lia32_inj93_app,
                     lia32_inj93_stl   = lia32_inj93_stl   +$lia32_inj93_stl,
                     lia32_inj21       = lia32_inj21       +$lia32_inj21,
                     lia32_inj21_app   = lia32_inj21_app   +$lia32_inj21_app,
                     lia32_inj21_stl   = lia32_inj21_stl   +$lia32_inj21_stl,
                     only_12           = only_12           +$only_12,
                     only_12_app       = only_12_app       +$only_12_app,
                     only_12_stl       = only_12_stl       +$only_12_stl,
                     only_11           = only_11           +$only_11,
                     only_11_app       = only_11_app       +$only_11_app,
                     only_11_stl       = only_11_stl       +$only_11_stl,
                     with_21           = with_21           +$with_21,
                     with_21_app       = with_21_app       +$with_21_app,
                     with_21_stl       = with_21_stl       +$with_21_stl,
                     other_iins        = other_iins        +$other_iins,
                     other_iins_app    = other_iins_app    +$other_iins_app,
                     other_iins_stl    = other_iins_stl    +$other_iins_stl
               WHERE iclaim_2  = $Iclaim_2
                 AND iadjuster = $Iadjuster;

             if (sqlca.sqlerrd[2]==0)
             {
                 printf("bef int iins_count-2 iclaim=[%s]\n", Iclaim);
                 $INSERT INTO iins_count
                         ( iclaim_2, iadjuster, 
                           only_01, only_01_app, only_01_stl,
			   only_32, only_32_app, only_32_stl, 
			   only_93, only_93_app, only_93_stl,
			   only_93_rel, only_93_rel_app, only_93_rel_stl, 
                           only_21, only_21_app, only_21_stl, 
			   dam01_lia32, dam01_lia32_app, dam01_lia32_stl, 
			   dam01_inj93, dam01_inj93_app, dam01_inj93_stl,
			   dam01_lia32_inj93, dam01_lia32_inj93_app, dam01_lia32_inj93_stl,
                           dam01_lia32_inj21, dam01_lia32_inj21_app, dam01_lia32_inj21_stl,
			   lia32_inj93, lia32_inj93_app, lia32_inj93_stl,
			   lia32_inj21, lia32_inj21_app, lia32_inj21_stl,
			   only_12, only_12_app, only_12_stl,
                           only_11, only_11_app, only_11_stl,
			   with_21, with_21_app, with_21_stl,
                           other_iins, other_iins_app, other_iins_stl)
                  VALUES ($Iclaim_2, $Iadjuster, 
                          $only_01, $only_01_app, $only_01_stl,
			  $only_32, $only_32_app, $only_32_stl,
			  $only_93, $only_93_app, $only_93_stl,
			  $only_93_rel, $only_93_rel_app, $only_93_rel_stl,                             
                          $only_21, $only_21_app, $only_21_stl,
			  $dam01_lia32, $dam01_lia32_app, $dam01_lia32_stl,
			  $dam01_inj93, $dam01_inj93_app, $dam01_inj93_stl,
			  $dam01_lia32_inj93, $dam01_lia32_inj93_app, $dam01_lia32_inj93_stl,                          
                          $dam01_lia32_inj21, $dam01_lia32_inj21_app, $dam01_lia32_inj21_stl,
			  $lia32_inj93, $lia32_inj93_app, $lia32_inj93_stl,
			  $lia32_inj21, $lia32_inj21_app, $lia32_inj21_stl,
			  $only_12, $only_12_app, $only_12_stl,                        
                          $only_11, $only_11_app, $only_11_stl,
                          $with_21, $with_21_app, $with_21_stl,
                          $other_iins, $other_iins_app, $other_iins_stl );
             }
        }
        $CLOSE app_cur;
        $FREE  app_cur;
    }
    
    printf(" check_21_tot[%d]\n",check_21_tot);
    printf(" check_with_21_tot[%d]\n",check_with_21_tot);
    printf(" with_21_tot[%d]\n",with_21_tot);


    if (option[0] == '2')
    {
    $DECLARE CUR_6 CURSOR FOR
      SELECT iclaim_2, iadjuster, 
             only_01, only_01_app, only_01_stl, 
	     only_32, only_32_app, only_32_stl,
	     only_93, only_93_app, only_93_stl,
	     only_93_rel, only_93_rel_app, only_93_rel_stl,
	     only_21, only_21_app, only_21_stl,
             dam01_lia32, dam01_lia32_app, dam01_lia32_stl,
	     dam01_inj93, dam01_inj93_app, dam01_inj93_stl,
	     dam01_lia32_inj93, dam01_lia32_inj93_app, dam01_lia32_inj93_stl,
	     dam01_lia32_inj21, dam01_lia32_inj21_app, dam01_lia32_inj21_stl,
             lia32_inj93, lia32_inj93_app, lia32_inj93_stl,
	     lia32_inj21, lia32_inj21_app, lia32_inj21_stl,
	     only_12, only_12_app, only_12_stl,
	     only_11, only_11_app, only_11_stl,
	     with_21, with_21_app, with_21_stl,
	     other_iins, other_iins_app, other_iins_stl
        FROM iins_count
       ORDER BY 1;
    $OPEN CUR_6;
    for(;;)
    {
        $FETCH CUR_6 INTO
              $Iclaim_2 , $Iadjuster , 
	      $only_01, $only_01_app, $only_01_stl,
	      $only_32, $only_32_app, $only_32_stl,
	      $only_93, $only_93_app, $only_93_stl,
	      $only_93_rel, $only_93_rel_app, $only_93_rel_stl,
	      $only_21, $only_21_app, $only_21_stl,
              $dam01_lia32, $dam01_lia32_app, $dam01_lia32_stl,
	      $dam01_inj93, $dam01_inj93_app, $dam01_inj93_stl,
	      $dam01_lia32_inj93, $dam01_lia32_inj93_app, $dam01_lia32_inj93_stl,
	      $dam01_lia32_inj21, $dam01_lia32_inj21_app, $dam01_lia32_inj21_stl,
              $lia32_inj93, $lia32_inj93_app, $lia32_inj93_stl,  
	      $lia32_inj21, $lia32_inj21_app, $lia32_inj21_stl,
	      $only_12, $only_12_app, $only_12_stl,
	      $only_11, $only_11_app, $only_11_stl,
	      $with_21, $with_21_app, $with_21_stl,
	      $other_iins, $other_iins_app, $other_iins_stl;

        if (SQLCODE==SQLNOTFOUND) break;
        
        /*�����ץ�Ƥ~���*/
        
        if( only_01 != 0 || only_32 != 0 || only_93 != 0 || only_93_rel != 0 || 
            only_21 != 0 || dam01_lia32 != 0 || dam01_inj93 != 0 || dam01_lia32_inj93 != 0 ||
            dam01_lia32_inj21 != 0 || lia32_inj93 != 0 || lia32_inj21 != 0 || only_12 != 0 || 
            only_11 != 0 || with_21 != 0 || other_iins != 0 )
        {
          
        $SELECT  b.nname ,a.iapp_unit
           INTO  $Iadjuster_name,$iapp_unit
           FROM  cm_clm_adjuster a,officer b
          WHERE  empl_no = $Iadjuster
            AND  empl_no = iofficer;


        /*$SELECT nchi_full[1,4]*/
        $SELECT nchi_full
           INTO $Nchi_full
           FROM branch
          WHERE ibranch = $iapp_unit;

        rgu_put_body_string(1, trim(Nchi_full), LEFT );
        rgu_put_body_string(1, trim(Iadjuster_name) , LEFT );

        strcpy(str , itoa(only_01));
        rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(only_01_app, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(only_01_stl, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );

        strcpy( str , itoa(only_32));
        rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(only_32_app, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(only_32_stl, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );

        strcpy( str , itoa(only_93));
        rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(only_93_app, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(only_93_stl, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );
		
        strcpy( str , itoa(only_93_rel));
        rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(only_93_rel_app, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(only_93_rel_stl, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );
		
        strcpy( str , itoa(only_21));
        rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(only_21_app, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(only_21_stl, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );
		
        strcpy( str , itoa(dam01_lia32));
        rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(dam01_lia32_app, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(dam01_lia32_stl, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );

        strcpy( str , itoa(dam01_inj93));
        rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(dam01_inj93_app, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(dam01_inj93_stl, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );

        strcpy( str , itoa(dam01_lia32_inj93));
        rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(dam01_lia32_inj93_app, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(dam01_lia32_inj93_stl, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );

        strcpy( str , itoa(dam01_lia32_inj21));
        rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(dam01_lia32_inj21_app, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(dam01_lia32_inj21_stl, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );

        strcpy( str , itoa(lia32_inj93));
        rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(lia32_inj93_app, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(lia32_inj93_stl, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );

        strcpy( str , itoa(lia32_inj21));
        rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(lia32_inj21_app, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(lia32_inj21_stl, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );

        strcpy( str , itoa(only_12));
        rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(only_12_app, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(only_12_stl, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );

        strcpy( str , itoa(only_11));
        rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(only_11_app, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(only_11_stl, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );

        strcpy( str , itoa(with_21));
        rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(with_21_app, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(with_21_stl, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );

        strcpy( str , itoa(other_iins));
        rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(other_iins_app, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );
		rfmtlong(other_iins_stl, "---,---,---,--&", str);
		rgu_put_body_string(1, trim(str), LEFT );

        rgu_put_body(1);

        max_cnt++;
        
        }

    }
    EXEC SQL CLOSE CUR_6;
    EXEC SQL FREE  CUR_6;
    }
    else
    {
       strcpy(sfilename,"���ץ�Ʃ��Ӫ�");
       strcpy(stitle,"���z����G");
       strcat(stitle, dbgn);
       strcat(stitle, " ~ ");
       strcat(stitle, dend);
       strcat(stitle,"\n\t�z�ߩҦb���\t�z�ߤH��\t�߮׸��X\t���z���\t�����Ұ�\t���z���\t��O\t��W���l\t�w�����B\t�w�M���B\t��W�]�l\t�w�����B\t�w�M���B\t��W���[���N](�L���p)\t�w�����B\t�w�M���B\t��W���[���N](�����p)\t�w�����B\t�w�M���B\t��W�j��\t�w�����B\t�w�M���B\t���B�]�l\t�w�����B\t�w�M���B\t���l�B���[���N]\t�w�����B\t�w�M���B\t���B�]�B��[���N]\t�w�����B\t�w�M���B\t���B�]�B��[�j��]\t�w�����B\t�w�M���B\t�]�B��[���N]\t�w�����B\t�w�M���B\t�]�B��[�j��]\t�w�����B\t�w�M���B\t�s����\t�w�����B\t�w�M���B\t�㨮����[�t�M�^]\t�w�����B\t�w�M���B\t�j���I\t�w�����B\t�w�M���B\t��L�I��\t�w�����B\t�w�M���B\t");

       sprintf_s(stmt,1024,
        " select * from iins_count_dtl order by iclaim ");

       rc = unload_file(outputf," ",sfilename,stitle,stmt);

       if (rc != SUCCESS)
       {
           if (rc == 3501)
           {
              sprintf_s(sErrmsg,100," ��J���^������䤣���� ",sfilename);
           }
           else
           {
              sprintf_s(sErrmsg,100," %s �ɮ׵L�k���� ",sfilename);
           }

           EWRITE(userid, rc , sErrmsg);
           exit(1);
       }
    }
    return M_CM_OK;
   
errexit:
   
   printf("body1:SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;   
   
}
