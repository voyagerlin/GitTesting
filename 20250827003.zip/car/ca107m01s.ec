/************************************************/
/*                                              */
/*   PROGRAM : ca107m01s.ec by Dennis Chang     */
/*   DATE    : 1993/09/01                       */
/*   ����100�~�M��: Checked  (2008/08/08)       */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include <decimal.h>
#include "safeclib.h"


long car107(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car107_insert(),car107_single_query(),car107_update_exec();
 long car107_multiple_query();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
           rtncode=car107_insert(reply);
           break;
  case 'Q':
           rtncode=car107_single_query(reply);
           break;
  case 'M':
           rtncode=car107_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car107_update_exec(reply,command,com_len);
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
            return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

/*-----------------------------------------------------------------*/
long car107_insert(reply)
serverReply reply;
{
 $char DBName[5];
 $int  insperiod;
 $double rate;
 dec_t dec_rate;
 char  tmp_rate[21];
 int tmp_len;
 long MsgCode;
   DBinfo *list;
   int i, j, is_add_fail=0, api_f;
   $char stmt_buf[300];

 cm_buf_get("%s %d %s",DBName,&insperiod,tmp_rate);
 deccvasc( tmp_rate, strlen(tmp_rate), &dec_rate);
 dectodbl( &dec_rate, &rate);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }

 $BEGIN WORK;
 for(j=0;j<i;j++)
 {
  sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:short_period_rate "
         " (qperiod, prate) VALUES(?,?)" ,list[j].dbname);

  $PREPARE a_id FROM $stmt_buf;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  $EXECUTE a_id USING $insperiod,$rate;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  tmp_len = cm_buf_len(ReplyBuf);
  if( j == i-1 )
     api_f = api_OKComplete;
  else
     api_f = api_OK;

  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    {
     is_add_fail = 2;
     break;
    }  
#ifdef DEBUG 
printf("INSERT %d\n", j+1);
#endif
 } /* for loop */

 if( is_add_fail == 1 ) goto errexit;

 if( is_add_fail == 2 ) 
  {
   $ROLLBACK WORK;
   return apiRC;
  }

 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

 errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
}

/*-----------------------------------------------------------------*/
long car107_single_query(reply)
serverReply reply;
{
 $char DBName[5];
 $int  insperiod;
 $double rate = 0.0;
 int tmp_len;

 cm_buf_get("%s %d",DBName,&insperiod);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

 $SELECT prate
    INTO $rate
    FROM short_period_rate
   WHERE qperiod=$insperiod;

 if(SQLCODE==SQLNOTFOUND)
  {
   if(exitsub(reply,M_CA_NSHORT_RATE) == True)
    return M_CA_NSHORT_RATE;
   else
    return apiRC;
  }

 cm_buf_init(ReplyBuf);
 cm_buf_put("%l %d %e",M_CM_OK,insperiod,rate);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}

/*-----------------------------------------------------------------*/
long car107_multiple_query(reply)
serverReply reply;
{
 $char DBName[5];
 $int  key_insperiod,insperiod = 0;
 $double rate = 0.0;
 char  key_char_insperiod[10];
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;
 int flag;

 cm_buf_get("%s %s" ,DBName,key_char_insperiod);


 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

 if( key_char_insperiod[0] == '*') {
printf("---- flag=1\n");
    flag = 1;
    $DECLARE q_cur1 CURSOR FOR
       SELECT qperiod,prate
       INTO $insperiod,$rate
       FROM short_period_rate
       WHERE qperiod >= 0
       ORDER BY prate;
  } else {
printf("---- flag=2\n");
    key_insperiod = atoi( key_char_insperiod);  /* ????? */
    flag = 2;
    $DECLARE q_cur2 CURSOR FOR
       SELECT qperiod,prate
       INTO $insperiod,$rate
       FROM short_period_rate
       WHERE qperiod = $key_insperiod
       ORDER BY prate;
  }

 if( flag == 1)
   $OPEN q_cur1;
 else
   $OPEN q_cur2;

 for(;;)
  {
    if( flag == 1)
       $FETCH q_cur1;
    else
       $FETCH q_cur2;
    if (SQLCODE != 0) break;
printf("---- period[%d] rate[%f]\n",insperiod,rate);

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    cm_buf_put("%d %e",insperiod, rate);

    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
         if( flag == 1)
            $CLOSE q_cur1;
         else
            $CLOSE q_cur2;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%d %e",insperiod, rate);

        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 if( flag == 1)
    $CLOSE q_cur1;
 else
    $CLOSE q_cur2;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CA_NSHORT_RATE) == True)
    return M_CA_NSHORT_RATE;
   else
    return apiRC;
  }

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}


/*-----------------------------------------------------------------*/
long car107_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 $char DBName[5];
 $int  insperiod, cur_insperiod;
 $double rate, cur_rate = 0.0;
 dec_t dec_rate, dec_cur_rate;
 char tmp_rate[21], tmp_cur_rate[21];
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len;
 long dummy;
 long MsgCode;
   DBinfo *list;
   int i, j, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[300];

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }
 /* compare old record and current record, if the record has not been changed
    since last request, update or delete the record, otherwise return errmsg
    to client side */

 /* get old record info from command buffer */

/*
 raw_len = *(int *) &comm[com_len];
 memcpy(&raw_len,(void *)&command[com_len],sizeof(int));
*/
 memcpy(&raw_len,&comm[com_len],sizeof(int));
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)
  memcpy(raw_ptr,pos,raw_len);
 else
  {
   if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
    return M_CM_NOT_MALLOC;
   else
    return apiRC;
  }

 cm_buf_init(raw_ptr);          /* get index key from old record */
 cm_buf_get("%l %d",&dummy,&cur_insperiod);

 $BEGIN WORK;

 $SELECT prate
    INTO $cur_rate
    FROM short_period_rate
   WHERE qperiod=$cur_insperiod;

  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */

 if (SQLCODE == SQLNOTFOUND)
  {
   MsgCode = M_CM_NOT_FOUND;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
  }

 cm_buf_init(cur_buf);
 cm_buf_put("%l %d %e",dummy,cur_insperiod,cur_rate);

 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
  {
   MsgCode = M_CM_NOT_EQUAL;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
  }
  
  free(raw_ptr);

 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
     
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM %s:short_period_rate WHERE qperiod = ?"
		,list[j].dbname); 
    $PREPARE d_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
    $EXECUTE d_id USING $cur_insperiod;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
#ifdef DEBUG 
printf("Delete %d\n", j+1);
#endif
   }/* for loop */

   if( is_del_fail ) goto errexit;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
   cm_buf_init(command);
   cm_buf_get("%c %s %d %s",&option,DBName,&insperiod,tmp_rate);
   deccvasc( tmp_rate, strlen( tmp_rate), &dec_rate);
   dectodbl( &dec_rate, &rate);
        
   $WHENEVER SQLERROR CONTINUE;
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE %s:short_period_rate "
       		" SET (qperiod,prate) = (?,?) WHERE qperiod = ?",list[j].dbname);

    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    $EXECUTE u_id USING $insperiod,$rate,$cur_insperiod;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {
      sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:short_period_rate "
			" (qperiod,prate) VALUES (?,?)",list[j].dbname);

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }
      $EXECUTE ua_id USING $insperiod,$rate;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }
     }
#ifdef DEBUG 
printf("Update %d\n", j+1);
#endif
   } /* for loop */

   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
    return M_CM_WRONG_OPTION;
   else
    return apiRC;
  }

 errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
}
/*-----------------------------------------------------------------*/
