/**********************************************************************/
/*                                                                    */
/*   program id   : ca_edr_to_yl.ec                                   */
/*   program name : �ζ��P�ߪA�ȥd�������X--�u�w��j���I          */
/*   date written : 2004/02/25                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : Jessie                                            */
/*   files        : edr_relation        i                             */
/*                  ply_relation        i                             */
/*                  policy              i                             */
/*                  ply_ins_type        i                             */
/**********************************************************************/
#include <stdio.h>
#include <string.h>
#include <time.h>
$include sqlca;
#include "sql.h"
#include "sqlfatal.h"
#include "commsgs.h"
#include "globdata.h"
#include "safeclib.h"
/*--------------------------------------------------------------------*/
time_t   current_time;

$char    dbgn[11],dend[11];
$char    ipolicy[21],icard[21],iengine[CA_ENGINE_NUM],dpolicy[11];
$char    dply_begin[11],dply_end[11],nassured[121];
$char    icar_type[3],iissue_ym[7],itag[9],iass4[5];
$char    ibrand[9],iins_type[7],fcard_class[2];
$long    mprem,mdmg_cover = 0,minj_cover,mdth_cover,mdeduct,mins_prem;
$char    note[2],nass_all[121],iofficer[11],ilast_ply[21];
$char    dbgn_ymd[9],dend_ymd[9],dpolicy_ymd[9],dissue_ym[7];

char     DBName[5];
FILE     *fp2;
char     sApHome[30];
char     filename2[50],pathname2[31];
/*--------------------------------------------------------------------*/
ca_edr_to_yl(db,dproc1)
char *db,*dproc1;
{
int      rc;

   strcpy(DBName,db);
   strcpy(dpolicy,dproc1);
/* strcpy(dbgn,dproc1);
   strcpy(dend,dproc2);*/
   current_time=time(NULL);

   rc = getApHome(sApHome);
   /* �ζ��P�ߪA�ȥd */
   sprintf_s(pathname2,sizeof pathname2,"%s/rptftp/yl/",sApHome);
   sprintf_s(filename2,sizeof filename2,"%sedr_%s_%ld.txt",pathname2,db,current_time);

   if ((fp2=fopen(filename2,"w")) == NULL) {
      printf("fopen error[%s]\n",filename2);
      return M_CM_FAILED;
   }
   
   /*----------------*/

   rc = read_edr_data();
   if (rc != M_CM_OK)
      return rc;

   fclose(fp2);

   return M_CM_OK;
}
/*--------------------------------------------------------------------*/
long read_edr_data()
{
int      dyy;
$char    fbenef[2];

   $whenever sqlerror goto errexit;

   if (db_select(DBName) == 0) {
        printf("M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
   }

   $declare cur_edr cursor for
     select distinct ipolicy
       into $ipolicy
       from edr_relation
      where dendorse = $dpolicy
        and fcard_class = '1'
        and iofficer[1] = 'A'
        and fedr_class not in ('A','B');
   $open    cur_edr;

   while(1) {
      $fetch cur_edr;
      if (SQLCODE == SQLNOTFOUND) break;

      $select a.icard,iengine,nassured,dply_begin,dpolicy,
            dply_end,icar_type,to_char(dissue,'%Y')::integer||to_char(dissue,'%m'),
            nvl(itag,' '), 
            ibrand,nvl(ilast_ply,' '),iofficer,mdamage_cover,
            iassured[7,10]
       into $icard,$iengine,$nass_all,$dply_begin,$dpolicy,
            $dply_end,$icar_type,$dissue_ym,$itag,
            $ibrand,$ilast_ply,$iofficer,$mdmg_cover,
            $iass4
       from ply_relation a,policy b,ply_ins_type c
      where a.ipolicy = $ipolicy
        and a.ipolicy = b.ipolicy
        and a.ipolicy = c.ipolicy;

      if (SQLCODE==SQLNOTFOUND) continue;
/*********�ζ��n�T�w����
      strcpy(ipolicy,trim(ipolicy));
      strcpy(icard,trim(icard));
      strcpy(iengine,trim(iengine));
      strcpy(nassured,trim(nass_all));
      strcpy(itag,trim(itag));
      strcpy(nass_all,trim(nass_all));
      strcpy(iofficer,trim(iofficer));
      strcpy(ilast_ply,trim(ilast_ply));
********/
      trans_date1(dply_begin,dbgn_ymd);
      trans_date1(dply_end,  dend_ymd);
      trans_date1(dpolicy,dpolicy_ymd);
      if (mdmg_cover==0)
         strcpy(note,"2");
      else
         strcpy(note,"1");
      fprintf(fp2,"%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s\n",
              ipolicy,icard,nass_all,iengine,itag,ilast_ply,
              dbgn_ymd,dend_ymd,dissue_ym,icar_type,iofficer,
              dpolicy_ymd,note,ibrand,iass4);

   }
   $close cur_edr;
   $free  cur_edr;

   return M_CM_OK;

errexit:
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/

/*--------------------------------------------------------------------*/
trans_date(dfrom,dtrans)
char *dfrom,*dtrans;
{
   char dtrans_tmp[20];
   sprintf_s(dtrans_tmp,sizeof dtrans_tmp,"%s/",substring(dfrom,7,4));
   strcpy( dtrans, dtrans_tmp);
   strncat(dtrans,dfrom,5);
}
/*--------------------------------------------------------------------*/
trans_date1(dfrom,dtrans)
char *dfrom,*dtrans;
{
   strcpy(dtrans,substring(dfrom,7,4));
   strcat(dtrans,substring(dfrom,1,2));
   strcat(dtrans,substring(dfrom,4,2));
}
/*--------------------------------------------------------------------*/
