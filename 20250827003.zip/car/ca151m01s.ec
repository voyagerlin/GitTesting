/************************************************/
/*   TABLE   : ca_terms                         */
/************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
$include "var_length.h";
#include "safeclib.h"

long car151(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    long rtncode;
    long car151_insert(),car151_single_query(),car151_multiple_query();
    long car151_update_exec();
    char option;

    cm_buf_init(command);
    cm_buf_get("%c",&option);
    switch(option)
    {
        case 'A': rtncode=car151_insert(reply);
                  break;
        case 'Q': rtncode=car151_single_query(reply);
                  break;
        case 'M': rtncode=car151_multiple_query(reply);
                  break;
        case 'D':
        case 'U': rtncode=car151_update_exec(reply,command,com_len);
                  break;
        default : 
                  return exitsub(reply,M_CM_WRONG_OPTION)?M_CM_WRONG_OPTION:apiRC;
    }
    return(rtncode);
}
/*-----------------------------------------------------------------*/
long car151_insert(reply)
serverReply reply;
{
    $char  DBName[5];
    $char  iins_type[11], deffect[11], iupdate[11], dcreate[11],icreate[11];
    $char  ncontent1[251], ncontent2[251], ncontent3[251], ncontract[21], qorder[6];
    $char  stmt[1024];

    int    tmp_len;
    long   MsgCode;

    cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s", DBName, iins_type, deffect, qorder, ncontract, ncontent1,ncontent2,ncontent3,icreate,dcreate,iupdate);

    strcpy(iins_type,  trim(iins_type));
    strcpy(ncontract, trim(ncontract));
    strcpy(ncontent1, trim(ncontent1));
    strcpy(ncontent2, trim(ncontent2));
    strcpy(ncontent3, trim(ncontent3));
    strcpy(icreate, trim(icreate));
    strcpy(iupdate,   trim(iupdate));
    strcpy(deffect,cm_to_infdate(deffect));

    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $BEGIN WORK;

    $WHENEVER SQLERROR GOTO errexit;

    if (strlen(trim(ncontent2)) == 0) strcpy(ncontent2," ");
    if (strlen(trim(ncontent3)) == 0) strcpy(ncontent3," ");
  $INSERT INTO ca_terms
     VALUES ($iins_type,$deffect,$qorder, $ncontract, $ncontent1, $ncontent2, $ncontent3, $iupdate, $dcreate, $iupdate, current year to second);

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);

    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return apiRC;
    }  
    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;
    return api_OKComplete;

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/*-----------------------------------------------------------------*/
long car151_single_query(reply)
serverReply reply;
{
    $char  DBName[5];
    $char  iins_type[11], deffect[11], iupdate[11], dcreate[11],icreate[11];
    $char  ncontent1[251], ncontent2[251], ncontent3[251], ncontract[21], qorder[6];
    $char  dupdate[41], ncreate[11], nupdate[11];
    $char  v_iins_type[11],v_ncontract[21];

    int    tmp_len;

    cm_buf_get("%s",DBName);

    cm_buf_get("%s %s ", v_iins_type, v_ncontract);

    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    printf( "SELECT ca_terms\n");
    $SELECT iins_type, deffect, qorder, ncontract, ncontent1, ncontent2, ncontent3, 
            icreate, dcreate, iupdate, dupdate
       INTO $iins_type, $deffect, $qorder, $ncontract, $ncontent1, $ncontent2, $ncontent3,
            $icreate, $dcreate, $iupdate, $dupdate
       FROM ca_terms
      WHERE iins_type = $v_iins_type
        AND ncontract = $v_ncontract;

    if(SQLCODE==SQLNOTFOUND) 
        return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND : apiRC;

    $SELECT nname INTO $ncreate
      FROM  officer
      WHERE iofficer = $icreate;
      if(SQLCODE==SQLNOTFOUND) strcpy(ncreate," ");
      
     $SELECT nname INTO $nupdate
      FROM  officer
      WHERE iofficer = $iupdate;
      if(SQLCODE==SQLNOTFOUND) strcpy(nupdate," ");
     
     strcpy(deffect,cm_from_infdate_100(deffect));
     
     
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s %s ", M_CM_OK, iins_type, deffect, qorder ,ncontract);
    cm_buf_put("%s %s %s %s %s %s", ncontent1, ncontent2,ncontent3, icreate, ncreate, dcreate);
    cm_buf_put("%s %s %s", iupdate,nupdate,dupdate);

    tmp_len = cm_buf_len(ReplyBuf);
    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}

/*-----------------------------------------------------------------*/
long car151_multiple_query(reply)
serverReply reply;
{
    $char  DBName[5], stmt[1024], stable[31], scolumn[101];

    $char  iins_type[11], deffect[11], iupdate[11], dcreate[11],icreate[11];
    $char  ncontent1[251], ncontent2[251], ncontent3[251], ncontract[21], qorder[6];
    $char  dupdate[41], ncreate[11], nupdate[11];
    $char  v_iins_type[11],v_ncontract[21];

    char   tmpbuf[4000], qryLog;
    int    count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int    i,total_count=0;
    $char  Tmtbuf[1024];

    printf("car151_multiple_query \n");
    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s ", v_iins_type, v_ncontract);

    strcpy( iins_type, trim(iins_type));
    strcpy( ncontract, trim(ncontract));

    $WHENEVER SQLERROR GOTO errexit;
    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    sprintf_s( stmt, sizeof stmt,
      "SELECT iins_type, deffect, qorder, ncontract,a.icreate,a.dcreate, "
      "       a.iupdate, a.dupdate, b.nname, c.nname"
      "  FROM ca_terms a, officer b, officer c"
      " WHERE a.iins_type  matches '%s'"
      "   AND a.ncontract   matches '%s'"
      "   AND a.icreate = b.iofficer"
      "   AND a.iupdate = c.iofficer"
      "   ORDER BY iins_type,ncontract ", v_iins_type, v_ncontract);

    $PREPARE prep3 FROM $stmt;
    $DECLARE q_cur CURSOR FOR prep3;
    $OPEN q_cur;
    for(;;)
    {
       $FETCH q_cur INTO $iins_type, $deffect, $qorder, $ncontract, $icreate,
                         $dcreate, $iupdate, $dupdate, $ncreate, $nupdate;

        if(SQLCODE != 0) break;

        cm_buf_init(tmpbuf);
        if( count == 0 )
        {
             cm_buf_res_msg();    /* reserve for MsgCode and count */
             cm_buf_res_count();
        }

        /** convert from DATE type to CY/MM/DD string **/

        strcpy(deffect, cm_from_infdate_100(deffect));
        cm_buf_put("%s", iins_type);
        cm_buf_put("%s", deffect);
        cm_buf_put("%s", qorder);
        cm_buf_put("%s", ncontract);
        cm_buf_put("%s", icreate);
        cm_buf_put("%s", ncreate);
        cm_buf_put("%s", dcreate);
        cm_buf_put("%s", iupdate);
        cm_buf_put("%s", nupdate);
        cm_buf_put("%s", dupdate);

        tmp_len = cm_buf_len(tmpbuf);

        if( tmp_len + repbuf_len < 3000 )
        {    /* buffer size less than 4K */
            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else
        {    /* more than 4K, send to client side */
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);

            if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {
                $CLOSE q_cur;
                return apiRC;
            }
            else
            {    /* clear ReplyBuf and count to start all over again */
                replycnt++;

                if(replycnt == 10)
                {    /* more than 30K, client cannot display,error */
                    cm_buf_init(ReplyBuf);
                    cm_buf_put("%l",M_CM_OUT_SPACE);
                    tmp_len = cm_buf_len(ReplyBuf);
                    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                        return apiRC;
                    return M_CM_OUT_SPACE;
                }

                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();    /* reserve for MsgCode and count */
                cm_buf_res_count();

		/*
                printf("BBB deffect[%s]\n",deffect);
                strcpy(deffect,cm_from_infdate_100(deffect));
                printf("AAA deffect[%s]\n",deffect);
		*/
                cm_buf_put("%s", iins_type);
                cm_buf_put("%s", deffect);
                cm_buf_put("%s", qorder);
                cm_buf_put("%s", ncontract);
                cm_buf_put("%s", icreate);
                cm_buf_put("%s", ncreate);
                cm_buf_put("%s", dcreate);
                cm_buf_put("%s", iupdate);
                cm_buf_put("%s", ncreate);
                cm_buf_put("%s", dupdate);

                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
            }
        }
    }   /* for loop */

    $CLOSE q_cur;
    if(count > 0)
    {    /* break out, at least one record is selected */
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if(SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
            return apiRC;
        return api_OKComplete;
    }
    else    /* break out, not any row is found */
    {
        return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND : apiRC;
    }

errexit:
    return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}

/*-----------------------------------------------------------------*/
long car151_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    $char  old_iins_type[11], old_deffect[11], old_iupdate[11], old_dcreate[11],old_icreate[11];
    $char  old_ncontent1[251], old_ncontent2[251], old_ncontent3[251], old_ncontract[21], old_qorder[6];
    $char  old_dupdate[41], old_ncreate[11], old_nupdate[11];

    $char  iins_type[11], deffect[11], iupdate[11], dcreate[11],icreate[11];
    $char  ncontent1[251], ncontent2[251], ncontent3[251], ncontract[21], qorder[6];
    $char  dupdate[41], ncreate[11], nupdate[11];
    $int   iRows;

    char   option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
    int    tmp_len,raw_len;
    long   dummy;
    long   MsgCode;
    char   tmp_buf[20];
    long   tmp_long;

    $char  DBName[5];

    comm = (char *) command;
    cm_buf_init(command);
    cm_buf_get("%c %s", &option, DBName);

    $WHENEVER SQLERROR GOTO errexit;

    if(db_select(DBName) == False) 
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    memcpy(&raw_len,&comm[com_len],sizeof(int));
    pos = &comm[com_len+sizeof(int)];
    raw_ptr = malloc(raw_len);
    if (raw_ptr != (char*)0)
     memcpy(raw_ptr,pos,raw_len);
    else
     {
      if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
       return M_CM_NOT_MALLOC;
      else
       return apiRC;
     }
   printf("raw_ptr[%s]\n", raw_ptr);

    cm_buf_init(raw_ptr);          /* get index key from old record */

    cm_buf_get("%s %s %s %s %s", &dummy, old_iins_type, old_deffect, old_qorder, old_ncontract);
    cm_buf_get("%s %s %s %s %s %s", old_ncontent1, old_ncontent2, old_ncontent3, old_icreate, old_ncreate, old_dcreate);
    cm_buf_get("%s %s %s", old_iupdate,old_nupdate,old_dupdate);

    $BEGIN WORK;

    $SELECT COUNT(*) INTO $iRows
       FROM ca_terms
      WHERE iins_type  = $old_iins_type
        AND ncontract = $old_ncontract;

    if (iRows == 0) /* compare 2 records, not equal */
    {
        $ROLLBACK WORK;
        if(exitsub(reply,M_CM_NOT_EQUAL) == True)
            return M_CM_NOT_EQUAL;
        else
            return apiRC;
    }

    /* equal, then exec DB operation */
    if( option == 'D' )
    {

         $DELETE FROM ca_terms
           WHERE iins_type = $old_iins_type
             AND ncontract = $old_ncontract;

         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OK);
         tmp_len = cm_buf_len(ReplyBuf);
         if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
         {
             $WHENEVER SQLERROR CONTINUE;
             $ROLLBACK WORK;
             return apiRC;
         }

         $WHENEVER SQLERROR GOTO errexit;
         $COMMIT WORK;
         return api_OKComplete;
    }
    else if(option == 'U')
    {
         printf("OPTION U");

         cm_buf_init(command);
         cm_buf_get("%c %s %s %s %s %s %s %s %s %s %s %s", &option,DBName, iins_type, deffect, qorder, ncontract, ncontent1,ncontent2, ncontent3,icreate,dcreate,iupdate);

         strcpy(iins_type,  trim(iins_type));
         strcpy(deffect, cm_to_infdate(deffect));
         strcpy(iupdate,   trim(iupdate));
         strcpy(ncontract,   trim(ncontract));
         strcpy(ncontent1,   trim(ncontent1));
         strcpy( old_iins_type, trim(old_iins_type));
         strcpy( old_ncontract, trim(old_ncontract));

         if (strlen(trim(ncontent2)) == 0) strcpy(ncontent2," ");
             $UPDATE ca_terms
                 SET deffect = $deffect,
                     qorder  = $qorder,
                     ncontent1 = $ncontent1,
                     ncontent2 = $ncontent2,
                     ncontent3 = $ncontent3,
                     iupdate = $iupdate,
                     dupdate = current year to second
               WHERE iins_type = $old_iins_type
                AND  ncontract = $old_ncontract;

         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OK);
         tmp_len = cm_buf_len(ReplyBuf);

         if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
         {
             $WHENEVER SQLERROR CONTINUE;
             $ROLLBACK WORK;
             return apiRC;
         }

         $WHENEVER SQLERROR GOTO errexit;
         $COMMIT WORK;
         return api_OKComplete;
    }
    else
    {
         return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
    }

errexit:
    MsgCode = SQLCODE;
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if( SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
