/************************************************/
/*                                              */
/*   PROGRAM : car140m01s.ec                    */
/*                                              */
/************************************************/
     
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"
$include sqlca;


long car140(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car140_insert(),car140_single_query(),car140_multiple_query(),car140_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);

 switch(option)
 {
  case 'A':
printf("=== 00 \n");
	   rtncode=car140_insert(reply);
	   break;
  case 'Q':
	   rtncode=car140_single_query(reply);
	   break;
  case 'M':
           rtncode=car140_multiple_query(reply);
	   break;
  case 'D':
  case 'U':
	   rtncode=car140_update_exec(reply,command,com_len);
	   break;
	case 'L':
     rtncode=car140_Kind_query(reply);
     break;
  default :
	   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
	    return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

long car140_insert(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table car_code */
 $char kind[3];
 $char detail[21],detail2[21],chiname[41],engname[41],userid[11];
 /* end of car_code */

 /* standard defined data */
 int tmp_len;
   DBinfo *list;
   int i, j, is_add_fail=0, api_f;
   $char stmt_buf[300];
   $char stmt_buf2[300];
 /* end of standard data */

 /* self defined data */
 long MsgCode;
 /* end of self data */

printf("=== 01 \n");
 cm_buf_get("%s",DBName);
printf("=== 02 \n");
/*
 cm_buf_get("%s %s %s %s %s",kind,detail,detail2,chiname,engname);
*/
 cm_buf_get("%s",kind);
printf("=== 02.1 \n");
 cm_buf_get("%s",detail);
printf("=== 02.2 \n");
 cm_buf_get("%s",detail2);
printf("=== 02.22\n");
 cm_buf_get("%s",chiname);
printf("=== 02.3 \n");
 cm_buf_get("%s",engname);
printf("=== 03 \n");
 cm_buf_get("%s",userid);
printf("=== 04 \n");
 
 if (db_select(DBName) == False) 
  { 
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }
 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 ) 
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }

 $BEGIN WORK;
 for(j=0;j<i;j++)
 {

  printf("i=[%d] j=[%d]\n", i, j );
  sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO %s:car_code (kind,detail,detail2,chiname,engname,icreate,dcreate,iupdate,dupdate) "
  		    " VALUES (?,?,?,?,?,?,current,?,current)" ,list[j].dbname);

  $PREPARE a_id FROM $stmt_buf;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  printf("kind=[%s] detail=[%s]\n", kind, detail );

  $EXECUTE a_id USING $kind,$detail,$detail2,$chiname,$engname,$userid,$userid;
  
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }

 /*�g�JLOG��*/
  sprintf_s(stmt_buf2, sizeof stmt_buf2, "INSERT INTO car_code_log (itype,kind,detail,detail2,chiname,engname,iupdate,dupdate) "
  		    " VALUES ('A','%s','%s','%s','%s','%s','%s',current)" ,kind,detail,detail2,chiname,engname,userid);

  $PREPARE add_log FROM $stmt_buf2;
  $EXECUTE add_log;

  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
   
printf("is_add_fail %d\n", is_add_fail );
   
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  tmp_len = cm_buf_len(ReplyBuf);
  if( j == i-1 )
     api_f = api_OKComplete;
  else
     api_f = api_OK;

  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    {
     is_add_fail = 2;
     break;
    }  
#ifdef DEBUG 
printf("INSERT %d\n", j+1);
#endif
 } /* for loop */

printf("is_add_fail %d\n", is_add_fail );

 if( is_add_fail == 1 ) goto errexit;

 if( is_add_fail == 2 ) 
  {
   $ROLLBACK WORK;
   return apiRC;
  }

 
 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

 errexit:
  $WHENEVER SQLERROR CONTINUE;    
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}

long car140_single_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table car_code */
 $char kind[3];
 $char detail[21],detail2[21],chiname[41],engname[41];
 $char icreate[11],dcreate[20],iupdate[11],dupdate[20];
 /* end of car_code */

 /* standard defined data */
 int tmp_len;
 /* end of standard data */

 /* self defined data */
 
 /* end of self data */
 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s %s",kind,detail,detail2);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 $SELECT chiname,engname,icreate,dcreate,iupdate,dupdate
  INTO $chiname,$engname,$icreate,$dcreate,$iupdate,$dupdate
  FROM car_code
  WHERE kind=$kind AND detail=$detail AND detail2=$detail2;

 if(SQLCODE==SQLNOTFOUND) 
  {
   if(exitsub(reply,M_CA_NCODE) == True) 
    return M_CA_NCODE; 
   else  
    return apiRC;
  }

 cm_buf_init(ReplyBuf); 
 cm_buf_put("%l",M_CM_OK);
 cm_buf_put("%s %s %s %s %s %s %s %s %s",kind,detail,detail2,chiname,engname,icreate,dcreate,iupdate,dupdate);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}

/*************************************************************************/
long car140_multiple_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table car_code */
 $char kind[3];
 $char detail[21],detail2[21],chiname[41],engname[41];
 $char tmp_kind[3];
 $char tmp_detail[21],tmp_detail2[21],tmp_chiname[41],tmp_engname[41];
 /* end of car_code */

 /* standard defined data */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0; 
 /* end of standard data */

 /* self defined data */
 
 /* end of self data */

 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s %s",kind,detail,detail2); 

printf("================== kind[%s] detail[%s]\n",kind,detail);
printf("================== detail2[%s]\n",detail2);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
 }

 $DECLARE q_cur CURSOR FOR
    SELECT kind,detail,detail2,chiname,engname
    INTO $tmp_kind, $tmp_detail, $tmp_detail2,
         $tmp_chiname, $tmp_engname
    FROM car_code
  WHERE kind matches $kind AND detail matches $detail 
                           AND detail2 matches $detail2
  ORDER BY kind, detail, detail2;

 $OPEN q_cur;

 for(;;)
  {
    $FETCH q_cur;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf); 
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();          
     }
    cm_buf_put("%s %s %s %s",tmp_kind,tmp_detail,tmp_detail2,tmp_chiname);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */ 
     { 
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
	    $CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE; 
        }
	   ReplyBuf[0] = '\0';
	   count = 0;
	   cm_buf_init(ReplyBuf);
       cm_buf_res_msg();           /* reserve for MsgCode and count */
       cm_buf_res_count();    
       cm_buf_put("%s %s %s %s",tmp_kind,tmp_detail,tmp_detail2,tmp_chiname);
	repbuf_len = cm_buf_len(ReplyBuf);
	count++;
       }
     } 
  } /* for loop */

 $CLOSE q_cur;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CA_NCODE) == True) 
    return M_CA_NCODE;
   else  
    return apiRC;
  } 

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}


long car140_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table car_code */
 $char kind[3],old_kind[3];
 $char detail[21],old_detail[21],chiname[41],engname[41];
 $char detail2[21],old_detail2[21];
 $char old_icreate[11],old_dcreate[20],old_iupdate[11],old_dupdate[20];
 $char icreate[11],dcreate[20],iupdate[11],dupdate[20];
 $char userid[11];
 /* end of car_code */

 /* standard defined data */
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len;
 long dummy=0;
   DBinfo *list;
   int i, j=0, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[300];
   $char stmt_buf2[300];
 /* end of standard data */

 /* self defined data */
 long MsgCode;
 /* end of self data */

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s %s",&option,DBName,userid);

printf("F001     \n");
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

printf("F002     \n");
 if( (list=get_db_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }
 /* compare old record and current record, if the record has not been changed  
    since last request, update or delete the record, otherwise return errmsg
    to client side */

printf("F003     \n");
 /* get old record info from command buffer */ 

 memcpy(&raw_len,&comm[com_len],sizeof(int));   
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
printf("F004     \n");
 if (raw_ptr != (char*)0)  
  memcpy(raw_ptr,pos,raw_len);
 else
  {
   if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */ 
    return M_CM_NOT_MALLOC;
   else  
    return apiRC;
  }
    
printf("F005     \n");
 cm_buf_init(raw_ptr);          /* get index key from old record */
 cm_buf_get("%l %s %s %s",&dummy,old_kind,old_detail,old_detail2);
 old_kind[2]='\0';

printf("F006     \n");
   $BEGIN WORK;                
 $SELECT chiname,engname,icreate,dcreate,iupdate,dupdate
  INTO $chiname,$engname,$old_icreate,$old_dcreate,$old_iupdate,$old_dupdate 
  FROM car_code
  WHERE kind=$old_kind AND detail=$old_detail AND detail2=$old_detail2;

printf("F007     \n");
  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */ 

 if (SQLCODE == SQLNOTFOUND)
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CM_NOT_FOUND) == True) 
    return M_CM_NOT_FOUND;
   else  
    return apiRC;
  }
printf("F008     \n");
   $WHENEVER SQLERROR GOTO errexit;

printf("F009     \n");
 cm_buf_init(cur_buf);
 cm_buf_put("%l %s %s %s %s %s %s %s %s %s"
            ,dummy,old_kind,old_detail,old_detail2,chiname,engname,old_icreate,old_dcreate,old_iupdate,old_dupdate);
            
 write(1,cur_buf,raw_len); printf("\n");
 write(1,raw_ptr,raw_len); printf("\n");           

 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   free(raw_ptr);
   if(exitsub(reply,M_CM_NOT_EQUAL) == True) 
    return M_CM_NOT_EQUAL;
   else  
    return apiRC;
  }
   $WHENEVER SQLERROR GOTO errexit;
  
 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
   /* for(j=0;j<i;j++)
   {
   */
    sprintf_s(stmt_buf, sizeof stmt_buf, "DELETE FROM car_code WHERE kind = ? "
	 " AND detail = ? AND detail2 = ?" ); 
    $PREPARE d_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      /* break; */
     }
    $EXECUTE d_id USING $old_kind,$old_detail,$old_detail2; 
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      /* break; */
     }
     
  /*�g�JLOG��*/
  sprintf_s(stmt_buf2, sizeof stmt_buf2, "INSERT INTO car_code_log (itype,kind,detail,detail2,chiname,engname,iupdate,dupdate) "
  		    " VALUES ('D','%s','%s','%s','%s','%s','%s',current)" ,old_kind,old_detail,old_detail2,chiname,engname,userid);

  $PREPARE add_log FROM $stmt_buf2;
  $EXECUTE add_log;

  if(SQLCODE != 0)
   {
    is_del_fail = 1;
   }
     
#ifdef DEBUG 
printf("Delete %d\n", j+1);
#endif
   /* } for loop */

   if( is_del_fail ) goto errexit;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
/* 9/3/1993    $BEGIN WORK;               */ 
   cm_buf_init(command);
   cm_buf_get("%c %s %s %s %s %s %s %s",&option,DBName,kind,
                                  detail,detail2,chiname,engname,userid); 
   kind[2]='\0';
                  
   $WHENEVER SQLERROR CONTINUE;
/*
   for(j=0;j<i;j++)
   {
*/
    sprintf_s(stmt_buf, sizeof stmt_buf, "UPDATE car_code "
   		" SET (kind,detail,detail2,chiname,engname,iupdate,dupdate) = (?,?,?,?,?,?,current) "
   		" WHERE kind = ? AND detail = ? AND detail2= ?");

    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      /* break; */
     }
    $EXECUTE u_id USING $kind,$detail,$detail2,$chiname,$engname,$userid,
                        $old_kind,$old_detail,$old_detail2;
                        
printf("+++stmt_buf[%s],sqlca.sqlerrd[2]=%d\n",stmt_buf,sqlca.sqlerrd[2]);

    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      /* break; */
     }
     
   /*�g�JLOG��*/
  sprintf_s(stmt_buf2, sizeof stmt_buf2, "INSERT INTO car_code_log (itype,kind,detail,detail2,chiname,engname,iupdate,dupdate) "
  		    " VALUES ('U','%s','%s','%s','%s','%s','%s',current)" ,kind,detail,detail2,chiname,engname,userid);

  $PREPARE add_log FROM $stmt_buf2;
  $EXECUTE add_log;
     if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      /* break; */
     }
     
    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {
  	sprintf_s(stmt_buf,"INSERT INTO car_code (kind,detail,detail2, "
  		" chiname,engname) VALUES (?,?,?,?,?)" );

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        /* break; */
       }
      $EXECUTE ua_id USING $kind,$detail,$detail2,$chiname,$engname;
printf("-----stmt_buf[%s]\n",stmt_buf);
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        /* break; */
       }
     }
#ifdef DEBUG 
printf("Update %d\n", j+1);
#endif
   /*} for loop */

   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True) 
    return M_CM_WRONG_OPTION;
   else  
    return apiRC;
  } 

 errexit:
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}


long car140_Kind_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table car_code */
 $char kind[3];
 $char detail[21],detail2[21],chiname[41],engname[41];
 $char tmp_kind[3];
 $char tmp_detail[21],tmp_detail2[21],tmp_chiname[41],tmp_engname[41];
 $char tmpString[3000];
 /* end of car_code */

 /* standard defined data */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0; 
 /* end of standard data */

 /* self defined data */
 
 /* end of self data */

 cm_buf_get("%s",DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
 }

 $DECLARE q_curL CURSOR FOR
    SELECT detail,chiname
    INTO $tmp_detail, $tmp_chiname
    FROM car_code
   where kind = '00'
  ORDER BY detail;

 $OPEN q_curL;

 for(;;)
  {
    $FETCH q_curL;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf); 
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();          
     }
    cm_buf_put("%s %s ",tmp_detail,tmp_chiname);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */ 
     { 
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
	    $CLOSE q_curL;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE; 
        }
	   ReplyBuf[0] = '\0';
	   count = 0;
	   cm_buf_init(ReplyBuf);
       cm_buf_res_msg();           /* reserve for MsgCode and count */
       cm_buf_res_count();    
       cm_buf_put("%s %s ",tmp_detail,tmp_chiname);
	repbuf_len = cm_buf_len(ReplyBuf);
	count++;
       }
     } 
  } /* for loop */

 $CLOSE q_curL;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CA_NCODE) == True) 
    return M_CA_NCODE;
   else  
    return apiRC;
  } 

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}