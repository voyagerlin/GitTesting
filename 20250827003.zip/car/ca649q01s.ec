/**********************************************************************/
/*   program id   : ca649q01s.ec                                      */
/*   program name : �j��Υ��N�I�u�f���B���X��ɮ��ˮ�                */
/*   date written : 2016/12/01 by 041090                              */
/*   files        :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "safeclib.h"
$char opt[2];
$char dbgn[11];
$char dend[11];
$char dday[5];
$char imgr[2];

int   count_db;
char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];

DBinfo *list;

main(argc, argv)
int argc;
char **argv;
{
 int rc;

	batchinit();
	strcpy(DBName,    isNULLstr(argv[1]));
	strcpy(userid,    isNULLstr(argv[2]));
	strcpy(opt,       isNULLstr(argv[3])); /*�ͮĤ��ñ���*/
	strcpy(dbgn,      isNULLstr(argv[4]));
	strcpy(dend,      isNULLstr(argv[5]));
	strcpy(dday,      isNULLstr(argv[6])); /*�t�Z�Ѽ�*/
	strcpy(imgr,      isNULLstr(argv[7])); /*�O�_�����ӥ�*/
	strcpy(outputf,   isNULLstr(argv[8]));
	
	rc = car649_get_db();
	if (rc != M_CM_OK)
		return rc;

	rc = car649_prepare_data();
	if (rc != M_CM_OK)
		return rc;

	rc = car649_build();
	if (rc != M_CM_OK) 
		return rc;
}

long car649_get_db()
{
	$whenever sqlerror goto errexit;

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car649_prepare_data()
{
 $char iassured1[13],ipolicy1[21],itag1[CA_TAG_NUM],iengine1[CA_ENGINE_NUM],dins_bgn1[11],dins_end1[11],iofficer1[11],nofficer1[11],iquota1[7],ileader1[11],irate_type1[2],dwritten1[11];
 $char dply_begin1[11],dply_end1[11],iassured_1[13],iengine_1[CA_ENGINE_NUM],iquota_1[7],iofficer_1[11],ileader_1[11];
 $char iassured2[13],ipolicy2[21],itag2[CA_TAG_NUM],iengine2[CA_ENGINE_NUM],dins_bgn2[11],dins_end2[11],iofficer2[11],nofficer2[11],iquota2[7],ileader2[11],irate_type2[2],dwritten2[11];
 $char dply_begin2[11],dply_end2[11],iassured_2[13],iengine_2[CA_ENGINE_NUM],iquota_2[7],iofficer_2[11],ileader_2[11];
 $char irate_type_1[6],irate_type_2[6];
 $int mprem1,mprem2,ddays;
 $char stmt[2048],stmt1[4096],stmp[128],stmp2[128],stmt2[2048],stmt3[2048],stmp3[128];
 $char sFullName[21];
 $char sys[20];
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == FALSE)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return FAIL;
	}

	$create temp table car649_tmp1
	(
	iassured1       char(12),
	ipolicy1        char(20),
	itag1           char(12),
	iengine1        char(25),
	dply_begin1     char(10),
	dply_end1       char(10),
	mprem1          int,
	dwritten1       char(20),
	iofficer1       char(10),
	iquota1         char(6),
	nofficer1      char(10),
	ileader1        char(10),
	irate_type1     char(5),
	iassured2       char(12),
	ipolicy2        char(20),
	itag2           char(12),
	iengine2        char(25),
	dply_begin2     char(10),
	dply_end2      char(10),
	mprem2          int,
	dwritten2       char(20),
	iofficer2       char(10),
	iquota2        char(6),
	nofficer2       char(10),
	ileader2        char(10),
	irate_type2     char(5),
	ddays          int
	) with no log;

	strcpy(dbgn,cm_to_infdate(dbgn));
	strcpy(dend,cm_to_infdate(dend));

	strcpy(opt, trim(opt));
	if (strcmp(opt,"B")==0)
	{
		strcpy( stmp, "a1.dins_bgn");
		strcpy( stmp3, "b.dins_bgn-a.dins_bgn");
	}
	else
	{
		strcpy( stmp, "a1.dwritten");
		strcpy( stmp3, "b.dwritten-a.dwritten");
	}
	strcpy(imgr, trim(imgr));
	if(strcmp(imgr,"1") == 0)
		strcpy( stmp2, "AND a3.imgr = '1'");
	else if(strcmp(imgr,"2") == 0)
		strcpy( stmp2, "AND a3.imgr != '1'");
	else
		strcpy( stmp2, " ");

	sprintf_s(stmt1, sizeof stmt1,
		"SELECT a1.iassured,trim(a1.ipolicy1||a1.ipolicy2) AS ipolicy ,a2.itarget1 AS itag,a2.ntarget1 AS iengine,a1.dins_bgn,a1.dins_end,  "
		"	a1.iofficer,a1.iquota,a3.nname AS nofficer,a1.ileader,a1.macct_prem AS mprem,a1.irate_type,a1.dwritten,a3.imgr  "
		"  FROM policy_main a1, policy_new a2, officer a3  "
		" WHERE a1.ipolicy1 = a2.ipolicy1  "
		"   AND a1.ipolicy2 = a2.ipolicy2  "
		"   AND a1.iendorsement = ' '  "
		"   AND a1.insure_type = 'C'  "
		"   AND a1.insure_level = 'C2'   "
		"   AND a1.iofficer = a3.iofficer  "
		"   %s   "
		"   AND a2.fstatus = 'G'  "
		"   AND %s BETWEEN '%s' AND '%s'  "
		"   INTO temp new1 WITH no log",stmp2,stmp,dbgn,dend ); 

	printf("stmt1[%s]\n", stmt1);
	$PREPARE pre1 FROM $stmt1;
	$EXECUTE pre1;

	sprintf_s(stmt2, sizeof stmt2,
		"SELECT a1.iassured,trim(a1.ipolicy1||a1.ipolicy2) AS ipolicy ,a2.itarget1 AS itag,a2.ntarget1 AS iengine,a1.dins_bgn,a1.dins_end,  "
		"	a1.iofficer,a1.iquota,a3.nname AS nofficer,a1.ileader,a1.macct_prem AS mprem,a1.irate_type,a1.dwritten,a3.imgr  "
		"  FROM policy_main a1, policy_new a2, officer a3  "
		" WHERE a1.ipolicy1 = a2.ipolicy1  "
		"   AND a1.ipolicy2 = a2.ipolicy2  "
		"   AND a1.iendorsement = ' '  "
		"   AND a1.insure_type = 'C'  "
		"   AND a1.insure_level = 'C1'   "
		"   AND a1.iofficer = a3.iofficer  "
		"   %s   "
		"   AND a2.fstatus = 'G'  "
		"   AND %s BETWEEN date('%s')-%s AND date('%s')+%s  "
		"   INTO temp new2 WITH no log",stmp2,stmp,dbgn,dday,dend,dday ); 

	printf("stmt2[%s]\n", stmt2);
	$PREPARE pre2 FROM $stmt2;
	$EXECUTE pre2;
	
	sprintf_s(stmt3, sizeof stmt3,
		"SELECT a.iassured,a.ipolicy,a.itag,a.iengine,a.dins_bgn,a.dins_end,a.dwritten,a.iofficer,a.iquota,  "
		"	a.nofficer,a.ileader,a.mprem,a.irate_type,  "
		"	b.iassured,b.ipolicy,b.itag,b.iengine,b.dins_bgn,b.dins_end,b.dwritten,b.iofficer,b.iquota,  "
		"	b.nofficer,b.ileader,b.mprem,b.irate_type,ABS(%s)  "
		"  FROM new1 a ,new2 b  "
		" WHERE a.imgr = b.imgr   "
		"   AND a.itag = b.itag  "
		"   AND a.iengine = b.iengine  "
		"   AND a.irate_type <> b.irate_type  "
		"   AND ABS(%s) <= %s",stmp3,stmp3,dday);
	printf("stmt3[%s]\n", stmt3);	    
	$PREPARE pre3 FROM $stmt3;
	$DECLARE cur_pre3 CURSOR for pre3;
	$OPEN cur_pre3;
	for(;;)
	{
		$FETCH cur_pre3 INTO $iassured1,$ipolicy1,$itag1,$iengine1,$dply_begin1,$dply_end1,$dwritten1,$iofficer1,$iquota1,
		 		     $nofficer1,$ileader1,$mprem1,$irate_type1,
				     $iassured2,$ipolicy2,$itag2,$iengine2,$dply_begin2,$dply_end2,$dwritten2,$iofficer2,$iquota2,
		 		     $nofficer2,$ileader2,$mprem2,$irate_type2,$ddays;
		
		if(SQLCODE == SQLNOTFOUND) break;
		
		strcpy(iassured_1, "�");
      		strcat(iassured_1,trim(iassured1));
      		
      		strcpy(iengine_1, "�");
      		strcat(iengine_1,trim(iengine1));

      		strcpy(iquota_1, "�");
      		strcat(iquota_1,trim(iquota1));

      		strcpy(iofficer_1, "�");
      		strcat(iofficer_1,trim(iofficer1));

      		strcpy(ileader_1, "�");
      		strcat(ileader_1,trim(ileader1));
      		
      		strcpy(iassured_2, "�");
      		strcat(iassured_2,trim(iassured2));
      		
      		strcpy(iengine_2, "�");
      		strcat(iengine_2,trim(iengine2));

      		strcpy(iquota_2, "�");
      		strcat(iquota_2,trim(iquota2));

      		strcpy(iofficer_2, "�");
      		strcat(iofficer_2,trim(iofficer2));

      		strcpy(ileader_2, "�");
      		strcat(ileader_2,trim(ileader2));
      		
      		if(strncmp(irate_type1,"C",1)==0)
      		strcpy(irate_type_1, "�����");
      		else
      		strcpy(irate_type_1, "�����");
      		
      		if(strncmp(irate_type2,"C",1)==0)
      		strcpy(irate_type_2, "�����");
      		else
      		strcpy(irate_type_2, "�����");
      		

		$INSERT INTO car649_tmp1 (iassured1,ipolicy1,itag1,iengine1,dply_begin1,dply_end1,mprem1,dwritten1,iofficer1,iquota1,nofficer1,ileader1,irate_type1,
					  iassured2,ipolicy2,itag2,iengine2,dply_begin2,dply_end2,mprem2,dwritten2,iofficer2,iquota2,nofficer2,ileader2,irate_type2,ddays)
				values ($iassured_1,$ipolicy1,$itag1,$iengine_1,$dply_begin1,$dply_end1,$mprem1,$dwritten1,$iofficer_1,$iquota_1,$nofficer1,$ileader_1,$irate_type_1,
				        $iassured_2,$ipolicy2,$itag2,$iengine_2,$dply_begin2,$dply_end2,$mprem2,$dwritten2,$iofficer_2,$iquota_2,$nofficer2,$ileader_2,$irate_type_2,$ddays);
	}
	$CLOSE cur_pre3;
	$FREE cur_pre3;
	
	return M_CM_OK;
	
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/


long car649_build()
{
 int rc;
 char sfilename[81],stitle[1024],stmt[1024];

	$WHENEVER SQLERROR GOTO errexit;

	strcpy(sfilename,"�j��Υ��N�I�u�f���B���X��ɮ��ˮ�[car649]");
	strcpy(stitle,"\t�{���N��:car649\�j��Υ��N�I�u�f���B���X��ɮ��ˮ�\t�L����:");
	strcat(stitle,cm_get_sysd());
	strcat(stitle,"\n");

	strcat(stitle,"\t�Q�O�I�H\t�O�渹�X\t����\t�������X\t�O�I�_��\t�O�I����\t�O�O\tñ����\t�g��N��\t���O\t�g��N���W��\t�޲z�H�W��\t�O�v�O\t");
	strcat(stitle,"�Q�O�I�H\t�O�渹�X\t����\t�������X\t�O�I�_��\t�O�I����\t�O�O\tñ����\t�g��N��\t���O\t�g��N���W��\t�޲z�H�W��\t�O�v�O\t�t�Z�Ѽ�\t");
	strcpy(stmt,"select * from car649_tmp1");

	rc = unload_file(outputf," ",sfilename,stitle,stmt);
	
	if (rc != SUCCESS) 
	{
	    sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}
