/************************************************/
/*   PROGRAM : ca306q01s.ec by Dennis Chang     */
/*   DATE    : 1993/10/04                       */
/*             1998/06/09                       */
/*             2001/07/23                       */
/************************************************/
#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include <malloc.h>
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
$include "var_length.h";
#include "safeclib.h"
#define DATENULL                0x80000000L

$int PgLine=0;
char OutFile[20];
FILE  *fptr;
/*** Screen Variable ***/
$char  char_dentry0[YYMMDD],char_dentry1[YYMMDD], dentry0[YYYYMMDD],dentry1[YYYYMMDD];
$char  ply_bgn[POLICY_NUM_1],ply_end[POLICY_NUM_1];
$char  sIbranch[BRANCH_ID], ileader[11];

/*** Report Variable ***/
$char  XIpolicy[POLICY_NUM_1];
$char  RIpolicy[POLICY_NUM_1];
$date  Today;
$char  old_iply[2];

/*****************************/
$char DBName[DBNAME];
$char  userid[USER_ID];
char  FormTp[3];
char  TitleFmt[N_FILE+1];
$char  outputf[20];
int   max_count=0,iPrintlist=0; /* 2008/04/17�s�W�ǤJ�@�Ѽ�iPrintlist,0���C�L�W�U,1�����L */
$int  ibatch_no;
$char list_print[2];
$int iCountFunsale=0;

/*** transno ***/
$char   ymd[12], iroute4[13], chb_ply[2];
$static char sTmpIbranch[BRANCH_ID], sTmpIcomp[BRANCH_ID];
$char   sTransno[21], ikind[2], sErrMsg[2048], xIquota[10],sTrans[21], PrintDlist[2], ProtectData[2];
$int    iSeqno=0;
$char   sTmp1[3600], sTmp2[600];
char s_prog[11], s_subject[101], s_file[101], s_err[101], tmpcmd[150];
FILE *fp;
$char mbuf[9000];
$char Errfile[60],outputf2[30];
char     sApHome[30];
/* ��r�y�� Add in 2006/09/27 by Julia */
char tmpword[3];
int iEplyCnt=0;/* 1061108001-SC4-�s��*/
static int iFpolicy;
static int iFbig;
$char chkoutprint[2];/*1061012002-SC3 ISID+rba*/

$char iprinter[11];
$char ichkform[2],formid[11],fprov[2];

$char fhide[2];

$char sToday1[11],sToday2[11];
$char skpid[12],skpid_tmp[12];

$char errmsg2[512];
$int  sqltmp=0;

long car306_build();
long ca_freeform_policy();
long car306_mailV7();
/*---------------------------------------------------------------------*/
main(argc,argv)
int argc;
char **argv;
{
    $int rc=0, rtncode=0;
    $int count_print=0;
	$char errmsg[512],v_sMsg[2048],stmp_free[1024];
	$char feply_tmp[2],iofficer_tmp[11],ileader_tmp[11];
	$int res=0,iTryCnt=0;
	$int cnt_no_ply=0;

	batchinit();
	strcpy(DBName,       isNULLstr(argv[1]));
	strcpy(userid,       isNULLstr(argv[2]));
	strcpy(char_dentry0, isNULLstr(argv[3]));
	strcpy(char_dentry1, isNULLstr(argv[4]));
	strcpy(sIbranch,     isNULLstr(argv[5]));
	strcpy(ileader,      isNULLstr(argv[6]));
	strcpy(ply_bgn,      isNULLstr(argv[7]));
	strcpy(ply_end,      isNULLstr(argv[8]));
	strcpy(ikind,        isNULLstr(argv[9]));
	strcpy(old_iply,     isNULLstr(argv[10]));  /* �P�_�O�_���«O��C�L */
	strcpy(list_print,   isNULLstr(argv[11]));  /* �P�_�O�_�C�L�W�U */
	strcpy(xIquota,      isNULLstr(argv[12]));  /* �~�Z��� */
	strcpy(PrintDlist,   isNULLstr(argv[13]));  /* �O�_�C�LD���ڦW�U:0:���L 1:�C�L */
	strcpy(ProtectData,  isNULLstr(argv[14]));  /* �Ӹ�B�n 0:���B�n 1:�B�n */
	strcpy(ichkform,     isNULLstr(argv[15]));  /* �j�r���O�� 1:�@�� 2:��j */
	strcpy(fprov,        isNULLstr(argv[16]));  /* ���� Y:������ N:�������� */
	strcpy(skpid,        isNULLstr(argv[17]));  /* Freeform.kpid */
	strcpy(outputf,      isNULLstr(argv[18]));

	$WHENEVER SQLERROR GOTO errexit;

    rc = getApHome(sApHome);
    if (rc<0) {
       strcpy(errmsg,"read Config file error!!-->getApHome\n");
       EWRITE(userid,rc,errmsg);
       return rc;
    }
    
    if (db_select(DBName) == False)  return M_CM_DB_NOTOPEN;
    
	/* V7�Ƶ{�A�nkpid */  
	/* �����W */
    /*if(strncmp(skpid,"V",1) == 0)  
    {
    	$BEGIN WORK;
    	strcpy(sToday1,cm_edate_str(cm_today()));
		strcpy(sToday2,cm_cdate_str_100(cm_today()));
    	strcpy(skpid_tmp," ");
    	
    	printf("res=[%d] sToday1=[%s] sToday2=[%s] skpid_tmp=[%s] \n",res,sToday1,sToday2,skpid_tmp);
    	res = cm_get_serial_num_dwritten("CM","FREEFORM","0","00",sToday1,sToday2,skpid_tmp);

		iTryCnt = 0;
		RETRY:
		if (res != 0) {
		    iTryCnt++;
		    if (iTryCnt > 3) 
		    { 
		    	strcpy(sErrMsg, "kpid�������ѡA���ݤU���Ƶ{����ΤH�u����");
				EWRITE(userid, 0, errmsg);
				$ROLLBACK WORK;
		    	return res;
			}
		    sleep(1);
		    goto  RETRY;
		}
		
		printf("res=[%d] sToday1=[%s] sToday2=[%s] skpid_tmp=[%s] \n",res,sToday1,sToday2,skpid_tmp);
		strcpy(skpid_tmp,trim(skpid_tmp));
		strcpy(skpid,skpid_tmp);
		$COMMIT WORK;
    }
    else {}*/

	if(ichkform[0] == '1')
		strcpy(formid,"CARPLY001");
	else 
		strcpy(formid,"CARPLY002");

	strcpy(dentry0, cm_to_infdate(char_dentry0));
	strcpy(dentry1, cm_to_infdate(char_dentry1));
	rtoday(&Today);
	/* �~�� */
	strcpy(ymd,cm_cdate_str(Today));
	/* ������c */
	strncpy(sTmpIbranch, sIbranch, 2);
	sTmpIbranch[2] = '\0';
	/* �����q */
	strncpy(sTmpIcomp, sIbranch+2, 1);
	sTmpIcomp[1] = '\0';

	iPrintlist = atoi(list_print);           /* �O�_�C�L�W�U */

    printf("*****before car306_build() dentry0[%s]dentry1[%s]\n",dentry0,dentry1);
    printf("ply_bgn[%s],ply_end[%s]\n",ply_bgn,ply_end);

	if (sIbranch[0]=='*' || sIbranch[0]==' ' || sIbranch[0]=='\0')
	strcpy(sIbranch, "*");

	/* �إ�temp table ------------------------------------------------------ */
	$create temp table tmp_tb
	(
		ipolicy			char(20),      -- �O�渹
		fprint          char(1),       -- �i�_�C�L�O��
		errmsg			char(255),     -- ���~�T��
		ftype_pol       char(2),       --JC:�F���ۼ�,SP:�S�O�ĳq
		iestimate       char(20)
	) with no log;
	/* --------------------------------------------------------------------- */
	
	/* 1111019012_C05_���I�Φ����O���Freeform�L�s�}�o(�q�l�O��) - �D�ɲ���fversion�A�����ɷs�Wfversion */
	/* �إ�temp freedtl_tmp------------------------------------------------------ */
	$create temp table freedtl_tmp
	(
		kpid     CHAR (11)     NOT NULL,
		iins_cat CHAR (1)      NOT NULL,
		ipolicy  CHAR (20)     NOT NULL,
		iendorse CHAR (20)     NOT NULL,
		icard    CHAR (20)     NOT NULL,
		feply    CHAR (1)      NOT NULL,
		fversion CHAR (2)      NOT NULL,
		fstatus  INTEGER       NOT NULL,
		iofficer CHAR (10)     NOT NULL,
		ileader  CHAR (10)     NOT NULL,
		iserl    CHAR (10)     NOT NULL,
		nnote    VARCHAR (255) NOT NULL
	) with no log;
	/* --------------------------------------------------------------------- */
	
	if (ProtectData[0] == '1') strcpy(fhide,"Y");
	else strcpy(fhide,"N");
	
	/* INSERT cm_freeform     kpid       ����Ǹ�,   iins_cat �I�O,       formid�M�L�O,      fprint   �C�L�O, fformal �����O, 
	                          fhide      �Ӹ�����,   fnote    ���C�L�Ƶ�, fbranch�C�L����O, fpolicy �O��O, 
	                          fcondition �C�L���ڧO, iprinter �L�����N�� */

	$INSERT INTO cm_freeform (kpid, iins_cat, formid, fprint, fformal, 
	                          fhide, fnote, fbranch, fpolicy,
	                          fcondition, iprinter, ipgid, iupdate, tstime, tetime)
	                  VALUES ($skpid, 'C', $formid, ' ', 'F',
	                          $fhide, ' ', ' ', ' ', 
	                          ' ',  ' ', 'car306a', $userid, current, NULL);

	rc = car306_chkpolicy();
	if (rc != M_CM_OK)
	{
		sprintf_s(errmsg, sizeof errmsg,"�O����ˮֲ��`[%d]",rc);
		$INSERT INTO freedtl_tmp VALUES($skpid,'C',' ',' ',' ',' ',' ',199,' ',' ',' ',$errmsg);
		return rc;
	}

	strcpy(feply_tmp," ");
	strcpy(iofficer_tmp," ");
	strcpy(ileader_tmp," ");

	$select count(ipolicy) into $count_print
	   from tmp_tb
	  where fprint <> 'Y';
	if (count_print > 0)
	{
		$DECLARE PLY_CUR_B1 CURSOR FOR
		  SELECT ipolicy, errmsg
		    FROM tmp_tb
		   WHERE fprint <> 'Y';
		$OPEN PLY_CUR_B1;
		while (1)
		{
			$FETCH PLY_CUR_B1 INTO $XIpolicy, $errmsg;
			if (SQLCODE == SQLNOTFOUND) break;
			
			strcpy(XIpolicy, trim(XIpolicy));
			strcpy(errmsg, trim(errmsg));
			
			$SELECT feply,iofficer,ileader
			   INTO $feply_tmp,$iofficer_tmp,$ileader_tmp
			   FROM ply_relation 
			  WHERE ipolicy = $XIpolicy;

			$INSERT INTO freedtl_tmp VALUES($skpid,'C',$XIpolicy,' ',' ',$feply_tmp,' ',199,$iofficer_tmp,$ileader_tmp,' ',$errmsg);
			printf("XIpolicy=[%s]errmsg=[%s]\n",XIpolicy,errmsg);
		}
		$close PLY_CUR_B1;
		$free PLY_CUR_B1;
	}

    rc=car306_build();
    printf("car306_build[%d]\n",rc);

    if (rc == M_CA_NREL_PLY)
    {
        strcpy(errmsg,"�O��w�L�L�Χ䤣�즹�O�渹");
        cnt_no_ply = 0;
        $Select count(*) INTO $cnt_no_ply From freedtl_tmp;
        if(cnt_no_ply == 0) $INSERT INTO freedtl_tmp VALUES($skpid,'C',' ',' ',' ',' ',' ',199,' ',' ',' ',$errmsg);
        /*rtncode=car306_mailV7();
        return rc;*/
    }
    else if (rc == M_CA_TOBE_NO_PRINT)
    {
		strcpy(errmsg,"�C�L���O�欰�M�׷~�ȡA�G�N����ܫO�椺�e���!");
		$INSERT INTO freedtl_tmp VALUES($skpid,'C',' ',' ',' ',' ',' ',199,' ',' ',' ',$errmsg);
        /*rtncode=car306_mailV7();
        return rc;*/
    }
    else if (rc == M_CA_NESTIMATE)
    {
		strcpy(errmsg,"�t�Φ��L���A�еy�ԦA����!");
		$INSERT INTO freedtl_tmp VALUES($skpid,'C',' ',' ',' ',' ',' ',199,' ',' ',' ',$errmsg);
        /*rtncode=car306_mailV7();
        return rc;*/
    }
    else if (rc != M_CM_OK)
    {
        sprintf_s(errmsg, sizeof errmsg," \���~�T���N�� [%d]",rc);
        printf("skpid[%s] errmsg[%s] \n",skpid,errmsg);
        $INSERT INTO freedtl_tmp VALUES($skpid,'C',' ',' ',' ',' ',' ',199,' ',' ',' ',$errmsg);
        /*rtncode=car306_mailV7();
        return rc;*/
    }

	/* UPDATE cm_freeform.tetime */
	$UPDATE cm_freeform
	    SET tetime = CURRENT
	  WHERE kpid = $skpid;

    sprintf_s(stmp_free, sizeof stmp_free,"INSERT INTO cm_freeform_dtl "
                        "SELECT kpid, iins_cat, ipolicy, iendorse, icard, feply, ' ', fstatus, iofficer, ileader, iserl, nnote, '%s', CURRENT FROM freedtl_tmp",userid);
	$PREPARE insert_dtl FROM $stmp_free;
	$EXECUTE insert_dtl;
	
	if(strcmp(sApHome,"/TEST/IPIS")==0) printf("sApHome[%s]\n",sApHome);
	else if (strcmp(sApHome,"/DEV/IPIS")==0) printf("sApHome[%s]\n",sApHome);
	else 
	{
    	rtncode=car306_mailV7();
    	if (rc != M_CM_OK) return rc;
	}
	
    printf("*****after car306_build() dentry0[%s]dentry1[%s]\n",dentry0,dentry1);

	$DROP TABLE freedtl_tmp;
    strcpy(errmsg,"�pCMN201���A���uF�v�B����{���N�����ucar306a�v�A�Ц�CMN545�T�{�O����檬�A");
	EWRITE(userid, 0, errmsg);
	return 0;
    
errexit:
    printf("SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

long car306_mailV7()
{
    int rc=0,rt=0;
    $char sApHome[31];
    if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
    {
        rt = getApHome(sApHome);
        if (rt < 0) {
            printf("read Config file error!!\n");
            return M_CM_READ_CONFIG_ERR;
        }
        printf("outputf[%s]\n", outputf);
        sprintf_s(s_file, sizeof s_file, "%s/rptftp/Car306_%s.txt",sApHome, outputf);
        printf("s_file[%s]\n", s_file);

        sprintf_s(tmpcmd, sizeof tmpcmd,"rm %s", s_file);
        system(tmpcmd);

        if ((fp=fopen(s_file, "a")) == 0) printf("open file error! Exit Program\n");
        fprintf(fp, "%s\n", mbuf);
        fclose(fp);

        strcpy(s_prog, "CAR306");
        strcpy(s_subject, "V7�O��C�L-�۰ʱƵ{�B�z���G�q��");

        /* �H���Ū�� cu_code_data.itype='DO' */
        rc=FA_send_mail(s_prog, s_subject, s_file, s_err);
        return M_CM_OK;
    }    
    return M_CM_OK;
}
/******************************************************************************/
long car306_build()
{
    int    count=0;
    int    count_no_tobe=0;
    int    rc=0;
    $char  FormFile[N_FILE+1];
    $char  stmt[400];
    $char  tmp_policy[POLICY_NUM_1];
    $char  sTmpbgn1[POLICY_NUM_1], sTmpend1[POLICY_NUM_1];
    $char  sTmpbgn2[POLICY_NUM_1], sTmpend2[POLICY_NUM_1];
    $date  dDpolicy;
    $date  dDply_close;
    $short no_null;
    $char  nbenef_tmp[43], nbenef[43];
    $char  sTmpiofficer[11], sIresource[2], sIbroker[11], sIquota[11], sIleader[11];
    $char  nequipment14[2];
    $char  nequipment[31];
    $char  itmp_pol_a[21], tmp_transno[21], v_sMsg[512], v_sMsgtmp[512];
    char fbusiness[2], ibroker_top[11], bzfrom[3];
    $long  mcommission=0;
    $char  sIcomm_obj[11], sIroute_comm[4], sIroute_prop[3], sIroute[21];
    $char fprint[2], serrmsg[512], fstatus[3], sIestimate[21], ftype_pol[3];
    $int  count_pass, count_receive;
    $char sIassured[13],sIapplicant[13];
    $int iCountDeny;
    $char sFeply2[2],sIcomp_in[3],sAemail_eply[51],sDply_end[11],sDply_bgn[11];
    $char sFeply1[2],sIcard1[21],sDpolicy1[11],sIquota1[7],sNassured1[121],sPasswd[13];
    $char sIrelative_ply[21],sIserial[12],date[11],dToday[11],ireceipt[21];
    $char yyyy[5];
    long t=0;
    $int res=0;
    $datetime year to second dt_dprint;
    $char e_nfile[36];
    $int fspeed=0;
    $char tmobile_eply[21];
    $char iserl[11];
    $int  ieplyfree_chk=0;
    
    /* �q�l�O���ˮ���� */
	$char sNplyidx1[256], sNplyidx2[1001], sNplyidx3[5001]; 

	$WHENEVER SQLERROR GOTO errexit;
	$SET LOCK MODE TO WAIT;
	
	iEplyCnt = 0 ; 
	iFpolicy = TRUE;   /*�H�O�渹�C�L*/
	iFbig = FALSE;     /*�L�j�O��J�`*/
	count = 0;
	count_no_tobe = 0;
	
	if (ply_bgn[0]=='*' || ply_bgn[0]==' ' || ply_bgn[0]=='\0')
	{
	    iFpolicy = FALSE;
	    iFbig = FALSE;
	}
	
	if (ply_end[0]=='*' || ply_end[0]==' ' || ply_end[0]=='\0')
	{
	    iFpolicy = FALSE;
	    iFbig = FALSE;
	}

	if (iFpolicy)
	{
		rc = split_policy(ply_bgn, sTmpbgn1, sTmpbgn2);
		if (rc !=  M_CM_OK) return rc;
		rc = split_policy(ply_end, sTmpend1, sTmpend2);
		if (rc !=  M_CM_OK) return rc;
		
		if (strcmp(sTmpbgn1, sTmpend1) != 0)
		{
			strcpy(ply_bgn, sTmpbgn1);
			strcpy(ply_end, sTmpend1);
			iFbig = FALSE;
		}
		else
		{
			if (strlen(sTmpbgn2) == CAR_TARGET_LEN &&
			    strlen(sTmpend2) == CAR_TARGET_LEN)
			{
			    if (strcmp(sTmpbgn2, sTmpend2) == 0) iFbig = FALSE;
			    else iFbig = TRUE;
			}
			else
			{
			    strcpy(ply_bgn, sTmpbgn1);
			    strcpy(ply_end, sTmpend1);
			    iFbig = FALSE;
			}
		}

		ibatch_no=0;
	}
	else ibatch_no = 0;
	
	printf("ply_bgn[%s],ply_end[%s] \n",ply_bgn,ply_end);
	/* 104.01.09 �ư��M�ץ� */
	if (iFpolicy)
	{
		$DECLARE PLY_CUR_2 CURSOR FOR
		  SELECT a.ipolicy , a.iofficer , a.iresource , a.dpolicy, a.dply_close, a.ibroker,
		         a.iquota, a.mlia_commi + a.mdmg_commi, a.ileader,
		         a.icomm_obj, a.iroute_comm, b.iroute, b.iroute_prop,
		         c.iestimate,a.irelative_ply,
		         (select iroute_main from cm_route where iroute = b.iroute),
		         c.ftype_pol, b.iassured,b.iapplicant,a.feply,a.icomp_in,a.aemail_eply,a.dply_end,
		         b.iassured,a.tmobile_eply,year(today),a.dply_begin
		    FROM ply_relation a, policy b, tmp_tb c
		   WHERE a.ipolicy = b.ipolicy
		     AND a.ipolicy = c.ipolicy
		     AND b.ipolicy = c.ipolicy
		     AND c.fprint='Y'
		     AND a.fcard_class='2'
		     AND a.dpolicy is NULL
		     AND a.dply_close is NULL
		     AND a.ileader matches $ileader
		     AND a.iquota matches $xIquota
		     AND (a.ipolicy >= $ply_bgn AND a.ipolicy <= $ply_end)
		     AND (a.iofficer[1] not in ('W','N') and not (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) )
		   ORDER BY a.ipolicy;
		printf("-----> into PLY_CUR_2\n");
    }
	else
	{   
		if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
		{
			/*�u�L�D�j�O��*/
			$DECLARE PLY_CUR_4 CURSOR FOR
			  SELECT a.ipolicy , a.iofficer , a.iresource , a.dpolicy , a.dply_close, a.ibroker,
			         a.iquota, a.mlia_commi + a.mdmg_commi, a.ileader,
			         a.icomm_obj, a.iroute_comm, b.iroute, b.iroute_prop,
			         c.iestimate,a.irelative_ply,
			         (select iroute_main from cm_route where iroute = b.iroute),
			         c.ftype_pol,b.iassured,b.iapplicant,a.feply,a.icomp_in,a.aemail_eply,a.dply_end,
			         b.iassured,a.tmobile_eply,year(today),a.dply_begin
			    FROM ply_relation a, policy b, tmp_tb c
			   WHERE a.ipolicy = b.ipolicy
			     AND a.ipolicy = c.ipolicy
			     AND b.ipolicy = c.ipolicy
			     AND c.fprint='Y'
			     AND a.dentry between $dentry0 and $dentry1
			     AND a.ileader matches $ileader
			     AND a.ipolicy[1,3] MATCHES $sIbranch
			     AND a.ipolicy[6,7] = 'V7'
			     AND a.fcard_class='2'
			     AND a.dpolicy is NULL
			     AND a.dply_close is NULL
			     AND LENGTH(a.ipolicy) = 13
			     AND a.ileader matches $ileader
			     AND a.iquota matches $xIquota
			     AND (a.iofficer[1] not in ('W','N') and not (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) )
			   ORDER BY a.ipolicy;
			printf("-----> into PLY_CUR_4\n");
		}
		else
		{
			/*�u�L�D�j�O��*/
			$DECLARE PLY_CUR_3 CURSOR FOR
			  SELECT a.ipolicy , a.iofficer , a.iresource , a.dpolicy , a.dply_close, a.ibroker,
			         a.iquota, a.mlia_commi + a.mdmg_commi, a.ileader,
			         a.icomm_obj, a.iroute_comm, b.iroute, b.iroute_prop,
			         c.iestimate,a.irelative_ply,
			         (select iroute_main from cm_route where iroute = b.iroute),
			         c.ftype_pol,b.iassured,b.iapplicant,a.feply,a.icomp_in,a.aemail_eply,a.dply_end,
			         b.iassured,a.tmobile_eply,year(today),a.dply_begin
			    FROM ply_relation a, policy b, tmp_tb c
			   WHERE a.ipolicy = b.ipolicy
			     AND a.ipolicy = c.ipolicy
			     AND b.ipolicy = c.ipolicy
			     AND c.fprint='Y'
			     AND a.dentry between $dentry0 and $dentry1
			     AND a.ileader matches $ileader
			     AND a.ipolicy[1,3] MATCHES $sIbranch
			     AND a.fcard_class='2'
			     AND a.dpolicy is NULL
			     AND a.dply_close is NULL
			     AND LENGTH(a.ipolicy) = 13
			     AND a.ileader matches $ileader
			     AND a.iquota matches $xIquota
			     AND (a.iofficer[1] not in ('W','N') and not (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) )
			   ORDER BY a.ipolicy;
			printf("-----> into PLY_CUR_3\n");
		}
	}

	if (iFpolicy)
		$OPEN PLY_CUR_2;
	else
	{
		if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
			$OPEN PLY_CUR_4;
		else 
			$OPEN PLY_CUR_3;
	}

    $BEGIN WORK;

	while (1)
	{
        XIpolicy[0]='\0';
        if (iFpolicy)
        {
			$FETCH PLY_CUR_2 INTO $XIpolicy, $sTmpiofficer , $sIresource , $dDpolicy, $dDply_close,
			                      $sIbroker, $sIquota, $mcommission, $sIleader,
			                      $sIcomm_obj, $sIroute_comm, $sIroute, $sIroute_prop,
			                      $sIestimate, $sIrelative_ply, $iroute4, $ftype_pol, $sIassured, $sIapplicant, $sFeply2,$sIcomp_in,
			                      $sAemail_eply,$sDply_end,$sPasswd,$tmobile_eply,$yyyy,$sDply_bgn;
		}
        else
        {
			if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
			{
				$FETCH PLY_CUR_4 INTO $XIpolicy, $sTmpiofficer , $sIresource , $dDpolicy, $dDply_close,
				                      $sIbroker, $sIquota, $mcommission, $sIleader,
				                      $sIcomm_obj, $sIroute_comm, $sIroute, $sIroute_prop,
				                      $sIestimate, $sIrelative_ply, $iroute4, $ftype_pol, $sIassured, $sIapplicant, $sFeply2,$sIcomp_in,
				                      $sAemail_eply,$sDply_end,$sPasswd,$tmobile_eply,$yyyy,$sDply_bgn;
			}
			else 
			{
				$FETCH PLY_CUR_3 INTO $XIpolicy, $sTmpiofficer , $sIresource , $dDpolicy, $dDply_close,
				                      $sIbroker, $sIquota, $mcommission, $sIleader,
				                      $sIcomm_obj, $sIroute_comm, $sIroute, $sIroute_prop,
				                      $sIestimate, $sIrelative_ply, $iroute4, $ftype_pol, $sIassured, $sIapplicant, $sFeply2,$sIcomp_in,
				                      $sAemail_eply,$sDply_end,$sPasswd,$tmobile_eply,$yyyy,$sDply_bgn;
			}
		}
        if (SQLCODE == SQLNOTFOUND) break;

		/* �ˮ֭Ӹ�O�_����ϥ�  add by sylvia 103.02.17 (1020924002_C2)
		   ����car306_chkpolicy�ˮ�*/
		strcpy(iroute4, trim(iroute4));
		strcpy(sIroute, trim(sIroute));
		printf("ipolicy=[%s], iroute4[%s]\n",XIpolicy, iroute4);
		
		if ((dDpolicy != DATENULL) || (dDply_close != DATENULL)) continue;
		printf("404:XIpolicy=[%s]\n",XIpolicy);
		count++;
		
		strcpy(sTmpiofficer, trim(sTmpiofficer));
		printf("sTmpIcomp[%s],sTmpIbranch[%s],ymd[%s]\n", sTmpIcomp, sTmpIbranch, ymd);
		
		/*------------------------------------------------------------------ */
		strcpy(sTmpiofficer, trim(sTmpiofficer));
		
		printf("sTmpiofficer[%s],sFeply2[%s],chkoutprint[%s] \n",sTmpiofficer,sFeply2,chkoutprint);
		
		/* �g��N����W99999BE�ɡAW99999IF,W99999IS, �h�𶷻s�@������ */
		if( (strncmp(sTmpiofficer,"W",1)==0) && (strncmp(sTmpiofficer+6,"LE30",4)!=0) )
		{
		    /* �E�M�a�x�M�׻ݦL�O�� */
		    /* Do not call ca_rpt_policy() */
		}
		else if ( (strncmp(sTmpiofficer,"F9813501",7)==0) || (strncmp(sTmpiofficer,"F9814201",7)==0) )
		{
		     /* Do not call ca_rpt_policy() */
		}
        else
        {
			if((strcmp(sFeply2,"1") == 0))
			{
				/* FreeForm���q�l�O��A���W���ҥ� */
				/*
				ieplyfree_chk = 0;
				$SELECT count(*) 
				   INTO $ieplyfree_chk 
				   FROM cm_code_data
				  WHERE itype = '11'
				    AND icode1 = 'C'
				    AND icode2 = 'EPLYFREE'
				    AND ncode1 = 'Y';
				
				if (ieplyfree_chk > 0)
				{
					/* �����s�q�l�O��Afprov_yn��Y�A�n���s���� *
					/*rc=ca_freeform_policy(XIpolicy, "", ibatch_no, ikind, iPrintlist, userid, PrintDlist, ProtectData, DBName, "0" ,skpid, &iserl, sFeply2, "Y", formid, "car306a", "Y", v_sMsg);*
					rc=ca_freeform_policy(XIpolicy, "", ikind, iPrintlist, userid, PrintDlist, ProtectData, "0" ,skpid, &iserl, sFeply2, "Y", formid, "car306a", "Y", sNplyidx1, sNplyidx2, sNplyidx3, " ", v_sMsg);
					printf("--rc[%d]]\n",rc);
					if (rc != M_CM_OK)
					{
						sprintf(v_sMsgtmp, "%s %s",v_sMsg,cm_get_errmsg(rc));
						/* For�̫�@�q�P�_�A���^��ñ��� *
						$UPDATE tmp_tb SET fprint = 'N',errmsg = $v_sMsgtmp WHERE ipolicy = $XIpolicy;
						$INSERT INTO freedtl_tmp VALUES($skpid,'C',$XIpolicy,' ',' ',$sFeply2,' ','199',$sTmpiofficer,$sIleader,' ',$v_sMsgtmp);
						continue;
					}
				}*/
				
				/* 1060328006_C1 �s�W�q�l�O�椽�ΫH�c(�q�ӳ��ϥ�) */
				if (strcmp(sIroute,"JB") == 0) strcpy(sIcomp_in , "88");
				/*�P�_�r�y��V7-->�ֳt��*/
				fspeed=1;
				if (strncmp(XIpolicy+5,"V7",2)==0) fspeed=2;

				/* �q�l�O�椣�ݦL�X�ȥ���ơA�ݱN�O���Ƽg�J�q�l�O������ */
				/*�O�o���ɦW*/
				strcpy(e_nfile,"");
				strcat(e_nfile,"P17CAR_");
				strcat(e_nfile,trim(XIpolicy));
				strcat(e_nfile,"_");
				strcat(e_nfile,trim(yyyy));
				strcpy(e_nfile,trim(e_nfile));

				/*�O�o�q�l�O��*/
				/*$INSERT INTO cm_e_policy(iins_cat,ipolicy,iendorse,iserno,ftype,fspeed,iins_kind_ply,iendorse_ti,
				                         fprocess,fdata,ibranch_code,icustomer,npassword,nemai_send,tsms_mobile,
				                         nfile,dbgn,dend,fstatus,iapplicant,iassured,ientry,dentry,iupdate,dupdate,
				                         nplyidx1,nplyidx2,nplyidx3,nedridx1,nedridx2,nedridx3,ifreeform)
				                 VALUES ('C',$XIpolicy,' ','01','2',$fspeed,'C2',' ',
				                         'A','P',$sIcomp_in,$sIapplicant,$sPasswd,$sAemail_eply,$tmobile_eply,
				                         $e_nfile,$sDply_bgn,$sDply_end,100,$sIapplicant,$sIassured,$userid,CURRENT,$userid,CURRENT,
				                         $sNplyidx1,$sNplyidx2,$sNplyidx3,' ',' ',' ',$skpid);*/
				$INSERT INTO cm_e_policy(iins_cat,ipolicy,iendorse,iserno,ftype,fspeed,iins_kind_ply,iendorse_ti,
				                         fprocess,fdata,ibranch_code,icustomer,npassword,nemai_send,tsms_mobile,
				                         nfile,dbgn,dend,fstatus,iapplicant,iassured,ientry,dentry,iupdate,dupdate,
				                         nplyidx1,nplyidx2,nplyidx3,nedridx1,nedridx2,nedridx3)
				                 VALUES ('C',$XIpolicy,' ','01','2',$fspeed,'C2',' ',
				                         'A','P',$sIcomp_in,$sIapplicant,$sPasswd,$sAemail_eply,$tmobile_eply,
				                         $e_nfile,$sDply_bgn,$sDply_end,100,$sIapplicant,$sIassured,$userid,CURRENT,$userid,CURRENT,
				                         ' ',' ',' ',' ',' ',' ');
                         
				iEplyCnt ++;
				strcpy(sIrelative_ply,trim(sIrelative_ply));

				/* �q�l��O���� */
				if(strlen(sIrelative_ply) > 0)
				{
					$SELECT a.feply,a.icard,nvl(a.dpolicy," "),a.iquota,b.nassured
					   INTO $sFeply1,$sIcard1,$sDpolicy1,$sIquota1,$sNassured1
					   FROM ply_relation a,policy b
					  WHERE a.ipolicy = b.ipolicy
					    AND a.ipolicy = $sIrelative_ply;
				
					if (SQLCODE != SQLNOTFOUND)
					{
						if(strcmp(sFeply1,"2") == 0)
						{
							strcpy(sDpolicy1,trim(sDpolicy1));
							
							if(strlen(sDpolicy1) == 0)
							{
								$update ply_relation
								    set feply = '0'
								  where ipolicy = $sIrelative_ply;
							}
						}
					}
				}
			}
			else
			{
				printf("IN 644ca_freeform_policy\n");
				/* 1061012002-SC3 ISID+rba�j���I�G�����X��@�~���L��� ���N�I ���ܦL��@�~���L���*/
				chkoutprint[0] = '\0';
				$select fout_print into $chkoutprint
				   from ply_relation
				  where ipolicy = $XIpolicy;
				if(chkoutprint[0] !='1')/* 1061012002-SC3 ISID+rba�j���I�G�����X��@�~���L��� ���N�I ���ܦL��@�~���L���*/
				{
					rc=ca_freeform_policy(XIpolicy, "", ikind, iPrintlist, userid, PrintDlist, ProtectData, "0" ,skpid, &iserl, sFeply2, fprov, formid, "car306a", "Y", sNplyidx1, sNplyidx2, sNplyidx3, " ", v_sMsg);
					printf("--rc[%d]]\n",rc);
					if (rc != M_CM_OK)
					{
						sprintf_s(v_sMsgtmp, sizeof v_sMsgtmp, "%s %s",v_sMsg,cm_get_errmsg(rc));
						/* For�̫�@�q�P�_�A���^��ñ��� */
						$UPDATE tmp_tb SET fprint = 'N',errmsg = $v_sMsgtmp WHERE ipolicy = $XIpolicy;
						$INSERT INTO freedtl_tmp VALUES($skpid,'C',$XIpolicy,' ',' ',$sFeply2,' ','199',$sTmpiofficer,$sIleader,' ',$v_sMsgtmp);
						continue;
					}
				}
				printf("OUT 663ca_freeform_policy\n");
			}
			count_no_tobe ++;
		}
		
		printf("�^���@�γ������� \n");
		printf("sIestimate[%s],XIpolicy[%s],sIassured[%s] \n",sIestimate,XIpolicy,sIassured);
		/* �^���@�γ������� ---------------------------------------------- */
		rc = Upd_Cm_pre_receive(sIestimate, XIpolicy, sIassured);
		if (rc != SUCCESS)
		{
			$ROLLBACK WORK;
			return rc;
		}
		
		$UPDATE ply_relation
		    SET fprint = "1",
		        dpolicy = $Today
		  WHERE fcard_class = '2'
		    AND dply_close is NULL
		    AND dpolicy is NULL
		    AND ipolicy = $XIpolicy;

		/* INSERT cm_freeform_dtl tmp table */    
		printf("INSERT cm_freeform_dtl tmp table \n");
        chkoutprint[0] = '\0';
		$select fout_print into $chkoutprint
		   from ply_relation
		  where ipolicy = $XIpolicy;
        if(chkoutprint[0] !='1')/* 1061012002-SC3 ISID+rba�j���I�G�����X��@�~���L��� ���N�I ���ܦL��@�~���L���*/
		{	
			if((strcmp(sFeply2,"1") == 0))
				$INSERT INTO freedtl_tmp VALUES($skpid,'C',$XIpolicy,' ',' ',$sFeply2,' ','100',$sTmpiofficer,$sIleader,' ','�wñ��A�ݫ���Ƶ{���s�q�l�O��');
			else 
        		$INSERT INTO freedtl_tmp VALUES($skpid,'C',$XIpolicy,' ',' ',$sFeply2,' ','100',$sTmpiofficer,$sIleader,$iserl,' ');
        }
        else
        {
        	$INSERT INTO freedtl_tmp VALUES($skpid,'C',$XIpolicy,' ',' ',$sFeply2,' ','600',$sTmpiofficer,$sIleader,' ','�e�~��A�ȩ�Wñ���');
		}
        /*if (iFpolicy && iFbig) break; */
	}
    printf("------>iFpolicy [%d]\n", iFpolicy);
    printf("------>iFbig [%d]\n", iFbig);

	if (iFpolicy)
	{
		$CLOSE PLY_CUR_2;
		$FREE PLY_CUR_2;
	}
	else
	{
		if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
		{	
			$CLOSE PLY_CUR_4;
			$FREE PLY_CUR_4;
		}
		else 
		{
			$CLOSE PLY_CUR_3;
			$FREE PLY_CUR_3;
		}
	}

	if (count == 0)
	{
		$ROLLBACK WORK;
		return M_CA_NREL_PLY;
	}
    printf("count_no_tobe[%d],count[%d]\n",count_no_tobe, count);
    /* �C�L�h�i�O��������ζ�TOBE�M�׮ɡA�h��ܤ��o�C�L�O�椺�e���T�� */
    if ((count_no_tobe == 0) && (count != 0))
    {
        printf("1\n");
        $COMMIT WORK;
        return M_CA_TOBE_NO_PRINT;
    }

	if (iFpolicy)
	{
		printf("strlen(ply_bgn)[%d] , CAR_PLY_TAG_LEN[%d]\n", strlen(ply_bgn) , CAR_PLY_TAG_LEN);
		
		$UPDATE ply_relation
		    SET fprint = "1", dpolicy = $Today
		  WHERE fcard_class = '2'
		    AND dply_close is NULL
		    AND dpolicy is NULL
		    AND LENGTH(ipolicy) = 13
		    AND (ipolicy >= $ply_bgn
		    AND  ipolicy <= $ply_end)
		    AND ileader matches $ileader
		    AND iquota matches $xIquota
		    AND ipolicy in (select ipolicy from tmp_tb where fprint = 'Y')
		    AND (iofficer[1] not in ('W','N') and not (iofficer[1] = 'H' and iofficer[2] not in ('0','1','2')) );
	}
	else
	{
		$UPDATE ply_relation
		    SET fprint = "1", dpolicy = $Today
		  WHERE dentry between $dentry0 and $dentry1
		    AND ipolicy[1,3] MATCHES $sIbranch
		    AND fcard_class='2'
		    AND dply_close is NULL
		    AND dpolicy is NULL
		    AND LENGTH(ipolicy) = 13
		    AND ileader matches $ileader
		    AND iquota matches $xIquota
		    AND ipolicy in (select ipolicy from tmp_tb where fprint = 'Y')
		    AND (iofficer[1] not in ('W','N') and not (iofficer[1] = 'H' and iofficer[2] not in ('0','1','2')) );
	}

    $COMMIT WORK;
    return M_CM_OK;
    
errexit:
	printf("SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
	sqltmp = SQLCODE;
	$ROLLBACK WORK;
    return sqltmp;
}
/******************************************************************************/
long car306_chkpolicy()
{
	int    count=0;
	int    count_no_tobe=0;
	int    rc;
	$char  FormFile[N_FILE+1];
	$char  stmt[400];
	$char  tmp_policy[POLICY_NUM_1];
	$char  sTmpbgn1[POLICY_NUM_1], sTmpend1[POLICY_NUM_1];
	$char  sTmpbgn2[POLICY_NUM_1], sTmpend2[POLICY_NUM_1];
	$date  dDpolicy;
	$date  dDply_close;
	$short no_null;
	$char  nbenef_tmp[43], nbenef[43];
	$char  sTmpiofficer[11], sIbroker[11], sIquota[11], sIleader[11];
	$char  nequipment14[2];
	$char  nequipment[31];
	$char  itmp_pol_a[21], tmp_transno[21], v_sMsg[512];
	char fbusiness[2], ibroker_top[11], bzfrom[3];
	$long  mcommission=0;
	$char  sIcomm_obj[11], sIroute_comm[4], sIroute_prop[3], sIroute[21];
	/* ���O�X�� */
	$char	sIestimate[21], sAbn_type[2], sImgr[2];
	$char sIpolicy1[21], sIpolicy2[21], dply_begin[11], iins_kind[2];
	$char deffect4[11];
	$int  iCountJC=0, iCountEW=0, ifuw_status=0, iCountSP=0;
	$double mprem=0,mnt1=0;
	$int  iCntSP1=0, iCntSP2=0, iCntSP3=0, iCntSP4=0, iCntSP5=0, iCountDeny=0;
	$char sIassured[13];
	$char sPassPrint[2] = " " , ChkPlyType[3] = " " ;
	$int  ichk_status=0;
	$char ipass_policy[POLICY_NUM_1];
    
    /* --------------------------------------------------------------------- */
    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    iFpolicy = TRUE;   /*�H�O�渹�C�L*/
    iFbig = FALSE;     /*�L�j�O��J�`*/
    count = 0;
    count_no_tobe = 0;
    iCountSP = iCntSP1 = iCntSP2 = iCntSP3 = iCntSP4 = iCntSP5 = 0;
    sTmp1[0]= '\0';
    sTmp2[0]= '\0';

    if (ply_bgn[0]=='*' || ply_bgn[0]==' ' || ply_bgn[0]=='\0')
    {
        iFpolicy = FALSE;
        iFbig = FALSE;
    }

    if (ply_end[0]=='*' || ply_end[0]==' ' || ply_end[0]=='\0')
    {
        iFpolicy = FALSE;
        iFbig = FALSE;
    }

	if (iFpolicy)
	{
		rc = split_policy(ply_bgn, sTmpbgn1, sTmpbgn2);
		if (rc !=  M_CM_OK) return rc;
		rc = split_policy(ply_end, sTmpend1, sTmpend2);
		if (rc !=  M_CM_OK) return rc;
		
		if (strcmp(sTmpbgn1, sTmpend1) != 0)
		{
		    strcpy(ply_bgn, sTmpbgn1);
		    strcpy(ply_end, sTmpend1);
		    iFbig = FALSE;
		}
		else
		{
		    if (strlen(sTmpbgn2) == CAR_TARGET_LEN &&
		        strlen(sTmpend2) == CAR_TARGET_LEN)
		    {
		        if (strcmp(sTmpbgn2, sTmpend2) == 0 && strlen(sTmpend2) == 0) iFbig = FALSE;
		        else iFbig = TRUE;
		    }
		    else
		    {
		        strcpy(ply_bgn, sTmpbgn1);
		        strcpy(ply_end, sTmpend1);
		        iFbig = FALSE;
		    }
		}
		printf("sTmpbgn1------------>[%s]\n",sTmpbgn1);
		if (strlen(ply_bgn) == CAR_PLY_TAG_LEN)
		{
	        $SELECT MAX(ibatch_no)+1
	           INTO $ibatch_no:no_null
	           FROM ply_relation a
	          WHERE ipolicy[1,13]= $sTmpbgn1
	            AND dply_close IS NOT NULL
	            AND ileader matches $ileader
	            AND iquota matches $xIquota;
	        if (SQLCODE == SQLNOTFOUND || no_null==-1) ibatch_no=1;
		}
		else ibatch_no=0;
	}
	else ibatch_no = 0;

	if (iFpolicy)
	{
		$DECLARE PLY_CUR_A2 CURSOR FOR
		  SELECT a.ipolicy , a.iofficer , a.dpolicy, a.dply_close, a.ibroker,
		         a.iquota, a.mlia_commi + a.mdmg_commi, a.ileader,
		         a.icomm_obj, a.iroute_comm, b.iroute, b.iroute_prop,
		         (select iroute_main from cm_route where iroute = b.iroute),
		         b.iassured
		    FROM ply_relation a, policy b
		   WHERE a.ipolicy = b.ipolicy
		     AND a.fcard_class='2'
		     AND a.dpolicy is NULL
		     AND a.dply_close is NULL
		     AND a.ileader matches $ileader
		     AND a.iquota matches $xIquota
		     AND (a.ipolicy >= $ply_bgn AND a.ipolicy <= $ply_end)
		   ORDER BY a.ipolicy;
		printf("-----> into PLY_CUR_2\n");
	}
    else
    {   
		if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
		{
		    $DECLARE PLY_CUR_A4 CURSOR FOR
		      SELECT a.ipolicy , a.iofficer , a.dpolicy , a.dply_close, a.ibroker,
		             a.iquota, a.mlia_commi + a.mdmg_commi, a.ileader,
		             a.icomm_obj, a.iroute_comm, b.iroute, b.iroute_prop,
		             (select iroute_main from cm_route where iroute = b.iroute),
		             b.iassured
		        FROM ply_relation a, policy b
		       WHERE a.ipolicy = b.ipolicy
		         AND a.dentry between $dentry0 and $dentry1
		         AND a.ileader matches $ileader
		         AND a.iquota matches $xIquota
		         AND a.ipolicy[1,3] MATCHES $sIbranch
		         AND a.ipolicy[6,7] = 'V7'
		         AND a.fcard_class='2'
		         AND a.dpolicy is NULL
		         AND a.dply_close is NULL
		         AND LENGTH(a.ipolicy) = 13
		       ORDER BY a.ipolicy;
		    printf("-----> into PLY_CUR_A4\n");
		}
		else 
		{
			/*�u�L�D�j�O��*/
			$DECLARE PLY_CUR_A3 CURSOR FOR
			  SELECT a.ipolicy , a.iofficer , a.dpolicy , a.dply_close, a.ibroker,
			         a.iquota, a.mlia_commi + a.mdmg_commi, a.ileader,
			         a.icomm_obj, a.iroute_comm, b.iroute, b.iroute_prop,
			         (select iroute_main from cm_route where iroute = b.iroute),
			         b.iassured
			    FROM ply_relation a, policy b
			   WHERE a.ipolicy = b.ipolicy
			     AND a.dentry between $dentry0 and $dentry1
			     AND a.ileader matches $ileader
			     AND a.iquota matches $xIquota
			     AND a.ipolicy[1,3] MATCHES $sIbranch
			     AND a.fcard_class='2'
			     AND a.dpolicy is NULL
			     AND a.dply_close is NULL
			     AND LENGTH(a.ipolicy) = 13
			   ORDER BY a.ipolicy;
			printf("-----> into PLY_CUR_3\n");
		}
	}

	if (iFpolicy)
		$OPEN PLY_CUR_A2;
	else
	{
		if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
			$OPEN PLY_CUR_A4;
		else 
			$OPEN PLY_CUR_A3;
	}

	while (1)
	{
		XIpolicy[0]='\0';
		/*----------------------------------------------------------------*/
		if (iFpolicy)
		{
			$FETCH PLY_CUR_A2 INTO $XIpolicy, $sTmpiofficer , $dDpolicy, $dDply_close,
		                           $sIbroker, $sIquota, $mcommission, $sIleader,
		                           $sIcomm_obj, $sIroute_comm, $sIroute, $sIroute_prop, $iroute4,
		                           $sIassured;
		}
        else
		{
			if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
				$FETCH PLY_CUR_A4 INTO $XIpolicy, $sTmpiofficer , $dDpolicy, $dDply_close,
			                           $sIbroker, $sIquota, $mcommission, $sIleader,
			                           $sIcomm_obj, $sIroute_comm, $sIroute, $sIroute_prop, $iroute4,
			                           $sIassured;
			else
				$FETCH PLY_CUR_A3 INTO $XIpolicy, $sTmpiofficer , $dDpolicy, $dDply_close,
			                           $sIbroker, $sIquota, $mcommission, $sIleader,
			                           $sIcomm_obj, $sIroute_comm, $sIroute, $sIroute_prop, $iroute4,
			                           $sIassured;
		}
        if (SQLCODE == SQLNOTFOUND) break;

        strcpy(iroute4, trim(iroute4));
        printf("ipolicy=[%s], iroute4[%s]\n",XIpolicy, iroute4);
        strcpy(ipass_policy,trim(XIpolicy));

        if ((dDpolicy != DATENULL) || (dDply_close != DATENULL)) continue;
		
		if (strncmp(XIpolicy+5,"EB",2)==0 || strncmp(XIpolicy+5,"VW",2)==0)
        {
			$select itmp_policy into $sIestimate
			   from ply_relation
			  where ipolicy = $XIpolicy;
       		$insert into tmp_tb (ipolicy, fprint, errmsg, ftype_pol, iestimate) values ($XIpolicy, 'Y',' ','0', $sIestimate);
       		continue;
    	}
		
		if( sTmpiofficer[0] != 'W')
		{
			/* �t�X�q���ĤG���q, ��H�@��function�ˮ� */
			rc = cm_chk_policy("1", sTmpiofficer, " ", " ", " ", " ", " ", " ");
			if( rc != M_CM_OK)
			{
			    strcpy(v_sMsg, trim(cm_get_errmsg(rc)));
			    /* �g�Jtemp table,���O����C�L,�ø���U�@�� */
			    $insert into tmp_tb (ipolicy,  fprint, errmsg)
			     values             ($XIpolicy,   'N', $v_sMsg);
			    continue;
			}
		}

		/* �t�X�q���ĤG���q, ��H�@��function�ˮ� */
		rc = cm_chk_policy("2", " ", " ", sIquota, " ", " ", " ", " ");
		if( rc != M_CM_OK)
		{
			strcpy(v_sMsg, trim(cm_get_errmsg(rc)));
			/* �g�Jtemp table,���O����C�L,�ø���U�@�� */
			$insert into tmp_tb (ipolicy,  fprint, errmsg)
			 values             ($XIpolicy,   'N', $v_sMsg);
			continue;
		}

		/* �I����H�O�_����X�� */
		rc = cm_chk_policy("4", " ", " ", " ", sIcomm_obj, " ", " ", " ");
		if( rc != M_CM_OK)
		{
			strcpy(v_sMsg, trim(cm_get_errmsg(rc)));
			/* �g�Jtemp table,���O����C�L,�ø���U�@�� */
			$insert into tmp_tb (ipolicy,  fprint, errmsg)
			 values             ($XIpolicy,   'N', $v_sMsg);
			continue;
		}

		/* �I����H���L�X���� */
		rc = cm_chk_policy("6", " ", " ", " ", sIcomm_obj, "C", " ", " ");
		if( rc != M_CM_OK)
		{
		    strcpy(v_sMsg, trim(cm_get_errmsg(rc)));
			/* �g�Jtemp table,���O����C�L,�ø���U�@�� */
			$insert into tmp_tb (ipolicy,  fprint, errmsg)
			  values            ($XIpolicy,   'N', $v_sMsg);
			continue;
		}

		/* �I����H��10000,������ add by sylvia 100.06.22 */
		if((strcmp(trim(sIcomm_obj),"10000") == 0)  && (mcommission > 0))
		{
			strcpy(v_sMsg, trim(cm_get_errmsg(rc)));
			/* �g�Jtemp table,���O����C�L,�ø���U�@�� */
			$insert into tmp_tb (ipolicy,  fprint, errmsg)
			  values            ($XIpolicy,   'N', $v_sMsg);
			continue;
		}

		/* �q���N���P�q���ۭq�~�ȥN���������Y�O�_���T add by sylvia 100.06.22 */
		rc = cm_chk_policy("7", " ", " ", " ", " ", " ", sIroute, sIroute_prop);
		if( rc != M_CM_OK)
		{
			strcpy(v_sMsg, trim(cm_get_errmsg(rc)));
			/* �g�Jtemp table,���O����C�L,�ø���U�@�� */
			$insert into tmp_tb (ipolicy,  fprint, errmsg)
			  values            ($XIpolicy,   'N', $v_sMsg);
			continue;
		}

		/*�ˮ֬O�_�f�ֳq�L�Afsign_status>=30 ---------------------------------*/
		/*1091021005_SC5_�s�W�A�Ȥ��ߩ�����*/
		ichk_status=0;
		$SELECT count(*) INTO $ichk_status FROM ply_relation WHERE ipolicy = $XIpolicy AND fsign_status>=30;
		
		if  (ichk_status == 0)
		{
			sprintf_s(v_sMsg, sizeof v_sMsg, "�O�渹[%s]���i�L��A�]���`�����q�|���f�֩��", XIpolicy);
			/* �g�Jtemp table,���O����C�L,�ø���U�@�� */
			$insert into tmp_tb (ipolicy,  fprint, errmsg)
			values            ($XIpolicy,   'N', $v_sMsg);
			continue;
		}

		/* �ˮ֭Ӹ�O�_����ϥ�  add by sylvia 103.02.17 (1020924002_C2) */
		iCountDeny=0;
		iCountFunsale=0;
		$select count(*) into $iCountDeny
		   from cm_personal_deny
		  where iassured = $sIassured
		    and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1] = '1')
		    and ddeny <= today
		    and (dexpire is null or dexpire >= today);
		
		if  (iCountDeny > 0)
		{
			sprintf_s(v_sMsg, sizeof v_sMsg, "�O�渹[%s]�Ӹ갱��ϥ�", XIpolicy);
			/* �g�Jtemp table,���O����C�L,�ø���U�@�� */
			$insert into tmp_tb (ipolicy,  fprint, errmsg)
			values            ($XIpolicy,   'N', $v_sMsg);
			continue;
		}

        /* �ˮ֬O�_�e�~�C�L  add by sylvia 103.03.13 (1010523004_C3)  */
        /* 1061012002-SC3 ISID+rba�j���I�G�����X��@�~���L��� ���N�I ���ܦL��@�~���L���*/
		chkoutprint[0] = '\0';
		$select fout_print,itmp_policy into $chkoutprint,$sIestimate
		   from ply_relation
		  where ipolicy = $XIpolicy;
         
        /*  1031111001_C1 ���O�X������{���վ�  */
		#if _CA_VERSION == 1 
			printf("-- trace _CA_VERSION = 1\n ");

		/*  1041013003_C1_car320.car301.car401��������(F)��J�ި�  */ 
		strcpy(sPassPrint,"N");
		rc = check_ca_id_officer(XIpolicy," ",sPassPrint,v_sMsg);
		if( rc != M_CM_OK || sPassPrint[0]=='N' )
		{
			/* �g�Jtemp table,���O����C�L,�ø���U�@�� */
			strcpy(v_sMsg, trim(cm_get_errmsg(rc)));
			printf("-- trace v_sMsg[%s]\n ",v_sMsg);	             
			$insert into tmp_tb (ipolicy,  fprint, errmsg)
			   values            ($XIpolicy,   'N', $v_sMsg);
			continue;
		}

		strcpy(sPassPrint,"N"); strcpy(ChkPlyType," ");
		rc = chk_policy_print(XIpolicy,sPassPrint,ChkPlyType,v_sMsg);
		if( rc != M_CM_OK || sPassPrint[0]!='Y' )
		{
			/* �g�Jtemp table,���O����C�L,�ø���U�@�� */
			printf("-- trace v_sMsg[%s]\n ",v_sMsg);
			$insert into tmp_tb (ipolicy,  fprint, errmsg)
			values            ($XIpolicy,   'N', $v_sMsg);
			continue;
		}
		
		#else
		printf("-- trace _CA_VERSION <> 1\n ");
		$SELECT a.itmp_policy, b.iabn_type, c.imgr,
		        case when b.iroute[1,2] = 'JC' then (select count(detail) from car_code where kind = '26' and detail = b.iassured) else 0 end ,
		        a.ipolicy[1,13],
		        case when a.ipolicy[6,7] = 'VW' then 1 else 0 end,
		        case when length(trim(a.ipolicy)) > 13 then a.ipolicy[14,17] else ' ' end,
		        case when trim(b.iabn_type) <> '' then nvl((select fuw_status from newa00:abnormal_ply where iabnormal = a.itmp_policy),-100)
		        else nvl((select fuw_status from estimate where iestimate = a.itmp_policy),-100) end,
		        (select count(icode) from ca_permit where iclass = '01' and (dexpire is null or dexpire > today) and trim(icode) <> '' and icode = b.iassured),
		        (select count(icode) from ca_permit where iclass = '02' and (dexpire is null or dexpire > today) and trim(icode) <> '' and icode = b.itag),
		        (select count(icode) from ca_permit where iclass = '03' and (dexpire is null or dexpire > today) and trim(icode) <> '' and icode = b.iengine),
		        (select count(icode) from ca_permit where iclass = '04' and (dexpire is null or dexpire > today) and trim(icode) <> '' and icode = b.iroute[1,2]),
		        (select count(icode) from ca_permit where iclass = '05' and (dexpire is null or dexpire > today) and trim(icode) <> '' and icode =
		        (select iroute_main from cm_route where iroute = b.iroute)), (mdmg_prem + mlia_prem), dply_begin
		   INTO $sIestimate, $sAbn_type, $sImgr, 
		        $iCountJC,
		        $sIpolicy1, 
		        $iCountEW, 
		        $sIpolicy2, 
		        $ifuw_status,
		        $iCntSP1, 
		        $iCntSP2, 
		        $iCntSP3, 
		        $iCntSP4, 
		        $iCntSP5,
		        $mprem, $dply_begin
		   FROM ply_relation a, policy b, officer c
		  WHERE a.ipolicy = b.ipolicy and a.iofficer = c.iofficer
		    AND a.fcard_class = '2' and a.dpolicy is null
		    AND a.ipolicy = $XIpolicy
		    AND a.ileader matches $ileader
		    AND a.iquota matches $xIquota;

		iCountSP = iCntSP1 + iCntSP2 + iCntSP3 + iCntSP4 + iCntSP5 ;

		printf("XIpolicy=[%s]mprem=[%ld]ileader=[%s]xIquota=[%s]\n",XIpolicy,mprem,ileader,xIquota);
		if ((ifuw_status == -1) || (ifuw_status >= 600))
		{
			/* �¬y�{�S����,�i�H���`�C�L�O�� & �鵲 */
			printf("�¬y�{�S����,�i�H���`�C�L�O�� & �鵲 :XIpolicy=[%s]\n",XIpolicy);
		}
		else if (iCountJC > 0)
		{
			/* �F���ۼХ�(JC) */
			 printf("�F���ۼХ�(JC) :XIpolicy=[%s]\n",XIpolicy);
		}
		else if (iCountEW > 0)
		{
			/* �O�T�I(EW) */
			printf("�O�T�I(EW :XIpolicy=[%s]\n",XIpolicy);
		}
		else if (iCountSP > 0)
		{
			/* �ĳq�ץ�(SP) */
			printf("�ĳq�ץ�(SP) :XIpolicy=[%s]\n",XIpolicy);
		}
		else if ((ifuw_status == -100 ) || ((ifuw_status >=500) && (ifuw_status < 600)))
		{
			/* ���I�պ��ɬd�L���,�i��O��O��αM�ץ�; 500/510 ���`���O�X��y�{ */
			$select fuw_status,	iestimate
			   into $ifuw_status, $sIestimate
			   from estimate
			  where ipolicy2 = $sIpolicy1 and dentry >= add_months(today,-6);
			printf("979:ifuw_status=[%d]sIestimate=[%s]\n",ifuw_status,sIestimate);

			if (SQLCODE == SQLNOTFOUND) ifuw_status = 500; /* �������ɧ䤣��, ���ӬO��O���(B2B�B�@���barcode) */
			if (ifuw_status == -1)
			{
				/*�¬y�{,�i���`�X��鵲 */
				printf("�¬y�{,�i���`�X��鵲 :XIpolicy=[%s]\n",XIpolicy);
			}
			else
			{
				/* ��@�γ������ɸ�� */
				$select unique ipre_rcv, iins_kind into $sIestimate, $iins_kind
				   from cm_pre_receive
				  where ipolicy1 = $sIpolicy1 and ipolicy2 = $sIpolicy2;
				printf("��@�γ������ɸ�� :sIpolicy1=[%s]sIpolicy2=[%s]\n",sIpolicy1,sIpolicy2);
				if (SQLCODE == SQLNOTFOUND)
				{
					/* ���b���I��������, ���b�@�γ�������...���D�j�F.......*/
					$insert into tmp_tb (ipolicy,  fprint, errmsg, ftype_pol)
					 values             ($XIpolicy,   'A', '�d�L��������','0');
					printf("���b���I��������, ���b�@�γ�������...���D�j�F :XIpolicy=[%s]\n",XIpolicy);
					continue;
				}
				else
				{
					strcpy(deffect4,cm_check_workday(dply_begin, deffect4));
					printf("dply_begin=[%s]deffect4=[%s]\n",dply_begin,deffect4);
					/* ú�Ǫ��`�O�O */
					$select nvl(sum(b.mnt),0) into $mnt1
					   from cm_pre_receive a, ao_prercv_pass b
					  where a.iins_cat = b.iins_cat
					    and a.ipre_rcv = b.ipre_rcv
					    and a.iins_kind = b.iins_kind
					    and a.ipre_end = b.ipre_end
					    and a.iins_cat = 'C'
					    and a.fstatus != 90
					    and a.ipre_rcv = $sIestimate
					    and a.iins_kind = $iins_kind
					    and ((a.ftype_pol = '1M' and b.dcoll_last <= (a.deffect + 30))
					     or (a.ftype_pol = ' ' and b.dcoll_last <= $deffect4))
					    and b.dacc_last is not null;

					printf("sIestimate=[%s]iins_kind=[%s]deffect4=[%s]mnt1=[%f]mprem=[%f]\n",sIestimate,iins_kind,deffect4,mnt1,mprem);
					if(mnt1 >= mprem)
					{
						/* �O�O����,�i���`�L��鵲 */
						printf("�O�O����,�i���`�L��鵲 :XIpolicy=[%s]mnt1=[%f]mprem=[%f]\n",XIpolicy,mnt1,mprem);
					}
					else
					{
						if (strcmp(sImgr,"1") == 0)
						{
							/* �j�v����*/
							if ((sIcomm_obj[0]=='B') || (sIcomm_obj[0]=='J'))
							{
								if ((mprem - mnt1) <= 10)
								{
									/* 10���e�\�d��,�i���`�L��鵲 */
									printf("10���e�\�d��,�i���`�L��鵲 :XIpolicy=[%s]mnt1=[%f]mprem=[%f]\n",XIpolicy,mnt1,mprem);
								}
								else
								{
									/* ���O������,�L�k�L��鵲 */
									$insert into tmp_tb (ipolicy,  fprint, errmsg)
									 values           ($XIpolicy,   'A', '���O������');
									printf("���O������,�L�k�L��鵲:XIpolicy=[%s]mnt1=[%f]mprem=[%f]\n",XIpolicy,mnt1,mprem);
									continue;
								}
							}
							else
							{
								if ((mprem - mnt1) <= 100)
								{
									/* 100���e�\�d��,�i���`�L��鵲 */
									printf("100���e�\�d��,�i���`�L��鵲:XIpolicy=[%s]mnt1=[%f]mprem=[%f]\n",XIpolicy,mnt1,mprem);
								}
								else
								{
									/* ���O������,�L�k�L��鵲 */
									$insert into tmp_tb (ipolicy,  fprint, errmsg)
									 values           ($XIpolicy,   'A', '���O������');
									printf(">100���e�\�d��,���O������,�L�k�L��鵲:XIpolicy=[%s]mnt1=[%f]mprem=[%f]\n",XIpolicy,mnt1,mprem);
									continue;
								}
							}
						}
						else
						{
							/* ���O������,�L�k�L��鵲 */
							$insert into tmp_tb (ipolicy,  fprint, errmsg)
							 values           ($XIpolicy,   'A', '���O������');
							printf("1076:���O������,�L�k�L��鵲:XIpolicy=[%s]\n",XIpolicy);
							continue;
						}
					}
				}
			}
		}
		else
		{
			/* ���D��, �L�k�k��........ */
			$insert into tmp_tb (ipolicy,  fprint, errmsg)
			 values           ($XIpolicy,   'A', '���D��, �L�k�k��........');
			printf("1088:���D��, �L�k�k��:XIpolicy=[%s]\n",XIpolicy);
			continue;
		}
		#endif
		/* ------------------------------------------------------------------ */
		$insert into tmp_tb (ipolicy, fprint, errmsg, ftype_pol, iestimate) values ($XIpolicy, 'Y',' ','0', $sIestimate);

		strcpy(sTmpiofficer, trim(sTmpiofficer));
		printf("sTmpIcomp[%s],sTmpIbranch[%s],ymd[%s]\n", sTmpIcomp, sTmpIbranch, ymd);
		/*if (iFpolicy && iFbig) break;*/
    }
    
    if (iFpolicy)
	{
		$CLOSE PLY_CUR_A2;
		$FREE PLY_CUR_A2;
	}
    else
    {
		if((strcmp(trim(ply_bgn),"*V7*")==0)&&(strcmp(trim(ply_end),"*V7*")==0))
		{
			$CLOSE PLY_CUR_A4;
			$FREE PLY_CUR_A4;
		}
    	else 
        {
        	$CLOSE PLY_CUR_A3;
        	$FREE PLY_CUR_A3;
        }
    }
    return M_CM_OK;

errexit:
	printf("SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
	strcpy(sErrMsg,"�O���ˮ֦��~!!");
	return SQLCODE;
}
