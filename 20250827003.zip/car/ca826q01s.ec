#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include <math.h>
#include "gls_array.h"
#include "gls_const.h"
#include "safeclib.h"

#define SUCCESS                 1
#define FAIL                    0
#define YES                     1
#define NO                      0
#define NEXTPAGE                7
#define FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND

extern char RPTDIR[];

/****  get data from client  ****/
$char  DBName[5];
char   userid[11];
$char  ibranch[4];
$char  datebgn[11], dateend[11];
$char  outputf[21];

/****  car826_p  ****/
$char  cDatebgn[11], cDateend[11];

$char  path_DataFile[80];
$char  sFullName[20];

static int pagenum=1;
$char  FormTp[3];
char   BodyFile[ N_FILE+1];
char   TitleFile[ N_FILE+1];
$int   StartRow,TitleRow;
$int   ItemRow, TotColumn;
$int   PgLine;
$int   Width = 0;
$int   iCnt;
int    max_count, errCode;
int    tmp_len;
$char  freason[2];
$char  xNassured[121],xIlicense[11],remark[31];

$char  stmt[2048];
long   msg_code;

$struct Rec826 {
   char sIpolicy[21];
   char sNassured[121];
   char sIofficer[11];
   char sNofficer[21];
   char sIclaim[21];
   char sIclose_type[2];
   char sIadjuster[11];
   char sNadjuster[21];
   char sIstl_note[4];
   char sReason[13];
   char sNcode[61];
   char dply_end[11];
} r;

long car826_build();
void car826_title();
void car826_body();

static char *get_car_full_db();
main(argc,argv)
int  argc;
char **argv;
{
   long rc=0;

   batchinit();

   strcpy(DBName,       isNULLstr(argv[1]));
   strcpy(userid,       isNULLstr(argv[2]));
   strcpy(datebgn,      isNULLstr(argv[3]));  /* �鵲�_�� */
   strcpy(dateend,      isNULLstr(argv[4]));  /* �鵲���� */
   strcpy(outputf,      isNULLstr(argv[5]));

   rc = car826_build();

   if (rc == api_OKComplete)
   {
       create_sign_form("car826",BodyFile, Width);
       if ((rc=save_form_info(F_BLK1,"CA",826,userid,FormTp,max_count,outputf))<0)
            EWRITE(userid,rc,"save_form_info_failed");
   }
}

long car826_build()
{
   $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
   $char  iclaim[CLAIM_NUM], ipolicy[POLICY_NUM_1], daccident[15];
   $long  dclose_ctype, dclose_rtype;
   int    i;
   $int   fcnt;

   $WHENEVER SQLERROR GOTO errexit;

   if(db_select(DBName) == False)
   {
       EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
       return FAIL;
   }

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth, iForm_Tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width, $FormTp
      FROM Form
     WHERE ksys_grp = "CA" AND kPgmID = 826;

   strcpy(TitleFmt, rtrim(TitleFmt));
   strcpy(BodyFmt, rtrim(BodyFmt));
   sprintf_s(TitleFile,N_FILE+1, "%s.ti", outputf);
   sprintf_s(BodyFile,N_FILE+1, "%s.bd", outputf);

   $WHENEVER SQLERROR GOTO errexit;

   $CREATE TEMP TABLE car826_TEMP
   (
    ipolicy     char(20)   default ' ',
    nassured    char(120)  default ' ',
    iofficer    char(10)   default ' ',
    iclaim      char(21)   default ' ',
    iclose_type char(1)    default ' ',
    iadjuster   char(11)   default ' ',
    istl_note   char(3)    default ' ',
    dply_end    date
   )WITH NO LOG;

   /* �B�z���Y */
   rgu_init_report(TitleFmt, TitleFile);
   car826_title();
   rgu_finish_report();

   /* �B�z���� */
   rgu_init_report(BodyFmt, BodyFile);

   /* �}�l������� */
   car826_p();

   $DECLARE Acursor1 CURSOR FOR
     SELECT ipolicy,nassured,iofficer,iclaim,iclose_type,iadjuster,istl_note,dply_end 
       FROM car826_TEMP
      ORDER BY 4,5,1;

   $OPEN Acursor1;

   for (i=0; ; i++)
   {
      $FETCH Acursor1
        INTO $r.sIpolicy,$r.sNassured,$r.sIofficer,
             $r.sIclaim,$r.sIclose_type,$r.sIadjuster,$r.sIstl_note,$r.dply_end;

      if (SQLCODE == SQLNOTFOUND)
      {
         if (i == 0)
         {
            EWRITE(userid, SQLCODE, "�L�X�G���󪺸�� !");
            return 0;
         }
         break;
      }

      $SELECT nname
         INTO $r.sNofficer
         FROM officer
        WHERE iofficer = $r.sIofficer;
        if (SQLCODE == SQLNOTFOUND) strcpy(r.sNofficer," ");

      $SELECT nname
         INTO $r.sNadjuster
         FROM officer
        WHERE iofficer = $r.sIadjuster;
        if (SQLCODE == SQLNOTFOUND) strcpy(r.sNadjuster," ");

      strcpy(sFullName, get_car_full_db(r.sIpolicy));

      sprintf_s(stmt,2048,"SELECT iassured,nassured \
                    FROM %s:adjustment_ply \
                    WHERE iclaim = '%s'",\
                    sFullName,r.sIclaim);

      $PREPARE w1 FROM $stmt;
      $DECLARE w1_cursor CURSOR FOR w1;
      $OPEN w1_cursor;
      $FETCH w1_cursor INTO $xIlicense,$xNassured;
      if(SQLCODE == SQLNOTFOUND)
       {strcpy(xIlicense," ");
        strcpy(xNassured," "); }
      $CLOSE w1_cursor;
      $FREE  w1_cursor;
  printf("206 siclaim[%s] Ilicense[%s] nassured[%s]\n", r.sIclaim,xIlicense, xNassured );
     $DECLARE f_cur CURSOR FOR
       SELECT freason,remark
         INTO $freason,$remark
         FROM reject_client
        WHERE ilicense = $xIlicense
          AND nassured = $xNassured;
        $OPEN f_cur;
     fcnt = 0;
     for(;;)
     {    
       $FETCH f_cur;
     if(SQLCODE == SQLNOTFOUND)
      { 
        strcpy(freason," ");
        strcpy(remark," "); 
        break;
      }

       fcnt++;
   /* { */
 printf("212 freason=[%s] ilicense=[%s] nassured=[%s] \n",freason,xIlicense,xNassured);
      if (strncmp(freason,"1",1)==0)
        strcpy(r.sReason,"���}�Ȥ�");
      else if (strncmp(freason,"2",1)==0)
        strcpy(r.sReason,"���Ѩ�");
      else if (strncmp(freason,"3",1)==0)
        strcpy(r.sReason,"���l��");
      else if (strncmp(freason,"4",1)==0)
        strcpy(r.sReason,"�w����");
      else if (strncmp(freason,"5",1)==0)
        strcpy(r.sReason,"��ĳ������O");
      else
        strcpy(r.sReason," ");

      if (strncmp(r.sIstl_note,"015",3)==0)
        strcpy(r.sNcode,remark);
      else
       {$SELECT ncode
           INTO $r.sNcode
           FROM adjustment_code
          WHERE fclass = '2'
            AND icode = $r.sIstl_note;
          if (SQLCODE == SQLNOTFOUND) strcpy(r.sNcode,r.sIstl_note);
       }
printf("239 \n");
        car826_body();
      }
      $CLOSE f_cur;
      $FREE  f_cur;
      if (fcnt == 0)
      {
  /* {  */
      printf("212 freason=[%s] ilicense=[%s] nassured=[%s] \n",freason,xIlicense,xNassured);
      if (strncmp(freason,"1",1)==0)
          strcpy(r.sReason,"���}�Ȥ�");
      else if (strncmp(freason,"2",1)==0)
          strcpy(r.sReason,"���Ѩ�");
      else if (strncmp(freason,"3",1)==0)
          strcpy(r.sReason,"���l��");
      else if (strncmp(freason,"4",1)==0)
        strcpy(r.sReason,"�w����");
      else if (strncmp(freason,"5",1)==0)
        strcpy(r.sReason,"��ĳ������O");
      else
        strcpy(r.sReason," ");

      if (strncmp(r.sIstl_note,"015",3)==0)
        strcpy(r.sNcode,remark);
      else
       {$SELECT ncode
           INTO $r.sNcode
           FROM adjustment_code
          WHERE fclass = '2'
            AND icode = $r.sIstl_note;
          if (SQLCODE == SQLNOTFOUND) strcpy(r.sNcode,r.sIstl_note);
       }
printf("239 \n");
        car826_body();
      }
   }
   $CLOSE Acursor1;
   $FREE Acursor1;

   rgu_put_body(2);
   rgu_finish_report();

   $DROP TABLE car826_TEMP;

   return SUCCESS;

errexit:
   /* printf("Lai:err,%d",SQLCODE);  */
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return 0;
}

car826_p()
{

     $char sBranch[3];
     $char stmt[2048];
     $char sIclaim[21],sIclose_type[2],sIpolicy[21],sIadjuster[11];
     $char sIstl_note[4];
     $char sNassured[121],sIofficer[11];
     $char dply_end[11];

     $WHENEVER SQLERROR goto errexit;
 
     /*** �߮ר��z����B�z ***/
     if (datebgn[0] == '*') strcpy(datebgn, "88/01/01");
     if (dateend[0] == '*') strcpy(dateend, "99/12/31");
     if (dateend[0] == ' ') strcpy(dateend, datebgn);

     strcpy(cDatebgn, cm_to_infdate(datebgn));
     strcpy(cDateend, cm_to_infdate(dateend));

     $DECLARE s_cur CURSOR FOR
       SELECT branch
         INTO $sBranch
         FROM servertbl
        WHERE branch <> 'S1';
     $OPEN s_cur;
     for(;;){
     $FETCH s_cur;
     if (SQLCODE == SQLNOTFOUND) break;

         sprintf_s(stmt,2048,
          " SELECT a.iclaim,a.iclose_type,a.ipolicy,b.iadjuster,   \
                   a.istl_note,c.nassured,c.iofficer              \
              FROM %s:settlement a,%s:appraisal b,%s:adjustment_ply c  \
             WHERE a.fstl = '1'                                   \
               AND a.dclose BETWEEN '%s' AND '%s'                 \
               AND NVL(a.istl_note,' ') != ' '    \
               AND a.iclaim = b.iclaim            \
               AND b.iclaim = c.iclaim ",
               get_full_dbname(sBranch),
               get_full_dbname(sBranch),
               get_full_dbname(sBranch),
               cDatebgn,cDateend);
         printf("stmt[%s]\n",stmt);
         $PREPARE cid01 FROM $stmt;
         $DECLARE st_cur CURSOR FOR cid01;
         $OPEN st_cur;
         for(;;){
         $FETCH st_cur
           INTO $sIclaim,$sIclose_type,$sIpolicy,$sIadjuster,
                $sIstl_note,$sNassured,$sIofficer;
         if (SQLCODE == SQLNOTFOUND) break;

             printf("sIclaim[%s]\n",sIclaim);
           /*
             sprintf_s(stmt,2048,
              " SELECT nassured,iofficer     \
                  FROM %s:adjustment_ply     \
                 WHERE iclaim = '%s' ",get_full_dbname(sBranch),sIclaim);
             $PREPARE cid02 FROM $stmt;
             $EXECUTE cid02 INTO $sNassured,$sIofficer;
              if (SQLCODE == SQLNOTFOUND) {
                  strcpy(sNassured," ");
                  strcpy(sIofficer," ");
              }
           */
             sprintf_s(stmt,2048,
              " SELECT dply_end         \
                  FROM %s:ply_relation  \
                 WHERE ipolicy = '%s' ",get_full_dbname(sBranch),sIpolicy);
             $PREPARE cid05 FROM $stmt;
             $EXECUTE cid05 INTO $dply_end;


         $INSERT INTO car826_TEMP
            VALUES ($sIpolicy,$sNassured,$sIofficer,$sIclaim,
                    $sIclose_type,$sIadjuster,$sIstl_note,$dply_end);

         }
         $CLOSE st_cur;
         $FREE  st_cur;
     }
     $CLOSE s_cur;
     $FREE  s_cur;

     printf("#######car826_p() OK!!!!\n");
     return M_CM_OK;

errexit:
  if (SQLCODE != 0) msg_code = SQLCODE;
  printf("car826_p():SQLCODE=[%ld], sqlerrm=[%s]\n",msg_code, sqlca.sqlerrm);
  return SQLCODE;
}

void car826_title()
{
   char currdate[20];
   char yy[4], mm[3], dd[3];
   char yy1[4], mm1[3], dd1[3];

   /*** get current_date ***/
   strcpy(currdate,cm_sysd_cdate_100(cm_get_sysd()));
   cm_split_ymd_100(currdate, yy, mm, dd);

   rgu_put_head_string(1, yy);
   rgu_put_head_string(1, mm);
   rgu_put_head_string(1, dd);

   /*** �߮פ鵲�϶� ***/
   cm_split_ymd_100(datebgn, yy1, mm1, dd1);
   rgu_put_head_string(1, yy1);
   rgu_put_head_string(1, mm1);
   rgu_put_head_string(1, dd1);
   cm_split_ymd_100(dateend, yy1, mm1, dd1);
   rgu_put_head_string(1, yy1);
   rgu_put_head_string(1, mm1);
   rgu_put_head_string(1, dd1);
   rgu_put_head();
}

void car826_body()
{
char sTmp[20];

   rgu_put_body_string(1, trim(r.sIpolicy), 1);
   rgu_put_body_string(1, trim(r.sNassured), 1);
   rgu_put_body_string(1, trim(r.sNofficer), 1);
   rgu_put_body_string(1, trim(r.sIclaim), 1);
   rgu_put_body_string(1, trim(r.sIclose_type), 1);
   rgu_put_body_string(1, trim(r.sNadjuster), 1);
   rgu_put_body_string(1, trim(r.sReason), 1);
   rgu_put_body_string(1, trim(r.sNcode), 1);
   strcpy(sTmp,cm_from_infdate_100(r.dply_end));
   rgu_put_body_string(1, trim(sTmp),1);
   rgu_put_body(1);
   max_count++;
}
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  static char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}
