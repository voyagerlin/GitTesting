/*******************************
 *       
 *   Program : ca118m01s.ec
 *   Author  : Tony
 *   Date    : 05.07.1994
 *
 ******************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "marmsgs.h"
#include "commsgs.h"
$include sqlca;
$include datetime.h;
#include "safeclib.h"

$char cDbName[5];
$char cIbrand[7], cIcarType[3];
$char cIbrand1[7], cIcarType1[3];
$dec_t dtPdmgFactor1st, dtPbrgFactor1st, dtPdmgFactor2nd, dtPbrgFactor2nd;
$long lDdate1st = 0, lDdate2nd;
$char stmt[600];
int   iRtnLen;

$char cPdmgFactor1st[9], cPbrgFactor1st[9];
$char cPdmgFactor2nd[9], cPbrgFactor2nd[9];
$char cDdate1st[12], cDdate2nd[12];
$char cNcode[12], cNbrandAbbr[14];

$char cPdmgFactor1st1[9], cPbrgFactor1st1[9];
$char cPdmgFactor2nd1[9], cPbrgFactor2nd1[9];
$char cDdate1st1[12], cDdate2nd1[12];
$char cNcode1[12], cNbrandAbbr1[14];

long car118(reply, command, com_len)
serverReply reply;
voidP command;
int com_len;
{
  long rtncode;
  long car118_insert(), car118_delete(), car118_single_query();
  long car118_multiple_query(), car118_update_exec();
  char option;

  cm_buf_init(command);
  cm_buf_get("%c", &option);
  switch(option) {
  case 'A':
  case 'U':
    rtncode = car118_insert(reply, option, command, com_len);
    break;
  case 'Q':
    rtncode = car118_single_query(reply);
    break;
  case 'M':
    rtncode = car118_multiple_query(reply);
    break;
  case 'D':
    rtncode = car118_delete(option, reply, command, com_len);
    break;
    /*
    rtncode = car118_update_exec(reply, command, com_len);
    break;
*/
  default :
    return exitsub(reply, M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
  }
  return(rtncode);
} /* car_118 */

long car118_delete(option, reply, command, com_len)
char option;
serverReply reply;
voidP command;
int com_len;
{
  long  MsgCode;
  int   iDbNum = 0, iTmp;
  int raw_len;
  char *pos, *raw_ptr, cur_buf[4000];
  char *comm;
  $char drate[12];
  DBinfo *dbList;
  DBinfo *get_sysdb_list();

  comm = (char *) command;

  cm_buf_get("%s %s %s %s", cDbName, cIbrand, cIcarType,drate);

   strcpy(drate,cm_to_infdate(drate));

  $WHENEVER SQLERROR GOTO errexit;


printf("sysdb_list\n");
printf("[iDbNum:%d]\n", iDbNum);
printf("[cDbName:%s]\n", cDbName);
  if((dbList=get_sysdb_list( &iDbNum, cDbName)) == (char *) 0)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
printf("sysdb_list ok\n");
  
  memcpy(&raw_len, &comm[com_len], sizeof(int));
  pos = &comm[com_len+sizeof(int)];
  raw_ptr = (char *) malloc(raw_len);
  if (raw_ptr != (char *) 0)
   memcpy(raw_ptr, pos, raw_len);
  else {
    if( exitsub(reply,M_CM_NOT_MALLOC) == True )  /* malloc fail */
     return M_CM_NOT_MALLOC;
    return apiRC;
  }

 /* get index key from old record, dummy is the MsgCode */

  cm_buf_init(raw_ptr);
  cm_buf_get("%l %s %s %s %s %s %s %s",
              &MsgCode, cIbrand, 
              cNbrandAbbr, cIcarType, cNcode, cDdate1st, cPdmgFactor1st, 
              cPbrgFactor1st);

printf("111\n");
printf("[ibrand:%s]\n", cIbrand);
printf("[icar_type:%s]\n", cIcarType);

   strcpy(cDdate1st,cm_to_infdate(cDdate1st));
  printf(" drate[%s]\n",drate);

  $SELECT pdmg_factor, pbrg_factor, drate
     INTO $dtPdmgFactor1st, $dtPbrgFactor1st, $lDdate1st
     FROM car_model_align
    WHERE ibrand = $cIbrand AND icar_type = $cIcarType AND drate = $cDdate1st;


  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */

 if (SQLCODE == SQLNOTFOUND)
  {
   if( exitsub(reply,M_CM_NOT_FOUND) == True )
    return M_CM_NOT_FOUND;
   return apiRC;
  }

  $SELECT ncode
     INTO $cNcode
     FROM car_type
    WHERE fclass = '1' AND icode = $cIcarType;

  $DECLARE cur CURSOR FOR
    SELECT nbrand_abbr
      INTO $cNbrandAbbr
      FROM ca_car_model
     WHERE ibrand = $cIbrand;
  $OPEN cur;
  $FETCH cur;

  dectoasc(&dtPdmgFactor1st, cPdmgFactor1st, 9, 4);
  dectoasc(&dtPbrgFactor1st, cPbrgFactor1st, 9, 4);

  strcpy(cPdmgFactor1st, rtrim(cPdmgFactor1st));
  strcpy(cPbrgFactor1st, rtrim(cPbrgFactor1st));

  strcpy(cDdate1st, cm_cdate_str_100(lDdate1st));


printf("333\n");
 cm_buf_init(cur_buf);
 cm_buf_put("%l %s %s %s %s %s %s %s", M_CM_OK, cIbrand,
      cNbrandAbbr, cIcarType, cNcode, cDdate1st, cPdmgFactor1st, 
      cPbrgFactor1st);

write(1, cur_buf, raw_len);
write(1, "\n", 1);
write(1, raw_ptr, raw_len);
write(1, "\n", 1);

 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
  {
   if( exitsub(reply,M_CM_NOT_EQUAL) == True )
    return M_CM_NOT_EQUAL;
   return apiRC;
  }
  
  free(raw_ptr);
  
  printf(" cDdate1st[%s]\n",cDdate1st);
  strcpy(cDdate1st,cm_to_infdate(cDdate1st));
  printf(" 111111111111111111111111111111 \n");
  $BEGIN WORK;
  for(iTmp=0; iTmp < iDbNum; iTmp++){
    printf(" ************************** \n");
    sprintf_s(stmt, sizeof stmt,
        "DELETE FROM %s:car_model_align "
        " WHERE ibrand = ? AND icar_type = ? AND drate = ?", dbList[iTmp].dbname);
    printf(" stmt[%s]\n",stmt);
    $PREPARE s_d_1 FROM $stmt;
    $EXECUTE s_d_1 USING $cIbrand, $cIcarType,$cDdate1st;
  } /* end of for */

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l", M_CM_OK);
  iRtnLen = cm_buf_len(ReplyBuf);

  if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False) {
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    return apiRC;
  }
  $COMMIT WORK;
  return api_OKComplete;

errexit:
  MsgCode = SQLCODE;
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  return exitsub(reply, MsgCode) ? MsgCode : apiRC;
} /* car118_delete */

long car118_insert(reply, option, command, com_len)
serverReply reply;
char option;
voidP command;
int com_len;
{
  long  MsgCode;
  int   iDbNum, iTmp;
  DBinfo *dbList;
  DBinfo *get_sysdb_list();
  int raw_len;
  char *pos, *raw_ptr, cur_buf[4000];
  char *comm;
  $char drate[12];

  cm_buf_get("%s %s %s %s %s %s ",
      cDbName, cIbrand, cIcarType, cDdate1st, cPdmgFactor1st, cPbrgFactor1st);

  $WHENEVER SQLERROR GOTO errexit;
  if((dbList=get_sysdb_list( &iDbNum, cDbName)) == (char *) 0)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  strcpy(cDdate1st, cm_to_infdate(cDdate1st));

  if(option == 'U'){
  comm = (char *) command;

  memcpy(&raw_len, &comm[com_len], sizeof(int));
  pos = &comm[com_len+sizeof(int)];
  raw_ptr = (char *) malloc(raw_len);
  if (raw_ptr != (char *) 0)
     memcpy(raw_ptr, pos, raw_len);
  else {    /* malloc fail */
    return exitsub(reply,M_CM_NOT_MALLOC) ? M_CM_NOT_MALLOC : apiRC;
  }

 /* get index key from old record, dummy is the MsgCode */

printf("[cNcode1:%s]\n", cNcode1);
printf("[cNbrandAbbr1:%s]\n", cNbrandAbbr1);
  cm_buf_init(raw_ptr);
  cm_buf_get("%l %s %s %s %s %s %s %s ", &MsgCode, cIbrand1,
       cNbrandAbbr1, cIcarType1, cNcode1, cDdate1st1, cPdmgFactor1st1, 
       cPbrgFactor1st1);

  strcpy(cDdate1st1,cm_to_infdate(cDdate1st1));
  
  printf("1111111111111[%s]\n",cDdate1st1);

  $SELECT pdmg_factor, pbrg_factor,drate
     INTO  $dtPdmgFactor1st, $dtPbrgFactor1st,$drate
     FROM car_model_align
    WHERE ibrand = $cIbrand1 AND icar_type = $cIcarType1 AND drate = $cDdate1st1;


  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */

 if (SQLCODE == SQLNOTFOUND)
   return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND : apiRC;

  $SELECT ncode
      INTO $cNcode1
      FROM car_type
      WHERE fclass = '1' AND icode = $cIcarType1;

  $DECLARE cur1 CURSOR FOR
   SELECT nbrand_abbr
      INTO $cNbrandAbbr1
      FROM ca_car_model
      WHERE ibrand = $cIbrand1;
  $OPEN cur1;
  $FETCH cur1;

printf("[cNcode1:%s]\n", cNcode1);
printf("[cNbrandAbbr1:%s]\n", cNbrandAbbr1);

  dectoasc(&dtPdmgFactor1st, cPdmgFactor1st1, 9, 4);
  dectoasc(&dtPbrgFactor1st, cPbrgFactor1st1, 9, 4);

  strcpy(cPdmgFactor1st1, rtrim(cPdmgFactor1st1));
  strcpy(cPbrgFactor1st1, rtrim(cPbrgFactor1st1));
  strcpy(drate,cm_from_infdate_100(drate));

printf("333\n");
 cm_buf_init(cur_buf);       /* must reserve msg and count for comparison */
 cm_buf_put("%l %s %s %s %s %s %s %s", M_CM_OK, cIbrand1,
      cNbrandAbbr1, cIcarType1, cNcode1, drate , cPdmgFactor1st1,
      cPbrgFactor1st1);
write(1, cur_buf, raw_len); write(1, "\n", 1);
write(1, raw_ptr, raw_len); write(1, "\n", 1);

 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
  {
   if( exitsub(reply,M_CM_NOT_EQUAL) == True )
    return M_CM_NOT_EQUAL;
   return apiRC;
  }
   ;;;
  } /* if option == 'U' */
  
  free(raw_ptr);

/*------------------------------------*/
  $BEGIN WORK;
  for(iTmp=0; iTmp < iDbNum; iTmp++){
    if(option == 'A'){
      sprintf_s(stmt, sizeof stmt, "INSERT INTO %s:car_model_align "
                    " (ibrand,icar_type,pdmg_factor,pbrg_factor,drate) "
                    " VALUES (?, ?, ?, ? , ? )",
             dbList[iTmp].dbname);
     printf("11111111111111[%s]\n",stmt );
       $PREPARE s1 FROM $stmt;
       $EXECUTE s1 USING $cIbrand, $cIcarType,$cPdmgFactor1st,$cPbrgFactor1st,$cDdate1st;

       printf("[A]:cIbrand=%s,cIcarType=%s\n",cIbrand,cIcarType);


    }else{
       strcpy(drate,cm_to_infdate(drate));
       printf("2222222222222222222[%s]\n",cDdate1st1);
      sprintf_s(stmt, sizeof stmt,
          "UPDATE %s:car_model_align "
          "   SET ibrand='%s', icar_type='%s', "
               "  pdmg_factor = '%s', "
               "  pbrg_factor = '%s', "
               "  drate = '%s' "
            " WHERE ibrand = ? AND icar_type = ? AND drate = ?",
          dbList[iTmp].dbname,cIbrand, cIcarType,
          cPdmgFactor1st, cPbrgFactor1st, cDdate1st);

    $PREPARE s2 FROM $stmt;
    printf("[U]:cIbrand1=%s,cIcarType=%s\n",cIbrand1,cIcarType1);
    $EXECUTE s2 USING $cIbrand1, $cIcarType1,$cDdate1st1;
   }
  } /* end of for */

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l", M_CM_OK);
  iRtnLen = cm_buf_len(ReplyBuf);

  if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False) {
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    return apiRC;
  }
  $COMMIT WORK;
  return api_OKComplete;

errexit:
  MsgCode = SQLCODE;
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  return exitsub(reply, MsgCode) ? MsgCode : apiRC;
} /* car118_insert */

/***********************************************************************/
long car118_single_query(reply)
serverReply reply;
{
  long  MsgCode = 0;
  $char cBuf[10];
  $char drate[12];

  cm_buf_get("%s %s %s %s", cDbName, cIbrand, cIcarType,drate);

  $WHENEVER SQLERROR GOTO errexit;

  if(db_select(cDbName) == False)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN :apiRC;


  strcpy(drate,cm_to_infdate(drate));

  $SELECT pdmg_factor, pbrg_factor, drate
     INTO $dtPdmgFactor1st, $dtPbrgFactor1st, $lDdate1st
     FROM car_model_align
    WHERE ibrand = $cIbrand AND icar_type = $cIcarType AND drate = $drate;

  if(SQLCODE == SQLNOTFOUND){
   if( exitsub(reply,M_CM_NOT_FOUND) == True )
    return M_CM_NOT_FOUND;
   return apiRC;
  }
  $SELECT ncode
      INTO $cNcode
      FROM car_type
      WHERE fclass = '1' AND icode = $cIcarType;

  strcpy(cBuf, rtrim(cIbrand));
printf("[cBuf:%s]\n", cBuf);

  $DECLARE cur2 CURSOR FOR
   SELECT nbrand_abbr
      INTO $cNbrandAbbr
      FROM ca_car_model
      WHERE ibrand = $cBuf;
  $OPEN cur2;
  $FETCH cur2;

  dectoasc(&dtPdmgFactor1st, cPdmgFactor1st, 9, 4);
  dectoasc(&dtPbrgFactor1st, cPbrgFactor1st, 9, 4);

  strcpy(cPdmgFactor1st, rtrim(cPdmgFactor1st));
  strcpy(cPbrgFactor1st, rtrim(cPbrgFactor1st));

  strcpy(cDdate1st, cm_cdate_str_100(lDdate1st));


  if(*cNbrandAbbr == '\0')
    strcpy(cNbrandAbbr, " ");
  if(*cNcode == '\0')
    strcpy(cNcode, " ");

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s %s %s %s %s %s", M_CM_OK, cIbrand,
              cNbrandAbbr, cIcarType, cNcode, cDdate1st, cPdmgFactor1st, 
              cPbrgFactor1st);

  iRtnLen = cm_buf_len(ReplyBuf);

  if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  return exitsub(reply, MsgCode) ? SQLCODE : apiRC;
}

/***********************************************************************/
long car118_multiple_query(reply)
serverReply reply;
{
  char tmpbuf[4000];
  $char termWhere[80];
  int count=0, iTmpLen=0, iRtnLen=0, replycnt=0;
  $char cBuf[10];
  $char drate[12];
  $char str_drate_bgn[12];
  $char str_drate_end[12];

  cm_buf_get("%s %s %s %s", cDbName, cIbrand, cIcarType,drate);

  $WHENEVER SQLERROR GOTO errexit;

  if(db_select(cDbName) == False)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

   if(drate[0] == '*')
     {strcpy(str_drate_bgn,"01/01/1980");
      strcpy(str_drate_end,"12/31/2999");}
   else
     {strcpy(str_drate_bgn,cm_to_infdate(drate));
      strcpy(str_drate_end,cm_to_infdate(drate));}


  sprintf_s(stmt, sizeof stmt, "SELECT ibrand, icar_type,drate FROM car_model_align "
                  " WHERE icar_type MATCHES '%s' "
                  " AND ibrand MATCHES '%s' "
                  " AND (drate >= '%s' AND drate <= '%s' ) "
                  ,cIcarType,cIbrand,str_drate_bgn,str_drate_end);
  printf("stmt[%s]\n",stmt);
  $PREPARE s_m_1 FROM $stmt;
  $DECLARE m1_cursor CURSOR FOR s_m_1;
  $OPEN m1_cursor;
  while(1)
  {
    $FETCH m1_cursor INTO $cIbrand, $cIcarType,$drate;

    if(SQLCODE == SQLNOTFOUND) break;

    strcpy(drate,cm_from_infdate_100(drate));
/***************************************
    *cPdmgFactor1st = *cPbrgFactor1st = *cPdmgFactor2nd = *cPbrgFactor2nd
        = *cDdate1st = *cDdate2nd = *cNcode = *cNbrandAbbr = '\0';

     $SELECT UNIQUE ncode
        INTO $cNcode
        FROM car_type
        WHERE fclass = '1' AND icode = $cIcarType;
   
printf("2\n");
    strcpy(cBuf, rtrim(cIbrand));
    strcat(cBuf, "*");   
printf("[cBuf:%s]\n", cBuf);

    $DECLARE cur3 CURSOR FOR
     SELECT UNIQUE nbrand_abbr
        INTO $cNbrandAbbr
        FROM ca_car_model
        WHERE ibrand = $cBuf;
    $OPEN cur3;
    $FETCH cur3;

printf("3\n");
    dectoasc(&dtPdmgFactor1st, cPdmgFactor1st, 9, 4);
    dectoasc(&dtPbrgFactor1st, cPbrgFactor1st, 9, 4);
    dectoasc(&dtPdmgFactor2nd, cPdmgFactor2nd, 9, 4);
    dectoasc(&dtPbrgFactor2nd, cPbrgFactor2nd, 9, 4);

    strcpy(cPdmgFactor1st, rtrim(cPdmgFactor1st));
    strcpy(cPbrgFactor1st, rtrim(cPbrgFactor1st));
    strcpy(cPdmgFactor2nd, rtrim(cPdmgFactor2nd));
    strcpy(cPbrgFactor2nd, rtrim(cPbrgFactor2nd));

    strcpy(cDdate1st, cm_cdate_str_100(lDdate1st));
    strcpy(cDdate2nd, cm_cdate_str(lDdate2nd));
******************************************************/

    cm_buf_init(tmpbuf);

    if(count == 0){
      cm_buf_res_msg();     /* reserve for MsgCode and count */
      cm_buf_res_count();
    }
    cm_buf_put("%s %s %s", cIbrand, cIcarType,drate);
    iTmpLen = cm_buf_len(tmpbuf);

    if(iTmpLen + iRtnLen < 3000){
      memcpy(&ReplyBuf[iRtnLen], tmpbuf, iTmpLen);
      iRtnLen += iTmpLen;
      count++;
    } else{
      cm_buf_init(ReplyBuf);       /* more than 4K, send to client side */
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OK) == False) 
      {
        $CLOSE m1_cursor;
        return apiRC;
      } else{

        replycnt++;   /* clear ReplyBuf and count to start all over again */
        if (replycnt == 10) 
        {
          cm_buf_init(ReplyBuf); /* more than 30K, client cannot display */
          cm_buf_put("%l", M_CM_OUT_SPACE);
          iTmpLen = cm_buf_len(ReplyBuf);
          if(SendSyncReply(reply,ReplyBuf,iTmpLen,api_OKComplete) == False)
            return apiRC;
          return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s", cIbrand, cIcarType, drate);
        iRtnLen = cm_buf_len(ReplyBuf);
        count++;
      } 
    } 
  }
  $CLOSE m1_cursor;

  if (count > 0) 
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False)
      return apiRC;
    return api_OKComplete;
  } else {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else                             
      return apiRC;                  
  }

errexit:
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}
