/************************************************/
/*						*/
/*   PROGRAM : ca123m01s.ec by Peter Hwang	*/
/*						*/
/*   PURPOSE : server side standard program	*/
/*	       (with listbox)			*/
/*						*/
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include "safeclib.h"

long MsgCode;

long car123(reply,command,com_len) /* orginal: car123 */
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car123_insert(),car123_single_query(),car123_multiple_query(),car123_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
	   rtncode=car123_insert(reply);
	   break;
  case 'Q':
	   rtncode=car123_single_query(reply);
	   break;
  case 'M':
	   rtncode=car123_multiple_query(reply);
	   break;
  case 'D':
  case 'U':
	   rtncode=car123_update_exec(reply,command,com_len);
	   break;
  default :
	   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
	    return M_CM_WRONG_OPTION;
	   return apiRC;
 }
 return(rtncode);
}

/*-------------------------------------------*/
long car123_insert(reply)
/*-------------------------------------------*/
serverReply reply;
{
 $char fclass[2],DBName[3];
 $int  qcnt,qrecord;
/* $long premium,coverage1,coverage2; */
 char drate[9];
 $long drate_l;
 int   tmp_len;
 DBinfo *list;
 int i, j, is_add_fail=0, api_f;
 $char stmt_buf[300];

 cm_buf_get("%s %s %d %d %s",DBName,fclass,&qcnt,&qrecord,drate);
 drate_l=cm_ymd_cdate(drate);

 if(db_select(DBName) == False)
  {
   if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
    return M_CM_DB_NOTOPEN;
   return apiRC;
  }

 $WHENEVER SQLERROR GOTO errexit;

 if(SQLCODE==SQLNOTFOUND)
  {
   if( exitsub(reply,M_CA_NCARTYPE) == True )
    return M_CA_NCARTYPE;
   return apiRC;
  }

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }

 $BEGIN WORK;
 $WHENEVER SQLERROR CONTINUE;
 for(j=0;j<i;j++)  /* original: j=0;j<i;j++ */
 {
    sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO %s:ca_acc_record "
	" (fclass,qcnt,qrecord,drate) "
	" VALUES (?,?,?,?)" ,list[j].dbname);

    $PREPARE a_id FROM $stmt_buf;
    if(SQLCODE != 0) {
      is_add_fail = 1;
      break;
     }
    $EXECUTE a_id USING $fclass,$qcnt,$qrecord,$drate_l;
    if(SQLCODE != 0) {
      is_add_fail = 1;
      break;
     }

     if (is_add_fail == 3) {
      is_add_fail = 1;
      break;
     }

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  tmp_len = cm_buf_len(ReplyBuf);
  if( j == i-1 )
     api_f = api_OKComplete;
  else
     api_f = api_OK;

  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    {
     is_add_fail = 2;
     break;
    }
 } /* for loop */

 if( is_add_fail == 1 ) goto errexit;

 if( is_add_fail == 2 ) {
   $ROLLBACK WORK;
   return apiRC;
  }


 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

 errexit:
  MsgCode = SQLCODE;
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if ( SQLCODE != 0 )
   MsgCode = SQLCODE;
  if ( exitsub(reply,MsgCode) == True )
   return MsgCode;
  return apiRC;
}

/*-------------------------------------------*/
long car123_single_query(reply)
/*-------------------------------------------*/
serverReply reply;
{
 $char fclass[2],DBName[3],drate[9],tqrecord[2];
 $int  qcnt,qrecord = 0;
 $char drate_l[12];
 int   tmp_len;

 cm_buf_get("%s %s %d %s",DBName,fclass,&qcnt,drate);
 /* printf("%s %d  %s\n", fclass, qcnt, drate);*/
 strcpy(drate_l,cm_to_infdate(drate));
 
 /* printf("%s \n",  drate_l);*/
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
    return M_CM_DB_NOTOPEN;
   return apiRC;
  }

 cm_buf_init(ReplyBuf);
 cm_buf_res_msg();
/* cm_buf_res_count(); */

 $SELECT fclass,qrecord
 INTO $fclass,$qrecord
 FROM ca_acc_record
 WHERE fclass = $fclass AND qcnt = $qcnt AND drate = $drate_l;

  if(SQLCODE==SQLNOTFOUND)
  {
   if( exitsub(reply,M_CA_NACC_RECORD) == True )
    return M_CA_NACC_RECORD;
   return apiRC;
  }

 cm_buf_put("%s %d %d %s",fclass,qcnt,qrecord,drate);
 cm_buf_put_msg(M_CM_OK);
 tmp_len=cm_buf_len(ReplyBuf);
 if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;


 errexit:
  if ( exitsub(reply,SQLCODE) == True )
   return SQLCODE;
  return apiRC;
}

/*-------------------------------------------*/
long car123_multiple_query(reply)
/*-------------------------------------------*/
serverReply reply;
{
 $char k_fclass[2],fclass[2],DBName[3];
 $char k_drate[9],drate[9],drate_inf[12],k_qcnt[3];
 $int  qcnt = 0,qcnt_bgn,qcnt_end,qrecord = 0;
 $int  cur_int_tmp;
 $long drate_l = 0;
 $char qcur_buf[800],qcur_addbuf[100];     /* -- new add -- */
 char tmpbuf[4000],key2[3];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0,flag;

 cm_buf_get("%s %s %s %s",DBName,k_fclass,k_qcnt,k_drate);
printf("--- db[%s] fclass[%s] qcnt[%s] drate[%s]\n",DBName,k_fclass,k_qcnt,k_drate);

 $WHENEVER SQLERROR GOTO errexit;
 if (db_select(DBName) == False)
 {
   if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
    return M_CM_DB_NOTOPEN;
   return apiRC;
 }

 sprintf_s(qcur_buf, sizeof qcur_buf, "SELECT fclass,qcnt,qrecord,drate "
                    " FROM ca_acc_record "
                    " WHERE fclass MATCHES '%s' ",
                    k_fclass); 
 if (k_qcnt[0]!='*') 
 {
     sprintf_s(qcur_buf, sizeof qcur_buf,
             "%s AND qcnt = '%s' ORDER BY fclass,qcnt,qrecord,drate",
             qcur_buf,k_qcnt); 
 } else {

    if (k_drate[0]!='*')
    { 
        strcpy(drate_inf,cm_to_infdate(k_drate));
        sprintf_s(qcur_buf, sizeof qcur_buf,
                "%s AND drate = '%s' ORDER BY fclass,qcnt,qrecord,drate",
                qcur_buf,drate_inf); 
    } else {
        sprintf_s(qcur_buf, sizeof qcur_buf,
                "%s ORDER BY fclass,qcnt,qrecord,drate",qcur_buf); 
    }
 }

printf("---qcur_buf[%s]\n",qcur_buf);


 $PREPARE mq_tmp FROM $qcur_buf;
 $DECLARE mq_01 CURSOR FOR mq_tmp; 
 $OPEN mq_01;

 for(;;)
  {
    $FETCH mq_01 INTO $fclass,$qcnt,$qrecord,$drate_l;
    if (SQLCODE != 0) break;
    strcpy(drate,cm_cdate_str(drate_l));
printf("--[%s] [%d] [%d] [%s]\n",fclass,qcnt,qrecord,drate);
    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg(); 	    /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    cm_buf_put("%s %d %d %s",fclass,qcnt,qrecord,drate);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )	 /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else			       /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
	$CLOSE mq_01;
	return apiRC;
       }
      else		 /* clear ReplyBuf and count to start all over again */
       {
	replycnt++;
	if (replycnt == 10)   /* more than 30K, client cannot display,error */
	{
	 cm_buf_init(ReplyBuf);
	 cm_buf_put("%l",M_CM_OUT_SPACE);
	 tmp_len = cm_buf_len(ReplyBuf);
	 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
	  return apiRC;
	 return M_CM_OUT_SPACE;
	}
	ReplyBuf[0] = '\0';
	count = 0;
	cm_buf_init(ReplyBuf);
	cm_buf_res_msg();	    /* reserve for MsgCode and count */
	cm_buf_res_count();
	cm_buf_put("%s %d %d %s",fclass,qcnt,qrecord,drate);
	repbuf_len = cm_buf_len(ReplyBuf);
	count++;
       }
     }
  } /* for loop */

  $CLOSE mq_01;

 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else		 /* break out, not any raw is found */
  {
   if( exitsub(reply,M_CA_NACC_RECORD) == True )
    return M_CA_NACC_RECORD;
   return apiRC;
  }

errexit:
  if ( exitsub(reply,SQLCODE) == True )
   return SQLCODE;
  return apiRC;
}


/*-------------------------------------------*/
long car123_update_exec(reply,command,com_len)
/*-------------------------------------------*/
serverReply reply;
voidP command;
int com_len;
{
 $char DBName[3],fclass[2],cur_fclass[2],drate[9],drate_e[12];
 $char cur_drate[9];
 $int  qcnt,cur_qcnt,qrecord,cur_qrecord;
 DBinfo *list;
 char option,*pos,*raw_ptr,cur_buf[4000],*comm,type;
 int tmp_len,raw_len,count,rows=0,i,flag;
 long dummy;
 int k, j, is_del_fail=0, is_upd_fail=0;
 $char stmt_buf[300];

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
    return M_CM_DB_NOTOPEN;
   return apiRC;
  }

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }
 /* compare old record and current record, if the record has not been changed
    since last request, update or delete the record, otherwise return errmsg
    to client side */

 /* get old record info from command buffer */

 memcpy(&raw_len,&comm[com_len],sizeof(int));
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)
  memcpy(raw_ptr,pos,raw_len);
 else
  {
   if( exitsub(reply,M_CM_NOT_MALLOC) == True )  /* malloc fail */
    return M_CM_NOT_MALLOC;
   return apiRC;
  }

 /* get index key from old record, dummy is the MsgCode */

 cm_buf_init(raw_ptr);
 cm_buf_get("%l %s %d %d %s",&dummy,fclass,&qcnt,&qrecord,drate);

 strcpy(drate_e,cm_to_infdate(drate));
 $BEGIN WORK;

 $SELECT fclass,drate
  INTO $fclass,$cur_drate
  FROM ca_acc_record
  WHERE fclass=$fclass AND qcnt=$qcnt AND drate = $drate_e;

  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */

 if (SQLCODE == SQLNOTFOUND)
  {
   if( exitsub(reply,M_CM_NOT_FOUND) == True )
    return M_CM_NOT_FOUND;
   return apiRC;
  }

/*printf("333\n");*/
 cm_buf_init(cur_buf);	       /* must reserve msg and count for comparison */
 cm_buf_res_msg();
 /*cm_buf_res_count();*/
 cm_buf_put_msg(dummy);
 /*cm_buf_put_count(count);*/
 cm_buf_put("%s %d %d %s",fclass,qcnt,qrecord,drate);

 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
  {
	free(raw_ptr);
   if( exitsub(reply,M_CM_NOT_EQUAL) == True )
    return M_CM_NOT_EQUAL;
   return apiRC;
  }

 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
   for(j=0;j<i;j++)  /* original: j=0;j<i;j++ */
   {
    sprintf_s(stmt_buf, sizeof stmt_buf, "DELETE FROM %s:ca_acc_record WHERE fclass=? "
                      " AND qcnt=? AND drate=?",list[j].dbname);
    $PREPARE d_id FROM $stmt_buf;
    if(SQLCODE != 0) {
      is_del_fail = 1;
      break;
     }
    $EXECUTE d_id USING $fclass,$qcnt,$drate_e;
    if(SQLCODE != 0) {
      is_del_fail = 1;
      break;
     }
   }/* for loop */

   if( is_del_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
   cm_buf_init(command);
   cm_buf_get("%c %s",&option,DBName);
   cm_buf_get("%s %d %d %s",cur_fclass,&cur_qcnt,&cur_qrecord,cur_drate);
   strcpy(drate_e,cm_to_infdate(cur_drate));


   $WHENEVER SQLERROR CONTINUE;
/*printf("bb\n");*/
   for(j=0;j<i;j++)     /* original: j=0;j<i;j++ */
   {
	sprintf_s(stmt_buf, sizeof stmt_buf, "UPDATE %s:ca_acc_record "
	" SET (fclass,qcnt,qrecord,drate) "
    "   = (?,?,?,?) WHERE fclass=? AND qcnt=? "
	" AND drate=? ",list[j].dbname);

/* printf("ccc\n");*/
    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
/*printf("drate_e=[%s]\n",drate_e);*/
    $EXECUTE u_id USING  $cur_fclass,$cur_qcnt,$cur_qrecord,$drate_e,$fclass,
		$qcnt,$drate_e;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {
      sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO %s:ca_acc_record "
	" (fclass,qcnt,qrecord,drate) "
	" VALUES(?,?,?,?) " ,list[j].dbname);

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0) {
	is_upd_fail = 1;
	break;
       }
/* printf("drate_e=[%s]\n",drate_e);*/
      $EXECUTE ua_id USING $cur_fclass,$cur_qcnt,$cur_qrecord,$drate_e;
      if(SQLCODE != 0) {
	is_upd_fail = 1;
	break;
       }
     }
   } /* for loop */

   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else	 /* option is not 'D' or 'U' */
  {
puts("mck 2");
   if (exitsub(reply,M_CM_WRONG_OPTION) == True)
    return M_CM_WRONG_OPTION;
   return apiRC;
  }

 errexit:
  MsgCode = SQLCODE;
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if (SQLCODE !=0)
   MsgCode = SQLCODE;
  if (exitsub(reply,MsgCode) == True)
   return MsgCode;
  return apiRC;
}
