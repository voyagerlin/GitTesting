/************************************************/
/*                                              */
/*   PROGRAM : ca101m01s.ec by Pai-Li Chen      */
/*   MODIFIER: Johnny Kuo 04/10/1997            */
/*   PURPOSE : server side standard program     */
/*             (with listbox)                   */
/*                                              */
/************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include <decimal.h>
#include "safeclib.h"

long MsgCode;

long car101(reply,command,com_len) /* orginal: car101 */
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car101_insert(), car101_update_exec();
 long car101_single_query(), car101_multiple_query();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
           rtncode=car101_insert(reply);
           break;
  case 'Q':
           rtncode=car101_single_query(reply);
           break;
  case 'M':
           rtncode=car101_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car101_update_exec(reply,command,com_len);
           break;
  default :
         return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION :apiRC;
 }
 return(rtncode);
}
long car101_insert(reply)
serverReply reply;
{
 $char icar_type[3],DBName[3];
 $char carname[30];
 $int  qperiod;
 $double qcar_personbgn,qcar_personend,mpremium,mbusiness;
 $double pready_rate,pcomprate,pstablerate,pinvestrate,pinterest,mresearch,pcapital;
 $double maintain;
 $char   fassured[2];
 $long  mcoverage1,mcoverage2,mcoverage3,mdrunk_prem,mviolate_prem;
 char   drate[10];
 $long  drate_l;
 int   tmp_len;
 DBinfo *list;
 int i, j, is_add_fail=0, api_f;
 $char stmt_buf[1024];

 cm_buf_get("%s %s %d %e %e %l %l %l %e %e %s %e %e %e %e %e %e %e %e %s %l %l", \
             DBName,icar_type, \
             &qperiod,&qcar_personbgn,&qcar_personend,&mcoverage1, \
             &mcoverage2,&mcoverage3,&mpremium,&mbusiness,drate, \
             &pready_rate,&pcomprate,&pstablerate,&pinvestrate,&pinterest,\
             &mresearch,&pcapital,&maintain,fassured,&mdrunk_prem,&mviolate_prem);
 drate_l=cm_ymd_cdate(drate);

 if(db_select(DBName) == False)
     return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

 $WHENEVER SQLERROR GOTO errexit;
 $SELECT ncode
    INTO $carname
    FROM car_type
   WHERE fclass="1" AND icode=$icar_type;

 if(SQLCODE==SQLNOTFOUND)
    return exitsub(reply,M_CA_NCARTYPE) ? M_CA_NCARTYPE : apiRC;

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
    return exitsub(reply,M_CM_NOT_DBLIST) ? M_CM_NOT_DBLIST : apiRC;

 $BEGIN WORK;
 $WHENEVER SQLERROR CONTINUE;
 for(j=0;j<i;j++)  /* original: j=0;j<i;j++ */
 {
    sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:compulsory_premium "
        " (icar_type,qperiod,qcar_personbgn,qcar_personend,mcoverage1, "
        " mcoverage2,mcoverage3,mpremium,mbusiness,drate,pready_rate, "
        " pcomprate,pstablerate,pinvestrate,pinterest,mresearch,pcapital,"
        " maintain,fassured,mdrunk_prem,mviolate_prem) "
        " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)" ,list[j].dbname);

    $PREPARE a_id FROM $stmt_buf;
    if(SQLCODE != 0) {
      is_add_fail = 1;
      break;
     }
    $EXECUTE a_id USING $icar_type,$qperiod,$qcar_personbgn,$qcar_personend,
                $mcoverage1,$mcoverage2,$mcoverage3,$mpremium,$mbusiness,
                $drate_l,$pready_rate,$pcomprate,$pstablerate,$pinvestrate,
                $pinterest,$mresearch,$pcapital,$maintain,$fassured,$mdrunk_prem,$mviolate_prem;
    if(SQLCODE != 0) {
      is_add_fail = 1;
      break;
     }

     if (is_add_fail == 3) {
      is_add_fail = 1;
      break;
     }

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  tmp_len = cm_buf_len(ReplyBuf);
  if( j == i-1 )
     api_f = api_OKComplete;
  else
     api_f = api_OK;

  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    {
     is_add_fail = 2;
     break;
    }
 } /* for loop */

 if( is_add_fail == 1 ) goto errexit;

 if( is_add_fail == 2 ) {
   $ROLLBACK WORK;
   return apiRC;
  }


 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

 errexit:
  MsgCode = SQLCODE;
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if ( SQLCODE != 0 )
   MsgCode = SQLCODE;
  if ( exitsub(reply,MsgCode) == True )
   return MsgCode;
  return apiRC;
}

long car101_single_query(reply)
serverReply reply;
{
 $char icar_type[3],DBName[3],carname[11],drate[10],drate_l[12];
 $int  qperiod;
 $double qcar_personbgn,qcar_personend,mpremium,mbusiness = 0.0;
 $double pready_rate,pcomprate,pstablerate,pinvestrate,pinterest,mresearch = 0.0,pcapital;
 $double maintain = 0.0;
 $char   fassured[2];
 $long mcoverage1,mcoverage2,mcoverage3,mdrunk_prem = 0,mviolate_prem = 0;
 $int qcar_personbgn_isnull,qcar_personend_isnull,mpremium_isnull;
 $int mbusiness_isnull;
 $int pready_rate_isnull = 0,pcomprate_isnull = 0,pstablerate_isnull = 0,pinvestrate_isnull = 0;
 $int pinterest_isnull = 0,mresearch_isnull,pcapital_isnull = 0;
 int   tmp_len;
 $dec_t mpremium_t;
 $char  mpremium_asi[18];

 cm_buf_get("%s %s %d %e %e %l %l %l %s %s",DBName,icar_type,&qperiod \
                               ,&qcar_personbgn,&qcar_personend \
                               ,&mcoverage1,&mcoverage2 \
                               ,&mcoverage3,drate,fassured);
 strcpy(drate_l,cm_to_infdate(drate));
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
    return M_CM_DB_NOTOPEN;
   return apiRC;
  }

 cm_buf_init(ReplyBuf);
 cm_buf_res_msg();
 cm_buf_res_count();

 $SELECT ncode
  INTO $carname
  FROM car_type
  WHERE fclass="1" AND icode=$icar_type;

 if(SQLCODE==SQLNOTFOUND)
  {
   if( exitsub(reply,M_CA_NCARTYPE) == True )
    return M_CA_NCARTYPE;
   return apiRC;
  }

 $SELECT mpremium,mbusiness,pready_rate,pcomprate,pstablerate,pinvestrate,
         pinterest,mresearch,pcapital,maintain,fassured,mdrunk_prem,mviolate_prem
  INTO  $mpremium_t,$mbusiness,$pready_rate:pready_rate_isnull,
        $pcomprate:pcomprate_isnull,$pstablerate:pstablerate_isnull,
        $pinvestrate:pinvestrate_isnull,$pinterest:pinterest_isnull,
        $mresearch,$pcapital:pcapital_isnull,$maintain,$fassured,$mdrunk_prem,$mviolate_prem
  FROM compulsory_premium
  WHERE icar_type=$icar_type AND qperiod=$qperiod
  AND qcar_personbgn=$qcar_personbgn AND qcar_personend=$qcar_personend
  AND mcoverage1=$mcoverage1 AND mcoverage2=$mcoverage2
  AND mcoverage3=$mcoverage3 AND drate=$drate_l AND  fassured = $fassured;
 if(SQLCODE==SQLNOTFOUND)
  {
   if( exitsub(reply,M_CA_NCOMP_PREMIUM) == True )
    return M_CA_NCOMP_PREMIUM;
   return apiRC;
  }
 if(pready_rate_isnull==-1) pready_rate=0;
 if(pcomprate_isnull==-1) pcomprate=0;
 if(pstablerate_isnull==-1) pstablerate=0;
 if(pinvestrate_isnull==-1) pinvestrate=0;
 if(pinterest_isnull==-1) pinterest=0;
 if(pcapital_isnull==-1) pcapital=0;

 /**  Decimal -> Asciaii **/ 
 dectoasc( &mpremium_t, mpremium_asi, sizeof(mpremium_asi), 11 );
 mpremium_asi[17] = '\0';
 printf("==> mpremium_asi [%s] \n", mpremium_asi );

  cm_buf_put("%s %d %s %e %e %l %l %l %s %s %e %e %e %e %e %e %e %e %e %s %l %l",icar_type \
                               ,qperiod,carname \
                               ,qcar_personbgn,qcar_personend \
                               ,mcoverage1,mcoverage2 \
                               ,mcoverage3,drate,mpremium_asi,mbusiness \
                               ,pready_rate,pcomprate,pstablerate \
                               ,pinvestrate,pinterest,mresearch,pcapital,maintain,fassured \
                               ,mdrunk_prem,mviolate_prem);
 cm_buf_put_msg(M_CM_OK);
 tmp_len=cm_buf_len(ReplyBuf);
 if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;


 errexit:
  if ( exitsub(reply,SQLCODE) == True )
   return SQLCODE;
  return apiRC;
}


long car101_multiple_query(reply)
serverReply reply;
{
 $char icar_type[3],k_icar_type[3],DBName[3];
 $char k_drate[10],drate[10],drate_bgn[12],drate_end[12];
 $int  qperiod,cur_int_tmp;

 $double qcar_personbgn,qcar_personend,mpremium,mbusiness;
 $double pready_rate,pcomprate,pstablerate,pinvestrate;
 $long mcoverage1,mcoverage2,mcoverage3;
 $int qcar_personbgn_isnull = 0,qcar_personend_isnull = 0,mpremium_isnull;
 $int mbusiness_isnull;
 $int pready_rate_isnull,pcomprate_isnull,pstablerate_isnull,pinvestrate_isnull;
 $char k_qcar_personbgn[8],k_qcar_personend[8];
 $char k_mcoverage1[9],k_mcoverage2[9],k_mcoverage3[9], fassured[2], k_fassured[2];

 $long drate_l = 0;
 $char qcur_buf[500],qcur_addbuf[100];     /* -- new add -- */
 char tmpbuf[4000],k_qperiod[3];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0,flag;


 cm_buf_get("%s %s %s %s %s %s %s %s %s %s",DBName,k_icar_type,k_qperiod \
                               ,k_qcar_personbgn,k_qcar_personend \
                               ,k_mcoverage1,k_mcoverage2 \
                               ,k_mcoverage3,k_drate,k_fassured);
 if (k_drate[0]=='*') 
   {
    sprintf_s(drate_bgn, sizeof drate_bgn,"01/01/1980");
    sprintf_s(drate_end, sizeof drate_end,"12/31/2999");
   }
 else
   {
    strcpy(drate_bgn,cm_to_infdate(k_drate));
    strcpy(drate_end,cm_to_infdate(k_drate));
   }
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
    return M_CM_DB_NOTOPEN;
   return apiRC;
  }
 sprintf_s(qcur_buf, sizeof qcur_buf,"SELECT icar_type,qperiod,qcar_personbgn,qcar_personend, "
                         " mcoverage1,mcoverage2,mcoverage3,drate, fassured "
                    " FROM compulsory_premium "
                    " WHERE icar_type MATCHES '%s' "
                    " AND drate BETWEEN '%s' AND '%s' "
                  ,k_icar_type,drate_bgn,drate_end); 
 if (k_qperiod[0]!='*')
   {
    qperiod=atoi(k_qperiod);
    sprintf_s(qcur_addbuf, sizeof qcur_addbuf," AND qperiod = %d ",qperiod);
    strcat(qcur_buf,qcur_addbuf);
   } 
 if (k_qcar_personbgn[0]!='*')
   {
    qcar_personbgn=atof(k_qcar_personbgn);
    sprintf_s(qcur_addbuf, sizeof qcur_addbuf," AND qcar_personbgn = %e ",qcar_personbgn);
    strcat(qcur_buf,qcur_addbuf);
   } 
 if (k_qcar_personend[0]!='*')
   {
    qcar_personend=atof(k_qcar_personend);
    sprintf_s(qcur_addbuf, sizeof qcur_addbuf," AND qcar_personend = %e ",qcar_personend);
    strcat(qcur_buf,qcur_addbuf);
   } 
 if (k_mcoverage1[0]!='*') 
   { 
    mcoverage1=atol(k_mcoverage1);
    sprintf_s(qcur_addbuf, sizeof qcur_addbuf," AND mcoverage1 = %ld",mcoverage1); 
    strcat(qcur_buf,qcur_addbuf);
   }
 if (k_mcoverage2[0]!='*') 
   {
    mcoverage2=atol(k_mcoverage2);
    sprintf_s(qcur_addbuf, sizeof qcur_addbuf," AND mcoverage2 = %ld",mcoverage2); 
    strcat(qcur_buf,qcur_addbuf);
   }
 if (k_mcoverage3[0]!='*') 
   {
    mcoverage3=atol(k_mcoverage3);
    sprintf_s(qcur_addbuf, sizeof qcur_addbuf," AND mcoverage3 = %ld",mcoverage3); 
    strcat(qcur_buf,qcur_addbuf);
   }
 if (k_fassured[0]!='*')
   {
    sprintf_s(qcur_addbuf, sizeof qcur_addbuf," AND fassured = '%s' ", k_fassured);
    strcat(qcur_buf,qcur_addbuf);
   } 
 sprintf_s(qcur_addbuf, sizeof qcur_addbuf,"ORDER BY icar_type");
 strcat(qcur_buf,qcur_addbuf);
 $PREPARE mq_tmp FROM $qcur_buf;
 $DECLARE mq_01 CURSOR FOR mq_tmp; 
 $OPEN mq_01;

 for(;;)
  {
    $FETCH mq_01 INTO $icar_type,$qperiod,$qcar_personbgn:qcar_personbgn_isnull
                        ,$qcar_personend:qcar_personend_isnull 
                        ,$mcoverage1,$mcoverage2,$mcoverage3,$drate_l,$fassured; 
    if (SQLCODE != 0) break;
    strcpy(drate,cm_cdate_str_100(drate_l));
    if(qcar_personbgn_isnull==-1) qcar_personbgn=0;
    if(qcar_personend_isnull==-1) qcar_personend=0;
    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
        cm_buf_put("%s %d %e %e %l %l %l %s %s",icar_type,qperiod \
                               ,qcar_personbgn,qcar_personend \
                               ,mcoverage1,mcoverage2 \
                               ,mcoverage3,drate,fassured);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE mq_01;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %d %e %e %l %l %l %s %s",icar_type,qperiod \
                               ,qcar_personbgn,qcar_personend \
                               ,mcoverage1,mcoverage2 \
                               ,mcoverage3,drate,fassured);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

  $CLOSE mq_01;

 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any raw is found */
  {
   if( exitsub(reply,M_CA_NCOMP_PREMIUM) == True )
    return M_CA_NCOMP_PREMIUM;
   return apiRC;
  }

 errexit:
  if ( exitsub(reply,SQLCODE) == True )
   return SQLCODE;
  return apiRC;
}


long car101_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 $char DBName[3],carname[11],icar_type[3],cur_icar_type[3],drate[10],drate_e[12];
 $char cur_drate[10], cur_drate_e[12], fassured[2], cur_fassured[2];
 $int  qperiod,cur_qperiod;

 $double qcar_personbgn,qcar_personend,mpremium,mbusiness;
 $double pready_rate,pcomprate,pstablerate,pinvestrate,pinterest,mresearch,pcapital,maintain;
 $long mcoverage1,mcoverage2,mcoverage3,mdrunk_prem,mviolate_prem;
 $double cur_qcar_personbgn,cur_qcar_personend,cur_mbusiness, cur_mpremium;
 $double cur_pready_rate,cur_pcomprate,cur_pstablerate,cur_pinvestrate,cur_pinterest,cur_mresearch,cur_pcapital;
 $double cur_maintain;
 $long cur_mcoverage1,cur_mcoverage2,cur_mcoverage3,cur_mdrunk_prem,cur_mviolate_prem;
 $int cur_mresearch_isnull,cur_pcapital_isnull;
 DBinfo *list;
 char option,*pos,*raw_ptr,cur_buf[4000],*comm,type;
 int tmp_len,raw_len,count,rows=0,i,flag;
 long dummy;
 int k, j, is_del_fail=0, is_upd_fail=0;
 $char stmt_buf[1024];
 $char   mpremium_asi[18], mpremium_sdec[18];
 $dec_t  mpremium_dec, mpremium_t; 

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
     return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
     return exitsub(reply,M_CM_NOT_DBLIST) ? M_CM_NOT_DBLIST : apiRC;

 /* compare old record and current record, if the record has not been changed
    since last request, update or delete the record, otherwise return errmsg
    to client side */

 /* get old record info from command buffer */

 memcpy(&raw_len,&comm[com_len],sizeof(int));
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)
  memcpy(raw_ptr,pos,raw_len);
 else
  { /* malloc fail */
    return  exitsub(reply,M_CM_NOT_MALLOC) ? M_CM_NOT_MALLOC : apiRC;
  }

 /* get index key from old record, dummy is the MsgCode */

 cm_buf_init(raw_ptr);
 cm_buf_get("%l %d %s %d %s %e %e %l %l %l %s %s %e %e %e %e %e %e %e %e %e %s %l %l" \
                               ,&dummy,&count,icar_type \
                               ,&qperiod,carname \
                               ,&qcar_personbgn,&qcar_personend \
                               ,&mcoverage1,&mcoverage2 \
                               ,&mcoverage3,drate,mpremium_asi,&mbusiness \
                               ,&pready_rate,&pcomprate,&pstablerate \
                               ,&pinvestrate,&pinterest,&mresearch,&pcapital,&maintain \
                               ,fassured,&mdrunk_prem,&mviolate_prem);

 strcpy(drate_e,cm_to_infdate(drate));

 $BEGIN WORK;
 $SELECT mpremium,mbusiness,pready_rate,pcomprate,pstablerate,pinvestrate,pinterest,mresearch,pcapital,maintain,
         fassured,mdrunk_prem,mviolate_prem
  INTO $mpremium_dec,$cur_mbusiness,$cur_pready_rate,$cur_pcomprate,
       $cur_pstablerate,$cur_pinvestrate,$cur_pinterest,
       $cur_mresearch,$cur_pcapital:cur_pcapital_isnull,$cur_maintain, $cur_fassured,
       $cur_mdrunk_prem,$cur_mviolate_prem
  FROM compulsory_premium        
  WHERE icar_type=$icar_type AND qperiod=$qperiod
  AND qcar_personbgn=$qcar_personbgn AND qcar_personend=$qcar_personend
  AND mcoverage1=$mcoverage1 AND mcoverage2=$mcoverage2  
  AND mcoverage3=$mcoverage3 AND drate=$drate_e
  AND fassured = $fassured;

   if(cur_pcapital_isnull==-1) cur_pcapital=0;

printf("222\n");
  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */

 if (SQLCODE == SQLNOTFOUND)
     return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND : apiRC;

 dectoasc( &mpremium_dec, mpremium_sdec, sizeof(mpremium_sdec), 11 );
 mpremium_sdec[17] = '\0';
 printf("==> mpremium_sdec [%s] \n", mpremium_sdec );

printf("333\n");
 cm_buf_init(cur_buf);         /* must reserve msg and count for comparison */
 cm_buf_res_msg();
 cm_buf_res_count();
 cm_buf_put_msg(dummy);
 cm_buf_put_count(count);
 cm_buf_put("%s %d %s %e %e %l %l %l %s %s %e %e %e %e %e %e %e %e %e %s %l %l",icar_type \
                               ,qperiod,carname \
                               ,qcar_personbgn,qcar_personend \
                               ,mcoverage1,mcoverage2 \
                               ,mcoverage3,drate,mpremium_sdec,cur_mbusiness \
                               ,cur_pready_rate,cur_pcomprate,cur_pstablerate \
                               ,cur_pinvestrate,cur_pinterest,cur_mresearch,cur_pcapital \
                               ,cur_maintain, cur_fassured,cur_mdrunk_prem,cur_mviolate_prem);

 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
     return exitsub(reply,M_CM_NOT_EQUAL) ? M_CM_NOT_EQUAL : apiRC;

 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
   for(j=0;j<i;j++)  /* original: j=0;j<i;j++ */
   {
    sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM %s:compulsory_premium WHERE icar_type=? "
                     " AND qcar_personbgn=? "
                     " AND qcar_personend=? AND qperiod=? "
                     " AND mcoverage1=? AND mcoverage2=? AND mcoverage3=? "
                     " AND drate=? AND fassured= ?",list[j].dbname);
    $PREPARE d_id FROM $stmt_buf;
    if(SQLCODE != 0) {
      is_del_fail = 1;
      break;
     }
    $EXECUTE d_id USING $icar_type,$qcar_personbgn,$qcar_personend 
                        ,$qperiod,$mcoverage1,$mcoverage2,$mcoverage3,$drate_e, $fassured;
    if(SQLCODE != 0) {
      is_del_fail = 1;
      break;
     }
   }/* for loop */

   if( is_del_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
   cm_buf_init(command);
   cm_buf_get("%c %s",&option,DBName);
   cm_buf_get("%s %d %e %e %l %l %l %e %e %s %e %e %e %e %e %e %e %e %s %l %l",cur_icar_type, \
                &cur_qperiod,&cur_qcar_personbgn,&cur_qcar_personend, \
                &cur_mcoverage1,&cur_mcoverage2,&cur_mcoverage3, \
                &cur_mpremium,&cur_mbusiness,cur_drate, \
                &cur_pready_rate,&cur_pcomprate,&cur_pstablerate, \
                &cur_pinvestrate,&cur_pinterest,&cur_mresearch,&cur_pcapital,&cur_maintain, \
                 cur_fassured,&cur_mdrunk_prem,&cur_mviolate_prem);
                 
   strcpy(cur_drate_e,cm_to_infdate(cur_drate));

/* --------------------- mark area ---------------------- 
   if ( !strcmp(icar_type,cur_icar_type) && (qperiod == cur_qperiod) )
     flag = 0;
   else
     flag = 1;
   --------------------- mark area ---------------------- */


   $WHENEVER SQLERROR CONTINUE;

   for(j=0;j<i;j++)     /* original: j=0;j<i;j++ */
   {
        sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE %s:compulsory_premium "
        " SET (icar_type,qperiod,qcar_personbgn,qcar_personend,mcoverage1, "
        " mcoverage2,mcoverage3,mpremium,mbusiness,drate,pready_rate,pcomprate, "
        " pstablerate,pinvestrate,pinterest,mresearch,pcapital,maintain,fassured,mdrunk_prem,mviolate_prem) "
        " = (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) WHERE icar_type=? AND qperiod=? "
                    " AND qcar_personbgn=? "
                    " AND qcar_personend=? "
                    " AND mcoverage1=? AND mcoverage2=? AND mcoverage3=? "
                    " AND drate=? AND fassured=?",list[j].dbname);

printf("ccc\n");
    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
printf("drate_e=[%s]\n",drate_e);
    $EXECUTE u_id USING $cur_icar_type,$cur_qperiod,$cur_qcar_personbgn,
                        $cur_qcar_personend,$cur_mcoverage1,$cur_mcoverage2,
                        $cur_mcoverage3,$cur_mpremium,$cur_mbusiness,
                        $cur_drate_e,$cur_pready_rate,$cur_pcomprate,
                        $cur_pstablerate,$cur_pinvestrate,$cur_pinterest,
                        $cur_mresearch,$cur_pcapital,$cur_maintain,$cur_fassured,
                        $cur_mdrunk_prem,$cur_mviolate_prem,
                        $icar_type,$qperiod,$qcar_personbgn,$qcar_personend,
                        $mcoverage1,$mcoverage2,$mcoverage3,$drate_e,$fassured; 
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {
      sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:compulsory_premium "
        "(icar_type,qperiod,qcar_personbgn,qcar_personend,mcoverage1, "
        " mcoverage2,mcoverage3,mpremium,mbusiness,drate,pready_rate, "
        " pcomprate,pstablerate,pinvestrate,pinterest,mresearch,pcapital,maintain,fassured,mdrunk_prem,mviolate_prem) "
        " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)" ,list[j].dbname);
      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0) {
        is_upd_fail = 1;
        break;
       }
printf("drate_e=[%s]\n",drate_e);
    $EXECUTE ua_id USING $cur_icar_type,$cur_qperiod,$cur_qcar_personbgn,
                        $cur_qcar_personend,$cur_mcoverage1,$cur_mcoverage2,
                        $cur_mcoverage3,$cur_mpremium,$cur_mbusiness,
                        $cur_drate_e,$cur_pready_rate,$cur_pcomprate,
                        $cur_pstablerate,$cur_pinvestrate,$cur_pinterest,
                        $cur_mresearch,$cur_pcapital,$cur_maintain,$cur_fassured,$cur_mdrunk_prem,$cur_mviolate_prem;
      if(SQLCODE != 0) {
        is_upd_fail = 1;
        break;
       }
     }
/*  ---------------------- mark area -------------------------
    if (is_upd_fail == 3){
        is_upd_fail = 1;
        break;
    }
   if ( flag == 1 )
    {
        $PREPARE u4_id FROM $stmt_buf;
        if(SQLCODE != 0) {
                is_upd_fail = 1;
                break;
        }
        $EXECUTE u4_id USING $cur_icar_type,$cur_qperiod,$icar_type,$qperiod;
        if(SQLCODE != 0) {
                is_upd_fail = 1;
                break;
        }
    }
    ---------------------- mark area -------------------------- */
   } /* for loop */

   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else    /* option is not 'D' or 'U' */
  {
puts("mck 2");
   if (exitsub(reply,M_CM_WRONG_OPTION) == True)
    return M_CM_WRONG_OPTION;
   return apiRC;
  }

 errexit:
  MsgCode = SQLCODE;
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if (SQLCODE !=0)
   MsgCode = SQLCODE;
  if (exitsub(reply,MsgCode) == True)
   return MsgCode;
  return apiRC;
}
