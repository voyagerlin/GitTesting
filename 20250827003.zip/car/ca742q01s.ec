/**********************************************************************/
/*   program id   : ca742q01s.ec                                      */
/*   program name : �j��q�l���Ҳέp����-���īO��                     */
/*   date written : 2021/10/26 by 041090                              */
/*   files        :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"

$char dply_end_tmp[11],dpolicy_tmp[11];
$char dply_end[11],dpolicy[11];

int   count_db,k; 
char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];

DBinfo *list;

main(argc, argv)
int argc;
char **argv;
{
 int rc;

	batchinit();
	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(dply_end_tmp,   isNULLstr(argv[3]));
	strcpy(outputf,        isNULLstr(argv[4]));
	
	strcpy(dply_end,cm_to_infdate(dply_end_tmp));
	strcpy(dpolicy,dply_end);
	
	rc = car7421_get_db();
	if (rc != M_CM_OK)
		return rc;

	rc = car7421_prepare_data();
	if (rc != M_CM_OK)
		return rc;

	rc = car7421_build();
	if (rc != M_CM_OK) 
		return rc;
		
	$DROP TABLE ply_tmp;
	$DROP TABLE ply_tmp_ecard;
	$DROP TABLE ply_show;
	$DROP TABLE ply_validcard;
	$DROP TABLE ply_ecard;
	$DROP TABLE ply_phone_mail;
	$DROP TABLE ply_sendecard;
}

long car7421_get_db()
{
	$whenever sqlerror goto errexit;

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car7421_prepare_data()
{
	$char stmt[4096],stmp1[4096],stmp2[4096];
	$char stmp_cont[1024];
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == FALSE)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return FAIL;
	}

	$CREATE TEMP TABLE ply_tmp
	(
		ipolicy       char (20),
		icard         char (20),
		bzfrom        char (2),
		fassured      char (1),
		ileader       char (10),
		feply         char (1),
		itmp_policy   char (20),
		tmobile_eply  VARCHAR (20),
		aemail_eply   VARCHAR (50),
		mobil_phone   char (20),
		iemail        VARCHAR (50),
		tmobile_appl  VARCHAR (20),
		aemail_appl   VARCHAR (50),
		dpolicy       DATE,
		iexaminer     char (10),
		ientry        char (10)
	)with no log;
	$CREATE INDEX ply_tmp_ind1 ON ply_tmp(ipolicy);
	$CREATE INDEX ply_tmp_ind2 ON ply_tmp(bzfrom);
	$CREATE INDEX ply_tmp_ind3 ON ply_tmp(fassured);
	
	$CREATE TEMP TABLE ply_tmp_ecard
	(
		ipolicy       char (20),
		icard         char (20),
		bzfrom        char (2),
		fassured      char (1),
		ileader       char (10),
		feply         char (1),
		itmp_policy   char (20),
		tmobile_eply  VARCHAR (20),
		aemail_eply   VARCHAR (50),
		mobil_phone   char (20),
		iemail        VARCHAR (50),
		tmobile_appl  VARCHAR (20),
		aemail_appl   VARCHAR (50),
		dpolicy       DATE,
		iexaminer     char (10),
		ientry        char (10)
	)with no log;
	$CREATE INDEX ply_tmp_ecard_ind1 ON ply_tmp_ecard(ipolicy);
	$CREATE INDEX ply_tmp_ecard_ind2 ON ply_tmp_ecard(fassured);
	$CREATE INDEX ply_tmp_ecard_ind3 ON ply_tmp_ecard(tmobile_eply);
	$CREATE INDEX ply_tmp_ecard_ind4 ON ply_tmp_ecard(aemail_eply);
	$CREATE INDEX ply_tmp_ecard_ind5 ON ply_tmp_ecard(ientry);
	$CREATE INDEX ply_tmp_ecard_ind6 ON ply_tmp_ecard(iexaminer);

	/* f_NL-N:�۵M�H L:�k�H */
	$CREATE temp TABLE ply_show
	(
		iserial         INT,
		f_NL            char(1)
	);
	$INSERT INTO ply_show VALUES(1,'N');
	$INSERT INTO ply_show VALUES(2,'L');
	
	/* ���īO�� */
	$CREATE TEMP TABLE ply_validcard
	(
		f_NL            char(1),
		bzfrom          char(2),
		cnt_validcard   int
	)with no log;
	$CREATE INDEX ply_validcard_ind1 ON ply_validcard(f_NL);
	$CREATE INDEX ply_validcard_ind2 ON ply_validcard(bzfrom);

	/* �����s�q�l���O�I�� */
	$CREATE TEMP TABLE ply_ecard
	(
		f_NL            char(1),
		bzfrom          char(2),
		cnt_fecard      int
	)with no log;
	$CREATE INDEX ply_ecard_ind1 ON ply_ecard(f_NL);
	$CREATE INDEX ply_ecard_ind2 ON ply_ecard(bzfrom);
	
	/* ������Ȥ�(�t�J���Ȥ�)����ʹq�ܤιq�l�l�� */
	$CREATE TEMP TABLE ply_phone_mail
	(
		f_NL            char(1),
		bzfrom          char(2),
		cnt_phone_mail  int
	)with no log;
	$CREATE INDEX ply_phone_mail_ind1 ON ply_phone_mail(f_NL);
	$CREATE INDEX ply_phone_mail_ind2 ON ply_phone_mail(bzfrom);
	
	/* �T��H�e�q�l���O�I�� */
	$CREATE TEMP TABLE ply_sendecard
	(
		f_NL            char(1),
		bzfrom          char(2),
		cnt_sendecard   int
	)with no log;
	$CREATE INDEX ply_sendecard_ind1 ON ply_sendecard(f_NL);
	$CREATE INDEX ply_sendecard_ind2 ON ply_sendecard(bzfrom);
	
	/* ���īO�� */
	for(k=0;k<count_db;k++) 
	{
		sprintf(stmt,"INSERT INTO ply_tmp \
		               SELECT a.ipolicy,a.icard,bzfrom,b.fassured,a.ileader,a.feply,a.itmp_policy, \
		                      a.tmobile_eply,a.aemail_eply,b.mobil_phone,b.iemail,b.tmobile_appl,b.aemail_appl, \
		                      a.dpolicy,a.iexaminer,a.ientry \
		                 FROM %s:ply_relation a,%s:policy b \
		                WHERE a.ipolicy = b.ipolicy \
		                  AND a.dply_end >= ? \
		                  AND a.dpolicy <= ?  \
		                  AND a.fcard_class = '1' ", list[k].dbname,list[k].dbname);
		printf("stmt[%s] \n",stmt);
		$PREPARE ply_data FROM $stmt;
		$EXECUTE ply_data USING $dply_end, $dpolicy;
	}

	/* �۵M�H���īO�� */
	$INSERT INTO ply_validcard
	 SELECT 'N',bzfrom,count(*) 
	  FROM ply_tmp 
	 WHERE fassured IN ('1','3','5')
	 GROUP BY 1,2;
	 
	/* �k�H���īO�� */
	$INSERT INTO ply_validcard
	 SELECT 'L',bzfrom,count(*) 
	   FROM ply_tmp 
	  WHERE fassured IN ('2','4','6')
	 GROUP BY 1,2;
	
	/* �����s�q�l���O�I�� */
	$INSERT INTO ply_tmp_ecard
	 SELECT ipolicy,icard,bzfrom,fassured,ileader,feply,itmp_policy,
	        tmobile_eply,aemail_eply,mobil_phone,iemail,tmobile_appl,aemail_appl,
	        dpolicy,iexaminer,ientry
	   FROM ply_tmp 
	  WHERE (ipolicy IN (SELECT ipolicy
	                       FROM newa00:ca_ecard_log 
	                      WHERE (result_code IN ('S0000') OR result_code[1,2] = 'E1' OR result_code[1,2] = 'E2' OR result_code[1,2] = 'E3' OR result_code[1,2] = 'E8' OR result_code = 'E9000')) 
	     OR (ientry = 'TRADE/SYS' OR iexaminer = 'TRADE/SYS'));

	/* �����s�q�l���O�I��-�۵M�H */
	$INSERT INTO ply_ecard
	 SELECT 'N',bzfrom,count(*)
	   FROM ply_tmp_ecard a
	  WHERE fassured IN ('1','3','5')
	  GROUP BY 1,2;
	  
	/* �����s�q�l���O�I��-�k�H */
	$INSERT INTO ply_ecard
	 SELECT 'L',bzfrom,count(*)
	   FROM ply_tmp_ecard a
	  WHERE fassured IN ('2','4','6')
	  GROUP BY 1,2;
	
	/* ������Ȥ�(�t�J���Ȥ�)����ʹq�ܤΤl�l��-�۵M�H */
	$INSERT INTO ply_phone_mail
	 SELECT 'N',bzfrom,count(*)
	   FROM ply_tmp_ecard 
	  WHERE fassured IN ('1','3','5') 
	    AND (trim(nvl(tmobile_appl,'')) = '' AND trim(nvl(aemail_appl,'')) = '') 
	    AND (trim(nvl(tmobile_eply,'')) = '' AND trim(nvl(aemail_eply,'')) = '') 
	  GROUP BY 1,2;
	  
	/* ������Ȥ�(�t�J���Ȥ�)����ʹq�ܤΤl�l��-�k�H */
	$INSERT INTO ply_phone_mail
	 SELECT 'L',bzfrom,count(*)
	   FROM ply_tmp_ecard 
	  WHERE fassured IN ('2','4','6') 
	    AND (trim(nvl(tmobile_appl,'')) = '' AND trim(nvl(aemail_appl,'')) = '') 
	    AND (trim(nvl(tmobile_eply,'')) = '' AND trim(nvl(aemail_eply,'')) = '') 
	  GROUP BY 1,2;
	
	/* �T��H�e�q�l���O�I��-�۵M�H */
	strcpy(stmp_cont,"\%\%\"sendOrNot\":\"Y\"\%\%");
	printf("stmp_cont[%s]\n",stmp_cont);
	
	sprintf(stmp1,"INSERT INTO ply_sendecard \
	               SELECT 'N',bzfrom,count(*) \
	                 FROM ply_tmp_ecard  \
	                WHERE ( \
	                        fassured IN ('1','3','5')  \
	                        AND (((ientry = 'TRADE/SYS' OR iexaminer = 'TRADE/SYS') AND (trim(nvl(tmobile_appl,'')) <> '' OR trim(nvl(aemail_appl,'')) <> ''))  \
	                         OR ((ientry <> 'TRADE/SYS' AND iexaminer <> 'TRADE/SYS') AND (trim(nvl(aemail_eply,'')) <> '' OR trim(nvl(tmobile_eply,'')) <> ''))) \
	                      ) \
	                   OR (  \
	                        ipolicy IN  \
	                        (SELECT DISTINCT a.ipolicy FROM ply_tmp_ecard a,newa00:ca_ecard_log b  \
	                          WHERE a.fassured IN ('1','3','5')   \
	                            AND (((trim(nvl(a.tmobile_appl,'')) = '' AND trim(nvl(a.aemail_appl,'')) = '') AND (a.ientry = 'TRADE/SYS' OR a.iexaminer = 'TRADE/SYS'))  \
	                             OR ((trim(nvl(a.aemail_eply,'')) = '' AND trim(nvl(a.tmobile_eply,'')) = '') AND (a.ientry <> 'TRADE/SYS' AND a.iexaminer <> 'TRADE/SYS'))) \
	                            AND a.ipolicy=b.ipolicy   \
	                            AND (b.trans_type='5' OR (b.trans_type = '8' AND b.trans_content LIKE '%s')) \
	                        ) \
	                      ) \
	                GROUP BY 1,2",stmp_cont);
	printf("stmp1[%s] \n",stmp1);
	$PREPARE sendecard1 FROM $stmp1;
	$EXECUTE sendecard1;
	
	/* �T��H�e�q�l���O�I��-�k�H */
	sprintf(stmp2,"INSERT INTO ply_sendecard \
	               SELECT 'L',bzfrom,count(*) \
	                 FROM ply_tmp_ecard  \
	                WHERE (  \
	                        fassured IN ('2','4','6')  \
	                        AND (((ientry = 'TRADE/SYS' OR iexaminer = 'TRADE/SYS') AND (trim(nvl(tmobile_appl,'')) <> '' OR trim(nvl(aemail_appl,'')) <> ''))  \
	                         OR ((ientry <> 'TRADE/SYS' AND iexaminer <> 'TRADE/SYS') AND (trim(nvl(aemail_eply,'')) <> '' OR trim(nvl(tmobile_eply,'')) <> ''))) \
	                      ) \
	                   OR (  \
	                        ipolicy IN  \
	                        (SELECT DISTINCT a.ipolicy FROM ply_tmp_ecard a,newa00:ca_ecard_log b  \
	                          WHERE a.fassured IN ('2','4','6')   \
	                            AND (((trim(nvl(a.tmobile_appl,'')) = '' AND trim(nvl(a.aemail_appl,'')) = '') AND (a.ientry = 'TRADE/SYS' OR a.iexaminer = 'TRADE/SYS'))  \
	                             OR ((trim(nvl(a.aemail_eply,'')) = '' AND trim(nvl(a.tmobile_eply,'')) = '') AND (a.ientry <> 'TRADE/SYS' AND a.iexaminer <> 'TRADE/SYS'))) \
	                            AND a.ipolicy=b.ipolicy   \
	                            AND (b.trans_type='5' OR (b.trans_type = '8' AND b.trans_content LIKE '%s')) \
	                        ) \
	                      ) \
	                GROUP BY 1,2",stmp_cont);
	printf("stmp2[%s] \n",stmp2);
	$PREPARE sendecard2 FROM $stmp2;
	$EXECUTE sendecard2;
	
	return M_CM_OK;
	
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/


long car7421_build()
{
	$int rc;
	$char sfilename[256],stitle[4096],stmt2[20000];

	$WHENEVER SQLERROR GOTO errexit;
	
	strcpy(sfilename,"�j��q�l���Ҳέp����[car74211]\n");
	strcpy(stitle,"\t\t10\t10\t10\t10\t10\t10\t10\t");
	strcat(stitle,"20\t20\t20\t20\t20\t20\t20\t");
	strcat(stitle,"21\t21\t21\t21\t21\t21\t21\t");
	strcat(stitle,"30\t30\t30\t30\t30\t30\t30\t");
	strcat(stitle,"31\t31\t31\t31\t31\t31\t31\t");
	strcat(stitle,"40\t40\t40\t40\t40\t40\t40\t");
	strcat(stitle,"41\t41\t41\t41\t41\t41\t41\t");
	strcat(stitle,"�[�`\t�[�`\t�[�`\t�[�`\t�[�`\t�[�`\t�[�`\n");
	strcat(stitle,"\t���īO��\t�Ȥ��ݩ�\t���īO��\t�����s�q�l���O�I��\t\t������Ȥ�(�t�J���Ȥ�)����ʹq�ܤΤl�l��\t\t�T��H�e�q�l���O�I��\t\t");
	strcat(stitle,"���īO��\t�����s�q�l���O�I��\t\t������Ȥ�(�t�J���Ȥ�)����ʹq�ܤΤl�l��\t\t�T��H�e�q�l���O�I��\t\t");
	strcat(stitle,"���īO��\t�����s�q�l���O�I��\t\t������Ȥ�(�t�J���Ȥ�)����ʹq�ܤΤl�l��\t\t�T��H�e�q�l���O�I��\t\t");
	strcat(stitle,"���īO��\t�����s�q�l���O�I��\t\t������Ȥ�(�t�J���Ȥ�)����ʹq�ܤΤl�l��\t\t�T��H�e�q�l���O�I��\t\t");
	strcat(stitle,"���īO��\t�����s�q�l���O�I��\t\t������Ȥ�(�t�J���Ȥ�)����ʹq�ܤΤl�l��\t\t�T��H�e�q�l���O�I��\t\t");
	strcat(stitle,"���īO��\t�����s�q�l���O�I��\t\t������Ȥ�(�t�J���Ȥ�)����ʹq�ܤΤl�l��\t\t�T��H�e�q�l���O�I��\t\t");
	strcat(stitle,"���īO��\t�����s�q�l���O�I��\t\t������Ȥ�(�t�J���Ȥ�)����ʹq�ܤΤl�l��\t\t�T��H�e�q�l���O�I��\t\t");
	strcat(stitle,"���īO��\t�����s�q�l���O�I��\t\t������Ȥ�(�t�J���Ȥ�)����ʹq�ܤΤl�l��\t\t�T��H�e�q�l���O�I��\t\t\n");
	strcat(stitle,"\t���\t\t���\t���\t��v%\t���\t��v%\t���\t��v%\t");
	strcat(stitle,"���\t���\t��v%\t���\t��v%\t���\t��v%\t");
	strcat(stitle,"���\t���\t��v%\t���\t��v%\t���\t��v%\t");
	strcat(stitle,"���\t���\t��v%\t���\t��v%\t���\t��v%\t");
	strcat(stitle,"���\t���\t��v%\t���\t��v%\t���\t��v%\t");
	strcat(stitle,"���\t���\t��v%\t���\t��v%\t���\t��v%\t");
	strcat(stitle,"���\t���\t��v%\t���\t��v%\t���\t��v%\t");
	strcat(stitle,"���\t���\t��v%\t���\t��v%\t���\t��v%\t");

	strcpy(stmt2," SELECT NVL((SELECT count(*) FROM ply_tmp WHERE fassured IN ('1','3','5')),0),                                                                      "
	              "        '�۵M�H',                                                                                                                                   "
	              "        NVL((SELECT sum(cnt_validcard) FROM ply_validcard WHERE f_NL = a.f_NL AND bzfrom = '10'),0),                                                "
	              "        NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '10'),0),                                                       "
	              "        ROUND(NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '10'),0)/(SELECT count(*) FROM ply_tmp),4)*100,           "
	              "        NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '10'),0),                                              "
	              "        ROUND(NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '10'),0)/(SELECT count(*) FROM ply_tmp),4)*100,  "
	              "        NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '10'),0),                                                "
	              "        ROUND(NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '10'),0)/(SELECT count(*) FROM ply_tmp),4)*100,    "
	              "        NVL((SELECT sum(cnt_validcard) FROM ply_validcard WHERE f_NL = a.f_NL AND bzfrom = '20'),0),                                                "
	              "        NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '20'),0),                                                       "
	              "        ROUND(NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '20'),0)/(SELECT count(*) FROM ply_tmp),4)*100,           "
	              "        NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '20'),0),                                              "
	              "        ROUND(NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '20'),0)/(SELECT count(*) FROM ply_tmp),4)*100,  "
	              "        NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '20'),0),                                                "
	              "        ROUND(NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '20'),0)/(SELECT count(*) FROM ply_tmp),4)*100,    "
	              "        NVL((SELECT sum(cnt_validcard) FROM ply_validcard WHERE f_NL = a.f_NL AND bzfrom = '21'),0),                                                "
	              "        NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '21'),0),                                                       "
	              "        ROUND(NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '21'),0)/(SELECT count(*) FROM ply_tmp),4)*100,           "
	              "        NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '21'),0),                                              "
	              "        ROUND(NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '21'),0)/(SELECT count(*) FROM ply_tmp),4)*100,  "
	              "        NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '21'),0),                                                "
	              "        ROUND(NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '21'),0)/(SELECT count(*) FROM ply_tmp),4)*100,    "
	              "        NVL((SELECT sum(cnt_validcard) FROM ply_validcard WHERE f_NL = a.f_NL AND bzfrom = '30'),0),                                                "
	              "        NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '30'),0),                                                       "
	              "        ROUND(NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '30'),0)/(SELECT count(*) FROM ply_tmp),4)*100,           "
	              "        NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '30'),0),                                              "
	              "        ROUND(NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '30'),0)/(SELECT count(*) FROM ply_tmp),4)*100,  "
	              "        NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '30'),0),                                                "
	              "        ROUND(NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '30'),0)/(SELECT count(*) FROM ply_tmp),4)*100,    "
	              "        NVL((SELECT sum(cnt_validcard) FROM ply_validcard WHERE f_NL = a.f_NL AND bzfrom = '31'),0),                                                "
	              "        NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '31'),0),                                                       "
	              "        ROUND(NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '31'),0)/(SELECT count(*) FROM ply_tmp),4)*100,           "
	              "        NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '31'),0),                                              "
	              "        ROUND(NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '31'),0)/(SELECT count(*) FROM ply_tmp),4)*100,  "
	              "        NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '31'),0),                                                "
	              "        ROUND(NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '31'),0)/(SELECT count(*) FROM ply_tmp),4)*100,    "
	              "        NVL((SELECT sum(cnt_validcard) FROM ply_validcard WHERE f_NL = a.f_NL AND bzfrom = '40'),0),                                                "
	              "        NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '40'),0),                                                       "
	              "        ROUND(NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '40'),0)/(SELECT count(*) FROM ply_tmp),4)*100,           "
	              "        NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '40'),0),                                              "
	              "        ROUND(NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '40'),0)/(SELECT count(*) FROM ply_tmp),4)*100,  "
	              "        NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '40'),0),                                                "
	              "        ROUND(NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '40'),0)/(SELECT count(*) FROM ply_tmp),4)*100,    "
	              "        NVL((SELECT sum(cnt_validcard) FROM ply_validcard WHERE f_NL = a.f_NL AND bzfrom = '41'),0),                                                "
	              "        NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '41'),0),                                                       "
	              "        ROUND(NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '41'),0)/(SELECT count(*) FROM ply_tmp),4)*100,           "
	              "        NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '41'),0),                                              "
	              "        ROUND(NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '41'),0)/(SELECT count(*) FROM ply_tmp),4)*100,  "
	              "        NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '41'),0),                                                "
	              "        ROUND(NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '41'),0)/(SELECT count(*) FROM ply_tmp),4)*100,    "
	              "       NVL((SELECT sum(cnt_validcard) FROM ply_validcard WHERE f_NL = a.f_NL),0),                                                                   "
	              "        NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL),0),                                                                         "
	              "        ROUND(NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL),0)/(SELECT count(*) FROM ply_tmp),4)*100,                             "
	              "        NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL),0),                                                                "
	              "        ROUND(NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL),0)/(SELECT count(*) FROM ply_tmp),4)*100,                    "
	              "        NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL),0),                                                                  "
	              "        ROUND(NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL ),0)/(SELECT count(*) FROM ply_tmp),4)*100                      "
	              "   FROM ply_show a                                                                                                                                  "
	              "  WHERE iserial = 1 AND f_NL = 'N'                                                                                                                  "
	              "  UNION ALL                                                                                                                                         "
	              " SELECT NVL((SELECT count(*) FROM ply_tmp WHERE fassured IN ('2','4','6')),0),                                                                      "
	              "        '�k�H',                                                                                                                                     "
	              "        NVL((SELECT sum(cnt_validcard) FROM ply_validcard WHERE f_NL = a.f_NL AND bzfrom = '10'),0),                                                "
	              "        NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '10'),0),                                                       "
	              "        ROUND(NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '10'),0)/(SELECT count(*) FROM ply_tmp),4)*100,           "
	              "        NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '10'),0),                                              "
	              "        ROUND(NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '10'),0)/(SELECT count(*) FROM ply_tmp),4)*100,  "
	              "        NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '10'),0),                                                "
	              "        ROUND(NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '10'),0)/(SELECT count(*) FROM ply_tmp),4)*100,    "
	              "        NVL((SELECT sum(cnt_validcard) FROM ply_validcard WHERE f_NL = a.f_NL AND bzfrom = '20'),0),                                                "
	              "        NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '20'),0),                                                       "
	              "        ROUND(NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '20'),0)/(SELECT count(*) FROM ply_tmp),4)*100,           "
	              "        NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '20'),0),                                              "
	              "        ROUND(NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '20'),0)/(SELECT count(*) FROM ply_tmp),4)*100,  "
	              "        NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '20'),0),                                                "
	              "        ROUND(NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '20'),0)/(SELECT count(*) FROM ply_tmp),4)*100,    "
	              "        NVL((SELECT sum(cnt_validcard) FROM ply_validcard WHERE f_NL = a.f_NL AND bzfrom = '21'),0),                                                "
	              "        NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '21'),0),                                                       "
	              "        ROUND(NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '21'),0)/(SELECT count(*) FROM ply_tmp),4)*100,           "
	              "        NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '21'),0),                                              "
	              "        ROUND(NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '21'),0)/(SELECT count(*) FROM ply_tmp),4)*100,  "
	              "        NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '21'),0),                                                "
	              "        ROUND(NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '21'),0)/(SELECT count(*) FROM ply_tmp),4)*100,    "
	              "        NVL((SELECT sum(cnt_validcard) FROM ply_validcard WHERE f_NL = a.f_NL AND bzfrom = '30'),0),                                                "
	              "        NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '30'),0),                                                       "
	              "        ROUND(NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '30'),0)/(SELECT count(*) FROM ply_tmp),4)*100,           "
	              "        NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '30'),0),                                              "
	              "        ROUND(NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '30'),0)/(SELECT count(*) FROM ply_tmp),4)*100,  "
	              "        NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '30'),0),                                                "
	              "        ROUND(NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '30'),0)/(SELECT count(*) FROM ply_tmp),4)*100,    "
	              "        NVL((SELECT sum(cnt_validcard) FROM ply_validcard WHERE f_NL = a.f_NL AND bzfrom = '31'),0),                                                "
	              "        NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '31'),0),                                                       "
	              "        ROUND(NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '31'),0)/(SELECT count(*) FROM ply_tmp),4)*100,           "
	              "        NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '31'),0),                                              "
	              "        ROUND(NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '31'),0)/(SELECT count(*) FROM ply_tmp),4)*100,  "
	              "        NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '31'),0),                                                "
	              "        ROUND(NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '31'),0)/(SELECT count(*) FROM ply_tmp),4)*100,    "
	              "        NVL((SELECT sum(cnt_validcard) FROM ply_validcard WHERE f_NL = a.f_NL AND bzfrom = '40'),0),                                                "
	              "        NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '40'),0),                                                       "
	              "        ROUND(NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '40'),0)/(SELECT count(*) FROM ply_tmp),4)*100,           "
	              "        NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '40'),0),                                              "
	              "        ROUND(NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '40'),0)/(SELECT count(*) FROM ply_tmp),4)*100,  "
	              "        NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '40'),0),                                                "
	              "        ROUND(NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '40'),0)/(SELECT count(*) FROM ply_tmp),4)*100,    "
	              "        NVL((SELECT sum(cnt_validcard) FROM ply_validcard WHERE f_NL = a.f_NL AND bzfrom = '41'),0),                                                "
	              "        NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '41'),0),                                                       "
	              "        ROUND(NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL AND bzfrom = '41'),0)/(SELECT count(*) FROM ply_tmp),4)*100,           "
	              "        NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '41'),0),                                              "
	              "        ROUND(NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL AND bzfrom = '41'),0)/(SELECT count(*) FROM ply_tmp),4)*100,  "
	              "        NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '41'),0),                                                "
	              "        ROUND(NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL AND bzfrom = '41'),0)/(SELECT count(*) FROM ply_tmp),4)*100,    "
	              "        NVL((SELECT sum(cnt_validcard) FROM ply_validcard WHERE f_NL = a.f_NL),0),                                                "
	              "        NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL),0),                                                                         "
	              "        ROUND(NVL((SELECT sum(cnt_fecard) FROM ply_ecard WHERE f_NL = a.f_NL),0)/(SELECT count(*) FROM ply_tmp),4)*100,                             "
	              "        NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL),0),                                                                "
	              "        ROUND(NVL((SELECT sum(cnt_phone_mail) FROM ply_phone_mail WHERE f_NL = a.f_NL),0)/(SELECT count(*) FROM ply_tmp),4)*100,                    "
	              "        NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL),0),                                                                  "
	              "        ROUND(NVL((SELECT sum(cnt_sendecard) FROM ply_sendecard WHERE f_NL = a.f_NL),0)/(SELECT count(*) FROM ply_tmp),4)*100                       "
	              "   FROM ply_show a                                                                                                                                  "
	              "  WHERE iserial = 2 AND f_NL = 'L' ");
	sprintf("stmt2[%s]",stmt2);
	rc = unload_file(outputf," ",sfilename,stitle,stmt2);
	
	if (rc != SUCCESS) 
	{
	    sprintf(msgbuf," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}

	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}
