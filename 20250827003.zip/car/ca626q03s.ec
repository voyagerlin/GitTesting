/*******************************************/
/*   �M�׽дک���                          */
/*   PROGRAM : ca626q03s.ec                */
/*   DATE    : 2003/09/16                  */
/*   MODIFY  : 2004/03/11;2007/04/30       */
/*******************************************/
#include <stdio.h>
#include <unistd.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "carmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <math.h>
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"

#define head_line         1
#define desc_line         2
#define data_line         2

extern  char RPTDIR[];

$char   dbgn1[11], dend1[11],iprmt[11];
$char   dbgn_inf[11], dend_inf[11];
char    MsgCode[50],fply_close[2],qnext_year[2];
$char   Igroup[7],Ngroup[21];
int     date_i;

$char   iquota[7],icard[21],ipolicy[21],iendorse[21],iassured[18];
$char   nassured[25],dpolicy[11],dply_begin[11],ibrand[9],ori_dpolicy[11];
$char   iengine[21],iissue_ym[7],ibig_office[10],ibig_office_c[11];
$char   itag[CA_TAG_NUM],nbrand_abbr[13],dendorse[11],ioff1[2];
$char   ibig_sales[11],nsales[11],iins_type[7],ioff_sales[4];
$char   ncomp[11],nbig[21],dedr_close[11],fedr_class[2],d_today[11];
$long   mprem,mprem_ori;
$long   mins_prem_14,mins_prem_17;
$double pdisc;
$char   iassured1[13],iassured2[3],ipro_year[5],nbrand[31];
$char   nprmt[31],iofficer_1[2],ioff_chk[11],iagent[11];
$char   dprmt_bgn[11],dprmt_end[11],iprmt[11],iins_type_prmt[11];
$int    lofficer,iremark,ioff_chk_bgn,ioff_chk_len;
$int    qfield_all,qfield_chk,qyear;
$char   fanother[2],iofficera_1[2],ioff_chka[11];
$int    lofficera,iremarka,ioff_chk_bgna,ioff_chk_lena;
$char   iofficer[10], iofficer_c[11];
$char   bufA[80];

$static char ipro_year_old[5];

$double mcar_price ,qpassenger;
$char   frate[4], icar_type_1[3], fcar_class[2];
$char   fuse_type[2] ,icar_series[3];
$char   dply_begin_1[11];
$char   car_type[3];
$char   icar_type[3];
$char   frate_ym[4];

$long   ply2_begin;
$long   cover_01_tmp, cover_01_11;
$long   cover_01, thousand_cover_01,damage_cover_01;
$int    car_age, car_age_mth;
$int    mdeduct;
$double year_dep, pdepreciate, brg_factor, car_price , s5_factor;
$char   fcar_class2[2], fcal_way[2] , ibrg_rate[3];

/* ca_rate */
$double prate_1, rate_prem, pextra_charge;
$char   ical_ins[INSURANCE_TYPE], fcal_class[2];

/* premium */
int     adj_age , int_ply_yr , tmp_cover_dep , thousand_cover_dep;
int     cover_dep , cover_dep_11;
double  adj_yr_dep;

$long mexpense,medr_dmg,medr_exp,mprem_dmg1,mprem_dmg,mprem1;
$long medr_09,mexp_09,mprem_09,mins_damage, mins_prem_01, mins_prem_ori;

/* car9805211 �s�W�n�O�H�H�Φw��/�޲z���I�[��T�� */
$char   napplicant[25],iapplicant[13];
$double rSafe_09,rSafe_14,rSafe_17,rSafe_11;
$double rMgmt_09,rMgmt_14,rMgmt_17,rMgmt_11;
$double tmp_safe = 0, tmp_manage = 0;
$char   iestimate[21],iabn_type[2]; /* 102.03 �]�����O�X�� */

struct struct_prem
{
    long  mins_premium;
    long  mprem;
};

struct  struct_prem  yprem[10];

DBinfo  *list;
int     count_db;
$char   DBName[05], iForm_Tp[03];
char    BodyFile[ N_FILE+1];
char    TitleFile[ N_FILE+1];
char    outputf[N_FILE+1], userid[11];

char    msgbuf[100];
$int    ItemRow, TotColumn;
$int    StartRow,TitleRow;
$int    PgLine, Width;
$char   check1[2],check2[2];

int     max_cnt;

long car6263_build1();
long car6263_build2();
long car6263_body1();
long car6263_body2();
long car6263_accumulate();
void car6263_title();
void print_car6263_body1();
void print_car6263_body2();
long car6263_iins11_prem();
static float MyPower();
double dbl_len8();

/*--------------------------------------------------------------------*/
car6263(DBName_h,userid_h,iprmt_h,dbgn1_h,dend1_h,check1_h,check2_h,
        date_h,fclose_h,qnext_year_h,outputf_h)
char *DBName_h,*userid_h,*iprmt_h,*dbgn1_h,*dend1_h;
char *check1_h,*check2_h,*fclose_h,*date_h;
char *qnext_year_h,*outputf_h;
{
    int rc;
    batchinit();

printf("begin car6263\n");
    
    strcpy(DBName,  DBName_h);
    strcpy(userid,  userid_h);
    strcpy(iprmt,   iprmt_h);
    strcpy(dbgn1,   dbgn1_h);
    strcpy(dend1,   dend1_h);
    strcpy(check1,  check1_h);
    strcpy(check2,  check2_h);
    strcpy(fply_close,  fclose_h);
    date_i=atoi(date_h);
    strcpy(qnext_year, qnext_year_h);
    strcpy(outputf, outputf_h);

    strcpy(dbgn_inf, cm_to_infdate(dbgn1));
    strcpy(dend_inf, cm_to_infdate(dend1));

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False) {
        return M_CM_DB_NOTOPEN;
    }

    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
        if (EWRITE(userid, M_CM_NOT_DBLIST) == True)
        	return M_CM_NOT_DBLIST;
      	return M_CM_OK;
   	}

   	rc = car6263_read_prmt();
   	if (rc != M_CM_OK) {
      	EWRITE(userid, rc,msgbuf);
      	return rc;
   	}

   	max_cnt=0;
   	if(strncmp(check1,"1",1)==0) {
      	rc = car6263_build1();
      	if ( rc != M_CM_OK)  {
          	EWRITE(userid, rc, " ");
          	return rc;
      	}
   	}

   	max_cnt=0;
   	if(strncmp(check2,"1",1)==0) {
      	rc = car6263_build2();
      	if ( rc != M_CM_OK)  {
          	EWRITE(userid, rc, " ");
          	return rc;
      	}
   	}
   	return M_CM_OK;

errexit:
  	sqlfatal();
  	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
  	return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car6263_read_prmt()
{
	$char  stmt[4096];
   	
   	$select nprmt,iofficer_1,lofficer,iremark,ioff_chk_bgn,
            ioff_chk_len,ioff_chk,iagent,qfield_all,qfield_chk,
            dprmt_bgn,dprmt_end,qyear,iins_type,fanother,
            iofficera_1,lofficera,iremarka,ioff_chk_bgna,
            ioff_chk_lena,ioff_chka
       into $nprmt,$iofficer_1,$lofficer,$iremark,$ioff_chk_bgn,
            $ioff_chk_len,$ioff_chk,$iagent,$qfield_all,$qfield_chk,
            $dprmt_bgn,$dprmt_end,$qyear,$iins_type_prmt,$fanother,
            $iofficera_1,$lofficera,$iremarka,$ioff_chk_bgna,
            $ioff_chk_lena,$ioff_chka
       from ca_promote
      where iprmt = $iprmt;

   	if (SQLCODE==SQLNOTFOUND) {
      	strcpy(msgbuf,"�d�L�M�׸��");
      	return SQLCODE;
   	}

   	sprintf(stmt,"SELECT nbrand_abbr,nbrand,ipro_year\
                  FROM ca_car_model \
                  WHERE ibrand = ?\
                  ORDER BY ipro_year ");
   	$PREPARE B_id FROM $stmt;
   	$DECLARE curBX CURSOR FOR B_id;

   	sprintf(stmt,"SELECT nname FROM officer WHERE iofficer = ? ");
   	$PREPARE pre_name FROM $stmt;

   	sprintf(stmt,"SELECT nname[1,10] FROM ca_big_office \
                  WHERE fclass = '2' AND ibig_comp = ? ");
   	$PREPARE pre_nsales FROM $stmt;

   	sprintf(stmt,"SELECT nbranch FROM sa_branch_type \
                  WHERE ibranch = ? ");
   	$PREPARE pre_nbranch FROM $stmt;

   	return M_CM_OK;

errexit:
   	sqlfatal();
   	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   	return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car6263_build1()
{
   	$char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
   	int    rc;
   	$WHENEVER SQLERROR GOTO errexit;

   	$SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
            kTot_Col, kPgNum_Line, kWidth, iForm_Tp
       INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
            $TotColumn, $PgLine, $Width, $iForm_Tp
       FROM Form
      WHERE ksys_grp = 'CA' AND kPgmID = 626 AND Iform_tp ='4';

   	strcpy( TitleFmt,rtrim(TitleFmt));
   	strcpy( BodyFmt,rtrim(BodyFmt));

   	if (strncmp(check2,"1",1)==0)
    {
    	sprintf( TitleFile,"%sA.ti",outputf);
      	sprintf( BodyFile,"%sA.bd",outputf);
    }
   	else
    {
    	sprintf( TitleFile,"%s.ti",outputf);
      	sprintf( BodyFile,"%s.bd",outputf);
    }

   	rgu_init_report(TitleFmt,TitleFile);
   	car6263_title();
   	rgu_finish_report();

   	rgu_init_report(BodyFmt,BodyFile);
   	rc = car6263_body1();
   	if (rc != M_CM_OK)
       	return rc;
   	rgu_finish_report();

   	if ((rc=save_form_info(F_BLK1, "CA", 626, userid, iForm_Tp, max_cnt,outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   	}

   	return M_CM_OK;
errexit:
   	sqlfatal();
   	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   	return SQLCODE;  
}

/*--------------------------------------------------------------------*/
long car6263_build2()
{
   	$char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
   	int    rc;
   	
   	$WHENEVER SQLERROR GOTO errexit;

    $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
            kTot_Col, kPgNum_Line, kWidth, iForm_Tp
       INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
            $TotColumn, $PgLine, $Width, $iForm_Tp
       FROM Form
      WHERE ksys_grp = "CA" AND kPgmID = 626 AND Iform_tp ='4';

   	strcpy( TitleFmt,rtrim(TitleFmt));
   	strcpy( BodyFmt,rtrim(BodyFmt));

   	if (strncmp(check1,"1",1)==0)
    {
    	sprintf( TitleFile,"%sB.ti",outputf);
      	sprintf( BodyFile,"%sB.bd",outputf);
    }
   	else
    {
    	sprintf( TitleFile,"%s.ti",outputf);
      	sprintf( BodyFile,"%s.bd",outputf);
    }

   	rgu_init_report(TitleFmt,TitleFile);
   	car6263_title();
   	rgu_finish_report();

   	rgu_init_report(BodyFmt,BodyFile);
   	rc = car6263_body2();
   	if (rc != M_CM_OK)
       	return rc;
   	rgu_finish_report();

   	if ((rc=save_form_info(F_BLK1, "CA", 626, userid, iForm_Tp, max_cnt, outputf))<0) {
        strcpy(MsgCode,"save_form_info failed");
        return rc;
   	}

   	return M_CM_OK;
errexit:
   	sqlfatal();
   	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   	return SQLCODE;
}

/*--------------------------------------------------------------------*/
long car6263_body1()
{
  	int   j, rc, i;
  	$char stmt[4096],stmt1[4096],stmt2[512],stmt3[512],stmt4[81],stmt_qnextyear[128];
  	$char stmt_safe[1024];
  	$char tmp_ipro_year[5], iins_ori[INSURANCE_TYPE], iins_type_safe[INSURANCE_TYPE];
  	char  tit[41],h_tit[14];
  	char  sequip_str[21];
  	char  iequip_tmp[3];
  	int   iequip_flag,iins;

  	$WHENEVER SQLERROR GOTO errexit;

  	sprintf(tit,"%s�M�׽дک��Ӫ�(�̷s�O��)",rtrim(nprmt));
  	rgu_put_body_string(1,tit          ,1);
  	rgu_put_body_string(1,cm_get_sysd(),1);
  	rgu_put_body_string(1,dbgn1,1);
  	rgu_put_body_string(1,dend1,1);
  	
  	if (qyear<2) 
  	{
     	rgu_put_body_string(1,"�ѵs�I�O�O",2);
     	/* ���v �վ������� T05202409240013
     	rgu_put_body_string(1,"�����v(�H)",2);
     	rgu_put_body_string(1,"��e�O�O",2);
     	*/
  	} 
  	else 
  	{
     	for(i=1;i<=qyear;i++) 
     	{
        	sprintf(h_tit,"(%d)�ѵs�I�O�O",i);
        	rgu_put_body_string(1,h_tit,1);
        	/* ���v �վ������� T05202409240013
        	sprintf(h_tit,"(%d)�����v(�H)",i);
        	rgu_put_body_string(1,h_tit,1);
        	sprintf(h_tit,"(%d)��e�O�O",i);
        	rgu_put_body_string(1,h_tit,1);
        	*/
     	}
  	}
  	rgu_put_body(1);
  	max_cnt =4;

  	if (strncmp(fply_close,"1",1)==0) 
     	strcpy(stmt2," AND a.dply_close is not null ");
  	else
     	strcpy(stmt2," ");
  	
  	/* 102.03 �s�W"��J���" */
  	if (date_i==0)
{
     	sprintf(stmt4," a.dpolicy  >= '%s' and a.dpolicy  <= '%s' ",dbgn_inf,dend_inf);
  	}else if (date_i==1) {
     	sprintf(stmt4," a.dply_end >= '%s' and a.dply_end <= '%s' ",dbgn_inf,dend_inf);
    }else if (date_i==2) {
    	sprintf(stmt4, " a.dentry  >= '%s' and a.dentry   <= '%s' ",dbgn_inf,dend_inf);
    }


    /* 102.03 �s�O��d��s�W�^��"���`��"�A�H�K�^�����_�O����  */
	/* �P�_�����O��/�s�O��/��O�� Modified by Julia Han in 2007/04/30 */
    /* "A"�������O��,"0"���s�O��,"1"����O�� */
    if (strncmp(qnext_year,"0",1)==0) {
     	strcpy(stmt_qnextyear,"AND (a.qnext_year = 0 Or nvl(b.iabn_type,' ')<>' ' )");
    } else if (strncmp(qnext_year,"1",1)==0) {
   		strcpy(stmt_qnextyear,"AND a.qnext_year > 0");
    } else {
   		strcpy(stmt_qnextyear,"");
    }
   
  	for(j=0;j<count_db;j++) 
  	{
      	sprintf(stmt,
             "SELECT a.ipolicy,a.icard,a.dply_begin,a.ibrand,nvl(a.itmp_policy, ' '),nvl(b.iabn_type,' '), \
                     to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'),\
                     a.ibig_office,a.iquota[1,4]||'00',a.dpolicy, a.ipro_year,\
                     mins_premium,pdiscount,mins_premium+mdiscount,\
                     b.iassured,b.iassured_ext,b.nassured[1,24],\
                     b.iengine,b.itag,nvl(a.dendorse,' '),ibig_sales,\
                     a.fedr_class,today, \
                     c.drate_ym, c.mdeduct, b.mcar_price, a.iofficer, b.iapplicant, b.napplicant[1,24],\
                     NVL((SELECT mins_premium FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type = '14'),0), \
                     NVL((SELECT mins_premium FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type = '17'),0), \
                     NVL((SELECT sum(mins_premium) FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type in ('01','05','08','09','201','205','209')),0) \
              FROM %s:ply_relation a, %s:policy b, outer %s:ply_ins_type c \
              WHERE %s AND a.ipolicy = b.ipolicy %s \
              AND a.ipolicy = c.ipolicy \
              AND c.iins_type IN ('11','211') \
              AND a.iofficer[1] = '%s' \
              AND a.iofficer[%d,%d] = '%s' \
              AND length(a.iofficer) = %d %s",
             list[j].dbname, list[j].dbname, list[j].dbname,
             list[j].dbname, list[j].dbname, list[j].dbname, stmt4, stmt2,
             iofficer_1, ioff_chk_bgn, ioff_chk_bgn+ioff_chk_len-1,
             ioff_chk, lofficer, stmt_qnextyear);
printf("body1.stmt[%s]\n",stmt);
      	$PREPARE a_id1 FROM $stmt;
      	$DECLARE cur_A CURSOR FOR a_id1;
      	$OPEN cur_A;
      	for(;;) 
     	   {
         	mprem=pdisc=mprem_ori=0;
         	mins_prem_14=mins_prem_17=0;
         	
         	$FETCH cur_A
           	  INTO $ipolicy,   $icard,       $dply_begin, $ibrand,
 $iestimate, $iabn_type,
                   $iissue_ym, $ibig_office, $iquota,     $dpolicy,
                   $ipro_year, $mprem,       $pdisc,      $mprem_ori,
                   $iassured1, $iassured2,   $nassured,
                   $iengine,   $itag,        $dendorse,   $ibig_sales,
                   $fedr_class,$d_today,
                   $frate_ym,  $mdeduct,     $car_price,  $iofficer, $iapplicant, $napplicant,
                   $mins_prem_14, $mins_prem_17, $mins_prem_01;

         	if (SQLCODE == SQLNOTFOUND) break;

         	if (strcmp(dendorse,d_today)!=0 && strncmp(fedr_class,"1",1)==0)
            	continue;
         
         	strcpy( frate ,  frate_ym);
printf("step 1\n");         	

         	$EXECUTE pre_name INTO $iofficer_c USING $iofficer;
         	if(SQLCODE == SQLNOTFOUND)
            	strcpy(iofficer_c, " ");
         
         	$EXECUTE pre_name INTO $ibig_office_c USING $ibig_office;
         	if(SQLCODE == SQLNOTFOUND)
           		strcpy(ibig_office_c,ibig_office);

         	$EXECUTE pre_nsales INTO $nsales USING $ibig_sales;
         	if (SQLCODE==SQLNOTFOUND)
            	strcpy(nsales," ");

         	if (strlen(trim(iassured1)) == 0 && strlen(trim(iassured2))==0)
            	iassured[0] ='\0';
         	else 
         	{
            	strcpy(iassured,rtrim(iassured1));
            	strcat(iassured,rtrim(iassured2));  
         	}

         	$OPEN curBX USING $ibrand;
         	$FETCH curBX INTO $nbrand_abbr,$nbrand,$tmp_ipro_year;
         	if(SQLCODE == SQLNOTFOUND) 
         	{
            	nbrand_abbr[0]='\0';
            	nbrand[0]='\0';
         	}
         	$CLOSE curBX;

         	$EXECUTE pre_nbranch INTO $Ngroup USING $iquota;
         	if(SQLCODE ==SQLNOTFOUND) Ngroup[0]='\0';

         	/* �p��n�~�ѵs�I�O�O */
         	rc = car6263_iins11_prem();
         	if ( rc != M_CM_OK )
         	{
             	return rc;
         	}      	
         	
         	/*-- �p������O�O --*/
         	mprem_dmg = mins_prem_01;
         	sprintf(stmt1,"SELECT iins_type , mins_premium FROM %s:ori_ins_type \
         	                WHERE ipolicy = ? AND iins_type in ('01','05','08','09','201','205','209')"
         	              ,list[j].dbname );
         	
         	$PREPARE get_iins_item FROM $stmt1;
         	$EXECUTE get_iins_item INTO $iins_ori, $mins_prem_ori 
         	   USING $ipolicy;
       	
                if (strncmp(fedr_class,"1",1)==0) {
                sprintf(stmt1,"select iins_type,medr_expense \
                                 from %s:edr_relation a,%s:edr_ins_type b \
                                where a.ipolicy = ? \
                                  and a.fedr_class = '1' \
                                  and a.dendorse is not null \
                                  and a.iendorse = b.iendorse \
                                  and iins_type in ('01','05','08','09','201','205','209') \
                                  and medrdmg_cover != 0 ",
                        list[j].dbname,list[j].dbname);
                }
                else {
                   sprintf(stmt1,"select iins_type,mexpense from %s:ply_ins_type \
                                   where ipolicy = ? and mdamage_cover != 0 \
                                     and iins_type in ('01','05','08','09','201','205','209') ", 
                           list[j].dbname);
                }
                $prepare a_id11 from $stmt1;
                $declare cur_A1 cursor for a_id11;
                $open cur_A1 using $ipolicy;
                $fetch cur_A1 into $iins_type,$mexpense;
                if (SQLCODE == SQLNOTFOUND) strcpy(iins_type,"00");
                $close cur_A1;             
                
                medr_dmg=medr_09=medr_exp=0;                               
    
                strcpy(iendorse," ");
                if (strncmp(dendorse," ",1)!=0) {
                   sprintf(stmt1,
                          "SELECT a.iendorse, b.medrins_prem, nvl(dedr_close,' ')\
                            FROM %s:edr_relation a,%s:edr_ins_type b\
                           WHERE ipolicy = ? \
                             AND dendorse is not null \
                             AND b.iins_type in ('01','05','08','09','201','205','209') \
                             AND a.iendorse = b.iendorse",
                          list[j].dbname,list[j].dbname);
                  
                   $PREPARE a_id2 FROM $stmt1;
                   $DECLARE cur_B CURSOR FOR a_id2;
                   $OPEN cur_B USING $ipolicy;
                   for(;;) {
                      mprem_dmg1=0;
                      $FETCH cur_B
                        INTO $iendorse, $mprem_dmg1, $dedr_close;
                      if (SQLCODE == SQLNOTFOUND) break;
                      
                      if (strncmp(dedr_close," ",1)==0) {
                         mprem_dmg -= mprem_dmg1;
                      }
                      else {
                         medr_dmg   += mprem_dmg1;
                      }
                      
                      mprem1=medr_exp=0;
                      sprintf(stmt3,
                         "select medrins_prem,medr_expense from %s:edr_ins_type \
                           where iendorse = ? and iins_type = '%s' \
                             and iedr_type != '02' ",list[j].dbname, iins_ori);
                      $prepare pre_BB from $stmt3; 
                      $execute pre_BB into $mprem1,$medr_exp 
                                     using $iendorse;
                      medr_09 += mprem1;
                      mexp_09 += medr_exp;
                   }
                   $CLOSE cur_B;
                }                
                
                strcpy(iins_type, trim(iins_type));
                strcpy(iins_ori, trim(iins_ori));
                
                /* if (strcmp(trim(iins_type),trim(iins_ori))==0) */
                if (strcmp(iins_type,iins_ori)==0) 
                   mprem_09 = mins_prem_ori;
                else
                   mprem_09 = mprem_dmg - medr_dmg + medr_09 - medr_exp;
                
                mins_damage = mins_prem_01 - mprem_09;
         	
         	
         	    /* ����w��/�޲z���I�[��T��  ���v �վ������� T05202409240013
                   sprintf(stmt_safe,"select iins_type,safe_rate,manage_rate from %s:ply_ins_type \
                                  where ipolicy = ? order by iins_type desc",list[j].dbname);
                   $prepare pre_1d from $stmt_safe;
                   $declare cur_1d cursor for pre_1d;
                   $open    cur_1d using $ipolicy;
                   while(1) {
                        $fetch cur_1d into $iins_type_safe,$tmp_safe,$tmp_manage;
                        
                        if (SQLCODE == SQLNOTFOUND) break;
            
                        strcpy(iins_type_safe, trim(iins_type_safe));
                        iins=atoi(iins_type_safe);
                        switch(iins) {
                             case 9:
                                  rSafe_09 = tmp_safe;
                                  rMgmt_09 = tmp_manage;                                  
                                  break;
                             case 11:
                                  rSafe_11 = tmp_safe;
                                  rMgmt_11 = tmp_manage;
                                  break;
                             case 14:
                                  rSafe_14 = tmp_safe;
                                  rMgmt_14 = tmp_manage;
                                  break;                             
                             case 17:
                                 rSafe_17 = tmp_safe;
                                 rMgmt_17 = tmp_manage;
                                 break;                                            
                         }
                    }
                    $close cur_1d;
                    $free cur_1d;
                  end of ����w��/�޲z���I�[��T�� */
                 
                 print_car6263_body1();
      	}
      	$CLOSE cur_A;

      	if (fanother[0]=='Y') 
      	{
         	sprintf(stmt,
             	"SELECT a.ipolicy,a.icard,a.dply_begin,a.ibrand,nvl(a.itmp_policy, ' '),nvl(b.iabn_type,' '), \
              	        to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'),\
              	        a.ibig_office,a.iquota[1,4]||'00',a.dpolicy,\
              	        a.ipro_year,mins_premium,pdiscount,mins_premium+mdiscount,\
              	        b.iassured,b.iassured_ext,b.nassured[1,24],\
              	        b.iengine,b.itag,nvl(a.dendorse,' '),ibig_sales,\
              	        a.fedr_class,today, \
                    	c.drate_ym, c.mdeduct, b.mcar_price, a.iofficer, b.iapplicant, b.napplicant[1,24],\
                        NVL((SELECT mins_premium FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type = '14'),0), \
                        NVL((SELECT mins_premium FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy and iins_type = '17'),0) \
              	   FROM %s:ply_relation a, %s:policy b, %s:ply_ins_type c \
              	   WHERE %s AND a.ipolicy = b.ipolicy %s \
              	   AND a.ipolicy = c.ipolicy \
              	   AND c.iins_type IN ('11','211') \
              	   AND a.iofficer[1] = '%s' \
              	   AND a.iofficer[%d,%d] = '%s' \
              	   AND length(a.iofficer) = %d %s",
             	list[j].dbname, list[j].dbname,
             	list[j].dbname, list[j].dbname, list[j].dbname, stmt4, stmt2,
             	iofficera_1, ioff_chk_bgna, ioff_chk_bgna+ioff_chk_lena-1,
             	ioff_chka, lofficera,stmt_qnextyear);

      		$PREPARE a_ida FROM $stmt;
      		$DECLARE cur_Aa CURSOR FOR a_ida;
      		$OPEN cur_Aa;
      		for(;;) 
      		{
         		mprem=pdisc=mprem_ori=0;
         		mins_prem_14=mins_prem_17=0;
         		
         		$FETCH cur_Aa
           		  INTO $ipolicy,   $icard,       $dply_begin, $ibrand, $iestimate,
 $iabn_type ,
                       $iissue_ym, $ibig_office, $iquota,     $dpolicy,
                       $ipro_year, $mprem,       $pdisc,      $mprem_ori,
                       $iassured1, $iassured2,   $nassured,
                       $iengine,   $itag,        $dendorse,   $ibig_sales,
                       $fedr_class,$d_today,
                       $frate_ym,  $mdeduct,     $car_price,  $iofficer, $iapplicant, $napplicant,
                       $mins_prem_14, $mins_prem_17;

         		if (SQLCODE == SQLNOTFOUND) break;

         		if (strcmp(dendorse,d_today)!=0 && strncmp(fedr_class,"1",1)==0)
            		continue;
         
         		strcpy( frate ,  frate_ym);
         		
         		$EXECUTE pre_name INTO $iofficer_c    USING $iofficer;
         		if(SQLCODE == SQLNOTFOUND)
            		strcpy(iofficer_c, " ");
         
         		$EXECUTE pre_name INTO $ibig_office_c USING $ibig_office;
         		if(SQLCODE == SQLNOTFOUND)
           			strcpy(ibig_office_c,ibig_office);

         		$EXECUTE pre_nsales INTO $nsales USING $ibig_sales;
         		if (SQLCODE==SQLNOTFOUND)
            		strcpy(nsales," ");

         		if (strlen(trim(iassured1)) == 0 && strlen(trim(iassured2))==0)
            		iassured[0] ='\0';
         		else 
         		{
            		strcpy(iassured,rtrim(iassured1));
            		strcat(iassured,rtrim(iassured2));  
         		}

         		$OPEN curBX USING $ibrand;
         		$FETCH curBX INTO $nbrand_abbr,$nbrand,$tmp_ipro_year;
         		if(SQLCODE == SQLNOTFOUND) {
            		nbrand_abbr[0]='\0';
            		nbrand[0]='\0';
         		}
         		$CLOSE curBX;

         		$EXECUTE pre_nbranch INTO $Ngroup USING $iquota;
         		if(SQLCODE ==SQLNOTFOUND) Ngroup[0]='\0';

         		/* �p��n�~�ѵs�I�O�O */
         		rc = car6263_iins11_prem();
         		if ( rc != M_CM_OK )
         		{
             		return rc;
         		}
         		
         		/* ����w��/�޲z���I�[��T��  ���v �վ������� T05202409240013
                   sprintf(stmt_safe,"select iins_type,safe_rate,manage_rate from %s:ply_ins_type \
                                  where ipolicy = ? order by iins_type desc",list[j].dbname);
                   $prepare pre_2d from $stmt_safe;
                   $declare cur_2d cursor for pre_2d;
                   $open    cur_2d using $ipolicy;
                   while(1) {
                        $fetch cur_2d into $iins_type_safe,$tmp_safe,$tmp_manage;
                        
                        if (SQLCODE == SQLNOTFOUND) break;
                        
                        strcpy(iins_type_safe, trim(iins_type_safe));
                        iins=atoi(iins_type_safe);
                        switch(iins) {
                             case 9:
                                  rSafe_09 = tmp_safe;
                                  rMgmt_09 = tmp_manage;                                  
                                  break;
                             case 11:
                                  rSafe_11 = tmp_safe;
                                  rMgmt_11 = tmp_manage;
                                  break;
                             case 14:
                                  rSafe_14 = tmp_safe;
                                  rMgmt_14 = tmp_manage;
                                  break;                             
                             case 17:
                                 rSafe_17 = tmp_safe;
                                 rMgmt_17 = tmp_manage;
                                 break;                                            
                         }
                    }
                    $close cur_2d;
                    $free cur_2d;
                  end of ����w��/�޲z���I�[��T�� */

         		print_car6263_body1();
      		}
      		$CLOSE cur_Aa;
      	}	
  	} 
  	$FREE  cur_A;
  	$FREE  cur_Aa;

  	return M_CM_OK;
   
errexit:
   	sqlfatal();
   	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   	return SQLCODE; 
}

/*--------------------------------------------------------------------*/
long car6263_body2()
{
 	int   j;
 	$char stmt1[4096],stmt[4096],stmt2[512];
 	char  tit[41];
 	char  sequip_str[21];
 	char  iequip_tmp[3];
 	int   iequip_flag;

 	$WHENEVER SQLERROR GOTO errexit;

 	sprintf(tit,"%s�M�׽дک��Ӫ�(���P���)",rtrim(nprmt));
 	rgu_put_body_string(1,tit          ,1);
 	rgu_put_body_string(1,cm_get_sysd(),1);
 	rgu_put_body_string(1,dbgn1,1);
 	rgu_put_body_string(1,dend1,1);
 	rgu_put_body_string(1,"�ѵs�I�O�O",2);
 	/* ���v �վ������� T05202409240013
 	rgu_put_body_string(1,"�����v(�H)",2);
 	rgu_put_body_string(1,"��e�O�O",2);
 	*/
 	rgu_put_body(1);
 	max_cnt = 4;

 	if (strncmp(fply_close,"1",1)==0) 
     	strcpy(stmt2," AND a.dedr_close is not null ");
 	else
     	strcpy(stmt2," ");

 	for(j=0;j<count_db;j++) 
 	{
      	sprintf(stmt,
             "SELECT a.ipolicy,a.icard,b.dply_begin,a.ibrand,\
                     to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'),\
                     a.ibig_office,a.iquota[1,4]||'00',a.dendorse, a.ipro_year,\
                     e.medrins_prem,d.pdiscount,e.medrins_prem+e.medr_discount,\
                     b.iassured,b.iassured_ext,b.nassured[1,24],\
                     b.iengine,b.itag,a.dendorse,a.ibig_sales,c.dpolicy,a.iendorse,a.iofficer, \
                     NVL((SELECT medrins_prem FROM %s:edr_ins_type WHERE iendorse = a.iendorse and iins_type = '14'),0), \
                     NVL((SELECT medrins_prem FROM %s:edr_ins_type WHERE iendorse = a.iendorse and iins_type = '17'),0), \
                     b.iapplicant,b.napplicant[1,24] \
                FROM %s:edr_relation a, %s:endorsement b, \
                     %s:ply_relation c, %s:ply_ins_type d, \
                     %s:edr_ins_type e \
               WHERE a.dendorse>= ? AND a.dendorse<= ? %s \
               AND   a.iendorse = b.iendorse \
               AND   a.ipolicy  = c.ipolicy \
               AND   a.ipolicy  = d.ipolicy \
               AND   a.iendorse = e.iendorse \
               AND   d.iins_type= e.iins_type \
               AND   e.iins_type IN ('11','211') \
               AND   a.fedr_class = '1' \
               AND   a.iofficer[1] = '%s' \
               AND   a.iofficer[%d,%d] = '%s' \
               AND   length(a.iofficer) = %d",
             list[j].dbname, list[j].dbname,
             list[j].dbname, list[j].dbname, list[j].dbname, list[j].dbname, list[j].dbname,
             stmt2, iofficer_1, ioff_chk_bgn,
             ioff_chk_bgn+ioff_chk_len-1, ioff_chk, lofficer);

      	$PREPARE a_id3 FROM $stmt;
      	$DECLARE cur_C CURSOR FOR a_id3;
      	$OPEN cur_C USING $dbgn_inf,$dend_inf;
      	for(;;) 
      	{
         	mprem=pdisc=mprem_ori=0;
         	mins_prem_14=mins_prem_17=0;
         	
         	$FETCH cur_C
           	  INTO $ipolicy,$icard,$dply_begin,$ibrand,$iissue_ym,
                   $ibig_office,$iquota,$dpolicy,$ipro_year,
                   $mprem,$pdisc,$mprem_ori,
                   $iassured1,$iassured2,$nassured,$iengine,
                   $itag,$dendorse,$ibig_sales,$ori_dpolicy,
                   $iendorse,$iofficer,
                   $mins_prem_14,$mins_prem_17,$iapplicant,$napplicant;
         	if (SQLCODE == SQLNOTFOUND) break;

         	$EXECUTE pre_name INTO $ibig_office_c USING $ibig_office;
         	if(SQLCODE == SQLNOTFOUND)
            	strcpy(ibig_office_c,ibig_office);

         	$EXECUTE pre_nsales into $nsales USING $ibig_sales;
         	if (SQLCODE==SQLNOTFOUND)
            	strcpy(nsales," ");

         	if (strlen(trim(iassured1)) == 0 && strlen(trim(iassured2))==0)
               	iassured[0] ='\0';
         	else
          	{ 
          		strcpy(iassured,rtrim(iassured1));
            	strcat(iassured,rtrim(iassured2));  
            }

         	$OPEN curBX USING $ibrand;
         	$FETCH curBX INTO $nbrand_abbr,$nbrand,$ipro_year;
         	if(SQLCODE == SQLNOTFOUND)
           	{
           		nbrand_abbr[0]='\0';
            	nbrand[0]='\0'; 
            }
         	$CLOSE curBX;

         	$EXECUTE pre_nbranch INTO $Ngroup USING $iquota;
         	if(SQLCODE ==SQLNOTFOUND) Ngroup[0]='\0';

            /* ���P,�L�ݦC�X�w��/�޲z�[��T�� */
            rSafe_09 = rSafe_11 = rSafe_14 = rSafe_17 = 0;
            rMgmt_09 = rMgmt_11 = rMgmt_14 = rMgmt_17 = 0;
            
         	print_car6263_body2();

      	}
      	$CLOSE cur_C;

      	if (fanother[0]=='Y') 
      	{
      		sprintf(stmt,
             	    "SELECT a.ipolicy,a.icard,b.dply_begin,a.ibrand,\
                            to_char(b.dissue,'%%Y')::integer - 1911 || '/' || to_char(b.dissue,'%%m'),\
                            a.ibig_office,a.iquota[1,4]||'00',a.dendorse, a.ipro_year,\
                            e.medrins_prem,d.pdiscount,e.medrins_prem+e.medr_discount,\
                            b.iassured,b.iassured_ext,b.nassured[1,24],\
                            b.iengine,b.itag,a.dendorse,a.ibig_sales,c.dpolicy,a.iendorse,a.iofficer, \
                            NVL((SELECT medrins_prem FROM %s:edr_ins_type WHERE iendorse = a.iendorse and iins_type = '14'),0), \
                            NVL((SELECT medrins_prem FROM %s:edr_ins_type WHERE iendorse = a.iendorse and iins_type = '17'),0), \
                            b.iapplicant,b.napplicant[1,24] \
                       FROM %s:edr_relation a, %s:endorsement b, \
                            %s:ply_relation c, %s:ply_ins_type d, \
                            %s:edr_ins_type e \
                      WHERE a.dendorse>= ? AND a.dendorse<= ? %s \
                      AND   a.iendorse = b.iendorse \
                      AND   a.ipolicy  = c.ipolicy \
                      AND   a.ipolicy  = d.ipolicy \
                      AND   a.iendorse = e.iendorse \
                      AND   d.iins_type= e.iins_type \
                      AND   e.iins_type IN ('11','211') \
                      AND   a.fedr_class = '1' \
                      AND   a.iofficer[1] = '%s' \
                      AND   a.iofficer[%d,%d] = '%s' \
                      AND   length(a.iofficer) = %d ",
                    list[j].dbname,list[j].dbname,list[j].dbname,
                    list[j].dbname,list[j].dbname,list[j].dbname,
                    list[j].dbname,stmt2,iofficera_1,ioff_chk_bgna,
                    ioff_chk_bgna+ioff_chk_lena-1,ioff_chka,lofficera);

      		$PREPARE a_id3a FROM $stmt;
      		$DECLARE cur_Ca CURSOR FOR a_id3a;
      		$OPEN cur_Ca USING $dbgn_inf,$dend_inf;
      		for(;;) 
      		{
         		mprem=pdisc=mprem_ori=0;
         		mins_prem_14=mins_prem_17=0;
         		
         		$FETCH cur_Ca
           		  INTO $ipolicy,$icard,$dply_begin,$ibrand,$iissue_ym,
                       $ibig_office,$iquota,$dpolicy,$ipro_year,
                       $mprem,$pdisc,$mprem_ori,
                       $iassured1,$iassured2,$nassured,$iengine,
                       $itag,$dendorse,$ibig_sales,$ori_dpolicy,
                       $iendorse,$iofficer,
                       $mins_prem_14,$mins_prem_17,$iapplicant,$napplicant;
         		if (SQLCODE == SQLNOTFOUND) break;

         		$EXECUTE pre_name INTO $ibig_office_c USING $ibig_office;
         		if(SQLCODE == SQLNOTFOUND)
            		strcpy(ibig_office_c,ibig_office);

         		$EXECUTE pre_nsales into $nsales USING $ibig_sales;
         		if (SQLCODE==SQLNOTFOUND)
            		strcpy(nsales," ");

         		if (strlen(trim(iassured1)) == 0 && strlen(trim(iassured2))==0)
               		iassured[0] ='\0';
         		else
          		{ 
          			strcpy(iassured,rtrim(iassured1));
            		strcat(iassured,rtrim(iassured2));  
            	}

         		$OPEN curBX USING $ibrand;
         		$FETCH curBX INTO $nbrand_abbr,$nbrand,$ipro_year;
         		if(SQLCODE == SQLNOTFOUND)
           		{
           			nbrand_abbr[0]='\0';
            		nbrand[0]='\0'; 
            	}
         		$CLOSE curBX;

         		$EXECUTE pre_nbranch INTO $Ngroup USING $iquota;
         		if(SQLCODE ==SQLNOTFOUND) Ngroup[0]='\0';
         		
         		/* ���P,�L�ݦC�X�w��/�޲z�[��T�� */
               rSafe_09 = rSafe_14 = rSafe_17 = 0;
               rMgmt_09 = rMgmt_14 = rMgmt_17 = 0;

         		print_car6263_body2();

      		}
      		$CLOSE cur_Ca;
      	}
    }
    $FREE cur_C;
    $FREE cur_Ca;
    $FREE  curBX;

    return M_CM_OK;

errexit:
   	sqlfatal();
   	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   	return SQLCODE;
}
/*--------------------------------------------------------------------*/
void print_car6263_body1()
{ 
  	char str[12],str1[8],brand14[5], office_c[5];
  	int  i;

  	rgu_put_body_string(2,iquota,LEFT);
  	rgu_put_body_string(2,trim(Ngroup),LEFT);
  	rgu_put_body_string(2,iestimate,LEFT); 
  	rgu_put_body_string(2,icard,LEFT);
  	rgu_put_body_string(2,ipolicy,LEFT);
  	rgu_put_body_string(2," "    ,LEFT);
  	rgu_put_body_string(2,iassured,LEFT);
  	rgu_put_body_string(2,nassured,LEFT);
  	rgu_put_body_string(2,iapplicant,LEFT);
  	rgu_put_body_string(2,napplicant,LEFT);
  	rgu_put_body_string(2,dpolicy,LEFT);
  	rgu_put_body_string(2,dply_begin,LEFT);
  	strncpy(brand14, ibrand, 4);
  	brand14[4] = '\0';
  	rgu_put_body_string(2,brand14,LEFT);
  	rgu_put_body_string(2,ibrand,LEFT);
  	rgu_put_body_string(2,nbrand_abbr,LEFT);
  	rgu_put_body_string(2,nbrand,LEFT);
  	rgu_put_body_string(2,iengine,LEFT);
  	rgu_put_body_string(2,iissue_ym,LEFT);
  	rgu_put_body_string(2,iofficer,LEFT);
  	rgu_put_body_string(2,iofficer_c,LEFT);
  	rgu_put_body_string(2,ibig_office,LEFT);
  	strncpy( office_c, ibig_office_c , 4 );
  	office_c[4] = '\0';
  	rgu_put_body_string(2,office_c     ,LEFT);
  	rgu_put_body_string(2,ibig_office_c,LEFT);
  	rgu_put_body_string(2,ibig_sales,LEFT);
  	rgu_put_body_string(2,nsales,LEFT);
  	rgu_put_body_string(2,itag,LEFT);
  	rgu_put_body_string(2,iabn_type,LEFT);  	
  	rfmtlong(mprem,"---------&",str);
  	rgu_put_body_string(2,str,LEFT);
  	/* ���v �վ������� T05202409240013
  	rfmtdouble(pdisc,"----.-&",str1);
  	rgu_put_body_string(2,str1,LEFT);
  	rfmtlong(mprem_ori,"---------&",str);
  	rgu_put_body_string(2,str,LEFT);
  	*/
  	rfmtlong(mprem_09,"---------&",str);
  	rgu_put_body_string(2,str,LEFT);  	
  	rfmtlong(mins_damage,"---------&",str);
  	rgu_put_body_string(2,str,LEFT);
  	
  	rfmtlong(mins_prem_17,"---------&",str);
  	rgu_put_body_string(2,str,LEFT);  	
  	rfmtlong(mins_prem_14,"---------&",str);
  	rgu_put_body_string(2,str,LEFT);
  	
  	rgu_put_body_string(2," ",LEFT);
  	
  	/* �w��/�޲z���I�[��T��  ���v �վ������� T05202409240013
  	rfmtdouble(rSafe_11,"-&&.&&&&&&&",str);
   rgu_put_body_string(2,str,2); 
  	rfmtdouble(rSafe_09,"-&&.&&&&&&&",str);
   rgu_put_body_string(2,str,2); 
   rfmtdouble(rSafe_17,"-&&.&&&&&&&",str);
   rgu_put_body_string(2,str,2); 
   rfmtdouble(rSafe_14,"-&&.&&&&&&&",str);  
   rgu_put_body_string(2,str,2);
   rfmtdouble(rMgmt_11,"-&&.&&&&&&&",str);
   rgu_put_body_string(2,str,2); 
   rfmtdouble(rMgmt_09,"-&&.&&&&&&&",str);
   rgu_put_body_string(2,str,2); 
   rfmtdouble(rMgmt_17,"-&&.&&&&&&&",str);
   rgu_put_body_string(2,str,2); 
   rfmtdouble(rMgmt_14,"-&&.&&&&&&&",str); 
   rgu_put_body_string(2,str,2);   
  */
  	for( i = 1 ; i < qyear; i++ )
  	{
     	rfmtlong(yprem[i].mins_premium,"---------&",str);
     	rgu_put_body_string(2,str,LEFT);
     	/* ���v �վ������� T05202409240013
     	rfmtdouble(pdisc,"----.-&",str1);
     	rgu_put_body_string(2,str1,LEFT);
     	rfmtlong(yprem[i].mprem,"---------&",str);
     	rgu_put_body_string(2,str,LEFT);
     	*/
  	}
  
  	rgu_put_body(2);
  	max_cnt++;
}

/*--------------------------------------------------------------------*/
void print_car6263_body2()
{ 
	char str[12],str1[8],brand14[5], office_c[5];

  	rgu_put_body_string(2,iquota,LEFT);
  	rgu_put_body_string(2,trim(Ngroup),LEFT);
  	rgu_put_body_string(2,iestimate,LEFT);   	
  	rgu_put_body_string(2,icard,LEFT);
  	rgu_put_body_string(2,ipolicy,LEFT);
  	rgu_put_body_string(2,iendorse,LEFT);
 	rgu_put_body_string(2,iassured,LEFT);
  	rgu_put_body_string(2,nassured,LEFT);
  	rgu_put_body_string(2,iapplicant,LEFT);
  	rgu_put_body_string(2,napplicant,LEFT);
  	rgu_put_body_string(2,dpolicy,LEFT);
  	rgu_put_body_string(2,dply_begin,LEFT);
  	strncpy(brand14, ibrand, 4);
  	brand14[4] = '\0';
  	rgu_put_body_string(2,brand14,LEFT);
  	rgu_put_body_string(2,ibrand,LEFT);
  	rgu_put_body_string(2,nbrand_abbr,LEFT);
  	rgu_put_body_string(2,nbrand,LEFT);
  	rgu_put_body_string(2,iengine,LEFT);
  	rgu_put_body_string(2,iissue_ym,LEFT);
  	rgu_put_body_string(2,iofficer,LEFT);
  	rgu_put_body_string(2,iofficer_c,LEFT);
  	rgu_put_body_string(2,ibig_office,LEFT);
  	strncpy( office_c, ibig_office_c , 4 );
  	office_c[4] = '\0';
  	rgu_put_body_string(2,office_c     ,LEFT);
 	rgu_put_body_string(2,ibig_office_c,LEFT);
  	rgu_put_body_string(2,ibig_sales,LEFT);
  	rgu_put_body_string(2,nsales,LEFT);
  	rgu_put_body_string(2,itag,LEFT);
  	rgu_put_body_string(2,iabn_type,LEFT);   	
  	rfmtlong(mprem,"---------&",str);
  	rgu_put_body_string(2,str,LEFT);
  	/* ���v �վ������� T05202409240013
  	rfmtdouble(pdisc,"----.-&",str1);
  	rgu_put_body_string(2,str1,LEFT);
  	rfmtlong(mprem_ori,"---------&",str);
  	rgu_put_body_string(2,str,LEFT);
	*/
  	rfmtlong(mins_prem_17,"---------&",str);
  	rgu_put_body_string(2,str,LEFT);
  	rfmtlong(mins_prem_14,"---------&",str);
  	rgu_put_body_string(2,str,LEFT);

  	rgu_put_body_string(2,ori_dpolicy,LEFT);
  	
  	/* �w��/�޲z���I�[��T�� ���v �վ������� T05202409240013
  	rfmtdouble(rSafe_11,"-&&.&&&&&&&",str);
   rgu_put_body_string(2,str,2); 
  	rfmtdouble(rSafe_09,"-&&.&&&&&&&",str);
   rgu_put_body_string(2,str,2); 
   rfmtdouble(rSafe_17,"-&&.&&&&&&&",str);
   rgu_put_body_string(2,str,2); 
   rfmtdouble(rSafe_14,"-&&.&&&&&&&",str); 
   rgu_put_body_string(2,str,2); 
   rfmtdouble(rMgmt_11,"-&&.&&&&&&&",str);
   rgu_put_body_string(2,str,2); 
   rfmtdouble(rMgmt_09,"-&&.&&&&&&&",str);
   rgu_put_body_string(2,str,2); 
   rfmtdouble(rMgmt_17,"-&&.&&&&&&&",str);
   rgu_put_body_string(2,str,2); 
   rfmtdouble(rMgmt_14,"-&&.&&&&&&&",str);    
   */
  	rgu_put_body(2);
  	max_cnt++;
}

/*--------------------------------------------------------------------*/
void car6263_title()
{
   	rgu_put_head();
}

/*--------------------------------------------------------------------*/
long car6263_iins11_prem()
{
   	char dyy[4],dmm[3],ddd[3];
   	int  code,i;
   	double ins_premium , pure_ins_premium , short_prate ; 
   	double cal_ins_premium , cal_discount , mins_discount , mins_premium;
   	$int dyy1, model_year, t_ipro_year , cal_pro_year;
   	$char s5_iproyear[6];
   
   	$WHENEVER sqlerror goto errexit;
   
   	/** �M�� struct ���� **/
   	for(i=0;i<qyear;i++)
   	{
      	yprem[i].mins_premium = 0;
      	yprem[i].mprem = 0;
   	}
   
   	if( mdeduct <= 0 )
   	{
      	/* ��h�A���p��O�O�F */
      	/* ���U��n�~���O�O����0 */
      	return M_CM_OK;
   	}
   
   	short_prate = 1.0;
   
   	/* Step 1 SELECT �t�P������ */ 
   
   	$SELECT mcar_price  ,icar_type    ,fuse_type  ,qpassenger  ,icar_series
       INTO $mcar_price ,$icar_type_1 ,$fuse_type ,$qpassenger ,$icar_series
       FROM ca_car_model
      WHERE ibrand    = $ibrand
        AND ipro_year = $ipro_year
        AND drate     = (SELECT drate
                           FROM ca_rate_date
                          WHERE icode  = $frate
                            AND itable = 'ca_car_model'); 
    if (SQLCODE==SQLNOTFOUND)
    {
        $DECLARE CA_OPT1_3A CURSOR FOR
          SELECT mcar_price  ,icar_type    ,fuse_type  ,qpassenger  ,icar_series  ,ipro_year
            INTO $mcar_price ,$icar_type_1 ,$fuse_type ,$qpassenger ,$icar_series
            FROM ca_car_model
           WHERE ibrand    = $ibrand
             AND ipro_year > $ipro_year
             AND drate     = (SELECT drate
                                FROM ca_rate_date
                               WHERE icode  = $frate
                                 AND itable = 'ca_car_model')
           ORDER BY ipro_year;
        $OPEN  CA_OPT1_3A;
        $FETCH CA_OPT1_3A;
        if (SQLCODE==SQLNOTFOUND) 
        {
            $DECLARE CA_OPT3B_305 CURSOR FOR
              SELECT mcar_price  ,icar_type,   fuse_type  ,qpassenger  ,icar_series  ,ipro_year
                INTO $mcar_price ,$icar_type_1,$fuse_type ,$qpassenger ,$icar_series
                FROM ca_car_model
               WHERE ibrand    = $ibrand
                 AND ipro_year < $ipro_year
                 AND drate     = (SELECT drate
                                    FROM ca_rate_date
                                   WHERE icode  = $frate
                                     AND itable = 'ca_car_model')
               ORDER BY ipro_year DESC;
            $OPEN  CA_OPT3B_305;
            $FETCH CA_OPT3B_305;
            if (SQLCODE==SQLNOTFOUND)
            {
                return M_CA_NBRAND;
                $CLOSE CA_OPT3B_305;
                $FREE  CA_OPT3B_305;
            }
            $CLOSE CA_OPT3B_305;
        }
        $CLOSE CA_OPT1_3A;
        $FREE  CA_OPT1_3A;
    }

   	/* Step 2 check �ۥ���~���O */
   	$SELECT fcar_class
       INTO $fcar_class2
       FROM car_type
      WHERE fclass='1'
        AND icode=$icar_type_1; 
    
    /*** STEP 3 check insurance 11 ***/
    /*** STEP 4 ���w�����j���ؤ��@
                ���ѵs�O�v�N������ѵs�I�O�v�N���Y��   ***/ 
    
    $SELECT ibrg_rate  , ipro_year
       INTO $ibrg_rate , $cal_pro_year
       FROM ca_car_model
      WHERE ibrand    = $ibrand
        AND ipro_year = $ipro_year
        AND drate     = (SELECT drate
                           FROM ca_rate_date
                          WHERE icode  = $frate
                            AND itable = 'ca_car_model');
    if(SQLCODE==SQLNOTFOUND)
    {
        $DECLARE CA_OPT11 CURSOR FOR
          SELECT ibrg_rate  , ipro_year
            INTO $ibrg_rate , $cal_pro_year
            FROM ca_car_model
           WHERE ibrand    = $ibrand
             AND ipro_year > $ipro_year
             AND drate     = (SELECT drate
                                FROM ca_rate_date
                               WHERE icode  = $frate
                                 AND itable = 'ca_car_model')
           ORDER BY ipro_year;

        $OPEN  CA_OPT11;
        $FETCH CA_OPT11;
        if (SQLCODE==SQLNOTFOUND)
        {
            $DECLARE CA_OPT11_1 CURSOR FOR
              SELECT ibrg_rate  , ipro_year
                INTO $ibrg_rate , $cal_pro_year
                FROM ca_car_model
               WHERE ibrand    = $ibrand
                 AND ipro_year < $ipro_year
                 AND drate     = (SELECT drate
                                    FROM ca_rate_date
                                   WHERE icode  = $frate
                                     AND itable = 'ca_car_model')
               ORDER BY ipro_year DESC;

               $OPEN  CA_OPT11_1;
               $FETCH CA_OPT11_1;
               if (SQLCODE==SQLNOTFOUND)
               {
                   $CLOSE CA_OPT11_1;
                   $FREE  CA_OPT11_1;
                   return M_CA_NBRAND;
               }
               $CLOSE CA_OPT11_1;
        }
        $CLOSE CA_OPT11;
        $FREE  CA_OPT11;
    }
    
    /*** STEP 5 �إ� car_model_factor EX:�O�v07 ***/
    /*** ��Table:
         2003	2002	2001	2000	<=1999
         1.00	0.76	0.56	0.38	0.22
         �إ�Temp Table 
         2003	2004	2005	2006	2007
         1.00	0.76	0.56	0.38	0.22  ***/
    
    $CREATE TEMP TABLE temp_model_factor
    (
       ipro_year  char(4) default ' ',
       pfactor    decimal(7,4)  default 0.0000
    )
    WITH NO LOG;
    
    $CREATE INDEX model_factor_ix1 ON temp_model_factor( ipro_year );
    
    strcpy(dply_begin_1 , cm_from_infdate_100(dply_begin));
    cm_split_ymd_100(dply_begin_1,dyy,dmm,ddd);
    dyy1=atoi(dyy)+1911;
    
    $DECLARE cur_model CURSOR for
      SELECT ipro_year, pfactor
        FROM car_model_factor
       WHERE fdmg_brg  = '2'
         AND irate     = $ibrg_rate
         AND drate     = (SELECT drate
                            FROM ca_rate_date
                           WHERE icode  = $frate
                            AND itable = 'car_model_factor')
       ORDER BY ipro_year DESC;
     
    $OPEN cur_model;
    for( model_year = dyy1 ; ; model_year++ )
    {
    	$FETCH cur_model INTO $t_ipro_year, $brg_factor;
        if( SQLCODE == SQLNOTFOUND ) break;
             
        $INSERT INTO temp_model_factor( ipro_year, pfactor )
         VALUES ($model_year, $brg_factor );
    }
    $CLOSE cur_model;
    $FREE  cur_model;
    
   /* 6 ~ 10 years */
    if (qyear > 5) {
    for(i=1;i<6;i++)
    {
        model_year = model_year + i;

        $INSERT INTO temp_model_factor( ipro_year, pfactor )
         VALUES ($model_year, $brg_factor );

    }
    }

    /*** STEP 6 get �򥻫O�O,�p��v,�p���I��,������� ***/
    $SELECT prate, mprem, ical_ins, fcal_class, pextra_charge/100
       INTO $prate_1, $rate_prem, $ical_ins, $fcal_class, $pextra_charge
       FROM ca_rate
      WHERE icar_type = $icar_type_1
        AND iins_type = '11'
        AND mdeduct   = $mdeduct
        AND qpt_bgn  <= 0
        AND qpt_end  >= 0
        AND drate     = (SELECT drate
                           FROM ca_rate_date
                          WHERE icode  = $frate
                            AND itable = 'ca_rate');
                            
    if (SQLCODE==SQLNOTFOUND) return M_CA_NRATE;
    
    prate_1=prate_1/100.0;
    
    /*** �}�l�p�Ⱶ�U�Ӫ�n�~�O�O ***/
    
    for( i = 1 ; i < qyear ; i ++ )
    {
       /* �s�@�ӫO�_�� */
       strcpy(dply_begin_1 , cm_from_infdate_100(dply_begin));
       cm_split_ymd_100(dply_begin_1,dyy,dmm,ddd);
       
       dply_begin_1[0] = dmm[0];
       dply_begin_1[1] = dmm[1];
       dply_begin_1[2] = '/';
       dply_begin_1[3] = ddd[0];
       dply_begin_1[4] = ddd[1];
       dply_begin_1[5] = '/';
       
       dyy1=atoi(dyy);
       dyy1=dyy1+1911+i;
       strcpy( dyy , itoa(dyy1) );
       
       dply_begin_1[6] = dyy[0];
       dply_begin_1[7] = dyy[1];
       dply_begin_1[8] = dyy[2];
       dply_begin_1[9] = dyy[3];
       
       rstrdate( dply_begin_1, &ply2_begin );
       
       /** Step 1 SetCarAge **/
       code = SetCarAge();
       
       /** Step 2 Ū���ӫO�_���~�ת� brg_factor **/
       
       $SELECT pfactor
          INTO $brg_factor
          FROM temp_model_factor
         WHERE ipro_year = $dyy1;
       
       /** Step 3 �p��M�I�O�O **/
       {
       	  adj_age = int_ply_yr - atoi(ipro_year);
          if (adj_age > 4) adj_age = 4;
          adj_yr_dep = MyPower(0.75, adj_age);

          tmp_cover_dep = (int)(car_price*10000.0*adj_yr_dep);
          thousand_cover_dep = tmp_cover_dep % 1000;
          
          if (thousand_cover_dep != 0)
          {
              cover_dep    = (tmp_cover_dep)-(thousand_cover_dep)+1000;
              cover_dep_11 = tmp_cover_dep - thousand_cover_dep;
          }
          else
          {
              cover_dep    = tmp_cover_dep;
              cover_dep_11 = tmp_cover_dep;
          }
          
/*          printf("\n");
          printf("11@@@@@ car_price[%f] brg_factor[%f]\n",car_price,brg_factor);
          printf("11@@@@@ cover_01_11[%ld], cover_dep_11[%ld]\n",cover_01_11,cover_dep_11);
          printf("PREM=car_price*prate_1*short_prate*brg_factor\n");
          printf("                      *(cover_01_11/cover_dep_11)\n");*/
          

          /* �«O�O(���p���I) */
          ins_premium     = car_price*10000.0*prate_1*short_prate*brg_factor
                            *((double)cover_01_11/(double)cover_dep_11);
       	  
       }
       
       /** Step 4 �p��W���O�O **/
       {
          /* �«O�O(�|�ˤ��J) */
          pure_ins_premium   = (long)(ins_premium+0.5);
          
          /* �W���O�O(�|�ˤ��J) */
          cal_ins_premium = (long)(dbl_len8(ins_premium)/(1.0-pextra_charge)+0.5);       	  
       }
       
       /** Step 5 �p��������B�Añ��O�O **/
       {
       	  
       	  cal_discount = 32.75;
       	  
       	  mins_discount = (long)( cal_ins_premium*cal_discount/100 + 0.5 );
       	  
       	  mins_premium = cal_ins_premium - mins_discount;
       	  
       }
      
       /** �p��X���O�O�g�J struct ���A�C�L��... **/ 
       yprem[i].mins_premium = mins_premium;
       yprem[i].mprem = cal_ins_premium;
       
    }
    
    
    $DROP TABLE temp_model_factor;
    
    return M_CM_OK;
    
errexit:
    printf("error in car6263_iins11_prem \n");
    printf("ERROR CODE = [%d] \n", SQLCODE );
    return SQLCODE;
}

/*****************************************************************/
static int SetCarAge()
{
    char   iissue_ymd[12];         /* extend CY/MM to CY/MM/DD */
    char   datestring[16], yy[4], mm[3], dd[3], yy2[4], mm2[3];
    int    yy1,mm1,yy3,mm3;
    long   iissue_date;
    $int   count_x=0;
    

    /*** STEP 3 -- a. ; here we calculate car_age, year_dep ...etc.  ***/
    
    /*** STEP 3.2 -- b. ***/
    sprintf(iissue_ymd,"%s/01",iissue_ym);
    iissue_date=cm_ymd_cdate(iissue_ymd);
    car_age=DiffMonth(ply2_begin,iissue_date);
    car_age_mth=car_age % 12;

    

    /** for flag_new **/
    strcpy(datestring,cm_cdate_str_100(ply2_begin));
    cm_split_ymd_100(datestring,yy,mm,dd);
    yy1=atoi(yy);
    int_ply_yr=yy1+1911; /* int_ply_yr for iins_type 11 */
    mm1=atoi(mm);

    strncpy(yy2,iissue_ym,2);
    yy2[2]='\0';
    strncpy(mm2,&iissue_ym[3],2);
    mm2[2]='\0';
    yy3=atoi(yy2);
    mm3=atoi(mm2);
    
    /*
    if (yy3-yy1>0 || (yy3-yy1==0 && mm3-mm1>=0))
         flag_new=TRUE;
    else flag_new=FALSE;  */

    /*** STEP 3.3 �~���� ***/
    
    if (fcar_class2[0]=='1') /* �ۥΨ� */  
        year_dep=MyPower(0.75, car_age/12);
    else
        year_dep=MyPower(0.70, car_age/12);
        
    /*** SETP 3.4 ����� ***/
    
    pdepreciate=0.0;
    
    /*** SETP 3.5 �p��O�I���B�B����«᪺�O�I���B ***/
    cover_01_tmp = car_price*10000.0*year_dep*(1.0-pdepreciate);
    thousand_cover_01 = cover_01_tmp % 1000;
    if (thousand_cover_01 != 0)
    {
        cover_01 = (cover_01_tmp)-(thousand_cover_01);
        cover_01_11 = cover_01_tmp - thousand_cover_01;
    }
    else
    {
        cover_01 = cover_01_tmp;
        cover_01_11 = cover_01_tmp;
    }

    return SUCCESS;
}

/*****************************************************************/
static int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
    short mdy1[3], mdy2[3];
    int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
    return datediff;
}

/*****************************************************************/
static float MyPower(f1, i1)
float f1;
int i1;
{
    int i;
    float ff=1.0;

    for (i=0; i<i1; i++)
    {
        ff=ff*f1;
    }
    return ff;
}
/*******************/
/**********
double dbl_len8(fulldbl)
double fulldbl;
{

     int chk_flag;
     if (fulldbl < 0)
          chk_flag = 1;
     else
          chk_flag = 0;

     fulldbl = fabs(fulldbl);

     fulldbl = (floor(fulldbl*pow(10,8)))/pow(10,8);

     if (chk_flag == 1)
         return -1 * fulldbl;
     else
         return fulldbl;
}
************/
