/**********************************************************************/
/*   program id   : ca355p01s.ec            1                           */
/*   program name : �O�O�]�l���ɧ@�~                                  */
/*   date written : 2022/01/06                                        */
/*   author       : 061476                                            */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <decimal.h>
#include <math.h>
#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "carmsg.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "sql.h"
$include sqlca;
#include "sqlfatal.h"

char *cm_eyear_str();
static int   DiffMonth();    /* input data should be date format */

/****************************************************************************/
$char   DBName[05],userid[11];
$char   fclass[2],date1[10],date2[10],dbgn[11],dend[11];
int     count_db, k;
/*$char date[11],dToday[11],nyy[4],nmm[3],ndd[3];*/

char    msgbuf[2048],sApHome[30];
char    outputf[N_FILE+1];
long    t;
DBinfo  *list;

$char   stmt1[2048],stmt2[1024],stmt_A1[2048],stmt_A2[1024],stmt_buf[1024];
$char   ipolicy[POLICY_NUM_1],idmg_rate[3],ibrg_rate[3],cal_car_id[3],iassured[13],
	brandi[9],pro_year[5],fpt[2],fassured[2];
$date   dply_begin;
$char   iins_main[INSURANCE_TYPE],iins_type[INSURANCE_TYPE],provision[21],provision_tmp[21],frate[5];
$double pdmg_factor,pbrg_factor,psex_age_damage,psex_age,pdmg_acc,plia_acc,qpt,car_price,pmequipment_rate;
$int    fset,qdrunk_driving,qpro_month,qply_period,qprovision,cnt_FTG,qviolate;
$long   injured_cover,death_cover,damage_cover;
$int    cal_deduct,qday,mins_premium,cal_deduct34_1,cal_deduct34_2;
$char   *prov;

long car355_get_db();
/****************************************************************************/
main(argc, argv)
int argc;
char **argv;
{
	int rc;

	batchinit();
	strcpy(DBName, isNULLstr(argv[1]));
	strcpy(userid, isNULLstr(argv[2]));
	strcpy(fclass, isNULLstr(argv[3]));  /* 1�G��O 2�G�ӫO */
	strcpy(date1,  isNULLstr(argv[4]));
	strcpy(date2,  isNULLstr(argv[5]));
	strcpy(outputf,isNULLstr(argv[6]));

	strcpy(dbgn, cm_to_infdate(date1));
	strcpy(dend, cm_to_infdate(date2));
	printf("-- ����϶�(�褸):[%s] ~ [%s]\n",dbgn,dend);

	rc = car355_get_db();
	if (rc != M_CM_OK)
	{
		EWRITE(userid,rc,msgbuf);
		return rc;
	}

	if (strcmp(fclass,"1") == 0)
	{
		/* �ˬd��O�O�_�}�� */
		rc = car355_check();
		if (rc != M_CM_OK)
		    return rc;

		$BEGIN WORK;
		rc = car355_policy302();
		if (rc != M_CM_OK)
		    return rc;
		$COMMIT WORK;

		EWRITE(userid, M_CM_OK, " ��O���ɧ��� ");
	}
	else
	{
		/*$BEGIN WORK;*/
		rc = car355_policy();
		if (rc != M_CM_OK)
		    return rc;
		/*$COMMIT WORK; */

		EWRITE(userid, M_CM_OK, " �ӫO���ɧ��� ");
	}
}
/******************************************************************************/
long car355_policy302()
{
	printf("BEGIN TO car355_policy302\n");
	$BEGIN WORK;
	$WHENEVER SQLERROR GOTO errexit;

	sprintf(stmt1,"SELECT a.ipolicy, nvl(a.idmg_rate,''), a.dmg_factor, nvl(a.ibrg_rate,''), \n"
	              "       a.brg_factor, a.psex_age_damage, \n"
	              "       decode(fcard_class,'1',a.psex_age_c,a.psex_age),    \n"
	              "       decode(a.pdmg_acc,'','0',a.pdmg_acc)::decimal(5,2), \n"
	              "       case when fcard_class ='1'  \n"
	              "            then decode(a.plia_acc_c,'','0',a.plia_acc_c)::decimal(5,2) \n"
	              "       else decode(a.plia_acc,'','0',a.plia_acc)::decimal(5,2) end, \n"
	              "       a.qdrunk_driving, a.icar_type, a.ilicense, a.ibrand, a.ipro_year,  \n"
	              "       a.qpro_month, a.fpt, a.qpt, a.dply_begin,   \n"
	              "       decode(a.mcar_price,'','0',a.mcar_price)/10000::int, a.qply_period, 0,   \n"
	              "       a.fassured, a.qviolate, \n"
	              "       (select count(*) from ply_ins_type_302 where ipolicy = a.ipolicy    \n"
	              "          and (trim(provision)||';' matches '*F;*'    \n"
	              "            OR trim(provision)||';' matches '*G;*'    \n"
	              "            OR trim(provision)||';' matches '*T;*')), \n"
	              "       case when a.mequipment > 0   \n"
	              "            then round((a.mequipment*10000 /(a.mcar_price - a.mequipment*10000)), 4) \n"
	              "       else 0 end   \n"
	              "  FROM policy_302 a \n"
	              " WHERE a.dply_begin between ? and ? \n"
	              "   AND a.ipolicy[6,7] not in ('VW','V7','ES') \n"
	              "   AND fuw_status_ori >= 500; \n");
	$PREPARE CUR_MAIN FROM $stmt1;
	$DECLARE cur_ply302 CURSOR FOR CUR_MAIN;
	$OPEN cur_ply302 USING $dbgn, $dend;

	while (1)
	{
		$FETCH cur_ply302
		  INTO $ipolicy, $idmg_rate, $pdmg_factor, $ibrg_rate,
		       $pbrg_factor, $psex_age_damage,
		       $psex_age,
		       $pdmg_acc,
		       $plia_acc,
		       $qdrunk_driving, $cal_car_id, $iassured, $brandi, $pro_year,
		       $qpro_month, $fpt, $qpt, $dply_begin,
		       $car_price, $qply_period, $qprovision,
		       $fassured, $qviolate,
		       $cnt_FTG,
		       $pmequipment_rate;

		if (SQLCODE == SQLNOTFOUND) break;

		if (cnt_FTG == 0)
		{
			/* �g�J�D�� */
			printf("insert into ca_policy_factor_302.......... \n");

			printf("Now ipolicy = [%s]\n", ipolicy);

			sprintf(stmt_A1,"INSERT INTO ca_policy_factor_302 \n"
			                "(ipolicy, idmg_rate, pdmg_factor, ibrg_rate, pbrg_factor, \n"
			                " pdmg_sex_age, plia_sex_age, pdmg_acc, plia_acc, qdrunk_driving, \n"
			                " icar_type, iassured, qviolate) \n"
			                " VALUES(?,?,?,?,?, ?,?,?,?,?, ?,?,?) \n");
			$PREPARE insert_factor FROM $stmt_A1;
			$EXECUTE insert_factor using $ipolicy, $idmg_rate, $pdmg_factor, $ibrg_rate, $pbrg_factor,
			                             $psex_age_damage, $psex_age, $pdmg_acc, $plia_acc, $qdrunk_driving,
			                             $cal_car_id, $iassured, $qviolate;

			sprintf(stmt2,"SELECT iins_type, nvl(provision,''), drate_ym, \n"
			              "       ori_inj_cover, ori_dea_cover, ori_dam_cover, ori_deduct, \n"
			              "       qday, ori_premium \n"
			              "  FROM ply_ins_type_302 \n"
			              " WHERE ori_dam_cover > 0 AND ipolicy = ? ; \n");

			$PREPARE CUR_DTL FROM $stmt2;
			$DECLARE cur_ins302 CURSOR FOR CUR_DTL;
			$OPEN cur_ins302 using $ipolicy;

			while (1)
			{
				$FETCH cur_ins302
				  INTO $iins_main, $provision, $frate,
				       $injured_cover, $death_cover, $damage_cover, $cal_deduct,
				       $qday, $mins_premium;

				if (SQLCODE == SQLNOTFOUND) break;

				iins_type[0] = '\0';
				provision_tmp[0] = '\0';
				strcpy(provision_tmp ,trim(provision));

				strcpy(iins_type,trim(iins_main));
				Cal_ins_premium();
				if (strlen(trim(provision_tmp)) > 0)
				{
					prov = strtok(provision_tmp,";");
					while(prov)
					{
						$SELECT count(*) INTO $fset
						FROM ca_provision_main
						WHERE fset = 'Y'
						AND iprovision = $prov;

						if (fset == 0)
						{
							prov = strtok(NULL,";");
						}
						else
						{
							strcpy(iins_type,trim(prov));
							Cal_ins_premium();
							prov = strtok(NULL,";");
						}
					}
				}
			}
			$CLOSE cur_ins302;
			$FREE cur_ins302;
		}
	}
	$CLOSE cur_ply302;
	$FREE cur_ply302;

	$COMMIT WORK;
	return M_CM_OK;

errexit:
    sqlfatal();
    $ROLLBACK WORK;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car355_policy()
{
	printf("BEGIN TO car355_policy\n");
	$BEGIN WORK;
	$WHENEVER SQLERROR GOTO errexit;

	for(k=0;k<count_db;k++)
	{
		sprintf(stmt1,"SELECT a.ipolicy, nvl(a.idmg_rate,''), a.pdmg_factor, nvl(a.ibrg_rate,''), a.pbrg_factor, \n"
			      "       a.psex_age, a.pdmg_acc, a.plia_acc, b.qdrunk_driving, \n"
			      "       b.icar_type, a.iassured, b.ibrand, b.ipro_year, a.qpro_month, \n"
			      "       a.fpt, a.qpt, b.dply_begin, a.mcar_price, b.qply_period, \n"
			      "       b.qprovision, a.fassured, b.qviolate, \n"
			      "       (select count(*) from %s:ori_ins_type where ipolicy = a.ipolicy \n"
			      "           and (trim(provision)||';' matches '*F;*'    \n"
			      "             OR trim(provision)||';' matches '*G;*'    \n"
			      "             OR trim(provision)||';' matches '*T;*')), \n"
			      "       case when a.mequipment > 0  \n"
			      "            then round((a.mequipment/(a.mcar_price - a.mequipment)), 4) \n"
			      "       else 0 end  \n"
			      "  FROM %s:original_ply a, %s:ori_ply_relation b \n"
			      " WHERE a.ipolicy = b.ipolicy \n"
			      "   AND b.dply_close between ? and ? \n"
			      "   AND a.ipolicy[6,7] not in ('VW','V7','ES'); \n"
			      ,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname);

		$PREPARE CUR_MAIN FROM $stmt1;
		$DECLARE cur_ply CURSOR FOR CUR_MAIN;
		$OPEN cur_ply USING $dbgn, $dend;

		while (1)
		{
			$FETCH cur_ply
			  INTO $ipolicy, $idmg_rate, $pdmg_factor, $ibrg_rate, $pbrg_factor,
			       $psex_age, $pdmg_acc, $plia_acc, $qdrunk_driving,
			       $cal_car_id, $iassured, $brandi, $pro_year, $qpro_month,
			       $fpt, $qpt, $dply_begin, $car_price, $qply_period,
			       $qprovision, $fassured, $qviolate,
			       $cnt_FTG,
			       $pmequipment_rate;

			if (SQLCODE == SQLNOTFOUND) break;

			/* ����ʧO�~�֫Y�Ƭ����b�I�ة����ɤ� */
			sprintf(stmt_buf,"SELECT first 1 psex_age FROM %s:ori_ins_type \n"
        		                 " WHERE ipolicy = ? \n"
        		                 "   AND iins_type in (select iins_type from insurance_type \n"
        		                 "                      where iins_type = iins_ply  \n"
        		                 "                        and imain_ins = iins_type \n"
        		                 "                        and fins_grp  = 1         \n"
        		                 "                        and iri_ins <> '11'       \n"
        		                 "                        and dexpire is null)      \n",list[k].dbname);

        		$PREPARE get_psexage FROM $stmt_buf;
        		$EXECUTE get_psexage INTO $psex_age_damage using $ipolicy;
			if (SQLCODE == SQLNOTFOUND) psex_age_damage = 0;

			if (cnt_FTG == 0)
			{
				/* �g�J�D�� */
				printf("insert into ca_policy_factor..........[%s] \n",ipolicy);
				sprintf(stmt_A1,"INSERT INTO %s:ca_policy_factor \n"
				                "(ipolicy, idmg_rate, pdmg_factor, ibrg_rate, pbrg_factor, \n"
				                " pdmg_sex_age, plia_sex_age, pdmg_acc, plia_acc, qdrunk_driving, \n"
				                " icar_type, iassured, qviolate) \n"
				                " VALUES(?,?,?,?,?, ?,?,?,?,?, ?,?,?) \n",list[k].dbname);

				$PREPARE insert_factor FROM $stmt_A1;
				$EXECUTE insert_factor using $ipolicy, $idmg_rate, $pdmg_factor, $ibrg_rate, $pbrg_factor,
				                             $psex_age_damage, $psex_age, $pdmg_acc, $plia_acc, $qdrunk_driving,
				                             $cal_car_id, $iassured, $qviolate;

				sprintf(stmt2,"SELECT iins_type, nvl(provision,''), drate_ym, \n"
				              "       minjured_cover, mdeath_cover, mdamage_cover, mdeduct, qday, \n"
				              "       mins_premium \n"
				              "  FROM %s:ori_ins_type \n"
				              " WHERE ipolicy = ? \n",list[k].dbname);

				$PREPARE CUR_DTL FROM $stmt2;
				$DECLARE cur_ins CURSOR FOR CUR_DTL;
				$OPEN cur_ins using $ipolicy;

				while (1)
				{
					$FETCH cur_ins
					  INTO $iins_main, $provision, $frate,
					       $injured_cover, $death_cover, $damage_cover, $cal_deduct, $qday,
					       $mins_premium;

					if (SQLCODE == SQLNOTFOUND) break;

					iins_type[0] = '\0';
					provision_tmp[0] = '\0';
					strcpy(provision_tmp ,trim(provision));

					strcpy(iins_type,trim(iins_main));
					Cal_ins_premium();
					if (strlen(trim(provision_tmp)) > 0)
					{
						prov = strtok(provision_tmp,";");

						while(prov)
						{
							$SELECT count(*) INTO $fset
							   FROM ca_provision_main
							  WHERE fset = 'Y'
							    AND iprovision = $prov;

							if (fset == 0)
							{
								prov = strtok(NULL,";");
							}
							else
							{
								strcpy(iins_type,trim(prov));
								Cal_ins_premium();
								prov = strtok(NULL,";");
							}
						}
					}
				}
				$CLOSE cur_ins;
				$FREE cur_ins;
			}
		}
		$CLOSE cur_ply;
		$FREE cur_ply;
	}
	$COMMIT WORK;
	return M_CM_OK;

errexit:
    sqlfatal();
    $ROLLBACK WORK;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car355_get_db()
{
	int return_code;

	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	if ( (list = get_db_list(&count_db,DBName)) == (char*)0 )
	{
		EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
		return M_CM_NOT_DBLIST;
	}

	return_code = getApHome(sApHome);
	if (return_code < 0)
	{
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return return_code;
	}
  return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
static int Cal_ins_premium()
{
	$int    iins,fins=0;
	$int    mcover_31,mcover_32;
	$int    ori_mcover1,ori_mcover2,ori_mcover3,ori_mcover4;
	$char   stmt[512];
	$char   tmp_fulldb[64];
	$char   fcal_way[2],isame_ins[INSURANCE_TYPE];
	$char   iins_scope[2],icar_series[3],tbl[30],fassured_comp[2];
	$long   lMins_amt,lDaily_pay;
	$double mpremium_1,mpremium_2,wk_qpt,prate,mprem;
	$double mprem_pure_base,coefficient;

	$long   tmp_mdeduct,lProYM;
	$char   sProYM[11];
	$int    iCar_age;

	lProYM =0;
	strcpy(sProYM,"");

	printf("INTO Cal_ins_prem()\n");

	$WHENEVER SQLERROR GOTO errexit;

	strcpy(tmp_fulldb, get_car_full_db(ipolicy));
	mpremium_1 = 0;	 mpremium_2 = 0;
	mcover_32 = 0;  mcover_31 = 0;
	mprem_pure_base = 0; coefficient = 0;

        strcpy(iins_type,trim(iins_type));
        strcpy(iins_main,trim(iins_main));
        strcpy(frate,trim(frate));
        /*-------------------------------------------------------------------*/
        /*** �O�O�p���k[fcal_way] : 1�O�v��   2�O�B�O�O��                ***/
        /*** �ۭt�B�O[fdeduct]      : 1���ۭt�B 0�L�ۭt�B                  ***/
        /*** �l���d���O[fins_grp]   : 1���l�I   2���d�I   3�j��d���I      ***/
        /*** �P�I�N��[isame_ins] , �C�L�Ǹ�[qserial] , �O�B�Ӽ�[qcoverage] ***/
        /*-------------------------------------------------------------------*/
        iins = 0;
        if (strcmp(iins_type,"21") == 0)
        {
        	fins = 2;   /* �j���I */
        }
        else if (strcmp(iins_type,iins_main) == 0)
        {
        	fins = 1;   /* �I�� */
        	$SELECT fcal_way, isame_ins
        	   INTO $fcal_way, $isame_ins
        	   FROM insurance_type
        	  WHERE iins_type = $iins_type;
        	iins = atoi(rtrim(iins_type));
        }
        else
        {
        	fins = 0;   /* ���[���� */
        	mins_premium = 0;  /* ���[���ڤ��Oñ��O�O */
        }

        if (fins == 0)
        {
        	/*** get ���[���ڶO�v ***/
        	/*** �f���B�e�H�d���I���[����-C ***/
        	if (strcmp(iins_type,"C")==0)
        	{
        		$SELECT coefficient
        		   INTO $coefficient
        		   FROM ca_add_provision
        		  WHERE icar_type = $cal_car_id
        		    AND iins_type = $iins_main
        		    AND provision = 'C'
        		    AND drate     = (SELECT drate
        		                       FROM ca_rate_date
        		                      WHERE icode  = $frate
        		                        AND itable = 'ca_add_provision');
        		if (SQLCODE == SQLNOTFOUND) coefficient = 1.0;

        		coefficient += 1.0;
        	}
        	/*** ���w�r�p�H����-D ***/
        	if (strcmp(iins_type,"D")==0)
        	{
        		$SELECT coefficient
        		   INTO $coefficient
        		   FROM ca_add_provision
        		  WHERE icar_type = $qprovision
        		    AND provision = 'D'
        		    AND drate     = (SELECT drate
        		                       FROM ca_rate_date
        		                      WHERE icode  = $frate
        		                        AND itable = 'ca_add_provision');
        		if (SQLCODE == SQLNOTFOUND) coefficient = 0;

        		if (strcmp(iins_main,"07")==0) coefficient = 0;
        	}
        	/*** �Ұ���O�٪��[����-H ***/
        	if (strcmp(iins_type,"H")==0)
        	{
        		if(strcmp(iins_main,"05")==0  || strcmp(iins_main,"09")==0  ||
        		   strcmp(iins_main,"31")==0  || strcmp(iins_main,"32")==0  ||
        		   strcmp(iins_main,"149")==0 || strcmp(iins_main,"198")==0 ||
        		   strcmp(iins_main,"255")==0 || strcmp(iins_main,"266")==0 ||
        		   strcmp(iins_main,"302")==0)
        		{
        			$SELECT coefficient
        			   INTO $coefficient
        			   FROM ca_add_provision
        			  WHERE icar_type = $cal_car_id
        			    AND iins_type = $iins_main
        			    AND provision = 'H'
        			    AND drate     = (SELECT drate
        			                       FROM ca_rate_date
        			                      WHERE icode  = $frate
        			                        AND itable = 'ca_add_provision');
        			if (SQLCODE == SQLNOTFOUND) coefficient = 1.0;
        		}
        		else
        		        coefficient = 1.0;
        	}
        	/*** �������B���[����-K ***/
        	if (strcmp(iins_type,"K")==0)
        	{
        		$SELECT coefficient
        		   INTO $coefficient
        		   FROM ca_add_provision
        		  WHERE icar_type = $cal_car_id
        		    AND provision = 'K'
        		    AND iins_type = '09'
        		    AND mexpense  = $damage_cover
        		    AND drate     = (SELECT drate
        		                       FROM ca_rate_date
        		                      WHERE icode  = $frate
        		                        AND itable = 'ca_add_provision');
        		if (SQLCODE == SQLNOTFOUND) coefficient = 0;
        	}
        	/*** ������~�γ~���[����-L ***/
        	if (strcmp(iins_type,"L")==0)
        	{
        		$SELECT coefficient
        		   INTO $coefficient
        		   FROM ca_add_provision
        		  WHERE icar_type = $cal_car_id
        		    AND provision = 'L'
        		    AND iins_type = $iins_main
        		    AND drate     = (SELECT drate
        		                       FROM ca_rate_date
        		                      WHERE icode  = $frate
        		                        AND itable = 'ca_add_provision');
        		if (SQLCODE == SQLNOTFOUND) coefficient = 1.0;
        	}
        	/*** ���w���²v���[����A��-P ***/
        	if (strcmp(iins_type,"P")==0)
        	{
        		$SELECT coefficient
        		   INTO $coefficient
        		   FROM ca_add_provision
        		  WHERE icar_type = (SELECT fcar_class
        		                       FROM car_type
        		                      WHERE fclass = '1'
        		                        AND icode  = $cal_car_id)
        		                        AND provision = 'P'
        		                        AND iins_type = $iins_main
        		    AND drate     = (SELECT drate
        		                       FROM ca_rate_date
        		                      WHERE icode  = $frate
        		                        AND itable = 'ca_add_provision');
        		if (SQLCODE == SQLNOTFOUND) coefficient = 1.0;
        	}
        	/*** ���w���²v���[����B��-Q ***/
        	if (strcmp(iins_type,"Q")==0)
        	{
        		$SELECT coefficient
        		   INTO $coefficient
        		   FROM ca_add_provision
        		  WHERE icar_type =  (SELECT fcar_class
        		                        FROM car_type
        		                       WHERE fclass = '1'
        		                         AND icode  = $cal_car_id)
        		    AND provision = 'Q'
        		    AND iins_type = $iins_main
        		    AND drate     = (SELECT drate
        		                       FROM ca_rate_date
        		                      WHERE icode  = $frate
        		                        AND itable = 'ca_add_provision');
        		if (SQLCODE == SQLNOTFOUND) coefficient = 1.0;
        	}
        	/*** ���w���²v���[����C��-M ***/
        	if (strcmp(iins_type,"M")==0)
        	{
        		$SELECT coefficient
        		   INTO $coefficient
        		   FROM ca_add_provision
        		  WHERE icar_type =  (SELECT fcar_class
        		                        FROM car_type
        		                       WHERE fclass = '1'
        		                         AND icode  = $cal_car_id)
        		    AND provision = 'M'
        		    AND iins_type = $iins_main
        		    AND drate     = (SELECT drate
        		                       FROM ca_rate_date
        		                      WHERE icode  = $frate
        		                        AND itable = 'ca_add_provision');
        		if (SQLCODE == SQLNOTFOUND) coefficient = 1.0;
        	}
        	/*** �T������l���O�I�s�t��W�B���[����-Y ***/
        	if (strcmp(iins_type,"Y")==0)
        	{
        		$SELECT first 1 coefficient
        		   INTO $coefficient
        		   FROM ca_add_provision
        		  WHERE icar_type = $cal_car_id
        		    AND provision = 'Y'
        		    AND iins_type = '*'
        		    AND mexpense <= $pmequipment_rate
        		    AND drate     = (SELECT drate
        		                       FROM ca_rate_date
        		                      WHERE icode  = $frate
        		                        AND itable = 'ca_add_provision')
        		  ORDER BY mexpense desc;
        		if (SQLCODE == SQLNOTFOUND) coefficient = 1.0;
        	}
        }
        else if (fins == 1)
        {
        	if (strcmp(fclass,"1") == 0)
        	{
        		strcpy(tbl,"ca_pa_ply_302");
        		sprintf(stmt,"SELECT first 1 mins_amt, ori_daily_pay, iins_scope FROM %s \n"
        		             " WHERE ipolicy = ? and iins_type = ? \n"
        		             "   AND mins_amt > 0 \n",tbl);
        		$PREPARE pre_pa FROM $stmt;
        		$EXECUTE pre_pa INTO $lMins_amt, $lDaily_pay, $iins_scope using $ipolicy, $iins_type;
        	}
        	else
        	{
        		sprintf(tbl,"%s:ca_pa_ori",tmp_fulldb);
        		sprintf(stmt,"SELECT first 1 mins_amt, daily_pay, iins_scope FROM %s \n"
        		             " WHERE ipolicy = ? and iins_type = ? \n"
        		             "   AND mins_amt > 0 \n",tbl);
        		$PREPARE pre_pa FROM $stmt;
        		$EXECUTE pre_pa INTO $lMins_amt, $lDaily_pay, $iins_scope using $ipolicy, $iins_type;
        	}

        	if (SQLCODE == SQLNOTFOUND)
        	{
        		lMins_amt = 0;
        		lDaily_pay = 0;
        		strcpy(iins_scope,"");
        	}

        	/*** �ˮ`�I-48 ***/
        	if (iins == 48)
        	{
        		/* 1.���o���ݯ«O�O (mpremium) */
        		$SELECT mpremium
        		   INTO $mpremium_1
        		   FROM cover_vs_premium
        		  WHERE icar_type = $cal_car_id
        		    AND iins_type = '48'
        		   AND mdeduct    = 0
        		   AND mcoverage1 = 0
        		   AND mcoverage2 = $lMins_amt
        		   AND drate      = (SELECT drate
        		                       FROM ca_rate_date
        		                      WHERE icode  = $frate
        		                        AND itable = 'cover_vs_premium');

        		/* 2.���o���[�����«O�O (mpremium) */
        		$SELECT mpremium
        		   INTO $mpremium_2
        		   FROM cover_vs_premium
        		  WHERE icar_type  = $cal_car_id
        		    AND iins_type  = '48'
        		    AND mdeduct    = 1
        		    AND mcoverage1 = 0
        		    AND mcoverage2 = $lDaily_pay
        		    AND drate      = (SELECT drate
        		                        FROM ca_rate_date
        		                       WHERE icode  = $frate
        		                         AND itable = 'cover_vs_premium');
        		mprem_pure_base = mpremium_1 + mpremium_2;

        		goto insert_table;
        	}
        	/*** �T�����[�����ĤT�H�d���I-35 ***/
        	if (iins == 35)
        	{
        		/* ���o�«O�O (mpremium) */
        		$SELECT mpremium
        		   INTO $mprem_pure_base
        		   FROM cover_vs_premium
        		  WHERE icar_type  = $cal_car_id
        		    AND iins_type  = '35'
        		    AND mdeduct    = $iins_scope
        		    AND mcoverage1 = 0
        		    AND mcoverage2 = $lMins_amt
        		    AND drate      = (SELECT drate
        		                        FROM ca_rate_date
        		                       WHERE icode  = $frate
        		                         AND itable = 'cover_vs_premium');

        		goto insert_table;
        	}
        	/*** �ˮ`�I-56/136/166/266 ***/
        	if (iins == 56 || iins == 136 || iins == 166 || iins == 266)
        	{
        		/* 1.���o���ݯ«O�O (mpremium) */
        		$SELECT mpremium
        		   INTO $mpremium_1
        		   FROM cover_vs_premium
        		  WHERE icar_type  = $cal_car_id
        		    AND iins_type  = $iins_type
        		    AND mdeduct    = 0
        		    AND mcoverage1 = 0
        		    AND mcoverage2 = $lMins_amt
        		    AND drate      = (SELECT drate
        		                        FROM ca_rate_date
        		                       WHERE icode  = $frate
        		                         AND itable = 'cover_vs_premium');

        		tmp_mdeduct = -1;
        		if( strcmp( iins_scope , "2" ) == 0 ){
        			tmp_mdeduct = 1;
        		}else if( strcmp( iins_scope , "3" ) == 0 ){
        			tmp_mdeduct = 2;
        		}

        		/* 2.���o���[�����«O�O (mpremium) */
        		$SELECT mpremium
        		   INTO $mpremium_2
        		   FROM cover_vs_premium
        		  WHERE icar_type  = $cal_car_id
        		    AND iins_type  = $iins_type
        		    AND mdeduct    = $tmp_mdeduct
        		    AND mcoverage1 = 0
        		    AND mcoverage2 = $lDaily_pay
        		    AND drate      = (SELECT drate
        		                        FROM ca_rate_date
        		                       WHERE icode  = $frate
        		                         AND itable = 'cover_vs_premium');
        		mprem_pure_base = mpremium_1 + mpremium_2;

        		goto insert_table;
        	}
        	/*** �s��Q�ѷl���I-12/28/128 ***/
        	if (iins == 12 || iins == 28 || iins == 128)
        	{
        		$DECLARE CA_OPT5 CURSOR for
        		  SELECT icar_series
        		    INTO $icar_series
        		    FROM ca_car_model
        		   WHERE ibrand    = $brandi
        		     AND ipro_year = $pro_year
        		     AND (dexpire is null or dexpire > today)
        		   ORDER BY drate DESC;
        		$OPEN CA_OPT5;
        		$FETCH CA_OPT5;
        		if (SQLCODE == SQLNOTFOUND)
        		{
        			$DECLARE CA_OPT5A CURSOR for
        			  SELECT icar_series
        			    INTO $icar_series
        			    FROM ca_car_model
        			   WHERE ibrand    = $brandi
        			     AND (dexpire is null or dexpire > today)
        			     AND ipro_year = (SELECT MAX(ipro_year)
        			                        FROM ca_car_model
        			                       WHERE ibrand = $brandi
        			                         AND ipro_year < $pro_year
        			                         AND (dexpire is null or dexpire > today))
        			                         AND (dexpire is null or dexpire > today)
        			   ORDER BY drate DESC;
        			$OPEN CA_OPT5A;
        			$FETCH CA_OPT5A;
        			if (SQLCODE == SQLNOTFOUND)
        			{
        				$DECLARE CA_OPT5A1 CURSOR for
        				  SELECT icar_series
        				    INTO $icar_series
        				    FROM ca_car_model
        				   WHERE ibrand    = $brandi
        				     AND (dexpire is null or dexpire > today)
        				     AND ipro_year = (SELECT MIN(ipro_year)
        				                        FROM ca_car_model
        				                       WHERE ibrand = $brandi
        				                         AND ipro_year > $pro_year
        				                         AND (dexpire is null or dexpire > today))
        				                         AND (dexpire is null or dexpire > today)
        				   ORDER BY drate DESC;
        				$OPEN CA_OPT5A1;
        				$FETCH CA_OPT5A1;

        				$CLOSE CA_OPT5A1;
        				$FREE CA_OPT5A1;
        			}
        			$CLOSE CA_OPT5A;
        			$FREE CA_OPT5A;
        		}
        		$CLOSE CA_OPT5;
        		$FREE CA_OPT5;

        		if (iins == 12)
        		{
        			$SELECT prate
        			   INTO $mprem_pure_base
        			   FROM ca_rate
        			  WHERE icar_type = $icar_series
        			    AND iins_type = $iins_type
        			    AND mdeduct   = $cal_deduct
        			    AND drate     = (SELECT drate
        			                       FROM ca_rate_date
        			                      WHERE icode  = $frate
        			                        AND itable = 'ca_rate');
        		}
        		else if (iins == 28 || iins == 128)
        		{
        			$SELECT mpremium
        			   INTO $mprem_pure_base
        			   FROM cover_vs_premium
        			  WHERE icar_type  = $icar_series
        			    AND iins_type  = $iins_type
        			    AND mcoverage1 = $injured_cover
        			    AND mcoverage2 = $damage_cover
        			    AND mdeduct    = $cal_deduct
        			    AND drate      = (SELECT drate
        			                        FROM ca_rate_date
        			                       WHERE icode  = $frate
        			                         AND itable = 'cover_vs_premium');
        		}
        		goto insert_table;
        	}

        	switch (fcal_way[0])   /***�O�O�p���k 1:�O�v�� 2:�O�B�O�O�� 3:�O�T�I 4:�O�v�ɥ[�O�B�O�O ***/
        	{
        		case '1':   /* fcal_way 1:�O�v�ɭp��O�O    */
        		case '4':   /* fcal_way 2:�O�v�ɥ[�O�B�O�O */

        		wk_qpt=0;

        		if (iins==1 || iins==5 || iins==9 || iins==181 || iins==198 || iins==201 || iins==205 || iins==209)
        		{
        			if (strcmp(cal_car_id,"05")==0 || strcmp(cal_car_id,"06")==0 ||
        			    strcmp(cal_car_id,"09")==0 || strcmp(cal_car_id,"10")==0 ||
        			    strcmp(cal_car_id,"20")==0)
        			{
        				wk_qpt = qpt;
        			}
        			else
        			    wk_qpt = 0;
        		}
        		else
        			wk_qpt = 0;

        		/******* BEGIN:�̶O�v�ɭp��O�O **********/
        		if (iins!=152 && iins!=153)
        		{
        			/* get �򥻫O�O,�p��v,�p���I��,������� */
        			if (fpt[0]=='P')
        			{
        				if (iins==24 || iins==26)
        				{
        					$SELECT prate, mprem
        					   INTO $prate, $mprem
        					   FROM ca_rate
        					  WHERE icar_type = $cal_car_id
        					    AND iins_type = $iins_type
        					    AND qpt_bgn  <= $wk_qpt
        					    AND qpt_end  >= $wk_qpt
        					    AND drate     = (SELECT drate
        					                       FROM ca_rate_date
        					                      WHERE icode  = $frate
        					                        AND itable = 'ca_rate');
        				}
        				else if (iins==111)
        				{
        					if (qply_period <= 12)
        					{
        						$SELECT prate, mprem
        						   INTO $prate, $mprem
        						   FROM ca_rate
        						  WHERE icar_type = $cal_car_id
        						    AND iins_type = $iins_type
        						    AND mdeduct   = 1
        						    AND qpt_bgn  <= $wk_qpt
        						    AND qpt_end  >= $wk_qpt
        						    AND drate     = (SELECT drate
        						                       FROM ca_rate_date
        						                      WHERE icode  = $frate
        						                        AND itable = 'ca_rate');
        					}
        					else
        					{
        						$SELECT prate, mprem
        						   INTO $prate, $mprem
        						   FROM ca_rate
        						  WHERE icar_type = $cal_car_id
        						    AND iins_type = $iins_type
        						    AND mdeduct   = 2
        						    AND qpt_bgn  <= $wk_qpt
        						    AND qpt_end  >= $wk_qpt
        						    AND drate     = (SELECT drate
        						                       FROM ca_rate_date
        						                      WHERE icode  = $frate
        						                        AND itable = 'ca_rate');
        					}
        				}
        				else
        				{
        					$SELECT prate, mprem
        					   INTO $prate, $mprem
        					   FROM ca_rate
        					  WHERE icar_type = $cal_car_id
        					    AND iins_type = $iins_type
        					    AND mdeduct   = $cal_deduct
        					    AND qpt_bgn  <= $wk_qpt
        					    AND qpt_end  >= $wk_qpt
        					    AND drate     = (SELECT drate
        					                       FROM ca_rate_date
        					                      WHERE icode  = $frate
        					                        AND itable = 'ca_rate');
        				}
        			}
        			else  /*(fpt[0]!='P')*/
        			{
        				if ((strcmp(cal_car_id,"06")==0 || strcmp(cal_car_id,"10")==0 || strcmp(cal_car_id,"20")==0 ) &&
        				    (iins==1 || iins==5 || iins==9 || iins==181 || iins==198 || iins==201 || iins==205 || iins==209))
        				{
        					$SELECT prate, mprem
        					   INTO $prate, $mprem
        					   FROM ca_rate
        					  WHERE icar_type = $cal_car_id
        					    AND iins_type = $iins_type
        					    AND mdeduct   = $cal_deduct
        					    AND qpt_bgn   < $wk_qpt
        					    AND qpt_end  >= $wk_qpt
        					    AND drate     = (SELECT drate
        					                       FROM ca_rate_date
        					                      WHERE icode  = $frate
        					                        AND itable = 'ca_rate');
        				}
        				else
        				{
        					if (iins==24 || iins==26)
        					{
        						$SELECT prate, mprem
        						   INTO $prate, $mprem
        						   FROM ca_rate
        						  WHERE icar_type = $cal_car_id
        						    AND iins_type = $iins_type
        						    AND qpt_bgn  <= $wk_qpt
        						    AND qpt_end  >= $wk_qpt
        						    AND drate     = (SELECT drate
        						                       FROM ca_rate_date
        						                      WHERE icode  = $frate
        						                        AND itable = 'ca_rate');
        					}
        					else
        					{
        						$SELECT prate, mprem
        						   INTO $prate, $mprem
        						   FROM ca_rate
        						  WHERE icar_type = $cal_car_id
        						    AND iins_type = $iins_type
        						    AND mdeduct   = $cal_deduct
        						    AND qpt_bgn  <= $wk_qpt
        						    AND qpt_end  >= $wk_qpt
        						    AND drate     = (SELECT drate
        						                       FROM ca_rate_date
        						                      WHERE icode  = $frate
        						                        AND itable = 'ca_rate');
        					}
        				}
        			}

        			if (prate > 0)
        			    mprem_pure_base = prate;
        			else
        			    mprem_pure_base = mprem;
        		}
        		/******* END:�̶O�v�ɭp��O�O **********/
        		break;

        		case '2':    /* fcal_way 2:�O�B�O�O�ɱo��O�O */
        		/******* BEGIN:�̫O�B�O�O�ɭp��O�O **********/
        		if (iins==34 || iins==115)
        		{
        			if (strcmp(fclass,"1") == 0)
        			{
        				/* ��O�S�������«O�O */
        				strcpy(tbl,"ply_ins_cover_302");
        				sprintf(stmt,"SELECT ori_mcover FROM %s \n"
        				             " WHERE ipolicy = ? \n"
        				             "   AND icover_type = '001'; \n",tbl);
        				$PREPARE pre_cover1 FROM $stmt;
        				$EXECUTE pre_cover1 INTO $ori_mcover1 using $ipolicy;

        				sprintf(stmt,"SELECT ori_mcover FROM %s \n"
        				             " WHERE ipolicy = ? \n"
        				             "   AND icover_type = '002'; \n",tbl);
        				$PREPARE pre_cover2 FROM $stmt;
        				$EXECUTE pre_cover2 INTO $ori_mcover2 using $ipolicy;

        				sprintf(stmt,"SELECT ori_mcover FROM %s \n"
        				             " WHERE ipolicy = ? \n"
        				             "   AND icover_type = '003'; \n",tbl);
        				$PREPARE pre_cover3 FROM $stmt;
        				$EXECUTE pre_cover3 INTO $ori_mcover3 using $ipolicy;

        				sprintf(stmt,"SELECT ori_mcover FROM %s \n"
        				             " WHERE ipolicy = ? \n"
        				             "   AND icover_type = '004'; \n",tbl);
        				$PREPARE pre_cover4 FROM $stmt;
        				$EXECUTE pre_cover4 INTO $ori_mcover4 using $ipolicy;

        				cal_deduct34_1 = 1;
        				cal_deduct34_2 = 2;
        				if(qply_period > 12)
        				{
        					cal_deduct34_1 = 21;
        					cal_deduct34_2 = 22;
        				}

        				$SELECT mpremium
        				   INTO $mpremium_1
        				   FROM cover_vs_premium
        				  WHERE icar_type  = $cal_car_id
        				    AND iins_type  = $iins_type
        				    AND mcoverage1 = $ori_mcover1
        				    AND mcoverage2 = $ori_mcover2
        				    AND mdeduct    = $cal_deduct34_1
        				    AND drate      = (SELECT drate
        				                        FROM ca_rate_date
        				                       WHERE icode = $frate
        				                         AND itable= 'cover_vs_premium');

        				$SELECT mpremium
        				   INTO $mpremium_2
        				   FROM cover_vs_premium
        				  WHERE icar_type  = $cal_car_id
        				    AND iins_type  = $iins_type
        				    AND mcoverage1 = $ori_mcover3
        				    AND mcoverage2 = $ori_mcover4
        				    AND mdeduct    = $cal_deduct34_2
        				    AND drate      = (SELECT drate
        				                        FROM ca_rate_date
        				                       WHERE icode = $frate
        				                         AND itable= 'cover_vs_premium');
        			}
        			else
        			{
        				sprintf(tbl,"%s:ori_ins_cover",tmp_fulldb);
        				sprintf(stmt,"SELECT mpure_prem FROM %s \n"
        				             " WHERE ipolicy = ? \n"
        				             "   AND icover_type = '001'; \n",tbl);
        				$PREPARE pre_cover1 FROM $stmt;
        				$EXECUTE pre_cover1 INTO $mpremium_1 using $ipolicy;

        				sprintf(stmt,"SELECT mpure_prem FROM %s \n"
        				             " WHERE ipolicy = ? \n"
        				             "   AND icover_type = '003'; \n",tbl);
        				$PREPARE pre_cover3 FROM $stmt;
        				$EXECUTE pre_cover3 INTO $mpremium_2 using $ipolicy;
        			}
        			mprem_pure_base = mpremium_1 + mpremium_2;
        		}
        		else if (!IsBlankNull(isame_ins))
        		{
        			/* 31,32,71,72,29,30,301,302,38,39,109,113,114,124,131,132,133,134,
        			   149,158,159,164,165,530,531,532,561,562,563 */
        			if (iins==71 || iins==72)
        			{
        				$SELECT mpremium
        				   INTO $mprem_pure_base
        				   FROM cover_vs_premium
        				  WHERE icar_type  = $cal_car_id
        				    AND iins_type  = $iins_type
        				    AND mcoverage2 = $damage_cover
        				    AND mdeduct    = $cal_deduct
        				    AND drate      = (SELECT drate
        				                        FROM ca_rate_date
        				                       WHERE icode=$frate
        				                         AND itable='cover_vs_premium');
        			}
        			else if (iins==29 || iins==30 || iins==124 || iins==301 || iins==302 || iins==530)
        			{
        				if (iins==30)
        				{
        					$SELECT mpremium
        					   INTO $mprem_pure_base
        					   FROM cover_vs_premium
        					  WHERE icar_type  = $cal_car_id
        					    AND iins_type  = $iins_type
        					    AND mcoverage1 = $injured_cover
        					    AND mcoverage2 = $damage_cover
        					    AND mdeduct    = 1+10*$cal_deduct
        					    AND drate      = (SELECT drate
        					                        FROM ca_rate_date
        					                       WHERE icode  = $frate
        					                         AND itable = 'cover_vs_premium');

        					if(qply_period > 12)
        					{
        						$SELECT mpremium
        						   INTO $mprem_pure_base
        						   FROM cover_vs_premium
        						  WHERE icar_type  = $cal_car_id
        						    AND iins_type  = $iins_type
        						    AND mcoverage1 = $injured_cover
        						    AND mcoverage2 = $damage_cover
        						    AND mdeduct    = 2+10*$cal_deduct
        						    AND drate      = (SELECT drate
        						                        FROM ca_rate_date
        						                       WHERE icode  = $frate
        						                         AND itable = 'cover_vs_premium');
        					}
        				}
        				if (iins==301 || iins==302 || iins==530)
        				{
        					$SELECT mpremium
        					   INTO $mprem_pure_base
        					   FROM cover_vs_premium
        					  WHERE icar_type  = $cal_car_id
        					    AND iins_type  = $iins_type
        					    AND mcoverage1 = $injured_cover
        					    AND mcoverage2 = $damage_cover
        					    AND mdeduct    = $cal_deduct
        					    AND drate      = (SELECT drate
        					                        FROM ca_rate_date
        					                       WHERE icode  = $frate
        					                         AND itable = 'cover_vs_premium');
        				}
        				if (iins==29 || iins==124)
        				{
        					if (strcmp(fclass,"1") == 0)
        					{
        						strcpy(tbl,"ply_ins_type_302");
        						sprintf(stmt,"SELECT first 1 ori_dam_cover FROM %s \n"
        						             " WHERE ipolicy = ? and ori_dam_cover > 0 \n"
        						             "   AND iins_type in ('132','134','149','32'); \n",tbl);
        						$PREPARE pre_dam32 FROM $stmt;
        						$EXECUTE pre_dam32 INTO $mcover_32 using $ipolicy;
        					}
        					else
        					{
        						sprintf(tbl,"%s:ori_ins_type",tmp_fulldb);
        						sprintf(stmt,"SELECT first 1 mdamage_cover FROM %s \n"
        						             " WHERE ipolicy = ? \n"
        						             "   AND iins_type in ('132','134','149','32'); \n",tbl);
        						$PREPARE pre_dam32 FROM $stmt;
        						$EXECUTE pre_dam32 INTO $mcover_32 using $ipolicy;
        					}

        					if (mcover_32 >= 200000 && mcover_32 < 500000)
        					    mcover_32 = 200000;
        					else if (mcover_32 >= 500000 && mcover_32 <= 1000000)
        					    mcover_32 = 500000;
        					else mcover_32 = 0;

        					$SELECT mpremium
        					   INTO $mprem_pure_base
        					   FROM cover_vs_premium
        					  WHERE icar_type  = $cal_car_id
        					    AND iins_type  = $iins_type
        					    AND mcoverage1 = $mcover_32
        					    AND mcoverage2 = $damage_cover
        					    AND mdeduct    = $cal_deduct
        					    AND drate      = (SELECT drate
        					                        FROM ca_rate_date
        					                       WHERE icode  = $frate
        					                         AND itable = 'cover_vs_premium');
        				}
        			}/* end 29,30,124,301,302,530 */
        			else if (iins == 38 || iins == 39)
        			{
        				/* ����1:�H�ۭt�B(���{��||����)���o�򥻯«O�O
        				   ����2:�ۭt�B205:�e2�X�����{��, ��1�X������.
        				   ����3:���֭p�� = �s�y�~ �� �_�O�~
        				   ����4:����5�~�H�W--���t5�~�� ( > 5)
        				         ����5�~�H�U--�t5�~ ( <= 5)
        				   �]�W,�Y���֤��~, ���H�ۭt�B=200�p��O�O */
        				iCar_age = atoi(cm_eyear_str(dply_begin)) - atoi(pro_year); /* �D���ϴ��I�ب��� */
        				if ( iCar_age <= 0) iCar_age = 1 ;      /* ���~��1�~ */
        				else if ( iCar_age >= 9) iCar_age = 9 ; /* �j��9�~��9�~ */

        				iCar_age = qday * 10 + iCar_age;

        				$SELECT a.mpremium
        				   INTO $mprem_pure_base
        				   FROM cover_vs_premium a
        				  WHERE a.icar_type  = $cal_car_id
        				    AND a.iins_type  = $iins_type
        				    AND a.mcoverage1 = $injured_cover
        				    AND a.mcoverage2 = $damage_cover
        				    AND drate        = (SELECT drate
        				                          FROM ca_rate_date
        				                         WHERE icode=$frate
        				                           AND itable='cover_vs_premium')
        				    AND mdeduct      = (select max(mdeduct) from cover_vs_premium
        				                         where icar_type = a.icar_type
        				                           and iins_type = a.iins_type
        				                           and mcoverage1 = a.mcoverage1
        				                           and mcoverage2 = a.mcoverage2
        				                           and drate = a.drate
        				                           and mdeduct < $iCar_age
        				                           and ((mdeduct- mod(mdeduct,$qday))/10 = $qday));
        			}
        			else  /* 31,32,45,46,109,113,114,131,132,133,134,149,158,159,164,
        			         165,231,232,249,331,332,531,532, 561,562,563 */
        			{
        				if (iins==32 || iins==132 || iins==134 || iins==149 || iins==232 ||
        				    iins==249 || iins==332 || iins==532)
        				{
        					$SELECT mpremium
        					   INTO $mprem_pure_base
        					   FROM cover_vs_premium
        					  WHERE icar_type  = $cal_car_id
        					    AND iins_type  = $iins_type
        					    AND mcoverage1 = $injured_cover
        					    AND mcoverage2 = $damage_cover
        					    AND mdeduct    = $cal_deduct
        					    AND drate      = (SELECT drate
        					                        FROM ca_rate_date
        					                       WHERE icode  = $frate
        					                         AND itable = 'cover_vs_premium');
        				}
        				else if (iins==31 || iins==131 || iins==133 || iins==231 || iins==331 || iins==532 )
        				{
        					$SELECT mpremium
        					   INTO $mprem_pure_base
        					   FROM cover_vs_premium
        					  WHERE icar_type  = $cal_car_id
        					    AND iins_type  = $iins_type
        					    AND mcoverage1 = $injured_cover
        					    AND mcoverage2 = $damage_cover
        					    AND mdeduct    = $cal_deduct
        					    AND drate      = (SELECT drate
        					                        FROM ca_rate_date
        					                       WHERE icode  = $frate
        					                         AND itable = 'cover_vs_premium');
        				}
        				else if (iins==109)
        				{
        					if (strcmp(fclass,"1") == 0)
        					{
        						strcpy(tbl,"ply_ins_type_302");
        						sprintf(stmt,"SELECT first 1 ori_inj_cover FROM %s \n"
        						             " WHERE ipolicy = ? and ori_dam_cover > 0 \n"
        						             "   AND iins_type in ('31','131','133','77'); \n",tbl);
        						$PREPARE pre_dam31 FROM $stmt;
        						$EXECUTE pre_dam31 INTO $mcover_31 using $ipolicy;
        					}
        					else
        					{
        						sprintf(tbl,"%s:ori_ins_type",tmp_fulldb);
        						sprintf(stmt,"SELECT first 1 minjured_cover FROM %s \n"
        						             " WHERE ipolicy = ? \n"
        						             "   AND iins_type in ('31','131','133','77'); \n",tbl);
        						$PREPARE pre_dam31 FROM $stmt;
        						$EXECUTE pre_dam31 INTO $mcover_31 using $ipolicy;
        					}

        					$SELECT mpremium
        					   INTO $mprem_pure_base
        					   FROM cover_vs_premium
        					  WHERE icar_type  = $cal_car_id
        					    AND iins_type  = $iins_type
        					    AND mcoverage1 = $mcover_31
        					    AND mcoverage2 = $death_cover
        					    AND drate      = (SELECT drate
        					                        FROM ca_rate_date
        					                       WHERE icode  = $frate
        					                         AND itable = 'cover_vs_premium');
        				}
        				else if (iins==113 || iins==114)
        				{
        					$SELECT mpremium
        					   INTO $mprem_pure_base
        					   FROM cover_vs_premium
        					  WHERE icar_type  = $cal_car_id
        					    AND iins_type  = $iins_type
        					    AND mcoverage1 = $injured_cover
        					    AND mcoverage2 = $damage_cover
        					    AND mdeduct    = 1+10*$cal_deduct
        					    AND drate      = (SELECT drate
        					                        FROM ca_rate_date
        					                       WHERE icode  = $frate
        					                         AND itable = 'cover_vs_premium');

        					if(qply_period > 12)
        					{
        						$SELECT mpremium
        						   INTO $mprem_pure_base
        						   FROM cover_vs_premium
        						  WHERE icar_type  = $cal_car_id
        						    AND iins_type  = $iins_type
        						    AND mcoverage1 = $injured_cover
        						    AND mcoverage2 = $damage_cover
        						    AND mdeduct    = 2+10*$cal_deduct
        						    AND drate      = (SELECT drate
        						                        FROM ca_rate_date
        						                       WHERE icode  = $frate
        						                         AND itable = 'cover_vs_premium');
        					}
        				}
        				else if (iins==164 || iins==165)
        				{
        					$SELECT mpremium
        					   INTO $mprem_pure_base
        					   FROM cover_vs_premium
        					  WHERE icar_type  = $cal_car_id
        					    AND iins_type  = $iins_type
        					    AND mcoverage1 = $injured_cover
        					    AND mcoverage2 = $damage_cover
        					    AND mdeduct    = $cal_deduct
        					    AND drate      = (SELECT drate
        					                        FROM ca_rate_date
        					                       WHERE icode  = $frate
        					                         AND itable = 'cover_vs_premium');
        				}
        				else
        				{
        					$SELECT mpremium
        					   INTO $mprem_pure_base
        					   FROM cover_vs_premium
        					  WHERE icar_type  = $cal_car_id
        					    AND iins_type  = $iins_type
        					    AND mcoverage1 = $injured_cover
        					    AND mcoverage2 = $damage_cover
        					    AND drate      = (SELECT drate
        					                        FROM ca_rate_date
        					                       WHERE icode  = $frate
        					                         AND itable = 'cover_vs_premium');
        				}
        			}
        		}
        		else
        		{
        			/* 19,27,157,15,16,66,67,154,155,156,163,62,63,64,86,101,102,103,104,143,145,146,148,161,162,110,53,22,21,117,28,57,59,60,147,128,135,136,55,255,34,35,47,48,49,50,198,160,171,172,238,237 */
        			/* 14,61,65,68,69,25,51,52,47,27,101,102,103,104 */
        			if (iins == 19 || iins == 27 || iins == 157)
        			{
        				$SELECT mpremium
        				   INTO $mprem_pure_base
        				   FROM cover_vs_premium
        				  WHERE icar_type  = $cal_car_id
        				    AND iins_type  = $iins_type
        				    AND mcoverage2 = $damage_cover
        				    AND drate      = (SELECT drate
        				                        FROM ca_rate_date
        				                       WHERE icode  = $frate
        				                         AND itable = 'cover_vs_premium');
        			}
        			else if (iins == 15  || iins == 16  || iins == 66 || iins == 67 ||
        			         iins == 154 || iins == 155 || iins == 156|| iins == 163 )
        			{
        				$SELECT mpremium
        				   INTO $mprem_pure_base
        				   FROM cover_vs_premium
        				  WHERE icar_type  = $cal_car_id
        				    AND iins_type  = $iins_type
        				    AND mcoverage1 = $injured_cover
        				    AND mcoverage2 = $damage_cover
        				    AND drate      = (SELECT drate
        				                        FROM ca_rate_date
        				                       WHERE icode  = $frate
        				                         AND itable = 'cover_vs_premium');
        			}
        			else if (iins==62 || iins==63  || iins==64  || iins==86  ||
        			iins==101 || iins==102 || iins==103 || iins==104 ||
        			iins==143 || iins==145 || iins==146 || iins==148 ||
        			iins==161 || iins==162 )
        			{
        				if (iins == 86)
        				{
        					injured_cover = 0;

        					if (strcmp(cal_car_id,"32")==0)
        					{
        						$select min(mcoverage1)
        						   into $injured_cover
        						   from cover_vs_premium
        						  where iins_type = $iins_type
        						    and icar_type = $cal_car_id
        						    and drate     = (SELECT drate
        						                       FROM ca_rate_date
        						                      WHERE icode  = $frate
        						                        AND itable = 'cover_vs_premium')
        						    and mcoverage1 >= $car_price;
        						if (SQLCODE == SQLNOTFOUND) injured_cover = 0;
        					}

        					$SELECT mpremium
        					   INTO $mprem_pure_base
        					   FROM cover_vs_premium
        					  WHERE icar_type  = $cal_car_id
        					    AND iins_type  = $iins_type
        					    AND mcoverage1 = $injured_cover
        					    AND mcoverage2 = $damage_cover
        					    AND mdeduct    = $cal_deduct
        					    AND drate      = (SELECT drate
        					                        FROM ca_rate_date
        					                       WHERE icode  = $frate
        					                         AND itable = 'cover_vs_premium');
        				}
        				else if (iins == 101 || iins == 102)
        				{
        					$SELECT first 1 mpremium
        					   INTO $mprem_pure_base
        					   FROM cover_vs_premium
        					  WHERE icar_type  = $cal_car_id
        					    AND iins_type  = $iins_type
        					    AND mcoverage2 = $damage_cover
        					    AND drate      = (SELECT drate
        					                        FROM ca_rate_date
        					                       WHERE icode  = $frate
        					                         AND itable = 'cover_vs_premium')
        					  ORDER BY mcoverage2 desc;
        				}
        				else if (iins == 103 || iins == 104 || iins == 145 || iins == 146 || iins == 148)
        				{
        					$SELECT mpremium
        					   INTO $mprem_pure_base
        					   FROM cover_vs_premium
        					  WHERE icar_type  = $cal_car_id
        					    AND iins_type  = $iins_type
        					    AND mcoverage1 = $injured_cover
        					    AND mcoverage2 = $damage_cover
        					    AND mdeduct    = $cal_deduct
        					    AND drate      = (SELECT drate
        					                        FROM ca_rate_date
        					                       WHERE icode  = $frate
        					                         AND itable = 'cover_vs_premium');
        				}
        				else if (iins == 161 || iins == 162)
        				{
        					$SELECT mpremium
        					   INTO $mprem_pure_base
        					   FROM cover_vs_premium
        					  WHERE icar_type  = $cal_car_id
        					    AND iins_type  = $iins_type
        					    AND mcoverage2 = $damage_cover
        					    AND mdeduct    = $cal_deduct
        					    AND drate      = (SELECT drate
        					                        FROM ca_rate_date
        					                       WHERE icode  = $frate
        					                         AND itable = 'cover_vs_premium');
        				}
        				else  /*62,63,64,143*/
        				{
        					$SELECT mpremium
        					   INTO $mprem_pure_base
        					   FROM cover_vs_premium
        					  WHERE icar_type  = $cal_car_id
        					    AND iins_type  = $iins_type
        					    AND mcoverage1 = $injured_cover
        					    AND mcoverage2 = $damage_cover
        					    AND mdeduct    = $cal_deduct
        					    AND drate      = (SELECT drate
        					                        FROM ca_rate_date
        					                       WHERE icode  = $frate
        					                         AND itable = 'cover_vs_premium');
        				}
        			}
							else if (iins==178)
							{
								$SELECT mpremium
        				   INTO $mprem_pure_base
        				   FROM cover_vs_premium
        				  WHERE icar_type  = $cal_car_id
        				    AND iins_type  = $iins_type
        				    AND mcoverage1 = $injured_cover
        				    AND mcoverage2 = $damage_cover
        				    AND mdeduct    = $cal_deduct
        				    AND drate      = (SELECT drate
        				                        FROM ca_rate_date
        				                       WHERE icode  = $frate
        				                         AND itable = 'cover_vs_premium');
					}
        			else if (iins==198)
        			{
        				$SELECT mpremium
        				   INTO $mprem_pure_base
        				   FROM cover_vs_premium
        				  WHERE icar_type  = $cal_car_id
        				    AND iins_type  = $iins_type
        				    AND mcoverage1 = $injured_cover
        				    AND mcoverage2 = $damage_cover
        				    AND mdeduct    = 0
        				    AND drate      = (SELECT drate
        				                        FROM ca_rate_date
        				                       WHERE icode  = $frate
        				                         AND itable = 'cover_vs_premium');
        			}
					else if (iins==237)
					{
						$SELECT mpremium
        				   INTO $mprem_pure_base
        				   FROM cover_vs_premium
        				  WHERE icar_type  = $cal_car_id
        				    AND iins_type  = $iins_type
        				    AND mcoverage1 = $injured_cover
        				    AND mcoverage2 = $damage_cover
        				    AND mdeduct    = 0
        				    AND drate      = (SELECT drate
        				                        FROM ca_rate_date
        				                       WHERE icode  = $frate
        				                         AND itable = 'cover_vs_premium');
					}
        			else if (iins==238)
        			{
        				if (qpro_month < 10)
        				    sprintf(sProYM,"0%d/01/%s",qpro_month,pro_year);
        				else
        				    sprintf(sProYM,"%d/01/%s",qpro_month,pro_year);

        				strcpy(sProYM,cm_from_infdate_100(sProYM));
        				lProYM = cm_ymd_cdate(sProYM);    /* ����~���((y)yy/mm/dd)�নDate(long) */
        				iCar_age=DiffMonth(dply_begin,lProYM);

        				if( iCar_age < 3*12 )        iCar_age = 3;
        				else if( iCar_age < 10*12 )  iCar_age = 10;
        				else if( iCar_age < 15*12 )  iCar_age = 15;
        				else                         iCar_age = 99;

        				iCar_age = qday * 100 + iCar_age;
        				$SELECT a.mpremium
        				   INTO $mprem_pure_base
        				   FROM cover_vs_premium a
        				  WHERE a.icar_type  = $cal_car_id
        				    AND a.iins_type  = $iins_type
        				    AND a.mcoverage1 = $injured_cover
        				    AND a.mcoverage2 = $damage_cover
        				    AND drate        = (SELECT drate
        				                          FROM ca_rate_date
        				                         WHERE icode=$frate
        				                           AND itable='cover_vs_premium')
        				    AND mdeduct      = (select max(mdeduct)
        				                          from cover_vs_premium
        				                         where icar_type = a.icar_type
        				                           and iins_type = a.iins_type
        				                           and mcoverage1 = a.mcoverage1
        				                           and mcoverage2 = a.mcoverage2
        				                           and drate = a.drate
        				                           and mdeduct = $iCar_age
        				                           and ((mdeduct- mod(mdeduct,$qday))/100 = $qday));
        			}
        			else  /**** �I��:50,51,47,52,57,59,60,79,80,89,90 110 112 117  ****/
        			{   /*47,110,117,147,22,57,59,60,53,21,28,128,135,136,55,255,35,48,49,50,160,171,172,252,253*/
        				if (iins==47 || iins==110  || iins==117 || iins==147 || iins==22 )
        				{
        					$long tmp_mcoverage2;

        					if (iins==47 || iins==117 || iins==147){
        						tmp_mcoverage2 = death_cover ;
        					}else{
        						tmp_mcoverage2 = damage_cover ;
        					}

        					$SELECT mpremium
        					   INTO $mprem_pure_base
        					   FROM cover_vs_premium
        					  WHERE icar_type  = $cal_car_id
        					    AND iins_type  = $iins_type
        					    AND mcoverage1 = $injured_cover
        					    AND mcoverage2 = $tmp_mcoverage2
        					    AND mdeduct    = 1
        					    AND drate      = (SELECT drate
        					                        FROM ca_rate_date
        					                       WHERE icode  = $frate
        					                         AND itable = 'cover_vs_premium');

        					if(qply_period > 12)
        					{
        						$SELECT mpremium
        						   INTO $mprem_pure_base
        						   FROM cover_vs_premium
        						  WHERE icar_type  = $cal_car_id
        						    AND iins_type  = $iins_type
        						    AND mcoverage1 = $injured_cover
        						    AND mcoverage2 = $tmp_mcoverage2
        						    AND mdeduct    = 2
        						    AND drate      = (SELECT drate
        						                        FROM ca_rate_date
        						                       WHERE icode  = $frate
        						                         AND itable = 'cover_vs_premium');
        					}
        				}
        				else if (iins==57 || iins==59 || iins==60)
        				{
        					/* ��˯«O�O */
        					$SELECT mpremium
        					   INTO $mpremium_1
        					   FROM cover_vs_premium
        					  WHERE icar_type  = $cal_car_id
        					    AND iins_type  = $iins_type
        					    AND mcoverage1 = $injured_cover
        					    AND mcoverage2 = 0
        					    AND mdeduct    = 0
        					    AND drate      = (SELECT drate
        					                        FROM ca_rate_date
        					                       WHERE icode  = $frate
        					                         AND itable = 'cover_vs_premium');

        					/* ���ݯ«O�O */
        					$SELECT mpremium
        					   INTO $mpremium_2
        					   FROM cover_vs_premium
        					  WHERE icar_type  = $cal_car_id
        					    AND iins_type  = $iins_type
        					    AND mcoverage1 = 0
        					    AND mcoverage2 = $death_cover
        					    AND mdeduct    = 0
        					    AND drate      = (SELECT drate
        					                        FROM ca_rate_date
        					                       WHERE icode  = $frate
        					                         AND itable = 'cover_vs_premium');

        					mprem_pure_base = mpremium_1 + mpremium_2;
        				}
        				else
        				{
        					/*53,21,28,128,135,136,55,255,35,48,49,50,160,171,172,252,253.555 */
        					$SELECT mpremium
        					   INTO $mprem_pure_base
        					   FROM cover_vs_premium
        					  WHERE icar_type  = $cal_car_id
        					    AND iins_type  = $iins_type
        					    AND mcoverage1 = $injured_cover
        					    AND mcoverage2 = $death_cover
        					    AND drate      = (SELECT drate
        					                        FROM ca_rate_date
        					                       WHERE icode  = $frate
        					                         AND itable = 'cover_vs_premium');
        				}
        			}
        		}
        		/******* END : �̫O�B�O�O�ɭp��O�O **********/
        		break;

        		case '3':    /* fcal_way 3:�����O�T�O�v�� */
        		if (iins==58)
        		{   /*** �����O�T ***/ }
        		break;
        	}
        } /* fins=1 END */
        else if (fins == 2)
        {
        	/* �j���I */
        	if (strcmp(trim(cal_car_id),"22") == 0)
        	{
        		if ((strcmp(fassured,"1")==0) || (strcmp(fassured,"3")==0) || (strcmp(fassured,"5")==0))
        		    strcpy(fassured_comp, "1");
        		else
        		    strcpy(fassured_comp, "2");
        	}
        	else strcpy(fassured_comp, " ");

        	if (qply_period <= 12) qply_period = 12;
        	else if (qply_period <= 24) qply_period = 24;
        	else if (qply_period <= 36) qply_period = 36;
        	else if (qply_period <= 48) qply_period = 48;
        	else qply_period = 60;

        	if(strcmp(trim(cal_car_id),"36") == 0) /* �����ج�36�� */
        	{
        		qply_period = 1; /* �ӫO��Ƴ]�w��1 */
        	}

        	$SELECT mpremium
        	   INTO $mprem_pure_base
        	   FROM compulsory_premium
        	  WHERE icar_type = $cal_car_id
        	    AND qperiod   = $qply_period
        	    AND ((qcar_personbgn <= $qpt AND qcar_personend >= $qpt) OR
        	         (qcar_personbgn = 0))
        	    AND drate     = (SELECT drate
        	                       FROM ca_rate_date
        	                      WHERE icode  = $frate
        	                        AND itable = 'compulsory_premium')
        	    AND fassured   = $fassured_comp;
        }

        insert_table:

        $WHENEVER SQLERROR CONTINUE;
        /* �g�J������ */
        if (strcmp(fclass,"1") == 0) strcpy(tbl,"ca_policy_factor_dtl_302");
        else sprintf(tbl,"%s:ca_policy_factor_dtl",tmp_fulldb);

        printf("insert into %s.......... \n",tbl);
        sprintf(stmt_A2,"INSERT INTO %s \n"
                        "(ipolicy, iins_main, iins_type, drate_ym, mprem_pure_base, \n"
                        " coefficient, mins_premium) \n"
                        " VALUES(?,?,?,?,?, ?,?) \n",tbl);

        $PREPARE insert_factor_dtl FROM $stmt_A2;
        $EXECUTE insert_factor_dtl using $ipolicy, $iins_main, $iins_type, $frate, $mprem_pure_base,
                                         $coefficient, $mins_premium;

        return M_CM_OK;

errexit:
    sqlfatal();
    $ROLLBACK WORK;
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car355_check() /* �����n��O��ƶ}��~������ */
{
	$char  yy[4],mm[3],dd[3],dyymm[6],fopen[2];

	$WHENEVER SQLERROR GOTO errexit;

	cm_split_ymd_100(date1,yy,mm,dd);
	sprintf(dyymm, "%s%s",yy,mm);     /* ����~�� */

	$select chiname INTO $fopen
	   from car_code
	  where kind = 'RN' and detail = 'car302'
            and chiname = 'Y' and detail2 = $dyymm;

        if ((SQLCODE == SQLNOTFOUND) || (strcmp(trim(fopen),"Y") != 0))
        {
        	EWRITE(userid, M_CMN_NO_DATA_FOUND, " ��O��Ʃ|���}�� ");
		return M_CMN_NO_DATA_FOUND;
        }

        return M_CM_OK;

errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
static int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
    short mdy1[3], mdy2[3];
    int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
    return datediff;
}
/******************************************************************************/
int IsBlankNull(str)
char *str;
{
    while (*str)
    {
        if (*str!=' ') return FALSE;
        str++;
    }
    return TRUE;
}
/*****************************************************************/