/*******************************
 *
 *   Program : ca413m01s.ec
 *   Author  : Cyrus Tsai
 *   Date    : 08.01.2002
 *   �`�N�Y����L��椣�o���
 *   �����έt����椧�����v�B�N�z�v�B�����v�������s
 *   �g���Ʃ|����J
 ******************************/

#include <stdio.h>
#include <math.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "marmsgs.h"
#include <cmnmsgs.h>
#include "commsgs.h"
#include "carmsgs.h"
#include "carmsg.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
$include sqlca;
$include datetime.h;
$include "ca401lib.h";

$char cDbName[5];
$char cIbrand[7], cIcarType[3];
$char cIbrand1[7], cIcarType1[3];
$dec_t dtPdmgFactor1st, dtPbrgFactor1st, dtPdmgFactor2nd, dtPbrgFactor2nd;
$long lDdate1st, lDdate2nd;
$char stmt[1600];
int iRtnLen;

$char cPdmgFactor1st[9], cPbrgFactor1st[9];
$char cPdmgFactor2nd[9], cPbrgFactor2nd[9];
$char cDdate1st[12], cDdate2nd[12];
$char cNcode[12], cNbrandAbbr[14];

$char cPdmgFactor1st1[9], cPbrgFactor1st1[9];
$char cPdmgFactor2nd1[9], cPbrgFactor2nd1[9];
$char cDdate1st1[12], cDdate2nd1[12];
$char cNcode1[12], cNbrandAbbr1[14];
$char g_option;
char *get_db();
$int qply_period;

char v_sMsg[1512], ipgid[11];

long car413(reply, command, com_len)
serverReply reply;
voidP command;
int com_len;
{
  long rtncode;
  long car413_insert(), car413_delete(), car413_single_query();
  long car413_multiple_query(), car413_update_exec();
  char option;

  strcpy(ipgid, "car413");

  cm_buf_init(command);
  cm_buf_get("%c", &option);
  g_option = option;
  switch (option)
  {
  case 'A':
  case 'U':
    rtncode = car413_insert(reply, option, command, com_len);
    break;
  case 'Q':
    rtncode = car413_single_query(reply);
    break;
  case 'M':
    rtncode = car413_multiple_query(reply);
    break;
  case 'D':
    rtncode = car413_delete(reply, command, com_len, option);
    break;
    /*
    rtncode = car413_update_exec(reply, command, com_len);
    break;
    */

  case 'I':
    rtncode = car413_get_iofficer(reply); /*   ����g��H�Ψ�������   */
    break;

  case 'J':
    rtncode = car413_get_icorps(reply);
    break;

  case '1':
    /*case '4':*/
    rtncode = car413_iofficer(reply);
    break;
  /*case '3':
   rtncode = car413_iquota(reply);
   break;*/
  case '2':
    rtncode = car413_iroute(reply);
    break;
  case '5':
    /* client�ݵ{���w�Qremark */
    rtncode = car413_get_comp(reply);
    break;
  case 'P':
    rtncode = car413_get_ipolicy(reply);
    break;
  case 'C':
    rtncode = car413_get_com_age(reply);
    break;
  case 'R':
    rtncode = car413_get_resource(reply);
    break;
  default:
    return exitsub(reply, M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
  }
  return (rtncode);
} /* car_118 */

$char iextra_charge_new[11], iextra_charge[11];

long car413_insert(reply, option, command, com_len)
serverReply reply;
char option;
voidP command;
int com_len;
{
  long MsgCode;
  long rc;
  int iDbNum, iTmp;
  DBinfo *dbList;
  DBinfo *get_sysdb_list();
  int raw_len;
  char *pos, *raw_ptr, cur_buf[4000];
  char *comm;
  $struct edr_relation p1;
  $struct edr_relation t, *tptr;

  $char ipolicy[21];
  $char sDB[3];
  $char iofficer[11];
  $char iroute[21];
  $char icorps[11];
  $char iquota[7];
  $char ileader[11];
  $char ibroker[11];
  $char iresource[2];
  $char ibig_office[10], ibig_sales[11];
  $char iofficer_prmt[11], ileader_prmt[11], iquota_prmt[7];
  $char ori_fcard_class[2];
  $char ori_iofficer[11];
  $char ori_ibroker[11];
  $char ori_iquota[7];      /* �s�W�ܼƥΨө�m��l�O�檺�~�Z���N��(car9612181) */
  $char iquota_dissolve[7]; /* �Ψө�m�߭t�����~�Z���渹(car9612181) */
  $int ibigflag;
  $int gcom_cnt;
  $int clm_cnt;
  $int diff_iquota, diff_leader;
  $char fedr_class[2];
  char sIbilling[3];
  $char userid[11];
  char sIbranchIcomp[CA_POL_BRH_NUM];
  char sIcomp_in[BRANCH_ID], sIbranch_in[BRANCH_ID];
  char sIcomp_in_short[BRANCH_ID];
  $char temp[POLICY_NUM_1];
  $char temp1[POLICY_NUM_1];
  $date dwritten;
  $char iedr_type1[3];
  $char iedr_type2[3];
  $char stmt[20000];
  /* $char policy_1[21],policy_2[21]; */
  $int ibatch_no;
  char payresult[3], paystatus[32], paydate[11], notedate[11];
  $char fpay[2];
  $char ori_fedr_class[2];
  $long stepi;
  $long fRtnCode;
  $int iedr_cnt, i;
  $char iins_type[7];
  $long minjured_cover, mdeath_cover, mdamage_cover;
  $long mdeduct, mins_premium;
  $long mpure_prem, mdiscount, mprem, mdrunk_prem, mviolate_prem;
  $double mdrunk_pure_prem, mviolate_pure_prem;
  $int qserial;
  $char drate_ym[5];
  $char iproduct[13];
  $char ipaid_base[2];
  $char g_iins_type[7];
  $double g_pcommission, g_pagent;
  $long g_mcommission, g_magent;
  $int ipa_cnt;
  $double pdiscount;
  $char iinsurant[11], iins_scope[2], icareer[2];
  $long mins_amt;
  $char fins_grp[2];
  $long mdmg_commi, mdmg_agent;
  $long mlia_commi, mlia_agent;
  $long mdmg_prem, mlia_prem;
  $long mdmg_discount, mlia_discount;
  $double mdmg_pure_prem, mlia_pure_prem;
  $double mready, mstable, mcompensation, madjcom_prem;
  $double mbusiness;
  $char ibranch_at[3], icomp_at[3];
  $char batchno[4];
  $char sIdir[9];
  $char ibus_location[11];
  $int exist_cnt;
  $double mresearch, minvest, mbus_rule, mcapital, maintain;
  $long qday, mexpense, mexp_disc;
  $char imgr[2];
  $char ori_imgr[2];
  $char fprop[2];
  $char provision[21];
  $int edrrel_qcount;
  $int edrins_qcount, iCount;
  $long mcommi, medrins_prem, mcommission, medr_commission, magent, medr_agent;
  /* ��m��e�q���N�� */
  $char b_iroute[21], ori_iroute[21];

  /* CA_Q */
  char policy_1[POLICY_NUM_1], policy_2[POLICY_NUM_2];
  char presult[11], pdesc[51], ibroker_expire[2];
  char sMcommission[21], sMagent[21], sMcommission1[21], sMagent1[21];
  char sPcommission[21], sPagent[21], sPcommission1[21], sPagent1[21];
  char sMdmg_commi[21], sMlia_commi[21], sMdmg_agent[21], sMlia_agent[21];
  char sMdmg_commi1[21], sMlia_commi1[21], sMdmg_agent1[21], sMlia_agent1[21];
  $char sIpolicy[21], sIendorse[21];
  $double pbusiness_new, pdiscount_new, pextra_charge_new;
  $double pbusiness, pextra_charge;
  $char sCCC1[101], sCCC2[101], sCCC3[101], f980401[2];
  double rCCC1, rCCC2, rCCC3;

  $char iabn_type[2], comp_frate[6];

  $char opt[2], insure_type[2];
  $char irate_type[2], bzfrom[3], iroute_comm[4], icomm_obj[11], ori_icomm_obj[11], ibig_comp[2];
  int v_iins;
  $char dcreate_max[31], dcreate_max_new[31];
  $char dlock[31], iroute_accept_edr[21], ireg_no[21];

  $WHENEVER SQLERROR GOTO errexit;

  qday = 0;
  mexpense = 0;
  mexp_disc = 0;

  edrrel_qcount = 0;
  edrins_qcount = 0;

  strcpy(iofficer_prmt, " ");
  strcpy(iquota_prmt, " ");
  strcpy(ileader_prmt, " ");

  cm_buf_get("%s", cDbName);
  cm_buf_get("%s", userid);
  cm_buf_get("%s", ipolicy);

  printf("ipolicy[%s]\n", ipolicy);
  if (db_select(cDbName) == False)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  /* get ���B�z������c & �����q*/
  $SELECT idir
      INTO $sIdir
          FROM user
              WHERE iemp = $userid;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }

  printf("int cm_get_unit_at: idir[%s]\n", sIdir);
  strncpy(ibranch_at, sIdir, BRANCH_ID - 1);
  ibranch_at[BRANCH_ID - 1] = '\0';
  printf("ibranch_at[%s]\n", ibranch_at);

  $SELECT iupcomp
      INTO $icomp_at
          FROM sa_branch_type
              WHERE ibranch = $sIdir;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }
  printf("icomp_at[%s]\n", icomp_at);
  strcpy(sDB, get_db(ipolicy));

  if (strncmp(sDB, "100", 3) == 0)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }

  if (db_select(sDB) == False)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  $SELECT COUNT(*)
      INTO $iCount
          FROM edr_relation
              WHERE ipolicy = $ipolicy
                  AND iendorse not like '%CVP%' AND dedr_close is null;

  /* �]�g����|�w�惡�O��Ҧ��O��榬�O���A�����P�B�z,�]�������Ҧ����Ҥw�鵲,�~�i�g����  */
  if (iCount != 0) /* ���O��|����楼�鵲,�ݤ鵲��j�ѦA��� */
  {
    if (exitsub(reply, M_CA_EDR_NO_CLOSE) == True)
      return M_CA_EDR_NO_CLOSE;
    else
      return apiRC;
  }

  rtoday(&dwritten);
  cm_buf_get("%s", fedr_class);
  cm_buf_get("%s %s %s %s %s %s %s %s %s %s",
             iofficer, iroute, icorps, iquota, ileader, ibroker, iresource, ibig_office, ibig_sales, iofficer_prmt);
  cm_buf_get("%s %s %s %s %s", icomm_obj, iroute_comm, irate_type, bzfrom, ireg_no);
  cm_buf_get("%s ", dcreate_max);

  $select max(dcreate)
      into $dcreate_max_new
          from edr_relation
              where ipolicy = $ipolicy and iendorse not like '%CVP%';

  strcpy(dcreate_max, trim(dcreate_max));
  strcpy(dcreate_max_new, trim(dcreate_max_new));

  printf("[%s] dcreate_max\n", dcreate_max);
  printf("[%s] dcreate_max_new\n", dcreate_max_new);

  if (strcmp(dcreate_max, dcreate_max_new) != 0)
  {
    if (exitsub(reply, M_CA_CHANGE_PLY) == True)
      return M_CA_CHANGE_PLY;
    else
      return apiRC;
  }

  if (fedr_class[0] == 'A')
  {
    strcpy(iedr_type1, "80");
    strcpy(iedr_type2, "81");
  }
  else
  {
    strcpy(iedr_type1, "82");
    strcpy(iedr_type2, "83");
  }

  /* 1000311003 �q��2 */
  /* �~�Z���O�_���� */
  strcpy(opt, "2");
  strcpy(insure_type, "C");
  rc = cm_chk_policy(opt, iofficer, ileader, iquota, icomm_obj, insure_type, iroute, "");
  if (rc != M_CM_OK)
  {
    if (exitsub(reply, rc) == True)
      return rc;
    else
      return apiRC;
  }

  $SELECT fcard_class, iofficer, ibroker, ibatch_no, fedr_class, mdmg_commi + mlia_commi, iextra_charge, iroute, icomm_obj, qply_period, a.dlock INTO $ori_fcard_class, $ori_iofficer, $ori_ibroker, $ibatch_no, $ori_fedr_class, $mcommi, $iextra_charge, $ori_iroute, $ori_icomm_obj, $qply_period,
      $dlock
          FROM ply_relation a,
      policy b
          WHERE a.ipolicy = b.ipolicy
                                AND a.ipolicy = $ipolicy;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }

  if (strlen(trim(dlock)) != 0) /* ���O��B2C��襤�A�ȮɵL�k��� */
  {
    if (exitsub(reply, M_CA_PLY_LOCK) == True)
      return M_CA_PLY_LOCK;
    else
      return apiRC;
  }

  if (ori_fcard_class[0] == '2')
  {
    strcpy(iextra_charge_new, bzfrom);
    /* �����g���H���������[�O�βv�N�� */
  }
  else
    strcpy(iextra_charge_new, " ");

  if (ori_fedr_class[0] == '1')
  {
    if (mcommi == 0)
    {
      if (exitsub(reply, M_CA_PLY_CANCEL) == True)
        return M_CA_PLY_CANCEL;
      else
        return apiRC;
    }
  }

  /* bis9901141 �Y�O��O��q���N������,�N�����ϥ�client�Ǧ^�Ӫ����q���N�� */
  if (strlen(trim(ori_iroute)) == 0)
    strcpy(b_iroute, iroute);
  else
    strcpy(b_iroute, ori_iroute);

  /***   ���o��~���I�N��   ***/
  $SELECT imgr, fprop, ibigcomp INTO $imgr, $fprop, $ibig_comp FROM officer WHERE iofficer = $iofficer;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }

  if (imgr[0] == '1')
  {
    if ((fedr_class[0] != 'A') || (fprop[0] == 'E'))
    {
      $SELECT ibig_office
          INTO $ibus_location
              FROM ply_relation
                  WHERE ipolicy = $ipolicy;
      if (SQLCODE == SQLNOTFOUND)
      {
        if (exitsub(reply, M_CM_NOT_FOUND) == True)
          return M_CM_NOT_FOUND;
        else
          return apiRC;
      }
    }
    else
    {
      $SELECT ibus_location
          INTO $ibus_location
              FROM officer
                  WHERE iofficer = $iofficer;
      if (SQLCODE == SQLNOTFOUND)
      {
        if (exitsub(reply, M_CM_NOT_FOUND) == True)
          return M_CM_NOT_FOUND;
        else
          return apiRC;
      }
    }
  }
  else
  {
    $SELECT ibig_office
        INTO $ibus_location
            FROM ply_relation
                WHERE ipolicy = $ipolicy;
    if (SQLCODE == SQLNOTFOUND)
    {
      if (exitsub(reply, M_CM_NOT_FOUND) == True)
        return M_CM_NOT_FOUND;
      else
        return apiRC;
    }
  }

  strcpy(ibroker, trim(ibroker));
  strcpy(ori_ibroker, trim(ori_ibroker));
  strcpy(ori_icomm_obj, trim(ori_icomm_obj));
  clm_cnt = 0;
  gcom_cnt = 0;
  diff_iquota = 0;
  diff_leader = 0;
  iedr_cnt = 0;
  ipa_cnt = 0;
  i = 0;
  minjured_cover = mdeath_cover = mdamage_cover = 0;
  mdeduct = mins_premium = 0;
  g_pcommission = g_pagent = 0;
  g_mcommission = g_magent = 0;
  pdiscount = 0;
  mins_amt = 0;
  mdmg_commi = mdmg_agent = 0;
  mlia_commi = mlia_agent = 0;
  mdmg_prem = mlia_prem = 0;
  mdmg_discount = mlia_discount = 0;
  mdmg_pure_prem = mlia_pure_prem = 0;
  mready = mstable = mcompensation = madjcom_prem = 0;
  mbusiness = 0;
  mresearch = minvest = mbus_rule = mcapital = maintain = 0;

  ibigflag = 0; /* �@��� */

  $SELECT imgr
      INTO $ori_imgr
          FROM officer
              WHERE iofficer = $ori_iofficer;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }

  if (ori_imgr[0] == '1')
  {
    ibigflag = 1; /* �O�N�� */
  }
  policy_1[0] = '\0';
  policy_2[0] = '\0';

  strncpy(policy_1, ipolicy, CAR_POLICY_LEN);
  policy_1[CAR_POLICY_LEN] = 0;

  if (strlen(ipolicy) > CAR_POLICY_LEN)
    strcpy(policy_2, &ipolicy[CAR_POLICY_LEN]);
  else
    strcpy(policy_2, " ");

  strcpy(ibroker_expire, "N");

  /* �I����H�O�_����O */
  strcpy(opt, "5");
  rc = cm_chk_policy(opt, "", "", "", icomm_obj, "", "", "");

  if (rc == M_CMN_COMM_OBJ_EXPIRE) /* �I����H����O */
  {
    strcpy(ibroker_expire, "Y");

    printf("before ao_chk_dpay_all =====> presult[%s]\n", presult);

    rc = ao_chk_dpay_all(policy_1, policy_2, presult, pdesc);
    if (rc != TRUE)
    {
      if (exitsub(reply, rc) == True)
        return rc;
      else
        return apiRC;
    }

    printf("after  ao_chk_dpay_all =====> presult[%s]\n", presult);

    /* presult      pdesc           */
    /* �סססססססססססס�   */
    /* X            �����~;         */
    /* P1           ���������h�O;   */
    /* P2           �����w���h�O;   */
    /* P3           ���h�O������;   */
  }
  else if (rc != M_CM_OK)
  {
    if (exitsub(reply, rc) == True)
      return rc;
    else
      return apiRC;
  }

  /* �����ˮֱ��� */
  exist_cnt = 0;
  $SELECT count(*)
      INTO $exist_cnt
          FROM edr_relation
              WHERE ipolicy = $ipolicy
                  AND fedr_class in('A', 'B')
                      AND date(dcreate) = $dwritten;

  if (exist_cnt != 0 && ibroker_expire[0] == 'N') /* �g���N�����έn�i�H�� */
  {
    if (exitsub(reply, M_CA_EXIST_ENDOR) == True)
      return M_CA_EXIST_ENDOR;
    else
      return apiRC;
  }

  /* �ˮ֤����g��N�����(fedr_class[0] == 'A') �H�Φ������(fedr_class[0] == 'B' */
  /* �g����ϥηs�ˮ�(car9612181),�������ϥ��¦����ˮ� */
  /* �s�º޲z�H�O�_�ۦP,���P�h�bclient�|��ܴ��ܰT��,server�ݤ��B�z */
  /* ��l�g���H�N���O�_����,�����Ϋh�|�bclient��ܴ��ܰT���T�{�O�_���,server�ݤ��B�z */
  if (fedr_class[0] == 'A')
  {
    /* ��l�O��P���~�Z�k�ݳ��O�_�ۦP */
    $SELECT count(*)
        INTO $diff_iquota
            FROM ori_ply_relation a,
        edr_relation b
            WHERE a.ipolicy = b.ipolicy
                                  AND a.iquota[1, 4] != b.iquota[1, 4] AND a.ipolicy = $ipolicy;
    if (diff_iquota != 0)
    {
      /* ���o�~�Z�k�ݳ��O�_���M */
      $SELECT iquota INTO $ori_iquota
          FROM ori_ply_relation
              WHERE ipolicy = $ipolicy;

      rc = chk_iquota_expire(ori_iquota, v_sMsg);
      if (rc == M_CM_OK) /* ��l�O��~�Z��쥼���M���o���; M_CM_OK=��쥼���M */
      {
        /* 1060816001_C1 car413������g��N���ˮ֨���
        if(exitsub(reply,M_CA_DISSOLVE_IQUOTA) == True )
             return M_CA_DISSOLVE_IQUOTA;
        else
             return apiRC;
        */
      }
    }
  }
  else
  {
    /* �������@�P�ˮ��޿� */
    /* 1. ��l�O��P���~�Z��줣�P������ */
    /* 2. ��l�O��P���޲z�H���P������ */
    /* ��l�O�椧�~�Z���P��椧�~�Z��줣�P�����\��� */
    $SELECT count(*)
        INTO $diff_iquota
            FROM ori_ply_relation a,
        edr_relation b
            WHERE a.ipolicy = b.ipolicy
                                  AND a.iquota[1, 4] != b.iquota[1, 4] AND a.ipolicy = $ipolicy;
    if (diff_iquota != 0)
    {
      if (exitsub(reply, M_CA_DIFF_QUOTA) == True)
        return M_CA_DIFF_QUOTA;
      else
        return apiRC;
    }

    /* ��l�O�椧�޲z�H�P��椧�޲z�H���P�����\��� */
    $SELECT count(*)
        INTO $diff_leader
            FROM ori_ply_relation a,
        edr_relation b
            WHERE a.ipolicy = b.ipolicy
                                  AND a.ileader != b.ileader
                                                       AND a.ipolicy = $ipolicy
                                                                           AND b.fedr_class != 'A';
    if (diff_leader != 0 && ibroker_expire[0] == 'N')
    {
      if (exitsub(reply, M_CA_DIFF_LEADER) == True)
        return M_CA_DIFF_LEADER;
      else
        return apiRC;
    }

#if 0
          /* �������Y���@����,�h�[�ˮ֧��e�᪺�g���H�ݬۦP,�_�h�����\��� */          
      	 if (ibigflag == 0)
      	 {
      	 	   if (ori_fcard_class[0] == '2')
      	 	   {
      	 	        if (strcmp(ori_ibroker,ibroker) != 0)
                    {
                          if(exitsub(reply,M_CA_BROKER_CHG) == True )
                             return M_CA_BROKER_CHG;
                          else
                             return apiRC;
                     }
               } else {
            	      /* �Y���@���j���I��,�h�[�P�_�O�_���ΥH�Τ���O�O�_�J�p */
            	     if (strcmp(ori_ibroker,ibroker) != 0 && ibroker_expire[0] == 'N')
                    {
                          $SELECT count(*)
                             INTO $gcom_cnt
                             FROM ao_officer_commit
                            WHERE fstatus not in ('N','F')
                              AND ipolicy1 = $ipolicy;
                          if (gcom_cnt != 0)
                          {
                               if(exitsub(reply,M_CA_BROKER_GROUP) == True )
                                   return M_CA_BROKER_GROUP;
                               else
                                   return apiRC;
                          }
                     }
               }
            }
#endif
  } /* �g��N���H�Φ��������󵲧� */
    /*  �����ˮ֧@�~  */

  /* �P�_�t��������ߦb���ӷ~�Z��� */
  /* �p�G�g���H����,�h�t���ߦb��᪺�s�~�Z��� */
  /* �p�G�g���H������,�B�����M,�h�t���ߦb��e�g��N�����ݤ��̷s�~�Z��� */
  $SELECT iquota INTO $iquota_dissolve
      FROM ply_relation
          WHERE ipolicy = $ipolicy;

  rc = chk_iquota_expire(iquota_dissolve, v_sMsg);

  if (ibroker_expire[0] == 'Y')
  {
    printf("iquota remains!!\n");
    strcpy(iquota_dissolve, iquota);
  }
  else
  {
    if (rc == M_SA_DEXP) /* �P�_��e�̷s�O��~�Z��쥼���M; M_CM_OK=��쥼���M */
    {
      printf("�g���H�����Φ������M\n");
      /* �g���H�����Φ������M,�t���ߦb��e�g��N�����ݤ��̷s�~�Z��� */
      $SELECT a.iquota INTO $iquota_dissolve
          FROM officer a,
          ply_relation b
              WHERE a.iofficer = b.iofficer
                                     AND b.ipolicy = $ipolicy;

      if (SQLCODE == SQLNOTFOUND)
      {
        if (exitsub(reply, M_CMN_NBRANCH_OFF) == True)
          return M_CMN_NBRANCH_OFF;
        else
          return apiRC;
      }
    }
    else if (rc != M_CM_OK)
    {
      $WHENEVER SQLERROR CONTINUE;
      exitsub(reply, rc);
      return stepi;
    }
    else
    {
      /*strcpy(iquota_dissolve,iquota);*/
      printf("�g���H�N��������,�~�Z���]�����M,�����e���޿�,�t���b�³��,�����b�s���\n");
    }
  }

  /* �ˬdiquota_dissolve(�t���~�Z���)�O�_����,�Y���Ϋh����� */
  rc = chk_iquota_expire(iquota_dissolve, v_sMsg);
  printf("�t���~�Z���[%s]\n", iquota_dissolve);
  if (rc == M_SA_DEXP) /* M_SA_DEXP�~�Z��찱�� */
  {
    if (exitsub(reply, M_CA_IQUOTA_EXPIRE) == True)
      return M_CA_IQUOTA_EXPIRE;
    else
      return apiRC;
  }

  /* get ���s�X���O*/
  strncpy(sIbilling, ipolicy + CAR_POL_CHR_POS - 1, 2);
  sIbilling[2] = '\0';
  printf("sIbilling[%s]\n", sIbilling);
  /* get ����k�ݤ�����c & �����q*/
  strncpy(sIbranchIcomp, ipolicy, CA_POL_BRH_NUM - 1);
  sIbranchIcomp[CA_POL_BRH_NUM - 1] = '\0';
  printf("sIbranchIcomp[%s]\n", sIbranchIcomp);

  fRtnCode = cm_get_unit_in("", sIbranchIcomp, userid,
                            sIbranchIcomp, "C1", sIcomp_in, sIbranch_in);
  if (fRtnCode != M_CM_OK)
    return exitsub(reply, fRtnCode) ? fRtnCode : apiRC;

  strcpy(sIcomp_in_short, get_upcomp(sIcomp_in, USE_BRANCH_ID, USE_SHORT_BRANCH_ID));

  /* bis9901141 �Y�OW�}�Y���g��N��,�ݭn���o�^�k�᪺�޲z�H�η~�Z����J��楿�V */
  printf("iofficer[%s]\n", iofficer);
  if (iofficer[0] == 'W' || (iofficer[0] == 'H' && iofficer[1] != '0' && iofficer[1] != '1' && iofficer[1] != '2') || iofficer[0] == 'N')
  {
    $SELECT ileader, iquota INTO $ileader_prmt, $iquota_prmt FROM officer WHERE iofficer = $iofficer_prmt;
    if (SQLCODE == SQLNOTFOUND)
    {
      if (exitsub(reply, M_CMN_NOFFICER) == True)
        return M_CMN_NOFFICER;
      else
        return apiRC;
    }
  }
  printf("iofficer[%s]\n", iofficer);
  /* end of bis9901141 */

  $BEGIN WORK;

  /***  �}�l�t���@�~  ***/
  stepi = cm_get_serial_num("C4", sIbilling,
                            sIcomp_in_short, sIbranch_in,
                            cm_cdate_str_100(cm_today()),
                            temp);
  if (stepi != 0)
  {
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if (stepi == 1 || stepi == 2)
      stepi = M_CM_DB_NOTOPEN;
    else if (stepi == 3)
      stepi = M_CMN_NAUTONUMBERING;
    exitsub(reply, stepi);
    return stepi;
  }
  $WHENEVER SQLERROR goto errexit;

  printf("temp[%s]\n", temp);

  stepi = cm_get_serial_num("C4", sIbilling,
                            sIcomp_in_short, sIbranch_in,
                            cm_cdate_str_100(cm_today()),
                            temp1);
  if (stepi != 0)
  {
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if (stepi == 1 || stepi == 2)
      stepi = M_CM_DB_NOTOPEN;
    else if (stepi == 3)
      stepi = M_CMN_NAUTONUMBERING;
    exitsub(reply, stepi);
    return stepi;
  }
  printf("temp1[%s]\n", temp1);

  printf("END get number\n");

  policy_1[0] = '\0';
  policy_2[0] = '\0';

  strncpy(policy_1, ipolicy, CAR_POLICY_LEN);
  policy_1[CAR_POLICY_LEN] = 0;

  printf("END ipolicy split \n");

  if (strlen(ipolicy) > CAR_POLICY_LEN)
    strcpy(policy_2, &ipolicy[CAR_POLICY_LEN]);
  else
    strcpy(policy_2, " ");

  printf("policy_1[%s]\n", policy_1);
  printf("policy_2[%s]\n", policy_2);
  printf("ibatch_no[%d]\n", ibatch_no);
  printf("sDB[%s]\n", sDB);

  strcpy(batchno, itoa(ibatch_no));
  printf("batchno[%s]\n", batchno);

  /* get ���O���A */
  rc = ao_chk_charge(sDB, '3', policy_1, policy_2, batchno,
                     payresult, paystatus, paydate, notedate);
  printf("rc[%d]\n", rc);
  if (rc != TRUE)
  {
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if (exitsub(reply, rc) == True)
      return rc;
    else
      return apiRC;
  }
  printf("ipolicy[%s],payresult[%s],ibroker_expire[%s]\n", ipolicy, payresult, ibroker_expire);

  if (payresult[0] == 'R')
  {
    strcpy(fpay, " ");
  }
  else
  {
    strcpy(fpay, "1");
  }

  sprintf(stmt,
          " SELECT fins_grp           \
          FROM insurance_type     \
         WHERE iins_type = ? ");
  $PREPARE surid FROM $stmt;

  /* CA_Q */
  if (ibroker_expire[0] == 'Y') /* �g���N������O */
  {
    /* P2�����w���O,P3�������O,else�������� */
    if (strncmp(presult, "P2", 2) == 0) /* �����w���X�@�t�@�����A�����ߦ� */
    {
      strcpy(sMcommission, "0"); /* �@�t�@�����Ҭ�0 */
      strcpy(sMagent, "0");      /* �@�t�@�����Ҭ�0 */
      strcpy(sPcommission, "0"); /* �@�t�@�����Ҭ�0 */
      strcpy(sPagent, "0");      /* �@�t�@�����Ҭ�0 */
      strcpy(sMdmg_commi, "0");  /* �@�t�@�����Ҭ�0 */
      strcpy(sMlia_commi, "0");  /* �@�t�@�����Ҭ�0 */
      strcpy(sMdmg_agent, "0");  /* �@�t�@�����Ҭ�0 */
      strcpy(sMlia_agent, "0");  /* �@�t�@�����Ҭ�0 */

      /* �t�V��氵����update�̷s�O�欰0 */
      strcpy(sMcommission1, "0");
      strcpy(sMagent1, "0");
      strcpy(sPcommission1, "0");
      strcpy(sPagent1, "0");
      strcpy(sMdmg_commi1, "0");
      strcpy(sMlia_commi1, "0");
      strcpy(sMdmg_agent1, "0");
      strcpy(sMlia_agent1, "0");
    }
    else if (strncmp(presult, "P3", 2) == 0) /* ���O�������X�@�t�@�����A�ݥߦ�,�u�������O�O���X�p�X��� */
    {
      /* �g���N���w�g���ΥB���O������ */
      $WHENEVER SQLERROR goto errexit;

      rc = insert_edr(sDB, ipolicy, policy_1, policy_2, temp, temp1, fpay, fedr_class,
                      iedr_type1, iedr_type2, iresource, ibig_office, ibig_sales, ori_ibroker,
                      ibroker, iofficer, iroute, ileader, icorps, iquota, iquota_dissolve,
                      ibus_location, userid, icomp_at, ibranch_at, dwritten, ori_fcard_class,
                      iofficer_prmt, iquota_prmt, ileader_prmt, b_iroute, irate_type, bzfrom, iroute_comm, icomm_obj, ibig_comp, ireg_no, reply);
      if (rc != M_CM_OK)
      {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        if (exitsub(reply, rc) == True)
          return rc;
        else
          return apiRC;
      }
      else
      {
        cm_buf_init(ReplyBuf);
        cm_buf_put("%l %s %s", M_CM_OK, temp, temp1);
        iRtnLen = cm_buf_len(ReplyBuf);

        if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          return apiRC;
        }
        $COMMIT WORK;
        return api_OKComplete;
      }
    }
    else /* �������� */
    {
      /* ����B�J�G
         1.�t�V���̷߳s�O��t��,
         2.update�̷s�O��s�������v��
         3.�A�����V���̷߳s�O�楿�� */
      strcpy(sMcommission, "mcommission");
      strcpy(sMagent, "magent");
      strcpy(sPcommission, "pcommission");
      strcpy(sPagent, "pagent");
      strcpy(sMdmg_commi, "mdmg_commi");
      strcpy(sMlia_commi, "mlia_commi");
      strcpy(sMdmg_agent, "mdmg_agent");
      strcpy(sMlia_agent, "mlia_agent");

      /* �t�V��氵����update�̷s�O�欰0 */
      strcpy(sMcommission1, "0");
      strcpy(sMagent1, "0");
      strcpy(sPcommission1, "0");
      strcpy(sPagent1, "0");
      strcpy(sMdmg_commi1, "0");
      strcpy(sMlia_commi1, "0");
      strcpy(sMdmg_agent1, "0");
      strcpy(sMlia_agent1, "0");
    }
  }
  else
  {
    /* ����B�J�G
       1.�t�V���̷߳s�O��t��,
       2.update�̷s�O��s�������v��
       3.�A�����V���̷߳s�O�楿�� */

    strcpy(sMcommission, "mcommission");
    strcpy(sMagent, "magent");
    strcpy(sPcommission, "pcommission");
    strcpy(sPagent, "pagent");
    strcpy(sMdmg_commi, "mdmg_commi");
    strcpy(sMlia_commi, "mlia_commi");
    strcpy(sMdmg_agent, "mdmg_agent");
    strcpy(sMlia_agent, "mlia_agent");

    /* �t�V��氵����update�̷s�O�欰0 */
    strcpy(sMcommission1, "0");
    strcpy(sMagent1, "0");
    strcpy(sPcommission1, "0");
    strcpy(sPagent1, "0");
    strcpy(sMdmg_commi1, "0");
    strcpy(sMlia_commi1, "0");
    strcpy(sMdmg_agent1, "0");
    strcpy(sMlia_agent1, "0");
  }

  /* ���J�g���N��0�}�Y��,�N�z�O����,�ѩ��᪺�g���N���|�̷Ӧ����N�z�v�ɧ�̷s���,�ҥH�����L�ݳB�z */
  /* Modified by Julia in 2008/04/22 */
  printf("ori_ibroker[%s],ibroker[%s]\n", ori_ibroker, ibroker);
  if (ori_ibroker[0] == '0')
  {
    strcpy(sMagent, "0");
    strcpy(sMdmg_agent, "0");
    strcpy(sMlia_agent, "0");
  }
  /* end of �g���N����0�}�Y�N�z�O�B�z */

  /**** START �t���e�ƥ� ****/
  rc = bk_401(sDB, ipolicy, temp);
  if (rc != M_CM_OK)
  {
    SQLCODE = rc;
    goto errexit;
  }
  /**** END   �t���e�ƥ� ****/
  printf("END bk401\n");

  /**** START �B�z�t���I���� ****/
  if (fedr_class[0] == 'A')
  {
    edrrel_qcount = -1;
    edrins_qcount = -1;
  }
  else
  {
    edrrel_qcount = 0;
    edrins_qcount = 0;
  }

  stmt[0] = '\0';
  sprintf(stmt,
          " INSERT INTO edr_ins_type                                            \
         (iendorse, iins_type, iedr_type, medrinj_cover, medrdea_cover,      \
          medrdmg_cover, mdeduct, medrins_prem, medrpure_prem, fcal_way,     \
          pcal, qserial, pcommission, medr_commission, pagent, medr_agent,   \
          pdiscount, medr_discount, drate_ym, medr_prem, iproduct,     \
          ipaid_base, qday, medr_expense, medr_exp_disc, qcount, provision, psex_age, \
          mdrunk_prem, mdrunk_pure_prem, mviolate_prem, mviolate_pure_prem)  \
          SELECT '%s', iins_type, '%s',                                      \
                 minjured_cover * (-1), mdeath_cover * (-1),                 \
                 mdamage_cover * (-1), mdeduct * (-1),                       \
                 mins_premium * (-1), mpure_prem * (-1),                     \
                 'M', 100, qserial, %s * (-1), %s * (-1),           \
                 %s * (-1), %s * (-1), pdiscount * (-1), mdiscount * (-1), \
                 drate_ym, mprem * (-1), iproduct, ipaid_base,               \
                 qday, mexpense * (-1), mexp_disc * (-1), %ld, provision, psex_age, \
                 mdrunk_prem*(-1), mdrunk_pure_prem*(-1), mviolate_prem*(-1), mviolate_pure_prem*(-1) \
            FROM ply_ins_type                                                \
           WHERE ipolicy = '%s' ",
          temp, iedr_type1, sPcommission, sMcommission, sPagent, sMagent, edrins_qcount, ipolicy);
  printf("stmt[%s]\n", stmt);
  $PREPARE eins1 FROM $stmt;
  $EXECUTE eins1;

  stmt[0] = '\0';
  sprintf(stmt,
          " INSERT INTO ca_pa_edr                                               \
        (iendorse, iins_type, iinsurant, iedr_type, ninsurant, dbirth,      \
         ainsurant, iins_scope, icareer, medrins_amt, fcal_way,             \
         pcal, medrins_prem, medrpure_prem, pcommission,                    \
         medr_commission, pagent, medr_agent, pdiscount,                    \
         medr_discount, dendorse, napplicant, relation_appl,                \
         nbeneficiary,relation_bene,tbenef, abenef_zip, abenef)             \
        SELECT '%s', iins_type, iinsurant, '%s', ninsurant, dbirth,         \
               ainsurant, iins_scope, icareer, mins_amt * (-1), 'M',        \
               100, mins_premium * (-1), mpure_prem * (-1), %s,             \
               %s * (-1), %s, %s * (-1), 0,                                 \
               mdiscount * (-1), %ld, napplicant, relation_appl,            \
               nbeneficiary,relation_bene,tbenef, abenef_zip, abenef        \
          FROM ca_pa_ply                                                    \
         WHERE ipolicy = '%s' ",
          temp, iedr_type1, sPcommission, sMcommission, sPagent, sMagent, dwritten, ipolicy);
  printf("stmt[%s]\n", stmt);
  $PREPARE caedr1 FROM $stmt;
  $EXECUTE caedr1;

  sprintf(stmt,
          " UPDATE ply_ins_type                                        \
           SET (minjured_cover,mdeath_cover,mdamage_cover,mdeduct, \
                mins_premium,iendorse,pcommission,                 \
                mcommission,pagent,magent,pdiscount,mdiscount,mprem, \
                mpure_prem,qday,mexpense,mexp_disc,mdrunk_prem,mdrunk_pure_prem, \
                mviolate_prem , mviolate_pure_prem)  \
             = (0,0,0,0,0,'%s', %s, %s, %s, %s,0,0,0,0,0,0,0,0,0,0,0) \
         WHERE ipolicy = '%s' ",
          temp, sPcommission1, sMcommission1, sPagent1, sMagent1, ipolicy);
  printf("stmt[%s]\n", stmt);
  $PREPARE pins1 FROM $stmt;
  $EXECUTE pins1;

  sprintf(stmt,
          " UPDATE ca_pa_ply                                                               \
           SET (mins_amt, mins_premium, mpure_prem, pcommission, mcommission,          \
                pagent, magent, pdiscount, mdiscount, iendorse)                        \
             = (0,0,0,%s,%s,%s,%s,0,0,'%s')                                              \
         WHERE ipolicy = '%s' ",
          sPcommission1, sMcommission1, sPagent1, sMagent1, temp, ipolicy);
  printf("stmt[%s]\n", stmt);
  $PREPARE cains1 FROM $stmt;
  $EXECUTE cains1;

  /**** END �B�z�t���I���� ****/

  /**** START �B�z�t���D�� ****/
  sprintf(stmt,
          " INSERT INTO edr_relation \
        (iendorse, fcard_class, ipolicy, icard, irelative_ply, irelative_edr, \
         fedr_class, fpay, ipay, iedr_field, dedr_begin, dedr_end, \
         ipro_year, ibrand, icar_type, medrdmg_agent, medrdmg_commi, \
         medrdmg_prem, medrdmg_pure_prem, medrlia_agent, medrlia_commi, \
         medrlia_prem, medrlia_pure_prem, ibig_comp, ibig_branch, ibig_office, \
         ibig_sales, iresource, ibroker, iofficer, ileader, icorps, iedr_area, \
         iedr_cashier, iedr_examiner, dedr_examine, dentry, dendorse, \
         fprint, itreaty, ibranch, iquota, icomp_in, ibranch_in, icomp_at, \
         ibranch_at, medr_ready, medr_stable, medr_compensate, medr_adjcom, \
         medr_research, medr_invest, medr_bus_rule, medr_business, \
         medr_capital, medr_maintain, fcomp_class, fcomp_class_last, fdiscount, medrdmg_disc,   \
         medrlia_disc, iedr_return, icar_flag, terminate_rsn, qcount, \
         iofficer_prmt, iquota_prmt, ileader_prmt, irate_type, bzfrom, iroute_comm, icomm_obj, qprovision, isecond_hand, icard_main, qdrunk_driving, isign, \
         feply, feedr, aemail_eply,tmobile_eply,ireg_no,isign_edr,dsign_edr,fsign_status_edr,funder_chk_edr,iprog,qviolate)  \
        SELECT '%s', fcard_class, ipolicy, icard, irelative_ply, ' ', \
         '%s', '%s', ' ', ' ', dply_begin, dply_end, \
         ipro_year, ibrand, icar_type, %s * (-1), %s * (-1), \
         mdmg_prem * (-1), mdmg_pure_prem * (-1), %s * (-1), %s * (-1), \
         mlia_prem * (-1), mlia_pure_prem * (-1), ibig_comp, ibig_branch, ibig_office, \
         ibig_sales, iresource, ibroker, iofficer, ileader, icorps, iarea, \
         '%s', '%s', %ld, %ld, '', \
          1, itreaty, ibranch, '%s', icomp_in, ibranch_in,    '%s' , \
               '%s' , mready * (-1), mstable * (-1), mcompensation * (-1), madjcom_prem * (-1), \
          mresearch * (-1), minvest * (-1), mbus_rule * (-1), mbusiness * (-1), \
          mcapital * (-1), maintain * (-1), fcomp_class, fcomp_class_last, fdiscount, mdmg_discount * (-1), \
          mlia_discount * (-1), '0', icar_flag, '0', %ld, \
          iofficer_prmt, iquota_prmt, ileader_prmt, irate_type, bzfrom, iroute_comm, icomm_obj, qprovision, isecond_hand, icard_main, qdrunk_driving, isign, \
          feply, '0', aemail_eply, tmobile_eply, '%s','system',today,40,'N','car413',qviolate  \
          FROM ply_relation \
         WHERE ipolicy = '%s' ",
          temp, fedr_class, fpay, sMdmg_agent, sMdmg_commi, sMlia_agent, sMlia_commi, userid, userid,
          dwritten, dwritten, iquota_dissolve, icomp_at, ibranch_at, edrrel_qcount, ireg_no, ipolicy);
  printf("stmt[%s]\n", stmt);
  $PREPARE edr1 FROM $stmt;
  $EXECUTE edr1;

  /**** START �B�z�t���򥻸���� ****/

  /*1071105008_SC2_ �������Ȩ��z��(FS)�A�éw�ɦ۰ʤU���ɮ�*/
  strcpy(iroute_accept_edr, " ");
  if (strncmp(b_iroute, "I009", 4) == 0)
  {
    strcpy(temp, trim(temp));
    sprintf(iroute_accept_edr, "CHB%s", temp);
  }
  printf("-- trace iroute_accept_edr[%s]\n ", iroute_accept_edr);

  sprintf(stmt,
          " INSERT INTO endorsement                                                               \
        (iendorse, qply_period, dply_begin, dply_end, fassured, iassured,                     \
         iassured_ext, nassured, ilicense, fsex, fmarriage, nuser,                            \
         ibenef, nbenef, aassured, aassured_zip, itel, apayment, apayment_zip,                \
         iply_area, nbrand_abbr, ncar_abbr, fcar_note, qcylinder, iengine, ibody,             \
         itag, mcar_price, nequipment, flimit, pdmg_align, pbrg_align, plia_align,            \
         idmg_rate, pdmg_factor, ibrg_rate, pbrg_factor, qpt, fpt, psex_age, psex_age_damage, lia_class, \
         plia_acc, dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd, pdmg_acc, fhuman, fcomp_24,         \
         napplicant, dbirth, dissue,                                                          \
         iextra_charge, gextra_charge, pextra_charge,                                         \
         iquery_num_damage, iquery_num, mequipment,                                           \
         survey_num, bound_num, abnormal_num, iapplicant,iroute,qlia_acc_sum, qdmg_acc_sum,   \
         fapplicant,fsex_appl,dbirth_appl,itel_appl,ndeputy_appl,nrelation_appl,ndeputy_assured,\
         iassured_cntry,iapplicant_cntry, nassured_cntry, napplicant_cntry, \
         foccup, noccup, applicant_foccup, applicant_noccup, iroute_accept,tmobile_appl,aemail_appl,\
         qpro_month)   \
         SELECT '%s', a.qply_period, a.dply_begin, a.dply_end,                                \
                b.fassured, b.iassured, b.iassured_ext, b.nassured,                           \
                b.ilicense, b.fsex, b.fmarriage, b.nuser,                                     \
                b.ibenef, b.nbenef, b.aassured, b.aassured_zip, b.itel,                       \
                b.apayment, b.apayment_zip, b.iply_area, b.nbrand_abbr,                       \
                b.ncar_abbr, b.fcar_note, b.qcylinder, b.iengine, b.ibody,                    \
                b.itag, b.mcar_price, b.nequipment, b.flimit, b.pdmg_align,                   \
                b.pbrg_align, b.plia_align, b.idmg_rate, b.pdmg_factor,                       \
                b.ibrg_rate, b.pbrg_factor, b.qpt, b.fpt, b.psex_age, b.psex_age_damage,      \
                b.lia_class, b.plia_acc, b.dmg_acc_1st, b.dmg_acc_2nd,                        \
                b.dmg_acc_3rd, b.pdmg_acc, b.fhuman, b.fcomp_24,                              \
                b.napplicant, b.dbirth, b.dissue,                                             \
                b.iextra_charge, b.gextra_charge, b.pextra_charge,                            \
                b.iquery_num_damage, b.iquery_num, b.mequipment,                              \
                b.survey_num, b.bound_num, b.abnormal_num, b.iapplicant, '%s', b.qlia_acc_sum, b.qdmg_acc_sum , \
                b.fapplicant,b.fsex_appl,b.dbirth_appl,b.itel_appl,b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured, \
                CASE WHEN b.iassured_cntry='' THEN '8' ELSE b.iassured_cntry END, \
                CASE WHEN b.iapplicant_cntry='' THEN '8' ELSE b.iapplicant_cntry END, b.nassured_cntry, b.napplicant_cntry, \
                b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup,'%s',b.tmobile_appl , b.aemail_appl, \
                b.qpro_month \
           FROM ply_relation a,policy b                                                       \
          WHERE a.ipolicy = b.ipolicy                                                         \
            AND a.ipolicy = '%s' ",
          temp, b_iroute, iroute_accept_edr, ipolicy);
  printf("stmt[%s]\n", stmt);
  $PREPARE endor1 FROM $stmt;
  $EXECUTE endor1;
  /**** END �B�z�t���򥻸���� ****/

  sprintf(stmt,
          " UPDATE ply_relation                                                 \
           SET (mdmg_prem, mdmg_agent, mdmg_commi,                          \
                mlia_prem, mlia_agent, mlia_commi,                          \
                mdmg_pure_prem, mlia_pure_prem,                             \
                mready, mstable, mcompensation,                             \
                madjcom_prem, mresearch, minvest,                           \
                mbus_rule, mbusiness, mcapital, maintain, mdmg_discount,    \
                mlia_discount)                                              \
             = (0,%s,%s,0,%s,%s,0,0,0,0,0,0,0,0,0,0,0,0,0,0)  \
         WHERE ipolicy = '%s' ",
          sMdmg_agent1, sMdmg_commi1, sMlia_agent1, sMlia_commi1, ipolicy);
  printf("stmt[%s]\n", stmt);
  $PREPARE ply1 FROM $stmt;
  $EXECUTE ply1;

  rc = insert_cm_pre_receive_edr(temp, ipolicy, ipgid, v_sMsg);
  if (rc != M_CM_OK)
  {
    SQLCODE = rc;
    goto errexit;
  }

  /**** END �B�z�t���D��  ****/
  /***** �������t���@�~�� *****/

  /***** ���}�l�����@�~�� *****/
  if (fedr_class[0] == 'A')
  {
    edrrel_qcount = 1;
    edrins_qcount = 1;
  }
  else
  {
    edrrel_qcount = 0;
    edrins_qcount = 0;
  }

  $WHENEVER SQLERROR goto errexit;

  /**** START �����e�ƥ� ****/
  rc = bk_401(sDB, ipolicy, temp1);
  if (rc != M_CM_OK)
  {
    SQLCODE = rc;
    goto errexit;
  }
  /**** END �����e�ƥ� ****/

  /**** START �I�إ��� ****/
  sprintf(stmt,
          " UPDATE ply_ins_type                                                      \
           SET (minjured_cover,mdeath_cover,mdamage_cover,mdeduct,               \
                mins_premium,mpure_prem,iendorse,pcommission,                    \
                mcommission,pagent,magent,pdiscount,mdiscount,mprem,ipaid_base,  \
                qday,mexpense,mexp_disc,provision,mdrunk_prem, mdrunk_pure_prem, \
                mviolate_prem , mviolate_pure_prem)                              \
             = (?,?,?,?,?,?,'%s',?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)                \
         WHERE ipolicy = ?                                                       \
           AND iins_type = ? ",
          temp1);
  printf("stmt[%s]\n", stmt);
  $PREPARE pins2 FROM $stmt;

  sprintf(stmt,
          " SELECT minjured_cover, mdeath_cover, mdamage_cover,                \
                mdeduct, mins_premium, mpure_prem, qserial, pdiscount,      \
                mdiscount, drate_ym, mprem, iproduct, qday, mexpense,       \
                mexp_disc, provision, mcommission, magent, mdrunk_prem, mdrunk_pure_prem, \
                mviolate_prem , mviolate_pure_prem                          \
           FROM ply_ins_type_bak                                            \
          WHERE ipolicy  = ?                                                \
            AND iendorse = ?                                                \
            AND iins_type = ? ");
  $PREPARE spins_bak FROM $stmt;

  cm_buf_get("%l", &iedr_cnt);

  for (i = 0; i < iedr_cnt; i++)
  {
    cm_buf_get("%s", iins_type);
    cm_buf_get("%e", &g_pcommission); /* �s�����v */
    cm_buf_get("%l", &g_mcommission); /* �s���� */
    cm_buf_get("%e", &g_pagent);      /* �s�N�z�v */
    cm_buf_get("%l", &g_magent);      /* �s�N�z�O */
    cm_buf_get("%s", ipaid_base);

    if (strcmp(trim(iins_type), "21") != 0) /* ���N�I */
    {
      $SELECT pbusiness, drate_ym, pdiscount, pextra_charge INTO $pbusiness_new, $drate_ym, $pdiscount_new, $pextra_charge_new FROM ply_ins_type WHERE ipolicy = $ipolicy AND iins_type = $iins_type;

      if (SQLCODE == SQLNOTFOUND)
      {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return exitsub(reply, M_CA_NINSTYPE) ? M_CA_NINSTYPE : apiRC;
      }

      $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
                                     INTO $f980401
                                         FROM ca_rate_date
                                             WHERE icode = $drate_ym
          AND itable = 'cm_extra_charge';

      if (SQLCODE == SQLNOTFOUND)
      {
        $WHENEVER SQLERROR CONTINUE;
        $ROLLBACK WORK;
        return exitsub(reply, M_CA_EXTRA_CHARGE_DRATE) ? M_CA_EXTRA_CHARGE_DRATE : apiRC;
      }

      /* �O�v�ۥѤƤ��� */
      if (f980401[0] == '1')
      {
        printf("pdiscount_new    [%f]\n", pdiscount_new);
        printf("g_pcommission    [%f]\n", g_pcommission);
        printf("g_pagent         [%f]\n", g_pagent);
        printf("pextra_charge_new[%f]\n", pextra_charge_new);
        printf("pbusiness_new    [%f]\n", pbusiness_new);
        if (pdiscount_new != 0) /* �O�v�ۥѤƤ��ᤣ�i������ */
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          return exitsub(reply, M_CA_PDISCOUNT_ERR) ? M_CA_PDISCOUNT_ERR : apiRC;
        }

        sprintf(sCCC1, "%f", (pdiscount_new + g_pcommission + g_pagent));
        sprintf(sCCC2, "%f", ((pextra_charge_new - pbusiness_new) * 100.0));
        printf("sCCC1[%s]\n", sCCC1);
        printf("sCCC2[%s]\n", sCCC2);
        rCCC1 = atof(sCCC1);
        rCCC2 = atof(sCCC2);

        printf("��+�N+�u[%f]\n", rCCC1);
        printf("��-�~   [%f]\n", rCCC2);

        if (rCCC1 > rCCC2)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          return exitsub(reply, M_CA_COMMI_ERR) ? M_CA_COMMI_ERR : apiRC;
        }

        v_iins = atoi(rtrim(iins_type));

        printf("1_iextra_charge_new[%s]\n", iextra_charge_new);
        printf("1_iroute[%s]\n", iroute);
        printf("1_b_iroute[%s]\n", b_iroute);
        printf("1_v_iins[%d]\n", v_iins);
        printf("1_drate_ym[%s]\n", drate_ym);
        printf("1_qply_period[%d]\n", qply_period);
        /* ����ᤧ���[�O�v */
        rc = get_cm_extra_charge_car(iextra_charge_new, drate_ym,
                                     &pextra_charge_new, &pbusiness_new, qply_period, v_iins, iroute, v_sMsg);
        if (rc != M_CM_OK)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          return exitsub(reply, rc) ? rc : apiRC;
        }
        printf("--1330 trace pextra_charge_new=[%f]", pextra_charge_new);

        /* ����e�����[�O�v */
        rc = get_cm_extra_charge_car(iextra_charge, drate_ym,
                                     &pextra_charge, &pbusiness, qply_period, v_iins, b_iroute, v_sMsg);
        if (rc != M_CM_OK)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          return exitsub(reply, rc) ? rc : apiRC;
        }
        printf("--1341 trace pextra_charge=[%f]", pextra_charge);

        /* �O�v�ۥѤƤ���,���[�O�βv���P,���i���,�Ь��ӫO�� */
        if (pextra_charge_new != pextra_charge)
        {
          $WHENEVER SQLERROR CONTINUE;
          $ROLLBACK WORK;
          return exitsub(reply, M_CA_PEXTRA_CHARGE_NOT_EQUAL) ? M_CA_PEXTRA_CHARGE_NOT_EQUAL : apiRC;
        }
      }
    }

    $EXECUTE spins_bak
        INTO $minjured_cover,
        $mdeath_cover, $mdamage_cover,
        $mdeduct, $mins_premium, $mpure_prem, $qserial, $pdiscount,
        $mdiscount, $drate_ym, $mprem, $iproduct, $qday, $mexpense,
        $mexp_disc, $provision, $mcommission, $magent, $mdrunk_prem, $mdrunk_pure_prem,
        $mviolate_prem, $mviolate_pure_prem USING $ipolicy, $temp, $iins_type;

    /* CA_Q */
    if (ibroker_expire[0] == 'Y') /* �g���N������ */
    {
      /* �����w���X�@�t�@�����A�����ߦ�,�ҥH�̷s�O������N�z�O�M���e�@�� */
      if (strncmp(presult, "P2", 2) == 0)
      {
        /*g_mcommission = mcommission;
        g_magent = magent;*/

        /* �����w�������p��,�����H�ΥN�z�v��[��Ҥ��ߦ� */
        g_mcommission = 0;
        g_magent = 0;
        g_pcommission = 0;
        g_pagent = 0;
      }
    }

    $EXECUTE pins2
        USING $minjured_cover,
        $mdeath_cover, $mdamage_cover,
        $mdeduct, $mins_premium, $mpure_prem, $g_pcommission, $g_mcommission,
        $g_pagent, $g_magent, $pdiscount, $mdiscount, $mprem, $ipaid_base,
        $qday, $mexpense, $mexp_disc, $provision, $mdrunk_prem, $mdrunk_pure_prem,
        $mviolate_prem, $mviolate_pure_prem,
        $ipolicy, $iins_type;

    printf("iins_type[%s]\n", iins_type);
    $EXECUTE surid
        INTO $fins_grp
            USING $iins_type;
    if (SQLCODE == SQLNOTFOUND)
    {
      $WHENEVER SQLERROR CONTINUE;
      $ROLLBACK WORK;
      if (exitsub(reply, M_CA_NINS_TYPE) == True)
        return M_CA_NINS_TYPE;
      else
        return apiRC;
    }
    $WHENEVER SQLERROR goto errexit;
    printf("fins_grp[%s]\n", fins_grp);
    switch (fins_grp[0])
    {
    case '1':
      mdmg_commi += g_mcommission;
      mdmg_agent += g_magent;
      break;
    case '2':
      mlia_commi += g_mcommission;
      mlia_agent += g_magent;
      break;
    case '3':
      mlia_commi += g_mcommission;
      mlia_agent += g_magent;
      break;
    default:
      $WHENEVER SQLERROR CONTINUE;
      $ROLLBACK WORK;
      if (exitsub(reply, M_CA_NINS_TYPE) == True)
        return M_CA_NINS_TYPE;
      else
        return apiRC;
      break;
    }
  }

  $WHENEVER SQLERROR goto errexit;

  sprintf(stmt,
          " INSERT INTO edr_ins_type                                            \
        (iendorse, iins_type, iedr_type, medrinj_cover,                     \
         medrdea_cover, medrdmg_cover, mdeduct, medrins_prem,               \
         medrpure_prem, fcal_way, pcal, qserial, pcommission,               \
         medr_commission, pagent, medr_agent, pdiscount, medr_discount,     \
         drate_ym, medr_prem, iproduct, ipaid_base, qday, medr_expense,     \
         medr_exp_disc, qcount, provision, psex_age, mdrunk_prem, mdrunk_pure_prem, \
         mviolate_prem , mviolate_pure_prem )  \
         SELECT '%s', iins_type, '%s',                                      \
                minjured_cover , mdeath_cover ,                             \
                mdamage_cover , mdeduct ,                                   \
                mins_premium , mpure_prem ,                                 \
                'M', 100, qserial, %s, %s,                     \
                %s, %s, pdiscount, mdiscount,                       \
                drate_ym, mprem, iproduct, ipaid_base, qday, mexpense,      \
                mexp_disc, %ld, provision, psex_age, mdrunk_prem, mdrunk_pure_prem, \
                mviolate_prem , mviolate_pure_prem \
           FROM ply_ins_type                                                \
          WHERE ipolicy = '%s' ",
          temp1, iedr_type2, sPcommission, sMcommission, sPagent, sMagent, edrins_qcount, ipolicy);
  printf("stmt[%s]\n", stmt);
  $PREPARE eins2 FROM $stmt;
  $EXECUTE eins2;

  /****  �B�z�ˮ`�I���I��   ****/
  sprintf(stmt,
          " UPDATE ca_pa_ply                                                         \
           SET (mins_amt, mins_premium, mpure_prem, pcommission, mcommission,    \
                pagent, magent, pdiscount, mdiscount, iendorse)                  \
             = (?,?,?,?,?,?,?,?,?,'%s')                                          \
         WHERE ipolicy = ?                                                       \
           AND iins_type = ?                                                     \
           AND iinsurant = ?                                                     \
           AND iins_scope = ?                                                    \
           AND icareer = ?  ",
          temp1);
  printf("stmt[%s]\n", stmt);
  $PREPARE cains2 FROM $stmt;

  sprintf(stmt,
          " SELECT mins_amt, mins_premium, mpure_prem, pdiscount,    \
               mdiscount, mcommission, magent                    \
          FROM ca_pa_ply_bak                                     \
         WHERE ipolicy = ?                                       \
           AND iendorse = ?                                      \
           AND iins_type = ?                                     \
           AND iinsurant = ?                                     \
           AND iins_scope = ?                                    \
           AND icareer = ? ");
  printf("stmt[%s]\n", stmt);
  $PREPARE pabak FROM $stmt;

  cm_buf_get("%l", &ipa_cnt);

  for (i = 0; i < ipa_cnt; i++)
  {
    printf("a:g_pcommission[%f], g_mcommission[%d]\n", g_pcommission, g_mcommission);
    cm_buf_get("%s", iins_type);
    cm_buf_get("%s", iinsurant);
    cm_buf_get("%s", iins_scope);
    cm_buf_get("%s", icareer);
    cm_buf_get("%e", &g_pcommission);
    printf("b:g_pcommission[%f], g_mcommission[%d]\n", g_pcommission, g_mcommission);
    cm_buf_get("%l", &g_mcommission);
    printf("c:g_pcommission[%f], g_mcommission[%d]\n", g_pcommission, g_mcommission);
    cm_buf_get("%e", &g_pagent);
    printf("d:g_pcommission[%f], g_mcommission[%d]\n", g_pcommission, g_mcommission);
    cm_buf_get("%l", &g_magent);

    printf("1:g_pcommission[%f], g_mcommission[%d]\n", g_pcommission, g_mcommission);

    printf("ipolicy[%s]\n", ipolicy);
    printf("iins_type[%s]\n", iins_type);
    printf("iinsurant[%s]\n", iinsurant);
    printf("iins_scope[%s]\n", iins_scope);
    printf("icareer[%s]\n", icareer);
    printf("2:g_pcommission[%f], g_mcommission[%d]\n", g_pcommission, g_mcommission);
    $EXECUTE pabak
        INTO $mins_amt,
        $mins_premium, $mpure_prem, $pdiscount,
        $mdiscount, $mcommission, $magent USING $ipolicy, $temp, $iins_type, $iinsurant, $iins_scope, $icareer;
    printf("3:g_pcommission[%f], g_mcommission[%d]\n", g_pcommission, g_mcommission);

    if (SQLCODE == SQLNOTFOUND)
    {
      $WHENEVER SQLERROR CONTINUE;
      $ROLLBACK WORK;
      if (exitsub(reply, M_CA_PA_BAK_NOT_FOUND) == True)
        return M_CA_PA_BAK_NOT_FOUND;
      else
        return apiRC;
    }

    printf("4:g_pcommission[%f], g_mcommission[%d]\n", g_pcommission, g_mcommission);
    /* CA_Q */
    if (ibroker_expire[0] == 'Y') /* �g���N������ */
    {
      printf("5:g_pcommission[%f], g_mcommission[%d]\n", g_pcommission, g_mcommission);
      /* �����w���X�@�t�@�����A�����ߦ�,�ҥH�̷s�O������N�z�O�M���e�@�� */
      if (strncmp(presult, "P2", 2) == 0)
      {
        printf("6:g_pcommission[%f], g_mcommission[%d]\n", g_pcommission, g_mcommission);
        /*g_mcommission = mcommission;
        g_magent = magent;*/

        /* �����w�������p��,�����H�ΥN�z�v��[��Ҥ��ߦ� */
        g_mcommission = 0;
        g_magent = 0;
        g_pcommission = 0;
        g_pagent = 0;
        printf("7:g_pcommission[%f], g_mcommission[%d]\n", g_pcommission, g_mcommission);
      }
      else if (strncmp(presult, "P3", 2) == 0) /* ���O�������X�@�t�@�����A�ݥߦ�,�u�������O�O���X�p�X��� */
      {
        printf("8:g_pcommission[%f], g_mcommission[%d]\n", g_pcommission, g_mcommission);
      }
    }
    printf("9:g_pcommission[%f], g_mcommission[%d]\n", g_pcommission, g_mcommission);
    $EXECUTE cains2
        USING $mins_amt,
        $mins_premium, $mpure_prem, $g_pcommission, $g_mcommission,
        $g_pagent, $g_magent, $pdiscount, $mdiscount, $ipolicy, $iins_type,
        $iinsurant, $iins_scope, $icareer;
  }

  sprintf(stmt,
          " INSERT INTO ca_pa_edr                                               \
        (iendorse, iins_type, iinsurant, iedr_type, ninsurant, dbirth,      \
         ainsurant, iins_scope, icareer, medrins_amt, fcal_way,             \
         pcal, medrins_prem, medrpure_prem, pcommission,                    \
         medr_commission, pagent, medr_agent, pdiscount,                    \
         medr_discount, dendorse, napplicant, relation_appl,                \
         nbeneficiary,relation_bene,tbenef, abenef_zip, abenef)             \
        SELECT '%s', iins_type, iinsurant, '%s', ninsurant, dbirth,         \
               ainsurant, iins_scope, icareer, mins_amt, 'M',               \
               100, mins_premium, mpure_prem, %s,                  \
               %s, %s, %s, 0,                                           \
               mdiscount, '', napplicant, relation_appl,                   \
               nbeneficiary, relation_bene,tbenef, abenef_zip, abenef       \
          FROM ca_pa_ply                                                    \
         WHERE ipolicy = '%s' ",
          temp1, iedr_type2, sPcommission, sMcommission, sPagent, sMagent, ipolicy);
  printf("stmt[%s]\n", stmt);
  $PREPARE caedr2 FROM $stmt;
  $EXECUTE caedr2;

  /**** END �I�إ��� ****/

  /**** START �D�ɥ��� ****/
  sprintf(stmt,
          " SELECT mdmg_prem, mlia_prem, mdmg_pure_prem,              \
               mlia_pure_prem, mready, mstable, mcompensation,    \
               madjcom_prem, mresearch, minvest, mbus_rule, mbusiness,   \
               mcapital, maintain, mdmg_discount,                 \
               mlia_discount                                      \
          FROM ply_relation_bak                                   \
         WHERE ipolicy = ?                                        \
           AND iendorse = ? ");
  $PREPARE splyid FROM $stmt;
  $EXECUTE splyid
      INTO $mdmg_prem,
      $mlia_prem, $mdmg_pure_prem,
      $mlia_pure_prem, $mready, $mstable, $mcompensation,
      $madjcom_prem, $mresearch, $minvest, $mbus_rule, $mbusiness,
      $mcapital, $maintain, $mdmg_discount,
      $mlia_discount
          USING $ipolicy,
      $temp;

  sprintf(stmt,
          " UPDATE ply_relation                                                 \
           SET (iresource, ibroker, iofficer, ileader, icorps,              \
                iquota,ibig_office,ibig_sales,                              \
                mdmg_prem, mdmg_agent, mdmg_commi,                          \
                mlia_prem, mlia_agent, mlia_commi,                          \
                mdmg_pure_prem, mlia_pure_prem,                             \
                mready, mstable, mcompensation,                             \
                madjcom_prem, mresearch, minvest, mbus_rule,                \
                mbusiness, mcapital, maintain , mdmg_discount,              \
                mlia_discount, iofficer_prmt, iquota_prmt, ileader_prmt, irate_type,bzfrom,iroute_comm,icomm_obj,ibig_comp,ireg_no)    \
             = (?,?,?,?,?,  ?,?,?,  ?,?,?,  ?,?,?,  ?,?,  ?,?,?,  ?,?,?,?,  \
                ?,?,?,?,  ?,?,?,?, ?,?,?,?,?,?)    \
         WHERE ipolicy = '%s' ",
          ipolicy);
  printf("stmt[%s]\n", stmt);

  $PREPARE ply2 FROM $stmt;
  $EXECUTE ply2
      USING $iresource,
      $ibroker, $iofficer, $ileader, $icorps,
      $iquota, $ibig_office, $ibig_sales,
      $mdmg_prem, $mdmg_agent, $mdmg_commi,
      $mlia_prem, $mlia_agent, $mlia_commi,
      $mdmg_pure_prem, $mlia_pure_prem,
      $mready, $mstable, $mcompensation,
      $madjcom_prem, $mresearch, $minvest, $mbus_rule,
      $mbusiness, $mcapital, $maintain, $mdmg_discount,
      $mlia_discount, $iofficer_prmt, $iquota_prmt, $ileader_prmt, $irate_type, $bzfrom, $iroute_comm, $icomm_obj, $ibig_comp, $ireg_no;

  if (strncmp(icomm_obj, "10000", 5) == 0 && mdmg_commi + mlia_commi != 0)
  {
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if (exitsub(reply, M_CA_CANT_HAVE_COMMI1) == True)
      return M_CA_CANT_HAVE_COMMI1;
    else
      return apiRC;
  }

  /* car9811303 �j���I99.3.1�O�v */
  if (ori_fcard_class[0] == '1')
  {
    strcpy(iabn_type, "");
    $SELECT drate_ym
        INTO $comp_frate
            FROM ply_ins_type
                WHERE ipolicy = $ipolicy
                    AND iins_type = '21';
    rc = chk_commi_business(1, iabn_type, comp_frate, mdmg_commi + mlia_commi, mbusiness, v_sMsg);

    if (rc != M_CM_OK)
    {
      $WHENEVER SQLERROR CONTINUE;
      $ROLLBACK WORK;
      if (exitsub(reply, rc) == True)
        return rc;
      else
        return apiRC;
    }
  }

  $UPDATE policy
      SET(iextra_charge, iroute) = ($iextra_charge_new, $iroute)
          WHERE ipolicy = $ipolicy;

  sprintf(stmt,
          " INSERT INTO edr_relation \
        (iendorse, fcard_class, ipolicy, icard, irelative_ply, irelative_edr, \
         fedr_class, fpay, ipay, iedr_field, dedr_begin, dedr_end,  \
         ipro_year, ibrand, icar_type, medrdmg_agent, medrdmg_commi,  \
         medrdmg_prem, medrdmg_pure_prem, medrlia_agent, medrlia_commi, \
         medrlia_prem, medrlia_pure_prem, ibig_comp, ibig_branch, ibig_office,  \
         ibig_sales, iresource, ibroker, iofficer, ileader, icorps, iedr_area,  \
         iedr_cashier, iedr_examiner, dedr_examine, dentry, dendorse, \
         fprint, itreaty, ibranch, iquota, icomp_in, ibranch_in, icomp_at,  \
         ibranch_at, medr_ready, medr_stable, medr_compensate, medr_adjcom, \
         medr_research, medr_invest, medr_bus_rule, medr_business,  \
         medr_capital, medr_maintain, fcomp_class, fcomp_class_last, fdiscount, medrdmg_disc, \
         medrlia_disc, iedr_return, icar_flag, terminate_rsn, qcount, \
         iofficer_prmt, iquota_prmt, ileader_prmt, irate_type,bzfrom,iroute_comm,icomm_obj,qprovision, isecond_hand, icard_main, qdrunk_driving, isign, \
         feply, feedr, aemail_eply, tmobile_eply,ireg_no,isign_edr,dsign_edr,fsign_status_edr,funder_chk_edr,iprog,qviolate) \
        SELECT '%s', fcard_class, ipolicy, icard, irelative_ply, ' ', \
         '%s', '%s', ' ', ' ', dply_begin, dply_end,  \
         ipro_year, ibrand, icar_type, %s, %s,  \
         mdmg_prem, mdmg_pure_prem, %s, %s, \
         mlia_prem, mlia_pure_prem, '%s', ibig_branch, '%s', \
         '%s', '%s', '%s', '%s', '%s', '%s', iarea, \
         '%s', '%s', %ld, %ld, '', \
          1, itreaty, ibranch, iquota, icomp_in, ibranch_in, '%s',  \
          '%s', mready, mstable, mcompensation, madjcom_prem, \
          mresearch, minvest, mbus_rule, mbusiness, \
          mcapital, maintain, fcomp_class, fcomp_class_last, fdiscount, mdmg_discount,  \
          mlia_discount, '0', icar_flag, '0', %ld, '%s', '%s', '%s','%s','%s','%s','%s', qprovision, isecond_hand, icard_main, qdrunk_driving, isign, \
          feply, '0', aemail_eply, tmobile_eply, '%s','system',today,40,'N','car413',qviolate \
          FROM ply_relation \
         WHERE ipolicy = '%s' ",
          temp1, fedr_class, fpay, sMdmg_agent, sMdmg_commi,
          sMlia_agent, sMlia_commi, ibig_comp, ibig_office, ibig_sales,
          iresource, ibroker, iofficer, ileader, icorps,
          userid, userid,
          dwritten, dwritten,
          icomp_at, ibranch_at, edrrel_qcount,
          iofficer_prmt, iquota_prmt, ileader_prmt, irate_type, bzfrom, iroute_comm, icomm_obj, ireg_no, ipolicy);
  printf("stmt[%s]\n", stmt);
  $PREPARE edr2 FROM $stmt;
  $EXECUTE edr2;

  /**** START �򥻸���ɥ��� ****/
  /*1071105008_SC2_ �������Ȩ��z��(FS)�A�éw�ɦ۰ʤU���ɮ�*/
  strcpy(iroute_accept_edr, " ");
  if (strncmp(iroute, "I009", 4) == 0)
  {
    strcpy(temp1, trim(temp1));
    sprintf(iroute_accept_edr, "CHB%s", temp1);
  }
  printf("-- trace iroute_accept_edr[%s]\n ", iroute_accept_edr);

  sprintf(stmt,
          " INSERT INTO endorsement                                                               \
        (iendorse, qply_period, dply_begin, dply_end, fassured, iassured,                     \
         iassured_ext, nassured, ilicense, fsex, fmarriage, nuser,                    \
         ibenef, nbenef, aassured, aassured_zip, itel, apayment, apayment_zip,                \
         iply_area, nbrand_abbr, ncar_abbr, fcar_note, qcylinder, iengine, ibody,             \
         itag, mcar_price, nequipment, flimit, pdmg_align, pbrg_align, plia_align,            \
         idmg_rate, pdmg_factor, ibrg_rate, pbrg_factor, qpt, fpt, psex_age, psex_age_damage, lia_class, \
         plia_acc, dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd, pdmg_acc, fhuman, fcomp_24,         \
         napplicant, dbirth, dissue,                              \
         iextra_charge, gextra_charge, pextra_charge,                                         \
         iquery_num_damage, iquery_num, mequipment,                               \
         survey_num, bound_num, abnormal_num, iapplicant, iroute, qlia_acc_sum, qdmg_acc_sum, \
         fapplicant,fsex_appl,dbirth_appl,itel_appl,ndeputy_appl,nrelation_appl,ndeputy_assured,\
         iassured_cntry,iapplicant_cntry, nassured_cntry, napplicant_cntry, \
         foccup, noccup, applicant_foccup, applicant_noccup, iroute_accept,tmobile_appl , aemail_appl,\
         qpro_month ) \
         SELECT '%s', a.qply_period, a.dply_begin, a.dply_end,                                \
                b.fassured, b.iassured, b.iassured_ext, b.nassured,                           \
                b.ilicense, b.fsex, b.fmarriage, b.nuser,                           \
                b.ibenef, b.nbenef, b.aassured, b.aassured_zip, b.itel,                       \
                b.apayment, b.apayment_zip, b.iply_area, b.nbrand_abbr,                       \
                b.ncar_abbr, b.fcar_note, b.qcylinder, b.iengine, b.ibody,                    \
                b.itag, b.mcar_price, b.nequipment, b.flimit, b.pdmg_align,                   \
                b.pbrg_align, b.plia_align, b.idmg_rate, b.pdmg_factor,                       \
                b.ibrg_rate, b.pbrg_factor, b.qpt, b.fpt, b.psex_age, b.psex_age_damage,      \
                b.lia_class, b.plia_acc, b.dmg_acc_1st, b.dmg_acc_2nd,                        \
                b.dmg_acc_3rd, b.pdmg_acc, b.fhuman, b.fcomp_24,                              \
                b.napplicant, b.dbirth, b.dissue,             \
                '%s', b.gextra_charge, b.pextra_charge,                            \
                b.iquery_num_damage, b.iquery_num, b.mequipment,                \
                b.survey_num, b.bound_num, b.abnormal_num, b.iapplicant, '%s', b.qlia_acc_sum, b.qdmg_acc_sum, \
                b.fapplicant,b.fsex_appl,b.dbirth_appl,b.itel_appl,b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured,\
                CASE WHEN b.iassured_cntry='' THEN '8' ELSE b.iassured_cntry END, \
                CASE WHEN b.iapplicant_cntry='' THEN '8' ELSE b.iapplicant_cntry END, b.nassured_cntry, b.napplicant_cntry, \
                b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup,'%s',b.tmobile_appl , b.aemail_appl, \
                b.qpro_month \
           FROM ply_relation a,policy b                                                       \
          WHERE a.ipolicy = b.ipolicy                                                         \
            AND a.ipolicy = '%s' ",
          temp1, iextra_charge_new, iroute, iroute_accept_edr, ipolicy);
  printf("stmt[%s]\n", stmt);
  $PREPARE endor2 FROM $stmt;
  $EXECUTE endor2;

  rc = insert_cm_pre_receive_edr(temp1, ipolicy, ipgid, v_sMsg);
  if (rc != M_CM_OK)
  {
    SQLCODE = rc;
    goto errexit;
  }

  /**** END �򥻸���ɥ��� ****/
  /* check �t���D�ɩ��Ӫ��B�O�_�@�P */
  $SELECT SUM(medrins_prem), SUM(medr_commission), SUM(medr_agent) INTO $medrins_prem, $medr_commission, $medr_agent FROM edr_ins_type WHERE iendorse = $temp;

  $SELECT medrlia_prem + medrdmg_prem, medrlia_commi + medrdmg_commi, medrlia_agent + medrdmg_agent INTO $mins_premium, $mcommission, $magent FROM edr_relation WHERE iendorse = $temp;

  printf("negative iendorse[%s]\n", temp);
  printf("medrins_prem    [%d] mins_premium[%d]\n", medrins_prem, mins_premium);
  printf("medr_commission [%d] mcommission [%d]\n", medr_commission, mcommission);
  printf("medr_agent      [%d] magent      [%d]\n", medr_agent, magent);

  if ((medrins_prem != mins_premium) ||
      (medr_commission != mcommission) ||
      (medr_agent != magent))
  {
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if (exitsub(reply, M_CA_EDR_PREM_NOT_EQUAL) == True)
      return M_CA_EDR_PREM_NOT_EQUAL;
    else
      return apiRC;
  }

  $SELECT SUM(medrins_prem), SUM(medr_commission), SUM(medr_agent) INTO $medrins_prem, $medr_commission, $medr_agent FROM edr_ins_type WHERE iendorse = $temp1;

  $SELECT medrlia_prem + medrdmg_prem, medrlia_commi + medrdmg_commi, medrlia_agent + medrdmg_agent INTO $mins_premium, $mcommission, $magent FROM edr_relation WHERE iendorse = $temp1;

  printf("iendorse[%s]\n", temp1);
  printf("medrins_prem    [%d] mins_premium[%d]\n", medrins_prem, mins_premium);
  printf("medr_commission [%d] mcommission [%d]\n", medr_commission, mcommission);
  printf("medr_agent      [%d] magent      [%d]\n", medr_agent, magent);

  /* check ���D�ɩ��Ӫ��B�O�_�@�P */
  if ((medrins_prem != mins_premium) ||
      (medr_commission != mcommission) ||
      (medr_agent != magent))
  {
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if (exitsub(reply, M_CA_EDR_PREM_NOT_EQUAL) == True)
      return M_CA_EDR_PREM_NOT_EQUAL;
    else
      return apiRC;
  }

  $select a.iendorse, a.iedr_type, a.iins_type, a.medrins_prem, sum(b.medrins_prem) from edr_ins_type a, ca_pa_edr b where a.iendorse = b.iendorse and a.iins_type = b.iins_type and a.iendorse = $temp group by 1, 2, 3, 4 having a.medrins_prem<> sum(b.medrins_prem);

  printf("SQLCODE[%d]\n", SQLCODE);
  if (SQLCODE != SQLNOTFOUND)
  {
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if (exitsub(reply, M_CA_EDR_PREM_NOT_EQUAL) == True)
      return M_CA_EDR_PREM_NOT_EQUAL;
    else
      return apiRC;
  }

  printf("SQLCODE[%d]\n", SQLCODE);
  $select a.iendorse, a.iedr_type, a.iins_type, a.medrins_prem, sum(b.medrins_prem) from edr_ins_type a, ca_pa_edr b where a.iendorse = b.iendorse and a.iins_type = b.iins_type and a.iendorse = $temp1 group by 1, 2, 3, 4 having a.medrins_prem<> sum(b.medrins_prem);

  if (SQLCODE != SQLNOTFOUND)
  {
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    if (exitsub(reply, M_CA_EDR_PREM_NOT_EQUAL) == True)
      return M_CA_EDR_PREM_NOT_EQUAL;
    else
      return apiRC;
  }

  /**** END �D�ɥ��� ****/

  /*****  ���������@�~   *****/

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s", M_CM_OK, temp, temp1);
  iRtnLen = cm_buf_len(ReplyBuf);

  if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False)
  {
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    return apiRC;
  }
  $COMMIT WORK;
  return api_OKComplete;

errexit:
  MsgCode = SQLCODE;
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if (SQLCODE != 0)
    MsgCode = SQLCODE;
  return exitsub(reply, MsgCode) ? MsgCode : apiRC;
} /* car413_insert */

/***********************************************************************/
long car413_single_query(reply)
serverReply reply;
{
  long MsgCode;
  $char cBuf[10];
  $char ipolicy[21];
  $char dendorse[11];
  $char iendorse1[21], iendorse2[21];
  $char dpolicy[11];
  $char iofficer[11];
  $char icorps[11];
  $char iquota[7];
  $char ileader[11];
  $char ibroker[11];
  $char iresource[2];
  $char nassured[121];
  $char off_nname[21];
  $char route_nname[21];
  $char cor_nname[21];
  $char quo_nname[41];
  $char lead_nname[11];
  $char nchi_abv[13];
  $char nresource[21];
  $char iins_type[INSURANCE_TYPE];
  $long mdiscount;
  $long mins_premium, rc;
  $double pcommission, pagent;
  $double pdiscount;
  $long mcommission, magent;
  $int ins_cnt;
  $char tmp_pdiscount[8];
  $char tmp_pcommission[8];
  $char tmp_pagent[8];
  $char sDB[3];
  $char fedr_class[2];
  $char iedr_type[3];
  $char iendorse_tmp[21], ibroker_expire[2], opt[2];
  $char ipolicy8;
  int iiedr;

  $double new_pcommission, new_pagent;
  $long new_mcommission, new_magent;
  $char new_tmp_pcommission[8], new_tmp_pagent[8];

  /* dws9807212�s�W�q�� */
  $char ioffice[10], isales[11];
  $char iroute[21];

  /* 1000311003 �q��2 */
  $char irate_type[2], bzfrom[3], iroute_comm[4], icomm_obj[11], ireg_no[21];

  pdiscount = 0;
  mdiscount = 0;
  mins_premium = 0;
  pcommission = 0;
  pagent = 0;
  mcommission = 0;
  magent = 0;

  cm_buf_get("%s", cDbName);
  cm_buf_get("%s %s %s %s", ipolicy, dendorse, iendorse1, iendorse2);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(cDbName) == False)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  strcpy(sDB, get_db(ipolicy));
  if (strncmp(sDB, "100", 3) == 0)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }

  if (db_select(sDB) == False)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  printf("iendorse1[%s] flag1\n", iendorse1);
  $SELECT dpolicy, iofficer, icorps, iquota, ileader, ibroker, iresource,
      ibig_office, ibig_sales, irate_type, bzfrom, iroute_comm, icomm_obj, ireg_no INTO $dpolicy, $iofficer, $icorps, $iquota, $ileader, $ibroker, $iresource,
      $ioffice, $isales, $irate_type, $bzfrom, $iroute_comm, $icomm_obj, $ireg_no FROM ply_relation_bak WHERE ipolicy = $ipolicy AND iendorse = $iendorse1;

  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }
  strcpy(dpolicy, cm_from_infdate_100(dpolicy));

  /* �q�̷s�O�����^���q���N��/�~�ȭ�
  $SELECT ibig_office, ibig_sales, b.iroute
     INTO $a_iroute, $a_isales, $a_iroute
     FROM ply_relation a, policy b
    WHERE a.ipolicy = $ipolicy
      AND a.ipolicy = b.ipolicy;*/

  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }
  /* end of �^���q���N��/�~�ȭ� */

  printf("iendorse1[%s] flag1\n", iendorse1);
  $SELECT UNIQUE iedr_type
      INTO $iedr_type
          FROM edr_ins_type
              WHERE iendorse = $iendorse1;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }
  iiedr = atoi(iedr_type);

  printf("iiedr[%d]\n", iiedr);
  $SELECT nassured, iroute INTO $nassured, $iroute FROM policy_bak WHERE ipolicy = $ipolicy AND iendorse = $iendorse1;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }

  strcpy(off_nname, " ");
  $SELECT nname
      INTO $off_nname
          FROM officer
              WHERE iofficer = $iofficer;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CA_NOT_IOFFICER) == True)
      return M_CA_NOT_IOFFICER;
    else
      return apiRC;
  }

  strcpy(cor_nname, " ");
  if (strlen(trim(icorps)) != 0)
  {
    ipolicy8 = ipolicy[7];
    if (ipolicy8 <= 65)
    {
      $SELECT nname
          INTO $cor_nname
              FROM officer
                  WHERE iofficer = $icorps;
      if (SQLCODE == SQLNOTFOUND)
      {
        if (exitsub(reply, M_CA_NOT_ICORPS) == True)
          return M_CA_NOT_ICORPS;
        else
          return apiRC;
      }
    }
  }

  $SELECT nbranch
      INTO $quo_nname
          FROM sa_branch_type
              WHERE ibranch = $iquota;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CA_NOT_IQUOTA) == True)
      return M_CA_NOT_IQUOTA;
    else
      return apiRC;
  }

  $SELECT nname
      INTO $lead_nname
          FROM officer
              WHERE iofficer = $ileader;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CA_NOT_ILEADER) == True)
      return M_CA_NOT_ILEADER;
    else
      return apiRC;
  }

  strcpy(ibroker_expire, "N");
  strcpy(nchi_abv, "");

  /* �I����H�O�_����O */
  strcpy(opt, "5");
  rc = cm_chk_policy(opt, "", "", "", icomm_obj, "", "", "");

  if (rc == M_CMN_COMM_OBJ_EXPIRE) /* �I����H����O */
  {
    strcpy(ibroker_expire, "Y");
  }
  else if (rc != M_CM_OK)
  {
    if (exitsub(reply, rc) == True)
      return rc;
    else
      return apiRC;
  }

  $SELECT ncode
      INTO $nresource
          FROM cu_code_data
              WHERE itype = '10' AND icode = $iresource;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CA_NOT_IRESOURCE) == True)
      return M_CA_NOT_IRESOURCE;
    else
      return apiRC;
  }

  /* �H���e���q���N����q���W�� */
  $SELECT nroute[1, 10] INTO $route_nname
      FROM cm_route
          WHERE iroute = $iroute;
  if (SQLCODE == SQLNOTFOUND)
  {
    strcpy(route_nname, "");
  }

  $SELECT dendorse
      INTO $dendorse
          FROM edr_relation
              WHERE iendorse = $iendorse1;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }
  strcpy(dendorse, cm_from_infdate_100(dendorse));

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l", M_CM_OK);

  cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
             ipolicy, iendorse1, iendorse2, dpolicy, nassured, iofficer, iroute, icorps,
             iquota, ileader, ibroker, iresource, ioffice, isales,
             off_nname, route_nname, cor_nname, quo_nname, lead_nname, nchi_abv, nresource, dendorse,
             irate_type, bzfrom, iroute_comm, icomm_obj, ireg_no);

  if (iiedr != 84)
  {
    $SELECT fedr_class, dendorse, iofficer, icorps, iquota, ileader, ibroker, iresource,
        ibig_office, ibig_sales, b.iroute, irate_type, bzfrom, iroute_comm, icomm_obj, ireg_no INTO $fedr_class, $dendorse, $iofficer, $icorps, $iquota, $ileader, $ibroker, $iresource,
        $ioffice, $isales, $iroute, $irate_type, $bzfrom, $iroute_comm, $icomm_obj, $ireg_no FROM edr_relation a, endorsement b WHERE a.iendorse = $iendorse2 AND a.iendorse = b.iendorse;

    if (SQLCODE == SQLNOTFOUND)
    {
      if (exitsub(reply, M_CM_NOT_FOUND) == True)
        return M_CM_NOT_FOUND;
      else
        return apiRC;
    }
    strcpy(dendorse, cm_from_infdate_100(dendorse));

    strcpy(off_nname, " ");
    $SELECT nname
        INTO $off_nname
            FROM officer
                WHERE iofficer = $iofficer;
    if (SQLCODE == SQLNOTFOUND)
    {
      if (exitsub(reply, M_CA_NOT_IOFFICER) == True)
        return M_CA_NOT_IOFFICER;
      else
        return apiRC;
    }

    strcpy(cor_nname, " ");
    if (strlen(trim(icorps)) != 0)
    {
      ipolicy8 = ipolicy[7];
      if (ipolicy8 <= 65)
      {
        $SELECT nname
            INTO $cor_nname
                FROM officer
                    WHERE iofficer = $icorps;
        if (SQLCODE == SQLNOTFOUND)
        {
          if (exitsub(reply, M_CA_NOT_ICORPS) == True)
            return M_CA_NOT_ICORPS;
          else
            return apiRC;
        }
      }
    }

    $SELECT nbranch
        INTO $quo_nname
            FROM sa_branch_type
                WHERE ibranch = $iquota;
    if (SQLCODE == SQLNOTFOUND)
    {
      if (exitsub(reply, M_CA_NOT_IQUOTA) == True)
        return M_CA_NOT_IQUOTA;
      else
        return apiRC;
    }

    $SELECT nname
        INTO $lead_nname
            FROM officer
                WHERE iofficer = $ileader;
    if (SQLCODE == SQLNOTFOUND)
    {
      if (exitsub(reply, M_CA_NOT_ILEADER) == True)
        return M_CA_NOT_ILEADER;
      else
        return apiRC;
    }

    strcpy(nchi_abv, "");

    $SELECT ncode
        INTO $nresource
            FROM cu_code_data
                WHERE itype = '10' AND icode = $iresource;
    if (SQLCODE == SQLNOTFOUND)
    {
      if (exitsub(reply, M_CA_NOT_IRESOURCE) == True)
        return M_CA_NOT_IRESOURCE;
      else
        return apiRC;
    }

    /* �H���᪺�q���N����q���W�� */
    $SELECT nroute[1, 10] INTO $route_nname
        FROM cm_route
            WHERE iroute = $iroute;
    if (SQLCODE == SQLNOTFOUND)
    {
      if (exitsub(reply, M_CMN_NROUTE) == True)
        return M_CMN_NROUTE;
      else
        return apiRC;
    }
  }
  else
  {
    strcpy(fedr_class, " ");
    strcpy(dendorse, " ");
    strcpy(iofficer, " ");
    strcpy(icorps, " ");
    strcpy(iquota, " ");
    strcpy(ileader, " ");
    strcpy(ibroker, " ");
    strcpy(iresource, " ");
    strcpy(off_nname, " ");
    strcpy(cor_nname, " ");
    strcpy(quo_nname, " ");
    strcpy(lead_nname, " ");
    strcpy(nchi_abv, " ");
    strcpy(nresource, " ");
  }

  cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
             fedr_class, dendorse, iofficer, iroute, icorps,
             iquota, ileader, ibroker, iresource, ioffice, isales,
             off_nname, route_nname, cor_nname, quo_nname, lead_nname, nchi_abv, nresource,
             irate_type, bzfrom, iroute_comm, icomm_obj, ireg_no);

  $SELECT count(*)
      INTO $ins_cnt
          FROM edr_ins_type
              WHERE iendorse = $iendorse1;
  if (ins_cnt == 0)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }

  printf("ins_cnt[%d]\n", ins_cnt);
  cm_buf_put("%l", ins_cnt);

  sprintf(stmt,
          " SELECT pcommission, medr_commission, pagent, medr_agent  \
       FROM edr_ins_type                                      \
      WHERE iendorse = ?                                      \
        AND iins_type = ? ");
  $PREPARE new_ins FROM $stmt;

  $DECLARE ins_bak CURSOR FOR
      SELECT a.iins_type,
      a.pdiscount, a.mdiscount, a.mins_premium,
      a.pcommission, a.mcommission, a.pagent, a.magent FROM ply_ins_type_bak a, edr_ins_type b WHERE a.ipolicy = $ipolicy AND a.iendorse = $iendorse1 AND a.iins_type = b.iins_type AND a.iendorse = b.iendorse;
  $OPEN ins_bak;
  for (;;)
  {
    $FETCH ins_bak
        INTO $iins_type,
        $pdiscount, $mdiscount, $mins_premium,
        $pcommission, $mcommission, $pagent, $magent;
    if (SQLCODE == SQLNOTFOUND)
      break;

    printf(" end ins_bak \n");
    printf(" iins_type[%s]\n", iins_type);

    if (iiedr != 84)
    {
      strcpy(iendorse_tmp, iendorse2);
    }
    else
    {
      strcpy(iendorse_tmp, iendorse1);
    }
    $EXECUTE new_ins
        INTO $new_pcommission,
        $new_mcommission, $new_pagent, $new_magent USING $iendorse_tmp, $iins_type;
    printf(" end new_ins \n");
    if (SQLCODE == SQLNOTFOUND)
    {
      if (exitsub(reply, M_CM_NOT_FOUND) == True)
        return M_CM_NOT_FOUND;
      else
        return apiRC;
    }

    printf("INTO cursor \n");
    sprintf(tmp_pcommission, "%4.2f", pcommission);
    sprintf(tmp_pagent, "%4.2f", pagent);
    sprintf(tmp_pdiscount, "%4.2f", pdiscount);
    sprintf(new_tmp_pcommission, "%4.2f", new_pcommission);
    sprintf(new_tmp_pagent, "%4.2f", new_pagent);

    cm_buf_put("%s %s %l %l %s %l %s %l",
               iins_type, tmp_pdiscount, mdiscount, mins_premium,
               tmp_pcommission, mcommission, tmp_pagent, magent);
    cm_buf_put("%s %l %s %l",
               new_tmp_pcommission, new_mcommission, new_tmp_pagent, new_magent);
  }
  $CLOSE ins_bak;
  $FREE ins_bak;

  cm_buf_put("%s", ibroker_expire);

  iRtnLen = cm_buf_len(ReplyBuf);

  if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  /***
  return exitsub(reply, MsgCode) ? SQLCODE : apiRC;
  ***/
  return SQLCODE;
}

/***********************************************************************/
long car413_multiple_query(reply)
serverReply reply;
{
  char tmpbuf[4000];
  $char termWhere[80];
  int count = 0, iTmpLen = 0, iRtnLen = 0, replycnt = 0;
  $char cBuf[10];
  $char ipolicy[21], iendorse1[21], iendorse2[21];
  $char dendorse[11];
  $char sDB[3];
  $char iendorse1_A[21], iendorse1_B[21], iendorse2_A[21], iendorse2_B[21];
  int iedr;
  $char sWhere[1024], stmt[2048];

  cm_buf_get("%s", cDbName);
  cm_buf_get("%s %s %s %s", ipolicy, dendorse, iendorse1, iendorse2);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(cDbName) == False)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  strcpy(sDB, get_db(ipolicy));
  if (strncmp(sDB, "100", 3) == 0)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }

  if (db_select(sDB) == False)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  strcpy(iendorse1, trim(iendorse1));
  iedr = strlen(iendorse1) - 1;
  if (iendorse1[iedr] == '*')
  {
    iendorse1[iedr] = ' ';
    strcpy(iendorse1_A, iendorse1);
    iendorse1[iedr] = '~';
    strcpy(iendorse1_B, iendorse1);
  }
  else
  {
    strcpy(iendorse1_A, iendorse1);
    strcpy(iendorse1_B, iendorse1);
  }

  strcpy(iendorse2, trim(iendorse2));
  iedr = strlen(iendorse2) - 1;
  if (iendorse2[iedr] == '*')
  {
    iendorse2[iedr] = ' ';
    strcpy(iendorse2_A, iendorse2);
    iendorse2[iedr] = '~';
    strcpy(iendorse2_B, iendorse2);
  }
  else
  {
    strcpy(iendorse2_A, iendorse2);
    strcpy(iendorse2_B, iendorse2);
  }

  if (dendorse[0] == '*')
  {
    strcpy(sWhere, " ");
  }
  else
  {
    strcpy(dendorse, cm_to_infdate(dendorse));
    sprintf(sWhere, " AND date(a.dcreate) = '%s' ", dendorse); /* ����אּdcreate, dendorse�� null */
  }

  sprintf(stmt,
          "  SELECT UNIQUE a.ipolicy, a.iendorse, b.iendorse, a.dendorse \
      FROM edr_relation a,edr_relation b,edr_ins_type c    \
     WHERE a.ipolicy = b.ipolicy                           \
       AND a.iendorse between '%s' and '%s'                \
       AND b.iendorse between '%s' and '%s'                \
       AND date(a.dcreate) = date(b.dcreate)               \
       AND a.fedr_class IN ('A','B')                       \
       AND b.fedr_class IN ('A','B')                       \
       AND b.iendorse = c.iendorse                         \
       AND c.iedr_type != '84'                             \
       AND a.iendorse < b.iendorse                         \
       AND a.ipolicy matches '%s' %s                       \
     UNION                                                 \
    SELECT UNIQUE a.ipolicy, a.iendorse, ' ', a.dendorse   \
      FROM edr_relation a,edr_ins_type b                   \
     WHERE a.iendorse = b.iendorse                         \
       AND b.iedr_type = '84'                              \
       AND a.fedr_class = 'B'                              \
       AND a.ipolicy matches '%s' %s  ",
          iendorse1_A, iendorse1_B, iendorse2_A, iendorse2_B, ipolicy, sWhere, ipolicy, sWhere);
  printf("stmt[%s]\n", stmt);
  $PREPARE muid1 FROM $stmt;
  $DECLARE muid_cur CURSOR FOR muid1;
  $OPEN muid_cur;
  for (;;)
  {
    $FETCH muid_cur
        INTO $ipolicy,
        $iendorse1, $iendorse2, $dendorse;
    if (SQLCODE == SQLNOTFOUND)
      break;
    strcpy(dendorse, cm_from_infdate_100(dendorse));
    cm_buf_init(tmpbuf);

    if (count == 0)
    {
      cm_buf_res_msg(); /* reserve for MsgCode and count */
      cm_buf_res_count();
    }
    cm_buf_put("%s %s %s %s", ipolicy, dendorse, iendorse1, iendorse2);
    iTmpLen = cm_buf_len(tmpbuf);

    if (iTmpLen + iRtnLen < 3000)
    {
      memcpy(&ReplyBuf[iRtnLen], tmpbuf, iTmpLen);
      iRtnLen += iTmpLen;
      count++;
    }
    else
    {
      cm_buf_init(ReplyBuf); /* more than 4K, send to client side */
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OK) == False)
      {
        $CLOSE muid_cur;
        return apiRC;
      }
      else
      {

        replycnt++; /* clear ReplyBuf and count to start all over again */
        if (replycnt == 10)
        {
          cm_buf_init(ReplyBuf); /* more than 30K, client cannot display */
          cm_buf_put("%l", M_CM_OUT_SPACE);
          iTmpLen = cm_buf_len(ReplyBuf);
          if (SendSyncReply(reply, ReplyBuf, iTmpLen, api_OKComplete) == False)
            return apiRC;
          return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg(); /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s %s", ipolicy, dendorse, iendorse1, iendorse2);
        iRtnLen = cm_buf_len(ReplyBuf);
        count++;
      }
    }
  }
  $CLOSE muid_cur;
  $FREE muid_cur;

  if (count > 0)
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False)
      return apiRC;
    return api_OKComplete;
  }
  else
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True) /*?*/
      return M_CM_NOT_FOUND;                    /*?*/
    else
      return apiRC;
  }

errexit:
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

/* �d�߸g��N�� */
long car413_iofficer(reply)
serverReply reply;
{
  char tmpbuf[4000];
  $char termWhere[80];
  int count = 0, iTmpLen = 0, iRtnLen = 0, replycnt = 0;
  $char cBuf[10];
  $char iofficer_1[11], iofficer_2[11];
  int lenA;
  $char iofficer[11], nname[11];
  $char sWhere[1000];

  cm_buf_get("%s %s %s", cDbName, iofficer_1, iofficer_2);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(cDbName) == False)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  strcpy(iofficer_1, trim(iofficer_1));
  lenA = strlen(iofficer_1) - 1;
  if (iofficer_1[lenA] == '*')
    iofficer_1[lenA] = ' ';

  strcpy(iofficer_2, trim(iofficer_2));
  lenA = strlen(iofficer_2) - 1;
  if (iofficer_2[lenA] == '*')
    iofficer_2[lenA] = '~';

  printf("iofficer_1[%s]\n", iofficer_1);
  printf("iofficer_2[%s]\n", iofficer_2);

  if (g_option == '1')
  {
    strcpy(sWhere, " AND fprop NOT IN ('4','5','6','J') ");
  }
  else if (g_option == '2')
  {
    strcpy(sWhere, " AND fprop IN ('4','5','6','J') ");
  }
  else
  {
    strcpy(sWhere, " AND fprop = '0' ");
  }

  sprintf(stmt,
          " SELECT iofficer,nname       \
       FROM officer              \
      WHERE iofficer BETWEEN '%s' AND '%s'  \
        %s                         \
      ORDER BY 1 ",
          iofficer_1, iofficer_2, sWhere);
  printf("stmt[%s]\n", stmt);
  $PREPARE iofficer_id FROM $stmt;
  $DECLARE off_cur CURSOR FOR iofficer_id;
  $OPEN off_cur;
  while (1)
  {
    $FETCH off_cur INTO $iofficer, $nname;

    if (SQLCODE == SQLNOTFOUND)
      break;

    cm_buf_init(tmpbuf);

    if (count == 0)
    {
      cm_buf_res_msg(); /* reserve for MsgCode and count */
      cm_buf_res_count();
    }
    cm_buf_put("%s %s", iofficer, nname);
    iTmpLen = cm_buf_len(tmpbuf);

    if (iTmpLen + iRtnLen < 3000)
    {
      memcpy(&ReplyBuf[iRtnLen], tmpbuf, iTmpLen);
      iRtnLen += iTmpLen;
      count++;
    }
    else
    {
      cm_buf_init(ReplyBuf); /* more than 4K, send to client side */
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OK) == False)
      {
        $CLOSE off_cur;
        return apiRC;
      }
      else
      {

        replycnt++; /* clear ReplyBuf and count to start all over again */
        if (replycnt == 20)
        {
          cm_buf_init(ReplyBuf); /* more than 30K, client cannot display */
          cm_buf_put("%l", M_CM_OUT_SPACE);
          iTmpLen = cm_buf_len(ReplyBuf);
          if (SendSyncReply(reply, ReplyBuf, iTmpLen, api_OKComplete) == False)
            return apiRC;
          return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg(); /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s", iofficer, nname);
        iRtnLen = cm_buf_len(ReplyBuf);
        count++;
      }
    }
  }
  $CLOSE off_cur;

  if (count > 0)
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False)
      return apiRC;
    return api_OKComplete;
  }
  else
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True) /*?*/
      return M_CM_NOT_FOUND;                    /*?*/
    else
      return apiRC;
  }

errexit:
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

/* �d�߳q���N�� */
long car413_iroute(reply)
serverReply reply;
{
  char tmpbuf[4000];
  $char termWhere[80];
  int count = 0, iTmpLen = 0, iRtnLen = 0, replycnt = 0;
  $char cBuf[10];
  $char iroute_1[21], iroute_2[21];
  int lenA;
  $char iroute[21], nname[41];
  $char sWhere[1000];

  cm_buf_get("%s %s %s", cDbName, iroute_1, iroute_2);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(cDbName) == False)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  strcpy(iroute_1, trim(iroute_1));
  lenA = strlen(iroute_1) - 1;
  if (iroute_1[lenA] == '*')
    iroute_1[lenA] = ' ';

  strcpy(iroute_2, trim(iroute_2));
  lenA = strlen(iroute_2) - 1;
  if (iroute_2[lenA] == '*')
    iroute_2[lenA] = '~';

  printf("iroute_1[%s]\n", iroute_1);
  printf("iroute_2[%s]\n", iroute_2);

  sprintf(stmt,
          " SELECT iroute,trim(nroute[1,40]) \
       FROM cm_route                      \
      WHERE iroute BETWEEN '%s' AND '%s'  \
      ORDER BY 1 ",
          iroute_1, iroute_2);
  printf("stmt[%s]\n", stmt);
  $PREPARE iroute_id FROM $stmt;
  $DECLARE route_cur CURSOR FOR iroute_id;
  $OPEN route_cur;
  while (1)
  {
    $FETCH route_cur INTO $iroute, $nname;

    if (SQLCODE == SQLNOTFOUND)
      break;

    cm_buf_init(tmpbuf);

    if (count == 0)
    {
      cm_buf_res_msg(); /* reserve for MsgCode and count */
      cm_buf_res_count();
    }
    cm_buf_put("%s %s", iroute, nname);
    iTmpLen = cm_buf_len(tmpbuf);

    if (iTmpLen + iRtnLen < 3000)
    {
      memcpy(&ReplyBuf[iRtnLen], tmpbuf, iTmpLen);
      iRtnLen += iTmpLen;
      count++;
    }
    else
    {
      cm_buf_init(ReplyBuf); /* more than 4K, send to client side */
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OK) == False)
      {
        $CLOSE route_cur;
        return apiRC;
      }
      else
      {

        replycnt++; /* clear ReplyBuf and count to start all over again */
        if (replycnt == 20)
        {
          cm_buf_init(ReplyBuf); /* more than 30K, client cannot display */
          cm_buf_put("%l", M_CM_OUT_SPACE);
          iTmpLen = cm_buf_len(ReplyBuf);
          if (SendSyncReply(reply, ReplyBuf, iTmpLen, api_OKComplete) == False)
            return apiRC;
          return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg(); /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s", iroute, nname);
        iRtnLen = cm_buf_len(ReplyBuf);
        count++;
      }
    }
  }
  $CLOSE route_cur;

  if (count > 0)
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False)
      return apiRC;
    return api_OKComplete;
  }
  else
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True) /*?*/
      return M_CM_NOT_FOUND;                    /*?*/
    else
      return apiRC;
  }

errexit:
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

long car413_iquota(reply)
serverReply reply;
{
  char tmpbuf[4000];
  $char termWhere[80];
  int count = 0, iTmpLen = 0, iRtnLen = 0, replycnt = 0;
  $char cBuf[10];
  $char iquota_1[11], iquota_2[11];
  int lenA;
  $char ibranch[11], nbranch[41];
  $char sWhere[1000];

  cm_buf_get("%s %s %s", cDbName, iquota_1, iquota_2);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(cDbName) == False)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  strcpy(iquota_1, trim(iquota_1));
  lenA = strlen(iquota_1) - 1;
  if (iquota_1[lenA] == '*')
    iquota_1[lenA] = ' ';

  strcpy(iquota_2, trim(iquota_2));
  lenA = strlen(iquota_2) - 1;
  if (iquota_2[lenA] == '*')
    iquota_2[lenA] = '~';

  sprintf(stmt,
          " SELECT ibranch,nbranch      \
       FROM sa_branch_type       \
      WHERE ibranch between '%s' and '%s'  \
      ORDER BY 1 ",
          iquota_1, iquota_2);

  printf("stmt[%s]\n", stmt);
  $PREPARE iquota_id FROM $stmt;
  $DECLARE quo_cur CURSOR FOR iquota_id;
  $OPEN quo_cur;
  while (1)
  {
    $FETCH quo_cur INTO $ibranch, $nbranch;
    if (SQLCODE == SQLNOTFOUND)
      break;

    cm_buf_init(tmpbuf);

    if (count == 0)
    {
      cm_buf_res_msg(); /* reserve for MsgCode and count */
      cm_buf_res_count();
    }
    cm_buf_put("%s %s", ibranch, nbranch);
    iTmpLen = cm_buf_len(tmpbuf);

    if (iTmpLen + iRtnLen < 3000)
    {
      memcpy(&ReplyBuf[iRtnLen], tmpbuf, iTmpLen);
      iRtnLen += iTmpLen;
      count++;
    }
    else
    {
      cm_buf_init(ReplyBuf); /* more than 4K, send to client side */
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OK) == False)
      {
        $CLOSE quo_cur;
        return apiRC;
      }
      else
      {

        replycnt++; /* clear ReplyBuf and count to start all over again */
        if (replycnt == 20)
        {
          cm_buf_init(ReplyBuf); /* more than 30K, client cannot display */
          cm_buf_put("%l", M_CM_OUT_SPACE);
          iTmpLen = cm_buf_len(ReplyBuf);
          if (SendSyncReply(reply, ReplyBuf, iTmpLen, api_OKComplete) == False)
            return apiRC;
          return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg(); /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s", ibranch, nbranch);
        iRtnLen = cm_buf_len(ReplyBuf);
        count++;
      }
    }
  }
  $CLOSE quo_cur;

  if (count > 0)
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False)
      return apiRC;
    return api_OKComplete;
  }
  else
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True) /*?*/
      return M_CM_NOT_FOUND;                    /*?*/
    else
      return apiRC;
  }

errexit:
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

long car413_get_ipolicy(reply)
serverReply reply;
{
  long MsgCode;
  $char cBuf[10];
  $char sDB[3];
  $int diff_iquota, diff_leader;
  $char ipolicy[21];
  $char nassured[121], dpolicy[11], ibroker[11], ileader[11];
  $char iquota[7], icorps[11];
  $char iofficer[11], fedr_class[2];
  $char iins_type[INSURANCE_TYPE];
  $long mdiscount;
  $long mins_premium;
  $double pcommission, pagent;
  $double pdiscount;
  $long mcommission, magent;
  $char off_nname[11], route_nname[11], cor_nname[11];
  $char quo_nname[41], lead_nname[11];
  $char nchi_abv[13];
  $int ins_cnt;
  $char tmp_pdiscount[8];
  $char tmp_pcommission[8];
  $char tmp_pagent[8];
  $char iresource[2];
  $char nresource[21];
  $char fcard_class[2];
  $int flag_33;
  $char iinsurant[11];
  $char iins_scope[2];
  $char icareer[2];
  $char sOption[2];
  $char ipolicy_tp[21];
  $char nequipment[31];
  $char imgr[2];
  $char fassured[2];
  $char icar_type[5];
  $char ipolicy8;
  $int qply_period;
  $long mbusiness;
  $long mcommi, rc;
  $char dexpire_m[2], dexpire[11], ibroker_expire[2], drate_ym[5];
  $int clm_cnt = 0, gcom_cnt = 0;
  char iquota_flag[2], ileader_flag[2], claim_flag[2], gcom_flag[2];
  $char iassured[13];

  /* dws9807212�s�W�q�� */
  $char ioffice[10], isales[11], iroute[21], flag_route[2];
  char resource_rel[3];

  /* 1000311003 �q��2 */
  $char irate_type[2], bzfrom[3], iroute_comm[4], icomm_obj[11], opt[2];

  $char dply_begin[11], dply_end[11], dentry[11];
  $char equipdecode[201];
  $char dcreate_max[31], ireg_no[21], iscan_no[26]; /* 1101018008_SC2 �q�lñ�ݱ��y�s������X�W��25�X */
  $char fenterprise[2] = "N";
  $char s_dbirth[11], s_dbirth_appl[11];

  diff_iquota = 0;
  diff_leader = 0;
  pdiscount = 0;
  mdiscount = 0;
  mins_premium = 0;
  pcommission = 0;
  pagent = 0;
  mcommission = 0;
  magent = 0;
  flag_33 = 0;
  strcpy(flag_route, "N");

  cm_buf_get("%s %s %s", cDbName, sOption, ipolicy_tp);
  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(cDbName) == False)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  /** �ϥΫO�d **/
  if (sOption[0] != '1')
  {
    $SELECT ipolicy
        INTO $ipolicy
            FROM assured_vs_ply
                WHERE icard = $ipolicy_tp;
    if (SQLCODE == SQLNOTFOUND)
    {
      if (exitsub(reply, M_CM_NOT_FOUND) == True)
        return M_CM_NOT_FOUND;
      else
        return apiRC;
    }
  }
  else
  {
    strcpy(ipolicy, ipolicy_tp);
  }

  strcpy(sDB, get_db(ipolicy));
  if (strncmp(sDB, "100", 3) == 0)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }

  printf("sDB[%s]\n", sDB);

  if (db_select(sDB) == False)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  /*1110926004_SC1 CAR401�PCAR413���ˮְ���(65��)�ҵ{�O�_���V���ݨD*/
  $SELECT a.iofficer, a.icorps, a.iquota, a.ileader, a.ibroker, a.dpolicy, b.nassured,a.fedr_class,
          a.iresource, a.fcard_class, b.nequipment, b.fassured, a.icar_type, a.qply_period,
          (a.mbus_rule - a.mbusiness), a.mdmg_commi + a.mlia_commi, a.ibig_office, a.ibig_sales,
          b.iassured, b.iroute, a.irate_type, a.bzfrom, a.iroute_comm, a.icomm_obj, dply_begin, dply_end, 
          dentry, nequipment, a.ireg_no, a.iscan_no, nvl(b.dbirth,' '), nvl(b.dbirth_appl,' ')
     INTO $iofficer, $icorps, $iquota, $ileader, $ibroker, $dpolicy, $nassured, $fedr_class,
          $iresource, $fcard_class, $nequipment, $fassured, $icar_type, $qply_period,
          $mbusiness, $mcommi, $ioffice, $isales,
          $iassured, $iroute, $irate_type, $bzfrom, $iroute_comm, $icomm_obj,$dply_begin, $dply_end,
          $dentry, $nequipment, $ireg_no, $iscan_no , $s_dbirth, $s_dbirth_appl
     FROM ply_relation a, policy b 
    WHERE a.ipolicy = b.ipolicy 
      AND a.ipolicy = $ipolicy 
      AND a.dply_close IS NOT NULL;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }
  strcpy(dpolicy, cm_from_infdate_100(dpolicy));

  if (fedr_class[0] == '1')
  {
    if (mcommi == 0)
    {
      if (exitsub(reply, M_CA_PLY_CANCEL) == True)
        return M_CA_PLY_CANCEL;
      else
        return apiRC;
    }
  }
  /* bis9901141 �Q�O�I�H���g�Ѧ@��function�T�{�~�ȩʽ謰
               ���Y���~(8),��O�t��(7),���h�श(G),��L���h�O���ª��~�ȩʽ�P�_�޿� */
  rc = cm_get_assured_resource("C", iassured, iofficer, resource_rel);
  if (rc != TRUE)
  {
    strcpy(resource_rel, " ");
  }
  /* end if bis9901141 */

  strcpy(ibroker_expire, "N");

  /* �I����H�O�_����O */
  strcpy(opt, "5");
  rc = cm_chk_policy(opt, "", "", "", icomm_obj, "", "", "");

  if (rc == M_CMN_COMM_OBJ_EXPIRE) /* �I����H����O */
  {
    strcpy(ibroker_expire, "Y");
  }
  else if (rc != M_CM_OK)
  {
    if (exitsub(reply, rc) == True)
      return rc;
    else
      return apiRC;
  }

  /* ��l�O�椧�~�Z���P��椧�~�Z��줣�P(N),�ۦP��(Y) */
  $SELECT count(*)
     INTO $diff_iquota
     FROM ori_ply_relation a, edr_relation b
    WHERE a.ipolicy = b.ipolicy
      AND a.iquota[1, 4] != b.iquota[1, 4] 
      AND a.ipolicy = $ipolicy;
  if (diff_iquota != 0)
    strcpy(iquota_flag, "N");
  else
    strcpy(iquota_flag, "Y");

  /* ��l�O�椧�޲z�H�P��椧�޲z�H���P(N),�ۦP��(Y) */
  $SELECT count(*)
     INTO $diff_leader
     FROM ori_ply_relation a, edr_relation b
    WHERE a.ipolicy = b.ipolicy
      AND a.ileader != b.ileader
      AND a.ipolicy = $ipolicy
      AND b.fedr_class != 'A';
  if (diff_leader != 0)
    strcpy(ileader_flag, "N");
  else
    strcpy(ileader_flag, "Y");

  /* �T�{�O�_���z��(���z��=>Y;�L�z��=> N) */
  $SELECT count(*) INTO $clm_cnt
     FROM appraisal
    WHERE ipolicy = $ipolicy;
  if (clm_cnt != 0)
    strcpy(claim_flag, "Y");
  else
    strcpy(claim_flag, "N");

  /* �T�{�����O�_�w�J�p(�w�J�p=>Y; ���J�p=>N) */
  $SELECT count(*) INTO $gcom_cnt
     FROM ao_officer_commit
    WHERE fstatus not in('N', 'F')
      AND ipolicy1 = $ipolicy;
  if (gcom_cnt != 0)
    strcpy(gcom_flag, "Y");
  else
    strcpy(gcom_flag, "N");

  /*1100118005_SC2 �j���I�����~���u�f���B�վ�,�s�W�^�� fenterprise(���~�Ю׵��O) */
  strcpy(off_nname, " ");
  strcpy(fenterprise, "N");
  $SELECT nname, imgr, fenterprise INTO $off_nname, $imgr, $fenterprise 
     FROM officer 
    WHERE iofficer = $iofficer;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CA_NOT_IOFFICER) == True)
      return M_CA_NOT_IOFFICER;
    else
      return apiRC;
  }

  strcpy(cor_nname, " ");
  if (strlen(trim(icorps)) != 0)
  {
    ipolicy8 = ipolicy[7];
    if (ipolicy8 <= 65)
    {
      $SELECT nname INTO $cor_nname
         FROM officer
        WHERE iofficer = $icorps;
      if (SQLCODE == SQLNOTFOUND)
      {
        if (exitsub(reply, M_CA_NOT_ICORPS) == True)
          return M_CA_NOT_ICORPS;
        else
          return apiRC;
      }
    }
  }

  /** �s���P�_�G���M����ˮ� car-9502103    dexpire_m = N ���ܤw���M**/

  $SELECT nbranch, case when today >= dexpire then 'N' else 'Y' end case 
     INTO $quo_nname, $dexpire_m 
     FROM sa_branch_type 
    WHERE ibranch = $iquota;

  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CA_NOT_IQUOTA) == True)
      return M_CA_NOT_IQUOTA;
    else
      return apiRC;
  }

  /** �ª��P�_�G��������ܸg��H�~�Z���w���M
  if( strlen(trim(dexpire)) > 0 )
  {
     strcpy(dexpire_m,"N");
  }
  else
     strcpy(dexpire_m,"Y");
  */

  $SELECT nname  INTO $lead_nname
     FROM officer
    WHERE iofficer = $ileader;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CA_NOT_ILEADER) == True)
      return M_CA_NOT_ILEADER;
    else
      return apiRC;
  }
  strcpy(nchi_abv, "");

  $SELECT ncode INTO $nresource
     FROM cu_code_data
    WHERE itype = '10' AND icode = $iresource;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CA_NOT_IRESOURCE) == True)
      return M_CA_NOT_IRESOURCE;
    else
      return apiRC;
  }
  printf("ireg_no[%s]\n", ireg_no);
  printf("iroute[%s]\n", iroute);
  strcpy(iroute, trim(iroute));
  /* �s�ǤJclient�ݤ@�ӰѼ�flag_route,�T�{�q���N���O�_�s�b(Y/N)��q���ɤ� */
  /* ��q���W�� */
  $SELECT nroute[1, 10] INTO $route_nname
     FROM cm_route
    WHERE iroute = $iroute;
  if (SQLCODE == SQLNOTFOUND)
  {
    /* ���e���O��q����Ƥ��ˬd */
    strcpy(route_nname, "");
    strcpy(flag_route, "N");
  }
  else
    strcpy(flag_route, "Y");

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
             M_CM_OK, ipolicy, nassured, resource_rel, dpolicy, iofficer, iroute, icorps,
             iquota, ileader, ibroker, iresource,
             off_nname, route_nname, cor_nname, quo_nname, lead_nname, nchi_abv, nresource,
             fcard_class);
  cm_buf_put("%s %s", nequipment, imgr);

  cm_buf_put("%s %s %s", ioffice, isales, flag_route);

  /* 1000311003 �q��2 */
  cm_buf_put("%s %s %s %s %s %s", irate_type, bzfrom, iroute_comm, icomm_obj, ireg_no, iscan_no);

  ins_cnt = 0;
  $SELECT count(*) INTO $ins_cnt
     FROM ply_ins_type
    WHERE ipolicy = $ipolicy;

  cm_buf_put("%l", ins_cnt);

  flag_33 = 0;
  $DECLARE idtl_cur CURSOR FOR
      SELECT iins_type, pdiscount, mdiscount, mins_premium, pcommission, mcommission, pagent, magent, drate_ym 
        FROM ply_ins_type 
       WHERE ipolicy = $ipolicy;
  $OPEN idtl_cur;
  for (;;)
  {
    $FETCH idtl_cur
      INTO $iins_type, $pdiscount, $mdiscount, $mins_premium,
           $pcommission, $mcommission, $pagent, $magent, $drate_ym;
    if (SQLCODE == SQLNOTFOUND)
      break;

    if ((strcmp(trim(iins_type), "33") == 0) || (strcmp(trim(iins_type), "35") == 0) ||
        (strcmp(trim(iins_type), "48") == 0) || (strcmp(trim(iins_type), "56") == 0) ||
        (strcmp(trim(iins_type), "136") == 0) || (strcmp(trim(iins_type), "166") == 0) ||
        (strcmp(trim(iins_type), "266") == 0))
    {
      flag_33 = 1;
    }
    sprintf(tmp_pcommission, "%4.2f", pcommission);
    sprintf(tmp_pagent, "%4.2f", pagent);
    sprintf(tmp_pdiscount, "%4.2f", pdiscount);
    cm_buf_put("%s %s %l %l %s %l %s %l %s",
               iins_type, tmp_pdiscount, mdiscount, mins_premium,
               tmp_pcommission, mcommission, tmp_pagent, magent, drate_ym);
  }
  $CLOSE idtl_cur;
  $FREE idtl_cur;

  cm_buf_put("%l", flag_33);
  if (flag_33 == 1)
  {
    $SELECT count(*) INTO $ins_cnt
       FROM ca_pa_ply
      WHERE ipolicy = $ipolicy;

    cm_buf_put("%l", ins_cnt);

    $DECLARE pa_cur CURSOR FOR
        SELECT iins_type,iinsurant, iins_scope, icareer, mins_premium, pcommission,
               mcommission, pagent, magent, pdiscount, mdiscount 
          FROM ca_pa_ply 
         WHERE ipolicy = $ipolicy ORDER BY 1, 2, 3, 4;
    $OPEN pa_cur;
    for (;;)
    {
      $FETCH pa_cur
        INTO $iins_type, $iinsurant, $iins_scope, $icareer, $mins_premium, $pcommission,
             $mcommission, $pagent, $magent, $pdiscount, $mdiscount;
      if (SQLCODE == SQLNOTFOUND)
        break;
      sprintf(tmp_pcommission, "%4.2f", pcommission);
      sprintf(tmp_pagent, "%4.2f", pagent);
      sprintf(tmp_pdiscount, "%4.2f", pdiscount);
      cm_buf_put("%s %s %s %s %l %s %l %s %l %s %l",
                 iins_type, iinsurant, iins_scope, icareer, mins_premium,
                 tmp_pcommission, mcommission, tmp_pagent, magent,
                 tmp_pdiscount, mdiscount);
    }
    $CLOSE pa_cur;
    $FREE pa_cur;
  }
  cm_buf_put("%s ", fassured);
  cm_buf_put("%s ", icar_type);
  cm_buf_put("%l ", qply_period);

  cm_buf_put("%l ", mbusiness);
  cm_buf_put("%s ", dexpire_m);
  cm_buf_put("%s ", ibroker_expire);
  cm_buf_put("%s %s %s %s", iquota_flag, ileader_flag, claim_flag, gcom_flag);
  cm_buf_put("%s", flag_route);
  cm_buf_put("%s", dply_begin);
  cm_buf_put("%s", dply_end);
  cm_buf_put("%s", dentry);

  strcpy(equipdecode, equip_get(nequipment));
  cm_buf_put("%s", equipdecode);

  cm_buf_put("%s", fenterprise); /*1100118005_SC2 �j���I�����~���u�f���B�վ�*/
  cm_buf_put("%s", iassured);    /*1091127003_SC2 �Эק��O181�I(���j���l)���g��βνs�ݦbCAR140���@�ɳ]�w*/

  $select max(dcreate)
     into $dcreate_max
     from edr_relation
    where ipolicy = $ipolicy and iendorse not like '%CVP%';

  cm_buf_put("%s ", dcreate_max);
  cm_buf_put("%s %s", s_dbirth, s_dbirth_appl); /*1110926004_SC1 CAR401�PCAR413���ˮְ���(65��)�ҵ{�O�_���V���ݨD�ΨC�봣�ѳ���*/

  printf("qply_period [%d]\n", qply_period);
  iRtnLen = cm_buf_len(ReplyBuf);

  if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

long car413_get_iofficer(reply)
serverReply reply;
{
  long MsgCode;
  $char cBuf[10];
  $char iofficer[11];
  $char iquota[11], ileader[11];
  $char ibus_location[11];
  $char nname[11];
  $char icar_broker[11];
  $char fprop[2];
  $char ncode[21];
  $char tcode_remark[21];
  $char imgr[2];
  $char iins_cat[5];
  $char froute[2], fsales[2], iroute[5]; /* car9808043 �P�_�O�_���n��J�q���N���γq���~�ȭ� */
  char iofficer_expire[2];
  long rc1;

  cm_buf_get("%s %s %s", cDbName, iofficer, iins_cat);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(cDbName) == False)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  $SELECT iquota, ileader, nname, fprop INTO $iquota, $ileader, $nname, $fprop FROM officer WHERE iofficer = $iofficer AND fprop NOT IN('4', '5', '6', 'J');
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CA_NOT_IOFFICER) == True)
      return M_CA_NOT_IOFFICER;
    else
      return apiRC;
  }

  if (fprop[0] == '0')
  {
    strcpy(fprop, "3");
  }

  /*$SELECT ncode,tcode_remark
     INTO $ncode,$tcode_remark
     FROM cu_code_data
    WHERE itype = '10'
      AND icode = $fprop;
   if (SQLCODE == SQLNOTFOUND)
   {
       if(exitsub(reply,M_CA_NOT_IRESOURCE) == True )
          return M_CA_NOT_IRESOURCE;
       else
          return apiRC;
   }*/

  $SELECT icar_broker
      INTO $icar_broker
          FROM officer_broker
              WHERE iofficer = $iofficer;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CA_NOT_IBROKER) == True)
      return M_CA_NOT_IBROKER;
    else
      return apiRC;
  }

  /*
  $SELECT first 1 ipaid_base
     INTO $ipaid_base
     FROM commission_agent
    WHERE iins_cat = $iins_cat
      AND ibroker = $icar_broker;
    if (SQLCODE == SQLNOTFOUND)
    {
            $SELECT first 1 ipaid_base
               INTO $ipaid_base
               FROM commission_agent
              WHERE iins_cat = 'C'
                AND ibroker = $icar_broker;
            if (SQLCODE == SQLNOTFOUND)
            {
                if(exitsub(reply,M_CA_NOT_IBROKER) == True )
                    return M_CA_NOT_IBROKER;
                else
                    return apiRC;
            }
     }
  /* �s�g��N���O�_����,���Ϋh�^�аT���i�D�ϥΪ̸Ӹg��N���w����(Y),������(N)
    rc1 = chk_iofficer_expire( iofficer, v_sMsg);
    if (rc1 == M_CA_IOFFICER_EXPIRE)  strcpy(iofficer_expire,"Y");
    else strcpy(iofficer_expire,"N");        */

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s %s %s %s",
             M_CM_OK, nname, iquota, ileader, icar_broker, fprop);

  iRtnLen = cm_buf_len(ReplyBuf);

  if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

long car413_get_resource(reply)
serverReply reply;
{
  long MsgCode;
  $char cBuf[10];
  $char fprop[2];
  $char ncode[21];
  $char tcode_remark[21];
  $char iresource[2];

  cm_buf_get("%s %s", cDbName, iresource);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(cDbName) == False)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  $SELECT ncode, tcode_remark INTO $ncode, $tcode_remark FROM cu_code_data WHERE itype = '10' AND icode = $iresource;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CA_NOT_IRESOURCE) == True)
      return M_CA_NOT_IRESOURCE;
    else
      return apiRC;
  }

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s",
             M_CM_OK, ncode, tcode_remark);

  iRtnLen = cm_buf_len(ReplyBuf);

  if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

long car413_get_icorps(reply)
serverReply reply;
{
  long MsgCode;
  $char cBuf[10];
  $char iofficer[11];
  $char iquota[11], ileader[11];
  $char nbranch[41];
  $char nname[11];
  $char lead_nname[11];
  $char icar_broker[11];
  $char nchi_abv[13];
  $char icorps[11];
  $char ipaid_base[2];
  $char fprop[2];
  $char ncode[21];
  $char tcode_remark[21];
  $char iins_cat[5];
  $char sStmt[1024], corp_stmt[200];

  cm_buf_get("%s %s %s", cDbName, icorps, iins_cat);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(cDbName) == False)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  if (strcmp(trim(icorps), "RENEW1") == 0)
    strcpy(corp_stmt, " ");
  else
    strcpy(corp_stmt, "AND fprop IN ('4','5','6','J')");

  sprintf(sStmt, "SELECT nname,fprop FROM officer WHERE iofficer = ? %s", corp_stmt);

  printf("sStmt=[%s]\n", sStmt);

  $prepare get_off_corp from $sStmt;
  $execute get_off_corp into $nname, $fprop using $icorps;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CA_NOT_ICORPS) == True)
      return M_CA_NOT_ICORPS;
    else
      return apiRC;
  }

  if (fprop[0] == '0')
  {
    strcpy(fprop, "3");
  }

  $SELECT ncode, tcode_remark INTO $ncode, $tcode_remark FROM cu_code_data WHERE itype = '10' AND icode = $fprop;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CA_NOT_IRESOURCE) == True)
      return M_CA_NOT_IRESOURCE;
    else
      return apiRC;
  }

  $SELECT icar_broker
      INTO $icar_broker
          FROM officer_broker
              WHERE iofficer = $icorps;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CA_NCORPS) == True)
      return M_CA_NCORPS;
    else
      return apiRC;
  }

  strcpy(nchi_abv, "");

  /*$SELECT first 1 ipaid_base
   INTO $ipaid_base
   FROM commission_agent
  WHERE iins_cat = $iins_cat
    AND ibroker = $icar_broker;

  if (SQLCODE == SQLNOTFOUND)
  {
          $SELECT first 1 ipaid_base
             INTO $ipaid_base
             FROM commission_agent
            WHERE iins_cat = 'C'
              AND ibroker = $icar_broker;
          if (SQLCODE == SQLNOTFOUND)
          {
             if(exitsub(reply,M_CA_NOT_IBROKER) == True )
                return M_CA_NOT_IBROKER;
             else
                return apiRC;
          }
   }*/
  strcpy(ipaid_base, "");

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s %s %s %s %s %s",
             M_CM_OK, nname, icar_broker, nchi_abv, ipaid_base, fprop, ncode, tcode_remark);

  iRtnLen = cm_buf_len(ReplyBuf);

  if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

long car413_get_comp(reply)
serverReply reply;
{
  long MsgCode;
  $char cBuf[10], tmp_fulldb[20], stmt[1024];
  $char ibroker[11], iins_cat[5];
  $char sOption[2], ipolicy[21], ipolicy_tp[21];
  $long mservice;
  $int iyear, qply_period;

  cm_buf_get("%s %s %s %s %s", cDbName, ibroker, iins_cat, sOption, ipolicy_tp);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(cDbName) == False)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  if (sOption[0] != '1')
  {
    $SELECT ipolicy
        INTO $ipolicy
            FROM assured_vs_ply
                WHERE icard = $ipolicy_tp;
    if (SQLCODE == SQLNOTFOUND)
    {
      if (exitsub(reply, M_CM_NOT_FOUND) == True)
        return M_CM_NOT_FOUND;
      else
        return apiRC;
    }
  }
  else
  {
    strcpy(ipolicy, ipolicy_tp);
  }

  strcpy(tmp_fulldb, get_car_full_db(ipolicy));

  sprintf(stmt, "SELECT qply_period FROM %s:ply_relation \
                 WHERE ipolicy = '%s' AND dply_close IS NOT NULL",
          tmp_fulldb, ipolicy);
  $PREPARE get_period FROM $stmt;
  $EXECUTE get_period INTO $qply_period;
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CM_NOT_FOUND) == True)
      return M_CM_NOT_FOUND;
    else
      return apiRC;
  }

  iyear = 0;
  if (strcmp(iins_cat, "Z") == 0)
  {
    if (qply_period > 12)
      iyear = 2;
    else
      iyear = 1;
  }
  else
    iyear = 0;

  mservice = 0;
  $SELECT mservice
      INTO $mservice
          FROM commission_agent
              WHERE iins_cat = $iins_cat
                  AND ibroker = $ibroker
                      AND iyear = $iyear
                          AND iins_type = '21';
  if (SQLCODE == SQLNOTFOUND)
  {
    if (strncmp(iins_cat, "X", 1) == 0)
    {
      strcpy(ibroker, "000");
      strcpy(iins_cat, "X");
    }
    else
    {
      strcpy(iins_cat, "C");
    }
    $SELECT mservice
        INTO $mservice
            FROM commission_agent
                WHERE iins_cat = $iins_cat
                    AND ibroker = $ibroker
                        AND iyear = $iyear
                            AND iins_type = '21';
    if (SQLCODE == SQLNOTFOUND)
    {
      if (exitsub(reply, M_CA_NCOMMION_FILE) == True)
        return M_CA_NCOMMION_FILE;
      else
        return apiRC;
    }
  }

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %l",
             M_CM_OK, mservice);

  iRtnLen = cm_buf_len(ReplyBuf);

  if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

long car413_get_com_age(reply)
serverReply reply;
{
  long MsgCode;
  $char cBuf[10];
  $long mservice;
  $char ibroker[11];

  cm_buf_get("%s %s", cDbName, ibroker);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(cDbName) == False)
    return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  mservice = 0;
  $SELECT mservice
      INTO $mservice
          FROM commission_agent
              WHERE iins_cat = 'C' AND ibroker = $ibroker
                  AND iins_type = '21';
  if (SQLCODE == SQLNOTFOUND)
  {
    if (exitsub(reply, M_CA_NCOMMION_FILE) == True)
      return M_CA_NCOMMION_FILE;
    else
      return apiRC;
  }

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %l",
             M_CM_OK, mservice);

  iRtnLen = cm_buf_len(ReplyBuf);

  if (SendSyncReply(reply, ReplyBuf, iRtnLen, api_OKComplete) == False)
    return apiRC;
  else
    return api_OKComplete;

errexit:
  if (exitsub(reply, SQLCODE) == True)
    return SQLCODE;
  else
    return apiRC;
}

/*********************************************************/
/* get db list */
char *get_db(sIpolicy)
char *sIpolicy;
{
  $char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  $char sTmp_db_name[21];
  char rtnd[11];

  $WHENEVER SQLERROR GOTO errexit;

  sTmp_db_name[0] = '\0';
  if (*sIpolicy != '\0' && *sIpolicy != ' ')
  {
    sTmp_db_name[0] = '\0';
    strncpy(sTmpScomp, sIpolicy + 2, 1);
    sTmpScomp[1] = '\0';
    printf("sTmpScomp = %s\n", sTmpScomp);
    $SELECT iupcomp
        INTO $sTmpcomp
            FROM branch
                WHERE ibranch_abbr = $sTmpScomp;
    if (SQLCODE == SQLNOTFOUND)
    {
      strcpy(rtnd, itoa(SQLCODE));
      goto errexit;
    }
    /*
    strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
           USE_BRANCH_ID));
    */
    printf("sTmpcomp = %s\n", sTmpcomp);
    strcpy(sTmp_db_name, sTmpcomp);
  }
  return sTmp_db_name;

errexit:
  return rtnd;
}

/* �g���N���w�g���ΥB���O������ */
long insert_edr(sDB, ipolicy, policy_1, policy_2, temp, temp1, fpay, fedr_class,
                iedr_type1, iedr_type2, iresource, ibig_office, ibig_sales, ori_ibroker,
                ibroker, iofficer, iroute, ileader, icorps, iquota, iquota_dissolve,
                ibus_location, userid, icomp_at, ibranch_at, dwritten, ori_fcard_class,
                iofficer_prmt, iquota_prmt, ileader_prmt, b_iroute, irate_type, bzfrom, iroute_comm, icomm_obj, ibig_comp, ireg_no, reply)
$char *sDB;
$char *ipolicy, *policy_1, *policy_2, *temp, *temp1, *fedr_class, *fpay, *iedr_type1, *iedr_type2;
$char *ibig_office, *ibig_sales, *iresource, *ibroker, *iofficer, *iroute, *ileader, *icorps, *iquota;
$char *iquota_dissolve, *ibus_location;
$char *userid, *icomp_at, *ibranch_at, *ori_ibroker, *ori_fcard_class;
$date dwritten;
$char *iofficer_prmt, *iquota_prmt, *ileader_prmt;
$char *b_iroute;
$char *irate_type, *bzfrom, *iroute_comm, *icomm_obj, *ibig_comp, *ireg_no;
serverReply reply;
{
  $char iins_type[7], sIpolicy[21], sIendorse[21], stmt[10000];
  $char ply[21], strpay[2], tmp_iins_type[7], iendorse_tmp[21];
  $long mins_premium, mcommission, magent;
  $long minjured_cover, mins_amt, mdmg_prem, medrins_prem, medrpure_prem;
  $long mdeath_cover, mpure_prem, mlia_prem, medr_commission, mdrunk_prem, mviolate_prem;
  $double mdrunk_pure_prem, mviolate_pure_prem;
  $long mdamage_cover, medr_agent, mdeduct, mdiscount;
  $long g_mcommission, g_magent, mprem, qday, mdmg_agent;
  $double pdiscount, g_pcommission, mdmg_pure_prem, mlia_pure_prem;
  $double g_pagent, mready, mstable, mcompensation, madjcom_prem;
  $int cnt, qserial, iedr_cnt, ipa_cnt;
  $char fins_grp[2], iinsurant[11], drate_ym[5], iins_scope[2];
  $char icareer[2], iproduct[13], ipaid_base[2], provision[21];
  $long mexpense, mdmg_commi, mexp_disc, mlia_agent, mdmg_discount;
  $double mresearch, minvest, mbus_rule, mcapital, maintain;
  $double mbusiness;
  $long mlia_commi, mlia_discount;
  $int edrrel_qcount, edrins_qcount;
  $long tmp_mins_premium, tmp_mpure_prem, tmp_mcommission, tmp_magent;
  $long sum_mdmg_commi, sum_mdmg_agent, sum_mlia_commi, sum_mlia_agent; /* �p���J�̷s�O���ɪ������N�z�v */
  $long mlia_pureprem, mdmg_pureprem;                                   /* �Ψө�m�O�O��� */
  $long sum_mdmg_prem, sum_mdmg_pureprem, sum_mlia_prem, sum_mlia_pureprem;
  $long bk_mins_prem, bk_pure_prem, ply_mdmgprem, ply_mdmgpure, ply_mliaprem, ply_mliapure, bk_mdrunk_prem, bk_mviolate_prem;
  $double bk_mdrunk_pure_prem, bk_mviolate_pure_prem;
  $long neg_mcommission, neg_magent;
  $long neg_mdmg_commi, neg_mdmg_agent, neg_mlia_commi, neg_mlia_agent;
  $double pbusiness_new, pdiscount_new, pextra_charge_new, pbusiness, pextra_charge;
  $char sCCC1[101], sCCC2[101], sCCC3[101], f980401[2];
  double rCCC1, rCCC2, rCCC3;
  $long minus_mdmg_agent, minus_mdmg_commi, minus_mdmg_prem, minus_mdmg_pureprem;
  $long minus_mlia_agent, minus_mlia_commi, minus_mlia_prem, minus_mlia_pureprem;

  char sMcommission[21], sMagent[21], sMcommission1[21], sMagent1[21];
  char sMdmg_commi[21], sMlia_commi[21], sMdmg_agent[21], sMlia_agent[21];
  char sMedrins_prem1[21], sMedrpure_prem1[21], sMdrunk_prem1[21], sMdrunk_pure_prem1[21], sMviolate_prem1[21], sMviolate_pure_prem1[21];
  long rc, MsgCode;
  int i = 0;
  char old_ply[21], old_iins_type[7];

  $long tmp_iedr, tmp_prem;
  $char tmp_iendorse[21];
  $char iabn_type[2], comp_frate[6], iroute_accept_edr[21];
  int v_iins;

  /* initialize variables begins */
  mins_premium = mcommission = magent = 0;
  minjured_cover = mins_amt = mdmg_prem = medrins_prem = 0;
  mdeath_cover = mpure_prem = mlia_prem = medr_commission = 0;
  mdamage_cover = medr_agent = mdeduct = mdiscount = 0;
  g_mcommission = g_magent = mprem = qday = mdmg_agent = 0;
  pdiscount = g_pcommission = mdmg_pure_prem = mlia_pure_prem = 0;
  g_pagent = mready = mstable = mcompensation = madjcom_prem = 0;
  cnt = qserial = iedr_cnt = ipa_cnt = 0;
  mexpense = mdmg_commi = mexp_disc = mlia_agent = mdmg_discount = 0;
  mresearch = minvest = mbus_rule = mcapital = maintain = 0;
  mbusiness = 0;
  mlia_commi = mlia_discount = 0;
  edrrel_qcount = edrins_qcount = 0;
  tmp_mins_premium = tmp_mpure_prem = tmp_mcommission = tmp_magent = 0;
  mdmg_prem = mdmg_pureprem = mlia_prem = mlia_pureprem = 0;
  sum_mdmg_prem = sum_mdmg_pureprem = sum_mlia_prem = sum_mlia_pureprem = 0;
  bk_mins_prem = bk_pure_prem = ply_mdmgprem = ply_mdmgpure = ply_mliaprem = ply_mliapure = 0;
  neg_mcommission = neg_magent = 0;
  neg_mdmg_commi = neg_mdmg_agent = neg_mlia_commi = neg_mlia_agent = 0;
  /* initalize variables ends */

  $CREATE TEMP TABLE MAIN_IINS(ipolicy char(20),
                               iendorse char(20),
                               iins_type char(6),
                               paid char(1),
                               mins_premium integer,
                               mpure_prem decimal(11, 4),
                               mcommission integer,
                               magent integer,
                               mdrunk_prem integer,
                               mdrunk_pure_prem decimal(11, 4),
                               mviolate_prem integer,
                               mviolate_pure_prem decimal(11, 4)) with no log;

  $CREATE TEMP TABLE IINS_POL(iins_type char(6),
                              mcommission integer,
                              magent integer,
                              pcommission decimal(4, 2),
                              pagent decimal(4, 2),
                              ipaid_base char(1)) with no log;
  $CREATE INDEX IINS_POL_idx1 on IINS_POL(iins_type);

  $CREATE TEMP TABLE IINS_PA(iins_type char(6),
                             iinsurant char(10),
                             iins_scope char(1),
                             icareer char(1),
                             mcommission integer,
                             magent integer,
                             pcommission decimal(4, 2),
                             pagent decimal(4, 2)) with no log;
  $CREATE INDEX IINS_PA_idx1 on IINS_PA(iins_type);

  printf("start to get dpay.................\n");

  /* ���Nclient�ҶǦ^�Ӫ��I��,����(�v),�N�z�O(�v)���temp table */
  /* �ˮ`�I����bIINS_PA,��L����bIINS_POL */
  cm_buf_get("%l", &iedr_cnt);

  for (i = 0; i < iedr_cnt; i++)
  {
    cm_buf_get("%s", tmp_iins_type);
    cm_buf_get("%e", &g_pcommission);
    cm_buf_get("%l", &g_mcommission);
    cm_buf_get("%e", &g_pagent);
    cm_buf_get("%l", &g_magent);
    cm_buf_get("%s", ipaid_base);

    $INSERT INTO IINS_POL(iins_type, mcommission, magent, pcommission, pagent, ipaid_base)
        VALUES($tmp_iins_type, $g_mcommission, $g_magent, $g_pcommission, $g_pagent, $ipaid_base);
  }

  cm_buf_get("%l", &ipa_cnt);

  for (i = 0; i < ipa_cnt; i++)
  {
    cm_buf_get("%s", tmp_iins_type);
    cm_buf_get("%s", iinsurant);
    cm_buf_get("%s", iins_scope);
    cm_buf_get("%s", icareer);
    cm_buf_get("%e", &g_pcommission);
    cm_buf_get("%l", &g_mcommission);
    cm_buf_get("%e", &g_pagent);
    cm_buf_get("%l", &g_magent);

    $INSERT INTO IINS_PA(iins_type, iinsurant, iins_scope, icareer, mcommission, magent, pcommission, pagent)
        VALUES($tmp_iins_type, $iinsurant, $iins_scope, $icareer, $g_mcommission, $g_magent, $g_pcommission, $g_pagent);
  }

  /* dpay�P�_ => 0�������O, 1���w���O */
  $DECLARE insert_cur1 CURSOR FOR
          SELECT trim(ipolicy1) ||
      trim(ipolicy2),
      iendorse,
      case WHEN dpay IS NOT NULL OR dpay < TODAY THEN 1 ELSE 0 END CASE
                                               FROM ao_plyedr_prem
                                                   WHERE ipolicy1 = $policy_1
          AND ipolicy2 = $policy_2;

  $OPEN insert_cur1;
  for (;;)
  {
    $FETCH insert_cur1 INTO $sIpolicy, $sIendorse, $strpay;
    if (SQLCODE == SQLNOTFOUND)
      break;

    /* �����h��X���Ҧ���L���I�ظ�� */
    if (sIendorse[0] != '\0' && sIendorse[0] != ' ')
    {
      stmt[0] = '\0';
      sprintf(stmt,
              "INSERT INTO MAIN_IINS  \
                    (ipolicy,iendorse,iins_type,paid,mins_premium,mpure_prem,mcommission,magent,mdrunk_prem, mdrunk_pure_prem,mviolate_prem,mviolate_pure_prem) \
                    SELECT '%s',iendorse,iins_type,'%s',medrins_prem,medrpure_prem,medr_commission,medr_agent,mdrunk_prem, mdrunk_pure_prem,mviolate_prem,mviolate_pure_prem \
                      FROM edr_ins_type               \
                     WHERE iendorse = '%s'",
              sIpolicy, strpay, sIendorse);

      $PREPARE edr_ins FROM $stmt;
      $EXECUTE edr_ins;
    }
    else
    {
      /* ��X�O��椧��,��X��l�O�檺�I�ظ�� */
      stmt[0] = '\0';
      sprintf(stmt,
              "INSERT INTO MAIN_IINS  \
                        (ipolicy,iendorse,iins_type,paid,mins_premium,mpure_prem,mcommission,magent,mdrunk_prem, mdrunk_pure_prem,mviolate_prem, mviolate_pure_prem) \
                        SELECT ipolicy,' ',iins_type,'%s',mins_premium,mpure_prem,mcommission,magent,mdrunk_prem, mdrunk_pure_prem,mviolate_prem, mviolate_pure_prem \
                          FROM ori_ins_type               \
                         WHERE ipolicy = '%s'",
              strpay, sIpolicy);

      $PREPARE ori_ply_ins FROM $stmt;
      $EXECUTE ori_ply_ins;
    }
  }
  $CLOSE insert_cur1;
  $FREE insert_cur1;

  /**** START �t���e�ƥ� ****/
  printf("insert_edr=>before negative information backup.......\n");
  $WHENEVER SQLERROR goto errexit;
  rc = bk_401(sDB, ipolicy, temp);
  if (rc != M_CM_OK)
  {
    SQLCODE = rc;
    goto errexit;
  }
  /**** END   �t���e�ƥ� ****/
  printf("END bk401\n");

  printf("Processing positive information..........\n");
  /***** ��begin�����@�~�� *****/
  $WHENEVER SQLERROR goto errexit;
  /**** START �����e�ƥ� ****/
  rc = bk_401(sDB, ipolicy, temp1);
  if (rc != M_CM_OK)
  {
    SQLCODE = rc;
    goto errexit;
  }
  /**** END �����e�ƥ� ****/
  printf("END bk401 positive\n");

  /* �Y�O/���w���O,�h�H���ߦ�(�����H�ΥN�z�v���s)���覡���ͧ�� */
  /* �Y�O/��楼���O,�h�̥��t���ߦ����覡���ͧ�� */
  /* �Y�O/���P�ɦ��w�����������p,�h�u�ݥ����h�H���t���ߦ����覡���ͧ�� */

  $DECLARE insert_cur2 CURSOR FOR
      SELECT ipolicy,
      iins_type, paid FROM MAIN_IINS WHERE ipolicy = $ipolicy GROUP BY 1, 2, 3 ORDER BY 1, 2, 3;

  $OPEN insert_cur2;
  for (;;)
  {
    $FETCH insert_cur2 INTO $ply, $iins_type, $strpay;
    if (SQLCODE == SQLNOTFOUND)
      break;

    strcpy(ply, trim(ply));
    strcpy(old_ply, trim(old_ply));
    strcpy(iins_type, trim(iins_type));
    strcpy(old_iins_type, trim(old_iins_type));

    if (strcmp(ply, old_ply) == 0 && strcmp(iins_type, old_iins_type) == 0)
      continue;
    printf("iins_type[%s]\n", iins_type);

    /* only�������O�O�����N�z�v�~�n�p��i�h */
    $SELECT nvl(sum(mins_premium), 0), nvl(sum(mpure_prem), 0),
        nvl(sum(mcommission), 0), nvl(sum(magent), 0), nvl(sum(mdrunk_prem), 0), nvl(sum(mdrunk_pure_prem), 0),
        nvl(sum(mviolate_prem), 0), nvl(sum(mviolate_pure_prem), 0) INTO $mins_premium, $mpure_prem, $neg_mcommission, $neg_magent, $mdrunk_prem, $mdrunk_pure_prem,
        $mviolate_prem, $mviolate_pure_prem FROM MAIN_IINS WHERE ipolicy = $ipolicy AND iins_type = $iins_type AND paid = $strpay;

    if (strncmp(strpay, "0", 1) == 0) /* ���� */
    {
      printf("����\n");
      strcpy(sMcommission, "mcommission"); /* ��欰�̷s�O��t�� */
      strcpy(sMagent, "magent");           /* ��欰�̷s�O��t�� */

      strcpy(sMcommission1, "0");        /* �̷s�O�欰0 */
      strcpy(sMagent1, "0");             /* �̷s�O�欰0 */
      strcpy(sMedrins_prem1, "0");       /* �̷s�O�欰0 */
      strcpy(sMedrpure_prem1, "0");      /* �̷s�O�欰0 */
      strcpy(sMdrunk_prem1, "0");        /* �̷s�O�欰0 */
      strcpy(sMdrunk_pure_prem1, "0");   /* �̷s�O�欰0 */
      strcpy(sMviolate_prem1, "0");      /* �̷s�O�欰0 */
      strcpy(sMviolate_pure_prem1, "0"); /* �̷s�O�欰0 */
    }
    else /* �w�� */
    {
      printf("�w��\n");
      strcpy(sMcommission, "0"); /* ��欰0 */
      strcpy(sMagent, "0");      /* ��欰0 */

      mins_premium = 0;    /* �w�����O�O��0 */
      mpure_prem = 0;      /* �w�����O�O��0 */
      neg_mcommission = 0; /* �t�����ϥ� */
      neg_magent = 0;      /* �t�����ϥ� */
      mdrunk_prem = 0;
      mdrunk_pure_prem = 0;
      mviolate_prem = 0;
      mviolate_pure_prem = 0;

      strcpy(sMcommission1, "mcommission");   /* �̷s�O�椣�� */
      strcpy(sMagent1, "magent");             /* �̷s�O�椣�� */
      strcpy(sMedrins_prem1, "mins_premium"); /* �̷s�O�椣�� */
      strcpy(sMedrpure_prem1, "mpure_prem");  /* �̷s�O�椣�� */
      strcpy(sMdrunk_prem1, "mdrunk_prem");
      strcpy(sMdrunk_pure_prem1, "mdrunk_pure_prem");

      strcpy(sMviolate_prem1, "mviolate_prem");
      strcpy(sMviolate_pure_prem1, "mviolate_pure_prem");
    }

    /* ���J�g���N��0*��,�N�z�O����,�ѩ��᪺�g���N���|�̷Ӧ����N�z�v�ɧ�̷s���,�ҥH�����L�ݳB�z */
    /* Modified by Julia in 2008/04/22 */
    printf("ori_ibroker[%s],ibroker[%s]\n", ori_ibroker, ibroker);
    if (ori_ibroker[0] == '0')
    {
      strcpy(sMagent, "0");
      neg_magent = 0;
    }
    /* end of �g���N����0*�Y�N�z�O�B�z */

    sprintf(stmt,
            " SELECT fins_grp           \
                       FROM insurance_type     \
                      WHERE iins_type = ? ");
    $PREPARE surid FROM $stmt;

    /**** START �B�z�t���I���� ****/
    /* �B�z�t���I���� */
    stmt[0] = '\0';
    sprintf(stmt,
            " INSERT INTO edr_ins_type                                            \
         (iendorse, iins_type, iedr_type, medrinj_cover, medrdea_cover,      \
          medrdmg_cover, mdeduct, medrins_prem, medrpure_prem, fcal_way,     \
          pcal, qserial, pcommission, medr_commission, pagent, medr_agent,   \
          pdiscount, medr_discount, drate_ym, medr_prem, iproduct,     \
          ipaid_base, qday, medr_expense, medr_exp_disc, qcount, provision, psex_age, mdrunk_prem, mdrunk_pure_prem, \
          mviolate_prem , mviolate_pure_prem)  \
          SELECT '%s', '%s', '%s',                                      \
                 minjured_cover * (-1), mdeath_cover * (-1),                 \
                 mdamage_cover * (-1), mdeduct * (-1),                       \
                 %ld, %ld,                     \
                 'M', 100, qserial, pcommission * (-1), %ld,           \
                 pagent * (-1), %ld, pdiscount * (-1), mdiscount * (-1), \
                 drate_ym, mprem * (-1), iproduct, ipaid_base,               \
                 qday, mexpense * (-1), mexp_disc * (-1), %ld, provision, psex_age, %ld, %f, %ld, %f     \
            FROM ply_ins_type                                                \
           WHERE ipolicy = '%s' AND iins_type = '%s'",
            temp, iins_type, iedr_type1,
            mins_premium * (-1), mpure_prem * (-1), neg_mcommission * (-1), neg_magent * (-1),
            edrins_qcount, mdrunk_prem * (-1), mdrunk_pure_prem * (-1), mviolate_prem * (-1), mviolate_pure_prem * (-1), ipolicy, iins_type);

    /* mins_premium * (-1), mpure_prem * (-1), neg_mcommission * (-1), neg_magent * (-1)
       --> �t�V�������O�O���X�p�O�O�Ϊ� */

    $PREPARE eins1 FROM $stmt;
    $EXECUTE eins1;

    sprintf(stmt,
            " UPDATE ply_ins_type                                        \
             SET (minjured_cover,mdeath_cover,mdamage_cover,mdeduct, \
                  mins_premium,iendorse,pcommission,                 \
                  mcommission,pagent,magent,pdiscount,mdiscount,mprem, \
                  mpure_prem,qday,mexpense,mexp_disc,mdrunk_prem, mdrunk_pure_prem, mviolate_prem, mviolate_pure_prem) \
               = (0,0,0,0,%s,'%s',0, %s,0, %s,0,0,0,%s,0,0,0,%s, %s, %s,%s) \
           WHERE ipolicy = '%s' AND iins_type = '%s'",
            sMedrins_prem1, temp,
            sMcommission1, sMagent1, sMedrpure_prem1, sMdrunk_prem1, sMdrunk_pure_prem1, sMviolate_prem1, sMviolate_pure_prem1, ipolicy, iins_type);

    $PREPARE pins1 FROM $stmt;
    $EXECUTE pins1;

    /* �t���ˮ`�I�����I�� */
    /* �ѩ�W�U���i�঳�h�H,�ҥH�binsert��ca_pa_edr���ɭԭn�����,�@�ج����O�O��,
        ���O�O���u�ݭn�ߥ������O�O�H�Φ���,�L�O�O���h�H�O�O���s����Ʃ��ca_pa_edr */
    /* ���O�O���W�U�Q�O�I�H */
    stmt[0] = '\0';
    sprintf(stmt,
            " INSERT INTO ca_pa_edr                                               \
        (iendorse, iins_type, iinsurant, iedr_type, ninsurant, dbirth,      \
         ainsurant, iins_scope, icareer, medrins_amt, fcal_way,             \
         pcal, medrins_prem, medrpure_prem, pcommission,                    \
         medr_commission, pagent, medr_agent, pdiscount,                    \
         medr_discount, dendorse, napplicant, relation_appl,                \
         nbeneficiary,relation_bene,tbenef, abenef_zip, abenef)             \
        SELECT '%s', iins_type, iinsurant, '%s', ninsurant, dbirth,         \
               ainsurant, iins_scope, icareer, mins_amt * (-1), 'M',        \
               100, %ld, %ld, 0, %ld             \
               , 0, %ld, 0,                                  \
               mdiscount * (-1), '', napplicant, relation_appl,            \
               nbeneficiary,relation_bene,tbenef, abenef_zip, abenef       \
          FROM ca_pa_ply                                                    \
         WHERE ipolicy = '%s' AND iins_type = '%s' AND mins_premium != 0",
            temp, iedr_type1,
            mins_premium * (-1), mpure_prem * (-1), neg_mcommission * (-1),
            neg_magent * (-1),
            ipolicy, iins_type);

    $PREPARE caedr1 FROM $stmt;
    $EXECUTE caedr1;

    /* �O�O���s���W�U�Q�O�I�H */
    sprintf(stmt,
            " INSERT INTO ca_pa_edr                                               \
        (iendorse, iins_type, iinsurant, iedr_type, ninsurant, dbirth,      \
         ainsurant, iins_scope, icareer, medrins_amt, fcal_way,             \
         pcal, medrins_prem, medrpure_prem, pcommission,                    \
         medr_commission, pagent, medr_agent, pdiscount,                    \
         medr_discount, dendorse, napplicant, relation_appl,                \
         nbeneficiary,relation_bene,tbenef, abenef_zip, abenef)             \
        SELECT '%s', iins_type, iinsurant, '%s', ninsurant, dbirth,         \
               ainsurant, iins_scope, icareer, mins_amt * (-1), 'M',        \
               100, 0, 0, 0, 0             \
               , 0, 0, 0,                                  \
               mdiscount * (-1), '', napplicant, relation_appl,            \
               nbeneficiary,relation_bene,tbenef, abenef_zip, abenef       \
          FROM ca_pa_ply                                                    \
         WHERE ipolicy = '%s' AND iins_type = '%s' AND mins_premium = 0",
            temp, iedr_type1,
            ipolicy, iins_type);

    $PREPARE caedr2 FROM $stmt;
    $EXECUTE caedr2;

    $DECLARE tmp_curs1 CURSOR FOR
        SELECT iendorse,
        iedr_type, medrins_prem FROM ca_pa_edr WHERE iendorse = $temp;
    $OPEN tmp_curs1;
    for (;;)
    {
      $FETCH tmp_curs1
          INTO $tmp_iendorse,
          $tmp_iedr, $tmp_prem;

      if (SQLCODE == SQLNOTFOUND)
        break;

      printf("iendorse[%s],medrins_prem[%ld]\n", tmp_iendorse, tmp_prem);
    }
    $close tmp_curs1;
    $free tmp_curs1;

    sprintf(stmt,
            " UPDATE ca_pa_ply                                                               \
           SET (mins_amt, mins_premium, mpure_prem, pcommission, mcommission,          \
                pagent, magent, pdiscount, mdiscount, iendorse)                        \
             = (0,%s,%s,0,%s,0,%s,0,0,'%s')                                              \
         WHERE ipolicy = '%s' AND iins_type = '%s' ",
            sMedrins_prem1, sMedrpure_prem1,
            sMcommission1, sMagent1, temp, ipolicy, iins_type);

    $PREPARE cains1 FROM $stmt;
    $EXECUTE cains1;

    /* �t���I���ɧ@�~���� */

    /* �����I���� */
    sprintf(stmt,
            " UPDATE ply_ins_type                                                      \
             SET (minjured_cover,mdeath_cover,mdamage_cover,mdeduct,               \
                  mins_premium,mpure_prem,iendorse,pcommission,                    \
                  mcommission,pagent,magent,pdiscount,mdiscount,mprem,ipaid_base,  \
                  qday,mexpense,mexp_disc,provision,mdrunk_prem, mdrunk_pure_prem,mviolate_prem , mviolate_pure_prem)   \
               = (?,?,?,?,?,?,'%s',?,?,?,?,?,?,?,?,?,?,?,?,?,? ,?,?)               \
           WHERE ipolicy = ?                                                       \
             AND iins_type = ? ",
            temp1);

    $PREPARE pins2 FROM $stmt;

    sprintf(stmt,
            " SELECT mins_premium, mpure_prem, \
                  minjured_cover, mdeath_cover, mdamage_cover,                \
                  mdeduct, qserial, pdiscount,                                \
                  mdiscount, drate_ym, mprem, iproduct, qday, mexpense,       \
                  mexp_disc, provision, mcommission, magent, mdrunk_prem, mdrunk_pure_prem, mviolate_prem ,mviolate_pure_prem  \
             FROM ply_ins_type_bak                                            \
            WHERE ipolicy  = ?                                                \
              AND iendorse = ?                                                \
              AND iins_type = ? ");
    $PREPARE spins_bak FROM $stmt;

    /* Ū�X�I�ؼȦs�ɤ����I�ة��Ӹ�� */
    $SELECT pcommission, pagent, ipaid_base INTO $g_pcommission, $g_pagent, $ipaid_base FROM IINS_POL WHERE iins_type = $iins_type;

    $EXECUTE spins_bak
        INTO $bk_mins_prem,
        $bk_pure_prem,
        $minjured_cover, $mdeath_cover, $mdamage_cover,
        $mdeduct, $qserial, $pdiscount,
        $mdiscount, $drate_ym, $mprem, $iproduct, $qday, $mexpense,
        $mexp_disc, $provision, $mcommission, $magent, $bk_mdrunk_prem, $bk_mdrunk_pure_prem,
        $bk_mviolate_prem, $bk_mviolate_pure_prem USING $ipolicy, $temp, $iins_type;

    if (strncmp(strpay, "1", 1) == 0)
    {
      printf("���I�إ����w��[%s]\n", iins_type);
      /* �����w�������p��,�����H�ΥN�z�v��[��Ҥ��ߦ� */
      /* �s�W�[�����w�������ή�,�O�O�]���p�� */
      mins_premium = 0;
      mpure_prem = 0;
      mdrunk_prem = 0;
      mdrunk_pure_prem = 0;
      mviolate_prem = 0;
      mviolate_pure_prem = 0;
    }
    else
    {
      /* �������V���O�O�ӥ� */
    }

    /* ���פw���Υ��������N�z�O�Ҥ��� */
    g_mcommission = 0;
    g_magent = 0;
    g_pcommission = 0;
    g_pagent = 0;
    neg_mcommission = neg_magent = 0;

    g_mcommission = mins_premium * (g_pcommission / 100);
    g_magent = mins_premium * (g_pagent / 100);

    if (strcmp(trim(iins_type), "21") != 0) /* ���N�I */
    {
      $SELECT pbusiness, drate_ym, pdiscount, pextra_charge INTO $pbusiness_new, $drate_ym, $pdiscount_new, $pextra_charge_new FROM ply_ins_type WHERE ipolicy = $ipolicy AND iins_type = $iins_type;

      if (SQLCODE == SQLNOTFOUND)
        return M_CA_NINSTYPE;

      $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
                                     INTO $f980401
                                         FROM ca_rate_date
                                             WHERE icode = $drate_ym
          AND itable = 'cm_extra_charge';

      if (SQLCODE == SQLNOTFOUND)
        return M_CA_EXTRA_CHARGE_DRATE;

      /* �O�v�ۥѤƤ��� */
      if (f980401[0] == '1')
      {
        printf("pdiscount_new[%f]\n", pdiscount_new);
        if (pdiscount_new != 0) /* �O�v�ۥѤƤ��ᤣ�i������ */
          return M_CA_PDISCOUNT_ERR;

        sprintf(sCCC1, "%f", (double)(pdiscount_new + g_pcommission + g_pagent));
        sprintf(sCCC2, "%f", (double)((pextra_charge_new - pbusiness_new) * 100.0));
        rCCC1 = atof(sCCC1);
        rCCC2 = atof(sCCC2);

        printf("��+�N+�u[%-3.20f]\n", rCCC1);
        printf("��-�~   [%-3.20f]\n", rCCC2);

        if (rCCC1 > rCCC2)
          return M_CA_COMMI_ERR;

        v_iins = atoi(rtrim(iins_type));

        printf("2_iextra_charge_new[%s]\n", iextra_charge_new);
        printf("2_iroute[%s]\n", iroute);
        printf("2_b_iroute[%s]\n", b_iroute);
        printf("2_v_iins[%d]\n", v_iins);
        printf("2_drate_ym[%s]\n", drate_ym);
        printf("2_qply_period[%d]\n", qply_period);
        /* ����ᤧ���[�O�v */
        rc = get_cm_extra_charge_car(iextra_charge_new, drate_ym,
                                     &pextra_charge_new, &pbusiness_new, qply_period, v_iins, iroute, v_sMsg);
        if (rc != M_CM_OK)
          return rc;
        printf("-- trace pextra_charge_new=[%f]", pextra_charge_new);

        /* ����e�����[�O�v */
        rc = get_cm_extra_charge_car(iextra_charge, drate_ym,
                                     &pextra_charge, &pbusiness, qply_period, v_iins, b_iroute, v_sMsg);
        if (rc != M_CM_OK)
          return rc;

        printf("-- trace pextra_charge=[%f]", pextra_charge);
        /* �O�v�ۥѤƤ���,���[�O�βv���P,���i���,�Ь��ӫO�� */
        if (pextra_charge_new != pextra_charge)
          return M_CA_PEXTRA_CHARGE_NOT_EQUAL;
      }
    }

    $EXECUTE pins2
        USING $minjured_cover,
        $mdeath_cover, $mdamage_cover,
        $mdeduct, $bk_mins_prem, $bk_pure_prem, $g_pcommission, $g_mcommission,
        $g_pagent, $g_magent, $pdiscount, $mdiscount, $mprem, $ipaid_base,
        $qday, $mexpense, $mexp_disc, $provision, $bk_mdrunk_prem, $bk_mdrunk_pure_prem, $bk_mviolate_prem, $bk_mviolate_pure_prem,
        $ipolicy, $iins_type;

    $EXECUTE surid
        INTO $fins_grp
            USING $iins_type;
    if (SQLCODE == SQLNOTFOUND)
    {
      return M_CA_NINS_TYPE;
    }

    $WHENEVER SQLERROR goto errexit;

    switch (fins_grp[0])
    {
    case '1':
      mdmg_commi += g_mcommission;
      mdmg_agent += g_magent;
      mdmg_prem += mins_premium;
      mdmg_pureprem += mpure_prem;
      neg_mdmg_commi += neg_mcommission;
      neg_mdmg_agent += neg_magent;
      break;
    case '2':
      mlia_commi += g_mcommission;
      mlia_agent += g_magent;
      mlia_prem += mins_premium;
      mlia_pureprem += mpure_prem;
      neg_mlia_commi += neg_mcommission;
      neg_mlia_agent += neg_magent;
      break;
    case '3':
      mlia_commi += g_mcommission;
      mlia_agent += g_magent;
      mlia_prem += mins_premium;
      mlia_pureprem += mpure_prem;
      neg_mlia_commi += neg_mcommission;
      neg_mlia_agent += neg_magent;
      break;
    default:
      return M_CA_NINS_TYPE;
      break;
    }
    /* Ū�X�I�ؼȦs�ɤ����I�ة��Ӹ��ends */

    $WHENEVER SQLERROR goto errexit;

    sprintf(stmt,
            "INSERT INTO edr_ins_type                                            \
            (iendorse, iins_type, iedr_type, medrinj_cover,                     \
            medrdea_cover, medrdmg_cover, mdeduct, medrins_prem,               \
            medrpure_prem, fcal_way, pcal, qserial, pcommission,               \
            medr_commission, pagent, medr_agent, pdiscount, medr_discount,     \
            drate_ym, medr_prem, iproduct, ipaid_base, qday, medr_expense,     \
            medr_exp_disc, qcount, provision, psex_age, mdrunk_prem, mdrunk_pure_prem,mviolate_prem , mviolate_pure_prem )  \
           SELECT '%s', iins_type, '%s',                                      \
                  minjured_cover , mdeath_cover ,                             \
                  mdamage_cover , mdeduct , %ld,                              \
                  %ld , 'M', 100, qserial, pcommission,                       \
                   %s, pagent, %s, pdiscount, mdiscount,                     \
                  drate_ym, mprem, iproduct, ipaid_base, qday, mexpense,      \
                  mexp_disc, %ld, provision, psex_age, %ld, %f , %ld, %f \
             FROM ply_ins_type                                                \
            WHERE ipolicy = '%s' AND iins_type = '%s' ",
            temp1, iedr_type2,
            mins_premium, mpure_prem, sMcommission, sMagent, edrins_qcount, mdrunk_prem, mdrunk_pure_prem, mviolate_prem, mviolate_pure_prem,
            ipolicy, iins_type);

    $PREPARE eins2 FROM $stmt;
    $EXECUTE eins2;

    /****  �B�z�ˮ`�I���I��   ****/
    sprintf(stmt,
            " UPDATE ca_pa_ply                                                         \
           SET (mins_amt, mins_premium, mpure_prem, pcommission, mcommission,    \
                pagent, magent, pdiscount, mdiscount, iendorse)                  \
             = (?,?,?,?,?,?,?,?,?,'%s')                                          \
         WHERE ipolicy = ?                                                       \
           AND iins_type = ?                                                     \
           AND iinsurant = ?                                                     \
           AND iins_scope = ?                                                    \
           AND icareer = ?  ",
            temp1);

    printf("stmt[%s]\n", stmt);
    $PREPARE cains2 FROM $stmt;

    sprintf(stmt,
            " SELECT mins_premium, mpure_prem, \
               mins_amt, pdiscount, mdiscount, mcommission, magent   \
          FROM ca_pa_ply_bak                                     \
         WHERE ipolicy = ?                                       \
           AND iendorse = ?                                      \
           AND iins_type = ?                                     \
           AND nvl(iinsurant,'') = ?                             \
           AND nvl(iins_scope,'') = ?                            \
           AND nvl(icareer,'') = ? ");

    printf("stmt[%s]\n", stmt);
    $PREPARE pabak FROM $stmt;

    /* Ū�X�I�ؼȦs�ɤ����ˮ`�I�I�ة��Ӹ�� */
    $DECLARE curs1 CURSOR FOR
        SELECT nvl(iinsurant,''),
        nvl(iins_scope,''), nvl(icareer,''), pcommission, pagent FROM IINS_PA WHERE iins_type = $iins_type;

    $OPEN curs1;
    for (;;)
    {
      $FETCH curs1
          INTO $iinsurant,
          $iins_scope, $icareer, $g_pcommission, $g_pagent;

      if (SQLCODE == SQLNOTFOUND)
        break;

      $EXECUTE pabak
          INTO $bk_mins_prem,
          $bk_pure_prem,
          $mins_amt, $pdiscount, $mdiscount, $mcommission, $magent USING $ipolicy, $temp, $iins_type, $iinsurant, $iins_scope, $icareer;

      printf("SQLCODE[%d]\n", SQLCODE);
      printf("ipolicy[%s], temp[%s], iins_type[%s], iinsurant[%s], iins_scope[%s], icareer[%s]\n",
             ipolicy, temp1, iins_type, iinsurant, iins_scope, icareer);
      if (SQLCODE == SQLNOTFOUND)
      {
        return M_CA_PA_BAK_NOT_FOUND;
      }

      if (strncmp(strpay, "1", 1) == 0)
      {
        /* �����w�������p��,�����H�ΥN�z�v��[��Ҥ��ߦ� */
        g_mcommission = 0;
        g_magent = 0;
        g_pcommission = 0;
        g_pagent = 0;
        mins_premium = 0;
        mpure_prem = 0;
      }
      g_mcommission = mins_premium * (g_pcommission / 100);
      g_magent = mins_premium * (g_pagent / 100);

      $EXECUTE cains2
          USING $mins_amt,
          $bk_mins_prem, $bk_pure_prem, $g_pcommission, $g_mcommission,
          $g_pagent, $g_magent, $pdiscount, $mdiscount, $ipolicy, $iins_type,
          $iinsurant, $iins_scope, $icareer;
      /* Ū�X�I�ؼȦs�ɤ����ˮ`�I�I�ة��Ӹ��ends */

      /* �����ˮ`�I�����I�� */
      /* �ѩ�W�U���i�঳�h�H,�ҥH�binsert��ca_pa_edr���ɭԭn�����,�@�ج����O�O��,
         ���O�O���u�ݭn�ߥ������O�O�H�Φ���,�L�O�O���h�H�O�O���s����Ʃ��ca_pa_edr */
      /* ���O�O���W�U�Q�O�I�H */
      sprintf(stmt,
              " INSERT INTO ca_pa_edr                                               \
                (iendorse, iins_type, iinsurant, iedr_type, ninsurant, dbirth,      \
                ainsurant, iins_scope, icareer, medrins_amt, fcal_way,             \
                pcal, medrins_prem, medrpure_prem, pcommission,                    \
                medr_commission, pagent, medr_agent, pdiscount,                    \
                medr_discount, dendorse, napplicant, relation_appl,                \
                nbeneficiary,relation_bene,tbenef, abenef_zip, abenef)             \
               SELECT '%s', iins_type, iinsurant, '%s', ninsurant, dbirth,         \
                      ainsurant, iins_scope, icareer, mins_amt, 'M',               \
                      100, %ld, %ld, pcommission,                  \
                      %s, pagent, %s, 0,                                           \
                      mdiscount, '', napplicant, relation_appl,                   \
                      nbeneficiary, relation_bene,tbenef, abenef_zip, abenef       \
                 FROM ca_pa_ply                                                    \
                WHERE ipolicy = '%s' AND iins_type = '%s' AND iinsurant = '%s'     \
                  AND mins_premium != 0",
              temp1, iedr_type2,
              mins_premium, mpure_prem, sMcommission, sMagent,
              ipolicy, iins_type, iinsurant);

      $PREPARE caedr3 FROM $stmt;
      $EXECUTE caedr3;

      /* �O�O���s���W�U�Q�O�I�H */
      sprintf(stmt,
              " INSERT INTO ca_pa_edr                                               \
                (iendorse, iins_type, iinsurant, iedr_type, ninsurant, dbirth,      \
                ainsurant, iins_scope, icareer, medrins_amt, fcal_way,             \
                pcal, medrins_prem, medrpure_prem, pcommission,                    \
                medr_commission, pagent, medr_agent, pdiscount,                    \
                medr_discount, dendorse, napplicant, relation_appl,                \
                nbeneficiary,relation_bene,tbenef, abenef_zip, abenef)             \
               SELECT '%s', iins_type, iinsurant, '%s', ninsurant, dbirth,         \
                      ainsurant, iins_scope, icareer, mins_amt, 'M',               \
                      100, 0, 0, pcommission,                  \
                      %s, pagent, %s, 0,                                           \
                      mdiscount, '', napplicant, relation_appl,                   \
                      nbeneficiary, relation_bene,tbenef, abenef_zip, abenef       \
                 FROM ca_pa_ply                                                    \
                WHERE ipolicy = '%s' AND iins_type = '%s' AND iinsurant = '%s'     \
                  AND mins_premium = 0",
              temp1, iedr_type2,
              sMcommission, sMagent,
              ipolicy, iins_type, iinsurant);

      $PREPARE caedr4 FROM $stmt;
      $EXECUTE caedr4;
    }
    $CLOSE curs1;
    $FREE curs1;
    /* �����I���ɧ@�~���� */

    /* �Ncurrent���O���ƥH���I�ظ�ưO���U��,�ΨӧP�_�U�@���O�_���ۦP�I�إu�O�w�������O���� */
    strcpy(old_ply, ply);
    strcpy(old_iins_type, iins_type);

  } /* End of select from MAIN_IINS */
  $CLOSE insert_cur2;
  $FREE insert_cur2;

  /* �t���D�ɳB�zbegins */
  if (fedr_class[0] == 'A')
  {
    edrrel_qcount = -1;
    edrins_qcount = -1;
  }
  else
  {
    edrrel_qcount = 0;
    edrins_qcount = 0;
  }

  $SELECT nvl(sum(medr_agent), 0), nvl(sum(medr_commission), 0), nvl(sum(medrins_prem), 0), nvl(sum(medrpure_prem), 0) INTO $minus_mdmg_agent, $minus_mdmg_commi, $minus_mdmg_prem, $minus_mdmg_pureprem FROM edr_ins_type a, insurance_type b WHERE a.iins_type = b.iins_type AND a.iendorse = $temp AND fins_grp = '1';

  $SELECT nvl(sum(medr_agent), 0), nvl(sum(medr_commission), 0), nvl(sum(medrins_prem), 0), nvl(sum(medrpure_prem), 0) INTO $minus_mlia_agent, $minus_mlia_commi, $minus_mlia_prem, $minus_mlia_pureprem FROM edr_ins_type a, insurance_type b WHERE a.iins_type = b.iins_type AND a.iendorse = $temp AND fins_grp in('2', '3');

  sprintf(stmt,
          " INSERT INTO edr_relation \
                  (iendorse, fcard_class, ipolicy, icard, irelative_ply, irelative_edr, \
                  fedr_class, fpay, ipay, iedr_field, dedr_begin, dedr_end, \
                  ipro_year, ibrand, icar_type, medrdmg_agent, medrdmg_commi, \
                  medrdmg_prem, medrdmg_pure_prem, medrlia_agent, medrlia_commi,  \
                  medrlia_prem, medrlia_pure_prem, ibig_comp, ibig_branch, ibig_office, \
                  ibig_sales, iresource, ibroker, iofficer, ileader, icorps, iedr_area, \
                  iedr_cashier, iedr_examiner, dedr_examine, dentry, dendorse,  \
                  fprint, itreaty, ibranch, iquota, icomp_in, ibranch_in, icomp_at, \
                  ibranch_at, medr_ready, medr_stable, medr_compensate, medr_adjcom,\
                  medr_research, medr_invest, medr_bus_rule, medr_business, \
                  medr_capital, medr_maintain, fcomp_class, fcomp_class_last, fdiscount,    \
                  medrdmg_disc, medrlia_disc, iedr_return, icar_flag, terminate_rsn, qcount,\
                  iofficer_prmt, iquota_prmt, ileader_prmt,irate_type,bzfrom,iroute_comm,icomm_obj,qprovision, isecond_hand, icard_main, qdrunk_driving, isign,\
                  feply, feedr, aemail_eply, tmobile_eply,ireg_no,isign_edr,dsign_edr,fsign_status_edr,funder_chk_edr,iprog,qviolate) \
                 SELECT '%s', fcard_class, ipolicy, icard, irelative_ply, ' ',  \
                        '%s', '%s', ' ', ' ', dply_begin, dply_end, \
                        ipro_year, ibrand, icar_type, %ld, %ld, \
                        %ld, %ld, %ld, %ld,  \
                        %ld, %ld, ibig_comp, ibig_branch, ibig_office,     \
                        ibig_sales, iresource, ibroker, iofficer, ileader, icorps, iarea,   \
                        '%s', '%s', %ld, %ld, '',                                          \
                        1, itreaty, ibranch, '%s', icomp_in, ibranch_in,    '%s' ,        \
                        '%s' , mready * (-1), mstable * (-1), mcompensation * (-1), madjcom_prem * (-1),   \
                        mresearch * (-1), minvest * (-1), mbus_rule * (-1), mbusiness * (-1),              \
                        mcapital * (-1), maintain * (-1), fcomp_class, fcomp_class_last, fdiscount, \
                        mdmg_discount * (-1), mlia_discount * (-1), '0', icar_flag, '0', %ld,\
                        iofficer_prmt, iquota_prmt, ileader_prmt, irate_type,bzfrom,iroute_comm,icomm_obj,qprovision, isecond_hand, icard_main, qdrunk_driving, isign,\
                        feply, '0', aemail_eply, tmobile_eply,'%s','system',today,40,'N','car413',qviolate \
                   FROM ply_relation \
                  WHERE ipolicy = '%s' ",
          temp, fedr_class, fpay,
          minus_mdmg_agent, minus_mdmg_commi, minus_mdmg_prem, minus_mdmg_pureprem,
          minus_mlia_agent, minus_mlia_commi, minus_mlia_prem, minus_mlia_pureprem,
          userid, userid, dwritten, dwritten, iquota_dissolve, icomp_at, ibranch_at,
          edrrel_qcount, ireg_no, ipolicy);

  printf("stmt[%s]\n", stmt);
  $PREPARE edr1 FROM $stmt;
  $EXECUTE edr1;

  /* �t�V�D�� */

  /*1071105008_SC2_ �������Ȩ��z��(FS)�A�éw�ɦ۰ʤU���ɮ�*/
  strcpy(iroute_accept_edr, " ");
  if (strncmp(b_iroute, "I009", 4) == 0)
  {
    strcpy(temp, trim(temp));
    sprintf(iroute_accept_edr, "CHB%s", temp);
  }
  printf("-- trace iroute_accept_edr[%s]\n ", iroute_accept_edr);

  sprintf(stmt,
          " INSERT INTO endorsement                                                     \
                   (iendorse, qply_period, dply_begin, dply_end, fassured, iassured,          \
                    iassured_ext, nassured, ilicense, fsex, fmarriage, nuser,         \
                    ibenef, nbenef, aassured, aassured_zip, itel, apayment, apayment_zip,        \
                    iply_area, nbrand_abbr, ncar_abbr, fcar_note, qcylinder, iengine, ibody,     \
                    itag, mcar_price, nequipment, flimit, pdmg_align, pbrg_align, plia_align,    \
                    idmg_rate, pdmg_factor, ibrg_rate, pbrg_factor, qpt, fpt, psex_age, psex_age_damage, lia_class,\
                    plia_acc, dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd, pdmg_acc, fhuman, fcomp_24,  \
                    napplicant, dbirth, dissue, \
                    iextra_charge, gextra_charge, pextra_charge, \
                    iquery_num_damage, iquery_num, mequipment, \
                    survey_num, bound_num, abnormal_num, iapplicant, iroute, qlia_acc_sum, qdmg_acc_sum, \
                    fapplicant,fsex_appl,dbirth_appl,itel_appl,ndeputy_appl,nrelation_appl,ndeputy_assured,\
                    iassured_cntry,iapplicant_cntry,nassured_cntry, napplicant_cntry, \
                    foccup, noccup, applicant_foccup, applicant_noccup, iroute_accept,tmobile_appl , aemail_appl,\
                    qpro_month,dinstall, isequence, ainstall_zip, ainstall) \
                   SELECT '%s', a.qply_period, a.dply_begin, a.dply_end,                        \
                          b.fassured, b.iassured, b.iassured_ext, b.nassured,                   \
                          b.ilicense, b.fsex, b.fmarriage, b.nuser,                   \
                          b.ibenef, b.nbenef, b.aassured, b.aassured_zip, b.itel,               \
                          b.apayment, b.apayment_zip, b.iply_area, b.nbrand_abbr,               \
                          b.ncar_abbr, b.fcar_note, b.qcylinder, b.iengine, b.ibody,            \
                          b.itag, b.mcar_price, b.nequipment, b.flimit, b.pdmg_align,           \
                          b.pbrg_align, b.plia_align, b.idmg_rate, b.pdmg_factor, \
                          b.ibrg_rate, b.pbrg_factor, b.qpt, b.fpt, b.psex_age, b.psex_age_damage, \
                          b.lia_class, b.plia_acc, b.dmg_acc_1st, b.dmg_acc_2nd, \
                          b.dmg_acc_3rd, b.pdmg_acc, b.fhuman, b.fcomp_24, \
                          b.napplicant, b.dbirth, b.dissue,     \
                          b.iextra_charge, b.gextra_charge, b.pextra_charge, \
                          b.iquery_num_damage, b.iquery_num, b.mequipment, \
                          b.survey_num, b.bound_num, b.abnormal_num, b.iapplicant, '%s', b.qlia_acc_sum, b.qdmg_acc_sum, \
                          b.fapplicant,b.fsex_appl,b.dbirth_appl,b.itel_appl,b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured,\
                          CASE WHEN b.iassured_cntry='' THEN '8' ELSE b.iassured_cntry END,\
                          CASE WHEN b.iapplicant_cntry='' THEN '8' ELSE b.iapplicant_cntry END, b.nassured_cntry, b.napplicant_cntry, \
                          b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup,'%s',b.tmobile_appl , b.aemail_appl, \
                          b.qpro_month,b.dinstall, b.isequence, b.ainstall_zip, b.ainstall      \
                     FROM ply_relation a,policy b                                               \
                    WHERE a.ipolicy = b.ipolicy                                                 \
                      AND a.ipolicy = '%s'",
          temp, b_iroute, iroute_accept_edr, ipolicy);

  printf("endorsement stmt[%s]\n", stmt);
  $PREPARE endor1 FROM $stmt;
  $EXECUTE endor1;

  /*sprintf(stmt,
          " UPDATE ply_relation                                                 \
               SET (mdmg_prem, mdmg_agent, mdmg_commi,                          \
                   mlia_prem, mlia_agent, mlia_commi,                          \
                   mdmg_pure_prem, mlia_pure_prem,                             \
                   mready, mstable, mcompensation,                             \
                   madjcom_prem, mresearch, minvest,                           \
                   mbus_rule, mbusiness, mcapital, maintain, mdmg_discount,    \
                   mlia_discount)                                              \
                 = (0,%s,%s,0,%s,%s,0,0,0,0,0,0,0,0,0,0,0,0,0,0)  \
             WHERE ipolicy = '%s' ", sMdmg_agent1, sMdmg_commi1, sMlia_agent1, \
                   sMlia_commi1, ipolicy);

   $PREPARE ply1 FROM $stmt;
   $EXECUTE ply1; */

  rc = insert_cm_pre_receive_edr(temp, ipolicy, ipgid, v_sMsg);
  if (rc != M_CM_OK)
    return rc;

  /* �t���D�ɳB�zends */

  printf("begin �����D��\n");
  /* �����D�ɳB�zbegins */
  if (fedr_class[0] == 'A')
  {
    edrrel_qcount = 1;
    edrins_qcount = 1;
  }
  else
  {
    edrrel_qcount = 0;
    edrins_qcount = 0;
  }

  sprintf(stmt,
          " SELECT mdmg_prem, mlia_prem, mdmg_pure_prem,              \
                        mlia_pure_prem, mready, mstable, mcompensation,    \
                        madjcom_prem, mresearch, minvest, mbus_rule, mbusiness,   \
                        mcapital, maintain, mdmg_discount, mlia_discount   \
                   FROM ply_relation_bak                                   \
                  WHERE ipolicy = ?                                        \
                    AND iendorse = ? ");
  $PREPARE splyid FROM $stmt;
  $EXECUTE splyid
      INTO $ply_mdmgprem,
      $ply_mliaprem, $ply_mdmgpure,
      $ply_mliapure, $mready, $mstable, $mcompensation,
      $madjcom_prem, $mresearch, $minvest, $mbus_rule, $mbusiness,
      $mcapital, $maintain, $mdmg_discount, $mlia_discount USING $ipolicy, $temp;

  /* �N������諸�����ΥN�z�v,�����t���A�[�W����,update ply_relation */
  $SELECT mdmg_agent, mdmg_commi, mlia_agent, mlia_commi INTO $sum_mdmg_agent, $sum_mdmg_commi, $sum_mlia_agent, $sum_mlia_commi FROM ply_relation WHERE ipolicy = $ipolicy;

  sum_mdmg_agent += (mdmg_agent + (neg_mdmg_agent * (-1)));
  sum_mdmg_commi += (mdmg_commi + (neg_mdmg_commi * (-1)));
  sum_mlia_agent += (mlia_agent + (neg_mlia_agent * (-1)));
  sum_mlia_commi += (mlia_commi + (neg_mlia_commi * (-1)));

  sprintf(stmt,
          " UPDATE ply_relation                                        \
                    SET (iresource, ibroker, iofficer, ileader, icorps,     \
                        iquota, ibig_office, ibig_sales,                    \
                        mdmg_prem, mdmg_agent, mdmg_commi,                  \
                        mlia_prem, mlia_agent, mlia_commi,                  \
                        mdmg_pure_prem, mlia_pure_prem,                     \
                        mready, mstable, mcompensation,                     \
                        madjcom_prem, mresearch, minvest, mbus_rule,        \
                        mbusiness, mcapital, maintain , mdmg_discount, mlia_discount,irate_type,bzfrom,iroute_comm,icomm_obj,ibig_comp,ireg_no) \
                      = (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?, ?,?,?,?,?,?)       \
                  WHERE ipolicy = '%s' ",
          ipolicy);

  $PREPARE ply2 FROM $stmt;
  $EXECUTE ply2
      USING $iresource,
      $ibroker, $iofficer, $ileader, $icorps,
      $iquota, $ibig_office, $ibig_sales,
      $ply_mdmgprem, $sum_mdmg_agent, $sum_mdmg_commi,
      $ply_mliaprem, $sum_mlia_agent, $sum_mlia_commi,
      $ply_mdmgpure, $ply_mliapure,
      $mready, $mstable, $mcompensation,
      $madjcom_prem, $mresearch, $minvest, $mbus_rule,
      $mbusiness, $mcapital, $maintain, $mdmg_discount, $mlia_discount,
      $irate_type, $bzfrom, $iroute_comm, $icomm_obj, $ibig_comp, $ireg_no;

  if (strncmp(icomm_obj, "10000", 5) == 0 && sum_mdmg_commi + sum_mlia_commi != 0)
    return M_CA_CANT_HAVE_COMMI1;

  /* car9811303 �j���I99.3.1�O�v */
  if (ori_fcard_class[0] == '1')
  {
    strcpy(iabn_type, "");
    $SELECT drate_ym
        INTO $comp_frate
            FROM ply_ins_type
                WHERE ipolicy = $ipolicy
                    AND iins_type = '21';
    rc = chk_commi_business(1, iabn_type, comp_frate, sum_mdmg_commi + sum_mlia_commi, mbusiness, v_sMsg);
    if (rc != M_CM_OK)
      return rc;
  }

  $UPDATE policy
      SET(iextra_charge, iroute) = ($iextra_charge_new, $iroute)
          WHERE ipolicy = $ipolicy;

  sprintf(stmt,
          " INSERT INTO edr_relation \
                  (iendorse, fcard_class, ipolicy, icard, irelative_ply, irelative_edr,   \
                  fedr_class, fpay, ipay, iedr_field, dedr_begin, dedr_end, \
                  ipro_year, ibrand, icar_type, medrdmg_agent, medrdmg_commi, \
                  medrdmg_prem, medrdmg_pure_prem, medrlia_agent, medrlia_commi,  \
                  medrlia_prem, medrlia_pure_prem, ibig_comp, ibig_branch, ibig_office,   \
                  ibig_sales, iresource, ibroker, iofficer, ileader, icorps, iedr_area,   \
                  iedr_cashier, iedr_examiner, dedr_examine, dentry, dendorse,  \
                  fprint, itreaty, ibranch, iquota, icomp_in, ibranch_in, icomp_at, \
                  ibranch_at, medr_ready, medr_stable, medr_compensate, medr_adjcom,  \
                  medr_research, medr_invest, medr_bus_rule, medr_business, \
                  medr_capital, medr_maintain, fcomp_class, fcomp_class_last, fdiscount, medrdmg_disc,\
                  medrlia_disc, iedr_return, icar_flag, terminate_rsn, qcount,  \
                  iofficer_prmt, iquota_prmt, ileader_prmt,irate_type,bzfrom,iroute_comm,icomm_obj,qprovision, isecond_hand, icard_main, qdrunk_driving, isign,\
                  feply, feedr, aemail_eply, tmobile_eply,ireg_no,isign_edr,dsign_edr,fsign_status_edr,funder_chk_edr,iprog,qviolate) \
                 SELECT '%s', fcard_class, ipolicy, icard, irelative_ply, ' ',  \
                        '%s', '%s', ' ', ' ', dply_begin, dply_end, \
                        ipro_year, ibrand, icar_type, %ld, %ld, \
                        %ld, %ld, %ld, %ld,  \
                        %ld, %ld, '%s', ibig_branch, '%s',  \
                        '%s', '%s', '%s', '%s', '%s', '%s', iarea,  \
                        '%s', '%s', %ld, %ld, '',  \
                        1, itreaty, ibranch, iquota, icomp_in, ibranch_in, '%s', \
                        '%s', mready, mstable, mcompensation, madjcom_prem,  \
                        mresearch, minvest, mbus_rule, mbusiness, \
                        mcapital, maintain, fcomp_class, fcomp_class_last, fdiscount, mdmg_discount,\
                        mlia_discount, '0', icar_flag, '0', %ld, \
                        '%s', '%s', '%s', '%s', '%s', '%s', '%s', qprovision, isecond_hand, icard_main, qdrunk_driving, isign,\
                        feply, '0', aemail_eply, tmobile_eply,'%s','system',today,40,'N','car413',qviolate \
                  FROM ply_relation \
                 WHERE ipolicy = '%s' ",
          temp1, fedr_class, fpay, mdmg_agent, mdmg_commi,
          mdmg_prem, mdmg_pureprem, mlia_agent, mlia_commi,
          mlia_prem, mlia_pureprem, ibig_comp, ibig_office, ibig_sales, iresource,
          ibroker, iofficer, ileader, icorps,
          userid, userid,
          dwritten, dwritten,
          icomp_at, ibranch_at, edrrel_qcount,
          iofficer_prmt, iquota_prmt, ileader_prmt, irate_type, bzfrom, iroute_comm, icomm_obj, ireg_no,
          ipolicy);

  $PREPARE edr2 FROM $stmt;
  $EXECUTE edr2;

  /*1071105008_SC2_ �������Ȩ��z��(FS)�A�éw�ɦ۰ʤU���ɮ�*/
  strcpy(iroute_accept_edr, " ");
  if (strncmp(iroute, "I009", 4) == 0)
  {
    strcpy(temp1, trim(temp1));
    sprintf(iroute_accept_edr, "CHB%s", temp1);
  }
  printf("-- trace iroute_accept_edr[%s]\n ", iroute_accept_edr);
  sprintf(stmt,
          " INSERT INTO endorsement                                                     \
                   (iendorse, qply_period, dply_begin, dply_end, fassured, iassured,           \
                   iassured_ext, nassured, ilicense, fsex, fmarriage, nuser,           \
                   ibenef, nbenef, aassured, aassured_zip, itel, apayment, apayment_zip,       \
                   iply_area, nbrand_abbr, ncar_abbr, fcar_note, qcylinder, iengine, ibody,    \
                   itag, mcar_price, nequipment, flimit, pdmg_align, pbrg_align, plia_align,   \
                   idmg_rate, pdmg_factor, ibrg_rate, pbrg_factor, qpt, fpt, psex_age, psex_age_damage, lia_class,\
                   plia_acc, dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd, pdmg_acc, fhuman, fcomp_24,  \
                   napplicant, dbirth, dissue,                       \
                   iextra_charge, gextra_charge, pextra_charge,                                  \
                   iquery_num_damage, iquery_num, mequipment,                        \
                   survey_num, bound_num, abnormal_num, iapplicant, iroute, qlia_acc_sum, qdmg_acc_sum, \
                   fapplicant,fsex_appl,dbirth_appl,itel_appl,ndeputy_appl,nrelation_appl,ndeputy_assured,\
                   iassured_cntry, iapplicant_cntry, nassured_cntry, napplicant_cntry, \
                   foccup, noccup, applicant_foccup, applicant_noccup, iroute_accept,tmobile_appl ,aemail_appl, \
                   dinstall, isequence, ainstall_zip, ainstall ) \
                  SELECT '%s', a.qply_period, a.dply_begin, a.dply_end,                        \
                         b.fassured, b.iassured, b.iassured_ext, b.nassured,                   \
                         b.ilicense, b.fsex, b.fmarriage, b.nuser,                   \
                         b.ibenef, b.nbenef, b.aassured, b.aassured_zip, b.itel,               \
                         b.apayment, b.apayment_zip, b.iply_area, b.nbrand_abbr,               \
                         b.ncar_abbr, b.fcar_note, b.qcylinder, b.iengine, b.ibody,            \
                         b.itag, b.mcar_price, b.nequipment, b.flimit, b.pdmg_align,           \
                         b.pbrg_align, b.plia_align, b.idmg_rate, b.pdmg_factor,               \
                         b.ibrg_rate, b.pbrg_factor, b.qpt, b.fpt, b.psex_age, b.psex_age_damage, \
                         b.lia_class, b.plia_acc, b.dmg_acc_1st, b.dmg_acc_2nd,                \
                         b.dmg_acc_3rd, b.pdmg_acc, b.fhuman, b.fcomp_24,                      \
                         b.napplicant, b.dbirth, b.dissue,     \
                         '%s', b.gextra_charge, b.pextra_charge,                    \
                         b.iquery_num_damage, b.iquery_num, b.mequipment,        \
                         b.survey_num, b.bound_num, b.abnormal_num, b.iapplicant,'%s', b.qlia_acc_sum, b.qdmg_acc_sum, \
                         b.fapplicant,b.fsex_appl,b.dbirth_appl,b.itel_appl,b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured,\
                         CASE WHEN b.iassured_cntry='' THEN '8' ELSE b.iassured_cntry END,\
                         CASE WHEN b.iapplicant_cntry='' THEN '8' ELSE b.iapplicant_cntry END, b.nassured_cntry, b.napplicant_cntry, \
                         b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup,'%s',b.tmobile_appl , b.aemail_appl, \
                         b.dinstall, b.isequence, b.ainstall_zip, b.ainstall \
                    FROM ply_relation a,policy b \
                   WHERE a.ipolicy = b.ipolicy \
                     AND a.ipolicy = '%s' ",
          temp1, iextra_charge_new, iroute, iroute_accept_edr, ipolicy);

  $PREPARE endor2 FROM $stmt;
  $EXECUTE endor2;

  rc = insert_cm_pre_receive_edr(temp1, ipolicy, ipgid, v_sMsg);
  if (rc != M_CM_OK)
    return rc;

  /* �����t���I���ɥH�ΥD�ɪ����B�ˮ� */

  $SELECT SUM(medrins_prem), SUM(medrpure_prem), SUM(medr_commission), SUM(medr_agent) INTO $medrins_prem, $medrpure_prem, $medr_commission, $medr_agent FROM edr_ins_type WHERE iendorse = $temp;

  $SELECT medrlia_prem + medrdmg_prem, medrlia_pure_prem + medrdmg_pure_prem,
      medrlia_commi + medrdmg_commi, medrlia_agent + medrdmg_agent INTO $mins_premium, $mpure_prem, $mcommission, $magent FROM edr_relation WHERE iendorse = $temp;

  printf("negative iendorse[%s]\n", temp);
  printf("medrins_prem    [%d] mins_premium[%d]\n", medrins_prem, mins_premium);
  printf("medrpure_prem   [%d] mpure_prem  [%d]\n", medrpure_prem, mpure_prem);
  printf("medr_commission [%d] mcommission [%d]\n", medr_commission, mcommission);
  printf("medr_agent      [%d] magent      [%d]\n", medr_agent, magent);

  /* check �t�����D�ɩ��Ӫ��B�O�_�@�P */
  if ((medrins_prem != mins_premium) ||
      (medr_commission != mcommission) ||
      (medr_agent != magent) ||
      (medrpure_prem != mpure_prem))
  {
    return M_CA_EDR_PREM_NOT_EQUAL;
  }

  $SELECT SUM(medrins_prem), SUM(medrpure_prem), SUM(medr_commission), SUM(medr_agent) INTO $medrins_prem, $medrpure_prem, $medr_commission, $medr_agent FROM edr_ins_type WHERE iendorse = $temp1;

  $SELECT medrlia_prem + medrdmg_prem, medrlia_pure_prem + medrdmg_pure_prem,
      medrlia_commi + medrdmg_commi, medrlia_agent + medrdmg_agent INTO $mins_premium, $mpure_prem, $mcommission, $magent FROM edr_relation WHERE iendorse = $temp1;

  printf("postivie iendorse[%s]\n", temp1);
  printf("medrins_prem    [%d] mins_premium[%d]\n", medrins_prem, mins_premium);
  printf("medrpure_prem   [%d] mpure_prem  [%d]\n", medrpure_prem, mpure_prem);
  printf("medr_commission [%d] mcommission [%d]\n", medr_commission, mcommission);
  printf("medr_agent      [%d] magent      [%d]\n", medr_agent, magent);

  /* check �������D�ɩ��Ӫ��B�O�_�@�P */
  if ((medrins_prem != mins_premium) ||
      (medr_commission != mcommission) ||
      (medr_agent != magent) ||
      (medrpure_prem != mpure_prem))
  {
    return M_CA_EDR_PREM_NOT_EQUAL;
  }

  $select a.iendorse, a.iedr_type, a.iins_type, a.medrins_prem, sum(b.medrins_prem) into $iendorse_tmp, $ibranch_at, $iins_type, $medrins_prem, $mins_premium from edr_ins_type a, ca_pa_edr b where a.iendorse = b.iendorse and a.iins_type = b.iins_type and a.iendorse = $temp group by 1, 2, 3, 4 having a.medrins_prem<> sum(b.medrins_prem);

  printf("SQLCODE[%d],temp[%s]\n", SQLCODE, temp);
  printf("edr[%d],pa[%d]\n", medrins_prem, mins_premium);

  if (SQLCODE != SQLNOTFOUND)
  {
    return M_CA_EDR_PREM_NOT_EQUAL;
  }

  $select a.iendorse, a.iedr_type, a.iins_type, a.medrins_prem, sum(b.medrins_prem) into $iendorse_tmp, $ibranch_at, $iins_type, $medrins_prem, $mins_premium from edr_ins_type a, ca_pa_edr b where a.iendorse = b.iendorse and a.iins_type = b.iins_type and a.iendorse = $temp1 group by 1, 2, 3, 4 having a.medrins_prem<> sum(b.medrins_prem);

  printf("SQLCODE[%d],temp1[%s]\n", SQLCODE, temp1);
  printf("edr[%d],pa[%d]\n", medrins_prem, mins_premium);

  if (SQLCODE != SQLNOTFOUND)
  {
    return M_CA_EDR_PREM_NOT_EQUAL;
  }

  /* �����D�ɳB�zends */
  /* �����D�ɳB�zends */

  /* car9802182
     �g���H����O�A�����O�������ɡA�N�̷s�O���ɪ������N�z�O�Τ���O�k0�A
     ����X�����Ҥ��ߦ� */

  $UPDATE ply_ins_type
      SET mcommission = 0,
          magent = 0,
          pcommission = 0,
          pagent = 0 where ipolicy = $ipolicy;

  $UPDATE ca_pa_ply
      SET mcommission = 0,
          magent = 0,
          pcommission = 0,
          pagent = 0 where ipolicy = $ipolicy;

  $UPDATE ply_relation
      SET mlia_commi = 0,
          mdmg_commi = 0,
          mlia_agent = 0,
          mdmg_agent = 0 where ipolicy = $ipolicy;

  $DROP TABLE MAIN_IINS;
  $DROP TABLE IINS_POL;
  $DROP TABLE IINS_PA;

  return M_CM_OK;

errexit:
  return SQLCODE;
}
