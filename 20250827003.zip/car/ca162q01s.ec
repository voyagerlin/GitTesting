/**********************************************************************/
/*   program id   : ca162q01s.ec                                      */
/*   program name : ����TXT���s                                       */
/*   date written : 2017/05/08                                        */
/*   date modify  : yyyy/mm/dd                                        */
/**********************************************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"
#include "carmsgs.h"
#include "safeclib.h"

#define SUCCESS                 1


char  	outputf[ N_FILE+1];
$char  	userid[11];
$char	DBName[5];
$char   iprovision_p[6],drate_ym_p[5],iclass_p[2],dbegin_p[11];


DBinfo  *list;
    
int     flen, count_db, i, j=0, k , count=0;
$char	v_sMsg[1024],sErrMsg[1024];
char	msgbuf[100];
$char   dtoday1[11];
$long	dsys;
$char   sWhere[512];

int iTryCnt,res1,iTryCnt2,res2;

int result;
char tar[512], gzip[121], cp[128], rm[128];
char  s[10],s1[10],s2[10],s3[10];

char    sApHome[30];
char    filename[30];
FILE    *fp;
int     flen;
$static char exec_time[20];

static char *get_car_full_db();
/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
	int rc;
	char  Message[1024];
	  
	batchinit();
	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(iprovision_p,   isNULLstr(argv[3])); 
	strcpy(drate_ym_p,     isNULLstr(argv[4])); 
	strcpy(iclass_p,       isNULLstr(argv[5])); 
	strcpy(dbegin_p,       isNULLstr(argv[6])); 
	strcpy(outputf,        isNULLstr(argv[7]));
	
	rc = car_get_db();
	if (rc != M_CM_OK) {
		printf("error on car_get_db\n");
		return rc;
	}
	
	strcpy(iprovision_p,trim(iprovision_p));
	strcpy(drate_ym_p,trim(drate_ym_p));
	strcpy(iclass_p,trim(iclass_p));
	strcpy(dbegin_p,trim(dbegin_p));
	strcpy(dbegin_p,cm_to_infdate(dbegin_p));
	printf("iprovision_p[%s] drate_ym_p[%s] iclass_p[%s] dbegin_p[%s]",iprovision_p,drate_ym_p,iclass_p,dbegin_p);
	
	s[0]  = '\0';
	s1[0] = '\0';
	s2[0] = '\0';
	s3[0] = '\0';
	
	strcpy(dtoday1,cm_cdate_str(cm_today()));
	cm_char_split_3ymd(dtoday1,s1,s2,s3);
	
	/**** ����ɶ� exec_time [YYYY-MM-DD HH:MM] ****/
	strcpy(exec_time, cm_get_sysd());
	printf("{car162.0001}:EXECUTE TIME[%s]\n",exec_time);
	/***********************************************/
	
	strncpy(filename," ",30);
	sprintf_s(filename, sizeof filename,"%s/rptftp/", sApHome);
	printf("{car162.0002}:filename[%s]\n",filename);
	
	/*�������*/
	rc = create_provision();
	if ( rc != M_CM_OK ) {
	 	printf("error on create_provision\n");
	 	EWRITE(userid, rc, sErrMsg);
		return rc;	
	}
	
	strcpy(Message,  "\n�Цܦ@�θ귽[N]/�d��[B]/�ɮפU���@�~[cmn202]�U���ɮ�!\n");
	
	EWRITE(userid,M_CM_OK,Message);

	printf("END PROGRAM\n");
	return SUCCESS;

errexit:
	printf("-- Query_card -- SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
	return SQLCODE;     
}
/*----------------------------------------------------------------------------*/
long car_get_db()
{
	int rc;
	
	if (db_select(DBName) == False) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
		return M_CM_DB_NOTOPEN;
	}
	
	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
	 	return rc;
	}
	
	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}
	
	return M_CM_OK;
}
/*----------------------------------------------------------------------------*/
/*char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
	char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
	char sTmp_db_name[21];
	
	sTmp_db_name[0]='\0';
	if (*sIpolicy != '\0' && *sIpolicy !=' ')
	{
	    sTmp_db_name[0]='\0';
	    strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
	    strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
	           USE_BRANCH_ID));
	    strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
	}        
	return sTmp_db_name;
}*/
/*----------------------------------------------------------------------------*/
long create_provision()
{
	
	$char drate[4],stmt3[1024],stmt4[1024],stmt5[1024];
	$char stmp1[256],stmp2[256],stmp3[256],stmp4[256];
	$char iprovision_in[6],drate_ym_in[5],iclass_in[2],dbegin_in[11];
	$char iprovision[6],drate_ym[5],iclass[2],dbegin[11],nprovision[256],nnumber[256],fcont1[2],fcont2[2],narticle[256],ncontent[256],nnumber2[256],nprovision2[256],dbegin2[11];
	$char dbegin2_yy[4],dbegin2_mm[3],dbegin2_dd[3],nprovision_fcont[2],nnumber_fcont[2],ncontent2[256];
	$int iarticle=0,icontent=0;
	$char chn[5];
	$char *ptr,*ptr2;
	char  file_catalog[200];
	$char filename1[200];
	
	$WHENEVER SQLERROR GOTO errexit;
	$SET LOCK MODE TO WAIT;
	$BEGIN WORK;
        
        filename1[0]    = '\0';
	file_catalog[0] = '\0';
	
	sprintf_s(filename1, sizeof filename1,"car162_provision_%s%s%s.txt",s1,s2,s3);
	strcpy(file_catalog, trim(filename));
	strcat(file_catalog, trim(filename1));
	
	fp=fopen(file_catalog,"w");

	if(strlen(iprovision_p) == 0 || strncmp(iprovision_p,"*",1) == 0 )
		strcpy(stmp1," ");
	else
		sprintf_s(stmp1, sizeof stmp1,"AND a.iprovision matches '%s' ",iprovision_p);
		
	if(strlen(drate_ym_p) == 0 || strncmp(drate_ym_p,"*",1) == 0 )
		strcpy(stmp2," ");
	else
		sprintf_s(stmp2, sizeof stmp2,"AND a.drate_ym matches '%s' ",drate_ym_p);

	if(strncmp(iclass_p,"C",1) == 0 )
		strcpy(stmp3,"AND a.iclass = 'C' ");
	else if(strncmp(iclass_p,"S",1) == 0 )
		strcpy(stmp3,"AND a.iclass = 'S' ");
	else if(strncmp(iclass_p,"A",1) == 0 )
		strcpy(stmp3,"AND a.iclass = 'A' ");
	else if(strncmp(iclass_p,"B",1) == 0 )
		strcpy(stmp3,"AND a.iclass = 'B' ");
	else if(strncmp(iclass_p,"E",1) == 0 )
		strcpy(stmp3,"AND a.iclass = 'E' ");
	else
		strcpy(stmp3," ");
	
	if(strlen(dbegin_p) == 0 || strncmp(dbegin_p,"*",1) == 0 )
		strcpy(stmp4," ");
	else
		sprintf_s(stmp4, sizeof stmp4,"AND a.dbegin = '%s' ",dbegin_p);
	
	sprintf_s(stmt4, sizeof stmt4,"SELECT distinct a.iprovision,a.drate_ym,a.iclass,a.dbegin "
	                " FROM ca_provision a "
		        " WHERE (a.dexpire IS NULL OR a.dexpire = '' OR a.dexpire >= today) "
		        "  %s %s %s %s ",stmp1,stmp2,stmp3,stmp4);
	printf("stmt4[%s]\n\n\n",stmt4);
	$PREPARE odrate FROM $stmt4;
	$DECLARE outdrate CURSOR FOR odrate;  
	$OPEN    outdrate;	
	printf("-----> into drate_ym \n");
	for(;;)
	{
		$FETCH outdrate INTO $iprovision_in,$drate_ym_in,$iclass_in,$dbegin_in;
		if (SQLCODE == SQLNOTFOUND) break;		
	    	sprintf_s(stmt5, sizeof stmt5,"SELECT a.iprovision,a.drate_ym,a.iclass,a.dbegin,cast(a.iarticle as int),a.fcont,a.narticle,b.icontent,b.fcont,b.ncontent "
	                       " FROM ca_provision a , ca_prov_content b  "
	                       " WHERE a.iprovision = b.iprovision "
	                       "  AND a.drate_ym = b.drate_ym "
	                       "  AND a.iclass = b.iclass "
	                       "  AND a.dbegin = b.dbegin "
	                       "  AND a.iarticle = b.iarticle "
	                       "  AND a.iprovision = '%s' "
	                       "  AND a.drate_ym = '%s' "
	                       "  AND a.iclass = '%s' "
	                       "  AND a.dbegin = '%s' "
	                       "  AND (a.dexpire IS NULL OR a.dexpire = '' OR a.dexpire >= today) "
	                    " ORDER BY 1,2,3,5,8 ",iprovision_in,drate_ym_in,iclass_in,dbegin_in);
		$PREPARE pro FROM $stmt5;
		$DECLARE pro1 CURSOR FOR pro;  
		$OPEN    pro1;
		printf("stmt5[%s]\n\n\n",stmt5);
    		for(;;)
		{		
		$FETCH pro1 INTO $iprovision,$drate_ym,$iclass,$dbegin,$iarticle,$fcont1,$narticle,$icontent,$fcont2,$ncontent; 
			if (SQLCODE == SQLNOTFOUND) break;
			strcpy(iprovision,trim(iprovision));
			strcpy(drate_ym,trim(drate_ym));
			strcpy(iclass,trim(iclass));
			strcpy(dbegin2,cm_from_infdate_100(dbegin));
		    cm_char_split_3ymd(dbegin2,dbegin2_yy,dbegin2_mm,dbegin2_dd);
		    strcpy(ncontent2,trim(ncontent));
			strcpy(ncontent,rtrim(ncontent));
			strcpy(narticle,rtrim(narticle));
			if(iarticle ==1 && icontent ==1)
			{
				 $SELECT fcont,narticle
				    INTO $nprovision_fcont,$nprovision
				    FROM ca_provision
			           WHERE iprovision = $iprovision
			             AND drate_ym = $drate_ym
			             AND iclass = $iclass
			             AND dbegin = $dbegin
			             AND iarticle = 'P';
			              	
				  $SELECT fcont,narticle
				    INTO $nnumber_fcont,$nnumber
				    FROM ca_provision
			           WHERE iprovision = $iprovision
			             AND drate_ym = $drate_ym
			             AND iclass = $iclass
			             AND dbegin = $dbegin
			             AND iarticle = 'N';		
			
				fprintf(fp,"~~%s_%s_%s_%s%s%s\n",iprovision,drate_ym,iclass,dbegin2_yy,dbegin2_mm,dbegin2_dd);
				ptr = strtok(nprovision,",");
				while(ptr)
			  	{
				  	nprovision2[0] = '\0';
				  	strcpy(nprovision2,ptr);
				  	strcpy(nprovision2,trim(nprovision2));
				  	if(strlen(nprovision2) == 0)
				  	break;
					fprintf(fp,"%s%s\n",nprovision_fcont,nprovision2);
					ptr = strtok(NULL, ",");
				}
				ptr2 = strtok(nnumber,",");
				while(ptr2)
			  	{
				  	nnumber2[0] = '\0';
				  	strcpy(nnumber2,ptr2);
				  	strcpy(nnumber2,rtrim(nnumber2));
				  	if(strlen(nnumber2) == 0)
				  	break;
					fprintf(fp,"%s%s\n",nnumber_fcont,nnumber2);
					ptr2 = strtok(NULL, ",");
				}					
				fprintf(fp,"%s%s\n%s%s\n",fcont1,narticle,fcont2,ncontent);
			}
			else if(iarticle !=1 && icontent ==1) 
			{
				if(strlen(ncontent2)==0)
				fprintf(fp,"%s%s\n",fcont1,narticle);
				else
				fprintf(fp,"%s%s\n%s%s\n",fcont1,narticle,fcont2,ncontent);	
			}
			else
				fprintf(fp,"%s%s\n",fcont2,ncontent);		
		}
	$CLOSE pro1;
        $FREE  pro1;	
	}
	$CLOSE outdrate;
        $FREE  outdrate;
        
        fclose(fp);
        
        EXEC SQL INSERT INTO rptftplist (nuserid, ipgid,     noutfile,   dcreate)
                              VALUES ($userid, 'car162',  $filename1, $exec_time);
	$COMMIT WORK;
	return M_CM_OK;
	
errexit:
    fclose(fp);
    printf("-- Query_policy -- SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
    $ROLLBACK WORK;
    return SQLCODE;
}
/*-------------------------------THE END--------------------------------------*/


