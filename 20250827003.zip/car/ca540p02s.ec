/**********************************************************************/
/*   program id   : ca540p02s.ec                                      */
/*   program name : ��Q�I�߮׸�����ɳ���                            */
/*   date written : 2018/12/18 by sylvia                              */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "safeclib.h"


char  outputf[21];
$char userid[11], sdate1[11], sdate2[11],sIdatano[21],proce_type[2];
$char DBName[5];
$char msgbuf[1000],sApHome[30];
char  opt[2],dbgn[11],dend[11];
int rc;
DBinfo  *list;
int   count_db;
$int icnt = 0;

main(argc, argv)
int argc;
char **argv;
{

	batchinit();

	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(opt,            isNULLstr(argv[3])); /* �d�����O:0:���ɧ帹 1:���ɤ�� */
	strcpy(sIdatano,        isNULLstr(argv[4])); /* ���ɧ帹 */
	strcpy(dbgn,           isNULLstr(argv[5])); /* ���ɤ��:�_�� */
	strcpy(dend,           isNULLstr(argv[6])); /* ���ɤ��:���� */
	strcpy(outputf,        isNULLstr(argv[7]));

	strcpy(sdate1,cm_to_infdate(dbgn));
	strcpy(sdate2,cm_to_infdate(dend));

	printf("opt=[%s]sIdatano=[%s]\n",opt,sIdatano);

	rc = car540_get_db();
    if (rc != M_CM_OK) {
        printf("error on car540_get_db\n");
        return rc;
    }

	rc = car540_prepare_data();
	if (rc != M_CM_OK) {
	    printf("error on car540_prepare_data\n");
		return rc;
    }

	rc = car540_build();
	if (rc != M_CM_OK)
		return rc;
}
/* ------------------------------------------------------------------------- */
long car540_get_db()
{
    long	rc;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
    }

    if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;
    }

    rc = getApHome(sApHome);

    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }

    $create temp table tb540
    (
        iclaim          char(20),   --�߮׸�
        inumber_0800    char(20),   --0800MEMO
        itag            char(12),   --�P�Ӹ��X
        mamt38          int,        --38�I�ت��B
        mamt39          int,        --39�I�ت��B
        mamt238         int,        --238�I�ت��B
        mtotal          int,        --��Q�I���B
        ipolicy         char(20),   --�O�渹
        dreceiver       date,       --�o����
        invoice         char(20),   --�o�����X
        idatano         char(20),    --���ɧ帹
        dclose          date,       --�鵲��
        iqserial        char(20)    --�鵲�帹
    )with no log;

    return M_CM_OK;
}
/* ------------------------------------------------------------------------- */
long car540_prepare_data()
{
	$WHENEVER SQLERROR GOTO errexit;

    $char  sTmp1[100],sTmp2[200],stmt1[3000];
    int i;


    /* ���ɧ帹 �� ���ɤ�� */
    if (opt[0] == '0') {
        sprintf_s(sTmp1,100,"and idatano matches '%s'",sIdatano);
    }
    else if (opt[0] == '1') {
        sprintf_s(sTmp1,100,"and date(dcreate) between '%s' and '%s' ",sdate1,sdate2);
    }
    else
        strcpy(sTmp1," ");

     /* �`�N:�U�CSQL����''�OASCII��127�X,�b�S�w�r���~�ݱo��,�������@�Ӧr��,
       ���i�H�b��Excel�ɮɥi�H��ܧ��㪺�Ʀr, ���|�y�������D,���V��..
       add by sylvia 107.12.17 */
    sprintf_s(stmt1,3000,
        "insert into tb540 \
	     select iclaim, chr(127)||inumber_0800, chr(127)||itag, mins_38, mins_39, \
                mins_238, mamount, ipolicy, dreceiver, invoice, idatano, \
                dclose, iqserial \
           from sysdb:ca_tow_away \
          where 1=1  %s ", sTmp1 );
    printf("stmt1=[%s]\n",stmt1);
    $prepare pre1 from $stmt1;
    $execute pre1;


    $select count(*) into $icnt
      from tb540
     where 1=1;

	/* �Y�d�L���,�g�@���T����USER���D */
	if (icnt == 0)
	{
	    $insert into tb540 (iclaim) values ('�d�L��ơA�Э��s�T�{');
	}

	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/


long car540_build()
{
    $char    sfilename[51], stitle[1000], stmt[1000];

	$WHENEVER SQLERROR GOTO errexit;

	strcpy(sfilename,"��Q�I���ɳ���");
	if (opt[0] == '0')
	{
	    sprintf_s(stitle,1000,"���ɧ帹:%s\t",sIdatano);
	} else {
	    sprintf_s(stitle,1000,"���ɤ��:%s~%s\t",dbgn,dend);
	}
	strcat(stitle,"\n");
	strcat(stitle,"\t�߮׸�\t0800MEMO\t�P�Ӹ��X\t38�I�ت��B\t39�I�ت��B\t238�I�ت��B\t��Q�I���B\t");
	strcat(stitle,"�O�渹\t�o����\t�o�����X\t���ɧ帹\t�鵲��\t�鵲�帹\t");

	sprintf_s(stmt,1000,
	    "select * from tb540 order by 1 ");

	rc = unload_file(outputf," ",sfilename,stitle,stmt);

	if (rc != SUCCESS)
	{
	    sprintf_s(msgbuf,1000," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}

	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  static char sTmp_db_name[31];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}
