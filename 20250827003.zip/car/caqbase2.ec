/************************************************/
/*                                              */
/*   PROGRAM : caqbase2.ec by Han-Cheng Chen    */
/*                                              */
/*   PURPOSE : server side standard program     */
/*                                              */
/************************************************/

#include <stdio.h>
#include <string.h>
#include <decimal.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "bfsmsgs.h"
#include "cmnmsgs.h"
#include "carmsgs.h"
#include "cusmsgs.h"
#include "safeclib.h"
$include sqlca;
$include "var_length.h";

#define DATENULL                0x80000000L

/*
*  Name: caqbase2
*
*  Description: The purpose of this function is to select corresponding
*               name from database according to the namecode and option.
*
*/
char v_sMsg[1512];

long caqbase2(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long brand_push(), material_push(), material_push2(), benef_push(),
      cartype_push(), aligns_push();
 long edrtype_push(), settle_push(), settle_obj_push(),
      note_push();
 long select_code_data_itype_25();
 long select_user_iquota();
 long select_ca_comp_return();
 long select_ca_promote();
 long select_ibigcomp();
 long select_insurance_type(); /* �I�ة��� Modified by Julia in 2006/11/28 */
 long select_est_prem();       /* ���������߷s�}�@�T�{�O�O��function */
 long get_drate_date();       /* �̶O�v�N�����o�O�v�ͮĤ�� add by sylvia 100.03.28 */
 long cofirm_first_underwriter();	/* �O�_�㦳��֤H����� add by sylvia 102.03.14 */
 long get_first_underwriter(); /* ���o��֤H���M�� add by larry 104.03.17 */
 long get_ipre_rcv_info();
 long get_iscan_no(); /* 1060817004-C1 �q�lñ�p���y�Ǹ� */
 
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);

 printf("caqbase2[%c]\n",option);
 switch(option)
 {
  case 'A':
           rtncode=brand_push(reply);
           break;
  case 'a':
           rtncode=get_privilege_info(reply);
           break;
  case 'B':
           rtncode=material_push(reply);
           break;
  case 'b':
           rtncode=material_push2(reply);
           break;
  case 'C':
           rtncode=benef_push(reply);
           break;
  case 'c':
           rtncode=chk_holiday_info(reply);          /* ���o�U�@�Ӥu�@�� */
           break;
  case 'D':
           rtncode=cartype_push(reply);
           break;
  case 'd':
           rtncode=deduct_push(reply);               /* ���I�جd�ߩҦ��ۭt�B */
           break;
  case 'E':
           rtncode=aligns_push(reply, 2);
           break;
  case 'e':
  	   rtncode=chk_working_date_info(reply);     /* ���oN�u�@�ѫ᪺��� */
  	   break;
  case 'F':
  case 'G':
           rtncode=aligns_push(reply, 4);
           break;
  case 'f':
  	   rtncode=get_car_series(reply);            /* �̷Ӽt�P�������o���t */
  	   break;
  case 'g':
           rtncode = get_drate_date(reply);          /* �̶O�v�N�����o�O�v�ͮĤ� */
           break;
  case 'H':
           rtncode=edrtype_push(reply);
           break;
  case 'h':
           rtncode=chk_dmg_acc(reply);               /* �ˮ֨���Y�ƿ�J�O�_���T */
           break;
  case 'I':
           rtncode=settle_push(reply);
           break;
  case 'i':
           rtncode=get_provision(reply);	     /* �������S�����ڥN�� */
           break;
  case 'J':
           rtncode=note_push(reply);
           break;
  case 'j':
           rtncode=chk_provision_D(reply);	     /* D���ڤH���ˮ� */
           break;
  case 'K':
           rtncode=settle_obj_push(reply);
           break;
  case 'k':
           rtncode=get_customer_data(reply);	     /* ���ȪA��P�ɸ��(�q��(�])�B��ʹq�ܡBemail) */
           break;
  case 'L':
           rtncode=query_all_server_name(reply);
           break;
  case 'l':																						/* �p�gL */
           rtncode=GetCarCode(reply);		     /* ���ocar_code �浧��� */
           break;
  case 'M':
           rtncode=query_all_ibranch_name(reply);
           break;
  case 'm':
           rtncode=Get_Car_class(reply);	     /* ���ۥ���~���O */
           break;
  case 'N':
  	   rtncode=query_all_up_name(reply);
           break;
  case 'n':
           rtncode=cofirm_first_underwriter(reply);  /* �O�_�㦳��֤H����� */
           break;
  case 'O':
           rtncode=select_code_data_itype_25(reply);
           break;
  case 'o':																						/* �p�gO */
           rtncode=Get_Cu_code_data(reply);	     /* ���ocu_code_data �浧��� */
           break;
  case 'P':
           rtncode=select_user_iquota(reply);
           break;
  case 'p':
  	   rtncode=select_est_prem(reply);
  	   break;
  case 'Q':
           rtncode=select_ca_comp_return(reply);
           break;
  case 'q':
           rtncode=GetApplicant_W(reply);	     /* ���o��@W�g��N�����n�O�H��� */
           break;
  case 'R':
           rtncode=query_all_clm_ibranch_name(reply);
           break;
  case 'r':
           rtncode=GetLeaderQuota(reply);	     /* ���o���ĳq�����q���W�١B�޲z�H�B�~�Z��� �浧��� */
           break;
  case 'S':
           rtncode=select_ca_promote(reply);
           break;
  case 's':																	/* �p�g s */	
           rtncode=GetDReportOption(reply);	     /* ���o���w�r�p�H���������� */
           break;
  case 'T':
           rtncode=select_ibigcomp(reply);
           break;
  case 't':	
  	   rtncode=chk_est_fstatus(reply);           /* �ˮֳ�����ثe���A add by sylvia 102.03.19 */
           break;
  case 'U':
           rtncode=select_ca_ext_comp(reply);
           break;     
  case 'u':
           rtncode=check_policy_print(reply);        /* �ˮ֫O��O�_�i�C�L add by sylvia 102.03.19 */
           break; 
  case 'V':
           rtncode=query_all_icustomer_name(reply);
           break;
  case 'v':
           rtncode=chk_credit_dsign(reply);          /* �ˮ֫H�Υdñ�ָ�� add by sylvia 102.03.22 */
           break;
  case 'W':
           rtncode=confirm_icustomer(reply);
           break;          
  case 'w':
           rtncode=get_ibigcmp_list(reply);	     /* ���o�j�v�O�N�W�� add by sylvia */
           break;        
  case 'X':
           rtncode=get_wacc_reason_info(reply);
           break;
  case 'x':
           rtncode=get_sales_route(reply);	     /* �̳q�����u���q���N�� add by sylvia */
           break;
  case 'Y':
  	   rtncode=select_insurance_type(reply);
  	   break;
  case 'y':
  	   rtncode=chk_nequipment87(reply);	     /* ���O87��1,2�~�ӫO��� */
  	   break;
  case 'Z':
  	   rtncode=check_ibig_sales(reply);	     /* �j�g��Z */
  	   break;
  case 'z':																/* �p�g��z */
  	   rtncode=get_all_project(reply);	     /* ���Ҧ��M�ץ���O�N�� */
  	   break;
  case '1':
  	   rtncode=get_iengine_ibody(reply);
  	   break;	   
  case '2':
  	   rtncode=get_user_quota_list(reply);
  	   break;    	        
  case '3':
  	   rtncode=get_quota_name(reply);
  	   break;	   
  case '4':
  	   rtncode=get_ins_grp_dtl(reply);	     /* �����d�B����B���l�I�I�إN��(�A�O�ˮ֨ϥ�) */
  	   break;	   
  case '5':
  	   rtncode=check_personal_deny(reply);	     /* �ˮ֭Ӹ�O�_�w���� add by sylvia 103.02.13 (1020924002_C2) */
  	   break;	   
  case '6':
  	   rtncode=check_ply_renew11(reply);	     /*  103.07.25 �ˮ֬O�_�ŦX�ѵs�I��O��  */
  	   break;	   
  case '7':
  	   rtncode=get_sys_date(reply);	             /*  103.07.25 ���oSERVER�ݨt�Τ��(�ɶ�)  */
  	   break;  	 
  case '8':
  	   rtncode=get_officer_A(reply);             /*  103.09.24 ���oA*�g��N��(�Ѳ��sN*�M�׸g��ϥ�)  add by sylvia (103.09.24(1030630002_C1)  */
  	   break;
  case '9':
  	   rtncode=get_ply_info(reply);              /*  103.10.21 �H�d�����o�O����  103.10.15 (1030630002_C2_���M�ץ�@�~�Ҧ��վ� )  */
  	   break;  	   
  case '0':
  	   rtncode=check_ply_renew12(reply);	     /* �ˮ֬O�_�ŦX104�~1,2��u��O��v�w�q (1031111001_C1_���O�X������{���վ�) */
  	   break;  	   
  case '+':
   	   /*rtncode =get_302_by_iestimate(reply);*/ /* 104.01.19 ��CR�����o��O�ɸ�� */
   	   rtncode =get_estimate_date(reply);        /* 1041221009_C1_���T���d�I�Y�Ƭd�߳W�h�վ� */
   	   break;  
  case '-':
           rtncode=get_first_underwriter(reply);     /* ���o��֤H���M�� */
           break;       
  case '*':
  	   rtncode=get_ipre_rcv_info(reply);         /* ���o�@�γ������ɸ�T */
  	   break;
  case '~':
           rtncode=get_rel_card_pol_info(reply);     /* ���o���p�ҥd���ΫO�渹���O���T */
           break;
  case '!':
           rtncode=check_valid_isign(reply);         /* �ˮ֬O�_���A�椧�֫O�H�� */
           break;  
  case '@':
           rtncode=get_ply_for_isurvey(reply);       /* ���o�ˮְɨ��ӫO�Ҷ���� */
           break;         
  case '#':
  	   rtncode=check_ply_renew01(reply);         /*  104.07.29 �ˮ֬O�_�ŦX�����I��O��  */
  	   break;                     
  case '$':
           rtncode=get_ca_id_officer_iins(reply);    /* 104.11.02 ���o�Y����F���ڤ��Ҧ��I�� */
           break;   
  case '^':
           rtncode=chk_iroute_work(reply);           /* 104.12.15 �ˮ֬O�_�i�d�߸ӳq���N��  */  
           break;   
  case '&':
           rtncode=get_RisKCntry(reply);             /* 105.02.18 ���o�����I��a */  
           break;    
  case '(':
           rtncode=get_last_ply(reply);              /*  105.03.14 ���o�e�樮�� (1040720002_C1_�ץ��ߦw�����I�������l���p��覡)  */
           break;
  case ')':
           rtncode=chk_pay_status(reply);            /* 1050525001_C2 ���I�O���X�j�e�~�L�s */
           break;
  case '%':    
           rtncode=get_renew_data(reply);            /* 105.09.20 ���o�h�~(�̷s�O��)����O�ɤ��O��ID�B�ͮĤ�B�����B����������T */
           break;
  case ':':    
           rtncode=get_sp_20(reply);                 /* �P�_�O�_���S�w�O�g�N��(car153) */
           break;  
  case '[':    
           rtncode=chk_dply_close(reply);            /* �ˮ֬O�_�w�鵲 */
           break;     
  case ']':    
           rtncode=check_last_ply(reply);            /* ���o�e���T */
           break;          
  case '|':    
           rtncode=Get_Ca_Eply_Mail(reply);          /* ���o�q�l�O��k�Hmail�]�w(car164) */
           break;    
  case '_':	
  	   rtncode=Get_PlyInfo(reply);               /* car219 */
  	   break;    	        	               
  case '<':
  	   rtncode=get_iscan_no(reply);              /* 1060817004 -�q�lñ�p-���y�Ǹ�*/
  	   break;
  case '>':
  	   rtncode=get_leader_info(reply);           /* ���o�޲z�H��T */
  	   break;    	   	   
  case '?':
  	   rtncode=call_cm_preview_rba(reply);       /* �I�s cm_preview_rba */
  	   break;  
  case '=':
  	   rtncode=chk_ecard_log(reply);             /* chk 1070125001-SC2-�w�W�ǻ{�ҥ��x���j���I�O�B��歭��i�󥿡B�R��  */
  	   break;   	     	   
  case '/':
  	   rtncode=chk_fecard_sys(reply);            /* chk 1070125001-SC7-�q�l�j���Ҧ۰ʥX�����A�����\�R���O��  */
  	   break;   	     	   
  case '`':
  	   rtncode=Insert_CaLog(reply);              /* �g�Jca_log */
  	   break;   
  case '.':
  	   rtncode=get_est_ientry(reply);            /* ���o�պ��J�H�� */
  	   break;
  case '{':
  	   rtncode=query_all_clm_server_name(reply); /* �U�z�ߤ��� */
  	   break;  
  case '}':
  	   rtncode=get_ins_detail(reply);            /* ���o�O���I�ة��� */
  	   break;
  case ';':
  	   rtncode=get_302_ins_deduct(reply);        /* ���oCR(ply_ins_type_302)�ۭt�B */
  	   break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
             return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

/*
*  Name: brand_push
*
*  Description: Select car type name from database
*/
long brand_push(reply)
serverReply reply;
{
 $char DBName[5];
 $char upper[9], lower[9], brand_code[9], brand_abbr[13];
 $char nbrand[31];
 char nbrand_abbr[43];
 char  tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;
 int endlen;


 cm_buf_get("%s %s %s", DBName, lower, upper);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 if (strcmp(lower,"*")==0)
 {
        strcpy(lower,"00000000");
 }
 if(strcmp(upper,"*")==0)
 {
        strcpy(upper,"99999999");
 }

 endlen = strlen(trim(lower))-1;
 if (lower[endlen] == '*') lower[endlen] = ' ';
 endlen = strlen(trim(upper))-1;
 if (upper[endlen] == '*') upper[endlen] = '~';



                                        /*TONY 850926*/
printf("lower[%s]\n",lower);
printf("upper[%s]\n",upper);
 $DECLARE q_cur1 CURSOR FOR
   SELECT UNIQUE ibrand, nbrand_abbr, nbrand
     INTO $brand_code, $brand_abbr, $nbrand
     FROM ca_car_model  /* mag */
    WHERE ibrand >= $lower AND ibrand <= $upper;

 $OPEN q_cur1;

 for(;;)
  {
    $FETCH q_cur1;

    strcpy(nbrand_abbr, brand_abbr);
    strcat(nbrand_abbr, trim(nbrand));

    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();        /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    cm_buf_put("%s %s", brand_code, nbrand_abbr);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur1;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s",brand_code,nbrand_abbr);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur1;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CA_NBRAND) == True)
    return M_CA_NBRAND;
   else
    return apiRC;
  }

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}


/*
*  Name: material_push
*
*  Description: Select car series name from database
*/
long material_push(reply)
serverReply reply;
{
 $char DBName[5];
 $char upper[7], lower[7], material[7], mat_abbr[21],nmaterial[41];
 char  tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;

 cm_buf_get("%s %s %s", DBName, lower, upper);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
   return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

 if (strcmp(lower,"*")==0) strcpy(lower,"000000");
 if (strcmp(upper,"*")==0) strcpy(upper,"999999");
                                                /*TONY 850926*/
 $DECLARE q_cur2 CURSOR FOR
    SELECT imaterial, nmat_abbr,nmaterial
    INTO $material, $mat_abbr,$nmaterial
    FROM material
    WHERE $upper >= imaterial and imaterial >= $lower ;

 $OPEN q_cur2;

 for(;;)
  {
    $FETCH q_cur2;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();        /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    cm_buf_put("%s %s %s", material,nmaterial, mat_abbr);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur2;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s",material,nmaterial,mat_abbr);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur2;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   return exitsub(reply,M_CA_NMATERIAL) ? M_CA_NMATERIAL : apiRC;
  }

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: material_push2  �]503�o�{�u����ӰѼ�,�G����K�A�ƻs�@���������禡
*
*  Description: Select car series name from database
*/
long material_push2(reply)
serverReply reply;
{
 $char DBName[5];
 $char upper[7], lower[7], material[7], mat_abbr[21],nmaterial[41];
 char  tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;
 int last_star;

 cm_buf_get("%s %s %s", DBName, lower, upper);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
   return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

 if (strcmp(lower,"*")==0) strcpy(lower,"000000");
 else{
    last_star = strlen(trim(lower))-1;
    if (lower[last_star] == '*') lower[last_star] = ' ';
 }

 if (strcmp(upper,"*")==0) strcpy(upper,"999999");
 else{
    last_star = strlen(trim(upper))-1;
    if (upper[last_star] == '*') upper[last_star] = '~';
 }
                                                /*TONY 850926*/
 $DECLARE mater_cur2 CURSOR FOR
    SELECT imaterial, nmat_abbr,nmaterial
    INTO $material, $mat_abbr,$nmaterial
    FROM material
    WHERE $upper >= imaterial and imaterial >= $lower ;

 $OPEN mater_cur2;

 for(;;)
  {
    $FETCH mater_cur2;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();        /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    cm_buf_put("%s %s", material,nmaterial);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE mater_cur2;
        $FREE  mater_cur2;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s",material,nmaterial);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE mater_cur2 ;
 $FREE  mater_cur2 ;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   return exitsub(reply,M_CA_NMATERIAL) ? M_CA_NMATERIAL : apiRC;
  }

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: benef_push
*
*  Description: Select car type name from database
*/
long benef_push(reply)
serverReply reply;
{
 $char DBName[5];
 $char upper[11], lower[11], ibroker[11], nchi_full[31];
 char  tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;


 cm_buf_get("%s %s %s", DBName, lower, upper);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 if (strcmp(lower,"*")==0)
 {
        strcpy(lower,"       ");
 }
 if(strcmp(upper,"*")==0)
 {
        strcpy(upper,"~~~~~~~");
 }                                              /*TONY 851016*/

 /*$DECLARE q_curc CURSOR FOR
    SELECT ibroker, nchi_full
    INTO $ibroker, $nchi_full
    FROM broker_agent
    WHERE $upper >= ibroker and ibroker >= $lower ;*/

 /*�����Ȧ���W�Ӫ�nchi_full, ��H�Ȧ�²��nchi_abv 97.04.15 */

 $DECLARE q_curc CURSOR FOR
   SELECT ibank, nchi_abv
     INTO $ibroker, $nchi_full
     FROM bf_bank
    WHERE $upper >= ibank and ibank >= $lower ;

 $OPEN q_curc;

 for(;;)
  {
    $FETCH q_curc;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();        /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    cm_buf_put("%s %s",ibroker, nchi_full);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_curc;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s",ibroker,nchi_full);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_curc;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_BF_NBANK) == True)
    return M_BF_NBANK;
   else
    return apiRC;
  }

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}
/*
*  Name: cartype_push
*
*  Description: Select car type name from database
*/
long cartype_push(reply)
serverReply reply;
{
 $char DBName[5];
 $char upper[3], lower[3], code[3], name_code[11];
 char  tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;


 cm_buf_get("%s %s %s",DBName, lower, upper);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 if (strcmp(lower,"*")==0)
 {
        strcpy(lower,"00");
 }
 if(strcmp(upper,"*")==0)
 {
        strcpy(upper,"99");
 }                                              /*TONY 851016*/

 $DECLARE q_cur3 CURSOR FOR
    SELECT icode, ncode
    INTO $code, $name_code
    FROM car_type
    WHERE $upper >= icode and icode >= $lower 
     AND fclass ='1' ;

 $OPEN q_cur3;

 for(;;)
  {
    $FETCH q_cur3;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();        /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    cm_buf_put("%s %s",code, name_code);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur3;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s", code,name_code);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur3;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CA_NCARTYPE) == True)
    return M_CA_NCARTYPE;
   else
    return apiRC;
  }

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}

/*
*  Name: aligns_push
*
*  Description: Select alignment code and percentage
*/
long aligns_push(reply, class)
serverReply reply;
int class;
{
 $char DBName[5];
 $char upper[3], lower[3], code[3], iclass[2];
 $dec_t align_dec;
 double align;
 char  tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;


 cm_buf_get("%s %s %s",DBName, lower, upper);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 if ( class == 2)
     strcpy(iclass, "2");
 else if ( class == 4)
     strcpy(iclass, "4");
 if (strcmp(lower,"*")==0)
 {
        strcpy(lower,"00");
 }
 if(strcmp(upper,"*")==0)
 {
        strcpy(upper,"99");
 }                                              /*TONY 851016*/

 $DECLARE q_cur4 CURSOR FOR
    SELECT icode, palign
    INTO $code, $align_dec
    FROM alignment
    WHERE $upper >= icode and icode >= $lower and fclass = $iclass;

 $OPEN q_cur4;

 for(;;)
  {
    $FETCH q_cur4;
    if (SQLCODE != 0) break;
    dectodbl( &align_dec, &align);

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();        /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    cm_buf_put("%s %e",code, align);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur4;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %e", code, align);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur4;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CA_NALIGN) == True)
    return M_CA_NALIGN;
   else
    return apiRC;
  }

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}

/*
*  Name: edrtype_push
*
*  Description: Select endorsement code and name
*/
long edrtype_push(reply)
serverReply reply;
{
 $char DBName[5], class[2];
 $char upper[3], lower[3], code[3], ncode[11];
 char  tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;


 cm_buf_get("%s %s %s",DBName, lower, upper);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 strcpy(class, "1");
 if (strcmp(lower,"*")==0)
 {
        strcpy(lower,"00");
 }
 if(strcmp(upper,"*")==0)
 {
        strcpy(upper,"99");
 }

 $DECLARE q_cur5 CURSOR FOR
   SELECT icode, ncode
     INTO $code, $ncode
     FROM endorsement_code
    WHERE icode <= $upper AND icode >= $lower AND fclass=$class;

 $OPEN q_cur5;

 for(;;)
  {
    $FETCH q_cur5;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();        /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    cm_buf_put("%s %s",code, ncode);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur5;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s", code,ncode);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur5;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CA_NCODE) == True)
    return M_CA_NCODE;
   else
    return apiRC;
  }

errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}

/**********************************************
*  Name: settle_push
*
*  Description: Select paymentee and code
*/
long settle_push(reply)
serverReply reply;
{
 $char DBName[5];
 $char upper[13], lower[13], code[13], ncode[13];
 char  tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;

 cm_buf_get("%s %s %s",DBName, lower, upper);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
     return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

 if (strcmp(lower,"*")==0)
 {
        strcpy(lower,"00000000");
 }
 if(strcmp(upper,"*")==0)
 {
        strcpy(upper,"99999999");
 }                                              /*TONY 851016*/

 $DECLARE q_cur6 CURSOR FOR
    SELECT a.ifpce_id, a.nchi_abv
    INTO $code, $ncode
    FROM customer_basic_inf a,settlement_object b
    WHERE $upper >= b.ifpce_id AND b.ifpce_id >= $lower AND
          a.ifpce_id = b.ifpce_id;

 $OPEN q_cur6;

 for(;;)
  {
    $FETCH q_cur6;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();        /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    cm_buf_put("%s %s",code, ncode);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur6;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s", code,ncode);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur6;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   return exitsub(reply,M_CA_NCODE) ? M_CA_NCODE : apiRC;
  }

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: note_push
*
*  Description: Select note code and name
*/
long note_push(reply)
serverReply reply;
{
 $char DBName[5], class[2];
 $char upper[4], lower[4], code[4], code_name[41];
 char  tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;


 cm_buf_get("%s %s %s",DBName,lower, upper);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 strcpy(class, "2");
 if (strcmp(lower,"*")==0)
 {
        strcpy(lower,"00");
 }
 if(strcmp(upper,"*")==0)
 {
        strcpy(upper,"99");
 }                                              /*TONY 851016*/

 $DECLARE q_cur7 CURSOR FOR
    SELECT icode, ncode
    INTO $code, $code_name
    FROM adjustment_code
    WHERE $upper >= icode and icode >= $lower and fclass =$class;

 $OPEN q_cur7;

 for(;;)
  {
    $FETCH q_cur7;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();        /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    cm_buf_put("%s %s",code, code_name);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur7;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s", code, code_name);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur7;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CA_NCODE) == True)
    return M_CA_NCODE;
   else
    return apiRC;
  }

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}

/*
*  Name: settle_obj_push
*
*  Description: Select paymentee and code
*/
long settle_obj_push(reply)
serverReply reply;
{
 $char DBName[5];
 $char upper[13], lower[13], code[13], ncode[13];
 char  tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;


 cm_buf_get("%s %s %s",DBName, lower, upper);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 if (strcmp(lower,"*")==0)
 {
        strcpy(lower,"00000");
 }
 if(strcmp(upper,"*")==0)
 {
        strcpy(upper,"99999");
 }                                              /*TONY 851016*/

 $DECLARE q_cur8 CURSOR FOR
    SELECT ifpce_id, nchi_abv
    INTO $code, $ncode
    FROM customer_basic_inf
    WHERE $upper >= ifpce_id and ifpce_id >= $lower ;

 $OPEN q_cur8;

 for(;;)
  {
    $FETCH q_cur8;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();        /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    cm_buf_put("%s %s",code, ncode);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur8;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s", code,ncode);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur8;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CA_NCODE) == True)
    return M_CA_NCODE;
   else
    return apiRC;
  }

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}
/******************************************************************
*  select all the database's ibranch name and chinese name
*  modify by scott890523
*  �]�s�w��CAR517�ݨD�ӼW�[function,�ثe���t�εL�ϥ�
*
********************************************************************/
long query_all_server_name(reply)
serverReply reply;
{
 $char branch[3],chinese[11],DBName[5];
 int    tmp_len,server_count;
 server_count=0;

 cm_buf_get("%s", DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
   return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();
        cm_buf_res_count();

        $DECLARE a_cur CURSOR FOR
          SELECT servertbl.branch,servertbl.chinese
            INTO $branch,$chinese
            FROM servertbl,branch
           WHERE servertbl.branch=branch.ibranch
        ORDER BY servertbl.branch;

        $OPEN a_cur;

        while(1)
        {
        $FETCH a_cur;
        if(SQLCODE == SQLNOTFOUND) break;
        cm_buf_put("%s %s",branch,chinese);
        server_count ++;
        }
        $CLOSE a_cur;
        $FREE a_cur;

        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(server_count);
        tmp_len = cm_buf_len(ReplyBuf);


        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                return apiRC;
        else
                return api_OKComplete;


 errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/********************************************************************
*
*  select all the ibranch name and chinese name in this system
*  modify by SCOTT890523
*  �s�w��CAR517�ݨD,���ثe���t�εL�ϥ�
**********************************************************************/
long query_all_ibranch_name(reply)
serverReply reply;
{
 $char ibranch[3],nchi_full[41],DBName[5];
 int    tmp_len,branch_count;
 branch_count=0;

 cm_buf_get("%s", DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
   return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();
        cm_buf_res_count();

        $DECLARE b_cur CURSOR FOR
          SELECT ibranch,nchi_full
            INTO $ibranch,$nchi_full
            FROM branch
        ORDER BY ibranch;
        $OPEN b_cur;


        while(1)
        {
        $FETCH b_cur;
        if(SQLCODE == SQLNOTFOUND) break;
        cm_buf_put("%s %s",ibranch,nchi_full);
        branch_count ++;
        }
        $CLOSE b_cur;
        $FREE b_cur;

        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(branch_count);
        tmp_len = cm_buf_len(ReplyBuf);

        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                return apiRC;
        else
                return api_OKComplete;

 errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/***** �W�[�_�ϵ��T,���ϵ��T,�n�ϵ��T **********/
long query_all_clm_ibranch_name(reply)
serverReply reply;
{
 $char ibranch[3],nchi_full[41],DBName[5];
 int    tmp_len,branch_count;
 branch_count=0;

 cm_buf_get("%s", DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
   return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();
        cm_buf_res_count();

        $DECLARE b_cur1 CURSOR FOR
          SELECT ibranch,nchi_full
            INTO $ibranch,$nchi_full
            FROM v_branch
        ORDER BY ibranch;
        $OPEN b_cur1;

        while(1)
        {
        $FETCH b_cur1;
        if(SQLCODE == SQLNOTFOUND) break;
        cm_buf_put("%s %s",ibranch,nchi_full);
        branch_count ++;
        }
        $CLOSE b_cur1;
        $FREE b_cur1;

        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(branch_count);
        tmp_len = cm_buf_len(ReplyBuf);

        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                return apiRC;
        else
                return api_OKComplete;

 errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/*********************************************************************/

long query_all_up_name(reply)
serverReply reply;
{
 $char ibranch[3],nchi_full[41],DBName[5];
 int    tmp_len,branch_count;
 $char iupbranch[3];

 branch_count=0;
 cm_buf_get("%s", DBName);

 $WHENEVER SQLERROR GOTO errexit;
 if (db_select(DBName) == False)
   return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();
        cm_buf_res_count();

        $DECLARE up_cur CURSOR FOR
          SELECT unique iupbranch
            INTO $iupbranch
            FROM branch
        ORDER BY 1 ;

        $OPEN up_cur;
        while(1)
        {
        $FETCH up_cur;
        if(SQLCODE == SQLNOTFOUND) break;

        $SELECT ibranch,nchi_full
           INTO $ibranch,$nchi_full
           FROM branch
          WHERE ibranch = $iupbranch;

        cm_buf_put("%s %s",ibranch,nchi_full);
        branch_count ++;
        }
        $CLOSE up_cur;
        $FREE up_cur;

        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(branch_count);
        tmp_len = cm_buf_len(ReplyBuf);

        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                return apiRC;
        else
                return api_OKComplete;

 errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long select_code_data_itype_25(reply)
serverReply reply;
{
 $char   DBName[5],itype[3],icode[11],ncode[31];
 int     tmp_len;

 cm_buf_get("%s %s",DBName,itype);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
       return M_CM_DB_NOTOPEN;
   else
       return apiRC;
 }

 $SELECT ncode
    INTO $ncode
    FROM cu_code_data
   WHERE itype="25"
     AND icode=$itype;
 if(SQLCODE==SQLNOTFOUND)
 {
    if(exitsub(reply,M_CU_NCU_CODE_DATA) == True)
       return M_CU_NCU_CODE_DATA;
    else
       return apiRC;
 }

 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s",M_CM_OK,ncode);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
     return apiRC;
 else
     return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long select_user_iquota(reply)
serverReply reply;
{
     $char   DBName[5],userid[11],iquota[11];
     int     tmp_len;

     cm_buf_get("%s %s",DBName,userid);
     strcpy(userid, trim(userid));

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
     {
       if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
           return M_CM_DB_NOTOPEN;
       else
           return apiRC;
     }

     $SELECT iquota
        INTO $iquota
        FROM officer
       WHERE iofficer=$userid;
     if(SQLCODE==SQLNOTFOUND)
     {
        if(exitsub(reply,M_CU_NCU_CODE_DATA) == True)
           return M_CU_NCU_CODE_DATA;
        else
           return apiRC;
     }

     cm_buf_init(ReplyBuf);

     cm_buf_put("%l %s",M_CM_OK,iquota);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long select_ca_comp_return(reply)
serverReply reply;
{
   $char  DBName[5];
   int    tmp_len;
   $char  stmt[1024];
   $long  ca_count = 0;
   $long  dendorse;
   $char  sDendorse[10];

   cm_buf_get("%s", DBName);
   printf("select_ca_comp_return\n");

   $WHENEVER SQLERROR GOTO errexit;
   if (db_select(DBName) == False)
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

   cm_buf_init(ReplyBuf);
   cm_buf_res_msg();
   cm_buf_res_count();

   sprintf_s(stmt,sizeof stmt,"SELECT FIRST 3 %s FROM %s WHERE %s %s ",
                "UNIQUE dendorse ",
                "ca_comp_return ",
                "note = 'U' ",
                "ORDER BY dendorse desc ");
   $PREPARE ca_comp_tmp FROM :stmt;
   $DECLARE ca_comp_cur CURSOR FOR ca_comp_tmp;
   $OPEN    ca_comp_cur;
   while(1)
   {
        $FETCH ca_comp_cur INTO :dendorse;
        if(SQLCODE == SQLNOTFOUND) break;
        strcpy(sDendorse,cm_cdate_str_100(dendorse));

        cm_buf_put("%s",sDendorse);
        ca_count ++;
   }
   $CLOSE ca_comp_cur;
   $FREE  ca_comp_cur;

   cm_buf_put_msg(M_CM_OK);
   cm_buf_put_count(ca_count);
   tmp_len = cm_buf_len(ReplyBuf);

   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
   else
       return api_OKComplete;

errexit:
   return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long select_ca_promote(reply)
serverReply reply;
{
 $char   DBName[5],iprmt[11],nprmt[31];
 $int    qfield_all,qfield_chk;
 int     tmp_len,prmt_cnt;

 cm_buf_get("%s",DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
       return M_CM_DB_NOTOPEN;
   else
       return apiRC;
 }

 cm_buf_init(ReplyBuf);
 cm_buf_res_msg();
 cm_buf_res_count();

 prmt_cnt=0;
 $DECLARE cur_prmt cursor for
   SELECT iprmt,nprmt,qfield_all,qfield_chk
     INTO $iprmt,$nprmt,$qfield_all,$qfield_chk
     FROM ca_promote
    WHERE iprmt not in (select detail2 from car_code where kind = 'RN' and detail = 'PROJ_X')
    ORDER BY 1;
 $OPEN    cur_prmt;

 while(1) {
    $FETCH cur_prmt;
    if(SQLCODE==SQLNOTFOUND) break;
    sprintf_s(nprmt,sizeof nprmt,"%s(%d/%d)",rtrim(nprmt),qfield_chk,qfield_all);
    cm_buf_put("%s %s",iprmt,nprmt);
    prmt_cnt++;
 }
 $CLOSE cur_prmt;
 $FREE  cur_prmt;

 cm_buf_put_msg(M_CM_OK);
 cm_buf_put_count(prmt_cnt);
 tmp_len = cm_buf_len(ReplyBuf);

 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
     return apiRC;
 else
     return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long select_ibigcomp(reply)
serverReply reply;
{
 $char   DBName[5],icom[3],ncom[11],remark[41];
 int     tmp_len,com_cnt;

 cm_buf_get("%s",DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
       return M_CM_DB_NOTOPEN;
   else
       return apiRC;
 }

 cm_buf_init(ReplyBuf);
 cm_buf_res_msg();
 cm_buf_res_count();

 com_cnt=0;
 $DECLARE cur_com cursor for
   SELECT icode,ncode[1,4],tcode_remark
     INTO $icom,$ncom,$remark
     FROM cu_code_data
    WHERE itype = '21'
      AND icode != '00'
    ORDER BY 3;
 $OPEN    cur_com;

 while(1) {
    $FETCH cur_com;
    if(SQLCODE==SQLNOTFOUND) break;
    cm_buf_put("%s %s",icom,rtrim(ncom));
    com_cnt++;
 }
 $CLOSE cur_com;
 $FREE  cur_com;

 cm_buf_put_msg(M_CM_OK);
 cm_buf_put_count(com_cnt);
 tmp_len = cm_buf_len(ReplyBuf);

 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
     return apiRC;
 else
     return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long select_ca_ext_comp(reply)
serverReply reply;
{
 $char   DBName[5];
 $char   ipolicy[21],iengine[CA_ENGINE_NUM],itag[CA_TAG_NUM],fext[2],fnew[2];
 $char   dcheck[11],dply_begin[11],dissue[11],dchk_pay[11];
 $char   dconfirm[11],dcreate[11],dupdate[11],iprocess[11];
 $char   dendorse[11];
 int     tmp_len;

 cm_buf_get("%s %s",DBName,ipolicy);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
       return M_CM_DB_NOTOPEN;
   else
       return apiRC;
 }

 $SELECT ipolicy,iengine,itag,fext,dcheck,dply_begin,dissue,
         fnew,dchk_pay,dconfirm,dcreate,dupdate,
         (select nvl(nname,' ') from officer where iofficer = iprocess),
         nvl(dendorse,' ')
    INTO $ipolicy,$iengine,$itag,$fext,$dcheck,$dply_begin,$dissue,
         $fnew,$dchk_pay,$dconfirm,$dcreate,$dupdate,$iprocess,$dendorse
    FROM ca_ext_compulsory
   WHERE ipolicy = $ipolicy;
 if (SQLCODE==SQLNOTFOUND) {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)
           return M_CM_NOT_FOUND;
    else
           return apiRC;
 }

 cm_buf_init(ReplyBuf);
 cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
         M_CM_OK,ipolicy,iengine,itag,fext,dcheck,dply_begin,dissue,
         fnew,dchk_pay,dconfirm,dcreate,dupdate,iprocess,dendorse);

 tmp_len = cm_buf_len(ReplyBuf);

 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
     return apiRC;
 else
     return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


/*****  ����k�H�Ȥ�  **********/
long query_all_icustomer_name(reply)
serverReply reply;
{
 $char icustomer[16],nchi_full[41],DBName[5];
 int    tmp_len,icustomer_count;
 icustomer_count=0;

 cm_buf_get("%s", DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
   return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();
        cm_buf_res_count();

        $DECLARE b_cur_icus CURSOR FOR
          SELECT icustomer
            INTO $icustomer
            FROM ca_icustomer
        ORDER BY 1;
        $OPEN b_cur_icus;

        while(1)
        {
        $FETCH b_cur_icus;
        if(SQLCODE == SQLNOTFOUND) break;
        cm_buf_put("%s ",icustomer);
        icustomer_count ++;
        }
        $CLOSE b_cur_icus;
        $FREE b_cur_icus;

        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(icustomer_count);
        tmp_len = cm_buf_len(ReplyBuf);

        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                return apiRC;
        else
                return api_OKComplete;

 errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/*********************************************************************/

long confirm_icustomer(reply)
serverReply reply;
{
 $char icustomer[16],nchi_full[41],DBName[5];
 int    tmp_len,count , i;
 count =0;

printf(" *****************************\n");
 cm_buf_get("%s", DBName);
 printf( " 00000000000000000 \n");
 cm_buf_get("%d", &count);
 printf(" 111111111111111111 \n");



 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
   return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     $DELETE FROM ca_icustomer;

        for (i=0; i<count; i++) {
printf(" ********************************************** \n");
     cm_buf_get("%s " , icustomer  );

     $INSERT INTO  ca_icustomer
	 (icustomer  )  VALUES   ($icustomer );

     }

        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        tmp_len = cm_buf_len(ReplyBuf);

        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                return apiRC;
        else
                return api_OKComplete;

 errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/*********************************************************************/
/**********************************************************/
/******  �����O�T�I�X�I��] BEGIN COPY RIGHT BY MAX  ******/
/**********************************************************/
long get_wacc_reason_info(reply)
serverReply reply;
{
	$char DBName[5];
	$char icode[3], nabbr[9];
	int tmp_len;

	cm_buf_get("%s %s", DBName, icode);

	$WHENEVER SQLERROR GOTO errexit;
	if (db_select(DBName) == False)
	{
		if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}

	$SELECT distinct naccident
	INTO $nabbr
	FROM ot_accident
	WHERE iins_cat = 'C' AND icode[1,3] = $icode;
	if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CA_NACCREASON) == True)
			return M_CA_NACCREASON;
		else
			return apiRC;
	}

	cm_buf_init(ReplyBuf);

	cm_buf_put("%l %s",M_CM_OK,nabbr);

	tmp_len = cm_buf_len(ReplyBuf);
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		return apiRC;
	else
		return api_OKComplete;

	errexit:
		return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/******  �����O�T�I�X�I��] END  ******/

/**************************************/
/* Select �I�ة��� */
long select_insurance_type(reply)
serverReply reply;
{
 $char   DBName[5],iins_type[7],nins_abbr[21];
 int     tmp_len,prmt_cnt;

 cm_buf_get("%s",DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
       return M_CM_DB_NOTOPEN;
   else
       return apiRC;
 }

 cm_buf_init(ReplyBuf);
 cm_buf_res_msg();
 cm_buf_res_count();

 prmt_cnt=0;
 $DECLARE cur_iinstype cursor for
   SELECT iins_type,nins_abbr
     INTO $iins_type,$nins_abbr
     FROM insurance_type
    ORDER BY 1;
 $OPEN    cur_iinstype;

 while(1) {
    $FETCH cur_iinstype;
    if(SQLCODE==SQLNOTFOUND) break;
    /*sprintf_s(nprmt,sizeof nprmt,"%s(%d/%d)",rtrim(nprmt),qfield_chk,qfield_all);*/
    cm_buf_put("%s %s",iins_type,nins_abbr);
    prmt_cnt++;
 }
 $CLOSE cur_iinstype;
 $FREE  cur_iinstype;

 cm_buf_put_msg(M_CM_OK);
 cm_buf_put_count(prmt_cnt);
 tmp_len = cm_buf_len(ReplyBuf);

 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
     return apiRC;
 else
     return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long check_ibig_sales(reply)
serverReply reply;
{
  int    rc, tmp_len;
  $char  DBName[5];
  $char  iofficer[11], ibig_sales[11];
  $char  sMsg[512];

 cm_buf_get("%s %s %s", DBName, iofficer, ibig_sales);

 $WHENEVER SQLERROR GOTO errexit;

  rc = chk_ibig_sales( iofficer, ibig_sales, sMsg);
  if( rc != M_CM_OK);
  {
      if(exitsub(reply, rc) == True)
          return  rc;
      else
          return apiRC;
  }

  cm_buf_init(ReplyBuf);

  cm_buf_put("%l", rc);

  tmp_len = cm_buf_len(ReplyBuf);

   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
   else
       return api_OKComplete;


errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_privilege_info(reply)
serverReply reply;
{
     $char   DBName[5],userid[USERID], ipgid[IPGID];
     int     tmp_len, rc;
     $int    flevel;

     cm_buf_get("%s %s", DBName, userid);
     cm_buf_get("%s", ipgid);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
     {
       if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
           return M_CM_DB_NOTOPEN;
       else
           return apiRC;
     }

     rc = get_privilege( userid, ipgid, &flevel, v_sMsg);

     if( rc != M_CM_OK)
     {
        if(exitsub(reply, rc) == True)
           return  rc;
        else
           return apiRC;
     }

     cm_buf_init(ReplyBuf);

     cm_buf_put("%l %d",M_CM_OK, flevel);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/***********************************************************/
/*   �Y�O������^�ǤU�@�Ӥu�@��,�Y�D����h�^�ǶǤJ�����   */
/*   Created by Julia Han in 2008/09/16                    */
/***********************************************************/
long chk_holiday_info(reply)
serverReply reply;
{
     $char   DBName[5],before_date[11],after_date[11];
     int     tmp_len, rc;

     cm_buf_get("%s %s", DBName, before_date);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
     {
       if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
           return M_CM_DB_NOTOPEN;
       else
           return apiRC;
     }

     rc = chk_holiday( before_date, &after_date, v_sMsg);

     if( rc != M_CM_OK)
     {
        if(exitsub(reply, rc) == True)
           return  rc;
        else
           return apiRC;
     }

     cm_buf_init(ReplyBuf);

     cm_buf_put("%l %s",M_CM_OK, after_date);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*
*  Name: deduct_push
*
*  Description: Select type of deduct according to insurance_type from database
*/
long deduct_push(reply)
serverReply reply;
{
 $char DBName[5];
 $char upper[4], lower[4];
 $char iins_type[7],ndeduct[101],ndeduct_note[201];
 $char ninjure_cover[51], ndeath_cover[51], ndamage_cover[51];

 char  tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;


 cm_buf_get("%s %s %s",DBName, lower, upper);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 if (strcmp(lower,"*")==0)
 {
        strcpy(lower,"000");
 }
 if(strcmp(upper,"*")==0)
 {
        strcpy(upper,"999");
 }

 $DECLARE q_cur_ins CURSOR FOR
    SELECT iins_type, ndeduct, ndeduct_note, ninjure_cover, ndeath_cover, ndamage_cover
    INTO $iins_type, $ndeduct, $ndeduct_note, $ninjure_cover, $ndeath_cover, $ndamage_cover
    FROM insurance_type
    WHERE iins_type between $lower and $upper
      AND iins_type = iins_ply
      AND (dexpire = " " OR dexpire IS NULL)
 ORDER BY iins_type;

 $OPEN q_cur_ins;

 for(;;)
  {
    $FETCH q_cur_ins;
    if (SQLCODE != 0) break;

    strcpy(ndeduct,trim(ndeduct));
    strcpy(ndeduct_note,trim(ndeduct_note));
    /*strcpy(ninjure_cover,trim(ninjure_cover));
    strcpy(ndeath_cover,trim(ndeath_cover));
    strcpy(ndamage_cover,trim(ndamage_cover));*/

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();        /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    cm_buf_put("%s %s %s %s %s %s",iins_type, ndeduct, ndeduct_note,
                   ninjure_cover, ndeath_cover, ndamage_cover);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur3;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s %s %s %s", iins_type, ndeduct, ndeduct_note,
                             ninjure_cover, ndeath_cover, ndamage_cover);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE q_cur_ins;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CMN_NO_DATA_FOUND) == True)
    return M_CMN_NO_DATA_FOUND;
   else
    return apiRC;
  }

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}

/***********************************************************/
/*   1. �ΰj��Ū����J�������ca_holiday�T�{�Ӥ���O�_������,
        �Y�O������h�p���ܼ�(cnt)���[�@,�Y�D����h�p���ܼ�(cnt)�[�@,
        ����p���ܼƻP�ǤJ���u�@�ѼƧk�X�h���X�j��
     2. �N�ǤJ���u�@�ѼƧk�X������^��   */
/*   Created by Julia Han in 2008/09/16                    */
/***********************************************************/
long chk_working_date_info(reply)
serverReply reply;
{
     $char   DBName[5],before_date[11],after_date[11],str_days[2];
     int     tmp_len, rc;
     int     int_days=0;

     cm_buf_get("%s %s %s", DBName, before_date, str_days);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
     {
       if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
           return M_CM_DB_NOTOPEN;
       else
           return apiRC;
     }

     int_days = atoi(str_days);

     rc = chk_working_date( before_date, int_days, &after_date, v_sMsg);

     if( rc != M_CM_OK)
     {
        if(exitsub(reply, rc) == True)
           return  rc;
        else
           return apiRC;
     }

     cm_buf_init(ReplyBuf);

     cm_buf_put("%l %s",M_CM_OK, after_date);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*****************************************************************************/
/*   �ھڶǨӪ��պ⸹��X��Ʈw�����O�O�æ^��                                */
/*   �Y�O�������ߪ��H���h�䤻�Ӹ�Ʈw,�D�������ߤH���h�ȧ�M�ثe�Ҧb����Ʈw */
/*   Created by Julia Han in 2010/08/16                                      */
/*****************************************************************************/
long select_est_prem(reply)
serverReply reply;
{
     $char   DBName[5],userid[11],iestimate[21],iquota[11];
     $long   db_premium=0,tmp_premium=0;
     int     tmp_len, rc, i;
     int     count_db=0;
     $char    stmt[512];
     DBinfo  *list;

     cm_buf_get("%s %s %s", DBName, userid, iestimate);

     $WHENEVER SQLERROR GOTO errexit;

     if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
     {
        if(exitsub(reply,M_CM_NOT_DBLIST) == True)
           return M_CM_NOT_DBLIST;
        else
           return apiRC;
     }

     $SELECT iquota
        INTO $iquota
        FROM officer
       WHERE iofficer=$userid;
     if(SQLCODE==SQLNOTFOUND)
     {
        if(exitsub(reply,M_CU_NCU_CODE_DATA) == True)
           return M_CU_NCU_CODE_DATA;
        else
           return apiRC;
     }

     if (strncmp(iquota,"4204",4) == 0)
     {
     	  /* �]���O�������ߤH��,�Ҧ���Ʈw���n�� */
     	    for (i=0;i<count_db;i++)
          {
          	  sprintf_s( stmt,sizeof stmt, "SELECT (mpremium1 + mpremium2) "
                        "  FROM %s:estimate "
                        " WHERE iestimate = '%s'",list[i].dbname,iestimate);

              printf("stmt[%s]\n", stmt);
              $PREPARE prep_p FROM $stmt;
              $DECLARE prep_cur CURSOR FOR prep_p;
              $OPEN    prep_cur;
              $FETCH   prep_cur INTO $db_premium;

              if(SQLCODE==SQLNOTFOUND) continue;
              else
              {
              	  tmp_premium = db_premium;
              	  break;
              }
          }
          $FREE prep_p;
          $CLOSE prep_cur;
          $FREE  prep_cur;
printf("CP[%s],mpremium[%ld]\n",iestimate,tmp_premium);
     }
     else
     {
     	  /* �D�������ߤH���̶ȯ�bDBName�Ҧs��DB���� */
     	  if (db_select(DBName) == False)
        {
           if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
               return M_CM_DB_NOTOPEN;
           else
               return apiRC;
        }

     	  $SELECT (mpremium1 + mpremium2) INTO $tmp_premium
     	     FROM estimate
     	    WHERE iestimate = $iestimate;

        if(SQLCODE==SQLNOTFOUND) tmp_premium = 0;
     }

     cm_buf_init(ReplyBuf);

     cm_buf_put("%l %ld",M_CM_OK, tmp_premium);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* 104.09.09 fix ca_car_model �^���޿� */
long get_car_series(reply)
serverReply reply;
{
  int    rc, tmp_len;
  $char  DBName[5];
  $char  ibrand[9], icar_series[3], ipro_year[5];
  $char  sMsg[512];

 cm_buf_get("%s %s %s", DBName, ibrand, ipro_year);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
   return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

 $SELECT FIRST 1 icar_series INTO $icar_series
    FROM ca_car_model
   WHERE ibrand = $ibrand
     AND ipro_year = $ipro_year
     AND (dexpire is null or dexpire > today) ORDER BY drate desc;
 
  if(SQLCODE==SQLNOTFOUND)
  {
  	$SELECT UNIQUE icar_series INTO $icar_series
       FROM ca_car_model
      WHERE ibrand = $ibrand
        AND ipro_year=(SELECT MAX(ipro_year) 
                              FROM ca_car_model
                             WHERE ibrand=$ibrand
                               AND ipro_year < $ipro_year
                               AND (dexpire is null or dexpire > today));
	  if(SQLCODE==SQLNOTFOUND)
	  {
	  	$SELECT UNIQUE icar_series INTO $icar_series
	       FROM ca_car_model
	      WHERE ibrand = $ibrand
	        AND ipro_year=(SELECT MIN(ipro_year) 
	                              FROM ca_car_model
	                             WHERE ibrand=$ibrand
	                               AND ipro_year > $ipro_year
	                               AND (dexpire is null or dexpire > today));                               
	  }                             
  }

  cm_buf_init(ReplyBuf);

  cm_buf_put("%l %s", M_CM_OK, icar_series);

  tmp_len = cm_buf_len(ReplyBuf);

   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
   else
       return api_OKComplete;


errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


long get_drate_date(reply)
serverReply reply;
{
  int    rc, tmp_len;
  $char  DBName[5];
  $char  sIcode[6], sItable[31], sDrate[11];
  $char  sMsg[512];

 cm_buf_get("%s %s %s", DBName, sIcode, sItable);

 $WHENEVER SQLERROR GOTO errexit;
 if (db_select(DBName) == False)
 {
   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }

 $select drate into $sDrate
    from ca_rate_date
   where icode = $sIcode
     and itable = $sItable;

  if(SQLCODE == SQLNOTFOUND)
      strcpy(sDrate," ");

  cm_buf_init(ReplyBuf);

  cm_buf_put("%l %s", M_CM_OK, sDrate);

  tmp_len = cm_buf_len(ReplyBuf);

   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
   else
       return api_OKComplete;


errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* -------------------------------------------------------------------------- */
/* �ˮ֨���Y�ƿ�J�O�_���T */
long chk_dmg_acc(reply)
serverReply reply;
{
     $char   DBName[5],sFrate[5],sDmg_acc[10];
     $int    tmp_len,  iCount;

     cm_buf_get("%s %s %s", DBName, sFrate, sDmg_acc);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
     {
       if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
           return M_CM_DB_NOTOPEN;
       else
           return apiRC;
     }

     printf("sDmg_acc=[%s]\n",sDmg_acc);

     $select count(*) into $iCount
        from ca_acc_factor
       where pfactor = $sDmg_acc
         and drate = (select drate from ca_rate_date where icode = $sFrate
                         and itable = 'ca_acc_factor');

     if(SQLCODE == SQLNOTFOUND)
         iCount = 0;

     cm_buf_init(ReplyBuf);

     cm_buf_put("%l %d",M_CM_OK, iCount);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
long get_iengine_ibody(reply)
serverReply reply;
{
$char DBName[5];
$char ipolicy[21], sFullName[31], stmt[1024], iengine[CA_ENGINE_NUM], ibody[CA_BODY_NUM], icard[21],iassured[13],s_dbirth[11],rel_icard[21];
$int  tmp_len;

    cm_buf_get("%s",DBName);
    cm_buf_get("%s ",icard);

    if (db_select(DBName) == False)
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(ipolicy, " ");

    /* �������j��d����O�渹 */
    $select ipolicy into $ipolicy
      from compulsory_card
     where icard = $icard;
    if(SQLCODE == SQLNOTFOUND)
    {
        /* �q���N�d�ɧ�O�渹 */
        $select ipolicy into $ipolicy
           from card
          where icard = $icard;

        if(SQLCODE == SQLNOTFOUND)
        {
           strcpy(ipolicy, trim(icard));
        }
    }
    if (strlen(trim(ipolicy))==0) {
   	    return exitsub(reply,M_CA_NOT_PLY) ? M_CA_NOT_PLY : apiRC;
    }
    else
    {
        /*   1100809008-SC1-�ק�CAR301���~�T��201��r�T��  */
        if (strlen(trim(ipolicy)) < 13)
        {
            return exitsub(reply,M_CA_PLY_NEXIST) ? M_CA_PLY_NEXIST : apiRC;
        }
    }
   
    strcpy(iengine, " ");  strcpy(ibody, " ");	  strcpy(iassured, " "); 
    strcpy(s_dbirth, " "); strcpy(rel_icard, " ");
   printf("icard=[%s]ipolicy=[%s]\n",icard,ipolicy);
    strcpy(sFullName, get_car_full_db( ipolicy));

    sprintf_s(stmt,sizeof stmt, "SELECT nvl(iengine,' '), nvl(ibody,' '), iassured, nvl(dbirth,' '), icard "
                  "  FROM %s:policy "
                  " WHERE ipolicy = '%s' ",sFullName, ipolicy);

    $PREPARE prep1 FROM $stmt;
    $EXECUTE prep1 INTO $iengine, $ibody, $iassured, $s_dbirth, $rel_icard;
    if (SQLCODE == SQLNOTFOUND){
    	strcpy(ipolicy, " "); /* �L���p�O���� */
    }

    cm_buf_init(ReplyBuf);

    cm_buf_put("%l %s %s %s %s %s %s",M_CM_OK, iengine, ibody, iassured, s_dbirth, ipolicy, rel_icard );

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


/* ���S�����ڥN�� */
long get_provision(reply)
serverReply reply;
{
  $char  DBName[5];
  $char  iprovision[7], nprovision[41];/*1081225006-SC1-���ά�-�X�R���[���ڥN�X */
  $char  dactive[11],dexpire[11];
  char  tmpbuf[4000];
  int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
  int i,total_count=0;
    cm_buf_get("%s ", DBName);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }

    memset(iprovision,0x00,sizeof(iprovision));
    memset(nprovision,0x00,sizeof(nprovision));
    memset(dactive,0x00,sizeof(dactive));
    memset(dexpire,0x00,sizeof(dexpire));
    count = 0;
    /* cu_code_data.A5 ->�z�ߦ���tcode_remark,  ���ӷ�����²��   ����Ѧ�H0 �]���e�~�M��
        car_code.PR
    
	$DECLARE iCur1 CURSOR FOR
			SELECT kind, detail
			  INTO $sItype, $sIcode1
			  FROM car_code
			 WHERE kind in ('PR')
               AND (CASE WHEN engname=''  THEN today+1 ELSE trim(engname)::date END) > today;
	$OPEN iCur1;
	for(;;)
	{
		$FETCH iCur1;
		printf("sItype=[%s]sIcode1=[%s]\n",sItype,sIcode1);
        if(SQLCODE == SQLNOTFOUND) break;
        strcat(sIcodeA, trim(sIcode1));* �S������ *

	}
    */
    /*  
    1081225006-SC1-���ά�-�X�R���[���ڥN�X 
    �t�Τ�i�^���ɤήɧP�_�A���ͮĤ鶷�^��client�պ��˵��~���D�O�_�ŦX
    �^�����ΥͮĤ�-92��  ��h�W���N�I�����W�L92�ѥ��X��
    dactive_sys�ҥΨt�Τ�        dexpire_sys���Ψt�Τ�
    dactive    �ҥΥͮĤ�        dexpire    ���ΥͮĤ�
    nprovision-->���e����W��
    nprint->�����ϥ�
    */

    $DECLARE iCur1 CURSOR FOR
      SELECT iprovision, nprint,dactive,dexpire
        INTO $iprovision, $nprovision,$dactive,$dexpire
        FROM ca_provision_main
       WHERE (dactive_sys <= today  OR dactive_sys IS NULL)
         AND (dexpire_sys >  today  OR dexpire_sys IS NULL)
         AND (dexpire >  today - 92 OR dexpire IS NULL)
       ORDER BY 1;
       $OPEN iCur1;
    for(;;)
    {
        $FETCH iCur1;
        /*printf("iprovision=[%s]nprovision=[%s]dactive=[%s],dexpire=[%s]\n",iprovision,nprovision,dactive,dexpire);*/
        if(SQLCODE == SQLNOTFOUND) break;
        cm_buf_init(tmpbuf);
        if ( count == 0 )
        {
            cm_buf_res_msg();        /* reserve for MsgCode and count */
            cm_buf_res_count();
        }
        cm_buf_put("%s %s %s %s", iprovision,nprovision,dactive,dexpire);
        tmp_len = cm_buf_len(tmpbuf);
        if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
        {
            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count ++ ;
        }
        else                               /* more than 4K, send to client side */
        {
            cm_buf_init(ReplyBuf);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);
            if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
            {
                $CLOSE iCur1;
                return apiRC;
            }
            else               /* clear ReplyBuf and count to start all over again */
            {
                replycnt++;
                if (replycnt == 10)   /* more than 30K, client cannot display,error */
                {
                    cm_buf_init(ReplyBuf);
                    cm_buf_put("%l",M_CM_OUT_SPACE);
                    tmp_len = cm_buf_len(ReplyBuf);
                    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                    return apiRC;
                    return M_CM_OUT_SPACE;
                }
                ReplyBuf[0] = '\0';
                count = 0;
                cm_buf_init(ReplyBuf);
                cm_buf_res_msg();           /* reserve for MsgCode and count */
                cm_buf_res_count();
                cm_buf_put("%s %s %s %s", iprovision,nprovision,dactive,dexpire);
                repbuf_len = cm_buf_len(ReplyBuf);
                count++;
            }
        }
    }
    
    $CLOSE iCur1;
    if (count > 0)   /* break out, at least one record is selected */
    {
        cm_buf_init(ReplyBuf);
        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(count);
        if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
        return apiRC;
        return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
        if(exitsub(reply,M_CMN_NO_DATA_FOUND) == True)
        return M_CMN_NO_DATA_FOUND;
        else
        return apiRC;
    }

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/* ------------------------------------------------------------------------- */
/* D���ڤH���ˮ� */
long chk_provision_D(reply)
serverReply reply;
{
  int    rc, tmp_len;
  $char  DBName[5];
  $char  sqprovision[3], sDrate[5], sCheck[2], sIofficer[11];
  $char  sMsg[512];
  $int	 iqpro1, iqpro_max, iqpro_min;

	cm_buf_get("%s %s %s %s", DBName,sqprovision,sDrate,sIofficer);

	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False)
	{
		if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}

	iqpro1 = iqpro_max = iqpro_min = 0;

	strcpy(sqprovision, trim(sqprovision));
	iqpro1 = atoi(sqprovision);

	$SELECT max(icar_type), min(icar_type)
		 into $iqpro_max, $iqpro_min
     FROM ca_add_provision
    WHERE provision = "D"
      AND drate = (SELECT drate
                     FROM ca_rate_date
                    WHERE icode  = $sDrate
                      AND itable = 'ca_add_provision');

	if ((iqpro1 >= iqpro_min) && (iqpro1 <= iqpro_max))
	{
		    /* 1060701�ͮĤ���O��A�}��@�H */
			/* �Ȧ��@�H��,���ˮָg��O�_�bcar140(kind=30)���]�w�� add by sylvia 102.10.24 (1021018003_C1)
			if (iqpro1 == 1)
			{
				$select detail into $sIofficer
				   from car_code
				  where kind = '30'
				    and detail = $sIofficer
				    and detail2 = ' ';
				if (SQLCODE==SQLNOTFOUND)
						strcpy(sCheck, "N");
				else
						strcpy(sCheck, "Y");
			}
			else */
				strcpy(sCheck, "Y");
	}
	else
			strcpy(sCheck, "N");

  cm_buf_init(ReplyBuf);

	cm_buf_put("%l %s ", M_CM_OK, sCheck);

	tmp_len = cm_buf_len(ReplyBuf);

	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
			return apiRC;
	else
			return api_OKComplete;

	errexit:
  		return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* ���ȪA��P�ɸ��(�q��(�])�B��ʹq�ܡBemail) */
long get_customer_data(reply)
serverReply reply;
{
  int    rc, tmp_len;
  $char  DBName[5];
  $char  sItel_night[21], sMobil_phone[21], sIemail[51], sIfpce_id[11], sIfpce_ext[3];
  $char  sMsg[512];

	cm_buf_get("%s %s %s", DBName,sIfpce_id,sIfpce_ext);

	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False)
	{
		if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}

	memset(sItel_night,0x00,sizeof(sItel_night));
	memset(sMobil_phone,0x00,sizeof(sMobil_phone));
	memset(sIemail,0x00,sizeof(sIemail));


	$SELECT case when length(trim(tphone_con)) < 6 then
		 					 ' ' else tphone_con end,
					case when length(trim(imovephone)) < 6 then
					     ' ' else imovephone end,
					case when length(trim(iemail)) < 6 then
					     ' ' else iemail end
     INTO :sItel_night , :sMobil_phone, :sIemail
     FROM cu_customer
    WHERE ifpce_id     = $sIfpce_id
      AND ifpce_id_ext = $sIfpce_ext;

  cm_buf_init(ReplyBuf);

	printf("sItel_night=[%s]sMobil_phone=[%s]sIemail=[%s]\n",sItel_night, sMobil_phone, sIemail);
	cm_buf_put("%l %s %s %s", M_CM_OK, sItel_night, sMobil_phone, sIemail);

	tmp_len = cm_buf_len(ReplyBuf);

	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
			return apiRC;
	else
			return api_OKComplete;

	errexit:
  		return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/* ------------------------------------------------------------------------- */
long GetCarCode(reply)
serverReply reply;
{
  int    rc, tmp_len;
  long 	RTN;
  $char  DBName[5];
  $char  GKind[3], GDetail[21], GDetail2[21], GChiname[41], GEngname[41],
         sKind[3], sDetail[21], sDetail2[21], sChiname[41], sEngname[41],
         sTmpSQL[2000];
         
	GKind[0] = '\0';
	GDetail[0] = '\0';
	GDetail2[0] = '\0';
	GChiname[0] = '\0';
	GEngname[0] = '\0';
  sKind[0] = '\0';
  sDetail[0] = '\0';
  sDetail2[0] = '\0';
  sChiname[0] = '\0';
  sEngname[0] = '\0';
  
 	cm_buf_get("%s %s %s %s %s %s", 
 				DBName, GKind, GDetail, GDetail2, GChiname, GEngname);
 	
 	$WHENEVER SQLERROR GOTO errexit;
 	if (db_select(DBName) == False)
 	{
   	if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     		return M_CM_DB_NOTOPEN;
   	else
     		return apiRC;
 	}

	sprintf_s(sTmpSQL,sizeof sTmpSQL, "select detail, detail2, chiname, engname \
                      from car_code \
                     where kind matches '%s' and detail  matches '%s' \
                       and detail2 matches '%s' and chiname matches '%s' \
                       and engname matches '%s'",
                    GKind, GDetail, GDetail2, GChiname, GEngname);

	printf("sTmpSQL=[%s]\n",sTmpSQL);
 
	$PREPARE prep_carcode FROM $sTmpSQL;
  $EXECUTE prep_carcode INTO $sDetail, $sDetail2, $sChiname, $sEngname;
  
 	cm_buf_init(ReplyBuf);

  cm_buf_put("%l %s %s %s %s", 
  		M_CM_OK, sDetail, sDetail2, sChiname, sEngname);

  tmp_len = cm_buf_len(ReplyBuf);

   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
   else
       return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/* ------------------------------------------------------------ */
/* ���ۥ���~���O */
long Get_Car_class(reply)
serverReply reply;
{
  int    rc, tmp_len;
  long 	RTN;
  $char  DBName[5];
  $char  GIcode[3], sFcar_class[2];
         
	  
 	cm_buf_get("%s %s ", DBName, GIcode);
 	
 	$WHENEVER SQLERROR GOTO errexit;
 	if (db_select(DBName) == False)
 	{
   	if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     		return M_CM_DB_NOTOPEN;
   	else
     		return apiRC;
 	}

	$select fcar_class into $sFcar_class
	   from car_type where fclass = '1' and icode = $GIcode;
	
  cm_buf_init(ReplyBuf);

  cm_buf_put("%l %s ", M_CM_OK, sFcar_class);

  tmp_len = cm_buf_len(ReplyBuf);

   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
   else
       return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* ------------------------------------------------------------------------ */
/* ���ocu_code_data �浧��� */
long Get_Cu_code_data(reply)
serverReply reply;
{
  int    rc, tmp_len;
  long 	RTN;
  $char  DBName[5];
  $char  GItype[3], GIcode[11], GNcode[41], GTcode_remark[21], 
         sItype[3], sIcode[11], sNcode[41], sTcode_remark[21], 
         sTmpSQL[2000];
         
	GItype[0] = '\0';
	GIcode[0] = '\0';
	GNcode[0] = '\0';
	GTcode_remark[0] = '\0';
	sItype[0] = '\0';
  sIcode[0] = '\0';
  sNcode[0] = '\0';
  sTcode_remark[0] = '\0';
  
 	cm_buf_get("%s %s %s %s %s ", 
 				DBName, GItype, GIcode, GNcode, GTcode_remark);
 	
 	$WHENEVER SQLERROR GOTO errexit;
 	if (db_select(DBName) == False)
 	{
   	if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     		return M_CM_DB_NOTOPEN;
   	else
     		return apiRC;
 	}

	sprintf_s(sTmpSQL,sizeof sTmpSQL, "select icode, ncode, tcode_remark \
                      from cu_code_data \
                     where itype matches '%s' and icode  matches '%s' \
                       and ncode matches '%s' and tcode_remark matches '%s'",
                    GItype, GIcode, GNcode, GTcode_remark);

	printf("sTmpSQL=[%s]\n",sTmpSQL);
 
	$PREPARE prep_cucode FROM $sTmpSQL;
  $EXECUTE prep_cucode INTO $sIcode, $sNcode, $sTcode_remark;
  
 	cm_buf_init(ReplyBuf);

  cm_buf_put("%l %s %s %s ", 
  		M_CM_OK, sIcode, sNcode, sTcode_remark);

  tmp_len = cm_buf_len(ReplyBuf);

   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
   else
       return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/* ------------------------------------------------------------------------- */
/* ���o��@W�g��N�����n�O�H��� */
long GetApplicant_W(reply)
serverReply reply;
{
  int    rc, tmp_len;
  $long  lDbirth_appl;
  $char  DBName[5], sTmpSQL[1024];
  $char  sWofficer[11], sBig_office[10];
  $char  sIofficer[11], iprmt[11], sImodule[2], sIdealer[4], sFapplicant[2],
			   sIapplicant[13], sFsex_appl[2], sDbirth_appl[11], sNapplicant[121], 
			   sItel_appl[21], sApayment_zip[CA_ZIP], sApayment[91], sNdeputy_appl[51],
			   sNrelation_appl[41];/* 1090525004-SC1-�]�y��-�s���l���ϸ�3+3   ZIP_CODE 5+1->CA_ZIP 6+1*/
         

 	cm_buf_get("%s %s %s", DBName, sWofficer, sBig_office);
 	
 	strcpy(sWofficer, trim(sWofficer));					/* W �g��N�� */
 	strcpy(sBig_office, trim(sBig_office));			/* ������~�� */
 	
 	$WHENEVER SQLERROR GOTO errexit;
 	if (db_select(DBName) == False)
 	{
   	if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     		return M_CM_DB_NOTOPEN;
   	else
     		return apiRC;
 	}

	sprintf_s(sTmpSQL, sizeof sTmpSQL,
			"SELECT b.iofficer, b.iprmt, c.imodule, d.idealer, d.fapplicant, "
			"       d.iapplicant, d.fsex_appl, d.dbirth_appl, d.napplicant, "
			"       d.itel_appl, d.apayment_zip, d.apayment, d.ndeputy_appl, "
			"       d.nrelation_appl "
      "  FROM ca_promote_officer b,ca_promote c, ca_dealer_appl d "
      " WHERE b.iprmt = c.iprmt "
      "   AND (CASE WHEN c.imodule ='2' THEN b.iofficer[1,3] "
      "             ELSE b.iofficer[1] END ) = d.idealer "
      "   AND b.iofficer_ori = '%s' and b.ibig_office = '%s';",
      sWofficer, sBig_office);

	printf("sTmpSQL=[%s]\n",sTmpSQL);
 
	$PREPARE prep_caseq FROM $sTmpSQL;
  $EXECUTE prep_caseq INTO 
  		$sIofficer, $iprmt, $sImodule, $sIdealer, $sFapplicant,
			$sIapplicant, $sFsex_appl, $lDbirth_appl, $sNapplicant,
			$sItel_appl, $sApayment_zip, $sApayment, $sNdeputy_appl,
			$sNrelation_appl;
  
	if (SQLCODE==SQLNOTFOUND) {
  	if(exitsub(reply,M_CM_NOT_FOUND) == True)
    	return M_CM_NOT_FOUND;
    else
			return apiRC;
	}
	
	strcpy(sDbirth_appl, cm_cdate_str_100(lDbirth_appl));	/* �n�O�H�ͤ� */
  
 	cm_buf_init(ReplyBuf);

  cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s", 
  		M_CM_OK, sIofficer, iprmt, sImodule, sIdealer, sFapplicant,
			sIapplicant, sFsex_appl, sDbirth_appl, sNapplicant,
			sItel_appl, sApayment_zip, sApayment, sNdeputy_appl, sNrelation_appl);

  tmp_len = cm_buf_len(ReplyBuf);

   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
   else
       return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* ���o���ĳq�����q���W�١B�޲z�H�B�~�Z��� �浧��� */
long GetLeaderQuota(reply)
serverReply reply;
{
  int    rc, tmp_len;
  long 	RTN;
  $char  DBName[5];
  $char  GIroute[21], sNroute[41], sNleader[41], sNbranch[41],
         sTmpSQL[2000];
         
	GIroute[0] = '\0';
	sNroute[0] = '\0';
	sNleader[0] = '\0';
	sNbranch[0] = '\0';
  
 	cm_buf_get("%s %s", DBName, GIroute);
 	
 	$WHENEVER SQLERROR GOTO errexit;
 	if (db_select(DBName) == False)
 	{
   	if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     		return M_CM_DB_NOTOPEN;
   	else
     		return apiRC;
 	}

	sprintf_s(sTmpSQL,sizeof sTmpSQL, "select a.nroute, b.nname, c.nbranch \
                     from cm_route a, officer b, sa_branch_type c \
                    where a.ileader = b.iofficer and b.iquota = c.ibranch \
                      and (a.dexpire is null or a.dexpire > today) \
                      and a.iroute matches '%s' ",GIroute);

	printf("sTmpSQL=[%s]\n",sTmpSQL);
 
	$PREPARE prep_GETL1 FROM $sTmpSQL;
  $EXECUTE prep_GETL1 INTO $sNroute, $sNleader, $sNbranch;
  
 	cm_buf_init(ReplyBuf);

  cm_buf_put("%l %s %s %s ", 
  		M_CM_OK, sNroute, sNleader, sNbranch);

  tmp_len = cm_buf_len(ReplyBuf);

   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
   else
       return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/* -------------------------------------------------------------------------- */
long GetDReportOption(reply)
serverReply reply;
{
    $char DBName[5], OptKind[3];
    $char sDetail[21], sChiname[41];
    $int  iCount;
    int tmp_len;
    cm_buf_get("%s %s",DBName, OptKind);

    $WHENEVER SQLERROR GOTO errexit;
    
		if (db_select(DBName) == False)
   		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $SELECT count(unique detail)	INTO $iCount
       FROM car_code
      WHERE kind = $OptKind; 

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    cm_buf_put("%d",iCount);
    
    $DECLARE Dreport CURSOR FOR
     SELECT unique detail, chiname
       INTO $sDetail, $sChiname
       FROM car_code
      WHERE kind = $OptKind
      ORDER BY detail;

    $OPEN Dreport;
    for(;;)
    {
        $FETCH Dreport;
        if(SQLCODE==SQLNOTFOUND) break;
        cm_buf_put("%s",sDetail);
        cm_buf_put("%s",sChiname);
        
    }
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;
   
errexit:
    if(exitsub(reply,SQLCODE) == True) 
        return SQLCODE;
    else  
        return apiRC;
}
/* --------------------------------------------------------------------------- */
/* ���ouser�i�X�椧�~�Z���N�X(�h��) */
long get_user_quota_list(reply)
serverReply reply;
{	
	 $char   DBName[5],userid[11],unit_id[7],unit_name[41];
	 int     tmp_len,cnt;
	 $char   IsManager[2];
	
     cm_buf_get("%s %s",DBName,userid);
	
	 $WHENEVER SQLERROR GOTO errexit;
	
	 if (db_select(DBName) == False)
	 {
	   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
	       return M_CM_DB_NOTOPEN;
	   else
	       return apiRC;
	 }
	
	 cm_buf_init(ReplyBuf);
	 cm_buf_res_msg();
	 cm_buf_res_count();

     cnt=0;
     strcpy(unit_id," ");
     strcpy(unit_name," ");
     strcpy(IsManager," ");
     $DECLARE cur_Unit CURSOR FOR
       SELECT a.iquota,b.nbranch
         FROM officer a ,sa_branch_type b
        WHERE a.iquota   = b.ibranch
          AND a.iofficer = $userid
       UNION
       SELECT a.code_no,b.nbranch
        FROM personal:unitid2ef a, sa_branch_type b
       WHERE a.resp_name = $userid
         AND a.code_no   = b.ibranch
         AND a.code_no[3,6] <>'0000'
         AND b.dexpire is null
       UNION
       SELECT code_no,code_name
        FROM personal:unitid2ef 
       WHERE resp_name = $userid
         AND code_no[3,6] = '0000' ;
	   
     $OPEN    cur_Unit;
	 for(;;) {
	    $FETCH cur_Unit INTO $unit_id, $unit_name ;
	    if(SQLCODE==SQLNOTFOUND) break;

	    $SELECT CASE WHEN (count(*)>0) THEN 'Y' ELSE 'N' END 
	       INTO $IsManager      	
	       FROM personal:unitid2ef 
          WHERE resp_name =$userid ;	 	  
          
	    cm_buf_put("%s %s %s",unit_id, unit_name,IsManager);
	    cnt++;
	 }
	 $CLOSE cur_Unit;
	 $FREE  cur_Unit;

     cm_buf_put_msg(M_CM_OK);
     cm_buf_put_count(cnt);
     tmp_len = cm_buf_len(ReplyBuf);

     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/* --------------------------------------------------------------------------- */
/* ���o "�~�Z���W��"  */
long get_quota_name(reply)
serverReply reply;
{
     $char   DBName[5],sIquota[7],sNquota[41];
     int     tmp_len;

     cm_buf_get("%s %s",DBName,sIquota);
     strcpy(sIquota, trim(sIquota));

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
     {
       if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
           return M_CM_DB_NOTOPEN;
       else
           return apiRC;
     }

     strcpy(sNquota," ");
     if (sIquota[2]=='*') /* ex. '22*'   */
     {
		 $SELECT first 1 code_name INTO $sNquota 
		    FROM personal:unitid2ef
		   WHERE code_no matches $sIquota
		   ORDER BY 1 ;
     }else{      	
	     $SELECT first 1 nbranch INTO $sNquota 
  	        FROM sa_branch_type 
	       WHERE ibranch matches $sIquota
	       ORDER BY 1 ;
     }
     cm_buf_init(ReplyBuf);
     cm_buf_put("%l %s",M_CM_OK,sNquota);
     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/* --------------------------------------------------------------------------- */
/* �O�_�㦳��֤H����� add by sylvia 102.03.14 */
long cofirm_first_underwriter(reply)
serverReply reply;
{
  int    rc, tmp_len;
  long 	RTN;
  $char  DBName[5];
  $char  iofficer[7],sConfirm[2];
  $int  iCount;
         
	  
 	cm_buf_get("%s %s ", DBName, iofficer);
 	
 	$WHENEVER SQLERROR GOTO errexit;
 	if (db_select(DBName) == False)
 	{
   	if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     		return M_CM_DB_NOTOPEN;
   	else
     		return apiRC;
 	}

	$select count(*) into $iCount
	   from car_code 
	  where kind = '27'
      and detail = $iofficer
      and detail2 = $DBName;
	
	if (iCount > 0)
			strcpy(sConfirm, "Y");
	else
			strcpy(sConfirm, "N");
			
  cm_buf_init(ReplyBuf);

  cm_buf_put("%l %s ", M_CM_OK, sConfirm);

  tmp_len = cm_buf_len(ReplyBuf);

   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
   else
       return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/* -------------------------------------------------------------------------- */
/* 1031111001_C1_���O�X������{���վ� */ 
/* �s�W���o"�������"*/
/* �ˮֳ�����ثe���A add by sylvia 102.03.19 */
/* �s�Wñ�p��(dsign) 1040918005_C2_�g�ȫD�����X���ˮ֤ΫO����ɭץ� */
long chk_est_fstatus(reply)
serverReply reply;
{
    int    rc, tmp_len;
    $char  DBName[5];
    $char sIestimate[21],sAbn_type[2],sIaccept_keyin[21];
    $char sTmpStr[2048];
    $char sFuw_status[4], sIuw_first[11], sDuw_first[21], ipre_rcv_ori[21],
          sDply1_begin[11], sDply1_end[11], sDply2_begin[11], sDply2_end[11],sDentry[11],sDsign[11],
          dProprem[11]    , cm_prem[11]   , sIcomm_obj1[11]  ,sIcomm_obj2[11],ftype_pol[3] ,ftype_sp[3] ;
    $char iroute_accept[21];/*1090821009-SC1-�ק�O����(I050)�q�����z�s����h */
    $char siroute_main[13];
    cm_buf_get("%s %s %s %s", DBName, sIestimate, sAbn_type, sIaccept_keyin);

    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }
    strcpy(sDentry," " );     strcpy(dProprem," " );    strcpy(sDsign, " ");	 
    strcpy(sIcomm_obj1," " ); strcpy(sIcomm_obj2," " ); strcpy(sDply2_begin, " ");  strcpy(sDply2_end, " ");		
    strcpy(iroute_accept," ");
    strcpy(siroute_main," ");
    strcpy(sIestimate, trim(sIestimate));
    strcpy(sAbn_type, trim(sAbn_type));
    strcpy(sIaccept_keyin, trim(sIaccept_keyin));
    printf("--- 3457 sAbn_type=[%s] sIestimate=[%s]\n",sAbn_type,sIestimate);

    /*  1090504007-SC1-���ʱo-�ɤs�����{���}�o -cm_route_fback*/
    if ((strcmp(sAbn_type,"Y") == 0) || (strcmp(sAbn_type,"S") == 0))
    {
        sprintf_s(sTmpStr,sizeof sTmpStr,
            "select fuw_status, decode(trim(iuw_first),'system','�t�ή֫O', \
                    (select nname from officer where iofficer = a.iuw_first)), \
                    duw_first, \
                    dcomp_begin, dcomp_end, dbegin, dend, \
                    nvl((select sum(mins_premium) from newa00:abn_ply_ins_type \
                      where iabnormal = a.iabnormal and fproject <> 'Y'),0), \
                    dentry,icomm_obj1,icomm_obj2, \
                    nvl(dsign,' ')::date, a.iaccept, c.iroute_main \
               from newa00:abnormal_ply a , cm_route c\
              where iabnormal = '%s' \
                AND a.iroute=c.iroute; ",sIestimate);
    }
    else
    {
        sprintf_s(sTmpStr,sizeof sTmpStr,
            "select fuw_status, decode(trim(iuw_first),'system','�t�ή֫O', \
                    (select nname from officer where iofficer = a.iuw_first)), \
                    duw_first,  \
                    dply1_begin, dply1_end, dply2_begin, dply2_end, \
                    nvl((select sum(mins_premium) from est_ins_type \
                          where iestimate = a.iestimate and fproject <> 'Y'),0), \
                    dentry,icomm_obj1,icomm_obj2, \
                    nvl(dsign,' ')::date, a.iaccept, c.iroute_main \
               from estimate a, cm_route c \
              where iestimate = '%s'\
                AND a.iroute=c.iroute; ",sIestimate);
    }
    
    printf("sTmpStr=[%s]\n",sTmpStr);
        
    $PREPARE pre_chk_est1 FROM $sTmpStr;
    $DECLARE cur_chk_est1 CURSOR FOR pre_chk_est1;
    $OPEN    cur_chk_est1;
    $FETCH   cur_chk_est1 into  $sFuw_status, $sIuw_first, $sDuw_first,
                                $sDply1_begin, $sDply1_end,
                                $sDply2_begin, $sDply2_end, $dProprem, $sDentry,$sIcomm_obj1,$sIcomm_obj2,$sDsign,
                                $iroute_accept, $siroute_main;
                                    

    if(SQLCODE == SQLNOTFOUND) 
    {
        printf("--- 3492 sAbn_type=[%s] sIestimate=[%s]\n",sAbn_type,sIestimate);
        /* �i��O������ɪ� */
        $select distinct '500','�t�ή֫O',dentry, 
               (select deffect from cm_pre_receive where ipre_rcv = a.ipre_rcv 
                   and iins_cat = 'C' and iins_kind = '1'),' ', 
                     (select deffect from cm_pre_receive where ipre_rcv = a.ipre_rcv 
                   and iins_cat = 'C' and iins_kind = '2' and ipre_end = ' '), 
               ' ', (select sum(nvl(mprem,0)) from cm_pre_receive
                      where ipre_rcv = a.ipre_rcv), dentry,
               (select icomm_obj from cm_pre_receive where ipre_rcv = a.ipre_rcv 
                   and iins_cat = 'C' and iins_kind = '1'),
               (select icomm_obj from cm_pre_receive where ipre_rcv = a.ipre_rcv 
                   and iins_cat = 'C' and iins_kind = '2'), b.iroute_main	           		              
          into $sFuw_status, $sIuw_first, $sDuw_first,
               $sDply1_begin, $sDply1_end,
               $sDply2_begin, $sDply2_end, $dProprem, $sDentry,$sIcomm_obj1,$sIcomm_obj2,
               $siroute_main
          from cm_pre_receive a, cm_route b
         where iins_cat = 'C' and ipre_rcv = $sIestimate and a.iroute = b.iroute;
             

        
    }		                            
    $close    cur_chk_est1;
    $free    cur_chk_est1;
    
    printf("--sDsign=[%s]\n ",sDsign);  
     
    /*  1090504007-SC1-���ʱo-�ɤs�����{���}�o */   
    if(strncmp(siroute_main,"I808",4) == 0)
    {
        $SELECT dcreate
           into $sDsign
           FROM sysdb:cm_route_fback
          WHERE iroute_main[1,4] ='I808'
            AND iroute_accept = $sIestimate;
        if(SQLCODE == SQLNOTFOUND) strcpy(sDsign,"");        	
    }
    
    
    
    /* 1120616008_C01_����(I807)�ץ�X��d�����z�s�� (�U�I�X��{��SAM403) */
    if (strcmp(trim(sDsign),"") == 0 && strncmp(siroute_main,"I807",4) == 0)
    {
        $SELECT dcreate
           into $sDsign
           FROM sysdb:cm_route_fback
          WHERE iroute_main[1,4] ='I807'
            AND iroute_accept = $sIaccept_keyin;
        if(SQLCODE == SQLNOTFOUND) strcpy(sDsign,"");     	
    	
    }
    /* 1130424007_C01_SAM403�d���X��\��s�WI009���� */
    if (strcmp(trim(sDsign),"") == 0 && strncmp(siroute_main,"I009",4) == 0)
    {
        $SELECT dcreate
           into $sDsign
           FROM sysdb:cm_route_fback
          WHERE iroute_main[1,4] ='I009'
            AND iroute_accept = $sIaccept_keyin;
        if(SQLCODE == SQLNOTFOUND) strcpy(sDsign,"");
    	
    } 
    
    
    printf("--cm_route_fback.sDsign[%s]\n ",sDsign);
    /* 1040225003_C1 �s�W���o ftype_pol,ftype_sp  */
    strcpy(cm_prem," " );  strcpy(ftype_pol," " ); strcpy(ftype_sp," " ); strcpy(ipre_rcv_ori," " );
    $select nvl(sum(mprem),0), max(dentry) ,max(ftype_pol),max(ftype_sp),max(ipre_rcv_ori)
      into $cm_prem ,$sDentry, $ftype_pol ,$ftype_sp, $ipre_rcv_ori
       from cm_pre_receive
      where ipre_rcv = $sIestimate 
        and ipre_end = ' ';

          
    

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
                M_CM_OK, sFuw_status, sIuw_first, sDuw_first, 
                sDply1_begin, sDply1_end, sDply2_begin, sDply2_end, dProprem,cm_prem,
                sDentry,sIcomm_obj1,sIcomm_obj2,ftype_pol ,ftype_sp,sDsign,ipre_rcv_ori,iroute_accept);

    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
    else
       return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/* ------------------------------------------------------------------------------------- */
/* �ˮ֫O��O�_�i�C�L add by sylvia 102.03.19 */
long check_policy_print(reply)
serverReply reply;
{
	int    rc, tmp_len;
	$char  DBName[5];
    $char sIpolicy[21], sAbn_type[2], sIestimate[21], sIcomm_obj[11], sImgr[2],
          sIpolicy1[21], sIpolicy2[21], sFstatus[3], ipre_rcv[21], iins_kind[2];
    $char sTmpStr[1000];
    $int  iCountJC,  iCountEW, iCountSP, ifuw_status;
    $char deffect4[11], dply_begin[11];
    char  ChkPlyType[3];  /* N1:���O������ N2:���D�� Y1:�¬y�{���`�� Y2:�S���� Y3:�s�y�{���`�� Y4:�t�B�e�\�� */
	$char  sPassPrint[2];	/* �i�_�C�L */
	$long mprem,mnt1;
	$int  iCntSP1, iCntSP2, iCntSP3, iCntSP4, iCntSP5;
	$char fVersion[2],ftype_pol[3],sMsg[513];
		
    cm_buf_get("%s %s %s", DBName, sIpolicy ,fVersion);
    strcpy(sIpolicy, trim(sIpolicy));

	$WHENEVER SQLERROR GOTO errexit;
	if (db_select(DBName) == False)
	{
	 	if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
	   		return M_CM_DB_NOTOPEN;
	 	else
	   		return apiRC;
	}
			
	/* 1031111001_C1_���O�X������{���վ� */
	/* ���s��z�i�_�L���޿謰�G		
		1.�w���O�̡A�@�ߥi�L��C
		2.�����O�̡A�̦@�γ������ɡu�O�����O�v�P�_�O�_�i�L��G
		?��Y�u�O�����O�v= NA �BSP �̡A�i�L��
		3.���O�������G
		     ?��j�v�O�N��G���q�B���׮t�B10���H���i�L��A��l�t�B100���H��
		        �i�L��F�@��󤣥i�L��
		4.�L��ɡA���A���s�P�_�B���ʡu�O�����O�v�A�H�X��(���O�渹)���ɧP�_�����G
		  ���ǡC
	*/
    if (fVersion[0]=='1'){ 

        /* 1041013003_C1_car320.car301.car401��������(F)��J�ި� */ 
        printf("-- check_ca_id_officer()\n ");
        strcpy(sPassPrint," ");
    	rc = check_ca_id_officer(sIpolicy," ",sPassPrint,sMsg);
	    if( rc != M_CM_OK)
	    {
	        if(exitsub(reply, rc) == True)
	           return  rc;
	        else
	           return apiRC;
	    }	    
	    if (sPassPrint[0]=='Y'){
	    	strcpy(ChkPlyType,"YF");
	    }else{	    	
 	        strcpy(ChkPlyType,"NF");
 	    }

	    printf("-- trace sPassPrint[%s]\n ",sPassPrint);                            	    	    	    	    	
	    printf("-- trace ChkPlyType[%s]\n ",ChkPlyType);
 	        
 	            	
    	printf("-- chk_policy_print()\n ");
    	rc = chk_policy_print(sIpolicy,sPassPrint,ChkPlyType,sMsg);
	    if( rc != M_CM_OK)
	    {
	        if(exitsub(reply, rc) == True)
	           return  rc;
	        else
	           return apiRC;
	    }
	    printf("-- trace sPassPrint[%s]\n ",sPassPrint);                            	    	    	    	    	
	    printf("-- trace ChkPlyType[%s]\n ",ChkPlyType);
        
    }else{

		strcpy(ChkPlyType, " ");
		strcpy(sPassPrint,"N");	/* �w�]����C�L */    
		iCntSP1 = iCntSP2 = iCntSP3 = iCntSP4 = iCntSP5 = 0;
	     
	     $select a.itmp_policy, b.iabn_type, a.icomm_obj, c.imgr,
	            case when b.iroute[1,2] = 'JC' then
	                 (select count(detail) from car_code where kind = '26'
	                     and detail = b.iassured) else 0 end , 
	            a.ipolicy[1,13],
	            case when a.ipolicy[6,7] = 'VW' then 1 else 0 end,
	            case when length(trim(a.ipolicy)) > 13 then
	                 a.ipolicy[14,17] else ' ' end,
	            case when trim(b.iabn_type) <> '' then
	                 nvl((select fuw_status from newa00:abnormal_ply where iabnormal = a.itmp_policy),-100)
	                 else nvl((select fuw_status from estimate where iestimate = a.itmp_policy),-100) end,
	            (select count(icode) from ca_permit where iclass = '01' 
	               and (dexpire is null or dexpire > today) and trim(icode) <> '' and icode = b.iassured),
	            (select count(icode) from ca_permit where iclass = '02' 
	               and (dexpire is null or dexpire > today) and trim(icode) <> '' and icode = b.itag),
	            (select count(icode) from ca_permit where iclass = '03' 
	               and (dexpire is null or dexpire > today) and trim(icode) <> '' and icode = b.iengine),
	            (select count(icode) from ca_permit where iclass = '04' 
	               and (dexpire is null or dexpire > today) and trim(icode) <> '' and icode = b.iroute[1,2]),
	            (select count(icode) from ca_permit where iclass = '05' 
	               and (dexpire is null or dexpire > today) and trim(icode) <> '' and icode = 
	                   (select iroute_main from cm_route where iroute = b.iroute)),
	            (mdmg_prem + mlia_prem), dply_begin
	       into $sIestimate, $sAbn_type, $sIcomm_obj, $sImgr, $iCountJC, 
	            $sIpolicy1, $iCountEW, $sIpolicy2, $ifuw_status, 
	            $iCntSP1, $iCntSP2, $iCntSP3, $iCntSP4, $iCntSP5,
	            $mprem, $dply_begin
	       from ply_relation a, policy b, officer c
	      where a.ipolicy = b.ipolicy and a.iofficer = c.iofficer
	        and a.fcard_class = '2' and a.dpolicy is null
	        and a.ipolicy = $sIpolicy;
	
			printf("iCountJC=[%d]iCountEW=[%d]\n",iCountJC,iCountEW);
	   	printf("iCntSP1=[%d]iCntSP2=[%d]iCntSP3=[%d]iCntSP4=[%d]iCntSP1=[%d]\n",
	   		        iCntSP1,iCntSP2,iCntSP3,iCntSP4,iCntSP5);
	
	        
	    if ((ifuw_status == -1) || (ifuw_status >= 600))
	    {
	   		/* �¬y�{�S����,�i�H���`�C�L�O�� & �鵲 */
	   		strcpy(sPassPrint,"Y");
	   		strcpy(ChkPlyType, "Y1");
	    }
	    else if ((iCountJC > 0) || (iCountEW > 0) || ((iCntSP1+iCntSP2+iCntSP3+iCntSP4+iCntSP5) > 0))
	    {
	   		/* �F���ۼХ�(JC)�B�ĳq�ץ�(SP)�ΫO�T�I(EW),�i�H���`�C�L�O�� & �鵲 */
	   		strcpy(sPassPrint,"Y");
	   		strcpy(ChkPlyType, "Y2");
	    }
	    else if ((ifuw_status == -100 ) || ((ifuw_status >=500) && (ifuw_status < 600)))
	    {
	   		/* ���I�պ��ɬd�L���(ifuw_status=-100),
	   		   �i��O��O��αM�ץ�; 500/510 ���`���O�X��y�{ */
	   		$select fuw_status,  iestimate 
	   		        into $ifuw_status, $sIestimate
	   		   from estimate where ipolicy2 = $sIpolicy and dentry >= add_months(today,-6);
	
	   		if (SQLCODE == SQLNOTFOUND) ifuw_status = 500; /* �������ɧ䤣��, ���ӬO��O���(B2B�B�@���barcode) */
	   			
	   		if (ifuw_status == -1)
	   		{ 
	   			/*�¬y�{,�i���`�X��鵲 */ 
	   			strcpy(sPassPrint,"Y");	
	   			strcpy(ChkPlyType, "Y1");
	   		}
	   		else
	   		{
	   			/* ��@�γ������ɸ�� */
	   			$select unique ipre_rcv, iins_kind into $ipre_rcv, $iins_kind
	   			   from cm_pre_receive
	   			  where ipolicy1 = $sIpolicy1 and ipolicy2 = $sIpolicy2;
	   			if (SQLCODE == SQLNOTFOUND)
	   			{
	   				/* ���b���I��������, ���b�@�γ�������...���D�j�F.......*/
	   				strcpy(sPassPrint,"N");	
	   				strcpy(ChkPlyType, "N2");
	   			}
	   			else
	   			{
	   				strcpy(deffect4,cm_check_workday( dply_begin, deffect4));
	   				/* ú�Ǫ��`�O�O */
	   				$select nvl(sum(b.mnt),0) into $mnt1
	   				   from cm_pre_receive a, ao_prercv_pass b
	   				  where a.iins_cat = b.iins_cat
	   				    and a.ipre_rcv = b.ipre_rcv
	   				    and a.iins_kind = b.iins_kind
	   				    and a.ipre_end = b.ipre_end
	   				    and a.iins_cat = 'C'
	   				    and a.fstatus != 90
	   				    and a.ipre_rcv = $ipre_rcv
	   				    and a.iins_kind = $iins_kind
	   				    and ((a.ftype_pol = '1M' and b.dcoll_last <= (a.deffect + 30))
	   				         or (a.ftype_pol = ' ' and b.dcoll_last <= $deffect4))
	   				    and b.dacc_last is not null;
	
						if(mnt1 >= mprem)
						{
								strcpy(sPassPrint,"Y");	/* �O�O����,�i���`�L��鵲 */
								strcpy(ChkPlyType, "Y3");
						}
						else
						{
							if (strcmp(sImgr,"1") == 0)
							{
								/* �j�v����*/
								if ((sIcomm_obj[0]=='B') || (sIcomm_obj[0]=='J'))
								{
									if ((mprem - mnt1) <= 10)
									{
											strcpy(sPassPrint,"Y");	/* 10���e�\�d��,�i���`�L��鵲 */
											strcpy(ChkPlyType, "Y4");
									}
									else
									{
											strcpy(sPassPrint,"N");	/* ���O������,�L�k�L��鵲 */
											strcpy(ChkPlyType, "N1");
									}
								}
								else
								{
									if ((mprem - mnt1) <= 100)
									{
											strcpy(sPassPrint,"Y");	/* 100���e�\�d��,�i���`�L��鵲 */
											strcpy(ChkPlyType, "Y4");
									}
									else
									{
											strcpy(sPassPrint,"N");	/* ���O������,�L�k�L��鵲 */
											strcpy(ChkPlyType, "N1");
									}
								}
							}
							else
							{
								strcpy(sPassPrint,"N");	/* ���O������,�L�k�L��鵲 */
								strcpy(ChkPlyType, "N1");
							}
						}
	   			}
	   		}
	   }
	   else
	   {
	   		/* ���D��, �L�k�k��........ */
	   		strcpy(sPassPrint,"N");	
				strcpy(ChkPlyType, "N2");
	   }

    }
    if (sPassPrint[0]=='Y')
    {
        $SELECT CASE WHEN fsign_status < 30 THEN 'N' ELSE 'Y' END , 
                CASE WHEN fsign_status < 30 THEN '���i�L��A�]���`�����q�|���f�֩��' ELSE '' END
           INTO $sPassPrint , $sMsg
           FROM ply_relation
          WHERE ipolicy = $sIpolicy;
    }

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s ", M_CM_OK, sPassPrint, ChkPlyType, sMsg);

	tmp_len = cm_buf_len(ReplyBuf);
	
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
	   return apiRC;
	else
	   return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/* --------------------------------------------------------------------------- */
/* �ˮ֫H�Υdñ�ָ�� add by sylvia 102.03.22 */
long chk_credit_dsign(reply)
{
		int    rc, tmp_len;
		$char  DBName[5];
    $char icreditno[17], deffect[5], iauthno[9], dsign[11], sMcredit[10],
          iestimate[21], trcv[20], ReCredit[2];
		$double mcredit;
		$int Count1, Count2;

    printf(" --------- chk_credit_dsign start -------------------- \n");
    cm_buf_get("%s %s %s %s %s %s",
               DBName, icreditno, deffect, sMcredit, iauthno, iestimate);
    
    $WHENEVER SQLERROR GOTO errexit;
		if (db_select(DBName) == False)
		{
		 	if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
		   		return M_CM_DB_NOTOPEN;
		 	else
		   		return apiRC;
		}
    
    strcpy(icreditno, trim(icreditno));	/* �d�� */
    strcpy(deffect, trim(deffect));				/* ���Ħ~�� */
    strcpy(iauthno, trim(iauthno));				/* ���v�X */
    dsign[0] = '\0';											/* ���v�� */
    mcredit = atof(sMcredit);							/* ���v���B */
    strcpy(iestimate, trim(iestimate));		/* �����渹 */
    
    /* ���ˮ֬O�_�P�w������Ш�d -------------------------------------- */
    Count1 = 0;
    $declare chk_cur1 cursor for
    	select trcv
        from ao_rcv_type
       where ipre_rcv = $iestimate;
    $open chk_cur1;
    for(;;)
  	{
    	$fetch chk_cur1 into $trcv;
    	if (SQLCODE != 0) break;
    	
    	Count2 = 0;
    	$select count(*) into $Count2
    	   from ao_credit_auth
    	  where trcv = $trcv;

			Count1 = Count1+Count2;
    }
		if (Count1 > 0)	
				strcpy(ReCredit,"Y");	/* �����ƨ�d */
		else
				strcpy(ReCredit,"N");	/* �L���ƨ�d */
		/* ------------------------------------------------------------------ */
		
    $select dsign into $dsign
       from ao_credit_auth
      where iauthno = $iauthno
        and icreditno = $icreditno
        and deffect = $deffect
        and mcredit = $mcredit;

    if(SQLCODE == SQLNOTFOUND)
				strcpy(dsign, "0");

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s", M_CM_OK, dsign, ReCredit);

    tmp_len = cm_buf_len(ReplyBuf);
		
		if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		   return apiRC;
		else
		   return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/* --------------------------------------------------------------------------- */
/*1031111001_C1_���O�X������{���վ�*/
/* ���o�j�v�O�N�W�� */
long get_ibigcmp_list( reply )
serverReply reply;
{
int     tmp_len;
$char   DBName[5], stmt[1024], icode[11], ncode[41],tcode_remark[21];
long    rc, iCount;

$char iins_type[INSURANCE_TYPE], nins_type[51];

    $WHENEVER SQLERROR GOTO errexit;

    cm_buf_get("%s ", DBName);
    cm_buf_get("%s ", icode);

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }
    
    
    if (strlen(trim(icode))> 0 ){
    	sprintf_s( stmt,sizeof stmt, "SELECT icode, ncode,tcode_remark[2] FROM cu_code_data WHERE itype = 'CO' and icode ='%s'" ,trim(icode));
    	
    }else{
    	sprintf_s( stmt,sizeof stmt, "SELECT icode, ncode,tcode_remark[2] FROM cu_code_data WHERE itype = 'CO' ");
    }

    printf("stmt[%s]\n", stmt);
    cm_buf_init(ReplyBuf);
    cm_buf_res_msg();
    cm_buf_res_count();

    $PREPARE prep3 FROM $stmt;
    $DECLARE curs3 CURSOR FOR prep3;
    iCount = 0;
    $OPEN curs3;
    for(;;)
    {
        $FETCH curs3 INTO $icode, $ncode,$tcode_remark;
        if( SQLCODE == SQLNOTFOUND)
            break;
        strcpy(icode, rtrim(icode));
        strcpy(ncode, rtrim(ncode));
        strcpy(tcode_remark, rtrim(tcode_remark));
        cm_buf_put("%s %s %s ", icode, ncode,tcode_remark);
        iCount++;
    }
    $FREE prep3;
    $CLOSE curs3;
    $FREE curs3;
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(iCount);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/* ------------------------------------------------------------------------ */
/* �̳q�����u���q���N�� add by sylvia */
long get_sales_route(reply)
serverReply reply;
{
  int    rc, tmp_len;
  long 	RTN;
  $char  DBName[5];
  $char  Iroute[21], Isales[11], iroute_full[21], is_dexpire[2];
  $char  sTmp[1000];
         
	
 	cm_buf_get("%s %s %s", DBName, Iroute, Isales);
 	strcpy(Iroute, trim(Iroute));
 	strcpy(Isales, trim(Isales));
 	
 	$WHENEVER SQLERROR GOTO errexit;
 	if (db_select(DBName) == False)
 	{
   	if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     		return M_CM_DB_NOTOPEN;
   	else
     		return apiRC;
 	}

	sprintf_s(sTmp,sizeof sTmp, "select iroute_full from cm_route_sales  \
                     where isales = '%s'  \
                      and (dexpire is null or dexpire > today) \
                      and iroute matches '%s' ",Isales, Iroute);

	printf("sTmp=[%s]\n",sTmp);
 
	$PREPARE pre_getx1 FROM $sTmp;
  $DECLARE cur_getx1 CURSOR FOR pre_getx1;
  $OPEN    cur_getx1;
  $FETCH   cur_getx1 into $iroute_full;
  
  if(SQLCODE == SQLNOTFOUND)
  {
  			strcpy(iroute_full, " ");
  			strcpy(is_dexpire, "Y");	/* �w���� */
  }
  else
  		strcpy(is_dexpire, "N");	/* ������ */

	$CLOSE   cur_getx1 ;
	$FREE   cur_getx1 ;
	
 	cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s %s", M_CM_OK, iroute_full, is_dexpire);
  tmp_len = cm_buf_len(ReplyBuf);
		
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		   return apiRC;
	else
		   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/* ------------------------------------------------------------------------ */
/*1030725001_C1 �ߦw(118)�B����(120)����[�N�B���O�I*/
/* ���O87��1,2�~�ӫO��� add by sylvia 102.07.26 */
long chk_nequipment87(reply)
serverReply reply;
{
  int    rc, tmp_len, i;
  long 	 RTN;
  $char  DBName[5];
  $int  iyear;
  $char ipolicy[21], syear[2], ilast_ipolicy[5][21], nequipment[5][31];
  $char sFullName[31], sFullName2[31], sFullName3[31], stmt[3000], chk_qem87[2], 
        fcard_class[2], irelative_ply[21], ilst_ply[21], stmt2[1000];
  $int icount[5] = {0,0,0,0,0};
  

	
 	cm_buf_get("%s %s %s", DBName, syear, ipolicy);
 	iyear = atoi(syear);
 	strcpy(ipolicy, trim(ipolicy));
 	strcpy(chk_qem87, "Y");		/* �w�]�ŦX���O87���� */
 	
 	$WHENEVER SQLERROR GOTO errexit;
 	if (db_select(DBName) == False)
 	{
   	if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     		return M_CM_DB_NOTOPEN;
   	else
     		return apiRC;
 	}

	for (i=0; i<5; i++)
	{
		icount[i] = 0;
		strcpy(nequipment[i], " ");
	}

	
	/* iyear:���~�O�M�ת���N�~ ipolicy:�e�@�~���O�渹 
	   ��:iyear = 2 -- ���ܤ��~�O��2�~ , ipolicy �O��1�~���O�渹 	*/
	printf("------ 3992  iyear=[%d]------- \n",iyear);
	for (i=iyear; i > 1 ; i--)
	{
			printf("���[%d]�~���\n",i);
			strcpy(sFullName, get_car_full_db( ipolicy));		/*  �O���Ʈw */
			
			/* ��e�O������p�O�檺��Ʈw,�Y�L���,�H�O���Ʈw���N */
			sprintf_s(stmt2,sizeof stmt2,"select ilast_ply, irelative_ply from %s:ply_relation \
			                 where ipolicy = '%s'",sFullName,ipolicy);
			$PREPARE pre_ya FROM $stmt2;
		  $DECLARE cur_ya CURSOR FOR pre_ya;
		  $OPEN    cur_ya;
		  $FETCH   cur_ya into $ilst_ply, $irelative_ply;
		  $close cur_ya;
		  $free cur_ya;
		  
		  strcpy(ilst_ply, trim(ilst_ply));
		  strcpy(irelative_ply, trim(irelative_ply));
		  
		  if (strlen(ilst_ply) > 0)
		  		strcpy(sFullName2, get_car_full_db( ilst_ply));	/* ��O���Ʈw */
		  else
		  		strcpy(sFullName2, get_car_full_db( ipolicy));
		  		
		  if (strlen(irelative_ply) > 0)
		  		strcpy(sFullName3, get_car_full_db( irelative_ply)); /* ���p�O���Ʈw */
		  else
		  		strcpy(sFullName3, get_car_full_db( ipolicy));		
			/* --------------------------------------------------------------- */
			
			sprintf_s(stmt, sizeof stmt,
				"select a.ilast_ply, b.nequipment,  \
				        case when a.fcard_class = 2 then \
				        		(select count(ipolicy) from %s:ply_ins_type c \
				        		  where  c.ipolicy = a.ipolicy and iins_type in ('01','05','105','118','122','201','205')) \
				        else \
				        		case when length(trim(irelative_ply)) = 0 then 0  \
				        		else \
				        			(select count(ipolicy) from %s:ply_ins_type d \
				        		  where d.ipolicy = a.irelative_ply and iins_type in ('01','05','105','118','122','201','205')) end \
				        end \
		       from %s:ply_relation a, %s:policy b \
			    where a.ipolicy = b.ipolicy \
			      and a.ipolicy = '%s' ", 
			       sFullName, sFullName3, sFullName, sFullName, ipolicy); 
			printf("sTmp=[%s]\n",stmt);
		 
			$PREPARE pre_y1 FROM $stmt;
		  $DECLARE cur_y1 CURSOR FOR pre_y1;
		  $OPEN    cur_y1;
		  $FETCH   cur_y1 into $ilast_ipolicy[i-1],$nequipment[i-1], 
		                       $icount[i-1];
  
  		if (equip_cmp(nequipment[i-1],"87") != TRUE)
  		{ 
  				/* ��O�~��(�e�@�~��)�����O87, ���~�פ��o�[��87 */
  				strcpy(chk_qem87, "N");		/* �w�]���ŵ��O87���� */
  				break;
  		}
		  strcpy(ipolicy, ilast_ipolicy[i-1]);
  		$CLOSE   cur_y1 ;
			$FREE   cur_y1 ;
	}
		
	if ((iyear > 2) &&  (iyear != 3))
	{
		 if ((icount[2] == 0) || (icount[1] == 0))
		 {
		 		/* ��1,2�~���ӫO01,05�I�� */
		 		strcpy(chk_qem87, "N");		/* ���ŵ��O87���� */
		 }
	}
	else
	{
			if (icount[1] == 0)
					strcpy(chk_qem87, "N");		/* ���ŵ��O87���� */
	}
	
 	cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s", M_CM_OK, chk_qem87);
  tmp_len = cm_buf_len(ReplyBuf);
		
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		   return apiRC;
	else
		   return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* ------------------------------------------------------------------------- */
/* �ˮ֫O�����O: A:�M��A��; B:�M��B��; C:��L */
long get_all_project(reply)
serverReply reply;
{
  int    rc, tmp_len;
  $char  DBName[5];
  $char  sIproject[500], sDetail[7];
  $char  sMsg[512];

	cm_buf_get("%s ", DBName);

	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False)
	{
		if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}

	memset(sIproject,0x00,sizeof(sIproject));
	strcpy(sIproject,";");
	
	$DECLARE proj1 CURSOR FOR
			SELECT trim(detail)||';'
				FROM car_code 
			 WHERE kind = '33';
	$open  proj1;
	for(;;)
	{
		$FETCH proj1 INTO $sDetail;
		
		printf("sDetail=[%s]\n",sDetail);
		if(SQLCODE == SQLNOTFOUND) break;
		
		strcpy(sDetail, trim(sDetail));
		strcat(sIproject,sDetail); 
	}
	$close proj1;
	$free proj1;
  cm_buf_init(ReplyBuf);

	printf("sIproject=[%s]\n",sIproject);
	cm_buf_put("%l %s ", M_CM_OK, sIproject);

	tmp_len = cm_buf_len(ReplyBuf);

	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
			return apiRC;
	else
			return api_OKComplete;

	errexit:
  		return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/* ------------------------------------------------------------------------- */
/*1100909003_SC2 �_�@�Ϯ��S�h���p�{��(����07.15)�}���O181�I�ݨD 
  �s�W�T�ӡG�ѵs�D�I�B������[�I�B�ѵs���[�I */
/* �����d�B����B���l�I�I�إN��(�A�O�ˮ֨ϥ�) */
long get_ins_grp_dtl(reply)
serverReply reply;
{
  int    rc, tmp_len;
  $char  DBName[5];
  $char  sDmga[500],sDmgb[500],sLia[500],sRinc[500];
  $char  sMsg[512], sTmpIns[7];
  $char  fins_grp[2],iri_ins[7],imain_ins[7],sDmgc[500];
  $char  sDmgb_1[500],sDmgd[500],sDmgd_1[500],sLia31_1[500];
	cm_buf_get("%s ", DBName);

	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False)
	{
		if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}

	memset(sTmpIns  ,0x00 ,sizeof(sTmpIns));
	memset(fins_grp ,0x00 ,sizeof(fins_grp));
	memset(iri_ins  ,0x00 ,sizeof(iri_ins));
	memset(imain_ins,0x00 ,sizeof(imain_ins));
	strcpy(sDmga,";");	/* ���l�I */
	strcpy(sDmgb,";");	/* ����D�I */
	strcpy(sDmgc,";");	/* ���l�D�I */
	strcpy(sLia,";");	  /* ���d�I */
	strcpy(sRinc,";");	/* ���{�����I�� */

	strcpy(sDmgb_1,";");/* ������[�I */ 
 	strcpy(sDmgd,";");	/* �ѵs�D�I */
 	strcpy(sDmgd_1,";");/* �ѵs���[�I */

  strcpy(sLia31_1,";"); /* �ĤT�H�d���I���[�I */ 
    
    
	/* ���l�I -- �ư�38,39 */
    /* 1100507006-SC1-���ά�-�бN238�I�ư����l�����I�P�_ */
	$DECLARE GetIns CURSOR FOR
		select iins_type,fins_grp, iri_ins,imain_ins
			from insurance_type
		 where iins_type = iins_ply;
	$open  GetIns;
	for(;;)
	{
		$FETCH GetIns INTO $sTmpIns, $fins_grp, $iri_ins, $imain_ins;				
		if(SQLCODE == SQLNOTFOUND) break;
			
		printf("sTmpIns=[%s]\n",sTmpIns);		
		strcpy(sTmpIns  ,trim(sTmpIns));	
		strcpy(fins_grp ,trim(fins_grp));	
		strcpy(iri_ins  ,trim(iri_ins));	
		strcpy(imain_ins,trim(imain_ins));	
		
		if (fins_grp[0]=='1')
		{
		   if (strcmp(sTmpIns,"38")==0)	continue;
		   if (strcmp(sTmpIns,"39")==0)	continue;
       if (strcmp(sTmpIns,"238")==0)	continue;
		   	
		   strcat(sDmga,sTmpIns); 	 
		   strcat(sDmga,";");                 /* ���l�I -- �ư�38,39 */
		   
		   if (strcmp(sTmpIns,imain_ins)==0)
		   {
		       strcat(sDmgc,sTmpIns); 	
		   	   strcat(sDmgc,";");             /* ���l�D�I */
		   	   
		   	   if (strcmp(iri_ins,"11")!=0)
		   	   {
               strcat(sDmgb,sTmpIns); 	
		   	       strcat(sDmgb,";");         /* ����D�I */		   	   	
		   	   }else{
               strcat(sDmgd,sTmpIns); 	
		   	       strcat(sDmgd,";");         /* �ѵs�D�I */
           }

		   }else{  /* ���l���[�I  */
		   	   if (strcmp(iri_ins,"11")!=0)
		   	   {
               strcat(sDmgb_1,sTmpIns); 	
		   	       strcat(sDmgb_1,";");         /* ������[�I */		   	   	
		   	   }else{
               strcat(sDmgd_1,sTmpIns); 	
		   	       strcat(sDmgd_1,";");         /* �ѵs���[�I */
           }
       }

	  }
		else	
		{
		   strcat(sLia,sTmpIns);  
		   strcat(sLia,";"); 			      /* ���d�I  */
		   
		   if (strcmp(sTmpIns,"24")==0)	continue;
		   if (strcmp(sTmpIns,"88")==0)	continue;
		   	
		   strcat(sRinc,sTmpIns); 	 
		   strcat(sRinc,";");                 /* �{���I�� -- �ư�24,88  */

       if (strcmp(sTmpIns,imain_ins)!=0)  /* ���d���[�I */
		   {
            if((strcmp(imain_ins,"31")==0)||(strcmp(imain_ins,"113")==0)) 
            {
               strcat(sLia31_1,sTmpIns); 	
		   	       strcat(sLia31_1,";");        /* �ĤT�H�d���I���[�I */
            }
           
       } 
		}		
	}
	$close GetIns;
	$free GetIns;
	
	
    cm_buf_init(ReplyBuf);

	printf("sDmga=[%s]\n",sDmga);
	printf("sDmgb=[%s]\n",sDmgb);
	printf("sDmgc=[%s]\n",sDmgc);
	printf("sLia=[%s]\n",sLia);
	printf("sRinc=[%s]\n",sRinc);
	cm_buf_put("%l %s %s %s %s %s %s %s %s %s", M_CM_OK, sDmga,sDmgb,sLia,sRinc,sDmgc,sDmgd,sDmgb_1,sDmgd_1,sLia31_1);

	tmp_len = cm_buf_len(ReplyBuf);

	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
			return apiRC;
	else
			return api_OKComplete;

	errexit:
  		return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* �ˮ֭Ӹ�O�_�w���� add by sylvia 103.02.13 (1020924002_C2) */

long check_personal_deny(reply)
serverReply reply;
{
  int    tmp_len;
  $char  DBName[5];
  $char  iassured[12];
  $char  sMsg[512]=" ",o_sFply_chk[2]=" ";
  long   rc;

 cm_buf_get("%s %s", DBName, iassured);

 $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
	  if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
		 return M_CM_DB_NOTOPEN;
	  else
		 return apiRC;
  }
	
  rc = cm_chk_personal(iassured, "C" , "*" , sMsg, o_sFply_chk);
  if (rc != M_CM_OK)
  {
      if(exitsub(reply, rc) == True)
          return  rc;
      else
          return apiRC;  	
  }
  else
  {
      if (o_sFply_chk[0]=='N') /* ���i�X�� ; PS:����u��P�v���i�X�� (o_sFply_chk[0] => 'Y') */
      {
	      if(exitsub(reply, M_CA_PERSONAL_DENY) == True)
	          return  M_CA_PERSONAL_DENY;
	      else
	          return apiRC;          
      }
  }
  
  strcpy(sMsg , trim(sMsg));
  if (strlen(sMsg)==0) strcpy(sMsg," ");

  cm_buf_init(ReplyBuf);

  cm_buf_put("%l %s", rc, sMsg);  

  tmp_len = cm_buf_len(ReplyBuf);

   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
   else
       return api_OKComplete;


errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* 1030728 �ѵs�I���� 1030724002 _C1 */ 	
long check_ply_renew11(reply)
serverReply reply;
{
   int   rc, tmp_len;
   $char DBName[5];
   $char iLastply[21],s_ilicense[11],s_iengine[CA_ENGINE_NUM],s_dply_begin[11],sIins_type[INSURANCE_TYPE];
   $char s_fcard_class[2],s_irelative_ply[21],s_nequipment[31],sFullName[31]; 
   $char sMsg[512];
   
   $char stmt[1024]; 
   long  count = 0;
   $long ori_dam_cover, ori_deduct;
  
   cm_buf_get("%s %s", DBName, iLastply);
   
   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False) 
   {
	   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
		   return M_CM_DB_NOTOPEN;
	   else
	       return apiRC;
   }
			   
   strcpy(s_ilicense, " ");  strcpy(s_iengine, " "); strcpy(s_dply_begin, " ");
   
   strcpy(iLastply,trim(iLastply));
    
   	
   $Select ilicense,iengine,dply_begin,fcard_class,irelative_ply,nequipment
      into $s_ilicense,$s_iengine,$s_dply_begin,$s_fcard_class,$s_irelative_ply,$s_nequipment
      from policy_302 
     where ipolicy = $iLastply 
       and fcard_class='2'; /* <= ���w���������N�I�O�渹 */
   if(SQLCODE==SQLNOTFOUND)
   {
       if(exitsub(reply,M_CM_NOT_FOUND) == True)      
          return M_CM_NOT_FOUND;                        
       else
          return apiRC;
   }
   /* �p�T�����ݭn�۰ʰ��o�Ӱʧ@�A�p�Guser�αj���I�O�渹�a�A�h�ݧאּ���N�I�O�渹
   if (s_fcard_class[0]=='1'){
   	  if (strlen(trim(s_irelative_ply)) > 0){
	  	 $Select ilicense,iengine,dply_begin,fcard_class,ipolicy 
	  	    into $s_ilicense,$s_iengine,$s_dply_begin,$s_fcard_class,$iLastply
	  	    from policy_302 
	  	   where ipolicy = $s_irelative_ply ; 
	  	 if(SQLCODE==SQLNOTFOUND)
	  	 {
	  	     if(exitsub(reply,M_CM_NOT_FOUND) == True)      
	  	        return M_CM_NOT_FOUND;                        
	  	    else
	  	        return apiRC;
	  	 }		    
   	  }
   }
   */  
   cm_buf_init(ReplyBuf);
   cm_buf_res_msg(); 
   cm_buf_res_count(); /* for �I�ة��ӵ��� */
   
   cm_buf_put("%s %s %s %s ",  s_ilicense, s_iengine, s_dply_begin, s_nequipment);
   
   /*================  �I�ة���     =================*/
   if (s_nequipment[4]=='1'){ 
			strcpy(sFullName, get_car_full_db( iLastply));	
			sprintf_s(stmt,  sizeof stmt,
	         "SELECT iins_type, mdeduct,mdamage_cover \
	            FROM %s:ply_ins_type \
	           WHERE mdamage_cover > 0 and ipolicy ='%s' \
	             AND iins_type in ('11','12','13','16','17','18','19','20','22','28','76','96','97','111','112','211') \
	          Order By qserial "
	         , sFullName,iLastply);
   }else{	
	   sprintf_s(stmt,sizeof stmt,
	         "SELECT iins_type, ori_deduct,ori_dam_cover \
	            FROM ply_ins_type_302 \
	           WHERE ori_dam_cover > 0 and ipolicy ='%s' \
	             AND iins_type in ('11','12','13','16','17','18','19','20','22','28','76','96','97','111','112','211') \
	          Order By qserial "
	         , iLastply);    	
   }
    printf("stmt[%s]\n", stmt);
    
    $PREPARE pre_ins_302 FROM $stmt;
    $DECLARE cur_ins_302 CURSOR FOR pre_ins_302;
    $OPEN cur_ins_302;
    
    count = 0; ori_deduct = 0; ori_dam_cover = 0;
    strcpy(sIins_type, " ");
    while(1){    	
	     $FETCH cur_ins_302 INTO $sIins_type, $ori_deduct, $ori_dam_cover ;
 	     if(SQLCODE==SQLNOTFOUND) break;
 	     	
         printf("sIins_type[%s]\n",sIins_type);
         printf("ori_deduct[%ld]\n",ori_deduct);
         printf("ori_dam_cover[%ld]\n",ori_dam_cover);
	     count ++;
 	     cm_buf_put("%s %l %l",sIins_type, ori_deduct, ori_dam_cover);
    }
    printf("count[ply_ins_type_302]=%d\n",count);
    
    $CLOSE cur_ins_302;
    $FREE cur_ins_302; 
    
    cm_buf_put_msg(M_CM_OK);    
    cm_buf_put_count(count); /* for �I�ة��ӵ��� */
    
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

 /* 1030728 �ѵs�I���� 1030724002 _C1 */ 	
 /*  ���oSERVER�ݨt�Τ��(�ɶ�)[mm/dd/yyyy HH:MM:SS] */
long get_sys_date(reply)
serverReply reply;
{
   $char   DBName[5],opt[2];
   $char   dsysdate[20];
   int     tmp_len;

   cm_buf_get("%s %s",DBName,opt);

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
   {
      if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
         return M_CM_DB_NOTOPEN;
      else
         return apiRC;
   }
   strcpy(dsysdate , " ");
   if (opt[0]=='2') {
   	   $SELECT first 1 to_char(current,'%m/%d/%Y %H:%M:%S') INTO $dsysdate FROM systables ;  /* ���+�ɶ� */
   }else{
       $SELECT first 1 to_char(today,'%m/%d/%Y')            INTO $dsysdate FROM systables ;  /* ��� */
   } 	
   if(SQLCODE==SQLNOTFOUND)
   {
       if(exitsub(reply,M_CM_NOT_FOUND) == True)      
          return M_CM_NOT_FOUND;                      
       else
          return apiRC;
   }

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l %s",M_CM_OK,dsysdate);

   tmp_len = cm_buf_len(ReplyBuf);
   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
   else
       return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/* -------------------------------------------------------------------------- */
long get_officer_A(reply)
serverReply reply;
{
    $char DBName[5];
    $char sIofficer[11], sChiname[11];
    $int  iCount;
    int tmp_len;
    cm_buf_get("%s",DBName);

    $WHENEVER SQLERROR GOTO errexit;
    
		if (db_select(DBName) == False)
   		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $SELECT count(unique iofficer[1,3])	INTO $iCount
       FROM officer
      WHERE iofficer[1,1] = 'A'
        AND iofficer[1,2] <> 'A5'
        AND iofficer[1,3] not in ('A00','A20','A27') 
        AND dexpire is null; 

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    cm_buf_put("%d",iCount);
    
    $DECLARE cusor_a CURSOR FOR
     SELECT unique iofficer[1,3], iofficer[1,3]||' '||nname[1,4]
       INTO $sIofficer, $sChiname
       FROM officer
      WHERE iofficer[1,1] = 'A'
        AND iofficer[1,2] <> 'A5'
        AND iofficer[1,3] not in ('A00','A20','A27')
        AND dexpire is null;

    $OPEN cusor_a;
    for(;;)
    {
        $FETCH cusor_a;
        if(SQLCODE==SQLNOTFOUND) break;
        cm_buf_put("%s",sIofficer);
        cm_buf_put("%s",sChiname);
        
    }
    $CLOSE cusor_a;
    $FREE cusor_a;
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;
   
errexit:
    if(exitsub(reply,SQLCODE) == True) 
        return SQLCODE;
    else  
        return apiRC;
}

/*103.10.15 (1030630002_C2_���M�ץ�@�~�Ҧ��վ� ) �M�ץ�N�g�쬰"���ӥ�" �B�Ѩt�Φ۰ʨ��d��*/
/* ���F���M�פ�"�^�k�g��"�P��J��"A�����p�d��"�O�_�@�P, �G��"A�����p�d��"���o�X��ɤ��g��N�� */
long get_ply_info(reply)
serverReply reply;
{
$char DBName[5];
$char sFullName[31], stmt[1024], icard[21], fcard_class[2],ipolicy[21], s_iofficer[11];
$int  tmp_len;

    cm_buf_get("%s",DBName);
    cm_buf_get("%s ",icard);
    cm_buf_get("%s ",fcard_class);
    
    if (db_select(DBName) == False)
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $WHENEVER SQLERROR GOTO errexit;
    printf("icard=[%s]fcard_class=[%s]\n",icard,fcard_class); 
    
    if (fcard_class[0]=='1'){
	   $select ipolicy into $ipolicy
	      from compulsory_card
	     where icard = $icard;
   	
    }else if (fcard_class[0]=='2'){
       $select ipolicy into $ipolicy
          from card
         where icard = $icard;
    }

    if (strlen(trim(ipolicy))==0) {
   	   return exitsub(reply,M_CA_NOT_PLY) ? M_CA_NOT_PLY : apiRC;
    }	   	
   	
    printf("ipolicy=[%s]\n",ipolicy);
    strcpy(sFullName, get_car_full_db( ipolicy));

    sprintf_s(stmt,sizeof stmt, "SELECT nvl(iofficer,' ')"
                  "  FROM %s:ply_relation "
                  " WHERE ipolicy = '%s' ",sFullName, ipolicy);

    $PREPARE prepPly FROM $stmt;
    $EXECUTE prepPly INTO $s_iofficer;
    printf("s_iofficer=[%s]\n",s_iofficer);
    
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s",M_CM_OK, s_iofficer);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


long check_ply_renew12(reply)
serverReply reply;
{
   int   rc, tmp_len;
   $char DBName[5];
   $char iLastply[21],s_ilicense[11],s_iengine[CA_ENGINE_NUM],s_dply_begin[11],sIins_type[INSURANCE_TYPE];
   $char s_fcard_class[2],s_irelative_ply[21],sFullName[31]; 
   $char sMsg[512];
   
   $char stmt[1024]; 
   long  count = 0;
   $long ori_dam_cover, ori_deduct;
  
   cm_buf_get("%s %s", DBName, iLastply);
   
   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False) 
   {
	   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
		   return M_CM_DB_NOTOPEN;
	   else
	       return apiRC;
   }
			   
   strcpy(s_ilicense, " ");  strcpy(s_iengine, " "); strcpy(s_dply_begin, " "); strcpy(s_irelative_ply, " ");
   
   strcpy(iLastply,trim(iLastply));
    
   	
   $Select ilicense,iengine,dply_begin,fcard_class,irelative_ply
      into $s_ilicense,$s_iengine,$s_dply_begin,$s_fcard_class,$s_irelative_ply
      from policy_302 
     where ipolicy = $iLastply 
       and dply_begin between '01/01/2015' and '02/28/2015' ;
       
   if(SQLCODE==SQLNOTFOUND)
   {
       if(exitsub(reply,M_CM_NOT_FOUND) == True)      
          return M_CM_NOT_FOUND;                        
       else
          return apiRC;
   }
  
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l %s %s %s %s ",M_CM_OK, s_ilicense, s_iengine, s_dply_begin,s_fcard_class );
  
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* 1031111001_C1_���O�X������{���վ� * 	
long get_302_by_iestimate(reply)
serverReply reply;
{
   int   rc, tmp_len;
   $char DBName[5];
   $char iEstimateCR[21],ipolicy_302[21],isys[3],iins_kind[2];
  
   cm_buf_get("%s %s", DBName, iEstimateCR);
   
   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False) 
   {
	   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
		   return M_CM_DB_NOTOPEN;
	   else
	       return apiRC;
   }			      
   
   strcpy(ipolicy_302 , " " ); strcpy(isys , " " ); strcpy(iins_kind , " " );
   strcpy(iEstimateCR,trim(iEstimateCR));

    $DECLARE cusor_302 CURSOR FOR
      SELECT b.ipolicy,a.isys,a.iins_kind
        FROM cm_pre_receive a,policy_302 b
       WHERE a.ipre_rcv  = $iEstimateCR       
         AND a.ipre_rcv  = b.iestimate_ori  
         AND a.iins_kind = b.fcard_class
     UNION
     SELECT b.ipolicy,a.isys,a.iins_kind
        FROM cm_pre_receive a,policy_302 b
       WHERE a.ipre_rcv  = $iEstimateCR        
         AND a.ipre_rcv  = b.iestimate_sug          
         AND a.iins_kind = b.fcard_class            
     ORDER BY a.iins_kind desc;   * ���j��B���N�G��,*
    $OPEN cusor_302;
    for(;;)
    {
        $FETCH cusor_302 Into $ipolicy_302 , $isys , $iins_kind;
        if(SQLCODE==SQLNOTFOUND) break;
        cm_buf_put("%s",ipolicy_302);
        cm_buf_put("%s",isys);
        cm_buf_put("%s",iins_kind);
        
        break; * ���Ĥ@�� *
    }
    $CLOSE cusor_302;
    $FREE cusor_302;           	
       
   if(SQLCODE==SQLNOTFOUND)
   {
       if(exitsub(reply,M_CM_NOT_FOUND) == True)      
          return M_CM_NOT_FOUND;                        
       else
          return apiRC;
   }
  
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l %s %s %s %s ",M_CM_OK, ipolicy_302, isys, iins_kind);
  
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
} */

/* 1041221009_C1_���T���d�I�Y�Ƭd�߳W�h�վ� */ 	
long get_estimate_date(reply)
serverReply reply;
{
   int   rc, tmp_len;
   $char DBName[5],stmt[1024];
   $char iEst[21],s_destimate[11],s_dply_begin[11];
  
   cm_buf_get("%s %s ", DBName, iEst);
   
   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False) 
   {
	   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
		   return M_CM_DB_NOTOPEN;
	   else
	       return apiRC;
   }			      
   
   strcpy(iEst,trim(iEst));   
   printf("-- trace iEst[%s]\n ",iEst);
   if (strncmp(&iEst[5],"CR",2) == 0)
   {
	   sprintf_s(stmt,sizeof stmt,
       "SELECT first 1 dupdate::date,dply_begin FROM policy_302 WHERE iestimate_ori = '%s' or iestimate_sug = '%s' ", iEst ,iEst);
   }
   else if (strncmp(&iEst[5],"CX",2) == 0)
   {
	   sprintf_s(stmt,sizeof stmt,
       "SELECT dentry::date,dbegin FROM newa00:abnormal_ply WHERE iabnormal = '%s'" ,iEst);   	   
   }	
   else
   {
	   sprintf_s(stmt,sizeof stmt,
       "SELECT dentry::date,dply2_begin FROM estimate WHERE iestimate = '%s'" ,iEst);
   }
   strcpy(s_destimate  , " " ); 
   strcpy(s_dply_begin , " " );
   $PREPARE pre_est FROM $stmt;
   $EXECUTE pre_est INTO $s_destimate ,$s_dply_begin;   
   printf("-- trace s_destimate[%s]\n ",s_destimate);
   printf("-- trace s_dply_begin[%s]\n ",s_dply_begin);
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l %s %s",M_CM_OK, s_destimate, s_dply_begin);
  
   tmp_len = cm_buf_len(ReplyBuf);
   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
   else
       return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/*----------------------------------------------------------------------------*/
/* ���o��֤H���M�� (1040212015_C2) */
long get_first_underwriter(reply)
serverReply reply;
{
    $char DBName[5];
    $char nbranch[41], chiname[41], detail[21];
    char  tmpbuf[4000];
    int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
    int i,total_count=0;

    cm_buf_get("%s",DBName);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
          return M_CM_DB_NOTOPEN;
        else
          return apiRC;
    }

    $DECLARE q_cur9 CURSOR FOR
      SELECT c.nbranch, a.chiname, a.detail
        INTO $nbranch, $chiname, $detail
        FROM car_code a, officer b, sa_branch_type c
       WHERE a.detail = b.iofficer
         AND b.iquota = c.ibranch
         AND a.kind = '27'
         AND a.detail2 = $DBName
       ORDER BY b.iquota;
    $OPEN q_cur9;

    for(;;)
    {
        $FETCH q_cur9;
        if (SQLCODE != 0) break;

        cm_buf_init(tmpbuf);
        if ( count == 0 )
        {
           cm_buf_res_msg();        /* reserve for MsgCode and count */
           cm_buf_res_count();
        }
        cm_buf_put("%s %s %s ",nbranch, chiname, detail);
        tmp_len = cm_buf_len(tmpbuf);
        if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
        {
            memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
            repbuf_len += tmp_len;
            count++;
        }
        else  /* more than 4K, send to client side */
        {
           cm_buf_init(ReplyBuf);
           cm_buf_put_msg(M_CM_OK);
           cm_buf_put_count(count);
           if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
           {
               $CLOSE q_cur9;
               return apiRC;
           }
           else  /* clear ReplyBuf and count to start all over again */
           {
               replycnt++;
               if (replycnt == 10)/* more than 30K, client cannot display,error */
               {
                 cm_buf_init(ReplyBuf);
                 cm_buf_put("%l",M_CM_OUT_SPACE);
                 tmp_len = cm_buf_len(ReplyBuf);
                 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                   return apiRC;
                   
                 return M_CM_OUT_SPACE;
               }
               ReplyBuf[0] = '\0';
               count = 0;
               cm_buf_init(ReplyBuf);
               cm_buf_res_msg(); /* reserve for MsgCode and count */
               cm_buf_res_count();
               cm_buf_put("%s %s %s ",nbranch, chiname, detail);
               repbuf_len = cm_buf_len(ReplyBuf);
               count++;
          }
       }
    } /* for loop */

    $CLOSE q_cur9;
    if (count > 0)   /* break out, at least one record is selected */
    {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
        return apiRC;
      return api_OKComplete;
    }
    else            /* break out, not any row is found */
    {
       if(exitsub(reply,M_CA_NCODE) == True)
         return M_CA_NCODE;
       else
         return apiRC;
    }

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}
/* ���o�@�γ������ɸ�T */
long get_ipre_rcv_info(reply)
serverReply reply;
{
    $char DBName[5], iestimate[21], iins_kind[2];
    $char mprem[11],dentry[11],ftype_pol[3],ftype_sp[3],fstatus[3],icomm_obj[11],fcommit[2];
    $int  tmp_len;

    cm_buf_get("%s", DBName);
    cm_buf_get("%s ",iestimate);
    cm_buf_get("%s ",iins_kind);
    
    if (db_select(DBName) == False)
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $WHENEVER SQLERROR GOTO errexit;
    printf("get_ipre_rcv_info iestimate=[%s],iins_kind[%s]\n",iestimate,iins_kind); 
    
    $SELECT nvl(sum(mprem),0),max(dentry),max(ftype_pol),max(ftype_sp),
            max(fstatus),max(icomm_obj),max(fcommit)
       INTO $mprem ,$dentry, $ftype_pol ,$ftype_sp, $fstatus, $icomm_obj,$fcommit
	     FROM cm_pre_receive
	    WHERE iins_cat = 'C'
	      AND iins_kind matches $iins_kind
	      AND ipre_rcv = $iestimate 
	      AND ipre_end = ' ';
    
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s ",M_CM_OK, mprem ,dentry, ftype_pol);
    cm_buf_put("%s %s %s %s",ftype_sp ,fstatus ,icomm_obj,fcommit);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


long get_rel_card_pol_info(reply)
serverReply reply;
{
$char DBName[5], sFullName[31], stmt[1024];
$char fcard_ply[2],iRel_card_ply[21], iRel_card[21],iRel_ply[21],fRel_card_class[2],s_dply_begin[11],iRel_tag[CA_TAG_NUM],iRel_car_type[3];
$int  tmp_len,iCount1,iCount2;

    cm_buf_get("%s",DBName);
    cm_buf_get("%s",iRel_card_ply);

    if (db_select(DBName) == False)
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $WHENEVER SQLERROR GOTO errexit;
        
       
    /* �������j��d���� */
    /* �����]�O�����p�ҥd���d�� */
    strcpy(fcard_ply,"1");
    $select ipolicy into $iRel_ply from compulsory_card  where icard = $iRel_card_ply;
    if(SQLCODE==SQLNOTFOUND)
    {
       /* �A�ե��N�d�� */
        $select ipolicy into $iRel_ply from card where icard = $iRel_card_ply;
        if(SQLCODE==SQLNOTFOUND){
            strcpy(fcard_ply,"2");  /* �ҥd���L��ơA�אּ�����p�O�渹�d�� */
        }
    }   
    
    strcpy(iRel_card, " ");  strcpy(fRel_card_class, " ");  
    strcpy(iRel_tag , " ");  strcpy(s_dply_begin   , " "); strcpy(iRel_car_type   , " ");
    
    if (fcard_ply[0]=='1'){
        /* �����p�ҥd���d�� */
        strcpy(sFullName, get_car_full_db(iRel_ply));
        sprintf_s(stmt,sizeof stmt, "SELECT a.ipolicy,a.icard,a.fcard_class,nvl(a.dply_begin,' ') ,b.itag, a.icar_type "
                      "  FROM %s:ply_relation a,%s:policy b"
                      " WHERE a.ipolicy = b.ipolicy and a.icard = '%s' ",sFullName, sFullName, iRel_card_ply); 
    }else{
        /* �����p�O�渹�d�� */      
        strcpy(sFullName, get_car_full_db(iRel_card_ply));
        sprintf_s(stmt,sizeof stmt, "SELECT a.ipolicy,a.icard,a.fcard_class,nvl(a.dply_begin,' ') ,b.itag, a.icar_type "
                      "  FROM  %s:ply_relation a,%s:policy b"
                      " WHERE a.ipolicy = b.ipolicy and a.ipolicy = '%s' ",sFullName, sFullName, iRel_card_ply);                                     
    }
    
    $PREPARE prepRel FROM $stmt;
    $EXECUTE prepRel INTO $iRel_ply, $iRel_card, $fRel_card_class, $s_dply_begin, $iRel_tag, $iRel_car_type ;
       
    printf("iRel_card_ply=[%s]iRel_ply=[%s]fRel_card_class=[%s]\n",iRel_card_ply,iRel_ply,fRel_card_class);    
    printf("s_dply_begin=[%s]iRel_tag=[%s] iRel_car_type[%s]\n",s_dply_begin,iRel_tag,iRel_car_type);

    /* �YiRel_ply�ťաA���ܶǤJ��iRel_card_ply�i�঳�~ */
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s %s %s %s",M_CM_OK, fRel_card_class, iRel_card, iRel_ply, s_dply_begin, iRel_tag, iRel_car_type);
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;

}


/* �ˮ֬O�_���A�椧�֫O�H�� 104.06.25 */
long check_valid_isign(reply)
serverReply reply;
{
	int    rc, tmp_len;
	$char  DBName[5];
    $char  sIsign[11],sMsg[513],sIins_cat[2], sdate[11];        
    char   rtValid[3]=" ";  /* N0:�D�A��֫O�H�� ; Y0:�A��֫O�H�� */
    $char  sFsign[7];/*1091021005-SC1-���ά�-�s�W�A�Ȥ��ߩ�����*/
			
    cm_buf_get("%s %s %s %s %s", DBName, sIins_cat, sIsign, sdate ,sFsign);
    
    strcpy(sIins_cat, trim(sIins_cat));
    strcpy(sIsign   , trim(sIsign));
    strcpy(sdate   , trim(sdate));

    printf("-- trace sIsign[%s]\n ",sIsign); 
	$WHENEVER SQLERROR GOTO errexit;
	if (db_select(DBName) == False)
	{
	 	if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
	   		return M_CM_DB_NOTOPEN;
	 	else
	   		return apiRC;
	}
	if (strlen(sIins_cat)==0) strcpy(sIins_cat, "C");
		
    rc = chk_valid_isign(sIins_cat,sIsign,sdate,sFsign,rtValid,sMsg);
    if( rc != M_CM_OK)
    {
        if(exitsub(reply, rc) == True)
           return  rc;
        else
           return apiRC;
    }
    
    printf("-- trace rtValid[%s]\n ",rtValid);
    printf("-- trace sMsg[%s]\n ",sMsg);

	    
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s ", M_CM_OK, rtValid, sMsg);

	tmp_len = cm_buf_len(ReplyBuf);
	
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
	   return apiRC;
	else
	   return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_ply_for_isurvey(reply)
serverReply reply;
{
$char DBName[5], sFullName[31], stmt[2048];
$char ilast_ply[21],s_dply_end[11], dmgflag[2],provision_0905_h[2];
$int  tmp_len,iCount1,iCount2;
$long cover105=0, deduct11=0;

    cm_buf_get("%s",DBName);
    cm_buf_get("%s",ilast_ply);

    if (db_select(DBName) == False)
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $WHENEVER SQLERROR GOTO errexit;
        
    strcpy(s_dply_end, " "); strcpy(dmgflag, " "); strcpy(provision_0905_h, " "); 
    cover105 = 0; deduct11 = 0;
        
	/* �����p�O�渹�d�� */    	
    strcpy(sFullName, get_car_full_db(ilast_ply));

    /*1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I  �����ɨ�*/
    /*1081225006-SC1-���ά�-�X�R���[���ڥN�X */
	sprintf_s(stmt,sizeof stmt, " select a.dply_end,max(  \n\
				          CASE WHEN b.iins_type IN ('09','98','120','126','198','209') THEN 'A' \n\
				               WHEN b.iins_type IN ('85')                  THEN 'B' \n\
				               WHEN b.iins_type IN ('05','125','205')      THEN 'C' \n\
				               WHEN b.iins_type IN ('105','118')           THEN 'D' \n\
				          ELSE  ' ' END) AS dmgflag , \n\
				          max(CASE WHEN b.iins_type IN ('105','118') THEN b.minjured_cover ELSE -1 END) AS cover105 , \n\
				          max(CASE WHEN b.iins_type IN ('11','96','129','211') THEN b.mdeduct ELSE -1 END) AS deduct11, \n\
				          max(CASE WHEN b.iins_type IN ('09','05','209','205') THEN \n\
				                   CASE WHEN trim(b.provision)||';' LIKE '%%H;%%' THEN 'Y' ELSE ' ' END  \n\
				                   ELSE ' ' END) AS provision_0905_h \n\
				     from %s:ply_relation a, %s:ply_ins_type b \n\
				    where a.ipolicy = b.ipolicy and nvl(b.fedr_status,'') not in ('1','2','3') \n\
				      and a.ipolicy = '%s' group by 1 ",sFullName,sFullName, ilast_ply);
    
    printf("stmt=[%s]\n",stmt);
    $PREPARE preplast FROM $stmt;    
    $EXECUTE preplast INTO $s_dply_end, $dmgflag , $cover105, $deduct11 ,$provision_0905_h  ;
       	
    printf("s_dply_end=[%s] dmgflag=[%s] provision_0905_h=[%s] \n",s_dply_end, dmgflag, provision_0905_h);    
    printf("cover105=[%ld] deduct11=[%ld] \n", cover105, deduct11);

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s %ld %ld ",M_CM_OK, s_dply_end, dmgflag, provision_0905_h , cover105, deduct11);
    
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


/* 104.07.29 �����I���� 
long check_ply_renew01(reply)
serverReply reply;
{
   int   rc, tmp_len;
   $char DBName[5];
   $char iLastply[21],s_ilicense[11],s_iengine[21],s_dply_begin[11],sIins_type[INSURANCE_TYPE];
   $char s_fcard_class[2],s_irelative_ply[21],sFullName[31]; 
   $char sMsg[512];
   $char sDmgC_list[51]=" ";
   
   $char stmt[2048]; 
   long  count = 0;
   $char dmgflag_302_A[2],dmgflag_302_B[2],dmgflag_302_C[2],dmgflag_302_D[2],dmgflag_302_38[2],dmgflag_302_39[2];
  
   cm_buf_get("%s %s", DBName, iLastply);
   
   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False) 
   {
	   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
		   return M_CM_DB_NOTOPEN;
	   else
	       return apiRC;
   }
			   
   strcpy(s_ilicense, " ");  strcpy(s_iengine, " "); strcpy(s_dply_begin, " ");
   
   strcpy(iLastply,trim(iLastply));
    
   	
   $Select ilicense,iengine,dply_begin,fcard_class,irelative_ply
      into $s_ilicense,$s_iengine,$s_dply_begin,$s_fcard_class,$s_irelative_ply
      from policy_302 
     where ipolicy = $iLastply 
       and fcard_class='2'; * <= ���w���������N�I�O�渹 *
   if(SQLCODE==SQLNOTFOUND)
   {
       if(exitsub(reply,M_CM_NOT_FOUND) == True)      
          return M_CM_NOT_FOUND;                        
       else
          return apiRC;
   }  
   
   *================  �I�ة���     =================*
  
   strcpy(dmgflag_302_A , " "); strcpy(dmgflag_302_B , " ");
   strcpy(dmgflag_302_C , "N"); strcpy(dmgflag_302_D , "N"); strcpy(dmgflag_302_38 , "N"); strcpy(dmgflag_302_39 , "N");					        	    	
   sprintf_s(stmt,sizeof stmt,
	 "select \
          max(CASE WHEN iins_type IN ('09','98','126') THEN 'A' \
	               WHEN iins_type IN ('120')           THEN 'B' \
	               WHEN iins_type IN ('85')            THEN 'C' \
	               WHEN iins_type IN ('05','125')      THEN 'D' \
	               WHEN iins_type IN ('105')           THEN 'E' \
	               WHEN iins_type IN ('118')           THEN 'F' \
	               WHEN iins_type IN ('01')            THEN 'G' \
	               WHEN iins_type IN ('122')           THEN 'H' \
              ELSE ' ' END) AS dmgflag_302_A,  \
          max(CASE WHEN iins_type IN ('15')            THEN 'A' \
	               WHEN iins_type IN ('67')            THEN 'B' \
	               WHEN iins_type IN ('106')           THEN 'C' \
	               WHEN iins_type IN ('66')            THEN 'D' \
              ELSE ' ' END) AS dmgflag_302_B, \
          max(CASE WHEN iins_type IN ('04','06','18','23','75','81','83','86','110') THEN 'Y' ELSE 'N' END) AS dmgflag_302_C, \
          max(CASE WHEN iins_type IN ('02','03','07','10','61','62','63','64','65','69','107','108','119','121','123','127') THEN 'Y' ELSE 'N' END) AS dmgflag_302_D, \
          max(CASE WHEN iins_type IN ('38') THEN 'Y' ELSE 'N' END) AS dmgflag_302_38, \
          max(CASE WHEN iins_type IN ('39') THEN 'Y' ELSE 'N' END) AS dmgflag_302_39 \
       from ply_ins_type_302  \
      where ipolicy = '%s' \
        and ori_premium >0 ",iLastply );
    printf("stmt[%s]\n", stmt);        
    
    $PREPARE pre_ins_302 FROM $stmt;
    $EXECUTE pre_ins_302 INTO $dmgflag_302_A ,$dmgflag_302_B ,$dmgflag_302_C ,$dmgflag_302_D,$dmgflag_302_38,$dmgflag_302_39 ;

	printf("-- trace dmgflag_302_A[%s] ,dmgflag_302_B[%s]\n " ,dmgflag_302_A,dmgflag_302_B);
	printf("-- trace dmgflag_302_C[%s] ,dmgflag_302_D[%s]\n " ,dmgflag_302_C,dmgflag_302_D);
	printf("-- trace dmgflag_302_38[%s],dmgflag_302_39[%s]\n ",dmgflag_302_38,dmgflag_302_39);

    cm_buf_init(ReplyBuf);   
    cm_buf_put("%l %s %s %s ", M_CM_OK, s_ilicense, s_iengine, s_dply_begin);
    cm_buf_put("%s %s %s %s %s %s ",  dmgflag_302_A, dmgflag_302_B, dmgflag_302_C, dmgflag_302_D, dmgflag_302_38, dmgflag_302_39);
    
    strcpy(sDmgC_list,";");
    if (dmgflag_302_C[0]=='Y')
    {    		    
	    $DECLARE curdmgD CURSOR FOR
	      SELECT iins_type        
	        FROM ply_ins_type_302
	       WHERE ipolicy = $iLastply
	         AND iins_type in ('04','06','18','23','75','81','83','86','110')
	         AND ori_premium >0;
	    $OPEN curdmgD;
	    for(;;)
	    {
	        $FETCH curdmgD INTO $sIins_type;
	        if (SQLCODE != 0) break;
	        strcpy(sIins_type, trim(sIins_type));
	    	strcat(sDmgC_list, sIins_type);
	    	strcat(sDmgC_list, ";");
	    }
	    $CLOSE curdmgD;
    }
    cm_buf_put("%s",  sDmgC_list);
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
    else
       return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}	 */ 

/* �ܧ�γ~:���̷s�O���� */
long check_ply_renew01(reply)
serverReply reply;
{
   int   rc, tmp_len;
   $char DBName[5];
   $char iLastply[21],s_ilicense[11],s_iengine[CA_ENGINE_NUM],s_dply_begin[11],sIins_type[INSURANCE_TYPE];
   $char s_fcard_class[2],s_irelative_ply[21],sFullName[31]; 
   $char sMsg[512];
   $char sDmgC_list[51]=" ";
   
   $char stmt[2048]; 
   long  count = 0;
   $char dmgflag_302_A[2],dmgflag_302_B[2],dmgflag_302_C[2],dmgflag_302_D[2],dmgflag_302_38[2],dmgflag_302_39[2],dmgflag_152[2],dmgflag_153[2];
   $char dmgflag_161[2],dmgflag_162[2]; /*1070212002-SC1-�A������152�I�ؤΤ�������153�I�ءA�����s�I�إN����161�B162*/
   cm_buf_get("%s %s", DBName, iLastply);
   
   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False) 
   {
	   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
		   return M_CM_DB_NOTOPEN;
	   else
	       return apiRC;
   }
   
   strcpy(s_ilicense, " ");  strcpy(s_iengine, " "); strcpy(s_dply_begin, " ");
   strcpy(s_fcard_class, " "); 
      
   strcpy(iLastply,trim(iLastply)); 
   strcpy(sFullName, get_car_full_db(iLastply));               

   /* s_dply_begin: ���O������A��Y����O�ͮĤ� */			   
   sprintf_s(stmt,sizeof stmt, "select a.iassured,a.iengine,b.dply_end,b.fcard_class,b.irelative_ply  \
				    from %s:policy a ,%s:ply_relation b  \
				   where a.ipolicy = b.ipolicy  \
				     and a.ipolicy = ?",sFullName,sFullName);
    printf("-- trace stmt[%s]\n ",stmt);
    $PREPARE pre_ply_last FROM $stmt;
    $EXECUTE pre_ply_last INTO $s_ilicense,$s_iengine,$s_dply_begin,$s_fcard_class,$s_irelative_ply
       USING $iLastply;
				                  
   if(SQLCODE==SQLNOTFOUND)
   {   	   	
       if(exitsub(reply,M_CM_NOT_FOUND) == True)      
          return M_CM_NOT_FOUND;                        
       else
          return apiRC;
   }  
   if (s_fcard_class[0]=='1')   	
   {
   	   if (strlen(trim(s_irelative_ply))>0)
   	   {   	   	   
		    $EXECUTE pre_ply_last INTO $s_ilicense,$s_iengine,$s_dply_begin,$s_fcard_class,$s_irelative_ply
		       USING $s_irelative_ply;     
     
		   if(SQLCODE==SQLNOTFOUND)
		   {   	   	
		       if(exitsub(reply,M_CM_NOT_FOUND) == True)      
		          return M_CM_NOT_FOUND;                        
		       else
		          return apiRC;
		   } 		     
   	   }
   	   else
   	   {
	       if(exitsub(reply,M_CM_NOT_FOUND) == True)      
	          return M_CM_NOT_FOUND;                        
	       else
	          return apiRC;   	   	
   	   }   	
   }
   /*================  �I�ة���     =================*/
  
   strcpy(dmgflag_302_A , " "); strcpy(dmgflag_302_B , " ");
   strcpy(dmgflag_302_C , "N"); strcpy(dmgflag_302_D , "N"); strcpy(dmgflag_302_38 , "N"); strcpy(dmgflag_302_39 , "N");					        	    	
   sprintf_s(stmt,sizeof stmt,
	 "select \
          max(CASE WHEN iins_type IN ('152','153','161','162')     THEN '9' \
                   WHEN iins_type IN ('09','98','126','198','209') THEN 'A' \
	               WHEN iins_type IN ('120')           THEN 'B' \
	               WHEN iins_type IN ('85')            THEN 'C' \
	               WHEN iins_type IN ('05','125','205')THEN 'D' \
	               WHEN iins_type IN ('105')           THEN 'E' \
	               WHEN iins_type IN ('118')           THEN 'F' \
	               WHEN iins_type IN ('01','201')      THEN 'G' \
	               WHEN iins_type IN ('122')           THEN 'H' \
              ELSE ' ' END) AS dmgflag_302_A,  \
          max(CASE WHEN iins_type IN ('15')            THEN 'A' \
	               WHEN iins_type IN ('67')            THEN 'B' \
	               WHEN iins_type IN ('106')           THEN 'C' \
	               WHEN iins_type IN ('66')            THEN 'D' \
              ELSE ' ' END) AS dmgflag_302_B, \
          max(CASE WHEN iins_type IN ('04','06','18','23','75','81','83','86','110') THEN 'Y' ELSE 'N' END) AS dmgflag_302_C, \
          max(CASE WHEN iins_type IN ('02','03','07','10','61','62','63','64','65','69','107','108','119','121','123','127') THEN 'Y' ELSE 'N' END) AS dmgflag_302_D, \
          max(CASE WHEN iins_type IN ('38') THEN 'Y' ELSE 'N' END) AS dmgflag_302_38, \
          max(CASE WHEN iins_type IN ('39') THEN 'Y' ELSE 'N' END) AS dmgflag_302_39, \
          max(CASE WHEN iins_type IN ('152') THEN 'Y' ELSE 'N' END) AS dmgflag_152, \
          max(CASE WHEN iins_type IN ('153') THEN 'Y' ELSE 'N' END) AS dmgflag_153, \
          max(CASE WHEN iins_type IN ('161') THEN 'Y' ELSE 'N' END) AS dmgflag_161, \
          max(CASE WHEN iins_type IN ('162') THEN 'Y' ELSE 'N' END) AS dmgflag_162 \
       from %s:ply_ins_type  \
      where ipolicy = '%s'" ,sFullName,iLastply );

    printf("stmt[%s]\n", stmt);        
    
    $PREPARE pre_ins_302 FROM $stmt;
    $EXECUTE pre_ins_302 INTO $dmgflag_302_A ,$dmgflag_302_B ,$dmgflag_302_C ,$dmgflag_302_D,$dmgflag_302_38,$dmgflag_302_39,$dmgflag_152,$dmgflag_153,$dmgflag_161,$dmgflag_162  ;

	printf("-- trace dmgflag_302_A[%s] ,dmgflag_302_B[%s]\n " ,dmgflag_302_A,dmgflag_302_B);
	printf("-- trace dmgflag_302_C[%s] ,dmgflag_302_D[%s]\n " ,dmgflag_302_C,dmgflag_302_D);
	printf("-- trace dmgflag_302_38[%s],dmgflag_302_39[%s]\n ",dmgflag_302_38,dmgflag_302_39);
	printf("-- trace dmgflag_152[%s],dmgflag_153[%s]\n ",dmgflag_152,dmgflag_153);
    printf("-- trace dmgflag_161[%s],dmgflag_162[%s]\n ",dmgflag_161,dmgflag_162);

    cm_buf_init(ReplyBuf);   
    cm_buf_put("%l %s %s %s ", M_CM_OK, s_ilicense, s_iengine, s_dply_begin);
    cm_buf_put("%s %s %s %s %s %s %s %s %s %s ",  dmgflag_302_A, dmgflag_302_B, dmgflag_302_C, dmgflag_302_D, dmgflag_302_38, dmgflag_302_39,dmgflag_152,dmgflag_153,dmgflag_161,dmgflag_162);
    
    strcpy(sDmgC_list,";");
/*    
    if (dmgflag_302_C[0]=='Y')
    {    		    
	    $DECLARE curdmgD CURSOR FOR
	      SELECT iins_type        
	        FROM ply_ins_type
	       WHERE ipolicy = $iLastply
	         AND iins_type in ('04','06','18','23','75','81','83','86','110');
	         
	    $OPEN curdmgD;
	    for(;;)
	    {
	        $FETCH curdmgD INTO $sIins_type;
	        if (SQLCODE != 0) break;
	        strcpy(sIins_type, trim(sIins_type));
	    	strcat(sDmgC_list, sIins_type);
	    	strcat(sDmgC_list, ";");
	    }
	    $CLOSE curdmgD;
    }
*/    
    cm_buf_put("%s",  sDmgC_list);
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
    else
       return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* 1041013003_C1_car320.car301.car401��������(F)��J�ި� */
long get_ca_id_officer_iins(reply)
serverReply reply;
{
$char DBName[5];
$char s_provision[7],s_iins_list[512],sIins_type[INSURANCE_TYPE],stmt[1024];/* 1081225006-SC1-���ά�-�X�R���[���ڥN�X  */
$char iins_cat[IINS_CAT], iassured[IASSURED], iofficer[IOFFICER],icar_type[ICAR_TYPE],iroute[21];
$char dply_begin[DATE], dpolicy[DATE],carteam[11];
char  iyear[2];
int   rc,tmp_len;
  
    cm_buf_get("%s", DBName);
    cm_buf_get("%s %s %s", iassured, iofficer, iroute );
    cm_buf_get("%s %s", icar_type, dply_begin);
    cm_buf_get("%s", dpolicy);
   
    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False) 
    {
	   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
		   return M_CM_DB_NOTOPEN;
	   else
	       return apiRC;
    }   
   
    /* ���B�ȥΨ쨮�إN�����o�������O, ��l,2:�������[���ڥ�,0:�O��(��),year�~��,�S���Ψ�A�Ȭ��F�ŦX�Ѽƶǻ� */ 
    rc = get_iins_cat( icar_type, 2, 0, iins_cat, iyear, v_sMsg );
    if( rc != M_CM_OK) return rc;

    if (strlen(trim(dpolicy)) == 0) strcpy(dpolicy, cm_edate_str(cm_today()));    		
    
    printf("iins_cat=[%s] iassured=[%s]\n   ", iins_cat, iassured);        
    printf("iofficer=[%s] icar_type=[%s]\n  ", iofficer, icar_type);        	
    printf("dpolicy =[%s] dply_begin=[%s]\n ", dpolicy , dply_begin);        

    strcpy(carteam," ");
    strcpy(sIins_type ," ");
    strcpy(s_iins_list,";"); 
        
    if (strncmp(iroute,"PE",2) == 0)
    {
        strncpy(carteam, &iroute[2], strlen(iroute)-2 );
        carteam[strlen(iroute)-2] = '\0';                        
    }
    strcpy(carteam, trim(carteam));
    printf("carteam=[%s] \n ", carteam);              
    
    if (strlen(carteam)>0)
    {
    	strcpy(iofficer, carteam);
    }else{    	
        strcpy(iofficer, trim(iofficer));
    }
    /*** iassured���|�P�ɦ�F�PG���� ***/
    sprintf_s(stmt,sizeof stmt,
		 "SELECT iins_type,provision \
	       FROM ca_id_officer   \
	      WHERE iins_cat = '%s' \
	        AND iassured = '%s' \
		    AND iofficer = '%s' \
	        AND '%s' matches CASE WHEN trim(icar_type) = '' then '*' ELSE icar_type END      \
	        AND '%s' BETWEEN nvl(drate_bgn  ,'01/01/1999'::date) AND nvl(drate_end  ,'01/01/2999'::date) \
	        AND '%s' BETWEEN nvl(dpolicy_bgn,'01/01/1999'::date) AND nvl(dpolicy_end,'01/01/2999'::date) \
	        AND (dexpire is null or dexpire > '%s')"
	        ,iins_cat, iassured, iofficer, icar_type , dply_begin, dpolicy, dpolicy);
    printf("pre_GetProv_F stmt[%s]\n", stmt);        
    $PREPARE pre_GetProv_F FROM $stmt;
    $DECLARE curGetProv_F CURSOR FOR pre_GetProv_F;
    $OPEN curGetProv_F;
    for(;;)
    {
         $FETCH curGetProv_F INTO $sIins_type,$s_provision;
         if (SQLCODE != 0) break;         
         strcpy(sIins_type, trim(sIins_type));
    	 strcat(s_iins_list, sIins_type);
    	 strcat(s_iins_list, ";");
    }
    $CLOSE curGetProv_F;
	    
    printf("s_iins_list=[%s]  \n",s_iins_list);    
    printf("s_provision=[%s]  \n",s_provision);

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s", M_CM_OK, s_iins_list, s_provision);
    
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


long chk_iroute_work(reply)
serverReply reply;
{
$char DBName[5];
$char userid[11];
$char iquota[11];
$char s_iins_list[512],sIins_type[INSURANCE_TYPE],stmt[1024];
$char iins_cat[IINS_CAT], iassured[IASSURED], iofficer[IOFFICER],icar_type[ICAR_TYPE],iroute[21];
$char dply_begin[DATE], dpolicy[DATE],carteam[11];
char  iyear[2];
int   rc,tmp_len;
$char rtn[2];
  
    cm_buf_get("%s", DBName);
    cm_buf_get("%s %s", userid, iroute);
   
    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False) 
    {
	   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
		   return M_CM_DB_NOTOPEN;
	   else
	       return apiRC;
    }   

    strcpy(rtn,"0");

    $select iquota
       into $iquota
       from officer 
      where iofficer = $userid;
    if (SQLCODE != SQLNOTFOUND)
    {
       $select icode[1] 
          into $rtn
          from cu_code_data
         where itype = 'DE'
           and ncode = $iroute 
           and tcode_remark[1,4] = substr($iquota,1,4);
       if (SQLCODE != SQLNOTFOUND)
       {
          strcpy(rtn,"1");
       }
    }

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s", M_CM_OK, rtn);
    
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}



/**********************************************************************************
1050105008_C1 RBA�t�Ϋظm
1101124011_SC1_RBA�ק�@�~
**********************************************************************************/

static long get_RisKCntry( reply )
serverReply reply;
{
int     tmp_len;
$char   DBName[5],itype[2],fmember[2],nmember[101],stmp[1024];
long    rc, iCount;

    $WHENEVER SQLERROR GOTO errexit;

    cm_buf_get("%s %s %s", DBName, itype, fmember);

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }
	
    if(strncmp(itype,"1",1) == 0 || strncmp(itype,"2",1) == 0)
    {
    	sprintf_s(stmp,sizeof stmp," SELECT nmember \n"
    	             "   FROM cm_risk_member \n"
    	             "  WHERE itype = '%s' AND dexpire is null \n", itype);       
    }
    else if(strncmp(itype,"3",1) == 0 || strncmp(itype,"6",1) == 0 || strncmp(itype,"E",1) == 0)
    {
    	sprintf_s(stmp,sizeof stmp," SELECT nmember \n"
    	             "   FROM cm_risk_member  \n"
    	             "  WHERE itype = '%s' AND fmember = '%s'  \n"
    	             "    AND dexpire is null \n", itype, fmember);
    }
    else if (strncmp(itype,"P",1) == 0)
    {
    	sprintf_s(stmp,sizeof stmp," SELECT (trim(imember)||' '||trim(nmember)) \n"
    	             "   FROM cm_risk_member \n"
    	             "  WHERE itype = '%s' AND fmember = 'P' \n"
    	             "    AND dexpire is null \n", itype);       
    }
    else if (strncmp(itype,"R",1) == 0)
    {
    	sprintf_s(stmp,sizeof stmp," SELECT detail2 FROM car_code \n"
    	             "  WHERE kind = 'RB' AND detail = '1' \n", itype);       
    }
	
    cm_buf_init(ReplyBuf);
    cm_buf_res_msg();
    cm_buf_res_count();
    iCount=0;
    $PREPARE curRisk FROM $stmp;
    $DECLARE curRisk_cur CURSOR FOR curRisk;
    $OPEN curRisk_cur;
    for(;;)
    {
        $FETCH curRisk_cur INTO $nmember;
        if( SQLCODE == SQLNOTFOUND)
            break;
        cm_buf_put("%s", nmember);
        iCount++;
    }
    $CLOSE curRisk_cur;
    $FREE curRisk_cur;
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(iCount);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


static long get_last_ply( reply )
serverReply reply;
{
	$char DBName[5], sFullName[31], stmt[2048];
	$char ilast_ply[21],s_dply_end[11], s_ins_dmg[2],iassured[13],iengine[CA_ENGINE_NUM],drate_ym[4],opt[2];
	$int  tmp_len,iCount1,iCount2;
	$long cover105=0, deduct11=0;
	
	$char funknown_dmg[2],iquery_num_damage[21],f302Set[2];

    cm_buf_get("%s",DBName);
    cm_buf_get("%s",ilast_ply);
    cm_buf_get("%s",opt);
    cm_buf_get("%s",f302Set);
    
    printf("ilast_ply=[%s]\n", ilast_ply);
    printf("opt      =[%s]\n", opt);
    printf("f302Set  =[%s]\n", f302Set);
    
    if (db_select(DBName) == False)
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $WHENEVER SQLERROR GOTO errexit;
        
    strcpy(drate_ym, " "); strcpy(s_ins_dmg, " ");     
    strcpy(iassured, " "); strcpy(iengine, " "); strcpy(s_dply_end, " "); 
    
    if (opt[0]=='1'){ /* �e�O��*/
    
	    strcpy(sFullName, get_car_full_db(ilast_ply));
        /* 1090812005-SC1-���ά�-�s�W�s�ӫ~-�T�����B���郞�I���l���O�I198�I */
	    sprintf_s(stmt,sizeof stmt,
		 "select max( CASE WHEN iins_type IN ('01','122','05','09','120','125','126','105','85','118','198','201','205','209') THEN  drate_ym ELSE ' ' END) AS drate_ym, \
	          max(CASE WHEN iins_type IN ('01','122','201')                  THEN '1' \
		               WHEN iins_type IN ('05','09','120','125','126','198','205','209') THEN '2' \
		               WHEN iins_type IN ('105','85','118')            THEN '3' \
	              ELSE ' ' END) AS s_ins_dmg  \
	       from %s:ply_ins_type  \
	      where ipolicy = '%s' \
	        and nvl(fedr_status,'') not in ('1','2','3') ",sFullName ,ilast_ply );
	    printf("stmt1=[%s]\n",stmt);
	    $PREPARE preplast1 FROM $stmt;    
	    $EXECUTE preplast1 INTO $drate_ym, $s_ins_dmg;       
	    printf("drate_ym=[%s] s_ins_dmg=[%s]\n", drate_ym, s_ins_dmg);
	        
		sprintf_s(stmt,sizeof stmt, " select b.iassured, b.iengine, a.dply_end \
					     from %s:ply_relation a,%s:policy b \
					    where a.ipolicy = b.ipolicy  \
					      and a.ipolicy = '%s'  ",sFullName, sFullName, ilast_ply);
	    printf("stmt2=[%s]\n",stmt);
	    $PREPARE preplast2 FROM $stmt;    
	    $EXECUTE preplast2 INTO $iassured, $iengine, $s_dply_end ;
	    printf("iassured=[%s] iengine=[%s] s_dply_end=[%s] \n",iassured, iengine, s_dply_end);    
	    
	    if (SQLCODE != SQLNOTFOUND){
		    strcpy(iassured     ,trim(iassured));
		    strcpy(iengine      ,rtrim(iengine));
		    strcpy(s_dply_end   ,trim(s_dply_end)); 
		    strcpy(drate_ym     ,trim(drate_ym));
		    /*strcpy(s_ins_dmg ,trim(s_ins_dmg));*/
		}    
	    cm_buf_init(ReplyBuf);
	    cm_buf_put("%l %s %s %s %s %s ",M_CM_OK, s_ins_dmg, iassured, iengine, s_dply_end , drate_ym );
		
    }else{ /*��O��*/

    	strcpy(funknown_dmg , " ");   	strcpy(iquery_num_damage, " ");  
        
        if (f302Set[0]=='4')       /*���O*/  
        {   /*1070212002-SC1-�A������152�I�ؤΤ�������153�I�ءA�����s�I�إN����161�B162*/
		    sprintf_s(stmt,sizeof stmt,
			 "select \
		          max(CASE WHEN iins_type IN ('01','122','201')                  THEN '1' \
			               WHEN iins_type IN ('05','09','120','125','126','198','205','209') THEN '2' \
			               WHEN iins_type IN ('105','85','118')            THEN '3' \
			               WHEN iins_type IN ('152','153','161','162')                 THEN '4' \
		              ELSE ' ' END) AS s_ins_dmg  \
		       from ply_ins_type_302  \
		      where ipolicy = '%s' and ori_premium > 0 " ,ilast_ply );
		    printf("stmt1=[%s]\n",stmt);
		    $PREPARE prep3021 FROM $stmt;    
		    $EXECUTE prep3021 INTO $s_ins_dmg;
		    printf("302 s_ins_dmg=[%s]\n", s_ins_dmg);        	
	        	
		    sprintf_s(stmt,sizeof stmt,
		    "select funknown_dmg_ori,iquery_num_damage \
		       from policy_302  \
		      where ipolicy = '%s'" ,ilast_ply );
		    printf("stmt1=[%s]\n",stmt);
		    $PREPARE prep3022 FROM $stmt;    
		    $EXECUTE prep3022 INTO $funknown_dmg, $iquery_num_damage;	        	         		    
        }
        else if (f302Set[0]=='5')  /*��ĳ��O*/
        {   /*1070212002-SC1-�A������152�I�ؤΤ�������153�I�ءA�����s�I�إN����161�B162*/
		    sprintf_s(stmt,sizeof stmt,
			 "select \
		          max(CASE WHEN iins_type IN ('01','122','201')                  THEN '1' \
			               WHEN iins_type IN ('05','09','120','125','126','198','205','209') THEN '2' \
			               WHEN iins_type IN ('105','85','118')            THEN '3' \
			               WHEN iins_type IN ('152','153','161','162')                 THEN '4' \
		              ELSE ' ' END) AS s_ins_dmg  \
		       from ply_ins_type_302  \
		      where ipolicy = '%s' and mins_premium > 0 " ,ilast_ply );
		    printf("stmt1=[%s]\n",stmt);
		    $PREPARE prep3023 FROM $stmt;    
		    $EXECUTE prep3023 INTO $s_ins_dmg;
		    printf("302 s_ins_dmg=[%s]\n", s_ins_dmg);        	
	        	
		    sprintf_s(stmt,sizeof stmt,
			 "select funknown_dmg_sug,iquery_num_damage_sug \
		       from policy_302  \
		      where ipolicy = '%s'" ,ilast_ply );
		    printf("stmt1=[%s]\n",stmt);
		    $PREPARE prep3024 FROM $stmt;    
		    $EXECUTE prep3024 INTO $funknown_dmg,$iquery_num_damage;	   		    
        }
        
	    printf("funknown_dmg=[%s] iquery_num_damage=[%s] \n", funknown_dmg, iquery_num_damage); 
	    if (SQLCODE != SQLNOTFOUND){
	       strcpy(funknown_dmg       ,trim(funknown_dmg));		       
	       strcpy(iquery_num_damage  ,trim(iquery_num_damage));		       
	    }  
	    cm_buf_init(ReplyBuf);
        cm_buf_put("%l %s %s %s",M_CM_OK, s_ins_dmg, funknown_dmg, iquery_num_damage );	
    }
    
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}     	


/*1050525001_C2 ���I�O���X�j�e�~�L�s */
/* ���o�����榬�O���A(�J��e) */
static long chk_pay_status( reply )
serverReply reply;
{
int     tmp_len;
$char   DBName[5],ipre_rcv[21],ftype_pol_1[3] ,ftype_sp_1[3],ftype_pol_2[3] ,ftype_sp_2[3];
$long   pre_mprem_1,pre_mprem_2,pass_mprem_1,pass_mprem_2,rt_status_1,rt_status_2,rt_status_all;
$int    rc, t_count=0,pre_fstatus_1,pre_fstatus_2;


    $WHENEVER SQLERROR GOTO errexit;

    cm_buf_get("%s %s", DBName, ipre_rcv);

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }
    
    
    /* rt_status_1 = -1 �|�����O
       rt_status_1 =  0 �����B���O 
       rt_status_1 =  1 ���B���O 
    */
    t_count = 0; rt_status_1 = -1 ; rt_status_2 = -1 ; rt_status_all =-1 ; 
    pre_mprem_1= 0; pass_mprem_1= 0; pre_fstatus_1 = 0;
    strcpy(ftype_pol_1 ," "); strcpy(ftype_sp_1," ");
       
	$select mprem, fstatus, ftype_pol , ftype_sp
	   into $pre_mprem_1, $pre_fstatus_1, $ftype_pol_1 , $ftype_sp_1
	   from cm_pre_receive
	  where ipre_rcv = $ipre_rcv and iins_kind = '1' and ipre_end = ' ';
    if (SQLCODE == SQLNOTFOUND)
    {
    	 rt_status_1 = -2;  /* �L�@�γ����� */
    }
    else
    {    	
    	if (pre_mprem_1 > 0)
    	{
			$select mnt into $pass_mprem_1
			   from ao_prercv_pass
			  where ipre_rcv = $ipre_rcv and iins_kind = '1' and ipre_end = ' ';
		    if (SQLCODE == SQLNOTFOUND)	
		    {
		    	rt_status_1 = -1;         /* �|�����O */ 
		    }
		    else
		    {
		    	if (pass_mprem_1 > 0)
		    	{	
			    	if (pass_mprem_1 >= pre_mprem_1)  
			    	{
			    		rt_status_1 = 1;   /* ���B */
			    	}
			    	else
			    	{
			    		rt_status_1 = 0;   /* �����B */
			    	}	
			    }	
			    else
			    {
			    	rt_status_1 = -4;  /* ao_prercv_pass ���B=0 (���`) */ 
			    }	
		    }
	    }
	    else
	    {
	    	rt_status_1 = -3;  /* �@�γ�������B=0 (���`) */ 
	    }
	    	
    }

    pre_mprem_2= 0; pass_mprem_2= 0; pre_fstatus_2 = 0;
    strcpy(ftype_pol_2 ," "); strcpy(ftype_sp_2," "); 
        
	$select mprem, fstatus, ftype_pol , ftype_sp
	   into $pre_mprem_2, $pre_fstatus_2, $ftype_pol_2 , $ftype_sp_2
	   from cm_pre_receive
	  where ipre_rcv = $ipre_rcv and iins_kind = '2' and ipre_end = ' ';
    if (SQLCODE == SQLNOTFOUND)
    {
    	 rt_status_2 = -2;  /* �L�@�γ����� */
    }
    else
    {
    	/* rt_status_1 <=0 ���ܩ|�����O( =-1) �� �����B���O(= 0) */
    	if (pre_mprem_2 > 0)
    	{
			$select mnt into $pass_mprem_2
			   from ao_prercv_pass
			  where ipre_rcv = $ipre_rcv and iins_kind = '2' and ipre_end = ' ' ;
		    if (SQLCODE == SQLNOTFOUND)	
		    {
		    	rt_status_2 = -1;         /* �|�����O */ 
		    }
		    else
		    {
		    	if (pass_mprem_2 > 0)
		    	{	
			    	if (pass_mprem_2 >= pre_mprem_2)  
			    	{
			    		rt_status_2 = 1;   /* ���B */
			    	}
			    	else
			    	{
			    		rt_status_2 = 0;   /* �����B */
			    	}	
			    }	
			    else
			    {
			    	rt_status_2 = -4;  /* ao_prercv_pass ���B=0 (���`) */ 
			    }
		    }
	    }
	    else
	    {
	    	rt_status_2 = -3;  /* �@�γ�������B=0 (���`) */ 
	    }

    }
    printf("-- rt_status_1[%d] rt_status_2[%d] \n ",rt_status_1,rt_status_2);
        
    /* ��j or ���or �j+�� ���O���A�G 1:�w��; -1:���� */
	if ((rt_status_1==1 && rt_status_2==-2) || (rt_status_1==-2 && rt_status_2==1) || (rt_status_1==1 && rt_status_2==1) )
	{
		rt_status_all = 1; 
	}
	printf("-- rt_status_all[%d] \n ",rt_status_all);
    cm_buf_init(ReplyBuf);

    cm_buf_put("%l", M_CM_OK);
    cm_buf_put("%d %d %d", rt_status_1 ,rt_status_2, rt_status_all);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


long get_renew_data(reply)
serverReply reply;
{
    int   rc, tmp_len;
    $char DBName[5], iLastply[21],fOpt[2],fcard_class[2],iins_type[7];
    $char s_ilicense[11],s_iengine[CA_ENGINE_NUM],s_dply_begin[11],s_fcard_class[2],s_irelative_ply[21],s_itag[CA_TAG_NUM];
    $char stmt[1024],stmp[51],sFullName[31],stmt1[1024],stmt2[1024]; 
    $int  ori_ins_cnt, sug_ins_cnt;
    $char s_have_ins[2];
    char fNoData = 'N';
        
    cm_buf_get("%s %s %s %s %s", DBName,fOpt, iLastply,fcard_class,iins_type);

    printf("-- trace get_renew_data()\n ");
    
    $WHENEVER SQLERROR GOTO errexit;
    
    if (db_select(DBName) == False) 
    {
	    if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
	 	   return M_CM_DB_NOTOPEN;
	    else
	        return apiRC;
    }
	
	fNoData = 'Y';	strcpy(stmp," ");
    strcpy(s_ilicense, " ");    strcpy(s_iengine, " ");       strcpy(s_itag, " ");  strcpy(s_dply_begin, " "); 
    strcpy(s_fcard_class, " "); strcpy(s_irelative_ply, " "); strcpy(s_have_ins,"0");
    
    strcpy(iLastply,trim(iLastply));
    strcpy(iins_type,trim(iins_type));    
    
    if (strlen(iLastply)>0)
    {   
    	if (strlen(trim(fcard_class))>0)
    	{  
    		sprintf_s(stmp,sizeof stmp," AND fcard_class matches '%s' ",fcard_class);
    	}
    	printf("-- trace stmp[%s]\n ",stmp);	
    	     
	    /* fOpt = "2" ��O�ɸ�� ; fOpt = "1" �h�~(�̷s�O����)��� */ 
	    if (fOpt[0] == '2'){

		    sprintf_s(stmt,sizeof stmt, "Select a.ilicense, nvl(a.iengine,' '), nvl(a.itag,' '), a.dply_begin, a.fcard_class, nvl(a.irelative_ply,' ') "
		                  "  FROM policy_302 a "
		                  " WHERE a.ipolicy = ? ");
		    
		    if (strlen(iins_type)>0)
		    {
		    	/* ���O�զX */
		    	sprintf_s(stmt1,sizeof stmt1, "Select count(*) "
		    	               "  FROM ply_ins_type_302 "
		    	               " WHERE ipolicy = ? "
		    	               "   AND iins_type = ? "
		    	               "   AND ori_dam_cover > 0 ");
				/* ��ĳ��O�զX */
		        sprintf_s(stmt2,sizeof stmt2, "Select count(*) "
		    	               "  FROM ply_ins_type_302 "
		    	               " WHERE ipolicy = ? "
		    	               "   AND iins_type = ? "
		    	               "   AND mdamage_cover > 0 ");
		    }
		    else
		    {
		    	ori_ins_cnt = 0;
		    	sug_ins_cnt = 0;
		    }
		    	
		}
		else
		{
			strcpy(sFullName, get_car_full_db(iLastply));
			if (strlen(iins_type)>0)
		    {
			    sprintf_s(stmt1,sizeof stmt1, "Select count(*) "
			    	           "  FROM %s:ply_ins_type "
			    	           " WHERE ipolicy = ? "
			    	           "   AND iins_type = ? "
			    	           "   AND mdamage_cover > 0 ",sFullName);
		   	}
		   	else
		   	{
		   		ori_ins_cnt = 0;
		    	sug_ins_cnt = 0;
		   	}
 	 		    
		    sprintf_s(stmt,sizeof stmt, "SELECT b.iassured, nvl(b.iengine,' '), nvl(b.itag,' '), a.dply_end, a.fcard_class, nvl(a.irelative_ply,' ') "
		                  "  FROM %s:ply_relation a ,%s:policy b "
		                  " WHERE a.ipolicy = b.ipolicy "
		                  "   AND a.ipolicy = ? ", sFullName,sFullName);
		}
		strcat(stmt,stmp);
		printf("-- trace stmt[%s]\n ",stmt);
		printf("-- trace stmt1[%s]\n ",stmt1);
		$PREPARE pre_ply FROM $stmt;    
	    $EXECUTE pre_ply INTO  $s_ilicense, $s_iengine, $s_itag, $s_dply_begin ,$s_fcard_class , $s_irelative_ply
	       USING $iLastply;	    
	    if (strlen(trim(s_ilicense))>0)	    
	    {
			 fNoData = 'N';
			 
			 if (strlen(iins_type)>0)
			 {
			 	if (fOpt[0] == '2')
			 	{
				 	$PREPARE pre_ins1 FROM $stmt1;    
		    		$EXECUTE pre_ins1 INTO $ori_ins_cnt
		       		USING $iLastply,$iins_type;
		       		
		       		$PREPARE pre_ins2 FROM $stmt2;    
		    		$EXECUTE pre_ins2 INTO $sug_ins_cnt
		       		USING $iLastply,$iins_type;
			 	}
			 	else
			 	{
				 	$PREPARE pre_ins1 FROM $stmt1;    
		    		$EXECUTE pre_ins1 INTO $ori_ins_cnt
		       		USING $iLastply,$iins_type;
		       		
		       		sug_ins_cnt = ori_ins_cnt;
			 	}
			 }

			 if(ori_ins_cnt == 0 && sug_ins_cnt == 0)
			 	strcpy(s_have_ins,"0");
			 else if(ori_ins_cnt == 1 && sug_ins_cnt == 1)
			 	strcpy(s_have_ins,"1");
			 else
			 	strcpy(s_have_ins,"2");
	    }
    }
    
    if (fNoData == 'Y')
    {	
        if(exitsub(reply,M_CM_NOT_FOUND) == True)      
           return M_CM_NOT_FOUND;                        
        else
           return apiRC;
    }

    cm_buf_init(ReplyBuf);   
    cm_buf_put("%l %s %s %s %s %s %s %s", M_CM_OK, s_ilicense, s_iengine, s_itag, s_dply_begin ,s_fcard_class , s_irelative_ply, s_have_ins);               
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
    else
       return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

long get_sp_20(reply)
serverReply reply;
{
     $char   DBName[5],iofficer[11],iassured[13],itag[CA_TAG_NUM],iengine[CA_ENGINE_NUM],iroute[21];
     int     tmp_len, rc;
     $int	 iCount;

     cm_buf_get("%s %s %s %s %s %s ", DBName, iofficer, iassured, itag, iengine, iroute);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
     {
       if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
           return M_CM_DB_NOTOPEN;
       else
           return apiRC;
     }
     
     iCount = 0;

     rc = chk_SP_20( iofficer, iassured, itag, iengine, iroute, &iCount, v_sMsg);
     
     printf("iCount[%d]\n",iCount);

     if( rc != M_CM_OK)
     {
        if(exitsub(reply, rc) == True)
           return  rc;
        else
           return apiRC;
     }

     cm_buf_init(ReplyBuf);

     cm_buf_put("%l %d",M_CM_OK, iCount);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* -------------------------------------------------------------------------- */
/* �ˮ֬O�_�w�鵲 */
long chk_dply_close(reply)
serverReply reply;
{
     $char   DBName[5],pgmname[8],sdate[11],sClose[2],sCommand[50];
     int     tmp_len, rc;
     $int    iCount;

     cm_buf_get("%s %s %s", DBName, pgmname, sdate);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
     {
       if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
           return M_CM_DB_NOTOPEN;
       else
           return apiRC;
     }
     
	 strcpy(pgmname,trim(pgmname));
     
     printf("pgmname=[%s],sdate=[%s]\n",pgmname,sdate);
     
     strcpy(sCommand,"*");
     strcat(sCommand,pgmname);
     strcat(sCommand,"*");
     strcat(sCommand,DBName);
     strcat(sCommand,"*");
     
     printf("sCommand=[%s]\n",sCommand);

     $SELECT count(*)
        INTO $iCount
		FROM gb_ScheduleLog
	   WHERE command matches $sCommand
         AND npgmname = 'car5081'
		 AND date(tctime) = $sdate;
		 
	 printf("iCount=[%d]\n",iCount);

     cm_buf_init(ReplyBuf);

     cm_buf_put("%l %d",M_CM_OK, iCount);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}


/* chek �e����N�I */
long check_last_ply(reply)
serverReply reply;
{
   int   rc, tmp_len;
   $char DBName[5];
   $char iLastply[21],s_ilicense[11],s_iengine[CA_ENGINE_NUM],s_dply_end[11],s_qprovision[2],sIins_type[INSURANCE_TYPE];
   $char s_fcard_class[2],s_irelative_ply[21],sFullName[31]; 
   $char sMsg[512];
   $char sIns_list[51]=" ";
   
   $char stmt[2048]; 
   long  count = 0;   
   $char iins_flag_A[2],iins_flag_B[2],iins_flag_C[2],iins_flag_D[2],iins_flag_E[2],iins_flag_F[2];
   $char iins_flag_38[2],iins_flag_39[2],iins_flag_provD[2];
     
   cm_buf_get("%s %s", DBName, iLastply);
   
   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False) 
   {
	   if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
		   return M_CM_DB_NOTOPEN;
	   else
	       return apiRC;
   }
   
   strcpy(s_ilicense, " ");  strcpy(s_iengine, " "); strcpy(s_dply_end, " ");  strcpy(s_fcard_class, " "); 
   strcpy(s_irelative_ply, " "); strcpy(s_qprovision , " ");
      
   strcpy(iLastply,trim(iLastply)); 
   strcpy(sFullName, get_car_full_db(iLastply));               
		   
   sprintf_s(stmt,sizeof stmt, "select a.iassured,a.iengine,b.dply_end,b.fcard_class,b.irelative_ply,b.qprovision  \
				    from %s:policy a ,%s:ply_relation b  \
				   where a.ipolicy = b.ipolicy  \
				     and a.ipolicy = ?",sFullName,sFullName);
    printf("-- trace stmt[%s]\n ",stmt);
    $PREPARE pre_ply_last FROM $stmt;
    $EXECUTE pre_ply_last INTO $s_ilicense,$s_iengine,$s_dply_end,$s_fcard_class,$s_irelative_ply,$s_qprovision
       USING $iLastply;
				                  
   if(SQLCODE==SQLNOTFOUND)
   {   	   	
       if(exitsub(reply,M_CM_NOT_FOUND) == True)      
          return M_CM_NOT_FOUND;                        
       else
          return apiRC;
   }  
   if (s_fcard_class[0]=='1')   	
   {
   	   if (strlen(trim(s_irelative_ply))>0)  /* ���N�I */
   	   {   	   	   
		    $EXECUTE pre_ply_last INTO $s_ilicense,$s_iengine,$s_dply_end,$s_fcard_class,$s_irelative_ply,$s_qprovision
		       USING $s_irelative_ply;     
     
		   if(SQLCODE==SQLNOTFOUND)
		   {   	   	
		       if(exitsub(reply,M_CM_NOT_FOUND) == True)      
		          return M_CM_NOT_FOUND;                        
		       else
		          return apiRC;
		   } 		     
   	   }
   	   else  /* �e��L���N�I */
   	   {
	       if(exitsub(reply,M_CM_NOT_FOUND) == True)      
	          return M_CM_NOT_FOUND;                        
	       else
	          return apiRC;   	   	
   	   }   	
   }
   /*================  �I�ة���     =================*/
   /*1081225006-SC1-���ά�-�X�R���[���ڥN�X */
   strcpy(iins_flag_A  , " "); strcpy(iins_flag_B  , " "); strcpy(iins_flag_C     , " "); 
   strcpy(iins_flag_D  , " "); strcpy(iins_flag_E  , " "); strcpy(iins_flag_F     , " "); 
   strcpy(iins_flag_38 , " "); strcpy(iins_flag_39 , " "); strcpy(iins_flag_provD , " ");
   sprintf_s(stmt,sizeof stmt,
	 "select \
          max(CASE WHEN iins_type IN ('09','98','198','209') THEN 'A' "
	             " WHEN iins_type IN ('05','205')      THEN 'B' \n"
	             " WHEN iins_type IN ('01','201')      THEN 'C' "
            " ELSE ' ' END) AS iins_flag_A,\n"
        " max(CASE WHEN iins_type IN ('15')      THEN 'A' "
	             " WHEN iins_type IN ('67')      THEN 'B' \n"
	             " WHEN iins_type IN ('66')      THEN 'C' "
            " ELSE ' ' END) AS iins_flag_B, \n"
        " max(CASE WHEN iins_type IN ('153','162') THEN 'A' "
	             " WHEN iins_type IN ('152','161') THEN 'B' \n"
            " ELSE ' ' END) AS iins_flag_C, \n"
        " max(CASE WHEN iins_type IN ('04','06','18','23','75','86','110') THEN 'Y' ELSE ' ' END) \n"
                          " AS iins_flag_D, \n"
        " max(CASE WHEN iins_type IN ('02','03','07','10','61','62','63','64','65','69','150') THEN 'Y' ELSE ' ' END) \n"
                          " AS iins_flag_E, \n"
        " max(CASE WHEN iins_type IN ('11','76','129','82','211')  THEN 'Y' ELSE ' ' END) \n"
                          " AS iins_flag_F, \n"
        " max(CASE WHEN iins_type IN ('38') THEN 'Y' ELSE ' ' END) \n"
                          " AS iins_flag_38, \n"
        " max(CASE WHEN iins_type IN ('39') THEN 'Y' ELSE ' ' END) \n"
                          " AS iins_flag_39, \n"
        " max(CASE WHEN trim(provision)||';' matches '*D;*' THEN 'Y' ELSE ' ' END) \n"
                          " AS iins_flag_provD \n"
     " from %s:ply_ins_type "
      " where ipolicy = '%s'\n" ,sFullName,iLastply );
    /*1070212002-SC1-�A������152�I�ؤΤ�������153�I�ءA�����s�I�إN����161�B162*/
    printf("stmt[%s]\n", stmt);
    
    $PREPARE pre_ins_302 FROM $stmt;
    $EXECUTE pre_ins_302 INTO $iins_flag_A , $iins_flag_B , $iins_flag_C , $iins_flag_D, $iins_flag_E, $iins_flag_F,
                              $iins_flag_38, $iins_flag_39, $iins_flag_provD;

    if(SQLCODE==SQLNOTFOUND)
    {   	   	
       if(exitsub(reply,M_CM_NOT_FOUND) == True)      
          return M_CM_NOT_FOUND;                        
       else
          return apiRC;
    } 
    cm_buf_init(ReplyBuf);   
    cm_buf_put("%l %s %s %s %s ", M_CM_OK, s_ilicense, s_iengine, s_dply_end,s_qprovision);
    cm_buf_put("%s %s %s %s %s %s %s %s %s ",  iins_flag_A , iins_flag_B , iins_flag_C, iins_flag_D, iins_flag_E, iins_flag_F,
                                      iins_flag_38, iins_flag_39, iins_flag_provD );
 /*    
    strcpy(sIns_list,";");
   
    if (dmgflag_302_C[0]=='Y')
    {    		    
	    $DECLARE curdmgD CURSOR FOR
	      SELECT iins_type        
	        FROM ply_ins_type
	       WHERE ipolicy = $iLastply
	         AND iins_type in ('04','06','18','23','75','86','110');
	         
	    $OPEN curdmgD;
	    for(;;)
	    {
	        $FETCH curdmgD INTO $sIins_type;
	        if (SQLCODE != 0) break;
	        strcpy(sIins_type, trim(sIins_type));
	    	strcat(sIns_list, sIins_type);
	    	strcat(sIns_list, ";");
	    }
	    $CLOSE curdmgD;
    }
   
    cm_buf_put("%s",  sIns_list);
*/     
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
    else
       return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}



long Get_Ca_Eply_Mail(reply)
serverReply reply;
{
    int    rc, tmp_len;
    $char  DBName[5], sTmpSQL[1024];
    $char  sIassured[13], sIroute[21];
    $char  fexist[2], aemail[51], nftp_memo[51],freceipt[2], femail[2], fftp[2];  

  
 	cm_buf_get("%s %s %s", DBName, sIassured, sIroute);
 	
 	$WHENEVER SQLERROR GOTO errexit;
 	if (db_select(DBName) == False)
 	{
   	if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     		return M_CM_DB_NOTOPEN;
   	else
     		return apiRC;
 	}
    printf("-- trace sIassured[%s]\n ", sIassured);
    printf("-- trace   sIroute[%s]\n ", sIroute);
    
    strcpy(fexist,"0");    strcpy(aemail," ");  strcpy(nftp_memo," ");
    strcpy(freceipt," ");  strcpy(femail," ");  strcpy(fftp," ");
    
	sprintf_s(sTmpSQL,sizeof sTmpSQL, "select '1', aemail, nftp_memo,freceipt, femail, fftp \
                        from ca_eply_mail \
                       where iassured = '%s' and '%s' matches trim(iroute)||'*' \
                         and (dexpire is null or dexpire > today) ",sIassured,trim(sIroute));

	printf("sTmpSQL=[%s]\n",sTmpSQL);
 
	$PREPARE prep_get_1 FROM $sTmpSQL;
    $EXECUTE prep_get_1 INTO $fexist, $aemail, $nftp_memo,$freceipt, $femail, $fftp;
  
 	cm_buf_init(ReplyBuf);

    cm_buf_put("%l %s %s %s %s %s %s ", 
  		M_CM_OK, fexist ,aemail, nftp_memo,freceipt, femail, fftp);

    tmp_len = cm_buf_len(ReplyBuf);

     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* for car219 */
static long Get_PlyInfo( reply )
serverReply reply;
{
     $char   DBName[5],sApHome[50],filename[101],logname[101],txtfile[101];     
     int     count_db=0,tmp_len, rc, i, stmt_len, iCount ,ttlen;
     $char   stmt[2048], cmd_str[2048],fPlyCard[2],sPlyCard[21],sPlyCardEmail[21];
     $char   icard[21],ipolicy[21],itag[CA_TAG_NUM],iofficer[11],nofficer[11],nleader[11],iemail_emp[51],email_ply_card[51];	
     DBinfo  *list;
     FILE *fp;
   
     $WHENEVER SQLERROR GOTO errexit;

     cm_buf_get("%s %s %s", DBName, txtfile, fPlyCard);

 	 if (db_select(DBName) == False)
 	 {
   	    if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
     		return M_CM_DB_NOTOPEN;
   	    else
     		return apiRC;
 	 } 
     
     rc = getApHome(sApHome);
     if (rc < 0)
     {
        if(exitsub(reply,M_CM_READ_CONFIG_ERR) == True)
           return M_CM_READ_CONFIG_ERR;
        else
           return apiRC;
     }
  
  
     $EXECUTE IMMEDIATE "DROP TABLE IF EXISTS tmpPlyCard";
     $CREATE TEMP table tmpPlyCard
     (
        ipolicy 	   char(20)
     )with no log;
     $truncate table tmpPlyCard;
              
     /* ��r�� => temp table */
     printf("sApHome[%s]\n",sApHome);
     printf("txtfile[%s]\n",txtfile);
     sprintf_s(filename,sizeof filename,"%s/dat/car/%s",sApHome,txtfile);     
     printf("filename[%s]\n",filename);

	if( (fp=fopen(filename, "r")) == NULL)
	{
         if(exitsub(reply, M_CM_OPEN_FILE_FAIL) == True)
             return  M_CM_OPEN_FILE_FAIL;
         else
             return apiRC;
	}
	else
	{		     
		while(fscanf(fp,"%s\t",sPlyCard) != EOF)
		{
			printf("[%s]\t\n",sPlyCard);                 
      		$insert into tmpPlyCard (ipolicy) values ($sPlyCard);
		}
    }
         
 
     printf("-- CREATE tempPly ...\n ");
     $EXECUTE IMMEDIATE "DROP TABLE IF EXISTS tempPly";
     $CREATE TEMP table tempPly
     (
        ipolicy 	   char(20),			         
        icard          char(20),			         
        itag		   char(12),			         
        iofficer	   char(10),			         
		nofficer	   char(10),			         
        nleader 	   char(10),			         
        emp_email      varchar(50),			         /* �޲z�Hemail   */
        email_ply_card varchar(50)			         /* �Q�h��email */         
     )with no log;
     $truncate table tempPly;
     
     printf("-- get_db_list ...\n ");    
     /* get plydata(00~70) by tmpPlyCard => into tempPly  */
     if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
     {
         if(exitsub(reply,M_CM_NOT_DBLIST) == True)
            return M_CM_NOT_DBLIST;
         else
            return apiRC;
     }      

     if (fPlyCard[0]=='0')
     {	
         strcpy(sPlyCard      , "a.icard"       );
         strcpy(sPlyCardEmail , "a.iemail"      );         
     }
     else
     {
     	 strcpy(sPlyCard      , "a.ipolicy"     );	
     	 strcpy(sPlyCardEmail , "b.aemail_eply" );
     }	

     $DECLARE cur123  CURSOR FOR select ipolicy from tmpPlyCard ;
     $OPEN    cur123  ;     
     while(1)
     {
        $FETCH cur123 INTO $icard;
        if(SQLCODE == SQLNOTFOUND)   break;
     	printf("-- trace icard[%s]\n ",icard);
     }	
     $close cur123;
     $free cur123;
         	          
     printf("-- into tempPly ...\n ");    	 
	 for (i=0;i<count_db;i++)
     {
      	  sprintf_s( stmt, sizeof stmt,
      	     "insert into tempPly \
      	      select a.ipolicy, a.icard, a.itag, b.iofficer, c.nname, \
                      (SELECT nname FROM officer WHERE iofficer = c.ileader ), \
                      (SELECT trim(email)||'@tmnewa.com.tw' FROM personal:asempl WHERE empl_no = c.ileader ) , \
                      %s \
                from %s:policy a, %s:ply_relation b ,officer c \
               where a.ipolicy = b.ipolicy and b.iofficer = c.iofficer \
                 and %s in (select ipolicy from tmpPlyCard)", 
                 sPlyCardEmail, list[i].dbname, list[i].dbname, sPlyCard);

          printf("stmt[%s]\n", stmt);
          $PREPARE prep_p FROM $stmt;
          $EXECUTE prep_p;
     }
          
     /* get tempPly record => put to client   */     	
     cm_buf_init(ReplyBuf);
     cm_buf_res_msg();
     cm_buf_res_count();
     iCount=0;
    
     sprintf_s( stmt,sizeof stmt,"select ipolicy, icard, itag, iofficer, nofficer, nleader, email_ply_card , emp_email\
                      from tempPly order by nleader");     
     printf("-- stmt",stmt);
	 $PREPARE prePly FROM $stmt;
	 $DECLARE curPly CURSOR FOR prePly;
     $OPEN curPly;
     for(;;)
     {
        $FETCH curPly 
          INTO $ipolicy,$icard,$itag,$iofficer,$nofficer,$nleader,$email_ply_card,$iemail_emp;
        if( SQLCODE == SQLNOTFOUND) break;
   
        printf("-- trace iCount[%d]\n ",iCount);
        printf("-- trace icard[%s]\n ",icard);
        printf("-- trace email_ply_card[%s]\n ",email_ply_card);
        iCount++;            
        cm_buf_put("%s %s %s %s %s %s %s %s",
                   ipolicy,icard,itag,iofficer,nofficer,nleader,email_ply_card,iemail_emp);
        tmp_len = cm_buf_len(ReplyBuf);
        printf("-- trace tmp_len[%ld]\n ",tmp_len); 
        if (tmp_len>39000)
        {   /* if data length >= 3K/4K, then multiple send */
        	 printf("-- trace tmp_len[%ld]\n ",tmp_len);
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(iCount);
            if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
            {
                $CLOSE curPly;
                $FREE  curPly;
                return apiRC;
            }
            ttlen=ttlen+tmp_len;
            iCount=0;
            cm_buf_init(ReplyBuf);
            cm_buf_res_msg();           /* reserve for msg_code and count */
            cm_buf_res_count();
        }
        /*
        if (ttlen+tmp_len>=300000)
        {                        
            $CLOSE curPly;
            $FREE  curPly;
            printf("-- trace ttlen+tmp_len[%ld]\n ",ttlen+tmp_len);
            cm_buf_init(ReplyBuf);
            cm_buf_put("%l",M_CM_OUT_SPACE);
            tmp_len = cm_buf_len(ReplyBuf);
            if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
            {
                return apiRC;
            }
            return M_CM_OK;                   
        }
        */
     }
     $CLOSE curPly;
     $FREE  curPly;

	 if (iCount > 0)   /* break out, at least one record is selected */
	 {
	    cm_buf_init(ReplyBuf);
	    cm_buf_put_msg(M_CM_OK);
	    cm_buf_put_count(iCount);
	    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
	      return apiRC;
	    return api_OKComplete;
	 }
	 else            /* break out, not any row is found */
	 {
	    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
	      return M_CM_NOT_FOUND;                               /*?*/
	    else
	      return apiRC;
	 }

errexit:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/* 1060817004-C1���o�q�lñ�p���y��T */
long get_iscan_no(reply)
serverReply reply;
{
    $char DBName[5], iscan_no[26];/* 1101018008-SC1-�d����-�q�lñ�ݱ��y�s������X�W��25�X*/
    $int  tmp_len;
    $long lFstatus;
    $char   equipdecode[201];
    $char ca_nequipment[31];          /* ���I���O */
    $char ca_isurvey_num[21];         /* �ɨ����渹 */
    $char ca_ibound_num[21];          /* ���O���渹 */
    $char ca_ixxcard[21];             /* �P�~�Ҹ� */
    $char ca_icard[21];               /* �j���Ҹ� */
    $char ca_icard2[21];              /* ���N�d�� */
    $char ca_nassured_deputy[21];     /* �Q�O�I�H�k�H�N�� */
    $char ca_aassured_zip[CA_ZIP];         /* �Q�O�I�H�l���ϸ� *//* 1090525004-SC1-�]�y��-�s���l���ϸ�3+3   ZIP_CODE 5+1->CA_ZIP 6+1*/
    $char ca_aassured[101];           /* �Q�O�I�H�a�} */
    $char ca_tassured_day[21];        /* �Q�O�I�H�q��(��) */
    $char ca_tassured_night[21];      /* �Q�O�I�H�q��(�]) */
    $char ca_tassured_mobile[21];     /* �Q�O�I�H��ʹq�� */
    $char ca_aassured_email[51];      /* �Q�O�I�H�q�l�H�c */
    $char ca_napplicant_deputy[21];   /* �n�O�H�k�H�N�� */
    $char ca_aapplicant_zip[CA_ZIP];       /* �n�O�H�l���ϸ� *//* 1090525004-SC1-�]�y��-�s���l���ϸ�3+3   ZIP_CODE 5+1->CA_ZIP 6+1*/
    $char ca_aapplicant[101];         /* �n�O�H�a�} */
    $char ca_tapplicant_day[21];      /* �n�O�H�p���q��(��) */
    $char ca_napplicant_relation[41]; /* �n�Q�O�I�H���Y */
    $char ca_nuser[19];               /* �ϥΤH */
    $char ca_ipro_year[5];            /* �s�y�~�� */
    $int  ca_qpro_month;              /* �s�y��� */
    $char ca_ibrand[9];               /* �t�P���� */
    $double  ca_qcylinder;            /* �Ʈ�q *//* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
    $char ca_ibody[CA_BODY_NUM];               /* ������ */
    $double ca_qpt;                   /* �Ӹ��H��/���� */
    $double ca_mequipment;            /* �t�ƪ��B */
    $char ca_ibig_office[11];         /* ������~�� */
    $char ca_introducer[11];          /* �q�����u */
    $char ca_feply[2];                /* �q�l�O����O */
    $char ca_aemail_eply[51];         /* �q�l�O��email */
    $char ca_ientry[11];              /* ���I��J�H�� */
    /* 1060817004_SC4_�s�W�q�lñ�p�����{��-�W�[��� */
    $char ca_dassured_birth[11];      /* �Q�O�I�H�ͤ� */
    $char ca_dapplicant_birth[11];    /* �n�O�H�ͤ� */
    $char ca_tapplicant_mobile[21];   /* �Q�O�I�H��ʹq�� */
    $char ca_dissue[11];              /* �o�Ӥ�� */
    $char ca_fecard[2];               /* �j��q�l���ҵ��O */
    
    $char cm_iquote[21];              /*  �����渹  */
    $char cm_fc1_only[2];             /*  ��j���O  */
    $char cm_fcase[2];                /*  ��O  */
    $char cm_ipolicy[21];             /*  �O�渹�X �j���I */
    $char cm_iendorse[21];            /*  ��渹�X  */
    $char cm_iins_newtype[2];         /*  �I�O  */
    $char cm_iassured[11];            /*  �Q�O�I�HID  */
    $char cm_nassured[101];           /*  �Q�O�I�H  */
    $char cm_iapplicant[11];          /*  �n�O�I�HID  */
    $char cm_napplicant[101];         /*  �n�O�I�H  */
    $char cm_isales[11];              /*  �q���~�ȭ�  */
    $char cm_iofficer[11];            /*  �g��N�� �j���I */
    $char cm_ileader[11];             /*  �޲z�H �j���I */
    $char cm_iroute[21];              /*  �q���N��  */
    $char cm_itag[13];                /*  �P�Ӹ��X  */
    $char cm_iengine[41];  /*  ������  */
    $char cm_iunder[11];              /*  �֫O�H��  */
    $char cm_dunder[11];              /*  �֫O���  */
    $char cm_dins_bgn[11];            /*  �_�O��� �j���I */
    $char cm_dins_end[11];            /*  ������ �j���I */
    $char cm_dply_edr[11];            /*  ñ���� �j���I */
    $char cm_fstatus[2];              /*  ���A �j���I */
    $char cm_iroute_accept[41];       /*  �q�����z�s��  */
    $char cm_ipolicy2[21];            /*  �O�渹�X2 ���N�I */
    $char cm_iofficer2[11];           /*  �g��N��2 ���N�I */
    $char cm_ileader2[11];            /*  �޲z�H2 ���N�I */
    $char cm_dins_bgn2[11];           /*  �_�O���2 ���N�I*/
    $char cm_dins_end2[11];           /*  ������2 ���N�I */
    $char cm_dply_edr2[11];           /*  ñ����2 ���N�I*/
    $char cm_fstatus2[2];             /*  ���A2 ���N�I*/
    $char cm_fagency[2];              /*  �O�g�Nñ�p���O */
    $char cm_fappend[2];              /*  ����f�� */
    $char cm_dappend[11];             /*  ����f�֤��  */
    $char cm_icreate[21];             /*  ���ɤH��/�{��  */
    $char cm_dcreate[21];             /*  ���ɮɶ�  */
    $char cm_iupdate[21];             /*  ���ʤH��/�{��  */
    $char cm_dupdate[21];             /*  ���ʮɶ�  */
     /* 1060817004_SC4_�s�W�q�lñ�p�����{��-�W�[��� */
    $char cm_foccup_assured[2];       /*  �Q�O�I�H¾/��~�O  */
    $char cm_foccup_applicant[2];     /*  �n�O�H¾/��~�O  */
    $char sTmpcylinder[9];            /*  1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
    $char ca_feterms[2];              /*  1100419003-���I�O�����QR Code�q�l��   �ȥ��O��u�q�l���ڡv*/
    $char ca_tmobile_eply[21];        /*     */
    $char ca_aapplicant_email[51];    /*  1100913004-SC1-���I�q�lñ�p�s�W�n�O�Hemail���-�n�O�HE-Mail*/
    $char cm_ftrans_third[2];         /*  �~����Ʀ@�ɵ��O (1111003006_SC1_�q�lñ�p���x�s�W����[�~����Ʀ@��]�ﶵ���O)*/
    cm_buf_get("%s", DBName);
    cm_buf_get("%s ",iscan_no);
    
    if (db_select(DBName) == False)
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    $WHENEVER SQLERROR GOTO errexit;
    printf("get_iscan_no iscan_no=[%s]\n",iscan_no); 
    
    
    lFstatus = -1; 
   $select a.iquote,a.fc1_only,a.fcase,a.ipolicy,a.iendorse,a.iins_newtype,
           a.iassured,a.nassured,a.foccup_assured,a.iapplicant,a.napplicant,a.foccup_applicant,a.isales,a.iofficer,
           a.ileader,a.iroute,a.itag,a.iengine,a.iunder,a.dunder,a.dins_bgn,a.dins_end,
           a.dply_edr,a.fstatus,a.iroute_accept,a.ipolicy2,a.iofficer2,a.ileader2,
           a.dins_bgn2,a.dins_end2,a.dply_edr2,a.fstatus2,a.fagency,a.fappend,a.dappend,
           a.icreate,a.dcreate,a.iupdate,a.dupdate,
           (case when CHARINDEX('9',a.fstatus)+CHARINDEX('9',a.fstatus2) >0 then -1 
                 when (CHARINDEX('1',a.fstatus)+CHARINDEX('1',a.fstatus2)
                     +CHARINDEX('2',a.fstatus)+CHARINDEX('2',a.fstatus2)
                     +CHARINDEX('3',a.fstatus)+CHARINDEX('3',a.fstatus2)) >0 then 1 ELSE  0 end),
           b.nequipment,b.isurvey_num,b.ibound_num,b.ixxcard,
           b.icard,b.icard2,b.dassured_dbirth,b.nassured_deputy,b.aassured_zip,b.aassured,
           b.tassured_day,b.tassured_night,b.tassured_mobile,b.aassured_email,b.dapplicant_birth,
           b.napplicant_deputy,b.aapplicant_zip,b.aapplicant,b.tapplicant_day,b.tapplicant_mobile,
           b.napplicant_relation,b.nuser,b.dissue,b.ipro_year,b.qpro_month,b.ibrand,b.qcylinder,
           b.ibody,b.qpt,b.mequipment,b.ibig_office,b.introducer,b.feply,b.aemail_eply,b.fecard,
           b.ientry,b.feterms,b.tmobile_eply,nvl(b.aapplicant_email,''),a.ftrans_third
      INTO $cm_iquote,$cm_fc1_only,$cm_fcase,$cm_ipolicy,$cm_iendorse,$cm_iins_newtype,
           $cm_iassured,$cm_nassured,$cm_foccup_assured,$cm_iapplicant,$cm_napplicant,$cm_foccup_applicant,$cm_isales,$cm_iofficer,
           $cm_ileader,$cm_iroute,$cm_itag,$cm_iengine,$cm_iunder,$cm_dunder,$cm_dins_bgn,$cm_dins_end,
           $cm_dply_edr,$cm_fstatus,$cm_iroute_accept,$cm_ipolicy2,$cm_iofficer2,$cm_ileader2,
           $cm_dins_bgn2,$cm_dins_end2,$cm_dply_edr2,$cm_fstatus2,$cm_fagency,$cm_fappend,$cm_dappend,
           $cm_icreate,$cm_dcreate,$cm_iupdate,$cm_dupdate,
           $lFstatus,
           $ca_nequipment,$ca_isurvey_num,$ca_ibound_num,$ca_ixxcard,
           $ca_icard,$ca_icard2,$ca_dassured_birth,$ca_nassured_deputy,$ca_aassured_zip,$ca_aassured,
           $ca_tassured_day,$ca_tassured_night,$ca_tassured_mobile,$ca_aassured_email,$ca_dapplicant_birth,
           $ca_napplicant_deputy,$ca_aapplicant_zip,$ca_aapplicant,$ca_tapplicant_day,$ca_tapplicant_mobile,
           $ca_napplicant_relation,$ca_nuser,$ca_dissue,$ca_ipro_year,$ca_qpro_month,$ca_ibrand,$ca_qcylinder,
           $ca_ibody,$ca_qpt,$ca_mequipment,$ca_ibig_office,$ca_introducer,$ca_feply,$ca_aemail_eply,$ca_fecard,
           $ca_ientry,$ca_feterms,$ca_tmobile_eply,$ca_aapplicant_email,
           $cm_ftrans_third
      from cm_esign_data a,ca_esign_data b
     where a.iscan_no = $iscan_no and a.iins_newtype='C'
       and a.iscan_no = b.iscan_no;
    if( SQLCODE == SQLNOTFOUND)
    {
        strcpy(cm_iquote," ");
        strcpy(cm_fc1_only," ");                        strcpy(cm_fcase," ");
        strcpy(cm_ipolicy," ");                         strcpy(cm_iendorse," ");
        strcpy(cm_iins_newtype," ");                    strcpy(cm_iassured," ");
        strcpy(cm_nassured," ");                        strcpy(cm_iapplicant," ");
        strcpy(cm_napplicant," ");                      strcpy(cm_isales," ");
        strcpy(cm_iofficer," ");                        strcpy(cm_ileader," ");
        strcpy(cm_iroute," ");                          strcpy(cm_itag," ");
        strcpy(cm_iengine," ");                         strcpy(cm_iunder," ");
        strcpy(cm_dunder," ");                          strcpy(cm_dins_bgn," ");
        strcpy(cm_dins_end," ");                        strcpy(cm_dply_edr," ");
        strcpy(cm_fstatus," ");                         strcpy(cm_iroute_accept," ");
        strcpy(cm_ipolicy2," ");                        strcpy(cm_iofficer2," ");
        strcpy(cm_ileader2," ");                        strcpy(cm_dins_bgn2," ");
        strcpy(cm_dins_end2," ");                       strcpy(cm_dply_edr2," ");
        strcpy(cm_fstatus2," ");                        strcpy(cm_fagency," ");
        strcpy(cm_fappend," ");                         strcpy(cm_dappend," ");
        strcpy(cm_icreate," ");                         strcpy(cm_dcreate," ");
        strcpy(cm_iupdate," ");                         strcpy(cm_dupdate," ");
        strcpy(cm_foccup_assured," ");                  strcpy(cm_foccup_applicant," ");
        
        
        strcpy(ca_nequipment," ");
        strcpy(ca_isurvey_num," ");                     strcpy(ca_ibound_num," ");
        strcpy(ca_ixxcard," ");                         strcpy(ca_icard," ");
        strcpy(ca_icard2," ");                          strcpy(ca_nassured_deputy," ");
        strcpy(ca_aassured_zip," ");                    strcpy(ca_aassured," ");
        strcpy(ca_tassured_day," ");                    strcpy(ca_tassured_night," ");
        strcpy(ca_tassured_mobile," ");                 strcpy(ca_aassured_email," ");
        strcpy(ca_napplicant_deputy," ");               strcpy(ca_aapplicant_zip," ");
        strcpy(ca_aapplicant," ");                      strcpy(ca_tapplicant_day," ");
        strcpy(ca_napplicant_relation," ");             strcpy(ca_nuser," ");
        strcpy(ca_ipro_year," ");
        ca_qpro_month =0;
        strcpy(ca_ibrand," ");
        ca_qcylinder =0.0;
        strcpy(ca_ibody," ");
        ca_qpt =0;
        ca_mequipment =0;
        strcpy(ca_ibig_office," ");                     strcpy(ca_introducer," ");
        strcpy(ca_feply," ");                           strcpy(ca_aemail_eply," ");
        strcpy(ca_ientry," ");                          
        lFstatus = -1;
        strcpy(ca_dassured_birth," ");                  strcpy(ca_dapplicant_birth," ");
        strcpy(ca_tapplicant_mobile," ");               strcpy(ca_dissue," ");   
        strcpy(ca_fecard," ");   
        strcpy(ca_feterms ," ");
        strcpy(ca_tmobile_eply ," ");
        strcpy(ca_aapplicant_email," ");
        strcpy(cm_ftrans_third," ");
    }
    
    /* �j����N�X�֬�  -1�G�d�L���(�t9:�h��)�B0�G���ӱ��y�Ǹ��B1:�w�X��(1:�w�X�� 2:�w�鵲 3:�w�^��,�ư�0:���X�� ) */
    strcpy(equipdecode,equip_get(ca_nequipment));
    printf("ca_nequipment[%s]\nequipdecode[%s]\n",ca_nequipment,equipdecode);
    
    strcpy(ca_dassured_birth,cm_from_infdate_100(ca_dassured_birth));
    strcpy(ca_dapplicant_birth,cm_from_infdate_100(ca_dapplicant_birth));
    strcpy(ca_dissue,cm_from_infdate_100(ca_dissue));
    
    /* 1100419003-���I�O�����QR Code�q�l��   feterms
       �t�X�Ʀ�A�Ȭ�t�Ӷi�סA�{���վ㬰�����I�q�lñ�p����ɪ��ȥ��O��u�q�l���ڡv���O��쬰�ťծɡA
       �H�U��������O�Ȭ��ǡF�������ťծɡA�hcar301-client�e����ƥH���I�q�lñ�p����ɵ��O�л\
    */
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %l ",M_CM_OK, lFstatus);
    
    cm_buf_put("%s %s %s %s %s",cm_iquote,  cm_fc1_only,  cm_fcase,  cm_ipolicy,  cm_iendorse);
    cm_buf_put("%s %s %s %s %s %s %s",cm_iins_newtype,  cm_iassured,  cm_nassured, cm_foccup_assured, cm_iapplicant,  cm_napplicant, cm_foccup_applicant);
    cm_buf_put("%s %s %s %s %s",cm_isales,  cm_iofficer,  cm_ileader,  cm_iroute,  cm_itag);
    cm_buf_put("%s %s %s %s %s",cm_iengine,  cm_iunder,  cm_dunder,  cm_dins_bgn,  cm_dins_end);
    cm_buf_put("%s %s %s %s %s",cm_dply_edr,  cm_fstatus,  cm_iroute_accept,  cm_ipolicy2,  cm_iofficer2);
    cm_buf_put("%s %s %s %s %s",cm_ileader2,  cm_dins_bgn2,  cm_dins_end2,  cm_dply_edr2,  cm_fstatus2);
    cm_buf_put("%s %s %s ",cm_fagency,  cm_fappend,  cm_dappend);
    /*cm_buf_put("%s %s %s %s ",cm_icreate,cm_dcreate,  cm_iupdate,cm_dupdate);*/

    cm_buf_put("%s %s %s %s %s",equipdecode,  ca_isurvey_num,  ca_ibound_num,  ca_ixxcard,  ca_icard);
    cm_buf_put("%s %s %s %s %s %s",ca_icard2, ca_dassured_birth, ca_nassured_deputy,  ca_aassured_zip,  ca_aassured,  ca_tassured_day);
    cm_buf_put("%s %s %s %s %s %s",ca_tassured_night,  ca_tassured_mobile,  ca_aassured_email, ca_dapplicant_birth, ca_napplicant_deputy,  ca_aapplicant_zip);
    cm_buf_put("%s %s %s %s %s %s",ca_aapplicant,  ca_tapplicant_day, ca_tapplicant_mobile, ca_napplicant_relation,  ca_nuser, ca_dissue);
    strcpy(sTmpcylinder,"");/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
    sprintf_s(sTmpcylinder,sizeof sTmpcylinder,"%8.2f",ca_qcylinder);
    strcpy(sTmpcylinder,trim(sTmpcylinder));
    cm_buf_put("%s %d %s %s %s",ca_ipro_year,  ca_qpro_month,  ca_ibrand,  sTmpcylinder,  ca_ibody);/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/
    cm_buf_put("%f %f %s %s %s",ca_qpt,  ca_mequipment,  ca_ibig_office,  ca_introducer,  ca_feply);
    cm_buf_put("%s %s %s %s %s",ca_feterms ,ca_aemail_eply, ca_fecard, ca_ientry, ca_tmobile_eply );
    cm_buf_put("%s ",ca_aapplicant_email);  /*1100913004-SC1-���I�q�lñ�p�s�W�n�O�Hemail���*/
    cm_buf_put("%s ",cm_ftrans_third); /*  �~����Ʀ@�ɵ��O (1111003006_SC1_�q�lñ�p���x�s�W����[�~����Ʀ@��]�ﶵ���O)*/
    
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
      return apiRC;
    else
      return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* 1061012002_C2_ISID�PRBA�ק�@�~ */
long get_leader_info(reply)
serverReply reply;
{
    $char   DBName[5];
    $char   iofficer[EMPLOYEE_ID],ileader[EMPLOYEE_ID],nleader[11],iquota_leader[7],ibranch_leader[3],iquota_grp[7];      
    int     tmp_len;
    long    rc;
    
    cm_buf_get("%s %s", DBName, iofficer);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }
    printf("get_leader_info:iofficer[%s]\n",iofficer);
    
    
    /* bis9901141�Ҧ����󳣵����q��,�ҥH�q�����O(froute)�אּ�@�ߧ�Y */
    /* 2018/06/12�g��N�����ΨS���Y�A�޲z�H���n���ΧY�i */
    strcpy(ileader," ");       strcpy(nleader," "); 
    strcpy(iquota_leader," "); strcpy(ibranch_leader," ");
    
	$SELECT iofficer, nname, iquota, ibranch 
	   INTO $ileader , $nleader, $iquota_leader, $ibranch_leader
	   FROM officer
	  WHERE iofficer in (
		 	SELECT ileader       
			  FROM officer
			 WHERE iofficer = $iofficer 
	       ) 
	   AND (dexpire IS NULL OR dexpire>today);
    if(SQLCODE==SQLNOTFOUND)
    {
        /* 1070621015-SC1-�]�g��N�����ξɭPISID�iĵ�L�q���H��
           �Y�޲z�H�N�����ΡA�h����޲z�H���ݳ�줧�D�� */
		$SELECT iofficer, nname, iquota, ibranch 
		   INTO $ileader , $nleader, $iquota_leader, $ibranch_leader
		   FROM officer
		  WHERE iofficer = (
				SELECT resp_name FROM personal:unitid2ef 
				 WHERE code_no = (
				       SELECT iquota FROM officer
				        WHERE iofficer = (SELECT ileader       
							                FROM officer
							               WHERE iofficer = $iofficer 
							             )  
				                 )
	                       );
        if(SQLCODE==SQLNOTFOUND)
        {
	        if(exitsub(reply,M_CMN_NOFFICER) == True)
	            return M_CA_NOT_ILEADER;
	        else
	            return apiRC;
        }
    }

    strcpy(iquota_grp," ");    /* ���n��� */
	$select c.iquota_grp INTO $iquota_grp
	   from officer a, sa_branch_type b, branch c, sa_branch_type d
	  where a.iofficer   = a.ileader
	    and a.iquota     = b.ibranch and a.dexpire is null
	    and a.iapp_unit != b.iply_branch
	    and a.iapp_unit  = c.ibranch
	    and c.iquota_grp = d.ibranch 
	    AND a.iofficer   = $ileader;
	    	    
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l", M_CM_OK);
    cm_buf_put("%s %s %s %s %s", ileader, nleader, iquota_leader, ibranch_leader, iquota_grp);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/* 1061012002_C2_ISID�PRBA�ק�@�~ */
/* 1101124011_SC1_RBA�ק�@�~ �W�[�ǤJ��a�W�� */
/*  iref_num1,iref_num2,iref_num3 : �d��ISID�ɨϥΤ�Key �� */
/*  fkind : 2:�ӫO  */
long call_cm_preview_rba(reply)
serverReply reply;
{
    $char   DBName[5];
    $char   fkind[2],iref[21],iply1[21],iply2[21],iedr[21],iref_num1[21],iref_num2[21],iref_num3[21];
    $char   iExec_num[21];
    $char   iassured[13],nassured[121],fassured[2];
    $char   iassured_cntry[2],nassured_cntry[51],foccup[2],noccup[6];
    $char   iapplicant[13],napplicant[121],fapplicant[2];
    $char   iapplicant_cntry[2],napplicant_cntry[51],applicant_foccup[2],applicant_noccup[6];
    $char   iroute[21], bzfrom[3]; 
    $char   rba_HG_ass[2],rba_HG_app[2],rba_dbirth[11],rba_dbirth_appl[11],stmt_rba[1024];
    $char   iassured_cntry_rba[2],iapplicant_cntry_rba[2],foccup_rba[2],applicant_foccup_rba[2],noccup_rba[5],applicant_noccup_rba[6];
    $long   tot_prem;
    $date   dbirth,dbirth_appl; 
	
    int     tmp_len;
    long    rc;

    cm_buf_get("%s %s %s %s %s %s %s %s %s", DBName,fkind,iref,iply1,iply2,iedr,iref_num1,iref_num2,iref_num3);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }
    
    rba_HG_ass[0] = '\0';
    rba_HG_app[0] = '\0';
    
    /*1101124011_SC1_RBA�ק�@�~  �W�[4.5���������O�B�W�[�ǤJ���y�O	
    if (fkind[0] == '2') /*  �ӫO => �ϥ� iply1 (�O�渹)  */
    {
    	strcpy(iExec_num, trim(iply1));
    	
    	$select a.iassured, a.nassured, a.fassured, a.dbirth, 
    	        a.iassured_cntry, a.nassured_cntry, a.foccup, a.noccup, 
                a.iapplicant, a.napplicant, a.fapplicant, a.dbirth_appl, 
                a.iapplicant_cntry, a.napplicant_cntry, a.applicant_foccup, a.applicant_noccup, 
                a.iroute, b.bzfrom, (b.mdmg_prem + b.mlia_prem)
           into $iassured, $nassured, $fassured, $dbirth, 
                $iassured_cntry, $nassured_cntry, $foccup, $noccup, 
                $iapplicant, $napplicant, $fapplicant, $dbirth_appl, 
                $iapplicant_cntry, $napplicant_cntry, $applicant_foccup, $applicant_noccup, 
                $iroute, $bzfrom, $tot_prem   
           from policy a, ply_relation b
    	  where a.ipolicy = b.ipolicy
    	    and a.ipolicy = $iExec_num;
	    if(SQLCODE==SQLNOTFOUND)
	    {
	        if(exitsub(reply,M_CA_NPOLICY) == True)
	            return M_CA_NPOLICY;
	        else
	            return apiRC;
	    }

	    strcpy(iassured_cntry,trim(iassured_cntry));
	    strcpy(iapplicant_cntry,trim(iapplicant_cntry));
	 	    	 
	    /* �X��ɰ����I����(cm_preview_rba)�A�Y�������I�h�g�Jcm_risk_preview��ca_log */
	    printf("iassured[%s] nassured[%s] fassured[%s] dbirth[%d] iassured_cntry[%s]\n",iassured,nassured,fassured,dbirth,iassured_cntry);
	    printf("iapplicant[%s] napplicant[%s] fapplicant[%s] dbirth_appl[%d] iapplicant_cntry[%s]\n",iapplicant,napplicant,fapplicant,dbirth,iapplicant_cntry);
	    printf("bzfrom[%s] \n",bzfrom);
	    printf("iroute[%s]\n",iroute);
	    printf("tot_prem[%ld] \n",tot_prem);
	    printf("foccup[%s] noccup[%s]\n",foccup,noccup);
	    printf("applicant_foccup[%s] applicant_noccup[%s]\n",applicant_foccup,applicant_noccup);
	     
	    /* �P�_�k�H�ͤ�O�_��NULL */
	    if(dbirth == DATENULL) strcpy(rba_dbirth," ");
	    else strcpy(rba_dbirth,cm_edate_str(dbirth));
	    if(dbirth_appl == DATENULL) strcpy(rba_dbirth_appl," ");
	    else strcpy(rba_dbirth_appl,cm_edate_str(dbirth_appl));
	    printf("dbirth[%s]\n",rba_dbirth);
	    printf("dbirth[%s]\n",rba_dbirth_appl);
	    
	    if(strncmp(iassured_cntry,"1",1)==0) strcpy(iassured_cntry_rba,"Y");
	    else if(strncmp(iassured_cntry,"4",1)==0) strcpy(iassured_cntry_rba,"M");
	    else if(strncmp(iassured_cntry,"5",1)==0) strcpy(iassured_cntry_rba,"S");
	    else strcpy(iassured_cntry_rba,"N");
	    if(strncmp(iapplicant_cntry,"1",1)==0) strcpy(iapplicant_cntry_rba,"Y");
	    else if(strncmp(iapplicant_cntry,"4",1)==0) strcpy(iapplicant_cntry_rba,"M");
	    else if(strncmp(iapplicant_cntry,"5",1)==0) strcpy(iapplicant_cntry_rba,"S");
	    else strcpy(iapplicant_cntry_rba,"N");
	    printf("iassured_cntry_rba[%s] iapplicant_cntry_rba[%s]\n",iassured_cntry_rba,iapplicant_cntry_rba);
	    
	    strcpy(foccup_rba,trim(foccup));
	    strcpy(applicant_foccup_rba,trim(applicant_foccup));
	    strcpy(noccup_rba,trim(noccup));
	    strcpy(applicant_noccup_rba,trim(applicant_noccup));
	    
	    /* ¾/��~���ť��ˮ֮ɰe Y��999 */
	    if(strlen(foccup_rba)==0) strcpy(foccup_rba,"Y");
	    if(strlen(applicant_foccup_rba)==0) strcpy(applicant_foccup_rba,"Y");
	    if(strlen(noccup_rba)==0) strcpy(noccup_rba,"999");
	    if(strlen(applicant_noccup_rba)==0) strcpy(applicant_noccup_rba,"999");
	    printf("foccup_rba[%s] noccup_rba[%s]\n",foccup_rba,noccup_rba);
	    printf("applicant_foccup_rba[%s] applicant_noccup_rba[%s]\n",applicant_foccup_rba,applicant_noccup_rba);
	    
	    /*
	    sprintf_s(stmt_rba,sizeof stmt_rba,"insert into ca_log values('car301','O',?,'A','�����I�W��','%s',current)",userid);
	    $prepare rba_chk from $stmt_rba;
	    printf("stmt_rba[%s]\n",stmt_rba);
	    */
	    
	    /* cm_preview_rba() => cmfun2s.ec */
	    if(strncmp(iassured,iapplicant,10) == 0)
	    {
	    	printf("-- trace 3\n ");
	    	/*�n�Q�O�H�ۦP�u�e�@���i�J�����Y�i*/                               
	    	rc = cm_preview_rba("3"," ",iExec_num," "," ",iassured,nassured,fassured,rba_dbirth,iassured_cntry_rba,bzfrom,iroute,tot_prem,foccup_rba,noccup_rba,iref_num1,iref_num2,iref_num3,rba_HG_ass,nassured_cntry);
	    	/*
	    	if (rc != SUCCESS)
	    	{
				return rc;
			}
			if(strncmp(rba_HG_ass,"Y",1) == 0) $execute rba_chk using $iExec_num;*/
	    }
	    else
	    {
	    	printf("-- trace 1\n "); 
	    	/*�n�Q�O�H���P�H�ݤ��O���� 1.�n�O�H 2.�Q�O�H*/
	    	rc = cm_preview_rba("1"," ",iExec_num," "," ",iapplicant,napplicant,fapplicant,rba_dbirth_appl,iapplicant_cntry_rba,bzfrom,iroute,tot_prem,applicant_foccup_rba,applicant_noccup_rba,iref_num1,iref_num2,iref_num3,rba_HG_app,napplicant_cntry);
	    	/*
	    	if (rc != SUCCESS)
	    	{
	    		return rc;
		}
		if(strncmp(rba_HG_app,"Y",1) == 0) $execute rba_chk using $iExec_num;*/
		
		printf("-- trace 2\n "); 
	    	rc = cm_preview_rba("2"," ",iExec_num," "," ",iassured,nassured,fassured,rba_dbirth,iassured_cntry_rba,bzfrom,iroute,tot_prem,foccup_rba,noccup_rba,iref_num1,iref_num2,iref_num3,rba_HG_ass,nassured_cntry);
	    	/*
	   	if (rc != SUCCESS)
	    	{ 
			return rc;
		}
		if(strncmp(rba_HG_ass,"Y",1) == 0 && strncmp(rba_HG_app,"Y",1) != 0) $execute rba_chk using $iExec_num;*/
	    }
    }
    printf("rba_HG_ass[%s] rba_HG_app[%s]\n",rba_HG_ass,rba_HG_app);
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l", M_CM_OK);
    cm_buf_put("%s %s ", rba_HG_ass, rba_HG_app);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;
	    
errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}    
/* chk 1070125001-SC2-�w�W�ǻ{�ҥ��x���j���I�O�B��歭��i�󥿡B�R��  */
long chk_ecard_log(reply)
serverReply reply;
{
     $char   DBName[5],ipolicy[21],iendorse_arg[21],iendorse[21];
     int     tmp_len, rc;
     $int    iCount;

     cm_buf_get("%s %s %s", DBName, ipolicy, iendorse_arg);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False) 
     {
       if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
           return M_CM_DB_NOTOPEN;
       else
           return apiRC;
     }
     strcpy(iendorse_arg,trim(iendorse_arg));
     if(strlen(iendorse_arg)>0)
        sprintf_s(iendorse,sizeof iendorse,"17%s",trim(iendorse_arg));
     else
        strcpy(iendorse," ");
    
     printf("ipolicy=[%s],iendorse[%s]iendorse_arg=[%s]\n",ipolicy,iendorse,iendorse_arg);
     iCount = 0 ;  
     $SELECT count(*)
        INTO $iCount
		FROM ca_ecard_log
	   WHERE ipolicy = $ipolicy
         AND iendorse = $iendorse
         AND (result_code IN ('E1008','S0000') or result_code[1,2] ='E8');
         /*S0000 �ǿ馨�\ E1008���ƶǿ�  E8*���ܦ��\�� */
		 
	 printf("iCount=[%d]\n",iCount);

     cm_buf_init(ReplyBuf);

     cm_buf_put("%l %d",M_CM_OK, iCount);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/* chk 1070125001-SC7-�q�l�j���Ҧ۰ʥX�����A�����\�R���O��  */
long chk_fecard_sys(reply)
serverReply reply;
{
     $char   DBName[5],comp_card[21];
     int     tmp_len, rc;
     $int    iCount;

     cm_buf_get("%s %s", DBName, comp_card);

     $WHENEVER SQLERROR GOTO errexit;
     
     if (db_select(DBName) == False) 
     {
       if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
           return M_CM_DB_NOTOPEN;
       else
           return apiRC;
     }
     
     printf("comp_card=[%s]\n",comp_card);
     iCount = 0 ;  
     $SELECT count(*)
        INTO $iCount
		FROM compulsory_card
	   WHERE icard = $comp_card
         AND ireceive ='system';
		 
	 printf("iCount=[%d]\n",iCount);
     
     if (iCount>0) SQLCODE= M_CA_INSSYS_DELCARD_ERR; 
     else   SQLCODE = M_CM_OK;

     cm_buf_init(ReplyBuf);

     cm_buf_put("%l %d",SQLCODE, iCount);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
long Insert_CaLog(reply)
serverReply reply;
{
    /* �g�Jlog�ѫ���d���*/
     $char DBName[5];
     int   tmp_len, rc;
     $char ipgid[9],ftype[2],ilog_number1[21],ilog_number2[21],ncontent[256],userid[11],Msg[1024];
     $int  iCnt;
    
     cm_buf_get("%s", DBName);
     cm_buf_get("%s", ipgid);
     cm_buf_get("%s", ftype);
     cm_buf_get("%s", ilog_number1);
     cm_buf_get("%s", ilog_number2);
     cm_buf_get("%s", ncontent);
     cm_buf_get("%s", userid);

     $WHENEVER SQLERROR GOTO errexit;
     
     if (db_select(DBName) == False) 
     {
       if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
           return M_CM_DB_NOTOPEN;
       else
           return apiRC;
     }
    printf("insert_ca_log-[%s]\n",ipgid);
    iCnt = 0 ;
    strcpy(ipgid,trim(ipgid));
    if (strcmp(ipgid,"ISID") == 0 ) /* �p�G�OISID �ˬd�O�_���g�J �S���n�d�s����*/
    {
        $SELECT count(*) INTO $iCnt
           FROM cm_isid_log
          WHERE iref_num1 = $ilog_number1
            AND imember = $ilog_number2;
        if (iCnt ==0)
        {
            $SELECT count(*) INTO $iCnt
               FROM cm_isid_batch
              WHERE iref_num1 = $ilog_number1
                AND imember = $ilog_number2;            
        }
    }
    printf("iCnt=[%d]\n",iCnt);
    if (iCnt ==0)
    {
        rc = insert_ca_log(ipgid,ftype,ilog_number1,ilog_number2,ncontent,userid,Msg);
        printf("Msg[%s] rc[%d]",Msg,rc);
        if (rc != M_CM_OK)
        {
           return rc;
        } 
    }
    SQLCODE = M_CM_OK;
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l ",SQLCODE);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
long get_est_ientry(reply)
serverReply reply;
{
    $char   DBName[5],stmp[1024];
    $char   iestimate[21],ientry[EMPLOYEE_ID],iexaminer[EMPLOYEE_ID];      
    int     tmp_len;
    long    rc;
    
    cm_buf_get("%s %s", DBName, iestimate);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
        else
             return apiRC;
    }
    printf("get_est_ientry:iestimate[%s]\n",iestimate);

    strcpy(ientry," ");strcpy(iexaminer," ");

	if (strncmp(iestimate+4,"CVQ",3)==0 ||strncmp(iestimate+5,"CP",2) == 0 )
	{
		$SELECT ientry,iexaminer
		   INTO $ientry,$iexaminer
		   FROM estimate
		  WHERE iestimate = $iestimate;
		if(SQLCODE==SQLNOTFOUND)
   		{
	        if(exitsub(reply,M_CM_NOT_FOUND) == True)
	           return M_CM_NOT_FOUND;
	        else
	           return apiRC;
    	}
	}
	else if (strncmp(iestimate+5,"CX",2) == 0)
	{
		sprintf_s(stmp,sizeof stmp,
		    	"select ientry,iexaminer \
		    	   from newa00:abnormal_ply  \
		    	  where iabnormal = '%s';",iestimate);
	    printf("stmp=[%s]\n",stmp);
			
		$PREPARE pre_chk_abn FROM $stmp;
	    $DECLARE cur_chk_abn CURSOR FOR pre_chk_abn;
		$OPEN    cur_chk_abn;
		$FETCH   cur_chk_abn into $ientry,$iexaminer;
		if(SQLCODE==SQLNOTFOUND)
   		{
	        if(exitsub(reply,M_CM_NOT_FOUND) == True)
	           return M_CM_NOT_FOUND;
	        else
	           return apiRC;
    	}
	}
	else
	{
		strcpy(ientry," ");
		strcpy(iexaminer," ");	
	}
 	    
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l", M_CM_OK);
    cm_buf_put("%s %s", ientry,iexaminer);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/***** �U���ߥN�� **********/
long query_all_clm_server_name(reply)
serverReply reply;
{
 $char branch[3],chinese[20],DBName[5];
 int    tmp_len,server_count;
 server_count=0;

 cm_buf_get("%s", DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
   return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();
        cm_buf_res_count();

        $DECLARE a_cur1 CURSOR FOR
          SELECT servertbl.branch,
					CASE servertbl.branch 
					  WHEN '00' THEN '�x�_�z�ߤ���'
					  WHEN '22' THEN '�s�_�z�ߤ���'
					  WHEN '33' THEN '��˭]�z�ߤ���'
					  WHEN '40' THEN '������z�ߤ���'
					  WHEN '66' THEN '���ūn�z�ߤ���'
					  WHEN '70' THEN '����̲z�ߤ���' END chinese
            INTO $branch,$chinese
            FROM servertbl,branch
           WHERE servertbl.branch=branch.ibranch
        ORDER BY servertbl.branch;

        $OPEN a_cur1;

        while(1)
        {
        $FETCH a_cur1;
        if(SQLCODE == SQLNOTFOUND) break;
        cm_buf_put("%s %s",branch,chinese);
        server_count ++;
        }
        $CLOSE a_cur1;
        $FREE a_cur1;

        cm_buf_put_msg(M_CM_OK);
        cm_buf_put_count(server_count);
        tmp_len = cm_buf_len(ReplyBuf);


        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                return apiRC;
        else
                return api_OKComplete;


 errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/*********************************************************************/
/* ���o�O���I�ة��� *//*1120831003_C02_�վ㨮�֭��O�ˮֱ���*/
long get_ins_detail(reply)
serverReply reply;
{
   int   rc, tmp_len;
   $char DBName[5];
   $char iLastply[21],s_ilicense[11],s_iengine[CA_ENGINE_NUM],s_dply_end[11],s_qprovision[2],sIins_type[INSURANCE_TYPE];
   $char s_fcard_class[2],s_irelative_ply[21],sFullName[31]; 
   $char sMsg[512];
   $char sIns_list[500]=" ";
   $char tmp_prov[5],provision[50],iins_type[INSURANCE_TYPE];
   
   $char stmt[2048]; 
   long  count = 0;  
   $char iins_flag_A[2],iins_flag_B[2],iins_flag_C[2],iins_flag_D[2],iins_flag_E[2],iins_flag_F[2];
   $char iins_flag_38[2],iins_flag_39[2],iins_flag_provD[2];
     
   cm_buf_get("%s %s", DBName, iLastply);
   
   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False) 
   {
       if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
           return M_CM_DB_NOTOPEN;
       else
           return apiRC;
   }
   
   strcpy(s_fcard_class, " "); 
   strcpy(s_irelative_ply, " ");
      
   strcpy(iLastply,trim(iLastply)); 
   strcpy(sFullName, get_car_full_db(iLastply));               
		   
   sprintf_s(stmt,sizeof stmt, "select fcard_class,irelative_ply "
			       "  from %s:ply_relation   "
			       " where ipolicy = ?",sFullName);
   printf("-- trace stmt[%s]\n ",stmt);
   $PREPARE pre_ply_last FROM $stmt;
   $EXECUTE pre_ply_last INTO $s_fcard_class,$s_irelative_ply
      using $iLastply;
				                  
   if(SQLCODE==SQLNOTFOUND)
   {   	   	
       if(exitsub(reply,M_CM_NOT_FOUND) == True)      
          return M_CM_NOT_FOUND;                        
       else
          return apiRC;
   }  
   

   strcpy(sIns_list," "); 
   if (s_fcard_class[0]=='1')   	
   {
       if (strlen(trim(s_irelative_ply))>0)   /*�쥦���p�����N�I*/ 
       {   
           strcpy(iLastply,s_irelative_ply);
       }
       else   /*�e��L���N�I*/ 
       {
           strcpy(iLastply,"");  	
       }   	
   }

   /*================  �I�ة���     =================*/
   
   if(strlen(trim(iLastply))>0)
   {
       strcpy(sFullName, get_car_full_db(iLastply));
       sprintf_s(stmt,sizeof stmt,"select iins_type, trim(provision) \n"
                                  "  from %s:ply_ins_type \n"
                                  " where ipolicy = '%s' and mdamage_cover > 0 \n" ,sFullName,iLastply );
                                  
       printf("-- stmt[%s]\n",stmt);                           
       $PREPARE ins_dtl FROM $stmt;
       $DECLARE cur_ins_dtl CURSOR FOR ins_dtl;
       $OPEN cur_ins_dtl;
       for(;;)
       {
       	   strcpy(iins_type,"");
       	   strcpy(provision,"");
       	   
           $FETCH cur_ins_dtl 
             INTO $iins_type,$provision;
             
           if( SQLCODE == SQLNOTFOUND) break;
   
           if(strlen(trim(provision)) == 0)
           {
               strcat(sIns_list,trim(iins_type));
               strcat(sIns_list,";");
           }
           else
           {
           	strcpy(provision,trim(provision));
           	sprintf_s(provision,sizeof provision,"%s;",provision);
           	printf("provision[%s]\n",provision);
           	strcpy(tmp_prov,"");
           	for(int i=0;i<strlen(trim(provision));i++)
           	{
           	    
           	    if(strncmp(provision+i,";",1) !=0)
           	    {
           	    	strcpy(tmp_prov,trim(tmp_prov));
           	    	sprintf_s(tmp_prov,sizeof tmp_prov,"%s%c",tmp_prov,provision[i]);
           	    	printf("provision[%d][%c]\n",i,provision[i]);
           	    	printf("tmp_prov[%s]\n",tmp_prov);
           	    }
           	    else
           	    {
           	    	strcpy(iins_type,trim(iins_type));
           	    	strcat(sIns_list,iins_type);
           	    	strcat(sIns_list,"+");
           	    	strcat(sIns_list,tmp_prov);
           	    	strcat(sIns_list,";");
           	    	strcpy(tmp_prov,"");
           	    	
           	    }
           	}
           } 
       }
       $CLOSE cur_ins_dtl;
       $FREE  cur_ins_dtl;
     
     
   }


   if(strlen(trim(sIns_list))==0) strcpy(sIns_list," ");


    printf("sIns_list[%s]\n", sIns_list);
    


    cm_buf_init(ReplyBuf);   
    cm_buf_put("%l %s ", M_CM_OK, sIns_list);
  
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
    else
       return api_OKComplete;

errexit:
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/*********************************************************************/
/* ���oCR(ply_ins_type_302)�ۭt�B */
long get_302_ins_deduct(reply)
serverReply reply;
{
   int   rc, tmp_len;
   $char DBName[5];
   $char iestimate[21],sIins_type[INSURANCE_TYPE];
   $char stmt[2048],s_deduct[11];  

   cm_buf_get("%s %s %s", DBName, iestimate, sIins_type);
   
   strcpy(s_deduct,"0");
   
   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False) 
   {
       if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
           return M_CM_DB_NOTOPEN;
       else
           return apiRC;
   }
                
		   
   sprintf_s(stmt,sizeof stmt, "select a.ori_deduct "
			       "  from ply_ins_type_302 a,policy_302 b "
			       " where a.ipolicy = b.ipolicy and b.iestimate_ori = '%s' and a.iins_type = '%s' ", iestimate, sIins_type);
   printf("-- trace stmt[%s]\n ",stmt);
   
   $PREPARE pre_ins_302_ori FROM $stmt;
   $EXECUTE pre_ins_302_ori INTO $s_deduct;

   if(SQLCODE==SQLNOTFOUND)
   {   	   	
       sprintf_s(stmt,sizeof stmt, "select a.mdeduct "
			           "  from ply_ins_type_302 a,policy_302 b "
			           " where a.ipolicy = b.ipolicy and b.iestimate_sug = '%s' and a.iins_type = '%s' ", iestimate, sIins_type);
       printf("-- trace stmt[%s]\n ",stmt);
   
       $PREPARE pre_ins_302_sug FROM $stmt;
       $EXECUTE pre_ins_302_sug INTO $s_deduct;
          
       if(SQLCODE==SQLNOTFOUND)
       {   	   	
           if(exitsub(reply,M_CM_NOT_FOUND) == True)      
               return M_CM_NOT_FOUND;                        
           else
               return apiRC;
       }            
   }
   
   $FREE pre_ins_302_ori;
   $FREE pre_ins_302_sug;

   printf("s_deduct[%s]\n", s_deduct);
    
   cm_buf_init(ReplyBuf);   
   cm_buf_put("%l %s ", M_CM_OK, s_deduct);
  
   tmp_len = cm_buf_len(ReplyBuf);
   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
   else
       return api_OKComplete;

errexit:
   return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}