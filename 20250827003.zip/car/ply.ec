/*******************************************************************************
*                                                                              *
*   FILE:              ca311q01s.ec                                            *
*                                                                              *
*   DESCRIPTION:       �O�榬�ڸɵo.			                       *
*                                                                              *
*   DATABASE ACCESS:   form, ply_relation - DBS_Select   		       *
*                                                                              *
*   FORM:	       car311.fmt                                              *
*                                                                              *
********************************************************************************
*                                                                              *
*                              MODIFICATION LOG                                *
*                                                                              *
*    DATE            SE                         DESCRIPTION                    *
*  --------  -------------------  ------------------------------------------   *
*  20000712  Daniel Chen                                                       *
*                                                                              *
*******************************************************************************/
#include <stdio.h>
#include "api_xsrv.h"
#include "sql.h"
#include "datetime.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "print.h"
#include "is_def.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"

EXEC SQL include sqlca;
EXEC SQL BEGIN DECLARE SECTION;
     char GHcPlyBgn[21];
     char GHcPlyEnd[21];
     char GHcCardBgn[21];
     char GHcCardEnd[21];
EXEC SQL END DECLARE SECTION;

char GsDBName[DBNAME];
char GsChoice[2];
char GsPtr[2];
char outputf[20];

int car311_initial();
int car311_process();
int ca_rpt_ply_rcp();

main(argc,argv)
int argc;
char **argv;
{
    char LsUserId[USER_ID];
    char LsFormTp[3];
    int LiRtnCode;
    int LiMax_Cnt;

    LiMax_Cnt = 0;
    LiRtnCode = 0;

    batchinit();
    strcpy(GsDBName, isNULLstr(argv[1]));
    strcpy(LsUserId, isNULLstr(argv[2]));

    strcpy(GsChoice, isNULLstr(argv[3]));
    strcpy(GHcPlyBgn, isNULLstr(argv[4]));
    strcpy(GHcPlyEnd, isNULLstr(argv[5]));
    strcpy(GHcCardBgn, isNULLstr(argv[6]));
    strcpy(GHcCardEnd, isNULLstr(argv[7]));
    strcpy(GsPtr, isNULLstr(argv[8]));

    strcpy(outputf, isNULLstr(argv[9]));

/****
    printf("***** GsDBName[%s] LsUserId[%s] \n", GsDBName, LsUserId);
    printf("***** GHcPlyBgn[%s] GHcPlyEnd[%s] GHcCardBgn[%s] GHcCardEnd[%s]\n",
            GHcPlyBgn,GHcPlyEnd,GHcCardBgn,GHcCardEnd);
****/

    LiRtnCode = car311_initial();

    LiRtnCode = car311_process();

    if(LiRtnCode == M_CA_NREL_PLY)
    {
        EWRITE(LsUserId, LiRtnCode, "�O�楼�L�L�Χ䤣�즹�O�渹!");
        return LiRtnCode;
    }

    if(LiRtnCode != M_CM_OK)
    {
        EWRITE(LsUserId, LiRtnCode, "�O��C�L�����\�Э��դ@��!");
        return LiRtnCode;
    }

    LsFormTp[0] = '\0';

    LiRtnCode = save_form_info(F_FREE, "CA", 311, LsUserId, LsFormTp,LiMax_Cnt, outputf);

    if(LiRtnCode < 0)
    {
        EWRITE(LsUserId, LiRtnCode, "save_form_info failed");
    }
}

int car311_initial()
{
    EXEC SQL BEGIN DECLARE SECTION;
   	 char LHcFormFile[21];
	 int  LHiPageLine;
    EXEC SQL END DECLARE SECTION;

    char LsOutputFile[20];

printf("=== GsDBName = [%s] \n\n", GsDBName);

    if(db_select(GsDBName) == False)
    {
        return M_CM_DB_NOTOPEN;
    }

    if(GsChoice[0] == '1')
    {
        if(GHcPlyEnd[0] == '*' || GHcPlyEnd[0] == ' ' || GHcPlyEnd[0] == '\0')
	{
            strcpy(GHcPlyEnd, GHcPlyBgn);
	}
    }
    else
    {
        if(GHcCardEnd[0] == '*' || GHcCardEnd[0] == ' ' || GHcCardEnd[0] == '\0') 
	{
            strcpy(GHcCardEnd, GHcCardBgn);
	}
    }

    EXEC SQL WHENEVER SQLERROR GOTO errexit;

    EXEC SQL SELECT kpgnum_line, nform_file
	       INTO :LHiPageLine, :LHcFormFile
	       FROM form
	      WHERE ksys_grp = 'CA'	AND
		    kpgmid   = 311;	

    strcpy(LHcFormFile, rtrim(LHcFormFile));
    sprintf_s(LsOutputFile, sizeof LsOutputFile, "%s.tx", outputf);

    rgu_init_report(LHcFormFile, LsOutputFile);

errexit:
    printf("SQLCODE=[%ld], sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

int car311_process()
{
    EXEC SQL BEGIN DECLARE SECTION;
         char LHcIpolicy[21];
         char LHcIcard[21];
         char LHcDply_Begin[11];
         char LHcDply_End[11];
         char LHcIofficer[11];
         char LHcDpolicy[11];
         char LHcIbranch[3];
         char LHcNassured[121];
         char LHcNuser[19];
         char LHcNchi_Abv[13];
         char LHcNpresident[11];
	 int  LHiMdmg_Discount;
	 int  LHiMdmg_Prem;
	 int  LHiMlia_Discount;
	 int  LHiMlia_Prem;
    EXEC SQL END DECLARE SECTION;

    char LcIpolicy[20];
    char LcDply_Begin[10];
    char LcDply_End[10];
    char LcIofficer[10];
    char LcDpolicy[10];
    char LcNchi_Abv[12];
    char LcNpresident[10];
    char LsUser[120];
    int LiRtnCode;
    int LiCnt;
    int LiPayAmt;

    LiRtnCode = 0;
    LiCnt = 0;
    LiPayAmt = 0;

    memset(LsUser, 0x00, sizeof(LsUser));

    EXEC SQL WHENEVER SQLERROR GOTO errexit;

    if(GsChoice[0] == '1')
    {
	EXEC SQL DECLARE PLY_CUR_1 CURSOR FOR

             SELECT A.ipolicy, A.icard, A.dply_begin, A.dply_end,
		    A.mdmg_discount, A.mdmg_prem, A.mlia_discount, A.mlia_prem,
		    A.iofficer, A.dpolicy, A.ibranch, B.nassured, B.nuser,
		    C.nchi_abv, C.npresident
               FROM ply_relation A, policy B, branch C
              WHERE A.dpolicy is not null      		AND
              	    A.fprint = '1'      		AND
               	    A.ipolicy >= :GHcPlyBgn 		AND
		    A.ipolicy <= :GHcPlyEnd		AND
		    A.ipolicy = B.ipolicy		AND
		    A.ibranch =	C.ibranch
              ORDER BY A.ipolicy;

	EXEC SQL OPEN PLY_CUR_1;
    }
    else
    {
	EXEC SQL DECLARE PLY_CUR_2 CURSOR FOR

             SELECT A.ipolicy, A.icard, A.dply_begin, A.dply_end,
		    A.mdmg_discount, A.mdmg_prem, A.mlia_discount, A.mlia_prem,
		    A.iofficer, A.dpolicy, A.ibranch, B.nassured, B.nuser,
		    C.nchi_abv, C.npresident
               FROM ply_relation A, policy B, branch C
              WHERE A.dpolicy is not null      		AND
              	    A.fprint = '1'      		AND
               	    A.icard >= :GHcCardBgn 		AND
		    A.icard <= :GHcCardEnd		AND
		    A.ipolicy = B.ipolicy		AND
		    A.ibranch =	C.ibranch
              ORDER BY A.ipolicy;

	EXEC SQL OPEN PLY_CUR_2;
    }

    while(1)
    {

    	if(GsChoice[0] == '1')
    	{
	    EXEC SQL FETCH PLY_CUR_1
                 into :LHcIpolicy, :LHcIcard, :LHcDply_Begin, :LHcDply_End,
		      :LHiMdmg_Discount, :LHiMdmg_Prem, :LHiMlia_Discount, :LHiMlia_Prem,
		      :LHcIofficer, :LHcDpolicy, :LHcIbranch, :LHcNassured, :LHcNuser,
		      :LHcNchi_Abv, :LHcNpresident;
	}
	else
	{
	    EXEC SQL FETCH PLY_CUR_2
                 into :LHcIpolicy, :LHcIcard, :LHcDply_Begin, :LHcDply_End,
		      :LHiMdmg_Discount, :LHiMdmg_Prem, :LHiMlia_Discount, :LHiMlia_Prem,
		      :LHcIofficer, :LHcDpolicy, :LHcIbranch, :LHcNassured, :LHcNuser,
		      :LHcNchi_Abv, :LHcNpresident;
	}

        if(SQLCODE == SQLNOTFOUND)
	{
	    break;
	}
	
	LiPayAmt = (LHiMdmg_Prem - LHiMdmg_Discount) + (LHiMlia_Prem - LHiMlia_Discount);

        if(GsPtr[0] == '0')
        {
	     strcpy(LsUser, trim(LHcNassured));	
	}
	else
        {
	     strcpy(LsUser, trim(LHcNuser));	
	}

        LiCnt++;

	strcpy(LcNchi_Abv, trim(LHcNchi_Abv));
	strcpy(LcNpresident, trim(LHcNpresident));
	strcpy(LcDpolicy, trim(LHcDpolicy));
	strcpy(LcIpolicy, trim(LHcIpolicy));
	strcpy(LcDply_Begin, trim(LHcDply_Begin));
	strcpy(LcDply_End, trim(LHcDply_End));
	strcpy(LcIofficer, trim(LHcIofficer));

/****
	printf(" *****  LcNchi_Abv = [%s] \n\n", LcNchi_Abv);
	printf(" *****  LcNpresident = [%s] \n\n", LcNpresident);
	printf(" *****	LcDpolicy = [%s] \n\n", LcDpolicy);
	printf(" *****	LcIpolicy = [%s] \n\n", LcIpolicy);
	printf(" *****	LcDply_Begin = [%s] \n\n", LcDply_Begin);
	printf(" *****	LcDply_End = [%s] \n\n", LcDply_End);
	printf(" *****	LcIofficer = [%s] \n\n", LcIofficer);
****/
	
        LiRtnCode = ca_rpt_ply_rcp(LcNchi_Abv, LcNpresident, LsUser, LcDpolicy, LcIpolicy, LcDply_Begin, LcDply_End, LiPayAmt, LcIofficer);

        if(LiRtnCode != M_CM_OK)
	{
	    return LiRtnCode;
	}
    }

    if(GsChoice[0] == '1')
    {
	EXEC SQL CLOSE PLY_CUR_1;
	EXEC SQL FREE PLY_CUR_1;
    }
    else
    {
	EXEC SQL CLOSE PLY_CUR_2;
	EXEC SQL FREE PLY_CUR_2;
    }

    if(LiCnt == 0)
    {
	return M_CA_NREL_PLY;
    }

    rgu_finish_report();

    return M_CM_OK;

    errexit:
   	printf("SQLCODE=[%ld], sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   	return SQLCODE;
}
