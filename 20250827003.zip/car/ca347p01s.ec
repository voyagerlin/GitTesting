/************************************************/
/*                                              */
/*   PROGRAM : ca347p01s.ec                     */
/*   PURPOSE : �n�O�Ѧ��^�@�~                   */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
$include sqlca;
$include decimal;

char *equip_delete();
char *equip_insert();
char *equip_put();
char *equip_get();

DBinfo  *list;
int  count_db;

$char sFullName[20];
 
$char ipre_rcv[21],ipolicy[21],ipolicy1[21],ipolicy2[21];

$char tmp_ipolicy1[21],tmp_ipolicy2[21],tmp_icard1[21],tmp_icard2[21];
$char tmp_iassured1[11],tmp_nassured1[41],tmp_iapplicant1[11],tmp_napplicant1[41];
$char tmp_iofficer1[11],tmp_nofficer1[41],tmp_dbegin1[11],tmp_dend1[11];

$char tmp_iassured2[11],tmp_nassured2[41],tmp_iapplicant2[11],tmp_napplicant2[41];
$char tmp_iofficer2[11],tmp_nofficer2[41],tmp_dbegin2[11],tmp_dend2[11];

$char tmp_nequipment1[31],tmp_nequipment2[31],nequipment1[31],nequipment2[31];

$char icode[2],itype[2],num[21],num1[21];
$int  cnt_neq103;

$char sFeply2[3],sAemail_eply[51];

$char foccup[2],noccup[6],applicant_foccup[2],applicant_noccup[6];
$char iscan_no1[26],iscan_no2[26];

long car347(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car347_single_query(),car347_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);

 switch(option)
 {
  case 'Q':
	   rtncode=car347_single_query(reply);
	   break;
  case 'P':
	   rtncode=car347_update_exec(reply,command,com_len);
	   break;
  default :
	   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
	    return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

/*******************************************************************/

long car347_single_query(reply)
serverReply reply;
{
 $char DBName[3];
 char  tmpbuf[4000];
 int   count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int   i,total_count=0,k;
 $char userid[11];


 $char stmt[1024];
 $char Full_DBName[31];
 int   rc;
 $int  cnt,cnt_103;

 cnt = 0;

  cm_buf_get("%s %s %s %s ",DBName,userid,icode,num);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
     if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
       return M_CM_DB_NOTOPEN;
     else
       return apiRC;
  }
  
  if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
         printf("get_db_list error accur \n");
         return SQLCODE;
     }

  init_data();
  
  if( strcmp(icode,"1") == 0 )
  {
  	strcpy(ipre_rcv,num);
  }
  else if( strcmp(icode,"2") == 0 )
  {
  	$SELECT	first 1 ipre_rcv
  	   INTO $ipre_rcv
  	   FROM cm_pre_receive
  	  WHERE ipolicy1 = $num;

  	if(SQLCODE == SQLNOTFOUND)
  	{
  		SQLCODE = M_CM_NOT_FOUND;
  		goto errexit;
  	}
  }
  else
  {
  	/*
  	$SELECT	first 1 ipre_rcv
  	   INTO $ipre_rcv
  	   FROM ao_rcv_type
  	  WHERE $num like trim(trcv)||'%';
  	*/

  	strncpy(num1,num,16);
  	printf("num1[%s]\n",num1);
  	$SELECT	first 1 ipre_rcv
  	   INTO $ipre_rcv
  	   FROM ao_rcv_type
  	  WHERE trcv = $num1
  	    AND paydate >= today -180;

  	if(SQLCODE == SQLNOTFOUND)
  	{
  		SQLCODE = M_CM_NOT_FOUND;
  		goto errexit;
  	}
  }

    sprintf_s(stmt, sizeof stmt,"SELECT ipolicy1||ipolicy2,icard,iassured,nassured,iapplicant,napplicant,iofficer,"
                 "       (SELECT nname FROM officer WHERE iofficer = a.iofficer), "
                 "       nvl(year(dbegin)||to_char(dbegin,'/%%m/%%d'),''), "
                 "       nvl(year(dend)||to_char(dend,'/%%m/%%d'),'') "
                 "  FROM cm_pre_receive a "
                 " WHERE ipre_rcv = '%s'  "
                 "   AND iins_kind = '1'  "
                 "   AND iins_cat = 'C'   "
                 "   AND ipre_end = ' '   "
                 "   AND iendorse = ' '   ",ipre_rcv);

printf("stmt[%s]\n",stmt);

	$PREPARE pre3_1 FROM $stmt;
        $DECLARE cur_pre3_1 CURSOR for pre3_1;
      	$OPEN cur_pre3_1;

      	while(1)
      	{
         	$FETCH cur_pre3_1 INTO $tmp_ipolicy1,$tmp_icard1,$tmp_iassured1,$tmp_nassured1,
         	                       $tmp_iapplicant1,$tmp_napplicant1,$tmp_iofficer1,$tmp_nofficer1,
                                       $tmp_dbegin1,$tmp_dend1;

         	if(SQLCODE == SQLNOTFOUND) break;

	}
        $CLOSE cur_pre3_1;
        $FREE cur_pre3_1;

        sprintf_s(stmt, sizeof stmt,"SELECT ipolicy1||ipolicy2,icard,iassured,nassured,iapplicant,napplicant,iofficer,"
                 "       (SELECT nname FROM officer WHERE iofficer = a.iofficer), "
                 "       nvl(year(dbegin)||to_char(dbegin,'/%%m/%%d'),''), "
                 "       nvl(year(dend)||to_char(dend,'/%%m/%%d'),'') "
                 "  FROM cm_pre_receive a "
                 " WHERE ipre_rcv = '%s'  "
                 "   AND iins_kind = '2'  "
                 "   AND iins_cat = 'C'   "
                 "   AND ipre_end = ' '   "
                 "   AND iendorse = ' '   ",ipre_rcv);

printf("stmt[%s]\n",stmt);

	$PREPARE pre3_2 FROM $stmt;
        $DECLARE cur_pre3_2 CURSOR for pre3_2;
      	$OPEN cur_pre3_2;

      	while(1)
      	{
         	$FETCH cur_pre3_2 INTO $tmp_ipolicy2,$tmp_icard2,$tmp_iassured2,$tmp_nassured2,
         	                       $tmp_iapplicant2,$tmp_napplicant2,$tmp_iofficer2,$tmp_nofficer2,
                                       $tmp_dbegin2,$tmp_dend2;

         	if(SQLCODE == SQLNOTFOUND) break;

	}
        $CLOSE cur_pre3_2;
        $FREE cur_pre3_2;

	/* �n�O�Ѧ��^�O�� */
        sprintf_s(stmt, sizeof stmt,"SELECT count(*) "
	                "  FROM ca_autoply_log a  "
	                " WHERE a.ipre_rcv = '%s' "
	                "   AND a.itype = 'D'     "
	                "   AND a.dupdate = (select max(dupdate) from ca_autoply_log where ipre_rcv = a.ipre_rcv )",ipre_rcv);

printf("stmt[%s]\n",stmt);

           $PREPARE pre3_3 FROM $stmt;
           $DECLARE cur_pre3_3 CURSOR for pre3_3;
      	   $OPEN cur_pre3_3;
   	   $FETCH cur_pre3_3 INTO $cnt;
   	   
   	/* 103�n�O�ѥ��^�P�_ */
   	strcpy(tmp_ipolicy1,trim(tmp_ipolicy1));
   	strcpy(tmp_ipolicy2,trim(tmp_ipolicy2));
   	
   	if (strlen(tmp_ipolicy1) != 0)
   	{
   		strcpy(sFullName, get_car_full_db(tmp_ipolicy1));
   	}
   	else if(strlen(tmp_ipolicy2) != 0)
   	{
   		strcpy(sFullName, get_car_full_db(tmp_ipolicy2));
   	}	
   	else
   	{
   		SQLCODE = M_CM_NOT_FOUND;
  		goto errexit;
   	}


    if(strlen(tmp_ipolicy2) != 0)
    {
    	sprintf_s(stmt, sizeof stmt,"SELECT case when feply = '0' then '�_' else '�O' end,aemail_eply "
	             "  FROM %s:ply_relation  "
	             " WHERE ipolicy = '%s' ",sFullName,tmp_ipolicy2);

	$PREPARE u_feply_2 FROM $stmt;
    	$EXECUTE u_feply_2 into $sFeply2,$sAemail_eply;
    }
    else
   {
   	strcpy(sFeply2,"�_");
   	strcpy(sAemail_eply," ");
   }

   sprintf_s(stmt, sizeof stmt," SELECT count(*) "
	        "  FROM %s:policy  "
	        " WHERE nequipment[13] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.') "
	        "   AND (ipolicy = '%s' or ipolicy = '%s')",sFullName,tmp_ipolicy1,tmp_ipolicy2);

   $prepare pre3_4 FROM $stmt;
   $execute pre3_4 INTO $cnt_103;
   
   if(strlen(tmp_ipolicy1) != 0)
   {
   	sprintf_s(stmt, sizeof stmt," SELECT iscan_no "
                     "   FROM %s:ply_relation "
                     "  WHERE ipolicy = '%s' ",sFullName,tmp_ipolicy1);
        
        $PREPARE scan_no1 FROM $stmt;
        $EXECUTE scan_no1 into $iscan_no1;
   }
   else
   {
   	strcpy(iscan_no1," ");
   }  
   	
 
   if(strlen(tmp_ipolicy2) != 0)
   {
   	sprintf_s(stmt, sizeof stmt," SELECT iscan_no "
                     "   FROM %s:ply_relation "
                     "  WHERE ipolicy = '%s' ",sFullName,tmp_ipolicy2);
        
        $PREPARE scan_no2 FROM $stmt;
        $EXECUTE scan_no2 into $iscan_no2;
   }
   else
   {
   	strcpy(iscan_no2," ");
   }
   
   
   if(strlen(tmp_ipolicy1) != 0)
   {
   	sprintf_s(stmt, sizeof stmt,"SELECT foccup,noccup,applicant_foccup,applicant_noccup "
                     "  FROM %s:policy  "
                     " WHERE ipolicy = '%s' ",sFullName,tmp_ipolicy1);
   }
   else
   {
   	sprintf_s(stmt, sizeof stmt,"SELECT foccup,noccup,applicant_foccup,applicant_noccup "
                     "  FROM %s:policy  "
                     " WHERE ipolicy = '%s' ",sFullName,tmp_ipolicy2);
   }             
                 
printf("stmt[%s]\n",stmt);
   
    $PREPARE occup FROM $stmt;
    $EXECUTE occup into $foccup,$noccup,$applicant_foccup,$applicant_noccup;

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %s %s %s %s %s ",M_CM_OK,ipre_rcv,tmp_icard1,tmp_ipolicy1,tmp_iassured1,tmp_nassured1,tmp_iapplicant1,tmp_napplicant1);
    cm_buf_put("%s %s %s %s ",tmp_iofficer1,tmp_nofficer1,tmp_dbegin1,tmp_dend1);
    cm_buf_put("%s %s %s %s %s ",tmp_ipolicy2,tmp_iassured2,tmp_nassured2,tmp_iapplicant2,tmp_napplicant2);
    cm_buf_put("%s %s %s %s %s %s ",tmp_iofficer2,tmp_nofficer2,tmp_dbegin2,tmp_dend2,sFeply2,sAemail_eply);
    cm_buf_put("%s %s %s %s %s %s ",foccup,noccup,applicant_foccup,applicant_noccup,iscan_no1,iscan_no2);
    cm_buf_put("%d %d ",cnt,cnt_103);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
       return apiRC;
    else
       return api_OKComplete;



errexit:
  printf("SQLCODE:%d errmsg:%s\n",SQLCODE,sqlca.sqlerrm);
  if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
  else
     return apiRC;
}



/******************************************************************/
long car347_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 $char DBName[3];

 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int raw_len;
 long dummy=0;
 long MsgCode;
 $char userid[11];
 int   rc,is_upd_fail=0;
 $char stmt_buf[1024],stmt[1024];
 $int cnt_neq113=0;


 comm = (char *) command;
 cm_buf_init(command);
 printf("123456789\n");
 cm_buf_get("%c %s",&option,DBName);

printf("0000000011111122222\n");

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }


   $BEGIN WORK;
   cm_buf_init(command);
   cm_buf_get("%c %s",&option,DBName);
   cm_buf_get("%s %s %s %s %s %s %s %s %s ",userid,itype,ipre_rcv,ipolicy1,ipolicy2,foccup,noccup,applicant_foccup,applicant_noccup);

   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT 5;

   if(strlen(trim(ipolicy1)) != 0)
   {
   	strcpy(sFullName, get_car_full_db(ipolicy1));

	   sprintf_s(stmt, sizeof stmt,"SELECT nequipment "
	                "  FROM %s:policy  "
	                " WHERE ipolicy = '%s' ",sFullName,ipolicy1);

           $PREPARE pre1_1 FROM $stmt;
           $DECLARE cur_pre1_1 CURSOR for pre1_1;
      	   $OPEN cur_pre1_1;
   	   $FETCH cur_pre1_1 INTO $tmp_nequipment1;

	   printf("tmp_nequipment1[%s]\n",tmp_nequipment1);

   	   if ( strcmp(itype,"A") == 0 )
   	   {
   	   	strcpy(nequipment1,equip_insert(tmp_nequipment1,"103"));
   	   	printf("nequipment1[%s]\n",nequipment1);
   	   	sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE %s:policy SET "
                             " (nequipment,foccup,noccup,applicant_foccup,applicant_noccup) "
                             " = (?,?,?,?,?) "
                             " WHERE ipolicy = ? "
                             " AND nequipment[12] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.')",sFullName);
   	   }
   	   else
   	   {
   	   	/* �s�W113���O�G�n�O�ѥ��^(E�O��) �P�άսT�{�A�u���j���I�|���W113���O (1071009009_SC3) */
   	   	if (equip_cmp(tmp_nequipment1,"113"))
   	   	{
   	   		cnt_neq113 = 1; 
   	   		strcpy(nequipment1,equip_delete(tmp_nequipment1,"113"));
   	   		printf("nequipment1-113[%s]\n",nequipment1);
   	   		sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE %s:policy SET "
                            "         (nequipment,foccup,noccup,applicant_foccup,applicant_noccup) "
                            "      = (?,?,?,?,?) "
                            " WHERE ipolicy = ? "
                            "   AND nequipment[23] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.')",sFullName);
   	   	}
   	   	else
   	   	{
   	   		strcpy(nequipment1,equip_delete(tmp_nequipment1,"103"));
   	   		printf("nequipment1[%s]\n",nequipment1);
   	   		sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE %s:policy SET "
                           "        (nequipment,foccup,noccup,applicant_foccup,applicant_noccup) "
                           "       = (?,?,?,?,?) "
                           "  WHERE ipolicy = ? "
                           "    AND nequipment[12] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.') "
                           "    AND nequipment[13] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.')",sFullName);
   	   	}
   	   }

                $PREPARE u_id1 FROM $stmt_buf;
                $EXECUTE u_id1 using $nequipment1,$foccup,$noccup,$applicant_foccup,$applicant_noccup,$ipolicy1;

           if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated */
       	   {
        	SQLCODE = M_CM_NOT_FOUND;
        	goto errexit;
    	   }
    	   
    	   /*** �T�{���O�O�_�������\ ***/
    	   if ( strcmp(itype,"D") == 0 )
   	   {
   	   	sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT count(*)  "
                                 "   FROM %s:policy "
                                 "  WHERE ipolicy = ?  "
                                 "    AND (nequipment[13] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.') "
                                 "    OR nequipment[23] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.'))",sFullName);
   	   
   	   	$PREPARE u_id1_1 FROM $stmt_buf;
                $EXECUTE u_id1_1 into $cnt_neq103 using $ipolicy1 ;
                
                printf("cnt_neq103[%d]\n",cnt_neq103);
                
                if (cnt_neq103 > 0)
                {
                	SQLCODE = M_CM_PROCESS_ERR;
                	goto errexit;
                }
   	   }

   }

   if ((strlen(trim(ipolicy2)) != 0)&&(cnt_neq113==0))
   {
   	strcpy(sFullName, get_car_full_db(ipolicy2));

	   sprintf_s(stmt, sizeof stmt,"SELECT nequipment "
	                "  FROM %s:policy  "
	                " WHERE ipolicy = '%s' ",sFullName,ipolicy2);

           $PREPARE pre2_1 FROM $stmt;
           $DECLARE cur_pre2_1 CURSOR for pre2_1;
      	   $OPEN cur_pre2_1;
   	   $FETCH cur_pre2_1 INTO $tmp_nequipment2;

	   printf("tmp_nequipment2[%s]\n",tmp_nequipment2);

   	   if ( strcmp(itype,"A") == 0 )
   	   {
   	   	strcpy(nequipment2,equip_insert(tmp_nequipment2,"103"));
   	   	printf("nequipment2[%s]\n",nequipment2);
   	   	sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE %s:policy SET "
                            "         (nequipment,foccup,noccup,applicant_foccup,applicant_noccup) "
                            "       = ('%s','%s','%s','%s','%s') "
                            "  WHERE ipolicy = '%s' "
                            "    AND nequipment[12] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.')",sFullName,nequipment2,foccup,noccup,applicant_foccup,applicant_noccup,ipolicy2);
   	   }
   	   else
   	   {
   	   	strcpy(nequipment2,equip_delete(tmp_nequipment2,"103"));
   	   	printf("nequipment2[%s]\n",nequipment2);
   	   	sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE %s:policy SET "
                                 "    (nequipment,foccup,noccup,applicant_foccup,applicant_noccup) "
                                 " = ('%s','%s','%s','%s','%s') "
                             " WHERE ipolicy = '%s' "
                             " AND nequipment[12] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.') "
                             " AND nequipment[13] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.')",sFullName,nequipment2,foccup,noccup,applicant_foccup,applicant_noccup,ipolicy2);
   	   }
	   
	   printf("stmt_buf[%s]\n",stmt_buf);

           $EXECUTE IMMEDIATE $stmt_buf;

           if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated */
       	   {
        	SQLCODE = M_CM_NOT_FOUND;
        	goto errexit;
    	   }
    	   
    	   /*** �T�{���O�O�_�������\ ***/
    	   if ( strcmp(itype,"D") == 0 )
   	   {
   	   	sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT count(*) "
                                 "   FROM %s:policy "
                                 "  WHERE ipolicy = ?    "
                                 "    AND (nequipment[13] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.') "
                                 "     OR nequipment[23] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.'))",sFullName);
   	   
   	   	$PREPARE u_id2_1 FROM $stmt_buf;
                $EXECUTE u_id2_1 into $cnt_neq103 using $ipolicy2 ;
                
                printf("cnt_neq103[%d]\n",cnt_neq103);
                
                if (cnt_neq103 > 0)
                {
                	SQLCODE = M_CM_PROCESS_ERR;
                	goto errexit;
                }
   	   }

   }


   /* insert ca_autoply_log */
   sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO ca_autoply_log "
       "  (ipre_rcv,ipolicy1,ipolicy2,itype,iupdate,dupdate) "
	" VALUES (?,?,?,?,?,current)");

   $PREPARE a_id FROM $stmt_buf;
   $EXECUTE a_id USING $ipre_rcv,$ipolicy1,$ipolicy2,$itype,$userid;

   if(SQLCODE != 0) goto errexit;


     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     tmp_len = cm_buf_len(ReplyBuf);
     if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
     {
       $WHENEVER SQLERROR CONTINUE;
       $ROLLBACK WORK;
       return apiRC;
     }
     $WHENEVER SQLERROR GOTO errexit;
     $COMMIT WORK;
     return api_OKComplete;


errexit:
  printf("SQLCODE:%d errmsg:%s\n",SQLCODE,sqlca.sqlerrm);
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True)
   return MsgCode;
  else
   return apiRC;
}

init_data()
{
    strcpy(tmp_icard1," ");
    strcpy(tmp_ipolicy1," ");
    strcpy(tmp_iassured1," ");
    strcpy(tmp_nassured1," ");
    strcpy(tmp_iapplicant1," ");
    strcpy(tmp_napplicant1," ");
    strcpy(tmp_iofficer1," ");
    strcpy(tmp_nofficer1," ");
    strcpy(tmp_dbegin1," ");
    strcpy(tmp_dend1," ");
    strcpy(tmp_icard2," ");
    strcpy(tmp_ipolicy2," ");
    strcpy(tmp_iassured2," ");
    strcpy(tmp_nassured2," ");
    strcpy(tmp_iapplicant2," ");
    strcpy(tmp_napplicant2," ");
    strcpy(tmp_iofficer2," ");
    strcpy(tmp_nofficer2," ");
    strcpy(tmp_dbegin2," ");
    strcpy(tmp_dend2," ");
    cnt_neq103 = 0;
}