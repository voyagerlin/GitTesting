/*--------------------------------------------------------------------
 *    Program    : ca508p03s.ec
 *                 �z�ߤ鵲�B�z
 *    Date       : 12/19/1994
 *                 modify by johnny Kuo 07/22/1997
 *--------------------------------------------------------------------*/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include <decimal.h>

#include "is_def.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "glsstru.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "comdata.h"
#include "cm_stl_info.h"
#include "ISconstant_car.h"

$include sqlca;
$include datetime;
$include sqltypes;

#define TRUE                    1
#define FALSE                   0
#define FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND
#define EQUAL(s1,s2)            !strcmp(s1,s2)
#define NOT_EQUAL(s1,s2)        strcmp(s1,s2)

$char  err_buf[50000], err_ifrs[200];
$char  DBname[5], userid[USER_ID], outputf[21], creator[USER_ID];
char   dclosing_type[2], ch_dwritten[16], Tqserial[4];
$char qserial1[12];
$int qserial,qserial2,qserial;
$char str_qserial[20];
$char tmp_qserial[3];
$date  Today, dwritten;
char success_str[100], upd_smsg[30000];
char success_qserial[50000];
$char iproduct[13];
$char kclsfyitem[5];
$char kreserve[6];
$char get_iins_type[INSURANCE_TYPE],ply_ins[INSURANCE_TYPE],provision[7];
$char frate[5];
$char invoice[21],dreceive[11];
$char ito_sub[3],iaccsub[3];

$date  stldate, groupdate;
$int   c_cnt,s_cnt;
$long  rcA;
$char  remarkA[201];

$date  groupdate1;
time_t current_secs;
struct tm *tm_now;
$char  curtime[30];
$char  thh[3];
$char  tmm[3];
$char  vouch_state[4];
$char  nvouch_state[30];
$char  sSpace[2];
$char  freason_tmp[2];
$char  stmt_reject[2048];
$int   ireject_cnt;
$char  sItransno[22];
$char  iaccount_branch[3], sIsign[21];
$char	 upd_smsg1[61];


static int db_num;
$static char  sIpolicy1[POLICY_NUM_1], sIpolicy2[POLICY_NUM_2];
DBinfo *list;

$char  CACmaxp_2[CLAIM_NUM];

struct STL_LIST {
    char iclaim[CLAIM_NUM];
    int  iclose_type;
    char ipolicy[POLICY_NUM_1];
    long dadjust;
    char fstl[2];
    struct STL_LIST *next;
};

struct STL_LIST *StlFirst, *StlCurr, *StlLast;

int DiffMonth();
long car5083_call_car519();
long Car508_P();
long cm_stl_info_insert();
long cm_stl_info_delete();
int cm_stl_info_init();
int  ca_close_chk();
extern void trim_cspace();

main(argc, argv)
int argc;
char **argv;
{
    long rc;

    batchinit();
    strcpy(DBname       ,isNULLstr(argv[1]));
    strcpy(userid       ,isNULLstr(argv[2]));
    strcpy(dclosing_type,isNULLstr(argv[3])); /*3:�@��߮� A:�{���B�z�O�Χ妸���ɤ鵲 B:���O�l�v�妸���ɤ鵲 T:��Q�I���ɤ鵲 C:�j���I�P�~�u������(car926) F:(car929) D:���T�O�Χ妸���ɤ鵲(car546)*/
    strcpy(ch_dwritten  ,isNULLstr(argv[4]));
    strcpy(creator      ,isNULLstr(argv[5])); /*userid*/
    strcpy(sItransno    ,isNULLstr(argv[6])); /*�ť�:�@��߮� ����:�Ѳ{���B�z�O/���O�l�v/��Q�I�妸���ɤ鵲�ϥ� */
    strcpy(outputf      ,isNULLstr(argv[7]));

    printf("ch_dwritten[%s]\n",ch_dwritten);
    dwritten=cm_ymd_cdate(ch_dwritten);

    rtoday(&Today);     /* get today's datetime */

    strcpy(sSpace," ");

    if (db_select(DBname) == False)
    {
        EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
        return 0;
    }
    memset(err_buf,0,sizeof(err_buf));

    memset(upd_smsg,0,sizeof(upd_smsg));

    rc=Car508_P();

    $WHENEVER SQLERROR CONTINUE;     /* reset error handling */
    if (rc != M_CM_OK)
    {
        printf("[����]\n");
        printf("rc=[%d] err_buf=[%s]\n",rc, err_buf);
        if (rc==4) EWRITE(userid,rc,"�h�H�P�ɤ鵲�A�������ѡA�еy��A����I");
        else EWRITE(userid,rc,err_buf);
        return rc;
    }
    FreeStlList(StlFirst,StlCurr);


	  rc = car5083_call_car519();
    /**** else return code == M_CM_OK ****/
    printf("return success\n");
    printf("*******************************************************");


    strcpy(success_str,"�z�ߤ鵲����,�鵲�帹��");

    printf("str_qserial[%s]\n",str_qserial);

    strcpy(success_qserial,strcat(success_str,str_qserial));
    strcat(success_qserial, "\n\n");
    strcat(success_qserial, upd_smsg);

    printf("success_qserial[%s]\n",success_qserial);

    if ((dclosing_type[0]=='3') || (dclosing_type[0]=='A') ||
        (dclosing_type[0]=='B') || (dclosing_type[0]=='T') ||
        (dclosing_type[0]=='C') || (dclosing_type[0]=='F') ||
		(dclosing_type[0]=='D'))
        EWRITE(userid,M_CM_OK,success_qserial);

    printf("*******************************************************");
    return SUCCESS;
}

long car5083_call_car519()
{
	int result;
	char p0[101];
	char sApHome[31],command[512];

	result = getApHome(sApHome);
	if(result < 0)
	{
		printf("read Config file error!!\n");
		return M_CM_READ_CONFIG_ERR;
	}

	sprintf( p0,"runbatch %s %s car519 Q 3 '%s' '%s' '1' >/dev/null &", DBname,userid,ch_dwritten,substring(str_qserial,9,2));
	printf("p0[%s]\n",p0);
	sprintf(command, "%s", p0);
	result = system(command);
	printf("result[%d]\n", result);
	puts("test_data ok");
	return M_CM_OK;
}

long Car508_P()
{
	$char 	REJECT_REMARK[100],REJECT_REMARK_TMP[100];
    $char   DBName[5],sDBName_loc[21];
    $char   car_comp_acc[5], car_dmg_acc[5], car_lia_acc[5] , car_mot_comp_acc[5];
    $char   car_pa_acc[5];

    $int    i=0, j=0, k=0;
    $long   rc;
    $date   dclose;
    $double dclose_e;

    $char   ftrans[2];
    $char   isub[3],insure_type[2];

    $char   ipolicy[POLICY_NUM_1];
    $char   iclaim_tmp[20];
    $char   icard[CARD_NUM],fcard_class[2],ins_type[INSURANCE_TYPE];
    $char   isettle_type[2], asettle[65], aperm[65], ifirm_pid[11];
    $char   asettle_1[61], aperm_1[61], itrans_acc[15];

    $char   dbsub[3], icls_dept[3], ipay_dept[3];
    $char   iclaim[CLAIM_NUM],iclose[15],fsalvage[2],ireceive[13];
    $char   iacc_reason[3], fpart[2], fstl[2], ibranch[3];
    $char   ipayment[11],ipay_area[3],fspeed[2],fpay_cond[2],frecover[2],fsale[2];
    $char   re_frecover[2], re_frecov[2];	/*recovery�l�v�O�ޱ�*/
    $int    tmp_count;
    $char   iadjuster[11], message_tel[11];
    $char   npayment[101];
    $char   napyment[101];
    $char   frecov[2],fsal[2];
    $long   total_mfee;
    $char   istl_obj[13],nstl_obj[101], ifpce_id_ext[3], nchi_full[100];
    $char   nchi_full_6[100];
    $char   xibank[8],xiaccount[15],xfpay_cond[2],xmail_chk[2],xcombine_chk[2];
    $char   xtel[16],xastl_obj_c[61];
    $char   cFcardClass[2],flast[2];
    $char   iins_item[INSURANCE_TYPE],ivictim[11],iins_type[INSURANCE_TYPE];
    $char   tel[21],ibank[8],mail_chk[2], combine_chk[2];
    $int    iclose_type,id_cust;
    $long   dentry;
    $long   adj_begin,adj_end;
    $long   iMonth;
    $char   fcar_class[2];
    $char   adj_car_type[3];

    $double ptax, ptax_1, mpayment_1;

    $char   tmp_ptax[16], tmp_mpayment[20];
    dec_t   dec_ptax, dec_mpayment;
    $char   sIfpce_id[12], sIfpce_id_ext[3];
    $int    lQserial;
    $int    cartype27; /*27���دS���B�z*/
    $int    iser_rec, iser_rec_new, iFacc_duty, iFdmg_duty;

    /*** AOI ***/
    $char   ao_policy1[POLICY_NUM_1], ao_policy2[CA_TARGET_NUM];
    $long   mstl_sum, mproc_sum, msalv_sum, mplace_sum;
    $char   sclose_type[6];
    $char   insure_kind[11];
    $long   msettle,mdmg_proc,mlia_proc, mpayment, mdbp, mli;

    $long   total_msettle;
    $long   total_msettle_rec;
    $long   mstl,mproc, mstl1,mproc1,msalv1, mstl2,mproc2,msalv2,msalvage;
    $long   mplace1;
    $long   mstl3,mproc3,msalv3;
    $long   mins_stl,mins_proc,mstl_health,sum_stl_proc;
    $long   mins_place;
    char    *pos;

    $char   sStmt[1024], buf[5], stmt_buf[400], sTmp_duty[400];
    $char   stmt[2048];
    $char   sFullName[20], sFullName_ply[20], sFullName_loc[20];
    $char   stlinfodaccident[17], stlinfodclaim[17];
    $char   stlinfodaccident_tmp[YYYYMMDD], stlinfodclaim_tmp[YYYYMMDD];
    $char   ipolicy_M[2];
    char    str[YYYYMMDD];
    char    stlinfodclose[YYYYMMDD];
    int     fFound, iRtnCode;
    SETTLE_INFO stCmStlInfo;
    int rtncode;
    char sIunit[6], sIbranch_in[BRANCH_ID];
    $char istl_note[4],sWh1[100],sWh2[100],sWh3[100];
    $int    re_cnt, clm_cnt;
    int rtn;
    char fOld, fCarStl;
    $int fclaim_status_pre, ioth_duty;
    $long mmrecov;
    $char fsystem[2], sitag[CA_TAG_NUM];

    $int app_count;
    $int hist_count;
    $char msgbuf[500];

    $char frec_type[2];
    $char izipcode[CA_ZIP];
    $char aaddress[121];
    $char nreceiver[101];
    $char iofficer[11];
    $char ioff_branch[3];
    $char ioff_tel_ext[6];
    $char itelephone[21];
    $char imobilephone[21];
    $char nremark[101];
    $char fchange[2];
    $char iemail[51], imobile[21], izipcode_con[CA_ZIP], tfax[21];

    $char sIclaim[135];
    $int dProcCnt, sIclaim_cnt;
    $char tmpstr1[31], sIstl_flag[2];
    $char sImerber[11], sNmember[101];
    $char irecvory[11];
    $char fabandon[2];

    $double psupp_prem;
    $int mptax, msupp_prem;
    $char ibranch_in[7];


    EXEC SQL WHENEVER SQLERROR GOTO optP_err;
    mstl_sum = mproc_sum = msalv_sum = mplace_sum = 0;
    /* define �|�p��إN�� */

    strcpy(car_dmg_acc,CAR_DMG_ACC);               /* 1010 */
    strcpy(car_lia_acc,CAR_LIA_ACC);               /* 1020 */
    strcpy(car_comp_acc,CAR_COMP_ACC);             /* 1030 */
    strcpy(car_mot_comp_acc,CAR_MOT_COMP_ACC);     /* 1040 */
    strcpy(car_pa_acc,CAR_PA_ACC);                 /* 1050 */
	
    memset(isub, 0, 3) ; memset(insure_type,0, 2)  ; memset(fpay_cond, 0, 2);
    memset(dbsub, 0, 3) ; memset(icls_dept, 0, 3)  ; memset(ipay_dept, 0, 3);
    memset(iclaim, 0, 15); memset(iclose, 0, 15) ; iclose_type=0;
    memset(fsalvage, 0, 2) ; memset(ireceive, 0, 13) ; memset(iacc_reason,0, 3);
    memset(fpart, 0, 2) ; memset(fstl, 0, 2)  ; memset(ibranch, 0, 3);
    memset(ipayment, 0, 61); memset(ipay_area, 0, 3)  ; memset(fspeed, 0, 2);
    memset(frecover, 0, 2) ; memset(nstl_obj, 0, 101); memset(cFcardClass,0, 2);
    memset(sclose_type,0,5);

    sprintf(stmt_reject,
     " select count(*)    \
         from reject_client    \
	where nassured = ? and ilicense = ? and itag = ?    \
	  and iengine = ? and ibody = ? and freason = ? ");
    $prepare get_reject_cnt from $stmt_reject;

    stldate=dwritten;
    groupdate = get_next_workday(stldate);
    if (groupdate == FALSE)
    {
      printf("get_next_workday FALSE\n");
      sprintf(err_buf, "get_next_workday[%ld]", dwritten);
      return FALSE;
    }
        printf("AAA groupdate[%ld]\n",groupdate);

        current_secs=time(NULL);
        tm_now=localtime(&current_secs);
        strcpy(curtime,datetime_string(tm_now));
        strncpy(thh,curtime+11,2);
        thh[2] = '\0';

        strncpy(tmm,curtime+14,2);
        tmm[2] = '\0';

        printf("thh[%s]\n",thh);
        printf("tmm[%s]\n",tmm);

        /*  groupdate for �K�ߵ���  �Ygroupdate = ���ѡA�B�ɶ� >= 19:30�A�hŪ�� groupdate �U�@�u�@�� */
        if ((atoi(thh) > 19) || ((atoi(thh) == 19) && (atoi(tmm) >= 30)))
        {
           if (groupdate == Today)
           {
              groupdate = groupdate + 1;
              groupdate1 = get_next_workday(groupdate);
              if (groupdate1 == FALSE)
              {
                printf("get_next_workday1 FALSE\n");
                sprintf(err_buf, "get_next_workday1[%ld]", groupdate);
                return FALSE;
	            }
              groupdate = groupdate1;
              printf("BBB groupdate1[%ld]\n",groupdate1);
           }
        }

    /**** STEP P1 *****************************************/

    printf("-> enter P1\n");
    /* �ˮ֬O�_��IFRS���զX�N�X�θs�եN�X add by sylvia 111.11.01 */
    rtn = ChkIFRS();
    if (rtn != SUCCESS)
    {
        return rtn;
    }

    EXEC SQL SET LOCK MODE TO WAIT;
    EXEC SQL BEGIN WORK;

    StlFirst=StlCurr=StlLast=NULL;     /* clear list pointer first */

    /*�o�춷�鵲 ��settlement  from ca_local_stl */

    rc=(long)CheckSerialIAdjust(&StlFirst, &StlCurr, &StlLast, CACmaxp_2);

    if (rc != SUCCESS)
    {
       EXEC SQL WHENEVER SQLERROR CONTINUE;
       EXEC SQL ROLLBACK WORK;
       return rc;
    }

    EXEC SQL WHENEVER SQLERROR GOTO optP_err;      /* resume error handling */

    printf("-> enter P2\n");

    if ((list=get_sysdb_list(&db_num, DBname)) == (char*)0)
    {
       strcpy(err_buf,"get_sysdb_list ERROR");
       $WHENEVER SQLERROR CONTINUE;
       $ROLLBACK WORK;
       return M_CM_NOT_DBLIST;
    }
    $WHENEVER SQLERROR GOTO optP_err;

    sIclaim_cnt = 0;
    dProcCnt = 0;

    $SELECT iclaim, ivictim, iins_item, flast, (ivictim||iins_item) iins_type
       FROM newa00:ca_stl_victim
      WHERE iclaim = '!'
      into temp stl;

    StlCurr=StlFirst;
    while (StlCurr)
    {
          strcpy(fstl,StlCurr->fstl);
          iclose_type=StlCurr->iclose_type;
          strcpy(ipolicy,StlCurr->ipolicy);
          strcpy(iclaim,StlCurr->iclaim);

          /* strncpy(dbsub,ipolicy,2); */
          /***add by cjli 05.26*******/
          if ((rtncode = split_policy(ipolicy, sIpolicy1, sIpolicy2)) != M_CM_OK)
          {
              sprintf(err_buf, "split_policy[%s]", ipolicy);
              EXEC SQL WHENEVER SQLERROR CONTINUE;
              EXEC SQL ROLLBACK WORK;
              return rtncode ;
          }
          EXEC SQL WHENEVER SQLERROR GOTO optP_err;
          /***************************/

          rtncode = cm_get_unit_in(sIpolicy1, DBname," " , sIunit,"C3"
                                   ,dbsub, sIbranch_in);
          if(rtncode != M_CM_OK)
          {
              sprintf(err_buf, "cm_get_unit_in[%s]", sIpolicy1);
              EXEC SQL WHENEVER SQLERROR CONTINUE;
              EXEC SQL ROLLBACK WORK;
              return  rtncode ;
          }
          EXEC SQL WHENEVER SQLERROR GOTO optP_err;

          strcpy(sFullName_ply,get_full_dbname(dbsub));

          memset(err_buf,0,sizeof(err_buf));
          strcpy(err_buf,"select settlement iclose:");
          strcat(err_buf,iclaim);
          strcat(err_buf," fstl:");
          strcat(err_buf,fstl);
          strcat(err_buf," iclose_tp:");
          strcat(err_buf,itoa(iclose_type));

          /* AOI table,data type of iclose_type is char */
          sprintf (sclose_type," %d ",iclose_type );
          printf ("sclose_type[%s]",sclose_type);
          strcpy(irecvory, "");
          sprintf(sStmt, "SELECT frecover, fsale, icard, msettle, fcard_class, \
                                 iser_rec, ioth_duty, istl_flag, irecvory, fabandon  \
                            FROM %s:settlement \
                           WHERE iclaim=? AND iclose_type = ? AND fstl= ? ",
                  sFullName_ply);
          EXEC SQL PREPARE p3_1 FROM       :sStmt;
          EXEC SQL DECLARE STL1 CURSOR FOR p3_1;
          EXEC SQL OPEN    STL1 USING      :iclaim, :iclose_type, :fstl;
          while (1)
          {
              msettle=0;

              EXEC SQL FETCH STL1 INTO :frecover, :fsale, :icard, :msettle, :fcard_class,
                                       :iser_rec, :ioth_duty, :sIstl_flag, :irecvory, :fabandon;
              if (NOT_FOUND) break;

              printf("Define If Insert into recovery \n");
              printf("----------iclaim[%s] frecover[%s] fsale[%s]\n",iclaim,frecover,fsale);

              memset(err_buf,0,sizeof(err_buf));
              strcpy(err_buf,"select appraisal iclaim:");
              strcat(err_buf,iclaim);

              sprintf(sStmt,"SELECT a.iacc_reason, a.fpart, a.iadjuster, b.itag, a.message_tel \
                               FROM %s:appraisal a, %s:adjustment_ply b \
                              WHERE a.iclaim = b.iclaim \
                                and a.iclaim= ? ", sFullName_ply, sFullName_ply);
              EXEC SQL PREPARE p3_2       FROM       :sStmt;
              EXEC SQL DECLARE p32_cursor CURSOR FOR p3_2;
              EXEC SQL OPEN    p32_cursor USING      :iclaim;
              EXEC SQL FETCH   p32_cursor INTO       :iacc_reason ,:fpart, :iadjuster, :sitag, :message_tel;
              EXEC SQL CLOSE   p32_cursor;
              EXEC SQL FREE    p32_cursor;

/******************************************************************************/
/**** fstl     ==> 1.�ߥI     2.�l�v                                       ****/
/**** frecover ==> 0.���ݰl�v 1.�ۦ�l�v 2.�w�ۦ�l�v 3.�k�Ȱl�v           ****/
/****              4.�ۦ�l�v��k�Ȱl�v                                    ****/
/**** fsale    ==> 0.���ݩ�� 1.�ݩ��                                     ****/
/**** frecov   ==> 0.�����l�v 1.�l�v�� 2.���l�v 3.�����l�v 4.�P�M�T�w    ****/
/**** fsal     ==> 0.������� 1.��椤 2.����� 3.������� 4.�M�^�լd    ****/
/**** �߮פ����פ��(dclose)�C���鵲��g�J�̷s���鵲��                     ****/
/**** �ߥI�`�B���ӽ߮פ��ߥI�p��ѦU���ߥI���B���`�X�p,�ä�������l�v�Ω��****/
/**** �]�L�k���                                                           ****/
/**** �l�v���A:���ߥI�p�����J���l�v��,�h�l�v���A���i1.�l�v���j           ****/
/**** ��檬�A:���ߥI�p�����J������,�h��檬�A���i1.��椤�j           ****/
/**** �l�v����:���l�v�p�����J���l�v�O�B���̫�@����,�h�l�v���A��         ****/
/****          �i3.�l�v�����j                                              ****/
/**** ��槹��:���l�v�p�����J�����O�B���̫�@����,�h��檬�A��         ****/
/****          �i3.��槹���j                                   {          ****/
/**** �l�v�p��ѹ�󶷰l�v�M��椧�߮׶����}���l�v�p��Ѥ��o�Ϥ��l�^�����B ****/
/**** ���k��                                                               ****/
/******************************************************************************/



              if (*fstl=='1')  /*** �ߥI�p��� ***/
              {
                  printf("�ߥI��##### fstl==>[%s],frecover[%s],fsale[%s]\n",fstl,frecover,fsale);

                  /* �w�]�����l�v */
                  strcpy(re_frecover, "0");
                  strcpy(re_frecov, "0");

                  /* �㨮���� �p�G�L�l�v�޲z�h�s�W */
                  if (fcard_class[0]=='2' && strncmp(iacc_reason, "21", 2)==0) fCarStl=1;
                  else fCarStl=0;

                  /* �s�¨t�ε��O */
                  $SELECT fsystem
                     INTO $fsystem
                     FROM ca_clm_process
                    WHERE iclaim = $iclaim;
                  if (fsystem[0]=='P') fOld=1;
                  else fOld=0;

                  printf("fOld[%d]fCarStl[%d]\n", fOld, fCarStl);

                  /* ���s�t�� or �㨮���� */
                  if (fOld==1 || fCarStl==1)
                  {
                      if (fOld==1)
                      {
                          sprintf(stmt,
                            "SELECT COUNT(*) \
                               FROM %s:recovery \
                              WHERE iclaim = ? ",sFullName_ply);
                          $PREPARE get_ser_1 FROM $stmt;
                          $EXECUTE get_ser_1 INTO $re_cnt USING $iclaim;
                          if (re_cnt == 0) iser_rec_new = 0;
                          else
                          {
                              sprintf(stmt," SELECT NVL(MAX(frecover), '#'), MIN(frecov) FROM %s:recovery WHERE iclaim = ? ",sFullName_ply);
                        	  $PREPARE recovery_id00 FROM $stmt;
                        	  $EXECUTE recovery_id00 INTO $re_frecover, $re_frecov USING $iclaim;
                          }
                      }
                      else
                      {
                          sprintf(stmt,
                           " SELECT NVL(MAX(iser_rec), 0) + 1 \
                               FROM %s:recovery \
                              WHERE iclaim = ? ",sFullName_ply);
                          $PREPARE get_ser_2 FROM $stmt;
                          $EXECUTE get_ser_2 INTO $iser_rec_new USING $iclaim;
                          re_cnt = 0;

                          if (fCarStl==1)
                          {
                              /* �㨮���� �p�G���l�v�޲z�h���s�W */
                              sprintf(stmt,
                                "SELECT COUNT(*) \
                                   FROM %s:recovery \
                                  WHERE iclaim = ? ",sFullName_ply);
                              $PREPARE get_ser_3 FROM $stmt;
                              $EXECUTE get_ser_3 INTO $re_cnt USING $iclaim;
                          }
                      }

                      printf("re_cnt[%d]\n",re_cnt);

                      /* pduty_rec, 0 �ݷf�t�l�v�޲z�{���W�u */

                      if (re_cnt == 0)
                      {

                       /*
                       sprintf(stmt,
                          "INSERT INTO %s:recovery (iclaim,iser_rec,ipolicy,icard,dclose, \
                                                    iacc_reason,fpart,msettle,frecover, \
                                                    frecov,fsale,fsal,mrecov,msal_done,lawgiver,ientry, \
                                                    iupdate, dentry, dupdate) \
                              VALUES (?,?,?,?,?, ?,?,0,'0','0','0','0',0,0,?,?,?,current,current)", sFullName_ply);
                       */


                       sprintf(stmt,
                          "INSERT INTO %s:recovery (iclaim,iser_rec,ipolicy,icard,dclose, \
                                                    iacc_reason,fpart,msettle,frecover, \
                                                    frecov,fsale,fsal,mrecov,msal_done,lawgiver,ientry, \
                                                    iupdate, dentry, dupdate, pduty_rec,iexec_type,frecov_out2) \
                              VALUES (?,?,?,?,?, ?,?,0,'0','0','0','0',0,0,?,?,?,current,current, 0,'0',' ')", sFullName_ply);


                           printf("stmt[%s]\n",stmt);
                           $PREPARE st_id02 FROM $stmt;
                           $EXECUTE st_id02
                              USING :iclaim,:iser_rec_new,:ipolicy,:icard,:stldate,
                                    :iacc_reason,:fpart,:iadjuster, :userid, :userid;

                          if (fCarStl==1)
                          {
                              sprintf(stmt,"UPDATE %s:recovery \
                                                SET (irec_kind,frecov_out,iobject,fsale_method, itag_oth) \
                                                  = ('3','0','1','1', ?) \
                                              WHERE iclaim = ? AND iser_rec = ? ", sFullName_ply);

                              printf("stmt[%s]\n",stmt);
                              $PREPARE st_id03 FROM  $stmt;
                              $EXECUTE st_id03 USING $sitag, $iclaim, $iser_rec_new;

                              printf("stmt_OK[%s]\n",stmt);
                          }
                      }
                  }
                  else if (frecover[0]!='0' && frecover[0]!='2')
                  {
                      /* �D�����l�v&�D�w�۰l */
                      sprintf(stmt," SELECT NVL(MAX(frecover), '#'), MIN(frecov) FROM %s:recovery WHERE iclaim = ? ",sFullName_ply);
                      $PREPARE recovery_id01 FROM $stmt;
                      $EXECUTE recovery_id01 INTO $re_frecover, $re_frecov USING $iclaim;
                      if (re_frecover[0] == '#')
                      {
                          sprintf(err_buf, "�ߥI�L�l�v�޲z �׸�[%s]", iclaim);
                          EXEC SQL WHENEVER SQLERROR CONTINUE;
                          EXEC SQL ROLLBACK WORK;
                          return M_CM_NOT_FOUND;
                      }
                      EXEC SQL WHENEVER SQLERROR GOTO optP_err;
    			  }

                  /**** �ݰl�v�ݩ�椧�߮� *****/

/*                  if ((*frecover != '0') && (*frecover != '2')){
                        strcpy(frecov,"1");
                  }

                  if (*frecover == '2') strcpy(frecov,"3");*/
                  /*���l<�w�۰l<�۰l<�k�l<�k�l or �۰l��k�l<�����l�v or ���l�v*/
				  if ((re_frecov[0] == '2') || (re_frecov[0] == '3'))
				  {
					  strcpy(re_frecover,re_frecover);
				  }
				  else
				  {
					  if (re_frecover[0] == '0')
					  {
						  strcpy(re_frecover, frecover);
					  }
					  else if ((re_frecover[0] == '2') && (*frecover != '0'))
					  {
						  strcpy(re_frecover, frecover);
					  }
					  else if ((re_frecover[0] == '1') && (*frecover != '0') && (*frecover != '2'))
					  {
						  strcpy(re_frecover, frecover);
					  }
					  else
					  {
						  strcpy(re_frecover,re_frecover);
					  }
				  }

                  if (*fsale != '0') strcpy(fsal,"1");


                  printf("####### frecov[%s] , fsal[%s]\n",frecov,fsal);

                  memset(err_buf,0,sizeof(err_buf));
                  strcpy(err_buf,"update recovery:");
                  
				  /*** 582���w�۰l�ɡA�n�b�������l�v��W�l�v�����B�l�v��� ***/
				  /* ����G������e583���w�۰l�B�l�v���B�l�v����Gnull�B�l�v�H���P�g�� */
				  if(frecover[0] == '2')
				  {
					printf("���������� iadjuster[%s] , iclaim[%s]\n",iadjuster,iclaim);				
					  
					sprintf(sStmt,"UPDATE %s:recovery        \
									  SET frecov = '3', drecov = ?  \
									WHERE iclaim = ? AND frecover = '2' AND frecov = '1' AND drecov IS NULL AND lawgiver = ? ",
							sFullName_ply);
					EXEC SQL PREPARE frecover2 FROM  :sStmt;
					EXEC SQL EXECUTE frecover2 USING :stldate, :iclaim ,:iadjuster ;					  
				  }

                  total_msettle     = 0;
                  total_msettle_rec = 0;
                  total_mfee        = 0;
                  mmrecov           = 0;

                  /*** �ߥI�`�B ***/
                  sprintf(sStmt, "SELECT sum(msettle) \
                                    FROM %s:settlement \
                                   WHERE iclaim=? AND fstl='1' ",
                          sFullName_ply);
                  EXEC SQL PREPARE total_1    FROM       :sStmt;
                  EXEC SQL DECLARE STL1_TOTAL CURSOR FOR total_1;
                  EXEC SQL OPEN    STL1_TOTAL USING      :iclaim;
                  EXEC SQL FETCH   STL1_TOTAL INTO       :total_msettle;
                  EXEC SQL CLOSE   STL1_TOTAL;
                  EXEC SQL FREE    STL1_TOTAL;

/*                  if (*frecover != '0')
                      sprintf(sWh1," ,frecover = '%s',frecov = '%s' ",frecover,frecov);
                  else
                      strcpy(sWh1," ");*/
/*
                  if(*frecover != '0')
                    sprintf(sWh1, " ,frecover = '%s' ", re_frecover);
                  else
                    strcpy(sWh1," ");
                  �]���z�ߤH���Ϊk�ȤH���|�]�w�U���ưl�v�O�A�ҥH�����קאּ�ۦP���l�v�O
*/
                  strcpy(sWh1," ");

                  if (*fsale != '0')
                      sprintf(sWh2," ,fsale = '%s',fsal = '%s' ",fsale,fsal);
                  else
                      strcpy(sWh2," ");

                  /* 981130�s�t�Τ~�����l�v���B */
                  if (fOld==0)
                  {
                      /* ���l�v���B=�z�ߪ��B*���F�d */
                      mmrecov = total_msettle*ioth_duty/100;
                      sprintf(sWh3," ,mmrecov = %ld ", mmrecov);

                      /* 1001229�]�z�ߤH����J�����B�|�Q�ﱼ�A�G���A������l���B */
                      strcpy(sWh3," ");
                  }
                  else strcpy(sWh3," ");

                  sprintf(sStmt,"UPDATE %s:recovery        \
                                    SET msettle = ?, dclose = ? %s %s %s \
                                  WHERE iclaim = '%s' AND dclose is null ",
                          sFullName_ply, sWh1,sWh2,sWh3,iclaim);
                  printf("sStmt[%s]\n",sStmt);
                  EXEC SQL PREPARE p3_6 FROM  :sStmt;
                  EXEC SQL EXECUTE p3_6 USING :total_msettle, :stldate;

                  

                  if (fabandon[0] != ' ' && fabandon[0] != '0')
                  {
                      sprintf(sStmt,"UPDATE %s:recovery                \
                                        SET frecov = '2', drecov = ?   \
                                      WHERE iclaim =  ?                \
                                        AND iclose_type = ? ", sFullName_ply);
                      printf(" setAban sStmt[%s], iclaim[%s], fabandon[%s] \n", sStmt, iclaim, fabandon);
                      $PREPARE setAban FROM $sStmt;
                      $EXECUTE setAban USING $stldate, $iclaim, $iclose_type;
                  }
                  else
                  {
                      /*  ��Ӧ�2��H�W����訮�F�d > 100%�� , �Yuser��583�I����l�v�z��, 
                            5083�۰ʦ^�g���A��2.���l�v, ��ӻP�t���^�Ц��ؤ覡���̭�y�{
                            ��585�l�v�z�������l�v�ɤ~�^�g
                      
                      sprintf(sStmt,"UPDATE %s:recovery                \
                                        SET frecov = '2', drecov = ?   \
                                      WHERE iclaim =  ?                \
                                        AND iclose_type = ?            \
                                        AND trim(nreason_aban) != '' ", sFullName_ply);
                      printf(" setAban2 sStmt[%s], iclaim[%s], fabandon[%s] \n", sStmt, iclaim, fabandon);
                      $PREPARE setAban2 FROM $sStmt;
                      $EXECUTE setAban2 USING $stldate, $iclaim, $iclose_type;
                      */
                  }
              }
              else if (*fstl=='2')     /*** �l�v�p��� ***/
              {
                  printf("�l�v��##### fstl==>[%s],frecover[%s],fsale[%s]\n",fstl,frecover,fsale);

                  if (strlen(trim(frecover)) != 0) /**** ���l�v�ʽ褧�߮� *****/
                  {
                       if (*frecover == '1')
                       {
                           sprintf(stmt, "SELECT frecov FROM %s:recovery WHERE iclaim = ? AND iser_rec = ? ", sFullName_ply);
                           $PREPARE recovery_id02 FROM $stmt;
                           $EXECUTE recovery_id02 INTO $re_frecov USING $iclaim, $iser_rec;
                           if (SQLCODE == SQLNOTFOUND)
                           {
                               sprintf(err_buf, "�l�v�L�l�v�޲z �׸�[%s]�Ǹ�[%d]", iclaim, iser_rec);
                               EXEC SQL WHENEVER SQLERROR CONTINUE;
                               EXEC SQL ROLLBACK WORK;
                               return M_CM_NOT_FOUND;
                           }
                           if (re_frecov[0]=='4') strcpy(frecov, re_frecov);
                           else strcpy(frecov, frecover);
                       }
                       else strcpy(frecov, frecover);
                       printf("�l�v\n");
                       memset(err_buf,0,sizeof(err_buf));
                       strcpy(err_buf,"update recovery iclaim:");
                       strcat(err_buf,iclaim);

                       /**** �l�v���B�����:�l�v���B--�w�l�^���B ****/
                       total_msettle     = 0;
                       total_msettle_rec = 0;
                       total_mfee        = 0;

                       /*
                       sprintf(sStmt, "SELECT sum(msettle) , sum(mdmg_proc+mlia_proc) \
                                         FROM %s:settlement \
                                        WHERE iclaim = ? \
                                          AND fstl = '2' \
                                          AND frecover <> '0' AND frecover <> '' AND frecover is not null",
                               sFullName_ply);
                       EXEC SQL PREPARE total_21    FROM       :sStmt;
                       EXEC SQL DECLARE STL21_TOTAL CURSOR FOR total_21;
                       EXEC SQL OPEN    STL21_TOTAL USING      :iclaim;
                       EXEC SQL FETCH   STL21_TOTAL INTO       :total_msettle_rec , :total_mfee;
                       EXEC SQL CLOSE   STL21_TOTAL;
                       EXEC SQL FREE    STL21_TOTAL;
                       */

                       if (fcard_class[0]=='2')
                       {
                           sprintf(sStmt, "SELECT NVL(SUM(b.mins_stl), 0), NVL(SUM(b.mins_proc), 0) \
                                             FROM %s:settlement a, %s:stl_ins_type b \
                                            WHERE a.iclaim = b.iclaim \
                                              AND a.fstl = b.fstl \
                                              AND a.iclose_type = b.iclose_type \
                                              AND a.iclaim = ? AND a.iser_rec = ? \
                                              AND a.fstl = '2' \
                                              AND a.frecover <> '0' AND a.frecover <> '' AND a.frecover is not null",
                                   sFullName_ply, sFullName_ply);
                           EXEC SQL PREPARE total_21_1 FROM :sStmt;
                           EXEC SQL DECLARE STL21_TOTAL_1 CURSOR FOR total_21_1;
                           EXEC SQL OPEN    STL21_TOTAL_1 USING :iclaim, :iser_rec;
                           EXEC SQL FETCH   STL21_TOTAL_1 INTO :total_msettle_rec, :total_mfee;
                           EXEC SQL CLOSE   STL21_TOTAL_1;
                           EXEC SQL FREE    STL21_TOTAL_1;
                       }
                       else
                       {
                           sprintf(sStmt, "SELECT NVL(SUM(b.mins_stl+b.mstl_health), 0), NVL(SUM(b.mins_proc), 0) \
                                             FROM %s:settlement a, %s:ca_stl_victim b \
                                            WHERE a.iclaim = b.iclaim \
                                              AND a.fstl = b.fstl \
                                              AND a.iclose_type = b.iclose_type \
                                              AND a.iclaim = ? AND a.iser_rec = ? \
                                              AND a.fstl = '2' \
                                              AND a.frecover <> '0' AND a.frecover <> '' AND a.frecover is not null",
                                   sFullName_ply, sFullName_ply);
                           EXEC SQL PREPARE total_21_2 FROM :sStmt;
                           EXEC SQL DECLARE STL21_TOTAL_2 CURSOR FOR total_21_2;
                           EXEC SQL OPEN    STL21_TOTAL_2 USING :iclaim, :iser_rec;
                           EXEC SQL FETCH   STL21_TOTAL_2 INTO :total_msettle_rec, :total_mfee;
                           EXEC SQL CLOSE   STL21_TOTAL_2;
                           EXEC SQL FREE    STL21_TOTAL_2;
                       }

                       /* 
                       ���q�P�_�Y�w��582�g�J��recovery��ơA�w�]582���O���l�v�۰ʦ^�g�l�v����A
                       �h���A�^�㤧�e�w�^�㪺�l�v���
                       */
                       sprintf(stmt, "SELECT count(*)         \
                                        FROM %s:recovery      \
                                       WHERE iclaim = ?       \
                                         AND iser_rec = ?     \
                                         AND iclose_type <> 0 \
                                         AND drecov is not null ", sFullName_ply);
                       printf("frecov stmt[%s] iclaim[%s] iser_rec[%d]\n", stmt, iclaim, iser_rec);
                       $PREPARE recovery_id0222 FROM $stmt;
                       $EXECUTE recovery_id0222 
                           INTO $tmp_count
                          USING $iclaim, $iser_rec;
                       if (tmp_count == 0)
                       {
                           sprintf(sStmt, "UPDATE %s:recovery \
                                              SET drecov = ?, mrecov = ?, mfee = ?, frecov = ? \
                                            WHERE iclaim = '%s' AND iser_rec = %d ", sFullName_ply, iclaim, iser_rec);
                           printf("sStmt[%s]\n", sStmt);
                           EXEC SQL PREPARE p3_6b FROM  :sStmt;
                           EXEC SQL EXECUTE p3_6b USING :stldate , :total_msettle_rec, :total_mfee, :frecov;
                       }
                       else
                       {
                           /* ��582�s�W��recovery�l�v��� */
                           sprintf(sStmt, "UPDATE %s:recovery \
                                              SET mrecov = ?, mfee = ?, frecov = ? \
                                            WHERE iclaim = '%s' AND iser_rec = %d ", sFullName_ply, iclaim, iser_rec);
                           printf("sStmt[%s]\n", sStmt);
                           EXEC SQL PREPARE p3_6by6 FROM  :sStmt;
                           EXEC SQL EXECUTE p3_6by6 USING :total_msettle_rec, :total_mfee, :frecov;
                       }

                       if (sqlca.sqlerrd[2]==0)
                       {
                           sprintf(err_buf, "�L�l�v�޲z �׸�[%s]�Ǹ�[%d]", iclaim, iser_rec);
                           EXEC SQL WHENEVER SQLERROR CONTINUE;
                           EXEC SQL ROLLBACK WORK;
                           return M_CM_NOT_FOUND;
                       }
                       EXEC SQL WHENEVER SQLERROR GOTO optP_err;

                  }

                  if (strlen(trim(fsale)) != 0) /**** �����ʽ褧�߮� *****/
                  {

                       strcpy(fsal,fsale);
                       printf("���\n");
                       memset(err_buf,0,sizeof(err_buf));
                       strcpy(err_buf,"update recovery iclaim:");
                       strcat(err_buf,iclaim);

                       /**** �l�v���B�����:�����B ****/
                       total_msettle = 0;
                       /*
                       sprintf(sStmt, "SELECT sum(msettle) , sum(mdmg_proc+mlia_proc) \
                                         FROM %s:settlement \
                                        WHERE iclaim = ? \
                                          AND fstl = '2' \
                                          AND fsale <> '0' \
                                          AND fsale <> '' \
                                          AND fsale is not null",
                               sFullName_ply);
                       EXEC SQL PREPARE total_23    FROM       :sStmt;
                       EXEC SQL DECLARE STL23_TOTAL CURSOR FOR total_23;
                       EXEC SQL OPEN    STL23_TOTAL USING      :iclaim;
                       EXEC SQL FETCH   STL23_TOTAL INTO       :total_msettle_rec , :total_mfee;
                       EXEC SQL CLOSE   STL23_TOTAL;
                       EXEC SQL FREE    STL23_TOTAL;
                       */
                       if (fcard_class[0]=='2')
                       {
                           sprintf(sStmt, "SELECT NVL(SUM(b.mins_stl), 0), NVL(SUM(b.mins_proc), 0) \
                                             FROM %s:settlement a, %s:stl_ins_type b \
                                            WHERE a.iclaim = b.iclaim \
                                              AND a.fstl = b.fstl \
                                              AND a.iclose_type = b.iclose_type \
                                              AND a.iclaim = ? AND a.iser_rec = ? \
                                              AND a.fstl = '2' \
                                              AND a.fsale <> '0' \
                                              AND a.fsale <> '' \
                                              AND a.fsale is not null",
                                   sFullName_ply, sFullName_ply);
                           EXEC SQL PREPARE total_23_1    FROM       :sStmt;
                           EXEC SQL DECLARE STL23_TOTAL_1 CURSOR FOR total_23_1;
                           EXEC SQL OPEN    STL23_TOTAL_1 USING      :iclaim, :iser_rec;
                           EXEC SQL FETCH   STL23_TOTAL_1 INTO       :total_msettle_rec , :total_mfee;
                           EXEC SQL CLOSE   STL23_TOTAL_1;
                           EXEC SQL FREE    STL23_TOTAL_1;
                       }
                       else
                       {
                           /* �l�v������Ӥ��|���j�� */
                           sprintf(sStmt, "SELECT NVL(SUM(b.mins_stl+b.mstl_health), 0), NVL(SUM(b.mins_proc), 0) \
                                             FROM %s:settlement a, %s:ca_stl_victim b \
                                            WHERE a.iclaim = b.iclaim \
                                              AND a.fstl = b.fstl \
                                              AND a.iclose_type = b.iclose_type \
                                              AND a.iclaim = ? AND a.iser_rec = ? \
                                              AND a.fstl = '2' \
                                              AND a.fsale <> '0' \
                                              AND a.fsale <> '' \
                                              AND a.fsale is not null",
                                   sFullName_ply, sFullName_ply);
                           EXEC SQL PREPARE total_23_2    FROM       :sStmt;
                           EXEC SQL DECLARE STL23_TOTAL_2 CURSOR FOR total_23_2;
                           EXEC SQL OPEN    STL23_TOTAL_2 USING      :iclaim, :iser_rec;
                           EXEC SQL FETCH   STL23_TOTAL_2 INTO       :total_msettle_rec , :total_mfee;
                           EXEC SQL CLOSE   STL23_TOTAL_2;
                           EXEC SQL FREE    STL23_TOTAL_2;
                       }

                       sprintf(sStmt, "UPDATE %s:recovery \
                                          SET dsal = ?, msal_done = ?, msal_fee = ?, fsal = ? \
                                        WHERE iclaim = '%s' AND iser_rec = %d ", sFullName_ply, iclaim, iser_rec);
                       printf("sStmt[%s]\n",sStmt);
                       EXEC SQL PREPARE p3_6c FROM  :sStmt;
                       EXEC SQL EXECUTE p3_6c USING :stldate , :total_msettle_rec , :total_mfee, :fsal;

                       if (sqlca.sqlerrd[2]==0)
                       {
                           sprintf(err_buf, "���L�l�v�޲z �׸�[%s]�Ǹ�[%d]", iclaim, iser_rec);
                           EXEC SQL WHENEVER SQLERROR CONTINUE;
                           EXEC SQL ROLLBACK WORK;
                           return M_CM_NOT_FOUND;
                       }
                       EXEC SQL WHENEVER SQLERROR GOTO optP_err;
                  }

              }

              /***********************************************************
               * P23
               * Update every database: reject_client,customer_quota
               ***********************************************************/

              /* fpart=1 ���l, reason=21 �㨮�Q��, reason=23 �㨮�Q�ѴM�^ */
			  stpcpy(iadjuster,trim(iadjuster));
			  stpcpy(iclaim,trim(iclaim));
			  sprintf(REJECT_REMARK,"; �z�ߤH���G%s; �߮׸��X�G%s",iadjuster,iclaim);
              if(*fpart == '1' ||
                 *fpart == '2' ||
                 *fpart == '3' ||
                 strcmp(iacc_reason, "21") == 0 ||
                 strcmp(iacc_reason, "23") == 0 )
              {
                   int       iTmp;
                   /* $char     stmt[500]; ���Ыŧi */
                   $char     cItag[CA_TAG_NUM], cIengine[CA_ENGINE_NUM], cIbody[CA_BODY_NUM];

                   printf("******[�ګO�B�z]******\n");

                   memset(err_buf,0,sizeof(err_buf));
                   strcpy(err_buf,"select adjustment_ply iclaim:");
                   strcat(err_buf,iclaim);

                   sprintf(sStmt, "SELECT iengine, ibody, itag \
                                     FROM %s:adjustment_ply \
                                    WHERE iclaim = '%s'",
                           sFullName_ply, iclaim);
                   $PREPARE p3_46 FROM $sStmt;
                   $DECLARE p346_cursor CURSOR FOR p3_46;
                   $OPEN p346_cursor;
                   $FETCH p346_cursor INTO $cIengine, $cIbody, $cItag;
                   $CLOSE p346_cursor;
                   $FREE  p346_cursor;
                   printf("tag[%s],eng[%s],body[%s]\n",cItag,cIengine,cIbody);

                   for(iTmp=0; iTmp < db_num; iTmp++)
                   {

                       if(*fpart == '2'|| *fpart =='3' )  /* ���l */
                       {
                          printf("[�ګO�B�z-���l] 1\n");
                          $WHENEVER SQLERROR CONTINUE;
                          memset(err_buf,0,sizeof(err_buf));
                          strcpy(err_buf,"insert reject_client:fpart=1");

                          strcpy(freason_tmp, "3");
						  $execute get_reject_cnt
							  into $ireject_cnt
							 using $sSpace, $sSpace, $cItag, $cIengine, $cIbody, $freason_tmp;

						  if (ireject_cnt == 0)
						  {
							sprintf(REJECT_REMARK_TMP,"���l%s",REJECT_REMARK);
							
						    sprintf(stmt," INSERT INTO %s:reject_client \
										 (nassured, ilicense, itag, \
									  iengine, ibody, freason, remark, icreate, dcreate)  \
								 VALUES (' ', ' ', ?, ?, ?, '3', ?, 'car5083', today)",
											 list[iTmp].dbname);

						    printf("stmt = %s \n", stmt);

						    $PREPARE s2 FROM $stmt;
						    $EXECUTE s2 USING $cItag, $cIengine, $cIbody, $REJECT_REMARK_TMP;
							
						    printf("[�ګO�B�z-���l] SQL = %ld \n", SQLCODE);

						    if (SQLCODE==-239) continue;
						  }
						  $WHENEVER SQLERROR GOTO optP_err;

                       }
                       else if (strcmp(iacc_reason, "23") == 0)
                       {
                          printf("[�ګO�B�z-(23)]\n");
                          memset(err_buf,0,sizeof(err_buf));
                          strcpy(err_buf,"delete reject_client:iacc_reason=23");

                          sprintf(stmt,"DELETE FROM %s:reject_client \
                                         WHERE freason = '2' AND itag = ? \
                                           AND iengine = ? AND ibody = ?",
                                                    list[iTmp].dbname);
                          $PREPARE s2_2 FROM $stmt;
                          $EXECUTE s2_2 USING $cItag, $cIengine, $cIbody;
                       }
                       else if ( *fpart =='1' && strcmp(iacc_reason, "21") == 0)
                       {
                          printf("[�ګO�B�z-(21)]\n");
                          $WHENEVER SQLERROR CONTINUE;
                          memset(err_buf,0,sizeof(err_buf));
                          strcpy(err_buf,"insert reject_client:iacc_reason=21");

                          strcpy(freason_tmp, "2");
						  $execute get_reject_cnt
							  into $ireject_cnt
							 using $sSpace, $sSpace, $cItag, $cIengine, $cIbody, $freason_tmp;

						  if (ireject_cnt == 0)
						  {
							sprintf(REJECT_REMARK_TMP,"�㨮�Q��%s",REJECT_REMARK);
							sprintf(stmt,"INSERT INTO %s:reject_client \
									(nassured, ilicense, itag, \
									iengine, ibody, freason, remark, icreate, dcreate)  \
									VALUES (' ', ' ', ?, ?, ?, '2', ?, 'car5083', today)",
									list[iTmp].dbname);
							$PREPARE s2_1 FROM $stmt;
							$EXECUTE s2_1 USING $cItag, $cIengine, $cIbody, $REJECT_REMARK_TMP;

							printf("[�ګO�B�z-�㨮�Q��] SQL = %ld \n", SQLCODE);

							if (SQLCODE==-239) continue;
						  }
                          $WHENEVER SQLERROR GOTO optP_err;
                       }
                   } /* for */
              }
          }  /* settlement end-while */
          $CLOSE STL1;
          $FREE STL1;

          /* �ˮֲz�߸g��O�_�^�Ъ��Ю֥��ƶ� add by larry 103.08.07 (1030417003_C2)*/
          /* car546��J�����L���ˮ� modify by Winnie 112.12.05(1120704003_A04)  */
          /* car539��J�����L���ˮ� modify by sylvia 107.07.30(1070724004_SC1)  */
          /* car537(���O�l�v����)�Bcar540(��Q�I����)��J�����L���ˮ� modify by sylvia 108.03.29 (1070705004_SC1  */
          /* car926(�j���I�P�~�F�d���u) ��J�����L���ˮ� modify by sylvia 110.09.09 (1100608003_SC2)  */
          if (((strcmp(dclosing_type,"A") == 0) || (strcmp(dclosing_type,"B") == 0) ||
               (strcmp(dclosing_type,"T") == 0) || (strcmp(dclosing_type,"C") == 0) || (strcmp(dclosing_type,"F") == 0))
               && (strlen(sItransno) > 10))
          {
                dProcCnt = 0;
          }
          else
          {
              $SELECT count(iclaim) INTO $dProcCnt
                 FROM ca_clm_recheck
                WHERE iclaim = $iclaim
                  AND dproc is null;
                if (dProcCnt > 0)
                {
              	  sIclaim_cnt++;
              	  if (sIclaim_cnt == 1)
              	  {
                   	     strcpy(sIclaim, iclaim);
              	  }
              	  else
              	  {
                         if (sIclaim_cnt < 12)
                         {
              	        strcat(sIclaim,"�B");
              	        strcat(sIclaim, iclaim);
              	     }
              	  }
                }
           }
          /* �M�����׭��}���O */
          StlCurr=StlCurr->next;
    }

    if (sIclaim_cnt > 0)
    {
       strcpy(sIclaim,trim(sIclaim));
       sprintf(err_buf, "�׸�[%s]�A�|���^�вz�ߥD��/���ɭ����Ю֥��ƶ��A�Щ�^�Ы�A��鵲�C", sIclaim);
       EXEC SQL WHENEVER SQLERROR CONTINUE;
       EXEC SQL ROLLBACK WORK;
       return M_CM_NOT_FOUND;
    }


    $WHENEVER SQLERROR GOTO optP_err;

    /**** STEP P4 *****************************************/
    /**** �^�g��Ʀ� ao_stl_close_dtl (�z�߱b�ک�����)
                     ao_stl_close     (�z�߱b����)
                     ao_stl_obj_close (�ߥI��H������)
                     cm_stl_info      (�O��߮׸����)
                     ca_sign_receipt  (ñ����H��)
     ******************************************************/
    printf("-> enter P4\n");

    StlCurr=StlFirst;
    while (StlCurr)
    {
        sclose_type[0]=NULL;
        strcpy(iclaim    ,StlCurr->iclaim);
        iclose_type=StlCurr->iclose_type;
        strcpy(ipolicy    ,StlCurr->ipolicy);
        strcpy(fstl       ,StlCurr->fstl);

        if ((rtncode = split_policy(ipolicy, sIpolicy1, sIpolicy2)) != M_CM_OK)
        {
            sprintf(err_buf, "P4 split_policy[%s]", ipolicy);
            EXEC SQL WHENEVER SQLERROR CONTINUE;
            EXEC SQL ROLLBACK WORK;
            return rtncode;
        }
        EXEC SQL WHENEVER SQLERROR GOTO optP_err;

        rtncode = cm_get_unit_in(sIpolicy1, DBname," " , sIunit,"C3",
                                 dbsub, sIbranch_in);
        if(rtncode != M_CM_OK)
        {
            sprintf(err_buf, "P4 cm_get_unit_in[%s]", sIpolicy1);
            EXEC SQL WHENEVER SQLERROR CONTINUE;
            EXEC SQL ROLLBACK WORK;
            return rtncode;
        }
        EXEC SQL WHENEVER SQLERROR GOTO optP_err;

        strcpy(sFullName_ply, get_full_dbname(dbsub));
        strcpy(sFullName_loc, get_full_dbname(DBname));
        sprintf (sclose_type,"%d",iclose_type);

        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"P.3--(6):select settlement iclose:");
        strcat(err_buf," iclose_tp:");
        strcat(err_buf,itoa(iclose_type));

        /** �d��-�p����� **/

        sprintf(sStmt,
	  "SELECT dply_begin,dply_end,icar_type   \
	     FROM %s:adjustment_ply     \
	    WHERE iclaim      = ?  ",sFullName_ply);
         $PREPARE get_adj_date FROM $sStmt;

        sprintf(sStmt,
          "SELECT fsalvage,ireceive,fcard_class ,msettle ,\
                  msalvage, ipolicy[6], date(dentry), iadjuster \
             FROM %s:settlement \
            WHERE iclaim=? AND fstl=? AND iclose_type=? ", sFullName_ply);

        printf("iclaim=%s, fstl=%s , iclose_type=%d \n", iclaim, fstl, iclose_type);

        $PREPARE p3_49 FROM $sStmt;
        $DECLARE STL2 CURSOR FOR p3_49;
        $OPEN STL2 USING $iclaim,$fstl,$iclose_type;
        while (1)
        {
           /*---PREPARE FOR ao_stl_close, ao_stl_close_dtl---*/
           mstl1=mproc1=msalv1=0;
           mstl2=mproc2=msalv2=0;
           mstl3=mproc3=msalv3=0;
           mplace1=0;

           $FETCH STL2 INTO $fsalvage,$ireceive,$fcard_class, $msettle,
                            $msalvage,$ipolicy_M, $dentry, $iadjuster ;
           if (NOT_FOUND) break;

           printf("step 1-1 iclaim=%s, fstl=%s , iclose_type=%d \n", iclaim, fstl, iclose_type);

           mdmg_proc = lGetStlVal(sFullName_ply, "2", "1", iclaim, fstl, iclose_type);
           mlia_proc = lGetStlVal(sFullName_ply, "2", "2", iclaim, fstl, iclose_type);

           /*----------------------*/
           memset(err_buf,0,sizeof(err_buf));
           strcpy(err_buf,"select appraisal, iclaim:");
           strcat(err_buf,iclaim);

           memset(iacc_reason, 0, 3);
           /** �d��-���z�w���� **/
           sprintf(sStmt, "SELECT iacc_reason FROM %s:appraisal \
                            WHERE iclaim=? ", sFullName_ply);
           $PREPARE p3_55 FROM $sStmt;
           $DECLARE APP1 CURSOR FOR p3_55;
           $OPEN  APP1 USING $iclaim;
           $FETCH APP1 INTO $iacc_reason;
           $CLOSE APP1;
           $FREE  APP1;

           /* 0990916006�^��ñ���ɤ鵲��A�t�K�ߩҥH���e�ܦ� */
           /*** update ca_sign_receipt **/
           sprintf(sStmt,"SELECT ipayment, ifpce_id_ext, qserial \
                            FROM %s:payment \
                           WHERE iclaim='%s' AND iclose_type=%d AND fstl ='%s'",
                          sFullName_ply, iclaim, iclose_type, fstl);
           $PREPARE u_sign1 FROM $sStmt;
           $DECLARE u_sign2 CURSOR for u_sign1;
           $OPEN u_sign2;
           while(1)
           {
              $FETCH u_sign2 INTO $sIfpce_id, $sIfpce_id_ext, $lQserial;
              if(SQLCODE == SQLNOTFOUND) break;

              sprintf(sStmt,"UPDATE %s:ca_sign_receipt \
                                SET dsettle = ?, dclose = ? \
                              WHERE iclaim = '%s' AND ifpce_id = '%s' \
                                AND ifpce_id_ext = '%s' AND qserial = %d ",
                            sFullName_ply, iclaim, sIfpce_id, sIfpce_id_ext, lQserial);
              $PREPARE u_sign3 FROM $sStmt;
              $EXECUTE u_sign3 USING $dentry, $stldate;

           }
           $CLOSE u_sign2;
           $FREE  u_sign2;

           /* icls_dept �X�p��Ѫ���� 860620-mag */
           /*strncpy(icls_dept,iclaim,2); icls_dept[2]='\0';*/


           /* �t�X�Q���줽�Ǥɯ�,���d��iaccount_branch  add by sylvia 107.06.20 (1070322011_SC3) */
           $Select c.iaccount_branch, c.iupcomp
              into $iaccount_branch, $icls_dept
              From ca_clm_process a, cm_clm_adjuster b, branch c
             Where a.adjustment = b.empl_no
               And b.iapp_unit = c.ibranch
               and a.iclaim = $iclaim;


           /* 870623 maggie */
           /* strncpy(icls_dept,DBname,2); icls_dept[2]='\0'; */
           /* ��@��߮׺�����@�k modify by sylvia 107.06.20 (1070322011_SC3) */
           if (strcmp(dclosing_type,"3") == 0)
           {
                memset(icls_dept, 0, 3)  ;
                strncpy(icls_dept,DBname,2); icls_dept[2]='\0';
           }


           /***** 860620-mag *************************
            * strncpy(isub,iclaim,2); isub[2]='\0';
            *
            * memset(err_buf,0,sizeof(err_buf));
            * strcpy(err_buf,"1-select claim_branch iclaim_branch:");
            * strcat(err_buf,isub);
            *
            * $SELECT iup_branch INTO $icls_dept
            *    FROM claim_branch
            *   WHERE iclaim_branch=$isub;
            ******************************************/

           memset(err_buf,0,sizeof(err_buf));
           strcpy(err_buf,"delete ao_stl_close:");
           strcat(err_buf,",");
           strcat(err_buf,iclaim);

           /*---delete ao_stl_close---*/

           $DELETE FROM ao_stl_close
             WHERE iclose      = $iclaim
               AND iclose_type = $sclose_type
               AND fstl        = $fstl
               AND fstl_sta    = 'C';
           if (sqlca.sqlerrd[2]>0)
           {
               $DELETE FROM ao_stl_close_dtl
                 WHERE iclose      = $iclaim
                   AND iclose_type = $sclose_type
                   AND fstl        = $fstl;
               $DELETE FROM ao_stl_obj_close
                 WHERE iclose      = $iclaim
                   AND iclose_type = $sclose_type
                   AND fstl        = $fstl;
               $DELETE FROM ao_stl_notes_info
                 WHERE inum1       = $iclaim
                   AND inum2       = $sclose_type
                   AND inum3       = $fstl;
           }

	   $EXECUTE get_adj_date
	       INTO $adj_begin,$adj_end,$adj_car_type
	      USING $iclaim;
/**********************************
            $SELECT fcar_class
               INTO $fcar_class
	       FROM car_type
	      WHERE fclass = '1'
	        AND icode = $adj_car_type;
***********************************/

			sprintf(sStmt,"SELECT count(*) \
						     FROM %s:payment \
                            WHERE fspeed = 'E' \
							  AND iclaim = '%s' \
							  AND fstl = '2' \
                              AND iclose_type = %d ", sFullName_ply, iclaim, iclose_type);
            $PREPARE get_s_fspeed FROM $sStmt;
			  
             iMonth = DiffMonth(adj_end,adj_begin);
             printf("iMonth[%d]\n",iMonth);
             mstl_sum  = 0;
             mproc_sum = 0;
             msalv_sum = 0;
             mplace_sum = 0;
           if (*fcard_class=='1')
           {   /*** P31 ***/
               mproc1= mlia_proc +mdmg_proc;
               mstl1=msettle;
               msalv1=msalvage;
               memset(err_buf,0,sizeof(err_buf));

               strcpy(err_buf,"select stl_ins_type,insurance_type iclose:");
               strcat(err_buf," iclose_type:");
               strcat(err_buf,itoa(iclose_type));

			   if(mstl1  < 0) mstl1  = 0; /*�߰l���B*/
			   if(mproc1 < 0) /*�O��*/
			   {
				   $EXECUTE get_s_fspeed INTO $s_cnt;
				   if (s_cnt == 0)
					   mproc1 = 0;
			   }
               if(msalv1 < 0) msalv1 = 0;
               if (mstl1 + mproc1 + msalv1 == 0) continue; /* ���e��u */

			   /*27����2008.7.22�ۥΧ���~*/
			   if (strcmp(adj_car_type,"27") == 0)
			   {
					sprintf(sStmt,"SELECT count(*) FROM %s:ply_relation \
									WHERE ipolicy = '%s'  AND dpolicy < '07/22/2008'",sFullName_ply,ipolicy);
					$PREPARE cartype_27 FROM $sStmt;
					$EXECUTE cartype_27 INTO $cartype27;
					if (cartype27 > 0)
						strcpy(adj_car_type, "03");
			   }

                           sprintf(sStmt, "select drate_ym from %s:ply_ins_type where ipolicy = '%s' and iins_type = '21' ", sFullName_ply, ipolicy);
                           $prepare get_frate_21 from $sStmt;
                           $execute get_frate_21 into $frate;

                           if (frate[0] == '\0') strcpy(frate," ");

			   rtn = get_product_code_car("C","21",adj_car_type,iMonth,iproduct,kclsfyitem,kreserve," ",frate);

			   if (rtn != M_CM_OK)
               {
                    EWRITE(userid,M_CM_NOT_FOUND,"get_product_code_car err");
                    goto optP_err;
               }
               printf("kclsfyitem[%s]\n",kclsfyitem);
                   memset(err_buf,0,sizeof(err_buf));
                   strcpy(err_buf,"insert ao_stl_close_dtl-fcard_class=1 iclose:");
                   strcat(err_buf," iclose_type:");
                   strcat(err_buf,itoa(iclose_type));
                   strcat(err_buf,kclsfyitem);

                   $UPDATE ao_stl_close_dtl
                       SET (mstl, mproc, mstl_nt, mproc_nt)
                         = (mstl + $mstl1, mproc + $mproc1, mstl_nt + $mstl1,
                            mproc_nt + $mproc1)
                     WHERE iclose      = $iclaim
                       AND iclose_type = $sclose_type
                       AND fstl        = $fstl
                       AND insure_kind = $kclsfyitem;
                   if (sqlca.sqlerrd[2] == 0)
                   {
                   $INSERT INTO ao_stl_close_dtl
                               (iclose, iclose_type, fstl, insure_kind, icur,
                                mstl, mproc,  mstl_nt, mproc_nt)
                        VALUES ($iclaim,$sclose_type,$fstl,$kclsfyitem, "NT",
                                $mstl1,$mproc1,$mstl1,$mproc1);
                   }
                   mstl_sum  = (double)(mstl1) + mstl_sum;
                   mproc_sum = (double)(mproc1) + mproc_sum;
                   msalv_sum = (double)(msalv1) + msalv_sum;
                   $WHENEVER SQLERROR GOTO optP_err;
           }
           else
           {   /**  P32 **/
               memset(err_buf,0,sizeof(err_buf));
               strcpy(err_buf,"select stl_ins_type,insurance_type iclose:");
               strcat(err_buf," iclose_type:");
               strcat(err_buf,itoa(iclose_type));

               sprintf(sStmt,
                 " SELECT a.iins_type,a.mins_stl,a.mins_proc,a.mins_salv,b.iins_ply,a.mins_place   \
                     FROM %s:stl_ins_type a inner join insurance_type b on a.iins_type = b.iins_type        \
                    WHERE a.iclaim = '%s'       \
                      AND a.fstl   = '%s'       \
                      AND a.iclose_type = %d ",sFullName_ply,iclaim,fstl,iclose_type);
                 $PREPARE get_ins FROM $sStmt;
                 $DECLARE get_ins_cur CURSOR FOR get_ins;
                 $OPEN    get_ins_cur;
                 for(;;)
                 {
                 $FETCH  get_ins_cur
                   INTO  $get_iins_type,$mstl1,$mproc1,$msalv1,$ply_ins,$mplace1;
                   if (SQLCODE == SQLNOTFOUND) break;
					sprintf(sStmt," SELECT provision, drate_ym   \
									FROM %s:ply_ins_type                          \
									WHERE ipolicy = '%s' AND iins_type = '%s' ",sFullName_ply,ipolicy,ply_ins);
					$PREPARE get_provision FROM $sStmt;
					$DECLARE get_provision_cur CURSOR FOR get_provision;
					$OPEN    get_provision_cur;
					$FETCH  get_provision_cur INTO $provision, $frate;

                   if(mstl1  < 0) mstl1  = 0;
                   if(mproc1 < 0) 
				   {
					   $EXECUTE get_s_fspeed INTO $s_cnt;
					   if (s_cnt == 0)
						   mproc1 = 0;
				   }
                   if(msalv1 < 0) msalv1 = 0;
                   if(mplace1 < 0) mplace1 = 0;

                   if ((mstl1 == 0) && (mproc1 == 0) && (msalv1 == 0) && (mplace1 == 0))
                      continue;

					/*27����2008.7.22�ۥΧ���~*/
					if (strcmp(adj_car_type,"27") == 0)
					{
						sprintf(sStmt,"SELECT count(*) FROM %s:ply_relation \
										WHERE ipolicy = '%s'  AND dpolicy < '07/22/2008'",sFullName_ply,ipolicy);
						$PREPARE cartype_27 FROM $sStmt;
						$EXECUTE cartype_27 INTO $cartype27;
						if (cartype27 > 0)
							strcpy(adj_car_type, "03");
					}

				   rtn = get_product_code_car("C",get_iins_type,adj_car_type,iMonth,iproduct,kclsfyitem,kreserve,provision,frate);
                   if (rtn != M_CM_OK)
                   {   printf("get_product_code_car err");
                       EWRITE(userid,M_CM_NOT_FOUND,"get_product_code_car err");
                       goto optP_err;
                   }
				   printf("get_product_code_car ok");
                   memset(err_buf,0,sizeof(err_buf));
                   strcpy(err_buf,"select stl_ins_type iclose:");
                   strcat(err_buf," iclose_type:");
                   strcat(err_buf,itoa(iclose_type));

                   $UPDATE ao_stl_close_dtl
                       SET (mstl, mproc, msalv, mstl_nt, mproc_nt, msalv_nt)
                         = (mstl + $mstl1, mproc + $mproc1, msalv + $msalv1,
                            mstl_nt + $mstl1, mproc_nt + $mproc1, msalv_nt + $msalv1)
                     WHERE iclose      = $iclaim
                       AND iclose_type = $sclose_type
                       AND fstl        = $fstl
                       AND insure_kind = $kclsfyitem;

                   if (sqlca.sqlerrd[2] == 0)
                   {
				   puts("UPDATE error");
                   $INSERT INTO ao_stl_close_dtl
                                (iclose, iclose_type, fstl, insure_kind, icur,
                                 mstl, mproc, msalv, mstl_nt, mproc_nt, msalv_nt)
                         VALUES ($iclaim,$sclose_type,$fstl,$kclsfyitem,"NT",
                                 $mstl1,$mproc1,$msalv1,$mstl1,$mproc1,$msalv1);
   				   puts("$INSERT ok");
                   }
				   puts("UPDATE ok");

                   if (mplace1 > 0)
                   {
                      $UPDATE ao_stl_close_dtl
                          SET (mstl, mproc, msalv, mstl_nt, mproc_nt, msalv_nt)
                            = (0, mproc + $mproc1, 0,
                               0, mproc_nt + $mproc1, 0)
                        WHERE iclose      = $iclaim
                          AND iclose_type = $sclose_type
                          AND fstl        = $fstl
                          AND insure_kind = '5650';
                      if (sqlca.sqlerrd[2] == 0)
                      {
                         $INSERT INTO ao_stl_close_dtl
                                      (iclose, iclose_type, fstl, insure_kind, icur,
                                       mstl, mproc, msalv, mstl_nt, mproc_nt, msalv_nt)
                               VALUES ($iclaim,$sclose_type,$fstl,'5650',"NT",
                                       0,$mplace1,0,0,$mplace1,0);
                      }
                   }

                   mstl_sum  = (double)(mstl1) + mstl_sum;
                   mproc_sum = (double)(mproc1) + mproc_sum;
                   msalv_sum = (double)(msalv1) + msalv_sum;
                   mplace_sum = (double)(mplace1) + mplace_sum;
                   $WHENEVER SQLERROR GOTO optP_err;
                 }
				 if ((mstl_sum == 0) && (mproc_sum == 0) && (msalv_sum == 0) && (mplace_sum == 0)) continue;
                 $CLOSE get_ins_cur;
                 $FREE  get_ins_cur;
               $WHENEVER SQLERROR GOTO optP_err;
           }/*fcard_class*/

           strncpy(ao_policy1,ipolicy   ,CAR_POLICY_LEN);
           ao_policy1[CAR_POLICY_LEN]='\0';
           strncpy(ao_policy2,ipolicy+CAR_POLICY_LEN, CAR_TARGET_LEN);
           ao_policy2[CAR_TARGET_LEN] ='\0';
           if (ao_policy2[0]=='\0') strncpy(ao_policy2,"    ",CAR_TARGET_LEN);

           memset(err_buf,0,sizeof(err_buf));
           strcpy(err_buf,"insert ao_stl_close:");
           strcat(err_buf,",");
           strcat(err_buf,iclaim);

           printf("************************************************qserial[%s]\n",str_qserial);

           /*---insert into ao_stl_close---*/
           printf ("insert into ao_stl_close \n");

           mproc_sum += mplace_sum;

           $INSERT INTO ao_stl_close
                        (iclose, iclose_type, fstl, dclose,
                         icls_dept, ipolicy1, ipolicy2, iclaim,
                         freceive, ireceive, fstl_sta, icur,
                         mstl_sum, mproc_sum, msalv_sum, insure_type,
                         mstl_sum_nt,mproc_sum_nt,msalv_sum_nt,sys_source,ibatch,
                         icreator,iadjuster,iaccount_branch)
                 VALUES ($iclaim,$sclose_type,$fstl,$stldate,
                         $icls_dept,$ao_policy1,$ao_policy2,$iclaim,
                         $fsalvage,$ireceive,'F','NT',
                         $mstl_sum,$mproc_sum,$msalv_sum, 'C',
                         $mstl_sum,$mproc_sum,$msalv_sum,"CAR",$str_qserial,
                         $userid,$iadjuster,$iaccount_branch);

           $WHENEVER SQLERROR GOTO optP_err;

           /*** P33 ***/
           /*---PREPARE FOR ao_stl_obj_close---*/
           /* 1000117001��I�覡��{�}���A�״ڦ�w�P�b���g�J�ť� */
           memset(err_buf,0,sizeof(err_buf));
           /* strcpy(err_buf,"select payment iclose:");
           strcpy(err_buf," iclose_type:");
           strcat(err_buf,itoa(iclose_type)); */
           sprintf(err_buf, "select payment iclaim='%s'  iclose_type=%d  fstl ='%s'",iclaim,iclose_type,fstl);

           printf("before payment cursur \n");

           sprintf(sStmt, "SELECT ipayment, ifpce_id_ext, \
                                  nchi_full, xsettle_type, ipay_area, nvl(xptax, 0.00),\
                                  xfpay_cond, DECODE(xfpay_cond,'2',' ',xibank), \
                                  DECODE(xfpay_cond,'2',' ',xiaccount), aperm_con,\
                                  xastl_obj_c, sum(mpayment), fspeed,  \
                                  nvl(frec_type,' '), nvl(izipcode,' '),    \
                                  nvl(aaddress,' '), nvl(nreceiver,' '),    \
                                  nvl(iofficer,' '),   \
                                  nvl(ioff_branch,' '), nvl(ioff_tel_ext,' '),   \
                                  nvl(itelephone,' '), nvl(imobilephone,' '),    \
                                  nvl(nremark,' '), nvl(fchange,' '), \
                                  nvl(iemail,' '), nvl(imobile,' '), nvl(izipcode_con,' '), nvl(tfax,' '), \
                                  nvl(mptax, 0), nvl(psupp_prem, 0.00), nvl(msupp_prem, 0) \
                             FROM %s:payment \
                            WHERE iclaim='%s' AND iclose_type=%d AND fstl ='%s'\
                         GROUP BY ipayment, ifpce_id_ext, \
                                  nchi_full, xsettle_type, ipay_area, xptax,\
                                  xfpay_cond, 8, 9, aperm_con,\
                                  xastl_obj_c,  fspeed, frec_type, izipcode, aaddress, \
                                  nreceiver, iofficer, ioff_branch, ioff_tel_ext, itelephone, \
                                  imobilephone, nremark, fchange, iemail, imobile, izipcode_con, tfax, \
								  mptax, psupp_prem, msupp_prem ", 
                 sFullName_ply, iclaim, iclose_type, fstl );

           printf("sStmt[%s]\n",sStmt);
           $PREPARE p3_56 FROM $sStmt;
           $DECLARE ins1_cursor CURSOR FOR p3_56;
           $OPEN ins1_cursor;
           while(1)
           {
                strcpy(ipayment,"") ; strcpy(nstl_obj,"")     ; strcpy(ipay_dept,"")  ;
                strcpy(ipay_area,""); strcpy(isettle_type,"") ; strcpy(fspeed,"")     ;
                strcpy(ifirm_pid,""); strcpy(asettle,"")      ; strcpy(aperm,"")      ;
                strcpy(asettle_1,""); strcpy(aperm_1,"")      ;
                mpayment=0          ; ptax=0                  ; mpayment_1=0          ;
                ptax_1=0            ; mptax=0                 ; psupp_prem=0.00       ;
                msupp_prem=0        ;

                $FETCH ins1_cursor INTO $ipayment,$ifpce_id_ext,
                                        $nchi_full, $isettle_type, $ipay_area, $ptax,
                                        $fpay_cond, $ibank, $itrans_acc, $aperm,
                                        $xastl_obj_c,$mpayment,$fspeed,$frec_type, $izipcode, $aaddress,
                                        $nreceiver, $iofficer, $ioff_branch, $ioff_tel_ext, $itelephone,
                                        $imobilephone, $nremark, $fchange ,$iemail, $imobile, $izipcode_con, $tfax,
                                        $mptax, $psupp_prem, $msupp_prem;

                if(NOT_FOUND) break;

                printf("INTO payment cursor\n");

                /** only �l�v��B�O��=0 ���g�Jao_stl_obj_close **/
                if (*fstl=='2')
                {
                    if (mpayment == 0)  /*** edit by Peter Sun for < to == [88/09/29] ***/
                      { continue; }
					else if (fspeed[0] != 'E')
					{ mpayment=mpayment*(-1); }
                }

                /** xsettle_type = 6 �ר��t read cu_stl_obj tstl_remark 880527*/
                /** ���H�ר��t���D,�u�n����W�N����W 890804 ***/
              /*    $SELECT tstl_remark
                      INTO $nchi_full_6:id_cust
                      FROM cu_stl_obj
                     WHERE ifpce_id = $ipayment
                       AND ifpce_id_ext = $ifpce_id_ext;
                   if ((id_cust >= 0) && strlen(rtrim(nchi_full_6))!=0)
                      strcpy(nchi_full,nchi_full_6);                          */
                /*-------------------------------------------------------880527*/

/* ��W���ѭ�ӧ��A�ɧ令��z�ߺݤ���� */
       sprintf(sStmt, "SELECT distinct npayment  \
                         FROM %s:payment \
                        WHERE iclaim='%s' AND iclose_type=%d AND fstl ='%s' \
                          AND ipayment = '%s' AND ifpce_id_ext = '%s' ",
                 sFullName_ply, iclaim, iclose_type, fstl,ipayment,ifpce_id_ext);
         printf("sStmt[%s]\n",sStmt);
  
         $PREPARE sid012 FROM $sStmt;
         $EXECUTE sid012 INTO $npayment;


        if( SQLCODE == SQLNOTFOUND)
        {   strcpy(npayment," ");     }


          strcpy(invoice," ");
          strcpy(dreceive," ");
          sprintf(sStmt, "SELECT FIRST 1 invoice,dreceive,isign \
                         FROM %s:ca_sign_receipt \
                        WHERE iclaim='%s' AND dclose=? \
                          AND ifpce_id = '%s' AND ifpce_id_ext = '%s' ",
                 sFullName_ply, iclaim, ipayment, ifpce_id_ext);
         $PREPARE sid013 FROM $sStmt;
         $EXECUTE sid013 INTO $invoice,$dreceive, $sIsign USING $stldate;

 printf(" *******************  invoice[%s] ,   dreceive[%s] \n",invoice, dreceive);

   if((npayment[0]==' ') || (npayment[0]=='' ))
   {   strcpy(npayment,nchi_full);            }

                sprintf(tmp_mpayment,"17.4f",mpayment);
                deccvasc(tmp_mpayment,strlen(tmp_mpayment),&dec_mpayment);
                dectodbl(&dec_mpayment,&mpayment_1);
                printf("--------------> mapyment_1[%f]\n",mpayment_1);
                strcpy(asettle_1,   xastl_obj_c);
                strncpy(aperm_1,aperm,60);
                sprintf(tmp_ptax,"%7.2f",ptax);
                deccvasc(tmp_ptax,strlen(tmp_ptax),&dec_ptax);
                dectodbl(&dec_ptax,&ptax_1);

                /** AOI�ߥI��H�� **/
                memset(err_buf,0,sizeof(err_buf));
                strcpy(err_buf,"insert ao_stl_obj_close:");
                strcat(err_buf,",");
                strcat(err_buf,ipayment);
                printf ("ao_stl_obj_close\n");

                   sprintf(stmt,
               " SELECT ito_sub,iaccsub        \
                   FROM %s:ao_close_temp     \
                  WHERE iclaim = '%s' and itmp_no = '%s'  ",sFullName_ply,iclaim,ireceive);
              $PREPARE st_id01 FROM $stmt;
              $EXECUTE st_id01 INTO $ito_sub,$iaccsub;

  printf("  $$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$$ito_sub[%s],iaccsub[%s]\n",ito_sub,iaccsub);

/*************  1010208 isou_dept -> DBName
                $INSERT INTO ao_stl_obj_close
                             (iclose, iclose_type,fstl,istl_obj,istl_obj_ext,icur,
                              nstl_obj, m_stl, mexchange,
                              ipay_dept,isou_dept,
                              isettle_type,
                              ptax, dspeed, fpay_cond, iaccount, dclose,
                              istl_obj_i, astl_obj_c, astl_obj, ireceive,
                              fstl_obj_sta, ibank ,invoice , dreceive )
                      VALUES ($iclaim,$sclose_type,$fstl,$ipayment,$ifpce_id_ext,
                              'NT',
                              $npayment,$mpayment,$mpayment,
                              $DBname,  $iaccsub,
                              $isettle_type,
                              $ptax_1,$fspeed,$fpay_cond,$itrans_acc,$stldate,
                              $ipayment,$asettle_1,$aperm_1, $ireceive,
                              'F', $ibank ,$invoice, $dreceive );
***************/

                printf("before ao_stl_obj_close\n");
                $INSERT INTO ao_stl_obj_close
                             (iclose, iclose_type,fstl,istl_obj,istl_obj_ext,icur,
                              nstl_obj, m_stl, mexchange,
                              ipay_dept,icls_dept,
                              isettle_type,
                              ptax, dspeed, fpay_cond, iaccount, dclose,
                              istl_obj_i, astl_obj_c, astl_obj, ireceive,
                              fstl_obj_sta, ibank ,invoice , dreceive,
                              astl_obj_email, tstl_obj_mobile, astl_obj_c_zip, tfax,
                              mptax, psupp_prem, msupp_prem)
                      VALUES ($iclaim,$sclose_type,$fstl,$ipayment,$ifpce_id_ext,
                              'NT',
                              $npayment,$mpayment,$mpayment,
                              '00',  $DBname,
                              $isettle_type,
                              $ptax_1,$fspeed,$fpay_cond,$itrans_acc,$stldate,
                              $ipayment,$aperm_1,$asettle_1, $ireceive,
                              'F', $ibank ,$invoice, $dreceive,
                              $iemail, $imobile, $izipcode_con, $tfax,
                              0, $psupp_prem, 0);

               /* ���ܫ���u_pay_area�B�z */
               /*
               sprintf(sStmt,"UPDATE %s:payment \
                                 SET ipay_area = '%s'  \
                               WHERE iclaim = '%s' \
                                 AND fstl = '%s'   \
                                 AND iclose_type = '%s'   \
                                 AND ipayment = '%s'      \
                                 AND ifpce_id_ext = '%s' ",
                          sFullName_ply,DBname,iclaim,fstl,sclose_type,ipayment,ifpce_id_ext);
                       EXEC SQL PREPARE u_payment FROM  :sStmt;
                       EXEC SQL EXECUTE u_payment;
                */

               if (fpay_cond[0] == '2')
               {
                  $WHENEVER SQLERROR CONTINUE;
                  $INSERT INTO ao_stl_notes_info
                    (fdata_type, inum1, inum2, inum3, istl_obj, istl_obj_ext, icur, nstl_obj,
                     frec_type, izipcode, aaddress, nreceiver, iofficer, ioff_branch,
                     ioff_tel_ext, itelephone, imobilephone, nremark, fchange, iupdate, dupdate)
                    VALUES
                    ('1', $iclaim, $sclose_type, $fstl, $ipayment, $ifpce_id_ext, 'NT', $npayment,
                     $frec_type, $izipcode, $aaddress, $nreceiver, $iofficer, $ioff_branch,
                     $ioff_tel_ext, $itelephone, $imobilephone, $nremark, $fchange, $userid, today);
                    if (SQLCODE != 0 && SQLCODE != -239)
                    {
                       goto optP_err;
                    }
                $WHENEVER SQLERROR GOTO optP_err;
               }
                $WHENEVER SQLERROR GOTO optP_err;
           }
           $CLOSE ins1_cursor;
           $FREE  ins1_cursor;



           /************insert into cm_stl_info*********************************/
           printf("insert into cm_stl_info\n");
           sprintf(sStmt, "SELECT dclaim, daccident \
                             FROM %s:appraisal \
                            WHERE iclaim = '%s'",
                           sFullName_ply, iclaim);
           $PREPARE cm_stl FROM $sStmt;
           $DECLARE cmstlinfo_cursor CURSOR FOR cm_stl;
           $OPEN cmstlinfo_cursor;
           $FETCH cmstlinfo_cursor INTO $stlinfodclaim, $stlinfodaccident;
           $CLOSE cmstlinfo_cursor;
           $FREE  cmstlinfo_cursor;

           strncpy (stlinfodclaim_tmp, stlinfodclaim, 10);
           strncpy (stlinfodaccident_tmp, stlinfodaccident, 10);

           stlinfodclaim_tmp[10]='\0';
           stlinfodaccident_tmp[10]='\0';

           strcpy( str, stlinfodclaim_tmp);
           stlinfodclaim_tmp[0]=str[5];
           stlinfodclaim_tmp[1]=str[6];
           stlinfodclaim_tmp[2]='/';
           stlinfodclaim_tmp[3]=str[8];
           stlinfodclaim_tmp[4]=str[9];
           stlinfodclaim_tmp[5]='/';
           stlinfodclaim_tmp[6]=str[0];
           stlinfodclaim_tmp[7]=str[1];
           stlinfodclaim_tmp[8]=str[2];
           stlinfodclaim_tmp[9]=str[3];
           stlinfodclaim_tmp[10]='\0';

           strcpy( str, stlinfodaccident_tmp);
           stlinfodaccident_tmp[0]=str[5];
           stlinfodaccident_tmp[1]=str[6];
           stlinfodaccident_tmp[2]='/';
           stlinfodaccident_tmp[3]=str[8];
           stlinfodaccident_tmp[4]=str[9];
           stlinfodaccident_tmp[5]='/';
           stlinfodaccident_tmp[6]=str[0];
           stlinfodaccident_tmp[7]=str[1];
           stlinfodaccident_tmp[8]=str[2];
           stlinfodaccident_tmp[9]=str[3];
           stlinfodaccident_tmp[10]='\0';

           strcpy (stlinfodclose, cm_edate_str(stldate));

           cm_stl_info_init(&stCmStlInfo);
           strcpy(stCmStlInfo.insure_type, "C");                  /* �I�O    */
           strcpy(stCmStlInfo.isys_source, "CAR");
           strcpy(stCmStlInfo.ipolicy1,    ao_policy1);           /* �O��@  */
           strcpy(stCmStlInfo.ipolicy2,    ao_policy2);           /* �O��G  */
           strcpy(stCmStlInfo.iclaim,      iclaim );              /* �߮׸�  */
           strcpy(stCmStlInfo.fstl,        fstl);                 /* �߰l�N��*/
           strcpy(stCmStlInfo.iclaim_seq,  sclose_type);          /* �߮���*/
           strcpy(stCmStlInfo.dclaim,      stlinfodclaim_tmp);    /* ���z���*/
           strcpy(stCmStlInfo.daccident,   stlinfodaccident_tmp); /* �X�I���*/
           if (fstl[0]=='1')
               stCmStlInfo.msettle = mstl_sum;                    /* �߰l���B*/
           else
               stCmStlInfo.msettle = (mstl_sum* -1);              /* �߰l���B*/
           stCmStlInfo.mprocess             = mproc_sum;          /* �B�z�O��*/
           stCmStlInfo.mreins_stl           = 0;                  /* �A�O�u�^*/
           strcpy(stCmStlInfo.dclose,       stlinfodclose);       /* ���פ��*/

           printf("**** call cm_stl_info_insert\n");
           /* �̻ݨD���A�g�J cm_stl_info (1071221010_SC1) mark by sylvia 108.01.03 */
           /* iRtnCode = cm_stl_info_insert(&stCmStlInfo);
           if(iRtnCode != 0)
              if (iRtnCode == -239)
              {
                 iRtnCode=cm_stl_info_delete(stCmStlInfo.ipolicy1, stCmStlInfo.ipolicy2, stCmStlInfo.iclaim, stCmStlInfo.fstl, stCmStlInfo.iclaim_seq);
                 if (iRtnCode == 0)
                     iRtnCode = cm_stl_info_insert(&stCmStlInfo);
                     if(iRtnCode != 0)
                     {
                         sprintf(err_buf, "cm_stl_info_delete & cm_stl_info_insert[%s]", iclaim);
                         EXEC SQL WHENEVER SQLERROR CONTINUE;
                         EXEC SQL ROLLBACK WORK;
                         return iRtnCode;
                     }
                     EXEC SQL WHENEVER SQLERROR GOTO optP_err;
              }
              else
              {
                  sprintf(err_buf, "cm_stl_info_insert[%s]", iclaim);
                  EXEC SQL WHENEVER SQLERROR CONTINUE;
                  EXEC SQL ROLLBACK WORK;
                  return iRtnCode;
              }
              EXEC SQL WHENEVER SQLERROR GOTO optP_err; */

            /************finish  cm_stl_info*********************************/

            /************start   call no_chk_recinfo   1010213 **************/
            printf("iclaim [%s], fstl[%s], sclose_type[%s] no_chk_recinfo start\n",iclaim,fstl,sclose_type);
            rcA = no_chk_recinfo(iclaim,sclose_type,fstl,remarkA);
            if (rcA != 3500)
            {
               sprintf(err_buf, "no_chk_recinfo err [%s]", remarkA);
               EXEC SQL WHENEVER SQLERROR CONTINUE;
               EXEC SQL ROLLBACK WORK;
               return rcA;
            }
            printf("iclaim [%s], fstl[%s], sclose_type[%s] no_chk_recinfo end\n",iclaim,fstl,sclose_type);
            /************end     call no_chk_recinfo   1010213 **************/
        }
        EXEC SQL CLOSE STL2;
        EXEC SQL FREE  STL2;

        StlCurr=StlCurr->next;
    }

    EXEC SQL WHENEVER SQLERROR GOTO optP_err;

    /**** STEP P5 *****************************************/
    printf("-> enter P5\n");

    StlCurr=StlFirst;
    while (StlCurr)
    {
        sclose_type[0]=NULL;
        strcpy(iclaim,StlCurr->iclaim);
        iclose_type=StlCurr->iclose_type;
        strcpy(ipolicy,StlCurr->ipolicy);
        strcpy(fstl,StlCurr->fstl);

        strncpy(dbsub,ipolicy,2);
        strcpy(sFullName_ply, get_full_dbname(dbsub));
        sprintf (sclose_type,"%d",iclose_type);
        printf ("sclose_type[%s]\n",sclose_type);

        /***********************************************
         **        �w���M������ѫ�u�B�z             **
         ***********************************************/

        sprintf (sStmt,"SELECT fcard_class,frecover,fsale,istl_note,iadjuster \
                          FROM %s:settlement \
                         WHERE iclaim='%s' \
                           AND fstl  ='%s' \
                           AND iclose_type=%d",
                 sFullName_ply,iclaim,fstl,iclose_type);
        EXEC SQL PREPARE p3_551 FROM      :sStmt;
        EXEC SQL DECLARE APPx1 CURSOR FOR p3_551;
        EXEC SQL OPEN  APPx1 ;
        EXEC SQL FETCH APPx1 INTO :fcard_class, :frecover, :fsale, :istl_note, :iadjuster;
        EXEC SQL CLOSE APPx1;
        EXEC SQL FREE  APPx1;

        if (fcard_class[0]=='2')   /*** ���N�I ***/
        {
			/*���o���ײz��P�O���`�B*/
			sprintf(sStmt,"SELECT SUM(mins_stl+mins_proc) \
							FROM %s:stl_ins_type \
							WHERE iclaim = '%s' \
							AND fstl = '%s' \
							AND iclose_type = %d",
							sFullName_ply,iclaim,fstl,iclose_type);
			EXEC SQL PREPARE sum_stl_ins   FROM       :sStmt;
            EXEC SQL DECLARE sum_stl_ins_cur CURSOR FOR sum_stl_ins;
            EXEC SQL OPEN    sum_stl_ins_cur;
			EXEC SQL FETCH sum_stl_ins_cur INTO :sum_stl_proc;
			EXEC SQL CLOSE sum_stl_ins_cur;
			EXEC SQL FREE  sum_stl_ins_cur;

            printf ("select iins_type \n");
            sprintf (sStmt,"SELECT iins_type,flast,mins_stl,mins_proc,mins_place \
                              FROM %s:stl_ins_type \
                             WHERE iclaim = '%s' \
                               AND fstl = '%s' \
                               AND iclose_type = %d",
                     sFullName_ply,iclaim,fstl,iclose_type);
            EXEC SQL PREPARE u_settlement   FROM       :sStmt;
            EXEC SQL DECLARE settlement_cur CURSOR FOR u_settlement;
            EXEC SQL OPEN    settlement_cur;
            for ( ; ; )
            {
               EXEC SQL FETCH settlement_cur INTO :iins_type,:flast,:mins_stl,:mins_proc,:mins_place;
               if (SQLCODE == SQLNOTFOUND)  break;

               printf ("update app_ins_type \n");
               if (fstl[0]=='1')
               {
                   /*** ���q�u�w��K�ߵ��װ� update dgroup �M fclose ���ʧ@,��l�������ѥ߱b�ɳB�z ***/
                   if(mins_stl == 0 && flast[0] == '1' && mins_proc == 0 && sum_stl_proc == 0 && mins_place == 0)
                   {
                       sprintf(sStmt,"UPDATE %s:app_ins_type \
                                         SET dclose_ctype = ? , dgroup1 = ? , fclose = ? \
                                       WHERE iclaim = '%s' \
                                         AND iins_type = '%s'",
                               sFullName_ply,iclaim,iins_type);
                       EXEC SQL PREPARE u_appinstype FROM  :sStmt;
                       EXEC SQL EXECUTE u_appinstype USING :stldate , :groupdate , '1';

                       sprintf (sStmt,"UPDATE %s:stl_ins_type \
                                          SET dclose = (?),dgroup = ? \
                                        WHERE iclaim = '%s'\
                                          AND fstl   = '%s'\
                                          AND iclose_type = %d \
                                          AND iins_type = '%s' \
                                          AND dgroup IS NULL ",
                                sFullName_ply,iclaim,fstl,iclose_type,iins_type);
                       EXEC SQL PREPARE u_stlinstype FROM  :sStmt;
                       EXEC SQL EXECUTE u_stlinstype USING :stldate , :groupdate;
                   }
                   else
                   {
                       sprintf(sStmt,"UPDATE %s:app_ins_type \
                                         SET dclose_ctype = ? \
                                       WHERE iclaim       = '%s' \
                                         AND iins_type    = '%s'",
                               sFullName_ply,iclaim,iins_type);
                       EXEC SQL PREPARE u_appinstype FROM  :sStmt;
                       EXEC SQL EXECUTE u_appinstype USING :stldate;

                       sprintf(sStmt,"UPDATE %s:stl_ins_type \
                                         SET dclose = (?) \
                                       WHERE iclaim = '%s'\
                                         AND fstl   = '%s'\
                                         AND iclose_type = %d \
                                         AND iins_type = '%s' ",
                       sFullName_ply,iclaim,fstl,iclose_type,iins_type);
                       EXEC SQL PREPARE u_stlinstype FROM  :sStmt;
                       EXEC SQL EXECUTE u_stlinstype USING :stldate;
                   }

                   /*** �l�v�B�z�g�J���פ�� ***/

                   if (flast[0] == '1')
                   {
                       printf("####### fstl = [1],flast = [1],frecover[%s],fsale[%s]\n",frecover,fsale);

                       sprintf(sStmt,"SELECT iclaim \
                                        FROM %s:recovery \
                                       WHERE iclaim = '%s' \
                                         AND dclose is null",sFullName_ply,iclaim);
                       EXEC SQL PREPARE sel_recov_1 FROM          :sStmt;
                       EXEC SQL DECLARE sel_recov_cur1 CURSOR FOR  sel_recov_1;
                       EXEC SQL OPEN    sel_recov_cur1;
                       EXEC SQL FETCH   sel_recov_cur1 INTO       :iclaim_tmp;
                       if (SQLCODE == SQLNOTFOUND)
                       {

                            strcpy(iins_type,trim(iins_type));
                            if ((strcmp(iins_type,"01") == 0) ||
                                (strcmp(iins_type,"05") == 0) ||
                                (strcmp(iins_type,"08") == 0) ||
                                (strcmp(iins_type,"09") == 0) ||
                                (strcmp(iins_type,"11") == 0) ||
                                (strcmp(iins_type,"71") == 0) ||
                                (strcmp(iins_type,"24") == 0)){

/*                                if ((strcmp(iins_type,"11") == 0) &&
                                    (frecover[0] == '0')
                                   ){*/
                                     /* do nothing  */
                                   /* ���ѥ��l������h�٦ۭt�B���l�v���A���O�d
                                      �쪬�A
                                   */
/*                                }else{

                                  if (frecover[0] == '0'){
                                  sprintf(sStmt,"UPDATE %s:recovery                  \
                                                    SET (frecover,frecov,freprocess) \
                                                      = ('0','0',' ')                \
                                                  WHERE iclaim = '%s'  ",
                                                  sFullName_ply, iclaim);
                                      EXEC SQL PREPARE p5_rcvs1 FROM   :sStmt;
                                      EXEC SQL EXECUTE p5_rcvs1;

                                  }else{
                                  sprintf(sStmt,"UPDATE %s:recovery \
                                                    SET frecover = ? \
                                                  WHERE iclaim = '%s' ",
                                                  sFullName_ply, iclaim);
                                      EXEC SQL PREPARE p5_rcv FROM   :sStmt;
                                      EXEC SQL EXECUTE p5_rcv USING  :frecover;
                                  }
                                }*/
                            }
                       }
                       EXEC SQL CLOSE   sel_recov_cur1;
                       EXEC SQL FREE    sel_recov_cur1;

                       /* �Y�ߨ��l�B�D�K�ߵ��ש㵲�פ�A�]�קK
                          �ߥI��� > �l�v���
                       */
                       strcpy(iins_type,trim(iins_type));
/*                            if (
                                (
                                 (strcmp(iins_type,"01") == 0) ||
                                 (strcmp(iins_type,"05") == 0) ||
                                 (strcmp(iins_type,"08") == 0) ||
                                 (strcmp(iins_type,"09") == 0) ||
                                 (strcmp(iins_type,"11") == 0) ||
                                 (strcmp(iins_type,"71") == 0) ||
                                 (strcmp(iins_type,"24") == 0)
                                ) && (mins_stl != 0)
                               ) {
                            sprintf(sStmt,"UPDATE %s:recovery   \
                                              SET dclose = ?    \
                                            WHERE iclaim = '%s' ",
                                       sFullName_ply, iclaim);
                            EXEC SQL PREPARE p5_rcvs1 FROM   :sStmt;
                            EXEC SQL EXECUTE p5_rcvs1 USING  :stldate ;
                         }*/
                   }
               }
               if (fstl[0] == '2')
               {
                   /*** ���q�u�w��K�ߵ��װ� update dgroup �M fclose ���ʧ@,��l�������ѥ߱b�ɳB�z ***/
                   if(mins_stl == 0 && flast[0] == '1' && mins_proc == 0 && sum_stl_proc == 0 && mins_place == 0)
                   {
                       sprintf(sStmt,"UPDATE %s:app_ins_type \
                                         SET dclose_ctype=?,dgroup1=?,fclose=?\
                                       WHERE iclaim='%s' \
                                         AND iins_type='%s'",
                               sFullName_ply,iclaim,iins_type);
                       EXEC SQL PREPARE u_appinstype_2 FROM  :sStmt;
                       EXEC SQL EXECUTE u_appinstype_2 USING :stldate , :groupdate , '1';

                       sprintf (sStmt,"UPDATE %s:stl_ins_type \
                                          SET dclose = (?),dgroup = ? \
                                        WHERE iclaim='%s'\
                                          AND fstl  ='%s'\
                                          AND iclose_type =%d \
                                          AND iins_type ='%s' \
                                          AND dgroup IS NULL ",
                                sFullName_ply,iclaim,fstl,iclose_type,iins_type);
                       EXEC SQL PREPARE u_stlinstype_2 FROM  :sStmt;
                       EXEC SQL EXECUTE u_stlinstype_2 USING :stldate , :groupdate;
                   }
                   else
                   {
                       sprintf(sStmt,"UPDATE %s:app_ins_type \
                                         SET dclose_rtype=? \
                                       WHERE iclaim='%s' \
                                         AND iins_type='%s'",
                               sFullName_ply,iclaim,iins_type);
                       EXEC SQL PREPARE u_appinstype FROM  :sStmt;
                       EXEC SQL EXECUTE u_appinstype USING :stldate;

                       sprintf (sStmt,"UPDATE %s:stl_ins_type \
                                          SET dclose = (?) \
                                        WHERE iclaim='%s'\
                                          AND fstl  ='%s'\
                                          AND iclose_type =%d \
                                          AND iins_type = '%s' ",
                       sFullName_ply,iclaim,fstl,iclose_type,iins_type);
                       EXEC SQL PREPARE u_stlinstype FROM  :sStmt;
                       EXEC SQL EXECUTE u_stlinstype USING :stldate;
                   }

                   /**** �l�v���� ****/
               }
            }
            EXEC SQL CLOSE settlement_cur;
            EXEC SQL FREE  settlement_cur;
        }

        if (fcard_class[0]=='1')
        {
			/*���o���ײz��P�O���`�B*/
			sprintf(sStmt,"SELECT SUM(mins_stl+mins_proc+mstl_health) \
							FROM %s:ca_stl_victim \
							WHERE iclaim = '%s' \
							AND fstl = '%s' \
							AND iclose_type = %d",
							sFullName_ply,iclaim,fstl,iclose_type);
			EXEC SQL PREPARE sum_stl_victim   FROM       :sStmt;
            EXEC SQL DECLARE sum_stl_victim_cur CURSOR FOR sum_stl_victim;
            EXEC SQL OPEN    sum_stl_victim_cur;
			EXEC SQL FETCH sum_stl_victim_cur INTO :sum_stl_proc;
			EXEC SQL CLOSE sum_stl_victim_cur;
			EXEC SQL FREE  sum_stl_victim_cur;

            printf ("select ca_stl_victim \n");

            sprintf (sStmt ,"SELECT iins_item,ivictim,mins_stl,flast,mins_proc,mstl_health \
                               FROM %s:ca_stl_victim \
                              WHERE iclaim='%s'\
                                AND fstl='%s'\
                                AND iclose_type =%d",
                     sFullName_ply,iclaim,fstl,iclose_type);
            EXEC SQL PREPARE u_castlvictim   FROM       :sStmt;
            EXEC SQL DECLARE castlvictim_cur CURSOR FOR u_castlvictim;
            EXEC SQL OPEN    castlvictim_cur;
            for ( ; ;)
            {
                EXEC SQL FETCH castlvictim_cur INTO :iins_item, :ivictim, :mins_stl,
                                                    :flast,:mins_proc, :mstl_health;
                if (SQLCODE == SQLNOTFOUND) break ;

                /* �ˮ� �z���� �̷s�w���� �w�����v�� ��ƬO�_�@�P */

          printf(" **************************************** \n");
                app_count = hist_count = 0;
                sprintf(stmt_buf,"select count(*)  \
                                    from %s:ca_app_victim  \
                                   WHERE iclaim='%s'\
                                     AND iins_item = '%s'  \
                                     AND ivictim = '%s' ",
                   sFullName_ply,iclaim,iins_item,ivictim );

            printf("   ---------------- stmt_buf [%s] \n",stmt_buf);
            $prepare pre_app from $stmt_buf;
            $execute pre_app into $app_count;
            printf("   ---------------- app_count [%d] \n",app_count);
            if(app_count == 0)
            {

            	printf(" ************** msgbuf[%s]\n",msgbuf);
            	printf(" <><><><><><><><><><><><><><><><><><><><> \n");

               memset(err_buf,0,sizeof(err_buf));
               sprintf(msgbuf,"�׸�[%s]�z�߹w���ɸ�ƻP�z���ɤ���\n",iclaim);
               strcpy(err_buf,msgbuf);
               strcat(err_buf," ");


                goto optP_err;

             }


                            sprintf(stmt_buf,"select count(*)  \
                                    from %s:ca_app_victim_hist  \
                                   WHERE iclaim='%s'\
                                     AND iins_item = '%s'  \
                                     AND ivictim = '%s' ",
                   sFullName_ply,iclaim,iins_item,ivictim );

            printf("   ---------------- stmt_buf [%s] \n",stmt_buf);
            $prepare pre_app from $stmt_buf;
            $execute pre_app into $hist_count;
            printf("   ---------------- hist_count [%d] \n",hist_count);
            if(hist_count == 0)
            {

            	printf(" ************** msgbuf[%s]\n",msgbuf);
            	printf(" <><><><><><><><><><><><><><><><><><><><> \n");

               memset(err_buf,0,sizeof(err_buf));
               sprintf(msgbuf,"�׸�[%s]�z�߹w�����v�ɸ�ƻP�z���ɤ���\n",iclaim);
               strcpy(err_buf,msgbuf);
               strcat(err_buf," ");


                goto optP_err;

             }


                printf ("update ca_app_victim \n");
                if (fstl[0]=='1')
                {
				   /*if(mins_stl == 0  && flast[0] == '1' && mins_proc == 0)*/
                   if(((mins_stl == 0  && flast[0] == '1') || (flast[0] == '2' && mstl_health == 0)) && mins_proc == 0 && sum_stl_proc == 0)
                   {
                       sprintf (sStmt ,"UPDATE %s:ca_app_victim \
                                           SET dclose_ctype = ? , dgroup1 = ? , fclose = ? \
                                         WHERE iclaim    = '%s' \
                                           AND iins_item = '%s' \
                                           AND ivictim   = '%s' ",
                                sFullName_ply,iclaim,iins_item,ivictim);
                       EXEC SQL PREPARE u_caappvictim   FROM  :sStmt;
                       EXEC SQL EXECUTE u_caappvictim   USING :stldate,:groupdate,'1';

printf("iclaim[%s],fstl[%s],iclose_type[%d],iins_item[%s],ivictim[%s]\n",
        iclaim  ,  fstl  ,  iclose_type  ,  iins_item  ,  ivictim);
                       sprintf (sStmt,"UPDATE %s:ca_stl_victim \
                                          SET dclose = ? , dgroup = ? \
                                        WHERE iclaim      = '%s' \
                                          AND fstl        = '%s' \
                                          AND iclose_type = %d   \
                                          AND iins_item   = '%s' \
                                          AND ivictim     = '%s' \
                                          AND dgroup IS NULL ",
                                sFullName_ply, iclaim,fstl,iclose_type,iins_item,ivictim);
                       EXEC SQL PREPARE u_stlvictim   FROM  :sStmt;
                       EXEC SQL EXECUTE u_stlvictim   USING :stldate , :groupdate;
printf("END UPDATE ca_stl_victim \n");
                   }
                   else
                   {
                       sprintf (sStmt ,"UPDATE %s:ca_app_victim \
                                           SET dclose_ctype=? \
                                         WHERE iclaim='%s' \
                                           AND iins_item='%s' \
                                           AND ivictim='%s' ",
                                 sFullName_ply,iclaim,iins_item,ivictim);
                       EXEC SQL PREPARE u_caappvictim   FROM  :sStmt;
                       EXEC SQL EXECUTE u_caappvictim   USING :stldate;

                       sprintf (sStmt,"UPDATE %s:ca_stl_victim \
                                          SET dclose=? \
                                        WHERE iclaim='%s' \
                                          AND fstl='%s' \
                                          AND iclose_type=%d \
                                          AND iins_item='%s' \
                                          AND ivictim ='%s'  ",
                                sFullName_ply, iclaim,fstl,iclose_type,iins_item,ivictim);
                       EXEC SQL PREPARE u_stlvictim   FROM  :sStmt;
                       EXEC SQL EXECUTE u_stlvictim   USING :stldate;
                   }

                   /*** ��s�l�v�� dclose(�ߥI���)���t�Τ�� ***/
/*                   if (flast[0] == '1' &&
                      (frecover[0] == '1' ||
                       frecover[0] == '2' ||
                       frecover[0] == '3' ||
                       frecover[0] == '4' ||
                       frecover[0] == '5' ||
                       fsale[0]    == '1' ))
                   {
                       sprintf(sStmt,"SELECT iclaim \
                                        FROM %s:recovery \
                                       WHERE iclaim = '%s' \
                                         AND dclose is null",sFullName_ply,iclaim);
                       EXEC SQL PREPARE sel_recov_2 FROM          :sStmt;
                       EXEC SQL DECLARE sel_recov_cur2 CURSOR FOR  sel_recov_2;
                       EXEC SQL OPEN    sel_recov_cur2;
                       EXEC SQL FETCH   sel_recov_cur2 INTO       :iclaim_tmp;
                       if (SQLCODE == SQLNOTFOUND)
                       {
                            printf("##### fstl = [1],flast = [1] , frecover[%s] , fsale[%s]\n",frecover,fsale);
                            sprintf(sStmt,"UPDATE %s:recovery \
                                              SET dclose =  ?, frecover = ? \
                                            WHERE iclaim = '%s' ",
                                    sFullName_ply, iclaim);
                            EXEC SQL PREPARE p5_crcv FROM   :sStmt;
                            EXEC SQL EXECUTE p5_crcv USING  :stldate, :frecover;
                       }
                       EXEC SQL CLOSE   sel_recov_cur2;
                       EXEC SQL FREE    sel_recov_cur2;
                   }*/
                }
                if (fstl[0]=='2')
                {
                   if (((mins_stl == 0  && flast[0] == '1') || (flast[0] == '2' && mins_stl == 0 && mstl_health == 0)) && mins_proc == 0 && sum_stl_proc == 0)
                   {
                       sprintf (sStmt ,"UPDATE %s:ca_app_victim \
                                           SET dclose_ctype=?,dgroup1=?,fclose=? \
                                         WHERE iclaim='%s' \
                                           AND iins_item='%s' \
                                           AND ivictim='%s' ",
                                 sFullName_ply,iclaim,iins_item,ivictim);
                       EXEC SQL PREPARE u_caappvictim   FROM  :sStmt;
                       EXEC SQL EXECUTE u_caappvictim   USING :stldate,:groupdate,'1';

printf("iclaim[%s],fstl[%s],iclose_type[%d],iins_item[%s],ivictim[%s]\n",
        iclaim  ,  fstl  ,  iclose_type  ,  iins_item  ,  ivictim);
                       sprintf (sStmt,"UPDATE %s:ca_stl_victim \
                                          SET dclose=?,dgroup=? \
                                        WHERE iclaim='%s' \
                                          AND fstl='%s' \
                                          AND iclose_type=%d \
                                          AND iins_item='%s' \
                                          AND ivictim ='%s'  \
                                          AND dgroup IS NULL ",
                         sFullName_ply, iclaim,fstl,iclose_type,iins_item,ivictim);
                       EXEC SQL PREPARE u_stlvictim   FROM  :sStmt;
                       EXEC SQL EXECUTE u_stlvictim   USING :stldate , :groupdate;
printf("END UPDATE ca_stl_victim \n");
                   }
                   else
                   {
                       sprintf (sStmt ,"UPDATE %s:ca_app_victim \
                                           SET dclose_rtype=? \
                                         WHERE iclaim='%s' \
                                           AND iins_item='%s' \
                                           AND ivictim='%s' ",
                                sFullName_ply,iclaim,iins_item,ivictim);
                       EXEC SQL PREPARE u_caappvictim_3   FROM  :sStmt;
                       EXEC SQL EXECUTE u_caappvictim_3   USING :stldate;

                       sprintf (sStmt,"UPDATE %s:ca_stl_victim \
                                          SET dclose=? \
                                        WHERE iclaim='%s' \
                                          AND fstl='%s' \
                                          AND iclose_type=%d \
                                          AND iins_item='%s' \
                                          AND ivictim ='%s'  ",
                         sFullName_ply, iclaim,fstl,iclose_type,iins_item,ivictim);
                       EXEC SQL PREPARE u_stlvictim_3   FROM  :sStmt;
                       EXEC SQL EXECUTE u_stlvictim_3   USING :stldate;
                   }

                   /****�P�_�l�v����*****/
                }

                /* 870722-maggie */
                if (iins_item[0]=='A')
                {
                    sprintf (sStmt ,"SELECT ftrans \
                                       FROM %s:ca_clm_victim_tran \
                                      WHERE iclaim='%s'\
                                        AND ivictim='%s'",
                             sFullName_ply,iclaim,ivictim);
                    $PREPARE sq_tran FROM $sStmt;
                    $DECLARE tran_cur CURSOR FOR sq_tran;
                    $OPEN tran_cur;
                    $FETCH tran_cur INTO $ftrans;

                    if (SQLCODE==SQLNOTFOUND)
                    {
                        printf ("  �s�W ca_clm_victim_tran \n");
                        sprintf (sStmt ,"INSERT INTO %s:ca_clm_victim_tran \
                              (iclaim,ivictim,dclose,ftrans, mstl) \
                              VALUES (?,?,?,?,?)",
                              sFullName_ply);
                        $PREPARE i_victim_tran FROM $sStmt ;
                        $EXECUTE i_victim_tran
                        USING $iclaim ,$ivictim ,$stldate,'N', $mins_stl;
                    }
                    else if (ftrans[0]=='N')
                    {
                        sprintf (sStmt ,"UPDATE %s:ca_clm_victim_tran \
                                            SET (mstl,dclose) = (mstl+?,?) \
                                          WHERE iclaim= '%s' \
                                            AND ivictim='%s'",
                                 sFullName_ply ,iclaim,ivictim );
                        $PREPARE i_13 FROM $sStmt ;
                        $EXECUTE i_13 USING $mins_stl,$stldate;
                    }
                }
            }
            EXEC SQL CLOSE castlvictim_cur;
            EXEC SQL FREE  castlvictim_cur;

        }

        printf("----- update settlement\n");
        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"update settlement iclaim:");
        strcat(err_buf,iclaim);
        strcat(err_buf," fstl:");
        strcat(err_buf,fstl);
        strcat(err_buf," iclose_tp:");
        strcat(err_buf,itoa(iclose_type));

		/* ��Q�I�]���z��ᶷ�����U�Ӱ��ȥ�ñ��,�ҥH�b�鵲�ɶ��^�ɪ��A=130 modify by sylvia 108.03.29 (1070705004_SC1) */
		/* �j���I�P�~�F�d���u���ɡA��ɩ�Q�I�����ȥ�ñ�֡A�ҥH�b�鵲�ɶ��^�ɪ��A=130  modify by sylvia 110.09.09 (1100608003_SC2)  */
        if ((dclosing_type[0]=='T')||(dclosing_type[0]=='C') ||(dclosing_type[0]=='F'))
        {
            sprintf(sStmt,"UPDATE %s:settlement \
                              SET (dclose) = (?), \
                                  vouch_state =  130 \
                            WHERE iclaim = '%s' AND fstl ='%s' AND iclose_type = %d ",
                    sFullName_ply, iclaim, fstl, iclose_type);
        }
        else
        {
        		sprintf(sStmt,"UPDATE %s:settlement \
            		              SET (dclose) = (?) \
                		        WHERE iclaim = '%s' AND fstl ='%s' AND iclose_type = %d ",
                sFullName_ply, iclaim, fstl, iclose_type);
				}
        $PREPARE u_12 FROM $sStmt;
        $EXECUTE u_12 USING $stldate;


        printf("----- update payment\n");
        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"update payment iclaim:");
        strcat(err_buf,iclaim);
        strcat(err_buf," fstl:");
        strcat(err_buf,fstl);
        strcat(err_buf," iclose_tp:");
        strcat(err_buf,itoa(iclose_type));

        sprintf(sStmt,"UPDATE %s:payment \
                          SET (ipay_area) = (?) \
                        WHERE iclaim = '%s' AND fstl ='%s' AND iclose_type = %d ",
                sFullName_ply, iclaim, fstl, iclose_type);
        $PREPARE u_pay_area FROM $sStmt;
        $EXECUTE u_pay_area USING $DBname;

        /*-----*/
        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"update ca_local_stl iclaim:");
        strcat(err_buf,iclaim);
        strcat(err_buf," fstl:");
        strcat(err_buf,fstl);
        strcat(err_buf," iclose_tp:");
        strcat(err_buf,itoa(iclose_type));



        printf("----- update ca_local_stl\n");
        printf ("ic[%s],fs[%s],icl_type[%d]\n",iclaim,fstl,iclose_type);


/*        strncpy(str_qserial,str_qserial+5,2);  */

        tmp_qserial[0] = str_qserial[8];
        tmp_qserial[1] = str_qserial[9];
        tmp_qserial[2] = '\0';
/*        strcpy(str_qserial,str_qserial[8,9]);   */
        printf("str_qserial[%s]\n",str_qserial);

        qserial=atoi(str_qserial);
        printf("qserial[%d]\n",qserial);

       strcpy(qserial1,substring(str_qserial,9,2));
       printf("**************************************");

       qserial2=atoi(qserial1);
       printf("qserial2[%d]\n",qserial2);

        /* ���@��߮׻Pcar539�������ɤ鵲���߮�  modify by sylvia  107.05.01 (1070403001_SC1) */
        if (strcmp(dclosing_type,"3") == 0)
        {
            sprintf (sStmt," UPDATE %s:ca_local_stl \
                                SET (qserial,dclose) = (?,?)  \
                              WHERE iclaim = '%s' \
                                AND fstl='%s' \
                                AND iclose_type = %d ",
                     sFullName_loc,iclaim,fstl,iclose_type);

        }
        else
        {
            /* car546�Bcar539�Bcar537�Bcar540, car926 ���� */

            sprintf (sStmt," UPDATE ca_local_stl \
                                SET (qserial,dclose) = (?,?)  \
                              WHERE iclaim = '%s' \
                                AND fstl='%s' \
                                AND iclose_type = %d ",
                     iclaim,fstl,iclose_type);
                     printf("2419:sStmt[%s]\n",sStmt);
        }
        $PREPARE u_local FROM $sStmt;
        $EXECUTE u_local USING $qserial2,$stldate ;
        printf("2423:sStmt[%s]\n",sStmt);
        printf("qserial[%d]\n",qserial);


        /**********************************/
        /* �B�z���פw���^��               */
        /**********************************/
        $SELECT fclaim_status
           INTO $fclaim_status_pre
           FROM ca_clm_process
          WHERE iclaim=$iclaim;
        printf("���פw���B�zbegin [%s]fclaim_status_pre[%d]\n", iclaim, fclaim_status_pre);

        strcpy(sWh1, " ");
        /* �߮פw�����פw�����A���� ���A�ˬd */
        if (fclaim_status_pre != 501)
        {
            if (fcard_class[0]=='2')
            {

                sprintf(stmt, "SELECT COUNT(*) "
                                "FROM %s:appraisal a "
                               "WHERE a.iclaim = ? "
                                 "AND (select count(*) "
                                 "       from %s:app_ins_type x "
                                 "      where x.iclaim = a.iclaim) = "
                                 "    (select count(distinct iins_type) "
                                 "       from %s:stl_ins_type x "
                                 "      where x.iclaim = a.iclaim "
                                 "        and x.dclose is not null "
                                 "        and x.flast = '1') "
                                 , sFullName_ply, sFullName_ply, sFullName_ply);

            }
            else
            {
                sprintf(stmt,  " insert into stl "
                               "SELECT iclaim, ivictim, iins_item, flast, (ivictim||iins_item) iins_type "
                                 "FROM %s:ca_stl_victim x "
                               "WHERE x.iclaim = ? "
                                 "AND ((iins_item[1,1] = 'A' and flast = '2') or "
                                 "     (iins_item[1,1] = 'B' and flast in ('1','2')) or "
                                 "     (iins_item[1,1] = 'C' and flast in ('1','2'))) "
                                 "AND x.dclose is not null "
                                , sFullName_ply);


                $PREPARE sel_stl_temp FROM $stmt;
                $EXECUTE sel_stl_temp using $iclaim;


                sprintf(stmt, "SELECT COUNT(*) "
                                "FROM %s:appraisal a "
                               "WHERE a.iclaim = ? "
                                 "AND (select count(*) "
                                 "       from %s:ca_app_victim x "
                                 "      where x.iclaim = a.iclaim) = "
                                 "    (select count(distinct iins_type) "
                                 "       from stl x "
                                 "      where x.iclaim = a.iclaim) "
                                 , sFullName_ply, sFullName_ply);



            }

            $PREPARE sel_stl FROM $stmt;
            $EXECUTE sel_stl INTO $clm_cnt USING $iclaim;

            if (clm_cnt > 0)
            {
               strcpy(sWh1, ", fclaim_status = 501 ");

               printf("���פw���B�zend [iclaim=%s, clm_cnt=%d (501), SQLCODE[%ld]\n", iclaim, clm_cnt, SQLCODE);

               if (fcard_class[0]=='2')
               {
                   sprintf(stmt,
                    " insert into sysdb:car_spec_policy_log (ikind, type, inumber, check_fedr, note, iclaim, iupdate, dupdate)   \
                         select 'D', type, inumber, check_fedr, note, iclaim, '%s', current    \
                           from sysdb:car_spec_policy   \
                          where iclaim  = ? ", userid );
                   $prepare ins_spec_log from $stmt;

                   printf("2526stmt=[%s]\n",stmt);

                   $execute ins_spec_log using $iclaim;

                   sprintf(stmt,
                    " delete from sysdb:car_spec_policy where iclaim = ? ");
                   $prepare del_spec from $stmt;
                   $execute del_spec using $iclaim;

                   printf("2535\n");
               }
            }
            else
            {
               printf("���פw���B�zend [iclaim=%s, clm_cnt=%d (401), SQLCODE[%ld]\n", iclaim, clm_cnt, SQLCODE);
            }
        }

        /************** add for clm_process **********************/
        for (i=0;i<db_num;i++)
        {
        	 printf("2547\n");
           sprintf(sStmt,"UPDATE %s:ca_clm_process \
                             SET dclose = ?, fclaim_status_pre = ? %s \
                           WHERE iclaim = ? ", list[i].dbname, sWh1);
           printf ("2518:aa[%s]\n", sStmt);
           $PREPARE d_id FROM $sStmt;
           $EXECUTE d_id USING $stldate, $fclaim_status_pre, $iclaim;
           $FREE d_id;
        } /* for loop */

 printf("2557\n");
        printf("sFullName_ply[%s]\n",sFullName_ply);
        printf("iclaim[%s]\n",iclaim);
        printf("fstl[%s]\n",fstl);
        printf("iclose_type[%d]\n",iclose_type);
        printf("istl_note[%s]\n",istl_note);
        printf("fcard_class[%s]\n",fcard_class);

        rtn = sRejectCustomer(sFullName_ply,iclaim,fstl,iclose_type,istl_note,fcard_class);
        if (rtn == FALSE){
            printf("CHECK REJECT CLIENT FALSE\n");
            printf("iclaim[%s]\n",iclaim);
            printf("fstl[%s]\n",fstl);
            printf("iclose_type[%d]\n",iclose_type);
            sprintf(err_buf, "sRejectCustomer[%s][%s][%d]", iclaim, fstl,iclose_type);
            goto optP_err;
        }

        /** car_spec_policy ���s�O������ **/
        $DELETE FROM car_spec_policy
          WHERE inumber = $ipolicy
            AND type = '1'
            AND check_fedr[1] = '2';


        /* �w��car546���ɪ����, ���^�� ca_viewer_pay  add by Winnie 112.12.05 (1120704003_A04) */
        /* �w��car539���ɪ����, ���^�� ca_onsiteproc_cost  add by sylvia 107.05.01 (1070403001_SC1) */
        /* �w��car537���ɪ����, ���^�� ca_health_recovery  add by sylvia  */
        /* �w��car540���ɪ����, ���^�� ca_tow_away  add by sylvia 108.03.29 (1070705004_SC1) */
        /* �w��car539���ɪ����, ���^�� �F�d�N�� 4 ==> 3 �÷s�W ca_clm_upd_log ��ơC  add by sylvia 109.09.08 (1090820001_SC1) */
        /* �w��car539���ɪ����,  �@�߷s�W�@��ca_clm_upd_log ��ơC  add by sylvia 109.12.28*/
        /* �w��car926(�j���I�P�~�F�d���u) ��J�����,�^��ca_clm_com_trans  modify by sylvia 110.09.09 (1100608003_SC2)  */
        strcpy(tmpstr1," ");
        if (((strcmp(dclosing_type,"A") == 0)||(strcmp(dclosing_type,"B") == 0) ||
             (strcmp(dclosing_type,"T") == 0)||(strcmp(dclosing_type,"C") == 0) ||(strcmp(dclosing_type,"F") == 0)
			 ||(strcmp(dclosing_type,"D") == 0))
             && (strlen(sItransno) > 10))
        {
           if (strcmp(dclosing_type,"A") == 0)
           {
              strcpy(tmpstr1,"sysdb:ca_onsiteproc_cost");	/* �{���B�z�O */

              /* --- ���^�� �F�d�N�� 4 ==> 3 �÷s�W ca_clm_upd_log ��� ---- */
              iFacc_duty = iFdmg_duty = 0;
              sprintf(sTmp_duty,"select facc_duty, fdmg_duty from %s:appraisal where iclaim = '%s' ",
                     sFullName_ply, iclaim);

              $PREPARE duty01 FROM $sTmp_duty;
              $EXECUTE duty01 INTO $iFacc_duty, $iFdmg_duty;

              if(iFacc_duty == 4)
              {
                    sprintf(sTmp_duty,"update %s:appraisal set facc_duty = '3' where iclaim = '%s' and facc_duty = '4' ",
                                   sFullName_ply, iclaim);
                    $PREPARE duty02 FROM $sTmp_duty;
                    $EXECUTE duty02 ;

                    $insert into sysdb:ca_clm_upd_log
                     (iclaim, ifield, ndata_after, ndata_before, icreate, dcreate)
                     values
                     ($iclaim, '2', '3', '4', 'CAR539', current);
               }
               else
               {
	               		$insert into sysdb:ca_clm_upd_log
	                     (iclaim, ifield, ndata_after, ndata_before, icreate, dcreate)
	                     values
	                     ($iclaim, '2', $iFacc_duty, $iFacc_duty, 'CAR539', current);
								}

              if(iFdmg_duty == 4)
              {
                    sprintf(sTmp_duty,"update %s:appraisal set fdmg_duty = '3' where iclaim = '%s' and fdmg_duty = '4' ",
                                   sFullName_ply, iclaim);
                    $PREPARE duty03 FROM $sTmp_duty;
                    $EXECUTE duty03 ;

                    $insert into sysdb:ca_clm_upd_log
                     (iclaim, ifield, ndata_after, ndata_before, icreate, dcreate)
                     values
                     ($iclaim, '1', '3', '4', 'CAR539', current);
               }
               else
               {
               			$insert into sysdb:ca_clm_upd_log
                     (iclaim, ifield, ndata_after, ndata_before, icreate, dcreate)
                     values
                     ($iclaim, '1', $iFdmg_duty, $iFdmg_duty, 'CAR539', current);
               }

              /* ----------------------------------------------------------- */

           }
           else if (strcmp(dclosing_type,"B") == 0)
              strcpy(tmpstr1,"sysdb:ca_health_recovery");	/* ���O�l�v */
           else if ((strcmp(dclosing_type,"C") == 0) || (strcmp(dclosing_type,"F") == 0))
              strcpy(tmpstr1,"sysdb:ca_clm_com_trans ");	/* �j���I�F�d�P�~���u */
           else if (strcmp(dclosing_type,"D") == 0)
		   {
			    $SELECT FIRST 1 "newa" || trim(ibranch_in)
			       into $ibranch_in
				   FROM ca_clm_process 
				  WHERE iclaim = $iclaim;
				
			    strcpy(tmpstr1,ibranch_in);
                strcat(tmpstr1,":ca_viewer_pay");  	/* ���T�O�Χ妸���ɤ鵲 */
		   }
           else
              strcpy(tmpstr1,"sysdb:ca_tow_away");				/* ��Q�I */

            sprintf(sStmt,"UPDATE %s \
                             SET dclose	= ? , \
                                 iqserial = ? , \
                                 iupdate = ? , \
                                 dupdate = current \
                           WHERE iclaim = ? \
                             AND itransno = ? ",tmpstr1 );
            $PREPARE uplog FROM $sStmt;
            $EXECUTE uplog using $stldate, $str_qserial, $userid, $iclaim, $sItransno;
            $FREE uplog;

            printf ("aa[%s]\n", sStmt);

        }
		
		
        /* ��ʥѲz���¨t�ο�J���O�l�v��(isign= ' '),���A�g�@����RBA��ISID  add by sylvia 109.07.29 */
            strcpy(sIsign, trim(sIsign));
            strcpy(sIfpce_id, trim(sIfpce_id));
				if ((strlen(sIsign) < 3) && (strcmp(sIfpce_id,"08628407") == 0) && (strcmp(fstl,"1") == 0))
				{
						printf(" ��ʥѲz���¨t�ο�J���O�l�v��(isign= ' '),���A�g�@����RBA��ISID \n");
		        memset(err_buf,0,sizeof(err_buf));
		        strcpy(err_buf,"�¨t�� insert cm_risk_claim error");

		        $insert into sysdb:cm_risk_claim
		         (iclaim, iclaim_risk, iclaim_sno, ipolicy, imember,
		          nmember, fmember, mstl, qtotal_uw, qtotal_clm,
		          qtotal_black, irisk_a, nrisk_a, irisk_b, nrisk_b,
		          insure_type, iins_kind, iins_class, iupdate, dupdate)
		         values
		         ($iclaim, ' ', $iclose_type, $ipolicy, $sIfpce_id,
						  '�åͺ֧Q���������d�O�I�p', '2', $msettle, '0','3',
						  '0',' ', ' ', ' ', ' ',
						  'C', 'C9', 'C', $userid, current);


		        memset(err_buf,0,sizeof(err_buf));
		        strcpy(err_buf,"�¨t�� insert cm_isid_log error");

		        $insert into cm_isid_log
		            (iref_num1, iref_num2, iref_num3, idata_type, imember,
		             nmember, icountry, idept, iins_class, fkind,
		             fbatch, irun_id, inotice, ileader, ftype,
		             icreate, dcreate)
		         values
		            ($iclaim, ' ', $iclose_type, 'A', '08628407',
		             '�åͺ֧Q���������d�O�I�p','TW', '3601', 'C', '3',
		             '1',' ', $userid, $iadjuster, 'N',
		             $userid, current);

				}

				/* �@��߮פ~����²�T, �妸���ɪ�car540, car537, car539, car546 ������²�T add by sylvia 109.10.30 (1090926004_SC1) */
				upd_smsg1[0]='\0';
				printf("dclosing_type=[%s]iclaim=[%s]iclose_type=[%d]\n",dclosing_type,iclaim,iclose_type);
				if ((strcmp(dclosing_type,"3") == 0) && (strcmp(fstl,"1") == 0))
				{
				    if ((strcmp(sIstl_flag, "B") != 0) && (strcmp(sIstl_flag,"8") != 0))
				    {
    					rc = upd_ca_lm_smsg(fcard_class, sFullName_ply, iclaim, iclose_type, iadjuster);
    					printf("upd_ca_lm_smsg = [%d]\n",rc);
    					printf("upd_smsg1=[%s]\n",upd_smsg1);
    				}
				}

        StlCurr=StlCurr->next;
    }

    /* ���O�l�v��,�C���H�鵲�帹���N��,�g�JRBA (cm_risk_claim) ��ISID (cm_isid_log) ��Ʈw add by sylvia 108.01.30 (1070309005_SC1) */
	/* car546���T�O�άO�¶O�� ���ݭn�g�JRBA ��ISID  add by Winnie 112.12.05 (1120704003_A04) */
	
    if (dclosing_type[0]=='B')
    {
        printf(" ���O�l�v��,�C���H�鵲�帹���N��,�g�JRBA (cm_risk_claim) ��ISID (cm_isid_log) ��Ʈw \n");
        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"insert cm_risk_claim error");

        $insert into cm_risk_claim
         select first 1 iqserial, ' ', ' ', idatano, '08628407','�åͺ֧Q���������d�O�I�p','2',
                (select sum(mpay) from sysdb:ca_health_recovery
                  where iqserial = a.iqserial),
                '0','3','0',' ', ' ', ' ', ' ', 'C', 'C9', 'C', iupdate, current
           from sysdb:ca_health_recovery a
          where iqserial = $str_qserial;


        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"insert cm_isid_log error");

        $insert into cm_isid_log
            (iref_num1, iref_num2, iref_num3, idata_type, imember,
             nmember, icountry, idept, iins_class, fkind,
             fbatch, irun_id, inotice, ileader, ftype,
             icreate, dcreate)
         values
            ($str_qserial, ' ', ' ', 'A', '08628407',
             '�åͺ֧Q���������d�O�I�p','TW', '3601', 'C', '3',
             '1',' ', $userid, $userid, 'N',
             $userid, current);
    }

    /* ��Q�I���ɥ�,�C���H�鵲�帹���N��,�g�JRBA (cm_risk_claim) ��ISID (cm_isid_log) ��Ʈw
       add by sylvia 108.03.29 (1070705004_SC1) */
    if (dclosing_type[0]=='T')
    {
        printf(" ��Q�I���ɥ�,�C���H�鵲�帹���N��,�g�JRBA (cm_risk_claim) ��ISID (cm_isid_log) ��Ʈw \n");
        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"insert cm_risk_claim error");

        $insert into cm_risk_claim
         select first 1 iqserial, ' ', ' ', idatano, '16784078','���ӿ��~�ѥ��������q','2',
                (select sum(mamount) from sysdb:ca_tow_away
                  where iqserial = a.iqserial),
                '0','3','0',' ', ' ', ' ', ' ', 'C', 'V9', 'C', iupdate, current
           from sysdb:ca_tow_away a
          where iqserial = $str_qserial;


        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"insert cm_isid_log error");

        $insert into cm_isid_log
            (iref_num1, iref_num2, iref_num3, idata_type, imember,
             nmember, icountry, idept, iins_class, fkind,
             fbatch, irun_id, inotice, ileader, ftype,
             icreate, dcreate)
         values
            ($str_qserial, ' ', ' ', 'A', '16784078',
             '���ӿ��~�ѥ��������q','TW', '3601', 'C', '3',
             '1',' ', $userid, $userid, 'N',
             $userid, current);
    }

    /* �j���I�F�d���u���ɥ�,�C���H�鵲�帹���N��,�g�JRBA (cm_risk_claim) ��ISID (cm_isid_log) ��Ʈw
       add by sylvia 110.09.09 (1100608003_SC2) */
    if (((dclosing_type[0]=='C') || (dclosing_type[0]=='F'))&&(strcmp(fstl,"1") == 0))
    {
        printf(" �j���I�F�d���u���ɥ�,�C���H�鵲�帹���N��,�g�JRBA (cm_risk_claim) ��ISID (cm_isid_log) ��Ʈw \n");
        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"insert cm_risk_claim error");

        /***  �u����W�١A�u�^����HC   ***/
        $SELECT first 1 c.ifpce_id, c.nchi_full into $sImerber, $sNmember
           FROM ca_clm_com_trans a, cu_code_data b, cu_customer c
          WHERE a.icompany = b.icode AND b.ncode = c.ifpce_id
            AND b.itype = 'HC'
            AND a.itransno = $sItransno;

        strcpy(sImerber, trim(sImerber));
        strcpy(sNmember, trim(sNmember));

        printf("str_qserial=[%s]sImerber=[%s]sNmember=[%s]\n",str_qserial,sImerber,sNmember);

        sprintf(sStmt,
                "insert into cm_risk_claim "
                "select first 1 a.iqserial, ' ', ' ', a.itransno, '%s','%s','2', "
                "       (select sum(mprem) from sysdb:ca_clm_com_trans "
                "         where itransno = a.itransno), "
                "       '0','3','0',' ', ' ', ' ', ' ', 'C', 'C9', 'C', iupdate, current "
                "  from sysdb:ca_clm_com_trans a "
                "  WHERE itransno = '%s' ", sImerber, sNmember, sItransno);

         $PREPARE dcltypeC FROM $sStmt;
         $EXECUTE dcltypeC ;


printf("--- 2821 --- \n");
        memset(err_buf,0,sizeof(err_buf));
        strcpy(err_buf,"insert cm_risk_claim error");

        $insert into cm_isid_log
            (iref_num1, iref_num2, iref_num3, idata_type, imember,
             nmember, icountry, idept, iins_class, fkind,
             fbatch, irun_id, inotice, ileader, ftype,
             icreate, dcreate)
         values
            ($str_qserial, ' ', ' ', 'A', $sImerber,
             $sNmember,'TW', '3601', 'C', '3',
             '1',' ', $userid, $userid, 'N',
             $userid, current);

printf("--- 2836 --- \n");

    }

    $WHENEVER SQLERROR GOTO optP_err;

    /**** STEP P6 *****************************************/
    printf("-> enter P6\n");

    EXEC SQL COMMIT WORK;

    printf("------> ca5083 finish \n");
    $SET LOCK MODE TO NOT WAIT;
    return M_CM_OK;

optP_err:
    printf("------> optP_err: \n");
    printf("sStmt[%s]\n",sStmt);

    if (dclosing_type[0]=='B')
    {
        strcat(err_buf,"\n\n �� ���O�l�v��Ƥw��J,���鵲����,�бqcar537�i�w���ɥ��鵲�j�i��鵲�@�~�I�I \n");
    }

    if (dclosing_type[0]=='T')
    {
        strcat(err_buf,"\n\n �� ��Q�I��Ƥ鵲����,�бqcar540�i�w���ɥ��鵲�j�i��鵲�@�~�I�I \n");
    }

    if (dclosing_type[0]=='C')
    {
        strcat(err_buf,"\n\n �� �j���I�F�d���u��Ƥ鵲����,�бqcar926�i���ɽ߮פ鵲�j�i��鵲�@�~�I�I \n");
    }

    if (dclosing_type[0]=='F')
    {
        strcat(err_buf,"\n\n �� �j���I�P�~���u��Ƥ鵲����,�бqcar929�i���ɽ߮פ鵲�j�i��鵲�@�~�I�I \n");
    }

    if (dclosing_type[0]=='D')
    {
        strcat(err_buf,"\n\n �� ���T�O�θ�Ƥw��J,���鵲����,�бqcar546�i�w���ɥ��鵲�j�i��鵲�@�~�I�I \n");
    }
	
    rc = cm_show_sql_err("ca508", "");
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;


}


/****************************************/
/*     ���o513�ҿ諸LocalDB���z�ߥ�     */
/****************************************/

int CheckSerialIAdjust(slistF,slistC,slistL,maxp3)
struct STL_LIST **slistF, **slistC, **slistL;
$char maxp3[15];
{
    $char tmp_iclaim[CLAIM_NUM], tmp_ipolicy[POLICY_NUM_1];
    $int  tmp_iclose_type, iCount, iCount1;
    char fspeed_5, fspeed_oth;
    $long lDadjust;
    $long  idate;
    int   count=0;
    $char tmp_fstl[2], sStmt[1024];
  /*  $static char str_qserial[20];  */
    int code;
    $static char   localdb[DBNAME];
    char  ymd[12];
    char sIunit[6], sIbranch_in[BRANCH_ID];
    $char   dbsub[3],  sFullName_ply[20], sFcard_class[2], sFreason[2];
    $int    ABflag, SPflag;
    $char   fspeed[2];
	int hasFspeedE = 0,NhasFspeedE = 0;	
    $char iclaim_E[CLAIM_NUM];
    $int iclose_type_E;

    printf("ch_dwritten[%s]\n",ch_dwritten);
        printf("DBname[%s]\n",DBname);

    ABflag = 0;
    SPflag = 0;

    code=cm_get_serial_num_dwritten("C3","4",DBname,DBname,ch_dwritten,ch_dwritten,str_qserial);

        if (code==1 || code==2)

            return M_CM_DB_NOTOPEN;
        else if (code==3)
            return M_CMN_NAUTONUMBERING;


        else if (code!=0)
        {
             printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
             return code;
        }


    printf("str_qserial[%s]\n",str_qserial);


    EXEC SQL WHENEVER SQLERROR GOTO chks_err;

    printf("---------- into CheckSerialIAdjust()\n");

    fspeed_5 = fspeed_oth = 0;

    if (strcmp(dclosing_type,"3") == 0)
    {
        EXEC SQL DECLARE CA508_3 CURSOR FOR
                  SELECT iclaim, ipolicy, dclose, iclose_type, fstl
                    FROM ca_local_stl
                   WHERE fchoose = "1"
                     AND (dclose IS NULL)
                     AND userid = $userid
                   ORDER BY iclaim, ipolicy;
        EXEC SQL OPEN CA508_3;

    }
    else if(strcmp(dclosing_type,"A") == 0)
    {
        EXEC SQL DECLARE CA508_A CURSOR FOR
                  SELECT a.iclaim, a.ipolicy, a.dclose, a.iclose_type, a.fstl
                    FROM ca_local_stl a, sysdb:ca_onsiteproc_cost b
                   WHERE a.iclaim = b.iclaim
                     AND a.fchoose = "1"
                     AND (a.dclose IS NULL and b.dclose is null)
                     and b.itransno = $sItransno
                     AND userid = $userid
                   ORDER BY iclaim, ipolicy;
        EXEC SQL OPEN CA508_A;
    }
    else if(strcmp(dclosing_type,"B") == 0)
    {
        EXEC SQL DECLARE CA508_B CURSOR FOR
                  SELECT unique a.iclaim, a.ipolicy, a.dclose, a.iclose_type, a.fstl
                    FROM ca_local_stl a, sysdb:ca_health_recovery b
                   WHERE a.iclaim = b.iclaim
                     AND a.fchoose = "1"
                     AND (a.dclose IS NULL and b.dclose is null)
                     and b.itransno = $sItransno
                     AND userid = $userid
                   ORDER BY iclaim, ipolicy;
        EXEC SQL OPEN CA508_B;
    }
    else if(strcmp(dclosing_type,"T") == 0)
    {
        EXEC SQL DECLARE CA508_T CURSOR FOR
                  SELECT unique a.iclaim, a.ipolicy, a.dclose, a.iclose_type, a.fstl
                    FROM ca_local_stl a, sysdb:ca_tow_away b
                   WHERE a.iclaim = b.iclaim
                     AND a.fchoose = "1"
                     AND (a.dclose IS NULL and b.dclose is null)
                     and b.itransno = $sItransno
                     AND userid = $userid
                   ORDER BY iclaim, ipolicy;
        EXEC SQL OPEN CA508_T;
    }
    else if ((strcmp(dclosing_type,"C") == 0) || (strcmp(dclosing_type,"F") == 0))
    {
        EXEC SQL DECLARE CA508_C CURSOR FOR
                  SELECT unique a.iclaim, a.ipolicy, a.dclose, a.iclose_type, a.fstl
                    FROM ca_local_stl a, sysdb:ca_clm_com_trans b
                   WHERE a.iclaim = b.iclaim
                     AND a.fchoose = "1"
                     AND (a.dclose IS NULL and b.dclose is null)
                     and b.itransno = $sItransno
                   ORDER BY iclaim, ipolicy;
        EXEC SQL OPEN CA508_C;
    }
    else if(strcmp(dclosing_type,"D") == 0)
    {
        EXEC SQL DECLARE CA508_D CURSOR FOR
                  SELECT unique a.iclaim, a.ipolicy, a.dclose, a.iclose_type, a.fstl
                    FROM ca_local_stl a, (select iclaim,dclose,itransno from newa00:ca_viewer_pay 
						                      union all
											  select iclaim,dclose,itransno from newa22:ca_viewer_pay
											  union all
											  select iclaim,dclose,itransno from newa33:ca_viewer_pay
											  union all
											  select iclaim,dclose,itransno from newa40:ca_viewer_pay
											  union all
											  select iclaim,dclose,itransno from newa66:ca_viewer_pay
											  union all
											  select iclaim,dclose,itransno from newa70:ca_viewer_pay											  
											 ) b
                   WHERE a.iclaim = b.iclaim
                     AND a.fchoose = "1"
                     AND (a.dclose IS NULL and b.dclose is null)
                     and b.itransno = $sItransno
                     AND userid = $userid
                   ORDER BY iclaim, ipolicy;
        EXEC SQL OPEN CA508_D;
    }

    while (1)
    {
        if (strcmp(dclosing_type,"3") == 0)
        {
            EXEC SQL FETCH CA508_3 INTO :tmp_iclaim ,:tmp_ipolicy,
                                        :lDadjust, :tmp_iclose_type ,:tmp_fstl;
        }
        else if (strcmp(dclosing_type,"A") == 0)
        {
            EXEC SQL FETCH CA508_A INTO :tmp_iclaim ,:tmp_ipolicy,
                                        :lDadjust, :tmp_iclose_type ,:tmp_fstl;
        }
        else if (strcmp(dclosing_type,"B") == 0)
        {
            EXEC SQL FETCH CA508_B INTO :tmp_iclaim ,:tmp_ipolicy,
                                        :lDadjust, :tmp_iclose_type ,:tmp_fstl;
        }
        else if (strcmp(dclosing_type,"T") == 0)
        {
            EXEC SQL FETCH CA508_T INTO :tmp_iclaim ,:tmp_ipolicy,
                                        :lDadjust, :tmp_iclose_type ,:tmp_fstl;
        }
        else if ((strcmp(dclosing_type,"C") == 0) || (strcmp(dclosing_type,"F") == 0))
        {
            EXEC SQL FETCH CA508_C INTO :tmp_iclaim ,:tmp_ipolicy,
                                        :lDadjust, :tmp_iclose_type ,:tmp_fstl;
        }
        else if (strcmp(dclosing_type,"D") == 0)
        {
            EXEC SQL FETCH CA508_D INTO :tmp_iclaim ,:tmp_ipolicy,
                                        :lDadjust, :tmp_iclose_type ,:tmp_fstl;
        }

        if (SQLCODE==SQLNOTFOUND) break;

        printf("clm[%s] ply[%s] cls_tp[%d]fstl [%s]\n",tmp_iclaim,tmp_ipolicy,tmp_iclose_type,tmp_fstl);



        if ((code = split_policy(tmp_ipolicy, sIpolicy1, sIpolicy2)) != M_CM_OK)
             return code ;
        /***************************/

        code = cm_get_unit_in(sIpolicy1, DBname," " , sIunit,"C3" ,dbsub, sIbranch_in);
        if(code != M_CM_OK)
           return  code ;

        strcpy(sFullName_ply,get_full_dbname(dbsub));

        strcpy(vouch_state,"");

        fspeed[0] = '\0';

        /****** start �ߥI�t��E���ץ�A�г�W�鵲 ******/
        sprintf(sStmt," select nvl(min(fspeed),' ') from %s:payment where iclaim = '%s' AND fstl = '%s' AND iclose_type = %d "
                        , sFullName_ply, tmp_iclaim, tmp_fstl, tmp_iclose_type);
        $prepare get_fspeedE from $sStmt;
        $execute get_fspeedE into $fspeed;
        
        printf("stmt_E[%s]\n", sStmt);
        printf("iclaim_E[%s], fspeed_E[%s],fspeed[0][%c]\n", tmp_iclaim, fspeed,fspeed[0]);

        if(fspeed[0] == 'E')
        {
            hasFspeedE = 1;
            strcpy(iclaim_E,tmp_iclaim);
            iclose_type_E = tmp_iclose_type;
        }            
        else{
            NhasFspeedE = 1;
        }            
        
        printf("hasFspeedE[%d], NhasFspeedE[%d]\n", hasFspeedE, NhasFspeedE);

        if(hasFspeedE + NhasFspeedE == 2)
        {
            sprintf(err_buf,"�׸�[%s], �߰l�ʽ�[2], �߰l����[%d] ���ߥI�t��E�A�г�W�鵲�C \n",
					 iclaim_E, iclose_type_E);
		    return FAIL;
        }     

        /****** end �ߥI�t��E���ץ�A���i�P��L�t�פ@�P�鵲 ******/

        sprintf(sStmt," select nvl(min(fspeed),' ') from %s:payment where iclaim = '%s' AND fstl = '%s' AND iclose_type = %d \
                          and fspeed in ('A','B') ", sFullName_ply, tmp_iclaim, tmp_fstl, tmp_iclose_type);
        $prepare get_fspeed from $sStmt;
        $execute get_fspeed into $fspeed;

        printf("stmt[%s]\n", sStmt);
        printf("iclaim[%s], fspeed[%s]\n", tmp_iclaim, fspeed);

		if (fspeed[0] == 'A' || fspeed[0] == 'B')
		{
		   ABflag = 1;
		}
		else
		{
		   SPflag = 1;
		}

        printf("ABflag[%d], SPflag[%d]\n",ABflag,SPflag);

        if (ABflag == 1 && SPflag == 1)
			{
		       sprintf(err_buf,"�׸�[%s], �߰l�ʽ�[%s], �߰l����[%d] ���ɽ߮פΤ@���߮פ��i�P�ɤ鵲 \n",
					 tmp_iclaim, tmp_fstl, tmp_iclose_type);
		       return FAIL;
			}

        sprintf(sStmt, "SELECT fcard_class, case when d_reason is null then '0' else '1' end, vouch_state "
                       "  FROM %s:settlement "
                       " WHERE iclaim= ? "
                       "   AND iclose_type = ? "
                       "   AND fstl= ? " , sFullName_ply);

        $PREPARE prep1 FROM $sStmt;
        $EXECUTE prep1 INTO $sFcard_class, $sFreason, $vouch_state USING $tmp_iclaim, $tmp_iclose_type, $tmp_fstl;

        if (SQLCODE != SQLNOTFOUND)
        {
           strcpy(vouch_state,trim(vouch_state));

			/* �]��Q�I���A����100,���鵲��@�֦^��130,�G���ư���Q�I���ɥ� modify by sylvia 108.03.29 (1070705004_SC1) */
           if (strncmp(vouch_state,"130",3) != 0)
           {
           		 if ((strcmp(dclosing_type,"T") != 0) && (strcmp(dclosing_type,"C") != 0) && (strcmp(dclosing_type,"F") != 0))
           		 {
	               if (strncmp(vouch_state,"80",2) == 0) strcpy(nvouch_state,"80.�h�^ñ��");
	               if (strncmp(vouch_state,"90",2) == 0) strcpy(nvouch_state,"90.�h��");
	               if (strncmp(vouch_state,"100",3) == 0) strcpy(nvouch_state,"100.��ñ��");
	               if (strncmp(vouch_state,"110",3) == 0) strcpy(nvouch_state,"110.ñ�֤�");

	               printf("vouch_state [%s], nvouch_state [%s]\n",vouch_state, nvouch_state);

	               sprintf(err_buf,"�׸�[%s], �߰l�ʽ�[%s], �߰l����[%d] ���A����ñ�֧����A�ثe���A��[%s]�A�O�_�N�����������צA�@�鵲�C \n",
								 tmp_iclaim, tmp_fstl, tmp_iclose_type, nvouch_state);
	               return FAIL;
             	 }
           }
        }

        if( sFcard_class[0] == '2')
            sprintf(sStmt, "SELECT count(*) "
                           "  FROM %s:stl_ins_type "
                           " WHERE iclaim= ? "
                           "   AND iclose_type = ? "
                           "   AND fstl= ?  "
                           "   AND dclose IS NOT NULL " , sFullName_ply);
        else
            sprintf(sStmt, "SELECT count(*) "
                           "  FROM %s:ca_stl_victim "
                           " WHERE iclaim= ? "
                           "   AND iclose_type = ? "
                           "   AND fstl= ?  "
                           "   AND dclose IS NOT NULL " , sFullName_ply);

        $PREPARE prep2 FROM $sStmt;
        $EXECUTE prep2 INTO $iCount USING $tmp_iclaim, $tmp_iclose_type, $tmp_fstl;
        $FREE prep2;

        if( iCount != 0)	/* �����פ� */
        {
           if( sFreason[0] == '0')	/* ���O�h�� */
           {
               sprintf(err_buf,"�׸�[%s], �߰l�ʽ�[%s], �߰l����[%d] �w�鵲�A���i�A���A�нT�{ \n",
				tmp_iclaim, tmp_fstl, tmp_iclose_type);
               return FAIL;
           }
        }

        /* ���O�l�v�ߥI�P��L�����߮פ��o�P�ɤ鵲 */
        sprintf(sStmt, "SELECT NVL(SUM(CASE WHEN fspeed='5' THEN 1 ELSE 0 END),0), "
                             " NVL(SUM(CASE WHEN fspeed='5' THEN 0 ELSE 1 END),0) "
                       "  FROM %s:payment "
                       " WHERE iclaim= ? "
                       "   AND iclose_type = ? "
                       "   AND fstl= ? " , sFullName_ply);
        $PREPARE prep3 FROM $sStmt;
        $EXECUTE prep3 INTO $iCount, $iCount1 USING $tmp_iclaim, $tmp_iclose_type, $tmp_fstl;
        if (iCount > 0) fspeed_5 = 1;
        if (iCount1 > 0) fspeed_oth = 1;
        printf("fspeed_5[%d]fspeed_oth[%d]\n", fspeed_5, fspeed_oth);

        if (fspeed_5==1 && fspeed_oth==1)
        {
            sprintf(err_buf, "�׸�[%s], �߰l�ʽ�[%s], �߰l����[%d] ���O�l�v�ߥI�P��L�����߮פ��o�P�ɤ鵲�I",
                tmp_iclaim, tmp_fstl, tmp_iclose_type);
            return FAIL;
        }

        *slistC=(struct STL_LIST *)malloc(sizeof(struct STL_LIST));
        if (*slistC==NULL)
        {
            printf("malloc fail in struct STL_LIST allocation!\n");
            strcpy(err_buf,"malloc fail in struct STL_LIST allocation");
            if (strcmp(dclosing_type,"3") == 0)
            {
                $CLOSE CA508_3;
                $FREE  CA508_3;
            }
            else if (strcmp(dclosing_type,"A") == 0)
            {
                $CLOSE CA508_A;
                $FREE  CA508_A;
            }
            else if (strcmp(dclosing_type,"B") == 0)
            {
                $CLOSE CA508_B;
                $FREE  CA508_B;
            }
            else if (strcmp(dclosing_type,"T") == 0)
            {
                $CLOSE CA508_T;
                $FREE  CA508_T;
            }
            else if ((strcmp(dclosing_type,"C") == 0) || (strcmp(dclosing_type,"F") == 0))
            {
                $CLOSE CA508_C;
                $FREE  CA508_C;
            }
            else if (strcmp(dclosing_type,"D") == 0)
            {
                $CLOSE CA508_D;
                $FREE  CA508_D;
            }

            return M_CM_NOT_MALLOC;
        }
        /*** use a  list ***/
        if (*slistF==NULL) {    /* if it's first element?! */
            *slistF=*slistL=*slistC;
        } else {
            (*slistL)->next=*slistC;
            *slistL = *slistC;        /* add by tony at 83/05/05 */
        }
        strcpy((*slistC)->iclaim, rtrim(tmp_iclaim));
        (*slistC)->iclose_type=tmp_iclose_type;
        strcpy((*slistC)->ipolicy,tmp_ipolicy);
        (*slistC)->dadjust = lDadjust;
        strcpy((*slistC)->fstl,tmp_fstl);
        (*slistC)->next=NULL;
        printf ("check fstl [%s]\n",(*slistC)->fstl);
        count++;
    }

    printf("------------ [CheckSerialIAdjust]:count=%d\n",count);
    if (strcmp(dclosing_type,"3") == 0)
    {
        $CLOSE CA508_3;
        $FREE  CA508_3;
    }
    else if (strcmp(dclosing_type,"A") == 0)
    {
        $CLOSE CA508_A;
        $FREE  CA508_A;
    }
    else if (strcmp(dclosing_type,"B") == 0)
    {
        $CLOSE CA508_B;
        $FREE  CA508_B;
    }
    else if (strcmp(dclosing_type,"T") == 0)
    {
        $CLOSE CA508_T;
        $FREE  CA508_T;
    }
    else if ((strcmp(dclosing_type,"C") == 0) || (strcmp(dclosing_type,"F") == 0))
    {
        $CLOSE CA508_C;
        $FREE  CA508_C;
    }
    else if (strcmp(dclosing_type,"D") == 0)
    {
        $CLOSE CA508_D;
        $FREE  CA508_D;
    }

    if (count==0) return M_CM_NOT_FOUND;
    return SUCCESS;

chks_err:
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    memset(err_buf,0,sizeof(err_buf));
    strcpy(err_buf,maxp3);
    return SQLCODE;
}


int sRejectCustomer(sRfulldbname,sRiclaim,sRfstl,iRiclose_type,sRistl_note,sRfcard_class)
$char sRfulldbname[21];
$char sRiclaim[21];
$char sRfstl[2];
$int  iRiclose_type;
$char sRistl_note[4];
$char sRfcard_class[2];
{
$int    iReject,iRejCnt,iDtlCnt,iCaStlVic,iRejCnt2;
$char   sIclaim_R[21],sIsign[21],sIagent[13],sNagent[51];
$char   sIassured_R[21],sIpolicy_R[21],sNassured_R[121],sItag_R[CA_TAG_NUM], sIengine_R[CA_ENGINE_NUM];
$char   sStmt[2048];
$char remark[101];
$char iadjuster[11];
$char REJECT_REMARK[100];

$WHENEVER SQLERROR GOTO errexit;
	iReject = FALSE;
	iRejCnt = 0;
	iDtlCnt = 0;
	iCaStlVic = 0;
	iRejCnt2 = 0;
	sprintf(sStmt,
			" SELECT a.iassured,b.ipolicy,a.nassured,b.iadjuster, a.itag, a.iengine  \
			FROM %s:adjustment_ply a,%s:appraisal b   \
			WHERE a.iclaim = '%s'                     \
			AND a.iclaim = b.iclaim ",sRfulldbname,sRfulldbname,sRiclaim);
	printf("sStmt[%s]\n",sStmt);

	$PREPARE sdetail FROM $sStmt;
	$EXECUTE sdetail INTO $sIassured_R,$sIpolicy_R,$sNassured_R,$iadjuster, $sItag_R, $sIengine_R;

	if (SQLCODE == SQLNOTFOUND)
	{
		strcpy(sIassured_R," ");
		strcpy(sIpolicy_R," ");
		strcpy(sItag_R," ");
		strcpy(sIengine_R," ");
	}
	stpcpy(iadjuster,trim(iadjuster));
	sprintf(REJECT_REMARK,"; �z�ߤH���G%s; �߮׸��X�G%s",iadjuster,sRiclaim);
	/* �ګO�Ȥ�B�z */
	if (strncmp(sRistl_note,"004",3) == 0)
	{
		iReject = TRUE;
		strcpy(remark,sRistl_note);
	}
	/*015�G��ĳ������O*/
	else if(strncmp(sRistl_note,"015",3) == 0)
	{   /*�鵲�ɼg�J�ګO�Ȥ� (1100805001_SC1)*/
		
		/*CAR140����ID������ID*/
		$char sIassured_TMP[21];
		strcpy(sIassured_TMP, " ");

		$SELECT detail2
		FROM car_code
		WHERE kind = 'CL'
		AND detail = 'REJECT_CAR5083'
		AND detail2 = $sIassured_R;
		
		if (SQLCODE != 0)
		{
			strcpy(sIassured_TMP, sIassured_R);
		}

		sprintf(remark,"��ĳ���P��O%s",REJECT_REMARK);
		$INSERT INTO reject_client
		(nassured,ilicense,itag,iengine,ibody,freason,remark,
		icreate,dcreate,iupdate,dupdate)
		VALUES('',$sIassured_TMP,$sItag_R,$sIengine_R,'','5', $remark,
		'car5083',today,'car5083',CURRENT);
	}
	else
	{

		printf("INTO Reject_client CalCnt3157\n");

		sprintf(sStmt,
		" SELECT count(*)                                \
		  FROM %s:adjustment_ply a,%s:appraisal b      \
		 WHERE a.iassured = '%s'                       \
		   AND b.ipolicy = '%s'                        \
		   AND a.iclaim = b.iclaim ",
		sRfulldbname,sRfulldbname,sIassured_R,sIpolicy_R);

		printf("sStmt[%s]\n",sStmt);

		$PREPARE iasscnt FROM $sStmt;
		$EXECUTE iasscnt INTO $iRejCnt;

		printf("sIassured_R[%s]\n",sIassured_R);
		printf("sIpolicy_R[%s]\n",sIpolicy_R);
		printf("iRejCnt[%d]\n",iRejCnt);

		/* ���׻F�d�A�鵲�߮׹F5���H�W */
		if (iRejCnt >= 5)
		{
			iCaStlVic = 0;

			printf("INTO Second iCaStlVic[%d]\n",iCaStlVic);

			sprintf(sStmt,
			" SELECT a.iclaim                                \
			  FROM %s:adjustment_ply a,%s:appraisal b      \
			 WHERE a.iassured = '%s'                       \
			   AND b.ipolicy = '%s'                        \
			   AND a.iclaim = b.iclaim ",
			sRfulldbname,sRfulldbname,sIassured_R,sIpolicy_R);

			printf("sStmt[%s]\n",sStmt);

			$PREPARE iassdtl FROM $sStmt;
			$DECLARE iass_cur CURSOR FOR iassdtl ;
			$OPEN iass_cur;
			for(;;)
			{
				$FETCH iass_cur INTO $sIclaim_R;
				if (SQLCODE == SQLNOTFOUND) break;

				printf("For loop sfcard_class[%s]\n",sRfcard_class);

				if (sRfcard_class[0] == '1')
				{
					sprintf(sStmt,
					" SELECT count(*)                     \
					   FROM %s:ca_stl_victim b           \
					  WHERE iclaim = '%s'                \
						AND fstl = '%s'                  \
						AND NOT ((mins_stl + mins_proc) = 0 AND flast = '1') \
						AND dclose IS NOT NULL ",
					 sRfulldbname,sIclaim_R,sRfstl,sRfulldbname);

					printf("sStmt[%s]\n",sStmt);

					$PREPARE vic_cnt FROM $sStmt;
					$EXECUTE vic_cnt INTO $iDtlCnt;
					if (iDtlCnt > 0) iCaStlVic++;

				}
				else
				{
					/* �I�إN�� 38 ,39�����p�� */
					sprintf(sStmt,
					" SELECT count(*)                     \
						FROM %s:stl_ins_type b            \
					   WHERE iclaim = '%s'                \
						 AND fstl = '%s'                  \
						 AND NOT ((mins_stl + mins_proc) = 0 AND flast = '1') \
						 AND dclose IS NOT NULL           \
						 AND iins_type not in ('38','39','238') ",
						sRfulldbname,sIclaim_R,sRfstl,sRfulldbname);

					printf("sStmt[%s]\n",sStmt);
					$PREPARE stins_cnt FROM $sStmt;
					$EXECUTE stins_cnt INTO $iDtlCnt;
					if (iDtlCnt > 0) iCaStlVic++;
				}
			}
			$CLOSE iass_cur;
			$FREE  iass_cur;
			printf("iCaStlVic[%d]\n",iCaStlVic);
			if (iCaStlVic >= 5) iReject = TRUE;
			strcpy(remark,"�P�@�O��z�߹F5��(�t)�A���׻F�d");
			strcat(remark," ; ");
			strcat(remark, trim(sNassured_R));
			strcat(remark," ; ");
			strcat(remark, trim(sIpolicy_R));
		}

		/* �ư��F�d2��3�A�鵲�߮׹F3���H�W */
		/* �YiRejCnt�j�󵥩�5�W���|������A���GiReject�Y��TRUE�h�H�U�N���ΰ��� */
		if (iRejCnt >= 3 && iReject == FALSE)
		{
			iCaStlVic = 0;
			iDtlCnt = 0;

			printf("INTO third iCaStlVic[%d]\n",iCaStlVic);

			sprintf(sStmt,
			" SELECT a.iclaim                                \
			  FROM %s:adjustment_ply a,%s:appraisal b      \
			 WHERE a.iassured = '%s'                       \
			   AND b.ipolicy = '%s'                        \
			   AND a.iclaim = b.iclaim ",
			sRfulldbname,sRfulldbname,sIassured_R,sIpolicy_R);

			printf("sStmt[%s]\n",sStmt);

			$PREPARE iassdtl FROM $sStmt;
			$DECLARE iass_cur1 CURSOR FOR iassdtl ;
			$OPEN iass_cur1;
			for(;;)
			{
				$FETCH iass_cur1 INTO $sIclaim_R;
				if (SQLCODE == SQLNOTFOUND) break;

				printf("For loop sfcard_class[%s]\n",sRfcard_class);

				if (sRfcard_class[0] == '1')
				{
					/* ���d�F�d�N����2��3�����p��*/
					sprintf(sStmt,
					" SELECT count(*)                     \
					   FROM %s:ca_stl_victim b           \
					  WHERE iclaim = '%s'                \
						AND fstl = '%s'                  \
						AND NOT ((mins_stl + mins_proc) = 0 AND flast = '1') \
						AND dclose IS NOT NULL           \
						AND iclaim in (SELECT iclaim FROM %s:appraisal \
										WHERE iclaim = b.iclaim        \
										  AND facc_duty not in ('2','3'))",
					 sRfulldbname,sIclaim_R,sRfstl,sRfulldbname);

					printf("sStmt[%s]\n",sStmt);

					$PREPARE vic_cnt FROM $sStmt;
					$EXECUTE vic_cnt INTO $iDtlCnt;
					if (iDtlCnt > 0) iCaStlVic++;

				}
				else
				{
					/* �I�إN�� 38 ,39�����p�� */
					/* ���d�B����F�d�N����2��3�����p�� */
					sprintf(sStmt,
					" SELECT count(*)                     \
						FROM %s:stl_ins_type b            \
					   WHERE iclaim = '%s'                \
						 AND fstl = '%s'                  \
						 AND NOT ((mins_stl + mins_proc) = 0 AND flast = '1') \
						 AND dclose IS NOT NULL           \
						 AND iins_type not in ('38','39','238') \
						 AND iclaim in (SELECT iclaim FROM %s:appraisal \
										 WHERE iclaim = b.iclaim \
										   AND ((SELECT fins_grp FROM insurance_type   \
												 WHERE iins_type = b.iins_type) = '1' \
										   AND fdmg_duty not in ('2','3')) \
											OR ((SELECT fins_grp FROM insurance_type   \
												 WHERE iins_type = b.iins_type) in ('2','3') \
										   AND facc_duty not in ('2','3')))",
						sRfulldbname,sIclaim_R,sRfstl,sRfulldbname);

					printf("sStmt[%s]\n",sStmt);
					$PREPARE stins_cnt FROM $sStmt;
					$EXECUTE stins_cnt INTO $iDtlCnt;
					if (iDtlCnt > 0) iCaStlVic++;
				}
			}
			$CLOSE iass_cur1;
			$FREE  iass_cur1;
			printf("iCaStlVic[%d]\n",iCaStlVic);
			if (iCaStlVic >= 3) iReject = TRUE;
			strcpy(remark,"�P�@�O��z�߹F3��(�t)");
			strcat(remark," ; ");
			strcat(remark, trim(sNassured_R));
			strcat(remark," ; ");
			strcat(remark, trim(sIpolicy_R));
		}

	}

	printf("iReject[%d]\n",iReject);
	/* ����car102�����,�N���R���A�s�W  modify by sylvia 107.09.06 (1070824009_SC10 */
	if (iReject == TRUE)
	{
		/* �۵M�H */
		printf("INTO reject_client\n");
		$SELECT ifpce_id
		FROM cu_customer
		WHERE ifpce_id = $sIassured_R
		 AND ifpce_id_ext = ' '
		 AND fassured in('1','3','5');
		if (SQLCODE == 0)
		{
			$SELECT count(*)
			  INTO $iDtlCnt
			  FROM reject_client
			 WHERE ilicense = $sIassured_R
			   AND freason = '1' and icreate = 'car5083';


			/* if (iDtlCnt == 0)
			$INSERT INTO reject_client (nassured,ilicense,itag,iengine,ibody,
			  freason,remark,icreate,dcreate)
			  VALUES (' ',$sIassured_R,' ',' ',' ','1',$remark,'car5083',today); */

			if (iDtlCnt > 0)
			{
				$delete from reject_client
				  WHERE ilicense = $sIassured_R
					AND freason = '1' and icreate = 'car5083';
			}

			strcat(remark,REJECT_REMARK);
			$INSERT INTO reject_client
				(nassured,ilicense,itag,iengine,ibody, freason,remark,
					icreate,dcreate, iupdate, dupdate, dexpire)
				VALUES (' ',$sIassured_R,' ',' ',' ','1',$remark,
						'car5083',today, 'car5083',current, add_months(today,24));

			printf("�۵M�HiDtlCnt[%d]\n",iDtlCnt);
		}
		else
		{
			/* �k�H */
			printf("INTO reject_client3308\n");
			$SELECT ifpce_id
			  FROM cu_customer
			 WHERE ifpce_id = $sIassured_R
			   AND ifpce_id_ext = ' '
			   AND fassured in('2','4','6');
			if (SQLCODE == 0)
			{
				if(strncmp(sItag_R," ",1)!=0)
				{
					/* ���P */
					$SELECT count(*)
					  INTO $iDtlCnt
					  FROM reject_client
					 WHERE freason = '1'
					   AND itag = $sItag_R and icreate = 'car5083';

					/* if (iDtlCnt == 0)
					$INSERT INTO reject_client
								(nassured    ,ilicense,itag    ,iengine,ibody,freason,remark ,icreate   ,dcreate)
						 VALUES (' ',' '     ,$sItag_R,' '    ,' '  ,'1'    ,$remark,'car5083',today); */

					if (iDtlCnt > 0)
					{
						$delete FROM reject_client
						  WHERE freason = '1'
							AND itag = $sItag_R and icreate = 'car5083';
					}
					strcat(remark,REJECT_REMARK);
					$INSERT INTO reject_client
						(nassured ,ilicense,itag ,iengine,ibody,freason,remark ,
						 icreate   ,dcreate, iupdate, dupdate, dexpire)
					 VALUES (' ',' '  ,$sItag_R,' '  ,' '  ,'1'    ,$remark,
							 'car5083',today, 'car5083',current, add_months(today,24));

					printf("�k�H���PiDtlCnt[%d]\n",iDtlCnt);
				}
				else
				{
					if(strncmp(sIengine_R," ",1)!=0)
					{
						/* �������X */
						$SELECT count(*)
						INTO $iDtlCnt
						FROM reject_client
						WHERE freason = '1'
						 AND iengine = $sIengine_R and icreate = 'car5083';

						/* if (iDtlCnt == 0)
						$INSERT INTO reject_client
								(nassured ,ilicense,itag    ,iengine    ,ibody,freason,remark ,icreate   ,dcreate)
						 VALUES (' ',' '     ,' '     ,$sIengine_R, ' ' ,'1'    ,$remark,'car5083',today); */

						if (iDtlCnt > 0)
						{
							$delete FROM reject_client
							WHERE freason = '1'
							  AND iengine = $sIengine_R and icreate = 'car5083';
						}
						strcat(remark,REJECT_REMARK);
						$INSERT INTO reject_client
							(nassured ,ilicense,itag ,iengine ,ibody,freason,remark ,
							 icreate   ,dcreate, iupdate, dupdate, dexpire)
						VALUES (' ',' '     ,' '     ,$sIengine_R, ' ' ,'1'    ,$remark,
							   'car5083',today, 'car5083',current, add_months(today,24));

						printf("�k�H�������XiDtlCnt[%d]\n",iDtlCnt);
					}
				}

			}
		}
	}

	/*1140312006_A01_�z�ߵ��O�s�W�a�JCAR102�W�h�˵��վ�A�N�l���D�ɤ����O�����N��H�s�i�ګO�ɡA�u���j��~���N��H�A�G�ư����N*/
	if (sRfcard_class[0] == '1')
	{
		sprintf(sStmt," SELECT isign                                         \
						  FROM sysdb:ca_sign_receipt                         \
						 WHERE iclaim = '%s'                                 \
						   AND iclose_type = '%d'                            \
						   AND isign != '' ", sRiclaim, iRiclose_type);
		printf("sStmt[%s]\n",sStmt);

		$PREPARE isign1 FROM $sStmt;
		$DECLARE isign_cur CURSOR FOR isign1 ;
		$OPEN isign_cur;
		for(;;)
		{
			$FETCH isign_cur INTO $sIsign;
			if (SQLCODE == SQLNOTFOUND) 
			{
				break;
			}
			sprintf(sStmt, " SELECT distinct a.iagent, a.nagent                                  \
							   FROM sysdb:ca_human_est a, sysdb:ca_human_ins b               \
							  WHERE a.ihuman_est = b.ihuman_est and a.iagent != '' and b.isign = '%s' and a.iclaim = '%s' ", sIsign, sRiclaim);
			printf("sStmt[%s]\n",sStmt);

			$PREPARE agentdetail FROM $sStmt;
			$EXECUTE agentdetail INTO $sIagent, $sNagent;
			
			if (SQLCODE == SQLNOTFOUND) 
			{
				continue;
			}
			sprintf(sStmt, " SELECT COUNT(*)                    \
							   FROM sysdb:reject_client         \
							  WHERE ilicense = '%s'             \
								and nassured = '%s'             \
								and freason = '5'             \
								and remark = '�j���I�N��H;%s' ", 
							sIagent, sNagent, sRiclaim);
			printf("sStmt[%s]\n",sStmt);
							
			$PREPARE iRej_Cnt FROM $sStmt;
			$EXECUTE iRej_Cnt INTO $iRejCnt2;
			
			if(iRejCnt2 == 0)
			{
				strcpy(remark,"�j���I�N��H;");
				strcat(remark,sRiclaim);
				$INSERT INTO reject_client
						(nassured, ilicense, itag, iengine, ibody, freason, remark, 
						 icreate, dcreate, iupdate, dupdate, dexpire)
				 VALUES ($sNagent, $sIagent, ' ', ' ', ' ', '5', $remark, 
						 'car5083', today, 'car5083', current, today);
			}
		}
	}
	
	return TRUE;

errexit:
    printf("sRejectCustomer ERROR \n");
    printf("SQLCODE [%d]\n",SQLCODE);
    return FALSE;
}

/*****************************************************************/
FreeStlList(slistF,slistC)
struct STL_LIST *slistF, *slistC;
{
    while (slistF != NULL)
    {
        slistC=slistF;
        slistF=slistC->next;
        free(slistC);
    }
}

int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
short mdy1[3], mdy2[3];
int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
    return datediff;
}


/****************************************************************/
/****************************************************************/
long get_next_workday(h_date)
$date h_date;
{
  /* ���o�U�@�u�@�� */

  int     k, count_db;
  $date   next_date;
  $int    h_count;
  DBinfo  *list;

   $whenever sqlerror goto errexit;

   for(;;)
   {
      $SELECT count(*)
         INTO $h_count
         FROM ca_holiday
        WHERE holiday_bgn <=  $h_date
          AND holiday_end >=  $h_date;

      if(h_count == 0)
      {
      	/* �D���� */

      	break;
      }
      else
      {
      	/* ���� */
      	$SELECT max(holiday_end)+1
           INTO $next_date
           FROM ca_holiday
          WHERE holiday_bgn <=  $h_date
            AND holiday_end >=  $h_date;

        if(SQLCODE == 0)
        {
        	h_date = next_date;
        }
      }
   }

   return h_date;

errexit:
	printf("sRejectCustomer ERROR \n");
	printf("SQLCODE [%d]\n",SQLCODE);
	return FALSE;
}

/****************************************************************/

long upd_ca_lm_smsg(Pfcard_class, PPlyDB, Pclaim, Pclose_type1, Padjuster)
$char Pfcard_class[2], PPlyDB[21], Pclaim[21], Padjuster[11];
$int Pclose_type1;
{
	$char sTpSql_V[3000], sTpSql_C[3000], sTpSql[1000], sTpSql2[1000], sTpSql3[500];
	$char sFclaim2[21], sFdclose[11], sFdgroup[11], sFientry[11];
	$int  iFclose_type2, iFmins_stl, iFmins_proc, iCntMsg;
	$char sReOpenClose[2];
	$char sFclose[2]; /* �߮ת��A Y:���פw�M N:�����w�M(���M) */
	$char sFsend[2];   /* Y: �ǰe²�T N:����²�T */
	$char sFcheck[3];  /* �O�_�ǰe²�T�ˮ֥N�X
	                     x0:0��,���o²�T(���M)
                       x1:�۩l0�ߤ��o²�T(���פw�M)
                       x2:0��,�ݽT�{(���פw�M)
                       x3:�D0��,�o²�T(���פw�M)
                       x4:�D0��,�o²�T(���M)
                       x5:�d�L���,����²�T
                       x6:���}�פ��o²�T
                       x7:�¶O�Τ��o²�T
                       */
	$char Pmsg_tel[11];
	$WHENEVER SQLERROR CONTINUE;

	iFmins_proc = iFmins_stl = 0;
	printf(" ------------- upd_ca_lm_smsg start ----------- \n\n");
	printf("Pfcard_class=[%s]PPlyDB=[%s]\n",Pfcard_class,PPlyDB);
	printf("Pclaim=[%s]Padjuster=[%s]\n",Pclaim,Padjuster);
	printf("Pclose_type1=[%d]\n",Pclose_type1);



	/* �d²�T�q�� */
	sprintf(sTpSql3,
					"select message_tel from %s:appraisal where iclaim = '%s'",
	          PPlyDB, Pclaim );
	$prepare get_tel from $sTpSql3;
	$execute get_tel INTO $Pmsg_tel;

	printf("Pmsg_tel=[%s]\n",Pmsg_tel);


	/* ���N�I */
	sprintf(sTpSql_V,
          "SELECT a.iclaim, a.iclose_type, sum(b.mins_stl), "
          "       sum(nvl(b.mins_proc,0)), b.dclose, b.dgroup, a.ientry, "
          "       Case when (Select count(*) from %s:app_ins_type where iclaim = a.iclaim) = "
			    "                 (select count(DISTINCT iins_type) from %s:stl_ins_type "
			    "                   where iclaim = a.iclaim and dclose is not null "
			    "                     and flast = '1') then 'Y' else 'N' end as fclose, "
	        "       Case when (Select count(*) from %s:app_ins_type where iclaim = a.iclaim) = "
			    "                 (select count(DISTINCT iins_type) from %s:stl_ins_type "
			    "                   where iclaim = a.iclaim and dclose is not null "
			    "                     and flast = '1') then "
			    "             CASE WHEN (SELECT sum(mins_stl) FROM %s:stl_ins_type d "
			    "                         WHERE d.iclaim = a.iclaim "
			    "                           AND d.iins_type NOT IN ('38','39','238') "
			    "                           AND d.fstl = '1'  ) = 0  THEN 'x1' ELSE  "
	  			"                   CASE WHEN (SELECT sum(msettle) FROM %s:settlement e "
	  			"                               WHERE e.iclaim = a.iclaim AND e.fstl = '1' "
	  			"                                 AND e.iclose_type = a.iclose_type ) = 0  "
	  			"                         THEN 'x2'	ELSE 'x3' END  END"
	        "       else "
	  	    "            CASE WHEN (SELECT sum(msettle) FROM %s:settlement e "
	  	    "                        WHERE e.iclaim = a.iclaim AND e.fstl = '1' "
	  	    "                          AND e.iclose_type = a.iclose_type ) = 0 "
	  	    "                 THEN 	'x0'	ELSE 	'x4' END "
	        "       end as fcheck "
          "  FROM %s:settlement a, %s:stl_ins_type b "
          " WHERE a.iclaim = b.iclaim       AND a.iclose_type = b.iclose_type "
          "   AND a.fstl = b.fstl           AND a.fstl = '1' "
          "   AND a.ientry[1,3] <> 'car'    AND b.iins_type NOT IN ('38','39','238') "
          "   AND a.dclose = today "
          "   AND a.iclaim = '%s' and a.iclose_type = %d "
          " GROUP BY 1,2,5,6,7,8,9;  ",
          PPlyDB, PPlyDB, PPlyDB, PPlyDB, PPlyDB, PPlyDB, PPlyDB,
          PPlyDB, PPlyDB, Pclaim, Pclose_type1);


	/* �j�� */
	sprintf(sTpSql_C,
          "SELECT a.iclaim, a.iclose_type, sum(b.mins_stl), "
          "       sum(nvl(b.mins_proc,0)), b.dclose, b.dgroup, a.ientry, "
          "       Case when (SELECT count(*) FROM %s:ca_app_victim WHERE iclaim = a.iclaim) = "
			    "                 (SELECT count(DISTINCT trim(iins_item)||trim(ivictim)) "
			    "                    FROM %s:ca_stl_victim WHERE iclaim = a.iclaim "
          "                     AND ((iins_item[1,1] = 'A' AND flast = '2') "
          "                           OR (iins_item[1,1] = 'B' AND flast IN ('1', '2')) "
          "                           OR (iins_item[1,1] = 'C' AND flast IN ('1', '2'))) "
	  		  "                     and dclose is not null ) then 'Y' else 'N' end as fclose, "
	        "       Case when (SELECT count(*) FROM %s:ca_app_victim WHERE iclaim = a.iclaim) = "
			    "                 (SELECT count(DISTINCT trim(iins_item)||trim(ivictim)) "
			    "                    FROM %s:ca_stl_victim  WHERE iclaim = a.iclaim  "
          "                     AND ((iins_item[1,1] = 'A' AND flast = '2') "
          "                      OR (iins_item[1,1] = 'B' AND flast IN ('1', '2')) "
          "                      OR (iins_item[1,1] = 'C' AND flast IN ('1', '2'))) "
	  		  "                     and dclose is not null ) then "
	  			"	           CASE WHEN (SELECT nvl(sum(mpayment),0) FROM %s:payment d "
	  			"	                       WHERE d.iclaim = a.iclaim AND d.fstl = '1' "
	  			"	                         AND fspeed IN ('1','3','4') and pay_kind in ('1','2','3','5') "
	  			"                          AND fassured IN ('1','3','5') ) = 0 "
	  			"                 THEN 'x1'  ELSE  "
	  			"		              CASE WHEN (SELECT nvl(sum(mpayment),0) FROM %s:payment e "
	  			"                             WHERE e.iclaim = a.iclaim AND e.fstl = '1' "
	  			"		                            AND e.iclose_type = a.iclose_type "
	  			"                               AND fspeed IN ('1','3','4') and pay_kind in ('1','2','3','5') "
	  			"                               AND fassured IN ('1','3','5')) = 0 "
	  			"                      THEN 'x2'  ELSE 'x3' END END "
	  	    "       else "
	  		  "           CASE WHEN (SELECT nvl(sum(mpayment),0) FROM %s:payment e "
	  		  "                       WHERE e.iclaim = a.iclaim AND e.fstl = '1' "
	  			"		                      AND e.iclose_type = a.iclose_type "
	  			"                         AND fspeed IN ('1','3','4') and pay_kind in ('1','2','3','5') "
	  			"                         AND fassured IN ('1','3','5')) = 0 "
	  			"                THEN 'x0'	ELSE 'x4' END "
	  	    "       end as fcheck "
          "  FROM %s:settlement a, %s:ca_stl_victim b "
          " WHERE a.iclaim = b.iclaim        AND a.iclose_type = b.iclose_type "
          "   AND a.fstl =  b.fstl           AND a.fstl = '1' "
          "   AND a.dclose = today           AND a.ientry[1,3] <> 'car' "
          "   AND (SELECT nvl(sum(CASE WHEN fspeed IN ('1','3','4') and pay_kind in ('1','2','3','5') "
          "                                 AND fassured IN ('1','3','5') THEN 1 "
  		    "                            WHEN mpayment > 0 THEN 0 "
  		    "                        ELSE 1 end),1) "
  		    "          FROM %s:payment WHERE iclaim = a.iclaim "
  		    "           AND iclose_type = a.iclose_type "
  		    "           AND fstl= a.fstl)  > 0 		    "
  		    "   AND a.iclaim = '%s' and a.iclose_type = %d "
          "   GROUP BY 1,2,5,6,7,8,9 ",
          PPlyDB, PPlyDB, PPlyDB, PPlyDB, PPlyDB, PPlyDB, PPlyDB,
          PPlyDB, PPlyDB, PPlyDB, Pclaim, Pclose_type1);

  /* �鵲��h�󭫷s�鵲 */
	sprintf(sTpSql2, "update %s:ca_clm_smsg "
	                 "   set dclose = today, "
	                 "       iupdate = 'car5083', "
	                 "       dupdate = current "
                   " where iclaim = '%s'  "
                   "   and iclose_type = %d "
                   "   and dclose is null ", PPlyDB, Pclaim, Pclose_type1) ;

	iFmins_stl =  iFmins_proc = iCntMsg = 0;
	if(Pfcard_class[0] == '1')
	{
		  printf("sTpSql_C=[%s]\n",sTpSql_C);
			$prepare PreSmsg1 from $sTpSql_C;
	}
	else
	{
			printf("sTpSql_V=[%s]\n",sTpSql_V);
			$prepare PreSmsg1 from $sTpSql_V;
	}

	$execute PreSmsg1
			INTO $sFclaim2, $iFclose_type2, $iFmins_stl, $iFmins_proc,
			     $sFdclose, $sFdgroup, $sFientry, $sFclose, $sFcheck;

	printf("PreSmsg1=[%d]\n",SQLCODE);

	if (SQLCODE == SQLNOTFOUND)
	{
		strcpy(sFcheck,"x5");	/* �d�L��� */
	}
	else
	{
		$select fclose into $sReOpenClose
		   from ca_local_stl
		  where iclaim = $Pclaim
		    and iclose_type = $Pclose_type1
		    and fstl = '1';

		if(strcmp(sReOpenClose,"1") == 0)
				strcpy(sFcheck,"x6");	/* ���}�פ���²�T */
		else if (strcmp(sFcheck,"x2") == 0)
		{
			if (iFmins_proc > 0)
				strcpy(sFcheck,"x7");	/* �¶O�Τ���²�T */
		}
	}

	printf("sFclaim2=[%s] iFclose_type2 = [%d]\n",sFclaim2,iFclose_type2);
	printf("iFmins_stl=[%d] iFmins_proc = [%d]\n",iFmins_stl,iFmins_proc);
	printf("sFdclose=[%s] sFdgroup = [%s]\n",sFdclose,sFdgroup);
	printf("sFientry=[%s] sFclose = [%s] sFcheck = [%s]\n",sFientry,sFclose,sFcheck);



	switch (sFcheck[1])
	{
		case '0':
		case '1':
		case '6':
		case '7':
			{
				strcpy(sFsend, "N");
      	sprintf(sTpSql, "insert into %s:ca_clm_smsg \
				                 (iclaim, iclose_type, dclose, mins_stl, fcheck, \
				                   fsend, fclose, message_tel, iadjuster, dgroup, \
				                   icreate, dcreate ) \
				                 values \
				                 ('%s', %d, today, %d, '%s', \
				                  '%s', '%s', '%s', '%s', today, \
			                    'car5083', current)",
			                    PPlyDB, Pclaim, Pclose_type1, iFmins_stl, sFcheck,
			                    sFsend, sFclose, Pmsg_tel, Padjuster ) ;

				printf("3687:sTpSql=[%s]\n",sTpSql);

				$PREPARE PreSmsg5 FROM $sTpSql;
				$execute PreSmsg5;

				printf("PreSmsg5=[%d]\n",SQLCODE);
				if (SQLCODE==-239)
				{
					/* �鵲��h�󭫷s�鵲 */
					printf("3695:sTpSql2=[%s]\n",sTpSql2);
					$PREPARE PreSmsg7B FROM $sTpSql2;
					$execute PreSmsg7B;

					printf("3712:PreSmsg7B=[%d]\n",SQLCODE);
				}
			}
			break;

		case '2':
			sprintf(sTpSql, "select count(*) from %s:ca_clm_smsg \
			                  where iclaim = '%s'  \
			                    and dclose is not null \
			                    and fsend = 'Y' and dsend is null ", PPlyDB, Pclaim) ;

			printf("3623:sTpSql=[%s]\n",sTpSql);

			$PREPARE PreSmsg2 FROM $sTpSql;
			$execute PreSmsg2 INTO $iCntMsg;

			printf("3628:iCntMsg=[%d]\n",iCntMsg);

			if (iCntMsg > 0)
			{
				strcpy(sFsend, "Y");
				sprintf(sTpSql, "update %s:ca_clm_smsg \
				                    set fclose = 'Y', \
				                        iupdate = 'car5083', \
				                        dupdate = current \
			                    where iclaim = '%s'  \
			                      and dclose is not null \
			                      and fsend = 'Y' and dsend is null ", PPlyDB, Pclaim) ;

				printf("3640:sTpSql=[%s]\n",sTpSql);

				$PREPARE PreSmsg3 FROM $sTpSql;
				$execute PreSmsg3;

				printf("PreSmsg3=[%d]\n",SQLCODE);
			}
			else
			{
				sprintf(sTpSql, "insert into %s:ca_clm_smsg \
				                 (iclaim, iclose_type, dclose, mins_stl, fcheck, \
				                   fsend, fclose, message_tel, iadjuster, dgroup, \
				                   icreate, dcreate ) \
				                 values \
				                 ('%s', %d, today, %d, '%s', \
				                  'Y', '%s', '%s', '%s', today, \
			                    'car5083', current)",
			                    PPlyDB, Pclaim, Pclose_type1, iFmins_stl,sFcheck,
			                    sFclose, Pmsg_tel, Padjuster ) ;

				printf("3658:sTpSql=[%s]\n",sTpSql);

				$PREPARE PreSmsg4 FROM $sTpSql;
				$execute PreSmsg4;

				printf("PreSmsg4=[%d]\n",SQLCODE);

				if (SQLCODE==-239)
				{
					/* �鵲��h�󭫷s�鵲 */
					printf("3666:sTpSql2=[%s]\n",sTpSql2);
					$PREPARE PreSmsg7A FROM $sTpSql2;
					$execute PreSmsg7A;

					printf("PreSmsg7A=[%d]\n",SQLCODE);
				}
			}
			break;

		case '3':
		case '4':
			{
      		strcpy(sFsend, "Y");
      		sprintf(sTpSql, "insert into %s:ca_clm_smsg \
				                 (iclaim, iclose_type, dclose, mins_stl, fcheck, \
				                   fsend, fclose, message_tel, iadjuster, dgroup, \
				                   icreate, dcreate ) \
				                 values \
				                 ('%s', %d, today, %d, '%s', \
				                  '%s', '%s', '%s', '%s', '', \
			                    'car5083', current)",
			                    PPlyDB, Pclaim, Pclose_type1, iFmins_stl, sFcheck,
			                    sFsend, sFclose, Pmsg_tel, Padjuster ) ;

					printf("3713:sTpSql=[%s]\n",sTpSql);

					$PREPARE PreSmsg6 FROM $sTpSql;

					$execute PreSmsg6;
					printf("3733PreSmsg6=[%d]\n",SQLCODE);

					if (SQLCODE==-239)
					{
						/* �鵲��h�󭫷s�鵲 */
						printf("3721:sTpSql2=[%s]\n",sTpSql2);
						$PREPARE PreSmsg7C FROM $sTpSql2;
						$execute PreSmsg7C;

						printf("PreSmsg7C=[%d]\n",SQLCODE);
					}
      }
      break;

		case '5':
			iFmins_stl = 0;
			strcpy(sFsend, "N");
			strcpy(sFclose," ");

			sprintf(sTpSql, "insert into %s:ca_clm_smsg \
					                 (iclaim, iclose_type, dclose, mins_stl, fcheck, \
					                   fsend, fclose, message_tel, iadjuster, dgroup, \
					                   icreate, dcreate ) \
					                 values \
					                 ('%s', %d, today, %d, '%s', \
					                  'N', '%s', '%s', '%s', today, \
				                    'car5083', current)",
				                    PPlyDB, Pclaim, Pclose_type1, iFmins_stl,sFcheck,
				                    sFclose, Pmsg_tel, Padjuster ) ;

				printf("3655:sTpSql=[%s]\n",sTpSql);

				$PREPARE PreSmsg_x5 FROM $sTpSql;
				$execute PreSmsg_x5;
			break;

		default:

			break;
	}

	printf("SQLCODE = [%d]\n",SQLCODE);

	sprintf(upd_smsg1,"%15.15s - %d \t �O�_�ǰT %s\t �w���M %s \t SQL=[%d][%s]\n",
	        trim(Pclaim),Pclose_type1,sFsend,sFclose,SQLCODE,sFcheck);
	printf("upd_smsg1=[%s]\n");
	/* strcat(upd_smsg,rtrim(upd_smsg1)); */
	printf(" ------------- upd_ca_lm_smsg end ----------- \n\n");

	return SUCCESS;
}
/* ------------------------------------------------------------------------- */
/* �ˮ֫O��O�_��IFRS �զX�N�X�θs�եN�X  add by sylvia 111.11.01  */
int ChkIFRS()
{
    $char sToday[11], sYN[2];
    $int  rtn, icnt_1, icntT, tmp_iclose_type;
    $char tmp_iclaim[21], tmp_ipolicy[21], tmp_fstl[2];
    $long lDadjust;

    $WHENEVER SQLERROR GOTO chkifrs_err;

		icnt_1 = 0;

    $select first 1 today into $sToday
       from car_code
      where 1=1;

    rtn = cm_get_IFRS_DATE(sToday, sYN);
    printf("sToday=[%s], sYN=[%s]\n",sToday,sYN);

    /*----------------------------------------------------------------*/
    /* IFRS�����ˮ� add by sylvia 111.10.18 (1110303007��SC3) */
    /*----------------------------------------------------------------*/

    /*   1120914001_A01_IFRS17 �t�X��Ʀ^�ɬ����ק�   */
    strcpy(sYN,"N");
    if (strcmp(sYN,"Y") == 0)
    {
        memset(err_buf,0,sizeof(err_buf));

        printf("------------ start check ifrs -------------- \n");
        printf("dclosing_type = [%s]\n",dclosing_type);

        if (strcmp(dclosing_type,"3") == 0)
        {
            EXEC SQL DECLARE CA508_3a CURSOR FOR
                      SELECT iclaim, ipolicy, dclose, iclose_type, fstl,
                      (select count(*) from policy_main_dtl
                        where insure_type = 'C' and isys_source = 'CAR'
                          and ipolicy1 = a.ipolicy[1,13]
                          and ipolicy2 = nvl(substr(a.ipolicy,14,4),' ')
                          and (nvl(iportfolio,' ') = ' ' or nvl(igroup_profit,' ') = ' '))
                        FROM ca_local_stl a
                       WHERE fchoose = '1'
                         AND (dclose IS NULL)
                         AND userid = $userid
                       ORDER BY iclaim, ipolicy;
            EXEC SQL OPEN CA508_3a;
        }
        else if(strcmp(dclosing_type,"A") == 0)
        {
            EXEC SQL DECLARE CA508_Aa CURSOR FOR
                      SELECT a.iclaim, a.ipolicy, a.dclose, a.iclose_type, a.fstl,
                      (select count(*) from policy_main_dtl
                        where insure_type = 'C' and isys_source = 'CAR'
                          and ipolicy1 = a.ipolicy[1,13]
                          and ipolicy2 = nvl(substr(a.ipolicy,14,4),' ')
                          and (nvl(iportfolio,' ') = ' ' or nvl(igroup_profit,' ') = ' '))
                        FROM ca_local_stl a, sysdb:ca_onsiteproc_cost b
                       WHERE a.iclaim = b.iclaim
                         AND a.fchoose = '1'
                         AND (a.dclose IS NULL and b.dclose is null)
                         and b.itransno = $sItransno
                         AND userid = $userid
                       ORDER BY iclaim, ipolicy;
            EXEC SQL OPEN CA508_Aa;
        }
        else if(strcmp(dclosing_type,"B") == 0)
        {
            EXEC SQL DECLARE CA508_Ba CURSOR FOR
                      SELECT unique a.iclaim, a.ipolicy, a.dclose, a.iclose_type, a.fstl,
                      (select count(*) from policy_main_dtl
                        where insure_type = 'C' and isys_source = 'CAR'
                          and ipolicy1 = a.ipolicy[1,13]
                          and ipolicy2 = nvl(substr(a.ipolicy,14,4),' ')
                          and (nvl(iportfolio,' ') = ' ' or nvl(igroup_profit,' ') = ' '))
                        FROM ca_local_stl a, sysdb:ca_health_recovery b
                       WHERE a.iclaim = b.iclaim
                         AND a.fchoose = '1'
                         AND (a.dclose IS NULL and b.dclose is null)
                         and b.itransno = $sItransno
                         AND userid = $userid
                       ORDER BY iclaim, ipolicy;
            EXEC SQL OPEN CA508_Ba;
        }
        else if(strcmp(dclosing_type,"T") == 0)
        {
            EXEC SQL DECLARE CA508_Ta CURSOR FOR
                      SELECT unique a.iclaim, a.ipolicy, a.dclose, a.iclose_type, a.fstl,
                      (select count(*) from policy_main_dtl
                        where insure_type = 'C' and isys_source = 'CAR'
                          and ipolicy1 = a.ipolicy[1,13]
                          and ipolicy2 = nvl(substr(a.ipolicy,14,4),' ')
                          and (nvl(iportfolio,' ') = ' ' or nvl(igroup_profit,' ') = ' '))
                        FROM ca_local_stl a, sysdb:ca_tow_away b
                       WHERE a.iclaim = b.iclaim
                         AND a.fchoose = '1'
                         AND (a.dclose IS NULL and b.dclose is null)
                         and b.itransno = $sItransno
                         AND userid = $userid
                       ORDER BY iclaim, ipolicy;
            EXEC SQL OPEN CA508_Ta;
        }
        else if ((strcmp(dclosing_type,"C") == 0) || (strcmp(dclosing_type,"F") == 0))
        {
            EXEC SQL DECLARE CA508_Ca CURSOR FOR
                      SELECT unique a.iclaim, a.ipolicy, a.dclose, a.iclose_type, a.fstl,
                      (select count(*) from policy_main_dtl
                        where insure_type = 'C' and isys_source = 'CAR'
                          and ipolicy1 = a.ipolicy[1,13]
                          and ipolicy2 = nvl(substr(a.ipolicy,14,4),' ')
                          and (nvl(iportfolio,' ') = ' ' or nvl(igroup_profit,' ') = ' '))
                        FROM ca_local_stl a, sysdb:ca_clm_com_trans b
                       WHERE a.iclaim = b.iclaim
                         AND a.fchoose = '1'
                         AND (a.dclose IS NULL and b.dclose is null)
                         and b.itransno = $sItransno
                       ORDER BY iclaim, ipolicy;
            EXEC SQL OPEN CA508_Ca;
        }
        else if(strcmp(dclosing_type,"D") == 0)
        {
            EXEC SQL DECLARE CA508_Da CURSOR FOR
                      SELECT unique a.iclaim, a.ipolicy, a.dclose, a.iclose_type, a.fstl,
                      (select count(*) from policy_main_dtl
                        where insure_type = 'C' and isys_source = 'CAR'
                          and ipolicy1 = a.ipolicy[1,13]
                          and ipolicy2 = nvl(substr(a.ipolicy,14,4),' ')
                          and (nvl(iportfolio,' ') = ' ' or nvl(igroup_profit,' ') = ' '))
                        FROM ca_local_stl a, (select iclaim,dclose,itransno from newa00:ca_viewer_pay 
						                      union all
											  select iclaim,dclose,itransno from newa22:ca_viewer_pay
											  union all
											  select iclaim,dclose,itransno from newa33:ca_viewer_pay
											  union all
											  select iclaim,dclose,itransno from newa40:ca_viewer_pay
											  union all
											  select iclaim,dclose,itransno from newa66:ca_viewer_pay
											  union all
											  select iclaim,dclose,itransno from newa70:ca_viewer_pay											  
											 ) b
                       WHERE a.iclaim = b.iclaim
                         AND a.fchoose = '1'
                         AND (a.dclose IS NULL and b.dclose is null)
                         and b.itransno = $sItransno
                         AND userid = $userid
                       ORDER BY iclaim, ipolicy;
            EXEC SQL OPEN CA508_Da;
        }

        while (1)
        {
            if (strcmp(dclosing_type,"3") == 0)
            {
                EXEC SQL FETCH CA508_3a INTO :tmp_iclaim ,:tmp_ipolicy,
                                            :lDadjust, :tmp_iclose_type ,:tmp_fstl,
                                            :icnt_1;
            }
            else if (strcmp(dclosing_type,"A") == 0)
            {
                EXEC SQL FETCH CA508_Aa INTO :tmp_iclaim ,:tmp_ipolicy,
                                            :lDadjust, :tmp_iclose_type ,:tmp_fstl,
                                            :icnt_1;
            }
            else if (strcmp(dclosing_type,"B") == 0)
            {
                EXEC SQL FETCH CA508_Ba INTO :tmp_iclaim ,:tmp_ipolicy,
                                            :lDadjust, :tmp_iclose_type ,:tmp_fstl,
                                            :icnt_1;
            }
            else if (strcmp(dclosing_type,"T") == 0)
            {
                EXEC SQL FETCH CA508_Ta INTO :tmp_iclaim ,:tmp_ipolicy,
                                            :lDadjust, :tmp_iclose_type ,:tmp_fstl,
                                            :icnt_1;
            }
            else if ((strcmp(dclosing_type,"C") == 0) || (strcmp(dclosing_type,"F") == 0))
            {
                EXEC SQL FETCH CA508_Ca INTO :tmp_iclaim ,:tmp_ipolicy,
                                            :lDadjust, :tmp_iclose_type ,:tmp_fstl,
                                            :icnt_1;
            }
            else if (strcmp(dclosing_type,"D") == 0)
            {
                EXEC SQL FETCH CA508_Da INTO :tmp_iclaim ,:tmp_ipolicy,
                                            :lDadjust, :tmp_iclose_type ,:tmp_fstl,
                                            :icnt_1;
            }

            if (SQLCODE==SQLNOTFOUND) break;

            if (icnt_1 > 0)
            {
                icntT ++;
                memset(err_ifrs,0,sizeof(err_ifrs));
                sprintf(err_ifrs,"�߮סi%s�j���O�渹�i%s�j�d�L�զX�N�X(iportfolio)�ΦX���s�եN�X(igroup_profit)�A�Ь���ⳡ�]�w!\n",tmp_iclaim,tmp_ipolicy);
            }
            strcat(err_buf, err_ifrs);
        }

        printf("-- [ChkIFRS]:icnt_1=%d\n",icnt_1);
        if (strcmp(dclosing_type,"3") == 0)
        {
            $CLOSE CA508_3a;
            $FREE  CA508_3a;
        }
        else if (strcmp(dclosing_type,"A") == 0)
        {
            $CLOSE CA508_Aa;
            $FREE  CA508_Aa;
        }
        else if (strcmp(dclosing_type,"B") == 0)
        {
            $CLOSE CA508_Ba;
            $FREE  CA508_Ba;
        }
        else if (strcmp(dclosing_type,"T") == 0)
        {
            $CLOSE CA508_Ta;
            $FREE  CA508_Ta;
        }
        else if ((strcmp(dclosing_type,"C") == 0)|| (strcmp(dclosing_type,"F") == 0))
        {
            $CLOSE CA508_Ca;
            $FREE  CA508_Ca;
        }
        else if (strcmp(dclosing_type,"D") == 0)
        {
            $CLOSE CA508_Da;
            $FREE  CA508_Da;
        }
    }
    if (icnt_1 >0)
        return FALSE;

    return SUCCESS;

chkifrs_err:
    printf("sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    memset(err_buf,0,sizeof(err_buf));
    sprintf(err_buf,"sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
