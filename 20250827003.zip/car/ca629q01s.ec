/**********************************************************************/
/*                                                                    */
/*   program id   : ca629q01s.ec                                      */
/*   program name : �X��ɮı���                                      */
/*   date written : 2005/02/15                                        */
/*   date modify  : 2006/02/14                                        */
/*   author       : Neo Chen                                          */
/*   Checked for ����100�~�M��                                        */
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "safeclib.h"
/*--------------------------------------------------------------------*/
$char  t_data1[13], t_data2[13], option[2], fcard_class[3], t_type[2];
$char  rcpbgn[11], rcpend[11], dbegin[20], dend[20], tmp_dbegin[11], tmp_dend[11];
$char  dbegin_mm[3], dbegin_dd[3], dbegin_yy[5],dend_mm[3], dend_dd[3], dend_yy[5];
$char  ipolicy[21], icard[21], big_office12[3], big_office34[3];
$char  dapply[13], dpolicy[13], dply_begin[13], dply_end[13];
$int   dappdiff = 0,dplydiff = 0;
$char  iengine[CA_ENGINE_NUM], itag[CA_TAG_NUM], nname[20], sTmpDate[11];
$char  ipolicy12[3], nassured[61];
$char  iofficer[11], nofficer[11], ileader[11], nleader[11], nbranch[21];
$char  ientry[11], nentry[13], s_qday[3], dcreate[11];
$int   qday, count2, count3;
$char  imgr[2], iupcomp[3], seqno[3], nchi_abv[21], t_quota[11];
$char  iresource[2];

$char DBName[05], iForm_Tp[03];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[N_FILE+1];
$char userid[11],choice[2];

char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;

static int  max_cnt,num;

int   k,count_db;
DBinfo *list;

long car629_build();
void car629_title();
long car629_body();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;

   batchinit();
   $WHENEVER SQLERROR GOTO errexit;
   strcpy(DBName,  isNULLstr(argv[1]));
   strcpy(userid,  isNULLstr(argv[2]));
   strcpy(option,  isNULLstr(argv[3]));
   strcpy(t_data1, isNULLstr(argv[4]));
   strcpy(t_data2, isNULLstr(argv[5]));
   strcpy(fcard_class, isNULLstr(argv[6]));
   strcpy(s_qday,  isNULLstr(argv[7]));
   strcpy(t_type,  isNULLstr(argv[8]));		/* �������� 1:�������Ӫ� 2:�ζ����Ӫ� 3:�����έp�� 4:�������Ӫ�(���t�M�ץ�) 5:�����έp��(���t�M�ץ�)*/
   strcpy(t_quota,  isNULLstr(argv[9]));	/* �~�Z��� */
   strcpy(outputf, isNULLstr(argv[10]));

   /** t_data ���C�L��� or ���ʤ��  **/
   if( option[0] == '1' )
   {
   	strcpy(dbegin, cm_to_infdate(t_data1));
   	strcpy(dend,   cm_to_infdate(t_data2));
   }
   else
   {

   	strcpy(tmp_dbegin, cm_to_infdate(t_data1));
   	strcpy(tmp_dend,   cm_to_infdate(t_data2));

   	cm_split_ymd(tmp_dbegin, dbegin_mm, dbegin_dd, dbegin_yy);
   	cm_split_ymd(tmp_dend  , dend_mm, dend_dd, dend_yy);

   	strcat(dbegin,dbegin_yy);
   	strcat(dbegin,"-");
   	strcat(dbegin,dbegin_mm);
   	strcat(dbegin,"-");
   	strcat(dbegin,dbegin_dd);
   	strcat(dbegin," ");
   	strcat(dbegin,"00:00:00");

   	strcat(dend,dend_yy);
   	strcat(dend,"-");
   	strcat(dend,dend_mm);
   	strcat(dend,"-");
   	strcat(dend,dend_dd);
   	strcat(dend," ");
   	strcat(dend,"23:59:59");

   }

   qday = atoi(s_qday);
   strcpy(t_quota, trim(t_quota));
   strcat(t_quota,"*");
   printf("option [%s] t_data1[%s] t_data2[%s]\n",
           option,  t_data1, t_data2 );
   printf("dbegin [%s] dend [%s] \n", dbegin, dend );


   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   max_cnt=0;

   if((t_type[0] == '1')||(t_type[0] == '4'))
   {	/* 1:�������Ӫ�  4:�������Ӫ�(���t�M�ץ�) */
      rc = car629_build();

      if (rc != FAIL)
      {
          if ((rc=save_form_info(F_BLK0, "CA", 629, userid, iForm_Tp, max_cnt, outputf))<0) {
              strcpy(msgbuf,"save_form_info failed");
              return rc;
          }
      }
   }
   else if((t_type[0] == '3')||(t_type[0] == '5'))
   {
   		/* �����έp�� */
   		/* ��temp table : tmp_table1 */
			rc = car629_temp_table();
		  if (rc != M_CM_OK)
		  		return rc;

			rc = car629_build2();
      if (rc != M_CM_OK)
      {
					/* strcpy(msgbuf,"save_form_info failed"); */
					return rc;
      }
   }
   else if(t_type[0] == '6')
   {
   	/* ñ���ɮĲέp�� */
   	rc = car629_temp_table1();
		  if (rc != M_CM_OK)
		  return rc;

	rc = car629_build3();
      if (rc != M_CM_OK)
      {
					/* strcpy(msgbuf,"save_form_info failed"); */
					return rc;
      }
   }
   else
   {
   		/* �ζ����Ӫ� */
      rc = car629_build1();

      if (rc != FAIL)
      {
          if ((rc=save_form_info(F_BLK0, "CA", 629, userid, iForm_Tp, max_cnt, outputf))<0) {
              strcpy(msgbuf,"save_form_info failed");
              return rc;
          }
      }
   }

   return ;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;

}
/*--------------------------------------------------------------------*/

long car629_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc,rtncode;
   $char stmt[500];


   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth ,iform_tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width ,$iForm_Tp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 629 AND iform_tp = '1';

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
   sprintf_s(BodyFile, sizeof BodyFile,"%s.bd",outputf);

   printf("@@@@@@@@@@@@@@@@@@ titlefmt = [%s]",TitleFile);
   printf(" iForm_Tp [%s] \n",iForm_Tp);

   rgu_init_report(TitleFmt,TitleFile);
   car629_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);

   rtncode = car629_body();
   if( rtncode != M_CM_OK )
       return rtncode;

   rgu_finish_report();

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

void car629_title()
{
   rgu_put_head_string(1," ");
   rgu_put_head_string(1," ");
   rgu_put_head();
}


long car629_body()
{
  $char stmt[3024], stmt_buf1[1024], stmt_state[200];
  $char fulldbname[20], tmp_buf[14];
  int   ifstatus;
  $long iTmp, jTmp, dateBefore, iCount = 0;
  $char nprmt[5];

  max_cnt = 0;

  if( option[0] == '1' )
  {
     rgu_put_body_string(1,"������",1);
     rgu_put_body_string(1,dbegin,1);
     rgu_put_body_string(1,dend,1);
  }
  else
  {
     rgu_put_body_string(1,"��J���",1);
     rgu_put_body_string(1,tmp_dbegin,1);
     rgu_put_body_string(1,tmp_dend,1);
  }

  rgu_put_body_string(1, cm_get_sysd(),1);
  rgu_put_body(1);

  max_cnt += 6;
  $WHENEVER SQLERROR GOTO errexit;


  if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;

   }

  if( option[0] == '1' )
  {
      sprintf_s(stmt_buf1, sizeof stmt_buf1," AND dapply >= '%s' AND dapply <= '%s'",dbegin, dend );
  }
  else
  {
      sprintf_s(stmt_buf1, sizeof stmt_buf1," AND dcreate >= '%s' AND dcreate <= '%s'",dbegin, dend );
  }

  if( fcard_class[0] == '1' )
  {
      strcat(stmt_buf1," AND fcard_class = '1'" );
  }
  else if( fcard_class[0] == '2' )
  {
      strcat(stmt_buf1," AND fcard_class = '2'" );
  }

  if (t_type[0] == '4')
  {
			strcat(stmt_buf1," AND a.iofficer[1,1] != 'W' AND not (a.iofficer[1,1] = 'H' and a.iresource ='E') AND not (a.iofficer[1,1] = 'N' AND a.iresource ='E')" );
  }

  printf("stmt_buf1=[%s]\n",stmt_buf1);
  /* �]���Ӹ�k,�Q�O�I�H�W�ٶȨ��e�@�X add by sylvia 101.12.14 */
  /* �ʱo���z���X,���Ϥ��P�ɶ��I�]�X�Ӫ���Ƥ@�P,�אּŪ����l�O���ɸ�� modify by sylvia 102.01.08 */
  for(k=0;k<count_db;k++)
  {
  	  strcpy(stmt, "");
      sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy[1,2], a.ipolicy, b.nassured[1,2]||'�ݢ�', a.dply_begin, a.dply_end,  "
                    "      dapply, dpolicy, (date(dcreate) - dapply), (a.dpolicy - a.dply_begin),  "
                    "      a.iofficer,(select nname from officer where iofficer = a.iofficer), "
                    "      a.ileader, (select nname from officer where iofficer = a.ileader),  "
                    "      (select nchi_full from branch where ibranch = a.ipolicy[1,2]),  "
                    "      a.ientry, (select nname from officer where iofficer = a.ientry ),  "
                    "      date(dcreate),a.iresource  "
                    " FROM %s:ori_ply_relation a, %s:original_ply b  "
                    "WHERE a.ipolicy = b.ipolicy  "
                    "  and dpolicy is not null and dply_close is not null  "
                    "  and a.iquota matches '%s'  "
                    "  and a.fedr_class != '1' %s  "
                    "  and a.ipolicy[6,7] != 'VW'  "
                    " ORDER BY a.ipolicy[1,2], a.iofficer, a.dpolicy  "
                    "  ",list[k].dbname, list[k].dbname, t_quota, stmt_buf1 );

      printf("stmt=[%s]\n", stmt );
      $PREPARE p_dapp_stmt1 FROM $stmt;
      $DECLARE p_dapp_1 CURSOR for p_dapp_stmt1;
      $OPEN p_dapp_1;
      while(1)
      {
          $FETCH p_dapp_1 INTO $ipolicy12, $ipolicy, $nassured, $dply_begin, $dply_end,
                               $dapply, $dpolicy, $dappdiff, $dplydiff, $iofficer,
                               $nofficer, $ileader, $nleader, $nbranch, $ientry, $nentry, $dcreate, $iresource;

          if(SQLCODE == SQLNOTFOUND)
             break;

          if((strncmp(iofficer,"W",1) == 0) ||
      	     ((strncmp(iofficer,"H",1) == 0) && (strncmp(iresource,"E",1) == 0)) ||
      	     ((strncmp(iofficer,"N",1) == 0) && (strncmp(iresource,"E",1) == 0)))
          {
          	strcpy(nprmt,"�M�ץ�");
          }
          else
          {
          	strcpy(nprmt,"�D�M�ץ�");
          }


          printf("ipolicy = [%s] dapply=[%s] dpolicy=[%s] dappdiff = [%d] dplydiff = [%d]\n",
                  ipolicy, dapply, dpolicy, dappdiff,dplydiff );
          printf("*300*iofficer = [%s]\n",iofficer);
          /* ��X dcreate �e qday �u�@�� */
          jTmp = dateBefore = 0;
          for(iTmp=1;jTmp<=qday;iTmp++)
          {
              $select count(*)
                 into $iCount
                 from ca_holiday
                where (date($dcreate) - $iTmp) between holiday_bgn and holiday_end;
              if( iCount == 0) jTmp++;
              printf("iTmp[%d],jTmp[%d]\n", iTmp, jTmp);
              if( jTmp == qday && dateBefore == 0) {dateBefore = iTmp;break;}
          }
          $select first 1 * from ca_holiday
            where date($dcreate) - date($dapply) >= $dateBefore;
          printf("dateBefore[%d]\n", dateBefore);
          if( SQLCODE == SQLNOTFOUND) continue;

          /* ��Xdapply~dcreate���X�Ӱ��� */
          jTmp = jTmp = 0;
          for(iTmp=1;iTmp<=dappdiff;iTmp++)
          {
              $select count(*)
                 into $iCount
                 from ca_holiday
                where (date($dcreate) - $iTmp) between holiday_bgn and holiday_end;
              printf("iTmp[%d]\n", iTmp);
              if( iCount > 0) jTmp++;
          }
          dappdiff = dappdiff - jTmp;   /* �u�@�� = ����Ѽ� - ���� */

          strncpy( sTmpDate, dapply+6, 4);
          sTmpDate[4] = '/';
          sTmpDate[5] = dapply[0];
          sTmpDate[6] = dapply[1];
          sTmpDate[7] = '/';
          sTmpDate[8] = dapply[3];
          sTmpDate[9] = dapply[4];
          sTmpDate[10] = '\0';
          strcpy(dapply, sTmpDate );

          strncpy( sTmpDate, dpolicy+6, 4);
          sTmpDate[4] = '/';
          sTmpDate[5] = dpolicy[0];
          sTmpDate[6] = dpolicy[1];
          sTmpDate[7] = '/';
          sTmpDate[8] = dpolicy[3];
          sTmpDate[9] = dpolicy[4];
          sTmpDate[10] = '\0';
          strcpy(dpolicy, sTmpDate );

          strncpy( sTmpDate, dply_begin+6, 4);
          sTmpDate[4] = '/';
          sTmpDate[5] = dply_begin[0];
          sTmpDate[6] = dply_begin[1];
          sTmpDate[7] = '/';
          sTmpDate[8] = dply_begin[3];
          sTmpDate[9] = dply_begin[4];
          sTmpDate[10] = '\0';
          strcpy(dply_begin, sTmpDate );

          strncpy( sTmpDate, dply_end+6, 4);
          sTmpDate[4] = '/';
          sTmpDate[5] = dply_end[0];
          sTmpDate[6] = dply_end[1];
          sTmpDate[7] = '/';
          sTmpDate[8] = dply_end[3];
          sTmpDate[9] = dply_end[4];
          sTmpDate[10] = '\0';
          strcpy(dply_end, sTmpDate );

          rgu_put_body_string(2, trim(nbranch),  LEFT );
          rgu_put_body_string(2, ipolicy,        LEFT );
          rgu_put_body_string(2, trim(nassured), LEFT );
          rgu_put_body_string(2, trim(dply_begin), LEFT );
          rgu_put_body_string(2, trim(dply_end)  , LEFT );
          rgu_put_body_string(2, trim(dapply),   LEFT );
          rgu_put_body_string(2, trim(dpolicy),  LEFT );

          if( strlen(trim(dapply)) == 0 )
              rgu_put_body_string(2, " ", LEFT );
          else
              rgu_put_body_string(2, itoa(dappdiff), LEFT );


          rgu_put_body_string(2, itoa(dplydiff), LEFT );

          rgu_put_body_string(2, trim(dcreate),  LEFT );
          rgu_put_body_string(2, trim(iofficer),   LEFT );
          rgu_put_body_string(2, trim(nofficer),   LEFT );
          rgu_put_body_string(2, trim(ileader),    LEFT );
          rgu_put_body_string(2, trim(nleader),    LEFT );
          rgu_put_body_string(2, trim(ientry),     LEFT );
          rgu_put_body_string(2, trim(nentry),     LEFT );

          /*rgu_put_body_string(2, trim(nprmt),     LEFT );*/

          rgu_put_body(2);
          max_cnt++;

      }
      printf("get out of while loop \n");

      $CLOSE p_dapp_1;
  		$free p_dapp_1;
  		printf("stmt_buf1=[%s]\n",stmt_buf1);
      printf("after CLOSE p_dapp_1\n");
  }

  printf("end of car629_bidy \n");

  return M_CM_OK;


errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);
}

long car629_build1()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc,rtncode;
   $char stmt[500];

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
           kTot_Col, kPgNum_Line, kWidth ,iform_tp
      INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
           $TotColumn, $PgLine, $Width ,$iForm_Tp
      FROM Form
     WHERE ksys_grp="CA" AND kPgmID = 629 AND iform_tp = '2';

   strcpy( TitleFmt,rtrim(TitleFmt));
   strcpy( BodyFmt,rtrim(BodyFmt));
   sprintf_s(TitleFile, sizeof TitleFile,"%s.ti",outputf);
   sprintf_s(BodyFile, sizeof BodyFile,"%s.bd",outputf);

   printf("@@@@@@@@@@@@@@@@@@ titlefmt = [%s]",TitleFile);
   printf(" iForm_Tp [%s] \n",iForm_Tp);

   rgu_init_report(TitleFmt,TitleFile);
   car629_title();
   rgu_finish_report();

   rgu_init_report(BodyFmt,BodyFile);

   rtncode = car629_body1();
   if( rtncode != M_CM_OK )
       return rtncode;

   rgu_finish_report();

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car629_body1()
{
  $char stmt[3024], stmt_buf1[1024], stmt_state[200];
  $char fulldbname[20], tmp_buf[14];
  int   ifstatus;
  $long iTmp, jTmp, dateBefore, iCount;

  max_cnt = 0;

  if( option[0] == '1' )
  {
     rgu_put_body_string(1,"������",1);
     rgu_put_body_string(1,dbegin,1);
     rgu_put_body_string(1,dend,1);
  }
  else
  {
     rgu_put_body_string(1,"��J���",1);
     rgu_put_body_string(1,tmp_dbegin,1);
     rgu_put_body_string(1,tmp_dend,1);
  }

  rgu_put_body_string(1, cm_get_sysd(),1);
  rgu_put_body(1);

  max_cnt += 6;
  $WHENEVER SQLERROR GOTO errexit;

  if( option[0] == '1' )
  {
      sprintf_s(stmt_buf1, sizeof stmt_buf1," AND dapply >= '%s' AND dapply <= '%s'",dbegin, dend );
  }
  else
  {
      sprintf_s(stmt_buf1, sizeof stmt_buf1," AND dcreate >= '%s' AND dcreate <= '%s'",dbegin, dend );
  }

  if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;

   }
  /* �ʱo���z���X,���Ϥ��P�ɶ��I�]�X�Ӫ���Ƥ@�P,�אּŪ����l�O���ɸ�� modify by sylvia 102.01.08 */
  for(k=0;k<count_db;k++)
  {
      sprintf_s(stmt, sizeof stmt,"SELECT a.ipolicy, a.icard, ibig_office[1,2], ibig_office[3,4],  "
                    "      dapply, dpolicy, dply_begin, (date(dcreate) - dapply), iengine,  "
                    "      itag, ( select nname from ca_big_office where fclass = '2'  "
                    "      and ibig_comp = a.ibig_sales ),  "
                    "      date(dcreate)  "
                    " FROM %s:ori_ply_relation a, %s:original_ply b  "
                    "WHERE a.ipolicy = b.ipolicy and fcard_class = '2'  "
                    "  and a.iquota matches '%s'  "
                    "  and a.ipolicy[6,7] != 'VW'  "
                    "  and iofficer[1] = 'A' and dpolicy is not null and dply_close is not null  "
                    "  %s ",list[k].dbname, list[k].dbname, t_quota, stmt_buf1 );

      printf("stmt=[%s]\n", stmt );
      $PREPARE p_dapp_stmt2 FROM $stmt;
      $DECLARE p_dapp_2 CURSOR for p_dapp_stmt2;
      $OPEN p_dapp_2;
      while(1)
      {
          $FETCH p_dapp_2 INTO $ipolicy, $icard, $big_office12, $big_office34, $dapply, $dpolicy,
                               $dply_begin, $dappdiff, $iengine, $itag, $nname, $dcreate;
          if(SQLCODE == SQLNOTFOUND)
             break;

          /* ��X dcreate �e qday �u�@�� */
          jTmp = dateBefore = 0;
          for(iTmp=1;jTmp<=qday;iTmp++)
          {
              $select count(*)
                 into $iCount
                 from ca_holiday
                where (date($dcreate) - $iTmp) between holiday_bgn and holiday_end;
              if( iCount == 0) jTmp++;
              printf("iTmp[%d],jTmp[%d]\n", iTmp, jTmp);
              if( jTmp == qday && dateBefore == 0) {dateBefore = iTmp;break;}
          }
          $select first 1 * from ca_holiday
            where date($dcreate) - date($dapply) >= $dateBefore;
          printf("dateBefore[%d]\n", dateBefore);
          if( SQLCODE == SQLNOTFOUND) continue;

          /* ��Xdapply~dcreate���X�Ӱ��� */
          jTmp = jTmp = 0;
          for(iTmp=1;iTmp<=dappdiff;iTmp++)
          {
              $select count(*)
                 into $iCount
                 from ca_holiday
                where (date($dcreate) - $iTmp) between holiday_bgn and holiday_end;
              printf("iTmp[%d]\n", iTmp);
              if( iCount > 0) jTmp++;
          }
          dappdiff = dappdiff - jTmp;   /* �u�@�� = ����Ѽ� - ���� */

          strncpy( sTmpDate, dapply+6, 4);
          sTmpDate[4] = '/';
          sTmpDate[5] = dapply[0];
          sTmpDate[6] = dapply[1];
          sTmpDate[7] = '/';
          sTmpDate[8] = dapply[3];
          sTmpDate[9] = dapply[4];
          sTmpDate[10] = '\0';
          strcpy(dapply, sTmpDate );

          strncpy( sTmpDate, dpolicy+6, 4);
          sTmpDate[4] = '/';
          sTmpDate[5] = dpolicy[0];
          sTmpDate[6] = dpolicy[1];
          sTmpDate[7] = '/';
          sTmpDate[8] = dpolicy[3];
          sTmpDate[9] = dpolicy[4];
          sTmpDate[10] = '\0';
          strcpy(dpolicy, sTmpDate );

          strncpy( sTmpDate, dply_begin+6, 4);
          sTmpDate[4] = '/';
          sTmpDate[5] = dply_begin[0];
          sTmpDate[6] = dply_begin[1];
          sTmpDate[7] = '/';
          sTmpDate[8] = dply_begin[3];
          sTmpDate[9] = dply_begin[4];
          sTmpDate[10] = '\0';
          strcpy(dply_begin, sTmpDate );

          rgu_put_body_string(2, trim(big_office12), LEFT );
          rgu_put_body_string(2, trim(big_office34), LEFT );
          rgu_put_body_string(2, trim(nname),   LEFT );
          rgu_put_body_string(2, trim(iengine), LEFT );
          rgu_put_body_string(2, trim(itag),    LEFT );
          rgu_put_body_string(2, trim("�s�w"),  LEFT );

          rgu_put_body_string(2, trim(dapply),   LEFT );
          rgu_put_body_string(2, trim(icard),    LEFT );
          rgu_put_body_string(2, trim(dply_begin), LEFT );
          rgu_put_body_string(2, trim(dpolicy),  LEFT );

          if( strlen(trim(dapply)) == 0 )
              rgu_put_body_string(2, " ", LEFT );
          else
              rgu_put_body_string(2, itoa(dappdiff), LEFT );

          rgu_put_body_string(2, trim(dcreate),  LEFT );

          rgu_put_body_string(2, trim(ipolicy),  LEFT );


          rgu_put_body(2);
          max_cnt++;

      }

      $CLOSE p_dapp_2;
      $FREE p_dapp_2;
  }

  printf("end of car629_bidy \n");

  return M_CM_OK;


errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);
}

long car629_build2()
{
   int   rc,rtncode;
   char  sfilename[81],stitle[2024],stmt[2024];
   char  sTmp[30];
   char  sp1[2];


   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   rtncode = car629_body2();
   if( rtncode != M_CM_OK )
       return rtncode;

    strcpy(sfilename,"�X��y�{���޲έp��(����)[CAR629]");
    strcpy(stitle,"  \t�@�@�@�@�@\t�@�@�@�@�@\t �X��y�{���޲έp��(����)\t�@�@�@�@�@\t�@�@�@�@�@\t�@�@�@�@�@\t�@�@�@�@�@\t�@�@�@�@�@\t�@�@�@�@�@\t�@�@�@�@�@\n");

		if( option[0] == '1' )
		{

			strcat(stitle,"  \t\t\t\t ������:");
    	strcat(stitle,dbegin);
    	strcat(stitle,"��");
    	strcat(stitle,dend);
    	strcat(stitle,"\n");
		}
		else
		{
			strcat(stitle,"  \t\t\t\t ��J���:");
    	strcat(stitle,tmp_dbegin);
    	strcat(stitle,"��");
    	strcat(stitle,tmp_dend);
    	strcat(stitle,"\n\n");
		}

		strcat(stitle,"  \t\t �{���N��:CAR629\t\t\t\t\t\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n\n");
		strcat(stitle,"\t\t\t��J��ߩ�֫O�� (�O�G�u�@��)\t\t\t\t\t\t��J��ߩ�O�I�ͮĤ� (�O�@����(�t))\n");
    strcat(stitle,"\t���O\t��J���(1)\t�g�P�ӿ�J�`���(2)\t�g�P�ӹO����J���(3)\t");
    strcat(stitle,"�g�P�ӹO����J��v(%)(4)=(3)/(2)\t�D�g�P�ӿ�J�`���(5)\t");
    strcat(stitle,"�D�g�P�ӹO����J���(6)\t�D�g�P�ӹO����J��v(%)(7)=(6)/(5)\t");
    strcat(stitle,"�g�P�ӹO����J���(8)\t�g�P�ӹO����J��v(%)(9)=(8)/(2)\t");
    strcat(stitle,"�D�g�P�ӹO����J���(10)\t�D�g�P�ӹO����J��v(%)(11)=(10)/(5)\t");

    strcpy(stmt,"select nbranch, tcount, mgr1_tcount, mgr1_count2, ");
    strcat(stmt,"       mgr1_prate2||'%', mgr2_tcount, ");
    strcat(stmt,"       mgr2_count2, mgr2_prate2||'%', ");
    strcat(stmt,"       mgr1_count3, mgr1_prate3||'%', ");
    strcat(stmt,"       mgr2_count3, mgr2_prate3||'%' ");
		strcat(stmt,"       from tmp_table3  order by iupcomp, seqno, ipolicy12 ");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);
    printf("---- rc=[%d]---- \n",rc);
    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car629_build3()
{
   int   rc,rtncode;
   char  sfilename[81],stitle[2024],stmt[2024];
   char  sTmp[30];
   char  sp1[2];


   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   rtncode = car629_body3();
   if( rtncode != M_CM_OK )
       return rtncode;

    strcpy(sfilename,"�X��y�{���޲έp��(����)[CAR629]");
    strcpy(stitle,"  \t�@�@�@�@�@\t�@�@�@�@�@\t �X��y�{���޲έp��(����)\t�@�@�@�@�@\t�@�@�@�@�@\t�@�@�@�@�@\t�@�@�@�@�@\t�@�@�@�@�@\t�@�@�@�@�@\t�@�@�@�@�@\n");

		if( option[0] == '1' )
		{

			strcat(stitle,"  \t\t\t\t ������:");
    	strcat(stitle,dbegin);
    	strcat(stitle,"��");
    	strcat(stitle,dend);
    	strcat(stitle,"\n");
		}
		else
		{
			strcat(stitle,"  \t\t\t\t ��J���:");
    	strcat(stitle,tmp_dbegin);
    	strcat(stitle,"��");
    	strcat(stitle,tmp_dend);
    	strcat(stitle,"\n\n");
		}

		strcat(stitle,"  \t\t �{���N��:CAR629\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n\n");
		strcat(stitle,"\t\t\tñ���ߩ�ͮĤ� (�O�@����)\n");
    strcat(stitle,"\t���O\t��J���(1)\t�g�P�ӿ�J�`���(2)\t�g�P�ӹO����J���(3)\t");
    strcat(stitle,"�g�P�ӹO����J��v(%)(4)=(3)/(2)\t�D�g�P�ӿ�J�`���(5)\t");
    strcat(stitle,"�D�g�P�ӹO����J���(6)\t�D�g�P�ӹO����J��v(%)(7)=(6)/(5)\t");

    strcpy(stmt,"select nbranch, tcount, mgr1_tcount, mgr1_count2, ");
    strcat(stmt,"       mgr1_prate2||'%', mgr2_tcount, ");
    strcat(stmt,"       mgr2_count2, mgr2_prate2||'%'  ");
    strcat(stmt,"       from tmp_table7  order by iupcomp, seqno, ipolicy12 ");

    rc = unload_file(outputf,"A",sfilename,stitle,stmt);
    printf("---- rc=[%d]---- \n",rc);
    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    strcpy(sfilename,"�X��y�{���޲έp��(�M�ץ�)[CAR629]");
    strcpy(stitle,"  \t�@�@�@�@�@\t�@�@�@�@�@\t �X��y�{���޲έp��(�M�ץ�)\t\n");
    if( option[0] == '1' )
		{

			strcat(stitle,"  \t\t\t\t ������:");
    	strcat(stitle,dbegin);
    	strcat(stitle,"��");
    	strcat(stitle,dend);
    	strcat(stitle,"\n");
		}
		else
		{
			strcat(stitle,"  \t\t\t\t ��J���:");
    	strcat(stitle,tmp_dbegin);
    	strcat(stitle,"��");
    	strcat(stitle,tmp_dend);
    	strcat(stitle,"\n\n");
		}

		strcat(stitle,"  \t\t �{���N��:CAR629\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n\n");
		strcat(stitle,"\t\t\tñ���ߩ�ͮĤ� (�O�@����)\n");
    strcat(stitle,"\t���O\t��J���(1)\t�g�P�ӿ�J�`���(2)\t�g�P�ӹO����J���(3)\t");
    strcat(stitle,"�g�P�ӹO����J��v(%)(4)=(3)/(2)\t�D�g�P�ӿ�J�`���(5)\t");
    strcat(stitle,"�D�g�P�ӹO����J���(6)\t�D�g�P�ӹO����J��v(%)(7)=(6)/(5)\t");

    strcpy(stmt,"select nbranch, tcount, mgr1_tcount, mgr1_count2, ");
    strcat(stmt,"       mgr1_prate2||'%', mgr2_tcount, ");
    strcat(stmt,"       mgr2_count2, mgr2_prate2||'%'  ");
    strcat(stmt,"       from tmp_table8  order by iupcomp, seqno, ipolicy12 ");

    rc = unload_file(outputf,"B",sfilename,stitle,stmt);
    printf("---- rc=[%d]---- \n",rc);
    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    strcpy(sfilename,"�X��y�{���޲έp��(�D�M�ץ�)[CAR629]");
    strcpy(stitle,"  \t�@�@�@�@�@\t�@�@�@�@�@\t �X��y�{���޲έp��(�D�M�ץ�)\t\n");
    if( option[0] == '1' )
		{

			strcat(stitle,"  \t\t\t\t ������:");
    	strcat(stitle,dbegin);
    	strcat(stitle,"��");
    	strcat(stitle,dend);
    	strcat(stitle,"\n");
		}
		else
		{
			strcat(stitle,"  \t\t\t\t ��J���:");
    	strcat(stitle,tmp_dbegin);
    	strcat(stitle,"��");
    	strcat(stitle,tmp_dend);
    	strcat(stitle,"\n\n");
		}

		strcat(stitle,"  \t\t �{���N��:CAR629\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n\n");
		strcat(stitle,"\t\t\tñ���ߩ�ͮĤ� (�O�@����)\n");
    strcat(stitle,"\t���O\t��J���(1)\t�g�P�ӿ�J�`���(2)\t�g�P�ӹO����J���(3)\t");
    strcat(stitle,"�g�P�ӹO����J��v(%)(4)=(3)/(2)\t�D�g�P�ӿ�J�`���(5)\t");
    strcat(stitle,"�D�g�P�ӹO����J���(6)\t�D�g�P�ӹO����J��v(%)(7)=(6)/(5)\t");

    strcpy(stmt,"select nbranch, tcount, mgr1_tcount, mgr1_count2, ");
    strcat(stmt,"       mgr1_prate2||'%', mgr2_tcount, ");
    strcat(stmt,"       mgr2_count2, mgr2_prate2||'%'  ");
    strcat(stmt,"       from tmp_table9  order by iupcomp, seqno, ipolicy12 ");

    rc = unload_file(outputf,"C",sfilename,stitle,stmt);
    printf("---- rc=[%d]---- \n",rc);
    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car629_body2()
{
  $char stmt[3024], stmt_buf1[1024], stmt_state[200];
  $char fulldbname[20], tmp_buf[14];
  int   ifstatus;
  $long iTmp, jTmp, dateBefore, iCount;
    
  max_cnt = 0;

  $WHENEVER SQLERROR GOTO errexit;

  if( option[0] == '1' )
  {
      sprintf_s(stmt_buf1, sizeof stmt_buf1," AND dapply >= '%s' AND dapply <= '%s'",dbegin, dend );
  }
  else
  {
      sprintf_s(stmt_buf1, sizeof stmt_buf1," AND a.dcreate >= '%s' AND a.dcreate <= '%s'",dbegin, dend );
  }

  if( fcard_class[0] == '1' )
  {
      strcat(stmt_buf1," AND fcard_class = '1'" );
  }
  else if( fcard_class[0] == '2' )
  {
      strcat(stmt_buf1," AND fcard_class = '2'" );
  }

  if( t_type[0] == '5' )
  		strcat(stmt_buf1," AND a.iofficer[1,1] != 'W' AND not (a.iofficer[1,1] = 'H' and a.iofficer[2,2] not in ('0','1','2')) AND not (a.iofficer[1,1] = 'N' AND a.iresource ='E')" );

  if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }
  /* �ʱo���z���X,���Ϥ��P�ɶ��I�]�X�Ӫ���Ƥ@�P,�אּŪ����l�O���ɸ�� modify by sylvia 102.01.08 */
  for(k=0;k<count_db;k++)
  {
      sprintf_s(stmt, sizeof stmt,
      			"SELECT '1', a.ipolicy[1,2], a.ipolicy, b.nassured[1,2]||'�ݢ�', a.dply_begin, a.dply_end,  "
              "      dapply, dpolicy, (date(a.dcreate) - dapply), a.iofficer, c.nname,  "
              "      a.ileader, (select nname from officer where iofficer = a.ileader),  "
              "      (select nchi_full from branch where ibranch = a.ipolicy[1,2]),  "
              "      a.ientry, (select nname from officer where iofficer = a.ientry ),  "
              "      date(a.dcreate), c.imgr, (select iupcomp from branch where ibranch = a.ipolicy[1,2]),  "
              "      decode((select iupcomp from branch where ibranch = a.ipolicy[1,2]),  "
              "      '00', '�_�@��', '22', '�_�G��', '33', '��˭]��',  "
              "      '40', '�������', '66', '���ūn��', '����̰�'), 0,  "
              "      case when (date(a.dcreate) - a.dply_begin) >= 1 then 1 else 0 end  "
              " FROM %s:ori_ply_relation a, %s:original_ply b, officer c  "
              "WHERE a.ipolicy = b.ipolicy  "
              "  and a.iofficer = c.iofficer  "
              "  and dpolicy is not null and dply_close is not null  "
              "  and a.ipolicy[6,7] != 'VW'  "
              "  and a.fedr_class != '1' and a.iquota matches '%s' %s  "
              " ORDER BY a.ipolicy[1,2], a.iofficer, a.dpolicy  "
              "  ", list[k].dbname, list[k].dbname, t_quota, stmt_buf1 );

      printf("stmt=[%s]\n", stmt );
      $PREPARE p_opt3 FROM $stmt;
      $DECLARE p_cus3 CURSOR for p_opt3;
      $OPEN p_cus3;
      while(1)
      {
          $FETCH p_cus3 INTO $seqno, $ipolicy12, $ipolicy, $nassured, $dply_begin, $dply_end,
                             $dapply, $dpolicy, $dappdiff, $iofficer, $nofficer,
                             $ileader, $nleader, $nbranch,
                             $ientry, $nentry,
                             $dcreate, $imgr,
                             $iupcomp, $nchi_abv, $count2, $count3;
          if(SQLCODE == SQLNOTFOUND)
             break;

          printf("ipolicy = [%s] dapply=[%s] dpolicy=[%s] dappdiff = [%d]\n",
                  ipolicy, dapply, dpolicy, dappdiff );

          /* ��X dcreate �e qday �u�@�� */
          jTmp = dateBefore = 0;
          for(iTmp=1;jTmp<=qday;iTmp++)
          {
              $select count(*)
                 into $iCount
                 from ca_holiday
                where (date($dcreate) - $iTmp) between holiday_bgn and holiday_end;
              if( iCount == 0) jTmp++;
              printf("iTmp[%d],jTmp[%d]\n", iTmp, jTmp);
              if( jTmp == qday && dateBefore == 0) {dateBefore = iTmp;break;}
          }
          $select first 1 * from ca_holiday
            where date($dcreate) - date($dapply) >= $dateBefore;
          printf("dateBefore[%d]\n", dateBefore);
          if( SQLCODE == SQLNOTFOUND) continue;

          /* ��Xdapply~dcreate���X�Ӱ��� */
          jTmp = jTmp = 0;
          for(iTmp=1;iTmp<=dappdiff;iTmp++)
          {
              $select count(*)
                 into $iCount
                 from ca_holiday
                where (date($dcreate) - $iTmp) between holiday_bgn and holiday_end;
              printf("iTmp[%d]\n", iTmp);
              if( iCount > 0)
              		jTmp++;
          }
          dappdiff = dappdiff - jTmp;   /* �u�@�� = ����Ѽ� - ���� */
				  if (dappdiff > 2)
				  	 count2 = 1;
				  else
				  	 count2 = 0;
					printf("seqno=[%s], ipolicy12=[%s], ipolicy=[%s]\n",seqno,ipolicy12,ipolicy);
					printf("nassured=[%s], dply_begin=[%s], dply_end=[%s]\n",nassured,dply_begin,dply_end);
					printf("dapply=[%s], dpolicy=[%s], dappdiff=[%d]\n",dapply,dpolicy,dappdiff);
					printf("iofficer=[%s], nofficer=[%s], ileader=[%s]\n",iofficer,nofficer,ileader);
					printf("nleader=[%s], nbranch=[%s], ientry=[%s]\n",nleader,nbranch,ientry);
					printf("nentry=[%s], dcreate=[%s], imgr=[%s], iupcomp=[%s]\n",nentry,dcreate,imgr,iupcomp);
					printf("nchi_abv=[%s], count2=[%d], count3[%d]\n",nchi_abv,count2,count3);

          $insert into tmp_table1
          	(seqno, ipolicy12, ipolicy, nassured, dply_begin, dply_end,
          	 dapply, dpolicy,dappdiff, iofficer, nofficer, ileader,
          	 nleader, nbranch, ientry, nentry, dcreate, imgr, iupcomp,
          	 nchi_abv, count2, count3)
          values
           ($seqno, $ipolicy12, $ipolicy, $nassured, $dply_begin, $dply_end,
            $dapply, $dpolicy, $dappdiff, $iofficer, $nofficer, $ileader,
            $nleader, $nbranch, $ientry, $nentry, $dcreate, $imgr, $iupcomp,
            $nchi_abv, $count2, $count3);
      }
      $CLOSE p_cus3;
      $FREE p_cus3;
  }

      /* �v�O��p��O����� */
		$insert into tmp_table2
			select seqno, iupcomp, nchi_abv, ipolicy12, nbranch, ipolicy,
						 case when imgr = "1" then 1 else 0 end,
						 case when imgr = "2" then 1 else 0 end,
						 case when imgr = "1" then count2 else 0 end,
						 case when imgr = "2" then count2 else 0 end,
						 case when imgr = "1" then count3 else 0 end,
						 case when imgr = "2" then count3 else 0 end
        from tmp_table1;

    /* �έp�U����ƤΤ�v */
    /* �]�������H0�����D, �אּ�P�_���ӤΫD���ӥ�ƬO�_��0 */
    /* $insert into tmp_table3
    	select seqno, iupcomp, nchi_abv, ipolicy12, nbranch, count(ipolicy),
     				 sum(mgr1_tcount), sum(mgr2_tcount), sum(mgr1_count2),
     				 case when count(ipolicy) = 0 then 0 else (round((sum(mgr1_count2)/sum(mgr1_tcount))*100,2)) end,
     				 sum(mgr2_count2),
     				 case when count(ipolicy) = 0 then 0 else (round((sum(mgr2_count2)/sum(mgr2_tcount))*100,2)) end,
     				 sum(mgr1_count3),
     				 case when count(ipolicy) = 0 then 0 else (round((sum(mgr1_count3)/sum(mgr1_tcount))*100,2)) end,
      			 sum(mgr2_count3),
      			 case when count(ipolicy) = 0 then 0 else (round((sum(mgr2_count3)/sum(mgr2_tcount))*100,2)) end
		 from tmp_table2
		group by 1,2,3,4,5;  */
		$insert into tmp_table3
    	select seqno, iupcomp, nchi_abv, ipolicy12, nbranch, count(ipolicy),
     				 sum(mgr1_tcount), sum(mgr2_tcount), sum(mgr1_count2),
     				 case when sum(mgr1_tcount) = 0 then 0 else (round((sum(mgr1_count2)/sum(mgr1_tcount))*100,2)) end,
     				 sum(mgr2_count2),
     				 case when sum(mgr2_tcount) = 0 then 0 else (round((sum(mgr2_count2)/sum(mgr2_tcount))*100,2)) end,
     				 sum(mgr1_count3),
     				 case when sum(mgr1_tcount) = 0 then 0 else (round((sum(mgr1_count3)/sum(mgr1_tcount))*100,2)) end,
      			 sum(mgr2_count3),
      			 case when sum(mgr2_tcount) = 0 then 0 else (round((sum(mgr2_count3)/sum(mgr2_tcount))*100,2)) end
		 from tmp_table2
		group by 1,2,3,4,5;
		/* �[�`�U�����q��ƤΤ�v */
		$insert into tmp_table3
    	select '2', iupcomp, nchi_abv, ' ', trim(nchi_abv)||'�X�p', sum(tcount),
     				 sum(mgr1_tcount), sum(mgr2_tcount), sum(mgr1_count2),
     				 case when sum(mgr1_tcount) = 0 then 0 else (round((sum(mgr1_count2)/sum(mgr1_tcount))*100,2)) end,
     				 sum(mgr2_count2),
     				 case when sum(mgr2_tcount) = 0 then 0 else (round((sum(mgr2_count2)/sum(mgr2_tcount))*100,2)) end,
     				 sum(mgr1_count3),
     				 case when sum(mgr1_tcount) = 0 then 0 else (round((sum(mgr1_count3)/sum(mgr1_tcount))*100,2)) end,
      			 sum(mgr2_count3),
      			 case when sum(mgr2_tcount) = 0 then 0 else (round((sum(mgr2_count3)/sum(mgr2_tcount))*100,2)) end
		 from tmp_table3
		where seqno = '1'
		group by 1,2,3,4,5;

		/* �[�`�������q��ƤΤ�v */
		$insert into tmp_table3
    	select '3', '99', ' ', ' ', '�`�p', sum(tcount),
     				 sum(mgr1_tcount), sum(mgr2_tcount), sum(mgr1_count2),
     				 case when sum(mgr1_tcount) = 0 then 0 else (round((sum(mgr1_count2)/sum(mgr1_tcount))*100,2)) end,
     				 sum(mgr2_count2),
     				 case when sum(mgr2_tcount) = 0 then 0 else (round((sum(mgr2_count2)/sum(mgr2_tcount))*100,2)) end,
     				 sum(mgr1_count3),
     				 case when sum(mgr1_tcount) = 0 then 0 else (round((sum(mgr1_count3)/sum(mgr1_tcount))*100,2)) end,
      			 sum(mgr2_count3),
      			 case when sum(mgr2_tcount) = 0 then 0 else (round((sum(mgr2_count3)/sum(mgr2_tcount))*100,2)) end
		 from tmp_table3
		where seqno = '2'
		group by 1,2,3,4,5;

  printf("end of car629_bidy2 \n");

  return M_CM_OK;


errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);
}

long car629_body3()
{
  $char stmt[3024], stmt_buf1[1024], stmt_state[200];
  $char fulldbname[20], tmp_buf[14];
  int   ifstatus;
  $long iTmp, jTmp, dateBefore, iCount;

  max_cnt = 0;

  $WHENEVER SQLERROR GOTO errexit;

  if( option[0] == '1' )
  {
      sprintf_s(stmt_buf1, sizeof stmt_buf1," AND dapply >= '%s' AND dapply <= '%s'",dbegin, dend );
  }
  else
  {
      sprintf_s(stmt_buf1, sizeof stmt_buf1," AND a.dcreate >= '%s' AND a.dcreate <= '%s'",dbegin, dend );
  }

  if( fcard_class[0] == '1' )
  {
      strcat(stmt_buf1," AND fcard_class = '1'" );
  }
  else if( fcard_class[0] == '2' )
  {
      strcat(stmt_buf1," AND fcard_class = '2'" );
  }

  if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }
  /*** ñ���ɮĲέp��(����) ***/
  for(k=0;k<count_db;k++)
  {
      sprintf_s(stmt, sizeof stmt,
      			"SELECT '1', a.ipolicy[1,2], a.ipolicy, b.nassured[1,2]||'�ݢ�', a.dply_begin, a.dply_end,  "
              "      dapply, a.iofficer, c.nname,  "
              "      a.ileader, (select nname from officer where iofficer = a.ileader),  "
              "      (select nchi_full from branch where ibranch = a.ipolicy[1,2]),  "
              "      a.ientry, (select nname from officer where iofficer = a.ientry ),  "
              "      date(a.dcreate), c.imgr, (select iupcomp from branch where ibranch = a.ipolicy[1,2]),  "
              "      decode((select iupcomp from branch where ibranch = a.ipolicy[1,2]),  "
              "      '00', '�_�@��', '22', '�_�G��', '33', '��˭]��',  "
              "      '40', '�������', '66', '���ūn��', '����̰�'),  "
              "      case when (a.dpolicy - a.dply_begin) >= 1 then 1 else 0 end,a.iresource  "
              " FROM %s:ori_ply_relation a, %s:original_ply b, officer c  "
              "WHERE a.ipolicy = b.ipolicy  "
              "  and a.iofficer = c.iofficer  "
              "  and dpolicy is not null and dply_close is not null  "
              "  and a.ipolicy[6,7] != 'VW'  "
              "  and a.fedr_class != '1' and a.iquota matches '%s' %s  "
              " ORDER BY a.ipolicy[1,2], a.iofficer, a.dpolicy  "
              "  ", list[k].dbname, list[k].dbname, t_quota, stmt_buf1 );

      printf("stmt=[%s]\n", stmt );
      $PREPARE p_opt4 FROM $stmt;
      $DECLARE p_cus4 CURSOR for p_opt4;
      $OPEN p_cus4;
      while(1)
      {
          $FETCH p_cus4 INTO $seqno, $ipolicy12, $ipolicy, $nassured, $dply_begin, $dply_end,
                             $dapply, $iofficer, $nofficer,
                             $ileader, $nleader, $nbranch,
                             $ientry, $nentry,
                             $dcreate, $imgr,
                             $iupcomp, $nchi_abv, $count2,$iresource;
          if(SQLCODE == SQLNOTFOUND)
             break;
             
          /* ��X dcreate �e qday �u�@�� */
          jTmp = dateBefore = 0;
          for(iTmp=1;jTmp<=qday;iTmp++)
          {
              $select count(*)
                 into $iCount
                 from ca_holiday
                where (date($dcreate) - $iTmp) between holiday_bgn and holiday_end;
              if( iCount == 0) jTmp++;
              printf("iTmp[%d],jTmp[%d]\n", iTmp, jTmp);
              if( jTmp == qday && dateBefore == 0) {dateBefore = iTmp;break;}
          }
          $select first 1 * from ca_holiday
            where date($dcreate) - date($dapply) >= $dateBefore;
          printf("dateBefore[%d]\n", dateBefore);
          if( SQLCODE == SQLNOTFOUND) continue;

          /* ��Xdapply~dcreate���X�Ӱ��� */
          jTmp = jTmp = 0;
          for(iTmp=1;iTmp<=dappdiff;iTmp++)
          {
              $select count(*)
                 into $iCount
                 from ca_holiday
                where (date($dcreate) - $iTmp) between holiday_bgn and holiday_end;
              printf("iTmp[%d]\n", iTmp);
              if( iCount > 0)
              		jTmp++;
          }

          /*printf("ipolicy = [%s] dapply=[%s] dpolicy=[%s] dappdiff = [%d]\n",
                  ipolicy, dapply, dpolicy, dappdiff );*/

          $insert into tmp_table4
          	(seqno, ipolicy12, ipolicy, nassured, dply_begin, dply_end,
          	 dapply, dappdiff, iofficer, nofficer, ileader,nleader, nbranch, ientry,
          	 nentry, dcreate, imgr, iupcomp,nchi_abv, count2,iresource)
          values
           ($seqno, $ipolicy12, $ipolicy, $nassured, $dply_begin, $dply_end,
            $dapply, $dappdiff, $iofficer, $nofficer, $ileader,$nleader, $nbranch, $ientry,
            $nentry, $dcreate, $imgr, $iupcomp,$nchi_abv, $count2,$iresource);
      }
      $CLOSE p_cus4;
      $FREE p_cus4;
  }
             
      /*** ñ���ɮĲέp��(����) ***/
      $insert into tmp_table5
      	      select seqno,ipolicy12,ipolicy,nassured,dply_begin,dply_end,
		     iofficer,nofficer,ileader,nleader,nbranch,ientry,
		     nentry,imgr,iupcomp,nchi_abv,count2
	 	from tmp_table4;

	 	/* �v�O��p��O����� */
		$insert into tmp_table6
			select seqno, iupcomp, nchi_abv, ipolicy12, nbranch, ipolicy,
						 case when imgr = "1" then 1 else 0 end,
						 case when imgr = "2" then 1 else 0 end,
						 case when imgr = "1" then count2 else 0 end,
						 case when imgr = "2" then count2 else 0 end
        from tmp_table5;

		$insert into tmp_table7
    	select seqno, iupcomp, nchi_abv, ipolicy12, nbranch, count(ipolicy),
     				 sum(mgr1_tcount), sum(mgr2_tcount), sum(mgr1_count2),
     				 case when sum(mgr1_tcount) = 0 then 0 else (round((sum(mgr1_count2)/sum(mgr1_tcount))*100,2)) end,
     				 sum(mgr2_count2),
     				 case when sum(mgr2_tcount) = 0 then 0 else (round((sum(mgr2_count2)/sum(mgr2_tcount))*100,2)) end
		 from tmp_table6
		group by 1,2,3,4,5;
		/* �[�`�U�����q��ƤΤ�v */
		$insert into tmp_table7
    	select '2', iupcomp, nchi_abv, ' ', trim(nchi_abv)||'�X�p', sum(tcount),
     				 sum(mgr1_tcount), sum(mgr2_tcount), sum(mgr1_count2),
     				 case when sum(mgr1_tcount) = 0 then 0 else (round((sum(mgr1_count2)/sum(mgr1_tcount))*100,2)) end,
     				 sum(mgr2_count2),
     				 case when sum(mgr2_tcount) = 0 then 0 else (round((sum(mgr2_count2)/sum(mgr2_tcount))*100,2)) end
		 from tmp_table7
		where seqno = '1'
		group by 1,2,3,4,5;

		/* �[�`�������q��ƤΤ�v */
		$insert into tmp_table7
    	select '3', '99', ' ', ' ', '�`�p', sum(tcount),
     				 sum(mgr1_tcount), sum(mgr2_tcount), sum(mgr1_count2),
     				 case when sum(mgr1_tcount) = 0 then 0 else (round((sum(mgr1_count2)/sum(mgr1_tcount))*100,2)) end,
     				 sum(mgr2_count2),
     				 case when sum(mgr2_tcount) = 0 then 0 else (round((sum(mgr2_count2)/sum(mgr2_tcount))*100,2)) end
		 from tmp_table7
		where seqno = '2'
		group by 1,2,3,4,5;

	$delete from tmp_table5 where 1=1;
	$delete from tmp_table6 where 1=1;

	/*** ñ���ɮĲέp��(�M�ץ�) ***/
	$insert into tmp_table5
      	      select seqno,ipolicy12,ipolicy,nassured,dply_begin,dply_end,
		     iofficer,nofficer,ileader,nleader,nbranch,ientry,
		     nentry,imgr,iupcomp,nchi_abv,count2
	 	from tmp_table4
	       where (iofficer[1,1] = 'W' or (iofficer[1,1] = 'H' and iresource = 'E') or (iofficer[1,1] = 'N' and iresource = 'E' ));

      /* �v�O��p��O����� */
		$insert into tmp_table6
			select seqno, iupcomp, nchi_abv, ipolicy12, nbranch, ipolicy,
						 case when imgr = "1" then 1 else 0 end,
						 case when imgr = "2" then 1 else 0 end,
						 case when imgr = "1" then count2 else 0 end,
						 case when imgr = "2" then count2 else 0 end
        from tmp_table5;

		$insert into tmp_table8
    	select seqno, iupcomp, nchi_abv, ipolicy12, nbranch, count(ipolicy),
     				 sum(mgr1_tcount), sum(mgr2_tcount), sum(mgr1_count2),
     				 case when sum(mgr1_tcount) = 0 then 0 else (round((sum(mgr1_count2)/sum(mgr1_tcount))*100,2)) end,
     				 sum(mgr2_count2),
     				 case when sum(mgr2_tcount) = 0 then 0 else (round((sum(mgr2_count2)/sum(mgr2_tcount))*100,2)) end
		 from tmp_table6
		group by 1,2,3,4,5;
		/* �[�`�U�����q��ƤΤ�v */
		$insert into tmp_table8
    	select '2', iupcomp, nchi_abv, ' ', trim(nchi_abv)||'�X�p', sum(tcount),
     				 sum(mgr1_tcount), sum(mgr2_tcount), sum(mgr1_count2),
     				 case when sum(mgr1_tcount) = 0 then 0 else (round((sum(mgr1_count2)/sum(mgr1_tcount))*100,2)) end,
     				 sum(mgr2_count2),
     				 case when sum(mgr2_tcount) = 0 then 0 else (round((sum(mgr2_count2)/sum(mgr2_tcount))*100,2)) end
		 from tmp_table8
		where seqno = '1'
		group by 1,2,3,4,5;

		/* �[�`�������q��ƤΤ�v */
		$insert into tmp_table8
    	select '3', '99', ' ', ' ', '�`�p', sum(tcount),
     				 sum(mgr1_tcount), sum(mgr2_tcount), sum(mgr1_count2),
     				 case when sum(mgr1_tcount) = 0 then 0 else (round((sum(mgr1_count2)/sum(mgr1_tcount))*100,2)) end,
     				 sum(mgr2_count2),
     				 case when sum(mgr2_tcount) = 0 then 0 else (round((sum(mgr2_count2)/sum(mgr2_tcount))*100,2)) end
		 from tmp_table8
		where seqno = '2'
		group by 1,2,3,4,5;

		$delete from tmp_table5 where 1=1;
		$delete from tmp_table6 where 1=1;
		
	/*** ñ���ɮĲέp��(�D�M�ץ�) ***/
	$insert into tmp_table5
      	      select seqno,ipolicy12,ipolicy,nassured,dply_begin,dply_end,
		     iofficer,nofficer,ileader,nleader,nbranch,ientry,
		     nentry,imgr,iupcomp,nchi_abv,count2
	 	from tmp_table4
	       where iofficer[1,1] != 'W'
                 and not (iofficer[1,1] = 'H' and iresource ='E')
                 and not (iofficer[1,1] = 'N' and iresource ='E');

      /* �v�O��p��O����� */
		$insert into tmp_table6
			select seqno, iupcomp, nchi_abv, ipolicy12, nbranch, ipolicy,
						 case when imgr = "1" then 1 else 0 end,
						 case when imgr = "2" then 1 else 0 end,
						 case when imgr = "1" then count2 else 0 end,
						 case when imgr = "2" then count2 else 0 end
        from tmp_table5;

		$insert into tmp_table9
    	select seqno, iupcomp, nchi_abv, ipolicy12, nbranch, count(ipolicy),
     				 sum(mgr1_tcount), sum(mgr2_tcount), sum(mgr1_count2),
     				 case when sum(mgr1_tcount) = 0 then 0 else (round((sum(mgr1_count2)/sum(mgr1_tcount))*100,2)) end,
     				 sum(mgr2_count2),
     				 case when sum(mgr2_tcount) = 0 then 0 else (round((sum(mgr2_count2)/sum(mgr2_tcount))*100,2)) end
		 from tmp_table6
		group by 1,2,3,4,5;
		/* �[�`�U�����q��ƤΤ�v */
		$insert into tmp_table9
    	select '2', iupcomp, nchi_abv, ' ', trim(nchi_abv)||'�X�p', sum(tcount),
     				 sum(mgr1_tcount), sum(mgr2_tcount), sum(mgr1_count2),
     				 case when sum(mgr1_tcount) = 0 then 0 else (round((sum(mgr1_count2)/sum(mgr1_tcount))*100,2)) end,
     				 sum(mgr2_count2),
     				 case when sum(mgr2_tcount) = 0 then 0 else (round((sum(mgr2_count2)/sum(mgr2_tcount))*100,2)) end
		 from tmp_table9
		where seqno = '1'
		group by 1,2,3,4,5;

		/* �[�`�������q��ƤΤ�v */
		$insert into tmp_table9
    	select '3', '99', ' ', ' ', '�`�p', sum(tcount),
     				 sum(mgr1_tcount), sum(mgr2_tcount), sum(mgr1_count2),
     				 case when sum(mgr1_tcount) = 0 then 0 else (round((sum(mgr1_count2)/sum(mgr1_tcount))*100,2)) end,
     				 sum(mgr2_count2),
     				 case when sum(mgr2_tcount) = 0 then 0 else (round((sum(mgr2_count2)/sum(mgr2_tcount))*100,2)) end
		 from tmp_table9
		where seqno = '2'
		group by 1,2,3,4,5;

printf("end of car629_body3 \n");

  return M_CM_OK;


errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   exit(FAIL);
}

long car629_temp_table()
{
		$whenever sqlerror goto errexit;

		$create temp table tmp_table1
		(
				seqno				char(2), 							-- �Ǹ�
				ipolicy12		char(2), 							-- �O�渹�e2�X
				ipolicy			char(20), 						-- �O�渹
				nassured		char(60), 						-- �Q�O�I�H
        dply_begin	char(10), 						-- �_�O��
        dply_end		char(10), 						-- ���O��
				dapply			char(10),							-- �֫O��
				dpolicy			char(10), 						-- ñ���
        dappdiff		int, 									-- �X��Ѽ�
				iofficer		char(10), 						-- �g��N��
				nofficer		char(10),							-- �g��W��
				ileader			char(10),							-- �޲z�H
				nleader			char(10),							-- �޲z�H�W��
        nbranch			char(20),							-- ���W��
				ientry			char(10),							-- ��J�H���N��
        nentry			char(12),							-- ��J�H���W��
        dcreate			char(10),							-- ��J��
        imgr				char(1),							-- ���ӧO(1:���� 2:�D����)
        iupcomp			char(2),							-- ���ݤ����q�O
        nchi_abv		char(20),							-- ���ݤ����q²��
        count2			int,									-- ñ���-�֫O�� > 3��(�u�@��) ��1��,���M��0
        count3 			int										-- ��J��-�ͮĤ� >= 1��(����) ��1��,���M��0
       ) with no log;

   $create temp table tmp_table2
   (
   		seqno				char(2), 							-- �Ǹ�
			iupcomp			char(2),							-- ���ݤ����q�O
			nchi_abv		char(20),							-- ���ݤ����q²��
			ipolicy12		char(2), 							-- �O�渹�e2�X
   		nbranch			char(20),							-- ���W��
   		ipolicy			char(20), 						-- �O�渹
   		mgr1_tcount	int,									-- ���ӥ�
   		mgr2_tcount	int,									-- �D���ӥ�
      mgr1_count2	int,									-- ���� ñ��ߩ�֫O���
      mgr2_count2	int,									-- �D���� ñ��ߩ�֫O���
      mgr1_count3	int,									-- ���� ��J��ߩ�ͮĤ���
      mgr2_count3	int										-- �D���� ��J��ߩ�ͮĤ���
		) with no log;

		$create temp table tmp_table3
		(
				seqno				char(2), 							-- �Ǹ�
				iupcomp			char(2),							-- ���ݤ����q�O
				nchi_abv		char(20),							-- ���ݤ����q²��
				ipolicy12		char(2), 							-- �O�渹�e2�X
   			nbranch			char(20),							-- ���W��
   			tcount			int, 									-- ����`���(1)
   			mgr1_tcount	int, 									-- �����`���(2)
   			mgr2_tcount	int, 									-- �D�����`���(5)
       	mgr1_count2	int,									-- ���� ñ��ߩ�֫O���(3)
        mgr1_prate2	decimal(6,2),					-- ���� ñ��ߩ�֫O��v(4) (3)/(2)
       	mgr2_count2	int,									-- �D���� ñ��ߩ�֫O���(6)
				mgr2_prate2 decimal(6,2),					-- �D���� ñ��ߩ�֫O��v(7) (6)/(5)
       	mgr1_count3	int,									-- ���� ��J��ߩ�ͮĤ���(8)
       	mgr1_prate3	decimal(6,2),					-- ���� ��J��ߩ�ͮĤ��v(9) (8)/(2)
       	mgr2_count3	int,									-- �D���� ��J��ߩ�ͮĤ���(10)
       	mgr2_prate3	decimal(6,2)					-- �D���� ��J��ߩ�ͮĤ��v(11) (10)/(5)
  	) with no log;

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car629_temp_table1()
{
		$whenever sqlerror goto errexit;

		$create temp table tmp_table4
		(
		seqno			char(2), 	-- �Ǹ�
		ipolicy12		char(2), 	-- �O�渹�e2�X
		ipolicy			char(20), 	-- �O�渹
		nassured		char(60), 	-- �Q�O�I�H
        	dply_begin		char(10), 	-- �_�O��
        	dply_end		char(10), 	-- ���O��
        	dapply			char(10),	-- �֫O��
        	dappdiff		int, 		-- �X��Ѽ�
		iofficer		char(10), 	-- �g��N��
		nofficer		char(10),	-- �g��W��
		ileader			char(10),	-- �޲z�H
		nleader			char(10),	-- �޲z�H�W��
        	nbranch			char(20),	-- ���W��
		ientry			char(10),	-- ��J�H���N��
        	nentry			char(12),	-- ��J�H���W��
        	dcreate			char(10),	-- ��J��
	        imgr			char(1),	-- ���ӧO(1:���� 2:�D����)
        	iupcomp			char(2),	-- ���ݤ����q�O
        	nchi_abv		char(20),	-- ���ݤ����q²��
        	count2 			int,		-- ñ���-�ͮĤ� >= 1��(����) ��1��,���M��0
        	iresource		char(1)		-- �~�Ȩӷ�
       ) with no log;

       		$create temp table tmp_table5
		(
		seqno			char(2), 	-- �Ǹ�
		ipolicy12		char(2), 	-- �O�渹�e2�X
		ipolicy			char(20), 	-- �O�渹
		nassured		char(60), 	-- �Q�O�I�H
        	dply_begin		char(10), 	-- �_�O��
        	dply_end		char(10), 	-- ���O��
		iofficer		char(10), 	-- �g��N��
		nofficer		char(10),	-- �g��W��
		ileader			char(10),	-- �޲z�H
		nleader			char(10),	-- �޲z�H�W��
        	nbranch			char(20),	-- ���W��
		ientry			char(10),	-- ��J�H���N��
        	nentry			char(12),	-- ��J�H���W��
	        imgr			char(1),	-- ���ӧO(1:���� 2:�D����)
        	iupcomp			char(2),	-- ���ݤ����q�O
        	nchi_abv		char(20),	-- ���ݤ����q²��
        	count2 			int		-- ñ���-�ͮĤ� >= 1��(����) ��1��,���M��0
       ) with no log;

   $create temp table tmp_table6
   (
   	seqno			char(2), 		-- �Ǹ�
	iupcomp			char(2),		-- ���ݤ����q�O
	nchi_abv		char(20),		-- ���ݤ����q²��
	ipolicy12		char(2), 		-- �O�渹�e2�X
   	nbranch			char(20),		-- ���W��
   	ipolicy			char(20), 		-- �O�渹
   	mgr1_tcount		int,			-- ���ӥ�
   	mgr2_tcount		int,			-- �D���ӥ�
        mgr1_count2		int,			-- ���� ñ��ߩ�ͮĤ���
        mgr2_count2		int			-- �D���� ñ��ߩ�ͮĤ���										-- �D���� ��J��ߩ�ͮĤ���
   ) with no log;

		$create temp table tmp_table7
		(
		seqno			char(2), 	-- �Ǹ�
		iupcomp			char(2),	-- ���ݤ����q�O
		nchi_abv		char(20),	-- ���ݤ����q²��
		ipolicy12		char(2), 	-- �O�渹�e2�X
   		nbranch			char(20),	-- ���W��
   		tcount			int, 		-- ����`���(1)
   		mgr1_tcount		int, 		-- �����`���(2)
  		mgr2_tcount		int, 		-- �D�����`���(5)
      		mgr1_count2		int,		-- ���� ñ��ߩ�ͮĥ��(3)
        	mgr1_prate2		decimal(6,2),	-- ���� ñ��ߩ�ͮĤ�v(4) (3)/(2)
       		mgr2_count2		int,		-- �D���� ñ��ߩ�ͮĥ��(6)
		mgr2_prate2 		decimal(6,2)	-- �D���� ñ��ߩ�ͮĤ�v(7) (6)/(5)
  	        ) with no log;

  		$create temp table tmp_table8
		(
		seqno			char(2), 	-- �Ǹ�
		iupcomp			char(2),	-- ���ݤ����q�O
		nchi_abv		char(20),	-- ���ݤ����q²��
		ipolicy12		char(2), 	-- �O�渹�e2�X
   		nbranch			char(20),	-- ���W��
   		tcount			int, 		-- ����`���(1)
   		mgr1_tcount		int, 		-- �����`���(2)
  		mgr2_tcount		int, 		-- �D�����`���(5)
      		mgr1_count2		int,		-- ���� ñ��ߩ�ͮĥ��(3)
        	mgr1_prate2		decimal(6,2),	-- ���� ñ��ߩ�ͮĤ�v(4) (3)/(2)
       		mgr2_count2		int,		-- �D���� ñ��ߩ�ͮĥ��(6)
		mgr2_prate2 		decimal(6,2)	-- �D���� ñ��ߩ�ͮĤ�v(7) (6)/(5)
  	        ) with no log;

  		$create temp table tmp_table9
		(
		seqno			char(2), 	-- �Ǹ�
		iupcomp			char(2),	-- ���ݤ����q�O
		nchi_abv		char(20),	-- ���ݤ����q²��
		ipolicy12		char(2), 	-- �O�渹�e2�X
   		nbranch			char(20),	-- ���W��
   		tcount			int, 		-- ����`���(1)
   		mgr1_tcount		int, 		-- �����`���(2)
  		mgr2_tcount		int, 		-- �D�����`���(5)
      		mgr1_count2		int,		-- ���� ñ��ߩ�ͮĥ��(3)
        	mgr1_prate2		decimal(6,2),	-- ���� ñ��ߩ�ͮĤ�v(4) (3)/(2)
       		mgr2_count2		int,		-- �D���� ñ��ߩ�ͮĥ��(6)
		mgr2_prate2 		decimal(6,2)	-- �D���� ñ��ߩ�ͮĤ�v(7) (6)/(5)
  	        ) with no log;

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
