/************************************************/
/*                                              */
/*   PROGRAM : ca162m01s.ec                     */
/*                                              */
/************************************************/
#include <stdio.h>
#include <string.h>
#include <decimal.h>
#include <time.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "is_def.h"
$include sqlca;
#include "safeclib.h"

char   sApHome[50];
FILE   *sfp,*fp;
static char  *bp;
static int   recLen=1024;
int offset;
$char getfile[300];
char delimiter;
$date Today;
#define TRUE 1
#define FALSE 0
long MsgCode;

char  OutFile[20];
FILE  *fptr;
$char sErrMsg[2048],outputf[20],errmsg[512];

long car162(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	long rtncode;
	char option;

	cm_buf_init_x(command);
	cm_buf_get("%c",&option);

	switch(option)
	{
		case 'I':
			rtncode=car162_insert(reply);
	           break;
		case 'A':
			rtncode=car162_insert_provision(reply);
			break;
		case 'Q':
			rtncode=car162_single_query(reply);
			break;
		case 'M':
			rtncode=car162_multiple_query(reply);
			break;
		case 'm':
			rtncode=car162_multiple_query2(reply);
			break;
		case 'R':
			rtncode=car162_insert_new_rate(reply);
			break;
		case 'D':
		case 'U':
			rtncode=car162_update_exec(reply,command,com_len);
			break;
		default :
			return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
	}
	return(rtncode);
}

void GetData(data, maxlen, delimiter)
char *data, delimiter;
int maxlen;
{
	int fori, pre_offset, cnt=0;

	data[0]='\0';
	pre_offset = offset;

	for (fori=pre_offset; bp[fori]!=0x00&&bp[fori]!=0x0d&&bp[fori]!=0x0a&&bp[fori]!=delimiter; fori++)
	{
		offset++;
		if (cnt < maxlen-1)
		{
			data[cnt]=bp[fori];
			cnt++;
		}
	}

	offset++;
	if (cnt==0) data[cnt++]=0x20;
	data[cnt]=0x00;
	printf("pre_offset[%d]offset[%d]len[%d]data[%s]\n", pre_offset, offset, cnt, data);
}

long car162_insert(reply)
serverReply reply;
{
	$int  ipflag,icnt;
	$char DBName[5],userid[11];
	$char iprovision[6],nprovision[256],nnumber[256],narticle[256],ncontent[256],c_iarticle[3];
	$char drate_ym[5],iclass[2],dbegin[11],dend[11],fcont[2],fcont_1[2],narticle_1[256];
	$int  iarticle,icontent;
	$char icreate[11],dcreate[20],iupdate[11],dupdate[20];
	$char old_dbegin[11],old_dend[11],dbegin1[11],dend1[11],new_dbegin[11];
	$char narticle_p[256],narticle_n[256];
	$char msgbuf[2048],LsBuffer[1024],LsBuffer1[1024],stmt_cpa[1024];
	long  MsgCode,rtncode;
	$long old_dbegin1,old_dend1,new_dbegin1;
	int   tmp_len,lenErr,i,x;
	$char txtfile[101],ffname[101];
	$char  str[256],str2[256],sprov_article[1024];
	$int  iarticle_no_content = 0;
	$char c_iarticle_no_content[3];
	
	iarticle = icontent = 0;
	char *malloc();
	
	cm_buf_get("%s %s %s %s %s %s %s %s %s ",DBName,txtfile,ffname,iprovision,drate_ym,iclass,dbegin,dend,userid);
	
	strcpy(new_dbegin,dbegin);
	strcpy(dbegin, cm_to_infdate(dbegin));
	strcpy(dend, cm_to_infdate(dend));
	narticle_n[0] = '\0';
	narticle_p[0] = '\0';	
	rtoday(&Today);
	
	if (db_select(DBName) == False)
	{
		if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
		return M_CM_DB_NOTOPEN;
		else
		return apiRC;
	}
	rtncode = getApHome(sApHome);
	if (rtncode < 0)
	{
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return rtncode;
	}
	
	$SET LOCK MODE TO WAIT;
	$WHENEVER SQLERROR GOTO errexit;
	$BEGIN WORK;
	
	printf("iprovision[%s] drate_ym[%s] iclass[%s] dbegin[%s] dend[%s] nprovision[%s] nnumber[%s] iarticle[%d] narticle[%s] icontent[%d] ncontent[%s] userid[%s] \n",
	        iprovision,drate_ym,iclass,dbegin,dend,nprovision,nnumber,iarticle,narticle,icontent,ncontent,userid);
	        
	new_dbegin1 = cm_ymd_cdate(new_dbegin);
	/*�P�_�ͮĤ�O�_���а϶�*/    
	sprintf_s(stmt_cpa, sizeof stmt_cpa,"SELECT UNIQUE dbegin,dend "
	                                    " FROM ca_provision "
	                                    " WHERE iprovision = '%s' "
	                                    "  AND drate_ym = '%s' "
	                                    "  AND iclass = '%s' "
	                                    "  AND (dexpire IS NULL OR dexpire = ' ')",iprovision,drate_ym,iclass);
	printf("stmt_cpa[%s]\n",stmt_cpa);
	$PREPARE pre_cpa FROM $stmt_cpa;
	$DECLARE dec_cpa CURSOR FOR pre_cpa;
	$OPEN dec_cpa;
	for(;;)
	{
		$FETCH dec_cpa INTO $dbegin1,$dend1;
		if (SQLCODE != 0) break;
		strcpy(dbegin1,trim(dbegin1));
		strcpy(dend1,trim(dend1));
		strcpy(old_dbegin,cm_from_infdate_100(dbegin1));
		old_dbegin1 = cm_ymd_cdate(old_dbegin);
		strcpy(old_dend,cm_from_infdate_100(dend1));
		old_dend1 = cm_ymd_cdate(old_dend);
		printf("new_dbegin1[%d] old_dbegin1[%d] old_dend1[%d]\n",new_dbegin1,old_dbegin1,old_dend1);
	    	
		if(strlen(dend1)==0)
			if(new_dbegin1 > old_dbegin1)	
				return exitsub(reply,M_CM_DUPDATA) ? M_CM_DUPDATA :apiRC;
			else
				continue;
		else if(strlen(dend1) != 0)
			if(new_dbegin1 > old_dbegin1 && new_dbegin1 < old_dend1)
				return exitsub(reply,M_CM_DUPDATA) ? M_CM_DUPDATA :apiRC;
			else
				continue;
		else 
			continue;
	}
	$CLOSE dec_cpa;
	
	ipflag = 0;
	printf("sApHome[%s]\n",sApHome);
	printf("txtfile[%s]\n",txtfile);
	sprintf_s(getfile, sizeof getfile,"%s/dat/car/%s",sApHome,txtfile);
	printf("getfile[%s]\n",getfile);
	
	if ((fp=fopen(getfile,"rt"))==NULL)
	{
	    return FAIL;
	}
	if ((bp=malloc(recLen))==NULL)
	{
	    printf("System malloc failed  !\n");
	    return FAIL;
	}

	delimiter = '\r';
	icnt = 0;
	while(fgets(bp,recLen,fp))
	{
		if (feof(fp)) break;
		offset = 0;
		GetData(str,               sizeof(str),           delimiter);
		
		printf("str[%s]\n,",str);
		strcpy(str,rtrim(str));
		$WHENEVER SQLERROR GOTO errexit;
		printf("INSERT_BGN\n");
		if(strncmp(str,"P",1) == 0 && strncmp(str,"P.",2) != 0)
		{
			narticle[0] = '\0';
			narticle_1[0] = '\0';
			printf("IN P\n");
			strcat(narticle,str);
			strncpy(narticle_1,narticle+1,strlen(narticle)-1);
			narticle_1[strlen(narticle)-1] = '\0';
			printf("-----narticle_1[%s]\n",narticle_1);
			strcat(narticle_p,narticle_1);
			strcat(narticle_p,",");
		}
		else if(strncmp(str,"N",1) == 0 && strncmp(str,"N.",2) != 0)
		{
			narticle[0] = '\0';
			narticle_1[0] = '\0';
			printf("IN N\n");
			strcat(narticle,str);
			strncpy(narticle_1,narticle+1,strlen(narticle)-1);
			narticle_1[strlen(narticle)-1] = '\0';
			printf("-----narticle_1[%s]\n",narticle_1);
			strcat(narticle_n,narticle_1);
			strcat(narticle_n,",");
		}
		else if(strncmp(str,"B",1) == 0 && strncmp(str,"B.",2) != 0)
		{
			iarticle++;
			narticle[0] = '\0';
			fcont_1[0] = '\0';
			narticle_1[0] = '\0';
			printf("IN B\n");
			strcat(narticle,str);
			strcpy(c_iarticle,itoa(iarticle));
			printf("-----c_iarticle[%s]",c_iarticle);
			strncpy(fcont_1,narticle,1);
			strncpy(narticle_1,narticle+1,strlen(narticle)-1);
			narticle_1[strlen(narticle)-1] = '\0';
			printf("-----fcont_1[%s]\n",fcont_1);
			printf("-----narticle_1[%s]\n",narticle_1);
			icontent = 1 ;
			
			sprintf_s(LsBuffer1, sizeof LsBuffer1,"INSERT INTO ca_provision "
	                                              "           (iprovision,drate_ym,iclass,dbegin,dend,iarticle,fcont,narticle,icreate,dcreate,iupdate,dupdate) "
	     	                                      "    VALUES ('%s','%s','%s','%s','%s','%s','%s','%s','%s',current,'%s',current)",
	     	                                                  iprovision,drate_ym,iclass,dbegin,dend,c_iarticle,fcont_1,narticle_1,userid,userid);
			printf("LsBuffer[%s]\n",LsBuffer1);
			$PREPARE ins1 FROM $LsBuffer1;
			$EXECUTE ins1 ;
		}
		else
		{
			if(strlen(str)==0)
			{
				ncontent[0] = '\0';
				continue;
			}
			else
			{
				strcpy(ncontent,str);
				sprintf_s(LsBuffer, sizeof LsBuffer,"INSERT INTO ca_prov_content "
				                                    "            (iprovision,drate_ym,iclass,dbegin,iarticle,icontent,fcont,ncontent,icreate,dcreate,iupdate,dupdate) "
				                                    "     VALUES ('%s','%s','%s','%s','%s',%d,' ','%s','%s',current,'%s',current)",
				                                                  iprovision,drate_ym,iclass,dbegin,c_iarticle,icontent,ncontent,userid,userid);
				printf("LsBuffer[%s]\n",LsBuffer);
				$PREPARE ins FROM $LsBuffer;
				$EXECUTE ins ;
				icontent++;
				ncontent[0] = '\0';
			}
		}
		printf("INSERT_END\n");
		memset(bp, ' ', recLen);
		icnt++;
	}

	if (icnt == 0)
	{
		return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND :apiRC;
	}
	
	free(bp);
	fclose(fp);

	/*printf("\nnarticle_p[%s]\nnarticle_n[%s]\n",narticle_p);*/
	$INSERT INTO ca_provision(iprovision,drate_ym,iclass,dbegin,dend,iarticle,fcont,narticle,icreate,dcreate,iupdate,dupdate)
	                   VALUES($iprovision,$drate_ym,$iclass,$dbegin,$dend,'P','P',$narticle_p,$userid,current,$userid,current);
	$INSERT INTO ca_provision(iprovision,drate_ym,iclass,dbegin,dend,iarticle,fcont,narticle,icreate,dcreate,iupdate,dupdate)
	                   VALUES($iprovision,$drate_ym,$iclass,$dbegin,$dend,'N','N',$narticle_n,$userid,current,$userid,current);

	/* �����`�S������A�s�W�@���ťզ�A�]���S���������J���ڥ\��A�q�@�}�l���s�W���ڱ��� */
	sprintf_s(sprov_article, sizeof sprov_article,"SELECT iarticle "
												  "  FROM ca_provision a "
												  " WHERE NOT EXISTS(SELECT 1 FROM ca_prov_content "
												  "                   WHERE iprovision = a.iprovision AND drate_ym = a.drate_ym"
												  "                     AND iclass = a.iclass AND dbegin = a.dbegin AND iarticle = a.iarticle)"
												  "   AND iprovision = '%s' AND drate_ym = '%s'  AND iclass = '%s' AND dbegin = '%s' "
												  "   AND iarticle NOT IN ('P','N');",iprovision,drate_ym,iclass,dbegin);
	printf("sprov_article[%s]\n",sprov_article);
	$PREPARE pre_prov_article FROM $sprov_article;
	$DECLARE dec_pre_prov_article CURSOR FOR pre_prov_article;
	
	$OPEN dec_pre_prov_article;
	for(;;)
	{
		$FETCH dec_pre_prov_article INTO $iarticle_no_content;
		if(SQLCODE == SQLNOTFOUND) break; /* ���ڷs�W�L���` */

		printf("iarticle_no_content[%d]\n",iarticle_no_content);
		/* �w�ﳹ�`����s�W�ťզ� */
		strcpy(c_iarticle_no_content,itoa(iarticle_no_content));
		$INSERT INTO ca_prov_content(iprovision,drate_ym,iclass,dbegin,iarticle,icontent,fcont,ncontent,icreate,dcreate,iupdate,dupdate)
							VALUES($iprovision,$drate_ym,$iclass,$dbegin,$c_iarticle_no_content,1,' ',' ',$userid,current,$userid,current);

	}
	$CLOSE dec_pre_prov_article;

	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	tmp_len = cm_buf_len(ReplyBuf);
	
	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
	{
	    $WHENEVER SQLERROR CONTINUE;
	    $ROLLBACK WORK;
	    return apiRC;
	}
	$COMMIT WORK;
	return api_OKComplete;
	
errexit:
    printf(" sqlerrm = %s\n",sqlca.sqlerrm);
    $WHENEVER SQLERROR CONTINUE;
    MsgCode = SQLCODE;
    $ROLLBACK WORK;
    if (SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

long car162_insert_provision(reply)
serverReply reply;
{
	$char DBName[5],DBName1[5];
	$char LsBuffer0[1024],LsBuffer1[1024],LsBuffer2[1024],LsBuffer3[1024],sFullName[20],stmp[128];
	$char sFullName_sys[20];
	$char old_iprovision[6],old_drate_ym[5],old_iclass[2],old_dbegin[11],old_dend[11],old_dexpire[11];
	$char new_iprovision[6],new_drate_ym[5],new_iclass[2],new_dbegin[11],new_dend[11],new_nnumber[256];
	$char icreate[20],dcreate[20],iupdate[20],dupdate[20],userid[11];
	$int cnt_pro = 0;
	int LiBufLen;
	
	cm_buf_get("%s",DBName);
	cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s",old_iprovision,old_drate_ym,old_iclass,old_dbegin,old_dend,old_dexpire,new_drate_ym,
	                                              new_dbegin,new_dend,new_nnumber,userid);

	if (db_select(DBName) == False)
	return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
	
	$WHENEVER SQLERROR GOTO errexit;
	$BEGIN WORK;
	
	strcpy(old_dbegin, cm_to_infdate(old_dbegin));
	strcpy(old_dend, cm_to_infdate(old_dend));
	strcpy(new_dbegin, cm_to_infdate(new_dbegin));
	strcpy(new_dend, cm_to_infdate(new_dend));
	
	strcpy(old_dexpire,trim(old_dexpire));
	if(strlen(old_dexpire)==0)
		strcpy(stmp," ");
	else{
		strcpy(old_dexpire, cm_to_infdate(old_dexpire));
		sprintf_s(stmp, sizeof stmp,"AND dexpire = '%s'",old_dexpire);
	}
	
	sprintf_s(LsBuffer0, sizeof LsBuffer0,"SELECT count(*) "
	                                      "  FROM ca_provision "
	                                      " WHERE iprovision = '%s' "
	                                      "   AND drate_ym = '%s' "
	                                      "   AND iclass = '%s' "
	                                      "   AND dbegin = '%s' "
	                                      "   AND iarticle <> 'N' %s",old_iprovision,old_drate_ym,old_iclass,old_dbegin,stmp);
	printf("a1[%s]\n\n",LsBuffer0);
	$PREPARE in_before FROM $LsBuffer0;
	$EXECUTE in_before INTO $cnt_pro;
	
	if(cnt_pro == 0)
	{
		$COMMIT WORK;
		return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND :apiRC;	
	}

	sprintf_s(LsBuffer1, sizeof LsBuffer1,"INSERT INTO ca_provision "
	                                      "SELECT iprovision,'%s',iclass,'%s',iarticle,'%s',dexpire,fcont,narticle,'%s',CURRENT,'%s',current "
	                                      "  FROM ca_provision "
	                                      " WHERE iprovision = '%s' "
	                                      "   AND drate_ym = '%s' "
	                                      "   AND iclass = '%s' "
	                                      "   AND dbegin = '%s' "
	                                      "   AND iarticle <> 'N' %s",new_drate_ym,new_dbegin,new_dend,userid,userid,old_iprovision,old_drate_ym,old_iclass,old_dbegin,stmp);
	printf("a1[%s]\n\n",LsBuffer1);
	$PREPARE in_a FROM $LsBuffer1;
	$EXECUTE in_a;

	sprintf_s(LsBuffer2, sizeof LsBuffer2,"INSERT INTO ca_provision "
	                                     " SELECT iprovision,'%s',iclass,'%s',iarticle,'%s',dexpire,fcont,'%s','%s',CURRENT,'%s',current "
	                                     "   FROM ca_provision "
	                                     "  WHERE iprovision = '%s' "
	                                     "    AND drate_ym = '%s' "
	                                     "    AND iclass = '%s' "
	                                     "    AND dbegin = '%s' "
	                                     "    AND iarticle = 'N' %s",new_drate_ym,new_dbegin,new_dend,new_nnumber,userid,userid,old_iprovision,old_drate_ym,old_iclass,old_dbegin,stmp);
	printf("a2[%s]\n\n",LsBuffer2);
	$PREPARE in_b FROM $LsBuffer2;
	$EXECUTE in_b;

	sprintf_s(LsBuffer3, sizeof LsBuffer3,"INSERT INTO ca_prov_content "
	                                      "SELECT iprovision,'%s',iclass,'%s',iarticle,icontent,fcont,ncontent,'%s',CURRENT,'%s',current "
	                                      "  FROM ca_prov_content "
	                                      " WHERE iprovision = '%s' "
	                                      "   AND drate_ym = '%s' "
	                                      "   AND iclass = '%s' "
	                                      "   AND dbegin = '%s' %s",new_drate_ym,new_dbegin,userid,userid,old_iprovision,old_drate_ym,old_iclass,old_dbegin,stmp);
	printf("a3[%s]\n\n",LsBuffer3);
	$PREPARE in_c FROM $LsBuffer3;
	$EXECUTE in_c;

	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	LiBufLen = cm_buf_len(ReplyBuf);

	if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
	{
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		return apiRC;
	}
	
	$COMMIT WORK;
	return api_OKComplete;

errexit:
	printf(" sqlerrm = %s\n",sqlca.sqlerrm);
	$WHENEVER SQLERROR CONTINUE;
	MsgCode = SQLCODE;
	$ROLLBACK WORK;
	if (SQLCODE != 0) MsgCode = SQLCODE;
	return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

long car162_single_query(reply)
serverReply reply;
{
	$char DBName[5],sFullName[21],stmt[2048],stmt2[2048],stmt_P[1024],stmt_N[1024],stmp[128],stmp2[128];
	$char m_iprovision[6],m_drate_ym[5],m_iclass[2],m_dbegin[11],m_dend[11],m_dexpire[11],m_iarticle[3];
	$char q_iprovision[6],q_drate_ym[5],q_iclass[2],q_dbegin[11],q_dend[11],q_dexpire[11],q_iarticle[3],q_narticle[256];
	$char q_nnumber[256],q_narticle1[256];
	$char q_ncontent_tmp1[20601],q_ncontent_tmp2[20601],q_ncontent_tmp3[20601],q_ncontent_tmp4[20601]; /* �������ڲӱ��夺�e�L���A���ըS��k�@���^�ǹL�j�q�A�קK�ǿ鲧�`����ǿ�i�� */
	$char q_icreate[11],q_dcreate[20],q_iupdate[11],q_dupdate[20],q_iupdate2[11],q_dupdate2[20];
	$char q_ncreate[11],q_nupdate[11],q_nupdate2[11];
	$char ncontent_tmp[103];
	$int q_icontent = 0;
	char tmpbuf[100000];
	long count=0,repbuf_len=0,tmp_len=0,replycnt=0;
	int i,total_count=0;

	$int cnt_content_row = 0,cnt_block = 0;
	
	int thresholds[] = {190, 380, 570, 760};    
	char *bufs[] = {q_ncontent_tmp1, q_ncontent_tmp2, q_ncontent_tmp3,q_ncontent_tmp4};
	size_t bufSizes[] = {sizeof(q_ncontent_tmp1), sizeof(q_ncontent_tmp2), sizeof(q_ncontent_tmp3),sizeof(q_ncontent_tmp4)};
	
	bufs[0][0] = '\0';
	bufs[1][0] = '\0';
	bufs[2][0] = '\0';
	bufs[3][0] = '\0';
  
	cm_buf_get("%s %s %s %s %s %s %s %s ",DBName,m_iprovision,m_drate_ym,m_iclass,m_dbegin,m_dend,m_iarticle,m_dexpire);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	strcpy(m_dexpire,trim(m_dexpire));
	strcpy(m_dend,trim(m_dend));
		
	if(strlen(m_dexpire)==0) 
		strcpy(stmp," ");
	else
		sprintf_s(stmp, sizeof stmp,"AND dexpire = '%s' ",m_dexpire);
	
	if(strlen(m_dend)==0)  
		strcpy(stmp2," ");
	else 
		sprintf_s(stmp2, sizeof stmp2,"AND dend = '%s' ",m_dend);

	if (db_select(DBName) == False)
	{
		if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}

	sprintf_s(stmt, sizeof stmt,"SELECT UNIQUE a.iprovision,a.drate_ym,a.iclass,a.dbegin,a.dend,a.dexpire,a.iarticle,(a.fcont||a.narticle), "
	                            "       a.icreate,(SELECT nname FROM officer WHERE iofficer = a.icreate),a.dcreate, "
	                            "       a.iupdate,(SELECT nname FROM officer WHERE iofficer = a.iupdate),a.dupdate "
                                "       FROM ca_provision a "
                                " WHERE a.iprovision = '%s' "
                                "   AND a.drate_ym = '%s' "
                                "   AND a.iclass = '%s' "
                                "   AND a.dbegin = '%s' "
                                "   %s "
                                "   AND a.iarticle = '%s' %s ",m_iprovision,m_drate_ym,m_iclass,m_dbegin,stmp2,m_iarticle,stmp);
	printf("stmt[%s]\n", stmt);
	$PREPARE prep_provision FROM $stmt;
	$EXECUTE prep_provision INTO $q_iprovision,$q_drate_ym,$q_iclass,$q_dbegin,$q_dend,$q_dexpire,$q_iarticle,$q_narticle,
	                             $q_icreate,$q_ncreate,$q_dcreate,
	                             $q_iupdate,$q_nupdate,$q_dupdate;
	
	if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True) 
			return M_CM_NOT_FOUND;
		else
			return apiRC;
	}

	sprintf_s(stmt_P, sizeof stmt_P,"SELECT (fcont||narticle) "
	                              "  FROM ca_provision "
	                              " WHERE iprovision = '%s' "
	                              "   AND drate_ym = '%s' "
	                              "   AND iclass = '%s' "
	                              "   AND dbegin = '%s' "
	                              "   %s "
	                              "   AND iarticle = 'P' %s ",m_iprovision,m_drate_ym,m_iclass,m_dbegin,stmp2,stmp);
	printf("stmt_P[%s]\n", stmt_P);
	$PREPARE prep_P FROM $stmt_P;
	$EXECUTE prep_P INTO $q_narticle1;
	
	if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)
			return M_CM_NOT_FOUND;
		else
			return apiRC;
	}	
	sprintf_s(stmt_N, sizeof stmt_N,"SELECT (fcont||narticle) "
		                          "  FROM ca_provision "
	                              " WHERE iprovision = '%s' "
	                              "   AND drate_ym = '%s' "
	                              "   AND iclass = '%s' "
	                              "   AND dbegin = '%s' "
	                              "       %s "
	                              "   AND iarticle = 'N' %s ",m_iprovision,m_drate_ym,m_iclass,m_dbegin,stmp2,stmp);
	printf("stmt_N[%s]\n", stmt_N);
	$PREPARE prep_N FROM $stmt_N;
	$EXECUTE prep_N INTO $q_nnumber;
	
	if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)
	 		return M_CM_NOT_FOUND;
		else
			return apiRC;
	}
	
	cnt_content_row = 0;
	cnt_block = 1;

	sprintf_s(stmt2, sizeof stmt2,"SELECT a.icontent,(a.fcont||a.ncontent),a.iupdate,(SELECT nname FROM officer WHERE iofficer = a.iupdate),a.dupdate "
	   		                      "  FROM ca_prov_content a "
	                              " WHERE a.iprovision = '%s' "
	 	                          "   AND a.drate_ym = '%s' "
	 	                          "   AND a.iclass = '%s' "
	 	                          "   AND a.dbegin = '%s' "
	 	                          "   AND a.iarticle = '%s'",m_iprovision,m_drate_ym,m_iclass,m_dbegin,m_iarticle);
	printf("stmt2[%s]\n",stmt2);
	$PREPARE prep_ncontent FROM $stmt2;
	$DECLARE dec_ncontent CURSOR FOR prep_ncontent;
	
	$OPEN dec_ncontent;
	for(;;)
	{
		ncontent_tmp[0] = '\0';
		$FETCH dec_ncontent INTO $q_icontent,$ncontent_tmp,$q_iupdate2,$q_nupdate2,$q_dupdate2;
		if(SQLCODE == SQLNOTFOUND) break;

		cnt_content_row++;
		strcpy(ncontent_tmp, rtrim(ncontent_tmp));
		
		/* �H190�欰��ǡA�Ӥj�^�Ƿ|�����D */
		/* �ثe���@�Өҥ~�O57�I�ر��ڡA�L��1500�h��A���ީ���X���A�^�ǳ��٬O�|�������ѡA�p�����ʥu��z�L�󥿳�B�z */
		int r = 0;
		for(r = 0; r < 3; r++) {
	        if(cnt_content_row <= thresholds[r] && cnt_block == r + 1){
				strncat(bufs[r], ncontent_tmp, bufSizes[r] - strlen(bufs[r]) - 1);
				strncat(bufs[r], "\x0d\x0a", bufSizes[r] - strlen(bufs[r]) - 1);
				break;
			}
		}
		if(r == 3){
        	strncat(bufs[3], ncontent_tmp, bufSizes[3] - strlen(bufs[3]) - 1);
			strncat(bufs[3], "\x0d\x0a", bufSizes[3] - strlen(bufs[3]) - 1);
		}
		
		/* �C�� 190 ��Acnt_block++ */
    	if(cnt_content_row % 190 == 0)
        	cnt_block++;
	}
	$CLOSE dec_ncontent;

	cnt_content_row = 0;
	cnt_block = 0;

	strcpy(q_dbegin, cm_from_infdate_100(q_dbegin));
	strcpy(q_dend, cm_from_infdate_100(q_dend));
	strcpy(q_dexpire, cm_from_infdate_100(q_dexpire));

	cm_buf_init(ReplyBuf);
	cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s ",
	            M_CM_OK,q_iprovision,q_drate_ym,q_iclass,q_dbegin,q_dend,q_dexpire,q_narticle1,q_nnumber,q_iarticle,q_narticle,
	                    q_icreate,q_ncreate,q_dcreate,q_iupdate,q_nupdate,q_dupdate,q_icreate,q_ncreate,q_dcreate,q_iupdate2,q_nupdate2,q_dupdate2);
	cm_buf_put("%zs", q_ncontent_tmp1);
	cm_buf_put("%zs", q_ncontent_tmp2);
	cm_buf_put("%zs", q_ncontent_tmp3);
	cm_buf_put("%zs", q_ncontent_tmp4);
			
	tmp_len = cm_buf_len(ReplyBuf);
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		return apiRC;
	else
		return api_OKComplete;

	errexit:
	MsgCode = cm_show_sql_err("ca162_single_query", NULL);
	if(exitsub(reply,MsgCode) == True)
		return SQLCODE;
	else
		return apiRC;
}

long car162_multiple_query(reply)
serverReply reply;
{
	$char DBName[5];
	$char m_iprovision[6],m_drate_ym[5],m_iclass[2],m_dbegin[9],m_dend[9],m_dbegin_tmp[9],m_dend_tmp[9];
	$char iprovision[6],drate_ym[5],iclass[2],dbegin[11],dend[11],dexpire[11],iarticle[3],narticle[256];
	$char narticle1[256],nnumber[256];
	char  tmpbuf[4000];
	int   count=0,repbuf_len=0,tmp_len=0,replycnt=0; 
	int   i,total_count=0;
	$char stmt_mq1[1024],stmp_mq1[256];
	$int  in_iarticle = 0;
	
	cm_buf_get("%s %s %s %s %s %s ",DBName,m_iprovision,m_drate_ym,m_iclass,m_dbegin_tmp,m_dend_tmp);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
	       		return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}
	
	if(strncmp(m_dbegin_tmp,"*",1) == 0 && strncmp(m_dend_tmp,"*",1) == 0)
		strcpy(stmp_mq1," ");
	else
	{
		strcpy(m_dbegin, cm_to_infdate(m_dbegin_tmp));
		strcpy(m_dend, cm_to_infdate(m_dend_tmp));
		sprintf_s(stmp_mq1, sizeof stmp_mq1,"AND dbegin BETWEEN '%s' AND '%s' ",m_dbegin,m_dend);
	}
	
	sprintf_s(stmt_mq1, sizeof stmt_mq1,"SELECT UNIQUE a.iprovision,a.drate_ym,a.iclass,a.dbegin,a.dend,a.dexpire,a.narticle "
	                                   "  FROM ca_provision a "
	                                   " WHERE a.iprovision matches '%s' "
	                                   "   AND a.drate_ym matches '%s' "
	                                   "   AND a.iclass matches '%s' %s "
	                                   "   AND a.iarticle = 'P' ",m_iprovision,m_drate_ym,m_iclass,stmp_mq1);
	printf("stmt_mq1[%s]\n",stmt_mq1);
	
	$PREPARE pre_mq1 FROM $stmt_mq1;
	$DECLARE dec_mq1 CURSOR FOR pre_mq1;
	
	$OPEN dec_mq1;
	for(;;)
	{
		$FETCH dec_mq1 INTO $iprovision,$drate_ym,$iclass,$dbegin,$dend,$dexpire,$narticle;
		
		if (SQLCODE != 0) break;
		
		$WHENEVER SQLERROR GOTO errexit;
		
		if (SQLCODE != 0) break;
		
		cm_buf_init(tmpbuf);
		if ( count == 0 )
		{
			cm_buf_res_msg();
			cm_buf_res_count();
		}
		
		cm_buf_put("%s %s %s %s %s %s ",iprovision,drate_ym,iclass,dbegin,dend,narticle);
		
		tmp_len = cm_buf_len(tmpbuf);
		if ( tmp_len + repbuf_len < 3000 )
		{
			memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
			repbuf_len += tmp_len;
			count++;
		}
		else
		{
			cm_buf_init(ReplyBuf);
			cm_buf_put_msg(M_CM_OK);
			cm_buf_put_count(count);
			if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
			{
			    $CLOSE dec_mq1;
			    return apiRC;
			}
			else
			{
			    replycnt++;
			    if (replycnt == 30)
			    {
			    	cm_buf_init(ReplyBuf);
			    	cm_buf_put("%l",M_CM_OUT_SPACE);
			    	tmp_len = cm_buf_len(ReplyBuf);
			    	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
			   		return apiRC;
			    	return M_CM_OUT_SPACE;
			    }
			    ReplyBuf[0] = '\0';
			    count = 0;
			    cm_buf_init(ReplyBuf);
			    cm_buf_res_msg();
			    cm_buf_res_count();
			    cm_buf_put("%s %s %s %s %s %s ",iprovision,drate_ym,iclass,dbegin,dend,narticle);
			    repbuf_len = cm_buf_len(ReplyBuf);
			    count++;
			}
		}
	}	
	$CLOSE dec_mq1;
	
	if (count > 0)
	{
		cm_buf_init(ReplyBuf);
		cm_buf_put_msg(M_CM_OK);
		cm_buf_put_count(count);
		if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
			return apiRC;
		return api_OKComplete;
	}
	else
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)
			return M_CM_NOT_FOUND;
		else
			return apiRC;
	}
	
	errexit:
	if(exitsub(reply,SQLCODE) == True)
		return SQLCODE;
	else
		return apiRC;
}

long car162_multiple_query2(reply)
serverReply reply;
{
	$char DBName[5];
	$char m_iprovision[6],m_drate_ym[5],m_iclass[2],m_dbegin[9];
	$char iprovision[6],drate_ym[5],iclass[2],dbegin[11],dend[11],dexpire[11],iarticle[3],narticle[101];
	$char narticle1[256],nnumber[256];
	char  tmpbuf[4000];
	int   count=0,repbuf_len=0,tmp_len=0,replycnt=0;
	int   i,total_count=0;
	$char stmt_mq2[1024],stmp_mq2[256];
	$int in_iarticle = 0;
	
	cm_buf_get("%s %s %s %s %s ",DBName,m_iprovision,m_drate_ym,m_iclass,m_dbegin);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
	       		return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}
	
	sprintf_s(stmt_mq2, sizeof stmt_mq2,"SELECT UNIQUE a.iprovision,a.drate_ym,a.iclass,a.dbegin,a.dend,a.dexpire,a.iarticle,a.narticle,cast(a.iarticle as int) "
	                                    "  FROM ca_provision a "
	                                    " WHERE a.iprovision matches '%s' "
	                                    "   AND a.drate_ym matches '%s' "
	                                    "   AND a.iclass matches '%s' "
	                                    "   AND a.dbegin = '%s' "
	                                    "   AND a.iarticle not in ('P','N') "
	                                    "   ORDER BY 1,2,3,9 ",m_iprovision,m_drate_ym,m_iclass,m_dbegin);
	printf("stmt_mq2[%s]\n",stmt_mq2);
	
	$PREPARE pre_mq2 FROM $stmt_mq2;
	$DECLARE dec_mq2 CURSOR FOR pre_mq2;
	
	$OPEN dec_mq2;
	for(;;)
	{
		$FETCH dec_mq2 INTO $iprovision,$drate_ym,$iclass,$dbegin,$dend,$dexpire,$iarticle,$narticle,$in_iarticle;
		
		if (SQLCODE != 0) break;
		
		$SELECT narticle
		   INTO $narticle1
		   FROM ca_provision
		  WHERE iprovision = $iprovision
		    AND drate_ym = $drate_ym
		    AND iclass = $iclass
		    AND dbegin = $dbegin
		    AND iarticle = 'P';
		
		if (SQLCODE != 0) break;
		
		cm_buf_init(tmpbuf);
		if ( count == 0 )
		{
			cm_buf_res_msg();
			cm_buf_res_count();
		}
		
		cm_buf_put("%s %s %s %s %s %s %s %s %s ",iprovision,drate_ym,iclass,dbegin,dend,narticle1,iarticle,narticle,dexpire);
		
		tmp_len = cm_buf_len(tmpbuf);
		if ( tmp_len + repbuf_len < 3000 )
		{
			memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
			repbuf_len += tmp_len;
			count++;
		}
		else
		{
			cm_buf_init(ReplyBuf);
			cm_buf_put_msg(M_CM_OK);
			cm_buf_put_count(count);
			if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
			{
			    $CLOSE dec_mq2;
			    return apiRC;
			}
			else
			{
			    replycnt++;
			    if (replycnt == 30)
			    {
			    	cm_buf_init(ReplyBuf);
			    	cm_buf_put("%l",M_CM_OUT_SPACE);
			    	tmp_len = cm_buf_len(ReplyBuf);
			    	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
			   		return apiRC;
			    	return M_CM_OUT_SPACE;
			    }
			    ReplyBuf[0] = '\0';
			    count = 0;
			    cm_buf_init(ReplyBuf);
			    cm_buf_res_msg();
			    cm_buf_res_count();
			    cm_buf_put("%s %s %s %s %s %s %s %s %s ",iprovision,drate_ym,iclass,dbegin,dend,narticle1,iarticle,narticle,dexpire);
			    repbuf_len = cm_buf_len(ReplyBuf);
			    count++;
			}
		}
	}	
	$CLOSE dec_mq2;
	
	if (count > 0)
	{
		cm_buf_init(ReplyBuf);
		cm_buf_put_msg(M_CM_OK);
		cm_buf_put_count(count);
		if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
			return apiRC;
		return api_OKComplete;
	}
	else
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)
			return M_CM_NOT_FOUND;
		else
			return apiRC;
	}
	
	errexit:
	if(exitsub(reply,SQLCODE) == True)
		return SQLCODE;
	else
		return apiRC;
}

long car162_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	$char DBName[5],sFullName[21],userid[11];
	$char stmt_prov[2048],stmt_cont[2048],stmt_cn_prov[2048],stmp[128],stmp2[128],stmt_P[1024],stmt_N[1024];
	
	$char q_iprovision[6],q_drate_ym[5],q_iclass[2],q_dbegin[11],q_dend[11],q_dexpire[11],q_iarticle[3];
	$char q_narticle[256],q_nnumber[256];
	$char q_narticle1[256];
	$char q_ncontent_tmp1[20601],q_ncontent_tmp2[20601],q_ncontent_tmp3[20601],q_ncontent_tmp4[20601];
	$char q_icreate[11],q_dcreate[20],q_iupdate[11],q_dupdate[20];
	
	$int  cur_icontent = 0,ppp = 0,cnt_up = 0,cnt_upp = 0,cnt_upn = 0,cnt_upna = 0,cnt_upc = 0;
	
	$char cur_iprovision[6],cur_drate_ym[5],cur_iclass[2],cur_dbegin[11],cur_dend[11],cur_dexpire[11],cur_iarticle[3];
	$char cur_narticle[256],cur_narticle1[256];
	$char cur_icreate[11],cur_dcreate[20];
	$char cur_iupdate[11],cur_dupdate[20];
	$char cur_iupdate2[11],cur_dupdate2[20];
	$char cur_ncreate[11],cur_nupdate[11],cur_nupdate2[11];
	$char cur_nnumber[256];
	$char cur_ncontent_tmp1[20601],cur_ncontent_tmp2[20601],cur_ncontent_tmp3[20601],cur_ncontent_tmp4[20601];
	$int  cnt_content_row_cur = 0,cnt_block_cur = 0;
	
	$char stmt_buf[2048],stmt_buf1[2048],stmt_insert_content[40960];
	$char stmt_u1[2048],stmt_u2[2048];
	$char stmt_u3[2048],stmt_u4[2048];
	$char stmt_u5[2048],stmt_uu[2048];
	$char stmt_del[2048];
	
	$char u_iprovision[6],u_drate_ym[5],u_iclass[2],u_dbegin[20],u_dend[20],u_dexpire[11];
	$char u_nnumber[256],u_iarticle[3],u_narticle[256];
	$char u_ncontent_tmp1[20601],u_ncontent_tmp2[20601],u_ncontent_tmp3[20601],u_ncontent_tmp4[20601];
	$char temp_content[20601];
	$char ncontent1[256],u_ncontent2[256],u_nprovision[256];
	$char u_nprovision_fcont[2],u_nprovision_1[256],u_nnumber_fcont[2],u_nnumber_nar[256];
	$char u_narticle_fcont_1[2],u_narticle_1[256],u_ncontent2_1[2],u_ncontent2_2[256];
	
	$char *ptr;
	$int  cn_prov = 0;
	int   innumber;
	char  tmpbuf[100000];
	int   count = 0;
	char  option,*pos,*raw_ptr,*malloc(),cur_buf[100000],*comm;
	int   tmp_len,raw_len; 
	int   i,j,is_del_fail=0,is_upd_fail=0;
	$long  dummy;
	DBinfo *list;
	
	int thresholds_cur[] = {190, 380, 570, 760};    
	char *bufs_cur[] = {cur_ncontent_tmp1, cur_ncontent_tmp2, cur_ncontent_tmp3,cur_ncontent_tmp4};
	size_t bufSizes_cur[] = {sizeof(cur_ncontent_tmp1), sizeof(cur_ncontent_tmp2), sizeof(cur_ncontent_tmp3),sizeof(cur_ncontent_tmp4)};
	
	bufs_cur[0][0] = '\0';
	bufs_cur[1][0] = '\0';
	bufs_cur[2][0] = '\0';
	bufs_cur[3][0] = '\0';

	comm = (char *) command;
	cm_buf_init(command);
	cm_buf_get("%c %s",&option,DBName);
	
	if (db_select(DBName) == False)
		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

	$WHENEVER SQLERROR GOTO errexit;
	$BEGIN WORK;
	memcpy(&raw_len,&comm[com_len],sizeof(int));
	pos = &comm[com_len+sizeof(int)];
	raw_ptr = malloc(raw_len);
	if (raw_ptr != (char*)0)
		memcpy(raw_ptr,pos,raw_len);
	else
	{
		return exitsub(reply,M_CM_NOT_MALLOC) ? M_CM_NOT_MALLOC : apiRC;
	}

	cm_buf_init(raw_ptr);
	cm_buf_get("%l %s %s %s %s %s %s %s %s %s %s ",
	           &dummy,q_iprovision,q_drate_ym,q_iclass,q_dbegin,q_dend,q_dexpire,q_narticle1,q_nnumber,q_iarticle,q_narticle);
	cm_buf_get("%zs",q_ncontent_tmp1);
	cm_buf_get("%zs",q_ncontent_tmp2);
	cm_buf_get("%zs",q_ncontent_tmp3);
	cm_buf_get("%zs",q_ncontent_tmp4);

	strcpy(q_dbegin, cm_to_infdate(q_dbegin));
	strcpy(q_dend, cm_to_infdate(q_dend));
	strcpy(q_dexpire, cm_to_infdate(q_dexpire));
	strcpy(stmp," ");
	strcpy(stmp2," ");
	
	strcpy(q_dexpire,trim(q_dexpire));
	if(strlen(q_dexpire)==0)
		strcpy(stmp," ");
	else
		sprintf_s(stmp, sizeof stmp,"AND dexpire = '%s'",q_dexpire);

	if(strlen(q_dend)==0)
		strcpy(stmp2," ");
	else
		sprintf_s(stmp2, sizeof stmp2,"AND dend = '%s'",q_dend);

	sprintf_s(stmt_prov, sizeof stmt_prov,"SELECT UNIQUE a.iprovision,a.drate_ym,a.iclass,a.dbegin,a.dend,a.dexpire,a.iarticle,(a.fcont||a.narticle), "
	                                      "              a.icreate,(SELECT nname FROM officer WHERE iofficer = a.icreate),a.dcreate, "
	                                      "              a.iupdate,(SELECT nname FROM officer WHERE iofficer = a.iupdate),a.dupdate "
	                                      "  FROM ca_provision a "
	                                      " WHERE a.iprovision = '%s' "
	                                      "   AND a.drate_ym = '%s' "
	                                      "   AND a.iclass = '%s' "
	                                      "   AND a.dbegin = '%s' "
	                                      "    %s "
	                                      "   AND a.iarticle = '%s' %s",q_iprovision,q_drate_ym,q_iclass,q_dbegin,stmp2,q_iarticle,stmp);
	printf("stmt_prov[%s]\n", stmt_prov);

	$PREPARE prep_cur_prov FROM $stmt_prov;
	$EXECUTE prep_cur_prov INTO $cur_iprovision,$cur_drate_ym,$cur_iclass,$cur_dbegin,$cur_dend,$cur_dexpire,$cur_iarticle,$cur_narticle,$cur_icreate,$cur_ncreate,$cur_dcreate,$cur_iupdate,$cur_nupdate,$cur_dupdate;
	
	strcpy(cur_icreate,trim(cur_icreate));

	if (SQLCODE == SQLNOTFOUND)
	{
		MsgCode = M_CM_NOT_FOUND;
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		if(SQLCODE != 0) MsgCode = SQLCODE;
		return exitsub(reply,MsgCode) ? MsgCode : apiRC;
	}

	sprintf_s(stmt_P, sizeof stmt_P,"SELECT (fcont||narticle) "
	                                " FROM ca_provision "
	                                " WHERE iprovision = '%s' "
	                                " AND drate_ym = '%s' "
	                                " AND iclass = '%s' "
	                                " AND dbegin = '%s' "
	                                " %s %s "
	                                " AND iarticle = 'P'",q_iprovision,q_drate_ym,q_iclass,q_dbegin,stmp2,stmp);
	$PREPARE prep_cur_P FROM $stmt_P;
	$EXECUTE prep_cur_P INTO $cur_narticle1;

	if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)
			return M_CM_NOT_FOUND; 
		else
			return apiRC;
	}

	sprintf_s(stmt_N, sizeof stmt_N,"SELECT (fcont||narticle) "
	                                " FROM ca_provision "
	                                " WHERE iprovision = '%s' "
	                                " AND drate_ym = '%s' "
	                                " AND iclass = '%s' "
	                                " AND dbegin = '%s' "
	                                " %s %s "
	                                " AND iarticle = 'N'",q_iprovision,q_drate_ym,q_iclass,q_dbegin,stmp2,stmp);

	$PREPARE prep_cur_N FROM $stmt_N;
	$EXECUTE prep_cur_N INTO $cur_nnumber;

	if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True)
			return M_CM_NOT_FOUND;
		else
			return apiRC;
	}
	/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	cnt_content_row_cur = 0;
	cnt_block_cur = 1;
	sprintf_s(stmt_cont, sizeof stmt_cont,"SELECT a.icontent,(a.fcont||a.ncontent),a.iupdate,(SELECT nname FROM officer WHERE iofficer = a.iupdate),a.dupdate "
                                          " FROM ca_prov_content a "
                                          "   WHERE a.iprovision = '%s' "
                                          "     AND a.drate_ym = '%s' "
                                          "     AND a.iclass = '%s' "
                                          "     AND a.dbegin = '%s' "
                                          "     AND a.iarticle = '%s' %s",q_iprovision,q_drate_ym,q_iclass,q_dbegin,q_iarticle,stmp);
	printf("stmt_cont[%s]\n",stmt_cont);
	$PREPARE prep_cur_ncontent FROM $stmt_cont;
	$DECLARE dec_cur_ncontent CURSOR FOR prep_cur_ncontent;
	$OPEN dec_cur_ncontent;
	for(;;)
	{
		ncontent1[0] = '\0';
		$FETCH dec_cur_ncontent INTO $cur_icontent,$ncontent1,$cur_iupdate2,$cur_nupdate2,$cur_dupdate2;
		if (SQLCODE != 0) break;
		
		cnt_content_row_cur++;
		strcpy(ncontent1,rtrim(ncontent1));
		
		int r = 0;
		for(r = 0; r < 3; r++) {
	        if(cnt_content_row_cur <= thresholds_cur[r] && cnt_block_cur == r + 1){
				strncat(bufs_cur[r], ncontent1, bufSizes_cur[r] - strlen(bufs_cur[r]) - 1);
				strncat(bufs_cur[r], "\x0d\x0a", bufSizes_cur[r] - strlen(bufs_cur[r]) - 1);
				break;
			}
		}
		if(r == 3){
        	strncat(bufs_cur[3], ncontent1, bufSizes_cur[3] - strlen(bufs_cur[3]) - 1);
			strncat(bufs_cur[3], "\x0d\x0a", bufSizes_cur[3] - strlen(bufs_cur[3]) - 1);
		}
		
    	if(cnt_content_row_cur % 190 == 0)
        	cnt_block_cur++;
	}
	$CLOSE dec_cur_ncontent;
	/*----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
	strcpy(cur_dbegin, cm_from_infdate_100(cur_dbegin));
	strcpy(cur_dend, cm_from_infdate_100(cur_dend));
	strcpy(cur_dexpire, cm_from_infdate_100(cur_dexpire));

	cm_buf_init(cur_buf);
	cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
	            &dummy,cur_iprovision,cur_drate_ym,cur_iclass,cur_dbegin,cur_dend,cur_dexpire,cur_narticle1,cur_nnumber,cur_iarticle,cur_narticle,
	            cur_icreate,cur_ncreate,cur_dcreate,cur_iupdate,cur_nupdate,cur_dupdate,cur_icreate,cur_ncreate,cur_dcreate,cur_iupdate2,cur_nupdate2,cur_dupdate2);
	cm_buf_put("%zs",cur_ncontent_tmp1);
	cm_buf_put("%zs",cur_ncontent_tmp2);
	cm_buf_put("%zs",cur_ncontent_tmp3);
	cm_buf_put("%zs",cur_ncontent_tmp4);
	
	write(1,cur_buf,raw_len);
	write(1,"\n",1);
	write(1,raw_ptr,raw_len);
	write(1,"\n",1);

	sprintf_s(stmt_cn_prov, sizeof stmt_cn_prov,"SELECT count(*) "
	                                            "  FROM ca_prov_content a "
	                                            " WHERE a.iprovision = '%s' "
	                                            "   AND a.drate_ym = '%s' "
	                                            "   AND a.iclass = '%s' "
	                                            "   AND a.dbegin = '%s' "
	                                            "   AND a.iarticle = '%s' %s",q_iprovision,q_drate_ym,q_iclass,q_dbegin,q_iarticle,stmp);
	printf("stmt_cn_prov[%s]\n",stmt_cn_prov);
	$PREPARE prep_cn_prov FROM $stmt_cn_prov;
	$DECLARE dec_cn_prov CURSOR FOR prep_cn_prov;
	$EXECUTE dec_cn_prov INTO $cn_prov;
	if (memcmp(cur_buf,raw_ptr,raw_len) != 0 && cn_prov > 0) 
	{
		MsgCode = M_CM_NOT_EQUAL;
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		if(SQLCODE != 0) MsgCode = SQLCODE;
		return exitsub(reply,MsgCode) ? MsgCode : apiRC;
	}	
	
	memset(cur_buf, 0, sizeof(cur_buf));
	free(raw_ptr);
	
	if ( option == 'D' )
	{
		sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM ca_provision "
		                                    " WHERE iprovision = '%s' "
		                                    "   AND drate_ym = '%s' "
		                                    "   AND iclass = '%s' "
		                                    "   AND dbegin = '%s' "
		                                    "   %s %s ",q_iprovision,q_drate_ym,q_iclass,q_dbegin,stmp2,stmp);
		$PREPARE d_id FROM $stmt_buf;
		$EXECUTE d_id;
		if(SQLCODE != 0) is_del_fail = 1;
		
		sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM ca_prov_content "
		                                    " WHERE iprovision = '%s' "
		                                    "   AND drate_ym = '%s' "
		                                    "   AND iclass = '%s' "
		                                    "   AND dbegin = '%s' %s ",q_iprovision,q_drate_ym,q_iclass,q_dbegin,stmp);
		$PREPARE d_id2 FROM $stmt_buf;
		$EXECUTE d_id2;
		if(SQLCODE != 0) is_del_fail = 1;
	
		cm_buf_init(ReplyBuf);
		cm_buf_put("%l",M_CM_OK);
		tmp_len = cm_buf_len(ReplyBuf);
		
		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
		{
			$WHENEVER SQLERROR CONTINUE;
			$ROLLBACK WORK;
			return apiRC;
		}
		$COMMIT WORK;
		return api_OKComplete;
	}
	else if (option == 'U')
	{
		u_ncontent_tmp1[0] = '\0';
		u_ncontent_tmp2[0] = '\0';
		u_ncontent_tmp3[0] = '\0';
		u_ncontent_tmp4[0] = '\0';
		cm_buf_init(command);
		cm_buf_get("%c %s ",&option,DBName);
		cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s ",u_iprovision,u_drate_ym,u_iclass,u_dbegin,u_dend,u_dexpire,u_nprovision,u_nnumber,u_iarticle,u_narticle,userid);
		cm_buf_get("%zs ",u_ncontent_tmp1);
		cm_buf_get("%zs ",u_ncontent_tmp2);
		cm_buf_get("%zs ",u_ncontent_tmp3);
		cm_buf_get("%zs ",u_ncontent_tmp4);

		strcpy(u_dbegin, cm_to_infdate(u_dbegin));
		strcpy(u_dend, cm_to_infdate(u_dend));
		if(strlen(u_dexpire)==0)
			strcpy(u_dexpire,"NULL");
		else
			strcpy(u_dexpire, cm_to_infdate(u_dexpire));
		
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/* update_ca_provision_article_P */
		$WHENEVER SQLERROR go to errexit;
		strcpy(u_nprovision,rtrim(u_nprovision));
		/*printf("u_nprovision[%s]\n",u_nprovision);*/
		strncpy(u_nprovision_fcont,u_nprovision,1);
		u_nprovision_fcont[1] = '\0';
		strncpy(u_nprovision_1,u_nprovision+1,strlen(u_nprovision)-1);
		u_nprovision_1[strlen(u_nprovision)-1] = '\0';
		/*printf("u_nprovision_fcont[%s]\n",u_nprovision_fcont);
		printf("u_nprovision_1[%s]\n",u_nprovision_1);*/
		
		/*printf("u_iprovision[%s] u_drate_ym[%s] u_iclass[%s] u_dbegin[%s] u_dexpire[%s]\n",u_iprovision,u_drate_ym,u_iclass,u_dbegin,u_dexpire);
		printf("u_nprovision_fcont[%s] u_nprovision_1[%s] \n",u_nprovision_fcont,u_nprovision_1);
		printf("q_iprovision[%s]  \n",q_iprovision);
		printf("q_drate_ym[%s] q_iclass[%s] q_dbegin[%s] stmp[%s] \n",q_drate_ym,q_iclass,q_dbegin,stmp);*/

		sprintf_s(stmt_u1, sizeof stmt_u1,"UPDATE ca_provision \
		                                      SET iprovision = '%s',drate_ym = '%s',iclass = '%s',dbegin = '%s',dend = '%s',dexpire = '%s', \
		                                          fcont = '%s',narticle = '%s' \
		                                    WHERE iprovision = '%s' \
		                                      AND drate_ym = '%s' \
		                                      AND iclass = '%s' \
		                                      AND dbegin = '%s' %s \
		                                      AND iarticle = 'P'",u_iprovision,u_drate_ym,u_iclass,u_dbegin,u_dend,u_dexpire,
		                                                          u_nprovision_fcont,u_nprovision_1,
		                                                          q_iprovision,q_drate_ym,q_iclass,q_dbegin,stmp);
		printf("stmt_u1[%s] \n", stmt_u1);
		$PREPARE upp FROM $stmt_u1;
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/* update_ca_provision_article_N */
		u_nnumber_nar[0]='\0';
		u_nnumber_fcont[0]='\0';
		strcpy(u_nnumber,rtrim(u_nnumber));
		printf("u_nnumber[%s]\n",u_nnumber);
		innumber = strlen(u_nnumber);
		printf("innumber[%d]\n",innumber);
		strncpy(u_nnumber_fcont,u_nnumber,1);
		u_nnumber_fcont[1] = '\0';
		printf("u_nnumber_fcont[%s]\n",u_nnumber_fcont);
		printf("u_nnumber_nar[%s]\n",u_nnumber_nar);
		strncpy(u_nnumber_nar,u_nnumber+1,innumber-1);
		u_nnumber_nar[innumber-1] = '\0';
		printf("u_nnumber_nar[%s]\n",u_nnumber_nar);
		sprintf_s(stmt_u2, sizeof stmt_u2,"UPDATE ca_provision "
		                                  "   SET iprovision = '%s',drate_ym = '%s',iclass = '%s',dbegin = '%s',dend = '%s',dexpire = '%s', "
		                                  "       fcont = '%s',narticle = '%s' "
		                                  " WHERE iprovision = '%s' "
		                                  "   AND drate_ym = '%s' "
		                                  "   AND iclass = '%s' "
		                                  "   AND dbegin = '%s' %s "
		                                  "   AND iarticle = 'N'",u_iprovision,u_drate_ym,u_iclass,u_dbegin,u_dend,u_dexpire,u_nnumber_fcont,u_nnumber_nar,
		                                                         q_iprovision,q_drate_ym,q_iclass,q_dbegin,stmp);
		printf("stmt_u2[%s] \n", stmt_u2);
		$PREPARE upn FROM $stmt_u2;
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/* update_ca_provision_1(narticle) */
		strcpy(u_narticle,rtrim(u_narticle));
		printf("u_narticle[%s]\n",u_narticle);
		strncpy(u_narticle_fcont_1,u_narticle,1);
		u_narticle_fcont_1[1] = '\0';
		printf("u_narticle_fcont_1[%s]\n",u_narticle_fcont_1);
		strncpy(u_narticle_1,u_narticle+1,strlen(u_narticle)-1);
		u_narticle_1[strlen(u_narticle)-1] = '\0';
		printf("u_narticle_1[%s]\n",u_narticle_1);
		sprintf_s(stmt_u3, sizeof stmt_u3,"UPDATE ca_provision "
		                                  "   SET iprovision = '%s',drate_ym = '%s',iclass = '%s',dbegin = '%s',dend = '%s',dexpire = '%s', "
		                                  "       fcont = '%s',narticle = '%s',iupdate = '%s' ,dupdate = current "
		                                  " WHERE iprovision = '%s' "
		                                  "   AND drate_ym = '%s' "
		                                  "   AND iclass = '%s' "
		                                  "   AND dbegin = '%s' %s "
		                                  "   AND iarticle = '%s' ",u_iprovision,u_drate_ym,u_iclass,u_dbegin,u_dend,u_dexpire,u_narticle_fcont_1,u_narticle_1,userid,
		                                                            q_iprovision,q_drate_ym,q_iclass,q_dbegin,stmp,q_iarticle);
		printf("stmt_u3[%s] \n", stmt_u3);
		$PREPARE up1 FROM $stmt_u3;
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/* update_ca_provision_2 */
		sprintf_s(stmt_u4, sizeof stmt_u4,"UPDATE ca_provision "
		                                  "   SET iprovision = '%s',drate_ym = '%s',iclass = '%s',dbegin = '%s',dend = '%s',dexpire = '%s' "
		                                  " WHERE iprovision = '%s' "
		                                  "   AND drate_ym = '%s' "
		                                  "   AND iclass = '%s' "
		                                  "   AND dbegin = '%s' %s "
		                                  "   AND iarticle <> 'P' AND iarticle <> 'N'  ",u_iprovision,u_drate_ym,u_iclass,u_dbegin,u_dend,u_dexpire,
		q_iprovision,q_drate_ym,q_iclass,q_dbegin,stmp,q_iarticle);
		printf("stmt_u4[%s] \n", stmt_u4);
		$PREPARE up2 FROM $stmt_u4;
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/* update_ca_provision_3 */
		sprintf_s(stmt_u5, sizeof stmt_u5,"UPDATE ca_prov_content "
		                                  "   SET iprovision = '%s',drate_ym = '%s',iclass = '%s',dbegin = '%s',iupdate = '%s' ,dupdate = current "
		                                  " WHERE iprovision = '%s' "
		                                  "   AND drate_ym = '%s' "
		                                  "   AND iclass = '%s' "
		                                  "   AND dbegin = '%s' %s "
		                                  "   AND iarticle <> '%s' ",u_iprovision,u_drate_ym,u_iclass,u_dbegin,userid,q_iprovision,q_drate_ym,q_iclass,q_dbegin,stmp,q_iarticle);
		printf("stmt_u5[%s] \n", stmt_u5);
		$PREPARE up3 FROM $stmt_u5;
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/* update_ca_provision_updatedata */
		sprintf_s(stmt_uu, sizeof stmt_uu,"UPDATE ca_provision "
		                                  "   SET iupdate = '%s',dupdate = current "
		                                  " WHERE iprovision = '%s' "
		                                  "   AND drate_ym = '%s' "
		                                  "   AND iclass = '%s' "
		                                  "   AND dbegin = '%s' ",userid,q_iprovision,q_drate_ym,q_iclass,q_dbegin);
		printf("stmt_uu[%s] \n", stmt_uu);
		$PREPARE uu FROM $stmt_uu;
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		/* del ca_prov_content for insert */
		sprintf_s(stmt_del, sizeof stmt_del,"DELETE FROM ca_prov_content "
		                                    " WHERE iprovision = '%s' "
		                                    "   AND drate_ym = '%s' "
		                                    "   AND iclass = '%s' "
		                                    "   AND dbegin = '%s' %s "
		                                    "   AND iarticle = '%s' ",q_iprovision,q_drate_ym,q_iclass,q_dbegin,stmp,q_iarticle);
		printf("stmt_del[%s] \n", stmt_del);
		$PREPARE del_con FROM $stmt_del;
		/*------------------------------------------------------------------------------------------------------------------------------------------------------------------------------*/
		
		strcpy(q_iprovision,rtrim(q_iprovision)); strcpy(u_iprovision,rtrim(u_iprovision));
		strcpy(q_drate_ym,rtrim(q_drate_ym)); strcpy(u_drate_ym,rtrim(u_drate_ym));
		strcpy(q_iclass,rtrim(q_iclass)); strcpy(u_iclass,rtrim(u_iclass));
		strcpy(q_dbegin,rtrim(q_dbegin)); strcpy(u_dbegin,rtrim(u_dbegin));
		strcpy(q_dend,rtrim(q_dend)); strcpy(u_dend,rtrim(u_dend));
		strcpy(q_dexpire,rtrim(q_dexpire)); strcpy(u_dexpire,rtrim(u_dexpire));
		strcpy(q_narticle1,rtrim(q_narticle1)); strcpy(u_nprovision,rtrim(u_nprovision));
		strcpy(q_nnumber,rtrim(q_nnumber)); strcpy(u_nnumber,rtrim(u_nnumber));
		strcpy(q_narticle,rtrim(q_narticle)); strcpy(u_narticle,rtrim(u_narticle));

		/*
		printf("q_iprovision[%s],u_iprovision[%s]\n",q_iprovision,u_iprovision);
		printf("q_drate_ym[%s],u_drate_ym[%s]\n",q_drate_ym,u_drate_ym);
		printf("q_iclass[%s],u_iclass[%s]\n",q_iclass,u_iclass);
		printf("q_dbegin[%s],u_dbegin[%s]\n",q_dbegin,u_dbegin);
		printf("q_dend[%s],u_dend[%s]\n",q_dend,u_dend);
		printf("q_dexpire[%s],u_dexpire[%s]\n",q_dexpire,u_dexpire);
		printf("q_narticle1[%s],u_nprovision[%s]\n",q_narticle1,u_nprovision);
		printf("q_nnumber[%s],u_nnumber[%s]\n",q_nnumber,u_nnumber);
		printf("q_narticle[%s],u_narticle[%s]\n",q_narticle,u_narticle);
		*/
		
		if(strcmp(q_iprovision,u_iprovision)!=0) cnt_up++;
		if(strcmp(q_drate_ym,u_drate_ym)!=0) cnt_up++;
		if(strcmp(q_iclass,u_iclass)!=0) cnt_up++;
		if(strcmp(q_dbegin,u_dbegin)!=0) cnt_up++;
		if(strcmp(q_dend,u_dend)!=0) cnt_up++;
		if(strcmp(q_dexpire,u_dexpire)!=0) cnt_up++;
		if(strcmp(q_narticle1,u_nprovision)!=0) cnt_upp++;
		if(strcmp(q_nnumber,u_nnumber)!=0) cnt_upn++;
		if(strcmp(q_narticle,u_narticle)!=0) cnt_upna++;
		cnt_upc = 1;
		printf("\n*******\ncnt_up[%d],cnt_upp[%d],cnt_upn[%d],cnt_upna[%d],cnt_upc[%d]\n*******\n",cnt_up,cnt_upp,cnt_upn,cnt_upna,cnt_upc);

		if(cnt_up > 0)
		{
			$EXECUTE upp;
			$EXECUTE upn;
			$EXECUTE up1;
			$EXECUTE up2;
			$EXECUTE up3;
			$EXECUTE uu;
		}

		if(cnt_up == 0 && cnt_upp > 0 ) {$EXECUTE upp ;$EXECUTE uu;}
		if(cnt_up == 0 && cnt_upn > 0 ) {$EXECUTE upn ;$EXECUTE uu;}
		if(cnt_up == 0 && cnt_upna > 0 ) {$EXECUTE up1 ;}
		
		if(cnt_up > 0 || cnt_upc > 0 )
		{	
			$EXECUTE del_con;

			char *content_vars[4] = {u_ncontent_tmp1, u_ncontent_tmp2, u_ncontent_tmp3, u_ncontent_tmp4};
			const char *delimiter_end = "#END#";
			const char newline = '\n';
			char *pos;	

			ppp = 0;
	
			for (i = 0; i < 4; i++)
			{
				temp_content[0] = '\0';
				strcpy(temp_content, content_vars[i]); 
				
				printf("i[%d] strlen(temp_content)[%d]\n", i, strlen(temp_content));
				if (i > 0 && (strlen(temp_content) == 0 || strcmp(temp_content, " ") == 0)) {
					continue; /* �p�G���e���ũΪťաA���L�B�z�A�ȭ�2.3.4 */
				}
								
				while ((pos = strstr(temp_content, delimiter_end)) != NULL) {
					/* �N #END# ���Ĥ@�Ӧr�Ŵ����� \n */
					*pos = newline;
					
					/* �N�Ѿl���r��V�e���ʡA�л\�� #END# */
					memmove(pos + 1, pos + strlen(delimiter_end), strlen(pos + strlen(delimiter_end)) + 1);
				}

				int len = strlen(temp_content);
				if (len > 0 && temp_content[len - 1] == '\n') {
					temp_content[len - 1] = '\0';
				}

				ptr = strtok(temp_content, "\n"); /* �ھڴ���Ť��� */
				while (ptr)
				{
					ppp++;
				    /* ��l���ܼ� */
				    u_ncontent2[0] = '\0';
				    u_ncontent2_1[0] = '\0';
				    u_ncontent2_2[0] = '\0';
				    
				    /* �h�������ťզr�� */
				    strcpy(u_ncontent2,ptr);
					strcpy(u_ncontent2,rtrim(u_ncontent2));
					sprintf_s(u_ncontent2, sizeof u_ncontent2, "%s", ptr);

				    printf("ptr[%s] ppp[%d]\n", u_ncontent2, ppp);
				
				    /* �P�_�Ŧr�Ŧ걡�p */
				    if (strlen(u_ncontent2) == 0)
				    {
				        /* �p�G���šA�N u_ncontent2_1 �M u_ncontent2_2 �]����@�Ů� */
				        strcpy(u_ncontent2_1, " ");
				        strcpy(u_ncontent2_2, " ");
				    }
				    else
				    {
				    	/* �C��Ĥ@�X������X */
				        /* ���� u_ncontent2�A�Ĥ@�Ӧr�ŵ� u_ncontent2_1�A��l������ u_ncontent2_2 */
				        u_ncontent2_1[0] = u_ncontent2[0];  /* ���o���r�� */
				        u_ncontent2_1[1] = '\0';            /* �T�O������ */
				        strncpy(u_ncontent2_2, u_ncontent2 + 1, sizeof(u_ncontent2_2) - 1);  /* ���᭱���r�� */
				    }
				    printf("u_ncontent2_1[%s], u_ncontent2_2[%s] \n", u_ncontent2_1, u_ncontent2_2);

				    sprintf_s(stmt_insert_content, sizeof stmt_insert_content, "INSERT INTO ca_prov_content "
				                                                               "(iprovision, drate_ym, iclass, dbegin, iarticle, icontent, fcont, ncontent, icreate, dcreate, iupdate, dupdate) "
				                                                               "VALUES ('%s', '%s', '%s', '%s', '%s', %d, '%s', '%s', '%s', '%s', '%s', current)",
				                                                               u_iprovision, u_drate_ym, u_iclass, u_dbegin, u_iarticle, ppp, u_ncontent2_1, u_ncontent2_2, cur_icreate, cur_dcreate, userid);
				    printf("stmt_insert_content[%s] \n", stmt_insert_content);
				    $PREPARE upd_insert_content FROM $stmt_insert_content;
				    $EXECUTE upd_insert_content;
				    
				    /* �~��B�z�U�@�� */
				    ptr = strtok(NULL, "\n");
				}
			}
		}

		cm_buf_init(ReplyBuf);
		cm_buf_put("%l",M_CM_OK);
		tmp_len = cm_buf_len(ReplyBuf);
		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
		{
			$WHENEVER SQLERROR CONTINUE;
			$ROLLBACK WORK;
			return apiRC;
		}
		$WHENEVER SQLERROR GOTO errexit;
		$COMMIT WORK;
		return api_OKComplete;
	}
	else
	{
		MsgCode = M_CM_WRONG_OPTION;
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		if(SQLCODE != 0) MsgCode = SQLCODE;
		if(exitsub(reply,MsgCode) == True)
			return MsgCode;
		else
			return apiRC;
	}
	
errexit:
    printf(" sqlerrm = %s\n",sqlca.sqlerrm);
    $WHENEVER SQLERROR CONTINUE;
    MsgCode = SQLCODE;
    $ROLLBACK WORK;
    if (SQLCODE != 0) MsgCode = SQLCODE;
    return exitsub(reply,MsgCode) ? MsgCode : apiRC; 
}

long car162_insert_new_rate(reply)
serverReply reply;
{
	$char DBName[5],DBName1[5];
	$char LsBuffer0[1024],LsBuffer1[1024],LsBuffer2[1024],sFullName[20];
	$char sFullName_sys[20];
	$char old_drate_ym[5],new_drate_ym[5],userid[11];
	$int  cnt_pro = 0;
	int   LiBufLen;
	
	cm_buf_get("%s",DBName);
	cm_buf_get("%s %s %s ",old_drate_ym,new_drate_ym,userid);
	
	strcpy(old_drate_ym,trim(old_drate_ym));
	strcpy(new_drate_ym,trim(new_drate_ym));
	strcpy(userid,trim(userid));
	
	if (db_select(DBName) == False)
	return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
	
	$WHENEVER SQLERROR GOTO errexit;
	$BEGIN WORK;
	
	sprintf_s(LsBuffer1, sizeof LsBuffer1,"INSERT INTO ca_provision "
	                                      "SELECT iprovision,'%s',iclass,dbegin,iarticle,dend,dexpire,fcont,narticle,'%s',CURRENT,'%s',current "
	                                      "  FROM ca_provision "
	                                      " WHERE iprovision IN (SELECT UNIQUE iprovision FROM ca_provision WHERE drate_ym = '%s' ) "
	                                      "   AND drate_ym = '%s';",new_drate_ym,userid,userid,old_drate_ym,old_drate_ym);
	printf("in_rate1[%s]\n\n",LsBuffer1);
	$PREPARE in_rate1 FROM $LsBuffer1;
	$EXECUTE in_rate1;
	
	sprintf_s(LsBuffer2, sizeof LsBuffer2,"INSERT INTO ca_prov_content "
	                                      "SELECT iprovision,'%s',iclass,dbegin,iarticle,icontent,fcont,ncontent,'%s',CURRENT,'%s',current "
	                                      "  FROM ca_prov_content "
	                                      " WHERE iprovision IN (SELECT UNIQUE iprovision FROM ca_provision WHERE drate_ym = '%s') "
	                                      "   AND drate_ym = '%s';",new_drate_ym,userid,userid,old_drate_ym,old_drate_ym);
	printf("in_rate2[%s]\n\n",LsBuffer2);
	$PREPARE in_rate2 FROM $LsBuffer2;
	$EXECUTE in_rate2;

	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	LiBufLen = cm_buf_len(ReplyBuf);

	if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
	{
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		return apiRC;
	}
	
	$COMMIT WORK;
	return api_OKComplete;

errexit:
	printf(" sqlerrm = %s\n",sqlca.sqlerrm);
	$WHENEVER SQLERROR CONTINUE;
	MsgCode = SQLCODE;
	$ROLLBACK WORK;
	if (SQLCODE != 0) MsgCode = SQLCODE;
	return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}