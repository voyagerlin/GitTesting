/*----------------------------------------------------------------------
 *  program id   : ca_gl_rbc.ec
 *  program name : ���I�鵲�����JRBC�����
 *  written date : 08/06/2002
 *  modify  date :
 *  author       : jessie
 *--------------------------------------------------------------------*/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "cmnmsgs.h"
$include sqlca;
$include sqltypes;
$include datetime.h;
#include "sql.h"
#include "is_def.h"

$static char kacct[8][6]=
                 {"2304",         /*�j���I���v���*/
                  "4100",         /*�O�O���J*/
                  "41001",        /*�«O�O*/
                  "4101",         /*�O�O����*/
                  "5101",         /*��������*/
                  "5102",         /*�N�z�O��X*/
                  "5103",         /*����O��X*/
                  "6709"};        /*�~�ȶO��*/
$double mcomp,mprem,mpure,mdisc,mcomm,magent,mdeal,mbuss;
$char kprod[3],kclsfyitem[5],kreserve[6];
$char real_insure_kind[11];
$char ipolicy1[21],ipolicy2[21],iendorse[21],kclsfyitem[5];
$char kcracc_tp[3],kdctype[2],kvchr_tp[3],edeal[41],kacctitem[5];
$char iYYY[5],iMMM[3],iDDD[3],now_time[27],temp_time[27];
$char tmp_tbl1[300],tmp_tbl2[300],tbl1_name[19],tbl2_name[19];
$char tmp_tbl3[300], tbl3_name[19];
$char tmp_tbl31[300]; 
$char tmp_type[2];
$int ply_count, real_count, real_count_policy, real_count_endorse;
$char s_count[9];
$char mcommit_type[2], magent_type[2], mprem_type[2];
$double mcommit_nt,magent_nt,mdeal_nt,tmp_nt;
$double de_mprem_nt, de_mcompensation_nt, de_mdiscount_nt;
$double de_mcommit_nt,de_magent_nt, de_mdeal_nt;
$double mdeal_nt1, mdeal_nt2, mdeal_nt3;
$double mmagent_ntA,mmdeal_ntA,mmagent_ntB,mmdeal_ntB;
$double mprem_nt,mcompensation_nt,mdiscount_nt;
$double mmprem_nt,mmcompensation_nt,mmdiscount_nt;
$double totDB_nt,totCR_nt;
$long rtn,MsgCode;
$int kserial,itemp=0;
$int iYY,iMM,iDD;
struct tm *curtime;
time_t bintime;
$char  mark[41];
$int  fcount=0;
/*--------------------------------------------------------------------*/
long ca_gl_rbc(VDBName, Vdplyend, Vmode, Sys_source) 
$char *VDBName;
$char *Vdplyend;
$char *Vmode;
$char *Sys_source;
{
   if (db_select(VDBName) == False) 
      return M_CM_DB_NOTOPEN;
   strcpy(sys_source,Sys_source);
   strcpy(dplyend,cm_to_infdate(Vdplyend));

   $WHENEVER SQLERROR GOTO ErrExit;

   temp_time[0]='\0';
   time(&bintime);
   curtime=localtime(&bintime);
   strncpy(now_time,asctime(curtime),24);
   now_time[24]='\0';

   for (itemp=0;itemp<20;itemp++)
      if (now_time[itemp]>='0' && now_time[itemp]<='9')
         strncat(temp_time,now_time+itemp,1);

   strncpy(tbl1_name,sys_source,1);
   tbl1_name[1]='\0';
   strcat(tbl1_name,"A");
   strcat(tbl1_name,temp_time);
   strncpy(tbl2_name,sys_source,1);
   tbl2_name[1]='\0';
   strcat(tbl2_name,"B");
   strcat(tbl2_name,temp_time);

   sprintf(tmp_tbl1,"CREATE TEMP TABLE %s \
          (\
          tmp_insure_type       Char(1), \
          tmp_ftype             Char(1), \
          tmp_isub              Char(2), \ 
          tmp_dplyend           Date, \
          tmp_kprod             Char(2), \
          tmp_kacctitem         Char(5), \
          tmp_kclsfyitem        Char(4), \
          tmp_kreserve          Char(5), \
          tmp_mnt               Decimal(9,0) \
          ) WITH NO LOG",tbl1_name);

   $PREPARE tblA FROM  $tmp_tbl1;
   $EXECUTE tblA;

   sprintf(tmp_tbl3,"INSERT INTO %s VALUES \
          (?,?,?,?,?,?,?,?,?)",tbl1_name);
   $PREPARE tbl3 FROM  $tmp_tbl3;

   if (Vmode[0]=='1') /* mode = 1 �O�� */
   {
      /*----�@�~���j�����---------------*/
      $DECLARE c_motor_1 CURSOR FOR
        SELECT b.iproduct[4,5],kclsfyitem,kreserve,
               sum(mcompensation),sum(mins_premium),
               sum(mpure_prem),sum(mcommission),
               sum(mbusiness)
          FROM ply_relation a,ply_ins_type b,v_product_code c
         WHERE dpolicy = $dplyend
           AND fcard_class = '1'
           AND a.ipolicy[6]='M'
           AND qply_period <= 12
           AND a.ipolicy = b.ipolicy
           AND b.iporduct = c.iproduct
           AND c.icode2 = '1';
      $OPEN  c_motor_1;
      while (1)
      {
         $FETCH c_motor_1 INTO $kprod,$kclsfyitem,$kreserve,
                $mcomp,$mprem,$mpure,$mdeal,$mbuss;
         if (SQLCODE == SQLNOTFOUND) break;

         if (mcomp!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[0],$kclsfyitem,$kreserve,
                             $mcomp;
         if (mprem!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[1],$kclsfyitem,$kreserve,
                             $mprem;
         if (mpure!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[2],$kclsfyitem,$kreserve,
                             $mpure;
         if (mdeal!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[6],$kclsfyitem,$kreserve,
                             $mdeal;
         if (mbuss!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[7],$kclsfyitem,$kreserve,
                             $mbuss;
      }
      $CLOSE c_motor_1;
      $FREE  c_motor_1;

      /*----�G�~���j�����---------------*/
      $DECLARE c_motor_2 CURSOR FOR
        SELECT b.iproduct[4,5],kclsfyitem,kreserve,
               sum(mcompensation),sum(mins_premium),
               sum(mpure_prem),sum(mcommission),
               sum(mbusiness)
          FROM ply_relation a,ply_ins_type b,v_product_code c
         WHERE dpolicy = $dplyend
           AND fcard_class = '1'
           AND a.ipolicy[6]='M'
           AND qply_period > 12
           AND a.ipolicy = b.ipolicy
           AND b.iporduct = c.iproduct
           AND c.icode2 = '2';
      $OPEN  c_motor_2;
      while (1)
      {
         $FETCH c_motor_2 INTO $kprod,$kclsfyitem,$kreserve,
                $mcomp,$mprem,$mpure,$mdeal,$mbuss;
         if (SQLCODE == SQLNOTFOUND) break;

         if (mcomp!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[0],$kclsfyitem,$kreserve,
                             $mcomp;
         if (mprem!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[1],$kclsfyitem,$kreserve,
                             $mprem;
         if (mpure!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[2],$kclsfyitem,$kreserve,
                             $mpure;
         if (mdeal!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[6],$kclsfyitem,$kreserve,
                             $mdeal;
         if (mbuss!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[7],$kclsfyitem,$kreserve,
                             $mbuss;
      }
      $CLOSE c_motor_2;
      $FREE  c_motor_2;

      /*----�j��T��---------------*/
      $DECLARE c_car CURSOR FOR
        SELECT b.iproduct[4,5],kclsfyitem,kreserve,
               sum(mcompensation),sum(mins_premium),
               sum(mpure_prem),sum(mcommission),
               sum(mbusiness)
          FROM ply_relation a,ply_ins_type b,v_product_code c
         WHERE dpolicy = $dplyend
           AND fcard_class = '1'
           AND a.ipolicy[6]='C'
           AND a.ipolicy = b.ipolicy
           AND b.iporduct = c.iproduct;
      $OPEN  c_car;
      while (1)
      {
         $FETCH c_car INTO $kprod,$kclsfyitem,$kreserve,
                $mcomp,$mprem,$mpure,$mdeal,$mbuss;
         if (SQLCODE == SQLNOTFOUND) break;

         if (mcomp!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[0],$kclsfyitem,$kreserve,
                             $mcomp;
         if (mprem!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[1],$kclsfyitem,$kreserve,
                             $mprem;
         if (mpure!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[2],$kclsfyitem,$kreserve,
                             $mpure;
         if (mdeal!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[6],$kclsfyitem,$kreserve,
                             $mdeal;
         if (mbuss!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[7],$kclsfyitem,$kreserve,
                             $mbuss;
      }
      $CLOSE c_car;
      $FREE  c_car;

      /*----���N�T��---------------*/
      $DECLARE v_car CURSOR FOR
        SELECT b.iproduct[4,5],kclsfyitem,kreserve,
               sum(mins_premium),sum(mpure_prem),
               sum(mcommission),sum(magent)
          FROM ply_relation a,ply_ins_type b,v_product_code c
         WHERE dpolicy = $dplyend
           AND fcard_class = '2'
           AND a.ipolicy = b.ipolicy
           AND b.iporduct = c.iproduct;
      $OPEN  v_car;
      while (1)
      {
         $FETCH v_car INTO $kprod,$kclsfyitem,$kreserve,
                $mprem,$mpure,$mcomm,$magent;
         if (SQLCODE == SQLNOTFOUND) break;

         if (mprem!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[1],$kclsfyitem,$kreserve,
                             $mprem;
         if (mpure!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[2],$kclsfyitem,$kreserve,
                             $mpure;
         if (mcomm!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[4],$kclsfyitem,$kreserve,
                             $mcomm;
         if (magent!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[5],$kclsfyitem,$kreserve,
                             $magent;
      }
      $CLOSE v_car;
      $FREE  v_car;
   }
   else { /* mode = 2 ��� */
      /*----�@�~���j�����---------------*/
      $DECLARE c_motor_1 CURSOR FOR
        SELECT b.iproduct[4,5],kclsfyitem,kreserve,
               sum(mcompensation),sum(mins_premium),
               sum(mpure_prem),sum(mcommission),
               sum(mbusiness)
          FROM edr_relation a,edr_ins_type b,v_product_code c
         WHERE dendorse = $dplyend
           AND fcard_class = '1'
           AND a.ipolicy[6]='M'
           AND qply_period <= 12
           AND a.iendorse= b.iendorse
           AND b.iporduct = c.iproduct
           AND c.icode2 = '1';
      $OPEN  c_motor_1;
      while (1)
      {
         $FETCH c_motor_1 INTO $kprod,$kclsfyitem,$kreserve,
                $mcomp,$mprem,$mpure,$mdeal,$mbuss;
         if (SQLCODE == SQLNOTFOUND) break;

         if (mcomp!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[0],$kclsfyitem,$kreserve,
                             $mcomp;
         if (mprem!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[1],$kclsfyitem,$kreserve,
                             $mprem;
         if (mpure!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[2],$kclsfyitem,$kreserve,
                             $mpure;
         if (mdeal!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[6],$kclsfyitem,$kreserve,
                             $mdeal;
         if (mbuss!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[7],$kclsfyitem,$kreserve,
                             $mbuss;
      }
      $CLOSE c_motor_1;
      $FREE  c_motor_1;

      /*----�G�~���j�����---------------*/
      $DECLARE c_motor_2 CURSOR FOR
        SELECT b.iproduct[4,5],kclsfyitem,kreserve,
               sum(mcompensation),sum(mins_premium),
               sum(mpure_prem),sum(mcommission),
               sum(mbusiness)
          FROM ply_relation a,ply_ins_type b,v_product_code c
         WHERE dpolicy = $dplyend
           AND fcard_class = '1'
           AND a.ipolicy[6]='M'
           AND qply_period > 12
           AND a.ipolicy = b.ipolicy
           AND b.iporduct = c.iproduct
           AND c.icode2 = '2';
      $OPEN  c_motor_2;
      while (1)
      {
         $FETCH c_motor_2 INTO $kprod,$kclsfyitem,$kreserve,
                $mcomp,$mprem,$mpure,$mdeal,$mbuss;
         if (SQLCODE == SQLNOTFOUND) break;

         if (mcomp!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[0],$kclsfyitem,$kreserve,
                             $mcomp;
         if (mprem!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[1],$kclsfyitem,$kreserve,
                             $mprem;
         if (mpure!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[2],$kclsfyitem,$kreserve,
                             $mpure;
         if (mdeal!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[6],$kclsfyitem,$kreserve,
                             $mdeal;
         if (mbuss!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[7],$kclsfyitem,$kreserve,
                             $mbuss;
      }
      $CLOSE c_motor_2;
      $FREE  c_motor_2;

      /*----�j��T��---------------*/
      $DECLARE c_car CURSOR FOR
        SELECT b.iproduct[4,5],kclsfyitem,kreserve,
               sum(mcompensation),sum(mins_premium),
               sum(mpure_prem),sum(mcommission),
               sum(mbusiness)
          FROM ply_relation a,ply_ins_type b,v_product_code c
         WHERE dpolicy = $dplyend
           AND fcard_class = '1'
           AND a.ipolicy[6]='C'
           AND a.ipolicy = b.ipolicy
           AND b.iporduct = c.iproduct;
      $OPEN  c_car;
      while (1)
      {
         $FETCH c_car INTO $kprod,$kclsfyitem,$kreserve,
                $mcomp,$mprem,$mpure,$mdeal,$mbuss;
         if (SQLCODE == SQLNOTFOUND) break;

         if (mcomp!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[0],$kclsfyitem,$kreserve,
                             $mcomp;
         if (mprem!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[1],$kclsfyitem,$kreserve,
                             $mprem;
         if (mpure!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[2],$kclsfyitem,$kreserve,
                             $mpure;
         if (mdeal!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[6],$kclsfyitem,$kreserve,
                             $mdeal;
         if (mbuss!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[7],$kclsfyitem,$kreserve,
                             $mbuss;
      }
      $CLOSE c_car;
      $FREE  c_car;

      /*----���N�T��---------------*/
      $DECLARE v_car CURSOR FOR
        SELECT b.iproduct[4,5],kclsfyitem,kreserve,
               sum(mins_premium),sum(mpure_prem),
               sum(mcommission),sum(magent)
          FROM ply_relation a,ply_ins_type b,v_product_code c
         WHERE dpolicy = $dplyend
           AND fcard_class = '2'
           AND a.ipolicy = b.ipolicy
           AND b.iporduct = c.iproduct;
      $OPEN  v_car;
      while (1)
      {
         $FETCH v_car INTO $kprod,$kclsfyitem,$kreserve,
                $mprem,$mpure,$mcomm,$magent;
         if (SQLCODE == SQLNOTFOUND) break;

         if (mprem!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[1],$kclsfyitem,$kreserve,
                             $mprem;
         if (mpure!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[2],$kclsfyitem,$kreserve,
                             $mpure;
         if (mcomm!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[4],$kclsfyitem,$kreserve,
                             $mcomm;
         if (magent!=0)
         $EXECUTE tbl3 USING $Sys_source,$Vmode,$VDBName,$dplyend,
                             $kprod,$acct[5],$kclsfyitem,$kreserve,
                             $magent;
      }
      $CLOSE v_car;
      $FREE  v_car;
   }

   return api_OKComplete;

ErrExit:
   printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",
                SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
   $WHENEVER SQLERROR CONTINUE;
   MsgCode = SQLCODE;
   return MsgCode;
}
