/**********************************************************************/
/*   program id   : ca743q01s.ec                                      */
/*   program name : ������O���z��(E�O������)                         */
/*   date written : 2022/07/20 by 041090                              */
/*   files        :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "carmsgs.h"
#include "cmnmsgs.h"
#include "car_common.h"
#include <math.h>
#include "ISvar.h"

$char ftype[2],dbgn_tmp[11],dend_tmp[11];
$char dbgn[11],dend[11];
$char dbgn_trans1[16],dend_trans1[16],dbgn_trans[20],dend_trans[20];

int   count_db,k; 
char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];

DBinfo *list;

char  sApHome[30];
int   rtncode,rc;
char  filename[30];
FILE  *fp;
char  file_catalog[200];
$char filename1[200];
char  Message[1024];

main(argc, argv)
int argc;
char **argv;
{
 int rc;

	batchinit();
	strcpy(DBName,      isNULLstr(argv[1]));
	strcpy(userid,      isNULLstr(argv[2]));
	strcpy(ftype,       isNULLstr(argv[3]));
	strcpy(dbgn_tmp,    isNULLstr(argv[4]));
	strcpy(dend_tmp,    isNULLstr(argv[5]));
	strcpy(outputf,     isNULLstr(argv[6]));
	
	strcpy(dbgn,cm_to_infdate(dbgn_tmp));
	strcpy(dend,cm_to_infdate(dend_tmp));
	
	rc = car743_get_db();
	if (rc != M_CM_OK)
		return rc;

	rc = car743_prepare_data();
	if (rc != M_CM_OK)
		return rc;

	rc = car743_build();
	if (rc != M_CM_OK) 
		return rc;
		
	strcpy(Message,  "\n�Цܦ@�θ귽[N]/�d��[B]/�ɮפU���@�~[cmn202]�U���ɮ�!\n");
	EWRITE(userid,M_CM_OK,Message);

	printf("END PROGRAM\n");
	return SUCCESS;
}

long car743_get_db()
{
	$whenever sqlerror goto errexit;

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car743_prepare_data()
{
	$char stmt[4096],stmp1[128];
	$char stmp_cont[1024];
	
	$WHENEVER SQLERROR GOTO errexit;
	printf("IN\n");

	if (db_select(DBName) == FALSE)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return FAIL;
	}

	$CREATE TEMP TABLE car743(                                                    
	 icompany       varchar(10)   default '217', /*01 �O�I���q�N�X(217)             */
	 iproduct       varchar(20)   not null,      /*02 �ӫ~�N�X                      */
	 iroute_accept  varchar(20)   not null,      /*03 ���z�s��                      */
	 iply_last      varchar(30)   default ' ',   /*04 �e�O�渹                      */
	 fauto          char(1)       default 'N',   /*05 ���w��O                      */
	 dins_bgn       char(8)       not null,      /*06 �O��_��                      */
	 dins_end       char(8)       not null,      /*07 �O����                      */
	 napplicant     varchar(100)  not null,      /*08 �n�O�H�m�W/���               */
	 iapplicant     varchar(20)   not null,      /*09 �n�O�HID/�Τ@�s��             */
	 nassured       varchar(100)  not null,      /*10 �Q�O�H�m�W/���               */
	 iassured       varchar(20)   not null,      /*11 �Q�O�HID/�Τ@�s��             */
	 ibranch        char(7)       not null,      /*12 ����N�X                      */
	 isales         char(10)      not null,      /*13 �O�I�~�ȭ��N�X                */
	 mpremium       decimal(14,4) default 0 ,    /*14 �O�I�O                        */
	 mdiscount      decimal(14,4) default 0 ,    /*15 �馩���B                      */
	 pcomm          decimal(14,4) default 0 ,    /*16 �����v                        */
	 mcommission    decimal(14,4) default 0 ,    /*17 ����(����O)                  */
	 mdeal          decimal(14,4) default 0 ,    /*18 �A�ȶO                        */
	 nremark        varchar(50)   default ' ',   /*19 ���O                          */
	 Introduction   char(10)      default ' ',   /*20 ���ˤH                        */
	 ipay_sno       varchar(20)   default ' ',   /*21 �P�b�s��                      */
	 mpay           decimal(14,0) default 0  ,   /*22 ú�O���B                      */
	 iproject       varchar(10)   default ' ',   /*23 �M�ץN��                      */
	 icar_tag       varchar(30)   default ' ',   /*24 ����(���I��)                  */
	 nrmk           char(2)       default 'N',   /*25 �O�_��ĳ����                  */
	 nrmk_pcom      varchar(100)  default ' ',   /*26 ĳ����]                      */
	 iply_end       char(6)       default ' ',   /*27 ��O�������                */
	 mcover         decimal(14,0) default 0  ,   /*28 �O�I���B                      */
	 pay_method     char(1)       default 'O' ,  /*29 ú�O�覡                      */
	 zip            char(5)       default ' ' ,  /*30 �l���ϸ�(�n�O�H)              */
	 naddress       varchar(120)  default ' ' ,  /*31 �q�T�a�}(�n�O�H)              */
	 ntel1          varchar(20)   default ' ' ,  /*32 �p���q��(�n�O�H)              */
	 ijob           char(1)       default ' ' ,  /*33 ¾�~���O                      */
	 mchg_year      char(3)       default ' ' ,  /*34 ������[�򥻦a�_�~��          */
	 idetent_bank   char(7)       default ' ' ,  /*35 ����w                      */
	 iload          varchar(30)   default ' ' ,  /*36 ��ڱb��                      */
	 ibank          varchar(30)   default ' ' ,  /*37 ���ڱb��                      */
	 iconst_levela  char(2)       default ' ' ,  /*38 �`�Ӽh                        */
	 iconst_typea   char(2)       default ' ' ,  /*39 �ت��c�y                      */
	 iconst_roofa   char(2)       default ' ' ,  /*40 �ت��γ�                      */
	 const_size     char(7)       default ' ' ,  /*41 �ؿv���n                      */
	 iconst_yr      char(4)       default ' ' ,  /*42 �ؿv�����~��                  */
	 apropertya_1   varchar(120)  default ' ' ,  /*43 �ؿv�a�}                      */
	 iconst_classa  char(2)       default ' ' ,  /*44 �ت�����                      */
	 ipolicy_kind   char(2)       default '02'   /*45 ��O���A 01�G�۫O�� 02�G�@���*/ 
	) with no log; 

	printf("ftype[%s] \n",ftype[0]);
	if(ftype[0] == '1')
	{
		
		strcpy(dbgn_trans1,cm_from_infdate_100(dbgn));     /* CYY/MM/DD */
    	strcat(dbgn_trans1,"/00:00");                      /* CYY/MM/DD/hh:mm */
    	strcpy(dbgn_trans,cm_sysd_edatetime(dbgn_trans1)); /* YYYY-MM-DD hh:mm */
    	strcat(dbgn_trans,":00");                          /* YYYY-MM-DD hh:mm:ss */
		printf("dbgn[%s],dbgn_trans1[%s],dbgn_trans[%s] \n",dbgn,dbgn_trans1,dbgn_trans);
		
		strcpy(dend_trans1,cm_from_infdate_100(dend));     /* CYY/MM/DD */
    	strcat(dend_trans1,"/23:59");                      /* CYY/MM/DD/hh:mm */
    	strcpy(dend_trans,cm_sysd_edatetime(dend_trans1)); /* YYYY-MM-DD hh:mm */
    	strcat(dend_trans,":59");                          /* YYYY-MM-DD hh:mm:ss */
    	printf("dend[%s],dend_trans1[%s],dend_trans[%s] \n",dend,dend_trans1,dend_trans);

		sprintf(stmp1," a.dcreate BETWEEN '%s' AND '%s' ",dbgn_trans,dend_trans);
	}
	else 
	{
		sprintf(stmp1," a.dins_bgn BETWEEN '%s' AND '%s' ",dbgn,dend);
	}
	printf("stmp1[%s] \n",stmp1);
	
	/* ����E�O��������� */
	/* �j���I */
	sprintf(stmt,"INSERT INTO car743 \
	                     (iproduct, iroute_accept, iply_last, dins_bgn, dins_end, \
	                      napplicant, iapplicant, nassured, iassured, ibranch, \
	                      isales, mpremium, pcomm, mcommission, mdeal, \
	                      icar_tag, iply_end, mcover, zip, naddress, ntel1) \
	              SELECT NVL((SELECT ncode2 FROM cm_code_data \
	                           WHERE itype = '02'  \
	                             AND icode1 = 'I009' \
	                             AND icode2 = case WHEN b.icar_type IN ('01','02','32','34') THEN \
	                                          case WHEN b.qply_period > 12 THEN 'M92' else 'M91' END \
	                                          else a.iply_last[6,7] END),' '), \
	                     a.iroute_accept,a.iply_last, \
	                     to_char(a.dins_bgn,'%%Y%%m%%d'),to_char(a.dins_end,'%%Y%%m%%d'), \
	                     a.napplicant,a.iapplicant,a.nassured,a.iassured,a.iroute[5,8], \
	                     b.ibig_sales,NVL((SELECT sum(mins_premium) FROM newa00:ca_quotation_ins WHERE iquote = a.iquote),0),0, \
	                     case WHEN b.icar_type in ('01','02','32','34') THEN case WHEN b.qply_period > 12 then 245 else 175 end else 350 end,0, \
	                     NVL(b.itag,' '),to_char(a.dins_bgn,'%%Y%%m'),(SELECT sum(mdamage_cover) FROM newa00:ca_quotation_ins WHERE iquote = a.iquote AND iins_type = '21'), \
	                     NVL(a.aapplicant_zip[1,5],' '),NVL(a.aapplicant,' '), NVL(a.tapplicant_mobile,' ') \
	                FROM newa00:quotation_master a,newa00:ca_quotation b \
	               WHERE a.iquote = b.iquote \
	                 AND a.iins_kind_ply = b.iins_kind_ply \
	                 AND %s \
	                 AND a.iroute[1,4] = 'I009' \
	                 AND a.iins_kind_ply = 'C1' \
	                 AND (a.iply_last <> '' OR ilast_quote matches '*CR*') \
	                 AND a.iroute_accept <> '' ",stmp1);
	printf("stmt[%s] \n",stmt);
	$PREPARE quote_data_C FROM $stmt;
	$EXECUTE quote_data_C;
	
	/* ���N�I(���t�r��) */
	sprintf(stmt,"INSERT INTO car743 \
	                     (iproduct, iroute_accept, iply_last, dins_bgn, dins_end, \
	                      napplicant, iapplicant, nassured, iassured, ibranch, \
	                      isales, mpremium, pcomm, mcommission, mdeal, \
	                      icar_tag, iply_end, mcover, zip, naddress, ntel1) \
	              SELECT NVL((SELECT ncode2 FROM cm_code_data \
	                           WHERE itype = '02'  \
	                             AND icode1 = 'I009' \
	                             AND icode2 = case when b.icar_type in ('01','02','32','34') then \
	                                          case when b.qply_period > 12 then 'V92' else 'V91' end \
	                                          else a.iply_last[6,7] END),' '), \
	                     a.iroute_accept,a.iply_last, \
	                     to_char(a.dins_bgn,'%%Y%%m%%d'),to_char(a.dins_end,'%%Y%%m%%d'), \
	                     a.napplicant,a.iapplicant,a.nassured,a.iassured,a.iroute[5,8], \
	                     b.ibig_sales,NVL((SELECT sum(mins_premium) FROM newa00:ca_quotation_ins WHERE iquote = a.iquote AND iins_type <> '47'),0),18.4, \
	                     round(((SELECT sum(mins_premium) FROM newa00:ca_quotation_ins WHERE iquote = a.iquote AND iins_type <> '47')*18.4/100),0),50, \
	                     NVL(b.itag,' '),to_char(a.dins_bgn,'%%Y%%m'),(SELECT sum(mdamage_cover) FROM newa00:ca_quotation_ins WHERE iquote = a.iquote AND iins_type <> '47'), \
	                     NVL(a.aapplicant_zip[1,5],' '),NVL(a.aapplicant,' '), NVL(a.tapplicant_mobile,' ') \
	                FROM newa00:quotation_master a,newa00:ca_quotation b \
	               WHERE a.iquote = b.iquote \
	                 AND a.iins_kind_ply = b.iins_kind_ply \
	                 AND %s \
	                 AND a.iroute[1,4] = 'I009' \
	                 AND a.iins_kind_ply = 'C2' \
	                 AND (a.iply_last <> '' OR ilast_quote matches '*CR*') \
	                 AND a.iroute_accept <> '' \
	                 AND (SELECT count(*) FROM newa00:ca_quotation_ins WHERE iquote = a.iquote AND iins_type <> '47') > 0",stmp1);
	printf("stmt[%s] \n",stmt);
	$PREPARE quote_data_V1 FROM $stmt;
	$EXECUTE quote_data_V1;
	
	/* ���N�I(�t�r��) */
	sprintf(stmt,"INSERT INTO car743 \
	                     (iproduct, iroute_accept, iply_last, dins_bgn, dins_end, \
	                      napplicant, iapplicant, nassured, iassured, ibranch, \
	                      isales, mpremium, pcomm, mcommission, mdeal, \
	                      icar_tag, iply_end, mcover, zip, naddress, ntel1) \
	              SELECT NVL((SELECT ncode2 FROM cm_code_data \
	                           WHERE itype = '02'  \
	                             AND icode1 = 'I009' \
	                             AND icode2 = case when b.icar_type in ('01','02','32','34') THEN \
	                                          case when b.qply_period > 12 then '472' else '471' END \
	                                          else a.iply_last[6,7] END),' '), \
	                     a.iroute_accept,a.iply_last, \
	                     to_char(a.dins_bgn,'%%Y%%m%%d'),to_char(a.dins_end,'%%Y%%m%%d'), \
	                     a.napplicant,a.iapplicant,a.nassured,a.iassured,a.iroute[5,8], \
	                     b.ibig_sales,NVL((SELECT sum(mins_premium) FROM newa00:ca_quotation_ins WHERE iquote = a.iquote AND iins_type = '47'),0),18.4, \
	                     round(((SELECT sum(mins_premium) FROM newa00:ca_quotation_ins WHERE iquote = a.iquote AND iins_type = '47')*18.4/100),0),0, \
	                     NVL(b.itag,' '),to_char(a.dins_bgn,'%%Y%%m'),(SELECT sum(mdamage_cover) FROM newa00:ca_quotation_ins WHERE iquote = a.iquote AND iins_type = '47'), \
	                     NVL(a.aapplicant_zip[1,5],' '),NVL(a.aapplicant,' '), NVL(a.tapplicant_mobile,' ') \
	                FROM newa00:quotation_master a,newa00:ca_quotation b \
	               WHERE a.iquote = b.iquote \
	                 AND a.iins_kind_ply = b.iins_kind_ply \
	                 AND %s \
	                 AND a.iroute[1,4] = 'I009' \
	                 AND a.iins_kind_ply = 'C2' \
	                 AND (a.iply_last <> '' OR ilast_quote matches '*CR*') \
	                 AND a.iroute_accept <> '' \
	                 AND (SELECT count(*) FROM newa00:ca_quotation_ins WHERE iquote = a.iquote AND iins_type = '47') > 0",stmp1);
	printf("stmt[%s] \n",stmt);
	$PREPARE quote_data_V2 FROM $stmt;
	$EXECUTE quote_data_V2;

	return M_CM_OK;
	
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car743_build()
{
	$int rc;
	$char sfilename[256],stitle[4096],stmt2[20000];
	
	$char    icompany[11],fauto[2],dins_bgn[9],dins_end[9];
	$varchar iproduct[21],iroute_accept[21],iply_last[31];
	$varchar napplicant[51],iapplicant[21],nassured[51],iassured[21];
	$char    ibranch[8],isales[11],Introduction[11],iproject[11];
	$double  mprem,mdis,pcomm,mcomm,mdeal,mpay,mcover;
	$varchar nremark[51],ipay_sno[21],icar_tag[31],iload[31],ibank[31];
	$char    nrmk[2],iply_end[7],pay_method[2],zip[6],ijob[2];
	$varchar nrmk_pcom[101],naddress[101],ntel[21],apropertya_1[121];
	$char    mchg_year[4],idetent_bank[8],iconst_levela[3];
	$char    iconst_typea[3],iconst_roofa[3];
	$char    iconst_yr[5],iconst_classa[3],const_size[8];
	
	/* *** Declare change double �� char *** */
	$char    sMprem[15],sMdis[15],sPcomm[15],sMcomm[15],sMdeal[15];
	$char    sMpay[15],sPcomm_dis[15],sMcover[15];
	
	/* *** Declare ftp variables *** */
	$int     iQorder; 
	$varchar sFlieName1[41],sFlieName[41],sNow1[31],sFile_app[81];
	$char    Today[9],yyyy[5],mm[3],dd[3],sOrder[4];
	
	$char    ipolicy_kind[3];
	
	$varchar cmd_stmt[1024];

	$WHENEVER SQLERROR GOTO errexit;
	
	rc = getApHome(sApHome);
	if (rc < 0) 
	{
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
		return rc;
	}
	
	/*�ɦW�ǳ�*/
    strcpy(sNow1, cm_get_sysd());
    strcpy(yyyy,substring(sNow1,1,4));
    strcpy(mm,substring(sNow1,6,2));
    strcpy(dd,substring(sNow1,9,2));
    sprintf(sFlieName,"217RO%s%s%s",yyyy,mm,dd);
 
    /*�j�M�̤j���X*/ 
    $SELECT NVL(max(qorder),0) +1 INTO $iQorder
       FROM sa_route_trans
      WHERE iroute = 'I009'
        AND icode[1,13] = $sFlieName
        AND date(dtran) = today;

    sprintf(sOrder,"%03d",iQorder);
    sprintf(sFlieName,"%s%s.txt",sFlieName,sOrder);
  
    /* ���ȥ�Ȧs�ɦW�����নunicode */
    sprintf(sFile_app,"%s/rptftp/%s", sApHome, "217ROI009.txt");

    fp = fopen(sFile_app,"w");
 
	$DECLARE cursor_car743 CURSOR FOR 
	  SELECT icompany, iproduct, iroute_accept, iply_last, fauto,
	         dins_bgn, dins_end, napplicant, iapplicant, nassured,
	         iassured, ibranch, isales, sum(mpremium), sum(mdiscount),
	         sum(pcomm), sum(mcommission), sum(mdeal), nremark, 
	         Introduction, ipay_sno, sum(mpay), iproject, icar_tag, 
	         nrmk, nrmk_pcom, iply_end, sum(mcover), 
	         decode(pay_method,' ','E','O','E',pay_method), 
	         zip, naddress, ntel1, ijob, mchg_year, idetent_bank,
	         iload, ibank, iconst_levela, iconst_typea, iconst_roofa,
	         const_size, iconst_yr, apropertya_1, iconst_classa, ipolicy_kind
	    FROM car743
	   GROUP BY 1,2,3,4,5,6,7,8,9,10,11,12,13,19,20,21,23,24,25,26,
	            27,29,30,31,32,33,34,35,36,37,38,39,40,41,42,43,44,45
	  having sum(mpremium) != 0
	   order by 4;
	$OPEN cursor_car743;
	for (;;)
	{
		$FETCH cursor_car743 INTO $icompany, $iproduct, $iroute_accept, 
		                            $iply_last, $fauto, $dins_bgn, 
		                            $dins_end, $napplicant, $iapplicant,
		                            $nassured, $iassured, $ibranch, 
		                            $isales, $mprem, $mdis, $pcomm, 
		                            $mcomm, $mdeal, $nremark, 
		                            $Introduction, $ipay_sno, $mpay,
		                            $iproject, $icar_tag, $nrmk, 
		                            $nrmk_pcom, $iply_end, $mcover,
		                            $pay_method, $zip, $naddress, $ntel, 
		                            $ijob, $mchg_year, $idetent_bank, 
		                            $iload, $ibank, $iconst_levela,
		                            $iconst_typea, $iconst_roofa, 
		                            $const_size, $iconst_yr,
		                            $apropertya_1, $iconst_classa, $ipolicy_kind;

		if (SQLCODE == SQLNOTFOUND) break;

		sprintf(sMprem,"%10.2f",mprem);
		sprintf(sMdis,"%10.2f",mdis);
		sprintf(sPcomm,"%10.2f",pcomm);
		sprintf(sMcomm,"%10.2f",mcomm);
		sprintf(sMdeal,"%10.2f",mdeal);
		sprintf(sMpay,"%10.2f",mpay);
		sprintf(sMcover,"%10.2f",mcover);

		strcpy(iproduct,     trim(iproduct));
		strcpy(iply_last,    trim(iply_last));
		strcpy(ibranch,      trim(ibranch));
		strcpy(isales,       trim(isales));
		strcpy(ibank,        trim(ibank));
		strcpy(iload,        trim(iload));  
		strcpy(napplicant,   trim(napplicant));
		strcpy(iapplicant,   trim(iapplicant));
		strcpy(nassured,     trim(nassured));
		strcpy(sMprem,       trim(sMprem));
		strcpy(sMpay,        trim(sMpay));
		strcpy(sMcomm,       trim(sMcomm));
		strcpy(sMdeal,       trim(sMdeal));
		strcpy(icar_tag,     trim(icar_tag)); 
		strcpy(iproject,     trim(iproject));
		strcpy(naddress,     trim(naddress));
		strcpy(apropertya_1, trim(apropertya_1));
     
		fprintf(fp,"%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s	%s\n",
		icompany,iproduct,iroute_accept,iply_last,fauto,
		dins_bgn,dins_end,napplicant,iapplicant, nassured, 
		iassured, ibranch,isales,sMprem,sMdis,sPcomm,sMcomm,
		sMdeal,nremark,Introduction,ipay_sno,sMpay,iproject,
		icar_tag,nrmk,nrmk_pcom,iply_end,sMcover,
		pay_method,zip,naddress,ntel,ijob,mchg_year,
		idetent_bank,iload,ibank,iconst_levela,iconst_typea,
		iconst_roofa,const_size,iconst_yr,apropertya_1,
		iconst_classa,ipolicy_kind);
	}
	$CLOSE cursor_car743;
	$FREE  cursor_car743;
	fclose(fp);
	
	/* cmd��s�Xunicode */
	sprintf(cmd_stmt,"iconv -f Big5 -t UTF-8 %s > %s/rptftp/%s",sFile_app, sApHome, sFlieName);
	printf("cmd_stmt=[%s]\n", cmd_stmt);
	rc = system(cmd_stmt);
	/*if ( rc != M_CM_OK)
	{
		printf("�ഫ�s�X����\n");
		EWRITE(userid, rc, "�ഫ�s�X����!");
		return rc; 
	}*/
		
	$INSERT INTO rptftplist (nuserid,    ipgid,    noutfile,   dcreate)
	                 VALUES ($userid, 'car743',  $sFlieName,   current);

	$INSERT INTO sa_route_trans 
	 VALUES('I009', $sFlieName, current, $iQorder);
	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}
