/************************************************/
/*                                              */
/*   PROGRAM : ca107m01s.ec by Dennis Chang     */
/*                                              */
/*   DATE    : 1993/09/01                       */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include <decimal.h>
#include <safeclib.h>


long car124(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car124_insert(),car124_single_query(),car124_update_exec();
 long car124_multiple_query();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
           rtncode=car124_insert(reply);
           break;
  case 'Q':
           rtncode=car124_single_query(reply);
           break;
  case 'M':
           rtncode=car124_multiple_query(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car124_update_exec(reply,command,com_len);
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
            return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

/*-----------------------------------------------------------------*/
long car124_insert(reply)
serverReply reply;
{
 $char DBName[5],k_drate[9],drate[12];
 $int  qrecord;  
 $double pfactor;
 dec_t dec_pfactor;
 char  tmp_pfactor[21];
 int tmp_len;
 long MsgCode;
 DBinfo *list;
 int i, j, is_add_fail=0, api_f;
 $char stmt_buf[300];

 cm_buf_get("%s %d %s %s",DBName,&qrecord,tmp_pfactor,k_drate);
 deccvasc( tmp_pfactor, strlen(tmp_pfactor), &dec_pfactor);
 dectodbl( &dec_pfactor, &pfactor);
 strcpy(drate,cm_to_infdate(k_drate));

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
 }

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
 {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
 }

 $BEGIN WORK;
 for(j=0;j<i;j++)
 {
  sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO %s:ca_acc_factor "
         " (qrecord, pfactor, drate) VALUES(?,?,?)" ,list[j].dbname);

  $PREPARE a_id FROM $stmt_buf;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  $EXECUTE a_id USING $qrecord,$pfactor,$drate;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  tmp_len = cm_buf_len(ReplyBuf);
  if( j == i-1 )
     api_f = api_OKComplete;
  else
     api_f = api_OK;

  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    {
     is_add_fail = 2;
     break;
    }  
#ifdef DEBUG 
printf("INSERT %d\n", j+1);
#endif
 } /* for loop */

 if( is_add_fail == 1 ) goto errexit;

 if( is_add_fail == 2 ) 
  {
   $ROLLBACK WORK;
   return apiRC;
  }

 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

 errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
}

/*-----------------------------------------------------------------*/
long car124_single_query(reply)
serverReply reply;
{
 $char DBName[5],k_drate[9],drate[12],k_qrecord[4];
 $int  qrecord;
 $double pfactor = 0.0;
 int tmp_len;

 cm_buf_get("%s %d %s",DBName,&qrecord,k_drate);
 strcpy(drate,cm_to_infdate(k_drate));

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

 $SELECT pfactor
    INTO $pfactor
    FROM ca_acc_factor
   WHERE qrecord=$qrecord and drate=$drate;

 if(SQLCODE==SQLNOTFOUND)
  {
   if(exitsub(reply,M_CA_NACC_FACTOR) == True)
    return M_CA_NACC_FACTOR;
   else
    return apiRC;
  }

 cm_buf_init(ReplyBuf);
 cm_buf_put("%l %d %e %s",M_CM_OK,qrecord,pfactor,k_drate);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}

/*-----------------------------------------------------------------*/
long car124_multiple_query(reply)
serverReply reply;
{
 $char DBName[5],k_drate[9],drate[12];
 $int  key_qrecord,qrecord = 0;
 $long drate_l = 0;
 $double pfactor = 0.0;
 char  key_char_qrecord[4];
 char tmpbuf[4000],strtmp[11];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;
 int flag,date_flag;

 cm_buf_get("%s %s %s",DBName,key_char_qrecord,k_drate);
printf("-----DB[%s] qrecord[%s] drate[%s]\n",DBName,key_char_qrecord,k_drate);
 if(k_drate[0]=='*')
 {      
 	date_flag=0;
 }else{
 	strcpy(drate,cm_to_infdate(k_drate));
        date_flag=1;
 }
printf("-----date_flag[%d] drate[%s]\n",date_flag,drate);


 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
 	if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
 		return M_CM_DB_NOTOPEN;
 	else
 		return apiRC;
 }

 if( key_char_qrecord[0] == '*') {
 	if(date_flag == 1)
 	{
 		flag = 1;
 		$DECLARE q_cur1 CURSOR for
 		  SELECT qrecord,pfactor,drate
 		    INTO $qrecord,$pfactor,$drate_l
 		    FROM ca_acc_factor
 		   WHERE drate = $drate
 		   ORDER BY qrecord,pfactor,drate;
 	}else
 	{
 		flag = 2;
 		$DECLARE q_cur2 CURSOR for
 		  SELECT qrecord,pfactor,drate
 		    INTO $qrecord,$pfactor,$drate_l
 		    FROM ca_acc_factor
 		   ORDER BY qrecord,pfactor,drate;
 	}
 } else {
 	if(date_flag == 1)
 	{
 		key_qrecord= atoi(key_char_qrecord);
 		flag = 3;
 		$DECLARE q_cur3 CURSOR for
 		  SELECT qrecord,pfactor,drate
 		    INTO $qrecord,$pfactor,$drate_l
 		    FROM ca_acc_factor
 		   WHERE qrecord = $key_qrecord and drate = $drate
 		   ORDER BY qrecord,pfactor,drate;
 	}else{
 		key_qrecord= atoi( key_char_qrecord);
 		flag = 4;
 		$DECLARE q_cur4 CURSOR for
 		  SELECT qrecord,pfactor,drate
 		    INTO $qrecord,$pfactor,$drate_l
 		    FROM ca_acc_factor
 		   WHERE qrecord = $key_qrecord
 		   ORDER BY qrecord,pfactor,drate;
 	}
 }

 if( flag == 1)
   $OPEN q_cur1;
 if(flag==2)
   $OPEN q_cur2;
 if(flag==3)
   $OPEN q_cur3;
 if(flag==4) 
   $OPEN q_cur4;

 for(;;)
 {
    if(flag==1)
       $FETCH q_cur1;
    if(flag==2)
       $FETCH q_cur2;
    if(flag==3)
       $FETCH q_cur3;
    if(flag==4)
       $FETCH q_cur4;

    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
    {
    	cm_buf_res_msg();             /* reserve for MsgCode and count */
    	cm_buf_res_count();
    }
    sprintf_s(strtmp, sizeof strtmp, "%.1f",pfactor);
    strcpy(k_drate,cm_cdate_str(drate_l));
    cm_buf_put("%d %s %s", qrecord, strtmp, k_drate);

    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
    {
    	memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
    	repbuf_len += tmp_len;
    	count++;
    }
    else                               /* more than 4K, send to client side */
    {
    	cm_buf_init(ReplyBuf);
    	cm_buf_put_msg(M_CM_OK);
    	cm_buf_put_count(count);
    	
    	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
    	{
    		if( flag == 1)
    			$CLOSE q_cur1;
    		else if( flag == 2)
    			$CLOSE q_cur2;
    		else if( flag == 3)
    			$CLOSE q_cur3;
    		else
    			$CLOSE q_cur4;
    			
    		return apiRC;
    	}
    	else               /* clear ReplyBuf and count to start all over again */
    	{
    		replycnt++;
    		if (replycnt == 10)   /* more than 30K, client cannot display,error */
    		{
    			cm_buf_init(ReplyBuf);
    			cm_buf_put("%l",M_CM_OUT_SPACE);
    			tmp_len = cm_buf_len(ReplyBuf);
    			if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    				return apiRC;
    			
    			return M_CM_OUT_SPACE;
    		}
    		ReplyBuf[0] = '\0';
    		count = 0;
    		cm_buf_init(ReplyBuf);
    		cm_buf_res_msg();           /* reserve for MsgCode and count */
    		cm_buf_res_count();
    		sprintf_s(strtmp, sizeof strtmp, "%.1f",pfactor);
    		strcpy(k_drate,cm_cdate_str(drate_l));
    		if (flag==1 || flag==2)
    		cm_buf_put("%d %s %s", qrecord, strtmp, k_drate);
    		
    		repbuf_len = cm_buf_len(ReplyBuf);
    		count++;
    	}
    }
 } /* for loop */

 if( flag == 1)
    $CLOSE q_cur1;
 if (flag==2)
    $CLOSE q_cur2;
 if(flag==3)
    $CLOSE q_cur3;
 if(flag==4)
    $CLOSE q_cur4;
 
 if (count > 0)   /* break out, at least one record is selected */
 {
 	cm_buf_init(ReplyBuf);
 	cm_buf_put_msg(M_CM_OK);
 	cm_buf_put_count(count);
 	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
 		return apiRC;
 	return api_OKComplete;
 }
 else            /* break out, not any row is found */
 {
 	if(exitsub(reply,M_CA_NACC_FACTOR) == True)
 		return M_CA_NACC_FACTOR;
 	else
 		return apiRC;
 }

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}


/*-----------------------------------------------------------------*/
long car124_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 $char DBName[5],cur_drate[12],drate[12],k_drate[9],k_qrecord[4],m_drate[9];
 $int  qrecord,cur_qrecord ,count;
 $double pfactor, cur_pfactor;
 dec_t dec_pfactor, dec_cur_pfactor;
 char tmp_pfactor[21], tmp_cur_pfactor[21],tmp_qrecord[4];
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len;
 long dummy;
 long MsgCode;
 DBinfo *list;
 int i, j, is_del_fail=0, is_upd_fail=0;
 $char stmt_buf[300];

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
}
 /* compare old record and current record, if the record has not been changed
    since last request, update or delete the record, otherwise return errmsg
    to client side */

 /* get old record info from command buffer */

/*
 raw_len = *(int *) &comm[com_len];
 memcpy(&raw_len,(void *)&command[com_len],sizeof(int));
*/
 memcpy(&raw_len,&comm[com_len],sizeof(int));
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)
  memcpy(raw_ptr,pos,raw_len);
 else
  {
   if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
    return M_CM_NOT_MALLOC;
   else
    return apiRC;
  }
printf("work form here\n");
 cm_buf_init(raw_ptr);          /* get index key from old record */
 cm_buf_get("%l %s %e %s",&dummy,&k_qrecord,&cur_pfactor,k_drate);
 strcpy(cur_drate,cm_to_infdate(k_drate));
 cur_qrecord= atoi(k_qrecord);
 
 printf("is %s\n",k_drate);
 $BEGIN WORK;

 $SELECT pfactor
    INTO $cur_pfactor
    FROM ca_acc_factor
   WHERE qrecord=$cur_qrecord and drate=$cur_drate;

  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */

 if (SQLCODE == SQLNOTFOUND)
  {
   MsgCode = M_CM_NOT_FOUND;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
  }

 cm_buf_init(cur_buf);
 strcpy(m_drate,cm_cdate_str(cur_drate));
 cm_buf_put("%l %d %e %s",dummy,cur_qrecord,cur_pfactor,k_drate);

printf("kkkk\n");
 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
  {
printf("kkkk2\n");
   MsgCode = M_CM_NOT_EQUAL;
   free(raw_ptr);
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
  }

   $WHENEVER SQLERROR GOTO errexit;
 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
     
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf, "DELETE FROM %s:ca_acc_factor WHERE qrecord = ? and drate=?"
		,list[j].dbname); 
    $PREPARE d_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
    $EXECUTE d_id USING $cur_qrecord,$cur_drate;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
#ifdef DEBUG 
printf("Delete %d\n", j+1);
#endif
   }/* for loop */

   if( is_del_fail ) goto errexit;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
  printf("here1\n");
   cm_buf_init(command);
printf("here8\n");
   cm_buf_get("%c %s %s %s %s",&option,DBName,tmp_qrecord,tmp_pfactor,k_drate);
printf("here9\n");
   qrecord=atoi(tmp_qrecord);
   deccvasc( tmp_pfactor, strlen( tmp_pfactor), &dec_pfactor);
   dectodbl( &dec_pfactor, &pfactor);
   strcpy(drate,cm_to_infdate(k_drate));
printf("qrecord[%d]\n",qrecord);        
printf("pfactor[%f]\n",pfactor);        
printf("drate[%s]\n",drate);        
printf("qrecord[%d]\n",cur_qrecord);        
printf("drate[%d]\n",cur_drate);        
   $WHENEVER SQLERROR GOTO errexit;
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf, "UPDATE %s:ca_acc_factor "
       		" SET (qrecord,pfactor,drate) = (?,?,?) WHERE qrecord = ? and drate=?",list[j].dbname);

    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    $EXECUTE u_id USING $qrecord,$pfactor,$drate, $cur_qrecord,$cur_drate;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
printf("here3\n");
    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {
      sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO %s:ca_acc_factor "
			" (qrecord,pfactor,drate) VALUES (?,?,?)",list[j].dbname);

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }
      $EXECUTE ua_id USING $qrecord,$pfactor,$drate;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }
     }
#ifdef DEBUG 
printf("Update %d\n", j+1);
#endif
   } /* for loop */

   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
    return M_CM_WRONG_OPTION;
   else
    return apiRC;
  }

 errexit:
   MsgCode = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if( SQLCODE != 0) MsgCode = SQLCODE;
   if(exitsub(reply,MsgCode) == True)
    return MsgCode;
   else
    return apiRC;
}
