/**********************************************************************/
/*   program id   : ca301p04s.ec                                      */
/*   program name : �۰ʥX��n�O�ѥ��^E-mail�q��(�޲z�H)              */
/*   date written : 2016/05/09                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   shell        : car3014_email                                     */
/*   exec time    : 00:10                                             */
/**********************************************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"
#include "safeclib.h"

char  	outputf[ N_FILE+1];
$char  	userid[11],sDdate[11];
char  	ddate[11];
char	  syy[4],smm[3],sdd[3],sdate[11];

$char	DBName[5];
DBinfo  *list;
    
int     flen,count_db,i;
FILE    *fp;
char    sApHome[30];
$char   fname[60];
$char   filename[121];
$char	ftitle[1024],nsubject[512],nattachment[1025];
	
$char	mmsg[1024];
$char 	tbuf[501];
$char 	mbuf[9000];
$loc_t 	ctxt;

$char	smail[41];
$char	stmt[4096],stmt1[256],stmt2[256];
char	msgbuf[100];

$char	pre_ileader[11],sNleader[11],year2[3];
$char   sIemp[11],sNname[11];
$int 	mail_count,C_count,M_count;
$long	dsys;

$char	itmp_policy[21],ipolicy[21],icard1[21],itag[CA_TAG_NUM],fassured[2],dpolicy[11],iroute[21];
$varchar nassured[121],sNassured[121];
$char	iofficer[11],nofficer[11],ileader[11],nleader[11],nmail_type[11];
$int mpremium = 0;
$char   cdate1[11],cdate2[11];

/* asempl */
$char	email[51],chinese_name[15];

$char stmt_tmp[1024];
/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;
      
    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(ddate,   isNULLstr(argv[3])); /* cyy/mm/dd */
    strcpy(outputf, isNULLstr(argv[4]));
    
    strcpy(sDdate,cm_to_infdate(ddate));
    printf("-----dpolicy : [%s]\n-----",sDdate);

    rc = car3014_get_db();
    if (rc != M_CM_OK) {
        printf("error on car3014_get_db\n");
        return rc;
    }
    
    /* �ئ۰ʥX��O��M����� temp table (car3014) */        
    rc = car3014_init_data();
    if (rc != M_CM_OK) {
        printf("error on car3014_init_data\n");
        return rc;
    }
        
    /* �d�ߦ۰ʥX��O�������� */        
    rc = car3014_ply_data();
    if (rc != M_CM_OK) {
        printf("error on car3014_ply_data\n");
        EWRITE(userid, rc, "�d�߫O���Ʀ��~!");
        return rc;
    }

    /* �H�e���I�۰ʥX��O�� E-mail �q�����޲z�H */
    rc = car3014_send_email_ileader(); 
    if (rc != M_CM_OK) {
        printf("error on car3014_send_email_ileader\n");
        EWRITE(userid, rc, "�H�oE-mail�q���޲z�H���~!");
        return rc;
    }
    

    printf("[car3014]:process ok!\n"); 
}
/*----------------------------------------------------------------------------*/
long car3014_get_db()
{
    int	rc;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
       return M_CM_DB_NOTOPEN;
    }
    
    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }
    
    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
    }

    return M_CM_OK;
}
/*----------------------------------------------------------------------------*/
long car3014_init_data()
{
    $whenever sqlerror goto errexit;
    sprintf_s(stmt_tmp, sizeof stmt_tmp,"create temp table car3014 (\
		   itmp_policy		char(20),\
		   ipolicy		     char(20),\
		   icard1          char(20),\
		   nassured        char(120),\
       itag            char(%d),\
       mpremium        integer,\
       dpolicy         date,\
       iofficer        char(10),\
       nofficer        char(10),\
       iroute          char(20),\
       nmail_type      char(10),\
       ileader         char(10),\
       nleader         char(10),\
       fassured        char(1)\
     )with no log;",CA_TAG_NUM-1);
     $PREPARE stmp FROM $stmt_tmp;
     $EXECUTE stmp;
/*
	$SELECT first 1 dwork
           INTO $cdate2
           FROM cm_wrktbl
          WHERE dwork < $sDdate
        ORDER BY 1 desc;
        strcpy(cdate1,cm_from_infdate_100(cdate2));

    printf("-----cdate1 = [%s]-----\n",cdate1);

    cm_char_split_3ymd(cdate1,syy,smm,sdd);
*/


    printf("-----ddate = [%s]-----\n",ddate);
    dsys = cm_ymd_cdate(ddate);
    cm_char_split_3ymd(ddate,syy,smm,sdd);

    
    sprintf_s(sdate, sizeof sdate,"%s%s%s",syy,smm,sdd);
    printf("-----sdate = [%s]-----\n",sdate);
    
    /* ���~�� */
    strcpy(year2,substring(sdate,2,2));
    printf("-----���~��:[%s]-----\n",year2);

    /* ���Y */
    strcpy(ftitle,
           "�����渹,�O�渹�X,�j���Ҹ�,�Q�O�I�H�m�W,���P���X,�O�O,�X����,�g��N��,"
           "�g��N������,�q���N��,�l�H�覡,�޲z�H�N��,�޲z�H����\n");
    
    /* �D�� */
    sprintf_s(nsubject, sizeof nsubject,"�n�O�ѥ��^�q��");
	
    return M_CM_OK;

errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car3014_ply_data()
{
   int	rc;
   $char stmt_esign[1024],sign_pol[21],nequipment1[31],tmp_nequipment1[31],iquote[21],stmt_buf[1024];
   $whenever sqlerror goto errexit;
   /* 1060817004-C1 �q�lñ�p
   �b�C��q���޲z�H���e�A���˵����I�q�lñ�p����ɪ���f��(Y:�w�W�Ǫ���w�f)�B����f�֤��=�t�Τ�A
   �N���I���O��102 (�۰ʥX��)��103 (�n�O�ѥ��^(�۰ʥX��-��j���~)���A����103 (�n�O�ѥ��^(�۰ʥX��-��j���~)���O�C*/
    $WHENEVER ERROR CONTINUE;    
    $drop table esign_list;
    $whenever sqlerror goto errexit;
   
    /*1060817004-C1 �q�lñ�p */
  $SELECT iscan_no,nvl(ipolicy,'') as ipolicy1,nvl(ipolicy2,'') as ipolicy2,iquote
     FROM cm_esign_data
    WHERE dappend = $sDdate
      AND fstatus <> '9' 
      AND fstatus2 <> '9'
      AND fappend ='Y'
      AND dappend is not null
      AND iins_newtype='C'
      AND fpolicy ='1'
     INTO TEMP esign_list;
   /* 1070308001 -���f�֫�X��|�L�k�^�ɥH�H�u�B�z*/
   for(i=0;i<count_db;i++) 
   {    
        /*1060817004-C1 �q�lñ�p ������������*/
        /* �n�ư��N�q�lñ�p�����ɤ��������f�֪���A�M��̲׬O�ȥ��X��A�Ӥ��O�ιq�lñ�p�����y�Ǹ��X�� */
        sprintf_s(stmt_esign, sizeof stmt_esign,
                    "SELECT a.nequipment,nvl(b.ipolicy1,'') "
                    "  FROM %s:policy a,esign_list b ,%s:ply_relation c"
                    " WHERE a.ipolicy = b.ipolicy1 AND a.ipolicy = c.ipolicy "
                      " AND c.iscan_no = b.iscan_no "
                    " UNION "
                    " SELECT a.nequipment,nvl(b.ipolicy2,'') "
                    "  FROM %s:policy a,esign_list b  ,%s:ply_relation c"
                    " WHERE a.ipolicy = b.ipolicy2 AND a.ipolicy = c.ipolicy "
                      " AND c.iscan_no = b.iscan_no ",
                    list[i].dbname,list[i].dbname,list[i].dbname,list[i].dbname);
        printf("stmt_esign[%s]\n",stmt_esign);
       $PREPARE pre1_1 FROM $stmt_esign;
       $DECLARE cur_pre1_1 CURSOR for pre1_1;
       $OPEN cur_pre1_1;
       while (1)
        {
            $FETCH cur_pre1_1 INTO $tmp_nequipment1,$sign_pol;
            if(SQLCODE == SQLNOTFOUND) break;
            strcpy(nequipment1,equip_delete(tmp_nequipment1,"103"));
            sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE %s:policy SET \
                                         (nequipment,foccup,noccup,applicant_foccup,applicant_noccup) \
                                       = (?,'N','','N','') \
                                  WHERE ipolicy = ? \
                                    AND nequipment[13] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.')",
                                    list[i].dbname);

            $PREPARE u_id1 FROM $stmt_buf;
            $EXECUTE u_id1 using $nequipment1,$sign_pol;
           
            if (sqlca.sqlerrd[2]>0)
            {
                    /* insert ca_autoply_log */
                $INSERT INTO ca_autoply_log
                 SELECT iquote,ipolicy1,ipolicy2,'D','car3014',current from esign_list
                  WHERE ipolicy1 = $sign_pol;
                sleep(1);
            }
   
        }
        /*1060817004-C1 �q�lñ�p ������������������������*/
     sprintf_s(stmt, sizeof stmt,"INSERT INTO car3014 "
	   "SELECT a.itmp_policy,a.ipolicy, CASE WHEN a.fcard_class = '1' Then a.icard ELSE ' ' END, "
	   "       b.nassured , b.itag , (a.mdmg_prem+a.mlia_prem) as mpremium , "
	   "       a.dpolicy, a.iofficer, "
	   "      (SELECT nname FROM officer WHERE iofficer = a.iofficer) as nofficer, "
	   "       b.iroute, decode(a.fmail_type,'0','���e�~�l�H','1','���H','2','����', "
	   "                        '3','����','4','����',' '), a.ileader, " 
	   "      (SELECT nname FROM officer WHERE iofficer = a.ileader) as nleader, b.fassured "
	   "  FROM %s:ply_relation a, %s:policy b"
	   " WHERE a.ipolicy = b.ipolicy  "
	   "   AND a.dply_close is not null "
	   "   AND dpolicy = '%s'   "
	   "   AND b.nequipment[13] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.')",list[i].dbname,list[i].dbname,sDdate);

	   printf("stmt[%s]\n",stmt);
	   $prepare pre_ply from $stmt;
	   $execute pre_ply;
	 }  
	
	   return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car3014_send_email_ileader()
{
	int	rc;

	$whenever sqlerror goto errexit;
	 
	  strcpy(stmt,"SELECT itmp_policy, ipolicy, icard1, nassured, " 
	              "       itag, mpremium, dpolicy, iofficer,  "
				        "	      nofficer, iroute, nmail_type, "
				        "       ileader, nleader "
                "  FROM car3014     "
				        " WHERE ileader = ? "
                " ORDER BY itag ");
    printf("stmt[%s]\n",stmt);
    $PREPARE pre_data from $stmt;
    $DECLARE cur_data CURSOR FOR pre_data;
	
    $DECLARE cur_temp CURSOR FOR
      SELECT DISTINCT ileader
				INTO $ileader
				FROM car3014
       ORDER BY ileader;
    $OPEN  cur_temp;
    $FETCH cur_temp;
    strcpy(pre_ileader,ileader);
    
    mail_count=0;
    for(;;) 
    {
			if (SQLCODE==SQLNOTFOUND) break;

			if (strcmp(ileader,pre_ileader)!=0) 
			{
	    	rc = car3014_write_email_ileader();
	    	if (rc != M_CM_OK) {
					printf("error on car3014_write_email_ileader\n");
					return rc;
	    	}
	    	mail_count=0;
			}
			strcpy(pre_ileader,ileader);
	
			mail_count++;
			printf("---ileader:[%s]---\n",ileader);
			memset(fname,0x00,sizeof(fname));
			memset(filename,0x00,sizeof(filename));
			sprintf_s(fname, sizeof fname,"%s_�n�O�ѥ��^�q��_%s",sdate,trim(ileader));
			sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
			printf("----filename[%s]----\n",filename);
			fp=fopen(filename,"w");
		
			fprintf(fp,ftitle);
			
			$OPEN cur_data USING $ileader;
	
			for(;;)
		  {
		    $FETCH cur_data INTO $itmp_policy,$ipolicy,$icard1,$nassured,$itag,$mpremium,$dpolicy,$iofficer,
                             $nofficer,$iroute,$nmail_type,$ileader,$nleader;
	                           
		    if (SQLCODE==SQLNOTFOUND) break;
		   	
		    printf("---ipolicy[%s]---\n",ipolicy);
		    fprintf(fp,"%s,%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s\n",
		            itmp_policy,ipolicy, icard1, nassured, itag, mpremium, dpolicy, iofficer,
	              nofficer, iroute, nmail_type, ileader, nleader);
			}
			$CLOSE cur_data;
			fclose(fp);
			$FETCH cur_temp;
		}
    $FREE  cur_data;
    $CLOSE cur_temp;
    $FREE  cur_temp;
	    
    if (mail_count!=0) {
        rc = car3014_write_email_ileader();
        if (rc!=M_CM_OK) {
			    printf("error on car3014_write_email_ileader\n");
			    return rc;
				}
    }
           
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*---------------------------------------------------------------------------*/
long car3014_write_email_ileader()
{
    $whenever sqlerror goto errexit;
    
    $SELECT nname
       INTO $sNleader
       FROM officer
      WHERE iofficer = $pre_ileader;
    if (SQLCODE==SQLNOTFOUND) strcpy(sNleader,"�P��");
    
    strcpy(sNleader,trim(sNleader));
    /* email��� */
    sprintf_s(mmsg, sizeof mmsg,
	  "�z�n</P>\n\n"
	  "�q���z�A���ɬ��T����O��wú�O�۰ʥX����ӡA�q�Ш�U�V�Ȥ᦬�^����ñ�W���n�O�ѡA�e����A����k�ɡA</P>\n"
	  "����!</P>"
          "�s����� �ӫO���֫O�� �p�����D�Ь��U��쨮�I�֫O�H��</P></P></P>( ���H���CAR3014�{���۰ʱH�o )\n");

    strcpy(mbuf,rtrim(mmsg));
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mbuf;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mbuf) + 1;

    strcpy(email," ");
    $select email,chinese_name
       into $email,$chinese_name
       from personal:asempl
      where empl_no = $pre_ileader;

    strcpy(email,trim(email));
    if (strlen(email) != 0){ 
    	
      strcpy(email,trim(email));
      strcat(email,"@tmnewa.com.tw");
      printf("-----email:[%s]-----\n",email);
      
      /* 1110322014_SC1_batchemail�ಾ�ܷs���x */
      if (strlen(trim(fname)) != 0) sprintf_s(nattachment, sizeof nattachment,"%s.csv",trim(fname));
      printf("-----nattachment:[%s]-----\n",nattachment);
      
      $INSERT INTO batchemail
		  (project_id, mail_date, receiver_email,
		   receiver_name, cc, content, key, mail_count, nsubject,
		   nattachment)
       VALUES
		  ("CAR3014", today, $email, $chinese_name,
		   " ", $ctxt, $fname, $mail_count, $nsubject,
		   $nattachment);
    }
    
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/*-------------------------------THE END--------------------------------------*/
