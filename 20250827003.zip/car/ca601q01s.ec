/***************************************************/
/*      PROGRAM : ca601q01s.ec                     */
/*      Date    : 11/29/1994                       */
/*      EDIT    : Peter Sun   08/24/1999           */
/*      TABLE   : ori_ply_relation, original_ply,  */
/*                ori_ins_type, edr_relation,      */
/*                endorsement, edr_ins_type,       */
/*                branch, officer                  */
/*                                                 */
/***************************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"

#define  NEXTPAGE          8
/*------------------------------------*/

$char  iofficer[EMPLOYEE_ID];
$char  officerbgn[11],officerend[11];
$char  drcvbgn[10],drcvend[10];
$char  drcvbgn_inf[11],drcvend_inf[11];
$char  itype[2],dtype[2],qtype[2],rtype[2],quota_rec[5];
char   detail[2];
char   check1[2];

$char  ipolicy[POLICY_NUM_1],dpolicy[10],iendorse[ENDORSE_NUM];
$long  dpolicy_1;
$char  dendorse[10],fcard_class[2];
$char  icard[CARD_NUM],nassured[41], nassured1[13],iassured[11],itag[CA_TAG_NUM];
$char  iquota[7],ibig_sales[11];
$char  iquota14[5];
$long  mdmg_prem,mlia_prem;
$long  dendorse_1,medrdmg_prem_1,medrlia_prem_1;
$char  off_brk[EMPLOYEE_ID];
$char  quota_brk[5];
$char  nuser[21];

int    flag_exist=0;
$char  off[EMPLOYEE_ID],ply[POLICY_NUM_1],edr[ENDORSE_NUM],dte[12];
$char  name[13],itg[CA_TAG_NUM],ieng[20],isuym[7], dply[12], dplybgn[12], sIbrand[9],dpobgn[3];
$int   prem1,prem2,prem;
$char  nchi_full[13],off_name[11],card[CARD_NUM];
char   serial_num1[POLICY_NUM_1],chk_num1[CA_TARGET_NUM],num1[POLICY_NUM_1];
char   serial_num2[ENDORSE_NUM],chk_num2[CA_TARGET_NUM],num2[ENDORSE_NUM];
char   c_dte[9], str[20];
int    tot_rec_cnt,tot_rec_prem1,tot_rec_prem2;
int    tot_nrec_cnt,tot_nrec_prem1,tot_nrec_prem2;
int    tot_prem1,tot_prem2,tot_prem;
int    str_cnt;

$long dply_begin, dedr_begin;
$long dply_end  , dedr_end;
$char iengine[CA_ENGINE_NUM], iissue_ym[7];
$char key_no[21];
$long ins_amt1,ins_amt2,ins_amt3,ins_prem;
$long mdeduct;
$char nins_type[31];
$char stmt[2000];
$char iins_type[11];


$char dply_begin_c[11];
$char dply_end_c[11];
$char Today_c[11];
$char qnext_year_c[5];
char sfilename[41];
$char exec_time[31];

/*------------------------------------------------*/
$char DBName[5];
$char FormTp[3];
char  BodyFile[N_FILE+1];
char  TitleFile[N_FILE+1];
char  outputf[N_FILE+1];
$char  userid[11];

$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;
int   max_count=0;
    char sApHome[20];
int   rtncode;
$char  sfile[51],getfile[51];
FILE  *sfp,*fp;
long  flen;
static char  *bp;
static int   recLen=1024;


$char txtfile[101];
char delimiter;
int offset;
int   count_db;
DBinfo *list;

$char ftype_pol[3],ftype_sp[3],dentry[11];
$long  dwork;
$char stmt_tmp1[1024],stmt_tmp2[1024];

/*------------------------------------------------*/
long car601_build();
long car601_build1();
long car601_grp();
void car601_tot();
long car601_body();
long car601_detail();
char *get_date();
long get_txt();
void GetData();


/************************************************************************/
main(argc, argv)
int argc;
char **argv;
{
   int rc;

   batchinit();
   strcpy(DBName,isNULLstr(argv[1]));
   strcpy(userid,isNULLstr(argv[2]));
   strcpy(itype,isNULLstr(argv[3]));		/*Q:�O��� P:������*/
   strcpy(officerbgn,isNULLstr(argv[4]));
   strcpy(officerend,isNULLstr(argv[5]));
   strcpy(dtype,isNULLstr(argv[6]));		/*0:�鵲��� 1:��J���*/
   strcpy(drcvbgn,isNULLstr(argv[7]));
   strcpy(drcvend,isNULLstr(argv[8]));
   strcpy(qtype,isNULLstr(argv[9]));
   strcpy(quota_rec,isNULLstr(argv[10]));
   strcpy(detail, isNULLstr(argv[11]));
   strcpy(check1, isNULLstr(argv[12]));
   strcpy(outputf,isNULLstr(argv[13]));

   if(strcmp(itype,"P") == 0)		/*���������r��*/
   {
   	rc = car601_get_db();
    	if (rc != M_CM_OK)
       	return;

   	rc = get_txt();
    	if (rc != M_CM_OK)
       	return;

       	rc=car601_build1();
       	if (rc != M_CM_OK)
       	return;
   }
   else
   {

   /*---------------------------------------------*/
   if (officerend[0] == ' ')
      strcpy( officerend, officerbgn);
 /*if (officerbgn[0] == '*')
      strcpy( officerbgn, " ");
   if (officerend[0] == '*')
      strcpy( officerend, "~");*/
   str_cnt=strlen(officerbgn) - 1;
   if (officerbgn[str_cnt] == '*')
      officerbgn[str_cnt]=' ';
   str_cnt=strlen(officerend) - 1;
   if (officerend[str_cnt] == '*')
      officerend[str_cnt]='~';
   printf("officerbgn[%s]\n",officerbgn);
   printf("officerend[%s]\n",officerend);

   if (drcvend[0] == ' ')
      strcpy( drcvend, drcvbgn);
   if (drcvbgn[0] == '*')
      strcpy( drcvbgn, "080/01/01");
   if (drcvend[0] ==    '*')
      strcpy( drcvend, "199/12/31");

   strcpy(drcvbgn_inf,cm_to_infdate(drcvbgn));
   strcpy(drcvend_inf,cm_to_infdate(drcvend));

   str_cnt=strlen(rtrim(quota_rec));
   if (strcmp(quota_rec[str_cnt-1],"*")!=0)
      quota_rec[str_cnt]='*';

   /*---------------------------------------------*/

   rc=car601_build();
   if (rc != M_CM_OK) return;

      if (flag_exist==0)
      {
         EWRITE(userid,rc,"Record Not Found");
         exit(FAIL);
      }

      create_sign_form("car601",BodyFile,Width);
      if ((rc=save_form_info(F_BLK1,"CA",601,userid,FormTp,max_count,outputf))<0)
         EWRITE(userid,rc,"save_form_info failed");
  }
}

/**************************************************************************/
long car601_build()
{
	$char TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
	$int ibatch_no;
	char yy[5],mm[3],dd[3];
	int rc;
	char ply1[POLICY_NUM_1],ply2[CA_TARGET_NUM],batch_no[ENDORSE_NUM];
	long lCount=0;
	char stitle[1000],stmt[1024];
	char msgbuf[1000];
	char sDate_between[100];
	$char ipolicy1[21],date_now[11];

	

	if (db_select(DBName) == False)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	$WHENEVER SQLERROR GOTO errexit;

	$SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
              kTot_Col, kPgNum_Line, kWidth, iForm_Tp
		INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
              $TotColumn, $PgLine, $Width, $FormTp
		FROM Form
        WHERE ksys_grp="CA" AND kPgmID = 601;

	printf("---------------------1\n");

	strcpy( TitleFmt,rtrim(TitleFmt));
	strcpy( BodyFmt,rtrim(BodyFmt));
	sprintf( TitleFile,"%s.ti",outputf);
	sprintf( BodyFile,"%s.bd",outputf);

	printf("&&& build title &&&\n");
	/*----- build title -----*/
	rgu_init_report( TitleFmt,TitleFile);
	rgu_put_head_string( 1, cm_sysd_cdatetime_100(cm_get_sysd()));   /* get_currdt */
	cm_split_ymd_100(drcvbgn,yy,mm,dd);
	rgu_put_head_string( 1, yy);
	rgu_put_head_string( 1, mm);
	rgu_put_head_string( 1, dd);
	cm_split_ymd_100(drcvend,yy,mm,dd);
	rgu_put_head_string( 1, yy);
	rgu_put_head_string( 1, mm);
	rgu_put_head_string( 1, dd);
	rgu_put_head();
	rgu_finish_report();

	/*----- build body -----*/
	rgu_init_report( BodyFmt,BodyFile);
	printf("&&& CREATE TEMP TABLE tbl &&&\n");

	sprintf(stmt_tmp1,"CREATE TEMP TABLE tbl\
	    (\
	     iofficer        char(10),\
	     ipolicy         char(20),\
	     iendorse        char(20),\
	     icard           char(20),\
	     iassured        char(10),\
	     nassured        char(13),\
	     itag            char(%d),\
	     iengine         char(%d),\
	     iissue_ym       char(6),\
	     dpolicy         date,\
	     dply_begin      date,\
	     dmg_premium     int,\
	     lia_premium     int,\
	     iquota          char(4),\
	     ibig_sales      char(10),\
	     nuser           char(20),\
	     dply_end        date,\
	     qnext_year      smallint,\
	     ibrand          char(8)\
	    ) WITH NO LOG;",CA_TAG_NUM-1,CA_ENGINE_NUM-1);
     $PREPARE stmp1 FROM $stmt_tmp1;
     $EXECUTE stmp1;


	printf("dtype[%s]\n",dtype);
	printf("�d�����O qtype[%s]\n",qtype);

   	if (qtype[0]=='0' || qtype[0]=='1')  /*������ñ��*/
   	{
   		if(dtype[0]=='1')	     /*ñ���*/
   		{
   		printf("�d�����O��������ñ��iñ���_�l��jbgn[%s] end[%s]\n",drcvbgn_inf,drcvend_inf);
		$Insert into tbl (
				iofficer,	ipolicy,		iendorse,		icard,		iassured,		nassured,
				itag,		iengine,		iissue_ym,		dpolicy,	dply_begin,		dmg_premium,
				lia_premium,iquota,			ibig_sales,		nuser,		dply_end,		qnext_year, ibrand)
			Select
				a.iofficer,	a.ipolicy,		' ',			a.icard,	iassured,		nassured[1,12],
				itag,		iengine,		to_char(b.dissue,'%Y')::integer - 1911 || '/' || to_char(b.dissue,'%m'),
				a.dpolicy,	a.dply_begin,	a.mdmg_prem,
				a.mlia_prem,a.iquota[1,4],	a.ibig_sales,	nuser,		a.dply_end,		c.qnext_year, a.ibrand
			from ori_ply_relation a, original_ply b, ply_relation c
			WHERE
				(a.dpolicy BETWEEN $drcvbgn_inf AND $drcvend_inf) AND
				(a.iofficer BETWEEN $officerbgn AND $officerend) AND
				(a.ipolicy = b.ipolicy) AND
				(a.ipolicy = c.ipolicy) AND
				(a.iquota matches $quota_rec);
   		}
   		else			      /*��J��*/
   		{
   		printf("��J��\n");
		$Insert into tbl (
				iofficer,	ipolicy,		iendorse,		icard,		iassured,		nassured,
				itag,		iengine,		iissue_ym,		dpolicy,	dply_begin,		dmg_premium,
				lia_premium,iquota,			ibig_sales,		nuser,		dply_end,		qnext_year, ibrand)
			Select
				a.iofficer,	a.ipolicy,		' ',			a.icard,	iassured,		nassured[1,12],
				itag,		iengine,		to_char(b.dissue,'%Y')::integer - 1911 || '/' || to_char(b.dissue,'%m'),
				a.dpolicy,	a.dply_begin,	a.mdmg_prem,
				a.mlia_prem,a.iquota[1,4],	a.ibig_sales,	nuser,		a.dply_end,		a.qnext_year, a.ibrand
			from  ply_relation a, policy b
			WHERE
				(a.dentry BETWEEN $drcvbgn_inf AND $drcvend_inf) AND
				(a.iofficer BETWEEN $officerbgn AND $officerend) AND
				(a.dply_close is null ) AND
				(a.ipolicy = b.ipolicy) AND
				(a.iquota matches $quota_rec);
   		}

	}

	if (qtype[0]=='0' || qtype[0]=='2')
	{
		if(dtype[0]=='1')
		{
		printf("�d�����O�������Χ��\n");
		$INSERT INTO tbl (
				iofficer,		ipolicy,		iendorse,		icard,		iassured,	nassured,
				itag,			iengine,		iissue_ym,		dpolicy,	dply_begin, dmg_premium,
				lia_premium,	iquota,			ibig_sales,		nuser,		dply_end,	qnext_year, ibrand)
			Select
				a.iofficer,		a.ipolicy,		a.iendorse,		a.icard,	iassured,	nassured,
				itag,			iengine,		to_char(b.dissue,'%Y')::integer - 1911 || '/' || to_char(b.dissue,'%m'),
				a.dendorse,	dedr_begin,	medrdmg_prem,
				medrlia_prem,	a.iquota[1,4],	a.ibig_sales,	nuser,		dedr_end,	c.qnext_year, a.ibrand
			from edr_relation a, endorsement b, ply_relation c
			where
			 	(a.dendorse BETWEEN $drcvbgn_inf AND $drcvend_inf) AND
			 	(a.iofficer BETWEEN $officerbgn AND $officerend) AND
			 	(a.iendorse = b.iendorse) AND
			 	(a.ipolicy = c.ipolicy) AND
			 	(a.iquota matches $quota_rec);
		}
		else
		{
		printf("��J��\n");
		$INSERT INTO tbl (
				iofficer,		ipolicy,		iendorse,		icard,		iassured,	nassured,
				itag,			iengine,		iissue_ym,		dpolicy,	dply_begin, dmg_premium,
				lia_premium,	iquota,			ibig_sales,		nuser,		dply_end,	qnext_year, ibrand)
			Select
				a.iofficer,		a.ipolicy,		a.iendorse,		a.icard,	iassured,	nassured,
				itag,			iengine,		to_char(b.dissue,'%Y')::integer - 1911 || '/' || to_char(b.dissue,'%m'),
				a.dendorse,	dedr_begin,	medrdmg_prem,
				medrlia_prem,	a.iquota[1,4],	a.ibig_sales,	nuser,		dedr_end,	c.qnext_year, a.ibrand
			from edr_relation a, endorsement b, ply_relation c
			where
			 	(a.dentry BETWEEN $drcvbgn_inf AND $drcvend_inf) AND
			 	(a.iofficer BETWEEN $officerbgn AND $officerend) AND
			 	(a.dedr_close is null)    AND
			 	(a.iendorse = b.iendorse) AND
			 	(a.ipolicy = c.ipolicy) AND
			 	(a.iquota matches $quota_rec);
		}
	}

	/*----------report----------*/

	strcpy( off_brk," ");
	strcpy( quota_brk," ");

	tot_rec_cnt=tot_rec_prem1=tot_rec_prem2=0;
	tot_nrec_cnt=tot_nrec_prem1=tot_nrec_prem2=0;
	tot_prem1=tot_prem2=tot_prem=0;

	$DECLARE CCUR CURSOR FOR
		SELECT
			iofficer,ipolicy,iendorse,icard,iassured,nassured,itag,iengine,iissue_ym,dpolicy,dply_begin,dmg_premium,
			lia_premium,iquota,ibig_sales,nuser,dply_end,
			decode(nvl(qnext_year,-1),-1,' ',0,'�s�O','��O') as qnext_year_c, ibrand ,
			(case when dpolicy < dply_begin then '1' else '0' end)			
		FROM tbl
		ORDER BY iquota,iofficer,ibig_sales,iassured,ipolicy,iendorse,icard;
	$OPEN CCUR;

	while (1)
	{
		prem1=prem2=0;

		$FETCH CCUR INTO $off,$ply,$edr,$card,$iassured,$name,$itg,$ieng,
			$isuym,$dply,$dplybgn,$prem1,$prem2,$iquota,
			$ibig_sales,$nuser,$dply_end,$qnext_year_c, $sIbrand , $dpobgn;
		if (SQLCODE != 0)
			break;
		else
			flag_exist=1;

		printf("########### ply[%s] card[%s] name[%s]\n",ply,card,name);

		if (prem1==0 && prem2==0)
			continue;

		/*�O�����O�B�ĳq�ʽ�B���O���(��������t�B��檺���)*/
		$SELECT a.ftype_pol,a.ftype_sp,
		        NVL((select date(dentry)
		               from ao_prercv_pass x
                              where x.ipre_rcv = a.ipre_rcv
			        and x.iins_kind = a.iins_kind
			        and x.ipre_end = a.ipre_end)," ")
		   INTO $ftype_pol,$ftype_sp,$dentry
		   FROM cm_pre_receive a
		  WHERE a.ipolicy1 = $ply
		    AND a.iendorse = $edr
		    AND a.ipre_end = ' ';

		if (SQLCODE == SQLNOTFOUND)
		{
			strcpy(ftype_pol," ");
			strcpy(ftype_sp," ");
			strcpy(dentry," ");
		}
		printf("ftype_pol[%s] ftype_sp[%s] dentry[%s] dpolicy[%s]\n",ftype_pol,ftype_sp,dentry,dply);


		/*�p��S�w�q����ú�Ѽ�*/
		if(strcmp(trim(dentry),"")==0)
		{
			if(strcmp(trim(dpobgn),"1")==0)         /*�Y�����O��A[���O��-ñ���]�P[���O��-�ͮĤ�]�A��ܤѼƮt�Z���j��*/
			{                                       /*�hñ���p��ͮĤ�A��ñ���h�p��*/
			$SELECT count(dwork)
		           INTO $dwork
  		           FROM cm_wrktbl
 		          WHERE dwork > $dply
   		            AND dwork <= today
		          ORDER BY 1;
		        }
		        else
			{
			$SELECT count(dwork)
		           INTO $dwork
  		           FROM cm_wrktbl
 		          WHERE dwork > $dplybgn
   		            AND dwork <= today
		          ORDER BY 1;
		        }
		}
		else
		{
			if(strcmp(trim(dpobgn),"1")==0)
			{
			$SELECT count(dwork)
		           INTO $dwork
  		           FROM cm_wrktbl
 		          WHERE dwork > $dply
   		            AND dwork <= $dentry
		          ORDER BY 1;
		        } 
		        else
		        {
			$SELECT count(dwork)
		           INTO $dwork
  		           FROM cm_wrktbl
 		          WHERE dwork > $dplybgn
   		            AND dwork <= $dentry
		          ORDER BY 1;
		        } 
		}
		printf("dwork[%d]\n",dwork);


		if (strcmp(off_brk," ")==0)
		{
			rc=car601_grp();
			if (rc != M_CM_OK) return rc;
			strcpy(off_brk,off);
			strcpy(quota_brk,iquota);
		}
		else if (strcmp(off_brk,off)!=0 || strcmp(quota_brk,iquota) !=0)
		{
			car601_tot();
			rgu_put_body(NEXTPAGE);
			rc=car601_grp();
			if (rc != M_CM_OK) return rc;
		}
		rc=car601_body();
		if (rc != M_CM_OK) return rc;
		strcpy(off_brk,off);
		strcpy(quota_brk,iquota);
	} /*while*/

	if (flag_exist==1) car601_tot();

	$CLOSE CCUR;

	rgu_finish_report();

	if (check1[0] == '1')
	{
		printf("begin c_cur\n");
		printf("begin unload\n");
		sprintf(sDate_between,"[%s]_[%s]",drcvbgn,drcvend);
		printf("sDate_between[%s]\n",sDate_between);
		strcpy(sfilename,"��W�T�����.txt");
		/*
		strcat(sfilename,sDate_between);
		*/
		strcpy(sfile,sfilename);
		rtncode = getApHome(sApHome);
		if (rtncode < 0)
		{
			printf("read Config file error!!\n");
			return M_CM_READ_CONFIG_ERR;
		}
		sprintf(getfile, "%s/rptftp/%s", sApHome, sfile);
		printf("getfile[%s]\n",getfile);
		if ((fp=fopen(getfile,"w"))==NULL)
		{
			printf("fopen err\n");
            exit(1);
        }
        printf("fopen ok \n");

		$SELECT iquota[1,4]
			INTO $iquota14
			FROM officer
			WHERE iofficer = $userid;
			if (SQLCODE == SQLNOTFOUND)
			{
				strcpy(iquota14," ");
			}

		$DECLARE c_cur CURSOR FOR
			SELECT
				iassured,nassured,decode(ipolicy[6],'V',ipolicy,icard),itag,iengine,iendorse,
				dply_begin,dply_end,nuser,iofficer,ipolicy, ibrand
			FROM tbl
			WHERE iquota = $iquota14
			ORDER BY 3;
		$OPEN c_cur;
		for(;;)
		{
      		$FETCH c_cur
        		INTO $iassured,$nassured,$ipolicy,$itag,$iengine,$iendorse,$dply_begin,$dply_end,$nuser,$iofficer,$ipolicy1, $sIbrand;
      		if (SQLCODE == SQLNOTFOUND) break;

         	printf("BEGIN INTO c_cur ipolicy[%s],iendorse[%s]\n",ipolicy,iendorse);
         	if (iendorse[0] != ' ' && iendorse[0] != '\0')
         	{
            	sprintf(stmt,
						"select iins_type,medrinj_cover,medrdea_cover,medrdmg_cover,medrins_prem,mdeduct \
						from edr_ins_type \
						where iendorse = ? ");
            	strcpy(key_no,iendorse);
         	}
         	else
         	{
         		if(dtype[0]=='1')
         		{
         			sprintf(stmt,
                   		"select iins_type,minjured_cover,mdeath_cover,mdamage_cover,mins_premium,mdeduct \
                      		   from ori_ins_type \
                     		  where ipolicy = ? ");
         		}
         		else
         		{
         			sprintf(stmt,
                   		"select iins_type,minjured_cover,mdeath_cover,mdamage_cover,mins_premium,mdeduct \
                      		   from ply_ins_type \
                     		  where ipolicy = ? ");
         		}

            	strcpy(key_no,ipolicy1);
         	}

         	strcpy(Today_c,get_date(cm_today()));

			$prepare pre_ins1 from $stmt;
			$declare cur_ins1 cursor for pre_ins1;
			$open cur_ins1 using $key_no;
         	while(1)
         	{
         		$fetch cur_ins1 into $iins_type,$ins_amt1,$ins_amt2,$ins_amt3,$ins_prem,$mdeduct;
         		if (SQLCODE == SQLNOTFOUND) break;

            	$SELECT nins_type
               		INTO $nins_type
               		FROM insurance_type
              		WHERE iins_type = $iins_type;

		if (SQLCODE == SQLNOTFOUND)
                {
			strcpy(nins_type," ");
		}

			strcpy(dply_begin_c,get_date(dply_begin));
			strcpy(dply_end_c,get_date(dply_end));

			strcpy(iassured,rtrim(iassured));
			strcpy(ipolicy,rtrim(ipolicy));
			strcpy(itag,rtrim(itag));
			strcpy(iengine,rtrim(iengine));
			strcpy(dply_begin_c,rtrim(dply_begin_c));
			strcpy(dply_end_c,rtrim(dply_end_c));
			strcpy(iins_type,rtrim(iins_type));
			strcpy(nins_type,rtrim(nins_type));
			strcpy(nuser,rtrim(nuser));
			strcpy(iofficer,rtrim(iofficer));

            	flen=fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%ld,%ld,%ld,%ld,%ld,%s,%s,%s\n",
                             iassured,ipolicy,Today_c,itag,iengine,dply_begin_c,dply_end_c,
                             iins_type,nins_type,ins_amt3,ins_amt1,ins_amt2,mdeduct,ins_prem,nuser,iofficer, sIbrand);
			}
			$close cur_ins1;
			$free cur_ins1;
		}
		$CLOSE c_cur;
		$FREE c_cur;
		fclose(fp);

		strcpy(exec_time, cm_get_sysd());
		$INSERT INTO rptftplist (nuserid, ipgid, noutfile, dcreate)
			VALUES ($userid, 'car601', $sfile, $exec_time);
	}
	else
	{
		printf("�������ɮ� !\n");
	}
	return M_CM_OK;

errexit:
	printf("car601_build:err,%d",SQLCODE);
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}

/************************************************************************/
long car601_grp()
{
 $char  quota[7];
   $WHENEVER SQLERROR GOTO errexit;

   if (strcmp(quota_brk,iquota)!=0 || strcmp(quota_brk," ")==0) {
      strncpy(quota,iquota,4);
      quota[4]='0';
      quota[5]='0';
      $SELECT nbranch
         INTO $nchi_full
         FROM sa_branch_type
        WHERE ibranch = $quota;
   }
   $SELECT nname
      INTO $off_name
      FROM officer
     WHERE iofficer=$off;

   rgu_put_body_string(1,nchi_full,1);
   rgu_put_body_string(1,DBName,1);
   rgu_put_body(1);
   rgu_put_body_string(2,off,1);
   rgu_put_body_string(2,off_name,1);
   rgu_put_body(2);
   max_count+=2;

   return M_CM_OK;

errexit:
  printf("car601_grp:sqlcode=%d\n",SQLCODE);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  return SQLCODE;
}

/************************************************************************/
void car601_tot()
{
  $char str[20];

  rgu_put_body(4);
  max_count++;
  rfmtlong(tot_prem,"-,---,---,--&",str);
  rgu_put_body_string( 7,str,RIGHT);
/*rfmtlong(tot_prem2,"-,---,---,--&",str);
  rgu_put_body_string( 7,str,RIGHT);*/
  rgu_put_body(7);
  rgu_put_body(4);
  max_count+=3;

  tot_rec_cnt=tot_rec_prem1=tot_rec_prem2=0;
  tot_nrec_cnt=tot_nrec_prem1=tot_nrec_prem2=0;
  tot_prem1=tot_prem2=tot_prem=0;

}

/************************************************************************/
long car601_body()
{
  $char str[20],dwork1[10];
  char  tmp[50];
  int   rc;
  

  $WHENEVER SQLERROR GOTO errexit;

  if (detail[0]=='Y' && ply[5]=='V') {
     rc=car601_detail();
     if (rc != M_CM_OK) return rc;
  }

  strcpy(num1," ");
  strcpy(num2," ");

  if (ply[0]!=' ' && ply[0]!='\0')
  {
     if (strlen(rtrim(ply)) >= (CAR_POLICY_LEN+CAR_TARGET_LEN))
     {
        strncpy(serial_num1,ply,CAR_POLICY_LEN);
        serial_num1[CAR_POLICY_LEN]='\0';
        strncpy(chk_num1,&ply[CAR_POLICY_LEN],CAR_TARGET_LEN);
        chk_num1[CAR_TARGET_LEN]='\0';
        strcpy(num1,serial_num1);
        strcat(num1,"-");
        strcat(num1,chk_num1);
     }
     else
        strcpy(num1,ply);
  }
  else
  {
      strcpy(num1," ");
  }

  if (edr[0]!=' ' && edr[0]!='\0')
  {
     if (strlen(rtrim(edr)) >= (CAR_POLICY_LEN+CAR_TARGET_LEN))
     {
        strncpy(serial_num2,edr,CAR_POLICY_LEN);
        serial_num2[CAR_POLICY_LEN]='\0';
        strncpy(chk_num2,&edr[CAR_POLICY_LEN],CAR_TARGET_LEN);
        chk_num2[CAR_TARGET_LEN]='\0';
        strcpy(num2,serial_num2);
        strcat(num2,"-");
        strcat(num2,chk_num2);
     }
     else
        strcpy(num2,edr);
  }
  else
  {
      strcpy(num2," ");
  }

  rgu_put_body_string( 3,ibig_sales,LEFT);    /* �~�N�N�X */
  rgu_put_body_string( 3,num1,LEFT);          /* �O�渹�X */
  rgu_put_body_string( 3,num2,LEFT);          /* ��渹�X */
  rgu_put_body_string( 3,rtrim(card),LEFT);   /* �O�I�Ҹ� */
  rgu_put_body_string( 3,name,LEFT);          /* �Q�O�I�H�W�� */
  rgu_put_body_string( 3,nuser,LEFT);         /* �ϥΤH */
  rgu_put_body_string( 3,itg,LEFT);           /* �P�Ӹ��X */
  rgu_put_body_string( 3,ieng,LEFT);          /* �������X */
  rgu_put_body_string( 3,isuym,LEFT);         /* �o�Ӧ~�� */
  rgu_put_body_string( 3,dply,LEFT);          /* ñ����� */
  rgu_put_body_string( 3,dplybgn,LEFT);       /* ñ���ͮĤ� */
  prem = prem1 + prem2;
  rfmtlong(prem,"---,---,--&",str);           /* �����O�O */
  rgu_put_body_string( 3,str,RIGHT);
  rgu_put_body_string( 3,qnext_year_c,LEFT);  /* �s��O */
  rgu_put_body_string( 3,ftype_pol,LEFT);     /* �O�����O */
  rgu_put_body_string( 3,ftype_sp,LEFT);      /* �ĳq�ʽ� */
  rgu_put_body_string( 3,dentry,LEFT);     /* ���O��� */
  rgu_put_body_string( 3,itoa(dwork),LEFT);     /* �p��S�w�q����ú�Ѽ� */


  ply[0]=0;

  rgu_put_body( 3);
  max_count++;

  tot_rec_cnt += 1;
  tot_nrec_prem1 +=prem1;
  tot_nrec_prem2 +=prem2;
  tot_prem1 += prem1;
  tot_prem2 += prem2;
  tot_prem  += prem;

  return M_CM_OK;

errexit:
  printf("car601_body:sqlcode=%d\n",SQLCODE);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  return SQLCODE;
}
/************************************************************************/
long car601_detail()
{
  $char str[20];
  $char stmt[800],key_no[21];
  $char iins_type[7];
  $long ins_amt1,ins_amt2,ins_amt3,ins_prem;

  $WHENEVER SQLERROR GOTO errexit;

  if (edr[0]!=' ' && edr[0]!='\0') {
     sprintf(stmt,
            "select iins_type,medrinj_cover,medrdea_cover,medrdmg_cover, \
                    medrins_prem \
               from edr_ins_type \
              where iendorse = ? ");
     strcpy(key_no,edr);
  }
  else {
  	if(dtype[0]=='1')
        {
     	sprintf(stmt,
            "select iins_type,minjured_cover,mdeath_cover,mdamage_cover, \
                    mins_premium \
               from ori_ins_type \
              where ipolicy = ? ");
        }
        else
        {
        sprintf(stmt,
            "select iins_type,minjured_cover,mdeath_cover,mdamage_cover, \
                    mins_premium \
               from ply_ins_type \
              where ipolicy = ? ");
        }
     strcpy(key_no,ply);
  }
  $prepare pre_ins from $stmt;
  $declare cur_ins cursor for pre_ins;
  $open    cur_ins using $key_no;
  while(1) {
     $fetch cur_ins into $iins_type,$ins_amt1,$ins_amt2,$ins_amt3,$ins_prem;
     if (SQLCODE==SQLNOTFOUND) break;
     rgu_put_body_string( 5,iins_type,RIGHT);   /* �I�إN�X */
     rfmtlong(ins_amt1,"---------&",str);       /* �O�B�@ */
     rgu_put_body_string( 5,str,RIGHT);
     rfmtlong(ins_amt2,"---------&",str);       /* �O�B�G */
     rgu_put_body_string( 5,str,RIGHT);
     rfmtlong(ins_amt3,"---------&",str);       /* �O�B�T */
     rgu_put_body_string( 5,str,RIGHT);
     rfmtlong(ins_prem,"---,---,--&",str);      /* �O�O */
     rgu_put_body_string( 5,str,RIGHT);
     rgu_put_body( 5);
     max_count++;
  }
  return M_CM_OK;
errexit:
  printf("car601_detail:sqlcode=%d\n",SQLCODE);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  return SQLCODE;
}

char *get_date(ldate)
long ldate;
{
char cdate_str[11];
char cdate_tmp[11];

     strcpy(cdate_tmp,cm_edate_str(ldate));
     if (cdate_tmp[0] != ' ' && cdate_tmp[0] != '\0')
     {
        strcpy(cdate_str,substring(cdate_tmp,7,4));
        strcat(cdate_str,substring(cdate_tmp,1,2));
        strcat(cdate_str,substring(cdate_tmp,4,5));
        cdate_str[8] = '\0';
     }
     else
     {
        strcpy(cdate_str," ");
     }
     return cdate_str;

}

long car601_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
      if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
         return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long get_txt()
{
    $char itag[CA_TAG_NUM],iestimate[21];

    static int   recLen=1024;

    rtncode = getApHome(sApHome);
	if (rtncode < 0)
	{
		printf("read Config file error!!\n");
		return M_CM_READ_CONFIG_ERR;
	}

    EXEC SQL WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    printf("sApHome[%s]\n",sApHome);
    sprintf(getfile,"%s/dat/car/car601.txt",sApHome);
    printf("getfile[%s]\n",getfile);

    if ((fp=fopen(getfile,"rt"))==NULL)
    {
        return FAIL;
    }

    if ((bp=malloc(recLen))==NULL)
    {
        printf("System malloc failed  !\n");
        return FAIL;
    }

    /* ���j�Ÿ� */
    delimiter = '\t';

    $CREATE TEMP table tmp_car601
    (
        iestimate      char(20)		/*�պ⸹*/
    )with no log;

    while(fgets(bp,recLen,fp))
    {
       if (feof(fp)) break;
       offset = 0;

            /* ��ƨ��o���Ǥ��i�ܰ� */
            GetData(iestimate,          sizeof(iestimate),	delimiter);

printf("iestimate[%s]\n",iestimate);
            $insert into tmp_car601(iestimate)
             values ($iestimate);
     }

	    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

void GetData(data, maxlen, delimiter)
char *data, delimiter;
int maxlen;
{
int fori, pre_offset, cnt=0;

    data[0]='\0';
    pre_offset = offset;

    for (fori=pre_offset; bp[fori]!=0x00&&bp[fori]!=0x0d&&bp[fori]!=0x0a&&bp[fori]!=delimiter; fori++)
    {
        offset++;
        if (cnt < maxlen-1)
        {
            data[cnt]=bp[fori];
            cnt++;
        }
    }

    offset++; /* ���ܤU�@�� */
    if (cnt==0) data[cnt++]=0x20; /* �L��Ƶ��ť� */
    data[cnt]=0x00;
    printf("pre_offset[%d]offset[%d]len[%d]data[%s]\n", pre_offset, offset, cnt, data);
}
long car601_build1()
{
	int rc;

	sprintf(stmt_tmp2,"CREATE TEMP TABLE tbl1\
	    (\
	     iassured        char(10),\
	     ipolicy         char(20),\
	     itag            char(%d),\
	     iengine         char(%d),\
	     dply_begin      date,\
	     dply_end        date,\
	     iins_type       char(4),\
	     nins_type       char(20),\
	     ins_amt3        int,\
	     ins_amt1        int,\
	     ins_amt2        int,\
	     mdeduct         int,\
	     ins_prem        int,\
	     nuser           char(20),\
             iofficer        char(10),\
	     ibrand          char(8)\
	    ) WITH NO LOG;",CA_TAG_NUM-1,CA_ENGINE_NUM-1);
     $PREPARE stmp2 FROM $stmt_tmp2;
     $EXECUTE stmp2;


	/*�N��Ƽg�Jtemp table*/
	$Insert into tbl1 ( iassured,ipolicy,itag,iengine,dply_begin,dply_end,iins_type,
	                    nins_type,ins_amt3,ins_amt1,ins_amt2,mdeduct,ins_prem,nuser,
	                    iofficer,ibrand)
			Select a.iassured,
			       case when b.iins_type = '21' then a.icard1 else a.ipolicy2 end,
			       a.itag,a.iengine,
			       case when b.iins_type = '21' then dply1_begin else a.dply2_begin end,
			       case when b.iins_type = '21' then dply1_end else a.dply2_end end,
			       b.iins_type,(select nins_type from insurance_type where iins_type = b.iins_type ),
			       b.mdamage_cover,b.minjured_cover,b.mdeath_cover,b.mdeduct,b.mins_premium,
			       a.nuser,
			       case when b.iins_type = '21' then a.iofficer1 else a.iofficer2 end,
			       a.ibrand
			  from estimate a, est_ins_type b ,tmp_car601 c
		         WHERE a.iestimate = b.iestimate
		           and a.iestimate = c.iestimate;

	/*��Xtxt��*/
	printf("begin c_cur2\n");
	printf("begin unload\n");
	strcpy(sfilename,"��W�T�����(������).txt");

	strcpy(sfile,sfilename);

	rtncode = getApHome(sApHome);
	if (rtncode < 0)
	{
		printf("read Config file error!!\n");
		return M_CM_READ_CONFIG_ERR;
	}
	sprintf(getfile, "%s/rptftp/%s", sApHome, sfile);
	printf("getfile[%s]\n",getfile);

	if ((fp=fopen(getfile,"w"))==NULL)
	{
		printf("fopen err\n");
       		exit(1);
   	}

   printf("fopen ok \n");


	$DECLARE c_cur2 CURSOR FOR
		SELECT iassured,ipolicy,itag,iengine,dply_begin,dply_end,iins_type,
	               nins_type,ins_amt3,ins_amt1,ins_amt2,mdeduct,ins_prem,
	               nuser,iofficer,ibrand
		  FROM tbl1
		 ORDER BY 2;
	$OPEN c_cur2;
	for(;;)
	{
 		$FETCH c_cur2
   		INTO $iassured,$ipolicy,$itag,$iengine,$dply_begin,$dply_end,$iins_type,
	             $nins_type,$ins_amt3,$ins_amt1,$ins_amt2,$mdeduct,$ins_prem,
	             $nuser,$iofficer,$sIbrand;
 		if (SQLCODE == SQLNOTFOUND) break;

    	printf("BEGIN INTO c_cur2 ipolicy[%s]\n",ipolicy);

    	strcpy(Today_c,get_date(cm_today()));


			strcpy(dply_begin_c,get_date(dply_begin));
			strcpy(dply_end_c,get_date(dply_end));

			strcpy(iassured,rtrim(iassured));
			strcpy(ipolicy,rtrim(ipolicy));
			strcpy(itag,rtrim(itag));
			strcpy(iengine,rtrim(iengine));
			strcpy(dply_begin_c,rtrim(dply_begin_c));
			strcpy(dply_end_c,rtrim(dply_end_c));
			strcpy(iins_type,rtrim(iins_type));
			strcpy(nins_type,rtrim(nins_type));
			strcpy(nuser,rtrim(nuser));
			strcpy(iofficer,rtrim(iofficer));

       	flen=fprintf(fp,"%s,%s,%s,%s,%s,%s,%s,%s,%s,%ld,%ld,%ld,%ld,%ld,%s,%s,%s\n",
                        iassured,ipolicy,Today_c,itag,iengine,dply_begin_c,dply_end_c,
                        iins_type,nins_type,ins_amt3,ins_amt1,ins_amt2,mdeduct,ins_prem,nuser,iofficer, sIbrand);

	}
	$CLOSE c_cur2;
	$FREE c_cur2;
	fclose(fp);

	strcpy(exec_time, cm_get_sysd());
	$INSERT INTO rptftplist (nuserid, ipgid, noutfile, dcreate)
		VALUES ($userid, 'car601', $sfile, $exec_time);

	return M_CM_OK;

errexit:
	printf("car601_build1:err,%d",SQLCODE);
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}