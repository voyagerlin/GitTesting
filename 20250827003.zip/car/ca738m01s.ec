/*********************************************************/
/*                                                       */
/*  PROGRAM: ca738m01s.ec                                */
/*                                                       */
/*********************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "is_def.h"
#include <string.h>
#include <stdlib.h>
#include <time.h>
$include sqlca;
$include datetime.h;
#include "cmprint.h"
#include "safeclib.h"

char   tmpbuf[4000];
$char  dreprint[11];
$int   qreprint;
$char  DBName[5],type[2], sfile[20], ptype[6];
$char  buff[250],stmt[1000], sStmt[1024], stmt_type[500];
$char  ipolicy[21], nassured[80], itag[CA_TAG_NUM], iengine[CA_ENGINE_NUM], ipro_year[6];
$char  nuser[19]; /* Add by Julia Han in 2007/02/07 */
$char  nbrand[40], dbegin[13], dend[13], aassured[100], aassured_zip[10];
$char  ibrand[11], sibrand[11], sipro_year[6], fassured[2], fsex[2];
$char  ibig_branch[25], itel[16], ibig_office[6], ipolicy1[21], ipolicy2[21];
$char  comp_DB[3],icard_A[21],iofficer[11],nassured_x[80];


/** time **/
struct tm *currenttime;
time_t bintime;
char   strtime[20];

$char  param1[21], param2[21],pro_no1[6],sNoPlyB[2] ,sbus_source[11] ;

int  cm_get_serial_num_dwritten();


static char *get_car_full_db();
int rptftpinsert();
int    strSearchReplace();

long car738(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
     long rtncode;
     long car738_query();
     long car738_chk_edr_close();
     char option;

     cm_buf_init(command);
     cm_buf_get("%c",&option);
     switch(option)
     {
         case 'Q':
             rtncode=car738_query(reply);
             break;

         case 'E':
             rtncode=car738_chk_edr_close(reply);
             break;
               
         default :
             if(exitsub(reply,M_CM_WRONG_OPTION) == True)
                 return M_CM_WRONG_OPTION;
             return apiRC;
     }
     

     return(rtncode);
}

long car738_query(reply)
serverReply reply;
{
    int    rtn,pos,rc, rt;
    int    tmp_len, count, no_pay_cnt=0, pay_cnt=0;
    $char  Full_DBName[20], ipolicy_A[20];
    $char  payresult[5], paystatus[100], paydate[100], notedate[100], sIinsType[4];
    $char  sNinsType1[29];
    $long  ldend = 0, lMinjured_cover = 0, lMdeath_cover = 0, lMdamage_cover = 0;
    $int   qnext_year = 0, iCountDtl, qserial;
    int    i_ptype;
    char   errmsg[121],userid[10];
    $long  lDaily_pay;
    $char  iins_scope[2];
    $char  yy1[4], mm1[3],dd1[3],yy2[4], mm2[3],dd2[3],dperiod[31];
    $char  sToday1[11],sToday2[11],inumber[14],idb[3], iversion[2], stmpx[2000];
    $char  fdeduct[2],f86[2],drate_ym[6],icar_type[3];
    $int   deduct = 0,iins;
    $char  deduct_print[21],str_deduct[20],prn_deduct[121],tmp_deduct[20],deduct_30[11],Msg[121],ipolicy_2[3];
    $int   res,rc2;

    cm_buf_get("%s %s %s %s %s ",DBName, type, sfile, param1, param2 );
    cm_buf_get("%s %s", ptype, userid);
   
    printf(" car738_query \n");    

    $WHENEVER SQLERROR GOTO errexit;
        
    /* type :�w�T�w�� 2 (1:���ɮ� 2:�̫O�渹)*/
    /* ptype:�w�T�w�� Z00 */
    


    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }
     
    $BEGIN WORK;
     
    printf("Trace -- param1 = [%s] \n",  param1);
    printf("Trace -- param2 = [%s] \n",  param2);

    strcpy(ipolicy1, trim(param1));
    strcpy(ipolicy2, trim(param2));     	 
        

    $CREATE TEMP TABLE CAR738
    (
        ipolicy  char(21) default ' '
    )
    WITH NO LOG;

    $CREATE INDEX CAR738_ix1 ON CAR738 (ipolicy);

   

    if(strcmp(trim(ipolicy1),"") != 0 )
    {
        printf("INSERT ipolicy1[%s]\n", ipolicy1 );
     	$INSERT INTO CAR738 VALUES($ipolicy1);
    }
     	
    if(strcmp(trim(ipolicy2),"") != 0 )
    {
        printf("INSERT ipolicy2[%s]\n", ipolicy2 );
     	$INSERT INTO CAR738 VALUES($ipolicy2);
    }
    
	
    
    cm_buf_init(ReplyBuf);
    cm_buf_res_msg();
    cm_buf_res_count();
   

    printf("\n\n=================\n");
     
    sprintf_s(sStmt, sizeof sStmt,"select sbus_source from officer where iofficer = ?");
    $PREPARE curOff FROM $sStmt;
  	 
    count=0;
    $DECLARE curx CURSOR for
      SELECT ipolicy
        INTO $ipolicy 
        FROM CAR738;
    $OPEN curx;
    while(1)
    {
        $FETCH curx;
        if(SQLCODE == SQLNOTFOUND) break;
     
        if( strlen(trim(ipolicy)) == 0 ) continue;
    
        strcpy(Full_DBName,get_car_full_db(ipolicy));
        strncpy(ipolicy, trim(ipolicy),13); 
        printf("ipolicy[%s]\n", ipolicy );
         
        /* �Y�O "���s��O���ҹq�l��", �h�����z�L officer�� sbus_source ���o���� "�M�ץN�X"��, �A����ӱM�׬��������   */
        sprintf_s(sStmt, sizeof sStmt,
                  "SELECT a.ipolicy, a.dply_begin, a.dply_end, a.ipro_year, a.ibrand,  "
                  "       b.nassured, b.nuser, b.itag, b.iengine, b.aassured, b.aassured_zip,  "
                  "       b.fassured, b.fsex, a.ibig_office[1,3], a.icomp_in, a.dply_end,  "
                  "       a.qnext_year, trim(a.icard) || '-A' ,a.iofficer,  "
                  "       a.icar_type  "
                  " FROM %s:ply_relation a , %s:policy b  "
                  "WHERE a.ipolicy = '%s' and a.ipolicy = b.ipolicy "
                  "  AND a.fedr_class <> '1' ", 
                  Full_DBName, Full_DBName, ipolicy );
        
        printf("stmt[%s]\n", sStmt);
 
        $PREPARE cura1 FROM $sStmt;
     	$EXECUTE cura1 INTO $ipolicy, $dbegin, $dend, $ipro_year, $ibrand,
     	                    $nassured, $nuser, $itag, $iengine, $aassured, $aassured_zip, 
     	                    $fassured, $fsex, $ibig_office, $comp_DB, $ldend, $qnext_year,
                            $icard_A,$iofficer,$icar_type;

        if(SQLCODE == SQLNOTFOUND)
        {
            continue;
        }
     	printf("===>ply_relation ok\n");
     	 
     	strcpy(ipolicy_A  , " ");
     	strcpy(sbus_source, " ");
     	   
       

     	strcpy(sbus_source,trim(sbus_source));
     	/**********  check ��A��O�_�w���O  ***********/
     	 
     	 
     	/**********  �t�P�������  ***********/
    	$DECLARE cur_model CURSOR for
     	  SELECT ibrand, ipro_year, nbrand
     	    INTO $sibrand, $sipro_year, $nbrand
     	    FROM ca_car_model 
     	   WHERE ibrand = $ibrand 
     	   ORDER BY ipro_year desc;
     	$OPEN cur_model;
     	$FETCH cur_model;
     	$CLOSE cur_model;
     	 
     	printf("--->ca_car_model ok\n");
     	strcpy(nassured, trim(nassured));
     	strcpy(nassured_x, nassured); /* �S���[�ٿת��O��W�� */
     	strcpy(nuser, trim(nuser));

     	 
     	/* N*�g��S�O�P�_ add by sylvia 103.09.18 */
     	if (iofficer[0] = 'N')
     	{
     	    /* ��A�欰A*�g�쪺�~�� */
     	    $select iofficer[1,3] into $ibig_office
     	       from ca_promote_officer
     	      where iofficer_ori = $iofficer
     	        and iofficer[1,1] = 'A';
     	}
     	/* ---------------------------------------------------------------- */
     	$SELECT ibig_branch, itel
     	   INTO $ibig_branch, $itel
     	   FROM ca_big_office
     	  WHERE fclass = '1'
     	    AND ibig_comp = $ibig_office;
        if(SQLCODE == SQLNOTFOUND)
        {
            ibig_branch[0] = '\0';
            itel[0] ='\0';
        }    
     	printf("ibig_branch[%s] itel[%s]\n", ibig_branch, itel );      
     	 
     	printf("***ca_big_office ok\n");
     	strcpy(dbegin, cm_from_infdate(dbegin));
     	strcpy(dend  , cm_from_infdate(dend));
     	 
         	
	cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s ",ipolicy, nassured, nuser,
	           itag, iengine, ipro_year, nbrand, dbegin, dend, 
	           aassured, aassured_zip);
	cm_buf_put("%s %s %s ",ibig_branch, itel, icar_type);           
                 
        
                     
        count++;



        strcpy(sToday1,cm_edate_str(cm_today()));
	strcpy(sToday2,cm_cdate_str_100(cm_today()));
	strncpy(ipolicy_2,ipolicy,2);  
	ipolicy_2[2]='\0';  
	res = cm_get_serial_num_dwritten("CC","NN","0",ipolicy_2,sToday1,sToday2,inumber);
	printf("res=[%d]sToday1=[%s]sToday2=[%s]inumber=[%s]\n",res,sToday1,sToday2,inumber);
	  
        sprintf_s(sStmt, sizeof sStmt,
                  "SELECT COUNT(*)  "
                  "  FROM %s:ply_ins_type  "
                  " WHERE ipolicy = '%s'", 
	          Full_DBName, ipolicy);
        
        printf("stmt[%s]\n", sStmt);

        $PREPARE prep_ins FROM $sStmt;
        $EXECUTE prep_ins INTO $iCountDtl;
        $FREE prep_ins;

        cm_buf_put("%d", iCountDtl);
        /*1050530008_C1_CAR738�ק� �s�W�y�����s�� �g�Jlog�O����*/                     

	cm_buf_put("%s",inumber);

        sprintf_s(sStmt, sizeof sStmt,
                  "SELECT a.iins_type, b.nins_type, a.drate_ym, a.mdeduct, a.minjured_cover, a.mdeath_cover, a.mdamage_cover, b.qserial, nvl(deduct_print,' '), b.fdeduct  "
                  "  FROM %s:ply_ins_type a, insurance_type b  "
                  " WHERE a.iins_type = b.iins_type  "
                  "   AND a.ipolicy = '%s'  "
                  " ORDER BY b.qserial", Full_DBName, ipolicy);
        
        printf("stmt[%s]\n", sStmt);
        iCountDtl = 0;

        $PREPARE prep_ins FROM $sStmt;
        $DECLARE cur_ins CURSOR for prep_ins;

        $OPEN cur_ins;
        for(;;)
        {
            /* 1050530008_C1_CAR738�ק� �s�W�ۭt�B */
            /* 1100709003_SC1_CAR738�W�[56�I�ت��[�����P�_ */
            $FETCH cur_ins INTO $sIinsType, $sNinsType1, $drate_ym, $deduct, $lMinjured_cover, $lMdeath_cover, $lMdamage_cover,
                                $qserial,$deduct_print,$fdeduct;
            if(SQLCODE == SQLNOTFOUND) break;
            strcpy(deduct_print, rtrim(deduct_print));
                 
            lDaily_pay = 0;
            strcpy(iins_scope," ");
            if (strncmp(sIinsType,"56",2)==0)
            {
	        sprintf_s(sStmt, sizeof sStmt,
			  "SELECT first 1 daily_pay, iins_scope  "
		          "  FROM %s:ca_pa_ply  "
		          " WHERE ipolicy = '%s' AND daily_pay != 0 "
			  , Full_DBName, ipolicy);
		        
		printf("stmt[%s]\n", sStmt);
		$prepare pre_cur_pa from $sStmt;
		$execute pre_cur_pa into $lDaily_pay, $iins_scope;             	
            }
                 
            printf("-----lDaily_pay--[%ld]\n",lDaily_pay);
            printf("-----iins_scope--[%s]\n",iins_scope);
            /*----------------------------------------------------*/
            if (strncmp(fdeduct,"1",1) == 0)
            {
                if (strcmp(trim(sIinsType),"86") == 0)
        	{
        	    $SELECT case when drate >= date('06/08/2015') then '1' else '0' end
                       INTO $f86
                       FROM ca_rate_date
                      WHERE icode  = $drate_ym
                   	AND itable = 'cover_vs_premium';
                   	
        	    if (SQLCODE == SQLNOTFOUND)  return M_CA_EXTRA_CHARGE_DRATE;
        
               	    strcpy(str_deduct,"");
               	    if (strcmp(trim(f86),"1") == 0)
                    {
	                if (deduct != 0)
	               	{
		            sprintf_s(deduct_print, sizeof deduct_print,"%d",deduct);
		            strcpy(str_deduct,deduct_print);
		            strcat(str_deduct,"%");
	                }
	                else
	                {
	                    strcpy(str_deduct,"�L");
	                }
	            }
	            else
	            {
	                strcpy(str_deduct,"�L");
	            }
        	}
        	else
        	{
        	    if ((strcmp(trim(deduct_print),"") == 0) ||(strcmp(trim(deduct_print),'\0') == 0))
        	    {
        	        sprintf_s(str_deduct, sizeof str_deduct,"%d",deduct);
                  	prn_deduct[0]=0;
      
			$SELECT prn_deduct
			   INTO $prn_deduct
			   FROM ca_dmg_mdeduct
			  WHERE icar_type=$icar_type
			    AND ideduct=$str_deduct;
        
                   	strcpy(str_deduct, trim(prn_deduct));
        	    }
        	    else
        	    {
                        strcpy(str_deduct,deduct_print);
               	    }
             	}
            }
            else
            {
                strcpy(str_deduct,deduct_print);
            }
         
            printf("str_deduct[%s] \n",str_deduct);
         	
            iins=atoi(sIinsType);
            switch(iins)
            {
                case 11: case 129: case 211: 
		    strcat(str_deduct,refmtamt(deduct,MILLIONTH));
		    strcat(str_deduct,"%");
	            break;	
         	case 28: case 128:
		    strcat(str_deduct,refmtamt(deduct,MILLIONTH));
		    strcat(str_deduct,"%");
                    break;
         	case 18:
		    strcpy(tmp_deduct,itoa(deduct));
		    strncpy(deduct_30,&tmp_deduct[2],2);
		    deduct_30[2] = '%';
		    deduct_30[3] = '\0';
		    strcpy(str_deduct,deduct_30);
		    strcat(str_deduct,"(�_��");
		    strncpy(deduct_30,tmp_deduct,2);
		    deduct_30[2] = '%';
		    deduct_30[3] = '\0';
		    strcat(str_deduct,deduct_30);
		    strcat(str_deduct,")");
	            break;
	        case 96:
	            strcpy(str_deduct,refmtamt(deduct,MILLIONTH));
                    strcat(str_deduct,"%");
	            break;
	        case 176: case 177:
	            if (deduct==0)
	            {
	                strcpy(str_deduct,"�L");
	            }
	            else
	            {
	                strcpy(str_deduct,refmtamt(deduct,MILLIONTH));
                        strcat(str_deduct,"%");	            		
	            }
	            break;
	        case 31: case 32: case 133: case 134: case 149: case 231: case 232: case 249:
	            strcpy(str_deduct,refmtamt(deduct,MILLIONTH));
	            break;
	        case 62: case 63: case 64: case 143:
	            strcat(str_deduct,refmtamt(deduct,MILLIONTH));
	            break;
	        case 107: case 141:
	            strcat(str_deduct,refmtamt(deduct,MILLIONTH));
	            break;     	
            }       
            /*------------------------------------------------------*/
                 
            cm_buf_put("%s %s %s %l %l %l %l %s", sIinsType, sNinsType1, str_deduct, lMinjured_cover, lMdeath_cover, lMdamage_cover,lDaily_pay,iins_scope);
            iCountDtl ++;
        }
        $CLOSE cur_ins;
        $FREE  cur_ins;
        
         
        rc2 = insert_ca_log("car738","P",ipolicy,inumber,"��O�ҩ��C�L",userid,Msg);
        printf("Msg[%s] rc[%d]",Msg,rc2);
        if( rc2 != M_CM_OK)
        {
            SQLCODE = rc2;
            goto errexit;
        }
    }
    $CLOSE curx;
    $FREE  curx;
      
     
    printf(" ******************************************** \n");
    printf(" -------    pay_cnt = [%d]\n " , pay_cnt);
    printf(" -------      count = [%d]\n " , count);
     
    printf(" &&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&&& \n");
    printf(" IS SAFECLIB \n"); 
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);     
     
    $DROP TABLE CAR738;
         

    printf("ReplyBuf[%s]\n", ReplyBuf);
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    {
        $ROLLBACK WORK;
        return apiRC;
    }

    $WHENEVER SQLERROR GOTO errexit;
    $COMMIT WORK;
    return api_OKComplete;

     
errexit:
    $ROLLBACK WORK;
    printf("into errexit 1 \n");
    if(exitsub(reply,SQLCODE) == True)
    {
        printf("into errexit 2 \n");
        return SQLCODE;
    }
    else
        return apiRC;
}


char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
        char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
        char sTmp_db_name[31];

        sTmp_db_name[0]='\0';
        if (*sIpolicy != '\0' && *sIpolicy !=' ')
        {
           sTmp_db_name[0]='\0';
           strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
           strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
                  USE_BRANCH_ID));
           strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
        }
  return sTmp_db_name;
}


int rptftpinsert(user,pgid,outfile)
$char *user,*pgid,*outfile;
{
   $WHENEVER SQLERROR GOTO errexit;
printf(" !!!!!!!!!!!!!!!!!!!! \n");
printf(" nuserid[%s] ipgid[%s] noutfile[%s]  \n",user,pgid,outfile);
   $insert into rptftplist
    (nuserid,ipgid,noutfile,dcreate)
    values
    ($user,$pgid,$outfile,current);
printf(" 222222222222222222 \n");
   return 0;

 errexit:
 printf("SQLCODE[%d] errmsg[%s]\n",SQLCODE,sqlca.sqlerrm);
 exit(1);
}

/*********************************************************************************************/
long car738_chk_edr_close(reply)
serverReply reply;
{
    $char DBName[5];
    $char Full_DBName[20];
    int   tmp_len;
    $char stmt1[200];
    $int  cnt_edr;

    printf(" car738_chk_edr_close \n");
    cm_buf_get("%s %s",DBName, param1);

    
    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }

    strcpy(param1, trim(param1));  
    strcpy(Full_DBName,get_car_full_db(param1));
    
    strcpy(stmt1, "");
    sprintf_s(stmt1, sizeof stmt1, 
              "SELECT count(*) FROM %s:edr_relation " 
              " WHERE ipolicy='%s' AND iendorse NOT LIKE '%%CVP%%' AND dedr_close IS NULL ",Full_DBName,param1);
    printf("stmt1[%s]",stmt1);
    $PREPARE chk_edr FROM $stmt1;
    $EXECUTE chk_edr INTO $cnt_edr;

    if(SQLCODE==SQLNOTFOUND) return apiRC;


    cm_buf_init(ReplyBuf);

    cm_buf_put("%l %d",M_CM_OK,cnt_edr);

    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;

errexit:
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}