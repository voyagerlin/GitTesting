/*-------------------------------------------------------------------
 * Program: ca328q01s.ec
 * Date   : 10/132003
 *-------------------------------------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "safeclib.h"
$include "ca3xxlib.h";
$include "var_length.h";

$include sqlca;
$include sqltypes;


$char  DBName[05], FormTp[03], MsgCode[20],ibranch_abbr[05];
 char  outputf[N_FILE+1];
$char  userid[7];
static int max_cnt;

/* form */
$char iForm_Tp[03];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];

$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;

/* file */
$char    report_file1[30],report_file2[30],sTmp[1001];
$char    sData[2][21];
 char    sApHome[30],outputf1[80],outputf2[80];
 char    prtstr[277],prtstr2[177];
 char    getfile[128],txtfile[20];
 char    itmp[10];
 FILE    *fptr,*fptr2;
 FILE    *sfp;
static   int   recLen=10240;
static   char  *bp;
 FILE    *fp;
int Len=0;
int i,d;
$int tot_count=0;

/* MAIN data */
$char  dply_yy[4], dply_mm[2], card_bgn[20], card_end[20],check[2], isign[11];
$char  sStmt[1024], Full_DBName[31];

/* ca328_body */
$char  entry[11];
$char  sIast_card[20], sIlast_ply[20], tIpolicy[20];
$char  sply_begin[11], sply_end[11], sremark[129];
$char  sIbigcomp[2], sIbranch[3], sIbus_location[11], fprop[2], dexpire[11];
$char  sImgr[2], sIleader[11],  sIquota[7], ply_num1[21], iins_type[INSURANCE_TYPE];
$char  sNassured[90], sInext_ply[20], sIcard[20], broker_tmp[10];

$char  sTmpIbranch[BRANCH_ID], sTmpIcomp[BRANCH_ID];
$char  ymd[12], sIbilling[3], ymd_Today[12], ymd_bgn[5];
$char  sFcomp_class[3], sFcomp_class_last[3], sIcode[4];
$char  sIcar_type302[3], sIcar_type[3], sFcar_class[2], sFassured302[2], sFassured[2];
$char  sIofficer[11], sIcorps[11], sIbroker[11], sIresource[2], broker1[11];
$char  iproduct[20], sIpro_year[5], sIbrand[10];
$char  sIassured[13], sIassured_ext[3], sIassured302[13], sNuser[20], sIbenef[11], sNbenef[40];
$char  sApayment[90], sApayment_zip[CA_ZIP], sAassured[90], sAassured_zip[CA_ZIP];/* 1090525004-SC1-�]�y��-�s���l���ϸ�3+3   ZIP_CODE 5+1->CA_ZIP 6+1*/
$char  sApayment_new[90], sAassured_new[90];
$char  sIdmg_rate[3], sIbrg_rate[3], sIbig_branch[5], sIbig_office[10];
$char  sIbig_sales[11], sItel[21], sIemail[50], sIply_area[11], sNbrand_abbr[13];
$char  sNcar_abbr[13], sIengine[CA_ENGINE_NUM], sIbody[CA_BODY_NUM], sItag[CA_TAG_NUM], dfpt[2];
$char  sIlicense[13], sFsex[2], sFmarriage[2];
$char  tmp_resource[2], tFstatus[2], nequipment[31],nequipment_s[31], icar_flag[2];
$char  sIcomp_at[3], sIbranch_at[3], sIcomp_in[3], sIbranch_in[3],sIbranch_in2[3];
$char  sbranch_comp[5],tmp_car_type[3], narea[51] ,iquery_num[18];
$char  iestimate_ori[21];

$long    ply1_begin, ply1_end, lComp_prem, Idply_begin;
$double  dqpt, lMcar_price;
$double  premium21_bef, readyrate21, comprate21, stablerate21, investrate21, capital21;
$double  tmp_mbusiness_21, research21, psex_age21, plia_acc21;
$double  maintain21, mmaintain21;
$double  mready21, mcompensation21, mstable21, mresearch21, mcapital21, minvest21;
$double  mbusiness21, mbus_rule21, madjcom_prem21, temp_madjcom;
$double  short_prate_21, pcommission, pagent, pdiscount, pfix_agent;
$int     qply_period, qserial, lpdmg_align, lpbrg_align, lplia_align, sQpro_month;
$long    mcommission, magent, mdiscount;
$long    premium21, ins_premium, bef_ins_premium21;
$long    injured_cover, death_cover, damage_cover;
$double  qcylinder;/* 1080902001-SC1-�Ʈ�q�X�W�p���I2��*/ 
$int     tmp_mservice, mlia_agent_1, mlia_commi_1;
$int     cnt_card, cnt_ply;
$int     policy_num, policy_cnt, card_num, error_cnt;
$date    Today;
$char    stmt[2000];
$long    i_rtn;
$long    drate_long, lTmpPremium1;
$int     rcv_fstatus;

/**  commission_agent **/
$int    mother_busi, mservice, mservice_1;
$int    mother_busi_rule, mservice_rule, mservice_1;
$char   icheck_busi[2], icheck_mservice[2], ipaid_base[2];
$char   cIins_cat[3], abn_type[2];
$double mservice_rate, mservice_rate_1, mservice_rate_2, ZA_mbusiness;
$long   premium1_24;

/* �q���M�� */
$char   sIroute[21],sIntroducer[21];
$char   sIroute_prop[3], sIroute_accept[21];
/* ���Y���~�ҥΪ��~�ȩʽ� */
$char   resource_rel[2];
$char   sPaydate[11],ftype_sp[3],sDply_begin[11],sDply_end[11],sMsg[512];

$char   sDnotifyornot[24];/*1090831006-SC1-���ʱo-�{�ҥ��x�j��q�l���ҥ���g�����mail�ˮ�  */

static  char *get_car_full_db();
void    ca328_title();
long    ca328_report();
char    filename[51];
$char   v_sMsg[15120];

/* ����/���d�T�~�ߴڦ��� */
$int iQlia_acc_sum, iQdmg_acc_sum;

/* �]��KYC���s�W�n�O�H������� add by sylvia 101.09.10 */
$char			ndeputy_assured[50+1];			/* �Q�O�I�H���k�H�N���H */
$char			fapplicant[1+1];			/* �n�O�H�ʽ� */
$char			fsex_appl[1+1];				/* �n�O�H�ʧO */
$char			dbirth1[11],dbirth2[11],tmp_birth[11];  /* �n�O�H�ͤ� */
$char			itel_appl[20+1];			/* �n�O�H�p���q�� */
$char			ndeputy_appl[50+1];			/* �n�O�H���k�H�N���H */
$char			nrelation_appl[40+1];			/* �n�O�H�P�Q�O�I�H���Y */
$char			sYY[4],sMM[3],sDD[3];
$char			iapplicant[13];				/* �n�O�HID */
$char			napplicant[121];			/* �n�O�H�W�� */

/* �s�r�[�O���� add by sylvia 103.01.13 (1020801002_C1) */
$int    iQdrunk_driving;
$long	lMdrunk_prem;
$double dblMdrunk_pure_prem;

/* ���j�H�W�[�O���� add by 061476 111.06.15 (1110608012_SC1) */
$int    iQviolate;
$long	lMviolate_prem;
$double dblMviolate_pure_prem;

$char iassured_cntry[2]  = " ";        /* �Q�O�I�H��O���O(car328��J) */
$char iapplicant_cntry[2]  = " ";      /* �n�O�H��O���O(car328��J) */

$char iassured_cntry_302[2]  = " ";    /* �Q�O�I�H��O���O(��O) */
$char iapplicant_cntry_302[2]  = " ";  /* �n�O�H��O���O(��O) */

$char nassured_cntry[51]  = " ";       /* �Q�O�I�H���y�O(car328��J) */
$char napplicant_cntry[51]  = " ";     /* �n�O�H���y�O(car328��J) */

$char sNassured_cntry[51]  = " ";      /* �Q�O�I�H���y�O(�h�~) */
$char sNapplicant_cntry[51]  = " ";    /* �n�O�H���y�O(�h�~) */

$char foccup[2]  = " ";                /* �Q�O�I�H¾/��~�O */
$char noccup[6]  = " ";                /* �Q�O�I�H¾/��~�N�� */
$char applicant_foccup[2]  = " ";      /* �n�O�H¾/��~�O */
$char applicant_noccup[6]  = " ";      /* �n�O�H¾/��~�N�� */

$char rba_HG[2],rba_dbirth[11],rba_dbirth_appl[11];

char iassured_cntry_rba[2]= " ",iapplicant_cntry_rba[2]= " ";

$char stmt_tmp1[2048],stmt_tmp2[2048];
$char tmobile_appl[21],aemail_appl[51]; /* �n�O�H������X�Bemail */
$char mobil_phone[21];

$char fecard[2] = " ";                  /* �O�_�q�l */
$char aemail_eply[51] = " ";            /* �j��q�l����email */
$char ireg_no[21] = " ";
/*�j��q�l���Ҩ���*/
$char  tmp_car_type2[3],tmp_cardyear[3],tmp_char[2],tmp_char_out[2],tmp_office[2],tmp_office1[2],tmp_char_car[2];
$char  dissue_card[11],card_Msg[256],stmt_buf[2048];
$int   c_ca_office = 0;


main(argc,argv)
int argc;
char **argv;
{
    int rc;

    batchinit();
    strcpy(DBName,           isNULLstr(argv[1]));
    strcpy(userid,           isNULLstr(argv[2]));
    strcpy(dply_yy,          isNULLstr(argv[3]));
    strcpy(dply_mm,          isNULLstr(argv[4]));
    strcpy(card_bgn,         isNULLstr(argv[5]));
    strcpy(card_end,         isNULLstr(argv[6]));
    strcpy(filename,         isNULLstr(argv[7]));
    strcpy(check,            isNULLstr(argv[8]));	/*check=1 �䲼ú��*/
    strcpy(isign,            isNULLstr(argv[9]));  
    strcpy(foccup,           isNULLstr(argv[10]));
    strcpy(noccup,           isNULLstr(argv[11]));
    strcpy(applicant_foccup, isNULLstr(argv[12]));
    strcpy(applicant_noccup, isNULLstr(argv[13]));
   
    strcpy(outputf,  isNULLstr(argv[14]));

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False) 
    {
        EWRITE(userid, M_CM_DB_NOTOPEN,"M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }

    strcpy( localdb, DBName );
    strcpy( entry  , userid );
    rtoday(&Today);
    printf("------ before ca328_build() -------\n");
    printf("-- trace foccup[%s]\n ",foccup);
    printf("-- trace noccup[%s]\n ",noccup);
    printf("-- trace applicant_foccup[%s]\n ",applicant_foccup);
    printf("-- trace applicant_noccup[%s]\n ",applicant_noccup);
    

    rc = ca328_build();
    printf("--167--- rc - [%d] ----- \n",rc);
    if (rc == M_CM_OK)
    {
        if ((rc=save_form_info(F_BLK1, "CA", 328, userid, iForm_Tp, max_cnt,outputf))<0) 
        {
            strcpy(MsgCode,"save_form_info failed");
            return rc;
        }
    }

    exit(0);


errexit:
    printf("car328_err:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    $WHENEVER SQLERROR CONTINUE;     /* reset error handling */
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}


long ca328_build()
{
    $char  TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
    int    rc;
    $WHENEVER SQLERROR GOTO errexit;

    $SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row,
            kTot_Col, kPgNum_Line, kWidth, iForm_Tp
       INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow,
            $TotColumn, $PgLine, $Width, $iForm_Tp
       FROM Form
      WHERE ksys_grp = 'CA' AND kPgmID = 328 ;

    strcpy( TitleFmt,rtrim(TitleFmt));
    strcpy( BodyFmt,rtrim(BodyFmt));

    sprintf_s( TitleFile,sizeof TitleFile,"%s.ti",outputf);
    sprintf_s( BodyFile,sizeof BodyFile,"%s.bd",outputf);

    printf("------ start ca328_build() -------\n");
    printf("TitleFmt[%s] TitleFile[%s] \n", TitleFmt, TitleFile );
    printf("BodyFmt [%s] BodyFile [%s] \n", BodyFmt,  BodyFile  );

    rgu_init_report(TitleFmt,TitleFile);
    ca328_title();
    rgu_finish_report();

    rgu_init_report(BodyFmt,BodyFile);
    printf("---216--- before ca328_body() -------\n");
    rc = ca328_body();
    if (rc != M_CM_OK) 
    {
        EWRITE(userid,rc, v_sMsg);
        return rc;
    }
    rgu_finish_report();

    return M_CM_OK;

errexit:
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}


void ca328_title()
{
    rgu_put_head();
}

long ca328_body()
{
    int     rc, fRtnCode;
    long    code;
    int     yy1,yy2,mm1,mm2;
    char    cyy1[5],cyy2[5],cmm1[3],cmm2[3];
    char    sTmpyy1[4], sTmpmm1[3], sTmpdd1[3];  /* dply_begin */
    char    sTmpyy2[4], sTmpmm2[3], sTmpdd2[3];  /* dply_end   */
    $int    seqo, iCount;
    $char   iyear[2];
    char    fcheck[2];  /* fcheck==Y�ˮֱj���I��������O, N:���ˮ� */
    $char   comp_fassured[2], dissue[11];
    char    fbusiness[2], ibroker_top[11];
    char    tmp_icorps[18];
    $long   idate;
    $char   estimatei[21], ftype_pol[3], Iroute12[3];
    $int    icount_JC, icount_SP, iCntSP1, iCntSP2, iCntSP3, iCntSP4, iCntSP5;
    $char   ftrans_trade[2];
   
    /* �ȧ��|�Ψ�H�U��ơA�O��P���� CALL Cal_prem_21�A�O��u�O�n�ŦX�Ѽƶǻ� */
    /* 1�~���k�w�`�O�O, ��1�~�W��[�k�w]�~�Ⱥ޲z�O��, 1�~���O�氷�����O�I�O��, ��1�~��ñ��~�ȶO��, ��1�~���ά�o�O��*/
    $double  lFirstYear_bef, tmp_mbusiness_21, maintain21, ZA_mbusiness_1, research21;
    /* 2�~���k�w�`�O�O, ��2�~�W��[�k�w]�~�Ⱥ޲z�O��, 2�~���O�氷�����O�I�O��, ��2�~��ñ��~�ȶO��, ��2�~���ά�o�O��*/
    $double  lSecondYear_bef, dblSy_mbusiness, secMaintain21, ZA_mbusiness_2, secResearch21;
    /* 3�~���k�w�`�O�O, ��3�~�W��[�k�w]�~�Ⱥ޲z�O��, 3�~���O�氷�����O�I�O��, ��3�~��ñ��~�ȶO��, ��3�~���ά�o�O��*/
    $double  lThirdYear_bef, dblSy_mbusiness_3, thirdMaintain21, ZA_mbusiness_3, thirdResearch21;
    /* 4�~���k�w�`�O�O, ��4�~�W��[�k�w]�~�Ⱥ޲z�O��, 4�~���O�氷�����O�I�O��, ��4�~��ñ��~�ȶO��, ��4�~���ά�o�O��*/
    $double  lFourthYear_bef, dblSy_mbusiness_4, fourMaintain21, ZA_mbusiness_4, fourResearch21;
    /* 5�~���k�w�`�O�O, ��5�~�W��[�k�w]�~�Ⱥ޲z�O��, 5�~���O�氷�����O�I�O��, ��5�~��ñ��~�ȶO��, ��5�~���ά�o�O��*/
    $double  lFifthYear_bef, dblSy_mbusiness_5, fifMaintain21, ZA_mbusiness_5, fifResearch21;

    $char   f990301[2], iabn_type[2];

    /* 1000311003 �q��2 */
    $char     irate_type[2],bzfrom[3],iroute_comm[4],icomm_obj[11];
    $char     icheck_disc[2], icheck_commi[2], icheck_agent[2], itype_disc[2];
    $char     opt[2], fstart[2], fauth[2];
    $double   min_mother_busi,min_mother_busi_C0,
              min_mother_busi_M1,min_mother_busi_M2,min_mother_busi_Y1,min_mother_busi_Y2,min_mother_busi_Y3,min_mother_busi_V0;
    $char     stmp[21],fNewCompBusi[2],chk302_New[2];
    $char     iref_num1[21],idata_type[2],imember[11],nmember[101],icountry[6],idept[11],ibranch_leader[3],iquota_leader[7],ftype_batch[2],iins_class_batch[3];
    $datetime year to second dt_current;
    $date     dbirth_batch;
    $int      fkind_batch, fstatus_batch,tmpCount;
    int       iLoop_end;
    $int      ifresonB = 0; /* 1071029004_SC1_�s�W���sCAR102�Ȥ���@�ɲ�10��---����W��H�� */
    $int      iChk_JC;/* 1080307002-SC1-��౻T-CAR301�W�CJC�q���X���ˮ� */
    $int      icount_direct = 0 ;  /* 1080730006-SC2-��౻T-������O���x����O�@�~�ݨD*/
    $int      ftrans_check = 0; /* �ĤT��ǿ���O (1110303014_SC1) */
    $char     v_chk_msg[2];/*1090207006-SC2-���ɮi-�O��үd�s���q�T���(�t�q�l�l��H�c�a�}�q�ܤ��)���ޱ�*/
    int       fchkid = 0;
    $WHENEVER SQLERROR goto errexit;


    printf("----- start ca328_body() ------ \n");
    policy_cnt = 0;
    error_cnt  = 0;

    strcpy( fcheck, "Y");
    strcpy( chk302_New, "Y"); 

    yy1 = atoi( dply_yy );
    yy1 = yy1 + 1911;
    mm1 = atoi( dply_mm );

    if( mm1 == 12 )
    {
        yy2 = yy1 + 1;
        strcpy( cmm1 , "01" );
        strcpy( cmm2 , "01" );
        strcpy( cyy1 , itoa(yy1));
        strcpy( cyy2 , itoa(yy2));


        printf("cmm1[%s] cmm2[%s] cyy1[%s] cyy2[%s]\n", cmm1, cmm2, cyy1, cyy2 );
    }
    else
    {
        mm2 = mm1 + 1;
        yy2 = yy1;
        strcpy( cyy1 , itoa(yy1));
        strcpy( cyy2 , itoa(yy2));

        if ( mm1 < 10 )
            sprintf_s( cmm1 ,sizeof cmm1, "0%s", itoa(mm1));
        else
            strcpy( cmm1 , itoa(mm1));

        if (mm2 < 10 )
            sprintf_s( cmm2 ,sizeof cmm2, "0%s", itoa(mm2));
        else
            strcpy( cmm2 , itoa(mm2));

    }

    sply_begin[0] = '\0';
    strncpy(sply_begin, cmm1,2);
    strcat(sply_begin, "/01/");
    strncat(sply_begin, cyy1,4);

    sply_end[0] = '\0';
    strncpy(sply_end, cmm2,2);
    strcat(sply_end, "/01/");
    strncat(sply_end, cyy2,4);
    strcpy(ymd_Today, cm_cdate_str_100(cm_today()));

    printf("sply_begin [%s] sply_end [%s]\n",sply_begin, sply_end );
    printf("\n =================================== \n");
   
    /* 1050812001_C2 �j���I�����~���u�f */
    /* ���o�j���I�u�����O�v�v���̤֤������B�G
	      �E 73�� (�T��)
	      �E 60�� (�����@�~��)
	      �E 80�� (�����G�~��)   
    */
    strcpy(stmp," ");
    min_mother_busi_C0 =  0.0;
    min_mother_busi_M1 =  0.0;
    min_mother_busi_M2 =  0.0;
    min_mother_busi_Y1 =  0.0;
    min_mother_busi_Y2 =  0.0;
    min_mother_busi_Y3 =  0.0;
    min_mother_busi_V0 =  0.0;
    
    $DECLARE curCode CURSOR for
      SELECT detail,detail2::float from car_code
       WHERE kind = 'CD' ;
    $OPEN curCode;
    while(1)
    {
        $FETCH curCode INTO $stmp,$min_mother_busi;
        if(SQLCODE == SQLNOTFOUND) break;
      	
        if (strncmp(stmp,"C0",2)==0)
        {
            min_mother_busi_C0 = min_mother_busi;
        }
        else if (strncmp(stmp,"M1",2)==0)
        {
      	    min_mother_busi_M1 = min_mother_busi;
        }
        else if (strncmp(stmp,"M2",2)==0)
        {
            min_mother_busi_M2 = min_mother_busi;
        }
        else if (strncmp(stmp,"Y1",2)==0)
        {
            min_mother_busi_Y1 = min_mother_busi;
        }
        else if (strncmp(stmp,"Y2",2)==0)
        {
            min_mother_busi_Y2 = min_mother_busi;
        }
        else if (strncmp(stmp,"Y3",2)==0)
        {
            min_mother_busi_Y3 = min_mother_busi;
        } 
        else if (strncmp(stmp,"V0",2)==0)
        {
            min_mother_busi_V0 = min_mother_busi;
        }    	      	
    }   	
    $CLOSE curCode;
    $FREE  curCode;
             
    /* �إ�Temp Table */
    printf("----- �إ�Temp Table ------ \n");
    rc = ca328_create_table();
    if ( rc != M_CM_OK )
    {
        printf("create temp table error \n");
        return rc;
    }

    /* Ū����J���ɮ׸�� */
    printf("----- Ū����J���ɮ׸�� ------ \n");
    rc = ca328_getfile();
    if( rc != M_CM_OK )
    {
        printf(" get file error \n");
        return rc;
    }

    /* �إ� card_temp ��� */
    if(strcmp(trim(card_bgn),"")!=0 && strcmp(trim(card_end),"")!=0)
    {
        rc = ca328_set_cardtemp();
        printf("----- �إ� card_temp ��� ------ \n");
        if( rc != M_CM_OK )
        {
            printf("set card_temp data error \n");
            return rc;
        }
    }

    /* �إ� policy_temp ���*/
    printf("----- �إ� policy_temp ��� ------ \n");
    rc = ca328_set_policytemp();
    if( rc != M_CM_OK )
    {
        printf("set policy_temp data error \n");
        return rc;
    }

    /* 1060821005_C2_�j���Һ޲z�{�� */ 
    /* �i��X���ˮ֡B���� */
    sprintf_s(sStmt,sizeof sStmt,
              "SELECT first 1 icard , fstatus FROM card_temp "
              " WHERE fstatus in ('0','5','6' ) ");
    $PREPARE cur_card FROM $sStmt;

    /*====================================================*/
    /* Start Program */
   

    printf("Start Program \n");
    $WHENEVER SQLERROR goto errexit;

    $DECLARE curA CURSOR WITH HOLD for
      SELECT ilast_card, ilast_ply, itag, seqo, iofficer, iroute, mother_busi, mservice,
             iapplicant, napplicant, ndeputy_assured, fapplicant, fsex_appl, dbirth_app, itel_appl,
             ndeputy_appl, nrelation_appl, fecard, aemail_eply, ireg_no,
             (select count(*) from car_code where kind='63'  and detail = iroute), tmobile_appl, aemail_appl,
             iassured_cntry, nassured_cntry, iapplicant_cntry, napplicant_cntry
        FROM policy_temp;
    $OPEN curA;
    while(1)
    {
        $FETCH curA INTO $sIast_card, $sIlast_ply, $sItag, $seqo, $sIofficer, $sIroute, $mother_busi, $mservice,
                         $iapplicant, $napplicant, $ndeputy_assured, $fapplicant, $fsex_appl, $dbirth2, $itel_appl,
                         $ndeputy_appl, $nrelation_appl, $fecard, $aemail_eply, $ireg_no,
                         $icount_direct, $tmobile_appl, $aemail_appl,
                         $iassured_cntry, $nassured_cntry, $iapplicant_cntry, $napplicant_cntry;
        if(SQLCODE == SQLNOTFOUND) break;

        printf("sIast_ply [%s], mservice[%d] \n",sIlast_ply, mservice );
        printf("fecard[%s] aemail_eply[%s] \n",fecard,aemail_eply);
        strcpy(sremark," ");
        strcpy(v_sMsg," ");  

        strcpy(iapplicant, trim(iapplicant));    
        strcpy(aemail_eply,trim(aemail_eply));
        
        
        if( strcmp(trim(sIlast_ply),"SystemBusy") == 0 ) 
        {
            strcpy(sremark,"�t�Φ��L���A�еy�ԦA�դ@��");
            $UPDATE policy_temp
                SET remark = $sremark,
                    ilast_ply = " "
              WHERE itag = $sItag
                AND seqo = $seqo;

            error_cnt++;
            continue;
        }
        
        if( strlen(trim(sIlast_ply)) == 0 )
        {
            strcpy(sremark,"�o�x�����b�������q��O");
            $UPDATE policy_temp
                SET remark = $sremark
              WHERE itag = $sItag
                AND seqo = $seqo;

            error_cnt++;
            continue;
        }
        
        if (icount_direct > 0) 
        {
            strcpy(sremark,"���}�񪽱���O���x����O�@�~");
            $UPDATE policy_temp
                SET remark = $sremark
              WHERE itag = $sItag
                AND seqo = $seqo;
            error_cnt++;
            continue;
        }
        
        /* �Y�D�q���N�����q�T����ˮֵ��O��Y�A�h�ݩ�car301�浧�X�� (1110303014_SC1) */
        $SELECT count(*) into $ftrans_check
           FROM cm_route a, cm_route b
          WHERE a.iroute = b.iroute_main 
            AND a.ftrans_check = 'Y'
            AND b.iroute = $sIroute;   
        
        if (ftrans_check > 0)
        {
            strcpy(sremark , "�q�T����ˮֵ��O��Y�A�г浧�X����[�~����Ʀ@��]���");
            $UPDATE policy_temp
                SET remark = $sremark
              WHERE itag = $sItag
                AND seqo = $seqo;
                
            error_cnt++;
            continue;
        }
        
        iQdrunk_driving = 0;
        lMdrunk_prem = 0;
        dblMdrunk_pure_prem = 0.0;
        iQviolate = 0;
        lMviolate_prem = 0;
        dblMviolate_pure_prem = 0.0;

        /* A.�ˮ� */
        /* 1.1 ��O�J�p�D��policy_302 */
        $SELECT ipolicy, dply_begin, dply_end, fcomp_class,
                fcomp_class_last,  comp_prem, icar_type, fcar_class, fassured,
                qpt, psex_age_c, plia_acc_c, qply_period, dissue,
                ibrand, ibig_branch, nvl(ibig_office,' '),
                nvl(ibig_sales,' '),
                itel, iemail, iply_area, nbrand_abbr, ncar_type, qcylinder,
                iengine, ibody, itag, pdmg_align, pbrg_align, plia_align, fpt, ilicense,
                qdrunk_driving, iquery_num_c, iestimate_ori, iassured_cntry, iapplicant_cntry,
                CASE WHEN dply_begin >= '11/01/2016' THEN 'Y' ELSE 'N' END as chk302_New,
                imovephone, qviolate
           INTO $tIpolicy, $ply1_begin, $ply1_end, $sFcomp_class,
                $sFcomp_class_last, $lComp_prem, $sIcar_type302, $sFcar_class, $sFassured302,
                $dqpt, $psex_age21, $plia_acc21, $qply_period, $dissue,
                $sIbrand, $sIbig_branch, $sIbig_office, $sIbig_sales,
                $sItel, $sIemail, $sIply_area, $sNbrand_abbr, $sNcar_abbr, $qcylinder,
                $sIengine, $sIbody, $sItag, $lpdmg_align, $lpbrg_align, $lplia_align, $dfpt, $sIassured302,
                $iQdrunk_driving, $iquery_num, $iestimate_ori, $iassured_cntry_302, $iapplicant_cntry_302, 
                $chk302_New,
                $mobil_phone, $iQviolate
           FROM policy_302
          WHERE ipolicy = $sIlast_ply
            AND fcard_class = '1'
            AND dply_begin >= $sply_begin
            AND dply_begin <  $sply_end;

        if( SQLCODE == SQLNOTFOUND )
        {
      	    sprintf_s(sremark,sizeof sremark,"[%s]��O��Ƨ䤣��", sIlast_ply);
      	    $UPDATE policy_temp
      	        SET remark = $sremark
      	      WHERE ilast_ply = $sIlast_ply
      	        AND seqo = $seqo;

      	    error_cnt++;
      	    continue;
        }
        
        /* 1110401004_SC1_�ק�CAR328�ˮֳW�h */
        /* 1110518007_SC1_�����Q�O�H�ˮ� */

        if ((strlen(trim(aemail_appl))==0) && (strlen(trim(tmobile_appl))==0))
        {
      	    sprintf_s( v_sMsg,sizeof v_sMsg,"�n�O�H�������E-MAIL���o�����ŭ�(�ܤ֭n��J�@��)");
      	    $UPDATE policy_temp
      	        SET remark = $v_sMsg
      	      WHERE ilast_ply = $sIlast_ply
      	        AND seqo = $seqo;
     	  
     	    error_cnt++;
     	    continue; 
        }
      
        strcpy(sIengine, rtrim(sIengine));
        strcpy(sIbody  , rtrim(sIbody));
      
        strcpy(Full_DBName,get_car_full_db(sIlast_ply));

        printf("Full_DBName[%s]\n", Full_DBName);

        sStmt[0]='\0';
        sprintf_s(sStmt,sizeof sStmt,
                  "SELECT a.ibroker, a.iresource, b.nassured, b.iassured, "
                  "       b.iassured_ext, b.nuser, b.ibenef, b.nbenef, b.apayment, "
                  "       b.apayment_zip, b.aassured, b.aassured_zip, b.idmg_rate, "
                  "       b.ibrg_rate, b.ilicense, b.dbirth, b.fsex, b.fmarriage, "
                  "       mcar_price, a.ibranch, icar_type, fassured,  "
                  "       b.introducer, b.iroute_prop, b.iroute_accept, itag, "
                  "       b.nassured_cntry, b.napplicant_cntry, a.ipro_year, b.qpro_month "
                  "  FROM %s:ply_relation a , %s:policy b "
                  " WHERE a.ipolicy = b.ipolicy AND a.ipolicy = '%s' ",
                  Full_DBName, Full_DBName, sIlast_ply );

        printf("sStmt[%s]\n", sStmt);

        $PREPARE curC FROM $sStmt;
        $EXECUTE curC INTO
                    $sIbroker, $sIresource, $sNassured, $sIassured,
                    $sIassured_ext, $sNuser, $sIbenef, $sNbenef, $sApayment,
                    $sApayment_zip, $sAassured, $sAassured_zip,  $sIdmg_rate,
                    $sIbrg_rate, $sIlicense, $dbirth, $sFsex, $sFmarriage,
                    $lMcar_price, $sIbranch, $sIcar_type, $sFassured,
                    $sIntroducer, $sIroute_prop, $sIroute_accept, $sItag,
                    $sNassured_cntry,$sNapplicant_cntry, $sIpro_year, $sQpro_month;

        /** C.��s policy_temp ������� **/
        strcpy(sIassured, trim(sIassured));
        /* 1071029004_SC1_�s�W���sCAR102�Ȥ���@�ɲ�10��---����W��H�� */
        strcpy(sNassured,rtrim(sNassured));  /* �h���k��ťեH�Q��� */
        strcpy(napplicant,rtrim(napplicant));
        strcpy(sItag,trim(sItag));

        $UPDATE policy_temp
            SET (nassured, iofficer, dply_begin, dply_end, fcomp_class,
                 fcomp_class_last, icar_type, iassured, 
                 qdrunk_driving, qviolate)
              = ($sNassured, $sIofficer, $ply1_begin, $ply1_end,
                 $sFcomp_class, $sFcomp_class_last, $sIcar_type, $sIassured, 
                 $iQdrunk_driving, $iQviolate)
          WHERE ilast_ply = $sIlast_ply
            AND seqo = $seqo;
          
          
        /* 1071029004_SC1_�s�W���sCAR102�Ȥ���@�ɲ�10��---����W��H�� */
        ifresonB = 0;
        $SELECT nvl(sum(decode(freason,'B',1,0)),0)  
           INTO $ifresonB
           FROM reject_client
          WHERE (dexpire is null or dexpire > today)
            AND ( nassured = case when trim(nassured)='' then NULL else $sNassured end
         	   or nassured = case when trim(nassured)='' then NULL else $napplicant end
                   or ilicense = case when trim(ilicense)='' then NULL else $sIlicense end
                   or ilicense = case when trim(ilicense)='' then NULL else $iapplicant end
                   or itag = case when trim(itag)='' then NULL else $sItag end
                   or iengine = case when trim(iengine)='' then NULL else $sIengine end
                   or ibody = case when trim(ibody)='' then NULL else $sIbody end);
      
        printf("--630 ifresonB[%d] seqo[%d]\n", ifresonB,seqo);
        if (ifresonB > 0)
        {
	    strcpy(sremark,"�S���Ӯ׽Ь��ӫO��");
	    printf("--634 sIlast_ply[%s] \n", sIlast_ply );
	    printf("--634 sIcard[%s] \n", sIcard );
	    printf("--635 sremark[%s] \n", sremark );
	    
	    $UPDATE policy_temp
      	        SET remark = $sremark
      	      WHERE itag = $sItag 
      	        AND seqo = $seqo;

      	    error_cnt++;
	    continue;
        }
        
        /* 1080307002-SC1-��౻T-CAR301�W�CJC�q���X���ˮ� */
        iChk_JC=0;
        if (strncmp(substring(sIroute,1,2),"JC",2)==0) 
        {
            $SELECT count(*)
               INTO $iChk_JC
               FROM car_code
              WHERE kind ='26'
                and detail =$sIassured;
            if ((SQLCODE == SQLNOTFOUND ) || (iChk_JC==0))
            {
                strcpy(sremark,"JC�q���N���ݤ��a�����~�ȾA��,���Q�O�I�HID���g�ӫO�����ɩ�CAR140,�q�гq���ӫO��-�~�Ȧ�F��i����ɧ@�~�l�i��zñ��");
                printf("--CHK JC sIroute[%s] \n", sIroute );
                printf("--    sIassured[%s] \n", sIassured );
                printf("--    sremark[%s] \n", sremark );
                $UPDATE policy_temp
                    SET remark = $sremark
                  WHERE itag = $sItag 
                    AND seqo = $seqo;
                error_cnt++;
                continue;                
            }
        }
      
        /*1080408005_SC_�j��{�ҷs�W�q����Ƥεn���Ҹ� 2019.06.25 by 071004*/
        /*�ˮַ~�ȭ��n������쥲��J*/
        if(strcmp(trim(ireg_no),"")==0) 
        {

      	    strcpy(sremark,"�~�ȭ��n���Ҹ�����J");
      	    $UPDATE policy_temp
      	        SET remark = $sremark
      	      WHERE ilast_ply = $sIlast_ply
      	        AND seqo = $seqo;

	    error_cnt++;
	    continue;

        } 

        /*1080408005_SC_�j��{�ҷs�W�q����Ƥεn���Ҹ� 2019.06.25 by 071004*/
        /*�ˮַ~�ȭ��n�������ݲŦX�s�X�W�h*/
        if(strcmp(trim(ireg_no),"")!=0 ) 
        {

            if( (ireg_no[0]!='A' && ireg_no[0]!='B' && ireg_no[0]!='C'  && ireg_no[0]!='D' && ireg_no[0]!='E'  && ireg_no[0]!='F' && ireg_no[0]!='G' && ireg_no[0]!='H' &&
                 ireg_no[0]!='I' && ireg_no[0]!='J' && ireg_no[0]!='K'  && ireg_no[0]!='L' && ireg_no[0]!='M'  && ireg_no[0]!='N' && ireg_no[0]!='O' && ireg_no[0]!='P' &&
                 ireg_no[0]!='Q' && ireg_no[0]!='R' && ireg_no[0]!='S'  && ireg_no[0]!='T' && ireg_no[0]!='U'  && ireg_no[0]!='V' && ireg_no[0]!='W' && ireg_no[0]!='X' &&
                 ireg_no[0]!='Y' && ireg_no[0]!='Z' )||
                (ireg_no[1]!='A' && ireg_no[1]!='B' && ireg_no[1]!='C'  && ireg_no[1]!='D' && ireg_no[1]!='E'  && ireg_no[1]!='F' && ireg_no[1]!='G' && ireg_no[1]!='H' &&
                 ireg_no[1]!='I' && ireg_no[1]!='J' && ireg_no[1]!='K'  && ireg_no[1]!='L' && ireg_no[1]!='M'  && ireg_no[1]!='N' && ireg_no[1]!='O' && ireg_no[1]!='P' &&
                 ireg_no[1]!='Q' && ireg_no[1]!='R' && ireg_no[1]!='S'  && ireg_no[1]!='T' && ireg_no[1]!='U'  && ireg_no[1]!='V' && ireg_no[1]!='W' && ireg_no[1]!='X' &&
                 ireg_no[1]!='Y' && ireg_no[1]!='Z' && ireg_no[1]!='0'  && ireg_no[1]!='1' && ireg_no[1]!='2'  && ireg_no[1]!='3' && ireg_no[1]!='4' && ireg_no[1]!='5' &&
                 ireg_no[1]!='6' && ireg_no[1]!='7' && ireg_no[1]!='8'  && ireg_no[1]!='9' )||
                (ireg_no[2]!='0' && ireg_no[2]!='1' && ireg_no[2]!='2'  && ireg_no[2]!='3' && ireg_no[2]!='4' && ireg_no[2]!='5' && ireg_no[2]!='6' && ireg_no[2]!='7' && 
                 ireg_no[2]!='8' && ireg_no[2]!='9' )||
                (ireg_no[3]!='A' && ireg_no[3]!='B' && ireg_no[3]!='C'  && ireg_no[3]!='D' && ireg_no[3]!='E'  && ireg_no[3]!='F' && ireg_no[3]!='G' && ireg_no[3]!='H' &&
                 ireg_no[3]!='I' && ireg_no[3]!='J' && ireg_no[3]!='K'  && ireg_no[3]!='L' && ireg_no[3]!='M'  && ireg_no[3]!='N' && ireg_no[3]!='O' && ireg_no[3]!='P' &&
                 ireg_no[3]!='Q' && ireg_no[3]!='R' && ireg_no[3]!='S'  && ireg_no[3]!='T' && ireg_no[3]!='U'  && ireg_no[3]!='V' && ireg_no[3]!='W' && ireg_no[3]!='X' &&
                 ireg_no[3]!='Y' && ireg_no[3]!='Z' )||
                (ireg_no[4]!='0' && ireg_no[4]!='1' && ireg_no[4]!='2'  && ireg_no[4]!='3' && ireg_no[4]!='4' && ireg_no[4]!='5' && ireg_no[4]!='6' && ireg_no[4]!='7' && 
                 ireg_no[4]!='8' && ireg_no[4]!='9' )||
                (ireg_no[5]!='0' && ireg_no[5]!='1' && ireg_no[5]!='2'  && ireg_no[5]!='3' && ireg_no[5]!='4' && ireg_no[5]!='5' && ireg_no[5]!='6' && ireg_no[5]!='7' && 
                 ireg_no[5]!='8' && ireg_no[5]!='9' )||
                (ireg_no[6]!='0' && ireg_no[6]!='1' && ireg_no[6]!='2'  && ireg_no[6]!='3' && ireg_no[6]!='4' && ireg_no[6]!='5' && ireg_no[6]!='6' && ireg_no[6]!='7' && 
                 ireg_no[6]!='8' && ireg_no[6]!='9' )||
                (ireg_no[7]!='0' && ireg_no[7]!='1' && ireg_no[7]!='2'  && ireg_no[7]!='3' && ireg_no[7]!='4' && ireg_no[7]!='5' && ireg_no[7]!='6' && ireg_no[7]!='7' && 
                 ireg_no[7]!='8' && ireg_no[7]!='9' )||
                (ireg_no[8]!='0' && ireg_no[8]!='1' && ireg_no[8]!='2'  && ireg_no[8]!='3' && ireg_no[8]!='4' && ireg_no[8]!='5' && ireg_no[8]!='6' && ireg_no[8]!='7' && 
                 ireg_no[8]!='8' && ireg_no[8]!='9' )||
                (ireg_no[9]!='0' && ireg_no[9]!='1' && ireg_no[9]!='2'  && ireg_no[9]!='3' && ireg_no[9]!='4' && ireg_no[9]!='5' && ireg_no[9]!='6' && ireg_no[9]!='7' && 
                 ireg_no[9]!='8' && ireg_no[9]!='9' )||
                (ireg_no[4]=='0' && ireg_no[5]=='0' && ireg_no[6]=='0'  && ireg_no[7]=='0' && ireg_no[8]=='0' && ireg_no[9]=='0') )
            {
                strcpy(sremark,"�~�ȭ��n���Ҹ���J���~");
      	        $UPDATE policy_temp
      	            SET remark = $sremark
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

	        error_cnt++;
	        continue;        	
         	
            }

        }       
           
        if(fecard[0] == '0'  || strcmp(trim(fecard),"")==0) 
        {
      	    if(strlen(aemail_eply) > 0)
      	    {
      	        strcpy(sremark,"�D�j��q�l���Ҥ��i��Jemail");
      		$UPDATE policy_temp
      	            SET remark = $sremark
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

		error_cnt++;
		continue;
      	    }
        }

        if( strcmp( sIcar_type, sIcar_type302) != 0)
        {
      	    sprintf_s(sremark,sizeof sremark,"�̷s�O�樮�ػP��O�ɨ��ؤ��@�P,�г浧�X��");
      	    $UPDATE policy_temp
      	        SET remark = $sremark
      	      WHERE ilast_ply = $sIlast_ply
      	        AND seqo = $seqo;
      	    printf("sIlast_ply[%s]%s \n", sremark );

     	    error_cnt++;
      	    continue;
        }
        
        strcpy(sIassured,trim(sIassured));
        strcpy(sIassured302,trim(sIassured302));
        if( strcmp( sIassured, sIassured302) != 0)
        {
      	    sprintf_s(sremark,sizeof sremark,"�̷s�O��Q�O�I�HID�P��O�ɳQ�O�I�HID���@�P,�г浧�X��");
      	    $UPDATE policy_temp
      	        SET remark = $sremark
      	      WHERE ilast_ply = $sIlast_ply
      	        AND seqo = $seqo;
      	    printf("sIlast_ply[%s]%s \n", sremark );

     	    error_cnt++;
      	    continue;
        }
      
        /* �s�W�ˮֻs�y���0���i����O�渹 add by 061476 (1120308004_SC1) */
        if (sQpro_month == 0)
        {
      	    sprintf_s(sremark,sizeof sremark,"�e��s�y�����0,���i�X��");
      	    $UPDATE policy_temp
      	        SET remark = $sremark
      	      WHERE ilast_ply = $sIlast_ply
      	        AND seqo = $seqo;
      	    printf("sIlast_ply[%s]%s \n", sremark );

     	    error_cnt++;
      	    continue;
        }

        if( sFassured[0] != '2' && sFassured[0] != '4' && sFassured[0] != '6')
        {
      	    sprintf_s(sremark,sizeof sremark,"�̷s�O��Q�O�I�H�ʽ褣�O�k�H,���i�X��,���{���u�B�z�k�H�X��");
      	    $UPDATE policy_temp
      	        SET remark = $sremark
      	      WHERE ilast_ply = $sIlast_ply
      	        AND seqo = $seqo;
      	    printf("sIlast_ply[%s]%s \n", sremark );

     	    error_cnt++;
      	    continue;
        }

        if( strncmp(sIbrand+(3-1),"000000",6)==0 &&
            strncmp(sIbrand+(1-1),"OM",2)!=0 &&
            strncmp(sIbrand+(1-1),"MM",2)!=0 &&
            strncmp(sIbrand+(1-1),"00",2)!=0)
        {
      	    sprintf_s(sremark,sizeof sremark,"�t���N��[%s]�w���ΡA�Эץ�", sIbrand);
      	    $UPDATE policy_temp
      	        SET remark = $sremark
      	      WHERE ilast_ply = $sIlast_ply
      	        AND seqo = $seqo;
      	    printf("sIlast_ply[%s]%s \n", sremark );

     	    error_cnt++;
      	    continue;
        }
        
        printf("-- trace0 Today[%ld]\n ",Today);
        printf("-- trace0 ply1_begin[%ld]\n ",ply1_begin);
        if( ply1_begin < Today)
        {
      	    sprintf_s(sremark,sizeof sremark,"�O�����i�l��,���i�X��");
      	    $UPDATE policy_temp
      	        SET remark = $sremark
      	      WHERE ilast_ply = $sIlast_ply
      	        AND seqo = $seqo;
      	    printf("sIlast_ply[%s]%s \n", sremark );

     	    error_cnt++;
      	    continue;
        }

        /* 1.2 �ˮ֬O�_�w��O */
        sprintf_s(sStmt,sizeof sStmt,
                  "SELECT inext_ply FROM %s:ply_relation "
                  " WHERE ipolicy = '%s'",Full_DBName, sIlast_ply );

        $PREPARE curB FROM $sStmt;
        $EXECUTE curB INTO $sInext_ply;

        if( strlen(trim(sInext_ply)) > 0 )
        {
      	    /* ����O���A���ܤw��O */
      	    strcpy(sremark,"�j���I�w��O");
      	    $UPDATE policy_temp
      	        SET remark = $sremark
      	      WHERE ilast_ply = $sIlast_ply
      	        AND seqo = $seqo;
      	    printf("sIlast_ply[%s] �w��O\n", sIlast_ply );

     	    error_cnt++;
      	    continue;
        }

        $SELECT ibigcomp, ibus_location, fprop, dexpire , imgr,
                ileader,  iquota, irate_type, iroute_comm, icomm_obj
           INTO $sIbigcomp, $sIbus_location, $tmp_resource, $dexpire, $sImgr,
                $sIleader,  $sIquota, $irate_type, $iroute_comm, $icomm_obj
           FROM officer
          WHERE iofficer = $sIofficer;

        rc = cm_get_bzfrom( sIofficer, icomm_obj, irate_type, bzfrom);
        if( rc != M_CM_OK)
        {
            strcpy(v_sMsg, cm_get_errmsg( rc));
      	    $UPDATE policy_temp
      	        SET remark = $v_sMsg
      	      WHERE ilast_ply = $sIlast_ply
      	        AND seqo = $seqo;

      	    error_cnt++;
      	    continue;
        }

        strcpy( opt, "P");
        rc = cm_chk_policy( opt, sIofficer, sIleader, sIquota, icomm_obj, "C", iroute, sIroute_prop);
        if( rc != M_CM_OK)
        {
            strcpy( v_sMsg, cm_get_errmsg( rc));
      	    $UPDATE policy_temp
      	        SET remark = $v_sMsg
      	      WHERE ilast_ply = $sIlast_ply
      	        AND seqo = $seqo;

      	    error_cnt++;
      	    continue;
        }
      
        /*1090317002_SC3_�s�W�ˮֳ�j�αj+���@�߭n��J��ʸ��X��EMAIL���@*/
        if( strncmp(bzfrom,"10",2)==0 && strlen(trim(tmobile_appl))==0 && strlen(trim(aemail_appl))==0 )
        {
            strcpy( v_sMsg, "�O�o�q��[10]�A�n�O�H����έn�O�HEmail�оܤ@��J");
      	    $UPDATE policy_temp
      	        SET remark = $v_sMsg
      	      WHERE ilast_ply = $sIlast_ply
      	        AND seqo = $seqo;

      	    error_cnt++;
      	    continue;
        }   
       
        if( strlen(trim(tmobile_appl))!=0  )
        {
      	    if( strlen(trim(tmobile_appl))!=10 || strncmp(trim(tmobile_appl),"09",2)!=0 )
      	    {
                strcpy( v_sMsg, "�n�O�H����榡���~�A����09�}�Y10�X");
      	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt++;
      	        continue;      	 	
      	 	
      	    }
        }  
        
        /*1130108009_C01_�]2023��ƫ~��|ĳ�~�׷|ĳ�d�ֵ��G�A�W�[�ˮ�*/
        /*������*/
        if(strlen(trim(sIengine))!=0)
        {
            if(strlen(trim(sIengine)) < 3)
            {
                strcpy( v_sMsg, "�������X���פ��i�p��3�X");
      	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt++;
      	        continue;   
            }
            
            if( !(65 <= (int)sIengine[0] && (int)sIengine[0] <= 90)  && /*���O A-Z*/
                !(97 <= (int)sIengine[0] && (int)sIengine[0] <= 122) && /*���O a-z*/
                !(48 <= (int)sIengine[0] && (int)sIengine[0] <= 57)  && /*���O 0-9*/
                !((int)sIengine[0] == 42)                               /*���O *  */
              )
            {
                strcpy( v_sMsg, "�������X�Ĥ@�X�ݬ��^��r���μƦr��*��");
      	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt++;
      	        continue;
            }
        }
        /*������*/
        if(strlen(trim(sIbody))!=0)
        {
            if(strlen(trim(sIbody)) < 3)
            {
                strcpy( v_sMsg, "�������X���פ��i�p��3�X");
      	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt++;
      	        continue;   
            }
            
            if( !(65 <= (int)sIbody[0] && (int)sIbody[0] <= 90)  && /*���O A-Z*/
                !(97 <= (int)sIbody[0] && (int)sIbody[0] <= 122) && /*���O a-z*/
                !(48 <= (int)sIbody[0] && (int)sIbody[0] <= 57)  && /*���O 0-9*/
                !((int)sIbody[0] == 42)                             /*���O *  */
              )
            {
                strcpy( v_sMsg, "�������X�Ĥ@�X�ݬ��^��r���μƦr��*��");
      	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt++;
      	        continue;
            }
        }
        /*�Q�O�H�ʽ�*/
        if(strcmp(trim(sFassured),"2") == 0) /* 2:�ꤺ�k�H*/
        {
    	    if(strlen(trim(sIassured)) != 8 )
    	    {
                strcpy( v_sMsg, "�Q�O�H�ʽ謰[2:�ꤺ�k�H],�Q�O�HID��������8�X");
      	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt++;
      	        continue;
    	    }
    	    fchkid = 0;
    	    for(int i=0;i<=7;i++)
    	    {
    	        if ((int)sIassured[i] < 48 || (int)sIassured[i] > 57)
    	        {
      	            fchkid = 1;
      	            break;
    	        }
    	    }
    	    if (fchkid == 1)
    	    {
                strcpy( v_sMsg, "�Q�O�H�ʽ謰[2:�ꤺ�k�H],�Q�O�HID�����Ʀr");
      	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;  
      	            
      	        error_cnt++; 	
      	        continue;    	
    	    }
        }
        
        /*�n�O�H�ʽ�*/
        if(strcmp(trim(fapplicant),"2") == 0) /* 2:�ꤺ�k�H*/
        {
    	    if(strlen(trim(iapplicant)) != 8 )
    	    {
                strcpy( v_sMsg, "�n�O�H�ʽ謰[2:�ꤺ�k�H],�n�O�HID��������8�X");
      	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt++;
      	        continue;
    	    }
    	 
    	    fchkid = 0;
    	    for(int i=0;i<=7;i++)
    	    {
    	        if ((int)iapplicant[i] < 48 || (int)iapplicant[i] > 57)
    	        {
      	            fchkid = 1;
      	            break;
    	        }
    	    }
    	    if (fchkid == 1)
    	    {
                strcpy( v_sMsg, "�n�O�H�ʽ謰[2:�ꤺ�k�H],�n�O�HID�����Ʀr");
      	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;  
      	            
      	        error_cnt++;
      	        continue;
    	    } 
    	    
    	    
        }
        
      
      
        /* �P�_�q����������O�_�ҥ� */
        rc = cm_get_route_auth( "C", sIroute, sIofficer, fstart, fauth);
        if( rc != M_CM_OK)
        {
            strcpy(v_sMsg, cm_get_errmsg( rc));
      	    $UPDATE policy_temp
      	        SET remark = $v_sMsg
      	      WHERE ilast_ply = $sIlast_ply
      	        AND seqo = $seqo;

      	    error_cnt++;
      	    continue;
        }

        /* 1.5 bis9901141 �q���N���ˮֳq�L��,�Y�e��X��PE,¾�ΥN���۰ʨ��N���q���N���h��PE,
            �_�h¾�ΥN������ */
        strcpy(sIroute,trim(sIroute));
        strcpy(sIcorps,"");
        if (strncmp(sIroute,"PE",2) == 0 && fstart[0] == 'N')
        {
      	    strncpy(tmp_icorps,sIroute+2,18);
      	    tmp_icorps[18] = '\0';
      	    if (strlen(trim(tmp_icorps)) > 10)
      	    {
      	        strcpy( v_sMsg, "¾�ΥN�����o�j��10�X");
      	  	$UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt++;
      	        continue;
      	    }
            printf("tmp_icorps[%s]\n",tmp_icorps);
      	    strcpy(sIcorps,trim(tmp_icorps));
      	    
      	    /* �Y��¾�ΥN���h��¾�ΥN��+�q���N���ˮ֥��T�� */
      	    /* 1090207006-SC2-���ɮi-�O��үd�s���q�T���(�t�q�l�l��H�c�a�}�q�ܤ��)���ޱ�  
      	       car328�S��  �Q�O�H���, �Q�O�H�q��(�]),�n�O�H�q��(�]),�q�l�O�������X*/
            strcpy(v_sMsg,"");
            strcpy(sIemail,trim(sIemail));
            strcpy(aemail_appl,trim(aemail_appl));
            strcpy(aemail_eply,trim(aemail_eply));
            rc = cm_check_route_sales_comm("A",sIcorps,sIroute,"C",sIbig_sales,sIntroducer,sIroute_prop,sIroute_accept," ",
                                            sIassured,iapplicant,sIemail,aemail_appl,aemail_eply,
                                            "",sItel,"",tmobile_appl,itel_appl,"","",v_sMsg);
            if (rc != TRUE)
            {
      	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt++;
      	        continue;
            }
        } 
        else
        {
      	    sIcorps[0] = ' ';
      	    /* �Y�DPE�h�N�����O¾�Υ�,�h�ϥθg��N��+�q���N���ˮ֥��T�� */
      	    /*1090207006-SC2-���ɮi-�O��үd�s���q�T���(�t�q�l�l��H�c�a�}�q�ܤ��)���ޱ� 
              car328�S��  �Q�O�H���, �Q�O�H�q��(�]),�n�O�H�q��(�]),�q�l�O�������X */
            strcpy(v_sMsg,"");
            strcpy(sIemail,trim(sIemail));
            strcpy(aemail_appl,trim(aemail_appl));
            strcpy(aemail_eply,trim(aemail_eply));
            rc = cm_check_route_sales_comm("A",sIofficer,sIroute,"C",sIbig_sales,sIntroducer,sIroute_prop,sIroute_accept," ",
                                            sIassured,iapplicant,sIemail,aemail_appl,aemail_eply,
                                            "",sItel,"",tmobile_appl, itel_appl,"","",v_sMsg);
            if (rc != TRUE)
            {
      	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt++;
      	        continue;
            }
        }
       
        strcpy(v_chk_msg,"");
        strcpy(v_sMsg,"");
        rc = cm_check_noisemp_email(sIassured,iapplicant,sIemail,aemail_appl,aemail_eply,v_chk_msg,v_sMsg);
        printf("v_chk_msg[%s]\n");
        if (rc != TRUE)
        {
            if (v_chk_msg[0] == 'Y')
            {
                $UPDATE policy_temp
                    SET remark = $v_sMsg
                  WHERE ilast_ply = $sIlast_ply
                    AND seqo = $seqo;

                error_cnt++;
                continue;
            }
        }
        printf("sIcorps[%s],iroute[%s],iofficer[%s]\n",sIcorps,sIroute,sIofficer);

        /* �N�{��u�a�ϥN�����v���R���N��42�u�x�����v�B�N��63�u�x�n���v�B�N��65�u�������v�C*/
        if( strncmp( sIply_area, "42", 2) == 0)
            strcpy( sIply_area, "41");
        else if( strncmp( sIply_area, "63", 2) == 0)
            strcpy( sIply_area, "62");
        else if( strncmp( sIply_area, "65", 2) == 0)
            strcpy( sIply_area, "64");

        rc = cm_chk_city(sAassured_zip, sAassured, narea);/* �l���ϸ��P��F�ϰ��ˮ�(�Ҧ���F�ϰ���ˮ�) */
        if( rc != M_CM_OK)
        {
	    switch( rc)
            {
                case M_CMN_NZIPCODE:
                    sprintf_s( v_sMsg,sizeof v_sMsg,"�Q�O�I�H�l���ϸ����s�b[%s]\n", sAassured_zip);
                    break;
                    
                case M_CM_CITY_WRONG:
                    sprintf_s( v_sMsg,sizeof v_sMsg, "�Q�O�I�H�l���ϸ��P��F�ϰ줣�@�P�A�нT�{�l���ϸ�[%s],���}[%s],�l���ϸ���������F��[%s]\n", sAassured_zip, sAassured,narea);
                    break;
                    
                default:
                    sprintf_s( v_sMsg,sizeof v_sMsg, "�l���ϸ��P��F���ˮֿ��~�N��[%d],�Q�O�I�H�l���ϸ�[%s],���}[%s]\n", rc, sAassured_zip, sAassured);
                    break;
            }
            
      	    $UPDATE policy_temp
      	        SET remark = $v_sMsg
      	      WHERE ilast_ply = $sIlast_ply
      	        AND seqo = $seqo;

      	    error_cnt++;
      	    continue;
        }

        rc = cm_chk_city(sApayment_zip, sApayment, narea);/* �l���ϸ��P��F�ϰ��ˮ�(�Ҧ���F�ϰ���ˮ�) */
        if( rc != M_CM_OK)
        {
	    switch( rc)
            {
                case M_CMN_NZIPCODE:
                    sprintf_s( v_sMsg,sizeof v_sMsg, "�n�O�H�l���ϸ����s�b[%s]\n", sApayment_zip);
                    break;
                    
                case M_CM_CITY_WRONG:
                    sprintf_s( v_sMsg,sizeof v_sMsg, "�n�O�H�l���ϸ��P��F�ϰ줣�@�P�A�нT�{�l���ϸ�[%s],���}[%s],�l���ϸ���������F��[%s]\n", sApayment_zip, sApayment,narea);
                    break;
                    
                default:
                    sprintf_s( v_sMsg,sizeof v_sMsg, "�l���ϸ��P��F���ˮֿ��~�N��[%d],�n�O�H�l���ϸ�[%s],���}[%s]\n", rc, sApayment_zip, sApayment);
                    break;
            }
            
      	    $UPDATE policy_temp
      	        SET remark = $v_sMsg
      	      WHERE ilast_ply = $sIlast_ply
      	        AND seqo = $seqo;

      	    error_cnt++;
      	    continue;
        }
	  
        /*1060515003_C1_�ӽаw����ĳq�������X��a�}���t���ˮ֧@�~*/
        printf("sAassured[%s] sApayment[%s] \n",sAassured,sApayment);
        printf("sFassured[%s] \n",sFassured);
        rc = cmc_route_dupaddr(sIroute, sAassured, sFassured, sItel, "", v_sMsg);
        strcpy(v_sMsg,trim(v_sMsg));
        if( rc != M_CM_OK)
        {
            strcpy( v_sMsg, "cmc_route_dupaddrr()�ˮ֦��~�A�гq����T��\n");
            $UPDATE policy_temp
                SET remark = $v_sMsg
              WHERE ilast_ply = $sIlast_ply
                AND seqo = $seqo;
            error_cnt++;
            continue;
        }
        else if( rc == M_CM_OK && strcmp(v_sMsg,"") != 0)
        {
            $UPDATE policy_temp
                SET remark = $v_sMsg
              WHERE ilast_ply = $sIlast_ply
                AND seqo = $seqo;
            error_cnt++;
	    continue;
        }
        else
        {
            rc =cmc_route_dupaddr(sIroute, sApayment, fapplicant, itel_appl, "", v_sMsg);
	    strcpy(v_sMsg,trim(v_sMsg));
	    if( rc != M_CM_OK)
 	    {
	        strcpy( v_sMsg, "cmc_route_dupaddrr()�ˮ֦��~�A�гq����T��\n");
		$UPDATE policy_temp
	      	    SET remark = $v_sMsg
	      	  WHERE ilast_ply = $sIlast_ply
	      	    AND seqo = $seqo;
	        error_cnt++;
		continue;
	    }
	    else if( rc == M_CM_OK && strcmp(v_sMsg,"") != 0)
	    {
	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;
		error_cnt++;
	   	continue;
	    }
        }
        
        $BEGIN WORK;
      
      
        /* 1.4 Ūcard_temp�d�� */
        if (strcmp(fecard,"0")==0 || strcmp(trim(fecard),"")==0)  /*�ȥ��~�qcard_tempŪ���A�q�l�۰ʨ���*/ /*1080307008_SC1_CAR328�s�W�۰ʨ����\�� by 071004 2019.04.18*/
        {
      	    /*�ȥ�*/
      	
            $EXECUTE cur_card INTO $sIcard, $tFstatus;
            if( SQLCODE == SQLNOTFOUND)
            {
                $ROLLBACK WORK;
                strcpy(sremark,"�w�L�O�I�ҥi�ѥX��");
      	        $UPDATE policy_temp
      	            SET remark = $sremark
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt = error_cnt++;
      	        continue;

      	        /* card_temp �w�L���  */
      	        /*1.4.1 �w�L�O�I�d��ơA�ˮ�policy_temp �O�_�٦����X���� */
                #if 0
      	        $SELECT count(*)
      	           INTO $cnt_ply
      	           FROM policy_temp
      	          WHERE ipolicy = ' ' AND icard = ' ';

      	        if( cnt_ply > 0 )
      	        {
      	            /* policy_temp �����X���� */
      	            strcpy(sremark,"�w�L�O�I�ҥi�ѥX��");
      	            $UPDATE policy_temp
      	                SET remark = $sremark
      	              WHERE ipolicy = ' ' AND icard = ' ';

      	            error_cnt = error_cnt ++ cnt_ply;
      	        }
      	        break; /* �����j�� */
                #endif
            }

            if( strncmp( sIcar_type, "01", 2) == 0 ||
                strncmp( sIcar_type, "02", 2) == 0 ||
                strncmp( sIcar_type, "32", 2) == 0 ||
                strncmp( sIcar_type, "34", 2) == 0 ||
                strncmp( sIcar_type, "35", 2) == 0)
            {
                puts("01,02,32,34,35");
                $SELECT COUNT(*)
                   INTO $iCount
                   FROM compulsory_card
                  WHERE icard = $sIcard
                    AND icar_type IN ('01','02','32','34','35');
            }
            else
            {
                puts("not 01,02,32,34,35");
                $SELECT COUNT(*)
                   INTO $iCount
                   FROM compulsory_card
                  WHERE icard = $sIcard
                    AND icar_type NOT IN ('01','02','32','34','35');
            }

            printf("sIcar_type[%s],iCount[%d]\n", sIcar_type, iCount);

            if( iCount == 0)
            {
                $ROLLBACK WORK;
                sprintf_s(v_sMsg,sizeof v_sMsg, "�d���P���ؤ���");
      	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt++;
      	        continue;
            }
        }
        else
        {
            dissue_card[0] = '\0';
      	    /*�q�l*/
      	    /*���� ����ca301m01s.ec Get_CompCard ����*/
      	    strcpy(dissue_card, cm_edate_str(cm_today( )));
	
  	    /* �@��� */

	    if ((strcmp(sIcar_type, "01") == 0) ||(strcmp(sIcar_type, "02") == 0) ||
		(strcmp(sIcar_type, "32") == 0) ||(strcmp(sIcar_type, "34") == 0) ||
		(strcmp(sIcar_type, "35") == 0))
	    {
	        strcpy(tmp_car_type2,"01");
		strcpy(tmp_char,"M");
	    }
	    else
	    {
		strcpy(tmp_car_type2,"03");
		strcpy(tmp_char,"C");
	    }
				
	    strcpy(tmp_cardyear," "); strcpy(card1," ");
	    $SELECT first 1 substr(cast((year(today)-1911) AS char(3)),2,2),
		    cast((year(today)-1911) AS char(3))
	       INTO $tmp_cardyear
	       FROM systables WHERE 1=1;
	    strcpy(tmp_cardyear,trim(tmp_cardyear));
				
            $SELECT trim(ibranch)||trim(iupcomp)
               INTO $sIbranch_in2
               FROM officer
              WHERE iofficer=$userid;

	    sprintf_s(stmt_buf,sizeof stmt_buf,
		      " SELECT nvl(min(icard),'') FROM compulsory_card "
		      "  WHERE icard[1,4] = '%s%s8' "
		      "    AND ioffice   = '8'  "
	              "    AND icardyear = '%s' "
		      "    AND icar_type = '%s' "
		      "    AND fstatus   = '0' "
		      "    AND iofficer  = '%s' "
		      "    AND ireceive  = 'system' AND dissue BETWEEN today-30 AND today", tmp_cardyear, tmp_char, tmp_cardyear, tmp_car_type2,sIofficer);
	    $PREPARE pre_geteCard1 FROM $stmt_buf;             
	    $EXECUTE pre_geteCard1 INTO $sIcard;
	    printf("---stmt_buf[%s]\n",stmt_buf);
	    if (strlen(trim(sIcard))<3)
	    {
	        rc = get_ca_compcard(sIofficer,"8",sIquota,tmp_char,tmp_car_type2,tmp_cardyear,dissue_card,qply_period,sIbranch_in2,card_Msg);
	        if( rc != M_CM_OK)
	        {
	            /* 1130409006_C01_�ץ�car328�p�G���������ѡAcmn201�|�X�{��Ƨ䤣�쪺���p */
                    $ROLLBACK WORK;
                    sprintf_s(v_sMsg,sizeof v_sMsg, "�j���Ҩ������ѡA�еy�ԦA�դ@��");
      	            $UPDATE policy_temp
      	                SET remark = $v_sMsg
      	              WHERE ilast_ply = $sIlast_ply
      	                AND seqo = $seqo;

      	            error_cnt++;
      	            continue;
		    /*return rc;*/
	        }	      	
	      	
                sprintf_s(stmt_buf,sizeof stmt_buf," SELECT nvl(min(icard),'') FROM compulsory_card "
				                   "  WHERE icard[1,4] = '%s%s8' "
					           "    AND ioffice   = '8'  "
					           "    AND icardyear = '%s' "
					           "    AND icar_type = '%s' "
					           "    AND iofficer  = '%s' "
				                   "    AND ireceive  = 'system' AND dissue BETWEEN today-30 AND today "
					           "    AND fstatus   = '0'", tmp_cardyear, tmp_char, tmp_cardyear, tmp_car_type2, sIofficer);
		$PREPARE pre_geteCard2 FROM $stmt_buf;             
		$EXECUTE pre_geteCard2 INTO $sIcard;
		printf("--ecard3-stmt_buf[%s] card1[%s]\n",stmt_buf);
		if (strlen(trim(sIcard))<3)
		{
		    /* 1130409006_C01_�ץ�car328�p�G���������ѡAcmn201�|�X�{��Ƨ䤣�쪺���p */
                    $ROLLBACK WORK;
                    sprintf_s(v_sMsg,sizeof v_sMsg, "�j���Ҩ������ѡA�еy�ԦA�դ@��");
      	            $UPDATE policy_temp
      	                SET remark = $v_sMsg
      	              WHERE ilast_ply = $sIlast_ply
      	                AND seqo = $seqo;

      	            error_cnt++;
      	            continue;
		    /*return 100;*/
		}
	    }
	    printf("-- trace �j��q�l���� sIcard[%s]\n ",sIcard);	
  			
  	  
            /*���� ����ca301m01s.ec Get_CompCard ����*/
        } 
      
      
      
      
        /*=========================================================*/
        /** B.�O�浹�� **/
        /**   ply_num1 **/
        /**============**/


        $SELECT ibranch,iupcomp,ibranch||iupcomp
           INTO $sTmpIbranch,$sTmpIcomp,$sbranch_comp
           FROM officer
          where iofficer = $sIofficer;


        $SELECT ibranch_abbr
           INTO $ibranch_abbr
           FROM branch
          where ibranch = $localdb;



        if(strncmp(sTmpIcomp,ibranch_abbr,1)!=0)
        {
      	    $ROLLBACK WORK;
      	    strcpy( v_sMsg,"�޲z�H���P��Ʈw���šA���@��O�ʧ@");
            $UPDATE policy_temp
      	        SET remark = $v_sMsg
      	      WHERE ilast_ply = $sIlast_ply
      	        AND seqo = $seqo;

      	    error_cnt++;
      	    continue;
        }

        printf("sTmpIcomp=%s\nibranch_abbr=%s\n",sTmpIcomp,ibranch_abbr);



        if (isalpha(sIcard[3]))
        {
            sIbilling[0] = '\0';
            strcpy(ymd, cm_cdate_str_100(ply1_begin));

            strcpy(sIbilling, "C");
            strncat(sIbilling, sIcard+2, 2);
            sIbilling[3] = '\0';

            code=cm_get_serial_num_dwritten("C1",sIbilling,sTmpIcomp,sTmpIbranch, ymd_Today, ymd_Today, ply_num1);
            if (code==1 || code==2)
            {
                $ROLLBACK WORK;
                strcpy( v_sMsg, "M_CM_DB_NOTOPEN");
      	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt++;
      	        continue;
            }
            else if (code==3)
            {
                $ROLLBACK WORK;
                strcpy( v_sMsg, "M_CMN_NAUTONUMBERING");
      	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

                puts("555");
      	        error_cnt++;
      	        continue;
            }
            else if (code!=0)
            {
                $ROLLBACK WORK;
                sprintf_s( v_sMsg,sizeof v_sMsg,"%d", code);
      	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt++;
      	        continue;
            }
        }
        else
        {
            sIbilling[0] = '\0';
            if (strlen(trim(sIcard)) == 13)
            {
                if (strncmp(sIcard+5 , "C9" , 2) == 0 ||strncmp(sIcard+2 , "C8" , 2) == 0 )
                {
                    strcpy(sIbilling, "CR"); /*** �T���I ***/
                }
                else if (strncmp(sIcard+5 , "M9" , 2) == 0||strncmp(sIcard+2 , "M8" , 2) == 0 )
                {
                    strcpy(sIbilling, "MR"); /*** �����I ***/
                }
            }

            if (strlen(trim(sIcard)) == 10)
            {
                if (strncmp(sIcard+2 , "C9" , 2) == 0 ||strncmp(sIcard+2 , "C8" , 2) == 0 )
                {
                    strcpy(sIbilling, "CR"); /*** �T���I ***/
                }
                else if (strncmp(sIcard+2 , "M9" , 2) == 0 ||strncmp(sIcard+2 , "M8" , 2) == 0 )
                {
                    strcpy(sIbilling, "MR"); /*** �����I ***/
                }
            }

            strcpy(ymd, cm_cdate_str_100(ply1_begin));

            printf("sIbilling[%s] sTmpIcomp[%s] sTmpIbranch[%s], ymd_Today[%s]\n", sIbilling,sTmpIcomp,sTmpIbranch, ymd_Today );

            code=cm_get_serial_num_dwritten("C1",sIbilling,sTmpIcomp,sTmpIbranch, ymd_Today, ymd_Today, ply_num1);
            puts("111");
            if (code==1 || code==2)
            {
                $ROLLBACK WORK;
                strcpy( v_sMsg, "M_CM_DB_NOTOPEN");
      	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt++;
      	        continue;
            }
            else if (code==3)
            {
                $ROLLBACK WORK;
                strcpy( v_sMsg, "M_CMN_NAUTONUMBERING");
      	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt++;
      	        continue;
            }
            else if (code!=0)
            {
                $ROLLBACK WORK;
                sprintf_s( v_sMsg,sizeof v_sMsg,"%d", code);
      	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt++;
      	        continue;
            }

        }
        ply_num1[CAR_POLICY_LEN]='\0';

        printf("ply_num1[%s]\n\n",ply_num1 );

        printf("icorps[%s]\n",sIcorps);

        strcpy( broker_tmp, "");
        if( fstart[0] == 'N')
        {
            /* �����oibroker�Bresource����� */
            if (sIcorps[0] != ' ' && sIcorps[0] != '\0')
            {
                $SELECT a.icar_broker , b.fprop
                   INTO $broker_tmp , $tmp_resource
                   FROM officer_broker a, officer b
                  WHERE a.iofficer = $sIcorps
                    AND a.iofficer = b.iofficer;
            }
            else
            {
                $SELECT a.icar_broker , b.fprop
                   INTO $broker_tmp , $tmp_resource
                   FROM officer_broker a , officer b
                  WHERE a.iofficer = $sIofficer
                    AND a.iofficer = b.iofficer;
            }
        }

        strcpy(tmp_resource, trim(tmp_resource));

        if ( fstart[0] == 'N' && (SQLCODE==SQLNOTFOUND || broker_tmp[0]==' ' || broker_tmp[0]=='\0'))
        {
            strcpy(broker1,sIbroker);
        }
        else
        {
            strcpy(broker1,trim(broker_tmp));

            /* bis9901141 �Q�O�I�H���g�Ѧ@��function�T�{�~�ȩʽ謰
               ���Y���~(8),��O�t��(7),���h�श(G),��L���h�O���ª��~�ȩʽ�P�_�޿� */
            rc = cm_get_assured_resource("C",sIassured,sIofficer,resource_rel);
            if (rc != TRUE)
            {
          	$ROLLBACK WORK;
               	sprintf_s( v_sMsg,sizeof v_sMsg,"�P�_���Y���~���~(%s), ���~�N��(%d)", sIassured, rc);
      	        $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt++;
      	        continue;
            }
          
            /* bis9901141�ھڶǦ^�Ӫ�resource_rel�M�w�~�ȩʽ� */
            if (resource_rel[0] == '8' || resource_rel[0] == '7' || resource_rel[0] == 'G')
                strcpy(sIresource,resource_rel);
            else
            {
                if (sIcorps[0] != ' ' && sIcorps[0] != '\0')  /* ¾�ΥN���Φ�P�N�� */
                {
                    if ((strcmp(tmp_resource,"6")==0) &&
                        (sFassured302[0] == '2' || sFassured302[0] == '4' || sFassured302[0] == '6'))
                        strcpy(sIresource,"8");
                    else
                        strcpy(sIresource,tmp_resource);
                }
                else
                {
                    if (isdigit(sIofficer[0])!=0)  /* �g��N���Ĥ@�X���ƭ� */
                    {
                        /* �ȸg��N�������u�N���B����¾�η~�ȤΦ�P�~�ȮɡA
                           �~�Ȩӷ�����0[���u],3[������O],9[���u],Z[���u����] */
                        if (strcmp(sIresource,"0")!=0 && strcmp(sIresource,"3")!=0 &&
                            strcmp(sIresource,"9")!=0 && strcmp(sIresource,"G")!=0)
                        {
                            strcpy(sIresource,tmp_resource);
                        }
                    }
                    else
                        strcpy(sIresource,tmp_resource);
                }
            }
            /* end of �P�_resource_rel */
        }
        
        if(strcmp(sIresource,"0")==0)
            strcpy(sIresource,"3");

        printf("sIresource[%s]\n",sIresource);
        
        /** D. �p����[�O�I�O **/
        /**    ���odrate **/
        $SELECT drate_ym
           INTO $sIcode
           FROM ply_ins_type_302
          WHERE ipolicy = $sIlast_ply
            AND iins_type = 21;

        if( SQLCODE == SQLNOTFOUND )
        {

            $SELECT icode
               INTO $sIcode
               FROM ca_rate_renew
              WHERE deffect_bgn <= $ply1_begin
                AND deffect_end >= $ply1_begin
                AND fcard_class = '1';

            if (NOT_FOUND)
            {
                $ROLLBACK WORK;
                sprintf_s( v_sMsg,sizeof v_sMsg,"����O��[%s] ��O�O�v�ͮĥN�����(car128)�䤣��", sIlast_ply);
                $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt++;
      	        continue;
            }
        }
        printf("rate_code[%s]\n",sIcode);

        /* car9712022 �j���I�ȳf������۵M�H�k�H�O�v */
        rc = get_comp_car_type_fassured( sIcar_type302, sIcode, sFassured302, tmp_car_type, comp_fassured, v_sMsg);
        if ( rc != M_CM_OK)
        {
     	    $ROLLBACK WORK;
            sprintf_s( v_sMsg,sizeof v_sMsg, "����O��[%s] �j���I�O�v�ͮĤ�䤣��,�Ь��ӫO����car120�]�w", sIlast_ply);
            $UPDATE policy_temp
      	        SET remark = $v_sMsg
      	      WHERE ilast_ply = $sIlast_ply
      	        AND seqo = $seqo;

      	    error_cnt++;
      	    continue;
        }

        /** D.1 �j��[�T��]�d���I **/
        if ((strncmp(sIcar_type302, "01", 2) !=0) &&(strncmp(sIcar_type302, "02", 2) !=0) &&
            (strncmp(sIcar_type302, "32", 2) !=0) &&(strncmp(sIcar_type302, "34", 2) !=0) &&
            (strncmp(sIcar_type302, "35", 2) !=0))
        {

            $SELECT drate
               INTO $drate_long
               FROM ca_rate_date
              WHERE icode  = $sIcode
                AND itable = 'compulsory_premium';
            if (NOT_FOUND)
            {
                $ROLLBACK WORK;
                sprintf_s( v_sMsg,sizeof v_sMsg,"����O��[%s] �O�v�ͮĥN��[%s]���(car120)�䤣��", sIlast_ply, sIcode);
                $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

      	        error_cnt++;
      	        continue;
            }

            $SELECT mcoverage1,mcoverage2,mcoverage3,
                    mpremium, pready_rate, pcomprate, pstablerate, pinvestrate, pcapital,
                    mbusiness, mresearch, maintain
               INTO $injured_cover,$death_cover,$damage_cover,
                    $premium21_bef, $readyrate21, $comprate21, $stablerate21, $investrate21, $capital21 ,
                    $tmp_mbusiness_21, $research21, $maintain21
               FROM compulsory_premium
              WHERE icar_type = $tmp_car_type
                AND qperiod   = 12
                AND ((qcar_personbgn <= $dqpt AND qcar_personend >= $dqpt) OR
                     (qcar_personbgn = 0))
                AND drate= $drate_long
                AND fassured = $comp_fassured;

            if (NOT_FOUND)
            {
                $ROLLBACK WORK;
                sprintf_s( v_sMsg,sizeof v_sMsg, "����O��[%s],����[%s] �j���I�O�v���(car101)�䤣��", sIlast_ply, tmp_car_type);
                $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

                error_cnt++;
                continue;
            }
        }
        printf("end compute commission\n");
      
        strcpy( iyear, "0");
      
        /*�j��[����]�d���I*/
        if ((strncmp(sIcar_type302, "01", 2) ==0) || (strncmp(sIcar_type302, "02", 2) ==0) ||
            (strncmp(sIcar_type302, "32", 2) ==0) || (strncmp(sIcar_type302, "34", 2) ==0) ||
            (strncmp(sIcar_type302, "35", 2) ==0))
        {
            /*comp_frate:�j��O�v�N��*/

            $SELECT drate
               INTO $drate_long
               FROM ca_rate_date
              WHERE icode  = $sIcode
                AND itable = 'compulsory_premium';
            if (NOT_FOUND)  return M_CA_NRATE_DATE;

            if( qply_period == 12)
                strcpy( iyear, "1");
            else if( qply_period == 24)
                strcpy( iyear, "2");
            else if( qply_period == 36)
                strcpy( iyear, "3");
            else if( qply_period == 48)
                strcpy( iyear, "4");
            else if( qply_period == 60)
                strcpy( iyear, "5");
            else
            {
                $ROLLBACK WORK;
                sprintf_s( v_sMsg,sizeof v_sMsg, "����O��[%s],�ӫO���[%d] ������~ ", sIlast_ply, qply_period);
                $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

                error_cnt++;
                continue;
            }

            /*�p��Ĥ@�~�j������O�O*/
            $SELECT mcoverage1,mcoverage2,mcoverage3,
                    mpremium,pready_rate,pcomprate,pstablerate,
                    pinvestrate,mbusiness,mresearch,pcapital,maintain
               INTO $injured_cover,$death_cover,$damage_cover,
                    $premium21_bef,$readyrate21,$comprate21,$stablerate21,
                    $investrate21,$tmp_mbusiness_21,$research21,$capital21,$maintain21
               FROM compulsory_premium
              WHERE icar_type = $sIcar_type302
                AND qperiod   = 12
                AND ((qcar_personbgn <= $dqpt AND qcar_personend >= $dqpt) OR
                     (qcar_personbgn = 0))
                AND drate= $drate_long
                AND fassured = $comp_fassured;
            if (NOT_FOUND)
            {
                $ROLLBACK WORK;
                sprintf_s( v_sMsg,sizeof v_sMsg, "����O��[%s],����[%s],�ӫO���12 �j���I�O�v���(car101)�䤣��", sIlast_ply, tmp_car_type );
                $UPDATE policy_temp
      	            SET remark = $v_sMsg
      	          WHERE ilast_ply = $sIlast_ply
      	            AND seqo = $seqo;

                error_cnt++;
                continue;
            }
            
            if( iyear[0] != '1') /*�G�~�H�W*/
            {
                $SELECT mcoverage1,mcoverage2,mcoverage3,
                        mpremium,pready_rate,pcomprate,pstablerate,
                        pinvestrate,mbusiness+$tmp_mbusiness_21,mresearch,pcapital,maintain
                   INTO $injured_cover,$death_cover,$damage_cover,
                        $premium21_bef,$readyrate21,$comprate21,$stablerate21,
                        $investrate21,$tmp_mbusiness_21,$research21,$capital21,$maintain21
                   FROM compulsory_premium
                  WHERE icar_type = $sIcar_type302
                    AND qperiod   = 24
                    AND ((qcar_personbgn <= $dqpt AND qcar_personend >= $dqpt) OR
                         (qcar_personbgn = 0))
                    AND drate= $drate_long
                    AND fassured = $comp_fassured;
                if (NOT_FOUND)
                {
              	    $ROLLBACK WORK;
                    sprintf_s( v_sMsg,sizeof v_sMsg, "����O��[%s],����[%s],�ӫO���24 �j���I�O�v���(car101)�䤣��", sIlast_ply, tmp_car_type);
                    $UPDATE policy_temp
      	                SET remark = $v_sMsg
      	              WHERE ilast_ply = $sIlast_ply
      	                AND seqo = $seqo;

                    error_cnt++;
                    continue;
                }
              
                if( iyear[0] != '2') /*�T�~�H�W*/
                {
              	    $SELECT mcoverage1,mcoverage2,mcoverage3,
              	            mpremium,pready_rate,pcomprate,pstablerate,
              	            pinvestrate,mbusiness+$tmp_mbusiness_21,mresearch,pcapital,maintain
              	       INTO $injured_cover,$death_cover,$damage_cover,
              	            $premium21_bef,$readyrate21,$comprate21,$stablerate21,
              	            $investrate21,$tmp_mbusiness_21,$research21,$capital21,$maintain21
              	       FROM compulsory_premium
              	      WHERE icar_type = $sIcar_type302
              	        AND qperiod   = 36
              	        AND ((qcar_personbgn <= $dqpt AND qcar_personend >= $dqpt) OR
              	             (qcar_personbgn = 0))
              	        AND drate= $drate_long
              	        AND fassured = $comp_fassured;
              	    if (NOT_FOUND)
              	    {
              	   	$ROLLBACK WORK;
              	   	sprintf_s( v_sMsg,sizeof v_sMsg, "����O��[%s],����[%s],�ӫO���36 �j���I�O�v���(car101)�䤣��",
              	   	                  sIlast_ply, tmp_car_type);
              	   	$UPDATE policy_temp
              	   	    SET remark = $v_sMsg
              	   	  WHERE ilast_ply = $sIlast_ply
              	   	    AND seqo = $seqo;
              	   	
              	   	error_cnt++;
              	   	continue;
              	    }
              	   
              	    if( iyear[0] != '3') /*�|�~�H�W*/
              	    {
              	   	$SELECT mcoverage1,mcoverage2,mcoverage3,
              		        mpremium,pready_rate,pcomprate,pstablerate,
              		        pinvestrate,mbusiness+$tmp_mbusiness_21,mresearch,pcapital,maintain
              		   INTO $injured_cover,$death_cover,$damage_cover,
              		        $premium21_bef,$readyrate21,$comprate21,$stablerate21,
              		        $investrate21,$tmp_mbusiness_21,$research21,$capital21,$maintain21
              		   FROM compulsory_premium
              		  WHERE icar_type = $sIcar_type302
              		    AND qperiod   = 48
              		    AND ((qcar_personbgn <= $dqpt AND qcar_personend >= $dqpt) OR
              		         (qcar_personbgn = 0))
              		    AND drate= $drate_long
              		    AND fassured = $comp_fassured;
              		if (NOT_FOUND)
              		{
              		    $ROLLBACK WORK;
              		    sprintf_s( v_sMsg,sizeof v_sMsg, "����O��[%s],����[%s],�ӫO���36 �j���I�O�v���(car101)�䤣��", sIlast_ply, tmp_car_type);
              		    $UPDATE policy_temp
              			SET remark = $v_sMsg
              		      WHERE ilast_ply = $sIlast_ply
              			AND seqo = $seqo;
              			
              		    error_cnt++;
              		    continue;
              		}
              		
              		if( iyear[0] != '4') /*���~�H�W*/
              		{
              		    $SELECT mcoverage1,mcoverage2,mcoverage3,
              			    mpremium,pready_rate,pcomprate,pstablerate,
              			    pinvestrate,mbusiness+$tmp_mbusiness_21,mresearch,pcapital,maintain
              		       INTO $injured_cover,$death_cover,$damage_cover,
              			    $premium21_bef,$readyrate21,$comprate21,$stablerate21,
              			    $investrate21,$tmp_mbusiness_21,$research21,$capital21,$maintain21
              		       FROM compulsory_premium
              		      WHERE icar_type = $sIcar_type302
              			AND qperiod   = 60
              			AND ((qcar_personbgn <= $dqpt AND qcar_personend >= $dqpt) OR
              			     (qcar_personbgn = 0))
              			AND drate= $drate_long
              			AND fassured = $comp_fassured;
              		    if (NOT_FOUND)
              		    {
              		        $ROLLBACK WORK;
              			sprintf_s( v_sMsg,sizeof v_sMsg, "����O��[%s],����[%s],�ӫO���36 �j���I�O�v���(car101)�䤣��", sIlast_ply, tmp_car_type);
              			$UPDATE policy_temp
              			    SET remark = $v_sMsg
              			  WHERE ilast_ply = $sIlast_ply
              			    AND seqo = $seqo;
              				
              			error_cnt++;
              			continue;
              		    }
              		}
              	    }
                }
            }
        }
      
        strcpy( nequipment, "000000000000000000000000000000");
      
        /* �j���I�O�O�p�� */
        /* �ǤJ�Ѽ�=======> */
        /* ���ءA�ۥ���~���O */
        /* �g��N���A�~�Ⱥ޲z�O�βb�� */
        /* �O��ͮĤ�A�O������A�O�I���� */
        /* �g���H�N���A�O�v�ͮĥN�� */
        /* �Ӹ����� */
        /* �Q�O�I�H�����O�A�ʧO�~�֫Y�ơA�ߴڰO���Y�� */
        /* ���`����O�A���`�O�O */
        /* �O�_�ҥγq���~�ȱ���, �q���N��, �O�v�O, �~�ȱ���N�� */
        /* �t�X�s�r�[�O,�s�W�T�ӰѼ� add by sylvia 103.01.07 (1020801002_C1)
           �ǤJ��:iQdrunk_driving  (�s�r����) */

        /* �Ǧ^�Ѽ�=======> */
        /* �j���Iñ��O�I�O */
        /* �j���I�W���O�I�O */
        /* �S�O�ǳƪ��A���v����A�w�w��� */
        /* ���ά�s�o�i�O�ΡA��������A��ꦬ�q */
        /* �������O�I�A�~�ȶO�βb�ȡA�k�w�~�ȶO�� */
        /* �«O�O�A����O(cmn111���]�w */
        /* �j��s�O�O:�@�~���O�O�A������O�Ǹ�,�~�Ȩӷ�,����O(user��J) */
        /* �t�X�s�r�[�O,�s�W�T�ӰѼ� add by sylvia 103.01.07 (1020801002_C1)
           �Ǧ^��:lMdrunk_prem (�s�r�O�O), dblMdrunk_pure_prem (�s�r�«O�O) */
           
        /* fNewCompBusi => 1050812001_C2 �j���I�����~���u�f (�s����G1 ;�±���G0) */
        /* ��O�J�p��G �±���:�ͮĤ�10���(�t)�H�e����O�J�p��	; �s����G�ͮĤ�11���(�t)�H�ᤧ��O�J�p�� */
        strcpy(bzfrom, trim(bzfrom));
        strcpy(fNewCompBusi,"1");
        if (strlen(trim(iestimate_ori)) != 0) 
        {
      	    if (chk302_New[0]=='N') strcpy(fNewCompBusi,"0"); /* �±���:�ͮĤ�10���(�t)�H�e����O�J�p�� */
        }
      
        if (fNewCompBusi[0]=='1')
        {

      	    if (strcmp(bzfrom,"40")==0 || strcmp(bzfrom,"41")==0)
      	    {
      	 	
      	 	/*1111019003_SC1_�s�W�L�q�������I�O*/   
      	 	/*1121115007_C01_�ĤG���ը��P��O�j��T���d���O�I*/   	 	
      	 	stmp[0]='\0';
      	 	if ((iyear[0] == '0') && (strncmp(sIcar_type302, "36", 2) !=0) && (mother_busi < min_mother_busi_C0)) sprintf_s(stmp,sizeof stmp,"%f ��", min_mother_busi_C0);      	 		
      	 	if ((iyear[0] == '1') && (strncmp(sIcar_type302, "35", 2) !=0) && (mother_busi < min_mother_busi_M1)) sprintf_s(stmp,sizeof stmp,"%f ��", min_mother_busi_M1);
      	 	if ((iyear[0] == '2') && (strncmp(sIcar_type302, "35", 2) !=0) && (mother_busi < min_mother_busi_M2)) sprintf_s(stmp,sizeof stmp,"%f ��", min_mother_busi_M2);
      	 	if ((iyear[0] == '1') && (strncmp(sIcar_type302, "35", 2) ==0) && (mother_busi < min_mother_busi_Y1)) sprintf_s(stmp,sizeof stmp,"%f ��", min_mother_busi_Y1);
      	 	if ((iyear[0] == '2') && (strncmp(sIcar_type302, "35", 2) ==0) && (mother_busi < min_mother_busi_Y2)) sprintf_s(stmp,sizeof stmp,"%f ��", min_mother_busi_Y2);
      	 	if ((iyear[0] == '3') && (strncmp(sIcar_type302, "35", 2) ==0) && (mother_busi < min_mother_busi_Y3)) sprintf_s(stmp,sizeof stmp,"%f ��", min_mother_busi_Y3);
      	 	if ((iyear[0] == '0') && (strncmp(sIcar_type302, "36", 2) ==0) && (mother_busi < min_mother_busi_V0)) sprintf_s(stmp,sizeof stmp,"%f ��", min_mother_busi_V0);      	 	 	 	
      	 	
      	 	strcpy(stmp, rtrim(stmp));
      	 	if (stmp[0]!='\0')
      	 	{
      	 	    $ROLLBACK WORK;
                    sprintf_s( v_sMsg,sizeof v_sMsg, "����O��[%s]�������O�v,�~�ȶO�Χ��[%d],���i�C��̧C�u�����B�v[%s]", sIlast_ply, mother_busi,stmp );
  	 	  	
                    $UPDATE policy_temp
                        SET remark = $v_sMsg
        	      WHERE ilast_ply = $sIlast_ply
        	        AND seqo = $seqo;
        	        
        	    error_cnt++;
                    continue;
          
      	        }      
      	    }
        }
        else
        {	  
      	    /*  �ϥ��±��� => ���O105 */      
	    strcpy(nequipment_s, equip_insert(nequipment,"105"));    	        	        	
	    printf("-- trace nequipment_s[%s]\n ",nequipment_s);        	
        }
      
        ZA_mbusiness = tmp_mbusiness_21 - mother_busi;
        printf("resource[%s]\n",sIresource);
        printf("mservice[%d]\n",mservice);
        printf("ZA_mbusiness[%f]\n", ZA_mbusiness);
        strcpy( abn_type, "");
        lTmpPremium1 = 0;
        /* �t�X��椣�ˮֳq�����v, �T�w�ǫO�����O=P(�O��) modify by sylvia 101.02.07 */
        code = Cal_prem_21 (sIcar_type302, sFcar_class,
                            sIofficer, ZA_mbusiness,
                            ply1_begin, ply1_end, qply_period,
                            broker1, sIcode,
                            dqpt,
                            sFassured302, psex_age21, plia_acc21,
                            abn_type, lTmpPremium1,
                            fstart, sIroute, irate_type, iroute_comm,
                            iQdrunk_driving, iQviolate,
                            &premium21,
                            &bef_ins_premium21,
                            &mready21, &mcompensation21, &mstable21,
                            &mresearch21, &mcapital21, &minvest21,
                            &maintain21, &mbusiness21, &mbus_rule21,
                            &madjcom_prem21, &mcommission21,
                            &premium1_24, "", sIresource, mservice,
                            &lFirstYear_bef, &tmp_mbusiness_21, &maintain21, &ZA_mbusiness_1, &research21,
                            &lSecondYear_bef, &dblSy_mbusiness, &secMaintain21, &ZA_mbusiness_2, &secResearch21,
                            fcheck, "P", &lMdrunk_prem, &dblMdrunk_pure_prem, fNewCompBusi,
                            &lMviolate_prem, &dblMviolate_pure_prem,
                            &lThirdYear_bef, &dblSy_mbusiness_3, &thirdMaintain21, &ZA_mbusiness_3, &thirdResearch21,
                            &lFourthYear_bef, &dblSy_mbusiness_4, &fourMaintain21, &ZA_mbusiness_4, &fourResearch21,
                            &lFifthYear_bef, &dblSy_mbusiness_5, &fifMaintain21, &ZA_mbusiness_5, &fifResearch21);
        if (code != SUCCESS)
        {
      	    $ROLLBACK WORK;
            if( code == M_CA_BROKER_ERROR)
                sprintf_s( v_sMsg,sizeof v_sMsg, "����O��[%s],�g���N��[%s],����O,�~�ȶO�Χ���ˮ֦��~", sIlast_ply, broker1);
            else if( code == M_CA_COMMI_BUSINESS)
                sprintf_s( v_sMsg,sizeof v_sMsg, "����O��[%s],�j���I(����O+�~�ȶO�Χ��)>�W���~�ȶO��,�q�Эץ�", sIlast_ply);
            else
            {
                strcpy(sTmp, cm_get_errmsg( code));
                sprintf_s( v_sMsg,sizeof v_sMsg, "����O��[%s],�g���N��[%s]�O�O�p����~,���~�N��[%d],���~�T��[%s]", sIlast_ply, broker1, code,sTmp);
            }
          
            $UPDATE policy_temp
                SET remark = $v_sMsg
              WHERE ilast_ply = $sIlast_ply
                AND seqo = $seqo;

            error_cnt++;
            continue;
        }

        /**==========================================================**/

        mlia_agent_1=0;
        mlia_commi_1=(long)mservice;

        strcpy(ins_type,"21    ");
        deduct          = 0;
        pcommission     = 0;
        pagent          = 0;
        pdiscount       = 0;
        mcommission     = mservice;
        magent          = 0;
        mdiscount       = 0;
        qserial         = 0;

        if( strncmp( icomm_obj, "10000", 5) == 0 && mlia_commi_1 != 0)
        {
      	    $ROLLBACK WORK;
            sprintf_s( v_sMsg,sizeof v_sMsg, "����O��[%s],���I���~�Ȥ��i�H������", sIlast_ply);
      	    $UPDATE policy_temp
      	        SET remark = $v_sMsg
      	      WHERE ilast_ply = $sIlast_ply
      	        AND seqo = $seqo;

      	    error_cnt++;
      	    continue;
        }

        /**==========================================================**/
        /** F. �g�Jply_relation�Bpolicy�Bply_ins_type                **/
        /**    UPDATE compulsory_card                                **/
        /**==========================================================**/
        /*�k�ݳ��*/

        printf("localdb[%s], entry[%s],  sbranch_comp[%s]\n", localdb, entry,  sbranch_comp);
        fRtnCode = cm_get_unit_in("", localdb, entry, sbranch_comp, "C1", sIcomp_in, sIbranch_in);
        if (fRtnCode != M_CM_OK)
        {
      	    $ROLLBACK WORK;
            sprintf_s( v_sMsg,sizeof v_sMsg, "����O��[%s],�k�ݳ����~�N��[%d]", sIlast_ply, fRtnCode);
            $UPDATE policy_temp
                SET remark = $v_sMsg
              WHERE ilast_ply = $sIlast_ply
                AND seqo = $seqo;

            error_cnt++;
            continue;
        }
        printf("===>sIcomp_in[%s]\n", sIcomp_in);
        printf("===>sIbranch_in[%s]\n", sIbranch_in);


        /*�B�z���*/
        fRtnCode = cm_get_unit_at(entry, "C1", sIcomp_at, sIbranch_at);
        printf("===>sIcomp_at[%s]\n", sIcomp_at);
        printf("===>sIbranch_at[%s]\n", sIbranch_at);

        if (fRtnCode != M_CM_OK)
        {
      	    $ROLLBACK WORK;
            sprintf_s( v_sMsg,sizeof v_sMsg,"����O��[%s],�B�z�����~�N��[%d]", sIlast_ply, fRtnCode);
            $UPDATE policy_temp
                SET remark = $v_sMsg
              WHERE ilast_ply = $sIlast_ply
                AND seqo = $seqo;

            error_cnt++;
            continue;
        }

        printf("===>sIcomp_at[%s]\n", sIcomp_at);
        printf("===>sIbranch_at[%s]\n", sIbranch_at);

        rc = get_iproduct_car("21",sIcar_type302,iproduct,"",sIcode);
        if (rc != M_CM_OK)
        {
      	    $ROLLBACK WORK;
            sprintf_s( v_sMsg,sizeof v_sMsg, "����O��[%s],����[%s]�ӫ~�N�X��Ƨ䤣��", sIlast_ply, sIcar_type302);
            $UPDATE policy_temp
                SET remark = $v_sMsg
              WHERE ilast_ply = $sIlast_ply
                AND seqo = $seqo;

            error_cnt++;
            continue;
        }

        /** C.��s policy_temp ������� **/

        $UPDATE policy_temp
            SET (ipolicy, icard, mins_premium )
              = ($ply_num1, $sIcard, $premium21 )
          WHERE ilast_ply = $sIlast_ply
            AND seqo = $seqo;

        /** �s�¨��P�_�A�@�w���¨� **/
        strcpy(icar_flag, "2");

        if(strcmp(trim(check),"1") == 0)
        {
      	    strcpy(nequipment_s,equip_insert(nequipment,"97"));
        }
        else
        {
      	    strcpy(nequipment_s, nequipment);
        }

        strcpy(isign,trim(isign));
        strcpy(sIleader,trim(sIleader));
        printf("*****isign[%s], ileader[%s]*****\n",isign, sIleader);
        
        /* �g��N�����޲z�H�P�֫O�H�����i���P�@�H (1020226003_C3) */
        if (strcmp(isign, sIleader) == 0)
        {
      	    $ROLLBACK WORK;
            sprintf_s( v_sMsg,sizeof v_sMsg, "����O��[%s],�֫O�H�����o�f�֦ۦ�g�줧�ץ�", sIlast_ply);
            $UPDATE policy_temp
                SET remark = $v_sMsg
              WHERE ilast_ply = $sIlast_ply
                AND seqo = $seqo;

            error_cnt++;
            continue;
        }


        printf("before ply_relation ipolicy[%s]\n", ply_num1 );

        /* car9811303 �j���I99.3.1�O�v */
        strcpy( iabn_type, "");
        rc = chk_commi_business( 1, iabn_type, sIcode, mlia_commi_1, mbusiness21, v_sMsg);

        if( rc != M_CM_OK)
        {
      	    $ROLLBACK WORK;
            $UPDATE policy_temp
                SET remark = $v_sMsg
              WHERE ilast_ply = $sIlast_ply
                AND seqo = $seqo;

            error_cnt++;
            continue;
        }
      
        /* �������渹 */
        /* ��O�ɳ����渹(���O�զX)��CR���A�åB�j���I�O�O�P�X��O�O�ۦP�ɡA�N�̸�CR�պ⸹����ñ��պ⸹ */
        printf("iestimate_ori[%s]\n",iestimate_ori);
        printf("lComp_prem[%d]premium21[%d]\n",lComp_prem,premium21);
      
        rcv_fstatus = 10;
      
        if (strlen(trim(iestimate_ori)) != 0 && lComp_prem == premium21)
        {
	    printf("iestimate is CR \n");
		
            /* 1050803001 _C1 �ӽзs�W�ܺ��I�j���I�Y�ɶǿ�@�~ (fstatus = 45) */
	    $SELECT CASE WHEN fstatus<45 THEN 30  WHEN fstatus>=45 and fstatus<90 THEN 60 ELSE fstatus END
	       INTO $rcv_fstatus
	       FROM cm_pre_receive
	      WHERE ipre_rcv=$iestimate_ori
		AND iins_kind='1'
		AND ipre_end= ' ';
		    
            printf("rcv_fstatus=[%d]\n",rcv_fstatus);

	    if (SQLCODE == SQLNOTFOUND)
	    {
	        $ROLLBACK WORK;
		strcpy(sMsg,"�@�γ�����L��CR��");
		sprintf_s( v_sMsg,sizeof v_sMsg, "���ѡG��O��[%s];�����渹:[%s];sMsg[%s]",sIlast_ply,iestimate_ori,sMsg);
	        $UPDATE policy_temp
	            SET remark = $v_sMsg
	          WHERE ilast_ply = $sIlast_ply
	            AND seqo = $seqo;

	        error_cnt++;
	        continue;
            }

	    if(rcv_fstatus == 90)
	    {
	        $ROLLBACK WORK;
		strcpy(sMsg,"�@�γ����檬�A���~");
		sprintf_s( v_sMsg,sizeof v_sMsg, "���ѡG��O��[%s];�����渹:[%s];sMsg[%s]",sIlast_ply,iestimate_ori,sMsg);
	        $UPDATE policy_temp
	            SET remark = $v_sMsg
	          WHERE ilast_ply = $sIlast_ply
	            AND seqo = $seqo;

	          	error_cnt++;
	          	continue;
	    }
	    strcpy(estimatei, trim(iestimate_ori));
        }
        else
        {
	    printf("iestimate is not CR \n");
	    code=cm_get_serial_num("C1", "CK", sTmpIcomp, sTmpIbranch, ymd_Today, estimatei);
	    
	    if (code==1 || code==2)
	    {	 
	        $ROLLBACK WORK;
		strcpy( v_sMsg, "�����渹:M_CM_DB_NOTOPEN");
		$UPDATE policy_temp
		    SET remark = $v_sMsg
		  WHERE ilast_ply = $sIlast_ply
		    AND seqo = $seqo;
		error_cnt++;
		continue;
	    }
	    else if (code==3)
	    {
	        $ROLLBACK WORK;
		strcpy( v_sMsg, "�����渹:M_CMN_NAUTONUMBERING");
		$UPDATE policy_temp
		    SET remark = $v_sMsg
		  WHERE ilast_ply = $sIlast_ply
		    AND seqo = $seqo;

		error_cnt++;
		continue;
	    }
	    else if (code!=0)
            {
	        printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
		$ROLLBACK WORK;
		sprintf_s( v_sMsg,sizeof v_sMsg, "�����渹:%d", code);
		$UPDATE policy_temp
		    SET remark = $v_sMsg
		  WHERE ilast_ply = $sIlast_ply
		    AND seqo = $seqo;

		error_cnt++;
		continue;
	    }
	    rcv_fstatus = 30; /* �w�X�� �����O*/
	    strcpy(estimatei, trim(estimatei));
        }
      
        $UPDATE policy_temp
            SET iestimate = $estimatei,
                qdrunk_driving = $iQdrunk_driving,
                qviolate = $iQviolate
          WHERE ilast_ply = $sIlast_ply
            AND seqo = $seqo;
        printf("{car328-1507}:estimatei_new[%s]\n",estimatei);
      
        /* 1050803001 _C1 �ӽзs�W�ܺ��I�j���I�Y�ɶǿ�@�~ */
        strcpy( ftrans_trade,"0" );  /* ���T�Y�ɶǿ����O */      
        if (rcv_fstatus > 30) 
        {
	    $SELECT CASE WHEN fimmed_trans = 'Y' THEN '1' ELSE '0' END  
               INTO $ftrans_trade
               FROM ao_prercv_pass
              WHERE ipre_rcv = $estimatei AND iins_kind ='1' AND ipre_end=' ' AND iins_cat='C';
            if (SQLCODE == SQLNOTFOUND) strcpy( ftrans_trade,"0" );  
        }
         
        if (strlen(trim(iassured_cntry_302))>0)   strcpy(iassured_cntry  ,iassured_cntry_302);
        if (strlen(trim(iapplicant_cntry_302))>0) strcpy(iapplicant_cntry,iapplicant_cntry_302);
      
        /* 1101124011_SC1_RBA�ק�@�~ �L����N2.9�ɤW���y�O */
        if (strcmp(iassured_cntry,"2")   == 0) strcpy(sNassured_cntry,  "����j��");
        if (strcmp(iassured_cntry,"9")   == 0) strcpy(sNassured_cntry,  "���إ���");
        if (strcmp(iapplicant_cntry,"2") == 0) strcpy(sNapplicant_cntry,"����j��");
        if (strcmp(iapplicant_cntry,"9") == 0) strcpy(sNapplicant_cntry,"���إ���");
      
        /* 1050930004_C1_�ӽЭץ����s�t�ΰ�O���O���ˮ� */
        if (strcmp(iassured_cntry,"1") == 0 || strcmp(iassured_cntry,"4") == 0 || strcmp(iassured_cntry,"5") == 0)
        {
      	    strcpy(nassured_cntry,trim(nassured_cntry));   /* �̷ӵe���ǤJ���y�O */

	    if (strcmp(nassured_cntry,"") == 0)
	    {
	        $ROLLBACK WORK;
	      	strcpy(sMsg,"�Q�O�I�H���y�O���~");
		sprintf_s( v_sMsg,sizeof v_sMsg, "���ѡG��O��[%s];sMsg[%s]",sIlast_ply,sMsg);
	        $UPDATE policy_temp
	            SET remark = $v_sMsg
	          WHERE ilast_ply = $sIlast_ply
	            AND seqo = $seqo;

	        error_cnt++;
	        continue;
	    }
        }
        else
        {
      	    strcpy(nassured_cntry,sNassured_cntry);   /* �̷ӥh�~�̷s�O���ɰ��y�O */
        }
      
        if (strcmp(iapplicant_cntry,"1") == 0 || strcmp(iapplicant_cntry,"4") == 0 || strcmp(iapplicant_cntry,"5") == 0)
        {
      	    strcpy(napplicant_cntry,trim(napplicant_cntry));
      		
	    if (strcmp(napplicant_cntry,"") == 0)
	    {
	        $ROLLBACK WORK;
	      	strcpy(sMsg,"�n�O�H���y�O���~");
		sprintf_s( v_sMsg,sizeof v_sMsg, "���ѡG��O��[%s];sMsg[%s]",sIlast_ply,sMsg);
	        $UPDATE policy_temp
	            SET remark = $v_sMsg
	          WHERE ilast_ply = $sIlast_ply
	            AND seqo = $seqo;

	        error_cnt++;
	        continue;
	    }
        }
        else
        {
      	    strcpy(napplicant_cntry,sNapplicant_cntry);
        }

     

        if (strlen(trim(tmobile_appl)) == 0) strcpy(tmobile_appl," ");
        if (strlen(trim(aemail_appl)) == 0) strcpy(aemail_appl," ");
        if (strlen(trim(mobil_phone)) == 0) strcpy(mobil_phone," ");
        if (strlen(trim(sIemail)) == 0) strcpy(sIemail," ");
        if (strlen(trim(aemail_eply)) == 0) strcpy(aemail_eply," ");
     
        /* 1110207003_SC1_�s�W�Q�O�I�H����ʤ�mail�^���ܱH�e�q�l���O�I�Ҫ���� */
        if (strlen(trim(aemail_eply))==0) strcpy(aemail_eply,aemail_appl);
        /*������null*/
        if(strlen(trim(sIengine))==0)  strcpy(sIengine," ");
      
        /*1090831006-SC1-���ʱo-�{�ҥ��x�j��q�l���ҥ���g�����mail�ˮ� 
                           �n�O�H�P�ɵL��ʹq�ܻPemail�B�ݩ�q�l���ҿﶵ�L�H�o²�T����ʹq�ܻP�H�o��email�� 
        i.	�p�G�O�쥻�w�������渹�B�L�e�z�p����T�ɡA���������渹�ɡA���u�έ������ҰO�������O���ɶ��C
        ii.	�p�G���O�����������s�W�ɡA�h�H�s�W�����椧�ɶ��C
        iii.	�p�G���W�z�p����T���@�榳��ƮɡA���O���i�j��q�l�O��-�T�{�L�k���Ѥ��email�j���ťաC
                            */
        strcpy(sDnotifyornot," ");
        $select current year to fraction(3) 
           into $sDnotifyornot
           from officer
          where iofficer = $userid;
        
        /* �n�O�H������X�B�n�O�Hemail �q�l�O��H�e��email  
           ���Y�j�ҨS���ϥιq�l�O��H�etmobile_eply*/
        printf("tmobile_appl[%s]\n",tmobile_appl);
        printf("aemail_appl[%s]\n",aemail_appl);
        printf("aemail_eply[%s]\n",aemail_eply);
        if ((strlen(trim(tmobile_appl))==0) && (strlen(trim(aemail_appl))==0)&&(strlen(trim(aemail_eply))==0) )  
        {
     	    printf("sDnotifyornot[%s]\n",sDnotifyornot);
        }
        else
        {
     	    printf("�p����T���@�榳���\n");
     	    strcpy(sDnotifyornot," ");
        }
     
        /** ply_relation **/
        /* 1091215005-SC1-���ά�-���F�P�_�O���ӷ�, �n�s�W�x�s����{���N�X����� iprog*/
        $INSERT INTO ply_relation
           (ipolicy, icard, fcard_class, irelative_ply, ilast_ply, ilast_card,
            iofficer, iquota, ileader, ibroker, icorps,
            iarea, icashier, iexaminer, dexamine, ientry, dentry, dpolicy,
            fprint, iresource, ibig_comp, ibig_branch, ibig_office, ibig_sales,
            qply_period, dply_begin, dply_end, ipro_year, ibrand,
            icar_type, itreaty, ibranch, fcomp_class, fcomp_class_last,
            mbusiness, mbus_rule, mresearch, mcapital, minvest,
            mready, mstable, mcompensation, madjcom_prem, maintain,
            icomp_in, ibranch_in, icomp_at, ibranch_at, dapply, fdiscount,
            icar_flag,
            mdmg_agent, mdmg_commi, mdmg_discount, mdmg_prem, mdmg_pure_prem,
            mlia_agent, mlia_commi, mlia_discount, mlia_prem, mlia_pure_prem,
            irate_type,bzfrom,iroute_comm,icomm_obj, itmp_policy, qdrunk_driving,
            isign, ftrans_trade, feply, feterms, aemail_eply, ireg_no, dnotifyornot,
            fsign_status, funder_chk, iprog, qviolate)
         VALUES
           ($ply_num1, $sIcard, "1", " ", $sIlast_ply, $sIast_card,
            $sIofficer, $sIquota, $sIleader, $broker1, $sIcorps,
            $localdb, $sIofficer, $entry, $Today, $entry, $Today, $Today,
            "0", $sIresource, $sIbigcomp, $sIbig_branch, $sIbig_office, $sIbig_sales,
            $qply_period, $ply1_begin,$ply1_end, $sIpro_year, $sIbrand,
            $sIcar_type302, "6", $sIbranch, $sFcomp_class, $sFcomp_class_last,
            $mbusiness21, $mbus_rule21, $mresearch21, $mcapital21, $minvest21,
            $mready21,$mstable21,$mcompensation21, $madjcom_prem21, $maintain21,
            $sIcomp_in, $sIbranch_in, $sIcomp_at, $sIbranch_at, $Today, "N",
            "2",
            0,0,0,0,0,$mlia_agent_1, $mlia_commi_1, 0, $premium21, $madjcom_prem21,
            $irate_type, $bzfrom, $iroute_comm, $icomm_obj, $estimatei, $iQdrunk_driving,
            $isign, $ftrans_trade, $fecard, "0", $aemail_eply, $ireg_no, $sDnotifyornot,
            40, "N", 'car328', $iQviolate);

        printf("sfcomp_class=%s\nsfcomp_class_last=%s\n",sFcomp_class,sFcomp_class_last);

        printf("{car328-1569}:ply_num1[%s]\n",ply_num1);
        
        /** policy **/
        /* �s�W�d�d/����T�~�ߴڦ������ add by sylvia 100.11.01 */
        iQlia_acc_sum = iQdmg_acc_sum = 0;
        if (nassured_cntry[0]=='\0') 		strcpy(nassured_cntry," ");
        if (napplicant_cntry[0]=='\0') 	strcpy(napplicant_cntry," ");
      	
        if (noccup[0]=='\0') 	strcpy(noccup," ");
        if (applicant_noccup[0]=='\0') 	strcpy(applicant_noccup," ");

        
        $INSERT INTO policy
           (ipolicy, icard, fassured, iassured, iassured_ext, nassured,
            ilicense, fsex, fmarriage, nuser, ibenef, nbenef,
            aassured, aassured_zip, itel, iemail, apayment, apayment_zip,
            iply_area, nbrand_abbr, ncar_abbr, qcylinder, iengine, ibody,
            itag, mcar_price, nequipment, pdmg_align,pbrg_align,plia_align,
            fcut, fcal_way, idmg_rate, ibrg_rate, qpt, fpt, psex_age,
            lia_class, plia_acc, pdmg_acc, fcomp_24, fhuman, dissue, dbirth, iroute, iroute_prop,
            qlia_acc_sum, qdmg_acc_sum, iapplicant, napplicant, ndeputy_assured, fapplicant, fsex_appl,
            dbirth_appl, itel_appl, ndeputy_appl, nrelation_appl, iquery_num, iassured_cntry, iapplicant_cntry,
            nassured_cntry, napplicant_cntry, foccup,noccup, applicant_foccup, applicant_noccup, 
            tmobile_appl, aemail_appl, qpro_month)
         VALUES
           ($ply_num1, $sIcard, $sFassured302, $sIassured, $sIassured_ext, $sNassured,
            $sIlicense, $sFsex, $sFmarriage, $sNuser, $sIbenef, $sNbenef,
            $sAassured, $sAassured_zip, $sItel, $sIemail, $sApayment, $sApayment_zip,
            $sIply_area, $sNbrand_abbr, $sNcar_abbr, $qcylinder, $sIengine, $sIbody,
            $sItag, $lMcar_price, $nequipment_s, $lpdmg_align, $lpbrg_align, $lplia_align,
            "0", "M", $sIdmg_rate, $sIbrg_rate, $dqpt, $dfpt, $psex_age21,
            " ", $plia_acc21, 0, "N", "1" , $dissue, $dbirth, $sIroute, $sIroute_prop,
            $iQlia_acc_sum, $iQdmg_acc_sum, $iapplicant, $napplicant, $ndeputy_assured, $fapplicant, $fsex_appl,
            $dbirth2, $itel_appl, $ndeputy_appl, $nrelation_appl, $iquery_num,$iassured_cntry, $iapplicant_cntry,
            $nassured_cntry, $napplicant_cntry, $foccup, $noccup, $applicant_foccup, $applicant_noccup, 
            $tmobile_appl, $aemail_appl, $sQpro_month);
      
        printf("{car328-1594}:ply_num1[%s]\niquery_num=%s\n",ply_num1,iquery_num);
        
        $INSERT INTO  ply_ins_type
              ( ipolicy, iins_type, minjured_cover, mdeath_cover,
                mdamage_cover, mdeduct, mins_premium, mpure_prem, pcommission,
                mcommission, pagent, magent, pdiscount, mdiscount,
                qserial, drate_ym, mprem, iproduct, qday, mexpense, mexp_disc,
                mins_premium_n, mpure_prem_n, mprem_n,
                mdrunk_prem, mdrunk_pure_prem, mviolate_prem, mviolate_pure_prem)
         VALUES ( $ply_num1, $ins_type, $injured_cover, $death_cover,
                $damage_cover, $deduct, $premium21, $madjcom_prem21, $pcommission,
                $mcommission, $pagent, $magent, $pdiscount, $mdiscount,
                $qserial, $sIcode, $bef_ins_premium21, $iproduct, 0, 0, 0,
                $premium21, $madjcom_prem21, $bef_ins_premium21,
                $lMdrunk_prem, $dblMdrunk_pure_prem, $lMviolate_prem, $dblMviolate_pure_prem);
                
        printf("{car328-1608}:ply_num1[%s]\n",ply_num1);

        /** �^�g ply_relation : inext_ply **/
        $UPDATE ply_relation
            SET inext_ply = $ply_num1
          WHERE ipolicy = $sIlast_ply;

        /** �g�J��O�渹 **/
        sprintf_s(stmt,sizeof stmt,
                  " EXECUTE PROCEDURE update_ilast_ply('%s') ",ply_num1);
        printf("stmt[%s]\n",stmt);
        $PREPARE o_id1 FROM $stmt;
        $EXECUTE o_id1 INTO $i_rtn;
        printf("--- 1611 -------------\n");

        /* �s�W�@�γ������� */
        strcpy(sIbigcomp,trim(sIbigcomp));
        if (strlen(sIbigcomp) > 0 )
      	    strcpy(sIbigcomp, "1");	/* �j�v */
        else
      	    strcpy(sIbigcomp, "N");	/* �@�� */

        /*1031111001_C1 ���O�X������{���վ�( _CA_VERSION �w�q�b var_length.h )*/


        strcpy(sPaydate," ");   strcpy(ftype_pol, " ");  strcpy(ftype_sp," ");
        rc = get_pre_type_pol(ply_num1, 1, " " , sPaydate, ftype_pol, ftype_sp, sMsg);
        if( rc != M_CM_OK)
        {
            $DELETE From ply_ins_type Where ipolicy = $ply_num1;
            $DELETE From ply_relation Where ipolicy = $ply_num1;
            $DELETE From policy Where ipolicy = $ply_num1;
          
            $ROLLBACK WORK;

            sprintf_s( v_sMsg,sizeof v_sMsg, "rc=[%ld];get_pre_type_pol()���ѡG�O�渹:[%s];sMsg[%s]",rc,ply_num1,sMsg);
            $UPDATE policy_temp
                SET remark = $v_sMsg
	      WHERE ilast_ply = $sIlast_ply
	        AND seqo = $seqo;

	    error_cnt++;
	    continue;
        }
        printf("-- trace ���N estimatei[%s]\n ",estimatei);
        printf("-- trace sPaydate[%s]\n ",sPaydate);
        printf("-- trace ftype_pol[%s]\n ",ftype_pol);
        printf("-- trace ftype_sp[%s]\n ",ftype_sp);

        /* CR��:update CP��:insert */
        if (strlen(trim(iestimate_ori)) != 0 && lComp_prem == premium21)
        {
	    $update cm_pre_receive
		Set iassured=$sIassured, nassured=$sNassured, iapplicant=$iapplicant,
		    napplicant=$napplicant, itag=$sItag, iengine=$sIengine, deffect=$ply1_begin,
		    paydate=$sPaydate ,Iofficer=$sIofficer, ileader=$sIleader, iquota=$sIquota,
		    icomm_obj=$icomm_obj, iroute=$sIroute ,  fstatus=$rcv_fstatus, iupdate='Car328',
		    dupdate=current, ipolicy1=$ply_num1, ipolicy2=' ', icard=$sIcard,
		    dprint= current,ftype_pol=$ftype_pol, ftype_sp=$ftype_sp,
		    dbegin=$ply1_begin, dend=$ply1_end
	      WHERE ipre_rcv=$estimatei
		AND iins_kind='1'
		AND ipre_end= ' ';

        }
        else
        {
	    $insert into cm_pre_receive
			(iins_cat, ipre_rcv, iins_kind, iins_kind_ply, ipre_end, ftype,
			iassured, nassured, iapplicant, napplicant, itag,
			iengine, deffect, paydate, mprem, isub,
			iofficer, ileader, iquota, icomm_obj, iroute,
			fcommit, ientry, dentry, isys, igroup,
			fstatus, iupdate, dupdate, ipolicy1, ipolicy2, icard, dprint, ftype_pol, ftype_sp, dbegin, dend)
	     values
			('C', $estimatei, '1','C1', ' ', 'P',
			$sIassured, $sNassured, $iapplicant, $napplicant, $sItag,
			$sIengine, $ply1_begin, $sPaydate , $premium21, $localdb,
			$sIofficer, $sIleader, $sIquota, $icomm_obj, $sIroute,
			$sIbigcomp, $entry, current, '1', ' ',
			$rcv_fstatus, 'Car328', current, $ply_num1, ' ', $sIcard, current, $ftype_pol,$ftype_sp, $ply1_begin,$ply1_end);
        }

        printf("--- 1646  ------------ \n");

        /** compulsory_card **/
        $UPDATE  compulsory_card
            SET  fstatus = '1',   ialter = $entry,
                 dalter = $Today, ipolicy= $ply_num1
          WHERE  icard = $sIcard;

        /** card_temp **/
        $UPDATE  card_temp
            SET  fstatus = '1', ipolicy = $ply_num1
          WHERE  icard = $sIcard;


        /* 1040416007_C1 �S�w�q��ñ��W�h�վ�
			��	�w��u�O�����O = SP-20�v�̡G
			(1)	�Y[(�ͮĤ�-�t�Τ�) > 25��]�B[�����O]�A�h�אּ���g�J��ñ��顨;
			    �ӡu�@�γ�����v�����A���h�g�J��10��(������)�B�L��ɶ����礣�g�J�C
			(2)	�Y[(�ͮĤ�-�t�Τ�) �� 25��] ��[�w���O]�̡A�h�g�J��ñ���(=�t�Τ�)�� ;�ӡu�@�γ�����v�����A
			    ���h�g�J��60��(�w�X��-�w���O) �Ρ�30��(�w�X��-�����O)�A�L��ɶ�
			    ����P�ɼg�J(=�t�ήɶ�)�C

			(car328 �����O�A�������O )
        */
        if ((strcmp(ftype_pol,"SP")==0) && (strcmp(ftype_sp,"20")==0))
        {
            printf("-- trace Today[%ld]\n ",Today);
            printf("-- trace ply1_begin[%ld]\n ",ply1_begin);

            /* 1040603001_c1 car301��car153�{���վ� */
            $int qday_permit_c;
            qday_permit_c = 0;
	    $SELECT nvl(qday_permit_c,0) into $qday_permit_c
	       FROM ca_permit
	      WHERE (dexpire is null or dexpire > today)
	        AND (iclass = '05' and $sIroute like trim(icode)||'%' and ftype_sp = '20');

	    if (qday_permit_c > 0)
	    {
	        if( ply1_begin - Today > qday_permit_c)
	        {
	            $Update ply_relation
		        Set dpolicy = null, fprint = '0'
		      Where ipolicy = $ply_num1;

		    $Update cm_pre_receive
		        Set dprint = null, fstatus = 10
		      Where ipolicy1 = $ply_num1 and ipre_end = ' ';
	        }
	    }
        }
	   
      
      
      
        /*----------------------�� 1060606002_C4_RBA�t�έץ� ��--------------------*/ 

        /*  �sRBA  */
        iLoop_end = 0;   strcpy(idata_type, "0");  strcpy(icountry ," "); strcpy(ibranch_leader ," "); strcpy(iquota_leader ," ");
        dtcurrent(&dt_current);
        fkind_batch = 2;  strcpy(ftype_batch , "E"); fstatus_batch = 10; strcpy(iins_class_batch , "C");
       
        strcpy(iref_num1, trim(ply_num1)); 
       
        strcpy(sIassured , trim(sIassured)); 
        strcpy(iapplicant, trim(iapplicant)); 
        /* 1061012002-SC3 ISID+rba �j���I�Gcm_isid_batch=>E */ 				        
        $prepare rba_chk from 
	  	     "insert into cm_isid_batch (iref_num1,iref_num2,iref_num3,idata_type,imember,nmember,icountry,dbirth,idept,iins_class,fkind,ftype,icreate,dcreate,nbatch,fstatus,inotice,ileader) \
	  	                          values(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)";
      
        $prepare getLeaderInfo from  "select ibranch, iquota from officer where iofficer = ? " ;
        $execute getLeaderInfo into $ibranch_leader, $iquota_leader using $sIleader ;
        printf("-- trace sIleader[%s], ibranch_leader[%s], iquota_leader[%s]\n ",sIleader,ibranch_leader, iquota_leader); 
       	    
        if (strcmp(ibranch_leader,"00")==0)
        {
            /* �`���q�f�ֳ��T�w���ӫO��(3201) */
            strcpy(idept, "3201");
        }
        else
        {
      	    strncpy(idept, iquota_leader, 4);  idept[4]='\0';
        }
        printf("idept[%s]\n", idept);
       
        if(strcmp(sIassured,iapplicant) == 0) 
        { 
       	    iLoop_end = 1;
        }
        else
        {
       	    iLoop_end = 2;
        }
        printf("-- trace iLoop_end[%d]\n ",iLoop_end); 
       
        for(i = 1;  i<=iLoop_end; i++)
        { 
       	 
       	    if (iLoop_end==1)
       	    {
       	  	strcpy(idata_type, "3");               /*  idata_type = 1.�n�O�H 2.�Q�O�H  3.�n�O�H = �Q�O�H*/
       	    }
       	    else
       	    {
       	        strcpy(idata_type, itoa(i) ); 
       	    }
       	    printf("i[%d] ,idata_type[%s]\n",i, idata_type);
       	  
       	    if (i==1) /* �n�O�H */ 
       	    {
       	  	strcpy(imember, trim(iapplicant));
       	  	strcpy(nmember, trim(napplicant));
       	  	 
       	  	if( iapplicant_cntry[0] == '9')
       	  	{
       	  	    strcpy(icountry ,"TW");
       	  	}
       	  	else if( iapplicant_cntry[0] == '2')
       	  	{
       	  	    strcpy(icountry ,"CN");
       	  	}
       	  	
       	  	if( strlen(trim(dbirth2)) == 0 )
       	  	{
       	  	    dbirth_batch = DATENULL;
       	  	}
       	  	else
       	  	{
       	  	    rfmtdate(dbirth_batch,"mm/dd/yyyy",dbirth2);
                }
              
       	    }
       	    else
       	    {
       	  	
       	        strcpy(imember, trim(sIassured));
       	  	strcpy(nmember, trim(sNassured));
       	  	 
       	  	if( iassured_cntry[0] == '9')
       	  	{
       	  	    strcpy(icountry ,"TW");
       	  	}
       	  	else if( iassured_cntry[0] == '2')
       	  	{
       	  	    strcpy(icountry ,"CN");
       	  	} 
       	  	 
       	  	dbirth_batch = dbirth;
       	    } 
       	  
       	    $execute rba_chk using $iref_num1, ' ', ' ' ,$idata_type, $imember, $nmember, $icountry, $dbirth_batch, $idept, $iins_class_batch, 
       	                           $fkind_batch , $ftype_batch, $entry, $dt_current, ' ', $fstatus_batch, $entry,$sIleader;  
        }
       
	    	   
        policy_cnt++;
        $COMMIT WORK;
        sleep(1);
    }
    $CLOSE curA;
    $FREE  curA;

    printf("\n====================\n");

    /* �ˮ֬O�_�����P�����j���� */
    $SELECT count(*)
       INTO $cnt_card
       FROM card_temp
      WHERE fstatus in ('0','7');

    if ( cnt_card > 0 )
    {
        printf("cnt_card[%d]\n",cnt_card );

        /* �����P�����j���� */
        strcpy(sremark,"�j���ҥ��P��");
        $UPDATE card_temp
            SET remark = $sremark
      	  WHERE fstatus in ('0','7');
    }

    /**  �}�l���ͳ���  **/
    rc = ca328_report();



    return M_CM_OK;

errexit:
    printf("ca328_body error [%d]\n", SQLCODE );
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    $ROLLBACK WORK;
    return SQLCODE;
}

long ca328_create_table()
{

    $WHENEVER SQLERROR goto errexit;

    $CREATE TEMP TABLE card_temp
    (
        icard    char(20),
        fstatus  char(2)   default ' ',
        ipolicy  char(20)  default ' ',
        remark   char(128) default ' '
    )
    WITH NO LOG;

    $CREATE INDEX card_temp_ix1 ON card_temp(icard);

    printf("Create card_temp success \n");

    sprintf_s(stmt_tmp1,sizeof stmt_tmp1,
                      "CREATE TEMP TABLE policy_temp"
                      "("
                      " itag             char(%d)  default ' ', "
                      " icar_type        char(2)   default ' ', "
                      " ilast_card       char(20)  default ' ', "
                      " ilast_ply        char(20)  default ' ', "
                      " nassured         char(90)  default ' ', "
                      " iassured         char(12)  default ' ', "
                      " ipolicy          char(20)  default ' ', "
                      " icard            char(20)  default ' ', "
                      " iofficer         char(10)  default ' ', "
                      " iroute           char(20)  default ' ', "
                      " dply_begin       DATE, "
                      " dply_end         DATE, "
                      " fcomp_class      char(2)   default ' ', "
                      " fcomp_class_last char(2)   default ' ', "
                      " mins_premium     integer,  "
                      " mother_busi      integer,  "
                      " mservice         integer,  "
                      " remark           char(128),"
                      " iapplicant       char(12), "
                      " napplicant       char(120),"
                      " ndeputy_assured  char(51), "
                      " fapplicant       char(2),  "
                      " fsex_appl	 char(2),  "
                      " dbirth_app       char(11), "
                      " itel_appl	 char(21), "
                      " ndeputy_appl     char(51), "
                      " nrelation_appl   char(41), "
                      " qdrunk_driving   integer,  "
                      " iestimate        char(20)  default ' ', "
                      " fecard           char(1)   default '0', "
                      " aemail_eply      char(50)  default ' ', "
                      " ireg_no          char(20), "
                      " tmobile_appl     char(20), "
                      " aemail_appl      char(50), "
                      " qviolate         integer,  "
                      " iassured_cntry   char(1),  "
                      " nassured_cntry   char(50), "
                      " iapplicant_cntry char(1),  "
                      " napplicant_cntry char(50), "
                      " seqo             smallint  "
                      ")WITH NO LOG;",CA_TAG_NUM-1);
     
    $PREPARE stmp1 FROM $stmt_tmp1;
    $EXECUTE stmp1;

    $CREATE INDEX policy_temp_ix1 ON policy_temp(ilast_card);
    $CREATE INDEX policy_temp_ix2 ON policy_temp(ilast_ply);

    printf("Create policy_temp success \n");

    sprintf_s(stmt_tmp2,sizeof stmt_tmp2,
                        "CREATE TEMP TABLE CAR328_getfile"
                        "("
                        "  itag              char(%d), "
                        "  iofficer          char(10), "
                        "  iroute            char(20), "
                        "  mother_busi       integer,  "
                        "  mservice          integer,  "
                        "  iapplicant	     char(12), "
                        "  napplicant	     char(120),"
                        "  ndeputy_assured   char(51), "
                        "  fapplicant	     char(2),  "
                        "  fsex_appl	     char(2),  "
                        "  dbirth_app	     char(11), "
                        "  itel_appl	     char(21), "
                        "  ndeputy_appl	     char(51), "
                        "  nrelation_appl    char(41), "
                        "  fecard            char(1),  "
                        "  aemail_eply       char(50), "
                        "  ireg_no           char(20), "
                        "  tmobile_appl      char(20), "
                        "  aemail_appl       char(50), "
                        "  iassured_cntry    char(1),  "
                        "  nassured_cntry    char(50), "
                        "  iapplicant_cntry  char(1),  "
                        "  napplicant_cntry  char(50), "
                        "  seqo              serial    "
                        ") WITH NO LOG;",CA_TAG_NUM-1);
     
    $PREPARE stmp2 FROM $stmt_tmp2;
    $EXECUTE stmp2;

    printf("Create CAR328_getfile \n");

    return M_CM_OK;

errexit:
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

long  ca328_getfile()
{
    int   rtncode;
    int   k,m,i,n, rc, rc1;
    $int  seqo;
    char  local_dbname[41];
    char  FullGetName[101], FullLogName[101], FullRptName[101];
    char  GetName[51], LogName[51], RptName[51], TmpName[51];
    char  cmd_stmt[20480];
    $char itag[CA_TAG_NUM], iofficer[11], iroute[21];
    $long mother_busi, mservice;
    $WHENEVER sqlerror goto errexit;

    strcpy(local_dbname, get_full_dbname(DBName));

    printf("  into read file \n");
    rtncode = getApHome(sApHome);
    if (rtncode < 0)
    {
        sprintf_s( v_sMsg,sizeof v_sMsg,"read Config file error!!\n");
        printf("%s\n", v_sMsg);
        return M_CM_READ_CONFIG_ERR;
    }
    $DELETE FROM CAR328 WHERE 1=1;
    /* client�ݱNuser���Ѫ����X�檺�����ftp��/dat/car/ */

    sprintf_s( LogName,sizeof LogName,"car328_load_err_%s.txt", outputf);
    sprintf_s( FullGetName,sizeof FullGetName, "%s/dat/car/%s", sApHome, filename);
    sprintf_s( FullLogName,sizeof FullLogName, "%s/rptftp/%s", sApHome, LogName);

    printf("LogName[%s]\n", LogName);
    printf("FullGetName[%s]\n", FullGetName);
    printf("FullLogName[%s]\n", FullLogName);

    sprintf_s(stmt,sizeof stmt,"load from %s delimiter '\t' \r\n"
                               "insert into car328 \n"
                               "(itag,iofficer,iroute,mservice,mother_busi,iapplicant,napplicant,fapplicant, \n"
                               " fsex_appl,dbirth_appl,itel_appl,tmobile_appl,aemail_appl, \n"
                               " ndeputy_appl,nrelation_appl,ndeputy_assured,fecard,aemail_eply,ireg_no, \n"
                               " iassured_cntry,nassured_cntry,iapplicant_cntry,napplicant_cntry); \r\n", FullGetName);

    printf("local_dbname[%s]\n", local_dbname);
    sprintf_s(cmd_stmt,sizeof cmd_stmt,"dbaccess %s > %s 2>&1 << !\r\n"
                                       "%s\r\n!", local_dbname, FullLogName, stmt);

    printf("cmd_stmt[%s]\n",cmd_stmt);

    rc = system(cmd_stmt);
    if (rc != 0) 
    {
        sprintf_s( v_sMsg,sizeof v_sMsg,"���J���X���Ƶo�Ϳ��~\r\n"
                                        "���I���ɮפU���@�~�d��[Q],�ɦW:[%s]�T�w���~��]", LogName);
        printf("v_sMsg[%s]\n", v_sMsg);
        rc1=rptftpinsert(userid,"car328", LogName);
        printf("rc1[%d]\n", rc1);
        if (rc1!=0)
        {
            sprintf_s( v_sMsg,sizeof v_sMsg,"%s�g�Jrptftplist���~\r\n", LogName);
            printf("v_sMsg[%s]\n", v_sMsg);
            return -1;
        }

        return -1;
    }

    $DECLARE curs1 CURSOR FOR
      SELECT * FROM car328;
    $OPEN curs1;
    puts("open curs1");
    for(;;)
    {
        $FETCH curs1 INTO $itag, $iofficer, $iroute, $mservice, $mother_busi,
                          $iapplicant, $napplicant,
                          $fapplicant, $fsex_appl, $dbirth1, $itel_appl,
                          $ndeputy_appl, $nrelation_appl, $ndeputy_assured, $fecard, 
                          $aemail_eply, $ireg_no, $tmobile_appl, $aemail_appl,
                          $iassured_cntry, $nassured_cntry, $iapplicant_cntry, $napplicant_cntry;
        printf("fetch curs1[%d]\n", SQLCODE);
        if( SQLCODE == SQLNOTFOUND) break;

        /* �ഫ�n�O�H�ͤ� */
        strcpy(dbirth1, trim(dbirth1));
        if (strcmp(fapplicant,"1") == 0)
        {	
            /* �۵M�H */
            if ((strlen(dbirth1) < 7 ) || (strlen(dbirth1) > 7 ))
	    {
	        sprintf_s( v_sMsg,sizeof v_sMsg,"����[%s]�n�O�H�ͤ�[%s]�榡���~[CYY/MM/DD]\r\n", itag,dbirth1);
	        printf("v_sMsg[%s]\n", v_sMsg);
	        return -1;
	    }
	    else if (strlen(dbirth1) < 7 )
	    {
	        strncpy(sYY,  &dbirth1[0], 2); sYY[2]='\0';
	        strncpy(sMM,  &dbirth1[2], 2); sMM[2]='\0';
	        strncpy(sDD,  &dbirth1[4], 2); sDD[2]='\0';
	    }
	    else
	    {
	        strncpy(sYY,  &dbirth1[0], 3); sYY[3]='\0';
	        strncpy(sMM,  &dbirth1[3], 2); sMM[2]='\0';
	        strncpy(sDD,  &dbirth1[5], 2); sDD[2]='\0';
	    }
	    sprintf_s(tmp_birth,sizeof tmp_birth,"%s/%s/%s", sYY,sMM,sDD);
	    strcpy(dbirth2, cm_to_infdate(tmp_birth));
	}
	else
	{
	    dbirth2[0]='\0';
	    strcpy(fsex_appl," ");
	}
	
	printf("dbirth2=[%s],tmp_birth=[%s],dbirth2=[%s]\n",dbirth1,tmp_birth,dbirth2);
	
        $INSERT INTO CAR328_getfile
         ( itag, iofficer, iroute, mother_busi, mservice,
           iapplicant, napplicant,ndeputy_assured, fapplicant, fsex_appl, dbirth_app, itel_appl,
           ndeputy_appl, nrelation_appl, fecard, aemail_eply, ireg_no, tmobile_appl, aemail_appl,
           iassured_cntry, nassured_cntry, iapplicant_cntry, napplicant_cntry)
         VALUES
         ( $itag, $iofficer, $iroute, $mother_busi, $mservice,
           $iapplicant, $napplicant, $ndeputy_assured, $fapplicant, $fsex_appl, $dbirth2, $itel_appl,
           $ndeputy_appl, $nrelation_appl, $fecard, $aemail_eply, $ireg_no, $tmobile_appl, $aemail_appl,
           $iassured_cntry, $nassured_cntry, $iapplicant_cntry, $napplicant_cntry);
    }
    $CLOSE curs1;
    $FREE curs1;


    printf ("Loading %s to car328 Complete!!\n", FullGetName);

    return M_CM_OK;

errexit:
    printf("ca328_getfile SQLCODE [%d]\n", SQLCODE );
    rc = SQLCODE;
    return rc;
}

long ca328_set_cardtemp()
{

    $char cIcard[20], cFstatus[2], cremark[129];
    $long iCount;

    $WHENEVER SQLERROR goto errexit;
    card_num = 0;


    $SELECT count(*)
       INTO $iCount
       FROM compulsory_card
      WHERE icard >= $card_bgn
        AND icard <= $card_end;
    if( iCount > 2000)
    {
        sprintf_s(v_sMsg,sizeof v_sMsg,"�d�����i�W�X2000��");
        return -1;
    }

    $DECLARE cur_setcard CURSOR for
      SELECT icard, fstatus
        INTO $cIcard, $cFstatus
        FROM compulsory_card
       WHERE icard >= $card_bgn
         AND icard <= $card_end;
    $OPEN cur_setcard;
    while(1)
    {
        $FETCH cur_setcard;
        if(SQLCODE == SQLNOTFOUND) break;

        printf("cIcard[%s], cFstatus[%s]\n", cIcard, cFstatus);      

        /* 1060821005_C2_�j���Һ޲z�{�� */
        switch ( cFstatus[0] )
        {
      	    case '0' :
      	    case '5' :
      	    case '6' :
      	        strcpy( cremark, " ");
      	 	break;
      	 	
      	    default:
      	        sprintf_s( cremark,sizeof cremark,"���j���Ҫ��A (���A= %s)���i�i��ñ��@�~,�нT�{���ҥd�O�_���wñ��Υ�ñ�o����L���A",cFstatus);
      	        break;
        }    	      

        $INSERT INTO card_temp ( icard, fstatus, remark )
         VALUES ( $cIcard, $cFstatus, $cremark );

        card_num++;
    }
    $CLOSE cur_setcard;
    $FREE  cur_setcard;


    return M_CM_OK;

errexit:
    strcpy( v_sMsg, sqlca.sqlerrm);
    return SQLCODE;
}

long ca328_set_policytemp()
{
    $char pIcard[20], pItag[CA_TAG_NUM], pIpolicy[20];
    $date bdply_end;
    $int  seqo;

    /* �NCAR328_getfile ��Ƽg�Jpolicy_temp */
    $WHENEVER SQLERROR CONTINUE;
    policy_num = 0;
    iQdrunk_driving = 0;
    iQviolate = 0;

   
    $DECLARE cur_car328 CURSOR for
      SELECT itag, seqo, iofficer, iroute, mother_busi, mservice,
             iapplicant, napplicant, ndeputy_assured, fapplicant, fsex_appl, dbirth_app, itel_appl,
             ndeputy_appl, nrelation_appl , fecard, aemail_eply, ireg_no, tmobile_appl, aemail_appl,
             iassured_cntry, nassured_cntry, iapplicant_cntry, napplicant_cntry
        INTO $pItag, $seqo, $sIofficer, $sIroute, $mother_busi, $mservice,
             $iapplicant, $napplicant, $ndeputy_assured, $fapplicant, $fsex_appl, $dbirth2, $itel_appl,
             $ndeputy_appl, $nrelation_appl , $fecard, $aemail_eply, $ireg_no, $tmobile_appl, $aemail_appl,
             $iassured_cntry, $nassured_cntry, $iapplicant_cntry, $napplicant_cntry
        FROM CAR328_getfile;

    $OPEN cur_car328;
    while(1)
    {
        $FETCH cur_car328;
        if(SQLCODE == SQLNOTFOUND) break;


        $DECLARE curASS CURSOR for
          SELECT a.ipolicy, a.icard, a.itag, b.dply_end
            INTO $pIpolicy, $pIcard, $pItag, $bdply_end
            FROM assured_vs_ply a , ply_relation b ,ply_ins_type c
           WHERE a.icard = b.icard AND c.ipolicy = b.ipolicy
             AND (a.itag = $pItag or
                  a.itag = (SELECT itag_last FROM ca_change_tag where itag_next = $pItag) or
                  a.itag = (SELECT itag_next FROM ca_change_tag where itag_last = $pItag)
                 )
             AND b.dply_end >= $sply_begin
             AND b.dply_end <  $sply_end
             AND b.fcard_class = '1'
             AND c.mdamage_cover <> 0
           ORDER BY b.dply_end DESC;

        $OPEN curASS;
        $FETCH curASS;
        
       
        if(SQLCODE == SQLNOTFOUND )
        {
      	    strcpy( pIpolicy, " ");
      	    strcpy( pIcard, " ");
        }
        else if (SQLCODE < 0)
        {
      	    strcpy( pIpolicy, "SystemBusy");
      	    strcpy( pIcard, " ");		
        }


        $CLOSE curASS;
        $FREE  curASS;
 
        
        printf("itag[%s], ilast_ply[%s], seqo[%d], iofficer[%s], icorps[%s], mother_busi[%d], mservice[%d]\n", pItag, pIpolicy, seqo, sIofficer, sIcorps, mother_busi, mservice);
        

        $INSERT INTO policy_temp
      	      ( itag, ilast_card, ilast_ply, seqo, iofficer, iroute, mother_busi, mservice,
                iapplicant, napplicant, ndeputy_assured, fapplicant, fsex_appl, dbirth_app, itel_appl,
                ndeputy_appl, nrelation_appl, qdrunk_driving, fecard, aemail_eply, ireg_no, 
                tmobile_appl, aemail_appl, qviolate,
                iassured_cntry, nassured_cntry, iapplicant_cntry, napplicant_cntry)
         VALUES
       	      ( $pItag, $pIcard, $pIpolicy, $seqo, $sIofficer, $sIroute, $mother_busi, $mservice,
                $iapplicant, $napplicant, $ndeputy_assured, $fapplicant, $fsex_appl, $dbirth2, $itel_appl,
                $ndeputy_appl, $nrelation_appl, $iQdrunk_driving ,$fecard, $aemail_eply ,$ireg_no, 
                $tmobile_appl, $aemail_appl, $iQviolate,
                $iassured_cntry, $nassured_cntry, $iapplicant_cntry, $napplicant_cntry);        	
        


        policy_num++;
    }
    $CLOSE  cur_car328;
    $FREE   cur_car328;


    return M_CM_OK;

errexit:
    strcpy( v_sMsg, sqlca.sqlerrm);
    return SQLCODE;
}

long ca328_report()
{
    char  date_str[17], yy[4], mm[2], dd[2], hhmin[6];
    char  sTmpBuf2[10];
    $char  eicard[20], efstatus[2], eremark[129], pitag[CA_TAG_NUM], pilast_card[20];
    $char  pnassured[90], pipolicy[20], picard[20], piofficer[10], pdply_begin[11];
    $char  pdply_end[11], premark[129], pfcomp_class[3], pfcomp_class_last[3];
    $long  pmins_premium;
    $char  sIestimate[21];
    printf("\n===================\nin ca328_report \n");

    strcpy(date_str, cm_get_sysd2_100());
    strcpy(yy, "");
    strcpy(mm, "");
    strcpy(dd, "");
    strcpy(hhmin, "");
    printf("date_str[%s]\n",date_str);

    rgu_put_body(1);

    rgu_put_body_string(2,trim(dply_yy),LEFT);
    rgu_put_body_string(2,trim(dply_mm),LEFT);

    yy[0] = date_str[0];
    yy[1] = date_str[1];
    yy[2] = date_str[2];
    yy[3] = '\0';
    rgu_put_body_string(2,trim(yy),LEFT);


    mm[0] = date_str[4];
    mm[1] = date_str[5];
    mm[2] = '\0';
    rgu_put_body_string(2,trim(mm),LEFT);

    dd[0] = date_str[7];
    dd[1] = date_str[8];
    dd[2] = '\0';
    rgu_put_body_string(2,trim(dd),LEFT);

    strncpy(hhmin , date_str+10 , 5 );
    hhmin[5] = '\0';
    rgu_put_body_string(2,trim(hhmin),LEFT);

    rgu_put_body(2);
    rgu_put_body(3);
    max_cnt += 3;

    /* card_temp ���`�󳡥� */
    $DECLARE curErr CURSOR for
      SELECT icard, fstatus, remark
        INTO $eicard, $efstatus, $eremark
        FROM card_temp
       WHERE fstatus not in ('0','5','6')  /* 1060821005_C2_�j���Һ޲z�{�� */
         AND ipolicy = ' ';

    $OPEN curErr;
    while(1)
    {
        $FETCH curErr;
        if(SQLCODE == SQLNOTFOUND) break;
        /* show �X�s�j���Ҹ��B�Ƶ� */
        rgu_put_body_string(4," ",LEFT);
        rgu_put_body_string(4," ",LEFT);
        rgu_put_body_string(4," ",LEFT);
        rgu_put_body_string(4," ",LEFT);
        rgu_put_body_string(4,trim(eicard),LEFT);
        rgu_put_body_string(4," ",LEFT);
        rgu_put_body_string(4," ",LEFT);
        rgu_put_body_string(4," ",LEFT);
        rgu_put_body_string(4," ",LEFT);
        rgu_put_body_string(4," ",LEFT);
        rgu_put_body_string(4," ",LEFT);
        rgu_put_body_string(4," ",LEFT);
        rgu_put_body_string(4," ",LEFT);
        rgu_put_body_string(4," ",LEFT);
        rgu_put_body_string(4," ",LEFT);
        rgu_put_body_string(4," ",LEFT);
        rgu_put_body_string(4," ",LEFT);
        rgu_put_body_string(4,trim(eremark),LEFT);
        rgu_put_body(4);
        max_cnt++;
    }
    $CLOSE curErr;
    $FREE  curErr;


    /** policy_temp **/
    $DECLARE curPol CURSOR for
      SELECT itag, icar_type, ilast_card, nassured, iassured, ipolicy, icard, iofficer, iroute,
             dply_begin, dply_end, fcomp_class, fcomp_class_last,
             mins_premium, mservice, mother_busi, remark, iestimate
        INTO $pitag, $sIcar_type, $pilast_card, $pnassured, $sIassured, $pipolicy, $picard, $piofficer,
             $sIroute,
             $pdply_begin, $pdply_end, $pfcomp_class, $pfcomp_class_last,
             $pmins_premium, $mservice, $mother_busi, $premark, $sIestimate
        FROM policy_temp;
    $OPEN curPol;
    while(1)
    {
        $FETCH curPol;
        if(SQLCODE == SQLNOTFOUND) break;
        printf("pfcomp_class=%s\npfcomp_class_last=%s\n",pfcomp_class,pfcomp_class_last);
        rgu_put_body_string(4,trim(pitag),LEFT);
        rgu_put_body_string(4,trim(sIcar_type),LEFT);
        rgu_put_body_string(4,trim(pilast_card),LEFT);
        rgu_put_body_string(4,trim(pnassured),LEFT);
        rgu_put_body_string(4,trim(sIassured),LEFT);
        rgu_put_body_string(4,trim(pipolicy),LEFT);
        rgu_put_body_string(4,trim(picard),LEFT);
        rgu_put_body_string(4,trim(sIestimate),LEFT);
        rgu_put_body_string(4,trim(piofficer),LEFT);
        rgu_put_body_string(4,trim(sIroute),LEFT);
        rgu_put_body_string(4,trim(pdply_begin),LEFT);
        rgu_put_body_string(4,trim(pdply_end),LEFT);
        rgu_put_body_string(4,trim(pfcomp_class_last),LEFT);
        rgu_put_body_string(4,trim(pfcomp_class),LEFT);

        rfmtlong(pmins_premium, "-,---,--&", sTmpBuf2);
        rgu_put_body_string(4,sTmpBuf2,LEFT);
        rfmtlong(mservice, "-,---,--&", sTmpBuf2);
        rgu_put_body_string(4,sTmpBuf2,LEFT);
        rfmtlong(mother_busi, "-,---,--&", sTmpBuf2);
        rgu_put_body_string(4,sTmpBuf2,LEFT);
        rgu_put_body_string(4,trim(premark),LEFT);
        rgu_put_body(4);
        max_cnt++;

    }
    $CLOSE curPol;
    $FREE  curPol;

    rfmtlong(policy_num, "--,---,--&", sTmpBuf2);
    rgu_put_body_string(5,sTmpBuf2,LEFT);
    rfmtlong(card_num, "--,---,--&", sTmpBuf2);
    rgu_put_body_string(5,sTmpBuf2,LEFT);
    rfmtlong(policy_cnt, "--,---,--&", sTmpBuf2);
    rgu_put_body_string(5,sTmpBuf2,LEFT);
    rfmtlong(error_cnt, "--,---,--&", sTmpBuf2);
    rgu_put_body_string(5,sTmpBuf2,LEFT);
    rgu_put_body(5);

    return M_CM_OK;

errexit:
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}


int GetData(data,offset,length)
char *data;
int offset,length;
{
    data[0]='\0';
    memcpy(data,offset,length);
    data[length] = 0x00;
    printf("data[%s]\n",data);
}

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
    char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
    char sTmp_db_name[21];

    sTmp_db_name[0]='\0';
    if (*sIpolicy != '\0' && *sIpolicy !=' ')
    {
        sTmp_db_name[0]='\0';
        strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
        strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
        strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
    }
    return sTmp_db_name;
}
