/**********************************************************************/
/*   program id   : ca625q04s.ec                                      */
/*   program name : �M�׸�Ƥ��@�~--�Ҧ��O��                        */
/*   date written : 2004/05/20                                        */
/*   date modify  : 2004/mm/dd                                        */
/*   files        : ply_relation        i                             */
/*   temp table   : car6254             io                            */
/*   Checked for ����100�~�M��                                        */
/**********************************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
$include sqlca;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "car_equip.h"
#include "safeclib.h"
/*--------------------------------------------------------------------*/
$char   h_dbgn[11],h_dend[11];
$char   icard[21],ipolicy[21],iengine[21],itag[CA_TAG_NUM],fcard_class[2];
$char   nassured[11],dpolicy[11],iofficer[11],nofficer[11];
$char   iquota[7],nquota[21],remark[31],nremark[91],remark1[3];
$char   dply_begin[11],dply_end[11],ncode[31];
$int    qfield_all,qfield_chk;
$char   equipdecode[201];
$char   napplicant[121],iapplicant[13];

$char   sdata[24][41];

int     flen,cnt;
FILE    *fp;
char    sApHome[30];
char    filename[50],fulldb[21];

$char   DBName[05];
char    outputf[N_FILE+1], userid[11];

char    msgbuf[100];
int 		iTmpCode;
/*--------------------------------------------------------------------*/
car6254(DBName1,userid1,dbgn1,dend1,outputf1)
$char *DBName1,*userid1,*dbgn1,*dend1,*outputf1;
{  
int rc;

   printf("dbname[%s]userid[%s]output[%s]\n",DBName,userid,outputf);

   strcpy(DBName, DBName1);
   strcpy(userid, userid1);
   strcpy(h_dbgn, dbgn1);
   strcpy(h_dend, dend1);
   strcpy(outputf,outputf1);

   rc = car6254_get_db();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   rc = car6254_read_file();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   rc = car6254_write_text();
   if (rc != SUCCESS) {
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   return rc;
}
/*--------------------------------------------------------------------*/
long car6254_get_db()
{
int    rc;
$char  stmt[512];

   if (db_select(DBName) == False) {
       strcpy(msgbuf,"M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   rc = getApHome(sApHome);
   if (rc < 0) {
       strcpy(msgbuf,"read Config file error!!-->getApHome\n");
       return rc;
    }
    
   strcpy(stmt,
         "select '[' || trim(ncode) || ']' from cu_code_data  "
           "where itype = '25' and icode = ? ");
   $prepare pre_code from $stmt;

   return SUCCESS;

errexit:
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
long car6254_read_file()
{
char   *bp;
int    rc,i,j,k,m,n;

    $whenever sqlerror goto errexit;

    rc=car6254_create_temp();
    if (rc != SUCCESS)
        return rc;

    sprintf_s(filename, sizeof filename,"%s/dat/car/car625.txt",sApHome);
    flen=80;
    qfield_all = 1;
    qfield_chk = 1;
    if ((fp=fopen(filename,"r"))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���",filename);
       return FALSE;
    }
    if ((bp=malloc(flen))==NULL) {
       sprintf_s(msgbuf, sizeof msgbuf,"System malloc failed !");
       free(bp);
       return FALSE;
    }

    for (i=0;(feof(fp)==0);i++) {
        memset(bp,0x00,flen);
        fgets(bp,flen,fp);
        if (bp[0]==0x00)
           break;
        for(j=0;j<qfield_all;j++)
           memset(sdata[j],0x00,41);
        k=m=n=0;
        for (j=0;j<flen;j++) {
            if (bp[j]=='\t' || bp[j]=='\0' || bp[j]=='\n') {
                strncpy(sdata[k],bp+m,j-m);
                sdata[k][j-m]='\0';
                m=j+1;
                k++;
            }
            if (bp[j]=='\n')
                break;
            if (k > (qfield_all - 1)) break;
        }      
        if (sdata[0][0]=='\0') continue;
        rtrim_alldata4();
        
        printf("iengine[%s]\n",iengine);
        rc=car6254_read_ply();
        if (rc!=SUCCESS)
           return rc;
    }

    return SUCCESS;
errexit:
    sqlfatal();
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6254_read_ply()
{
int    rc,i;
$char  stmt[1024],stmt1[512],stmtdt[81];
extern struct sEquip *IfirstEquip, *IcurrEquip, *IlastEquip, *IEquip_ptr;

   $whenever sqlerror goto errexit;

   if (h_dbgn[0]=='*')
      strcpy(stmtdt," ");
   else
      sprintf_s(stmtdt, sizeof stmtdt,"and dpolicy between '%s' and '%s' ",h_dbgn,h_dend);

   $declare cur_vs cursor for
     select ipolicy,icard,itag,nassured,fcard_class
       into $ipolicy,$icard,$itag,$nassured,$fcard_class
       from assured_vs_ply
      where iengine = $iengine;
   $open cur_vs;
   
   while(1) {
      $fetch cur_vs;
      if (SQLCODE==SQLNOTFOUND) break;

      printf("ipolicy[%s]\n",ipolicy);
      strcpy(fulldb,get_car_full_db(ipolicy));
      
      sprintf_s(stmt, sizeof stmt,
        "select iquota,dpolicy,dply_begin,dply_end, "
                "iofficer, "
                "(select nequipment from %s:policy  "
                "  where ipolicy = a.ipolicy), "
                "(select nbranch from sa_branch_type  "
                "  where ibranch = a.iquota[1,4]||'00'), "
                "(select nname from officer where iofficer = a.iofficer), "
                "(select iapplicant from %s:policy where ipolicy = a.ipolicy),  "
                "(select napplicant[1,40] from %s:policy where ipolicy = a.ipolicy)  "
           "from %s:ply_relation a  "
          "where a.ipolicy = ?  %s "
            "and a.fedr_class != '1'",fulldb,fulldb,fulldb,fulldb,stmtdt); 
      $prepare pre_2 from $stmt;
      $execute pre_2 into $iquota,$dpolicy,$dply_begin,$dply_end,
                     $iofficer,$remark,$nquota,$nofficer,$iapplicant,$napplicant
               using $ipolicy;
      if (SQLCODE==SQLNOTFOUND) continue;

      nremark[0]='\0';
      strcpy(equipdecode,equip_get(remark));
      IEquip_ptr=IfirstEquip;
      while (IEquip_ptr)
      {
          /******
          i = IEquip_ptr->iequip;
          strcpy(remark1,itoa(i));
          ******/
          strcpy(remark1,IEquip_ptr->sequip);
          iTmpCode = atoi(remark1);
          sprintf_s(remark1, sizeof remark1,"%02d",iTmpCode);
          
          $execute pre_code into $ncode using $remark1;
          if (SQLCODE != SQLNOTFOUND)
          {
             if ((strlen(nremark)+strlen(ncode))>90) break;
             strcat(nremark,rtrim(ncode));
             strcat(nremark," ");
          }

          IEquip_ptr=IEquip_ptr->next;
      }
      /****************************************************************
      for(i=0;i<30;i++)
      {
         if (remark[i]=='1') 
         {
            strcpy(remark1,itoa(i+1));
            $execute pre_code into $ncode using $remark1; 
            if ((strlen(nremark)+strlen(ncode))>90) break;
            strcat(nremark,rtrim(ncode));
            strcat(nremark," ");
         }
      }
      ****************************************************************/
      $insert into car6254
       values ($iengine,$fcard_class,$ipolicy,$icard,$itag,$dpolicy,
               $dply_begin,
               $dply_end,$iofficer,$nofficer,$iquota,$nquota,$nassured,
               $iapplicant,$napplicant,$nremark);
   }
   $close cur_vs;
   $free  cur_vs;
   return SUCCESS;
errexit:
   sqlfatal();
   strcpy(msgbuf,sqlca.sqlerrm);
   return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car6254_write_text()
{
int   rc;
char  sfilename[41],stitle[252],stmt[1024];
    
    strcpy(sfilename,"�������X����ƪ�");
    strcpy(stitle,"�������X\t�j����N�O\t�O�渹�X\t�ҥd���X\t�P�Ӹ��X\tñ����\t�_�O���\t������\t�g��N�X\t�g��W��\t���N�X\t���W��\t�Q�O�I�H\t�n�O�HID\t�n�O�H�m�W\t���O\n");
    strcpy(stmt,"select * from car6254 order by 1,2,3");
printf("before unload\n");
    rc = unload_file(outputf," ",sfilename,stitle,stmt);
    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        return rc;
    }

    return SUCCESS;
}
/*--------------------------------------------------------------------*/
long car6254_create_temp()
{
    $whenever sqlerror goto errexit;
      
    $create temp table car6254
     (iengine        char(20),
      fcard_class    char(1),
      ipolicy        char(20),
      icard          char(20),
      itag           char(12),
      dpolicy        date,
      dply_begin     date,
      dply_end       date,
      iofficer       char(10),
      nofficer       char(10),
      iquota         char(06),
      nquota         char(20),
      nassured       char(10),
      iapplicant     char(12),
      napplicant     char(40),
      nremark        char(60))
     with no log;

    return SUCCESS;
errexit:
    sqlfatal();
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
rtrim_alldata4()
{
int  x;
    for(x=0;x<qfield_all;x++)
       strcpy(sdata[x],rtrim(sdata[x]));
    strcpy(iengine,sdata[qfield_chk-1]);
}
/*--------------------------------------------------------------------*/
