/*******************************************/
/*                                         */
/*   PROGRAM : ca417q01s.ec                */
/*                                         */
/*   DATE    : 920402                      */
/*                                         */
/*******************************************/

#include <stdio.h>
#include <math.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "carmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
$include sqltypes.h;
$include cmnroute.h;

extern char RPTDIR[];

int  first,flag;

$char DBName[5],FormTp[3];
$char outputf[N_FILE+1], userid[6];
static int max_cnt=0;

$char dbgn1[11],dend1[11];
$char deffect[11];
$char dprint[11];
$char dpolicy_bgn[11],dpolicy_end[11];
/* 1000311003 �q��2 */
$char g_iroute[21];
$char ibroker[11];
$char processid[21];
$long lprocessid;
$char ckind[2];
$char sIprocess[21];
$char sFstatus[2];
$char sDummy[11];
$char sErrmsg[512];
$char iins_type_input[7];
$char icar_type[3];
$char iins_cat[2];
$char iyear[3];
$int  qply_period;
char  v_sMsg[1512];

long car417_accumulate();
long car417_report();
char *get_car_full_db();

#define fmt "---,---,---,---"

/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;

   batchinit();
   strcpy(DBName,    isNULLstr(argv[1]));
   strcpy(userid,    isNULLstr(argv[2]));
   strcpy(ckind,     isNULLstr(argv[3]));

   strcpy(deffect,"");
   strcpy(dprint,"");
   if (ckind[0] == '1')
   {
       strcpy(dbgn1,     isNULLstr(argv[4]));
       strcpy(dend1,     isNULLstr(argv[5]));
       /* 1000311003 �q��2 */
       strcpy(g_iroute,    isNULLstr(argv[6]));
       strcpy(ibroker,   isNULLstr(argv[7]));
       strcpy(sDummy,    isNULLstr(argv[8]));
   }
   else if (ckind[0] == '2')
   {
       strcpy(dbgn1,     isNULLstr(argv[4]));
       strcpy(dend1,     isNULLstr(argv[5]));
       /* 1000311003 �q��2 */
       /* �̳�����@�߬��j�v��A�j�v��]�ȵL�q���N���A������g���H������A���q���N��client�@�߶Ǫť� */
       strcpy(g_iroute,    isNULLstr(argv[6]));
       strcpy(ibroker,   isNULLstr(argv[7]));
       strcpy(deffect,   isNULLstr(argv[8]));
   }
   else
   {
       strcpy(sIprocess, isNULLstr(argv[4]));
       strcpy(sFstatus,  isNULLstr(argv[5]));
       strcpy(sDummy,    isNULLstr(argv[6]));
       strcpy(sDummy,    isNULLstr(argv[7]));
       strcpy(sDummy,    isNULLstr(argv[8]));
   }
   strcpy(iins_type_input,   isNULLstr(argv[9]));
   strcpy(outputf        ,   isNULLstr(argv[10]));

   if ((ckind[0] == '1') || (ckind[0] == '2'))
   {
       strcpy(dpolicy_bgn, cm_to_infdate(dbgn1));
       strcpy(dpolicy_end, cm_to_infdate(dend1));

       if (ckind[0] == '2')
       {
          strcpy(deffect,     cm_to_infdate(deffect));
       }

       lprocessid = atol(outputf);
       rfmtlong(lprocessid,"-------------&",processid);
       strcpy(processid,trim(processid));
printf("processid[%s]\n",processid);
       printf("dpolicy_bgn[%s]\n",dpolicy_bgn);
       printf("dpolicy_end[%s]\n",dpolicy_end);
       printf("deffect[%s]\n",deffect);
       printf("ibroker[%s]\n",ibroker);

       rc = car417_accumulate();
       if (rc != M_CM_OK)
       {
           printf("rc[%d],err[%s]\n",rc,sErrmsg);
           EWRITE(userid, rc, sErrmsg);
           return rc;
       }

       rc = car417_report(DBName,userid,processid,"3",outputf);
       if (rc != M_CM_OK)
       {
           EWRITE(userid, rc, "car417 ���ͳ������~");
           return rc;
       }
   }
   else
   {
       if (sFstatus[0] == 'A')
           strcpy(sFstatus,"4");

       rc = car417_report(DBName,userid,sIprocess,sFstatus,outputf);
       if (rc != M_CM_OK)
       {
           EWRITE(userid, rc, "car417 ���ͳ������~");
           return rc;
       }
   }
}

/*----------------------------------------------------------------------------*/
long car417_accumulate()
{
   int rc;
   $int     i,sqltmp;
   $char    branch[3];
   $char    stmt[3000], stmp[128];
   $char    sFull[21];
   $char    ipolicy[21],iins_type[7];
   $char    iendorse[21];
   $char    ipaid_base[2];
   $char    fcard_class[2];
   $long    existcnt;

   $long    mins_premium,mdiscount,mcommission,magent;
   $double  pcommission,pagent;
   $double  pcommission_new,pagent_new, pbusiness_new, pdiscount_new, pextra_charge_new;
   $long    mcommission_new,mdamagecover;
   $int     iedr_cnt;
   $long    mcomm_diff,magent_diff,mdeal_diff;
   $double  mservice;

   $long    mcomm_33,magent_33;
   $long    mcomm_new,magent_new; 

   $char    fagent[2], drate_ym[5], drate_ym_rel[5];
   $date    dwritten;
   $double  dMod;
   $long    ext_cnt;
   $int     ihas;
   $long    dprint_tmp, iCount;
   $int     flag_tmp;
   $char    sWhere_ins[300];
   $char   sCCC1[101], sCCC2[101], sCCC3[101], f980401[2], irelative_ply[21];
   double rCCC1, rCCC2, rCCC3;
   char  sIupcompShort[2], policyDB[21], policyDBname[41];

   /* 1000311003 �q��2 */
   $char   insure_type[2], iofficer[11], fstart[2], fauth[2];
   $char   irate_type[2],iroute_comm[4];
   $char   ileader[11], iquota[11], icomm_obj[11], iroute[21], iroute_prop[3];
   $char   opt[2], swhere[128];
   int     *o_qrec;
   $struct cm_route_comm o_stcomm;

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return FAIL;
   }

   /* 1000311003 �q��2 */
   memset(&o_stcomm, 0, sizeof(o_stcomm));
   o_qrec = 0;
   strcpy( insure_type, "C");
   iofficer[0] = fstart[0] = fauth[0] = '\0';

   if( strlen( trim(ibroker)) != 0)  /* ����Jibroker */
   {
       rc = chk_ibroker_expire( ibroker, sErrmsg);
       if( rc != M_CM_OK)
       {
           return rc;
       }
   }

    strcpy(sErrmsg," ");
    mins_premium = mdiscount = mcommission = magent = 0;
    pcommission = pagent = 0;
    pcommission_new = pagent_new = pbusiness_new = pdiscount_new = pextra_charge_new = 0;
    mcommission_new = mdamagecover = 0;
    iedr_cnt = 0;
    existcnt = 0;
    mcomm_diff = magent_diff = mdeal_diff = 0;
    mservice = 0;

    mcomm_33 = magent_33 = 0;
    mcomm_new = magent_new = 0;
    dMod = 0;
    ihas = 1;

    rtoday(&dwritten);
    $BEGIN WORK;

    if (iins_type_input[0] != ' ' && iins_type_input[0] != '\0' &&
        iins_type_input[0] != '*')
    {
       sprintf(sWhere_ins," AND b.iins_type = '%s' ",iins_type_input);
    }
    else
    {
       strcpy(sWhere_ins," ");
    }

    sprintf(stmt,
    "INSERT INTO ca_comm_balance                                            \
      (iprocess,iroute, irate_type, iroute_comm, ibroker,dpolicy_bgn,dpolicy_end,ipolicy,iins_type,          \
       pcomm,pagent,mdeal,mcomm_diff,magent_diff,mdeal_diff,ientry,dentry,deffect,dprint)  \
     VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");
   $PREPARE ins_bal FROM $stmt;

    /* �j���I�p��mcomm_diff,magent_diff,mdeal_diff�w�g�O�O���֭p�p��A�]��update�̫���B */
    sprintf(stmt,
    "UPDATE ca_comm_balance                                 \
        SET (mcomm_diff,magent_diff,mdeal_diff)             \
          = ( ?, ?, ?) \
      WHERE iprocess  = ?                                   \
        AND ipolicy   = ?                                   \
        AND iins_type = ?  ");
   $PREPARE up_bal1 FROM $stmt;

    /* ���N�I�p��mcomm_diff,magent_diff,mdeal_diff�O�O�����O�p��A�]���O�H�t�Bupdate */
    sprintf(stmt,
    "UPDATE ca_comm_balance                                 \
        SET (mcomm_diff,magent_diff,mdeal_diff)             \
          = (mcomm_diff + ?,magent_diff + ?,mdeal_diff + ?) \
      WHERE iprocess  = ?                                   \
        AND ipolicy   = ?                                   \
        AND iins_type = ?  ");
   $PREPARE up_bal FROM $stmt;

   if( strlen( trim(ibroker)) != 0)  /* ����Jibroker */
   {
    $SELECT fagent
       INTO $fagent
       FROM broker_agent
      WHERE ibroker = $ibroker;
         if (SQLCODE == SQLNOTFOUND)
         {
             sprintf(sErrmsg,"[%s]�g���H[%s]�|������",ibroker,iins_type);
             printf("sErrmsg[%s]\n",sErrmsg);
             goto errexit;
         }
   }

  sprintf(stmt,
   " SELECT pagent*100,pcommiss*100,mservice,ipaid_base  \
       FROM commission_agent                     \
      WHERE iins_cat  = ?                        \
        AND ibroker   = ?                        \
        AND iins_type = ?                        \
	AND iyear     = ? ");
   $PREPARE comid FROM $stmt;

  sprintf(stmt,
   " SELECT pagent*100,pcommiss*100,mservice,ipaid_base   \
       FROM commission_agentc                    \
      WHERE iins_cat  = ?                        \
        AND ibroker   = ?                        \
        AND iins_type = ?                        \
        AND deffect   = ?                        \
	AND iyear     = ?  ");
   $PREPARE comid_deffect FROM $stmt;

   /* Processing  dprint  data */
   if (ckind[0] == '2')
   {
      $CREATE TEMP TABLE grp_data
      (
        ipolicy    char(20) default ' ',
        iendorse   char(20) default ' ',
        dprint     date
      ) WITH NO LOG;
      $CREATE UNIQUE INDEX grp_ix_1 ON grp_data(ipolicy,iendorse);

      $CREATE TEMP TABLE grp_data1
      (
        ipolicy    char(20) default ' ',
        iendorse   char(20) default ' '
      ) WITH NO LOG;
      $CREATE UNIQUE INDEX grp1_ix_1 ON grp_data1(ipolicy,iendorse);

      sprintf(stmt,
      " INSERT INTO grp_data VALUES (?,?,?) ");
      $PREPARE ins_grp_data FROM $stmt;

      $DECLARE sscur CURSOR FOR
        SELECT first 1 branch
          FROM servertbl
         WHERE branch != 'S1'
         ORDER BY branch;
      $OPEN sscur;
      for(;;)
      {
      $FETCH sscur INTO $branch;
       if (SQLCODE == SQLNOTFOUND) break;
       strcpy(sFull,get_full_dbname(branch));

       sprintf(stmt,
        " SELECT distinct TRIM(b.ipolicy1) || b.ipolicy2,b.iendorse,a.dprint, \
                 (SELECT count(*) FROM ao_prem_grp d \
                   WHERE a.icard = d.icard \
                     AND d.dprint < a.dprint)  \
            FROM %s:ao_prem_grp a,%s:ao_prem_rcv b,%s:ao_prem_rcv_detail c    \
           WHERE a.itmp_no = c.irelative         \
             AND a.icard   = b.icard             \
             AND b.ircv    = c.ircv              \
             AND b.iseq    = c.iseq              \
             AND a.dprint BETWEEN ? AND ?        \
             AND a.ibroker = ?                   \
             AND a.drcv_no IS NOT NULL ",sFull,sFull,sFull);
        $PREPARE get_grp FROM $stmt;
        $DECLARE get_grp_cur CURSOR FOR get_grp;
        $OPEN    get_grp_cur USING $dpolicy_bgn,$dpolicy_end,$ibroker;
        for(;;)
        {
        $FETCH get_grp_cur
          INTO $ipolicy,$iendorse,$dprint_tmp, $iCount;
            if (SQLCODE == SQLNOTFOUND) break;

            sIupcompShort[0] = ipolicy[2]; /* �O�渹�ĤT�X */
            sIupcompShort[1] = '\0';
            strcpy( policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
            strcpy( policyDBname, get_full_dbname(policyDB));

            sprintf( stmt, "SELECT a.fcard_class "
                           "  FROM %s:ply_relation a "
                           " WHERE a.ipolicy = '%s' " , policyDBname, ipolicy);
            printf("stmt[%s]\n", stmt);
            $PREPARE prep0 FROM $stmt;
            $EXECUTE prep0 INTO  $fcard_class;

            /* car9804171 �j���I �P�_�O�_���p��ӱj���I�d�������餧�Ȧ���ơA
                          �Y���h��������O���A���N�I���A��*/
            if( fcard_class[0] == '1' && iCount != 0)
                continue;

            $WHENEVER SQLERROR CONTINUE;
            $EXECUTE ins_grp_data
               USING $ipolicy,$iendorse,$dprint_tmp;

            if ((SQLCODE != -239) && (SQLCODE != 0))
            {
               goto errexit;
            }
            $WHENEVER SQLERROR GOTO errexit;
        }
        $CLOSE get_grp_cur;
        $FREE  get_grp_cur;
      }
      $CLOSE sscur;
      $FREE  sscur;

      $INSERT INTO grp_data1
        SELECT a.ipolicy,a.iendorse
          FROM grp_data a
         WHERE a.ipolicy NOT IN (SELECT b.ipolicy
                                   FROM grp_data b
                                  WHERE NVL(b.iendorse,' ') = ' '
                                    AND a.ipolicy = b.ipolicy);
   }

   $DECLARE s_cur CURSOR FOR 
     SELECT branch
       FROM servertbl
      WHERE branch != 'S1'
      ORDER BY branch;
   $OPEN s_cur;
   for(;;)
   {
   $FETCH s_cur INTO $branch;
    if (SQLCODE == SQLNOTFOUND) break;
    strcpy(sFull,get_full_dbname(branch));
printf("did you get all the database?[%s]\n",sFull);
       sprintf(stmt,
      " SELECT pcommission,pagent,mcommission,mdamage_cover, pbusiness, drate_ym, pdiscount, pextra_charge  \
          FROM %s:ply_ins_type     \
         WHERE ipolicy = ?         \
           AND iins_type = ? ",sFull);
      $PREPARE get_new_com FROM $stmt;

       sprintf(stmt,
      " SELECT count(*)                             \
          FROM %s:edr_relation                      \
         WHERE ipolicy = ?                          \
           AND fedr_class = '1'                     \
           AND dedr_close IS NOT NULL ",sFull);
      $PREPARE insedr FROM $stmt;

       sprintf(stmt,
      " SELECT mins_premium,mdiscount     \
          FROM %s:ca_pa_ori               \
         WHERE ipolicy = ? ",sFull);
      $PREPARE ins33id FROM $stmt;
      $DECLARE ins33_cur CURSOR FOR ins33id;

       sprintf(stmt,
      " SELECT medrins_prem,medr_discount   \
          FROM %s:ca_pa_edr                 \
         WHERE iendorse = ? ",sFull);
      $PREPARE ins33id_edr FROM $stmt;
      $DECLARE ins33_edr_cur CURSOR FOR ins33id_edr;

       sprintf(stmt,
      " SELECT b.iins_type,b.mins_premium,b.mdiscount,b.mcommission,b.magent      \
          FROM %s:ori_ins_type b                                                  \
         WHERE ipolicy = ? %s ",sFull,sWhere_ins);

      $PREPARE orins_id FROM $stmt;
      $DECLARE orins_cur CURSOR FOR orins_id;

       sprintf(stmt,
      " DELETE FROM ca_comm_balance   \
         WHERE iprocess    = ?        \
           AND ipolicy     = ?        \
           AND mcomm_diff  = 0        \
           AND magent_diff = 0        \
           AND mdeal_diff  = 0 ");
      $PREPARE del_bal FROM $stmt;

      swhere[0] == '\0';
      /* �B�z�O�� */
      /* 1000311003 �q��2 */
      if (ckind[0] == '1')
      {
         if( strlen( trim( g_iroute)) != 0)  /* ����J�q���N�� */
             sprintf( swhere, " AND c.iroute = '%s'", g_iroute);
         sprintf( stmt,
         " SELECT a.ipolicy,a.fcard_class,a.icar_type,a.qply_period, b.irelative_ply, \
                  a.iofficer, a.ileader, a.iquota, a.icomm_obj, c.iroute, c.iroute_prop, a.irate_type, a.iroute_comm \
             FROM %s:ori_ply_relation a, %s:ply_relation b, %s:original_ply c \
            WHERE a.ipolicy = b.ipolicy \
              AND a.ipolicy = c.ipolicy \
              AND a.dpolicy BETWEEN '%s' AND '%s'     \
              AND a.ibroker = '%s'                    \
              AND a.dply_close IS NOT NULL \
              %s ",sFull,sFull,sFull,dpolicy_bgn,dpolicy_end,ibroker,swhere);
      }
      else if (ckind[0] == '2')
      {
         sprintf(stmt,
         " SELECT DISTINCT a.ipolicy,a.fcard_class,a.icar_type,a.qply_period, c.irelative_ply, \
                  a.iofficer, a.ileader, a.iquota, a.icomm_obj, d.iroute, d.iroute_prop, a.irate_type, a.iroute_comm \
             FROM %s:ori_ply_relation a,grp_data b, %s:ply_relation c, %s:original_ply d \
            WHERE a.ipolicy = b.ipolicy \
              AND a.ipolicy = c.ipolicy \
              AND a.ipolicy = d.ipolicy \
              AND a.dply_close IS NOT NULL ",sFull, sFull, sFull);
      }
      printf("stmt=[%s]\n", stmt);
      $PREPARE main_id FROM $stmt;
      $DECLARE main_cur CURSOR FOR main_id;
      $OPEN    main_cur;
      for(;;)
      {
      $FETCH main_cur
        INTO $ipolicy,$fcard_class,$icar_type,$qply_period,$irelative_ply,
                  $iofficer, $ileader, $iquota, $icomm_obj, $iroute, $iroute_prop, $irate_type, $iroute_comm;
          if (SQLCODE == SQLNOTFOUND) break;

           /* 1000311003 �q��2 */
            /* �~�Z���O�_���� */
            strcpy( opt, "2");
            rc = cm_chk_policy( opt, iofficer, ileader, iquota, icomm_obj, insure_type, iroute, iroute_prop);
            if( rc != M_CM_OK)
            {
                strcpy(stmp, cm_get_errmsg( rc));
                sprintf(sErrmsg,"�O�渹[%s],�~�Z���[%s],���~�T��[%s][%d]\n", ipolicy, iquota, stmp,rc);
                printf("sErrmsg[%s]\n",sErrmsg);
                goto errexit;
            }

            /* �I����H�O�_����O */
            strcpy( opt, "5");
            rc = cm_chk_policy( opt, iofficer, ileader, iquota, icomm_obj, insure_type, iroute, iroute_prop);
            if( rc != M_CM_OK)
            {
                strcpy(stmp, cm_get_errmsg( rc));
                sprintf(sErrmsg,"�O�渹[%s],�I����H[%s],���~�T��[%s][%d]\n", ipolicy, icomm_obj, stmp,rc);
                printf("sErrmsg[%s]\n",sErrmsg);
                goto errexit;
            }

            /* �I����H���L�X���� */
            strcpy( opt, "6");
            rc = cm_chk_policy( opt, iofficer, ileader, iquota, icomm_obj, insure_type, iroute, iroute_prop);
            if( rc != M_CM_OK)
            {
                strcpy(stmp, cm_get_errmsg( rc));
                sprintf(sErrmsg,"�O�渹[%s],�I����H[%s],���~�T��[%s][%d]\n", ipolicy, icomm_obj, stmp,rc);
                printf("sErrmsg[%s]\n",sErrmsg);
                goto errexit;
            }

            strcpy( fstart, "Y");

            rc = get_iins_cat( icar_type, 1, qply_period, iins_cat, iyear, v_sMsg );
            if( rc != M_CM_OK)
            {
                 sprintf(sErrmsg,"�O��[%s]����[%s],�ӫO���[%d],[%s]",ipolicy,icar_type,qply_period,v_sMsg);
                 printf("sErrmsg[%s]\n",sErrmsg);
                 goto errexit;
            }

           $EXECUTE insedr
               INTO $iedr_cnt
              USING $ipolicy;
              if (iedr_cnt > 0) continue;

           ihas = 1;
           strcpy(dprint," ");
           if (ckind[0] == '2')
           {
              sprintf(stmt,
               " SELECT count(*)                  \
                   FROM grp_data                  \
                  WHERE ipolicy = ?               \
                    AND NVL(iendorse,' ') = ' ' ");
               $PREPARE get_grp_cnt FROM $stmt;
               $EXECUTE get_grp_cnt
                   INTO $ihas
                  USING $ipolicy;

              sprintf(stmt,
               " SELECT First 1 dprint            \
                   FROM grp_data                  \
                  WHERE ipolicy = ?               \
                    AND NVL(iendorse,' ') = ' ' ");
               $PREPARE get_dprint FROM $stmt;
               $EXECUTE get_dprint 
                   INTO $dprint 
                  USING $ipolicy;
                     if (SQLCODE == SQLNOTFOUND) 
                     {
                        strcpy(dprint," ");
                     }
           }

           if (ihas > 0)
           {
               $OPEN orins_cur USING $ipolicy;
               for(;;)
               {
               $FETCH orins_cur INTO $iins_type,$mins_premium,$mdiscount,$mcommission,$magent;
               if (SQLCODE == SQLNOTFOUND) break;
               strcpy( iins_type, trim( iins_type));
                 pagent         = 0;
                 pcommission    = 0;
                 mservice       = 0;
                 mcomm_diff = magent_diff = mdeal_diff = 0;
                 mcomm_33 = magent_33 = 0;
                 mcomm_new = magent_new = 0;

                 if (ckind[0] == '1')
                 {
                    /* 1000311003 �q��2 */
                    if( fstart[0] == 'Y')
                    {
                        rc = cm_get_insure_comm(iroute, irate_type, iroute_comm, insure_type, iins_cat, iins_type, iyear, &o_qrec, &o_stcomm, deffect);
                        if (rc != M_CM_OK )
                        {
                            strcpy(stmp, cm_get_errmsg( rc));
                            sprintf(sErrmsg,"�O�渹[%s],�q���N��[%s],�O�v�O[%s],�~�ȱ���[%s],�I��[%s],�~��[%s],�ͮĤ�[%s],���~�T��:[%s][%d]\n", 
                                             ipolicy, iroute, irate_type, iroute_comm, iins_type, iyear, deffect, stmp,rc );
                            printf("sErrmsg[%s]\n",sErrmsg);
                            goto errexit;
                        }
                        else if( o_qrec == 0) 
                        {
                            if (iins_cat[0] == 'C' || iins_cat[0] == 'X' || iins_cat[0] == 'Z')
                            {
                                memset(&o_stcomm, 0x00, sizeof(o_stcomm));
                                o_qrec = 0;
                                strcpy( iins_cat, "C");
                                strcpy( iyear, "0");
                                rc = cm_get_insure_comm(iroute, irate_type, iroute_comm, insure_type, iins_cat, iins_type, iyear, &o_qrec, &o_stcomm, deffect);
                            
                                if (rc != M_CM_OK )
                                {
                                    strcpy(stmp, cm_get_errmsg( rc));
                                    sprintf(sErrmsg,"�O�渹[%s],�q���N��[%s],�O�v�O[%s],�~�ȱ���[%s],�I��[%s],�~��[%s],�ͮĤ�[%s],���~�T��:[%s][%d]\n", 
                                                     ipolicy, iroute, irate_type, iroute_comm, iins_type, iyear, deffect, stmp,rc );
                                    printf("sErrmsg[%s]\n",sErrmsg);
                                    goto errexit;
                                }
                            }
                            if( o_qrec == 0) 
                            {
                                sprintf(sErrmsg,"�O�渹[%s],�q���N��[%s],�O�v�O[%s],�~�ȱ���[%s],�I��[%s],�~��[%s],�ͮĤ�[%s],�����N�z�v�ɸ�Ƨ䤣��\n", 
                                                 ipolicy, iroute, irate_type, iroute_comm, iins_type, iyear, deffect );
                                printf("sErrmsg[%s]\n",sErrmsg);
                                goto errexit;
                            }
                        }
                        pagent = o_stcomm.pagent * 100;
                        pcommission = o_stcomm.pcommiss * 100;
                        mservice = o_stcomm.mservice;
                        strcpy( ipaid_base, o_stcomm.ipaid_base);
                    }
                    else
                    {
                        $EXECUTE comid
                            INTO $pagent,$pcommission,$mservice,$ipaid_base
                           USING $iins_cat,$ibroker,$iins_type,$iyear;

                         if (SQLCODE == SQLNOTFOUND)
                         {
                             sprintf(sErrmsg,"[%s]�g���H[%s]�I�إ�����",ibroker,iins_type);
                             printf("sErrmsg[%s]\n",sErrmsg);
                             goto errexit;
                         }
                     }
                 }
                 else
                 {
                    /* 1000311003 �q��2 */
                    if( fstart[0] == 'Y')
                    {
                        rc = cm_get_insure_comm(iroute, irate_type, iroute_comm, insure_type, iins_cat, iins_type, iyear, &o_qrec, &o_stcomm, deffect);
                        if (rc != M_CM_OK ) 
                        {
                            strcpy(stmp, cm_get_errmsg( rc));
                            sprintf(sErrmsg,"�O�渹[%s],�q���N��[%s],�O�v�O[%s],�~�ȱ���[%s],�I��[%s],�~��[%s],�ͮĤ�[%s],���~�T��:[%s][%d]\n", 
                                             ipolicy, iroute, irate_type, iroute_comm, iins_type, iyear, deffect, stmp,rc );
                            printf("sErrmsg[%s]\n",sErrmsg);
                            goto errexit;
                        }
                        else if( o_qrec == 0)
                        {
                            if (iins_cat[0] == 'C' || iins_cat[0] == 'X' || iins_cat[0] == 'Z')
                            {
                                memset(&o_stcomm, 0x00, sizeof(o_stcomm));
                                o_qrec = 0;
                                strcpy( iins_cat, "C");
                                strcpy( iyear, "0");
                                rc = cm_get_insure_comm(iroute, irate_type, iroute_comm, insure_type, iins_cat, iins_type, iyear, &o_qrec, &o_stcomm, deffect);

                                if (rc != M_CM_OK )
                                {
                                    strcpy(stmp, cm_get_errmsg( rc));
                                    sprintf(sErrmsg,"�O�渹[%s],�q���N��[%s],�O�v�O[%s],�~�ȱ���[%s],�I��[%s],�~��[%s],�ͮĤ�[%s],���~�T��:[%s][%d]\n",
                                                     ipolicy, iroute, irate_type, iroute_comm, iins_type, iyear, deffect, stmp,rc );
                                    printf("sErrmsg[%s]\n",sErrmsg);
                                    goto errexit;
                                }
                            }
                            if( o_qrec == 0)
                            {
                                sprintf(sErrmsg,"�O�渹[%s],�q���N��[%s],�O�v�O[%s],�~�ȱ���[%s],�I��[%s],�~��[%s],�ͮĤ�[%s],�����N�z�v�ɸ�Ƨ䤣��\n",
                                                 ipolicy, iroute, irate_type, iroute_comm, iins_type, iyear, deffect );
                                printf("sErrmsg[%s]\n",sErrmsg);
                                goto errexit;
                            }
                        }

                        pagent = o_stcomm.pagent * 100;
                        pcommission = o_stcomm.pcommiss * 100;
                        mservice = o_stcomm.mservice;
                        strcpy( ipaid_base, o_stcomm.ipaid_base);
                    }
                    else
                    {
                        $EXECUTE comid_deffect
                            INTO $pagent,$pcommission,$mservice,$ipaid_base
                           USING $iins_cat,$ibroker,$iins_type,$deffect,$iyear;
                         if (SQLCODE == SQLNOTFOUND)
                         {
                             /*************************  �Y�䤣��A���ܦ����N�z�v�@�P�A�����վ�
                             sprintf(sErrmsg,"[%s]�g���H[%s]�I�إ�����",ibroker,iins_type);
                             printf("sErrmsg[%s]\n",sErrmsg);
                             goto errexit;
                             **************************/
                             continue;
                         }
                    }
                 }
                 
                 $EXECUTE get_new_com
                     INTO $pcommission_new,$pagent_new,$mcommission_new,$mdamagecover,$pbusiness_new,$drate_ym,
                          $pdiscount_new, $pextra_charge_new
                    USING $ipolicy,$iins_type;
                  if (SQLCODE == SQLNOTFOUND)
                  {
                     continue;
                     sprintf(sErrmsg,"[%s]�̷s�O��[%s]�I�ؤ��s�b",ipolicy,iins_type);
                     printf("sErrmsg[%s]\n",sErrmsg);
                     goto errexit;
                  }

                  /*  �����O�T��w���^�����B�N�z�O���A�ߤ@�������B�N�z�O */
                  if (strcmp(iins_type,"51") == 0)
                  {
                     $SELECT count(*)
                        INTO $ext_cnt
                        FROM ext_policy
                       WHERE ipolicy = $ipolicy;
                          if (ext_cnt != 0)
                          {
                             if (pagent_new == 0)
                             {
                                printf("INTO continue ipolicy[%s]\n",ipolicy);
                                continue;
                             }
                          }
                  }
printf("mdamagecover[%d];;mcommission_new[%d];;mservice[%d]\n",mdamagecover,mcommission_new,mservice);
                  if (fcard_class[0] == '1')
                  {
                      if ((mdamagecover == 0) || (mcommission_new == mservice))
                      {
                           continue;
                      }

                      $SELECT COUNT(*)
                         INTO $iCount
                         FROM ca_ext_compulsory
                        WHERE ipolicy = $ipolicy;

                      /* car9804171 �P�_�Y�����O�T�j��O���ɦ���ơA���ܬ�6510�����O�T�A�h���վ����O */
                      if( iCount != 0) 
                          continue;

                      /* car9803311���q���ץ��N�I�Y�O�¶O�v,�ӱj���I�H�¤���O��I,����� */
                      if( strlen(trim( irelative_ply)) !=0 &&
                          (strncmp( trim(ibroker), "JH",2) == 0 ||
                           strncmp( trim(ibroker), "BD",2) == 0 )
                        )
                      {
                          sprintf( stmt, "SELECT max(drate_ym)"
                                         "  FROM %s:ori_ins_type"
                                         " WHERE ipolicy = ?", sFull);

                          $PREPARE prep1 FROM $stmt;
                          $EXECUTE prep1 INTO $drate_ym_rel USING $irelative_ply;

                          if (risnull(SQLCHAR, drate_ym_rel) != 1) /* �����N�I�O�v�N�� */
                          {
                              $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
                                 INTO $f980401
                                 FROM ca_rate_date
                                WHERE icode  = $drate_ym_rel
                                 AND itable = 'cm_extra_charge';
 
                              if (SQLCODE == SQLNOTFOUND)
                              {
                                 sprintf(sErrmsg,"�O�v�N��[%s],���[�O�βv�O�v�ͮĤ�䤣��,�Ь��ӫO����car120�]�w", drate_ym);
                                 printf("sErrmsg[%s]\n",sErrmsg);
                                 goto errexit;
                              }
                              /* ���N�I���¶O�v,����� */
                              if( f980401[0] == '0')
                                  continue;
                          }
                      }
                  }
                  else
                  {
                      if ((pcommission_new == pcommission) && (pagent_new == pagent))
                      {
                           continue;
                      }

                      $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
                         INTO $f980401
                         FROM ca_rate_date
                        WHERE icode  = $drate_ym
                          AND itable = 'cm_extra_charge';

                      if (SQLCODE == SQLNOTFOUND)
                      {
                         sprintf(sErrmsg,"�O�v�N��[%s],���[�O�βv�O�v�ͮĤ�䤣��,�Ь��ӫO����car120�]�w", drate_ym);
                         printf("sErrmsg[%s]\n",sErrmsg);
                         goto errexit;
                      }

                      /* �O�v�ۥѤƤ��� */
                      if( f980401[0] == '1')
                      {
                          printf("�̷s�O��pdiscount_new[%f]\n", pdiscount_new);
                          if( pdiscount_new != 0) /* �O�v�ۥѤƤ��ᤣ�i������ */
                          {
                             sprintf(sErrmsg,"�O�渹[%s],�O�v�ۥѤƤ��ᤣ�i������", ipolicy);
                             printf("sErrmsg[%s]\n",sErrmsg);
                             goto errexit;
                          }

                          sprintf( sCCC1 ,"%f", (double)(pdiscount_new + pcommission + pagent));
                          sprintf( sCCC2 ,"%f", (double)( (pextra_charge_new - pbusiness_new) * 100.0));
              
                          rCCC1 = atof( sCCC1);
                          rCCC2 = atof( sCCC2);
              
                          printf("��+�N+�u[%-3.20f]\n", rCCC1);
                          printf("��-�~   [%-3.20f]\n", rCCC2);
                            
                          if ( rCCC1 > rCCC2 )
                          {
                             sprintf(sErrmsg,"�O�渹[%s],(�����v+�~�޶O�βv) ���i�j�� ���[�O�βv,�Ь��ӫO��", ipolicy);
                             printf("sErrmsg[%s]\n",sErrmsg);
                             goto errexit;
                          }
                      }

                  }
      
                  if (fcard_class[0] == '1')
                  {
                      mdeal_diff = mservice - mcommission;
                  }
                  else
                  {
                      if (strcmp(iins_type,"33") == 0)
                      {
                           printf("INTO iins_type = '33' \n");
                          $OPEN ins33_cur USING $ipolicy;
                          for(;;)
                          {
                          $FETCH ins33_cur
                            INTO $mins_premium,$mdiscount;
                              if (SQLCODE == SQLNOTFOUND) break;

                              if (ipaid_base[0] == 'B')
                              {
                                  mcomm_33   = (long)((float)(mins_premium+mdiscount)*pcommission/100.0+0.5);
                                  magent_33  = (long)((float)(mins_premium+mdiscount)*pagent/100.0+0.5);
                              }
                              else
                              {
                                  mcomm_33   = (long)((float)mins_premium*pcommission/100.0+0.5);
                                  magent_33  = (long)((float)mins_premium*pagent/100.0+0.5);
                              }
                              mcomm_new  += mcomm_33;
                              magent_new += magent_33;
                          }
                          $CLOSE ins33_cur;
                      }
                      else
                      {
                          printf("NOT INTO iins_type = '33' \n");
                          if (ipaid_base[0] == 'B')
                          {
                              mcomm_new   = (long)((float)(mins_premium+mdiscount)*pcommission/100.0+0.5);
                              magent_new  = (long)((float)(mins_premium+mdiscount)*pagent/100.0+0.5);
                          }
                          else
                          {
                              mcomm_new   = (long)((float)mins_premium*pcommission/100.0+0.5);
                              magent_new  = (long)((float)mins_premium*pagent/100.0+0.5);
                          }
                      }
                      mcomm_diff  = mcomm_new  - mcommission;
                      magent_diff = magent_new - magent;
                  }

/*                  printf("mcomm_new[%ld],magent_new[%ld],mcommission[%ld],magent[%ld]\n",
                          mcomm_new,magent_new,mcommission,magent);
                  printf("mcomm_diff[%ld],magent_diff[%ld],mdeal_diff[%ld]\n",
                          mcomm_diff,magent_diff,mdeal_diff);*/
                  if ((mcomm_diff  != 0) || (magent_diff != 0) || (mdeal_diff  != 0))
                  {
                      $EXECUTE ins_bal
                         USING $processid, $iroute, $irate_type, $iroute_comm, $ibroker,$dpolicy_bgn,$dpolicy_end,$ipolicy,$iins_type,
                               $pcommission,$pagent,$mservice,$mcomm_diff,$magent_diff,$mdeal_diff,
                               $userid,$dwritten,$deffect,$dprint;
                  }
               }
               $CLOSE orins_cur;
           }

           /*  �B�z���  */
           if ((ckind[0] == '1') || ((ckind[0] == '2') && (ihas > 0)))
           {
               sprintf(stmt,
              " SELECT a.iendorse,b.iins_type,b.medrins_prem,b.medr_discount,            \
                       b.medr_commission,b.medr_agent,a.icar_type,c.qply_period,         \
                       a.iofficer, a.ileader, a.iquota, a.icomm_obj, c.iroute, a.irate_type, a.iroute_comm \
                  FROM %s:edr_relation a,%s:edr_ins_type b,%s:endorsement c              \
                 WHERE a.iendorse = b.iendorse                                           \
		   AND a.iendorse = c.iendorse                                           \
                   AND a.dedr_close IS NOT NULL                                          \
                   AND ((b.medr_commission != 0) OR (b.medr_agent != 0))                 \
                   AND a.ipolicy = ? %s ",sFull,sFull,sFull,sWhere_ins);
           }
           else if (ckind[0] == '2')
           {
              sprintf(stmt,
              " SELECT DISTINCT b.iins_type                \
                  FROM grp_data1 a,%s:edr_ins_type b       \
                 WHERE a.iendorse  = b.iendorse            \
                   AND b.iedr_type = '05'                  \
                   AND a.ipolicy   = ?                     \
                  INTO TEMP edr_tmp WITH NO LOG ",sFull);
              $PREPARE get_ed_in FROM $stmt;
              $EXECUTE get_ed_in USING $ipolicy;

               sprintf(stmt,
              " SELECT a.iendorse,b.iins_type,b.medrins_prem,b.medr_discount,            \
                       b.medr_commission,b.medr_agent,a.icar_type,d.qply_period,         \
                       a.iofficer, a.ileader, a.iquota, a.icomm_obj, d.iroute, a.irate_type, a.iroute_comm \
                  FROM %s:edr_relation a,%s:edr_ins_type b, edr_tmp c, %s:endorsement d    \
                 WHERE a.iendorse = b.iendorse                                           \
		   AND a.iendorse = d.iendorse                                           \
                   AND a.dedr_close IS NOT NULL                                          \
                   AND ((b.medr_commission != 0) OR (b.medr_agent != 0))                 \
                   AND b.iins_type = c.iins_type                                         \
                   AND a.ipolicy = ? %s ",sFull,sFull,sFull,sWhere_ins);
           }
           printf("stmt=[%s]\n", stmt);
              $PREPARE main_id_edr FROM $stmt;
              $DECLARE main_cur_edr CURSOR FOR main_id_edr;

           $OPEN  main_cur_edr USING $ipolicy;
           for(;;)
           {
           $FETCH main_cur_edr
             INTO $iendorse,$iins_type,$mins_premium,$mdiscount,
                  $mcommission,$magent,$icar_type,$qply_period,$iofficer, $ileader, $iquota, $icomm_obj, $iroute,
                  $irate_type, $iroute_comm;
               if (SQLCODE == SQLNOTFOUND) break;

               rc = get_iins_cat( icar_type, 1, qply_period, iins_cat, iyear, v_sMsg );
               if( rc != M_CM_OK)
               {
                    sprintf(sErrmsg,"�O��[%s]����[%s],�ӫO���[%d],[%s]",ipolicy,icar_type,qply_period,v_sMsg);
                    printf("sErrmsg[%s]\n",sErrmsg);
                    goto errexit;
               }

               pagent         = 0;
               pcommission    = 0;
               mservice       = 0;
               mcomm_diff = magent_diff = 0;

               mcomm_33 = magent_33 = 0;
               mcomm_new = magent_new = 0;

               /* 1000311003 �q��2 */
               /* �~�Z���O�_���� */
               strcpy( opt, "2");
               rc = cm_chk_policy( opt, iofficer, ileader, iquota, icomm_obj, insure_type, iroute, iroute_prop);
               if( rc != M_CM_OK)
               {
                   strcpy(stmp, cm_get_errmsg( rc));
                   sprintf(sErrmsg,"�O�渹[%s],��渹[%s],�~�Z���[%s],���~�T��[%s][%d]\n", ipolicy, iendorse, iquota, stmp, rc);
                   printf("sErrmsg[%s]\n",sErrmsg);
                   goto errexit;
               }

               /* �I����H�O�_����O */
               strcpy( opt, "5");
               rc = cm_chk_policy( opt, iofficer, ileader, iquota, icomm_obj, insure_type, iroute, iroute_prop);
               if( rc != M_CM_OK)
               {
                   strcpy(stmp, cm_get_errmsg( rc));
                   sprintf(sErrmsg,"�O�渹[%s],��渹[%s],�I����H[%s],���~�T��[%s][%d]\n", ipolicy, iendorse, icomm_obj, stmp, rc);
                   printf("sErrmsg[%s]\n",sErrmsg);
                   goto errexit;
               }

               /* �I����H���L�X���� */
               strcpy( opt, "6");
               rc = cm_chk_policy( opt, iofficer, ileader, iquota, icomm_obj, insure_type, iroute, iroute_prop);
               if( rc != M_CM_OK)
                {
                   strcpy(stmp, cm_get_errmsg( rc));
                    sprintf(sErrmsg,"�O�渹[%s],��渹[%s],�I����H[%s],���~�T��[%s][%d]\n", ipolicy, iendorse, icomm_obj, stmp, rc);
                    printf("sErrmsg[%s]\n",sErrmsg);
                    goto errexit;
                }

               strcpy( fstart, "Y");

               if (ckind[0] == '1')
               {
                    /* 1000311003 �q��2 */
                    if( fstart[0] == 'Y')
                    {
                        rc = cm_get_insure_comm(iroute, irate_type, iroute_comm, insure_type, iins_cat, iins_type, iyear, &o_qrec, &o_stcomm, deffect);
                        if (rc != M_CM_OK )
                        {
                            strcpy(stmp, cm_get_errmsg( rc));
                            sprintf(sErrmsg,"�O�渹[%s],��渹[%s],�q���N��[%s],�O�v�O[%s],�~�ȱ���[%s],�I��[%s],�~��[%s],�ͮĤ�[%s],���~�T��:[%s][%d]\n", 
                                             ipolicy, iendorse, iroute, irate_type, iroute_comm, iins_type, iyear, deffect, stmp, rc );
                            printf("sErrmsg[%s]\n",sErrmsg);
                            goto errexit;
                        }
                        else if( o_qrec == 0)
                        {
                            if (iins_cat[0] == 'C' || iins_cat[0] == 'X' || iins_cat[0] == 'Z')
                            {
                                memset(&o_stcomm, 0x00, sizeof(o_stcomm));
                                o_qrec = 0;
                                strcpy( iins_cat, "C");
                                strcpy( iyear, "0");
                                rc = cm_get_insure_comm(iroute, irate_type, iroute_comm, insure_type, iins_cat, iins_type, iyear, &o_qrec, &o_stcomm, deffect);

                                if (rc != M_CM_OK )
                                {
                                    strcpy(stmp, cm_get_errmsg( rc));
                                    sprintf(sErrmsg,"�O�渹[%s],�q���N��[%s],�O�v�O[%s],�~�ȱ���[%s],�I��[%s],�~��[%s],�ͮĤ�[%s],���~�T��:[%s][%d]\n",
                                                     ipolicy, iroute, irate_type, iroute_comm, iins_type, iyear, deffect, stmp,rc );
                                    printf("sErrmsg[%s]\n",sErrmsg);
                                    goto errexit;
                                }
                            }
                            if( o_qrec == 0)
                            {
                                sprintf(sErrmsg,"�O�渹[%s],�q���N��[%s],�O�v�O[%s],�~�ȱ���[%s],�I��[%s],�~��[%s],�ͮĤ�[%s],�����N�z�v�ɸ�Ƨ䤣��\n",
                                                 ipolicy, iroute, irate_type, iroute_comm, iins_type, iyear, deffect );
                                printf("sErrmsg[%s]\n",sErrmsg);
                                goto errexit;
                            }
                        }

                        pagent = o_stcomm.pagent * 100;
                        pcommission = o_stcomm.pcommiss * 100;
                        mservice = o_stcomm.mservice;
                        strcpy( ipaid_base, o_stcomm.ipaid_base);
                   }
                   else
                   {
                       $EXECUTE comid
                           INTO $pagent,$pcommission,$mservice,$ipaid_base
                          USING $iins_cat,$ibroker,$iins_type,$iyear;

                          if (SQLCODE == SQLNOTFOUND) 
                          {
                              sprintf(sErrmsg,"[%s]�g���H[%s]�I�إ�����",ibroker,iins_type);
                              printf("sErrmsg[%s]\n",sErrmsg);
                              goto errexit;
                          }
                   }
                   strcpy(dprint," ");
               }
               else
               {
                    /* 1000311003 �q��2 */
                    if( fstart[0] == 'Y')
                    {
                        rc = cm_get_insure_comm(iroute, irate_type, iroute_comm, insure_type, iins_cat, iins_type, iyear, &o_qrec, &o_stcomm, deffect);
                        if (rc != M_CM_OK )
                        {
                            strcpy(stmp, cm_get_errmsg( rc));
                            sprintf(sErrmsg,"�O�渹[%s],��渹[%s],�q���N��[%s],�O�v�O[%s],�~�ȱ���[%s],�I��[%s],�~��[%s],�ͮĤ�[%s],���~�T��:[%s][%d]\n", 
                                             ipolicy, iendorse, iroute, irate_type, iroute_comm, iins_type, iyear, deffect, stmp, rc );
                            printf("sErrmsg[%s]\n",sErrmsg);
                            goto errexit;
                        }
                        else if( o_qrec == 0)
                        {
                            if (iins_cat[0] == 'C' || iins_cat[0] == 'X' || iins_cat[0] == 'Z')
                            {
                                memset(&o_stcomm, 0x00, sizeof(o_stcomm));
                                o_qrec = 0;
                                strcpy( iins_cat, "C");
                                strcpy( iyear, "0");
                                rc = cm_get_insure_comm(iroute, irate_type, iroute_comm, insure_type, iins_cat, iins_type, iyear, &o_qrec, &o_stcomm, deffect);

                                if (rc != M_CM_OK )
                                {
                                    strcpy(stmp, cm_get_errmsg( rc));
                                    sprintf(sErrmsg,"�O�渹[%s],�q���N��[%s],�O�v�O[%s],�~�ȱ���[%s],�I��[%s],�~��[%s],�ͮĤ�[%s],���~�T��:[%s][%d]\n",
                                                     ipolicy, iroute, irate_type, iroute_comm, iins_type, iyear, deffect, stmp,rc );
                                    printf("sErrmsg[%s]\n",sErrmsg);
                                    goto errexit;
                                }
                            }
                            if( o_qrec == 0)
                            {
                                sprintf(sErrmsg,"�O�渹[%s],�q���N��[%s],�O�v�O[%s],�~�ȱ���[%s],�I��[%s],�~��[%s],�ͮĤ�[%s],�����N�z�v�ɸ�Ƨ䤣��\n",
                                                 ipolicy, iroute, irate_type, iroute_comm, iins_type, iyear, deffect );
                                printf("sErrmsg[%s]\n",sErrmsg);
                                goto errexit;
                            }
                        }

                        pagent = o_stcomm.pagent * 100;
                        pcommission = o_stcomm.pcommiss * 100;
                        mservice = o_stcomm.mservice;
                        strcpy( ipaid_base, o_stcomm.ipaid_base);
                   }
                   else
                   {
                        $EXECUTE comid_deffect
                        INTO $pagent,$pcommission,$mservice,$ipaid_base
                       USING $iins_cat,$ibroker,$iins_type,$deffect,$iyear;                      
                      
                     if (SQLCODE == SQLNOTFOUND)
                     {
                         /**********************************************
                         sprintf(sErrmsg,"[%s]�g���H[%s]�I�إ�����",ibroker,iins_type);
                         printf("sErrmsg[%s]\n",sErrmsg);
                         goto errexit;
                         ***********************************************/
                         continue;
                     }
                   }
                   sprintf(stmt,
                          " SELECT First 1 dprint,decode(TRIM(iendorse),'%s',0,1) flag   \
                              FROM grp_data       \
                             WHERE ipolicy = ?    \
                             ORDER BY 2 ",rtrim(iendorse));
                   $PREPARE get_dprint2 FROM $stmt; 
                   $EXECUTE get_dprint2 
                       INTO $dprint ,$flag_tmp
                      USING $ipolicy;               
                         if (SQLCODE == SQLNOTFOUND)
                         {
                            strcpy(dprint," ");
                         }
               }
               $EXECUTE get_new_com
                   INTO $pcommission_new,$pagent_new,$mcommission_new,$mdamagecover,$pbusiness_new,$drate_ym,
                          $pdiscount_new, $pextra_charge_new
                  USING $ipolicy,$iins_type;
                  if (SQLCODE == SQLNOTFOUND)
                  {
                      continue;
                      sprintf(sErrmsg,"[%s]�̷s�O��[%s]�I�ؤ��s�b",ipolicy,iins_type);
                      printf("sErrmsg[%s]\n",sErrmsg);
                      goto errexit;
                  }
                  if (strcmp(iins_type,"51") == 0)
                  {
                     $SELECT count(*)
                        INTO $ext_cnt
                        FROM ext_policy
                       WHERE ipolicy = $ipolicy;
                          if (ext_cnt != 0)
                          {
                             if (pagent_new == 0)
                             {
                                printf("INTO continue ipolicy[%s]\n",ipolicy);
                                continue;
                             }
                          }
                  }
               if (fcard_class[0] == '1')
               {
                   if ((mdamagecover == 0) || (mcommission_new == mservice))
                   {
                        continue;
                   }

                   $SELECT COUNT(*)
                      INTO $iCount
                      FROM ca_ext_compulsory
                     WHERE ipolicy = $ipolicy;

                   /* car9804171 �P�_�Y�����O�T�j��O���ɦ���ơA���ܬ�6510�����O�T�A�h���վ����O */
                   if( iCount != 0) 
                       continue;

                   /* car9803311���q���ץ��N�I�Y�O�¶O�v,�ӱj���I�H�¤���O��I,����� */
                   if( strlen(trim( irelative_ply)) !=0 &&
                       (strncmp( trim(ibroker), "JH",2) == 0 ||
                        strncmp( trim(ibroker), "BD",2) == 0 )
                     )
                   {
                       sprintf( stmt, "SELECT max(drate_ym)"
                                      "  FROM %s:ply_ins_type"
                                      " WHERE ipolicy = ?", sFull);

                       $PREPARE prep2 FROM $stmt;
                       $EXECUTE prep2 INTO $drate_ym_rel USING $irelative_ply;

                       if (risnull(SQLCHAR, drate_ym_rel) != 1) /* �����N�I�O�v�N�� */
                       {
                           $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
                              INTO $f980401
                              FROM ca_rate_date
                             WHERE icode  = $drate_ym_rel
                              AND itable = 'cm_extra_charge';

                           if (SQLCODE == SQLNOTFOUND)
                           {
                              sprintf(sErrmsg,"�O�v�N��[%s],���[�O�βv�O�v�ͮĤ�䤣��,�Ь��ӫO����car120�]�w", drate_ym);
                              printf("sErrmsg[%s]\n",sErrmsg);
                              goto errexit;
                           }
                           /* ���N�I���¶O�v,����� */
                           if( f980401[0] == '0')
                               continue;
                       }
                   }
               }
               else
               {
                   if ((pcommission_new == pcommission) && (pagent_new == pagent))
                   {
                        continue;
                   }

                   $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
                      INTO $f980401
                      FROM ca_rate_date
                     WHERE icode  = $drate_ym
                                    AND itable = 'cm_extra_charge';

                   if (SQLCODE == SQLNOTFOUND)
                   {
                      sprintf(sErrmsg,"�O�v�N��[%s],���[�O�βv�O�v�ͮĤ�䤣��,�Ь��ӫO����car120�]�w", drate_ym);
                      printf("sErrmsg[%s]\n",sErrmsg);
                      goto errexit;
                   }

                   /* �O�v�ۥѤƤ��� */
                   if( f980401[0] == '1')
                   {
                       printf("�̷s�O��pdiscount_new[%f]\n", pdiscount_new);
                       if( pdiscount_new != 0) /* �O�v�ۥѤƤ��ᤣ�i������ */
                       {
                          sprintf(sErrmsg,"�O�渹[%s],�O�v�ۥѤƤ��ᤣ�i������", ipolicy);
                          printf("sErrmsg[%s]\n",sErrmsg);
                          goto errexit;
                       }

                       sprintf( sCCC1 ,"%f", (double)(pdiscount_new + pcommission + pagent));
                       sprintf( sCCC2 ,"%f", (double)( (pextra_charge_new - pbusiness_new) * 100.0));

                       rCCC1 = atof( sCCC1);
                       rCCC2 = atof( sCCC2);

                       printf("��+�N+�u[%-3.20f]\n", rCCC1);
                       printf("��-�~   [%-3.20f]\n", rCCC2);

                       if ( rCCC1 > rCCC2 )
                       {
                          sprintf(sErrmsg,"�O�渹[%s],(�����v+�~�޶O�βv) ���i�j�� ���[�O�βv,�Ь��ӫO��", ipolicy);
                          printf("sErrmsg[%s]\n",sErrmsg);
                          goto errexit;
                       }
                   }
               }
               if (fcard_class[0] == '1')
               {
/*printf("mservice[%ld],mins_premium[%ld]\n",mservice,mins_premium);*/
                   /*
                   if ((mins_premium < 0) || (mcommission < 0))
                       mservice *= -1;
                   */

                   mdeal_diff = mdeal_diff - mcommission;
/*printf("mdeal_diff[%ld],iendorse[%s],mcommission[%ld]\n",mdeal_diff,iendorse,mcommission);*/
               }
               else
               {
                   if (strcmp(iins_type,"33") == 0)
                   {
                       $OPEN ins33_edr_cur USING $iendorse;
                       for(;;)
                       {
                       $FETCH ins33_edr_cur
                         INTO $mins_premium,$mdiscount;
                           if (SQLCODE == SQLNOTFOUND) break;

                           if (mins_premium < 0)
                               dMod = -0.5;
                           else
                               dMod = 0.5;
    
                           if (ipaid_base[0] == 'B')
                           {
                               mcomm_33   = (long)((float)(mins_premium+mdiscount)*pcommission/100.0+dMod);
                               magent_33  = (long)((float)(mins_premium+mdiscount)*pagent/100.0+dMod);
                           }
                           else
                           {
                               mcomm_33   = (long)((float)mins_premium*pcommission/100.0+dMod);
                               magent_33  = (long)((float)mins_premium*pagent/100.0+dMod);
                           }
                           mcomm_new  += mcomm_33;                    
                           magent_new += magent_33;
                       }
                       $CLOSE ins33_edr_cur;
                   }
                   else
                   {
                       if (mins_premium < 0)
                           dMod = -0.5;
                       else
                           dMod = 0.5;

                       if (ipaid_base[0] == 'B')
                       {
                           mcomm_new   = (long)((float)(mins_premium+mdiscount)*pcommission/100.0+dMod);
                           magent_new  = (long)((float)(mins_premium+mdiscount)*pagent/100.0+dMod);
                       }
                       else
                       {
                           mcomm_new   = (long)((float)mins_premium*pcommission/100.0+dMod);
                           magent_new  = (long)((float)mins_premium*pagent/100.0+dMod);
                       }
                   }
                   mcomm_diff  = mcomm_new  - mcommission;
                   magent_diff = magent_new - magent; 
               }

               if ((mcomm_diff  != 0) || (magent_diff != 0) || (mdeal_diff  != 0))
               {
                   if (fcard_class[0] == '1')
                   {
                       $EXECUTE up_bal1
                          USING $mcomm_diff,$magent_diff,$mdeal_diff,$processid,$ipolicy,$iins_type;
                          if (sqlca.sqlerrd[2] == 0)
                          {
                              $EXECUTE ins_bal
                                 USING $processid, $iroute, $irate_type, $iroute_comm,$ibroker,$dpolicy_bgn,$dpolicy_end,$ipolicy,$iins_type,
                                       $pcommission,$pagent,$mservice,$mcomm_diff,$magent_diff,$mdeal_diff,
                                       $userid,$dwritten,$deffect,$dprint;
                          }
                   }
                   else
                   {
                       $EXECUTE up_bal
                          USING $mcomm_diff,$magent_diff,$mdeal_diff,$processid,$ipolicy,$iins_type;
                          if (sqlca.sqlerrd[2] == 0)
                          {
                              $EXECUTE ins_bal 
                                 USING $processid, $iroute, $irate_type, $iroute_comm,$ibroker,$dpolicy_bgn,$dpolicy_end,$ipolicy,$iins_type,
                                       $pcommission,$pagent,$mservice,$mcomm_diff,$magent_diff,$mdeal_diff,
                                       $userid,$dwritten,$deffect,$dprint;
                          }
                   }
               }
           }
           $CLOSE   main_cur_edr;

           $EXECUTE del_bal 
              USING $processid,$ipolicy;

           if ((ckind[0] == '2') && (ihas == 0))
           {
               $DROP TABLE edr_tmp;
           }
      }
      $CLOSE main_cur;
      $FREE  main_cur;
   }
   $CLOSE s_cur;
   $FREE  s_cur;
   $COMMIT WORK;
   return M_CM_OK;

errexit:
   printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
   sqltmp = SQLCODE;
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   printf("ROLLBACK OK \n");
   if (sErrmsg[0] == ' ') strcpy(sErrmsg,sqlca.sqlerrm);
   EWRITE(userid, sqltmp, sErrmsg);
   exit(1);
}

char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}
