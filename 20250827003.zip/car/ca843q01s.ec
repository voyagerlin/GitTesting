/************************************************/
/*   PROGRAM : ca843q01s.ec                     */
/*   MODIFY  : cyrus                            */
/*   DATE    : 104.12.15                        */
/*   NOTE    : �q���I�ؽߴک��Ӫ�               */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
$include datetime.h;
#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"


$char DBName[05], iForm_Tp[03], outputf[N_FILE+1];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
$char  userid[11];

char  msgbuf[100];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width;
$int  PERIOD;

static int  max_count;

DBinfo  *list;
int     count_db;

$char sIbranch[BRANCH_ID], sIofficer[EMPLOYEE_ID];
$char sNname[EMPLOYEE_NAME];
$char sIclaim[CLAIM_NUM], sFcard_class[2], sDclaim[YYYYMMDD];
$char sYearMonth[7];
$char sIadjuster[EMPLOYEE_ID], sFclose[2], sIins_type[INSURANCE_TYPE];
$char sDclose[13], victim[11], flast[2];
$char sDgroup[11];
$char dgroup[11];
$long ldgroup;
$char sNgroup[5],sNadjuster[11];
$char sIupbranch[3], sNupgroup[11];
$char sFins_grp[2];
$char sBgnDate_e[11], sEndDate_e[11], sBgnDate[11], sEndDate[11];
$char sIroute[21];
$long lBgnDate, lEndDate;
$long iQorder, i, qmonth, lMins_stl;
$char ivictim[11];
$long qdmg_claim, qdmg_close, qdmg_nopay;       /** ���l **/
$long qlia_claim, qlia_close, qlia_nopay;       /** �d�� **/
$long qburg_claim, qburg_close, qburg_nopay;    /** �W�[�ѵs�����Ѩ��l�������X **/
$long qcomp_claim, qcomp_close, qcomp_nopay;    /** �j�� **/
$long qwea_claim, qwea_close, qwea_nopay;       /** �]�� **/
$long mins_stl;
$date lDclaim;
$char iclaim[21];
$int  iclose_type;
$int  icnt;
$char stmt[2000];
$char stmt3[9500];
$char sIinsType[INSURANCE_TYPE];
$char sIinsTypeB[INSURANCE_TYPE];

$char iins_item[INSURANCE_TYPE];

int qlia, qburg, qdmg, qwea;
$int iTmp;
$int iMaxCnt;
$int id1;
$int iMonthDiff;

$char m_bgn[11], m_end[11], r_bgn[11], r_end[11];
$char server[3];
$char iofficer[11];

long car843_build();
void car843_title();
long car843_body();
long car843_print();
void car843_print2();
int DiffMonth();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
   int rc;
   
   batchinit();
   strcpy(DBName   ,  isNULLstr(argv[1]));
   strcpy(userid   ,  isNULLstr(argv[2]));
   strcpy(sBgnDate ,  isNULLstr(argv[3]));
   strcpy(sEndDate ,  isNULLstr(argv[4]));

   strcpy(sIroute  ,  isNULLstr(argv[5]));

   strcpy(outputf  ,  isNULLstr(argv[6]));

   strcpy(sBgnDate_e, cm_to_infdate(sBgnDate));
   strcpy(sEndDate_e, cm_to_infdate(sEndDate));

   rstrdate(sBgnDate_e, &lBgnDate);
   rstrdate(sEndDate_e, &lEndDate);

   printf("sBgnDate_e[%s] sEndDate_e[%s]\n",sBgnDate_e , sEndDate_e);

   printf("sIroute[%s]\n", sIroute);
 
   rc=car843_get_db();
   if (rc!=M_CM_OK)
      return rc;
   
   rc = car843_build();
   if (rc != M_CM_OK)
       return rc;

   return M_CM_OK;
   
errexit:
   printf("main :SQLCODE[%d], errstr:[%s]\n",SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/

long car843_build()
{
   $char  TitleFmt[N_FILE+1],BodyFmt[N_FILE+1];
   int    rc;
   
   $WHENEVER SQLERROR GOTO errexit;
   $SET LOCK MODE TO WAIT;
   
   if (db_select(DBName) == False)
   {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   rc = car843_body();
   if (rc != M_CM_OK)
       return rc;
           
   rc = car843_print();
   if (rc != M_CM_OK)
       return rc;
 
   return M_CM_OK;

errexit:
   EWRITE(userid,rc,sqlca.sqlerrm);
   return SQLCODE;  
}

long car843_get_db()
{
   $whenever sqlerror goto errexit;

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

long car843_body()
{
    int i;
    long rc;
    $char sStmt[9500],sStmt1[9500],sStmt2[9500],sStmt3[9500],sStmt4[9500];
    $char stmt[9500];
    $char tmp[4096], tmp1[4096], tmp2[4096];
    $char stepcar[4096];
    $char iapp_unit[3];
    $char falldb[2];
    $char k;

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    $create temp table tag_data
     (
        itag   char(12)

     )with no log;
    printf("1111111111111111111");
    for(k=0;k<count_db;k++)
    {
       sprintf_s(stmt, 9500 ,
        " insert into tag_data              \
           select unique b.itag             \
             from %s:ply_relation a, %s:policy b   \
            where a.ipolicy  =  b.ipolicy          \
              and a.dply_end between ? and ?       \
              and a.dply_close is not null         \
              and b.iroute  matches ? ", list[k].dbname, list[k].dbname);
    
        $prepare idstmt1 from $stmt;
        $execute idstmt1 using $lBgnDate, $lEndDate, $sIroute;
    }
    printf("2222222222");
    sprintf_s(stmt, 9500 ,
    " select unique itag from tag_data into temp tag_data1 with no log ");
   
    $prepare idstmt2 from $stmt;
    $execute idstmt2;

    $create unique index tag_data_ix1 on tag_data1(itag);

    $create temp table car843tbl
     (
        itag            char(12),
        iacc_year       int,
        iins_type       char(7),
        nins_type       char(30),
        ndmglia         char(10),
        mdamage_cover   int,
        mstl            int
     )with no log;

printf("3333333333333");
    for(k=0;k<count_db;k++)
    {
       sprintf_s(stmt, 9500,
        " insert into car843tbl      \
          select c.itag, year(a.dply_begin) as iyear, d.iins_type,    \
                 e.nins_type, decode(e.fins_grp,'1','���l','2','���d','') as fins_grp,   \
                 d.mdamage_cover,    \
                 0 as mins_stl       \
            from %s:ply_relation a, %s:policy b, tag_data1 c, %s:ply_ins_type d, insurance_type e   \
           where a.ipolicy     =  b.ipolicy         \
             and b.itag        =  c.itag            \
             and a.ipolicy     =  d.ipolicy         \
             and d.iins_type   =  e.iins_type       \
             and a.dply_close  is not null          \
             and a.fcard_class = '2'   ", list[k].dbname, list[k].dbname, list[k].dbname);

        $prepare idstmt3 from $stmt;
        $execute idstmt3;

       sprintf_s(stmt, 9500 ,
        " insert into car843tbl     \
          select a.itag,            \
                 year(a.daccident) as daccident,    \
                 e.iins_ply as iins_type,           \
                 (select nins_type from insurance_type where iins_type = e.iins_ply) as nins_type,   \
                 decode(e.fins_grp,'1','���l','2','���d','') as fins_grp,    \
                 0 as damage_cover,                 \
                 decode(d.fstl,'2',d.mins_stl*(-1),d.mins_stl) as mins_stl   \
           from ca_clm_process a, tag_data1 c, %s:stl_ins_type d, insurance_type e   \
          where a.itag      =    c.itag             \
            and a.iclaim    =    d.iclaim           \
            and d.dgroup    is not null             \
            and d.iins_type =    e.iins_type ", list[k].dbname);

        $prepare idstmt4 from $stmt;
        $execute idstmt4;
    }

  return M_CM_OK;
        
errexit:
   printf("car843_body ==> SQLCODE:[%ld][%s] \n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   printf("   end EWRITE \n");
   return SQLCODE;
}

long car843_print()
{
   $char stmt[4096], stmt1[1024], stmt2[1024];
   $long qorder;
   int i,x,j,k;
   $int COUNT;
   $char sfilename[200];
   $char stitle[1000];
   $char ssql[1000];
   $char dyearmonth_tmp[7];
   $char title_tmp[101];
   $char title_tmp0[101];
   $char title_tmp1[101];
   $char title_tmp2[101];
   $char filed[20][15];
   $char sqltmp[1024];
   $char filed_tmp[200];
   $char sErrmsg[100];
   $char stitletmp[512];
   $int  rc;
 
   $char sWhere1[1024];
   $char sWhere2[1024];
   $char sWhere3[1024];
   $char sWhere4[1024];

   $WHENEVER ERROR goto errexit;
   $SET LOCK MODE TO WAIT;

   strcpy(sfilename,"�q���I�ؽߴک��Ӫ�");
   printf("sfilename[%s]\n",sfilename);

   strcpy(stitle, sfilename);
   printf("stitle[%s]\n",stitle);
   strcat(stitle, "\n\t");
   strcat(stitle, "�������G ");
   strcat(stitle, sBgnDate_e);
   strcat(stitle, " ~ ");
   strcat(stitle, sEndDate_e);
   strcat(stitle, "   �q���N���G ");
   strcat(stitle, sIroute);
   strcat(stitle, "\n\t�P�Ӹ��X\t�~��\t��O�I��\t��O�I�ئW��\t���l/���d�O\t�O�I���B\t�ߴڪ��B\t");

   printf("stitle[%s]\n",stitle);

   sprintf_s(ssql, 1000 ,
    " select * from car843tbl ");

   printf("ssql[%s]\n",ssql);

   rc = unload_file(outputf," ",sfilename,stitle,ssql);

   if (rc != SUCCESS)
   {
       if (rc == 3501)
       {
          sprintf_s(sErrmsg,100," ��J���^������䤣���� ",sfilename);
       }
       else
       {
          sprintf_s(sErrmsg,100," %s �ɮ׵L�k���� ",sfilename);
       }

       EWRITE(userid, rc , sErrmsg);
       exit(1);
   }

   return M_CM_OK;

errexit:
  printf("SQL=[%d], sqlca.sqlerrm[%s]\n", SQLCODE, sqlca.sqlerrm);
  EWRITE(userid, SQLCODE, sqlca.sqlerrm);
  exit(1);
    
}

int DiffMonth(d1,d2)    /* input data should be date format */
long d1, d2;
{
short mdy1[3], mdy2[3];
int datediff=0;

    rjulmdy(d1,mdy1);
    rjulmdy(d2,mdy2);
    datediff=(mdy1[2]*12+mdy1[0])-(mdy2[2]*12+mdy2[0]);
    if (datediff<0) datediff=0;
    return datediff;
}

