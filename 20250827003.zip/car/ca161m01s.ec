/************************************************/
/*                                              */
/*   PROGRAM : ca161m01s.ec                     */
/*                                              */
/*   PURPOSE : �w��J���L��f��                 */
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
$include sqlca;
#include "safeclib.h"

DBinfo  *list;
int  count_db, i;

long car161(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car161_insert(),car161_single_query(),car161_multiple_query(),
      car161_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {

  case 'Q':
           rtncode=car161_single_query(reply);
           break;
  case 'M':
           rtncode=car161_multiple_query(reply);
           break;
  case 'm':
           rtncode=car161_multiple_query2(reply);
           break;
  case 'D':
  case 'U':
           rtncode=car161_update_exec(reply,command,com_len);
           break;
  default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
             return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}


long car161_single_query(reply)
serverReply reply;
{
 $char DBName[5],ipolicy_in[21],userid[11], sFullName[21], stmt[2048],stmp[2048];
 $char buff[250];
 $char nquota[41],itmp_policy[21],ipolicy[21],nassured[121],iassured[13],iengine[CA_ENGINE_NUM],itag[CA_TAG_NUM],dply_begin[11],dply_end[11];
 $char iofficer[11],nofficer[11],ileader[11],nleader[11],dentry[11],fassured[2],icar_type[3],dpolicy[11],fprint_note[2],fverify_note[2];
 $char ncar_type[11],chk_yn[2];
 $char ncontent_open[256],ncontent_verify[256];
 $char tIpolicy1[POLICY_NUM_1] , tIpolicy2[POLICY_NUM_2];
 $int cnt_empl_no = 0,top_unit = 0,top_40 = 0,top_20 = 0,cnt_top_unit =0;
 $int mprem = 0;
 int tmp_len;

 cm_buf_get("%s %s %s",DBName,ipolicy_in,userid);
 strcpy(ipolicy_in,trim(ipolicy_in));

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
 }

 strcpy(sFullName, get_car_full_db(ipolicy_in));
 
  $SELECT count(*) 
	   INTO $cnt_empl_no
	   FROM personal:asempl 
	  WHERE unit_id = '320101' 
	    AND move_type < 59 
	    AND empl_no = $userid;
 if(cnt_empl_no > 0) 
 {
 	strcpy(stmp," ");
 	strcpy(chk_yn,"Y");
 }    
 else
 {
 	top_40=0;top_20=0;
 	strcpy(chk_yn,"N");
 	$DECLARE top0 cursor for
		 SELECT CASE WHEN top_unit[3,6] = '0000' THEN 40 /*���D��*/
		             WHEN top_unit[5,6] = '00' THEN 20   /*��D��*/
		             else 0 END                          
		   FROM personal:unitid2ef
		  WHERE resp_name = $userid;   
	        $OPEN top0;
		for(;;)
		{
			$FETCH top0 INTO $top_unit;   
			if (SQLCODE != 0) break;
			cnt_top_unit = 0; 
			
			if(top_unit == 40)
				top_40 = 1;
		 	else if(top_unit == 20)
	    			top_20 = 1;
		   	else
		   		cnt_top_unit = 0;	         
		}
		$CLOSE top0;
	 if(top_40 == 1)
	 {
	 	sprintf_s(stmp, sizeof stmp, "AND (a.iquota in (SELECT code_no FROM personal:unitid2ef WHERE top_unit IN (SELECT code_no FROM personal:unitid2ef WHERE resp_name = '%s' AND (dexpire >= today OR dexpire IS NULL))) "
	 	               " OR a.iquota IN (SELECT code_no FROM personal:unitid2ef WHERE resp_name = '%s' AND (dexpire >= today OR dexpire IS NULL)))",userid,userid);
	 }
	 else if(top_20 == 1)
	 {
	 	sprintf_s(stmp, sizeof stmp, "AND a.iquota in (SELECT code_no FROM personal:unitid2ef WHERE resp_name = '%s' AND (dexpire >= today OR dexpire IS NULL))",userid);
	 }
	 else
	 {
		 if(exitsub(reply,M_CM_NOT_FOUND) == True)
		 return M_CM_NOT_FOUND;
		 else
		 return apiRC;			
	 }
 }
 
 sprintf_s(stmt, sizeof stmt, "SELECT (SELECT nbranch FROM sa_branch_type WHERE ibranch = a.iquota),a.itmp_policy, "
    "    a.ipolicy,b.nassured,b.iassured,b.iengine,b.itag,a.dply_begin,a.dply_end,(a.mdmg_prem+a.mlia_prem), "
    "    a.iofficer,(SELECT nname FROM officer WHERE iofficer = a.iofficer), "
    "    a.ileader,(SELECT nname FROM officer WHERE iofficer = a.ileader), "
    "    a.dentry,b.fassured,a.icar_type,a.dpolicy "
    " FROM %s:ply_relation a,%s:policy b,sa_branch_type c,cm_pre_receive d "
    " WHERE a.ipolicy = b.ipolicy "
    " and a.ipolicy[6,7] <> 'VW' "
    " and a.icar_type not in ('51','T1','T2') "
    " and a.iofficer[1,1] not in ('W','H','N') "
    " and a.ipolicy = d.ipolicy1 and d.ipolicy2 = ' ' "
    " and a.itmp_policy = d.ipre_rcv and d.iins_kind = '2' and d.ipre_end = ' ' "
    " and d.ftype_sp not in ('20','JC') "
    " AND a.dentry < today "
    " AND a.dpolicy IS NULL "
    " AND a.iquota = c.ibranch "
    " AND a.dply_begin <= today %s "
    " AND a.ipolicy = '%s'",sFullName,sFullName,stmp,ipolicy_in);
     
 printf("stmt[%s]\n\n",stmt);    
 $PREPARE ppllyy FROM $stmt;
 $EXECUTE ppllyy INTO $nquota,$itmp_policy,$ipolicy,$nassured,$iassured,$iengine,$itag,$dply_begin,$dply_end,$mprem,
                      $iofficer,$nofficer,$ileader,$nleader,$dentry,$fassured,$icar_type,$dpolicy;
 if(SQLCODE==SQLNOTFOUND)
  {
   if(exitsub(reply,M_CM_NOT_FOUND) == True)      /*?*/
    return M_CM_NOT_FOUND;                        /*?*/
   else
    return apiRC;
  }
 	 	
  split_policy(ipolicy_in, tIpolicy1, tIpolicy2);
  printf("[%s][%s]\n",tIpolicy1,tIpolicy2);
  
  $SELECT NVL(fprint_note," "),NVL(fverify_note," ")
     INTO $fprint_note,$fverify_note
     FROM cm_pre_receive 
    WHERE ipolicy1 = $tIpolicy1
      AND ipolicy2 = $tIpolicy2;    
  
  if(SQLCODE==SQLNOTFOUND)
  {
   if(exitsub(reply,M_CM_NOT_FOUND) == True)      /*?*/
    return M_CM_NOT_FOUND;                        /*?*/
   else
    return apiRC;
  }
  
 $select first 1 ncontent into $ncontent_verify from ca_log where ipgid = 'car161' and ilog_number1 = $ipolicy order by dupdate DESC;
 if(SQLCODE==SQLNOTFOUND) strcpy(ncontent_verify," ");
 $select first 1 ncontent into $ncontent_open from ca_log where ipgid = 'car163' and ilog_number1 = $itmp_policy order by dupdate DESC;
 if(SQLCODE==SQLNOTFOUND) strcpy(ncontent_open," "); 

 strcpy(dply_begin,cm_from_infdate_100(dply_begin));
 strcpy(dply_end,cm_from_infdate_100(dply_end));
 strcpy(dentry,cm_from_infdate_100(dentry));
 strcpy(dpolicy,cm_from_infdate_100(dpolicy));

 strcpy(icar_type,trim(icar_type));
 if(strcmp(icar_type,"01")==0||strcmp(icar_type,"02")==0||strcmp(icar_type,"32")==0||strcmp(icar_type,"34")==0||strcmp(icar_type,"35")==0)
 strcpy(ncar_type,"����");
 else 
 strcpy(ncar_type,"�T��");
 
 cm_buf_init(ReplyBuf);

 cm_buf_put("%l %s %s %s %s %s %s %s %s %d %s %s %s %s %s %s %s %s %s %s %s %s %s",
	M_CM_OK,nquota,ipolicy,nassured,iassured,iengine,itag,dply_begin,dply_end,mprem,
                iofficer,nofficer,ileader,nleader,dentry,fassured,ncar_type,dpolicy,fprint_note,fverify_note,chk_yn,ncontent_open,ncontent_verify);

 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}

long car161_multiple_query(reply)
serverReply reply;
{
 $char DBName[5],ileader_in[11],userid[11],delay_day[3],fprint_note[2],stmt[1024],v_sMsg[2040],stmp[128];
 $char iquota[7],ipolicy[21],iassured[13],iengine[CA_ENGINE_NUM],itag[CA_TAG_NUM],dply_begin[11],dply_end[11],iofficer[11],ileader[11],dentry[11],dpolicy[11],empl_no[7],iroute[21];
 $char tIpolicy1[POLICY_NUM_1] , tIpolicy2[POLICY_NUM_2];
 $int cnt_empl_no = 0,c_iroute = 0,c_iofficer = 0,c_iassured = 0,top_unit = 0 ,cnt_top_unit = 0;
 $int sum_cnt = 0 ,c_fprint_note = 0;
 $int mprem,cn_day,qday_permit,delay_day2;
 $char after_date[11],dateline[11],dply_begin2[11],s_dply_begin[11],fverify_note[2],fprint_note2[2],chk_yn[2];
 $long sToday,ply2_begin,sLdeffect;
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;
 int top_40 = 0,top_20 = 0 ,rc;

 cm_buf_get("%s %s %s %s %s",DBName,ileader_in,userid,delay_day,fprint_note);
 delay_day2 = atoi(delay_day);
 strcpy(fprint_note,trim(fprint_note));
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 
if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
         printf("get_db_list error accur \n");
         return SQLCODE;
 }
for(int k=0 ; k<count_db ; k++)
{
/*�P��O�_���ӫO��*/
  $SELECT count(*) 
	   INTO $cnt_empl_no
	   FROM personal:asempl 
	  WHERE unit_id = '320101' 
	    AND move_type < 59 
	    AND empl_no = $userid;
 if(cnt_empl_no > 0) 
 {
 	strcpy(stmp," ");
 	strcpy(chk_yn,"Y");
 }    
 else
 {
 	strcpy(chk_yn,"N");
 	$DECLARE top1 cursor for
		 SELECT CASE WHEN top_unit[3,6] = '0000' THEN 40 /*���D��*/
		             WHEN top_unit[5,6] = '00' THEN 20   /*��D��*/
		             else 0 END                          /*OTH*/
		   FROM personal:unitid2ef
		  WHERE resp_name = $userid;   
	        $OPEN top1;
		for(;;)
		{
			$FETCH top1 INTO $top_unit;   
			if (SQLCODE != 0) break;
			cnt_top_unit = 0; 
			
				if(top_unit == 40)
					top_40 = 1;
			 	else if(top_unit == 20)
		    			top_20 = 1;
			   	else
			   		cnt_top_unit = 0;	         
		}
		$CLOSE top1;
	 if(top_40 == 1)
	 {
	 	sprintf_s(stmp, sizeof stmp, "AND (a.iquota in (SELECT code_no FROM personal:unitid2ef WHERE top_unit IN (SELECT code_no FROM personal:unitid2ef WHERE resp_name = '%s' AND (dexpire >= today OR dexpire IS NULL))) "
	 	               " OR a.iquota IN (SELECT code_no FROM personal:unitid2ef WHERE resp_name = '%s' AND (dexpire >= today OR dexpire IS NULL)))",userid,userid);
	 }
	 else if(top_20 == 1)
	 {
	 	sprintf_s(stmp, sizeof stmp, "AND a.iquota in (SELECT code_no FROM personal:unitid2ef WHERE resp_name = '%s' AND (dexpire >= today OR dexpire IS NULL))",userid);
	 }
	 else
	 {
		 if(exitsub(reply,M_CM_NOT_FOUND) == True)
		 return M_CM_NOT_FOUND;
		 else
		 return apiRC;			
	 }
 }
 
 sprintf_s(stmt, sizeof stmt, "SELECT a.iquota,a.ipolicy,b.iassured,b.iengine,b.itag,a.dply_begin,a.dply_end,a.iofficer,a.ileader,a.dentry,a.dpolicy,b.iroute "
    " FROM %s:ply_relation a,%s:policy b,sa_branch_type c,cm_pre_receive d "
    " WHERE a.ipolicy = b.ipolicy "
    " and a.ipolicy[6,7] <> 'VW' "
    " and a.icar_type not in ('51','T1','T2') "
    " and a.iofficer[1,1] not in ('W','H','N') "
    " and a.ipolicy = d.ipolicy1 and d.ipolicy2 = ' ' "
    " and a.itmp_policy = d.ipre_rcv and d.iins_kind = '2' and d.ipre_end = ' ' "
    " and d.ftype_sp not in ('20','JC') "
    " AND a.dentry < today "
    " AND a.dpolicy IS NULL "
    " AND a.iquota = c.ibranch "
    " AND a.dply_begin <= today %s "
    " AND a.ileader matches '%s' ",list[k].dbname ,list[k].dbname,stmp,ileader_in);
     
	printf("stmt[%s]\n",stmt);
 $PREPARE q_curs FROM $stmt;
 $DECLARE q_cur CURSOR FOR q_curs;
 $OPEN q_cur;
 
 for(;;)
  {
     s_dply_begin[0] = '\0';
     dply_begin[0] = '\0';
     after_date[0] = '\0';
     sToday = 0;
     sLdeffect = 0;
 
     $FETCH q_cur INTO $iquota,$ipolicy,$iassured,$iengine,$itag,$dply_begin,$dply_end,$iofficer,$ileader,$dentry,$dpolicy,$iroute;
     
     if (SQLCODE != 0) break;
     cm_buf_init(tmpbuf);
     if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
     
     sToday = cm_today( );
     strcpy(s_dply_begin,cm_from_infdate_100(dply_begin)); 
     rc = chk_working_date( s_dply_begin, delay_day2, &after_date, v_sMsg);
     sLdeffect = cm_ymd_cdate(after_date);
     printf("--sToday[%d]  sLdeffect[%d]\n",sToday,sLdeffect);
     if(sToday > sLdeffect)
     continue;
     
     strcpy(dply_begin2,cm_from_infdate_100(dply_begin));
     strcpy(dply_end,cm_from_infdate_100(dply_end)); 
     strcpy(dentry,cm_from_infdate_100(dentry));
     strcpy(dpolicy,cm_from_infdate_100(dpolicy)); 
            
     $select count(*) into $c_iroute from ca_permit where iclass = '05' and ftype_sp in ('A1','A2') AND icode = (select iroute_main from cm_route where iroute = $iroute);
     $select count(*) into $c_iofficer from ca_permit where iclass = '06' and ftype_sp in ('A1','A2') AND icode = $iofficer;
     $select count(*) into $c_iassured from ca_permit where iclass = '01' and ftype_sp in ('A1','A2') AND icode = $iassured;    
     if(c_iroute > 0 ||c_iofficer > 0||c_iassured > 0) continue;
     
     split_policy(ipolicy, tIpolicy1, tIpolicy2);
     printf("[%s][%s]\n",tIpolicy1,tIpolicy2);
     $SELECT fverify_note,fprint_note
        INTO $fverify_note,$fprint_note2
        FROM cm_pre_receive
       WHERE ipolicy1 = $tIpolicy1
         AND ipolicy2 = $tIpolicy2
         AND fprint_note matches $fprint_note;
    if(SQLCODE==SQLNOTFOUND) continue;
    printf("---fverify_note[%s],fprint_note2[%s]\n",fverify_note,fprint_note2);
     
    cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s",iquota,ipolicy,iassured,iengine,itag,dply_begin2,dply_end,iofficer,ileader,dentry,fverify_note,fprint_note2);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s %s %s %s %s %s %s %s %s %s",iquota,ipolicy,iassured,iengine,itag,dply_begin2,dply_end,iofficer,ileader,dentry,fverify_note,fprint_note2);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */
}
 $CLOSE q_cur;
 
 
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

errexit:
   if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
   else
     return apiRC;
}

long car161_multiple_query2(reply)
serverReply reply;
{
 $char DBName[5],ipolicy_in[20],userid[11],stmt[1024],v_sMsg[2040],stmp[128];
 $char ipolicy[21],itmp_policy[20],iassured[13],iofficer[11],iroute[21],ipgid[9],iverify[20],dupdate[20],ncontent[256],dupdate2[20],ncontent2[256];
 $char tIpolicy1[POLICY_NUM_1] , tIpolicy2[POLICY_NUM_2];
 $int cnt_empl_no = 0,c_iroute = 0,c_iofficer = 0,c_iassured = 0,top_unit = 0 ,cnt_top_unit = 0;
 $int sum_cnt = 0 ,c_fprint_note = 0;
 $int mprem,cn_day,qday_permit,delay_day2;
 $char after_date[11],dateline[11],dply_begin2[11],s_dply_begin[11],fverify_note[2],fprint_note2[2],chk_yn[2];
 $long sToday,ply2_begin,sLdeffect;
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0;
 int top_40 = 0,top_20 = 0 ,rc;

 cm_buf_get("%s %s %s ",DBName,ipolicy_in,userid);
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
     return M_CM_DB_NOTOPEN;
   else
     return apiRC;
 }
 
if ( (list=get_db_list(&count_db,DBName)) == (char*)0 ) {
         printf("get_db_list error accur \n");
         return SQLCODE;
 }
for(int k=0 ; k<count_db ; k++)
{
/*�P��O�_���ӫO��*/
  $SELECT count(*) 
	   INTO $cnt_empl_no
	   FROM personal:asempl 
	  WHERE unit_id = '320101' 
	    AND move_type < 59 
	    AND empl_no = $userid;
 if(cnt_empl_no > 0) 
 {
 	strcpy(stmp," ");
 	strcpy(chk_yn,"Y");
 }    
 else
 {
 	strcpy(chk_yn,"N");
 	$DECLARE top2 cursor for
		 SELECT CASE WHEN top_unit[3,6] = '0000' THEN 40 /*���D��*/
		             WHEN top_unit[5,6] = '00' THEN 20   /*��D��*/
		             else 0 END                          /*OTH*/
		   FROM personal:unitid2ef
		  WHERE resp_name = $userid;   
	        $OPEN top2;
		for(;;)
		{
			$FETCH top2 INTO $top_unit;   
			if (SQLCODE != 0) break;
			cnt_top_unit = 0; 
			
				if(top_unit == 40)
					top_40 = 1;
			 	else if(top_unit == 20)
		    			top_20 = 1;
			   	else
			   		cnt_top_unit = 0;	         
		}
		$CLOSE top2;
	 if(top_40 == 1)
	 {
	 	sprintf_s(stmp, sizeof stmp, "AND (a.iquota in (SELECT code_no FROM personal:unitid2ef WHERE top_unit IN (SELECT code_no FROM personal:unitid2ef WHERE resp_name = '%s' AND (dexpire >= today OR dexpire IS NULL))) "
	 	               " OR a.iquota IN (SELECT code_no FROM personal:unitid2ef WHERE resp_name = '%s' AND (dexpire >= today OR dexpire IS NULL)))",userid,userid);
	 }
	 else if(top_20 == 1)
	 {
	 	sprintf_s(stmp, sizeof stmp, "AND a.iquota in (SELECT code_no FROM personal:unitid2ef WHERE resp_name = '%s' AND (dexpire >= today OR dexpire IS NULL))",userid);
	 }
	 else
	 {
		 if(exitsub(reply,M_CM_NOT_FOUND) == True)
		 return M_CM_NOT_FOUND;
		 else
		 return apiRC;			
	 }
 }
 
 sprintf_s(stmt, sizeof stmt, "SELECT a.ipolicy,a.itmp_policy,b.iassured,a.iofficer,b.iroute,d.ipgid,d.ilog_number2,d.dupdate,d.ncontent "
    " FROM %s:ply_relation a,%s:policy b,cm_pre_receive c,ca_log d "
    " WHERE a.ipolicy = b.ipolicy "
    " and a.ipolicy[6,7] <> 'VW' "
    " and a.icar_type not in ('51','T1','T2') "
    " and a.iofficer[1,1] not in ('W','H','N') "
    " and a.ipolicy = c.ipolicy1 and c.ipolicy2 = ' ' "
    " and a.itmp_policy = c.ipre_rcv and c.iins_kind = '2' and c.ipre_end = ' ' "
    " and c.ftype_sp not in ('20','JC') "
    " AND a.dentry < today "
    " AND d.ipgid in ('car161','car163') "
    " AND (a.ipolicy = d.ilog_number1 or a.itmp_policy = d.ilog_number1) "
    " AND a.dply_begin <= today %s "
    " AND a.ipolicy = '%s' "
    " order by d.dupdate asc",list[k].dbname ,list[k].dbname,stmp,ipolicy_in);
     
 printf("stmt[%s]\n",stmt);
 $PREPARE q_curs2 FROM $stmt;
 $DECLARE q_cur2 CURSOR FOR q_curs2;
 $OPEN q_cur2;
 
 for(;;)
  {
 
     $FETCH q_cur2 INTO $ipolicy,$itmp_policy,$iassured,$iofficer,$iroute,$ipgid,$iverify,$dupdate,$ncontent;
     
     if (SQLCODE != 0) break;
     cm_buf_init(tmpbuf);
     if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
            
     $select count(*) into $c_iroute from ca_permit where iclass = '05' and ftype_sp in ('A1','A2') AND icode = (select iroute_main from cm_route where iroute = $iroute);
     $select count(*) into $c_iofficer from ca_permit where iclass = '06' and ftype_sp in ('A1','A2') AND icode = $iofficer;
     $select count(*) into $c_iassured from ca_permit where iclass = '01' and ftype_sp in ('A1','A2') AND icode = $iassured;    
     if(c_iroute > 0 ||c_iofficer > 0||c_iassured > 0) continue;
     
     split_policy(ipolicy, tIpolicy1, tIpolicy2);
     printf("[%s][%s]\n",tIpolicy1,tIpolicy2);
     $SELECT fverify_note,fprint_note
        INTO $fverify_note,$fprint_note2
        FROM cm_pre_receive
       WHERE ipolicy1 = $tIpolicy1
         AND ipolicy2 = $tIpolicy2;
    if(SQLCODE==SQLNOTFOUND) continue;
    
    printf("---fverify_note[%s],fprint_note2[%s]\n",fverify_note,fprint_note2);
     
    cm_buf_put("%s %s %s %s %s",ipolicy,ipgid,iverify,dupdate,ncontent);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE q_cur2;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s %s %s",ipolicy,iverify,dupdate,ncontent,ncontent2);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */
}
 $CLOSE q_cur2;
 
 
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

errexit:
   if(exitsub(reply,SQLCODE) == True)
     return SQLCODE;
   else
     return apiRC;
}

long car161_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 $char DBName[5],ipolicy[21],fverify_note[2],ncontent_verify[256],userid[11];
 $char tIpolicy1[POLICY_NUM_1] , tIpolicy2[POLICY_NUM_2];
 char  option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int   tmp_len,raw_len;
 long  dummy;
 long  MsgCode;
 DBinfo *list;
 int   i, j, is_del_fail=0, is_upd_fail=0;
 $char stmt_buf[300];

	comm = (char *) command;
	cm_buf_init(command);
	cm_buf_get("%c %s",&option,DBName);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
		if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}

	if (option == 'U')
	{
		$BEGIN WORK;
		cm_buf_init(command);
		cm_buf_get("%c %s %s %s %s %s",&option,DBName,ipolicy,fverify_note,ncontent_verify,userid);
		split_policy(ipolicy, tIpolicy1, tIpolicy2);
		printf("[%s][%s]\n",tIpolicy1,tIpolicy2);
		
		if(strcmp(fverify_note,"0") == 0)
		{
			$UPDATE cm_pre_receive
			    SET fverify_note = $fverify_note , fprint_note = 'Y' , dprint_note = current
			  WHERE ipolicy1 = $tIpolicy1
			    AND ipolicy2 = $tIpolicy2
			    AND iins_cat = 'C';
		}
		else
		{
			$UPDATE cm_pre_receive
			    SET fverify_note = $fverify_note , fprint_note = ' ' , dprint_note = NULL
			  WHERE ipolicy1 = $tIpolicy1
			    AND ipolicy2 = $tIpolicy2
			    AND iins_cat = 'C';  		
		} 
	  
		if(SQLCODE != 0) goto errexit;
		
		sprintf_s(stmt_buf, sizeof stmt_buf, "insert into ca_log values ('car161','A',?,?,?,?,current)");
		
		$PREPARE ins_log FROM $stmt_buf;
		$EXECUTE ins_log USING $ipolicy,$fverify_note,$ncontent_verify,$userid;
		
		if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
		{
			  printf("no rows has been updated then insert it\n");
		}
		printf("stmt_buf[%s]\n",stmt_buf);
		
		cm_buf_init(ReplyBuf);
		cm_buf_put("%l",M_CM_OK);
		tmp_len = cm_buf_len(ReplyBuf);
		if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
		{
			$WHENEVER SQLERROR CONTINUE;
			$ROLLBACK WORK;
			return apiRC;
		}
		$WHENEVER SQLERROR GOTO errexit;
		$COMMIT WORK;
		return api_OKComplete;
	}
	else
	{
		if(exitsub(reply,M_CM_WRONG_OPTION) == True)
	    	return M_CM_WRONG_OPTION;
		else
	    	return apiRC;
	}

errexit:
	MsgCode = SQLCODE;
	$WHENEVER SQLERROR CONTINUE;
	$ROLLBACK WORK;              /* rollback fail */
	if(SQLCODE != 0) MsgCode = SQLCODE;
	if(exitsub(reply,MsgCode) == True)
	 return MsgCode;
	else
	 return apiRC;
}
