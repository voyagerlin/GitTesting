/*******************************************/
/*                                         */
/*  Program : ca513m01s.ec                 */
/*            by Johnny Kuo                */
/*  Modify  : 86/11/27                     */
/*                                          */
/*  insert    : line 86                    */
/*******************************************/

#include <stdio.h>
#include <string.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "scsmsgs.h"
#include "is_def.h"
#include "print.h"
#include "safeclib.h"
$include sqlca;

$static char dclaim1[17]; /*from query section*/
$static char dclaim2[17]; /*from query section and convert dclaim1*/
$static char Aiclaim[15];
$static char AIacc_reason[3];
$static short int  Aqstl_hist;
$static long Amstl_hist,Amparts_hist;
$char   fspeed[2];

/* johnny add */
  static int errCode;
  char OutFile[20];
 $int PgLine;
 int tmp_len;

$struct itype_hist{
  char ipolicy[POLICY_NUM_1];
  char iins_type[INSURANCE_TYPE];
  char pay_status;
  long dedr_begin;
  long dedr_end;
  char fedr_status[3];
  long dendorse;
  int  minjured_cover;
  int  mdeath_cover;
  int  mdamage_cover;
  long mdeduct;
  int  mpremium;
  struct itype_hist *next;
};

/***********************************************************************/
long car513(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	long rtncode;

	long car513_query1();
	long car513_query2();
	long car513_query3();
	long car513_query4();
	long car513_query5();
	long car513_query6();
	long car513_update();
	char option;

	cm_buf_init(command);
	cm_buf_get("%c",&option);
	switch(option)
	{
		case 'Q':	/* ���鵲��Ƭd�� */ /* ��ñ�ָ�Ƭd�� vouch_state = 100 */
			rtncode=car513_query1(reply);
			break;
		case 'W':	/* ñ�ְh���Ƭd�� vouch_state = 90 */
			rtncode=car513_query5(reply);
			break;
		case 'X':	/* �w��ץ��鵲��Ƭd�� */
			rtncode=car513_query2(reply);
			break;
		case 'Y':	/* ��ñ�֧�����Ƭd�� vouch_state = 110 */
			rtncode=car513_query3(reply);
			break;
		case 'Z':	/* �wñ�֧������鵲��Ƭd��(�ư����O�l�v)  vouch_state = 130 */
			rtncode=car513_query4(reply);
			break;
		case 'H':	/* ���O�l�v��Ƭd��  vouch_state = 130 */
			rtncode=car513_query6(reply);
			break;
		case 'U':
			rtncode=car513_update(reply);
			break;

		default :
			if(exitsub(reply,M_CM_WRONG_OPTION) == True)
			return M_CM_WRONG_OPTION;
			return apiRC;
	}
	return(rtncode);
}

/**************************************************************************/
long car513_query1(reply)
serverReply reply;
{
  $char DBName[5], DBName1[5],sFullName1[20],userid[10];
  /***** ca_local_stl *****/
  $char  iclaim[CLAIM_NUM], fstl[2], iclose_type[3], fchoose[2], Iadjuster[11];
  $char  ipolicy[POLICY_NUM_1]; 
  $long  int dclose;
  $short int kserial;
  $char  ibranch[4],iupbranch[3];
  char   tmpbuf[4000];
  int    repbuf_len=0,tmp_len=0,replycnt=0;

  int    is_iupbranch;
  char   ins_row[5];
  long   MsgCode;
  int    count=0,i,flag;
  int    total_count=0;
  $char  sFullName[20], stmt[1024], sWhere[200];
  $char  fprop;
  $long  vouch = 0;

  /*-------------begin insert------*/
  cm_buf_get("%s %s", DBName, userid);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
      return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  /*****/
  /*  �鵲�@�~�קאּ�T���šB�`�����q�B���ų�B�q�T�B��� */
  /*  �h�`�����q�i��������߮װ��鵲
        ����     �i�ﳡ�ŤΨ�H�U��줧�߮פ鵲
        �q�T�B   �i��ӳ��i�鵲���߮�
      
      ��1�G�����Ϥ������v���Ѫ�  ca503m01s.ec 
      ��2�G���O���w��פ��߮צb���鵲��Ƭd�ߤ���show �X�ӡA�b�w��ץ��鵲�ɥX�{�A
           �Y�o�ͳ��ſ���q�T�B���߮׮ɡA�q�T�B�N�L�k�ݨ�ۤv���߮סA����
           �A�ѦU���ۦ��աC
  ****/
  $SELECT b.fprop, b.ibranch 
     INTO $fprop , $ibranch 
     FROM officer a , branch b
     WHERE a.ibranch = b.ibranch 
       AND a.iofficer = $userid;

  if( SQLCODE == SQLNOTFOUND ) 
      return M_SC_IDIR_NOTFOUND; 

  printf("ibranch [%s] \n", ibranch);

  if (strncmp(ibranch,"02",2) == 0)
      fprop = '1';

  printf("fprop[%c]\n", fprop);

 /* �g�ѨϥΪ�ID �o������쬰��س�쵥�� */

  switch( fprop )
  {
      case '1' :
           sprintf_s(sWhere , 200 ," ");
           break;
           
      case '2' :
			sprintf_s(sWhere , 200 , " AND ((a.ibranch in(select ibranch from branch where iupbranch = '%s')) OR (a.ibranch = '%s')) ",ibranch,ibranch);
            /*sprintf(sWhere , " AND a.ibranch = '%s' " , ibranch );*/
           break;   
      case '3' :
           sprintf_s(sWhere , 200 , " AND a.ibranch = '%s' " , ibranch );
           break;
      default:
           sprintf_s(sWhere , 200 ," ");
           break;
  } 
  
  printf("sWhere[%s]\n",sWhere); 
  printf("ibranch[%s]\n",ibranch);
  /* �]��Q�I���ɸ�Ʀb�z��ɬ�100,��鵲��~�|�^����130,�G���ư���Q�I��� modify by sylvia 108.03.29(1070705004_SC1) */
  sprintf_s(stmt, 1024,"SELECT a.iclaim, a.ipolicy, a.fstl, a.iclose_type, a.fchoose \
                  FROM ca_local_stl a , ca_clm_process b \
                 WHERE ( a.dclose IS NULL OR a.dclose=' ' ) \
                   AND ( a.dentry IS NOT NULL ) \
                   AND a.fchoose <> '1'  \
                   AND ( b.re_state = ' ' OR b.re_state = 'Y' OR b.re_state is NULL ) \
                   AND a.iclaim = b.iclaim  %s \
                   AND not exists (select * from sysdb:ca_tow_away \
                       where iclaim = a.iclaim and a.iclose_type = '1' and dclose is null) \
                ORDER BY iclaim, ipolicy ,fstl, iclose_type",sWhere);


  printf("stmt[%s]\n",stmt);

  $PREPARE q11 FROM $stmt;
  $DECLARE q1_cur1 CURSOR FOR q11;
  $OPEN q1_cur1;
  for(;;)
  {
    $FETCH q1_cur1 INTO  $iclaim,  $ipolicy,$fstl, $iclose_type, $fchoose;
    if (SQLCODE != 0) break;
 
    strncpy (DBName1, ipolicy ,2);
    DBName1[2]='\0';
    strcpy (sFullName1, get_full_dbname(DBName1));
 
    sprintf_s(stmt,1024 ,"SELECT iadjuster \
                    FROM   %s:appraisal \
                    WHERE iclaim ='%s' ",sFullName1, iclaim );
 
    $PREPARE q1x FROM $stmt;
    $DECLARE q1x_cur1 CURSOR FOR q1x;
    $OPEN q1x_cur1;
    $FETCH q1x_cur1 INTO $Iadjuster;

	sprintf_s(stmt,1024,"SELECT count(*) FROM %s:settlement WHERE iclaim = '%s' AND fstl = '%s' AND iclose_type = '%s' \
                  AND vouch_state = 100 and dgroup is null",sFullName1, iclaim, fstl, iclose_type);
	$PREPARE q11x FROM $stmt;
	$DECLARE q11x_cur11 CURSOR FOR q11x;
	$OPEN q11x_cur11;
	$FETCH q11x_cur11 INTO $vouch;

	if (vouch == 0)
		continue;

        sprintf_s(stmt,1024," select nvl(min(fspeed),' ') from %s:payment where iclaim = '%s' AND fstl = '%s' AND iclose_type = '%s' \
                          and fspeed in ('A','B') ", sFullName1, iclaim, fstl, iclose_type);
        $prepare get_fspeed from $stmt;
        $execute get_fspeed into $fspeed;


    cm_buf_init(tmpbuf);
    if ( count == 0 )
    {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
    }
    cm_buf_put("%s %s %s %s %s %s", Iadjuster, iclaim, fstl ,iclose_type, fspeed, fchoose);
    printf("[513]:%s,%s,%s,%s,%s.%s",Iadjuster,iclaim,fstl,iclose_type,fspeed,fchoose);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
    {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
      total_count++;
    }
    else                               /* more than 4K, send to client side */
    {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
      {
         $CLOSE q1x_cur1;     $FREE q1x_cur1; 
         $CLOSE q1_cur1;      $FREE q1_cur1; 
         return apiRC;
      }
      else               /* clear ReplyBuf and count to start all over again */
      {
        replycnt++;
        if (replycnt > 1) sleep(2);
        if (replycnt == 15)   /* more than 30K, client cannot display,error */
        {
           cm_buf_init(ReplyBuf);
           cm_buf_put("%l",M_CM_OUT_SPACE);
           tmp_len = cm_buf_len(ReplyBuf);
           if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
              return apiRC;
              return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s %s %s %s", Iadjuster, iclaim, fstl ,iclose_type, fspeed, fchoose);
        printf("[513]:%s,%s,%s,%s,%s.%s",Iadjuster,iclaim,fstl,iclose_type,fspeed,fchoose);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
        total_count++;
      }
    }
  $CLOSE q1x_cur1;
  $FREE q1x_cur1; 
  }
  printf("[513]:total_count=%d\n",total_count);
  $CLOSE q1_cur1;
  $FREE q1_cur1; 

  if (count > 0)   /* break out, at least one record is selected */
  {
     cm_buf_init(ReplyBuf);
     cm_buf_put_msg(M_CM_OK);
     cm_buf_put_count(count);
     if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
        return apiRC;
     return api_OKComplete;
  }
  else            /* break out, not any row is found */
  {
     if(exitsub(reply,M_CM_NOT_FOUND) == True)
       return M_CM_NOT_FOUND;
     else
       return apiRC;
  }


errexit:
  MsgCode = SQLCODE;
  if(SQLCODE != 0) MsgCode = SQLCODE;
  return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/************************************************************************/
long car513_query2(reply)
serverReply reply;
{
  $char DBName[5],DBName1[5],sFullName1[20];
  /***** ca_local_stl *****/
  $char  iclaim[CLAIM_NUM], ipolicy[POLICY_NUM_1];
  $char  iclose_type[3], fchoose[2], Iadjuster[11], fstl[2];
  $long int dclose;
  $short int kserial;
  char   tmpbuf[4000];
  int    repbuf_len=0,tmp_len=0,replycnt=0;

  char   ins_row[5];
  long   MsgCode;
  int    count=0,i,flag;
  int    total_count=0;
  $char  sFullName[20], stmt[1024], userid[8];

  /*-------------begin insert------*/
  cm_buf_get("%s %s", DBName , userid );

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
      return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  /* �ư�car539��car537�s�y�{���ɽ߮� add by sylvia 108.01.11  */
  sprintf_s(stmt,1024,"SELECT iclaim, ipolicy, fstl, iclose_type, fchoose \
                   FROM ca_local_stl c \
                  WHERE (dclose is NULL OR dclose = ' ') \
                    AND fchoose = '1' AND userid = ? \
                    AND not exists \
                    		(select * from sysdb:ca_onsiteproc_cost \
                          where iclaim = c.iclaim and iclose_type = c.iclose_type  \
                            and dclose is null)	\
                    AND not exists \
                        (select * from sysdb:ca_health_recovery \
						              where iclaim = c.iclaim and iclose_type = c.iclose_type \
						                and dclose is null) \
						        AND not exists \
                        (select * from sysdb:ca_tow_away \
						              where iclaim = c.iclaim and c.iclose_type = '1' and dclose is null) \
                  ORDER BY iclaim, ipolicy ,fstl, iclose_type");
  $PREPARE q21 FROM $stmt;
  $DECLARE q2_cur1 CURSOR FOR q21;
  $OPEN q2_cur1 USING $userid;
  for(;;)
  {
    $FETCH q2_cur1 INTO $iclaim, $ipolicy, $fstl, $iclose_type, $fchoose;
    if (SQLCODE != 0) break;

    strncpy (DBName1, ipolicy ,2);
    DBName1[2]='\0';
    strcpy (sFullName1, get_full_dbname(DBName1));
  
    sprintf_s(stmt,1024 ,"SELECT iadjuster \
                    FROM   %s:appraisal \
                    WHERE iclaim ='%s' ",sFullName1, iclaim );
    
    $PREPARE q2x FROM $stmt;
    $DECLARE q2x_cur CURSOR FOR q2x;
    $OPEN q2x_cur;
    $FETCH q2x_cur INTO $Iadjuster;

    sprintf_s(stmt,1024," select nvl(min(fspeed),' ') from %s:payment where iclaim = '%s' AND fstl = '%s' AND iclose_type = '%s' \
                      and fspeed in ('A','B') ", sFullName1, iclaim, fstl, iclose_type);
    $prepare get_fspeed from $stmt;
    $execute get_fspeed into $fspeed;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
    {
       cm_buf_res_msg();             /* reserve for MsgCode and count */
       cm_buf_res_count();
    }
    cm_buf_put("%s %s %s %s %s %s", Iadjuster, iclaim, fstl ,iclose_type, fspeed, fchoose);
    printf("[513]:%s,%s,%s,%s,%s.%s",Iadjuster,iclaim,fstl,iclose_type,fspeed,fchoose);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
    {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
      total_count++;
    }
    else                               /* more than 4K, send to client side */
    {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
      {
         $CLOSE q2x_cur;      $FREE q2x_cur;
         $CLOSE q2_cur1;      $FREE q2_cur1;
         return apiRC;
      }
      else               /* clear ReplyBuf and count to start all over again */
      {
        replycnt++;
        if (replycnt > 1) sleep(2);
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
           cm_buf_init(ReplyBuf);
           cm_buf_put("%l",M_CM_OUT_SPACE);
           tmp_len = cm_buf_len(ReplyBuf);
           if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
              return apiRC;
              return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s %s %s %s", Iadjuster, iclaim, fstl ,iclose_type, fspeed, fchoose);
        printf("[513]:%s,%s,%s,%s,%s.%s",Iadjuster,iclaim,fstl,iclose_type,fspeed,fchoose);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
        total_count++;
      }
    }
    $CLOSE q2x_cur;
    $FREE q2x_cur;
  } 
  $CLOSE q2_cur1;
  $FREE q2_cur1;

  if (count > 0)   /* break out, at least one record is selected */
  {
     cm_buf_init(ReplyBuf);
     cm_buf_put_msg(M_CM_OK);
     cm_buf_put_count(count);
     if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
        return apiRC;
     return api_OKComplete;
  }
  else            /* break out, not any row is found */
  {
     if(exitsub(reply,M_CM_NOT_FOUND) == True)
       return M_CM_NOT_FOUND;
     else
       return apiRC;
  }

errexit:
  MsgCode = SQLCODE;
  if(SQLCODE != 0) MsgCode = SQLCODE;
  return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/************************************************************************/
long car513_query3(reply)
serverReply reply;
{
  $char DBName[5], DBName1[5],sFullName1[20],userid[10];
  /***** ca_local_stl *****/
  $char  iclaim[CLAIM_NUM], fstl[2], iclose_type[3], fchoose[2], Iadjuster[11];
  $char  ipolicy[POLICY_NUM_1]; 
  $long  int dclose;
  $short int kserial;
  $char  ibranch[4],iupbranch[3];
  char   tmpbuf[4000];
  int    repbuf_len=0,tmp_len=0,replycnt=0;

  int    is_iupbranch;
  char   ins_row[5];
  long   MsgCode;
  int    count=0,i,flag;
  int    total_count=0;
  $char  sFullName[20], stmt[1024], sWhere[200];
  $char  fprop;
  $long  vouch = 0;

  /*-------------begin insert------*/
  cm_buf_get("%s %s", DBName, userid);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
      return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  /*****/
  /*  �鵲�@�~�קאּ�T���šB�`�����q�B���ų�B�q�T�B��� */
  /*  �h�`�����q�i��������߮װ��鵲
        ����     �i�ﳡ�ŤΨ�H�U��줧�߮פ鵲
        �q�T�B   �i��ӳ��i�鵲���߮�
      
      ��1�G�����Ϥ������v���Ѫ�  ca503m01s.ec 
      ��2�G���O���w��פ��߮צb���鵲��Ƭd�ߤ���show �X�ӡA�b�w��ץ��鵲�ɥX�{�A
           �Y�o�ͳ��ſ���q�T�B���߮׮ɡA�q�T�B�N�L�k�ݨ�ۤv���߮סA����
           �A�ѦU���ۦ��աC
  ****/
  $SELECT b.fprop, b.ibranch 
     INTO $fprop , $ibranch 
     FROM officer a , branch b
     WHERE a.ibranch = b.ibranch 
       AND a.iofficer = $userid;

  if( SQLCODE == SQLNOTFOUND ) 
      return M_SC_IDIR_NOTFOUND; 

  if (strncmp(ibranch,"02",2) == 0)
     fprop = '1';

 /* �g�ѨϥΪ�ID �o������쬰��س�쵥�� */

  switch( fprop )
  {
      case '1' :
           sprintf_s(sWhere , 200," ");
           break;
           
      case '2' :
			sprintf_s(sWhere,200 , " AND ((a.ibranch in(select ibranch from branch where iupbranch = '%s')) OR (a.ibranch = '%s')) ",ibranch,ibranch);
            /*sprintf(sWhere , " AND a.ibranch = '%s' " , ibranch );*/
           break;   
      case '3' :
           sprintf_s(sWhere,200 , " AND a.ibranch = '%s' " , ibranch );
           break;
      default:
           sprintf_s(sWhere,200 ," ");
           break;
  } 
  
  printf("sWhere[%s]\n",sWhere); 
  printf("ibranch[%s]\n",ibranch);

  sprintf_s(stmt,1024,"SELECT a.iclaim, a.ipolicy, a.fstl, a.iclose_type, a.fchoose \
                  FROM ca_local_stl a , ca_clm_process b \
                 WHERE ( a.dclose IS NULL OR a.dclose=' ' ) \
                   AND ( a.dentry IS NOT NULL ) \
                   AND a.fchoose <> '1'  \
                   AND ( b.re_state = ' ' OR b.re_state = 'Y' OR b.re_state is NULL ) \
                   AND a.iclaim = b.iclaim  %s \
                ORDER BY iclaim, ipolicy ,fstl, iclose_type",sWhere);


  printf("stmt[%s]\n",stmt);

  $PREPARE q31 FROM $stmt;
  $DECLARE q3_cur1 CURSOR FOR q31;
  $OPEN q3_cur1;
  for(;;)
  {
    $FETCH q3_cur1 INTO  $iclaim,  $ipolicy,$fstl, $iclose_type, $fchoose;
    if (SQLCODE != 0) break;
 
    strncpy (DBName1, ipolicy ,2);
    DBName1[2]='\0';
    strcpy (sFullName1, get_full_dbname(DBName1));
 
    sprintf_s(stmt,1024 ,"SELECT iadjuster \
                    FROM   %s:appraisal \
                    WHERE iclaim ='%s' ",sFullName1, iclaim );
 
    $PREPARE q3x FROM $stmt;
    $DECLARE q3x_cur1 CURSOR FOR q3x;
    $OPEN q3x_cur1;
    $FETCH q3x_cur1 INTO $Iadjuster;

	sprintf_s(stmt,1024,"SELECT count(*) FROM %s:settlement WHERE iclaim = '%s' AND fstl = '%s' AND iclose_type = '%s' \
                  AND vouch_state = 110 ",sFullName1, iclaim, fstl, iclose_type);
	$PREPARE q31x FROM $stmt;
	$DECLARE q31x_cur11 CURSOR FOR q31x;
	$OPEN q31x_cur11;
	$FETCH q31x_cur11 INTO $vouch;

	printf("vouch_stat_sql==>[%s]\n",stmt);

	if (vouch == 0)
		continue;

        sprintf_s(stmt,1024," select nvl(min(fspeed),' ') from %s:payment where iclaim = '%s' AND fstl = '%s' AND iclose_type = '%s' \
                          and fspeed in ('A','B') ", sFullName1, iclaim, fstl, iclose_type);
        $prepare get_fspeed from $stmt;
        $execute get_fspeed into $fspeed;


    cm_buf_init(tmpbuf);
    if ( count == 0 )
    {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
    }
    cm_buf_put("%s %s %s %s %s %s", Iadjuster, iclaim, fstl ,iclose_type, fspeed, fchoose);
    printf("[513]:%s,%s,%s,%s,%s.%s",Iadjuster,iclaim,fstl,iclose_type,fspeed,fchoose);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
    {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
      total_count++;
    }
    else                               /* more than 4K, send to client side */
    {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
      {
         $CLOSE q3x_cur1;     $FREE q3x_cur1; 
         $CLOSE q3_cur1;      $FREE q3_cur1; 
         return apiRC;
      }
      else               /* clear ReplyBuf and count to start all over again */
      {
        replycnt++;
        if (replycnt > 1) sleep(2);
        if (replycnt == 15)   /* more than 30K, client cannot display,error */
        {
           cm_buf_init(ReplyBuf);
           cm_buf_put("%l",M_CM_OUT_SPACE);
           tmp_len = cm_buf_len(ReplyBuf);
           if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
              return apiRC;
              return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s %s %s %s", Iadjuster, iclaim, fstl ,iclose_type, fspeed, fchoose);
        printf("[513]:%s,%s,%s,%s,%s.%s",Iadjuster,iclaim,fstl,iclose_type,fspeed,fchoose);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
        total_count++;
      }
    }
  $CLOSE q3x_cur1;
  $FREE q3x_cur1; 
  }
  printf("[513]:total_count=%d\n",total_count);
  $CLOSE q3_cur1;
  $FREE q3_cur1; 

  if (count > 0)   /* break out, at least one record is selected */
  {
     cm_buf_init(ReplyBuf);
     cm_buf_put_msg(M_CM_OK);
     cm_buf_put_count(count);
     if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
        return apiRC;
     return api_OKComplete;
  }
  else            /* break out, not any row is found */
  {
     if(exitsub(reply,M_CM_NOT_FOUND) == True)
       return M_CM_NOT_FOUND;
     else
       return apiRC;
  }


errexit:
  MsgCode = SQLCODE;
  if(SQLCODE != 0) MsgCode = SQLCODE;
  return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/************************************************************************/
long car513_query4(reply)
serverReply reply;
{
  $char DBName[5], DBName1[5],sFullName1[20],userid[10];
  /***** ca_local_stl *****/
  $char  iclaim[CLAIM_NUM], fstl[2], iclose_type[3], fchoose[2], Iadjuster[11];
  $char  ipolicy[POLICY_NUM_1]; 
  $long  int dclose;
  $short int kserial;
  char   tmpbuf[4000];
  int    repbuf_len=0,tmp_len=0,replycnt=0;

  char   ins_row[5];
  long   MsgCode;
  int    count=0,i,flag;
  int    total_count=0;
  $char  sFullName[20], stmt[4096];
  $char  fprop;
  $long  vouch = 0;
  $char  fcard_class[2];
  $char  ibranch[11];

  /*-------------begin insert------*/
  cm_buf_get("%s %s", DBName, userid);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
      return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  $WHENEVER SQLERROR continue;

  $drop table car513_4;

  $WHENEVER SQLERROR GOTO errexit;

  $create temp table car513_4
   (
       iclaim          char(20),
       ipolicy         char(20),
       fstl            char(2),
       iclose_type     int,
       fchoose         char(1),
       iadjuster       char(10),
       fspeed          char(1)
   )with no log;

  
  $declare cc_cur cursor for
    select branch
      into $ibranch 
      from servertbl
     where branch != 'S1'
     order by 1;
  
   $open cc_cur;
   for(;;)
   {
      $fetch cc_cur;
      if (SQLCODE == SQLNOTFOUND) break;

      sprintf_s(stmt,4096,
        "insert into car513_4    \
	  select a.iclaim, a.ipolicy, a.fstl, a.iclose_type, a.fchoose, b.adjustment,   \
                 (select nvl(min(fspeed),' ')               \
                    from %s:payment v                       \
                   where iclaim      =  c.iclaim            \
                     and fstl        =  c.fstl              \
                     and iclose_type =  c.iclose_type       \
                     and fspeed in ('A','B') )              \
	    from ca_local_stl a, ca_clm_process b, %s:settlement c      \
           where (a.dclose is null or a.dclose = ' ')  \
	     and a.dentry is not null    \
             and a.fchoose <> '1'        \
	     and (b.re_state = ' ' or b.re_state = 'Y' or b.re_state is null)  \
	     and a.iclaim  =  b.iclaim       \
	     and a.iclaim      =  c.iclaim   \
	     and a.fstl        =  c.fstl     \
	     and a.iclose_type =  c.iclose_type \
	     and c.vouch_state =  130            \
	     and c.dclose      is null           \
	     and not exists (select *            \
	                       from %s:ca_stl_victim d               \
			      where a.iclaim      =  d.iclaim        \
			        and a.fstl        =  d.fstl          \
				and a.iclose_type =  d.iclose_type   \
				and d.mstl_health >  0) \
		and not exists (select * from sysdb:ca_onsiteproc_cost \
                         where iclaim = c.iclaim and iclose_type = c.iclose_type \
                           and dclose is null)		", 
        get_full_dbname(ibranch), get_full_dbname(ibranch), get_full_dbname(ibranch) );
 
      $prepare getalldata from $stmt;
      $execute getalldata;
      printf("stmt[%s]\n",stmt);

   }
   $close cc_cur;
   $free cc_cur;
   
   sprintf_s(stmt,4096," select * from car513_4 order by 1,2,3,4 ");

  printf("stmt[%s]\n",stmt);

  $PREPARE q41 FROM $stmt;
  $DECLARE q4_cur1 CURSOR FOR q41;
  $OPEN q4_cur1;
  for(;;)
  {
    $FETCH q4_cur1 INTO  $iclaim, $ipolicy, $fstl, $iclose_type, $fchoose, $Iadjuster, $fspeed;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
    {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
    }
    cm_buf_put("%s %s %s %s %s %s", Iadjuster, iclaim, fstl ,iclose_type, fspeed, fchoose);
    printf("[513]:%s,%s,%s,%s,%s.%s",Iadjuster,iclaim,fstl,iclose_type,fspeed,fchoose);

    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
    {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
      total_count++;
    }
    else                               /* more than 4K, send to client side */
    {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
      {
         $CLOSE q4_cur1;      $FREE q4_cur1; 
         return apiRC;
      }
      else               /* clear ReplyBuf and count to start all over again */
      {
        replycnt++;
        if (replycnt > 1) sleep(1);
        if (replycnt == 15)   /* more than 30K, client cannot display,error */
        {
           cm_buf_init(ReplyBuf);
           cm_buf_put("%l",M_CM_OUT_SPACE);
           tmp_len = cm_buf_len(ReplyBuf);
           if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
              return apiRC;
              return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s %s %s %s", Iadjuster, iclaim, fstl ,iclose_type, fspeed, fchoose);
        printf("[513]:%s,%s,%s,%s,%s.%s",Iadjuster,iclaim,fstl,iclose_type,fspeed,fchoose);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
        total_count++;
      }
    }
  }
  printf("[513]:total_count=%d\n",total_count);
  $CLOSE q4_cur1;
  $FREE q4_cur1; 

  $WHENEVER SQLERROR continue;

  $drop table car513_4;

  $WHENEVER SQLERROR GOTO errexit;

  if (count > 0)   /* break out, at least one record is selected */
  {
     cm_buf_init(ReplyBuf);
     cm_buf_put_msg(M_CM_OK);
     cm_buf_put_count(count);
     if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
        return apiRC;
     return api_OKComplete;
  }
  else            /* break out, not any row is found */
  {
     if(exitsub(reply,M_CM_NOT_FOUND) == True)
       return M_CM_NOT_FOUND;
     else
       return apiRC;
  }


errexit:
  MsgCode = SQLCODE;
  if(SQLCODE != 0) MsgCode = SQLCODE;
  return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/************************************************************************/
long car513_query5(reply)
serverReply reply;
{
  $char DBName[5], DBName1[5],sFullName1[20],userid[10];
  /***** ca_local_stl *****/
  $char  iclaim[CLAIM_NUM], fstl[2], iclose_type[3], fchoose[2], Iadjuster[11];
  $char  ipolicy[POLICY_NUM_1]; 
  $long  int dclose;
  $short int kserial;
  $char  ibranch[4],iupbranch[3];
  char   tmpbuf[4000];
  int    repbuf_len=0,tmp_len=0,replycnt=0;

  int    is_iupbranch;
  char   ins_row[5];
  long   MsgCode;
  int    count=0,i,flag;
  int    total_count=0;
  $char  sFullName[20], stmt[1024], sWhere[200];
  $char  fprop;
  $long  vouch = 0;

  /*-------------begin insert------*/
  cm_buf_get("%s %s", DBName, userid);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
      return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  /*****/
  /*  �鵲�@�~�קאּ�T���šB�`�����q�B���ų�B�q�T�B��� */
  /*  �h�`�����q�i��������߮װ��鵲
        ����     �i�ﳡ�ŤΨ�H�U��줧�߮פ鵲
        �q�T�B   �i��ӳ��i�鵲���߮�
      
      ��1�G�����Ϥ������v���Ѫ�  ca503m01s.ec 
      ��2�G���O���w��פ��߮צb���鵲��Ƭd�ߤ���show �X�ӡA�b�w��ץ��鵲�ɥX�{�A
           �Y�o�ͳ��ſ���q�T�B���߮׮ɡA�q�T�B�N�L�k�ݨ�ۤv���߮סA����
           �A�ѦU���ۦ��աC
  ****/
  $SELECT b.fprop, b.ibranch 
     INTO $fprop , $ibranch 
     FROM officer a , branch b
     WHERE a.ibranch = b.ibranch 
       AND a.iofficer = $userid;

  if( SQLCODE == SQLNOTFOUND ) 
      return M_SC_IDIR_NOTFOUND; 

  if (strncmp(ibranch,"02",2) == 0)
     fprop = '1';

 /* �g�ѨϥΪ�ID �o������쬰��س�쵥�� */

  switch( fprop )
  {
      case '1' :
           sprintf_s(sWhere,200 ," ");
           break;
           
      case '2' :
			sprintf_s(sWhere,200 , " AND ((a.ibranch in(select ibranch from branch where iupbranch = '%s')) OR (a.ibranch = '%s')) ",ibranch,ibranch);
            /*sprintf(sWhere , " AND a.ibranch = '%s' " , ibranch );*/
           break;   
      case '3' :
           sprintf_s(sWhere,200 , " AND a.ibranch = '%s' " , ibranch );
           break;
      default:
           sprintf_s(sWhere,200 ," ");
           break;
  } 
  
  printf("sWhere[%s]\n",sWhere); 
  printf("ibranch[%s]\n",ibranch);

  sprintf_s(stmt,1024,"SELECT a.iclaim, a.ipolicy, a.fstl, a.iclose_type, a.fchoose \
                  FROM ca_local_stl a , ca_clm_process b \
                 WHERE ( a.dclose IS NULL OR a.dclose=' ' ) \
                   AND ( a.dentry IS NOT NULL ) \
                   AND a.fchoose <> '1'  \
                   AND ( b.re_state = ' ' OR b.re_state = 'Y' OR b.re_state is NULL ) \
                   AND a.iclaim = b.iclaim  %s \
                ORDER BY iclaim, ipolicy ,fstl, iclose_type",sWhere);


  printf("stmt[%s]\n",stmt);

  $PREPARE q51 FROM $stmt;
  $DECLARE q5_cur1 CURSOR FOR q51;
  $OPEN q5_cur1;
  for(;;)
  {
    $FETCH q5_cur1 INTO  $iclaim,  $ipolicy,$fstl, $iclose_type, $fchoose;
    if (SQLCODE != 0) break;
 
    strncpy (DBName1, ipolicy ,2);
    DBName1[2]='\0';
    strcpy (sFullName1, get_full_dbname(DBName1));
 
    sprintf_s(stmt,1024 ,"SELECT iadjuster \
                    FROM   %s:appraisal \
                    WHERE iclaim ='%s' ",sFullName1, iclaim );
 
    $PREPARE q5x FROM $stmt;
    $DECLARE q5x_cur1 CURSOR FOR q5x;
    $OPEN q5x_cur1;
    $FETCH q5x_cur1 INTO $Iadjuster;

	sprintf_s(stmt,1024,"SELECT count(*) FROM %s:settlement WHERE iclaim = '%s' AND fstl = '%s' AND iclose_type = '%s' \
                  AND vouch_state = 90 ",sFullName1, iclaim, fstl, iclose_type);
	$PREPARE q51x FROM $stmt;
	$DECLARE q51x_cur11 CURSOR FOR q51x;
	$OPEN q51x_cur11;
	$FETCH q51x_cur11 INTO $vouch;

	if (vouch == 0)
		continue;
   
    sprintf_s(stmt,1024," select nvl(min(fspeed),' ') from %s:payment where iclaim = '%s' AND fstl = '%s' AND iclose_type = '%s' \
                      and fspeed in ('A','B') ", sFullName1, iclaim, fstl, iclose_type);
    $prepare get_fspeed from $stmt;
    $execute get_fspeed into $fspeed;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
    {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
    }
    cm_buf_put("%s %s %s %s %s %s", Iadjuster, iclaim, fstl ,iclose_type, fspeed, fchoose);
    printf("[513]:%s,%s,%s,%s,%s.%s",Iadjuster,iclaim,fstl,iclose_type,fspeed,fchoose);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
    {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
      total_count++;
    }
    else                               /* more than 4K, send to client side */
    {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
      {
         $CLOSE q5x_cur1;     $FREE q5x_cur1; 
         $CLOSE q5_cur1;      $FREE q5_cur1; 
         return apiRC;
      }
      else               /* clear ReplyBuf and count to start all over again */
      {
        replycnt++;
        if (replycnt > 1) sleep(2);
        if (replycnt == 15)   /* more than 30K, client cannot display,error */
        {
           cm_buf_init(ReplyBuf);
           cm_buf_put("%l",M_CM_OUT_SPACE);
           tmp_len = cm_buf_len(ReplyBuf);
           if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
              return apiRC;
              return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s %s %s %s", Iadjuster, iclaim, fstl ,iclose_type, fspeed, fchoose);
        printf("[513]:%s,%s,%s,%s,%s.%s",Iadjuster,iclaim,fstl,iclose_type,fspeed,fchoose);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
        total_count++;
      }
    }
  $CLOSE q5x_cur1;
  $FREE q5x_cur1; 
  }
  printf("[513]:total_count=%d\n",total_count);
  $CLOSE q5_cur1;
  $FREE q5_cur1; 

  if (count > 0)   /* break out, at least one record is selected */
  {
     cm_buf_init(ReplyBuf);
     cm_buf_put_msg(M_CM_OK);
     cm_buf_put_count(count);
     if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
        return apiRC;
     return api_OKComplete;
  }
  else            /* break out, not any row is found */
  {
     if(exitsub(reply,M_CM_NOT_FOUND) == True)
       return M_CM_NOT_FOUND;
     else
       return apiRC;
  }


errexit:
  MsgCode = SQLCODE;
  if(SQLCODE != 0) MsgCode = SQLCODE;
  return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/************************************************************************/
long car513_query6(reply)
serverReply reply;
{
  $char DBName[5], DBName1[5],sFullName1[20],userid[10];
  /***** ca_local_stl *****/
  $char  iclaim[CLAIM_NUM], fstl[2], iclose_type[3], fchoose[2], Iadjuster[11];
  $char  ipolicy[POLICY_NUM_1]; 
  $long  int dclose;
  $short int kserial;
  char   tmpbuf[4000];
  int    repbuf_len=0,tmp_len=0,replycnt=0;

  char   ins_row[5];
  long   MsgCode;
  int    count=0,i,flag;
  int    total_count=0;
  $char  sFullName[20], stmt[1024];
  $long  vouch = 0;
  $char  fcard_class[2];

  /*-------------begin insert------*/
  cm_buf_get("%s %s", DBName, userid);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
      return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

  sprintf_s(stmt,1024,"SELECT a.iclaim, a.ipolicy, a.fstl, a.iclose_type, a.fchoose \
                  FROM ca_local_stl a , ca_clm_process b \
                 WHERE ( a.dclose IS NULL OR a.dclose=' ' ) \
                   AND ( a.dentry IS NOT NULL ) \
                   AND a.fchoose <> '1' \
                   AND ( b.re_state = ' ' OR b.re_state = 'Y' OR b.re_state is NULL ) \
                   AND a.iclaim = b.iclaim \
                ORDER BY iclaim, ipolicy ,fstl, iclose_type");
  printf("stmt[%s]\n",stmt);

  $PREPARE q61 FROM $stmt;
  $DECLARE q6_cur1 CURSOR FOR q61;
  $OPEN q6_cur1;
  for(;;)
  {
    $FETCH q6_cur1 INTO $iclaim, $ipolicy, $fstl, $iclose_type, $fchoose;
    if (SQLCODE != 0) break;
 
    strncpy (DBName1, ipolicy ,2);
    DBName1[2]='\0';
    strcpy (sFullName1, get_full_dbname(DBName1));
 
    sprintf_s(stmt,1024 ,"SELECT iadjuster, fcard_class \
                    FROM   %s:appraisal \
                    WHERE iclaim ='%s' ", sFullName1, iclaim);
    $PREPARE q6x FROM $stmt;
    $EXECUTE q6x INTO $Iadjuster, $fcard_class;
    printf("fcard_class[%s]\n", fcard_class);

    if (fcard_class[0]!='1') continue;

	sprintf_s(stmt,1024,"SELECT count(*) FROM %s:settlement WHERE iclaim = '%s' AND fstl = '%s' AND iclose_type = '%s' \
                  AND vouch_state = 130 ", sFullName1, iclaim, fstl, iclose_type);
	$PREPARE q61x FROM $stmt;
	$EXECUTE q61x INTO $vouch;
	if (vouch == 0)
		continue;

	/* ���O�l�v */
	sprintf_s(stmt,1024,"SELECT COUNT(*) FROM %s:ca_stl_victim WHERE iclaim = '%s' AND fstl = '%s' AND iclose_type = '%s' \
                  AND mstl_health > 0 ", sFullName1, iclaim, fstl, iclose_type);
	$PREPARE q62x FROM $stmt;
	$EXECUTE q62x INTO $vouch;
	printf("vouch[%ld]\n", vouch);
	if (vouch == 0)	continue;

        /* ���O�l�v���|���t��A�BB�� */
        strcpy(fspeed," ");

    cm_buf_init(tmpbuf);
    if ( count == 0 )
    {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
    }
    cm_buf_put("%s %s %s %s %s %s", Iadjuster, iclaim, fstl ,iclose_type, fspeed, fchoose);
    printf("[513]:%s,%s,%s,%s,%s.%s",Iadjuster,iclaim,fstl,iclose_type,fspeed,fchoose);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
    {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
      total_count++;
    }
    else                               /* more than 4K, send to client side */
    {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
      {
         $CLOSE q6_cur1;      $FREE q6_cur1; 
         return apiRC;
      }
      else               /* clear ReplyBuf and count to start all over again */
      {
        replycnt++;
        if (replycnt > 1) sleep(2);
        if (replycnt == 15)   /* more than 30K, client cannot display,error */
        {
           cm_buf_init(ReplyBuf);
           cm_buf_put("%l",M_CM_OUT_SPACE);
           tmp_len = cm_buf_len(ReplyBuf);
           if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
              return apiRC;
              return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s %s %s %s", Iadjuster, iclaim, fstl ,iclose_type, fspeed, fchoose);
        printf("[513]:%s,%s,%s,%s,%s.%s",Iadjuster,iclaim,fstl,iclose_type,fspeed,fchoose);
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
        total_count++;
      }
    }
  }
  printf("total_count=%d\n",total_count);
  $CLOSE q6_cur1;
  $FREE q6_cur1; 

  if (count > 0)   /* break out, at least one record is selected */
  {
     cm_buf_init(ReplyBuf);
     cm_buf_put_msg(M_CM_OK);
     cm_buf_put_count(count);
     if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
        return apiRC;
     return api_OKComplete;
  }
  else            /* break out, not any row is found */
  {
     if(exitsub(reply,M_CM_NOT_FOUND) == True)
       return M_CM_NOT_FOUND;
     else
       return apiRC;
  }


errexit:
  MsgCode = SQLCODE;
  if(SQLCODE != 0) MsgCode = SQLCODE;
  return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/************************************************************************/
long car513_update(reply)
serverReply reply;
{
  $char DBName[5];
  /***** ca_local_stl *****/
  $char iclaim[CLAIM_NUM], fstl[2],iclose_type[3], fchoose[2];
  $long int dclose;
  $short int kserial;

  char ins_row[5];
  long MsgCode;
  int tmp_len;
  int count=0,i,flag;
  $char sFullName[20], stmt[1024], userid[8], ibranch1[3], ibranch2[4];
  $char fprop1 = "";
  $char fprop2 = "";

  /*-------------begin insert------*/
cm_buf_get("%s %s %s", DBName, userid ,ins_row);
  sscanf_s(ins_row,"%d",&count);

  $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
      return exitsub(reply, M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
      
  /********************************************************************/    
  /*
    �ק�ᤧ�鵲�@�~�A�Y�o�ͨ�ӥH�W���P�ɿ�߮׮ɡA�H�̤p���
    ���D-->  �q�T�B > ���ų�� > �`�����q                          
                                                                      */
  /********************************************************************/
  $SET LOCK MODE TO WAIT 220;
  $BEGIN WORK;

  for (i=0; i<count; i++){
      cm_buf_get("%s %s %s %s", iclaim, fstl, iclose_type, fchoose);

     $UPDATE ca_local_stl
         SET fchoose     = $fchoose , 
             userid      = $userid
       WHERE iclaim      = $iclaim 
         AND fstl        = $fstl
         AND iclose_type = $iclose_type
         AND fchoose     <> '1';
         
     if( sqlca.sqlerrd[2] == 0 ) 
     {
        /*  ���ɦ��߮פw����פ��ʧ@�A�ˬd���̷s��s�H�������A
            �Y�̷s��s�H�����`�����q�A�h�����\��s�U�ų�줧���
            ���ŤH�����\��s�q�T�B�H�������*/
            
        $SELECT decode(b.ibranch,"02","1",b.fprop)
           INTO $fprop1
           FROM officer a , branch b
          WHERE a.ibranch = b.ibranch 
            AND a.iofficer = $userid;  /*��s�H���Ҧb��줧���� */
            
        $SELECT decode(c.ibranch,"02","1",c.fprop)
              INTO $fprop2
              FROM ca_local_stl a , officer b , branch c
             WHERE a.userid    = b.iofficer 
               AND b.ibranch   = c.ibranch
               AND a.iclaim    = $iclaim 
               AND fstl        = $fstl
               AND iclose_type = $iclose_type;
        
        printf("fprop1[%c]  fprop2[%c]\n",fprop1,fprop2);
           
        if ( fprop1 == '1' && fprop2 != '1' )
        {
            continue;     /* ��s�H�����`�B�����q�ɡA�������*/  
        }

        if ( fprop1 == '2' && fprop2 == '3' )
        {
           
              continue;    /* ��s�H�������šB�����߮׳q�T�B�w��  */
                           /* �B��פH�����q�T�B�H���A�G����s */
            
        }
        
        printf("before update iclaim[%s] fstl[%s] iclose_type[%s] userid[%s]\n",
                iclaim , fstl , iclose_type , userid );
        
        $UPDATE ca_local_stl
            SET fchoose     = $fchoose , 
                userid      = $userid
          WHERE iclaim      = $iclaim 
            AND fstl        = $fstl
            AND iclose_type = $iclose_type;
     }
  }

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l",M_CM_OK);
  tmp_len = cm_buf_len(ReplyBuf);
  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False) {
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    return apiRC;
    $WHENEVER SQLERROR GOTO errexit;
  }

  $WHENEVER SQLERROR GOTO errexit;
  $COMMIT WORK;

  return api_OKComplete;

errexit:
  MsgCode = SQLCODE;
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if(SQLCODE != 0) MsgCode = SQLCODE;
  return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/************************************************************************/

