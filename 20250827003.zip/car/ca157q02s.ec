/************************************************************************************/
/*                                                                                  */
/*      PROGRAM : ca157q02s.ec                                                      */
/*      Modify  :                                                                   */
/************************************************************************************/

#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "cmprint.h"
$include sqlca;
$include sqltypes;
#include <decimal.h>
#include "print.h"
#include "sqlfatal.h"
#include "safeclib.h"

$char g_sDbName[5],g_iofficer[11],g_check[2];
$char  g_sUserId[11],g_dply_begin[31],g_dply_begin1[31],g_dply_end[31],g_dply_end1[31];
$char sfilename[41],stitle[1000],outputf[21],sErrmsg[200],dapplicant[31];
$char iassured[13],nassured[101],dply_begin[20],dply_end[20],iroute[20],nroute[41];
$char iofficer[11],nofficer[11],safe_rate[10],manage_rate[10];
$char iassured1[14],iofficer1[12],iupdate[11],iupdate1[11],dupdate[20],stmp[20];
$int  mins_premium,sunrate;
$char    stmt[3000];
char     g_sMsgBuf[1024];
long     rc;

int      count_db,i;
char     sApHome[30];
DBinfo   *list;

       
main (argc, argv)
int argc;
char **argv;
{
    int rtc;

    batchinit();

    strcpy(g_sDbName,isNULLstr(argv[1]));
    strcpy(g_sUserId,isNULLstr(argv[2]));
    strcpy(g_iofficer,isNULLstr(argv[3]));
    strcpy(g_dply_begin,isNULLstr(argv[4]));
    strcpy(g_dply_end,isNULLstr(argv[5]));
    strcpy(g_check,isNULLstr(argv[6]));
    strcpy(outputf,isNULLstr(argv[7]));
    
    /*�N����~�ର�褸�~*/
    strcpy(g_dply_begin1,cm_to_infdate(g_dply_begin));
    strcpy(g_dply_end1,cm_to_infdate(g_dply_end));
/*    
    rtc = car157_get_db();
    if (rtc != M_CM_OK) {
	EWRITE(g_sUserId,rtc,g_sMsgBuf);
	return rtc;
	}
*/
      if ((rtc=car157_init()) != SUCCESS)
        {
           EWRITE(g_sUserId,rtc,g_sMsgBuf);
           return rtc;
        }
      if ((rtc=car157_cacul()) != SUCCESS)
        {
            EWRITE(g_sUserId, rtc, g_sMsgBuf);
            return rtc;
        }
    
      rtc=car157_dtl_rptA();
    
if (rtc != SUCCESS)
  {
        EWRITE(g_sUserId,rtc,g_sMsgBuf);
        return rtc;
  }
    
}

car157_init()
{
    $WHENEVER SQLERROR goto errexit;

    if(db_select(g_sDbName) == False)
    {
     	strcpy(g_sMsgBuf,"DB [%s] : is not opened",g_sDbName);
     	return M_CM_DB_NOTOPEN;
    }

    $CREATE TEMP TABLE car157_tmp
    (
        iassured       char(13)    ,                        /*�Q�O�I�H�N��*/
        nassured       char(100)   ,                        /*�Q�O�I�H�W��*/
   	iofficer       char(11)    ,                        /*�g��N��*/
    	nofficer       char(10)    ,                        /*�g��W��*/
    	iroute         char(20)    ,                        /*�q���N��*/
    	nroute         char(40)    ,                        /*�q���W��*/    
    	safe_rate      decimal(9,7),                        /*�w���[��O�T��*/
    	manage_rate    decimal(9,7),                        /*�޲z�[��O�T��*/
        dply_begin     date        ,                        /*�ͮĤ�*/
    	dply_end       date        ,                        /*�����*/
    	iupdate        char(10)    ,                        /*���ɤH��*/
        dupdate        char(20)                             /*���ɮɶ�*/
    )WITH NO LOG;

    return SUCCESS;

errexit:
  printf("Steven:err[%ld][%s]\n",SQLCODE,sqlca.sqlerrm);
  sprintf_s(g_sMsgBuf, sizeof g_sMsgBuf, "%s",sqlca.sqlerrm);
  return SQLCODE;
}

car157_cacul()
{

    $WHENEVER SQLERROR goto errexit;
    printf("------------------g_iofficer[%s]\n",g_iofficer);
    printf("------------------g_dply_begin1[%s]\n",g_dply_begin1);
    printf("------------------g_dply_end1[%s]\n",g_dply_end1);
    printf("------------------g_check[%s]\n",g_check);
    if(strcmp(g_check,"1")==0)
    strcpy(stmp,"");
    else
    strcpy(stmp,"AND a.dexpire is null");
        
    sprintf_s(stmt, sizeof stmt, " Select a.iassured,"
		  "  (select max(b.nchi_full) from cu_customer b where b.ifpce_id = a.iassured) as nassured, "
                  "  a.iofficer, "
                  "  (select max(c.nname) from officer c where c.iofficer = a.iofficer) as nofficer, "
                  "  a.iroute, "
                  "  (select max(d.nroute) from cm_route d where d.iroute = a.iroute) as nroute, "
                  "  a.safe_rate,a.manage_rate,a.drate,a.dexpire,a.iupdate,a.dupdate "
                  "  FROM ca_truck_transport a "
                  " WHERE a.iofficer matches '%s' "
                  "   AND a.drate between '%s' and '%s' " 
                  "   %s ",g_iofficer,g_dply_begin1,g_dply_end1,stmp);             
                      

printf(" stmt[%s] \n\n", stmt);

    $PREPARE P1 FROM $stmt;
    $DECLARE cur_1 cursor for P1;
    $OPEN cur_1;

    for(;;)
    {
	    $FETCH cur_1
	      INTO $iassured ,$nassured ,$iofficer ,$nofficer ,$iroute ,$nroute ,$safe_rate ,$manage_rate ,$dply_begin ,$dply_end ,$iupdate ,$dupdate;
	      	           
        if (SQLCODE==SQLNOTFOUND) break;

               
              strcpy(iassured1, "�");                       /*���X�Ĥ@�X��0�A�����bexcel show �X*/
              strcat(iassured1,trim(iassured));                         
              
              strcpy(iofficer1, "�");
              strcat(iofficer1,trim(iofficer));
              
              strcpy(iupdate1, "�");
              strcat(iupdate1,trim(iupdate));
              
	      $INSERT INTO car157_tmp
	 	 VALUES ($iassured1 ,$nassured ,$iofficer1 ,$nofficer ,$iroute ,$nroute ,$safe_rate ,$manage_rate ,$dply_begin ,$dply_end ,$iupdate1 ,$dupdate);   /*���ӤW��car157_tmp����*/

    }
    $CLOSE cur_1;
    $FREE cur_1;
    
 
    
    return SUCCESS;
    
errexit:
  printf("Steven:err[%ld][%s]\n",SQLCODE,sqlca.sqlerrm);
  sprintf_s(g_sMsgBuf, sizeof g_sMsgBuf, "%s",sqlca.sqlerrm);
  return SQLCODE;
}

car157_dtl_rptA()
{
    char tmp[30];

    strcpy(sfilename,"���@�ɩ��� ");

    memset(stmt, 0x00, sizeof(stmt));
   
    sprintf_s(stmt, sizeof stmt, " SELECT * FROM car157_tmp ");
                 
    sprintf_s(stitle, sizeof stitle, "���@�ɩ��� \n \t�d�ߥͮĤ�϶�:%s��%s \n \t",g_dply_begin,g_dply_end);
    strcat(stitle,"�Q�O�I�H�N��\t�Q�O�I�H�W��\t�g��N��\t�g��N���W��\t�q���N��\t�q���N���W��\t�w���[��O�T��\t�޲z�[��O�T��\t�ͮĤ�\t���Τ�\t���ɤH��\t���ɤ��\t");

 
    rc = unload_file(outputf," ",sfilename,stitle,stmt);
 
    if (rc != SUCCESS)
    {
        sprintf_s(sErrmsg, sizeof sErrmsg, " %s �ɮ׵L�k���� ",sfilename);
        printf("-----IN");
        EWRITE(g_sUserId, rc , sErrmsg);
        exit(1);
    }

    return SUCCESS;

errexit:
  printf("Steven:err[%ld][%s]\n",SQLCODE,sqlca.sqlerrm);
  sprintf_s(g_sMsgBuf, sizeof g_sMsgBuf, "%s",sqlca.sqlerrm);
  return SQLCODE;
}
/*
long car157_get_db()
{
	int rtc;

	if (db_select(g_sDbName) == False) {
		strcpy(g_sMsgBuf,"M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	rtc = getApHome(sApHome);
	if (rtc < 0) {
		strcpy(g_sMsgBuf,"read Config file error!!-->getApHome\n");
		return rtc;
  }
  
  if ((list = get_db_list (&count_db, g_sDbName)) == (char *) 0) {
       if (EWRITE(g_sUserId, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
  }

  return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(g_sUserId,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
*/