/**********************************************************************/
/*   program id   : ca660q01s.ec                                      */
/*   program name : �j��I�«O�O�έp����                            */
/*   date written : 2021/10/21 by 041090                              */
/*   files        :                                                   */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "safeclib.h"
$char dpolicy_bgn_tmp[11],dpolicy_end_tmp[11],dply_begin_tmp[11];
$char dpolicy_bgn[21],dpolicy_end[21],dply_begin[21];

int   count_db,k; 
char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];

DBinfo *list;

main(argc, argv)
int argc;
char **argv;
{
	int rc;

	batchinit();
	strcpy(DBName,          isNULLstr(argv[1]));
	strcpy(userid,          isNULLstr(argv[2]));
	strcpy(dpolicy_bgn_tmp, isNULLstr(argv[3]));
	strcpy(dpolicy_end_tmp, isNULLstr(argv[4]));
	strcpy(dply_begin_tmp,  isNULLstr(argv[5]));
	strcpy(outputf,         isNULLstr(argv[6]));
	
	printf("dpolicy_bgn_tmp[%s] dpolicy_end_tmp[%s] dply_begin_tmp[%s]\n",dpolicy_bgn_tmp,dpolicy_end_tmp,dply_begin_tmp);
	strcpy(dpolicy_bgn,cm_to_infdate(dpolicy_bgn_tmp));
	strcpy(dpolicy_end,cm_to_infdate(dpolicy_end_tmp));
	strcpy(dply_begin,cm_to_infdate(dply_begin_tmp));
	printf("dpolicy_bgn[%s] dpolicy_end[%s] dply_begin[%s]\n",dpolicy_bgn,dpolicy_end,dply_begin);
	
	rc = car660_prepare_data();
	if (rc != M_CM_OK)
		return rc;

	rc = car660_build();
	if (rc != M_CM_OK) 
		return rc;
}

long car660_prepare_data()
{
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == FALSE)
	{
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return FAIL;
	}
		
	$CREATE TEMP TABLE ply_mpure
	(			
		mpure_prem	 decimal(14,4),
		mon_dwritten char(5)
	) with no log;

	$CREATE INDEX ply_mpure_inx ON ply_mpure(mon_dwritten);

	$INSERT INTO ply_mpure 
	 SELECT {+policy_main_k1}b.mpure_prem,(year(b.dwritten)-1911)||lpad(month(b.dwritten),2,'0') AS mon_dwritten
	   FROM policy_main a, policy_main_dtl b
	  WHERE a.ipolicy1 = b.ipolicy1
	    AND a.ipolicy2 = b.ipolicy2
	    AND a.iendorsement = b.iendorsement
	    AND a.insure_type = b.insure_type
	    AND a.insure_class = 'C'
	    AND a.insure_level = 'C1'
	    AND b.insure_instype = '21'
	    AND a.dwritten BETWEEN $dpolicy_bgn AND $dpolicy_end
	    AND a.dins_bgn < $dply_begin;

	$INSERT INTO ply_mpure
 
	 SELECT sum(mpure_prem),'99999'
	   FROM ply_mpure
;

	return M_CM_OK;
	
errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car660_build()
{
	int rc;
	$char sfilename[256],stitle[2048],stmt1[4096];

	$WHENEVER SQLERROR GOTO errexit;
	
	sprintf_s(sfilename, sizeof sfilename,"�j��I�«O�O�έp����\n");
	
	sprintf_s(stitle, sizeof stitle,"ñ��~��\t�«O�O\t");
	
	strcpy(stmt1,"SELECT mon_dwritten::INT,sum(mpure_prem)  "
	             "  FROM ply_mpure  "
	             " GROUP BY 1  "
	             " ORDER BY 1 ASC ");

	rc = unload_file(outputf," ",sfilename,stitle,stmt1);
	$DROP TABLE ply_mpure;	
	
	if (rc != SUCCESS) 
	{
	    sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	printf("done. return M_CM_OK\n");	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;
}
