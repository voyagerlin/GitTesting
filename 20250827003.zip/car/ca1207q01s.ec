/************************************************************************/
/*                                                                      */   
/*   program id   : ca1207q01s.ec                                       */
/*   program name : �z�߶i�ױ������Ҳέp���Ӫ�                          */
/*   date written : 2020/07/22                                          */
/*   author       : neo                                                 */
/************************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "safeclib.h"
/*--------------------------------------------------------------------*/
$char DBName[05],userid[11], ibranch_flag[2] , ibranch[8]  , dbgn[9] , dend[9];

char  msgbuf[2048], sApHome[30], rpt_type[2], getfile[101];
char  v_sMsg[1024], outputf[N_FILE+1];
int   count_db,i;
DBinfo  *list;
FILE    *fp;



/*--------------------------------------------------------------------*/

main(argc,argv)
int  argc;
char **argv;
{  
   
   int rc;
   batchinit();
   strcpy(DBName,   		isNULLstr(argv[1]));
   strcpy(userid,  	 	isNULLstr(argv[2]));
   strcpy(ibranch_flag,    	isNULLstr(argv[3]));  /* ���z�����O */
   strcpy(ibranch,         	isNULLstr(argv[4]));  /* ���z��� */
   strcpy(dbgn,    		isNULLstr(argv[5]));  /* ���z����϶�-�}�l */
   strcpy(dend,     		isNULLstr(argv[6]));  /* ���z����϶�-���� */
   strcpy(outputf,  		isNULLstr(argv[7]));  


   printf("outputf:s\n",outputf);
	printf("--1.car1207_get_db ------ \n");
	rc = car1207_get_db();
	if (rc != M_CM_OK) {
		EWRITE(userid,rc,msgbuf);
		return rc;
	}
	
    
        printf("--2.car1207_init_data ------ \n");
        rc = car1207_init_data();
        if (rc != M_CM_OK) {
            printf("error on car1207_init_data\n");
    		EWRITE(userid,rc,"�إ� temp table ���~!");
    		return rc;
        }
    
        printf("--3.car1207_query_detail ------ \n");
    	rc = car1207_query_detail();
        if (rc != M_CM_OK) {
        printf("error on car1207_query_detail\n");
    		EWRITE(userid, rc, "���̷s�߮׸��X���~");
    		return rc;
    	}
    	 
    	printf("--4.car1207_print_detail ------ \n");
        rc = car1207_print_detail();
        if (rc != M_CM_OK) {
         printf("error on car1207_print_detail\n");
         EWRITE(userid, rc, "���s�������Ӧ��~!");
         return rc;
        }
       
    
			
    return rc;

}
/******************************************************************************/
long car1207_get_db()
{
	int return_code;
	
	$WHENEVER SQLERROR GOTO errexit;

	if (db_select(DBName) == False) {
		strcpy(msgbuf,"��Ʈw�L�k�}��");
		return M_CM_DB_NOTOPEN;
	}

	return_code = getApHome(sApHome);
	if (return_code < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		return return_code;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
	}

	return M_CM_OK;

errexit:
   printf("--car1207_get_db-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
long car1207_init_data()
{   
    $WHENEVER SQLERROR GOTO errexit;

    $create temp table tb_ca12071
    (
		nclaim_center		char(30),				-- �U�z�ߤ��ߦW��
		iclaim_center		char(2),				-- �U���ߥN��
		iunit			char(2),				-- �U���N��
		nunit			char(60),				-- �U���W��
       		iclaim 			char(20),   				-- �z�߮׸�
       		itag 			varchar(12),   				-- ����
       		iadjuster       	char(10),       			-- �g��H�����s
		nadjuster       	char(10),       			-- �g��H���m�W
       		nassured		varchar(120),				-- �Q�O�I�H
		idriver_mail		varchar(50),				-- �r�p�HE-MAIL
		fdriver_mail_type	char(1),				-- �Ŀ����
		ndriver_mail_type	char(10),				-- �Ŀ����W��
		dclaim 			date,    				-- ���z��
		ddriver_mail		varchar(20),				-- �r�p�HMail�o�e��
		tdriver_phone		varchar(20),				-- �r�p�H�q��
		ddriver_phone		varchar(20),       			-- �r�p�H²�T�H�e��
		ddriver_mail_verify     varchar(20),       			-- �r�p�HMail���Ҥ�
		dclose       		date		       			-- �̫�鵲���
		
    )with no log;
	  
    return M_CM_OK;

errexit:
    printf("--car1207_init_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car1207_query_detail()
{
    int	    rc;
    $char   stmt1[4000],stmt2[100],stmt3[2000];
    $int    icnt;
   
    $WHENEVER SQLERROR GOTO errexit;
	
	printf("ibranch_flag : %s \n",ibranch_flag);
	printf("ibranch : %s \n",ibranch);
	printf("dbgn : %s \n",dbgn);
	printf("dend : %s \n",dend);
	 
	if(strcmp(trim(ibranch_flag), "1") == 0 )
		sprintf_s(stmt3,2000 , "and Q.iquota matches '%s' " , ibranch);
   	 else 
		sprintf_s(stmt3,2000 , "and Q.iapp_unit matches '%s' " , ibranch);
		
		printf("stmt2 : %s \n",stmt3);
		
        sprintf_s(stmt1,4000,
           "insert into tb_ca12071 \
            SELECT * FROM (	\
				SELECT CASE WHEN t.ibranch[1,4] ='3602' or t.ibranch[1,4] ='L103' THEN '�x�_�z�ߤ���' \
						    WHEN t.ibranch[1,4] ='3603' or t.ibranch[1,4] ='L105' THEN '��˭]�z�ߤ���' \
						    WHEN t.ibranch[1,4] ='3604' or t.ibranch[1,4] ='L201' THEN '������z�ߤ���' \
						    WHEN t.ibranch[1,4] ='3605' or t.ibranch[1,4] ='L202' THEN '���ūn�z�ߤ���' \
						    WHEN t.ibranch[1,4] ='3606' or t.ibranch[1,4] ='L203' THEN '����̲z�ߤ���' \
						    WHEN t.ibranch[1,4] ='3607' or t.ibranch[1,4] ='L104' THEN '�s�_�z�ߤ���' END nserver , \
				       CASE WHEN o.iquota[1,4] = '3602' or o.iquota[1,4] = 'L103' THEN '00' \
							WHEN o.iquota[1,4] = '3607' or o.iquota[1,4] = 'L104' THEN '22'\
							WHEN o.iquota[1,4] = '3603' or o.iquota[1,4] = 'L105' THEN '33'\
							WHEN o.iquota[1,4] = '3604' or o.iquota[1,4] = 'L201' THEN '40'\
							WHEN o.iquota[1,4] = '3605' or o.iquota[1,4] = 'L202' THEN '66'\
							WHEN o.iquota[1,4] = '3606' or o.iquota[1,4] = 'L203' THEN '70' END iquota, \
				       o.iapp_unit , t.nbranch , p.iclaim , p.itag , p.adjustment , o.nname , p.nassured , v.idriver_mail , v.fdriver_mail_type , \
				       CASE v.fdriver_mail_type WHEN ''  THEN '' \
	        					WHEN 'Y' THEN 'Y.�ݭn���� ' \
	        					WHEN 'N' THEN 'N.�������� ' \
	        					WHEN 'F' THEN 'F.���ҥ��� ' \
	        					WHEN 'S' THEN 'S.���ҧ��� ' \
	        					WHEN 'C' THEN 'C.����H�e ' END ndriver_mail_type , \
	   				Date(p.dclaim) as dclaim , cast(v.ddriver_mail as varchar(20)), \
	   				v.tdriver_phone , cast(v.ddriver_phone as varchar(20)) ,\
	   				cast(v.ddriver_mail_verify as varchar(20)) ,  \
	   				CASE  WHEN p.fclaim_status = '501' THEN Date(p.dclose) ELSE null END dclose   \
				FROM sysdb:ca_clm_process p  , sysdb:ca_verify v , sysdb:ca_ver_relation r  , sysdb:officer o  , sysdb:sa_branch_type t  \
				WHERE p.iclaim = r.iclaim \
				  AND p.iclaim[6,6] = 'V' \
				  AND v.iverify = r.iverify \
				  AND p.adjustment = o.iofficer \
				  AND o.iquota = t.ibranch \
			)Q	\
			WHERE Q.dclaim BETWEEN '%s' AND '%s'  %s ", dbgn , dend , stmt3 );
         
        printf("stmt1=[%s]\n",stmt1);
        $PREPARE pre_A1 FROM $stmt1;
        $EXECUTE pre_A1;
    
     
    return M_CM_OK;
  
errexit:
    printf("--car1207_query_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* ------------------------------------------------------------------------- */
long car1207_print_detail()
{
    int     rc;
    char    sfilename[128],stitle[2048],stmt[2048];
    $int    icnt;

    $WHENEVER SQLERROR GOTO errexit;
    
    strcpy(sfilename,"�z�߶i�ױ������Ҳέp���Ӫ�");
    strcpy(stitle,"�{���N��:CAR12071\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");

    
    icnt = 0;
    $select count(*) into $icnt
      from tb_ca12071;
	  printf("icnt:%d\n",icnt);
    if (icnt == 0) 
    {
        sprintf_s(msgbuf,2048," %s �d�L���, �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return  M_CM_NOT_FOUND;
    }
    
    strcat(stitle,"\t����\t��O\t�z�߮׸�\t����\t�g��H��\t�Q�O�I�H\t�r�p�HE-MAIL\t�Ŀ����\t���z��\t�o�e���Ҥ�\t�r�p�H�q��\t�r�p�H²�T�H�e��\t�������Ҥ�\t�鵲��");

	
    strcpy(stmt,"select   nclaim_center , nunit , iclaim , ''''||itag , nadjuster , nassured , idriver_mail , ndriver_mail_type ,\
                        dclaim , ddriver_mail  , tdriver_phone , ddriver_phone, ddriver_mail_verify  , dclose  \
				 from tb_ca12071 where 1=1   order by iunit asc ");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {

        sprintf_s(msgbuf,2048," %s �ɮ׵L�k���� ",sfilename);

        EWRITE(userid, rc , msgbuf);
        return rc;
    }
    return M_CM_OK;
    
errexit:
    printf("--car1207_print_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

/******************************************************************************/



