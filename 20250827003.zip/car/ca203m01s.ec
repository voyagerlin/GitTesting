/*********************************************************/
/*                                                       */
/*  PROGRAM: ca203m01s.ec                                */
/*                                                       */
/*  Compulsory card barcode print                        */
/*********************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
#include <string.h>
#include <stdlib.h>
#include "safeclib.h"
$include sqlca;

 $char  dreprint[11];
 $int   qreprint;
 $char  DBName[5],type[2],cardbgn[21],cardend[21];
 $char  sitename[20],ipolicy[21],icard[21],card_check[21];
 $char  nassured[122],aassured[92],apayment[92], icar_type[03];
 $char  Tassured1[35],Tassured2[35];
 $char  ncar_abbr[14],iissue_ym[7],itag[CA_TAG_NUM],iengine[CA_ENGINE_NUM],nbrand_abbr[14];
 $char  ibrand[9],ibody[21],dply_begin[14],dply_end[14],ilicense[12];
 $char  ibirth[10],fsex[2],itel[21],pdate[16],bcard1[20];
 $char  fmarriage[2],Iofficer[11],fpt[2],iassured[11];
 $char  Nofficer[13],irelative_ply[21],fcomp_class[3],fcomp_class_last[3];
 $char  bcard2[21],bcard3[21],irelative_card[21];
 $char  ileader[10],Nleader[21],iquery_num[15];
 $char  iscan_no[26];
 static Today;
 static char yy1[4], mm1[3], dd1[3];
 char   s_dpolicy[14];
 char   icard_ipo[2];    /*icar_ipo=Y���O����;icar_ipo=N�L�O����*/
 char   companyid[COMPANY_ID];

 $double qpt;
 $int    qperiod = 0, mpremium = 0;
 $double qcylinder = 0;
 $char   s_qcylinder[9];
 $long   mdamage_cover = 0;
 $char   sWhereTag[27],sWhereEngine[35],sWhereBody[34];
 $char   sWhereLicense[37],sWhereAssured[54];
 $char   buff[250],stmt[1000];
 $int    AZPG;
 
void clear_data();

long car203(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
     long rtncode;
     long car203_single_query();
     char option;

     cm_buf_init(command);
     cm_buf_get("%c",&option);
     switch(option)
     {
     	  case 'C':
               rtncode=car203_icard_count(reply); /* �j���ҥ�� */
               break;
               
     	  case 'M':
               rtncode=car203_no_outside_query(reply); /* �D�~��d�L�� */
               break;
               
          case 'Q':
               rtncode=car203_single_query(reply); /* �ɵo�M�L���X(�p�g�L����) */
               break;
               
          case 'L':
               rtncode=car203_single_query_L(reply); /* �M�L�O�I�Ҹ��α��X(HP-5000) */
               break;
          
          case 'N':
               rtncode=car203_single_query_N(reply); /* �@�목�M�L���X */
               break;
               
          case 'I':
               rtncode=car203_iserial_count(reply); /* �ɵo�Ǹ��Ӽ� + �O�_���i���ɵo��C2/M2 */
               break; 
               
          case '2':
               rtncode=car203_chk_ireceive(reply); /* �ˬd���I��ΤH */
               break;
               
          case '3':
               rtncode=car203_chk_CC(reply); /* �T�{�O�_��CC�d */
               break;      
               
          case 'K':
               rtncode=car203_chk_35(reply); /* �L�q��������ڽT�{ */
               break;         
               
          default :
               if(exitsub(reply,M_CM_WRONG_OPTION) == True)
                   return M_CM_WRONG_OPTION;
               return apiRC;
     }
     return(rtncode);
}
/******************************************************************************/
/* �C�L���X�椧�j���� */
long car203_single_query_L(reply)
serverReply reply;
{
     int    rtn,pos;
     int    tmp_len;
     $long  count_card;
     $char  ichk_num[3];

     cm_buf_get("%s %s %s ",DBName,cardbgn,cardend);

     printf(" car203_single_query_L \n");
     count_card = 0;

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
     {
         if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
         else
            return apiRC;
     }

     rtn = getCompanyId(companyid);
     if (rtn < 0)
     {
         if(exitsub(reply,M_CM_COMPANY_ID_ERR) == True)
            return M_CM_COMPANY_ID_ERR;
         else
            return apiRC;
     }

     $SELECT count(*)
        INTO $count_card
        FROM compulsory_card
       WHERE icard between $cardbgn and $cardend
         AND fstatus in ('0','5','6','7');

     if(count_card == 0)
     {
          if(exitsub(reply,M_CM_NOT_FOUND) == True)
              return M_CM_NOT_FOUND;
          else
              return apiRC;
     }

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l %l ",M_CM_OK,count_card);

     sprintf_s(stmt, sizeof stmt, "SELECT %s FROM %s WHERE %s %s %s ",
                   " icard, ichk_num ",
                   " compulsory_card ",
                   " icard between ? and ? ",
                   "AND fstatus in ('0','5','6','7') ",
                   "ORDER BY icard ");
     printf("car203_single_query_L:stmt[%s]\n",stmt);
     $PREPARE cur_stmtL from $stmt;
     $DECLARE cur_comL CURSOR for cur_stmtL;
     $OPEN    cur_comL USING $cardbgn, $cardend;

     while(1)
     {
         $FETCH cur_comL INTO $icard , $ichk_num;

         printf("card[%s] SQLCODE[%d]\n",icard, SQLCODE);

         if(SQLCODE==SQLNOTFOUND) break;

         strcpy(icard,trim(icard));
         strcpy(ichk_num,trim(ichk_num));

         cm_buf_put ("%s %s %s ", icard, ichk_num, companyid);

     } /* end while */
     $CLOSE cur_comL;
     $FREE  cur_comL;

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     printf("into errexit \n");
     if(exitsub(reply,SQLCODE) == True)
     {
         /* EXEC SQL ROLLBACK WORK; */
         return SQLCODE;
     }
     else
         return apiRC;
}
/******************************************************************************/
/* �@�목�M�L���X (�DC9/M9 + C2/M2(PA*)) */
long car203_single_query_N(reply)
serverReply reply;
{
     $char userid[11],iserial_bgn[8],iserial_end[8],ibranch[4],dpolicy[8],iroute[21];
     $char iquota[7];     
     $char Full_DBName[20];
     $char stmt1[128],stmt_dpolicy[64];
     $int  Serial;
     int   rtn,pos;
     char  flag_tag[2],flag_c2m2[2];
     
     char tmpbuf[4000];
     int count=0, repbuf_len=0, tmp_len=0, replycnt=0;
     int total_count=0;

     cm_buf_get("%s %s %s %s %s",DBName,userid,type,cardbgn,cardend);
     cm_buf_get("%s %s %s %s %s %s %s",iserial_bgn,iserial_end,ibranch,dpolicy,iroute,flag_tag,flag_c2m2);
     printf(" ****************************** \n");
     
     strcpy(cardbgn,trim(cardbgn));
     strcpy(dreprint,cm_edate_str(cm_today()));
     printf("dreprint-1[%s]\n",dreprint);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
     {
         if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
         else
            return apiRC;
     }

     rtn = getCompanyId(companyid);
     if (rtn < 0)
     {
         if(exitsub(reply,M_CM_COMPANY_ID_ERR) == True)
            return M_CM_COMPANY_ID_ERR;
         else
            return apiRC;
     }

     EXEC SQL BEGIN WORK;
     
     if ( flag_c2m2[0] == '1' )  /* C2/M2(PA*�q��) */
     {
     	sprintf_s(stmt1, sizeof stmt1, " AND r.icard[3,4] in ('C2','M2') AND iroute[1,2] = 'PA' AND iroute = '%s' AND r.dply_close >= '01/01/2017'",iroute);
     }
     else /* �DC9/M9�B�ȥ� */
     {
     	sprintf_s(stmt1, sizeof stmt1, " AND r.feply = '0' AND a.ireceive = 'system' "); 
     }
     
     if(strcmp(trim(dpolicy),"*") == 0)
         sprintf_s(stmt_dpolicy, sizeof stmt_dpolicy," ");
     else
     {
     	strcpy(dpolicy,cm_to_infdate(dpolicy));
     	sprintf_s(stmt_dpolicy, sizeof stmt_dpolicy," AND r.dpolicy = '%s' ",dpolicy);
     }

     if ( type[0] == '0' ) /* �O�渹 */
     {    
          sprintf_s(stmt, sizeof stmt, " SELECT ipolicy,icard "
                        " FROM compulsory_card a"
                        " WHERE ipolicy between '%s' and '%s' "
                        " ORDER BY ipolicy ",cardbgn,cardend);
     }
     else /* �O�d�� */
     {     	  
          sprintf_s(stmt, sizeof stmt, " SELECT ipolicy,icard "
                        " FROM compulsory_card "
                        " WHERE icard between '%s' and '%s' "
                        " ORDER BY icard ",cardbgn,cardend);
     }
     printf("stmt-1[%s]\n",stmt);

     clear_data();
     
     $PREPARE Acursora FROM :stmt;
     $DECLARE acur CURSOR FOR Acursora;
     $OPEN acur;
     
     while(1)
     {
     	$FETCH acur INTO $ipolicy, $icard;
     	if(SQLCODE == SQLNOTFOUND) break;
     	strcpy(ipolicy, trim(ipolicy));
     	
     	if (strlen(ipolicy) == 0) 
     	{
     		EXEC SQL ROLLBACK WORK;
     		if(exitsub(reply,M_CA_NOT_PLY) == True)
     		    return M_CA_NOT_PLY;
     		else
     		    return apiRC;
     	}
	    
	strcpy(Full_DBName,get_car_full_db(ipolicy));
	printf("ipolicy[%s]card[%s]SQLCODE[%d]\n",ipolicy,icard,SQLCODE);
	        	    
	if (ipolicy[7] > '9')
	{
	    printf("INTO comp\n");
	    strcpy(companyid,"16");  
	}
	        	        
	sprintf_s(stmt, sizeof stmt, " SELECT p.ipolicy, p.nassured, p.aassured, p.apayment, r.icar_type, "
                    " p.ncar_abbr, "
                    " to_char(p.dissue,'%%Y')::integer - 1911 || '/' || to_char(p.dissue,'%%m'), " 
                    " p.itag, p.iengine, p.nbrand_abbr, "
                    " r.ibrand, p.qcylinder, p.ibody, r.dply_begin, r.dply_end, "
                    " r.qply_period, p.ilicense,  "
                    " to_char(p.dbirth,'%%Y')::integer - 1911 || '/' || to_char(p.dbirth,'%%m/%%d'),  "
                    " p.fsex, p.itel, "
                    " r.dpolicy, r.ilast_card, p.fmarriage, r.mlia_prem, r.iofficer, "
                    " p.fpt, p.qpt , p.iassured , r.irelative_ply, r.fcomp_class , "
                    " r.fcomp_class_last, r.ileader, p.iquery_num, r.iscan_no "
                    " FROM %s:policy p, %s:ply_relation r, OUTER compulsory_card a"
                    " WHERE p.ipolicy = r.ipolicy "
                    " AND a.icard = r.icard " 
                    " AND r.ipolicy = '%s' "
                    " AND r.fprint = '0' "
                    " AND r.ipolicy[1,3] = '%s' "
                    " %s %s",
                    Full_DBName,Full_DBName,ipolicy,ibranch,stmt_dpolicy,stmt1);
                      
        printf("stmt[%s]\n", stmt);
        $PREPARE prep2 from $stmt;
        $EXECUTE prep2 
        INTO $ipolicy, $nassured, $aassured, $apayment, $icar_type,
             $ncar_abbr, $iissue_ym, $itag, $iengine, $nbrand_abbr,
             $ibrand, $qcylinder, $ibody, $dply_begin, $dply_end,
             $qperiod, $ilicense, 
             $ibirth, 
             $fsex, $itel,
             $pdate, $bcard1, $fmarriage, $mpremium, $Iofficer ,
             $fpt, $qpt, $iassured, $irelative_ply, $fcomp_class,
             $fcomp_class_last, $ileader, $iquery_num, $iscan_no;
             
        if(SQLCODE==SQLNOTFOUND)
        {
            strcpy(icard_ipo,"N");
            continue;
        }
        else
        {
            strcpy(icard_ipo,"Y");
            
            /* update�ɦL���Ƥήɶ� */       
            $select nvl(max(qreprint),0)
               into $qreprint
               from compulsory_card
              where icard = $icard;
              
              printf(" [%s]qreprint[%d]\n",icard,qreprint);
              qreprint = qreprint + 1;
              printf(" [%s]qreprint[%d]\n",icard,qreprint);
              
              $UPDATE compulsory_card
                  SET (qreprint , dreprint)
                   = ($qreprint,$dreprint)
                WHERE icard = $icard;
        }
            
        /* �ɵo�C�L�ɡA�L�X�k�H�νs */
        if (strncmp(ilicense," ",1)==0)
            if (strncmp(iassured,"AAAAAAAAAA",10)!=0)
                strcpy(ilicense,iassured);
                
        $FREE prep2;
        
        sprintf_s(stmt, sizeof stmt, "SELECT mdamage_cover "
                    "  FROM %s:ply_ins_type "
                    " WHERE ipolicy= '%s'; ", Full_DBName, ipolicy);
        $PREPARE prep3 from $stmt;
        $EXECUTE prep3 INTO $mdamage_cover;
        
        if (SQLCODE != SQLNOTFOUND)
        {
        	$FREE prep3;
        	if( mdamage_cover == 0)
        	{
        		printf("mdamage_cover in:[%ld]\n",mdamage_cover);
        		EXEC SQL ROLLBACK WORK;
        		if(exitsub(reply,M_CA_CANERD_NRPT) == True)
        		    return M_CA_CANERD_NRPT;
        		else
        		    return apiRC;
        	}
        }
        $FREE prep3;
        printf("mdamage_cover out:[%ld]\n",mdamage_cover);
        printf("select data from policy \n");
        
        $SELECT  nname   /* �g��H����*/
           INTO  $Nofficer
           FROM  officer
          WHERE  iofficer = $Iofficer;
          
        $SELECT  nname   /* �޲z�H����*/
           INTO  $Nleader
           FROM  officer
          WHERE  iofficer = $ileader;
          
        $SELECT  ncode   /* ���ؤ��� */
           INTO  $ncar_abbr
           FROM  car_type
          WHERE  icode = $icar_type AND fclass = '1';
          
          ncar_abbr[8] = '\0';
          printf("---------------->%s",ncar_abbr);
          
          sprintf_s(stmt, sizeof stmt, " SELECT icard "
                         "  FROM %s:ply_relation "
                         " WHERE ipolicy = '%s' ", Full_DBName, irelative_ply);               
          $PREPARE prep4 from $stmt;
          $EXECUTE prep4 INTO $irelative_card;
          $FREE prep4;
          
          sprintf_s(stmt, sizeof stmt, " SELECT ilast_card "
                         "  FROM %s:ply_relation "
                         " WHERE icard= '%s' ", Full_DBName, bcard1);
          $PREPARE prep5 from $stmt;
          $EXECUTE prep5 INTO $bcard2;
          
          if (SQLCODE != SQLNOTFOUND)
          {
          	sprintf_s(stmt, sizeof stmt, " SELECT ilast_card "
                           "  FROM %s:ply_relation"
                           " WHERE icard= '%s' ", Full_DBName, bcard2);
            $PREPARE prep6 from $stmt;
            $EXECUTE prep6 INTO $bcard3;
            $FREE prep6;
           }
           $FREE prep5;
           
           sprintf_s(stmt, sizeof stmt, " UPDATE %s:ply_relation "
                          "   SET fprint = '1'"
                          " WHERE ipolicy= '%s'"
                          "   AND fprint = '0' ", Full_DBName, ipolicy);
           $PREPARE prep6 from $stmt;
           $EXECUTE prep6;
           
           rtoday(&Today);
           strcpy(s_dpolicy,cm_cdate_str_100(Today));
           cm_split_ymd_100(s_dpolicy,yy1,mm1,dd1);
           
           strcpy( nassured , rtrim(nassured));
           strcpy( aassured , rtrim(aassured));
           
           rtn=cc_split_chinese(aassured,Tassured1,34);
           pos=rtn+1;
           
           rtn=cc_split_chinese(substring(aassured,pos,68),Tassured2,34);
           printf("dply_begin[%s] dply_end[%s]\n",dply_begin,dply_end);
           
           strcpy( dply_begin , cm_from_infdate_100(dply_begin));
           strcpy( dply_end ,  cm_from_infdate_100(dply_end));
           
           /* �Y���������ŭ�,�h�L�X������ */
           if(strlen(trim(iengine)) == 0) strcpy(iengine,ibody);
    
           /* �Y��ܤ��L���P,�h���P���M���ť� */
           if (flag_tag[0] == '1') strcpy(itag," ");
           
           if (qcylinder!=0) 
               sprintf_s(s_qcylinder, sizeof s_qcylinder,"%5.2f",qcylinder);
           else
               strcpy(s_qcylinder," ");
           
           
           /**/
	        cm_buf_init(tmpbuf); 
	    	if ( count == 0 )
	     	{
	      	  cm_buf_res_msg();             
	      	  cm_buf_res_count();          
	     	}
			cm_buf_put("%s %s %s %s %s %s %s %s",icard_ipo,icard,irelative_ply,irelative_card,bcard1,nassured,Tassured1,Tassured2);
			cm_buf_put("%s %s %s %s %s %s",ncar_abbr,nbrand_abbr,iissue_ym,itag,iengine,s_qcylinder);
			cm_buf_put("%s %s %s %s %l",dply_begin,dply_end,fcomp_class,fcomp_class_last,qperiod);
			cm_buf_put("%s %s %s %s",ilicense,ibirth,fsex,fmarriage);
			cm_buf_put("%l %s %s %s %s %s",mpremium,Iofficer,Nofficer,yy1,mm1,dd1);
			cm_buf_put("%s %s %s %s %s %s",Nleader,companyid,iquery_num,icar_type,ipolicy,iscan_no);
	        tmp_len = cm_buf_len(tmpbuf);
	    	if ( tmp_len + repbuf_len < 3000 ) 
	    	{
	      	  memcpy(&ReplyBuf[repbuf_len], tmpbuf, tmp_len);
	      	  repbuf_len += tmp_len;
	      	  count++;
	      	}
	      	else                               
	     	{ 
	      	  cm_buf_init(ReplyBuf);
	      	  cm_buf_put_msg(M_CM_OK);
	      	  cm_buf_put_count(count);
	      	  if (SendSyncReply(reply, ReplyBuf, repbuf_len, api_OK)==False)
	      	  {
	      	  	$CLOSE ply_cur;
	      	  	return apiRC;
	      	  }
	      	  else                
	      	  {
	      	  	replycnt++;
	      	  	if (replycnt == 10)
	      	  	{
	      	  		cm_buf_init(ReplyBuf);
	      	  		cm_buf_put("%l", M_CM_OUT_SPACE);
	      	  		tmp_len = cm_buf_len(ReplyBuf);
	      	  		if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
	      	  		    return apiRC;
	      	  		return M_CM_OUT_SPACE; 
	      	  	}
	      	  	ReplyBuf[0] = '\0';
	      	  	count = 0;
			    cm_buf_init(ReplyBuf);
				cm_buf_res_msg();            
				cm_buf_res_count();    
				cm_buf_put("%s %s %s %s %s %s %s %s",icard_ipo,icard,irelative_ply,irelative_card,bcard1,nassured,Tassured1,Tassured2);
				cm_buf_put("%s %s %s %s %s %s",ncar_abbr,nbrand_abbr,iissue_ym,itag,iengine,s_qcylinder);
				cm_buf_put("%s %s %s %s %l",dply_begin,dply_end,fcomp_class,fcomp_class_last,qperiod);
				cm_buf_put("%s %s %s %s",ilicense,ibirth,fsex,fmarriage);
				cm_buf_put("%l %s %s %s %s %s",mpremium,Iofficer,Nofficer,yy1,mm1,dd1);
				cm_buf_put("%s %s %s %s %s %s",Nleader,companyid,iquery_num,icar_type,ipolicy,iscan_no);
			    repbuf_len = cm_buf_len(ReplyBuf);
			    count++;
			  }
	       } /**/
           
           /*count = 4;
           cm_buf_init(ReplyBuf);
           cm_buf_put("%l %l %s %s %s %s %s %s %s %s",M_CM_OK,count,icard_ipo,icard,irelative_ply,irelative_card,bcard1,nassured,Tassured1,Tassured2);
           cm_buf_put("%s %s %s %s %s %l",ncar_abbr,nbrand_abbr,iissue_ym,itag,iengine,qcylinder);
           cm_buf_put("%s %s %s %s %l",dply_begin,dply_end,fcomp_class,fcomp_class_last,qperiod);
           cm_buf_put("%s %s %s %s",ilicense,ibirth,fsex,fmarriage);
           cm_buf_put("%l %s %s %s %s %s",mpremium,Iofficer,Nofficer,yy1,mm1,dd1);
           cm_buf_put("%s %s %s %s %s",Nleader,companyid,iquery_num,icar_type,ipolicy);*/
           
           $SELECT iquota INTO $iquota
           FROM officer WHERE iofficer = $userid;
           
           $INSERT INTO ca_card_log
            (icard,ipolicy,iserial,iquota,icar_type,ireason,nreason,nassured,icreate,dcreate)
           values
            ($icard,$ipolicy,$iserial_bgn,$iquota,$icar_type,'5','',$nassured,$userid,current);
            
           Serial = atoi(iserial_bgn)+1;
           if(strlen(iserial_bgn) == 6)
               sprintf_s(iserial_bgn, sizeof iserial_bgn, "%06d", Serial);
           else
               sprintf_s(iserial_bgn, sizeof iserial_bgn, "%07d", Serial);    		
     }
     $CLOSE acur;
     $FREE acur;
     
     /**/
      EXEC SQL COMMIT WORK;
	  if (count > 0)   /* break out, at least one record is selected */
	  {
	    cm_buf_init(ReplyBuf);
	    cm_buf_put_msg(M_CM_OK);
	    cm_buf_put_count(count);
	    if (SendSyncReply(reply, ReplyBuf, repbuf_len, api_OKComplete)==False)
	      return apiRC;
	    return api_OKComplete;
	  }
	  else            /* break out, not any row is found */
	  {
	   if(exitsub(reply, M_CM_NOT_FOUND) == True) 
	    return M_CM_NOT_FOUND;
	   else  
	    return apiRC;
	  } 
     /**/

     /*EXEC SQL COMMIT WORK;
     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;*/

errexit:
     printf("into errexit \n");
     if(exitsub(reply,SQLCODE) == True)
     {
         EXEC SQL ROLLBACK WORK;
         return SQLCODE;
     }
     else
         return apiRC;
}
/******************************************************************************/
long car203_single_query(reply)
serverReply reply;
{
     char  taipei_db[40];
     $char userid[11], iserial[8], ireason[2], nreason[61], iquota[7];     
     $char Full_DBName[20];
     int   rtn,pos;
     int   tmp_len;
     char  flag_tag[2];

     cm_buf_get("%s %s %s %s %s %s %s %s",DBName,type,cardbgn, userid, iserial, ireason, nreason, flag_tag);
     printf(" ****************************** \n");

     strcpy(dreprint,cm_edate_str(cm_today()));
     printf("dreprint-2[%s]\n",dreprint);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
     {
         if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
         else
            return apiRC;
     }

     printf("ciphers db_select \n");

     rtn = getCompanyId(companyid);
     if (rtn < 0)
     {
         if(exitsub(reply,M_CM_COMPANY_ID_ERR) == True)
            return M_CM_COMPANY_ID_ERR;
         else
            return apiRC;
     }

     EXEC SQL BEGIN WORK;

     if ( type[0] == '0' ) /* �O�渹 */
     {
          sprintf_s(stmt, sizeof stmt, " SELECT ipolicy , icard FROM compulsory_card "
                        " WHERE  ipolicy = ? ORDER BY ipolicy ");

          $select nvl(max(qreprint),0)
             from compulsory_card
            where ipolicy = $cardbgn;

          printf(" qreprint[%d]\n",qreprint);
          qreprint = qreprint + 1;
          printf(" qreprint[%d]\n",qreprint);

          $UPDATE compulsory_card
              SET (qreprint  , dreprint )
                = ($qreprint,$dreprint )
            WHERE ipolicy = $cardbgn;
     }
     else /* �O�d�� */
     {
          sprintf_s(stmt, sizeof stmt, " SELECT ipolicy , icard FROM compulsory_card "
                        " WHERE  icard = ? ORDER BY icard ");

          $select nvl(max(qreprint),0)
             from compulsory_card
            where icard = $cardbgn;

          printf(" qreprint[%d]\n",qreprint);
          qreprint = qreprint + 1;
          printf(" qreprint[%d]\n",qreprint);

          $UPDATE compulsory_card
              SET (qreprint , dreprint)
                = ($qreprint,$dreprint)
            WHERE icard = $cardbgn;
     }

     printf("stmt-2[%s]\n",stmt);

     clear_data();

     $PREPARE cur_stmt1 from $stmt;
     $EXECUTE cur_stmt1 INTO $ipolicy , $icard USING $cardbgn;

     if(SQLCODE==SQLNOTFOUND)
     {
         $FREE cur_stmt1;
         EXEC SQL ROLLBACK WORK;
         if(exitsub(reply,M_CA_NPOLICY) == True)
            return M_CA_NPOLICY;
         else
            return apiRC;
     }
     $FREE cur_stmt1;

     strcpy(ipolicy, trim(ipolicy));
     if (strlen(ipolicy) == 0) 
     {
        EXEC SQL ROLLBACK WORK;
        if(exitsub(reply,M_CA_NOT_PLY) == True)
           return M_CA_NOT_PLY;
        else
           return apiRC;
     }
     	
     strcpy(Full_DBName,get_car_full_db(ipolicy));

     printf("policy[%s] card[%s] SQLCODE[%d]\n",ipolicy , icard, SQLCODE);

     printf("ABC\n");
     printf("ABC1 ipolicy[%s]\n",ipolicy);

     if (ipolicy[7] > '9')
     {
        printf("INTO comp\n");
        strcpy(companyid,"16");  
     }

     sprintf_s(stmt, sizeof stmt, "SELECT p.ipolicy, p.nassured, p.aassured, p.apayment, r.icar_type, "
                    " p.ncar_abbr, "
                    " to_char(p.dissue,'%%Y')::integer - 1911 || '/' || to_char(p.dissue,'%%m'), " 
                    " p.itag, p.iengine, p.nbrand_abbr, "
                    " r.ibrand, p.qcylinder, p.ibody, r.dply_begin, r.dply_end, "
                    " r.qply_period, p.ilicense,  "
                    " to_char(p.dbirth,'%%Y')::integer - 1911 || '/' || to_char(p.dbirth,'%%m/%%d'),  "
                    " p.fsex, p.itel, "
                    " r.dpolicy, r.ilast_card, p.fmarriage, r.mlia_prem, r.iofficer, "
                    " p.fpt, p.qpt , p.iassured , r.irelative_ply, r.fcomp_class , "
                    " r.fcomp_class_last, r.ileader, p.iquery_num, r.iscan_no "
                    " FROM %s:policy p, %s:ply_relation r "
                    " WHERE p.ipolicy = r.ipolicy "
                      " AND r.ipolicy = '%s'; ", Full_DBName, Full_DBName, ipolicy);
     printf("stmt[%s]\n", stmt);
     $PREPARE prep2 from $stmt;
     $EXECUTE prep2 
        INTO $ipolicy, $nassured, $aassured, $apayment, $icar_type,
             $ncar_abbr, $iissue_ym, $itag, $iengine, $nbrand_abbr,
             $ibrand, $qcylinder, $ibody, $dply_begin, $dply_end,
             $qperiod, $ilicense, 
             $ibirth, 
             $fsex, $itel,
             $pdate, $bcard1, $fmarriage, $mpremium, $Iofficer ,
             $fpt, $qpt, $iassured, $irelative_ply, $fcomp_class,
             $fcomp_class_last, $ileader, $iquery_num, $iscan_no;

     if(SQLCODE==SQLNOTFOUND)
          strcpy(icard_ipo,"N");
     else
          strcpy(icard_ipo,"Y");
     
     /*1061120004_C1 �ɵo�C�L�ɡA�L�X�k�H�νs*/     
     if (strncmp(ilicense," ",1)==0)
         if (strncmp(iassured,"AAAAAAAAAA",10)!=0)
             strcpy(ilicense,iassured);
          
     $FREE prep2;

     sprintf_s(stmt, sizeof stmt, "SELECT mdamage_cover "
                    "  FROM %s:ply_ins_type "
                    " WHERE ipolicy= '%s'; ", Full_DBName, ipolicy);
     $PREPARE prep3 from $stmt;
     $EXECUTE prep3 INTO $mdamage_cover;
     if (SQLCODE != SQLNOTFOUND)
     {
         $FREE prep3;
         if( mdamage_cover == 0)
         {
              printf("mdamage_cover in:[%ld]\n",mdamage_cover);
              EXEC SQL ROLLBACK WORK;
              if(exitsub(reply,M_CA_CANERD_NRPT) == True)
                  return M_CA_CANERD_NRPT;
              else
                  return apiRC;
         }
     }
     $FREE prep3;
     printf("mdamage_cover out:[%ld]\n",mdamage_cover);
     printf("select data from policy \n");

     $SELECT  nname   /* �g��H����*/
        INTO  $Nofficer
        FROM  officer
       WHERE  iofficer = $Iofficer;

     $SELECT  nname   /* �޲z�H����*/
        INTO  $Nleader
        FROM  officer
       WHERE  iofficer = $ileader;

     $SELECT  ncode   /* ���ؤ��� */
        INTO  $ncar_abbr
        FROM  car_type
       WHERE  icode = $icar_type AND fclass = '1';

      ncar_abbr[8] = '\0';
      rintf("---------------->%s",ncar_abbr);

      sprintf_s(stmt, sizeof stmt, "SELECT icard "
                     "  FROM %s:ply_relation "
                     " WHERE ipolicy = '%s'", Full_DBName, irelative_ply);

     $PREPARE prep4 from $stmt;
     $EXECUTE prep4 INTO $irelative_card;
     $FREE prep4;

     sprintf_s(stmt, sizeof stmt, "SELECT ilast_card "
                    "  FROM %s:ply_relation "
                    " WHERE icard= '%s'", Full_DBName, bcard1);
     $PREPARE prep5 from $stmt;
     $EXECUTE prep5 INTO $bcard2;

     if (SQLCODE != SQLNOTFOUND)
     {
        sprintf_s(stmt, sizeof stmt, "SELECT ilast_card "
                       "  FROM %s:ply_relation"
                       " WHERE icard= '%s'", Full_DBName, bcard2);
        $PREPARE prep6 from $stmt;
        $EXECUTE prep6 INTO $bcard3;
        $FREE prep6;
     }
     $FREE prep5;

     sprintf_s(stmt, sizeof stmt, "UPDATE %s:ply_relation "
                    "   SET fprint = '1'"
                    " WHERE ipolicy= '%s'"
                    "   AND fprint = '0'; ", Full_DBName, ipolicy);
     $PREPARE prep6 from $stmt;
     $EXECUTE prep6;

     rtoday(&Today);
     strcpy(s_dpolicy,cm_cdate_str_100(Today));
     cm_split_ymd_100(s_dpolicy,yy1,mm1,dd1);

     strcpy( nassured , rtrim(nassured));
     strcpy( aassured , rtrim(aassured));

     rtn=cc_split_chinese(aassured,Tassured1,34);
     pos=rtn+1;

     rtn=cc_split_chinese(substring(aassured,pos,68),Tassured2,34);

     printf("dply_begin[%s] dply_end[%s]\n",dply_begin,dply_end);

     strcpy( dply_begin , cm_from_infdate_100(dply_begin));
     strcpy( dply_end ,  cm_from_infdate_100(dply_end));
     
     /* car9711072 �Y���������ŭ�,�h�L�X������ */
     if(strlen(trim(iengine)) == 0) strcpy(iengine,ibody);
     
     /* car9901133 �Y��ܤ��L���P,�h���P���M���ť� */
     if (flag_tag[0] == '1') strcpy(itag," ");
     
     if (qcylinder!=0) 
         sprintf_s(s_qcylinder, sizeof s_qcylinder,"%5.2f",qcylinder);
     else
         strcpy(s_qcylinder," ");     

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l %s %s %s %s %s %s %s %s",M_CM_OK,icard_ipo,icard,irelative_ply,irelative_card,
                 bcard1,nassured,Tassured1,Tassured2);
     cm_buf_put("%s %s %s %s %s %s",ncar_abbr,nbrand_abbr,iissue_ym,itag,iengine,
                 s_qcylinder);
     cm_buf_put("%s %s %s %s %l",dply_begin,dply_end,fcomp_class,fcomp_class_last,qperiod);
     cm_buf_put("%s %s %s %s",ilicense,ibirth,fsex,fmarriage);
     cm_buf_put("%l %s %s %s %s %s",mpremium,Iofficer,Nofficer,yy1,mm1,dd1);
     cm_buf_put("%s %s %s %s %s %s",Nleader,companyid,iquery_num,icar_type,ipolicy,iscan_no);

     $SELECT iquota 
        INTO $iquota
        FROM officer WHERE iofficer = $userid;

     $INSERT INTO ca_card_log (icard, ipolicy, iserial, iquota, icar_type, ireason, nreason, nassured, icreate)
                       values ($icard, $ipolicy, $iserial, $iquota, $icar_type, $ireason, $nreason, $nassured, $userid);

     EXEC SQL COMMIT WORK;
     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     printf("into errexit \n");
     if(exitsub(reply,SQLCODE) == True)
     {
         EXEC SQL ROLLBACK WORK;
         return SQLCODE;
     }
     else
         return apiRC;
}
/******************************************************************************/
long car203_no_outside_query(reply)
serverReply reply;
{
    int count, checkErr_cnt, repbuf_len,tmp_len,replycnt, ttlen;
    int rc;
    char tmpbuf[4000];
    $char stmt[4096];
    /* Query Condition */
    $char dentry_bgn[11], dentry_end[11], ipolicy3[4], ileader[11], ientry[11];
    $char iquota[8], ipolicy_bgn[21], ipolicy_end[21], car_kind[2];
    /**************************************************************************/
    $char sIpolicy[21], sItmp_policy[21], sItag[CA_TAG_NUM], sDply_bgn[11],sDply_end[11];
    $char sDentry[11], sIofficer[11], sNofficer[11], sNleader[11], sIquota[8];
    $char sIcomm_obj[11], sIroute[21], sIroute_prop[3];
    $varchar sNassured[120];
   
    $char ftype_sp[3], deffect4[11], deffect4_edr[10], err_flag[2], payStatus[7];
    $char remark[512], Condition1[64], Condition2[64];
    $char fstatus[3];
    $int  count_receive, count_pass, sMprem = 0;
    $long sToday, sLdeffect4;
    $int  iTmp, jTmp;
    
    cm_buf_get("%s %s %s %s", DBName, dentry_bgn, dentry_end, ipolicy3);
    cm_buf_get("%s %s %s %s %s", iquota, ileader, ientry, ipolicy_bgn, ipolicy_end);
    cm_buf_get("%s", car_kind);

    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False)
    {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True) return M_CM_DB_NOTOPEN;
        else return apiRC;
    }
    
    strcpy(car_kind, trim(car_kind));
    if (strcmp(car_kind, "0") == 0)
        strcpy(Condition1, " AND icar_type IN ('01','02','32','34','35') ");
    else
        strcpy(Condition1, " AND icar_type NOT IN ('01','02','32','34','35') ");
    
    strcpy(ipolicy_bgn, trim(ipolicy_bgn));
    if (strcmp(ipolicy_bgn, "*") != 0)
        sprintf_s(Condition2, sizeof Condition2, " AND ipolicy >= '%s' AND ipolicy <= '%s'"
                          , ipolicy_bgn, ipolicy_end);
    else
    	  strcpy(Condition2, " ");
    
    count = ttlen = repbuf_len = tmp_len = replycnt = 0;
    
    cm_buf_init(ReplyBuf);
    cm_buf_res_msg();  /* reserve for MsgCode and count */
    cm_buf_res_count();
    
    $WHENEVER ERROR CONTINUE;
    $DROP TABLE tmp_ply_relation;
    $WHENEVER SQLERROR GOTO errexit;
    
	  sprintf_s(stmt, sizeof stmt,
	          "SELECT ipolicy, itmp_policy, dply_begin, dply_end, dentry, iofficer, ileader,"
	          "      (mlia_prem+mdmg_prem) mprem, iquota, icomm_obj "
		  "  FROM ply_relation "
		  " WHERE ipolicy = icard "
		  "   AND ibig_comp = ' ' "
		  "   AND dentry >= '%s' "
		  "   AND dentry <= '%s' "
		  "   AND ipolicy[1,3] matches '%s' "
		  "   AND iquota matches '%s' "
		  "   AND ileader matches '%s' "
		  "   AND ientry matches '%s'  "
		  "   %s %s "
		  "INTO temp tmp_ply_relation WITH NO log;"
		 	      , dentry_bgn, dentry_end, ipolicy3, iquota, ileader, ientry, Condition1, Condition2);
printf("stmt[%s]\n",stmt);

	  $EXECUTE IMMEDIATE $stmt;
    
	  sprintf_s(stmt, sizeof stmt, 
	          "SELECT a.ipolicy, b.itmp_policy, a.nassured, a.itag, b.dply_begin,"
	          "       b.dply_end, b.dentry, b.iofficer, "
	          "       NVL((SELECT nname FROM officer WHERE iofficer = b.iofficer), ''), "
	          "       NVL((SELECT nname FROM officer WHERE iofficer = b.ileader), ''), "
	          "       b.mprem, b.iquota, b.icomm_obj, "
	          "       a.iroute, a.iroute_prop  "
		 	      "  FROM policy a, tmp_ply_relation b "
		 	      " WHERE a.ipolicy = b.ipolicy "
		 	      " ORDER BY b.dply_begin DESC;");
printf("stmt[%s]\n",stmt);

    $PREPARE ca_card FROM $stmt;
    $DECLARE no_outside_cur CURSOR FOR ca_card;
    $OPEN no_outside_cur;
    for(;;)
    {
        $FETCH no_outside_cur INTO $sIpolicy, $sItmp_policy, $sNassured, $sItag,  
                                   $sDply_bgn, $sDply_end, $sDentry, $sIofficer,
                                   $sNofficer, $sNleader, $sMprem, $sIquota,
                                   $sIcomm_obj, $sIroute, $sIroute_prop;
        if(SQLCODE == SQLNOTFOUND) break;
        
        checkErr_cnt = 0;
        strcpy(remark, "");
        /* �ˮ�(�@)�g��N���O�_���� */
        if( sIofficer[0] != 'W')
        {
            rc = cm_chk_policy("1", sIofficer, " ", " ", " ", " ", " ", " ");
            if( rc != M_CM_OK)
            {
            	  checkErr_cnt++;
                strcpy(remark, cm_get_errmsg(rc));
            }
        }
        /* �ˮ�(�G)�~�Z���O�_���� */
        rc = cm_chk_policy("2", " ", " ", sIquota, " ", " ", " ", " ");
        if( rc != M_CM_OK)
        {
            checkErr_cnt++;
            strcpy(remark, trim(remark));
            if (strlen(remark) != 0)
            {
               strcat(remark, ";");
               strcat(remark, cm_get_errmsg(rc));
            }
            else
            {
               strcpy(remark, cm_get_errmsg(rc));
            }
        }
        /* �ˮ�(�T)�I����H�O�_����X�� */
        rc = cm_chk_policy("4", " ", " ", " ", sIcomm_obj, " ", " ", " ");
        if( rc != M_CM_OK)
        {
            checkErr_cnt++;
            strcpy(remark, trim(remark));
            if (strlen(remark) != 0)
            {
               strcat(remark, ";");
               strcat(remark, cm_get_errmsg(rc));
            }
            else
            {
            strcpy(remark, cm_get_errmsg(rc));
            }
        }
        /* �ˮ�(�|)�I����H���L�X���� */
        rc = cm_chk_policy("6", " ", " ", " ", sIcomm_obj, "C", " ", " ");
        if( rc != M_CM_OK)
        {
            checkErr_cnt++;
            strcpy(remark, trim(remark));
            if (strlen(remark) != 0)
            {
               strcat(remark, ";");
               strcat(remark, cm_get_errmsg(rc));
            }
            else
            {
               strcpy(remark, cm_get_errmsg(rc));
            }
        }
        /* �ˮ�(��)�q���N���P�q���ۭq�~�ȥN���������Y�O�_���T */
        rc = cm_chk_policy("7", " ", " ", " ", " ", " ", sIroute, sIroute_prop);
        if( rc != M_CM_OK)
        {
            checkErr_cnt++;
            strcpy(remark, trim(remark));
            if (strlen(remark) != 0)
            {
               strcat(remark, ";");
               strcat(remark, cm_get_errmsg(rc));
            }
            else
            {
               strcpy(remark, cm_get_errmsg(rc));
            }
        }
			  	      
			  /* �P�_�O�_�w���O */
			  count_pass = 0;
        $SELECT count(ipre_rcv) INTO $count_pass
			     FROM ao_prercv_pass
			    WHERE iins_cat  = 'C'
			      AND ipre_rcv  = $sItmp_policy
			      AND iins_kind = '1' 
			      AND ipre_end  = ' ';
			  
			  if (count_pass > 0)
			     strcpy(payStatus, "�w���O");
			  else
			     strcpy(payStatus, "�����O");
      
        /* �ˮ�(��)�O�_�s�b�@�γ������� */
        count_receive = 0;
        strcpy(ftype_sp, "");
        $SELECT ftype_sp,fstatus, count(ftype_sp)
           INTO $ftype_sp,$fstatus, $count_receive
           FROM cm_pre_receive
          WHERE iins_cat = 'C'
            AND ipre_rcv = $sItmp_policy
            AND iins_kind = '1'
            AND ipre_end = ' '
          GROUP BY ftype_sp,fstatus;
          
          strcpy(fstatus, trim(fstatus));
        if (count_receive > 0)
        {
        	/* 1060106005_C1 �ץ����s�t�ΥX��@�~(�p�P�N�����榬�O�@�o�ɻݦP�ɨ����i�X��@�~) */
         	if (strcmp(fstatus, "90") == 0)
	        {
	        	checkErr_cnt++;
                strcat(remark, ";");
                strcat(remark, "�@�γ�����w�@�o");
	        }
	        else
	        {
	        	/* �O�����O=[PA] */
	            strcpy(ftype_sp, trim(ftype_sp));
	            if (strcmp(ftype_sp, "PA") == 0)
	            {       
				    if (count_pass == 0)
				    {
	                    /* �ư��O�����O=[PA]�����O*/
	                    printf("***** ipolicy[%s]�G[PA]�����O ***** \n", ipolicy);
	                    continue;
	                }
	            }
            }
        }
        else
        {

        	  /* errmsg: �@�γ������ɵL�O���� */
            checkErr_cnt++;
            strcpy(remark, trim(remark));
            if (strlen(remark) != 0)
            {
                strcat(remark, ";");
                strcat(remark, "�@�γ������ɵL�O����");
            }
            else
            {
                strcpy(remark, "�@�γ������ɵL�O����");
            }
        }
        
        /* �ˮ�(�C)�O�_�O�� (�t�Τ� > �ͮĤ�+�|�Ӥu�@��) */
        sToday = 0;
			  sLdeffect4 = 0;
			  strcpy(deffect4_edr, "");
        
        /* �ͮĤ�+ �|�Ӥu�@�� */
        /*
        strcpy(deffect4, "");
			  $SELECT skip 3 first 1 dwork
			     INTO $deffect4
			     FROM cm_wrktbl
			    WHERE dwork > $sDply_bgn
			      AND fwork = '0';*/
			      
		jTmp = 0;
 		for(iTmp=1;jTmp<=4;iTmp++)
 		{
     		$select 1 
        	   from ca_holiday
       		  where (date($sDply_bgn) + $iTmp) between holiday_bgn and holiday_end;
       		  
     		if( SQLCODE == SQLNOTFOUND) jTmp++;
     		
     		printf("iTmp[%d,jTmp[%d]\n", iTmp, jTmp);
     		
     		if( jTmp == 4 ) break;

		}
 		$select first 1 to_char(date($sDply_bgn) + $iTmp) into $deffect4 from ca_holiday;

		strcpy(deffect4_edr, cm_from_infdate_100(deffect4));
	    sLdeffect4 = cm_ymd_cdate(deffect4_edr);
		sToday = cm_today( ); /* �t�Τ� */
		printf("***** Today[%ld], Deffect4[%ld]*****\n", sToday, sLdeffect4);
		/* �i�t�Τ� > �ͮĤ�+�|�Ӥu�@�ѡj(�O����)*/
		if (sToday > sLdeffect4)
		{
		    checkErr_cnt++;
        	strcpy(remark, trim(remark));
        	if (strlen(remark) != 0)
        	{
            	strcat(remark, ";");
            	strcat(remark, "�O����");
        	}
        	else
        	{
            	strcpy(remark, "�O����");
        	}
		}     

        /* err_flag�G[0]�ˮ֨S���D!, [1]�ˮ֦��~! */
     	strcpy(err_flag, "");
     	if (checkErr_cnt > 0)
     	    strcpy(err_flag, "1");
     	else
     	    strcpy(err_flag, "0");
     	  	  
     	count++;
    	cm_buf_put("%s %s %s %s %s %s", sIpolicy, sItmp_policy, sNassured,sItag, 
    	                                  sDply_bgn, sDply_end);
        cm_buf_put("%s %s %s %s %d %s %s",sDentry, sIofficer, sNofficer, 
                                         sNleader, sMprem, deffect4, remark);
        cm_buf_put("%s %s", payStatus, err_flag);
        tmp_len = cm_buf_len(ReplyBuf);
    	if (tmp_len > 39000)
        {   /* if data length >= 3K/4K, then multiple send */
            cm_buf_put_msg(M_CM_OK);
            cm_buf_put_count(count);
            if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OK)==False)
            {
                $CLOSE no_outside_cur;
                $FREE  no_outside_cur;
                return apiRC;
            }
            ttlen=ttlen+tmp_len;
            /*count=0;*/
            cm_buf_init(ReplyBuf);
            cm_buf_res_msg();           /* reserve for msg_code and count */
            cm_buf_res_count();
        }
        if (ttlen+tmp_len>=300000)
        {                               /* if data length > 30K */
            $CLOSE no_outside_cur;
            $FREE  no_outside_cur;          
            cm_buf_init(ReplyBuf);
            cm_buf_put("%l",M_CM_OUT_SPACE);
            cm_buf_put_count(count);
            if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                return apiRC;
            return M_CM_OUT_SPACE; 
        }
    }
    $CLOSE no_outside_cur;
    $FREE  no_outside_cur;
    
    $drop table tmp_ply_relation;
        
    if(count > 0)
    {
    	cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK); /* remained data */
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
          return apiRC;
      return api_OKComplete;
    } 
    else
    {
      if(exitsub(reply,M_CM_NOT_FOUND) == True) 
          return M_CM_NOT_FOUND;
      else  
          return apiRC;
    }

errexit:
    printf("<car203_no_outside_query> sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    if(exitsub(reply,SQLCODE) == True)  return SQLCODE;
    else return apiRC;
}
/******************************************************************************/
long car203_icard_count(reply)
serverReply reply;
{
     $char DBName[5];
     $char icard_begin[21], icard_end[21], fstatus[2], sIbranch[3], ibranch[3];
     $char sStmt[256];
     $int count_card, count_err, ibranch_flag;

     int  tmp_len;

     cm_buf_get("%s %s %s %s", DBName, icard_begin, icard_end, sIbranch);

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if (db_select (DBName) == False)
     {
         if (exitsub (reply, M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
         else
            return apiRC;
     }
     
     strcpy(icard_begin , trim(icard_begin));
     strcpy(icard_end   , trim(icard_end));
     strcpy(sIbranch    , trim(sIbranch));

     count_card = count_err = ibranch_flag = 0;

     sprintf_s(sStmt, sizeof sStmt, " SELECT fstatus FROM compulsory_card "
                       "WHERE icard >= '%s' AND icard <= '%s';",icard_begin,icard_end);
                       
     $PREPARE card_cur FROM $sStmt;
     $DECLARE comp_cur CURSOR FOR card_cur;
     $OPEN comp_cur;
     
     for(;;)
     {
         $FETCH comp_cur INTO $fstatus;
         if (SQLCODE == SQLNOTFOUND) break;
         
         strcpy(fstatus, trim(fstatus));
         if (strcmp(fstatus, "0") == 0)
             count_card++;
         else
             count_err++;
     }
     $CLOSE comp_cur;
	 $FREE  comp_cur; 
	 
	 /*1061120006_C1 ���O�P�ӻ��줣�P�ɡA�s�W���ܰT��*/
	 sprintf_s(sStmt, sizeof sStmt, " SELECT iissue_branch "
	                " FROM compulsory_card "
	                " WHERE icard >= '%s' AND icard <= '%s' "
	                " AND fstatus = '0' "
	                " GROUP BY 1 ", icard_begin, icard_end);
                       
     $PREPARE branch_cur FROM $sStmt;
     $DECLARE count_cur CURSOR FOR branch_cur;
     $OPEN count_cur;
     
     for(;;)
     {
         $FETCH count_cur INTO $ibranch;
         if (SQLCODE == SQLNOTFOUND) break;
         
         strcpy(ibranch, trim(ibranch));
         if (strcmp(sIbranch, ibranch) != 0)
             ibranch_flag++;
     }
     $CLOSE count_cur;
	 $FREE  count_cur;

     printf("###### print card [%d], error card \n", count_card, count_err);
     printf("ibranch_flag[%d] \n", ibranch_flag);

     cm_buf_init (ReplyBuf);
     cm_buf_put ("%l %d %d %d", M_CM_OK, count_card, ibranch_flag, count_err);

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply (reply, ReplyBuf, tmp_len, api_OKComplete) == False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     printf("<car203_icard_count> sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
     if (exitsub (reply, SQLCODE) == True)
        return SQLCODE;
     else
        return apiRC;
}
/******************************************************************************/
long car203_iserial_count(reply)
serverReply reply;
{
     $char DBName[5];
     $char flag[2],bgn[21],end[21],ibranch[4],dpolicy[7],ipolicy[21],iroute[21];
     $char stmt[1024],stmt1[128],stmt_dpolicy[64];
     $int count,count_card,flag_c2m2;
     int count_db,k;
     $char userid[11];
     
     DBinfo *list;

     int  tmp_len;

     cm_buf_get("%s %s %s %s %s %s %s",DBName,flag,bgn,end,ibranch,dpolicy,iroute);

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if (db_select (DBName) == False)
     {
         if (exitsub (reply, M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
         else
            return apiRC;
     }
     if ((list = get_db_list (&count_db, DBName)) == (char *) 0) 
     {
     	if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
		else
		    return apiRC;
	}
     
     strcpy(bgn,trim(bgn));
     strcpy(end,trim(end));
     strcpy(ibranch,trim(ibranch));

     count = count_card = flag_c2m2 = 0;
     
     if(strcmp(trim(dpolicy),"*") == 0)
     {
	 sprintf_s(stmt_dpolicy, sizeof stmt_dpolicy," ");
     }
     else
     {
	 printf("dpolicy[%s]\n",dpolicy);
	 strcpy(dpolicy,cm_to_infdate(dpolicy));
	 printf("dpolicy[%s]\n",dpolicy);
	 sprintf_s(stmt_dpolicy, sizeof stmt_dpolicy," AND dpolicy = '%s' ",dpolicy);
     }
    
     if ( flag[0] == '0' ) /* �O�渹 */    
         sprintf_s(stmt1, sizeof stmt1, " AND a.ipolicy between '%s' and '%s' ",bgn,end);
     else /* �O�d�� */
         sprintf_s(stmt1, sizeof stmt1," AND a.icard between '%s' and '%s' ",bgn,end); 	      
      
     /** �P�_�O�_���i���ɵo��C2/M2 **/
     for(k=0;k<count_db;k++)
     {
     	sprintf_s(stmt, sizeof stmt, " SELECT count(*) "
                       "   FROM %s:ply_relation a, %s:policy b "
                       "  WHERE a.ipolicy = b.ipolicy AND a.fprint = '0' "
                       "    AND (a.icard[3,4] = 'C2' OR a.icard[3,4] = 'M2') "
                       "    AND b.iroute = '%s' "
                       "    AND iroute[1,2] = 'PA' "
                       "    AND a.ipolicy[1,3] = '%s' "
                       " %s %s ",list[k].dbname,list[k].dbname,iroute,ibranch,stmt1,stmt_dpolicy);
            
        printf("stmt[%s]\n", stmt);
        $PREPARE count1 FROM $stmt;
        $EXECUTE count1 INTO $count;
            
        count_card = count_card + count; 
     }
     
     if (count_card > 0) 
        flag_c2m2 = 1;     
     else
     {
     	for(k=0;k<count_db;k++)
     	{
     	    sprintf_s(stmt, sizeof stmt, " SELECT count(*) "
                           "   FROM %s:ply_relation a "
                           "  WHERE fprint = '0' "
                           "    AND feply = '0'  "
                           "    AND ipolicy[1,3] = '%s' "
                           " %s %s ",list[k].dbname,ibranch,stmt1,stmt_dpolicy);
            printf("stmt[%s]\n", stmt);
            $PREPARE count_cur FROM $stmt;
            $EXECUTE count_cur INTO $count;
            
            count_card = count_card + count; 
        }
     }              
        
        printf("######count_card[%d]flag_c2m2[%d]\n",count_card,flag_c2m2);
        
        cm_buf_init (ReplyBuf);
        cm_buf_put ("%l %d %d ", M_CM_OK,count_card,flag_c2m2);
        
        tmp_len = cm_buf_len(ReplyBuf);
        if (SendSyncReply (reply, ReplyBuf, tmp_len, api_OKComplete) == False)
            return apiRC;
        else
            return api_OKComplete;

errexit:
     printf("<car203_icard_count> sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
     if (exitsub (reply, SQLCODE) == True)
        return SQLCODE;
     else
        return apiRC;
}
/******************************************************************************/
long car203_chk_ireceive(reply)
serverReply reply;
{
     $char DBName[5],userid[11];
     $char flag[2],bgn[21],end[21];
     $char stmt[1024];
     $int count, cnt;
     int count_db,k;
     
     DBinfo *list;

     int  tmp_len;

     cm_buf_get("%s %s %s %s",DBName,flag,bgn,end);

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if (db_select (DBName) == False)
     {
         if (exitsub (reply, M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
         else
            return apiRC;
     }
     if ((list = get_db_list (&count_db, DBName)) == (char *) 0) 
     {
     	if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
     	    return M_CM_NOT_DBLIST;
	else
	    return apiRC;
     }
     
     strcpy(bgn,trim(bgn));
     strcpy(end,trim(end));
     count = cnt = 0;
    
     if ( flag[0] == '1' )  /* �O�d�� */
     {
     	$SELECT count(*) 
     	   INTO $count
     	   FROM compulsory_card 
     	  WHERE icard between $bgn and $end
     	  AND ireceive = 'system';
     }    
     else /* �O�渹 */
     {
     	for(k=0;k<count_db;k++)
     	{
     	    sprintf_s(stmt, sizeof stmt, " SELECT count(*) "
                          "   FROM %s:ply_relation a, compulsory_card b  "
                          "  WHERE a.icard = b.icard "
                          "    AND b.ireceive = 'system' "
                          "    AND a.ipolicy BETWEEN '%s' AND '%s' ", list[k].dbname,bgn,end);
            
            $PREPARE cntA FROM $stmt;
            $EXECUTE cntA INTO $cnt;
            count = count + cnt;
        }	 
     }  
     
     cm_buf_init (ReplyBuf);
     cm_buf_put ("%l %d",M_CM_OK,count);
     
     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply (reply, ReplyBuf, tmp_len, api_OKComplete) == False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     printf("<car203_chk_ireceive> sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
     if (exitsub (reply, SQLCODE) == True)
        return SQLCODE;
     else
        return apiRC;
}
/******************************************************************************/
long car203_chk_CC(reply)
serverReply reply;
{
     $char DBName[5],userid[11];
     $char flag[2],bgn[21],end[21];
     $char stmt[1024],stmt1[64];
     $int count, cnt;
     int count_db,k;
     
     DBinfo *list;

     int  tmp_len;

     cm_buf_get("%s %s %s %s",DBName,flag,bgn,end);

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if (db_select (DBName) == False)
     {
         if (exitsub (reply, M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
         else
            return apiRC;
     }
     if ((list = get_db_list (&count_db, DBName)) == (char *) 0) 
     {
     	if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
     	    return M_CM_NOT_DBLIST;
	else
	    return apiRC;
     }
     
     strcpy(bgn,trim(bgn));
     strcpy(end,trim(end));
     count = 0;
    
     if ( flag[0] == '1' )  /* �O�d�� */
     	sprintf_s(stmt1, sizeof stmt1, "AND icard between '%s' and '%s' ",bgn,end);    
     else /* �O�渹 */
     	sprintf_s(stmt1, sizeof stmt1, "AND ipolicy between '%s' and '%s' ",bgn,end); 
     
     for(k=0;k<count_db;k++)
     {
     	sprintf_s(stmt, sizeof stmt, " SELECT count(*) "
     	"   FROM %s:ply_relation "
     	"  WHERE icard = ipolicy %s ", list[k].dbname,stmt1);
     	
     	$PREPARE cntA FROM $stmt;
     	$EXECUTE cntA INTO $cnt;
     	count = count + cnt;
     }
     
     cm_buf_init (ReplyBuf);
     cm_buf_put ("%l %d",M_CM_OK,count);
     
     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply (reply, ReplyBuf, tmp_len, api_OKComplete) == False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     printf("<car203_chk_CC> sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
     if (exitsub (reply, SQLCODE) == True)
        return SQLCODE;
     else
        return apiRC;
}

long car203_chk_35(reply)
serverReply reply;
{
	$char   DBName[5],userid[11];
	$char   ftype[2],ibegin[21];
	$char   stmt_x[1024],stmp_x[100];
	$int   chk_35 = 0,chk_35_tmp = 0;
	$int   count, cnt;
    int    count_db,k;
	int    tmp_len;
	DBinfo *list;
	
	cm_buf_get("%s %s %s", DBName, ftype, ibegin);
	
	EXEC SQL WHENEVER SQLERROR GOTO errexit;
	
	if (db_select (DBName) == False)
	{
		if (exitsub (reply, M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}
	
	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) 
	{
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
		else
			return apiRC;
	}
	
	strcpy(ibegin , trim(ibegin));
	
	if(ftype[0] == 'C') 
	{
		sprintf_s(stmp_x, sizeof stmp_x," AND a.icard = '%s' ",ibegin);		
	}
	else if(ftype[0] == 'P') 
	{
		sprintf_s(stmp_x, sizeof stmp_x," AND a.ipolicy = '%s' ",ibegin);
	}
	
	chk_35 = 0;
	for(k=0;k<count_db;k++)
	{
		sprintf_s(stmt_x, sizeof stmt_x," SELECT count(*)  "
		                "   FROM %s:ply_relation a,%s:policy b  "
		                "  WHERE a.ipolicy = b.ipolicy  "
		                "    AND b.itag = ''  "
		                "    AND (a.ipro_year||trim(Lpad(b.qpro_month::VARCHAR(2), 2, '0')))::INT < 202212 AND a.dply_begin < '11/30/2024' "
		                "    AND a.ipro_year||trim(Lpad(b.qpro_month::VARCHAR(2), 2, '0')) <> to_char(a.dply_begin,'%Y%m') AND a.icar_type = '35'"
		                "    %s ",list[k].dbname,list[k].dbname,stmp_x);
		printf("stmt_x[%s] \n",stmt_x);
		$PREPARE card_chk_35 FROM $stmt_x;
		$EXECUTE card_chk_35 INTO $chk_35_tmp;
		
		chk_35 = chk_35 + chk_35_tmp;
	}
	
	if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True) 
			return M_CM_NOT_FOUND;
		else
			return apiRC;
	}
	
	cm_buf_init (ReplyBuf);
	cm_buf_put ("%l %d", M_CM_OK, chk_35);
	
	tmp_len = cm_buf_len(ReplyBuf);
	if (SendSyncReply (reply, ReplyBuf, tmp_len, api_OKComplete) == False)
		return apiRC;
	else
		return api_OKComplete;
	
	errexit:
	printf("<car203_chk_35> sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
	if (exitsub (reply, SQLCODE) == True)
		return SQLCODE;
	else
		return apiRC;
}
/******************************************************************************/
void clear_data()
{
     irelative_ply[0]=0;
     fcomp_class[0]=fcomp_class_last[0]=0;
     nassured[0]=aassured[0]=0;
     apayment[0]=0;
     ncar_abbr[0]=0;
     iissue_ym[0]=0;
     itag[0]=0;
     iengine[0]=0;
     icar_type[0]=0;
     nbrand_abbr[0]=0;
     ibrand[0]=0;
     /*  qcylinder_buf[0]=0; */
     s_qcylinder[0]=0;
     ibody[0]=0;
     dply_begin[0]=dply_end[0]=0;
     /*  qperiod_buf[0]=0;
     mpremium_buf[0]=0;  */
     ilicense[0]=0;
     ibirth[0]=0;
     fsex[0]=0;
     itel[0]=0;
     bcard1[0]=bcard2[0]=bcard3[0]=0;
     irelative_card[0]=0;
     pdate[0]=fpt[0]=0;
     Nofficer[0]=Iofficer[0]=0;
     fmarriage[0]=0;
     iassured[0]=0;
     mpremium = qperiod = qpt= 0;
     mdamage_cover = 0;
}
