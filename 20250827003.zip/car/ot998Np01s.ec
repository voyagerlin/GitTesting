/****************************************************/
/*                                                  */
/*   PROGRAM      : ot998p01.ec   BY inhua          */
/*   DATE WRITTEN : 2001/6/27                       */
/*   DATE MODIFY  :                                 */
/*   ��L������o�i���ߴC��@�~(90.07�s�榡)        */
/*   files        : ot_ply_edr          i           */
/*                  ot_settlement       i           */
/*   output       : PLYIP17yymm         o           */
/*                  EDRIP17yymm         o           */
/*                  STLIP17yymm         o           */
/*                  APPIP17yymm         o           */
/*   *900913�w�M�ߴڥ���~��אּ�鵲��              */
/****************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include "glsmsgs.h"
#include "glsstru.h"
#include "glscom.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
$include sqltypes.h;

/*--------------------------------------------------------------------*/
int   trn_i,rtc;
int   flen_P, flen_E, flen_C, flen_O;
long  print_cnt,print_amt,pure_print_amt;
$double memno, memno1;
long  rtn;
char  msgbuf[1024];
long  today;
char date_tmp[11];
$double mdeduct, msettle, deduct, mcertificate, mprocess;
$char paycd[5],mpremiumcd[2], source[3], smins_covercd[2];
$double mlaw_acc, mpremium, mpremium_pure;
$char smpremium_pure[11], smpremium[11];
$char msettlecd[2], smsettle[14], stotamt[9];
$char mestimatecd[2], smestimate[14], fcareer[2];
$char career_type[2],idno[11], nobject[101],flag12[2],flagPG[2],dbirth[11];
$char plybegin[10],iendorse[21],member[9],dbegin_ply[10], dend_ply[10];
$char siendorse[21], smembercd[2];
$char limit[4], type[3], date1[9], date2[9],birth[9];
$char flagno[2],score[5],amtcd1[2],amt1[11],amtcd2[2],amt2[11];
$char amt3[14], amt4[9], amtcd3[2], amtcd4[2];
$char workno[2],payitem[3],smins_cover[14], transferdate[9];
$int  id1,id2,id3,id4;
char  sApHome[30];
char  outputf[N_FILE+1], userid[6];
extern char RPTDIR[];
static char filename_P[51],filename_E[51],filename_C[51],filename_O[51];
$char sex[2],datebgn[11],dateend[11],id[2],plydbegin[10], plydend[10];
$char edrdbegin[10],edrdend[10];
$char sdie_amt[13], smed_limit[13], sinpday_amt[13];
$char sdie_mprem[10], smed_mprem[10], sinpday_mprem[10];
$char sdie_pure[10], smed_pure[10], sinpday_pure[10];
$double die_amt, med_limit, inpday_amt, nurse_amt;
$double die_mprem, med_mprem, inpday_mprem, nurse_mprem;
$double die_pure, med_pure, inpday_pure, nurse_pure;
$char pol[2], edr[2], clm[2], out[2];
$char DBnameFull[21], DBname[42];
$char fname[21];
$char s4[3],s1[3],s2[3],s3[5],s5[3];
$char stmt[2000];
FILE  *fp_P, *fp_E, *fp_C, *fp_O;

int  oth998_accumulate();
int  oth998_accumu_oth_ply();
int  oth998_accumu_fir_ply();
int  oth998_accumu_car_ply();
int  oth998_accumu_oth_edr();
int  oth998_accumu_fir_edr();
int  oth998_accumu_car_edr();
int  oth998_accumu_oth_clm();
int  oth998_accumu_car_clm();
int  oth998_accumu_car_out();
int  oth998_accumu_oth_out();
int  ot998_P();
int  ot998_E();
int  ot998_C();
int  ot998_O();
char *get_dtl_full_db();
/*--------------------------------------------------------------------*/
main(argc,argv)
int  argc;
char **argv;
{
    batchinit();
    strcpy(DBname,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(datebgn, isNULLstr(argv[3]));
    strcpy(dateend, isNULLstr(argv[4]));
    strcpy(pol,     isNULLstr(argv[5]));
    strcpy(edr,     isNULLstr(argv[6]));
    strcpy(clm,     isNULLstr(argv[7]));
    strcpy(out,     isNULLstr(argv[8]));
    strcpy(outputf, isNULLstr(argv[9]));

   printf("datebgn[%s] dateend[%s]\n",datebgn,dateend);
   printf("pol[%s] edr[%s] clm[%s] out[%s]\n",pol,edr,clm,out);
   printf("DBname:[%s]\n",DBname);

   today = cm_today( );
   strcpy(date_tmp,cm_edate_str(today));
   strncpy(transferdate,&date_tmp[6],4);  transferdate[4]='\0';
   strncat(transferdate,&date_tmp[0],2);  transferdate[6]='\0';
   strncat(transferdate,&date_tmp[3],2);  transferdate[8]='\0';

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBname) == False) {
      return M_CM_DB_NOTOPEN;
   }

    rtn=oth998_accumulate();

    if (rtn<0)
    {
        EWRITE(userid,rtn,"��o�i���ߧ@�~����");
        return rtn;
    }
    else EWRITE(userid,M_CM_OK,msgbuf);
    return SUCCESS;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------------*/
int oth998_accumulate()
{
    $char db_ibranch[3];
    $char dbegin[11], dend[11];
    $char Mprem[9];

    $WHENEVER SQLERROR GOTO errexit;

   /****** creat temp table ******/

$create temp table ot_ply_edr_998
(
    plyedrcd char(1),
    iproduct char(12),
    flag12 char(1),
    flagPG char(1),
    plycd char(4),
    ipolicy char(15),
    edrcd char(4),
    iendorse char(15),
    fedr_class char(1),
    plydate char(8),
    plybegin char(8),
    plyend char(8),
    edrdate char(8),
    edrbegin char(8),
    edrend char(8),
    date1 char(8),
    date2 char(8),
    flagno char(1),
    member char(8)
        default '00000000',
    id char(1),
    idno char(10)
        default '0000000000',
    sex char(1),
    birth char(8)
        default '00000000',
    score char(4),
    mpremcd char(1)
        default '+',
    mprem char(13)
        default '0000000000000',
    limit char(3)
        default '000',
    amtcd1 char(1)
        default '+',
    amt1 char(10)
        default '0000000000',
    amtcd2 char(1)
        default '+',
    amt2 char(10)
        default '0000000000',
    workno char(1),
    transferdate char(8),
    type char(2)
)with no log;

$create temp table ot_app_stl_998
( 
    appstlcd char(1),
    iproduct char(12),
    flag12 char(1),
    flagPG char(1),
    iclaimcd char(4),
    iclaim char(15),
    iclaim_sno char(4),
    plycd char(4),
    ipolicy char(15),
    daccident char(8),
    dclaim char(8),
    dgroup char(6),
    plybegin char(8),
    plyend char(8),
    id char(1),
    idno char(10)
 	default '0000000000',
    sex char(1),
    birth char(8)
        default '00000000',
    nreason char(3),
    txcd char(1),
    fdecide char(1),
    score char(4),
    amtcd3 char(1)
        default '+',
    amt3 char(13)
        default '0000000000000',
    amtcd4 char(1)
        default '+',
    amt4 char(8)
        default '00000000',
    payitem char(2),
    paycd char(4),
    workno char(1),
    transferdate char(8),
    mins_cover char(13),
    type char(2)
)with no log;

    $DECLARE srv_cursor CURSOR FOR
     SELECT branch
       FROM servertbl
      WHERE branch != 'S1';

    $OPEN srv_cursor;

    while(1)
    {
        $FETCH srv_cursor INTO $db_ibranch;
        printf(" fetch srv_cursor[%s]\n",db_ibranch);

        if(SQLCODE == SQLNOTFOUND) break;

        strcpy(DBnameFull, get_full_dbname(trim(db_ibranch)));
        printf("DBnameFull[%s]\n",DBnameFull);

        if (strncmp(pol,"1",1)==0)
        {
            rtn=oth998_accumu_oth_ply();
            if (rtn<0) return rtn;

            rtn=oth998_accumu_fir_ply();
            if (rtn<0) return rtn;
            
            rtn=oth998_accumu_car_ply();
            if (rtn<0) return rtn;
        }
        if (strncmp(edr,"1",1)==0)
        {
            rtn=oth998_accumu_oth_edr();
            if (rtn<0) return rtn;

            rtn=oth998_accumu_fir_edr();
            if (rtn<0) return rtn;
            
            rtn=oth998_accumu_car_edr();
            if (rtn<0) return rtn;
        }
        if (strncmp(clm,"1",1)==0)
            if(strncmp(db_ibranch, "00", 2)==0)
            {
                rtn=oth998_accumu_oth_clm();
                if (rtn<0) return rtn;
                
                rtn=oth998_accumu_car_clm();
                if (rtn<0) return rtn;
            }
        if (strncmp(out,"1",1)==0)
            if(strncmp(db_ibranch, "00", 2)==0)
            {
printf(" ***************** oth 998 ****************** \n");            	
                rtn=oth998_accumu_oth_out();
                if (rtn<0) return rtn;
  printf(" *************************************** 998 ************** \n");              
                rtn=oth998_accumu_car_out();
                if (rtn<0) return rtn;
            }

    }
    $CLOSE srv_cursor;
    $FREE  srv_cursor;


    cm_split_ymd(dateend,s1,s2,s3);
    printf("s1[%s]\n,s2[%s]\n,s3[%s]\n",s1,s2,s3);
    trn_i = atoi(s3);
    trn_i -= 1911;
    strcpy(s4,itoa(trn_i));
    strcpy(s5,trim(s4));

    rtn = getApHome(sApHome);
    if (rtn < 0)
    {
        printf("read Config file error!!-->getApHome\n");
        goto errexit;
    }
    printf("sApHome:[%s]\n",sApHome);
    rtn = getInitServerDB(DBname);

    if (rtn < 0)
    {
        printf("read Config file error!!-->getInitServerDB\n");
        goto errexit;
    }

    if (strncmp(pol,"1",1)==0)
    {
        sprintf(fname,"PLYIP17%s%s",s5,s1);
        strncpy(filename_P," ",30);
        sprintf(filename_P,"%s/tmp/", sApHome);
        strcat(filename_P,fname);
        if((fp_P = fopen(filename_P,"w+")) == NULL)
        {
            printf("fp_P open file fail[%s]\n",filename_P);
            exit(1);
        }
        else printf("open fp_P file success!!!\n");

        print_cnt=print_amt=pure_print_amt=0;
        rtn=ot998_P();
        fclose(fp_P);
    }

    if (strncmp(edr,"1",1)==0)
    {
        sprintf(fname,"EDRIP17%s%s",s5,s1);
        strncpy(filename_E," ",30);
        sprintf(filename_E,"%s/tmp/", sApHome);
        strcat(filename_E,fname);
        if((fp_E = fopen(filename_E,"w+")) == NULL)
        {
            printf("fp_E open file fail[%s]\n",filename_E);
            exit(1);
        }
        else printf("open fp_E file success!!!\n");

        print_cnt=print_amt=pure_print_amt=0;
        rtn=ot998_E();
        fclose(fp_E);
    }

    if (strncmp(clm,"1",1)==0)
    {
        sprintf(fname,"STLIP17%s%s",s5,s1);
        strncpy(filename_C," ",30);
        sprintf(filename_C,"%s/tmp/", sApHome);
        strcat(filename_C,fname);
        if((fp_C = fopen(filename_C,"w+")) == NULL)
        {
            printf("fp_C open file fail[%s]\n",filename_C);
            exit(1);
        }
        else printf("open fp_C file success!!!\n");

        print_cnt=print_amt=0;
        rtn=ot998_C();
        fclose(fp_C);
    }

    if (strncmp(out,"1",1)==0)
    {
    	printf(" !!!!!!!!!!!!!!!!!!!!!!!!!!!!!! show it !!!!!!!! \n");
        sprintf(fname,"APPIP17%s%s",s5,s1);
        strncpy(filename_O," ",30);
        sprintf(filename_O,"%s/tmp/", sApHome);
        strcat(filename_O,fname);
        if((fp_O = fopen(filename_O,"w+")) == NULL)
        {
            printf("fp_O open file fail[%s]\n",filename_O);
            exit(1);
        }
        else printf("open fp_O file success!!!\n");

        print_cnt=print_amt=0;
        
        printf(" $$$$$$$$$$$$$$$$$$$$$$$$$$$$ prepare to printf \n");        
        rtn=ot998_O();
        fclose(fp_O);
    }


    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------------*/
int oth998_accumu_oth_ply()
 {
    $char iproduct[13], iins_scope[3], fassured, ipolicy[21], icard[11], risk_area[4];
    $char dply_edr[11], dbegin[11], dend[11], ddanger_begin[11], ddanger_end[11];
    $char resp_type, ideduct, pcosharecd, sprem_rule, idanger_unit[3];
    $char icareer[8], idanger_type[3], ndanger_type[5];
    $double pcoshare;
    $int  pprem_rule, qdanger_unit;
    $double mins_cover, mins_deduct, mpremium, mpremium_pure;
    $char plycd[5], ipolicy_into[16], plydate[9], plybegin[9], plyend[9];
    $char dang_bgn_into[9],dang_end_into[9], mins_deduct_into[7], pcoshare_into[6];
    $char mprem[11],sharemprem[11],pprem_rule_into[4],qdanger_unit_into[8];
    $char nonrespcd,nonrespamt[14],biaopcd,biaopamt[11];
    $char biaoacd,biaoaamt[11],pdaoacd,pdaoaamt[11],cslcd,cslamt[14];
    $char pure_mpremcd, pure_mprem[11], pure_sharemprem[11];
    $char iins_type[5], iins_kind[11];
    long  lyear, lyear2;

printf("========START oth998_accumu_oth_ply========\n");
    $whenever sqlerror goto errexit;

    sprintf(stmt," select e.iproduct, d.iins_scope, a.fassured, a.ipolicy, \
                          a.risk_area, a.dply_edr, a.dbegin, a.dend, \
                          a.ddanger_begin, a.ddanger_end, d.resp_type, \
                          b.mins_cover, c.pcoshare, b.ideduct, b.mins_deduct, \
                          a.pcosharecd, b.mpremium,b.mpremium_pure,a.sprem_rule,a.pprem_rule, \
                          a.idanger_unit, a.qdanger_unit, a.icareer, \
                          a.idanger_type, a.ndanger_type, d.iins_type, b.iins_kind \
                     from %s:ot_ply_edr a, %s:ot_ply_edr_instype b, %s:ot_ply_share c, \
                          %s:ot_insurance d, %s:cm_product_code e \
                    where a.dply_edr between ? and ? \
		      and a.ipolicy[6,7] in ('IP', 'PG', 'EP', 'TP', 'IJ') \
                      and a.iendorse = '' \
                      and a.iins_cat = 'O' \
                      and a.ipolicy = b.ipolicy \
                      and b.mpremium != 0 \
                      and b.mpremium_pure != 0 \
                      and b.iendorse = '' \
                      and c.ipolicy = a.ipolicy \
                      and c.icofirm = '17' \
                      and d.iins_cat = 'O' \
                      and d.iins_kind = b.iins_kind \
                      and e.iins_class = 'O' \
		      and b.iins_kind in ('EP34', 'EP35', 'EP36', 'EP37', 'TP39', 'TP40', 'IP31', 'IP32', 'IP33', 'PG31', 'PG32', 'PG33','IJ31','IJ32','IJ33','IJ41','IJ51','IJ52','IJ53','IJ54','IJ55','IJ56') \
                      and ( e.icode1 = '0' or e.icode1 = ' ')  \
                      and ( e.icode2 = '0' or e.icode2 = ' ')  \
                      and e.iins_type = b.ipolicy[6,7]",DBnameFull,DBnameFull,
                                        DBnameFull,DBnameFull,DBnameFull);

    $PREPARE pre_P1 FROM $stmt;
    $DECLARE cur_P1 CURSOR FOR pre_P1;
    $OPEN cur_P1 USING $datebgn, $dateend;
    while(1)
    {

        $FETCH cur_P1 INTO $iproduct, $iins_scope, $fassured, $ipolicy,
                 $risk_area, $dply_edr, $dbegin, $dend, $ddanger_begin,
                 $ddanger_end, $resp_type, $mins_cover, $pcoshare,
                 $ideduct, $mins_deduct, $pcosharecd, $mpremium, $mpremium_pure,
                 $sprem_rule, $pprem_rule, $idanger_unit, $qdanger_unit,
                 $icareer, $idanger_type, $ndanger_type, $iins_type, $iins_kind;

        if(SQLCODE == SQLNOTFOUND) break;

/**** 3 ****/

        if (memcmp(&ipolicy[5], "IP", 2) == 0 || memcmp(&ipolicy[5], "IJ", 2) == 0)
		flagPG[0] = 'P';
        else 
		flagPG[0] = 'G';

/**** 4 ****/

        strcpy(plycd,"17");
        strncat(plycd,ipolicy,2);
        plycd[4]='\0';

        strncpy(ipolicy_into,&ipolicy[3],10);
        ipolicy_into[10] = '\0';
        strcat(ipolicy_into,"     ");
        ipolicy_into[15] = '\0';

/**** 7 ****/

       	strncpy(plydate,  &dply_edr[6], 4);
       	plydate[4] = '\0';
       	strncat(plydate, &dply_edr[0], 2);
       	plydate[6] = '\0';
       	strncat(plydate, &dply_edr[3], 2);

/**** 8 ****/

        strncpy(plybegin,  &dbegin[6], 4);
        plybegin[4] = '\0';
        strncat(plybegin, &dbegin[0], 2);
        plybegin[6] = '\0';
        strncat(plybegin, &dbegin[3], 2);

        strncpy(plyend,  &dend[6], 4);
        plyend[4] = '\0';
        strncat(plyend, &dend[0], 2);
        plyend[6] = '\0';
        strncat(plyend, &dend[3], 2);

/**** 12 ****/

        if (memcmp(&ipolicy[5], "IP", 2) == 0 ||
	    memcmp(&ipolicy[5], "IJ", 2) == 0)
	{
		strcpy(member,"00000001");

    		sprintf(stmt," select idno, dbirth \
                     from %s:ot_group_member \
                    where ipolicy = ? \
		      and ftype = '1' \
                      and (iendorse is null or iendorse = ' ')",DBnameFull);

    		$PREPARE pre_P_11 FROM $stmt;
    		$DECLARE cur_P_11 CURSOR FOR pre_P_11;
    		$OPEN cur_P_11 USING $ipolicy;

    		while(1)
    		{
        		$FETCH cur_P_11 INTO $idno, $dbirth;

        		if(SQLCODE == SQLNOTFOUND) break;
    		}
    		$CLOSE cur_P_11;
    		$FREE cur_P_11;

	}

        if (memcmp(&ipolicy[5], "PG", 2) == 0)
        {
    		sprintf(stmt," select nobject \
                     from %s:ot_ply_obj \
                    where iobject = 'PG94' \
		      and ipolicy = ? \
                      and (iendorse is null or iendorse = ' ')",DBnameFull);

    		$PREPARE pre_P_1 FROM $stmt;
    		$DECLARE cur_P_1 CURSOR FOR pre_P_1;
    		$OPEN cur_P_1 USING $ipolicy;

    		while(1)
    		{
        		$FETCH cur_P_1 INTO $nobject;

        		if(SQLCODE == SQLNOTFOUND) break;
    		}
    		$CLOSE cur_P_1;
    		$FREE cur_P_1;

                memno = atof(nobject);
                sprintf(member,"%08.0f",memno);
        }

        if (memcmp(&ipolicy[5], "EP", 2) == 0)
        {
    		sprintf(stmt," select nobject \
                     from %s:ot_ply_obj \
                    where iobject = 'EP94' \
		      and ipolicy = ? \
                      and (iendorse is null or iendorse = ' ')",DBnameFull);

    		$PREPARE pre_P_2 FROM $stmt;
    		$DECLARE cur_P_2 CURSOR FOR pre_P_2;
    		$OPEN cur_P_2 USING $ipolicy;

    		while(1)
    		{
        		$FETCH cur_P_2 INTO $nobject;

        		if(SQLCODE == SQLNOTFOUND) break;
    		}
    		$CLOSE cur_P_2;
    		$FREE cur_P_2;

                memno = atof(nobject);
                sprintf(member,"%08.0f",memno);
        }

        if (memcmp(&ipolicy[5], "TP", 2) == 0)
        {
    		sprintf(stmt," select qdanger_unit \
                     from %s:ot_ply_edr \
		    where ipolicy = ? \
                      and (iendorse is null or iendorse = ' ')",DBnameFull);

    		$PREPARE pre_P_3 FROM $stmt;
    		$DECLARE cur_P_3 CURSOR FOR pre_P_3;
    		$OPEN cur_P_3 USING $ipolicy;

    		while(1)
    		{
        		$FETCH cur_P_3 INTO $qdanger_unit;

        		if(SQLCODE == SQLNOTFOUND) break;
    		}
    		$CLOSE cur_P_3;
    		$FREE cur_P_3;

                sprintf(member,"%08.0f",qdanger_unit);
        }

/**** 13 ****/

        if (memcmp(&ipolicy[5], "IP", 2) == 0 || memcmp(&ipolicy[5], "IJ", 2) == 0)
	{
		id[0] = '1';
	}
	else
	{
		id[0] = '0';
	}

/**** 14 ****/

	if (memcmp(&idno[1], "1", 1) == 0)
	{
		sex[0] = '1';
	}
	else
	{
		sex[0] = '2';
	}

/**** 15 ****/

        if (memcmp(&ipolicy[5], "IP", 2) == 0 || memcmp(&ipolicy[5], "IJ", 2) == 0)
	{
        	if (risnull(SQLCHAR,dbirth) != 1)
        	{
            		strncpy(birth,  &dbirth[6], 4);
            		birth[4] = '\0';
            		strncat(birth, &dbirth[0], 2);
            		birth[6] = '\0';
            		strncat(birth, &dbirth[3], 2);
        	}
        	else 
		{
			strcpy(birth, "00000000");
        		birth[8] = '\0';
		}
	}
       	else 
	{
		strcpy(birth, "00000000");
       		birth[8] = '\0';
	}

/**** 16 ****/

	if(memcmp(&iins_kind[2], "31", 2) == 0 ||
 	   memcmp(&iins_kind[2], "34", 2) == 0 ||
 	   memcmp(&iins_kind[2], "40", 2) == 0)
 	{
                flag12[0] = '1';
                memcpy(score, "0100", 4);
		strcpy(limit,"000");
        }

	if(memcmp(&iins_kind[2], "32", 2) == 0 ||
 	   memcmp(&iins_kind[2], "35", 2) == 0 ||
 	   memcmp(&iins_kind[2], "39", 2) == 0)
 	{
                flag12[0] = '2';
                memcpy(score, "2100", 4);
		strcpy(limit,"000");
        }

	if(memcmp(&iins_kind[2], "33", 2) == 0 ||
 	   memcmp(&iins_kind[2], "36", 2) == 0)
 	{
                flag12[0] = '2';
                memcpy(score, "2200", 4);
		strcpy(limit,"090");
        }

	if(memcmp(&iins_kind[2], "37", 2) == 0)
 	{
                flag12[0] = '2';
                memcpy(score, "2302", 4);
		strcpy(limit,"000");
        }

	if(memcmp(&iins_kind[2], "41", 2) == 0 ||
 	   memcmp(&iins_kind[2], "51", 2) == 0 ||
 	   memcmp(&iins_kind[2], "52", 2) == 0 ||
 	   memcmp(&iins_kind[2], "53", 2) == 0 ||
 	   memcmp(&iins_kind[2], "54", 2) == 0 ||
 	   memcmp(&iins_kind[2], "55", 2) == 0 ||
 	   memcmp(&iins_kind[2], "56", 2) == 0)
 	{
                flag12[0] = '1';
                memcpy(score, "0102", 4);
		strcpy(limit,"000");
        }

	if(memcmp(&iins_kind[2], "34", 2) == 0)
	{
		flag12[0] = '2';
	}

/**** 20 21 ****/

       	strcpy(smpremium,"0000000000000");
	sprintf(smpremium,"%010.0f",mpremium * pcoshare / 100);
        smpremium[10] = '\0';

/**** 22 23 ****/

       	strcpy(smpremium_pure,"0000000000000");
	sprintf(smpremium_pure,"%010.0f",mpremium_pure * pcoshare / 100);
        smpremium_pure[10] = '\0';

/**** 24 ****/

        $select type
           into $career_type
           from ot_career
          where icareer = $icareer;

        if (memcmp(&ipolicy[5], "PG", 2) == 0 ||
            memcmp(&ipolicy[5], "EP", 2) == 0 ||
            memcmp(&ipolicy[5], "TP", 2) == 0 ||
            memcmp(&ipolicy[5], "PA", 2) == 0 ||
            memcmp(&ipolicy[5], "TS", 2) == 0 ||
            memcmp(&ipolicy[5], "TY", 2) == 0 ||
            memcmp(&ipolicy[5], "TC", 2) == 0 ||
            memcmp(&ipolicy[5], "TA", 2) == 0)
        {
                career_type[0] = '0';
        }
        else
        {
                career_type[0] = '9';
        }

/**** 26 ****/

        if (memcmp(&ipolicy[5], "IP", 2) == 0 || 
	    memcmp(&ipolicy[5], "IJ", 2) == 0 ||
	    memcmp(&ipolicy[5], "PG", 2) == 0)
	{
       		strcpy(source,"51");

		strcpy(smins_cover,"0000000000000");
		sprintf(smins_cover,"%013.0f",mins_cover);
	}
	else
	{
       		strcpy(source,"41");
	}

/**** �~�Ȩӷ��� 41 �Ĥ@���q���ݿ��s��� ****/

/****
        if (memcmp(source, "41", 2) == 0)
	{
		flagPG[0] = '0';
		flagno[0] = '0';
       		strcpy(member,"00000000");
		id[0] = '0';
       		strcpy(idno,"0000000000");
		sex[0] = '0';
       		strcpy(birth,"00000000");
       		strcpy(score,"0000");
       		strcpy(limit,"000");
		workno[0] = '0';
		career_type[0] = '0';
       		strcpy(smins_cover,"0000000000000");
	}
****/

	/**** �����I���ݰe��� ****/

	if(flagPG[0] == 'G')
	{
		id[0] = '0';
       		strcpy(idno,"0000000000");
		sex[0] = '0';
       		strcpy(birth,"00000000");
	}

	/**** �����I¾�~���O���ݰe ****/

	if(flagPG[0] == 'G' && memcmp(source, "51", 2) == 0)
		career_type[0] = '0';

	/**** �ӫO�d�� 2200 ���v���B�� 090 ��L�� 000 ****/

	if(memcmp(score, "2200", 4) == 0)
		strcpy(limit, "090");
	else
		strcpy(limit, "000");

	/**** ���_�O�_���~��H ****/
	
        if (memcmp(&ipolicy[5], "IP", 2) == 0 || memcmp(&ipolicy[5], "IJ", 2) == 0) 
	{
	   if(memcmp(&idno[1], "0", 1) == 0 ||
	      memcmp(&idno[1], "1", 1) == 0 ||
	      memcmp(&idno[1], "2", 1) == 0 ||
	      memcmp(&idno[1], "3", 1) == 0 ||
	      memcmp(&idno[1], "4", 1) == 0 ||
	      memcmp(&idno[1], "5", 1) == 0 ||
	      memcmp(&idno[1], "6", 1) == 0 ||
	      memcmp(&idno[1], "7", 1) == 0 ||
	      memcmp(&idno[1], "8", 1) == 0 ||
	      memcmp(&idno[1], "9", 1) == 0)
		{
			id[0] = '1';
			if(memcmp(&idno[1], "1", 1) == 0)
			{
				sex[0] = '1';
			}
			else
			{
				sex[0] = '2';
			}
		}
		else
		{
			id[0] = '9';
			sex[0] = '1';
		}
	}

	/**** IP�H�Ƭ��@�H ****/

        if (memcmp(&ipolicy[5], "IP", 2) == 0 || memcmp(&ipolicy[5], "IJ", 2) == 0)
	{
       		strcpy(member,"00000001");
		career_type[0] = '9';
	}

        /**** TP �H�Υd ****/

        if (memcmp(&ipolicy[5], "TP", 2) == 0)
	{
       		strcpy(iproduct,"425240391911");
		flag12[0] = '2';
	}
	
        if (memcmp(source, "41", 2) == 0)
	{
       		strcpy(member,"00000000");
		id[0] = '0';
		sex[0] = '0';
	}

       	   $INSERT INTO ot_ply_edr_998
              VALUES('1',$iproduct, $flag12, $flagPG, $plycd, $ipolicy_into,
                     '0000','000000000000000','0',$plydate,
                     $plybegin,$plyend,'00000000','00000000','00000000',
                     $plybegin,$plyend,'+',$member,$id,$idno,$sex,$birth,
                     $score,'+',$smins_cover,$limit,'+',$smpremium,'+',
		     $smpremium_pure, $career_type,$transferdate, $source);

        printf("===oth998_accumu_oth_ply insert compelete====\n");
    }
    $CLOSE cur_P1;
    $FREE  cur_P1;

printf("========END oth998_accumu_oth_ply========\n");
    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
int oth998_accumu_oth_edr()
{
    $char iproduct[13], iins_scope[3], fassured, ipolicy[21], icard[11];
    $char iendorse[21], risk_area[4], fedr_class, dply_edr_pol[11], dbegin_pol[11], dply_edr[11];
    $char dbegin[11], dend[11], ddanger_begin[11], ddanger_end[11], dend_pol[11];
    $char resp_type, ideduct, pcosharecd, sprem_rule, idanger_unit[3];
    $char icareer[8], idanger_type[3], ndanger_type[5];
    $double pcoshare;
    $int  pprem_rule, qdanger_unit;
    $double mins_cover, mins_deduct, mpremium, mpremium_pure;
    $char plycd[5], ipolicy_into[16], edrcd[5], iendorse_into[16], fedr_class_into, plydate[9], plybegin[9], plyend[9], edrdate[9], edrbegin[9], edrend[9];
    $char dang_bgn_into[9],dang_end_into[9], mins_deduct_into[7], pcoshare_into[6];
    $char mpremcd[2], mprem[11],sharemprem[11],pprem_rule_into[4],qdanger_unit_into[8];
    $char nonrespcd,nonrespamt[14],biaopcd,biaopamt[11];
    $char biaoacd,biaoaamt[11],pdaoacd,pdaoaamt[11],cslcd,cslamt[14];
    $char pure_mpremcd, pure_mprem[11], pure_sharemprem[11];
    $char iins_type[5], iins_kind[11];
    long  leyear, leyear2;

printf("========START oth998_accumu_oth_edr========\n");
    $whenever sqlerror goto errexit;

    sprintf(stmt," select e.iproduct, d.iins_scope, a.fassured, a.ipolicy, \
                          a.iendorse, a.risk_area, a.fedr_class, a.dply_edr, \
                          a.dbegin, a.dend, a.ddanger_begin, a.ddanger_end, \
                          d.resp_type, b.mins_cover, c.pcoshare, b.ideduct, \
                          b.mins_deduct, a.pcosharecd, b.mpremium,b.mpremium_pure,a.sprem_rule, \
                          a.pprem_rule, a.idanger_unit, a.qdanger_unit, a.icareer, \
                          a.idanger_type, a.ndanger_type, d.iins_type, b.iins_kind \
                     from %s:ot_endorse a, %s:ot_edr_instype b, %s:ot_ply_share c, \
                          %s:ot_insurance d, %s:cm_product_code e \
                    where a.dply_edr between ? and ? \
		      and a.ipolicy[6,7] in ('IP', 'PG', 'EP', 'TP', 'IJ') \
                      and a.iins_cat = 'O' \
                      and a.mpremium != 0 \
                      and a.fedr_class not in ('9', 'A') \
                      and a.iendorse = b.iendorse \
		      and b.iins_kind in ('EP34', 'EP35', 'EP36', 'EP37', 'TP39', 'TP40', 'IP31', 'IP32', 'IP33', 'PG31', 'PG32', 'PG33','IJ31','IJ32','IJ33','IJ41','IJ51','IJ52','IJ53','IJ54','IJ55','IJ56') \
                      and b.mpremium != 0 \
                      and b.mpremium_pure != 0 \
                      and c.ipolicy = a.ipolicy \
                      and c.icofirm = '17' \
                      and d.iins_cat = 'O' \
                      and d.iins_kind = b.iins_kind \
                      and e.iins_class = 'O' \
                      and ( e.icode1 = '0' or e.icode1 = ' ')  \
                      and ( e.icode2 = '0' or e.icode2 = ' ')  \
                      and e.iins_type = b.ipolicy[6,7]",DBnameFull,DBnameFull,
                                        DBnameFull,DBnameFull,DBnameFull);

    $PREPARE pre_E1 FROM $stmt;
    $DECLARE cur_E1 CURSOR FOR pre_E1;
    $OPEN cur_E1 USING $datebgn, $dateend;
    while(1)
    {
        $FETCH cur_E1 INTO $iproduct, $iins_scope, $fassured, $ipolicy,
                          $iendorse, $risk_area, $fedr_class, $dply_edr,
                          $dbegin, $dend, $ddanger_begin, $ddanger_end,
                          $resp_type, $mins_cover, $pcoshare, $ideduct,
                          $mins_deduct, $pcosharecd, $mpremium, $mpremium_pure, $sprem_rule,
                          $pprem_rule, $idanger_unit, $qdanger_unit, $icareer,
                          $idanger_type, $ndanger_type, $iins_type, $iins_kind;

        if(SQLCODE == SQLNOTFOUND) break;

/**** 3 ****/

        if (memcmp(&ipolicy[5], "IP", 2) == 0 || memcmp(&ipolicy[5], "IJ", 2) == 0)
		flagPG[0] = 'P';
        else 
		flagPG[0] = 'G';

/**** 4 ****/

        strcpy(plycd,"17");
        strncat(plycd,ipolicy,2);
        plycd[4]='\0';

        strncpy(ipolicy_into,&ipolicy[3],10);
        ipolicy_into[10] = '\0';
        strcat(ipolicy_into,"     ");
        ipolicy_into[15] = '\0';

/**** 5 ****/

        strcpy(edrcd,"17");
        strncat(edrcd,iendorse,2);
        edrcd[4]='\0';

        strncpy(iendorse_into,&iendorse[3],10);
        iendorse_into[10] = '\0';
        strcat(iendorse_into,"     ");
        iendorse_into[15] = '\0';

/**** 6 ****/

        if (fedr_class == '5') fedr_class_into = '1';
        else if (fedr_class == '1') fedr_class_into = '2';
        else fedr_class_into = '5';

/**** 7 ****/

        sprintf(stmt,"select dply_edr \
                         from %s:ot_ply_edr \
                        where ipolicy = ? \
                          and iendorse = ''",DBnameFull);

        $PREPARE pre_E2 FROM $stmt;
        $DECLARE cur_E2 CURSOR FOR pre_E2;

        $OPEN cur_E2 USING $ipolicy;

        $FETCH cur_E2 INTO $dply_edr_pol;

        if(SQLCODE == SQLNOTFOUND)
        {
            strcpy(plydate, "00000000");
        }
        else
        {
            strncpy(plydate,  &dply_edr_pol[6], 4);
            plydate[4] = '\0';
            strncat(plydate, &dply_edr_pol[0], 2);
            plydate[6] = '\0';
            strncat(plydate, &dply_edr_pol[3], 2);
            plydate[8] = '\0';
        }
        $CLOSE cur_E2 ;
        $FREE cur_E2 ;

/**** 8 ****/

        sprintf(stmt,"select dbegin, dend \
                         from %s:ot_ply_edr \
                        where ipolicy = ? \
                          and iendorse = ? ",DBnameFull);

        $PREPARE pre_E3 FROM $stmt;
        $DECLARE cur_E3 CURSOR FOR pre_E3;

        $OPEN cur_E3 USING $ipolicy, $iendorse;

        $FETCH cur_E3 INTO $dbegin_pol, $dend_pol;

        if(SQLCODE == SQLNOTFOUND)
        {
            strcpy(plybegin, "00000000");
            strcpy(plyend  , "00000000");
        }
        else
        {
            printf("dbegin_pol = %s, dend_pol = %s \n", dbegin_pol, dend_pol);
            strncpy(plybegin,  &dbegin_pol[6], 4);
            plybegin[4] = '\0';
            strncat(plybegin, &dbegin_pol[0], 2);
            plybegin[6] = '\0';
            strncat(plybegin, &dbegin_pol[3], 2);
            plybegin[8] = '\0';

            strncpy(plyend  ,  &dend_pol[6], 4);
            plyend[4] = '\0';
            strncat(plyend  , &dend_pol[0], 2);
            plyend[6] = '\0';
            strncat(plyend  , &dend_pol[3], 2);
            plyend[8] = '\0';
        }
        $CLOSE cur_E3 ;
        $FREE cur_E3 ;

/**** 9 ****/

        if (risnull(SQLCHAR,dply_edr) != 1)
        {
            strncpy(edrdate,  &dply_edr[6], 4);
            edrdate[4] = '\0';
            strncat(edrdate, &dply_edr[0], 2);
            edrdate[6] = '\0';
            strncat(edrdate, &dply_edr[3], 2);
        }
        else strcpy(edrdate, "00000000");
        edrdate[8] = '\0';

/**** 10 ****/

        if (risnull(SQLCHAR,dbegin) != 1)
        {
            strncpy(edrbegin,  &dbegin[6], 4);
            edrbegin[4] = '\0';
            strncat(edrbegin, &dbegin[0], 2);
            edrbegin[6] = '\0';
            strncat(edrbegin, &dbegin[3], 2);
        }
        else strcpy(edrbegin, "00000000");
        edrbegin[8] = '\0';

        if (risnull(SQLCHAR,dend) != 1)
        {
            strncpy(edrend,  &dend[6], 4);
            edrend[4] = '\0';
            strncat(edrend, &dend[0], 2);
            edrend[6] = '\0';
            strncat(edrend, &dend[3], 2);
        }
        else strcpy(edrend, "00000000");
        edrend[8] = '\0';

/**** 12 ****/

        if (memcmp(&ipolicy[5], "IP", 2) == 0 ||
	    memcmp(&ipolicy[5], "IJ", 2) == 0)
        {
		strcpy(member,"00000001");

    		sprintf(stmt,"select distinct idno, dbirth \
                     from %s:ot_group_member \
                    where ipolicy = ? \
                      and iendorse = ?",DBnameFull);

    		$PREPARE pre_E_11 FROM $stmt;
    		$DECLARE cur_E_11 CURSOR FOR pre_E_11;
    		$OPEN cur_E_11 USING $ipolicy, $iendorse;
    		while(1)
    		{
        		$FETCH cur_E_11 INTO $idno, $dbirth;

        		if(SQLCODE == SQLNOTFOUND) break;

    		}
    		$CLOSE cur_E_11;
    		$FREE cur_E_11;
        }

        if (memcmp(&ipolicy[5], "PG", 2) == 0)
	{
    		sprintf(stmt," select max(iendorse) \
                     from %s:ot_endorse \
                    where ipolicy = ? \
                      and iendorse < ?",DBnameFull);

    		$PREPARE pre_E_1 FROM $stmt;
    		$DECLARE cur_E_1 CURSOR FOR pre_E_1;
    		$OPEN cur_E_1 USING $ipolicy, $iendorse;
    		while(1)
    		{
        		$FETCH cur_E_1 INTO $siendorse;

        		if(SQLCODE == SQLNOTFOUND) break;

    		}
    		$CLOSE cur_E_1;
    		$FREE cur_E_1;

        	if(SQLCODE == SQLNOTFOUND || memcmp(siendorse, ' ', 1) == 0)
		{
    			sprintf(stmt," select nobject \
                     		from %s:ot_ply_obj \
                    		where iobject = 'PG94' \
		      		and ipolicy = ? \
                      		and (iendorse is null or iendorse = ' ')",DBnameFull);

    			$PREPARE pre_E_2 FROM $stmt;
    			$DECLARE cur_E_2 CURSOR FOR pre_E_2;
    			$OPEN cur_E_2 USING $ipolicy;
    			while(1)
    			{
        			$FETCH cur_E_2 INTO $nobject;

        			if(SQLCODE == SQLNOTFOUND) break;
    			}
    			$CLOSE cur_E_2;
    			$FREE cur_E_2;
		}
		else
		{
    			sprintf(stmt," select nobject \
                     		from %s:ot_edr_obj \
                    		where ipolicy = ? \
                      		and iendorse = ? \
			        and iobject = 'PG94'",DBnameFull);

    			$PREPARE pre_E_3 FROM $stmt;
    			$DECLARE cur_E_3 CURSOR FOR pre_E_3;
    			$OPEN cur_E_3 USING $ipolicy, $siendorse;
    			while(1)
    			{
        			$FETCH cur_E_3 INTO $nobject;

        			if(SQLCODE == SQLNOTFOUND) break;

    			}
    			$CLOSE cur_E_3;
    			$FREE cur_E_3;
		}

		memno1 = atof(nobject);

    		sprintf(stmt," select nobject \
                     		from %s:ot_edr_obj \
                    		where ipolicy = ? \
                      		and iendorse = ? \
			        and iobject = 'PG94'",DBnameFull);

    		$PREPARE pre_E_4 FROM $stmt;
    		$DECLARE cur_E_4 CURSOR FOR pre_E_4;
    		$OPEN cur_E_4 USING $ipolicy, $iendorse;
    		while(1)
    		{
        		$FETCH cur_E_4 INTO $nobject;

        		if(SQLCODE == SQLNOTFOUND) break;

    		}
    		$CLOSE cur_E_4;
    		$FREE cur_E_4;
	}

        if (memcmp(&ipolicy[5], "EP", 2) == 0)
	{
    		sprintf(stmt," select max(iendorse) \
                     from %s:ot_endorse \
                    where ipolicy = ? \
                      and iendorse < ?",DBnameFull);

    		$PREPARE pre_E_5 FROM $stmt;
    		$DECLARE cur_E_5 CURSOR FOR pre_E_5;
    		$OPEN cur_E_5 USING $ipolicy, $iendorse;
    		while(1)
    		{
        		$FETCH cur_E_5 INTO $siendorse;

        		if(SQLCODE == SQLNOTFOUND) break;

    		}
    		$CLOSE cur_E_5;
    		$FREE cur_E_5;

        	if(SQLCODE == SQLNOTFOUND || memcmp(siendorse, ' ', 1) == 0)
		{
    			sprintf(stmt," select nobject \
                     		from %s:ot_ply_obj \
                    		where iobject = 'EP94' \
		      		and ipolicy = ? \
                      		and (iendorse is null or iendorse = ' ')",DBnameFull);

    			$PREPARE pre_E_6 FROM $stmt;
    			$DECLARE cur_E_6 CURSOR FOR pre_E_6;
    			$OPEN cur_E_6 USING $ipolicy;
    			while(1)
    			{
        			$FETCH cur_E_6 INTO $nobject;

        			if(SQLCODE == SQLNOTFOUND) break;
    			}
    			$CLOSE cur_E_6;
    			$FREE cur_E_6;
		}
		else
		{
    			sprintf(stmt," select nobject \
                     		from %s:ot_edr_obj \
                    		where ipolicy = ? \
                      		and iendorse = ? \
			        and iobject = 'EP94'",DBnameFull);

    			$PREPARE pre_E_7 FROM $stmt;
    			$DECLARE cur_E_7 CURSOR FOR pre_E_7;
    			$OPEN cur_E_7 USING $ipolicy, $siendorse;
    			while(1)
    			{
        			$FETCH cur_E_7 INTO $nobject;

        			if(SQLCODE == SQLNOTFOUND) break;

    			}
    			$CLOSE cur_E_7;
    			$FREE cur_E_7;
		}

		memno1 = atof(nobject);

    		sprintf(stmt," select nobject \
                     		from %s:ot_edr_obj \
                    		where ipolicy = ? \
                      		and iendorse = ? \
			        and iobject = 'EP94'",DBnameFull);

    		$PREPARE pre_E_8 FROM $stmt;
    		$DECLARE cur_E_8 CURSOR FOR pre_E_8;
    		$OPEN cur_E_8 USING $ipolicy, $iendorse;
    		while(1)
    		{
        		$FETCH cur_E_8 INTO $nobject;

        		if(SQLCODE == SQLNOTFOUND) break;

    		}
    		$CLOSE cur_E_8;
    		$FREE cur_E_8;
	}

	memno = atof(nobject);

	if(memno1 != memno)
	{
		memno = memno1 - memno;
	}

	if(memno >= 0)
	{
		smembercd[0] = '+';
	}
	else
	{
		smembercd[0] = '-';
		memno = memno * -1;
	}

        sprintf(member,"%08.0f",memno);

/**** 13 ****/

        if (memcmp(&ipolicy[5], "IP", 2) == 0 || memcmp(&ipolicy[5], "IJ", 2) == 0)
        {
                id[0] = '1';
        }
	else
        {
                id[0] = '0';
        }

/**** 14 ****/

        if (&idno[1] == '1')
        {
                sex[0] = '1';
        }
        else
        {
                sex[0] = '2';
        }

	if (risnull(SQLCHAR,dbirth) != 1)
        {
            strncpy(birth,  &dbirth[6], 4);
            birth[4] = '\0';
            strncat(birth, &dbirth[0], 2);
            birth[6] = '\0';
            strncat(birth, &dbirth[3], 2);
        }
        else strcpy(birth, "00000000");
        birth[8] = '\0';

/**** 15 ****/

	if (memcmp(&ipolicy[5], "IP", 2) == 0 || memcmp(&ipolicy[5], "IJ", 2) == 0)
 	{
 		if (risnull(SQLCHAR,dbirth) != 1)
 		{
 			strncpy(birth,  &dbirth[6], 4);
                        birth[4] = '\0';
                        strncat(birth, &dbirth[0], 2);
                        birth[6] = '\0';
                        strncat(birth, &dbirth[3], 2);
                }
                else
                {
                        strcpy(birth, "00000000");
                        birth[8] = '\0';
                }
        }
        else
        {
                strcpy(birth, "00000000");
                birth[8] = '\0';
        }

/**** 16 ****/

	if(memcmp(&iins_kind[2], "31", 2) == 0 ||
 	   memcmp(&iins_kind[2], "34", 2) == 0 ||
 	   memcmp(&iins_kind[2], "40", 2) == 0)
 	{
                flag12[0] = '1';
                memcpy(score, "0100", 4);
		strcpy(limit,"000");
        }

	if(memcmp(&iins_kind[2], "32", 2) == 0 ||
 	   memcmp(&iins_kind[2], "35", 2) == 0 ||
 	   memcmp(&iins_kind[2], "39", 2) == 0)
 	{
                flag12[0] = '2';
                memcpy(score, "2100", 4);
		strcpy(limit,"000");
        }

	if(memcmp(&iins_kind[2], "33", 2) == 0 ||
 	   memcmp(&iins_kind[2], "36", 2) == 0)
 	{
                flag12[0] = '2';
                memcpy(score, "2200", 4);
		strcpy(limit,"090");
        }

	if(memcmp(&iins_kind[2], "37", 2) == 0)
 	{
                flag12[0] = '2';
                memcpy(score, "2302", 4);
		strcpy(limit,"000");
        }

        if(memcmp(&iins_kind[2], "41", 2) == 0 ||
           memcmp(&iins_kind[2], "51", 2) == 0 ||
 	   memcmp(&iins_kind[2], "52", 2) == 0 ||
 	   memcmp(&iins_kind[2], "53", 2) == 0 ||
 	   memcmp(&iins_kind[2], "54", 2) == 0 ||
 	   memcmp(&iins_kind[2], "55", 2) == 0 ||
           memcmp(&iins_kind[2], "56", 2) == 0)
        {
                flag12[0] = '1';
                memcpy(score, "0102", 4);
                strcpy(limit,"000");
        }

	if(memcmp(&iins_kind[2], "34", 2) == 0)
	{
		flag12[0] = '2';
	}

/**** 20 21 ****/

	if(mpremium >= 0)
	{
		mpremiumcd[0] = '+';
 		strcpy(smpremium,"0000000000000");
 		sprintf(smpremium,"%010.0f",mpremium * pcoshare / 100);
 		smpremium[10] = '\0';
	}
	else
	{
		mpremiumcd[0] = '-';
		mpremium = mpremium * -1;
 		strcpy(smpremium,"0000000000000");
 		sprintf(smpremium,"%010.0f",mpremium * pcoshare / 100);
 		smpremium[10] = '\0';
	}

/**** 22 23 ****/

	if(mpremium_pure >= 0)
	{
 		strcpy(smpremium_pure,"0000000000000");
 	       sprintf(smpremium_pure,"%010.0f",mpremium_pure * pcoshare / 100);
		smpremium_pure[10] = '\0';
	}
	else
	{
		mpremium_pure = mpremium_pure * -1;
 		strcpy(smpremium_pure,"0000000000000");
 	       sprintf(smpremium_pure,"%010.0f",mpremium_pure * pcoshare / 100);
		smpremium_pure[10] = '\0';
	}

	if (memcmp(&ipolicy[5], "IP", 2) == 0 ||
	    memcmp(&ipolicy[5], "IJ", 2) == 0 ||
	    memcmp(&ipolicy[5], "PG", 2) == 0)
 	{
 		strcpy(source,"51");

 		strcpy(smins_cover,"0000000000000");

		if(mins_cover >= 0)
		{
			smins_covercd[0] = '+';
 			sprintf(smins_cover,"%013.0f",mins_cover);
		}
		else
		{
			smins_covercd[0] = '-';
			mins_cover = mins_cover * -1;
 			sprintf(smins_cover,"%013.0f",mins_cover);
		}
 	}
 	else
 	{
 		strcpy(source,"41");
	}

/****  24 ****/

        if (memcmp(&ipolicy[5], "PG", 2) == 0 ||
            memcmp(&ipolicy[5], "EP", 2) == 0 ||
            memcmp(&ipolicy[5], "TP", 2) == 0 ||
            memcmp(&ipolicy[5], "PA", 2) == 0 ||
            memcmp(&ipolicy[5], "TS", 2) == 0 ||
            memcmp(&ipolicy[5], "TY", 2) == 0 ||
            memcmp(&ipolicy[5], "TC", 2) == 0 ||
            memcmp(&ipolicy[5], "TA", 2) == 0)
        {
                career_type[0] = '0';
        }
        else
        {
                career_type[0] = '9';
        }

	/**** �~�Ȩӷ��� 41 �Ĥ@���q���ݿ��s��� ****/

/****
        if (memcmp(source, "41", 2) == 0)
        {
                flagPG[0] = '0';
                flagno[0] = '0';
                smembercd[0] = '+';
                strcpy(member,"00000000");
                id[0] = '0';
                strcpy(idno,"0000000000");
                sex[0] = '0';
                strcpy(birth,"00000000");
                strcpy(score,"0000");
                strcpy(limit,"000");
                workno[0] = '0';
                career_type[0] = '0';
                smins_covercd[0] = '+';
                strcpy(smins_cover,"0000000000000");
        }
****/

	/**** �����I���ݰe��� ****/

	if(flagPG[0] == 'G')
	{
		id[0] = '0';
       		strcpy(idno,"0000000000");
		sex[0] = '0';
       		strcpy(birth,"00000000");
		strcpy(limit,"090");
	}

	/**** �����I¾�~���O���ݰe ****/

	if(flagPG[0] == 'G' && memcmp(source, "51", 2) == 0)
		career_type[0] = '0';

	/**** �ӫO�d�� 2200 ���v���B�� 090 ��L�� 000 ****/

	if(memcmp(score, "2200", 4) == 0)
		strcpy(limit, "090");
	else
		strcpy(limit, "000");

	/**** ���_�O�_���~��H ****/
	
        if (memcmp(&ipolicy[5], "IP", 2) == 0 || memcmp(&ipolicy[5], "IJ", 2) == 0)
	{
	   if(memcmp(&idno[1], "0", 1) == 0 ||
	      memcmp(&idno[1], "1", 1) == 0 ||
	      memcmp(&idno[1], "2", 1) == 0 ||
	      memcmp(&idno[1], "3", 1) == 0 ||
	      memcmp(&idno[1], "4", 1) == 0 ||
	      memcmp(&idno[1], "5", 1) == 0 ||
	      memcmp(&idno[1], "6", 1) == 0 ||
	      memcmp(&idno[1], "7", 1) == 0 ||
	      memcmp(&idno[1], "8", 1) == 0 ||
	      memcmp(&idno[1], "9", 1) == 0)
		{
			id[0] = '1';
	                if(memcmp(&idno[1], "1", 1) == 0)
                        {
         			sex[0] = '1';
                        }
                        else
                        {
                                sex[0] = '2';
                        }

		}
		else
		{
			id[0] = '9';
			sex[0] = '1';
		}
	}

	/**** IP�H�Ƭ��@�H ****/

        if (memcmp(&ipolicy[5], "IP", 2) == 0 || memcmp(&ipolicy[5], "IJ", 2) == 0)
	{
       		strcpy(member,"00000001");
		career_type[0] = '9';
	}

        /**** TP �H�Υd ****/

        if (memcmp(&ipolicy[5], "TP", 2) == 0)
	{
       		strcpy(iproduct,"425240391911");
		flag12[0] = '2';
	}
		
        if (memcmp(source, "41", 2) == 0)
	{
       		strcpy(member,"00000000");
		id[0] = '0';
		sex[0] = '0';
	}

	if(fedr_class_into == '1')
		smembercd[0] = '-';

       	   $INSERT INTO ot_ply_edr_998
              VALUES('2',$iproduct, $flag12, $flagPG, $plycd, $ipolicy_into,
                     $edrcd, $iendorse_into, $fedr_class_into,$plydate,
                     $plybegin,$plyend,$edrdate,$edrbegin,$edrend,
                     $edrbegin,$edrend,$smembercd,$member,$id,$idno,$sex,$birth,
                     $score,$smins_covercd,$smins_cover,$limit,$mpremiumcd,$smpremium,$mpremiumcd,$smpremium_pure,
                     $career_type,$transferdate,$source);
    }
    $CLOSE cur_E1;
    $FREE  cur_E1;
printf("========END oth998_accumu_oth_edr========\n");
    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*--------------------------------------------------------------------*/

int oth998_accumu_oth_clm()
{
    $char item1[5], item2[3], item3[5], item4[2], career_type[2];
    $char iproduct[13], iins_scope[3], ipolicy[21], iclaim[21];
    $char daccident[11], dclaim[11], dgroup[11], resp_type, ireason[11];
    $char fassured, risk_area[4], dbegin[11], dend[11], pcosharecd;
    $char icareer[8], idanger_type[3], ndanger_type[5];
    $char iclaimcd[5], iclaim_into[16], iclaim_sno_into[5], txcd;
    $char plycd[5], ipolicy_into[16], daccident_into[9], dclaim_into[9];
    $char dgroup_into[7], plybegin[9], plyend[9], mins_deduct_into[13];
    $char nreason[4], pcoshare_into[6], idanger_unit[3], fsettle, iins_kind[5];
    $char nonrespamt[14] ,biaopamt[11], biaoaamt[11], pdaoaamt[11], cslamt[14];
    $char totamtcd[2], qdanger_unit_into[8];
    $double pcoshare, totamt;
    $int  iclaim_sno, qdanger_unit, i;
    $double money[4], mins_deduct, mins_cover;
    $char iins_type[5], isscd;
    char DBnameFull_2[21];

printf("========START oth998_accumu_oth_clm========\n");

    $whenever sqlerror goto errexit;

    sprintf(stmt," select e.iproduct, d.iins_scope, a.ipolicy, a.iclaim,  \
                          c.idno, c.dbirth, b.iclaim_sno, c.daccident, c.dclaim, a.dgroup, d.resp_type, \
                          b.msettle, b.mdeduct, b.mcertificate, b.mprocess, \
                          b.mlaw_acc, c.ireason, a.fsettle, b.iins_kind, d.iins_type \
                     from %s:ot_settlement a, %s:ot_stl_instype b, %s:ot_appraisal c, \
                          %s:ot_insurance d, %s:cm_product_code e \
                    where a.dgroup between ? and ? \
		      and a.ipolicy[6,7] in ('IP', 'PG', 'EP', 'TP', 'IJ') \
                      and a.mtotal != 0 \
		      and c.fnewest = 'Y' \
		      and b.iins_kind in ('EP34', 'EP35', 'EP36', 'EP37', 'TP39', 'TP40', 'IP31', 'IP32', 'IP33', 'PG31', 'PG32', 'PG33','IJ31','IJ32','IJ33','IJ41','IJ51','IJ52','IJ53','IJ54','IJ55','IJ56') \
                      and a.fdecide = '1' \
                      and a.fclose = '1' \
                      and b.iclaim = a.iclaim \
                      and b.fsettle = a.fsettle \
                      and b.iclaim_sno = a.iclaim_sno \
                      and c.iclaim = a.iclaim \
                      and c.ipolicy = a.ipolicy \
                      and d.iins_cat = 'O' \
                      and d.iins_kind = b.iins_kind \
                      and e.iins_class = 'O' \
                      and ( e.icode1 = '0' or e.icode1 = ' ') \
                      and ( e.icode2 = '0' or e.icode2 = ' ') \
                      and e.iins_type = a.ipolicy[6,7]",DBnameFull,DBnameFull,
                                        DBnameFull,DBnameFull,DBnameFull);

    $PREPARE pre_C1 FROM $stmt;
    $DECLARE cur_C1 CURSOR FOR pre_C1;
    $OPEN cur_C1 USING $datebgn, $dateend;
    while(1)
    {
        $FETCH cur_C1 INTO $iproduct, $iins_scope, $ipolicy, $iclaim,
                          $idno, $dbirth, $iclaim_sno, $daccident, $dclaim, $dgroup, $resp_type,
                          $msettle, $mdeduct, $mcertificate, $mprocess,
                          $mlaw_acc, $ireason, $fsettle, $iins_kind, $iins_type;

        if(SQLCODE == SQLNOTFOUND) break;

        strcpy(DBnameFull_2,get_dtl_full_db(ipolicy));

        sprintf(stmt," select a.fassured, a.risk_area, a.dbegin, a.dend, \
                              b.pcoshare, a.pcosharecd, a.idanger_unit, \
                              a.qdanger_unit, a.icareer, a.idanger_type, \
                              a.ndanger_type, c.mins_cover \
                         from %s:ot_ply_edr a, %s:ot_ply_share b, %s:ot_ply_edr_instype c, outer %s:ot_group_member d \
                        where a.ipolicy = ? \
                          and c.iins_kind = ? \
                          and a.ipolicy = c.ipolicy \
                          and a.ipolicy = b.ipolicy \
                          and a.fnewest = 'Y' \
                          and c.fnewest = 'Y' \
                          and a.ipolicy =  d.ipolicy \
                          and a.iendorse =  d.iendorse \
                          and a.iassured =  d.idno \
                          and a.nassured =  d.nassured \
                          and b.ipolicy =  d.ipolicy \
                          and c.ipolicy =  d.ipolicy \
                          and c.iendorse =  d.iendorse \
                          and b.icofirm = '17'",DBnameFull_2,DBnameFull_2,DBnameFull_2,DBnameFull_2);

        $PREPARE pre_C2 FROM $stmt;
        $DECLARE cur_C2 CURSOR FOR pre_C2;
        $OPEN cur_C2 USING $ipolicy, $iins_kind;
        $FETCH cur_C2 INTO $fassured, $risk_area, $dbegin, $dend,
                           $pcoshare, $pcosharecd, $idanger_unit,
                           $qdanger_unit, $icareer, $idanger_type,
                           $ndanger_type, $mins_cover;

        if(SQLCODE == SQLNOTFOUND)
        {
            printf("==========ipolicy[%s]iclaim[%s]=====\n",ipolicy,iclaim);
            fassured = 'X';
            strcpy(risk_area,"XXX");
            strcpy(dbegin,"XXXXXXXXXX");
            strcpy(dend,"XXXXXXXXXX");
            pcosharecd = 'X';
            strcpy(idanger_unit,"XX");
            strcpy(icareer,"XXXXXXX");
            strcpy(idanger_type,"XX");
            strcpy(ndanger_type,"XXXX");
            pcoshare = 0;
            qdanger_unit = 0;
            mins_cover = 0;
        }

        $CLOSE cur_C2;
        $FREE  cur_C2;

printf("======= 22222222222229 iclaim = [%s] \n\n", iclaim);
printf("======= 22222222222229 ipolicy = [%s] \n\n", ipolicy);
printf("======= 22222222222229 id = [%s] \n\n", id);
printf("======= 22222222222229 idno = [%s] \n\n", idno);
printf("======= 22222222222229 sex = [%s] \n\n", sex);
printf("======= 22222222222229 birth = [%s] \n\n", birth);

/**** 3 ****/

        if (memcmp(&ipolicy[5], "IP", 2) == 0 || memcmp(&ipolicy[5], "IJ", 2) == 0)
                flagPG[0] = 'P';
        else
                flagPG[0] = 'G';

/**** 4 ****/

        strcpy(iclaimcd,"17");
        strncat(iclaimcd,iclaim,2);
        iclaimcd[4]='\0';

        strncpy(iclaim_into,&iclaim[3],11);
        iclaim_into[11] = '\0';
        strcat(iclaim_into,"    ");
        iclaim_into[15] = '\0';

        if (risnull(SQLINT, &iclaim_sno) == 1) strcpy(iclaim_sno_into,"0000");
        else sprintf(iclaim_sno_into,"%04d",iclaim_sno);
        iclaim_sno_into[4] = '\0';

/**** 5 ****/

        strcpy(plycd,"17");
        strncat(plycd,ipolicy,2);
        plycd[4]='\0';

        strncpy(ipolicy_into,&ipolicy[3],10);
        ipolicy_into[10] = '\0';
        strcat(ipolicy_into,"     ");
        ipolicy_into[15] = '\0';

/**** 6 ****/

        if (risnull(SQLCHAR,daccident) != 1)
        {
            strncpy(daccident_into,  &daccident[6], 4);
            daccident_into[4] = '\0';
            strncat(daccident_into, &daccident[0], 2);
            daccident_into[6] = '\0';
            strncat(daccident_into, &daccident[3], 2);
        }
        else strcpy(daccident_into, "00000000");
        daccident_into[8] = '\0';

        if (risnull(SQLCHAR,dclaim) != 1)
        {
            strncpy(dclaim_into,  &dclaim[6], 4);
            dclaim_into[4] = '\0';
            strncat(dclaim_into, &dclaim[0], 2);
            dclaim_into[6] = '\0';
            strncat(dclaim_into, &dclaim[3], 2);
        }
        else strcpy(dclaim_into, "00000000");
        dclaim_into[8] = '\0';

        strncpy(dgroup_into,  &dgroup[6], 4);
        dgroup_into[4] = '\0';
        strncat(dgroup_into, &dgroup[0], 2);
        dgroup_into[6] = '\0';

/**** 7 ****/

        if (risnull(SQLCHAR,dbegin) != 1)
        {
            strncpy(plybegin,  &dbegin[6], 4);
            plybegin[4] = '\0';
            strncat(plybegin, &dbegin[0], 2);
            plybegin[6] = '\0';
            strncat(plybegin, &dbegin[3], 2);
        }
        else strcpy(plybegin, "00000000");
        plybegin[8] = '\0';

        if (risnull(SQLCHAR,dend) != 1)
        {
            strncpy(plyend,  &dend[6], 4);
            plyend[4] = '\0';
            strncat(plyend, &dend[0], 2);
            plyend[6] = '\0';
            strncat(plyend, &dend[3], 2);
        }
        else strcpy(plyend, "00000000");
        plyend[8] = '\0';

/**** 8 ****/

	if (memcmp(&ipolicy[5], "IP", 2) == 0 ||
	    memcmp(&ipolicy[5], "PG", 2) == 0)
        {
                id[0] = '1';
        }
	else
        {
                id[0] = '0';
        }

/**** 9 ****/

       if (memcmp(&idno[1], "1", 1) == 0)
       {
                sex[0] = '1';
       }
       else
       {
                sex[0] = '2';
       }

/**** 10 ****/

        if (risnull(SQLCHAR,dbirth) != 1)
        {
            strncpy(birth,  &dbirth[6], 4);
            birth[4] = '\0';
            strncat(birth, &dbirth[0], 2);
            birth[6] = '\0';
            strncat(birth, &dbirth[3], 2);
        }
        else strcpy(birth, "00000000");
        birth[8] = '\0';


/**** 11 ****/

        strcpy(ireason,trim(ireason));
        strncpy(nreason,ireason,3);
        nreason[3] = '\0';

/**** 15 ****/

	if(msettle >= 0)
	{
		msettlecd[0] = '+';
	}
	else
	{
		msettlecd[0] = '-';
		msettle = msettle * -1;
	}

        sprintf(smsettle,"%013.0f",msettle);

/**** 16 ****/

        if (memcmp(&iins_kind[2], "31", 2) == 0 ||
            memcmp(&iins_kind[2], "32", 2) == 0 ||
            memcmp(&iins_kind[2], "33", 2) == 0)
        {
                flag12[0] = '1';
        }
        else
        {
                flag12[0] = '2';
        }

/**** 17 ****/

	totamt = mdeduct + mcertificate + mprocess + mlaw_acc;

	if(totamt >= 0)
	{
		totamtcd[0] = '+';
	}
	else
	{
		totamtcd[0] = '-';
		totamt = totamt * -1;
	}

        sprintf(stotamt,"%08.0f",totamt);

/**** 20 *****/

	$select type
	   into $career_type
	   from ot_career
	  where icareer = $icareer;

        if (memcmp(&ipolicy[5], "PG", 2) == 0 ||
            memcmp(&ipolicy[5], "EP", 2) == 0 ||
            memcmp(&ipolicy[5], "TP", 2) == 0 ||
            memcmp(&ipolicy[5], "PA", 2) == 0 ||
            memcmp(&ipolicy[5], "TS", 2) == 0 ||
            memcmp(&ipolicy[5], "TY", 2) == 0 ||
            memcmp(&ipolicy[5], "TC", 2) == 0 ||
            memcmp(&ipolicy[5], "TA", 2) == 0)
        {
                career_type[0] = '0';
        }
        else
        {
                career_type[0] = '9';
        }

	if(memcmp(&iins_kind[2], "31", 2) == 0 || 
	   memcmp(&iins_kind[2], "34", 2) == 0 ||
   	   memcmp(&iins_kind[2], "40", 2) == 0)
	{
		flag12[0] = '1';
		memcpy(item1, "0100", 4);
		memcpy(item2, "02", 2);
		memcpy(item3, "0100", 4);
		memcpy(item4, "1", 1);
		item1[4] = '\0';
		item2[2] = '\0';
		item3[4] = '\0';
		item4[1] = '\0';
	}

	if(memcmp(&iins_kind[2], "32", 2) == 0 || 
	   memcmp(&iins_kind[2], "35", 2) == 0 ||
   	   memcmp(&iins_kind[2], "39", 2) == 0)
	{
		flag12[0] = '2';
		memcpy(item1, "2100", 4);
		memcpy(item2, "21", 2);
		memcpy(item3, "0001", 4);
		memcpy(item4, "2", 1);
		item1[4] = '\0';
		item2[2] = '\0';
		item3[4] = '\0';
		item4[1] = '\0';
	}

	if(memcmp(&iins_kind[2], "33", 2) == 0 || 
   	   memcmp(&iins_kind[2], "36", 2) == 0)
	{
		flag12[0] = '2';
		memcpy(item1, "2200", 4);
		memcpy(item2, "22", 2);
		memcpy(item3, "0001", 4);
		memcpy(item4, "2", 1);
		item1[4] = '\0';
		item2[2] = '\0';
		item3[4] = '\0';
		item4[1] = '\0';
	}

	if(memcmp(&iins_kind[2], "37", 2) == 0)
	{
		flag12[0] = '2';
		memcpy(item1, "2302", 4);
		memcpy(item2, "23", 2);
		memcpy(item3, "2302", 4);
		memcpy(item4, "2", 1);
		item1[4] = '\0';
		item2[2] = '\0';
		item3[4] = '\0';
		item4[1] = '\0';
	}

        if(memcmp(&iins_kind[2], "41", 2) == 0 ||
           memcmp(&iins_kind[2], "51", 2) == 0 ||
 	   memcmp(&iins_kind[2], "52", 2) == 0 ||
 	   memcmp(&iins_kind[2], "53", 2) == 0 ||
 	   memcmp(&iins_kind[2], "54", 2) == 0 ||
 	   memcmp(&iins_kind[2], "55", 2) == 0 ||
           memcmp(&iins_kind[2], "56", 2) == 0)
        {
		flag12[0] = '1';
		memcpy(item1, "0102", 4);
		memcpy(item2, "02", 2);
		memcpy(item3, "0100", 4);
		memcpy(item4, "1", 1);
		item1[4] = '\0';
		item2[2] = '\0';
		item3[4] = '\0';
		item4[1] = '\0';
        }

	if(memcmp(&iins_kind[2], "34", 2) == 0)
	{
		flag12[0] = '2';
	}

	strcpy(smins_cover,"0000000000000");
	sprintf(smins_cover,"%013.0f",mins_cover);

	if (memcmp(&ipolicy[5], "IP", 2) == 0 ||
	    memcmp(&ipolicy[5], "PG", 2) == 0 ||
	    memcmp(&ipolicy[5], "IJ", 2) == 0 ||
	    memcmp(&ipolicy[5], "PG", 2) == 0)
	{
		strcpy(source,"51");
	}
	else
	{
		strcpy(source,"41");
	}

	/**** �~�Ȩӷ��� 41 �Ĥ@���q���ݿ��s��� ****/

/****
        if (memcmp(source, "41", 2) == 0)
        {
		flagPG[0] = '0';
       		strcpy(dclaim_into,"00000000");
       		strcpy(dgroup_into,"000000");
		id[0] = '0';
       		strcpy(idno,"0000000000");
		sex[0] = '0';
       		strcpy(dbirth,"00000000");
       		strcpy(score,"0000");
       		strcpy(item1,"0000");
       		strcpy(item2,"00");
       		strcpy(item3,"0000");
		career_type[0] = '0';
       		strcpy(smins_cover,"0000000000000");
       		strcpy(plyend,"00000000");
	}
****/

	/**** �X�I��]�ȥΦ������覡 ****/

	if((memcmp(iins_kind, "TP39", 4) == 0) ||
	   (memcmp(iins_kind, "TP40", 4) == 0) ||
	   (memcmp(iins_kind, "IP32", 4) == 0) ||
	   (memcmp(iins_kind, "IP33", 4) == 0))
		strcpy(nreason, "960");

	if((memcmp(iins_kind, "EP34", 4) == 0) ||
	   (memcmp(iins_kind, "PG31", 4) == 0) ||
	   (memcmp(iins_kind, "IP31", 4) == 0))
		strcpy(nreason, "880");

	if((memcmp(iins_kind, "EP35", 4) == 0) ||
	   (memcmp(iins_kind, "EP37", 4) == 0) ||
	   (memcmp(iins_kind, "PG32", 4) == 0))
		strcpy(nreason, "881");

	if((memcmp(iins_kind, "PG33", 4) == 0))
		strcpy(nreason, "970");

	if((memcmp(iins_kind, "EP36", 4) == 0))
		strcpy(nreason, "920");

        if((memcmp(nreason, "960", 3) != 0) &&
           (memcmp(nreason, "880", 3) != 0) &&
           (memcmp(nreason, "881", 3) != 0) &&
           (memcmp(nreason, "970", 3) != 0) &&
           (memcmp(nreason, "920", 3) != 0))
	{
		strcpy(nreason, "920");
	}

	   if(memcmp(&idno[1], "0", 1) == 0 ||
	      memcmp(&idno[1], "1", 1) == 0 ||
	      memcmp(&idno[1], "2", 1) == 0 ||
	      memcmp(&idno[1], "3", 1) == 0 ||
	      memcmp(&idno[1], "4", 1) == 0 ||
	      memcmp(&idno[1], "5", 1) == 0 ||
	      memcmp(&idno[1], "6", 1) == 0 ||
	      memcmp(&idno[1], "7", 1) == 0 ||
	      memcmp(&idno[1], "8", 1) == 0 ||
	      memcmp(&idno[1], "9", 1) == 0)
		{
			id[0] = '1';
			if(memcmp(&idno[1], "1", 1) == 0)
			{
				sex[0] = '1';
			}
			else
			{
				sex[0] = '2';
			}
		}
		else
		{
			id[0] = '9';
			sex[0] = '1';
		}

printf("======= 1111111111111 iclaim = [%s] \n\n", iclaim);
printf("======= 1111111111111 ipolicy = [%s] \n\n", ipolicy);
printf("======= 1111111111111 id = [%s] \n\n", id);
printf("======= 1111111111111 idno = [%s] \n\n", idno);
printf("======= 1111111111111 sex = [%s] \n\n", sex);
printf("======= 1111111111111 birth = [%s] \n\n", birth);

        /**** TP �H�Υd ****/

        if (memcmp(&ipolicy[5], "TP", 2) == 0)
	{
       		strcpy(iproduct,"425240391911");
		flag12[0] = '2';
	}
	
	/**** �����I and �~�Ȩӷ� 41 ���ݰe��� ****/

/****
	if(flagPG[0] == '0' && memcmp(source, "41", 2) == 0)
	{
		id[0] = '0';
       		strcpy(idno,"0000000000");
		sex[0] = '0';
       		strcpy(birth,"00000000");
		career_type[0] = '0';
	}
****/

        $INSERT INTO ot_app_stl_998
                 VALUES('1',$iproduct, $flag12,$flagPG, $iclaimcd, $iclaim_into,
                          $iclaim_sno_into, $plycd, $ipolicy_into,
                          $daccident_into, $dclaim_into, $dgroup_into,
                          $plybegin, $plyend, $id, $idno, $sex, $birth,
                          $nreason, '1', 'S', $item1,
                          $msettlecd, $smsettle, $totamtcd, $stotamt,
                          $item2,$item3,$career_type,
                          $transferdate,$smins_cover,$source);

printf("===oth998_accumu_oth_clm insert compelete====\n");

    }
    $CLOSE cur_C1;
    $FREE  cur_C1;
printf("========END oth998_accumu_oth_clm========\n");


    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*--------------------------------------------------------------------*/
int oth998_accumu_oth_out()
 {
    $char item1[5], item2[3], item3[5], item4[2], career_type[2];
    $char iproduct[13], iins_scope[3], ipolicy[21], iclaim[21];
    $char daccident[11], dclaim[11], dgroup[11], resp_type, ireason[11];
    $char fassured, risk_area[4], dbegin[11], dend[11], pcosharecd;
    $char icareer[8], idanger_type[3], ndanger_type[5];
    $char iclaimcd[5], iclaim_into[16], iclaim_sno_into[5], txcd, fdecide;
    $char plycd[5], ipolicy_into[16], daccident_into[9], dclaim_into[9];
    $char dgroup_into[7], plybegin[9], plyend[9];
    $char nreason[4], pcoshare_into[6], idanger_unit[3], iins_kind[5];
    $char nonrespamt[14] ,biaopamt[11], biaoaamt[11], pdaoaamt[11], cslamt[14];
    $char qdanger_unit_into[8], fclose;
    $char iins_type[5], isscd, totamtcd[2];
    $double pcoshare, totamt;
    $int  iclaim_sno, qdanger_unit, i;
    $double money, money_p, mins_cover, mestimate;

    char DBnameFull_2[21];

printf("========START oth998_accumu_oth_out========\n");
    $whenever sqlerror goto errexit;

    sprintf(stmt," select d.iproduct, c.iins_scope, a.ipolicy, a.iclaim,  \
                          a.daccident, a.dclaim, a.destimate, c.resp_type, \
                          b.mestimate, a.ireason, b.iins_kind ,a.fclose, c.iins_type \
                     from %s:ot_appraisal a, %s:ot_app_instype b, \
                          %s:ot_insurance c, %s:cm_product_code d \
                    where a.dclaim <= ? \
		      and a.ipolicy[6,7] in ('IP', 'PG', 'EP', 'TP', 'IJ') \
                      and (a.dgroup is null or a.dgroup > ?) \
		      and b.iins_kind in ('EP34', 'EP35', 'EP36', 'EP37', 'TP39', 'TP40', 'IP31', 'IP32', 'IP33', 'PG31', 'PG32', 'PG33','IJ31','IJ32','IJ33','IJ41','IJ51','IJ52','IJ53','IJ54','IJ55','IJ56') \
                      and b.mestimate != 0 \
                      and b.iclaim = a.iclaim \
		      and a.fnewest = 'Y' \
		      and b.fnewest = 'Y' \
                      and c.iins_cat = 'O' \
                      and c.iins_kind = b.iins_kind \
                      and d.iins_class = 'O' \
                      and ( d.icode1 = '0' or d.icode1 = ' ') \
                      and ( d.icode2 = '0' or d.icode2 = ' ') \
                      and d.iins_type = a.ipolicy[6,7]",DBnameFull,DBnameFull,
                                        DBnameFull,DBnameFull);

    $PREPARE pre_O1 FROM $stmt;
    $DECLARE cur_O1 CURSOR FOR pre_O1;
    $OPEN cur_O1 USING $dateend, $dateend;
    while(1)
    {
        $FETCH cur_O1 INTO $iproduct, $iins_scope, $ipolicy, $iclaim,
                           $daccident, $dclaim, $dgroup, $resp_type,
                           $mestimate, $ireason, $iins_kind, $fclose, $iins_type;


        if(SQLCODE == SQLNOTFOUND) break;

        strcpy(DBnameFull_2,get_dtl_full_db(ipolicy));
        sprintf(stmt," select a.fassured, a.risk_area, a.dbegin, a.dend, \
                              b.pcoshare, a.pcosharecd, a.idanger_unit, \
                              a.qdanger_unit, a.icareer, a.idanger_type, \
			      d.idno, d.dbirth, \
                              a.ndanger_type, c.mins_cover \
                         from %s:ot_ply_edr a, %s:ot_ply_share b, %s:ot_ply_edr_instype c, outer %s:ot_group_member d \
                        where a.ipolicy = ? \
                          and c.iins_kind = ? \
                          and a.ipolicy = c.ipolicy \
                          and a.ipolicy = b.ipolicy \
                          and a.fnewest = 'Y' \
                          and c.fnewest = 'Y' \
			  and a.ipolicy =  d.ipolicy \
                          and a.iendorse =  d.iendorse \
                          and a.iassured =  d.idno \
                          and a.nassured =  d.nassured \
                          and b.ipolicy =  d.ipolicy \
                          and c.ipolicy =  d.ipolicy \
                          and c.iendorse =  d.iendorse \
                          and b.icofirm = '17'",DBnameFull_2,DBnameFull_2,DBnameFull_2, DBnameFull);
        $PREPARE pre_O2 FROM $stmt;
        $DECLARE cur_O2 CURSOR FOR pre_O2;
        $OPEN cur_O2 USING $ipolicy, $iins_kind;
        $FETCH cur_O2 INTO $fassured, $risk_area, $dbegin, $dend,
                           $pcoshare, $pcosharecd, $idanger_unit,
                           $qdanger_unit, $icareer, $idanger_type,
			   $idno, $dbirth,
                           $ndanger_type, $mins_cover;
        if(SQLCODE == SQLNOTFOUND)
        {
            printf("==========ipolicy[%s]iclaim[%s]=====\n",ipolicy,iclaim);
            fassured = 'X';
            strcpy(risk_area,"XXX");
            strcpy(dbegin,"XXXXXXXXXX");
            strcpy(dend,"XXXXXXXXXX");
            pcosharecd = 'X';
            strcpy(idanger_unit,"XX");
            strcpy(icareer,"XXXXXXX");
            strcpy(idanger_type,"XX");
            strcpy(ndanger_type,"XXXX");
            pcoshare = 0;
            qdanger_unit = 0;
            mins_cover = 0;
        }
        $CLOSE cur_O2;
        $FREE  cur_O2;

/**** 3 ****/

        if (memcmp(&ipolicy[5], "IP", 2) == 0 || memcmp(&ipolicy[5], "IJ", 2) == 0)
                flagPG[0] = 'P';
        else
                flagPG[0] = 'G';

/**** 4 ****/

        strcpy(iclaimcd,"17");
        strncat(iclaimcd,iclaim,2);
        iclaimcd[4]='\0';

        strncpy(iclaim_into,&iclaim[3],11);
        iclaim_into[11] = '\0';
        strcat(iclaim_into,"    ");
        iclaim_into[15] = '\0';

/****
        if (risnull(SQLINT, &iclaim_sno) == 1) strcpy(iclaim_sno_into,"0001");
        else sprintf(iclaim_sno_into,"%04d",iclaim_sno);
        iclaim_sno_into[4] = '\0';
****/
	strcpy(iclaim_sno_into,"0000");

/**** 5 ****/

        strcpy(plycd,"17");
        strncat(plycd,ipolicy,2);
        plycd[4]='\0';

        strncpy(ipolicy_into,&ipolicy[3],10);
        ipolicy_into[10] = '\0';
        strcat(ipolicy_into,"     ");
        ipolicy_into[15] = '\0';

/**** 6 ****/

        if (risnull(SQLCHAR,daccident) != 1)
        {
            strncpy(daccident_into,  &daccident[6], 4);
            daccident_into[4] = '\0';
            strncat(daccident_into, &daccident[0], 2);
            daccident_into[6] = '\0';
            strncat(daccident_into, &daccident[3], 2);
        }
        else strcpy(daccident_into, "00000000");
        daccident_into[8] = '\0';

        if (risnull(SQLCHAR,dclaim) != 1)
        {
            strncpy(dclaim_into,  &dclaim[6], 4);
            dclaim_into[4] = '\0';
            strncat(dclaim_into, &dclaim[0], 2);
            dclaim_into[6] = '\0';
            strncat(dclaim_into, &dclaim[3], 2);
        }
        else strcpy(dclaim_into, "00000000");
        dclaim_into[8] = '\0';

        strncpy(dgroup_into,  &dgroup[6], 4);
        dgroup_into[4] = '\0';
        strncat(dgroup_into, &dgroup[0], 2);
        dgroup_into[6] = '\0';

/**** 7 ****/

        if (risnull(SQLCHAR,dbegin) != 1)
        {
            strncpy(plybegin,  &dbegin[6], 4);
            plybegin[4] = '\0';
            strncat(plybegin, &dbegin[0], 2);
            plybegin[6] = '\0';
            strncat(plybegin, &dbegin[3], 2);
        }
        else strcpy(plybegin, "00000000");
        plybegin[8] = '\0';

        if (risnull(SQLCHAR,dend) != 1)
        {
            strncpy(plyend,  &dend[6], 4);
            plyend[4] = '\0';
            strncat(plyend, &dend[0], 2);
            plyend[6] = '\0';
            strncat(plyend, &dend[3], 2);
        }
        else strcpy(plyend, "00000000");
        plyend[8] = '\0';

/**** 8 ****/

	if (memcmp(&ipolicy[5], "IP", 2) == 0 ||
	    memcmp(&ipolicy[5], "PG", 2) == 0)
        {
                id[0] = '1';
        }
	else
        {
                id[0] = '0';
        }

/**** 9 ****/

       if (memcmp(&idno[1], "1", 1) == 0)
       {
                sex[0] = '1';
       }
       else
       {
                sex[0] = '2';
       }

/**** 10 ****/

        if (risnull(SQLCHAR,dbirth) != 1)
        {
            strncpy(birth,  &dbirth[6], 4);
            birth[4] = '\0';
            strncat(birth, &dbirth[0], 2);
            birth[6] = '\0';
            strncat(birth, &dbirth[3], 2);
        }
        else strcpy(birth, "00000000");
        birth[8] = '\0';


/**** 11 ****/

        strcpy(ireason,trim(ireason));
        strncpy(nreason,ireason,3);
        nreason[3] = '\0';

/**** 15 ****/

	if(msettle >= 0)
	{
		msettlecd[0] = '+';
	}
	else
	{
		msettlecd[0] = '-';
		msettle = msettle * -1;
	}

        sprintf(smsettle,"%013.0f",msettle);

/**** 16 ****/

        if (memcmp(&iins_kind[2], "31", 2) == 0 ||
            memcmp(&iins_kind[2], "32", 2) == 0 ||
            memcmp(&iins_kind[2], "33", 2) == 0)
        {
                flag12[0] = '1';
        }
        else
        {
                flag12[0] = '2';
        }

/**** 17 ****/

	totamt = mdeduct + mcertificate + mprocess + mlaw_acc;

	if(totamt >= 0)
	{
		totamtcd[0] = '+';
	}
	else
	{
		totamtcd[0] = '-';
		totamt = totamt * -1;
	}

        sprintf(stotamt,"%08.0f",totamt);

/**** 20 *****/

	$select type
	   into $career_type
	   from ot_career
	  where icareer = $icareer;

        if (memcmp(&ipolicy[5], "PG", 2) == 0 ||
            memcmp(&ipolicy[5], "EP", 2) == 0 ||
            memcmp(&ipolicy[5], "TP", 2) == 0 ||
            memcmp(&ipolicy[5], "PA", 2) == 0 ||
            memcmp(&ipolicy[5], "TS", 2) == 0 ||
            memcmp(&ipolicy[5], "TY", 2) == 0 ||
            memcmp(&ipolicy[5], "TC", 2) == 0 ||
            memcmp(&ipolicy[5], "TA", 2) == 0)
        {
                career_type[0] = '0';
        }
        else
        {
                career_type[0] = '9';
        }

	if(memcmp(&iins_kind[2], "31", 2) == 0 || 
	   memcmp(&iins_kind[2], "34", 2) == 0 ||
   	   memcmp(&iins_kind[2], "40", 2) == 0)
	{
		flag12[0] = '1';
		memcpy(item1, "0100", 4);
		memcpy(item2, "02", 2);
		memcpy(item3, "0100", 4);
		memcpy(item4, "1", 1);
		item1[4] = '\0';
		item2[2] = '\0';
		item3[4] = '\0';
		item4[1] = '\0';
	}

	if(memcmp(&iins_kind[2], "32", 2) == 0 || 
	   memcmp(&iins_kind[2], "35", 2) == 0 ||
   	   memcmp(&iins_kind[2], "39", 2) == 0)
	{
		flag12[0] = '2';
		memcpy(item1, "2100", 4);
		memcpy(item2, "21", 2);
		memcpy(item3, "0001", 4);
		memcpy(item4, "2", 1);
		item1[4] = '\0';
		item2[2] = '\0';
		item3[4] = '\0';
		item4[1] = '\0';
	}

	if(memcmp(&iins_kind[2], "33", 2) == 0 || 
   	   memcmp(&iins_kind[2], "36", 2) == 0)
	{
		flag12[0] = '2';
		memcpy(item1, "2200", 4);
		memcpy(item2, "22", 2);
		memcpy(item3, "0001", 4);
		memcpy(item4, "2", 1);
		item1[4] = '\0';
		item2[2] = '\0';
		item3[4] = '\0';
		item4[1] = '\0';
	}

	if(memcmp(&iins_kind[2], "37", 2) == 0)
	{
		flag12[0] = '2';
		memcpy(item1, "2302", 4);
		memcpy(item2, "23", 2);
		memcpy(item3, "2302", 4);
		memcpy(item4, "2", 1);
		item1[4] = '\0';
		item2[2] = '\0';
		item3[4] = '\0';
		item4[1] = '\0';
	}

        if(memcmp(&iins_kind[2], "41", 2) == 0 ||
           memcmp(&iins_kind[2], "51", 2) == 0 ||
 	   memcmp(&iins_kind[2], "52", 2) == 0 ||
 	   memcmp(&iins_kind[2], "53", 2) == 0 ||
 	   memcmp(&iins_kind[2], "54", 2) == 0 ||
 	   memcmp(&iins_kind[2], "55", 2) == 0 ||
           memcmp(&iins_kind[2], "56", 2) == 0)
        {
		flag12[0] = '1';
		memcpy(item1, "0102", 4);
		memcpy(item2, "02", 2);
		memcpy(item3, "0100", 4);
		memcpy(item4, "1", 1);
		item1[4] = '\0';
		item2[2] = '\0';
		item3[4] = '\0';
		item4[1] = '\0';
        }

	if(memcmp(&iins_kind[2], "34", 2) == 0)
	{
		flag12[0] = '2';
	}

	strcpy(smins_cover,"0000000000000");
	sprintf(smins_cover,"%013.0f",mins_cover);

	if (memcmp(&ipolicy[5], "IP", 2) == 0 ||
	    memcmp(&ipolicy[5], "PG", 2) == 0 ||
	    memcmp(&ipolicy[5], "IJ", 2) == 0 ||
	    memcmp(&ipolicy[5], "PG", 2) == 0)
	{
		strcpy(source,"51");
	}
	else
	{
		strcpy(source,"41");
	}

	/**** �~�Ȩӷ��� 41 �Ĥ@���q���ݿ��s��� ****/

        if (memcmp(source, "41", 2) == 0)
        {
		flagPG[0] = '0';
       		strcpy(dclaim_into,"00000000");
       		strcpy(dgroup_into,"000000");
		id[0] = '0';
       		strcpy(idno,"0000000000");
		sex[0] = '0';
       		strcpy(dbirth,"00000000");
       		strcpy(score,"0000");
       		strcpy(item1,"0000");
       		strcpy(item2,"00");
       		strcpy(item3,"0000");
		career_type[0] = '0';
       		strcpy(smins_cover,"0000000000000");
       		strcpy(plyend,"00000000");
	}

	/**** �X�I��]�ȥΦ������覡 ****/

	if((memcmp(iins_kind, "TP39", 4) == 0) ||
	   (memcmp(iins_kind, "TP40", 4) == 0) ||
	   (memcmp(iins_kind, "IP32", 4) == 0) ||
	   (memcmp(iins_kind, "IP33", 4) == 0))
		strcpy(nreason, "960");

	if((memcmp(iins_kind, "EP34", 4) == 0) ||
	   (memcmp(iins_kind, "PG31", 4) == 0) ||
	   (memcmp(iins_kind, "IP31", 4) == 0))
		strcpy(nreason, "880");

	if((memcmp(iins_kind, "EP35", 4) == 0) ||
	   (memcmp(iins_kind, "EP37", 4) == 0) ||
	   (memcmp(iins_kind, "PG32", 4) == 0))
		strcpy(nreason, "881");

	if((memcmp(iins_kind, "PG33", 4) == 0))
		strcpy(nreason, "970");

	if((memcmp(iins_kind, "EP36", 4) == 0))
		strcpy(nreason, "920");

        if((memcmp(nreason, "960", 3) != 0) &&
           (memcmp(nreason, "880", 3) != 0) &&
           (memcmp(nreason, "881", 3) != 0) &&
           (memcmp(nreason, "970", 3) != 0) &&
           (memcmp(nreason, "920", 3) != 0))
	{
		strcpy(nreason, "920");
	}

	   if(memcmp(&idno[1], "0", 1) == 0 ||
	      memcmp(&idno[1], "1", 1) == 0 ||
	      memcmp(&idno[1], "2", 1) == 0 ||
	      memcmp(&idno[1], "3", 1) == 0 ||
	      memcmp(&idno[1], "4", 1) == 0 ||
	      memcmp(&idno[1], "5", 1) == 0 ||
	      memcmp(&idno[1], "6", 1) == 0 ||
	      memcmp(&idno[1], "7", 1) == 0 ||
	      memcmp(&idno[1], "8", 1) == 0 ||
	      memcmp(&idno[1], "9", 1) == 0)
		{
			id[0] = '1';
			if(memcmp(&idno[1], "1", 1) == 0)
			{
				sex[0] = '1';
			}
			else
			{
				sex[0] = '2';
			}
		}
		else
		{
			id[0] = '9';
			sex[0] = '1';
		}

printf("======= 1111111111111 iclaim = [%s] \n\n", iclaim);
printf("======= 1111111111111 ipolicy = [%s] \n\n", ipolicy);
printf("======= 1111111111111 id = [%s] \n\n", id);
printf("======= 1111111111111 idno = [%s] \n\n", idno);
printf("======= 1111111111111 sex = [%s] \n\n", sex);
printf("======= 1111111111111 birth = [%s] \n\n", birth);

        /**** TP �H�Υd ****/

        if (memcmp(&ipolicy[5], "TP", 2) == 0)
	{
       		strcpy(iproduct,"425240391911");
		flag12[0] = '2';
	}
	
	/**** �����I and �~�Ȩӷ� 41 ���ݰe��� ****/

	if(flagPG[0] == '0' && memcmp(source, "41", 2) == 0)
	{
		id[0] = '0';
       		strcpy(idno,"0000000000");
		sex[0] = '0';
       		strcpy(birth,"00000000");
		career_type[0] = '0';
	}

	if(memcmp(source, "51", 2) == 0)
		strcpy(dgroup_into,"200412");
	else
       		strcpy(dgroup_into,"000000");

        $INSERT INTO ot_app_stl_998
                 VALUES('2',$iproduct, $flag12,$flagPG, $iclaimcd, $iclaim_into,
                          $iclaim_sno_into, $plycd, $ipolicy_into,
                          $daccident_into, $dclaim_into, $dgroup_into,
                          $plybegin, $plyend, $id, $idno, $sex, $birth,
                          $nreason, '2', 'U', $item1,
                          $msettlecd, $smsettle, $totamtcd, $stotamt,
                          $item2,$item3,$career_type,
                          $transferdate,$smins_cover,$source);
printf("===oth998_accumu_oth_out insert compelete====\n");
    }
    $CLOSE cur_O1;
    $FREE  cur_O1;
printf("========END oth998_accumu_oth_out========\n");
    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
 }

/*--------------------------------------------------------------------------*/
int ot998_P()

{
    $char plyedrcd[2], iproduct[13], iins_scope[3];
    $char plycd[5], ipolicy[16], card[11], edrcd[5], iendorse[16];
    $char risk_area[4], fedr_class[2], plydate[9], plybegin[9];
    $char plyend[9], edrdate[9], edrbegin[9], edrend[9];
    $char ddanger_begin[9], ddanger_end[9], nonrespcd[2], nonrespamt[14];
    $char biaopcd[2], biaopamt[11], biaoacd[2], biaoaamt[11];
    $char pdaoacd[2],  pdaoaamt[11], cslcd[2], cslamt[14];
    $char mins_deductcd[2], mins_deduct[7], sharecd[2], pcoshare[6];
    $char mpremcd[2], mprem[14],sharemprem[11], sprem_rule[2];
    $char pprem_rule[4], idanger_unit[3], qdanger_unit[8], icareer[8];
    $char idanger_type[3], ndanger_type[5];
    $char pure_mpremcd[2], pure_mprem[11],pure_sharemprem[11];

printf("========START ot998_P========\n");
    $WHENEVER ERROR GOTO errexit;

    $DECLARE P_cur CURSOR for SELECT * FROM ot_ply_edr_998 WHERE plyedrcd = '1';

    $OPEN  P_cur;

    for (;;)
    {
       $FETCH P_cur
         INTO $plyedrcd, $iproduct, $flag12, $flagPG, $plycd, $ipolicy,
              $edrcd, $iendorse, $fedr_class, $plydate,
              $plybegin, $plyend, $edrdate, $edrbegin, $edrend, $date1,
              $date2, $flagno, $member, $id, $idno,
              $sex, $birth, $score, $mpremcd, $mprem, $limit,
              $amtcd1, $amt1, $amtcd2, $amt2,
              $workno, $transferdate, $type;

        if (SQLCODE==SQLNOTFOUND) break;

        print_cnt ++;

        if (amtcd1[0] == '+')
        {
           print_amt += atoi(amt1);
           pure_print_amt += atoi(amt2);
        }
        else
        {
           print_amt -= atoi(mprem);
           pure_print_amt -= atoi(amt2);
        }

        flen_P =  fprintf(fp_P,"%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s\n",
         iproduct, flag12, flagPG, plycd, ipolicy,
              edrcd, iendorse, fedr_class, plydate,
              plybegin, plyend, edrdate, edrbegin, edrend, date1,
              date2, flagno, member, id, idno,
              sex, birth, score, mpremcd, mprem, limit,
              amtcd1, amt1, amtcd2, amt2,
              workno, transferdate, type);
    }
    $CLOSE P_cur;
    $FREE  P_cur;

    sprintf(msgbuf,"%s��L�I�O��:���[%d]���B[%ld]�«O�O[%ld]\n",msgbuf,print_cnt,print_amt,pure_print_amt);
printf("========END ot998_P========\n");
    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
 }

/*--------------------------------------------------------------------------*/

int ot998_E()
{
    $char plyedrcd[2], iproduct[13], iins_scope[3];
    $char plycd[5], ipolicy[16], card[11], edrcd[5], iendorse[16];
    $char risk_area[4], fedr_class[2], plydate[9], plybegin[9];
    $char plyend[9], edrdate[9], edrbegin[9], edrend[9];
    $char ddanger_begin[9], ddanger_end[9], nonrespcd[2], nonrespamt[14];
    $char biaopcd[2], biaopamt[11], biaoacd[2], biaoaamt[11];
    $char pdaoacd[2],  pdaoaamt[11], cslcd[2], cslamt[14];
    $char mins_deductcd[2], mins_deduct[7], sharecd[2], pcoshare[6];
    $char mpremcd[2], mprem[14],sharemprem[11], sprem_rule[2];
    $char pprem_rule[4], idanger_unit[3], qdanger_unit[8], icareer[8];
    $char idanger_type[3], ndanger_type[5];
    $char pure_mpremcd[2], pure_mprem[11],pure_sharemprem[11];

printf("========START ot998_E========\n");
    $WHENEVER ERROR GOTO errexit;

    $DECLARE E_cur CURSOR for SELECT * FROM ot_ply_edr_998 WHERE plyedrcd = '2';

    $OPEN  E_cur;

    for (;;)
    {
       $FETCH E_cur
         INTO $plyedrcd, $iproduct, $flag12, $flagPG, $plycd, $ipolicy,
              $edrcd, $iendorse, $fedr_class, $plydate,
              $plybegin, $plyend, $edrdate, $edrbegin, $edrend, $date1,
              $date2, $flagno, $member, $id, $idno,
              $sex, $birth, $score, $mpremcd, $mprem, $limit,
              $amtcd1, $amt1, $amtcd2, $amt2,
              $workno, $transferdate, $type;

        if (SQLCODE==SQLNOTFOUND) break;

        print_cnt ++;

        if (amtcd1[0] == '+')
        {
	   print_amt += atoi(amt1);
           pure_print_amt += atoi(amt2);
        }
        else
        {
	   print_amt -= atoi(amt1);
           pure_print_amt -= atoi(amt2);
        }

        flen_E =  fprintf(fp_E,"%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s\n",
          iproduct, flag12, flagPG, plycd, ipolicy,
              edrcd, iendorse, fedr_class, plydate,
              plybegin, plyend, edrdate, edrbegin, edrend, date1,
              date2, flagno, member, id, idno,
              sex, birth, score, mpremcd, mprem, limit,
              amtcd1, amt1, amtcd2, amt2,
              workno, transferdate, type);
    }
    $CLOSE E_cur;
    $FREE  E_cur;

    sprintf(msgbuf,"%s��L�I���:���[%d]���B[%ld]�«O�O[%ld]\n",msgbuf,print_cnt,print_amt,pure_print_amt);
printf("========END ot998_E========\n");
    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*---------------------------------------------------------------------------*/

int ot998_C()
{
    $char appstlcd[2], iproduct[13], iins_scope[3], iclaimcd[5], iclaim[16];
    $char iclaim_sno[5], plycd[5], ipolicy[16], card[11], risk_area[4], daccident[9];
    $char dclaim[9], dgroup[7], plybegin[9], plyend[9], nonrespamt[14], biaopamt[11];
    $char biaoaamt[11], pdaoaamt[11], cslamt[14], mins_deduct[13], nreason[4];
    $char sharecd[2], pcoshare[6], txcd[2], fdecide[2], totamtcd[2], totamt[14];
    $char idanger_unit[3], qdanger_unit[8], icareer[8], idanger_type[3], ndanger_type[5];
    $char isscd[2];

printf("========START ot998_C========\n");
    $WHENEVER ERROR GOTO errexit;

    $DECLARE C_cur CURSOR for SELECT * FROM ot_app_stl_998 WHERE appstlcd = '1';

    $OPEN  C_cur;

    for (;;)
    {
       $FETCH C_cur
         INTO $appstlcd, $iproduct, $flag12, $flagPG, $iclaimcd, $iclaim,
              $iclaim_sno, $plycd, $ipolicy, $daccident, $dclaim,
              $dgroup, $plybegin, $plyend, $id, $idno, $sex,
              $birth, $nreason,
              $txcd , $fdecide, $score, $amtcd3, $amt3, $amtcd4,
             $amt4, $payitem, $paycd,$workno, $transferdate, $smins_cover,$type;

        if (SQLCODE==SQLNOTFOUND) break;

printf("======= bbbbbbbbbbb iclaim = [%s] \n\n", iclaim);
printf("======= bbbbbbbbbbb idno = [%s] \n\n", idno);
printf("======= bbbbbbbbbbb birth = [%s] \n\n", birth);

        print_cnt ++;

        if (amtcd3[0] == '-') 
		print_amt -= atoi(amt3);
        else 
		print_amt += atoi(amt3);

        flen_C =  fprintf(fp_C,"%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s\n",
              iproduct, flag12, flagPG, iclaimcd, iclaim,
              iclaim_sno, plycd, ipolicy, daccident, dclaim,
              dgroup, plybegin, plyend, id, idno, sex,
              birth, nreason,
              txcd , fdecide, score, amtcd3, amt3, amtcd4,
              amt4, payitem, paycd,workno, transferdate, smins_cover,type);
    }
    $CLOSE C_cur;
    $FREE  C_cur;

    sprintf(msgbuf,"%s��L�I�w�M�߮�:���[%d]���B[%ld]\n",msgbuf,print_cnt,print_amt);
printf("========END ot998_C========\n");
    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*-------------------------------------------------------------------------*/

int ot998_O()
{
    $char appstlcd[2], iproduct[13], iins_scope[3], iclaimcd[5], iclaim[16];
    $char iclaim_sno[5], plycd[5], ipolicy[16], card[11], risk_area[4], daccident[9];
    $char dclaim[9], dgroup[7], plybegin[9], plyend[9], nonrespamt[14], biaopamt[11];
    $char biaoaamt[11], pdaoaamt[11], cslamt[14], mins_deduct[13], nreason[4];
    $char sharecd[2], pcoshare[6], txcd[2], fdecide[2], totamtcd[2], totamt[14];
    $char idanger_unit[3], qdanger_unit[8], icareer[8], idanger_type[3], ndanger_type[5];
    $char isscd[2];
    $int test_count;

printf("========START ot998_O========\n");
    $WHENEVER ERROR GOTO errexit;
    
     $select count(*)
   into $test_count
  from  ot_app_stl_998;
  
printf(" test_count[%d]\n",test_count);
    
    

    $DECLARE O_cur CURSOR for SELECT * FROM ot_app_stl_998 WHERE appstlcd = '2';

    $OPEN  O_cur;

    for (;;)
    {
       $FETCH O_cur
         INTO $appstlcd, $iproduct, $flag12, $flagPG, $iclaimcd, $iclaim,
              $iclaim_sno, $plycd, $ipolicy, $daccident, $dclaim,
              $dgroup, $plybegin, $plyend, $id, $idno, $sex,
              $birth, $nreason,
              $txcd , $fdecide, $score, $amtcd3, $amt3, $amtcd4,
             $amt4, $payitem, $paycd,$workno, $transferdate, $smins_cover,$type;

        if (SQLCODE==SQLNOTFOUND) break;

        print_cnt ++;

        if (amtcd3[0] == '-') print_amt -= atoi(amt3);
        else print_amt += atoi(amt3);

        flen_C =  fprintf(fp_O,"%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s%s\n",
         iproduct, flag12, flagPG, iclaimcd, iclaim,
              iclaim_sno, plycd, ipolicy, daccident, dclaim,
              dgroup, plybegin, plyend, id, idno, sex,
              birth, nreason,
              txcd , fdecide, score, amtcd3, amt3, amtcd4,
              amt4, payitem, paycd,workno, transferdate, smins_cover,type);
    }
    $CLOSE O_cur;
    $FREE  O_cur;

    sprintf(msgbuf,"%s��L�I���M�߮�:���[%d]���B[%ld]\n",msgbuf,print_cnt,print_amt);
printf("========END ot998_O========\n");
    return M_CM_OK;

errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*-------------------------------------------------------------------------*/

int oth998_accumu_fir_ply()
 {
    $char iproduct[13], iins_scope[3], fassured, ipolicy[21], icard[11], risk_area[4];
    $char dply_edr[11], dbegin[11], dend[11], ddanger_begin[11], ddanger_end[11];
    $char resp_type, ideduct, pcosharecd, sprem_rule, idanger_unit[3];
    $char icareer[8], idanger_type[3], ndanger_type[5];
    $double pcoshare;
    $int  pprem_rule, qdanger_unit;
    $double mins_cover, mins_deduct, mpremium, mpremium_pure;
    $char nasscd, plycd[5], ipolicy_into[16], plydate[9], plybegin[9], plyend[9];
    $char dang_bgn_into[9],dang_end_into[9], mins_deduct_into[7], pcoshare_into[6];
    $char mprem[11],sharemprem[11],pprem_rule_into[4],qdanger_unit_into[8];
    $char nonrespcd,nonrespamt[14],biaopcd,biaopamt[11];
    $char biaoacd,biaoaamt[11],pdaoacd,pdaoaamt[11],cslcd,cslamt[14];
    $char pure_mpremcd, pure_mprem[11], pure_sharemprem[11];
    $char iins_type[5], iins_kind[11];
    long  lyear, lyear2;

    /* ���I�ܼ� START*/
      $char stmt1[2000];
      $char Fipolicy[14], ipolicy67[3], Fiproduct[14], Fplycd[5], policy_no[13];
      $char dpolicy[11], Fdins_bgn[11], Fdins_end[11], Fbirth_date[11];
      $char Fplydate[9], Fplybegin[9], Fplyend[9], Fdate1[9], Fdate2[9], 
            Fbirth[9], date_tmp[11], Ftransferdate[9];
      $char Fidno[11], Fins_type[2], Ffcareer[2], Fid[2];
      $char icode1[2], sex[2], Fscode1[5], Fscode2[5];
      $int  Fqply_year;
       int  i, j; 
      $double Fmprop_ins_amt, Famt_med, Facc_prem, Fmed_prem, Famt21, Famt22;
      $double addition_rate;
      $char sFamt_med[14], sFmprop_ins_amt[14], sFmed_prem[11], sFacc_prem[11],             sFamt21[11], sFamt22[11], Flimit[4];
    /* ���I�ܼ� END */
   $char xxxx1[13];
    $whenever sqlerror goto errexit;
    /*=======================================================================*/
    printf(" ======== ���I START ======== \n");
    sprintf(stmt1," select a.ipolicy, a.dpolicy, \
                              a.dins_bgn, a.dins_end, a.qply_year, \
                              b.idno, b.birth_date, b.ins_type, \
                              b.mprop_ins_amt, b.amt_med, \
                              b.acc_prem, b.med_prem, b.fcareer \
                         from %s:fi_ori_ply a, %s:fi_ori_acc b \
                        where a.ipolicy = b.ipolicy \
                          and a.dpolicy between ? and ? ",
                          DBnameFull, DBnameFull);
      $PREPARE pre_FP1 FROM $stmt1;
      $DECLARE cur_FP1 CURSOR FOR pre_FP1;
      $OPEN cur_FP1 USing $datebgn, $dateend;
      while(1)
      {
        $FETCH cur_FP1 INTO $Fipolicy, $dpolicy, 
                            $Fdins_bgn, $Fdins_end, $Fqply_year,
                            $Fidno, $Fbirth_date, $Fins_type,
                            $Fmprop_ins_amt, $Famt_med,
                            $Facc_prem, $Fmed_prem, $Ffcareer;
        if(SQLCODE == SQLNOTFOUND) break;
printf("Fins_type[%s] Famt_med[%f] \n",Fins_type,Famt_med);
   /* ====== �橳�ʽ� ====== */
        /* 1.�ӫ~�N�X */
           if (Fqply_year == 1) 
               strcpy(icode1,"1");
           else 
               strcpy(icode1,"0");
           strncpy(ipolicy67,&Fipolicy[5],2);
           ipolicy67[2] = '\0';
           $SELECT iproduct
              INTO $Fiproduct
              FROM cm_product_code
             WHERE iins_class = 'F'
               AND iins_type = $ipolicy67
               AND icode1 = $icode1
               AND icode2 = 'P';
           if (SQLCODE == SQLNOTFOUND) 
               strcpy(Fiproduct,"############");
        /* 4.�O�渹�X */
           strcpy(Fplycd,"17");
           strncat(Fplycd,Fipolicy,2);
           Fplycd[4]='\0';

           strcpy(policy_no, &Fipolicy[3]);
           if (strlen(policy_no) < 12)
           {
               j = 12 - strlen(policy_no);
               for (i=0; i<j; i++)
                    strcat(policy_no, " ");
           }
           policy_no[12] = '\0';
 
   /* ====== ������ ====== */
        /* 7.�O��ñ��� */
           if (risnull(SQLCHAR,dpolicy) != 1)
           {
               strncpy(Fplydate,  &dpolicy[6], 4);
               Fplydate[4] = '\0';
               strncat(Fplydate, &dpolicy[0], 2);
               Fplydate[6] = '\0';
               strncat(Fplydate, &dpolicy[3], 2);
           }
           else 
               strcpy(Fplydate, "00000000");
           Fplydate[8] = '\0';

        /* 8.�O�I���� */
           if (risnull(SQLCHAR,Fdins_bgn) != 1)
           {
               strncpy(Fplybegin,  &Fdins_bgn[6], 4);
               Fplybegin[4] = '\0';
               strncat(Fplybegin, &Fdins_bgn[0], 2);
               Fplybegin[6] = '\0';
               strncat(Fplybegin, &Fdins_bgn[3], 2);
           }
           else 
               strcpy(Fplybegin, "00000000");
           Fplybegin[8] = '\0';

           if (risnull(SQLCHAR,Fdins_end) != 1)
           {
               strncpy(Fplyend,  &Fdins_end[6], 4);
               Fplyend[4] = '\0';
               strncat(Fplyend, &Fdins_end[0], 2);
               Fplyend[6] = '\0';
               strncat(Fplyend, &Fdins_end[3], 2);
           }
           else 
               strcpy(Fplyend, "00000000");
           Fplyend[8] = '\0';

        /* 11.�O��/���O�O���� */
           strcpy(Fdate1, Fplybegin); 
           strcpy(Fdate2, Fplyend);
          
   /* ====== �Q�O�I�H��� ====== */
        /* 13.�ҥ󸹽X */
           if(isalpha(Fidno) != 0)
              strcpy(Fid, "9");
           else
              strcpy(Fid, "1"); 

        /* 14.�ʧO */
           if(strcmp(Fid, "9") == 0)
              sex[0] = '0';
           else 
           {
             if(Fidno[1] == '1')
                sex[0] = '1';
             else
                sex[0] = '2';
           } 
        /* 15.�X�ͤ�� */
           if (risnull(SQLCHAR,Fbirth_date) != 1)
           {
               strncpy(Fbirth,  &Fbirth_date[6], 4);
               Fbirth[4] = '\0';
               strncat(Fbirth, &Fbirth_date[0], 2);
               Fbirth[6] = '\0';
               strncat(Fbirth, &Fbirth_date[3], 2);
           }
           else 
               strcpy(Fbirth, "00000000");
           Fbirth[8] = '\0';

   /* ====== �O�I���B ====== */
        /* 16.�ӫO�d�� */
           if (strcmp(Fins_type, "1") == 0)
               strcpy(Fscode1, "0102");
           else if(strcmp(Fins_type, "2") == 0)
               strcpy(Fscode1, "0100");
           else if(strcmp(Fins_type, "3") == 0)
           {
               strcpy(Fscode1, "0100");
               strcpy(Fscode2, "2200");
           } 
             
        /* 18.�O�I���B */
printf(" Fmprop_ins_amt[%f] Famt_med[%f] \n",Fmprop_ins_amt,Famt_med);
           if (strcmp(Fins_type, "1") == 0)
               sprintf(sFmprop_ins_amt,"%013.0f",Fmprop_ins_amt);
           else if(strcmp(Fins_type, "2") == 0)
               sprintf(sFmprop_ins_amt,"%013.0f",Fmprop_ins_amt);
           else if(strcmp(Fins_type, "3") == 0)
           {
               sprintf(sFmprop_ins_amt,"%013.0f",Fmprop_ins_amt);
               sprintf(sFamt_med,"%013.0f",Famt_med); 
           }
printf(" sFmprop_ins_amt[%s] sFamt_med[%s] \n",sFmprop_ins_amt,sFamt_med);           
        /* 19.�̰���ƭ��� */
           if(strcmp(Fins_type, "3") == 0)
              strcpy(Flimit, "090");
                  
   /* ====== �O�O ====== */
        /* 21.�O�O */ 
            if (strcmp(Fins_type, "1") == 0)
               sprintf(sFacc_prem,"%010.0f",Facc_prem);
           else if(strcmp(Fins_type, "2") == 0)
               sprintf(sFacc_prem,"%010.0f",Facc_prem);
           else if(strcmp(Fins_type, "3") == 0)
           {
               sprintf(sFacc_prem,"%010.0f",Facc_prem); 
               sprintf(sFmed_prem,"%010.0f",Fmed_prem);
           }

   /* ====== �«O�O ====== */     
        /* 23.�«O�O */
           $select addition_rate
                  into $addition_rate
                  from fi_addition_rate
                 where iins_kind = 'P'
                   and date_bgn = (select max(date_bgn)
                                     from fi_addition_rate
                                    where iins_kind = 'P'
                                      and date_bgn <= $Fdins_bgn);
           Famt21 = Facc_prem * (1 - addition_rate);
           Famt22 = Fmed_prem * (1 - addition_rate);

           if (strcmp(Fins_type, "1") == 0)
               sprintf(sFamt21,"%010.0f",Famt21);
           else if(strcmp(Fins_type, "2") == 0)
               sprintf(sFamt21,"%010.0f",Famt21);
           else if(strcmp(Fins_type, "3") == 0)
           {
               sprintf(sFamt21,"%010.0f",Famt21); 
               sprintf(sFamt22,"%010.0f",Famt22);
           } 
           
     /* ====== 24.¾�~���O�N�� ====== */
           if (strcmp(Fins_type, "1") == 0)
              strcpy(Ffcareer, "0");
              
     /* ====== 25.��ƻs�e��� ====== */
           strcpy(date_tmp,cm_edate_str(cm_today()));
           strncpy(Ftransferdate,&date_tmp[6],4);  
           Ftransferdate[4]='\0';
           strncat(Ftransferdate,&date_tmp[0],2);  
           Ftransferdate[6]='\0';
           strncat(Ftransferdate,&date_tmp[3],2);  
           Ftransferdate[8]='\0';

     /*$INSERT INTO ot_ply_edr_998
        VALUES('1', $Fiproduct, '2', 'P', $Fplycd,
               $policy_no, '0000', '000000000000000', '0', $Fplydate,
               $Fplybegin, $Fplyend, '00000000', '00000000', '00000000',
               $Fdate1, $Fdate2, '+', '00000001', $Fid,
               $Fidno, $sex, $Fbirth, $Fscode1, '+',
               $sFmprop_ins_amt, '000', '+', $sFacc_prem, '+',
               $sFamt21, $Ffcareer, $Ftransferdate, '21'); */
     $INSERT INTO ot_ply_edr_998
      VALUES('1', $Fiproduct, '2', '0', $Fplycd,
             $policy_no, '0000', '000000000000000', '0', $Fplydate,
             $Fplybegin, $Fplyend, '00000000', '00000000', '00000000',
             $Fdate1, $Fdate2, '+', '00000000', '0',
             '0000000000', '0', '00000000', '0000', '+',
             '0000000000000', '000', '+', $sFacc_prem, '+',
             $sFamt21, '0', $Ftransferdate, '21');

     /*if (strcmp(Fins_type, "3") == 0)
     {
         $INSERT INTO ot_ply_edr_998
            VALUES('1', $Fiproduct, '2', 'P', $Fplycd,
                   $policy_no, '0000', '000000000000000', '0', $Fplydate,
                   $Fplybegin, $Fplyend, '00000000', '00000000', '00000000',
                   $Fdate1, $Fdate2, '+', '00000001', $Fid,
                   $Fidno, $sex, $Fbirth, $Fscode2, '+',
                   $sFamt_med, $Flimit, '+', $sFmed_prem, '+',
                   $sFamt22, $Ffcareer, $Ftransferdate, '21');
     }*/
     if (strcmp(Fins_type, "3") == 0)
     {
         $INSERT INTO ot_ply_edr_998
            VALUES('1', $Fiproduct, '2', '0', $Fplycd,
                   $policy_no, '0000', '000000000000000', '0', $Fplydate,
                   $Fplybegin, $Fplyend, '00000000', '00000000', '00000000',
                   $Fdate1, $Fdate2, '+', '00000000', '0',
                   '0000000000', '0', '00000000', '0000', '+',
                   '0000000000000', '000', '+', $sFmed_prem, '+',
                   $sFamt22, '0', $Ftransferdate, '21');
     }
    }
    $CLOSE cur_FP1;
    $FREE  cur_FP1;
   printf(" ======== ���I END ======== \n"); 

    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}

/*-------------------------------------------------------------------------*/

int oth998_accumu_fir_edr()
{
    $char iproduct[13], iins_scope[3], fassured, ipolicy[21], icard[11];
    $char iendorse[21], risk_area[4], fedr_class, dply_edr_pol[11], dbegin_pol[11], dply_edr[11];
    $char dbegin[11], dend[11], ddanger_begin[11], ddanger_end[11], dend_pol[11];
    $char resp_type, ideduct, pcosharecd, sprem_rule, idanger_unit[3];
    $char icareer[8], idanger_type[3], ndanger_type[5];
    $double pcoshare;
    $int  pprem_rule, qdanger_unit;
    $double mins_cover, mins_deduct, mpremium, mpremium_pure;
    $char nasscd, plycd[5], ipolicy_into[16], edrcd[5], iendorse_into[16], fedr_class_into, plydate[9], plybegin[9], plyend[9], edrdate[9], edrbegin[9], edrend[9];
    $char dang_bgn_into[9],dang_end_into[9], mins_deduct_into[7], pcoshare_into[6];
    $char mpremcd, mprem[11],sharemprem[11],pprem_rule_into[4],qdanger_unit_into[8];
    $char nonrespcd,nonrespamt[14],biaopcd,biaopamt[11];
    $char biaoacd,biaoaamt[11],pdaoacd,pdaoaamt[11],cslcd,cslamt[14];
    $char pure_mpremcd, pure_mprem[11], pure_sharemprem[11];
    $char iins_type[5], iins_kind[11];
    long  leyear, leyear2;

    /* ���I�ܼ� START */
    int j, i;
    $char stmt1[2024];
    $char Fiendorsement[14], endorse_no[16];
    $char Fipolicy[14], ipolicy67[3], Fiproduct[14], Fplycd[5], policy_no[13];  
    $char Fdpolicy[11], Fdins_bgn[11], Fdins_end[11], Fbirth_date[11];
    $char Fdendorse[11], Fded_eff_bgn[11], Fded_eff_end[11], Fedrcd[5];
    $char Fplydate[9], Fplybegin[9], Fplyend[9], Fdate1[9], Fdate2[9], Fbirth[9], date_tmp[11], Ftransferdate[9];
    $char Fedrdate[9], Fedrbegin[9], Fedrend[9];
    $char Fidno[11], Fins_type[2], Ffcareer[2], Fid[2];
    $char icode1[2], sex[2], Fscode1[5], Fscode2[5], sFfcareer[3];
    $int  Fqply_year; 
    $double Fmprop_ins_amt, Famt_med, Facc_prem, Fmed_prem;
    $char sFamt_med[14], sFmprop_ins_amt[14], sFacc_prem[11], sFmed_prem[11], sFamt21[11], sFamt22[11];
    $char Fnreason[2], sFnreason[2], Fiendor_reason[3];
    $double addition_rate, Famt21, Famt22;
    $char Fmpremcd1[2], Fmpremcd2[2], Famtcd1[2], Famtcd2[2], sFamtcd3[2], sFamtcd4[2], Flimit[4];
    /* ���I�ܼ� END */   

    /* ======== ���I��� ======== */
printf(" ======== ���I��� START ======== \n");    
           sprintf(stmt1," select a.iendorsement, a.ipolicy, \
                                  c.dpolicy, c.dins_bgn, c.dins_end, c.qply_year, \
                                  a.dendorse, a.ded_eff_bgn, a.ded_eff_end, \
                                  b.iendor_reason, b.birth_date, b.idno, b.fcareer, b.ins_type, \
                                  b.mprop_diff_amt, b.amt_med, b.acc_prem, b.med_prem \
                         from %s:fi_endorsement a, %s:fi_ed_acc b, %s:fi_ori_ply c \
                        where a.ipolicy = c.ipolicy \
                          and a.iendorsement = b.iendorsement \
                          and b.icode = 'A' \
                          and a.dendorse between ? and ?",
                          DBnameFull, DBnameFull, DBnameFull);
      $PREPARE pre_FP1 FROM $stmt1;
      $DECLARE cur_FP2 CURSOR FOR pre_FP1;
      $OPEN cur_FP2 USing $datebgn, $dateend;
      while(1)
      {
        $FETCH cur_FP2 INTO $Fiendorsement, $Fipolicy, 
                            $Fdpolicy, $Fdins_bgn, $Fdins_end, $Fqply_year,
                            $Fdendorse, $Fded_eff_bgn, $Fded_eff_end,
                            $Fiendor_reason, $Fbirth_date, $Fidno, $Ffcareer, $Fins_type,
                            $Fmprop_ins_amt, $Famt_med, $Facc_prem, $Fmed_prem, $Ffcareer;
        if(SQLCODE == SQLNOTFOUND) break;
 
   /* ====== �橳�ʽ� ====== */
        /* 1.�ӫ~�N�X */
           if (Fqply_year == 1) 
               strcpy(icode1,"1");
           else 
               strcpy(icode1,"0");
           strncpy(ipolicy67,&Fipolicy[5],2);
           ipolicy67[2] = '\0';
           $SELECT iproduct
              INTO $Fiproduct
              FROM cm_product_code
             WHERE iins_class = 'F'
               AND iins_type = $ipolicy67
               AND icode1 = $icode1
               AND icode2 = 'P';
           if (SQLCODE == SQLNOTFOUND) 
               strcpy(Fiproduct,"############");
        /* 4.�O�渹�X */
           strcpy(Fplycd,"17");
           strncat(Fplycd,Fipolicy,2);
           Fplycd[4]='\0';

           strcpy(policy_no, &Fipolicy[3]);
           if (strlen(policy_no) < 12)
           {
               j = 12 - strlen(policy_no);
               for (i=0; i<j; i++)
                    strcat(policy_no, " ");
           }
           policy_no[12] = '\0';
        /* 5.��渹�X */
           strcpy(Fedrcd, "17");
           strncat(Fedrcd,Fiendorsement,2);
           Fedrcd[4] = '\0';
          
           strcpy(endorse_no, &Fiendorsement[3]);
           if(strlen(endorse_no) < 12)
           {
              j = 12 - strlen(endorse_no);
              for(i=0; i<j; i++)
                  strcat(endorse_no, " ");
           } 
           endorse_no[12] = '\0';
        /* 6.��������A�N�� */
           $SELECT nreason 
              INTO $Fnreason  
              FROM fi_ed_reason
             WHERE ireason = $Fiendor_reason;

           if (SQLCODE == SQLNOTFOUND)
              strcpy(sFnreason, " ");
           else if (risnull(CCHARTYPE, (char *)Fnreason) == 1)
              strcpy(sFnreason, " ");
           else
           {
              strncpy(sFnreason, Fnreason, 1); 
              sFnreason[1] = '\0';
           }

   /* ====== ������ ====== */
        /* 7.�O��ñ��� */
           if (risnull(SQLCHAR,Fdpolicy) != 1)
           {
               strncpy(Fplydate,  &Fdpolicy[6], 4);
               Fplydate[4] = '\0';
               strncat(Fplydate, &Fdpolicy[0], 2);
               Fplydate[6] = '\0';
               strncat(Fplydate, &Fdpolicy[3], 2);
           }
           else 
               strcpy(Fplydate, "00000000");
           Fplydate[8] = '\0';

        /* 8.�O�I���� */
           if (risnull(SQLCHAR,dbegin) != 1)
           {
               strncpy(Fplybegin,  &Fdins_bgn[6], 4);
               Fplybegin[4] = '\0';
               strncat(Fplybegin, &Fdins_bgn[0], 2);
               Fplybegin[6] = '\0';
               strncat(Fplybegin, &Fdins_bgn[3], 2);
           }
           else 
               strcpy(Fplybegin, "00000000");
           Fplybegin[8] = '\0';

           if (risnull(SQLCHAR,dend) != 1)
           {
               strncpy(Fplyend,  &Fdins_end[6], 4);
               Fplyend[4] = '\0';
               strncat(Fplyend, &Fdins_end[0], 2);
               Fplyend[6] = '\0';
               strncat(Fplyend, &Fdins_end[3], 2);
           }
           else 
               strcpy(Fplyend, "00000000");
           Fplyend[8] = '\0';
        /* 9.���ñ���� */
           if (risnull(SQLCHAR,Fdendorse) != 1)
           {
               strncpy(Fedrdate,  &Fdendorse[6], 4);
               Fedrdate[4] = '\0';
               strncat(Fedrdate, &Fdendorse[0], 2);
               Fedrdate[6] = '\0';
               strncat(Fedrdate, &Fdendorse[3], 2);
           }
           else 
               strcpy(Fedrdate, "00000000");
           Fedrdate[8] = '\0';
        /* 10.������ */
           if (risnull(SQLCHAR,Fded_eff_bgn) != 1)
           {
               strncpy(Fedrbegin,  &Fded_eff_bgn[6], 4);
               Fedrbegin[4] = '\0';
               strncat(Fedrbegin, &Fded_eff_bgn[0], 2);
               Fedrbegin[6] = '\0';
               strncat(Fedrbegin, &Fded_eff_bgn[3], 2);
           }
           else 
               strcpy(Fedrbegin, "00000000");
           Fedrbegin[8] = '\0';

           if (risnull(SQLCHAR,Fded_eff_end) != 1)
           {
               strncpy(Fedrend,  &Fded_eff_end[6], 4);
               Fedrend[4] = '\0';
               strncat(Fedrend, &Fded_eff_end[0], 2);
               Fedrend[6] = '\0';
               strncat(Fedrend, &Fded_eff_end[3], 2);
           }
           else 
               strcpy(Fedrend, "00000000");
           Fedrend[8] = '\0';       

        /* 11.�O��/���O�O���� */
           strcpy(Fdate1, Fedrbegin); 
           strcpy(Fdate2, Fedrend);
          
   /* ====== �Q�O�I�H��� ====== */
        /* 13.�ҥ󸹽X */
           if(isalpha(Fidno) != 0)
              strcpy(Fid, "9");
           else
              strcpy(Fid, "1"); 

        /* 14.�ʧO */
           if(strcmp(Fid, "9") == 0)
              sex[0] = '0';
           else 
           {
             if(strcmp(&Fidno[1], "1") == 0)
                sex[0] = '1';
             else
                sex[0] = '2';
           } 
        /* 15.�X�ͤ�� */
           if (risnull(SQLCHAR,Fbirth_date) != 1)
           {
               strncpy(Fbirth,  &Fbirth_date[6], 4);
               Fbirth[4] = '\0';
               strncat(Fbirth, &Fbirth_date[0], 2);
               Fbirth[6] = '\0';
               strncat(Fbirth, &Fbirth_date[3], 2);
           }
           else 
               strcpy(Fbirth, "00000000");
           Fbirth[8] = '\0';

   /* ====== �O�I���B ====== */
        /* 16.�ӫO�d�� */
           if (strcmp(Fins_type, "1") == 0)
               strcpy(Fscode1, "0102");
           else if(strcmp(Fins_type, "2") == 0)
               strcpy(Fscode1, "0100");
           else if(strcmp(Fins_type, "3") == 0)
           {
               strcpy(Fscode1, "0100");
               strcpy(Fscode2, "2200");
           } 
        /* 17.�O�I���B�[� */
printf(" Fmprop_ins_amt[%f] Famt_med[%f] \n",Fmprop_ins_amt,Famt_med);
        if (strcmp(Fins_type, "1") == 0)
        {
            if(Fmprop_ins_amt < 0)
               strcpy(Fmpremcd1, "-");
            else
               strcpy(Fmpremcd1, "+");
        }
        else if(strcmp(Fins_type, "2") == 0)
        {
             if(Fmprop_ins_amt < 0)
                strcpy(Fmpremcd1, "-");
             else
                strcpy(Fmpremcd1, "+");
        }
        else if(strcmp(Fins_type, "3") == 0)
        {
             if(Fmprop_ins_amt < 0)
                strcpy(Fmpremcd1, "-");
             else
                strcpy(Fmpremcd1, "+");
            
             if(Famt_med < 0)
                strcpy(Fmpremcd2, "-");
             else
                strcpy(Fmpremcd2, "+");
        }
               
        /* 18.�O�I���B */
           if (strcmp(Fins_type, "1") == 0)
               sprintf(sFmprop_ins_amt,"%013.0f",Fmprop_ins_amt);
           else if(strcmp(Fins_type, "2") == 0)
               sprintf(sFmprop_ins_amt,"%013.0f",Fmprop_ins_amt);
           else if(strcmp(Fins_type, "3") == 0)
           {
               sprintf(sFmprop_ins_amt,"%013.0f",Fmprop_ins_amt);
               sprintf(sFamt_med,"%013.0f",Famt_med); 
           }
           
        /* 19.�̰���ƭ��� */
           if(strcmp(Fins_type, "3") == 0)
              strcpy(Flimit, "090");
                  
   /* ====== �O�O ====== */
        /* 20.�O�O�[� */
           if (strcmp(Fins_type, "1") == 0)
           {
               if(Facc_prem < 0)
                  strcpy(Famtcd1, "-");
               else
                  strcpy(Famtcd1, "+");
           }
           else if(strcmp(Fins_type, "2") == 0)
           {
               if(Facc_prem < 0)
                  strcpy(Famtcd1, "-");
               else
                  strcpy(Famtcd1, "+");
           }
           else if(strcmp(Fins_type, "3") == 0)
           {
               if(Facc_prem < 0)
                  strcpy(Famtcd1, "-");
               else
                  strcpy(Famtcd1, "+");

               if(Fmed_prem < 0)
                  strcpy(Famtcd2, "-");
               else
                  strcpy(Famtcd2, "+");
        }

        /* 21.�O�O */ 
           if (strcmp(Fins_type, "1") == 0)
               sprintf(sFacc_prem,"%010.0f",Facc_prem);
           else if(strcmp(Fins_type, "2") == 0)
               sprintf(sFacc_prem,"%010.0f",Facc_prem);
           else if(strcmp(Fins_type, "3") == 0)
           {
               sprintf(sFacc_prem,"%010.0f",Facc_prem);
               sprintf(sFmed_prem,"%010.0f",Fmed_prem); 
           }

   /* ====== �«O�O ====== */
        /* 22.�«O�O�[� */      
        /* 23.�«O�O */
           $select addition_rate
                  into $addition_rate
                  from fi_addition_rate
                 where iins_kind = 'P'
                   and date_bgn = (select max(date_bgn)
                                     from fi_addition_rate
                                    where iins_kind = 'P'
                                      and date_bgn <= $Fded_eff_bgn);
printf(" addition_rate[%f] \n",addition_rate);
           Famt21 = Facc_prem * (1 - addition_rate);
           Famt22 = Fmed_prem * (1 - addition_rate);
           if (strcmp(Fins_type, "1") == 0)
           {
               if(Famt21 < 0)
                  strcpy(sFamtcd3, "-");
               else
                  strcpy(sFamtcd3, "+");
      
               sprintf(sFamt21,"%010.0f",Famt21);   
           }
           else if(strcmp(Fins_type, "2") == 0)
           {
               if(Famt21 < 0)
                  strcpy(sFamtcd3, "-");
               else
                  strcpy(sFamtcd3, "+");
      
               sprintf(sFamt21,"%010.0f",Famt21);
           }
           else if(strcmp(Fins_type, "3") == 0)
           {
               if(Famt21 < 0)
                  strcpy(sFamtcd3, "-");
               else
                  strcpy(sFamtcd3, "+");
      
               if(Famt22 < 0)
                  strcpy(sFamtcd4, "-");
               else
                  strcpy(sFamtcd4, "+");                

               sprintf(sFamt21,"%010.0f",Famt21); 
               sprintf(sFamt22,"%010.0f",Famt22);
           } 
           
     /* ====== 24.¾�~���O�N�� ====== */
           if (strcmp(Fins_type, "1") == 0)
              strcpy(sFfcareer, "00");
           else
              sprintf(sFfcareer, "%02d", atoi(Ffcareer));

     /* ====== 25.��ƻs�e��� ====== */
           strcpy(date_tmp,cm_edate_str(cm_today()));
           strncpy(Ftransferdate,&date_tmp[6],4);  
           Ftransferdate[4]='\0';
           strncat(Ftransferdate,&date_tmp[0],2);  
           Ftransferdate[6]='\0';
           strncat(Ftransferdate,&date_tmp[3],2);  
           Ftransferdate[8]='\0';
     /*$INSERT INTO ot_ply_edr_998
        VALUES('2', $Fiproduct, '2', 'P', $Fplycd,
               $policy_no, $Fedrcd, $endorse_no, $sFnreason, $Fplydate,
               $Fplybegin, $Fplyend, $Fedrdate, $Fedrbegin, $Fedrend,
               $Fdate1, 
               $Fdate2, '+', '00000001', $Fid, $Fidno,
               $sex, $Fbirth, $Fscode1, $Fmpremcd1, $sFmprop_ins_amt,
               '000', $Famtcd1, $sFacc_prem, $sFamtcd3, $sFamt21,
               $sFfcareer, $Ftransferdate, '21'); */

     $INSERT INTO ot_ply_edr_998
        VALUES('2', $Fiproduct, '2', '0', $Fplycd,
               $policy_no, $Fedrcd, $endorse_no, $sFnreason, $Fplydate,
               $Fplybegin, $Fplyend, $Fedrdate, $Fedrbegin, $Fedrend,
               $Fdate1,
               $Fdate2, '+', '00000000', '0', '0000000000',
               '0', '00000000', '0000', '+', '0000000000000',
               '000', $Famtcd1, $sFacc_prem, $sFamtcd3, $sFamt21,
               '0', $Ftransferdate, '21');

     /*if (strcmp(Fins_type, "3") == 0)
     {
         $INSERT INTO ot_ply_edr_998
            VALUES('2', $Fiproduct, '2', 'P', $Fplycd,
               $policy_no, $Fedrcd, $endorse_no, $sFnreason, $Fplydate,
               $Fplybegin, $Fplyend, $Fedrdate, $Fedrbegin, $Fedrend,
               $Fdate1, 
               $Fdate2, '+', '00000001', $Fid, $Fidno,
               $sex, $Fbirth, $Fscode2, $Fmpremcd2, $sFamt_med,
               $Flimit, $Famtcd2, $sFmed_prem, $sFamtcd4, $sFamt22,
               $sFfcareer, $Ftransferdate, '21');
     }*/
     if (strcmp(Fins_type, "3") == 0)
     {
         $INSERT INTO ot_ply_edr_998
            VALUES('2', $Fiproduct, '2', '0', $Fplycd,
               $policy_no, $Fedrcd, $endorse_no, $sFnreason, $Fplydate,
               $Fplybegin, $Fplyend, $Fedrdate, $Fedrbegin, $Fedrend,
               $Fdate1,
               $Fdate2, '+', '00000000', '0', '0000000000',
               '0', '00000000', '0000', '+', '0000000000000',
               '000', $Famtcd2, $sFmed_prem, $sFamtcd4, $sFamt22,
               '0', $Ftransferdate, '21');
     }
    }
    $CLOSE cur_FP2;
    $FREE  cur_FP2;
printf(" ======== ���I��� END ======== \n");

    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/*-------------------------------------------------------------------------*/
int oth998_accumu_car_ply()
{
    $char iproduct[13], iins_scope[3], fassured, ipolicy[21], icard[11], risk_area[4];
    $char dply_edr[11], dbegin[11], dend[11], ddanger_begin[11], ddanger_end[11];
    $char resp_type, ideduct, pcosharecd, sprem_rule, idanger_unit[3];
    $char icareer[8], idanger_type[3], ndanger_type[5];
    $double pcoshare;
    $int  pprem_rule, qdanger_unit;
    $double mins_cover, mins_deduct, mpremium, mpremium_pure;
    $char nasscd, plycd[5], ipolicy_into[16], plydate[9], plybegin[9], plyend[9];
    $char dang_bgn_into[9],dang_end_into[9], mins_deduct_into[7], pcoshare_into[6];
    $char mprem[11],sharemprem[11],pprem_rule_into[4],qdanger_unit_into[8];
    $char nonrespcd,nonrespamt[14],biaopcd,biaopamt[11];
    $char biaoacd,biaoaamt[11],pdaoacd,pdaoaamt[11],cslcd,cslamt[14];
    $char pure_mpremcd, pure_mprem[11], pure_sharemprem[11];
    $char iins_type[5], iins_kind[11];
    long  lyear, lyear2;    

    /** car var **/
    $char dpolicy[21], iassured[13], ibirth[11], iinsurant[11];
    $long mdamage_cover, mins_premium, mpure_prem, mins_amt;
    $long mpure_prem_0102, mpure_prem_2100, mins_prem_0102, mins_prem_2100;
    $long daily_pay, mr_ins_prem, mr_pure_prem;
    $char ibirth_yy[5],ibirth_mm[3],tmp_dd[3];
    $char fsex[2], cfassured[2], iscope[6];
    $char s_mdmg_cover[13], s_mins_prem[10], s_mpure_prem[10];
    $char s_mins_amt[13], s_ins_prem[10], s_pure_prem[10];
    $char s_mpure_prem_0102[10], s_mpure_prem_2100[10], s_mins_prem_0102[10], s_mins_prem_2100[10];
    
    printf(" ======== ���I�O�� START ======== \n");
    
    sprintf(stmt," select a.ipolicy, a.dply_begin, a.dply_end, a.dpolicy, \
                          c.fassured, c.iassured, c.ibirth, c.fsex, b.mdamage_cover, \
		          b.mins_premium, b.mpure_prem, b.iins_type \
                     from %s:ori_ply_relation a, %s: ori_ins_type b, \
                          %s:original_ply c \
                    where a.dpolicy between ? and ? \
                      and a.ipolicy = b.ipolicy \
                      and a.ipolicy = c.ipolicy \
                      and b.iins_type in ('47','33')" 
                      ,DBnameFull,DBnameFull,DBnameFull);
    printf("stmt[%s]\n",stmt);
    
    $PREPARE cur_car FROM $stmt;
    $DECLARE cur_ca1 CURSOR for cur_car;
    $OPEN cur_ca1 USING $datebgn, $dateend;
    while(1)
    {
    	$FETCH cur_ca1 INTO $ipolicy,  $dbegin, $dend, $dpolicy, $cfassured, 
    	                   $iassured, $ibirth, $fsex, $mdamage_cover:id1, 
                           $mins_premium, $mpure_prem, $iins_type; 
    	
    	if(SQLCODE == SQLNOTFOUND) break;
     
        printf("ipolicy[%s]\n", ipolicy );
      
        /**3.flagPG**/
	flagPG[0] = 'P';

        /**4.plycd**/
        strcpy(plycd,"17");
        strncat(plycd,ipolicy,2);
        plycd[4]='\0';
        
        /**5.ipolicy**/
        strncpy(ipolicy_into,&ipolicy[3],14);
        ipolicy_into[14] = '\0';
        strcat(ipolicy_into, " ");
        ipolicy_into[15] = '\0';        

        /**7.plydate**/
        if (risnull(SQLCHAR,dpolicy) != 1)
        {
            strncpy(plydate,  &dpolicy[6], 4);
            plydate[4] = '\0';
            strncat(plydate, &dpolicy[0], 2);
            plydate[6] = '\0';
            strncat(plydate, &dpolicy[3], 2);
        }
        else strcpy(plydate, "00000000");
        plydate[8] = '\0';

        /**8.plybegin**/
        if (risnull(SQLCHAR,dbegin) != 1)
        {
            strncpy(plybegin,  &dbegin[6], 4);
            plybegin[4] = '\0';
            strncat(plybegin, &dbegin[0], 2);
            plybegin[6] = '\0';
            strncat(plybegin, &dbegin[3], 2);
        }
        else strcpy(plybegin, "00000000");
        plybegin[8] = '\0';

        /**8.plyend**/
        if (risnull(SQLCHAR,dend) != 1)
        {
            strncpy(plyend,  &dend[6], 4);
            plyend[4] = '\0';
            strncat(plyend, &dend[0], 2);
            plyend[6] = '\0';
            strncat(plyend, &dend[3], 2);
        }
        else strcpy(plyend, "00000000");
        plyend[8] = '\0';

        /**9.edrdate**/
        /**10.edrbegin**/
        /**10.edrend**/

        /**12.member**/
        strcpy(member,"00000001");

        strcpy(iins_type, trim(iins_type));
        printf("iins_type[%s]\n", iins_type);
        /**   �H�U�̾�33�B47�����P���k **/
        if( strcmp(iins_type,"47")==0)
        {
            /** 1.iproduct **/
            $SELECT iproduct
               INTO $iproduct
               FROM cm_product_code
              WHERE iins_class = 'C'
                AND iins_type = $iins_type;
            
            strcpy(cfassured,trim(cfassured));
            /**13.id**/
            if ( strcmp( cfassured, "1") == 0 )
            {
                strcpy(idno, iassured);
                idno[10]='\0';
                strcpy(id, "1");
            }
	    else if( strcmp( cfassured, "3") == 0 )
	    {
	        strcpy(idno, iassured);
                idno[10]='\0';
                strcpy(id, "2");
	    }
	    else
	    {
	        flagPG[0] = 'Z';
	        strcpy(id  ,"0");
                strcpy(idno, "0000000000");
                ibirth[0] = '\0';
	    }
            /**14.sex**/
            if (strlen(rtrim(fsex)) == 0)
                sex[0] = '0';
            else
            {
                strcpy(sex, fsex);
                sex[1]='\0';
            }

            /**15.dbirth**/
            if (strlen(rtrim(ibirth)) == 0)
            {        
	        strcpy(birth, "00000000");
	    }
	    else
	    {
	        cm_split_ymd(ibirth,ibirth_yy,ibirth_mm,tmp_dd);

                if (strlen(rtrim(ibirth_yy)) == 0)
                {
                    strcpy(birth, "00000000");
                }
                else
                {
            	    strcpy(birth,itoa(1911+(atoi(ibirth_yy))));
            	    strcat(birth,ibirth_mm);
            	    strcat(birth,tmp_dd);
                }
            }

            rfmtlong(mdamage_cover,"&&&&&&&&&&&&&",s_mdmg_cover);
            s_mdmg_cover[13] = '\0';
            
            /*
            rfmtlong(mins_premium,"&&&&&&&&&&",s_mins_prem);
            s_mins_prem[10]='\0';
            rfmtlong(mpure_prem,"&&&&&&&&&&",s_mpure_prem);
            s_mpure_prem[10]='\0';
            */

            printf("insert into ot_ply_edr_998\n"); 
                        
            mins_prem_0102 = (long)(mins_premium * 0.8741 + 0.5);
            mins_prem_2100 = mins_premium - mins_prem_0102;
            mpure_prem_0102 = (long)(mpure_prem * 0.8741 + 0.5);
            mpure_prem_2100 = mpure_prem - mpure_prem_0102;
            
            rfmtlong(mins_prem_0102,"&&&&&&&&&&",s_mins_prem_0102);
            s_mins_prem_0102[10]='\0';
            rfmtlong(mins_prem_2100,"&&&&&&&&&&",s_mins_prem_2100);
            s_mins_prem_2100[10]='\0';
            rfmtlong(mpure_prem_0102,"&&&&&&&&&&",s_mpure_prem_0102);
            s_mpure_prem_0102[10]='\0';
            rfmtlong(mpure_prem_2100,"&&&&&&&&&&",s_mpure_prem_2100);
            s_mpure_prem_2100[10]='\0';
            
            /***
            $INSERT INTO ot_ply_edr_998
             VALUES('1',$iproduct, '2', '0', $plycd, $ipolicy_into,
                     '0000','000000000000000','0',$plydate,
                     $plybegin,$plyend,'00000000','00000000','00000000',
                     $plybegin,$plyend,'+','00000000','0','0000000000',
                     '0','00000000','0000','+','0000000000000','000','+',
                     $s_mins_prem,'+',$s_mpure_prem,'0',$transferdate,'11');
            **/
            
            
       	    $INSERT INTO ot_ply_edr_998
             VALUES('1',$iproduct, '2', $flagPG, $plycd, $ipolicy_into,
                     '0000','000000000000000','0',$plydate,
                     $plybegin,$plyend,'00000000','00000000','00000000',
                     $plybegin,$plyend,'+',$member,$id,$idno,$sex,$birth,
                     '0102','+',$s_mdmg_cover,'000','+',$s_mins_prem_0102,
                     '+',$s_mpure_prem_0102,'1',$transferdate,'11');
           
            
            $INSERT INTO ot_ply_edr_998
             VALUES('1',$iproduct, '2', $flagPG, $plycd, $ipolicy_into,
                     '0000','000000000000000','0',$plydate,
                     $plybegin,$plyend,'00000000','00000000','00000000',
                     $plybegin,$plyend,'+',$member,$id,$idno,$sex,$birth,
                     '2100','+',$s_mdmg_cover,'000','+',$s_mins_prem_2100,
                     '+',$s_mpure_prem_2100,'1',$transferdate,'11');
            
    	}
    	else if(strcmp(iins_type,"33")==0)
    	{
            stmt[0]='\0';
    	    sprintf(stmt,"SELECT iinsurant, dbirth, iins_scope, \
    	                         decode(icareer,'0','1',icareer), \
                                 mins_amt, mins_premium, mpure_prem, \
    	                         daily_pay, mr_ins_prem, mr_pure_prem \
    	                    FROM %s:ca_pa_ori \
    	                   WHERE ipolicy = ?",DBnameFull );
            printf("stmt[%s]\n",stmt);
    	    $PREPARE car_x2 FROM $stmt;
    	    $DECLARE car_c2 CURSOR for car_x2;
    	    $OPEN car_c2 USING $ipolicy;
    	    while(1)
    	    {
    	    	$FETCH car_c2 INTO $iinsurant, $ibirth, $iins_scope, $icareer, 
    	    	                   $mins_amt,  $mins_premium, $mpure_prem, 
    	    	                   $daily_pay, $mr_ins_prem, $mr_pure_prem;
    	    	if(SQLCODE == SQLNOTFOUND) break;
    	   
                mins_premium = mins_premium - mr_ins_prem;
                mpure_prem   = mpure_prem   - mr_pure_prem;
 
                printf("iinsurant[%s]\n", iinsurant );	
    	    	/** iproduct **/
    	    	$SELECT iproduct
                   INTO $iproduct
                   FROM cm_product_code
                  WHERE iins_class = 'C'
                    AND iins_type = $iins_type
                    AND icode1 = $iins_scope;
                
                /**13~15**/
                id[0] = '1';
                strcpy(idno, iinsurant);
                if (memcmp(&iinsurant[1], "1", 1) == 0)
                    sex[0]='1';
                else
                    sex[0]='2';
               
                printf("id[%s] idno[%s] ibirth[%s]\n",id, idno, ibirth ); 
                if (risnull(SQLCHAR,ibirth) != 1)
                {
                    strncpy(birth,  &ibirth[6], 4);
                    birth[4] = '\0';
                    strncat(birth, &ibirth[0], 2);
                    birth[6] = '\0';
                    strncat(birth, &ibirth[3], 2);
                }
                else strcpy(birth, "00000000");
                birth[8] = '\0';
              
                printf("birth[%s]\n", birth); 
                printf("insert into ot_ply_edr_998\n"); 
                /** score = 2100**/
                if(strcmp(iins_scope,"1")==0)
                    strcpy( iscope , "0102");
                else 
                    strcpy( iscope , "0100");
             
                rfmtlong(mins_amt,"&&&&&&&&&&&&&",s_mins_amt );
                s_mins_amt[13] = '\0';
                rfmtlong(mins_premium,"&&&&&&&&&&",s_mins_prem);
                s_mins_prem[10]='\0';
                rfmtlong(mpure_prem,"&&&&&&&&&&",s_mpure_prem);
                s_mpure_prem[10]='\0';
                
                /***
                $INSERT INTO ot_ply_edr_998
                     VALUES('1',$iproduct, '2', '0', $plycd, $ipolicy_into,
                            '0000','000000000000000','0',$plydate,
                            $plybegin,$plyend,'00000000','00000000','00000000',
                            $plybegin,$plyend,'+','00000000','0','0000000000',
                            '0','00000000','0000','+','0000000000000','000','+',
                            $s_mins_prem,'+',$s_mpure_prem,'0',$transferdate,'11');
                ***/
                            
                $INSERT INTO ot_ply_edr_998
                     VALUES('1',$iproduct, '2', $flagPG, $plycd, $ipolicy_into,
                            '0000','000000000000000','0',$plydate,
                            $plybegin,$plyend,'00000000','00000000','00000000',
                            $plybegin,$plyend,'+',$member,$id,$idno,$sex,$birth,
                            $iscope,'+',$s_mins_amt,'000','+',$s_mins_prem,
                            '+',$s_mpure_prem,$icareer,$transferdate,'11');
                
                if(strcmp(iins_scope,"3")==0)
                {
                    rfmtlong(s_ins_prem,"&&&&&&&&&&",mr_ins_prem);
                    s_ins_prem[10]='\0';
                    rfmtlong(s_pure_prem,"&&&&&&&&&&",mr_pure_prem);
                    s_pure_prem[10]='\0';

                    /**
                    $INSERT INTO ot_ply_edr_998
                     VALUES('1',$iproduct, '2', '0', $plycd, $ipolicy_into,
                            '0000','000000000000000','0',$plydate,
                            $plybegin,$plyend,'00000000','00000000','00000000',
                            $plybegin,$plyend,'+','00000000','0','0000000000',
                            '0','00000000','0000','+','0000000000000','000','+',
                            $s_ins_prem,'+',$s_pure_prem,'0',$transferdate,'11');
                    **/
                    
                    $INSERT INTO ot_ply_edr_998
                     VALUES('1',$iproduct, '2', $flagPG, $plycd, $ipolicy_into,
                            '0000','000000000000000','0',$plydate,
                            $plybegin,$plyend,'00000000','00000000','00000000',
                            $plybegin,$plyend,'+',$member,$id,$idno,$sex,$birth,
                            '2200','+',$daily_pay,'000','+',$s_ins_prem,
                            '+',$s_pure_prem,$icareer,$transferdate,'11');
                    
                }
    	    }
    	    $CLOSE car_c2;
    	    $FREE  car_c2;
            printf(" end iins 33 \n");
    	} /** end of iins_type**/
    }
    $CLOSE cur_ca1;
    
    printf(" ======== ���I�O�� END ======== \n");
    
    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;    
    
}

int oth998_accumu_car_edr()
{
    $char iproduct[13], iins_scope[3], fassured, ipolicy[21], icard[11];
    $char iendorse[21], risk_area[4], fedr_class, dply_edr_pol[11], dbegin_pol[11], dply_edr[11];
    $char dbegin[11], dend[11], ddanger_begin[11], ddanger_end[11], dend_pol[11];
    $char resp_type, ideduct, pcosharecd, sprem_rule, idanger_unit[3];
    $char icareer[8], idanger_type[3], ndanger_type[5];
    $double pcoshare;
    $int  pprem_rule, qdanger_unit;
    $double mins_cover, mins_deduct, mpremium, mpremium_pure;
    $char nasscd, plycd[5], ipolicy_into[16], edrcd[5], iendorse_into[16], fedr_class_into, plydate[9], plybegin[9], plyend[9], edrdate[9], edrbegin[9], edrend[9];
    $char dang_bgn_into[9],dang_end_into[9], mins_deduct_into[7], pcoshare_into[6];
    $char mpremcd, mprem[11],sharemprem[11],pprem_rule_into[4],qdanger_unit_into[8];
    $char nonrespcd,nonrespamt[14],biaopcd,biaopamt[11];
    $char biaoacd,biaoaamt[11],pdaoacd,pdaoaamt[11],cslcd,cslamt[14];
    $char pure_mpremcd, pure_mprem[11], pure_sharemprem[11];
    $char iins_type[5], iins_kind[11];
    long  leyear, leyear2;

    /** car endorsement**/
    $char  dpolicy[11], dendorse[11], dedr_begin[11], dedr_end[11];
    $char  iassured[11], fsex[2], ibirth[11], iinsurant[11], iedr_type[5];
    $long  medrdmg_cover, medrins_amt, medrins_prem, medrpure_prem;
    $long  medr_daily_pay, medr_mr_ins_prem, medr_mr_pure_prem;
    $char  ibirth_yy[5],ibirth_mm[3],tmp_dd[3], cfassured[2], iscope[6];
    $char  num_flag[2],medrdmg_flag[2],medrins_flag[2],medrpure_flag[2];
    $char  s_edrdmg_cover[13], s_edrins_prem[10], s_edrpure_prem[10];
    $char  s_edrins_amt[13], s_mr_ins_prem[10], s_mr_pure_prem[10];
     int   iedr_type_l;
    $long  edrpure_0102, edrpure_2100, edrins_0102, edrins_2100;
    $char  s_edrpure_2100[10], s_edrpure_0102[10], s_edrins_0102[10], s_edrins_2100[10];
     

    printf(" ======== ���I��� START ======== \n");
    
    sprintf(stmt,"SELECT a.iendorse, a.ipolicy , d.dpolicy, d.dply_begin, d.dply_end,\
                         a.dendorse, a.dedr_begin, a.dedr_end, b.fassured, b.iassured,\
                         b.fsex, b.ibirth, c.iins_type, c.iedr_type, c.medrdmg_cover,\
                         c.medrins_prem, c.medrpure_prem\
                    FROM %s:edr_relation a, %s:endorsement b, \
                         %s:edr_ins_type c, %s:ply_relation d\
                   WHERE a.iendorse = b.iendorse \
                     AND a.iendorse = c.iendorse \
                    AND a.ipolicy  = d.ipolicy  \
                     AND c.iins_type in ('33','47') \
                     AND a.dendorse BETWEEN ? AND ? ",
            DBnameFull,DBnameFull,DBnameFull,DBnameFull );
    printf("stmt[%s]\n",stmt); 
    $PREPARE car_edr FROM $stmt;
    $DECLARE car_e1  CURSOR for car_edr;
    $OPEN car_e1 USING $datebgn, $dateend;
    while(1)
    {
    	$FETCH car_e1 INTO $iendorse, $ipolicy, $dpolicy, $dbegin, $dend,
    	                   $dendorse, $dedr_begin, $dedr_end, $cfassured, $iassured,
    	                   $fsex, $ibirth, $iins_type, $iedr_type, $medrdmg_cover,
    	                   $medrins_prem, $medrpure_prem;
    	                   
    	if(SQLCODE == SQLNOTFOUND) break;
   
        printf("iendorse[%s] ipolicy[%s]\n", iendorse, ipolicy ); 	
        /**3.flagPG**/
        flagPG[0] = 'P';
        
        /**4.plycd**/
        strcpy(plycd,"17");
        strncat(plycd,ipolicy,2);
        plycd[4]='\0';

        /**5.ipolicy**/
        strncpy(ipolicy_into,&ipolicy[3],14);
        ipolicy_into[14] = '\0';
        strcat(ipolicy_into, " ");
        ipolicy_into[15] = '\0';

        /**7.edrcd**/
        strcpy(edrcd,"17");
        strncat(edrcd,iendorse,2);
        edrcd[4]='\0';

        /**8.endorse**/
        strncpy(iendorse_into,&iendorse[3],10);
        iendorse_into[10] = '\0';
        strcat(iendorse_into,"     ");
        iendorse_into[15] = '\0';
        printf("7.plydate\n"); 
        /**7.plydate**/
        if (risnull(SQLCHAR,dpolicy) != 1)
        {
            strncpy(plydate,  &dpolicy[6], 4);
            plydate[4] = '\0';
            strncat(plydate, &dpolicy[0], 2);
            plydate[6] = '\0';
            strncat(plydate, &dpolicy[3], 2);
        }
        else strcpy(plydate, "00000000");
        plydate[8] = '\0';
        printf("8.plybegin\n");
        /**8.plybegin**/
        if (risnull(SQLCHAR,dbegin) != 1)
        {
            strncpy(plybegin,  &dbegin[6], 4);
            plybegin[4] = '\0';
            strncat(plybegin, &dbegin[0], 2);
            plybegin[6] = '\0';
            strncat(plybegin, &dbegin[3], 2);
        }
        else strcpy(plybegin, "00000000");
        plybegin[8] = '\0';
        printf("8.dend\n");
        /**8.plyend**/
        if (risnull(SQLCHAR,dend) != 1)
        {
            strncpy(plyend,  &dend[6], 4);
            plyend[4] = '\0';
            strncat(plyend, &dend[0], 2);
            plyend[6] = '\0';
            strncat(plyend, &dend[3], 2);
        }
        else strcpy(plyend, "00000000");
        plyend[8] = '\0';        
    	
        /**9.edrdate**/
        if (risnull(SQLCHAR,dendorse) != 1)
        {
            strncpy(edrdate,  &dendorse[6], 4);
            edrdate[4] = '\0';
            strncat(edrdate, &dendorse[0], 2);
            edrdate[6] = '\0';
            strncat(edrdate, &dendorse[3], 2);
        }
        else strcpy(edrdate, "00000000");
        edrdate[8] = '\0';
        printf("edrbegin\n");
        /**10.edrbegin**/
        if (risnull(SQLCHAR,dedr_begin) != 1)
        {
            strncpy(edrbegin,  &dedr_begin[6], 4);
            edrbegin[4] = '\0';
            strncat(edrbegin, &dedr_begin[0], 2);
            edrbegin[6] = '\0';
            strncat(edrbegin, &dedr_begin[3], 2);
        }
        else strcpy(edrbegin, "00000000");
        edrbegin[8] = '\0';
        
        /**11.edrend**/
        if (risnull(SQLCHAR,dedr_end) != 1)
        {
            strncpy(edrend,  &dedr_end[6], 4);
            edrend[4] = '\0';
            strncat(edrend, &dedr_end[0], 2);
            edrend[6] = '\0';
            strncat(edrend, &dedr_end[3], 2);
        }
        else strcpy(edrend, "00000000");
        edrend[8] = '\0';
        
        /**12.member**/
        strcpy(member,"00000001");

        strcpy(iins_type, trim(iins_type));
        printf("iins_type[%s]\n", iins_type);
        /**   �H�U�̾�33�B47�����P���k **/
        if( strcmp(iins_type,"47")==0)
        {
            /** 1.iproduct **/
            $SELECT iproduct INTO $iproduct
               FROM cm_product_code
              WHERE iins_class = 'C'
                AND iins_type = $iins_type;
               
            strcpy(cfassured,trim(cfassured)); 
            /**13.id**/
            if ( strcmp(cfassured,"1")==0) 
            {
            	strcpy(idno, iassured);
                idno[10]='\0';
                strcpy(id, "1");
            }
	    else if( strcmp(cfassured,"3")==0) 
	    {
	        strcpy(idno, iassured);
                idno[10] = '\0';
                strcpy(id , "2");
	    }
	    else
	    { 
	        flagPG[0] = 'P';
	        id[0] = '9';
	        strcpy(idno, "0000000000");
	        ibirth[0] = '\0';
	    }

            /**14.sex**/
            if (strlen(rtrim(fsex)) == 0)
                sex[0] = '0';
            else
            {
                strcpy(sex, fsex);
                sex[1]='\0';
            }
            printf("id[%s] idno[%s] fsex[%s]\n", id, idno, sex );
            /**15.dbirth**/
            if (strlen(rtrim(ibirth)) == 0)
            {        
	        strcpy(dbirth, "00000000");
	    }
	    else
	    {
	        cm_split_ymd(ibirth,ibirth_yy,ibirth_mm,tmp_dd);

                if (strlen(rtrim(ibirth_yy)) == 0)
                {
                    strcpy(birth, "00000000");
                }
                else
                {
            	    strcpy(birth,itoa(1911+(atoi(ibirth_yy))));
            	    strcat(birth,ibirth_mm);
            	    strcat(birth,tmp_dd);
                }
            }
            
            iedr_type_l = atoi(iedr_type);
            printf("iedr_type_l[%d]\n", iedr_type_l);
            switch(iedr_type_l)
            {
                 case  1:
                          printf("in case 1 \n");
                          fedr_class = '1';
                          strcpy(num_flag,"-");
                          break;
                 case  2: case 60:
                          fedr_class = '2';
                          strcpy(num_flag,"-");
                          break;
                 case  5: case 50:
                          fedr_class = '7';
                          strcpy(num_flag,"+");
                          break;
                 case  4: case 76 : case 79 : case 75 :
                          fedr_class = '5';
                          strcpy(num_flag,"+");
                          break;
                 case 40: case 78 :
                 	  fedr_class = '6';
                          strcpy(num_flag,"+");
                          break;
                 case 80: case 81 : case 82 : case 83:
                          continue;
                          break;
                 default:
                          fedr_class = '5';
                          strcpy(num_flag,"+");
            }
            printf("set up flag \n"); 
            if( medrdmg_cover < 0 )
            {
               strcpy( medrdmg_flag,"-");
               medrdmg_cover = medrdmg_cover * (-1);
            }
            else 
               strcpy( medrdmg_flag,"+");
            
            if( medrins_prem < 0 )
            {
               strcpy( medrins_flag,"-");
               medrins_prem = medrins_prem * (-1);
               
               edrins_0102 = (long)( medrins_prem * 0.8741 - 0.5 );
               edrins_2100 = medrins_prem - edrins_2100;
            }
            else 
            {
               strcpy( medrins_flag,"+");
               
               edrins_0102 = (long)( medrins_prem * 0.8741 + 0.5 );
               edrins_2100 = medrins_prem - edrins_2100;
            }
               
            if( medrpure_prem < 0 )
            {
               strcpy( medrpure_flag,"-");
               medrpure_prem = medrpure_prem * (-1);
               
               edrpure_0102 = (long)( medrpure_prem * 0.8741 - 0.5 );
               edrpure_2100 = medrpure_prem - edrpure_2100;
            }
            else 
            {
               strcpy( medrpure_flag,"+");   
               
               edrpure_0102 = (long)( medrpure_prem * 0.8741 + 0.5 );
               edrpure_2100 = medrpure_prem - edrpure_2100;
            }
           
            rfmtlong(medrdmg_cover,"&&&&&&&&&&&&&",s_edrdmg_cover);
            s_edrdmg_cover[13] ='\0';
            /*
            rfmtlong(medrins_prem, "&&&&&&&&&&", s_edrins_prem );
            s_edrins_prem[10] = '\0';
            rfmtlong(medrpure_prem,"&&&&&&&&&&", s_edrpure_prem);
            s_edrpure_prem[10] ='\0';
            */

            /**
            $INSERT INTO ot_ply_edr_998
              VALUES('2',$iproduct, '2', '0', $plycd, $ipolicy_into,
                     $edrcd, $iendorse_into, $fedr_class,$plydate,
                     $plybegin,$plyend,$edrdate,$edrbegin,$edrend,
                     $edrbegin,$edrend,'+','00000000','0','0000000000','0','00000000',
                     '0000','+','0000000000000','000',$medrins_flag,$s_edrins_prem,
                     $medrpure_flag,$s_edrpure_prem,'0',$transferdate,'11');
            **/
            
            rfmtlong(edrins_0102, "&&&&&&&&&&", s_edrins_0102 );
            s_edrins_0102[10] = '\0';
            rfmtlong(edrpure_0102,"&&&&&&&&&&", s_edrpure_0102);
            s_edrpure_0102[10] ='\0';
            
            rfmtlong(edrins_2100, "&&&&&&&&&&", s_edrins_2100 );
            s_edrins_2100[10] = '\0';
            rfmtlong(edrpure_2100,"&&&&&&&&&&", s_edrpure_2100);
            s_edrpure_2100[10] ='\0';
            
            printf("before insert into ot_ply_edr_998\n"); 
            
            $INSERT INTO ot_ply_edr_998
              VALUES('2',$iproduct, '2', $flagPG, $plycd, $ipolicy_into,
                     $edrcd, $iendorse_into, $fedr_class,$plydate,
                     $plybegin,$plyend,$edrdate,$edrbegin,$edrend,
                     $edrbegin,$edrend,$num_flag,$member,$id,$idno,$sex,$birth,
                     '0102',$medrdmg_flag,$s_edrdmg_cover,'000',$medrins_flag,$s_edrins_0102,
                     $medrpure_flag,$s_edrpure_0102,'1',$transferdate,'11');
            
            $INSERT INTO ot_ply_edr_998
              VALUES('2',$iproduct, '2', $flagPG, $plycd, $ipolicy_into,
                     $edrcd, $iendorse_into, $fedr_class,$plydate,
                     $plybegin,$plyend,$edrdate,$edrbegin,$edrend,
                     $edrbegin,$edrend,$num_flag,$member,$id,$idno,$sex,$birth,
                     '2100',$medrdmg_flag,$s_edrdmg_cover,'000',$medrins_flag,$s_edrins_2100,
                     medrpure_flag,s_edrpure_2100,'1',$transferdate,'11');
            
    	}
    	else if( strcmp(iins_type,"33")==0)
    	{
    	    sprintf(stmt,"SELECT iinsurant, iedr_type, dbirth, iins_scope, \
                                 decode(icareer,'0','1',icareer), medrins_amt, \
                                 (medrins_prem-medr_mr_ins_prem), (medrpure_prem - medr_mr_pure_prem), \
                                 medr_daily_pay,medr_mr_ins_prem,medr_mr_pure_prem \
                            FROM %s:ca_pa_edr \
                           WHERE iendorse = ?",DBnameFull );
            $PREPARE car_epa FROM $stmt;
            $DECLARE car_e2 CURSOR FOR car_epa;
            $OPEN car_e2 USING $ipolicy;
            while(1)
            {
               $FETCH car_e2 INTO $iinsurant, $iedr_type, $ibirth, $iins_scope, 
                                  $icareer, $medrins_amt,
                                  $medrins_prem, $medrpure_prem,
                                  $medr_daily_pay,$medr_mr_ins_prem,$medr_mr_pure_prem;
               if(SQLCODE == SQLNOTFOUND) break;

                /** iproduct **/
                $SELECT iproduct INTO $iproduct
                   FROM cm_product_code
                  WHERE iins_class = 'C'
                    AND iins_type = $iins_type
                    AND icode1 = $iins_scope;

                 /**13~15**/
                id[0] = '1';
                strcpy(idno, iinsurant);
                if (memcmp(&iinsurant[1], "1", 1) == 0)
                    sex[0]='1';
                else
                    sex[0]='2';

                if (risnull(SQLCHAR,ibirth) != 1)
                {
                    strncpy(birth,  &ibirth[6], 4);
                    birth[4] = '\0';
                    strncat(birth, &ibirth[0], 2);
                    birth[6] = '\0';
                    strncat(birth, &ibirth[3], 2);
                }
                else strcpy(birth, "00000000");
                birth[8] = '\0';

                iedr_type_l = atoi(iedr_type);
                switch(iedr_type_l)
                {
                    case  1:
                          fedr_class = '1';
                          strcpy(num_flag,"-");
                          break;
                    case  2: case 60:
                          fedr_class = '2';
                          strcpy(num_flag,"-");
                          break;
                    case  5: case 50:
                          fedr_class = '7';
                          strcpy(num_flag,"+");
                          break;
                    case  4: case 76 : case 79 : case 75 :
                          fedr_class = '5';
                          strcpy(num_flag,"+");
                          break;
                    case 40: case 78 :
                          fedr_class = '6';
                          strcpy(num_flag,"+");
                          break;
                    case 80: case 81 : case 82 : case 83:
                          continue;
                          break;
                    default:
                          fedr_class ='5';
                          strcpy(num_flag,"+");
                }

                if( medrins_amt < 0 )
                {
                    strcpy( medrdmg_flag,"-");
                    medrins_amt = medrins_amt * (-1);
                }
                else
                    strcpy( medrdmg_flag,"+");

                if( medrins_prem < 0 )
                {
                    strcpy( medrins_flag,"-");
                    medrins_prem = medrins_prem * (-1);
                }
                else
                    strcpy( medrins_flag,"+");

                if( medrpure_prem < 0 )
                {
                    strcpy( medrpure_flag,"-");
                    medrpure_prem = medrpure_prem * (-1);
                }
                else
                    strcpy( medrpure_flag,"+");

                if(strcmp(iins_scope,"1")==0)
                {
                    strcpy( iscope, "0102");
                }
                else
                {
                    strcpy( iscope, "0100");
                }
               
                rfmtlong(medrins_amt,"&&&&&&&&&&&&&",s_edrins_amt);
                s_edrins_amt[13] = '\0';
                rfmtlong(medrins_prem, "&&&&&&&&&&", s_edrins_prem);
                s_edrins_prem[10] ='\0';
                rfmtlong(medrpure_prem, "&&&&&&&&&&",s_edrpure_prem);
                s_edrpure_prem[10] ='\0';
 
                printf("33 insert into ot_ply_edr_998\n");
                
                /**
                $INSERT INTO ot_ply_edr_998
                 VALUES('2',$iproduct, '2', '0', $plycd, $ipolicy_into,
                        $edrcd, $iendorse_into, $fedr_class,$plydate,
                        $plybegin,$plyend,$edrdate,$edrbegin,$edrend,
                        $edrbegin,$edrend,'+','00000000','0','0000000000','0','00000000',
                        '0000','+','0000000000000','000',$medrins_flag,$s_edrins_prem,
                        $medrpure_flag,$s_edrpure_prem,'0',$transferdate,'11');
                **/
                
                $INSERT INTO ot_ply_edr_998
                 VALUES('2',$iproduct, '2', $flagPG, $plycd, $ipolicy_into,
                        $edrcd, $iendorse_into, $fedr_class,$plydate,
                        $plybegin,$plyend,$edrdate,$edrbegin,$edrend,
                        $edrbegin,$edrend,$num_flag,$member,$id,$idno,$sex,$birth,
                        $iscope,$medrdmg_flag,$s_edrins_amt,'000',$medrins_flag,$s_edrins_prem,
                        $medrpure_flag,$s_edrpure_prem,$icareer,$transferdate,'11');
                
                if(strcmp(iins_scope,"3")==0)
                {
                   if( medr_daily_pay < 0 )
                   {
                       strcpy( medrdmg_flag,"-");
                       medr_daily_pay = medr_daily_pay * (-1);
                   }
                   else
                       strcpy( medrdmg_flag,"+");

                   if( medr_mr_ins_prem < 0 )
                   {
                       strcpy( medrins_flag,"-");
                       medr_mr_ins_prem = medr_mr_ins_prem * (-1);
                   }
                   else
                       strcpy( medrins_flag,"+");

                   if( medr_mr_pure_prem < 0 )
                   {
                       strcpy( medrpure_flag,"-");
                       medr_mr_pure_prem = medr_mr_pure_prem * (-1);
                   }
                   else
                       strcpy( medrpure_flag,"+");

                   rfmtlong(medr_mr_ins_prem,"&&&&&&&&&&",s_mr_ins_prem);
                   s_mr_ins_prem[10]='\0';
                   rfmtlong(medr_mr_pure_prem,"&&&&&&&&&&",s_mr_pure_prem);
                   s_mr_pure_prem[10] = '\0';
                   
                   /**
                   $INSERT INTO ot_ply_edr_998
                    VALUES('2',$iproduct, '2', '0', $plycd, $ipolicy_into,
                           $edrcd, $iendorse_into, $fedr_class,$plydate,
                           $plybegin,$plyend,$edrdate,$edrbegin,$edrend,
                           $edrbegin,$edrend,'+','00000000','0','0000000000','0','00000000',
                           '0000','+','0000000000000','000',$medrins_flag,$s_mr_ins_prem,
                           $medrpure_flag,$s_mr_pure_prem,'0',$transferdate,'11');
                   **/
                   
                   $INSERT INTO ot_ply_edr_998
                    VALUES('2',$iproduct, '2', $flagPG, $plycd, $ipolicy_into,
                           $edrcd, $iendorse_into, $fedr_class,$plydate,
                           $plybegin,$plyend,$edrdate,$edrbegin,$edrend,
                           $edrbegin,$edrend,$num_flag,$member,$id,$idno,$sex,$birth,
                           '2200',$medrdmg_flag,$medr_daily_pay,'000',$medrins_flag,$s_mr_ins_prem,
                           $medrpure_flag,$s_mr_pure_prem,$icareer,$transferdate,'11');
                   
                }

            }
            $CLOSE car_e2;
            $FREE  car_e2;
   	    
    	}
    	
    }
    $CLOSE car_e1;
    $FREE  car_e1;

    printf(" ======== ���I��� END ======== \n");

    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;

}

int oth998_accumu_car_clm()
{

    $char item1[5], item2[3], item3[5], item4[2], career_type[2], flagPG[2];
    $char iproduct[13], iins_scope[3], ipolicy[21], iclaim[21];
    $char daccident[11], dclaim[11], dgroup[11], resp_type, ireason[11];
    $char fassured, risk_area[4], dbegin[11], dend[11], pcosharecd;
    $char icareer[8], idanger_type[3], ndanger_type[5];
    $char iclaimcd[5], iclaim_into[16], iclaim_sno_into[4], txcd[2];
    $char plycd[5], ipolicy_into[16], daccident_into[9], dclaim_into[9];
    $char dgroup_into[7], plybegin[9], plyend[9], mins_deduct_into[13];
    $char nreason[4], pcoshare_into[6], idanger_unit[3], fsettle, iins_kind[5];
    $char nonrespamt[14] ,biaopamt[11], biaoaamt[11], pdaoaamt[11], cslamt[14];
    $char totamtcd, totamt[14], nasscd, qdanger_unit_into[8];
    $double pcoshare;
    $int  iclaim_sno, qdanger_unit, i;
    $double money[4], mins_deduct, mins_cover;
    $char iins_type[5], isscd;
    char DBnameFull_2[21];

    $char  fstl[2], flast[3];
    $char  dclaim_c[20], daccident_c[15], iacc_reason[3];
    $char  istl_recover[2], fdecide[2], iins_item[6];
    $char  iassured[11], fsex[2], ibirth[11];
    $char  ibirth_yy[5],ibirth_mm[3],tmp_dd[3], iscope[6];
    $int   iclose_type;
    $long  mins_stl,mins_proc,mdamage_cover;
    $char  s_mins_stl[13], s_mins_proc[8], s_mdamage_cover[13];

    printf(" ======== ���I�z�� START ======= \n");
    
    sprintf(stmt,"SELECT a.iclaim, a.fstl, a.iclose_type, a.iins_type, \
                         a.mins_stl, a.mins_proc, a.dgroup, a.flast, \
                         b.ipolicy, b.dclaim, b.daccident, b.iacc_reason, \
                         c.dply_begin, c.dply_end, c.iassured, \
                         c.ibirth, c.fsex, d.istl_recover \
                    FROM %s:stl_ins_type a, %s:appraisal b, %s:adjustment_ply c, \
                         %s:settlement d \
                   WHERE a.iclaim = b.iclaim \
                     AND b.iclaim = c.iclaim \
                     AND b.iclaim = d.iclaim \
                     AND a.iins_type in ('33','47')\
                     AND a.dgroup between ? and ? ",
                 DBnameFull,DBnameFull,DBnameFull,DBnameFull);

    printf("stmt[%s]\n", stmt);
    $PREPARE cur_cclm FROM $stmt;
    $DECLARE cur_co1 CURSOR for cur_cclm;
    $OPEN cur_co1 using $datebgn, $dateend;
    while(1)
    {
    	$FETCH cur_co1 INTO $iclaim, $fstl, $iclose_type, $iins_type, $mins_stl,
    	                    $mins_proc, $dgroup, $flast, $ipolicy, $dclaim_c,
    	                    $daccident_c, $iacc_reason, $dbegin, $dend, 
    	                    $iassured, $ibirth, $fsex, $istl_recover;
    	
    	if(SQLCODE == SQLNOTFOUND) break;
        
        printf("iclaim[%s]\n", iclaim );	
        flagPG[0] = 'P';
        
        /**4.iclaimcd**/
        strcpy(iclaimcd,"17");
        strncat(iclaimcd,iclaim,2);
        iclaimcd[4]='\0';

        /**5.iclaim**/
        strncpy(iclaim_into,&iclaim[3],8);
        iclaim_into[8] = '\0';
        strcat(iclaim_into,"       ");
        iclaim_into[15] = '\0';
        
        /**6.iclaim_sno**/
        sprintf(iclaim_sno_into,"%04d", iclose_type);
        iclaim_sno_into[4] = '\0';
       
        printf("iclaim_sno_into\n");
 
        /**7.plycd**/
        strcpy(plycd,"17");
        strncat(plycd,ipolicy,2);
        plycd[4]='\0';

        /**8.ipolicy**/
        strncpy(ipolicy_into,&ipolicy[3],14);
        ipolicy_into[14] = '\0';
        strcat(ipolicy_into, " ");
        ipolicy_into[15] = '\0';        

        printf("ipolicy_into\n");
        /**11.daccident**/
        if (risnull(SQLCHAR,daccident_c) != 1)
        {
            strncpy(daccident_into, &daccident_c[0], 4);
            daccident_into[4] = '\0';
            strncat(daccident_into, &daccident_c[5], 2);
            daccident_into[6] = '\0';
            strncat(daccident_into, &daccident_c[8], 2);
        }
        else strcpy(daccident_into, "00000000");
        daccident_into[8] = '\0';

        printf("daccident_into\n");
        /**12.dclaim**/
        if (risnull(SQLCHAR,dclaim_c) != 1)
        {
            strncpy(dclaim_into, &dclaim_c[0], 4);
            dclaim_into[4] = '\0';
            strncat(dclaim_into, &dclaim_c[5], 2);
            dclaim_into[6] = '\0';
            strncat(dclaim_into, &dclaim_c[8], 2);
        }
        else strcpy(dclaim_into, "00000000");
        dclaim_into[8] = '\0';
        
        printf("dclaim_into[%s]\n",dclaim_into);
        /**13.dgroup**/
        if (risnull(SQLCHAR,dgroup) != 1)
        {
            strncpy(dgroup_into,  &dgroup[6], 4);
            dgroup_into[4] = '\0';
            strncat(dgroup_into, &dgroup[0], 2);
        }
        else strcpy(dgroup_into, "000000");
        dgroup_into[6] = '\0';

        /**14.plybegin**/
        if (risnull(SQLCHAR,dbegin) != 1)
        {
            strncpy(plybegin,  &dbegin[6], 4);
            plybegin[4] = '\0';
            strncat(plybegin, &dbegin[0], 2);
            plybegin[6] = '\0';
            strncat(plybegin, &dbegin[3], 2);
        }
        else strcpy(plybegin, "00000000");
        plybegin[8] = '\0';

        /**15.plyend**/
        if (risnull(SQLCHAR,dend) != 1)
        {
            strncpy(plyend,  &dend[6], 4);
            plyend[4] = '\0';
            strncat(plyend, &dend[0], 2);
            plyend[6] = '\0';
            strncat(plyend, &dend[3], 2);
        }
        else strcpy(plyend, "00000000");
        plyend[8] = '\0';
        
        strcpy(fstl, trim(fstl));
        strcpy(iins_type, trim(iins_type));
        printf("iins_type[%s]\n");
        if(strcmp(iins_type, "47")==0)
        {
            
            sprintf(stmt,"SELECT mdamage_cover FROM %s:ori_ins_type \
                           WHERE ipolicy = '%s' AND iins_type = '47'", 
                           DBnameFull, ipolicy );
            $PREPARE cur_o1 FROM $stmt;
            $EXECUTE cur_o1 INTO $mdamage_cover;

            printf("===> iins_type[%s]\n", iins_type);            
            /** 1.iproduct **/
            $SELECT iproduct INTO $iproduct
               FROM cm_product_code
              WHERE iins_class = 'C'
                AND iins_type = '47';
            
            /**13.id**/
            if( isalpha(iassured[0]) == 0 )
            {
            	strcpy(idno, iassured);
            	strcpy(id, "1");
            }
	    else
	    { 
	        id[0] = '9';
	        strcpy(idno, "0000000000");
	        flagPG[0] = 'Z';
	        ibirth[0] = '\0';
	    }

            /**14.sex**/
            if (strlen(rtrim(fsex)) == 0)
                sex[0] = '0';
            else
            {
                strcpy(sex, fsex);
                sex[1]='\0';
            }
            printf("id[%s] idno[%s] fsex[%s]\n", id, idno, sex );
            /**15.dbirth**/
            if (strlen(rtrim(ibirth)) == 0)
            {        
	        strcpy(dbirth, "00000000");
	    }
	    else
	    {
	        cm_split_ymd(ibirth,ibirth_yy,ibirth_mm,tmp_dd);

                if (strlen(rtrim(ibirth_yy)) == 0)
                {
                    strcpy(birth, "00000000");
                }
                else
                {
            	    strcpy(birth,itoa(1911+(atoi(ibirth_yy))));
            	    strcat(birth,ibirth_mm);
            	    strcat(birth,tmp_dd);
                }
            }
            printf("birth[%s]\n", birth); 
            /** nreason **/
            sprintf(stmt,"SELECT pacc_reason, iins_item FROM %s:app_pa_type \
                           WHERE iclaim = '%s' AND pa_ins = '47'", 
                           DBnameFull, iclaim );
            $PREPARE cur_cl1 FROM $stmt;
            $EXECUTE cur_cl1 INTO $nreason, $iins_item;
            
            /** txcd **/
            if(strcmp(fstl,"1") == 0)
               strcpy( txcd ,"1");
            else
               strcpy( txcd ,"4");
           
            printf("txcd[%s]\n", txcd );
            /** fdecide **/
            if((strcmp(trim(istl_recover),"2")==0) || (strcmp(trim(istl_recover),"2")==0))
            {
            	strcpy( fdecide , "P");
            }
            else
                strcpy( fdecide , "S");
            
            printf("fdecide[%s] \n");

            rfmtlong(mins_stl,"&&&&&&&&&&&&&",s_mins_stl);
            s_mins_stl[13]='\0';
            rfmtlong(mins_proc,"&&&&&&&&",s_mins_proc);
            s_mins_proc[10]='\0';
            rfmtlong(mdamage_cover,"&&&&&&&&&&&&&",s_mdamage_cover);
            s_mdamage_cover[13]='\0';
            
            if( iins_item[0] == 'A' )
            {
                strcpy( item1, "2100");
                strcpy( item2, "21");
                strcpy( item3, "0001");
            }
            else if( iins_item[0] == 'B' )
            {
                strcpy( item1, "0102");
                strcpy( item2, "02");
                strcpy( item3, "0102");
            }
            else
            {
            	strcpy( item1, "0102");
            	strcpy( item2, "03");
            	strcpy( item3, "0102");
            }
            
            /**
            $INSERT INTO ot_app_stl_998
                 VALUES('1',$iproduct, '2', '0', $iclaimcd, $iclaim_into,
                        $iclaim_sno_into, $plycd, $ipolicy_into,
                        $daccident_into, '00000000', '00000000',
                        $plybegin, '00000000', '0', '0000000000', '0', '00000000',
                        $nreason, $txcd, $fdecide, '0000',
                        '+',$s_mins_stl, '+', $s_mins_proc, '00','0000',
                        '0',$transferdate,'0000000000000','11');
            **/
                        
            $INSERT INTO ot_app_stl_998
                 VALUES('1',$iproduct, '2', $flagPG, $iclaimcd, $iclaim_into,
                        $iclaim_sno_into, $plycd, $ipolicy_into,
                        $daccident_into, $dclaim_into, $dgroup_into,
                        $plybegin, $plyend, $id, $idno, $sex, $dbirth,
                        $nreason, $txcd, $fdecide, $item1,
                        '+',$s_mins_stl, '+', $s_mins_proc, $item2, $item3,
                        '1',$transferdate,$s_mdamage_cover,'11');
            
        }
        else
        {
           printf(" iclaim [%s] \n",iclaim );        	
           sprintf(stmt,"SELECT mdamage_cover FROM %s:ori_ins_type \
                           WHERE ipolicy = '%s' AND iins_type = '33'", 
                           DBnameFull, ipolicy );
            $PREPARE cur_o1_out FROM $stmt;
            $EXECUTE cur_o1_out INTO $mdamage_cover;

            printf("===> iins_type[%s]\n", iins_type);            
            /** 1.iproduct **/
            $SELECT iproduct INTO $iproduct
               FROM cm_product_code
              WHERE iins_class = 'C'
                AND iins_type = '33'
                AND icode1 = '1';
            
            /**13.id**/
            if( isalpha(iassured[0]) == 0 )
            {
            	strcpy(idno, iassured);
            	strcpy(id, "1");
            }
	    else
	    { 
	        id[0] = '9';
	        strcpy(idno, "0000000000");
	    }

            /**14.sex**/
            if (strlen(rtrim(fsex)) == 0)
                sex[0] = '0';
            else
            {
                strcpy(sex, fsex);
                sex[1]='\0';
            }
            printf("id[%s] idno[%s] fsex[%s]\n", id, idno, sex );
            /**15.dbirth**/
            if (strlen(rtrim(ibirth)) == 0)
            {        
	        strcpy(dbirth, "00000000");
	    }
	    else
	    {
	        cm_split_ymd(ibirth,ibirth_yy,ibirth_mm,tmp_dd);

                if (strlen(rtrim(ibirth_yy)) == 0)
                {
                    strcpy(birth, "00000000");
                }
                else
                {
            	    strcpy(birth,itoa(1911+(atoi(ibirth_yy))));
            	    strcat(birth,ibirth_mm);
            	    strcat(birth,tmp_dd);
                }
            }
            printf("birth[%s]\n", birth); 
            /** nreason **/
             /** nreason **/
            sprintf(stmt,"SELECT pacc_reason, iins_item, iins_scope FROM %s:app_pa_type \
                           WHERE iclaim = '%s' AND pa_ins = '33'", 
                           DBnameFull, iclaim );
            $PREPARE cur_cl2 FROM $stmt;
            $EXECUTE cur_cl2 INTO $nreason, $iins_item, $iins_scope;
            
            /** txcd **/
            if(strcmp(fstl,"1") == 0)
               strcpy( txcd ,"1");
            else
               strcpy( txcd ,"4");
           
            printf("txcd[%s]\n", txcd );
            /** fdecide **/
            if((strcmp(trim(istl_recover),"2")==0) || (strcmp(trim(istl_recover),"2")==0))
            {
            	strcpy( fdecide , "P");
            }
            else
                strcpy( fdecide , "S");
            
            printf("fdecide[%s] \n");

            rfmtlong(mins_stl,"&&&&&&&&&&&&&",s_mins_stl);
            s_mins_stl[13]='\0';
            rfmtlong(mins_proc,"&&&&&&&&",s_mins_proc);
            s_mins_proc[10]='\0';
            rfmtlong(mdamage_cover,"&&&&&&&&&&&&&",s_mdamage_cover);
            s_mdamage_cover[13]='\0';
 
            if( iins_item[0] == 'A' )
            {
                strcpy( item1, "2200");
                strcpy( item2, "22");
                strcpy( item3, "0001");
            }
            else if( iins_item[0] == 'B' )
            {
                if( iins_scope[0] == '1' )
                {
                    strcpy( item1, "0102");
                    strcpy( item3, "0102");
                }
                else
                {
                    strcpy( item1, "0100");
                    strcpy( item3, "0100");
                }        
                strcpy( item2, "02");
                
            }
            else
            {
            	if( iins_scope[0] == '1' )
                {
                    strcpy( item1, "0102");
                    strcpy( item3, "0102");
                }
                else
                {
                    strcpy( item1, "0100");
                    strcpy( item3, "0100");
                }
            	strcpy( item2, "03");
            	
            }
            
            printf(" ********************** before insert ******************* \n");
            /**
            $INSERT INTO ot_app_stl_998
                 VALUES('1',$iproduct, '2', '0', $iclaimcd, $iclaim_into,
                        $iclaim_sno_into, $plycd, $ipolicy_into,
                        $daccident_into, '00000000', '00000000',
                        $plybegin, '00000000', '0', '0000000000', '0', '00000000',
                        $nreason, $txcd, $fdecide, '0000',
                        '+',$s_mins_stl, '+', $s_mins_proc, '00','0000',
                        '0',$transferdate,'0000000000000','11');
            **/
            
            $INSERT INTO ot_app_stl_998
                 VALUES('1',$iproduct, '2', $flagPG, $iclaimcd, $iclaim_into,
                        $iclaim_sno_into, $plycd, $ipolicy_into,
                        $daccident_into, $dclaim_into, $dgroup_into,
                        $plybegin, $plyend, $id, $idno, $sex, $dbirth,
                        $nreason, $txcd, $fdecide, $item1,
                        '+',$s_mins_stl, '+', $s_mins_proc, $item2, $item3,
                        '1',$transferdate,$s_mdamage_cover,'11');
            
            printf("===oth998_accumu_car_clm insert compelete====\n");            
            
        }
        
    }
    $CLOSE cur_co1;
    $FREE  cur_co1;
    
    printf(" ======== ���I�z�� END ======= \n");
    
    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;

}

/* ************************************************* */
int oth998_accumu_car_out()
{
    $int test_count;
    $char item1[5], item2[3], item3[5], item4[2], career_type[2], flagPG[2];
    $char iproduct[13], iins_scope[3], ipolicy[21], iclaim[21];
    $char daccident[11], dclaim[11], dgroup[11], resp_type, ireason[11];
    $char fassured, risk_area[4], dbegin[11], dend[11], pcosharecd;
    $char icareer[8], idanger_type[3], ndanger_type[5];
    $char iclaimcd[5], iclaim_into[16], iclaim_sno_into[4], txcd[2];
    $char plycd[5], ipolicy_into[16], daccident_into[9], dclaim_into[9];
    $char dgroup_into[7], plybegin[9], plyend[9], mins_deduct_into[13];
    $char nreason[4], pcoshare_into[6], idanger_unit[3], fsettle, iins_kind[5];
    $char nonrespamt[14] ,biaopamt[11], biaoaamt[11], pdaoaamt[11], cslamt[14];
    $char totamtcd, totamt[14], nasscd, qdanger_unit_into[8];
    $double pcoshare;
    $int  iclaim_sno, qdanger_unit, i;
    $double money[4], mins_deduct, mins_cover;
    $char iins_type[5], isscd;
    char DBnameFull_2[21];

    $char  fstl[2], flast[3];
    $char  dclaim_c[20], daccident_c[15], iacc_reason[3];
    $char  istl_recover[2], fdecide[2], iins_item[6];
    $char  iassured[11], fsex[2], ibirth[11];
    $char  ibirth_yy[5],ibirth_mm[3],tmp_dd[3], iscope[6];
    $int   iclose_type;
    $long  mins_stl,mins_proc,mdamage_cover,mins_app,mproc_app;
    $char  s_mins_stl[13], s_mins_proc[8], s_mdamage_cover[13];
    $char  s_mins_app[13], s_mproc_app[8];

    printf(" ======== ���I�z�ߥ��M  START ======= \n");
    printf(" dateend[%s]\n",dateend);
    
    sprintf(stmt,"SELECT a.iclaim,  a.iins_type, \
                         a.mins_app, a.mproc_app,  \
                         b.ipolicy, b.dclaim, b.daccident, b.iacc_reason, \
                         c.dply_begin, c.dply_end, c.iassured, \
                         c.ibirth, c.fsex \
                    FROM %s:app_ins_type a, %s:appraisal b, %s:adjustment_ply c \
                   WHERE a.iclaim = b.iclaim \
                     AND b.iclaim = c.iclaim \
                     AND a.iins_type in ('33','47')\
                     AND DATE(b.daccident) < ?     \
                     AND a.fclose <> '1' ",
                 DBnameFull,DBnameFull,DBnameFull);

    printf("stmt[%s]\n", stmt);
    $PREPARE cur_cclm_out FROM $stmt;
    $DECLARE cur_co1_out CURSOR for cur_cclm_out;
    $OPEN cur_co1_out using $dateend;
    while(1)
    {
    	$FETCH cur_co1_out INTO $iclaim, $iins_type,
    	                        $mins_app,$mproc_app,
    	                   $ipolicy, $dclaim_c,$daccident_c, $iacc_reason,
    	                   $dbegin, $dend,$iassured, 
    	                   $ibirth, $fsex;
    	                   
         if(SQLCODE == SQLNOTFOUND) break;
         
         sprintf(stmt,"SELECT a.fstl, a.iclose_type, \
                              a.dgroup, a.flast,     \
                              b.istl_recover,        \
                              a.mins_stl, a.mins_proc \
                    FROM %s:stl_ins_type a, %s:settlement b  \
                   WHERE a.iclaim = '%s'    \
                     AND a.iclaim = b.iclaim \
                     AND a.fstl = b.fstl     \
                     AND a.iclose_type = b.iclose_type \
                     AND a.iins_type in ('33','47')\
                     AND a.dgroup is not null   ",
                 DBnameFull,DBnameFull,iclaim );

    printf("stmt[%s]\n", stmt);
    
    $PREPARE cur_col_stl_out FROM $stmt;
    $EXECUTE cur_col_stl_out into $fstl, $iclose_type,
                                  $dgroup,$flast,
                                  $istl_recover,
                                  $mins_stl,$mins_proc;
    	
    	if(SQLCODE != SQLNOTFOUND) 
    	{ 
    	  mins_app = mins_app - mins_stl;
    	  mproc_app = mproc_app - mins_proc;
    	  strcpy( fdecide , "P");
    	}
    	else
    	{
          strcpy(dgroup,"");
          iclose_type = 0;		
          strcpy( fdecide , "U");
        }
    	
        printf("iclaim[%s]\n", iclaim );	
        /**4.iclaimcd**/
        strcpy(iclaimcd,"17"); 
        strncat(iclaimcd,iclaim,2);
        iclaimcd[4]='\0';

        /**5.iclaim**/
        strncpy(iclaim_into,&iclaim[3],8);
        iclaim_into[8] = '\0';
        strcat(iclaim_into,"       ");
        iclaim_into[15] = '\0';
        
        printf("iclaim[%s]\n",iclaim );     
        /**6.iclaim_sno**/
        sprintf(iclaim_sno_into,"%04d", iclose_type);
        iclaim_sno_into[4] = '\0';
       
        printf("iclaim_sno_into\n");
 
        /**7.plycd**/
        strcpy(plycd,"17");
        strncat(plycd,ipolicy,2);
        plycd[4]='\0';
       
        printf("ipolicy[%s]\n", ipolicy );
        /**8.ipolicy**/
        strncpy(ipolicy_into,&ipolicy[3],14);
        ipolicy_into[14] = '\0';
        strcat(ipolicy_into, " ");
        ipolicy_into[15] = '\0';
        
        printf("daccident[%s]\n", daccident_c );
        /**11.daccident**/
        if (risnull(SQLCHAR,daccident_c) != 1)
        {
            strncpy(daccident_into, &daccident_c[0], 4);
            daccident_into[4] = '\0';
            strncat(daccident_into, &daccident_c[5], 2);
            daccident_into[6] = '\0';
            strncat(daccident_into, &daccident_c[8], 2);
        }
        else strcpy(daccident_into, "00000000");
        daccident_into[8] = '\0';
        
        printf("dclaim[%s]\n", dclaim_c );
        /**12.dclaim**/
        if (risnull(SQLCHAR,dclaim_c) != 1)
        {
            strncpy(dclaim_into, &dclaim_c[0], 4);
            dclaim_into[4] = '\0';
            strncat(dclaim_into, &dclaim_c[5], 2);
            dclaim_into[6] = '\0';
            strncat(dclaim_into, &dclaim_c[8], 2);
        }
        else strcpy(dclaim_into, "00000000");
        dclaim_into[8] = '\0';
        
        printf("dclaim_into[%s]\n",dclaim_into);
        printf("dgroup[%s]\n", dgroup );
        /**13.dgroup**/
        if (risnull(SQLCHAR,dgroup) != 1)
        {
            printf(" *************************** \n");
            strncpy(dgroup_into,  &dgroup[6], 4);
            dgroup_into[4] = '\0';
            strncat(dgroup_into, &dgroup[0], 2);
        }
        else strcpy(dgroup_into, "000000");
        dgroup_into[6] = '\0';
       
        printf("plybegin[%s]\n", dbegin );
        /**14.plybegin**/
        if (risnull(SQLCHAR,dbegin) != 1)
        {
            strncpy(plybegin,  &dbegin[6], 4);
            plybegin[4] = '\0';
            strncat(plybegin, &dbegin[0], 2);
            plybegin[6] = '\0';
            strncat(plybegin, &dbegin[3], 2);
        }
        else strcpy(plybegin, "00000000");
        plybegin[8] = '\0';
        
         printf("plyend[%s]\n", dend );
        /**15.plyend**/
        if (risnull(SQLCHAR,dend) != 1)
        {
            strncpy(plyend,  &dend[6], 4);
            plyend[4] = '\0';
            strncat(plyend, &dend[0], 2);
            plyend[6] = '\0';
            strncat(plyend, &dend[3], 2);
        }
        else strcpy(plyend, "00000000");
        plyend[8] = '\0';
        
        strcpy(fstl, trim(fstl));
        strcpy(iins_type, trim(iins_type));
        flagPG[0] = 'P';
        
        printf("iins_type[%s]\n");
        if(strcmp(iins_type, "47")==0)
        {
            
            sprintf(stmt,"SELECT mdamage_cover FROM %s:ori_ins_type \
                           WHERE ipolicy = '%s' AND iins_type = '47'", 
                           DBnameFull, ipolicy );
            $PREPARE cur_o1_out FROM $stmt;
            $EXECUTE cur_o1_out INTO $mdamage_cover;
            
            /** 1.iproduct **/
            $SELECT iproduct INTO $iproduct
               FROM cm_product_code
              WHERE iins_class = 'C'
                AND iins_type = '47';
            
            /**13.id**/
            if( isalpha(iassured[0]) == 0 )
            {
            	strcpy(idno, iassured);
            	strcpy(id, "1");
            }
	    else
	    { 
	        id[0] = '9';
	        strcpy(idno, "0000000000");
	        flagPG[0] = 'Z';
	        ibirth[0] = '\0';
	    }

            /**14.sex**/
            if (strlen(rtrim(fsex)) == 0)
                sex[0] = '0';
            else
            {
                strcpy(sex, fsex);
                sex[1]='\0';
            }
            printf("id[%s] idno[%s] fsex[%s]\n", id, idno, sex );
            /**15.dbirth**/
            if (strlen(rtrim(ibirth)) == 0)
            {        
	        strcpy(dbirth, "00000000");
	    }
	    else
	    {
	        cm_split_ymd(ibirth,ibirth_yy,ibirth_mm,tmp_dd);

                if (strlen(rtrim(ibirth_yy)) == 0)
                {
                    strcpy(birth, "00000000");
                }
                else
                {
            	    strcpy(birth,itoa(1911+(atoi(ibirth_yy))));
            	    strcat(birth,ibirth_mm);
            	    strcat(birth,tmp_dd);
                }
            }
            printf("birth[%s]\n", birth); 
            /** nreason **/
            sprintf(stmt,"SELECT pacc_reason, iins_item FROM %s:app_pa_type \
                           WHERE iclaim = '%s' AND pa_ins = '47'", 
                           DBnameFull, iclaim );
            $PREPARE cur_clx FROM $stmt;
            $EXECUTE cur_clx INTO $nreason, $iins_item;
            
            /** txcd **/
            if(strcmp(fstl,"1") == 0)
               strcpy( txcd ,"1");
            else
               strcpy( txcd ,"4");
           
            printf("txcd[%s]\n", txcd );
            /** fdecide **/
            
            if( iins_item[0] == 'A' )
            {
                strcpy( item1, "2100");
                strcpy( item2, "21");
                strcpy( item3, "0001");
            }
            else if( iins_item[0] == 'B' )
            {
                strcpy( item1, "0102");
                strcpy( item2, "02");
                strcpy( item3, "0102");
            }
            else
            {
            	strcpy( item1, "0102");
            	strcpy( item2, "03");
            	strcpy( item3, "0102");
            }
            
            printf("fdecide[%s] \n");
            
            rfmtlong(mins_app,"&&&&&&&&&&&&&",s_mins_app);
            s_mins_app[13]='\0';
            rfmtlong(mproc_app,"&&&&&&&&",s_mproc_app);
            s_mproc_app[10]='\0';
            rfmtlong(mdamage_cover,"&&&&&&&&&&&&&",s_mdamage_cover);
            s_mdamage_cover[13]='\0';
 
            /**
            $INSERT INTO ot_app_stl_998
                 VALUES('2',$iproduct, '2', '0', $iclaimcd, $iclaim_into,
                        $iclaim_sno_into, $plycd, $ipolicy_into,
                        $daccident_into, '00000000', '00000000',
                        $plybegin, '00000000', '0', '0000000000', '0', '00000000',
                        $nreason, $txcd, $fdecide, '0000',
                        '+',$s_mins_app, '+', $s_mproc_app, '00','0000',
                        '0',$transferdate,'0000000000000','11');
            **/
            
            $INSERT INTO ot_app_stl_998
                 VALUES('1',$iproduct, '2', $flagPG, $iclaimcd, $iclaim_into,
                        $iclaim_sno_into, $plycd, $ipolicy_into,
                        $daccident_into, $dclaim_into, $dgroup_into,
                        $plybegin, $plyend, $id, $idno, $sex, $dbirth,
                        $nreason, $txcd, $fdecide, $item1,
                        '+',$s_mins_stl, '+', $s_mins_proc, $item2, $item3,
                        '1',$transferdate,$s_mdamage_cover,'11');
            
        }
        else
        {
        	
           printf(" iclaim [%s] \n",iclaim );        	
           sprintf(stmt,"SELECT mdamage_cover FROM %s:ori_ins_type \
                           WHERE ipolicy = '%s' AND iins_type = '33'", 
                           DBnameFull, ipolicy );
            $PREPARE cur_o1_out FROM $stmt;
            $EXECUTE cur_o1_out INTO $mdamage_cover;

            printf("===> iins_type[%s]\n", iins_type);            
            /** 1.iproduct **/
            $SELECT iproduct INTO $iproduct
               FROM cm_product_code
              WHERE iins_class = 'C'
                AND iins_type = '33'
                AND icode1 = '1';
            
            /**13.id**/
            if( isalpha(iassured[0]) == 0 )
            {
            	strcpy(idno, iassured);
            	strcpy(id, "1");
            }
	    else
	    { 
	        id[0] = '9';
	        strcpy(idno, "0000000000");
	    }

            /**14.sex**/
            if (strlen(rtrim(fsex)) == 0)
                sex[0] = '0';
            else
            {
                strcpy(sex, fsex);
                sex[1]='\0';
            }
            printf("id[%s] idno[%s] fsex[%s]\n", id, idno, sex );
            /**15.dbirth**/
            if (strlen(rtrim(ibirth)) == 0)
            {        
	        strcpy(dbirth, "00000000");
	    }
	    else
	    {
	        cm_split_ymd(ibirth,ibirth_yy,ibirth_mm,tmp_dd);

                if (strlen(rtrim(ibirth_yy)) == 0)
                {
                    strcpy(birth, "00000000");
                }
                else
                {
            	    strcpy(birth,itoa(1911+(atoi(ibirth_yy))));
            	    strcat(birth,ibirth_mm);
            	    strcat(birth,tmp_dd);
                }
            }
            printf("birth[%s]\n", birth); 
            /** nreason **/
            sprintf(stmt,"SELECT pacc_reason, iins_item FROM %s:app_pa_type \
                           WHERE iclaim = '%s' AND pa_ins = '47'", 
                           DBnameFull, iclaim );
            $PREPARE cur_c2x FROM $stmt;
            $EXECUTE cur_c2x INTO $nreason, $iins_item;
            
            /** txcd **/
            if(strcmp(fstl,"1") == 0)
               strcpy( txcd ,"1");
            else
               strcpy( txcd ,"4");
           
            printf("txcd[%s]\n", txcd );
            /** fdecide **/
           
            if( iins_item[0] == 'A' )
            {
                strcpy( item1, "2100");
                strcpy( item2, "21");
                strcpy( item3, "0001");
            }
            else if( iins_item[0] == 'B' )
            {
                strcpy( item1, "0102");
                strcpy( item2, "02");
                strcpy( item3, "0102");
            }
            else
            {
            	strcpy( item1, "0102");
            	strcpy( item2, "03");
            	strcpy( item3, "0102");
            }
            
            printf("fdecide[%s] \n");

            rfmtlong(mins_app,"&&&&&&&&&&&&&",s_mins_app);
            s_mins_app[13]='\0';
            rfmtlong(mproc_app,"&&&&&&&&",s_mproc_app);
            s_mproc_app[10]='\0';
            rfmtlong(mdamage_cover,"&&&&&&&&&&&&&",s_mdamage_cover);
            s_mdamage_cover[13]='\0';
 
            printf(" ********************** before insert ******************* \n");
            /**
            $INSERT INTO ot_app_stl_998
                 VALUES('2',$iproduct, '2', '0', $iclaimcd, $iclaim_into,
                        $iclaim_sno_into, $plycd, $ipolicy_into,
                        $daccident_into, '00000000', '00000000',
                        $plybegin, '00000000', '0', '0000000000', '0', '00000000',
                        $nreason, $txcd, $fdecide, '0000',
                        '+',$s_mins_app, '+', $s_mproc_app, '00','0000',
                        '0',$transferdate,'0000000000000','11');
            **/
            $INSERT INTO ot_app_stl_998
                 VALUES('1',$iproduct, '2', $flagPG, $iclaimcd, $iclaim_into,
                        $iclaim_sno_into, $plycd, $ipolicy_into,
                        $daccident_into, $dclaim_into, $dgroup_into,
                        $plybegin, $plyend, $id, $idno, $sex, $dbirth,
                        $nreason, $txcd, $fdecide, $item1,
                        '+',$s_mins_stl, '+', $s_mins_proc, $item2, $item3,
                        '1',$transferdate,$s_mdamage_cover,'11');
            
            printf("===oth998_accumu_car_out insert compelete====\n");            
        }
  
           
    }      /* end of �w�� */
    $CLOSE cur_co1_out;
    $FREE  cur_co1_out;
    
  $select count(*)
   into $test_count
  from  ot_app_stl_998;
  
printf(" test_count[%d]\n",test_count);
    
    printf(" ======== ���I�z�ߥ��M END ======= \n");
    
    return M_CM_OK;
errexit:
   sqlfatal();
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;

}

/* *************************************************** */
char *get_dtl_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}
/*---------------------------------------------------------end program*/
