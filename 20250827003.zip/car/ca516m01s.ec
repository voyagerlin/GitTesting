/************************************************/
/*   PROGRAM : ca516m01s.ec                     */
/*             �l�v�@�~                         */
/*   DATE    : 03/26/1997                       */
/*   AUTHOR  : Johnny Kuo                       */
/*                                              */
/************************************************/
     
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cm_common.h"
#include "is_def.h"
$include sqlca;
$static char  Piclaim[CLAIM_NUM];


$int    ItemRow , TotColumn;
$int    StartRow , TitleRow;
$int    PgLine , Width;
$char   FormTp[3];
$char   BodyFile[N_FILE+1], TitleFile[N_FILE+1];
$char   tmpBody[N_TFILE+1], tmpTitle[N_TFILE+1];
$char   tmpOutFile[N_TFILE+1];
$extern char outputf[N_FILE+1];
$char   OutFile[20];
$static int  Totline=0;
$static int  max_count=0,errCode=M_CM_OK;
$static int miy=0;
char   DBName[5];
int    tmp_len;
DBinfo  *list;
int   count_db, i;

int IsNull(s)

char *s;
{
  return ((s[0]=='\0')?1:0);
}

long car516(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    long car516_update();
    long car516_query();
    long car516_query_server_name();
    long car516_query_ibranch_name();
    long car516_mquery();
    long car516_get_db();
	long car516_outsourcing();
    long rtncode;
    char option;

    cm_buf_init(command);
    cm_buf_get("%c",&option);

    switch(option) {
      case 'S' : rtncode = car516_squery(reply);
                   break;
      case 'Q' : rtncode = car516_query(reply);
                   break;
      case 'M' : rtncode = car516_mquery(reply);
                   break;
      case 'U' : rtncode = car516_update(reply);
                   break;
      case 'A' : rtncode = car516_insert(reply);
                   break;
      case 'D' : rtncode = car516_drecov(reply);
                   break;
      case 'R' : rtncode = car516_ricom_info(reply);
                   break;
      case 'P' : rtncode = car516_print_form(reply,command,com_len);
                   break;
	  case 'O' : rtncode = car516_outsourcing(reply);
				   break;
      default  : if (exitsub(reply, M_CM_WRONG_OPTION)==True)
                     return M_CM_WRONG_OPTION;
                 return apiRC;
    }
    return(rtncode);
}

long car516_squery(reply)
serverReply reply;
{
     $char DBName[5], D_dbsite[5];
     $char LHsBuffer[1024], sFullName[20];

     $char iclaim[CLAIM_NUM],ipolicy[POLICY_NUM_1], icard[CARD_NUM];
     $char iacc_reason[3], fpart[2], frecov[2], LHcFsal[2], LHcFrecover[2];
     $char LHcFsale[2], LHsLawgiver[11], LHsSalesman[11], LHcFpart[2];
     $char cdrecov[11], LHsIpolicy[21], LHsIcard[11];
     $char LHsIacc_Reason[3], LsDclose[11];
     $int  msettle, mrec_done, mfee_done, mrecov, mfee, LHiMsal_Done;
     $int  LHiMsettle, LHiMrec_Done, LiMsettle, LHiMmrecov, LHiMmsal_done;
     $long LHlDclose, edrecov;
     $char adjustment[11];
     $char fadjuster[2],fadjuster1[2];
     $char userid[11];
     
     $char stmt[1024];
     $char nassured[121], LHfrecov[2], LHfrecover[2];
     $char falldb[2];

     int LHiBufLen;
     long MsgCode;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s",userid);
     cm_buf_get("%s",iclaim);

     $WHENEVER SQLERROR GOTO errexit;
 
     if (db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;


     $SELECT a.ipolicy , a.ibranch_in ,a.adjustment,b.fadjuster
        INTO $ipolicy, $D_dbsite ,$adjustment,$fadjuster
        FROM ca_clm_process a,officer b
       WHERE a.iclaim = $iclaim
         AND a.adjustment = b.iofficer;
        
     if (SQLCODE == SQLNOTFOUND)
     {
         if(exitsub(reply,M_CM_NOT_FOUND) == True)
             return M_CM_NOT_FOUND;
         else
             return apiRC;
     }

     D_dbsite[2]='\0';
     strcpy(sFullName, get_full_dbname(D_dbsite));

     $WHENEVER SQLERROR GOTO errexit;
     
     $select falldb
        into $falldb
        from privilege
       where iemp = $userid
         and ipgid = 'car516';

	 $select fadjuster 
		 into $fadjuster1 
		 from officer
		 where iofficer = $userid;
     
     
     if (SQLCODE == SQLNOTFOUND)
     {
         strcpy(falldb,"n");
     }    
     
     

     sprintf(LHsBuffer, "SELECT ipolicy, icard, fpart, iacc_reason, fsale, frecover \
                     FROM %s:appraisal \
                     WHERE iclaim = ?", sFullName);

     $PREPARE appraisal_pre FROM $LHsBuffer;
     $DECLARE appraisal_cur CURSOR FOR appraisal_pre;
     $OPEN appraisal_cur USING $iclaim;
     $FETCH appraisal_cur INTO $LHsIpolicy, $LHsIcard, $LHcFpart, $LHsIacc_Reason, $LHcFsale,
                               $LHfrecover;

     if (SQLCODE == SQLNOTFOUND)
     {
         if(exitsub(reply,M_CM_NOT_FOUND) == True)
             return M_CM_NOT_FOUND;
         else
             return apiRC;
     }

     $CLOSE appraisal_cur;
     $FREE appraisal_cur;

     memset(LHsBuffer, 0x00, sizeof(LHsBuffer));

 
   sprintf(stmt,
    " SELECT nassured            \
        FROM %s:adjustment_ply   \
       WHERE iclaim = ? ",get_full_dbname(D_dbsite));
    $PREPARE sid00 FROM $stmt;
    $EXECUTE sid00 INTO $nassured USING $iclaim;
 
     if (SQLCODE == SQLNOTFOUND) strcpy(nassured," ");   


    sprintf(stmt,
     " SELECT NVL(sum(msettle),0)    \
         FROM %s:settlement   \
        WHERE iclaim = ?      \
          AND fstl = '1' ",get_full_dbname(D_dbsite));
     $PREPARE sid01 FROM $stmt;
     $EXECUTE sid01 INTO $LiMsettle USING $iclaim;

printf("LiMsettle[%d]",LiMsettle);

     if (SQLCODE == SQLNOTFOUND)
     {
         if(exitsub(reply,M_CM_NOT_FOUND) == True)
             return M_CM_NOT_FOUND;
         else
             return apiRC;
     }

     printf("LHfrecover[%s]\n",LHfrecover);

     if( strcmp( LHfrecover,"0" ) == 0)
     {
         strcpy( LHfrecov , "0" );
     }
     else if( strcmp( LHfrecover , "2") == 0 )
     {
         strcpy( LHfrecov , "3" );
     }
     else strcpy( LHfrecov, "1" );

     printf("LHfrecov[%s]\n",LHfrecov);

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);

     cm_buf_put("%s %s %s %s %s %d %d %d %s %s %s %s %s ",
                 LHsIpolicy, LHsIcard, LsDclose, LHsIacc_Reason, LHcFpart,
                 0, 0, LiMsettle, nassured ,adjustment,fadjuster,fadjuster1,falldb );
     cm_buf_put("%s %s ",LHfrecover, LHfrecov );

     LHiBufLen = cm_buf_len(ReplyBuf);

     if(SendSyncReply(reply,ReplyBuf,LHiBufLen,api_OKComplete) == False)
     {
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     return api_OKComplete;

     errexit:
        printf(" sqlerrm = %s\n",sqlca.sqlerrm);
        $WHENEVER SQLERROR CONTINUE;
        MsgCode = SQLCODE;
        if (SQLCODE != 0) MsgCode = SQLCODE;
        return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}



long car516_query(reply)
serverReply reply;
{
     $char DBName[5], D_dbsite[5];
     $char LsBuffer[1024], sFullName[20];
     $char userid[11];
     $char iclaim[CLAIM_NUM],ipolicy[POLICY_NUM_1], icard[CARD_NUM];
     $char iacc_reason[3], fpart[2], frecov[2], LHcFsal[2], LHcFrecover[2];
     $char LHcFsale[2], LHsLawgiver[11], LHsSalesman[11];
     $char cdclose[11], LHcFrecov[2];
     $int  msettle, mrec_done, mfee_done, mrecov, mfee, LHiMsal_Done;
     $int  LHiMmrecov, LHiMmsal_done, really_recovery;
     $long edclose,edrecov;
     $char freprocess[2];
     $char stmt[1024],nassured[121],iarrive_no[11];
     $char recov_man[2],recov_comp[7],compancy_name[10];
     $char recov_branch[21], recov_claim[16], recov_officer[11];
     $char recov_tel[16], recov_process[11], frecov_out[2];
     $char ioth_nassured[41],driver_nassured[41];
     $char fadjuster[2],fadjuster1[2],falldb[2];

     int LiBufLen;
     long MsgCode;

     cm_buf_get("%s",DBName);
     cm_buf_get("%s",userid);
     cm_buf_get("%s",iclaim);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     $SELECT ipolicy , ibranch_in
        INTO $ipolicy, $D_dbsite
        FROM ca_clm_process
       WHERE iclaim = $iclaim;
printf(" ipolicy[%s]\n",ipolicy);
     if (SQLCODE == SQLNOTFOUND)
     {
         if(exitsub(reply,M_CM_NOT_FOUND) == True)
             return M_CM_NOT_FOUND;
         else
             return apiRC;
     }

     D_dbsite[2]='\0';
     strcpy(sFullName, get_full_dbname(D_dbsite));
     printf ("dbname[%s]\n",D_dbsite);
     printf("[ca516]:dbname=%s\n",sFullName);
     printf("[ca516]:iclaim=%s,ipolicy=%s \n",iclaim,ipolicy);

     LHiMsal_Done = 0;

     sprintf(LsBuffer, "SELECT iclaim, ipolicy, iacc_reason, msettle, \
                            mrecov, frecov, dclose, icard, fpart, \
                            mrec_done, mfee_done, mfee, drecov, \
                            frecover, fsal, fsale, msal_done, \
                            lawgiver, salesman, mmrecov, really_recovery, mmsal_done, \
                            freprocess, iarrive_no, recov_man, recov_comp, \
                            recov_branch, recov_claim, recov_officer, \
                            recov_tel, recov_process, frecov_out \
                     FROM %s:recovery \
                     WHERE iclaim = ? AND ipolicy= ?", sFullName);

     $PREPARE p1_1 FROM $LsBuffer;
     $DECLARE p1_cursor CURSOR FOR p1_1;
     $OPEN p1_cursor USING $iclaim, $ipolicy;
     $FETCH p1_cursor INTO $iclaim, $ipolicy, $iacc_reason, $msettle,
                           $mrecov, $LHcFrecov, $edclose, $icard, $fpart,
                           $mrec_done, $mfee_done, $mfee, $edrecov,
                           $LHcFrecover, $LHcFsal, $LHcFsale, $LHiMsal_Done,
                           $LHsLawgiver, $LHsSalesman, $LHiMmrecov, $really_recovery, $LHiMmsal_done ,
                           $freprocess ,$iarrive_no, $recov_man, $recov_comp,
                           $recov_branch,$recov_claim,$recov_officer,$recov_tel,
                           $recov_process,$frecov_out;

     if (SQLCODE == SQLNOTFOUND)
     {
         $CLOSE p1_cursor;
         $FREE p1_cursor;
         if(exitsub(reply,M_CM_NOT_FOUND) == True)
             return M_CM_NOT_FOUND;
         else
             return apiRC;

     }
     $CLOSE p1_cursor;
     $FREE p1_cursor;

     printf("frecov_out[%s]\n",frecov_out);
     
     $select fadjuster
        into $fadjuster
        from officer
       where iofficer = $LHsLawgiver;

	 $select fadjuster
		 into $fadjuster1
		 from officer
		 where iofficer = $userid;
	 printf("fadjuster1 ==>[%s]\n",fadjuster1);
	 printf("userid ==> [%s]\n",userid);
       
      if (SQLCODE == SQLNOTFOUND)
      {  strcpy(fadjuster," ");  }
      
     $select falldb
        into $falldb
        from privilege
       where iemp = $userid
         and ipgid = 'car516';
    
      if (SQLCODE == SQLNOTFOUND)
      {  strcpy(falldb," ");  }   
     

     sprintf(stmt,
    " SELECT nassured            \
        FROM %s:adjustment_ply   \
       WHERE iclaim = ? ",get_full_dbname(D_dbsite));
    $PREPARE sid03 FROM $stmt;
    $EXECUTE sid03 INTO $nassured USING $iclaim;

     if (SQLCODE == SQLNOTFOUND) strcpy(nassured," ");
     
      sprintf(stmt,
    " SELECT max(ioth_nassured),max(driver_nassured)     \
        FROM %s:settlement   \
       WHERE iclaim = ? ",get_full_dbname(D_dbsite));
    $PREPARE sid03 FROM $stmt;
    $EXECUTE sid03 INTO $ioth_nassured,$driver_nassured USING $iclaim;

     if (SQLCODE == SQLNOTFOUND)
     {
     	 strcpy(ioth_nassured," ");
     	 strcpy(driver_nassured," ");
     }
     strcpy (cdclose,cm_cdate_str_100(edclose));
     
     $SELECT nrin_abbre 
        INTO $compancy_name
        FROM ri_ricom_info
       WHERE frin_attr = '2'
         AND irin_com = $recov_comp;
     
     if( SQLCODE == SQLNOTFOUND ) 
         strcpy(compancy_name," ");

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);

/****   if msal_done is null then LHiMsal_Done -2147483648      ****/

     if(LHiMsal_Done <0)
     {
        LHiMsal_Done = 0;
     }

     cm_buf_put("%s %s %s %s %s %s %s %s %s %s %d %d %s %s %d %s %d %s %s %d %d %s %s %s %s %s %s ",
                 iclaim, ipolicy, icard, cdclose, iacc_reason, fpart,
                 LHsLawgiver, fadjuster, fadjuster1 ,falldb, LHiMmrecov, really_recovery,LHcFrecov, LHcFrecover, mrecov,
                 LHsSalesman, LHiMmsal_done, LHcFsale, LHcFsal, LHiMsal_Done, 
                 msettle, freprocess, nassured, iarrive_no, recov_man,
                 recov_comp, compancy_name);

     cm_buf_put("%s %s %s %s %s %s %s %s ", recov_branch, recov_claim, recov_officer,
                          recov_tel, recov_process,frecov_out,ioth_nassured,driver_nassured);

     printf("freprocess[%s]\n",freprocess);
     LiBufLen = cm_buf_len(ReplyBuf);

     if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
     {
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     return api_OKComplete;

     errexit:
        printf(" sqlerrm = %s\n",sqlca.sqlerrm);
        $WHENEVER SQLERROR CONTINUE;
        MsgCode = SQLCODE;
        if (SQLCODE != 0) MsgCode = SQLCODE;
        return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

long car516_insert(reply)
serverReply reply;
{
     $char DBName[5],DBName1[5];
     $char LsBuffer[1024], sFullName[20];

     $char iclaim[CLAIM_NUM], ipolicy[POLICY_NUM_1],LHsLawgiver[11];
     $char LHcFrecov[2], LHsSalesman[11], LHcFsale[2], icard[CARD_NUM];
     $char LHcFrecover[2], LHcFsal[2], iacc_reason[3];
     $char fpart[2], LHsDclose[11], LsDclose[11], LHsMsettle[10];
     $char LHsMmrecov[10], LHsMmsal_done[10];
     $char freprocess[2],iarrive_no[11];
     $char recov_man[2],recov_comp[8];
     $char recov_branch[21], recov_claim[16], recov_officer[11];
     $char recov_tel[16], recov_process[11],  frecov_out[2];
     $char to_day[11];
     $char re_state[2];
     $char ioth_nassured[41],driver_nassured[41];
     $char userID[11];

     $int  mrec_done, LHiMsal_Done, LiMsettle, LHiMmrecov, really_recovery, LHiMmsal_done;

     int LiBufLen;
     long MsgCode;

     cm_buf_get("%s",DBName);

     cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
                 iclaim, ipolicy, icard, iacc_reason, fpart,
                 LHsLawgiver, LHsMmrecov, LHcFrecov, LHcFrecover, LHsSalesman,
                 LHsMmsal_done, LHcFsale, LHcFsal, LHsMsettle, freprocess, 
                 iarrive_no, recov_man, recov_comp);

     cm_buf_get("%s %s %s %s %s %s %s %s %s", recov_branch, recov_claim, recov_officer,
                          recov_tel, recov_process,frecov_out,ioth_nassured,driver_nassured, userID);

     LiMsettle = atoi(LHsMsettle);
     LHiMmrecov = atoi(LHsMmrecov);
     LHiMmsal_done = atoi(LHsMmsal_done);

     strcpy (LHsDclose, cm_to_infdate(LsDclose));

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     /*** ���O����ݸ�Ʈw ***/
     strcpy(sFullName, get_car_full_db(ipolicy));

     $BEGIN WORK;
     $WHENEVER SQLERROR GOTO errexit;

     $SELECT re_state
        INTO $re_state
        FROM ca_clm_process
       WHERE iclaim = $iclaim;

     printf("YA! re_state[%s]\n",re_state );

     if (LHcFrecov[0] == '2')
         strcpy(to_day,  cm_edate_str(cm_today()));
     else 
         strcpy(to_day," ");

     printf("to_day[%s]\n",to_day);
     sprintf(LsBuffer,"INSERT INTO %s:recovery \
         (iclaim, ipolicy, icard, iacc_reason, fpart, lawgiver, mmrecov, frecov,   \
          frecover, salesman, mmsal_done, fsale, fsal, msettle, freprocess, \
          drecov,iarrive_no,recov_man,recov_comp, recov_branch, recov_claim, \
          recov_officer,recov_tel,recov_process,frecov_out,ientry,iupdate,iexec_type,frecov_out2,dentry,dupdate ) VALUES   \
          (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'0','',current,current)" ,sFullName);
   
    printf("LsBuffer[%s]\n",LsBuffer);

     $PREPARE a_id FROM $LsBuffer;
     $EXECUTE a_id USING $iclaim, $ipolicy, $icard, $iacc_reason, $fpart, $LHsLawgiver, 
                         $LHiMmrecov, $LHcFrecov, $LHcFrecover, $LHsSalesman, $LHiMmsal_done, 
                         $LHcFsale, $LHcFsal, $LiMsettle,$freprocess,$to_day,
                         $iarrive_no, $recov_man, $recov_comp, $recov_branch, $recov_claim,
                         $recov_officer, $recov_tel, $recov_process,$frecov_out,$userID,$userID;

     if( strcmp(re_state,"N") == 0 )
     {
         printf(">_<bb freprocess[%s] recov_man[%s]\n",freprocess, recov_man);
         if( (strcmp(trim(freprocess),"") != 0) && (strcmp(trim(recov_man),"") != 0) )
         {
            $UPDATE ca_clm_process
                SET re_state = 'Y'
              WHERE iclaim = $iclaim;
         }
     }
     

     sprintf (LsBuffer ,"UPDATE %s:settlement \
                        SET ( ioth_nassured,driver_nassured ) \
                          = ( ?,? ) \
                      WHERE iclaim  ='%s' \
                        AND ipolicy ='%s'",sFullName ,iclaim,ipolicy);

      $PREPARE p1_211 FROM $LsBuffer;
      $EXECUTE p1_211 USING $ioth_nassured,$driver_nassured;
                            
      $FREE p1_211;

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     LiBufLen = cm_buf_len(ReplyBuf);

     if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
     {
       $WHENEVER SQLERROR CONTINUE;
       $ROLLBACK WORK;
       return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     $COMMIT WORK;
     return api_OKComplete;

     errexit:
         printf(" sqlerrm = %s\n",sqlca.sqlerrm);
         $WHENEVER SQLERROR CONTINUE;
         MsgCode = SQLCODE;
         $ROLLBACK WORK;
         if (SQLCODE != 0) MsgCode = SQLCODE;
         return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

long car516_update(reply)
serverReply reply;
{
     $char DBName[5],DBName1[5];
     $char LsBuffer[1024], sFullName[20];

     $char iclaim[CLAIM_NUM], ipolicy[POLICY_NUM_1],LHsLawgiver[11];
     $char LHcFrecov[2], LHsSalesman[11], LHcFsale[2], icard[CARD_NUM];
     $char LHcFrecover[2], LHcFsal[2], iacc_reason[3];
     $char fpart[2], LHsMmrecov[10], LHsMmsal_done[10];

     $int  mrec_done, LHiMsal_Done, msettle, LHiMmrecov, really_recovery, LHiMmsal_done;
     $char freprocess[2],iarrive_no[11];
     $char to_day[11],recov_man[2],recov_comp[7];
     $char recov_branch[21], recov_claim[16], recov_officer[11];
     $char recov_tel[16], recov_process[11], frecov_out[2];
     $char old_process[2],dprocess[11],stmt[80],re_state[2];
     $char ioth_nassured[41],driver_nassured[41];
     $char fadjuster[2],falldb[2];
     int LiBufLen;
     long MsgCode;

     cm_buf_get("%s",DBName);

     cm_buf_get("%s %s %s %s %l %s %s %s %s %s %s %s %s %s %s",
                 iclaim, ipolicy, LHsLawgiver, LHsMmrecov, &really_recovery, LHcFrecov,
                 LHcFrecover, LHsSalesman, LHsMmsal_done, LHcFsal, 
                 LHcFsale, freprocess, iarrive_no, recov_man, recov_comp);

     cm_buf_get("%s %s %s %s %s %s %s %s ", recov_branch, recov_claim, recov_officer,
                          recov_tel, recov_process,frecov_out,ioth_nassured,driver_nassured );

     printf("frecov[%s] \n",frecov_out);

     LHiMmrecov = atoi(LHsMmrecov);
     LHiMmsal_done = atoi(LHsMmsal_done);
     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     /*** ���O����ݸ�Ʈw ***/
     strcpy(sFullName, get_car_full_db(ipolicy));

     $BEGIN WORK;
     $WHENEVER SQLERROR GOTO errexit;

     $SELECT re_state
        INTO $re_state
        FROM ca_clm_process
       WHERE iclaim = $iclaim;


      if (LHcFrecov[0] == '2')
          strcpy(to_day, cm_edate_str(cm_today()));
      else
          strcpy(to_day," ");     

     sprintf(stmt,"SELECT freprocess FROM %s:recovery WHERE iclaim=?",sFullName);
     $PREPARE c_idx FROM $stmt;
     $EXECUTE c_idx INTO $old_process USING $iclaim;
     if( SQLCODE == SQLNOTFOUND ) strcpy(old_process," ");

     /*** ���k�ȤH��, �l�v���A, �l�v�O, ���H��, ��檬�A, ���O   ***/

     printf("old_process[%s] freprocess[%s]\n",old_process, freprocess );

     if (strncmp(old_process,freprocess,1) != 0)
     {
        strcpy(dprocess,cm_edate_str(cm_today()));
        printf("in the same dtoday[%s]\n",cm_edate_str(cm_today));
     }
     else
     {
        sprintf(stmt,"SELECT dprocess FROM %s:recovery WHERE iclaim = '%s'",
                      sFullName, iclaim );
        $PREPARE curA FROM $stmt;
        $EXECUTE curA INTO $dprocess;
        if( SQLCODE == SQLNOTFOUND ) strcpy(dprocess," ");
     }

     printf("dprocess[%s] \n",dprocess );
     sprintf (LsBuffer ,"UPDATE %s:recovery \
                        SET ( lawgiver,mmrecov,frecov,frecover,salesman,mmsal_done, \
                              fsale,fsal,freprocess,iarrive_no,recov_man,recov_comp, \
                              dprocess,recov_branch,recov_claim,recov_officer, \
                              recov_tel,recov_process,frecov_out,really_recovery ) \
                        = ( ?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,? ) \
                      WHERE iclaim  ='%s' \
                        AND ipolicy ='%s'",sFullName ,iclaim,ipolicy);

      $PREPARE p1_21 FROM $LsBuffer;
      $EXECUTE p1_21 USING $LHsLawgiver, $LHiMmrecov, $LHcFrecov, $LHcFrecover, $LHsSalesman,
                           $LHiMmsal_done, $LHcFsale, $LHcFsal, $freprocess, $iarrive_no,
                           $recov_man ,  $recov_comp, $dprocess,  $recov_branch,$recov_claim,
                           $recov_officer,$recov_tel, $recov_process,$frecov_out,$really_recovery;
      $FREE p1_21;

  printf("530  LsBuffer=[%s] \n",LsBuffer);

      sprintf(LsBuffer ,
        " UPDATE %s:recovery    \
             SET drecov = ?     \
           WHERE iclaim = '%s'  \
             AND ipolicy = '%s' \
             AND drecov IS NULL ",sFullName,iclaim,ipolicy ) ;
      $PREPARE cida FROM $LsBuffer;
      $EXECUTE cida USING $to_day;

     if( strcmp(re_state,"N") == 0 )
     {
         printf(">_<bb freprocess[%s] recov_man[%s]\n",freprocess, recov_man);
         if( (strcmp(trim(freprocess),"") != 0) && (strcmp(trim(recov_man),"") != 0) )
         {
            $UPDATE ca_clm_process
                SET re_state = 'Y'
              WHERE iclaim = $iclaim;
         }
     }
     
      sprintf (LsBuffer ,"UPDATE %s:settlement \
                        SET ( ioth_nassured,driver_nassured ) \
                          = ( ?,? ) \
                      WHERE iclaim  ='%s' \
                        AND ipolicy ='%s'",sFullName ,iclaim,ipolicy);

      $PREPARE p1_2111 FROM $LsBuffer;
      $EXECUTE p1_2111 USING $ioth_nassured,$driver_nassured;
                            
      $FREE p1_2111;


     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     LiBufLen = cm_buf_len(ReplyBuf);
     if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
     {
       $WHENEVER SQLERROR CONTINUE;
       $ROLLBACK WORK;
       return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     $COMMIT WORK;
     return api_OKComplete;

     errexit:
         printf(" sqlerrm = %s\n",sqlca.sqlerrm);
         $WHENEVER SQLERROR CONTINUE;
         MsgCode = SQLCODE;
         $ROLLBACK WORK;
         if (SQLCODE != 0) MsgCode = SQLCODE;
         return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

long car516_drecov(reply)
serverReply reply;
{
     $char DBName[5],DBName1[5];
     $char LsBuffer[1024], sFullName[20];

     $char iclaim[CLAIM_NUM], ipolicy[21];
     $char drecov[11], drecov1[11];

     int LiBufLen;
     long MsgCode;

     cm_buf_get("%s",DBName);

     cm_buf_get("%s %s %s",iclaim, ipolicy, drecov);

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     /*** ���O����ݸ�Ʈw ***/
     
     strcpy(sFullName, get_car_full_db(ipolicy));

     $BEGIN WORK;
     $WHENEVER SQLERROR GOTO errexit;

      strcpy( drecov1, cm_to_infdate(drecov));    


     /*** ���l�v���   ***/

     sprintf (LsBuffer ,"UPDATE %s:recovery SET ( drecov ) = ( ? ) \
                      WHERE iclaim  ='%s' ",sFullName ,iclaim );
     
     printf("LsBuffer[%s] drecov1[%s]\n",LsBuffer, drecov1 );
     
     $PREPARE p1_21 FROM $LsBuffer;
     $EXECUTE p1_21 USING $drecov1;
     $FREE p1_21;

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     LiBufLen = cm_buf_len(ReplyBuf);
     if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
     {
       $WHENEVER SQLERROR CONTINUE;
       $ROLLBACK WORK;
       return apiRC;
     }

     $WHENEVER SQLERROR GOTO errexit;
     $COMMIT WORK;
     return api_OKComplete;

     errexit:
         printf(" sqlerrm = %s\n",sqlca.sqlerrm);
         $WHENEVER SQLERROR CONTINUE;
         MsgCode = SQLCODE;
         $ROLLBACK WORK;
         if (SQLCODE != 0) MsgCode = SQLCODE;
         return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

long car516_ricom_info( reply )
{
  
  $char irin_com[7] , nrin_abbre[11];
  $char DBName[5];
  
  int LiBufLen, count;
  long MsgCode;
   
   count = 0;
   
   cm_buf_get("%s",DBName);

   $WHENEVER SQLERROR GOTO errexit;

   if (db_select(DBName) == False)
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

   cm_buf_init(ReplyBuf);
   cm_buf_res_msg();
   cm_buf_res_count();

   $DECLARE CURRIN CURSOR for
     SELECT irin_com , nrin_abbre
       FROM ri_ricom_info
      WHERE frin_attr = '2'
      ORDER BY irin_com;
      
   $OPEN CURRIN;
   while(1)
   {
        
      $FETCH CURRIN INTO $irin_com, $nrin_abbre;        
       
      if ( SQLCODE == SQLNOTFOUND ) break;
      
      cm_buf_put("%s %s ",irin_com, nrin_abbre );
      count++;

   }
   
   if ( count == 0 )
   {
       return M_CM_NOT_FOUND;
   }   
   
   cm_buf_put_msg( M_CM_OK);
   cm_buf_put_count_seq(1, count);

   LiBufLen = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
   {   
       return apiRC;
   }
   return api_OKComplete;

   errexit:
   printf(" sqlerrm = %s\n",sqlca.sqlerrm);
   $WHENEVER SQLERROR CONTINUE;
      MsgCode = SQLCODE;
   if (SQLCODE != 0) MsgCode = SQLCODE;
   return exitsub(reply,MsgCode) ? MsgCode : apiRC;
  
}
long car516_print_form(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
int res;
char aphome[40];
$char hostname[N_NAME+1];

         cm_buf_get("%s",DBName);
         if (db_select(DBName) == False)
            return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
         $SET LOCK MODE TO  WAIT 110;

         res = getApHome(aphome);
         if (res<0)
         {
             printf("In sigalrmcatcher func==>read config file error!!\n");
             return FAIL;
         }

         printf("car516_build_P begin\n");
         errCode= car516_build_P(reply);
         if (errCode != 1) return FAIL;
             printf("car516_build_P OK\n");

         gethostname(hostname,sizeof(hostname));
         sprintf(tmpBody,"%s/reportfile/%s",aphome,OutFile);
         cm_buf_init(ReplyBuf);
         miy=0;
         cm_buf_put("%l %s %s %d",(long)M_CM_OK,hostname,tmpBody,miy);

         tmp_len=cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
             return FAIL;
         else
             return SUCCESS;
}
long car516_build_P(reply)
serverReply reply;
{
  $char  FormFile[N_FILE+1], sFullName[20], stmt[1024];
  int    i;
  int    errCode;
  int    rc;

  memset(sFullName,0,20);
  memset(stmt,0,1024);
  cm_buf_get("%s ",Piclaim);

  $WHENEVER SQLERROR GOTO errexit;
  $SELECT kPgNum_Line, nForm_File, iForm_Tp
     INTO $PgLine, $FormFile, $FormTp
     FROM Form
    WHERE ksys_grp = "CA" AND kPgmID = 516;

  strcpy(FormFile,rtrim(FormFile));
  strcpy(outputf, getFileName());
  sprintf(OutFile,"%s.tx",outputf);

  rgu_init_report(FormFile,OutFile);
  /***********   P R O C E S S   B E G I N   **********/
  miy = 0;
  max_count = 0;
  rc=car516_data_P(reply);
  if (rc != SUCCESS)
        { return exitsub(reply,rc) ? rc : apiRC; }

  /***********   P R O C E S S   E N D   **********/

  rgu_finish_report();

  if (miy == 0)
     return exitsub(reply,M_CM_NOT_FOUND) ? M_CM_NOT_FOUND : apiRC;
  else {
     max_count = miy;
     printf("max_count=%d\n",max_count);
     return api_OKComplete;
  }

errexit:
  printf("sqlcode[%ld] sqlerrm[%s]",SQLCODE,sqlca.sqlerrm);
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;

}

long car516_data_P(reply)
serverReply reply;
{
  $char  stmt[1024];
  char   TpName[20];
  long   MsgCode;
  $char  Ffac[2];
  int    errCode;

  $WHENEVER SQLERROR GOTO errexit;

  if ((errCode=ca_rpt_recovery(Piclaim, &miy)) != SUCCESS)
         return errCode;

  return SUCCESS;

errexit:
  printf("car516_data_P:sqlcode[%ld] sqlerrm[%s]\n",SQLCODE,sqlca.sqlerrm);
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  return MsgCode;
}


long car516_mquery(reply)
serverReply reply;
{
 $char DBName[5], adjustment[8], frecover[2], frecov[2];
 $char sIclaim[20], sAdjustment[10], sLawgiver[10], sFrecov[2], sFrecover[2];
 $char sFreprocess[2], laName[11], adName[11], sRecov_man[2], pIclaim[20];
 $char option[2];
 $long lMmrecov,id1;
  char tmpbuf[4000];
 $char stmt[1024], sWhere1[250], sWhere2[250], tempbuf[11];
 $char ioth_nassured[41],driver_nassured[41];

 int count=0,repbuf_len=0,tmp_len=0,replycnt=0,rc;
 int i,total_count=0;
 long  MsgCode;

 printf("in car516_mquery \n");

 cm_buf_get("%s %s %s %s %s %s %s %s", DBName, option, adjustment, pIclaim, frecover, frecov,ioth_nassured,driver_nassured);


 $WHENEVER SQLERROR GOTO errexit;

  if (db_select(DBName) == False)
  {
    if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
      return M_CM_DB_NOTOPEN;
    else
      return apiRC;
  }

  if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
  {
       if(exitsub(reply,M_CM_NOT_DBLIST) == True)
         return M_CM_NOT_DBLIST;
       else
         return apiRC;
  }

  $CREATE TEMP TABLE CAR516_TMP
  (
     iclaim      char(20),
     adjustment  char(10),
     lawgiver    char(10),
     frecov      char(2),
     frecover    char(2),
     freprocess  char(2),
     recov_man   char(2),
     mmrecov     integer
  )
  WITH NO LOG;

  strcpy( frecover, trim(frecover));
  strcpy( frecov,   trim(frecov));
  strcpy( option,   trim(option));
  strcpy( pIclaim,  trim(pIclaim));

  if(strcmp(frecover,"A") == 0)
    strcpy( sWhere1 , " AND b.frecover in ('1','2')" );
  if(strcmp(frecover,"B") == 0)
    strcpy( sWhere1 , " AND b.frecover in ('4','5')" );
  if(strcmp(frecover,"1") == 0)
    strcpy( sWhere1 , " AND b.frecover = '1'");
  if(strcmp(frecover,"2") == 0)
    strcpy( sWhere1 , " AND b.frecover = '2'");
  if(strcmp(frecover,"3") == 0)
    strcpy( sWhere1 , " AND b.frecover = '3'");
  if(strcmp(frecover,"4") == 0)
    strcpy( sWhere1 , " AND b.frecover = '4'");
  if(strcmp(frecover,"5") == 0)
    strcpy( sWhere1 , " AND b.frecover = '5'");

  if(strcmp(frecov,"1") == 0)
    strcpy( sWhere2 , " AND b.frecov = '1'" );
  if(strcmp(frecov,"2") == 0)
    strcpy( sWhere2 , " AND b.frecov = '2'" );
  if(strcmp(frecov,"3") == 0)
    strcpy( sWhere2 , " AND b.frecov = '3'" );
  if(strcmp(frecov,"A") == 0)
    strcpy( sWhere2 , " AND b.frecov in ('1','2','3')" );

  printf("option[%s] ",option );


  for( i=0 ; i< count_db; i++ )
  {

     if( strcmp(option ,"2") == 0 )
     {
        sprintf(stmt,"SELECT a.iclaim, a.adjustment, b.lawgiver, b.frecov, b.frecover, \
                             b.freprocess, b.mmrecov, b.recov_man \
                        FROM ca_clm_process a, %s:recovery b \
                       WHERE a.iclaim = b.iclaim AND a.adjustment = '%s' \
                         AND a.iclaim matches '%s' %s %s ORDER BY 1 ",
                       list[i].dbname, adjustment, pIclaim, sWhere1, sWhere2 );
     }
     if( strcmp(option ,"3") == 0 )
     {
        sprintf(stmt,"SELECT a.iclaim, a.adjustment, b.lawgiver, b.frecov, b.frecover, \
                             b.freprocess, b.mmrecov, b.recov_man \
                        FROM ca_clm_process a, %s:recovery b \
                       WHERE a.iclaim = b.iclaim AND b.lawgiver = '%s' \
                         AND a.iclaim matches '%s' %s %s ORDER BY 1",
                       list[i].dbname, adjustment, pIclaim, sWhere1, sWhere2 );
     }
     if( strcmp(option ,"4") == 0 )
     {
        sprintf(stmt,"SELECT a.iclaim, a.adjustment, b.lawgiver, b.frecov, b.frecover, \
                             b.freprocess, b.mmrecov, b.recov_man \
                        FROM ca_clm_process a, %s:recovery b \
                       WHERE a.iclaim = b.iclaim AND b.lawgiver = ' ' \
                         AND b.frecover IN ('3','4','5') \
                         AND b.frecov IN ('1','2','3') ORDER BY 1 ", list[i].dbname );
     }
     if( strcmp(option ,"5") == 0 )
     {
        sprintf(stmt,"SELECT distinct a.iclaim, a.adjustment, b.lawgiver, b.frecov, b.frecover, \
                             b.freprocess, b.mmrecov, b.recov_man \
                        FROM ca_clm_process a, %s:recovery b,%s:settlement c \
                       WHERE a.iclaim = b.iclaim     \
                         AND b.iclaim = c.iclaim     \
                         AND c.ioth_nassured = '%s'  \
                         ORDER BY 1 ", list[i].dbname ,list[i].dbname,ioth_nassured);
     }
     if( strcmp(option ,"6") == 0 )
     {
        sprintf(stmt,"SELECT distinct a.iclaim, a.adjustment, b.lawgiver, b.frecov, b.frecover, \
                             b.freprocess, b.mmrecov, b.recov_man \
                        FROM ca_clm_process a, %s:recovery b,%s:settlement c \
                       WHERE a.iclaim = b.iclaim     \
                         AND b.iclaim = c.iclaim     \
                         AND c.driver_nassured = '%s'  \
                         ORDER BY 1 ", list[i].dbname ,list[i].dbname,driver_nassured);
     }

     printf(" stmt[%s]\n",stmt);

     $PREPARE cur_m1 FROM $stmt;
     $DECLARE cur_m2 CURSOR FOR cur_m1;
     $OPEN cur_m2;
     while(1)
     {
        $FETCH cur_m2 INTO $sIclaim, $sAdjustment, $sLawgiver, $sFrecov, $sFrecover,
                           $sFreprocess, $lMmrecov:id1 , $sRecov_man;

       if( SQLCODE == SQLNOTFOUND ) break;

       printf("sIclaim[%s] lMmrecov[%d] id1[%d] \n",sIclaim,lMmrecov, id1 );
       if( id1 == -1 ) lMmrecov = 0;
       $INSERT INTO CAR516_TMP
        VALUES ( $sIclaim, $sAdjustment, $sLawgiver, $sFrecov, $sFrecover,
                 $sFreprocess, $sRecov_man, $lMmrecov );

     }
     $CLOSE cur_m2;
     $FREE  cur_m2;

  }
  /* end for loop */

  printf("after for loop \n");
  $DECLARE cur_m3 CURSOR FOR
    SELECT iclaim, adjustment, lawgiver, frecov, frecover,
           freprocess, mmrecov, recov_man
      INTO $sIclaim, $sAdjustment, $sLawgiver, $sFrecov, $sFrecover,
           $sFreprocess, $lMmrecov:id1, $sRecov_man
      FROM CAR516_TMP;

  $OPEN cur_m3;
  for(;;)
  {
    $FETCH cur_m3;

    if ( id1 == -1 ) lMmrecov = 0;
    if (SQLCODE != 0) break;

    $SELECT nname INTO $adName FROM officer WHERE iofficer = $sAdjustment;
    $SELECT nname INTO $laName FROM officer WHERE iofficer = $sLawgiver;

    strcpy(adName , trim(adName));
    strcpy(laName , trim(laName));

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
    rfmtlong(lMmrecov,"--,---,--&",tempbuf);
    cm_buf_put("%s %s %s %s %s %s %s %s ", sIclaim, adName, laName, tempbuf, 
               sFrecover, sFrecov, sFreprocess, sRecov_man );
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE cur_m3;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;

        if(replycnt > 5) sleep(3);
        else if(replycnt > 3) sleep(2);
        else if(replycnt > 1) sleep(1);

        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();

        rfmtlong(lMmrecov,"--,---,--&",tempbuf);
        cm_buf_put("%s %s %s %l %s %s %s %s ", sIclaim, adName, laName, tempbuf, 
                    sFrecover, sFrecov, sFreprocess, sRecov_man );
        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

 $CLOSE cur_m3;
 $DROP TABLE CAR516_TMP;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
    if(exitsub(reply,M_CM_NOT_FOUND) == True)              /*?*/
      return M_CM_NOT_FOUND;                               /*?*/
    else
      return apiRC;
  }

 errexit:
   MsgCode = cm_show_sql_err("ca516_multiple_query", NULL);
   if(exitsub(reply,MsgCode) == True)
     return SQLCODE;
   else
     return apiRC;
}

long car516_outsourcing(reply)
serverReply reply;
{
	$char icode[11], ncode[41];
	int i,tmp_len;
	$char DBName[5];
	$char stmp[100];

	$WHENEVER SQLERROR GOTO ERREXIT;
	cm_buf_get("%s", DBName);
	if (db_select(DBName) == False)
	{
		if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
			return M_CM_DB_NOTOPEN;
		else
			return apiRC;
	}

	cm_buf_init(ReplyBuf);
	cm_buf_res_msg();
	cm_buf_res_count();

    $DECLARE out_csr CURSOR FOR
      SELECT icode,ncode
            FROM cu_code_data
           WHERE itype = '94' ORDER BY icode;

    $OPEN out_csr;
    for(i=0;;i++)
    {
        $FETCH out_csr INTO $icode, $ncode;
        if (SQLCODE == SQLNOTFOUND) break;

        strcpy(stmp,trim(icode));
		strcat(stmp,".  ");
        strcat(stmp,trim(ncode));

        cm_buf_put("%s", stmp);
    }

    $CLOSE out_csr;
    $FREE  out_csr;

    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(i);

    tmp_len = cm_buf_len(ReplyBuf);

    if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False) return apiRC;

    return M_CM_OK;

ERREXIT:
    return exitsub(reply, SQLCODE) ? SQLCODE : apiRC;
}

