/*----------------------------------------------------------------------------*/
/*   PROGRAM : ca_freeform_policy.ec                                          */
/*   AUTHOR  : STEVECHIANG                                                    */
/*   DATE    : 2023/05/10                                                     */
/*----------------------------------------------------------------------------*/
#include <stdio.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include <malloc.h>
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "print.h"
#include "is_def.h"
#include "carmsgs.h"
#include "commsgs.h"
$include "ply_ins_cover.h";
$include "var_length.h";
#include "car_common.h"
#include "ISvar.h"
#include "safeclib.h"

#define MAX_ROW 60
#define script      "�Ԩ��O����Ӫ�"
#define script1     "�Ԫ���"
#define str_ps      "����G���O�I��ҩӫO�����ȳd���I�A�ȭ��r�p�H���`�Ψ�����ˮɡA�����q�l�t���v�d���C"
#define str_add01   "���������o�ͩӫO�����I�ƬG�A�o�ɦ��̰�15��N�B�����C"
#define str_add11   "���������o�ͩӫO�ѵs�I�ƬG�A�o�ɦ��̰�30��N�B�����C"
#define str_add0111 "���������o�ͨ�����ѵs�I�ƬG�A�o���O�ɦ��̰�15���30��N�B�����C"
                
#define str_ins_30_1   "�W�B�d�����[���ڡЫO�٫��ӫO�d�򤣥]�t�G�ĤT�H�d�����s���v�T�έ�����˳d�����[���ڡC"
#define str_ins_30_2   "�W�B�d�����[���ڡЫO�٫��ӫO�d�򤣥]�t�G�ĤT�H�d�����s���v�T���[���ڡC"
#define str_ins_30_3   "�W�B�d�����[���ڡЫO�٫��ӫO�d�򤣥]�t�G������˳d�����[���ڡC"
#define str_ins_30_11  "�W�B�d�����[���ڡЫO�٫��ӫO�d��]�t�G������˳d�����[���ڡC"
#define str_ins_30_12  "�W�B�d�����[���ڡЫO�٫��ӫO�d��]�t�G�ĤT�H�d�����s���v�T���[���ڡC"
#define str_ins_30_13  "�W�B�d�����[���ڡЫO�٫��ӫO�d��]�t�G�ĤT�H�d�����s���v�T�έ�����˳d�����[���ڡC"
#define str_ins_30_21  "�W�B�d�����[���ڡЫO�٫��ӫO�d��]�t�G�ĤT�H�d�����s���v�T���[���ڦ����]�t������˳d�����[���ڡC"
#define str_ins_30_22  "�W�B�d�����[���ڡЫO�٫��ӫO�d��]�t�G������˳d�����[���ڦ����]�t�ĤT�H�d�����s���v�T���[���ڡC"
#define str_ins_30_4   "�W�B�d�����[���ڡЫO�٫��ӫO�d�򤣥]�t�G������˳d���I�C"

#define str_ins_301_1  "�W�B�d���I���[���ڡа�D���W���ӫO�d�򤣥]�t�G������˳d�����[���ڡC"
#define str_ins_301_11 "�W�B�d���I���[���ڡа�D���W���ӫO�d��]�t�G������˳d�����[���ڡC"
#define str_ins_301_2  "�W�B�d���I���[���ڡа�D���W���ӫO�d�򤣥]�t�G������˳d���I�C"

#define str_ins_302_1  "�ĤT�H�W�B�d���O�I�а�D���W���ӫO�d�򤣥]�t�G������˳d�����[���ڡC"
#define str_ins_302_11 "�ĤT�H�W�B�d���O�I�а�D���W���ӫO�d��]�t�G������˳d�����[���ڡC"
#define str_ins_302_2  "�ĤT�H�W�B�d���O�I�а�D���W���ӫO�d�򤣥]�t�G������˳d���I�C"
#define str_ins_302_21 "�ĤT�H�W�B�d���O�I�а�D���W���ӫO�d��]�t�G������˳d���I�C"

#define str_ins_530_1 "�r�V�Z�W�B�d���I�ӫO�d�򤣥]�t�G�r�V�Z������˳d���I�C"
#define str_ins_530_11 "�r�V�Z�W�B�d���I�ӫO�d��]�t�G�r�V�Z������˳d���I�C"

#define str_ins_55_car_11 "�����I�ӫO�d�򤣧t�˱w"

/* ��ϰϰ� */
#define area_restrict "��p�ϰ�:�O�W,���,����,�����άF���Ϊv�v�ҤΤ��a��"

/* �֭�帹 */
#define approval_1 "96�~6��8��s�w�F�ʮ��W96�r��0191����Ƭd"
#define approval_2 "96�~8��31��̦�F�|���ĺʷ��޲z�e���|95"
#define approval_3 "�~9��1����ޫO�G�r��09502522257���O�ץ�"
/* �t�X�O�v�ۥѤƦL�X�֭�帹 */
/*#define approval_980401_1 "98�~3��31��s�w�F�ʮ��W98�r��015120����Ƭd"*/
/*car9810133�X�֭ק� */
#define approval_980401_1 "99�~11��15��s�w�F�ʮ��W99�r��0655����Ƭd"
#define approval_980401_2 " "
#define approval_980401_3 " "
/* �����~�Ȥw�ɦ��u�f������ */
#define direct_disc_98    "(���O��w�ɦ�������O���O�O�u�f)"

/*** Report Variable ***/
 long           code;
 static  $char  icard[CARD_NUM];
 static  $char  r_icard[CARD_NUM];
 static  $char  nname[11];
 static  $char  ileader[10];
 static  $char  ipolicy[POLICY_NUM_1];
 static  $char  irelative_ply[POLICY_NUM_1];
 static  $char  fcard_class[2];
 static  $char  fprint[2];
 static  $char  ilast_ply[POLICY_NUM_1];
 static  $char  ibig_branch[5];
 static  $char  ibig_office[10];
 static  $char  ibig_sales[11];
 static  $char  ibroker[BROKER];
 static  char   new_ibroker[BROKER];
 static  char   dsc_ibroker[13];
 static  $char  iofficer[11];
 static  $char  iresource[2];
 static  $char  icashier[11];
 static  $long  mdmg_prem=0;
 static  $long  mlia_prem=0;
 static  $double  mpure_prem=0;
 static  $char  dpolicy[11];
 static  $long  dpolicy_long=0;
 static  $char  iexaminer[11];
 static  $char  ientry[11];
 static  $int   mdiscount=0;
 static  $char  iply_area[11];
 static  $char  ps_dtl[101];
 static  $char  ps_60[101];  /* 1120316006_SC5_�L��-���N�I���e�{�s�W���@�������������O�N��05�ή��s�X��t�ηs�W���@�����O */
 static  $char  transno[21];
 static  $char  dendorse[11];
 static  $int   seqno=0;
 static  $char  fassured[2];
 static  $char  nassured[122];
 static  $char  nuser[20];
 static  $char  nbenef[43];
 static  $char  aassured[92];
 static  $char  aassured_cmb[92];
 static  $char  aassured_zip[CA_ZIP];
 static  $char  itel[21];
 static  $char  apayment[92];
 static  $char  apayment_zip[CA_ZIP];
 static  $char  iextra_charge[11];
 static  $char  iroute[21]; /* bis9901141 �q���N�� */
 static  $int   qply_period=0;
 static  $long  dply_begin=0;
 static  $long  dply_end=0;
 static  $long  dentry=0;
 static  $char  ipro_year[5];
 static  $char  ibrand[9];
 static  $char  icar_type[3];
 static  $char  icar_flag[2];
 static  $double   qcylinder;
 static  $char  iengine[CA_ENGINE_NUM];
 static  $char  ibody[CA_BODY_NUM];
 static  $char  itag[CA_TAG_NUM];
 static  $double mcar_price;
 static  $double  qpt;
 static  $char  fpt[2];
 static  $double  psex_age;
 static  $double  psex_age_damage;
 static  $double  plia_acc;
 static  $double  pdmg_acc;
 static  $double  mcommission;
 static  $char  nbrand_abbr[14];
 static  $char  ncar_abbr[14];
 static  $char  fcar_class[2];
 static  $char  ilicense[11];
 static  $char  iassured[11];
 static  $char  fsex[2];
 static  $char  fmarriage[2];
 static  $double  pdmg_factor;
 static  $double  pbrg_factor;
 static  $char  flimit[2];
 static  $int   pdmg_align=0;
 static  $int   pbrg_align=0;
 static  $int   plia_align=0;
 static  $char  nequipment[31];
 static  $char  prn_deduct[20];
 static  $char  str_deduct[18];
 static  $char  tmp_deduct[20];
 static  $char  iins_type[7];
 static  $char  nins_type[50];
 static  $char  main_paid[81];
 static  $int   qcoverage;
 static  $char  cover_print[121];
 static  $char  edomain1[20];
 static  $char  fdeduct[2];
 static  $char  deduct_print[21];
 static  $char  fcomp_24;
 static  $int   injured_cover=0;
 static  $int   death_cover=0;
 static  $int   damage_cover=0;
 static  $int   deduct=0;
 static  $long  ins_premium=0;
 static  $int   qserial=0;
 static  $long  premium1=0;
 static  $long  prem21=0;
 static  $char  nequipment_7h_14[31], nequipment_7h_19[31];
 static  $char  iofficer_7h_14[11], iofficer_7h_19[11];
 static  $int   premium_7h_14=0, premium_7h_19=0;
 static  $int   old_premium_7h_14=0, old_premium_7h_19=0;
 static  $int   mdiscount_7h_14=0, mdiscount_7h_19=0;
 static  $char  nequipment_17[31];
 static  $int   premium_17=0;
 static  $int   old_premium_17=0;
 static  $int   mdiscount_17=0;
 static  $char  nequipment_7h[31];
 static  $char  iofficer_7h[11];
 static  $char  site2[3];
 static  $date r_dbegin,r_dend;
 $char   LHsNname[11];
 $char   npresident[11],tax_area[11];
 $char   ifirm_pid[13],sIlicense[11],sItel[21],sIapplicant[11];
 static  $char   napplicant[121];
 static  char  code1[3],code2[11], code3[3];
 char    s_r_dbegin[14],s_r_dend[14],tmp_str3[10];
 static  $date Today;
 
 static  $char  fsex_appl[2];
 static  $char  fapplicant[2];
 static  $char  iapplicant[13];
 $long  dbirth_appl=0;
 static  $char  iext_policy[21];
 
 static  char  yyext1[4],mmext1[3],ddext1[3];
 static  char  yyext2[4],mmext2[3],ddext2[3];
 static  char  dpoyy[4],dpomm[3],dpodd[3];
 static  char  yy1[4],mm1[3],dd1[3];
 static  char  yy2[4],mm2[3],dd2[3];
 static  char  yy3[4],mm3[3],dd3[3];
 static  char  yy4[4],mm4[3],dd4[3];
 static  char  yy5[4],mm5[3],dd5[3];
 static  char  yy6[4],mm6[3],dd6[3];
 static  char  yy7[4],mm7[4],dd7[4];
 static  char  is_yy[4],is_mm[3],is_dd[3],s_fpt[10];
 static  char  fcar1[3],fcar2[3];
 static  char  s_qcylinder[9],s_qpt[10],s_qcylinder2[9],s_pt[21];
 static  char  by[4],bm[4],bd[4];
 static  char  by_appl[4],bm_appl[4],bd_appl[4];
 static  char  sex1[4],marriage1[5],sex1_appl[4];
 static  char  s_psex_age[16],s_psex_age_damage[16],s_dmg_align[10],s_brg_align[10],s_lia_align[10];
 static  char  s_premium1[20];
 static  char  ply1[6],ply[3],ply2[14],last_ply1[6],last_ply2[14];
 static  $double  pcommission=0,pagent=0;
 static  $char  drate_ym[6];
 static  $char  s_note1[70];  /****** �����O�T�T�� ******/
 static  $char  s_note2[70];
 static  $char  provision[22];
 static  char  CompanyId[3];
 char     sTmp[21];
 int   add_mplace_01_flag=0 , add_mplace_11_flag=0;
$long  qday=0, dissue=0, dbirth=0;
$long  coverage1=0,coverage2=0,coverage3=0;
$char  sCoverage1[20],sCoverage2[20],sCoverage3[20];
 char  flag_29_exist[2],flag_31_exist[2],flag_32_exist[2];
 char  Str29_1[50];
 char  Str29_2[50];
 char  Str29_3[50];
 char  s_note[100];

$long  ins_mdiscount=0,old_premium=0,real_premium=0,real1_premium=0;
$long  tmp_prem=0,other_prem=0,trans_premium=0;
 char  ch_amt1[40],ch_amt2[40],ch_amt3[40],ch_amt4[40],ch_amt5[40];
 char  s_old_premium[40],s_real_premium[200],s1_real_premium[200],s_prem21[60],prem_note[100],prem_note1[40],prem_note2[40];
 char  s0_real_premium[200],s2_real_premium[200];
 char  s_dpolicy[14];
$char  s_lia_acc[30],s_dmg_acc[30],s_unk_acc[30];
 char  bak1[60],bak2[60],bak3[60],bak31[60],bak4[60],bak_chiness[60];
 int   people=0,iins=0,ben_len=0,ben_len_t=0;
 int   ins_14=0, ins_17=0, ins_51=0, ins_19=0, ins_31=0, ins_32=0, ins_11=0, ins_56=0, ins_575960=0, ins_36=0, ins_37=0, ins_150151=0;
 char  reprint[30],buf[20],tmp_reprint[30];
 long  rate = 0;
$char  deduct_30[11];
$char  deduct_301[11];
$char  deduct_302[11];

 long   ins_31_multiple=0;

 char  str_cover1[25],str_cover2[25],str_cover3[25],str_cover4[25];
 char  str_ins_premium[21];
 
$char ply_ext1[6],ply_ext2[15];
$char edr1[6],edr2[15];

/*56�I�سQ�O�I�H�W�U��� */
$char  ninsurant56[31],ninsurant67[31];
$long  dbirth56=0,dbirth67=0;
$char  iins_type56[7],iinsurant56[11],iinsurant67[11],sIinsurant56[11],sIinsurant67[11];
$char  nbeneficiary56[31],nbeneficiary67[31], tmp_nbeneficiary56[31], tmp_nbeneficiary67[31];
$char  relation_bene56[21],relation_bene67[21];
$char  tbenef56[21],abenef56[91];
int    line66, line67, list_cnt = 0;   /* �P�_�W�U�L���_,0�����L��,1���L�� */
/*end of �W�U���(modified by Julia Han in 2008/03/26 */

/* �P�_�O�_�C�L�W�U */
int list_print=0; /* 0���C�L,1�����C�L */

/* �O�v�ۥѤ� */
$char  f980401[2]; /* 1:cm_extra_charge�O�v�ͮĤ�>=980401,�O�v�ۥѤƫ�
                      0:cm_extra_charge�O�v�ͮĤ�< 980401,�O�v�ۥѤƫe */
char flag980401[2];

/* �j�O�檺�פ,�Ψӭp��j�O����ܪ��O�O */
$char ply_end[POLICY_NUM_1];

/* �g��N����I�}�Y��,�ݭn�C�X�g��H������W��(officer.nname) */
$char nname_I[11],nname_N[21];

/*�帹�� ca_terms */
$char viins_type[7],ncontract[21],ncontent1[251],ncontent2[251],ncontent3[251],ca_dpolicy[11];
$char stmt1[2048],stmt2[1024];
$char stmt1_2[1024],stmt2_2[512];
$varchar ncontent_a[302],ncontent_a_1[151],ncontent_a_2[151],ncontent_a_3[151];
$char ncontent_print[4096];
$int  iTmp=0, iTmp2=0, iTmp3=0, iTmp4=0, iTmp5=0, iTmp6=0, iTmp7=0, iTmp8=0, iTmp9=0, iTmp10=0, count=0, itext=0;
$char nbrand_1[20],nbrand_2[20]; /*�t�P�����_��*/
$char edomain_tmp[81],edomain[1024];

/* �I��52,53,55,24 �A�ηs�� -- ����J��˫O�B add by sylvia  */
$char     f52535524[2]; /* 1:�O�v�ͮĤ�>=100/4/15,�A�ηs�� */

/* �q���ĤG���q */
$char sIcomm_obj[11], sIroute_comm[4], sIroute_prop[3], sIcode[2];

char  tmpDrate[6];

int  idbstr=0;

/* ATM����O 101/06/01�_�խ���15��  modify by sylvia (101.05.24) */
$int	iATM_Fee=0;

/* D���ڤH�ƤΦW�U add by sylvia 101.06.21 */
$int iQprovision=0, iCounD=0, ninsD_cnt=0;
$char sProvD[100],sProvD_1[100],sProvD_2[100],sTmpIassured[13],sTmpIassured1[13],sTmpNiassured[31],sTmpDbirth[10],sTmpDbirth1[10],PrintDlist[2];
$char sTmpDbirth_yy[4],sTmpDbirth_mm[3],sTmpDbirth_dd[3];
$char ninsType[100];

/* �O��C�L�h�� add by sylvia 101.10.08 (1010928006_C1)*/
/* Tcount �I�ئ��, Pcount �`����, Pline �C�����, Total_Prem �O�O */  
$int  Tcount=0, Pcount=0, Pline=0, ipage=0;
$long Total_Prem=0;

/* �I��62,63,64 �A�ηs�� -- ����J��˫O�B add by sylvia (1011214002_C1)  */
$char     f626364[2]; /* �O�v�ͮĤ�>=101/12/01,�A�ηs�� */

/* �ӤH�O��Ӹ�(�B�n/����) add by larry 102.11.13 (1020924002_C1)*/
$char sProtectData[2];
$int ply_6075;		/* ����s����6075 */

/* �M�ץ�O��C�L add by larry 102.12.16 (1021122001_C3) */
$char DBName[05]; /* �D�M�ץ�O�椣�i���Ʈw */
$char sIpolicyB_type[2]; /* �D�M�ץ�O�� (sIpolicyB_type = 0) �M�ץ�O�� (sIpolicyB_type = 1) */
                         /* �e�~��O�� (sIpolicyB_type = 2) */
$char Full_DBName[20];

$char sNassured_56_136[15];

/* 86�I�اe�{�ۭt�B (1040525002_C1) */
$char f86[2]; /* �O�v�ͮĤ�>=104/06/08,�A�ηs�� */

/* �e�~�O��(�e�~�C�L,�l�H�覡) add by larry 103.03.11 (1010523004_C2) */
$char fout_print[2],fmail_type[2],outpolicy[16];
$char sRemark[15],dply_close[11],dcreate[24],sDate[8],sDateTime[22];
$int out_ply_50=0, out_ply_47=0, out_ply_147=0;
$char ntel_leader[51];
char stmp_space[2];

/* �C�L�t�ƪ��B (1031014003_C1) */
$double mequipment=0;
$char sMequipment[61];
$char bak1_ply[60];

/* �C�L��� (1040625002_C1) */
$char iquota[7];
$char nbranch[41];

/* �e�~�O��(������l���) (1041102003_C1)*/
$char tablePly[64], tableRelation[64], tableInsType[64], tablePaPly[64],tableAssured[64];
$char sIrouteNote[3],sIrouteNote2[2];
$int  cntIroute=0,cntIroute2=0;

/* �e�~��O�v�N���P�_ */
$int  irate_ym=0,out_ply_dmg=0;

/*150151�I�ح��m���Ȫ��B*/
$char tmp_150151[40];

/* 1050801002_C1_�s�W����~�S�w�γ~�ΩT�w�ϥΤH���[���� */
$int provision_J=0;

/**/
$double punknown_acc=0;
$char   iquery_num_unknown[121];

/*1051128002_C1_�վ㨮�I�e�~�O��L�s�@�~���ڸ��X�����覡*/
$char Ireceipt1_1[11],Ireceipt1_2[11],Ireceipt_2[11];
$int tmp_Ireceipt1_1=0;

/*1060426011_C1_CAR320,CAR322 �ק�30��301�I�ئC�L�n�O�ѳ������r*/
/*�ݨD�l�[�O���r*/
$char iins_type24[7],iins_type55[7];
int flag24=0,flag55=0,flag255=0;
int flag49117=0;
int flag555=0;
/*1060818001_C1_cmn134a-���I*/
int bufa_print = 0,bufa_print2;
$long i_begin=0,i_end=0;

/**/
$char nc1[201] = "",nc2[201] = "",nc3[201] = "",nc4[201] = "";
$char nc5[201] = "",nc6[201] = "",nc7[201] = "",nc8[201] = "";
$char ed1[201] = "",ed2[201] = "",ed3[201] = "";

$int  iTmpLen = 0,icont_len = 0,ilen_end = 0;
$char ncont_tmp[201],ed_tmp[201];

$char icar_type_ori[3];

/*�U�L�@���M�ץ�ɵo*/
$int bufa_ins_17 = 0,bufa_ins_19 = 0;

/*���P�X�W��25�X*/
$char iengine_0[CA_ENGINE_NUM],iengine_1[21],iengine_2[6];

/*���[���ڻ�����r*/
$char nprovision[42];
$char nprov_note[210];
$char nprov_note_print[220];

struct lin
{
    int no;
    int pos[MAX_ROW];
    char *pp[MAX_ROW];
};

struct  lin  ppage[120];
struct  lin  iins_page[120];
struct  lin  bottom_page[120];

$int provision_X = 0;
$char nprov_X[50];

/* 1071107007_SC2_UBI�{���W�u */
$int provision_U = 0;

/* 1071226006_SC4_�w���ƫ����վ�(���²v+�ĤT�H�d��) */
$int provision_P = 0,provision_Q = 0,provision_V = 0;
$int provision_M = 0,provision_Y = 0;
$int cnt_V09 = 0,cnt_V3132 = 0;
$char nprov_pqv[105];

/* 1080225007_SC4_�s�W�r�˰ӫ~  */
$int provision_K = 0;

/* 1080708002_SC4_�s�W�����������(�N��L)  */
$int provision_L = 0;
$char nprov_L[50];

/* 1080311008_SC4_�ͮĤ��71�_����s�v�I */
$char fchk_24[2];

/* 1100419003_SC3_���I�O�����QR Code�q�l��*/
$char feterms[2];
$char str_sEterms[2];

/* 1120316006_SC5_�L��-���N�I���e�{�s�W���@�������������O�N��05�ή��s�X��t�ηs�W���@�����O */
$char fdbgn20230601[2],fdply20230601[2];

long ply_query();
long get_ply_data();
long ca_freeform();
long insert_freeform();
long process_rpt();
long ca_free_data();

char *get_full_dbname();
char *get_car_full_db();
int IsFcomp24();
int IsFcomp55();
int *iGetChinesePos();

$char outputf2[20];
$char kpid[20];
$char nbrand[31];

/* �I�ة��� INSKIND */
$char stmt_kind[1024];
$double line_no_tmp;
$char iins_type_tmp[7];
$char nins_type_tmp[121];
$char main_paid_tmp[251];
$char cover_print_tmp[121];
$char amt_print_tmp[121];
$char prn_deduct_tmp[121];
$char str_ins_premium_tmp[121];
/* ���ڥN�� CONDITION */
$char stmt_cond[1024],icondition1[20];
$int  qserial1=0;

$char nofficer[11];
$char iserial[11];
$char feply2[2];
$char fprov_yn[2];
$char ncar_type[11];
$char formid_tmp[11];
$char ipgid_tmp[11];
$char freceipt_tmp[2];

/* �O�T�I */
$long   dply_begin_ext;
$long   dply_end_ext;
$char   nassured_ext[121],nowner_ext[121],nowner_ext_tmp[21];
$long   qperiod_ext,qmiles_ext;
$double mkilo_ply_ext;
$char   icar_flag_ext[2],iparts_ext[2];
$int    mcover1_ext;
$char   year_chinese[5],mile_chinese[60];
$char   mkiloply_tmp[12];
$char   mpremium_tmp[12];

$int    check_point=0;	

/* 1120927002_C03_�R�q�ΰӫ~�}�o(�tebpB2B���s) */
$long   dinstall;
$char   dinstall_str[40];
$char   yyinstall[4],mminstall[3],ddinstall[3];
$char   isequence[31],ainstall_zip[7],ainstall[91];

/* �q�l�O���ˮ���� */
$char   nplyidx1[256], nplyidx2[1001], nplyidx2_tmp[400], nplyidx3[5001], nplyidx3_tmp[400], nplyidx3_tmp2[400];
/* ���q�l�O�� */
$char   iendorse_free[21];

$char   v_sErrMsgtmp[512];

/* ���p�j���I */
$char icard_tmp[21];
$char r_feply[2],r_iassured[11],r_nassured[121],r_aassured[92],r_icar_type[3],r_nbrand_abbr[14];
$char r_ipro_year[5],r_itag[CA_TAG_NUM],r_iengine[CA_ENGINE_NUM],r_dcreate[21];
$char r_iofficer[11],r_nleader[11],r_ncar_type[11],r_dply_begin[11],r_dply_end[11],r_fout_print[2],r_fmail_type[2];
$int  r_qply_period = 0,r_mpremium = 0,chk_card_print = 0;
$char r_dply_begin_100[11],r_dply_begin_yy[4],r_dply_begin_mm[3],r_dply_begin_dd[3];
$char r_dply_end_100[11],r_dply_end_yy[4],r_dply_end_mm[3],r_dply_end_dd[3];
$char s_r_qply_period[2];
int   tmp_prem,other_prem;
$char url1[256],url2[256],url3[256];
char  ch_amt[40],ch_amt01[40],ch_amt02[40],ch_amt03[40],ch_amt04[40],ch_amt05[40];
$char r_itmp_policy[20];

$char itmp_policy[20];

/*------------------------------------------------------------------------------------------------------------------------------------*/
/* �ǿ���컡��
   sIpolicy:�O�渹                 freprint:�ɵo�O(�@��C�L(�t�q�l���):�ťաA�ɵo:0�θɵo�G�r)  
   sIkind:�O�_�L�X�u�f���B(0;1)    iPrintList:�O�_�L�W�U(0;1)   iprint:���ڥ�(userid)    PrintDlist:���r�W�U(0;1)   ProtectData:�Ӹ�B�n(0;1) 
   DbName:��Ʈw�O(����)           ipolicyB_type:�O��O�P�_(�@���0;�M�ץ�1;�e�~2...��)
   freeform_kpid:cmn545�帹        iserl:�O��y����(�^�ǭ�)     feply:�O�_�q�l�O��       fprov:�O�_�C�L����         formid:�O�橳�Z(CARPLY001�BCARPLY002)
   ipgid:����{��                  freceipt:�O�_�C�L���� 
   v_nplyidx1:�O�歺���˯����     v_nplyidx2:�O��ӫO���e      v_nplyidx3:�O������˯����(�e�T���^�ǭȥΡA�q�l�O��ϥ�)
   iendorse:��渹(�q�l�O���)     v_sErrMsg:���~�T���^��
*/
long ca_freeform_policy(sIpolicy, freprint, sIkind, iPrintList, iprint, PrintDlist, ProtectData, ipolicyB_type, freeform_kpid, iserl, feply, fprov, formid, ipgid, freceipt, v_nplyidx1, v_nplyidx2, v_nplyidx3, iendorse, v_sErrMsg)
$char sIpolicy[],iprint[11];
char  sIkind[];
int   iPrintList;
char  PrintDlist[2];
char  ProtectData[2];
char  ipolicyB_type[2];
char  freeform_kpid[20];
char  *iserl;
char  feply[2];
char  fprov[2];
char  formid[11];
char  ipgid[11];
char  freceipt[11];
char  *v_nplyidx1;
char  *v_nplyidx2;
char  *v_nplyidx3;
char  iendorse[21];
char  *v_sErrMsg;
{
    int rc;
    $int sType;
    iPrintList=0;

    Pline = 21; /* �C�@���I�س����i�C�L�����  add by sylvia 101.10.08 (1010928006_C1)*/
	/*1090218008_SC1_�e�~�O���I�ة��Ӱ϶������C�󥿬�21��*/
    printf(">>>>INTO ca_rpt_policy(),ipolicy[%s],List[%d]\n",sIpolicy,iPrintList);
    strcpy(reprint,freprint);
    strcpy(PrintDlist, trim(PrintDlist));
    strcpy(sProtectData,trim(ProtectData));
    strcpy(sIpolicyB_type,trim(ipolicyB_type));
    strcpy(kpid,trim(freeform_kpid));
    strcpy(feply2,trim(feply));
    strcpy(fprov_yn,trim(fprov));
    strcpy(formid_tmp,trim(formid));
    strcpy(ipgid_tmp,trim(ipgid));
    strcpy(freceipt_tmp,trim(freceipt));
    strcpy(iendorse_free,trim(iendorse));
    strcpy(v_sErrMsg," ");

    printf("---------------- PrintDlist = [%s] ------------\n",PrintDlist);
    printf("---------------- ProtectData = [%s] -----------\n",sProtectData);
    printf("---------------- DBName = [%s] ----------------\n",DBName);
    printf("---------------- sIpolicyB_type = [%s] --------\n",sIpolicyB_type);

    /* �s�W�@��temp table��m�I�ئC�L�һݪ���� */
    /* line_no�C�L����� */
    /* field1�Ĥ@��,�I�ؽs�� */
    /* field2�ĤG��,�I�ئW�� */
    /* field3�ĤT��,�D�n���I���� */
    /* field4�ĥ|��,�O�I���B */
    /* field5�Ĥ���,�O���I���ɪ��O�B */
    /* field5�Ĥ���,�ۭt�B */
    /* field6�ĤC��,�O�I�O */
    /* ins_premium�O�I�O(���A��long),�ˮ֥� */
	
	$CREATE TEMP TABLE ca_freeform_tmp
    (	kpid     CHAR (11)     NOT NULL,
        inumber  CHAR (20)     NOT NULL,
        iline    INTEGER       NOT NULL,
        ncontent VARCHAR (255) NOT NULL
    ) with no log;
	
    $CREATE TEMP TABLE tbl_print
    (   ipolicy   char(20),
        line_no   serial,
        field1    varchar(6),
        field2    varchar(120),
        field3    varchar(250),
        field4    varchar(120),
        field5    varchar(120),
        field6    varchar(120),
        field7    varchar(120),
        ins_premium integer
    ) with no log;
    
    $CREATE TEMP TABLE print_layout
    (   ipolicy     char(20),
        line_no     decimal(10,2),
        field1      varchar(6),
        field2      varchar(120),
        field3      varchar(250),
        field4      varchar(120),
        field5      varchar(120),
        field6      varchar(120),
        field7      varchar(120),
        ins_premium integer,
        field_tmp   varchar(120)
    ) with no log;
    
    $CREATE TEMP TABLE print_layout56
    (   ipolicy     char(20),
        line_no     decimal(10,2),
        field1      varchar(6),
        field2      varchar(120),
        field3      varchar(250),
        field4      varchar(120),
        field5      varchar(120),
        field6      varchar(120),
        field7      varchar(120),
        ins_premium integer,
        field_tmp   varchar(120)
    ) with no log;
    
    /* ��h�ӫO�B */
    $CREATE TEMP TABLE tbl_coverage
    (   ipolicy   char(20),
        serial_no serial,
        contain1  char(20)
    ) with no log;
    
    /*�帹*/
	$CREATE TEMP TABLE tbl_ncontent
    (   ipolicy   char(20),
        ncont  varchar(151),
        serial_no serial
    ) with no log;
    	$CREATE TEMP TABLE tbl_ncontent2
    (   ipolicy   char(20),
        ncont  varchar(151),
        serial_no serial
    ) with no log;
    
    /*�r�p�H�ˮ`�I�W�U*/
    $CREATE TEMP TABLE tbl_56list
    (   ipolicy       char(20),
        iins_type     char(6),
        iinsurant     char(10),
        ninsurant     char(30),
        dbirth        date,
        nbeneficiary  char(30),
        relation_bene char(1),
        tbenef        char(20),
        abenef        char(90),
        serial_no serial
    ) with no log;

   	/*��ӱ���*/
	$create temp table Cmp_tmp
	(
	  ipolicy      char(20),
	  iprovision   char(5),
	  qserial      int
	) with no log;
	$create index Cmp_ix1 on Cmp_tmp(ipolicy);
	
	/*�@�P����*/
	$create temp table Com_tmp
	(
	  ipolicy      char(20),
	  iprovision   char(5),
	  qserial      int
	) with no log;
	$create index Com_ix1 on Com_tmp(ipolicy);
	
	/*�I�ر���*/
	$create temp table Pro_tmp
	(
	  ipolicy      char(20),
	  iprovision   char(5),
	  qserial      int
	) with no log;
	$create index Pro_ix1 on Pro_tmp(ipolicy);
	
	/*�I�ر���*/
	$create temp table condition
	(
	  icondition  char(20),
	  qserial     int
	) with no log;
	$create index Cond_ix1 on condition(icondition);
	
	/*�帹������*/
	$create temp table ca_terms_tmpf
    (
      ncontract char(20)
    ) with no log;
    
    rc = getCompanyId(CompanyId);
    if (rc < 0) return rc;

    /* car9803301 default �֭�帹flag */
    strcpy(flag980401,"0");
    /* end of default */

    strcpy(deduct_30,"");
    strcpy(deduct_301,"");
    strcpy(deduct_302,"");
    
    strcpy(iserial," ");

    rc = ply_query(sIpolicy);
    if (rc!=M_CM_OK) return rc;
    
    /* �ھڶǤJ���ѼƨM�w�O�_�C�L�W�U */
    list_print = iPrintList;
    
    rc = get_ply_data(sIpolicy, sIkind);
    if (rc!=M_CM_OK) return rc;

    if(strncmp(sIpolicyB_type,"4",1) != 0) /*sIpolicyB_type=4�A�Ӧ�car353���I�O��ֹ�q���H�o�@�~�A�ޥ�ca_rpt_policy�O���I�ئC�L�榡*/
    {
    	/* tbl_print insert print_layout */
    	rc = process_rpt();
        if( rc!= M_CM_OK) return rc;
		/* Insert into ca_freefrom */
		rc = ca_freeform(iprint, " ",v_sErrMsgtmp);
		if( rc!= M_CM_OK) 
		{
			strcpy(v_sErrMsg,v_sErrMsgtmp);
			return rc;
		}
		
		$INSERT INTO ca_freeform SELECT * FROM ca_freeform_tmp;
		$DROP TABLE ca_freeform_tmp;
	}
	
	/* ���եΡA�ݹ��鲣�s�ɮ�*/
	/*rc = ca_free_data(sIpolicy);
	if (rc!=M_CM_OK) return rc;*/
	
	printf("iserial[%s] \n",iserial);
	strcpy(iserl,iserial);
	
	if (feply2[0] == '1')
	{
		strcpy(v_nplyidx1,nplyidx1);
		strcpy(v_nplyidx2,nplyidx2);
		strcpy(v_nplyidx3,nplyidx3);
	}
	else 
	{
		strcpy(v_nplyidx1," ");
		strcpy(v_nplyidx2," ");
		strcpy(v_nplyidx3," ");
	}

	return M_CM_OK;
}
/*--------------------------------------------------------------------*/
void ply_clear()
{
    int i;

    printf("in clear\n");
    sex1[0]=0; sex1_appl[0]=0;
    marriage1[0]=0;
    edomain1[0]=0;
    qcoverage=0;
    prem21=0;
    s_dpolicy[0]=0;
    s_r_dbegin[0]=0;
    s_r_dend[0]=0;
    r_dbegin=0;
    r_dend=0;
    fcar1[0]=0;
    fcar2[0]=0;
    s_premium1[0]=0;
    ply1[0]=0;
    ply[0]=0;
    ply2[0]=0;
    iply_area[0]=0;
    last_ply1[0]=0;
    last_ply2[0]=0;
    ps_dtl[0]=0;
    ps_60[0]=0;
    ins_11 = ins_14 = ins_17 = ins_19 = ins_31 = ins_32 = ins_51 = ins_56 = ins_575960 = ins_36 = ins_37 = ins_150151 = 0;
    qday=0;
    coverage1=coverage2=coverage3=0;
    ins_31_multiple = 0;
    line66 = line67 = 0;
    list_cnt = list_print = 0;

    strcpy(flag_29_exist," "); strcpy(flag_31_exist," "); strcpy(flag_32_exist," ");
    strcpy(sCoverage1,""); strcpy(sCoverage2,""); strcpy(sCoverage3,"");
    strcpy(icard,""); strcpy(ipolicy,""); strcpy(irelative_ply,"");
    strcpy(fcard_class,""); strcpy(fprint,"");
    strcpy(ilast_ply,""); strcpy(ibroker,""); strcpy(iofficer,"");
    strcpy(ibig_branch,""); strcpy(ibig_office,"");
    strcpy(ibig_sales,"");
    strcpy(icashier,""); strcpy(iexaminer,""); strcpy(ientry,"");
    strcpy(r_icard,""); strcpy(nbrand_abbr,""); strcpy(ncar_abbr,"");
    strcpy(fcar_class,"");
    strcpy(fassured,""); strcpy(nassured,""); strcpy(nuser,"");
    strcpy(nbenef,""); strcpy(aassured,""); strcpy(itel,"");
    strcpy(aassured_zip,"");strcpy(aassured_cmb,"");
    strcpy(ipro_year,""); strcpy(ibrand,"");
    strcpy(icar_type,""); strcpy(iengine,""); strcpy(ibody,"");
    strcpy(icar_flag,"");
    strcpy(itag,""); strcpy(ilicense,"");
    strcpy(fpt,"");
    strcpy(fsex,""); strcpy(fmarriage,"");strcpy(fsex_appl,"");
    
    strcpy(fapplicant,""); strcpy(napplicant,"");dbirth_appl=0;
    strcpy(iext_policy,"");
    
    strcpy(flimit,""); strcpy(apayment,""); strcpy(nequipment,"");
    strcpy(napplicant,""); strcpy(apayment_zip,""); strcpy(iextra_charge,"");
    strcpy(transno,""); strcpy(dendorse,"");
    strcpy(nequipment_17,""); premium_17=0; old_premium_17=0; mdiscount_17=0;
    strcpy(nequipment_7h_14,""); premium_7h_14=0; old_premium_7h_14=0; mdiscount_7h_14=0;
    strcpy(nequipment_7h_19,""); premium_7h_19=0; old_premium_7h_19=0; mdiscount_7h_19=0;
    strcpy(s_note1,""); strcpy(s_note2,"");
    seqno=0;
    mcar_price=0;qpt=0;psex_age=psex_age_damage=0;plia_acc=0;pdmg_acc=0;mdiscount=0;
    mdmg_prem=0; mlia_prem=0; qply_period=0; qcylinder=0;
    pdmg_align=0; pbrg_align=0; plia_align=0; pdmg_factor=0;
    pbrg_factor=0;
    ins_mdiscount=0,old_premium=0;
    s_old_premium[0]=0;
    mpure_prem=0;
    add_mplace_01_flag=0 , add_mplace_11_flag=0;
    /* �q���ĤG���q */
    strcpy(sIcomm_obj, "");
    strcpy(sIroute_comm,"");
    strcpy(sIroute_prop,"");
    strcpy(sIcode,"");
    iQprovision = 0;
    strcpy(sProvD, " ");
    strcpy(sProvD_1, " ");
    strcpy(sProvD_2, " ");

    strcpy(fout_print," ");
    strcpy(fmail_type," ");
    strcpy(dcreate,""); strcpy(sDateTime,""); strcpy(sDate,"");
    out_ply_50 = 0;
    out_ply_47 = 0;
    out_ply_147 = 0;
    strcpy(sNassured_56_136, " ");
    mequipment = 0;
    strcpy(sMequipment, " ");
    strcpy(iquota,""); strcpy(nbranch,"");
    strcpy(napplicant,"");
    cntIroute = 0;
    strcpy(sIrouteNote," ");
    cntIroute2 = 0;
    strcpy(sIrouteNote2," ");
    strcpy(drate_ym," ");
    irate_ym = 0;
    out_ply_dmg = 0;
    provision_J = 0;
    punknown_acc = 0;
    strcpy(iquery_num_unknown," ");
    provision_X = 0;
    strcpy(nprov_X," ");
    provision_U = 0;
    provision_L = 0;
    /* 1071226006_SC4_�w���ƫ����վ�(���²v+�ĤT�H�d��) */
    provision_P = 0;
    provision_Q = 0;
    provision_V = 0;
    provision_K = 0;
    provision_M = 0;
    provision_Y = 0;
    cnt_V09 = 0;
    cnt_V3132 = 0;
    strcpy(nprov_pqv," ");
    strcpy(fchk_24," ");
    strcpy(feterms," ");
    strcpy(fdbgn20230601," "); 
    strcpy(fdply20230601," "); 
    
    strcpy(iinsurant56," ");
    strcpy(ninsurant56," ");
    dbirth56=0;
    strcpy(nbeneficiary56," ");
    strcpy(relation_bene56," ");
    strcpy(tbenef56," ");
    strcpy(abenef56," ");
    
    dply_begin_ext=0;dply_end_ext=0;
    strcpy(nassured_ext," ");strcpy(nowner_ext," ");
    qperiod_ext=0;qmiles_ext=0;mkilo_ply_ext=0;
    strcpy(icar_flag_ext," ");strcpy(iparts_ext," ");
    mcover1_ext=0;
    strcpy(year_chinese," ");strcpy(mile_chinese," ");strcpy(mkiloply_tmp," ");strcpy(mpremium_tmp," ");
    
    dinstall = 0;
	strcpy(isequence," ");strcpy(ainstall_zip," ");strcpy(ainstall," ");
	
	strcpy(icard_tmp," ");
	strcpy(r_feply," ");strcpy(r_iassured," ");strcpy(r_nassured," ");strcpy(r_aassured," ");strcpy(r_icar_type," ");strcpy(r_nbrand_abbr," ");
	strcpy(r_ipro_year," ");strcpy(r_itag," ");strcpy(r_iengine," ");strcpy(r_dcreate," ");
	strcpy(r_iofficer," ");strcpy(r_nleader," ");strcpy(r_ncar_type," ");strcpy(r_dply_begin," ");strcpy(r_dply_end," ");strcpy(r_fout_print," ");strcpy(r_fmail_type," ");
	r_qply_period = 0;r_mpremium = 0;chk_card_print = 0;
	strcpy(r_dply_begin_100," ");strcpy(r_dply_begin_yy," ");strcpy(r_dply_begin_mm," ");strcpy(r_dply_begin_dd," ");
	strcpy(r_dply_end_100," ");strcpy(r_dply_end_yy," ");strcpy(r_dply_end_mm," ");strcpy(r_dply_end_dd," ");
	strcpy(s_r_qply_period," ");
	tmp_prem = 0;other_prem = 0;
	strcpy(url1," ");strcpy(url2," ");strcpy(url3," ");
	strcpy(ch_amt," ");strcpy(ch_amt01," ");strcpy(ch_amt02," ");strcpy(ch_amt03," ");strcpy(ch_amt04," ");strcpy(ch_amt05," ");
	
	strcpy(r_itmp_policy," ");
	strcpy(itmp_policy," ");
	
	printf("out clear\n");
}
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------*/
long ply_query(sIpolicy)
char *sIpolicy;
{
	int   i=0,k,rc=0;
	int   flag_exist;
	$char stmt[2000],buf[20],sStmt[4096];
	char  dbsite[3], FullDBName[40];
	$char imgr[2],fsales[2],tmp_iroute[5];
	char  tmpName[11], v_sMsg[512];
	$char prov_terms[22],prov_terms1[22],prov_iins[7];
	char  tmp_prov_terms[60],swhere[60];
	$char f47[2];
	char *ncon,*ncon2;
	$char *ptr1;
	
	ply_clear();
	strcpy(ipolicy, sIpolicy);
	
	/* �P�_���M�ץ�O��or�D�M�ץ�O�� add by larry 102.12.16 (1021122001_C3) */
	/* �P�_�e�~��O��(sIpolicyB_type = 2) modify by larry 103.03.11 (1010523004_C2) */
	/* 0:�D�M�ץ�O��
	   1:�M�ץ�O��
	   2:�e�~�O��(�w�鵲)
	   3:�e�~�O��(���鵲)
	   4:car353           */
	/*if ((strncmp(sIpolicyB_type,"1",1) == 0) || (strncmp(sIpolicyB_type,"2",1) == 0) || (strncmp(sIpolicyB_type,"3",1) == 0))
	{
	    printf("-----1:�M�ץ�O�� 2:�e�~�O��(�w�鵲) 3:�e�~�O��(���鵲) sIpolicyB_type = [%s] -----\n",sIpolicyB_type);
	    strcpy(Full_DBName,get_car_full_db(ipolicy));
	}
	else
	{
	    printf("-----0:�D�M�ץ�O��(�@��O��C�L) 4:car353 sIpolicyB_type = [%s]-----\n",sIpolicyB_type);
	    strcpy(Full_DBName,get_full_dbname(DBName));
	}*/
	
	/* ������O���Ʈw */
	strcpy(Full_DBName,get_car_full_db(ipolicy));
	
	/* ���d�ۡA�H��e�~�i��Ϊ���A�᭱�e�~�����P�_�������� */
	{
		/* �e�~�O�����u��l�O��v��� (1041102003_C1) */
		/* �e�~�O��w�鵲������l�O���ɡA�e�~�O�楼�鵲�h�����̷s�O����*/
		if (strncmp(sIpolicyB_type,"2",1) == 0)
		{
		    sprintf_s(tablePly, sizeof tablePly,"%s:original_ply", Full_DBName);
		    sprintf_s(tableRelation, sizeof tableRelation,"%s:ori_ply_relation", Full_DBName);
		    sprintf_s(tableInsType, sizeof tableInsType,"%s:ori_ins_type", Full_DBName);
		    sprintf_s(tablePaPly, sizeof tablePaPly,"%s:ca_pa_ori", Full_DBName);
		    sprintf_s(tableAssured, sizeof tableAssured,"%s:ori_ins_assured", Full_DBName);
		}
		else
		{
			sprintf_s(tablePly, sizeof tablePly,"%s:policy", Full_DBName);
		    sprintf_s(tableRelation, sizeof tableRelation,"%s:ply_relation", Full_DBName);
			sprintf_s(tableInsType, sizeof tableInsType,"%s:ply_ins_type", Full_DBName);
			sprintf_s(tablePaPly, sizeof tablePaPly,"%s:ca_pa_ply", Full_DBName);
			sprintf_s(tableAssured, sizeof tableAssured,"%s:ply_ins_assured", Full_DBName);
		}
	}
	
	strcpy(tablePly, trim(tablePly));
	strcpy(tableRelation, trim(tableRelation));
	strcpy(tableInsType, trim(tableInsType));
	printf("***** Query table[%s][%s][%s] *****\n", tablePly, tableRelation, tableInsType);
	
	$WHENEVER SQLERROR GOTO errexit;
	/*99.11.22 �]���U�����{�������Ψ� NULL �� dpolicy, �ȼv�T��{������h,�]���t�~�s�W�@ ca_dpolicy ���֭�帹��*/
	sprintf_s(sStmt, sizeof sStmt,"SELECT x.icard, x.ipolicy, x.irelative_ply, x.fcard_class, x.fprint,\
	                      x.ilast_ply, x.ibroker, x.iofficer, x.iresource ,x.icashier,\
	                      x.ibig_branch, x.ibig_office, x.ibig_sales,\
	                      x.mdmg_prem, x.mlia_prem, NVL(x.dpolicy,' '),NVL(x.dpolicy,today),\
	                      NVL(x.dpolicy,0),\
	                      x.iexaminer, x.ientry, y.iply_area,\
	                      y.fassured, y.nassured, y.nuser, y.nbenef, y.aassured, y.itel,\
	                      trim(y.apayment), x.qply_period, x.dply_begin, \
	                      x.dply_end, y.dissue, x.ipro_year, x.ibrand, \
	                      x.icar_type, x.dentry, y.qcylinder, y.iengine, y.ibody, y.itag, y.mcar_price,\
	                      y.qpt, y.fpt, y.psex_age, y.psex_age_damage, y.plia_acc, y.pdmg_acc, y.aassured_zip,\
	                      y.ilicense, y.dbirth, y.fsex, y.fmarriage,\
	                      y.pdmg_factor, y.pbrg_factor,\
	                      y.flimit, y.pdmg_align, y.pbrg_align, y.plia_align,\
	                      y.nequipment, y.nbrand_abbr, y.fcomp_24,\
	                      x.transno, x.seqno, x.dendorse, x.icar_flag,\
	                      x.mdmg_pure_prem + x.mlia_pure_prem, y.iassured, trim(y.napplicant), trim(y.apayment_zip),\
	                      trim(y.iextra_charge), y.iroute,\
	                      x.icomm_obj, x.iroute_comm, y.iroute_prop, x.qprovision,\
	                      decode(x.transno[1,4],'6075',1,0), x.fout_print, x.fmail_type, x.dcreate, x.dply_close, \
	                      y.mequipment, x.iquota , y.fsex_appl, \
	                      y.punknown_acc, y.iquery_num_unknown, \
	                      case when x.dply_begin < '07/01/2019' then 'Y' else 'N' end,x.feterms, \
	                      case when x.dply_begin > '06/01/2023' then 'Y' else 'N' end, \
	                      case when DATE(nvl(x.dpolicy,'01/01/1911')) >= '06/01/2023' then 'Y' else 'N' end, \
	                      y.fapplicant ,y.iapplicant, y.dbirth_appl, y.iext_policy, y.nowner, y.mkilo_ply, \
	                      y.dinstall, y.isequence, y.ainstall_zip, y.ainstall, nvl(x.itmp_policy,' ') \
	                 FROM %s x, %s y \
	                WHERE y.ipolicy = x.ipolicy \
	                  AND x.ipolicy = '%s' ",tableRelation,tablePly,ipolicy);
	
	printf("sStmt[%s]\n",sStmt);
	$PREPARE policy_cur FROM $sStmt;
	$EXECUTE policy_cur INTO $icard, $ipolicy, $irelative_ply, $fcard_class, $fprint,
	                         $ilast_ply,  $ibroker, $iofficer, $iresource ,$icashier,
	                         $ibig_branch, $ibig_office, $ibig_sales,
	                         $mdmg_prem, $mlia_prem, $dpolicy,$ca_dpolicy,$dpolicy_long,
	                         $iexaminer, $ientry, $iply_area,
	                         $fassured, $nassured, $nuser, $nbenef, $aassured, $itel,
	                         $apayment, $qply_period, $dply_begin,
	                         $dply_end, $dissue, $ipro_year, $ibrand,
	                         $icar_type, $dentry, $qcylinder, $iengine, $ibody, $itag, $mcar_price,
	                         $qpt, $fpt, $psex_age, $psex_age_damage, $plia_acc, $pdmg_acc, $aassured_zip,
	                         $ilicense, $dbirth, $fsex, $fmarriage,
	                         $pdmg_factor, $pbrg_factor,
	                         $flimit, $pdmg_align, $pbrg_align, $plia_align,
	                         $nequipment, $nbrand_abbr, $fcomp_24,
	                         $transno, $seqno, $dendorse, $icar_flag,
	                         $mpure_prem, $iassured, $napplicant, $apayment_zip,
	                         $iextra_charge, $iroute,
	                         $sIcomm_obj, $sIroute_comm, $sIroute_prop, $iQprovision,
	                         $ply_6075, $fout_print, $fmail_type, $dcreate, $dply_close,
	                         $mequipment, $iquota ,$fsex_appl,
	                         $punknown_acc, $iquery_num_unknown ,$fchk_24, $feterms, $fdbgn20230601, $fdply20230601,
	                         $fapplicant, $iapplicant, $dbirth_appl, $iext_policy, $nowner_ext, $mkilo_ply_ext,
	                         $dinstall, $isequence, $ainstall_zip, $ainstall, $itmp_policy;
	if (SQLCODE == SQLNOTFOUND) return M_CM_NOT_FOUND;
	
	strcpy(itmp_policy,rtrim(itmp_policy));
	
	if(strncmp(ipolicy+5,"VW",2)==0)
	{
		sprintf_s(sStmt, sizeof sStmt,"SELECT nassured, dply_begin, dply_end, \
		                      qperiod, qmiles, icar_flag, iparts, \
		                      mcover1 \
		                 FROM %s:ca_ply_ext \
		                WHERE ipolicy = '%s' ",Full_DBName,iext_policy);
		printf("sStmt[%s] \n",sStmt);
		$PREPARE ply_ext_cur FROM $sStmt;
		$EXECUTE ply_ext_cur INTO $nassured_ext, $dply_begin_ext, $dply_end_ext,
		                          $qperiod_ext, $qmiles_ext, $icar_flag_ext, $iparts_ext,
		                          $mcover1_ext;
		if (SQLCODE == SQLNOTFOUND) return M_CM_NOT_FOUND;
	}
	
    strcpy(irelative_ply,trim(irelative_ply));

    /* �D�M�ץ�P�_:�g��N������W�g��BM�g��B������M0,M9 add by larry 102.12.26 (1021122001_C3) */
    /* �M�ץ�P�_:�g��N����W�g��BH�g��B������H0-H2 modify by sylvia 103.01.07 (1021122001_C3) */
    /* �M�ץ�P�_:�s�WN�g��A�~�Ȩӷ���E (1030630002_C4)*/
    if (strncmp(sIpolicyB_type,"0",1) == 0)
    {
        if ((strncmp(iofficer,"W",1) == 0) ||
           ((strncmp(iofficer,"H",1) == 0 ) && ((strncmp(iofficer,"H0",2)!=0)
             && (strncmp(iofficer,"H1",2)!=0) && (strncmp(iofficer,"H2",2)!=0))) ||
           ((strncmp(iofficer,"N",1) == 0) && (strncmp(iresource,"E",1) == 0)))
        {
            printf("�D�M�ץ�O��:���g��N�����M�ץ�g��(W, H (�ư�H0-H2) , N (�~�Ȩӷ���E)) \n");
            return M_CM_NOT_FOUND;
        }
    }

    /* �O��O�v�N���P�_ */
    sprintf_s(stmt, sizeof stmt,"SELECT Max(drate_ym) "
                 "  FROM %s "
                 " WHERE ipolicy = '%s'  ",tableInsType,ipolicy);
    $PREPARE outply_drate_ym FROM $stmt;
    $EXECUTE outply_drate_ym INTO $drate_ym;
	  
    irate_ym = atoi(drate_ym);

    /* �q���O���O(�e�~�O����) (1041102003_C1) */
    $SELECT chiname, count(*)
       INTO $sIrouteNote, $cntIroute
       FROM car_code
      WHERE kind = 'SR'
        AND detail = $iroute
        AND detail2 = $iofficer
      GROUP BY chiname;

    /*1061128001_C1_����W�ǳW�h�ܰ�*/  
    strcpy(icar_type_ori,icar_type);
    strcpy(icar_type,TRANS_CAR_TYPE(icar_type,drate_ym));
    printf("--850 trace icar_type[%s] drate_ym[%s]\n ",icar_type,drate_ym);

    /* H�g�줣�C�L����W�� add by larry 102.12.16 (1021122001_C3) */
    $SELECT nname INTO $nname_I
       FROM officer
      WHERE iofficer = $iofficer
        AND iofficer[1,1] <> 'W'
        AND NOT (iofficer[1,1] = 'H' AND iofficer[2,2] not in ('0','1','2'))
        AND NOT (iofficer[1,1] = 'N' AND fprop = 'E');

    if(SQLCODE == SQLNOTFOUND)
    {
        /* strcpy(ibroker," "); */
        strcpy(nname_I, " ");
    }

    /* 99.11.19 �j�M�q���N��������W�� */
    $SELECT nroute[1,20] INTO $nname_N
       FROM cm_route
      WHERE iroute = $iroute;
	if(SQLCODE == SQLNOTFOUND) strcpy(nname_N," ");
        
    /* ���W�� add by larry 104.08.10 (1040625002_C1) */
    $SELECT nbranch INTO $nbranch
       FROM sa_branch_type
      WHERE ibranch = $iquota;
    if(SQLCODE == SQLNOTFOUND) strcpy(nbranch," ");

    /* CompanyId */
    printf("companyid[%s]\n",CompanyId);
    if(strcmp( CompanyId, "32") == 0)
    {
       if( fassured[0] == '2' || fassured[0] == '4' || fassured[0] == '6' )
           strcpy( ilicense, iassured );
    }
    
    $SELECT imgr
       INTO $imgr
       FROM officer
      WHERE iofficer = $iofficer;
    if (SQLCODE == SQLNOTFOUND) strcpy(imgr,"2");

    /*--- �j�M�~�ȥN���m�W ---*/
    /* get_route_data input ������~��/�q���N��,���ӳq����~���N��
         �H�θg��N��,�^�Ǩ���/�q����~������W�� (2:����/�q����~��, 1:����/�q����~��) */
    /* imgr=1���ɭԬO���ӥ�,�Ǩ�����~��,��L���h�ǤJ�q���N�� */
    strcpy(tmpName,"");

    if (imgr[0] == '1')
    {
        rc = get_route_data(1, iofficer, ibig_office, ibig_sales, tmpName, v_sMsg);
        if (rc != M_CM_OK) strcpy(tmpName," ");
        strncpy(LHsNname,tmpName,10);
        LHsNname[11]='\0';
    }
    else
    {
        rc = get_route_data(1, iofficer, iroute, ibig_sales, tmpName, v_sMsg);
        if (rc != M_CM_OK) strcpy(tmpName," ");
        strncpy(LHsNname,tmpName,10);
        LHsNname[11]='\0';
    }
    /* end of Ū������/�q����~��(��) */

    if (imgr[0] == '1')
    {
       if (strlen(trim(LHsNname)) == 0)
       {
          if (strlen(trim(ibig_sales)) == 10)
          {
             ibig_sales[6] = '*';
             ibig_sales[7] = '*';
             ibig_sales[8] = '*';
             ibig_sales[9] = '*';
          }
       }
       else
       {
          strcpy(ibig_sales," ");
       }
    }

    if (irelative_ply[0]!='\0' && irelative_ply[0]!=' ')
    {
		printf("0010:irelative_ply[%s],fcard_class[%s]\n",irelative_ply,fcard_class);
		sprintf_s(stmt, sizeof stmt,"SELECT a.icard,a.dply_begin,a.dply_end,a.feply,b.iassured,b.nassured,b.aassured,a.icar_type, \
		                                    b.nbrand_abbr,(a.ipro_year::int-1911)::CHAR(4),b.itag,b.iengine,a.qply_period,a.mlia_prem,to_char(a.dcreate,'%%Y-%%m-%%d %%H:%%M:%%S'), \
		                                    a.iofficer,(SELECT nname FROM officer WHERE iofficer = a.ileader),a.dply_begin,a.dply_end,a.fout_print,a.fmail_type,NVL(itmp_policy,' ') \
		                               FROM %s a,%s b \
		                              WHERE a.ipolicy = b.ipolicy AND a.ipolicy= '%s'",tableRelation,tablePly,irelative_ply);
		printf("stmt[%s] \n",stmt);
		$PREPARE policy_cur2 FROM $stmt;
		$DECLARE icard_ply_cur CURSOR FOR policy_cur2;
		$OPEN    icard_ply_cur;
		$FETCH   icard_ply_cur INTO $r_icard,$r_dbegin,$r_dend,$r_feply,$r_iassured,$r_nassured,$r_aassured,$r_icar_type,
		                            $r_nbrand_abbr,$r_ipro_year,$r_itag,$r_iengine,$r_qply_period,$r_mpremium,$r_dcreate,
		                            $r_iofficer,$r_nleader,$r_dply_begin,$r_dply_end,$r_fout_print,$r_fmail_type,$r_itmp_policy;
		/*
		printf("r_icard[%s] r_dbegin[%d] r_dend[%d] r_feply[%s] r_iassured[%s] r_nassured[%s] r_aassured[%s] r_icar_type[%s] \n",r_icard,r_dbegin,r_dend,r_feply,r_iassured,r_nassured,r_aassured,r_icar_type);
		printf("r_nbrand_abbr[%s] r_ipro_year[%s] r_itag[%s] r_iengine[%s] r_qply_period[%d] r_mpremium[%d] r_dcreate[%s] \n",r_nbrand_abbr,r_ipro_year,r_itag,r_iengine,r_qply_period,r_mpremium,r_dcreate);
		printf("r_iofficer[%s] r_nleader[%s] \n",r_iofficer,r_nleader);
		printf("r_dply_begin[%s] r_dply_end[%s] r_fout_print[%s] r_fmail_type[%s] \n",r_dply_begin,r_dply_end,r_iofficer,r_nleader);
		*/
		strcpy(r_icard,rtrim(r_icard));
		strcpy(r_iofficer,rtrim(r_iofficer));
		strcpy(r_itmp_policy,rtrim(r_itmp_policy));
		
		if (SQLCODE == SQLNOTFOUND)
		{
			strcpy(r_icard," ");
			r_dbegin=0;r_dend=0;
		}
		$CLOSE icard_ply_cur;
		$FREE  icard_ply_cur;
		
		if(fcard_class[0]=='2')
		{
			sprintf_s(stmt, sizeof stmt,"SELECT mlia_prem \
			                FROM %s \
			               WHERE ipolicy = '%s'",tableRelation,irelative_ply);
			$PREPARE policy_cur3 FROM $stmt;
			$DECLARE prem_ply_cur CURSOR FOR policy_cur3;
			$OPEN    prem_ply_cur;
			$FETCH   prem_ply_cur INTO $prem21;
			if (SQLCODE == SQLNOTFOUND) 
			    prem21=0;
			$CLOSE prem_ply_cur;
			$FREE  prem_ply_cur;
		}
    }

    /*����޲z�H�B�޲z�H�m�W�B�g��H�q�ܸ��X*/
	$SELECT first 1 z.ileader as ileader,
	                y.nname as nleader,
	        case WHEN LEFT(r.iroute,2) = 'JB' THEN r.tphone
	        else x.itel END as ntel_leader
	   INTO $ileader, $nname, $ntel_leader
	   FROM ca_big_office x, officer y, officer z,cm_route r
	  WHERE ((x.ibig_comp = y.iquota[1,4] || '00') or (x.ibig_comp = y.iquota))
	    AND r.iroute= z.iroute
	    AND x.fclass = '3'
	    AND y.iofficer = z.ileader
	    AND z.iofficer = $iofficer
	  order by x.ibig_comp desc;

    if(SQLCODE==SQLNOTFOUND)
    {
		strcpy( ileader, "");
		strcpy( nname, "");
		strcpy( ntel_leader, "");
		
		$SELECT ileader
		   INTO $ileader
		   FROM officer
		  WHERE iofficer=$iofficer;
		if (SQLCODE == SQLNOTFOUND)
		    strcpy(ileader," ");
		
		$SELECT nname
		   INTO $nname
		   FROM officer
		  WHERE iofficer=$ileader;
		if (SQLCODE == SQLNOTFOUND)
		    strcpy(nname," ");       
    }
    printf("***858***\nileader=%s,\n nname=%s,\n ntel_leader=%s\n",ileader,nname,ntel_leader);

	printf("0020:prem21[%d]\n",prem21);
	if(prem21 > 0 )
	{
		strcpy(bak4,"(�t�j��)");
		strcpy(bak1,refmtamt(prem21,MILLIONTH));
		if(strcmp(irelative_ply,r_icard) != 0)
		{
		    sprintf_s(s_prem21, sizeof s_prem21,"�j��O�O %s  (�Ҹ�%s)",bak1,r_icard);
		    sprintf_s(prem_note2, sizeof prem_note2,"(�j���Ҹ�%s  �O�O%s��)",r_icard,bak1);
		}
		else
		{
		    sprintf_s(s_prem21, sizeof s_prem21,"�j��O�O %s  ",bak1);
		    sprintf_s(prem_note2, sizeof prem_note2,"(�j��O�O%s��)",bak1);
		}
	}
	else
	{
		strcpy(bak4," ");
		strcpy(s_prem21," ");
	}

    printf("0020:s_prem21[%s]\n",s_prem21);

    mdiscount=0;
    mcommission=0;
    sprintf_s(stmt, sizeof stmt,"SELECT SUM(mcommission) \
                    FROM %s \
                   WHERE ipolicy = '%s'",tableInsType,ipolicy);
    $PREPARE policy_cur4 FROM $stmt;
    $DECLARE commis_cur CURSOR FOR policy_cur4;
    $OPEN  commis_cur;
    $FETCH commis_cur INTO $mcommission;
    $CLOSE commis_cur;
    $FREE  commis_cur;

    sprintf_s(stmt, sizeof stmt,"SELECT SUM(case when mdiscount<0 then 0 else mdiscount end) \
                    FROM %s \
                   WHERE ipolicy = '%s'",tableInsType,ipolicy);
    $PREPARE policy_cur5 FROM $stmt;
    $DECLARE discoun_cur CURSOR FOR policy_cur5;
    $OPEN  discoun_cur;
    $FETCH discoun_cur INTO $mdiscount;
    $CLOSE discoun_cur;
    $FREE  discoun_cur;

    sprintf_s(stmt, sizeof stmt,"SELECT SUM(mins_premium) \
                     FROM %s \
                    WHERE ipolicy = '%s'",tableInsType,ipolicy);
    $PREPARE policy_cur6 FROM $stmt;
    $DECLARE prem1_cur CURSOR FOR policy_cur6;
    $OPEN  prem1_cur;
    $FETCH prem1_cur INTO $premium1;
    $CLOSE prem1_cur;
    $FREE  prem1_cur;

    strncpy(site2,ipolicy,2);
    site2[2]='\0';

    $SELECT npresident,ifirm_pid,nchi_abv
       INTO $npresident,$ifirm_pid,$tax_area
       FROM branch
      WHERE ibranch = $site2;
    if (SQLCODE == SQLNOTFOUND)
        return M_CM_NOT_FOUND;

    $SELECT fcar_class, ncode
       INTO $fcar_class, $ncar_abbr
       FROM car_type
      WHERE icode = $icar_type AND fclass = '1';
    if(SQLCODE == SQLNOTFOUND)
        strcpy( fcar_class, " ");

    printf("ipolicy[%s] dply_begin[%ld] ca_dpolicy[%s]\n",ipolicy,dply_begin,ca_dpolicy);
    
    strcpy(f47,"0");
    /* 47�I�ضO�v�N���P�_ */
    /* f47 = '0'�A���ܥ��ӫO47��47�O�v�N��>=111�A�����47�帹*/
    /* f47 = '1'�A����47�O�v�N��<111�A�n���47�帹*/
    /*1081205009_SC4_�t�X47�I�رq�D�I�אּ���[�I�A�ק���s/E�O��/B2B/B2C�ˮ�(�Цb12�멳����)*/
    sprintf_s(stmt, sizeof stmt,"SELECT CASE WHEN CAST (drate_ym AS INTEGER)>=111 THEN '0' ELSE '1'  END "
                 "  FROM %s "
                 " WHERE ipolicy = '%s' AND iins_type='47' ",tableInsType,ipolicy);
    $PREPARE drate_ym_47 FROM $stmt;
    $EXECUTE drate_ym_47 INTO $f47;
    
    /* 1111005011_SC1_�����q�l����(�tE�O��B2B���s�q�lñ���u�W�n�O) */
    strcpy(feterms,"0");
    printf("feterms[%s]\n",feterms);
    
    /*******************************************/
    /*======== ��������������  �H�U�걵�I�ؤ帹  �������������� ========*/
    /* �C�@���帹���n�C�X�ӡA�ۥΧ�帹�@�B��~��帹�G */  
    /* 1090915004_SC1_�Эק�car307�B�e�~�B�q�l�O�檺�^���帹�W�h*/
    sprintf_s(ncontent_print, sizeof ncontent_print,"");
    sprintf_s(ncontent1, sizeof ncontent1,"");
    sprintf_s(ncontent2, sizeof ncontent2,"");
    
    sprintf_s(stmt1, sizeof stmt1,"SELECT max(ncontract),a.iins_type "
                  "  FROM ca_terms a, %s b"
                  " WHERE a.iins_type = b.iins_type"
                  "   AND b.ipolicy = ? "
                  "   AND deffect <= ? "
                  "   AND dcreate <= ? "
                  "   AND ((dendorse IS NULL) OR (dendorse IS NOT NULL AND b.minjured_cover + b.mdeath_cover + b.mdamage_cover = 0) )"
                  " GROUP BY a.iins_type "
                  " UNION "
                  "SELECT max(ncontract),a.iins_type "
                  "  FROM ca_terms a, %s b"
                  " WHERE a.iins_type = b.iins_type"
                  "   AND b.ipolicy = ? "
                  "   AND deffect <= b.dedr_begin "
                  "   AND dcreate <= b.dendorse "
                  "   AND dendorse IS NOT NULL AND b.minjured_cover + b.mdeath_cover + b.mdamage_cover <> 0 "
                  " GROUP BY a.iins_type "
                  " ORDER BY 1 DESC ",tableInsType,tableInsType);
    $PREPARE s_app4 FROM $stmt1;
    $DECLARE sel_app4 CURSOR FOR s_app4;
    $OPEN sel_app4 USING $ipolicy,$dply_begin,$ca_dpolicy,$ipolicy;
  
    while(1)
    {
        $FETCH sel_app4 INTO $ncontract,$viins_type;
         	
        if (SQLCODE == SQLNOTFOUND) break;
        printf("ncontract[%s],viins_type[%s]\n",ncontract, viins_type);

        sprintf_s(stmt2, sizeof stmt2, " SELECT ncontent1,ncontent2 "
                                       "   FROM ca_terms "
                                       "  WHERE ncontract = '%s' "
                                       "    AND iins_type = '%s' "
                                       "    AND ncontract NOT IN (SELECT ncontract FROM ca_terms_tmpf) " ,ncontract,viins_type);
        $PREPARE terms FROM $stmt2;
        $EXECUTE terms into $ncontent1,$ncontent2;
        
        if (SQLCODE == SQLNOTFOUND) continue;
        
        $INSERT INTO ca_terms_tmpf(ncontract) VALUES($ncontract);
            
        /*�O�v�N��>=111�A����ܤ帹*/
        /*1081205009_SC4_�t�X47�I�رq�D�I�אּ���[�I�A�ק���s/E�O��/B2B/B2C�ˮ�(�Цb12�멳����)*/
        if(strcmp(f47,"0")==0 && strcmp(trim(viins_type),"47")==0)
        {
            strcpy(ncontent1,"");
            strcpy(ncontent2,"");
        }

		if (fcar_class[0] == '1')
		{
			if (strcmp(trim(ncontent1),"") != 0)
			{
				sprintf_s(ncontent1, sizeof ncontent1, "%s;", trim(ncontent1));
				strcat(ncontent_print, ncontent1);
			}
		}
		else
		{
			if (strcmp(trim(ncontent2),"") != 0)
			{
				sprintf_s(ncontent2, sizeof ncontent2, "%s;", trim(ncontent2));
				strcat(ncontent_print, ncontent2);
			}
		}
	}
    $CLOSE sel_app4;
    $FREE  sel_app4;

    $DELETE FROM ca_terms_tmpf;
  
    /*======== ��������������  �H�U�걵���[���ڻ�����r�B�帹  �������������� ========*/
    strcpy(prov_terms,"");
    strcpy(prov_terms1,"");
    strcpy(prov_iins,"");
    strcpy(nprov_note,"");
    strcpy(swhere,"");
    sprintf_s(stmt1_2, sizeof stmt1_2,"SELECT trim(nvl(provision,' '))||';',iins_type "
                    " FROM  %s "
                    " WHERE ipolicy = '%s' ",tableInsType,ipolicy);
    $PREPARE s_app6 FROM $stmt1_2;
         
    $DECLARE sel_app6 CURSOR FOR s_app6;
    $OPEN sel_app6 ;
    printf("stmt1_2[%s]\n",stmt1_2);
    while(1)
    {
        $FETCH sel_app6 INTO $prov_terms1,$prov_iins;
        printf("prov_terms1[%s]prov_iins[%s]\n",prov_terms1,prov_iins);
        
        if (SQLCODE == SQLNOTFOUND)  break;

		if (strstr(trim(prov_terms1),"P;") != NULL)
		{
			if ((strcmp(trim(prov_iins),"01")!=0)  && (strcmp(trim(prov_iins),"05")!=0)  && (strcmp(trim(prov_iins),"09")!=0)  && (strcmp(trim(prov_iins),"11")!=0) &&
			    (strcmp(trim(prov_iins),"201")!=0) && (strcmp(trim(prov_iins),"205")!=0) && (strcmp(trim(prov_iins),"209")!=0) && (strcmp(trim(prov_iins),"211")!=0))
			$SELECT first 1 replace($prov_terms1,'P;','')
			   INTO $prov_terms1
			   FROM systables;
		}
		else if (strstr(trim(prov_terms1),"Q;") != NULL)
		{
			if ((strcmp(trim(prov_iins),"01")!=0) && (strcmp(trim(prov_iins),"05")!=0) && (strcmp(trim(prov_iins),"09")!=0) && (strcmp(trim(prov_iins),"11")!=0) &&
			    (strcmp(trim(prov_iins),"201")!=0) && (strcmp(trim(prov_iins),"205")!=0) && (strcmp(trim(prov_iins),"209")!=0) && (strcmp(trim(prov_iins),"211")!=0))
		 	$SELECT first 1 replace($prov_terms1,'Q;','')
		       INTO $prov_terms1
		       FROM systables;	
		}
		else if (strstr(trim(prov_terms1),"M;") != NULL)
		{
			if ((strcmp(trim(prov_iins),"01")!=0)  && (strcmp(trim(prov_iins),"05")!=0)  && (strcmp(trim(prov_iins),"09")!=0)  && (strcmp(trim(prov_iins),"11")!=0) && (strcmp(trim(prov_iins),"181")!=0) &&
			    (strcmp(trim(prov_iins),"201")!=0) && (strcmp(trim(prov_iins),"205")!=0) && (strcmp(trim(prov_iins),"209")!=0) && (strcmp(trim(prov_iins),"211")!=0))
		    $SELECT first 1 replace($prov_terms1,'M;','')
		       INTO $prov_terms1
		       FROM systables;		
		}
		else if (strstr(trim(prov_terms1),"Y;") != NULL)
		{
			/* 1130827011_C04_�s�W�s�t��W�B���[����(Y)(�L��) */
			if ((strcmp(trim(prov_iins),"01")!=0)  && (strcmp(trim(prov_iins),"05")!=0)  && (strcmp(trim(prov_iins),"09")!=0)  && (strcmp(trim(prov_iins),"11")!=0) && (strcmp(trim(prov_iins),"198")!=0) &&
			    (strcmp(trim(prov_iins),"201")!=0) && (strcmp(trim(prov_iins),"205")!=0) && (strcmp(trim(prov_iins),"209")!=0) && (strcmp(trim(prov_iins),"211")!=0))
		    $SELECT first 1 replace($prov_terms1,'Y;','')
		       INTO $prov_terms1
		       FROM systables;		
		}
		strcat(prov_terms,trim(prov_terms1));	  
    }
    $CLOSE sel_app6;
    $FREE  sel_app6;
    
	strcpy(prov_terms,trim(prov_terms));
	printf("prov_terms[%s]\n",prov_terms);
	strcpy(nprov_note_print,"  ");
	
	if(strlen(prov_terms)>1)
	{
		strcpy(swhere,"");
		strcpy(tmp_prov_terms,"");
		
		ptr1 = strtok(prov_terms,";");
		while(ptr1 != NULL)
		{
			sprintf_s(tmp_prov_terms, sizeof tmp_prov_terms,"'%s',",ptr1);  
			strcat(swhere,tmp_prov_terms);
			ptr1 = strtok(NULL, ";");
		}
        strcat(swhere,"''");	
        printf("�����[����:swhere[%s]\n",trim(swhere));
             
        /*���[���ڻ�����r*/
        strcpy(nprovision,"");
        strcpy(nprov_note,"���O����[");
        strcpy(nprov_note_print,"");
        sprintf_s(stmt1, sizeof stmt1,"SELECT trim(nprint)||',' "
                      "  FROM ca_provision_main "
                      " WHERE iprovision IN (%s) "
                      "   AND iprovision NOT IN ('C','E','S') ",swhere);
        $PREPARE s_app8 FROM $stmt1;
        $DECLARE sel_app8 CURSOR FOR s_app8;
        $OPEN sel_app8 ;
  
        while(1)
        {
            $FETCH sel_app8 INTO $nprovision;
         	
            if (SQLCODE == SQLNOTFOUND) break;
            strcat(nprov_note,trim(nprovision));
	    
        }
        $CLOSE sel_app8;
        $FREE  sel_app8;         
             
        if(strcmp(trim(nprov_note),"���O����[")==0) strcpy(nprov_note," ");
        nprov_note[strlen(nprov_note)-1]='\0';
    }
    
    /*======== ��������������  �H�U�걵���ڥN��  �������������� ========*/
	printf("drate_ym[%s],dpolicy[%s] \n",drate_ym,dpolicy);
	$char stmt_prov[2048],stmp_p[1024];
	$char stmt_cu[1024],stmt_cmp[1024],stmt_com[1024],stmt_pro[1024];
	$int cnt_prov,cnt_prov_chk;
	$char fcar_class_p[2],iins_type_p[7],fins_grp[2];
	$int  qserial_p,cnt_cmp=0,cnt_com=0,cnt_pro=0,cnt_pro_cmp=0,cnt_pro_cmp2=0;
	$char iprovision1[6],drate1[4],iclass1[2],dbegin[11],dbegin0[11],dbegin1[11],dbegin00[11];
	$char dbegin0_yy[4],dbegin0_mm[3],dbegin0_dd[3];
	$char cmp_provision[6],com_provision[6],iins_provision1[6],iins_provision2[6],iins_provision3[6];
	$char iins_provision_add[22],provision_add[6],iprovision_add[6],nprovision_add[6];
	$char icondition[21];
	$int cnt_cmp2=0,cnt_com2=0,err_cmp=0,err_com=0,icnt_cond=0;
	
	stmp_p[0] = '\0';
	cnt_prov_chk = 0;
	
	/*�P�_�ۥΡB��~*/
    if (strncmp(icar_type,"CS",2) == 0)  /* �R�q�� */
	{	
		strcpy(fcar_class_p,"B");
	}
	else 
	{
	    $SELECT case when fcar_class = '1' then 'C' else 'S' end
	       INTO $fcar_class_p
	       FROM car_type
	      WHERE icode = $icar_type AND fclass = '1';
		if(SQLCODE == SQLNOTFOUND) strcpy(fcar_class, " ");
	}
	
	if (fprov_yn[0] == 'Y')
	{
		/* �ɵo��ñ��� */
		if(strcmp(reprint,"�ɵo") == 0 || strcmp(reprint,"0") == 0)
		{
			sprintf_s(stmp_p, sizeof stmp_p," AND a.drate_ym = '%s' AND (a.iclass = '%s' OR a.iclass = 'A') AND a.dbegin <= '%s' "
			                                " AND (a.dend >= '%s' OR a.dend is null OR a.dend = ' ') "
			                                " AND (a.dexpire is null OR a.dexpire = ' ' OR dexpire >= today)",drate_ym,fcar_class_p,dpolicy,dpolicy);
		}
		else 
		{
			sprintf_s(stmp_p, sizeof stmp_p," AND a.drate_ym = '%s' AND (a.iclass = '%s' OR a.iclass = 'A') AND a.dbegin <= today "
			                                " AND (a.dend >= today OR a.dend is null OR a.dend = ' ') "
			                                " AND (a.dexpire is null OR a.dexpire = ' ' OR dexpire >= today)",drate_ym,fcar_class_p);	
		}
		
		sprintf_s(stmt_prov, sizeof stmt_prov,"SELECT a.iins_type,b.fins_grp,trim(nvl(a.provision,' '))||';' , "
		                                      "       nvl(c.cmp_provision,' '),"
		                                      "       nvl(c.com_provision,' '),"
		                                      "       nvl(c.iins_provision1,' '),"
		                                      "       nvl(c.iins_provision2,' '),"
		                                      "       nvl(c.iins_provision3,' '),"
		                                      "       b.qserial "
		                                      "  FROM %s a,insurance_type b,outer ca_prov_irate c"
		                                      " WHERE a.iins_type = b.iins_type AND a.iins_type = c.iins_type "
		                                      "   AND a.drate_ym = c.irate AND (c.iclass = '%s' OR c.iclass = 'A') AND a.ipolicy= '%s'" ,tableInsType,fcar_class_p,ipolicy);
		
		printf("stmt_prov[%s]\n",stmt_prov);
		cnt_cmp = 0;
		cnt_com = 0;
		$PREPARE insprov FROM $stmt_prov;
		$DECLARE insprov_cur CURSOR FOR insprov;
		$OPEN    insprov_cur;
		for(;;)
		{
			$FETCH insprov_cur INTO $iins_type_p,$fins_grp,$iins_provision_add,
			                        $cmp_provision,$com_provision,$iins_provision1,$iins_provision2,$iins_provision3,$qserial_p;
			if (SQLCODE == SQLNOTFOUND) break;
			strcpy(iins_provision_add,trim(iins_provision_add));
			strcpy(iins_type_p,trim(iins_type_p));
			strcpy(cmp_provision,trim(cmp_provision));
			strcpy(com_provision,trim(com_provision));
			strcpy(iins_provision1,trim(iins_provision1));
			strcpy(iins_provision2,trim(iins_provision2));
			strcpy(iins_provision3,trim(iins_provision3));
	
		    cnt_prov = 0;
		    $SELECT count(*) INTO $cnt_prov FROM ca_prov_irate WHERE iins_type = $iins_type_p AND irate = $drate_ym AND (iclass = $fcar_class_p OR iclass = 'A') ;
				
		    printf("cnt_prov[%d] cnt_prov_chk[%d] ipolicy[%s]\n",cnt_prov,cnt_prov_chk,ipolicy);
		    if (cnt_prov == 0) 
		    {
				printf("�O�渹�G%s\t�ӶO�v���I�صL�]�w��������!\t�O�v[%s]�I�إN��[%s]\n",ipolicy,drate_ym,iins_type_p);
				return 1;
		    }
			
			/*���[����*/
		    sprintf_s(stmt_cu, sizeof stmt_cu,"select trim(iprovision)||';',iprovision from ca_provision_main where iprovision not in ('C','E')");
		    printf("stmt_cu[%s]\n",stmt_cu);
		    $PREPARE ins_cu FROM $stmt_cu;
		    $DECLARE ins_cucode CURSOR FOR ins_cu;	 
		    $OPEN    ins_cucode;
		    for(;;)
		    {
		        $FETCH ins_cucode INTO $iprovision_add,$nprovision_add;
				strcpy(iprovision_add,trim(iprovision_add));
				strcpy(nprovision_add,trim(nprovision_add));
				if (SQLCODE == SQLNOTFOUND) break; 
				printf("iins_provision_add[%s] iprovision_add[%s] nprovision_add[%s]\n",iins_provision_add,iprovision_add,nprovision_add);
				if(strstr(iins_provision_add,iprovision_add) != NULL)
				{
				    printf("--IN\n");
				    strcpy(nprovision_add,trim(nprovision_add));
				    printf("--iprovision_add[%s]\n",iprovision_add);
				    printf("--nprovision_add[%s]\n",nprovision_add);
	
				    if (strcmp(iprovision_add,"P;") ==0 || strcmp(iprovision_add,"Q;") ==0 || strcmp(iprovision_add,"M;") ==0 || strcmp(iprovision_add,"Y;") ==0)
				    {
				        /* �w��D�I01�B05�B09�B11�B181�P�_����P�BQ�BM���� */
				        /* 1130827011_C04_�s�W�s�t��W�B���[����(Y)(�L��) */
						if (strcmp(iins_type,"01") == 0  || strcmp(iins_type,"05") == 0  || strcmp(iins_type,"09") == 0  || strcmp(iins_type,"11") == 0  || strcmp(iins_type,"181") == 0 || 
						    strcmp(iins_type,"201") == 0 || strcmp(iins_type,"205") == 0 || strcmp(iins_type,"209") == 0 || strcmp(iins_type,"211") == 0 || strcmp(iins_type,"198") == 0)
						{
						    $INSERT INTO Pro_tmp (ipolicy,iprovision,qserial) VALUES($ipolicy,$nprovision_add,100);
						}
						else 
						    printf("Do Nothing \n");
				    }
				    else if (strcmp(iprovision_add,"V;") ==0)
				    {
				       	/* V���� 09�n�վ㬰V1  31�B32��V2 */
				       	if (strcmp(iins_type,"09") == 0 || strcmp(iins_type,"209") == 0) strcpy(nprovision_add,"V1");
				       	else if (strcmp(iins_type,"31") == 0 || strcmp(iins_type,"32") == 0 || strcmp(iins_type,"231") == 0 || strcmp(iins_type,"232") == 0) strcpy(nprovision_add,"V2");
				       	$INSERT INTO Pro_tmp (ipolicy,iprovision,qserial) VALUES($ipolicy,$nprovision_add,100);
				    }
				    else 
				       	$INSERT INTO Pro_tmp (ipolicy,iprovision,qserial) VALUES($ipolicy,$nprovision_add,100);
				    
				    printf("iins_type[%s] nprovision_add[%s] \n",iins_type,nprovision_add);
				}
		    }	
		    $CLOSE ins_cucode;
		    $FREE  ins_cucode;
		    
			/*��ӱ���*/	
		    if(strlen(cmp_provision) != 0)
		    {
		        $INSERT INTO Cmp_tmp (ipolicy,iprovision,qserial) VALUES($ipolicy,$cmp_provision,1);
				cnt_cmp++;
		    }
		    /*�@�P����*/
		    if(strlen(com_provision) != 0)
		    {
				$INSERT INTO Com_tmp (ipolicy,iprovision,qserial) VALUES($ipolicy,$com_provision,1);
				cnt_com++;
		    }
		    /*���ڤ@*/
		    if(strlen(iins_provision1) != 0 )
		        $INSERT INTO Pro_tmp (ipolicy,iprovision,qserial) VALUES($ipolicy,$iins_provision1,$qserial_p);
		    /*���ڤG*/
		    if(strlen(iins_provision2) != 0 )
				$INSERT INTO Pro_tmp (ipolicy,iprovision,qserial) VALUES($ipolicy,$iins_provision2,$qserial_p);
		    /*���ڤT*/
		    if(strlen(iins_provision3) != 0 )
				$INSERT INTO Pro_tmp (ipolicy,iprovision,qserial) VALUES($ipolicy,$iins_provision3,$qserial_p);  
		    
		    printf("iins_provision_add[%s] cmp_provision[%s] com_provision[%s] iins_provision1[%s] iins_provision2[%s] iins_provision3[%s] \n",
			        iins_provision_add,cmp_provision,com_provision,iins_provision1,iins_provision2,iins_provision3);   
		}
		$CLOSE insprov_cur;
	    $FREE  insprov_cur;
	
	    /*��ӱ���*/
		iprovision1[0] = '\0';
		drate1[0] = '\0';
		iclass1[0] = '\0';
		dbegin1[0] = '\0';
		dbegin00[0] = '\0';
		icnt_cond=1;
	
		cnt_cmp2 = 0;
		sprintf_s(stmt_cmp, sizeof stmt_cmp,"SELECT unique a.iprovision,a.drate_ym,a.iclass,a.dbegin,max(b.qserial),count(*)"
		                 "  FROM ca_provision a, Cmp_tmp b"
		                 " WHERE a.iprovision = b.iprovision "
		                 "   AND b.ipolicy= '%s' %s"
		                 " GROUP BY 1,2,3,4"
		                 " ORDER BY 5,1" ,ipolicy,stmp_p);
		$PREPARE cp FROM $stmt_cmp;
		printf("stmt_cmp[%s]",stmt_cmp);
		$DECLARE cmp_cur CURSOR FOR cp; 
		$OPEN    cmp_cur;
		for(;;)
		{
			iprovision1[0] = '\0';
			drate1[0] = '\0';
			iclass1[0] = '\0';
			dbegin00[0] = '\0';
			icondition[0] = '\0';
	
			$FETCH cmp_cur INTO $iprovision1,$drate1,$iclass1,$dbegin,$cnt_cmp2;
			printf("--Cmp_tmp iprovision1[%s] drate1[%s] iclass1[%s] dbegin[%s]\n",iprovision1,drate1,iclass1,dbegin);
			if (SQLCODE == SQLNOTFOUND) break;
			strcpy(dbegin0,cm_from_infdate_100(dbegin));
			cm_char_split_3ymd(dbegin0,dbegin0_yy,dbegin0_mm,dbegin0_dd);
			printf("--Cmp_tmp dbegin0[%s] dbegin0_yy[%s]dbegin0_mm[%s]dbegin0_dd[%s] \n",dbegin0,dbegin0_yy,dbegin0_mm,dbegin0_dd);
			sprintf_s(dbegin00, sizeof dbegin00,"%s%s%s",dbegin0_yy,dbegin0_mm,dbegin0_dd);
			printf("--Cmp_tmp dbegin0[%s] dbegin00[%s] \n",dbegin0,dbegin00);
			strcpy(iprovision1,trim(iprovision1));
			strcpy(drate1,trim(drate1));
			strcpy(iclass1,trim(iclass1));
			strcpy(dbegin00,trim(dbegin00));
			printf("--Cmp_tmp iprovision1[%s] drate1[%s] iclass1[%s] dbegin00[%s]\n",iprovision1,drate1,iclass1,dbegin00);
			sprintf_s(icondition, sizeof icondition,"%s_%s_%s_%s",iprovision1,drate1,iclass1,dbegin00);
			$INSERT INTO condition VALUES ($icondition,$icnt_cond);
			icnt_cond++;
		}
		$CLOSE cmp_cur;
		$FREE  cmp_cur;
		
		/*�@�P����*/
		cnt_com2 = 0;
		sprintf_s(stmt_com, sizeof stmt_com,"SELECT unique a.iprovision,a.drate_ym,a.iclass,a.dbegin,max(b.qserial),count(*)"
		                 "  FROM ca_provision a, Com_tmp b"
		                 " WHERE a.iprovision = b.iprovision "
		                 "   AND b.ipolicy= '%s' %s"
		                 " GROUP BY 1,2,3,4"
		                 " ORDER BY 5,1" ,ipolicy,stmp_p);
		$PREPARE co FROM $stmt_com;
		printf("stmt_com[%s]",stmt_com);
		$DECLARE com_cur CURSOR FOR co; 
		$OPEN    com_cur;
		for(;;)
		{
			iprovision1[0] = '\0';
			drate1[0] = '\0';
			iclass1[0] = '\0';
			dbegin00[0] = '\0';
			icondition[0] = '\0';
			
			$FETCH com_cur INTO $iprovision1,$drate1,$iclass1,$dbegin,$cnt_com2;
			
			if (SQLCODE == SQLNOTFOUND) break;
			strcpy(dbegin0,cm_from_infdate_100(dbegin));
			cm_char_split_3ymd(dbegin0,dbegin0_yy,dbegin0_mm,dbegin0_dd);
			sprintf_s(dbegin00, sizeof dbegin00,"%s%s%s",dbegin0_yy,dbegin0_mm,dbegin0_dd);
			strcpy(iprovision1,trim(iprovision1));
			strcpy(drate1,trim(drate1));
			strcpy(iclass1,trim(iclass1));
			strcpy(dbegin00,trim(dbegin00));
			printf("--Com_tmp iprovision1[%s] drate1[%s] iclass1[%s] dbegin00[%s]\n",iprovision1,drate1,iclass1,dbegin00);
			sprintf_s(icondition, sizeof icondition,"%s_%s_%s_%s",iprovision1,drate1,iclass1,dbegin00);
			$INSERT INTO condition VALUES ($icondition,$icnt_cond);
			icnt_cond++;
		}
		$CLOSE com_cur;
		$FREE  com_cur;
	
	    /*���ڤ@�B���ڤG�B���ڤT�B���[����*/
		cnt_pro_cmp = 0;
		$SELECT count(UNIQUE iprovision) INTO $cnt_pro_cmp FROM Pro_tmp WHERE ipolicy = $sIpolicy;
		cnt_pro_cmp2 = 0;
			  
		sprintf_s(stmt_pro, sizeof stmt_pro,
		                   "SELECT unique a.iprovision,a.drate_ym,a.iclass,a.dbegin,max(b.qserial) "
		                   "  FROM ca_provision a, Pro_tmp b"
		                   " WHERE a.iprovision = b.iprovision "
		                   "   AND b.ipolicy= '%s' %s "
		                   " GROUP BY 1,2,3,4"
		                   " ORDER BY 5,1" ,ipolicy,stmp_p);
		$PREPARE pr FROM $stmt_pro;
		$DECLARE pr_cur CURSOR FOR pr;
		$OPEN    pr_cur;
		for(;;)
		{
			iprovision1[0] = '\0';
			drate1[0] = '\0';
			iclass1[0] = '\0';
			dbegin00[0] = '\0';
			icondition[0] = '\0';
			
			$FETCH pr_cur INTO $iprovision1,$drate1,$iclass1,$dbegin;
			
			if (SQLCODE == SQLNOTFOUND) break; 
			cnt_pro_cmp2++;
			strcpy(dbegin0,cm_from_infdate_100(dbegin));
			cm_char_split_3ymd(dbegin0,dbegin0_yy,dbegin0_mm,dbegin0_dd);
			sprintf_s(dbegin00, sizeof dbegin00,"%s%s%s",dbegin0_yy,dbegin0_mm,dbegin0_dd);
			strcpy(iprovision1,trim(iprovision1));
			strcpy(drate1,trim(drate1));
			strcpy(iclass1,trim(iclass1));
			strcpy(dbegin00,trim(dbegin00));
			printf("--Pro_tmp iprovision1[%s] drate1[%s] iclass1[%s] dbegin00[%s]\n",iprovision1,drate1,iclass1,dbegin00);
			sprintf_s(icondition, sizeof icondition,"%s_%s_%s_%s",iprovision1,drate1,iclass1,dbegin00);
			$INSERT INTO condition VALUES ($icondition,$icnt_cond);
			icnt_cond++;
		}
		$CLOSE pr_cur;
		$FREE  pr_cur;

		/* �q�l�O���ˮ����.nplyidx3 */
		nplyidx3[0] = '\0';
		if (feply2[0] == '1')
		{
			sprintf(stmt_pro,"SELECT unique "
			                 "       (SELECT narticle FROM ca_provision WHERE iprovision = a.iprovision "
			                 "                                            AND drate_ym = a.drate_ym AND iclass = a.iclass AND dbegin = a.dbegin AND iarticle = 'N')" 
			                 "       ||'|'|| " 
			                 "       (SELECT narticle FROM ca_provision WHERE iprovision = a.iprovision "
			                 "                                            AND drate_ym = a.drate_ym AND iclass = a.iclass AND dbegin = a.dbegin AND iarticle = 'P')"
			                 "       ||'#' " 
			                 "  FROM ca_provision a, Pro_tmp b"
			                 " WHERE a.iprovision = b.iprovision "
			                 "   AND b.ipolicy= '%s' %s " ,ipolicy,stmp_p);
			$PREPARE pr_ncontet FROM $stmt_pro;
			$DECLARE pr_ncontet_cur CURSOR FOR pr_ncontet;
			$OPEN    pr_ncontet_cur;
			for(;;)
			{
				$FETCH pr_ncontet_cur INTO $nplyidx3_tmp;
				if (SQLCODE == SQLNOTFOUND) break;
				strcpy(nplyidx3_tmp,trim(nplyidx3_tmp));
				nplyidx3_tmp2[0] = '\0';
				$SELECT first 1 replace($nplyidx3_tmp,',','') INTO $nplyidx3_tmp2 FROM systables;
				strcpy(nplyidx3_tmp2,trim(nplyidx3_tmp2));
				strcat(nplyidx3,nplyidx3_tmp2);
			}
			$CLOSE pr_ncontet_cur;
			$FREE  pr_ncontet_cur;

			/* �h�����ڤ��r�� */
			nplyidx3[strlen(nplyidx3) - 1 ] = '\0';
		}
	}
	return M_CM_OK;

errexit:
    return SQLCODE;
}
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------*/
/*--------------------------------------------------------------------*/
/* sIkind = 1 => �L�X�u�f���B, sIkind = 2 => ���L�u�f���B             */
/*--------------------------------------------------------------------*/
long get_ply_data(sIpolicy,sIkind)
char *sIpolicy;
char *sIkind;
{
    $int  i,line_no;
    int   j;
    int   str_length;
    char  *ilocation;
    char  s_qcylinder_tail[4];
    $char stmt[2000], sStmt[512];
    char  datestr[40];
    char  ikind[2];
    $char  tmp_iins_scope[3];
    $char iins_scope_56[2];
    $int   daily_pay;
    char   v_sMsg[512];
    long   rtncode, lPremSum;
    char   sColumn[21], sTable[21], sDbname[21];
    $char   contain_coverage[120],prt_coverage[120];
    $long    insurance_cover_count;
    char   *ptr;
    $char  tmp3132[13], sFcal_way[2];
    $char  tmpfield2[41];
    char   amt_print[11];
    long   tmp_cover1=0, tmp_cover2=0, tmp_cover3=0;
    long   deduct_prem=0;
    char   sNinstype2[31];
    $char   ins31_provision[11];
    $char  stmp_ntype1[17], stmp_ntype2[17],stmp_mpad1[15], stmp_mpad2[15];
    char   FullDBName[40];
    $char sIpolicy1[21]=" ",sIpolicy2[21]=" ";
    $double mdisc;
    $char nins_type2[50],provision2[22];
    $int nins_type_len = 0;
    $char nins_type_split[17];

    printf("start to get information...\n");

    ins31_provision[0]='\0';
    strcpy(ipolicy,sIpolicy);
    strcpy(ikind, sIkind);
    str_length = 0;
    tmpDrate[0] = '\0';
    daily_pay = 0;

    printf("111111111111111fcar1[%s] fcar_class[%s]\n",fcar1,fcar_class);
	
	/*1080720003_SC1_�ק�O��C�L2A�B2B���ئۥ�/��~����(�t�ȥ��B�q�l�B�e�~) 2019.08.07 by 071004*/
	if(strcmp(icar_type_ori,"4A")==0 || strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
	{
		strcpy(fcar2,"V");
	}
	else
	{
		if (fcar_class[0]=='1') strcpy(fcar1,"V");
		else if (fcar_class[0]=='2') strcpy(fcar2,"V");    	
	}
	
	strcpy(s_r_dbegin,cm_cdate_str_100(r_dbegin));
	strcpy(s_r_dend,cm_cdate_str_100(r_dend));

    /* ���[�N�B���A�� */
    if (strcmp(trim(fcard_class),"2")==0)
    {
        if (equip_cmp(nequipment,"15") == TRUE)
        {
            add_mplace_01_flag = 1;
        }
        else
        {
            add_mplace_01_flag = 0;
        }

        if (equip_cmp(nequipment,"16") == TRUE)
        {
            add_mplace_11_flag = 1;
        }
        else
        {
            add_mplace_11_flag = 0;
        }
    }

    if (ipolicy[0]!=' ' && ipolicy[0]!='\0') 
        strcpy(ply1,CompanyId);
    else 
        strcpy(ply1,"  ");

    strncat(ply1,ipolicy,3);
    strncpy(ply2,&ipolicy[3],10); ply2[10]='\0';

    if(ilast_ply[0]!=' ' && ilast_ply[0]!='\0')
        strcpy(last_ply1,CompanyId);
    else
    {
        memset(ilast_ply,0,sizeof(ilast_ply));
        strcpy(last_ply1,"  ");
    }

    strncat(last_ply1,ilast_ply,3);
    strncpy(last_ply2,&ilast_ply[3],10);
    last_ply2[10] = '\0';

    if(apayment[0]=='\0' || apayment[0]==' ') 
        strcpy(apayment,aassured);

    rtoday(&Today);
    strcpy(s_dpolicy,cm_cdate_str_100(Today));
    cm_split_ymd_100(s_dpolicy,yy5,mm5,dd5);

    strcpy(datestr,cm_cdate_str_100(dentry));
    cm_split_ymd_100(datestr,yy6,mm6,dd6);

    /* �e�~��O��t�Τ� = ñ��� */
    if (strncmp(sIpolicyB_type,"2",1) == 0 || strncmp(sIpolicyB_type,"3",1) == 0)
    {
	    strcpy(yy7,yy5);   /* �C�L�� = �t�Τ� */
		strcpy(mm7,mm5);
		strcpy(dd7,dd5);
		 
	    strcpy(datestr,cm_from_infdate_100(dpolicy));
	    cm_split_ymd_100(datestr,yy6,mm6,dd6);
	   
	    strcpy(yy5,yy6);   /* �t�Τ� = ñ��� */
	    strcpy(mm5,mm6);
	    strcpy(dd5,dd6);
	   
	    printf("---1201---datestr[%s]yy6[%s]mm6[%s]dd6[%s]\n",datestr,yy6,mm6,dd6);
	    printf("---1202---datestr[%s]yy5[%s]mm5[%s]dd5[%s]\n",datestr,yy5,mm5,dd5);
    }

    strcpy(datestr,cm_cdate_str_100(dply_begin));
    i_begin = cm_ymd_cdate(datestr);
    cm_split_ymd_100(datestr,yy1,mm1,dd1);

    strcpy(datestr,cm_cdate_str_100(dply_end));
    i_end = cm_ymd_cdate(datestr);
    cm_split_ymd_100(datestr,yy2,mm2,dd2);
    
    if(strncmp(ipolicy+5,"VW",2)==0)
    {
	    strcpy(datestr,cm_cdate_str_100(dply_begin_ext));
	    i_begin = cm_ymd_cdate(datestr);
	    cm_split_ymd_100(datestr,yyext1,mmext1,ddext1);
	
	    strcpy(datestr,cm_cdate_str_100(dply_end_ext));
	    i_end = cm_ymd_cdate(datestr);
	    cm_split_ymd_100(datestr,yyext2,mmext2,ddext2);
	    
	    /*strcpy(datestr,cm_from_infdate_100(Today));
		cm_split_ymd_100(datestr,dpoyy,dpomm,dpodd);*/
	}

    cm_long_split_3ymd(dissue,is_yy,is_mm,is_dd);   /* Date(long)�ন����~�B��B��(yyy,mm,dd) */

    sprintf_s(s_qcylinder, sizeof s_qcylinder, "%5.2f", qcylinder);   /*1080902001_SC4_�Ʈ�q�X�ܤp���I2��(�t�Ҧ������B�X��B�����B���p�d�ߡB���{��)*/
    strcpy(s_qcylinder,trim(s_qcylinder) );
    
    /*�Ʈ�q*/ 
    if (qpt!=0)  sprintf_s(s_qpt, sizeof s_qpt, "%5.1f", qpt);
    else  strcpy(s_qpt," ");

    if (qpt!=0)
    {
        if (fpt[0] == 'P')  strcpy(s_fpt, "�H");
        else if(fpt[0] == 'T')  strcpy(s_fpt, "��");
        s_fpt[2]=0;
    }
    else strcpy(s_fpt," ");

    /* �Ӹ�B�n */
    if (strncmp(sProtectData,"0",1) == 0)
    {
        printf("----------ProtectData = 0 ----------\n");
    	if( fassured[0] == '1' || fassured[0] == '3' || fassured[0] == '5' )
    	{
            cm_long_split_3ymd( dbirth, by, bm, bd);   /* Date(long)�ন����~�B��B��(yyy,mm,dd) */
        }
        else
        {
            strcpy( by, " ");
            strcpy( bm, " ");
            strcpy( bd, " ");
        }
        
        if( fapplicant[0] == '1' || fapplicant[0] == '3' || fapplicant[0] == '5' )
    	{
            cm_long_split_3ymd( dbirth_appl, by_appl, bm_appl, bd_appl);   /* Date(long)�ন����~�B��B��(yyy,mm,dd) */
        }
        else
        {
            strcpy( by_appl, " ");
            strcpy( bm_appl, " ");
            strcpy( bd_appl, " ");
        }
    }
    else
    {
    	printf("-----------ProtectData = 1 ----------\n");
    	if( fassured[0] == '1' || fassured[0] == '3' || fassured[0] == '5' )
    	{
    	    strcpy(sIlicense,substring(ilicense,1,4));
    	    strcat(sIlicense,"****");
    	    strcat(sIlicense,substring(ilicense,9,2));
			
			if((itel[0]==' ') || (itel[0]=='\0'))
			{
			    strcpy(sItel," ");
			}
			else
			{
				strcpy(sItel,substring(itel,1,3));
				strcat(sItel,"XXXX");
				strcat(sItel,substring(itel,8,13));
			}
    	}
    	else
    	{
            strcpy(sIlicense,ilicense);
    	    strcpy(sItel,itel);
    	}
    	
    	if( fassured[0] == '1' || fassured[0] == '3' || fassured[0] == '5' )
    	{
            cm_long_split_3ymd( dbirth, by, bm, bd);   /* Date(long)�ন����~�B��B��(yyy,mm,dd) */
            strcpy( by, "***");
            strcpy( bd, "**");
     	}
     	else
     	{
    	    strcpy( by, " ");
            strcpy( bm, " ");
            strcpy( bd, " ");
        }
        
        if( fapplicant[0] == '1' || fapplicant[0] == '3' || fapplicant[0] == '5' )
    	{
    		strcpy(sIapplicant,substring(iapplicant,1,4));
    	    strcat(sIapplicant,"****");
    	    strcat(sIapplicant,substring(iapplicant,9,2));
    		
            cm_long_split_3ymd( dbirth_appl, by_appl, bm_appl, bd_appl);   /* Date(long)�ন����~�B��B��(yyy,mm,dd) */
            strcpy( by_appl, "***");
            strcpy( bd_appl, "**");
        }
        else
        {
            strcpy( by_appl, " ");
            strcpy( bm_appl, " ");
            strcpy( bd_appl, " ");
        }
    }

    if (fsex[0]=='1')  strcpy(sex1,"�k");
    else if (fsex[0]=='2')  strcpy(sex1,"�k");
    
    if (fsex_appl[0]=='1')  strcpy(sex1_appl,"�k");
    else if (fsex_appl[0]=='2')  strcpy(sex1_appl,"�k");
    
    if (fmarriage[0]=='1')  strcpy(marriage1,"�w�B");
    else if (fmarriage[0]=='2')  strcpy(marriage1,"���B");

	/* �h���u�ݨ���B�ѵs�B�d��(���ϥ�) */
	/*
    if (pdmg_align==0)  s_dmg_align[0]='\0';
    else  sprintf_s(s_dmg_align, sizeof s_dmg_align, "%d", pdmg_align);

    if (pbrg_align==0)  s_brg_align[0]='\0';
    else  sprintf_s(s_brg_align, sizeof s_brg_align, "%d", pbrg_align);

    if (plia_align==0)  s_lia_align[0]='\0';
    else  sprintf_s(s_lia_align, sizeof s_lia_align, "%d", plia_align);
	*/
	
	/* ���d�ߴګY�� */
    sprintf_s(s_lia_acc, sizeof s_lia_acc,"%6.2f",plia_acc);
    /* ����ߴګY�� */
    sprintf_s(s_dmg_acc, sizeof s_dmg_acc,"%6.2f",pdmg_acc);
    /* �������l�ߴګY��(�䥦���l�ߴګY��) */
    sprintf_s(s_unk_acc, sizeof s_unk_acc,"%6.2f",punknown_acc);
    strcpy(s_unk_acc,trim(s_unk_acc));

    $WHENEVER SQLERROR GOTO errexit;
    
    strcpy( sDbname, Full_DBName);
    strcpy( sTable, "ply_ins_cover");
    strcpy( sColumn, "ipolicy");
	
    IcurrPlyInsCover=IfirstPlyInsCover=IlastPlyInsCover=NULL;  /* set init pointer to NULL */
    #ifdef CA_CONS
        IfirstPlyInsCover = get_ply_ins_cover( sDbname, sTable, sColumn, ipolicy, &rtncode, v_sMsg);
        if( rtncode != M_CM_OK)
            return rtncode;
    #endif

    strcpy(tableInsType, trim(tableInsType));
    strcpy(tablePaPly, trim(tablePaPly));
    strcpy(tableAssured, trim(tableAssured));
    printf("***** Get_data table[%s][%s] *****\n", tableInsType, tablePaPly);

    /********************/
    /*                  */
    /* �v�I�رN���Ū�X */
    /*                  */
    /********************/
    sprintf_s(stmt, sizeof stmt,"SELECT iins_type, minjured_cover, mdeath_cover,\
                         mdamage_cover, mdeduct, mins_premium, qserial,\
                         pcommission,pagent,mdiscount,drate_ym,mprem,qday,trim(nvl(provision,' '))||';' \
                    FROM %s \
                   WHERE (ipolicy = ?) ORDER BY qserial",tableInsType);
    $PREPARE CUR8 FROM $stmt;
    $DECLARE curh CURSOR FOR CUR8;
    $OPEN curh USING $ipolicy;

    for(;;)
    {
        $FETCH curh INTO $iins_type,$injured_cover,$death_cover, $damage_cover, $deduct, $ins_premium, $qserial,
                         $pcommission, $pagent, $ins_mdiscount, $drate_ym, $old_premium, $qday, $provision;
        if (SQLCODE == SQLNOTFOUND) break;

        lPremSum = 0;
        strcpy(cover_print,"");
        strcpy(amt_print,"");
        strcpy(str_cover1,"");
        strcpy(str_cover2,"");
        strcpy(str_cover3,"");
        strcpy(str_cover4,"");
        strcpy(f980401,"");
        strcpy(f52535524,"");
        strcpy(f626364,"");
        strcpy(f86,"");
        strcpy(iins_type, rtrim(iins_type));

        if (tmpDrate[0] == '\0') strcpy(tmpDrate, drate_ym);
        
        /* car9803301 �P�_�ϥηs�¶O�v(�s�O�v2009/04/01�W�u),�L�X���P���֭�帹 */
        /* �u�n���@�I�بϥηs�O�v,�֭�帹�K�ϥηs�� */
        $SELECT case when drate >= date('04/01/2009') then '1' else '0' end
           INTO $f980401
           FROM ca_rate_date
          WHERE icode  = $drate_ym
            AND itable = 'cm_extra_charge';
        if (SQLCODE == SQLNOTFOUND)  
            return M_CA_EXTRA_CHARGE_DRATE;

        if( f980401[0] == '1')
        {
            strcpy(flag980401,f980401);
        }
        /* end of car9803301 */

        /* �Y�O�O�B���s,�����u���O�O,�O��W���C�L,�B�O�O�]�n���� */
        /* �Y�O�B=,�O�O!= 0, �������I�ذh�O, �����C�L,�H���O�O�P�b�W�ƬۦP
           ���O�B�C�L�i�h�O�j�r�ˡC add by sylvia 101.10.08 (1010928006_C1) */
        if (damage_cover == 0)
        {
            if ((equip_cmp(nequipment,"5") == TRUE) &&
        	   ((strcmp(trim(iins_type),"17") == 0) || (strcmp(trim(iins_type),"19") == 0)))
            {
                /* �U�L�@��, 17��19���C�L */
            }
            else
            {
				deduct_prem = deduct_prem + ins_premium;
				
				if (ins_premium != 0)
				{
					$SELECT nins_type into $nins_type FROM insurance_type
					  WHERE iins_type = $iins_type;
					
					strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
					insert_prt_table(ipolicy,iins_type,nins_type," "," ","�i�h�O�j"," ",str_ins_premium,ins_premium);
				}
				continue;
			}
        }

        /* SELECT�O�I����,�D�n���I����,�O�I���B,�ۭt�B�C�L���� */
        $SELECT nins_type,edomain2,nvl(qcoverage,0),nvl(cover_print,' '),
                fdeduct,nvl(deduct_print,' '), fcal_way
           INTO $nins_type,$main_paid,$qcoverage,$cover_print,
                $fdeduct,$deduct_print, $sFcal_way
           FROM insurance_type
          WHERE iins_type = $iins_type;

        strcpy(deduct_print, rtrim(deduct_print));
        printf("iins_type=[%s]sFcal_way=[%s]\n",iins_type,sFcal_way);

        /*======================================================================*/
        /*�I��56 �������B���P����I�� 103.11.11*/
        /*�I��136 104.04.22 */
        /*166�I�حn�L�W�U (1090921003_SC1) */
        if (strcmp(trim(iins_type),"56") == 0 || strcmp(trim(iins_type),"136") == 0 || strcmp(trim(iins_type),"166") == 0 || strcmp(trim(iins_type),"266") == 0)
        {
            if (strcmp(trim(iins_type),"56") == 0)      strcpy(sNassured_56_136,"56 �Q�O�I�H:");
     	    else if(strcmp(trim(iins_type),"136") == 0) strcpy(sNassured_56_136,"136�Q�O�I�H:");
     	    else if(strcmp(trim(iins_type),"166") == 0) strcpy(sNassured_56_136,"166�Q�O�I�H:");    
            else                                        strcpy(sNassured_56_136,"266�Q�O�I�H:"); 
     	 	
            strcpy(Full_DBName,get_car_full_db(ipolicy));
            sprintf_s(stmt, sizeof stmt,"SELECT distinct iins_scope \
                            FROM %s \
                           WHERE ipolicy = '%s' \
                             AND iins_type = '%s' \
                             AND (nvl(fedr_status,'') != '1' \
                             AND  nvl(fedr_status,'') != '2' \
                             AND  nvl(fedr_status,'') != '3');",tablePaPly,ipolicy,iins_type);

			$PREPARE pa_ply_56_scope FROM $stmt;
			$DECLARE pa_ply_56_scope_cur CURSOR FOR pa_ply_56_scope;
			$OPEN    pa_ply_56_scope_cur;
			
			$FETCH pa_ply_56_scope_cur INTO $iins_scope_56;
			$CLOSE pa_ply_56_scope_cur;
			$FREE  pa_ply_56_scope_cur;

            if((strcmp(trim(iins_scope_56),"2")==0))
            {
            	qcoverage = 2; /* 56�I�ؤ������B���P����I�� */
                strcpy(cover_print,"���|�������B;���G����");
            }
            else if((strcmp(trim(iins_scope_56),"3")==0))
            {
            	qcoverage = 2; /* 56�I�ؤ������B���P����I�� */
                strcpy(cover_print,"�ˮ`�����й���I��;���G����");
            }
        }
		
		/* 1130510009_C06_�s�W�q�ʨ��M�ݰӫ~(�L��) */
        if ((strcmp(trim(iins_type),"24") == 0)  || (strcmp(trim(iins_type),"52") == 0)  ||
            (strcmp(trim(iins_type),"53") == 0)  || (strcmp(trim(iins_type),"55") == 0)  ||
            (strcmp(trim(iins_type),"135") == 0) || (strcmp(trim(iins_type),"255") == 0) ||
            (strcmp(trim(iins_type),"252") == 0) || (strcmp(trim(iins_type),"253") == 0))
        {
            /* �I��52,53,55,24 �O�v�ͮĤ� >- '04/06/2011', �A�ηs�� add by sylvia 100.03.29 (1000323008)*/
            if(strcmp(sFcal_way,"1") == 0)
            {
               $SELECT case when drate >= date('04/06/2011') then '1' else '0' end
                  INTO $f52535524
                  FROM ca_rate_date
                 WHERE icode  = $drate_ym
                   AND itable = 'ca_rate';
            }
            else
            {
               $SELECT case when drate >= date('04/06/2011') then '1' else '0' end
                  INTO $f52535524
                  FROM ca_rate_date
                 WHERE icode  = $drate_ym
                   AND itable = 'cover_vs_premium';
            }
            if (SQLCODE == SQLNOTFOUND)  
                return M_CA_EXTRA_CHARGE_DRATE;
            printf("drate_ym=[%s] f52535524=[%s]\n",drate_ym,f52535524);

            /* �I��52,53,55,24 �s�¦��t add by sylvia 100.03.29 */
            if (strcmp(f52535524,"0") == 0)
            {   /* �A���¨� �O�v�ͮĤ� < 04/06/2011 */
                printf("-------------- �A���¨� �O�v�ͮĤ� < 04/06/2011 ---------\n");
                if (strcmp(trim(iins_type),"24")==0)
                    strcpy(nins_type,"���s���v�T���ר��`�H���v�I");
                else if (strcmp(trim(iins_type),"52")==0)
                {
                    strcpy(nins_type,"���D�d���I");
                    qcoverage = 3; /* �¨3�ӫO�B--���,���`,�ƬG */
                    strcpy(cover_print,"�C�@�H���;�C�@�H���`;�C�@�N�~�ƬG���`�B");
                }
                else if (strcmp(trim(iins_type),"53")==0)
                {
                    qcoverage = 3; /* �¨3�ӫO�B--���,���`,�ƬG */
                    strcpy(cover_print,"�C�@�H���;�C�@�H���`;�C�@�N�~�ƬG���`�B");
                }
                else if (strcmp(trim(iins_type),"55")==0 || strcmp(trim(iins_type),"135")==0 || strcmp(trim(iins_type),"255")==0)
                {
                    qcoverage = 3; /* �¨3�ӫO�B--���,���`,�ƬG */
                    strcpy(cover_print,"�C�@�H���;�C�@�H���`�Υ���;�C�@�N�~�ƬG���`�B");
                }
            }
            else
            {   
            	/* �A�ηs�� �O�v�ͮĤ� >= 04/06/2011 (�̳]�w�ɦC�L) */
                printf("-------------- �A�ηs�� �O�v�ͮĤ� > 04/06/2011 ---------\n");
                /*  */
                if (strcmp(trim(iins_type),"52")==0 || strcmp(trim(iins_type),"252")==0)
                {
                    if (fcar_class[0] == '1')
                    {
                        strcpy(nins_type,"���D�d�����[����");
                    }
                    else
                    {
                        strcpy(nins_type,"�T�����D�d���O�I");
                    }
                }
            }
        }
        
        if ((strcmp(trim(iins_type),"62") == 0) || (strcmp(trim(iins_type),"63") == 0) ||
            (strcmp(trim(iins_type),"64") == 0) || (strcmp(trim(iins_type),"143") == 0))
        {
			/* �I��62,63,64 �O�v�ͮĤ� >= '12/01/2012', �A�ηs�� add by sylvia 101.12.25 (1011214002_C1)*/
			/* �s�W143�I�� add by �L�� 104.12.14 (1041203004_C2)*/   
			$SELECT case when drate >= date('12/01/2012') then '1' else '0' end
			   INTO $f626364
			   FROM ca_rate_date
			  WHERE icode  = $drate_ym
			    AND itable = 'cover_vs_premium';
			
			if (SQLCODE == SQLNOTFOUND)  
			    return M_CA_EXTRA_CHARGE_DRATE;
			printf("drate_ym=[%s] f626364=[%s]\n",drate_ym,f626364);
			
			if (strcmp(f626364,"0") == 0)
			{   
				/* �A���¨� �O�v�ͮĤ� < 12/01/2012 */
			    printf("-------------- �A���¨� �O�v�ͮĤ� < 12/01/2012 ---------\n");
			    if (strcmp(trim(iins_type),"62")==0)
			    {
			        qcoverage = 1; /* �¨�u��1�ӫO�B--�ƬG */
			        strcpy(cover_print," ");
			    }
			    else if (strcmp(trim(iins_type),"63")==0)
			    {
			        qcoverage = 1; /* �¨�u��1�ӫO�B--�ƬG */
			        strcpy(cover_print," ");
			    }
			    else if (strcmp(trim(iins_type),"64")==0)
			    {
			        qcoverage = 1; /* �¨�u��1�ӫO�B--�ƬG */
			        strcpy(cover_print," ");
			    }
			}
			else
			{   
				/* �A�ηs�� �O�v�ͮĤ� >= 12/01/2012 (�̳]�w�ɦC�L) */
			    printf("-------------- �A�ηs�� �O�v�ͮĤ� > 12/01/2012 ---------\n");
			    /* ��car108�]�w: 62,63,64�O�B��2��--��ˡB�ƬG, �O�B��r�̳]�w�ɳ]�w */
			}
        }
        
        /* �P�_�I��47 �O�v�ͮĤ� >= '03/01/2020', �I�ئW�٨̳]�w�ɦC�L*/
        /*            �O�v�ͮĤ� <  '03/01/2020', �I�ئW�٦C�L�u�����r�p�H�ˮ`�O�I�v*/
        /* 1081205009_SC4_�t�X47�I�رq�D�I�אּ���[�I�A�ק���s/E�O��/B2B/B2C�ˮ�(�Цb12�멳����)*/
        if (strcmp(trim(iins_type),"47") == 0 )
        {
			if (atoi(drate_ym) < 111)
			{   
			   /*�����C�L�u�����r�p�H�ˮ`�O�I�v*/
			   strcpy(nins_type,"�����r�p�H�ˮ`�O�I");
			}
			else
			{  
			   /* ��car108�]�w*/
			}
        }
        
        /* ��X�ۭt�B���C�L���e,fdeduct = 1�ɥN�����ۭt�B */
        printf("0110: �ۭt�B����[%s],deduct_print[%s]\n",fdeduct,deduct_print);
        if (strncmp(fdeduct,"1",1) == 0)
        {
            /* 86�I�اe�{�ۭt�B (1040525002_C1) */
            if (strcmp(trim(iins_type),"86") == 0)
            {
				$SELECT case when drate >= date('06/08/2015') then '1' else '0' end
				   INTO $f86
				   FROM ca_rate_date
				  WHERE icode  = $drate_ym
				    AND itable = 'cover_vs_premium';
				
				if (SQLCODE == SQLNOTFOUND)  
				    return M_CA_EXTRA_CHARGE_DRATE;
				
				strcpy(str_deduct,"");
				if (strcmp(trim(f86),"1") == 0)
				{
				    if (deduct != 0)
				    {
				        sprintf_s(deduct_print, sizeof deduct_print,"%d",deduct);
				        strcpy(str_deduct,deduct_print);
				        strcat(str_deduct,"%");
				    }
				    else
				    {
				        strcpy(str_deduct,"�L");
				    }
				}
				else
				{
				    strcpy(str_deduct,"�L");
				}
            }
            else
            {
				if ((strcmp(trim(deduct_print),"") == 0) ||(strcmp(trim(deduct_print),'\0') == 0))
				{
					sprintf_s(str_deduct, sizeof str_deduct,"%d",deduct);
					prn_deduct[0]=0;
					
					$SELECT prn_deduct
					   INTO $prn_deduct
					   FROM ca_dmg_mdeduct
					  WHERE icar_type=$icar_type
					    AND ideduct=$str_deduct;
					
					strcpy(str_deduct, trim(prn_deduct));
				}
				else
				{
					strcpy(str_deduct,deduct_print);
				}
            }
        }
        else
        {
        	strcpy(str_deduct,deduct_print);
        }

        /* �B�z�h�ӫO�B,���N�I�ؤ����O�B����";"�����j�Ÿ���} */
        printf("0120: qcoverage[%d],iins_type[%s]\n",qcoverage,iins_type);
        if (qcoverage > 1)
        {
            ptr = strtok(cover_print,";");
            while (ptr != NULL)
            {
                strcpy(prt_coverage,trim(ptr));
                $INSERT INTO tbl_coverage (ipolicy, contain1) VALUES ($ipolicy,$prt_coverage);
            	ptr = strtok(NULL,";");
            }
        }

		/* �I�ثO�B�B�ۭt�B�B�O�O�P�_ */
        printf("0130: ipolicy[%s][%s][%d][%d][%d][%d][%s]\n",ipolicy,iins_type,injured_cover,death_cover,damage_cover,ins_premium,prn_deduct);
        iins=atoi(iins_type);
		
		switch (iins)
		{
			/* 1130510009_C06_�s�W�q�ʨ��M�ݰӫ~(�L��) */
            case 1: case 5: case 9: case 8: case 86: case 110: case 120: case 122: case 125: case 126: case 152: case 153: case 161: case 162: case 201: case 205: case 209:
                
				strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
				if (iins == 120)
				{
				    sprintf_s(sStmt, sizeof sStmt, "SELECT sum(mins_premium) \
				                          FROM %s \
				                         WHERE ipolicy = '%s' \
				                           AND iins_type in ('120','121');", tableInsType, ipolicy);
				        $PREPARE plyInsType120_cur FROM $sStmt;
				        $EXECUTE plyInsType120_cur INTO $ins_premium;
				}
				else if (iins == 122)
				{
				    sprintf_s(sStmt, sizeof sStmt, "SELECT sum(mins_premium) \
				                          FROM %s \
				                         WHERE ipolicy = '%s' \
				                           AND iins_type in ('122','123');", tableInsType, ipolicy);
				        $PREPARE plyInsType122_cur FROM $sStmt;
				        $EXECUTE plyInsType122_cur INTO $ins_premium;
				}
				strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
        	break;

            case 85:
            
				strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcpy(str_cover2,rtrim(refmtamt(injured_cover,MILLIONTH)));
				strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
        	break;

            /* �����¦����s�A�������I�����{���]�w(137�B138�B139�B141�B142�I��) (1100311005_SC6)*/
            case 105: case 118:
            
	        	strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
	        	strcpy(str_cover2,rtrim(refmtamt(injured_cover,MILLIONTH)));
	        	if (iins == 118)
	        	{
	        	    sprintf_s(sStmt, sizeof sStmt, "SELECT sum(mins_premium) \
	                                      FROM %s \
	                                     WHERE ipolicy = '%s' \
	                                       AND iins_type in ('118','119');", tableInsType, ipolicy);
	                    $PREPARE plyInsType118_cur FROM $sStmt;
	                    $EXECUTE plyInsType118_cur INTO $ins_premium;
	        	}
                strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
        	break;

            case 2: case 3: case 7: case 150:
            
                strcpy(str_cover1," ");
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                if (iins == 150)
                {
                	strcpy(str_cover1,"�̱��ڬ��w");
                	sprintf_s(tmp_150151, sizeof tmp_150151,"���m����:%.1f�U",mcar_price);
            		ins_150151 = 1;
                }
			break;

            case 10: case 127:
            
        		strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
        	break;

            case 11: case 129: case 211:
            
                ins_11 = 1;
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcat(str_deduct,refmtamt(deduct,MILLIONTH));
                strcat(str_deduct,"%");
                strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
			break;

            case 12:
            
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcat(str_cover1,"��");
            break;

            case 28: case 128:
            
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcat(str_deduct,refmtamt(deduct,MILLIONTH));
                strcat(str_deduct,"%");
                strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
            break;

            case 14:
            
                ins_14=1;
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                if (equip_cmp(nequipment,"5") == TRUE)
                {
                    strcpy(nequipment_7h_14,"1");
                }
                else
                {
                    strcpy(nequipment_7h_14,"0");
                }
                strcpy(iofficer_7h_14,substring(iofficer,1,3));
                printf("0140: nequipment_7h_14:[%s]\n,iofficer_7h_14:[%s]",nequipment_7h_14,iofficer_7h_14);

                if ( strncmp(nequipment_7h_14,"1",1)==0 && strcmp(trim(dpolicy),"")!=0 &&
                   ( iofficer[0] == 'A' || iofficer[0] == 'B') )
                {
                    ins_14=2;
                    premium_7h_14 = ins_premium;
                    old_premium_7h_14 = old_premium;
                    mdiscount_7h_14 = ins_mdiscount;
                }
            break;

            /* �����¦����s�A�������I�����{���]�w(137�B138�B139�B141�B142�I��) (1100311005_SC6)*/
            case 15: case 16: case 66: case 67: case 106: case 119: case 121: case 123:
            
                strcpy(str_cover1,ltoa(qday));
                strcat(str_cover1,"��");
                if (iins != 119 && iins != 121 && iins != 123 )
                {
                    strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                }
                else
                {
                    strcpy(str_cover2,rtrim(refmtamt(injured_cover,MILLIONTH)));
                }
			break;

            case 17: case 130: case 151:
            
                ins_17=1;
                strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                /*�U�L�@���M�׸ɵo���L17�I��*/
                if (equip_cmp(nequipment,"5") == TRUE)
                {
                    strcpy(nequipment_17,"1");
                }
                else
                {
                    strcpy(nequipment_17,"0");
                }
                
                printf("0150: nequipment_17:[%s]\n",nequipment_17);
                if ((strcmp(nequipment_17,"1")==0 && strcmp(trim(dpolicy),"")!=0 &&
                   ( iofficer[0] == 'A' || iofficer[0] == 'B' || iofficer[0] == 'J')) ||
                    strncmp(sIpolicyB_type,"1",1) == 0 )
                {
                    /* ins_17=2���ɭԥN���ɵo�B���O17�I��,17�I�ؤ��e���C�L,�O�O�]�n� */
                    /* �M�ץ�O�� 17�I�ؤ��e���C�L,�O�O�]�n� */
                    bufa_ins_17 = 1;
                    ins_17=2;
                    premium_17 = ins_premium;
                    old_premium_17 = old_premium;
                    mdiscount_17 = ins_mdiscount;
                }
                
                if (iins == 151)
                {
                	strcpy(str_cover1,"�̱��ڬ��w");
                	sprintf_s(tmp_150151, sizeof tmp_150151,"���m����:%.1f�U",mcar_price);
            		ins_150151 = 1;
                }
			break;

            case 18:
            
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                strcpy(tmp_deduct,itoa(deduct));
                strncpy(deduct_30,&tmp_deduct[2],2);
                deduct_30[2] = '%';
                deduct_30[3] = '\0';
                strcpy(str_deduct,deduct_30);
                strcat(str_deduct,"(�_��");
                strncpy(deduct_30,tmp_deduct,2);
                deduct_30[2] = '%';
                deduct_30[3] = '\0';
                strcat(str_deduct,deduct_30);
                strcat(str_deduct,")");
            break;

            case 19:
            
                ins_19=1;
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                if (equip_cmp(nequipment,"5") == TRUE)
                {
                    strcpy(nequipment_7h_19,"1");
                }
                else
                {
                    strcpy(nequipment_7h_19,"0");
                }
                strcpy(iofficer_7h_19,substring(iofficer,1,3));
                printf("0190: nequipment_7h_19:[%s]\n,iofficer_7h_19:[%s]",nequipment_7h_19,iofficer_7h_19);

                if ( (strncmp(nequipment_7h_19,"1",1)==0 && strcmp(trim(dpolicy),"")!=0 &&
                   ( iofficer[0] == 'A' || iofficer[0] == 'B')) || strncmp(sIpolicyB_type,"1",1) == 0 )
				{
					/* �M�ץ�O�� 19�I�ؤ��e���C�L,�O�O�]�n� */
					bufa_ins_19 = 1;
					ins_19=2;
					premium_7h_19 = ins_premium;
					old_premium_7h_19 = old_premium;
					mdiscount_7h_19 = ins_mdiscount;
				}
			break;

            case 20: case 23: case 111:
				
				strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

            case 22: case 112:
            
				strcpy(str_cover1,refmtamt(damage_cover,MILLIONTH));
				strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

            case 24: case 88: case 26:
            
                if (fcomp_24 == 'Y' && strlen(str_ins_premium) != 0)
                {
                    strcpy(str_ins_premium,"�[�j ");
                    strcat(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                } 
                else 
                    strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

            case 29: case 124:
            
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

            case 30:
            
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcpy(tmp_deduct,itoa(deduct));
				strcpy(deduct_30,tmp_deduct);
						
				/*�T�{���[�O24*/    
				$SELECT iins_type
				   INTO $iins_type24
				   FROM ply_ins_type
				  WHERE ipolicy = $ipolicy
				    AND iins_type = '24';
				if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��24�I��*/
				{
				    flag24=0;
				}
				else
				{
				    flag24=1;
				}
				
				 /* 1110308005_SC4_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
				/*�T�{���[�O55*/
				$SELECT iins_type
				   INTO $iins_type55
				   FROM ply_ins_type
				  WHERE ipolicy = $ipolicy
				    AND iins_type = '55';
				if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
				{
				    flag55=0;
				}
				else
				{
				    flag55=1;
				}
				
				/*�T�{���[�O255*/
				$SELECT iins_type
				   INTO $iins_type55
				   FROM ply_ins_type
				  WHERE ipolicy = $ipolicy
				    AND iins_type = '255';
				if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��255�I��*/
				{
				    flag255=0;
				}
				else
				{
				    flag255=1;
				}
						
				/*�T�{���[�O49 or 117*/
				$SELECT iins_type
				   FROM ply_ins_type
				  WHERE ipolicy = $ipolicy
				    AND iins_type IN ('49','117');
				if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��49 or 117�I��*/
				{
				    flag49117=0;
				}
				else
				{
				    flag49117=1;
				}
				
				/* 1080311008_SC4_�ͮĤ��71�_����s�v�I */
				if((flag24 == 1) && (flag55 == 1) && (strncmp(fchk_24,"Y",1) == 0))
				{
				    if ((IsFcomp24(deduct_30)) && (IsFcomp55(deduct_30)))
				    {
				        strcpy(ps_dtl,str_ins_30_13);
				    }
				    else if (IsFcomp24(deduct_30))
				    {
						strcpy(ps_dtl,str_ins_30_21);
				    }
				    else if (IsFcomp55(deduct_30))
				    {
						strcpy(ps_dtl,str_ins_30_22);
				    }
				    else
				    {
				        strcpy(ps_dtl,str_ins_30_1 );
				    }
				}
				else if((flag24 == 1) && (strncmp(fchk_24,"Y",1) == 0))
				{
				    if (IsFcomp24(deduct_30))
				    {
				        strcpy(ps_dtl,str_ins_30_12);
				    }
				    else
				    {
						strcpy(ps_dtl,str_ins_30_2);
				    }		
				}
				else if((flag55 == 1) || (flag49117 == 1)) 
				{
				    if (IsFcomp55(deduct_30))
				    {
				        strcpy(ps_dtl,str_ins_30_11);
				    }
				    else
				    {
						strcpy(ps_dtl,str_ins_30_3);
				    }		
				}
				else if(flag255 == 1)
				{
					strcpy(ps_dtl,str_ins_30_4);
				}
						
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
                
            case 301:
            
            	/* 1110308005_SC4_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
				$SELECT iins_type
				   INTO $iins_type55
				   FROM ply_ins_type
				  WHERE ipolicy = $ipolicy
				    AND iins_type = '55';
				if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
				{
				    flag55=0;
				}
				else
				{
				    flag55=1;
				}
				$SELECT iins_type
				   INTO $iins_type55
				   FROM ply_ins_type
				  WHERE ipolicy = $ipolicy
				    AND iins_type = '255';
				if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��255�I��*/
				{
				    flag255=0;
				}
				else
				{
				    flag255=1;
				}
                strcpy(str_cover1,rtrim(refmtamt(injured_cover,MILLIONTH)));
                strcpy(str_cover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(tmp_deduct,itoa(deduct));
                strcpy(deduct_301,tmp_deduct);
                if(flag55 == 1)
                {
                    if (IsFcomp55(deduct_301))
                    {
                        strcpy(ps_dtl,str_ins_301_11);
                    }
                    else
                    {
                   		strcpy(ps_dtl,str_ins_301_1);
                    }
                }
                else if(flag255 == 1)
                {
                    strcpy(ps_dtl,str_ins_301_2);
                }
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

			case 302:
            /* 1110308005_SC4_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h */
				$SELECT iins_type
				   INTO $iins_type55
				   FROM ply_ins_type
				  WHERE ipolicy = $ipolicy
				    AND iins_type = '55';
				if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��55�I��*/
				{
				    flag55=0;
				}
				else
				{
				    flag55=1;
				}
				$SELECT iins_type
				   INTO $iins_type55
				   FROM ply_ins_type
				  WHERE ipolicy = $ipolicy
				    AND iins_type = '255';
				if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��255�I��*/
				{
				    flag255=0;
				}
				else
				{
				    flag255=1;
				}	
                strcpy(str_cover1,rtrim(refmtamt(injured_cover,MILLIONTH)));
                strcpy(str_cover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(tmp_deduct,itoa(deduct));
                strcpy(deduct_302,tmp_deduct);
                if(flag55 == 1)        /*55���[�I*/
                {
                    if (IsFcomp55(deduct_302))
                    {
                        strcpy(ps_dtl,str_ins_302_11);
                    }
                    else
                    {
                   		strcpy(ps_dtl,str_ins_302_1);
                    }
                }
                else if(flag255 == 1)  /*255�D�I*/
                {
                    if (IsFcomp55(deduct_302))
                    {
                        strcpy(ps_dtl,str_ins_302_21);
                    }
                    else
                    {
                   		strcpy(ps_dtl,str_ins_302_2);
                    }
                }
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
			/* 1140409004_C06_�s�W�r�V�Z��X�O�I */
			case 530:
				strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcpy(tmp_deduct,itoa(deduct));
				strcpy(deduct_30,tmp_deduct);

				$SELECT iins_type
				   INTO $iins_type55
				   FROM ply_ins_type
			      WHERE ipolicy = $ipolicy
				    AND iins_type = '555';
				if(SQLCODE == SQLNOTFOUND)	/*�p�G�O��S��555�I��*/
				{
					flag555=0;
				}
				else
				{
					flag555=1;
				}
				if(flag555 == 1)        /*555���[�I*/
                {
                    if (IsFcomp55(deduct_30))
                    {
                        strcpy(ps_dtl,str_ins_530_11);
                    }
                    else
                    {
                   		strcpy(ps_dtl,str_ins_530_1);
                    }
                }
			break;
			/* 1130510009_C06_�s�W�q�ʨ��M�ݰӫ~(�L��) */
            case 31: case 36: case 113: case 131: case 133: case 231: case 331: case 531:
            
				if(iins == 131 || iins == 331)
				{
					strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
					/* �Y�O�B�G�W�L99,999,999��,��H�U����� */
					if (damage_cover > 99999999)
					{
						strcpy(str_cover2,refmtamt((damage_cover/10000),MILLIONTH));
						strcat(str_cover2,"�U");
					}
					else
						strcpy(str_cover2,refmtamt(damage_cover,MILLIONTH));
					
					strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
				}
				else
				{
					ins_31 = 1;
					strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
					/* �Y�O�B�G�W�L99,999,999��,��H�U����� */
					if (damage_cover > 99999999)
					{
						strcpy(str_cover2,refmtamt((damage_cover/10000),MILLIONTH));
						strcat(str_cover2,"�U");
					}
					else
						strcpy(str_cover2,refmtamt(damage_cover,MILLIONTH));
					
					strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
					printf("--113 str_deduct[%s] deduct[%d] \n",str_deduct,deduct);
					
					if (iins == 31 || iins == 133 || iins == 113 || iins == 231)
						strcpy(str_deduct,refmtamt(deduct,MILLIONTH));
					
					printf("--113 str_deduct[%s] deduct[%d] \n",str_deduct,deduct);
					
					ins_31_multiple = damage_cover / injured_cover;
					
					/* ���w�r�p�H */
					if(strstr(trim(provision),"D;") != NULL)
					{
						strcpy(ins31_provision,"�i���w�r�p�H�j");
						printf("---- 1439---iins_type=[%s]provision=[%s]ins31_provision=[%s]\n",iins_type,provision,ins31_provision);
					}
					else if(strstr(trim(provision),"J;") != NULL)
					{
						provision_J = 1;
						strcpy(ins31_provision,"�i�S�w�γ~�[�T�w�ϥΤH�j");
						printf("---- 1439---iins_type=[%s]provision=[%s]ins31_provision=[%s]\n",iins_type,provision,ins31_provision);
					}
					else
						ins31_provision[0]= '\0';
				}
			break;
			
			/* 1130510009_C06_�s�W�q�ʨ��M�ݰӫ~(�L��) */
            case 32: case 37: case 114: case 132: case 134: case 149: case 232: case 332: case 249: case 532:
            
				if(iins == 132 || iins == 332)
				{
					strcpy(str_cover1,refmtamt(damage_cover,MILLIONTH));
					strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
				}
				else
				{
					ins_32 = 1;
					strcpy(str_cover1,refmtamt(damage_cover,MILLIONTH));
					strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
				}
				
				if (iins == 32 || iins == 134 || iins == 149 || iins == 114 || iins == 232 || iins == 249 || iins == 532)
					strcpy(str_deduct,refmtamt(deduct,MILLIONTH));
			break;

            case 34: case 87: case 115:
            
                /* �Ψ�Ū�����ݪ��I�ت��O�B�O�O */
				insurance_cover_count = 0;
				$SELECT COUNT(*)
				   INTO $insurance_cover_count
				   FROM insurance_cover
				  WHERE iins_type = $iins_type;
				/* �������ݪ����Ū�� */

                /* �ΨӳB�z�I��34 */
                if( insurance_cover_count != 0)
                {
                	/* CA_CONS */
                    IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "001");
                    strcpy(str_cover1, refmtamt(IcurrPlyInsCover->mcover, MILLIONTH));
                    lPremSum += IcurrPlyInsCover->mcover_prem;

                    IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "002");
                    strcpy(str_cover2, refmtamt(IcurrPlyInsCover->mcover, MILLIONTH));
                    lPremSum += IcurrPlyInsCover->mcover_prem;

                    IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "003");
                    strcpy(str_cover3, refmtamt(IcurrPlyInsCover->mcover, MILLIONTH));
                    printf("3------IcurrPlyInsCover->mcover=[%d],  str_cover3=[%s]\n ",IcurrPlyInsCover->mcover, str_cover3);
                    lPremSum += IcurrPlyInsCover->mcover_prem;

                    IcurrPlyInsCover = move_ply_ins_cover_curr2( IfirstPlyInsCover, &iins, "004");
                    strcpy(str_cover4, refmtamt(IcurrPlyInsCover->mcover,MILLIONTH));

                    strcpy(str_ins_premium,refmtamt( lPremSum,MILLIONTH)); /* �L�X���I�ؤ��P�O�B�X�p���O�O */
                }
            break;

            case 38: case 39:
           
                strcpy(str_cover1,ltoa(qday));
                strcat(str_cover1,"����");
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

            case 35: 
            
				strcpy(Full_DBName,get_car_full_db(ipolicy));
				sprintf_s(stmt, sizeof stmt,"SELECT distinct iins_scope \
				                FROM %s \
				               WHERE ipolicy = '%s' \
				                 AND iins_type = '35' \
				                 AND mins_amt > 0;",tablePaPly,ipolicy);
				$PREPARE pa_ply_35 FROM $stmt;
				$DECLARE pa_ply35_cur CURSOR FOR pa_ply_35;
				$OPEN  pa_ply35_cur;
				$FETCH pa_ply35_cur INTO $tmp_iins_scope;
				$CLOSE pa_ply35_cur;
				$FREE  pa_ply35_cur;
				
				strcpy(nins_type,trim(nins_type));
				
				if( strcmp(trim(tmp_iins_scope),"1") == 0 )      strcat(nins_type,"  �O�W��");
				else if( strcmp(trim(tmp_iins_scope),"2") == 0 ) strcat(nins_type,"  �a�x��");
				
				if (strcmp(trim(tmp_iins_scope),"1") != 0) strcpy(cover_print,"");
				
				strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
				
				strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
                
            case 48:
                
                if (damage_cover > 99999999)
                {
                    strcpy(str_cover1,refmtamt((damage_cover/10000),MILLIONTH));
                    strcat(str_cover1,"�U");	
                }
                else
                {
                    strcpy(str_cover1,refmtamt(damage_cover,MILLIONTH));
                }

                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

            case 47: case 147:
            	
            	if(strcmp(iins_type,"147")==0) ins_56 = 1;
            	
                if (injured_cover > 99999999)
                {
                    strcpy(str_cover1,refmtamt((injured_cover/10000),MILLIONTH));
                    strcat(str_cover1,"�U");                		
                }
                else
                {
                    strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
                }
                
                if (death_cover > 99999999)
                {
                    strcpy(str_cover2,refmtamt((death_cover/10000),MILLIONTH));
                    strcat(str_cover2,"�U");               		
                }
                else
                {
                    strcpy(str_cover2,refmtamt(death_cover,MILLIONTH));
                }

                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

            case 49:
            
                strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
                strcpy(str_cover2,refmtamt(death_cover,MILLIONTH));
                strcpy(str_cover3,refmtamt(damage_cover,MILLIONTH));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

            case 50:
                
                if (injured_cover > 99999999)
                {
                    strcpy(str_cover1,refmtamt((injured_cover/10000),MILLIONTH));
                    strcat(str_cover1,"�U");                		
                }
                else
                {
                    strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));                	
                }

                if (death_cover > 99999999)
                {
                    strcpy(str_cover2,refmtamt((death_cover/10000),MILLIONTH));
                    strcat(str_cover2,"�U");                	
                }
                else
                {
                    strcpy(str_cover2,refmtamt(death_cover,MILLIONTH));                	
                }

                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

			case 51:
            
                ins_51 = 1;
                strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
                strcpy(str_cover2,refmtamt(death_cover,MILLIONTH));
                /* �Y�O�B�T�W�L99,999,999��,��H�U����� */
                if (damage_cover > 99999999)
                {
                    strcpy(str_cover3,refmtamt((damage_cover/10000),MILLIONTH));
                    strcat(str_cover3,"�U");
                }
                else
                    strcpy(str_cover3,refmtamt(damage_cover,MILLIONTH));
                
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));

                if( (iins == 51) && (death_cover == damage_cover))
                    strcpy(ps_dtl,str_ps);
			break;

			/* 1130510009_C06_�s�W�q�ʨ��M�ݰӫ~(�L��) */
            case 52: case 252:
            
                if (qcoverage > 2)
                {
                    strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
                    strcpy(str_cover2,refmtamt(death_cover,MILLIONTH));
                    strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                    people = (int) (damage_cover / death_cover);
                    /* �Y�O�B�T�W�L99,999,999��,��H�U����� */
                    if (damage_cover > 99999999)
                    {
                        strcpy(str_cover3,refmtamt((damage_cover/10000),MILLIONTH));
                        strcat(str_cover3,"�U");
                    }
                    else
                        strcpy(str_cover3,refmtamt(damage_cover,MILLIONTH));
                }
                else
                {
                    strcpy(str_cover1,refmtamt(death_cover,MILLIONTH));
                    strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                    people = (int) (damage_cover / death_cover);
                    /* �Y�O�B�T�W�L99,999,999��,��H�U����� */
                    if (damage_cover > 99999999)
                    {
                        strcpy(str_cover2,refmtamt((damage_cover/10000),MILLIONTH));
                        strcat(str_cover2,"�U");
                    }
                    else
                        strcpy(str_cover2,refmtamt(damage_cover,MILLIONTH));
                }
			break;
			
			/* 1130510009_C06_�s�W�q�ʨ��M�ݰӫ~(�L��) */
            case 53: case 55: case 117: case 135: case 255: case 253: case 555:
            
                if (qcoverage > 2)
                {
                    strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
                    strcpy(str_cover2,refmtamt(death_cover,MILLIONTH));
                    /* �Y�O�B�T�W�L99,999,999��,��H�U����� */
                    if (damage_cover > 99999999)
                    {
                        strcpy(str_cover3,refmtamt((damage_cover/10000),MILLIONTH));
                        strcat(str_cover3,"�U");
                    }
                    else
                        strcpy(str_cover3,refmtamt(damage_cover,MILLIONTH));
                        
                    strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                }
                else
                {
                    strcpy(str_cover1,refmtamt(death_cover,MILLIONTH));
                    /* �Y�O�B�G�W�L99,999,999��,��H�U����� */
                    if (damage_cover > 99999999)
                    {
                        strcpy(str_cover2,refmtamt((damage_cover/10000),MILLIONTH));
                        strcat(str_cover2,"�U");
                    }
                    else
                        strcpy(str_cover2,refmtamt(damage_cover,MILLIONTH));
                        
                    strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
                }
                
                strcpy(ps_60,"");
                if(strcmp(iins_type,"55")==0 || strcmp(iins_type,"555")==0)
                {
                	if((strcmp(icar_type,"11") == 0) && (equip_cmp(nequipment,"115") == TRUE) && fdbgn20230601[0] == 'Y')
                	{
                		if (strcmp(trim(dpolicy),"")!=0 )
                		{
                			if(fdply20230601[0] == 'Y')
								strcpy(ps_60,str_ins_55_car_11);
							else 
								strcpy(ps_60," ");
						}
						else 
							strcpy(ps_60,str_ins_55_car_11);
					}
                }
			break;

            case 56: case 136: case 166: case 266:

                ins_56 = 1;
                strcpy(Full_DBName,get_car_full_db(ipolicy));
                sprintf_s(stmt, sizeof stmt,"SELECT max(daily_pay) \
                                FROM %s \
                               WHERE ipolicy = '%s' \
                                 AND iins_type in ('56','136','166','266');",tablePaPly,ipolicy);
                $PREPARE pa_ply_56 FROM $stmt;
		        $DECLARE pa_ply56_cur CURSOR FOR pa_ply_56;
		        $OPEN  pa_ply56_cur;
	            $FETCH pa_ply56_cur INTO $daily_pay;
	            $CLOSE pa_ply56_cur;
		        $FREE  pa_ply56_cur;
	              
                /*1080711006_SC1_�ק�O��/���C�L���e�A�ҥH�I�ثO�B�ҭn��"," 2019.08.07 by 071004*/
                strcpy(str_cover1,refmtamt(daily_pay,MILLIONTH));
                if (damage_cover > 99999999)
                {
                    strcpy(str_cover2, refmtamt((damage_cover /10000),MILLIONTH));
                    strcat(str_cover2,"�U");                 	
                }
                else
                {
                    strcpy(str_cover2, refmtamt(damage_cover,MILLIONTH));
                }

                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

            case 57: case 59: case 60:
            
                /* car9801122 �T���ȹB�~�����I(57,59,60), add by Julia in 2009/01/19 */
                /* 0991209006_C3 �[�L��˫O�B add by sylvia 100.01.20 (0991209006_C1) */
                if (qcoverage > 2)
                { /* ���L��� */
                    strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
                    strcpy(str_cover2,refmtamt(death_cover,MILLIONTH));
                    /* �Y�O�B�T�W�L99,999,999��,��H�U����� */
                    if (damage_cover > 99999999)
                    {
                        strcpy(str_cover3,refmtamt((damage_cover/10000),MILLIONTH));
                        strcat(str_cover3,"�U");
                    }
                    else
                        strcpy(str_cover3,refmtamt(damage_cover,MILLIONTH));
                }
                else
                {
                    /* ���L��� */
                    strcpy(str_cover1,refmtamt(death_cover,MILLIONTH));
                    /* �Y�O�B�G�W�L99,999,999��,��H�U����� */
                    if (damage_cover > 99999999)
                    {
                        strcpy(str_cover2,refmtamt((damage_cover/10000),MILLIONTH));
                        strcat(str_cover2,"�U");
                    }
                    else
                        strcpy(str_cover2,refmtamt(damage_cover,MILLIONTH));
                }
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));

                ins_575960 = 1;
			break;

            /* �����¦����s�A�������I�����{���]�w(137�B138�B139�B141�B142�I��) (1100311005_SC6)*/
            case 61: case 65: case 69: case 68: case 108:
            
                strcpy(str_cover1,refmtamt(damage_cover,MILLIONTH));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

            case 62: case 63: case 64: case 143:
            
				if (qcoverage > 1)
				{	
					/* �A�ηs��(���G�ӫO�B) add by sylvia 101.12.25 (1011214002_C1) */
					strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
					strcpy(str_cover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
					strcat(str_deduct,refmtamt(deduct,MILLIONTH));
					strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
				}
				else
				{
					/* �A���¨�(�u���@�ӫO�B) */
					strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
					strcat(str_deduct,refmtamt(deduct,MILLIONTH));
					strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
				}
			break;

            case 71: case 72: case 78: case 79: case 89: case 90:
            
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

            case 77: case 80:
            
                strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
                if (damage_cover > 99999999)
                {
                    strcpy(str_cover2,refmtamt((damage_cover/10000),MILLIONTH));
                    strcat(str_cover2,"�U");
                }
                else
                    strcpy(str_cover2,refmtamt(damage_cover,MILLIONTH));

                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

            case 96:
            
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
                strcpy(str_deduct,refmtamt(deduct,MILLIONTH));
                strcat(str_deduct,"%");
                /* Ū��96+97�O�O */
                sprintf_s(sStmt, sizeof sStmt, "SELECT sum(mins_premium) \
                                  FROM %s \
                                 WHERE ipolicy = '%s' \
                                   AND iins_type in ('96','97');", tableInsType, ipolicy);
                $PREPARE plyInsType96_cur FROM $sStmt;
                $EXECUTE plyInsType97_cur INTO $ins_premium;

                strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
			break;

            case 97:
            
                strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
            break;
            
            case 103:

				strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
				/* �Y�O�B�G�W�L99,999,999��,��H�U����� */
				if (damage_cover > 99999999)
				{
					strcpy(str_cover2,refmtamt((damage_cover/10000),MILLIONTH));
					strcat(str_cover2,"�U");
				}
				else
					strcpy(str_cover2,refmtamt(damage_cover,MILLIONTH));
				
				strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

			/* �����¦����s�A�������I�����{���]�w(137�B138�B139�B141�B142�I��) (1100311005_SC6)*/
			case 107:
			
				strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
				strcpy(str_cover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcat(str_deduct,refmtamt(deduct,MILLIONTH));
				strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
			
			case 154: case 155: case 156: case 163:
			
				strcpy(str_cover1,ltoa(qday));
				strcat(str_cover1,"��");
				strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
				strcpy(str_cover2,rtrim(refmtamt(injured_cover,MILLIONTH)));
			break;
		
			/* 1120927002_C03_�R�q�ΰӫ~�}�o(�tebpB2B���s) */
			case 173:
				
				strcpy(str_cover1,refmtamt(damage_cover,MILLIONTH));
				strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
			
			case 174:
			
				strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
				strcpy(str_cover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcat(str_deduct,refmtamt(deduct,MILLIONTH));
                strcat(str_deduct,"%");
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
			
			case 175:
			
				strcpy(str_cover1," ");
				strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
			
			/* 1130510009_C06_�s�W�q�ʨ��M�ݰӫ~(�L��) */
			case 176: case 177:
            	
            	strcat(str_deduct,refmtamt(deduct,MILLIONTH));
                strcat(str_deduct,"%");
        		strcpy(str_ins_premium,rtrim(refmtamt(ins_premium,MILLIONTH)));
        	break;

        	case 178:
			
				strcpy(str_cover1,refmtamt(injured_cover,MILLIONTH));
				strcpy(str_cover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcat(str_deduct,refmtamt(deduct,MILLIONTH));
                strcat(str_deduct,"%");
                strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
			
			case 237:
            	
	        	/*1130229009_C09_�s�W�N�~�ƬG�୼�O�Ϊ��[����(�L��)*/
	            strcpy(str_cover1,rtrim(refmtamt(injured_cover,MILLIONTH)));
	            strcpy(str_cover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
	            strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;		
			
            case 238:
            	
	        	/*1101229013_SC4_�s�W238�I�ؤ������{�O�v-�L��@�~*/
	        	if (qday == 999)
	        	{
	        		strcpy(str_cover4,"����");
	        	}
	        	else
	        	{
	            	strcpy(str_cover4,ltoa(qday));
	        	}
	            strcat(str_cover4,"����");
	            strcpy(str_cover1,rtrim(refmtamt(injured_cover,MILLIONTH)));
	            strcpy(str_cover2,rtrim(refmtamt(damage_cover,MILLIONTH)));
	            strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

			case 561:

				ins_56 = 1;
				strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
			case 562:

				strcpy(str_cover1,rtrim(refmtamt(injured_cover,MILLIONTH)));
				strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;

			default:
            
				strcpy(str_cover1,rtrim(refmtamt(damage_cover,MILLIONTH)));
				strcpy(str_ins_premium,refmtamt(ins_premium,MILLIONTH));
			break;
        }/* end of switch */


        /* �ɵo�O��B�ӳ榳�O�U�L�@��,17�I�ؤ��C�L */
        /* �M�ץ�O��,17�I�ؤ��C�L */
        if (ins_17 == 2)
        {
        	  ins_17 = 0;
        	  continue;
        }
        /* end of �P�_�U�L�@�� */

        /* �ɵo�O��B�ӳ榳�O�U�L�@��,14�I�ؤ��C�L */
        if (ins_14 == 2)
        {
        	  ins_14 = 0;
        	  continue;
        }
        /* end of �P�_�U�L�@�� */

        /* �ɵo�O��B�ӳ榳�O�U�L�@��,19�I�ؤ��C�L */
        /* �M�ץ�O��,19�I�ؤ��C�L */
        if (ins_19 == 2)
        {
        	  ins_19 = 0;
        	  continue;
        }
        /* end of �P�_�U�L�@�� */

        /* �N�C�L����Ʃ�J�Ȧstable */
        /* �Y�O�B���@�ӥH�W���ɭ�,�n�̷ӫO�B�Ӽƨ̧ǩ�J�Ȧs���C�Ltable */
        strcpy(iins_type,trim(iins_type));
        printf("iins_type=[%s]ins31_provision=[%s]\n",iins_type,ins31_provision);

		/*======== ��������������  �H�U�B�z�I�ؤ���W�٫�A�������[����  �������������� ========*/ 
		nins_type2[0] = '\0';
		strcpy(nins_type2,rtrim(nins_type));
		strcpy(provision2,trim(provision));
		if (strlen(provision) > 1) 
		{
			if(strstr(trim(provision),"P;") != NULL)
			{
				if ((strcmp(iins_type,"01") != 0)  && (strcmp(iins_type,"05") != 0)  && (strcmp(iins_type,"09") != 0)  && (strcmp(iins_type,"11") != 0) &&
				    (strcmp(iins_type,"201") != 0) && (strcmp(iins_type,"205") != 0) && (strcmp(iins_type,"209") != 0) && (strcmp(iins_type,"211") != 0))
					$SELECT first 1 replace($provision2,'P;','')
					   INTO $provision2
					   FROM systables;
			}
			
			if(strstr(trim(provision),"Q;") != NULL)
			{
				if ((strcmp(iins_type,"01") != 0)  && (strcmp(iins_type,"05") != 0)  && (strcmp(iins_type,"09") != 0)  && (strcmp(iins_type,"11") != 0) &&
				    (strcmp(iins_type,"201") != 0) && (strcmp(iins_type,"205") != 0) && (strcmp(iins_type,"209") != 0) && (strcmp(iins_type,"211") != 0))
					$SELECT first 1 replace($provision2,'Q;','')
					   INTO $provision2
					   FROM systables;
			}
			
			if(strstr(trim(provision),"M;") != NULL)
			{
				if ((strcmp(iins_type,"01") != 0)  && (strcmp(iins_type,"05") != 0)  && (strcmp(iins_type,"09") != 0)  && (strcmp(iins_type,"11") != 0)  && (strcmp(iins_type,"181") != 0) && 
				    (strcmp(iins_type,"201") != 0) && (strcmp(iins_type,"205") != 0) && (strcmp(iins_type,"209") != 0) && (strcmp(iins_type,"211") != 0))
					$SELECT first 1 replace($provision2,'M;','')
					   INTO $provision2
					   FROM systables;
			}
			
			/* 1130827011_C04_�s�W�s�t��W�B���[����(Y)(�L��) */
			if(strstr(trim(provision),"Y;") != NULL)
			{
				if ((strcmp(iins_type,"01") != 0)  && (strcmp(iins_type,"05") != 0)  && (strcmp(iins_type,"09") != 0)  && (strcmp(iins_type,"11") != 0)  && (strcmp(iins_type,"198") != 0) && 
				    (strcmp(iins_type,"201") != 0) && (strcmp(iins_type,"205") != 0) && (strcmp(iins_type,"209") != 0) && (strcmp(iins_type,"211") != 0))
					$SELECT first 1 replace($provision2,'Y;','')
					   INTO $provision2
					   FROM systables;
			}
				
			if(strstr(trim(provision),"X;") != NULL)
			{
				$SELECT first 1 replace($provision2,'X;','')
				   INTO $provision2
				   FROM systables;
			}
			
			if(strstr(trim(provision),"D;") != NULL)
			{
				if (strcmp(iins_type,"07") == 0) /*07�������(D)*/
				{
					$SELECT first 1 replace($provision2,'D;','')
					   INTO $provision2
					   FROM systables;
				}
			}
			
			if(strstr(trim(provision),"H;") != NULL)
			{
				if (strcmp(iins_type,"07") == 0 || strcmp(iins_type,"10") == 0 || strcmp(iins_type,"109") == 0)
				{
					$SELECT first 1 replace($provision2,'H;','')  /*07�B10�B109�������(H)*/
					   INTO $provision2
					   FROM systables;
				}
			}
			
			if(strstr(trim(provision),"L;") != NULL) /*1080708002_SC4_�s�W�����������(�N��L)*//* 2019.09.10 by 071004 */
			{
				$SELECT first 1 replace($provision2,'L;','')
				   INTO $provision2
				   FROM systables;
			}
			
			strcpy(provision2,trim(provision2));
			if (strlen(provision2) > 1) 
			{
				provision2[strlen(provision2)-1]='\0';
				strcat(nins_type2,"(");
				strcat(nins_type2,provision2);
				strcat(nins_type2,")");
				strcpy(nins_type,nins_type2);
				printf("--nins_type2[%s]\n",nins_type2);
			}
		}
		printf("--2999 iins_type[%s] nins_type[%s] provision[%s] \n",iins_type,nins_type,provision);
		
        /* �P�ɩӫO31,32�I��,�S�O�h�����O��,�B��D����,�n�b�g�J32�e�A�h�@��LD���ڸ�� */
        if (((strcmp(iins_type,"32") == 0) || (strcmp(iins_type,"134") == 0) || (strcmp(iins_type,"232") == 0)) && (ins_31_multiple > 2) && (ins31_provision[0] != '\0'))
        {
			if(strstr(trim(provision),"D;") != NULL)
			{
				insert_prt_table(ipolicy,"","�i���w�r�p�H�j","","","","","", 0);            
			}
			else if(strstr(trim(provision),"J;") != NULL)
			{
				insert_prt_table(ipolicy,"","�i�S�w�γ~�[�T�w�ϥΤH�j","","","","","", 0); 
			}
			printf("---- 1771---iins_type=[%s]provision=[%s]\n",iins_type,provision);
        }

        /*======== ��������������  �H�U�B�z�O�B�C�L  �������������� ========*/
    	if (qcoverage > 1)
        {
            /* �I�ئW�� */
            strcpy(nins_type, rtrim(nins_type));

            /* �D�n���I���� */
            strcpy(main_paid, rtrim(main_paid));

            /* �h�ӫO�B */
            $DECLARE cur_coverage1x CURSOR for
              SELECT contain1 FROM tbl_coverage WHERE ipolicy = $ipolicy ORDER BY serial_no;

			j = 0;
			$OPEN cur_coverage1x;
			while (1)
			{
				$FETCH cur_coverage1x INTO $contain_coverage;
				
				if (SQLCODE == SQLNOTFOUND) break; 
				
				strcpy(cover_print,trim(contain_coverage));
				
				if(j==0)
				{
					strcpy(amt_print, str_cover1);
                    strcpy(nins_type, nins_type);
                    strcpy(main_paid, main_paid);
				}
				else if (j==1)
				{
				    strcpy(amt_print, str_cover2);
				    strcpy(iins_type,"");
				    strcpy(nins_type,"");
				    strcpy(main_paid,"");
					strcpy(str_deduct,"");
				}
				else if (j==2)
				{
				    strcpy(amt_print, str_cover3);
				    strcpy(iins_type,"");
				    strcpy(nins_type,"");
				    strcpy(main_paid,"");
					strcpy(str_deduct,"");
				}
				else
				{
				    strcpy(amt_print, str_cover4);
				    strcpy(iins_type,"");
				    strcpy(nins_type,"");
				    strcpy(main_paid,"");
					strcpy(str_deduct,"");
				}
				
				if (j > 0)
                {   
                    strcpy(str_ins_premium,"");
                    ins_premium = 0;
                }
				
				printf("0160: cover_print[%s],amt_print[%s]\n",cover_print,amt_print);
				
				insert_prt_table(ipolicy,iins_type,nins_type,main_paid,cover_print,amt_print,str_deduct,str_ins_premium,ins_premium);
				j++;
			}
            $CLOSE cur_coverage1x;
            $FREE cur_coverage1x;
            $DELETE tbl_coverage WHERE ipolicy=$ipolicy;
                
        }
        else if (strcmp(iins_type, "96")==0)
        {
            /* �n�g�J�G��:�Ĥ@�欰�D�I��-�I�إN��96,�D�n�I�ئW��,�D�n���I����,96+97�`�O�O;
                          �ĤG�欰96�I��:�I�ئW��,�O�B,�ۭt�B */
            strcpy(cover_print,trim(cover_print));
            strcpy(amt_print,str_cover1);

            /* �Ĥ@�� */
            insert_prt_table(ipolicy,iins_type,"�T���ѵs�l���O�I(�ҫ�)","�ꨮ�ߥI�B�]���l���O�I���B�N���O��"," "," "," ",str_ins_premium,ins_premium);

            /* �ĤG�� */
            sprintf_s(sNinstype2, sizeof sNinstype2, "  %s",nins_type);
            insert_prt_table(ipolicy," ",sNinstype2," ",cover_print,amt_print,str_deduct," ", 0);
         
        }
        else if (strcmp(iins_type, "97")==0)
        {
            /* �g�J97�I��:�W��,�O�B,�ۭt�B */
            strcpy(cover_print,trim(cover_print));
            strcpy(amt_print,str_cover1);
            sprintf_s(sNinstype2, sizeof sNinstype2, "  %s",nins_type);
            insert_prt_table(ipolicy," ",sNinstype2," ",cover_print,amt_print,str_deduct," ", 0);

            /* �P�_�O�_�L�X���w�r�p�H add by sylvia 101.06.21 */
            if(strstr(trim(provision),"D;") != NULL)
            {
                strcpy(nins_type,"�i���w�r�p�H�j");
                insert_prt_table(ipolicy,"",nins_type,"","","","","", 0);
                printf("---- 1849---iins_type=[%s]provision=[%s]\n",iins_type,provision);
            }
        }
        else if (strcmp(iins_type, "119") == 0 || strcmp(iins_type, "121") == 0)
        {
	        /* 119��121�I�ءu�D�n���I���ءv�Ρu�O�I���B�v�e�{�覡��אּ��C (1040109009_C1)*/
	        strcpy(iins_type,"");
	        strcpy(cover_print,"");
	        strcpy(amt_print,"");
	        strcpy(str_ins_premium,"");
	        ins_premium = 0;

	        sprintf_s(cover_print, sizeof cover_print,"�̰�%s",str_cover1);
	        insert_prt_table(ipolicy,iins_type,stmp_ntype1,stmp_mpad1,cover_print,amt_print,str_deduct,str_ins_premium,ins_premium);
	
	        strcpy(cover_print,"");
	        sprintf_s(cover_print, sizeof cover_print,"�O�������Ѩ����ΨC��");
	        insert_prt_table(ipolicy,iins_type,stmp_ntype1,stmp_mpad1,cover_print,amt_print,str_deduct,str_ins_premium,ins_premium);
	        
	        strcpy(cover_print,"");
	        sprintf_s(cover_print, sizeof cover_print,"%s���G�̦X�p�̰�%s ",str_cover2,str_cover1);
	        insert_prt_table(ipolicy,iins_type,stmp_ntype2," ",cover_print,amt_print,"",str_ins_premium,ins_premium);

        }
        else if (strcmp(iins_type, "154") == 0 || strcmp(iins_type, "155") == 0 || strcmp(iins_type, "156") == 0)
        {
            sprintf_s(cover_print, sizeof cover_print,"�O�������Ѩ����ΨC��%s���G�̦X�p�̰�%s ",str_cover2,str_cover1);
            insert_prt_table(ipolicy,iins_type,nins_type,main_paid,cover_print,amt_print,str_deduct,str_ins_premium,ins_premium);
        }
        else if (strcmp(iins_type, "237") == 0)
        {
			strcpy(nins_type, rtrim(nins_type));
            strcpy(cover_print,"�C�@�ƬG");
            insert_prt_table(ipolicy,iins_type,nins_type,main_paid,cover_print,str_cover1,str_deduct,str_ins_premium,ins_premium);	
            insert_prt_table(ipolicy," "," "," ","�O�I����",str_cover2," "," ",0);
        }
        else if (strcmp(iins_type, "238") == 0)
        {
			strcpy(nins_type, rtrim(nins_type));
            strcpy(cover_print,"�C�@�ƬG");
            insert_prt_table(ipolicy,iins_type,nins_type,main_paid,cover_print,str_cover1,str_deduct,str_ins_premium,ins_premium);	
            sprintf_s(cover_print, sizeof cover_print,"��Q���{%s",str_cover4);
            insert_prt_table(ipolicy," ",cover_print," ","�O�I����",str_cover2," "," ",0);
        }
        else
        {
            strcpy(cover_print,trim(cover_print));
            strcpy(amt_print,str_cover1);
            /* 119��121�I�ت��O�O�w�[�`�b118��120�I�� add by larry 103.08.05 (1030725001_C5) */
            /* 123�I�ثO�O�w�[�`�b122�I�ثO�O add by larry 103.08.12 (1030806001_C2)*/
            /* 139�I�ت��O�O�w�[�`�b138�I�� add by larry 104.05.21 (1040515009_C2) */
            /* �����¦����s�A�������I�����{���]�w(137�B138�B139�B141�B142�I��) (1100311005_SC6)*/
            if (strcmp(iins_type, "123") == 0)
            {
                strcpy(iins_type,"");
                strcpy(cover_print,"");
                strcpy(amt_print,"");
                sprintf_s(cover_print, sizeof cover_print,"�O�������Ѩ����ΨC��%s���G�̦X�p�̰�%s ",str_cover2,str_cover1);
                strcpy(str_ins_premium,"");
                ins_premium = 0;
            }

            insert_prt_table(ipolicy,iins_type,nins_type,main_paid,cover_print,amt_print,str_deduct,str_ins_premium,ins_premium);

            /* �P�_�O�_�L�X�Ұ���O��(only iins_type = '05','09','32' */
            /* 1130510009_C06_�s�W�q�ʨ��M�ݰӫ~(�L��) */
            if (strcmp(iins_type,"05") == 0  || strcmp(iins_type,"09") == 0  ||
                strcmp(iins_type,"32") == 0  || strcmp(iins_type,"125") == 0 ||
                strcmp(iins_type,"126") == 0 || strcmp(iins_type,"134") == 0 ||
                strcmp(iins_type,"205") == 0 || strcmp(iins_type,"209") == 0)
            {
                /* if(strcmp(trim(provision),"H")==0) */
                if(strstr(trim(provision),"H;") != NULL)
                {
                    strcpy(nins_type,"�i�Ұ���O�١j");
                    insert_prt_table(ipolicy,"",nins_type,"","","","","", 0);
                }
            }

            /* �P�_�O�_�L�X���w�r�p�H add by sylvia 101.06.21 */
            if(strstr(trim(provision),"D;") != NULL)
            {
                if (strcmp(iins_type,"07") != 0)
                {
                    strcpy(nins_type,"�i���w�r�p�H�j");
                    insert_prt_table(ipolicy,"",nins_type,"","","","","", 0);
                    printf("---- 1876---iins_type=[%s]provision=[%s]\n",iins_type,provision);                     	
                }
            }

            if(strstr(trim(provision),"J;") != NULL)
            {
                provision_J = 1;
                strcpy(nins_type,"�i�S�w�γ~�[�T�w�ϥΤH�j");
                insert_prt_table(ipolicy,"",nins_type,"","","","","", 0);
                printf("---- 1876---iins_type=[%s]provision=[%s]\n",iins_type,provision);
            }
        }

        /* �P�_�O�_�L�X���������[���� add by �L�� 104.11.25 */
        if(strstr(trim(provision),"S;") != NULL)
        {
            if(strcmp(iins_type, "07") != 0 && strcmp(iins_type, "10") != 0 && strcmp(iins_type, "127") != 0)
            {
                strcpy(nins_type,"���������[����");
         	insert_prt_table(ipolicy,"",nins_type,"","","","","", 0);
         	printf("----2526---iins_type=[%s]provision=[%s]\n",iins_type,provision);
            }
        }
        
        /*======== ��������������  �H�U�B�z���[���ڵ��O  �������������� ========*/
		if(strstr(trim(provision),"X;") != NULL)
		{
			provision_X = 1;
			strcpy(nprov_X,"���O���O�i�O�I�����ܧ�Τ��~�פ���[���ڡj(X)");
			printf("---- 1781---iins_type=[%s]provision=[%s]\n",iins_type,provision);
		}
		
		printf("---iins_type=[%s]provision=[%s]\n",iins_type,provision);
		/* 1071226006_SC4_�w���ƫ����վ�(���²v+�ĤT�H�d��) */
		if(strstr(trim(provision),"P;") != NULL)
		{
			/* �u�w��D�I01�B05�B09�B11�P�_����P�BQ���ڴ��� */
			if (strcmp(iins_type, "01") == 0  || strcmp(iins_type, "05") == 0  || strcmp(iins_type, "09") == 0  || strcmp(iins_type, "11") == 0 || 
			    strcmp(iins_type, "201") == 0 || strcmp(iins_type, "205") == 0 || strcmp(iins_type, "209") == 0 || strcmp(iins_type, "211") == 0)
			{
				provision_P = 1;
			}
			else  printf("Do Nothing \n");
		}
		
		if(strstr(trim(provision),"Q;") != NULL)
		{
			/* �u�w��D�I01�B05�B09�B11�P�_����P�BQ���ڴ��� */
			if (strcmp(iins_type, "01") == 0  || strcmp(iins_type, "05") == 0  || strcmp(iins_type, "09") == 0  || strcmp(iins_type, "11") == 0 || 
			    strcmp(iins_type, "201") == 0 || strcmp(iins_type, "205") == 0 || strcmp(iins_type, "209") == 0 || strcmp(iins_type, "211") == 0)
			{
				provision_Q = 1;
			}
			else  printf("Do Nothing \n");
		}
		
		if(strstr(trim(provision),"M;") != NULL)
		{
			/* �u�w��D�I01�B05�B09�B11�P�_���� M ���ڴ��� */
			if (strcmp(iins_type, "01") == 0  || strcmp(iins_type, "05") == 0  || strcmp(iins_type, "09") == 0  || strcmp(iins_type, "11") == 0 || strcmp(iins_type, "181") == 0 || 
			    strcmp(iins_type, "201") == 0 || strcmp(iins_type, "205") == 0 || strcmp(iins_type, "209") == 0 || strcmp(iins_type, "211") == 0)
			{
				provision_M = 1;
			}
			else  printf("Do Nothing \n");
		}
		
		if(strstr(trim(provision),"Y;") != NULL)
		{
			/* 1130827011_C04_�s�W�s�t��W�B���[����(Y)(�L��) */
			if (strcmp(iins_type, "01") == 0  || strcmp(iins_type, "05") == 0  || strcmp(iins_type, "09") == 0  || strcmp(iins_type, "11") == 0 || strcmp(iins_type, "198") == 0 || 
			    strcmp(iins_type, "201") == 0 || strcmp(iins_type, "205") == 0 || strcmp(iins_type, "209") == 0 || strcmp(iins_type, "211") == 0)
			{
				provision_Y = 1;
			}
			else  printf("Do Nothing \n");
		}
		
		
		if(strstr(trim(provision),"V;") != NULL)
		{
			/* �w��09�B31�B32�P�_�ۭt�B���[���� */
			provision_V = 1;
			if(strcmp(iins_type, "09") == 0 || strcmp(iins_type, "209") == 0)  
			cnt_V09 = 1;
			if(strcmp(iins_type, "31") == 0 || strcmp(iins_type, "32") == 0 || strcmp(iins_type, "231") == 0 || strcmp(iins_type, "232") == 0) 
			cnt_V3132 = 1;
		}
		
		if(strstr(trim(provision),"K;") != NULL)
		{
			/* 1080225007_SC4_�s�W�r�˰ӫ~ */
			provision_K = 1;
		}
		
		if(strstr(trim(provision),"U;") != NULL)
		{
			provision_U = 1;
		}
		
		if(strstr(trim(provision),"L;") != NULL)
		{
			/* 1080708002_SC4_�s�W�����������(�N��L)  */
			provision_L = 1;
			strcpy(nprov_L,"�i���O����[������~�γ~���[���ڡj");
		}
	} /* end of Ū���I�� */
	$CLOSE curh;

    /* �O�O�����O�B���s���I�ثO�O */
    /* �O�B=0,�O�O!=0,�����C�L mark by sylvia 101.10.08 (1010928006_C1) */
    /* premium1 = premium1 - deduct_prem; */
    
    /* �Y��56.136�I��,�hŪ���X�Q�O�I�H�W�U������� */
    /* 166�I�حn�L�W�U (1090921003_SC1) */
    printf("list_print 0:�C�L 1:���L[%d]\n",list_print);
	if (ins_56 == 1 && list_print == 0)
	{
        sprintf_s(stmt, sizeof stmt,
                     "SELECT iins_type,iinsurant,ninsurant,dbirth,nbeneficiary,relation_bene,tbenef,abenef \
                        FROM %s \
                       WHERE ipolicy = '%s' \
                         AND iins_type in ('56','136','166','266') \
                         AND mins_amt > 0 \
                       union \
                      SELECT iins_type,iassured,nassured,dbirth,nbenef,rel_benef,tbenef,abenef \
		                FROM %s \
		               WHERE ipolicy = '%s' \
		                 AND iins_type in ('147','561') ;",tablePaPly,ipolicy,tableAssured,ipolicy);

        $PREPARE pa_ply FROM $stmt;
        $DECLARE ca_cur CURSOR FOR pa_ply;
        j = 0;
        
        $OPEN ca_cur;
        while(1)
        {
            
            $FETCH ca_cur INTO $iins_type56,$iinsurant56,$ninsurant56,$dbirth56,$nbeneficiary56,$relation_bene56,$tbenef56,$abenef56;
            if (SQLCODE == SQLNOTFOUND) 
            {
                line66 = 1;  /* line66 and line67�O�ӽT�{�Q�O�I�H�W�U�O�_�ݭn�C�L */
                line67 = 1;
                list_cnt = 1;
                break;
            }

            $INSERT INTO tbl_56list (ipolicy,iins_type,iinsurant,ninsurant,dbirth,nbeneficiary,relation_bene,tbenef,abenef) 
                  VALUES ($ipolicy,$iins_type56,$iinsurant56,$ninsurant56,$dbirth56,$nbeneficiary56,$relation_bene56,$tbenef56,$abenef56);
        }
        $CLOSE ca_cur;
        $FREE ca_cur;
    }
	else
	{
		/* ���L��ơA�u�L���廡�� */
		line66 = 1;
		line67 = 1;
		list_cnt = 1;
	}
   
	/*======================================================================*/
	/* 31,32�P�ɩӫO��,�Y���T���h���O�ٮ�,�[�L"�T���h���O��"�b31�I�ؤ��� */
	if (ins_31 == 1 && ins_32 == 1)
	{
		if (ins_31_multiple > 2)
		{
			strcpy(tmp3132,"�T���h���O��");
			strcpy(tmp3132,trim(tmp3132));
			
			$SELECT MIN(line_no) INTO $line_no FROM tbl_print WHERE ipolicy = $ipolicy AND field1 in ('31','36','231');
			    
			if (line_no > 0)
			{
				$SELECT field2 INTO $tmpfield2 FROM tbl_print WHERE ipolicy = $ipolicy AND line_no = $line_no;    
				strcpy(tmpfield2,trim(tmpfield2));
				strcat(tmpfield2,tmp3132);
				
				$UPDATE tbl_print
				    SET field2 = $tmpfield2
				  WHERE ipolicy = $ipolicy AND line_no = $line_no;
				strcpy(tmpfield2,""); 
			}
		}
	}

    printf("0170: before select mprem\n");
    sprintf_s(stmt, sizeof stmt,"SELECT SUM(mprem) \
                    FROM %s \
                   WHERE ipolicy = '%s';", tableInsType, ipolicy);
    printf("stmt[%s]\n", stmt);
    $PREPARE plyins_cur1 FROM $stmt;
    $DECLARE prem_cur1 CURSOR FOR plyins_cur1;
    $OPEN prem_cur1;
    $FETCH prem_cur1 INTO $old_premium;
    $CLOSE prem_cur1;
    $FREE  prem_cur1;

    if ( ins_17 == 0 || ins_17 == 2)
    {
        printf("***********************17�I�ؤ��C�L���O���O ******************************\n");
        premium1 = premium1 - premium_17;
        old_premium = old_premium - old_premium_17;
        mdiscount = mdiscount - mdiscount_17;
    } 
    else
    {
    	/* ���ӫO11�I�إH��17�I��,17�I�ؤ��C�L */
    }

    /* �M�ץ�O�椣�C�L19�I�� add by larry 102.12.16 (1021122001_C3) */
    if (strncmp(sIpolicyB_type,"1",1) == 0)
    {
        if ( ins_19 == 0 || ins_19 == 2)
        {
            premium1 = premium1 - premium_7h_19;
            old_premium = old_premium - old_premium_7h_19;
            mdiscount = mdiscount - mdiscount_7h_19;
        }
    }

	/*�C�M�ᨮ�ߨ����O*/
	if (equip_cmp(nequipment,"5") == TRUE)
	{
	    strcpy(nequipment_7h,"1");
	}
	else
	{
	    strcpy(nequipment_7h,"0");
	}

    strcpy(iofficer_7h,substring(iofficer,1,3));
    printf("0180: nequipment_7h:[%s],iofficer_7h:[%s], ins_14[%d]\n",nequipment_7h,iofficer_7h, ins_14);

	if ( strcmp(nequipment_7h,"1")==0 && strncmp(sIpolicyB_type,"0",1) == 0 )
	{
		if ( ins_14 == 0 || ins_14 == 2)
		{
		    premium1 = premium1 - premium_7h_14;
		    old_premium = old_premium - old_premium_7h_14;
		    mdiscount = mdiscount - mdiscount_7h_14;
		}
		
		if ( ins_19 == 0 || ins_19 == 2)
		{
		    premium1 = premium1 - premium_7h_19;
		    old_premium = old_premium - old_premium_7h_19;
		    mdiscount = mdiscount - mdiscount_7h_19;
		}
	}

    strcpy(s_note," ");

    strcpy(datestr,cm_cdate_str_100(dply_begin));
    cm_split_ymd_100(datestr,yy3,mm3,dd3);

    strcpy(datestr,cm_cdate_str_100(dply_end));
    cm_split_ymd_100(datestr,yy4,mm4,dd4);

    strcpy(s_premium1,refmtamt(premium1,MILLIONTH));

    /* 1040706002_C1_���O�X��1%���u�馩�� */
    mdisc=0.0;

    if (strlen(trim(ipolicy)) > 13)
    {
        strncpy(sIpolicy1, ipolicy, 13);
        sIpolicy1[13] = '\0';
        strncpy(sIpolicy2, ipolicy+13, 4);
        sIpolicy2[20] = '\0';
        if (sIpolicy2[0]=='\0' || sIpolicy2[0]==' ')  strcpy(sIpolicy2," ");
    }
    else
    {
        strcpy(sIpolicy1,ipolicy);
        strcpy(sIpolicy2," ");
    }

	$SELECT nvl(sum(pay_mnt),0.0)  Into $mdisc
	   FROM ao_reward_policy
	  WHERE ipolicy1 = $sIpolicy1
	    AND ipolicy2 = $sIpolicy2;

    strcpy(bak1_ply,refmtamt(premium1,   MILLIONTH));   /* for �O�I�O */

    if ( mpure_prem != 0 )
    {
        real_premium=premium1 + prem21 - (long)mdisc;           /* �X�p�O�O*/
        real1_premium=premium1 + mdiscount - (long)mdisc;       /* ���N�O�O*/

        strcpy(bak1,refmtamt(premium1- (long)mdisc,MILLIONTH)); /*����*/
        strcpy(bak3,refmtamt(real1_premium,MILLIONTH));         /*�O�Ototal*/
        strcpy(bak31,refmtamt(real_premium,MILLIONTH));         /*�X�p*/
        strcpy(bak2,refmtamt(mdiscount,MILLIONTH));             /*�u�f*/

        rate = (float)mdiscount / (float)( premium1 + mdiscount ) * 100  + 0.5;
    }
    else
    {
        real_premium=premium1 + prem21 - mdiscount - (long)mdisc;
        real1_premium=premium1 - mdiscount - (long)mdisc;
		
        strcpy(bak3,refmtamt(premium1- (long)mdisc,MILLIONTH)); /*�O�Ototal*/
        strcpy(bak1,refmtamt(real1_premium,MILLIONTH));         /*�ꦬ*/
        strcpy(bak31,refmtamt(real_premium,MILLIONTH));         /*�X�p*/
        strcpy(bak2,refmtamt(mdiscount,MILLIONTH));             /*�u�f*/

        rate = (float) mdiscount / (float) premium1 * 100 + 0.5;
    }

    if (mdiscount<=0)
    {
        sprintf_s(s0_real_premium, sizeof s0_real_premium,"                               %s", bak1_ply);/*�`�O�I�O    */
        sprintf_s(s_real_premium, sizeof s_real_premium,"���N�O�O %s  "                       , bak3);  /*�b��Ĥ@��  */
        sprintf_s(s1_real_premium, sizeof s1_real_premium,"�O�O %s "                           , bak3);  /*���ڲĤ@��  */
    }
    else
    {
        strcpy(iassured, trim(iassured));
        if( (strcmp(iassured,"23528130")==0) || (strcmp(iassured,"16091337")==0) ||
            (strcmp(iassured,"70462172")==0) || (strcmp(iassured,"80521360")==0) ||
            (strcmp(iassured,"16097233")==0) || (strcmp(ikind,"2")==0))
        {   /** car-9405172 �������̲νs�P�_���L�X�u�f�r�� **/
            sprintf_s(s0_real_premium, sizeof s0_real_premium,"                                 %s", bak1);           /*�`�O�I�O    */
            sprintf_s(s_real_premium, sizeof s_real_premium,"���N�O�O %s"   , bak1); /*�b��Ĥ@��  */
            sprintf_s(s1_real_premium, sizeof s1_real_premium,"�O�O %s"      , bak1); /*���ڲĤ@��  */
        }
        else
        {
            /*sprintf_s(s0_real_premium, sizeof s0_real_premium,"�����O��w�ɦ��O�O�u�f�� %s", bak1);*/              /*�`�O�I�O    */
            sprintf_s(s0_real_premium, sizeof s0_real_premium,"�����O��w�ɦ��O�O�u�f�� %s", bak1_ply);              /*�`�O�I�O    */
            sprintf_s(s_real_premium, sizeof s_real_premium,"���N�O�O %s �u�f %s ���N�ꦬ %s"   , bak3,bak2,bak1);  /*�b��Ĥ@��  */
            sprintf_s(s1_real_premium, sizeof s1_real_premium,"�O�O %s  �u�f %s  �ꦬ %s"          , bak3,bak2,bak1);/*���ڲĤ@��  */
        }
    }

    sprintf_s(s2_real_premium, sizeof s2_real_premium,"%s  �X�p�O�O %s",s_prem21,bak31); /*�b��ĤG��  */
    strcpy(s2_real_premium,ltrim(s2_real_premium));
    num_to_chinese(bak_chiness,real_premium);                  /*�Ĥ@�p���B����j�g  */
    strcpy(bak_chiness,trim(bak_chiness));
    strcat(bak_chiness,"����");

    if(strncmp(ibroker,"ZZZZZ",5)==0)
    {
        strcpy(new_ibroker,ibroker);
        strcpy(dsc_ibroker,"������O����");
    }
    else
    {
        strcpy(new_ibroker,ibroker);
        strcpy(dsc_ibroker," ");
    }

    if (plia_align==0)  s_lia_align[0]='\0';
    else  sprintf_s(s_lia_align, sizeof s_lia_align, "%d", plia_align);

    /* car9803242 */
    /* �Y�O�����~��(policy.iextra_charge = '40')�H�ο�ܦ��u�f,�C�ܥXdirect_disc_98�����e */
    strcpy(prem_note1," ");
    if (strncmp(iextra_charge,"40",2) == 0 && strncmp(sIkind,"1",1) == 0)
    {
    	strcat(s_real_premium,direct_disc_98);
    	strcat(s1_real_premium,direct_disc_98);
    	strcpy(prem_note1,direct_disc_98);
    }

    /* �����w�r�p�H�W�U add by sylvia 101.06.22 */
    if (iQprovision > 0 || provision_J == 1)
    {
		printf("2808\n");
		strcpy(sTmpIassured, " ");
		strcpy(sTmpIassured1, " ");
		strcpy(sTmpNiassured, " ");
		strcpy(sTmpDbirth, " ");
		strcpy(sTmpDbirth1, " ");
		strcpy(sTmpDbirth_yy, " ");
		strcpy(sTmpDbirth_mm, " ");
		strcpy(sTmpDbirth_dd, " ");
		
		if(provision_J == 1) strcpy(sProvD,"�S�w�γ~�[�T�w�ϥΤH�ӫ~�ΦW�U:");
		else strcpy(sProvD,"���w�r�p�H�ӫ~�ΦW�U:");
		
		strcpy(sProvD_1," ");
		strcpy(sProvD_2," ");

		iCounD = 0;
		ninsD_cnt = 0;
		$DECLARE cur_provd CURSOR for
		  SELECT trim(a.iins_type)||(SELECT nins_abbr FROM insurance_type WHERE iins_type = a.iins_type),
		         (SELECT count(*) FROM ply_ins_type WHERE ipolicy = a.ipolicy AND (trim(nvl(provision,' '))||';' like '%D;%' OR trim(nvl(provision,' '))||';' like '%J;%'))
		    FROM ply_ins_type a
		   WHERE a.ipolicy = $ipolicy
		     AND (trim(nvl(a.provision,' '))||';' like '%D;%' or trim(nvl(a.provision,' '))||';' like '%J;%')
		   GROUP BY 1,2;
		$OPEN cur_provd;
		while (1)
		{
			$FETCH cur_provd INTO $ninsType,$ninsD_cnt;

			if (SQLCODE == SQLNOTFOUND) break;
	
			iCounD ++;
	
			strcat(sProvD, rtrim(ninsType));
	
			if (iCounD < ninsD_cnt) strcat(sProvD, "�B");
			else strcat(sProvD, "�C");
		}

		iCounD = 0;
		ninsD_cnt = 0;
		$DECLARE cur_provd1 CURSOR for
		  SELECT iassured, nassured,year(dbirth)-1911||to_char(dbirth,'/%m/%d'),
		         (SELECT count(*) FROM ply_ins_assured WHERE ipolicy = a.ipolicy AND (trim(nvl(provision,' '))||';' like '%D;%' OR trim(nvl(provision,' '))||';' like '%J;%'))
		    FROM ply_ins_assured a
		   WHERE ipolicy = $ipolicy
		     AND (trim(nvl(provision,' '))||';' like '%D;%' or trim(nvl(provision,' '))||';' like '%J;%')
		   GROUP BY 1,2,3,4;
		$OPEN cur_provd1;
		while (1)
		{
			$FETCH cur_provd1 INTO $sTmpIassured1,$sTmpNiassured,$sTmpDbirth1,$ninsD_cnt;
			
			if (SQLCODE == SQLNOTFOUND) break;
			
			printf("2854---iCounD[%d]\n",iCounD);		
			iCounD ++;
			/* �Q�O�I�H�Ӹ�B�n */
			if (strncmp(sProtectData,"0",1) != 0)
			{
				strcpy(sTmpIassured,substring(sTmpIassured1,1,4));
				strcat(sTmpIassured,"****");
				strcat(sTmpIassured,substring(sTmpIassured1,9,2));
				cm_char_split_3ymd(sTmpDbirth1, sTmpDbirth_yy, sTmpDbirth_mm, sTmpDbirth_dd);
				strcpy(sTmpDbirth_yy,trim(sTmpDbirth_yy));
				sprintf_s(sTmpDbirth, sizeof sTmpDbirth,"***/%s/*%s",sTmpDbirth_mm,substring(sTmpDbirth_dd,2,2));
			}
			else
			{
				strcpy(sTmpIassured,trim(sTmpIassured1));
				strcpy(sTmpDbirth,trim(sTmpDbirth1));
			}
			
			if (iCounD <= 2)
			{
				strcat(sProvD_1, rtrim(sTmpIassured));
				strcat(sProvD_1, " ");
				strcat(sProvD_1, rtrim(sTmpNiassured));
				strcat(sProvD_1, " ");
				strcat(sProvD_1, rtrim(sTmpDbirth));
				if (iCounD == 1 && ninsD_cnt >= 2)
					strcat(sProvD_1, "�B");
			}
			else
			{
				strcat(sProvD_2, rtrim(sTmpIassured));
				strcat(sProvD_2, " ");
				strcat(sProvD_2, rtrim(sTmpNiassured));
				strcat(sProvD_2, " ");
				strcat(sProvD_2, rtrim(sTmpDbirth));
				if (iCounD == 3 && ninsD_cnt >= 4)
					strcat(sProvD_2, "�B");
			}
			printf("2876---iCounD[%d]ninsD_cnt[%d]\n",iCounD,ninsD_cnt);
		}
	}
   
    /* 1071107007_SC2_UBI�{���W�u */
	if(provision_U == 1)  strcpy(sProvD,"�i���O����[UBI���ڡj");

    /* �C�L�t�ƪ��B (1031014003_C1) */
	if (mequipment > 0)
	{
	    sprintf_s(sMequipment, sizeof sMequipment,"�t�ƪ��B(�w�]�t�b����/�ѵs�O�I���B��)�G%4.1f�U",mequipment);
	    strcpy(sProvD,trim(sProvD));
	    if(strlen(sProvD) == 0)  strcpy(sProvD,trim(sMequipment));
	    else  strcat(sProvD,trim(sMequipment));
	}
	
    printf("end of getdata\n\n");
    return M_CM_OK;
    
errexit:
	printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
	return SQLCODE;
}

/*--------------------------------------------------------------------*/
long ca_freeform(iprint, Ireceipt2, sErrMsg)
$char iprint[11];
$char Ireceipt2[11];
char *sErrMsg;
{
    $double p_no = 0;
    $char p_iins_type[7],p_nins_type[17],p_main_paid[17],p_qcoverage[21],p_qcoverage_amt[11];
    $char p_deduct[13],p_mpremium[14], sIpolicyTmp[21],p_field_tmp[38];
    int i,j,ben_len=0,len=0,ben_len_t=0,x;
    char tmp_address[100];
    char tmp_nassured[200],tmp_nassured_t[200];
    char tmp_nassured1[63],tmp_nassured1_t[63];
    char tmp_nassured2[63],tmp_nassured2_t[63];
    char tmp_nassured3[19], tmp_nassured4[63], tmp_nassured4_t[63],tmp_nassurC[29];
    char tmp_napplicant[200],tmp_napplicant_t[200],tmp_napplicant1[63];
    char nbenef_f[2];
    char sTmpbuf1[11],sTmpbuf2[11],sTmpbuf3[11],sTmpbuf4[12];
    char tax_area1[3];
    char tax_area2[3];
    char print_premium[200];
    char s_mcar_price[8];
    $char str_dbirth[10], sTmtx[1024], sTmp[250], sTmp1[250], sTmpPsexAge[34], sTmp2[250], sTmp3[250];
    int iins_cnt=0;     /* �ΨӧP�_�I�جO�_���L��,�L����iins_cnt = 1, �L�����h��0 */
    long sum_ins_premium;
    char tmp_575960[40];
    char tmpNameDrate[16];
    char tmpstr_print[38];
    char str_print[38];
    char s_Nassured[101], s_Napplicant[101], sNapp1[122], sNass1[122];
    int  iTmp1;
    $int  chk_finvalid;
    $char sTmpsql[1200];
    $char tmp_acc[40];/* 1051214006_C2_�]���D�޾������ܤ����X�W���l�I�U�[�ΰӫ~�s�W�����ܧ�O�v�ץ� */
    
    int tok=4;
    /* ���ڽs�� */
    $char sToday1[11],sToday2[11],ireceipt[11],idb[3], iversion[2], stmpx[2000];
    $int res;
    $varchar ntarget2[121];
    $char iendorse_tmp[21];

    $int cnt_ncont,cnt_ncont2;
    $char ncont1_1[81],ncont1_2[81],ncont2_1[81],ncont2_2[81],stmt_ncont[512];
	
    $int cnt_receipt=0,prem_receipt=0,receipt_print=0;
    $char tmp_receipt[11],receipt_dbegin[11],receipt_dend[11],receipt_nassured[101],receipt_napplicant[101];
    $char receipt_dbegin_100[11],receipt_dend_100[11];
    $long i_rebegin=0,i_reend=0;
    
    $long edrprem=0;
    
    $char nofficer_tmp[26],nleader[11],nleader_tmp[26];
    $int  fcandv = 0;
    $int  iout_draw = 0;
	$int  ino_outside = 0;

    $WHENEVER SQLERROR GOTO errexit;

    tmpNameDrate[0] = '\0';
    strcpy(stmp_space, " ");

    /*======== ��������������  �H�U�P�_�O�_�����ڽs���άO�_�C�L����  �������������� ========*/
    /*=====       bufa_print (0:�n�����ڽs�� 1:�������ڽs��)             =====*/
    /*=====       receipt_print (0:���C�L���ڽs�� 1:�C�L���ڽs��)        =====*/
    /*=====       bufa_print2 (0:���C�L�ɵo�r�� 1:�C�L�ɵo�r��)          =====*/
    
    /* �s�W�q�l��榬�ڡA���B>0�n��ܧ����B */

    /* 1060818001_C1_cmn134a-���I */
    bufa_print = 0;
    receipt_print = 0;
    bufa_print2 = 1;
    
    printf("reprint[%s]\n",reprint);
    if(strcmp(reprint,"0") == 0)  bufa_print2 = 0;
    printf("bufa_print2[%d]\n",bufa_print2);
    
    if(strcmp(reprint,"�ɵo") == 0 || strcmp(reprint,"0") == 0 || strlen(iendorse_free) > 0)
    {
    	/* �����B=0�ɡA��ӯȥ��O��ɵo���q�l�O��ɪ����ڲ��s�W�h */
    	/* �����B<0�ɡA��ӧ��O�O=0���q�l���A���N�즬�ڧ@�o�A�Y�i���s�s���ڡA���@�o�h���s���ڤw�}�ߪ����� */
    	/* �ɵo���O�� �� ���B=0����� �� ���B<0����� */
    	
		printf("X1\n");
		bufa_print = 1;
		cnt_receipt = 0;
		chk_finvalid = 0;
		
		edrprem = 0;
		if(strlen(iendorse_free) > 0)
		{
			strcpy(Full_DBName,get_car_full_db(ipolicy));
			
			sprintf_s(sTmtx, sizeof sTmtx, 
			                 "SELECT (medrdmg_prem+medrlia_prem) \
	                            FROM %s:edr_relation \
	                           WHERE iendorse = '%s'", Full_DBName,iendorse_free);
			printf("sTmtx[%s]\n", sTmtx);
			$PREPARE edrprem_cur1 FROM $sTmtx;
			$DECLARE edrprem CURSOR FOR edrprem_cur1;
			$OPEN edrprem;
			$FETCH edrprem INTO $edrprem;
			$CLOSE edrprem;
			$FREE  edrprem;
		}

		if(edrprem > 0) 
			bufa_print = 0;
		else 
		{
			/* ���o���@�o���ڵ��� : cnt_receipt*/	
			$SELECT count(*)
			   INTO $cnt_receipt
			   FROM cm_receipt_log
			  WHERE ireceipt IN (SELECT ireceipt FROM cm_receipt_log_dtl WHERE ipolicy = $ipolicy)
			    AND finvalid = 0;
			
			if(bufa_ins_17 == 1 || bufa_ins_19 == 1)
			{
				bufa_print = 0;
				bufa_ins_17 = 0;
				bufa_ins_19 = 0;
			}
			else if ( iofficer[0] == 'A' || iofficer[0] == 'B' || iofficer[0] == 'J' || strncmp(sIpolicyB_type,"1",1) == 0 )
			{
				/*�M�ץ�*/
				/*�P�_��l�O�榬�ڬO�_�Ҥw�@�o*/
				$SELECT count(*)
				   INTO $chk_finvalid
				   FROM cm_receipt_log
				  WHERE ireceipt IN (SELECT ireceipt FROM cm_receipt_log_dtl WHERE ipolicy = $ipolicy AND iendorse='' AND ireceipt[4]!='9')
				    AND finvalid = 0;
				
				if(chk_finvalid==0)
				{
					bufa_print = 0;
				}
				else
				{
					receipt_print = 0;
				}	
			}
			else
			{
				if(cnt_receipt == 0 )  /*�N�����ڳ��w�g���o  �ݭn�����@�Ӧ��ڨæL�X*/
				{
					bufa_print = 0;
				}
				else if(cnt_receipt == 1 )  /*�Y���ڥu���@��  �����B�B�O���B�n�Q�O�H����W�١A�Y�ҬۦP�h�L�X�����ڽs��*/
				{
					prem_receipt = 0;
					$SELECT mprem_cur,ireceipt,dbegin,dend,nassured,napplicant
					   INTO $prem_receipt,$tmp_receipt,$receipt_dbegin,$receipt_dend,$receipt_nassured,$receipt_napplicant
					   FROM cm_receipt_log
					  WHERE ipolicy =  $ipolicy
					    AND finvalid = 0;
				
					if(SQLCODE == SQLNOTFOUND) 
						receipt_print = 0;
					else
					{
						printf("prem_receipt[%d] premium1[%d] \n",prem_receipt,premium1);
							
						strcpy(receipt_dbegin_100,cm_from_infdate_100(receipt_dbegin));
						i_rebegin = cm_ymd_cdate(receipt_dbegin_100);
						strcpy(receipt_dend_100,cm_from_infdate_100(receipt_dend));
						i_reend = cm_ymd_cdate(receipt_dend_100);
							
						printf("i_rebegin[%d] i_reend[%d] \n",i_rebegin,i_reend);
						printf("i_begin[%d] i_end[%d] \n",i_begin,i_end);
						strcpy(nassured,rtrim(nassured));
						strcpy(napplicant,rtrim(napplicant));
						strcpy(receipt_nassured,rtrim(receipt_nassured));
						strcpy(receipt_napplicant,rtrim(receipt_napplicant));
						printf("nassured[%s] napplicant[%s] \n",nassured,napplicant);
						printf("receipt_nassured[%s] receipt_napplicant[%s] \n",receipt_nassured,receipt_napplicant);
							
						if(ireceipt[3] == "9") /*��}����(�ĥ|�X��9) �]�n��ܦ��ڤw�}��*/
						{
							receipt_print = 0; 
						}
						else if((premium1 == prem_receipt) && (i_rebegin == i_begin) && (i_reend == i_end) && (strcmp(receipt_nassured,nassured)==0) && (strcmp(receipt_napplicant,napplicant)==0) ) 
						{
							/*���B�B�O���B�n�Q�O�H����W�٬ҬۦP�h�C�L�L�L�����ڽs��*/
							receipt_print = 1;
							strcpy(ireceipt,tmp_receipt);
						}
						else 
							receipt_print = 0; 
					}
				}
				else 
				{
					/*�Y���ŦX�W�z����h�k�䦬�ڤ��C�L ��ܦ��ڤw�}��*/
					receipt_print = 0;
				}
				
				/* �����B<=0�A���C�L���� */
				if (strlen(iendorse_free) > 0 && edrprem<= 0) strcpy(freceipt_tmp,"N");
			}
		}
        if(receipt_print == 0)  strcpy(ireceipt," ");
    }
	
	/* �����ڽs�� add by sylvia 100.05.19 */
	strcpy(sToday1,cm_edate_str(cm_today()));
	strcpy(sToday2, cm_cdate_str_100(cm_today()));
	if(bufa_print == 0)
	{
		int iTryCnt;
		iTryCnt =0;
		
		strcpy(Ireceipt_2,Ireceipt2);
		printf("2+++++Ireceipt_2[%s]\n",Ireceipt_2);
		strcpy(Ireceipt_2,trim(Ireceipt_2));
		
		RETRY:
		if(strlen(Ireceipt_2)==0)
		{
			res = cm_get_serial_num_dwritten("CM","R1","0","00",sToday1,sToday2,ireceipt);

			if (res != 0) {
			    iTryCnt++;
			    if (iTryCnt > 3)  
			    {
			    	strcpy(sErrMsg, "���ڨ������ѡA�Э��s�C�L");
			    	return res;
			    }
			    sleep(1);
			    goto  RETRY;
			}
			printf("res=[%d]sToday1=[%s]sToday2=[%s]ireceipt=[%s]\n",res,sToday1,sToday2,ireceipt);
		}
		else 
			strcpy(ireceipt,Ireceipt_2);
		
		strcpy(ireceipt,trim(ireceipt));
	}
	printf("-------------------------------------------------------- \n");  
	printf("in ca_freeform \n");
	/* �O��C�L�g�Jca_freeform */
	long *icolumn;
	$long icolumn_edr;
	$char sTmp2_1[50],sTmp2_2[50],sTmp2_3[50],sTmp2_4[50],sTmp2_5[50],sTmp2_W[50];
	
	printf("iendorse_free[%s] \n",iendorse_free);
	/* icolumn��l */
	if(strlen(iendorse_free) == 0) 
	{
		icolumn = 1; 
	}
	else 
	{
		/* �q�l���n����g�J */
		/* ����END */
		$SELECT MAX(iline) INTO $icolumn_edr FROM ca_freeform WHERE kpid = $kpid AND inumber = $iendorse_free;
		$DELETE FROM ca_freeform WHERE kpid = $kpid AND inumber = $iendorse_free AND iline = $icolumn_edr;
		icolumn = icolumn_edr;
	}
	printf("--icolumn[%d] \n",icolumn);
	
	/* �򥻮榡�w�qH00 */
	{
		insert_freeform(&icolumn,"H00");
		
		/* ��B���L(0:���L�B���L 1:�[�L�צ��u���աv�B���L) */
		insert_freeform(&icolumn,"0");
		
		/* �q�l�O��(0:�ȥ� 1:�q�l�O��) */
		if(strncmp(ipolicy+5,"VW",2)==0)
			insert_freeform(&icolumn,"0");
		else 
			insert_freeform(&icolumn,feply2);
		
		/* �ۥ���~�O(0:����� 1:�ۥ� 2:��~) */
		if(strcmp(icar_type_ori,"4A")==0||strcmp(icar_type_ori,"2A")==0||strcmp(icar_type_ori,"2B")==0)
			insert_freeform(&icolumn,"2");
		else 
			insert_freeform(&icolumn,fcar_class);
		
		/* �ɵo�O(0:�ť� 1:�ɵo) */
		if(strcmp(reprint,"�ɵo") == 0)
			insert_freeform(&icolumn,"1");
		else 
			insert_freeform(&icolumn,"0");

		/* �ߴڬ����Y�ƤΦ~�֩ʧO�Y��(0:���C�L 1:�C�L) */
		if (strncmp(ipolicy+5,"EB",2)==0 || strncmp(ipolicy+5,"VW",2)==0)  
			insert_freeform(&icolumn,"0");
		else 
			insert_freeform(&icolumn,"1");
			
		/* �O��C�L�W�h(����v�H�ɻݭn)[V1:����O��(�t����)/��� V2:����O��(�t����)] */
		if ((strcmp(trim(nbenef),"") == 0) ||(strcmp(trim(nbenef),'\0') == 0)) /* �L����v�H */
			insert_freeform(&icolumn,"V1");
		else if (strcmp(reprint,"�ɵo") == 0 || strcmp(reprint,"0") == 0)      /* �ɵo�u�n�@�� */
			insert_freeform(&icolumn,"V1");
		else if (strncmp(ipgid_tmp,"car301",6)==0)                             /* car301������v�H�]�u�L�@�� */
			insert_freeform(&icolumn,"V1");
		else                                                                   /* �����C�L������v�H�n�L����O��A��car306 */
			insert_freeform(&icolumn,"V2");
		
		/* �O�T�I�����r(0:���C�L 1:��b���ƥѻ�����) */
		if (strncmp(ipolicy+5,"VW",2)==0)
			insert_freeform(&icolumn,"1");
		else 
			insert_freeform(&icolumn,"0");
	
		/* �q�ʦۦ樮�����r��(0:���C�L 1:�C�L) */
		if(strncmp(ipolicy+5,"EB",2)==0 && strncmp(ipgid_tmp,"car307a",7)!=0)
			insert_freeform(&icolumn,"1");
		else 
			insert_freeform(&icolumn,"0");
		
		/* ���ڤw�}��(0:������ 1:��ܦ��ڤw�}��) */
		if (bufa_print == 1 && receipt_print == 0)
			insert_freeform(&icolumn,"1");
		else
			insert_freeform(&icolumn,"0");
		
		/* 1130319005_C01_�n���q�H�c-�j���I+���N�I���� */
		/* ���ڪ����O(0:���C�L(��椣�C�L����) 1:���t�j��� 2:�j��+���N����+QRCODE) */
		fcandv = 0;
		printf("r_feply[%s] feply2[%s] r_fout_print[%s] r_fmail_type[%s] r_iofficer[%s] iofficer[%s] itmp_policy[%s] r_itmp_policy[%s]\n",r_feply,feply2,r_fout_print,r_fmail_type,r_iofficer,iofficer,itmp_policy,r_itmp_policy);
		
		if ((irelative_ply[0] != '\0')                     &&
		    (r_feply[0] == '0' && feply2[0] == '0')        &&
		    (strcmp(trim(r_iofficer),trim(iofficer)) == 0) &&
		    (strcmp(itmp_policy,r_itmp_policy) == 0))    
		{
			chk_card_print = 0;
			/*
				1.�j��+���N�Ҭ��ȥ� 
				2.�P�@�g��
				3.�P�@�����渹
				3.�ư��O�NC*�q��
				4.�ư��e�~��
				5.���bCar344(ca_out_draw) 
				6.�ɵo
			*/
			iout_draw = 0;
			$SELECT count(*)
			   INTO $iout_draw
			   FROM ca_out_draw 
			  WHERE ipolicy = $ipolicy
			    AND fout_type = '0';

			/* �j���I�O�渹�����P��j���I�Ҹ��A�Y�L�j���I�Ҹ��A�u�C�L����N�I���� (1140227009_C01) */			
			ino_outside = 0;

			sprintf_s(sTmtx, sizeof sTmtx, 
			"SELECT count(*) \
			   FROM %s \
			  WHERE ipolicy = '%s' \
			    AND ipolicy = icard;",tableRelation, irelative_ply);
   			printf("sTmtx[%s]\n", sTmtx);
   			$PREPARE no_outside_cur FROM $sTmtx;
   			$DECLARE ino_outside CURSOR FOR no_outside_cur;
   			$OPEN  ino_outside;
   			$FETCH ino_outside INTO $ino_outside;
   			$CLOSE ino_outside;
   			$FREE  ino_outside;	

			if (strncmp(iofficer,"C",1) == 0 || 
			    (fout_print[0] == '1' && fmail_type[0] != '0') ||
			    iout_draw > 0 ||
			    strncmp(ipgid_tmp,"car307a",7) == 0 ||
				ino_outside > 0)
			{
				insert_freeform(&icolumn,"1");
			}
			else 
			{
				insert_freeform(&icolumn,"2");
				fcandv = 1;
			}
		}
		else 
		{
			insert_freeform(&icolumn,"1");
		}
		
		/* �٭��ª����� */
		/* insert_freeform(&icolumn,"1"); */
		
		/* �O�_��ܱj���Ҹ�(0:���C�L 1:�C�L���D�Τ��e) */
		/* �Y�L�j���I�Ҹ��A����� (1140227009_C01) */
		if (irelative_ply[0] != '\0' && ino_outside == 0)       /* �����p�渹����ܱj���� */
		{
			insert_freeform(&icolumn,"1");
		}
		else 
			insert_freeform(&icolumn,"0");
		
		/* �L�����(0:���C�L 1:�g�v�� 2:�v��) */
		if (fsex_appl[0] == '1' || fsex_appl[0] == '2')
			insert_freeform(&icolumn,"1");
		else 
			insert_freeform(&icolumn,"2");

		/* �y����(0:���C�L) */
		if(strncmp(ipolicy+5,"VW",2)==0)
			insert_freeform(&icolumn,"0");
		else 
		{
			res = cm_get_serial_num_dwritten("C2","SE","0","00",sToday1,sToday2,iserial);

			int iTryCnt2;
			iTryCnt2 = 0;
			RETRY2:
			if (res != 0) {
			    iTryCnt2++;
			    if (iTryCnt2 > 3) 
			    { 
			    	strcpy(sErrMsg, "�O��y�����������ѡA�Э��s�C�L");
			    	return res;
				}
			    sleep(1);
			    goto  RETRY2;
			}
			
			printf("res=[%d] sToday1=[%s] sToday2=[%s] iserial=[%s] \n",res,sToday1,sToday2,iserial);
			strcpy(iserial,trim(iserial));
			
			insert_freeform(&icolumn,iserial);
		}
		/* �ݥ��ˬd�X */
		insert_freeform(&icolumn,"Q");
	}

	/* �q�θ�� */
	{
		/* �n�Q�O�H��� */
		/* --------------------------------------------------------------------------- */
		/* ����H */
		strcpy(tmp_napplicant,rtrim(napplicant));
		if(strncmp(icar_type,"15",2) != 0)
		{
			/* 1130129008_C03_�վ�C�L���t�����ͤp�j�A�אּ�g�A��S�վ㲾���g */
			/*if (fsex_appl[0] == '1')
			    strcat(tmp_napplicant," ����");
			else if (fsex_appl[0] == '2')
			    strcat(tmp_napplicant," �p�j");*/
		}
		strcpy( tmp_napplicant_t, tmp_napplicant);
		ben_len=cc_split_chinese(tmp_napplicant_t,tmp_napplicant1,62);
		
		/* �Q�O�I�H */
		/* �W�r�W�h�P�_ */
		printf("nuser[%s] \n",nuser);
		strcpy(tmp_nassured,rtrim(nassured));

		if(strncmp(icar_type,"15",2) != 0)
		{
			/* 1130129008_C03_�վ�C�L���t�����ͤp�j�A�אּ�g�A��S�վ㲾���g */
			/*if (fsex[0] == '1')
			    strcat(tmp_nassured," ����");
			else if (fsex[0] == '2')
			    strcat(tmp_nassured," �p�j");*/
			/*strcat(tmp_nassured," �g");*/
		}
		strcpy(tmp_nassured_t,tmp_nassured);

		if (nuser[0]!=' ' && nuser[0]!='\0')
		{
			strcat(tmp_nassured," �ϥΤH: ");
			strcat(tmp_nassured,rtrim(nuser));
		}
		
		strcpy( tmp_nassured4_t, tmp_nassured);
		ben_len=cc_split_chinese(tmp_nassured4_t,tmp_nassured4,62);
		ben_len=cc_split_chinese(tmp_nassured,tmp_nassured1,62);
		if(strlen(tmp_nassured)>62)
			ben_len=cc_split_chinese(&tmp_nassured[ben_len],tmp_nassured2,62);
		else
			strcpy(tmp_nassured2," ");
		
		ben_len_t=cc_split_chinese(tmp_nassured_t,tmp_nassured1_t,62);
		if(strlen(tmp_nassured_t)>62)
			ben_len_t=cc_split_chinese(&tmp_nassured_t[ben_len_t],tmp_nassured2_t,62);
		else
			strcpy(tmp_nassured2_t," ");
			
		ben_len_t=cc_split_chinese(tmp_nassured,tmp_nassured3,18);
		/* --------------------------------------------------------------------------- */
		
		/* ���� */
		aassured[76]=0;
		if (aassured_zip[0]!=' ' && aassured_zip[0]!='\0')
			sprintf_s(aassured_cmb, sizeof aassured_cmb,"%s ",trim(aassured_zip));
		else
			strcpy(aassured_cmb,"");
		
		strcat(aassured_cmb,aassured);
		
		/* �������� */
		ncar_type[0] = '\0';
		strcpy(ncar_type, trim(icar_type));
		strcat(ncar_type, " ");
		strcat(ncar_type, trim(ncar_abbr));
		
		/* �t�P�����W�� */
		if(strncmp(ipolicy+5,"VW",2)==0)
		{
			$SELECT nbrand
			   INTO $nbrand
			   FROM ca_car_model
			  WHERE ibrand = $ibrand
			    AND ipro_year = $ipro_year
			    AND (dexpire is null or dexpire > today)
			    AND drate = (SELECT drate 
			                   FROM ca_rate_date 
			                  WHERE icode = $drate_ym
			                    AND itable = 'ca_car_model');
			printf("[=ipro_year] SQLCODE[%d] nbrand[%s]\n",SQLCODE,nbrand);
			if (SQLCODE==SQLNOTFOUND)
			{
				$SELECT nbrand
				   INTO $nbrand
				   FROM ca_car_model a
				  WHERE ibrand = $ibrand
				    AND ipro_year = (SELECT MAX(ipro_year)
				                       FROM ca_car_model
				                      WHERE ibrand = $ibrand
				                        AND ipro_year < $ipro_year 
				                        AND drate = a.drate
				                        AND (dexpire is null or dexpire > today))
				    AND (dexpire is null or dexpire > today)
				    AND drate = (SELECT drate 
				                   FROM ca_rate_date 
				                  WHERE icode = $drate_ym
				                    AND itable = 'ca_car_model');
				 printf("[<ipro_year] SQLCODE[%d] nbrand[%s]\n",SQLCODE,nbrand);
			                    
				if (SQLCODE==SQLNOTFOUND)
				{
					$SELECT nbrand
					   INTO $nbrand
					   FROM ca_car_model  a
				      WHERE ibrand = $ibrand
				        AND ipro_year = (SELECT MAX(ipro_year)
				                           FROM ca_car_model
				                          WHERE ibrand = $ibrand
				                            AND ipro_year > $ipro_year
				                            AND drate = a.drate
				                            AND (dexpire is null or dexpire > today))
				        AND (dexpire is null or dexpire > today)
				        AND drate = (SELECT drate 
				                       FROM ca_rate_date 
				                      WHERE icode = $drate_ym
				                        AND itable = 'ca_car_model');
					printf("[>ipro_year] SQLCODE[%d] nbrand[%s]\n",SQLCODE,nbrand);
					if (SQLCODE==SQLNOTFOUND)
					{
						strcpy(nbrand," ");
						printf("--�t�ΨS���]�w���t�P�����N��?? ibrand[%s]\n",ibrand);
					}
				}
			}
		}
		
		/* �Ʈ�q */
		strcpy(s_qcylinder2, s_qcylinder);
		/*if (strncmp(ibrand+6,"01",2)==0) strcat(s_qcylinder2, "HP");*/
		
		/* �������� */
		s_pt[0] = '\0';
		strcpy(s_pt, ltrim(s_qpt));
		strcat(s_pt, " ");
		strcat(s_pt, trim(s_fpt));
		
		/* ����/����/���[���X */
		if(strlen(trim(iengine)) == 0) strcpy(iengine,ibody);
		strcpy(iengine_0,"");
		strcat(iengine_0,iengine);
		
		/* �g��W�� */
		$SELECT nname INTO $nofficer FROM officer WHERE iofficer = $iofficer;
		strcpy(nofficer,rtrim(nofficer));
		
		/* �޲z�H�W�� */
		$SELECT nname INTO $nleader FROM officer WHERE iofficer = $ileader;
		strcpy(nleader,rtrim(nleader));
	}
	
	/* ����RECEIPT */
	if (freceipt_tmp[0] == 'Y') /* �O�_�C�L���� */
	{
		if (fcandv == 0)
		{
			insert_freeform(&icolumn,"RECEIPT");
			
			/* �l�H�a�} */
			sTmp1[0] = '\0';
			sTmp2[0] = '\0';
			sTmp2_W[0] = '\0';
			strcpy(sTmp1,trim(apayment_zip));
			strcpy(sTmp2,sTmp1);
			for (int i=0;i<7-strlen(sTmp2);i++)
			{
				strcat(sTmp2_W," ");
			}
			strcat(sTmp1,sTmp2_W);
			strcat(sTmp1, trim(apayment));
			ben_len=cc_split_chinese( sTmp1, sTmp, 104);
			insert_freeform(&icolumn,sTmp);
			
			/* ����H */
			insert_freeform(&icolumn,tmp_napplicant1);
			
			/* �L���� */
			tax_area[4]='\0';
		    strncpy(tax_area1,tax_area,2);
		    tax_area1[2] = '\0';
		    strcpy(tax_area2,tax_area+2);
		    tax_area2[2] ='\0';
		    
		    /* �L����1 */
			insert_freeform(&icolumn,tax_area1);
			
			/* �L����2 */
			insert_freeform(&icolumn,tax_area2);
			
			/* �t�d�H */
			insert_freeform(&icolumn,npresident);
			
			/* �I�� */
			if (strncmp(ipolicy+5,"EB",2)==0)
				insert_freeform(&icolumn,"�q�ʦۦ樮��X�O�I");
			else if(strncmp(ipolicy+5,"ES",2)==0)
				insert_freeform(&icolumn,"�ۥΥR�q�κ�X�O�I");
			else 
				insert_freeform(&icolumn,"�T��");
			
			/* ���(�~) */
			insert_freeform(&icolumn,yy5);
			
			/* ���(��) */
			insert_freeform(&icolumn,mm5);
			
			/* ���(��) */
			insert_freeform(&icolumn,dd5);
			
			/* ���ڽs�� */
			insert_freeform(&icolumn,ireceipt);
			
			/* �O�I�渹 */
			sTmp1[0] = '\0';
			strcpy(sTmp1,"17");
			strcat(sTmp1,trim(ipolicy));
			if(strlen(iendorse_free) > 0)
			{
				strcat(sTmp1,"(��渹");
				strcat(sTmp1,iendorse_free);
				strcat(sTmp1,")");
			}
			insert_freeform(&icolumn,sTmp1);
			
			/* ��渹�X */
			insert_freeform(&icolumn," ");
	
			/* �Q�O�I�H */
			insert_freeform(&icolumn,tmp_nassured4);
			
			/* �n�O�H */
			insert_freeform(&icolumn,tmp_napplicant1);
			
			/* �O�I�l��(�~) */
			insert_freeform(&icolumn,yy1);
			
			/* �O�I�l��(��) */
			insert_freeform(&icolumn,mm1);
			
			/* �O�I�l��(��) */
			insert_freeform(&icolumn,dd1);
			
			/* �O�I�״�(�~) */
			insert_freeform(&icolumn,yy2);
			
			/* �O�I�״�(��) */
			insert_freeform(&icolumn,mm2);
			
			/* �O�I�״�(��) */
			insert_freeform(&icolumn,dd2);
			
			/* �g��N��(�t����) */
			/* 1121002006_C01_FreeForm�t���u�� */
			strcpy(iofficer,rtrim(iofficer));
			strcpy(nofficer,rtrim(nofficer));
			sprintf_s(nofficer_tmp,sizeof nofficer_tmp,"%s %s",iofficer,nofficer);
			insert_freeform(&icolumn,nofficer_tmp);
	
			/* �޲z�H(�t����) */
			/* 1121002006_C01_FreeForm�t���u�� */
			if(strncmp(iroute,"JB",2)==0)
				insert_freeform(&icolumn,"����A�Ȥp��");
			else
			{
				strcpy(ileader,rtrim(ileader));
				strcpy(nleader,rtrim(nleader));
				sprintf_s(nleader_tmp,sizeof nofficer_tmp,"%s %s",ileader,nleader);
				insert_freeform(&icolumn,nleader_tmp);
			}
			
			/* �O�I�O1 */
			/* 1121002006_C01_FreeForm�t���u�� */
			if(strlen(iendorse_free) > 0)
				insert_freeform(&icolumn,itoa(edrprem));
			else 
				insert_freeform(&icolumn,bak3);
	
			/* �O�O���O����1 */
			/* 1121002006_C01_FreeForm�t���u�� */
			if(strlen(iendorse_free) > 0)
			{
				insert_freeform(&icolumn," ");
			}
			else 
			{
				insert_freeform(&icolumn,prem_note1);
			}
			
			/* ���P���X1 */
			/* 1121002006_C01_FreeForm�t���u�� */
			insert_freeform(&icolumn,itag);
			
			/* �q���N�� */
			insert_freeform(&icolumn,iroute);
			
			/* �q���W�� */
			insert_freeform(&icolumn,nname_N);
			
			/* �q���~�ȭ� */
			if ((ibig_sales[0] != '\0' && ibig_sales[0] !=' ') || (LHsNname[0] != '\0' && LHsNname[0] != ' '))
				insert_freeform(&icolumn,LHsNname);
			else 
				insert_freeform(&icolumn," ");
			
			/* �O�I�O2 */
			/* 1121002006_C01_FreeForm�t���u�� */
			if(strlen(iendorse_free) > 0)
				insert_freeform(&icolumn,itoa(edrprem));
			else 
				insert_freeform(&icolumn,bak3);
	
			/* �O�O���O����2 */
			/* 1121002006_C01_FreeForm�t���u�� */
			if(strlen(iendorse_free) > 0)
			{
				insert_freeform(&icolumn," ");
			}
			else 
			{
				if (prem21 > 0)
				{
					sprintf_s(prem_note, sizeof prem_note,"%s �X�p�O�O %s",prem_note2,bak31);
					insert_freeform(&icolumn,prem_note);
				}
				else 
					insert_freeform(&icolumn," ");
			}
			
			/* �ݥ��ˬd�X */
			insert_freeform(&icolumn,"Q");
		}
		else 
		{
			insert_freeform(&icolumn,"RECEIPT_CANDV");
			
			tax_area[4]='\0';
		    strncpy(tax_area1,tax_area,2);
		    tax_area1[2] = '\0';
		    strcpy(tax_area2,tax_area+2);
		    tax_area2[2] ='\0';
		    
		    /* �L����1 */
			insert_freeform(&icolumn,tax_area1);
			
			/* �L����2 */
			insert_freeform(&icolumn,tax_area2);
			
			/* �t�d�H */
			insert_freeform(&icolumn,npresident);
			
			/* �I�� */
			if (strncmp(ipolicy+5,"EB",2)==0)
				insert_freeform(&icolumn,"�q�ʦۦ樮��X�O�I");
			else if(strncmp(ipolicy+5,"ES",2)==0)
				insert_freeform(&icolumn,"�ۥΥR�q�κ�X�O�I");
			else 
				insert_freeform(&icolumn,"�T��");
			
			/* �j���Ҹ� */
			sprintf_s(icard_tmp,sizeof icard_tmp,"17%s",r_icard);
			insert_freeform(&icolumn,icard_tmp);
			
			/* �Q�O�I�H */
			insert_freeform(&icolumn,r_nassured);
			
			/* ���� */
			insert_freeform(&icolumn,r_aassured);
			
			/* ���ئW�� */
			$SELECT ncode INTO $r_ncar_type FROM car_type WHERE icode = $r_icar_type AND fclass = '1';
			insert_freeform(&icolumn,r_ncar_type);
			
			/* �t�P���� */
			insert_freeform(&icolumn,r_nbrand_abbr);
			
			/* ��l�o�Ӧ~�� */
			insert_freeform(&icolumn,r_ipro_year);
			
			/* �P�Ӹ��X */
			insert_freeform(&icolumn,r_itag);
			
			/* ���� */
			insert_freeform(&icolumn,r_iengine);
			
			strcpy(r_dply_begin_100,cm_from_infdate_100(r_dply_begin));
			cm_split_ymd_100(r_dply_begin_100, r_dply_begin_yy, r_dply_begin_mm, r_dply_begin_dd);
			/* �O�I�����_(�~) */
			insert_freeform(&icolumn,r_dply_begin_yy);
			
			/* �O�I�����_(��) */
			insert_freeform(&icolumn,r_dply_begin_mm);
			
			/* �O�I�����_(��) */
			insert_freeform(&icolumn,r_dply_begin_dd);
			
			strcpy(r_dply_end_100,cm_from_infdate_100(r_dply_end));
			cm_split_ymd_100(r_dply_end_100, r_dply_end_yy, r_dply_end_mm, r_dply_end_dd);
			/* �O�I������(�~) */
			insert_freeform(&icolumn,r_dply_end_yy);
			
			/* �O�I������(��) */
			insert_freeform(&icolumn,r_dply_end_mm);
			
			/* �O�I������(��) */
			insert_freeform(&icolumn,r_dply_end_dd);
			
			/* �ӫO��� */
			sprintf(s_r_qply_period, "%d", r_qply_period);
			insert_freeform(&icolumn,s_r_qply_period);

			tmp_prem = 0,other_prem = 0;
			/* �O�O(�U */
			tmp_prem=r_mpremium/10000;
			other_prem=r_mpremium%10000;
			num_to_chinese(ch_amt,tmp_prem);     /* �N���ԧB�Ʀr �ন ����j�g�Ʀr */
			if (tmp_prem==0) strcpy(ch_amt,"�s");
			strcpy(ch_amt01, ch_amt);
			strcpy(ch_amt01, trim(ch_amt01));
			insert_freeform(&icolumn,ch_amt01);
	
			/* �O�O(�a */				
			tmp_prem=other_prem/1000;
			other_prem=other_prem%1000;
			num_to_chinese(ch_amt,tmp_prem);
			if (tmp_prem==0) strcpy(ch_amt,"�s");
			strcpy(ch_amt02, ch_amt);
			strcpy(ch_amt02, trim(ch_amt02));
			insert_freeform(&icolumn,ch_amt02);
	
			/* �O�O(�� */
			tmp_prem=other_prem/100;
			other_prem=other_prem%100;
			num_to_chinese(ch_amt,tmp_prem);
			if (tmp_prem==0) strcpy(ch_amt,"�s");
			strcpy(ch_amt03,ch_amt);
			strcpy(ch_amt03, trim(ch_amt03));
			insert_freeform(&icolumn,ch_amt03);
	
			/* �O�O(�B */
			tmp_prem=other_prem/10;
			other_prem=other_prem%10;
			num_to_chinese(ch_amt,tmp_prem);
			if (tmp_prem==0) strcpy(ch_amt,"�s");
			strcpy(ch_amt04,ch_amt);
			strcpy(ch_amt04,trim(ch_amt04));
			insert_freeform(&icolumn,ch_amt04);
	
			/* �O�O(�� */			
			num_to_chinese(ch_amt,other_prem);
			if (other_prem==0) strcpy(ch_amt,"�s");
			strcpy(ch_amt05,ch_amt);
			strcpy(ch_amt05,trim(ch_amt05));
			insert_freeform(&icolumn,ch_amt05);		
			
			/* ���z�ɶ� */
			printf("dcreate[%s] \n",r_dcreate);
			insert_freeform(&icolumn,dcreate);

			/* �g��N�� */
			insert_freeform(&icolumn,r_iofficer);
			
			/* �޲z�H */
			insert_freeform(&icolumn,r_nleader);
			/*------------------------------------------------------------------------------*/
			/* ���(�~) */
			insert_freeform(&icolumn,yy5);
			
			/* ���(��) */
			insert_freeform(&icolumn,mm5);
			
			/* ���(��) */
			insert_freeform(&icolumn,dd5);
			
			/* ���ڽs�� */
			insert_freeform(&icolumn,ireceipt);
			
			/* �O�I�渹 */
			sTmp1[0] = '\0';
			strcpy(sTmp1,"17");
			strcat(sTmp1,trim(ipolicy));
			if(strlen(iendorse_free) > 0)
			{
				strcat(sTmp1,"(��渹");
				strcat(sTmp1,iendorse_free);
				strcat(sTmp1,")");
			}
			insert_freeform(&icolumn,sTmp1);
			
			/* ��渹�X */
			insert_freeform(&icolumn," ");
	
			/* �Q�O�I�H */
			insert_freeform(&icolumn,tmp_nassured4);
			
			/* �n�O�H */
			insert_freeform(&icolumn,tmp_napplicant1);
			
			/* �O�I�l��(�~) */
			insert_freeform(&icolumn,yy1);
			
			/* �O�I�l��(��) */
			insert_freeform(&icolumn,mm1);
			
			/* �O�I�l��(��) */
			insert_freeform(&icolumn,dd1);
			
			/* �O�I�״�(�~) */
			insert_freeform(&icolumn,yy2);
			
			/* �O�I�״�(��) */
			insert_freeform(&icolumn,mm2);
			
			/* �O�I�״�(��) */
			insert_freeform(&icolumn,dd2);
			
			/* �g��N��(�t����) */
			/* 1121002006_C01_FreeForm�t���u�� */
			strcpy(iofficer,rtrim(iofficer));
			strcpy(nofficer,rtrim(nofficer));
			sprintf_s(nofficer_tmp,sizeof nofficer_tmp,"%s %s",iofficer,nofficer);
			insert_freeform(&icolumn,nofficer_tmp);
			
			/* �޲z�H(�t����) */
			/* 1121002006_C01_FreeForm�t���u�� */
			if(strncmp(iroute,"JB",2)==0)
				insert_freeform(&icolumn,"����A�Ȥp��");
			else
			{
				strcpy(ileader,rtrim(ileader));
				strcpy(nleader,rtrim(nleader));
				sprintf_s(nleader_tmp,sizeof nofficer_tmp,"%s %s",ileader,nleader);
				insert_freeform(&icolumn,nleader_tmp);
			}
			
			/* �O�I�O1 */
			/* 1121002006_C01_FreeForm�t���u�� */
			if(strlen(iendorse_free) > 0)
				insert_freeform(&icolumn,itoa(edrprem));
			else 
				insert_freeform(&icolumn,bak3);
	
			/* �O�O���O����1 */
			/* 1121002006_C01_FreeForm�t���u�� */
			if(strlen(iendorse_free) > 0)
			{
				insert_freeform(&icolumn," ");
			}
			else 
			{
				insert_freeform(&icolumn,prem_note1);
			}
			
			/* ���P���X1 */
			/* 1121002006_C01_FreeForm�t���u�� */
			insert_freeform(&icolumn,itag);
			
			/* �q���N�� */
			insert_freeform(&icolumn,iroute);
			
			/* �q���W�� */
			insert_freeform(&icolumn,nname_N);
			
			/* �q���~�ȭ� */
			if ((ibig_sales[0] != '\0' && ibig_sales[0] !=' ') || (LHsNname[0] != '\0' && LHsNname[0] != ' '))
				insert_freeform(&icolumn,LHsNname);
			else 
				insert_freeform(&icolumn," ");
			
			/* �O�I�O2 */
			/* 1121002006_C01_FreeForm�t���u�� */
			if(strlen(iendorse_free) > 0)
				insert_freeform(&icolumn,itoa(edrprem));
			else 
				insert_freeform(&icolumn,bak3);
	
			/* �O�O���O����2 */
			/* 1121002006_C01_FreeForm�t���u�� */
			if(strlen(iendorse_free) > 0)
			{
				insert_freeform(&icolumn," ");
			}
			else 
			{
				if (prem21 > 0)
				{
					sprintf_s(prem_note, sizeof prem_note,"%s �X�p�O�O %s",prem_note2,bak31);
					insert_freeform(&icolumn,prem_note);
				}
				else 
					insert_freeform(&icolumn," ");
			}
			
			/* �ݥ��ˬd�X */
			insert_freeform(&icolumn,"Q");
			
			strcpy(r_iassured,trim(r_iassured));
			strcpy(r_itag,trim(r_itag));
			/* QRCODE1 */
			{
				insert_freeform(&icolumn,"QRCODE1");
				
				sprintf_s(url1,sizeof url1,"https://www.tmnewa.com.tw/b2c_v2/frontstage/certificatequery.aspx?OWNER_ID=%s\&CAR_NO=%s\&TYPE=0",r_iassured,r_itag);
				insert_freeform(&icolumn,url1);
				
				/* �ݥ��ˬd�X */
				insert_freeform(&icolumn,"Q");
			}
			
			/* QRCODE2 */
			{
				insert_freeform(&icolumn,"QRCODE2");
				
				sprintf_s(url2,sizeof url2,"https://www.tmnewa.com.tw/b2c_v2/frontstage/certificatequery.aspx?OWNER_ID=%s\&CAR_NO=%s\&TYPE=2",r_iassured,r_itag);
				insert_freeform(&icolumn,url2);
				
				/* �ݥ��ˬd�X */
				insert_freeform(&icolumn,"Q");
			}
			
			/* QRCODE3 */
			{
				insert_freeform(&icolumn,"QRCODE3");
				
				if(strncmp(r_icar_type,"35",2) == 0)
					sprintf_s(url3,sizeof url3,"https://ecard.cali.org.tw/PPCP_QRY/file/EMotorClause.pdf");
				else 
					strcpy(url3," ");
		
				insert_freeform(&icolumn,url3);
				
				/* �ݥ��ˬd�X */
				insert_freeform(&icolumn,"Q");
			}
		}
	}

	if(strncmp(ipolicy+5,"VW",2)==0)
	{	
		/* �O�T�IEDR */
		{
			insert_freeform(&icolumn,"EDR");
			
			/* ������O */
			insert_freeform(&icolumn,"�T�������O�T�O�ΫO�I");
			
			/* �O�渹(����) */
			if (iext_policy[0]!=' ' && iext_policy[0]!='\0') 
			strcpy(ply_ext1,CompanyId);
			else 
			strcpy(ply_ext1,"  ");

			strncat(ply_ext1,iext_policy,3);
			strncpy(ply_ext2,&iext_policy[3],10); ply_ext2[10]='\0';
			
			insert_freeform(&icolumn,ply_ext1);
			
			/* �O�渹(�Ǹ�) */
			insert_freeform(&icolumn,ply_ext2);
			
			/* ��渹(����) */
			if (ipolicy[0]!=' ' && ipolicy[0]!='\0') 
			strcpy(edr1,CompanyId);
			else 
			strcpy(edr1,"  ");
			
			strncat(edr1,ipolicy,3);
			strncpy(edr2,&ipolicy[3],14); edr2[14]='\0';
			
			insert_freeform(&icolumn,edr1);
			
			/* ��渹(�Ǹ�) */
			insert_freeform(&icolumn,edr2);
			
			/* �Q�O�H */
			insert_freeform(&icolumn,tmp_nassured4);
			
			/* �Q�O�H�����Ҹ� */ /* �P�O��W�h */
			if( fassured[0] == '1' || fassured[0] == '3' || fassured[0] == '5' )
			{
				if (strncmp(sProtectData,"0",1) == 0)
					insert_freeform(&icolumn,ilicense);
				else
					insert_freeform(&icolumn,sIlicense);
			}
			else 
			{
				insert_freeform(&icolumn," ");
			}
			
			/* �Q�O�H�ͤ� */
			if( fassured[0] == '1' || fassured[0] == '3' || fassured[0] == '5' )
			{
				sTmp1[0] = '\0';
				strcpy(sTmp1, trim(by));
				strcat(sTmp1, "/");
				strcat(sTmp1, trim(bm));
				strcat(sTmp1, "/");
				strcat(sTmp1, trim(bd));
				insert_freeform(&icolumn,sTmp1);
			}
			else 
				insert_freeform(&icolumn," ");
			
			/* �n�O�H */
			insert_freeform(&icolumn,tmp_napplicant1);
			
			/* ���� */
			insert_freeform(&icolumn,aassured_cmb);
			
			/* ca_ext_ply.dply_begin */
			{
				/* �O�I�ͮĴ����_(�~) */
				insert_freeform(&icolumn,yyext1);
				
				/* �O�I�ͮĴ����_(��) */
				insert_freeform(&icolumn,mmext1);
				
				/* �O�I�ͮĴ����_(��) */
				insert_freeform(&icolumn,ddext1);
			}
			
			/* ca_ext_ply.dply_end */
			{
				/* �O�I�ͮĴ�����(�~) */
				insert_freeform(&icolumn,yyext2);
				
				/* �O�I�ͮĴ�����(��) */
				insert_freeform(&icolumn,mmext2);
				
				/* �O�I�ͮĴ�����(��) */
				insert_freeform(&icolumn,ddext2);
			}
			
			/* ply_relation.dpolicy */
			{
				/* ���ͮĴ����_(�~) */
				insert_freeform(&icolumn,yy5);
				
				/* ���ͮĴ����_(��) */
				insert_freeform(&icolumn,mm5);
				
				/* ���ͮĴ����_(��) */
				insert_freeform(&icolumn,dd5);
			}
			
			/* ca_ply_ext.dply_end */
			{
				/* ���ͮĴ�����(�~) */
				insert_freeform(&icolumn,yyext2);
				
				/* ���ͮĴ�����(��) */
				insert_freeform(&icolumn,mmext2);
				
				/* ���ͮĴ�����(��) */
				insert_freeform(&icolumn,ddext2);
			}
			
			/* ��l�o�Ӧ~��(�~ */
			insert_freeform(&icolumn,is_yy);
			
			/* ��l�o�Ӧ~��(�� */
			insert_freeform(&icolumn,is_mm);
			
			/* ��l�o�Ӧ~��(�� */
			/*insert_freeform(&icolumn,is_dd);*/
			
			/* �s�y�~�� */
			insert_freeform(&icolumn,ipro_year);
			
			/* �P�Ӹ��X */
			insert_freeform(&icolumn,itag);
			
			/* �t�P���� */
			insert_freeform(&icolumn,ibrand);
			
			/* �t�P�����W�١A��ܼt�P */
			insert_freeform(&icolumn,nbrand_abbr);   /* 1121002005_C01_FreeForm�����B�@�~�u�� */
			
			/* �������� */
			insert_freeform(&icolumn,ncar_type);
			
			/* �Ʈ�q */
			insert_freeform(&icolumn,s_qcylinder2);
			
			/* ���� */
			insert_freeform(&icolumn,iengine_0);
			
			/* �������� */
			insert_freeform(&icolumn,s_pt);
			
			/* �X�p */
			insert_freeform(&icolumn,bak3);
			
			/* �ꦬ�O�O */
			insert_freeform(&icolumn,bak3);
			
			/* �}�ߤ��(�~ */
			insert_freeform(&icolumn,yy6);
			
			/* �}�ߤ��(�� */
			insert_freeform(&icolumn,mm6);
			
			/* �}�ߤ��(�� */
			insert_freeform(&icolumn,dd6);
			
			/* �`�����q�O */
			insert_freeform(&icolumn,tax_area);
			
			/* �ӿ�H */
			insert_freeform(&icolumn,nname);
			
			/* �g��N�� */
			insert_freeform(&icolumn," ");

			/* ���H���N�� */
			insert_freeform(&icolumn," ");

			/* �ݥ��ˬd */
			insert_freeform(&icolumn,"Q");
		}
		
		/* ����I�ة��� EDRINS */
		{
			insert_freeform(&icolumn,"EDRINS");
			
			/* ���ʽ� */
			insert_freeform(&icolumn," ");
			
			/* �O�I�����W�� */
			insert_freeform(&icolumn," ");
			
			/* �O�I���B���t�� */
			insert_freeform(&icolumn," ");
			
			/* �O�I���B */
			insert_freeform(&icolumn," ");
			
			/* �ۭt�B���t�� */
			insert_freeform(&icolumn," ");
			
			/* �ۭt�B */
			insert_freeform(&icolumn," ");
			
			/* �O�I�O���t�� */
			insert_freeform(&icolumn," ");
			
			/* �O�I�O */
			insert_freeform(&icolumn," ");
			
			/* �ݥ��ˬd */
			insert_freeform(&icolumn,"Q");
		}
		
		/* ���ƥѻ���EDRNOTE */
		/* �]�����u���@��A�b�O��C�L�u��ۦ�p���m */
		{
			/* ���ƥѤ��e */
			/*
				�@.	�ۥ���XXX�~XX��XX��_�ӳ��Q�O�I�����p�U�G
				�ӳ�����@�@�O�T�����@�@���D�Τ������X�@�@�@�O�T��������̥���̬��ǡ@�@�@�@�t�P����
				�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@(���B�L�Ӥ�΢�U����)
				XXX.XX.XX �@XXX-XXXX�@�@��p��@�@�@�@�@�@�@XXX.XX.XX - XXX.XX.XX�@�@�@�@�@ ���h
				                        XXXXXXXXXXXXXXXXXX  (����12��)�@�@�@�@�@�@�@�@�@�@ �������
				                                                                           �������
				
				
				�G.�O�T�s��G�ʤO�ǰʨt�Ρ@�@�@�@�@�@�@�@�@ �A�ӫO���{�ơGXX,XXX����
				
				�T.Ų��e���ƥѡA�Q�O�I�H���[ú�O�I�O NT$X,XXX��
				
				�l�L�ܧ�A�S���[��C
				*** �H�U�ť� ***
			*/

			/* �@.	�ۥ���XXX�~XX��XX��_�ӳ��Q�O�I�����p�U�G*/
			insert_freeform(&icolumn,"EDRNOTE");
			sTmp2[0] = '\0';
			sprintf_s(sTmp2, sizeof sTmp2,"�@. �ۥ���%s�~%s��%s��_�ӳ��Q�O�I�����p�U�G",yy5,mm5,dd5);
			insert_freeform(&icolumn,sTmp2);
			insert_freeform(&icolumn,"C");
			
			/* �ӳ�����@�@�O�T�����@�@���D�Τ������X�@�@�@�O�T��������̥���̬��ǡ@�@�@�@�t�P����*/
			insert_freeform(&icolumn,"EDRNOTE");
			sTmp2[0] = '\0';
			/*         ��m 1         12            26                        52                            81 */
			sprintf_s(sTmp2, sizeof sTmp2,"�ӳ����   �O�T����      ���D�Τ������X            �O�T���� ����̥���̬���     �t�P����");
			insert_freeform(&icolumn,sTmp2);
			insert_freeform(&icolumn,"C");
			
			/* �@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@�@(���B�L�Ӥ�΢�U����) */
			insert_freeform(&icolumn,"EDRNOTE");
			sTmp2[0] = '\0';
			sTmp2_W[0] = '\0';
			for (int i=0;i<51;i++)
			{
				strcat(sTmp2_W," ");
			}
			strcat(sTmp2,sTmp2_W);
			sTmp2[51] = '\0';
			num_to_chinese(year_chinese,qperiod_ext);            
			strcpy(year_chinese,trim(year_chinese));
			strcat(year_chinese,"�Ӥ��");
			strcat(sTmp2,"(");
			strcat(sTmp2,year_chinese);
						
			num_to_chinese(mile_chinese,qmiles_ext);
			strcpy(mile_chinese,trim(mile_chinese));
			strcat(mile_chinese,"����");
			strcat(sTmp2,mile_chinese);
			strcat(sTmp2,")");

			insert_freeform(&icolumn,sTmp2);
			insert_freeform(&icolumn,"C");
			
			/* XXX.XX.XX �@XXX-XXXX�@�@��p��@�@�@�@�@�@�@XXX.XX.XX - XXX.XX.XX�@�@�@�@�@ ���h */
			insert_freeform(&icolumn,"EDRNOTE");
			/* �ӳ���� */
			sTmp2[0] = '\0';
			sTmp2_1[0] = '\0';
			sTmp2_W[0] = '\0';
			sprintf_s(sTmp2_1, sizeof sTmp2_1,"%s.%s.%s",yy5,mm5,dd5);
			strcpy(sTmp2,sTmp2_1);
			for (int i=0;i<11-strlen(sTmp2);i++)
			{
				strcat(sTmp2_W," ");
			}
			strcat(sTmp2,sTmp2_W);
			sTmp2[11] = '\0';

			/* �O�T����*/
			sTmp2_W[0] = '\0';
			strcat(sTmp2,itag);
			for (int i=0;i<25-strlen(sTmp2);i++)
			{
				strcat(sTmp2_W," ");
			}
			strcat(sTmp2,sTmp2_W);
			sTmp2[25] = '\0';
			
			/* ���D�Τ������X */
			iTmp=0;
			sTmp2_W[0] = '\0';
			iTmp = iGetChinesePos(nowner_ext,20);
			strcpy(nowner_ext_tmp,"");
			strncpy(nowner_ext_tmp,nowner_ext,iTmp+1);
			nowner_ext_tmp[iTmp+1] = '\0';
			strcat(sTmp2,nowner_ext_tmp);
			for (int i=0;i<51-strlen(sTmp2);i++)
			{
				strcat(sTmp2_W," ");
			}
			strcat(sTmp2,sTmp2_W);
			sTmp2[51] = '\0';
			
			/* �O�T���� */
			sTmp2_2[0] = '\0';
			sTmp2_W[0] = '\0';
			sprintf_s(sTmp2_2, sizeof sTmp2_2,"%s.%s.%s-%s.%s.%s",yy1,mm1,dd1,yy2,mm2,dd2);
			strcat(sTmp2,sTmp2_2);
			for (int i=0;i<81-strlen(sTmp2);i++)
			{
				strcat(sTmp2_W," ");
			}
			strcat(sTmp2,sTmp2_W);
			sTmp2[81] = '\0';
			
			/* �t�P���� */
			sTmp2_W[0] = '\0';
			strcat(sTmp2,nbrand_abbr);
			for (int i=0;i<100-strlen(sTmp2);i++)
			{
				strcat(sTmp2_W," ");
			}
			strcat(sTmp2,sTmp2_W);
			sTmp2[100] = '\0';
			
			insert_freeform(&icolumn,sTmp2);
			insert_freeform(&icolumn,"C");
			
			/*                         XXXXXXXXXXXXXXXXXX  (����12��)�@�@�@�@�@�@�@�@�@�@ ������� */
			insert_freeform(&icolumn,"EDRNOTE");
			iTmp = itext = iTmp2 = 0;
			sTmp2[0] = '\0';
			sTmp2_W[0] = '\0';
			for (int i=0;i<25;i++)
			{
				strcat(sTmp2_W," ");
			}
			strcat(sTmp2,sTmp2_W);
			sTmp2[25] = '\0';
			strcat(sTmp2,iengine_0);
			sTmp2_W[0] = '\0';
			for (int i=0;i<51-strlen(sTmp2);i++)
			{
				strcat(sTmp2_W," ");
			}
			strcat(sTmp2,sTmp2_W);
			sTmp2[51] = '\0';
			strcat(sTmp2,"(����12��)");
			
			sTmp2_W[0] = '\0';
			for (int i=0;i<81-strlen(sTmp2);i++)
			{
				strcat(sTmp2_W," ");
			}
			strcat(sTmp2,sTmp2_W);
			sTmp2[81] = '\0';
			
			/* �t�P�����_�� */
			iTmp=itext=iTmp2=0;
			iTmp = iGetChinesePos(nbrand,16);
			strcpy(nbrand_1,"");
			strcpy(nbrand_2,"");
			strncpy(nbrand_1,nbrand,iTmp+1);
			nbrand_1[iTmp+1] = '\0';
			itext = itext + iTmp + 1;
			if (itext <= strlen(nbrand))
			{
				iTmp2 = iGetChinesePos(nbrand+itext,16);
				strncpy(nbrand_2,nbrand+itext,iTmp2+1);
				nbrand_2[iTmp2+1] = '\0';
				itext = itext + iTmp2 + 1;
			}
			else strcpy(nbrand_2,"");
			
			strcat(sTmp2,nbrand_1);
			insert_freeform(&icolumn,sTmp2);
			insert_freeform(&icolumn,"C");
			
			/* (���e�����׷s�W): */
			sTmp2[0] = '\0';
			sTmp2_W[0] = '\0';
			if (strlen(nbrand_2) > 0)
			{
				for (int i=0;i<81;i++)
				{
					strcat(sTmp2_W," ");
				}
				strcat(sTmp2,sTmp2_W);
				sTmp2[81] = '\0';
				strcat(sTmp2,nbrand_2);
				
				insert_freeform(&icolumn,"EDRNOTE");
				insert_freeform(&icolumn,sTmp2);
				insert_freeform(&icolumn,"C");
			}
			
			/* �ťդ@�� */
			insert_freeform(&icolumn,"EDRNOTE");
			insert_freeform(&icolumn," ");
			insert_freeform(&icolumn,"C");
			
			/* �G.�O�T�s��G�ʤO�ǰʨt�Ρ@�@�@�@�@�@�@�@�@ �A�ӫO���{�ơGXX,XXX���� */
			insert_freeform(&icolumn,"EDRNOTE");
			sTmp2[0] = '\0';
			sTmp2_1[0] = '\0';
			sTmp2_W[0] = '\0';
			if (strcmp(iparts_ext,"1") == 0) strcpy(sTmp2_1,"����");
			else  strcpy(sTmp2_1,"�ʤO�ǰʨt��");
			strcat(sTmp2_1,"\0");
			sprintf_s(sTmp2, sizeof sTmp2,"�G.�O�T�s��G%s",sTmp2_1);
			for (int i=0;i<51-strlen(sTmp2);i++)
			{
				strcat(sTmp2_W," ");
			}
			strcat(sTmp2,sTmp2_W);
			sTmp2[51] = '\0';
			rfmtdouble(mkilo_ply_ext,"<<,<<<,<<<,<<<",mkiloply_tmp);
			strcat(sTmp2,", �ӫO���{�� : ");
			strcat(sTmp2,mkiloply_tmp);
			strcat(sTmp2,"  ����");
			insert_freeform(&icolumn,sTmp2);
			insert_freeform(&icolumn,"C");
			
			/* �ťդ@�� */
			insert_freeform(&icolumn,"EDRNOTE");
			insert_freeform(&icolumn," ");
			insert_freeform(&icolumn,"C");
			
			/* �T.Ų��e���ƥѡA�Q�O�I�H���[ú�O�I�O NT$X,XXX�� */
			insert_freeform(&icolumn,"EDRNOTE");
			sTmp2[0] = '\0';
			rfmtlong(real1_premium,"<<,<<<,<<<,<<<",mpremium_tmp);
			printf(" mpremium = %s \n", mpremium_tmp);
			sprintf_s(sTmp2, sizeof sTmp2,"�T.Ų��e���ƥѡA�Q�O�I�H���[ú�O�I�O %s",ascii_judge(mpremium_tmp, "NT"));
			insert_freeform(&icolumn,sTmp2);
			insert_freeform(&icolumn,"C");
			
			/* �ťդ@�� */
			insert_freeform(&icolumn,"EDRNOTE");
			insert_freeform(&icolumn," ");
			insert_freeform(&icolumn,"C");
			
			/* �l�L�ܧ�A�S���[��C */
			insert_freeform(&icolumn,"EDRNOTE");
			sTmp2[0] = '\0';
			sprintf_s(sTmp2, sizeof sTmp2,"�l�L�ܧ�A�S���[��C");
			insert_freeform(&icolumn,sTmp2);
			insert_freeform(&icolumn,"C");
			
			/* �ťդ@�� */
			insert_freeform(&icolumn,"EDRNOTE");
			insert_freeform(&icolumn," ");
			insert_freeform(&icolumn,"C");
			
			sTmp2[0] = '\0';
			insert_freeform(&icolumn,"EDRNOTE");
			sprintf_s(sTmp2, sizeof sTmp2,"*** �H�U�ť� ***");
			insert_freeform(&icolumn,sTmp2);
			insert_freeform(&icolumn,"Q");
		}

		/* ����Ƶ��� */
		insert_freeform(&icolumn,"QEQ");
	}	
	else 
	{
		/* �O����POLICY */
		{
			insert_freeform(&icolumn,"POLICY");
			
			/* �O��O */
			if (strncmp(ipolicy+5,"EB",2)==0)
				insert_freeform(&icolumn,"�q�ʦۦ樮��X�O�I");
			else if(strncmp(ipolicy+5,"ES",2)==0)
				insert_freeform(&icolumn,"�ۥΥR�q�κ�X�O�I");
			else 
				insert_freeform(&icolumn,"�T��");
			
			/* �j���Ҹ� */
			sprintf_s(icard_tmp,sizeof icard_tmp,"17%s",r_icard);
			insert_freeform(&icolumn,icard_tmp);			

			/* �O�渹(����) */
			insert_freeform(&icolumn,ply1);
			
			/* �O�渹(�Ǹ�) */
			insert_freeform(&icolumn,ply2);
			
			/* �q�l�O���ˮ�.nplyidx1 */
			strcpy(nplyidx1,ply1);
			strcat(nplyidx1,ply2);
			strcat(nplyidx1,"|");
			
			/* ��O�O�渹(����) */
			insert_freeform(&icolumn,last_ply1);
			
			/* ��O�O�渹(�Ǹ�) */
			insert_freeform(&icolumn,last_ply2);
			
			/* �Q�O�I�H */
			insert_freeform(&icolumn,tmp_nassured4);
			
			/* ����(�q�T�B) */
			insert_freeform(&icolumn,aassured_cmb);
			
			/* �Q�O�I�H�X�ͤ�� */
			if( fassured[0] == '1' || fassured[0] == '3' || fassured[0] == '5' )
			{
				sTmp1[0] = '\0';
				strcpy(sTmp1, trim(by));
				strcat(sTmp1, "/");
				strcat(sTmp1, trim(bm));
				strcat(sTmp1, "/");
				strcat(sTmp1, trim(bd));
				insert_freeform(&icolumn,sTmp1);
			}
			else 
				insert_freeform(&icolumn," ");
			
			/* �Q�O�I�H�ʧO */
			if( fassured[0] == '1' || fassured[0] == '3' || fassured[0] == '5' )
				insert_freeform(&icolumn,sex1);
			else 
				insert_freeform(&icolumn," ");
			
			/* �Q�O�I�HID */ /* �O�榳�ץ��A�O�T�I�����]�n�@�_�վ�W�h�@�P */
			if( fassured[0] == '1' || fassured[0] == '3' || fassured[0] == '5' )
			{
				if (strncmp(sProtectData,"0",1) == 0)
					insert_freeform(&icolumn,ilicense);
				else
					insert_freeform(&icolumn,sIlicense);
				
				/* �q�l�O���ˮ�.nplyidx1 */
				strcat(nplyidx1,sIlicense);
				strcat(nplyidx1,"|");
			}
			else 
			{
				insert_freeform(&icolumn," ");
				/* �q�l�O���ˮ�.nplyidx1 */
				strcat(nplyidx1," ");
				strcat(nplyidx1,"|");
			}
			
			/* �n�O�H�W�� */
			insert_freeform(&icolumn,tmp_napplicant1);
			
			/* �n�O�H�X�ͤ�� */
			if( fapplicant[0] == '1' || fapplicant[0] == '3' || fapplicant[0] == '5' )
			{
				sTmp1[0] = '\0';
				strcpy(sTmp1, trim(by_appl));
				strcat(sTmp1, "/");
				strcat(sTmp1, trim(bm_appl));
				strcat(sTmp1, "/");
				strcat(sTmp1, trim(bd_appl));
				insert_freeform(&icolumn,sTmp1);
			}
			else 
				insert_freeform(&icolumn," ");
			
			/* �n�O�H�ʧO */
			if( fapplicant[0] == '1' || fapplicant[0] == '3' || fapplicant[0] == '5' )
				insert_freeform(&icolumn,sex1_appl);
			else 
				insert_freeform(&icolumn," ");
				
			/* �n�O�HID */
			if( fapplicant[0] == '1' || fapplicant[0] == '3' || fapplicant[0] == '5' )
			{
				if (strncmp(sProtectData,"0",1) == 0)
					insert_freeform(&icolumn,iapplicant);
				else
					insert_freeform(&icolumn,sIapplicant);
			}
			else 
				insert_freeform(&icolumn," ");
			
			/* �O�I�����_(�~) */
			insert_freeform(&icolumn,yy1);
			
			/* �O�I�����_(��) */
			insert_freeform(&icolumn,mm1);
			
			/* �O�I�����_(��) */
			insert_freeform(&icolumn,dd1);
			
			/* �O�I������(�~) */
			insert_freeform(&icolumn,yy2);
			
			/* �O�I������(��) */
			insert_freeform(&icolumn,mm2);
			
			/* �O�I������(��) */
			insert_freeform(&icolumn,dd2);
			
			/* ��l�o�Ӧ~�� */
			sTmp1[0] = '\0';
			strcpy(sTmp1, trim(is_yy));
			strcat(sTmp1, "/");
			strcat(sTmp1, trim(is_mm));
			if(strncmp(ipolicy+5,"ES",2)==0)
				insert_freeform(&icolumn,"-");
			else 
				insert_freeform(&icolumn,sTmp1);
			
			/* �s�y�~��(�~) */
			if(strncmp(ipolicy+5,"ES",2)==0)
				insert_freeform(&icolumn,"-");
			else 
				insert_freeform(&icolumn,ipro_year);
			
			/* �P�Ӹ��X */
			if(strncmp(ipolicy+5,"ES",2)==0)
				insert_freeform(&icolumn,"-");
			else 
				insert_freeform(&icolumn,itag);
			
			/* �������� */
			if(strncmp(ipolicy+5,"ES",2)==0)
				insert_freeform(&icolumn,"-");
			else 
				insert_freeform(&icolumn,ncar_type);
			
			/* �t�P�����N�� */
			if(strncmp(ipolicy+5,"ES",2)==0)
				insert_freeform(&icolumn,"-");
			else 
				insert_freeform(&icolumn,ibrand);
			
			/* �t�P�����W�� */
			if(strncmp(ipolicy+5,"ES",2)==0)
				insert_freeform(&icolumn," ");
			else 
				insert_freeform(&icolumn,nbrand_abbr);  /* 1121002005_C01_FreeForm�����B�@�~�u�� */
			
			/* �Ʈ�q */	
			if(strncmp(ipolicy+5,"ES",2)==0)
				insert_freeform(&icolumn,"-");
			else 
				insert_freeform(&icolumn,s_qcylinder2);
			
			/* �����ƶq */
			if(strncmp(ipolicy+5,"ES",2)==0)
				insert_freeform(&icolumn,"-");
			else 
				insert_freeform(&icolumn,s_pt);
			
			/* ����/����/���[���X */
			if(strncmp(ipolicy+5,"ES",2)==0)
				insert_freeform(&icolumn,"-");
			else 
				insert_freeform(&icolumn,iengine_0);
			
			/* ���d�ߴګY�� */
			if(strncmp(ipolicy+5,"ES",2)==0)
				insert_freeform(&icolumn,"-");
			else 
				insert_freeform(&icolumn,s_lia_acc);
			
			/* ����ߴګY�� */
			if(strncmp(ipolicy+5,"ES",2)==0)
				insert_freeform(&icolumn,"-");
			else 
				insert_freeform(&icolumn,s_dmg_acc);
			
			/* �~�֩ʧO�Y�� */
			if(strncmp(ipolicy+5,"ES",2)==0)
				insert_freeform(&icolumn,"-");
			else 
				insert_freeform(&icolumn," "); /* �O�v�ۥѤƦ~�֩ʧO���L */
			
			/* �ծ֤�(�~) */
			insert_freeform(&icolumn,yy6);
			
			/* �ծ֤�(��) */
			insert_freeform(&icolumn,mm6);
			
			/* �ծ֤�(��) */
			insert_freeform(&icolumn,dd6);
			
			/* �`�����q�O */
			insert_freeform(&icolumn,tax_area);
			
			/* �`�O�O */
			insert_freeform(&icolumn,bak3);
			
			/* �q�l�O���ˮ�.nplyidx1 */
			strcat(nplyidx1,bak3);
			
			/* �g��N�� */
			insert_freeform(&icolumn,iofficer);
			
			/* �g��N���W�� */
			insert_freeform(&icolumn,nofficer);
			
			/* �޲z�H */
			insert_freeform(&icolumn,nname);
			
			/* �C�L�� */
			if (strncmp(sIpolicyB_type,"2",1) == 0 || strncmp(sIpolicyB_type,"3",1) == 0 )
			{
				sTmp1[0] = '\0';
				strcpy(sTmp1, trim(yy7));
				strcat(sTmp1, "/");
				strcat(sTmp1, trim(mm7));
				strcat(sTmp1, "/");
				strcat(sTmp1, trim(dd7));
			}
			else
			{
				sTmp1[0] = '\0';
				strcpy(sTmp1, trim(yy5));
				strcat(sTmp1, "/");
				strcat(sTmp1, trim(mm5));
				strcat(sTmp1, "/");
				strcat(sTmp1, trim(dd5));
			}
			insert_freeform(&icolumn,sTmp1);
			
			/* �ݥ��ˬd */
			insert_freeform(&icolumn,"Q");
		}
		
		$int check_point=0;
		nplyidx2[0] = '\0';
		/* �I�ة��� INSKIND */
		{
			/* INSKIND */
			insert_freeform(&icolumn,"INSKIND");
			check_point = 0;	
			sprintf_s(stmt_kind, sizeof stmt_kind,"SELECT line_no,field1,field2,field3,field4,field5,field6,field7 \
			                     FROM print_layout \
			                    WHERE ipolicy = '%s' order by line_no;",ipolicy);
	
			$PREPARE ins_print1 FROM $stmt_kind;
			$DECLARE ins_print CURSOR FOR ins_print1;
			$OPEN ins_print;
			while(1)
			{
				$FETCH ins_print INTO $line_no_tmp,$iins_type_tmp,$nins_type_tmp,$main_paid_tmp,$cover_print_tmp,$amt_print_tmp,$prn_deduct_tmp,$str_ins_premium_tmp;
				if(SQLCODE == SQLNOTFOUND) 
				{
					if (check_point == 0)
					{
						/* �����h�O�S�I�ؼg�J�A���ť� */
						/* �I�إN�� */
						insert_freeform(&icolumn," ");
						
						/* �I�ئW��/�O�B���D */
						insert_freeform(&icolumn," ");
						
						/* �O�I���B���� */
						insert_freeform(&icolumn," ");
						
						/* �O�I���B */
						insert_freeform(&icolumn," ");
						
						/* �ۭt�B */
						insert_freeform(&icolumn," ");
						
						/* �O�O */
						insert_freeform(&icolumn," ");
					}
					break;
				}
				
				strcpy(iins_type_tmp,trim(iins_type_tmp));
				strcpy(nins_type_tmp,trim(nins_type_tmp));
				strcpy(main_paid_tmp,trim(main_paid_tmp));
				strcpy(cover_print_tmp,trim(cover_print_tmp));
				strcpy(amt_print_tmp,trim(amt_print_tmp));
				strcpy(prn_deduct_tmp,trim(prn_deduct_tmp));
				strcpy(str_ins_premium_tmp,trim(str_ins_premium_tmp));
				
				printf("line_no_tmp[%.2f],iins_type_tmp[%s],nins_type_tmp[%s],main_paid_tmp[%s],cover_print_tmp[%s],amt_print_tmp[%s],prn_deduct_tmp[%s],str_ins_premium_tmp[%s] \n",
				        line_no_tmp,iins_type_tmp,nins_type_tmp,main_paid_tmp,cover_print_tmp,amt_print_tmp,prn_deduct_tmp,str_ins_premium_tmp);
				
				if (check_point > 0)
				{
					/* �ݥ��ˬd */
					insert_freeform(&icolumn,"C");
					
					/* INSKIND */
					insert_freeform(&icolumn,"INSKIND");
				}
				
				/* �I�إN�� */
				insert_freeform(&icolumn,iins_type_tmp);
				
				/* �I�ئW��/�O�B���D */
				insert_freeform(&icolumn,nins_type_tmp);
				
				/* �O�I���B���� */
				insert_freeform(&icolumn,cover_print_tmp);
				
				/* �O�I���B */
				insert_freeform(&icolumn,amt_print_tmp);
				
				/* �ۭt�B */
				insert_freeform(&icolumn,prn_deduct_tmp);
				
				/* �O�O */
				insert_freeform(&icolumn,str_ins_premium_tmp);
				
				/* �q�l�O���ˮ����.nplyidx2 */
				if(strlen(iins_type_tmp) > 0)
				{
					printf("amt_print_tmp[%s] \n",amt_print_tmp);
					nplyidx2_tmp[0] = '\0';
					sprintf(nplyidx2_tmp,"%s|%s#",nins_type_tmp,amt_print_tmp);
					strcat(nplyidx2,nplyidx2_tmp);
				}
				
				check_point++;
			}
			$CLOSE ins_print;
			$FREE ins_print;
			check_point = 0;

			nplyidx2[strlen(nplyidx2) - 1 ] = '\0';

			/* �ݥ��ˬd */
			insert_freeform(&icolumn,"Q");
		}
	
		/* �ˮ`�I�[����r NOTE_PA */
		{
			$char stmt_pa[512];
			$char notepa_1[7],notepa_2[121],notepa_3[121],notepa_4[121],notepa_5[121],notepa_6[121],notepa_7[121],field_tmp[121],notepa[256];
			$int  ipa=0,line_no=0;
			
			/* �ݥ��ˬd */
			ipa=0;
			$SELECT count(*) INTO $ipa FROM print_layout56 WHERE ipolicy = $ipolicy;
			printf("ipa[%d] \n",ipa);
			if (ipa > 0) insert_freeform(&icolumn,"NOTE_PA");
			check_point = 0;
			sprintf_s(stmt_pa, sizeof stmt_pa,"SELECT line_no,field1,field2,field3,field4,field5,field6,field7,field_tmp \
			                   FROM print_layout56 WHERE ipolicy = '%s' order by line_no;",ipolicy);
			$PREPARE notepa_pre FROM $stmt_pa;
			$DECLARE notepa_cur CURSOR FOR notepa_pre;
			$OPEN notepa_cur;
			while(1)
			{
				$FETCH notepa_cur INTO $line_no,$notepa_1,$notepa_2,$notepa_3,$notepa_4,$notepa_5,$notepa_6,$notepa_7,$field_tmp;
				if(SQLCODE == SQLNOTFOUND) break;
				strcpy(notepa_1,rtrim(notepa_1));
				strcpy(notepa_2,rtrim(notepa_2));
				strcpy(notepa_3,rtrim(notepa_3));
				strcpy(notepa_4,rtrim(notepa_4));
				strcpy(notepa_5,rtrim(notepa_5));
				strcpy(notepa_6,rtrim(notepa_6));
				strcpy(notepa_7,rtrim(notepa_7));
				strcpy(field_tmp,rtrim(field_tmp));
				
				if (check_point > 0)
				{
					/* �ݥ��ˬd */
					insert_freeform(&icolumn,"C");
					
					/* NOTE_PA */
					insert_freeform(&icolumn,"NOTE_PA");
				}
				
				/* �I�إN�� */
				insert_freeform(&icolumn,notepa_1);
				
				/* �W�U�Q�O�H */
				insert_freeform(&icolumn,notepa_2);
				
				/* �ͤ� */
				insert_freeform(&icolumn,notepa_3);
				
				/* �����Ҹ� */
				insert_freeform(&icolumn,notepa_4);
				
				/* ���q�H */
				insert_freeform(&icolumn,notepa_5);
				
				/* ���Y */
				insert_freeform(&icolumn,notepa_6);
				
				/* �q�� */
				insert_freeform(&icolumn,notepa_7);
				
				/* �a�} */
				insert_freeform(&icolumn,field_tmp);
				
				check_point++;
			}
			$CLOSE notepa_cur;
			$FREE notepa_cur;
			check_point = 0;
			/* �ݥ��ˬd */
			if (ipa > 0) insert_freeform(&icolumn,"Q");
		}

		/* �[����r NOTE */
		{
			/* ����v�H */
			/* 1121002005_C01_FreeForm�����B�@�~�u�� */
			if ((strcmp(trim(nbenef),"") != 0) && (strcmp(trim(nbenef),'\0') != 0))
			{
				insert_freeform(&icolumn,"NOTE");
				sprintf_s(sTmp1, sizeof sTmp1,"����v�H�Ψ��q�H�G%s",nbenef);
				insert_freeform(&icolumn,sTmp1);
				insert_freeform(&icolumn,"C");
			}
			
			/* �R�q�ε��O */
			if(strncmp(ipolicy+5,"ES",2)==0)
			{
				/* �w�ˤ�� */
				strcpy(dinstall_str,cm_cdate_str_100(dinstall));
				cm_split_ymd_100(dinstall_str,yyinstall,mminstall,ddinstall);
				sTmp1[0] = '\0';
				insert_freeform(&icolumn,"NOTE");
				sprintf_s(sTmp1, sizeof sTmp1,"�w�ˤ���G����%s�~%s��",yyinstall,mminstall);
				insert_freeform(&icolumn,sTmp1);
				insert_freeform(&icolumn,"C");
				/* ���~�Ǹ� */
				sTmp1[0] = '\0';
				insert_freeform(&icolumn,"NOTE");
				sprintf_s(sTmp1, sizeof sTmp1,"���~�Ǹ��G%s",isequence);
				insert_freeform(&icolumn,sTmp1);
				insert_freeform(&icolumn,"C");
				/* �w�˦a�} */
				sTmp1[0] = '\0';
				insert_freeform(&icolumn,"NOTE");
				strcpy(ainstall_zip,trim(ainstall_zip));
				sprintf_s(sTmp1, sizeof sTmp1,"�w�˦a�}�G%s %s",ainstall_zip,ainstall);
				insert_freeform(&icolumn,sTmp1);
				insert_freeform(&icolumn,"C");
			}
			
			/* ���w�r�p�H�ӫ~�ΦW�U�I�� */
			if (strcmp(PrintDlist,"0") != 0)
			{
				strcpy(sProvD,trim(sProvD));
				if (strlen(sProvD) > 0) 
				{
					insert_freeform(&icolumn,"NOTE");
					insert_freeform(&icolumn,sProvD);
					insert_freeform(&icolumn,"C");
				}
			}
			else
			{
				if (mequipment > 0)
				{
					insert_freeform(&icolumn,"NOTE");
					insert_freeform(&icolumn,sMequipment);
					insert_freeform(&icolumn,"C");
				}
			}	 	  
			
			/* �C�L���w�r�p�H�ӫ~�ΦW�U1 */
			if (strcmp(PrintDlist,"0") != 0)
			{
				strcpy(sProvD_1,trim(sProvD_1));
				if (strlen(sProvD_1) > 0)
				{
					insert_freeform(&icolumn,"NOTE");
					insert_freeform(&icolumn,sProvD_1);
					insert_freeform(&icolumn,"C");
				}
			}
			
			/* �C�L���w�r�p�H�ӫ~�ΦW�U2 */
			if (strcmp(PrintDlist,"0") != 0)
			{
				strcpy(sProvD_2,trim(sProvD_2));
				if (strlen(sProvD_2) > 0)
				{
					insert_freeform(&icolumn,"NOTE");
					insert_freeform(&icolumn,sProvD_2);
					insert_freeform(&icolumn,"C");
				}
			}

			$SELECT iins_type,mdeduct
			   FROM ply_ins_type
			  WHERE ipolicy = $ipolicy
			    AND iins_type in ( '30', '301' ,'302', '530')
			    AND mdamage_cover <> 0;
			if(SQLCODE == SQLNOTFOUND)
			{
				if (s_note[0] != '\0' && s_note[0] != " ") 
				{
					/* �W�B�d���I���O */
					strcpy(s_note,trim(s_note));
					insert_freeform(&icolumn,"NOTE");
					insert_freeform(&icolumn,s_note);
					insert_freeform(&icolumn,"C");
				} 
			}
			else
			{
				/* �����I����B�C�M�ᨮ�ߨ����O */
				if (ps_dtl[0] != '\0' && ps_dtl[0] != " ") 
				{
					insert_freeform(&icolumn,"NOTE");
					insert_freeform(&icolumn,ps_dtl);
					insert_freeform(&icolumn,"C");
				}
			}
			
			/* ���@�����O */
			if (ps_60[0] != '\0' && ps_60[0] != " ") 
            {
            	insert_freeform(&icolumn,"NOTE");
				insert_freeform(&icolumn,ps_60);
				insert_freeform(&icolumn,"C");
            }
            
            printf("nprov_note[%s] \n",nprov_note);
			/* ���[���ڻ�����r */
			if (nprov_note[0] != '\0' && nprov_note[0] != " ") 
            {
				insert_freeform(&icolumn,"NOTE");
				insert_freeform(&icolumn,nprov_note);
				insert_freeform(&icolumn,"C");
			}
			
			if (strcmp(iofficer,"Z17015Y01")==0 ||strcmp(iofficer,"Z17015Y")==0)
     		{ 	
     	    	insert_freeform(&icolumn,"NOTE");
				insert_freeform(&icolumn,"���w�ɦ��D���ϴ�100�����A�ȡA��کνվ�A�Ȥ��e�̡A�H�����q���������i�γq������");
				insert_freeform(&icolumn,"C");
     		}
			
			/* �j�r�O��帹�򵹥I���بC����׭���P */
			$int tmplen = 0;
			if(strncmp(formid_tmp,"CARPLY002",9) == 0)  tmplen = 62;
			else tmplen = 94;
			
			/* �ӫ~�帹 */
			icont_len = 0;
			ilen_end = 0;
			printf("ncontent_print[%s] \n",ncontent_print);

			/* �p��帹�̦��h��';'�Ÿ��A2�ӥH�W�ݧ�̫᪺"�C"�R�� (1140428007_C01)*/
			count = 0;
			for (int i = 0; ncontent_print[i] != '\0'; i++) {
				if (ncontent_print[i] == ';') {
					count++;
				}
			}
			
			while(icont_len <= strlen(ncontent_print))
			{
				iTmpLen = 0;
				ncont_tmp[0] = '\0';
				
				iTmpLen = iGetChinesePos(ncontent_print+icont_len,tmplen);
				strncpy(ncont_tmp,ncontent_print+icont_len,iTmpLen+1);
				ncont_tmp[iTmpLen+1] = '\0';
				printf("ncont_tmp[%s] \n",ncont_tmp);

				icont_len = icont_len + iTmpLen + 1;
				
				/* �̫�@�Ӥ����令�y�� */
				if (icont_len > strlen(ncontent_print))
				{
				    ilen_end = 0;
					ilen_end = strlen(ncont_tmp);
					if (ncont_tmp[ilen_end-1] == ';')
					{
						ncont_tmp[ilen_end-1] = '\0';
						strncat(ncont_tmp,"�C",ilen_end-1);
					}
				}

				/* �u���@�դ帹����̫᪺ܳ�u�C�v (1140428007_C01) */
				if (count <= 1)
				{					
					ilen_end = 0;
					ilen_end = strlen(ncont_tmp);					
					if (strcmp(&ncont_tmp[ilen_end-2],"�C")==0)
					{						
						ncont_tmp[ilen_end-2] = '\0';
						strncat(ncont_tmp,"",ilen_end-2);
					}
				}

				insert_freeform(&icolumn,"NOTE");
				insert_freeform(&icolumn,ncont_tmp);
				insert_freeform(&icolumn,"C");
			}

			/* �D�n���I���� */
			$char stmt_domain[512];
			check_point = 0;
			strcpy(edomain,"�D�n���I���ءG");
			sprintf_s(stmt_domain, sizeof stmt_domain,"SELECT unique field3 FROM print_layout WHERE ipolicy = '%s' AND field3 <> '';",ipolicy);
			$PREPARE domain_pre FROM $stmt_domain;
			$DECLARE domain_cur CURSOR FOR domain_pre;
			$OPEN domain_cur;
			while(1)
			{
				$FETCH domain_cur INTO $edomain_tmp;
				if(SQLCODE == SQLNOTFOUND) break;
				if (check_point > 0)
				{
					strcat(edomain,"�B");
				}
				strcat(edomain,rtrim(edomain_tmp));
				check_point++;
			}
			
			icont_len = 0;
			printf("edomain[%s] \n",edomain);
			while(icont_len <= strlen(edomain))
			{
				iTmpLen = 0;
				ed_tmp[0] = '\0';
				
				iTmpLen = iGetChinesePos(edomain+icont_len,tmplen);
				strncpy(ed_tmp,edomain+icont_len,iTmpLen+1);
				ed_tmp[iTmpLen+1] = '\0';
				printf("ed_tmp[%s] \n",ed_tmp);
				
				icont_len = icont_len + iTmpLen + 1;
				
				insert_freeform(&icolumn,"NOTE");
				insert_freeform(&icolumn,ed_tmp);
				insert_freeform(&icolumn,"C");
			}

			/* �ݥ��ˬd */
			insert_freeform(&icolumn,"NOTE");
			insert_freeform(&icolumn," ");
			insert_freeform(&icolumn,"Q");
		}
	
		/* �O���Ƶ��� */
		insert_freeform(&icolumn,"QPQ");
		
		/* ���[PDF NOTICE */
		{
			/*if (fprov_yn[0] == 'Y')
			{
				insert_freeform(&icolumn,"NOTICE");
				insert_freeform(&icolumn,"PersonalInfo"); /* �Ӹ��n�� *
				insert_freeform(&icolumn,"PolicyNotice"); /* ��O���� *
				insert_freeform(&icolumn," "); /* �O��A�ȥd *
				insert_freeform(&icolumn," "); 
				insert_freeform(&icolumn," "); 
				insert_freeform(&icolumn,"Q");	
			}*/
		}
		
		/* ���ڥN�� CONDITION */
		if (fprov_yn[0] == 'Y')
		{
			/* CONDITION */
			insert_freeform(&icolumn,"CONDITION");
			
			sprintf_s(stmt_cond, sizeof stmt_cond,"SELECT icondition,qserial FROM condition order by qserial;");
			$PREPARE condition_pre FROM $stmt_cond;
			$DECLARE condition_cur CURSOR FOR condition_pre;
			$OPEN condition_cur;
			while(1)
			{
				$FETCH condition_cur INTO $icondition1,$qserial1;
				if(SQLCODE == SQLNOTFOUND) break;
				strcpy(icondition1,trim(icondition1));
				if (qserial1 > 1)
				{
					/* �ݥ��ˬd */
					insert_freeform(&icolumn,"C");
					/* CONDITION */
					insert_freeform(&icolumn,"CONDITION");
				}
				/* ���ڥN�� */
				insert_freeform(&icolumn,icondition1);
			}
			$CLOSE condition_cur;
			$FREE condition_cur;

			/* �ݥ��ˬd */
			insert_freeform(&icolumn,"Q");
			
			$DELETE FROM condition;
		}
	}
	/* �C�L���� */
	insert_freeform(&icolumn,"END");
	
	printf("-------------------------------------------------------- \n");  
    /** �]�w��car140 ���O=SR ����W��=2 ���q���g��N���A **/
    /* �i�F����ġj����L��N�O��^�����u�e�~�v, �l�H�覡���u���H�v(1041102003_C1) */
    if (strncmp(sIpolicyB_type,"0",1) == 0)
    {
        if (cntIroute > 0 && (strncmp(sIrouteNote,"2",1) == 0)) 
        {
       	    printf("�q���O���O(�e�~�O����)[%s]\n", sIrouteNote);
            $UPDATE ply_relation
                SET fout_print = '1',
                    fmail_type = '1'
              WHERE fcard_class = '2'
                AND ipolicy = $ipolicy
                AND dpolicy IS NULL
                AND dply_close IS NULL;
        }
    }

    /* �M���I�ت�table */
    /* �]���O��C�L�h��,�P�_�ӭ����̫�@��,�~�M��temp table �B�g�J���ڰO����
       modify by sylvia 101.10.08 (1010928006_C1) */
    /*if (ipage == Pcount)*/
    {
		$DELETE FROM print_layout where ipolicy = $ipolicy;
		$DELETE FROM tbl_print WHERE ipolicy = $ipolicy;
		$DELETE FROM tbl_coverage WHERE ipolicy = $ipolicy;
		$DELETE FROM tbl_56list WHERE ipolicy = $ipolicy;
		/* �g�J���ڰO���� ------------------------------------------------------- */
	   
		if(strlen(ireceipt) > 0) 
		{
			if (strncmp(sIpolicyB_type,"2",1) != 0 && strncmp(sIpolicyB_type,"3",1) != 0 )
			{
				/* �D�e�~��*/
				strcpy(sDate,"today");
				strcpy(sDateTime,"current");
				strcpy(sRemark," ");
				strcpy(sDateTime,trim(sDateTime));
				if (strcmp(trim(dpolicy),"") == 0)
				{
					strcpy(iversion,"A");     /* ���� */
				}
				else
				{
					if (strncmp(sIpolicyB_type,"0",1) == 0)
					{
						/* �z�Lcar344�C�L�e�~��(�鵲�e),���������� add by larry 103.03.28 (1010523004_C2) */
						if (strncmp(fout_print,"1",1) == 0 && strncmp(fmail_type,"0",1) != 0 && strcmp(trim(dply_close),"") == 0 )
						{
							strcpy(iversion,"A");  /* ���� */
						}
						else
						{
							strcpy(iversion,"S");  /* �ɦL */
						}
					}
					else
					{
						/* �M�ץ�G�Ƶ��g�J�i�O��e�~�L�s�jmodify by larry 103.05.22 (1030325001_C1) */
						strcpy(sRemark,"�O��e�~�L�s");
						strcpy(iversion,"A");  /* ���� */
					}
				}
			}
		    else
		    {
		        /* �e�~��G�Ƶ��g�J�e�~�L�s add by larry 103.03.28 (1010523004_C2) */
				strcpy(sDate,"today");
				strcpy(sDateTime,"'");
				strcat(sDateTime,substring(dcreate,1,19));
				strcat(sDateTime,"'");
				strcpy(sRemark,"�e�~�L�s");
				strcpy(iversion,"A");      /* ���� */
		    }
	
		    idbstr = atoi(&ply1[4]);
		
		    printf("idbstr=[%d], ply1=[%s] \n",idbstr, ply1);
			switch (idbstr)
			{
				case 0:
					strcpy(idb,"00");
				break;
				
				case 1:
					strcpy(idb,"40");
				break;
				
				case 2:
					strcpy(idb,"70");
				break;
				
				case 5:
					strcpy(idb,"22");
				break;
				
				case 6:
					strcpy(idb,"33");
				break;
				
				case 7:
					strcpy(idb,"66");
				break;
			}
		
			/* cm_receipt_log.nassured �u��  varchar(100,0) �ҥH�n�^�X add by sylvia 101.03.07 */
			strcpy(sNass1, trim(nassured));
			
			if (strlen(sNass1) > 100)
			{
				iTmp1 = iGetChinesePos(sNass1,100);
				strncpy(s_Nassured,&sNass1[0],iTmp1+1);
				s_Nassured[iTmp1+1] = '\0';
			}
			else
			{
				strcpy(s_Nassured, trim(sNass1));
			}
		
			/* cm_receipt_log.napplicant �u��  varchar(100,0) �ҥH�n�^�X add by sylvia 101.03.07 */
			strcpy(sNapp1, trim(napplicant));
			if (strlen(sNapp1) > 100)
			{
				iTmp1 = iGetChinesePos(sNapp1,100);
				strncpy(s_Napplicant,&sNapp1[0],iTmp1+1);
				s_Napplicant[iTmp1+1] = '\0';
			}
			else
			{
				strcpy(s_Napplicant, trim(sNapp1));
			}
		
			/* �P�_(�e�~��)�O��ӫO���e�󭶼g�Jcm_receipt_log.ntarget2 add by larry 103.06.05 (1030415003_C1) */
			if (strncmp(sIpolicyB_type,"2",1) == 0 || strncmp(sIpolicyB_type,"3",1) == 0 )
			{
				if(Pcount > 1)
					sprintf_s(ntarget2, sizeof ntarget2,"%d",Pcount);
				else
					strcpy(ntarget2," ");
			}
			else
			{
				strcpy(ntarget2," ");
			}

			strcpy(stmpx," ");
			strcpy(iendorse_tmp," ");
			if(bufa_print == 0)
			{
				/*if((strlen(iendorse_free) > 0 && edrprem > 0) || strlen(iendorse_free) == 0)
				{
					if(strlen(iendorse_free) > 0) strcpy(iendorse_tmp,iendorse_free);
					else strcpy(iendorse_tmp," ");
					
					strcpy(stmpx," ");
					sprintf_s(stmpx, sizeof stmpx, "insert into cm_receipt_log \
					               (ireceipt, iins_cat, ipolicy, iendorse, itype, \
					                iversion, idb, iprint, dprint, remark,  \
					                dreceipt, nassured, napplicant, dbegin, dend, \
					                curr, mpremium, ileader, pexchg_rate, mprem_cur, \
					                iofficer, ntarget2,azip,aaddress) \
					        values \
					               ( '%s', 'C', '%s', '%s', 'N', \
					                 '%s', '%s', '%s', %s, '%s', \
					                 %s, '%s', '%s', %ld, %ld, \
					                 'NT', %ld, '%s', 1.0000, %ld, '%s', '%s',' ',' ')",
					                 ireceipt, ipolicy, iendorse_tmp, iversion, idb, iprint, sDateTime,sRemark,sDate,
					                 nassured,napplicant, dply_begin, dply_end, real1_premium,
					                 ileader, real1_premium,iofficer, ntarget2);
					printf("stmpx=[%s]\n",stmpx);
					$PREPARE ins_pre1 FROM $stmpx;
					$EXECUTE ins_pre1;
					strcpy(stmpx," ");

					sprintf_s(stmpx, sizeof stmpx, "insert into cm_receipt_log_dtl \
						              (ireceipt,ipolicy,iendorse,ftype,curr,pexchg_rate,mprem_cur) \
						        values('%s','%s','%s','N','NT',1.0000,'%ld') ",ireceipt,ipolicy,iendorse_tmp,real1_premium);
					printf("stmpx=[%s]\n",stmpx);
					$PREPARE ins_pre2 FROM $stmpx;
					$EXECUTE ins_pre2;
					strcpy(stmpx," ");
					   
					sprintf_s(stmpx, sizeof stmpx, "insert into cm_receipt_log_prt \
						              (ireceipt,fformal,fversion,fnote,iprint,dprint,isource) \
						        values('%s','F','%s',' ','%s',current,'car306') ",ireceipt,iversion,iprint);
					printf("stmpx=[%s]\n",stmpx);
					$PREPARE ins_pre3 FROM $stmpx;
					$EXECUTE ins_pre3;
					strcpy(stmpx," ");
				}*/
				strcpy(stmpx," ");
				sprintf_s(stmpx, sizeof stmpx, "insert into cm_receipt_log \
				               (ireceipt, iins_cat, ipolicy, iendorse, itype, \
				                iversion, idb, iprint, dprint, remark,  \
				                dreceipt, nassured, napplicant, dbegin, dend, \
				                curr, mpremium, ileader, pexchg_rate, mprem_cur, \
				                iofficer, ntarget2,azip,aaddress) \
				        values \
				               ( '%s', 'C', '%s', ' ', 'N', \
				                 '%s', '%s', '%s', %s, '%s', \
				                 %s, '%s', '%s', %ld, %ld, \
				                 'NT', %ld, '%s', 1.0000, %ld, '%s', '%s',' ',' ')",
				                 ireceipt, ipolicy, iversion, idb, iprint, sDateTime,sRemark,sDate,
				                 nassured,napplicant, dply_begin, dply_end, real1_premium,
				                 ileader, real1_premium,iofficer, ntarget2);
				printf("stmpx=[%s]\n",stmpx);
				$PREPARE ins_pre1 FROM $stmpx;
				$EXECUTE ins_pre1;
				strcpy(stmpx," ");
				/*1060818001_C1_cmn134a-���I */
				/*�W�[�g�J���ک��ӤΦC�L�O��*/
				sprintf_s(stmpx, sizeof stmpx, "insert into cm_receipt_log_dtl \
					              (ireceipt,ipolicy,iendorse,ftype,curr,pexchg_rate,mprem_cur) \
					        values('%s','%s',' ','N','NT',1.0000,'%ld') ",ireceipt,ipolicy,real1_premium);
				printf("stmpx=[%s]\n",stmpx);
				$PREPARE ins_pre2 FROM $stmpx;
				$EXECUTE ins_pre2;
				strcpy(stmpx," ");
				   
				sprintf_s(stmpx, sizeof stmpx, "insert into cm_receipt_log_prt \
					              (ireceipt,fformal,fversion,fnote,iprint,dprint,isource) \
					        values('%s','F','%s',' ','%s',current,'car306') ",ireceipt,iversion,iprint);
				printf("stmpx=[%s]\n",stmpx);
				$PREPARE ins_pre3 FROM $stmpx;
				$EXECUTE ins_pre3;
				strcpy(stmpx," ");
		    }
		}
	}
	return M_CM_OK;

errexit:
    printf("SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------------------------------------------------------------------------------------------*/
long process_rpt()
{
	$double i;
	$int    ser_no;
	$double max_line_no;
	$int    cnt_56list;
	$char   field1[7],field2[121],field3[251],field4[121],field5[121],field6[121],field7[121];
	$int    len1,len2,len3,len4,len5,len6,len7;
	$char   tmp_ipolicy[21],tmp_field1[7],tmp_field2[121],tmp_field3[251],tmp_field4[121],tmp_field5[121],tmp_field6[121],tmp_field7[121];
	$char   tmp_relation_bene[16],tmp_tbenef[21],tmp_abenef[91],tmp_nbeneficiary[38];
	$char   stmp_abenef1[38],stmp_abenef2[38],stmp_abenef3[38];
	$char   tmp_address[91];
	$char   address1[10],address2[11],address3[13],address4[14],address5[10],address6[11],address7[13],address8[14];
	$int    tmp_ins_premium;
	$int    itmp_abenef1,itmp_abenef2,itmp_abenef3,count_abenef;

    $WHENEVER SQLERROR GOTO errexit;

    printf("get into process_rpt\n");
    
    $DECLARE tmp_cur CURSOR for
      SELECT line_no,nvl(field1,' '),nvl(field2,' '),nvl(field3,' '),nvl(field4,' '),
             nvl(field5,' '),nvl(field6,' '),nvl(field7,' '),
             length(field1),length(field2),length(field3),length(field4),
             length(field5),length(field6),length(field7), ins_premium
        FROM tbl_print
       WHERE ipolicy = $ipolicy;
printf("?1\n");
    $OPEN tmp_cur;
    while (1)
    {
        $FETCH tmp_cur INTO $ser_no,
             		$field1,$field2,$field3,$field4,$field5,$field6,$field7,
             		$len1,$len2,$len3,$len4,$len5,$len6,$len7,$ins_premium;

        if (SQLCODE == SQLNOTFOUND) break;
    }
    $CLOSE tmp_cur;
    $FREE tmp_cur;
    printf("finish print...................................\n");

    $Update tbl_print set
        field1 = Nvl(field1,''),
        field2 = Nvl(field2,''),
        field3 = Nvl(field3,''),
        field4 = Nvl(field4,''),
        field5 = Nvl(field5,''),
        field6 = Nvl(field6,''),
        field7 = Nvl(field7,'')
      WHERE ipolicy = $ipolicy;

    i = 0.0;
	printf("get into while\n");
    while(1)
    {
        puts("in while 1");
    	i += 0.01;

	    $INSERT INTO print_layout
	     SELECT ipolicy, line_no + $i,
		    field1[1,3],
		    field2[1,40],
		    field3[1,40],
		    field4[1,40],
		    field5[1,40],
		    field6[1,40],
		    field7[1,8],
	                ins_premium,
	                ''
	       FROM tbl_print
	          WHERE ipolicy = $ipolicy;
	
	    printf("i=[%f]\n,tcount=[%d]\n",i,sqlca.sqlerrd[2]);
	    if(sqlca.sqlerrd[2] == 0) break;

	    $UPDATE tbl_print SET
		    field1 = field1[4,6],
		    field2 = field2[41,120],
		    field3 = field3[41,250],
		    field4 = field4[41,120],
		    field5 = field5[41,120],
		    field6 = field6[41,120],
		    field7 = field7[9,120],
	                ins_premium = 0
	          WHERE ipolicy = $ipolicy;
			
		$DELETE tbl_print
		  WHERE field1 || field2 || field3 || field4 || field5 || field6 || field7 = ''
		    AND ipolicy = $ipolicy;
	}
    printf("finish process_rpt\n");

    /*tbl_56list �g�J print_layout*/
    $SELECT count(*) INTO $cnt_56list FROM tbl_56list WHERE ipolicy = $ipolicy AND ninsurant!='' AND iinsurant!='1';
    printf("cnt_56list[%d]\n",cnt_56list);
    if(cnt_56list==0 )
    {
       /*do Nothing  */               
    }
    else
    {
    	max_line_no = 0;                 
        /*$INSERT INTO print_layout (ipolicy,line_no,field1,field2,field3,field4,field5,field6,field7,ins_premium,field_tmp) 
                           VALUES ($ipolicy,$max_line_no+1,'','','','','','','',0,''); 
        $INSERT INTO print_layout (ipolicy,line_no,field1,field2,field3,field4,field5,field6,field7,ins_premium,field_tmp) 
                           VALUES ($ipolicy,$max_line_no+2,'�i','�r�p�H�ˮ`�I�W�U','�j','','','','',0,'');        */
	
	    if (strncmp(sProtectData,"0",1) != 0)/*�B�n*/
	    {
	        $DECLARE cur_56list1 CURSOR for
	              SELECT ipolicy,
	                    iins_type,
	                    ''||trim(ninsurant),
	                    case when dbirth='' then '' when dbirth='01/01/1912' then '' when dbirth is null then '' else '**/'||to_char(dbirth,'%m')||'/**' end ,
	                    case when trim(iinsurant)='' then '' else''||trim(iinsurant[1,4])||'****'||trim(iinsurant[9,10]) end,
	                    ''||trim(nbeneficiary),
	                    0,
	                    relation_bene,
	                    case when trim(tbenef)='' then '' else ''||tbenef[1,3]||'XXXX'||tbenef[8,12] end,
	                    abenef
	               FROM tbl_56list 
	              WHERE ipolicy = $ipolicy AND trim(ninsurant)!='' AND trim(iinsurant)!='1';        	
	    $OPEN cur_56list1;
	    }
	    else  /*���B�n*/
	    {
	        $DECLARE cur_56list2 CURSOR for
	              SELECT ipolicy,
	                    iins_type,
	                    ''||trim(ninsurant),
	                    case when dbirth='' then '' when dbirth='01/01/1912' then '' when dbirth is null then '' else ''|| to_char(year(dbirth)-1911)||to_char(dbirth,'/%m/%d') end ,
	                    case when trim(iinsurant)='' then '' else''||trim(iinsurant) end,
	                    ''||trim(nbeneficiary),
	                    0,
	                    relation_bene,
	                    ''||tbenef[1,12],
	                    abenef
	               FROM tbl_56list 
	              WHERE ipolicy = $ipolicy AND trim(ninsurant)!='' AND trim(iinsurant)!='1'; 
	    	
	        $OPEN cur_56list2;
	    }
	    
        $int p;
        for(p=0;p<cnt_56list;p++)
        {
			if (strncmp(sProtectData,"0",1) != 0)/*�B�n*/
			{
				$FETCH cur_56list1 INTO $tmp_ipolicy,$tmp_field1,$tmp_field2,$tmp_field3,$tmp_field4,$tmp_nbeneficiary,$tmp_ins_premium,
				                        $tmp_relation_bene,$tmp_tbenef,$tmp_abenef;
			}
			else
			{
				$FETCH cur_56list2 INTO $tmp_ipolicy,$tmp_field1,$tmp_field2,$tmp_field3,$tmp_field4,$tmp_nbeneficiary,$tmp_ins_premium,
				                        $tmp_relation_bene,$tmp_tbenef,$tmp_abenef;        	
			}
      		
			if (strncmp(tmp_relation_bene,"1",1)==0) strcpy(tmp_relation_bene,"���H");
			else if (strncmp(tmp_relation_bene,"2",1)==0) strcpy(tmp_relation_bene,"�a��");
			else if (strncmp(tmp_relation_bene,"3",1)==0) strcpy(tmp_relation_bene,"�O�Υ����H");
			else if (strncmp(tmp_relation_bene,"4",1)==0) strcpy(tmp_relation_bene,"�ŰȤH");
			else if (strncmp(tmp_relation_bene,"5",1)==0) strcpy(tmp_relation_bene,"�]���޲z�H");
			else if (strncmp(tmp_relation_bene,"6",1)==0) strcpy(tmp_relation_bene,"�k�w�~�ӤH");
			else if (strncmp(tmp_relation_bene,"7",1)==0) strcpy(tmp_relation_bene,"�t��");
			else if (strncmp(tmp_relation_bene,"8",1)==0) strcpy(tmp_relation_bene,"���t����");
			else strcpy(tmp_relation_bene,"");
			
			strcpy(tmp_tbenef,trim(tmp_tbenef));
			
			/*�W�U�Q�O�H�B�ͤ�B�����Ҹ��B���q�H�B���Y�B�q�ܡB�a�}*/  
			$INSERT INTO print_layout56 (ipolicy,line_no,field1,field2,field3,field4,field5,field6,field7,ins_premium,field_tmp)
			       VALUES ($tmp_ipolicy,$max_line_no+1+$p,$tmp_field1,$tmp_field2,$tmp_field3,$tmp_field4,$tmp_nbeneficiary,$tmp_relation_bene,$tmp_tbenef,$tmp_ins_premium,$tmp_abenef);
		}
		
        if (strncmp(sProtectData,"0",1) != 0)/*�B�n*/
        {
            $CLOSE cur_56list1;
            $FREE cur_56list1; 
        }
        else
        {
            $CLOSE cur_56list2;
            $FREE cur_56list2;        	
        }
	}
	
	return M_CM_OK;

errexit:
	printf("process_rpt SQLCODE[%d]\n", SQLCODE);
	return SQLCODE;
}
/*--------------------------------------------------------------------*/
/** ���o���^���q�������T���嵲����m **/
int *iGetChinesePos(sStrTmp,iPos)
char *sStrTmp;
int  iPos;
{
   int  iTrueLen;
   int  i,x;

   for(i = 0; i<= iPos; i++){
         if ((int)(sStrTmp[i]) >= 128){
                i++;
         }
   }
   return (i-1);
}
/*********************************************************************************/
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
        char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
        static char sTmp_db_name[31];

        sTmp_db_name[0]='\0';
        if (*sIpolicy != '\0' && *sIpolicy !=' ')
        {
           sTmp_db_name[0]='\0';
           strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
           strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
                  USE_BRANCH_ID));
           strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
        }
  return sTmp_db_name;
}
/*********************************************************************************/
long insert_prt_table(ipolicy,iins_type,nins_type,main_paid,cover_print,amt_print,prn_deduct,str_ins_premium,ins_premium)
$char ipolicy[21];
$char iins_type[7];
$char nins_type[121];
$char main_paid[251];
$char cover_print[121];
$char amt_print[121];
$char prn_deduct[121];
$char str_ins_premium[121];
$long ins_premium;
{
	$WHENEVER SQLERROR GOTO errexit;
	
	printf("ipolicy=[%s],iins_type=[%s],nins_type=[%s],main_paid=[%s]\n",ipolicy,iins_type,nins_type,main_paid);
	printf("cover_print=[%s],amt_print=[%s],prn_deduct=[%s],str_ins_premium=[%s]\n",cover_print,amt_print,prn_deduct,str_ins_premium);
	printf("ins_premium=[%ld]\n",ins_premium);

	printf("insert table tbl_print...................................\n");
	$INSERT INTO tbl_print
	  (ipolicy,field1,field2,field3,field4,field5,field6,field7, ins_premium)
	 VALUES
	  ($ipolicy,$iins_type,$nins_type,$main_paid,$cover_print,$amt_print,$prn_deduct,$str_ins_premium,
	           $ins_premium);
	printf("end of insert......................\n");

errexit:
	return SQLCODE;
}
/*********************************************************************************/
long insert_freeform(iline,ncontent)
long  *iline;
$char ncontent[256];
{
	$long iline2;
	$char inumber[21],ncontent_tmp[256];
	iline2 = *iline;
	
	$WHENEVER SQLERROR GOTO errexit;
	
	strcpy(ncontent_tmp,rtrim(ncontent));
	if(strlen(iendorse_free) == 0) strcpy(inumber,ipolicy);
	else strcpy(inumber,iendorse_free);

	strcpy(inumber,rtrim(inumber));
	printf("kpid=[%s],inumber=[%s],iline=[%d],ncontent_tmp=[%s]\n",kpid,inumber,iline2,ncontent_tmp);
	
	if (strlen(ncontent_tmp)==0)
	{
		$INSERT INTO ca_freeform_tmp (kpid,  inumber, iline,  ncontent)
		                      VALUES ($kpid ,$inumber,$iline2, ' ');
	}
	else 
	{
		$INSERT INTO ca_freeform_tmp (kpid,  inumber, iline,  ncontent)
		                      VALUES ($kpid, $inumber,$iline2,$ncontent_tmp);
	}
	
	iline2++;
	*iline = iline2;
errexit:
    return SQLCODE;
}

/*********************************************************************************/
int IsFcomp24(str)
char *str;
{
    while (*str)
    {
        if (*str == '2')
        {
           str++;
           if (*str == '4')
           {
              return TRUE;
           }
           else
           {
              str--;
           }
        }
        str++;
    }
    return FALSE;
}
/*********************************************************************************/
int IsFcomp55(str)
char *str;
{
    while (*str)
    {
        if (*str == '5')
        {
           str++;
           if (*str == '5') /* original version is if (*str == '1') */
           {
              return TRUE;
           }
           else
           {
              str--;
           }
        }
        str++;
    }
    return FALSE;
}

long ca_free_data(sIpolicy)
char *sIpolicy;
{
	$char iline;
	$char stmt_free[1024],s_ipolicy[21],ncontent[256];
	FILE  *fptr, *fptr_err;
	int   count_db,k,i; 
	$char DBName[05];
	$char msgbuf[128];
	DBinfo *list;
	char    sApHome[30];
	int rtncode,rc;
	char    filename[30];
	FILE    *fp;
	char  file_catalog[200];
	$char filename1[200];
	char userid[12],errmsg[300],Message[300];
	char  prtstr[500];
	
	strcpy(s_ipolicy,sIpolicy);
	
	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
	 	return rc;
	}
	
	filename[0]    = '\0';
	file_catalog[0] = '\0';
	sprintf_s(filename, sizeof filename,"%s/rptftp/", sApHome);
	sprintf_s(filename1, sizeof filename1,"car306a_%s_%s.txt",kpid,s_ipolicy);
	strcpy(file_catalog, trim(filename));
	strcat(file_catalog, trim(filename1));
	printf("file_catalog[%s]\n",file_catalog);
	
	$whenever sqlerror goto errexitM;

	if ((fptr=fopen(file_catalog,"w")) == NULL)
	{
		return M_CM_OPEN_FILE_FAIL;
	}

	sprintf_s(stmt_free, sizeof stmt_free,"SELECT ncontent FROM ca_freeform WHERE inumber = '%s' AND kpid = '%s' ORDER BY iline,rowid",s_ipolicy,kpid);

	printf("stmt_free[%s] \n",stmt_free);
	$PREPARE ca_freeform_P FROM $stmt_free;
	$DECLARE ca_freeform_D CURSOR FOR ca_freeform_P;
	$OPEN ca_freeform_D;
	while (1)
	{
		$FETCH ca_freeform_D INTO $ncontent;
		if (SQLCODE == SQLNOTFOUND) break;

		strcpy(ncontent,rtrim(ncontent));
		printf("ncontent[%s] \n",ncontent);
		if (strcmp(ncontent,"C")==0 || strcmp(ncontent,"Q")==0 || strcmp(ncontent,"QPQ")==0 || strcmp(ncontent,"QEQ")==0)
		{
			fprintf(fptr,"%s\n",ncontent);
		}
		else if (strcmp(ncontent,"END")==0)
		{
			fprintf(fptr,"%s",ncontent);
		}
		else
		{
			fprintf(fptr,"%s",ncontent);
		}
	}
	$CLOSE ca_freeform_D;
	$FREE ca_freeform_D;
	
	fclose(fptr);
	
	printf("END\n");
	return M_CM_OK;

errexitM:
	printf("usrid=%s SOLCODE=%d sqlca.sqlerrm=%s\n",userid,SQLCODE,sqlca.sqlerrm);
	sprintf_s(errmsg, sizeof errmsg,"userid=%s SOLCODE=%d sqlca.sqlerrm=%s",userid,SQLCODE,sqlca.sqlerrm);
	fprintf(fptr_err,"%s\n",errmsg);
	return SQLCODE;	
}