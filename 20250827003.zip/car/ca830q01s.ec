/************************************************/
/*                                              */
/*   PROGRAM : ca830q01s.ec                     */
/*                                              */
/*                                              */
/************************************************/
#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "safeclib.h"
/*------------------------------------*/

$char ibranch[3], nchi_abv[13];
$int  ItemRow, TotColumn;
$int  StartRow,TitleRow;
$int  PgLine, Width=0;

char SysTm[ N_TM+1];
char BodyFile[ N_FILE+1];
char TitleFile[ N_FILE+1];
char outputf[ N_FILE+1];
char yy[3], mm[3], dd[3];
char yy1[3], mm1[3], dd1[3];
char yy2[3], mm2[3], dd2[3];
$char stmt_buf[1024];
int show_flag;

$char iclaim[21],fstl[2],nacc_driver[19],sNacc_driver[19];
$char dacc_birth[11],iacc_license[11],sIacc_license[11];
$int iclose_type;
$char ipolicy[21],daccident[21],dclaim[21];
$char iacc_reason[3],nuser[25] ,iadjuster[11];
$char iins_type[INSURANCE_TYPE];
$int mins_stl;
$char itag[CA_TAG_NUM];
$char fcard_class[2];
$char nequipment[25];
$char flast[2];

int count_db=0;
$char dbgn1[11];
$char dend1[11];
$char iassured[11];
$char dclose[11];

static int pagenum=1;
static int linecnt=0;

int  max_count, errCode;
int  tmp_len;
int  copies;
int  miy;

long car830_build();
void car830_title();
void car830_body();

/*----------------------------------------------------------------------------*/
$char DBName[5];
$char c_yymmbgn[17],c_yymmend[17];
$char countA[3];
char userid[11];
char FormTp[N_FILE+1];
$int  iCnt, iTot;
$char stmt[1024];

main(argc,argv)
int argc;
char **argv;
{
   char dummy[20],option;
   char prnTitleFile[N_FILE+1], prnBodyFile[N_FILE+1], prnDev[N_NAME+1];
   char tmpcmd[255],hostname[N_NAME+1];
   long rtncode;
   int rc;
   batchinit();

   strcpy(DBName,isNULLstr(argv[1]));
   strcpy(userid,isNULLstr(argv[2]));

   strcpy(c_yymmbgn,isNULLstr(argv[3]));
   strcpy(c_yymmend,isNULLstr(argv[4]));
   strcpy(iassured,isNULLstr(argv[5]));

   strcpy(outputf,isNULLstr(argv[6]));
   
   
   strcpy(c_yymmbgn, cm_to_infdate(c_yymmbgn));
   strcpy(c_yymmend, cm_to_infdate(c_yymmend));

printf("outputf[%s]\n",outputf);
printf("yymmbgn[%s]\n",c_yymmbgn);
printf("yymmend[%s]\n",c_yymmend);
printf("iassured[%s]\n",iassured);

    /**rc = car830_get_db();
    if (rc != SUCCESS)
    return rc;**/


    iTot = 0;
    car830_build();

    rtncode=create_sign_form("car830",BodyFile,Width);
    if (rtncode != 0)
    {
        EWRITE(userid,rtncode,"Error on creating sign form");
        printf("Error on creating sign form, rtncode=%d\n",rtncode);
        return;
    }

  if((rc=save_form_info(F_BLK1,"CA",830,userid,FormTp,max_count,outputf))<0)
    EWRITE(userid,rc,"save form info failure!");

}

/*----------------------------------------------------------------------------*/
long car830_build()
{
$char   TitleFmt[N_FILE+1], BodyFmt[N_FILE+1];
$char   Ipolicy[21], nassured[121],iofficer[21],dply_end[17],nname[21];
$int    tot_count, cnt_mdmg, cnt_mlia, lCount=0;
$char   cc_yymmbgn[17],cc_yymmend[17];
$char   yymmbgn[17],yymmend[17], sTmpIbranch[3], tmp_policy[20];
char    tmpend[17],tmpbgn[17];
int     i_yy,i_mm;
int     i,j;
DBinfo  *list;

   if(db_select(DBName) == False)
   {
    EWRITE(userid,M_CM_DB_NOTOPEN,"M_CM_NOTOPEN");
    return 0;
   } 

	if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
	{
		EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
		return M_CM_NOT_DBLIST;
	}

	$WHENEVER SQLERROR GOTO errexit;
	$SELECT nTitle_Fmt, nBody_Fmt, kStart_Row, kTitle_Row, kItem_Row,
			kTot_Col, kPgNum_Line, kWidth
		INTO $TitleFmt, $BodyFmt, $StartRow, $TitleRow, $ItemRow,
			$TotColumn, $PgLine, $Width
		FROM Form
		WHERE ksys_grp="CA" AND kPgmID = 830;

	strcpy( TitleFmt,rtrim(TitleFmt));
	strcpy( BodyFmt,rtrim(BodyFmt));
	sprintf_s( TitleFile, N_FILE+1,"%s.ti",outputf);
	sprintf_s( BodyFile, N_FILE+1,"%s.bd",outputf);

	strcpy(yymmbgn, cm_to_infdate(c_yymmbgn));
	strcpy(yymmend, cm_to_infdate(c_yymmend));
	printf("&&& yymmbgn:[%s] yymmend:[%s] &&&\n", yymmbgn, yymmend);

	printf("&&& datebgn:[%s], dateend:[%s] &&&\n",  yymmbgn, yymmend);
	/* ***** title file ***** */
	rgu_init_report( TitleFmt,TitleFile);
	car830_title();

	rgu_finish_report();

	/* ***** body file ***** */
	rgu_init_report( BodyFmt,BodyFile);

/*  if((list=get_db_list(&i,DBName)) == (char*)0 )
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return 0;
    }      */
     
    for (i=0;i<count_db;i++)
    {

        sprintf_s(stmt_buf,1024,"select a.iclaim,a.ipolicy,  \
										date(a.daccident), date(a.dclaim) , \
										a.iacc_reason ,b.nuser , a.iadjuster , b.itag ,a.fcard_class, \
										a.nacc_driver,a.dacc_birth,a.iacc_license \
								   from %s:appraisal  a,%s:adjustment_ply b      \
								  where date(a.dclaim) between '%s' and '%s'      \
								    and a.iclaim = b.iclaim         \
									and b.iassured = '%s'           \
							   order by 1 ", list[i].dbname, list[i].dbname, c_yymmbgn,c_yymmend, iassured );
        printf("stmt[%s]\n",stmt_buf);
        EXEC SQL PREPARE Acursor  FROM :stmt_buf;
        EXEC SQL DECLARE Acursor1 CURSOR FOR Acursor;
        EXEC SQL OPEN Acursor1;
        for(;;){
        EXEC SQL FETCH Acursor1 INTO:iclaim, :ipolicy, 
                                    :daccident, :dclaim, 
                                    :iacc_reason, :nuser, :iadjuster, :itag, :fcard_class, 
                                    :nacc_driver, :dacc_birth, :iacc_license;
                              
        if (SQLCODE == SQLNOTFOUND) break;
        
        /* �r�p�m�W�B�n */
        strcpy(sNacc_driver,substring(nacc_driver,1,2));
        strcat(sNacc_driver,"O");
        strcat(sNacc_driver,substring(nacc_driver,5,14));
        
        /* �����Ҧr���B�n */
        strcpy(sIacc_license,substring(iacc_license,1,4));
        strcat(sIacc_license,"XXXX");
        strcat(sIacc_license,substring(iacc_license,9,2));
                 
        if(strcmp(fcard_class,"1")==0) /*�j��*/
        {
        	mins_stl = 0;
			strcpy(fstl," ");
			
			sprintf_s(stmt_buf,1024,"SELECT nvl(sum(mins_stl),0) \
									   FROM %s:ca_stl_victim \
									  WHERE iclaim = '%s'  ",list[i].dbname,iclaim);
			$PREPARE prep FROM $stmt_buf;
			$EXECUTE prep INTO $mins_stl;
			$FREE prep;
			
			strcpy(iins_type,"21");
printf(" ^^^^^^^^^^^^^^^^^^^^^^^ mins_stl[%d] fstl[%s]\n",mins_stl,fstl);  
			
			if( mins_stl == 0 )   
            {
printf(" ****************************************�@\n");             	
            	/* strcpy(iins_type," "); */
            	strcpy(dclose," ");
            	mins_stl = 0;
        	    sprintf_s(stmt_buf,1024,"SELECT nvl(sum(mins_app),0), '0', ' ' \
										   FROM %s:app_ins_type \
										  WHERE iclaim = '%s'  ",list[i].dbname,iclaim);
            	/*strcpy(flast,"0");
				strcpy(fstl," ");*/
            }
			else
			{
				mins_stl = 0;
				sprintf_s(stmt_buf,1024,"SELECT nvl(sum(mins_stl),0),max(flast),fstl \
										   FROM %s:ca_stl_victim \
									      WHERE iclaim = '%s' \
									      GROUP BY fstl ",list[i].dbname,iclaim);
			}
			
			$PREPARE curbrand FROM $stmt_buf;
			$DECLARE curbrand1 CURSOR for curbrand;
            $OPEN curbrand1;
			
            while (1)
			{
				$FETCH curbrand1 INTO $mins_stl,$flast,$fstl;
				if( SQLCODE == SQLNOTFOUND )   
				{  
					strcpy(dclose," ");
					break;
				}
				
				$select dclose
				   into $dclose
				   from ca_clm_process
				  where iclaim = $iclaim;
              
				$select nname
				   into $nname
				   from officer
				  where iofficer = $iadjuster;
              
				strcpy(nequipment, " ");
				$select nequipment
				   into $nequipment
				   from conv_nequipment
				  where ipolicy = $ipolicy;
                 
				rgu_put_body_string(2, iclaim ,1);
				rgu_put_body_string(2, itag,1);
				rgu_put_body_string(2, ipolicy,1);
				rgu_put_body_string(2, daccident , 2);
				rgu_put_body_string(2, dclaim , 2);
				rgu_put_body_string(2, iins_type , 2);
				rgu_put_body_string(2, fstl, 2);
				rgu_put_body_string(2, itos(mins_stl), 2);
				rgu_put_body_string(2, dclose,1);
				rgu_put_body_string(2, flast,1);
				rgu_put_body_string(2, nname,1);
				rgu_put_body_string(2, nuser,1);
				rgu_put_body_string(2, sNacc_driver,1);
				rgu_put_body_string(2, dacc_birth,1);
				rgu_put_body_string(2, sIacc_license,1);
				rgu_put_body_string(2, nequipment,1);
				rgu_put_body(2); max_count++;
				mins_stl = 0;
			}
			$CLOSE curbrand1;
            $FREE  curbrand1;
        }
        else /*���N*/
        {    
			sprintf_s(stmt,1024,"SELECT count(*)  \
								   FROM %s:stl_ins_type  \
								  WHERE iclaim = '%s'  ", list[i].dbname, iclaim );
			$PREPARE prep2 FROM $stmt;
			$EXECUTE prep2 INTO $lCount;
			$FREE prep2;

         	show_flag = 0;
         	mins_stl = 0;
			strcpy(fstl," ");
            if( lCount == 0 )
			{
				 sprintf_s(stmt,1024,"SELECT iins_type , dclose_ctype ,sum(mins_app), '0', ' '  \
								 FROM %s:app_ins_type  \
								WHERE iclaim = '%s'  \
								GROUP BY  iins_type ,dclose_ctype  \
								ORDER BY  iins_type ", list[i].dbname, iclaim );
			}
			else
			{
				sprintf_s(stmt,1024,"SELECT iins_type , dclose ,sum(mins_stl),max(flast),fstl \
									   FROM %s:stl_ins_type  \
								      WHERE iclaim = '%s'  \
							       GROUP BY  iins_type ,dclose ,fstl \
							       ORDER BY  iins_type ", list[i].dbname, iclaim );
			}

            printf("stmt[%s]\n",stmt);
            $PREPARE curbrand FROM $stmt;
            $DECLARE curbrand2 CURSOR for curbrand;
            $OPEN curbrand2;
            while (1)
            {
				$FETCH curbrand2 INTO $iins_type, $dclose , $mins_stl, $flast, $fstl;
				if( SQLCODE == SQLNOTFOUND )   
				{  
					/* strcpy(iins_type," "); */
					strcpy(dclose," ");
					/* mins_stl = 0; */
					break;
			   
				}

printf(" &&&&&&&&&&&&&&&&&&&&&&& iclaim[%s] , iins_type[%s] , dclose[%s] , mins_stl[%d] flast[%s] fstl[%s] \n",
									 iclaim,iins_type,dclose , mins_stl ,flast, fstl);             

				$select nname
				   into $nname
				   from officer
				  where iofficer = $iadjuster;
				  
				strcpy(nequipment, " ");
				$select nequipment
				   into $nequipment
				   from conv_nequipment
				  where ipolicy = $ipolicy;
		   
				
				rgu_put_body_string(2, iclaim ,1);
				rgu_put_body_string(2, itag,1);
				rgu_put_body_string(2, ipolicy,1);
				rgu_put_body_string(2, daccident , 2);
				rgu_put_body_string(2, dclaim , 2);
				rgu_put_body_string(2, iins_type , 2);
				rgu_put_body_string(2, fstl, 2);
				rgu_put_body_string(2, itos(mins_stl), 2);
				rgu_put_body_string(2, dclose,1);
				rgu_put_body_string(2, flast,1);
				rgu_put_body_string(2, nname,1);
				rgu_put_body_string(2, nuser,1);
				rgu_put_body_string(2, sNacc_driver,1);
				rgu_put_body_string(2, dacc_birth,1);
				rgu_put_body_string(2, sIacc_license,1);
				rgu_put_body_string(2, nequipment,1);
				rgu_put_body(2); max_count++;
				mins_stl = 0;
				show_flag = 1;
            }
			
            if(show_flag == 0)
            {
                $select nname
                   into $nname
                   from officer
                  where iofficer = $iadjuster;
              
                strcpy(nequipment, " ");
                $select nequipment
                   into $nequipment
                   from conv_nequipment
                  where ipolicy = $ipolicy;
            
                rgu_put_body_string(2, iclaim ,1);
                rgu_put_body_string(2, itag,1);
			    rgu_put_body_string(2, ipolicy,1);
			    rgu_put_body_string(2, daccident , 2);
			    rgu_put_body_string(2, dclaim , 2);
			    rgu_put_body_string(2, iins_type , 2);
				rgu_put_body_string(2, fstl, 2);
			    rgu_put_body_string(2, itos(mins_stl), 2);
			    rgu_put_body_string(2, dclose,1);
			    rgu_put_body_string(2, flast,1);
			    rgu_put_body_string(2, nname,1);
			    rgu_put_body_string(2, nuser,1);
			    rgu_put_body_string(2, sNacc_driver,1);
			    rgu_put_body_string(2, dacc_birth,1);
			    rgu_put_body_string(2, sIacc_license,1);
			    rgu_put_body_string(2, nequipment,1);
			    rgu_put_body(2); max_count++;
			    mins_stl = 0;
            }      
            $CLOSE curbrand2;
            $FREE  curbrand2;                     	
        }

        }
        $CLOSE Acursor1;
        $FREE Acursor1;
  }/**get_db_list***/
        rgu_put_body(3);  max_count++;
        rgu_finish_report();
         return 0;

errexit:
printf("SQLCODE[%d],ERR[%s]\n",SQLCODE,sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,"Error on SQL");
    return 0;
}

/*----------------------------------------------------------------------------*/
void car830_title()
{
   char yy[4], mm[3],dd[3];
   rgu_put_head_string(1, cm_get_sysd());   /* get_currdt */
   rgu_put_head_string(1, c_yymmbgn);
   rgu_put_head_string(1, c_yymmend);
   rgu_put_head();
}

/*
long car830_get_db()
{

   if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }
    
   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return SUCCESS;

errexit:
   sqlfatal();  
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
 */
