/**********************�@�� Function ****************************/
/**********************CoFunction ****************************/
#ifndef _CARFUN_H_
#define _CARFUN_H_ 
/**********************�P�_�X�����B�Φۭt�B**********************/
#include <decimal.h>
#include "safeclib.h"

char *ascii_judge(ascii, curr)
char *ascii;
char *curr;
{
   /* ��r�ഫ���Ʀr�ι��O */
   static char rtn_string[101];
   char temp[101];
   char temp1[101];
   char temp2[101];
   char ascii2[101];

   unsigned long int amount;
   double amount2;
   long int amount3;

   int  amt1=0, amt2=0;
   int  i=0,j=0,len=0,len1=0,len2=0;
   $char  idelp[3];
   $char  nabv[21];

   strncpy(idelp, curr, 2);
   idelp[2]=0x0;

   $SELECT nabv
      INTO $nabv
      FROM currency
     WHERE idelp = $idelp;

   if(SQLCODE == SQLNOTFOUND)strcpy(nabv, idelp);

   i=0;
   j=0;
   strcpy(temp, " ");
   strcpy(temp1, " ");
   strcpy(temp2, " ");

   printf("ascii = %s \n", ascii);

   strcpy(ascii2, ascii);

   printf("��r�ഫ1 = %s , ascii2 = %s\n", ascii, ascii2);

   /* ascii[16]=0x0; */

   printf("��r�ഫ2 = %s , ascii2 = %s\n", ascii, ascii2);

   len = strlen(ascii2);

   printf("��r�ഫ = %s , len = %d \n", ascii2, len);

   for(i=0;i<101;i++)
   {
     if((ascii2[i] >= '0' && ascii2[i] <= '9') || ((ascii2[i] == '-') && (j==0)))
     {
       temp[j]=ascii2[i];
       j++;

       if(i==99)
       {
         temp[j]=0x0;
         printf("��r�ഫend = %s \n", temp);
         break;
       }
     }
     else
     {
       if(ascii2[i] == 0x0)
       {
         temp[j]=0x0;
         printf("��r�ഫend = %s \n", temp);
         break;
       }
     }
   }

   printf("��r�ഫ = %s \n", temp);

   len1 = strlen(temp);

   if(len1 >= 8)
   {
      amt1 = atol("10000");
      len2 = len1 - 4;

      strncpy(temp2, temp, len2);
      temp2[len2]=0x0;
      amt2 = atol(temp2);

      if(temp[0]=='-')
        amount3 = amt1 * amt2;
      else
        amount = amt1 * amt2;

      printf("amount = %ld \n", amount);

      strncpy(temp2, temp+len2, 4);
      temp2[4]=0x0;

      printf("temp = %s, temp2 = %s, len2 = %d \n", temp, temp2, len2);

      amt2 = atol(temp2);

      if(temp[0]=='-')
        amount3 = amount3 + amt2;
      else
        amount = amount + amt2;

      printf("amt1 = %ld, amt2 = %ld \n", amt1, amt2);
   }
   else
   {
      if(temp[0]=='-')
        amount3 = atol(temp);
      else
        amount = atol(temp);
   }

   printf("amount = %ld, amount3 = %ld \n", amount, amount3);

   if(temp[0]=='-')
     amount2 = amount3 * 1.0;
   else
     amount2 = amount * 1.0;

   printf("amount2 = %e \n", amount2);

   rfmtdouble(amount2,"---,---,---,---,--&",rtn_string);
   strcpy(temp1, trim(nabv));
   strcat(temp1, trim(rtn_string));
   strcpy(rtn_string, temp1);

   strcat(rtn_string, ".-");

   rtn_string[30] = '\0';
   printf("rtn_string = %s \n", rtn_string);
   return rtn_string;
}
#endif
/**********************ascii_judge  end**************************/

char *laser_get_cname()
{
  $static char co_cname[101];

  /* Ū�����q�W�١B�a�}�B�q�� */
  $SELECT nrin_cfull
     INTO $co_cname
     FROM ri_ricom_info
    WHERE irin_com = "17";

  if (SQLCODE==SQLNOTFOUND)
  {
    strcpy(co_cname, " ");
  }

  strcpy(co_cname, rtrim(co_cname));

  return co_cname;
}

char *laser_get_ename()
{

  $static char co_cname[101], co_ename[101], co_addr[101], co_tel[21];
  int   clen=0, tot_len=0, elen=0, i=0;
  char  temp1[101];

  /* Ū�����q�W�١B�a�}�B�q�� */
  $SELECT nrin_cfull, nrin_full, nrin_phone, nrin_addr
     INTO $co_cname,$co_ename, $co_tel, $co_addr
     FROM ri_ricom_info
    WHERE irin_com = "17";

  if (SQLCODE==SQLNOTFOUND)
  {
    strcpy(co_cname, " ");
    strcpy(co_ename, " ");
  }

  strcpy(co_cname, rtrim(co_cname));
  strcpy(co_ename, rtrim(co_ename));
  strcpy(co_addr, rtrim(co_addr));
  strcpy(co_tel, rtrim(co_tel));

  /* �з�22�C�r�e��0.38cm */
  clen = strlen(co_cname);
  tot_len = 0.38 * clen;

  /* �з�12�C�r�e��0.208cm */
  elen = strlen(co_ename);
  printf("clen = %d , elen = %d \n", clen, elen);

  /* �ھڤ���W�m�� */
  /* elen = (((tot_len - (0.208 * elen)) / 2) / 0.208); */
  strcpy(temp1, "");

  /* �^�夽�q�W�m�� */
  elen = (((4.5 / 0.208) * 2) - elen) / 2;

  for(i=0;i<elen;i++)strcat(temp1," ");

  strcat(temp1, co_ename);
  strcpy(co_ename, temp1);

  printf("ename end \n");
  return co_ename;
}

char *laser_get_addr()
{
  $static char addr[201];
  $char co_cname[101], co_ename[101],co_addr[101], co_tel[21] ;
  int   clen=0, tot_len=0, elen=0;

  /* Ū�����q�W�١B�a�}�B�q�� */
  $SELECT nrin_phone, nrin_addr
     INTO $co_tel, $co_addr
     FROM ri_ricom_info
    WHERE irin_com = "17";

  if (SQLCODE==SQLNOTFOUND)
  {
    strcpy(co_addr, " ");
    strcpy(co_tel , " ");
  }
  else
  {
    strcpy(co_addr, trim(co_addr));
    strcpy(co_tel , trim(co_tel));
  }

  printf("addr:%s, tel:%s \n",co_addr, co_tel);
  sprintf_s(addr, sizeof addr,"�`���q�G%s    �q�ܡG%s",co_addr,co_tel);

  printf("addr:%s \n",addr);

  return addr;
}

char *laser_print_bottom(ipolicy, dentry)
$char ipolicy[21];
char dentry[11];
{
  /* �C�L�O�歶�� */
  $char iofficer[11],nyy[4],nmm[3], ndd[3], sdentry[11], temp1[101], sentry[11];
  char comflag;
  int  rtn=0;
  long lbasic=0, lend=0;
  $char co_place[2], nbranch[11], nchi_abv[21], notice[101];

  /* ���o�t�Τ� */
  comflag = 'N';
  strncpy(sentry, cm_sysd_cdatetime_100(cm_get_sysd()), 9);
  sentry[9]=0x0;
  strcpy(sentry, cm_to_infdate(sentry));

  rtn = rstrdate("04/03/2005",&lbasic);   /* ��Ǥ� */
  rtn = rstrdate(sentry,&lend);           /* �t�Τ� */

  printf("basic = %ld, today = %ld, %s \n", lbasic, lend, sentry);

  if(lend > lbasic)comflag = 'Y';

  rgu_put_body_string(43,"{G;�O��01.jpg,120,235,70,30}",1);
  rgu_put_body(43);
  rgu_put_body_string(43,"{P;10,231}�Q�O�I�H���`�N�ƶ�:",1);
  rgu_put_body(43);
  rgu_put_body_string(43,"{P;126,231}{U;CNAME}",1);
  rgu_put_body(43);
  rgu_put_body_string(43,"{F;�ө���,9,0}",1);
  rgu_put_body(43);

  if(comflag == 'Y')
    rgu_put_body_string(43,"{G;�O��02.jpg, 95,235,30,30}",1);
  else rgu_put_body_string(43,"{G;�O��02.jpg, 95,235,24,34}",1);

  rgu_put_body(43);

  rgu_put_body_string(43,"{V;10,236}",1);
  rgu_put_body(43);

  /* Ū���`�N�ƶ� */
  $SELECT ncode
     INTO $notice
     FROM cu_code_data
    WHERE itype = '43'
      AND icode = '01';

  if (SQLCODE==SQLNOTFOUND) strcpy(temp1, " ");
  else strcpy(temp1, notice);

  rgu_put_body_string(43,temp1,1);
  rgu_put_body(43);

  $SELECT ncode INTO $notice
     FROM cu_code_data
    WHERE itype = '43' AND icode = '02';

  if (SQLCODE==SQLNOTFOUND) strcpy(temp1, " ");
  else strcpy(temp1, notice);

  rgu_put_body_string(43,rtrim(temp1),1);
  rgu_put_body(43);

  $SELECT ncode INTO $notice
     FROM cu_code_data
    WHERE itype = '43' AND icode = '03';

  if (SQLCODE==SQLNOTFOUND) strcpy(temp1, " ");
  else strcpy(temp1, notice);

  rgu_put_body_string(43,temp1,1);
  rgu_put_body(43);

  $SELECT ncode INTO $notice
     FROM cu_code_data
    WHERE itype = '43' AND icode = '04';

  if (SQLCODE==SQLNOTFOUND) strcpy(temp1, " ");
  else strcpy(temp1, notice);

  rgu_put_body_string(43,rtrim(temp1),1);
  rgu_put_body(43);

  $SELECT ncode INTO $notice
     FROM cu_code_data
    WHERE itype = '43' AND icode = '05';

  if (SQLCODE==SQLNOTFOUND) strcpy(temp1, " ");
  else strcpy(temp1, notice);

  rgu_put_body_string(43,temp1,1);
  rgu_put_body(43);

  $SELECT ncode INTO $notice
     FROM cu_code_data
    WHERE itype = '43' AND icode = '06';

  if (SQLCODE==SQLNOTFOUND) strcpy(temp1, " ");
  else strcpy(temp1, notice);

  rgu_put_body_string(43,rtrim(temp1),1);
  rgu_put_body(43);

  rgu_put_body_string(43,"{V}",1);
  rgu_put_body(43);
  rgu_put_body_string(43,"{F;�ө���,6,0}",1);
  rgu_put_body(43);
  rgu_put_body_string(43,"{V;10,260}",1);
  rgu_put_body(43);

  /*$SELECT ncode INTO $notice
     FROM cu_code_data
    WHERE itype = '43' AND icode = '11';

  if (SQLCODE==SQLNOTFOUND) strcpy(temp1, " ");
  else strcpy(temp1, trim(notice));

  $SELECT ncode INTO $notice
     FROM cu_code_data
    WHERE itype = '43' AND icode = '12';

  if (SQLCODE==SQLNOTFOUND) strcat(temp1, " ");
  else strcat(temp1, trim(notice));

  rgu_put_body_string(43,temp1,1);
  rgu_put_body(43);

  $SELECT ncode INTO $notice
     FROM cu_code_data
    WHERE itype = '43' AND icode = '13';

  if (SQLCODE==SQLNOTFOUND) strcpy(temp1, " ");
  else strcpy(temp1, trim(notice));

  $SELECT ncode INTO $notice
     FROM cu_code_data
    WHERE itype = '43' AND icode = '14';

  if (SQLCODE==SQLNOTFOUND) strcat(temp1, " ");
  else strcat(temp1, trim(notice)); 
  
  rgu_put_body_string(43,temp1,1);
  rgu_put_body(43);

  $SELECT ncode INTO $notice
     FROM cu_code_data
    WHERE itype = '43' AND icode = '15';

  if (SQLCODE==SQLNOTFOUND) strcpy(temp1, " ");
  else strcpy(temp1, trim(notice));

  $SELECT ncode INTO $notice
     FROM cu_code_data
    WHERE itype = '43' AND icode = '16';

  if (SQLCODE==SQLNOTFOUND) strcat(temp1, " ");
  else strcat(temp1, trim(notice));

  rgu_put_body_string(43,temp1,1);
  rgu_put_body(43); */
  strcpy(temp1,"�u�p���d�ߥ����q��T���}������󤺮e�A");
  rgu_put_body_string(43,temp1,1);
  rgu_put_body(43);
  strcpy(temp1,"�Цܥ����q���}: http://www.tmnewa.com.tw �d�ߡC");
  rgu_put_body_string(43,temp1,1);
  rgu_put_body(43);
  strcpy(temp1,"�ȪA�ΥӶD�M�u: 0800-050-119�v");
  rgu_put_body_string(43,temp1,1);
  rgu_put_body(43);

  rgu_put_body_string(43,"{V}",1);
  rgu_put_body(43);

  strcpy(sdentry,cm_from_infdate_100(dentry));
  cm_split_ymd_100(sdentry, nyy, nmm, ndd);
  nyy[3]='\0';
  nmm[2]='\0';
  ndd[2]='\0';

  strncpy(co_place,ipolicy+2,1);
  co_place[1]=0x0;

  $select nchi_abv
     into $nchi_abv
     from branch
    where ibranch_abbr = $co_place;

  if(SQLCODE != 0) strcpy(nchi_abv, " ");

  printf("nchi_abv = %s, ipolicy = %s \n", nchi_abv, ipolicy);

  rgu_put_body_string(43,"{F;�ө���,12,0}",1);
  rgu_put_body(43);
  rgu_put_body_string(43,"{F;�ө���,12,0}",1);
  rgu_put_body(43);
  rgu_put_body_string(43,"{P;19,272}",1);
  rgu_put_body(43);

  strcpy(nchi_abv, trim(nchi_abv));

  sprintf_s(temp1, sizeof temp1,"���إ���@�@ %s �@�@�~�@�@  %s�@�@��@�@ %s �@�@��@�ߩ�@�@%s�@�@�@�Ю�", nyy, nmm, ndd, nchi_abv);
  rgu_put_body_string(43,temp1,1);

  rgu_put_body(43);

  $SELECT trim(a.nbranch[1,10]), b.iofficer
     INTO $nbranch, $iofficer
     FROM sa_branch_type a, ot_ply_edr b
    WHERE b.ipolicy = $ipolicy
      AND b.fnewest = 'Y'
      AND a.ibranch = b.iquota;

  if (SQLCODE==SQLNOTFOUND)
  {
      strcpy(nbranch, " ");
      strcpy(iofficer," ");
  }

  rgu_put_body_string(43,"{F;�ө���,10,0}",1);
  rgu_put_body(43);
  rgu_put_body_string(43,"{P;10,278}",1);
  rgu_put_body(43);
  sprintf_s(temp1, sizeof temp1,"%s �@%s", nbranch, iofficer);
  rgu_put_body_string(43,temp1,1);
  rgu_put_body(43);
}



