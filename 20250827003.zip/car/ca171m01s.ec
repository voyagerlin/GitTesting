/************************************************/
/*                                              */
/*   PROGRAM : car171.ec
/*                                              */
/************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
$include decimal;
#include "safeclib.h"


long car171(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car171_insert(),car171_single_query(),car171_multiple_query(),car171_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
	   rtncode=car171_insert(reply);
	   break;
  case 'Q':
	   rtncode=car171_single_query(reply);
	   break;
  case 'M':
           rtncode=car171_multiple_query(reply);
	   break;
  case 'D':
  case 'U':
	   rtncode=car171_update_exec(reply,command,com_len);
	   break;
  default :
	   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
	    return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

long car171_insert(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table insurance_type_develop */
 $char iins_type[7], iins_type_main[3], iins_type_dtl[3], iins_type_develop[3], iins_type_rule[3];
 $char userid[11];
 /* end of insurance_type_develop */

 /* standard defined data */
 int tmp_len;
   DBinfo *list;
   int i, j, is_add_fail=0, api_f;
   $char stmt_buf[2000],stmtx[2000];
 /* end of standard data */

 /* self defined data */
 long MsgCode;
 /* end of self data */

 int LiBufLen;
 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s %s %s %s %s",iins_type,iins_type_main,iins_type_dtl,iins_type_develop,iins_type_rule,userid);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
	return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

 $BEGIN WORK;
 $WHENEVER SQLERROR GOTO errexit;

	$INSERT INTO insurance_type_develop
	       ( iins_type, iins_type_main, iins_type_dtl, iins_type_develop, iins_type_rule,icreate,dcreate,iupdate,dupdate)
	VALUES ($iins_type,$iins_type_main,$iins_type_dtl,$iins_type_develop,$iins_type_rule,$userid,current,$userid,current);

 cm_buf_init(ReplyBuf);
 cm_buf_put("%l",M_CM_OK);
 LiBufLen = cm_buf_len(ReplyBuf);

 if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
 {
	$WHENEVER SQLERROR CONTINUE;
	$ROLLBACK WORK;
	return apiRC;
 }


 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

 errexit:
 printf(" sqlerrm = %s\n",sqlca.sqlerrm);
 $WHENEVER SQLERROR CONTINUE;
 MsgCode = SQLCODE;
 $ROLLBACK WORK;
 if (SQLCODE != 0) MsgCode = SQLCODE;
 return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

long car171_single_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table insurance_type_develop */
 $char iins_type[7], iins_type_main[3], iins_type_dtl[3], iins_type_develop[3], iins_type_rule[3];
 $char icreate[11], dcreate[21], iupdate[11], dupdate[21];
 $dec_t dec;
 /* end of insurance_type_develop */

 /* standard defined data */
 int tmp_len;
 /* end of standard data */


 cm_buf_get("%s",DBName);
 cm_buf_get("%s",iins_type);
 
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 $SELECT iins_type, iins_type_main, iins_type_dtl, iins_type_develop, iins_type_rule, icreate, dcreate, iupdate, dupdate

       /*(select nname from officer where iofficer = a.icreate),
         (select nname from officer where iofficer = a.iupdate)*/
         
  INTO $iins_type, $iins_type_main, $iins_type_dtl, $iins_type_develop, $iins_type_rule, $icreate, $dcreate, $iupdate, $dupdate
  FROM insurance_type_develop
  WHERE iins_type=$iins_type;

 if(SQLCODE == SQLNOTFOUND)  
    {
    	if(exitsub(reply,M_CM_NOT_FOUND) == True)       /*?*/
			return M_CM_NOT_FOUND;                        /*?*/
		else
			return apiRC;
    }

  
 cm_buf_init(ReplyBuf); 
 cm_buf_put("%l",M_CM_OK);
 cm_buf_put("%s %s %s %s %s %s %s %s %s",
 iins_type, iins_type_main, iins_type_dtl, iins_type_develop, iins_type_rule, icreate, dcreate, iupdate, dupdate);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}

long car171_multiple_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table insurance_type_develop */
 $char iins_type[7], iins_type_main[3], iins_type_dtl[3], iins_type_develop[3], iins_type_rule[3];
 $char userid[11];
 $char keyclass[2];
 $dec_t dec;
 $char sTmp1[1000], sTmp2[100],rate[7];
 /* end of insurance_type_develop */

 /* standard defined data */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0; 
 /* end of standard data */


 char pbegin[10];
 int flag;

 cm_buf_get("%s",DBName);
 cm_buf_get("%c %s %s",&(keyclass[0]),pbegin,iins_type);

 keyclass[1] = '\0';

	if (strcmp(iins_type, "*") == 0)
	{
		strcpy(sTmp2, "");
	}
	else
	{
		strcpy(iins_type, cm_to_infdate(iins_type));
		sprintf_s(sTmp2, sizeof sTmp2, " and iins_type = '%s' ", iins_type);
		printf("iins_type=[%s]sTmp2=[%s]\n",iins_type,sTmp2);
	}

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

  flag =0 ;

    sprintf_s(sTmp1, sizeof sTmp1,
    		"SELECT iins_type, iins_type_main, iins_type_dtl, iins_type_develop, iins_type_rule "
            " FROM insurance_type_develop "
    	    " WHERE iins_type matches '%s' %s "
            " ORDER BY iins_type, iins_type_main, iins_type_dtl, iins_type_develop, iins_type_rule;",keyclass, sTmp2);
    printf("sTmp1=[%s]\n",sTmp1);

		$PREPARE m0_pre FROM $sTmp1;
		$DECLARE m0_cur  CURSOR FOR m0_pre;
    $OPEN m0_cur;


 for(;;)
  {

     $FETCH m0_cur into $iins_type, $iins_type_main, $iins_type_dtl, $iins_type_develop, $iins_type_rule;

    if (SQLCODE != 0)
         break;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }


    cm_buf_put("%s %s %s %s %s",iins_type, iins_type_main, iins_type_dtl, iins_type_develop, iins_type_rule);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
	if ( flag == 0 )
	 $CLOSE m0_cur;
        else
	 $CLOSE m1_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
	 cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
	ReplyBuf[0] = '\0';
	count = 0;
	cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%s %s %s %s %s",iins_type, iins_type_main, iins_type_dtl, iins_type_develop, iins_type_rule);
	repbuf_len = cm_buf_len(ReplyBuf);
	count++;
       }
     }
  } /* for loop */

 if ( flag == 0 )
  $CLOSE m0_cur;
 else
  $CLOSE m1_cur;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CM_NOT_FOUND) == True)
    return M_CM_NOT_FOUND;/* M_CA_NDEPRE_RATE */
   else
    return apiRC;
  }

 errexit:
  if(exitsub(reply,SQLCODE) == True)
   return SQLCODE;
  else
   return apiRC;
}


long car171_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table insurance_type_develop */
 $char iins_type[7], iins_type_main[3], iins_type_dtl[3], iins_type_develop[3], iins_type_rule[3];
 $char old_iins_type[7], old_iins_type_main[3], old_iins_type_dtl[3], old_iins_type_develop[3], old_iins_type_rule[3];
 $char icreate[11], dcreate[21], iupdate[11], dupdate[21];
 $char old_icreate[11],old_dcreate[21],old_iupdate[11],old_dupdate[21];
 $char userid[11];
 /* end of insurance_type_develop */

 /* standard defined data */
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len;
 long dummy=0;
   DBinfo *list;
   int i, j=0, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[300];
   $char stmt_buf2[300];
 /* end of standard data */

 /* self defined data */
 long MsgCode;
 /* end of self data */

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s %s",&option,DBName,userid);

printf("F001     \n");
 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
    return M_CM_DB_NOTOPEN;
   else
    return apiRC;
  }

printf("F002     \n");
 if( (list=get_db_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }
 /* compare old record and current record, if the record has not been changed
    since last request, update or delete the record, otherwise return errmsg
    to client side */

printf("F003     \n");
 /* get old record info from command buffer */

 memcpy(&raw_len,&comm[com_len],sizeof(int));
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
printf("F004     \n");
 if (raw_ptr != (char*)0)
  memcpy(raw_ptr,pos,raw_len);
 else
  {
   if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */
    return M_CM_NOT_MALLOC;
   else
    return apiRC;
  }

printf("F005     \n");
 cm_buf_init(raw_ptr);          /* get index key from old record */
 cm_buf_get("%l %s %s %s %s %s",&dummy,old_iins_type, old_iins_type_main, old_iins_type_dtl, old_iins_type_develop, old_iins_type_rule);

printf("F006     \n");
   $BEGIN WORK;
 $SELECT iins_type, iins_type_main, iins_type_dtl, iins_type_develop, iins_type_rule, icreate, dcreate, iupdate, dupdate
  INTO $old_iins_type, $old_iins_type_main, $old_iins_type_dtl, $old_iins_type_develop, $old_iins_type_rule, $old_icreate,
       $old_dcreate,$old_iupdate,$old_dupdate
  FROM insurance_type_develop
  WHERE iins_type=$old_iins_type;

printf("F007     \n");
  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */

 if (SQLCODE == SQLNOTFOUND)
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CM_NOT_FOUND) == True) 
    return SQLNOTFOUND;
   else  
    return apiRC;;
  }
printf("F008     \n");
   $WHENEVER SQLERROR GOTO errexit;

printf("F009     \n");
 cm_buf_init(cur_buf);
 cm_buf_put("%l %s %s %s %s %s %s %s %s %s"
            ,dummy,old_iins_type, old_iins_type_main, old_iins_type_dtl, old_iins_type_develop, old_iins_type_rule, old_icreate,old_dcreate,old_iupdate,old_dupdate);

 write(1,cur_buf,raw_len); printf("\n");
 write(1,raw_ptr,raw_len); printf("\n");

 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CM_NOT_EQUAL) == True)
    return M_CM_NOT_EQUAL;
   else
    return apiRC;
  }
  
  free(raw_ptr);
   $WHENEVER SQLERROR GOTO errexit;

 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
   /* for(j=0;j<i;j++)
   {
   */
    sprintf_s(stmt_buf, sizeof stmt_buf, "DELETE FROM insurance_type_develop WHERE iins_type = ?" );
    $PREPARE d_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_del_fail = 1;
      /* break; */
     }
    $EXECUTE d_id USING $old_iins_type;
    if(SQLCODE != 0)
     {
      is_del_fail = 1;
      /* break; */
     }

  if(SQLCODE != 0)
   {
    is_del_fail = 1;
   }

#ifdef DEBUG
printf("Delete %d\n", j+1);
#endif
   /* } for loop */

   if( is_del_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
/* 9/3/1993    $BEGIN WORK;               */
   cm_buf_init(command);
   cm_buf_get("%c %s %s %s %s %s %s %s",&option,DBName, iins_type, iins_type_main, iins_type_dtl, iins_type_develop, iins_type_rule, userid);

   $WHENEVER SQLERROR CONTINUE;
/*
   for(j=0;j<i;j++)
   {
*/
    sprintf_s(stmt_buf, sizeof stmt_buf, "UPDATE insurance_type_develop "
   		" SET (iins_type, iins_type_main, iins_type_dtl, iins_type_develop, iins_type_rule,iupdate,dupdate) = (?,?,?,?,?,?,current) "
   		" WHERE iins_type = ?");

    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      /* break; */
     }
     printf("%s %s %s %s %s\n",iins_type, iins_type_main, iins_type_dtl, iins_type_develop, iins_type_rule);
    $EXECUTE u_id USING $iins_type, $iins_type_main, $iins_type_dtl, $iins_type_develop, $iins_type_rule, $userid, $old_iins_type;


    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      /* break; */
     }

     if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      /* break; */
     }

    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {
  	sprintf_s(stmt_buf, sizeof stmt_buf, "INSERT INTO insurance_type_develop (iins_type, iins_type_main, iins_type_dtl, iins_type_develop, iins_type_rule) "
  		" VALUES (?,?,?,?,?)" );

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1;
        /* break; */
       }
      $EXECUTE ua_id USING $iins_type, $iins_type_main, $iins_type_dtl, $iins_type_develop, $iins_type_rule;
printf("-----stmt_buf[%s]\n",stmt_buf);
      if(SQLCODE != 0)
       {
        is_upd_fail = 1;
        /* break; */
       }
     }
#ifdef DEBUG
printf("Update %d\n", j+1);
#endif
   /*} for loop */

   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
    return M_CM_WRONG_OPTION;
   else
    return apiRC;
  }

 errexit:
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True)
   return MsgCode;
  else
   return apiRC;
}