/**********************************************************************/
/*   program id   : ca301p03s.ec                                      */
/*   program name : ���I�e�~�O��&�O�I�ҦL�sE-mail�q��(�޲z�H)         */
/*   date written : 2014/03/05                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : Larry Liao                                        */
/*   shell        : car3013_email                                     */
/*   exec time    : �C��ߤW11:30                                     */
/*   batchemail   : �C��W��6:55                                      */
/**********************************************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"
#include "safeclib.h"

char  	outputf[ N_FILE+1];
$char  	userid[11],sDdate[11],sDdate0[16],sDdate1[20],sDdate2[20],nattachment[100];
char  	ddate[11];
char	  syy[4],smm[3],sdd[3],sdate[11];

$char	DBName[5];
DBinfo  *list;
    
int     flen,count_db,i;
FILE    *fp;
char    sApHome[30];
$char   fname[60];
$char   filename[121];
$char	  ftitle[1024],nsubject[512];
	
$char	  mmsg[1024];
$char 	tbuf[501];
$char 	mbuf[9000];
$loc_t 	ctxt;

$char	smail[41];
$char	stmt[1024],stmt_1[4096],stmt_2[4096],stmt_3[4096],stmt_4[4096],stmt_5[4096],stmt_6[4096],stmt_7[4096],stmt_8[4096],stmt_9[4096],stmt_10[4096],stmt_11[4096],stmt1[256],stmt2[256];
char	msgbuf[100];

$char	pre_ileader[11],sNleader[11],year2[3];
$char sIemp[11],sNname[11];
$int 	mail_count,C_count,M_count;
$long	dsys;

$char	ipolicy[21],icard1[21],itag[CA_TAG_NUM],fassured[2],dpolicy[11],iroute[21],dsend[21];
$varchar nassured[121],sNassured[121];
$char	iofficer[11],nofficer[11],ileader[11],nleader[11],nmail_type[12];
$char   sout_trans[3],screate_eply[3];
$int mpremium = 0;
$char   cdate1[11],cdate2[11];
$int c_holiday=0,c_3072=0;
$char ck_holiday_year[4],ck_now[21],ck_holiday[11];
char cmd_stmt[1024];

/* asempl */
$char	email[51],chinese_name[15];

$char stmt_tmp[1024];
/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;
      
    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(ddate,   isNULLstr(argv[3])); /* cyy/mm/dd */
    strcpy(outputf, isNULLstr(argv[4]));
    
    strcpy(sDdate,cm_to_infdate(ddate));   /* sDdate:MM/DD/YYYY */
    strcpy(sDdate,trim(sDdate));
    printf("-----dpolicy : [%s]\n-----",sDdate);
    
    strcpy(sDdate0,cm_from_infdate_100(sDdate)); /* CYY/MM/DD */
    strcat(sDdate0,"/00:00");			 /* CYY/MM/DD/hh:mm */
    strcpy(sDdate1,cm_sysd_edatetime(sDdate0));	 /* YYYY-MM-DD hh:mm */
    strcat(sDdate1,":00");			 /* YYYY-MM-DD hh:mm:ss */
    	
    printf("sDdate1[%s]\n",sDdate1);
    	
    strcpy(sDdate0,cm_from_infdate_100(sDdate));
    strcat(sDdate0,"/23:59");
    strcpy(sDdate2,cm_sysd_edatetime(sDdate0));
    strcat(sDdate2,":59");

    printf("sDdate2[%s]\n",sDdate2);


    rc = car3013_get_db();
    if (rc != M_CM_OK) {
        printf("error on car3013_get_db\n");
        return rc;
    }
    
    strcpy(ck_holiday_year,"");
    strcpy(ck_holiday,"");
    strcpy(ck_holiday_year,cm_get_sysd());
    strcpy(ck_holiday_year,cm_sysd_cyear_100(ck_holiday_year));
    strcpy(ck_holiday,cm_get_sysd());
    strcpy(ck_holiday,cm_sysd_cdate_100(ck_holiday));
    strcpy(ck_holiday,cm_to_infdate(ck_holiday));
    /*strcpy(ck_holiday,"05/28/2016");*/
    printf("-----ck_holiday_year = [%s]-----\n",ck_holiday_year);
    printf("-----ck_holiday = [%s]-----\n",ck_holiday);
    $SELECT count(*)
       INTO $c_holiday 
       FROM ca_holiday  
      WHERE cyear = $ck_holiday_year
        AND $ck_holiday BETWEEN holiday_bgn AND holiday_end;  
    
      
    rc = car3013_init_data();
    if (rc != M_CM_OK) {
        printf("error on car3013_init_data\n");
        return rc;
    }
		        
    /* �d�ߩe�~�O�������� */        
    rc = car3013_ply_data();
    if (rc != M_CM_OK) {
        printf("error on car3013_ply_data\n");
        EWRITE(userid, rc, "�d�߫O���Ʀ��~!");
        return rc;
    }
		    
    /* �H�e���I�e�~�O��L�s�M�� E-mail �q�����޲z�H */
    rc = car3013_send_email_ileader(); 
    if (rc != M_CM_OK) {
        printf("error on car3013_send_email_ileader\n");
        EWRITE(userid, rc, "�H�oE-mail�q���޲z�H���~!");
        return rc;
    }
    
    /*�H�e���Ӫ�*/
    rc = car3013_print();	    
    if (rc != M_CM_OK) {
        printf("error on car3013_print\n");
        EWRITE(userid, rc, "�`�����s���~!");
        return rc;
    }
    
    printf("[car3013]:process ok!\n"); 
}
/*----------------------------------------------------------------------------*/
long car3013_get_db()
{
    int	rc;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
       return M_CM_DB_NOTOPEN;
    }
    
    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }
    
    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
    }

    return M_CM_OK;
}
/*----------------------------------------------------------------------------*/
long car3013_init_data()
{
    $whenever sqlerror goto errexit;


    sprintf_s(stmt_tmp, sizeof stmt_tmp,"create temp table car3013 (\
       ipolicy	       char(20),\
       icard1          char(20),\
       nassured        char(120),\
       itag            char(%d),\
       mpremium        integer,\
       dpolicy         date,\
       iofficer        char(10),\
       nofficer        char(10),\
       iroute          char(20),\
       nmail_type      char(11),\
       ileader         char(10),\
       nleader         char(10),\
       fassured        char(1),\
       sout_trans      char(2),\
       screate_eply    char(2),\
       dsend           DATETIME year TO second\
     )with no log;",CA_TAG_NUM-1);
      $PREPARE stmp FROM $stmt_tmp;
      $EXECUTE stmp;
    	

    
    printf("-----ddate = [%s]-----\n",ddate);
    dsys = cm_ymd_cdate(ddate);
    cm_char_split_3ymd(ddate,syy,smm,sdd);
    
    
    sprintf_s(sdate, sizeof sdate,"%s%s%s",syy,smm,sdd);
    printf("-----sdate = [%s]-----\n",sdate);
    
    
    
    
    /* ���~�� */
    strcpy(year2,substring(sdate,2,2));
    printf("-----���~��:[%s]-----\n",year2);

    /* ���Y */
    strcpy(ftitle,
           "�O�渹�X,�j���Ҹ�,�Q�O�I�H�m�W,���P���X,�O�O,�X����,�g��N��,"
           "�g��N������,�q���N��,�޲z�H�N��,�޲z�H����,�e�~,�q�l,�H�e�覡,�H�e���\n");
    
    /* �D�� */
    sprintf_s(nsubject, sizeof nsubject,"���I�O��ĩe�~�s�o�ιq�l�H�o�q��(%s�~%s��%s��)",syy,smm,sdd);
	
    return M_CM_OK;

errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car3013_ply_data()
{
   int	rc;
   
   $whenever sqlerror goto errexit;
   $SET LOCK MODE TO WAIT 5;  
   for(i=0;i<count_db;i++) 
   {  	 
     /*�e�~�C�L***********************************************************************************/
     /*�e�~�@�ߧ��l�O��*/
     sprintf_s(stmt_1, sizeof stmt_1,"INSERT INTO car3013 "
	   "SELECT a.ipolicy, CASE WHEN a.fcard_class = '1' Then a.icard ELSE ' ' END, "
	   "       b.nassured , b.itag , (a.mdmg_prem+a.mlia_prem) as mpremium , "
	   "       a.dpolicy, a.iofficer, "
	   "      (SELECT nname FROM officer WHERE iofficer = a.iofficer) as nofficer, "
	   "       b.iroute, decode(a.fmail_type,'0','���e�~�l�H','1','���H','2','����', "
	   "                        '3','����','4','����',' '), a.ileader, " 
	   "      (SELECT nname FROM officer WHERE iofficer = a.ileader) as nleader, b.fassured, "
	   "      'V' , "
	   "      ' ' ,a.dout_trans  "
	   "  FROM %s:ori_ply_relation a, %s:original_ply b"
	   " WHERE a.ipolicy = b.ipolicy  "
	   "   AND dpolicy >= '01/11/2016'   "
	   "   AND date(a.dout_trans) = '%s' ",list[i].dbname,list[i].dbname,sDdate);	  
	   printf("stmt1[%s]\n",stmt_1);
	   $prepare pre_ply1 from $stmt_1;
	   $execute pre_ply1;
	  
	  
     /*�q�l�H�e***********************************************************************************/
     /*�w�鵲���l�O��A���鵲��̷s�O��*/
     
     
     /*��j   */
     /*�ȯd���:    �H�e²�T  */
     /*�ȯdEmail:   �H�eEmail */
     /*�d���+Email:�H�eEmail */  
     
     /*���  */
     /*�ȯd���:    �H�e²�T      */
     /*�ȯdEmail:   �H�eEmail     */
     /*�d���+Email:�H�eEmail+²�T*/ 
         
     /*�j+��  */
     /*�ȯd���:    �H�e²�T      */
     /*�ȯdEmail:   �H�eEmail     */
     /*�d���+Email:�H�eEmail+²�T*/ 	
              
              
              
     /*��j�B���鵲���H�e���*/
     sprintf_s(stmt_2, sizeof stmt_2,"INSERT INTO car3013 "
           "SELECT a.ipolicy, a.icard, "
	   "       b.nassured , b.itag , (a.mdmg_prem+a.mlia_prem) as mpremium , "
	   "       a.dpolicy, a.iofficer, "
	   "       (SELECT nname FROM officer WHERE iofficer = a.iofficer) as nofficer, "
	   "       b.iroute, "
	   "       CASE WHEN (a.tmobile_eply IS NULL OR a.tmobile_eply='') AND (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') THEN 'Email' "
	   "            WHEN (a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'') AND (a.aemail_eply IS NULL OR a.aemail_eply='') THEN '²�T' "
	   "            WHEN (a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'') AND (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') THEN 'Email' "
	   "            ELSE '' END, "
	   "       a.ileader,  "
	   "       (SELECT nname FROM officer WHERE iofficer = a.ileader) as nleader, b.fassured,  "
	   "       ' ' ,  "
	   "       'V' ,CASE WHEN c.dupdate IS NOT NULL AND c.fstatus=600 THEN c.dupdate ELSE c.dcreate END  "
           "  FROM %s:ply_relation a, %s:policy b,sysdb:ca_ecard_email_log c "
           " WHERE a.ipolicy = b.ipolicy    "
           "   AND a.dpolicy >= '01/11/2016'  "
           "   AND a.dout_trans is null     "
           "   AND a.feply in ('1')         "
           "   AND a.fcard_class in ('1')   "
           "   AND a.ipolicy=c.ipolicy      "
           "   AND (date(c.dcreate) = '%s' OR (date(c.dupdate) = '%s' and c.fstatus=600 ) )  "
           "   AND ((a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'')  OR  (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') )  "
           "   AND (a.irelative_ply IS NULL OR a.irelative_ply='' )	 "   
           "   AND a.dply_close is null     " 
           ,list[i].dbname,list[i].dbname,sDdate,sDdate,sDdate);
           
	   printf("stmt_2[%s]\n",stmt_2);
	   $prepare pre_ply2 from $stmt_2;
	   $execute pre_ply2;
	   
	   
     /*��j�B�w�鵲���H�e���*/   
     sprintf_s(stmt_3, sizeof stmt_3,"INSERT INTO car3013 "
           "SELECT a.ipolicy, a.icard, "
	   "       b.nassured , b.itag , (a.mdmg_prem+a.mlia_prem) as mpremium , "
	   "       a.dpolicy, a.iofficer, "
	   "       (SELECT nname FROM officer WHERE iofficer = a.iofficer) as nofficer, "
	   "       b.iroute, "
	   "       CASE WHEN (a.tmobile_eply IS NULL OR a.tmobile_eply='') AND (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') THEN 'Email' "
	   "            WHEN (a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'') AND (a.aemail_eply IS NULL OR a.aemail_eply='') THEN '²�T' "
	   "            WHEN (a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'') AND (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') THEN 'Email' "
	   "            ELSE '' END, "
	   "       a.ileader,  "
	   "       (SELECT nname FROM officer WHERE iofficer = a.ileader) as nleader, b.fassured,  "
	   "       ' ' ,  "
	   "       'V' ,CASE WHEN c.dupdate IS NOT NULL AND c.fstatus=600 THEN c.dupdate ELSE c.dcreate END  "
           "  FROM %s:ori_ply_relation a, %s:original_ply b,sysdb:ca_ecard_email_log c "
           " WHERE a.ipolicy = b.ipolicy    "
           "   AND a.dpolicy >= '01/11/2016'  "
           "   AND a.dout_trans is null     "
           "   AND a.feply in ('1')         "
           "   AND a.fcard_class in ('1')   "
           "   AND a.ipolicy=c.ipolicy      "
           "   AND (date(c.dcreate) = '%s' OR (date(c.dupdate) = '%s' and c.fstatus=600 ) )  "
           "   AND ((a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'')  OR  (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') )  "
           "   AND (a.irelative_ply IS NULL OR a.irelative_ply='' )	 "   
           "   AND a.dply_close is not null     " 
           ,list[i].dbname,list[i].dbname,sDdate,sDdate);
           
	   printf("stmt_3[%s]\n",stmt_3);
	   $prepare pre_ply3 from $stmt_3;
	   $execute pre_ply3;
	   
   
                                                        

         
     /*�j+�������j��B���鵲���H�e���(�d���+Email �� �ȯdEmail)*/      
     sprintf_s(stmt_4, sizeof stmt_4,"INSERT INTO car3013 "
           "SELECT a.ipolicy, a.icard,  "
	   "       b.nassured , b.itag , (a.mdmg_prem+a.mlia_prem) as mpremium ,  "
	   "       a.dpolicy, a.iofficer,  "
	   "       (SELECT nname FROM officer WHERE iofficer = a.iofficer) as nofficer,  "
	   "       b.iroute,  "
	   "       CASE WHEN d.feply='0' AND (a.tmobile_eply IS NULL OR a.tmobile_eply='') AND (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') THEN 'Email' "
	   "            WHEN d.feply='0' AND (a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'') AND (a.aemail_eply IS NULL OR a.aemail_eply='') THEN '²�T' "
	   "            WHEN d.feply='0' AND (a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'') AND (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') THEN 'Email' "
	   "            WHEN (a.tmobile_eply IS NULL OR a.tmobile_eply='') AND (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') THEN 'Email' "
	   "            WHEN (a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'') AND (a.aemail_eply IS NULL OR a.aemail_eply='') THEN '²�T' "
	   "            WHEN (a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'') AND (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') THEN 'Email+²�T' "
	   "            ELSE '' END, "
	   "       a.ileader,  "
	   "       (SELECT nname FROM officer WHERE iofficer = a.ileader) as nleader, b.fassured,  "
	   "       ' ' ,  "
	   "       'V' ,CASE WHEN c.dupdate IS NOT NULL AND c.fstatus=600 THEN c.dupdate ELSE c.dcreate END "
           "  FROM %s:ply_relation a, %s:policy b, sysdb:ca_ecard_email_log c,%s:ply_relation d  "
           " WHERE a.ipolicy = b.ipolicy  AND a.irelative_ply=d.ipolicy"  
           "   AND a.dpolicy >= '01/11/2016'  "
           "   AND a.dout_trans is null     "
           "   AND a.feply in ('1')         "
           "   AND a.fcard_class in ('1')   "
           "   AND a.ipolicy=c.ipolicy      "
           "   AND (date(c.dcreate) = '%s' OR (date(c.dupdate) = '%s' and c.fstatus=600 ) )  "
           "   AND (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'')  "
           "   AND a.dply_close is null     "
           ,list[i].dbname,list[i].dbname,list[i].dbname,sDdate,sDdate,sDdate);
           
	   printf("stmt_4[%s]\n",stmt_4);
	   $prepare pre_ply4 from $stmt_4;
	   $execute pre_ply4;

     /* �]���j+���H²�T�H�e�A�j��H�e�ɶ����|�g�Jca_ecard_email_log�A                            */
     /* �ҥH���|�bca_ecard_email_log�A���]���j����N�|�X�ֵo�H�A�ҥH�j��H�e�ɶ�=���N�H�e�ɶ��A*/
     /* �]���j��H�e�ɶ��n�q���N�h��)  */
     

     /*�j+�������j��B�w�鵲���H�e���(�d���+Email �� �ȯdEmail)*/ 
     sprintf_s(stmt_5, sizeof stmt_5,"INSERT INTO car3013 "
           "SELECT a.ipolicy, a.icard,  "
	   "       b.nassured , b.itag , (a.mdmg_prem+a.mlia_prem) as mpremium ,  "
	   "       a.dpolicy, a.iofficer,  "
	   "       (SELECT nname FROM officer WHERE iofficer = a.iofficer) as nofficer,  "
	   "       b.iroute,  "
	   "       CASE WHEN d.feply='0' AND (a.tmobile_eply IS NULL OR a.tmobile_eply='') AND (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') THEN 'Email' "
	   "            WHEN d.feply='0' AND (a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'') AND (a.aemail_eply IS NULL OR a.aemail_eply='') THEN '²�T' "
	   "            WHEN d.feply='0' AND (a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'') AND (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') THEN 'Email' "
	   "            WHEN (a.tmobile_eply IS NULL OR a.tmobile_eply='') AND (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') THEN 'Email' "
	   "            WHEN (a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'') AND (a.aemail_eply IS NULL OR a.aemail_eply='') THEN '²�T' "
	   "            WHEN (a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'') AND (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') THEN 'Email+²�T' "
	   "            ELSE '' END, "
	   "       a.ileader,  "
	   "       (SELECT nname FROM officer WHERE iofficer = a.ileader) as nleader, b.fassured,  "
	   "       ' ' ,  "
	   "       'V' ,CASE WHEN c.dupdate IS NOT NULL AND c.fstatus=600 THEN c.dupdate ELSE c.dcreate END "
           "  FROM %s:ori_ply_relation a, %s:original_ply b, sysdb:ca_ecard_email_log c,%s:ori_ply_relation d  "
           " WHERE a.ipolicy = b.ipolicy  AND a.irelative_ply=d.ipolicy"  
           "   AND a.dpolicy >= '01/11/2016'  "
           "   AND a.dout_trans is null     "
           "   AND a.feply in ('1')         "
           "   AND a.fcard_class in ('1')   "
           "   AND a.ipolicy=c.ipolicy      "
           "   AND (date(c.dcreate) = '%s' OR (date(c.dupdate) = '%s' and c.fstatus=600 ) )  "
           "   AND (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') "
           "   AND a.dply_close is not null     " 	
           ,list[i].dbname,list[i].dbname,list[i].dbname,sDdate,sDdate);
           
	   printf("stmt_5[%s]\n",stmt_5);
	   $prepare pre_ply5 from $stmt_5;
	   $execute pre_ply5;
	   
	   
	   
 
           
     /*�j+�������j��B���鵲���H�e���(�ȯd���)(�B���N�I�O�q�l)*/                
     sprintf_s(stmt_6, sizeof stmt_6,"INSERT INTO car3013 "
           "SELECT a.ipolicy, a.icard,  "
           "       b.nassured , b.itag , (a.mdmg_prem+a.mlia_prem) as mpremium ,  "
           "       a.dpolicy, a.iofficer,  "
           "       (SELECT nname FROM officer WHERE iofficer = a.iofficer) as nofficer,  "
           "       b.iroute,  "
	   "       '²�T', "
           "       a.ileader,  "
           "       (SELECT nname FROM officer WHERE iofficer = a.ileader) as nleader, b.fassured,  "
           "       ' ' ,  "
           "       'V' ,CAST (c.demail AS DATETIME year TO second) "
           "  FROM %s:ply_relation a, %s:policy b, cm_e_policy c,%s:ply_relation d "
           " WHERE a.ipolicy = b.ipolicy AND a.irelative_ply=d.ipolicy"
           "   AND a.dpolicy >= '01/11/2016'  "
           "   AND a.dout_trans is null     "
           "   AND a.feply in ('1')         "
           "   AND a.fcard_class in ('1')   "
           "   AND c.demail between '%s' and '%s' "
           "   AND (SELECT count(*) FROM sysdb:ca_ecard_email_log WHERE ipolicy=a.ipolicy) =0   "
           "   AND ((d.tmobile_eply IS NOT NULL AND d.tmobile_eply<>'') AND (d.aemail_eply IS NULL OR d.aemail_eply='') )  "	
           "   AND d.ipolicy=c.ipolicy AND c.iendorse='' "
           "   AND a.dply_close is null     "
           ,list[i].dbname,list[i].dbname,list[i].dbname,sDdate1,sDdate2,sDdate);
           
	   printf("stmt_6[%s]\n",stmt_6);
	   $prepare pre_ply6 from $stmt_6;
	   $execute pre_ply6;     
	   
	   
     /*�j+�������j��B�w�鵲���H�e���(�ȯd���)(�B���N�I�O�q�l)*/    
     sprintf_s(stmt_7, sizeof stmt_7,"INSERT INTO car3013 "
           "SELECT c.ipolicy,c.icard,"
           "       d.nassured , d.itag , (c.mdmg_prem+c.mlia_prem) as mpremium ,"
           "       c.dpolicy, c.iofficer,  "
           "       (SELECT nname FROM officer WHERE iofficer = c.iofficer) as nofficer, " 
           "       d.iroute,"
           "       '²�T', "
           "       c.ileader, " 
           "       (SELECT nname FROM officer WHERE iofficer = c.ileader) as nleader, d.fassured, " 
           "       ' ' ,  "
           "       'V' ,CAST (a.demail AS DATETIME year TO second) "
           "  FROM cm_e_policy a,%s:ori_ply_relation b,%s:ori_ply_relation c,%s:original_ply d"
           " WHERE a.demail  between '%s' AND '%s' AND a.iendorse='' "
           "   AND a.iins_cat='C' AND a.fstatus>500 AND a.ipolicy=b.ipolicy AND b.irelative_ply=c.ipolicy"
           "   AND (b.tmobile_eply IS NOT NULL AND b.tmobile_eply<>'')  AND  (b.aemail_eply IS NULL OR b.aemail_eply='')  "
           "   AND c.ipolicy=d.ipolicy AND c.feply='1' "
           ,list[i].dbname,list[i].dbname,list[i].dbname,sDdate1,sDdate2);
        
	   printf("stmt_7[%s]\n",stmt_7);
	   $prepare pre_ply7 from $stmt_7;
	   $execute pre_ply7;  


     /*�j+�������j��B���鵲���H�e���(�ȯd���)(�B���N�I�O�ȥ�)*/
     sprintf_s(stmt_8, sizeof stmt_8,"INSERT INTO car3013 "
             "SELECT a.ipolicy, a.icard, " 
             "       b.nassured , b.itag , (a.mdmg_prem+a.mlia_prem) as mpremium ,  "
             "       a.dpolicy, a.iofficer,  "
             "       (SELECT nname FROM officer WHERE iofficer = a.iofficer) as nofficer,  "
             "       b.iroute, " 
             "       '²�T' ,"
             "       a.ileader, " 
             "       (SELECT nname FROM officer WHERE iofficer = a.ileader) as nleader, b.fassured, " 
             "       ' ' ,  "
             "       'V' ,CAST (c.dcreate AS DATETIME year TO second) "
             "  FROM %s:ply_relation a, %s:policy b, ca_ecard_email_log c,%s:ply_relation d "
             " WHERE a.ipolicy = b.ipolicy AND a.irelative_ply=d.ipolicy"
             "   AND a.dpolicy >= '01/11/2016'  "
             "   AND a.dout_trans is null    " 
             "   AND a.feply in ('1') AND d.feply='0'   "     
             "   AND a.fcard_class in ('1')   "
             "   AND c.dcreate between '%s' AND '%s'    "  
             "   AND ((a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'')  AND   (a.aemail_eply IS NULL OR a.aemail_eply='') ) " 
             "   AND a.ipolicy=c.ipolicy "
             "   AND a.dply_close is NULL"
           ,list[i].dbname,list[i].dbname,list[i].dbname,sDdate1,sDdate2,sDdate);
        
	   printf("stmt_8[%s]\n",stmt_8);
	   $prepare pre_ply8 from $stmt_8;
	   $execute pre_ply8; 

     /*�j+�������j��B�w�鵲���H�e���(�ȯd���)(�B���N�I�O�ȥ�)*/
     sprintf_s(stmt_9, sizeof stmt_9,"INSERT INTO car3013 "
             "SELECT a.ipolicy, a.icard,  "
             "       b.nassured , b.itag , (a.mdmg_prem+a.mlia_prem) as mpremium ,  "
             "       a.dpolicy, a.iofficer, " 
             "       (SELECT nname FROM officer WHERE iofficer = a.iofficer) as nofficer, " 
             "       b.iroute,  "
             "       '²�T', "
             "       a.ileader,  "
             "       (SELECT nname FROM officer WHERE iofficer = a.ileader) as nleader, b.fassured, " 
             "       ' ' ,  "
             "       'V' ,CAST (c.dcreate AS DATETIME year TO second) "
             "  FROM %s:ori_ply_relation a, %s:original_ply b, ca_ecard_email_log c,%s:ori_ply_relation d "
             " WHERE a.ipolicy = b.ipolicy AND a.irelative_ply=d.ipolicy"
             "   AND a.dpolicy >= '01/11/2016'  "
             "   AND a.dout_trans is null    " 
             "   AND a.feply in ('1') AND d.feply='0'  "      
             "   AND a.fcard_class in ('1')   "
             "   AND c.dcreate between '%s' AND '%s'  "    
             "   AND ((a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'')  AND   (a.aemail_eply IS NULL OR a.aemail_eply='') ) " 
             "   AND a.ipolicy=c.ipolicy "
             "   AND a.dply_close is NOT NULL"
           ,list[i].dbname,list[i].dbname,list[i].dbname,sDdate1,sDdate2);
        
	   printf("stmt_9[%s]\n",stmt_9);
	   $prepare pre_ply9 from $stmt_9;
	   $execute pre_ply9; 


     
      

     /*����B���鵲���H�e��� �� �j+���������N�B���鵲���H�e���*/      
     sprintf_s(stmt_10, sizeof stmt_10,"INSERT INTO car3013 "
           "SELECT a.ipolicy, ' ' ,  "
	   "       b.nassured , b.itag , (a.mdmg_prem+a.mlia_prem) as mpremium ,  "
	   "       a.dpolicy, a.iofficer,  "
	   "       (SELECT nname FROM officer WHERE iofficer = a.iofficer) as nofficer,  "
	   "       b.iroute,  "
	   "       CASE WHEN fstatus=620 THEN 'FTP' "
	   "            WHEN (a.tmobile_eply IS NULL OR a.tmobile_eply='') AND (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') THEN 'Email' "
	   "            WHEN (a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'') AND (a.aemail_eply IS NULL OR a.aemail_eply='') THEN '²�T' "
	   "            WHEN (a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'') AND (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') THEN 'Email+²�T' "
	   "            ELSE '' END, "
	   "       a.ileader,  "
	   "       (SELECT nname FROM officer WHERE iofficer = a.ileader) as nleader, b.fassured,  "
	   "       ' ' ,  "
	   "       'V' ,CAST (c.demail AS DATETIME year TO second) "
	   "  FROM %s:ply_relation a, %s:policy b,cm_e_policy c "
	   " WHERE a.ipolicy = b.ipolicy    "
	   "   AND a.dpolicy >= '01/11/2016'"
	   "   AND a.dout_trans is null     "
	   "   AND a.feply in ('1')         "
	   "   AND a.fcard_class in ('2')   "
	   "   AND a.ipolicy=c.ipolicy "
	   "   AND c.demail between '%s' and '%s' AND c.iendorse='' "
	   "   AND ((a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'')  OR  (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') ) " 
	   "   AND a.dply_close is null     "
           ,list[i].dbname,list[i].dbname,sDdate1,sDdate2);	
             
	   printf("stmt_10[%s]\n",stmt_10);
	   $prepare pre_ply10 from $stmt_10;
	   $execute pre_ply10;   
	   
	          
     /*����B�w�鵲���H�e��� �� �j+���������N�B�w�鵲���H�e���*/   
     sprintf_s(stmt_11, sizeof stmt_11,"INSERT INTO car3013 "
           "SELECT a.ipolicy, ' ' ,  "
	   "       b.nassured , b.itag , (a.mdmg_prem+a.mlia_prem) as mpremium ,  "
	   "       a.dpolicy, a.iofficer,  "
	   "       (SELECT nname FROM officer WHERE iofficer = a.iofficer) as nofficer,  "
	   "       b.iroute,  "
	   "       CASE WHEN fstatus=620 THEN 'FTP' "
	   "            WHEN (a.tmobile_eply IS NULL OR a.tmobile_eply='') AND (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') THEN 'Email' "
	   "            WHEN (a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'') AND (a.aemail_eply IS NULL OR a.aemail_eply='') THEN '²�T' "
	   "            WHEN (a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'') AND (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') THEN 'Email+²�T' "
	   "            ELSE '' END, "
	   "       a.ileader,  "
	   "       (SELECT nname FROM officer WHERE iofficer = a.ileader) as nleader, b.fassured,  "
	   "       ' ' ,  "
	   "       'V' ,CAST (c.demail AS DATETIME year TO second) "
	   "  FROM %s:ori_ply_relation a, %s:original_ply b,cm_e_policy c "
	   " WHERE a.ipolicy = b.ipolicy    "
	   "   AND a.dpolicy >= '01/11/2016'  "
	   "   AND a.dout_trans is null     "
	   "   AND a.feply in ('1')         "
	   "   AND a.fcard_class in ('2')   "
	   "   AND a.ipolicy=c.ipolicy "
	   "   AND c.demail between '%s' and '%s' AND c.iendorse='' "
	   "   AND ((a.tmobile_eply IS NOT NULL AND a.tmobile_eply<>'')  OR  (a.aemail_eply IS NOT NULL AND a.aemail_eply<>'') ) " 
	   "   AND a.dply_close is not null     "
           ,list[i].dbname,list[i].dbname,sDdate1,sDdate2);	
             
	   printf("stmt_11[%s]\n",stmt_11);
	   $prepare pre_ply11 from $stmt_11;
	   $execute pre_ply11; 	   

   }  
	
   return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car3013_send_email_ileader()
{
	int	rc;

	$whenever sqlerror goto errexit;
	 
	  strcpy(stmt,"SELECT distinct ipolicy, icard1," 
	              "       CASE WHEN fassured in ('1','3','5')"
	              "       THEN nassured[1,2]||'��'||nassured[5,6] ELSE nassured END ," 
	              "       itag, mpremium, dpolicy, chr(127)||iofficer,  "
		      "	      nofficer, iroute,  "
		      "       chr(127)||ileader, nleader,sout_trans,screate_eply,nmail_type,dsend "
                      "  FROM car3013     "
		      " WHERE ileader = ? "
                      " ORDER BY itag ");
    printf("stmt[%s]\n",stmt);
    $PREPARE pre_data from $stmt;
    $DECLARE cur_data CURSOR FOR pre_data;
	
    $DECLARE cur_temp CURSOR FOR
      SELECT DISTINCT ileader
	INTO $ileader
	FROM car3013
       ORDER BY ileader;
    $OPEN  cur_temp;
    $FETCH cur_temp;
    strcpy(pre_ileader,ileader);
    
    mail_count=0;
    for(;;) 
    {
			if (SQLCODE==SQLNOTFOUND) break;

			if (strcmp(ileader,pre_ileader)!=0) 
			{
	    	            rc = car3013_write_email_ileader();
	    	            if (rc != M_CM_OK) {
					printf("error on car3013_write_email_ileader\n");
					return rc;
	    	            }
	    	            mail_count=0;
			}
			strcpy(pre_ileader,ileader);
	
			mail_count++;
			printf("---ileader:[%s]---\n",ileader);
			memset(fname,0x00,sizeof(fname));
			memset(filename,0x00,sizeof(filename));
			sprintf_s(fname, sizeof fname,"%s_���I�O��e�~�s�o�ιq�l�H�o����_%s",sdate,trim(ileader));
			sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
			sprintf_s(nattachment, sizeof nattachment,"%s.csv",fname);
			printf("----filename[%s]----\n",filename);
			fp=fopen(filename,"w");
		
			fprintf(fp,ftitle);
			
			$OPEN cur_data USING $ileader;
	
			for(;;)
		        {
		            $FETCH cur_data INTO $ipolicy,$icard1,$nassured,$itag,$mpremium,$dpolicy,$iofficer,
                                                 $nofficer,$iroute,$ileader,$nleader,$sout_trans,$screate_eply,$nmail_type,$dsend;
	                           
		            if (SQLCODE==SQLNOTFOUND) break;
		   	
		            printf("---ipolicy[%s]---\n",ipolicy);
		            fprintf(fp,"%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s,%s,%s,%s\n",
		                       ipolicy, icard1, nassured, itag, mpremium, dpolicy, iofficer,
	                               nofficer, iroute, ileader, nleader, sout_trans, screate_eply, nmail_type, dsend);
			}
			$CLOSE cur_data;
			fclose(fp);
			$FETCH cur_temp;
    }
    $FREE  cur_data;
    $CLOSE cur_temp;
    $FREE  cur_temp;
	    
    if (mail_count!=0) {
        rc = car3013_write_email_ileader();
        if (rc!=M_CM_OK) {
		printf("error on car3013_write_email_ileader\n");
		return rc;
	}
    }
           
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*---------------------------------------------------------------------------*/
long car3013_write_email_ileader()
{
    $whenever sqlerror goto errexit;
    
    $SELECT nname
       INTO $sNleader
       FROM officer
      WHERE iofficer = $pre_ileader;
    if (SQLCODE==SQLNOTFOUND) strcpy(sNleader,"�P��");
    
    strcpy(sNleader,trim(sNleader));
    /* email��� */
    sprintf_s(mmsg, sizeof mmsg,
	  "�˷R�� %s,�z�n</P>\n\n"
	  "�q���z�A����O�z�Ҹg�쨮�I�~�Ȥ��ݩ�e�~�s�o�αĹq�l�H�o���ӡA</P>\n"
	  "�p�L�k���`�}�ҩΧe�{���e�ýX�A�аѦҥH�U�}���ɮפ������C</P>\n"
	  "�e�~�s�o���Ӥw�ѩe�~�t�Ӫ����L�s�j���ҡB�O��Φ��ڨñH�o���Ȥ�A</P>\n"
	  "�q�l�H�o���Ӥw�ѭn�O�Ѷ�㤧email�H�o�l��Τ�����X²�T���Ȥ�A</P>\n"
	  "�p������e�~���Ӱ��D�Ь��ӤH�O�I���~�Ȧ�F��C</P>\n"
	  "�p���q�l�j���ҡB�q�l�O��H�e���D,�Х������֫O�T�{�n�O�������C</P>\n\n"
	  "����!</P>\n"
	  "<br><br>\n"
          "��ʸ˸m�}���ɮ׻����G�̭ӧO�@�~�t�Φw�ˡyExcel�zAPP<br>\n"
          "1.	android�@�~�t�ΡG�}�ҡyplay�ө��z��<br>\n"
          "2.	iOS�@�~�t�ΡG�}�ҡyApp Store�z��<br>\n"
          "�j�M�yexcel�z�����Microsoft Corporation�}�o���yMicrosoft Excel�z�w�ˡ�<br>\n"
          "�w�˧������i�J�yExcel�zAPP�i��Ĥ@���ϥΰ򥻽T�{��<br>\n"
          "�I��Email��CSV���ɡA�}�ҵ{�����ΡyExcel�zAPP���i���`�s���ϥΡC<br>\n"

	  ,sNleader);

    strcpy(mbuf,rtrim(mmsg));
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mbuf;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mbuf) + 1;

    strcpy(email," ");
    $select email,chinese_name
       into $email,$chinese_name
       from personal:asempl
      where empl_no = $pre_ileader;

    strcpy(email,trim(email));
    if (strlen(email) != 0){ 
    	
      strcpy(email,trim(email));
      strcat(email,"@tmnewa.com.tw");
      printf("-----email:[%s]-----\n",email);
		
      $INSERT INTO batchemail
		  (project_id, mail_date, receiver_email,
		   receiver_name, cc, content, key, mail_count,nsubject,nattachment)
       VALUES
		  ("CAR_OUT", today+1, $email, $chinese_name,
			 " ", $ctxt, $fname, $mail_count, $nsubject, $nattachment);
    }
    
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
/*long car3013_send_card_count()
{
    $whenever sqlerror goto errexit;
    
     �T���j���ҳѾl�i�αi�� 
    sprintf_s(stmt1, sizeof stmt1,"SELECT count(icard)          "
                  "  FROM compulsory_card       "
                  " WHERE icard MATCHES '%sC7*' "
                  "   AND ioffice = '7'         "
                  "   AND icardyear = '%s'      "
                  "   AND icar_type = '03'      "     
                  "   AND fstatus = '0'         ",year2,year2);
    $PREPARE C_compulsory_cur FROM $stmt1;             
    $EXECUTE C_compulsory_cur INTO $C_count;
    
     �����j���ҳѾl�i�αi�� 
    sprintf_s(stmt2, sizeof stmt2,"SELECT count(icard)          "
                  "  FROM compulsory_card       "
                  " WHERE icard MATCHES '%sM7*' "
                  "   AND ioffice = '7'         "
                  "   AND icardyear = '%s'      "
                  "   AND icar_type = '01'      "     
                  "   AND fstatus = '0'         ",year2,year2);
    $PREPARE M_compulsory_cur FROM $stmt2;             
    $EXECUTE M_compulsory_cur INTO $M_count;
    
     �D�� 
    strcpy(nsubject,"�e�~��j���ҳѾl�i�αi�Ƴq��");

    $DECLARE temp_cur CURSOR FOR
      SELECT iofficer,nname
	FROM officer
	WHERE iofficer in ('703552','881360','990389','070319');
    $OPEN  temp_cur;
    
    for(;;)
    {
    	  $FETCH temp_cur INTO $sIemp,$sNname;
        if (SQLCODE == SQLNOTFOUND) break;
      
        strcpy(sNname,trim(sNname));        
         email��� 
        sprintf_s(mmsg, sizeof mmsg,
	      "�˷R�� %s,�z�n</P>\n\n"
	      "�q���z�G</P>\n"
	      "%s�~�T���j���ҳѾl�i�αi�ơG%d </P>\n"
	      "%s�~�����j���ҳѾl�i�αi�ơG%d </P>\n"
	      "����!</P>\n",sNname,syy,C_count,syy,M_count);

        strcpy(mbuf,rtrim(mmsg));
        ctxt.loc_loctype = LOCMEMORY;
        ctxt.loc_buffer = mbuf;
        ctxt.loc_bufsize = 9000;
        ctxt.loc_size =  strlen(mbuf) + 1;

        strcpy(email," ");
        $SELECT email,chinese_name
           INTO $email,$chinese_name
           FROM personal:asempl
          WHERE empl_no = $sIemp;

        strcpy(email,trim(email));
        if (strlen(email) != 0){ 
    	
           strcpy(email,trim(email));
           strcat(email,"@tmnewa.com.tw");
           printf("-----email:[%s]-----\n",email);
		
           $INSERT INTO batchemail
		       (project_id, mail_date, receiver_email,
		        receiver_name, cc, content, key, mail_count,nsubject)
            VALUES
		       ("CAR_OUT", today+1, $email, $chinese_name,
			      " ", $ctxt, " ", 1, $nsubject);
			  }
    }
    $CLOSE temp_cur;
    $FREE  temp_cur;
    
    return M_CM_OK;
        
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}*/
/*----------------------------------------------------------------------------*/
long car3013_print()
{
    int     rc;
    char    sfilename[100],stitle[1024],stmt[1024];

    $WHENEVER SQLERROR GOTO errexit;

    strcpy(sfilename,"���I�O��e�~�s�o�ιq�l�H�o����");
    strcpy(stitle,"�{���N��:CAR3013\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t\t\t\t\t\t\t\t\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");
    strcat(sfilename,"[CAR3013]");

    strcat(stitle,"\t�O�渹�X\t�j���Ҹ�\t�Q�O�I�H�m�W\t���P���X\t�O�O\t");
    strcat(stitle,"�X����\t�g��N��\t�g��N������\t�q���N��\t");
    strcat(stitle,"�޲z�H�N��\t�޲z�H����\t�e�~\t�q�l\t�l�H�覡\t�H�e���\t");

    strcpy(stmt,"SELECT distinct ipolicy, icard1," 
	        "       CASE WHEN fassured in ('1','3','5')"
	        "       THEN nassured[1,2]||'��'||nassured[5,6] ELSE nassured END ," 
	        "       itag, mpremium, dpolicy, chr(127)||iofficer,  "
		"	nofficer, iroute,  "
		"       chr(127)||ileader, nleader,sout_trans,screate_eply,nmail_type,to_char(dsend,'%Y/%m/%d %H:%M:%S') "
                "  FROM car3013     "
                " ORDER BY itag ");

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {
        sprintf_s(msgbuf, sizeof msgbuf," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return rc;
    }

    return M_CM_OK;
    
errexit:
    sqlfatal();
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}
/*-------------------------------THE END--------------------------------------*/
