/*--------------------------------------------------*/
/*   PROGRAM : ca536m01s.ec                         */
/*                                                  */
/*   DATE    : 2003/01/22                           */
/*--------------------------------------------------*/
     
#include <stdio.h>
#include <stdlib.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "aoimsgs.h"
$include sqlca;
#include <decimal.h>
#include "safeclib.h"


/*--------------------------------------------------*/
long car536(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
        long rtncode;
    long car536_insert();
	long car536_check_ibatch();
    static char *get_car_full_db();  /*   �ǤJ�O�渹��X���O�檺�k�ݸ�Ʈw */
    char option;

    cm_buf_init(command);
    cm_buf_get("%c",&option);

    switch(option)
    {

        case 'A':
			rtncode=car536_insert(reply);
            break;
        case 'C':
            rtncode=car536_check_ibatch(reply);
            break;
        default :
            if(exitsub(reply,M_CM_WRONG_OPTION) == True)
                return M_CM_WRONG_OPTION;
        return apiRC;
    }
    return(rtncode);
}

/*--------------------------------------------------*/

long car536_insert(reply)
serverReply reply;
{
    $char    DBName[5],sFullName[20];
    int      tmp_len;
    long     MsgCode;
    DBinfo   *list;
    int      k, j, is_add_fail=0, api_f;
    $char    stmt[5120];
    int      rows, i;

	$char   ibatch[11];
	$int    qserial;
	$char   dentry[12];

	$char ipolicy[21];
	$char iclaim[21];
	$char fstl[2];
	$int  iclose_type=0;
	$char fclose[2], iins_type[INSURANCE_TYPE], iins_item[INSURANCE_TYPE];
	$char ivictim[CUSTOMER_ID];
	$char fcard_class[2];
	$char Full_DBName[50];
	$char last_dclose[YYYYMMDD];
	$char option[2];
	$int sign_chk;

      int LiBufLen;

    cm_buf_get("%s",DBName);

    if (db_select(DBName) == False)
        {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
                return M_CM_DB_NOTOPEN;
        else
                return apiRC;
    }

    $WHENEVER SQLERROR GO TO errexit;
    $BEGIN WORK;
    
    strcpy(dentry, cm_cdate_str_100(cm_today()));
    strcpy(dentry, cm_to_infdate(dentry));
    printf(" dentry[%s]\n",dentry);

	cm_buf_get("%s",ibatch);

	/*�]�|�D�����h����O"C"*/
	$UPDATE ao_stl_close
		SET (fstl_sta) = ('C')
		WHERE ibatch = $ibatch;
 
    /*  ADD George 870818 �z�߼f��UPDATE�ߥI��HSTATUS */
	$UPDATE ao_stl_obj_close
		SET (fstl_obj_sta)=('C')
		WHERE EXISTS(SELECT * FROM ao_stl_close 
					WHERE ibatch = $ibatch
					AND ao_stl_close.iclose = ao_stl_obj_close.iclose
					AND ao_stl_close.iclose_type = ao_stl_obj_close.iclose_type
					AND ao_stl_close.fstl = ao_stl_obj_close.fstl);
 
    /*  ADD George 870818 �z�߰h��UPDATE���I */
	/* ���I�h�� */
/*	if (fstl_sta[0]=='C')
	{*/
	$UPDATE ca_local_stl
		SET (fchoose,dclose,qserial) = ('2',"",0)
		WHERE EXISTS(SELECT * FROM ao_stl_close 
					WHERE ibatch = $ibatch
					AND ao_stl_close.iclose = ca_local_stl.iclaim
					AND ao_stl_close.iclose_type = ca_local_stl.iclose_type
					AND ao_stl_close.fstl = ca_local_stl.fstl
					AND ao_stl_close.dgroup IS NULL)
		AND (dgroup = '' or dgroup is null)
		AND dclose IS NOT NULL;

	if (sqlca.sqlerrd[2] == 0)
	{
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		if(exitsub(reply,M_AO_NO_UPDATE_STL) == True)
			return M_AO_NO_UPDATE_STL;
		else
			return apiRC;
	}

	/*�h��UPDATE EasyFlow�һݪ���ca_stl_close_main.fstatus���h�󪬺A*/
	$UPDATE ca_stl_close_main
		SET fstatus = 'C'
		WHERE ibatch_no = $ibatch
		  AND ibranch = $DBName;

	/*  �h���]�i��N�S�F@@*/
	sprintf_s(stmt,5120,"SELECT trim(ipolicy1) || trim(ipolicy2),iclose,fstl,iclose_type FROM ao_stl_close WHERE ibatch = '%s' ",ibatch);
	$PREPARE reject_case FROM $stmt;
	$DECLARE rj_cur CURSOR FOR reject_case;
	$OPEN rj_cur;

	while(1)
	{
		$FETCH rj_cur INTO  $ipolicy,$iclaim,$fstl,$iclose_type;
		if(SQLCODE==SQLNOTFOUND) break;
		strcpy(sFullName,get_car_full_db(ipolicy));
		sprintf_s(stmt,5120, "SELECT %s FROM %s:%s WHERE ipolicy=?",
					 "fcard_class",sFullName,"ply_relation");
		$PREPARE sq_ply_fcard_class FROM $stmt;
		$DECLARE ply_cur_fcard_class CURSOR FOR sq_ply_fcard_class;
		$OPEN ply_cur_fcard_class USING $ipolicy;
		$FETCH ply_cur_fcard_class INTO $fcard_class;
		if (SQLCODE == SQLNOTFOUND) return exitsub(reply,M_CA_NREL_PLY) ? M_CA_NREL_PLY : apiRC;
		$CLOSE ply_cur_fcard_class;
		$FREE ply_cur_fcard_class;
		
		printf("debug db[%s]\n",get_car_full_db(ipolicy));
		/*settlement ���h���,�M�鵲��*/
		sprintf_s(stmt,5120,
		"UPDATE %s:settlement \
			SET d_reason = '%s', dclose = null \
			WHERE iclaim = '%s' \
			 AND fstl ='%s' \
			 AND iclose_type = %d;",
		sFullName, cm_edate_str(cm_today()),iclaim,fstl,iclose_type);
		printf("update settlement stmt==>[%s]\n",stmt);
		$PREPARE U1 FROM $stmt;
		$EXECUTE U1;
printf("flag1\n");
		if (fcard_class[0]=='2')
		{
printf("flag2\n");
			sprintf_s(stmt,5120, "SELECT iins_type \
							FROM %s:stl_ins_type \
							WHERE iclaim='%s' AND fstl='%s' AND iclose_type=%d \
							AND dgroup is null", 
			sFullName, iclaim, fstl, iclose_type);
			$PREPARE sq_stlins FROM $stmt;
			$DECLARE stlins_cur_536 CURSOR FOR sq_stlins;
			$OPEN stlins_cur_536;
printf("flag3\n");
			while(1)
			{
printf("flag4\n");
				$FETCH stlins_cur_536 INTO $iins_type;
				if (SQLCODE == SQLNOTFOUND) break;
				if (iclose_type > 1)
				{
					sprintf_s(stmt,5120, "SELECT dclose FROM %s:stl_ins_type \
									WHERE iclaim='%s' AND fstl='%s' \
									AND iclose_type=%d AND iins_type = '%s'",
								sFullName, iclaim, fstl, iclose_type-1,iins_type);
					$PREPARE last_stlins FROM $stmt;
					$DECLARE last_stlins_cur_reject CURSOR FOR last_stlins;
					$OPEN last_stlins_cur_reject;
					$FETCH last_stlins_cur_reject INTO $last_dclose;
					if (SQLCODE == SQLNOTFOUND)
						strcpy(last_dclose," ");
				}
				else
				 {
					strcpy(last_dclose," ");
				 }
printf("flag5\n");
				/*�٭�app_ins_type�鵲��*/
				strcpy(fclose,"0"); fclose[1]='\0';
				sprintf_s(stmt,5120, "UPDATE %s:app_ins_type \
								SET fclose=?, dclose_ctype = ? \
								WHERE iclaim=? AND iins_type=?", sFullName);
				$PREPARE upd_app_dclose FROM $stmt;
				$EXECUTE upd_app_dclose 
				USING $fclose, $last_dclose, $iclaim, $iins_type;
			}
			$CLOSE stlins_cur_536;
			$FREE stlins_cur_536;
			/*�Mstl_ins_type�鵲��*/
printf("flag6\n");
			sprintf_s(stmt,5120, "UPDATE %s:stl_ins_type \
							SET dclose = null \
							WHERE iclaim=? AND fstl=? AND iclose_type=? AND dgroup is null", sFullName);
			$PREPARE upd_stlins FROM $stmt;
			$EXECUTE upd_stlins USING $iclaim, $fstl, $iclose_type;
printf("flag7\n");
		}
		else
		{
printf("flag8\n");
			sprintf_s(stmt,5120, "SELECT iins_item, ivictim \
							FROM %s:ca_stl_victim \
							WHERE iclaim='%s' AND fstl='%s' AND iclose_type=%d \
							AND dgroup is null", 
			sFullName, iclaim, fstl, iclose_type);
			$PREPARE sq_stlvic FROM $stmt;
			$DECLARE stlvic_cur_536 CURSOR FOR sq_stlvic;
			$OPEN stlvic_cur_536;
printf("flag9\n");
			while(1)
			{
printf("flag10\n");
				$FETCH stlvic_cur_536 INTO $iins_type, $ivictim;
				if (SQLCODE == SQLNOTFOUND) break;

				if (iclose_type > 1)
				{
					sprintf_s(stmt,5120, "SELECT dclose FROM %s:ca_stl_victim \
									WHERE iclaim='%s' AND fstl='%s' \
									AND iclose_type=%d AND iins_item = '%s'",
								sFullName, iclaim, fstl, iclose_type-1,iins_item);
					$PREPARE last_stlvic FROM $stmt;
					$DECLARE last_stlvic_cur_reject CURSOR FOR last_stlvic;
					$OPEN last_stlvic_cur_reject;
					$FETCH last_stlvic_cur_reject INTO $last_dclose;
					if (SQLCODE == SQLNOTFOUND)
					strcpy(last_dclose," ");
				}
				else
				{
					strcpy(last_dclose," ");
				}
printf("flag11\n");
				/*�٭�ca_app_victim�鵲��*/
				strcpy(fclose,"0"); fclose[1]='\0';
				sprintf_s(stmt,5120, "UPDATE %s:ca_app_victim \
								SET fclose=?, dclose_ctype = ? \
								WHERE iclaim=? AND iins_item=? AND ivictim=?", sFullName);
				$PREPARE upd_vic_dclose FROM $stmt;
				$EXECUTE upd_vic_dclose
				USING $fclose, $last_dclose, $iclaim, $iins_item, $ivictim;
printf("flag12\n");
			}
			$CLOSE stlvic_cur_536;
			$FREE  stlvic_cur_536;
			/*�Mca_stl_victim�鵲��*/
printf("flag13\n");
			sprintf_s(stmt,5120, "UPDATE %s:ca_stl_victim \
							SET dclose = null \
							WHERE iclaim=? AND fstl=? AND iclose_type=? AND dgroup is null", sFullName);
			$PREPARE upd_stlvic FROM $stmt;
			$EXECUTE upd_stlvic USING $iclaim, $fstl, $iclose_type;
printf("flag14\n");
		}
printf("flag15\n");

		/*�M�� ca_clm_smsg �鵲��  add by sylvia 109.11.05 (1090926004_SC1) */
		sprintf_s(stmt,5120, "update %s:ca_clm_smsg \
	                    set dclose = '', \
	                        iupdate = 'car536', \
	                        dupdate = current \
                    where iclaim = '%s'  \
                      and iclose_type = %d \
                      and dclose is not null ", sFullName, iclaim, iclose_type) ;
		$PREPARE upd_ca_clm_smsg FROM $stmt;
		$EXECUTE upd_ca_clm_smsg;
	  printf("upd_ca_clm_smsg:[%d][%s] \n",SQLCODE,stmt);


		/*�٭�ca_clm_process�鵲��*/
		/* �^�_�e�߮ת��A */
		sprintf_s(stmt,5120, "UPDATE ca_clm_process SET dclose = ? , fclaim_status = fclaim_status_pre WHERE iclaim = ?");
		$PREPARE upd_process_dclose FROM $stmt;
		$EXECUTE upd_process_dclose USING $last_dclose, $iclaim;		
printf("flag16\n");

		
	}

printf("flag17\n");

	printf(" ************************** \n");
	cm_buf_init(ReplyBuf);
	cm_buf_put("%l",M_CM_OK);
	LiBufLen = cm_buf_len(ReplyBuf);

	if(SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete) == False)
	{
		$WHENEVER SQLERROR CONTINUE;
		$ROLLBACK WORK;
		return apiRC;
	}

	$WHENEVER SQLERROR GOTO errexit;
	$COMMIT WORK;
	return api_OKComplete;

	errexit:
		printf("car536_insert SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
		$WHENEVER SQLERROR CONTINUE;
		MsgCode = SQLCODE;
		$ROLLBACK WORK;
		if (SQLCODE != 0) MsgCode = SQLCODE;
		return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}

/****************************************************************************/
long car536_check_ibatch(reply)
serverReply reply;
{
	/*******************************************/
	/*    �ˮ֬O�_���Ӥ鵲�帹                 */
	/*  checking ibatch from AO system         */
	/*      Programing by Max                  */
	/*      Date: 2008.5                       */
	/*******************************************/
    $char   DBName[5];
	$char   ibatch[11];
	$char stmt[1024];
	$int chk_ibatch=0;

	int LiBufLen;

	cm_buf_get("%s %s",DBName, ibatch);

	if(db_select(DBName) == False)
		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

	$WHENEVER SQLERROR GOTO errexit;

	stmt[0] = '\0';
	
	/* �ư�car539��J���߮� modify by sylvia 107.05.03 (1070403001_SC1) */
	/* �ư�car537�s�y�{����J���߮� modify by sylvia 108.01.11 (1070403002_SC1) */
	/* �ư�car540��J���߮� modify by sylvia 108.03.29 (1070705004_SC1) */
	sprintf_s(stmt,5120,"SELECT count(*) \
						FROM ao_stl_close a \
						WHERE ibatch = '%s' \
						and dgroup IS NULL \
						and not exists (select * from sysdb:ca_onsiteproc_cost \
						    where iqserial = a.ibatch)\
						and not exists (select * from sysdb:ca_health_recovery \
						    where iqserial = a.ibatch)\
						and not exists (select * from sysdb:ca_tow_away \
						    where iqserial = a.ibatch)",  ibatch);
	printf("stmt==>[%s]\n",stmt);
	$PREPARE batch_no_chk FROM $stmt;
	$EXECUTE batch_no_chk INTO $chk_ibatch;

	cm_buf_init(ReplyBuf);
	cm_buf_put("%l %d",M_CM_OK,chk_ibatch);
	LiBufLen = cm_buf_len(ReplyBuf);
	if (SendSyncReply(reply,ReplyBuf,LiBufLen,api_OKComplete)==False)
	{
		puts("apiRC");
		return apiRC;
	}
	else
	{
		puts("api_OKComplete");
		return api_OKComplete;
	}

errexit:
	return SQLCODE;
}

/*--------------------------------------------------*/
/*char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}
*/
