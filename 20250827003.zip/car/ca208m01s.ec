/***************************************************/
/*                                                 */
/*   PROGRAM : ca208m01s.ec                        */
/*   Checked for ����100�~�M��                     */
/***************************************************/
#include <stdio.h>
#include "comdata.h"
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "gls_array.h" 
#include "gls_const.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include  "cmnmsgs.h"
#include "is_def.h"
#include "safeclib.h"
$include sqlca;

#define WAKEUP_CNT 100
#define DATENULL               0x80000000L

/************************************************************************/
long car208(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
     long rtncode;
     long car208_fstatus();
     long car208_compulsory_code();
     char option,option1;

     cm_buf_init(command);
     cm_buf_get("%c",&option);
     printf("36 %c\n" ,&option);
     switch(option)
     {
        case 'A':
             rtncode=car208_fstatus(reply);
             break;
        case 'B':
             rtncode=car208_compulsory_code(reply); /* �j��d�r�y */
             break;     
        default :
            return exitsub(reply,M_CM_WRONG_OPTION)?M_CM_WRONG_OPTION:apiRC;
     }
     return(rtncode);
}

/*****************************************************************************/
long car208_fstatus(reply)
serverReply reply; 
{
     $char DBName[DBNAME];
     char  funopt[2],dateopt[2];
     $char dabgn[11],daend[11];
     $char iquota[11];
     $char officerbgn[11],officerend[11];
     $char dptbgn[3],dptend[3];
     $char ideliverbgn[11],ideliverend[11];
     $char icard1[21],icard2[21];
     $char comp[2],card[2];
     $char cartype[2];
     $char fstatusbgn[2];
     $char fstatus[2],icar_type[3];
     $char buf1[201],buf2[128],buf3[50],buf4[50],buf5[60],buf6[70],buf7[50],buf8[50],buf9[50],buf10[50];
     long fstatus_0,fstatus_1,fstatus_2,fstatus_3,fstatus_4,fstatus_5,fstatus_6,fstatus_tot;
     long fstatus_7,fstatus_A,fstatus_B,fstatus_C,fstatus_D,fstatus_E;
     $char stmtA[512],stmtB[512];
     $char sKbill_code[5], choice1[2], table_name[15], fin_out[2];

     int   count,i; /* standard defined data */
     int   tmp_len;
     long  MsgCode;
     long  fRtnCode;
     /* end of standard data */

     /* self defined data */
     int   rows;
     $date max_drate=DATENULL;
     char  FullDBName[20];
     $char stmt_buf[500];
     /* end of self data */

     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
                dateopt, dabgn, daend, choice1, dptbgn, dptend, iquota, officerbgn,
                officerend, ideliverbgn, ideliverend, icard1, icard2, comp, card,
                cartype, fstatusbgn, sKbill_code,fin_out);

     strcpy(dabgn,cm_to_infdate(dabgn));
     strcpy(daend,cm_to_infdate(daend));

     fstatus_0=fstatus_1=fstatus_2=fstatus_3=fstatus_4=fstatus_5=fstatus_6=fstatus_tot=0;
     fstatus_7=fstatus_A=fstatus_B=fstatus_C=fstatus_D=fstatus_E=0;
     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
         return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
         	
     if (dptbgn[0]!='*' && dptend[0]!='*')
     {
       if (choice1[0] == '2' || choice1[0] == '3')
      		strcpy(table_name,",officer b ");
       else
      		strcpy(table_name,"");
     }
     else
     {
      	  strcpy(table_name,"");
     }
     printf("94 dateopt[0]= %s\n" ,dateopt[0]);
     if (dateopt[0]=='1')
        sprintf_s(buf1, sizeof buf1,"WHERE a.dissue BETWEEN '%s' AND '%s' ",dabgn,daend);
     else if (dateopt[0]=='2')
        sprintf_s(buf1, sizeof buf1,"WHERE a.dreceive BETWEEN '%s' AND '%s' ",dabgn,daend);
     else if (dateopt[0]=='3')
        sprintf_s(buf1, sizeof buf1,"WHERE a.ddeliver BETWEEN '%s' AND '%s' ",dabgn,daend);
     else if (dateopt[0]=='4')   
        sprintf_s(buf1, sizeof buf1,"WHERE a.dalter BETWEEN '%s' AND '%s' ",dabgn,daend);
     else if (dateopt[0]=='5')
        sprintf_s(buf1, sizeof buf1,"WHERE a.dissue BETWEEN '%s' AND '%s' "
                               "AND (a.ddeliver BETWEEN '%s' AND '%s' "
                                "OR a.ddeliver is null) ",dabgn,daend,dabgn,daend);
     
     strcpy(sKbill_code,trim(sKbill_code));
     if (strlen(sKbill_code) != 0)
       sprintf_s(buf9, sizeof buf9,"AND a.icard[3,4] = '%s' ",sKbill_code);
     else
       strcpy(buf9," ");
     
     if (dptbgn[0]!='*' && dptend[0]!='*'){     	
     	 if (choice1[0] == '1')      		
          sprintf_s(buf2, sizeof buf2,"AND a.iissue_branch BETWEEN '%s' AND '%s' ",dptbgn,dptend);
       else if (choice1[0] == '2')
        	sprintf_s(buf2, sizeof buf2,"AND a.ideliver = b.iofficer "
        	              "AND b.ibranch BETWEEN '%s' AND '%s' ",dptbgn,dptend);
       else
        	sprintf_s(buf2, sizeof buf2,"AND a.ialter = b.iofficer "
        	              "AND b.ibranch BETWEEN '%s' AND '%s' ",dptbgn,dptend);        	                                                 
     }
     else {
       strcpy(buf2," ");
     }

     if (officerbgn[0]!='*' && officerend[0]!='*')
       sprintf_s(buf3, sizeof buf3,"AND a.iofficer BETWEEN '%s' AND '%s' ",officerbgn,officerend);
     else
       strcpy(buf3," ");

     if (ideliverbgn[0]!='*' && ideliverend[0]!='*')
       sprintf_s(buf4, sizeof buf4,"AND a.ideliver BETWEEN '%s' AND '%s' ",ideliverbgn,ideliverend);
     else
       strcpy(buf4," ");

     if (ideliverbgn[0]!='*' && ideliverend[0]!='*')
       sprintf_s(buf4, sizeof buf4,"AND a.ideliver BETWEEN '%s' AND '%s' ",ideliverbgn,ideliverend);
     else
       strcpy(buf8," ");       

     if (icard1[0]!='*' && icard2[0]!='*')
       sprintf_s(buf5, sizeof buf5,"AND a.icard BETWEEN '%s' AND '%s' ",icard1,icard2);
     else
       strcpy(buf5," ");

     if (fstatusbgn[0]!='9' )
     {
     	if (fstatusbgn[0] == '0') 
      	{
      		strcpy(buf6," AND a.fstatus in ('0','5') ");
      	}
     	else if (fstatusbgn[0] == 'Y') 
      	{
      		strcpy(buf6," AND a.fstatus in ('0','5','6','7') ");
      	}
      	else if (fstatusbgn[0] == 'Z')
      	{
      		strcpy(buf6," AND a.fstatus in ('A','B','C','D','E','8','3') ");
      	}
      	else
      	{
          sprintf_s(buf6, sizeof buf6,"AND a.fstatus = '%s' ",fstatusbgn);
        }
     }
     
     sprintf_s(buf7, sizeof buf7,"AND a.iquota matches '%s' ",iquota);
     
     if (fin_out[0] == '8')
      {
      	strcpy(buf10,"AND a.fin_out in ('1','2') ");
      }
      else if(fin_out[0] == '9')
      {
      	strcpy(buf10," ");
      }
      else 
      {
      	sprintf_s(buf10, sizeof buf10,"AND a.fin_out = '%s' ",fin_out);
      }
      
       printf("132 buf1=[%s],buf2=[%s],buf3=[%s],buf4=[%s],buf5=[%s],buf6=[%s],buf7=[%s],buf9=[%s],buf10=[%s]\n",buf1,buf2,buf3,buf4,buf5,buf6,buf7,buf9,buf10);   
     if (comp[0]=='1')
     {
        sprintf_s(stmtA, sizeof stmtA,
               "SELECT a.icar_type,a.fstatus "
                  "FROM compulsory_card a%s %s %s %s %s %s %s %s %s %s",
                  table_name,buf1,buf2,buf3,buf4,buf5,buf6,buf7,buf9,buf10);

        $PREPARE CUR_STMT1 FROM $stmtA;
        printf(" 141&&&& stmtA=[%s] \n",stmtA);
        $DECLARE Acursor1 CURSOR FOR CUR_STMT1;
        $OPEN Acursor1;
        printf(" 144 stmtA=[%s] \n",stmtA);
      
        for(;;)
        {
          $FETCH Acursor1 INTO $icar_type,$fstatus;
          if(SQLCODE == SQLNOTFOUND ) break;

          if (cartype[0]=='1')       /* �T�� */
          { if(strncmp(icar_type,"01",2)==0 || strncmp(icar_type,"02",2)==0 ||
                strncmp(icar_type,"32",2)==0 || strncmp(icar_type,"34",2)==0 || strncmp(icar_type,"35",2)==0)
                continue;
          }
          else if(cartype[0]=='2')   /* ���� */
          { if(strncmp(icar_type,"01",2)!=0 && strncmp(icar_type,"02",2)!=0 &&
                strncmp(icar_type,"32",2)!=0 && strncmp(icar_type,"34",2)!=0 && strncmp(icar_type,"35",2)!=0)
                continue;

          }
          printf("##### fstatus[%s]\n",fstatus);
          
          if (strcmp(fstatus,"0")==0) 
              fstatus_0 +=1;
          if (strcmp(fstatus,"1")==0)
              fstatus_1 +=1;
          if (strcmp(fstatus,"3")==0)
              fstatus_3 +=1;
          if (strcmp(fstatus,"4")==0)
              fstatus_4 +=1;
          if (strcmp(fstatus,"5")==0)
              fstatus_5 +=1;
          if (strcmp(fstatus,"6")==0)
              fstatus_6 +=1;
          if (strcmp(fstatus,"7")==0) 
              fstatus_2 +=1; 
          if (strcmp(fstatus,"8")==0) 
              fstatus_7 +=1;
          if (strcmp(fstatus,"A")==0) 
              fstatus_A +=1;     
          if (strcmp(fstatus,"B")==0) 
              fstatus_B +=1;
          if (strcmp(fstatus,"C")==0) 
              fstatus_C +=1;
          if (strcmp(fstatus,"D")==0) 
              fstatus_D +=1;
          if (strcmp(fstatus,"E")==0) 
              fstatus_E +=1;       
      
        }
        $CLOSE Acursor1;
        $FREE Acursor1;
      }
      printf("171 fstatus0=[%ld],fststus1=[%ld],fstatus2=[%ld],fstatus3=[%ld],fststus4=[%ld],fststus5=[%ld],fststus6=[%ld]\n",fstatus_0,fstatus_1,fstatus_2,fstatus_3,fstatus_4,fstatus_5,fstatus_6);
      if (card[0]=='2')
      { sprintf_s(stmtB, sizeof stmtB,
               "SELECT a.icar_type,a.fstatus "
                  "FROM card a%s %s %s %s %s %s %s %s",
                  table_name,buf1,buf2,buf3,buf4,buf5,buf6,buf7);

        $PREPARE CUR_STMT2 FROM $stmtB;
        $DECLARE Acursor2 CURSOR FOR CUR_STMT2;
        $OPEN Acursor2;
        printf("181 stmtB=[%s] \n",stmtB);
        for(;;)
        {
          $FETCH Acursor2 INTO $icar_type,$fstatus;
          if(SQLCODE == SQLNOTFOUND ) break;

          if (cartype[0]=='1')       /* �T�� */
           { if(strncmp(icar_type,"01",2)==0 || strncmp(icar_type,"02",2)==0 ||
                strncmp(icar_type,"32",2)==0 || strncmp(icar_type,"34",2)==0 || strncmp(icar_type,"35",2)==0)
                continue;
           }
          else if(cartype[0]=='2')   /* ���� */
           { if(strncmp(icar_type,"01",2)!=0 && strncmp(icar_type,"02",2)!=0 &&
                strncmp(icar_type,"32",2)!=0 && strncmp(icar_type,"34",2)!=0 && strncmp(icar_type,"35",2)!=0)
                continue;

           }

          if (strcmp(fstatus,"0")==0)
              fstatus_0 +=1;
          if (strcmp(fstatus,"1")==0)
              fstatus_1 +=1;
          if (strcmp(fstatus,"3")==0)
              fstatus_3 +=1;
          if (strcmp(fstatus,"4")==0)
              fstatus_4 +=1;
          if (strcmp(fstatus,"5")==0)
              fstatus_5 +=1;
          if (strcmp(fstatus,"6")==0)
              fstatus_6 +=1;
          if (strcmp(fstatus,"7")==0)
              fstatus_2 +=1;              
          if (strcmp(fstatus,"8")==0) 
              fstatus_7 +=1;
          if (strcmp(fstatus,"A")==0) 
              fstatus_A +=1;     
          if (strcmp(fstatus,"B")==0) 
              fstatus_B +=1;
          if (strcmp(fstatus,"C")==0) 
              fstatus_C +=1;
          if (strcmp(fstatus,"D")==0) 
              fstatus_D +=1;
          if (strcmp(fstatus,"E")==0) 
              fstatus_E +=1;
        }
        $CLOSE Acursor2;
        $FREE Acursor2;
      }
      printf("215 fstatus0=[%d],fststus1=[%d],fstatus2=[%d],fstatus3=[%d],fststus4=[%d],fststus5=[%d],fststus6=[%d]\n",fstatus_0,fstatus_1,fstatus_2,fstatus_3,fstatus_4,fstatus_5,fstatus_6);
      fstatus_tot = fstatus_0 + fstatus_1 + fstatus_2 + fstatus_3 + fstatus_4+ fstatus_5+ fstatus_6 + fstatus_7 + fstatus_A + fstatus_B + fstatus_C + fstatus_D + fstatus_E;
      cm_buf_init(ReplyBuf);
      cm_buf_put("%l %l %l %l %l %l %l %l %l %l %l %l %l %l %l",M_CM_OK,
                 fstatus_0,fstatus_1,fstatus_2,fstatus_3,fstatus_4,fstatus_5,fstatus_6,fstatus_7,fstatus_A,fstatus_B,fstatus_C,fstatus_D,fstatus_E,fstatus_tot);
      tmp_len = cm_buf_len(ReplyBuf);

      if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
      else
         return api_OKComplete;
      printf("239 end \n");
    
errexit:
     printf("SQL ERROR = %ld errm=%s\n",SQLCODE,sqlca.sqlerrm);
     MsgCode = SQLCODE;
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     if (SQLCODE != 0) MsgCode = SQLCODE;
     return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
/*****************************************************************************/
long car208_compulsory_code(reply)
serverReply reply; 
{
    $char DBName[DBNAME];
    $char sKbill_code[5],sEbill_desc[21];
    $char stmt[101];
    
    int tmp_len,count;
    
    cm_buf_get("%s",DBName);
    
    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False) 
    { 
      if(exitsub(reply,M_CM_DB_NOTOPEN) == True)  return M_CM_DB_NOTOPEN;
      else  return apiRC;
    }
    
    cm_buf_init(ReplyBuf);
    cm_buf_res_msg();
    cm_buf_res_count(); /* �j��d�r�y */
    
    $DECLARE code_cur CURSOR FOR
      SELECT kbill_code,ebill_desc
        FROM billingsystem
        WHERE kbill_grp = 'C1'
         AND kbill_tp[1,1] in ('Z','M')
         AND length(kbill_tp) = '2'
         AND fcheck_num = 'Y'
       ORDER by kbill_code;

    $OPEN code_cur;
    count = 0;
    
    for(;;)
    {
    	$FETCH code_cur INTO $sKbill_code,$sEbill_desc;
      if (SQLCODE == SQLNOTFOUND) break;
         
      count++;
      strcpy(stmt,trim(sKbill_code));
      strcat(stmt," - ");
      strcat(stmt,trim(sEbill_desc));
      cm_buf_put("%s",stmt);    
    }        
    $CLOSE code_cur;
    $FREE  code_cur;
    
    cm_buf_put_count_seq(1,count);
    
    cm_buf_put_msg(M_CM_OK);
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)  return apiRC;
    else return api_OKComplete;
    
errexit:
printf("<car208_compulsory_code> sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  if(exitsub(reply,SQLCODE) == True)  return SQLCODE;
  else return apiRC;
}
/*****************************************************************************/
