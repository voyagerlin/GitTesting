/************************************************/
/*                                              */
/*   PROGRAM : ca202m01s.ec                     */ 
/*   Checked for ����100�~�M��                  */ 
/************************************************/
     
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;

#define WAKEUP_CNT      100

long car202(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
     long rtncode;
     long car202_card_query(),car202_card_count();
     long car202_ideliver_chkfin();
     long car202_chk_SQ();
     long car202_update_exec();
     long car202_print();
     char option;

     cm_buf_init(command);
     cm_buf_get("%c",&option);
     switch(option)
     {
          case '1':
                   rtncode=car202_card_query(reply);
                   break;
          case '2':
                   rtncode=car202_card_count(reply);
                   break;
          case '3': /*1060821005-�j���Һ޲z*/
                   rtncode=car202_ideliver_chkfin(reply);
                   break;
          case '4': /* 1070314013_SC1 */
                   rtncode=car202_chk_SQ(reply);
                   break;
          case 'M':
                   rtncode=car202_multiple_query(reply);
                   break;
                   
          case 'U':
                   rtncode=car202_update_exec(reply,command,com_len);
                   break;
          case 'P':
                   rtncode=car202_print(reply);
                   break;
          default :
                   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
                    return M_CM_WRONG_OPTION;
                   return apiRC;
     }
     return(rtncode);
}

/*****************************************************************************/
long car202_card_query(reply)
serverReply reply;
{
     $char DBName[DBNAME];
     $char sIcard[CARD_NUM], sIbranch[4];
     $char sfcard_class[2];

     /* standard defined data */
     int  tmp_len;
     long MsgCode, fRtnCode;
     /* end of standard data */

     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s ",sIbranch, sIcard );

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     if (db_select (DBName) == False)
     {
         if (exitsub (reply, M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
         else
            return apiRC;
     }
     
     /** �O�_���j���� **/
     $SELECT *
        FROM compulsory_card
       WHERE icard = $sIcard
         AND iissue_branch = $sIbranch;

     if (SQLCODE == SQLNOTFOUND)
     {
          /** �O�_�����N�d **/
          $SELECT *
             FROM card
            WHERE icard = $sIcard
              AND iissue_branch = $sIbranch;

          if (SQLCODE == SQLNOTFOUND)
          {
             if(exitsub(reply,M_CM_NOT_FOUND) == True)
                 return M_CM_NOT_FOUND;
             else
                 return apiRC;
          }
          else
             strcpy( sfcard_class,"2");
     }
     else
          strcpy( sfcard_class,"1");


     cm_buf_init(ReplyBuf);
     cm_buf_put("%l ",M_CM_OK);
     cm_buf_put("%s ",sfcard_class );
     
     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
     {
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         return apiRC;
     }
     else
         return api_OKComplete;

errexit:
     MsgCode = SQLCODE;
     printf("sqldata = %s\n",sqlca.sqlerrm);
     if (SQLCODE != 0) MsgCode = SQLCODE;
     if(exitsub(reply,MsgCode) == True)
        return MsgCode;
     else
        return apiRC;
} 

long car202_card_count(reply)
serverReply reply;
{
     char  DBName[5];
     $char  cardnum[19],tmp_cardnum[19];
     long  MsgCode, fRtnCode;
     char  issuredt[9];
     char  sIcardyear[YYYMMDD];
     int   tmp_len;
     char  bill_cde[3];
     int   rows,card_len;
     $char sFcard_class[2];
     $char sIbranch[4], Coption[2];
     $char sIcard_begin[CARD_NUM], sIcard_end[CARD_NUM];
     $long Dreceive,Ddeliver,id1;
     $long unused,usedsum,sum;
     $int  c_iofficer, rnt_msg;

     /* end of self data */
     printf("car202_card_count begin\n");

     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s %s %s %s ",Coption, sFcard_class, sIbranch, 
                                  sIcard_begin, sIcard_end );

     $WHENEVER SQLERROR GOTO errexit;
     if (db_select(DBName) == False)
     {
       if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
        return M_CM_DB_NOTOPEN;
       else
        return apiRC;
     }
         
     printf(" prepare count num \n");
     rnt_msg=0;
     usedsum=unused=sum=0;

     if( strcmp(Coption,"1") == 0 )
     {
        printf("Coption == [1]\n");
        /** �p��ӻ�i�� **/
        if(strcmp(sFcard_class,"1")==0)
        {
           $DECLARE comp1_cur CURSOR for
             SELECT dreceive
               INTO $Dreceive:id1
               FROM compulsory_card
              WHERE icard >= $sIcard_begin
                AND icard <= $sIcard_end
                AND iissue_branch = $sIbranch;
           $OPEN comp1_cur;
           while(1)
           {
               $FETCH comp1_cur;
               if( SQLCODE == SQLNOTFOUND ) break;
                                
               if (id1<0) unused++;
               else       usedsum++;
               
           }
           $CLOSE comp1_cur;
        }
        else
        {
           $DECLARE valu1_cur CURSOR for
             SELECT dreceive
               INTO $Dreceive:id1
               FROM card
              WHERE icard >= $sIcard_begin
                AND icard <= $sIcard_end
                AND iissue_branch = $sIbranch;
           $OPEN valu1_cur;
           while(1)
           {
               $FETCH valu1_cur;
               if( SQLCODE == SQLNOTFOUND ) break;
               
               if (id1<0) unused++;
               else       usedsum++;
           }
           $CLOSE valu1_cur;            
        
        }
     }
     else if( strcmp(Coption,"2")==0 )
     {
        /** �p��t�o�i�� **/
        if(strcmp(sFcard_class,"1")==0)
        {
           $DECLARE comp2_cur CURSOR for
             SELECT ddeliver
               INTO $Ddeliver:id1
               FROM compulsory_card
              WHERE icard >= $sIcard_begin
                AND icard <= $sIcard_end
                AND iissue_branch = $sIbranch
                AND dreceive is not null
                AND fstatus in ('0','5','6','7');
           $OPEN comp2_cur;
           while(1)
           {
               $FETCH comp2_cur;
               if( SQLCODE == SQLNOTFOUND ) break;
                                
               if (id1<0) unused++;
               else       usedsum++;
           }
           $CLOSE comp2_cur;
        }
        else
        {
           $DECLARE valu2_cur CURSOR for
             SELECT ddeliver
               INTO $Ddeliver:id1
               FROM card
              WHERE icard >= $sIcard_begin
                AND icard <= $sIcard_end
                AND iissue_branch = $sIbranch
                AND dreceive is not null
                AND fstatus in ('0','7');
           $OPEN valu2_cur;
           while(1)
           {
               $FETCH valu2_cur;
               if( SQLCODE == SQLNOTFOUND ) break;
                                
               if (id1<0) unused++;
               else       usedsum++;
           }
           $CLOSE valu2_cur;
        }       
        
     }  
     else if( strcmp(Coption,"3")==0 )
     {
        /** �ˮ֥d���϶������P�@��ΤH **/
        if(strcmp(sFcard_class,"1")==0)
        {
           $DECLARE comp3_cur CURSOR for
             SELECT NVL( count( distinct iofficer ),0)
               INTO $c_iofficer
               FROM compulsory_card
              WHERE icard >= $sIcard_begin
                AND icard <= $sIcard_end;
           $OPEN comp3_cur;
           $FETCH comp3_cur;
           $CLOSE comp3_cur;
           
           if( c_iofficer > 1 )
           {
                rnt_msg = 21004;
           }

           $DECLARE comp4_cur CURSOR for
             SELECT ddeliver
               INTO $Ddeliver:id1
               FROM compulsory_card
              WHERE icard >= $sIcard_begin
                AND icard <= $sIcard_end
                AND iissue_branch = $sIbranch
                AND dreceive is not null
                AND ddeliver is not null
                AND fstatus in ('0','5','6','7');
           $OPEN comp4_cur;
           while(1)
           {
               $FETCH comp4_cur;
               if( SQLCODE == SQLNOTFOUND ) break;
                                
               if (id1<0) unused++;
               else       usedsum++;
           }
           $CLOSE comp4_cur;
        }
        else
        {
           $DECLARE valu3_cur CURSOR for
             SELECT NVL( count( distinct iofficer ),0)
               INTO $c_iofficer
               FROM card
              WHERE icard >= $sIcard_begin
                AND icard <= $sIcard_end;
           $OPEN valu3_cur;
           $FETCH valu3_cur;
           $CLOSE valu3_cur;
           
           if( c_iofficer > 1 )
           {
                rnt_msg = 21004;
           }               

           $DECLARE valu4_cur CURSOR for
             SELECT ddeliver
               INTO $Ddeliver:id1
               FROM card
              WHERE icard >= $sIcard_begin
                AND icard <= $sIcard_end
                AND iissue_branch = $sIbranch
                AND dreceive is not null
                AND ddeliver is not null
                AND fstatus in ('0','7');
           $OPEN valu4_cur;
           while(1)
           {
               $FETCH valu4_cur;
               if( SQLCODE == SQLNOTFOUND ) break;
               
               if (id1<0) unused++;
               else       usedsum++;
           }
           $CLOSE valu4_cur;
        }                       
     }
     else
     {
        if(exitsub(reply,M_CM_WRONG_OPTION) == True)
           return M_CM_WRONG_OPTION;
        else
           return apiRC;
     }
     
     sum = unused + usedsum;

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     cm_buf_put("%l",rnt_msg );
     cm_buf_put("%l %l %l ",unused, usedsum, sum );
     
     tmp_len = cm_buf_len(ReplyBuf);

     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
     {
         $WHENEVER SQLERROR CONTINUE;
         return apiRC;
     }
     return api_OKComplete;

errexit:
     MsgCode = SQLCODE;
     printf("sqldata = %s\n",sqlca.sqlerrm);
     if (SQLCODE != 0) MsgCode = SQLCODE;
     if(exitsub(reply,MsgCode) == True)
         return MsgCode;
     else
         return apiRC;
}
long car202_chk_SQ(reply)
serverReply reply;
{
    $char DBName[DBNAME];
    $char ideliver[11], ileader[11] , iroute[21];
    $int c_ideliver;    
    int  tmp_len;
    long MsgCode, fRtnCode;

    cm_buf_get("%s",DBName);
    cm_buf_get("%s",ideliver);
    
    c_ideliver = 0;
    
    EXEC SQL WHENEVER SQLERROR GOTO errexit;
    
    if (db_select (DBName) == False)
    {
    	if (exitsub (reply, M_CM_DB_NOTOPEN) == True)
    	    return M_CM_DB_NOTOPEN;
    	else
    	    return apiRC;
    }
    
    /** �O�_��CAR140���OSQ **/
    $SELECT ileader, iroute
       INTO $ileader, $iroute
       FROM officer
      WHERE iofficer = $ideliver;
      
    
    $SELECT NVL(count(*),0)
       INTO $c_ideliver
       FROM car_code
      WHERE kind = 'SQ'
        AND detail = '1'
    	AND detail2 = $ideliver;
    	
    if (c_ideliver == 0)
    {
    	$SELECT NVL(count(*),0)
    	   INTO $c_ideliver
    	   FROM car_code
    	  WHERE kind = 'SQ'
    	    AND detail = '2'
    	    AND detail2 = $iroute;
    	    
    	if (c_ideliver == 0)
    	{
    	    $SELECT NVL(count(*),0)
    	       INTO $c_ideliver
    	       FROM car_code
    	      WHERE kind = 'SQ'
    	        AND detail = '1'
    	        AND detail2 = $ileader;
    	}
    }     
        
    cm_buf_init(ReplyBuf);
    cm_buf_put("%l ",M_CM_OK);
    cm_buf_put("%d ",c_ideliver);
    
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    {
    	$WHENEVER SQLERROR CONTINUE;
    	$ROLLBACK WORK;
    	return apiRC;
    }
    else
        return api_OKComplete;

errexit:
     MsgCode = SQLCODE;
     printf("sqldata = %s\n",sqlca.sqlerrm);
     if (SQLCODE != 0) MsgCode = SQLCODE;
     if(exitsub(reply,MsgCode) == True)
        return MsgCode;
     else
        return apiRC;
    
}
long car202_ideliver_chkfin(reply)
serverReply reply;
{
    char  DBName[5];
    long  MsgCode, fRtnCode;
    int   tmp_len;
    int   rows,card_len;
    $char sIbranch[4], Coption[2];
    $char sIcard_begin[CARD_NUM], sIcard_end[CARD_NUM];
    $long Dreceive,Ddeliver,id1;
    $long unused,usedsum,sum;
    $int  c_iofficer, rnt_msg,rc_ioff;
    $char ideliver[11],ibroker_top[2],bzfrom[3],fin_out[2],ioff_fin_out[2];
    /* end of self data */
    printf("car202_card_count begin\n");

    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s %s %s %s ",Coption,  ideliver,sIbranch, 
                                 sIcard_begin, sIcard_end );

    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False)
    {
      if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
       return M_CM_DB_NOTOPEN;
      else
       return apiRC;
    }
    /*
    ideliver    ��   ioff_fin_out 0:���]�w 1:���� 2:�~���q��
    ���u�s��           �����q��    �]�w��car140(55��)
    ���u�s��           �~���q��    �s�b�H�Ƹ���ɪ��g��N��
    
    �O�N/�O�g�g��N��  �~���q��    �O�o�q���N����20.21/30.31
    ����~�ȭ��g��N�� �~���q��    �I����H��I�}�Y������~�ȭ�
    
    �g��N��                      ���s�b��cmn108�B�����u�~�ȭ����ҡA�����o��J�Fĵ�ܰT���i�D�ݥi�t�o���g��N���j�C
    */
    printf(" prepare count num \n");
    rnt_msg=0;
    rc_ioff =0;
    c_iofficer =0;
    strcpy(ioff_fin_out,"");
    strcpy(fin_out,"");
    usedsum=unused=sum=0;
    
    printf("chk �]�w��car140(55��) \n");
    $SELECT NVL(count(*),0) 
       INTO $c_iofficer 
       FROM car_code 
      WHERE kind ='55' 
        AND detail = $ideliver;
    if(c_iofficer == 0)
    {
        printf("chk �H�Ƹ����\n");
        $SELECT NVL(count(*),0) 
           INTO $c_iofficer 
           FROM personal:asempl
          WHERE empl_no = $ideliver
            AND move_type < 59;
        if(c_iofficer == 0)
        {
            printf("�O�o�q���N��=>");
            rc_ioff =  cm_get_bzfrom(ideliver," "," ",bzfrom);
            printf("bzfrom [%s]\n",bzfrom);
            if((strcmp(bzfrom,"20") == 0 )||(strcmp(bzfrom,"21") == 0 )||(strcmp(bzfrom,"30") == 0 )||(strcmp(bzfrom,"31") == 0 ))
            {
                strcpy(ioff_fin_out,"2");
                printf("�O�N/�O�g\n");
            }
           else
            {
                $select nvl(b.ibroker_top[1], ' ') 
                   INTO $ibroker_top
                   FROM officer a,outer v_commission_obj b
                  WHERE a.iofficer = $ideliver
                    AND a.icomm_obj = b.icomm_obj;
                if(SQLCODE == SQLNOTFOUND)
                {
                    strcpy(ioff_fin_out,"X");
                    printf("�g��N�����s�b");
                }
                else
                {
                    if(strcmp(ibroker_top,"I") == 0 )
                    {
                        strcpy(ioff_fin_out,"2");
                        printf("�g��N��-����");
                    }    
                    else
                    {
                        strcpy(ioff_fin_out,"0");
                        printf("�g��N��-���o��J");
                    }    
                }
            }
        }
        else
        {
            strcpy(ioff_fin_out,"2");
        }
    }
    else
    {
        strcpy(ioff_fin_out,"1");
    }
    printf("ioff_fin_out[%s]\n",ioff_fin_out);
    
    rc_ioff = 0 ;
    strcpy(fin_out," ");
    if( strcmp(Coption,"2")==0 )
    {
       /** �ˮ֥d���϶����w���ҥd�t�e��� **/
        $DECLARE comp2_chk_cur CURSOR for
          SELECT ddeliver
            INTO $Ddeliver:id1
            FROM compulsory_card
           WHERE icard >= $sIcard_begin
             AND icard <= $sIcard_end
             AND iissue_branch = $sIbranch
             AND dreceive is not null
             AND fstatus in ('0','5','6','7');
           $OPEN comp2_chk_cur;
        while(1)
        {
            $FETCH comp2_chk_cur;
            if( SQLCODE == SQLNOTFOUND ) break;
                            
            if (id1<0) unused++;
            else       usedsum++;
        }
        $CLOSE comp2_chk_cur;
        $FREE comp2_chk_cur;
        printf("unused[%l]usedsum[%l]\n",unused,usedsum);
        
    }  
    else if( strcmp(Coption,"3")==0 )
    {
       /** �ˮ֥d���϶������P�@��ΤH **/
        $DECLARE comp3_chk_cur CURSOR for
          SELECT NVL( count( distinct iofficer ),0)
            INTO $c_iofficer
            FROM compulsory_card
           WHERE icard >= $sIcard_begin
             AND icard <= $sIcard_end;
        $OPEN comp3_chk_cur;
        $FETCH comp3_chk_cur;
        $CLOSE comp3_chk_cur;
        $FREE comp3_chk_cur;
        if( c_iofficer > 1 )
        {
            rnt_msg = 21004;
        }
      
        $DECLARE comp4_chk_cur CURSOR for
          SELECT NVL( count( distinct fin_out ),0)
            INTO $rc_ioff
            FROM compulsory_card
           WHERE icard >= $sIcard_begin
             AND icard <= $sIcard_end AND iissue_branch = $sIbranch
             AND dreceive is not null
             AND ddeliver is not null
             AND fstatus in ('0','5','6','7');
        $OPEN comp4_chk_cur;
        $FETCH comp4_chk_cur;
        $CLOSE comp4_chk_cur;
        $FREE comp4_chk_cur;
      
        if( rc_ioff > 1 )
        {
            printf("���ܥd���϶����󤺳�/�~���q��\n");
        }
        else
        {
            $SELECT DISTINCT fin_out
               INTO $fin_out
               FROM compulsory_card
              WHERE icard >= $sIcard_begin
                AND icard <= $sIcard_end
                AND iissue_branch = $sIbranch
                AND dreceive is not null
                AND ddeliver is not null
                AND fstatus in ('0','5','6','7');
            if( SQLCODE == SQLNOTFOUND ) strcpy(fin_out,"0");
        }
    }
    else
    {
        if(exitsub(reply,M_CM_WRONG_OPTION) == True)
            return M_CM_WRONG_OPTION;
        else
            return apiRC;
    }
    
   

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    cm_buf_put("%s %s",ioff_fin_out, fin_out );
    cm_buf_put("%l %l", usedsum ,rc_ioff);
    
    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    {
        $WHENEVER SQLERROR CONTINUE;
        return apiRC;
    }
    return api_OKComplete;

errexit:
    MsgCode = SQLCODE;
    printf("sqldata = %s\n",sqlca.sqlerrm);
    if (SQLCODE != 0) MsgCode = SQLCODE;
    if(exitsub(reply,MsgCode) == True)
        return MsgCode;
    else
        return apiRC;
}

/******************************************************************************/
long car202_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
     char  DBName[5];
     $char cardnum[19],tmp_cardnum[19];
     $char stmt[2048];
     long  MsgCode, fRtnCode;
     char  issuredt[9];
     char  sIcardyear[YYYMMDD];
     int   tmp_len;
     char  bill_cde[3];
     int   rows;
     $char iquota[10];
     $char sFcard_class[2];
     $char sIbranch[4], Uoption[2];
     $char icardyear[YYYMMDD], ioffice[7], sIbranch_in[4],  sIcomp_in[3];
     $char sIcard_begin[CARD_NUM], sIcard_end[CARD_NUM];
     $char sIcard[CARD_NUM];
     $char recdata[13], dreceive[13], userid[10];
     $char recdata2[4];
     $char ideliver[11],iofficer[11],ideliver_old[11],fstatus[2];
     $long Dreceive,Ddeliver,id1;
     $long dtoday;
     $long avaisum,usedsum,cancelsum,losssum,expiresum,sum;
     $int  ucount;
     $char fin_out[2];
     printf("car202_update_exec begin\n");

     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s %s %s %s %s %s %s ",Uoption, recdata, recdata2,
                                           sFcard_class, sIbranch,
                                           sIcard_begin, sIcard_end, userid);
     
     strcpy(recdata,trim(recdata));
     strcpy(recdata2,trim(recdata2));

     printf("cardbgn[%s],cardend[%s],sFcard_class[%s],userid[%s]\n",
             sIcard_begin, sIcard_end, sFcard_class,userid);
     printf("recdata[%s],recdata2[%s],sIbranch[%s]\n",recdata, recdata2,sIbranch);

     $WHENEVER SQLERROR GOTO errexit;
     if (db_select(DBName) == False)
     {
         if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
             return M_CM_DB_NOTOPEN;
         else
             return apiRC;
     }

     dtoday = cm_today();
     ucount = 0;

     EXEC SQL SET LOCK MODE TO WAIT 30;

     $BEGIN WORK;

     /* �O�I��/�d��� */
     if(strcmp(Uoption,"1") == 0)
     {
          strcpy(dreceive , recdata);
          strcpy(dreceive , cm_to_infdate(dreceive));

          if(strcmp(sFcard_class,"1") == 0)
          {
              $DECLARE comp_cur1 CURSOR WITH HOLD FOR
                SELECT icard
                  INTO :sIcard
                  FROM compulsory_card
                 WHERE icard         >= $sIcard_begin
                   AND icard         <= $sIcard_end
                   AND iissue_branch =  $sIbranch
                   AND dreceive is null;

              $OPEN comp_cur1;
              for (;;)
              {
                   $FETCH comp_cur1;
                   if (SQLCODE == SQLNOTFOUND) break;

                   $UPDATE compulsory_card
                       SET dreceive = $dreceive,
                           ireceive = $userid,
                           fstatus  = '7'         /*�w��w�d���d���A�q'F'���^'7'*/
                     WHERE icard = $sIcard;

                   ucount ++;
              }
              $CLOSE comp_cur1;

              printf("dreceive compulsory_card count[%d]\n",ucount );
          }
          else
          {
              $DECLARE card_cur1 CURSOR WITH HOLD FOR
                SELECT icard
                  INTO :sIcard
                  FROM card
                 WHERE icard         >= $sIcard_begin
                   AND icard         <= $sIcard_end
                   AND iissue_branch =  $sIbranch
                   AND dreceive is null;

              $OPEN card_cur1;
              for (;;)
              {
                   $FETCH card_cur1;
                   if (SQLCODE == SQLNOTFOUND) break;

                   $UPDATE card
                       SET dreceive = $dreceive,
                           ireceive = $userid,
                           fstatus  = '7'         /*�w��w�d���d���A�q'F'���^'7'*/
                     WHERE icard = $sIcard;

                   ucount ++;
              }
              $CLOSE card_cur1;
              printf("dreceive card count[%d]\n",ucount );
          }
     }
     else if( strcmp(Uoption,"2") == 0) /* �O�I�Ұt�o */
     {
          strcpy( ideliver , recdata );
          strcpy( dreceive , cm_edate_str(dtoday));
          printf("dreceive[%s]\n",dreceive);
          printf("begin[%s] end[%s] ibranch[%s]\n",sIcard_begin, sIcard_end , sIbranch );

          if( strcmp(sFcard_class,"1") == 0 )
          {
              $DECLARE comp_cur2 CURSOR WITH HOLD FOR
                SELECT icard
                  INTO :sIcard
                  FROM compulsory_card
                 WHERE icard         >= $sIcard_begin
                   AND icard         <= $sIcard_end
                   AND iissue_branch =  $sIbranch
                   AND dreceive is not null
                   AND ddeliver is null
                   AND fstatus in ('0','5','6','7');
              $OPEN comp_cur2;
              for (;;)
              {
                   $FETCH comp_cur2;
                   if (SQLCODE == SQLNOTFOUND) break;

                   $UPDATE compulsory_card
                       SET ideliver_old = $ideliver,
                           ideliver     = $ideliver,
                           ddeliver_old = $dreceive,
                           ddeliver     = $dreceive,
                           fin_out      = $recdata2,
                           fstatus      = '0'
                     WHERE icard   = $sIcard;

                   ucount ++;
              }
              $CLOSE comp_cur2;
              printf("class = 1 dreceive count[%d]\n",ucount );
          }
          else
          {
              $DECLARE card_cur2 CURSOR WITH HOLD FOR
                SELECT icard
                  INTO :sIcard
                  FROM card
                 WHERE icard         >= $sIcard_begin
                   AND icard         <= $sIcard_end
                   AND iissue_branch =  $sIbranch
                   AND dreceive is not null
                   AND fstatus in ('0','7');
              $OPEN card_cur2;
              for (;;)
              {
                   $FETCH card_cur2;
                   if (SQLCODE == SQLNOTFOUND) break;

                   $UPDATE card
                       SET ideliver_old = $ideliver,
                           ideliver     = $ideliver,
                           ddeliver     = $dreceive,
                           fstatus      = '0'
                     WHERE icard   = $sIcard;

                   ucount ++;
              }
              $CLOSE card_cur2;
              printf("class = 2 dreceive count[%d]\n",ucount );
          }
     }
     else if( strcmp( Uoption,"3") == 0 )  /* �󥿰t�o�H */
     {
          strcpy( ideliver , recdata);
          strcpy( dreceive , cm_edate_str(dtoday));
          printf("begin[%s] end[%s] ibranch[%s]\n",sIcard_begin, sIcard_end , sIbranch );
/*
   �����q���g��H �� �����q���g��H  �o�ק�
   �~���q���g��H �� �~���q���g��H  �o�ק�
   �����q���g��H �� �~���q���g��H  �P�ɭק��t�o��
*/
          if( strcmp(sFcard_class,"1") == 0 )
          {
              $DECLARE comp_cur3 CURSOR WITH HOLD FOR
                SELECT icard,fin_out
                  INTO :sIcard,:fin_out
                  FROM compulsory_card
                 WHERE icard         >= $sIcard_begin
                   AND icard         <= $sIcard_end
                   AND iissue_branch =  $sIbranch
                   AND dreceive is not null
                   AND ddeliver is not null
                   AND fstatus in ('0','5','6','7');

              $OPEN comp_cur3;
              for (;;)
              {
                   $FETCH comp_cur3;
                   if (SQLCODE == SQLNOTFOUND) break;
                    printf("fin_out[%s]\n",fin_out);
                    if((strcmp(fin_out,"1") == 0 ) && (strcmp(recdata2,"2") == 0 ))
                    {
                        printf("�� �� �~\n");
                       $UPDATE compulsory_card
                           SET ideliver = $ideliver,
                               ddeliver = $dreceive,
                               fin_out = $recdata2,
                               ddeliver_old = $dreceive
                         WHERE icard = $sIcard;
                    }
                    else
                    {
                        printf("�P�q��\n");
                       $UPDATE compulsory_card
                           SET ideliver = $ideliver,
                               ddeliver = $dreceive
                         WHERE icard = $sIcard;
                    }
                   ucount ++;
              }
              $CLOSE comp_cur3;
              printf("option3 = 1 dreceive count[%d]\n",ucount );
          }
          else
          {
              $DECLARE card_cur3 CURSOR WITH HOLD FOR
                SELECT icard
                  INTO :sIcard
                  FROM card
                 WHERE icard         >= $sIcard_begin
                   AND icard         <= $sIcard_end
                   AND iissue_branch =  $sIbranch
                   AND dreceive is not null
                   AND ddeliver is not null
                   AND fstatus in ('0','7');

              $OPEN card_cur3;
              for (;;)
              {
                   $FETCH card_cur3;
                   if (SQLCODE == SQLNOTFOUND) break;

                   $UPDATE card
                       SET ideliver = $ideliver,
                           ddeliver = $dreceive
                     WHERE icard = $sIcard;

                   ucount ++;
              }
              $CLOSE card_cur3;
              printf("option3 = 2 dreceive count[%d]\n",ucount );
          }
     }
     else if( strcmp( Uoption,"4") == 0 )  /* ���ӻ�H�Υӻ��� */
     {
          printf("DBName[%s], begin[%s] end[%s] ibranch[%s]\n",DBName,sIcard_begin, sIcard_end , sIbranch );
          strcpy(dreceive , cm_edate_str(dtoday));

          printf("recdata[%s], recdata2[%s]\n", recdata, recdata2);
          $SELECT iquota
             INTO $iquota
             FROM officer
            WHERE iofficer = $recdata;
          if(SQLCODE == SQLNOTFOUND)
              goto errexit;

          $SELECT iupcomp
             INTO :sIcomp_in
             FROM branch
            WHERE ibranch = :recdata2;
          if(SQLCODE == SQLNOTFOUND)
              goto errexit;

          printf("recdata[%s], recdata2[%s], sIcomp_in[%s]\n",
                  recdata, recdata2, sIcomp_in);

          if( strcmp(sFcard_class,"1") == 0 )
          {
              $DECLARE comp_cur4 CURSOR WITH HOLD FOR
                SELECT icard
                  INTO :sIcard
                  FROM compulsory_card
                 WHERE icard >= $sIcard_begin
                   AND icard <= $sIcard_end
                   AND ddeliver is null
                   AND fstatus in ('0','5','6','7');

              $OPEN comp_cur4;
              for (;;)
              {
                   $FETCH comp_cur4;
                   if (SQLCODE == SQLNOTFOUND) break;

                   $UPDATE compulsory_card
                       SET iissue_branch = $recdata2,
                           iquota        = $iquota,
                           iissue_comp   = $sIcomp_in,
                           iofficer      = $recdata,
                           ialter        = $userid,
                           dalter        = $dreceive
                     WHERE icard = $sIcard;

                   ucount ++;
              }
              $CLOSE comp_cur4;
              printf("option4 = 1 dreceive count[%d]\n",ucount );
          }
          else
          {
              $DECLARE card_cur4 CURSOR WITH HOLD FOR
                SELECT icard
                  INTO :sIcard
                  FROM card
                 WHERE icard >= $sIcard_begin
                   AND icard <= $sIcard_end
                   AND ddeliver is null
                   AND fstatus in ('0','7');

              $OPEN card_cur4;
              for (;;)
              {
                   $FETCH card_cur4;
                   if (SQLCODE == SQLNOTFOUND) break;

                   $UPDATE card
                       SET iissue_branch = $recdata2,
                           iquota        = $iquota,
                           iissue_comp   = $sIcomp_in,
                           iofficer      = $recdata,
                           ialter        = $userid,
                           dalter        = $dreceive
                     WHERE icard = $sIcard;

                   ucount ++;
              }
              $CLOSE card_cur4;
              printf("option4 = 2 dreceive count[%d]\n",ucount );
          }
     }

     avaisum=usedsum=cancelsum=losssum=expiresum=sum=0;
     $WHENEVER SQLERROR GOTO errexit;

     if( strcmp(sFcard_class ,"1") == 0 )
     {
         $SELECT icardyear, iofficer, ioffice, iissue_branch, iissue_comp
            INTO $icardyear,$iofficer,$ioffice,$sIbranch_in,  $sIcomp_in
            FROM compulsory_card
           WHERE icard = $sIcard_begin;
         
         $DECLARE comp_cur9 CURSOR FOR
           SELECT fstatus INTO $fstatus
             FROM compulsory_card
            WHERE icardyear     = $icardyear
              AND iofficer      = $iofficer
              AND ioffice       = $ioffice
              AND iissue_branch = $sIbranch_in
              AND iissue_comp   = $sIcomp_in;
         $OPEN comp_cur9;
         for (;;)
         {
             $FETCH comp_cur9;
             if (SQLCODE ==SQLNOTFOUND)
                  break;

             if (strcmp(fstatus,"0")==0) avaisum+=1;
             if (strcmp(fstatus,"1")==0) usedsum+=1;
             if (strcmp(fstatus,"3")==0) cancelsum+=1;
             if (strcmp(fstatus,"4")==0) losssum+=1;
             if (strcmp(fstatus,"2")==0) expiresum+=1;
             if (strcmp(fstatus,"5")==0) avaisum+=1;
             if (strcmp(fstatus,"6")==0) avaisum+=1;
             if (strcmp(fstatus,"7")==0) avaisum+=1;
         }
         $CLOSE comp_cur9;
     }
     else
     {
         $SELECT icardyear, iofficer, ioffice, iissue_branch, iissue_comp
            INTO $icardyear,$iofficer,$ioffice,$sIbranch_in,  $sIcomp_in
            FROM card
           WHERE icard = $sIcard_begin;

         $DECLARE valu_cur1 CURSOR for
           SELECT fstatus INTO $fstatus
             FROM card
            WHERE icardyear     = $icardyear
              AND iofficer      = $iofficer
              AND ioffice       = $ioffice
              AND iissue_branch = $sIbranch_in
              AND iissue_comp   = $sIcomp_in;
         $OPEN valu_cur1;
         for (;;)
         {
              $FETCH valu_cur1;
              if (SQLCODE ==SQLNOTFOUND) break;

              if (strcmp(fstatus,"0")==0) avaisum+=1;
              if (strcmp(fstatus,"1")==0) usedsum+=1;
              if (strcmp(fstatus,"3")==0) cancelsum+=1;
              if (strcmp(fstatus,"4")==0) losssum+=1;
              if (strcmp(fstatus,"2")==0) expiresum+=1;
              if (strcmp(fstatus,"5")==0) avaisum+=1;
              if (strcmp(fstatus,"6")==0) avaisum+=1;
              if (strcmp(fstatus,"7")==0) avaisum+=1;
         }
         $CLOSE valu_cur1;
     }
     sum=avaisum+usedsum+cancelsum+losssum+expiresum;
    
     $COMMIT WORK;

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     cm_buf_put("%l %l %l %l %l %l %l",
                 avaisum,usedsum,cancelsum,losssum,expiresum,sum,ucount);

     tmp_len = cm_buf_len(ReplyBuf);
     if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
     {
         $WHENEVER SQLERROR CONTINUE;
         $ROLLBACK WORK;
         return apiRC;
     }

     return api_OKComplete;

 errexit:
     printf("errm = %s\n",sqlca.sqlerrm);
     $WHENEVER SQLERROR CONTINUE;
     MsgCode = SQLCODE;
     $ROLLBACK WORK;
     if (SQLCODE != 0) MsgCode = SQLCODE;
     if(exitsub(reply,MsgCode) == True)
          return MsgCode;
     else
          return apiRC;
}

/**===================================================================**/
long car202_multiple_query(reply)
serverReply reply;
{
     $char DBName[5];

     $char iofficer[11],ioffice[7],icardyear[4],issuebranch[CA_POL_BRH_NUM];
     $char sIbranch_in[BRANCH_ID], sIcomp_in[BRANCH_ID];
      char sTmpIbranch[BRANCH_ID], sTmpIcomp[BRANCH_ID];
      char sTmpTaipei[BRANCH_ID];
      char FullDBName[20];
     $char dissue[11],s_dissue[9],iissuer[11],icar_type[3];
     $char sIcard[21], sIofficer[11], fstatus[3], sIdeliver[11];
     $long diss;
     $char key_dissure[11];
     $char icard_begin[21],icard_end[21];
     $char fapp_print[2],frec_print[2];
     $long qcard,qperiod;
     $char iissue_branch[3],sFcard_class[2];
     $char sIcard_begin[21], sIcard_end[21];
     $char dissue_bgn[13], dissue_end[13];
     $char sTmpBuf[2048],sTmpFstatus[128];
     $char TableName[30];

     struct card_t {
            char cardbegin[21];
            char cardend[21];
            char fstatus[3];
            char ideliver[11];
      } card[MAXROWITEMS];

     char officer_bak[11], status_bak[2], cardend_bak[21], deliver_bak[11];
     $long avaisum,usedsum,cancelsum,losssum,expiresum,sum;
     long fRtnCode;

     /* standard defined data */
     char tmpbuf[4000];
     int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
     int i,total_count=0;
     int iFirst, row, init1, icur1;
     /* end of standard data */

     cm_buf_get("%s",DBName);
     cm_buf_get("%s %s %s %s ",
                iissue_branch, ioffice, dissue_bgn, dissue_end );

     strcpy(dissue_bgn,cm_to_infdate(dissue_bgn));
     strcpy(dissue_end,cm_to_infdate(dissue_end));

     printf("dissue_bgn[%s] dissue_end[%s]\n",dissue_bgn, dissue_end );

     $WHENEVER SQLERROR GOTO errexit;
     if (db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     $DECLARE mcurd1 CURSOR FOR
       SELECT unique iofficer,ioffice,icardyear,dissue,iissue_branch,
              iissue_comp,fcard_class,icard_begin, icard_end
         INTO $iofficer,$ioffice,$icardyear,$diss,$sIbranch_in,$sIcomp_in,
              $sFcard_class,$sIcard_begin, $sIcard_end
         FROM issued_card
        WHERE iissue_branch MATCHES $iissue_branch
          AND ioffice MATCHES $ioffice
          AND dissue BETWEEN $dissue_bgn AND $dissue_end
          AND icard_begin <> ' '
          AND icard_end <> ' '
        ORDER BY dissue, icard_begin;
     $OPEN mcurd1;

     count=0, iFirst=1, row=0;
     for(;;)
     {
        $FETCH mcurd1;

        if (SQLCODE != 0) break;

        if( strcmp(sFcard_class,"1") ==0 )
        {
            strcpy(TableName,"compulsory_card");
            strcpy(sTmpFstatus," AND fstatus in ('0','5','6','7') ");
        }
        else
        {
            strcpy(TableName,"card");
            strcpy(sTmpFstatus," AND fstatus in ('0','7') ");
        }

        printf("sIcard_bgn[%s] sIcard_end[%s] iFirst[%d]\n",sIcard_begin, sIcard_end, iFirst );
        init1=0;
        icur1=0;

        sprintf(sTmpBuf,"SELECT %s FROM %s WHERE %s %s %s %s ",
                        " icard, ideliver, fstatus ",
                        TableName,
                        " icard >= ? ",
                        " AND icard <= ? ",
                        sTmpFstatus,
                        " ORDER BY icard");

        $PREPARE comp_tmp FROM   $sTmpBuf;
        $DECLARE comp_num CURSOR for comp_tmp;
        $OPEN    comp_num USING  $sIcard_begin, $sIcard_end;
        while(1)
        {
           $FETCH comp_num INTO $sIcard, $sIdeliver, $fstatus;
           if( SQLCODE == SQLNOTFOUND ) break;

           if( iFirst == 1 )
           {
              printf("iFirst[%d] sIdeliver[%s]\n",iFirst, sIdeliver );
              strcpy(deliver_bak, sIdeliver );
              strcpy(status_bak, fstatus );
              iFirst = 0;
              strcpy(card[row].cardbegin, sIcard );
              row++;
              printf("iFirst[%d] sIdeliver[%s]\n",iFirst , deliver_bak );
           }
           if( icur1 == 0 )
           {
              printf("icur1 =0 icard[%s]\n",sIcard );
              strcpy(deliver_bak, sIdeliver );
              strcpy(status_bak, fstatus );
              icur1 =1;
           }

           if( (strcmp(deliver_bak, sIdeliver ) != 0) || (strcmp(status_bak,fstatus) != 0) )
           {
              printf("officer_bak[%s], officer[%s]\n", deliver_bak, sIdeliver );
              printf("status_bak[%s] , fstatus[%s]\n", status_bak,  fstatus );
              printf("insert into card [%s]\n", sIcard );
              strcpy(card[row-1].cardend, cardend_bak );
              strcpy(card[row-1].fstatus, status_bak );
              strcpy(card[row-1].ideliver, deliver_bak );
              init1=0;
              strcpy( card[row].cardbegin, sIcard);
              row++;
           }
           strcpy(deliver_bak, sIdeliver );
           strcpy(status_bak , fstatus );
           strcpy(cardend_bak, sIcard );
        }
        $CLOSE comp_num;

        printf("insert into card 2 [%s]\n", sIcard );
        strcpy(card[row-1].cardend, sIcard );
        strcpy(card[row-1].fstatus, fstatus );
        strcpy(card[row-1].ideliver, sIdeliver);
        init1=0;
        iFirst = 1;
     }
     $CLOSE mcurd1;
     $FREE  mcurd1;

     for (i=0;i<row;i++)
     {
        printf("[%d]==>[%s][%s][%s][%s]\n",i, card[i].cardbegin, card[i].cardend,
                   card[i].fstatus, card[i].ideliver );
     }

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l ",M_CM_OK);
     cm_buf_put("%l ",row-1);

     for (i=0 ;i<row;i++)
        cm_buf_put("%s %s %s %s ", card[i].cardbegin, card[i].cardend,
                   card[i].fstatus, card[i].ideliver );

     if (row==0) {
        return exitsub(reply,M_CA_NCARD1) ? M_CA_NCARD1 : apiRC;
     }

     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
  printf("SQLCODE=%d errm=%s\n",sqlca.sqlcode,sqlca.sqlerrm);
  return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
long car202_print(reply)
serverReply reply;
{
    $char DBName[5];

    $char iofficer[11],ioffice[7],icardyear[4],issuebranch[41];
    $char dissue[11], sIcomp_in[3], sIbranch_in[3];
    $char s_dissue[10],iissuer[11],icar_type[3],frec_print[2];
    $char icard_begin[21],icard_end[21];
    $long qcard,qperiod;
    $char nofficer[11];
    $long avaisum,usedsum,cancelsum,losssum,expiresum,sum,sum1;
    $char fstatus[2];
    $char sIssue_branch[5];
    $long lchk_cardyear,lchk_ideliver,lchk_ddeliver,lchk_iissuebranch;
    $char sDdeliver[11],sIdeliver[11],sIdeliver_lead[11],sNdeliver[11];
    $char sTmpIbranch[3], sTmpIcomp[3];
    $char sTmpTaipei[BRANCH_ID];
    $char FullDBName[41];
    $char CompanyName[COMPANY_CFULL],sTmpBuf[256];

    /* standard defined data */
    int tmp_len;
    long MsgCode, fRtnCode;
    /* end of standard data */

    /* self defined data */
    long count;
    $long rec_count;
     /* end of self data */

    cm_buf_get("%s",DBName);
    cm_buf_get("%s %s", icard_begin,icard_end );      
    
    $WHENEVER SQLERROR GOTO errexit;
    if (db_select(DBName) == False)
       return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    fRtnCode = getHeadBranch(sTmpTaipei);
    if (fRtnCode < 0)
          return exitsub(reply, M_CM_READ_CONFIG_ERR ) ?
                 M_CM_READ_CONFIG_ERR : apiRC;

    if (strcmp(DBName, sTmpTaipei) !=0)
          return exitsub(reply,M_CA_BRANCH_NSAME) ? M_CA_BRANCH_NSAME :apiRC;

    strcpy(FullDBName, get_full_dbname(sTmpTaipei));
    if (FullDBName[0]=='\0')
          return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

    fRtnCode = getCompanyCFull(CompanyName);
    if (fRtnCode < 0)
       return exitsub(reply, fRtnCode) ?  fRtnCode : apiRC;
    
    /*
     ���o�d���϶�
       1.�p�����|���t�o�g��h���ĵ�ܡi�d���϶��|���t�o�g�줣��C�Lñ����ҡj�Clchk_ddeliver
       2.�p�d���϶��W�L�@�W�t�o�g��h���ĵ�ܡi�d���϶���t�o�g�줣��C�L���ҡA�нT�{�d���϶��j�Clchk_ideliver
       3.�p�G��O�Ҧ~�׫h���ĵ�ܡi�d���϶���O�Ҧ~�פ���C�L���ҡA�нT�{�d���϶��j�Clchk_cardyear
       4.�p�t�o�g��~�׸���h��ܷs�³��X�p�ơClchk_iissuebranch
    */   
    lchk_cardyear = 0 ;
    lchk_ideliver = 0 ;
    lchk_ddeliver = 0 ;
    lchk_iissuebranch = 0 ;


    sprintf(sTmpBuf,
            "SELECT count(*) - sum(CASE WHEN ddeliver IS NULL THEN 1 ELSE 0 END) ,"
            "       count(distinct icardyear)  "
            "  FROM compulsory_card "
            " WHERE icard >= '%s' AND icard <= '%s' ",icard_begin,icard_end); 
    printf("sTmpBuf[%s]",sTmpBuf);
    $PREPARE comp_tmpzzz FROM   $sTmpBuf;
    $DECLARE card_cnt_cur CURSOR FOR comp_tmpzzz;
       $OPEN card_cnt_cur;
      $FETCH card_cnt_cur INTO $lchk_ddeliver,$lchk_cardyear;
    
        
    printf("lchk_ddeliver[%d]llchk_cardyear[%d]",lchk_ddeliver,lchk_cardyear);
    
    if (lchk_ddeliver == 0)
    {
        printf("�����|���t�o�g��\n");
    }
    else
    {
        /*
        �i��a�G1060821005-C5 
        �ӻ�H-car202�̷s�t�o�g��N�����޲z�H(compulsory_card.ideliver->ileader)
        �ӻ���-car202�̷s�t�o�g��N�����~�Z��줤��
        �t�o�g��-car202���̷s�t�o�g��N���򤤤�(compulsory_card.ideliver)
        */
        $SELECT first 1 a.ddeliver, a.ideliver,icardyear,a.dissue,a.iissue_branch,
                (select e.nchi_full from branch e where e.ibranch=a.iissue_branch),a.ioffice,a.iofficer,
                (select f.ileader from officer f where f.iofficer=a.ideliver),
                (select k.nname from officer f,officer k where f.iofficer=a.ideliver and f.ileader = k.iofficer),
                (select f.nname from officer f where f.iofficer=a.ideliver)
           INTO $sDdeliver,$sIdeliver,$icardyear,$dissue,$sIssue_branch,$issuebranch,
                $ioffice,$iofficer,$sIdeliver_lead,$nofficer,$sNdeliver
           FROM compulsory_card a
          WHERE a.icard >= $icard_begin
            AND a.icard <= $icard_end
            AND a.ddeliver is not null
          GROUP BY 1,2,3,4,5,6,7,8,9;  
       printf("sDdeliver[%s],sIdeliver[%s]\n,iofficer[%s]icardyear[%s],dissue[%s],sIssue_branch[%s]issuebranch[%s]\n",
                sDdeliver,sIdeliver,iofficer,icardyear,dissue,sIssue_branch,issuebranch);
        $SELECT count(distinct ideliver)        
           INTO $lchk_ideliver 
           FROM compulsory_card a
          WHERE a.icard >= $icard_begin
            AND a.icard <= $icard_end
            AND a.ddeliver is not null;  
        if( SQLCODE == SQLNOTFOUND)
        {
            lchk_ideliver = 0;
        }    
        $SELECT count(distinct iissue_branch) 
           INTO $lchk_iissuebranch
           FROM compulsory_card
          WHERE icardyear=$icardyear
            AND ideliver=$sIdeliver;
        if( SQLCODE == SQLNOTFOUND)
        {
            lchk_iissuebranch = 0;
        }            
        printf("lchk_iissuebranch[%d]\nchk_ideliver[%d]\n",lchk_iissuebranch,lchk_ideliver);
      
        printf("******** issuebranch[%s] dbname[%s]ioffice[%s]\n",issuebranch,FullDBName,ioffice);
    }
    
    avaisum=usedsum=cancelsum=losssum=expiresum=0;
    strcpy(icardyear,trim(icardyear));

    if(lchk_ideliver > 1)
    {
        printf("�d���϶���t�o�g�줣��C�L���ҡA�нT�{�d���϶�\n");
    }
    else
    {
        $DECLARE comp_cur_print CURSOR FOR
          SELECT fstatus INTO $fstatus
            FROM compulsory_card
           WHERE icardyear=$icardyear
             AND ideliver=$sIdeliver;
        $OPEN comp_cur_print;
        $FETCH comp_cur_print;
        while (SQLCODE !=SQLNOTFOUND)
        {
            if (strcmp(fstatus,"0")==0) avaisum+=1;
            if (strcmp(fstatus,"1")==0) usedsum+=1;
            if (strcmp(fstatus,"3")==0) cancelsum+=1;
            if (strcmp(fstatus,"4")==0) losssum+=1;
            if (strcmp(fstatus,"2")==0) expiresum+=1;
            if (strcmp(fstatus,"5")==0) avaisum+=1;
            if (strcmp(fstatus,"6")==0) avaisum+=1;
            if (strcmp(fstatus,"7")==0) avaisum+=1;
            $FETCH comp_cur_print;
        }
        $CLOSE comp_cur_print;
    }
    sum=avaisum+usedsum+cancelsum+losssum+expiresum;
    printf("sum[%l]\n",sum);
    cm_buf_init(ReplyBuf);
    cm_buf_res_msg();
    cm_buf_res_count();
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put("%l %l %l %l %s",lchk_ddeliver,lchk_ideliver,lchk_cardyear,lchk_iissuebranch,dissue);
    cm_buf_put("%s %s %s %s %s %s %s %l %l %l %l %l %l",
                 sIdeliver_lead,nofficer,ioffice,sIdeliver,sNdeliver,icardyear,CompanyName,avaisum,usedsum,
                 cancelsum,losssum,expiresum,sum);
    cm_buf_put("%s",issuebranch);
    count = 0 ;
    sum1 = 0;
    printf("==============================================================\n");
    $DECLARE cur_print CURSOR FOR
     SELECT min(icard),max(icard),icar_type,qperiod,count(*)
       INTO $icard_begin,$icard_end,$icar_type,$qperiod,$qcard
       FROM compulsory_card
      WHERE icardyear=$icardyear
        AND ideliver=$sIdeliver
        AND iofficer = $iofficer
        AND ioffice = $ioffice
        AND dissue=$dissue
        AND icard >= $icard_begin
        AND icard <= $icard_end
      GROUP BY icar_type,qperiod;
    $OPEN cur_print;
    $FETCH cur_print;  
    while (SQLCODE !=SQLNOTFOUND)
    {
        printf("icard_begin[%s] icard_end[%s] icar_type[%s]\n [%l][%l]\n",icard_begin,icard_end,icar_type,qperiod,qcard);
        count++;
        sum1+=qcard;
        cm_buf_put("%s %s %s %l %l",icard_begin,icard_end,icar_type,qperiod,qcard);
        $FETCH cur_print;
    }
    $CLOSE cur_print;
    
    if (count == 0)
    {
       $WHENEVER SQLERROR CONTINUE;
       
      /* return exitsub(reply,M_CA_NISSUED_CARD) ? M_CA_NISSUED_CARD : apiRC;*/
    }
 
    cm_buf_put_count(count);
    cm_buf_put("%l",sum1);

    printf("##### sum1[%ld]\n",sum1);

    $WHENEVER SQLERROR GOTO errexit;
    tmp_len = cm_buf_len(ReplyBuf);
    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    {
         $WHENEVER SQLERROR CONTINUE;
        
         return apiRC;
    }

    $WHENEVER SQLERROR GOTO errexit;
   
    return api_OKComplete;

errexit:
       MsgCode = SQLCODE;
       $WHENEVER SQLERROR CONTINUE;
       
       if (SQLCODE != 0) MsgCode = SQLCODE;
       return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
