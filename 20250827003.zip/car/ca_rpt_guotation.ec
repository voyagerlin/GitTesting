/* ****************************************************************************
 * Program ID: ca_rpt_guotation.ec
 * Function by: ca320m01s.ec
 * Author:   
 * Purpose: ������C�L
 * ****************************************************************************/
#include <malloc.h>

#include <api_xsrv.h>
#include "comdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "globdata.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "gls_array.h"
#include "gls_const.h"
#include "print.h"
#include <stdlib.h>
#include "safeclib.h"

$include "ply_ins_cover.h";
$include "var_length.h";

$include datetime.h;
$include decimal.h;

/* �����~�Ȥw�ɦ��u�f������ */
#define direct_disc_98    "(���O��w�ɦ�������O���O�O�u�f)"
#define direct_disc_note1 "     .�������椧�O�O�u�f�A�ȭ��ˬ������q������O�l�o�ɦ����u�f�C"

/* *** Global variables *** */
$int  minus_flag;
$char DBName[05],Listcount[02],nassured[41],fsex[2],nass_type[2],itag[10];
$char brand_name[20],brand[9],iissue_yy[4],iissue_mm[3],qpt[2],fpt[2];
$char dbgn1[11],dend1[11],dbgn2[11],dend2[11];
$char pmdg_acc[5],plia_acc[5],comp_class[2],premium1[8],premium2[8];
$char comp_frate[4],rate_code[4];
$char tot_prem[8],iofficer[11],sIcar_type[3],comp_acc[8],tmp_yyy[3];
$char ibig_branch[20], fax[14], address[41], itel[21], name[11],ileader[11];
$char sIins_type[3], iMdeduct[8], iQcoverage[2], sNins_type[31];
$long lMdeduct;
$int  qserial = 0;
$char birthday[11],last_num[21],fcomp_24[2];
$char sex_factor1[6],sex_factor2[6], sex_damage_factor[6];
$char bgnyy[4],bgnmm[3],bgndd[3],biryy[4],birmm[3],birdd[3];
$char fdiscount[2];
$long car_price;
$char car_price_c[12], iestimate[21];

$char iIns_type[6],Amount1[9],Amount2[9],Amount3[9],iDeduct[8],TotAmount[9];
$char iins_type[02],deduct[03],tmp_pt[9],insprem[9];
$double pdiscount;
$long mdiscount;
$long mins_amt56, daily_pay56;

$long coverage1_31, coverage2_31, coverage3_32;
char  flag_31_exist[3],flag_32_exist[3],flag_29_exist[3];
char  flag_11_exist[3];
char  sCoverage1[30],sCoverage2[30],sCoverage3[30];

int   add_mplace_01_flag;
int   add_mplace_11_flag;
$long qday;
$char deduct_30[11];

$long Tamt1[20],Tamt2[20],Tamt3[20],Ttot[20],Tins[20],Tded;
$long minjured = 0,mdeath = 0,mdamage = 0,premium = 0,dtoday;
$long Tdiscount,Tinsprem,Iinsprem = 0;
$char provision[5];
$char iquery_num[21];
$char iquery_num_damage[21];
$char iquery_num_c[21];
$char iassured[11], sPrintPdiscount[2];
$char sPrintDiscNote[2]; /* car9803242 �C�L�u�f�T�� */
$char sQcylinder[10];

$double pfactor1;
$double pfactor2;

double  mbus_rule, mbusiness;

$int age;
int  rc;

char     v_sMsg[512];
long     rtncode;
char     sColumn[21], sTable[21], sDbname[21];

int count;
static int max_cnt;
long  ins_31_multiple;
char  stmt_buf[4096];

long car320_body();
long drop_temp_table();
char *rtrim_a();
int IsFcomp24();
int IsFcomp51();
int IsFcomp55();
struct   PLY_INS_COVER *IfirstPlyInsCover = NULL, *IcurrPlyInsCover, *IlastPlyInsCover;
char isBound[2];

long ca_rpt_guotation()
{
    int   iRtnCode = 0;
    
    $char sTmt[1024], sTmpBuf[512];
    
    $WHENEVER SQLERROR GOTO errexit;
    
    $CREATE TEMP TABLE CAR320
    ( 
        iins_type    char(03),
        minjured     integer default 0,
        mdeath       integer default 0,
        mdamage      integer default 0,
        deduct       char(08),
        provision    char(05),
        premium      integer default 0,
        insprem      integer default 0,
        qday         integer default 0,
        pdiscount    decimal(6,2) default 0
    ) with no log;
    
    $CREATE TEMP TABLE CAR_48_35
    (
        iins_type   char(6),
        iins_scope  char(2),
        mdamage     integer default 0,
        premium     integer default 0,
        daily_pay   integer default 0
    )
    WITH NO LOG;

    if((iRtnCode=car320_body()) != M_CM_OK)
    {
       drop_temp_table();
       return iRtnCode;
    }

    #ifdef CA_CONS
    while (IfirstPlyInsCover != NULL)
    {                                /* free all allocated memory */
        IcurrPlyInsCover=IfirstPlyInsCover;
        IfirstPlyInsCover=IcurrPlyInsCover->next;
        free(IcurrPlyInsCover);
    }
    #endif
    
    return M_CM_OK;

errexit:
  printf("{ca_rpt_guotation}: SQLCODE=[%d] sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
  return SQLCODE;
    
} /* end ca_rpt_guotation */    
    
    
long car320_body()
{    
    $char stmt[1024],str[2],str1[2];
    $int  rows_48, rows_35, rows_56;
    int i,iRtnCode,x, j, iPlyInsCoverRows;
    $char  iins_type_1[6], iIins_scope[3];
    $long  ldamage_cover48,lpremium48, ldamage_cover35,lpremium35, ldaily_pay48, mpure_prem;
    double psex_age1, psex_age2, psex_age_damage;
    
    minus_flag = 0;
    cm_buf_get("%s %s %s %s %s %s %s %s %s %d",
                Listcount, nassured, fsex, nass_type, birthday, last_num, itag,
                brand_name, brand, &car_price);
                
    rfmtlong(car_price, "---,---,--&", car_price_c);
    strcpy(car_price_c, trim(car_price_c));

    cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
                dbgn2,dend2,dbgn1,dend1,iissue_yy,iissue_mm,qpt,fpt,pmdg_acc,plia_acc,comp_frate,comp_class,
                premium1,premium2,tot_prem,iofficer,sIcar_type,fcomp_24);

    cm_buf_get("%s %s %s ",iquery_num_c,iquery_num, iquery_num_damage);

    cm_buf_get("%s",iassured);

    cm_buf_get("%s", fdiscount);    /*** �������O ***/

    cm_buf_get("%l %l %l",&coverage1_31, &coverage2_31, &coverage3_32);
    rfmtlong(coverage1_31,"--,---,--&",sCoverage1);
    rfmtlong(coverage2_31,"--,---,--&",sCoverage2);
    rfmtlong(coverage3_32,"--,---,--&",sCoverage3);
    printf("[%s][%s][%s]\n",sCoverage1,sCoverage2,sCoverage3);

    count = atoi(Listcount);
       
    add_mplace_01_flag = 0;
    add_mplace_11_flag = 0;
    qday               = 0;
    Tdiscount          = 0;
    ins_31_multiple    = 0;

    strcpy(flag_11_exist,"N");
    strcpy(flag_29_exist,"N");
    strcpy(flag_31_exist,"N");
    strcpy(flag_32_exist,"N");

    strcpy(deduct_30,"");
    minus_flag = 0;

    #ifdef CA_CONS
    IcurrPlyInsCover=IfirstPlyInsCover=IlastPlyInsCover=NULL;    /* set init pointer to NULL */
    #endif

    for(i=0 ; i< count ; i++)
    {
       cm_buf_get("%s %l %l %l %l %s %l %l %e %l %l %l",
                   iIns_type,&Tamt1[i],&Tamt2[i],&Tamt3[i],&Tded,
                   provision,&Ttot[i],&Tinsprem,&pdiscount,&mdiscount,&qday,&mpure_prem);

       if( mpure_prem > Tinsprem)
           return M_CA_PREMIUM_ERROR;

       #ifdef CA_CONS
       cm_buf_get("%l ", &iPlyInsCoverRows);

       for (j=0; j<iPlyInsCoverRows; j++)
       {
           IcurrPlyInsCover=(struct PLY_INS_COVER *)malloc(sizeof(struct PLY_INS_COVER));

           if (IcurrPlyInsCover==NULL)
           {
               printf("malloc fail in struct PLY_INS_COVER allocation!\n");
           }

           if (IfirstPlyInsCover==NULL)
           {
               IfirstPlyInsCover=IcurrPlyInsCover;
           }
           else
           {
               IlastPlyInsCover->next=IcurrPlyInsCover;
           }
           IlastPlyInsCover=IcurrPlyInsCover;
           IcurrPlyInsCover->next=NULL;

           cm_buf_get("%s ", IcurrPlyInsCover->iins_type);
           cm_buf_get("%s ", IcurrPlyInsCover->cover_name);
           cm_buf_get("%l ", &(IcurrPlyInsCover->mcover));
           cm_buf_get("%l ", &(IcurrPlyInsCover->mcover_prem));
           cm_buf_get("%l ", &(IcurrPlyInsCover->mprem));
           cm_buf_get("%e ", &(IcurrPlyInsCover->mpure_prem));
           cm_buf_get("%s ", IcurrPlyInsCover->icover_type);
           cm_buf_get("%s ", IcurrPlyInsCover->iprem_cover_type);
           IcurrPlyInsCover->pextra_charge = 0;

           printf("IcurrPlyInsCover->iins_type    [%s]\n"
                  "IcurrPlyInsCover->cover_name   [%s]\n"
                  "IcurrPlyInsCover->icover_type  [%s]\n"
                  "IcurrPlyInsCover->iprem_cover_type  [%s]\n"
                  "IcurrPlyInsCover->mcover       [%d]\n"
                  "IcurrPlyInsCover->mcover_prem  [%d]\n"
                  "IcurrPlyInsCover->mprem        [%d]\n"
                  "IcurrPlyInsCover->mpure_prem   [%f]\n"
                  "IcurrPlyInsCover->pextra_charge[%f]\n",
                   IcurrPlyInsCover->iins_type,
                   IcurrPlyInsCover->cover_name,
                   IcurrPlyInsCover->icover_type,
                   IcurrPlyInsCover->iprem_cover_type,
                   IcurrPlyInsCover->mcover,
                   IcurrPlyInsCover->mcover_prem,
                   IcurrPlyInsCover->mprem,
                   IcurrPlyInsCover->mpure_prem,
                   IcurrPlyInsCover->pextra_charge );
           puts("");
       }

       #endif

       if (mdiscount < 0)
          minus_flag = 1;

       printf("Tot_premium[%ld],pdiscount[%f]\n",Ttot[i],pdiscount);
       /*
       mdiscount = (float)Ttot[i]*((float)(pdiscount)/100) + 0.5;
       */

       Tdiscount += mdiscount;
       
       if (((strcmp(trim(iIns_type),"01")==0) ||
            (strcmp(trim(iIns_type),"05")==0) ||
            (strcmp(trim(iIns_type),"08")==0) ||
            (strcmp(trim(iIns_type),"09")==0) ||
            (strcmp(trim(iIns_type),"85")==0) ||
            (strcmp(trim(iIns_type),"86")==0)) &&
           (qday != 0))
       {
           add_mplace_01_flag = 1;
       }

       if ((strcmp(trim(iIns_type),"11")==0) &&
           (qday != 0))
       {
           add_mplace_11_flag = 1;
       }

       if ((strcmp(trim(iIns_type),"15")==0) || (strcmp(trim(iIns_type),"16")==0) ||
            (strcmp(trim(iIns_type),"66")==0) || (strcmp(trim(iIns_type),"67")==0))
       {
           qday = (long)(Tamt3[i]/Tamt1[i]);
       }

       if (strcmp(trim(iIns_type),"31")==0 || strcmp(trim(iIns_type),"36")==0)
       {
           ins_31_multiple = (long)(Tamt3[i]/Tamt1[i]);
       }

       if (strcmp(trim(iIns_type),"11")==0)
       {
           strcpy(flag_11_exist,"Y");
       }

       if (strcmp(trim(iIns_type),"29")==0)
       {
           strcpy(flag_29_exist,"Y");
       }

       if (strcmp(trim(iIns_type),"31")==0 || strcmp(trim(iIns_type),"36")==0)
       {
           strcpy(flag_31_exist,"Y");
       }

       if (strcmp(trim(iIns_type),"32")==0 || strcmp(trim(iIns_type),"37")==0)
       {
           strcpy(flag_32_exist,"Y");
       }

       printf("iins_type[%s],add_mplace_01_flag[%d],add_mplace_11_flag[%d]\n",
               iIns_type,    add_mplace_01_flag,    add_mplace_11_flag);

       strcpy(iDeduct,ltoa(Tded));
        
       if (strcmp(trim(iIns_type),"30")==0)
       {
           strcpy(deduct_30,iDeduct);
       }

       $INSERT INTO CAR320
         (iins_type,  minjured,  mdeath,    mdamage,   deduct ,  
          provision,  premium , insprem   , qday, pdiscount)
       VALUES 
         ($iIns_type, $Tamt1[i], $Tamt2[i], $Tamt3[i], $iDeduct, 
          $provision, $Ttot[i], $Tinsprem , $qday, $pdiscount);
    }

    cm_buf_get ("%s", rate_code);   /* ���N�I�O�v�ͮĥN�� */
    
    cm_buf_get("%d",&rows_48);
    
    printf("rows_48 = [%d]\n", rows_48 );
    
    for(i=0;i< rows_48; i++ )
    {
    	cm_buf_get("%s %l %l %l",
                   iIins_scope,&ldamage_cover48, &ldaily_pay48, &lpremium48  );
    	
    	strcpy(iins_type_1, "48");
    	ldamage_cover48 *= 10000.0;
    	ldaily_pay48 *= 10000.0;
    	
    	$INSERT INTO CAR_48_35 VALUES
    	 ($iins_type_1, $iIins_scope, $ldamage_cover48, $lpremium48, $ldaily_pay48);
    }
    
    cm_buf_get("%d",&rows_35);
    
    printf("rows_35 = [%d]\n", rows_35 );
    
    for(i=0;i< rows_35; i++ )
    {
    	cm_buf_get("%s %l %l ",
                   iIins_scope,&ldamage_cover35,&lpremium35 );
    	
    	strcpy(iins_type_1, "35");
    	ldamage_cover35 *= 10000;
    	
    	$INSERT INTO CAR_48_35 VALUES
    	 ($iins_type_1, $iIins_scope, $ldamage_cover35, $lpremium35, 0);
    }
    
    cm_buf_get("%d %d %d", &rows_56, &mins_amt56, &daily_pay56);
    
    cm_buf_get("%s %s", iestimate, sPrintPdiscount );
    cm_buf_get("%e %e %e %e %e %s", &mbusiness, &mbus_rule, &psex_age2, &psex_age1, &psex_age_damage, isBound );
    cm_buf_get("%s %s", sPrintDiscNote, sQcylinder);

    $WHENEVER SQLERROR GOTO errexit;
    
    ibig_branch[0]='\0';
    fax[0]='\0';
    address[0]='\0';
    itel[0]='\0';
    ileader[0]='\0';
    name[0]='\0';
    comp_acc[0]='\0';
  
    /* �j��ߴګY�� */
    $SELECT pcomp_factor
       INTO $comp_acc
       FROM ca_comp_acc_factor
      WHERE qclass = $comp_class
        AND fcard_class = '1'
        AND drate = (select drate
                       from ca_rate_date
                      where icode = $comp_frate
                        and itable = 'ca_comp_acc_factor');
    if( SQLCODE == SQLNOTFOUND )
         comp_acc[0]='\0';

    /* �g��H�ԲӸ�� */

    $SELECT a.ibig_branch,a.ibig_office,a.nname,a.itel /*�g��H���q�ܡB�a� */
       INTO $ibig_branch, $fax, $address, $itel
       FROM ca_big_office a, sa_branch_type b, officer c
      WHERE a.ibig_comp = b.ibranch
        AND b.ibranch[1,4] = c.iquota[1,4]
        and b.ibranch[5,6] = '00'
        and a.fclass = '3'
        and c.iofficer = $iofficer;

    $SELECT ileader   /* ���ެO�_�O�O�N�B¾�ε��A����X�޲z�̪����s*/
       INTO $ileader  /* �ۤv�O�ۤv���޲z�H */
       FROM officer
      WHERE iofficer = $iofficer;

    $SELECT nname
       INTO $name
       FROM officer
      WHERE iofficer = $ileader;
           
    /* �ʧO�~�֫Y�� */
    if ( strcmp(nass_type,"1") == 0 || strcmp(nass_type,"3") == 0 )
    {
        /* ���N�ʧO�~�֫Y�� */
        if ((dbgn2[0] != ' ') && (dbgn2[0] != '\0'))
        {
             rfmtdouble(psex_age2,"#&.##",sex_factor2);
             rfmtdouble(psex_age_damage,"#&.##",sex_damage_factor);
        }
        else
        {
             strcpy(sex_factor2,"  ");
             strcpy(sex_damage_factor,"  ");
        }

        if ((dbgn1[0] != ' ') && (dbgn1[0] != '\0'))
             rfmtdouble(psex_age1,"#&.##",sex_factor1);
        else
             strcpy(sex_factor1,"  ");
    }
    else if ( strcmp(nass_type,"2") == 0 )
    {
        strcpy(sex_factor1,"  ");
        strcpy(sex_factor2,"  ");
        strcpy(sex_damage_factor,"  ");
    }

    if( (iRtnCode = car320_body1()) != M_CM_OK ) /* line 1-10 */
    {
        drop_temp_table();
        return iRtnCode;
    }
   
    if( (iRtnCode = car320_body2()) != M_CM_OK ) /* �I�ة���*/
    {
         drop_temp_table();
         return iRtnCode;
    }

    if ( (iRtnCode = car320_body3()) != M_CM_OK )
    {
         drop_temp_table();
         return iRtnCode;
    }

    return M_CM_OK;
    
errexit:
    printf("{ca320_body}: SQLCODE=[%d] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;

} /* end car320_body */


long drop_temp_table ()
{
    $char sTmt[1024];
    $int  rc;

    $WHENEVER SQLERROR GOTO errexit;

    sprintf_s(sTmt,sizeof sTmt,
      "DROP TABLE CAR320");
    printf("--------------------- stmt[%s]\n", sTmt);
    $PREPARE dtt_1 FROM $sTmt;
    $EXECUTE dtt_1;

    sprintf_s(sTmt,sizeof sTmt,
      "DROP TABLE CAR_48_35");
    printf("--------------------- stmt[%s]\n", sTmt);
    $PREPARE dtt_1 FROM $sTmt;
    $EXECUTE dtt_1;

    return M_CM_OK;

errexit:
    printf("{drop_temp_table}: SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
} /* drop_temp_table */

long car320_body1()
{
    $char str[26],yy[3],mm[2],stemp[47];
    int l;
    $char CompanyName[21];
   
    $WHENEVER SQLERROR GOTO errexit;
    
    strcpy(nassured,rtrim(nassured));

    if( strcmp(nass_type,"1") ==0 )
    {
        if( strcmp(fsex,"1") ==0 )
            sprintf_s(stemp,sizeof stemp,"%s%s",nassured," ����");  /* strcat(nassured," ����"); */  
        else 
            sprintf_s(stemp,sizeof stemp,"%s%s",nassured," �p�j"); /* strcat(nassured," �p�j"); */
    }
    else strcpy(stemp,rtrim(nassured));
    stemp[46]='\0';
 
    rc = getCompanyCName(CompanyName);
    if (rc < 0)
        return rc;

    rgu_put_body_string(1,trim(CompanyName),2);
    rgu_put_body(1);
    rgu_put_body(2);
    rgu_put_body_string(3,stemp,LEFT);
    rgu_put_body(3);
    rgu_put_body(4);
    
    if( strlen(rtrim(iestimate)) > 0 )
    {
        sprintf_s(stemp,sizeof stemp,"%s %s","�����渹�G", iestimate );
        rgu_put_body_string(5,stemp,LEFT);
    }
    else rgu_put_body_string(5," ",LEFT);
    
    if ( strlen(rtrim(last_num)) > 0 )
    {
        sprintf_s(stemp,sizeof stemp,"%s %s","�� �O ���G",last_num);
        rgu_put_body_string(5,stemp,LEFT);
    }
    else rgu_put_body_string(5," ",LEFT);
    
    rgu_put_body_string(5,car_price_c,LEFT);   /* ���m���� */

    strncpy(str,nassured,30);
    /*str[30]='\0';*/
    rgu_put_body_string(5,str,LEFT);  
    rgu_put_body_string(5,itag,LEFT);
    rgu_put_body(5);
    rgu_put_body_string(6,brand_name,LEFT);
    rgu_put_body_string(6,brand,LEFT);
    strcat(sQcylinder," cc");
    rgu_put_body_string(6,sQcylinder,LEFT);

    if (dbgn2[0] != ' ' && dbgn2[0] != '\0')
    {
         rgu_put_body_string(6,dbgn2,LEFT);
         rgu_put_body_string(6,dend2,LEFT);
    }
    else
    {
         rgu_put_body_string(6,dbgn1,LEFT);
         rgu_put_body_string(6,dend1,LEFT);
    }
    rgu_put_body(6);
    
    rgu_put_body_string(7,iissue_yy,RIGHT);
    rgu_put_body_string(7,iissue_mm,LEFT);
    if(strcmp(fpt,"P") == 0)
      sprintf_s(tmp_pt,sizeof tmp_pt,"%s �H",qpt);
    else sprintf_s(tmp_pt,sizeof tmp_pt,"%s ��",qpt); 
    printf("tmp_qt[%s]\n",tmp_pt);
    rgu_put_body_string(7,tmp_pt,LEFT);
    rgu_put_body(7);
    
    /* �O�v�ۥѤƤ��L���N�I�ʧO�~�֫Y�� */
    /* rgu_put_body_string(8,sex_damage_factor,LEFT); */
    /* rgu_put_body_string(8,sex_factor2,LEFT); */
    rgu_put_body_string(8,"",LEFT);
    rgu_put_body_string(8,rtrim(pmdg_acc),2);
    rgu_put_body_string(8,rtrim(plia_acc),2);

    /* �j���I */
    rgu_put_body_string(8,sex_factor1,LEFT);
    rgu_put_body_string(8,rtrim(comp_acc),2);
    rgu_put_body(8);

    if (strcmp(fdiscount,"Y")==0)
    {
        if (minus_flag == 0)
        {
           rgu_put_body_string( 9, "�O�I�O", RIGHT);
        }
        else
        {
           rgu_put_body_string( 9, " ", RIGHT);
        }
        rgu_put_body_string( 9, "�ꦬ�O�O", RIGHT);
    }
    else
    {
        rgu_put_body_string( 9, " ", RIGHT);
        rgu_put_body_string( 9, "�ꦬ�O�O", RIGHT);
    }

    if( sPrintPdiscount[0] == 'Y')
        rgu_put_body_string( 9, "�u�f�v", LEFT);
    else
        rgu_put_body_string( 9, " ", LEFT);

    rgu_put_body(9);
    rgu_put_body(10);
    
    max_cnt += 18;
    
    return M_CM_OK;
    
errexit:
  printf("{body1}: SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  return SQLCODE;    
}

long car320_body2()
{
    $char stmt[1024],str[20],sTmpBuf[40];
    $char tmp1Deduct[14],sNins_type[31],tmp2Deduct[14], edomain1[31];
    int   l,flag,j;
    $int  pre_qserial;
    $char deduct_18[11];
    $char start_18[11], iIins_scope[3], sIcover_type[ICOVER_TYPE];
    $long lmdamage = 0, lpremium = 0, ldaily_pay = 0;
    $long    insurance_cover_count;
   
    $WHENEVER SQLERROR GOTO errexit;
    
    /*  �Y�������A�L�X�W���O�I�O���else �u�L�X�ꦬ�O�O  */
    
    if ((strcmp(fdiscount,"Y") == 0) && (minus_flag == 0))
         flag = 1;
    else flag = 0;
        
    sprintf_s(stmt,sizeof stmt, "SELECT %s %s FROM %s %s WHERE %s %s ",
                  "a.iins_type,minjured,mdeath,mdamage,deduct,a.provision,premium,",
                  "insprem,b.qcoverage,b.qserial,b.nins_type,a.qday, a.pdiscount, b.edomain1 ",
                  " CAR320 a , ",
                  " insurance_type b ",
                  "a.iins_type = b.iins_type ",
                  "order by b.qserial, a.iins_type ");
                  
    $PREPARE CAcur FROM $stmt;
        
    printf("CAR320[%s]\n",stmt);
    $DECLARE Xcur1 CURSOR FOR CAcur;
    $OPEN Xcur1;
    pre_qserial=0;

/*
    IcurrPlyInsCover=IfirstPlyInsCover=IlastPlyInsCover=NULL;
    #ifdef CA_CONS
        strcpy( sDbname, "");
        strcpy( sTable, "est_ins_cover");
        strcpy( sColumn, "iestimate");
        IfirstPlyInsCover = get_ply_ins_cover( sDbname, sTable, sColumn, iestimate, &rtncode, v_sMsg);
        if( rtncode != M_CM_OK)
            return rtncode;
    #endif
*/
        
    while(1)
    {
           $FETCH Xcur1 INTO $sIins_type, $minjured, $mdeath, $mdamage,
                             $iMdeduct,  $provision, $premium, $Iinsprem ,
                             $iQcoverage, $qserial, $sNins_type, $qday, $pdiscount, $edomain1;
           
           if(SQLCODE == SQLNOTFOUND) break;

           insurance_cover_count = 0;

           $SELECT COUNT(*)
              INTO $insurance_cover_count
              FROM insurance_cover
             WHERE iins_type = $sIins_type;


           printf("[%s %d %d %d %s %d %d] \n",sIins_type,minjured,mdeath,mdamage,
                                              iMdeduct,premium,Iinsprem);
           if (pre_qserial!=0)
           {
               if (pre_qserial < 10 && qserial >= 10)
               {
                   rgu_put_body(99);         /* �C�L�ťզ� */
                   max_cnt ++;
               }
               if (pre_qserial >= 10 && pre_qserial < 20 && qserial >= 20)
               {
                   rgu_put_body(99);         /* �C�L�ťզ� */
                   max_cnt ++;
               }
               if (pre_qserial >= 20 && pre_qserial < 30 && qserial >= 30)
               {
                   rgu_put_body(99);         /* �C�L�ťզ� */
                   max_cnt ++;
               }
               if (pre_qserial >= 30 && pre_qserial < 40 && qserial >= 40)
               {
                   rgu_put_body(99);         /* �C�L�ťզ� */
                   max_cnt ++;
               }
           }
           pre_qserial=qserial;
  
           if(strcmp(sIins_type,"31")==0 || strcmp(sIins_type,"36")==0)    /***  31�I��  ***/    
           {
                if(strcmp(trim(provision),"H")==0)
                {
                   strcpy(sNins_type,trim(sNins_type));
                   strcat(sNins_type,"���w�Ұ���O��");
                }
                rgu_put_body_string(11,sNins_type,LEFT);
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body(11);
                
                rgu_put_body_string(11,"    �C�@�ӤH�ˮ`",LEFT);
                rfmtlong(minjured, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body(11);
                
                rgu_put_body_string(11,"    �C�@�ƬG�`�B",LEFT);
                rfmtlong(mdamage, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rgu_put_body_string(11,"     �L",LEFT);
                rgu_put_body_string(11," ");
                
                if ( flag == 1 )
                {
                   rfmtlong(premium,"-,---,--&", sTmpBuf);
                }
                else  strcpy(sTmpBuf, " ");
                
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rfmtlong(Iinsprem,"-,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                
                if( sPrintPdiscount[0] == 'Y')
                {
                    rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                    rgu_put_body_string(11,sTmpBuf,LEFT);
                }
                else
                    rgu_put_body_string(11," ");

                rgu_put_body(11);
                
                max_cnt += 3;
           }
           else if(strcmp(sIins_type,"32")==0 || strcmp(sIins_type,"37")==0)  /***  32�I��  ***/
           { 
                if(strcmp(trim(provision),"H")==0)
                {
                   strcpy(sNins_type,trim(sNins_type));
                   strcat(sNins_type,"���w�Ұ���O��");
                }
                rgu_put_body_string(11,sNins_type,LEFT);
                rfmtlong(mdamage, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                
                /* car9902082 32�I�إ[�J�ۭt�B */
                if (strcmp(sIins_type,"32") == 0)
                {
                     rc = print_deduct();
                     if (rc != M_CM_OK)
                        rgu_put_body_string(11," ",RIGHT);
                }
                else
                {
                     rgu_put_body_string(11,"     �L",LEFT);                     
                }
                rgu_put_body_string(11," ");
                
                if ( flag == 1 )
                {
                   rfmtlong(premium,"-,---,--&", sTmpBuf);
                }
                else  strcpy(sTmpBuf, " ");
                
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rfmtlong(Iinsprem,"-,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);

                if( sPrintPdiscount[0] == 'Y')
                {
                    rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                    rgu_put_body_string(11,sTmpBuf,LEFT);
                }
                else
                    rgu_put_body_string(11," ");

                rgu_put_body(11);
                
                max_cnt++;
           }
           else if((strcmp(sIins_type,"51")==0) || (strcmp(sIins_type,"52")==0) || 
                   (strcmp(sIins_type,"55")==0) ) /** 51�B52�I�� **/
           {    
                rgu_put_body_string(11,sNins_type,LEFT);
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body(11);
                
                if(strcmp(sIins_type,"55")==0)
                    rgu_put_body_string(11,"    �C�@�ӤH�������",LEFT);
                else
                    rgu_put_body_string(11,"    �C�@�ӤH���",LEFT);
                rfmtlong(minjured, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body(11);
                
                rgu_put_body_string(11,"    �C�@�ӤH���`",LEFT);
                rfmtlong(mdeath, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rgu_put_body_string(11,"     �L",LEFT);
                rgu_put_body_string(11," ");
                
                if ( flag == 1 )
                {
                   rfmtlong(premium,"-,---,--&", sTmpBuf);
                }
                else  strcpy(sTmpBuf, " ");
                
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rfmtlong(Iinsprem,"-,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);

                if( sPrintPdiscount[0] == 'Y')
                {
                    rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                    rgu_put_body_string(11,sTmpBuf,LEFT);
                }
                else
                    rgu_put_body_string(11," ");

                rgu_put_body(11);
                
                rgu_put_body_string(11,"    �C�@�ƬG�`�B",LEFT);
                rfmtlong(mdamage, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body(11);
                
                max_cnt += 4;
           }
           else if((strcmp(sIins_type,"57")==0) || (strcmp(sIins_type,"59")==0) || 
                   (strcmp(sIins_type,"60")==0) ) 
           {    
           	    /* car9801122 �T���ȹB�~�����I(57,59,60), add by Julia in 2009/01/19 */
                rgu_put_body_string(11,sNins_type,LEFT);
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body(11);
                
                rgu_put_body_string(11,"    �C�@�ӤH���`�δݼo",LEFT);
                rfmtlong(mdeath, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body(11);
                
                rgu_put_body_string(11,"    �C�@�N�~�ƬG�`�B",LEFT);
                rfmtlong(mdamage, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rgu_put_body_string(11,"     �L",LEFT);
                rgu_put_body_string(11," ");
                
                if ( flag == 1 )
                {
                   rfmtlong(premium,"-,---,--&", sTmpBuf);
                }
                else  strcpy(sTmpBuf, " ");
                
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rfmtlong(Iinsprem,"-,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                
                if( sPrintPdiscount[0] == 'Y')
                {
                    rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                    rgu_put_body_string(11,sTmpBuf,LEFT);
                }
                else
                    rgu_put_body_string(11," ");

                rgu_put_body(11);
                
                max_cnt += 3;
           }
           
           else if(strcmp(sIins_type, "01")==0 || strcmp(sIins_type, "05")==0 ||
                   strcmp(sIins_type, "08")==0 || strcmp(sIins_type, "85")==0 ||
                   strcmp(sIins_type, "86")==0 || strcmp(sIins_type, "23")==0)
           {
                if(strcmp(trim(provision),"H")==0)
                {
                   strcpy(sNins_type,trim(sNins_type));
                   strcat(sNins_type,"���w�Ұ���O��");
                }
                rgu_put_body_string(11,sNins_type,LEFT);
                rfmtlong(mdamage, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
        
                rc = print_deduct();
                if (rc != M_CM_OK)
                   rgu_put_body_string(11," ",RIGHT);

                /******
                rc = get_deduct_info(sIcar_type,sIins_type,iMdeduct,
                     tmp2Deduct,tmp1Deduct); 
                if (rc != M_CM_OK) strcpy(tmp1Deduct," ");
                if (isdigit(tmp2Deduct[0])!=0) 
                   rgu_put_body_string(11,tmp1Deduct,RIGHT);
                else
                {
                   l=strlen(trim(tmp1Deduct));
                   l=(12-l)/2;
                   strcpy(tmp2Deduct," ");
                   for(j=0;j<l;j++)
                       strcat(tmp2Deduct," ");
                   strcat(tmp2Deduct,trim(tmp1Deduct));
                   rgu_put_body_string(11,tmp2Deduct,LEFT);
                }
                strcpy(iMdeduct,rtrim(iMdeduct));
                        
                $SELECT prn_deduct INTO $tmp1Deduct
                  FROM ca_dmg_mdeduct
                 WHERE icar_type=$sIcar_type
                   AND ideduct=$iMdeduct;
                if (SQLCODE==SQLNOTFOUND) strcpy(tmp1Deduct," ");
               
                if (strcmp(iMdeduct,"0") == 0)
                    rgu_put_body_string(11,"    �L",LEFT);
                else if((strlen(trim(tmp1Deduct))) == 0)
                    {
                    lMdeduct=atoi(iMdeduct);
                    rfmtlong(lMdeduct, "----,--&",sTmpBuf);
                    rgu_put_body_string(11,sTmpBuf,RIGHT);
                    }
                else rgu_put_body_string(11,tmp1Deduct,LEFT);
                *******/
               
                if (qday > 0)
                {
                    rgu_put_body_string(11,"(�[��)",RIGHT);
                }
                else
                {
                    rgu_put_body_string(11," " ,RIGHT);
                }

                if ( flag == 1 )
                {
                    rfmtlong(premium,"-,---,--&", sTmpBuf);
                }
                else  strcpy(sTmpBuf, " ");
                
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                
                rfmtlong(Iinsprem,"-,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                
                if( sPrintPdiscount[0] == 'Y')
                {
                    rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                    rgu_put_body_string(11,sTmpBuf,LEFT);
                }
                else
                    rgu_put_body_string(11," ");

                rgu_put_body(11);
                
                max_cnt++;
                                             
                if (strcmp(sIins_type,"85") == 0)
                {              	
                	 rgu_put_body_string(11,"    �������l�֭p���v���B",LEFT);
                   rfmtlong(minjured, "-,---,---,--&", sTmpBuf);
                   rgu_put_body_string(11,sTmpBuf,RIGHT);
                   rgu_put_body_string(11," ");
                   rgu_put_body_string(11," ");
                   rgu_put_body_string(11," ");
                   rgu_put_body_string(11," ");
                   rgu_put_body_string(11," ");
                   rgu_put_body(11);
                	 max_cnt++;
                }
           }
           /* �s�W71�I��(�f���B�e�H�d���I)�P�_ Modified by Julia Han in 2007/07/23 */
           else if (strcmp(sIins_type, "09")==0 || strcmp(sIins_type, "71")==0 || strcmp(sIins_type, "72")==0) 
           {
                if(strcmp(trim(provision),"H")==0)
                {
                   strcpy(sNins_type,trim(sNins_type));
                   strcat(sNins_type,"���w�Ұ���O��");
                }
                rgu_put_body_string(11,sNins_type,LEFT);
                rfmtlong(mdamage, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                /* rgu_put_body_string(11,"    �L",LEFT); */

                rc = print_deduct();
                if (rc != M_CM_OK)
                   rgu_put_body_string(11," ",RIGHT);
               
                /******
                rc = get_deduct_info(sIcar_type,sIins_type,iMdeduct,
                     tmp2Deduct,tmp1Deduct); 
                if (rc != M_CM_OK) strcpy(tmp1Deduct," ");
                if (isdigit(tmp2Deduct[0])!=0)
                   rgu_put_body_string(11,tmp1Deduct,RIGHT);
                else
                {
                   l=strlen(trim(tmp1Deduct));
                   l=(12-l)/2;
                   strcpy(tmp2Deduct," ");
                   for(j=0;j<l;j++)
                       strcat(tmp2Deduct," ");
                   strcat(tmp2Deduct,trim(tmp1Deduct));
                   rgu_put_body_string(11,tmp2Deduct,LEFT);
                }

               strcpy(iMdeduct,rtrim(iMdeduct));

               $SELECT prn_deduct INTO $tmp1Deduct
                  FROM ca_dmg_mdeduct
                 WHERE icar_type=$sIcar_type
                   AND ideduct=$iMdeduct;
                if (SQLCODE==SQLNOTFOUND) strcpy(tmp1Deduct," ");

               if (strcmp(iMdeduct,"0") == 0)
                   rgu_put_body_string(11,"    �L",LEFT);
               else if((strlen(trim(tmp1Deduct))) == 0)
                    {
                    lMdeduct=atoi(iMdeduct);
                    rfmtlong(lMdeduct, "-,---,--&",sTmpBuf);
                    rgu_put_body_string(11,sTmpBuf,RIGHT);
                    }
               else rgu_put_body_string(11,tmp1Deduct,LEFT);
                **********/
                
                if (qday > 0)
                {
                    rgu_put_body_string(11,"(�[��)",RIGHT);
                }
                else
                {
                    rgu_put_body_string(11," ");
                }

                if ( flag == 1 )
                {
                   rfmtlong(premium,"-,---,--&", sTmpBuf);
                }
                else  strcpy(sTmpBuf, " ");
                
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rfmtlong(Iinsprem,"-,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                
                if( sPrintPdiscount[0] == 'Y')
                {
                    rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                    rgu_put_body_string(11,sTmpBuf,LEFT);
                }
                else
                    rgu_put_body_string(11," ");

                rgu_put_body(11); 
                
                max_cnt++;                
           }
           else if (strcmp(sIins_type, "11")==0 || 
                    strcmp(sIins_type, "28")==0) /* car_9611281 ���B�s�t�� */
           {
                rgu_put_body_string(11,sNins_type,LEFT);
                rfmtlong(mdamage, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);

                if(strcmp(rtrim(iMdeduct), "10")==0)
                   rgu_put_body_string(11,"     10%",LEFT);
                else if(strcmp(rtrim(iMdeduct), "20")==0 )
                   rgu_put_body_string(11,"     20%",LEFT);
                else rgu_put_body_string(11,"     �L",LEFT);
                
                if (qday > 0)
                {
                    rgu_put_body_string(11,"(�[��)",RIGHT);
                }
                else
                {
                    rgu_put_body_string(11," ");
                }

                if ( flag == 1 )
                {
                   rfmtlong(premium,"-,---,--&", sTmpBuf);
                }
                else  strcpy(sTmpBuf, " ");
                
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rfmtlong(Iinsprem,"-,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                
                if( sPrintPdiscount[0] == 'Y')
                {
                    rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                    rgu_put_body_string(11,sTmpBuf,LEFT);
                }
                else
                    rgu_put_body_string(11," ");

                rgu_put_body(11);
                max_cnt++;
           }
           else if (strcmp(sIins_type, "18")==0)
           {
                rgu_put_body_string(28,sNins_type,LEFT);
                rfmtlong(mdamage, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(28,sTmpBuf,RIGHT);

                strncpy(deduct_18,iMdeduct+2,2);
                deduct_18[2] = '\0';
                strcpy(deduct_18,trim(deduct_18));

                strncpy(start_18,iMdeduct,2);
                start_18[2]  = '\0';
                strcpy(start_18,trim(start_18));

                strcpy(sTmpBuf,"     ");
                if (strcmp(deduct_18,"0") == 0)
                {
                   strcat(sTmpBuf,"�L");
                   strcat(sTmpBuf," ");
                }
                else
                {
                   strcat(sTmpBuf,deduct_18);
                   strcat(sTmpBuf,"%");
                }
                strcat(sTmpBuf,"(�_���B");
                strcat(sTmpBuf,start_18);
                strcat(sTmpBuf,"%)");

                rgu_put_body_string(28,sTmpBuf,LEFT);

                if ( flag == 1 )
                {
                   rfmtlong(premium,"-,---,--&", sTmpBuf);
                }
                else  strcpy(sTmpBuf, " ");
                
                rgu_put_body_string(28,sTmpBuf,RIGHT);
                rfmtlong(Iinsprem,"-,---,--&", sTmpBuf);
                rgu_put_body_string(28,sTmpBuf,RIGHT);
                
                if( sPrintPdiscount[0] == 'Y')
                {
                    rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                    rgu_put_body_string(28,sTmpBuf,LEFT);
                }
                else
                    rgu_put_body_string(28," ");

                rgu_put_body(28);
                max_cnt++;
                max_cnt++;
           }
           else if ((strcmp(sIins_type, "62")==0) ||
                    (strcmp(sIins_type, "63")==0) ||
                    (strcmp(sIins_type, "64")==0))
           {
                rgu_put_body_string(28,sNins_type,LEFT);
                rfmtlong(mdamage, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(28,sTmpBuf,RIGHT);

                strcpy(sTmpBuf,"    ���ݮɶ�");
                strcat(sTmpBuf,trim(iMdeduct));
                strcat(sTmpBuf,"�p��");
                rgu_put_body_string(28,sTmpBuf,1);
                if ( flag == 1 )
                {
                   rfmtlong(premium,"-,---,--&", sTmpBuf);
                }
                else  strcpy(sTmpBuf, " ");
                
                rgu_put_body_string(28,sTmpBuf,RIGHT);
                rfmtlong(Iinsprem,"-,---,--&", sTmpBuf);
                rgu_put_body_string(28,sTmpBuf,RIGHT);
                
                if( sPrintPdiscount[0] == 'Y')
                {
                    rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                    rgu_put_body_string(28,sTmpBuf,LEFT);
                }
                else
                    rgu_put_body_string(28," ");

                rgu_put_body(28);
                max_cnt++;
                max_cnt++;
           }
           else if( strcmp(sIins_type, "24") ==0 )
           {
                rgu_put_body_string(20,sNins_type,LEFT);
                rfmtlong(mdamage, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(20,sTmpBuf,RIGHT);
                rgu_put_body_string(20,"     �L",LEFT);
                
                if((strcmp(fcomp_24, "1") == 0 ) && (atoi(premium1) > 0))
                {
                     rgu_put_body_string(20,"(�[�j)",RIGHT);
                }
                else
                {
                     rgu_put_body_string(20," ");
                }

                if ( flag == 1 )
                {
                   rfmtlong(premium,"-,---,--&", sTmpBuf);
                }
                else  strcpy(sTmpBuf, " ");
                
                rgu_put_body_string(20,sTmpBuf,RIGHT);
                rfmtlong(Iinsprem,"-,---,--&", sTmpBuf);
                rgu_put_body_string(20,sTmpBuf,RIGHT);
                
                if( sPrintPdiscount[0] == 'Y')
                {
                    rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                    rgu_put_body_string(20,sTmpBuf,LEFT);
                }
                else
                    rgu_put_body_string(20," ");

                rgu_put_body(20); 
                
                max_cnt++;

                if (strcmp(trim(provision),"H")==0)
                {
                   rgu_put_body_string(20,"���w�Ұ���O��",LEFT);
                   rgu_put_body_string(20," ",1);
                   rgu_put_body_string(20," ",1);
                   rgu_put_body_string(20," ",1);
                   rgu_put_body_string(20," ",1);
                   rgu_put_body_string(20," ",1);
                   rgu_put_body_string(20," ",1);
                   rgu_put_body(20);
                   max_cnt++;
                }

                rgu_put_body(21);
                max_cnt++;
                
           }
           else if ((strcmp(sIins_type, "15") == 0) || (strcmp(sIins_type, "16") == 0) ||
                    (strcmp(sIins_type, "66") == 0) || (strcmp(sIins_type, "67") == 0))
           {
                rgu_put_body_string(11,sNins_type,LEFT);

                rfmtlong(qday,"--&", sTmpBuf);
                strcat(sTmpBuf,"��");
                rgu_put_body_string(11,sTmpBuf,RIGHT); 
                /*****************************************
                rfmtlong(mdamage, "--,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                *****************************************/

                rgu_put_body_string(11,"     �L",LEFT);
                rgu_put_body_string(11," "); 
                
                if ( flag == 1 )
                {
                   rfmtlong(premium,"-,---,--&", sTmpBuf);
                }
                else  strcpy(sTmpBuf, " ");
                
                rgu_put_body_string(11,sTmpBuf,RIGHT);
             
                rfmtlong(Iinsprem,"-,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                
                if( sPrintPdiscount[0] == 'Y')
                {
                    rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                    rgu_put_body_string(11,sTmpBuf,LEFT);
                }
                else
                    rgu_put_body_string(11," ");

                rgu_put_body(11); 
                
                max_cnt++;
           }
           else if (strcmp(sIins_type, "02") == 0)
           {

              rgu_put_body_string(20,sNins_type,LEFT);
              rfmtlong(mdamage, "-,---,---,--&", sTmpBuf);
              rgu_put_body_string(20,sTmpBuf,RIGHT);
              rgu_put_body_string(20,"     �L",LEFT);
              rgu_put_body_string(20," ");   /* �N�B���Ѽ� */

              if ( flag == 1 )
              {
                  rfmtlong(premium,"-,---,--&", sTmpBuf);
              }
              else  strcpy(sTmpBuf, " ");

              rgu_put_body_string(20,sTmpBuf,RIGHT);
              rfmtlong(Iinsprem,"-,---,--&", sTmpBuf);
              rgu_put_body_string(20,sTmpBuf,RIGHT);
                
                if( sPrintPdiscount[0] == 'Y')
                {
                    rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                    rgu_put_body_string(20,sTmpBuf,LEFT);
                }
                else
                    rgu_put_body_string(20," ");

              rgu_put_body(20);
              max_cnt++;

              if (strcmp(trim(provision),"H")==0)
              {
                 rgu_put_body_string(20,"���w�Ұ���O��",LEFT);
                 rgu_put_body_string(20," ",1);
                 rgu_put_body_string(20," ",1);
                 rgu_put_body_string(20," ",1);
                 rgu_put_body_string(20," ",1);
                 rgu_put_body_string(20," ",1);
                 rgu_put_body_string(20," ",1);
                 rgu_put_body(20);
                 max_cnt++;
              }

              rgu_put_body(21);
              max_cnt++;

           }
           else if (strcmp(sIins_type, "10") == 0)
           {
              if(strcmp(trim(provision),"H")==0)
              {
                 strcpy(sNins_type,trim(sNins_type));
                 strcat(sNins_type,"���w�Ұ���O��");
              }
              rgu_put_body_string(20,sNins_type,LEFT);
              strcpy(sTmpBuf,"�P�����I");
              rgu_put_body_string(20,sTmpBuf,RIGHT);
              rgu_put_body_string(20,sTmpBuf,RIGHT);
              rgu_put_body_string(20," ");   /* �N�B���Ѽ� */

              if ( flag == 1 )
              {
                  rfmtlong(premium,"-,---,--&", sTmpBuf);
              }
              else  strcpy(sTmpBuf, " ");

              rgu_put_body_string(20,sTmpBuf,RIGHT);
              rfmtlong(Iinsprem,"-,---,--&", sTmpBuf);
              rgu_put_body_string(20,sTmpBuf,RIGHT);

                if( sPrintPdiscount[0] == 'Y')
                {
                    rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                    rgu_put_body_string(20,sTmpBuf,LEFT);
                }
                else
                    rgu_put_body_string(20," ");

              rgu_put_body(20);
              max_cnt++;

              rgu_put_body(21);
              max_cnt++;

           }
           else if (strcmp(sIins_type, "35") == 0)
           {
              $DECLARE get_35 CURSOR FOR  
                SELECT iins_scope, SUM(mdamage), SUM(premium)
                  INTO $iIins_scope, $lmdamage, $lpremium
                  FROM CAR_48_35
                 WHERE iins_type = '35'
                 GROUP BY 1;
              $OPEN get_35;
              while(1)
              {
              	  $FETCH get_35;
              	  if(SQLCODE == SQLNOTFOUND) break;
              	  
              	  if( iIins_scope[0] == '1' )
              	      rgu_put_body_string(11,"�a�x���������d���I�O�W��",LEFT);
              	  else
              	      rgu_put_body_string(11,"�a�x���������d���I�a�x��",LEFT);
              	  
              	  rfmtlong(lmdamage, "-,---,---,--&", sTmpBuf);
                  rgu_put_body_string(11,sTmpBuf,RIGHT);
              	  rgu_put_body_string(11,"     �L",LEFT);
                  rgu_put_body_string(11," ");
                  rgu_put_body_string(11," ");
                  rfmtlong(lpremium,"-,---,--&", sTmpBuf);
                  rgu_put_body_string(11,sTmpBuf,RIGHT);

                  if( sPrintPdiscount[0] == 'Y')
                  {
                      rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                      rgu_put_body_string(11,sTmpBuf,LEFT);
                  }
                  else
                      rgu_put_body_string(11," ");

                  rgu_put_body(11);
                  max_cnt++;
              }
              $CLOSE get_35;
              $FREE  get_35;
           }
           else if (strcmp(sIins_type, "48") == 0)
           {
              $DECLARE get_48 CURSOR FOR  
                SELECT iins_scope, SUM(mdamage), SUM(premium), SUM(daily_pay)
                  INTO $iIins_scope, $lmdamage, $lpremium, $ldaily_pay
                  FROM CAR_48_35
                 WHERE iins_type = '48'
                GROUP BY 1;
              $OPEN get_48;
              while(1)
              {
              	  $FETCH get_48;
              	  if(SQLCODE == SQLNOTFOUND) break;
              	  
              	  if( iIins_scope[0] == '1' )
              	      rgu_put_body_string(11,"��@������q�ƬG�r�p�ˮ`�I",LEFT);
              	  else
              	      rgu_put_body_string(11,"��@������q�ƬG�r�p�ˮ`�I",LEFT);
              	  
              	  rfmtlong(lmdamage, "-,---,---,--&", sTmpBuf);
                  rgu_put_body_string(11,sTmpBuf,RIGHT);
              	  rgu_put_body_string(11,"     �L",LEFT);
                  rgu_put_body_string(11," ");
                  rgu_put_body_string(11," ");
                  
                  if( iIins_scope[0] == '1' )
                  {
                      rfmtlong(lpremium,"-,---,--&", sTmpBuf);
                      rgu_put_body_string(11,sTmpBuf,RIGHT);
                      if( sPrintPdiscount[0] == 'Y')
                      {
                          rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                          rgu_put_body_string(11,sTmpBuf,LEFT);
                      }
                      else
                          rgu_put_body_string(11," ");
                  }
                  else
                  {
                      rgu_put_body_string(11," ");
                      rgu_put_body_string(11," ");
                  }

                  rgu_put_body(11);
                  max_cnt++;
                  
                  if( iIins_scope[0] == '2' )
                  {
                      rgu_put_body_string(11,"                  �ˮ`����",LEFT);
                      rfmtlong(ldaily_pay, "---,---,--&", sTmpBuf);
                      rgu_put_body_string(11,sTmpBuf,RIGHT);
              	      rgu_put_body_string(11," ");
                      rgu_put_body_string(11," ");
                      rgu_put_body_string(11," ");
                      rfmtlong(lpremium,"-,---,--&", sTmpBuf);
                      rgu_put_body_string(11,sTmpBuf,RIGHT);

                      if( sPrintPdiscount[0] == 'Y')
                      {
                          rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                          rgu_put_body_string(11,sTmpBuf,LEFT);
                      }
                      else
                          rgu_put_body_string(11," ");

                      rgu_put_body(11);
                      max_cnt++;
                  }
                  
                  
              }
              $CLOSE get_48;
              $FREE  get_48;
           }
           else if (strcmp(sIins_type, "56") == 0)
           {

              rgu_put_body_string(11,"�r�p�H�ˮ`�O�I���`�O�I��",LEFT);
              rfmtlong(mdamage, "-,---,---,--&", sTmpBuf);
              rgu_put_body_string(11,sTmpBuf,RIGHT);
              rgu_put_body_string(11,"     �L",LEFT);
              rgu_put_body_string(11," ");   /* �N�B���Ѽ� */

              if ( flag == 1 )
              {
                  rfmtlong(premium,"-,---,--&", sTmpBuf);
              }
              else  strcpy(sTmpBuf, " ");

              rgu_put_body_string(11,sTmpBuf,RIGHT);
              rfmtlong(Iinsprem,"-,---,--&", sTmpBuf);
              rgu_put_body_string(11,sTmpBuf,RIGHT);

              if( sPrintPdiscount[0] == 'Y')
              {
                  rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                  rgu_put_body_string(11,sTmpBuf,LEFT);
              }
              else
                  rgu_put_body_string(11," ");

              rgu_put_body(11);
              max_cnt++;

              rgu_put_body_string(11,"              �������B",LEFT);
              rfmtlong(daily_pay56, "---,--&", sTmpBuf);
              rgu_put_body_string(11,sTmpBuf,RIGHT);
              rgu_put_body_string(11," ",1);
              rgu_put_body_string(11," ",1);
              rgu_put_body_string(11," ",1);
              rgu_put_body_string(11," ",1);
              rgu_put_body_string(11," ",1);
              rgu_put_body(11);
              max_cnt++;
              
           }
           else if (strcmp(sIins_type, "50") == 0)
           {
              strcpy( sNins_type, trim(sNins_type));
              strcpy( edomain1, trim(edomain1));
              strcat( sNins_type, edomain1);
              printf("sNins_type[%s]\n", sNins_type);
              rgu_put_body_string(11,sNins_type,LEFT);
              rgu_put_body_string(11," ",1);
              rgu_put_body_string(11," ",1);
              rgu_put_body_string(11," ",1);
              rgu_put_body_string(11," ",1);
              rgu_put_body_string(11," ",1);
              rgu_put_body(11);
              max_cnt++;

              rgu_put_body_string(11,"              ���`�δݼo�O�I��",LEFT);
              rfmtlong( mdeath, "-,---,---,--&", sTmpBuf);
              rgu_put_body_string(11,sTmpBuf,RIGHT);
              rgu_put_body_string(11,"     �L",LEFT);
              rgu_put_body_string(11," ");   /* �N�B���Ѽ� */

              if ( flag == 1 )
              {
                  rfmtlong(premium,"-,---,--&", sTmpBuf);
              }
              else  strcpy(sTmpBuf, " ");

              rgu_put_body_string(11,sTmpBuf,RIGHT);
              rfmtlong(Iinsprem,"-,---,--&", sTmpBuf);
              rgu_put_body_string(11,sTmpBuf,RIGHT);

              if( sPrintPdiscount[0] == 'Y')
              {
                  rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                  rgu_put_body_string(11,sTmpBuf,LEFT);
              }
              else
                  rgu_put_body_string(11," ");

              rgu_put_body(11);
              max_cnt++;

              rgu_put_body_string(11,"              �ˮ`�����O�I��",LEFT);
              rfmtlong( minjured, "-,---,---,--&", sTmpBuf);
              rgu_put_body_string(11,sTmpBuf,RIGHT);
              rgu_put_body_string(11," ",1);
              rgu_put_body_string(11," ",1);
              rgu_put_body_string(11," ",1);
              rgu_put_body_string(11," ",1);
              rgu_put_body_string(11," ",1);
              rgu_put_body(11);
              max_cnt++;
              
           }
           else if( insurance_cover_count != 0) 
           {
               rgu_put_body_string(11,sNins_type,LEFT);
               rgu_put_body_string(11," ");
               rgu_put_body_string(11," ");
               rgu_put_body_string(11," ");
               rgu_put_body_string(11," ");
               rgu_put_body_string(11," ");
               rgu_put_body_string(11," ");
               rgu_put_body(11);
                
               IcurrPlyInsCover = IfirstPlyInsCover;
               while( IcurrPlyInsCover)
               {
                   if (strncmp(sIins_type, IcurrPlyInsCover->iins_type, 2) == 0)
                   {

                       strcpy( sIcover_type, IcurrPlyInsCover->icover_type);
                       $SELECT print_name
                          INTO $sNins_type
                          FROM insurance_cover
                         WHERE iins_type = $sIins_type
                           AND icover_type = $sIcover_type; 

                       sprintf_s( sNins_type,sizeof sNins_type, "    %s", trim( sNins_type));
                       rgu_put_body_string(11, sNins_type, LEFT);
                       printf("sNins_type[%s]\n", sNins_type);
                       rfmtlong( IcurrPlyInsCover->mcover, "---,---,--&", sTmpBuf);
                       rgu_put_body_string(11,sTmpBuf,RIGHT);
                       rgu_put_body_string(11," ");
                       rgu_put_body_string(11," ");
                  
                       if (strncmp( IcurrPlyInsCover->icover_type, "004", 3) == 0)
                       {    if ( flag == 1 )
                            {
                                rfmtlong(premium,"-,---,--&", sTmpBuf);
                            }
                            else  strcpy(sTmpBuf, " ");
                
                            rgu_put_body_string(11,sTmpBuf,RIGHT);
                            rfmtlong(Iinsprem,"-,---,--&", sTmpBuf);
                            rgu_put_body_string(11,sTmpBuf,RIGHT);

                            if( sPrintPdiscount[0] == 'Y')
                            {
                                rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                                rgu_put_body_string(11,sTmpBuf,LEFT);
                            }
                            else
                                rgu_put_body_string(11," ");
                       }
                       else
                       {
                           strcpy( sTmpBuf, "");
                           rgu_put_body_string(11,sTmpBuf,RIGHT);
                           rgu_put_body_string(11,sTmpBuf,RIGHT);
                           rgu_put_body_string(11,sTmpBuf,RIGHT);
                       }

                       rgu_put_body(11);
                   }
                   IcurrPlyInsCover = IcurrPlyInsCover->next;
               }
           }
           else if(iQcoverage == 3)
           {
                sprintf_s(sTmpBuf,sizeof sTmpBuf, "%s%s", sNins_type, "  ���");
                rgu_put_body_string(11,sNins_type,LEFT);
                rfmtlong(minjured, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body(11);
                
                rgu_put_body_string(11,"            ���`",LEFT);
                rfmtlong(mdeath, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body(11);
 
                rgu_put_body_string(11,"            �`�B",LEFT);
                rfmtlong(mdamage, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rgu_put_body_string(11,"     �L",LEFT);
                rgu_put_body_string(11," ");
                
                if ( flag == 1 )
                {
                   rfmtlong(premium,"-,---,--&", sTmpBuf);
                }
                else  strcpy(sTmpBuf, " ");
                
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rfmtlong(Iinsprem,"-,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);

                if( sPrintPdiscount[0] == 'Y')
                {
                    rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                    rgu_put_body_string(11,sTmpBuf,LEFT);
                }
                else
                    rgu_put_body_string(11," ");

                rgu_put_body(11);
                
                max_cnt+= 3;
           } 
           else if(iQcoverage == 2)
           {
                sprintf_s(sTmpBuf,sizeof sTmpBuf, "%s%s", sNins_type, "  ���");
                rgu_put_body_string(11,sNins_type,LEFT);
                rfmtlong(minjured, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body_string(11," ");
                rgu_put_body(11);
                
                rgu_put_body_string(11,"            �`�B",LEFT);
                rfmtlong(mdamage, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rgu_put_body_string(11,"     �L",LEFT);
                rgu_put_body_string(11," ");
                
                if ( flag == 1 )
                {
                   rfmtlong(premium,"-,---,--&", sTmpBuf);
                }
                else  strcpy(sTmpBuf, " ");
                
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rfmtlong(Iinsprem,"-,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);

                if( sPrintPdiscount[0] == 'Y')
                {
                    rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                    rgu_put_body_string(11,sTmpBuf,LEFT);
                }
                else
                    rgu_put_body_string(11," ");

                rgu_put_body(11);
                
                max_cnt+= 2;
           }  
           else
           { 
                if((strcmp(sIins_type, "03") == 0) && (strcmp(trim(provision),"H")==0))
                {
                   strcpy(sNins_type,trim(sNins_type));
                   strcat(sNins_type,"���w�Ұ���O��");
                }
                
                if ((strncmp(sIins_type,"30",2) == 0) && (iMdeduct[0] == '3'))
                {
                   rgu_put_body_string(11,"�ĤT�H�d���I�W�B�d�����[����",1);  
                }
                else
                {
                   rgu_put_body_string(11,sNins_type,LEFT);
                }
                rfmtlong(mdamage, "-,---,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rgu_put_body_string(11,"     �L",LEFT);
                rgu_put_body_string(11," ");   /* �N�B���Ѽ� */
                
                if ( flag == 1 )
                {
                   rfmtlong(premium,"-,---,--&", sTmpBuf);
                }
                else  strcpy(sTmpBuf, " ");
                
                rgu_put_body_string(11,sTmpBuf,RIGHT);
                rfmtlong(Iinsprem,"-,---,--&", sTmpBuf);
                rgu_put_body_string(11,sTmpBuf,RIGHT);

                if( sPrintPdiscount[0] == 'Y')
                {
                    rfmtdouble( pdiscount,"#&.##", sTmpBuf);
                    rgu_put_body_string(11,sTmpBuf,LEFT);
                }
                else
                    rgu_put_body_string(11," ");

                rgu_put_body(11); 
                max_cnt++;

                if((strcmp(sIins_type,"02")== 0) && (strcmp(trim(provision),"H")==0))
                {
                   strcpy(sNins_type,"���w�Ұ���O��");
                   rgu_put_body_string(11,sNins_type,RIGHT);
                   rgu_put_body_string(11," ",RIGHT);
                   rgu_put_body_string(11," ",RIGHT);
                   rgu_put_body_string(11," ",RIGHT);
                   rgu_put_body_string(11," ",RIGHT);
                   rgu_put_body_string(11," ",RIGHT);
                   rgu_put_body_string(11," ",RIGHT);
                   rgu_put_body(11);
                   max_cnt++; 
                }
                
           }  
    } /* end while */
    $CLOSE Xcur1;
    $FREE Xcur1;

    return M_CM_OK;
    
errexit:
  printf("{body2}: SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  return SQLCODE;
}

long car320_body3()
{
    $char str[20],sTmpBuf[20],dnow[17];
    $char dnow_yy[3],dnow_mm[3],dnow_dd[3],dnow_hh[6];
    int rc;
    $long pre_tmp, premium_tot;
    $char tmpString[200];
    $long iseq;
    $long iseq_a;
    $char iseq1[3];
    $char note[501];
    $char note_tmp[501];
    $char CompanyId[3];
    int   isNewa, x, liassured, have_discount;
    char  id1;
    char  str_iassured[15], tmp_id[10], id_tmp[3], Tmp_iassured[11];
    double mdiscount21, mprem21;
    
    $WHENEVER SQLERROR GOTO errexit;
 
    have_discount = 0;
    rc = getCompanyId(CompanyId);
    if (rc < 0)
        return rc;

    if (strncmp(CompanyId,"17",2) == 0)
       isNewa = 1;
    else
       isNewa = 0;

    iseq   = 1;
    iseq_a = 1;
    $CREATE TEMP TABLE tnote_tmp
    (
      iseq     integer   default 0,
      iseq1    char(2)   default ' ',
      note     char(500) default ' '
    )WITH NO LOG;

    $SELECT SUM(premium)
       INTO $premium_tot
       FROM CAR320;

    if ((dbgn1[0] != ' ') && (dbgn1[0] != '\0'))
    {
        mdiscount21 = mbus_rule - mbusiness;
        mprem21 = atol(premium1)+mdiscount21;

        rfmtdouble( mprem21, "-,---,--&", sTmpBuf);           /* �j���I�O�I�O(�u�f�e) */
        rgu_put_body_string(13, trim(sTmpBuf),LEFT);

        if ( mdiscount21 != 0)  /*** �����������B ***/
        {
              printf("#1\n");
              rfmtdouble( mdiscount21, "-,---,--&", sTmpBuf);
              rgu_put_body_string(13,"�j���I�u�f���B:",LEFT);
              rgu_put_body_string(13, trim(sTmpBuf),LEFT);

              pre_tmp = atol(premium1);
              rfmtlong(pre_tmp,"-,---,--&",sTmpBuf);
              rgu_put_body_string(13,"�j���I�ꦬ�O�O:",LEFT);
              rgu_put_body_string(13, trim(sTmpBuf),LEFT);
              have_discount = 1;
        }
        else
        {
              printf("#2\n");
              rgu_put_body_string(13," ",LEFT);
              rgu_put_body_string(13," ",LEFT);
              rgu_put_body_string(13," ",LEFT);
              rgu_put_body_string(13," ",LEFT);
        }
    }
    else
    {
        rgu_put_body_string(13,"0",LEFT);
        rgu_put_body_string(13," ",LEFT);
        rgu_put_body_string(13," ",LEFT);
        rgu_put_body_string(13," ",LEFT);
        rgu_put_body_string(13," ",LEFT);
    }

    if ((dbgn2[0] != ' ') && (dbgn2[0] != '\0'))
    {
        rfmtlong( premium_tot,"-,---,--&",sTmpBuf); /* ���N�I�O�I�O(�u�f�e) */
        rgu_put_body_string(13, trim(sTmpBuf),LEFT);                

        printf("Tdiscount[%ld]\n", Tdiscount);
        if (Tdiscount != 0)  /*** �����������B ***/
        {
              printf("#1\n");
              rfmtlong(Tdiscount,"-,---,--&",sTmpBuf);
              
              rgu_put_body_string(13,"���N�I�u�f���B:",LEFT);
              rgu_put_body_string(13, trim(sTmpBuf),LEFT);
    
              pre_tmp = atol(premium2);
              rfmtlong(pre_tmp,"-,---,--&",sTmpBuf);
              rgu_put_body_string(13,"���N�I�ꦬ�O�O:",LEFT);
              rgu_put_body_string(13, trim(sTmpBuf),LEFT);
        
              have_discount = 1;
        }
        else
        {
              printf("#2\n");
              rgu_put_body_string(13," ",LEFT);
              rgu_put_body_string(13," ",LEFT);
              rgu_put_body_string(13," ",LEFT);
              rgu_put_body_string(13," ",LEFT);
        }
    }
    else
    {
        rgu_put_body_string(13,"0",LEFT);
        rgu_put_body_string(13," ",LEFT);
        rgu_put_body_string(13," ",LEFT);
        rgu_put_body_string(13," ",LEFT);
        rgu_put_body_string(13," ",LEFT);
    } 

    pre_tmp = atol(tot_prem);
    rfmtlong(pre_tmp,"-,---,--&",sTmpBuf);
    if( have_discount == 1)
        rgu_put_body_string(13,"�ꦬ�`�O�O:",LEFT);
    else
        rgu_put_body_string(13,"�X�p�`�O�O:",LEFT);
    rgu_put_body_string(13, trim(sTmpBuf), LEFT);       
    
    if (sPrintDiscNote[0] == 'Y')
        rgu_put_body_string(13, direct_disc_98, LEFT);
    else
        rgu_put_body_string(13, " ", LEFT);

    rgu_put_body(12);    

    if ((strcmp(fdiscount,"Y") == 0) && (minus_flag == 0))
    {
        rfmtlong( premium_tot,"-,---,--&",sTmpBuf);
        rgu_put_body_string(21,sTmpBuf,LEFT); /* SubTotal�O�I�O */
    }
    else
        rgu_put_body_string(21," ",LEFT);

    pre_tmp = atol(premium2);
    rfmtlong(pre_tmp,"-,---,--&",sTmpBuf);
    rgu_put_body_string(21,sTmpBuf,RIGHT); /* SubTotal�ꦬ�O�O */

    rgu_put_body(21);
    rgu_put_body(99);

    rgu_put_body(13);

    strcpy(ibig_branch,rtrim(ibig_branch));
    strcpy(name,rtrim(name));
    sprintf_s(sTmpBuf,sizeof sTmpBuf,"%s  %s",ibig_branch,name);
    
    rgu_put_body_string(14,sTmpBuf,LEFT); /* �g��H */
    
    strcpy(dnow,cm_get_sysd2());
    
    strncpy(dnow_yy,&dnow[0],2); dnow_yy[2] = '\0';
    strncpy(dnow_mm,&dnow[3],2); dnow_mm[2] = '\0';
    strncpy(dnow_dd,&dnow[6],2); dnow_dd[2] = '\0';
    strncpy(dnow_hh,&dnow[9],5); dnow_hh[5] = '\0';
    
    printf("YY[%s] MM[%s] DD[%s] HH[%s]\n",dnow_yy,dnow_mm,dnow_dd,dnow_hh);
    
    rgu_put_body_string(14,dnow_yy,LEFT);
    rgu_put_body_string(14,dnow_mm,LEFT);
    rgu_put_body_string(14,dnow_dd,LEFT);
    rgu_put_body_string(14,dnow_hh,LEFT);
    rgu_put_body(14);
    
    rgu_put_body_string(15,itel,LEFT);
    rgu_put_body_string(15,fax,LEFT);
    rgu_put_body_string(16,address,LEFT);

    rgu_put_body(15);
    rgu_put_body(16);

    rgu_put_body_string(19,iquery_num,1); /* ���N���d�Ǹ� */
    rgu_put_body_string(19,iquery_num_damage,1); /* ���N����Ǹ� */
    rgu_put_body(19);

    rgu_put_body_string(22,iquery_num_c,1); /* �j��Ǹ� */
    
    /** id iassured  */
    strcpy(Tmp_iassured, iassured);
    liassured = strlen(trim(Tmp_iassured));
    id1=0;
    
    if( (liassured == 0) || (Tmp_iassured[0] == '\0'))
    {
    	rgu_put_body_string(22," ",1); 
    }
    else
    {
        str_iassured[0] = '\0';
    	for(x=0;x<liassured;x++)
    	{
    	   id1 = Tmp_iassured[x];
    	   printf("x=[%d] id1=[%c] Tmp_iassured[%d]=[%s]\n", x, id1, x, Tmp_iassured[x] );
    	   if( (id1 >= 48) && (id1<=57) )
    	   {
    	   	  id1 = id1 - 48;
    	   	  sprintf_s(id_tmp,sizeof id_tmp,"%d",id1);
    	   }
    	   else if( (id1 >= 65) && (id1<=90) )
    	   {
    	      id1 = id1 - 64;
    	      if( id1 < 10 )
    	         sprintf_s(id_tmp,sizeof id_tmp,"0%d",id1);
    	      else
    	         sprintf_s(id_tmp,sizeof id_tmp,"%d",id1);
    	   }
    	   else
    	   {
    	   	  id1 = id1 - 96;
    	      if( id1 < 10 )
    	         sprintf_s(id_tmp,sizeof id_tmp,"0%d",id1);
    	      else
    	         sprintf_s(id_tmp,sizeof id_tmp,"%d",id1);
    	   }
    	   
    	   strcat(str_iassured, id_tmp );
    	}

    }
    
    rgu_put_body_string(22,str_iassured,1); 
    rgu_put_body(22);

    rgu_put_body(17);
    
    if ((dbgn2[0] != ' ') && (dbgn2[0] != '\0'))
    {
        /**************
        rgu_put_body_string(18,"���G2.�Z��O�����q�T�����N�I�Y�ɦ�24�p�ɨƬG�{���B�z�B�G�Q�����K�O�D���ϴ��A�ȡB",LEFT);
        rgu_put_body(18);

        rgu_put_body_string(18,"      ���Z�ɨ���׳̨��t�B�K�O��Ų���A��(������)�C",LEFT);
        rgu_put_body(18);
        ***************/

        if (isNewa)
        {           
        	  /* �ӫO���ج�03,04,19,21,22�̤~�C�L,�]������r�����ܰʤ��j,�G���H�]�w�ɤ覡�ק� */
           if (strncmp(sIcar_type,"03",2) == 0 || strncmp(sIcar_type,"04",2) == 0 ||
               strncmp(sIcar_type,"19",2) == 0 || strncmp(sIcar_type,"21",2) == 0 ||
               strncmp(sIcar_type,"22",2) == 0)
           {
           	    iseq++;
                iseq_a++;
                strcpy(iseq1,itoa(iseq_a));
                strcpy(note,"     .�Z��O�����q�T�����N�I�Y�ɦ�24�p�ɨƬG�{���B�z�B�G�Q�����K�O�D���ϴ��A�ȡC");
                $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);
                
                iseq++;            
                strcpy(iseq1," ");
                strcpy(note,"     ���Z�ɨ���׳̨��t�B�K�O��Ų���A��(������)�C");
                $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);
                  
                iseq++;            
                strcpy(iseq1," ");
                strcpy(note,"     �U�دS�ب��B��˨��B��~���B�O�����B�B�r���B�v�ި��B�l�����B�N�ᨮ�B�ĳX���A");
                $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);
                
                iseq++;            
                strcpy(iseq1," ");
                strcpy(note,"     �����b�K�O�D���D���A�Ƚd�򤺡A�Բӻ����q�Ьd�ߥ����q�����C");                                                
                $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);
           } else if (strncmp(sIcar_type,"01",2) == 0 || strncmp(sIcar_type,"02",2) == 0 ||
                      strncmp(sIcar_type,"32",2) == 0 || strncmp(sIcar_type,"34",2) == 0)
           {
           	      /* �������إH�W��r�����C�L�X */           	      
           } else
           { 
           	      /* ���H�W���إ~,�ȻݦC�L�X�Z��O�����q..... */
           	      iseq++;
                  iseq_a++;           
                  strcpy(iseq1,itoa(iseq_a));
                  strcpy(note,"     .�Z��O�����q�T�����N�I�Y�ɦ�24�p�ɥ�q�ƬG�{���B�z�C");
                  $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);           	      
           }            
        }
        else
        {
        	  if (strncmp(sIcar_type,"03",2) == 0 || strncmp(sIcar_type,"04",2) == 0 ||
               strncmp(sIcar_type,"19",2) == 0 || strncmp(sIcar_type,"21",2) == 0 ||
               strncmp(sIcar_type,"22",2) == 0)
           {
                iseq++;
                iseq_a++;
                strcpy(iseq1,itoa(iseq_a));
                strcpy(note,"     .�Z��O�����q�T�����N�I�Y�ɦ�24�p�ɨƬG�{���B�z�B�G�Q�����K�O�D���ϴ��A�ȡC");
                $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);
                
                iseq++;            
                strcpy(iseq1," ");
                strcpy(note,"     ���Z�ɨ���׳̨��t�B�K�O��Ų���A��(������)�C");
                $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);
                  
                iseq++;            
                strcpy(iseq1," ");
                strcpy(note,"     �U�دS�ب��B��˨��B��~���B�O�����B�B�r���B�v�ި��B�l�����B�N�ᨮ�B�ĳX���A");
                $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);
                
                iseq++;            
                strcpy(iseq1," ");
                strcpy(note,"     �����b�K�O�D���D���A�Ƚd�򤺡A�Բӻ����q�Ьd�ߥ����q�����C");                                                
                $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);
                
           } else if (strncmp(sIcar_type,"01",2) == 0 || strncmp(sIcar_type,"02",2) == 0 ||
                      strncmp(sIcar_type,"32",2) == 0 || strncmp(sIcar_type,"34",2) == 0)
           {
           	      /* �������إH�W��r�����C�L�X */           	      
           } else
           { 
           	      /* ���H�W���إ~,�ȻݦC�L�X�Z��O�����q..... */
           	      iseq++;
                  iseq_a++;           
                  strcpy(iseq1,itoa(iseq_a));
                  strcpy(note,"     .�Z��O�����q�T�����N�I�Y�ɦ�24�p�ɥ�q�ƬG�{���B�z�C");
                  $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);           	      
           }
        }
    }

    if (flag_11_exist[0] == 'Y')
    {
        iseq++;
        iseq_a++;
        strcpy(iseq1,itoa(iseq_a));
        strcpy(note,"     .�x�W�a�Ϥ��~���g�䭷�B���B�v�h�A�y��\�\\�h�����w�����l�A�s�a�ϱo�T���s�󥫳�");
        $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);

        iseq++;
        strcpy(iseq1," ");
        strcpy(note,"      �ݨD�j�W�A�Ѩ����Φ��w�������ʡA�����z�d�N�������ѡA���z���R�����w�񥪥k�C");
        $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);
    }
    
    if ( isBound[0] == 'Y')
    {
        iseq++;
        iseq_a++;
        strcpy(iseq1,itoa(iseq_a));
        strcpy(note,"     .�i�����q�O���������椧�֫O�v���j");
        $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);
    }
    
    if (ins_31_multiple > 2)
    {
        /****************
        rgu_put_body_string(18,"���G3.��������ĤT�H�ˮ`�d���O�I���h���O�٫�",LEFT);
        rgu_put_body(18);
        *****************/
        iseq++;
        iseq_a++;
        strcpy(iseq1,itoa(iseq_a));
        strcpy(note,"     .��������ĤT�H�ˮ`�d���O�I���h���O�٫�");
        $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);
    }

    if (strcmp(trim(flag_29_exist),"Y")==0 &&
        strcmp(trim(flag_31_exist),"N")==0 &&
        strcmp(trim(flag_32_exist),"N")==0)
    {
        strcpy(sCoverage1,trim(sCoverage1));
        strcpy(sCoverage2,trim(sCoverage2));
        strcpy(sCoverage3,trim(sCoverage3));

        printf("scoverage1[%s]\n",sCoverage1);

        tmpString[0] = '\0';
        sprintf_s(tmpString,sizeof tmpString,"     .�������ĤT�H�d���I�w�t���O�A�O�I���B���C�@�H�ˮ`NT$%s;",sCoverage1);
        printf("[%s]\n",tmpString);
        iseq++;
        iseq_a++;
        strcpy(iseq1,itoa(iseq_a));
        strcpy(note,tmpString);
        $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);

        /****************************************
        rgu_put_body_string(18,tmpString,LEFT);
        rgu_put_body(18);
        *****************************************/

        tmpString[0] = '\0';
        printf("scoverage2[%s]\n",sCoverage2);
        printf("scoverage3[%s]\n",sCoverage3);
        sprintf_s(tmpString,sizeof tmpString,"      �C�@�ƬG�ˮ`NT$%s;�C�@�ƬG�]�lNT$%s�C",sCoverage2,sCoverage3);
        printf("[%s]\n",tmpString);
        iseq++;
        strcpy(iseq1," ");
        strcpy(note,tmpString);
        $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);

        /***************************************
        rgu_put_body_string(18,tmpString,LEFT);
        rgu_put_body(18);
        ****************************************/
    }

    if (add_mplace_01_flag == 1)
    {
        iseq++;
        iseq_a++;
        strcpy(iseq1,itoa(iseq_a));
        strcpy(note,"     .��������ӫO�R���]�o�ͨ����I�ƬG�i�t���סA�Y�i�ɦ��O�I�������̪�15��N�B���A�ȡC");
        $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);

        /***************************************
        rgu_put_body_string(18,"���G��������ӫO�R���]�o�ͨ����I�ƬG�i�t���סA�Y�i�ɦ��O�I�������̪�15��N�B���A�ȡC",LEFT);
        rgu_put_body(18);
        ****************************************/
    }

    if (add_mplace_11_flag == 1)
    {
        iseq++;
        iseq_a++;
        strcpy(iseq1,itoa(iseq_a));
        strcpy(note,"     .��������ӫO�R���]�o���ѵs�I�ƬG�A�Y�i�b�M���������ɦ�30��N�B�����C");
        $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);

        /***************************************
        rgu_put_body_string(18,"���G��������ӫO�R���]�o���ѵs�I�ƬG�A�Y�i�b�M���������ɦ�30��N�B�����C",LEFT);
        rgu_put_body(18);
        ****************************************/
    }

    if (strlen(trim(deduct_30)) != 0)
    {
        if ( (!IsFcomp24(deduct_30)) && (!IsFcomp51(deduct_30)) && (!IsFcomp55(deduct_30)) )
        {
           iseq++;
           iseq_a++;
           strcpy(iseq1,itoa(iseq_a));
           strcpy(note,"     .���O�椧�W�B�d���I���[���کӫO�d�򤣥]�t�G");
           $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);

           iseq++;
           strcpy(iseq1," ");
           strcpy(note,"      �ĤT�H�d�����s���v�T�έ��ȳd�����[���ڡC");
           $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);
        }
        else if (!IsFcomp24(deduct_30))
        {
           iseq++;
           iseq_a++;
           strcpy(iseq1,itoa(iseq_a));
           strcpy(note,"     .���O�椧�W�B�d���I���[���کӫO�d�򤣥]�t�G");
           $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);

           iseq++;
           strcpy(iseq1," ");
           strcpy(note,"      �ĤT�H�d�����s���v�T���[���ڡC");
           $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);
        }
        else if ( (!IsFcomp51(deduct_30)) && (!IsFcomp55(deduct_30)) )
        {
           iseq++;
           iseq_a++;
           strcpy(iseq1,itoa(iseq_a));
           strcpy(note,"     .���O�椧�W�B�d���I���[���کӫO�d�򤣥]�t�G");
           $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);

           iseq++;
           strcpy(iseq1," ");
           strcpy(note,"      ���ȳd�����[���ڡC");
           $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);
        }
    }
    
    /* car9803242 �Y��ܦC�L�u�f����,�Ƶ��ݦC�L�Xdirect_disc_note1�����e */
    if (sPrintDiscNote[0] == 'Y')
    {
        iseq++;
        iseq_a++;
        strcpy(iseq1,itoa(iseq_a));
        strcpy(note,direct_disc_note1);
        $INSERT INTO tnote_tmp VALUES ($iseq,$iseq1,$note);

        /***************************************
        rgu_put_body_string(18,"���G��������ӫO�R���]�o�ͨ����I�ƬG�i�t���סA�Y�i�ɦ��O�I�������̪�15��N�B���A�ȡC",LEFT);
        rgu_put_body(18);
        ****************************************/
    }

    /*****************************************************************
    if ((add_mplace_01_flag == 0) && (add_mplace_11_flag == 0))
    {
        rgu_put_body_string(18," ",LEFT);
        rgu_put_body(18);
    }
    *******************************************************************/

    printf("flag1\n");
    $DECLARE tn_cur CURSOR FOR
      SELECT iseq,iseq1,note
        FROM tnote_tmp
       ORDER BY 1;
    $OPEN    tn_cur;
    for(;;)
    {
    $FETCH   tn_cur
        INTO $iseq,$iseq1,$note;
        if   (SQLCODE == SQLNOTFOUND) break;

        printf("iseq[%d]\n",iseq);
        printf("iseq1[%s]\n",iseq1);
        printf("note[%s]\n",note);
        strcpy(note,rtrim_a(note));
        if (iseq1[0] != ' ' && iseq1[0] != '\0')
        {
           strcpy(note_tmp,note);
           note_tmp[4] = iseq1[0];
        }
        else
        {
           strcpy(note_tmp,note);
        }
        rgu_put_body_string(18,note_tmp,1);
        rgu_put_body(18);
        printf("flag6112[%s]\n",note_tmp);
    }
    $CLOSE tn_cur;
    $FREE  tn_cur;
    printf("flag6113[%s]\n",note_tmp);
    $DROP TABLE tnote_tmp;
    return M_CM_OK;
        
errexit:
  printf("{body3}:SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  return SQLCODE;
}

char *rtrim_a(s)
char s[1000];
{

 int i ;
 int j ;
 int k ;

     j = strlen(s);
     for(i=0;i<j-1;i++)
     {
        if (s[i] == '\0') break;
        if (s[i] != ' ')
        {
           k = i;
        }
     }
     s[k+1] = '\0';
     return s;
}

int IsFcomp24(str)
char *str;
{
    while (*str)
    {
        if (*str == '2')
        {
           str++;
           if (*str == '4')
           {
              return TRUE;
           }
           else
           {
              str--;
           }
        }
        str++;
    }
    return FALSE;
}

int IsFcomp51(str)
char *str;
{
    while (*str)
    {
        if (*str == '5')
        {
           str++;
           if (*str == '1')
           {
              return TRUE;
           }
           else
           {
              str--;
           }
        }
        str++;
    }
    return FALSE;
}

int IsFcomp55(str)
char *str;
{
    while (*str)
    {
        if (*str == '5')
        {
           str++;
           if (*str == '5')
           {
              return TRUE;
           }
           else
           {
              str--;
           }
        }
        str++;
    }
    return FALSE;
}
long print_deduct()
{
$char tmp2Deduct[14],tmp1Deduct[14];
int   l,j,rc;

    rc = get_deduct_info(sIcar_type,sIins_type,iMdeduct,
         tmp2Deduct,tmp1Deduct); 
    if (rc != M_CM_OK) strcpy(tmp1Deduct," ");
    
    if (isdigit(tmp2Deduct[0])!=0)  /* �ƭ� */
       rgu_put_body_string(11,tmp1Deduct,RIGHT);
    else
    {
       l=strlen(trim(tmp1Deduct));
       l=(12-l)/2;
       tmp2Deduct[0]='\0';
       for(j=0;j<l;j++)
           strcat(tmp2Deduct," ");
       strcat(tmp2Deduct,trim(tmp1Deduct));
       rgu_put_body_string(11,tmp2Deduct,LEFT);
    }
    return M_CM_OK;
}
