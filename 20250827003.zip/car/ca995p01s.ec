/**********************************************************************/
/*   program id   : ca995p01s.ec                                      */
/*   program name : ��r����J��ƪ��B�z�@�~                          */
/*   date written : 2006/09/25                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : Jessie                                            */
/*   input        : car995.txt                                        */
/**********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "print.h"
#include "safeclib.h"
/*--------------------------------------------------------------------*/
char    sApHome[30];
char    filename[50],logname[50];
char    msgbuf[1000];
$char   DBName[05],localdb[41];
char    userid[11],outputf[21];
$char   tbname[50];
char    ctype[1];
int     itype=0;

$char   stmt[1024];
/*--------------------------------------------------------------------*/
main(argc,argv)
int   argc;
char  **argv;
{
int   rc=0;
long  sysdt=0;

   batchinit();

   strcpy(DBName, isNULLstr(argv[1]));
   strcpy(userid, isNULLstr(argv[2]));
   strcpy(localdb,isNULLstr(argv[3])); 
   strcpy(tbname, isNULLstr(argv[4])); 
   strcpy(ctype,  isNULLstr(argv[5])); 
   strcpy(outputf,isNULLstr(argv[6]));

   itype = atoi(ctype);

   rc=car995_get_db();
   if (rc!=M_CM_OK)
      return rc;

   rc=car995_load_data();
   if (rc!=M_CM_OK)
      return rc;
      
   return rc;

}
/*--------------------------------------------------------------------*/
long car995_get_db()
{
int   rc=0;

   rc = getApHome(sApHome);
   if (rc<0) {
      strcpy(msgbuf,"read Config file error!!-->getApHome\n");
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   sprintf_s(filename, sizeof filename,"%s/dat/car/car995.txt", sApHome);
   sprintf_s(logname, sizeof logname,"%s/rptftp/car995_log.txt",sApHome);

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }

   return M_CM_OK;
}
/*--------------------------------------------------------------------*/
long car995_load_data()
{
int   rc=0;
$int  cnt=0;
$char  stmt[2048];
char  cmd_str[2048];
char  errbuf[128];
int   stmt_len=0;

   $whenever sqlerror goto errexit;

   strcpy(stmt," ");
   sprintf_s(stmt, sizeof stmt,"select count(*) from %s ",tbname);
   $prepare pre_cnt from $stmt;
   $execute pre_cnt into $cnt;
   strcpy(msgbuf,"�즳���:");
   sprintf_s(msgbuf, sizeof msgbuf,"%s[%d]",trim(msgbuf),cnt);

   /* ����J�Ȧs��,�T�{��J���O�_���T */
   stmt_len = 0;
   stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt+stmt_len,
              "select * from %s where 1=0 into temp temp1 with no log;\r\n",
               tbname);
   stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt+stmt_len,
                      "load from %s delimiter '\t' insert into temp1; \r\n",
                       filename);
   sprintf_s(cmd_str, sizeof cmd_str,"dbaccess %s > %s 2>&1 << !\r\n"
                   "%s\r\n!",
           localdb,logname,stmt);
   printf("cmd_str[%s]\n",cmd_str);
   rc = system(cmd_str);
   if (rc != 0) {
       sprintf_s(errbuf, sizeof errbuf,"load file error[%s]\n"
                      "���I���ɮפU���@�~�d��[Q],�T�{���~��]",
               logname);
       EWRITE(userid,rc,errbuf);
       return rc;
   } 
   /* ��J�����ɮ� */
   stmt_len = 0;
   if (itype==1)
   {
       stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt+stmt_len,"delete from %s where 1=1;\r\n",
                   tbname);
   }
       
   stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt+stmt_len,
              "select * from %s where 1=0 into temp temp1 with no log;\r\n",
               tbname);
   stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt+stmt_len,
                      "load from %s delimiter '\t' insert into temp1; \r\n",
                       filename);
   stmt_len += sprintf_s(stmt+stmt_len, sizeof stmt+stmt_len,
                      "insert into %s select * from temp1;\r\n",
                       tbname);
   sprintf_s(cmd_str, sizeof cmd_str,"dbaccess %s > %s 2>&1 << !\r\n"
                   "%s\r\n!",
           localdb,logname,stmt);
   printf("cmd_str[%s]\n",cmd_str);
   rc = system(cmd_str);
   if (rc != 0) {
       sprintf_s(errbuf, sizeof errbuf,"load file error[%s]\n"
                      "���I���ɮפU���@�~�d��[Q],�T�{���~��]",
               logname);
       EWRITE(userid,rc,errbuf);
       return rc;
   } 

   $execute pre_cnt into $cnt;
   strcat(msgbuf,"  �{�����:");
   sprintf_s(msgbuf, sizeof msgbuf,"%s[%d]",msgbuf,cnt);

   rc=rptftpinsert(userid,"car995","car995_log.txt");
        if (rc!=0) {
                EWRITE(userid,rc,"�g�Jrptftplist���~\r\n");
                return rc;
        }
   EWRITE(userid,3500,msgbuf);

   return M_CM_OK;
errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
