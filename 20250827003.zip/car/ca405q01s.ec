/****************************************************
 *   Program ID: ca405q01s.ec
 *   ����      : ���ӽЮѦC�L
 *
 ****************************************************/
#include <stdio.h>

#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "carmsgs.h"
#include "rinmsgs.h"
#include "carday.h"
#include "car_equip.h"
#include "is_def.h"
#include "print.h"
#include "sql.h"
#include "safeclib.h"

$include sqlca;
$include decimal.h;
#define TRUE  1
#define FALSE 0
#define SUCCESS 1

long  rtncode;
char  rptstr405[10000], rptstr_dtl[10000];
$char DBName1[3];
$char sUserid[11];
$char sFullName[21];
$char Icard[21];
$char Nname[121];
$char Fcard_class[2];
$char Ibrand[21]; 
$char iins_type[4];  
$char prn_deduct[19];
$char Iassured[13];
$char Nassured[66];
$char Iofficer[11];
$char Car_type[3];
$char Ibirth[11];
$char str_deduct[9];
$char Aassured[111];
$char Dply_begin[17];
$char Dply_end[17];
$char Tag_num[CA_TAG_NUM];
$char Engine_num[21];
$char fedr_status[2];
$char Iissue_ym[7] , Ipro_year[5], Qpro_month[4];
$char provision[6];
$char Imgr[2];
$char Pdmg_acc[6] , Plia_acc[6];
$char Qcylinder[9];
$char Payway[20];
$char ao_policy1[21], ao_policy2[21];
$char Fcomp_24[2];
$char str1[21];
$char str2[21];
$char str3_tmp[21] , str3[21];
$char ao_policy2_tmp[21];
$float injured_cover = 0;
$float death_cover = 0;
$float damage_cover = 0;
$int deduct = 0;
$int Ibatch_no = 0;
$int ins_premium = 0;
$double Qcylinder_tmp = 0;
$double Pdmg_acc_tmp = 0 , Plia_acc_tmp = 0;
$long i_date;


/*********************************************************************/
long car405(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
$char DBName[5];
    long rtncode;
    
    long car405_endorse_print(),car405_rpt_get();
    long car405_multiple_queryi1();
    char option;

    printf("##### car405 begin\n");

    cm_buf_init(command);
    cm_buf_get("%c",&option);
    printf("option[%c]\n",option);

    switch(option)
    {  
         case 'i': /* ��A�U�z�B��A�� */
            rtncode = car405_multiple_queryi1(reply);
         	break;       
         case 'R': /* �C�L���ӽЮ� */
            cm_buf_get("%s",DBName);
            if (db_select(DBName) == False)
                return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

                $CREATE TEMP TABLE ca405_tmp
                ( ipolicy    char(20)
                ) with no log;
                puts("create temp table ok");

                rtncode = car405_endorse_print(reply);
                 
                $DROP TABLE ca405_tmp;

                break;        
         default :
               return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
    }
    return(rtncode);
}

/*********************************************************************/

long car405_endorse_print(reply)
serverReply reply;
{
        int rc,i,j,rtncode,tmp_len;
        char sApHome[31],sTmpBuf[254], option;
        $char DBName[5];
        $char stmt[1024];
        $char ipolicy[21], ipolicyBgn[21], ipolicyEnd[21], icardBgn[21], icardEnd[21];
        char sTmp0[51],file0[51], sdelimiter[2];
        char sTmp1[71],file1[51], outputf[31];
        time_t now;
        FILE  *fp0;
        FILE  *fp1;
        char FullGetName[101], filename[31];

        $WHENEVER SQLERROR GOTO errexit;

        cm_buf_get("%c", &option);

        rc = getApHome(sApHome);
        if (rc < 0)
        {
            printf("read Config file error!!\n");
            return exitsub(reply,M_CM_READ_CONFIG_ERR) ? M_CM_READ_CONFIG_ERR : apiRC;
        }

        time(&now);
		sprintf_s(sTmp0, sizeof sTmp0, "policy_%ld.txt", now);
        sprintf_s(sTmp1, sizeof sTmp1, "policy_%ld_dtl.txt",now);

        sprintf_s(file0, sizeof file0, "%s/rptftp/%s",sApHome,sTmp0);
        sprintf_s(file1, sizeof file1, "%s/rptftp/%s",sApHome,sTmp1);

        fp0=fopen(file0,"w");
        fp1=fopen(file1,"w");

        if( option == '1')  			/* �浧�H�O�渹�C�L */
        {
            cm_buf_get("%s", ipolicy);
            strcpy(sFullName, get_car_full_db( ipolicy));
            sprintf_s( stmt, sizeof stmt, "INSERT INTO ca405_tmp SELECT ipolicy FROM %s:ply_relation WHERE ipolicy = '%s'",
                            sFullName, ipolicy);
            $PREPARE prep1 FROM $stmt;
            $EXECUTE prep1;
            $FREE prep1;
        }
        else if( option == '2')  		/* ���H�O�渹�_�W�C�L */
        {
            cm_buf_get("%s %s", ipolicyBgn, ipolicyEnd);
            strcpy(sFullName, get_car_full_db( ipolicyBgn));
            sprintf_s( stmt, sizeof stmt, "INSERT INTO ca405_tmp SELECT ipolicy FROM %s:ply_relation "
                           " WHERE ipolicy BETWEEN '%s' AND '%s' ",
                             sFullName, ipolicyBgn, ipolicyEnd);
            $PREPARE prep2 FROM $stmt;
            $EXECUTE prep2;
            $FREE prep2;
        }
        else if( option == '3')  		/* ���H�d���_�W�C�L */
        {
            cm_buf_get("%s %s", icardBgn, icardEnd);
            sprintf_s( stmt, sizeof stmt, "INSERT INTO ca405_tmp SELECT ipolicy FROM ply_relation "
                           " WHERE ipolicy IN (SELECT ipolicy FROM ply_relation "
                           "                    WHERE icard BETWEEN '%s' AND '%s') ",
                             icardBgn, icardEnd);
            $PREPARE prep3 FROM $stmt;
            $EXECUTE prep3;
            $FREE prep3;
        }
        else if( option == '4')  		/* ���H��r�ɿ�J�h���O�渹�C�L */
        {
            cm_buf_get("%s ", filename);
            sprintf_s( FullGetName, sizeof FullGetName, "%s/dat/car/%s", sApHome, filename);
            strcpy( sdelimiter,  "\t");
            if ((rc=load_command1( FullGetName, outputf, "ca405_tmp", sdelimiter)) != SUCCESS)
            {
                return exitsub(reply, -1) ?  -1 : apiRC;
            }
        }
        else
            return exitsub(reply, M_CM_WRONG_OPTION) ?  M_CM_WRONG_OPTION : apiRC;

        /* ca405_tmp ��ipolicy�i�ର�d���ΫO�渹�Χ�渹 */
        $DECLARE curs1 CURSOR FOR
          SELECT distinct ipolicy FROM ca405_tmp
           WHERE ipolicy <> ' '
           UNION
          SELECT distinct b.ipolicy FROM ca405_tmp a, ply_relation b
           WHERE a.ipolicy = b.icard
             AND a.ipolicy <> ' '
           UNION
          SELECT distinct b.iendorse FROM ca405_tmp a, edr_relation b
           WHERE a.ipolicy = b.iendorse
             AND a.ipolicy <> ' '
          ;

        $OPEN curs1;
        for(;;)
        {
            $FETCH curs1 INTO $ipolicy;
            if( SQLCODE == SQLNOTFOUND)
                break;
            rc = car405_rpt_get(ipolicy);
            
            if(rc == 8888) /* �䤣���Ʈw�W��,�~��U�@�� */
                continue;
            else if(rc != M_CM_OK)
            {
                sprintf_s(sTmpBuf, sizeof sTmpBuf, "���ӽЮ�[%s] �C�L�����D", ipolicy);
                fclose(fp0);
                fclose(fp1);
                return exitsub(reply, rc) ?  rc : apiRC;
            }

            fprintf(fp0,"%s",rptstr405);
            fprintf(fp1,"%s",rptstr_dtl);

            printf("%s\n",rptstr405);
        }
        $CLOSE curs1;
        $FREE curs1;

        fclose(fp0);
        fclose(fp1);

        cm_buf_init(ReplyBuf);
        cm_buf_put("%l",M_CM_OK);
        cm_buf_put("%s %s",sTmp0, sTmp1);
        tmp_len = cm_buf_len(ReplyBuf);                
        if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
                return apiRC;
        else
                return api_OKComplete;

errexit:
    printf("car405_endorse_print:SOLERR:%s\n",sqlca.sqlerrm);
    fclose(fp0);
    fclose(fp1);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}

/*���o���ӽЮѸ��*/
long car405_rpt_get(e_sIpolicy)
$char *e_sIpolicy;                           /*�O�渹�X or ��渹�X*/
{
	int rc,i,j,k,rtncode;
	$char stmt[1024], sStmt[1024], sNapplicant[121], fdeduct[2];
	char DBName1[3];
	char sbuf[40];
	char tmp_ibatch_no[3],result1[3],comment1[31],date1[9],lastdate1[9];
	$char pay_date[9], sply_relation[21], spolicy[21], sply_ins_type[21], ipolicy[21], iendorse[21], iendorse_tmp[21], skey[21];
  $char sipolicy[21], check_fedr[11], iapplicant[13], sca_pa_ply[21], sca_pa_edr[21];
  $long qday=0, lIns_type, iedr, ldendorse=0, ireissueNumber;
  $char itmp_policy[21], ftype_sp[3], reissueNumber[4];
  
  $char nbeneficiary[31], sNbeneficiary[61], relation_bene[31], sRelation_bene[61];
  $char r_ibranch_in[3], feply[2], iroute[21], ileader[11], nleader[11],nins_type[29],nowner[121];
  $double mkilo_ply_tmp=0.0;
  $char   mkilo_ply[10],itel[21],nbrand[31];
  $char sDinstall_ym[7],sIsequence[31],sAinstall_zip[7],sAinstall[91];
  
	rptstr405[0] = '\0';
	rptstr_dtl[0] = '\0';

	$WHENEVER SQLERROR GOTO errexit;

        strcpy( iendorse_tmp, e_sIpolicy);
	printf("Policy ==>[%s] \n",e_sIpolicy);
	strcpy(sFullName, get_car_full_db(e_sIpolicy));
	printf("sFullName ==>[%s], strlen[%d]\n",sFullName, strlen(sFullName));
	if( strlen(sFullName) == 0)
            return 8888;
	
	/*rtncode = cm_get_unit_in(e_sIpolicy," ","" , " " ,"C3",DBName1,"");*/
        
        sprintf_s(stmt, sizeof stmt,"SELECT icomp_in FROM %s:ply_relation "
                     " WHERE ipolicy = '%s'", sFullName, e_sIpolicy);
	$PREPARE prep1_1 FROM $stmt;
	$EXECUTE prep1_1 INTO $DBName1;
	
	if( SQLCODE == SQLNOTFOUND ) /* ����� */
        {
           strncpy(r_ibranch_in,e_sIpolicy,2);
           r_ibranch_in[2] = '\0';

           EXEC SQL SELECT iupcomp
                      INTO :DBName1
                      FROM branch
                     WHERE ibranch = :r_ibranch_in;
           if(SQLCODE == SQLNOTFOUND)
	      return SQLNOTFOUND;
        }
        printf("DBName1[%s]\n",DBName1);

        strcpy( skey, e_sIpolicy); /*�O�渹�X or ��渹�X*/

        sprintf_s(stmt, sizeof stmt,"SELECT ipolicy, dendorse FROM %s:edr_relation "
                     " WHERE iendorse = '%s'", sFullName, skey);
	$PREPARE prep1 FROM $stmt;
	$EXECUTE prep1 INTO $e_sIpolicy, $ldendorse; /* e_sIpolicy ���O�渹 */

        if( SQLCODE == SQLNOTFOUND) /* ���O�� */
        {
            strcpy( sply_relation, "ply_relation"); /* table name */
            strcpy( spolicy, "policy"); /* table name */
            strcpy( sply_ins_type, "ply_ins_type"); /* table name */
            strcpy( sipolicy, "ipolicy"); /* ���W��  */
            iedr = 0;
            strcpy( e_sIpolicy, skey); /* e_sIpolicy ���O�渹 */
            strcpy( sca_pa_ply, "ca_pa_ply"); /* table name */
        }
        else /* �Y�����, �C�L��e���A */
        {
            strcpy( sply_relation, "ply_relation_bak"); /* table name */
            strcpy( spolicy, "policy_bak"); /* table name */
            strcpy( sply_ins_type, "ply_ins_type_bak"); /* table name */
            strcpy( sipolicy, "iendorse"); /* ���W�� */
            iedr = 1;
            strcpy( sca_pa_edr, "ca_pa_edr"); /* table name */
        }

    /*1110718002_SC2 �s�W�L���q�ʤG�����A35���ا�� ibody */
	sprintf_s(stmt, sizeof stmt,"SELECT B.icard , B.nassured , B.iassured , "
            "        to_char(dbirth,'%%Y')::integer - 1911 || '/' || to_char(dbirth,'%%m')|| '/' || to_char(dbirth,'%%d'), "
            "         trim(B.aassured) || ' ' || trim(B.mobil_phone), A.dply_begin , "
			" A.dply_end , B.itag ,Case When A.icar_type<>'35' Then B.iengine Else B.ibody End AS iengine , "
			" A.icar_type , A.ibrand , to_char(dissue,'%%Y')::integer - 1911 || '/' || to_char(dissue,'%%m'), "
            " A.ipro_year , B.qpro_month , "
			" B.qcylinder , B.pdmg_acc , "
			" B.plia_acc , A.iofficer,(SELECT imgr FROM officer WHERE iofficer = A.iofficer) , A.fcard_class, A.ibatch_no, B.fcomp_24, B.napplicant, A.ipolicy, B.iapplicant, "
			" A.itmp_policy, A.feply, B.iroute,B.itel,B.mkilo_ply,B.nowner, "
			" nvl(to_char(B.dinstall,'%%Y')::integer - 1911 || '/' || to_char(B.dinstall,'%%m'),' '), "
			" B.isequence, B.ainstall_zip, B.ainstall "
		"FROM %s:%s A , %s:%s B "
		"WHERE A.%s = B.%s "
		"  AND A.%s = '%s' AND A.dply_close is not null",  
	sFullName, sply_relation, sFullName, spolicy, sipolicy, sipolicy, sipolicy, skey );
        printf("stmt[%s]\n", stmt);
	$PREPARE GET_PLY1 FROM $stmt;
	$EXECUTE GET_PLY1 
	INTO $Icard , $Nassured, $Iassured , $Ibirth , $Aassured , $Dply_begin , $Dply_end ,
		$Tag_num , $Engine_num ,
		$Car_type , $Ibrand , $Iissue_ym , $Ipro_year , $Qpro_month ,
		$Qcylinder_tmp , $Pdmg_acc_tmp ,
		$Plia_acc_tmp , $Iofficer, $Imgr, $Fcard_class, $Ibatch_no, $Fcomp_24, $sNapplicant, $ipolicy, $iapplicant,
		$itmp_policy, $feply, $iroute, $itel, $mkilo_ply_tmp , $nowner,
		$sDinstall_ym, $sIsequence, $sAinstall_zip, $sAinstall;

        printf("nassured[%s]\n", Nassured);
		printf("Engine_num[%s]\n", Engine_num);
		printf("sIsequence[%s]\n", sIsequence);
		printf("sAinstall_zip[%s]\n", sAinstall_zip);		

	if (SQLCODE==SQLNOTFOUND)
	{
            return 8888;
	}
	$SELECT nname , ileader
           INTO $Nname, $ileader
	   FROM officer WHERE iofficer = $Iofficer;
	
	$SELECT nname
           INTO $nleader
	   FROM officer WHERE iofficer = $ileader;
	
	ireissueNumber = 0;
	if (Fcard_class[0]=='2')
	{
        $SELECT COUNT(*)
           INTO $ireissueNumber
           FROM ca_log
          WHERE itype = 'P' 
            AND ipgid = 'car307'
            AND ilog_number1 = $ipolicy;
    }
	else  /*1101004008_SC1 �ץ����ӽЮѦC�L���u�ȥ��ɵo���ơv����W�h*/
	{
        $SELECT COUNT(*)
           INTO $ireissueNumber
           FROM ca_card_log
          WHERE ipolicy = $ipolicy;
	}
    sprintf_s(reissueNumber, sizeof reissueNumber, "%d", ireissueNumber);	

	/* �u�O�_���O�v���G��ܤ��e�O�_���O+�ĳq�ʽ� 
	    add by larry 104.01.19 (1040107011_C1) */	
	$SELECT ftype_sp INTO $ftype_sp
	   FROM cm_pre_receive
	  WHERE ipre_rcv = $itmp_policy
	    AND iins_kind = $Fcard_class
	    AND ipre_end = ' ';
	if (SQLCODE==SQLNOTFOUND) strcpy(ftype_sp," ");

	printf("Select policy and ply_relation OK!!!\n");
	printf("Icard =======>[%s] \n",Icard);
	
	/*�s�y�~��*/
        strcat(Ipro_year, "/");
        strcat(Ipro_year, trim(Qpro_month));
        printf("**********Ipro_year = %s \n",Ipro_year);

	/******** �O��_�l�� */
	printf("Dply_begin ==>[%s] \n",Dply_begin);
	strcpy(str1,cm_from_infdate_100(Dply_begin));

	/******** �O��פ�� */
	printf("Dply_end ====>[%s] \n",Dply_end);
	strcpy(str2,cm_from_infdate_100(Dply_end));

	/******** �N���e�Y���ഫ���r��κA *********/
	sprintf_s(Pdmg_acc, sizeof Pdmg_acc,"%5.2f",Pdmg_acc_tmp);     /*** ���� ***/
	sprintf_s(Plia_acc, sizeof Plia_acc,"%5.2f",Plia_acc_tmp);     /*** ���d ***/

	printf("the Pdmg_acc is [%s] \n",Pdmg_acc);
	printf("the Plia_acc is [%s] \n",Plia_acc);

	/******** �N�Ʈ�q�Ѽƭ���r�� ****************/
	/*sprintf_s(Qcylinder, sizeof Qcylinder,"%4d",Qcylinder_tmp);*/ 
	sprintf_s(Qcylinder, sizeof Qcylinder,"%7.2f",Qcylinder_tmp);   /*1080902001_SC2 �Ʈ�q�X�ܤp���I2��*/

	printf("the Qcylinder is [%s] \n",Qcylinder);

	/******** �d�߫O��O�_�w���O ******************/
	pay_date[0] = '\0';
	result1[0]  = '\0';
	comment1[0] = '\0';
	date1[0]    = '\0';
	lastdate1[0]= '\0';

	if(Ibatch_no >= 0)
		strcpy(tmp_ibatch_no," ");
	else
		sprintf_s(tmp_ibatch_no, sizeof tmp_ibatch_no,"%d",Ibatch_no);

	if(strlen(trim( e_sIpolicy)) > CAR_POLICY_LEN)
	{
		strncpy(ao_policy1 ,  e_sIpolicy , CAR_POLICY_LEN);
		ao_policy1[CAR_POLICY_LEN] = '\0';
		strcpy(ao_policy2,substring( e_sIpolicy,CAR_POLICY_LEN+1,4));
	}
	else
	{
		strncpy(ao_policy1 ,  e_sIpolicy , CAR_POLICY_LEN);
		ao_policy1[CAR_POLICY_LEN] = '\0';
		strcpy(ao_policy2," ");
	}
	strcpy(ao_policy1,trim(ao_policy1));
	strcpy(ao_policy2,trim(ao_policy2));
	ao_chk_charge(DBName1, 'A', ao_policy1, ao_policy2 , tmp_ibatch_no, result1,
					comment1, date1, lastdate1);

	printf("ca_rpt_app-----aochk--Res[%s]\n",result1);
	printf("ca_rpt_app---lastdate1[%s]\n",lastdate1);
	if(strcmp(trim(result1),"R1")==0)

		strcpy(Payway,"�w���O");

	else if(strcmp(trim(result1),"R2")==0)

		strcpy(Payway,"�w���O;�I�{");

	else if(strcmp(trim(result1),"R3")==0)

		strcpy(Payway,"�w���O;�S��");

	else if(strcmp(trim(result1),"R4")==0)
	{

		strcpy(Payway,"���I,");
		strcat(Payway,lastdate1);
		strcpy(pay_date," ");
	}
	else if(strcmp(trim(result1),"R5")==0)

		strcpy(Payway,"�w���O,���{");

	else if(strcmp(trim(result1),"R6")==0)

		strcpy(Payway,"�H�Υd���P�b");

	else if(strcmp(trim(result1),"N2")==0)
	{
		strcpy(Payway,"�h��;");
		strcat(Payway,lastdate1);
		strcpy(pay_date," ");
	}
	else if(strcmp(trim(result1),"NC")==0)

		strcpy(Payway,"�w���O;�M��");

	else if(strcmp(trim(result1),"NA")==0)

		strcpy(Payway,"���O������");

	else if(strcmp(trim(result1),"NR")==0)

		strcpy(Payway,"���������O");

	else if(strcmp(trim(result1),"NR")==0)

		strcpy(Payway,"���Ѥ�");

    strcpy(nbrand," ");
    $Select first 1 nbrand into $nbrand 
       From ca_car_model where ibrand = $Ibrand;
       
    sprintf_s(mkilo_ply, sizeof mkilo_ply,"%9.2f",mkilo_ply_tmp);
/*
printf("-- trace itel[%s]\n ",itel);
printf("-- trace mkilo_ply[%s]\n ",mkilo_ply);
printf("-- trace nowner[%s]\n ",nowner);
*/
   
	/**************���̪�O����*****************/
        
	strcpy(rptstr405,Icard);
	strcat(rptstr405,"\t");
	strcat(rptstr405,e_sIpolicy);

	/*** ���o�Q�O�I�H�m�W(���e) ***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,trim(Nassured));
        printf("rptstr405[%s]\n", rptstr405);
	/*** ���o�Q�O�I�HID number ***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,Iassured);
	/*** ���o�Q�O�I�H�ͤ� ***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,Ibirth);
	/***���o���O��(���O���A)***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,Payway);
	strcat(rptstr405,",");
	strcat(rptstr405,trim(ftype_sp));
	/*** ���o���ڤ� ***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,pay_date);
	/*** ���o����(���e) ***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,Aassured);
	/*** ���o�O�I�����_�l ***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,str1);
	/*** ���o�O�I�����פ� ***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,str2);
	/*** ���o���P���X(���e) ***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,Tag_num);
	/*** ���o����/�������X(���e) ***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,rtrim(Engine_num));
	/*** ���o��������(���e) ***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,Car_type);
	/*** ���o�t�P����(���e) ***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,Ibrand);
	/*** ���o��l�o�Ӧ~��(���e) ***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,Iissue_ym);
	/*** ���o�s�y�~��(���e)***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,Ipro_year);
	/*** ���o�Ʈ�q(���e) ***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,Qcylinder);

	/******** �O�I���B ****************************/
	$WHENEVER SQLERROR GOTO errexit;
	strcpy(provision," ");

	sprintf_s(stmt, sizeof stmt,"SELECT a.iins_type, a.minjured_cover, a.mdeath_cover,    "
				 " a.mdamage_cover, a.mdeduct,a.mins_premium,a.fedr_status,  "
				 " a.provision, a.qday, b.fdeduct, b.nins_type               "
			     " FROM %s:%s a, insurance_type b "
			     " WHERE a.iins_type = b.iins_type and (a.%s = ?)", sFullName, sply_ins_type, sipolicy );

	printf("%s\n",stmt);

	$PREPARE CUR9 FROM $stmt;
	$DECLARE curh1 CURSOR FOR CUR9;
	$OPEN curh1 USING $skey;
	i=0;
	for(;;)
	{
		$FETCH curh1 INTO $iins_type,$injured_cover,$death_cover,
			$damage_cover,$deduct,$ins_premium,$fedr_status,
			$provision,$qday,$fdeduct,$nins_type;
		if(SQLCODE == SQLNOTFOUND) break;
		sprintf_s(str_deduct, sizeof str_deduct,"%d",deduct);
		prn_deduct[0]=0;
        /*
                $SELECT fdeduct
                   INTO $fdeduct
                   FROM insurance_type
                  WHERE iins_type = $iins_type;
        */
		$SELECT prn_deduct
			INTO $prn_deduct
			FROM ca_dmg_mdeduct
			WHERE icar_type=$Car_type
			AND ideduct=$str_deduct;
		printf("Ipolicy[%s][%s][%f][%f][%f]\n",e_sIpolicy,iins_type,injured_cover,death_cover,damage_cover);
		if(fedr_status[0] == '1') /*** ���h ***/
			continue;

		if(fedr_status[0] == '2') /*** �j�h ***/
			continue;

		if(fedr_status[0] == '3') /*** �h���h�O ***/
			continue;

		if(fedr_status[0] == '5' &&
			injured_cover == 0 &&
			death_cover == 0 &&
			damage_cover == 0)     /*** ���P ***/
			continue;
			
		strcat(rptstr_dtl,e_sIpolicy);
		strcat(rptstr_dtl,"\t");
		/*** ���o�I�� ***/
		strcat(rptstr_dtl,iins_type);
		strcat(rptstr_dtl,"\t");
		strcat(rptstr_dtl,rtrim(nins_type));

		/***  ���o�O�I���B ***/
		strcat(rptstr_dtl,"\t");
		/* 1000225003 �D���ϴ��O�θ��v�O�I�s�ӫ~�t�λݨD*/
		printf("iins_type[%s]=",iins_type); 
		
		lIns_type = atoi(iins_type);
		switch ( lIns_type)
        {
			case 38: case 39: case 238: /*1100119001_SC2 �s�W-�s�ӫ~(238�I-�D���ϴ��O�Ϊ��[����)�������ˮ֤Ϊ���*/
			    if (lIns_type==238) 
				{
					if(injured_cover != 0)
					{						
						/* �p�ƤG��L���U��@��, ex. 0.30/0.60;30���� => 0.3/0.6;30����  */
						if(((long)injured_cover % 10000) > 0)
							rfmtdouble((injured_cover / 10000), "(#####&.#)", sbuf); 
						else
							rfmtdouble((injured_cover / 10000), "(#####&)", sbuf);
						strcat(rptstr_dtl,trim(sbuf));
					}	
					if(damage_cover != 0)
					{
						if(injured_cover != 0 || death_cover != 0)
							strcat(rptstr_dtl,"/");
						if(((long)damage_cover % 10000) > 0)
							rfmtdouble((damage_cover / 10000), "(#####&.#)", sbuf);
						else
							rfmtdouble((damage_cover / 10000), "(#####&)", sbuf);
						strcat(rptstr_dtl,trim(sbuf));
					}								
				}

			    printf("qday[%d]=",qday);
				if(qday != 0)
				{
					if (lIns_type==38 || lIns_type==39) {
					   strcat(rptstr_dtl,"��Q���{");
					}

                    /*1101229013_SC2 �s�W238�I�ؤ������{�O�v*/
					if (qday==899 || qday==999)  /* ex. 0.3/0.6�������� */
					{  
						strcat( rptstr_dtl, "��������");

					}else{                       /* ex. 0.3/0.6;30���� */
						strcat(rptstr_dtl,";");
						rfmtlong( qday, "(#####&)", sbuf);
						strcat(rptstr_dtl,trim(sbuf));
						strcat(rptstr_dtl,"����");
					}
				}
				break;
			
			default:
				if(injured_cover != 0)
			    {
					
				    if(((long)injured_cover % 10000) > 0)
					    rfmtdouble((injured_cover / 10000), "(#####&.##)", sbuf);
				    else
					    rfmtdouble((injured_cover / 10000), "(#####&)", sbuf);
				    strcat(rptstr_dtl,trim(sbuf));
			    }
				if(death_cover != 0)
				{
					if(injured_cover != 0)
						strcat(rptstr_dtl,"/");
					if(((long)death_cover % 10000) > 0)
						rfmtdouble((death_cover / 10000), "(#####&.##)", sbuf);
					else
						rfmtdouble((death_cover / 10000), "(#####&)", sbuf);
					strcat(rptstr_dtl,trim(sbuf));
				}
				if(damage_cover != 0)
				{
					if(injured_cover != 0 || death_cover != 0)
						strcat(rptstr_dtl,"/");

					if (lIns_type==160) /*1110216005_SC1 �t�X�N�ɫO�ӫ~�վ�CAR401�B�q�l�O���E�O���t��*/
					{
                        strcpy(sbuf, "�̦�ӤW���Ӹ��H�ƴ�@�H����");
					}else{
						if(((long)damage_cover % 10000) > 0)
							rfmtdouble((damage_cover / 10000), "(#####&.##)", sbuf);
						else
							rfmtdouble((damage_cover / 10000), "(#####&)", sbuf);
					}	
					strcat(rptstr_dtl,trim(sbuf));
				}
				if(atoi(iins_type) == 18)
				{
					strcat(rptstr_dtl,",�_��");
					strcat(rptstr_dtl,substring(str_deduct,1,2));
					strcat(rptstr_dtl,"%");
				}

				break;
        }

		/*** ���o�ۭt�B ***/
		strcat(rptstr_dtl,"\t");
        if( fdeduct[0] == '0')
		{
		    strcat(rptstr_dtl," ");
		}	
		else if(lIns_type == 11  || lIns_type == 211 || 
		        lIns_type == 176 || lIns_type == 177 || lIns_type == 178) /*1130510009_C02 �s�W�q�ʨ��M�ݰӫ~(0701�W�u)*/
		{
			if (strlen(trim(str_deduct))>0)
			{
				strcat(rptstr_dtl,trim(str_deduct));			
				strcat(rptstr_dtl,"%");
			}
			else
			{
				strcat(rptstr_dtl," ");
			}
		}
		else if(lIns_type == 18)
		{
			strcat(rptstr_dtl,substring(str_deduct,3,2));
			strcat(rptstr_dtl,"%");
		}		
		else if (strlen(trim(prn_deduct)) > 6) /* �ˬd�r������ �W�L6�N����ܦۭt�B�N��(1140522004_C01) */
		{
			strcat(rptstr_dtl,trim(str_deduct));
		}
		else
		{
			strcat(rptstr_dtl,trim(prn_deduct));
		}			
		/*** ���o�O�O ***/
		strcat(rptstr_dtl,"\t");
		strcat(rptstr_dtl,refmtamt(ins_premium,MILLIONTH));
		/*** �O�_���Ұ���O�� ***/
		strcat(rptstr_dtl,"\t");
		strcat(rptstr_dtl,provision);

	        strcat(rptstr_dtl,"\t");
                if( iedr == 0)
	            strcat(rptstr_dtl,"");
                else
	            strcat(rptstr_dtl,skey);

		strcat(rptstr_dtl,"\n");
	i++;
	}
	$CLOSE curh1;
	$FREE  curh1;

	/******** ���t�Τ�� ********/
	rtoday(&i_date);
        if( iedr != 0) /* ���H���鬰�C�L��� */
            i_date = ldendorse;
	rdatestr(i_date,str3_tmp);
    printf("str3_tmp[%s]\n",str3_tmp);
	strcpy(str3,cm_from_infdate_100(str3_tmp));
	printf("str3[%s]\n",str3);

	/*********** �}�l�C�L�O����ӽЮ� *****************/
	if (strlen(trim(e_sIpolicy)) > CAR_POLICY_LEN)
	{
		strcpy(ao_policy2_tmp,"-");
		strcat(ao_policy2_tmp,ao_policy2);
		strcpy(ao_policy2_tmp,trim(ao_policy2_tmp));
	}
		
	/*** ���o����Y�� ***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,Pdmg_acc);
	/*** ���o����t�� ***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,Plia_acc);
	/*** ���o�g��H�N�� ***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,Iofficer);
	/*��O*/
	strcat(rptstr405,"\t");
	strcat(rptstr405,Imgr);	
	/*** ���o�g��H�m�W ***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,Nname);
	/*** ���o�C�L��� ***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,str3);
	strcat(rptstr405,"\t");
	strcat(rptstr405,Fcard_class);
	/*** ���o�n�O�H(���e) add by sylvia 99.12.24 ***/
	strcat(rptstr405,"\t");
	strcat(rptstr405,sNapplicant);
	strcat(rptstr405,"\t");
        if( iedr == 0)
	    strcat(rptstr405,"");
        else
	    strcat(rptstr405,skey);
	
	strcat(rptstr405,"\t");
    printf("begin car_spec_policy\n");
	strcpy( check_fedr, "");
	$SELECT first 1 check_fedr 
		INTO $check_fedr
		FROM car_spec_policy
		WHERE (inumber = $ipolicy or inumber = $Iassured or inumber = $Icard or inumber = $iapplicant)
		AND check_fedr[10] != '0';
    printf("end car_spec_policy\n");
	strcat(rptstr405, trim(check_fedr));
	strcat(rptstr405,"\t");
	
	strcpy(nbeneficiary," ");
	strcpy(relation_bene," ");
	strcpy(sNbeneficiary," ");
	strcpy(sRelation_bene," ");
	k = 0;
	sprintf_s(sStmt, sizeof sStmt,"SELECT DISTINCT nbeneficiary, "
	              "        CASE WHEN iins_type in ('33','56','136','166','266') THEN "
	              "             (CASE WHEN relation_bene = '1' THEN '���H' "
	              "                   WHEN relation_bene = '2' THEN '�a��' "
	              "                   WHEN relation_bene = '3' THEN '�O�Υ������H' "
	              "                   WHEN relation_bene = '4' THEN '�ŰȤH' "
	              "                   WHEN relation_bene = '5' THEN '�]���޲z�H' "
	              "                   WHEN relation_bene = '6' THEN '�k�w�~�ӤH' "
	              "                   WHEN relation_bene = '7' THEN '�t��' "
	              "                   WHEN relation_bene = '8' THEN '���t����' "
	              "              ELSE ' ' END) "
	              "         ELSE ' ' END relation_bene "
	              "   FROM %s:%s "
	              "  WHERE %s = ? "
	              "    AND trim(nbeneficiary) <> '' "
	              "    AND nbeneficiary IS NOT NULL; ", sFullName, sca_pa_ply, sipolicy);
    printf("sStmt[%s]=",sStmt); 
	$PREPARE CUR10 FROM $sStmt;
	$DECLARE cur_caPaPly CURSOR FOR CUR10;
	$OPEN cur_caPaPly USING $skey;
	
	for(;;)
	{
      $FETCH cur_caPaPly INTO $nbeneficiary, $relation_bene;
      
      if(SQLCODE == SQLNOTFOUND) break;

      k++;
      if (k == 1)
      {
          strcpy(sNbeneficiary, trim(nbeneficiary));
          strcpy(sRelation_bene, trim(relation_bene));
      }
      else
      {
          if (k > 2) break;
          strcat(sNbeneficiary, ",");
          strcat(sNbeneficiary, trim(nbeneficiary));
          strcat(sRelation_bene, ",");
          strcat(sRelation_bene, trim(relation_bene));
      }
	}
	$CLOSE cur_caPaPly;
	$FREE  cur_caPaPly;
	
	strcat(rptstr405, trim(sNbeneficiary));
	strcat(rptstr405,"\t");
	strcat(rptstr405, trim(sRelation_bene));
	strcat(rptstr405,"\t");
	strcat(rptstr405, trim(feply));
	strcat(rptstr405,"\t");
	strcat(rptstr405, trim(iroute));
	strcat(rptstr405,"\t");
	strcat(rptstr405, trim(ileader));
	strcat(rptstr405,"\t");
	strcat(rptstr405, trim(nleader));
	strcat(rptstr405,"\t");
	strcat(rptstr405, trim(reissueNumber));

	strcat(rptstr405,"\t");
	strcat(rptstr405, trim(itel));
	strcat(rptstr405,"\t");
	strcat(rptstr405, trim(mkilo_ply));
	strcat(rptstr405,"\t");
	strcat(rptstr405, rtrim(nowner));
	strcat(rptstr405,"\t");
	strcat(rptstr405, rtrim(nbrand));

    strcat(rptstr405,"\t");                  /*1120927002_C02 �R�q�ΰӫ~�}�o*/
	strcat(rptstr405,sDinstall_ym);
    strcat(rptstr405,"\t");
	strcat(rptstr405,rtrim(sIsequence));
    strcat(rptstr405,"\t");
	strcat(rptstr405,sAinstall_zip);
    strcat(rptstr405,"\t");
	strcat(rptstr405,rtrim(sAinstall));

	strcat(rptstr405,"\n");

	return M_CM_OK;
    
	errexit:
		printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
		return SQLCODE;
}

long car405_multiple_queryi1(reply)
serverReply reply;
{
     $char DBName[5], sFullName[20];
     int tmp_len;
     $char job_pos[5],iquota[7],priLevel[2];

     cm_buf_get("%s",DBName);
     cm_buf_get("%s",sUserid);

     if(db_select(DBName) == False)
        return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;

     EXEC SQL WHENEVER SQLERROR GOTO errexit;

     $SELECT work_type
        INTO $job_pos
        FROM personal:asempl
       WHERE empl_no=$sUserid;
     if (SQLCODE == SQLNOTFOUND) {
            return M_CMN_NOFFICER;
        }
        
     $SELECT iquota
        INTO $iquota
        FROM officer
      WHERE iofficer=$sUserid;
     if (SQLCODE == SQLNOTFOUND) {
            return M_CMN_NOFFICER;
        }
        
     strcpy(priLevel, "N");

	if (iquota[0] >= '6')
	{
		if (iquota[2] == '0' && iquota[3] == '1')
		{
			strcpy(priLevel, "Y");
		}
		else
		{
			if (strncmp(job_pos,"GA",2) == 0)
			{
				strcpy(priLevel, "Y");
			}
		}
	}

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l",M_CM_OK);
     cm_buf_put("%s",priLevel);
     tmp_len = cm_buf_len(ReplyBuf);

     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
    printf("SOLERR:%s\n",sqlca.sqlerrm);
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}
/******************************************************************************/
