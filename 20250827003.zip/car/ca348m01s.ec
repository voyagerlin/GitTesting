/*******************************************************************************
*                                                                              *
*   FILE         : ca348m01s.ec                                                *                                                                             *
*   DESCRIPTION  : �Τ@�F�ʹq�l�O��ǿ�@�~                                    *
*                                                                              *
*******************************************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "othmsgs.h"
#include "glscom.h"
#include "carmsgs.h"
#include "safeclib.h"
$include decimal.h;
$include sqlca;

DBinfo  *list;
int i, count_db;
FILE   *fp;
char errbuf[2048];
char err[128];
FILE   *fp;
static int   recLen=1024;
static char  *bp;
char delimiter;
int offset;
int  tmp_len;
/*----------------------------------------------------------------------------*/
long car348(reply, command, com_len)
serverReply reply;
voidP command;
int com_len;
{
  long rtncode;

  long car348_single_query();
  long car348_multiple_query();
  
  char option;
  cm_buf_init(command);
  cm_buf_get("%c",&option);
  switch(option)
  {
   case 'A':
           rtncode = car348_insert(reply);
           break;   
   case 'Q':
           rtncode = car348_single_query(reply);
	       break;
   case 'M':
           rtncode = car348_multiple_query(reply);
	       break;
   case 'D':
   case 'U':
           rtncode = car348_update_exec(reply,command,com_len);
           break;
   default :
           if(exitsub(reply,M_CM_WRONG_OPTION) == True)
             return M_CM_WRONG_OPTION;
           return apiRC;
  }
   return(rtncode);
}
/*----------------------------------------------------------------------------*/
long car348_insert(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 $char iyymm[6], ipolicy[21], frenew[2], dftp[20], userid[11];
 $char temp_ipolicy[21], tmp_fulldb[64], stmt_bufX[300];
 
 dec_t dec_psex_age;

 /* standard defined data */
 int tmp_len;
 long MsgCode;
   DBinfo *list;
   int i, j, is_add_fail=0, api_f;
   $char stmt_buf[300];
 /* end of standard data */

 cm_buf_get("%s",DBName);
 cm_buf_get("%s %s %s %s %s",iyymm, ipolicy, frenew, dftp, userid);

 printf("insert: iyymm[%s],ipolicy[%s],frenew[%s],dftp[%s],userid[%s]\n",iyymm, ipolicy, frenew, dftp, userid);
  
 $WHENEVER SQLERROR GOTO errexit;
 
 if (db_select(DBName) == False) 
 { 
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
 }
 
 strcpy(tmp_fulldb, get_car_full_db(ipolicy));
 if (strcmp(tmp_fulldb,"") == 0)
 {
 	if(exitsub(reply,M_CA_NPOLICY) == True) return M_CA_NPOLICY;
    else return apiRC;
 }
 
 sprintf_s(stmt_bufX,sizeof stmt_bufX,
     	" SELECT ipolicy "
     	" FROM %s:ply_relation "
     	" WHERE ipolicy = '%s' ", tmp_fulldb, ipolicy);
     	
       	$PREPARE sid001 FROM $stmt_bufX;
     	$EXECUTE sid001 INTO $temp_ipolicy; 
     	    
     printf(" temp_ipolicy[%s]\n", temp_ipolicy);  
     if (SQLCODE == SQLNOTFOUND)
     {
     	if(exitsub(reply,M_CA_NPOLICY) == True) return M_CA_NPOLICY;
        else return apiRC;
     }
     
 $BEGIN WORK;
  
 $INSERT INTO ca_eply_ftp (iyymm, ipolicy, frenew, dftp, icreate, dcreate, iupdate, dupdate) 
 		     VALUES($iyymm, $ipolicy, $frenew, $dftp, $userid, current, $userid, current);
      
 cm_buf_init(ReplyBuf); 		     
 cm_buf_put("%l", M_CM_OK);
 tmp_len=cm_buf_len(ReplyBuf);
 
 if(SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete)== False)
 {
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    return apiRC;
    	
 }
 
 $WHENEVER SQLERROR  GOTO errexit;
 $COMMIT WORK;
 
 return api_OKComplete;

 errexit:
  MsgCode = SQLCODE;
  $WHENEVER SQLERROR CONTINUE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}
/*----------------------------------------------------------------------------*/
long car348_single_query(reply)
serverReply reply;
{  
   $char DBName[DBNAME];
   $char Sipolicy[21];
   $char iyymm[6], ipolicy[21], frenew[2], dftp[20], icreate[11], dcreate[20], iupdate[11], dupdate[20];
   $char ncreate[10], nupdate[10];

   cm_buf_get("%s %s", DBName, Sipolicy);
   
   printf("Squery: ipolicy[%s]\n", Sipolicy);
   
   $WHENEVER SQLERROR GOTO errexit;
   if (db_select(DBName) == False) 
   {
      if(exitsub(reply,M_CM_DB_NOTOPEN) == True)  return M_CM_DB_NOTOPEN;
      else  return apiRC;
   }
   
   $SELECT iyymm, ipolicy, frenew, dftp, icreate, dcreate, iupdate, dupdate 
   INTO $iyymm, $ipolicy, $frenew, $dftp, $icreate, $dcreate, $iupdate, $dupdate
   FROM ca_eply_ftp 
   WHERE ipolicy =$Sipolicy;
         
   if (SQLCODE == SQLNOTFOUND)
   {
       if(exitsub(reply,M_CM_NOT_FOUND) == True) return M_CM_NOT_FOUND;
       else return apiRC;
   }
   
   $SELECT nname
   INTO $ncreate
   FROM officer
   WHERE iofficer = $icreate;
   
   printf("single query _  icreate = %s  ncreate = %s \n ",icreate,ncreate);
   
   $SELECT nname
   INTO $nupdate
   FROM officer
   WHERE iofficer = $iupdate;  
   
   printf("single query _  iupdate = %s  nupdate = %s \n ",iupdate,nupdate);
  
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   cm_buf_put("%s %s %s %s %s %s %s %s", iyymm, ipolicy, frenew, dftp, icreate, dcreate, iupdate, dupdate);
   cm_buf_put("%s %s", ncreate, nupdate);
   
   tmp_len = cm_buf_len(ReplyBuf);
   if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)  return apiRC;
   else return api_OKComplete;

errexit:
printf("<car348_single_query> sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    if(exitsub(reply,SQLCODE) == True) return SQLCODE;
    else return apiRC;
}
/*----------------------------------------------------------------------------*/
long car348_multiple_query(reply)
serverReply reply;
{
	 $char DBName[DBNAME];
     $char Siyymm[6], Sipolicy[21];
     $char iyymm[6], ipolicy[21], frenew[2], dftp[20];
     $char stmt[1024];
     
     char tmpbuf[4000];
     int count=0, repbuf_len=0, tmp_len=0, replycnt=0;
     int total_count=0;
     
     cm_buf_get("%s %s %s", DBName, Siyymm, Sipolicy);
     
     printf("Mquery: iyymm[%s], ipolicy[%s]\n", Siyymm, Sipolicy);
     
     $WHENEVER SQLERROR GOTO errexit;
     
     if (db_select(DBName) == False)
     {
        if(exitsub(reply,M_CM_DB_NOTOPEN) == True) return M_CM_DB_NOTOPEN;
        else return apiRC;
     }
    	 
     sprintf_s(stmt,sizeof stmt,"SELECT iyymm, ipolicy, frenew, dftp "
                  "  FROM ca_eply_ftp "
                  " WHERE iyymm matches '%s' "
                  "   AND ipolicy matches '%s' "
                  " ORDER BY iyymm, ipolicy ", Siyymm, Sipolicy);
                     
     $PREPARE ply_data FROM $stmt;
     $DECLARE ply_cur CURSOR FOR ply_data;
     $OPEN    ply_cur;
     printf("stmt[%s]\n", stmt);
     
    for(;;) 
    {      	
      $FETCH ply_cur INTO $iyymm, $ipolicy, $frenew, $dftp;
    	if (SQLCODE == SQLNOTFOUND) break;
 
    	cm_buf_init(tmpbuf); 
    	if ( count == 0 )
     	{
      	  cm_buf_res_msg();             /* reserve for MsgCode and count */
      	  cm_buf_res_count();          
     	}
    	  cm_buf_put("%s %s %s %s", iyymm, ipolicy, frenew, dftp);
        tmp_len = cm_buf_len(tmpbuf);
    	if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
      {
      	  memcpy(&ReplyBuf[repbuf_len], tmpbuf, tmp_len);
      	  repbuf_len += tmp_len;
      	  count++;
      }
   	  else                               /* more than 4K, send to client side */ 
     	{ 
      	  cm_buf_init(ReplyBuf);
      	  cm_buf_put_msg(M_CM_OK);
      	  cm_buf_put_count(count);
      if (SendSyncReply(reply, ReplyBuf, repbuf_len, api_OK)==False)
      {
	        $CLOSE ply_cur;
          return apiRC;
      }
      else               /* clear ReplyBuf and count to start all over again */
      {
          replycnt++;
          if (replycnt == 10)   /* more than 30K, client cannot display,error */
          {
	  	     cm_buf_init(ReplyBuf);
           cm_buf_put("%l", M_CM_OUT_SPACE);
           tmp_len = cm_buf_len(ReplyBuf);
           if (SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
              return apiRC;
              return M_CM_OUT_SPACE; 
          }
	    ReplyBuf[0] = '\0';
	    count = 0;
	    cm_buf_init(ReplyBuf);
      cm_buf_res_msg();           /* reserve for MsgCode and count */
      cm_buf_res_count();    
      cm_buf_put("%s %s %s %s", iyymm, ipolicy, frenew, dftp);
	    repbuf_len = cm_buf_len(ReplyBuf);
	    count++;
      }
     } 
   } /* for loop */
   $CLOSE ply_cur;
   $FREE  ply_cur;  
  
  if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply, ReplyBuf, repbuf_len, api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
  else            /* break out, not any row is found */
  {
   if(exitsub(reply, M_CM_NOT_FOUND) == True) 
    return M_CM_NOT_FOUND;
   else  
    return apiRC;
  } 

errexit:
printf("<car348_multiple_query> sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  if(exitsub(reply,SQLCODE) == True)  return SQLCODE;
  else return apiRC;
}
/*----------------------------------------------------------------------------*/
long car348_update_exec(reply,command,com_len)
serverReply reply;
voidP command;

int com_len;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table _RR */
 $char iyymm[6], ipolicy[21], frenew[2], dftp[20], userid[11], old_dupdate[21], temp_ipolicy[21];
 $char tmp_fulldb[64];
 /* end of _RR */

 /* standard defined data */
 char option, *pos, *raw_ptr, *malloc(), cur_buf[4000], *comm;
 int tmp_len, raw_len;
 long dummy;
   DBinfo *list;
   int i, j, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[300];
 /* end of standard data */

 /* self defined data */
 long MsgCode;
 /* end of self data */

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);
 
 printf("option=%c DBname=%s \n",option,DBName);
 cm_buf_get("%s %s %s %s %s %s",iyymm, ipolicy, frenew, dftp, old_dupdate, userid);
 strcpy(dftp, rtrim(dftp));
 printf("iyymm[%s], ipolicy[%s], frenew[%s], dftp[%s]",iyymm, ipolicy, frenew, dftp);
 

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply, M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 /* compare old record and current record, if the record has not been changed  
    since last request, update or delete the record, otherwise return errmsg
    to client side */
 
 $BEGIN WORK;  
             
 $SELECT ipolicy
    INTO $temp_ipolicy
    FROM ca_eply_ftp 
   WHERE ipolicy = $ipolicy
     AND dupdate = $old_dupdate;

  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */ 

 if (SQLCODE == SQLNOTFOUND)
 {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply, M_CM_NOT_EQUAL) == True) 
    return M_CM_NOT_EQUAL;
   else  
    return apiRC;
 }
 $WHENEVER SQLERROR GOTO errexit;

 if ( option == 'D' )
 {	
   $DELETE FROM ca_eply_ftp 
     WHERE ipolicy = $ipolicy
       AND dupdate = $old_dupdate;	
   
   if(SQLCODE !=0)
   {
     is_del_fail=1;
   } 
   
   if( is_del_fail ) goto errexit;
   
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l", M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
   {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
   }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
  
 else if (option == 'U')
  {
   $WHENEVER SQLERROR GOTO errexit;
   
   strcpy(tmp_fulldb, get_car_full_db(ipolicy));
   if (strcmp(tmp_fulldb,"") == 0)
   {
   	$ROLLBACK WORK;
   	if(exitsub(reply,M_CA_NPOLICY) == True) return M_CA_NPOLICY;
    else return apiRC;
   }
    	
   $UPDATE ca_eply_ftp
   	   SET (iyymm, ipolicy, frenew, dftp, iupdate, dupdate)
      	   =($iyymm, $ipolicy, $frenew, $dftp, $userid, current)
     WHERE dupdate = $old_dupdate 
       AND ipolicy = $ipolicy;  
       
   printf("UPDATE:iyymm[%s], ipolicy[%s], frenew[%s], dftp[%s]",iyymm, ipolicy, frenew, dftp);    
   
   if(SQLCODE != 0) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l", M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply, ReplyBuf, tmp_len, api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True) 
    return M_CM_WRONG_OPTION;
   else  
    return apiRC;
  } 

 errexit:
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}
/*--------------------------------THE END-------------------------------------*/