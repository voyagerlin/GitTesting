/**********************************************************************/
/*   program id   : ca704q01s.ec                                      */
/*   program name : ���I���鵲�~�Z�έp��                              */
/*   date written : 2000/10/05                                        */
/*   date modify  : 2001/01/29                                        */
/*   files        : ply_relation        i                             */
/*                  edr_relation        i                             */
/*                  sa_frm_module       i                             */
/*                  sa_branch_type      i                             */
/*   temp table   : car704              io                            */
/*                  car704_0            io                            */
/*                  car704_1            io                            */
/*                  car704_2            io                            */
/**********************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
#include "sammsgs.h"
#include "cmnmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
$include datetime.h;
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"

extern char RPTDIR[];

$char ibranch[6];

$long qorder;
$char igroup[6];
$char ngroup[21];
$char qindent[2];

$long sub_mprem_A;
$long sub_qcnt_A;
$long sub_mprem_B;
$long sub_qcnt_B;
$long sub_mprem_C;
$long sub_qcnt_C;

$long sum_mprem_A;
$long sum_qcnt_A;
$long sum_mprem_B;
$long sum_qcnt_B;
$long sum_mprem_C;
$long sum_qcnt_C;

$char DBName[05], FormTp[03];
char  outputf[N_FILE+1], userid[11];
int fHasData=0, fFindData=0, fFirstData=1;
static int max_cnt=0;

long car704_build();
long car704_detail();
long car704_accumulate();
void car704_title();
char isclose[2],formtype[11],fIsdtl[2],iofficer_input[20],iroute_input[20];	
char sTmpSql_P[200], sTmpSql_E[200],sTmpSql_iofc[200], sTmpSql_irou[200];
char  sFileName[51], sFullFileName[121];
char  sFileNameDtl[51], sFullFileNameDtl[121];
char   sApHome[51];
$char  sMsg[512];
FILE   *fptr1, *fptr2, *sfp;
int    rc;
long   rtncode;
$char  FormFmt[N_FILE+1], today_7[11];
$int   StartRow, TitleRow, TotColumn, PgLine, Width;
char   FormFile[N_FILE+1],filetype[30];
int    i, rcd;
$char   stmt[1024];

/*�`��*/
    $long Total;
    $long Qorder;
    $char Igroup[6], Ngroup[21];
    $long Mprem_A, Qcnt_A;
    $long Mprem_B, Qcnt_B;
    $long Mprem_C, Qcnt_C;
    $long Total_mprem, Total_qcnt;
    $long Tot_mprem_A, Tot_qcnt_A;
    $long Tot_mprem_B, Tot_qcnt_B;
    $long Tot_mprem_C, Tot_qcnt_C;
    $long Sum_tot_mprem, Sum_tot_qcnt;
/*���Ӫ�*/    
    $long Total;
    $long Qorder;
    $char Igroup[6], Ngroup[21];
    $long Mprem_A, Qcnt_A;
    $long Mprem_B, Qcnt_B;
    $long Mprem_C, Qcnt_C;
    $long Total_mprem, Total_qcnt;
    $long Tot_mprem_A, Tot_qcnt_A;
    $long Tot_mprem_B, Tot_qcnt_B;
    $long Tot_mprem_C, Tot_qcnt_C;
    $long Sum_tot_mprem, Sum_tot_qcnt;
    $char   stmt2[2048],cnt[5];
    $char ipolicy[20],ilast_ply[20],dpolicy[11],itag[10],iengine[20],nassured[20],dply_begin[11],dply_end[11],iofficer[20],iroute[20],nname[20],ileader[20],nbranch[30],mprem[15];


/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;

    batchinit();
    strcpy(DBName, 	    isNULLstr(argv[1]));
    strcpy(userid, 	    isNULLstr(argv[2]));
    strcpy(ibranch, 	    isNULLstr(argv[3]));
    strcpy(fIsdtl,  	    isNULLstr(argv[4]));        /* 1:�`�� 2:���Ӫ� */
    strcpy(isclose, 	    isNULLstr(argv[5]));	/* �w/���鵲 0:���鵲 1:�w�鵲 */
    strcpy(iofficer_input,  isNULLstr(argv[6]));        /* �g��N��*/
    strcpy(iroute_input,    isNULLstr(argv[7]));        /* �q���N��*/
    strcpy(outputf, 	    isNULLstr(argv[8]));
    

    rc = car704_build();
    

}
/*----------------------------------------------------------------------------*/
long car704_build()
{


    


    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        return M_CM_DB_NOTOPEN;
    }
    


    $SELECT nForm_File, kStart_Row, kTitle_Row,
            kTot_Col, kPgNum_Line, kWidth, iForm_Tp,to_char(today-7)
       INTO $FormFmt, $StartRow, $TitleRow,
            $TotColumn, $PgLine, $Width, $FormTp,  $today_7
       FROM Form
      WHERE ksys_grp = "CA" AND kPgmID = 704;
      
      
    char yy[3], mm[3], dd[3];
    cm_split_ymd(cm_from_infdate(today_7),yy,mm,dd);

    if(strcmp(isclose,"0")==0)
    {
        sprintf(filetype,"%s%s%s~%s%s%s ���鵲",cm_sysd_cyear(cm_from_infdate(today_7)),mm,dd
                                     ,cm_sysd_cyear(cm_get_sysd( )),cm_sysd_mon(cm_get_sysd( )),cm_sysd_day(cm_get_sysd( )));
    }
    else
    {
    	sprintf(filetype,"%s%s%s �w�鵲",cm_sysd_cyear(cm_get_sysd( )),cm_sysd_mon(cm_get_sysd( )),cm_sysd_day(cm_get_sysd( )));
    }    
    
    

    /* create & insert data with temp table */
    car704_accumulate(); 
      
    /* build report */
    if(strcmp(fIsdtl,"1")==0){
    	
         strcpy(FormFmt, rtrim(FormFmt));
         sprintf(FormFile, "%s.tx", outputf); 
         rgu_init_report(FormFmt, FormFile);   
         car704_title();         
         car704_detail();        /*�`��*/
         rgu_finish_report();
    
          if ((rc=save_form_info(F_FREE, "CA", 704, userid, FormTp, max_cnt,
               outputf))<0)
              EWRITE(userid, rc, "save_form_info failed");    	

    }
    else
    {
    
         strcpy(FormFmt, rtrim(FormFmt));
         sprintf(FormFile, "%s.tx", outputf); 
         rgu_init_report(FormFmt, FormFile);   
         car704_title();         
         car704_dtl_detail();        /*���Ӫ�*/
         rgu_finish_report();
    
          if ((rc=save_form_info(F_FREE, "CA", 704, userid, FormTp, max_cnt,
               outputf))<0)
              EWRITE(userid, rc, "save_form_info failed");    	    
    
    
    }


    return api_OKComplete;








errexit:
    printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return FAIL;
}
/*----------------------------------------------------------------------------*/
long car704_accumulate()
{
    int     k, count_db;

    DBinfo  *list;

    $long qorder; 
    $char igroup[6], ngroup[21] ,qindent[2],cnt[5];
    $char igroup_edr[6], fcard_class_edr[2], fedr_class_edr[2];
    $long prem_edr, cnt_edr;
    $char iofficer_edr[2];

    $long mprem_A, mprem_B, mprem_C;
    $long qcnt_A, qcnt_B, qcnt_C;

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;

    if (db_select(DBName) == FALSE)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }

    $create temp table car704_0
    (
        igroup          char(5),
        fcard_class     char(1),
        prem            integer,
        cnt             integer,
        iofficer        char(10)
    )with no log;

    $create temp table car704_1
    (   
        qorder          integer,
        igroup          char(5),
        ngroup          char(20),
        qindent         char(1),
        mprem           integer,
        qcnt            integer
    )with no log;

/* Temp table car704_2_1 is for �g�P�� */
    $create temp table car704_2_1
    (   
        qorder          integer,
        igroup          char(5),
        ngroup          char(20),
        qindent         char(1),
        mprem           integer,
        qcnt            integer,
        sofficer        char(1)
    )with no log;
    
/* Temp table car704_2_1 is for �D�g�P�� */
    $create temp table car704_2_2
    (   
        qorder          integer,
        igroup          char(5),
        ngroup          char(20),
        qindent         char(1),
        mprem           integer,
        qcnt            integer,
        sofficer        char(1)
    )with no log;

    $create temp table car704
    ( 
        qorder          integer, 
        igroup          char(5),
        ngroup          char(20),
        qindent         char(1),
        mprem_A         integer,
        qcnt_A          integer,
        mprem_B         integer,
        qcnt_B          integer,
        mprem_C         integer,
        qcnt_C          integer
    ) with no log;

    /*���Ӫ�*/
    $create temp table car704_dtl
    ( 
        data_class 	char(1),    /*1:�j��A2:�g�P�ӥ��N�A3:�D���ӥ��N*/
        ipolicy		char(20),
        ilast_ply	char(20),
        dpolicy		char(11),
        itag		char(10),
        iengine		char(20),
        nassured	char(20),
        dply_begin	char(11),
        dply_end	char(11),
        iofficer	char(20),
        iroute		char(20),
        nname		char(20),
        ileader		char(20),
        nbranch		char(30),
        mprem		char(15),
        Igroup		char(5)
    ) with no log;

    if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;
    }

		sTmpSql_P[0]='\0';
		sTmpSql_E[0]='\0';
		if (strcmp(isclose,"0") == 0)
		{	printf("---- ���鵲 ---[%s] \n",isclose);
				/* ���鵲 */
				strcpy(sTmpSql_P, "and a.dpolicy >= (today-7) and a.dpolicy <= today  and a.dply_close is null ");   /*and a.dpolicy >= (today-7) and a.dpolicy <= today */
				strcpy(sTmpSql_E, "and a.dendorse >= (today-7) and a.dendorse <= today and a.dedr_close is null "); /*and a.dendorse >= (today-7) and a.dendorse <= today */
				strcpy(formtype, " ���鵲 ");
		}
		else
		{	printf("---- �w�鵲 ---[%s] \n",isclose);
				/* ����w�鵲 */
				strcpy(sTmpSql_P, "and a.dpolicy = today and a.dply_close is not null "); /*and a.dpolicy = today */
				strcpy(sTmpSql_E, "and a.dendorse = today and a.dedr_close is not null ");/*and a.dendorse = today */
				strcpy(formtype, "����w�鵲");
		}
		printf("sTmpSql_P=[%s]\n",sTmpSql_P);
		printf("sTmpSql_E=[%s]\n",sTmpSql_E);
		
		sTmpSql_iofc[0]='\0';
		sTmpSql_irou[0]='\0';		
		
		if(strcmp(iofficer_input,"*") != 0)
		{
			sprintf(sTmpSql_iofc," and a.iofficer matches '%s' ",trim(iofficer_input));
		}
		if(strcmp(iroute_input,"*") != 0)
		{
			sprintf(sTmpSql_irou," and d.iroute matches '%s' ",trim(iroute_input));
		}
		
		
    for(k=0;k<count_db;k++)
    {
    
    /*--- Ū�O���� ---*/
        sprintf(stmt,
               "insert into car704_0 \
                 (igroup,fcard_class,prem,cnt,iofficer) \
                select b.igroup,a.fcard_class,sum(a.mdmg_prem+a.mlia_prem),count(*),c.imgr \
                  from %s:ply_relation a,sa_branch_type b, officer c ,%s:policy d \
                 where 1 = 1 %s %s %s \
                   and a.iquota[1,4] || '00' = b.ibranch \
                   and a.iquota[1,4] matches ? \
                   and c.iofficer = a.iofficer and a.ipolicy=d.ipolicy \
                 group by b.igroup,a.fcard_class,c.imgr", list[k].dbname, list[k].dbname, sTmpSql_P,sTmpSql_iofc, sTmpSql_irou  ); 
                 /**/
        printf("%s\n",stmt);
        $prepare pre_cur1 from $stmt;
        $execute pre_cur1 using $ibranch;

    /*--- Ū����� ---*/
        sprintf(stmt,
             "insert into car704_0 \
               (igroup,fcard_class,prem,cnt,iofficer) \
              select b.igroup,a.fcard_class,sum(a.medrdmg_prem+a.medrlia_prem), \
                sum(a.qcount),c.imgr \
                from %s:edr_relation a,sa_branch_type b, officer c ,%s:endorsement d\
                 where 1 = 1 %s %s %s \
                   and a.iquota[1,4] || '00' = b.ibranch \
                   and a.iquota[1,4] matches ? \
                   and c.iofficer = a.iofficer and a.iendorse=d.iendorse \
                 group by b.igroup,a.fcard_class,c.imgr", list[k].dbname, list[k].dbname,sTmpSql_E,sTmpSql_iofc, sTmpSql_irou  );
                 /*sTmpSql_iofc, sTmpSql_irou*/
        printf("%s\n",stmt);
        $prepare pre_cur2 from $stmt;
        $execute pre_cur2 using $ibranch;
          
    }



    if (ibranch[0] !='*')
    {
        $insert into car704_1
               (qorder,igroup,ngroup,qindent,mprem,qcnt)
         select b.qorder,b.igroup,b.ngroup,b.qindent,nvl(sum(prem),0),nvl(sum(cnt),0)
           from sa_frm_module b,outer car704_0 a
          where a.igroup=b.igroup
            and b.ifrm_module ='01'
            and fcard_class ='1'
          group by 1,2,3,4;
           

        /* Separate different selling channels by using table.field [officer.imgr] */ 
        $insert into car704_2_1
               (qorder,igroup,ngroup,qindent,mprem,qcnt,sofficer)
         select b.qorder,b.igroup,b.ngroup,b.qindent,nvl(sum(prem),0),nvl(sum(cnt),0),a.iofficer
           from sa_frm_module b,outer car704_0 a
          where a.igroup=b.igroup
            and b.ifrm_module ='01'
            and fcard_class ='2'
            and a.iofficer = '1'
          group by 1,2,3,4,a.iofficer;

  
  	$insert into car704_2_2
               (qorder,igroup,ngroup,qindent,mprem,qcnt,sofficer)
         select b.qorder,b.igroup,b.ngroup,b.qindent,nvl(sum(prem),0),nvl(sum(cnt),0),a.iofficer
           from sa_frm_module b,outer car704_0 a
          where a.igroup=b.igroup
            and b.ifrm_module ='01'
            and fcard_class ='2'
            and a.iofficer = '2'
          group by 1,2,3,4,a.iofficer;
          
          

          

    }
    else
    {
        $insert into car704_1
               (qorder,igroup,ngroup,qindent,mprem,qcnt)
         select b.qorder,b.igroup,b.ngroup,b.qindent,nvl(sum(prem),0),nvl(sum(cnt),0)
           from sa_frm_module b,outer car704_0 a
          where a.igroup=b.igroup
            and b.ifrm_module ='01'
            and fcard_class ='1'
          group by 1,2,3,4;

	  /* Separate different selling channels by using table.field [officer.imgr] */ 
          $insert into car704_2_1
               (qorder,igroup,ngroup,qindent,mprem,qcnt,sofficer)
         select b.qorder,b.igroup,b.ngroup,b.qindent,nvl(sum(prem),0),nvl(sum(cnt),0),a.iofficer
           from sa_frm_module b, outer car704_0 a
          where a.igroup=b.igroup
            and b.ifrm_module ='01'
            and fcard_class ='2'
            and a.iofficer = '1'
          group by 1,2,3,4,a.iofficer;
          
           
          $insert into car704_2_2
               (qorder,igroup,ngroup,qindent,mprem,qcnt,sofficer)
         select b.qorder,b.igroup,b.ngroup,b.qindent,nvl(sum(prem),0),nvl(sum(cnt),0),a.iofficer
           from sa_frm_module b, outer car704_0 a
          where a.igroup=b.igroup
            and b.ifrm_module ='01'
            and fcard_class ='2'
            and a.iofficer = '2'
          group by 1,2,3,4,a.iofficer;
          
    }
    
    
    

    	strcpy(stmt,"select a.qorder,a.igroup,a.ngroup,a.qindent,nvl(a.mprem,0),nvl(a.qcnt,0),nvl(b.mprem,0),nvl(b.qcnt,0),nvl(c.mprem,0),nvl(c.qcnt,0) "
                "  from car704_1 a, outer car704_2_1 b, outer car704_2_2 c "
                " where a.qorder=b.qorder and a.qorder=c.qorder "
                " order by qorder;");
    

    
    
                
                
                
                
    $prepare tmp from $stmt;            
    $declare cur1 cursor for tmp;




    $open cur1;

    while(1)
    {
        $fetch cur1 into $qorder, $igroup, $ngroup, $qindent, $mprem_A, $qcnt_A, $mprem_B, $qcnt_B, $mprem_C, $qcnt_C;
        

        
        if(SQLCODE == SQLNOTFOUND) break;

        
        if ( strcmp(trim(igroup),"YYY")==0 && strcmp(trim(qindent),"1")==0 )
        { 
            printf("YYY-1\n");
            sum_mprem_A += sub_mprem_A;
            sum_qcnt_A += sub_qcnt_A;
            sum_mprem_B += sub_mprem_B;
            sum_qcnt_B += sub_qcnt_B;
            sum_mprem_C += sub_mprem_C;
            sum_qcnt_C += sub_qcnt_C;
            sub_mprem_A = 0;
            sub_qcnt_A = 0;
            sub_mprem_B = 0;
            sub_qcnt_B = 0;
            sub_mprem_C = 0;
            sub_qcnt_C = 0;
        }
        else if ( strcmp(trim(igroup),"YYY")==0 && strcmp(trim(qindent),"0")==0 )
        { 
            printf("YYY-0\n");
            $insert into car704
                       ( qorder, igroup, ngroup, mprem_A, qcnt_A,
                         mprem_B, qcnt_B, mprem_C, qcnt_C )
                values ( $qorder, $igroup, $ngroup, $sub_mprem_A, $sub_qcnt_A,
                         $sub_mprem_B, $sub_qcnt_B, $sub_mprem_C, $sub_qcnt_C );

            sum_mprem_A += sub_mprem_A;
            sum_qcnt_A += sub_qcnt_A;
            sum_mprem_B += sub_mprem_B;
            sum_qcnt_B += sub_qcnt_B;
            sum_mprem_C += sub_mprem_C;
            sum_qcnt_C += sub_qcnt_C;
            sub_mprem_A = 0;
            sub_qcnt_A = 0;
            sub_mprem_B = 0;
            sub_qcnt_B = 0;
            sub_mprem_C = 0;
            sub_qcnt_C = 0;
        }
        else if ( strcmp(trim(igroup),"ZZZ")==0 && strcmp(trim(qindent),"1")==0 )
        { 
            printf("ZZZ-1\n");
        }
        else if ( strcmp(trim(igroup),"ZZZ")==0 && strcmp(trim(qindent),"0")==0 )
        {
            printf("ZZZ-0\n");
            $insert into car704
                       ( qorder, igroup, ngroup, mprem_A, qcnt_A,
                         mprem_B, qcnt_B, mprem_C, qcnt_C )
                values ( $qorder, $igroup, $ngroup, $sum_mprem_A, $sum_qcnt_A,
                         $sum_mprem_B, $sum_qcnt_B, $sum_mprem_C, $sum_qcnt_C );
            sum_mprem_A = 0;
            sum_qcnt_A = 0;
            sum_mprem_B = 0;
            sum_qcnt_B = 0;
            sum_mprem_C = 0;
            sum_qcnt_C = 0;
        }        
        else
        { 
            printf("AAA\n");
            $insert into car704
                       ( qorder, igroup, ngroup, mprem_A, qcnt_A, mprem_B, qcnt_B, mprem_C, qcnt_C )
                values ( $qorder, $igroup, $ngroup, $mprem_A, $qcnt_A, $mprem_B, $qcnt_B, $mprem_C, $qcnt_C );

                sub_mprem_A += mprem_A;
                sub_qcnt_A += qcnt_A;
                sub_mprem_B += mprem_B;
                sub_qcnt_B += qcnt_B;
                sub_mprem_C += mprem_C;
                sub_qcnt_C += qcnt_C;
                
                
        }

    } /* end of while */
    $close cur1;
    $free  cur1;

    $SET LOCK MODE TO NOT WAIT;
    return SUCCESS;

errexit:
    printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    exit(1);
}

/*----------------------------------------------------------------------------*/
void car704_title()
{
    
    
    rgu_put_body_string(11, filetype, 1);
    rgu_put_body_string(11, cm_sysd_cdatetime_100(cm_get_sysd()), 1);
    rgu_put_body_string(11, ibranch, 1);
    rgu_put_body_string(11, iofficer_input, 1);
    rgu_put_body_string(11, iroute_input, 1);
    rgu_put_body(11); max_cnt += 5; 
}

/*----------------------------------------------------------------------------*/
long car704_detail()  /*�`��*/
{
    /*$long Total;
    $long Qorder;
    $char Igroup[6], Ngroup[21];
    $long Mprem_A, Qcnt_A;
    $long Mprem_B, Qcnt_B;
    $long Mprem_C, Qcnt_C;
    $long Total_mprem, Total_qcnt;
    $long Tot_mprem_A, Tot_qcnt_A;
    $long Tot_mprem_B, Tot_qcnt_B;
    $long Tot_mprem_C, Tot_qcnt_C;
    $long Sum_tot_mprem, Sum_tot_qcnt;*/

    char tmp_buf[16];

    $WHENEVER SQLERROR GOTO errexit;
    
    rgu_put_body(1);
    


    
    

      $declare cursor cursor for
      select qorder, igroup, ngroup, mprem_A, qcnt_A, mprem_B, qcnt_B, mprem_C, qcnt_C 
        into $Qorder, $Igroup, $Ngroup, $Mprem_A, $Qcnt_A, $Mprem_B, $Qcnt_B, $Mprem_C, $Qcnt_C 
        from car704
       order by qorder;    	
       $open cursor;    	
    






    while(1)
    {

        $fetch cursor;
        



        if(SQLCODE == SQLNOTFOUND ) 
        {
            if(ibranch[0] !='*')
            {
            	
        	sprintf(stmt,"SELECT nbranch FROM sa_branch_type WHERE dexpire IS NULL AND ibranch= '%s00' ",trim(ibranch));
        	$prepare pre_cur3 from $stmt;
                $execute pre_cur3 INTO $Ngroup;
                
                Qcnt_A=0;
                Qcnt_B=0;
                Qcnt_C=0;   	
                Mprem_A=0;
                Mprem_B=0;
                Mprem_C=0;
                
        	Total_mprem = Mprem_A + Mprem_B + Mprem_C;
        	Total_qcnt = Qcnt_A + Qcnt_B + Qcnt_C;
        

        	rgu_put_body_string(2, Ngroup, 1);
        
        	rfmtlong(Qcnt_A, "-------&", tmp_buf);
        	rgu_put_body_string(2, tmp_buf, 2);

        	rfmtlong(Mprem_A, "------------&", tmp_buf);
        	rgu_put_body_string(2, tmp_buf, 2);

        	rfmtlong(Qcnt_B, "-------&", tmp_buf);
        	rgu_put_body_string(2, tmp_buf, 2);

        	rfmtlong(Mprem_B, "------------&", tmp_buf);
        	rgu_put_body_string(2, tmp_buf, 2);
        
        	rfmtlong(Qcnt_C, "-------&", tmp_buf);
        	rgu_put_body_string(2, tmp_buf, 2);

        	rfmtlong(Mprem_C, "------------&", tmp_buf);
        	rgu_put_body_string(2, tmp_buf, 2);

        	rfmtlong(Total_qcnt, "--------&", tmp_buf);
        	rgu_put_body_string(2, tmp_buf, 2);

        	rfmtlong(Total_mprem, "------------&", tmp_buf);
        	rgu_put_body_string(2, tmp_buf, 2);

        	rgu_put_body(2); max_cnt ++;
        	break;
            }
            else
            {
            	break;
            }
            
	    

        }
         
        /*--- ��X�C�@�檺�X�pñ��O�O ---*/

        Total_mprem = Mprem_A + Mprem_B + Mprem_C;
        Total_qcnt = Qcnt_A + Qcnt_B + Qcnt_C;
        
        /*if (strcmp(trim(Igroup),"ZZZ")==0)
        {
            continue;
        }*/
        
        if(ibranch[0] !='*')  /*�~�Z���D��J�u*�v*/
        {
            $char tmp[10];
            sprintf(stmt,"SELECT igroup FROM sa_branch_type WHERE dexpire IS NULL AND ibranch= '%s00' ",trim(ibranch));
            $prepare tmp from $stmt;
            $execute tmp INTO $tmp;
            
            
            if(atoi(Igroup)==atoi(tmp)) /*�u�L�X�ŦX���󪺳�쪺���@�C*/
            {
            	if(atoi(ibranch)!=atoi(tmp))   /*�]���`���N�`���q�����Ҧ�����k�ݦb�P�@���A�ҥH���n�d���`���q�����䤤�@�ӷ~�Z���ɡA�h����ܸӳ�쪺����*/
            	{
            	    sprintf(stmt,"SELECT nbranch FROM sa_branch_type WHERE dexpire IS NULL AND ibranch= '%s00' ",trim(ibranch));
                    $prepare pre_cur3 from $stmt;
                    $execute pre_cur3 INTO $Ngroup; 
                    
                    if(SQLCODE == SQLNOTFOUND ) strcpy(Ngroup," ");
                    
                    car704_detail_print();

                    break;              		
            		
            	}
            	else
            	{
                    car704_detail_print();
                    break;            		
            		
            	}

            }
        }
        else     /*�~�Z����J�u*�v�A�L�X����*/
        {
            car704_detail_print();       	
        }	
        

        
        /*if(ibranch[0] !='*') break;*/
        
       
    }
    $close cursor;
    $free  cursor;
    
    

    /*--- �L�X�̫�@�C�X�p��� ---*/
    $select nvl(SUM(mprem_A),0), nvl(SUM(qcnt_A),0), nvl(SUM(mprem_B),0), nvl(SUM(qcnt_B),0), nvl(SUM(mprem_C),0), nvl(SUM(qcnt_C),0)
       into $Tot_mprem_A, $Tot_qcnt_A, $Tot_mprem_B, $Tot_qcnt_B, $Tot_mprem_C, $Tot_qcnt_C 
       from car704
      where igroup != "YYY" 
        and igroup != "ZZZ";  

    if (SQLCODE == SQLNOTFOUND)
    {
 
        printf("[car704_detail] car704 not found !!\n") ;
        EWRITE(userid, M_CM_NOT_FOUND, "car704");
        exit(1);
    }

    Sum_tot_mprem = Tot_mprem_A + Tot_mprem_B + Tot_mprem_C;
    Sum_tot_qcnt = Tot_qcnt_A + Tot_qcnt_B + Tot_qcnt_C;

    
    strcpy(ngroup, "�`  �p");
    rgu_put_body_string(3, ngroup, 1);
    
    rfmtlong(Tot_qcnt_A, "--------&", tmp_buf);
    rgu_put_body_string(3, tmp_buf, 2);

    rfmtlong(Tot_mprem_A, "------------&", tmp_buf);
    rgu_put_body_string(3, tmp_buf, 2);

    rfmtlong(Tot_qcnt_B, "--------&", tmp_buf);
    rgu_put_body_string(3, tmp_buf, 2);

    rfmtlong(Tot_mprem_B, "------------&", tmp_buf);
    rgu_put_body_string(3, tmp_buf, 2);
    
    rfmtlong(Tot_qcnt_C, "--------&", tmp_buf);
    rgu_put_body_string(3, tmp_buf, 2);

    rfmtlong(Tot_mprem_C, "------------&", tmp_buf);
    rgu_put_body_string(3, tmp_buf, 2);

    rfmtlong(Sum_tot_qcnt, "--------&", tmp_buf);
    rgu_put_body_string(3, tmp_buf, 2);

    rfmtlong(Sum_tot_mprem, "------------&", tmp_buf);
    rgu_put_body_string(3, tmp_buf, 2);

    rgu_put_body(3); max_cnt ++; 
    

    return SUCCESS;
   


  
errexit:
    printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    exit(1);
}
/*----------------------------------------------------------------------------*/
long car704_dtl_detail()
{
    /*$long Total;
    $long Qorder;
    $char Igroup[6], Ngroup[21];
    $long Mprem_A, Qcnt_A;
    $long Mprem_B, Qcnt_B;
    $long Mprem_C, Qcnt_C;
    $long Total_mprem, Total_qcnt;
    $long Tot_mprem_A, Tot_qcnt_A;
    $long Tot_mprem_B, Tot_qcnt_B;
    $long Tot_mprem_C, Tot_qcnt_C;
    $long Sum_tot_mprem, Sum_tot_qcnt;*/
    int     k, count_db;
    DBinfo  *list;
/*    $char   stmt2[1024],cnt[5];
    $char ipolicy[20],ilast_ply[20],dpolicy[11],itag[10],iengine[20],nassured[20],dply_begin[11],dply_end[11],iofficer[20],iroute[20],nname[20],ileader[20],nbranch[30],mprem[15];
*/
    char tmp_buf[16];

    $WHENEVER SQLERROR GOTO errexit;

    if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
    {
        EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
        return M_CM_NOT_DBLIST;
    }

    for(k=0;k<count_db;k++)  
    {
         /*�j��*/        	
        sprintf(stmt2,"INSERT INTO car704_dtl "
        	      " SELECT  '1',a.ipolicy,nvl(a.ilast_ply,''),to_char(a.dpolicy),''''||d.itag,''''||d.iengine,d.nassured,to_char(a.dply_begin),to_char(a.dply_end),''''||a.iofficer,d.iroute,"
                      "         (SELECT nname FROM officer WHERE iofficer=a.iofficer),(SELECT nname FROM officer WHERE iofficer=a.ileader),"
                      "         (SELECT nbranch FROM sa_branch_type WHERE ibranch=(SELECT iquota FROM officer WHERE iofficer=a.ileader)),a.mdmg_prem+a.mlia_prem, "
                      "         (SELECT igroup from sa_branch_type where ibranch=(select iquota from %s:ply_relation where ipolicy=a.ipolicy) )  "
                      "   FROM  %s:ply_relation a,sa_branch_type b, officer c ,%s:policy d"
                      "  WHERE  1 = 1  %s %s %s "
                      "    AND  a.iquota[1,4] || '00' = b.ibranch" 
                      "    AND  a.iquota[1,4] matches '%s' "
                      "    AND  c.iofficer = a.iofficer " 
                      "    AND  a.fcard_class='1' "
                      "    AND  a.ipolicy=d.ipolicy ",list[k].dbname,list[k].dbname,list[k].dbname,sTmpSql_P, sTmpSql_iofc, sTmpSql_irou,ibranch);
        $prepare pre2 from $stmt2;
        $execute pre2 ;
        printf("%s\n",stmt2);			
        sprintf(stmt2,"INSERT INTO car704_dtl "
        	      " SELECT  '1',a.ipolicy,nvl((SELECT ilast_ply FROM %s:ply_relation WHERE ipolicy=a.ipolicy),''),  "
        	      "         to_char((SELECT dpolicy FROM %s:ply_relation WHERE ipolicy=a.ipolicy)),''''||d.itag,''''||d.iengine,d.nassured,   "
        	      "         to_char((SELECT dply_begin FROM %s:ply_relation WHERE ipolicy=a.ipolicy)),to_char((SELECT dply_end FROM %s:ply_relation WHERE ipolicy=a.ipolicy)),''''||a.iofficer,d.iroute, "
                      "         (SELECT nname FROM officer WHERE iofficer=a.iofficer),(SELECT nname FROM officer WHERE iofficer=a.ileader),"
                      "         (SELECT nbranch FROM sa_branch_type WHERE ibranch=(SELECT iquota FROM officer WHERE iofficer=a.ileader)),a.medrdmg_prem+a.medrlia_prem, "
                      "         (SELECT igroup from sa_branch_type where ibranch=(select iquota from %s:ply_relation where ipolicy=a.ipolicy) )  "
                      "   FROM  %s:edr_relation a,sa_branch_type b, officer c ,%s:endorsement d"
                      "  WHERE  1 = 1  %s %s %s"
                      "    AND  a.iquota[1,4] || '00' = b.ibranch" 
                      "    AND  a.iquota[1,4] matches '%s' "
                      "    AND  c.iofficer = a.iofficer " 
                      "    AND  a.fcard_class='1' "
                      "    AND  a.iendorse=d.iendorse ",list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,sTmpSql_E, sTmpSql_iofc, sTmpSql_irou,ibranch);
        $prepare pre2 from $stmt2;
        $execute pre2 ;
        printf("%s\n",stmt2);
        /*�g�P�ӥ��N*/	
        sprintf(stmt2,"INSERT INTO car704_dtl "
        	      " SELECT  '2',a.ipolicy,nvl(a.ilast_ply,''),to_char(a.dpolicy),''''||d.itag,''''||d.iengine,d.nassured,to_char(a.dply_begin),to_char(a.dply_end),''''||a.iofficer,d.iroute,"
                      "         (SELECT nname FROM officer WHERE iofficer=a.iofficer),(SELECT nname FROM officer WHERE iofficer=a.ileader),"
                      "         (SELECT nbranch FROM sa_branch_type WHERE ibranch=(SELECT iquota FROM officer WHERE iofficer=a.ileader)),a.mdmg_prem+a.mlia_prem, "
                      "         (SELECT igroup from sa_branch_type where ibranch=(select iquota from %s:ply_relation where ipolicy=a.ipolicy) )  "
                      "   FROM  %s:ply_relation a,sa_branch_type b, officer c ,%s:policy d"
                      "  WHERE  1 = 1  %s %s %s"
                      "    AND  a.iquota[1,4] || '00' = b.ibranch" 
                      "    AND  a.iquota[1,4] matches '%s' "
                      "    AND  c.iofficer = a.iofficer " 
                      "    AND  a.fcard_class='2' AND  c.imgr='1' "
                      "    AND  a.ipolicy=d.ipolicy ",list[k].dbname,list[k].dbname,list[k].dbname,sTmpSql_P, sTmpSql_iofc, sTmpSql_irou,ibranch);
        $prepare pre2 from $stmt2;
        $execute pre2 ;
        			
        sprintf(stmt2,"INSERT INTO car704_dtl "
        	      " SELECT  '2',a.ipolicy,nvl((SELECT ilast_ply FROM %s:ply_relation WHERE ipolicy=a.ipolicy),''), "
        	      "         to_char((SELECT dpolicy FROM %s:ply_relation WHERE ipolicy=a.ipolicy)),''''||d.itag,''''||d.iengine,d.nassured,   "
        	      "         to_char((SELECT dply_begin FROM %s:ply_relation WHERE ipolicy=a.ipolicy)),to_char((SELECT dply_end FROM %s:ply_relation WHERE ipolicy=a.ipolicy)),''''||a.iofficer,d.iroute, "
                      "         (SELECT nname FROM officer WHERE iofficer=a.iofficer),(SELECT nname FROM officer WHERE iofficer=a.ileader),"
                      "         (SELECT nbranch FROM sa_branch_type WHERE ibranch=(SELECT iquota FROM officer WHERE iofficer=a.ileader)),a.medrdmg_prem+a.medrlia_prem, "
                      "         (SELECT igroup from sa_branch_type where ibranch=(select iquota from %s:ply_relation where ipolicy=a.ipolicy) )  "
                      "   FROM  %s:edr_relation a,sa_branch_type b, officer c ,%s:endorsement d"
                      "  WHERE  1 = 1  %s %s %s"
                      "    AND  a.iquota[1,4] || '00' = b.ibranch" 
                      "    AND  a.iquota[1,4] matches '%s' "
                      "    AND  c.iofficer = a.iofficer " 
                      "    AND  a.fcard_class='2' AND  c.imgr='1' "
                      "    AND  a.iendorse=d.iendorse ",list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,sTmpSql_E, sTmpSql_iofc, sTmpSql_irou,ibranch);
        $prepare pre2 from $stmt2;
        $execute pre2 ;    
        
        /*�D���ӥ��N*/ 
        sprintf(stmt2,"INSERT INTO car704_dtl "
        	      " SELECT  '3',a.ipolicy,nvl(a.ilast_ply,''),to_char(a.dpolicy),''''||d.itag,''''||d.iengine,d.nassured,to_char(a.dply_begin),to_char(a.dply_end),''''||a.iofficer,d.iroute,"
                      "         (SELECT nname FROM officer WHERE iofficer=a.iofficer),(SELECT nname FROM officer WHERE iofficer=a.ileader),"
                      "         (SELECT nbranch FROM sa_branch_type WHERE ibranch=(SELECT iquota FROM officer WHERE iofficer=a.ileader)),a.mdmg_prem+a.mlia_prem, "
                      "         (SELECT igroup from sa_branch_type where ibranch=(select iquota from %s:ply_relation where ipolicy=a.ipolicy) )  "
                      "   FROM  %s:ply_relation a,sa_branch_type b, officer c ,%s:policy d"
                      "  WHERE  1 = 1  %s %s %s"
                      "    AND  a.iquota[1,4] || '00' = b.ibranch" 
                      "    AND  a.iquota[1,4] matches '%s' "
                      "    AND  c.iofficer = a.iofficer " 
                      "    AND  a.fcard_class='2' AND  c.imgr='2' "
                      "    AND  a.ipolicy=d.ipolicy ",list[k].dbname,list[k].dbname,list[k].dbname,sTmpSql_P, sTmpSql_iofc, sTmpSql_irou,ibranch);
        $prepare pre2 from $stmt2;
        $execute pre2 ;
        			
        sprintf(stmt2,"INSERT INTO car704_dtl "
        	      " SELECT  '3',a.ipolicy,nvl((SELECT ilast_ply FROM %s:ply_relation WHERE ipolicy=a.ipolicy),''),   "
        	      "         to_char((SELECT dpolicy FROM %s:ply_relation WHERE ipolicy=a.ipolicy)),''''||d.itag,''''||d.iengine,d.nassured,   "
        	      "         to_char((SELECT dply_begin FROM %s:ply_relation WHERE ipolicy=a.ipolicy)),to_char((SELECT dply_end FROM %s:ply_relation WHERE ipolicy=a.ipolicy)),''''||a.iofficer,d.iroute, "
                      "         (SELECT nname FROM officer WHERE iofficer=a.iofficer),(SELECT nname FROM officer WHERE iofficer=a.ileader),"
                      "         (SELECT nbranch FROM sa_branch_type WHERE ibranch=(SELECT iquota FROM officer WHERE iofficer=a.ileader)),a.medrdmg_prem+a.medrlia_prem, "
                      "         (SELECT igroup from sa_branch_type where ibranch=(select iquota from %s:ply_relation where ipolicy=a.ipolicy) )  "
                      "   FROM  %s:edr_relation a,sa_branch_type b, officer c ,%s:endorsement d"
                      "  WHERE  1 = 1  %s %s %s"
                      "    AND  a.iquota[1,4] || '00' = b.ibranch" 
                      "    AND  a.iquota[1,4] matches '%s' "
                      "    AND  c.iofficer = a.iofficer " 
                      "    AND  a.fcard_class='2' AND  c.imgr='2' "
                      "    AND  a.iendorse=d.iendorse ",list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname,sTmpSql_E, sTmpSql_iofc, sTmpSql_irou,ibranch);
        $prepare pre2 from $stmt2;
        $execute pre2 ;           		
    }
          
   
    strcpy(ipolicy,"");
    strcpy(ilast_ply,"");
    strcpy(dpolicy,"");
    strcpy(itag,"");
    strcpy(iengine,"");
    strcpy(nassured,"");
    strcpy(dply_begin,"");
    strcpy(dply_end,"");
    strcpy(iofficer,"");
    strcpy(iroute,"");
    strcpy(nname,"");
    strcpy(ileader,"");
    strcpy(nbranch,"");
    strcpy(mprem,"");

    $declare cursor2 cursor for
      select qorder, igroup, ngroup 
        into $Qorder, $Igroup, $Ngroup 
        from car704
       order by qorder;

   $open cursor2;

    while(1)
    {
	
        $fetch cursor2;
        if(SQLCODE == SQLNOTFOUND) 
        {
           if(ibranch[0] !='*') 
           {
            sprintf(stmt,"SELECT nbranch FROM sa_branch_type WHERE dexpire IS NULL AND ibranch= '%s00' ",trim(ibranch));
            $prepare pre_cur3 from $stmt;
            $execute pre_cur3 INTO $Ngroup;  
                      	
            rgu_put_body_string(4, Ngroup, 1);
            rgu_put_body(4);max_cnt +=5;
            rgu_put_body(5);
            rgu_put_body(6);
            rgu_put_body(7);
            rgu_put_body(8);
            rgu_put_body(9);
            rgu_put_body(10);
            }
            break;
           
          

        }

        if(ibranch[0]!= '*') /*�~�Z���D��J�u*�v*/
        {
            $char tmp[10];
            sprintf(stmt,"SELECT igroup FROM sa_branch_type WHERE dexpire IS NULL AND ibranch= '%s00' ",trim(ibranch));
            $prepare tmp from $stmt;
            $execute tmp INTO $tmp;
            
            
            if(atoi(Igroup)==atoi(tmp))  /*�u�L�X�ŦX���󪺳��*/
            {
            	if(atoi(ibranch)!=atoi(tmp))   /*�]���`���N�`���q�����Ҧ�����k�ݦb�P�@���A�ҥH���n�d���`���q�����䤤�@�ӷ~�Z���ɡA�h����ܸӳ�쪺����*/
            	{
            	    sprintf(stmt,"SELECT nbranch FROM sa_branch_type WHERE dexpire IS NULL AND ibranch= '%s00' ",trim(ibranch));
                    $prepare pre_cur3 from $stmt;
                    $execute pre_cur3 INTO $Ngroup; 
                    
                    if(SQLCODE == SQLNOTFOUND ) strcpy(Ngroup," ");
                                	
                    car704_dtl_detail_print();
                    break; 
                }
                else
                {
                    car704_dtl_detail_print();
                    break;                 	
                }  
            }        	
        	
        }
        else   /*�~�Z����J�u*�v�A�L�X����*/
        {
            car704_dtl_detail_print();
        }



     	/*if(ibranch[0] !='*') break;*/

    }
    $close cursor2;
    $free  cursor2;


    return SUCCESS;
    


  
errexit:
    printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    exit(1);
}
/*----------------------------------------------------------------------------*/
long car704_detail_print()  /*�`�����X*/
{


    char tmp_buf[16];

        	rgu_put_body_string(2, Ngroup, 1);
        
        	rfmtlong(Qcnt_A, "-------&", tmp_buf);
        	rgu_put_body_string(2, tmp_buf, 2);

        	rfmtlong(Mprem_A, "------------&", tmp_buf);
        	rgu_put_body_string(2, tmp_buf, 2);

        	rfmtlong(Qcnt_B, "-------&", tmp_buf);
        	rgu_put_body_string(2, tmp_buf, 2);

        	rfmtlong(Mprem_B, "------------&", tmp_buf);
        	rgu_put_body_string(2, tmp_buf, 2);
        
        	rfmtlong(Qcnt_C, "-------&", tmp_buf);
        	rgu_put_body_string(2, tmp_buf, 2);

        	rfmtlong(Mprem_C, "------------&", tmp_buf);
        	rgu_put_body_string(2, tmp_buf, 2);

        	rfmtlong(Total_qcnt, "--------&", tmp_buf);
        	rgu_put_body_string(2, tmp_buf, 2);

        	rfmtlong(Total_mprem, "------------&", tmp_buf);
        	rgu_put_body_string(2, tmp_buf, 2);

        	rgu_put_body(2); max_cnt ++;


   
    

    return SUCCESS;
   

}
/*----------------------------------------------------------------------------*/
long car704_dtl_detail_print()  /*���Ӫ����X*/
{
	
    $WHENEVER SQLERROR GOTO errexit;

                    if((strstr(Ngroup,"(" ) == NULL && strstr(Ngroup,")" ) == NULL && strstr(Ngroup,"��") == NULL) && (strcmp(trim(Igroup),"YYY")!=0)  )
     	            {
        	        /*���*/ 
        	        rgu_put_body_string(4, Ngroup, 1);
        	        rgu_put_body(4);max_cnt +=5;
        	
        	        /*�j��*/ 
        	        rgu_put_body(5);

                        sprintf(stmt2,"select count(*) from car704_dtl where Igroup = '%s' and data_class = '1' ",Igroup);
        	        $prepare pre2 from $stmt2;
        	        $execute pre2 into $cnt;            	         
                
                        sprintf(stmt2,"select ipolicy,ilast_ply,dpolicy,itag,iengine,nassured,dply_begin,dply_end,iofficer,iroute,nname,ileader,nbranch,mprem from car704_dtl where Igroup = '%s'and data_class = '1' ",Igroup);  
                        $prepare pre6 from $stmt2;      	     
                        $DECLARE cursor6 CURSOR for pre6  ;
        	        $open cursor6;
        		
        	        for(int i=0; i<=atoi(cnt);i++)
    		        {
        		    $fetch cursor6 into $ipolicy,$ilast_ply,$dpolicy,$itag,$iengine,$nassured,$dply_begin,$dply_end,$iofficer,$iroute,$nname,$ileader,$nbranch,$mprem;
        		        
        		    if(strcmp(trim(ipolicy),"")!=0)
        		    {
        			if(strcmp(trim(ilast_ply),"")==0) 
        				strcpy(ilast_ply," ");
        			rgu_put_body_string(6, ipolicy, LEFT);
        			rgu_put_body_string(6, ilast_ply, LEFT);
        			rgu_put_body_string(6, dpolicy, LEFT);
        			rgu_put_body_string(6, itag, LEFT);
        			rgu_put_body_string(6, iengine, LEFT);
        			rgu_put_body_string(6, nassured, LEFT);
        			rgu_put_body_string(6, dply_begin, LEFT);
        			rgu_put_body_string(6, dply_end, LEFT);
        			rgu_put_body_string(6, iofficer, LEFT);
        			rgu_put_body_string(6, iroute, LEFT);
        			rgu_put_body_string(6, nname, LEFT);
        			rgu_put_body_string(6, ileader, LEFT);    
        			rgu_put_body_string(6, nbranch, LEFT);   
        			rgu_put_body_string(6, mprem, LEFT);      		
        	        	rgu_put_body(6);
        	        	strcpy(ipolicy,"");
        	            }
        			
                        }
        	        $close cursor6;
                        $free  cursor6;
                
        	        /*�g�P�ӥ��N*/ 
        	        rgu_put_body(7);
        	
                        sprintf(stmt2,"select count(*) from car704_dtl where Igroup = '%s' and data_class = '2' ",Igroup);
        	        $prepare pre2 from $stmt2;
        	        $execute pre2 into $cnt;            	         
                
                        sprintf(stmt2,"select ipolicy,ilast_ply,dpolicy,itag,iengine,nassured,dply_begin,dply_end,iofficer,iroute,nname,ileader,nbranch,mprem from car704_dtl where Igroup = '%s'and data_class = '2' ",Igroup);  
                        $prepare pre7 from $stmt2;      	     
                        $DECLARE cursor7 CURSOR for pre7  ;
        	        $open cursor7;
        		
        	        for(int i=0; i<=atoi(cnt);i++)
    		        {
        		    $fetch cursor7 into $ipolicy,$ilast_ply,$dpolicy,$itag,$iengine,$nassured,$dply_begin,$dply_end,$iofficer,$iroute,$nname,$ileader,$nbranch,$mprem;
        		        
        		    if(strcmp(trim(ipolicy),"")!=0)
        		    {
        			if(strcmp(trim(ilast_ply),"")==0) 
        				strcpy(ilast_ply," ");
        			rgu_put_body_string(8, ipolicy, LEFT);
        			rgu_put_body_string(8, ilast_ply, LEFT);
        			rgu_put_body_string(8, dpolicy, LEFT);
        			rgu_put_body_string(8, itag, LEFT);
        			rgu_put_body_string(8, iengine, LEFT);
        			rgu_put_body_string(8, nassured, LEFT);
        			rgu_put_body_string(8, dply_begin, LEFT);
        			rgu_put_body_string(8, dply_end, LEFT);
        			rgu_put_body_string(8, iofficer, LEFT);
        			rgu_put_body_string(8, iroute, LEFT);
        			rgu_put_body_string(8, nname, LEFT);
        			rgu_put_body_string(8, ileader, LEFT);    
        			rgu_put_body_string(8, nbranch, LEFT);   
        			rgu_put_body_string(8, mprem, LEFT);      		
        	        	rgu_put_body(8);
        	        	strcpy(ipolicy,"");
        	            }
        			
                        }
        	        $close cursor7;
                        $free  cursor7;        	
        	
        	
        	
        	
        	        /*�D���ӥ��N*/ 
      	      	        rgu_put_body(9);

                        sprintf(stmt2,"select count(*) from car704_dtl where Igroup = '%s' and data_class = '3' ",Igroup);
        	        $prepare pre2 from $stmt2;
        	        $execute pre2 into $cnt;            	         
                
                        sprintf(stmt2,"select ipolicy,ilast_ply,dpolicy,itag,iengine,nassured,dply_begin,dply_end,iofficer,iroute,nname,ileader,nbranch,mprem from car704_dtl where Igroup = '%s'and data_class = '3' ",Igroup);  
                        $prepare pre8 from $stmt2;      	     
                        $DECLARE cursor8 CURSOR for pre8  ;
        	        $open cursor8;
        		
        	        for(int i=0; i<=atoi(cnt);i++)
    		        {
        		    $fetch cursor8 into $ipolicy,$ilast_ply,$dpolicy,$itag,$iengine,$nassured,$dply_begin,$dply_end,$iofficer,$iroute,$nname,$ileader,$nbranch,$mprem;
        		        
        		    if(strcmp(trim(ipolicy),"")!=0)
        		    {
        			if(strcmp(trim(ilast_ply),"")==0) 
        				strcpy(ilast_ply," ");
        			rgu_put_body_string(10, ipolicy, LEFT);
        			rgu_put_body_string(10, ilast_ply, LEFT);
        			rgu_put_body_string(10, dpolicy, LEFT);
        			rgu_put_body_string(10, itag, LEFT);
        			rgu_put_body_string(10, iengine, LEFT);
        			rgu_put_body_string(10, nassured, LEFT);
        			rgu_put_body_string(10, dply_begin, LEFT);
        			rgu_put_body_string(10, dply_end, LEFT);
        			rgu_put_body_string(10, iofficer, LEFT);
        			rgu_put_body_string(10, iroute, LEFT);
        			rgu_put_body_string(10, nname, LEFT);
        			rgu_put_body_string(10, ileader, LEFT);    
        			rgu_put_body_string(10, nbranch, LEFT);   
        			rgu_put_body_string(10, mprem, LEFT);      		
        	        	rgu_put_body(10);
        	        	strcpy(ipolicy,"");
        	            }
        			
                        }
        	        $close cursor8;
                        $free  cursor8; 
                    } 
                    
   
    return SUCCESS;
                    
 errexit:
    printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    exit(1);                   
                    
}