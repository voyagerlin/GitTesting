/*                                                                                  */
/*      PROGRAM : ca214q01s.ec                                                      */
/*      Modify  :                                                                   */
/************************************************************************************/

#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "cmprint.h"
$include sqlca;
$include sqltypes;
#include <decimal.h>
#include "print.h"
#include "safeclib.h"

$char g_sDbName[5];
char  g_sUserId[11],g_date_begin[31],g_date_begin1[31],g_date_end[31],g_date_end1[31],g_number[20];
$char ipolicy[21],sfilename[41],stitle[1000],outputf[21],sErrmsg[200],dapplicant[31];
$char iserial[20],iquota[7],nbranch[41],icreate[11],nname[11],icard[21],dcreate[31],iserial1[20],icreate1[11],icard1[21];
$varchar nassured[121];
$char    stmt[3000];
char     g_sMsgBuf[1024];
long     rc;


main (argc, argv)
int argc;
char **argv;
{
    int rtc;

    batchinit();

    strcpy(g_sDbName,isNULLstr(argv[1]));
    strcpy(g_sUserId,isNULLstr(argv[2]));
    strcpy(g_date_begin,isNULLstr(argv[3])); 
    strcpy(g_date_end,isNULLstr(argv[4]));
    strcpy(g_number,isNULLstr(argv[5]));
    strcpy(outputf,isNULLstr(argv[6]));
    
    strcpy(g_date_begin1,cm_to_infdate(g_date_begin));
    strcpy(g_date_end1,cm_to_infdate(g_date_end));
    

      if ((rtc=car214_init()) != SUCCESS)
        {
           EWRITE(g_sUserId,rtc,g_sMsgBuf);
           return rtc;
        }
      if ((rtc=car214_cacul()) != SUCCESS)
        {
            EWRITE(g_sUserId, rtc, g_sMsgBuf);
            return rtc;
        }
    
      rtc=car214_dtl_rptA();
    
if (rtc != SUCCESS)
  {
        EWRITE(g_sUserId,rtc,g_sMsgBuf);
        return rtc;
  }
    
}

car214_init()
{
    $WHENEVER SQLERROR goto errexit;

    if(db_select(g_sDbName) == False)
    {
     	strcpy(g_sMsgBuf,"DB [%s] : is not opened",g_sDbName);
     	return M_CM_DB_NOTOPEN;
    }

    $CREATE TEMP TABLE car214_tmp
    (
        dcreate char(31),                           /*�C�L�ɶ�*/
        iserial char(20),                           /*�s��*/
        iquota char(6),                             /*�C�L�H�����*/
        dapplicant char(31),                           /*�n�O�Ѥ��*/
        nbranch char(40),                           /*�C�L�H�����W��*/
        icreate char(10),                           /*�C�L�H���N��*/
    	nname char(10),                             /*�C�L�H���W��*/
    	icard char(20),                             /*�C�L�Ҹ�*/
    	nassured varchar(120)                       /*�Q�O�I�H*/
    )WITH NO LOG;

    return SUCCESS;

errexit:
  printf("Steven:err[%ld][%s]\n",SQLCODE,sqlca.sqlerrm);
  sprintf_s(g_sMsgBuf, sizeof g_sMsgBuf,"%s",sqlca.sqlerrm);
  return SQLCODE;
}

car214_cacul()
{

    $WHENEVER SQLERROR goto errexit;

    

    
    sprintf_s(stmt, sizeof stmt, " SELECT iserial,ipolicy,icard,dapplicant,iquota,nassured,icreate,dcreate "
                  " FROM ca_card_proof "
                  " WHERE ipolicy matches '%s' "
                  " AND dcreate >= extend(date('%s'), year to second)"
                  " AND dcreate < extend(date('%s')+1, year to second)",g_number,g_date_begin1,g_date_end1);
               
               
                  

printf("=== 1111111 [%s] \n\n", stmt);

    $PREPARE P1 FROM $stmt;
    $DECLARE cur_1 cursor for P1;
    $OPEN cur_1;

    for(;;)
    {
	    $FETCH cur_1
	      INTO $iserial,$ipolicy,$icard,$dapplicant,$iquota,$nassured,$icreate,$dcreate;
	           
        if (SQLCODE==SQLNOTFOUND) break;

        
        
              $select nbranch into $nbranch
               from sa_branch_type 
               where ibranch = $iquota;
               
              $select nname into $nname
               from officer 
               where iofficer = $icreate;
               
              strcpy(iserial1, "�");                       /*���X�Ĥ@�X��0�A�����bexcel�q�X*/
              strcat(iserial1,trim(iserial));
              
              strcpy(icreate1, "�");
              strcat(icreate1,trim(icreate));
              
              strcpy(icard1, "�");
              strcat(icard1,trim(icard));
              
              /*printf("****************dcreate = %s*****************\n",dcreate);*/
	      $INSERT INTO car214_tmp
	 	 VALUES ($dcreate,$iserial1,$iquota,$dapplicant,$nbranch,$icreate1,$nname,$icard1,$nassured);   /*���ӤW��car214_tmp����*/

    }
    $CLOSE cur_1;
    $FREE cur_1;

    return SUCCESS;

errexit:
  printf("Steven:err[%ld][%s]\n",SQLCODE,sqlca.sqlerrm);
  sprintf_s(g_sMsgBuf, sizeof g_sMsgBuf,"%s",sqlca.sqlerrm);
  return SQLCODE;
}

car214_dtl_rptA()
{
    char tmp[30];

    strcpy(sfilename,"�j���ҧ�O�ҩ����Ӫ�");

    memset(stmt, 0x00, sizeof(stmt));
   
    sprintf_s(stmt, sizeof stmt," SELECT dcreate,iserial,iquota,nbranch,icreate,nname,icard,nassured,dapplicant "
                 " FROM car214_tmp ");
                 
    sprintf_s(stitle, sizeof stitle,"�j���ҧ�O�ҩ��C�L���Ӫ� �C�L����G%s��%s \n \t",g_date_begin1,g_date_end1);
    strcat(stitle,"�C�L����ɶ�\t�s��\t�C�L�H�����\t�C�L�H�����W��\t�C�L�H���N��\t�C�L�H���W��\t�C�L�Ҹ�\t�Q�O�I�H\t�n�O���\t");

 
    rc = unload_file(outputf," ",sfilename,stitle,stmt);
 
    if (rc != SUCCESS)
    {
        sprintf_s(sErrmsg, sizeof sErrmsg," %s �ɮ׵L�k���� ",sfilename);
        EWRITE(g_sUserId, rc , sErrmsg);
        exit(1);
    }

    return SUCCESS;
      
errexit:
  printf("Steven:err[%ld][%s]\n",SQLCODE,sqlca.sqlerrm);
  sprintf_s(g_sMsgBuf, sizeof g_sMsgBuf,"%s",sqlca.sqlerrm);
  return SQLCODE;
}

