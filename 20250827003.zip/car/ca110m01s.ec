/************************************************/
/*                                              */
/*   PROGRAM : car110m01s.ec
/*                                              */
/************************************************/
     
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
#include <ca401field.h>
$include sqlca;
#include "safeclib.h"

long car110(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car110_insert(),car110_single_query(),car110_multiple_query(),car110_update_exec();
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 switch(option)
 {
  case 'A':
	   rtncode=car110_insert(reply);
	   break;
  case 'Q':
	   rtncode=car110_single_query(reply);
	   break;
  case 'M':
           rtncode=car110_multiple_query(reply);
	   break;
  case 'D':
  case 'U':
	   rtncode=car110_update_exec(reply,command,com_len);
	   break;
  case 'T': /* �ഫB2C�����챱��X��� */
	   rtncode=car110_control_exec(reply,command,com_len);
	   break;
  default :
	   if(exitsub(reply,M_CM_WRONG_OPTION) == True)
	    return M_CM_WRONG_OPTION;
           return apiRC;
 }
 return(rtncode);
}

long car110_insert(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table endorsement_code */
 $char class[2];
 $char icode[3],caname[11],item[3];
 /* end of endorsement_code */

 /* standard defined data */
 int tmp_len;
   DBinfo *list;
   int i, j, is_add_fail=0, api_f;
   $char stmt_buf[300];
 /* end of standard data */

 /* self defined data */
 long MsgCode;
 /* end of self data */

 cm_buf_get("%s",DBName);
 cm_buf_get("%c %s %s %s",&class[0],icode,caname,item);
 class[1]='\0';

 if (db_select(DBName) == False) 
  { 
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }
 
 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }

 $BEGIN WORK;
 for(j=0;j<i;j++)
 {
  sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:endorsement_code (fclass,icode,ncode, "
  		" iedr_item) VALUES (?,?,?,?)" ,list[j].dbname);

  $PREPARE a_id FROM $stmt_buf;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  $EXECUTE a_id USING  $class,$icode,$caname,$item;
  if(SQLCODE != 0)
   {
    is_add_fail = 1;
    break;
   }
  cm_buf_init(ReplyBuf);
  cm_buf_put("%l %s",M_CM_OK,list[j].dbchi);
  tmp_len = cm_buf_len(ReplyBuf);
  if( j == i-1 )
     api_f = api_OKComplete;
  else
     api_f = api_OK;

  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_f) == False)
    {
     is_add_fail = 2;
     break;
    }  
#ifdef DEBUG 
printf("INSERT %d\n", j+1);
#endif
 } /* for loop */

 if( is_add_fail == 1 ) goto errexit;

 if( is_add_fail == 2 ) 
  {
   $ROLLBACK WORK;
   return apiRC;
  }


 $WHENEVER SQLERROR GOTO errexit;
 $COMMIT WORK;
 return api_OKComplete;

 errexit:
  $WHENEVER SQLERROR CONTINUE;    
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}

long car110_single_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table endorsement_code */
 $char class[2];
 $char code[3],caname[11],item[3];
 /* end of endorsement_code */

 /* standard defined data */
 int tmp_len;
 /* end of standard data */

 /* self defined data */
 
 /* end of self data */
 cm_buf_get("%s",DBName);
 /*cm_buf_get("%s %c",code,&class[0]); */
 cm_buf_get("%c %s",&class[0],code);
 class[1]='\0';

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 $SELECT ncode,iedr_item
  INTO $caname,$item
  FROM endorsement_code
  WHERE fclass=$class AND icode=$code; 

 if(SQLCODE==SQLNOTFOUND) 
  {
   if(exitsub(reply,M_CA_NCODE) == True) 
    return M_CA_NCODE; 
   else  
    return apiRC;
  }

 cm_buf_init(ReplyBuf); 
 cm_buf_put("%l",M_CM_OK);
 cm_buf_put("%c %s %s %s",class[0],code,caname,item);
 tmp_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
  return apiRC;
 else
  return api_OKComplete;

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}

/*************************************************************************/
long car110_multiple_query(reply)
serverReply reply;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table endorsement_code */
 $char class[2];
 $char code[3],caname[11],item[3];
 $char tmpclass[2];
 $char tmpcode[3],tmpname[11];
 /* end of endorsement_code */

 /* standard defined data */
 char tmpbuf[4000];
 int count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 int i,total_count=0; 
 /* end of standard data */

 /* self defined data */
 
 /* end of self data */

 cm_buf_get("%s",DBName);
 cm_buf_get("%c %s",&class[0],code); 
 class[1]='\0';

printf("================== class[%s] code[%s]\n",class,code);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False) 
 {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
 }

 $DECLARE q_cur CURSOR FOR
    SELECT fclass,icode,ncode
    INTO $tmpclass, $tmpcode, $tmpname
    FROM endorsement_code
  WHERE fclass matches $class AND icode matches $code
  ORDER BY fclass, icode;

 $OPEN q_cur;

 for(;;)
  {
    $FETCH q_cur;
    if (SQLCODE != 0) break;

    cm_buf_init(tmpbuf); 
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();          
     }
    cm_buf_put("%c %s %s",tmpclass[0],tmpcode,tmpname);
    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */ 
     { 
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
	    $CLOSE q_cur;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 10)   /* more than 30K, client cannot display,error */
        {
	     cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE; 
        }
	   ReplyBuf[0] = '\0';
	   count = 0;
	   cm_buf_init(ReplyBuf);
       cm_buf_res_msg();           /* reserve for MsgCode and count */
       cm_buf_res_count();    
       cm_buf_put("%c %s %s",tmpclass[0],tmpcode,tmpname);
	repbuf_len = cm_buf_len(ReplyBuf);
	count++;
       }
     } 
  } /* for loop */

 $CLOSE q_cur;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any row is found */
  {
   if(exitsub(reply,M_CA_NCODE) == True) 
    return M_CA_NCODE;
   else  
    return apiRC;
  } 

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}


long car110_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
 /* standard defined host variables */
 $char DBName[5];
 /* end of standard host var */

 /* table endorsement_code */
 $char class[2],old_class[2];
 $char code[3],old_code[3],caname[11],item[3];
 /* end of endorsement_code */

 /* standard defined data */
 char option,*pos,*raw_ptr,*malloc(),cur_buf[4000],*comm;
 int tmp_len,raw_len;
 long dummy=0;
   DBinfo *list;
   int i, j, is_del_fail=0, is_upd_fail=0;
   $char stmt_buf[300];
 /* end of standard data */

 /* self defined data */
 long MsgCode;
 /* end of self data */

 comm = (char *) command;
 cm_buf_init(command);
 cm_buf_get("%c %s",&option,DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

 if( (list=get_sysdb_list(&i,DBName)) == (char*)0 )
  {
   if(exitsub(reply,M_CM_NOT_DBLIST) == True)
    return M_CM_NOT_DBLIST;
   return apiRC;
  }
 /* compare old record and current record, if the record has not been changed  
    since last request, update or delete the record, otherwise return errmsg
    to client side */

 /* get old record info from command buffer */ 

 memcpy(&raw_len,&comm[com_len],sizeof(int));   
 pos = &comm[com_len+sizeof(int)];
 raw_ptr = malloc(raw_len);
 if (raw_ptr != (char*)0)  
  memcpy(raw_ptr,pos,raw_len);
 else
  {
   if(exitsub(reply,M_CM_NOT_MALLOC) == True)   /* malloc fail */ 
    return M_CM_NOT_MALLOC;
   else  
    return apiRC;
  }
    
 cm_buf_init(raw_ptr);          /* get index key from old record */
 cm_buf_get("%l %c %s",&dummy,&old_class[0],old_code);
 old_class[1]='\0';

   $BEGIN WORK;                
 $SELECT ncode,iedr_item
  INTO $caname,$item  
  FROM endorsement_code
  WHERE fclass=$old_class AND icode=$old_code;

  /* if key value has been changed then SQLNOTFOUND,else put current value
     into cur_buf for comparison */ 

 if (SQLCODE == SQLNOTFOUND)
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CM_NOT_FOUND) == True) 
    return M_CM_NOT_FOUND;
   else  
    return apiRC;
  }
   $WHENEVER SQLERROR GOTO errexit;

 cm_buf_init(cur_buf);
 cm_buf_put("%l %c %s %s %s"
            ,dummy,old_class[0],old_code,caname,item);

 if (memcmp(cur_buf,raw_ptr,raw_len) != 0) /* compare 2 records, not equal */
  {
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if(exitsub(reply,M_CM_NOT_EQUAL) == True) 
    return M_CM_NOT_EQUAL;
   else  
    return apiRC;
  }
   $WHENEVER SQLERROR GOTO errexit;
   
   free(raw_ptr);
  
 /* equal, then exec DB operation */

 if ( option == 'D' )
  {
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf,"DELETE FROM %s:endorsement_code WHERE fclass = ? "
	 " AND icode = ?" ,list[j].dbname); 
    $PREPARE d_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
    $EXECUTE d_id USING $old_class,$old_code; 
    if(SQLCODE != 0)
     {
      is_del_fail = 1; 
      break;
     }
#ifdef DEBUG 
printf("Delete %d\n", j+1);
#endif
   }/* for loop */

   if( is_del_fail ) goto errexit;
   
   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else if (option == 'U')
  {
/* 9/3/1993    $BEGIN WORK;               */ 
   cm_buf_init(command);
   cm_buf_get("%c %s %c %s %s %s",&option,DBName,&class[0],code,caname,item); 
   class[1]='\0';
                  
   $WHENEVER SQLERROR CONTINUE;
   for(j=0;j<i;j++)
   {
    sprintf_s(stmt_buf, sizeof stmt_buf,"UPDATE %s:endorsement_code "
   		" SET (fclass,icode,ncode,iedr_item) = (?,?,?,?) "
   		" WHERE fclass = ? AND icode = ?" ,list[j].dbname);

    $PREPARE u_id FROM $stmt_buf;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    $EXECUTE u_id USING $class,$code,$caname,$item, $old_class,$old_code;
    if(SQLCODE != 0)
     {
      is_upd_fail = 1;
      break;
     }
    if(sqlca.sqlerrd[2] == 0)  /* no rows has been updated then insert it*/
     {
  	sprintf_s(stmt_buf, sizeof stmt_buf,"INSERT INTO %s:endorsement_code (fclass,icode,ncode, "
  		" iedr_item) VALUES (?,?,?,?)" ,list[j].dbname);

      $PREPARE ua_id FROM $stmt_buf;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }
      $EXECUTE ua_id USING $class,$code,$caname,$item;
      if(SQLCODE != 0)
       {
        is_upd_fail = 1; 
        break;
       }
     }
#ifdef DEBUG 
printf("Update %d\n", j+1);
#endif
   } /* for loop */

   if( is_upd_fail ) goto errexit;

   cm_buf_init(ReplyBuf);
   cm_buf_put("%l",M_CM_OK);
   tmp_len = cm_buf_len(ReplyBuf);
   if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
    {
     $WHENEVER SQLERROR CONTINUE;
     $ROLLBACK WORK;
     return apiRC;
    }  

   $WHENEVER SQLERROR GOTO errexit;
   $COMMIT WORK;
   return api_OKComplete;
  }
 else
  {
   if(exitsub(reply,M_CM_WRONG_OPTION) == True) 
    return M_CM_WRONG_OPTION;
   else  
    return apiRC;
  } 

 errexit:
  $WHENEVER SQLERROR CONTINUE;
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}

long car110_control_exec(reply)
serverReply reply;
{
 $char DBName[5];
 $char icode1[101];
 $char icode1_tmp[101];
 $char icode2[8];
 char  sdata[3];
 long iStart, iLen, iTmp, iCol, iLenTotal;
 char  *pStart;

 /* standard defined data */
 int tmp_len, idata;
 $char stmt_buf[300];
 /* end of standard data */

 /* self defined data */
 long MsgCode;
 /* end of self data */

 cm_buf_get("%s",DBName);

 $database sysdb;

 $BEGIN WORK;
 $DECLARE cur1 CURSOR FOR
   SELECT icode1 from ca_edr_field_trans;

 $OPEN cur1;

 for(;;)
  {
    $FETCH cur1 INTO $icode1_tmp;
    if (SQLCODE == SQLNOTFOUND) break;
    strcpy( icode1, trim(icode1_tmp));
    memset (&(icode2), 0, sizeof (icode2));
    FLD_SET (icode2, 7);
    FLD_SET (icode2, 15);
    FLD_SET (icode2, 23);
    FLD_SET (icode2, 31);
    FLD_SET (icode2, 39);
    FLD_SET (icode2, 47);
    FLD_SET (icode2, 55);
    FLD_SET (icode2, 63);

    /* ���icode1�H/���j,Ū�X��� */

    printf("===============[%s]\n", icode1);
    iLenTotal = strlen( icode1);
    iStart = 0;
    iLen = 0;
    for( iTmp = 0; iTmp <=iLenTotal; iTmp++)
    {
        if( icode1[iTmp] == '/' || icode1[iTmp] == '\0') 
        {
            strncpy( sdata, &icode1[iStart], iLen);
            sdata[iLen] = '\0';
            iStart = iStart + iLen + 1;
            iLen=0;
            printf("sdata[%s]\n", sdata);
            idata = atoi( sdata);
            printf("idata[%d]\n", idata);
            FLD_SET (icode2, idata);
        }
        else 
        {
            iLen++;
        }
    }
    $UPDATE ca_edr_field_trans
        SET icode2 = $icode2
      WHERE icode1 = $icode1;
  }
  $COMMIT WORK;

  cm_buf_init(ReplyBuf);
  cm_buf_put("%l ",M_CM_OK);
  tmp_len = cm_buf_len(ReplyBuf);

  if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
  {
      return apiRC;
  }  
  return api_OK;

 errexit:
  $WHENEVER SQLERROR CONTINUE;    
  MsgCode = SQLCODE;
  $ROLLBACK WORK;
  if (SQLCODE != 0) MsgCode = SQLCODE;
  if(exitsub(reply,MsgCode) == True) 
   return MsgCode;
  else  
   return apiRC;
}
