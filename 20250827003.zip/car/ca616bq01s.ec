/*--------------------------------------------------------------------*/
/*   PROGRAM ID    : ca616bq01s.ec                                    */
/*   PROGRAM NAME  : ��s�T����W���ר�s�T���A�����n�Q�O�H�X��� */
/*   AUTHOR        : 071004                                           */
/*   DATE WRITTEN  : 2019/10/09                                       */
/*--------------------------------------------------------------------*/
#include <stdio.h>
#include <ca401field.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include <string.h>
#include "api_xsrv.h"
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
$include sqltypes;
$include datetime;
#define False                 0
#define LOAD_FAIL            -1
#include "safeclib.h"
/*--------------------------------------------------------------------*/
$char    type[1];
$char    dbgn[11];
$char    fbig_office[2];
$int     id1,id2,qcount,ply_cnt,dtl_cnt;
int      itype;
char     errmsg[200];
char     sysEd[11],sysTm[9];
long     sysdt;

DBinfo   *list;
int      count_db,i,rc;
char     msgbuf[1024];

int      flen,cnt,cnt_1,cnt_2;
int      cnt_p,cnt_i,cnt_c;
FILE     *fp,*fp1,*fp2,*fp3,*fp4;
FILE     *fp_sym, *fp_sym1;
char     sApHome[30];
$char    fname[21];
char     filename[50],filename1[50],filename2[50],filename3[50],filename4[50];
char     file_sym[50], file_sym1[50];
$char    DBName[5], iForm_Tp[3];
$char    full_dbname[20];
char     BodyFile[ N_FILE+1];
char     TitleFile[ N_FILE+1];
char     outputf[N_FILE+1], userid[11];
char     pgid[11];
char     icard_test[20];
$int     ItemRow, TotColumn;
$int     StartRow,TitleRow;
$int     PgLine, Width;

int  max_cnt;

$char stmt_tmp1[1024],stmt_tmp2[1024];

/* for�P�Ӿ���� */
FILE   *sfp, *report, *report1;
char   sMsg[10240];

static char *get_car_full_db();

double d45();

/*--------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{    
    batchinit();
    strcpy(DBName, isNULLstr(argv[1]));
    strcpy(userid, isNULLstr(argv[2]));
    strcpy(dbgn, isNULLstr(argv[3]));/*����*/
    /*strcpy(icard_test, isNULLstr(argv[3]));/*����*/
    strcpy(outputf, isNULLstr(argv[4]));

    strcpy(icard_test,trim(icard_test));

    
    
   
    rc=car616_get_db();
    if ( rc != M_CM_OK) return rc;

    sysdt=cm_today();
    strcpy(sysEd,cm_edate_str(sysdt));
    strcpy(sysTm,substring(sysEd,7,4));
    strncat(sysTm,sysEd,2);
    strncat(sysTm,sysEd+3,2);    

    strcpy(pgid,"car616");

    $BEGIN WORK;
    rc = car616_update_name(); 
    if (rc == LOAD_FAIL);                           
    else if (rc != M_CM_OK)
    {
        $ROllBACK WORK;
        EWRITE(userid, rc, sMsg);
        return rc;
    }
    $COMMIT WORK;                                         
                     
    /*return rc;*/
    if (rc != M_CM_OK)
    { 
       EWRITE(userid, rc, sMsg);
       return rc;
    }

     WRITELOG( sfp, sMsg);
     ENDLOG(sfp);
     return M_CM_OK;

errexit:
    printf("------car616_err: SQLCODE[%d]\n",SQLCODE);
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    exit(1);
}

/*--------------------------------------------------------------------*/
long car616_get_db()
{
    int rc;
    $whenever sqlerror goto errexit;
    
    sfp =  (FILE *)STARTLOG();

    if (db_select(DBName) == FALSE)
    {
        EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
        return M_CM_DB_NOTOPEN;
    }
    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }
    if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
    {
       EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
       return M_CM_NOT_DBLIST;
    }

    return M_CM_OK;
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;  
}
/*--------------------------------------------------------------------*/
long car616_update_name()
{
   $char sIpolicy[21], sItag[CA_TAG_NUM], itag[CA_TAG_NUM]; /* client�ݱNuser���Ѫ�����諸����� */    
   $char iendorse[21], key_value[CA_ENGINE_NUM], db_keyvalue[21], iedr_field[9];
   char  payresult[5], paystatus[100], paydate[100], notedate[100];
   char  policy_1[POLICY_NUM_1],policy_2[POLICY_NUM_2];
   char   sIcomp_in[BRANCH_ID], sIbranch_in[BRANCH_ID];
   char   sIbranchIcomp[CA_POL_BRH_NUM], sIbilling[3];   
   $char ibatch_no[11], iquota[11], ileader[11], iofficer[11];
   $char fcard_class[2],icar_type[3],iroute[21], iofficer_prmt[11];
   $char iroute_off[21],ibig_office[10];
   $long tmp_cnt=0,tot_prem=0;
   
   int   iCount, iTmp, rc1;
   char  FullGetName[101], FullLogName[101], FullRptName[101];
   char  GetName[51], LogName[51], RptName[51], TmpName[51];
   char  sIupcompShort[2], policyDB[21], policyDBname[41];
   char  sIupcompShortNext[2], policyDBNext[21], policyDBnameNext[41];
   char  local_dbname[41];
   $char stmt[20480], stmt1[2048], cmd_stmt[20480], datetime[12];
   $char fedr_class[2], inext_ply[21];
   $char fassured_next[2], fcomp_class_next[3];
   long  tt, code;
   $long dwritten, dissue;
   char  v_sMsg[512],err_sMsg[512];     
   $char dlock[31],iroute_accept_edr[21];
   $char  feply[2]=" ",tmobile_eply[21]=" ",aemail_eply[51]=" "; /*1090831006_SC2 �{�ҥ��x�j��q�l���ҥ���g�����mail�ˮ�*/
   $char  tmobile_appl[21]=" ",aemail_appl[51]=" ",s_notifyornot[21]="";
   $datetime year to second dnotifyornot;  

    $WHENEVER SQLERROR GOTO errexit;        

    strcpy(local_dbname, get_full_dbname(DBName));
    
    sprintf_s(filename, sizeof filename,"%s/rptftp/car616b_report.txt",sApHome);
    report=fopen(filename,"w");

    
	
    /* -------------------------------------------------------*/
    /* �}�l�X��� */
    /* ���o���椧�t�Τ�� */
    rtoday(&dwritten);

    memset (&iedr_field, 0, sizeof (iedr_field));

    for( iTmp = 0; iTmp < 8; iTmp++)
        FLD_SET ( iedr_field, iTmp*8 + 7);

    FLD_SET ( iedr_field, 2);   /* ���Q�O�I�H�W��(�N����2) */
    FLD_SET ( iedr_field, 50);  /* ���n�O�H�W��(�N����50) */
    
    iCount = 0; 
    
    $CREATE temp TABLE car616b
    (
        ipolicy char(20)
    );
    
    /*����n��諸�O�渹*/
    $INSERT  INTO car616b
     SELECT  a.ipolicy
       FROM  newa00:policy a,newa00:ply_relation b
      WHERE  a.ipolicy = b.ipolicy
        AND  b.iofficer IN ( SELECT iofficer FROM officer WHERE iroute LIKE 'PA23892144%' AND iofficer[1]='Y' )
        AND  dply_end >= today  /*(�O�_���w����Χ����ѡA�R���n�A�T�{)*/
        AND  a.ipolicy NOT IN ('02008C9038986','02008C9038988') 
        AND  b.dply_close IS NOT NULL ;       
    
    
    $DECLARE curs1 CURSOR for
     SELECT * FROM car616b;


    $OPEN curs1;
    for(;;)
    {
         $FETCH curs1 INTO $sIpolicy;
                              
         if (SQLCODE == SQLNOTFOUND) break;   
         iCount++;
         strcpy(stmt1,""); 
         strcpy(stmt,""); 
         strcpy(sIpolicy,trim(sIpolicy));       
          
         
              
         strcpy(inext_ply,"");
         strcpy(fassured_next,"");
         strcpy(fcomp_class_next,"");

         sIupcompShort[0] = sIpolicy[2]; /* �O�渹�ĤT�X */
         sIupcompShort[1] = '\0';
         strcpy( policyDB, get_upcomp(sIupcompShort, USE_SHORT_BRANCH_ID, USE_BRANCH_ID));
         strcpy( policyDBname, get_full_dbname(policyDB));                              

         printf("�O�渹[%s][%s]\n", sIpolicy, policyDBname);

         tot_prem=0; 
         sprintf_s(stmt, sizeof stmt, "SELECT a.icard, b.itag, a.iofficer, a.fcard_class, a.icar_type, b.iroute, a.iofficer_prmt, a.ibig_office, a.fedr_class, a.inext_ply, b.dissue, a.dlock ,  "
                        " (SELECT sum(mdamage_cover)::integer FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy ),  "
                        " a.feply , a.tmobile_eply , a.aemail_eply , b.tmobile_appl , b.aemail_appl " 
                        "  FROM %s:ply_relation a, %s:policy b  "
                        " WHERE a.ipolicy = b.ipolicy  "
                        "   AND a.dply_close is NOT NULL  "
                        "   AND a.ipolicy = '%s' ", policyDBname, policyDBname, policyDBname, sIpolicy);

         $PREPARE prep1 FROM $stmt;
         $EXECUTE prep1 INTO $db_keyvalue, $itag, $iofficer, $fcard_class, $icar_type, $iroute, $iofficer_prmt, $ibig_office,$fedr_class,
                             $inext_ply, $dissue, $dlock, $tot_prem,
                             $feply , $tmobile_eply , $aemail_eply , $tmobile_appl , $aemail_appl;
         code = SQLCODE; 

         
         sprintf_s(sMsg, sizeof sMsg, "�O�渹[%s]\t", sIpolicy);

         if (code == SQLNOTFOUND)
         {
              strcat( sMsg, "�O���Ƨ䤣��Υ��鵲" );
              fprintf( report, "%s\n", sMsg);
              continue;
         }
               
         strcpy(iendorse, " "); 	
               
         if( strlen(trim(dlock)) != 0 ) /* ���O��B2C��襤�A�ȮɵL�k��� */
         {
              strcat( sMsg, "���O��B2C��襤�A�ȮɵL�k���" );
              fprintf( report, "%s\n", sMsg);
              continue;
	 }              
         if(fedr_class[0] == '1') 
         {
               strcat( sMsg, "�ӫO��w���P,������,�нT�{" );  
               fprintf( report, "%s\n", sMsg);
               continue;
         }  

         /* 1071027001_C1�]���q�l���ҤW�u�A�u�n�j��O��h�O�Y���i��CAR616�ɨ��P */
         if (tot_prem==0)
         {
               strcat( sMsg, "���O��w�h�O,������,�нT�{" );
               fprintf( report, "%s\n", sMsg);
               continue;   
          }

          strncpy(sIbranchIcomp, sIpolicy, CA_POL_BRH_NUM - 1);
          sIbranchIcomp[CA_POL_BRH_NUM - 1] = '\0';

          /* get ����k�ݤ�����c & �����q*/
          rc = cm_get_unit_in("", policyDB, userid, sIbranchIcomp, "C1", sIcomp_in, sIbranch_in);
          if ( rc != M_CM_OK)
          {
                strcat( sMsg, "����k�ݤ�����c & �����q�䤣��");
                fprintf( report, "%s\n", sMsg);
                continue;
          }

          /* check ����k�ݤ����q�MDB�O�_�@�P*/
          if (strncmp( sIcomp_in, get_upcomp( policyDB, USE_BRANCH_ID, USE_BRANCH_ID), 1) != 0)
          {
                strcat( sMsg, "����k�ݤ����q�MDB���@�P");
                fprintf( report, "%s\n", sMsg);
                continue;
          }

          /**** ��涷���s����g��H�~�Z�k�ݳ��κ޲z�H ****/
          $SELECT iquota, ileader, iroute
             INTO $iquota, $ileader, $iroute_off
             FROM officer
            WHERE iofficer = $iofficer;

          if (SQLCODE == SQLNOTFOUND)
          {
               strcat( sMsg, "�g��H��Ƨ䤣��");
               fprintf( report, "%s\n", sMsg);
               continue;
          }

               rc = chk_iquota_expire( iquota, v_sMsg);
               if( rc != M_CM_OK)
               {
                   strcat( sMsg, v_sMsg);
                   fprintf( report, "%s\n", sMsg);
                   continue;
               }
               
               /* bis9901141 �q���M�� */
               /* W�}�Y���g��N���n�Φ^�k�᪺�g��N���h��w�]�q���N�� */
               if (iofficer[0] == 'W')
               {
                    strcpy(iofficer_prmt,trim(iofficer_prmt));
                    /* �Y��O��S���^�k�᪺�g��N��,�N�����^ca_promote_officer�h�� */
                    if (iofficer_prmt[0] == ' ' || iofficer_prmt[0] == '\0')
                    {
                    	   $SELECT iofficer INTO $iofficer_prmt FROM ca_promote_officer
                          WHERE iofficer_ori = $iofficer
                            AND ibig_office = $ibig_office;
                            
                        if (SQLCODE == SQLNOTFOUND) strcpy(iofficer_prmt," ");
                    }
 
                    $SELECT iroute INTO $iroute FROM officer where iofficer = $iofficer_prmt;
                    if (SQLCODE == SQLNOTFOUND) strcpy(iroute," ");
               } else
               {
               	/* �Y�q���N���ťթάO���s�b,�ϥθg��N���w�]�q���N�� */
               	if (iroute[0] == ' ' || iroute[0] == '\0') strcpy(iroute,iroute_off);
               }             	           
               	
               /* �Y�q���N���ťթάO���s�b,�ϥιw�]�q���N�� */
               strcpy(iroute,trim(iroute));
               if (iroute[0] == ' ' || iroute[0] == '\0')
               {        	            
               	 strcat( sMsg, "�q���N�����ťթ�NULL");
                   fprintf( report, "%s\n", sMsg);
                   continue;                                   
               } else  
               {
               	/* �ˬd�q���N���O�_�s�b��q���ɤ� */
                  $SELECT count(*) INTO $tmp_cnt FROM cm_route
                    WHERE iroute = $iroute;
                  if (tmp_cnt == 0)
                  {
           	            strcat( sMsg, "�q����Ƥ��s�b");
                        fprintf( report, "%s\n", sMsg);
                        continue;
                   }
               }               

               /* get ���s�X���O*/
               strncpy(sIbilling, sIpolicy+CAR_POL_CHR_POS-1, 2);
               sIbilling[2]='\0';

               rc = cm_get_serial_num_dwritten ("C2", sIbilling,
                                                sIupcompShort, sIbranch_in,
                                                cm_cdate_str_100(dwritten),
                                                cm_cdate_str_100(cm_today ()), iendorse);
               if (rc != 0)
               {
                    if ( rc == 1 ||  rc == 2) strcat( sMsg, "��Ʈw�L�k�}��");
                    else if ( rc == 3) strcat( sMsg, "���۰ʵ�����Ƥ��s�b");
                    else strcat( sMsg, "����渹���~");

                    fprintf( report, "%s\n", sMsg);
                    continue;
               }

               rc = bk_401( policyDB, sIpolicy, iendorse);
               if ( rc != M_CM_OK)
               {
                    strcat( sMsg, "�O��ƥ�����");
                    fprintf( report, "%s\n", sMsg);
                    continue;
               }

               /* 1090831006_SC2 �{�ҥ��x�j��q�l���ҥ���g�����mail�ˮ� */
               rsetnull(CDTIMETYPE, (char *) &dnotifyornot);	
               strcpy(s_notifyornot,"");         
               if (fcard_class[0] == '1')
               {              
                   if ( 
                        ( strlen(trim(tmobile_appl))==0 && strlen(trim(aemail_appl))==0 ) && 
                        ( (feply[0]=='1' && strlen(trim(tmobile_eply))==0 && strlen(trim(aemail_eply))==0 ) || feply[0]=='0')
                      )                        
                   {
                       dtcurrent(&dnotifyornot);
                       dttoasc(&dnotifyornot, s_notifyornot);
                   }
                   printf("--trace s_notifyornot[%s]",s_notifyornot);
               }

               policy_1[0]='\0';
               policy_2[0]='\0';

               strncpy(policy_1, sIpolicy, CAR_POLICY_LEN);
               policy_1[CAR_POLICY_LEN]=0;

               if (strlen(sIpolicy)>CAR_POLICY_LEN) strcpy(policy_2,&sIpolicy[CAR_POLICY_LEN]);
               else strcpy(policy_2," ");

               ao_chk_charge( policyDB, 'A', policy_1, policy_2, ibatch_no,
                              payresult, paystatus, paydate, notedate);

	           /*1071105008_SC2_ �������Ȩ��z��(FS)�A�éw�ɦ۰ʤU���ɮ�*/
	           strcpy(iroute_accept_edr," ");         
	           if(strncmp(iroute,"I009",4)==0)
	           {
	               strcpy(iendorse, trim(iendorse));             
	               sprintf_s(iroute_accept_edr, sizeof iroute_accept_edr, "CHB%s", iendorse);             
	           }
	           printf("-- trace iroute_accept_edr[%s]\n ", iroute_accept_edr); 
         
               sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:endorsement  "
               "             (iendorse,    qply_period,  dply_begin,  dply_end,    fassured,  "
               "              iassured,    iassured_ext, nassured,    ilicense,     "
               "              fsex,        fmarriage,    nuser,       ibenef,      nbenef,  "
               "              aassured,    aassured_zip, itel,        apayment,    apayment_zip, "
               "              iply_area,   nbrand_abbr,  ncar_abbr,   fcar_note,   qcylinder,  "
               "              iengine,     ibody,        itag,        mcar_price,  nequipment,  "
               "              flimit,      pdmg_align,   pbrg_align,  plia_align,  idmg_rate,  "
               "              pdmg_factor, ibrg_rate,    pbrg_factor, qpt,         fpt,  "
               "              psex_age,    psex_age_damage, lia_class,    plia_acc,    dmg_acc_1st, dmg_acc_2nd,  "
               "              dmg_acc_3rd, pdmg_acc,     fhuman,      fcomp_24,    payresult,  "
               "              iext_policy, qpro_month,   mkilo_ply,   mkilo_edr,   irisk,  "
               "              irelative_ext,  "
               "              napplicant,  dbirth,   dissue,     "
               "              iextra_charge, gextra_charge, pextra_charge,                     "
               "              iquery_num_damage, iquery_num, mequipment,           "
               "              survey_num,  bound_num,    abnormal_num, iapplicant, iroute, qlia_acc_sum, qdmg_acc_sum,  "
               "              fapplicant,fsex_appl,dbirth_appl,itel_appl,ndeputy_appl,nrelation_appl,ndeputy_assured,  "
               "              iassured_cntry, iapplicant_cntry,nassured_cntry, napplicant_cntry,  "
               "              foccup, noccup, applicant_foccup, applicant_noccup, iroute_accept,tmobile_appl , aemail_appl)  "
               "        SELECT '%s', a.qply_period,           a.dply_begin,  a.dply_end,    b.fassured,  "
               "              b.iassured,    b.iassured_ext, replace( trim(b.nassured),'��s�T��','���ר�s����'),    b.ilicense,      "
               "              b.fsex,        b.fmarriage,    b.nuser,       b.ibenef,      b.nbenef,  "
               "              b.aassured,    b.aassured_zip, b.itel,        b.apayment,    b.apayment_zip, "
               "              b.iply_area,   b.nbrand_abbr,  b.ncar_abbr,   b.fcar_note,   b.qcylinder,  "
               "              b.iengine,     b.ibody,        b.itag,          b.mcar_price,  b.nequipment,  "
               "              b.flimit,      b.pdmg_align,   b.pbrg_align,  b.plia_align,  b.idmg_rate,  "
               "              b.pdmg_factor, b.ibrg_rate,    b.pbrg_factor, b.qpt,         b.fpt,  "
               "              b.psex_age,    b.psex_age_damage, b.lia_class,    b.plia_acc,    b.dmg_acc_1st, b.dmg_acc_2nd,  "
               "              b.dmg_acc_3rd, b.pdmg_acc,     b.fhuman,      b.fcomp_24,    '%s',  "
               "              b.iext_policy, b.qpro_month,   b.mkilo_ply,   b.mkilo_edr,   b.irisk,  "
               "              b.irelative_ext,  "
               "              replace( trim(b.napplicant),'��s�T��','���ר�s����'),  b.dbirth,   b.dissue, "
               "              b.iextra_charge, b.gextra_charge, b.pextra_charge,                     "
               "              b.iquery_num_damage, b.iquery_num, b.mequipment,         "
               "              b.survey_num,  b.bound_num,    b.abnormal_num, b.iapplicant, '%s', b.qlia_acc_sum, b.qdmg_acc_sum,  "
               "              b.fapplicant,b.fsex_appl,b.dbirth_appl,b.itel_appl,b.ndeputy_appl,b.nrelation_appl,b.ndeputy_assured,  "
               "              CASE WHEN b.iassured_cntry='' THEN '8' ELSE b.iassured_cntry END,  "
               "              CASE WHEN b.iapplicant_cntry='' THEN '8' ELSE b.iapplicant_cntry END, b.nassured_cntry, b.napplicant_cntry, "
               "              b.foccup, b.noccup, b.applicant_foccup, b.applicant_noccup, '%s',b.tmobile_appl , b.aemail_appl  "
               "          FROM %s:ply_relation a, %s:policy b  "
               "         WHERE a.ipolicy = b.ipolicy  "
               "           AND a.ipolicy = '%s' ", policyDBname, iendorse, payresult, iroute, iroute_accept_edr, policyDBname, policyDBname, sIpolicy);

               printf("[%s]\n",stmt);
               $PREPARE prep2 FROM  $stmt;
               $EXECUTE prep2;

               /*�U�CSQL��fedr_class�n��5:�@���� */
               sprintf_s(stmt, sizeof stmt, "INSERT INTO %s:edr_relation  "
                    "         (iendorse,      fcard_class,   ipolicy,       icard,             irelative_ply,  "
                    "          irelative_edr, fedr_class,    fpay,          ipay,              iedr_field,  "
                    "          dedr_begin,    dedr_end,      ipro_year,         ibrand,  "
                    "          icar_type,     medrdmg_agent, medrdmg_commi, medrdmg_prem,      medrdmg_pure_prem, "
                    "          medrlia_agent, medrlia_commi, medrlia_prem,  medrlia_pure_prem, ibig_comp,  "
                    "          ibig_branch,   ibig_office,   ibig_sales,    iresource,         ibroker,  "
                    "          iofficer,      ileader,       icorps,        iedr_area,         iedr_cashier,  "
                    "          iedr_examiner, dedr_examine,  dentry,        dendorse,          fprint,  "
                    "          itreaty,       ibranch,       iquota,        icomp_in,          ibranch_in,  "
                    "          icomp_at,      ibranch_at,    medr_ready,    medr_stable,       medr_compensate,  "
                    "          medr_adjcom,   medr_research, medr_invest,   medr_bus_rule,     medr_business,  "
                    "          medr_capital,  medr_maintain, fcomp_class,   fcomp_class_last,  fdiscount,  "
                    "          medrdmg_disc,  medrlia_disc,  iedr_return,   icar_flag,         terminate_rsn,  "
                    "          qcount,        iofficer_prmt, iquota_prmt,   ileader_prmt,      irate_type,  "
                    "          bzfrom,        iroute_comm,   icomm_obj,     qprovision,        isecond_hand,icard_main, qdrunk_driving, isign, "
                    "          feply,         feedr,         aemail_eply,   tmobile_eply,      ireg_no, dnotifyornot,  "
                    "          isign_edr,dsign_edr, fsign_status_edr,funder_chk_edr, iprog,qviolate )  "
                    "  SELECT  '%s',        fcard_class, ipolicy,     icard,            irelative_ply,  "
                    "          ' ',         '5',         ' ',         ' ',              ' ',  "
                    "          %ld,         dply_end,    ipro_year,        ibrand,  "
                    "          icar_type,        0,           0,           0,                0,  "
                    "          0,           0,           0,           0,                ibig_comp,  "
                    "          ibig_branch, ibig_office, ibig_sales,  iresource,        ibroker,  "
                    "          iofficer,    '%s',        icorps,      iarea,            icashier,  "
                    "          '881236',    %ld,         %ld,         %ld ,             1,  "
                    "          itreaty,     ibranch,     '%s',        icomp_in,         ibranch_in,  "
                    "          icomp_at,    ibranch_at,  0,           0,                0,  "
                    "          0,           0,           0,           0,                0,  "
                    "          0,           0,           fcomp_class, fcomp_class_last, fdiscount,  "
                    "          0,           0,           '0',         icar_flag,        '0',  "
                    "          0,           iofficer_prmt,iquota_prmt,ileader_prmt,     irate_type,  "
                    "          bzfrom,      iroute_comm, icomm_obj,   qprovision,       isecond_hand,icard_main, qdrunk_driving, isign, "
                    "          feply,       '0',         aemail_eply, tmobile_eply,     ireg_no , '%s',  "
                    "          'system',    today,       40,          'N' ,             'car616b',qviolate  "
                    "    FROM %s:ply_relation  "
                    "   WHERE ipolicy = '%s'", policyDBname,
                       iendorse, dwritten, ileader, dwritten, dwritten, dwritten, iquota, s_notifyornot, policyDBname, sIpolicy);

               $PREPARE prep3 FROM  $stmt;
               $EXECUTE prep3;

               sprintf_s(stmt, sizeof stmt, "UPDATE %s:ply_relation  "
                             "   SET iquota    = '%s',"                       
                             "       ileader   = '%s',  "
                             "       dnotifyornot   = '%s'  "
                             " WHERE ipolicy = '%s'", 
                                   policyDBname, iquota, ileader,s_notifyornot, sIpolicy);
               $PREPARE prep4 FROM  $stmt;
               $EXECUTE prep4;

               sprintf_s(stmt, sizeof stmt, "UPDATE %s:edr_relation SET iedr_field = ? WHERE iendorse = '%s'", 
                             policyDBname, iendorse);
                             
               $PREPARE prep5 FROM  $stmt;
               $EXECUTE prep5 USING $iedr_field;
         
               /*�^���̷s�O��*/
               sprintf_s(stmt, sizeof stmt, "UPDATE %s:policy  "
                             "   SET nassured = (SELECT replace( trim(nassured),'��s�T��','���ר�s����') FROM %s:policy WHERE ipolicy='%s'), "  
                             "       napplicant =  (SELECT replace( trim(napplicant),'��s�T��','���ר�s����') FROM %s:policy WHERE ipolicy='%s')"                                            
                             " WHERE ipolicy = '%s'", policyDBname, policyDBname, sIpolicy, policyDBname, sIpolicy, sIpolicy);
                             
               $PREPARE prep6 FROM  $stmt;
               $EXECUTE prep6;
                  
               sprintf_s(sMsg, sizeof sMsg, "�O�渹[%s]\t�w�X���A��渹[%s]", sIpolicy,iendorse );  
               fprintf( report, "%s\n", sMsg);
         
         
                     
    } /* End for(;;) */
    
    printf( "iCount=[%d]\n", iCount);
    $CLOSE curs1;   
    $Free curs1;

   

    sprintf_s(TmpName, sizeof TmpName, "car616b_report.txt", outputf);



    fclose(report);
    rc=rptftpinsert(userid,"car616b","car616b_report.txt");
    if (rc!=0) {
        EWRITE(userid,rc,"�g�Jrptftplist���~");
        return rc;
    }


    time(&tt);
    printf("�ɶ�[%s]\n", ctime(&tt));

    sprintf_s(sMsg, sizeof sMsg, "�@[%d]��\n", iCount);
    WRITELOG( sfp, sMsg);
    printf("sMsg[%s]", sMsg);

    sprintf_s(sMsg, sizeof sMsg,"��粒��,���I���ɮפU���@�~�d��[Q],�U����ﵲ�G����[%s] \r\n", TmpName);

    return M_CM_OK;

 errexit:

    sprintf_s(v_sMsg, sizeof v_sMsg, "SQLCODE[%d], ERRM[%s] �O�渹[%s],���P���X[%s]\n",
          SQLCODE, sqlca.sqlerrm, sIpolicy,  sItag);

    strcat( sMsg, v_sMsg);
    fprintf( report, "%s\n", sMsg);
    fclose(report);
    printf("sMsg[%s]\n", sMsg);
    return SQLCODE; 
}


/*--------------------------------------------------------------------*/

     

