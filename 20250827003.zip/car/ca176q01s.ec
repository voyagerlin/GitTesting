#include <stdio.h>
#include <stdlib.h>
#include "sqlfatal.h"
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "car_common.h"
#include <math.h>
#include "safeclib.h"

#define SUCCESS                 1

FILE  *fptr, *fptr_err;
$char  errFile[120];
$char   stmt[4096];
$static char remotedb[DBNAME]; 
int   count_db,k,i; 
$char  data_yyyymm[7],idata[2],data_yyyymm_tmp[7];

$char DBName[05];
$char msgbuf[128];
DBinfo *list;
char    sApHome[30];
int rtncode,rc;
char    filename[30];
FILE    *fp;
char  file_catalog[200];
$char filename1[200];
$char userid[11];
$char aphome[40],prtfile[80],outputf[80],outputf1[80],tmp_outputf[21];
char option[2];
char errmsg[300],Message[300];
int res;

long car176_get_db();
long car176_build_W();
long car176_build_X();
long car176_build_YZ();
/*long car176_build_Z();*/

main(argc,argv)
int argc;
char **argv;
{
	batchinit();
	
	strcpy(DBName      ,isNULLstr(argv[1]));
	strcpy(userid      ,isNULLstr(argv[2]));
	strcpy(idata       ,isNULLstr(argv[3]));
	strcpy(data_yyyymm ,isNULLstr(argv[4]));
	strcpy(outputf     ,isNULLstr(argv[5]));
	
	printf("DBName[%s],userid[%s],data_yyyymm[%s],idata[%s],outputf[%s] \n",DBName,userid,data_yyyymm,idata,outputf);
	
	rc = car176_get_db();
	if (rc != M_CM_OK)
	{
		return rc;
	}
	
	if (idata[0] == 'W')
	{
		rc = car176_build_W();
		if ( rc != SUCCESS ) {
		 	printf("error on car9995_build_W \n");
		 	EWRITE(userid, rc, errmsg);
			return rc;	
		}
	}
	else if (idata[0] == 'X')
	{
		rc = car176_build_X();
		if ( rc != SUCCESS ) {
		 	printf("error on car9995_build_X \n");
		 	EWRITE(userid, rc, errmsg);
			return rc;	
		}
	}
	else if (idata[0] == 'Y' || idata[0] == 'Z')
	{
		rc = car176_build_YZ();
		if ( rc != SUCCESS ) {
		 	printf("error on car9995_build_Y \n");
		 	EWRITE(userid, rc, errmsg);
			return rc;	
		}
	}
	
	strcpy(Message,  "���榨�\ \n");
	EWRITE(userid,M_CM_OK,Message);
	return SUCCESS;
}

long car176_get_db()
{
	$whenever sqlerror goto errexit1;

	if (db_select(DBName) == DBName) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	
	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
	 	return rc;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit1:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

long car176_build_W()
{
	$char   ipolicy[21],iendorse[21],icompany[3],iply_br[3],iply[13],iply_last_br[3],iply_last[13];
	$char   iedr_br[3],iedr[13],iarea[3],dedr_begin[9],dedr_end[9],dply_begin[9],dply_end[9],iobjno[5],iissue_ym[7],ipro_ym[7],ibrand[9];
	$char   icar_type_ori[3],icar_type[3],icar_type_no[3],iengine[26],itag[13],fpt[2],iassured[11],dbirth_y[5],fsex[2],fmarriage[2];
	$char   ipdmg_align[2],ipbrg_align[2],iplia_align[2],iins_type[7],iins_main[7],iins_type_main[2],iins_type_dtl[3];
	$char   iedr_type_ori[3],iedr_type[3],iins_type_dev[5],iins_type_rule[3],frule[2],ubi_data[9],fmdeduct[2];
	$char   iproduct[13],drate_ym[7],dendorse_ym[7],dpolicy_ym[7],bzfrom[3],dsend[9];
	$long   qcylinder = 0,qpt = 0,padjust_rate = 0,p_mcar_price = 0,qdmg_acc_year = 0,qdmg_acc_time = 0,pdepreciate_year = 0;
	$long   minjured_cover = 0,mdeath_cover = 0,mdamage_cover = 0,mdamage_cover_bak,mdamage_cover_aft,iins_mult = 0;
	$long   mdeduct = 0,mprem = 0,mprem_pure = 0,mprem_bak,mprem_pure_bak,mprem_aft,mprem_pure_aft;
	$double pins_acc = 0.0,psex_age = 0.0,mprem_pure_base = 0.0,mprem_pure_base_bak,mprem_pure_base_aft,coefficient = 0.0;
	$char   pins_acc_tmp[7],psex_age_tmp[7],mprem_pure_base_tmp[15],mprem_pure_base_bak_tmp[15],mprem_pure_base_aft_tmp[15],coefficient_tmp[15];
	
	$char   qcylinder_c[6],qpt_tmp[5],adjust_tmp[4],p_mcar_price_tmp[4],qdmg_acc_year_c[2],qdmg_acc_time_c[2],sex_age_tmp[4];
	$char   minjured_c[10],mdeath_c[10],mdamage_c[10],pdepreciate_year_tmp[4],iins_mult_c[3];
	$char   mdeduct_c[8],mprem_c[10],mprem_pure_c[10],mprem_pure_base_c[14];
	
	char prtstr[304];

	filename[0]    = '\0';
	file_catalog[0] = '\0';
	sprintf_s(filename, sizeof filename,"%s/rptftp/", sApHome);
	sprintf_s(filename1, sizeof filename1,"AUTOW17_%d.txt",atoi(data_yyyymm)+191100);
	strcpy(file_catalog, trim(filename));
	strcat(file_catalog, trim(filename1));
	
	sprintf_s(data_yyyymm_tmp, sizeof data_yyyymm_tmp,"%d", atoi(data_yyyymm)+191100);
	
	$whenever sqlerror goto errexitW;

	if ((fptr=fopen(file_catalog,"w")) == NULL)
	{
		sprintf_s(errmsg, sizeof errmsg,"Cannot open print file: %s",outputf);
		return M_CM_OPEN_FILE_FAIL;
	}
	
	/* *** open error log file *** */
	res = getApHome(aphome);
	sprintf_s(errFile, sizeof errFile,"%s.%s.error",outputf,DBName);
	if ((fptr_err=fopen(errFile,"w")) == NULL)
	{
		sprintf_s(errmsg, sizeof errmsg,"Cannot open print file: %s",errFile);
		return M_CM_OPEN_FILE_FAIL;
	}

	for(k=0;k<count_db;k++)
	{
		sprintf_s(stmt, sizeof stmt,"SELECT ipolicy,iendorse,icompany,iply_br,iply,iply_last_br,iply_last, "
		                    " iedr_br,iedr,iarea,dedr_begin,dedr_end,dply_begin,dply_end,iobjno,iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no, "
		                    " qcylinder,iengine,itag,qpt,fpt,iassured,dbirth_y,fsex,fmarriage, "
		                    " ipdmg_align,ipbrg_align,iplia_align,iins_type,iins_main,iins_type_main,iins_type_dtl,iedr_type_ori,iedr_type,iins_type_dev,iins_type_rule,frule, "
		                    " padjust_rate,p_mcar_price,pins_acc,qdmg_acc_year,qdmg_acc_time,psex_age,pdepreciate_year,ubi_data, "
		                    " minjured_cover,mdeath_cover,mdamage_cover,mdamage_cover_bak,mdamage_cover_aft, "
		                    " iins_mult,fmdeduct,mdeduct,mprem,mprem_pure,mprem_pure_base, "
		                    " mprem_bak,mprem_pure_bak,mprem_pure_base_bak,mprem_aft,mprem_pure_aft,mprem_pure_base_aft, "
		                    " coefficient,iproduct,drate_ym,dendorse_ym,dpolicy_ym,bzfrom,dsend "
		               " FROM %s:ca_dev_ply_edr "
		              " WHERE data_yyyymm = '%s' "
		                " AND idata       = '%s' ",list[k].dbname,data_yyyymm_tmp,idata);
		
		printf("stmt[%s] \n",stmt);
		$PREPARE ca_dev_ply1 FROM $stmt;
		$DECLARE ca_dev_ply CURSOR FOR ca_dev_ply1;
		$OPEN ca_dev_ply;
		while (1)
		{
			$FETCH ca_dev_ply INTO $ipolicy,$iendorse,$icompany,$iply_br,$iply,$iply_last_br,$iply_last,
                                   $iedr_br,$iedr,$iarea,$dedr_begin,$dedr_end,$dply_begin,$dply_end,$iobjno,$iissue_ym,$ipro_ym,$ibrand,$icar_type_ori,$icar_type,$icar_type_no,
                                   $qcylinder,$iengine,$itag,$qpt,$fpt,$iassured,$dbirth_y,$fsex,$fmarriage,
                                   $ipdmg_align,$ipbrg_align,$iplia_align,$iins_type,$iins_main,$iins_type_main,$iins_type_dtl,$iedr_type_ori,$iedr_type,$iins_type_dev,$iins_type_rule,$frule,
                                   $padjust_rate,$p_mcar_price,$pins_acc,$qdmg_acc_year,$qdmg_acc_time,$psex_age,$pdepreciate_year,$ubi_data,
                                   $minjured_cover,$mdeath_cover,$mdamage_cover,$mdamage_cover_bak,$mdamage_cover_aft,
                                   $iins_mult,$fmdeduct,$mdeduct,$mprem,$mprem_pure,$mprem_pure_base,
                                   $mprem_bak,$mprem_pure_bak,$mprem_pure_base_bak,$mprem_aft,$mprem_pure_aft,$mprem_pure_base_aft,
                                   $coefficient,$iproduct,$drate_ym,$dendorse_ym,$dpolicy_ym,$bzfrom,$dsend;
			
			printf("data_yyyymm[%s],ipolicy[%s],icompany[%s],iply_br[%s],iply[%s],iply_last_br[%s],iply_last[%s] \n",
			        data_yyyymm,ipolicy,icompany,iply_br,iply,iply_last_br,iply_last);
			printf("iarea[%s],dply_begin[%s],dply_end[%s],iobjno[%s],iissue_ym[%s],ipro_ym[%s],ibrand[%s],icar_type_ori[%s],icar_type[%s],icar_type_no[%s] \n",
			        iarea,dply_begin,dply_end,iobjno,iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no);
			printf("qcylinder[%d],iengine[%s],itag[%s],qpt[%d],fpt[%s],iassured[%s],dbirth_y[%s],fsex[%s],fmarriage[%s] \n",
			        qcylinder,iengine,itag,qpt,fpt,iassured,dbirth_y,fsex,fmarriage);
			printf("ipdmg_align[%s],ipbrg_align[%s],iplia_align[%s],iins_type[%s],iins_main[%s],iins_type_main[%s],iins_type_dtl[%s],iins_type_dev[%s],iins_type_rule[%s],frule[%s] \n",
			        ipdmg_align,ipbrg_align,iplia_align,iins_type,iins_main,iins_type_main,iins_type_dtl,iins_type_dev,iins_type_rule,frule);
			printf("padjust_rate[%d],p_mcar_price[%d],pins_acc[%f],qdmg_acc_year[%d],qdmg_acc_time[%d],psex_age[%f],pdepreciate_year[%d],ubi_data[%s] \n",
			        padjust_rate,p_mcar_price,pins_acc,qdmg_acc_year,qdmg_acc_time,psex_age,pdepreciate_year,ubi_data);
			printf("iins_mult[%d],fmdeduct[%s],mdeduct[%d],mprem[%d],mprem_pure[%d],mprem_pure_base[%f] \n",
			        iins_mult,fmdeduct,mdeduct,mprem,mprem_pure,mprem_pure_base);
			printf("coefficient[%f],iproduct[%s],drate_ym[%s],dpolicy_ym[%s],bzfrom[%s],dsend[%s] \n",
			        coefficient,iproduct,drate_ym,dpolicy_ym,bzfrom,dsend);
			        
			if (SQLCODE == SQLNOTFOUND) break;

			/*1-2  ���q�N��*/
			printf("--���q�N��\n");
			strcpy(prtstr, icompany);

			/*3-4  ������c*/
			printf("--������c\n");
			strncpy(iply_br,&ipolicy[0],2); iply_br[2]='\0';	
			if (iply_br[0] == '\0') 
			{
				strcat(prtstr,"00");
			}
			else
			{
				strcat(prtstr,iply_br);
			}

			/*5-16  �O��s��*/
			printf("--�O��s��\n");
			if (iply[0]=='\0')
			{
				strcat(prtstr,"          ");
			}
			else
			{
				strncat(prtstr,iply,10);
			}
			prtstr[14]='\0';
			strcat(prtstr, "  ");
			
			/*21-32  ��O�O��s��*/
			printf("--��O�O��s��\n");
			if (strlen(trim(iply_last)) == 0)
			{
				strcat(prtstr,"              ");
			}
			else
			{
				strcat(prtstr,icompany);
				if (iply_last_br[0] == '\0') strcat(prtstr,"00");
				else strcat(prtstr,iply_last_br);
				strcat(prtstr,iply_last);
			}
			prtstr[30]='\0';
			strcat(prtstr, "  ");

			/*33-34  �ӫO�a�ϥN��*/
			printf("--�ӫO�a�ϥN��\n");
			strcat(prtstr, iarea);
			prtstr[34]='\0';

			/*35-42  �O�I�ͮĶ}�l���*/
			printf("--�O�I�ͮĶ}�l���\n");
			strcat(prtstr,dply_begin);

			/*43-50  �O�I�ͮĲפ���*/
			printf("--�O�I�ͮĲפ���\n");
			strcat(prtstr,dply_end);

			/*51-54  �O��Ъ���*/
			printf("--�O��Ъ���\n");
			if ((strlen(rtrim(iobjno))) == 0)
			{
				strcat(prtstr,"0001");
			}
			else
			{
				strcat(prtstr,iobjno);
			}
			
			/*55-64  �o��/�s�y�~��*/
			printf("--�o��/�s�y�~��\n");
			strcat(prtstr,iissue_ym); /*�o�Ӧ~��*/
			strcat(prtstr,ipro_ym);   /*�s�y�~��*/
			
			/*67-74  �t�P�����N��*/
			printf("--�t�P�����N��\n");
			strcat(prtstr,ibrand);
	
			/*75-76  ���������N��*/
			printf("--���������N��\n");
			strcat(prtstr,icar_type);
			
			/*77-78  �����������O�N�� */
			printf("--�����������O�N��\n");
			strcat(prtstr,icar_type_no);
			
			/*79-83  �Ʈ�q*/
			printf("--�Ʈ�q\n");
			rfmtdouble(qcylinder,"&&&&&",qcylinder_c);
			strcat(prtstr,qcylinder_c);
			
			/*84-108  ����/������*/
			printf("--����/������\n");
			if ((iengine[0]=='\0' || iengine[0]==' ')) 
			{
				strcat(prtstr,"                         ");
			}
			else 
			{
				strcat(prtstr,iengine);
			}
			
			/*109-120  �P�Ӹ��X*/
			printf("--�P�Ӹ��X\n");
			if (itag[0]=='\0' || itag[0]==' ')
			{
				strcat(prtstr,"            ");
			}
        	else 
        	{
        		strcat(prtstr,itag);
        	}                
			
			/*121-124  �����ƶq*/
			printf("--�����ƶq\n");
			/*** if (qpt < 5) qpt = 5; ***/
			rfmtdouble(qpt,"&&&&", qpt_tmp);
			strcat(prtstr,qpt_tmp);  
       
			/*125-125  �������*/
			printf("--�������\n");
			if (strlen(rtrim(fpt)) == 0) 
			{
				strcat(prtstr," ");
			}
			else 
			{
				strcat(prtstr,fpt);
			}                 

			/*126-141  �Q�O�I�H���*/
			printf("--�Q�O�I�H���\n");
			strcat(prtstr, rtrim(iassured));  /*126-135  �Q�O�I�H�����Ҹ�/�νs*/
			for(i=0 ; i < (10-strlen(rtrim(iassured))); i++) strcat(prtstr, " ");
			strcat(prtstr, dbirth_y);         /*136-139  �X�ͦ~��*/
			strcat(prtstr, fsex);             /*140-140  �ʧO*/
			strcat(prtstr, fmarriage);        /*141-141  �B�çO*/
			prtstr[141]='\0';
			
			/*142-144  �h�����u�ݥN��*/
			printf("--�h�����u�ݥN��\n");
			strcat(prtstr, ipdmg_align);
			strcat(prtstr, ipbrg_align);
			strcat(prtstr, iplia_align);

			/*145-152  �o�i���߫O�I�����B�O�v�W�����*/
			/*145  �O�I�����j��*/
			printf("--�O�I�����j��\n");
			if (strcmp(trim(iins_type_main),"")==0) 
			{
				strcat(prtstr," ");
			}
			else 
			{
				strcat(prtstr,trim(iins_type_main));
			}
			/*146-147  �O�I�����Ӷ�*/
			printf("--�O�I�����Ӷ�\n");
			if (strcmp(trim(iins_type_dtl),"")==0) 
			{
				strcat(prtstr,"  ");
			}
			else 
			{
				strcat(prtstr,trim(iins_type_dtl));
			}
			/*148-149  �I�O�N��*/
			printf("--�I�O�N��\n");
			if (strcmp(trim(iins_type_dev),"")==0) 
			{
				strcat(prtstr,"  ");
			}
			else 
			{
				strcat(prtstr,trim(iins_type_dev));
			}
			/*150-151  �I�O����*/
			printf("--�I�O����\n");
			if (strcmp(trim(iins_type_rule),"")==0) 
			{
				strcat(prtstr,"20");
			}
			else 
			{
				strcat(prtstr,trim(iins_type_rule));
			}
			/*152  �O�_���W���O�v*/
			printf("--�O�_���W���O�v\n");
			if (strcmp(trim(iins_type_rule),"")==0) 
			{
				strcat(prtstr,"N");
			}
			else 
			{
				strcat(prtstr,frule);
			}

			/*153-156  �����[��T��*/
			printf("--�����[��T��\n");
			if(padjust_rate < 0)
			{
				strcat(prtstr,"-");
				rfmtdouble(padjust_rate,"&&&", adjust_tmp);
				strcat(prtstr,adjust_tmp);
			}
			else
			{
				strcat(prtstr,"+");
				if( padjust_rate > 0 )
				{
					rfmtdouble(padjust_rate,"&&&", adjust_tmp);
					strcat(prtstr,adjust_tmp);
				}
				else
					strcat(prtstr,"000");
			}
			prtstr[156]='\0';

			/*157-160  �[�˳]�ƫ�W�L���m���椧�T��*/
			printf("--�[�˳]�ƫ�W�L���m���椧�T��\n");
			if(p_mcar_price < 0)
			{
				strcat(prtstr,"-");
				rfmtdouble(p_mcar_price,"&&&", p_mcar_price_tmp);
				strcat(prtstr,p_mcar_price_tmp);
			}
			else
			{
				strcat(prtstr,"-");
				rfmtdouble(p_mcar_price,"&&&", p_mcar_price_tmp);
				strcat(prtstr,p_mcar_price_tmp);
			}
			
			/*161-164  �Q�O�I�H�ߴګY��*/
			printf("--�Q�O�I�H�ߴګY��\n");
			if( pins_acc < 0 )
			{
				strcat(prtstr,"-");
				rfmtdouble((pins_acc*100),"&&&", pins_acc_tmp);
				strcat(prtstr,pins_acc_tmp);
			}
			else
			{
				strcat(prtstr,"+");
				if( pins_acc > 0 )
				{
					rfmtdouble((pins_acc*100),"&&&", pins_acc_tmp);
					strcat(prtstr,pins_acc_tmp);
				}
				else strcat(prtstr,"000");
			}

			/*165-166  �L�ߴڦ~���I�� = �ߴڬ����I�� - �ߴڦ����I��*/
			printf("--�L�ߴڦ~���I��\n");
			if (qdmg_acc_year < 0) 
			{
				strcat(prtstr,"-");
				rfmtdouble(qdmg_acc_year,"&", qdmg_acc_year_c);
				strcat(prtstr,qdmg_acc_year_c);
			}
			else 
			{
				strcat(prtstr,"+");
				rfmtdouble(qdmg_acc_year,"&", qdmg_acc_year_c);
				strcat(prtstr,qdmg_acc_year_c);
			}
			
			/*167-168  �ߴڦ����I��*/
			printf("--�ߴڦ����I��\n");
			if (qdmg_acc_year < 0) 
			{
				if (qdmg_acc_time == 0) strcat(prtstr,"-");
				else strcat(prtstr,"+");
				rfmtdouble(qdmg_acc_time,"&", qdmg_acc_time_c);
				strcat(prtstr,qdmg_acc_time_c);
			}
			else 
			{
				strcat(prtstr,"+");
				rfmtdouble(qdmg_acc_time,"&", qdmg_acc_time_c);
				strcat(prtstr,qdmg_acc_time_c);
			}

			/*169-172  �Q�O�I�H�~�֩ʧO�Y��*/
			printf("--�Q�O�I�H�~�֩ʧO�Y��\n");
			if( psex_age < 0 )
			{
				strcat(prtstr,"-");
				rfmtdouble(psex_age,"&&&", sex_age_tmp);
				strcat(prtstr,sex_age_tmp);
			}
			else
			{
				strcat(prtstr,"+");
				if( psex_age > 0 )
				{
					rfmtdouble(psex_age,"&&&", sex_age_tmp);
					strcat(prtstr,sex_age_tmp);
				}
				else strcat(prtstr,"000");
			}

			/*173-176  ���²v�ʤ���-�~���� */
			printf("--���²v�ʤ���-�~����\n");
			if (pdepreciate_year >=0)
				strcat(prtstr,"+");
			else 
				strcat(prtstr,"-");
			rfmtlong(pdepreciate_year,"&&&", pdepreciate_year_tmp);
			strcat(prtstr,pdepreciate_year_tmp);

			/*177-184  ubi�ӫ~�O�v�]�l */
			printf("--ubi�ӫ~�O�v�]�l\n");
			strcat(prtstr,ubi_data);

			/*185-214  �O�I���B���*/
			/*185-194  �C�@�H��˫O�B*/
			printf("--�C�@�H��˫O�B\n");
			if( minjured_cover < 0 ) 
				strcat(prtstr,"-");
			else 
				strcat(prtstr,"+");
			rfmtdouble(minjured_cover,"&&&&&&&&&",minjured_c);
			strcat(prtstr,minjured_c);
			
			/*195-204   �C�@���`�O�B*/
			printf("--�C�@���`�O�B\n");
			if( mdeath_cover < 0 ) 
				strcat(prtstr,"-");
			else 
				strcat(prtstr,"+");
			rfmtdouble(mdeath_cover,"&&&&&&&&&",mdeath_c);
			strcat(prtstr,mdeath_c);
			
			/*205-214   �C�@�ƬG�O�B*/
			printf("--�C�@�ƬG�O�B\n");
			if( mdamage_cover < 0 ) 
				strcat(prtstr,"-");
			else 
				strcat(prtstr,"+");
			rfmtdouble(mdamage_cover,"&&&&&&&&&",mdamage_c);
			strcat(prtstr,mdamage_c);
			
			/*215-217  �O�٭���*/
			printf("--�O�٭���\n");
			rfmtdouble(iins_mult,"&&",iins_mult_c);
			strcat(prtstr,"+");
			strcat(prtstr,iins_mult_c);
			
			/*218-225  �ۭt�B*/
			printf("--�ۭt�B\n");
			strcat(prtstr,fmdeduct);
			rfmtdouble(mdeduct,"&&&&&&&",mdeduct_c);
			strcat(prtstr,mdeduct_c);

			/*226-235  ñ��O�O*/
			printf("--ñ��O�O\n");
			if( mprem < 0 ) strcat(prtstr,"-");
			else strcat(prtstr,"+");
			rfmtdouble(mprem,"&&&&&&&&&",mprem_c);
			strcat(prtstr,mprem_c);
			
			/*236-245  �«O�O*/
			printf("--�«O�O\n");
			if( mprem_pure < 0 ) strcat(prtstr,"-");
			else strcat(prtstr,"+");
			rfmtdouble(mprem_pure,"&&&&&&&&&",mprem_pure_c);
			strcat(prtstr,mprem_pure_c);
			
			/*245-259  �򥻯«O�O*/
			printf("--�򥻯«O�O\n");
			if( mprem_pure_base < 0 ) strcat(prtstr,"-");
			else if ( mprem_pure_base == 0 )
			{
				if( mprem_pure_base < 0 ) strcat(prtstr,"-");
				else strcat(prtstr,"+");
			}
			else strcat(prtstr,"+");
			rfmtdouble((mprem_pure_base*10000),"&&&&&&&&&&&&&",mprem_pure_base_c);
			strcat(prtstr,mprem_pure_base_c);
			
			/*260-271  �ӫ~�N�X*/
			printf("--�ӫ~�N�X\n");
			strcat(prtstr,iproduct);
			
			/*272-277  �O�v��I�~��*/
			printf("--�O�v��I�~��\n");
			strcat(prtstr,drate_ym);

			/*278-283  ñ��~��*/
			printf("--ñ��~��\n");
			strcat(prtstr,dpolicy_ym);

			/*284-285  �q���O�N��*/
			printf("--�q���O�N��\n");
			strcat(prtstr,bzfrom);
			
			/*286-293  ��ƻs�e��*/
			printf("--��ƻs�e��\n");
			strcat(prtstr,dsend);
			
			strcat(prtstr,"0000000000");
			
			printf("prtstr[%s] \n",prtstr);
			fprintf(fptr,"%s\n",prtstr);
		}
		$CLOSE ca_dev_ply;
		$FREE ca_dev_ply;
	}
	fclose(fptr);
	fclose(fptr_err);
	
	printf("END\n");
	return SUCCESS;

errexitW:
	printf("usrid=%s SOLCODE=%d sqlca.sqlerrm=%s\n",userid,SQLCODE,sqlca.sqlerrm);
	sprintf_s(errmsg, sizeof errmsg,"userid=%s SOLCODE=%d sqlca.sqlerrm=%s",userid,SQLCODE,sqlca.sqlerrm);
	fprintf(fptr_err,"%s\n",errmsg);
	return SQLCODE;	
}

long car176_build_X()
{
	$char   ipolicy[21],iendorse[21],icompany[3],iply_br[3],iply[13],iply_last_br[3],iply_last[13];
	$char   iedr_br[3],iedr[13],iarea[3],dedr_begin[9],dedr_end[9],dply_begin[9],dply_end[9],iobjno[5],iissue_ym[7],ipro_ym[7],ibrand[9];
	$char   icar_type_ori[3],icar_type[3],icar_type_no[3],iengine[26],itag[13],fpt[2],iassured[11],dbirth_y[5],fsex[2],fmarriage[2];
	$char   ipdmg_align[2],ipbrg_align[2],iplia_align[2],iins_type[7],iins_main[7],iins_type_main[2],iins_type_dtl[3];
	$char   iedr_type_ori[3],iedr_type[3],iins_type_dev[5],iins_type_rule[3],frule[2],ubi_data[9],fmdeduct[2];
	$char   iproduct[13],drate_ym[7],dendorse_ym[7],dpolicy_ym[7],bzfrom[3],dsend[9];
	$long   qcylinder,qpt,padjust_rate,p_mcar_price,qdmg_acc_year,qdmg_acc_time,pdepreciate_year;
	$long   minjured_cover,mdeath_cover,mdamage_cover,mdamage_cover_bak,mdamage_cover_aft,iins_mult;
	$long   mdeduct,mprem,mprem_pure,mprem_bak,mprem_pure_bak,mprem_aft,mprem_pure_aft;
	$double pins_acc,psex_age,mprem_pure_base,mprem_pure_base_bak,mprem_pure_base_aft,coefficient;
	$char   pins_acc_tmp[7],psex_age_tmp[7],mprem_pure_base_tmp[15],mprem_pure_base_bak_tmp[15],mprem_pure_base_aft_tmp[15],coefficient_tmp[15];
	
	$char   qcylinder_c[6],qpt_tmp[5],adjust_tmp[4],p_mcar_price_tmp[4],qdmg_acc_year_c[2],qdmg_acc_time_c[2],sex_age_tmp[4];
	$char   minjured_c[10],mdeath_c[10],mdamage_c[10],pdepreciate_year_tmp[4],iins_mult_c[3];
	$char   mdeduct_c[8],mprem_c[10],mprem_pure_c[10],mprem_pure_base_c[14];

	char prtstr[318];
	
	filename[0]    = '\0';
	file_catalog[0] = '\0';
	sprintf_s(filename, sizeof filename,"%s/rptftp/", sApHome);
	sprintf_s(filename1, sizeof filename1,"AUTOX17_%d.txt",atoi(data_yyyymm)+191100);
	strcpy(file_catalog, trim(filename));
	strcat(file_catalog, trim(filename1));
	
	sprintf_s(data_yyyymm_tmp, sizeof data_yyyymm_tmp,"%d", atoi(data_yyyymm)+191100);
	
	$whenever sqlerror goto errexitX;

	if ((fptr=fopen(file_catalog,"w")) == NULL)
	{
		sprintf_s(errmsg, sizeof errmsg,"Cannot open print file: %s",outputf);
		return M_CM_OPEN_FILE_FAIL;
	}
	
	/* *** open error log file *** */
	res = getApHome(aphome);
	sprintf_s(errFile, sizeof errFile,"%s.%s.error",outputf,DBName);
	if ((fptr_err=fopen(errFile,"w")) == NULL)
	{
		sprintf_s(errmsg, sizeof errmsg,"Cannot open print file: %s",errFile);
		return M_CM_OPEN_FILE_FAIL;
	}

	for(k=0;k<count_db;k++)
	{
		sprintf_s(stmt, sizeof stmt,"SELECT ipolicy,iendorse,icompany,iply_br,iply,iply_last_br,iply_last, "
		                    " iedr_br,iedr,iarea,dedr_begin,dedr_end,dply_begin,dply_end,iobjno,iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no, "
		                    " qcylinder,iengine,itag,qpt,fpt,iassured,dbirth_y,fsex,fmarriage, "
		                    " ipdmg_align,ipbrg_align,iplia_align,iins_type,iins_main,iins_type_main,iins_type_dtl,iedr_type_ori,iedr_type,iins_type_dev,iins_type_rule,frule, "
		                    " padjust_rate,p_mcar_price,pins_acc,qdmg_acc_year,qdmg_acc_time,psex_age,pdepreciate_year,ubi_data, "
		                    " minjured_cover,mdeath_cover,mdamage_cover,mdamage_cover_bak,mdamage_cover_aft, "
		                    " iins_mult,fmdeduct,mdeduct,mprem,mprem_pure,mprem_pure_base, "
		                    " mprem_bak,mprem_pure_bak,mprem_pure_base_bak,mprem_aft,mprem_pure_aft,mprem_pure_base_aft, "
		                    " coefficient,iproduct,drate_ym,dendorse_ym,dpolicy_ym,bzfrom,dsend "
		               " FROM %s:ca_dev_ply_edr "
		              " WHERE data_yyyymm = '%s' "
		                " AND idata       = '%s' ",list[k].dbname,data_yyyymm_tmp,idata);
		
		printf("stmt[%s] \n",stmt);
		$PREPARE ca_dev_edr1 FROM $stmt;
		$DECLARE ca_dev_edr CURSOR FOR ca_dev_edr1;
		$OPEN ca_dev_edr;
		while (1)
		{
			$FETCH ca_dev_edr INTO $ipolicy,$iendorse,$icompany,$iply_br,$iply,$iply_last_br,$iply_last,
			                       $iedr_br,$iedr,$iarea,$dedr_begin,$dedr_end,$dply_begin,$dply_end,$iobjno,$iissue_ym,$ipro_ym,$ibrand,$icar_type_ori,$icar_type,$icar_type_no,
			                       $qcylinder,$iengine,$itag,$qpt,$fpt,$iassured,$dbirth_y,$fsex,$fmarriage,
			                       $ipdmg_align,$ipbrg_align,$iplia_align,$iins_type,$iins_main,$iins_type_main,$iins_type_dtl,$iedr_type_ori,$iedr_type,$iins_type_dev,$iins_type_rule,$frule,
			                       $padjust_rate,$p_mcar_price,$pins_acc,$qdmg_acc_year,$qdmg_acc_time,$psex_age,$pdepreciate_year,$ubi_data,
			                       $minjured_cover,$mdeath_cover,$mdamage_cover,$mdamage_cover_bak,$mdamage_cover_aft,
			                       $iins_mult,$fmdeduct,$mdeduct,$mprem,$mprem_pure,$mprem_pure_base,
			                       $mprem_bak,$mprem_pure_bak,$mprem_pure_base_bak,$mprem_aft,$mprem_pure_aft,$mprem_pure_base_aft,
			                       $coefficient,$iproduct,$drate_ym,$dendorse_ym,$dpolicy_ym,$bzfrom,$dsend;
			
			printf("data_yyyymm[%s],ipolicy[%s],iendorse[%s],icompany[%s],iply_br[%s],iply[%s],iply_last_br[%s],iply_last[%s] \n",
			        data_yyyymm,ipolicy,iendorse,icompany,iply_br,iply,iply_last_br,iply_last);
			printf("iarea[%s],dedr_begin[%d],dedr_end[%d],iobjno[%s],iissue_ym[%s],ipro_ym[%s],ibrand[%s],icar_type_ori[%s],icar_type[%s],icar_type_no[%s] \n",
			        iarea,dedr_begin,dedr_end,iobjno,iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no);
			printf("qcylinder[%d],iengine[%s],itag[%s],qpt[%d],fpt[%s],iassured[%s],dbirth_y[%s],fsex[%s],fmarriage[%s] \n",
			        qcylinder,iengine,itag,qpt,fpt,iassured,dbirth_y,fsex,fmarriage);
			printf("ipdmg_align[%s],ipbrg_align[%s],iplia_align[%s],iins_type[%s],iins_main[%s],iins_type_main[%s],iins_type_dtl[%s],iedr_type[%s],iins_type_dev[%s],iins_type_rule[%s],frule[%s] \n",
			        ipdmg_align,ipbrg_align,iplia_align,iins_type,iins_main,iins_type_main,iins_type_dtl,iedr_type,iins_type_dev,iins_type_rule,frule);
			printf("padjust_rate[%d],p_mcar_price[%d],pins_acc[%f],qdmg_acc_year[%d],qdmg_acc_time[%d],psex_age[%f],pdepreciate_year[%d],ubi_data[%s] \n",
			        padjust_rate,p_mcar_price,pins_acc,qdmg_acc_year,qdmg_acc_time,psex_age,pdepreciate_year,ubi_data);
			printf("iins_mult[%d],fmdeduct[%s],mdeduct[%d],mprem[%d],mprem_pure[%d],mprem_pure_base[%f] \n",
			        iins_mult,fmdeduct,mdeduct,mprem,mprem_pure,mprem_pure_base);
			printf("coefficient[%f],iproduct[%s],drate_ym[%s],dpolicy_ym[%s],bzfrom[%s],dsend[%s] \n",
			        coefficient,iproduct,drate_ym,dpolicy_ym,bzfrom,dsend);
			if (SQLCODE == SQLNOTFOUND) break;

			/* 1-4 ���q�N���Τ�����c�N�� */
			strcpy(prtstr, icompany);
			strcat(prtstr, iply_br);

			/* 5-16 �O�渹�X */
			if (strlen(trim(iply)) == 0)
			{
				strcat(prtstr,"          ");
			}
			else
			{
				strcat(prtstr, iply);
			}
			prtstr[14]='\0';
			strcat(prtstr, "  ");
			
			/* 17-20 ���q�N���Τ�����c�N�� */
			strcat(prtstr, icompany);
			strcat(prtstr, iedr_br);
			
			/* 21-32 ��渹�X */
			if (strlen(trim(iedr)) == 0)
			{
				strcat(prtstr,"          ");
			}
			else
			{
				strcat(prtstr,iedr);
			}
			prtstr[30]='\0';
			strcat(prtstr, "  ");
			
			/* 33-34 �ӫO�a�ϥN�� */
			strcat(prtstr,iarea);

			/* 35-42 ���ͮİ_�l��� */
			strcat(prtstr,dedr_begin);
			
			/* 43-50 ���ͮĲפ��� */
			strcat(prtstr,dedr_end);
			
			/* 51-56�O�I�}�l�ͮĦ~�� */
			strncat(prtstr,dply_begin,6);
			
			/* 57-60 �O��Ъ��s�� */
			if ((strlen(rtrim(iobjno))) == 0)
			{
				strcat(prtstr,"0001");
			}
			else
			{
				strcat(prtstr,iobjno);
			}
			
			/* 61-66 ��l�o�Ӧ~�� */
			strcat(prtstr,iissue_ym);
			/* 67-72 �s�y�~�� */
			strcat(prtstr,ipro_ym);
			
			/* 73-80 �t�P�����N�� */
			printf("--�t�P�����N��\n");
			strcat(prtstr,ibrand);
	
			/* 81-82 ���������N�� */
			printf("--���������N��\n");
			strcat(prtstr,icar_type);
			
			/* 83-84 �����������O�N�� */
			printf("--�����������O�N��\n");
			strcat(prtstr,icar_type_no);
			
			/* 85-89 �Ʈ�q */
			printf("--�Ʈ�q\n");
			rfmtdouble(qcylinder,"&&&&&",qcylinder_c);
			strcat(prtstr,qcylinder_c);
			
			/* 90-114 ����/�������X */
			printf("--����/������\n");
			if ((iengine[0]=='\0' || iengine[0]==' ')) 
			{
				strcat(prtstr,"                         ");
			}
			else 
			{
				strcat(prtstr,iengine);
			}
			
			/* 115-126 �P�Ӹ��X */
			if (itag[0]=='\0' || itag[0]==' ')
			{
				strcat(prtstr,"            ");
			}
        	else 
        	{
        		strcat(prtstr,itag);
        	}                
			
			/* 127-131 �������� */
			rfmtdouble(qpt,"&&&&", qpt_tmp);
			strcat(prtstr,qpt_tmp);  
       
			if (strlen(rtrim(fpt)) == 0) 
			{
				strcat(prtstr," ");
			}
			else 
			{
				strcat(prtstr,fpt);
			}      
			
			/* 132-147 �Q�O�I�H��� */
			strcat(prtstr, rtrim(iassured));
			for(i=0 ; i < (10-strlen(rtrim(iassured))); i++) strcat(prtstr, " ");
			strcat(prtstr, dbirth_y);
			strcat(prtstr, fsex);
			strcat(prtstr, fmarriage);
			prtstr[147]='\0';
			
			/* 148 �����I�h�����u�� */
			strcat(prtstr, ipdmg_align);
			/* 149 �ѵs�I�h�����u�� */
			strcat(prtstr, ipbrg_align);
			/* 150 �d���I�h�����u�� */
			strcat(prtstr, iplia_align);
			prtstr[150] = '\0';
			
			/* 151 �O�I�����j�� */
			if (strcmp(trim(iins_type_main),"")==0) 
			{
				strcat(prtstr," ");
			}
			else 
			{
				strcat(prtstr,trim(iins_type_main));
			}
			
			/* 152-153 �O�I�����Ӷ� */
			if (strcmp(trim(iins_type_dtl),"")==0) 
			{
				strcat(prtstr,"  ");
			}
			else 
			{
				strcat(prtstr,trim(iins_type_dtl));
			}
			
			/* 154-155 ���ʽ�N�� */
			if (strcmp(trim(iedr_type),"")==0) 
			{
				strcat(prtstr,"  ");
			}
			else 
			{
				strcat(prtstr,trim(iedr_type));
			}
			
			/* 156-157 �I�O�N�� */
			if (strcmp(trim(iins_type_dev),"")==0) 
			{
				strcat(prtstr,"  ");
			}
			else 
			{
				strcat(prtstr,trim(iins_type_dev));
			}
			
			/* 158-159 �I�O���� */
			if (strcmp(trim(iins_type_rule),"")==0) 
			{
				strcat(prtstr,"20");
			}
			else 
			{
				strcat(prtstr,trim(iins_type_rule));
			}
			
			/* 160 �O�_���W���O�v */
			if (strcmp(trim(iins_type_rule),"")==0) 
			{
				strcat(prtstr,"N");
			}
			else 
			{
				strcat(prtstr,frule);
			}
			
			/* 161-164  �����[��T��*/
			if(padjust_rate < 0)
			{
				strcat(prtstr,"-");
				rfmtdouble(padjust_rate,"&&&", adjust_tmp);
				strcat(prtstr,adjust_tmp);
			}
			else
			{
				strcat(prtstr,"+");
				if( padjust_rate > 0 )
				{
					rfmtdouble(padjust_rate,"&&&", adjust_tmp);
					strcat(prtstr,adjust_tmp);
				}
				else
					strcat(prtstr,"000");
			}
			
			/* 165-168 �[�˳]�ƫ᭫�m����T�� */
			if(p_mcar_price < 0)
			{
				strcat(prtstr,"-");
				rfmtdouble(p_mcar_price,"&&&", p_mcar_price_tmp);
				strcat(prtstr,p_mcar_price_tmp);
			}
			else
			{
				strcat(prtstr,"-");
				rfmtdouble(p_mcar_price,"&&&", p_mcar_price_tmp);
				strcat(prtstr,p_mcar_price_tmp);
			}
			
			/* 169-172 �Q�O�I�H�ߴګY�� */
			if( pins_acc < 0 )
			{
				strcat(prtstr,"-");
				rfmtdouble((pins_acc*100),"&&&", pins_acc_tmp);
				strcat(prtstr,pins_acc_tmp);
			}
			else
			{
				strcat(prtstr,"+");
				if( pins_acc > 0 )
				{
					rfmtdouble((pins_acc*100),"&&&", pins_acc_tmp);
					strcat(prtstr,pins_acc_tmp);
				}
				else strcat(prtstr,"000");
			}
			
			/* 173-174 �L�ߴڦ~���I�� = �ߴڬ����I�� - �ߴڦ����I��*/
			if (qdmg_acc_year < 0) 
			{
				strcat(prtstr,"-");
				rfmtdouble(qdmg_acc_year,"&", qdmg_acc_year_c);
				strcat(prtstr,qdmg_acc_year_c);
			}
			else 
			{
				strcat(prtstr,"+");
				rfmtdouble(qdmg_acc_year,"&", qdmg_acc_year_c);
				strcat(prtstr,qdmg_acc_year_c);
			}
			
			/* 175-176 �ߴڦ����I��*/
			if (qdmg_acc_year < 0) 
			{
				if (qdmg_acc_time == 0) strcat(prtstr,"-");
				else strcat(prtstr,"+");
				rfmtdouble(qdmg_acc_time,"&", qdmg_acc_time_c);
				strcat(prtstr,qdmg_acc_time_c);
			}
			else 
			{
				strcat(prtstr,"+");
				rfmtdouble(qdmg_acc_time,"&", qdmg_acc_time_c);
				strcat(prtstr,qdmg_acc_time_c);
			}
			
			/* 177-180 �Q�O�I�H�~�֩ʧO�Y�� */
			if( psex_age < 0 )
			{
				strcat(prtstr,"-");
				rfmtdouble(psex_age,"&&&", sex_age_tmp);
				strcat(prtstr,sex_age_tmp);
			}
			else
			{
				strcat(prtstr,"+");
				if( psex_age > 0 )
				{
					rfmtdouble(psex_age,"&&&", sex_age_tmp);
					strcat(prtstr,sex_age_tmp);
				}
				else strcat(prtstr,"000");
			}
			
			/* 181-184 ���²v�ʤ��� */
			if (pdepreciate_year >=0)
				strcat(prtstr,"+");
			else 
				strcat(prtstr,"-");
			rfmtlong(pdepreciate_year,"&&&", pdepreciate_year_tmp);
			strcat(prtstr,pdepreciate_year_tmp);
			
			/* 185-192 UBI�ӫ~�O�v�]�l*/
			strcat(prtstr,ubi_data);
			
			/* 193-202 �C�H��� */
			if( minjured_cover < 0 ) 
				strcat(prtstr,"-");
			else 
				strcat(prtstr,"+");
			rfmtdouble(minjured_cover,"&&&&&&&&&",minjured_c);
			strcat(prtstr,minjured_c);
			
			/* 203-212 �C�H���` */
			if( mdeath_cover < 0 ) 
				strcat(prtstr,"-");
			else 
				strcat(prtstr,"+");
			rfmtdouble(mdeath_cover,"&&&&&&&&&",mdeath_c);
			strcat(prtstr,mdeath_c);
			
			/* 213-222 �C�@�ƬG */
			if( mdamage_cover < 0 ) 
				strcat(prtstr,"-");
			else 
				strcat(prtstr,"+");
			rfmtdouble(mdamage_cover,"&&&&&&&&&",mdamage_c);
			strcat(prtstr,mdamage_c);
			
			/* 233-225 �O�٭��� */
			rfmtdouble(iins_mult,"&&",iins_mult_c);
			strcat(prtstr,"+");
			strcat(prtstr,iins_mult_c);
			
			/* 226-233 �ۭt�B */
			strcat(prtstr,fmdeduct);
			rfmtdouble(mdeduct,"&&&&&&&",mdeduct_c);
			strcat(prtstr,mdeduct_c);
			
			/* 234-267 �h���u�ݫe�O�O */
			if( mprem < 0 ) strcat(prtstr,"-");
			else strcat(prtstr,"+");
			rfmtdouble(mprem,"&&&&&&&&&",mprem_c);
			strcat(prtstr,mprem_c);
			
			if( mprem_pure < 0 ) strcat(prtstr,"-");
			else strcat(prtstr,"+");
			rfmtdouble(mprem_pure,"&&&&&&&&&",mprem_pure_c);
			strcat(prtstr,mprem_pure_c);
			
			if( mprem_pure_base < 0 ) strcat(prtstr,"-");
			else if ( mprem_pure_base == 0 )
			{
				if( mprem_pure_base < 0 ) strcat(prtstr,"-");
				else strcat(prtstr,"+");
			}
			else strcat(prtstr,"+");
			rfmtdouble((mprem_pure_base*10000),"&&&&&&&&&&&&&",mprem_pure_base_c);
			strcat(prtstr,mprem_pure_base_c);
			
			/* 268-279 �ӫ~�N�X */
			strcat(prtstr,iproduct);
			
			/* 280-285 �O�v��I�~�� */
			strcat(prtstr,drate_ym);
			
			/* 286-291 ���~�� */
			strcat(prtstr,dendorse_ym);
			
			/* 292-297 ñ��~�� */
			strcat(prtstr,dpolicy_ym);
			
			/* 298-299 �q���O�N�� */
			strcat(prtstr,bzfrom);
			
			/* 300-307 ��ƻs�e��� */
			strcat(prtstr,dsend);
			
			/* ubi���{�� */
			strcat(prtstr,"0000000000");
			
			printf("prtstr[%s] \n",prtstr);
			fprintf(fptr,"%s\n",prtstr);
		}
		$CLOSE ca_dev_edr;
		$FREE ca_dev_edr;
	}
	fclose(fptr);
	fclose(fptr_err);
	
	printf("END\n");
	return SUCCESS;

errexitX:
	printf("usrid=%s SOLCODE=%d sqlca.sqlerrm=%s\n",userid,SQLCODE,sqlca.sqlerrm);
	sprintf_s(errmsg, sizeof errmsg,"userid=%s SOLCODE=%d sqlca.sqlerrm=%s",userid,SQLCODE,sqlca.sqlerrm);
	fprintf(fptr_err,"%s\n",errmsg);
	return SQLCODE;	
}

long car176_build_YZ()
{
	$char   istl[2],ipolicy[21],iclaim[21],icompany[3],iclm_br[3],iclm[13],dclaim[9],dgroup[9];
	$char   icompany_ply[3],iply_br[3],iply[13],dply_begin_ym[7],iobjno[5],iissue_ym[7],ipro_ym[7],ibrand[9],icar_type_ori[3],icar_type[3],icar_type_no[3];
	$char   iengine[26],itag[13],fpt[2],iacc_license[11],iacc_birth_y[5],facc_sex[2],facc_marri[2],iacc_reason[3],fduty[2];
	$char   iassured[11],dbirth_y[5],fsex[2],fmarriage[2],daccident[9],dvp_code1[3],dvp_code2[3],fpart[2];
	$char   ipdmg_align[2],ipbrg_align[2],iplia_align[2],iins_type_ori[7],iins_type[7],iins_main[7],iins_type_main[2],iins_type_dtl[3],iins_type_dev[5],iins_type_rule[3],iins_type_class[3],frule[3];
	$char   ubi_data[9],fmdeduct[2],fstl[2],iproduct[13],drate_ym[7],dentry[9],bzfrom[3],dpolicy_ym[7],dsend[9],fsingle_acc[5],adjustment[7],ifacnum[11];
	$long   iclose_type,qcylinder,qpt,qlia1,qlia2,qlia3,p_mcar_price,pdepreciate_year,mcover,iins_mult,mdeduct,qpeople;
	$long   iself_duty,ioth_duty,ianoth_duty,mins_app,mdeduct_clm,mins_stl,mins_proc;
	$double pins_acc,psex_age;
	$char   pins_acc_tmp[7],psex_age_tmp[7];
	
	$char   iclose_type_c[3],qlia1_c[4],qlia2_c[4],qlia3_c[4],qpeople_c[4],iself_duty_c[4],ioth_duty_c[4],ianoth_duty_c[4];
	$char   mcover_c[10],mins_app_c[9],mdeduct_clm_c[8],mins_stl_c[9],mins_proc_c[8];
	$char   qcylinder_c[6],qpt_tmp[5],adjust_tmp[4],p_mcar_price_tmp[4],qdmg_acc_year_c[2],qdmg_acc_time_c[2],sex_age_tmp[4];
	$char   minjured_c[10],mdeath_c[10],mdamage_c[10],pdepreciate_year_tmp[4],iins_mult_c[3];
	$char   mdeduct_c[8],mprem_c[10],mprem_pure_c[10],mprem_pure_base_c[14];

	char prtstr[379];
	
	filename[0]    = '\0';
	file_catalog[0] = '\0';
	sprintf_s(filename, sizeof filename,"%s/rptftp/", sApHome);
	
	sprintf_s(filename1, sizeof filename1,"AUTO%s17_%d.txt",idata[0],atoi(data_yyyymm)+191100);
	
	strcpy(file_catalog, trim(filename));
	strcat(file_catalog, trim(filename1));
	sprintf_s(data_yyyymm_tmp, sizeof data_yyyymm_tmp,"%d",atoi(data_yyyymm)+191100);
	
	$whenever sqlerror goto errexitY;

	if ((fptr=fopen(file_catalog,"w")) == NULL)
	{
		sprintf_s(errmsg, sizeof errmsg,"Cannot open print file: %s",outputf);
		return M_CM_OPEN_FILE_FAIL;
	}
	
	/* *** open error log file *** */
	res = getApHome(aphome);
	sprintf_s(errFile, sizeof errFile,"%s.%s.error",outputf,DBName);
	if ((fptr_err=fopen(errFile,"w")) == NULL)
	{
		sprintf_s(errmsg, sizeof errmsg,"Cannot open print file: %s",errFile);
		return M_CM_OPEN_FILE_FAIL;
	}

	for(k=0;k<count_db;k++)
	{
		sprintf_s(stmt, sizeof stmt,"SELECT istl,ipolicy,iclaim,icompany,iclm_br,iclm,dclaim,iclose_type,dgroup, "
	                        " icompany_ply,iply_br,iply,dply_begin_ym,iobjno,iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no, "
	                        " qcylinder,iengine,itag,qpt,fpt,iacc_license,iacc_birth_y,facc_sex,facc_marri,iacc_reason,fduty, "
	                        " iassured,dbirth_y,fsex,fmarriage,qlia1,qlia2,qlia3,daccident,dvp_code1,dvp_code2,fpart, "
	                        " ipdmg_align,ipbrg_align,iplia_align,iins_type_ori,iins_type,iins_main,iins_type_main,iins_type_dtl,iins_type_dev,iins_type_rule,iins_type_class,frule, "
	                        " p_mcar_price,pins_acc,psex_age,pdepreciate_year,ubi_data,mcover,iins_mult,fmdeduct,mdeduct,qpeople, "
	                        " iself_duty,ioth_duty,ianoth_duty,mins_app,mdeduct_clm,mins_stl,mins_proc,fstl, "
	                        " iproduct,drate_ym,dentry,bzfrom,dpolicy_ym,dsend,fsingle_acc,adjustment,ifacnum "
		               " FROM %s:ca_dev_clm "
		              " WHERE data_yyyymm = '%s' "
		                " AND idata       = '%s' ",list[k].dbname,data_yyyymm_tmp,idata);
		
		printf("stmt[%s] \n",stmt);
		$PREPARE ca_dev_clmY1 FROM $stmt;
		$DECLARE ca_dev_clmY CURSOR FOR ca_dev_clmY1;
		$OPEN ca_dev_clmY;
		while (1)
		{
			$FETCH ca_dev_clmY INTO $istl,$ipolicy,$iclaim,$icompany,$iclm_br,$iclm,$dclaim,$iclose_type,$dgroup,
			                        $icompany_ply,$iply_br,$iply,$dply_begin_ym,$iobjno,$iissue_ym,$ipro_ym,$ibrand,$icar_type_ori,$icar_type,$icar_type_no,
			                        $qcylinder,$iengine,$itag,$qpt,$fpt,$iacc_license,$iacc_birth_y,$facc_sex,$facc_marri,$iacc_reason,$fduty,
			                        $iassured,$dbirth_y,$fsex,$fmarriage,$qlia1,$qlia2,$qlia3,$daccident,$dvp_code1,$dvp_code2,$fpart,
			                        $ipdmg_align,$ipbrg_align,$iplia_align,$iins_type_ori,$iins_type,$iins_main,$iins_type_main,$iins_type_dtl,$iins_type_dev,$iins_type_rule,$iins_type_class,$frule,
			                        $p_mcar_price,$pins_acc,$psex_age,$pdepreciate_year,$ubi_data,$mcover,$iins_mult,$fmdeduct,$mdeduct,$qpeople,
			                        $iself_duty,$ioth_duty,$ianoth_duty,$mins_app,$mdeduct_clm,$mins_stl,$mins_proc,$fstl,
			                        $iproduct,$drate_ym,$dentry,$bzfrom,$dpolicy_ym,$dsend,$fsingle_acc,$adjustment,$ifacnum;
			
			if (SQLCODE == SQLNOTFOUND) break;
			
			printf("data_yyyymm[%s],istl[%s],ipolicy[%s],iclaim[%s],icompany[%s],iclm_br[%s],iclm[%s],dclaim[%s] \n",
	        	    data_yyyymm,istl,ipolicy,iclaim,icompany,iclm_br,iclm,dclaim);
			printf("iclose_type[%d],dgroup[%s],icompany_ply[%s],iply_br[%s],iply,[%s],dply_begin_ym[%s],iobjno[%s] \n",
			        iclose_type,dgroup,icompany_ply,iply_br,iply,dply_begin_ym,iobjno);
			printf("iissue_ym[%s],ipro_ym[%s],ibrand[%s],icar_type_ori[%s],icar_type[%s],icar_type_no[%s],qcylinder[%d] \n",
			        iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no,qcylinder);
			printf("iengine[%s],itag[%s],qpt[%d],fpt[%s],iacc_license[%s],iacc_birth_y[%s],facc_sex[%s],facc_marri[%s] \n",
			        iengine,itag,qpt,fpt,iacc_license,iacc_birth_y,facc_sex,facc_marri);
			printf("iacc_reason[%s],fduty[%s],iassured[%s],dbirth_y[%s],fsex[%s],fmarriage[%s],qlia1[%d],qlia2[%d],qlia3[%d] \n",
			        iacc_reason,fduty,iassured,dbirth_y,fsex,fmarriage,qlia1,qlia2,qlia3);
			printf("daccident[%s],dvp_code1[%s],dvp_code2[%s],fpart[%s],ipdmg_align[%s],ipbrg_align[%s],iplia_align[%s] \n",
			        daccident,dvp_code1,dvp_code2,fpart,ipdmg_align,ipbrg_align,iplia_align);
			printf("iins_type_ori[%s],iins_type[%s],iins_main[%s],iins_type_main[%s],iins_type_dtl[%s],iins_type_dev[%s] \n",
			        iins_type_ori,iins_type,iins_main,iins_type_main,iins_type_dtl,iins_type_dev);
			printf("iins_type_rule[%s],iins_type_class[%s],frule[%s],p_mcar_price[%d],pins_acc[%f],psex_age[%f] \n",
			        iins_type_rule,iins_type_class,frule,p_mcar_price,pins_acc,psex_age);
			printf("pdepreciate_year[%d],ubi_data[%s],mcover[%d],iins_mult[%d],fmdeduct[%s],mdeduct[%d],qpeople[%d] \n",
			        pdepreciate_year,ubi_data,mcover,iins_mult,fmdeduct,mdeduct,qpeople);
			printf("iself_duty[%d],ioth_duty[%d],ianoth_duty[%d],mins_app[%d],mdeduct_clm[%d],mins_stl[%d],mins_proc[%d] \n",
			        iself_duty,ioth_duty,ianoth_duty,mins_app,mdeduct_clm,mins_stl,mins_proc);
			printf("fstl[%s],iproduct[%s],drate_ym[%s],dentry[%s],bzfrom[%s],dpolicy_ym[%s],dsend[%s],fsingle_acc[%s] \n",
			        fstl,iproduct,drate_ym,dentry,bzfrom,dpolicy_ym,dsend,fsingle_acc);
			printf("adjustment[%s],ifacnum[%s] \n",
			        adjustment,ifacnum);

			/* 1-1 �߮שʽ�N�� */
			printf("�߮שʽ�N�� \n");
			strcpy(prtstr, istl);

			/* 2-17 �߮ר��z���X */
			printf("�߮ר��z���X \n");
			strcat(prtstr, icompany);
			strcat(prtstr, iclm_br);
			strcat(prtstr, iclm);

			/* 18-25 �߮ר��z��� */
			printf("�߮ר��z��� \n");
			strcat(prtstr, dclaim);

			/* 26-41 �߮׸��X  */
			printf("�߮׸��X \n");
			strcat(prtstr, icompany);
			strcat(prtstr, iclm_br);
			strcat(prtstr, iclm);

			/* 42-43 �ߥI/�l�v���� */
			printf("�ߥI/�l�v���� \n");
			rfmtlong(iclose_type,"&&",iclose_type_c);
			strcat(prtstr,iclose_type_c);

			/* 44-51 ���פ�� */
			printf("���פ�� \n");
			strcat(prtstr, dgroup);

			/* 52-67 ���q�N���ΫO�渹�X */
			printf("���q�N���ΫO�渹�X \n");
			strcat(prtstr, icompany_ply);
			strcat(prtstr, iply_br);
			iply[12] = '\0';
			strcat(prtstr, iply);

			/* 68-73 �}�l�ͮĦ~�� */
			printf("�}�l�ͮĦ~�� \n");
			strcat(prtstr, dply_begin_ym);

			/* 74-77 �O�I�Ъ��s�� */
			printf("�O�I�Ъ��s�� \n");
			if ((strlen(rtrim(iobjno))) == 0)
			{
				strcat(prtstr,"0001");
			}
			else
			{
				strcat(prtstr,iobjno);
			}

			/* field 10 78-83 ��l�o�Ӧ~�� */
			printf("�o�Ӧ~�� \n");
			strcat(prtstr, iissue_ym);
			
			/* field 11 84-87 �s�y�~+�� */
			printf("�s�y�~�� \n");
			strcat(prtstr, ipro_ym);
			
			/* field 12 88-95 �t�P�����N�� */
			printf("�t�P�����N�� \n");
			strcat(prtstr, ibrand);
			
			/* field 13 96-97 ���إN�� */
			printf("���إN�� \n");
			strcat(prtstr, icar_type);
			
			/* �����������O�N�� */
			printf("�����������O�N�� \n");
			strcat(prtstr, icar_type_no);
			
			/* 102-106 �Ʈ�q */
			printf("�Ʈ�q \n");
			rfmtdouble(qcylinder,"&&&&&",qcylinder_c);
			strcat(prtstr,qcylinder_c);
			
			/* 107-131 �������X */
			printf("�������X \n");
			if ((iengine[0]=='\0' || iengine[0]==' ')) 
			{
				strcat(prtstr,"                         ");
			}
			else 
			{
				strcat(prtstr,iengine);
			}
			
			/* 132-143 �P�Ӹ��X */
			printf("�P�Ӹ��X \n");
			if (itag[0]=='\0' || itag[0]==' ')
			{
				strcat(prtstr,"            ");
			}
        	else 
        	{
        		strcat(prtstr,itag);
        	} 
        	
			/* 144-148 �������� */
			printf("�������� \n");
			rfmtdouble(qpt,"&&&&", qpt_tmp);
			strcat(prtstr,qpt_tmp);  
			if (strlen(rtrim(fpt)) == 0) 
			{
				strcat(prtstr," ");
			}
			else 
			{
				strcat(prtstr,fpt);
			}   
			
			/* 149-158 �r�p�H���*/
			printf("�r�p�H��� \n");
			strcat(prtstr, rtrim(iacc_license));
			for(i=0 ; i < (10-strlen(rtrim(iacc_license))); i++) strcat(prtstr, " ");		
			strcat(prtstr, iacc_birth_y);
			strcat(prtstr, facc_sex);
			strcat(prtstr, facc_marri);
			
			/* 165-166 �X�I��]�N�� */
			printf("�X�I��]�N�� \n");
			strcat(prtstr, iacc_reason);
			
			/* 167 �F�Ƴd���N�� */
			printf("�F�Ƴd���N�� \n");
			strcat(prtstr, fduty);
			prtstr[167]='\0';
			
			/* 168-183 �Q�O�I�H��� */
			printf("�Q�O�I�H��� \n");
			strcat(prtstr, rtrim(iassured));
			for(i=0 ; i < (10-strlen(rtrim(iassured))); i++) strcat(prtstr, " ");
			
			strcat(prtstr, dbirth_y);
			strcat(prtstr, fsex);
			strcat(prtstr, fmarriage);
			
			/* 184-192 �ĤT�H�d���I�ˤ`�H�� */
			printf("�ĤT�H�d���I�ˤ`�H�� \n");
			rfmtlong(qlia1,"&&&",qlia1_c);
			strcat(prtstr, qlia1_c);
			rfmtlong(qlia2,"&&&",qlia2_c);
			strcat(prtstr, qlia2_c);
			rfmtlong(qlia3,"&&&",qlia3_c);
			strcat(prtstr, qlia3_c);
			
			/* 193-200 �X�I��� */
			printf("�X�I��� \n");
			strcat(prtstr, daccident);
			
			/* 201-202 �X�I�a�ϥN�� */
			printf("�X�I�a�ϥN�� \n");
			strcat(prtstr, dvp_code1);
			
			/* 203-204 �ӫO�a�ϥN�� */
			printf("�ӫO�a�ϥN�� \n");
			strcat(prtstr, dvp_code2);
			
			/* 205 �����l�O */
			printf("�����l�O \n");
			strcat(prtstr, fpart);
			
			/* 206-208 �h�����u�ݥN�� */
			printf("�h�����u�f�N�� \n");
			strcat(prtstr, ipdmg_align);
			strcat(prtstr, ipbrg_align);
			strcat(prtstr, iplia_align);
			
			/* 209-217 �O�I�����N�� */
			printf("�O�I�����N�� \n");
			strcat(prtstr,iins_type_main);
			prtstr[209]='\0';
			strcat(prtstr,iins_type_dtl);
			prtstr[211]='\0';
			strcat(prtstr,iins_type_dev);
			prtstr[213]='\0';
			strcat(prtstr,iins_type_rule);
			prtstr[215]='\0';
			strcat(prtstr,iins_type_class);
			prtstr[217]='\0';
			strcat(prtstr,frule);
			prtstr[218]='\0';
			
			/*�[�˳]�ƫ�W�L���m���椧�T��*/  
			printf("�[�˳]�ƫ�W�L���s���椧�T�� \n");
			if(p_mcar_price < 0)
			{
				strcat(prtstr,"-");
				rfmtdouble(p_mcar_price,"&&&", p_mcar_price_tmp);
				strcat(prtstr,p_mcar_price_tmp);
			}
			else
			{
				strcat(prtstr,"+");
				rfmtdouble(p_mcar_price,"&&&", p_mcar_price_tmp);
				strcat(prtstr,p_mcar_price_tmp);
			}
			
			/* field 30 211-213 �Q�O�I�H�����Y�� */
			printf("�Q�O�I�H�����Y�� \n");
			if( pins_acc < 0 )
			{
				strcat(prtstr,"-");
				rfmtdouble((pins_acc*100),"&&&", pins_acc_tmp);
				strcat(prtstr,pins_acc_tmp);
			}
			else
			{
				strcat(prtstr,"+");
				if( pins_acc > 0 )
				{
					rfmtdouble((pins_acc*100),"&&&", pins_acc_tmp);
					strcat(prtstr,pins_acc_tmp);
				}
				else strcat(prtstr,"000");
			}
			
			/*�Q�O�I�H�~�֩ʧO�Y��*/
			printf("�Q�O�I�H�~�֩ʧO�Y�� \n");
			if( psex_age < 0 )
			{
				strcat(prtstr,"-");
				rfmtdouble(psex_age,"&&&", sex_age_tmp);
				strcat(prtstr,sex_age_tmp);
			}
			else
			{
				strcat(prtstr,"+");
				if( psex_age > 0 )
				{
					rfmtdouble(psex_age,"&&&", sex_age_tmp);
					strcat(prtstr,sex_age_tmp);
				}
				else strcat(prtstr,"000");
			}
			
			/*���²v-�����I*/
			printf("���²v \n");
			if (pdepreciate_year >=0)
				strcat(prtstr,"+");
			else 
				strcat(prtstr,"-");
			rfmtlong(pdepreciate_year,"&&&", pdepreciate_year_tmp);
			strcat(prtstr,pdepreciate_year_tmp);
			
			/*UBI�ӫ~�O�v�]�l*/
			printf("UBI�ӫ~�O�v�]�l \n");
			strcat(prtstr,ubi_data);
			
			/* field 31 214-223 �O�I���B */
			printf("�O�I���B \n");
			if( mcover < 0 ) 
				strcat(prtstr,"-");
			else 
				strcat(prtstr,"+");
			rfmtdouble(mcover,"&&&&&&&&&",mcover_c);
			strcat(prtstr,mcover_c);
			
			/*�O�٭���*/
			printf("�O�٭��� \n");
			rfmtdouble(iins_mult,"&&",iins_mult_c);
			strcat(prtstr,"+");
			strcat(prtstr,iins_mult_c);
			
			/* �ۭt�B */
			printf("�ۭt�B \n");
			strcat(prtstr,fmdeduct);
			rfmtdouble(mdeduct,"&&&&&&&",mdeduct_c);
			strcat(prtstr,mdeduct_c);
			
			/* field 33  232-234 ��ڲz�ߤH�� */
			printf("��ڲz�ߤH�� \n");
			rfmtdouble(qpeople,"&&&",qpeople_c);
			strcat(prtstr,qpeople_c);
			
			/* 267-269 �����F�Ƴd���ʤ��� */
			/* 270-272 ��訮�F�Ƴd���ʤ��� */
			/* 273-275 ��L���F�Ƴd���ʤ��� */
			printf("�F�Ƴd���ʤ��� \n");
			rfmtlong(iself_duty,"&&&",iself_duty_c);
			strcat(prtstr, iself_duty_c);
			rfmtlong(ioth_duty,"&&&",ioth_duty_c);
			strcat(prtstr, ioth_duty_c);
			rfmtlong(ianoth_duty,"&&&",ianoth_duty_c);
			strcat(prtstr, ianoth_duty_c);
			
			/* 276-284 �w���l�����B */
			printf("�w���l�����B \n");
			strcat(prtstr,"+");
			rfmtlong(mins_app, "&&&&&&&&", mins_app_c);
			strcat(prtstr, mins_app_c);
			
			/* 292-300 �z�ߦۭt�B */
			printf("�z�ߦۭt�B \n");
			rfmtlong(mdeduct_clm, "&&&&&&&", mdeduct_clm_c);
			strcat(prtstr, mdeduct_clm_c);
			
			/* 292-300 ��ڲz�ߪ��B */
			printf("��ڲz�ߪ��B \n");
			if(mins_stl >= 0)
				strcat(prtstr,"+");
			else 
				strcat(prtstr,"-");
			rfmtlong(mins_stl, "&&&&&&&&", mins_stl_c);
			strcat(prtstr, mins_stl_c);
			
			/* 301-308 �z�߶O�� */
			printf("�z�߶O�� \n");
			strcat(prtstr,"+");
			rfmtlong(mins_proc, "&&&&&&&", mins_proc_c);
			strcat(prtstr, mins_proc_c);
			
			/* 309 �ߥI�N�� */
			printf("�ߥI�N�� \n");
			strcat(prtstr,fstl);
			
			/* 310-321 �ӫ~�N�X  */
			printf("�ӫ~�N�X \n");
			strcat(prtstr,iproduct);
			
			/* 322-327 �O�v��I�~��  */
			printf("�O�v��I�~�� \n");
			strcat(prtstr,drate_ym);
			
			/* 328-335 �ߥI��� */
			printf("�ߥI��� \n");
			strcat(prtstr,dgroup);
			
			/* 336-337 �q���O�N�� 2009.2�W�C�榡*/
			printf("�q���O�N�� \n");
			strcat(prtstr,bzfrom);

			/* 338-343 ñ��~��*/
			printf("ñ��� \n");
			strcat(prtstr,dpolicy_ym);
			prtstr[343] = '\0';
			
			/* 344-351 ��ƻs�e��� */
			printf("��ƭP�e��� \n");
			strcat(prtstr,dsend);
			prtstr[351] = '\0';
			
			/* 352 ��@�����ۦ�I���ƬG�έp�N�X */
			printf("��@���� \n");
			strcat(prtstr,fsingle_acc);
			prtstr[352] = '\0';
			
			/* 353-358 �z�߸g��H���N�X */
			printf("�z�߸g�� \n");
			strcat(prtstr,adjustment);
			prtstr[358] = '\0';
			
			/* 359-368 �ײz�t��Q�Ʒ~�Τ@�s���έt�d�H�����Ҧr�� */
			printf("�ײz�t \n");
			strcat(prtstr,ifacnum);
			prtstr[368] = '\0';
			
			/* 369-378 ���{�� */
			printf("���{�� \n");
			strcat(prtstr,"0000000000");
			prtstr[378] = '\0';
			
			printf("prtstr[%s] \n",prtstr);
			fprintf(fptr,"%s\n",prtstr);
		}
		$CLOSE ca_dev_clmY;
		$FREE ca_dev_clmY;
	}
	fclose(fptr);
	fclose(fptr_err);
	
	printf("END\n");
	return SUCCESS;
	
errexitY:
	printf("usrid=%s SOLCODE=%d sqlca.sqlerrm=%s\n",userid,SQLCODE,sqlca.sqlerrm);
	sprintf_s(errmsg, sizeof errmsg,"userid=%s SOLCODE=%d sqlca.sqlerrm=%s",userid,SQLCODE,sqlca.sqlerrm);
	fprintf(fptr_err,"%s\n",errmsg);
	return SQLCODE;		
}
