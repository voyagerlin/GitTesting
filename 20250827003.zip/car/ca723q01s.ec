/**********************************************************************/
/*   program id   : ca723p01s.ec                                      */
/*   program name : �x�sB2C�O�渹�X�^�X�@�~                           */
/*   date written : 2005/05/19                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   author       : Jessie Leng                                       */
/*   files        : ply_relation        i                             */
/*   input        : dat/car/car723.txt                                */
/*   output       : rptftp/car723.txt                                 */
/*   Checked for ����100�~�M��                                        */
/**********************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "print.h"
#include "safeclib.h"
/*--------------------------------------------------------------------*/
$char   dbgn1[11],dend1[11],dbgn2[11],dend2[11];
$char   fclass[2];
char    sApHome[30];
$char   fname[21];
char    filename[50],filename1[50];
char    msgbuf[1000];
$char   DBName[05];
char    userid[11],outputf[21+1];

$char   ipolicy[21],iestimate[21],iassured[13],nassured[21];
$char   f1[7],f2[11],f3[11];
$long   mprem,mprem_o = 0;

$char   sIroute_main[21], sIroute_prop[3];
/*--------------------------------------------------------------------*/
main(argc,argv)
int   argc;
char  **argv;
{
int   rc;
   char option[2];
   char iofficer[15];
   
   batchinit();
   

   strcpy(DBName,	isNULLstr(argv[1]));
   strcpy(userid,	isNULLstr(argv[2]));
   strcpy(option, 	isNULLstr(argv[3]));
   strcpy(dbgn2, 	isNULLstr(argv[4]));
   strcpy(dend2, 	isNULLstr(argv[5]));
   strcpy(iofficer, isNULLstr(argv[6]));
   strcpy(sIroute_main, isNULLstr(argv[7]));
   strcpy(sIroute_prop, isNULLstr(argv[8]));
   strcpy(outputf,	isNULLstr(argv[9]));

   strcpy(dbgn1, cm_to_infdate(dbgn2));
   strcpy(dend1, cm_to_infdate(dend2));

	printf("option=[%s]\n",option);
	printf("dbgn1=[%s]\n",dbgn1);
	printf("dend1=[%s]\n",dend1);
	printf("iofficer=[%s]\n",iofficer);
	printf("sIroute_main=[%s]\n",sIroute_main);
	printf("sIroute_prop=[%s]\n",sIroute_prop);
	
   rc=car723_get_db();
   if (rc!=M_CM_OK)
      return rc;

	if(option[0] == '1')
	{
	   rc=car723_read_data();
	   if (rc!=M_CM_OK)
	      return rc;
	}
	else if(option[0] == '2')
	{
		rc = car723_renew_data_download(dbgn1,dend1,iofficer);
		if (rc!=M_CM_OK)
			return rc;
	}
	

   return rc;

}
/*--------------------------------------------------------------------*/
long car723_get_db()
{
int   rc;

   $whenever sqlerror goto errexit;

   rc = getApHome(sApHome);
   if (rc<0) {
      strcpy(msgbuf,"read Config file error!!-->getApHome\n");
      EWRITE(userid,rc,msgbuf);
      return rc;
   }

   strcpy(fname,"car723.txt");
   strcpy(filename," ");
   sprintf_s(filename, sizeof filename,"%s/dat/car/", sApHome);
   strcat(filename,fname);
   strcpy(filename1," ");
   sprintf_s(filename1, sizeof filename1,"%s/rptftp/", sApHome);
   strcat(filename1,fname);

   if (db_select(DBName) == FALSE) {
      EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
      return M_CM_DB_NOTOPEN;
   }
   return M_CM_OK;

errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}

long car723_renew_data_download(char *in_DPlyBegin_Begin,
								char *in_DPlyBegin_End,
								char *in_Iofficer)
{
	$whenever sqlerror goto errexit;
	int return_code;
	$char search_DPlyBegin_Begin[11],search_DPlyBegin_End[11];
	$char search_Iofficer[15];

	$char stmt[5000] = "";
	char stmt_filter[3000] = "";
	int stmt_filter_len;
	int stmt_len;
	char command_str[6000];
	
	$char sPlyfile[31], sInsfile[31];


	/*********** ���o�ѼƸ��  *****************/
	strcpy(search_DPlyBegin_Begin,in_DPlyBegin_Begin);
	strcpy(search_DPlyBegin_End,in_DPlyBegin_End);
	strcpy(search_Iofficer,in_Iofficer);
	
	/*********** �d�ߪ�SQL *******/
	stmt_filter_len = 0;
	stmt_len = 0;
	if (search_DPlyBegin_Begin[0] != '\0') 
		stmt_filter_len += sprintf_s(stmt_filter + stmt_filter_len, sizeof stmt_filter + stmt_filter_len," and (a.dply_begin >= '%s')\r\n ",search_DPlyBegin_Begin);
	if (search_DPlyBegin_End[0] != '\0') 
		stmt_filter_len += sprintf_s(stmt_filter + stmt_filter_len, sizeof stmt_filter + stmt_filter_len," and (a.dply_begin <= '%s')\r\n ",search_DPlyBegin_End);
	if (search_Iofficer[0] != '\0') 
		stmt_filter_len += sprintf_s(stmt_filter + stmt_filter_len, sizeof stmt_filter + stmt_filter_len," and (a.iofficer matches '%s')\r\n ",search_Iofficer);
	
	/* add by sylvia 100.07.19 */	
	stmt_filter_len += sprintf_s(stmt_filter + stmt_filter_len, sizeof stmt_filter + stmt_filter_len," and a.ipolicy[1,13] = b.ipolicy1 \r\n ");
	stmt_filter_len += sprintf_s(stmt_filter + stmt_filter_len, sizeof stmt_filter + stmt_filter_len," and a.ipolicy[14,20] = b.ipolicy2 \r\n ");
	stmt_filter_len += sprintf_s(stmt_filter + stmt_filter_len, sizeof stmt_filter + stmt_filter_len," and a.iroute = c.iroute \r\n ");
	stmt_filter_len += sprintf_s(stmt_filter + stmt_filter_len, sizeof stmt_filter + stmt_filter_len," and (c.iroute_main = '%s')\r\n ",sIroute_main);
	
	if (strcmp(trim(sIroute_main),"I812") == 0)
	   stmt_filter_len += sprintf_s(stmt_filter + stmt_filter_len, sizeof stmt_filter + stmt_filter_len," and (b.column_10 in ('05','06'))\r\n ");
	else
	   stmt_filter_len += sprintf_s(stmt_filter + stmt_filter_len, sizeof stmt_filter + stmt_filter_len," and (b.column_10 in ('%s'))\r\n ",sIroute_prop);
	
	
	/*�N���insert into temp table TempTable_RenewPly */
	stmt_len += sprintf_s(stmt + stmt_len, sizeof stmt + stmt_len,"select a.* from policy_302 a, cm_route_data b, cm_route c \r\n");
	if (stmt_filter[0] != '\0')
		stmt_len += sprintf_s(stmt + stmt_len, sizeof stmt + stmt_len," where %s ",stmt_filter + 4);
	stmt_len += sprintf_s(stmt + stmt_len, sizeof stmt + stmt_len," into temp TempTable_RenewPly;\r\n");

	/*�Nply_ins_type_302���unload�X�� */
	/* stmt_len += sprintf_s(stmt + stmt_len, sizeof stmt + stmt_len,
					"unload to %s/rptftp/ca_renew_ins.body delimiter '\t'\r\n"
					"select B.* from TempTable_RenewPly A,ply_ins_type_302 B, officer_broker C \r\n"
					"where A.ipolicy = B.ipolicy\r\n"
					"AND A.iofficer = C.iofficer AND C.icar_broker like 'YZC%%';\r\n",
					sApHome); */

   stmt_len += sprintf_s(stmt + stmt_len, sizeof stmt + stmt_len,
					"unload to %s/rptftp/ca_renew_ins.body delimiter '\t'\r\n"
					"select B.* from TempTable_RenewPly A,ply_ins_type_302 B, cm_route_data C, cm_route D \r\n"
					"where A.ipolicy = B.ipolicy \r\n"
					"  and A.ipolicy[1,13] = C.ipolicy1 \r\n"
					"  and A.ipolicy[14,20] = C.ipolicy2 \r\n"
					"  and A.iroute = D.iroute \r\n"
					"  and C.column_10 = '%s' and D.iroute_main = '%s';\r\n",
					sApHome, sIroute_prop, sIroute_main );
					
printf("stmt[%s]\n",stmt);					
	
	/*�Ntemp table TempTable_RenewPly unload�X�� */
	stmt_len += sprintf_s(stmt + stmt_len, sizeof stmt + stmt_len,
					"unload to %s/rptftp/ca_renew_ply.body delimiter '\t'\r\n"
					"select * from TempTable_RenewPly;\r\n",sApHome);
					 
	/* drop temp table */
	stmt_len += sprintf_s(stmt + stmt_len, sizeof stmt + stmt_len,"drop table TempTable_RenewPly;\r\n");

	/*�@�~������  */	
	sprintf_s(command_str, sizeof command_str,"dbaccess %s > %s/rptftp/%s 2>&1 << !\r\n"
  			"%s\r\n!",
  			"sysdb", 
  			sApHome,
  			"car723_log.txt", 
  			stmt); 
	printf("command_str=[%s]\r\n",command_str);
	return_code = system(command_str); 
    if (return_code != 0) {
		EWRITE(userid,return_code,"unload���~\r\n");
		return FALSE;    
    }	
    
    /*�@�X�ּ��D */
    sprintf_s(sPlyfile, sizeof sPlyfile,"ca_renew_ply_%s.txt",sIroute_main);
    sprintf_s(sInsfile, sizeof sInsfile,"ca_renew_ins_%s.txt",sIroute_main);
        
    /* sprintf_s(command_str, sizeof command_str,
    	"cd %s/rptftp/;"
    	"cat ../form/ca_renew_ply.head ca_renew_ply.body > ca_renew_ply.txt;"
    	"cat ../form/ca_renew_ins.head ca_renew_ins.body > ca_renew_ins.txt;"
    	"rm -f ca_renew_ply.body;"
    	"rm -f ca_renew_ins.body",
    	sApHome); */
   sprintf_s(command_str, sizeof command_str,
    	"cd %s/rptftp/;"
    	"cat ../form/ca_renew_ply.head ca_renew_ply.body > %s;"
    	"cat ../form/ca_renew_ins.head ca_renew_ins.body > %s;"
    	"rm -f ca_renew_ply.body;"
    	"rm -f ca_renew_ins.body",
    	sApHome,sPlyfile,sInsfile );
    	
	printf("command_str=[%s]\r\n",command_str);
	return_code = system(command_str); 
    if (return_code != 0) {
    	printf("cat file���~\r\n");
		EWRITE(userid,return_code,"cat file���~\r\n");
		return FALSE;    
    }
    
    /* �[�Jftp list */
	/* return_code=rptftpinsert(userid,"car723","ca_renew_ins.txt"); */
	return_code=rptftpinsert(userid,"car723",sInsfile);
	if (return_code!=0) {
		EWRITE(userid,return_code,"�g�Jrptftplist���~\r\n");
		return return_code;
	}
	
	/* return_code=rptftpinsert(userid,"car723","ca_renew_ply.txt"); */
	return_code=rptftpinsert(userid,"car723",sPlyfile);
	if (return_code!=0) {
		EWRITE(userid,return_code,"�g�Jrptftplist���~\r\n");
		return return_code;
	}
	return_code=rptftpinsert(userid,"car723","car723_log.txt");
	if (return_code!=0) {
		EWRITE(userid,return_code,"�g�Jrptftplist���~\r\n");
		return return_code;
   	}
	
	return SUCCESS;
	
errexit:
	printf("Error SQLCODE = %d\r\n",SQLCODE);
	sqlfatal();
	strcpy(msgbuf,sqlca.sqlerrm);
	return SQLCODE;  
}


/*--------------------------------------------------------------------*/
long car723_read_data()
{
int   flen,fg,rc;
FILE  *fp,*fp1;
char  *bp,scnt[5];
int   i,j,icnt;


   $whenever sqlerror goto errexit;

   flen=92;
   if ((fp=fopen(filename,"r"))==NULL) {
      sprintf_s(msgbuf, sizeof msgbuf,"%s �ɮ׶}�ҥ���\n",filename); 
      EWRITE(userid,FALSE,msgbuf);
      return FALSE;
   }
   if ((bp=malloc(flen))==NULL) {
      sprintf_s(msgbuf, sizeof msgbuf,"System malloc failed !");
      EWRITE(userid,FALSE,msgbuf);
      free(bp);
      return FALSE;
   }

   fp1=fopen(filename1,"w");

   for(i=0;(feof(fp)==0);i++) {
      memset(bp,0x00,flen);
      fgets(bp,flen,fp);
      if (bp[0]==0x00)
         break;
      null_alldata();
      memcpy(f1,bp+0,6);
      memcpy(iestimate,bp+6,14);
      memcpy(iassured,bp+40,12);
      memcpy(nassured,bp+52,20);
      memcpy(f2,bp+72,10);
      memcpy(f3,bp+82,10);
      if (iestimate[0]=='\0') continue;
      if (strncmp(iestimate," ",1)==0) continue;

      printf("iestimate[%s][%s]iassured[%s]\n",iestimate,f2,iassured);
      mprem = atoi(f2);
      if (f3[2]=='C')
         strcpy(fclass,"1");
      else
         strcpy(fclass,"2");
      /* �x�sB2C�u�b�`���q�X�� */
      $select ipolicy into $ipolicy
         from ply_relation
        where iofficer[1,8] = 'Y03613ZC'
          and dpolicy >= $dbgn1
          and dpolicy <= $dend1
          and fcard_class = $fclass
          and itmp_policy = $iestimate;
      if (SQLCODE==SQLNOTFOUND) {
         $select max(ipolicy) into $ipolicy
            from assured_vs_ply
           where iassured = $iassured
             and fcard_class = $fclass
             and ipolicy[1,3]='000';
         if (SQLCODE==SQLNOTFOUND)
            strcpy(ipolicy,"                    ");
         else {
            $select mdmg_prem+mlia_prem
               into $mprem_o
               from ply_relation
              where ipolicy = $ipolicy;
            if (mprem!=mprem_o)
               strcpy(ipolicy,"                    ");
         }
      }

      ipolicy[20]='\0';
      iestimate[14]='\0';
      iassured[12]='\0';
      nassured[20]='\0';
      f1[6]='\0';
      f2[10]='\0';
      f3[10]='\0';
      fprintf(fp1,"%s%s%s%s%s%s%s\n",f1,iestimate,ipolicy,iassured,
              nassured,f2,f3);

   }
        
   fclose(fp);
   fclose(fp1);

   rc=rptftpinsert(userid,"car723","car723.txt");
   if (rc!=0) {
       EWRITE(userid,rc,"�g�Jrptftplist���~");
       return rc;
   }

   sprintf_s(msgbuf, sizeof msgbuf,"�B�z����[%d]",i);
   EWRITE(userid,M_CM_OK,msgbuf);
   return M_CM_OK;
errexit:
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   sqlfatal();
   return SQLCODE;
}
/*--------------------------------------------------------------------*/
null_alldata()
{
   memset(iestimate,0x00,21);
   memset(iassured,0x00,13);
   memset(f1,0x00,7);
   memset(f2,0x00,41);
}
/*--------------------------------------------------------------------*/
/*********
rtrim_alldata()
{
   strcpy(iestimate,rtrim(iestimate));
   strcpy(f1,rtrim(f1));
   strcpy(f2,rtrim(f2));
}
**********/
/*---------------------------------------------------------end program*/
