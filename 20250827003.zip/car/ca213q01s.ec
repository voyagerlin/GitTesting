/*************************************************************/
/*                                                           */
/*   PROGRAM : car213_laser_policy_EW.ec  by Julia           */
/*   �s�w�T�������O�T�O�I��       02/16/2005                 */
/*************************************************************/

/*#define  APPROVE    "91.02.05�x�]�O��0910700944����֭�"
#define  APPROVE2   "92.09.08 92 �w�r��102����ֳ�"
*/
#define  APPROVE    ""
#define  APPROVE2   ""
#define  APPROVE3   "103.10.15�s�w�F�ʮ��W�]103�^�r��0270����Ƭd"
#define  TABSPACE  "            "
/* LINE_HEIGTH : �氪                                  */
/* INS_LINE    : �O���Ʀ��                          */
/* AMT_LINE    : �O�B��Ʀ��                          */
/* XPOS_MA     : �����I�ئW�� X ����                   */
/* XPOS_MB     : �����I�ئW�� X ����                   */
/* XPOS_APPROVE: �֭�帹     X ����                   */
#define  LINE_HEIGTH  5
#define  INS_LINE     8       /* �Q�O�I�H���   */
#define  AMT_LINE     3       /* �ӫO�d��       */
#define  PRE_LINE     1       /* �`�O�O���`�O�B */
#define  TOT_LINE     26      /* �O�歺���`��� */
#define  XPOS_MA      "62"
#define  XPOS_MB      "1"
#define  XPOS_APPROVE "144"
#define  XPOS_APPROVE2 "110"
#define  XPOS_APPROVE3 "147"

#include <stdio.h>
#include <string.h>
#include <time.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "commsgs.h"
$include carest.h;
#include "cmnmsgs.h"
#include "sqlfatal.h"
/*#include "glsmsgs.h"
#include "budmsgs.h"
#include "glscom.h"*/
#include "cmprint.h"
#include "ISvar_gls.h"
#include "funlist.h"
#include "safeclib.h"
$include decimal.h;
$include sqlca;
$include carmsgs.h;
/*$include othnew.h;
$include othmsgs.h;*/


$char DBName[5];
$char userid[7];
char sApHome[30];
char filename[201];
char fname[101];
FILE *fp;







long  car213_laser_policy_VW(reply,command,com_len)    
serverReply reply;
voidP command;
int com_len;
{
 long rtncode;
 long car213_laser_VW();             
 char option;

 cm_buf_init(command);
 cm_buf_get("%c",&option);
 
 rtncode=car213_laser_VW(reply);   /* peter 12.14 */
 return(rtncode);

}

/***************************************************************************/
long car213_laser_VW(reply)          /* peter 12.14 */
serverReply reply;
{
 /* standard defined host variables */
 $char printtype[3];
 int   rc,res,tmp_len;
 char  tempstr[121];
 char  OutFile[21],outputf[21],tmpOutFile[51];
 char  hostname[20],aphome[40];
 $char FormFile[21];
 $int  PgLine = 0;
 long  msg;
 int   i,page;
 /* standard defined host variables ends */
 
 /* variables in car213_laser_VW */
  char  bch_date[12],ech_date[12];
  char  ipolicyfrt[4],ipolicybak[11];
  char  iplyfrt_prv[4],iplybak_prv[11];
  char  tabstr[2];
  char  nyy[4],nmm[3],ndd[3];
  char  syy[4],smm[3],sdd[3],eyy[4],emm[3],edd[3];/*��O�I����*/
  char  option[3], fori[2];
 /* variables in car213_laser_VW ends*/
 
 /* db variables */
  $char ipolicy[21],ipolicy_prv[21];
  $char dbegin[11],dend[11];    
  $char iassured[11],nassured[121];
  $char aassured[91],abusiness_zip[6],abusiness[91];
  $char icar_flag[2],iparts[2];
  $char irate[11],nmodule[41];
  $long mcover1 = 0,mcover2 = 0,mdeduct = 0,mpremium;
  $char dpolicy[20],ientry[11];
  
  $char sdentry[11];
 /* db variables ends */

 /* variables for the format of form */
  int ypos;
  char mcover1_tmp[51],mcover2_tmp[51],mcover3_tmp[51],mdeduct_tmp[12];
  char sMcover1_tmp[51],sMcover2_tmp[51],sMcover3_tmp[51];
  char dpolicy_tmp[11];
  $int count_line;
  $char co_cname[101], co_ename[101], co_addr[101];
  char  addr[101],ins_name1[101], ins_name2[101];
  char car_parts[20];
 /* variables for the format of form ends */
 
  $char stmt1[1024],viins_type[7],ncontract[21],ncontent1[251],ncontent2[251];
  $char today[11],dpolicy_100[11],dp_yy[4],dp_mm[3],dp_dd[3];
  $char co_place[2],nchi_abv[21];
  
  $char f_1070601[2];

  cm_buf_get("%s",DBName);
  cm_buf_get("%s",printtype);
  cm_buf_get("%s",ipolicy);

printf("DBName=[%s],printtype[%s],ipolicy[%s],old_ipolicy[]",DBName,printtype,ipolicy);
  tabstr[0]=0x9;
  tabstr[1]=0x0;

  strncpy(fori, printtype+1, 1);
  fori[1]=0x0;

  printf("laser print %s\n", fori);

  $WHENEVER SQLERROR GOTO errexit;
  if (db_select(DBName) == False)
  {
   if(exitsub(reply,M_CM_DB_NOTOPEN) == True) 
    return M_CM_DB_NOTOPEN;
   else  
    return apiRC;
  }

  /*CHOICE */
  $WHENEVER SQLERROR GOTO optL_err;

  $SELECT kpgnum_line,nform_file INTO $PgLine,$FormFile
     FROM form
    WHERE ksys_grp="CA" AND kpgmid = 213 AND iform_tp = "VW";     /* peter 12.14 */
  if (SQLCODE==SQLNOTFOUND)
  {
    printf("FormFile not found in Form!!\n");
    goto optL_err;
  }
  strcpy(FormFile,rtrim(FormFile));
  strcpy(outputf, getFileName());
  sprintf_s(OutFile, sizeof OutFile,"%s.tx",outputf);
  rgu_init_report(FormFile,OutFile);
  msg = M_CM_OK;


  
  $SELECT a.dply_begin,a.dply_end,a.iassured,a.nassured,a.aassured,a.abusiness,
  	   	     a.nmodule,a.icar_flag,a.iparts,a.mcover1,a.mcover2,a.mdeduct,
  	   	     a.dpolicy,a.ipolicy_prv,
  	   	     case when a.dpolicy >= '06/01/2018' then 'Y' else 'N' end
                INTO $dbegin,$dend,$iassured,$nassured,$aassured,$abusiness,
                     $nmodule,$icar_flag,$iparts,$mcover1,$mcover2,$mdeduct,
                     $dpolicy,$ipolicy_prv,$f_1070601
                FROM ca_ply_ext a
               WHERE a.ipolicy = $ipolicy;
               

 printf("laser print 1-2\n");

 if (SQLCODE == SQLNOTFOUND)
 {
   if(exitsub(reply,M_CA_NPOLICY) == True)
     return M_CA_NPOLICY;
   else
     return apiRC;
 }

 sprintf_s(stmt1, sizeof stmt1,"SELECT max(ncontract ),a.iins_type "
                " FROM  ca_terms a "
               " WHERE a.iins_type = '58' "
                "  AND  deffect <= '%s' "
                "  AND  dcreate <= '%s' "
                " GROUP BY a.iins_type "
                " ORDER BY 1 DESC ",dbegin,dpolicy);
 $PREPARE term FROM $stmt1;
 printf("stmt1[%s]\n",stmt1);
 $DECLARE term_ncon CURSOR FOR term;
 $OPEN term_ncon;
 $FETCH term_ncon INTO $ncontract,$viins_type;
 $CLOSE term_ncon;
 $FREE  term_ncon;
 
 printf("ncontract[%s]\n",ncontract);
 
 if (SQLCODE == SQLNOTFOUND)
 {
   if(exitsub(reply,M_CA_NPOLICY) == True)
     return M_CA_NPOLICY;
   else
     return apiRC;
 }
 
 $SELECT ncontent1,ncontent2
    INTO $ncontent1,$ncontent2
    FROM ca_terms
   WHERE ncontract = $ncontract
    AND  iins_type = $viins_type;
 
 strcpy(ncontent1,trim(ncontent1));
 strcpy(ncontent2,trim(ncontent2));
 printf("\n---ncontent1[%s]\n",ncontent1);
 printf("\n---ncontent2[%s]\n",ncontent2);
 
 
 printf("laser print 1-3\n");
 strncpy(ipolicyfrt,ipolicy,3);
 ipolicyfrt[3]='\0';
 strcpy(ipolicybak,ipolicy+3);
 ipolicybak[10]='\0';
 
 /* Process previous ipolicy */
    if (strlen(ipolicy_prv) > 0) 
    {
    	strncpy(iplyfrt_prv,ipolicy_prv,3);
    	iplyfrt_prv[3]='\0';
    	strcpy(iplybak_prv,ipolicy_prv+3);
    	iplybak_prv[10]='\0';
    } else {
    	strcpy(iplyfrt_prv,"");
    	strcpy(iplybak_prv,"");
    }
 /* Process previous ipolicy ends */
 

 /*�ͮİ_���������*/
 strcpy(bch_date,cm_from_infdate_100(dbegin));
 cm_split_ymd_100(bch_date,syy,smm,sdd);
 strcpy(ech_date,cm_from_infdate_100(dend));
 cm_split_ymd_100(ech_date,eyy,emm,edd);
 
 
     /* insert */
	strcpy(co_cname, laser_get_cname());
	strcpy(co_ename, laser_get_ename());
	strcpy(co_addr , laser_get_addr());
	if(strncmp(f_1070601,"Y",1) == 0)
		strcpy(ins_name1,"�s�w�F�ʮ��W�����T�������O�T�O�ΫO�I");
	else 
		strcpy(ins_name1,"�s�w�F�ʮ��W�����O�T�����d���O�I");
	strcpy(ins_name2, ins_name1);
	strcat(ins_name1, "��");
	strcat(ins_name2, "����");

   /* �O�渹�X */
   rgu_put_body_string(1,ins_name1,1);
   rgu_put_body_string(1,ipolicy,1);
   rgu_put_body_string(1,ncontent1,2);
   rgu_put_body_string(1,ncontent2,2);
   rgu_put_body_string(1," ",2);
   rgu_put_body_string(1,co_cname,1);
   rgu_put_body_string(1,co_ename,1);
   rgu_put_body_string(1,co_addr,1);

   switch(fori[0])
   {
     case '1':
               rgu_put_body_string(1,"����",1);
               rgu_put_body_string(1,XPOS_MA,1);
               rgu_put_body_string(1,ins_name1,1);
               rgu_put_body_string(1,"0",2);
               rgu_put_body_string(1,"0",2);
               rgu_put_body_string(1,"0",2);
               rgu_put_body_string(1,"����",1);
               rgu_put_body_string(1,XPOS_MB,1);
               rgu_put_body_string(1,ins_name2,1);
               rgu_put_body_string(1,"0",2);
               rgu_put_body_string(1,"0",2);
               rgu_put_body_string(1,"0",2);
               break;
     case '2':
               rgu_put_body_string(1,"�ƥ�",1);
               rgu_put_body_string(1,XPOS_MA,1);
               rgu_put_body_string(1,ins_name1,1);
               rgu_put_body_string(1,"0",1);
               rgu_put_body_string(1,"0",1);
               rgu_put_body_string(1,"0",1);
               rgu_put_body_string(1,"�ƥ�",1);
               rgu_put_body_string(1,XPOS_MB,1);
               rgu_put_body_string(1,ins_name2,1);
               rgu_put_body_string(1,"0",1);
               rgu_put_body_string(1,"0",1);
               rgu_put_body_string(1,"0",1);
               break;
     case '3':
               rgu_put_body_string(1,"�չ�",1);
               rgu_put_body_string(1,XPOS_MA,1);
               rgu_put_body_string(1,ins_name1,1);
               rgu_put_body_string(1,"0",1);
               rgu_put_body_string(1,"0",1);
               rgu_put_body_string(1,"0",1);
               rgu_put_body_string(1,"�չ�",1);
               rgu_put_body_string(1,XPOS_MB,1);
               rgu_put_body_string(1,ins_name2,1);
               rgu_put_body_string(1,"0",1);
               rgu_put_body_string(1,"0",1);
               rgu_put_body_string(1,"0",1);
               break;
   }

   rgu_put_body(1);

   /* �O�I�渹���� */
     rgu_put_body_string(2,ipolicy,1);
     rgu_put_body_string(2,ipolicyfrt,1);
     rgu_put_body_string(2,ipolicybak,1);

     rgu_put_body_string(2,iplyfrt_prv,1);
     rgu_put_body_string(2,iplybak_prv,1);
     /*rgu_put_body_string(2);*/
   /* �O�I�渹���� */


   /* �Q�O�I�H��Ƴ��� */
     rgu_put_body_string(2,nassured,1);
     rgu_put_body_string(2,iassured,1);
     rgu_put_body_string(2,aassured,1);
     rgu_put_body_string(2,abusiness,1);
     rgu_put_body_string(2,nmodule,1);
     
     /* �զ��O�T�s����� */
      strcpy(car_parts,NULL);
      if (strcmp(icar_flag,"1") == 0)
      	strcpy(car_parts,"�s��");
      else
      	strcpy(car_parts,"���j��");
      	
      if (strcmp(iparts,"1") == 0)
        strcat(car_parts,"����");
      else
      	strcat(car_parts,"�ʤO�ǰʨt��");
      	
      rgu_put_body_string(2,car_parts,1);
     /* �զ��O�T�s����� ends */
     
     rgu_put_body_string(2,"�x�W���q",1);   /* �a�ϭ��� */

     /* �O�I���� */
       rgu_put_body_string(2,syy,1);
       rgu_put_body_string(2,smm,1);
       rgu_put_body_string(2,sdd,1);
       rgu_put_body_string(2,"12",1);
       rgu_put_body_string(2,eyy,1);
       rgu_put_body_string(2,emm,1);
       rgu_put_body_string(2,edd,1);
       rgu_put_body_string(2,"12",1);
     /* �O�I���� */
   /* �Q�O�I�H��Ƴ��� */

   /* �ӫO�d��W��u */
     ypos = 67 + (INS_LINE * LINE_HEIGTH);
     sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
     rgu_put_body_string(2,tempstr,1);
     rgu_put_body_string(2,tempstr,1);

   /* �ӫO�d����Y */
     ypos = ypos + 1;
     sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
     rgu_put_body_string(2,tempstr,1);
     rgu_put_body_string(2,tempstr,1);
     rgu_put_body_string(2,tempstr,1);

   /* �ӫO�d��U��u */
     ypos = ypos + LINE_HEIGTH;
     sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
     rgu_put_body_string(2,tempstr,1);
     rgu_put_body_string(2,tempstr,1);

   /* �ӫO�d�򤺮e */
     ypos = ypos + 2;
     sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
     rgu_put_body_string(2,tempstr,1);
     
     strcpy(iassured,trim(iassured));
     printf("iassured[%s]\n",iassured);
     
     if(strcmp(iassured,"54657518") == 0)	/*** MAZDA ***/
     {
     	strcpy(sMcover1_tmp,"�C�@�ƬG�̰����v���B");
     	strcpy(sMcover2_tmp,"�C�@�O�T�Ъ����̰����v���B");
     	strcpy(sMcover3_tmp,"�O�I�������̰����v���B");
     	
     	strcpy(mcover1_tmp,"�Q�O�T�T���o�;���G�ٷ��ɤ���ڲ{������");
     	strcpy(mcover2_tmp,"�Q�O�T�T�������m����");
     	strcpy(mcover3_tmp,"�L");
     	
     	rgu_put_body_string(2, sMcover1_tmp, 1);
     	rgu_put_body_string(2, mcover1_tmp, 2);
     	rgu_put_body_string(2, "�L�ۭt�B", 2);
     	rgu_put_body_string(2, sMcover2_tmp, 1);
     	rgu_put_body_string(2, mcover2_tmp, 2);
     	rgu_put_body_string(2, " ", 2);
     	rgu_put_body_string(2, sMcover3_tmp, 1);
     	rgu_put_body_string(2, mcover3_tmp, 2);
     	rgu_put_body_string(2, " ", 2);
     	
     }
     else
     {
     	if(strncmp(f_1070601,"Y",1) == 0)
     	{
     		strcpy(sMcover1_tmp,"�O�T�Ъ����̰����I���B");
     		strcpy(sMcover2_tmp," ");
    	}
    	else
    	{
     		strcpy(sMcover1_tmp,"�C�@�ƬG�̰����v���B");
     		strcpy(sMcover2_tmp,"�O�I�������̰����v���B");
    	}
     	
     	printf("mcover1[%d],mcover2[%d],mdeduct[%d]\n",mcover1,mcover2,mdeduct);
		
		if(mcover1 ==0)
		{
			strcpy(mcover1_tmp,"�Q�O�T�T�������m����");
			strcpy(mcover2_tmp,"�L");	
		}
		else
		{
			rfmtlong(mcover1,"<<,<<<,<<<,<<<",mcover1_tmp);
			printf(" mcover1 = %s \n", mcover1_tmp);
			rfmtlong(mcover2,"<<,<<<,<<<,<<<",mcover2_tmp);
			printf(" mcover2 = %s \n", mcover2_tmp);	
		}
		
		trim(mcover1_tmp);
		trim(mcover2_tmp);
		rfmtlong(mdeduct,"<<,<<<,<<<,<<<",mdeduct_tmp);
		printf(" mdeduct_tmp = %s \n", mdeduct_tmp);
      	trim(mdeduct_tmp);
     
     rgu_put_body_string(2, sMcover1_tmp, 1);
     
     if(mcover1 == 0)
     	rgu_put_body_string(2, mcover1_tmp, 2);
     else
     	rgu_put_body_string(2, ascii_judge(mcover1_tmp, "NT"), 2);
     
     /*rgu_put_body_string(2, "�Ԩ��O�����",2);*/
     
     /* �M�w�ۭt�B */
       trim(mdeduct_tmp);
       
	printf("what is self-paid amt?[%s]\n",mdeduct_tmp);
       if (mdeduct == 0)
       {
       		rgu_put_body_string(2,"�L�ۭt�B",2);
       	} else {
       		rgu_put_body_string(2, ascii_judge(mdeduct_tmp, "NT"), 2);
       	}
     /* ends */
    
     /*rgu_put_body_string(2,"�Ԩ��O�����",2);Modified by Julia*/
     /*rgu_put_body_string(2,"", 2);
     rgu_put_body_string(2,"", 2);*/
   
     /*rgu_put_body_string(2,"�Ԩ��O�����", 2);*/
     if(strncmp(f_1070601,"Y",1) == 0)
     {
     	rgu_put_body_string(2, " ", 2);
	    rgu_put_body_string(2, " ", 2);
	 }
	 else
	 {
		 rgu_put_body_string(2, sMcover2_tmp, 1);
	     if(mcover1 == 0)
	     rgu_put_body_string(2, mcover2_tmp, 2);
	     else
	     rgu_put_body_string(2, ascii_judge(mcover2_tmp, "NT"), 2);
     }     
     
     rgu_put_body_string(2," ", 2);
     
     rgu_put_body_string(2," ", 2);
     rgu_put_body_string(2," ", 2);
     rgu_put_body_string(2," ", 2);
     
     }

   /* �ӫO�d���a�u */
     ypos = 67 + (INS_LINE * LINE_HEIGTH);
     sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
     rgu_put_body_string(2,tempstr,1);

     ypos = 67 + (INS_LINE * LINE_HEIGTH) + 1 + 5 + 2 + (AMT_LINE * LINE_HEIGTH);
     sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
     rgu_put_body_string(2,tempstr,1);

   /* �`�O�I�O�W��u  */
     ypos = 67 + (INS_LINE * LINE_HEIGTH) + 1 + 5 + 2 + (AMT_LINE * LINE_HEIGTH);
     sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
     rgu_put_body_string(2,tempstr,1);
     rgu_put_body_string(2,tempstr,1);

   /* �`�O�I�O���e */
     ypos = ypos + 1;
     sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
     rgu_put_body_string(2,tempstr,1);
     rgu_put_body_string(2," ",1);

   /* �`�O�I�O�U��u */
     ypos = ypos + LINE_HEIGTH;
     sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
     rgu_put_body_string(2,tempstr,1);
     rgu_put_body_string(2,tempstr,1);

     rgu_put_body(2);

   /* ���[���� */
     ypos = ypos + 1;
     sprintf_s(tempstr, sizeof tempstr,"%d",ypos);
     rgu_put_body_string(3,tempstr,1);
   
     ypos = ypos + LINE_HEIGTH;
     sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
     rgu_put_body_string(3,tempstr,1);

     rgu_put_body(3);
	 
	 if(strncmp(f_1070601,"Y",1) == 0)   
	 	rgu_put_body_string(4," ",1);
	 else
     	rgu_put_body_string(4,"911           ���ƥD�q���~���[����",1);
    
     rgu_put_body(4);
     
     ypos = ypos + LINE_HEIGTH;
     sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
     printf("ypos[%d]\n\n",ypos);
     rgu_put_body_string(5,tempstr,1);
     rgu_put_body_string(5,tempstr,1);
     
     rgu_put_body(5);
   
   /* �Ƶ� */
     ypos = ypos + 1;
     sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
     rgu_put_body_string(41,tempstr,1);
     rgu_put_body_string(41,tempstr,1);
     ypos = ypos + 1;
     sprintf_s(tempstr, sizeof tempstr,"%d", ypos);
     rgu_put_body_string(41,tempstr,1);
     rgu_put_body(41);
     
     rgu_put_body(42);
     rgu_put_body_string(43," ",1);
     rgu_put_body(43);
     rgu_put_body(44);
     rgu_put_body(45);
     
     /*strcpy(today,cm_today());*/
     strcpy(dpolicy_100,cm_from_infdate_100(dpolicy));
     cm_split_ymd_100(dpolicy_100,dp_yy,dp_mm,dp_dd);
     
     strncpy(co_place,ipolicy+2,1);
  	   co_place[1]=0x0;
       
	 $select nchi_abv
		into $nchi_abv
		from branch
	   where ibranch_abbr = $co_place;
       
  	 if(SQLCODE != 0) strcpy(nchi_abv, " ");
  	   
     rgu_put_body_string(9,dp_yy,1);
     rgu_put_body_string(9,dp_mm,1);
     rgu_put_body_string(9,dp_dd,1);
     rgu_put_body_string(9,nchi_abv,1);
   	 rgu_put_body(9);
     
printf("dpolicy = [%s]",dpolicy);

   /* Bottom */
     /*laser_print_bottom(ipolicy, dpolicy);*/

  /*********************�H�U�q�X�t�Τ��**************
  printf("show dentry %s\n",sdentry);
  printf("nyy=%s\n",nyy);
  printf("nmm=%s\n",nmm);
  printf("ndd=%s\n",ndd);*/

  /***************** �N�t�Τ����i dply_edr(ñ���)��줤,fprint�]��'Y'  peter 12.14 *****/

  /*laser_update_dply_edr(ipolicy, "", fori[0]);   /* ñ���ΦC�L���O */

  printf("FLAG1,put_body,ok\n");
  
  /* print bottom */
    rgu_put_body(91);
  /* print bottom ends */

  rgu_finish_report();

  printf("FLAG1\n");


    if (msg == M_CM_OK)
    {
        printf("FLAG2\n");
        res = getApHome(aphome);
        if (res<0)
        {
            printf("In sigalrmcatcher func==>read config file error!!\n");
            return res;
        }
        printf("aphome[%s]\n",aphome);

        gethostname(hostname,sizeof(hostname));
        sprintf_s(tmpOutFile, sizeof tmpOutFile, "%s/reportfile/%s", aphome,OutFile);
    }

    printf("FLAG3\n");

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l %s %s %d", msg, hostname, tmpOutFile, PgLine);

printf("ReplyBuf by j = [%s]",ReplyBuf);

    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
    {
        return apiRC;
    }
    printf("show sysdatetime %s\n",cm_get_sysd2());
    printf("FLAG4\n");
    return M_CM_OK;

optL_err:
    printf("sqlerrcode=%d, sqlerrmsg=%s sqlca.sqlerrd[1]=%d\n",SQLCODE,sqlca.sqlerrm,sqlca.sqlerrd[1]);
    return SQLCODE;

 errexit:
  if(exitsub(reply,SQLCODE) == True) 
   return SQLCODE;
  else  
   return apiRC;
}
/*************************************************************************/



long car213_print_policy(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
    long rtncode;
    long car213_print();
    char option;

    cm_buf_init(command);
    cm_buf_get("%c",&option);
 
    rtncode=car213_print(reply);
    return(rtncode);
}

/**************************************************************************/
long car213_print(reply)
serverReply reply;
{
    $char todaydate[11],dToday[11],nyy[4],nmm[3],ndd[3];
    $char sWhere0[256];
    $char stmt[2048];
    char msgbuf[2048];
    $int res;
    int return_code;
    int	tmp_len;
    long t;
    $char ireceipt[21];
    
    $char begin[11],begin_y[4],begin_m[3],begin_d[3];
    $char end[11],end_y[4],end_m[3],end_d[3];
    $char cltipolicy[21];
    $char n_assured[121],n_represent[121],i_assured[11],a_assured[91],n_module[41],icarflag[2],i_parts[2];
    $char dplybegin[21],dplyend[21],dpolicy[11];
    $int  m_cover1 = 0,m_cover2 = 0,m_deduct = 0;
    $char stmt_term[1024],viins_type[7],ncontract[21],ncontent1[251],ncontent2[251];
     
    time_t now;




    cm_buf_get("%s %s",DBName,cltipolicy);

    $WHENEVER SQLERROR GOTO errexit;


    if (db_select(DBName) == False)
    {
        if (exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
        else
            return apiRC;
    }



    return_code = getApHome(sApHome);
    if (return_code < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        return return_code;
    }


    t = cm_today();
    strcpy(todaydate,cm_edate_str(t));
    strcpy(dToday,cm_from_infdate_100(todaydate));
    cm_split_ymd_100(dToday,nyy,nmm,ndd);
    
    time(&now);
    strcpy(filename," ");
    sprintf_s(fname, sizeof fname,"Ext%s%s%s%ld.txt",nyy,nmm,ndd,now);
    sprintf_s(filename, sizeof filename,"%s/rptftp/%s",sApHome,fname);
    printf("�T�������O�T�����d���O�I�n�O��[%s]\n",filename);
    fp=fopen(filename,"w");
    sprintf_s(stmt, sizeof stmt,"select nassured   ,nrepresent ,iassured  ,aassured,"
                 "       nmodule    ,icar_flag  ,iparts,"
                 "       dply_begin ,dply_end   ,"
                 "       mcover1    ,mcover2    ,mdeduct ,dpolicy"
                 "  from ca_ply_ext "
                 " where ipolicy = '%s' "
                 ,cltipolicy);


    /*�L�X�W����SQL���G*/
    printf("%s\n",stmt);

    $PREPARE ca_policy FROM $stmt;
    $DECLARE policy_cur CURSOR FOR ca_policy;
    $OPEN policy_cur;
    /*qcnt = 0;*/
    
    
    $BEGIN WORK;
    
    
    for(;;)
    {
        $FETCH policy_cur INTO $n_assured,$n_represent,$i_assured,$a_assured,
                               $n_module,$icarflag,
                               $i_parts,$dplybegin,$dplyend,
                               $m_cover1,$m_cover2,$m_deduct,$dpolicy;

        if (SQLCODE != 0) break;
        
        strcpy(dpolicy,trim(dpolicy));
        if(dpolicy[0] == '')
        {
			sprintf_s(stmt_term, sizeof stmt_term,"SELECT max(ncontract),a.iins_type "
			                  "  FROM ca_terms a"
			                  " WHERE a.iins_type = '58' "
			                  "   AND  deffect <= '%s' "
			                  "   AND  dcreate <= today "
			                  " GROUP BY a.iins_type "
			                  " ORDER BY 1 DESC ",dplybegin);	
        }
        else
        {
	        sprintf_s(stmt_term, sizeof stmt_term,"SELECT max(ncontract),a.iins_type "
	                          "  FROM ca_terms a "
	                          " WHERE a.iins_type = '58' "
	                          "   AND  deffect <= '%s' "
	                          "   AND  dcreate <= '%s' "
	                          " GROUP BY a.iins_type "
	                          " ORDER BY 1 DESC ",dplybegin,dpolicy);
        }
		$PREPARE term_1 FROM $stmt_term;
		printf("stmt_term[%s]\n",stmt_term);
		$DECLARE term_1_ncon CURSOR FOR term_1;
		$OPEN term_1_ncon;
		$FETCH term_1_ncon INTO $ncontract,$viins_type;
		$CLOSE term_1_ncon;
		$FREE  term_1_ncon;
		
		printf("ncontract[%s]\n",ncontract);
		
		if (SQLCODE == SQLNOTFOUND)
		{
		if(exitsub(reply,M_CA_NPOLICY) == True)
		 return M_CA_NPOLICY;
		else
		 return apiRC;
		}
		
		$SELECT ncontent1,ncontent2
		   INTO $ncontent1,$ncontent2
		   FROM ca_terms
		  WHERE ncontract = $ncontract
		    AND iins_type = $viins_type;
		
		strcpy(ncontent1,trim(ncontent1));
		strcpy(ncontent2,trim(ncontent2));
		printf("\n---ncontent1[%s]\n",ncontent1);
		printf("\n---ncontent2[%s]\n",ncontent2);

        /* ��q��Ʈw���쪺ply_begin�q�ഫ���������begin*/
        strcpy(begin,cm_from_infdate_100(dplybegin));
        cm_split_ymd_100(begin,begin_y,begin_m,begin_d);
        /*��begin���ɶ������~���*/

        /* ��q��Ʈw���쪺ply_end�q�ഫ���������end*/
        strcpy(end,cm_from_infdate_100(dplyend));
        cm_split_ymd_100(end,end_y,end_m,end_d);
        /*��end���ɶ������~���*/

	printf("======================================================================\n");
        printf("%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%d\n%d\n%d\n%s\n%s\n",
                n_assured,n_represent,i_assured,a_assured,n_module,icarflag,i_parts,
                begin_y,begin_m,begin_d,end_y,end_m,end_d,m_cover1,m_cover2,m_deduct,ncontent1,ncontent2);
	printf("======================================================================\n");
	/*
        fprintf(fp,"%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n%s\n",
                   n_assured,n_represent,i_assured,a_assured,n_module,icarflag,i_parts,
                   begin_y,begin_m,begin_d,end_y,end_m,end_d,m_cover1,m_cover2,m_deduct);*/
        fprintf(fp,"%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%d\t%d\t%d\t%s\t%s\n",
                   n_assured,n_represent,i_assured,a_assured,n_module,icarflag,i_parts,
                   begin_y,begin_m,begin_d,end_y,end_m,end_d,m_cover1,m_cover2,m_deduct,ncontent1,ncontent2);
   }

    $CLOSE policy_cur;
    $FREE  policy_cur;
    fclose(fp);
    $COMMIT WORK;
    

    cm_buf_init(ReplyBuf);
    cm_buf_put("%l",M_CM_OK);
    cm_buf_put("%s",fname);

    tmp_len = cm_buf_len(ReplyBuf);

    if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
        return apiRC;
    else
        return api_OKComplete;


errexit:

    $ROLLBACK WORK;
    fclose(fp);
    sqlfatal();
    return exitsub(reply,SQLCODE) ? SQLCODE : apiRC;
}