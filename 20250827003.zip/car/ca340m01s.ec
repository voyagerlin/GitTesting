/*********************************************************/
/*                                                       */
/*  PROGRAM: ca340m01s.ec                                */
/*                                                       */
/*********************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmnmsgs.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "safeclib.h"
#include <string.h>
#include <stdlib.h>
$include sqlca;

 $char DBName[5];
 $char stmt[10000];
 $char userid[11];
 char option;
 
long car340(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
     long rtncode;
     long car340_insert();

     cm_buf_init(command);
     cm_buf_get("%c",&option);
     switch(option)
     {
          case 'A':
          case 'U':
          case 'D':
               rtncode=car340_AUD(reply);
               break;
          case 'M':
               rtncode=car340_multiple_query(reply);
               break;
          case 'W':
               rtncode=car340_get_5_work_day(reply);
               break;
          case 'P':
	      rtncode=car340_get_ilast_ply(reply);
	      break;
	  case 'E':
	      rtncode=car340_get_iestimate(reply);
	      break;
          default :
               if(exitsub(reply,M_CM_WRONG_OPTION) == True)
                   return M_CM_WRONG_OPTION;
               return apiRC;
     }
     return(rtncode);
}

long car340_AUD(reply)
serverReply reply;
{
     $char iestimate[21], ilast_ply[21], icard1[21], nassured[121], iassured[21], itag[CA_TAG_NUM], iengine[CA_ENGINE_NUM], iofficer[11];
     $char dply1_begin[11], dply1_end[11], dply2_begin[11], dply2_end[11], ncar_note[61], nass_note[61], nins_note[61];
     $char nseal_note[61], nremark[256], iexaminer[11], dupdate[31], curr_dupdate[31];
     $long  iserial;
     int   tmp_len;

     cm_buf_get("%s %s %l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s",
               DBName, userid, &iserial, iestimate, ilast_ply, icard1, nassured, iassured, itag, iengine, iofficer, 
               dply1_begin, dply1_end, dply2_begin, dply2_end, ncar_note, nass_note, nins_note, nseal_note, nremark, iexaminer, dupdate); 

     printf(" ****************************** \n");

     $WHENEVER SQLERROR GOTO errexit;

     if (db_select(DBName) == False)
     {
         if(exitsub(reply,M_CM_DB_NOTOPEN) == True)
            return M_CM_DB_NOTOPEN;
         else
            return apiRC;
     }

           
               
     $BEGIN WORK;

     if( option == 'A')
         $INSERT INTO ca_note (iestimate, ilast_ply, icard1, nassured, 
                               iassured, itag, iengine, iofficer, dply1_begin, dply1_end, 
                               dply2_begin, dply2_end, fstatus1, fstatus2, ncar_note, 
                               nass_note, nins_note, nseal_note, nremark, iexaminer, 
                               icreate, dcreate, iupdate, dupdate)
                       values ($iestimate, $ilast_ply, $icard1, $nassured, $iassured, $itag, $iengine, $iofficer, 
                               $dply1_begin, $dply1_end, $dply2_begin, $dply2_end, '0', '0', $ncar_note, 
                               $nass_note, $nins_note, $nseal_note, $nremark, $iexaminer,
                               $userid, current year to second, ' ', current year to second); 
     else if( option == 'U' || option == 'D')
     {
         $select dupdate into $curr_dupdate from ca_note where iserial = $iserial;
         strcpy( curr_dupdate, rtrim( curr_dupdate));
         printf("[%s]\n", dupdate);
         printf("[%s]\n", curr_dupdate);
         if( strcmp( dupdate, curr_dupdate) != 0)
         {
             $ROLLBACK WORK;
             if(exitsub(reply,M_CM_NOT_EQUAL) == True)
                return M_CM_NOT_EQUAL;
             else
                return apiRC;
         }
         if( option == 'U')
             $UPDATE ca_note set (iestimate, ilast_ply, icard1, nassured, 
                                  iassured, itag, iengine, iofficer, dply1_begin, dply1_end, 
                                  dply2_begin, dply2_end, ncar_note, 
                                  nass_note, nins_note, nseal_note, nremark, iexaminer, 
                                  iupdate, dupdate)
                               = ($iestimate, $ilast_ply, $icard1, $nassured, $iassured, $itag, $iengine, $iofficer, 
                                  $dply1_begin, $dply1_end, $dply2_begin, $dply2_end, $ncar_note, 
                                  $nass_note, $nins_note, $nseal_note, $nremark, $iexaminer,
                                  $userid, current year to second)
                  WHERE iserial = $iserial;
         else if( option == 'D')
             $UPDATE ca_note set fstatus = 'D', 
                                 iupdate = $userid, 
                                 dupdate = current year to second 
                           where iserial = $iserial;
     }

     $COMMIT WORK;

     cm_buf_init(ReplyBuf);
     cm_buf_put("%l ",M_CM_OK);
     tmp_len = cm_buf_len(ReplyBuf);
     if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
         return apiRC;
     else
         return api_OKComplete;

errexit:
     printf("into errexit SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
     if(exitsub(reply,SQLCODE) == True)
     {
         $ROLLBACK WORK;
         return SQLCODE;
     }
     else
         return apiRC;
}
long car340_get_5_work_day(reply)
serverReply reply;
{
 $int  iTmp, jTmp, date5;
 $char sdate[11];
 int   repbuf_len=0;

 cm_buf_get("%s ",DBName);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
       return M_CM_DB_NOTOPEN;
   return apiRC;
 }

 /* ��X�e5�u�@�� */
 jTmp = date5 = 0;
 for(iTmp=1;jTmp<=5;iTmp++)
 {
     $select 1 
        from ca_holiday
       where (today - $iTmp) between holiday_bgn and holiday_end;
     if( SQLCODE == SQLNOTFOUND) jTmp++;
     printf("iTmp[%d,jTmp[%d]\n", iTmp, jTmp);
     if( jTmp == 5 && date5 == 0) {date5 = iTmp;break;}
 }
 $select first 1 to_char(today - $iTmp) into $sdate from ca_holiday;
 cm_buf_init(ReplyBuf);
 cm_buf_put("%d %s", M_CM_OK, sdate);
 repbuf_len = cm_buf_len(ReplyBuf);
 if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
   return apiRC;
 return api_OKComplete;

 errexit:
  printf("into errexit SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  if ( exitsub(reply,SQLCODE) == True )
   return SQLCODE;
  return apiRC;
}

long car340_multiple_query(reply)
serverReply reply;
{
 char  tmpbuf[4000];
 $char qcur_buf[1600], stmp[201];
 int   count=0,repbuf_len=0,tmp_len=0,replycnt=0;
 $long iserial;

 $char iestimate[21], ilast_ply[21], icard1[21], nassured[121], iassured[21], itag[CA_TAG_NUM], iengine[CA_ENGINE_NUM], iofficer[11];
 $char dply1_begin[11], dply1_end[11], dply2_begin[11], dply2_end[11], ncar_note[61], nass_note[61], nins_note[61];
 $char nseal_note[61], nremark[256], iexaminer[11], dcreateBgn[11], dcreateEnd[11], fstatus[11], fstatus1[11], fstatus2[11];
 $char icreate[11], iupdate[11], dcreate[31], dupdate[31], ipolicy1[21], ipolicy2[21];

 cm_buf_get("%s %s %s %s %s %s %s ",DBName, iexaminer, iassured, itag, dcreateBgn, dcreateEnd, fstatus);

 $WHENEVER SQLERROR GOTO errexit;

 if (db_select(DBName) == False)
 {
   if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
       return M_CM_DB_NOTOPEN;
   return apiRC;
 }

 sprintf_s(qcur_buf,sizeof qcur_buf,"SELECT iserial, iestimate, ilast_ply, icard1, nassured,"
                  "       iassured, itag, iengine, iofficer, "
                  "       to_char(dply1_begin,'%%Y')::integer - 1911 || to_char(dply1_begin,'%%m%%d'), "
                  "       to_char(dply1_end,'%%Y')::integer - 1911 || to_char(dply1_end,'%%m%%d'), "
                  "       to_char(dply2_begin,'%%Y')::integer - 1911 || to_char(dply2_begin,'%%m%%d'), "
                  "       to_char(dply2_end,'%%Y')::integer - 1911 || to_char(dply2_end,'%%m%%d'), "
                  "       case when dply1_begin is null then ' ' when fstatus1 = '1' then '�w�X��' else '���X��' end, ipolicy1,"
                  "       case when dply2_begin is null then ' ' when fstatus2 = '1' then '�w�X��' else '���X��' end, ipolicy2, ncar_note, "
                  "       nass_note, nins_note, nseal_note, nremark, iexaminer, "
                  "       icreate , dcreate, iupdate, dupdate "
                  " FROM ca_note "
                  " WHERE iexaminer = '%s' AND fstatus != 'D'"
                  "   AND date(dcreate) between '%s' and '%s'",
                      iexaminer, dcreateBgn, dcreateEnd);
 printf("qcur_buf[%s]\n", qcur_buf);
 if( strlen( trim(itag)) != 0) 
 {
     sprintf_s( stmp,sizeof stmp, " AND itag = '%s'", itag);
     strcat( qcur_buf, stmp);
 }
 if( strlen( trim(iassured)) != 0) 
 {
     sprintf_s( stmp,sizeof stmp, " AND iassured = '%s'", iassured);
     strcat( qcur_buf, stmp);
 }
 if( fstatus[0] == '0' || fstatus[0] == '1')
 {
     sprintf_s( stmp,sizeof stmp, " AND ((dply1_begin is not null and fstatus1 = '%s') or ( dply2_begin is not null and fstatus2 = '%s'))", fstatus, fstatus);
     strcat( qcur_buf, stmp);
 }

 $PREPARE mq_tmp FROM $qcur_buf;
 $DECLARE mq_01 CURSOR FOR mq_tmp;
 $OPEN mq_01;

 for(;;)
  {
    $FETCH mq_01 INTO $iserial, $iestimate, $ilast_ply, $icard1, $nassured,
                      $iassured, $itag, $iengine, $iofficer, $dply1_begin, $dply1_end, 
                      $dply2_begin, $dply2_end, $fstatus1, $ipolicy1, $fstatus2, $ipolicy2, $ncar_note, 
                      $nass_note, $nins_note, $nseal_note, $nremark, $iexaminer, 
                      $icreate , $dcreate, $iupdate, $dupdate;

    if (SQLCODE == SQLNOTFOUND) break;

    cm_buf_init(tmpbuf);
    if ( count == 0 )
     {
      cm_buf_res_msg();             /* reserve for MsgCode and count */
      cm_buf_res_count();
     }
     cm_buf_put("%d %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s", 
                 iserial, iestimate, ilast_ply, icard1, nassured,
                 iassured, itag, iengine, iofficer, dply1_begin, dply1_end, 
                 dply2_begin, dply2_end, fstatus1, ipolicy1, fstatus2, ipolicy2, ncar_note, 
                 nass_note, nins_note, nseal_note, nremark, iexaminer, 
                 icreate , dcreate, iupdate, dupdate);

    tmp_len = cm_buf_len(tmpbuf);
    if ( tmp_len + repbuf_len < 3000 )   /* buffer size less than 4K */
     {
      memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
      repbuf_len += tmp_len;
      count++;
     }
    else                               /* more than 4K, send to client side */
     {
      cm_buf_init(ReplyBuf);
      cm_buf_put_msg(M_CM_OK);
      cm_buf_put_count(count);
      if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
       {
        $CLOSE mq_01;
        return apiRC;
       }
      else               /* clear ReplyBuf and count to start all over again */
       {
        replycnt++;
        if (replycnt == 20)   /* more than 30K, client cannot display,error */
        {
         cm_buf_init(ReplyBuf);
         cm_buf_put("%l",M_CM_OUT_SPACE);
         tmp_len = cm_buf_len(ReplyBuf);
         if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
          return apiRC;
         return M_CM_OUT_SPACE;
        }
        ReplyBuf[0] = '\0';
        count = 0;
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();           /* reserve for MsgCode and count */
        cm_buf_res_count();
        cm_buf_put("%d %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s", 
                    iserial, iestimate, ilast_ply, icard1, nassured,
                    iassured, itag, iengine, iofficer, dply1_begin, dply1_end, 
                    dply2_begin, dply2_end, fstatus1, ipolicy1, fstatus2, ipolicy2, ncar_note, 
                    nass_note, nins_note, nseal_note, nremark, iexaminer, 
                    icreate , dcreate, iupdate, dupdate);

        repbuf_len = cm_buf_len(ReplyBuf);
        count++;
       }
     }
  } /* for loop */

  $CLOSE mq_01;
 if (count > 0)   /* break out, at least one record is selected */
  {
    cm_buf_init(ReplyBuf);
    cm_buf_put_msg(M_CM_OK);
    cm_buf_put_count(count);
    if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
      return apiRC;
    return api_OKComplete;
  }
 else            /* break out, not any raw is found */
  {
   if( exitsub(reply, SQLNOTFOUND) == True )
    return SQLNOTFOUND;
   return apiRC;
  }

 errexit:
  printf("into errexit SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
  if ( exitsub(reply,SQLCODE) == True )
   return SQLCODE;
  return apiRC;
}

long car340_get_ilast_ply(reply)
serverReply reply;
{
	$char stmt1[1024];
	$char ilast_ply[21];
	$char fcard_class[2], icard[21], nassured[120], iassured[15], itag[15], iengine[30], iofficer[15], dply_begin[31], dply_end[31];
	int   repbuf_len=0;
	
	cm_buf_get("%s %s", DBName, ilast_ply);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
	    if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
		    return M_CM_DB_NOTOPEN;
	    return apiRC;
	}
	
	sprintf_s(stmt1, sizeof stmt1, " SELECT fcard_class, a.icard, nassured, iassured, itag, iengine, iofficer,"
	                               "        dply_begin, dply_end "
								   "   FROM newa%s:ply_relation a, newa%s:policy b "
								   "  WHERE a.ipolicy = b.ipolicy "
								   "    AND a.ipolicy = '%s' ", DBName, DBName, ilast_ply);
	
	$PREPARE get_ilast_ply1 FROM $stmt1;
	$EXECUTE get_ilast_ply1 INTO $fcard_class, $icard, $nassured, $iassured, $itag, $iengine, $iofficer, $dply_begin, $dply_end;
	
	cm_buf_init(ReplyBuf);
	cm_buf_put("%d %s %s %s %s %s %s %s %s %s", M_CM_OK, fcard_class, icard, nassured, iassured, itag, iengine, iofficer, dply_begin, dply_end);
	repbuf_len = cm_buf_len(ReplyBuf);
	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
		return apiRC;
	
	return api_OKComplete;
	
errexit:
	printf("into errexit SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
	if ( exitsub(reply,SQLCODE) == True )
		return SQLCODE;
	return apiRC;
}

long car340_get_iestimate(reply)
serverReply reply;
{
	$char stmt2[1024];
	$char iestimate1[25];
	$char icard[21], nassured[120], iassured[15], itag[15], iengine[30], iofficer1_2[15], dply1_begin[31], dply2_begin[31], dply1_end[31], dply2_end[31];
	int   repbuf_len=0;
	
	cm_buf_get("%s %s", DBName, iestimate1);
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
	{
	    if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
		    return M_CM_DB_NOTOPEN;
	    return apiRC;
	}
	
        cm_buf_init(ReplyBuf);
        cm_buf_res_msg();
        cm_buf_res_count();
	sprintf_s(stmt2, sizeof stmt2, " SELECT icard1, nassured, iassured, itag, iengine, CASE WHEN nvl(iofficer2, '') <> '' THEN iofficer2 ELSE iofficer1 END, "
	                               "        dply1_begin, dply1_end, dply2_begin, dply2_end "
				       "   FROM newa%s:estimate "
				       "  WHERE iestimate = '%s' ", DBName, iestimate1);
	printf("stmt2[%s]\n",stmt2);
	$PREPARE get_iestimate1 FROM $stmt2;
	$EXECUTE get_iestimate1 INTO $icard, $nassured, $iassured, $itag, $iengine, $iofficer1_2, $dply1_begin, $dply1_end, $dply2_begin, $dply2_end;

        if(SQLCODE==SQLNOTFOUND)
        {
            if(exitsub(reply,M_CM_NOT_FOUND) == True)       /*?*/
                return M_CM_NOT_FOUND;                        /*?*/
            else
                return apiRC;
        }
  
	cm_buf_put("%s %s %s %s %s %s %s %s %s %s", 
	            icard, nassured, iassured, itag, iengine, iofficer1_2, dply1_begin, dply1_end, dply2_begin, dply2_end);
	cm_buf_put_msg(M_CM_OK);
	repbuf_len = cm_buf_len(ReplyBuf);
	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
		return apiRC;
	else
	    return api_OKComplete;
	
errexit:
	printf("into errexit SQLCODE[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
	if ( exitsub(reply,SQLCODE) == True )
		return SQLCODE;
	return apiRC;
}
