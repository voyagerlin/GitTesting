/*--------------------------------------------------*/
/*   PROGRAM : ca180m01s.ec by 101314          */
/*   MODIFIER:                                      */
/*                                                  */
/*   DATE    : 2021/09/06                           */
/*--------------------------------------------------*/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "carmsgs.h"
#include "commsgs.h"
$include sqlca;
#include <decimal.h>

#include <stdlib.h>
#include "cmprint.h"
#include "print.h"
#include "is_def.h"
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "safeclib.h"


char errbuf[512];
$int count1;
$char getfile[300];
FILE   *fp;
static int   recLen=1024;
static char  *bp;
char delimiter;
int  offset;
int  tmp_len;
/*--------------------------------------------------*/
long car180(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{
	long rtncode;
	long car180_insert(),car180_single_query(),car180_multiple_query(),car180_update_exec();
	char option;

	cm_buf_init(command);
 	cm_buf_get("%c",&option);
        printf("38:option\n");
 	switch(option)
 	{
	  	case 'A':
    		rtncode=car180_insert(reply);
        	break;
  		case 'Q':
    		rtncode=car180_single_query(reply);
        	break;
  		case 'M':
        	rtncode=car180_multiple_query(reply);
        	break;
  		case 'D':
  		case 'U':
        	rtncode=car180_update_exec(reply,command,com_len);
        	break;
  		default :
    		if(exitsub(reply,M_CM_WRONG_OPTION) == True)
        		return M_CM_WRONG_OPTION;
           	return apiRC;
 	}
 	return(rtncode);
}

/*--------------------------------------------------*/
long car180_insert(reply)
serverReply reply;
{
	
}

/*--------------------------------------------------*/
long car180_single_query(reply)
serverReply reply;
{
        
	$char   stmt[1024],DBName[3];
	$char Full_DBName[20];
	
	$char   iins_kind[2],iquery_kind[2],txb_query[40];	/*buf_get*/
	$char   ipre_rcv[21],iapplicant[11],napplicant[41],dbegin[21],dend[21],deffect[21],ileader[11],nleader[21],iquota[11],nquota[41],charge[10],ipolicy1[21];   /*buf_put*/
	$char   ipre_rcv2[21],iapplicant2[11],napplicant2[41],dbegin2[21],dend2[21],ileader2[11],nleader2[21],iquota2[11],nquota2[41];   /*buf_put*/
	$char   edrCount[10],userid[11];
         $char   stmp_txb_query[128];
	
	int     rows=0,tmp_len,first;

	cm_buf_get("%s %s %s %s",DBName,iins_kind,iquery_kind,txb_query);

	printf("167:car180_single_query\n");
	$WHENEVER SQLERROR GOTO errexit;
	
	if (db_select(DBName) == False)
		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
	
	printf("iins_kind = [%s], iquery_kind = [%s], txb_query = [%s]", iins_kind, iquery_kind, txb_query);

	if(iquery_kind[0] == '2') /*�d�߱���:�O�渹�X�A�����X�����渹*/
	{
	        printf("221:select ipre_rcv\n");
                $SELECT ipre_rcv
                    INTO $ipre_rcv
                    FROM cm_pre_receive
                    WHERE ipolicy1 = $txb_query
                    AND iins_cat = 'C'
                    AND iendorse = '' 
                    AND ipre_end = ''
                    AND iins_kind=$iins_kind;
                    
                  if(SQLCODE==SQLNOTFOUND)
            	{
            		if(exitsub(reply,M_CM_NOT_FOUND) == True) 
            			return M_CM_NOT_FOUND;
            		else
            			return apiRC;
            	}
	}else{
	        sprintf_s(ipre_rcv, sizeof ipre_rcv, txb_query);
         }
		 
		 strcpy(ipolicy1, " ");
		 strcpy(dbegin, " ");
		 strcpy(dend, " ");
	
	    printf("236:select all\n");	    
	    $SELECT ipre_rcv,iapplicant,napplicant,dbegin,dend,deffect,
                    ileader,(SELECT nname FROM officer WHERE iofficer = a.ileader) AS nleader,
                    iquota,(SELECT nbranch FROM sa_branch_type WHERE ibranch = a.iquota) AS nquota,ipolicy1
	          INTO   $ipre_rcv,$iapplicant,$napplicant,$dbegin,$dend,$deffect,$ileader,$nleader,$iquota,$nquota,$ipolicy1
                   FROM cm_pre_receive a
                   WHERE iins_kind=$iins_kind
                   AND iins_cat = 'C'
                   AND ipre_rcv = $ipre_rcv
                   AND iendorse = '' 
                   AND ipre_end = ''
				   AND ipolicy1 <> '';

		printf("ipolicy1 = [%s], dbegin = [%s], dend = [%s]\n", ipolicy1, dbegin, dend);
		
	if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True) 
			return M_CM_NOT_FOUND;
		else
			return apiRC;
	}
	 
	printf("254:select dentry\n");
        	$SELECT dentry
          FROM ao_prercv_pass
         WHERE ipre_rcv = $ipre_rcv
           AND iins_kind = $iins_kind
           AND ipre_end = '';
           
        if(SQLCODE==SQLNOTFOUND) /*�����O*/
        {
            sprintf_s(charge, sizeof charge, "�����O");
        }
        else  /* �w���O*/
        {
             sprintf_s(charge, sizeof charge, "�w���O");
        }
	
	strcpy(Full_DBName,get_car_full_db(ipolicy1));
	printf("250:ipolicy1=[%s]   iins_kind=[%s]\n",ipolicy1,iins_kind);
	printf("250:Full_DBName=[%s]\n",Full_DBName);
	printf("282:\n");
          sprintf_s(stmt, sizeof stmt, "SELECT itmp_policy,iapplicant,napplicant,dply_begin,dply_end, "
                           " a.ileader,(SELECT nname FROM officer WHERE iofficer = a.ileader) AS nleader, "
                           " a.iquota,(SELECT nbranch FROM sa_branch_type WHERE ibranch = a.iquota) AS nquota "
			" FROM %s:ply_relation a "
			" JOIN %s:policy b ON a.ipolicy = b.ipolicy "
 			" WHERE a.ipolicy  = '%s' "
   			" AND fcard_class = '%s'",Full_DBName,Full_DBName,ipolicy1,iins_kind);
   	printf("290:stmt=[%s]\n",stmt);
   		
         $PREPARE cur1 FROM $stmt;
         printf("293:\n");	     
     	$EXECUTE cur1 INTO $ipre_rcv2,$iapplicant2,$napplicant2,$dbegin2,$dend2,$ileader2,$nleader2,$iquota2,$nquota2;
     	         
         if(SQLCODE==SQLNOTFOUND)
	{
		if(exitsub(reply,M_CM_NOT_FOUND) == True) 
			return M_CM_NOT_FOUND;
		else
			return apiRC;
	}
	
	 sprintf_s(stmt, sizeof stmt, "SELECT count(*) "
                                  " FROM %s:edr_relation "
                                  " WHERE ipolicy = '%s'",Full_DBName,ipolicy1);
   			
         $PREPARE cur1 FROM $stmt;
     	$EXECUTE cur1 INTO $edrCount;
	
	printf("306:edrCount=[%s]\n",edrCount);
	
	printf("260:ipre_rcv2=[%s]\n",ipre_rcv2);
	
	cm_buf_init(ReplyBuf);
	printf("203:\n"); 
	
         cm_buf_put("%l %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s %s", \
	            M_CM_OK,ipre_rcv,iapplicant,napplicant,dbegin,dend, \
	            ileader,nleader,iquota,nquota,charge,ipre_rcv2,iapplicant2,napplicant2, \
	            dbegin2,dend2,ileader2,nleader2,iquota2,nquota2,edrCount,ipolicy1);
                 
	printf("209:\n"); 
	tmp_len = cm_buf_len(ReplyBuf);
	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete)==False)
		return apiRC;
	else
		return api_OKComplete;
	
errexit:
	if ( exitsub(reply,SQLCODE) == True )
		return SQLCODE;
	return apiRC;
}

/*--------------------------------------------------*/
long car180_multiple_query(reply)
serverReply reply;
{
         printf("197:car180_multiple_query\n");
	$char   stmt[1024],DBName[3];
	
	$char   iins_kind[2],iquery_kind[2],txb_query[40];	/*buf_get*/
	$char   ipre_rcv[21],ipolicy1[21],iendorse[21],iapplicant[11],napplicant[41],dbegin[21],dend[21];   /*buf_put*/
         $char   stmp_txb_query[128];
         
         printf("222:\n");
   	char    tmpbuf[4000];
   	int     count=0,repbuf_len=0,tmp_len=0,replycnt=0;
   	int     i,total_count=0,flag;
   	char irule_mainBuf[12],iruleBuf[12];
         printf("226:cm_buf_get\n");
         cm_buf_get("%s %s %s %s",DBName,iins_kind,iquery_kind,txb_query);

   	$WHENEVER SQLERROR GOTO errexit;

   	if (db_select(DBName) == False)
   	{
    	if( exitsub(reply,M_CM_DB_NOTOPEN) == True )
			return M_CM_DB_NOTOPEN;
      	return apiRC;
   	}
	
	 if(iquery_kind[0] == '1') /*rad_ipre_rcv*/
	{
	    	if(txb_query[0] == '*')
                  {
                	strcpy(stmp_txb_query," ");
            	}
               	else
                  {
                	sprintf_s(stmp_txb_query, sizeof stmp_txb_query, "AND ipre_rcv = '%s' ",txb_query);
            	}
	}
	else                                     /*rad_ipolicy1*/
	{
	    	if(txb_query[0] == '*')
                  {
                	strcpy(stmp_txb_query," ");
            	}
               	else
                  {
                	sprintf_s(stmp_txb_query, sizeof stmp_txb_query, "AND ipolicy1 = '%s' ",txb_query);
            	}	
         }
	
	
	sprintf_s(stmt, sizeof stmt, "SELECT ipre_rcv,ipolicy1,iendorse,iapplicant,napplicant,dbegin,dend "
                   " FROM cm_pre_receive "
                   " WHERE iins_kind=%s  "
                   " %s "
                   " AND ipre_end = '' "
                   " AND iendorse = '' "
                   " AND iins_cat = 'C'",iins_kind,stmp_txb_query);

	$PREPARE m_cur1 FROM $stmt;
	$DECLARE m_cur CURSOR FOR m_cur1;
	printf("266:stmt[%s]\n",stmt);
	$OPEN m_cur;
   	for(;;)
   	{
    	$FETCH m_cur INTO $ipre_rcv,$ipolicy1,$iendorse,$iapplicant,$napplicant,$dbegin,$dend;         /*--------------cur INTO--------------*/
     	if (SQLCODE != 0) break;

      	cm_buf_init(tmpbuf);
         printf("274:cm_buf_init\n");
         
      	if ( count == 0 )
      	{
        	cm_buf_res_msg();               /* reserve for MsgCode and count */
         	cm_buf_res_count();
      	}
	
      	cm_buf_put("%s %s %s",ipre_rcv,iapplicant,napplicant);      /*--------------buf_put--------------*/
         printf("283:cm_buf_put\n");	
      	tmp_len = cm_buf_len(tmpbuf);
      	
    	printf("286:tmpbuf[%s]\n",tmpbuf);
    	
      	if ( tmp_len + repbuf_len < 3000 )  /* buffer size less than 4K */
      	{
        	        memcpy(&ReplyBuf[repbuf_len],tmpbuf,tmp_len);
        	        repbuf_len += tmp_len;
        	        count++;
     	}
      	else                               /* more than 4K, send to client side */
      	{
        	        cm_buf_init(ReplyBuf);
        	        cm_buf_put_msg(M_CM_OK);
        	        cm_buf_put_count(count);
         	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OK)==False)
         	{
            	         $CLOSE m_cur;
	    		$FREE m_cur;
            	         return apiRC;
		}
            	else                      /* clear ReplyBuf and count to start all over again */
            	{
                    	replycnt++;
        	                 if (replycnt == 10)   /* more than 30K, client cannot display,error */
            	        {
                	       	         cm_buf_init(ReplyBuf);
                    	   	cm_buf_put("%l",M_CM_OUT_SPACE);
            	               	tmp_len = cm_buf_len(ReplyBuf);
            	               	if (SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
                              	        return apiRC;
                       		return M_CM_OUT_SPACE;
                    	}
                    	ReplyBuf[0] = '\0';
                    	count = 0;
                    	cm_buf_init(ReplyBuf);
                    	cm_buf_res_msg();     /* reserve for MsgCode and count */
                    	cm_buf_res_count();
        
                    	cm_buf_put("%s %s %s",ipre_rcv,iapplicant,napplicant);      /*--------------buf_put--------------*/
                    	printf("324:cm_buf_put\n");
                    	repbuf_len = cm_buf_len(ReplyBuf);
                    	count++;
    	         }
	}
	}  /* for loop */
   	$CLOSE m_cur;
   	$FREE m_cur;

	if (count > 0)  /* break out, at least one record is selected */
   	{
      	cm_buf_init(ReplyBuf);
      	cm_buf_put_msg(M_CM_OK);
      	cm_buf_put_count(count);
      	if (SendSyncReply(reply,ReplyBuf,repbuf_len,api_OKComplete)==False)
        	return apiRC;
      	return api_OKComplete;
   	}
   	else  /* break out, not any raw is found */
   	{
    	if( exitsub(reply,M_CA_NRATE) == True )
        	return M_CA_NRATE;
      	return apiRC;
   	}

errexit:
   	if ( exitsub(reply,SQLCODE) == True )
    	return SQLCODE;
   	return apiRC;
}

long car180_update_exec(reply,command,com_len)
serverReply reply;
voidP command;
int com_len;
{		
	$char    DBName[3];

	$char   update_type[2],iins_kind[2],ipre_rcv[21],iapplicant[11],napplicant[41],dbegin[31],dend[31],tempLbl_query[40],itype[2],iupdate[11],ileader[11],iquota[11],ipolicy1[21];	/*buf_get*/
	$char   ilog_number[21];
	/* undate_type:1=�󥿭n�O�H�B2=�󥿥ͮĤ�     iins_kind:1=�j���I�B2=���N�I */
	
	int     tmp_len,raw_len,count,rows=0,i,flag,count1,y;
	
	char  option,*pos,*raw_ptr,cur_buf[10000],*comm,type;
	long  dummy;
	long  MsgCode;
	int   first;
	int   k, j, is_del_fail=0, is_upd_fail=0,is_add_fail=0;
	$char  stmt_buf[1024];
	$int     chk_code;
	comm = (char *) command;
	cm_buf_init(command);
	cm_buf_get("%c %s",&option,DBName);
	printf("439:\n");
	cm_buf_get("%s %s %s %s %s %s %s %s %s %s %s %s %s", \
	           update_type,iins_kind,ipre_rcv,iapplicant,napplicant,dbegin,dend,tempLbl_query,itype,iupdate,ileader,iquota,ipolicy1);
	           	
	$WHENEVER SQLERROR GOTO errexit;

   	if (db_select(DBName) == False)
		return exitsub(reply,M_CM_DB_NOTOPEN) ? M_CM_DB_NOTOPEN : apiRC;
	         
	 printf("466:update_type[%s],iins_kind[%s],ipre_rcv[%s],iapplicant[%s] \n",update_type,iins_kind,ipre_rcv,iapplicant);
   	

   	
   	$BEGIN WORK;
   	
 
   	$WHENEVER SQLERROR GOTO errexit;

         if(option == 'U')
   	{
   	        printf("514:\n");              
   	            
      	        if(update_type[0] == '1')  /*�󥿭n�O�H*/
      	        {
          	      printf("517:UPDATE\n");          	      
                        $UPDATE cm_pre_receive
                            SET(iapplicant,napplicant, iupdate, dupdate)=($iapplicant,$napplicant, 'car180', CURRENT)
                            WHERE ipre_rcv = $ipre_rcv
                            AND ipolicy2 = ''
                            AND iins_cat = 'C'
                            AND iendorse = ''
                            AND iins_kind = $iins_kind
                            AND ipre_end = '';                        
      	        }
      	        else if(update_type[0] == '2')  /*�󥿥ͮĤ�*/
      	        {
           	      printf("527:UPDATE\n");
           	          /*�N����~�ର�褸�~*/
                            strcpy(dbegin,cm_to_infdate(dbegin));
							strcpy(dend,cm_to_infdate(dend));
                            printf("538:dbegin=[%s], dend=[%s]\n",dbegin,dend);
                            
                        $UPDATE cm_pre_receive /*ú�ڴ����B�w�w�ͮĤ�P�O�I�ͮĤ�ۦP*/
                            SET(deffect, paydate, dbegin, dend, iupdate, dupdate)=($dbegin, $dbegin, $dbegin, $dend, 'car180', CURRENT) 
                            WHERE ipre_rcv = $ipre_rcv
                            AND ipolicy2 = ''
                            AND iins_cat = 'C'
                            AND iendorse = ''
                            AND iins_kind = $iins_kind
                            AND ipre_end = '';
      	        }
      	               	        
              	 if( is_upd_fail ) goto errexit;
              	 
              	 if(itype[0] == 'I' || itype[0] == 'E')
              	 {
              	    sprintf_s(ilog_number, sizeof ilog_number, ipre_rcv);
              	 }
              	 else
              	 {
               	    sprintf_s(ilog_number, sizeof ilog_number, ipolicy1);             	    
              	}
              	 
              	 $INSERT INTO ca_log
            	       (ipgid, itype, ilog_number1, ilog_number2, ncontent, iupdate, dupdate)
            	VALUES ("car180",$itype,$ilog_number,$ileader,$iquota,$iupdate,current);	
		printf("565:insert\n");
		
		if( is_add_fail ) goto errexit;
              	 
            	cm_buf_init(ReplyBuf);
            	cm_buf_put("%l",M_CM_OK);
            	tmp_len = cm_buf_len(ReplyBuf);
            	if(SendSyncReply(reply,ReplyBuf,tmp_len,api_OKComplete) == False)
            	{
                    	$WHENEVER SQLERROR CONTINUE;
                        	$ROLLBACK WORK;
                        	return apiRC;
            	}
        	        $WHENEVER SQLERROR GOTO errexit;
            	$COMMIT WORK;
            	return api_OKComplete;
   	}
   	else
   	{
		return exitsub(reply,M_CM_WRONG_OPTION) ? M_CM_WRONG_OPTION : apiRC;
   	}

errexit:
	MsgCode = SQLCODE;
	$WHENEVER SQLERROR CONTINUE;
   	$ROLLBACK WORK;
   	if( SQLCODE != 0) MsgCode = SQLCODE;
   	return exitsub(reply,MsgCode) ? MsgCode : apiRC;
}
