/**********************************************************************/
/*   program id   : ca301p05s.ec                                      */
/*   program name : �۰ʥX��n�O�ѥ��^E-mail�q��(�D��)                */
/*   date written : 2016/05/09                                        */
/*   date modify  : yyyy/mm/dd                                        */
/*   shell        : car3015_email                                     */
/*   exec time    : 00:20                                             */
/**********************************************************************/

#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"
#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "othmsgs.h"
#include "commsgs.h"
#include "sqlfatal.h"
#include "safeclib.h"

char  	outputf[ N_FILE+1];
$char  	userid[11],sDdate[11];
char  	ddate[11];
char	  syy[4],smm[3],sdd[3],sdate[11];

$char	DBName[5];
DBinfo  *list;
    
int     flen,count_db,i;
FILE    *fp;
char    sApHome[30];
$char   fname[60];
$char   filename[121];
$char	  ftitle[1024],nsubject[512],nattachment[1025];
	
$char	  mmsg[1024];
$char 	tbuf[501];
$char 	mbuf[9000];
$loc_t 	ctxt;

$char	smail[41];
$char	stmt[4096],stmt1[256],stmt2[256];
char	msgbuf[100];

$char	pre_ileader[11],sNleader[11],year2[3];
$char sIemp[11],sNname[11];
$int 	mail_count,C_count,M_count;
$long	dsys;

$char	itmp_policy[21],ipolicy[21],icard1[21],itag[CA_TAG_NUM],fassured[2],dpolicy[11],iroute[21];
$varchar nassured[121],sNassured[121];
$char	iofficer[11],nofficer[11],ileader[11],nleader[11],nmail_type[11];
$int mpremium = 0;
$char   cdate1[11],cdate2[11];
$char ileader1[11],ileader2[11],ileader3[11];

/* asempl */
$char	email[51],chinese_name[15];

$char stmt_tmp[1024];
/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
    int rc;
      
    batchinit();
    strcpy(DBName,  isNULLstr(argv[1]));
    strcpy(userid,  isNULLstr(argv[2]));
    strcpy(ddate,   isNULLstr(argv[3])); /* cyy/mm/dd */
    strcpy(outputf, isNULLstr(argv[4]));
    
    strcpy(sDdate,cm_to_infdate(ddate));
    printf("-----dpolicy : [%s]\n-----",sDdate);

    rc = car3015_get_db();
    if (rc != M_CM_OK) {
        printf("error on car3015_get_db\n");
        return rc;
    }
    
    /* �ئ۰ʥX��O��M����� temp table (car3015) */        
    rc = car3015_init_data();
    if (rc != M_CM_OK) {
        printf("error on car3015_init_data\n");
        return rc;
    }
        
    /* �d�ߦ۰ʥX��O�������� */        
    rc = car3015_ply_data();
    if (rc != M_CM_OK) {
        printf("error on car3015_ply_data\n");
        EWRITE(userid, rc, "�d�߫O���Ʀ��~!");
        return rc;
    }

    /* �H�e���I�۰ʥX��O�� E-mail �q����ťD�� */
    rc = car3015_send_email_ileader1(); 
    if (rc != M_CM_OK) {
        printf("error on car3015_send_email_ileader1\n");
        EWRITE(userid, rc, "�H�oE-mail�q���޲z�H���~!");
        return rc;
    }
    
    /* �H�e���I�۰ʥX��O�� E-mail �q�����ťD�� */
    rc = car3015_send_email_ileader2(); 
    if (rc != M_CM_OK) {
        printf("error on car3015_send_email_ileader2\n");
        EWRITE(userid, rc, "�H�oE-mail�q���޲z�H���~!");
        return rc;
    }
    
    /* �H�e���I�۰ʥX��O�� E-mail �q���ҰϥD�� */
    rc = car3015_send_email_ileader3(); 
    if (rc != M_CM_OK) {
        printf("error on car3015_send_email_ileader3\n");
        EWRITE(userid, rc, "�H�oE-mail�q���޲z�H���~!");
        return rc;
    }

    printf("[car3015]:process ok!\n"); 
}
/*----------------------------------------------------------------------------*/
long car3015_get_db()
{
    int	rc;

    if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "��Ʈw�L�k�}��!");
       return M_CM_DB_NOTOPEN;
    }
    
    rc = getApHome(sApHome);
    if (rc < 0) {
        strcpy(msgbuf,"read Config file error!!-->getApHome\n");
        EWRITE(userid,rc,msgbuf);
        return rc;
    }
    
    if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
    }

    return M_CM_OK;
}
/*----------------------------------------------------------------------------*/
long car3015_init_data()
{
    $whenever sqlerror goto errexit;

    sprintf_s(stmt_tmp, sizeof stmt_tmp,"create temp table car3015 ( \
		   itmp_policy		     char(20),\
		   ipolicy		     char(20),\
		   icard1          char(20),\
		   nassured        char(120),\
       itag            char(%d),\
       mpremium        integer,\
       dpolicy         date,\
       iofficer        char(10),\
       nofficer        char(10),\
       iroute          char(20),\
       nmail_type      char(10),\
       ileader         char(10),\
       nleader         char(10),\
       fassured        char(1),\
       day             integer,\
       ileader1        char(10),\
       ileader2        char(10),\
       ileader3        char(10)\
     )with no log;",CA_TAG_NUM-1);
     $PREPARE stmp FROM $stmt_tmp;
     $EXECUTE stmp;

/* 	
    	$SELECT first 1 dwork
           INTO $cdate2
           FROM cm_wrktbl
          WHERE dwork < $sDdate
        ORDER BY 1 desc;
        strcpy(cdate1,cm_from_infdate_100(cdate2));

    printf("-----cdate1 = [%s]-----\n",cdate1);

    cm_char_split_3ymd(cdate1,syy,smm,sdd);
*/

    printf("-----ddate = [%s]-----\n",ddate);
    dsys = cm_ymd_cdate(ddate);
    cm_char_split_3ymd(ddate,syy,smm,sdd);

    
    sprintf_s(sdate, sizeof sdate,"%s%s%s",syy,smm,sdd);
    printf("-----sdate = [%s]-----\n",sdate);
    
    /* ���~�� */
    strcpy(year2,substring(sdate,2,2));
    printf("-----���~��:[%s]-----\n",year2);

    /* ���Y */
    strcpy(ftitle,
           "�����渹,�O�渹�X,�j���Ҹ�,�Q�O�I�H�m�W,���P���X,�O�O,�X����,�g��N��,"
           "�g��N������,�q���N��,�l�H�覡,�޲z�H�N��,�޲z�H����\n");
    
    /* �D�� */
    sprintf_s(nsubject, sizeof nsubject,"�n�O�ѥ��^�q��");
	
    return M_CM_OK;

errexit:
        sqlfatal();
        EWRITE(userid,SQLCODE,sqlca.sqlerrm);
        return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car3015_ply_data()
{
   int	rc;
   
   $whenever sqlerror goto errexit;
   
   for(i=0;i<count_db;i++) 
   {  	 
     sprintf_s(stmt, sizeof stmt,"INSERT INTO car3015 "
	   "SELECT a.itmp_policy, a.ipolicy, CASE WHEN a.fcard_class = '1' Then a.icard ELSE ' ' END, "
	   "       b.nassured , b.itag , (a.mdmg_prem+a.mlia_prem) as mpremium , "
	   "       a.dpolicy, a.iofficer, "
	   "      (SELECT nname FROM officer WHERE iofficer = a.iofficer) as nofficer, "
	   "       b.iroute, decode(a.fmail_type,'0','���e�~�l�H','1','���H','2','����', "
	   "                        '3','����','4','����',' '), a.ileader, " 
	   "      (SELECT nname FROM officer WHERE iofficer = a.ileader) as nleader, b.fassured, "
	   "      today - dpolicy, "
	   "      (select resp_name from sa_branch_type c, personal:unitid2ef d where c.ibranch = d.code_no and c.dexpire is null and c.ibranch not in ('110100','110200') and c.ibranch = a.iquota),"
	   "      (select resp_name from sa_branch_type e, personal:unitid2ef f where e.ibranch = f.code_no and e.dexpire is null and e.ibranch not in ('110100','110200') and e.fprop = '2' and e.ibranch[1,4] = a.iquota[1,4]) ,"
	   "      (select resp_name from sa_branch_type g, personal:unitid2ef h where g.dexpire is null and g.ibranch not in ('110100','110200') and g.group3[1,2]||'0000' = h.code_no and g.ibranch = a.iquota)"
	   "  FROM %s:ply_relation a, %s:policy b"
	   " WHERE a.ipolicy = b.ipolicy  "
	   "   AND a.dply_close is not null "
	   "   AND dpolicy between add_months(today-1,-3) AND (today-1)"
	   "   AND b.nequipment[13] in ('8','9','A','B','C','D','E','F','O','P','Q','R','S','T','U','V','e','f','g','h','i','j','k','l','u','v','w','x','y','z','-','.')",list[i].dbname,list[i].dbname);

	   printf("stmt[%s]\n",stmt);
	   $prepare pre_ply from $stmt;
	   $execute pre_ply;
	 }  
	
	   return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car3015_send_email_ileader1()
{
	int	rc;

	$whenever sqlerror goto errexit;
	 
	  strcpy(stmt,"SELECT itmp_policy, ipolicy, icard1, nassured," 
	              "       itag, mpremium, dpolicy, iofficer,  "
				        "	      nofficer, iroute, nmail_type, "
				        "       ileader, nleader "
                "  FROM car3015     "
				        " WHERE ileader1 = ? "
				        "   AND day > 5 "
                " ORDER BY itag ");
    printf("stmt[%s]\n",stmt);
    $PREPARE pre_data1 from $stmt;
    $DECLARE cur_data1 CURSOR FOR pre_data1;
	
    $DECLARE cur_temp1 CURSOR FOR
      SELECT DISTINCT ileader1
				INTO $ileader1
				FROM car3015
			       WHERE ileader1 is not null
			         AND day > 5
       ORDER BY ileader1;
    $OPEN  cur_temp1;
    $FETCH cur_temp1;
    strcpy(pre_ileader,ileader1);
    
    mail_count=0;
    for(;;) 
    {
			if (SQLCODE==SQLNOTFOUND) break;

			if (strcmp(ileader1,pre_ileader)!=0) 
			{
	    	rc = car3015_write_email_ileader();
	    	if (rc != M_CM_OK) {
					printf("error on car3015_write_email_ileader\n");
					return rc;
	    	}
	    	mail_count=0;
			}
			strcpy(pre_ileader,ileader1);
	
			mail_count++;
			printf("---ileader1:[%s]---\n",ileader1);
			memset(fname,0x00,sizeof(fname));
			memset(filename,0x00,sizeof(filename));
			sprintf_s(fname, sizeof fname,"%s_�n�O�ѥ��^�q��1_%s",sdate,trim(ileader1));
			sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
			printf("----filename[%s]----\n",filename);
			fp=fopen(filename,"w");
		
			fprintf(fp,ftitle);
			
			$OPEN cur_data1 USING $ileader1;
	
			for(;;)
		  {
		    $FETCH cur_data1 INTO $itmp_policy,$ipolicy,$icard1,$nassured,$itag,$mpremium,$dpolicy,$iofficer,
                             $nofficer,$iroute,$nmail_type,$ileader,$nleader;
	                           
		    if (SQLCODE==SQLNOTFOUND) break;
		   	
		    printf("---ipolicy[%s]---\n",ipolicy);
		    fprintf(fp,"%s,%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s\n",
		            itmp_policy, ipolicy, icard1, nassured, itag, mpremium, dpolicy, iofficer,
	              nofficer, iroute, nmail_type, ileader, nleader);
			}
			$CLOSE cur_data1;
			fclose(fp);
			$FETCH cur_temp1;
		}
    $FREE  cur_data1;
    $CLOSE cur_temp1;
    $FREE  cur_temp1;
	    
    if (mail_count!=0) {
        rc = car3015_write_email_ileader();
        if (rc!=M_CM_OK) {
			    printf("error on car3015_write_email_ileader\n");
			    return rc;
				}
    }
           
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

long car3015_send_email_ileader2()
{
	int	rc;

	$whenever sqlerror goto errexit;
	 
	  strcpy(stmt,"SELECT itmp_policy, ipolicy, icard1, nassured,"  
	              "       itag, mpremium, dpolicy, iofficer,  "
				        "	      nofficer, iroute, nmail_type, "
				        "       ileader, nleader "
                "  FROM car3015     "
				        " WHERE ileader2 = ? "
				        "   AND day > 8 "
                " ORDER BY itag ");
    printf("stmt[%s]\n",stmt);
    $PREPARE pre_data2 from $stmt;
    $DECLARE cur_data2 CURSOR FOR pre_data2;
	
    $DECLARE cur_temp2 CURSOR FOR
      SELECT DISTINCT ileader2
				INTO $ileader2
				FROM car3015
			       WHERE ileader2 is not null
			         AND day > 8
       ORDER BY ileader2;
    $OPEN  cur_temp2;
    $FETCH cur_temp2;
    strcpy(pre_ileader,ileader2);
    
    mail_count=0;
    for(;;) 
    {
			if (SQLCODE==SQLNOTFOUND) break;

			if (strcmp(ileader2,pre_ileader)!=0) 
			{
	    	rc = car3015_write_email_ileader();
	    	if (rc != M_CM_OK) {
					printf("error on car3015_write_email_ileader\n");
					return rc;
	    	}
	    	mail_count=0;
			}
			strcpy(pre_ileader,ileader2);
	
			mail_count++;
			printf("---ileader2:[%s]---\n",ileader2);
			memset(fname,0x00,sizeof(fname));
			memset(filename,0x00,sizeof(filename));
			sprintf_s(fname, sizeof fname,"%s_�n�O�ѥ��^�q��2_%s",sdate,trim(ileader2));
			sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
			printf("----filename[%s]----\n",filename);
			fp=fopen(filename,"w");
		
			fprintf(fp,ftitle);
			
			$OPEN cur_data2 USING $ileader2;
	
			for(;;)
		  {
		    $FETCH cur_data2 INTO $itmp_policy,$ipolicy,$icard1,$nassured,$itag,$mpremium,$dpolicy,$iofficer,
                             $nofficer,$iroute,$nmail_type,$ileader,$nleader;
	                           
		    if (SQLCODE==SQLNOTFOUND) break;
		   	
		    printf("---ipolicy[%s]---\n",ipolicy);
		    fprintf(fp,"%s,%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s\n",
		            itmp_policy,ipolicy, icard1, nassured, itag, mpremium, dpolicy, iofficer,
	              nofficer, iroute, nmail_type, ileader, nleader);
			}
			$CLOSE cur_data2;
			fclose(fp);
			$FETCH cur_temp2;
		}
    $FREE  cur_data2;
    $CLOSE cur_temp2;
    $FREE  cur_temp2;
	    
    if (mail_count!=0) {
        rc = car3015_write_email_ileader();
        if (rc!=M_CM_OK) {
			    printf("error on car3015_write_email_ileader\n");
			    return rc;
				}
    }
           
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

long car3015_send_email_ileader3()
{
	int	rc;

	$whenever sqlerror goto errexit;
	 
	  strcpy(stmt,"SELECT itmp_policy,ipolicy, icard1, nassured," 
	              "       itag, mpremium, dpolicy, iofficer,  "
				        "	      nofficer, iroute, nmail_type, "
				        "       ileader, nleader "
                "  FROM car3015     "
				        " WHERE ileader3 = ? "
				        "   AND day > 11 "
                " ORDER BY itag ");
    printf("stmt[%s]\n",stmt);
    $PREPARE pre_data3 from $stmt;
    $DECLARE cur_data3 CURSOR FOR pre_data3;
	
    $DECLARE cur_temp3 CURSOR FOR
      SELECT DISTINCT ileader3
				INTO $ileader3
				FROM car3015
			       WHERE ileader3 is not null
			         AND day > 11
       ORDER BY ileader3;
    $OPEN  cur_temp3;
    $FETCH cur_temp3;
    strcpy(pre_ileader,ileader3);
    
    mail_count=0;
    for(;;) 
    {
			if (SQLCODE==SQLNOTFOUND) break;

			if (strcmp(ileader3,pre_ileader)!=0) 
			{
	    	rc = car3015_write_email_ileader();
	    	if (rc != M_CM_OK) {
					printf("error on car3015_write_email_ileader\n");
					return rc;
	    	}
	    	mail_count=0;
			}
			strcpy(pre_ileader,ileader3);
	
			mail_count++;
			printf("---ileader3:[%s]---\n",ileader3);
			memset(fname,0x00,sizeof(fname));
			memset(filename,0x00,sizeof(filename));
			sprintf_s(fname, sizeof fname,"%s_�n�O�ѥ��^�q��3_%s",sdate,trim(ileader3));
			sprintf_s(filename, sizeof filename,"%s/rptftp/car_email/%s.csv",sApHome,fname);
			printf("----filename[%s]----\n",filename);
			fp=fopen(filename,"w");
		
			fprintf(fp,ftitle);
			
			$OPEN cur_data3 USING $ileader3;
	
			for(;;)
		  {
		    $FETCH cur_data3 INTO $itmp_policy,$ipolicy,$icard1,$nassured,$itag,$mpremium,$dpolicy,$iofficer,
                             $nofficer,$iroute,$nmail_type,$ileader,$nleader;
	                           
		    if (SQLCODE==SQLNOTFOUND) break;
		   	
		    printf("---ipolicy[%s]---\n",ipolicy);
		    fprintf(fp,"%s,%s,%s,%s,%s,%d,%s,%s,%s,%s,%s,%s,%s\n",
		            itmp_policy,ipolicy, icard1, nassured, itag, mpremium, dpolicy, iofficer,
	              nofficer, iroute, nmail_type, ileader, nleader);
			}
			$CLOSE cur_data3;
			fclose(fp);
			$FETCH cur_temp3;
		}
    $FREE  cur_data3;
    $CLOSE cur_temp3;
    $FREE  cur_temp3;
	    
    if (mail_count!=0) {
        rc = car3015_write_email_ileader();
        if (rc!=M_CM_OK) {
			    printf("error on car3015_write_email_ileader\n");
			    return rc;
				}
    }

    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/*---------------------------------------------------------------------------*/
long car3015_write_email_ileader()
{
    $whenever sqlerror goto errexit;
    
    $SELECT nname
       INTO $sNleader
       FROM officer
      WHERE iofficer = $pre_ileader;
    if (SQLCODE==SQLNOTFOUND) strcpy(sNleader,"�P��");
    
    strcpy(sNleader,trim(sNleader));
    /* email��� */
    sprintf_s(mmsg, sizeof mmsg,
	  "�z�n</P>\n\n"
	  "�q���z�A���ɬ����ݺ޲z�P���A�T����O��۰�ñ��A�n�O�ѩ|���ɦ^�M��A�q�Ш�U���P�P�����t�ɦ^�A</P>\n"
	  "����!</P>�s����� �ӫO���֫O�� �p�����D�Ь��U��쨮�I�֫O�H��</P></P></P>( ���H���CAR3015�{���۰ʱH�o )\n");

    strcpy(mbuf,rtrim(mmsg));
    ctxt.loc_loctype = LOCMEMORY;
    ctxt.loc_buffer = mbuf;
    ctxt.loc_bufsize = 9000;
    ctxt.loc_size =  strlen(mbuf) + 1;

    strcpy(email," ");
    $select email,chinese_name
       into $email,$chinese_name
       from personal:asempl
      where empl_no = $pre_ileader;

    strcpy(email,trim(email));
    if (strlen(email) != 0){ 
    	
      strcpy(email,trim(email));
      strcat(email,"@tmnewa.com.tw");
      printf("-----email:[%s]-----\n",email);
      
      /* 1110322014_SC1_batchemail�ಾ�ܷs���x */
      if (strlen(trim(fname)) != 0) sprintf_s(nattachment, sizeof nattachment,"%s.csv",trim(fname));
      printf("-----nattachment:[%s]-----\n",nattachment);
      		
      $INSERT INTO batchemail
		  (project_id, mail_date, receiver_email,
		   receiver_name, cc, content, key, mail_count, nsubject,
		   nattachment)
       VALUES
		  ("CAR3015", today, $email, $chinese_name,
		   " ", $ctxt, $fname, $mail_count, $nsubject,
		   $nattachment);
    }
    
    return M_CM_OK;
  
errexit:
    sqlfatal();
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/*-------------------------------THE END--------------------------------------*/