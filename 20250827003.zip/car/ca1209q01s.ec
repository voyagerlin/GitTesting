/************************************************************************/
/*                                                                      */   
/*   program id   : ca1209q01s.ec                                       */
/*   program name : �z�߶i�ױ������c���R����                            */
/*   date written : 2020/11/06                                          */
/*   author       : neo                                                 */
/************************************************************************/

#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include "safeclib.h"
/*--------------------------------------------------------------------*/
$char DBName[05],userid[11], ibranch_flag[2] , ibranch[8]  , dbgn[11] , dend[11];

char  msgbuf[2048], sApHome[30], rpt_type[2], getfile[101];
char  v_sMsg[1024], outputf[N_FILE+1];
int   count_db,i;
DBinfo  *list;
FILE    *fp;



/*--------------------------------------------------------------------*/

main(argc,argv)
int  argc;
char **argv;
{  
   
   int rc;
   batchinit();
   strcpy(DBName,               isNULLstr(argv[1]));
   strcpy(userid,               isNULLstr(argv[2]));
   strcpy(ibranch_flag,         isNULLstr(argv[3]));  /* ���z�����O */
   strcpy(ibranch,              isNULLstr(argv[4]));  /* ���z��� */
   strcpy(dbgn,                 isNULLstr(argv[5]));  /* ���z����϶�-�}�l */
   strcpy(dend,                 isNULLstr(argv[6]));  /* ���z����϶�-���� */
   strcpy(outputf,              isNULLstr(argv[7]));  


   printf("outputf:s\n",outputf);
        printf("--1.car1209_get_db ------ \n");
        rc = car1209_get_db();
        if (rc != M_CM_OK) {
                EWRITE(userid,rc,msgbuf);
                return rc;
        }
        
    
        printf("--2.car1209_init_data ------ \n");
        rc = car1209_init_data();
        if (rc != M_CM_OK) {
            printf("error on car1209_init_data\n");
                EWRITE(userid,rc,"�إ� temp table ���~!");
                return rc;
        }
    
        printf("--3.car1209_query_detail ------ \n");
        rc = car1209_query_detail();
        if (rc != M_CM_OK) {
        printf("error on car1209_query_detail\n");
                EWRITE(userid, rc, "���̷s�߮׸��X���~");
                return rc;
        }
         
        printf("--4.car1209_print_detail ------ \n");
        rc = car1209_print_detail();
        if (rc != M_CM_OK) {
         printf("error on car1209_print_detail\n");
         EWRITE(userid, rc, "���s�������Ӧ��~!");
         return rc;
        }
       
    
                        
    return rc;

}
/******************************************************************************/
long car1209_get_db()
{
        int return_code;
        
        $WHENEVER SQLERROR GOTO errexit;

        if (db_select(DBName) == False) {
                strcpy(msgbuf,"��Ʈw�L�k�}��");
                return M_CM_DB_NOTOPEN;
        }

        return_code = getApHome(sApHome);
        if (return_code < 0) {
                strcpy(msgbuf,"read Config file error!!-->getApHome\n");
                return return_code;
        }

        if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
       if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
          return M_CM_NOT_DBLIST;
        }

        return M_CM_OK;

errexit:
   printf("--car1209_get_db-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
/******************************************************************************/
long car1209_init_data()
{   
    $WHENEVER SQLERROR GOTO errexit;

    $create temp table tb_ca12091
    (
                iclaim                  char(20),                               -- �z�߮׸�
                dclaim                  date,                                   -- ���z���
                itype                   char(2),                                -- �o�e����
                stype                   varchar(20),                            -- ���ұ���
                iquota                  char(2),                                -- �z�ߤ���
                iapp_unit               char(2),                                -- �z�߳��
                nmessage                lvarchar(1024),                         -- ��m�Ŀ鷺�e
                sdcreate                varchar(20),                            -- �Ŀ�ɶ�
                ddcreate                date                                    -- ��� 
    )with no log;
          
    return M_CM_OK;

errexit:
    printf("--car1209_init_data-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}
/******************************************************************************/
long car1209_query_detail()
{
    int     rc;
    $char   stmt1[6000],stmt2[100],stmt3[2000];
    $int    icnt;
   
    $WHENEVER SQLERROR GOTO errexit;
        
        printf("ibranch_flag : %s \n",ibranch_flag);
        printf("ibranch : %s \n",ibranch);
        printf("dbgn : %s \n",dbgn);
        printf("dend : %s \n",dend);
         
        if(strcmp(trim(ibranch_flag), "1") == 0 )
                sprintf_s(stmt3,2000 , " G.iquota matches '%s' " , ibranch);
         else 
                sprintf_s(stmt3,2000 , " G.iapp_unit matches '%s' " , ibranch);
                
                printf("stmt2 : %s \n",stmt3);
                
        sprintf_s(stmt1,6000,
 	    "insert into tb_ca12091 \
 	    SELECT * FROM ( \
	    	SELECT p.iclaim , p.dclaim , a.itype , \
		       CASE v.fdriver_mail_type	   \
		        WHEN 'Y' THEN 'Y.�ݭn����' \
			WHEN 'N' THEN 'N.��������' \
			WHEN 'F' THEN 'F.���ҥ���' \
			WHEN 'S' THEN 'S.���ҧ���' \
			WHEN 'C' THEN 'C.����H�e' Else '' END stype, \
            CASE WHEN o.iquota[1,4] = '3602' or o.iquota[1,4] = 'L103' THEN '00' \
				 WHEN o.iquota[1,4] = '3607' or o.iquota[1,4] = 'L104' THEN '22'\
				 WHEN o.iquota[1,4] = '3603' or o.iquota[1,4] = 'L105' THEN '33'\
				 WHEN o.iquota[1,4] = '3604' or o.iquota[1,4] = 'L201' THEN '40'\
				 WHEN o.iquota[1,4] = '3605' or o.iquota[1,4] = 'L202' THEN '66'\
				 WHEN o.iquota[1,4] = '3606' or o.iquota[1,4] = 'L203' THEN '70' END iquota, \
		      o.iapp_unit, a.nmessage, \
		      CAST(nvl(max(a.dcreate), '') as varchar(19) ) as dcreate , \
		      DATE(a.dcreate) AS ddcreate \
		  FROM sysdb:ca_clm_process p	\
		LEFT JOIN sysdb:officer	o ON p.adjustment = o.iofficer \
		LEFT JOIN sysdb:sa_branch_type t ON o.iquota = t.ibranch \
		LEFT JOIN sysdb:ca_ver_relation	r ON r.iclaim =	p.iclaim \
		LEFT JOIN sysdb:ca_verify v ON v.iverify = r.iverify \
		LEFT outer JOIN	sysdb:ca_push_notify a ON a.iclaim = p.iclaim \
		 WHERE p.iclaim[6,6] = 'V' \
		   AND p.dclaim   >= '%s' \
	   	   AND p.dclaim   <= '%s' \
		GROUP BY p.iclaim , v.fdriver_mail_type	, a.itype , a.nmessage,	p.dclaim , ddcreate , o.iquota , o.iapp_unit \
 	    )G WHERE %s order by G.iclaim asc , G.dclaim asc ",  dbgn , dend , stmt3 );
         
        printf("stmt1=[%s]\n",stmt1);
        $PREPARE pre_A1 FROM $stmt1;
        $EXECUTE pre_A1;
    
     
    return M_CM_OK;
  
errexit:
    printf("--car1209_query_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid,SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

/* ------------------------------------------------------------------------- */
long car1209_print_detail()
{
    int     rc;
    char    sfilename[128],stitle[2048],stmt[2048];
    $int    icnt;

    $WHENEVER SQLERROR GOTO errexit;
    
    strcpy(sfilename,"�z�߶i�ױ������c���R����");
    strcpy(stitle,"�{���N��:CAR12091\t");
    strcat(stitle,sfilename);
    strcat(stitle,"\t�L����:");
    strcat(stitle,cm_get_sysd());
    strcat(stitle,"\n");

    
    icnt = 0;
    $select count(*) into $icnt
      from tb_ca12091;
          printf("icnt:%d\n",icnt);
    if (icnt == 0) 
    {
        sprintf_s(msgbuf,2048," %s �d�L���, �ɮ׵L�k���� ",sfilename);
        EWRITE(userid, rc , msgbuf);
        return  M_CM_NOT_FOUND;
    }
    
    strcat(stitle,"\t�׸�\t���z�ɶ�\t�o�e����\t�o�e�N�X\t���ұ���\t��x�Ŀ鷺�e\t�Ŀ�ɶ�\t���");

        
    strcpy(stmt,"select   iclaim , dclaim , itype , itype[1,1] as ftype , stype , replace(replace(nmessage,chr(13),''),chr(10),'') AS nmessage  , sdcreate , ddcreate \
                                 from tb_ca12091 where 1=1   ");        

    rc = unload_file(outputf," ",sfilename,stitle,stmt);

    if (rc != SUCCESS) {

        sprintf_s(msgbuf,2048," %s �ɮ׵L�k���� ",sfilename);

        EWRITE(userid, rc , msgbuf);
        return rc;
    }
    return M_CM_OK;
    
errexit:
    printf("--car1209_print_detail-- sqlcode[%d][%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    return SQLCODE;
}

/******************************************************************************/



