/*----------------------------------------
 * Program: ca302q01s.ec
 *          ��O�J�p�@�~
 *---------------------------------------*/

#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>
#include "is_def.h"
#include "comdata.h"
#include "globdata.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include <time.h>
#include <math.h>

$include datetime.h;
$include "ca3xxlib.h";
$include "ca_hcc.h";
$include sqlca;
$include sqltypes;
$include "ply_ins_cover.h";      /* 960612, ���ݪ��I34: */
$include "var_length.h";         /* 960612, ���ݪ��I34: */
$include "car_common.h";
$include "cmnroute.h";
$include "cmnmsg.h";

#define  FOUND                   sqlca.sqlcode!=SQLNOTFOUND
#define  NOT_FOUND               sqlca.sqlcode==SQLNOTFOUND

/** debug �}�� (#ifdef PRINTF_FLAG) ���J�p�ɭn�����A�קK�v�T�J�p�ɶ� */
/* #define  PRINTF_FLAG */
/*****************************************************************/

int     count_db;
$int    intopt = 0;
DBinfo  *db_list;
DBinfo  *get_sysdb_list();
$char   choice[2],nname[21],nchi_full[31];
$char   plyyear[4],plymonth[3],db[3];
$char   pre_ply[3][20],pre_comp[3][20];
$char   last_policy_2[20],last_policy_3[20];
$char   nproject[21],nprocomp[11],s_nequprem[6];
$char   remark1[101],remark2[101],remark4[101],remark5[141], remark6[101], remark7[101];
$char   remark_tmp1[101], remark_tmp2[101], iassured_B[21], iassured_A[21],remark3[737];
$char   stm1[25],stm2[25],stm3[25],stm5[25];
$char   tmp_big_office[10],tmp_big_sales[11];
char    GsIdx[100];
$char   iofficer_a[11];
$char   stmt[8192], dbname_tp[20], stmt_gply[300];
$char   tmp_relative_ply[POLICY_NUM_1];
$int    t_count,nproprem,tmp_nproprem1,tmp_nproprem2;
char    lia_flag,dmg_flag,dmg_flag2;

$char   f_1_9_exist,f_02_exist,f_01_exist,f_05_exist,f_08_exist,f_09_exist,f_125_exist,f_126_exist;
$char   f_31_exist,f_51_exist,f_55_exist,f_49_exist, f_135_exist, f_133_exist, f_134_exist,f_129_exist,
        f_128_exist,f_127_exist,f_124_exist,f_03_exist;
$char   f_32_exist, f_30_change, f_30_exist, f_131_exist, f_132_exist, chk_32, f_sug_28, f_sug_55;
$char   f_11_exist,f_12_exist,f_16_exist,f_19_exist,f_149_exist, f_301_exist, f_150_exist;
$char   f_14_exist, f_10_exist,f_27_exist;
$char   f_47_exist,f_24_exist,f_34_exist,f_28_exist,f_85_exist,f_147_exist;
$char   f_66_exist ,f_67_exist ,f_15_exist,f_29_exist,f_38_exist,f_39_exist;
$char   f_62_exist , f_63_exist , f_64_exist, f_143_exist ;
$char   f_61_exist , f_65_exist , f_69_exist ,f_86_exist,f_98_exist,f_07_exist;
$char   f_105_exist, f_106_exist , f_107_exist , f_108_exist, f_109_exist;
$char   f_77_exist, f_78_exist , f_79_exist , f_80_exist,  f_87_exist,
        f_88_exist,  f_89_exist ;
$char   f_110_exist, f_111_exist, f_112_exist, f_113_exist, f_114_exist,
        f_115_exist, f_117_exist, f_110_112_sug, f_110_112_ori,
        f_113_115_sug, f_18_exist, f_17_exist;
$char   f_152_exist, f_153_exist, f_154_exist, f_155_exist, f_156_exist,
        f_161_exist, f_162_exist, f_163_exist, f_164_exist, f_165_exist,
        f_181_exist, f_198_exist, f_238_exist, f_255_exist, f_302_exist;
$char   f_176_exist, f_177_exist, f_178_exist;
$char   f_530_exist, f_531_exist, f_532_exist, f_555_exist, f_561_exist, f_562_exist, f_563_exist;
$char   f_1_9_sug,f_01_sug,f_08_sug,f_105_sug,f_85_sug,f_05_sug,f_09_sug,f_120_sug,f_156_sug;
$char   f_24_nosug,f_no_comp_24,comp_flag,sug_flag;
char    err_buf[150];
$int    iplyyear,iplymonth,linnum;
$char   cy_type[3],cy_fpt[2];
$long   cy_qpt,man_qty,sug_qpt,no_sug_5556;
$double pdis_rate;
$char   issue_12[4],comp_ins[3],icar_flag[2],lia_class[3]; /*s_ilicense[13]*/
$int    motor_cnt;
$double main_discount;
$int    dmg_acc_1st,dmg_acc_2nd,dmg_acc_3rd;
$int    bqdmg[3];
$date   dpolicy;
char    dmg_flag_p,lia_flag_p;
$int    iseq_tmp;
$char   dclaim_tmp[11],dprocess_tmp[11],drescue_tmp[11],qday_tmp[11];
int     itp;
$char   sclmdb[21],sfins[2];
$int    idmg[5];
char    rdmg,rlia,rvkind;
char    smdmg,smlia,smbrg;
$char   simain_ins[INSURANCE_TYPE],sinsfcal_way[3],sstpe[INSURANCE_TYPE],tmp_provision[22];
$char   ins_type_ttmp[INSURANCE_TYPE],ori_ins_type[INSURANCE_TYPE], old_ins_type[INSURANCE_TYPE];
$char   tphone_con[21],imovephone[21],iemail[51],aemail_eply[51],tmobile_eply[21];
$char   tphone_con_cus[21],imovephone_cus[21],iemail_cus[51];
$char   ireg_no[21],feterms[2];
int     ins33_flag,ins35_flag,ins48_flag,ins56_flag,TmNewa_rule_flag,ins56_sug_flag,ins50_flag,
        ins136_flag,ins163_flag,ins166_flag,ins266_flag,ins09k_flag;
$char   birth33[11], Aipolicy[21];
char    yy33[4],mm33[3],dd33[3],dply_end_yy33[4],dply_end_mm33[3],dply_end_dd33[3];
int     age33;
$char   ichange_note[129] = " " , ichange_note_tmp[129] = " ";
$long   lDbirth_ori;
char    ndeputy[31] = " ";
$char   birth_ori[11] = " ",birth_new[11] = " ";
char    tmp_sdate[11]="";
$char   f_118_exist,f_119_exist,f_120_exist,f_121_exist,f_122_exist,f_123_exist;
/*---------------------------------------------------------------*/
$char   FormFile[N_FILE+1],OutFile[20];
int     rec_count, max_count;
long    rec_count_1=0,rec_count_2=0;
$char   DBName[5];
$char   FormTp[3];
char    outputf[65] ,outputf1[65],outputf2[65] ,outputf3[65] ,outputf5[65],outputf8[65],outputf10[65],outputf12[65] ;
$char   userid[11];
$int    fg1,y;
int     rtcn;
$char   clmply[21],clm_db[3];
$int    clmcnt ;
int     dtlint;
$char   str_deduct[9];
$char   sequip_str[201];
$char   sDplyEndBgn[11],sDplyEndEnd[11];
$long   lDplyEndBgn    ,lDplyEndEnd;
$int    iYY,iMM;
$char   sYY[4],sMM[3];
$char   sTmpMsg[512]="",ctmp_ipolicy[21]="",ctmp_iins_type[11]="",ctmp_iengine[CA_ENGINE_NUM]="",ctmp_message[121]="",ctmp_ierrno[4]="";
$char   sfile[513],sfile2[513];
char    sSelect[2] = "0" ;  /* �w�]��"��J�h��"*/
char    ipgid[9] = "car302";
int     flgMsg = 0;
char    sGenFile[2] ;  /* �����J�p��O�_�P�ɲ��s�ɮ� */
char    Execdate[11],TradEnd[11],sMinQuery[11];
$date   dExecdate,dTradEnd,dMinQuery;
$char   outMsg[11];
$char   freason_reject[2]  = " "; /* 102.01.11*/
$char   remark_reject[256] = " "; /* 102.01.11*/

/* 102.03 */
$char   Aiequip[3] = " ";
$char   ply_ym[6];
int     itmp_year,itmp_month;
char    IsPlyB;
$int    IS_1stYear_No_PlyB = -1;
$int    iRemark_yn = 0;
int     tp_iins_type = 0,tp_ins_type;  /* �]get_cm_extra_charge_car()���s�W�I�ذѼ�,���קK�v�I�ح��ƩI�s,�H0�ȥN add by sylvia 103.05.23 */
char    tp_iins_type_tmp[INSURANCE_TYPE];

$char   dbegin47[11], dend47[11];

/* �ഫN�g�����  add by sylvia 103.09.01 (1030630002_C1) */
$char   NTmpSQL[500];
$char   IsChgNofficer[2];
$char   sIprmt[4];   /*�t�XN�g��,�s�W�M�ץN�� add by sylvia 103.09.03*/
$char  *PROJ_YF;

/* �ư�����~�έp�{�����P�_ */
$int    chkPA;

/* ��104/08/15�_�����I����3�Ӥ�, �G�O�������104/12/31��, �w��h�~����O�����I��,
   ���A��ĳ�I��(��ĳ��O�զX=���O�զX)  add by sylvia 104.07/23 */
$char   fdmg_sug;   /* Y:��ĳ�I��  N:����ĳ�I�� */

$double iBasePrice;

$int    chk518;

/* �������l�s�¨�:1:�������l�h���O�� 2:���t�u�������l�v3:�������l�h���u�O�@��  ' ':��L
                  4:09+152/09+153 �s��   5:09+152/09+153 �¨�*/
$char   funknown_dmg_ori[2], funknown_dmg_sug[2];

/* ���ظg�P����O  */
$int    cnt_prj55;
$char   sdata[35][151];
$char   stmp55[11];

$int    cdiscount[3];  /* �j���I�����~�ȧ����B */
$char   bzfrom1[2];
$char   brand_BEV[2];

/* 105.12.22 �s�W��˭]�Ұ� add by sylvia 105.12.22 (1051220006_C1) */
$char   fquota63;  /* �_�G�Ұϭ��w����:(1)�_�G��(�~�Z���=63*)�B(2)��03,22���� (3)�D����,�D����B�Dcar147�]�w�����ĳq�� <==���ŦX */
$char   f245_265;  /* �s��(245)�O��(265)����W�ۤw���I�ث�ĳ�W�h add by sylvia 106.06.23 (1060614005_C1) */
$char   fbz_2131;  /* �O�g�N����(�O�o�q���N��21/31)����ĳ�����I��(��ĳ��O = ���O) add by 061476 107.07.27 (1070314007_SC3) */
$char   fkaxx;     /* ������O����ĳ�����I�� add by 061476 (1080730006_SC1)109.01.17 */
$char   fBEV;      /* �q�ʨ�����ĳ�����I�� (1130510009_C13) */
$char   fES;       /* �R�q�Τ���ĳ�����I�� (1120927002_C05) */
$char   fquota_63; /* �s�_�ҰϷs�W��ĳ��O�զX add by 061476 (1080322003_SC1) */
$char   fquota_62; /* �_�@�ҰϽվ��ĳ��O�զX add by 061476 (1080507001_SC1) */
$int    fquota67 = 0; /* �����Ұ�(67*)�S�w����ݽվ���O�զX */
$int    tmp_iym_end2;
$char   f25C01;  /* ���ӫO�r�V�Z��X�I(530,531,532,555,561,562,563���@�I��)  add by sylvia 114.04.24 (1140409004_C01)
*/
/*---------------------------------------------------------------*/
int     Insert_INS_TYPE_33();
int     Get_comp_prem_302();
int     sPrepare();
char*   splace();
long    car302_build1();
long    test_data();
char*   get_car_full_db();
char   *sLastChinese();
int     strSearchReplace();
int     get_fb_data();

$char   tmp1021[20],tmp1022[20],tmp1023[20],tmp1024[20],tmp1025[20];
$int    icnt_102;

/*****************************************************************/

main(argc,argv)
int argc;
char **argv;
{   long  src;
    char  tmpopt[2];
    $int  iCount;
    int    rc;
    int result;
    char sApHome[31];
    char path_DataFile[80];
    char cover_file[21];
    FILE   *fp;
    int    fStat;
    char syscmd[200];
    int tmp_intopt;

    float tused=0;
    time_t tstart, tstop;
    STOP_CHG1589_FLAG = 'Y';    /* �t�X�����I�����ӫ~����, ���A��105��A���ӫ~ add by sylvia 105.01.03 */

    $char  sDetail2[21],sKind[3],sdetail[21];

    strcpy(DBName   , isNULLstr(argv[1]));
    strcpy(userid   , isNULLstr(argv[2]));
    strcpy(tmpopt   , isNULLstr(argv[3]));
    strcpy(plyyear  , isNULLstr(argv[4]));
    strcpy(plymonth , isNULLstr(argv[5]));
    strcpy(sfile    , isNULLstr(argv[6]));
    strcpy(sfile2   , isNULLstr(argv[7]));
    strcpy(sSelect  , isNULLstr(argv[8]));
    strcpy(sGenFile , isNULLstr(argv[9]));
    strcpy(Execdate , isNULLstr(argv[10]));
    strcpy(TradEnd  , isNULLstr(argv[11]));
    strcpy(outputf  , isNULLstr(argv[12]));

    /***********************************************/
    time(&tstart);  /* �p�ɶ}�l */
    /***********************************************/
    strcpy(sfile, rtrim(sfile));
    strcpy(plyyear,trim(plyyear));

    iplyyear = atoi(plyyear);
    iplyyear += 1911;
    iplymonth = atoi(plymonth);
    sprintf(ply_ym,"%s%02d",plyyear,iplymonth);
    sprintf(stmp55,"%s%02d_55",plyyear,iplymonth);
    printf("trace ply_ym[%s]\n ",ply_ym);
    intopt = atoi(tmpopt);
    printf("--------------------------------------------\n");
    printf("Trace -- iplyyear  = [%d] \n",  iplyyear);
    printf("Trace -- iplymonth = [%d] \n",  iplymonth);
    printf("Trace -- sfile     = [%s] \n",  sfile);
    printf("Trace -- sfile2    = [%s] \n",  sfile2);
    printf("Trace -- sSelect   = [%s] \n",  sSelect);
    printf("Trace -- sGenFile  = [%s] \n",  sGenFile);
    printf("Trace -- Execdate  = [%s] \n",  Execdate);
    printf("Trace -- TradEnd   = [%s] \n",  TradEnd);
    printf("Trace -- outputf   = [%s] \n",  outputf);
    printf("--------------------------------------------\n\n");
    rtoday(&Today);     /* get today's datetime */
    printf("Trace -- Today     = [%ld] \n",  Today);

    /* 990820 ,�J�p��*/
    if (strlen(trim(Execdate))==0){
    	dExecdate = Today;
    }else{
    	rdefmtdate(&dExecdate, "mm/dd/yyyy", Execdate);
    }
    printf("Trace -- dExecdate = [%ld] \n",  dExecdate);

    /* 9912,���T�Y�ƺI���*/
    /* �Z�O [����� > ���T�Y�ƺI���] ���O��A�䨮��[��O�I��=0�B���d�̷s�ż�=4 */
    if (strlen(trim(TradEnd))==0){
    	dTradEnd = Today;
    }else{
    	rdefmtdate(&dTradEnd, "mm/dd/yyyy", TradEnd);
    }
    printf("Trace -- dTradEnd = [%ld] \n",  dTradEnd);

    /***********************************************/
    /***********************************************/
    /* begin */
    sprintf(sDplyEndBgn,"%s/%s/01",plyyear,plymonth);
    lDplyEndBgn = cm_ymd_cdate(sDplyEndBgn);

    /* end   */
    if (strcmp(trim(plymonth),"12")==0)
    {
        iYY = atoi(plyyear) + 1;
        strcpy(sYY, itoa(iYY));
        sprintf(sDplyEndEnd,"%s/01/01",sYY);
    }
    else
    {
        iMM = atoi(plymonth) + 1;
        strcpy(sMM, itoa(iMM));

        sprintf(sDplyEndEnd,"%s/%s/01",plyyear,sMM);
    }
    lDplyEndEnd = cm_ymd_cdate(sDplyEndEnd)-1;

    #ifdef PRINTF_FLAG
    printf("lDplyEndBgn[%ld]\n",lDplyEndBgn);
    printf("lDplyEndEnd[%ld]\n",lDplyEndEnd);
    printf("lDplyEndBgn[%s]\n", cm_cdate_str_100(lDplyEndBgn));
    printf("lDplyEndEnd[%s]\n",cm_cdate_str_100(lDplyEndEnd));
    #endif

    /* �p��J�p�~�멹�e6�Ӥ몺�~�B�� */
    itmp_year = 0 ; itmp_month = 0;
    if (iplymonth>6){
    	itmp_month = iplymonth - 6;
    	itmp_year  = iplyyear;
    }else{
    	itmp_month = iplymonth + 12 - 6;
    	itmp_year  = iplyyear -1 ;
    }

    /* �^��ca_trade_302 �����󤧤@�G
       ���T�d�ߤ�� �� (�J�p�~��- 3�Ӥ�) 1��
       (Ex. �J�p9912��O��,���^�� �d�ߤ�� �� 990901)
       ���o (�J�p�~��- 3�Ӥ�) 1��  => dMinQuery
    */
    iYY = iplyyear;
    iMM = iplymonth-3;
    if (iMM<=0){
			iMM = iMM + 12;
			iYY = iYY - 1;
    }

    sprintf(sMinQuery,"%02d/01/%d",iMM,iYY );

    rdefmtdate(&dMinQuery, "mm/dd/yyyy",sMinQuery);
    printf("Trace -- sMinQuery = [%s] \n",  sMinQuery);
    printf("Trace -- dMinQuery = [%ld] \n",  dMinQuery);

    $WHENEVER SQLERROR GOTO errexit;

    if (db_select(DBName) == False)
    {
        EWRITE(userid,M_CM_DB_NOTOPEN,DBName);
        return M_CM_DB_NOTOPEN;
    }

    if ((db_list = get_db_list (&count_db, DBName)) == (char *) 0)
    {
       EWRITE(userid, M_CM_NOT_DBLIST);
       return M_CM_NOT_DBLIST;
    }

    batchinit();
    /* ���~�T������ */
    iCnt_Before = 0;
    iCnt_After = 0;
    iCnt_NewMsg = 0;

    /* �O�_��ĳ�����I add by sylvia 104.07.28  (�t�X1040815-1041115����P�⨮���I) */
    /* 2015/12 �H�e����ĳ *//* 104/11/03�q��2016/01�]����ĳ */
    fdmg_sug = 'Y';     /* ��ĳ�����I */
    printf("�O�_��ĳ�����I:[%c]\n",fdmg_sug);

    /* $set explain on; */
    /* �ˮ֬O�_�ư�����έp�{��  */
    chk_PA = 0;
    $select case when detail2 >  today then 0 else 1 end
       into $chk_PA
       from car_code where kind = 'RN' and detail = 'CHK_PA';

    /* �ˮֱj���I���覡 A:��ӥh�~�X���� B:���������  add by sylvia 104.04.20 (1040312001_C1) */
    /* �j���I�����~�Ȥ@�ߧאּŪ��cmn144�]�w mark by 061476 110.01.20 (1100118005_SC3) */
    /*$select detail2 into $chk_cal_comp
       from car_code
      where kind = 'RN'
        and detail = 'cal_comp';
    if (SQLCODE == SQLNOTFOUND)
        strcpy(chk_cal_comp,"A");  */ /* �w�]��:��ӥh�~�X���� */

    /* N�g�����  ----------------------------------------------------------------------- */
    /* N�g��O�_�ҥ�  add by sylvia 103.09.04 */
    strcpy(IsChgNofficer,"Y"); /* �w�ҥ��ഫN�g�� modify by sylvia 1040310 */

    PROJ_YF="Y30,Y31,Y40,Y43,Y44,Y52,Y53,Y54,Y55,Y56,Y58";     /* �r�y��YF�M�ץN�� */

    /* ��g�쪺temp table  */
    $select distinct iofficer_ori from ca_promote_officer where iofficer_ori[1,1] in ('W','H','N')
      into temp ca_promote_officer_A with no log;
    $create index ca_promote_A1 on ca_promote_officer_A(iofficer_ori);

    $select distinct iofficer_ori,iprmt from ca_promote_officer where iprmt <> ''
       into temp ca_promote_officer_P with no log;
    $create index ca_promote_P1 on ca_promote_officer_P(iofficer_ori);
    /* ----------------------------------------------------------------------------------- */

    /* �۵M�H��J���P(�Y���N�I�ϥ����T��O�Y��(�����)) add by sylvia 103.10.12 */
    TRADE3022 = 1; /* ���N�I�w�ϥ����T��O�Y��(�����)���,�G�������w  modify by sylvia 105.01.18 */

    $SELECT kPgNum_Line,nForm_File
       INTO $PgLine,$FormFile
       FROM Form
      WHERE ksys_grp="CA" AND kpgmid = 302;

    strcpy(FormFile,rtrim(FormFile));
    sprintf(OutFile,"%s.tx",outputf);
    rgu_init_report(FormFile,OutFile);

    result = getApHome(sApHome);
    if (result < 0)
    {
       printf("read Config file error!!\n");
       return M_CM_READ_CONFIG_ERR;
    }

    /** 980825, �M�ɧ@�~�ಾ�ܦ� ( �`�N�G���@�~�Nlock �Ҧ�302����table ) **/
    if (intopt == 1 ||intopt == 4 )
    {
        rc = clear_ply_last();
				if (rc != M_CM_OK)
				{
				    printf("Trace -- clear_ply_last() ���� \n");
				    return rc;
				}

        /*980825, ��O�J�p�e�A�M�����Ӥ�e����O��� */
				rc = clear_ply_302(itmp_year, itmp_month , -1 );
				if (rc != M_CM_OK)
				{
	    		printf("Trace -- clear_ply_302() ���� \n");
	    		if (rc == -2){
			        sprintf( sTmpMsg, "��O�J�p�@�~�w���_�G\n  �J�p�@�~�Y�N�R��%d�~%d�뤧6�Ӥ�e��O��ơA���P�����O�d�̪�T�Ӥ������ƳW�h�Ĭ�A\n  �нT�{����~��O�_���T\n",iplyyear,iplymonth);
		                rgu_put_body_string(1, rtrim(sTmpMsg), 1);
		                rgu_put_body(1);
							rgu_finish_report();

							FormTp[0] = '\0';
							if(rc=(save_form_info(F_FREE,"CA",302,userid,FormTp,max_count,outputf))<0)
							{
							    printf("*** save_form_info() fail\n");
							}
									return rc;
	    		}else{
	        		return rc;
	    		}
				}
		} /* end (intopt == 1 ||intopt == 4 ) */

    /**********************************************************************/
    if (intopt >= 11 && intopt <= 20)
    {
        /* �M���Ӥ���O�J�p��working table��Ƹ�� */
        if (intopt == 11){
           rc = clear_ply_last();
				   if (rc != M_CM_OK)
				   {
				       printf("Trace -- clear_ply_last() ���� \n");
				       return rc;
				   }
				   sprintf( sTmpMsg, "5 last file deleted \n");

				}else if(intopt == 12 ){
		    /* 980825, �̫��w�~�]�褸�^�B��A�M���Ӥ���O�J�p��� */
	            rc = clear_ply_302(iplyyear, iplymonth , 302 );
				    if (rc != M_CM_OK)
				    {
				        printf("Trace -- clear_ply_302() ���� \n");
				        return rc;
				    }
				    sprintf( sTmpMsg, "ply_302 files deleted(%d_%d) \n",iplyyear,iplymonth);

				}else if(intopt == 13 ){
				    /* 980825, �̫��w�~�]�褸�^�B��A�M���Ӥ���O�J�p���(option in ('1','9') ) */
			            rc = clear_ply_302(iplyyear, iplymonth , 3021 );
				    if (rc != M_CM_OK)
				    {
				        printf("Trace -- clear_ply_302() ���� \n");
				        return rc;
				    }
				    sprintf( sTmpMsg, "ply_302 files deleted(%d_%d)[option in (1,9)] \n",iplyyear,iplymonth);

				}else if(intopt == 14 ){
				    /* 980825, �̫��w�~�]�褸�^�B��A�M���Ӥ���O�J�p���(option=1) */
						rc = clear_ply_302(iplyyear, iplymonth , 3022 );
				    if (rc != M_CM_OK)
				    {
				        printf("Trace -- clear_ply_302() ���� \n");
				        return rc;
				    }
	    		sprintf( sTmpMsg, "ply_302 files deleted(%d_%d)[option = 1] \n",iplyyear,iplymonth);

				}else if(intopt == 15 ){
		    		/* 980825, �̫��w�~�]�褸�^�B��A�M���Ӥ���O�J�p���(option in ('4','9') ) */
	          rc = clear_ply_302(iplyyear, iplymonth , 3023 );
				    if (rc != M_CM_OK)
				    {
				        printf("Trace -- clear_ply_302() ���� \n");
				        return rc;
				    }
				    sprintf( sTmpMsg, "ply_302 files deleted(%d_%d)[option in (4,9)] \n",iplyyear,iplymonth);
				}else if(intopt == 16 ){
	    			/* 980825, �̫��w�~�]�褸�^�B��A�M���Ӥ���O�J�p���(option=4) */
            rc = clear_ply_302(iplyyear, iplymonth , 3024 );
				    if (rc != M_CM_OK)
				    {
				        printf("Trace -- clear_ply_302() ���� \n");
				        return rc;
				    }
				    sprintf( sTmpMsg, "ply_302 files deleted(%d_%d)[option = 4] \n",iplyyear,iplymonth);
				}
        rgu_put_body_string(1, rtrim(sTmpMsg), 1);
        rgu_put_body(1);
        rgu_finish_report();

        FormTp[0] = '\0';
        if(rc=(save_form_info(F_FREE,"CA",302,userid,FormTp,max_count,outputf))<0)
        {
            printf("*** save_form_info() fail\n");
        }
        return M_CM_OK;
    }

    /************************************************************/
    if( intopt == 9) /* �J�ptmepdb���,�G���R�� */
    {
				$DELETE FROM newa00:ca_tmp_no WHERE 1=1;

    		/* 990401,�����J�p�W�[�h����J�覡 */
    		/* 981006,ca_tmp_no ���iengine,�P�ɧ��car302�����W�� */
    		if (sSelect[0]== '0'){

    	    $char *vParam,*chrTest;

			    chrTest = strchr(sfile,';');
			    printf("Trace -- chrTest len = [%d] \n",  strlen(trim(chrTest)));
			    if (chrTest){ /* ����ȥH";"���j => ���ca_tmp_no���H�i�沣�s */
			        vParam = strtok(sfile,";");
							$INSERT INTO newa00:ca_tmp_no values($vParam);
							while(vParam != NULL){
							    vParam = strtok(NULL,";");
						      if (vParam){
							        $INSERT INTO newa00:ca_tmp_no values($vParam);
							    }
							}
			    }else{
			        $INSERT INTO newa00:ca_tmp_no values($sfile);
			    }
    	}else{
		    sprintf( path_DataFile, "%s/dat/car/%s", sApHome,sfile);

		    sprintf(stmt,"load from %s delimiter '\t' insert into newa00:ca_tmp_no; \r\n",
			         path_DataFile);
		    sprintf(syscmd,"dbaccess newa00 2>&1 << !\r\n  %s\r\n!",stmt);

		    rc = system(syscmd);
		    if (rc != 0) {
		        printf("The file %s does not exist!\n",path_DataFile);
						return rc;
		    }
	   	}
    	rc = GetPlyFromEngine(DBName,lDplyEndBgn,lDplyEndEnd,"newa00:ca_tmp_no");
    	if (rc !=M_CM_OK){
			    printf("GetPlyFromEngine() �o�Ϳ��~\n");
			    return rc;
			}

			/* ---   �ܦ��w�Nca_tmp_no �אּ�W�Ǥ�iengine���ݤ��j��Υ��N�O�渹 */
			/* 102.12.25 delete _last�B_302�� �]�]�i��t������B�� ( "....-B")�A�G�n�ϥ� "like" �^*/
			strcpy(ctmp_ipolicy," ");

			/* �R����O���D��T��(car_renew_msg)  add by sylvia 104.07.08 (1040106005_C1) */
      /* �R��ƫe���� */
      $select count(*) into $iCnt_Before
	    	 from sysdb:car_renew_msg a, newa00:ca_tmp_no b
	  		where a.ipolicy = b.ipolicy
	    		and a.dply_end between $lDplyEndBgn and $lDplyEndEnd
          and a.err_no in (select detail2 from car_code where kind = 'RN'
          and detail = 'Mail_To_Leader'
          and engname = 'Y');

			$DECLARE cur_del_tmp CURSOR FOR
        Select ipolicy From newa00:ca_tmp_no ;
        $OPEN cur_del_tmp;
        for(;;)
        {
            $FETCH cur_del_tmp INTO $ctmp_ipolicy;
            if (SQLCODE == SQLNOTFOUND) break;

            strcpy(ctmp_ipolicy,trim(ctmp_ipolicy)) ;
            printf("delete _last�B_302��.... ctmp_ipolicy[%s]\n",ctmp_ipolicy );

            /* delete _last ��*/
            sprintf(stmt, "delete from sysdb:ply_relation_last where ipolicy like '%s%%' ",ctmp_ipolicy );
            $execute immediate $stmt;

            sprintf(stmt, "delete from sysdb:policy_last where ipolicy like '%s%%' ",ctmp_ipolicy );
            $execute immediate $stmt;

            sprintf(stmt, "delete from sysdb:ply_ins_type_last where ipolicy like '%s%%' ",ctmp_ipolicy );
            $execute immediate $stmt;

            sprintf(stmt, "delete from sysdb:ca_pa_ply_last where ipolicy like '%s%%' ",ctmp_ipolicy );
            $execute immediate $stmt;

            sprintf(stmt, "delete from sysdb:ply_ins_cover_last where ipolicy like '%s%%' ",ctmp_ipolicy );
            $execute immediate $stmt;

            /* delete _302 ��*/
            sprintf(stmt, "delete from sysdb:policy_302 where ipolicy like '%s%%' ",ctmp_ipolicy );
            $execute immediate $stmt;

            sprintf(stmt, "delete from sysdb:ply_ins_type_302 where ipolicy like '%s%%' ",ctmp_ipolicy );
            $execute immediate $stmt;

            sprintf(stmt, "delete from sysdb:ca_pa_ply_302 where ipolicy like '%s%%' ",ctmp_ipolicy );
            $execute immediate $stmt;

            /* add by sylvia 114.04.22 (1140409004_C01) */
            sprintf(stmt, "delete from sysdb:ply_ins_assured_302 where ipolicy like '%s%%' ",ctmp_ipolicy );
            $execute immediate $stmt;

            sprintf(stmt, "delete from sysdb:ply_ins_cover_302 where ipolicy like '%s%%' ",ctmp_ipolicy );
            $execute immediate $stmt;

            /* �R����O���D��T��(car_renew_msg)  add by sylvia 104.07.08 (1040106005_C1) */
            sprintf(stmt, "delete from sysdb:car_renew_msg where ipolicy like '%s%%' ",ctmp_ipolicy );
            $execute immediate $stmt;

            /* �R��policy_302f (��O�q����M��) add by sylvia 105.01.18 (1041001006_C1) */
            sprintf(stmt, "delete from sysdb:policy_302f where ipolicy like '%s%%' ",ctmp_ipolicy );
            $execute immediate $stmt;
        }
        $CLOSE cur_del_tmp;
        $FREE  cur_del_tmp;

        /* �R��ƫᵧ�� */
				$select count(*) into $iCnt_After
				   FROM sysdb:car_renew_msg a, newa00:ca_tmp_no b
				  WHERE a.ipolicy = b.ipolicy;
    } /* end ( intopt == 9) */


    /* ���ظg�P����O(8-11��) */
    if (intopt == 55 )
    {
        rc = get_fb_data(); /* ��z��� */

        if (rc != SUCCESS)
        {
            printf("get_fb_data() err ==> %s\n",err_buf);
            return rc;
        }

        /* delete _last ��*/
        $DELETE FROM newa00:ca_tmp_no WHERE 1=1;

        $insert into newa00:ca_tmp_no
         select ipolicy from newa00:estimate_fb
          where dply_end >=$lDplyEndBgn
            and dply_end <=$lDplyEndEnd;

        cnt_prj55 = 0;
        $select count(*) into $cnt_prj55 from newa00:ca_tmp_no where 1=1;
        printf("���ظg�P��=[%d]�� \n",cnt_prj55);

        sprintf(stmt, "delete from sysdb:ply_relation_last where exists \
                       (select ipolicy from newa00:ca_tmp_no where ipolicy = sysdb:ply_relation_last.ipolicy)");
        $execute immediate $stmt;

        sprintf(stmt, "delete from sysdb:policy_last where exists \
                       (select ipolicy from newa00:ca_tmp_no where ipolicy = sysdb:policy_last.ipolicy)");
        $execute immediate $stmt;

        sprintf(stmt, "delete from sysdb:ply_ins_type_last where exists \
                        (select ipolicy from newa00:ca_tmp_no where ipolicy = sysdb:ply_ins_type_last.ipolicy)");
        $execute immediate $stmt;

        sprintf(stmt, "delete from sysdb:ca_pa_ply_last where exists \
                        (select ipolicy from newa00:ca_tmp_no where ipolicy = sysdb:ca_pa_ply_last.ipolicy)");
        $execute immediate $stmt;

        /* delete _302 ��*/
        sprintf(stmt, "delete from sysdb:policy_302 where exists \
                        (select ipolicy from newa00:ca_tmp_no where ipolicy = sysdb:policy_302.ipolicy)");
        $execute immediate $stmt;

        sprintf(stmt, "delete from sysdb:ply_ins_type_302 where exists \
                        (select ipolicy from newa00:ca_tmp_no where ipolicy = sysdb:ply_ins_type_302.ipolicy)");
        $execute immediate $stmt;

        /* add by sylvia 114.04.24 (1140409004_C01) */
        sprintf(stmt, "delete from sysdb:ply_ins_assured_302 where exists \
                        (select ipolicy from newa00:ca_tmp_no where ipolicy = sysdb:ply_ins_assured_302.ipolicy)");
        $execute immediate $stmt;

        sprintf(stmt, "delete from sysdb:ca_pa_ply_302 where exists \
                        (select ipolicy from newa00:ca_tmp_no where ipolicy = sysdb:ca_pa_ply_302.ipolicy)");
        $execute immediate $stmt;

        /* �R����O���D��T��(car_renew_msg)  add by sylvia 104.07.08 (1040106005_C1) */
        sprintf(stmt, "delete from sysdb:car_renew_msg where exists \
                        (select ipolicy from newa00:ca_tmp_no where ipolicy = sysdb:car_renew_msg.ipolicy)");
        $execute immediate $stmt;

        /* �R��policy_302f (��O�q����M��) add by sylvia 105.01.18 (1041001006_C1) */
        sprintf(stmt, "delete from sysdb:policy_302f where exists \
                        (select ipolicy from newa00:ca_tmp_no where ipolicy = sysdb:policy_302f.ipolicy)");
        $execute immediate $stmt;

    } /* end ���ظg�P����O(8-11��) */

    src = car302_build1();
    if (src != M_CM_OK)
    {

     		$WHENEVER SQLERROR GOTO errexit;
        flgMsg =0;
    		/** ����~�T���d�U�� **/
    		$DECLARE log_cur CURSOR FOR
          SELECT ipolicy,iengine,ierr_no,iins_type,message
            INTO $ctmp_ipolicy,$ctmp_iengine,$ctmp_ierrno,$ctmp_iins_type,$ctmp_message
            FROM duplic1
          ORDER BY 1;
        $OPEN log_cur;
        for(;;)
        {
           $FETCH log_cur;
           if (SQLCODE == SQLNOTFOUND) break;

           if (flgMsg==0){
	            sprintf(sTmpMsg,"%s\t %s\t %s\t %s\t %s\t ","�O�渹","������","���~�N�X","�T��1","�T��2");
	            rgu_put_body_string(1, rtrim(sTmpMsg), 1);
	            rgu_put_body(1); max_count++;
	            flgMsg =1;
           }

           sprintf(sTmpMsg,"%s\t %s\t %s\t %s\t %s\t ",ctmp_ipolicy,ctmp_iengine,ctmp_ierrno,ctmp_iins_type,ctmp_message);
           rgu_put_body_string(1, rtrim(sTmpMsg), 1);
           rgu_put_body(1); max_count++;
        }
        $CLOSE log_cur;
        $FREE  log_cur;
        rgu_finish_report();
        FormTp[0] = '\0';

        #ifdef PRINTF_FLAG
        printf("bef save_form_info \n");
        #endif

        if(rc=(save_form_info(F_FREE,"CA",302,userid,FormTp,max_count,outputf))<0)
        {
            printf("*** save_form_info() fail\n");
        }

        goto errexit;
    }

    /* ���׷J�p���G���L���D��, ���N"�ˮ֭�" �ܧ󬰹w�]��(�����\����J�p) */
    /*  ���s "���ե�M���ɮ�" , �n�P�ɲ��s "���ե��ɮ�" */

    /* ���~�T����� --------------------------------------------------------- */
    /* �N���D���Ƽg�J����table (car_renew_msg)   add by sylvia 104.07.08 (1040106005_C1)  */
    /* �ק�޲z�H����W�h modify by 061476 108.06.04 (1080531001_SC1) */

    /* ���q���Jcar302_build1�̭���prepare_reject_client_ply���e*/
    /* modify by 071004 */
    /*sprintf(stmt,
        "insert into sysdb:car_renew_msg \
         select a.ipolicy, nvl(f.itag,' '), nvl(f.iengine,' '), f.iassured, f.nassured, \
                a.icar_type, a.dply_end, e.nbranch, d.ileader, d.nname, \
                a.iofficer, c.nname, f.iroute, b.nroute, nvl(f.iabn_type,' '), 'E', \
                '�L�k��O�J�p', g.ierr_no, nvl(trim(g.iins_type)||' '||trim(g.message),' '), \
                'N', nvl(decode(a.iofficer[1,1],'J',ibig_sales,'B',ibig_sales,' '),' '), \
                case when a.iofficer[1,1] in ('B','J') then \
                     nvl((select nname from ca_big_office where fclass = '2' \
                             and ibig_comp = a.ibig_sales),' ') else ' ' end, \
                '%s',current \
           FROM ply_relation_last a, cm_route b , officer c, officer d, \
                sa_branch_type e, policy_last f, duplic1 g \
          WHERE a.iofficer = c.iofficer  AND c.ileader = d.iofficer \
            AND f.iroute = b.iroute  AND a.iquota = e.ibranch \
            AND a.ipolicy = f.ipolicy  and a.ipolicy = g.ipolicy ", userid);

    $PREPARE pre_ermsg FROM $stmt;*/

    if( intopt == 1 )
    {

        if (intopt==1){  /* �U�b��έ��Ψ�L */
            tmp_intopt = 0;
				}else{
            tmp_intopt = 10;  /* �W�b��έ�� */
        }

        /* --------------- */
        /* $UPDATE STATISTICS FOR TABLE ply_ins_cover_302;
			    	$UPDATE STATISTICS FOR TABLE ply_ins_type_302;
			    	$UPDATE STATISTICS FOR TABLE ca_pa_ply_302;
			    	$UPDATE STATISTICS FOR TABLE policy_302; */
				/* --------------- */

        /* 102.03 ���s"���ե�" */
        rc = gen_test2_list(iplyyear,iplymonth,DBName,userid,ipgid,intopt,2);
				if (rc != 1)
				{
				    printf("gen_test2_list() ���s���ե�M�楢�� !\n");
				    /*$EXECUTE pre_ermsg;*/
				    return rc;
				}
				else
				{
				    tmp_intopt = 98; /* �g��car302 ���s���ե� �]from newa00:ca_tmp_no�^ */

				    sprintf(outputf1,"p32_%d_2p_2",iplymonth);
				    sprintf(outputf2,"p32_ins_%d_2p_2",iplymonth);
			            rc=p32_print_1("1",iplyyear,iplymonth,outputf1,outputf2,outputf,userid,DBName,ipgid,tmp_intopt,"100000000000000111000000000000");
				    if (rc != 1)
				    {
				        printf("p32_print_1() ���s2p���ե��ɮץ���_2 !\n");
				        /*$EXECUTE pre_ermsg;*/
				        return  rc;
				    }

			            sprintf(outputf1,"p32_%d_5p_2",iplymonth);
				    sprintf(outputf2,"p32_ins_%d_5p_2",iplymonth);

			            rc=p32_print_1("2",iplyyear,iplymonth,outputf1,outputf2,outputf,userid,DBName,ipgid,tmp_intopt,"100001001100000000000000000000");
				    if (rc != 1)
				    {
				        printf("p32_print_1() ���s5p���ե��ɮץ���_2 !\n");
				        /*$EXECUTE pre_ermsg;*/
				        return  rc;
				    }
        }

        /*---------------- ---      ���sbarcode�������    -------------------- ------ */
				/*  ca3025_barcode (�D���Ӿ�����j)  */
        sprintf(outputf10,"p32_%d_barcode",iplymonth);
        sprintf(outputf12,"p32_ins_%d_barcode",iplymonth);
        rc=ca3025_barcode(iplyyear,iplymonth,userid,outputf10,outputf12,"car302T","MOT00");
        if (rc != 1){
            printf("---> ca3025_barcode (MOT00) error \n");
        }

        /*  ca3025_barcode (�D���ӨT����j)  */
				rc=ca3025_barcode(iplyyear,iplymonth,userid,outputf10,outputf12,"car302T","CAR00");
        if (rc != 1){
            printf("---> ca3025_barcode (CAR00) error \n");
        }

        /*  ca3025_barcode (�q�ʦۦ樮)  */
				rc=ca3025_barcode(iplyyear,iplymonth,userid,outputf10,outputf12,"car302T","EB00");
        if (rc != 1){
            printf("---> ca3025_barcode (CAR00) error \n");
        }

        /*  ca3025_barcode (car147�]�w���q�� (�Ȧ�Btpl barcode�B�����㨮���ѡB ......))  */
        if (fBarcode_setup == 'Y'){
     	  		rc=ca3025_barcode(iplyyear,iplymonth,userid,outputf10,outputf12,"car302T"," ");
            if (rc != 1){
                printf("---> ca3025_barcode error \n");
            }
        }

        /* �s�W�۩l���J�p���� (1110915007_SC1) */
        rc=ca3025_chk_total(iplyyear,iplymonth,userid,"car302T");
        if (rc != 1){
            printf("---> ca3025_chk_total error \n");
        }

        /*$EXECUTE pre_ermsg;*/
        /*----------------------------------------------------------------------------- */
        /* 102.03 ,�J�p�����A�s�W�Ӧ~�뤧"��O��Ʊ���" �}�� -------*/
				$char tmp_col[21],tmp_value[41];

        $select first 1 to_char(current,'%m/%d/%Y %H:%M:%S') into $tmp_col from systables;
        strcpy(tmp_value,userid); strcat(tmp_value,";");  strcat(tmp_value,tmp_col);

        /* �Y�Ӧ~��]�w�Ȥw�s�b�A�h�R���A�A�s�W*/
				rc = do_car_code('Q',"RN","car302",ply_ym," "," ",3,userid);
        if (rc == 1){
    	    rc = do_car_code('D',"RN","car302",ply_ym," "," ",3,userid);
        }
				rc = do_car_code('A',"RN","car302",ply_ym,"N",tmp_value,0,userid);

        /*------------   �M�����Ӥ�e������]�w���    ------------*/

        sprintf(ply_ym,"%d%02d",(itmp_year-1911),itmp_month);
				rc = do_car_code('D',"RN","car302",ply_ym," "," ",3,userid);

				/*---------------------------------------------------------*/

  			printf("Trace -- ply_302_key() 2 \n" );
        rc = ply_302_key(1, "car302a", "A", "0",userid);
        rc = ply_302_key(1, "car302b", "A", "0",userid);
        rc = ply_302_key(1, "car302a", "B", "0",userid);
        rc = ply_302_key(1, "car302a", "C", "0",userid);
        /* �j���I�����~���u�f���B�վ㰱��car159t�{�� mark by 061476 110.01.25 (1100118005_SC3) */
        /*rc = ply_302_key(1, "car302a", "D", "0",userid);*/   /* ��O�j���I�~���ˮ�(car159) add by sylvia 104.04.23 (1040312001_C1) */
        rc = ply_302_key(1, "car302a", "E", "0",userid);   /* RBA�����I�ˮ� add by sylvia 106.08.15 (1060606002_C5) */
    }
    else
    {
        /***********************************************/
        /*$EXECUTE pre_ermsg;*/
        printf("end insert car_renew_msg\n");
    }

    free(ca_chg_sale);
    free(ca_chg_office);
    free(ca_chg_dc);
    free(ply_302_update);
    /***********************************************/
    time(&tstop);  /* �p�ɵ��� */
    tused=difftime(tstop, tstart);
    printf("������� = %f  ��\n", tused);
    /***********************************************/

    return M_CM_OK;

errexit:
    printf("--878: car302 main err: [%d] \n", SQLCODE);
    printf("------car302_err: ErrMsg[%d]\n",src);
    /* EWRITE(userid, SQLCODE,sqlca.sqlerrm); */
    exit(1);
}

long car302_build1()
{
    $int     PgLine,t_count;
    $char    FullDBName[20],TpDBName[20];
    $char    stmt_buf[8192],buf1[2000];
    $char    t_iquota[7];
    $char    tmp_fcard_class[2],prt[2],office[10];
    $date    tmp_dply_end;
    long     rtncode;
    int      count;
    int      rc;
    $int     big_cnt;
    long     i;
    $char    plyYYMM[6];
    $char    sIclass[3];
    $char    sIbig_sales[11];
    $char    sOri_iofficer[11];
    $char    sNew_iofficer[11];
    $char    update_ipolicy[21];
    $char    update_iofficer[11];
    $char    update_ibig_sales[11];
    $char    update_note[3];
    $char    SelectEquip[900];
    $char    tmp_YYMM[6];
    $int     tmp_iym_end;
    $char    xBranch[3];
    $char    sfpart[2],tmp_iroute1[21],tmp_iroute2[21],tmp_iofficer[11];
    $char    siacc_reason[3];
    char     last_iengine_pre[CA_ENGINE_NUM]="";
    $long    chk_mdamage_cover;
    $int     ply_end_month;
    $char    chk_iofficer[11],ipolicy_msg[21],iofficer_msg[11];
    $char    nofficer_msg[11],ileader_msg[11],nleader_msg[11],nbranch_msg[41];
    strcpy(tmp_YYMM,trim(plyyear));

    if ((atoi(plymonth) >= 1) && (atoi(plymonth) <= 9)){
         strcat(tmp_YYMM, "0");
         strcat(tmp_YYMM, trim(plymonth));
    }else{
         strcat(tmp_YYMM, trim(plymonth));
    }

    tmp_iym_end=atoi(tmp_YYMM);
    tmp_iym_end2 = tmp_iym_end;
    #ifdef PRINTF_FLAG
    printf("tmp_iym_end[%d]\n",tmp_iym_end);
    #endif

    strcpy(plyYYMM, trim(tmp_YYMM));

    #ifdef PRINTF_FLAG
    printf("plyYYMM[%s]\n",plyYYMM);
    #endif

    /* use form: car302.fmt => ����:150 �r�� */
    /* ������s�ܼơG sTmpMsg[131],ctmp_ipolicy[21],ctmp_iins_type[11],ctmp_iengine[21],ctmp_message[71]*/
    /* �s�W ���~�N�X ��� add by sylvia 104.07.08 (1040106005_C1) */
    /* �s�W �g��N�� ��� add by 071004 (1110325004_SC1)*/
    $CREATE TEMP TABLE duplic1(
        ipolicy       char(20),
        iengine       char(25),
        iins_type     char(10),
        message       char(120),
        delkind       char(1),
        ierr_no       char(3),	-- ���~�N�X
        iofficer      char(10)
    )WITH NO LOG;

    $CREATE INDEX dup_ix1 ON duplic1 (ipolicy);
    $CREATE INDEX dup_ix2 ON duplic1 (ipolicy,delkind);
    $CREATE INDEX dup_ix3 ON duplic1 (ierr_no);

    /* ���N�I���J�p,�j���I�]���J�p add by sylvia 105.07.15 (1050302003_C1) */
    $create temp table tp_relply (
        ipolicy         char(20),
        irelative_ply   char(20),
        iassured        char(12)
    ) with no log;
    $CREATE INDEX tp_relply_idx1 ON tp_relply(ipolicy,iassured);

    /* �����j���I���p���ť�, �d���p�O�渹(47��ĳ�W�h�ק�) add by sylvia 105.07.18 (1050704006_C1) */
    $create temp table wk_policy_302 (
        ipolicy_c       char(20),
        ipolicy_v       char(20),
        dply_end        char(12)
    ) with no log;
    $CREATE INDEX wk_idx1 ON wk_policy_302(ipolicy_c);

    /* �T���j���I���p���ť�, �d���p�O�渹(50/149��ĳ�W�h�ק�) add by 061476 108.08.21 (1080710001_SC1) */
    $create temp table wk_policy_302_50 (
        ipolicy_c       char(20),
        ipolicy_v       char(20),
        dply_end        char(12)
    ) with no log;
    $CREATE INDEX wk_50_idx1 ON wk_policy_302_50(ipolicy_c);


    /* �r�V�Z��X�I�W�U���~�� (�P�p��L��,�G�u��Temp Table) add by sylvia 114.04.24 (1140409004_C01) */
    /* $select * from sysdb:ply_ins_assured_302 where 1=0 into temp ply_ins_assured_last with no log;
    $create index ply_ins_assured_last_x1 on ply_ins_assured_last (ipolicy) ; */

    /* 970219, car147�]�w���q��barcode */
    rc = prepare_barcode_ioff(iplyyear,iplymonth);

    if (rc==M_CM_OK){
    	fBarcode_setup = 'Y'; /* ���ܸ���O�~���barcode�]�w�ɥ]�t���Ī��]�w���M�� */
		              /* �P��tmp_barcode_officer�w��J�Ҧ��ŦX�]�w���󤧸g��N�� */
    }else{
    	if (rc!=-1){
    		printf(" prepare_barcode_ioff-- rc = [%d]\n " , rc);
    		return rc;
    	}
    	fBarcode_setup = 'N';
    }

    /* 980616 */
    rc = no_barcode_list();	 /* ����barcode, �u����O�q����+�q���� */
    if (rc != M_CM_OK)   return rc;

    /* 101.10 �A�]��tpl barcode, ���o�i��O50�I�ؤ����� */
    rc = get_ins50_car_type(iplyyear,iplymonth);
    if (rc != M_CM_OK)   return rc;

    /* 991019,�]�w��cus101,���O�GC7 */
    /* ���צ�سW�h�ɭP���L��O�q����(�q�`�O���Lbarcode��)�A���B�M�欰�@�߶��L��O�q���� */
    rc = Force_Print_302_list();
    if (rc != M_CM_OK)   return rc;

    /* 980311,��h�W�A��O�J�p�H�Ө������ҥΦP�@�ӶO�v�N���A����ڤW�O�v�N������ܥi����"��"       */
    /* �Y�n�����Ө��o�O�v�N���A�h������ Get302Data() ��������O��j�餤�v�O��̨����P�_��
       �]lDplyEndBgn ����������1��, Ex. 980501�B980601 �^ */
    printf(" ------- lDplyEndBgn = [%ld]\n " , lDplyEndBgn);

    /* �j���I��O�O�v�N�� */
    $SELECT icode
       INTO $tmp_frate1
       FROM ca_rate_renew
      WHERE deffect_bgn <= $lDplyEndBgn
        AND deffect_end >= $lDplyEndBgn
        AND fcard_class = '1';
    if (SQLCODE == SQLNOTFOUND)
    {
       sprintf( err_buf, "�j���I��O�O�v�ͮĦ~��[%d] not in ca_rate_renew", tmp_iym_end);
       EWRITE(userid,M_CA_NRATE_DATE, err_buf);
       return M_CA_NRATE_DATE;
    }

    strcpy(tmp_frate1,trim(tmp_frate1));

    /* ���N�I��O�O�v�N�� */
    $SELECT icode
       INTO $tmp_frate2
       FROM ca_rate_renew
      WHERE deffect_bgn <= $lDplyEndBgn
        AND deffect_end >= $lDplyEndBgn
        AND fcard_class = '2';
    if (SQLCODE == SQLNOTFOUND)
    {
       sprintf( err_buf, "���N�I��O�O�v�ͮĦ~��[%d] not in ca_rate_renew", tmp_iym_end);
       EWRITE(userid, M_CA_NRATE_DATE, err_buf);
       return M_CA_NRATE_DATE;
    }

    strcpy(tmp_frate2,trim(tmp_frate2));

    /* ���������Y�ư򥻫O�B   */
    $select min(car_price_bgn)  into $iBasePrice
       from car_price_factor
      where pcar_price > 1
        and drate = (select drate from ca_rate_date where icode = $tmp_frate2
                        and itable = 'car_price_factor');

		/* 101.01.10 �t�P�����ɷs�W���Τ�ΥN�X�ܧ�  */
		/* �N���ܧ󪺼t�P�����N�����^����tmp_ibrand */
		/* �� AND (dexpire is NOT null OR dexpire <= today)  �אּ==> AND (dexpire is NOT null AND dexpire <= today)*/
		$SELECT DISTINCT ibrand,ibrand_new
		   FROM ca_car_model
		  WHERE  drate=(SELECT drate FROM ca_rate_date
		                WHERE icode  =$tmp_frate2 AND itable = 'ca_car_model')
		    AND (dexpire is NOT null AND dexpire <= today)
		   INTO temp tmp_ibrand WITH NO log;

    /* 981208, ���o�j���I�B�ˮ`�I(47�B50�B48�B147)�O�B ���U�۫O�B (���Ҽ{����)
               �j���I:injured_cover_comp�Bdeath_cover_comp�Bdamage_cover_comp
               �ˮ`�I:injured_cover_pa_xx�Bdeath_cover_pa_xx�Bdamage_cover_pa_xx (�䤤xx���I�إN�X�G47�B50�B48�B147)   */
    rc = get_comp_pa_cover(tmp_frate1,tmp_frate2);
    if (rc != M_CM_OK)   return rc;

    /* 97.11�J�O�v�ۥѤ� */
    strcpy(f980101,"1");

    /* �P�_47�I�جO�_�A�ηs��k */
    strcpy(f1030601,"1");  /* �O�v�ͮĤ馭�w�W�L103/06/01,�������w1  modify by sylvia 106.03.16 */


    /* 960110, ���o�O�O�p��һݤ������Y���ɨæs�� struct  �]for ���ХH�~�^ */
    rc = Get_Data_For_Cal_ins_prem_302(tmp_iym_end,userid);
    if (rc != M_CM_OK) goto errexit;

    #ifdef PRINTF_FLAG
    printf("tmp_frate1[%s]\n",tmp_frate1);
    printf("tmp_frate2[%s]\n",tmp_frate2);
    #endif


    /***  �إ� plyAB_chk  ****/
    $CREATE TEMP TABLE plyAB_chk
    (
        Aipolicy   char(20),
        Bipolicy   char(20),
        Biofficer  char(10),
        nequ_name  char(20),
        nequ_comp  char(10),
        nequ_prem  integer,
        BPlyClosed integer default 0,  -- /* 0:no->B��M�ש|������ ; 1:yes->B��M�׵��� */
        remark_yn  integer default 0,  -- /* 0:�b�Ƶ���C�L ; 1:�Q�α���X�Ѽt�ӦC�L */
        iprmt     char(3)              -- /* �M�ץN�� */
    ) WITH NO LOG;

    /* 960628,���]���@�iA������h��B��*/
    $CREATE UNIQUE INDEX plyAB_chk_ix2 ON plyAB_chk( Bipolicy );
    $CREATE  INDEX plyAB_chk_ix1 ON plyAB_chk( Aipolicy );

    /* ���q�O�N�~�N�ξ��I��:�ثe���w���u�o�󴫦P���I���~�N , car329 */
    /* note:1.�~�N�� */
    /* note:2.���I�� */
    /* note:3.�~�N�ξ��I�� */
    /* �C������A ply_302_update �|�u�O�d�����2�Ӥ뤺�����*/

    sprintf(stmt, "SELECT month(dply_end) FROM ca_ply_period WHERE ipolicy = ?");
    $PREPARE pre_ply_end FROM $stmt;

    i = 0;
    max_ply_302_update = 0;
    sprintf(stmt,"SELECT %s FROM %s WHERE %s ",
                 "ipolicy, iofficer, ibig_sales, note ",
                 "ply_302_update",
                 "note = '1' AND dupdate>=(today-30) ");
    $PREPARE ply_update_curTmp FROM $stmt;
    $DECLARE ply_update_cur CURSOR FOR ply_update_curTmp;
    $OPEN    ply_update_cur;
    for(;;)
    {
         $FETCH ply_update_cur INTO $update_ipolicy,$update_iofficer,$update_ibig_sales,$update_note;
         if (SQLCODE==SQLNOTFOUND) break;
         ply_end_month = 0;
         $EXECUTE pre_ply_end Into $ply_end_month Using $update_ipolicy;
         if (ply_end_month != iplymonth) continue;

         ply_302_update=(struct ply_302_update_t *) realloc (ply_302_update,(i+1) * sizeof(struct ply_302_update_t));

         strcpy(ply_302_update[i].ipolicy    , trim(update_ipolicy));
         strcpy(ply_302_update[i].iofficer   , trim(update_iofficer));
         strcpy(ply_302_update[i].ibig_sales , trim(update_ibig_sales));
         strcpy(ply_302_update[i].note       , trim(update_note));
         i++;
    }
    $CLOSE   ply_update_cur;
    $FREE    ply_update_cur;
    max_ply_302_update = i;

    i             = 0;
    maxcount_sale = 0;

    /* 990121,fix  */
    printf("Trace -- plyYYMM = [%s] \n",  plyYYMM);
    printf("Trace -- tmp_iym_end = [%d] \n",  tmp_iym_end);

    /* �~�N�N���ഫ ,car139 */
    sprintf(stmt,"SELECT %s FROM %s WHERE %s %s %s %s",
                 "iclass, ibig_sales, ori_iofficer, new_iofficer ",
                 "ca_change_office " ,
                 "iclass = '2' ",
                 "AND plybgn_yymm::integer <= ? ",
                 "AND plyend_yymm::integer >= ? ",
                 "ORDER BY ibig_sales ");
    $PREPARE AcursorTmp FROM :stmt;
    $DECLARE Acursor CURSOR FOR AcursorTmp;
    $OPEN    Acursor USING :tmp_iym_end, :tmp_iym_end;
    #ifdef PRINTF_FLAG
    printf("stmt[%s]\n",stmt);
    printf("Trace -- �~�N�N���ഫ ,car139 \n");
    #endif
    for(;;)
    {
       $FETCH Acursor INTO $sIclass, $sIbig_sales, $sOri_iofficer, $sNew_iofficer;
       if (SQLCODE == SQLNOTFOUND) break;

       #ifdef PRINTF_FLAG
       printf("[%s][%s][%s][%s]\n",sIclass,sIbig_sales,sOri_iofficer,sNew_iofficer);
       #endif

       /* the following block is modified by paili */
       ca_chg_sale=(struct ca_chk_sale_t *) realloc (ca_chg_sale,(i+1) * sizeof(struct ca_chg_sale_t));

       strcpy(ca_chg_sale[i].iclass       , trim(sIclass));
       strcpy(ca_chg_sale[i].ibig_sales   , trim(sIbig_sales));
       strcpy(ca_chg_sale[i].ori_iofficer , trim(sOri_iofficer));
       strcpy(ca_chg_sale[i].new_iofficer , trim(sNew_iofficer));
       i++;
    }
    $CLOSE Acursor;

    maxcount_sale   = i;
    #ifdef PRINTF_FLAG
    printf("maxcount_sale[%ld]\n",maxcount_sale);
    #endif

    i               = 0;
    maxcount_office = 0;
    /* �g��N���ഫ ,car139 */
    /* ���O3���@���g��N��,�t�X�e���S�ʤO��O�~�ȸg��N���󥿡f�ݨD�ӷs�W�C modify by sylvia 104.06.03 (1040528003_C1) */
    sprintf(stmt,"SELECT %s FROM %s WHERE %s %s %s %s",
                 "iclass, ibig_sales, ori_iofficer, new_iofficer ",
                 "ca_change_office " ,
                 "iclass in('1','3') ",
                 "AND plybgn_yymm::integer <= ? ",
                 "AND plyend_yymm::integer >= ? ",
                 "ORDER BY ibig_sales ");
    $PREPARE AcursorTmp2 FROM :stmt;
    $DECLARE Acursor2 CURSOR FOR AcursorTmp2;
    $OPEN    Acursor2 USING :tmp_iym_end, :tmp_iym_end;
    #ifdef PRINTF_FLAG
    printf("stmt[%s]\n",stmt);
    printf("Trace -- �g��N���ഫ ,car139 \n");
    #endif

    for(;;)
    {
       $FETCH Acursor2 INTO $sIclass, $sIbig_sales, $sOri_iofficer, $sNew_iofficer;
       if (SQLCODE == SQLNOTFOUND) break;
       #ifdef PRINTF_FLAG
       printf("[%s][%s][%s][%s]\n",sIclass,sIbig_sales,sOri_iofficer,sNew_iofficer);
       #endif
       /* the following block is modified by paili */
       ca_chg_office=(struct ca_chk_sale_t *) realloc (ca_chg_office,(i+1) * sizeof(struct ca_chg_sale_t));

       strcpy(ca_chg_office[i].iclass       , trim(sIclass));
       strcpy(ca_chg_office[i].ibig_sales   , trim(sIbig_sales));
       strcpy(ca_chg_office[i].ori_iofficer , trim(sOri_iofficer));
       strcpy(ca_chg_office[i].new_iofficer , trim(sNew_iofficer));
       i++;
    }
    $CLOSE Acursor2;

    maxcount_office = i;
    #ifdef PRINTF_FLAG
    printf("maxcount_office[%ld]\n",maxcount_office);
    #endif

    strcpy(db,"00");

    #ifdef PRINTF_FLAG
    printf("before sPrepare\n");
    #endif
    rc = sPrepare(); /*  ��z���   policy -> policy_last  */
    if (rc != TRUE){
        #ifdef PRINTF_FLAG
        printf("sPrepare() FALSE \n");
        #endif
        goto errexit ;
    }

    /* �g��N���w������,�H�̷s�O��Ҹ��g��N���J�p,�����ഫ,�������ܰT�� add by sylvia 106.04.05 (1060324001_C1) */
    if( intopt == 9)
    {
        $insert into duplic1
         select a.ipolicy, c.iengine, ' ', '�O��g��N���w������,�H�O��Ҹ��g��i����O�J�p','2','W02',b.iofficer
           from sysdb:ca_dc_change a, sysdb:ply_relation_last b, sysdb:policy_last c, newa00:ca_tmp_no d
          where a.ipolicy = d.ipolicy and b.ipolicy = d.ipolicy
            and a.ipolicy = b.ipolicy and a.ipolicy = c.ipolicy and b.ipolicy = c.ipolicy
            and a.iofficer_ori <> b.iofficer;
    }
    else
    {
        $insert into duplic1
         select a.ipolicy, c.iengine, ' ', '�O��g��N���w������,�H�O��Ҹ��g��i����O�J�p','2','W02',b.iofficer
           from sysdb:ca_dc_change a, sysdb:ply_relation_last b, sysdb:policy_last c
          where a.ipolicy = b.ipolicy and a.ipolicy = c.ipolicy and b.ipolicy = c.ipolicy
            and a.iofficer_ori <> b.iofficer;
    }


    /* ���������~��(ca_dc_change) add by sylvia 106.04.05 (1060324001_C1) */
    i=0; maxcount_dc = 0;

    sprintf(stmt,"select a.ipolicy, a.iofficer_ori, a.iofficer_new \
                    from sysdb:ca_dc_change a, sysdb:ply_relation_last b \
                   where a.ipolicy = b.ipolicy and a.iofficer_ori = b.iofficer ");
    $PREPARE pre_dccursor FROM :stmt;
    $DECLARE dc_cursor CURSOR FOR pre_dccursor;
    $OPEN    dc_cursor ;
    for(;;)
    {
       $FETCH dc_cursor INTO $ipolicy, $sOri_iofficer, $sNew_iofficer;
       if (SQLCODE == SQLNOTFOUND) break;

       /* the following block is modified by paili */
       ca_chg_dc =(struct ca_chg_dc_t *) realloc (ca_chg_dc,(i+1) * sizeof(struct ca_chg_dc_t));

       strcpy(ca_chg_dc[i].ipolicy       , trim(ipolicy));
       strcpy(ca_chg_dc[i].iofficer_ori   , trim(sOri_iofficer));
       strcpy(ca_chg_dc[i].iofficer_new , trim(sNew_iofficer));
       i++;
    }
    $CLOSE dc_cursor;
    maxcount_dc   = i;


    /* �P�_cmn518�O�_�������I��a������ add by sylvia 105.02.25 (1050105008_C4) */
    $select count(nmember)
       into $chk518
       from cm_risk_member
      where itype = '3'
        and dupdate >= (select min(dpolicy) from ply_relation_last)
     �@ and dupdate <= today;

    /* �j���I�����~�ȧ����B add by sylvia 105.08.19 (1050812001_C1) */
    /* �j���I�����~���u�f���B�վ� mark by 061476 110.01.20 (1100118005_SC3) */
    /*i=0;
    $DECLARE cur_cdiscount CURSOR FOR
         Select detail2 From car_code where kind = 'CD' order by detail ;
    $OPEN cur_cdiscount;
    for(;;)
    {
        $FETCH cur_cdiscount INTO $cdiscount[i];
        if (SQLCODE == SQLNOTFOUND) break;
        i++;
    }
    $CLOSE cur_cdiscount;
    $FREE cur_cdiscount;*/

    sprintf(stmt,"SELECT %s FROM %s WHERE %s",
                 " fins_grp ",
                 " reject_policy ",
                 " ipolicy = ? ");
    $PREPARE fins1 FROM $stmt;
    $DECLARE fins_cur CURSOR FOR fins1;

    /** for �ذe�ѵs�I�M��(2�~�H�W) **/
    /* �s�W�֪@�M�׸g��(FS) add by sylvia 103.04.17 (1020704005_C3) */
    /* �s�WN�g����� add by sylvia 1030.09.01 (1030630002_C1) */
    /* �qca_promote_officer_A�T�{�O�_���M��N�g��  */
    strcpy(NTmpSQL," or (Biofficer in (select iofficer_ori from ca_promote_officer_A where iofficer_ori[1,1] = 'N'))");

    /* �s�W�鲣66����(�g��YS,���O93,�M�ץN��Y59) add by sylvia 103.09.03 */
    /* "         and Biofficer[7,9] not in ('YFB','YFC','YF6')) %s)",NTmpSQL); */
    sprintf(stmt,"SELECT Aipolicy, nequ_name, nequ_comp, nequ_prem, Biofficer, BPlyClosed, remark_yn, iprmt "
                 "  FROM plyAB_chk "
                 " WHERE Aipolicy = ? "
                 "   AND ((    (Biofficer[7,8] in ('LE','LS','YF','YG','YI','RL','FW','DF','HF','BF','NF','TB','FS','YS') "
                 "          OR (Biofficer[7,9] in ('YCF','YL9','YL5','FWD','EM6','EM5','FWD','YFS','YJ1','ES1','YFL','YFN')) "
                 "          OR Biofficer[7,10] in ('ES01','YS66') "
                 "          OR (Biofficer matches 'W*555*') "
                 "          OR (Biofficer matches 'L*B')) "
                 "         and Biofficer[7,9] not in ('YFB','YFC')) %s)",NTmpSQL);

    $PREPARE plychk1 FROM $stmt;
    #ifdef PRINTF_FLAG
    printf("plychk1[%s]\n", stmt);
    #endif

    /* 102.12.25 �s�W�HB��O�渹����*/
    /** for �ذe�ѵs�I�M��(2�~�H�W) **/
    /* �s�W�֪@�M�׸g��(FS) add by sylvia 103.04.17 (1020704005_C3) */
    /* "         and Biofficer[7,9] not in ('YFB','YFC','YF6')) %s)",NTmpSQL); */
    /* �s�W���M�M�� add by 061476 108.12.16 (1081018008_SC1) */
    sprintf(stmt,"SELECT first 1 Bipolicy, nequ_name, nequ_comp, nequ_prem, Biofficer, BPlyClosed, remark_yn, iprmt "
                 "  FROM plyAB_chk"
                 " WHERE Bipolicy = ?"
                 "   AND ((    (Biofficer[7,8] in ('LE','LS','YF','YG','YI','RL','FW','DF','HF','BF','NF','TB','FS','YS') "
                 "          OR (Biofficer[7,9] in ('YCF','YL9','YL5','FWD','EM6','EM5','FWD','YFS','YJ1','ES1','YFL','YFN')) "
                 "          OR Biofficer[7,10] in ('ES01','YS66') "
                 "          OR (Biofficer matches 'W*555*') "
                 "          OR (Biofficer matches 'L*B')) "
                 "         and Biofficer[7,9] not in ('YFB','YFC')) %s)",NTmpSQL);

    $PREPARE plychk1_b FROM $stmt;
    #ifdef PRINTF_FLAG
    printf("plychk1_b[%s]\n", stmt);
    #endif

    /* 103.09.03 �P�\���T�{,�U�C�M�פw����,�G���[�JN�g��P�_  add by sylvia 103.09.03 --------------------------------------------- */
    /* 970102, ���p1519�M(AHL)  => �ηs�A���M�w����,�������N */
    /* 990319, �W�ߤA���M�� + �W��DLR50�M�� */
    /* 990319, �έ�A���M�� + �έ�DLR50�M�� */
    sprintf(stmt,"SELECT Aipolicy, nequ_name, nequ_comp, nequ_prem, Biofficer, BPlyClosed, remark_yn, iprmt "
                 "  FROM plyAB_chk"
                 " WHERE Aipolicy = ?"
                 "   AND (Biofficer[7,8] in ('UC','UF') Or Biofficer[7,9] in ('AHL','YF6','YFC','YFB'))");
    $PREPARE plychk2_1 FROM $stmt;
    #ifdef PRINTF_FLAG
    printf("plychk2_1[%s]\n", stmt);
    #endif

    /* 102.12.25 �s�W�HB��O�渹����*/
    sprintf(stmt,"SELECT first 1 Bipolicy, nequ_name, nequ_comp, nequ_prem, Biofficer, BPlyClosed, remark_yn,iprmt "
                 "  FROM plyAB_chk"
                 " WHERE Bipolicy = ?"
                 "   AND (Biofficer[7,8] in ('UC','UF') Or Biofficer[7,9] in ('AHL','YF6','YFC','YFB'))");
    $PREPARE plychk2_1_b FROM $stmt;
    #ifdef PRINTF_FLAG
    printf("plychk2_1_b[%s]\n", stmt);
    #endif

   /* �W�C�M�פw����  add by sylvia 103.09.03 ------------------------------------------------------------------- */

    #ifdef PRINTF_FLAG
    printf("1.----- plyyear[%s] plymonth[%s]\n",plyyear,plymonth);
    #endif

    sprintf(stmt, "SELECT %s FROM %s WHERE %s %s",
                  " iseq,dclaim,dprocess,drescue,nvl(qday,' ') ",
                  " ca_ply_service ",
                  " ipolicy = ? ",
                  " ORDER BY 1 ");
    $PREPARE clmid FROM $stmt;
    $DECLARE clm_cur CURSOR FOR clmid;


    sprintf(stmt, "SELECT mdamage_cover FROM ply_ins_type_last WHERE ipolicy = ? AND iins_type='21'");
    $PREPARE pre_chk FROM $stmt;

    /* 100.01.04, ���qSQL��ca3xxlib.ec �p��71�I�ت��[C���ڨϥ� */
    /* P�BQ���ڦ@�Φ��qSQL (1071226006_SC3) */
    /* SQL�s�Wmexpense��K���ڨϥ� (1080408008_SC3) */
    sprintf(stmt, "SELECT coefficient FROM ca_add_provision \n\
                    WHERE icar_type = ? \n\
                      AND iins_type = ? \n\
                      AND provision = ? \n\
                      AND mexpense  = ? \n\
                      AND drate     = (SELECT drate \n\
                                         FROM ca_rate_date \n\
                                        WHERE icode  = ? \n\
                                          AND itable = 'ca_add_provision') ");
    $PREPARE pre_ca_add_prov FROM $stmt;

    /* 100.01.13,���o86�I����O���̳̰��O�B  */
    /* �t�X86�I�ثO�O�p��覡�վ�, �s�Wmcoverage1���� modify by sylvia 104.06.11 (1040525002_C3) */
     sprintf(stmt, "SELECT nvl(max(mcoverage2),0) \n\
                             FROM cover_vs_premium \n\
                      WHERE iins_type  = ? \n\
                              AND icar_type  = ? \n\
                              AND mcoverage1  = ? \n\
                              AND mcoverage2 <= ? \n\
                              AND mdeduct    = ? \n\
                              AND drate=(SELECT drate \n\
                                           FROM ca_rate_date \n\
                                          WHERE icode  = ? \n\
                                            AND itable = 'cover_vs_premium') ");

    $PREPARE pre_get_max_cover2 FROM $stmt;

    sprintf(stmt, "SELECT nvl(min(mcoverage2),0) \n\
                             FROM cover_vs_premium \n\
                      WHERE iins_type  = ? \n\
                              AND icar_type  = ? \n\
                              AND mcoverage1  = ? \n\
                              AND mdeduct    = ? \n\
                              AND drate=(SELECT drate \n\
                                           FROM ca_rate_date \n\
                                          WHERE icode  = ? \n\
                                            AND itable = 'cover_vs_premium') ");

    $PREPARE pre_get_min_cover2 FROM $stmt;

    sprintf(stmt, "SELECT pcomp_factor \n\
                     FROM ca_comp_acc_factor \n\
                    WHERE fcard_class  = ? \n\
                      AND fcar_class = ?     \n\
                      AND qclass  = ? \n\
                      AND drate=(SELECT drate \n\
                                   FROM ca_rate_date \n\
                                  WHERE icode  = ? \n\
                                    AND itable = 'ca_comp_acc_factor') ");
    $PREPARE get_acc_factor FROM $stmt;

    sprintf(stmt,
    "SELECT qclass FROM ca_comp_acc_factor \n\
      WHERE fcard_class = '2'  \n\
        AND fcar_class = ?     \n\
        AND pcomp_factor = ?   \n\
        AND drate=(SELECT drate \n\
                     FROM ca_rate_date \n\
                    WHERE icode  = ? \n\
                      AND itable = 'ca_comp_acc_factor') ");

    $PREPARE get_lia_qclass FROM $stmt;

    /* 107.05.16 ��������ȪA��P���ɸ�� mark by 061476 (1070226005_SC1) */
    /* sprintf(stmt,"SELECT %s FROM %s WHERE %s ",
                 " First 1 nvl(tphone_con,' '),nvl(imovephone,' '),nvl(iemail,' ') ",
                 " cu_customer ",
                 " ifpce_id = ? ");
    $PREPARE cus_id FROM $stmt; */

    /* 101.10 �A�ק� "�A��50�I�ؤ�����" �P�_�覡  */
    sprintf(stmt, "SELECT count(*) \
                     FROM tmp_ins50_cartype \
                    WHERE icar_type =? ");
    $PREPARE preIns50_cartype FROM $stmt;

    /* 101.10 �A�D���Ӿ���barcode �P�_�h�~���L47  */
    sprintf(stmt, " SELECT count(*) \
                    FROM ply_ins_type_last \
                   WHERE ipolicy = ? \
                     AND iins_type = ? \
                     AND mdamage_cover>0 ");
    $PREPARE pre_check_ins FROM $stmt;

    sprintf(stmt, "SELECT mservice,mother_busi FROM cm_route_comm \
                    WHERE iroute   = ? \
                      AND insure_type = 'C' \
                      AND iins_cat    = ? \
                      AND irate_type  = ? \
                      AND iroute_comm = ? \
                      AND iyear = ?\
                      AND iins_type= ? ");
     $PREPARE prep_get_route_comm FROM $stmt;

     /* 101.10 �Afor tpl_barcode, check �O�_�ŦX �D���Ӿ���barcode �I�ر��� */
     sprintf(stmt, "SELECT count(*) \
                      FROM ply_ins_type_last \
                     WHERE ipolicy =? \
                       AND iins_type IN (%s,%s) ", INS01_STRING, INS11_STRING);
     $PREPARE prep_chk01_11 FROM $stmt;

     /* 102.12.25 :�ק�M�ץ�g�����*/
     /* �t�X�M�׸g��(N�g��)�ϥ�,�ק�N,H�M�׸g�쪺���� modify by sylvia 103.09.01 (1030630002_C1) */
	 /* sprintf(stmt, "SELECT  count(*) \
	                  FROM  ply_relation_last a,policy_last b,ply_ins_type_last c \
				      WHERE  a.ipolicy  = b.ipolicy AND a.ipolicy  = c.ipolicy \
			            AND  a.ipolicy  = ? \
			            AND  b.iassured = ? \
			            AND nvl(c.fedr_status,'') not in ('1','2','3') \
			            AND ( a.iofficer[1] <> 'W' and not (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) ) " ); */
	  sprintf(stmt, "SELECT  count(*) \
	                  FROM  ply_relation_last a,policy_last b,ply_ins_type_last c \
				  WHERE  a.ipolicy  = b.ipolicy AND a.ipolicy  = c.ipolicy \
			            AND  a.ipolicy  = ? \
			            AND  b.iassured = ? \
			            AND  nvl(b.dbirth,' ') = ? \
			            AND  a.bzfrom = ? \
			            AND  nvl(c.fedr_status,'') not in ('1','2','3') \
			            AND  a.ileader = ? \
			            AND ( a.iofficer[1] not in ('W','N') and not (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) and not (a.iofficer[1] = 'L' and a.iofficer[7] = 'B') )");

     $PREPARE prep_chkChange FROM $stmt;

     sprintf(stmt, "SELECT  count(*) \
	                  FROM  policy_302 a \
				  WHERE  a.ipolicy  = ? \
			            AND  a.ilicense = ? \
			            AND  nvl(a.dbirth,' ') = ? \
			            AND  a.bzfrom = ? \
			            AND  a.ileader = ? \
			            AND  a.dply_begin >= ? and dply_begin <= ? ");

     $PREPARE prep_chkChange2 FROM $stmt;


     sprintf(stmt, "SELECT count(*) FROM ply_ins_type_last \
                     WHERE ipolicy = ? \
                       AND iins_type <>'50'") ;

     $PREPARE prep_chk_ins50 FROM $stmt;

     /* 102.12.25 , �ק�M�ץ�g�����G�g��N���Ĥ@�X = ��W��or (�g��N���Ĥ@�X  = ��H��and �g��N���ĤG�X not in (��0��,��1��,��2��)) */
     /* �Z�O�h�~�u�O21+50�̥B��ĳ�I�ؤ����t�����ѵs�̡A��[�J�T����jbarcode */
     /* �t�X�M�׸g��(N�g��)�ϥ�,�ק�N,H�M�׸g�쪺���� modify by sylvia 103.09.01 (1030630002_C1) */
	   sprintf(stmt, "SELECT  count(*) \
	                  FROM  ply_relation_last a,policy_last b,ply_ins_type_last c \
				      WHERE  a.ipolicy  = b.ipolicy AND a.ipolicy  = c.ipolicy \
			            AND  a.ipolicy  = ? \
			            AND  b.iassured = ? \
			            AND  nvl(c.fedr_status,'') not in ('1','2','3') \
			            AND ( a.iofficer[1] not in ('W','N') and not (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) \
			                  and not (a.iofficer[1] = 'L' and a.iofficer[7] = 'B') )");

     $PREPARE prep_check_ins FROM $stmt;

     sprintf(stmt, "SELECT count(*) \
                    FROM tmp_no_barcode_list \
                    WHERE tmp_iofficer =? ");
     $PREPARE preNo_barcode FROM $stmt;

     /*102.08.01 ,�]����ĳ98�I�� */
     sprintf(stmt, "SELECT count(*) FROM ca_car_model \
	                 WHERE ibrand = ? AND sports_car = 'Y' \
	                   AND drate = (SELECT drate FROM ca_rate_date \
	                                 WHERE icode = ? AND itable = 'ca_car_model')");
     $PREPARE preSports_car FROM $stmt;

     sprintf(stmt, "SELECT b.ncode FROM ca_car_model a, cu_code_data b \
	                 WHERE a.icar_series = b.icode \
	                   AND b.itype = 'CJ' AND a.ibrand = ? \
	                   AND a.ipro_year = (select max(ipro_year) from ca_car_model \
	                                       where ibrand = a.ibrand and drate = a.drate ) \
	                   AND a.drate     = (select drate from ca_rate_date \
	                                       where icode = ? and itable = 'ca_car_model') ");
     $PREPARE pre98deduct FROM $stmt;

     /* 102.08.08,���ЫO�N���w�t���ϥίS�O���²v */
     sprintf(stmt, "SELECT max(trim(detail2)),count(*) FROM car_code  \
	                 WHERE kind = 'P0' AND ? matches detail");
     $PREPARE preHondaIbrand FROM $stmt;

     /* 102.09.06 */
     sprintf(stmt, "SELECT count(*) FROM ply_ins_type_last \
	                 WHERE ipolicy= ?  \
	                   AND iins_type = ? ");
     $PREPARE preChk0585 FROM $stmt;

     sprintf(stmt, "SELECT count(*) FROM ply_ins_type_last \
	                 WHERE ipolicy= ?  \
	                   AND iins_type in ('63','65','67') ");
     $PREPARE preChk636567 FROM $stmt;

     /* JB�q���ˮ�110�I�ج���:110����,110�I�حӼ�,����I�حӼ� add by sylvia 104.05.19  */
     sprintf(stmt, "SELECT round((year(dply_end)-ipro_year)*12+(month(dply_end)-qpro_month)),\
	                       (select count(*) from ply_ins_type_last where ipolicy = a.ipolicy \
                               and iins_type in ('110','111','112')), \
                           (select count(*) from ply_ins_type_last where ipolicy = a.ipolicy) \
                      from ply_relation_last a, policy_last b \
                     where a.ipolicy = b.ipolicy and a.ipolicy = ? ");

     $PREPARE prep_110check FROM $stmt;

     if(( intopt == 9 )||( intopt == 25) || (intopt == 55)){
        strcpy(dbname_tp,get_full_dbname("00"));
        #ifdef PRINTF_FLAG
        printf("dbname_tp=[%s]\n", dbname_tp);
        #endif
        sprintf(stmt_gply, " AND a.ipolicy in (select ipolicy from %s:ca_tmp_no ) ", dbname_tp );
    }else{
        strcpy(stmt_gply, " ");
    }

    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;
    rec_count=0; rec_count_1 =0; rec_count_2 = 0;



    for(y=1;y<=2;y++)
    {
         /* y==1 :�@��� */
         /* y==2 :�O�N�� */
         strcpy(choice,itoa(y));
         #ifdef PRINTF_FLAG
         printf("choice[%s]\n",choice);
         #endif

         /* initialize data to blank or 0 */
         InitData();
         memset(remark1, 0x00, sizeof(remark1));
         memset(remark2, 0x00, sizeof(remark2));
         memset(remark6, 0x00, sizeof(remark6));
         memset(remark7, 0x00, sizeof(remark7));
         memset(remark4, 0x00, sizeof(remark4));
         memset(remark5, 0x00, sizeof(remark5));

         memset(tmp_iroute1, 0x00, sizeof(tmp_iroute1));
         memset(tmp_iroute2, 0x00, sizeof(tmp_iroute2));

         /**linnum ply_ins_type_302,policy_302 sequential�P�B ***/
         rtncode=1,linnum=0;

         if (*choice=='1')
         {
             strcpy(FullDBName,get_full_dbname(db));
             if (FullDBName[0]=='\0')
             {
                 EWRITE(userid,M_CM_DB_NOTOPEN,db);
                 return M_CM_DB_NOTOPEN;
             }

             /* 102.12.25 �M�ץ�H*�g���ibigcomp �]�w��"A"�]�ζ��^ or "B"�]���ء^�A�|�Q�k�쨮�ӥ�F
                          �M�ץ�W*��ibigcomp �]�w��" "�A�|�Q�k��D���ӥ�A��W*���O�O�������O�v�~
                          ��l�欰�Ҭ�"����"�A�GSQL����אּ�ϥ�imgr(���Ӥ@���O)�A�hH* or W* or N*�ұN��
                          "���ӥ�"�]img=1�^ */
             sprintf(stmt_buf,"SELECT a.irelative_ply,a.fcard_class,a.ipolicy,c.ibigcomp,d.iengine,d.iroute,a.iofficer \
                                 FROM %s:ply_relation_last a, %s:policy_last d, %s:officer c \
                                WHERE a.ipolicy=d.ipolicy AND a.iofficer=c.iofficer \
                                  AND a.dply_end Between %ld And %ld \
                                  AND nvl(a.fedr_class,' ') <> '1' \
                                  AND c.imgr != '1' %s \
                                ORDER BY a.fcard_class ",
                             FullDBName, FullDBName, FullDBName,
                             lDplyEndBgn, lDplyEndEnd, stmt_gply);
             #ifdef PRINTF_FLAG
             printf("CURSOR CA302_1:[%s]\n",stmt_buf);
             #endif

             $PREPARE CUR_STMT3 FROM $stmt_buf;
             $DECLARE CA302_1 CURSOR WITH HOLD FOR CUR_STMT3;
             /*$OPEN    CA302_1 USING $iplyyear,$iplymonth;*/
             $OPEN    CA302_1;
             while (1)
             {
                  $FETCH CA302_1 INTO $tmp_relative_ply,$fcard_class,
                                      $last_ply,$ibigcomp,$last_iengine,$tmp_iroute1,$tmp_iofficer;
                  if  (SQLCODE != 0) break ;

                  /* �X�w�ˮ�--���p���D���X�w�̶��M�����p�� add by sylvia 105.06.02 (1050107005_C4) */
                  if ((strlen(tmp_relative_ply) >= 13) && (strncmp(tmp_iroute1, "I006",4) == 0))
                  {
                     $select iroute into $tmp_iroute2
                        from policy_last
                       where ipolicy = $tmp_relative_ply;
                      if (SQLCODE == SQLNOTFOUND)
                      {
                         strcpy(tmp_iroute2, " " );
                      }
                      else
                      {
                          if(strncmp(tmp_iroute2, "I006",4) != 0)
                          {
                            $update ply_relation_last
                                set irelative_ply = ' '
                              where ipolicy in ($last_ply, $tmp_relative_ply);

                             strcpy(tmp_relative_ply, " ");

                          }
                      }
                  }

                  if (fcard_class[0]=='1'){
                  	  chk_mdamage_cover = 0;
                      $EXECUTE pre_chk INTO $chk_mdamage_cover USING $last_ply;
                      if (chk_mdamage_cover==0) continue; /* �j���I�L�īO�� */
                  }
                  rdmg = 'N';   rlia = 'N';   rvkind = 'N';

                  $OPEN fins_cur USING $last_ply;  /* car137 ����ĳ��O��ƺ��@ */
                  for(;;)
                  {
                       $FETCH fins_cur INTO $sfins;
                       if (SQLCODE == SQLNOTFOUND) break;

                       if (sfins[0] == '1') /* ���l */
                       {
                           rdmg = 'Y';
                       }

                       if (sfins[0] == '2') /* ���d */
                       {
                           rlia = 'Y';
                       }

                       if ((sfins[0] == '3') || (sfins[0] == '4')) /* 3:���N  4:�j�� */
                       {
                           rvkind = 'Y';
                       }
                  }
                  $CLOSE fins_cur;

                  if (rvkind == 'Y') continue; /* rdmg�B rlia �b�᭱�P�_ */

                  if (fcard_class[0] == '2')
                  {

                       strcpy(clmply,last_ply);
                  }
                  else
                  {

                       strcpy(clmply,tmp_relative_ply);
                  }

                  if (strlen(trim(clmply)) >= 13)
                  {
                       #ifdef PRINTF_FLAG
                       printf("clmply[%s]\n",clmply);
                       #endif

                       strcpy(clm_db,get_car_full_db(clmply));

                       #ifdef PRINTF_FLAG
                       printf("clm_db [%s]\n",clm_db);
                       #endif
                       /* 961129, �קKappraisal���G����� => ���̷s�����@��(ex.ipolicy=22596V90027650003 ) */
                       /* 960315,  fpart = 1:����  2:�N��  3:���� ����O
                                   �Y��1:���ѡA�����Acheck �X�I��]��"21�G�㨮����" �~����O */
                       sprintf(stmt, "SELECT first 1 %s FROM %s:%s WHERE %s %s",
                                     " fpart ,iacc_reason ",
                                     get_full_dbname(clm_db),
                                     "appraisal ",
                                     " ipolicy = ? ",
                                     " AND fpart IN ('1','2','3') order by dclaim desc");

                       $PREPARE clmid FROM $stmt;
                       $EXECUTE clmid INTO $sfpart,$siacc_reason USING $clmply;

                       #ifdef PRINTF_FLAG
                       printf("CURSOR clmid[%s]\n",stmt);
                       #endif

                       if (SQLCODE != SQLNOTFOUND) {
                       	   if ((sfpart[0]=='1')&&(strncmp(siacc_reason,"21",2)==0)){
                       	   	   if (fcard_class[0] == '2'){            /* 960815, �Y�O�j���A���n��O */
                       	   	       /* �k���iE05���~ (1110915007_SC1) */
                       	   	       $INSERT INTO duplic1 VALUES ($clmply,'','','���ѡB�N���B��������O','1','E05',$tmp_iofficer);
                       	   	       continue;                          /* 1:���� �B�X�I��]�� 21�G�㨮���� ����O */
                       	   	   }
                       	   }
                       	   if (sfpart[0]=='2' || sfpart[0]=='3'){/* 2:�N��  3:���� ����O */
                       	   	/* ��Ӿ㨮���ѡA�j��n�J�p (1080531002_SC1)*/
                       	   	if (fcard_class[0] == '2'){
                       	   		/* �k���iE05���~ (1110915007_SC1) */
                       	   		$INSERT INTO duplic1 VALUES ($clmply,'','','���ѡB�N���B��������O','1','E05',$tmp_iofficer);
                       	   		continue;
                       	   	}
                       	   }
                       }
                       /*if (clmcnt > 0) continue;*/
                  }

                  #ifdef PRINTF_FLAG
                  printf("3.------------ last_ply[%s],SQLCODE[%d]\n",last_ply,SQLCODE);
                  printf("Ca302q01--Debug---DBname[%s]\n",DBName);
                  #endif

                  dmg_flag = 'N';
                  lia_flag = 'N';
                  dmg_flag2 = 'N';

                  rec_count++;
                  rec_count_1++;
                  InitData1();

                  strcpy(stm1,"ply_relation_last");
                  strcpy(stm2,"policy_last");
                  strcpy(stm3,"ply_ins_type_last A");
                  strcpy(stm5,"edr_relation");
                  linnum += 1;
                  rtncode=Get302Data(db,"1");

                  if (rtncode != SUCCESS) {
                  	   if (rtncode == -1000 ){
                  	   	   continue;
                  	   }else{
                  	       return rtncode;
                  	   }
                  }

                  while (Ifirst != NULL)
                  {
                        Icurr=Ifirst;
                        Ifirst=Icurr->next;
                        free(Icurr);
                  }
             }
             $CLOSE CA302_1;
             $FREE CA302_1;
             #ifdef PRINTF_FLAG
             printf("\n===> end of choice 1 \n");
             #endif
         }
         else if (*choice=='2')
         {
             rtncode = getHeadBranch(taipei_db);
             if (rtncode < 0)
             {
                #ifdef PRINTF_FLAG
                printf("read Config file error!!\n");
                #endif

                return M_CM_READ_CONFIG_ERR;
             }
             strcpy(TpDBName,get_full_dbname(taipei_db));

             if (TpDBName[0]=='\0')
             {
                 EWRITE(userid,M_CM_DB_NOTOPEN,"00");
                 return M_CM_DB_NOTOPEN;
             }

             #ifdef PRINTF_FLAG
             printf("Trace -- lDplyEndBgn = [%ld] \n",  lDplyEndBgn);
             printf("Trace -- lDplyEndEnd = [%ld] \n",  lDplyEndEnd);
             #endif
             /* 102.12.25 �M�ץ�H*�g���ibigcomp �]�w��"A"�]�ζ��^ or "B"�]���ء^�A�|�Q�k�쨮�ӥ�F
                          �M�ץ�W*��ibigcomp �]�w��" "�A�|�Q�k��D���ӥ�A��W*���O�O�������O�v�~
                          ��l�欰�Ҭ�"����"�A�GSQL����אּ�ϥ�imgr(���Ӥ@���O)�A�hH* or W* or N*�ұN��
                          "���ӥ�"�]img=1�^*/
             sprintf(stmt_buf,"SELECT a.ipolicy,irelative_ply,a.fcard_class,a.ibig_office, \
                                      a.ibig_sales,c.ibigcomp,d.iengine,a.iofficer \
                                 FROM %s:ply_relation_last a, %s:policy_last d, %s:officer c \
                                WHERE a.ipolicy=d.ipolicy AND a.iofficer=c.iofficer \
                                  AND a.dply_end Between %ld And %ld \
                                  AND nvl(a.fedr_class,' ') <> '1' \
                                  AND c.imgr = '1'  %s \
                                ORDER BY a.fcard_class ",
                             TpDBName, TpDBName, TpDBName,
                             lDplyEndBgn, lDplyEndEnd, stmt_gply);

             $PREPARE CUR_STMT2 FROM $stmt_buf;
             $DECLARE CA302_4 CURSOR WITH HOLD FOR CUR_STMT2;
             $OPEN CA302_4 ;
             while (1)
             {
                  $FETCH CA302_4 INTO $last_ply,$tmp_relative_ply,$fcard_class,
                                      $big_office,$big_sales,$ibigcomp,$last_iengine,$tmp_iofficer;

                  if (SQLCODE != 0) break;

                  if (fcard_class[0]=='1'){
                  	  chk_mdamage_cover = 0;
                      $EXECUTE pre_chk INTO $chk_mdamage_cover USING $last_ply;

                      if (chk_mdamage_cover==0) continue; /* �j���I�L�īO�� */

                  }

                  #ifdef PRINTF_FLAG
                  printf("lastply[%s],big_office[%s]\n",last_ply,big_office);
                  printf("�O�N�� check �O�_��O�j��\n");
                  #endif

                  rdmg = 'N';   rlia = 'N';   rvkind = 'N';
                  $OPEN fins_cur USING $last_ply;
                  for(;;)
                  {
                       $FETCH fins_cur INTO $sfins;
                       if (SQLCODE == SQLNOTFOUND) break;

                       if (sfins[0] == '1')  /* ���l */
                       {
                           rdmg = 'Y';
                       }

                       if (sfins[0] == '2')  /* ���d */
                       {
                           rlia = 'Y';
                       }

                       if ((sfins[0] == '3') || (sfins[0] == '4')) /* 3:���N  4:�j�� */
                       {
                           rvkind = 'Y';
                       }
                  }
                  $CLOSE fins_cur;

                  if (rvkind == 'Y') continue; /* rdmg�B rlia �b�᭱�P�_ */

                  if (fcard_class[0] == '2')
                  {

                      strcpy(clmply,last_ply);
                  }
                  else
                  {

                      strcpy(clmply,tmp_relative_ply);
                  }

                  if (strlen(trim(clmply)) >= 13)
                  {
                      #ifdef PRINTF_FLAG
                      printf("clmply[%s]\n",clmply);
                      #endif

                      strcpy(clm_db,get_car_full_db(clmply));

                      #ifdef PRINTF_FLAG
                      printf("clm_db [%s]\n",clm_db);
                      #endif
                       /* 961129, �קKappraisal���G����� => ���̷s�����@��(ex.ipolicy=22596V90027650003 ) */
                       /* 960315,  fpart = 1:����  2:�N��  3:���� ����O
                                   �Y��1:���ѡA�����Acheck �X�I��]��"21�G�㨮����" �~����O */
                       sprintf(stmt, "SELECT  first 1 %s FROM %s:%s WHERE %s %s",
                                     " fpart ,iacc_reason ",
                                     get_full_dbname(clm_db),
                                     "appraisal ",
                                     " ipolicy = ? ",
                                     " AND fpart IN ('1','2','3') order by dclaim desc");

                       $PREPARE clmid FROM $stmt;
                       $EXECUTE clmid INTO $sfpart,$siacc_reason USING $clmply;

                       #ifdef PRINTF_FLAG
                       printf("CURSOR clmid[%s]\n",stmt);
                       #endif

                       if (SQLCODE != SQLNOTFOUND) {
                       	   if ((sfpart[0]=='1')&&(strncmp(siacc_reason,"21",2)==0)){
                       	   	   if (fcard_class[0] == '2'){            /* 960815, �Y�O�j���A���n��O */
                       	   	       /* �k���iE05���~ (1110915007_SC1) */
                       	   	       $INSERT INTO duplic1 VALUES ($clmply,'','','���ѡB�N���B��������O','1','E05','');
                       	   	       continue;                          /* 1:���� �B�X�I��]�� 21�G�㨮���� ����O */
                       	   	   }
                       	   }
                       	   if (sfpart[0]=='2' || sfpart[0]=='3'){ /* 2:�N��  3:���� ����O */
                       	       /*add by 071004 (1110307006_SC1_�վ㨮�ӥ���O�J�p�W�h(�z�ߥ����l���A))*/
                       	       if (fcard_class[0] == '2'){
                       	   	   /* �k���iE05���~ (1110915007_SC1) */
                       	   	   $INSERT INTO duplic1 VALUES ($clmply,'','','���ѡB�N���B��������O','1','E05','');
                       	   	   continue;
                       	       }
                       	   }
                       }
                  }

                  #ifdef PRINTF_FLAG
                  printf("after lastply[%s],big_office[%s]\n",last_ply,big_office);
                  printf("3.0>>>last_ply[%s],ibigcomp[%s]\n",last_ply,ibigcomp);
                  #endif

                  dmg_flag = 'N';
                  lia_flag = 'N';
                  dmg_flag2 = 'N';
                  rec_count++;
                  rec_count_2++;
                  InitData1();

                  strcpy(stm1,"ply_relation_last ");
                  strcpy(stm2,"policy_last");
                  strcpy(stm3,"ply_ins_type_last A");
                  linnum +=1;
                  rtncode=Get302Data("00","2");

                  if (rtncode != SUCCESS) {
                  	   if (rtncode == -1000 ){
                  	   	   continue;
                  	   }else{
                  	       return rtncode;
                  	   }
                  }

                  while (Ifirst != NULL)
                  {
                        Icurr=Ifirst;
                        Ifirst=Icurr->next;
                        free(Icurr);
                  }

             }
             $CLOSE CA302_4;
             $FREE CA302_4;

             while (Ifirst != NULL)
             {
                  Icurr=Ifirst;
                  Ifirst=Icurr->next;
                  free(Icurr);
             }
             #ifdef PRINTF_FLAG
             printf("4.{Car302.0010}:rec_count[%d]\n",rec_count);
             #endif
         }


         if( intopt == 25 ){
            /* [del intopt == 25]102.03 �w��5/1�ᤧ 5,6��|���X�椧��O���ơA�ɻ����O�X���ơA�H�Q���H�o��O�� 102.07���i�R��*/
            /* ��ӳ����J�p�覡�ɸ�� */
         }else{
            /* �j���I���p�����N�I���J�p, �j���I�礣�J�p  add by sylvia(1050302003_C1) ---------------------- */
            /* �s�W���J�p�N��E48:150/151���J�p add by sylvia  (1050801007_C3) */
            /* �s�W���J�p�N��E50:�U�[�ӫ~���J�p(125,126,18) add by sylvia 105.12.28 (1051214006_C4) */
            /* �s�W���J�p�N��E51:���N�I�O�O<100���J�p add by sylvia 106.06.15 (1060608010_C1) */
            /* �s�W���J�p�N��E52~E55(��E45����X�Ӫ�) add by 061476 107.08.09 (1070628004_SC1) */
            /* �s�W���J�p�N��E56�ò���E40 modify by 061476 110.04.12 (1100310005_SC1) */
            /* �s�W���J�p�N��E40:���O100�D���ި��챾�l�� add by 061476 110.05.20 (1100504003_SC1)*/
            /* �s�W���J�p�N��E57 modify by 061476 112.05.04 (1120427002_SC1)*/
            /* �s�W���J�p�N��E58�G�R�q�ζW�L4�~ (1120927002_C05)*/

            /* -------------------  SET EXPLAIN ON ------------------- */
            $SET EXPLAIN FILE TO '/dbdump/car302_explain1.out';
            $SET EXPLAIN ON AVOID_EXECUTE;
            sprintf(stmt_buf, " insert into tp_relply \n"
                              " select a.ipolicy, a.irelative_ply, c.iassured \n"
                              "   from ply_relation_last a, policy_last b, policy_last c \n"
                              "  where a.ipolicy = b.ipolicy  and a.irelative_ply = c.ipolicy \n"
                              "    and a.fcard_class = '1' and nvl(a.irelative_ply,' ') <> ' '  \n"
                              "    and a.irelative_ply in   \n"
                              "        (select unique ipolicy from duplic1 \n"
                              "          where ierr_no in ('E06','E16','E17','E29','E30','E40','E41', \n"
                              "                            'E43','E45','E48','E50','E51','E52','E53', \n"
                              "                            'E54','E55','E56','E57','E58')); ");
            $PREPARE set_relply_explain1 FROM $stmt_buf;
            $EXECUTE set_relply_explain1;

            sprintf(stmt_buf, " insert into duplic1 \n"
                              " select ipolicy, iengine, ' ', '�j���I���p�����N�I�O��('||trim(irelative_ply)||')���J�p', '1', 'E47', iofficer \n"
                              "   from policy_302 where fcard_class = '1' and nvl(irelative_ply,' ') <> ' ' \n"
                              "    and exists (select ipolicy, iassured from tp_relply where tp_relply.ipolicy = policy_302.ipolicy \n"
                              "                   and tp_relply.iassured = policy_302.ilicense); ");
            $PREPARE set_duplic1_explain1 FROM $stmt_buf;
            $EXECUTE set_duplic1_explain1;
            $SET EXPLAIN OFF;
            /* -------------------   ------------------- */
            $SET EXPLAIN FILE TO '/dbdump/car302_explain2.out';
            $SET EXPLAIN ON AVOID_EXECUTE;

            sprintf(stmt_buf, " insert into tp_relply \n"
                              " select a.ipolicy, a.irelative_ply, b.iassured \n"
                              "   from ply_relation_last a, policy_last b \n"
                              "  where a.irelative_ply = b.ipolicy \n"
                              "    and a.fcard_class = '1'  \n"
                              "    and a.irelative_ply in   \n"
                              "        (select distinct ipolicy from duplic1 \n"
                              "          where ierr_no in ('E06','E16','E17','E29','E30','E40','E41', \n"
                              "                            'E43','E45','E48','E50','E51','E52','E53', \n"
                              "                            'E54','E55','E56','E57','E58')); ");
            $PREPARE set_relply_explain2 FROM $stmt_buf;
            $EXECUTE set_relply_explain2;

            sprintf(stmt_buf, " insert into duplic1 \n"
                              " select a.ipolicy, a.iengine, ' ', '�j���I���p�����N�I�O��('||trim(a.irelative_ply)||')���J�p', '1', 'E47', a.iofficer \n"
                              "   from policy_302 a, tp_relply b \n"
                              "  where nvl(a.irelative_ply, '') <> '' \n"
                              "    and a.ipolicy = b.ipolicy and a.ilicense = b.iassured; ");
            $PREPARE set_duplic1_explain2 FROM $stmt_buf;
            $EXECUTE set_duplic1_explain2;
            $SET EXPLAIN OFF;
            /* -------------------  SET EXPLAIN OFF ------------------- */
            /* -------------------   ------------------- */
            $SET EXPLAIN FILE TO '/dbdump/car302_explain3.out';
            $SET EXPLAIN ON AVOID_EXECUTE;

            sprintf(stmt_buf, " insert into tp_relply \n"
                              " select a.ipolicy, a.irelative_ply, b.iassured \n"
                              "   from ply_relation_last a, policy_last b \n"
                              "  where a.irelative_ply = b.ipolicy \n"
                              "    and a.fcard_class = '1'  \n"
                              "    and a.irelative_ply in   \n"
                              "        (select ipolicy from duplic1 \n"
                              "          where ierr_no in ('E06','E16','E17','E29','E30','E40','E41', \n"
                              "                            'E43','E45','E48','E50','E51','E52','E53', \n"
                              "                            'E54','E55','E56','E57','E58')); \n");
            $PREPARE set_relply_explain3 FROM $stmt_buf;
            $EXECUTE set_relply_explain3;

            sprintf(stmt_buf, " insert into duplic1 \n"
                              " select a.ipolicy, a.iengine, ' ', '�j���I���p�����N�I�O��('||trim(a.irelative_ply)||')���J�p', '1', 'E47', a.iofficer \n"
                              "   from policy_302 a, tp_relply b \n"
                              "  where a.irelative_ply <> '' and a.irelative_ply is not null \n"
                              "    and a.ipolicy = b.ipolicy and a.ilicense = b.iassured; \n");
            $PREPARE set_duplic1_explain3 FROM $stmt_buf;
            $EXECUTE set_duplic1_explain3;
            $SET EXPLAIN OFF;
            /* -------------------  SET EXPLAIN OFF ------------------- */

            sprintf(stmt_buf, " insert into tp_relply \n"
                              " select a.ipolicy, a.irelative_ply, b.iassured \n"
                              "   from ply_relation_last a, policy_last b \n"
                              "  where a.irelative_ply = b.ipolicy \n"
                              "    and a.fcard_class = '1'  \n"
                              "    and a.irelative_ply in   \n"
                              "        (select ipolicy from duplic1 \n"
                              "          where ierr_no in ('E06','E16','E17','E29','E30','E40','E41', \n"
                              "                            'E43','E45','E48','E50','E51','E52','E53', \n"
                              "                            'E54','E55','E56','E57','E58')); \n");
            $PREPARE wk_tp_relply FROM $stmt_buf;
            $EXECUTE wk_tp_relply;

            sprintf(stmt_buf, " insert into duplic1 \n"
                              " select a.ipolicy, a.iengine, ' ', '�j���I���p�����N�I�O��('||trim(a.irelative_ply)||')���J�p', '1', 'E47', a.iofficer \n"
                              "   from policy_302 a, tp_relply b \n"
                              "  where a.irelative_ply <> '' and a.irelative_ply is not null \n"
                              "    and a.ipolicy = b.ipolicy and a.ilicense = b.iassured;  \n");
            $PREPARE wk_tp_duplic1 FROM $stmt_buf;
            $EXECUTE wk_tp_duplic1;



			       if(0)
			       {   /*  --��{���X-- */
			            sprintf(stmt_buf, " insert into tp_relply \n"
			                              " select a.ipolicy, a.irelative_ply, c.iassured \n"
			                              "   from ply_relation_last a, policy_last b, policy_last c \n"
			                              "  where a.ipolicy = b.ipolicy  and a.irelative_ply = c.ipolicy \n"
			                              "    and a.fcard_class = '1' and nvl(a.irelative_ply,' ') <> ' '  \n"
			                              "    and a.irelative_ply in   \n"
			                              "        (select unique ipolicy from duplic1 \n"
			                              "          where ierr_no in ('E06','E16','E17','E29','E30','E40','E41', \n"
			                              "                            'E43','E45','E48','E50','E51','E52','E53', \n"
			                              "                            'E54','E55','E56','E57','E58')); ");
			            $PREPARE wk_tp_relply FROM $stmt_buf;
			            $EXECUTE wk_tp_relply;

			            /*$insert into tp_relply
			             select a.ipolicy, a.irelative_ply, c.iassured
			               from ply_relation_last a, policy_last b, policy_last c
			              where a.ipolicy = b.ipolicy  and a.irelative_ply = c.ipolicy
			                and a.fcard_class = '1' and nvl(a.irelative_ply,' ') <> ' '
			                and a.irelative_ply in
			                    (select unique ipolicy from duplic1
			                     where ierr_no in ('E06','E16','E17','E29','E30','E38','E40','E41','E43','E45','E48','E50','E51','E52','E53','E54','E55','E56','E57','E58'));*/

			            sprintf(stmt_buf, " insert into duplic1 \n"
			                              " select ipolicy, iengine, ' ', '�j���I���p�����N�I�O��('||trim(irelative_ply)||')���J�p', '1', 'E47', iofficer \n"
			                              "   from policy_302 where fcard_class = '1' and nvl(irelative_ply,' ') <> ' ' \n"
			                              "    and exists (select ipolicy, iassured from tp_relply where tp_relply.ipolicy = policy_302.ipolicy \n"
			                              "                   and tp_relply.iassured = policy_302.ilicense); ");
			            $PREPARE wk_tp_duplic1 FROM $stmt_buf;
			            $EXECUTE wk_tp_duplic1;

			            /*$insert into duplic1
			             select ipolicy , iengine, ' ', '�j���I���p�����N�I�O��('||trim(irelative_ply)||')���J�p', '1', 'E47',iofficer
			               from policy_302 where fcard_class = '1' and nvl(irelative_ply,' ') <> ' '
			                and exists (select ipolicy, iassured from tp_relply where tp_relply.ipolicy = policy_302.ipolicy
			                               and tp_relply.iassured = policy_302.ilicense);*/

			            /* �j���I���p�����N�I���J�p, �j���I�礣�J�p  add by sylvia(1050302003_C1) end ------------------- */
			        }/*  --��{���X END -- */

             /* 9711, add ca_pa_ply_302,ply_ins_cover_302 */
             $DELETE FROM policy_302
               WHERE ipolicy IN (select ipolicy from duplic1 where policy_302.ipolicy = duplic1.ipolicy AND delkind = '1' );

             $DELETE FROM ply_ins_type_302
               WHERE ipolicy IN (select ipolicy from duplic1 where ply_ins_type_302.ipolicy = duplic1.ipolicy AND delkind = '1');

             $DELETE FROM ca_pa_ply_302
               WHERE ipolicy IN (select ipolicy from duplic1 where ca_pa_ply_302.ipolicy = duplic1.ipolicy AND delkind = '1');

             $DELETE FROM ply_ins_cover_302
               WHERE ipolicy IN (select ipolicy from duplic1 where ply_ins_cover_302.ipolicy = duplic1.ipolicy AND delkind = '1');

               /* add by sylvia 114.04.22 (1140409004_C01) */
               $DELETE FROM ply_ins_assured_302
               WHERE ipolicy IN (select ipolicy from duplic1 where ply_ins_assured_302.ipolicy = duplic1.ipolicy AND delkind = '1');

             /* �]fcomp_24�w����,��policy_302f�ɧ@policy_302�w�R�檺���O add by sylvia 105.03.16 */
             $update policy_302f
                 set fcomp_24 = 'D'
               where exists (select distinct ipolicy from duplic1 where policy_302f.ipolicy = duplic1.ipolicy AND delkind = '1' );
             #ifdef PRINTF_FLAG
             printf("\n\n before output \n");
             #endif


				}

         #ifdef PRINTF_FLAG
         printf("******************************* 2038 --------------------- \n");
         printf("rec_count[%d]\n",rec_count);
         printf("rec_count_1[%d]\n",rec_count_1);
         printf("rec_count_2[%d]\n",rec_count_2);
         #endif

         /*------------------   �ܦ���Ƥw���� INSERT INTO policy_302  �i�@���ɮ�  ----------------------- */
         $WHENEVER SQLERROR GOTO errexit;  /* resume error handle label */

         while (Ifirst != NULL) { /* make sure once more, free all alloc. memory */
             Icurr=Ifirst;
             Ifirst=Icurr->next;
             free(Icurr);
         }
    } /* End For y */


    /* �N���D���Ƽg�J����table (car_renew_msg)*/
    /* modify by 071004 �qcar302_build1���Ჾ��prepare_reject_client_ply���e*/
    /* modify by 071004 �ګO���`-�޲z�H���D�̷s�޲z�H(1110325004_SC1)*/
    /* �쥻�O�H�e�檺�g��B�~�Z���g�Jcar_renew_msg�A�令�H�J�p(car139�ഫ�B�z��)���g��N���A�Yduplic1�������g��A�g�Jcar_renew_msg*/
    sprintf(stmt,
        "insert into sysdb:car_renew_msg \
         select a.ipolicy, nvl(f.itag,' '), nvl(f.iengine,' '), f.iassured, f.nassured, \
                a.icar_type, a.dply_end, e.nbranch, c.ileader, d.nname, \
                g.iofficer, c.nname, f.iroute, b.nroute, nvl(f.iabn_type,' '), 'E', \
                '�L�k��O�J�p', g.ierr_no, nvl(trim(g.iins_type)||' '||trim(g.message),' '), \
                'N', nvl(decode(a.iofficer[1,1],'J',ibig_sales,'B',ibig_sales,' '),' '), \
                case when a.iofficer[1,1] in ('B','J') then \
                     nvl((select nname from ca_big_office where fclass = '2' \
                             and ibig_comp = a.ibig_sales),' ') else ' ' end, \
                '%s',current \
           FROM ply_relation_last a, cm_route b , officer c, officer d, \
                sa_branch_type e, policy_last f, duplic1 g \
          WHERE g.iofficer = c.iofficer  AND c.ileader = d.iofficer \
            AND f.iroute = b.iroute  AND c.iquota = e.ibranch \
            AND a.ipolicy = f.ipolicy  and a.ipolicy = g.ipolicy ", userid);

    $PREPARE pre_ermsg FROM $stmt;
    $EXECUTE pre_ermsg;


    /*E42���~:�q�ʦۦ樮��X�O�I�ȥi��O�Ĥ@�~�βĤG�~��*/
    /*E49���~:�Q�O�H�]�w������O/�d�ߤΧR���Ӹ�(���N�I)*/
    /*E58���~:�R�q�Ϧw�ˤ�j��4�~��O�~���A�Ь��֫O�H��*/
    /*�H�W3�ӿ��~���|�blast�ɡA�ҥH���|�b�W�����@�q�Q�g�Jcar_renew_msg*/
    /*�b�o�q�t�~�B�z*/

     $DECLARE sdb_curE CURSOR for
       SELECT branch
         INTO $xBranch
         FROM servertbl
        WHERE branch <> 'S1';
     $OPEN sdb_curE;
     for(;;)
     {
        $FETCH sdb_curE;
        if (SQLCODE == SQLNOTFOUND) break;


        strcpy(FullDBName,get_full_dbname(xBranch));


        sprintf(stmt,
                "insert into sysdb:car_renew_msg \
                 SELECT a.ipolicy,nvl(c.itag,' '), nvl(c.iengine,' '), c.iassured, c.nassured, \
                        b.icar_type, b.dply_end, d.nbranch, b.ileader, e.nname, \
                        a.iofficer, f.nname, c.iroute, g.nroute, nvl(c.iabn_type,' '), 'E', \
                        '�L�k��O�J�p', a.ierr_no, nvl(trim(a.iins_type)||' '||trim(a.message),' '), \
                        'N', nvl(decode(a.iofficer[1,1],'J',ibig_sales,'B',ibig_sales,' '),' '), \
                        case when b.iofficer[1,1] in ('B','J') then \
                                  nvl((select nname from ca_big_office where fclass = '2' \
                                          and ibig_comp = b.ibig_sales),' ') else ' ' end, \
                        '%s',current \
                   FROM duplic1 a ,%s:ply_relation b, %s:policy c, sa_branch_type d, \
                        officer e,officer f ,cm_route g\
                  WHERE ((a.ierr_no='E49' AND a.message='�Q�O�H�]�w������O/�d�ߤΧR���Ӹ�2')  \
                         or (a.ierr_no='E42' AND a.message='�q�ʦۦ樮��X�O�I�ȥi��O�Ĥ@�~�βĤG�~��') \
                         or (a.ierr_no='E58' AND a.message='�R�q�Ϧw�ˤ�j��4�~��O�~���A�Ь��֫O�H��')) \
                    AND a.ipolicy=b.ipolicy AND b.ipolicy=c.ipolicy AND d.ibranch=f.iquota \
                    AND b.ileader = e.iofficer AND a.iofficer=f.iofficer AND c.iroute = g.iroute",
                userid,FullDBName, FullDBName );

        $PREPARE insert_msg FROM $stmt;
        $EXECUTE insert_msg ;

     }
     $CLOSE sdb_curE;
     $FREE sdb_curE;




    /*E33�BE34�BE35�BE36�BE37�BE40�BE42(�q�ʦۦ樮��X�O�I�ȥi��O�Ĥ@�~�βĤG�~��)�BE46�BE49*/
    /*�H�W�o�ǿ��~�A�g�Jduplic1��car_renew_msg���g�줴�O�e�檺�g��*/
    /*(�]���O�b�g���ഫ�e(sPrepare���ɭ�)�N�g�Jduplic1�A�ҥHduplic1�������g��O�e�檺�g��A�g�Jcar_renew_msg���g��]�N�O�e�檺)*/
    /*�w��o�ǿ��~�A�b�o�q�A�P�_update�@��*/

     strcpy(chk_iofficer,"");
     strcpy(ipolicy_msg,"");
     strcpy(iofficer_msg,"");
     strcpy(nofficer_msg,"");
     strcpy(ileader_msg,"");
     strcpy(nleader_msg,"");
     strcpy(nbranch_msg,"");

     $DECLARE upd_officer_cur CURSOR for
       SELECT a.ipolicy,a.iofficer
         INTO $ipolicy_msg,$iofficer_msg
         FROM sysdb:car_renew_msg a,duplic1 b
        WHERE (a.err_no in ('E33','E34','E35','E36','E37','E40','E46','E49') OR
              (a.err_no='E42' AND a.remark_reject='�q�ʦۦ樮��X�O�I�ȥi��O�Ĥ@�~�βĤG�~��'))
          AND a.ipolicy=b.ipolicy;
     $OPEN upd_officer_cur;
     for(;;)
     {
        strcpy(chk_iofficer,"");
        strcpy(ipolicy_msg,"");
        strcpy(iofficer_msg,"");
        strcpy(nofficer_msg,"");
        strcpy(ileader_msg,"");
        strcpy(nleader_msg,"");
        strcpy(nbranch_msg,"");

        $FETCH upd_officer_cur;
        if (SQLCODE == SQLNOTFOUND) break;

        strcpy(iofficer_msg,trim(iofficer_msg));

        /*�ˬd�O�_�bcar139�]�w�g��N���ഫ*/
        for (i=0;i<maxcount_office;i++)
        {
              strcpy(chk_iofficer,trim(ca_chg_office[i].ori_iofficer));


              if (strcmp(chk_iofficer , iofficer_msg) == 0)
              {
                  strcpy(iofficer_msg , ca_chg_office[i].new_iofficer);
                  break;
              }
        }

        /*�H���g��N������@���޲z�H�B�~�Z��줤��*/
        $SELECT a.nname, a.ileader ,b.nname  ,c.nbranch
           INTO $nofficer_msg,$ileader_msg,$nleader_msg,$nbranch_msg
           FROM officer a ,officer b,sa_branch_type c
          WHERE a.iofficer=$iofficer_msg
            AND a.ileader=b.iofficer AND a.iquota=c.ibranch;

        if (SQLCODE != SQLNOTFOUND)
        {
            /*��s*/
            $UPDATE sysdb:car_renew_msg
                SET iofficer = $iofficer_msg,
                    nofficer = $nofficer_msg,
                    ileader = $ileader_msg,
                    nleader = $nleader_msg,
                    nquota = $nbranch_msg
              WHERE ipolicy = $ipolicy_msg;
        }


     }
     $CLOSE upd_officer_cur;
     $FREE upd_officer_cur;




    /*-------------------     101.12 �^���X����~�묰�ګO��̡B���`��       -----------------------*/

    /* 102.03 �����J�p������A�אּ�������s�ɮסA�G�J�p���Ҧ���ƫ�A���� �ګO�B���`���ƪ��^��(��btmp_reject_client_ply) */
    rc = prepare_reject_client_ply(iplyyear,iplymonth,intopt);
    if (rc!=M_CM_OK){
�@      if (rc!=-1){
�@         printf(" prepare_reject_client_ply-- rc = [%d]\n " , rc);
        �@ return rc;
	    	}
    }

    /* 102.03 -----------------------------------------------------------------------------------*/
    /* �i�t�μf�֡j
        [�ˮֶ���]�G 2.�]�w��car102���ګO�Ȥ��
        [�f�֤��q�L��]�N�X]�G20  (�f�ֳq�L�̡G500)
        [�ˮֻ���]�G����O�榳�]�w��car102�̡A�Ҥ��q�L
                ��:�u�ګO���O1�B�P�@�O��X�I�T���v(���O�GP)�Ρu�ګO���O�G7�v���H�o��O�q����(�G�]���|��ú�ڳ�)�A
                    ��l���O�|�H�o��O�q���ѡA�����Lú�ڳ�

    */
    /* �u�| update ���N�I�A�j���I�@�߼g�J 500(�f�ֳq�L) (�j+�����f�֪��A�@�߬ݥ��N�I���f�֪��A)*/
    /*----- 102.01.10 update policy_302���ګO���O���(remark_reject)(for BIS��) --------*/
    /*  ����tmp_reject_client_ply �]�t��O�~�뤧�Ҧ��ګO�B���`���  */

    /* �e�ˮֱ���ק�f�s�W�֫O���A=40,41���O�欰�ګO��, �����^���֫O���A, ������40,41 modify by sylvia 104.06.30 (1040624002_C1) */
    if (rc != -1){
	     printf(" UPDATE policy_302�G freason_reject�Bremark_reject .......... \n " );

        /* �t�XRBA�����I�ˮ�, ��{���אּ���N�I�M��;
           �s�W�j���I:���O1,7,9�@�˦C�J�ˮ֥N��20;��L�h����ĳ47,50,149���I�� */

        /* ���N�I modify by sylvia 106.08.15 (1060606002_C5) */
        $UPDATE policy_302
            SET freason_reject = ( select max(freason) from tmp_reject_client_ply r
                                    where r.ipolicy = policy_302.ipolicy ),
	        			nremark_reject = ( select max(remark_reject) from tmp_reject_client_ply r
		                    						where r.ipolicy = policy_302.ipolicy ),
								fuw_status_ori = (case when fuw_status_ori in ('40','41') then fuw_status_ori else 20 end) ,
								fuw_status_sug = (case when fuw_status_sug in ('40','41') then fuw_status_sug else 20 end)
	  			WHERE EXISTS (select ipolicy from tmp_reject_client_ply r
		         						 where r.ipolicy = policy_302.ipolicy and r.fcard_class = '2');

        /* �@�֧�s policy_302f (��O�q����M��) add by sylvia 105.01.18 (1041001006_C1) */
        $UPDATE policy_302f
	    			SET freason_reject = ( select max(freason) from tmp_reject_client_ply r
		                    						where r.ipolicy = policy_302f.ipolicy ),
	        			nremark_reject = ( select max(remark_reject) from tmp_reject_client_ply r
		                    						where r.ipolicy = policy_302f.ipolicy ),
								fuw_status_ori = (case when fuw_status_ori in ('40','41') then fuw_status_ori else 20 end) ,
								fuw_status_sug = (case when fuw_status_sug in ('40','41') then fuw_status_sug else 20 end)
	  			WHERE EXISTS (select ipolicy from tmp_reject_client_ply r
		         							where r.ipolicy = policy_302f.ipolicy and r.fcard_class = '2');

				/* �w��CAR102�����OP.7.9�̡A�@�ߤ��J�p(�ק�j���I����) add by 061476 107.01.19 (1070111012_C1) */
				/* CAR102��10��(B)��Ӳ�9�� modify by 061476 107.11.29 (1071029004_SC3) */
				/* �C�JCAR102�Ҧ����O modify by 061476 110.06.01 (1100504003_SC1) */
        $UPDATE policy_302
            SET freason_reject = ( select max(freason) from tmp_reject_client_ply r
                                    where r.ipolicy = policy_302.ipolicy ),
                nremark_reject = ( select max(remark_reject) from tmp_reject_client_ply r
                �@�@�@�@�@�@        where r.ipolicy = policy_302.ipolicy ),
                fuw_status_ori = (case when fuw_status_ori in ('40','41') then fuw_status_ori else 20 end),
                fuw_status_sug = (case when fuw_status_sug in ('40','41') then fuw_status_sug else 20 end)
          WHERE EXISTS (select ipolicy from tmp_reject_client_ply r
                         where r.ipolicy = policy_302.ipolicy and r.fcard_class = '1');

        /* �ɥ�fcomp_24 �����OP�B7�B9�j���I�@�߱H�e�q���� add by 061476 107.01.19 (1070111012_C1) */
        /* CAR102��10��(B)��Ӳ�9�� modify by 061476 107.11.29 (1071029004_SC3) */
        /* �C�JCAR102�Ҧ����O modify by 061476 110.06.01 (1100504003_SC1) */
        $UPDATE policy_302f
				    SET freason_reject = ( select max(freason) from tmp_reject_client_ply r
					                    where r.ipolicy = policy_302f.ipolicy ),
				        nremark_reject = ( select max(remark_reject) from tmp_reject_client_ply r
					                    where r.ipolicy = policy_302f.ipolicy ),
								fuw_status_ori = (case when fuw_status_ori in ('40','41') then fuw_status_ori else 20 end),
								fuw_status_sug = (case when fuw_status_sug in ('40','41') then fuw_status_sug else 20 end),
								fcomp_24 = 'D'
	  			WHERE EXISTS (select ipolicy from tmp_reject_client_ply r
		      						   where r.ipolicy = policy_302f.ipolicy and r.fcard_class = '1');

        /* �j���I modify by sylvia 106.08.15 (1060606002_C5) */
        /* �j���I:�b�ګO�ɤ����O��, �R���w��ĳ�����N�I(47,50,149) */
        $update policy_302 set v_prem = 0, tot_prem = 0
          WHERE fcard_class = '1'
            AND EXISTS (select ipolicy from tmp_reject_client_ply r
		         where r.ipolicy = policy_302.ipolicy
		           and r.fcard_class = '1' );

        $delete from ply_ins_type_302
          where iins_type != '21'
            and ipolicy in (select ipolicy from tmp_reject_client_ply r
		             where r.fcard_class = '1' );
    }

    /* -------------------------------------------------------------------------------------------*/

        $select count(*) into $iCnt_NewMsg
           from duplic1
          where ierr_no in (select detail2 from car_code where kind = 'RN'
                               and detail = 'Mail_To_Leader' and engname = 'Y');

        sprintf(sTmpMsg, "���������J�p,���q���޲z�H����:�J�p�e[%ld]��,�R����[%d]��,���s�J�p��[%d]��\t\t\t\t\t \n", iCnt_Before, iCnt_After, iCnt_NewMsg);
        rgu_put_body_string(1, rtrim(sTmpMsg), 1);
        rgu_put_body(1);
        max_count++;

    /* ---------------------------------------------------------------------- */
    char fDone='N';
    /* ���s 2p 5p �ɮ� */
    for(y=1;y<=2;y++)
    {
         /* y==1 :�@��� */
         /* y==2 :�O�N�� */
         strcpy(choice,itoa(y));

         if (*choice == '1'){
             sprintf(outputf1,"p32_%d_2p",iplymonth);
             sprintf(outputf2,"p32_ins_%d_2p",iplymonth);
         }else if (*choice == '2'){
             sprintf(outputf1,"p32_%d_5p",iplymonth);
             sprintf(outputf2,"p32_ins_%d_5p",iplymonth);
         }

         if( intopt == 1 ){    /* �����J�p */

         	 if (*choice=='1'){
         	    sprintf(sTmpMsg, "�@���@�J�p [ %ld ] ���I\t\t\t\t\t", rec_count_1);
         	 }else{
         	 	sprintf(sTmpMsg, "�O�N��@�J�p [ %ld ] ���I\t\t\t\t\t", rec_count_2);
         	 }
         	 printf("Trace -- sTmpMsg = [%s] \n",  sTmpMsg);
             rgu_put_body_string(1, rtrim(sTmpMsg), 1);
             rgu_put_body(1);
             max_count++;

         } else if( intopt == 9 ){
         	 /* 981019,�����J�p���]�P�ɲ��s�bca_tmp_no�����ɮ� */
         	 /*client �ݡG nRemoteFile = "car302_part" & CStr(chkGenFile.Value) & ".txt" */

		     /* �����J�p �J�p�����A�P�_�Y�w�g���i�a��O��ƪ��A��('Y')�A�����P�ɼg�J������� */

				     rtcn = do_car_code('Q',"RN","car302",ply_ym,"Y"," ",4,userid);
				     if (rtcn == 1){
					     rtcn = WriteToEstimate(choice,iplyyear,iplymonth,intopt,ipgid,userid);

					     if(rtcn != M_CM_OK) {
					     	 		if (rtcn != -1){
		                         $INSERT INTO duplic1 VALUES (' ',' ',' ','�����J�p�����A���g�J������Ʀ��~!WriteToEstimate()','2', 'E00',' ');
		                     }
		                }else{
				          		if (sGenFile[0]=='1'){
						             rtcn=p32_print_1(choice,iplyyear,iplymonth,outputf1,outputf2,outputf,userid, DBName,ipgid, 99,"111111111111111111111111111111");
						             if (rtcn != 1){
						                 $INSERT INTO duplic1 VALUES (' ',' ',' ','�����ɮצ��~! p32_print_1','2', 'E00', ' ');
						             }else{
							             	 if (*choice=='1'){
							             	    sprintf(sTmpMsg, "�y�����J�p�z�@��� = %ld��,���I��i�ɮפU���j( �Φ� cmn202 ) �}�l�U���z���s���ɮסI\t\t\t\t\t", GiCnt);
							             	 }else{
							             	    sprintf(sTmpMsg, "�y�����J�p�z�O�N�� = %ld��,���I��i�ɮפU���j( �Φ� cmn202 ) �}�l�U���z���s���ɮסI\t\t\t\t\t", GiCnt);
							             	 }
							             	 printf("Trace -- sTmpMsg = [%s] \n",  sTmpMsg);
							 	             rgu_put_body_string(1, rtrim(sTmpMsg), 1);
							 	             rgu_put_body(1);
							 	             max_count++;
						             }
				             	}else{
				             	 		if (fDone == 'N'){
							             	 fDone = 'Y';
								             rgu_put_body_string(1, " \t  \t  \t \t  \t", 1);
								             rgu_put_body(1);
								             max_count++;

				              	     sprintf(sTmpMsg, "�w����y�����J�p�z�@ %d �����\t\t\t\t\t", rec_count );
							         			rgu_put_body_string(1, rtrim(sTmpMsg), 1);
							         			rgu_put_body(1); max_count++;
						         			}
				             }
			            }

				      }else{
				         if (fDone == 'N'){
					       	 			fDone = 'Y';
			                 	if (sGenFile[0]=='1'){
			                 		 sprintf(sTmpMsg, "�w����y�����J�p�z�@ %d �����!���|������u�}��a��O��ơv�A�L�k���s�ɮ�\t\t\t\t\t", rec_count);
			                 	}else{
			                 	 	sprintf(sTmpMsg, "�w����y�����J�p�z�@ %d �����(�`�N�G�|������u�}��a��O��ơv)\t\t\t\t\t", rec_count );
			                 	}
				             		rgu_put_body_string(1, rtrim(sTmpMsg), 1);
				             		rgu_put_body(1);
				             		max_count++;
			            }
				     }
         } else if( intopt == 25 ){
            /* [del intopt == 25]102.03 �w��5/1�ᤧ 5,6��|���X�椧��O���ơA�ɻ����O�X���ơA�H�Q���H�o��O�� 102.07���i�R��*/
            /* ��ӳ����J�p�覡�ɸ�� */
		     		rtcn = WriteToEstimate(choice,iplyyear,iplymonth,intopt,ipgid,userid);

		     		if(rtcn != M_CM_OK) {
		     	 			if (rtcn != -1){
                     $INSERT INTO duplic1 VALUES (' ',' ',' ','�g�J������Ʀ��~!WriteToEstimate()','2', 'E00', ' ');
                 }
             }else{
	          		if (sGenFile[0]=='1'){
			              rtcn=p32_print_1(choice,iplyyear,iplymonth,outputf1,outputf2,outputf,userid, DBName,ipgid, 99,"111111111111111111111111111111");
			              if (rtcn != 1){
			                  $INSERT INTO duplic1 VALUES (' ',' ',' ','�����ɮצ��~! p32_print_1','2', 'E00', ' ');
			              }else{
			             	  if (*choice=='1'){
			             		  sprintf(sTmpMsg, "�y�ɸ�ơz�@��� = %ld��,���I��i�ɮפU���j( �Φ� cmn202 ) �}�l�U���z���s���ɮסI\t\t\t\t\t", GiCnt);
			             	  }else{
			             		  sprintf(sTmpMsg, "�y�ɸ�ơz�O�N�� = %ld��,���I��i�ɮפU���j( �Φ� cmn202 ) �}�l�U���z���s���ɮסI\t\t\t\t\t", GiCnt);
			              	  }
			              	  printf("Trace -- sTmpMsg = [%s] \n",  sTmpMsg);
			 	              rgu_put_body_string(1, rtrim(sTmpMsg), 1);
			 	              rgu_put_body(1);
			 	              max_count++;
			             }
	             	}else{
			             	 if (fDone == 'N'){
				             	 fDone = 'Y';
					             rgu_put_body_string(1, " \t  \t  \t \t \t ", 1);
					             rgu_put_body(1); max_count++;

			              	     sprintf(sTmpMsg, "�w����y�����J�p�z(�ɸ��)�@ %d �����\t\t\t\t\t", rec_count );
						         rgu_put_body_string(1, rtrim(sTmpMsg), 1);
						         rgu_put_body(1); max_count++;
					        }
	             }
	         	}
         }else if( intopt == 55 ) {
         		rc = do_car_code('Q',"RN","car302",stmp55," "," ",3,userid);
            if (rc == 1){
    	        rc = do_car_code('D',"RN","car302",stmp55," "," ",3,userid);
            }
	        	rc = do_car_code('A',"RN","car302",stmp55,"Y"," ",0,userid);


		     		rtcn = WriteToEstimate(choice,iplyyear,iplymonth,intopt,ipgid,userid);
		     		if(rtcn != M_CM_OK) {
		     	 			if (rtcn != -1){
                     $INSERT INTO duplic1 VALUES (' ',' ',' ','���ظg�P����O�J�p����,���g�J������Ʀ��~!WriteToEstimate()','2', 'E00', ' ');
                }
            }else{
                rtcn = WriteToCar320(choice,iplyyear,iplymonth,intopt,ipgid,userid);
                if(rtcn != M_CM_OK) {
                    if (rtcn != -1){
                         $INSERT INTO duplic1 VALUES (' ',' ',' ','���ظg�P����O�J�p����,�g�JCAR320���~!WriteToCar320()','2', 'E00', ' ');
                    }
                }else{
                    if (fDone == 'N'){
			                fDone = 'Y';
				          	  rgu_put_body_string(1, " \t  \t  \t \t \t ", 1);
				          	  rgu_put_body(1); max_count++;

		              	  sprintf(sTmpMsg, "�w����y���ظg�P����O��ơz�@ %d �����\t\t\t\t\t", rec_count );
					        		rgu_put_body_string(1, rtrim(sTmpMsg), 1);
				        			rgu_put_body(1); max_count++;
                    }
                }
	         	}
         }
    	}

    	/* 102.03 �����J�p������A�������s�ɮ� */

    	if( intopt == 1 ){

					if(0){ /* 102.03 �����J�p������A�������s�ɮ� */
	        /*------------------------------------    �έp���    -----------------------------------*/

		        sprintf(outputf3,"p32_%d_statistic",iplymonth);

		        rtcn=ca3021_build(iplyyear,iplymonth,userid,outputf3,ipgid,intopt); /* p32_xx_statistic */
		        if (rtcn != 1){

		            #ifdef PRINTF_FLAG
		            printf("---> ca3021_build error \n");
		            #endif
		            $INSERT INTO duplic1 VALUES (' ',' ',' ','�����ɮצ��~! ca3021_build','2', 'E00', ' ');
		        }


						/*------------------------------------  �Ҧ�barcode   -----------------------------------*/

						/* �J�p�������n���sbarcode��(�Ѵ��ե�)�A�ߦ����٨S�� "ú�ڥ���s��"  */
						/*  ca3025_barcode (�D���Ӿ�����j)  */
		        sprintf(outputf10,"p32_%d_barcode",iplymonth);
		        sprintf(outputf12,"p32_ins_%d_barcode",iplymonth);
		        rtcn=ca3025_barcode(iplyyear,iplymonth,userid,outputf10,outputf12,ipgid,"MOT00");
		        if (rtcn != 1){

		            #ifdef PRINTF_FLAG
		            printf("---> ca3025_barcode (MOT00) error \n");
		            printf("---> �s�@�ɮץ��� \n");
		            #endif
		            $INSERT INTO duplic1 VALUES (' ',' ',' ','�����ɮצ��~! ca3025_barcode (MOT00)','2', 'E00', ' ');
		        }

		        /* 980616 ,�T����O�j�� => ��ĳ50�I�� => �ﲣ�s��barcode*/
			    	/*   ����G�Ҧ��@��� �]���~�G �^*/
			    	/*   ���ءG07�B03�B04�B06�B10�B12�B13�B15�B19�B20�B21�B22�B30  */
			    	/*     Z12010C(�T���I������O)��car147�]�w���Ȧ�q�����ǤJ��barcode���s */
		        /* 101.10 �����㨮���ѱM�� �[�Jcar147�]�w */
		        /* 980727 ,�����㨮���ѱM�� => �u���sbarcode */

		    		/*  ca3025_barcode (�D���ӨT����j)  */
		    		rtcn=ca3025_barcode(iplyyear,iplymonth,userid,outputf10,outputf12,ipgid,"CAR00");
		        if (rtcn != 1){
		            #ifdef PRINTF_FLAG
		            printf("---> ca3025_barcode (CAR00) error \n");
		            printf("---> �s�@�ɮץ��� \n");
		            #endif
		            $INSERT INTO duplic1 VALUES (' ',' ',' ','�����ɮצ��~! ca3025_barcode (CAR00)','2', 'E00', ' ');
		        }

		        /*  ca3025_barcode (�q�ʦۦ樮)  */
		    		rtcn=ca3025_barcode(iplyyear,iplymonth,userid,outputf10,outputf12,ipgid,"EB00");
		        if (rtcn != 1){
		            #ifdef PRINTF_FLAG
		            printf("---> ca3025_barcode (EB00) error \n");
		            printf("---> �s�@�ɮץ��� \n");
		            #endif
		            $INSERT INTO duplic1 VALUES (' ',' ',' ','�����ɮצ��~! ca3025_barcode (EB00)','2', 'E00', ' ');
		        }


		        /*  101.04:tpl_barcode */
		        /*  ca3025_barcode (car147�]�w���q�� (�Ȧ�Btpl barcode�B�����㨮���ѡB ......))  */
		        if (fBarcode_setup == 'Y'){
		        	rtcn=ca3025_barcode(iplyyear,iplymonth,userid,outputf10,outputf12,ipgid," ");
		            if (rtcn != 1){

		                #ifdef PRINTF_FLAG
		                printf("---> ca3025_barcode error \n");
		                printf("---> �s�@�ɮץ��� \n");
		                #endif
		                $INSERT INTO duplic1 VALUES (' ',' ',' ','�����ɮצ��~! ca3025_barcode','2', 'E00', ' ');
		            }
		        }

		        /*------------------------------------     �q����     -----------------------------------*/
		        sprintf(outputf5,"p32_%d_notity",iplymonth);
		        sprintf(outputf8,"p32_%d_no_notity",iplymonth);
		        rtcn=ca3024_build(iplyyear,iplymonth,userid,outputf5,outputf8,ipgid,intopt);  /* p32_xx_notity, p32_xx_no_notity */
		        if (rtcn != 1){

		           #ifdef PRINTF_FLAG
		           printf("---> ca3024_build error \n");
		           #endif
		           $INSERT INTO duplic1 VALUES (' ',' ',' ','�����ɮצ��~! ca3024_build','2', 'E00', ' ');
		        }
        	}
    	}


    /* 981019, ���ץ����J�p�γ����J�p, �ҿ�Xlog */
    flgMsg =0;
		$DECLARE log_cur9 CURSOR FOR
      SELECT ipolicy,iengine,ierr_no,iins_type,message
        INTO $ctmp_ipolicy,$ctmp_iengine,$ctmp_ierrno,$ctmp_iins_type,$ctmp_message
        FROM duplic1
      ORDER BY 1;
    $OPEN log_cur9;
    for(;;)
    {
        $FETCH log_cur9;

        if (SQLCODE == SQLNOTFOUND) break;

        if (flgMsg==0){
            rgu_put_body_string(1, " \t \t \t \t \t ", 1);
            rgu_put_body(1); max_count++;

            sprintf(sTmpMsg,"%s\t %s\t %s\t %s\t %s\t ","�O�渹","������","���~�N�X","�T��1","�T��2");
            rgu_put_body_string(1, rtrim(sTmpMsg), 1);
            rgu_put_body(1); max_count++;
            flgMsg =1;
        }

        sprintf(sTmpMsg,"%s\t %s\t %s\t %s\t %s\t ",ctmp_ipolicy,ctmp_iengine,ctmp_ierrno,ctmp_iins_type,ctmp_message);
        rgu_put_body_string(1, rtrim(sTmpMsg), 1);
        rgu_put_body(1); max_count++;
        printf("->duplic1 Msg = [%s]\n " , sTmpMsg);
    }
    $CLOSE log_cur9;
    $FREE  log_cur9;

    rgu_finish_report();
    FormTp[0] = '\0';
    if(rc=(save_form_info(F_FREE,"CA",302,userid,FormTp,max_count,outputf))<0)
    {
        #ifdef PRINTF_FLAG
  	    printf("*** save_form_info() fail\n");
        #endif
    }

    return M_CM_OK;

errexit:
    printf("2318: sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
    $WHENEVER SQLERROR CONTINUE;     /* reset error handling */
    SQLCODE = rc;
    EWRITE(userid, SQLCODE,sqlca.sqlerrm);
    return SQLCODE;
}

Get302Data(pDb,pTp)
$char *pDb, *pTp;
{
   char    FDBNAME[20];
   long    code, tmp;
   $int    qserial,id,pre_year;
   $char   buf1[10000],aassured_zip[CA_ZIP],irel_card[21], ileader_tmp[11],buf2[2000];
   $date   ddate_1st;
   $char   comp_date_begin[15],comp_date_end[15],sp_sex_age[6],sp_sex_age_dmg[6],
           sp_lia_acc[6],sp_dmg_acc[6],note1[21], sp_unknown_acc[6];
   int     yy1,fany=0,ins_count=0,str_len,ch_ins_cnt,ins_grp_cnt,int_ins,ins_first;
   $char   fagent[1],ibig_branch[5],last_comp_class[3],tmp_ipolicy[21],sTpMsg[71],tmp_ply[3];

   $int    pre_inj_cover,pre_dea_cover,pre_dam_cover,pre_dedu,pre_prem;
   $long   pre_mdiscount,mdiscount,tot_mpay;
   $long   sum_mdiscount,sum_dmg_cover;

   long    qdmg[3],qlia[3],MsgCode;
   long    mdmg[3],mlia[3];

   long    last_dply_bgn;

   $long   qlia_acc,qdmg_acc,v_prem,v_ori_prem,tot_prem;
   $long   qunknown_acc;
   $char   fyear[4],inumber[26],lia_ac_cnt[3][3],dmg_ac_cnt[3][3],lia_ac_cntc[3],nbrand[51];
   $char   LHsIbig_Nname[11];
   $char   plia_acc_c[6],ch_deduct[20],fnation[2],
           ch_ins_grp[3][56],ch_ins[21],pre_prem1[7],pre_prem2[7],scar_price[11];
   $char   pre_ch_ins_grp[3][56];
   $int    tmp_iym_end,tlia_prem,tdmg_prem,dmg_cnt,lia_cnt,icnt1;
   char    iym_end[6],tmp_dply_end_pre[10],tmp_dply_begin_pre[10];
   $long   dply_begin_pre;
   $double tp_dmg_acc,tp_lia_acc,tp_sex_age,tp_sex_age_dmg;
   $double tp_unknown_acc;
   $date   pre_ply1_bgn,pre_ply2_bgn,pre_ply1_end,pre_ply2_end,
           tp_bgn,tp_end;
   $char   icorps[11],ncorps[31];
   $char   ply_group[2];
   $double pextra_charge_check;
   $char   s_car_series[3];
   $double wk_qpt;
   int     i;
   $char   check_sales[21],sInstype[7],sIns_tmp[7];
   $long   chk_count;
   int     find_flag, rc, transKA06_flag;
   int     sug_ins_type,dinstype;


   $char   check_ipolicy[21];
   $char   dmg_class[3], lia_class[3], fH067, sNequipment[31]; /* 990728,���� sNequipment */
   char    dunknown_class[3];
   $int    i_lia;
   $int    cnt_n47, t_count, cnt_ins77, cnt_ins79, cnt_ins118, cnt_ins120, cnt_ins122,
           cnt_ins131,cnt_ins132, cnt_n147, cnt_110_117, cnt_125_136, cnt_f25C01;
   $int    cnt_non_sug, cnt_hi_car_price, cnt_EB;
   $long   tmp_mdamage_cover, tmp_injured_cover, death_cover_56 ,tmp_death_cover;
   $char   assuredn[131], assureda[91], icar_type_tmp[3], Biofficer[11];
   $char   applicantn[121], paymenta[91], ndeputy_appl2[51];
   $long   lDbirth_appl2 = 0;
   char    deduct30[6], deduct30_1[2], deduct30_2[3], deduct30_3[3];
   $char   tmp_nins_type[29];
   $char   Bipolicy[21];
   $long   qday_bak,pre_qday;
   char    c_30_set ;
   long    deduct_30,deduct_29,lng_deduct,deduct_09,deduct_01,deduct_05,deduct_301,damager_cover_30,deduct_530 ;
   int     ins1419_chg_flag,insqday15_chg_flag,ins98_chg_flag;
   int     ins_cnt=0;
   $char   ibirthday_tmp[11],iassured_tmp[11],itag_tmp[CA_TAG_NUM], icar_type_tmp2[3],ilast_card_tmp[19];
   $long   dbirthday_tmp;
   char    fSunLi;
   $char   icheck_disc[2],iins_cat[2],iyear[3];
   $double pdiscount_broker;
   $double pcommiss_broker;
   $char   inequipment[31];
   $char   sdply_end[11];
   int     ilast_comp_class;
   char    v_sMsg[512];
   long    rtncode;
   char    sColumn[21], sTable[21], sDbname[21];
   $double pextra_charge_check1,pextra_charge_check2;
   $long   mcover_inj1,mcover_inj2,mcover_dea1,mcover_dea2;
   $long   damage_cover1=0,ori_damage_cover1=0;   /* for 34�I�� �C�@�ƬG���| �O�B*/
   $long   mcover_tmp,mdiscount_tmp;
   $double short_prate_tmp,adjust_rate_tmp;
   $char   icover_type_tmp[ICOVER_TYPE],iprem_cover_type_tmp[ICOVER_TYPE],cover_name_tmp[COVER_NAME],print_name_tmp[PRINT_NAME];
   $char   deduct_tmp[5],deduct_tmp1[3],deduct_tmp2[3];

   $char   icover_type_302[ICOVER_TYPE];
   $long   mcover_302,mcover_prem_302,mdiscount_302,mprem_302;
   $long   pre_mcover_302,pre_mcover_prem_302,pre_mdiscount_302,pre_mprem_302 ;
   $long   ori_mcover_302,ori_mcover_prem_302,ori_mdiscount_302,ori_mprem_302 ;
   $int    BPlyClosed;
   $char   f_YT_ply, f_YF4_ply, f_EM_ply, f_YTA_ply;
   $char   f_AHL_ply, f_YF6_ply;
   $char   f_UC_ply, f_YFC_ply,f_UF_ply, f_YFB_ply;
   $int    SkipIns;
   $char   tmp_nproject1[21],tmp_nproject2[21];
   $long   mcomp_busi = 0;  /*  �X�w�j��~�ȶO��� */
   $int    ioff_count = 0;
   $char   s_icode_no[11],s_fcomp_disc[2] ,s_fvol_disc[2] , s_fmot_insure[3], s_fcar_insure[3];
   $double s_mcomp_disc,s_mcomp_disc_mot1,s_mcomp_disc_mot2,s_pvol_disc,s_pvol_disc_mot1,s_pvol_disc_mot2;
   $char   icheck_busi[2]; /* �~�ȶO���ˮֽX  */
   $double mservice;       /* ����O , */
   $int    mother_busi;    /* ��L�~�ȶO�� */
   char    fProjNoPlyB='N';
   char    fTaishin = 'N'; /* �x�s�O�g�N flag 980223*/
   int     fOtherIns47 = 0,fOtherIns50 = 0,fPreIns47 = 0,fPreIns31 = 0, fmore21 = 0,
           fOtherIns3132 = 0;
   $long   pre_daily_pay ,pre_daily_pay_tmp,pre_daily_pay_48;
   $char   tMsg[71]="";
   $char   fshow_comp_disc = 'N';    /* 990126,�O�_�nshow�j���I�O�O���T�� */
   $char   f_AN_SHIN ;  /* 99.03.12 ���q�w�߱M�� */
   $char   sTmp[11];
   $char   lia_class_last[3];
   $char   s_qdmg_point[5], s_qunknown_point[5];
   $char   s_lia_class[3];
   $long   tmp_lDamage75 = 0;
   $long   lDamage75 = 0;
   $long   lDamage75_min = 0;
   int     f_del_dmg;
   $long   injured_cover52_old,injured_cover53_old,injured_cover55_old;
   $struct cm_route_comm o_stcomm;
   int     o_qrec = 0;
   $int    icar_age = 0 ;
   $long   prem38_ori,prem39_ori,prem50_ori,prem55_ori,prem56_ori,injured_cover39_ori,damage_cover39_ori,damage_cover11_ori;
   $long   injured_cover31,injured_cover31_ori,damage_cover31,damage_cover32,damage_cover32_ori,damage_cover149;
   int     f_provision_D, f_provision_E, f_provision_R, f_provision_S, f_provision_T,
           f_provision_EZ,f_provision_J, f_provision_X, f_provision_H, f_provision_K,
           f_provision_L, f_provision_ZZ;
   $char   drate_01[5],drate_11[5],last_ply_tmp[21];
   $long   prem38_sug,prem39_sug,prem50_sug,prem55_sug,prem56_sug;
   $long   mcomp_busi_ori = 0,mcomp_busi_no_47= 0,mcomp_busi_47= 0;
   $char   iroute_comm_2147[4],iroute_comm_21[4],v_ipolicy[21], iroute_main_ply[21];
   $char   chk_iofficer[11], chk_policy[21];
   char    fSug3839  ='N';
   $char   f_NO_WORRY ;  /* 101.11 (����)���E�L�~�M�� */
   char    fIns21_50 = 'N'; /* �ŦX�D���ӨT����jbarcode���� "�h�~��O21+50 ��"*/
   $long   damage_cover98_pre, tmp_cover, damage_cover56;
   /*$int    qpro_month = 0;  ��bca3xxlib.h�ŧi mark by 061476 (1100119001_SC3) */
   $long   lng_Pro_ymd;
   char    pro_ymd[11];
   int     intCar_age;
   char    flagOK = 'N';
   $long   minjured_cover105_sug,minjured_cover105_pre,tpCover_E,tpCover_105;
   $long   injured_cover31_pre,damage_cover31_pre,damage_cover32_pre,deduct31_pre,deduct32_pre; /*1101209008_SC1_�_�@�Ͻվ��ĳ��O��סA����31.32�e��O�B*/
   $long   cover_E_last,lDaily_pay_a;
   char    f_del_105,f_del_118,f_get_ca_trade_sug,f_del_98,
           f_del_85,f_del_120,f_del_121,f_del_122,f_del_123,f_del_112,f_del_119,
           f_del_106,f_del_107,f_del_108,f_del_24,f_del_38,f_del_39;
   $char   sCar_kind[2],sAcc_kind[3],iins_scope_a[2],cmp_officer[11];
   $char   spdmg_acc[5],splia_acc[6],spdmg_acc_sug[5],itag131[CA_TAG_NUM],msg1[71],sLia_tax[5];
   $char   spunknown_acc[5], spunknown_acc_sug[5];
   int     fremark1;
   $int    CntPrmt,Cnt142108,CarAgeMonth;
   $int    age_110, cnt_110, oth_110;
   $int    ichg_applicant; /* �󥿭n�O�H=�Q�O�I�H��� */
   int     tmp_status_ori, tmp_status_sug;
   $int    cnt_itag,cnt_sprot;
   $char   tmp_err[61],chk_no_tag[2],upd29_cov1[2],honda_sug_30[2];
   $int    mcover1_178,damage_cover178=0;

   /* �@���j���I���p�� : (add by sylvia 104.04.21 (1040312001_C1)
      1.�p����@���, ���ӫO�N���p����
      2.JB�q���Bcar147�]�w��barcode��BJZ16834703�BZ6102104��, �]���ۤw�p��W�h,�G�]���ǥ󥻦��p��d��
      3.���W�h��:��ӥh�~�Υ�������� (�]�w�� car_code.kind=RN & detail = 'cal_comp' & detail2= A (��ӥh�~) B (���������)
      4.���׬O��ӥh�~���Υ��������, ���|�A��car159�]�w(��O�j���I���]�w�^�i��T�w���B���@�]�Ycar159���ҥ~�޲z�^*/
   char     f_cal_comp, find_comp; /* �O�_����j���I��� Y:�p����  N:���p��p�� */
   $long    mprem_21, mprem_21_ori; /* �j���I���e�O�O */
   $double  mbusiness2;     /* �g��policy_302.mbusiness  (�W���~�ȶO��-�j���I���) */
   /* --------------------------------------------------------------------------------- */
   /* 86�I�ثO�O�p�ⲧ��: modify by sylvia 104.06.11 (1040525002_C3)
      �O�v�N��<74 :�º�k,�S���ۭt�B,32���ت��ۭt�B�����m���Ȫ��ŶZ
      �O�v�N��>=74 :�s��k,���ۭt�B, 32���ت��ۭt�B�^�k�u��ۭt�B, ���m���Ȫ��ŶZ���s��
                    (���«O�O��,���m���Ȫ��ŶZ���O�B1)
   */
   $int idrate_ym, mcover1_86;
   $long mcover2_86_min;
   /*---------------------------------------------------------------------------------- */
   /* �������[�O����   add by sylvia 104.11.25 */
    char    fhi_price;      /* �O�_�ŦX�������[�O Y:�ŦX N:���ŦX   */
    $double hi_car_price;   /* �������[�O�Y��(�d��) */

   /*---------------------------------------------------------------------------------- */
    $int    cnt_provision_T, cnt_provision_Z, cnt_ins_Z, cnt_ins_E;    /* ���ڭӼ� */
    $int    cnt_ins_P, cnt_provision_P, cnt_other_ins1589, cnt_ins_Q, cnt_ins_Y;
    $int    cnt_ins_M, cnt_provision_Q;
    /* --------------------------------------------------------------------- */
    int  fitable; /* �H�j��覡���O�g�Jpolicy_302, policy_302f add by sylvia 105.01.18 */
    $char  ntable[12];

    /* �L�����O�J�p add by sylvia 105.01.27 (1041001006_C1) */
    $int  cnt_137,cnt_RD,cnt_C;
    $char dtransfer[11], iroute12[3];

    /* RBA�t�Ϋظm add by sylvia 105.02.26 (1050105008_C4) */
    $char iassured_cntry[2], iapplicant_cntry[2];

    /* RBA�t�έק� add by sylvia 106.08.16 */
    $char foccup[2], noccup[6], applicant_foccup[2], applicant_noccup[6];

    /* �s�W�t�� add by sylvia 105.07.04 (1041026008_C4) */
    $char fequipment1[2], fequipment2[2], fequipment3[2], fequipment4[2],
          fequipment5[2], fequipment6[2], fequipment9[2], nequipment9[101];

    /* �s�W�n�O�H������X�B�n�O�HEmail add by 061476 106.01.24 (1061003004_C1)*/
    $char tmobile_appl[21], aemail_appl[51], new_route[21];

    /* �s�W�R�q�ά������ (1120927002_C05) */
    $char dinstall[11], isequence[31], ainstall_zip[CA_ZIP], ainstall[91];

    $char relply_end[11], sFullDBName[22];

    /* �t�X�ӫ~���� */
    $long    mdamage_cover_09_sug, mdamage_cover_05_sug, mdamage_cover_01_sug; /* ���� */
    $long    mdamage_cover_153_sug, mdamage_cover_152_sug, mdamage_cover_161_sug, mdamage_cover_162_sug;  /* �������l */
    $long    mdamage_cover_154_sug, mdamage_cover_155_sug, mdamage_cover_156_sug, mdamage_cover_163_sug;   /* �N�B�� */
    $long    mdamage_cover_22_sug;   /* �N�B�� */
    $int     qday_154, qday_155, qday_156, qday_163, qday_67;   /* �N�B�� */
    $int     qday_238; /* ��Q���{ */
    $long    mdamage_cover_67_sug,mdamage_cover_63_sug,mdamage_cover_65_sug;
    $long    mdamage_0509,mdamage_1523,mprem_0509,mprem_1523;
    $long    minjured_cover_156_sug,minjured_cover_154_sug,minjured_cover_155_sug,minjured_cover_163_sug;
    $long    minjured_cover_67_sug,minjured_cover_63_sug;
    $char    chk_chang_149[2];
    $int     qpoint_3132=-9999,qpoint_09=-9999; /* �����I��(��ĳ09�I�إ�) */
    $int     qdmg_acc_3132=0,qdmg_duty_3132=0,qlia_acc_3132=0,qlia_duty_3132=0,qduty_sum_3132=0,qdmg_acc_sum_3132=0,fhave_newa_3132=0;
    $char    dfirst_ply_3132[11];
    int	     qlia_acc_21 = 0;

    /* HCC�֫O�ҫ��ظm add by 061476 (1090803002_SC2) */
    $struct CA_HCC_FACTOR ca_hcc_fac;
    $struct CA_HCC_LEVEL  ca_hcc_lvl;
    int     iHccLevel[INS_SETS] = {0};
    $char   stmt_hcc[2048],stmt_hcc2[512],s_iins_type[INSURANCE_TYPE];
    $int    iset=0,cnt_hcc=0;
    $long   ldfirst_ply;
    $char   cdfirst_ply[10];

    /* 198�I�ؤ��J�p�W�h add by 121219 (1120731006_C03)*/
    $int cnt_fdmg_duty = 0;

		$WHENEVER SQLERROR GOTO get302_err;

   Icurr=Ifirst=Ilast=NULL;             /* set INS_TYPE pointer to NULL */
   Icurr_33=Ifirst_33=Ilast_33=NULL;    /* set INS_TYPE pointer to NULL */
   IfirstPlyInsCover =IcurrPlyInsCover =IlastPlyInsCover =INS_ptrPlyInsCover =NULL ;   /* 960612, ���ݪ��I34 for���O�զX*/
   IfirstPlyInsCover1=IcurrPlyInsCover1=IlastPlyInsCover1=INS_ptrPlyInsCover1=NULL ;   /* 960612, ���ݪ��I34 for��ĳ��O�զX*/
   IfirstPlyInsCover2=IcurrPlyInsCover2=IlastPlyInsCover2=INS_ptrPlyInsCover2=NULL ;   /* 960612, ���ݪ��I34 for�h�~��O�զX*/
   IfirstHccIns=IcurrHccIns=IlastHccIns=NULL; /* HCC�֫O�ҫ��ظm add by 061476 (1090803002_SC2) */

   ply1f=FALSE;
   ply2f=FALSE;

   /******�e���򥻸��*******/
   sp_lia_acc[0] = '\0';
   sp_dmg_acc[0] = '\0';
   strcpy(sp_unknown_acc,"0.0");
   sp_sex_age[0] = '\0';
   sp_sex_age_dmg[0] = '\0';
   note1[0] = '\0';
   rsetnull(CLONGTYPE,(char*)&pre_ply1_bgn);
   rsetnull(CLONGTYPE,(char*)&pre_ply2_bgn);
   rsetnull(CLONGTYPE,(char*)&pre_ply1_end);
   rsetnull(CLONGTYPE,(char*)&pre_ply2_end);
   pre_prem1[0] = '\0';
   pre_prem2[0] = '\0';

   qday      = 0;
   mexpense  = 0;
   mexp_disc = 0;
   damage_add_flag = 0;
   thief_add_flag  = 0;

   mcover_inj1 = 0;
   mcover_inj2 = 0;
   mcover_dea1 = 0;
   mcover_dea2 = 0;
   qday_bak    = 0;
   pre_qday    = 0;
   pre_daily_pay = 0; pre_daily_pay_tmp = 0; pre_daily_pay_48 = 0;
   lDaily_pay  = 0;
   ori_lDaily_pay = 0; /* �u��56���B�� */
   lDaily_pay_a = 0;
   qpro_month  = 0;

   mcover_302=mcover_prem_302=mdiscount_302=mprem_302=0;
   pre_mcover_302=pre_mcover_prem_302=pre_mdiscount_302=pre_mprem_302=0 ;
   ori_mcover_302=ori_mcover_prem_302=ori_mdiscount_302=ori_mprem_302=0 ;

   f_YT_ply = ' ';  f_YF4_ply = ' ' ;  f_EM_ply = ' ' ;  f_YTA_ply = ' ' ;
   f_AHL_ply= ' ';  f_YF6_ply = ' ' ;

   f_AN_SHIN = ' '; /* 99.03.12 ���q�w�߱M�� */ f_NO_WORRY = ' ';
   f_UC_ply  = ' '; /*�W�ߤA���M��*/   f_UF_ply  = ' '; /*�W��DLR50�M�� */
   f_YFC_ply = ' '; /*�έ�A���M��*/   f_YFB_ply = ' '; /*�έ�50�M��(��)*/

   fBarcode = 'N'; /* Barcode ��O�� flag */
   fMotProj = 'N'; /* �����㨮���ѱM�� flag */
   fSug3839 = 'N'; f_del_105 = 'N';  f_del_118 = 'N'; f_del_119 = 'N';
   f_del_120 = 'N'; f_del_121 = 'N'; f_del_122 = 'N'; f_del_123 = 'N'; f_del_112 = 'N'; f_del_85 = 'N'; f_del_98 = 'N';
   f_del_106 = 'N'; f_del_107 = 'N'; f_del_108 = 'N'; f_del_24  = 'N'; f_del_38  = 'N'; f_del_39 = 'N';
   v_sMsg[0]='\0';

   iquery_num[0]= ' '; iquery_num[1]= '\0';
   iquery_num_damage[0]= ' '; iquery_num_damage[1]= '\0';
   iquery_num_unknown[0]= ' '; iquery_num_unknown[1]= '\0';
   iquery_num_c[0]= ' '; iquery_num_c[1]= '\0';

   strcpy(s_fmot_insure," ");
   strcpy(s_fcar_insure," ");
	 strcpy(dfirst_ply_3132," ");
   strcpy(honda_sug_30,"N"); /* ����31�B32<=200/400/50 ��ĳ30�I��500�U */

   /* 102.03 ���O�X�� */
   strcpy(iestimate_ori," "); strcpy(iestimate_sug," ");  /* �����渹   */
   strcpy(itransno_ori," ");  strcpy(itransno_sug," ");   /* ú�ڥ���s��   */
   strcpy(itransno_ori_atm," ");  strcpy(itransno_sug_atm," ");   /* ATMú�ڥ���s��   */
   strcpy(itransno_ori_post," ");  strcpy(itransno_sug_post," ");   /* �l�F����ú�ڥ���s��   */
   strcpy(itransno_ori_007," ");  strcpy(itransno_sug_007," ");   /* �@�ȵ����b��   */
   strcpy(itransno_ori_008," ");  strcpy(itransno_sug_008," ");   /* �ػȵ����b��   */
   strcpy(itransno_ori_009," ");  strcpy(itransno_sug_009," ");   /* ���ȵ����b��   */
   strcpy(itransno_ori_013," ");  strcpy(itransno_sug_013," ");   /* �@�ص����b��   */

   fuw_status_ori = -1  ;fuw_status_sug = -1;             /* ������f�ֵ��G(-1:�|���f��) */
   frenew_type[0] = '1' ; frenew_type[1] = '\0' ;         /* ��O�櫬���G1=�q����(2p�B5P)����;2=��barcode�����A�w�] 1�A��barcode������WriteToEstimate()���A�P�_��^�� */

   strcpy(sCar_kind," "); sCar_kind[1]='\0';
   strcpy(sAcc_kind," "); sAcc_kind[2]='\0';

   damage_149 = 0;deduct_149=0;
   iplyins = 0; mlimit = 0;

   chk_flag = 0 ;/* 102.09.06 �ΥH�P�_�O�_���[�Lú�ڳ� */
   ichg_applicant = 0; /* 0:���󥿭n�O�H���  >0:�󥿭n�O�H=�Q�O�I�H���  add by sylvia */
   memset(dtransfer,0,sizeof(dtransfer)); /* �L��� */
   memset(iroute12,0,sizeof(iroute12)); /* �q���e�G�X */

   strcpy(FDBNAME,get_full_dbname(pDb));
   if (FDBNAME[0]=='\0') {
        EWRITE(userid,M_CM_DB_NOTOPEN,pDb);
        return M_CM_DB_NOTOPEN;
   }

   /* ���n�����H�U�o�T�� printf */
   printf("xxx plyyear[%d]\n",atoi(plyyear));
   printf(" ------- iplyyear10 = [%d]\n " , iplyyear);
   printf(" ------- iplymonth10 = [%d]\n " , iplymonth);

   /************************** STEP 1 ***********************************/
   IsPlyB = 'N'; /* �O�_���M�ץ� */
   ibig_comp[0]=' ' ;
   ibig_comp[1]='\0';

   dedr_begin=DATENULL;

   /* �j���I���O�O�p�� add by sylvia 104.04.21 --------------------------- */
   f_cal_comp = 'Y';    /* �w�]�p��,���ӥ󤣺� */
   pre_discont = 0;
   /* ----------------------------------------------------------------------- */
   /* �I�ذ}�C�M�� add by sylvia 106.03.07 (1060302003_C1) */
    for (i=0;i<1000;i++)
    {
        iply_ins[i]=0;
    }
   /* �Nply_ins_type_last�I�ؼg�Jiply_ins[]�}�C add by syliva 106.03.08 */
    sprintf(buf2, " select iins_type::integer from ply_ins_type_last where ipolicy = '%s' \
                       and mdamage_cover > 0 ", last_ply);
    $PREPARE pre_J1 FROM $buf2;
    $DECLARE cur_J1 CURSOR for pre_J1;
    $OPEN cur_J1;
    while(1)
		{
       $FETCH cur_J1  INTO $iplyins;
       if(SQLCODE == SQLNOTFOUND) break;
       iply_ins[iplyins] = 1;
    }

   	if (*choice=='1') /*�D���ӥ�*/
   	{   /* 950704 ,add dpolicy*/
        sprintf(buf1,"SELECT %s %s %s %s %s FROM %s:%s a %s",
                     "icard,fcard_class,irelative_ply,inext_ply,iofficer,ileader,",
                     "nvl(ibig_comp,' '),ibig_office,ibig_sales,ibroker,iarea,iresource,",
                     "nvl(fedr_class,' '),ibig_branch,fcomp_class,dply_begin,dply_end,mdmg_prem,mlia_prem,dpolicy,dtransfer,iofficer_prmt,isecond_hand,icard_main, ",
                     "(select count(*) from car_code  where kind = 'RN' and detail = 'CHG_APPLICANT' and detail2 = a.iofficer), ",
                     "case when icar_type in ('01','02','32','34','35','27','51','T1','T2') then 'N' else 'Y' end ",
                     FDBNAME,stm1,
                     "WHERE ipolicy=?");

        $PREPARE STM_1_1 FROM $buf1;
        $DECLARE CUR_1_1 CURSOR FOR STM_1_1;
        $OPEN CUR_1_1 USING $last_ply;
        $FETCH CUR_1_1 INTO $last_card,$fcard_class,$irelative_ply,
                            $inext_ply,$iofficer,$ileader,$ibig_comp,$tmp_big_office,$tmp_big_sales,
                            $broker,$area,$resource,$fedr_class,$ibig_branch,$last_comp_class,
                            $tp_bgn,$tp_end,$tdmg_prem,$tlia_prem,$dpolicy,$dedr_begin,$iofficer_prmt,$isecond_hand,$icard_main,
                            $ichg_applicant, $chk_no_tag;

				if (NOT_FOUND)
				{
				        memset(err_buf,0,sizeof(err_buf));
				        strcpy(err_buf,"Get302Data()1:");
				        strcat(err_buf,"select ");
				        strcat(err_buf,stm1);
				        strcat(err_buf,"-");
				        strcat(err_buf,last_ply);
				        EWRITE(userid,M_CA_NPOLICY,err_buf);
				        return M_CA_NPOLICY;
				}
        last_dply_bgn  = tp_bgn;

        sprintf(buf1,"SELECT count(*) FROM %s:%s %s",
                     FDBNAME,"ply_ins_type_last",
                     "WHERE ipolicy=? AND iins_type in ('01','05','08','09','85','86','98','105','110','118','120','122','125','126','181','198','201','205','209') ");

        $PREPARE STM_ins FROM $buf1;
        $EXECUTE STM_ins INTO $dmg_cnt USING $last_ply;

        if (dmg_cnt > 0){
            dmg_flag = 'Y';
            dmg_flag2 = 'Y';
        }

        /* �[�J133�I�� modify by sylvia 104.11.16 (1041030001_C4) */
        /* �s�W149�I�� modify by sylvia 106.02.16 (1050601006_C4) */
        sprintf(buf1,"SELECT count(*) FROM %s:%s %s",
                     FDBNAME,"ply_ins_type_last",
                     "WHERE ipolicy=? AND iins_type in ('31','36','133','149','231','249','531')");
        $PREPARE STM_ins1 FROM $buf1;
        $EXECUTE STM_ins1 INTO $lia_cnt USING $last_ply;
        if (lia_cnt > 0)
            lia_flag = 'Y';

        strcpy(tmp_big_sales,trim(tmp_big_sales));
   }
   else
   {   /*���ӥ�]�]�t�M�ץ�W*�B H*, N*�^*/
        sprintf(buf1,"SELECT %s %s %s %s %s %s %s FROM %s:%s a %s",
                     "icard,fcard_class,irelative_ply,inext_ply,iofficer,ileader,",
                     "nvl(ibig_comp,' '),ibig_office,ibig_sales,ibroker,iarea,",
                     "iresource,",
                     "nvl(fedr_class,' '),ibig_branch,fcomp_class,dply_begin,dply_end,mlia_prem,mdmg_prem,dpolicy,dtransfer,iofficer_prmt,isecond_hand,icard_main,",
                     "(select count(iofficer_ori) from ca_promote_officer_A where iofficer_ori = a.iofficer), ",
                     "(select count(*) from car_code  where kind = 'RN' and detail = 'CHG_APPLICANT' and detail2 = a.iofficer), ",
                     "case when icar_type in ('01','02','32','34','35','27','51','T1','T2') then 'N' else 'Y' end ",
                     FDBNAME,stm1,
                     "WHERE ipolicy=?");

        $PREPARE STM_1_2 FROM $buf1;
        $DECLARE CUR_1_2 CURSOR FOR STM_1_2;

        $OPEN CUR_1_2 USING $last_ply;
        $FETCH CUR_1_2 INTO $last_card,$fcard_class,$irelative_ply,
                            $inext_ply,$iofficer,$ileader,$ibig_comp,$tmp_big_office,
                            $tmp_big_sales, $broker,$area,$resource,
                            $fedr_class,$ibig_branch,$last_comp_class,$tp_bgn,$tp_end,
                            $tlia_prem,$tdmg_prem,$dpolicy,$dedr_begin,$iofficer_prmt,$isecond_hand,$icard_main,
                            $CntPrmt, $ichg_applicant, $chk_no_tag;

        #ifdef PRINTF_FLAG
        printf("Getp32-->irelative_ply[%s]\n",irelative_ply);
        #endif
				if (NOT_FOUND)
				{
				        memset(err_buf,0,sizeof(err_buf));
				        strcpy(err_buf,"Get302Data()1:");
				        strcat(err_buf,"select ");
				        strcat(err_buf,stm1);
				        strcat(err_buf,"-");
				        strcat(err_buf,last_ply);
				        EWRITE(userid,M_CA_NPOLICY,err_buf);
				        return M_CA_NPOLICY;
				}


				/* N*�qca_promote_officer�P�_  modify by sylvia 103.09.03 */
        /* if(iofficer[0]=='W' || (iofficer[0] == 'H' && (iofficer[1]!='0' && iofficer[1]!='1' && iofficer[1]!='2'))) */
        if ((CntPrmt > 0)||(iofficer[0] == 'L' && iofficer[6] == 'B'))
        {
       	    IsPlyB = 'Y';
        }



        /* 990527,car329 �����w�Y�@�a�O�N */

        strcpy(last_ply,trim(last_ply));

        for (i=0;i<max_ply_302_update;i++)
        {
            if (ply_302_update[i].ipolicy[0] =='*') continue;

            strcpy(check_ipolicy,trim(ply_302_update[i].ipolicy));
            if (strcmp(last_ply , check_ipolicy) == 0)
            {
                strcpy(tmp_big_sales,ply_302_update[i].ibig_sales);
                ply_302_update[i].ipolicy[0] = '*';   /* �N�������w�g�ιL�F*/
                break;
            }
        }


        /*��~���󴫾��I�N��:FROM TABLE:ca_change_office */
        if (IsPlyB != 'Y')
        {
				    strcpy(tmp_big_sales,trim(tmp_big_sales));

				    for (i=0;i<maxcount_sale;i++)
				    {
				        strcpy(check_sales,trim(ca_chg_sale[i].ibig_sales));

				        #ifdef PRINTF_FLAG
				        printf("$$$$$$$$   check_sales[%s],new_iofficer[%s],tmp_big_sales[%s],iofficer[%s]\n",
				        check_sales,ca_chg_sale[i].new_iofficer,tmp_big_sales,iofficer);
				        #endif
				        if (strcmp(tmp_big_sales , check_sales) == 0)
				        {
				            strcpy(iofficer , ca_chg_sale[i].new_iofficer);
				            break;
				        }
				    }
        }

        last_dply_bgn  = tp_bgn;

        sprintf(buf1,"SELECT count(*) FROM %s:%s %s",
                     FDBNAME,"ply_ins_type_last",
                     "WHERE ipolicy=? AND iins_type in  ('01','05','08','09','85','86','98','105','110','118','120','122','125','126','181','198','201','205','209') ");

        $PREPARE ST_ins FROM $buf1;
        $EXECUTE ST_ins INTO $dmg_cnt USING $last_ply;
        if (dmg_cnt > 0){
            dmg_flag = 'Y';
            dmg_flag2 = 'Y';
        }

        sprintf(buf1,"SELECT count(*) FROM %s:%s %s",
                     FDBNAME,"ply_ins_type_last",
                     "WHERE ipolicy=? AND iins_type in ('31','36','149','231','249','531')");
        $PREPARE ST_ins1 FROM $buf1;
        $EXECUTE ST_ins1 INTO $lia_cnt USING $last_ply;
        if (lia_cnt > 0)
            lia_flag = 'Y';

        /* �p��h�~�j���I�����B --------------------------------------------- */
        /* �]�j������B��Ūcmn144�A�G���ӥ�]�C�J�p�� modify by 061476 (1100118005_SC3)*/
        /*f_cal_comp = 'N';  ���ӥ󤣭p�� �j���I��� */
        f_cal_comp = 'Y';  /* ���ӥ���­n���̧C�����B */
		}

	   /* �������p���O��O�_��14,21,08����==> Cnt142108>0 �O14,21,08���� add by sylvia 104.01.26 (1040114003_C1)*/
	   /* �ư����@�O��O�s�W���ت�  modify by sylvia 104.02.16 (1040202006_C3) */
	   /* ����08���ت�����  (and icar_type in ('14','21','08')) modify by sylvia 105.03.23 (1050317003_C1) */
	   /* �]4A�B9A�B2B�����ػݭ��s�f�֯�������,�C�J�H�u�֫O�� modify by sylvia 1060726008_C1) */
	   Cnt142108 = 0;
	   if (chk_PA > 0)
	   {
	          $select count(*) into $Cnt142108
	            from ply_relation_last a
	           where (ipolicy = $last_ply or irelative_ply = $last_ply)
	             and icar_type in ('14','21','4A','9A','2B')
	             and nvl((select icar_type from ply_relation_last
	                       where ipolicy = a.irelative_ply),a.icar_type) not in ('2A','2C','8A','9B');
	   }

   	if ((fcard_class[0] == '2') && (strcmp(irelative_ply," ") != 0) && (strcmp(chk_no_tag,"Y") == 0))
   	{
        /* ���N�I�Y���p���j���I�O��L���P,���N�I�礣�J�p add by sylvia 105.04.18(1040901002_C1) */

        cnt_itag = 0;
        $select count(*) into $cnt_itag
           from duplic1 where ipolicy = $irelative_ply
            and ierr_no = 'E46';
        if (cnt_itag > 0)
        {
            sprintf(tmp_err,"���p���j���I�O��[%s]�L���P",irelative_ply);
            $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,' ',$tmp_err,'1','E46',$iofficer);
        }
   	}

	  strcpy(iofficer,trim(iofficer));

	   /* �ˮ֬O�_��[�� �n�O�H=�Q�O�I�H]���g��N�� add by sylvia 104.06.16 (1040528003_C1) */
	   /*  $select count(*) into $ichg_applicant
	      from car_code
	     where kind = 'RN' and detail = 'CHG_APPLICANT'
	       and detail2 = $iofficer; */



	   /* Car139 �󴫸g��N��(���O1,3):TABLE:ca_change_office */
	   /* ���O3���@���g��N��,�t�X�e���S�ʤO��O�~�ȸg��N���󥿡f�ݨD�ӷs�W�C modify by sylvia 104.06.03 (1040528003_C1) */
	  find_flag = 0;

   	for (i=0;i<maxcount_office;i++)
   	{
         strcpy(chk_iofficer,trim(ca_chg_office[i].ori_iofficer));
         if (strcmp(chk_iofficer , iofficer) == 0){
             strcpy(iofficer , ca_chg_office[i].new_iofficer);
             find_flag = 1;

             break;
         }
   	}

   #ifdef PRINTF_FLAG
      printf("Fetched ileader----------->[%s]\n",ileader);
      printf("Fetched ibig_sales-------->[%s]\n",tmp_big_sales);
      printf("11dmg_flag[%c]\n",dmg_flag);
   #endif

   /* �t�X�����~�������~��,�s�W���P�_(���b�ˮ֧�car139�B����s�~���ഫ add by sylvia 106.04.05 (1060324001_C1) */
   if (find_flag == 0)
   {
        strcpy(chk_policy,"");  strcpy(chk_iofficer,"");

        for (i=0;i<maxcount_dc;i++)
        {
            strcpy(chk_policy,trim(ca_chg_dc[i].ipolicy));
            strcpy(chk_iofficer,trim(ca_chg_dc[i].iofficer_ori));

            if((strcmp(trim(last_ply),chk_policy) == 0) &&
               (strcmp(iofficer,chk_iofficer) == 0))
            {
                strcpy(iofficer , trim(ca_chg_dc[i].iofficer_new));

                break;
            }
        }
   }


   transKA06_flag = 0;
   /* add by 071004 (1110419009_SC1_�ӽ�B2B2C���~¾����O��g��N���ץ�)*/
   /* �H�U�g���ର�޲z�H���s+A*/
   if (strcmp(iofficer,"Z6102148")==0 || strcmp(iofficer,"Z6102149")==0 ||
       strcmp(iofficer,"Z6103815")==0 || strcmp(iofficer,"Z6103816")==0 ||
       strcmp(iofficer,"Z6263703")==0 || strcmp(iofficer,"Z6263704")==0 ||
       strcmp(iofficer,"Z6402416")==0 || strcmp(iofficer,"Z6402417")==0 ||
       strcmp(iofficer,"Z6402424")==0 || strcmp(iofficer,"Z6402425")==0 ||
       strcmp(iofficer,"Z6505606")==0 || strcmp(iofficer,"Z6505607")==0
      )
   {

	   	$select ileader into $ileader from officer where iofficer=$iofficer;
	   	strcpy(iofficer , trim(ileader));
	   	strcat(iofficer , "A");
	   	strcpy(iofficer , trim(iofficer));
	   	transKA06_flag = 1;

   }


   /*strcpy(broker2,broker);*/
   /*******�D�e���O���A�O�O,�ߴګY��********/
   if (fcard_class[0] == '1')
   {
      pre_ply1_bgn = tp_bgn;
      pre_ply1_end = tp_end;
      strcpy(pre_prem1,itoa(tlia_prem+tdmg_prem));
   }
   else
   {
      pre_ply2_bgn = tp_bgn;
      pre_ply2_end = tp_end;
      strcpy(pre_prem2,itoa(tdmg_prem+tlia_prem));
      #ifdef PRINTF_FLAG
      printf("pre_prem2[%s]\n",pre_prem2);
      #endif
   }

   if (*choice=='1')
   {
      $CLOSE CUR_1_1;
      $FREE CUR_1_1;
   }
   else
   {
      $CLOSE CUR_1_2;
      $FREE CUR_1_2;
   }

   /*******Ū���g��N���̷s�޲z�H�A�̷s���ݷ~�Z���**************/
   /* 100.06.27,�q���N���ĤG���q
      �H�g��N���ܸg��H��(officer)���s�^���O�v�O�B�O�o�q���N�� �B�~�ȱ���N�� �A
      �u�q���ۭq�~�ȥN���v�h�����s�^���A�����Ѩ���O��(policy)���o(�P�u�q���N���viroute�覡)�C

      irate_type  �O�v�O
      iroute_comm �~�ȱ���N��
      icomm_obj   �I����H => �ΨӨ��o bzfrom �O�o�q���N�� ( = ���[�O�βv)    */

   $SELECT iquota,ileader,nvl(ibigcomp,' '),imgr,irate_type,iroute_comm,icomm_obj
      INTO $iquota,$ileader,$ibig_comp,$imgr,$irate_type,$iroute_comm,$icomm_obj
      FROM officer
     WHERE iofficer=$iofficer;

   if (NOT_FOUND){
	 strcpy(imgr," ");
     	 sprintf(tMsg,"�g��N�����~[%s] ",iofficer);
         $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$iofficer,$tMsg,'1','E01',$iofficer);
   }

   	if( ileader[0] != '6')
   	{   /* dummy */ }
   	else /* �����޲z�H */
		{
        strcpy( ileader_tmp, ileader);
        $SELECT iquota, ileader
           INTO $iquota, $ileader
           FROM officer
          WHERE iofficer = $ileader_tmp;
        if (SQLCODE==SQLNOTFOUND){
            $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ileader_tmp,'�޲z�H�N�����~','1','E02',$iofficer);
        }
   	}

		rc = cm_get_bzfrom("",icomm_obj,irate_type,bzfrom);
		if (rc != M_CM_OK){
			sprintf(tMsg,"���o�O�o�q���N�����~�G�g��[%s] �I����H [%s] �O�v�O[%s]",iofficer,icomm_obj,irate_type);
			$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$iofficer,$tMsg,'1','E03',$iofficer);
	  }

   	/* �t�X�O�o�q���X�s,���q���N����H��1�X��� modify by sylvia 106.01.25 (1060111005_C3) */
   	strncpy(bzfrom1,bzfrom,1);
   	bzfrom1[1]='\0';
   	printf("Trace -- bzfrom = [%s] bzfrom1=[%s]\n",  bzfrom,bzfrom1);
   	/*�ثe�u���[�O�βv�N��(iextra_charge)�v �Y�� �u�O�o�q���N�� (bzfrom)�v*/

   	if (choice[0] == '1')
   	{
          $SELECT nbranch
             INTO $nchi_full
             FROM sa_branch_type
            WHERE ibranch = $iquota;
   	}
   	else
   	{
       /* 102.12.25 :�ק�M�ץ�g�����*/
       /* ���󨮰ӥ󪺾��I�N�����G
              �O���ɩ񪺬O    A�� : �ζ�(A)=A��g��N��;����(B)�Ψ�L="A��g��H�]�w���g�P�Ӿ��I�N��(ibus_location)"
                              B�� : �ζ�(A)=A��g��N��;����(B)�Ψ�L="A��g��H�]�w���g�P�Ӿ��I�N��(ibus_location)"
              ��O�ɩ񪺬O:   A�� : ���O"A��g��H�]�w���g�P�Ӿ��I�N��(ibus_location)"
                              B�� : �ζ�(A)=A��g��N��; ����(B)�Ψ�L="A��g��H�]�w���g�P�Ӿ��I�N��(ibus_location)"
                                   ( �]�N�OB��O��ӥh�~�O���ۦP�����I�N����� )
       */
       /*if(strncmp(iofficer,"W",1)==0)*/
       /* ���MB�椣�ϥΦ^�k�g�� modify by 061476 (1100407009_SC1) */
       if ((IsPlyB=='Y')&&(iofficer[0]!='L'))
       {
	       	/* 102.12.25 �אּ�����ϥΦ^�k�g��Giofficer_prmt*/
	       	$SELECT nname
	       	   INTO $nchi_full
	       	   FROM officer
	       	  WHERE iofficer = $iofficer_prmt;
       }
       else
       {
          $SELECT nname,ibus_location
             INTO $nchi_full,$tmp_big_office
             FROM officer
            WHERE iofficer = $iofficer;
       }
   	}

   	#ifdef PRINTF_FLAG
      printf("last_ply[%s], nchi_full[%s], SQLCODE[%d], choice[%s]\n", last_ply, nchi_full, SQLCODE, choice);
   	#endif

   	$SELECT nname
    	 INTO $nname
       FROM officer
     	WHERE iofficer = $ileader ;


   	strcpy(sclmdb,get_car_full_db(last_ply));
   	strcpy(sclmdb,get_full_dbname(sclmdb));
   	strcpy(sclmdb,trim(sclmdb));

	   /*  1081218  �s�W���M�˥߱M�� add by 061476 (1081018008_SC1) */
	   /*  1030417  �s�W�֪@�M�׸g��(FS) add by sylvia(1020704005_C3) */
	   /*  1021205  �Ǵ����R�@�e�|�M��II(YFN)(89) */
	   /*  1010203, �ΫH2-5�~�ѵs�I�M��(ES1)(78)*/
	   /*  1000825, �Υ�2-5�~�ѵs�I�M��(EM5)(73)(�R1�e4), �ζ�2-6�~�ѵs�I�M��(EM6)(74)(�R1�e5) */
	   /*  1000825, �ηs2-5�~�ѵs�I�M��(YJ1)(78),�����Ť�2-6�~�ѵs�I�M��(TB)(79)*/
	   /*  990319,���ظU�o�ֱM�ס]iofficer[7,9]='FWD'�^���Ĥ@�~ => �LB��Y���Ĥ@�~  **/
	   /*  990319,�Υ�60�M�ס]iofficer[7,9]='EM6'�^�B�Υ�50�M�ס]iofficer[7,9]='EM5'�^���Ĥ@�~ => �LB��Y���Ĥ@�~  **/
	   /*  970812,�s�߶R�@�e�|��P      */
	   /** 960124,�T�{�����׸U�o�ֱM�פ��Ĥ@�~ => �LB��Y���Ĥ@�~  **/
	   /* 102.12.25 , �ק�M�ץ�g�����*/
   	sprintf(stmt,"SELECT first 1 a.ipolicy FROM %s:policy a, %s:ply_relation b WHERE %s %s %s %s %s %s %s %s",
                 sclmdb,sclmdb,
                 " a.ipolicy = b.ipolicy",
                 " AND b.fcard_class = '2' ",
                 " AND (((b.iofficer[1] = 'W' or (b.iofficer[1] = 'H' and b.iofficer[2] not in ('0','1','2')))",
                 "      AND (b.iofficer[7,8] in ('FW','HF','TB','FS') Or b.iofficer[7,9] in ('FWD','EM6','EM5','YJ1','ES1','YFL','YFN'))) ",
                 "   or (b.iofficer in (select iofficer_ori from ca_promote_officer_A where iofficer_ori[1,1] = 'N')) ",
                 "   or (b.iofficer[1] = 'L' and b.iofficer[7] = 'B'))",
                 " AND b.dply_end= ? ",
                 " AND a.iengine = ? " );
   	#ifdef PRINTF_FLAG
      printf("chk_polB[%s]\n", stmt);
   	#endif
   	if (intopt != 55 )
        $PREPARE chk_polB FROM $stmt;

	   strcpy(iofficer,trim(iofficer));
	   strcpy(icorps," ");
	   strcpy(ncorps," ");
	   strcpy(ply_group," ");
	   strcpy(iintroducer," ");  /* 102.11.29 */

   	remark1[0] = '\0';
   	remark2[0] = '\0';
   	remark6[0] = '\0';
   	remark7[0] = '\0';
   	remark4[0] = '\0';
   	remark5[0] = '\0';
   	nproject[0] = '\0';
   	fProjNoPlyB = 'N';
   	fIns21_50 = 'N';
   	qpro_month = 0;

		if (*choice=='1')
   	{
			strcpy(iins_cat," ");
      sprintf(buf1,
        "SELECT a.fassured,a.nassured,a.iassured,a.fsex,a.fmarriage,a.nuser,a.nbenef, "
        "       a.aassured,a.itel,a.iply_area,a.aassured_zip,a.ixxcard,b.ipro_year, "
        "       a.nbrand_abbr,a.ncar_abbr,a.fcar_note,a.qcylinder,a.iengine,a.ibody, "
        "       a.itag,a.mcar_price,nvl(a.iabn_type,' '),a.fcal_way,b.qply_period, "
        "       b.dply_begin,b.dply_end,b.ibrand,b.icar_type,a.qpt,a.fpt,a.plia_acc, "
        "       a.pdmg_acc,a.fhuman,a.fcomp_24,a.pdmg_align,a.pbrg_align,a.plia_align, "
        "       psex_age,plia_acc,pdmg_acc,b.fcomp_class,b.icorps,b.icar_flag,a.lia_class, "
        "       a.dmg_acc_1st,a.dmg_acc_2nd,a.dmg_acc_3rd,a.nequipment,a.psex_age_damage, "
        "       a.dbirth,a.dissue,nvl(a.iroute,' '),nvl(a.iroute_prop,' '),a.iapplicant, "
        "       a.napplicant,a.apayment_zip,a.apayment,a.itel_night,a.mobil_phone, "
        "       a.iemail,a.fapplicant,a.fsex_appl,a.dbirth_appl,a.itel_appl, "
        "       a.ndeputy_appl,a.nrelation_appl,a.ndeputy_assured,a.qpro_month,a.introducer, "
        "       nvl((select ncode from cu_code_data where itype = '97' and icode = b.icar_type),' '), "
        "       c.iroute_main,nvl(a.mequipment,0),b.dtransfer,a.iroute[1,2], "
        "       a.iassured_cntry,a.iapplicant_cntry,a.fequipment1,a.fequipment2, "
        "       a.fequipment3,a.fequipment4,a.fequipment5,a.fequipment6,a.fequipment9, "
        "       a.nequipment9,nvl(a.dbirth,' '),a.punknown_acc,a.punknown_acc,b.aemail_eply, "
        "       foccup,noccup,applicant_foccup,applicant_noccup,tmobile_appl,aemail_appl,tmobile_eply, "
        "       ireg_no,feterms,a.dinstall,a.isequence,a.ainstall_zip,a.ainstall "
        "  FROM %s:%s a, %s:%s b, cm_route c  "
        " WHERE a.ipolicy = b.ipolicy and a.iroute = c.iroute AND a.ipolicy=? ",
        FDBNAME,stm2,FDBNAME,stm1);
      #ifdef PRINTF_FLAG
      	printf("buf1=[%s]\n",buf1);
      #endif
			$PREPARE STM_2 FROM $buf1;
      $DECLARE CUR_2 CURSOR FOR STM_2;
      $OPEN CUR_2 USING $last_ply;
      $FETCH CUR_2 INTO $assuredf,$assuredn,$license,
                        $sex,$marriage,$user,$benefn,
                        $assureda,$tel,$ply_area,$aassured_zip,$ixxcard,
                        $pro_year,$brandn,$car_typen,
                        $fcar_note,$cylinder,$engine,$body,$tagnum,$car_price,
                        $abn_type,$cal_way,$qply_period,
                        $dply_begin,$dply_end,$brandi,$car_typei,
                        $qpt,$fpt,$plia_acc,$pdmg_acc,$fhuman,$fcomp_24,
                        $dmg_align,$brg_align,$lia_align,$tp_sex_age,$tp_lia_acc,$tp_dmg_acc,
                        $comp_class_last,$icorps,$icar_flag,$lia_class,$dmg_acc_1st,$dmg_acc_2nd,$dmg_acc_3rd,$inequipment,$tp_sex_age_dmg,
                        $dbirth,$dissue,$iroute,$iroute_prop,$iapplicant,$napplicant,$apayment_zip,$apayment,$tphone_con, $imovephone , $iemail,
                        $fapplicant,$fsex_appl,$dbirth_appl,$itel_appl,$ndeputy_appl,$nrelation_appl,$ndeputy_assured,$qpro_month,$iintroducer,
                        $iins_cat, $iroute_main_ply,$mequipment, $dtransfer, $iroute12, $iassured_cntry, $iapplicant_cntry,
                        $fequipment1, $fequipment2, $fequipment3, $fequipment4, $fequipment5,
                        $fequipment6, $fequipment9, $nequipment9, $chk_dbirth, $punknown_acc, $tp_unknown_acc, $aemail_eply,
                        $foccup, $noccup, $applicant_foccup, $applicant_noccup, $tmobile_appl, $aemail_appl, $tmobile_eply,
                        $ireg_no, $feterms, $dinstall, $isequence, $ainstall_zip, $ainstall;
      if (NOT_FOUND)
      {
          memset(err_buf,0,sizeof(err_buf));
          strcpy(err_buf,"Get302Data()2:");
          strcat(err_buf,"select ");
          strcat(err_buf,stm2);
          strcat(err_buf,"-");
          strcat(err_buf,last_ply);
          EWRITE(userid, M_CA_NPOLICY,err_buf);
          return M_CA_NPOLICY;
      }
      $CLOSE CUR_2;
      $FREE CUR_2;

      if (fcard_class[0] == '2')
      {
          if(strlen(trim(irelative_ply))==0)
          {
              strcpy(irel_card,ixxcard);
          }
          else
          {
              $SELECT icard
                 INTO $irel_card
                 FROM ply_relation_last
                WHERE ipolicy = $irelative_ply;

              if (SQLCODE == SQLNOTFOUND) strcpy(irel_card," ");
          }

          if (IsPlyB!='Y')
          {
	            /* =>�T�{�ӵ���ƬO�_���ŦX�T����jbarcode�B�h�~�u����O 21 +50 */
	            /* �A��50�I�ؤ����� */
	            t_count = 0;
	            $Execute preIns50_cartype INTO $t_count Using $car_typei;
            	if (t_count > 0)
            	{
	               /* ��50�I�إ~�A�S����L���N�I */
	               	t_count = 0;

	               	$EXECUTE prep_chk_ins50 INTO $t_count USING  $last_ply ;
               		if (t_count == 0) {
                  	/* ����barcode���g�찣�~ */
                  	$Execute preNo_barcode INTO $t_count Using $iofficer;

                  	if( t_count == 0) {
	                     /* �j����N�P����~��B�P�@�O�� */
	                     /* �٭n�P�@�ͤ�,�P�@�O�o�q�� add by sylvia 105.08.16 (1050718003_C1,1050714004_C1) */
	                     /* �t�X�O�o�q���X�s,���q���N����H��1�X��� modify by sylvia 106.01.25 (1060111005_C3) */
	                     /* �ק��ˮ֡G�O�o�q���N���������@�P�A�_�h������j/��� modify by 061476 (1090430005_SC1) */
	                     /* �W�[�ˮ֡G�޲z�H�ݤ@�P add by 061476 (1090616006_SC1) */
	                     	$EXECUTE prep_chkChange2 INTO $t_count USING  $irelative_ply, $license, $chk_dbirth,
	                                                   $bzfrom, $ileader, $lDplyEndBgn, $lDplyEndEnd ;
                     		if (t_count>0) {
                        		fIns21_50 = 'Y';
                        		/* �]�j���I���bzfrom��, �|���s/�¸g��N�����t��, �ӻ~�P����j,
                           		 �G�b���B�A�P�_�@��,�Y���j���I��, �N�j���I�ҫ�ĳ��50�I�اR�� add by sylvia 105.11.23 */
                        		$update policy_302 set v_prem = 0, tot_prem = 0
                          		where fcard_class = '1' and ipolicy = $irelative_ply;
                        		$delete from ply_ins_type_302 where ipolicy = $irelative_ply and iins_type != '21';
                     		}
                  	}
               		}
               		else
               		{

		                  /* �]�j���I���bzfrom��, �|���s/�¸g��N�����t��, �ӻ~�P����j,
		                     �G�b���B�A�P�_�@��,�Y���j���I��, �N�j���I�ҫ�ĳ��50�I�اR�� add by sylvia 105.11.23 */
		                  /* �t�X�O�o�q���X�s,���q���N����H��1�X��� modify by sylvia 106.01.25 (1060111005_C3) */
		                  /* �s�W�ˮ�149�I�ؤ]�n�@�֧R�� add by sylvia 106.03.13 (1060302003_C1)*/
		                  /* �ק��ˮ֡G�O�o�q���N���������@�P�A�_�h������j/��� modify by 061476 (1090430005_SC1) */
		                  /* �W�[�ˮ֡G�޲z�H�ݤ@�P add by 061476 (1090616006_SC1) */
		                  $EXECUTE prep_chkChange2 INTO $t_count USING  $irelative_ply, $license, $chk_dbirth,
		                                                $bzfrom, $ileader, $lDplyEndBgn, $lDplyEndEnd ;

		                  if (t_count > 0)
		                  {
		                      $update policy_302 set v_prem = 0, tot_prem = 0
		                        where fcard_class = '1' and ipolicy = $irelative_ply;
		                      $delete from ply_ins_type_302
		                        where ipolicy = $irelative_ply
		                          and iins_type != '21';
		                  }
               		}
							}
					}
			}
	    else
	    {
	          strcpy(irel_card,last_card);
	    }
   	}
   	else
   	{
	      /* �O�N�� */
	      strcpy(iins_cat," ");
	      sprintf(buf1,
	        "SELECT a.fassured,a.nassured,a.iassured,a.fsex,a.fmarriage,a.nuser,a.nbenef, "
	        "       a.aassured,a.itel,a.iply_area,a.aassured_zip,a.ixxcard,b.ipro_year, "
	        "       a.nbrand_abbr,a.ncar_abbr,a.fcar_note,a.qcylinder,a.iengine,a.ibody, "
	        "       a.itag,a.mcar_price,nvl(a.iabn_type,' '),a.fcal_way,b.qply_period, "
	        "       b.dply_begin,b.dply_end,b.ibrand,b.icar_type,a.qpt,a.fpt,a.plia_acc, "
	        "       a.pdmg_acc,a.fhuman,a.fcomp_24,a.pdmg_align,a.pbrg_align,a.plia_align, "
	        "       psex_age,plia_acc, pdmg_acc,b.fcomp_class,b.icar_flag,a.lia_class, "
	        "       a.dmg_acc_1st,a.dmg_acc_2nd,a.dmg_acc_3rd,a.nequipment,a.psex_age_damage, "
	        "       a.dbirth,a.dissue,nvl(a.iroute,' '),nvl(a.iroute_prop,' '),a.iapplicant, "
	        "       a.napplicant,a.apayment_zip,a.apayment,a.itel_night,a.mobil_phone, "
	        "       a.iemail,a.fapplicant,a.fsex_appl,a.dbirth_appl,a.itel_appl,a.ndeputy_appl, "
	        "       a.nrelation_appl,a.ndeputy_assured,a.qpro_month,a.introducer, "
	        "       nvl((select ncode from cu_code_data where itype = '97' and icode = b.icar_type),' '), "
	        "       c.iroute_main,nvl(a.mequipment,0),b.dtransfer,a.iroute[1,2], "
	        "       a.iassured_cntry,a.iapplicant_cntry,a.fequipment1,a.fequipment2, "
	        "       a.fequipment3,a.fequipment4,a.fequipment5,a.fequipment6,a.fequipment9, "
	        "       a.nequipment9,nvl(a.dbirth,' '),a.punknown_acc,a.punknown_acc,b.aemail_eply, "
	        "       foccup,noccup,applicant_foccup,applicant_noccup,tmobile_appl,aemail_appl,tmobile_eply, "
	        "       ireg_no,feterms,a.dinstall,a.isequence,a.ainstall_zip,a.ainstall "
	        "  FROM %s:%s a, %s:%s b, cm_route c  "
	        " WHERE a.ipolicy = b.ipolicy and a.iroute = c.iroute AND a.ipolicy=? ",
	        FDBNAME,stm2,FDBNAME,stm1);
	      $PREPARE STM_2_1 FROM $buf1;
	      $DECLARE CUR_2_1 CURSOR FOR STM_2_1;

	      $OPEN CUR_2_1 USING $last_ply;
	      $FETCH CUR_2_1
	        INTO $assuredf,$assuredn,$license,
	             $sex,$marriage,$user,$benefn,
	             $assureda,$tel,$ply_area,$aassured_zip,$ixxcard,
	             $pro_year,$brandn,$car_typen,
	             $fcar_note,$cylinder,$engine,$body,$tagnum,$car_price,
	             $abn_type,$cal_way,$qply_period,
	             $dply_begin,$dply_end,$brandi,$car_typei,
	             $qpt,$fpt,$plia_acc,$pdmg_acc,$fhuman,$fcomp_24,
	             $dmg_align,$brg_align,$lia_align,$tp_sex_age,$tp_lia_acc,$tp_dmg_acc,
	             $comp_class_last,$icar_flag,$lia_class,$dmg_acc_1st,$dmg_acc_2nd,$dmg_acc_3rd,$inequipment,$tp_sex_age_dmg,
	             $dbirth,$dissue,$iroute,$iroute_prop,$iapplicant,$napplicant,$apayment_zip,$apayment,$tphone_con, $imovephone , $iemail,
	             $fapplicant,$fsex_appl,$dbirth_appl,$itel_appl,$ndeputy_appl,$nrelation_appl,$ndeputy_assured,$qpro_month,$iintroducer,
	             $iins_cat, $iroute_main_ply, $mequipment, $dtransfer, $iroute12, $iassured_cntry, $iapplicant_cntry,
	             $fequipment1, $fequipment2, $fequipment3, $fequipment4, $fequipment5,
	             $fequipment6, $fequipment9, $nequipment9, $chk_dbirth, $punknown_acc, $tp_unknown_acc, $aemail_eply,
	             $foccup, $noccup, $applicant_foccup, $applicant_noccup, $tmobile_appl, $aemail_appl, $tmobile_eply,
	             $ireg_no, $feterms, $dinstall, $isequence, $ainstall_zip, $ainstall;

	      if (NOT_FOUND) {

	          memset(err_buf,0,sizeof(err_buf));
	          strcpy(err_buf,"Get302Data()2_1:");
	          strcat(err_buf,"select ");
	          strcat(err_buf,stm2);
	          strcat(err_buf,"-");
	          strcat(err_buf,last_ply);
	          EWRITE(userid, M_CA_NPOLICY,err_buf);
	          return M_CA_NPOLICY;
	      }

      	if (fcard_class[0] == '2'){
						if (IsPlyB=='Y')
		         {
		            /* 102.12.25 B��g��i�ഫ�L�Giofficer_prmt*/
		       	     $SELECT iroute
		       	        INTO $iroute
		       	        FROM officer
		       	       WHERE iofficer = $iofficer;
		         }

		         /*970418, �Y�ذe�I�ج����[�I�A�@��|��"�ƫ��[�ذe�I�ؤ覡"�A�����M�סA���|��car130���]�w�A
		                 �礣�|��B��A�Ȧ�A����O�A�@��]�S���O��q�T��wording,�Ҷ��B�z���ئ�(ex.�Υ��u�樮�@�ӱM�סv)�G
		                  (1)�e����O���e���A�ذe��56�I�ة�O�O�椤�H��ܡ�(�M�ץ�)�����N�C
		                  (2)��O����Y������ܡu�樮�@�ӱM�סv
		                  (3)�u�O��q�T��v������ܰT���C
		                  (4)��O��ĳ�I�ؤ�������ذe��56�I�ءC                     */
		         /* �樮�@�ӱM�סGA����O�N��=62 ; �g�P��=�Υ� (A21*) ; �ذe�I��=56 */
		     	 	if( (strncmp(iofficer,"A21",3)==0)&&(equip_cmp(inequipment,"62") == True)){
		            fProjNoPlyB = 'Y';
		     	 	}

         		if(strlen(trim(irelative_ply))==0)
		         {
		              strcpy(irel_card,ixxcard);
		         }
		         else
		         {
		              $SELECT icard
		                INTO $irel_card
		                FROM ply_relation_last
		               WHERE ipolicy = $irelative_ply;
		              if (SQLCODE == SQLNOTFOUND) strcpy(irel_card," ");
		         }

      	}else{
     	  		strcpy(irel_card,last_card);
      	}
      	$CLOSE CUR_2_1;
      	$FREE CUR_2_1;
   	}


		/* ����[�������^]���O(���O�N��091)  add by sylvia 103.07.04 (1020619003_C1) */
		strcpy(inequipment,equip_delete(inequipment,"091"));

		/* 101.01.10 �t�P�����ɷs�W���Τ�ΥN�X�ܧ� */
		$Select ibrand_new Into $brandi From tmp_ibrand Where ibrand=$brandi;

		/* ���d�q���N�� add by 061476 (1080220006_SC1) */
		if ((strncmp(iroute,"BA",2)==0)||((strncmp(iroute,"I",1)==0)&&(strncmp(ileader,"R",1)==0)))
		{
		   	t_count = 0;
		   	$SELECT count(*) INTO $t_count
		   	FROM car_code
		   	WHERE kind = 'RN' AND detail = 'CHG_ROUTE'
		   	AND detail2 = $iroute_main_ply;

		   	if (t_count > 0)
		   	{
		   		$SELECT nvl(iroute_full,"") INTO $new_route
		   		FROM cm_route_sales
		   		WHERE isales = $tmp_big_sales
		   		AND iroute = $iroute_main_ply
		   		AND dexpire IS null;

   				if (SQLCODE == SQLNOTFOUND) strcpy(new_route," ");

   				strcpy(new_route,trim(new_route));
   				if (strlen(trim(new_route))>0) strcpy(iroute, new_route);
   			}
   	}

		/* 980815, �]���s�Wdbirth ,dissue*/
		if ((assuredf[0] == '2') || (assuredf[0] == '4') || (assuredf[0] == '6')){
		  	birth[0] = '\0';
		}else{
		  	strcpy( birth ,cm_cdate_str_100(dbirth));  /* Date(long)�ন����~���(yyy/mm/dd) */
		}
   	printf("Trace -- birth = [%s] \n",  birth);
   	strcpy( issue ,cm_cdate_str_100(dissue));  /* Ex. 098/08/15 */
   	strncpy(issue_ym,issue,6);  /* Ex. 098/08 */
   	printf("Trace -- issue_ym = [%s] \n",  issue_ym);

   	#ifdef PRINTF_FLAG
    	  printf("irel_card[%s]\n",irel_card);
   	#endif

   	/* �H�g��N���i��P�_,�˵��ӳ�O�_�ݲ��sbarcode ����O��,�P�ɨ��o�����]�w*/
   	if (fBarcode_setup == 'Y')
   	{
				ioff_count = 0;
				strcpy(car_typei, trim(car_typei));

				  $SELECT count(*),a.icode_no,a.fcomp_disc,a.mcomp_disc,a.mcomp_disc_mot1,a.mcomp_disc_mot2,a.fvol_disc,a.pvol_disc,a.pvol_disc_mot1,a.pvol_disc_mot2,a.fmot_insure,a.fcar_insure
				   INTO $ioff_count,$s_icode_no,$s_fcomp_disc,$s_mcomp_disc,$s_mcomp_disc_mot1,$s_mcomp_disc_mot2,$s_fvol_disc,$s_pvol_disc,$s_pvol_disc_mot1,$s_pvol_disc_mot2,$s_fmot_insure,$s_fcar_insure
				   FROM sysdb:car302_barcode_setup a, tmp_barcode_officer b
				  WHERE a.icode_no = b.icode_no
				    AND (b.iofficer = $iofficer Or b.iofficer = $iroute ) and a.icode_no <> 'EB000001'
    			GROUP BY a.icode_no,a.fcomp_disc,a.mcomp_disc,a.mcomp_disc_mot1,a.mcomp_disc_mot2,a.fvol_disc,a.pvol_disc,a.pvol_disc_mot1,a.pvol_disc_mot2,a.fmot_insure,a.fcar_insure;

		      /* �Yioff_count>1 �Bs_icode_no���P,�h���ܳ]�w�ɳ]�w�覡���~,�ɭP�@�Ӹg��N���P�ɲŦX�G�ճ]�w�� */
		      if(SQLCODE == SQLNOTFOUND){
		        	fBarcode = 'N';
      		}else{
         			fBarcode = 'Y';
		        	#ifdef PRINTF_FLAG
			        	printf(" => s_icode_no   = [%s]\n " , s_icode_no);
			        	printf(" => s_fcomp_disc = [%s]\n " , s_fcomp_disc);
			        	printf(" => s_mcomp_disc = [%f]\n " , s_mcomp_disc);
			        	printf(" => s_mcomp_disc_mot1 = [%f]\n " , s_mcomp_disc_mot1);
			        	printf(" => s_mcomp_disc_mot2 = [%f]\n " , s_mcomp_disc_mot2);
			        	printf(" => s_fvol_disc  = [%s]\n " , s_fvol_disc);
			        	printf(" => s_pvol_disc  = [%f]\n " , s_pvol_disc);
			        	printf(" => s_pvol_disc_mot1  = [%f]\n " , s_pvol_disc_mot1);
			        	printf(" => s_pvol_disc_mot2  = [%f]\n " , s_pvol_disc_mot2);
			        	printf(" => s_fmot_insure = [%s]\n " , s_fmot_insure);
			        	printf(" => s_fcar_insure = [%s]\n " , s_fcar_insure);
		        	#endif
      		}
   		}else{
      	fBarcode = 'N';
   		}

	   	/*** �O��q�T��( �@���]�i��ݭn ) ***/
	   	/*** EX:B��LA��ɡA��B��X��O��   ***/
	   	if (fcard_class[0] == '2')
	   	{
      		/* 102.12.25 , �ק�M�ץ�g�����G�g��N���Ĥ@�X = ��W��or (�g��N���Ĥ@�X  = ��M��and �g��N���ĤG�X not in (��0��,��9��)) */
    			/*if (((ibig_comp[0]!=' ')&&(ibig_comp[0]!='\0'))||(iofficer[0] == 'W'))*/
    			if (((ibig_comp[0]!=' ')&&(ibig_comp[0]!='\0'))|| (IsPlyB=='Y') )
        	{
        			/* 102.12.25 A�BB����}�� */
        			if (IsPlyB=='Y'){
        					$DECLARE CUR_plychk1_b CURSOR FOR plychk1_b;
		        			$OPEN CUR_plychk1_b USING $last_ply;
							}else{
		        			$DECLARE CUR_plychk1 CURSOR FOR plychk1;
		        			$OPEN CUR_plychk1 USING $last_ply;
							}

							i = 0;
							BPlyClosed = 1;
							iRemark_yn = 0;
							strcpy(sIprmt," ");
							strcpy(note1," ");
							while(1)
							{
									if (IsPlyB=='Y'){
											$FETCH CUR_plychk1_b
		                		INTO $Aipolicy, $nproject, $nprocomp, $nproprem, $Biofficer, $BPlyClosed, $iRemark_yn, $sIprmt;
		        			}else{
		        					$FETCH CUR_plychk1
		                		INTO $Aipolicy, $nproject, $nprocomp, $nproprem, $Biofficer, $BPlyClosed, $iRemark_yn, $sIprmt;
		        			}

					        if (SQLCODE == SQLNOTFOUND) break;
					        strcpy(note1, sIprmt); /* �M�ץN���g�Jnote1��� add by sylvia 104.05.08 */


		        			/*if (i>1) break;*/ /* plychk1 ��A�BB�����ӬO�@��@ */

									#ifdef PRINTF_FLAG
											printf("last_ply[%s], nproject[%s], Biofficer[%s], BPlyClosed[%d], SQLCODE[%d]\n", last_ply, nproject, Biofficer, BPlyClosed, SQLCODE);
							        printf("last_ply[%s], nproject[%s], Biofficer[%s], BPlyClosed[%d], SQLCODE[%d]\n", last_ply, nproject, Biofficer, BPlyClosed, SQLCODE);
							        printf("BPlyClosed[%d], iRemark_yn[%d]\n", BPlyClosed,iRemark_yn);
					        #endif

									if (BPlyClosed==0){
											remark1[0] = '\0';  remark2[0] = '\0';  remark6[0] = '\0';
											remark7[0] = '\0';  remark4[0] = '\0';  remark5[0] = '\0';

											if (iRemark_yn != 1)
											{
			   			            rfmtlong(nproprem,"&,&&&",s_nequprem);
			   			            sprintf(remark_tmp1,"%s%s%s%s",
   			                                "���˷R���Ȥ�A�P�±z��h�~��O�ɰѥ[",
   			                                trim(nprocomp), rtrim(nproject),
   			                                "�M�סA�����@�z���v�Q�A�����z�ȥ��V��g�P��" );

													sprintf(remark_tmp2,"%s%s%s%s",
   			                                "��z��O�B�y�t���N�D�I(�D���[�I)�O�O�F", s_nequprem ,"���H�W�z�A�R���Y",
   			                                "�i�ɦ����w���ѵs�I�O�١I");

                          #ifdef PRINTF_FLAG
   			            				printf("remark_tmp1[%s]\n", remark_tmp1);
   			            			#endif

   			            			if(remark1[0] == '\0')
			   			            {
			   			                strcpy(remark1, remark_tmp1);
			   			                strcpy(remark2, remark_tmp2);
			   			            }
			   			            else
			   			            {
			   			                sprintf(remark_tmp1,"%s%s%s",
			   			                                    "���˷R���Ȥ�A�P�±z��h�~�ѥ[",
			   			                                    rtrim(nproject),
			   			                                    "�Ω����O�T�M�סA�����@�z���v�Q�����z�ȥ��V��g�P�ӿ�z��");

			                                        sprintf(remark_tmp2,
			   			                        "�O�B�y���t���C�����I�����N�I�O�O�F 8,000���H�W�z�R���Y"
			   			                        "�ɬ��w���ѵs�I�O�٤Τ��~�K�U���������O�T�A��");

			                                        strcpy(remark1, remark_tmp1);
			   			                strcpy(remark2, remark_tmp2);
			   			            }
			        				}
			    				}else{ /* �M�ר�� */
			    						strcpy(nproject," ");
			    						strcpy(note1, " ");
			    				}
			    				i++ ;
		    			}

					    if (IsPlyB=='Y'){
					    	$CLOSE CUR_plychk1_b;
					        $FREE CUR_plychk1_b;
					    }else{
					        $CLOSE CUR_plychk1;
					        $FREE CUR_plychk1;
					    }
	    		}

			    if (iofficer[0]=='A' || iofficer[0]=='F' || IsPlyB=='Y' )
			    {
				    	/* 102.12.25 A�BB����}�� */
				    	if (iofficer[0]=='A' || iofficer[0]=='F')
				    	{
				    		$DECLARE CUR_plychk2_1 CURSOR FOR plychk2_1;
				    		$OPEN CUR_plychk2_1 USING $last_ply;
				    	}else if (IsPlyB=='Y'){
				    		$DECLARE CUR_plychk2_1_b CURSOR FOR plychk2_1_b;
				    		$OPEN CUR_plychk2_1_b USING $last_ply;
				    	}

					    i = 0;
					    BPlyClosed = 1;
					    iRemark_yn = 0;
					    strcpy(sIprmt," ");
					    strcpy(note1," ");

					    /* strcpy(nproject," "); nproprem = 0; ����M�ũ��k�s,
					      �]�� CUR_plychk2_1 �i��S����� �Ӥ��e�i�঳��L�M�רϥΤFnproject */
					    strcpy(tmp_nproject1," "); strcpy(tmp_nproject2," ");
					    tmp_nproprem1 = 0;tmp_nproprem2 = 0;
					    while(1)
					    {
						    	/* 102.12.25 A�BB����}�� */
						    	if (iofficer[0]=='A' || iofficer[0]=='F')
						    	{
						    		$FETCH CUR_plychk2_1
						    		INTO $Aipolicy, $nproject, $nprocomp, $nproprem, $Biofficer, $BPlyClosed, $iRemark_yn, $sIprmt;
						    	}
						    	else if (IsPlyB=='Y')
		    					{
						    			$FETCH CUR_plychk2_1_b
						    			INTO $Aipolicy, $nproject, $nprocomp, $nproprem, $Biofficer, $BPlyClosed, $iRemark_yn, $sIprmt;
						      }
		        			if (SQLCODE == SQLNOTFOUND) break;

		        			strcpy(nproject,trim(nproject)) ;
		        			strcpy(note1,sIprmt);  /* �M�ץN���g�Jnote1��� add by sylvia 104.05.08 */

					        #ifdef PRINTF_FLAG
					        printf("last_ply[%s], nproject[%s],nproprem[%d], Biofficer[%s], BPlyClosed[%d], SQLCODE[%d]\n", last_ply, nproject,nproprem, Biofficer, BPlyClosed, SQLCODE);
					        #endif

					        /* �䤤�@����M�� �f�t �ѵs�M�� */
					        if (BPlyClosed==0)
					        { /* �� f_xx_ply �M�סA�B����� */
			        				if(strncmp(Biofficer+(7-1),"AHL", 3) == 0){
			            				f_AHL_ply = 'Y';   /* 970102, ���p1519�M(AHL)  => �ηs�A���M�w����,�������N */
			            				strcpy(tmp_nproject1, nproject);
			            				tmp_nproprem1 = nproprem;
			        				}else if(strncmp(Biofficer+(7-1),"YF6",3) == 0){
			            				f_YF6_ply = 'Y';   /** DLR50�M�� **/
			            				strcpy(tmp_nproject2, nproject);
			            				tmp_nproprem2 = nproprem;
			        				}else if(strncmp(Biofficer+(7-1),"UC",2) == 0){
                      		f_UC_ply = 'Y';   /** �W�ߤA���M�� **/
			            				strcpy(tmp_nproject1, nproject);
			            				tmp_nproprem1 = nproprem;
			        				}else if(strncmp(Biofficer+(7-1),"UF",2) == 0){
			            				f_UF_ply = 'Y';   /** �W��DLR50�M�� **/
			            				strcpy(tmp_nproject2, nproject);
			            				tmp_nproprem2 = nproprem;
			        				}else if(strncmp(Biofficer+(7-1),"YFC",3) == 0){
			            				f_YFC_ply = 'Y';   /** �έ�A���M�� **/
			            				strcpy(tmp_nproject1, nproject);
			            				tmp_nproprem1 = nproprem;
			        				}else if(strncmp(Biofficer+(7-1),"YFB",3) == 0){
                          f_YFB_ply = 'Y';   /** �έ�50�M��(��) **/
			            				strcpy(tmp_nproject2, nproject);
			            				tmp_nproprem2 = nproprem;
			        				}
									}
									else
									{
											/* �� f_xx_ply �M�סA�B�w��� */
			        				/* �u�n���䤤�@�ӱM�ץ����,�h nproject�N���i�H�O " " */
			    						/*strcpy(nproject," ");*/
			    						if(strncmp(Biofficer+(7-1),"AHL", 3) == 0){
			        						f_AHL_ply = 'N';   /* 970102, ���p1519�M(AHL)  => �ηs�A���M�w����,�������N */
							        }else if(strncmp(Biofficer+(7-1),"YF6",3) == 0){
							        	f_YF6_ply = 'N';   /** DLR50�M�� **/
							        }else if(strncmp(Biofficer+(7-1),"UC",2) == 0){
							        	f_UC_ply  = 'N';   /** �W�ߤA���M�� **/
							        }else if(strncmp(Biofficer+(7-1),"UF",2) == 0){
							        	f_UF_ply  = 'N';   /** �W��DLR50�M�� **/
							        }else if(strncmp(Biofficer+(7-1),"YFC",3) == 0){
							        	f_YFC_ply = 'N';   /** �έ�A���M�� **/
							        }else if(strncmp(Biofficer+(7-1),"YFB",3) == 0){
							        	f_YFB_ply = 'N';   /** �έ�50�M��(��) **/
							        }

			        				#ifdef PRINTF_FLAG
							        printf("trace inequipment[%s]\n ",inequipment);
							        printf("trace Aiequip[%s]\n ",Aiequip);
							        #endif
			    						strcpy(inequipment, equip_delete(inequipment,Aiequip)); /* 102.03 */
			    						strcpy(note1, " ");
									}
								i++ ;
		    			}

				    /* 102.12.25 A�BB����}�� */
				    if (iofficer[0]=='A' || iofficer[0]=='F'){
				      $CLOSE CUR_plychk2_1;
				      $FREE CUR_plychk2_1;
				    }else if (IsPlyB=='Y'){
				      $CLOSE CUR_plychk2_1_b;
				      $FREE CUR_plychk2_1_b;
				    }

				    /** �p�G���ѵs�I�M�ץB���f�t�e���骺�M�סA�hnproject�H�e���骺�M�צW�٬��D **/
				    if (((f_YF6_ply == 'Y')&&(f_AHL_ply == 'Y')) ||
				    	 ((f_UF_ply  == 'Y')&&(f_UC_ply  == 'Y')) ||
				    	 ((f_YFB_ply == 'Y')&&(f_YFC_ply == 'Y')))
				    {
				    	strcpy(nproject, tmp_nproject1);
				     	/*if (f_UF_ply  == 'Y') tmp_nproprem2 = 2000;*/
				        sprintf(remark1,"�˷R���Ȥ�P�±z�h�~�ѥ[%s��%s�M�סA�����@�z���v�Q�A�����z�ȥ����2�~�V",tmp_nproject1,tmp_nproject2);
				        sprintf(remark2,"��g�P����O�y���N�I�D�I�O�O�F%d���H�W�z�A�R���Y�i�ɦ����������I�ά��w���ѵs�I�O�١I",tmp_nproprem2);
				    }
		    		else
				    {   /* �u���ѵs�Ψ����@B��*/
				    	if ((f_YF6_ply == 'Y')||(f_UF_ply  == 'Y')||(f_YFB_ply  == 'Y')){ /* �ѵs*/
				                 /*if (f_UF_ply  == 'Y') tmp_nproprem2 = 2000;*/
					         sprintf(remark1,"�˷R���Ȥ�A�P�±z��h�~��O�ɰѥ[%s�M�סA�����@�z���v�Q�A�����z�ȥ��V��g�P",tmp_nproject2);
					         sprintf(remark2,"�ӿ�z��O�B�y�t���N�D�I(�D���[�I)�O�O�F%d���H�W�z�A�i�ɦ����w���ѵs�I�O�١I",tmp_nproprem2);
				    	}else if ((f_AHL_ply == 'Y')||(f_UC_ply  == 'Y')||(f_YFC_ply  == 'Y')){ /* ����*/
					         sprintf(remark1,"�˷R���Ȥ�A�P�±z��h�~��O�ɰѥ[%s�M�סA�����@�z���v�Q�A�����z�ȥ��V��g�P�ӿ�z��",tmp_nproject1);
					         sprintf(remark2,"�O�B�y�t���N�D�I(�D���[�I)�O�O�F%d���H�W�z�A�R���Y�i�ɦ����������I�O�١I",tmp_nproprem1);
				    	}
				    }
	   			} /* if (iofficer[0]=='A' || iofficer[0]=='F' || IsPlyB=='Y' ) end */
    	}

	    #ifdef PRINTF_FLAG
	      printf("Trace -- 1111111remark1 = [%s] \n",  remark1);
	      printf("bef assuredf[%s]\n",assuredf);
	      printf("bef car_typei[%s]\n",car_typei);
	    #endif

	    /* �q���N��KA02->KA03�A�B�����B�אּ350�� add by 061476 109.04.08 (1090305002_SC1)*/
	    /* �q���N��KA03->KA04 modify by 061476 (1091022004_SC1) */
	    /* �q���N��KA04->KA05 modify by 061476 (1100106005_SC1) */
	    /* �q���N��KA05->KA06 modify by 061476 (1100302002_SC1) */
	    if((strncmp(iroute,"KA02",4) == 0) || (strncmp(iroute,"KA03",4) == 0) ||
	       (strncmp(iroute,"KA04",4) == 0) || (strncmp(iroute,"KA05",4) == 0))
	    {
	    	strcpy(iroute,"KA06");
	    }

	    /* add by 071004 (1110419009_SC1_�ӽ�B2B2C���~¾����O��g��N���ץ�)*/
	    /* �q���ରKA06*/
	    if (transKA06_flag==1)
	    {
	    	strcpy(iroute,"KA06");
	    }

	    /* �k�H  ����04->19  ����06->20  */
	    if ((assuredf[0] == '2') || (assuredf[0] == '4') || (assuredf[0] == '6'))
	    {
	      if (strncmp(car_typei,"04",2) == 0 )
	         strcpy(car_typei,"19");
	      else if (strncmp(car_typei,"06",2) == 0)
	         strcpy(car_typei,"20");
	    }
	    else
	    {
	      if ((strncmp(car_typei,"19",2) == 0 )||(strcmp(car_typei,"9A") == 0)||
	          (strcmp(car_typei,"9B") == 0))
	      {
	         strcpy(car_typei,"04");

	         /* �]9A�����ؤ��P,����������I�O  add by sylvia 104.012.16 (1040202006_C3) */
	         $select ncode into $iins_cat
	           from cu_code_data
	           where itype = '97'
	           and  icode = $car_typei;
	      }
	      else if (strncmp(car_typei,"20",2) == 0)
	         strcpy(car_typei,"06");
	    }

	    /* �����쥻���� icar_type_ori*/
	    strcpy( icar_type_ori, car_typei);
	    strcpy( ichange_note, " ");
	    lDbirth_ori = 0;
	    dbirthday_tmp = 0;
	    strcpy( birth_ori, " ");

	    if (fcard_class[0] == '1')
	    {
	    	/* 951113,���T�j����O������� ca_trade_diff*/
	        ilast_card_tmp[0]='\0';

	        /* 960528, �קK�p�f�������i��]��O��s�@�ɶ��t,���ͪk�H�P�۵M�H�L��ҭP���ؤ��P�����p */
	        /* �k�H  ����04->19  ����06->20  */
	        if ( (assuredf[0] == '2') || (assuredf[0] == '4') || (assuredf[0] == '6'))
	        {
	        	if (strncmp(car_typei,"04",2) == 0 )
		            strcpy(car_typei,"19");
		        else if (strncmp(car_typei,"06",2) == 0)
		            strcpy(car_typei,"20");
					}
					else
					{
					        if (strncmp(car_typei,"19",2) == 0 )
					            strcpy(car_typei,"04");
					        else if (strncmp(car_typei,"20",2) == 0)
					            strcpy(car_typei,"06");
					}
			}
    	else
    	{
	        /* ����~���N�I������(�ثe�Ȯ�W,�D�q���]�w��car_code.kind = 'PA') add by sylvia 104.02.22  */
	        if (strcmp(iroute12,"PA") == 0)
	        {
	            $select a.icar_type_new into $icar_type_tmp2
	               from ca_exception a , cm_route b
	              where a.iroute = b.iroute
	                and a.ipolicy = $last_ply
	                and b.iroute_main = $iroute_main_ply
	                and a.icar_type_ori = $car_typei;

	            if (NOT_FOUND)
	                strcpy(car_typei,trim(car_typei));
	            else
	                strcpy(car_typei,trim(icar_type_tmp2));
	        }
    	}

	    if (strncmp(car_typei,icar_type_ori,2) != 0){
	        sprintf(ichange_note,"(%s->%s)",icar_type_ori,car_typei);
	    }

	    if ( (assuredf[0] == '1') || (assuredf[0] == '3') || (assuredf[0] == '5'))
	    {
	        if ((lDbirth_ori !=0)&&(lDbirth!=0)&&(lDbirth_ori!=lDbirth))
	        {
	            strcpy(birth_ori, trim(birth_ori));
		    	strcpy(birth_new, trim(birth));
		    	strSearchReplace(birth_new,"/","");  /* �h�� "/" */
		    	strSearchReplace(birth_ori,"/","");

	            if (strlen(trim(ichange_note))>0){
	                strcpy(ichange_note_tmp, trim(ichange_note));
	                sprintf(ichange_note,"%s(%s->%s)", ichange_note_tmp, birth_ori, birth_new);
	            }else{
	            	sprintf(ichange_note,"(%s->%s)", birth_ori, birth_new);
	            }
	        }
    	}
	    #ifdef PRINTF_FLAG
	    printf(" ichange_note = [%s]\n " , ichange_note);
	    printf("aft assuredf[%s]\n",assuredf);
	    printf("aft car_typei[%s]\n",car_typei);
	    #endif

	    /* 31���ؤ��J�p(�]�n�C�L�򥻸��, �ķJ�p��R��) add by sylvia 106.03.24 (1060220002_C1) */
	    if (strcmp(car_typei, "31") == 0)
	        $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,' ','�S�w�I��/������O�ݭ��s���w���e���J�p','1','E48',$iofficer);

	   	/*�e���~�֡A���d�A����ߴګY��*******/
	   	sprintf(sp_sex_age,"%5.2f",tp_sex_age);
	   	sprintf(sp_sex_age_dmg,"%5.2f",tp_sex_age_dmg);

	   	if (fcard_class[0] == '2')
	   	{
	      sprintf(sp_lia_acc,"%5.2f",tp_lia_acc);
	      sprintf(sp_dmg_acc,"%5.2f",tp_dmg_acc);
	      sprintf(sp_unknown_acc,"%5.2f",tp_unknown_acc);
	   	}

   		strcpy(tmp_ply, substring(last_ply,6,2));

			$SELECT fcar_class, ncode
	       INTO $fcar_class, $car_typen
	       FROM car_type
	      WHERE fclass='1'
	        AND icode=$car_typei;

			if (NOT_FOUND)
			{
			   	/* �s���I�صL����  add by 061476 107.04.12 (1061108001_SC7) */
			   	if (strncmp(tmp_ply,"V7",2)== 0)
			   	{

   				}
   				else
			   	{
			   	    strcpy( car_typei, icar_type_ori);

			   	    $SELECT fcar_class, ncode
			   	       INTO $fcar_class, $car_typen
			   	       FROM car_type
			   	      WHERE fclass='1'
			   	        AND icode=$car_typei;

			   	    if (NOT_FOUND)
			   	    {
			   	    	memset(err_buf,0,sizeof(err_buf));
			   	    	strcpy(err_buf,"Get302Data():");
			   	    	strcat(err_buf,"select car_type");
			   	    	strcat(err_buf,"-");
			   	    	strcat(err_buf,"not found");
			   	    	EWRITE(userid,M_CA_NCARTYPE,err_buf);
			   	    	return M_CA_NCARTYPE;
			   	    }
			   	}
   		}

		   /*abn_type[0]='\0';��Oabn_type�M���ť�*/
		   strcpy(tmp_dply_end_pre  ,cm_cdate_str_100(dply_end));     /* 102.03,����O�� ����� */
		   strcpy(tmp_dply_begin_pre,cm_cdate_str_100(dply_begin));   /* 102.03,����O�� �ͮĤ� */
		   dply_begin_pre = dply_begin;

		   #ifdef PRINTF_FLAG
		      printf("3.3 tmp_dply_end_pre[%s]\n",tmp_dply_end_pre);
		   #endif

   		find_flag = 0;
   		frate[0]='\0';
   		strcpy(fcard_class, trim(fcard_class));

   		if (fcard_class[0] == '1'){
      		strcpy(frate,tmp_frate1);
   		}else{
      		strcpy(frate,tmp_frate2);
   		}

   		#ifdef PRINTF_FLAG
      	  printf("frate[%s]  tmp_frate2[%s]\n" , frate, tmp_frate2);
        	printf("iofficer[%c]  fcard_class[%c]\n" , iofficer[0], fcard_class[0]);
   		#endif

			if (car_price==0)
   		{
	      /* �אּ����<ipro_year ���̤j�~��, �A�䤣��~�� >ipro_year ���̤p�~��
	         ��: ��J���s�y�~����2014, �Y�d�L2014�~�������, �h���� <2014����1�� (2013), �A�d����h�� >2014����@��(2015)
	         modify by sylvia 104.09.15  (1040714001_C3) */
	      $SELECT first 1 mcar_price INTO $car_price
	         FROM ca_car_model
	        WHERE ibrand=$brandi
	          AND ipro_year=$pro_year
	          AND drate=(select drate from ca_rate_date
	                      where itable = 'ca_car_model' and icode = $tmp_frate2 );

      	if (NOT_FOUND)
      	{
	         $SELECT first 1 mcar_price INTO $car_price
	            FROM ca_car_model
	           WHERE ibrand=$brandi
	             AND ipro_year < $pro_year
	             AND drate=(select drate from ca_rate_date
	                      where itable = 'ca_car_model' and icode = $tmp_frate2 )
	             order by ipro_year desc;

         	if (NOT_FOUND)
         	{
            $SELECT first 1 mcar_price INTO $car_price
               FROM ca_car_model
              WHERE ibrand=$brandi
                AND ipro_year > $pro_year
                AND drate=(select drate from ca_rate_date
                      where itable = 'ca_car_model' and icode = $tmp_frate2 )
                order by ipro_year ;

         	}
      	}
			} /* end car_price==0 */


	   /************************** STEP 2 ***********************************/
	   #ifdef PRINTF_FLAG
	      printf(">>>>step2 stm1[%s] stm2[%s]\n",stm1,stm2);
	   #endif
	   /************************** STEP 3 ***********************************/
	   step3:
	      #ifdef PRINTF_FLAG
	         printf("3.5 >>>>step3 fcard_class[%s]\n",fcard_class);
	      #endif

	   /*---get newest psex_age---*/
	   if ((assuredf[0]=='1') || (assuredf[0]=='3') || (assuredf[0] == '5'))   /*�۵M�H*/
	   {
	      /* birth, tmp_dply_end_pre is CY/MM/DD */
	      rc = get_age( birth, tmp_dply_end_pre, &age, v_sMsg);
	      if( rc != M_CM_OK)  return rc;

	      if (strlen(trim(sex)) == 0)
	      {
	         wsex[0] = license[1];
	         wsex[1] = '\0'      ;
	      }
	      else
	      {
	         strcpy(wsex,sex);
	      }

	      psex_age   = 0.0;
	      psex_age1  = 0.0;
	      psex_age2  = 0.0;
	      psex_age_damage = 0.0; /* 980310,*/
	      psex_age_c = 0.0;     /* �j���I add by sylvia 106.03.28 */
	      strcpy(fcard_class, trim(fcard_class));
	      strcpy(wsex,        trim(wsex));
	      psex_age_notfound  = 0;
	      psex_age_notfound1 = 0;
	      psex_age_notfound2 = 0;
	      psex_age_notfound3 = 0;

	      /* �j���I�ʧO�~�֫Y�� */
	      find_flag = 0;
	      for (chk_count=0 ; chk_count<max_ca_sex_age_factor ; chk_count++)
	      {
	         if ((strcmp(ca_sex_age_factor[chk_count].fcard_class, "1") == 0) &&
	             (strcmp(ca_sex_age_factor[chk_count].fsex, wsex) == 0) &&
	             (ca_sex_age_factor[chk_count].qage_bgn < age) &&
	             (ca_sex_age_factor[chk_count].qage_end >= age) &&
	             (strcmp(ca_sex_age_factor[chk_count].frate, tmp_frate1) == 0))
	         {
	            find_flag  = 1;
	            psex_age1 = ca_sex_age_factor[chk_count].pfactor;
	            break;
	         }
	      }
	      if (find_flag == 0)  /* NOT FOUND */
	         psex_age_notfound1 = 1;

	      /* ���N�I�ʧO�~�֫Y��(���d) */
	      find_flag = 0;
	      for (chk_count=0 ; chk_count<max_ca_sex_age_factor ; chk_count++)
	      {
	         if ((strcmp(ca_sex_age_factor[chk_count].fcard_class, "2") == 0) &&
	             (strcmp(ca_sex_age_factor[chk_count].fsex, wsex) == 0) &&
	             (ca_sex_age_factor[chk_count].qage_bgn <= age) &&
	             (ca_sex_age_factor[chk_count].qage_end > age) &&
	             (strcmp(ca_sex_age_factor[chk_count].frate, tmp_frate2) == 0))
	         {
	            find_flag  = 1;
	            psex_age2 = ca_sex_age_factor[chk_count].pfactor;
	            break;
	         }
	      }

	      if (find_flag == 0)  /* NOT FOUND */
	         psex_age_notfound2 = 1;

	      /*980310, insert ��policy_302��,�ϥ� psex_age , �j����j��ʧO�~�֫Y��
	                                                      ���N��񨮳d�ʧO�~�֫Y�� */
	      if (*fcard_class == '1'){
	         /* psex_age = psex_age1; */
	         psex_age_c = psex_age1;    /* �אּ�g�Jpsex_age  modify by sylvia 106.03.28 */
	      }else{
	         psex_age = psex_age2;
	      }

	      #ifdef PRINTF_FLAG
	      printf("age[%f],sex[%s],psex_age[%4.12f]\n",age,wsex,psex_age);
	      printf("psex_age_notfound[%d],psex_age_notfound1[%d],psex_age_notfound2[%d]\n",psex_age_notfound,psex_age_notfound1,psex_age_notfound2);
	      #endif

	      strcpy(outMsg, rtrim(license));
	   }else{
		   	psex_age   = 1.0;
		   	psex_age1  = 1.0;
		   	psex_age2  = 1.0;
		   	psex_age_c = 1.0;
		   	psex_age_damage = 1.0;
		   	strcpy(outMsg, rtrim(tagnum));
   	}

    /* 101.10 �Atpl_barcode , �D���Ӿ���barcode���ܧ�~���A�@�ߤ�ӥh�~*/
    qply_period_pre = qply_period;
    if (qply_period<=12)
    {
        qply_period = 12;
    }
    else
    {
    	/*35���ءA�L�׫e��O���X�~�A��O�@��1�~��(1110718002_SC3_�s�W�L���q�ʤG����)*/
      if (ISMOT(car_typei) && strcmp(car_typei,"35") != 0)
      {
	    		qply_period = 24;
			}
			else
			{
	    	qply_period = 12;
			}
		}

    dply_begin=dply_end;
    dply_end=GetNextYearDate(dply_end);

   	#ifdef PRINTF_FLAG
   	printf("dply_begin[%ld],dply_end[%ld]\n",dply_begin,dply_end);
   	#endif

   	fMotProj = 'N';
   	/* 100.06���T����: �J�`���O:2(�T��); 3(����) */
   	if (ISMOT(car_typei))
   	{
        sCar_kind[0]='3';

        /* 100.06���T���� :�J�`���O:����*/
        /* 100.02.10 ,�����㨮���ѱM�� ��H�q���N��+�g��N�������� */
				/* 980727, �˵��ӳ�O�_�ݾ����㨮���ѱM�� */
				t_count = 0;

				$SELECT count(*) INTO $t_count
				   FROM tmp_barcode_officer
				  WHERE icode_no='MOTOR20'
				    AND (iofficer = $iofficer Or iofficer = $iroute);
				if (t_count>0)
				{
				    fMotProj = 'Y';
				}

        /* 101.10 �Atpl_barcode , �D���Ӿ���barcode���ܧ�~���A�@�ߤ�ӥh�~*/
        if (qply_period==24 )
        {
	    		dply_end=GetNextYearDate(dply_end);
				}
				iSecondYear2 = qply_period - 12;

        #ifdef PRINTF_FLAG
	        printf("---***--- qply_period=[%d] dply_end=[%ld]\n", qply_period, dply_end );
					printf("iSecondYear2[%d]\n",iSecondYear2);
				#endif
   	}
   	else
   	{
      sCar_kind[0]='2';
   	}

   	if (tagnum[0]==' ' || tagnum[0]=='\0')
      strcpy(inumber,engine);
   	else
      strcpy(inumber,tagnum);

   	#ifdef PRINTF_FLAG
   	printf("dply_begin[%ld],dply_end[%ld]\n",dply_begin,dply_end);
   	printf("3.6 choice[%c],ca_acc-->inumber[%s],fcard_class[%s]\n", *choice,inumber);
   	#endif

    /******�D�e�T�~�O��********/
    last_policy_2[0] = last_policy_3[0] = '\0';

    if (*fcard_class == '2')
    {
        for (pre_year=0; pre_year <= 2 ; pre_year++)
        {
            #ifdef PRINTF_FLAG
             printf("read pre_policy--cnt[%d],inumber[%s]\n",pre_year,inumber);
            #endif
            pre_ply[pre_year][0] = '\0';
            pre_comp[pre_year][0] = '\0';

            $DECLARE ply_cur CURSOR FOR
              SELECT ipolicy
                FROM ca_ply_period
               WHERE inumber=$inumber
                 AND fcard_class='2'
                 AND YEAR(dply_bgn)=(YEAR($dply_begin)-($pre_year+1));
            $OPEN ply_cur;
            while(1)
            {
                #ifdef PRINTF_FLAG
                 printf("fetch-------cnt[%d]\n",pre_year);
                #endif

                $FETCH ply_cur into $pre_ply[pre_year];
                if (SQLCODE == SQLNOTFOUND)
                       break;
            }
            $CLOSE ply_cur;
            $FREE  ply_cur;

            strcpy(last_policy_2,pre_ply[1]);
            strcpy(last_policy_3,pre_ply[2]);
        }

        #ifdef PRINTF_FLAG
          printf("ipolicy[%s]\n",last_ply);
          printf("BEFORE lia_class[%s]\n",lia_class);
        #endif

        /*** �Q�ΫY�Ʀ^���ż� ***/
	    /* 101.07.03,ca_comp_acc_factor �[ fcar_class ��� */
	    if (strlen(trim(lia_class)) == 0)
	    {
	        $EXECUTE get_lia_qclass
	            INTO $lia_class
	           USING $fcar_class,$plia_acc,$tmp_frate2;
        }

	    #ifdef PRINTF_FLAG
	      printf("AFTER  lia_class[%s]\n",lia_class);
	      printf("--dmg_flag[%c]\n",dmg_flag);
        #endif

        pdmg_acc_last  = pdmg_acc;
        punknown_acc_last  = punknown_acc;
        strcpy(lia_class_last , lia_class);
    }else{
        strcpy(lia_class," "); /* lia_class�b ca_get_fclass_302() �L�γ~ */
    }

    strcpy(plia_acc_c," ");  /* �j���I�Y��*/
    strcpy(lia_ac_cntc," "); /* �e�@�~�j�ߦ���*/
    qlia_acc_21 = 0; /* �j���I�ż� add by sylvia 1140624 (1140605006_C01) */

    dmg_ac_cnt[0][0]    = '\0';
    dmg_ac_cnt[1][0]    = '\0';
    dmg_ac_cnt[2][0]    = '\0';

    lia_ac_cnt[0][0]    = '\0';
    lia_ac_cnt[1][0]    = '\0';
    lia_ac_cnt[2][0]    = '\0';

    qdmg_point_renew   = 0;     /* �����I�� */
    qunknown_point_renew   = 0; /* �������l�I�� */
    lia_class_renew    = 4;     /* ���d�ż� */
    qdmg_acc_sum_renew = 0;     /* ����T�~���ߴڦ����`�M (�u��"�d���T��"�~��)*/
    qunknown_acc_sum_renew = 0; /* �������l�T�~���ߴڦ����`�M (�u��"�d���T��"�~��)*/
    qlia_acc_sum_renew = 0;     /* ���d�T�~���ߴڦ����`�M (�u��"�d���T��"�~��)*/

    qdmg_point_renew_ori   = 0;
    qdmg_acc_sum_renew_ori = 0;
    qdmg_point_renew_sug   = 0;
    qdmg_acc_sum_renew_sug = 0;

    qunknown_point_renew_ori   = 0;
    qunknown_acc_sum_renew_ori = 0;
    qunknown_point_renew_sug   = 0;
    qunknown_acc_sum_renew_sug = 0;

    qdmg_acc_sum_5y_renew = 0;      /* ����e���~�߮צ���(�w�M�B�ߴڪ��B��0) */
    qlia_acc_sum_5y_renew = 0;      /* ���d�e���~�߮צ��� */
    qacc_sum_5y_renew     = 0;      /* �e���~�߮צ���(����+���d) */
    qduty_sum_5y_renew    = 0;      /* �e���~���F�d�p������(����+���d) */
    strcpy(dfirst_ply," ");         /* ���N�I�̦���O�� */
    qdmg_acc_sum_5y_pure_renew = 0; /* ����e���~�ߴڦ��� */
    fhave_newa_c_2y_renew = 0;      /* �L�h�G�~�O�_�b�s�w��O�L�T���I */

    strcpy(query_num_dmg," "); strcpy(query_num_dmg_ori," "); strcpy(query_num_dmg_sug," ");
    strcpy(query_num_unknown," "); strcpy(query_num_unknown_ori," "); strcpy(query_num_unknown_sug," ");
    strcpy(query_num_lia," ");
    strcpy(trade_msg_no_dmg," ");strcpy(trade_msg_no_unknown," ");
    strcpy(trade_msg_no_lia," ");

    pdmg_acc_ori = 0;   punknown_acc_ori = 0;
    pdmg_acc_sug = 0;   punknown_acc_sug = 0;
    plia_acc = 0;
    qdrunk_driving = 0;
    qviolate = 0;

    strcpy(splia_acc," ");
    strcpy(spdmg_acc," ");      strcpy(spunknown_acc,"0.0");
    strcpy(spdmg_acc_sug," ");  strcpy(spunknown_acc_sug,"0.0");

    strcpy(iquery_num," ");
    strcpy(iquery_num_damage," ");      strcpy(iquery_num_unknown," ");
    strcpy(iquery_num_damage_sug," ");  strcpy(iquery_num_unknown_sug," ");
    strcpy(iquery_num_c," ");
    strcpy(funknown_dmg_ori," ");   /* �������l�O���覡�O(���O�զX) */
    strcpy(funknown_dmg_sug," ");   /* �������l�O���覡�O(��ĳ��O�զX) */

    if (*fcard_class == '1')
    {
        ply1f = TRUE;
        if (!ISMOT(car_typei))
        {
            ilast_comp_class = atoi(last_comp_class);

            if (intopt == 55 )
            {
                $select iquery_num,comp_line,qdrunk_driving
                   into $iquery_num, $qlia_acc, $qdrunk_driving
                   from estimate_fb
                  where ipolicy = $last_ply;

                $SELECT pcomp_factor INTO $plia_acc
                   FROM ca_comp_acc_factor
                  WHERE qclass=$qlia_acc
                    AND fcard_class = '1'
                    AND fcar_class = (SELECT fcar_class FROM car_type  WHERE fclass='1' AND  icode=$car_typei)
                    AND drate = (select drate from ca_rate_date
                                  where icode = $frate
                                    and itable = 'ca_comp_acc_factor');
            }
            else
            {
                /* 960214, �h�~�j��żƿ��~�h�^�ǿ��~�T�� */
                if ((ilast_comp_class < 1) || (ilast_comp_class > 10)){
                	$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,'21','�I�إh�~�j��żƿ��~','1','E04',$iofficer);
                     /* return M_CA_NCOMP_ACC_FACTOR;  4342�G�L���j��ߴگż� */
                }
                 /* 101.07.03,ca_comp_acc_factor �[ fcar_class ���A�ҥH�[�� car_typei */
                 /*990820,remove dply_begin(��˼Ʋ�8�ӰѼ�) */
                 /* 103.02.05 �s�W�G�^�ǰs�r���� */
                 /*���j�H�W�[�O�[�O(1110608012_SC3)*/
                code =ca_get_fclass_302(pDb,inumber,dply_begin,fcard_class,
                                     qdmg,qlia,mdmg,mlia,&qdmg_acc,&qlia_acc,
                                     &pdmg_acc,&plia_acc,fyear,last_comp_class,lia_class,
                                     bqdmg,frate,license,tagnum,assuredf,
                                     last_card,issue_ym,iquery_num_c,car_typei,
                                     &qdrunk_driving,&qviolate);
                if(code!=M_CM_OK) {
                    if (code==M_CA_NCOMP_ACC_FACTOR){
                        $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,'21','�I�صL���j��ż�','1','E04',$iofficer);
                    }else{
                        return code;
                    }
                }
            }
        }
        else
        {
            strcpy(fyear,"NNN");
            qdmg_acc = 0;
            pdmg_acc = 0;
            plia_acc = 0;
            qlia_acc = 4;
            qunknown_acc = 0;
            punknown_acc = 0;
        }

        sprintf(plia_acc_c,"%4.2f",plia_acc);

        #ifdef PRINTF_FLAG
         printf("qlia0--->[%d]\n",qlia[0]);
        #endif

        if (fyear[0] == 'Y')
            strcpy(lia_ac_cntc,itoa(qlia[0]));
        else
            strcpy(lia_ac_cntc,"0");

        strcpy(comp_class,itoa(qlia_acc));
        qlia_acc_21 = qlia_acc;  /* �j���I�ż� add by sylvia 1140624 (1140605006_C01) */

        #ifdef PRINTF_FLAG
				printf("comp_class=[%s]\n", comp_class);
	 			printf("plia_acc_c=[%s]\n",plia_acc_c);
				#endif
    }/* End of �j���I */
    else
    {
        ply2f = TRUE;
        /* 102.11.12 ���N�I�ߴګY�Ƨﲾ��᭱�A���N�I�O�O�p�⤧�e*/
    }/* End of ���N�I */

    #ifdef PRINTF_FLAG
     printf("3.7 before step4&5 ply1f[%d],ply2f[%d]\n",ply1f,ply2f);
     printf("3.8 psex_age[%f] \n",psex_age);
     printf("3.9 >>>>step4\n");
    #endif

		/************************** STEP 4 ***********************************/
   	if (strcmp(car_typei,"CS") != 0)
   	{
   		#ifdef PRINTF_FLAG
   	 	printf("3.11 ---------brand[%s] pro_year[%s]\n",brandi,pro_year);
   		#endif

	   	$DECLARE CA_OPT1 CURSOR for
	   	  SELECT icar_type,fuse_type,qpassenger,mcar_price,icar_series,drate
	   	    INTO $icar_type,$fuse_type,$qpassenger,$mcar_price,$s_car_series
	   	    FROM ca_car_model
	   	   WHERE ibrand    = $brandi
	   	     AND ipro_year = $pro_year
	   	     AND drate = (select drate from ca_rate_date
	   	                   where itable = 'ca_car_model' and icode = $tmp_frate2 )
         ORDER BY drate DESC;

      $OPEN CA_OPT1;
      $FETCH CA_OPT1;
      if (NOT_FOUND)
      {
			   #ifdef PRINTF_FLAG
			      printf("step 4---brandi[%f]\n",brandi);
			      printf("step 4---pro_year[%f]\n",pro_year);
			   #endif

	   			/* 960504,�ץ�ca_car_model ��Ƨ���W�h => �Pcar301
                ( idmg_rate �� ibrg_rate �bca3xxlib.ec ���~��� )*/
           /* �אּ����<ipro_year ���̤j�~��, �A�䤣��~�� >ipro_year ���̤p�~��
              ��: ��J���s�y�~����2014, �Y�d�L2014�~�������, �h���� <2014����1�� (2013), �A�d����h�� >2014����@��(2015)
              modify by sylvia 104.09.15  (1040714001_C3)
           */
           $DECLARE CA_OPT3A CURSOR for
             SELECT icar_type,fuse_type,qpassenger,mcar_price,icar_series
               INTO $icar_type,$fuse_type,$qpassenger,$mcar_price,$s_car_series
               FROM ca_car_model
              WHERE ibrand    = $brandi
                AND ipro_year < $pro_year
                AND drate     = (SELECT drate
                                   FROM ca_rate_date
                                  WHERE icode  = $tmp_frate2
                                    AND itable = 'ca_car_model')
              ORDER BY ipro_year desc;

           $OPEN  CA_OPT3A;
           $FETCH CA_OPT3A;

      		if (NOT_FOUND)
      		{
		      	$DECLARE CA_OPT3B CURSOR for
		      	  SELECT icar_type,fuse_type,qpassenger,mcar_price,icar_series
		      	    INTO $icar_type,$fuse_type,$qpassenger,$mcar_price,$s_car_series
		            FROM ca_car_model
		           WHERE ibrand=$brandi
		             AND ipro_year > $pro_year
		             AND drate     = (SELECT drate
		                                FROM ca_rate_date
		                               WHERE icode  = $tmp_frate2
		                                 AND itable = 'ca_car_model')
		           ORDER BY ipro_year ;

		        $OPEN  CA_OPT3B;
		        $FETCH CA_OPT3B;

        		if (NOT_FOUND)
		        {
		        	$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$brandi,'�t�P�����䤣��','2','E06',$iofficer);
		        	$CLOSE CA_OPT3B;
		        	$FREE  CA_OPT3B;
		        } else
		        {
		        	$CLOSE CA_OPT3B;
		        }
      		}
      		$CLOSE CA_OPT3A;
      		$FREE  CA_OPT3A;
   		}
   		$CLOSE CA_OPT1;
   		$FREE CA_OPT1;

	   	#ifdef PRINTF_FLAG
	    	printf("step 4---mcar_price[%f]\n",mcar_price);
	    	printf("step 4---qpassenger[%f]\n",qpassenger);
	   	#endif
   	}

   	/************************** STEP 5 ***********************************/
		premium1 =  0; mdrunk_prem = 0; mdrunk_pure_prem = 0.0; mprem_21 = 0; mprem_21_ori = 0;
	  mbusiness2 = 0.0;
	  mviolate_prem = 0; mviolate_pure_prem = 0.0; /*���j�H�W�[�O�[�O(1110608012_SC3)*/
	  if (ply1f==TRUE)
	  {

    	code =Get_comp_prem_302(car_typei,&premium1,plia_acc,comp_prem,qply_period,userid,
                              qdrunk_driving,qviolate,&mdrunk_prem,&mdrunk_pure_prem,&mviolate_prem,&mviolate_pure_prem);
      if (code != SUCCESS)
      {
         memset(err_buf,0,sizeof(err_buf));
         strcpy(err_buf,"Get_comp_prem_302()1");
         strcat(err_buf,last_ply);
         EWRITE(userid,code,err_buf);
         return code;
      }

      /* 101.10 */
      premium1_ori = premium1;
      mprem_21 = premium1; /* �j���I���e�O�O */
      mprem_21_ori = premium1_ori; /* �j���I���e�O�O */

      fshow_comp_disc = 'N';

      /* �j���I�����~���u�f���B�վ�A���q���^�kŪ��cmn144�]�w�������B mark by 061476 110.01.21 (1100118005_SC3) */
      /*****************************************************************************************************************/
      /* �X�w�J�p�ɤw���A�G���s��jbarcode �ɱj���I�O�O�����A�� */
      /* 970219, �B�z�������~���Ҧ�barcode�q�l�ɤ����s */
      /*if (fTCB_Bank == 'Y'){ �X�w �j��~�ȶO���n��h�~�@��*/
      if (fBarcode == 'Y')
      {
         /* �j���I�����]�w */
         switch (s_fcomp_disc[0])
         {
            case '0': /* �L���� */
                  mcomp_busi = 0;
            	  break;

            case '1': /* �������A�̥h�~�������B�A������j��Ӹg���N���ثe�����N�z�v�]�w��(�G�̨����p��) */
	    			case '3': /* �������A�ϥ���O�J�p���ɤ������N�z�v�]�w��*/
	              /* --------------------------------------------------------------------*/

	              /* ���o�g��H���ݸg���H�U�I�ئ����N�z�v�ɳ]�w���u�f�v( + �����v )
	                 icheck_disc : �u�f�v�ˮֽX ;pdiscount_broker:�u�f�v ; �����v:pcommiss_broker */

	              /* ���� */
	              /* �]���T���I��������������,�����I�O�w�b�e���^��,�G���q�u�P�_�~�� mark by sylvia 103.11.14 (1031103007_C2) */
	              if (ISMOT(car_typei))
	              {
	              	if (qply_period==12)
	              	    strcpy(iyear,"1");
	              	else
			    						strcpy(iyear,"2");
		      			}
					      else
					      {
					      	strcpy(iyear,"0");
					      }

					      /* �ǤJ�Ѽ�:
					         1.	�q���N��    2.	�O�v�O           3.	�~�ȱ���N��     4.	�X�@�j�I�O
					         5.	�����I�O    6.	�I��(���I��)     7.	�~��          */

					      memset(&o_stcomm, 0x00, sizeof(o_stcomm));
					      o_qrec = 0;
					      rtncode = cm_get_insure_comm(iroute, irate_type, iroute_comm, "C", iins_cat ,
					                                   "21", iyear, &o_qrec, &o_stcomm, " ");

					      #ifdef PRINTF_FLAG
					      printf("Trace -- iroute = [%s] \n",  iroute);
					      printf("Trace -- cm_get_insure_comm()  rtncode = [%ld],o_qrec=[%d] \n", rtncode,o_qrec);
					      #endif

					      if(rtncode != M_CM_OK || o_qrec==0 )
					      {
					          sprintf(tMsg,"���o�~�ȱ�����~:�q��[%s]�O�v�O[%s]�~�ȱ���N��[%s]�I�O[%s]�I��[21]",rtrim(iroute),irate_type,iroute_comm,iins_cat);
					      	  $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$iroute,$tMsg,'1','E08',$iofficer);
					      	  return -1000;

					      }
					      strcpy(icheck_busi, o_stcomm.icheck_busi);
					      mother_busi = o_stcomm.mother_busi;
					      mservice = o_stcomm.mservice;

					      #ifdef PRINTF_FLAG
					      printf(" ------- icheck_busi[0] = [%c]\n " , icheck_busi[0]);
					      printf(" ------- mservice    = [%f]\n "   , mservice);
					      printf(" ------- mother_busi = [%d]\n "   , mother_busi);
					      #endif

					      if (icheck_busi[0]=='0')
					      {
					          mcomp_busi = (long)mother_busi;
					      }
					      else if ((icheck_busi[0]=='1')||(icheck_busi[0]=='3'))
					      {
					          if (s_fcomp_disc[0]=='1')
					          {
				      	      /* �h�~�������B = �W���O�O-ñ��O�O */
				              sprintf(buf1,"SELECT (mprem-mins_premium) FROM %s %s",
				      		           "ply_ins_type_last",
				      		           "WHERE ipolicy=? AND iins_type = '21'");
				      	      $PREPARE comp_busi FROM $buf1;
				      	      $EXECUTE comp_busi INTO $mcomp_busi USING $last_ply;

				      	      if( SQLCODE == SQLNOTFOUND)
				      	      {
				      	          mcomp_busi = (long)mother_busi;
				      	      }
				      	      else
				      	      {
		      	          	if (icheck_busi[0]=='1')
		      	          	{
		      		      			if (mcomp_busi > mother_busi)
			      		      		{
			      		          	mcomp_busi = (long)mother_busi;
			      		      		}
		      		  				}
		      		  				else
						      		  {
						      		      if (mcomp_busi > ((long)mother_busi + (long)mservice))
						      		      {
						      		          mcomp_busi = (long)mother_busi + (long)mservice;
						      		      }
						      		  }
		      	      		}
		      	  			}
		      	  			else
		      	 	 			{
				      	      if (icheck_busi[0]=='1')
				      	      {
				      	          mcomp_busi = (long)mother_busi ;
				      	      }
				      	      else
				      	      {
				      	          mcomp_busi = (long)mother_busi + (long)mservice;
				      	      }
		      	  			}
		      			}
		      			else if (icheck_busi[0]=='2')
		      			{
		          		if (s_fcomp_disc[0]=='1')
				          {
				      	      /* �h�~�������B = �W���O�O-ñ��O�O */
				      	      sprintf(buf1,"SELECT (mprem-mins_premium) FROM %s %s",
				      		            "ply_ins_type_last",
				      		            "WHERE ipolicy=? AND iins_type = '21'");
				      	      $PREPARE comp_busi FROM $buf1;
				      	      $EXECUTE comp_busi INTO $mcomp_busi USING $last_ply;

				      	      if( SQLCODE == SQLNOTFOUND)
				      	      {
				      	          mcomp_busi = (long)mother_busi;
				      	      }
				      	      else
				      	      {
				      	          /* �p�G�h�~������(mcomp_busi=0),�h��O���������� */
				      		  /* �p�G�h�~������(mcomp_busi>0),�h��O�ɧ����̤j���i�W�L (mother_busi + mservice) */
				      		  if (mcomp_busi > ((long)mother_busi + (long)mservice))
				      		  {
				      		      mcomp_busi = (long)mother_busi + (long)mservice;
				      		  }
				      	      }

				      	  }
		      	  		else
				      	  {
				      	      mcomp_busi = (long)mother_busi + (long)mservice;
				      	  }
		      			}
		      	break;

	    			case '2': /* �������A�T�w�������B*/

                      if (ISMOT(car_typei))
                      {
                          if (qply_period==12)
                      	      mcomp_busi = (long)s_mcomp_disc_mot1; /* �����@�~�� */
                      	  else
                      	      mcomp_busi = (long)s_mcomp_disc_mot2; /* �����G�~�� */
                      }
                      else
                      {
                          mcomp_busi = (long)s_mcomp_disc;          /* �T�� */
                      }
                      break;
         }

         /* �j���I����: �D�����~��, ���=0; �����~��, �̧C����� �T��73/�����@�~��60/�����G�~��80
            add by sylvia 105.08.19 (1050812001_C1) */
         if (strcmp(irate_type,"C") == 0)
            mcomp_busi = 0; /* �D�����~�Ȥ���� */
         else
         {
            if (ISMOT(car_typei))
            {
                if (qply_period<=12)
                    strcpy(iyear,"1");
                else
                    strcpy(iyear,"2");
            }
            else
                strcpy(iyear,"0");

            /* �j���I�����~���u�f���B�վ�A�@�ߧ�Ūcmn144�]�w���A�ˮ�car140-CD�ҳ]�w�̧C�����B
               mark by 061476 110.01.21 (1100118005_SC3) */
            /*if (mcomp_busi < cdiscount[atoi(iyear)])
                mcomp_busi = cdiscount[atoi(iyear)];*/
         }

         mcomp_busi_ori = mcomp_busi;
         f_cal_comp = 'N';  /* barcode��w���p����, ���A����j���I��� */
      }
      /* �j��O�O��� */
      if ((mcomp_busi > 0 || mcomp_busi_ori >0) && (fBarcode == 'Y' || fshow_comp_disc == 'Y'))
      {
         #ifdef PRINTF_FLAG
       	   printf(" ------- premium1(before (-mcomp_busi)) = [%ld]\n " , premium1);
         #endif
        mprem_21 = premium1; /* �j���I���e�O�O */
        mprem_21_ori = premium1_ori; /* �j���I���e�O�O */
        f_cal_comp = 'N';    /* ���A����j���I���O�O */

      	premium1_ori -= mcomp_busi_ori;
        premium1 -= mcomp_busi;

        #ifdef PRINTF_FLAG
           printf(" ------- last_ply = [%s]\n " , last_ply);
           printf(" ------- car_typei = [%s]\n " , car_typei);
           printf(" ------- qply_period = [%d]\n " , qply_period);
           printf(" ------- mcomp_busi( �j��~�ȶO���)= [%ld]\n " , mcomp_busi);
           printf(" ------- premium1 = [%ld]\n " , premium1);
        #endif

				/* 990126,������O(�g��GZ12010C)�ιq�ܦ�P�M��(�g��GZ6102104)�� "�T��" �O�I��O�q���ѡA�w��j���I�O�O�n���100�� */
				/* �q�ܦ�P�M��(�g��GZ6102104)�J�p�ɤw���A�G���s��jbarcode �ɱj���I�O�O�����A�� */
				if (fshow_comp_disc == 'Y'){
					/* �����@���A�G���|�� "�ζ��鲣�P�ߪA�ȥd�M��" wording �ۨR  */
					/* sprintf(remark4,"%s%ld%s",
					   "����O�q���Ѥw�ɦ��j���I ",mcomp_busi,"���u�f�A���N�I�ɦ�������O�u�f�C" ); *//* mark by sylvia 105.06.20 (1050602005_C1)*/
					strcpy(remark4, " " );
					strcpy(remark5, " " );
					/*strcpy(remark5, "a4" ); 102.12.25 ����*/
			         }
      }
   }
   /************************** STEP 6 ***********************************/
   if (ply1f== TRUE)
   {
      rfmtdate(dply_begin,"mm/dd/yyyy",comp_date_begin);
      rfmtdate(dply_end,"mm/dd/yyyy",comp_date_end);
   }
   else
   {
      rfmtdate(dply_begin,"mm/dd/yyyy",comp_date_begin);
      rfmtdate(dply_end,"mm/dd/yyyy",comp_date_end);
   }
   #ifdef PRINTF_FLAG
      printf("step5--comp_date_begin[%s],comp_date_end[%s]\n",comp_date_begin,comp_date_end);
      printf("3.12 >>>>step5 ply1f[%d]\n",ply1f);
   #endif

   /************************** STEP 7 ***********************************/
   #ifdef PRINTF_FLAG
      printf("3.19 >>>>step7\n");
   #endif
   /************************** STEP 8 ***********************************/
   /*   �N��O�I�ؼg�JINS_ptr                                           */
   /*   �B�z��ĳ�I��                                                    */
   /*                                                                   */
   /**********************************************************************/
   sprintf(stmt, "SELECT %s FROM %s WHERE %s",
                  " nins_abbr ",
                  " insurance_type ",
                  " iins_type = ? ");
   $PREPARE nins FROM $stmt;

   pre_ch_ins_grp[0][0] = '\0';
   pre_ch_ins_grp[1][0] = '\0';
   pre_ch_ins_grp[2][0] = '\0';
   ch_ins_cnt = 0;
   ins_grp_cnt = 0;

   #ifdef PRINTF_FLAG
      printf("3.10 >>>>step8\n");
      printf("3.10 >>> strp8\n");
      printf("choice[%s]\n", choice);
      printf("iquota[%s]\n", iquota);
   #endif

   /* 1020808, ���ЫO�N(�q���N���e�|�X�GCAC1P)���w�t���ϥΫ��w���²v */
   /* ���²v = 15% => CRV(�t���N��C804*)�BACCORD(�t���N��C802*)�BCIVIC(�t���N��C803*)�BFIT����(�t���N��C805*)*/
   /* ���²v = 25% => INSIGHT(�t���N��94030500)�BCRZ(�t���N��94030600) */
   /* �t���]�w�bcar_code�Akind�G"P0" */

   f_Honda_dep = 'N';  dep_Honda[0]=' '; dep_Honda[1]='\0';

   /* �O�v�N��>=79��,�ϥ�Z����,���Ч��¤��A�� modify by sylvia 105.03.17 (1050226003_C3) */
   if ((atoi(tmp_frate2)) < 79)
   {
        if (strncmp(iroute,"CAC1P",4) == 0 ){
            t_count = 0;
            $EXECUTE preHondaIbrand Into $dep_Honda,$t_count USING $brandi;
    	        if (t_count > 0 ){
                    /* dep_Honda �b ca3xxlib.ec ��SetCarAge()(�h�~�LE���ڮ�) �� SetCover_For_Prov_E()(�h�~��E���ڮ�) ���ϥ� */
    	 	        f_Honda_dep = 'Y';
                }
        }
   }
    /* 111�O�v�_Z���ڰ��ΡA�ﵹP���� (1081105005_SC3) */
    f_provision_Z = 'N';  cnt_provision_Z = 0;  cnt_ins_Z = 0; cnt_ins_E = 0;
    if (((atoi(tmp_frate2)) >= 79)&&((atoi(tmp_frate2)) < 111)) /* 79 =< �O�v�N�� < 111 �A�� */
    {
        /* �ˮ֬O�_�����[Z����, �L���[Z���ڦ����ج�4A,9A,2B�n�۰ʪ��[Z����
        �åHZ���ڭp�����(���²v=15%) add by sylvia 105.03.16 (1050226003_C3)    */
        /* printf("---- 4685 ipolicy=[%s] f_provision_Z=[%c]----- \n",last_ply,f_provision_Z); */

        f_Honda_dep = 'N';  /* �O�v�N��>=79��,�ϥ�Z����,���Ч��¤��A�� modify by sylvia 105.03.17 (1050226003_C3) */
        $select count(*) into $cnt_provision_Z from ply_ins_type_last
          where ipolicy = $last_ply  and trim(provision)||';' matches "*Z;*";
        if (cnt_provision_Z > 0)
        {
            f_provision_Z = 'Y';

        }
    }

    /* �s�WP�BQ�BV���� add by 061476 108.01.25(1071226006_SC3) */
    /* �}����~�����[�A�H�ηs�WM���� 108.12.24(1081105005_SC3) */
    cnt_ins_Y = 0;
    f_provision_Y = 'N';
    /* ���t�ƪ��B�A�ŦX���اY�����i���[Y���ڡA����|�A�P�_�O�_���ӫO�����I��(1130827011_C03) */
    if (mequipment > 0 && ISCAR_Y(car_typei))
    {
    	f_provision_Y = 'Y';
    }


    /* �ˮ֬O�_���[P/Q���� add by 061476 108.01.25 (1071226006_SC3) */
    /* �W�[��~���P�_   modify by 061476 108.12.24 (1081105005_SC3)*/
    f_provision_P = 'N'; f_sug_P = 'N'; f_provision_Q = 'N'; f_provision_M = 'N';
    cnt_ins_P = 0; cnt_provision_P = 0; cnt_other_ins1589 = 0; cnt_ins_Q = 0;
    cnt_ins_M = 0; cnt_provision_Q = 0;
    strcpy(last_ply_tmp,"");

    if (fcar_class[0] == '1')
		{
    	/* �H�U�P�_��B��� */
    	if (IsPlyB == 'Y')
    	{
    		strcpy(last_ply_tmp,trim(last_ply));
    		strSearchReplace(last_ply_tmp,"-B","");

    		$select count(*) into $cnt_ins_Q from ply_ins_type_last
    		  where ipolicy = $last_ply_tmp and trim(provision)||';' matches "*Q;*";
    		if (cnt_ins_Q > 0)
    		{
    			f_provision_Q = 'Y';
    		}
    		else
    		{
    			$select count(*) into $cnt_provision_P from ply_ins_type_last
    			  where ipolicy = $last_ply_tmp and trim(provision)||';' matches "*P;*";
    			if (cnt_provision_P > 0) f_provision_P = 'Y';
    		}
    	}
    	else
    	{
    		/* �ˮ֬O�_�����[Q���� (���²v=20%)*/
    		$select count(*) into $cnt_ins_Q from ply_ins_type_last
    		  where ipolicy = $last_ply and trim(provision)||';' matches "*Q;*";
    		if (cnt_ins_Q > 0) f_provision_Q = 'Y';
    		else
    		{
    			/* �S��Q�A��P����(���²v=15%)�Τ��[(���²v=25%) */
    			/* �S���H�U�I�ت��ܵL�ӫO�t���¬����I�ءA���i���ĳ09/98�A�G���²v�N�w�]��P */
    			$select count(*) into $cnt_ins_P from ply_ins_type_last
    			  where ipolicy = $last_ply
    			    and iins_type in ('01','05','09','11','101','102','110','111','129','20','23','75','76','86','98','02','03','10','201','205','209','211','176','177');
    			if (cnt_ins_P == 0) f_sug_P = 'Y';

    			$select count(*) into $cnt_provision_P from ply_ins_type_last
    			  where ipolicy = $last_ply and trim(provision)||';' matches "*P;*";
    			if (cnt_provision_P > 0) f_provision_P = 'Y';
    			else
    			{
    				/* �Y���H�U�I�إ����B�u����[P���ڡA�_�h�����L���[���±��� */
    				$select count(*) into $cnt_other_ins1589 from ply_ins_type_last
    				  where ipolicy = $last_ply
    				    and iins_type in ('101','102','110','111','129','20','23','75','76','86','98');
    				if (cnt_other_ins1589 > 0) f_provision_P = 'Y';
    			}
    		}
    	}
    }
    else /* ��~�� */
    {
    	/* �P�\���T�{B��L��~�� */
    	if (IsPlyB == 'Y')
    	{    	}
    	else
    	{
    		/* �ˮ֬O�_�����[M���� (���²v=25%)*/
    		$select count(*) into $cnt_ins_M from ply_ins_type_last
    		  where ipolicy = $last_ply and trim(provision)||';' matches "*M;*";
    		if (cnt_ins_M > 0) f_provision_M = 'Y';
    		else
    		{
    			/* �S��M�A��Q����(���²v=20%)�Τ��[(���²v=30%) */
    			/* ��~���S����ĳ09/09+K�I�ت�ĳ�D */
					$select count(*) into $cnt_provision_Q from ply_ins_type_last
					  where ipolicy = $last_ply and trim(provision)||';' matches "*Q;*";
					if (cnt_provision_Q > 0) f_provision_Q = 'Y';
					else
					{
						if((strcmp(car_typei,"4A") == 0) || (strcmp(car_typei,"9A") == 0) ||
						   (strcmp(car_typei,"2B") == 0))
						{
							$select count(*) into $cnt_provision_P from ply_ins_type_last
							  where ipolicy = $last_ply and trim(provision)||';' matches "*P;*";
							if (cnt_provision_P > 0) f_provision_P = 'Y';
						}
					}
				}
			}
    } /* ���§P�_END */


   	/* 102.07.01�A���³B�z���ܦ��B�A�H�Q 86 20 23�I�ثO�B�p�� */
   	code=SetCarAge(tmp_frate2);
   	if (code != SUCCESS)
   	{
      /* �s���I�صL����  add by 061476 107.04.12 (1061108001_SC7) */
      if (strncmp(tmp_ply,"V7",2)== 0)
      {

      }
      else
      {
      	memset(err_buf,0,sizeof(err_buf));
      	strcpy(err_buf,"Get302Data()8-2->setcarage ERROR:");
      	strcat(err_buf,last_ply);
      	EWRITE(userid,code,err_buf);
      	return code;
      }

   	}

		/* printf("==4679==>car_age=[%d]\n", car_age); */
		pdis_rate = 0;
		cal_pdiscount = 0;
		strcpy(fdiscount,"N");
		main_discount = 0;

		strcpy(issue_12,substring(issue_ym,1,3));
		printf("Trace -- issue_12 = [%s] \n",  issue_12);
   	/**** ���N�I   ******/
   	if (ply2f==TRUE)
   	{
        if(strlen(trim(irelative_ply))==0)
            comp_flag = 'N';
        else
            comp_flag = 'Y';

        strcpy(GsIdx," {+ INDEX (A ca_plyinslast_ix_2) }");
        sprintf(buf1,"SELECT %s %s %s %s FROM %s:%s,%s:%s %s %s %s %s",
                    GsIdx,
                   "A.iins_type,minjured_cover,mdeath_cover,mdamage_cover,",
                   "mdeduct,mins_premium,pagent,pcommission,",
                   "drate_ym,pdiscount,mprem,B.qserial,pdiscount,B.imain_ins,A.qday,A.mexpense,B.fcal_way,nvl(A.provision,' ')  ",
                   FDBNAME,stm3,
                   FDBNAME,"insurance_type B",
                   "WHERE ipolicy=? ",
                   "  AND nvl(fedr_status,'') not in ('1','2','3') ", /* fedr_status => 1:���h  2:�j�h 3:�h���h�O */
                   "  AND A.iins_type=B.iins_type ",
                   "ORDER BY B.qserial DESC");

        $PREPARE STM_5 FROM $buf1;
        $DECLARE CUR_5 CURSOR FOR STM_5;
        $OPEN    CUR_5 USING $last_ply;

        ins_count=0;
        ins_first = 1;
        main_discount = 0;
        dtlint = 0;
        damage_add_flag = 0;
        thief_add_flag = 0;
        qday = 0;
        mexpense = 0;
        mexp_disc = 0;
        deduct_30 = 0; deduct_29 = 0; deduct_09=0; deduct_01=0; deduct_05=0;deduct_301 =0;damager_cover_30 = 0;deduct_530 =0;
        minjured_cover_156_sug=0;minjured_cover_154_sug=0;minjured_cover_155_sug=0;minjured_cover_163_sug=0;
        minjured_cover_67_sug=0;minjured_cover_63_sug=0;
        cnt_ins77 = 0; cnt_ins79 = 0; cnt_110_117 = 0; cnt_125_136=0;
        cnt_f25C01 = 0;
        cnt_ins118 = 0;cnt_ins120 = 0;cnt_ins122 = 0;cnt_ins131=0;cnt_ins132=0;
        cnt_non_sug = 0; cnt_hi_car_price = 0; cnt_n147 = 0; cnt_EB = 0;
        f_32_exist = 'N'; chk_32 = 'N'; f_30_exist = 'N'; f_131_exist = 'N'; f_132_exist = 'N';
        f_31_exist = 'N'; f_51_exist = 'N'; f_sug_28 = 'N'; f_sug_55 = 'N'; f_149_exist = 'N';
        f_11_exist = 'N'; f_12_exist = 'N'; f_301_exist = 'N'; f_150_exist = 'N';
        f_16_exist = 'N'; f_47_exist = 'N'; f_147_exist = 'N';
        f_24_exist = 'N'; f_no_comp_24 = 'N';
        f_14_exist = 'N'; f_55_exist = 'N';
        f_1_9_exist = 'N'; f_02_exist = 'N';f_03_exist = 'N';f_27_exist = 'N';
        f_24_nosug = 'Y'; f_10_exist = 'N';
        f_49_exist = 'N';
        f_19_exist = 'N';
        f_34_exist = 'N';
        c_30_set = '0';
        f_28_exist = 'N';
        f_85_exist = 'N';f_105_exist = 'N';
        f_01_exist = 'N';f_05_exist = 'N';f_08_exist = 'N';f_09_exist = 'N';
        f_66_exist = 'N' ;f_67_exist = 'N'; f_15_exist = 'N';
        f_29_exist = 'N' ;f_38_exist = 'N'; f_39_exist = 'N';
        f_62_exist = 'N'; f_63_exist = 'N'; f_64_exist = 'N'; f_143_exist = 'N';
        f_61_exist = 'N'; f_65_exist = 'N'; f_69_exist = 'N'; f_17_exist = 'N';
        f_86_exist = 'N'; f_98_exist = 'N'; f_07_exist = 'N'; f_18_exist = 'N';
        f_106_exist = 'N'; f_107_exist = 'N'; f_108_exist = 'N'; f_109_exist = 'N';
        f_77_exist = 'N'; f_78_exist = 'N'; f_79_exist = 'N'; f_80_exist = 'N';
        f_87_exist = 'N';f_88_exist = 'N'; f_89_exist = 'N';
        f_118_exist = 'N';f_119_exist = 'N';f_120_exist = 'N';f_121_exist = 'N';
        f_122_exist = 'N';f_123_exist = 'N'; f_124_exist = 'N';
        /*102.11.12, �w��h�~�L�����I�A��O����ĳ�����I�� ( �h�~�������I�A��ĳ��O�������ΤɯŨ����I�̤���,�o�����P�_�O�� ins1589_chg_flag) */
        f_1_9_sug  = 'N' ; f_09_sug = 'N'; f_01_sug= 'N'; f_08_sug= 'N';f_156_sug='N';
        f_105_sug= 'N';f_85_sug= 'N'; f_05_sug= 'N'; f_120_sug = 'N';

        /* �I��110-117������X�I���� add by sylvia 104.05.04 (1030407005_C4) */
        f_110_exist='N';f_111_exist='N';f_112_exist='N';f_113_exist='N';f_114_exist='N';
        f_115_exist='N';f_117_exist='N';f_110_112_sug='N'; f_110_112_ori='N';
        f_113_115_sug='N';

        /* ���ľ��c�q�~�H����X�I */
        f_125_exist = 'N';f_126_exist = 'N'; f_135_exist = 'N'; f_133_exist = 'N'; f_134_exist = 'N';
        f_129_exist = 'N';f_128_exist = 'N';f_127_exist = 'N';

        ins33_flag = ins35_flag = ins48_flag = ins56_flag = ins56_sug_flag = ins50_flag= 0;  /* 950704 */
        ins136_flag = ins163_flag = ins166_flag = ins266_flag = ins09k_flag = 0;

        f_152_exist = 'N';f_153_exist = 'N';f_154_exist = 'N';f_155_exist = 'N';
        f_156_exist = 'N';f_161_exist = 'N';f_162_exist = 'N';f_163_exist = 'N';
        f_164_exist = 'N';f_165_exist = 'N';f_181_exist = 'N';f_198_exist = 'N';
        f_238_exist = 'N';f_255_exist = 'N';f_302_exist = 'N';

        /* �q�ʨ��M���I��(1130510009_C13) */
        f_176_exist = 'N';f_177_exist = 'N';f_178_exist = 'N';

				/* �r�V�Z��X�I  add by sylvia 114.04.24 (1140409004_C01) */
				f_530_exist= 'N'; f_531_exist= 'N'; f_532_exist= 'N'; f_555_exist= 'N';
				f_561_exist= 'N'; f_562_exist= 'N'; f_563_exist= 'N';

        TmNewa_rule_flag = 0 ;   /* 950824,51��55,56�O�_�ĥ�TMNewa �W�h*/
        ins1589_chg_flag = 0 ;   /* 950824,�O�_�ഫ�����I�I�� 1:09==>05; 2:05==>105(104.01.01����) 3:85==>105(104.01.01����) */
                                 /* �s�W�ഫ�N�� add by sylvia 103.10.01
                                    5: 05 ==>118+119 (��104.07.01�W�u�ᰱ��,���A�ഫ(1040515009_C4),
                                    6: 105 ==>118+119
                                    7: 09 ==>120+121,  8:  01 ==>122+123  */
                                 /* �t�X�ӫ~����, ins1589_chg_flag ���A�ഫ modify by 105.12.28 (1051214006_C4) */
        insA_chg_flag = 0;       /* �t�X�ӫ~�����ഫ�I�� (add by sylvia 105.12.28 (1051214006_C4))  */
        ins7780_chg_flag = 0;    /* �t�X�ۥΨ���X�I(77,78,79,80,87,88,89)����,ins7780_chg_flag  add by sylvia 106.09.25 (1060921001_C1)
                                   77==>31�B78==>32�B79==>55�B80==>56�B87==>34�B88==>24�B89==>��椣�J�p  */
        ins1419_chg_flag = 0 ;   /* 980310,�s�O�v, 14 �I�Q���N�� 19 */
        insqday15_chg_flag = 0;  /* 980310,�s�O�v, 09 �I���[�ȫ�(15��)�אּ15�I�� */
                                 /* 981106, 01 �I���[�ȫ�(X��)�אּ66�I��(X��);
                                          05 �I���[�ȫ�(X��)�אּ67�I��(X��) */
        ins3637_chg_flag   = 0;  /* 990604,  36,37 => 31,32, �ܧ��I�ث�,�h�~�O�O���n��36,37 */
        ins98_chg_flag = 0;      /* 98�I�ذ����ഫ09+K  add by 061476 (1080408008_SC3) */
        fSunLi = 'N';
        provision[0]=' '; provision[1]='\0';
        flgIns96To11 = 'N';
        injured_cover39_ori = 0; damage_cover39_ori = 0;
        f_provision_D = 0 ;
        f_provision_E = 0 ;
        f_provision_X = 0 ;
        f_provision_H = 0 ;
        f_provision_K = 0 ;
        f_provision_L = 0 ;
        f_provision_ZZ = 0 ;
        provision_E[0]=' '; provision_E[1]='\0'; cover_E_last = 0;
        f_provision_R = 0; /* ����������[���� add by sylvia 104.11.05 (1041002004_C3) */
        f_provision_EZ = 0; /* �P�ɨϥ�EZ���� add by sylvia 105.07.19 */
        /* �������[�O�Y��  add by sylvia 104.11.25 (1021211003_C1) */
        pcar_price    = 1.0;
        fhi_price = 'N'; /* �w�]���ŦX�������[�O */
        f_provision_S = 0; /* �������[�O�Y�� ���[����  */
        f_provision_J = 0 ; /* add by sylvia 105.09.23 */
        damage_cover11_ori = 0;
        injured_cover31 = 0;injured_cover31_ori = 0;damage_cover31 = 0;
        damage_cover32 = 0;damage_cover32_ori = 0;
        damage_cover149 = 0;
        /*1101209008_SC1_�_�@�Ͻվ��ĳ��O��סA����31.32�e��O�B*/
        injured_cover31_pre = 0;
        damage_cover31_pre = 0;
        damage_cover32_pre = 0;
        deduct31_pre = 0;
        deduct32_pre = 0;

        /* ��~�βĤT�H�f�B�~���[����(T����) add by sylvia 104.12.02 (104111011_C1) */
        safe_rate = manage_rate = 0.0;

        /* 951127,�W�ߨT��(�g��N��F05*,F06*,F981*,G05*) 96�~02�����O�����׭q */
        if ((strncmp(iofficer,"F05",3)==0) || (strncmp(iofficer,"F06",3)==0) ||
            (strncmp(iofficer,"F981",4)==0) ||(strncmp(iofficer,"G05",3)==0) ){
                fSunLi ='Y';
        }else{
            fSunLi ='N';
        }

				/* 980223, �x�s�O�g�N   */
				if((strncmp(iofficer, "Y61024ZC03",10) == 0)||(strncmp(iofficer, "Y61024ZC04",10) == 0)||
				   (strncmp(iofficer, "Y61024ZCRA",10) == 0)||
				   (strncmp(iofficer, "Y03613ZC6",9) == 0)||(strncmp(iofficer, "Y03613ZCD",9) == 0)||
				   (strncmp(iofficer, "Y03613ZCA",9) == 0)||(strncmp(iofficer, "Y03613ZC5",9) == 0))
				{
				    fTaishin   = 'Y';
				}else{
				    fTaishin   = 'N';
				}

        /* �_�G�Ұ� -------------------------------------------------------- */
        /* �s�W��˭]�Ұ�(64*)��ӿ�z add by sylvia 105.12.22 (1051220006_C1) */
        strcpy(upd29_cov1,"N"); /* �O�_����29�I�ثO�B1���B (�_�G�ҰϱM��) add by sylvia 105.09.19 */
        fquota63 = 'N'; /* �]�����ĳ149�I��,���ĳ�W�h���� modify by sylvia 106.03.13 (1060302003_C1) */
        if(0)
        {
            if (((strncmp(iquota,"63",2) == 0) || (strncmp(iquota,"64",2) == 0))&&
                (strcmp(imgr,"2") == 0) && (strncmp(iroute,"PA",2) != 0) && (fBarcode == 'N') &&
                ((strcmp(car_typei,"03")==0)||(strcmp(car_typei,"22")==0)))
                fquota63 = 'Y'; /* �ŦX�_�G�ϯS�w���� */
            else
                fquota63 = 'N'; /* ���ŦX�_�G�ϯS�w���� */
        }
        /* ----------------------------------------------------------------- */
        /* �O�o�q��21/31 ����ĳ�����I�� add by 061476 107.07.27(1070314007_SC3)*/
        fbz_2131 = 'N';
        if ((strncmp(bzfrom,"21",2) == 0) || (strncmp(bzfrom,"31",2) == 0))
        {
            fbz_2131 = 'Y';
        }
        /* ----------------------------------------------------------------- */
        /* �q�ʨ� ����ĳ�����I�� (1130510009_C13)*/
        fBEV = 'N';
        strcpy(brand_BEV, substring(brandi,7,2));
        if (strncmp(brand_BEV,"01",2) == 0)
        {
        	fBEV = 'Y';
        }
        /* ----------------------------------------------------------------- */
        /* �R�q�� ����ĳ�����I�� (1120927002_C05)*/
        fES = 'N';
        if ((strncmp(car_typei,"CS",2)==0) || (strncmp(last_ply+(5),"ES",2)==0))
        {
        	fES = 'Y';
        }
        /* ----------------------------------------------------------------- */
        /* �r�V�Z��X�I ����ĳ�����I�� add by sylvia 114.04.24 (1140409004_C01) */
        f25C01= 'N';
        if ((iply_ins[531] == 1)||(iply_ins[532] == 1))
        {
        	f25C01= 'Y';	/* �r�V�Z��X�I�ֶ̤��ӫO531+532�I��, �G�H�ˮ�531��532�I�جO�_�s�b�Y�i */
        }

        /* ----------------------------------------------------------------- */
        /* ������O����ĳ�����I�� add by 061476 (1080730006_SC1)109.01.17 */
        /* �s�W�q���N��KA04 modify by 061476 (1091022004_SC1) */
        /* �s�W�q���N��KA05 modify by 061476 (1100106005_SC1) */
        /* �s�W�q���N��KA06 modify by 061476 (1100302002_SC1) */
        fkaxx = 'N';
        if ((strncmp(iroute,"KA02",4) == 0) || (strncmp(iroute,"KA03",4) == 0) ||
            (strncmp(iroute,"KA04",4) == 0) || (strncmp(iroute,"KA05",4) == 0) ||
            (strncmp(iroute,"KA06",4) == 0))
        {
            fkaxx = 'Y';
        }
        /* ----------------------------------------------------------------- */
        /* �s��(636300)�O��(630200) �ۦ��I�ث�ĳ�W�h add by sylvia 106.06.23 (1051220006_C1)*/
        /* �H�U�T�ؤ���ĳ�����I�ت������u���Ұϫ�ĳ�W�h�A�ݱư� (���Msug_flag='N'������L��ĳ�W�h)*/
        f245_265 = 'N';
        if (((strncmp(iquota,"6363",4) == 0) || (strncmp(iquota,"6302",4) == 0)) &&
            (strcmp(imgr,"2") == 0)&&
            (fbz_2131 == 'N')&&(fkaxx == 'N')&&(fBEV == 'N')&&(fES == 'N')&&
            (f25C01 == 'N')&&(strncmp(iroute,"JB",2) != 0))
        {
            f245_265 = 'Y';
        }
        /* ----------------------------------------------------------------- */
        /* �s�_�ҰϽվ��ĳ��O�զX(27/34�I��) add by 061476 108.05.09 (1080322003_SC1) */
        fquota_63 = 'N';
        if ((strncmp(iquota,"63",2) == 0) && (strcmp(imgr,"2") == 0))
        {
            if ((strncmp(car_typei,"03",2)==0)||(strncmp(car_typei,"22",2)==0)||
                (strncmp(car_typei,"04",2)==0)||(strncmp(car_typei,"19",2)==0))
            {
            	fquota_63 = 'Y';
            }
        }
        /* ----------------------------------------------------------------- */
        /* �_�@�ҰϷs�W��ĳ��O�զX add by 061476 108.05.27 (1080507001_SC1) */
        /* �P�\���T�{�A�H�U�T�ؤ���ĳ�����I�ت������u��_�@�Ұϫ�ĳ�W�h�A�ݱư� */
        fquota_62 = 'N';
        if ((strncmp(iquota,"62",2) == 0)&&(strcmp(imgr,"2") == 0)&&(fBarcode == 'N')&&
            (fbz_2131 == 'N')&&(fkaxx == 'N')&&(fBEV == 'N')&&(fES == 'N')&&
            (f25C01 == 'N')&&(strncmp(iroute,"JB",2) != 0))
        {
            if ((ISCAR_SET1(car_typei))||
                (strncmp(car_typei,"01",2)==0)||(strncmp(car_typei,"02",2)==0))
            {
            	fquota_62 = 'Y';

            }
        }
        /* ----------------------------------------------------------------- */
        /* �����ҰϯS�w�W�h�ݽվ���O�զX add by 061476 108.03.20(1080308004_SC1) */
        fquota67 = 0;
        if ((iplyyear==2019) || (iplyyear==2020 && iplymonth<=1))
        {
        	if ((strncmp(iquota,"67",2) == 0)&&(strcmp(imgr,"2") == 0)&&(strncmp(iroute,"I",1) != 0))
        	{
        		if ((strncmp(car_typei,"03",2)==0)||(strncmp(car_typei,"22",2)==0)||
        		    (strncmp(car_typei,"04",2)==0)||(strncmp(car_typei,"19",2)==0))
        		{
        			$SELECT count(*) INTO $fquota67
        			   FROM ply_ins_type_last
        			  WHERE ipolicy = $last_ply
        			    AND iins_type = '30'
        			    AND mdeduct IN (1,124,155,12455);

        			if (NOT_FOUND) fquota67 = 0;
        		}
        	}
        }

        /**********************************************************************/
				/* �P�_�O�_�ŦX�������[�O �è��o�������[�O�Y��   add by sylvia 104.11.26
				        (����03,21,22,4A,2B,2C,14
				         �����I�D�I:01,05.09.85,105,118,120,122,125,126
				         ������[�I:07,10,127) */
				hi_car_price = 1.0;
				/* printf("== 4813: car_typei=[%s]mcar_price=[%f]iBasePrice=[%f]\n",car_typei,mcar_price,iBasePrice); */
				/* �������������[����(S����)  */
				if(0)
				{
	            if (((strncmp(car_typei,"03",2)==0)||(strncmp(car_typei,"21",2)==0)||
	    	       (strncmp(car_typei,"22",2)==0)||(strncmp(car_typei,"4A",2)==0)||
	    	       (strncmp(car_typei,"2B",2)==0)||(strncmp(car_typei,"2C",2)==0)||
	    	       (strncmp(car_typei,"14",2)==0)||(strncmp(car_typei,"2A",2)==0)) &&
	    	       (mcar_price * 10000 >= iBasePrice ))
			    	    {
			    	        /* printf("== 4819: car_typei=[%s]mcar_price=[%f]iBasePrice=[%f]\n",car_typei,mcar_price,iBasePrice); */
			    	        fhi_price = 'Y';
			                $select pcar_price  into $hi_car_price
			                   from car_price_factor
			                  where car_price_bgn <= $mcar_price * 10000
			                    and car_price_end >  $mcar_price * 10000
			                    and drate = (select drate from ca_rate_date where icode = $tmp_frate2
			                                    and itable = 'car_price_factor');
			                if (NOT_FOUND)
			                {
			                    hi_car_price = 0.0; /* �����D */
			                    $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,' ','�A�ΰ������[�O,���d�L�[�O�Y��','1','E41',$iofficer);
			    		        goto end;
			                }
			    	    }
				}


				/**********************************************************************/
				/* 102.08.26 ,for �s�A����O����P�_
				    ==> �w��h�~�ӫO�A�������I�A��O�J�p�אּ��ĳ�s�A�������I
				   -----------------------------------------------------------------------
				      ��  ��		     �t  ��		 �������l�O�B
				   -----------------------------------------------------------------------
				      �ۤp�f(04�B19)		*		    1�U
				   -----------------------------------------------------------------------
				     	 		   �겣��(���t�� 10)        2�U
				     			(�t��0131*�B E5*���~)
				      �ۤp��(03�B22)  ---------------------------------------------------
				     			   �i�f��(���t�� 10)         2.5�U
				                       	+ �t��0131* (�겣��-TEANA)
				                        + �t��E5*   (�Ǵ���)
				   -----------------------------------------------------------------------
				    �i���j�겣���i�f���O�A�t�̡u�t�P������ƺ��@�v(car103)�]�w
				          �������t��(icar_series)�P�_�A�u���t = 10�v���겣���A��l���i�f��
				 [���~��]
			         (1)	barcode��(�]�w��car147���q���H�ΨT�B������jbarcode��)
			         (2)	�h�~�ӫO���e�t�� ��105�I�ؼȤ��i���[���I�ء��̡G�ۥΤp�T���N�B���O�I(67)�B�N���O�ΫO�I�Ф��B��(63)�B�N���O�ΫO�I�Ф�ҫ�(65)�C
			         (3)	����~��(�q���N���GPA*)�C
				*/

				/* 102.09.06
				   �w�郞�ج��ۥΤp�Ȩ�(03)�B�ۥΤp�ȳf��(22)�B��������p�Ȩ�(21)�B�ۥΤp�f��(04)�B���q�渹�ۥΤp�f��(19) �̡A
				   �Y����O�榳�ӫO�u�A������l���I�v�̡G
				   1.��O�q���ѤW�@�ߤ����[ú�ڳ�A�Y�ϸӥ�q�L�t�μf�֥�M�C
				   2.�Y��car147�]�w���Ȧ�q��barcode��A�h���L�sbarcode�n�O�ѡA�u�L�s�j���I�q�������O�n�O��(2p)
				     (�Ȧ�q����car147�W�Ҧ��]�w�n�[�L2p��O�n�O��)�C
				   ���ŦX�W�z���Ϊ̡A�Y�G
				   (1)���q�L�t�μf�̡֪A�f�֪��A�X�N��500�אּ505�C
				   (2)���q�L�t�μf�̡֪A�f�֪��A�X���ܰʡC
				*/
				/* 103.10.02 ����(B*) & �έ�(A09*)03,21,22���ةӫO�����I(05,105,09,105)�ରA���ӫ~(118+119,120+121,122+123)
				       modify by sylvia */
				/* 104.01.22 ���q(J*) 03,21,22���ةӫO�����I(05,105,09,105)�ରA���ӫ~(118+119,120+121,122+123)
				       modify by sylvia (1040114008_C1) */
        minjured_cover105_sug = 0 ;
        minjured_cover105_pre = 0;

        /* �t�X�ӫ~���� */
        mdamage_cover_09_sug = mdamage_cover_05_sug = mdamage_cover_01_sug = 0;
        mdamage_cover_153_sug = mdamage_cover_152_sug = mdamage_cover_161_sug = mdamage_cover_162_sug = 0;
        mdamage_cover_154_sug = mdamage_cover_155_sug = mdamage_cover_156_sug = mdamage_cover_163_sug = 0;
        mdamage_cover_63_sug = mdamage_cover_65_sug = mdamage_cover_67_sug = 0;
        mdamage_cover_22_sug = 0;
        qday_154 = qday_155 = qday_156 = qday_163 = qday_67 = qday_238= 0;
        damage_cover56=0;

				/*  �s�W����(4A,8A,9A,9B,2A,2B,2C)����ĳA���ӫ~ modify by sylvia 104.02.16(1040202006_C3) */
				/*if ((f_05_exist=='Y')&&((f_63_exist=='N')&&(f_65_exist=='N')&&(f_67_exist=='N'))&&(ins1589_chg_flag!=1)&&(fBarcode=='N')&&(fIns21_50=='N')&&(strncmp(iroute,"PA",2) != 0 )){*/
				if (STOP_CHG1589_FLAG == 'N')
				{
    	    if ((fBarcode=='N')&&(fIns21_50=='N'))
    	    {   /* �ۤp�f */
    	        if ((strncmp(car_typei,"04",2)==0)||(strncmp(car_typei,"19",2)==0))
    	        {
    	            /* 05 => 105 */
    	            t_count = 0;
    	            /* �t�X���O�X��104/01/01�W�u,05���A��105�I��,�G���A��h�~�O�_��05�I��,t_count=0  mark by sylvia 103.12.16(1031209009_C1) */
    	            /* $EXECUTE preChk0585 INTO $t_count USING $last_ply,"05";  */
    	            if (t_count > 0)
    	            {
                        chk_flag = 1; /* 03 04 19 21 22���ءA�h�~��05��,2p�B5p���Lú�ڳ� (barcode��bca3xxlib.ec WriteToEstimate()���B�z) */
    	                	t_count = 0;
    		        				$EXECUTE preChk636567 INTO $t_count USING $last_ply;
						    			if (t_count == 0)
						    			{  /* �h�~�� 05�A�B�S��63 65 67 */
					    			    if (strncmp(iroute,"PA",2) != 0 )
					    			    {
					    			    	/* �D���� */
					                ins1589_chg_flag = 2 ;
					    						minjured_cover105_sug = 10000 ;
					    			    }
		    							}
    		    			}
    		    			else
    		    			{
                    /* 85 => 105 */
		    		        /* 102.09.23 �_�G�Ұ�(�~�Z�k��63*)���g�P�ӸΫH(A23*)�M�� 85=>105 ,�u��3�Ӥ�(103.02�����) */
		    		        if ((iplyyear==2013) || (iplyyear==2014 && iplymonth<=2))
		    		        {
    		            	if ( (strncmp(iofficer,"A23",3) == 0) && (strncmp(iquota,"63",2)==0) )
	    		            {
	    			        		t_count = 0;
						    				/* �ӫO�\���n�D���A�ഫ85�I�� mark by sylvia 103.12.16 (1031209009_C1) */
						    				/* $EXECUTE preChk0585 INTO $t_count USING $last_ply,"85";  */
						    				if (t_count > 0)
						    				{
					    				    /*chk_flag = 1;  5p �ثe���ӴN���Lú�ڳ�  */
					    				    chk_flag = 1;  /* 5P�w�|�C�Lú�ڳ�,��85��105�٬O���C�L modify by sylvia 103.12.16(1031209009_C1) */
					    				    t_count = 0;
					    				    $EXECUTE preChk636567 INTO $t_count USING $last_ply;
					    				    if (t_count == 0)
					    				    {
	    				        			/* �h�~�� 05�A�B�S��63 65 67 */
					    							ins1589_chg_flag = 3 ;
					    							minjured_cover105_sug = 10000 ;
					    				    }
	    									}
	    		            }
    		        		}
    		    			}
              } /* end �ۤp�f */
    					else if ((strncmp(car_typei,"03",2)==0)||(strncmp(car_typei,"22",2)==0)||
    		         (strncmp(car_typei,"21",2)==0))
    					{
		    		    /* �ۤp�� */
		    		    /* 05�I�ؤ��A�ഫ118+119 modify by sylvia 104.06.03 (1040515009_C4)
		    		    /* �t�X�ӫ~����,���A�ഫ118+119�I�� modify by sylvia 105.12.28 (1051214006_C4) */
		    		    if (intopt == 55 )
		    		    {
		    		        /* ���ظg�P��8-11����O,���n�ഫ */
		    		        $select count(*) into $t_count
		        		   from ply_ins_type_last
		        		  where ipolicy = $last_ply and iins_type in ('01','09','05','105','201','205','209');
		    		    }
		    		    else
	    		    	{
	        				t_count = 0;
	        	    }

		    		    /* ����(B*)�θέ�(A09*),���ӫO�����I('01','05','09','105')�B���ج�03,22,21��, ���ରA���ӫ~(118+119,120+121,122+123)
		    		     	   add by sylvia 103.10.01  */
		    		    /* �]�s�W�ഫ�����ӫO�N A01,A04,A10,A11,A21,A23,A25  ��H�I�s IS_CHG_A_prod �T�{����
		    		     	   modify by sylvia 103.10.22 (1031016004_C1) */
		    		    /* �s�W���q(J*)�ഫ�����I��A���ӫ~ modify by sylvia 104.01.22 (1040114008_C1) */
		    		    /* ���Ű������[�O���� (fhi_price=='N') �~��ĳ�ഫ */
    		    		if ((IS_CHG_A_prod(iofficer) > 0) && (t_count > 0) && (fhi_price=='N'))
                {
                        /* �ŦX�������[�O����, �����ݰ�����, ����ĳ��A�� add by sylvia 104.11.26(1021211003_C1)  */
                        if (fdmg_sug == 'Y')
                        {
                            if (intopt == 55 )
                            {
                                $select decode(iins_type,'05',5,'205',5,'105',6,'09',7,'209',7,8)
            		     	   					 into $ins1589_chg_flag
            		     	   					 from ply_ins_type_last
            		     	  					where ipolicy = $last_ply
            		     	    					and iins_type in ('01','09','05','105','201','205','209');
                            }
                            else
                            {
				            		     	$select decode(iins_type,'105',6,'09',7,'209',7,8)
				            		     	   into $ins1589_chg_flag
				            		     	   from ply_ins_type_last
				            		     	  where ipolicy = $last_ply
				            		     	    and iins_type in ('01','09','105','201','209');
            		    				}
        								}
        								else
        								{
                            ins1589_chg_flag = 0;
                        }

					    		     	/* 05��105�I��==>118+119, ���������l
					    		     	   �겣��: 20,000, ���t��0131*(TEANA)�t��E5*(�Ǵ���):25,000
					    		     	   �i�f��: 25,000 */
       		    					if ((ins1589_chg_flag == 5) || (ins1589_chg_flag == 6))
                        {
                            /* �ഫA���ӫ~�٬O�n�Lú�ڳ�  modify by sylvia 103.12.16 (1031209009_C1) */
				       		    	    /*chk_flag = 1;*//* ���Lú�ڳ�  */
				       		    	    chk_flag = 0;
				       		    	    if (ins1589_chg_flag == 6)
				       		    	    {
       		    	        			/* ����X�h�~���������l�O�B */
					          		    	$select minjured_cover into $minjured_cover105_pre
					                		   from ply_ins_type_last
					                		  where ipolicy = $last_ply and iins_type = '105';
					       		    	  }

       		    	    				if (strncmp(iofficer,"A09",3) == 0)
				       		    	    {
				       		    	        minjured_cover105_sug = 25000 ;  /* �έ𤣽׶i�f�ΰ겣,�@��25000 */
				       		    	    }
				       		    	    else
				       		    	    {
			       		    	        /* 05��118+119, �������l�p�U modify by sylvia 103.12.16 (1031128004_C1) */
			       		    	        if(ins1589_chg_flag == 5)
			       		    	        {
                                if (strncmp(s_car_series,"10",2)==0)
             			    					{
                                        minjured_cover105_sug = 20000 ;  /* �겣�� */
             											/* �ҥ~�G�t��0131* (�겣��-TEANA) �B �t��E5*   (�Ǵ���) */
             											if ((strncmp(brandi,"0131",4)==0)||(strncmp(brandi,"E5",2)==0))
             			            				minjured_cover105_sug = 25000 ;
                                }
                                else
					             			    {
					                       			minjured_cover105_sug = 25000 ;  /* �i�f�� */
					             			    }
             									}
             									else
             									{
             			    					/* 105��118+119(ins1589_chg_flag=6),�������l�P�h�~105���������l(�έ𰣥~) modify by sylvia 103.12.16 (1031128004_C1)*/
             			    					minjured_cover105_sug = minjured_cover105_pre;
             									}
          		    					}
                        	}
                } /* ����(B*)�θέ�(A09*)��A01,A04,A10,A11,A21,A23,A25,���ӫO�����I('01','05','09','105') end */
    		    		else
    		    		{
    		    					/* 05 => 105 */
                      t_count = 0;
                      /* �t�X���O�X��104/01/01�W�u,05���A��105�I��,�G���A��h�~�O�_��05�I��,t_count=0  mark by sylvia 103.12.16(1031209009_C1) */
       	              /* $EXECUTE preChk0585 INTO $t_count USING $last_ply,"05"; */

       		    				if (t_count > 0)
       		    				{
			       		    	    chk_flag = 1;/* 03 04 19 21 22���ءA�h�~��05��,2p�B5p���Lú�ڳ� (barcode��bca3xxlib.ec WriteToEstimate()���B�z) */
			       		    	    t_count = 0;
			                            $EXECUTE preChk636567 INTO $t_count USING $last_ply;
			       		    	    if (t_count == 0)
			       		    	    {
       		    	        			/* �h�~�� 05�A�B�S��63 65 67 */
						       		    	 	if (strncmp(iroute,"PA",2) != 0 )
						       		    	 	{  /* �D���� */
       				    							ins1589_chg_flag = 2 ;
       				    							if (strncmp(s_car_series,"10",2)==0)
       				    							{
                                        minjured_cover105_sug = 20000 ;  /* �겣�� */
                                        /* �ҥ~�G�t��0131* (�겣��-TEANA) �B �t��E5*   (�Ǵ���) */
       																if ((strncmp(brandi,"0131",4)==0)||(strncmp(brandi,"E5",2)==0))
											       					{
											       					    minjured_cover105_sug = 25000 ;
											       					}
       																/*102.10.22 �Ω�(A14*)�վ㤣�����l�O�B�G
       					    												[2.2 �U]
                                            �E�t��0124* (�겣��-New Sentra)   �t��0133* (�겣��-Tiida)
                                            �E�t��0134* (�겣��-Bluebird)     �t��0135* (�겣��-Livina)
                                            [2.6 �U]
                                            �E�t��0131* (�겣��-TEANA) */
       																if (strncmp(iofficer,"A14",3)==0)
       																{
       					    											if ((strncmp(brandi,"0124",4)==0) || (strncmp(brandi,"0133",4)==0) ||
       																					(strncmp(brandi,"0134",4)==0) || (strncmp(brandi,"0135",4)==0) )
											       					    {
											       					        minjured_cover105_sug = 22000 ;
											       					    }
											       					    else if (strncmp(brandi,"0131",4)==0)
											       					    {
											                     		minjured_cover105_sug = 26000 ;
											       					    }
       				        								}
       				    							}
       				    							else
       				    							{
       				        							minjured_cover105_sug = 25000 ;  /* �i�f�� */
										       					/*102.10.22 �Ω�(A14*)�վ㤣�����l�O�B�G
										       					[2.6 �U]
										       					�E�t��A2* (�鲣�^��)
										       					[3.5 �U]
										       					�E�t��58* (�i�f��-Infiniti)  */
                                    if (strncmp(iofficer,"A14",3)==0)
                                    {
       					    									if (strncmp(brandi,"A2",2)==0)
									       					    {
									       					        minjured_cover105_sug = 26000 ;
									       					    }
									       					    else if (strncmp(brandi,"58",2)==0)
									       					    {
									       					        minjured_cover105_sug = 35000 ;
									       					    }
       															}
       				    							}
       												}
       			    					}
       		        		}
       		        		else
       		        		{
	       		            /* 85 => 105 */
	                            /* 102.09.23 �_�G�Ұ�(�~�Z�k��63*)���g�P�ӸΫH(A23*)�M�� 85=>105 ,�u��3�Ӥ�(103.02�����) */
	       		            if ((iplyyear==2013) || (iplyyear==2014 && iplymonth<=2))
	       		            {
	       		                if ((strncmp(iofficer,"A23",3) == 0) && (strncmp(iquota,"63",2)==0))
	       		                {
                              t_count = 0;
                                    /* �ӫO�\���n�D���A�ഫ85�I�� mark by sylvia 103.12.16 (1031209009_C1) */
						       				    /* $EXECUTE preChk0585 INTO $t_count USING $last_ply,"85";   */
						       				    if (t_count > 0)
						       				    {
						       				    	/*chk_flag = 1;  5p �ثe���ӴN���Lú�ڳ�  */
						       				        chk_flag = 1; /* 5P�w�g�|�Lú�ڳ�,��85��105���٬O���L  modify by sylvia 103.12.16(1031209009_C1) */

       				      						  t_count = 0;
       														$EXECUTE preChk636567 INTO $t_count USING $last_ply;
       														if (t_count == 0)
       														{
								       					    /* �h�~�� 05�A�B�S��63 65 67 */
								       					    ins1589_chg_flag = 3 ;
								       					    if (strncmp(s_car_series,"10",2)==0)
								       					    {
       					        							minjured_cover105_sug = 20000 ;  /* �겣�� */
										       						/* �ҥ~�G�t��0131* (�겣��-TEANA) �B �t��E5*   (�Ǵ���) */
										       						if ((strncmp(brandi,"0131",4)==0)||(strncmp(brandi,"E5",2)==0))
										       						{
										       						    minjured_cover105_sug = 25000 ;
										       						}
       					    								}
       					    								else
								       					    {
								       					        minjured_cover105_sug = 25000 ;  /* �i�f�� */
								       					    }
       														}/* end �h�~�� 05�A�B�S��63 65 67 */
       				    						}
       		         					}
       		            	}
       		        	}/* end 85 => 105 */
    		    		}/* end 05 => 105 */
							}/* �ۤp��(03,21,22) end */

                /* 102.11.8 , �w��ŦX 05 =>105 �� 85=>105 �̡A
    		       �Y1�U�� ������O�O�B ��10�U�A��ĳ��O�զX��105�I���������l�O�B�@�ߧ令1�U��
    		       �Y      ������O�O�B �� 1�U�A���� 05 =>105 �� 85=>105 ����ĳ�ʧ@  */
			    		/* 05��118,105��118 ��ӿ�z modify by sylvia 103.10.01 */
			    		if (ins1589_chg_flag==2 || ins1589_chg_flag==3 ||
			    		    ins1589_chg_flag==5 || ins1589_chg_flag==6)
			    		{
    		    		if (cover_01 >= 10000 && cover_01 < 100000)
    		    		{
    		        	if ((ins1589_chg_flag==6) && (minjured_cover105_pre <= 10000))
    		            minjured_cover105_sug = minjured_cover105_pre;
    		        	else
    		     	    	minjured_cover105_sug = 10000 ;
    		    		}
    		    		else if (cover_01 < 10000)
    		    		{
    		        		ins1589_chg_flag = 0 ;
    		     				minjured_cover105_sug = 0 ;
    		    		}
							}
            }
        } /* STOP_CHG1589_FLAG = 'N' */

        /* �P�_�]�ӫ~�I����ӫ~�ഫ���O add by sylvia 105.12.28 (1051214006_C4)       */
        $select decode(iins_type,'85',1,'120',2,'105',3,'118',4,'122',5,'112',6,0)
        		     	      into $insA_chg_flag
        		     	      from ply_ins_type_last
        		     	     where ipolicy = $last_ply
        		     	       and iins_type in ('85','120','105','118','122','112');
        if (SQLCODE == SQLNOTFOUND) insA_chg_flag = 0;

        /*  960730, �j���I�ƲĤ@�ӽT�O�L�X*/
        if( comp_flag == 'Y')
        {   strcat(pre_ch_ins_grp[0], "�j���I");
            strcat(pre_ch_ins_grp[0],"�@");
            ch_ins_cnt ++;
        }

        /*f_iBroker = 0;*/
        injured_cover52_old = 0;
        injured_cover53_old = 0;
        injured_cover55_old = 0;

        /* �ˮ֬O�_���ӫO�ۥΨ���X�O�I(�H77��79�I�ج��ˮְ��)
           ���ӫO�ۥΨ���X�O�I,��ĳ��O�զX=���O�զX add by sylvia 103.04.09 */
        /* �X�֨�U�� cnt_non_sug modify by sylvia 104.11.26 */
        /* $EXECUTE preChk0585 INTO $cnt_ins77 USING $last_ply,"77";
        $EXECUTE preChk0585 INTO $cnt_ins79 USING $last_ply,"79"; */

        /* �ˮ֬O�_���ӫO�����IA��(118,120,122) add by sylvia 103.08.12 */
        /* �X�֨�U�� cnt_non_sug modify by sylvia 104.11.26 */
        /* $EXECUTE preChk0585 INTO $cnt_ins118 USING $last_ply,"118";
        $EXECUTE preChk0585 INTO $cnt_ins120 USING $last_ply,"120";
        $EXECUTE preChk0585 INTO $cnt_ins122 USING $last_ply,"122"; */


        for (i=1;i<1000;i++)
        {
            switch(i)
            {

                case 26: case 29: case 30: case 149: case 249: case 301: case 302:
                    break;

                case 110: case 111: case 112: case 113: case 114: case 115: case 117:
                    cnt_110_117 = cnt_110_117+iply_ins[i];
                    break;

                case 101: case 102: case 103: case 104:
                    cnt_EB = cnt_EB+iply_ins[i];
                    break;

                case 131: case 331:
                    cnt_ins131 = cnt_ins131+iply_ins[i];
                    break;

                case 132: case 332:
                    cnt_ins132 = cnt_ins132+iply_ins[i];
                    break;

                case 77: case 79: case 78: case 80: case 87: case 88: case 89:
                    cnt_non_sug = cnt_non_sug+iply_ins[i];
                    break;

                case 118: case 120: case 122: case 125: case 126:
                case 127: case 129: case 130: case 128: case 133: case 134: case 135:
                case 136:
                    cnt_non_sug = cnt_non_sug+iply_ins[i];
                    break;
                    
                case 530: case 531: case 532: case 555: case 561: case 562: case 563:
                    cnt_f25C01 = cnt_f25C01+iply_ins[i];
                		if (cnt_f25C01 > 0 ) f25C01 = 'Y';	/* �r�V�Z��X�I */
                    break;
            }
        }

        if (strcmp(car_typei,"51") == 0)
        {
            if ((cnt_EB > 0) && (cnt_EB < 4))
            {
                $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,' ','�q�ʦۦ樮��X�I�U�I�إ��@�_�ӫO','1','E42',$iofficer);
            }
        }

				/*1101209008_SC1_�_�@�Ͻվ��ĳ��O��� (add by 071004 2021.12.30)*/
				/*����31.32�e��O�B*/
				if(iply_ins[31] == 1 || iply_ins[231] == 1)
        {
            $select minjured_cover,mdamage_cover,mdeduct
	       			 into $injured_cover31_pre,$damage_cover31_pre,$deduct31_pre
	       			 from ply_ins_type_last
              where ipolicy = $last_ply and iins_type in ('31','231');
        }

        if(iply_ins[32] == 1 || iply_ins[232] == 1)
        {
            $select mdamage_cover,mdeduct
	       			 into $damage_cover32_pre,$deduct32_pre
	       			 from ply_ins_type_last
              where ipolicy = $last_ply and iins_type in ('32','232');
        }

        /* �������l�O���覡�O: add by sylvia 105.03.16 (1050226003_C3)
            1:�������l�h��(01,122)(85�B105�B118(�s��:�O�v�N�� = 79)
            2:���t�������l(05�B09�B120�B125�B126)
            3:�������l�u�p�@�� 85�B105�B118(�¨�: �O�v�N�� <= 78)
            ' ': �D�W�z�I�دd�ť�  */
        /* �t�X�ӫ~����, ���¨�(105,118,85,�O�v�N��<79),�N�ର05+152��09+153���¨�,�N��=5
                           �s��(105,118,85,�O�v�N��>=79),�N�ର05+152��09+153���s��,�N��=4
        */
        /* BUG�ץ��G�]����אּ���T�J�`(93�O�v�H��)�A�����]�ݭn����ܧ� modity by 061476 107.03.26*/
        if ((atoi(tmp_frate2)) < 93)
        {
        	sprintf(stmt, "select case when iins_type in ('01','122','201') then '1' \
                                       when iins_type in ('120','125','126') then '2' \
                                       when iins_type in ('05','09','205','209') then \
                                            case when (select count(iins_type) from ply_ins_type_last \
                                                 where ipolicy = a.ipolicy \
                                                 and iins_type in ('152','153')) > 0 then '4' else '2' end \
                                       when iins_type in ('85','105','118') then \
                                            case when drate_ym <= 78 then '5' else '4' end \
                                  else ' ' end \
                        FROM ply_ins_type_last a \
                       WHERE ipolicy =? \
                         AND iins_type IN (%s) ", INS01_STRING);
        }
        else
        {
        	sprintf(stmt, "select case when iins_type in ('01','122','120','125','126','05','09','85','105','118','201','205','209') then '1' \
                                   else ' ' end \
                        FROM ply_ins_type_last a \
                       WHERE ipolicy =? \
                         AND iins_type IN (%s) ", INS01_STRING);
        }

        $PREPARE prep_chkdmg FROM $stmt;
        $EXECUTE prep_chkdmg INTO $funknown_dmg_ori USING $last_ply;
        strcpy(funknown_dmg_sug, funknown_dmg_ori); /* �w�]���O�զX�P��ĳ��O�զX�ۦP */



        /* �ˮ֬O�_�����[T����,�ìd�X�[��O�T�� add by sylvia 104.12.02 (104111011_C1) */
        /* �s�W149�I��  add by sylvia 106.02.16 (1050601006_C4) */
        cnt_provision_T = 0;
        f_provision_T = 0;
        $select count(*) into $cnt_provision_T from ply_ins_type_last where ipolicy = $last_ply
            and iins_type in ('31','32','133','134','149','231','232','249') and trim(provision)||';' matches "*T;*";

        if (cnt_provision_T > 0)
        {
            f_provision_T = 1;
            $SELECT safe_rate ,manage_rate
               INTO $safe_rate , $manage_rate
               FROM ca_truck_transport a
              WHERE iassured  = $license
                AND iofficer  = $iofficer
                AND iroute    = $iroute
                AND drate = (SELECT MAX(drate) FROM ca_truck_transport b
                              WHERE b.iassured  = a.iassured
                                AND b.iofficer  = a.iofficer
                                AND b.iroute    = a.iroute
                                AND drate    <= $dply_end
                                AND (dexpire is null or dexpire > today))
                AND (dexpire is null or dexpire > today);

            if (NOT_FOUND)
            {
                safe_rate = manage_rate = 0.0;
                f_provision_T = 0;
            }
        }


        fremark1=0;
        /* �ӫO�I�ة��� */
        while (1)
        {
            $FETCH CUR_5
                INTO $ins_type, $injured_cover, $death_cover, $damage_cover,
                     $deduct, $ins_premium,$pagent,$pcommission,$drate_ym,
                     $pdiscount,$mprem,$qserial,$pdis_rate,$simain_ins,$qday,
                     $mexpense,$sinsfcal_way,$provision;
            if (NOT_FOUND)
            {
                if (ins_count==0)
                { /* �����h,�j�h,�h���h�O */
                    /* �k���iE05���~ (1110915007_SC1) */
                    $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,'','���h�B�j�h�B�h���h�O','2','E05',$iofficer);
                    fany=0;
                    break;
                }
                else
                    break;
            }
            strcpy(ins_type,trim(ins_type));
            strcpy(simain_ins,trim(simain_ins));
            strcpy(tmp_provision,"");
            sprintf(tmp_provision,"%s;",trim(provision)); /* ���� */
            int_ins = atoi(ins_type);

				    /* �ӫO85�I�ب��֤j��7�~(84�Ӥ�) ��椣�p��O�O  add by sylvia 104.12.04 (1041104002_C1) */
				    /* �t�X�ӫ~����,85��09+153, �綷�ˮ�09+153����>7�~1��椣�J�p  add by sylvia 105.12.29 (1051214006_C4) */
				    /* 153�I�ذ����ഫ162�I�ءA�ק�E45�P�_�W�h modify by 061476 108.09.16 (1080903005_SC1) */
				    /* �ק郞�֭p��覡(��H�s�y�~��p��) modify by 061476 110.04.28 (1100330003_SC1) */
				    if ( int_ins==85 || int_ins==9 || int_ins==209)
				    {
							CarAgeMonth = 0;
							CarAgeMonth = (iplyyear-atoi(pro_year))*12 + (iplymonth-qpro_month);
							if (CarAgeMonth > 84)
							{
						    if (int_ins==85)
						    {
						        $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�ӫO85�I�إB���֡�7�~','1','E45',$iofficer);
						    }
						    else
						    {
									$select count(iins_type) into $icnt1
									   from ply_ins_type_last
									  where ipolicy   = $last_ply
									    and iins_type = '162';

									if (icnt1 > 0)
			    					$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�ӫO09+162/209+162�I�إB���֡�7�~','1','E45',$iofficer);
		    				}
							}

	    			}

				    /* 238�I�ؾ����u�ӫO3�~���s���A�W�L3�~�h�C���D�� add by 061476 (1100119001_SC3) */
				    /* 238�I�ؾ����B��JB�q���u�ӫO����>=10�~�A��L�q��������W�h */
				    if ((int_ins==238) && (ISMOT(car_typei)))
				    {
	        		CarAgeMonth = 0;
							CarAgeMonth = (iplyyear-atoi(pro_year))*12 + (iplymonth-qpro_month);

							if(strcmp(trim(iroute),"JB") == 0)
							{
								if (CarAgeMonth >= 120)
								{
								    $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�����ӫO238�I�إBJB�q������>=10�~','1','E45',$iofficer);
								    continue;
								}
							}
							else
							{
								if (CarAgeMonth >= 36)
								{
								    $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�����ӫO238�I�إB����>=3�~','1','E45',$iofficer);
								    continue;
								}
							}
	    			}

	    			/* �ӫO176�I�ب���>8�~ (1130510009_C13) */
				    if (int_ins==176)
				    {
	        		CarAgeMonth = 0;
							CarAgeMonth = (iplyyear-atoi(pro_year))*12 + (iplymonth-qpro_month);

							if (CarAgeMonth >= 96)
							{
								$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�q���ۿU���[�I����>8�~','1','E45',$iofficer);
								continue;
							}
	    			}

				    /* ���ը���X�I���J�p  add by sylvia 105.02.23 (1050105002_C3) */
				    if ((int_ins==145) || (int_ins==146) || (int_ins==148))
				    {
							$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'���ը���X�I���J�p','1','E42',$iofficer);
							continue;
	    			}

				    /* �ӫO150/151�I�ؾ����O���J�p  add by sylvia 105.09.07 (1050801007_C3) */
				    if ((int_ins==150) || (int_ins==151))
				    {
							$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�S�w�I��/������O�ݭ��s���w���e���J�p','1','E48',$iofficer);
							continue;
				    }

				    /* �s���I����O���J�p  add by 061476 107.04.03 (1061108001_SC7) */
				    /* �W�[171�B172�I�� add by 061476 110.02.01 (1091216004_SC6) */
				    if ((int_ins==157) || (int_ins==158) || (int_ins==159) || (int_ins==160)|| (int_ins==171) || (int_ins==172))
				    {
				        $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�s���I�ؤ��J�p','1','E42',$iofficer);
				        continue;
				    }

				    /* ���魫�j�l���I��O���J�p  add by 061476 109.06.10 (1090527002_SC3) */
				    /* ��09���ثO181���J�p�A���~�N�X�אּE42 modify by 061476 110.10.19(1100909003_SC3) */
				    if ((int_ins==181) && (strcmp(car_typei,"09") == 0))
				    {
							$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'09���ا�O181�I�ؤ��J�p','1','E42',$iofficer);
							continue;
				    }

				    /* �t�X�ӫ~����,�ӫO125,126,18�]�L�k�ഫ,�����O���J�p  add by sylvia 105.12.28 (1051214006_C4) */
				    /* �s�W89�I�ذ��⤣�J�p  add by sylvia 106.09.25 (1060921001_C1) */
				    if ((int_ins==125) || (int_ins==126) || (int_ins==18) || (int_ins==89))
				    {
							$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�]�ӫ~���⤣�J�p','1','E50',$iofficer);
							continue;
	    			}

	    			/* �t�X�r�V�Z��X�I�ӫ~�W�u, ��26�I�ذ���B���ഫ�B���J�p  add by sylvia 114.04.24 (1140409004_C01) */
	    			printf("-�������������������������������������������������������������������������������������������������� ply_ym =[%s] atoi(ply_ym)\n",ply_ym, atoi(ply_ym));
				    /* if ((int_ins==26) && (atoi(ply_ym) >= 11407)) */
				    if (int_ins==26)
				    {

								$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'26�I����A�Ч�ξr�V�Z��X�O�I���s����','1','E50',$iofficer);
								continue;

	    			}

            /* 101.06.25 */
	    			if (f_provision_D==0){
                if(strstr(tmp_provision,"D;") != NULL){
                    f_provision_D = 1 ;
                }
            }

            /* J���ڤ��D����  add by sylvia 105.09.23 (1050801002_C4) */
            if (f_provision_J==0){
                if(strstr(tmp_provision,"J;") != NULL){
                    f_provision_J = 1 ;
                }
            }

            /* X���ڤ��D����  add by 061476 107.11.08 (1070928002_SC4) */
            if (f_provision_X==0){
                if(strstr(tmp_provision,"X;") != NULL){
                    f_provision_X = 1 ;
                }
            }

            /* ��O���p��H���ڶO�v  add by 061476 108.04.17 (1080403003_SC1) */
            /* �n�p��H���ڶO�v (1110308005_SC3)*/
            if (f_provision_H==0){
                if(strstr(tmp_provision,"H;") != NULL){
                    f_provision_H = 1 ;
                }
            }

            if (f_provision_ZZ==0){
                if(strstr(tmp_provision,"Z;") != NULL){
                    f_provision_ZZ = 1 ;
                }
            }

            if (f_provision_K==0){
                if(strstr(tmp_provision,"K;") != NULL){
                    f_provision_K = 1 ;
                }
            }

            if (f_provision_L==0){
                if(strstr(tmp_provision,"L;") != NULL){
                    f_provision_L = 1 ;
                }
            }

            if (f_provision_E==0){
            	if(strstr(tmp_provision,"E;") != NULL){
	                f_provision_E = 1 ;
									strcpy(provision_E,trim(provision_E));
									strcat(provision_E,"E");
									cover_E_last = damage_cover; /* E���ڭn�ϥΥh�~�O�B�p����O�O�B�C��ĳ�����I�خɡA�ݭn���ѥh�~�O�B */
                }
            }

            /* ����������[���� add by sylvia 104.11.05 (1041002004_C3) */
            if (f_provision_R==0){
                if(strstr(tmp_provision,"R;") != NULL){
                    f_provision_R = 1 ;
                }
            }

            /* �������[������ add by sylvia 104.11.26 (1021211003_C1) */
            if (f_provision_S==0){
                if(strstr(tmp_provision,"S;") != NULL){
                    f_provision_S = 1 ;
                }
            }

	    			/* 100.04.01,�C�@�ӤH��ˡB�C�@�ӤH����=> �X�֬��C�@�ӤH�ˮ`(death_cover) */
	    			/* ������˫O�B, �ѧP�_����O��O�_���«� 52 53 55 */
				    if (int_ins==52 || int_ins==53 || int_ins==252 || int_ins==253 || int_ins==55)
				    {
                if (int_ins==52 || int_ins==252) injured_cover52_old = injured_cover;
								if (int_ins==53 || int_ins==253) injured_cover53_old = injured_cover;
								if (int_ins==55) injured_cover55_old = injured_cover;
                injured_cover = 0;
                ori_injured_cover = 0;
	    			}

            fany=1;
            ins_count=1;
            dtlint++;
            strcpy(sinsfcal_way,trim(sinsfcal_way));

            if (int_ins==21) {
                injured_cover = injured_cover_comp  ;
                death_cover   = death_cover_comp   ;
                damage_cover  = damage_cover_comp  ;
            }else if (int_ins==50) {
                injured_cover = injured_cover_pa_50 ;
                death_cover   = death_cover_pa_50   ;
                damage_cover  = damage_cover_pa_50  ;
            }else if (int_ins==47) {
                injured_cover = injured_cover_pa_47 ;
                death_cover   = death_cover_pa_47   ;
                damage_cover  = damage_cover_pa_47  ;
            }else if (int_ins==147) {
                injured_cover = injured_cover_pa_147 ;
                death_cover   = death_cover_pa_147   ;
                damage_cover  = damage_cover_pa_147  ;
            }else if (int_ins==48) {
               	injured_cover = injured_cover_pa_48 ;
               	death_cover   = death_cover_pa_48   ;
               	damage_cover  = damage_cover_pa_48  ;
            }

            ori_injured_cover = injured_cover;
            ori_death_cover   = death_cover;
            ori_damage_cover  = damage_cover;
            ori_deduct        = deduct;
            pre_qday          = qday;

            #ifdef PRINTF_FLAG
            printf("Trace -- TEST ins_type = [%s] \n",  ins_type);
            printf("Trace -- TEST ori_injured_cover = [%ld]ori_damage_cover=[%ld] \n",  ori_injured_cover, ori_damage_cover);
            #endif

	    			/* �O���e����O�I��(�ѦC�L��O�q�����) */
				    ch_ins[0] = '\0';
				    $EXECUTE nins INTO $ch_ins USING $ins_type;

            /* 960730,�ץ����I�ؼƶW�L9�ӮɡApre_ch_ins_grp[ins_grp_cnt]���޶W�L�d��A�O����t�m�����D
	           �쥻�G
						pre_ch_ins_grp[0]    =[����A�@�ѵs�I�@�ˮ`�I�@ ]
						pre_ch_ins_grp[1]    =[�]�l�I�@�ˮ`�I�@�d���I�@ ]
						pre_ch_ins_grp[2]    =[�ˮ`�I�@�����I�@�s�v�I�@ ] */
            /* �W�[�P�_ins_grp_cnt < 3�A�קK�I�عL�h�ɭP���� modify by 061476 107.10.25 (1071016006_SC1) */
            if (ins_grp_cnt < 3)
            {
                strcat(pre_ch_ins_grp[ins_grp_cnt],trim(ch_ins));
	        			ch_ins_cnt ++;
	    			}

            /*960730, �C��5���I�ءA�@�T��A�񤣤U���h�����]�R���w�T�{�^�A���j���I�@�w�n�� */
            if (ins_grp_cnt<3) {
                if (ch_ins_cnt == 5)
								{
								    ins_grp_cnt += 1;
								    ch_ins_cnt =  0;
								}else{
								    strcat(pre_ch_ins_grp[ins_grp_cnt],"�@");
								}
	    			}

	    			/***********************  ���Qcontinue���I��   ***********************/
            /* �O�B��0���B�z */
            if ((strcmp(ins_type,"12") != 0) && (damage_cover == 0))
                continue;

            /* 981106 */
				    if (strcmp(ins_type,"17") == 0){
				        if (equip_cmp(inequipment,"5") == True )
				        {/* �U�L�@�� */ /* add 101.11*/
			                    if (icar_flag[0]=='1'){
					        if (iofficer[0] =='J') {
					            f_AN_SHIN = 'Y';   /* 99.03.12 ���q�w�߱M�� */
					            strcpy(nproject, "���q�w�߱M��");
					            strcpy(note1,"J05");

					        }else if (iofficer[0] =='B') {
					            /*  102.10.08 �M�װ��� */
					            /* ���E�L�~�M�׭��s�ҥ�  modify by sylvia 103.07..04 (1030701007_C1) */
					            f_NO_WORRY = 'Y';   /* 101.11 ���E�L�~�M�� */
					            strcpy(nproject, "���E�L�~�M��");
					            strcpy(note1,"B05");
					        }
			                    }
			                    continue;
				        }
				        /* 102.12.25 */
				        if (IsPlyB=='Y'){
			                    continue;
			                }
				    } /* end (strcmp(ins_type,"17") == 0) */

	    			/* 102.12.25�G
			       DLR���s8�M��(�M�ץN��: Y43;�M�׵��O�G21)��B���ƫ�i��|��[17�B19�I�ءA
			       ��17�B19�I�بëD�ݸӱM�פ��ذe�I�ءA�G��M�ץ���O�n�O�Ѥ�
		               �i�]�t17�B19�I�ءA�礣�i�N17�B19�I�إ[�J��A�椤            */
		        if (strcmp(ins_type,"19") == 0)
		            {
					        if (IsPlyB=='Y'){
				                    continue;
					        }
			    	}

				    /*  102.10.08 */
				    /* ���E�L�~�M�׭��s�ҥ�  modify by sylvia 103.07..04 (1030701007_C1) */
				    if (strcmp(ins_type,"19") == 0){
				        /* if (f_NO_WORRY == 'Y'){
			                    strcpy(note1,"B05");
				        	   continue;
				            } */
				            /* bug�ץ�:�]��19�I�ت��Ǹ��b17�I�ثe��,�G�n���s�P�_���O�θg��N��  by sylvia 106.07.26 */
				        if ((equip_cmp(inequipment,"5") == True ) && (iofficer[0] =='B'))
				        {
			              f_NO_WORRY = 'Y';
								    strcpy(nproject, "���E�L�~�M��");
								    strcpy(note1,"B05");
				            continue;
				        }
				    }

				    /* 990604,  36,37 ��31,32 */
				    if (strcmp(ins_type,"36") == 0){
			                ins3637_chg_flag = 1;
				        strcpy(ins_type,"31");
				        sprintf(remark1,"%s","�]�����q�ĤT�H�d���I�S�w�q�����I�ؤw����A�G�����H�ĤT�H�d���O�I�����A�p�ݻ����Ь������q�A�ȤH��");
				    }else if (strcmp(ins_type,"37") == 0){
				        ins3637_chg_flag = 1;
				        strcpy(ins_type,"32");
				    }

				    /* 101.04.30,  96,97 ��11,19 */
				    if (int_ins == 96 ){
				        flgIns96To11 = 'Y';
				        strcpy(ins_type,"11");
								sprintf(remark1,"%s","������O�T��96�ѵs�l���O�I(�ҫ�)�]���A�βĤG�~����O,��ĳ���~���O11�ѵs�I");
				    }else if (int_ins == 97 ){
				        flgIns96To11 = 'Y';
				        strcpy(ins_type,"19");
				    }

				    /* �ۥΨ���X�I(77,78,79,80,87,88,89)�����ഫ add by sylvia 106.09.25 (1060921001_C1) */
				    if (strcmp(ins_type,"77") == 0){
			                ins7780_chg_flag = 1;
				        strcpy(ins_type,"31");
				    }else if (strcmp(ins_type,"78") == 0){
			                ins7780_chg_flag = 1;
				        strcpy(ins_type,"32");
				    }else if (strcmp(ins_type,"88") == 0){
			                ins7780_chg_flag = 1;
				        strcpy(ins_type,"24");
				    }

				    /* �t�X�ӫ~�����ഫ �I��152/153==>161/162 add by 061476 107.02.22 (1070212002_SC3) */
				    if(strcmp(ins_type, "152") == 0){
				        strcpy(ins_type, "161");
				    }
				    if(strcmp(ins_type, "153") == 0){
				        strcpy(ins_type, "162");
				    }

				    /* 98�I�ذ����ഫ��09+K���� add by 061476 108.04.18 (1080408008_SC3) */
				    if(strcmp(ins_type, "98") == 0){
				        ins98_chg_flag = 1;
				        strcpy(ins_type, "09");
				        strcpy(provision,trim(provision));
				        strcat(provision,";K");
				        ori_deduct = deduct = 0;   /* �ഫ09+K�ᤣ���i�f/�겣 */
				    }

				    /* K���ڰ��� 09+K�����ഫ��198 add by 061476 109.11.06 (1091103004_SC1) */
				    /*if ((ins09k_flag == 1)*/
				    if((strcmp(ins_type, "09") == 0)&&(f_provision_K == 1))
				    {
				        strcpy(ins_type, "198");
				    }

				    /* �q�ʨ��ഫ���M���I�� (1130510009_C13) */
				    if(fBEV == 'Y')
				    {
				        if(strcmp(ins_type, "01") == 0){
				        	strcpy(ins_type, "201");
				        }
				        if(strcmp(ins_type, "05") == 0){
				        	strcpy(ins_type, "205");
				        }
				        if(strcmp(ins_type, "09") == 0){
				        	strcpy(ins_type, "209");
				        }
				        if(strcmp(ins_type, "11") == 0){
				        	strcpy(ins_type, "211");
				        }
				        if(strcmp(ins_type, "31") == 0){
				        	strcpy(ins_type, "231");
				        }
				        if(strcmp(ins_type, "32") == 0){
				        	strcpy(ins_type, "232");
				        }
				        if(strcmp(ins_type, "149") == 0){
				        	strcpy(ins_type, "249");
				        }
				        if(strcmp(ins_type, "131") == 0){
				        	strcpy(ins_type, "331");
				        }
				        if(strcmp(ins_type, "132") == 0){
				        	strcpy(ins_type, "332");
				        }
				        if((strcmp(ins_type, "52") == 0)&&(fcar_class[0] == '2')){ /* ����~���ഫ */
				        	strcpy(ins_type, "252");
				        }
				        if(strcmp(ins_type, "53") == 0){
				        	strcpy(ins_type, "253");
				        }
				    }

            /* 107.07.02 �����ذe�M�פ�r modify by 061476 (1070608008_SC1) */
            /*if (f_AN_SHIN == 'Y')
            {
                strcpy(note1,"J05");
	            if ((strcmp(ins_type,"01")==0) || (strcmp(ins_type,"05")==0) ||
	                (strcmp(ins_type,"08")==0))
                {
	                sprintf(remark1,"%s","�ĤG�~����O���N�I�t�ѵs�I(�ۭt�B10%)�βĤT�H�d���I�A�B�O�O�W�L(�t)�s�x��5000���H�W");
	                sprintf(remark2,"%s","�A�Y�ذe�ĤG�~�w�߱M��");
                }else if ((strcmp(ins_type,"09")==0) || (strcmp(ins_type,"85")==0) ) {
	                sprintf(remark1,"%s","�ĤG�~����O���N�I�t���@�����I�B�ѵs�I(�ۭt�B10%)�βĤT�H�d���I");
	                sprintf(remark2,"%s","�A�Y�ذe�ĤG�~�w�߱M��");
                }

            }*/
            /*  102.10.08 */
            /* ���E�L�~�M�׭��s�ҥ�  modify by sylvia 103.07..04 (1030701007_C1) */
            /* 107.07.02 �����ذe�M�פ�r modify by 061476 (1070608008_SC1) */
            /* if ((f_NO_WORRY == 'Y') && ((strcmp(ins_type,"17")==0) || (strcmp(ins_type,"19")==0))) */
            /*if ((f_NO_WORRY == 'Y') && (fremark1 == 0))
            {
                strcpy(note1,"B05");
                if (strlen(trim(remark1))>10){
		            sprintf(remark6,"%s","�ĤG�~����O���N�I�t���@�����I�B�ѵs�I(�ۭt�B10%)�βĤT�H�d���I");
		            sprintf(remark7,"%s","�A�Y�ذe�ĤG�~���E�L�~�M��");
		        }else{
		            sprintf(remark1,"%s","�ĤG�~����O���N�I�t���@�����I�B�ѵs�I(�ۭt�B10%)�βĤT�H�d���I");
		            sprintf(remark2,"%s","�A�Y�ذe�ĤG�~���E�L�~�M��");
                }
		        fremark1 = fremark1+1;

            }*/

            /*********************************************************************/
            /* 102.12.25 :�ק�M�ץ�g����� */
            /* 980520,�j�v�~�ȧP�_, �ȳB�z�@���,�O�N�󲤹L */
            if (((ibig_comp[0]==' ')||(ibig_comp[0]=='\0')||(ibig_comp[0]=='\0'))&&
                 (IsPlyB!='Y'))
            {
                if(strstr(tmp_provision,"A;") != NULL){
                    sprintf(remark1,"%s","����O��O�O���]�t�j�v�~�Ȫ��[���ڳ]�w����A�Э��s�g�ӫO���ӽЮ֭��l�i���[�C");
                }else if (strstr(tmp_provision,"B;") != NULL){
	                sprintf(remark1,"%s","����O��O�O���]�t�j�v�~�Ȫ��[���ڳ]�w����B���]�t�F�ƥ[��O�A�Э��s�g�ӫO���ӽЮ֭��l�i���[�C");
	        			}
            }

            /* �ѵs�I*/
            else if (strcmp(ins_type,"11")==0 || strcmp(ins_type,"211")==0)
            {
                thief_add_flag = 0;
            }
            else if (strcmp(ins_type,"16")==0)
            {
                mexpense = 0;
                mexp_disc = 0;
            }
            else
            {
                mexpense = 0;
                mexp_disc = 0;
            }

            #ifdef PRINTF_FLAG
            printf("--------  sug_flag[%c]\n", sug_flag);
            printf("ins_type[%s]\n",ins_type);
            printf("death_cover[%ld]\n",death_cover);
            printf("damage_cover[%ld]\n",damage_cover);
            #endif

            /* 960612, ���ݪ��I34, ���o�h�~�O��|�ӫO�B */
            if ((strcmp(ins_type,"34") == 0)||(strcmp(ins_type,"87") == 0)||(strcmp(ins_type,"115") == 0))
            {
                strcpy( sDbname, "sysdb");
				        strcpy( sColumn, "ipolicy");
				        strcpy( sTable,  "ply_ins_cover_last");
                IfirstPlyInsCover2 = get_ply_ins_cover( sDbname, sTable, sColumn, last_ply, &rtncode, v_sMsg);

	        			if( rtncode != M_CM_OK)
                    return rtncode;

                i=1;
                mcover_inj1 = 0;
                mcover_inj2 = 0;
                mcover_dea1 = 0;
                mcover_dea2 = 0;

                IcurrPlyInsCover2 = IfirstPlyInsCover2;
								while( IcurrPlyInsCover2)
								{
								    if (i>INS_COVER_NUM) break;

								    if (i==1){
								        mcover_inj1 = IcurrPlyInsCover2->mcover ;   /* �C�@�H���|���ݪ�    */
								    }else if (i==2){
												mcover_inj2 = IcurrPlyInsCover2->mcover ;   /* �C�@�ƬG���|���ݪ� */
								    }else if (i==3){
												mcover_dea1 = IcurrPlyInsCover2->mcover ;   /* �C�@�H���G���ݪ�   */
								    }else if (i==INS_COVER_NUM){
												mcover_dea2 = IcurrPlyInsCover2->mcover ;   /* �C�@�ƬG���G���ݪ� */
                    }
		    						i++;
		    						IcurrPlyInsCover2 = IcurrPlyInsCover2->next;
                }

                #ifdef PRINTF_FLAG
								printf("mcover_inj1=[%ld]\n",mcover_inj1);
								printf("mcover_inj2=[%ld]\n",mcover_inj2);
								printf("mcover_dea1=[%ld]\n",mcover_dea1);
								printf("mcover_dea2=[%ld]\n",mcover_dea2);
								#endif

                ori_injured_cover = mcover_inj1 ; /* �C�@�H���|���ݪ�   */
                ori_damage_cover1 = mcover_inj2 ; /* �C�@�ƬG���|���ݪ� */
                ori_death_cover   = mcover_dea1 ; /* �C�@�H���G���ݪ�   */
                ori_damage_cover  = mcover_dea2 ; /* �C�@�ƬG���G���ݪ� */

                injured_cover = ori_injured_cover ;
                damage_cover1 = ori_damage_cover1 ;
                death_cover   = ori_death_cover ;
                damage_cover  = ori_damage_cover ;

                if (strcmp(ins_type,"87") == 0)
                {
                    ins7780_chg_flag = 1;
                    strcpy(ins_type,"34");
                    $update  ply_ins_cover_last
                        set iins_type = '34'
                      where ipolicy = $last_ply and iins_type = '87';
                }
            }

            if ((strcmp(ins_type,"21") == 0) || (strcmp(ins_type,"33") == 0) ||
                (strcmp(ins_type,"35") == 0) || (strcmp(ins_type,"47") == 0) ||
                (strcmp(ins_type,"48") == 0) || (strcmp(ins_type,"50") == 0) ||
                (strcmp(ins_type,"147") == 0))
            {
                pdiscount = 0;
            }
            main_discount = pdiscount;  /* default  �h�~�u�f�v�]��O��W�|��� �^*/

            /* 980310, �O�v�ۥѤƫ�,���N�I�w�L���� */
            pdiscount = 0 ;
            cal_pdiscount = 0;
            pdis_rate = 0;
            strcpy(fdiscount,"N");

            if (strcmp(ins_type,"33") == 0) ins33_flag=1;
            if (strcmp(ins_type,"35") == 0) ins35_flag=1;
            if (strcmp(ins_type,"48") == 0) ins48_flag=1;
            if (strcmp(ins_type,"56") == 0) ins56_flag=1;  /* 950704 */
            if (strcmp(ins_type,"50") == 0) ins50_flag=1;  /* 950704 */
            if (strcmp(ins_type,"136") == 0) ins136_flag=1;
            if (strcmp(ins_type,"166") == 0) ins166_flag=1;
            if (strcmp(ins_type,"266") == 0) ins266_flag=1; /*�s�W266�I�� (1110308005_SC3_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h)*/

            /* �D03,04,22���ؤ���ĳ16�A�Y�ϥh�~���ӫO��P */
            if (strcmp(ins_type,"16") == 0){
                if ((strncmp(car_typei,"03",2) != 0) && (strncmp(car_typei,"04",2) != 0) &&
                    (strncmp(car_typei,"22",2) != 0))
                {
                    continue;
                }
            }

            #ifdef PRINTF_FLAG
            printf("ibig_comp[%s]\n",ibig_comp);
            #endif

            if ((strcmp(ins_type,"31") == 0) || (strcmp(ins_type,"131") == 0) || (strcmp(ins_type,"231") == 0) || (strcmp(ins_type,"331") == 0) ||
                (strcmp(ins_type,"133") == 0) || (strcmp(ins_type,"149") == 0)|| (strcmp(ins_type,"249") == 0)){
                 /* ��~�ΨT���ĤT�H�d���I�T���f�B�~�M�Ϊ��[���� */
                if(strstr(tmp_provision,"T;") != NULL){
                    if (f_provision_T == 0)
                    {
    	    	        sprintf(remark1,"%s%s",
    	                       "����O��O�O���]�t��~�ΨT���ĤT�H�d���I�T���f�B�~�M�Ϊ��[���ڡA",
    	                       "�Э��s�g�ӫO���ӽЮ֭��l�i���[�C");
    	            }
    	            else
    	            {
    	                sprintf(remark1,"%s",
  	                       "���n�O�ѾA��(��~�ΨT���ĤT�H�d���I�T���f�B�~�M�Ϊ��[����) ");
    	            }
                }
            }

            /* 961128, �x���Υ�(A21*)���O�զX��^ "�����O�B" */
            /* 950913 ,�έ�A09*     ==> 05,09����אּ"05�K�ۭt�B"  => �ȫ�ĳ��O�զX�n��(���֤��~��)*/
            /* 950822 ,�x���Υ�A21* ==> 05,09����אּ"05�K�ۭt�B"  => �ȫ�ĳ��O�զX�n��(���֤��~��)  */
            /* 950331 ���p(A11*) ���餣�� */

            /* �έ�(A09)�����I���ରA���ӫ~,������֬����~�� modify by sylvia 103.10.02 */
            /* �s�WA01,A04,A10,A11,A21,A23,A25�����ӳq��, �ç��IS_CHG_A_prod()�P�_
            modify by sylvia 103.10.22 (1031016004_C1) */
            /*if (((strncmp(iofficer,"A09",3) == 0)||(strncmp(iofficer,"B",1) == 0)) &&
                 (ins1589_chg_flag >=5)) */
            /* �t�X�ӫ~����,���ഫ���ؤ��ഫ modify by sylvia 105.12.28 (1051214006_C4) */
            if (STOP_CHG1589_FLAG == 'N')
            {
                if ((IS_CHG_A_prod(iofficer)) > 0 && (ins1589_chg_flag >=5))
                {
                    if (strcmp(ins_type,"118") == 0)
                        deduct = 0;
                    else
                        deduct = ori_deduct;
                }
                else if (((strncmp(iofficer,"A09",3) == 0)||(strncmp(iofficer,"A21",3) == 0))&&
                         ((atoi(plyyear) - atoi(issue_12)) <= 4))
                {
                    /*961128, �x���Υ�(A21*)���O�զX��^ "�����O�B" */
                    /* A21* : �A���Τ��� => �ȫ�ĳ��O�զX�n�אּ�A�K */
                    /* A09* : �A���Τ��� => �ȫ�ĳ��O�զX�n�אּ�A�K */
                    if((strcmp(ins_type,"05") == 0)||(strcmp(ins_type,"09") == 0))
                    {
                        if (fdmg_sug == 'Y')
                        {
                            if (strcmp(ins_type,"09") == 0){

                                strcpy(ins_type,"05");
                    	        ins1589_chg_flag = 1;   /* ���ഫ�����I�I�� */

                            }

                            if ((ins1589_chg_flag !=2)&&(ins1589_chg_flag !=3))
                            {
                                deduct = 0;  /* 102.08.26: 05=>105��,��ĳ��O���������O�զX*/
                            }
                        }
                    }
                }
            }

            /* 101.04.30 */
            if (strcmp(ins_type,"11") == 0 || strcmp(ins_type,"211") == 0 || strcmp(ins_type,"96") == 0 ||
                strcmp(ins_type,"112") == 0 || strcmp(ins_type,"129") == 0)
            {
                if (IsPlyB=='Y'){
                    deduct = 10;
            	    ori_deduct = 10;
                }
                else
                {
                	if (deduct < 10)
	                {
	                	deduct = ori_deduct;  /* ��ĳ��O�@�ס@���O�@*/
	                }

	                /* �_�@�Ϧ��ӫO11�I�ؽվ�ۭt�B add by 061476 108.06.12 (10805007001_SC1) */
	                if ((deduct > 0)&&(fquota_62 == 'Y')&&(strcmp(ins_type,"11") == 0))
	                {
	                	if (ISCAR_SET1(car_typei)) deduct = 0;
	                }
	        			}
            }

            /*980310,�s�O�v, 14 �I�Q���N�� 19 */
            if (strcmp(ins_type,"02") == 0)
            {
                if (dmg_flag2 == 'N')
                {
                    continue;
                }
            }
            /*980310,�s�O�v, 30�I�ۭt�B�ܧ� */
            if (strcmp(ins_type,"30") == 0){
                switch (deduct)
                {
                    case 151:     ori_deduct = 155   ; deduct = 155   ;break;
                    case 251:     ori_deduct = 255   ; deduct = 255   ;break;
                    case 12451:   ori_deduct = 12455 ; deduct = 12455 ;break;
                    case 22451:   ori_deduct = 22455 ; deduct = 22455 ;break;
                }
            }

            /* 101.11, 29�I�دŶZ(�ۭt�B) 80�ɦ�=>�ܧ�70�ɦ� ; 50�ɦ�(31�I����˦b70~79�U�� => �ܧ�70�ɦ�) */
            if (strcmp(ins_type,"29") == 0){
                if (atoi(drate_ym)<47){
	            				if(deduct==80){
	                				ori_deduct = 70 ;
	            						deduct     = 70 ;
	            				}else if(deduct==50){
                        	t_count = 0;
													$SELECT count(*) INTO $t_count FROM ply_ins_type_last
													  WHERE ipolicy   = $last_ply
													    AND iins_type in ('31','231')
													    AND minjured_cover Between 700000 And 790000;
													if (t_count > 0){
	            	    					ori_deduct = 70 ;
	            	    					deduct     = 70 ;
                        	}
                    }
                }
            }
            /* 104.05.04 �s�W�����G�~����X�O�I110  add by sylvia (1030407005_C4) */
            /* 102.08 �q�ʦۦ樮��X�I���@�G�q�ʦۦ樮���B���郞�I���l��(101) */
            /* 102.08 �q�ʦۦ樮��X�I���@�G�q�ʦۦ樮�㨮���ѷl���O�I(102) */
            /* 100.01 86�I�� */
            if ((strcmp(ins_type,"86") == 0)||(strcmp(ins_type,"101") == 0)||
                (strcmp(ins_type,"102") == 0) )
            {

            	/*1101112002_SC1_86�I�ק�֫O����M�O�B�������-->�̻ݨD�������q�ˮ� (modify by 071004) */
                /*if (strcmp(ins_type,"86") == 0)
                {
                    /* �Y���֤��~(�t)�H�W�̡A���L���I�ءA�üg�J�����T��
	            /* �Y�ӳ��ݾ����㨮���ѱM�ת̡A�h�����ˮֱ��󭭨�
	               �A86�I�إ�����]�t��barcode �����O�զX��(A���)
                    if (fMotProj=='N'){
                        if ((atoi(plyyear) - atoi(issue_12)) > 4){
                            if (strlen(trim(remark1))>10){
			        sprintf(remark6,"���ӳ�h�~��O86�I��(���B���郞�I���l���I)�A�]���~���֤v�O���~�A�G�����ѳ����A�Y���ðݽЬ��ӫO��");
					    }else{
									sprintf(remark1,"���ӳ�h�~��O86�I��(���B���郞�I���l���I)�A�]���~���֤v�O���~�A�G�����ѳ����A�Y���ðݽЬ��ӫO��");
					    }
					    continue;
		            	/* $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,'86','�����G�������֤w�F���~�H�W�A�w�J�p','2');
                        }
                    }
                }*/

			    	 	/* �H���W�L�h�~�O�B��0.75����O�O�B*/
			    	 	tmp_lDamage75 = 0;
			    	 	lDamage75 = 0;

			    	 	/* 102.09.13�A��O�O�B��^���k�G  �h�~�O�B * (1.0 �� �~���²v)*/
			    	 	/* 102.07.01�A��O�O�B��� SetCarAge()�̨������º�X���O�B (�n�h��@�~)*/
    	 				tmp_lDamage75   = (long)(ori_damage_cover*(1.0-pdep_rate_year))  ;
    	 				/*tmp_lDamage75   = cover_01_tmp*(1.0-pdep_rate_year) ;*/  /* cover_01 �w�i���d�� ;cover_01_tmp��cover_01���i�줧�e���� */
	 						printf("Trace -- tmp_lDamage75 = [%ld] \n",  tmp_lDamage75);

						 	/* ��O�B�O�O�ɤ��p�󵥩� ���̨������º�X���O�B�� �����̰��O�B */
						 	/* �t�X86�I�ثO�O�p��覡�վ�  modify by sylvia 104.06.11 (1040525002_C3) */
						 	idrate_ym = atoi(drate_ym); /* �e�O��O�v�N�� */
						 	mcover1_86 = 0;
						 	mcover2_86_min = 0;
						 	if (strcmp(ins_type,"86") == 0)
						 	{
						 	    if (idrate_ym < 74)
						 	    {
						 	        if (atoi(frate) >= 74)
						 	        {
						 	            mcover1_86 = ori_deduct; /* �O�v�N��< 74, �O�B1���H�e���ۭt�B(�Y32���ج������ŶZ) */
						 	            ori_deduct = deduct = 0;          /* �O�v�N��< 74, �S���ۭt�B,�G�ۭt�B�k0 */
						 	        }
						 	    }
						 	    else
						 	    {
						 	        /* �O�v�N�� >= 74 */
						 	        if (strcmp(car_typei,"32") == 0)
						 	        {
					 	            /* 32����86�I�ا��H�u�U�v���p��O�B add by 061476 107.04.18 (1070129008_SC1) */
					 	            tmp_lDamage75 = ((long)(tmp_lDamage75/10000)) * 10000;

					 	            /* �̨��������O�B1���ŶZ */
					 	            $select min(mcoverage1) into $mcover1_86
					 	               from cover_vs_premium
					 	              Where iins_type ='86' and icar_type = '32'
					 	                And mcoverage2 = $tmp_lDamage75
					 	                And mcoverage1 >= $car_price
					 	                And drate= (SELECT drate
					 	                              FROM ca_rate_date
					 	                             WHERE icode  = $frate
					 	                               AND itable = 'cover_vs_premium');
					 	            if (SQLCODE==SQLNOTFOUND)  mcover1_86 = 0;
  	 	        				}
	 	        					else
	 	            				mcover1_86 = 0; /* �D32����,�O�B1����0 */
	 	    					}
	 						}
	 						else
	 	    					mcover1_86 = 0; /* ��L�I�ثO�B1=0, �ۭt�B�Y����ۭt�B */

							$EXECUTE pre_get_max_cover2
							    INTO $lDamage75
							   USING $ins_type,$car_typei,$mcover1_86, $tmp_lDamage75,$ori_deduct,$frate;

							if ((SQLCODE==SQLNOTFOUND)||(lDamage75==0))
							{
                    if (strcmp(ins_type,"86") == 0){
                        if (idrate_ym < 74)
				    	 	        {
				    	 	            if (atoi(frate) >= 74)
				    	 	            {
				    	 	                mcover1_86 = ori_deduct; /* �O�v�N��< 74, �O�B1���H�e���ۭt�B(�Y32���ج������ŶZ) */
				    	 	                ori_deduct = deduct = 0;          /* �O�v�N��< 74, �S���ۭt�B,�G�ۭt�B�k0 */
				    	 	            }
				    	 	        }
				    	 	        else
				    	 	        {
		    	 	            	/* �O�v�N�� >= 74 */
			    	 	            if (strcmp(car_typei,"32") == 0)
			    	 	            {
			    	 	                /* �̨��������O�B1���ŶZ */
			    	 	                $select min(mcoverage1) into $mcover1_86
			    	 	                   from cover_vs_premium
			                                  Where iins_type ='86' and icar_type = '32'
			                                    And mcoverage2 = $tmp_lDamage75
			                                    And mcoverage1 >= $car_price
			                                    And drate=(SELECT drate
			                                                 FROM ca_rate_date
			                                                WHERE icode  = $frate
			                                                  AND itable = 'cover_vs_premium');
		                                if (SQLCODE==SQLNOTFOUND)  mcover1_86 = 0;
		      	 	            }
		    	 	            	else
		    	 	                mcover1_86 = 0; /* �D32����,�O�B1����0 */
		    	 	        		}


		                    /* ��O�B�O�O�ɤ����ɶO�v���̤p�O�B */
			                	lDamage75_min = 0;
				        				$EXECUTE pre_get_min_cover2
					    							INTO $lDamage75_min
					   							 USING $ins_type,$car_typei,$mcover1_86,$ori_deduct,$frate;

												printf("Trace -- lDamage75_min = [%ld] \n",  lDamage75_min);
		                    if ((SQLCODE==SQLNOTFOUND)||(lDamage75_min==0))
		                    {

		                            /*1101112002_SC1_86�I�ק�֫O����M�O�B������� modify by 071004*/
		                            /*32���حY�䤣���ơA�P�_���u�e��86�O�B*�~����(�L����˥h�ܸU��)�v�p��car109�]�w�ɳ̧C�O�B�ɡA
		                              �Y�u���~�ר���*�~���¡v�j�󵥩�]�w�ɳ̧C�O�B�A�h�H�]�w�ɳ̧C�O�B�A�Ӱ����U�@�~�ת��O�B�C*/
		                            if(strcmp(car_typei,"32") == 0 && strcmp(ins_type,"86") == 0 )
		                            {
		                                /*�����ocar109���ɶO�v86�I��32���ت��̧C�O�B*/
		                                $SELECT nvl(min(mcoverage2),0) into $mcover2_86_min
		                                  FROM cover_vs_premium
		                                 WHERE iins_type  = '86'
		                                   AND icar_type  = '32'
		                                   AND mcoverage1  >= $car_price
		                                   AND mdeduct    = 0
		                                   AND drate=(SELECT drate
		                                                FROM ca_rate_date
		                                               WHERE icode  = $frate
		                                                 AND itable = 'cover_vs_premium');

		                                /*���u�e��86�O�B*�~����(�L����˥h�ܸU��)�v�p��car109�]�w�ɳ̧C�O�B��*/
		                                if (tmp_lDamage75 < mcover2_86_min)
		                                {
		                                    /*�Y�u���~�ר���*�~���¡v�j�󵥩�]�w�ɳ̧C�O�B*/
		                                    if(cover_01*(1.0-pdep_rate_year) >= mcover2_86_min)
		                                    {
		                                    	/*�H�]�w�ɳ̧C�O�B�A�Ӱ����U�@�~�ת��O�B*/
		                                        ori_damage_cover = mcover2_86_min;
		    	 	                        damage_cover     = mcover2_86_min;
		                                    }
		                                    else
		                                    {
									      	                $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�I�ا��«��O�B�O�O�ɧ䤣��O�v_3','1','E10',$iofficer);
									                        goto end;
		                                    }
		                                }
		                                else
					                          {
										      	            $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�I�ا��«��O�B�O�O�ɧ䤣��O�v_2','1','E10',$iofficer);
										                    goto end;
		                                }
		                            }
		                            else
		                            {
									      	        $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�I�ا��«��O�B�O�O�ɧ䤣��O�v_1','1','E10',$iofficer);
									                goto end;
		                            }
						        		}
								        else
								        {
							            /* ���M�̤p�O�B>�̨������º�X���O�B �A���H�̤p�O�B���� */
							            ori_damage_cover = lDamage75_min;
							            damage_cover     = lDamage75_min;
												}
                    }
                    else
                    {
		        					/*�q�ʦۦ樮���B���郞�I���l���I(101,102)�����\  �̤p�O�B > �̨������º�X���O�B */
											strcpy(sTpMsg," ");
											sprintf(sTpMsg,"�I�ا��«�[%ld]��O�B�O�O�ɧ䤣��O�v",tmp_lDamage75);
										      	/* $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'���«�[%ld]��O�B�O�O�ɧ䤣��O�v_1','1'); */
							      	$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,$sTpMsg,'1','E10',$iofficer);
							        goto end;
                    }
                }else{
				    	 	    ori_damage_cover = lDamage75;
				    	 	    damage_cover     = lDamage75;
                }
                printf("Trace -- lDamage75 = [%ld] \n",  lDamage75);
								printf("Trace -- ori_damage_cover = [%ld] \n",  ori_damage_cover);
            }

            /* 102.09.13�A��O�O�B��^���k�G  �h�~�O�B * (1.0 �� �~���²v)*/
            /* 990604,23�I�� */
            /* 990604,23�I�ثO�B�L�C�̡A�O�O�i�ର0 => �O�B�ը� 4000 => �O�O1�� ,�@�ɽT�{ */
            if ((strcmp(ins_type,"20") == 0)||(strcmp(ins_type,"23") == 0)){
                tmp_lDamage75 = 0;
                tmp_lDamage75    = (long)(ori_damage_cover*(1.0-pdep_rate_year))  ;
                tmp_lDamage75    = ((long)(tmp_lDamage75/1000)) * 1000; /*����d��*/

			        	damage_cover     = tmp_lDamage75 ;
			        	ori_damage_cover = tmp_lDamage75 ;

                if (damage_cover < 4000){
                    if(strcmp(ins_type,"23") == 0){
                        damage_cover     = 4000;
                	ori_damage_cover = 4000;
                    }
                }
            }

            if ((strcmp(ins_type,"110") == 0)||(strcmp(ins_type,"111") == 0))
            {

                /* 110�P110�O�B�ۦP, �H110�I�ب��O�B */
                tmp_lDamage75 = 0; lDamage75 = 0;
                tmp_lDamage75   = cover_01_tmp*(1.0-pdep_rate_year) ;  /* ���������m���ȭp��(�n�h��@�~) */

                /* ��O���O�I���B=���m����x���~�ק��²vx�A�h���¤@�~ �B ���i�j��h�~���O�I���B
                   ��car109���]�w�̱��񤧫O�B  */
                $SELECT nvl(max(unique mcoverage2),0) into $lDamage75
                   FROM cover_vs_premium
                  WHERE iins_type  = '110'
                    AND icar_type  = $car_typei
                    AND mdeduct    = '1'
                    AND mcoverage2 <= $ori_damage_cover
                    AND mcoverage2 <= $tmp_lDamage75
                    AND drate=(SELECT drate FROM ca_rate_date
                                WHERE icode  = $frate AND itable = 'cover_vs_premium');

                if (SQLCODE==SQLNOTFOUND){
		    						$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�I�ا��«��O�B�O�O�ɧ䤣��O�v','1','E55',$iofficer);
								}
								else
								{
								    ori_damage_cover = lDamage75;
						    	 	    damage_cover     = lDamage75;
						    }
    	 							printf("damage_cover=[%d]\n",damage_cover);
            }

            if((strcmp(ins_type,"110") == 0)||(strcmp(ins_type,"111") == 0)||(strcmp(ins_type,"112") == 0))
            {
                CarAgeMonth = 0;
                CarAgeMonth = (iplyyear-atoi(pro_year))*12 + (iplymonth-qpro_month);
                if (CarAgeMonth <= 24)
                {
                    f_110_112_sug='Y'; f_110_112_ori='Y';f_113_115_sug = 'N';
                }
                else
                {
                    f_110_112_sug='N'; f_110_112_ori='N';f_113_115_sug = 'Y';
                }
            }

            /* 102.07.01 ,add 98�I��  */
            /* 108.04.22 98�I�ذ����ഫ09+K (1080408008_SC3) */
            /* 109.11.06 09+K�ഫ198 (1091103004_SC1) */
            if (strcmp(ins_type,"198") == 0)
            {
                damage_cover98_pre = damage_cover  ;  /* �O���h�~�O�B */

                /* 3�~���X�I2��(�t)�H�W�ĤT�H�d���I�X�I�����A�h��O�椣�e�{���I����O���e */
                if (qlia_acc_sum_renew>=2){
                    if (strlen(trim(remark1))>10){
                        sprintf(remark6,"���O����O198�I��,���~��O�ݭ��s�f��,��������O�O�O,�p�����D�Ь��ӫO��");
                    }else{
                	sprintf(remark1,"���O����O198�I��,���~��O�ݭ��s�f��,��������O�O�O,�p�����D�Ь��ӫO��");
                    }
                    continue;
                }


                /*                                                [���¦~��]                        */
                /* ��O�u��ڲ{�����ȡv�� ���m���� �� (1.0 �� �~���²v)   ��    (1.0 �� ����²v)   */

                /* �]198�I�دS���W�h�G�ۥΧ���15% ��~20%(�i�P�����¤��@�P�A�]���b�����ڲ{������)*/
                /* (1091103004_SC1) */
                code=SetCover_198(frate);
                if (code != SUCCESS) continue;

                printf("trace �����«O�B=[%ld]\n ",cover_01);
                printf("trace ��ڲ{������=[%ld]\n ",cover_198);
                printf("trace �h�~��O���B=[%ld]\n ",damage_cover98_pre);

                /* ��O�O�I���B�G�H��O�u��ڲ{�����ȡv�Ҹ����ŶZ�A�ä���h�~�O�B�A�H�M�w��O�I���B */
                tmp_cover = 0 ;
                $SELECT max(engname::integer) INTO $tmp_cover  FROM car_code
                  WHERE kind = '98'
                    AND detail2::integer  <= $cover_198  AND  chiname::integer > $cover_198
                    AND engname::integer  <= $damage_cover98_pre ;

                damage_cover     = tmp_cover ;
                ori_damage_cover = tmp_cover ;
                /* �խY���o�� �u��O�O�I���B�v�աu�h�~�O�B�v �A �h��u�O��q�T��v��ܴ����T���p�U�G */
                if (damage_cover < damage_cover98_pre){
                    if ((car_age >= 48) && (damage_cover98_pre <= 100000))
                    {
                        /* ���ֲ�5�~(���|�~)�H�W�B��O98�����I�ݫO�B10�U�H�U����,�}���O�B�J�p��O�æL�s��O�n�O��. add by sylvia 105.03.24(1050317004_C1) */
                        /* �קאּ���� >= 48�Ӥ�q�L(1080408008_SC3) */
                        /* �ק�O�B�� <= 10�U�q�L (1091103004_SC1) */
                    }
                    else
                    {
                        if (strlen(trim(remark1))>10){
                            sprintf(remark6,"���O����O198�I�ثO�B%ld,�]��O�������C�P�ݭ��C��O���B��%ld,�p�����D�Ь��ӫO��",damage_cover98_pre,damage_cover);
                            $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,$remark6,'1','E53',$iofficer); /* modify by sylvia 105.02.02 (1041230003_C1) */
                        }else{
                            sprintf(remark1,"���O����O198�I�ثO�B%ld,�]��O�������C�P�ݭ��C��O���B��%ld,�p�����D�Ь��ӫO��",damage_cover98_pre,damage_cover);
                            $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,$remark1,'1','E53',$iofficer); /* modify by sylvia 105.02.02 (1041230003_C1) */
                        }
                    }
                }

                /* 98�I�ت��[E���ڷs�W���ܰT�� add by 061476 107.02.07 (1060914009_C3) */
                /* �� 98�I�ت��[E���ڤ��H �h�~�O�B*(1.0-�~���²v) �p��A�ӬO��98�I�ؤ����p�� ��*/
                /*�վ���O�L�s�W�h198�I+E (1110617008_SC1)*/
                if (strstr(tmp_provision,"E;") != NULL)
                {
                    if (damage_cover98_pre > 100000)
                    {
                        $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'198�I�إh�~��E���کӫO�A�Э��s�T�{���~�ӫO�O�B','1','E53',$iofficer);
                    }
                }
            }

            /* car137 �]�w���l�I�ګO�A�G�u�n�D�I�����l�I�̬ҩګO */
            if ( (ISINS01(simain_ins)) || (ISINS11(simain_ins)) )
            {
                if (rdmg == 'Y') continue;
            }

            /* car137 �]�w���d�I�ګO�A�G�u�n�D�I�����d�I�̬ҩګO */
            /* �s�W149�I���ˮ�  add by sylvia 106.02.16 (1050601006_C4) */
            if ((strcmp(simain_ins,"31") == 0) || (strcmp(simain_ins,"32") == 0) ||
                (strcmp(simain_ins,"231") == 0) || (strcmp(simain_ins,"232") == 0) ||
                (strcmp(simain_ins,"113") == 0) || (strcmp(simain_ins,"114") == 0) ||
                (strcmp(simain_ins,"133") == 0) || (strcmp(simain_ins,"134") == 0) ||
                (strcmp(simain_ins,"149") == 0) || (strcmp(simain_ins,"249") == 0) ||
                (strcmp(simain_ins,"531") == 0) || (strcmp(simain_ins,"532") == 0))
            {
                if (rlia == 'Y') continue;
            }

            #ifdef PRINTF_FLAG
            printf("3.21 step_8-->ply[%s],ins_type[%s],insprem[%d]\n",last_ply,ins_type,ins_premium);
            #endif
            strcpy(drate_ym,trim(drate_ym));

            #ifdef PRINTF_FLAG
            printf("3.22 drate_ym[%s]\n",drate_ym);
            printf("3.23 fhuman[%s],deduct[%d],ins_type[%s]\n",fhuman,deduct,ins_type);
            printf("ipolicy[%s] before injured_cover[%d]\n",last_ply,injured_cover);
            printf("choice == [%s]\n",choice);
            printf("iquota == [%s]\n",iquota);
            #endif

            /* �O�_���]�� add by sylvia 105.10.21 */
            cnt_sprot = 0;
            $EXECUTE preSports_car INTO $cnt_sprot USING $brandi, $tmp_frate2 ;

            /*************************  * ����ĳ�I�ؤΫO�B�A�Y ��ĳ��O�զX <���> ���O�զX *  ****************************/
            /*             (�̳W�w���վ�O�B���I�ت�,���|�i��վ�A���O�Ϋ�ĳ��O�զX�O�B���ӳ��|(�n)�@�_�վ�)            */
            /* 102.08.26 ���� "iquota=6102 ����ĳ���P�_", 05=>105,��ĳ��O���������O�զX*/
            /* 970219, �B�z�������~���Ҧ�barcode�q�l�ɤ����s */
            /* 102.12.25 �M�ץ󤣫�ĳ�O�B�B�I��*/
            /* �s�W�ӫO�ۥΨ���X�O�I(cnt_ins77 >0||cnt_ins79 >0)  add by sylvia 103.04.09 */
            /* �s�W����A������ĳ(�]�P���L��ĳ�I�ةʽ譫��,�G�Ȥ�����L��ĳ�I��)  add by sylvia 103.04.09 */
            /* �s�W����(4A,8A,9A,9B,2A,2B,2C, �Y���إN�X��2�X�����Ʀr��)����ĳ�I�� modify by sylvia 104.02.16(1040202006_C3) */
            /* ���ľ��c�q�~�H���T����X�O�I(125-136)����ĳ�s�I�� add by sylvia 104.06.02 (1040407003_C6) */
            /* �N�ۥΨ���X�I(cnt_ins77 >0) || (cnt_ins79 >0) A�������I(cnt_ins118 >0) || (cnt_ins120 >0) || (cnt_ins122 >0) ||
                 ���ľ��c�q�~�H���T����X�I|| (cnt_125_136 > 0) �X�֨� cnt_non_sug    modify by sylvia 104.11.26 */
            /* JB�q�����A��ĳ�����I�� modify by sylvia 105.06.13 (1050602005_C1) */
            /* �W�Q���ζ]������ĳ�I�� add by sylvia 105.10.21 */
            /* �s�W�]�ӫ~������ഫ���O�� insA_chg_flag > 0  add by sylvia 105.12.28 (1051214006_C4) */
            /* �O�o�q��21/31����ĳ�����I�� add by 061476 107.07.27 (1070314007_SC3) */
            /* ������O����ĳ�����I�� add by 061476 (1080730006_SC1)109.01.17 */
            /* �r�V�Z��X�I(f25C01) ����ĳ�����I�� add by sylvia 114.04.24 (1140409004_C01) */
            if ((IsPlyB=='Y')||
                (ins1589_chg_flag > 0)||    /* �����I�ഫ��A���ӫ~ */
                ((fBarcode=='Y')&&(!(ISMOT(car_typei)))&&(strncmp(s_fcar_insure,"02",2)==0) )||  /* ��car147�]�w���q��, ���T���B �]�w�T���I����ĳ */
                ((cnt_non_sug > 0) && insA_chg_flag == 0) ||
                (fhi_price == 'Y') ||
                (strncmp(iroute,"JB",2) == 0)||
                (fquota63 == 'Y')||
                (ISSPC_BRAND(brandi))||
                (cnt_sprot > 0)||
                (fbz_2131 == 'Y')||
                (fquota_62 == 'Y')||
                (fkaxx == 'Y')||
                (fBEV == 'Y')||
                (fES == 'Y')||(f25C01 == 'Y'))
            {/*
                strcpy(chk_chang_149,"N");  * �]�ӫ~����(insA_chg_flag>0)�]���ର��ĳ149,�G��W�b���A�P�_�@�� add by sylvia 106.03.13 *
                strcpy(dealer_149,"00000");*/
            }

            /* �s��(245)�O��(265)�u��ĳ149,34,55,56, ��L����ĳ, �G���C�J����ĳ�I�سo�� add by sylvia 106.06.23 (1060614005_C1) */
            if ((strcmp(car_typei,"51") == 0)||
                (IsPlyB=='Y')||
                (ins1589_chg_flag > 0)||    /* �����I�ഫ��A���ӫ~ */
                ((fBarcode=='Y')&&(!(ISMOT(car_typei)))&&(strncmp(s_fcar_insure,"02",2)==0) )||  /* ��car147�]�w���q��, ���T���B �]�w�T���I����ĳ */
                ((fBarcode=='Y')&&(  ISMOT(car_typei) )&&(strncmp(s_fmot_insure,"02",2)==0) )||  /* ��car147�]�w���q��, �������B �]�w�����I����ĳ */
                (cnt_ins131 >0) ||
                (cnt_ins132 >0) ||
                (car_typei[1] >= 65) ||
                (cnt_110_117 > 0) ||
                (cnt_non_sug > 0) ||
                (fhi_price == 'Y') ||
                (intopt == 55 )||
                (strncmp(iroute,"JB",2) == 0)||
                (fquota63 == 'Y')||
                (ISSPC_BRAND(brandi))||
                (cnt_sprot > 0)||
                (insA_chg_flag > 0) ||
                (f245_265 == 'Y')||
                (ins7780_chg_flag > 0)||
                (fbz_2131 == 'Y')||
                (fquota_62 == 'Y')||
                (fkaxx == 'Y')||
                (fBEV == 'Y')||
                (fES == 'Y')||(f25C01 == 'Y'))
            {

                sug_flag = 'N';

                /* ��O104/10-12 ��ĳ��O�զX=���O�զX, ��L����������ĳ�I��
                   �G�P�_(fdmg_sug = 'Y')�~�~�򩹤U��  add by sylvia 104.07.28  */
                if (fdmg_sug == 'Y')
                {
                    /* 101.10 �D���Ӿ���barcode   */
                    /* ������X�I(110-117)����ĳ�s�I�� */
                    if (ISMOT(car_typei))
                    {
                        if (strncmp(iroute,"JB",2) == 0)
                        {
                            sug_flag = 'N';
                        }
                        else if ((strncmp(car_typei,"32",2)!=0) && (cnt_110_117 == 0))
                        {
                            sug_flag = 'Y';
                        }
                    }
                    /* 102.11.26 2���אּ10��,�s�W32�I��50�U */
		    		        /* 102.10.22 �A�u��q�v(A16*) �Y�Ϧ� 05=>105 �]�n����31�I����ĳ��O�զX�A
		    		                       ����L�I�ؤ��� */
		    		        /* �s�W����(4A,8A,9A,9B,2A,2B,2C, �Y���إN�X��2�X�����Ʀr��)����ĳ�I�� modify by sylvia 104.02.16(1040202006_C3) */
		    		        /* ��q(A16*)TPL 31/32�I�ا��ĳ�� 500�U/5000�U/70�U
		    		           31�I��: ���O�զX�O�B1 < 500�U   �h�@�߫�ĳ 500�U/5000�U
		    		                   �O�B1 = 500�U   �h�O�B2�ܤֶ���5000�U(10��)
		    		                   �O�B1 > 500�U   �h�����O�B2���O�B
		    		           32�I��:�ܤ�70�U
		    		           ���اt 03/21/22/04/19   modify by sylvia 104.05.18 (1040424003_C1)*/
    		           		/* �s�W301�I�� add by sylvia 106.04.17(1060329005_C4) */
				    		    if ((ins1589_chg_flag ==2) || (insA_chg_flag > 0))
				    		    {
				                        if((strncmp(iofficer,"A16",3) == 0) && (car_typei[1] < 65))
				                        {
				    		            if ((f_29_exist=='N') && (f_30_exist=='N') && (f_301_exist=='N'))
				    		            {
				    		            	if((strncmp(car_typei,"03",2) == 0) || (strncmp(car_typei,"21",2) == 0) ||
				    		            	   (strncmp(car_typei,"22",2) == 0) || (strncmp(car_typei,"04",2) == 0) ||
				    		            	   (strncmp(car_typei,"19",2) == 0))
				    		            	{
				    		            		if( f_109_exist=='N')
				                                        {
				                                        	if (((strcmp(ins_type,"31") == 0)||(strcmp(ins_type,"231") == 0))&&(ori_deduct==0))
				                                        	{
				                                        		if ((ori_injured_cover < 5000000)||
				                                        		   ((ori_injured_cover == 5000000)&&(ori_damage_cover < 50000000 )))
				                                        		{
				                                        			injured_cover = 5000000;
				                                        			damage_cover  = 10 * injured_cover;
				                                        		}
				                                        	}
				                                        	if (((strcmp(ins_type,"32") == 0)||(strcmp(ins_type,"232") == 0))&&(ori_deduct==0) )
				                                        	{
				                                        		if (ori_damage_cover < 700000)
				                                        		{
				                                        			damage_cover = 700000;
				                                        		}
				                                        	}
				                                        }
				                                }
				                            }
				                        }
				            }/* end of if ((ins1589_chg_flag ==2) || (insA_chg_flag > 0))*/

                    /* �έ�(A09*)����ĳ�ഫ�I��, �]�n��31,32��ĳ�O�B add by sylvia 104.05.19(1040424003_C1) */
                    if (strncmp(iofficer,"A09",3) == 0)
                    {
                        /* �s�W301�I�� add by sylvia 106.04.17(1060329005_C4) */
                        if ((f_29_exist=='N') && (f_30_exist=='N') && (f_301_exist=='N') && (f_302_exist=='N') )
				    		        {
				    		        	if( f_109_exist=='N')
                                {
                                	if (strcmp(ins_type,"31") == 0 || strcmp(ins_type,"231") == 0)
                                	{
                                		if ((ori_injured_cover < 4000000)||
                                		   ((ori_injured_cover == 4000000)&&(ori_damage_cover < 40000000 )))
                                		{
                                			injured_cover = 4000000;
                                			damage_cover  = 10 * injured_cover;
                                		}
                                	}
                                	if (strcmp(ins_type,"32") == 0 || strcmp(ins_type,"232") == 0)
                                	{
                                		if (ori_damage_cover < 500000)
                                		{
                                			damage_cover = 500000;
                                		}
                                	}
                                }
                        }
                    }
                } /* if (fdmg_sug == 'Y') end */
            } /* ����ĳ�s�I��(end) */
            else
            {
            	/*************************  * ����ĳ�I�ؤΫO�B *  ****************************/
                if (fdmg_sug == 'Y')
                    sug_flag = 'Y';

                /* ��ĳ��O�զX���e�ݩM�h�~���O�զX�ۦP */
                if ((iofficer[0]=='P')||(strncmp(iroute,"JB",2) == 0)||(fbz_2131 == 'Y')||
                    (fkaxx == 'Y')||(fBEV == 'Y')||(fES == 'Y')||(f25C01 == 'Y')){
                    sug_flag = 'N';
                }
            }

            /* 100.04.01,55�I�بC�@�ӤH��ˡB�C�@�ӤH����=> �X�֬��C�@�ӤH�ˮ`(death_cover) */
            if (strcmp(ins_type,"55") == 0)
            {
                f_55_exist = 'Y';

                /* 06 �ۤj�f(��) 20(���j�f) 18(�ۥΤ@��|��) 31(�ۥγf�d�|��) 12(�ۤj��)
		   					qpt��qpassenger���O����,�ҥH�n��"�e���O�B"�^��"���ȼ�"	*/
                if ((strncmp(car_typei,"06",2) == 0) || (strncmp(car_typei,"20",2) == 0) ||
                    (strncmp(car_typei,"18",2) == 0) || (strncmp(car_typei,"31",2) == 0) ||
                    (strncmp(car_typei,"12",2) == 0))
                {
                    qpassenger = ori_damage_cover/ori_death_cover ;
                }

                if (sug_flag=='Y')
                {
                    if(ISCAR_SET1(car_typei)) {
                        #ifdef PRINTF_FLAG
								        printf("1ori_injured_cover[%d]\n", ori_injured_cover);
								        printf("1ori_death_cover[%d]\n", ori_death_cover);
								        printf("1ori_damage_cover[%d]\n", ori_damage_cover);
                        #endif

                        /*981208,���p(A11*)���O�զX��^ "�����O�B"  */
                        /*961128, �x���Υ�(A21*)���O�զX "�����O�B" */
                        if ((strncmp(trim(iofficer),"A21",3) == 0)||
                            (strncmp(trim(iofficer),"A11",3) == 0))
                        {
                            if (ori_death_cover>2000000){
												        /* ������O�B */
												    }else if (ori_death_cover>1500000){
                                death_cover   = 6000000 ;
			            	  	    }else if (ori_death_cover>1000000){
			                                death_cover   = 4500000 ;
			            	  	    }else if (ori_death_cover<=1000000){
			                                death_cover   = 3000000 ;
			            	  	    }
            	  				}else if (fTaishin=='Y'){
                            if (ori_death_cover<=1000000){
	                        			death_cover   = 1000000 ;
                            }
                        }else if (strncmp(trim(iofficer),"A04",3) == 0){
                            if (ori_death_cover<=5000000){
	                        death_cover   = 5000000 ;
                            }
                        }else{
											    if (ori_death_cover <= 3000000){
											        death_cover = 3000000 ;
                          }
    	  	   						}

			                	/* 55 �C�@�ƬG�O�B�p�� */
												if((qpt != 0) && (qpt != 1) && fpt[0]=='P'){
									                            damage_cover = death_cover * (qpt-1);
												}else{
												    damage_cover = death_cover * (qpassenger-1);
												}
												#ifdef PRINTF_FLAG
								        printf("2ori_injured_cover[%d]\n", ori_injured_cover);
								        printf("2ori_death_cover[%d]\n", ori_death_cover);
								        printf("2ori_damage_cover[%d]\n", ori_damage_cover);
                        #endif
                    }
                }

                if((f_30_exist == 'Y')&&
								   (((deduct_30==151)||(deduct_30==251)||(deduct_30==12451)||(deduct_30==22451))||
								   ((deduct_30==155)||(deduct_30==255)||(deduct_30==12455)||(deduct_30==22455))||
								   ((deduct_30==355)||(deduct_30==32455))))
								{
						     		if (ori_death_cover < 500000){
								        death_cover   = 500000 ;
						        }
								}

								/* �s�W301�I�� */
								if((f_301_exist == 'Y') &&
								  ((deduct_301==155)||(deduct_301==255)||(deduct_301==355)))
								{
						                    if (ori_death_cover < 500000){
								        death_cover   = 500000 ;
						                    }
								}
	    			}
	    			else if (strcmp(ins_type,"135") == 0)
            {
                f_135_exist = 'Y';

                if ((strncmp(car_typei,"06",2) == 0) || (strncmp(car_typei,"20",2) == 0) ||
                    (strncmp(car_typei,"18",2) == 0) || (strncmp(car_typei,"31",2) == 0) ||
                    (strncmp(car_typei,"12",2) == 0))
                {
                    qpassenger = ori_damage_cover/ori_death_cover ;
                }
            }
            else if (strcmp(ins_type,"56") == 0)
            {
            	ins56_flag = 1;
            	$select first 1 iins_scope,daily_pay into $iins_scope_a,$lDaily_pay_a
                   from ca_pa_ply_last
                  where ipolicy = $last_ply and iins_type = '56';

                if (sug_flag=='Y'){
                    if((strncmp(car_typei,"03",2) == 0) ||(strncmp(car_typei,"04",2) == 0) ||
		       						 (strncmp(car_typei,"19",2) == 0) ||(strncmp(car_typei,"21",2) == 0) ||
		       						 (strncmp(car_typei,"22",2) == 0))
		    						{
                        /*981208,���p(A11*)���O�զX��^ "�����O�B"  */
                        /*961128, �x���Υ�(A21*)���O�զX "�����O�B" */
                        if ((strncmp(trim(iofficer),"A21",3) == 0)||(strncmp(trim(iofficer),"A11",3) == 0))
                        {
                            if (ori_damage_cover>1500000){
                            	damage_cover = 6000000 ;
                            }else if (ori_damage_cover>1000000){
                            	damage_cover = 4500000 ;
                            }else if (ori_damage_cover<=1000000){
                            	damage_cover = 3000000 ;
                            }

                            /* ���B��(iins_scope_a=2)�~�������O�B,����I��(iins_scope_a=3)���������O�B modify by sylvia 103.11.19 */
                            if (strcmp(iins_scope_a,"2") == 0)
                            {
                            	lDaily_pay     = 2000 ;
                            	ori_lDaily_pay = 2000;
                            }

                        }else if (fTaishin=='Y'){
                            if (ori_damage_cover <= 1000000){
                                damage_cover = 1000000 ;
                            }
                        }else if (strncmp(trim(iofficer),"A04",3) == 0){
                            /* �����վ��ĳ��O�զX (1081024005_SC1)(1120309003_SC1) */
                            if (ori_damage_cover < 5000000){
                                damage_cover = 5000000 ;
                            }

                            /* ���B��(iins_scope_a=2) */
                            if (strcmp(iins_scope_a,"2") == 0)
                            {
                        	lDaily_pay     = 2000;
                            }
                            else if (strcmp(iins_scope_a,"3") == 0){
                        	lDaily_pay     = 200000;
                            }
                        }
                    }
                }

                /* 980416, �p�G��O�B<300�U, ��ĳ��O�զX��ĳ 300�U/2000�� */
                /* �������B��(iins_scope_a=2)�~��,����I��(iins_scope_a=3)�P�e�� modify by sylvia 103.11.19 */
                /* ����56�I�ح��O�զX���B��ĳ modify by sylvia 105.08.03 (1050728009_C1) */
                /* ����56�I�ئ��|���B��ĳ modify by sylvia 105.12.22 (1051208008_C1) */
                if (strcmp(iins_scope_a,"2") == 0)
                {
                    if (fquota63 == 'Y')
                    {   /* �ŦX�_�G�ϯS�w�����,�@�ߦP���O�զX add by sylvia 105.10.26 */
                        ori_lDaily_pay	= lDaily_pay_a;
   											lDaily_pay  	= lDaily_pay_a;
                    }
                    else if (f245_265=='Y')
                    {
                        /* �s��(245)�O��(265)����W�ۤw���I�ث�ĳ�W�h add by sylvia 106.06.23 (1060614005_C1) */
                        ori_lDaily_pay	= lDaily_pay_a; /* bug�ץ�,�����N�Ҧ����ت����B�٭쬰���O�զX�����B  by sylvia 106.07.26 */
   											lDaily_pay  	= lDaily_pay_a;

                        if((strncmp(car_typei,"03",2) == 0) ||(strncmp(car_typei,"04",2) == 0) ||
		           						 (strncmp(car_typei,"19",2) == 0) ||(strncmp(car_typei,"22",2) == 0))
		        						{
								            /* ���O�O�B > 300�U,�P���O�զX; ���O�O�B <= 300�U,�C�H300�U+���B2000�� */
								            if (ori_damage_cover > 3000000)
                            {
                                damage_cover = ori_damage_cover ;
                                ori_lDaily_pay	= lDaily_pay_a;
                                lDaily_pay  	= lDaily_pay_a;
                            }
                    	    	else
                    	    	{
                    	  			damage_cover = 3000000 ;

		            	  	        if (strcmp(iins_scope_a,"2") == 0)
		            	  	        {
		               	  	            lDaily_pay     = 2000 ;
		               	  	            ori_lDaily_pay	= lDaily_pay_a;
		            	  	        }
            	  	    			}
		        						}
                    }
                    else
                    {
                        if (ori_damage_cover < 3000000){
                   	    	ori_lDaily_pay = lDaily_pay_a;
                   	    	lDaily_pay  	= lDaily_pay_a;
                        }else{
       			    					ori_lDaily_pay = lDaily_pay_a;
       			    					lDaily_pay  	= lDaily_pay_a;
                        }
                    }
                }
                else
                {
                    ori_lDaily_pay	= lDaily_pay_a;
                    lDaily_pay  	= lDaily_pay_a;
                }
                #ifdef PRINTF_FLAG
                printf(" ------- 56 only2 \n ");
            		printf(" ------- car_typei = [%s]\n " , car_typei);
								printf(" ------- ori_damage_cover = [%ld]\n " , ori_damage_cover);
								printf(" ------- damage_cover = [%ld]\n " , damage_cover);
                #endif
            }
            else if (strcmp(ins_type,"136") == 0)
            {
            	ins136_flag = 1;
            	$select first 1 iins_scope,daily_pay into $iins_scope_a,$lDaily_pay_a
                   from ca_pa_ply_last
                  where ipolicy = $last_ply and iins_type = '136';

                ori_lDaily_pay	= lDaily_pay_a;
                lDaily_pay  	= lDaily_pay_a;
            }
            else if (strcmp(ins_type,"166") == 0)
            {
            	ins166_flag = 1;
            	$select first 1 iins_scope,daily_pay into $iins_scope_a,$lDaily_pay_a
                   from ca_pa_ply_last
                  where ipolicy = $last_ply and iins_type = '166';

                ori_lDaily_pay	= lDaily_pay_a;
                lDaily_pay  	= lDaily_pay_a;
            }
            else if (strcmp(ins_type,"266") == 0) /*�s�W266�I�� (1110308005_SC3)*/
            {
            	ins266_flag = 1;
            	$select first 1 iins_scope,daily_pay into $iins_scope_a,$lDaily_pay_a
                   from ca_pa_ply_last
                  where ipolicy = $last_ply and iins_type = '266';

                ori_lDaily_pay	= lDaily_pay_a;
                lDaily_pay  	= lDaily_pay_a;
            }
            else if (strcmp(ins_type,"52") == 0 || strcmp(ins_type,"53") == 0 || strcmp(ins_type,"252") == 0 || strcmp(ins_type,"253") == 0)
            {
                /* 06 �ۤj�f(��) 20(���j�f) 18(�ۥΤ@��|��) 31(�ۥγf�d�|��) 12(�ۤj��)
		   	       qpt��qpassenger���O����,�ҥH�n��"�e���O�B"�^��"���ȼ�"	*/
                if ((strncmp(car_typei,"06",2) == 0) || (strncmp(car_typei,"20",2) == 0) ||
                    (strncmp(car_typei,"18",2) == 0) || (strncmp(car_typei,"31",2) == 0) ||
                    (strncmp(car_typei,"12",2) == 0))
                {
                    qpassenger = ori_damage_cover/ori_death_cover ;
                }
            }
            else if (strcmp(ins_type,"31") == 0 || strcmp(ins_type,"231") == 0 || strcmp(ins_type,"531") == 0)
            {
            	f_31_exist = 'Y';

                if (ori_deduct == 0)
                { /* 102.10.23 , �O�v�ɷs�W�ۭt�B�A���O���ۭt�B�̡A����ĳ */
	                if (ISMOT(car_typei))
	                {
	                    if (sug_flag=='Y'){
	                        if (injured_cover < 300000){
	                            injured_cover = 300000;
	                            damage_cover  = 600000;
	                        }
	                    }
	                }
	                else
	                {
	                    if (sug_flag=='Y')
	                    {
		                    	/* ����O 29, 30�I�ت̡A��ĳ��O�զX=���O�զX  */
		                    	if ((f_29_exist=='N') && (f_30_exist=='N') && (f_301_exist=='N') && (f_302_exist=='N') )
		                    	{ /* 29�B30 qserial �� 31�B32 �j �A�G�|���P�_�� (�]�� ORDER BY qserial DESC) */
			                    		if(ISCAR_SET1(car_typei)) {
				                    			/* ����(A04)��ӸΫH(A23*) */
				                    			/* ���p(A11*)���O�զX��^ "�����O�B" */
				                    			/* �x���Υ�(A21*) ��l��O�զX��^ "�����O�B"  */
				                    			/* �W�ߨT�� */
				                    			/* �ΫH(A23*)�x���Υ�(A21*)���p(A11*) =>��l�Ϋ�ĳ�ҭn�� */
				                    			/* ���M(L*)�ק��ĳ��O�զX add by 061476 (1080212008_SC1) */
				                    			if ((fSunLi=='Y')||(strncmp(iofficer,"A11",3) == 0)||
				                    			    (strncmp(iofficer,"A21",3) == 0)||(strncmp(iofficer,"A23",3) == 0)||
				                    			    (strncmp(iofficer,"A04",3) == 0)||(strncmp(iofficer,"A16",3) == 0)||
				                    			    (strncmp(iofficer,"A10",3) == 0)||(iofficer[0]=='L'))
				                    			{
	                    								/* ��q(A16*)TPL 31/32�I�ا��ĳ�� 500�U/5000�U/70�U
                            		                   31�I��: ���O�զX�O�B1 < 500�U   �h�@�߫�ĳ 500�U/5000�U
                            		                   �O�B1 = 500�U   �h�O�B2�ܤֶ���5000�U(10��)
                            		                   �O�B1 > 500�U   �h�����O�B2���O�B
                            		                   32�I��:�ܤ�70�U
                            		                   ���اt 03/21/22/04/19   modify by sylvia 104.05.18 (1040424003_C1)*/
																			if(f_109_exist=='N')
				                            	{
				                            			if(strncmp(iofficer,"A16",3) == 0)
				    							    						{
				    																	if ((ori_injured_cover < 5000000)||
				            				                           ((ori_injured_cover == 5000000)&&(ori_damage_cover < 50000000 )))
				            				                        {
				            				                            injured_cover = 5000000;
				            				                            damage_cover  = 10 * injured_cover;
				            				                        }
				    							    						}
				    							    						else if(strncmp(iofficer,"A04",3) == 0)
				    							    						{/* �����վ��ĳ��O�զX add by 061476 108.11.22 (1081024005_SC1) */
				    							     							/* modify by 061476 112.04.11 (1120309003_SC1) */
												    								if (injured_cover <= 5000000)
												    								{
												    								    injured_cover = 5000000;
												    								    damage_cover  = 10 * injured_cover ;
												    								}
				    							    						}
				    							    						else if(strncmp(iofficer,"A10",3) == 0)
				    							    						{/* �ηs�վ�O�B add by 061476 109.05.13 (1090410009_SC1) */
												    								if (injured_cover <= 2000000)
												    								{
												    								     injured_cover = 2000000;
												    								     damage_cover  = 5 * injured_cover ;
												    								}
				    							    						}
				    							    						else if(iofficer[0]=='L')
				    							    						{/* ���M�վ�O�B add by 061476 110.01.06 (1080212008_SC1) */
				    							        					if((strncmp(car_typei,"03",2) == 0) || (strncmp(car_typei,"21",2) == 0) ||
				    								   									(strncmp(car_typei,"22",2) == 0))
				    																{
				    								    								if ((injured_cover <= 2000000) && (damage_cover <= 4000000))
				    								    								{
				    								        								injured_cover = 2000000;
				    																				damage_cover  = 12 * injured_cover ;
				    								    								}
				    																}
				    							    						}
				    							    						else
				    							    						{
												    								/* �W�ߡBA11�BA21�BA23�BA04 ���� 03 21 22 ���� �վ�(12��)�O�B*/
												    								if((strncmp(car_typei,"03",2) == 0) || (strncmp(car_typei,"21",2) == 0) ||
												    								   (strncmp(car_typei,"22",2) == 0))
												    								{
				    																	if ((injured_cover <= 2000000) && (damage_cover <= 4000000))
				    																	{
													    										/*** ��ĳ��O�զX ***/
													    										injured_cover = 2000000;
													    										damage_cover  = 12 * injured_cover ;

													    										/*** ���O�զX   ***/
													    										/* 981208,���p(A11*)���O�զX��^ "�����O�B" */
													    										/* �x���Υ�(A21*)���O�զX��^ "�����O�B" */
													    										/* ���ΫH(A23*)�B�W�� ���O�զX������O�B�~�A��l�אּ200�U */
													    										/* 981208,���p(A11*)���O�զX��^ "�����O�B",�ҥH���O�զX�u��"�ΫH"�n�אּ12�� */
													    										/* �x���Υ�(A21*)���O�զX��^ "�����O�B" */
													    										/* �W�� ���O�զX������O�B */
													    										if(strncmp(iofficer,"A23",3) == 0){
													    											ori_damage_cover  = 12 * ori_injured_cover;
													    										}
												    									}else{
												    										/* 981208,���p(A11*)���O�զX��^ "�����O�B",�ҥH���O�զX�u��"�ΫH"�n�אּ12�� */
												    										/* �x���Υ�(A21*)���O�զX��^ "�����O�B" */
												    										/* ���W�� ���O�զX������O�B�~�A��l�אּ12�� */
												    										if (strncmp(iofficer,"A23",3) == 0){
												    											ori_damage_cover  = 12 * ori_injured_cover;
												    										}
												    										damage_cover = 12 * injured_cover;
												    									}
				        					  							}
				        						    				}
				        											}/* end f_109_exist=='N' */
						    										/* �C�M��92�~10��_������O��,�ĤT�H�d���I����ĳ�O�B��200/400/50 car-9206241 */
						    										/* 980223, �x�s�O�g�N   */
    															}else if ((strncmp(iofficer,"A02",3) == 0)||fTaishin=='Y'){
	    																if(f_109_exist=='N')
	                                		{
	                                				if ((injured_cover <= 2000000) && (damage_cover <= 4000000)){
								    							        		injured_cover = 2000000;
								    							        		damage_cover  = 4000000;
	    							    									}
	    																}
    															}else if(strncmp(iofficer,"A09",3) == 0){
	    														/* �έ�(A09*)TPL 31/32�I�ا��ĳ�� 400�U/4000�U/50�U
	    						           					31�I��: ���O�զX�O�B1 < 400�U �h�@�߫�ĳ 400�U/4000�U
	    						                   �O�B1 = 400�U   �h�O�B2�ܤֶ���4000�U(10��)
	    						                   �O�B1 > 400�U   �h�����O�B2���O�B
	    						           				32�I��: �ܤ�50�U   modify by sylvia 104.05.18 (1040424003_C1)*/

		    														if( f_109_exist=='N')
		                                {
		    							      						if ((ori_injured_cover < 4000000)||
		            				                    ((ori_injured_cover == 4000000)&&(ori_damage_cover < 40000000 )))
		            				                {
		                                    		injured_cover = 4000000;
		            				                    damage_cover  = 10 * injured_cover;
		                                    }
																		}
                           				}else if (strncmp(car_typei,"03",2) == 0){
				                              /* �D�s��(245)�O��(265)�~���U�C�P�_add by sylvia 106.06.23 (1060614005_C1) */
				                              /* �_�@�ҰϤ]���i�վ� add by 061476 108.05.30 (1080507001_SC1) */
				                              if ((f245_265 == 'N')&&(fquota_62 == 'N'))
				                              {
				                              		if( f_109_exist=='N')
				                                  {
				                                  	/* ��Ө�L����,���ĳ�W�h���� modify by sylvia 106.03.13 (1060302003_C1) */
				                                    if((ori_injured_cover <= 2000000) && (ori_damage_cover <= 4000000)){
				        						        						injured_cover = 2000000;
				        						        						damage_cover  = 4000000;
				        						    							}
				        					        				} /* end f_109_exist=='N' */
				    					            		}
                          				}
                							}
								        			else
								        			{
												    		/* �D�s��(245)�O��(265)�~���U�C�P�_add by sylvia 106.06.23 (1060614005_C1) */
												    		/* �_�@�ҰϤ]���i�վ� add by 061476 108.05.30 (1080507001_SC1) */
														    if ((f245_265 == 'N')&&(fquota_62 == 'N'))
														    {
									    						/* 1000724, �D 03/21/22���ت̡A�����O�B
									    						   ���B���D 03/21/22/04/19 ���� */
									    						if ((fSunLi=='Y')||(strncmp(iofficer,"A11",3) == 0)||
									    						    (strncmp(iofficer,"A21",3) == 0)||(strncmp(iofficer,"A23",3) == 0)||
									    						    (strncmp(iofficer,"A04",3) == 0)||(strncmp(iofficer,"A16",3) == 0))
							                    {
							                        /* �����O�B */
							                    }
							                    else
							                    {
							                        /* 31�I��: ���O�զX�O�B1 < 400�U   �h�@�߫�ĳ 400�U/4000�U
							        		                 �O�B1 = 400�U   �h�O�B2�ܤֶ���4000�U(10��)
							        		                 �O�B1 > 400�U   �h�����O�B2���O�B
							        		               32�I��:�ܤ�50�U   */
							        		            if(f_109_exist=='N')
							        		            {
																					if(strncmp(iofficer,"A09",3) == 0)
							                            {
							                            		if ((ori_injured_cover < 4000000)||
							            				                ((ori_injured_cover == 4000000)&&(ori_damage_cover < 40000000 )))
							            				            {
							            				            		injured_cover = 4000000;
							            				                damage_cover  = 10 * injured_cover;
							                                }
							                            }
							                            else
							                            {
							        						    				/* 960402,��L����(���إN���D03,04,19,21,22) ,��ӫO�O�B�C��B����200/400�U�Υ���O��,��ĳ�O�B�]�w200/400�U�C*/
											        						    if((ori_injured_cover <= 2000000) && (ori_damage_cover <= 4000000))
											        						    {
											        						        injured_cover = 2000000;
											        						        damage_cover  = 4000000;
											        						    }
							    					              }
							    					         } /* end f_109_exist=='N' */
						    					      	}
				    				      			}
                							}
                    			}/* end of if ((f_29_exist=='N') && (f_30_exist=='N') && (f_301_exist=='N') )*/
                      }/*end of if (sug_flag=='Y')*/
                      else if(fquota_62 == 'Y')
                      {
                                #ifdef PRINTF_FLAG
                                printf("�i�J�_�@��31�S����O�W�h\n ");
                                printf("injured_cover31_pre[%ld]\n ",injured_cover31_pre);
                                printf("damage_cover31_pre[%ld]\n ",damage_cover31_pre);
                                printf("damage_cover32_pre[%ld]\n ",damage_cover32_pre);
                                printf("deduct32_pre[%ld]\n ",deduct32_pre);
                                #endif
                            	/* 1101209008_SC1_�_�@�Ͻվ��ĳ��O��� (add by 071004 2021.12.30) */
                            	/* ��109�I�ؤ��o�վ��ĳ�O�B (1111005003_SC1) */
                            	if(f_109_exist=='N')
                            	{
                            		if(ISCAR_SET1(car_typei))
                            	        {
                            	        	if(injured_cover31_pre == 2000000 && damage_cover31_pre == 4000000 && damage_cover32_pre == 500000 && deduct32_pre == 0)
                            	        	{
                            	        		injured_cover = 3000000;
                            	        		damage_cover  = 6000000;
                            	        	}
                            	        }
                            	}
                      }
		            			#ifdef PRINTF_FLAG
	                    printf("31 ========  c_30_set[%d]  ori_injured_cover[%ld]  ori_damage_cover[%ld]\n",c_30_set, ori_injured_cover, ori_damage_cover);
	                    printf("31 ========  f_30_exist[%d] injured_cover[%ld]     damage_cover[%ld]\n",f_30_exist,injured_cover,damage_cover);
                      #endif
                   }
                }/* ��ۭt�B=0  end */

                /* ���Υ��P�_30�I�ئۭt�B�� (1070629004_SC1)*/
                /* 30/301�I�طs�W�����A�ۭt�B��ѧP�_31�B32�O�B modify by 061476 (1071203004_SC3) */
                injured_cover31 = injured_cover;
                injured_cover31_ori = ori_injured_cover;

                /* (1130510009_C13) */
                damage_cover31 = damage_cover;
            }
            else if (strcmp(ins_type,"133") == 0)
            {
                f_133_exist = 'Y';
                /* ���31�I��, ���ӫO30�I�خɷ|�̾�30�I�ئۭt�B�ק�133�I�س̧C�O�B add by sylvia 104.11.16 (1041030001_C4) */
                /* ���ľ��c�T����X�O�I���i�ӫO30�B301�I�� add by 061476 (1071203004_SC3) */
            }
            else if (strcmp(ins_type,"32") == 0 || strcmp(ins_type,"232") == 0 || strcmp(ins_type,"532") == 0)
            {
                f_32_exist = 'Y';

                if (ori_deduct == 0){	/* 990921, 32 �I�ئp�G���ۭt�B�A���ܧ��ĳ�O�B */
                    if (ISMOT(car_typei)){
                        if (sug_flag=='Y'){
                            if (damage_cover < 50000)
	                    				{
	                    					damage_cover = 50000;
                            	}
                        }
                    }
                    else
                    {
                        if (sug_flag=='Y')
                        {
                            /* ����(A04)��ӸΫH(A23*) */
                            /* ����O 29, 30�I�ت̡A��ĳ��O�զX=���O�զX  */
                            /* �s�W301�I�� add by sylvia 106.04.17 (1060329005_C4) */
                            if ((f_29_exist=='N') && (f_30_exist=='N') && (f_301_exist=='N') && (f_302_exist=='N') )
                            {
                                /* 100.01.05, ���M�O�N �ĤT�H�d���I���]�l�d���I��ĳ�O�B���ɦ�80�U�� */
			                        	/* ���M(L*)�O�N�ק��ĳ��O�զX���e modify by 061476 (1080212008_SC1) */
			                        	if (iofficer[0]=='L')
			                        	{
			                        		if((strncmp(car_typei,"03",2) == 0) || (strncmp(car_typei,"21",2) == 0) || (strncmp(car_typei,"22",2) == 0))
			                        		{
			                        		    if(f_109_exist=='N')
			                        		    {
			                        		        if (damage_cover < 500000) {
			                        			    				damage_cover  = 500000;
			                        							}
			                        		    }
			                        		}
    														}
										    				else
										    				{
										    				    if(ISCAR_SET1(car_typei)) {
										    				        /* 102.11.26, �s�W��qA16 */
										    				        /* 981208,���p(A11*)���O�զX��^ "�����O�B" */
										    				        /* 961128, �x���Υ�(A21*)���O�զX��^ "�����O�B" */
										    				        /* 951107 ,�ΫH(A23*)*/ /* 951127, �W�ߨT�� */
													    					/* 950913 ,�έ�(A09*) �ק��ĳ����(��������)  */
													    					/* 950831 ,�x���Υ�(A21*)�B���p(A11*) =>��l�Ϋ�ĳ�ҭn�� */
													    					/* �C�M��92�~10��_������O��,�ĤT�H�d���I����ĳ�O�B��200/400/50 car-9206241 */
													    					/* ��q(A16*) 32�I�ئܤ�70�U  modify by sylvia 104.05.18 (1040424003_C1) */
													    					/* �έ�(A09*) 32�I�ئܤ�50�U  modify by sylvia 104.05.18 (1040424003_C1) */
    				        										if ((strncmp(iofficer,"A11",3) == 0)||
													    					    (strncmp(iofficer,"A21",3) == 0)||(strncmp(iofficer,"A02",3) == 0)||
													    					    (strncmp(iofficer,"A23",3) == 0)||(fSunLi=='Y'))
													    					{
													    						if(f_109_exist=='N')
													    						{
													    						    if (damage_cover < 500000)
													    						    {
													    						        damage_cover  = 500000;
													    						    }
													    						}
													    					}
													    					else if(strncmp(iofficer,"A04",3) == 0)
													    					{
													    						if(f_109_exist=='N')
													    						{
													    						    if (ori_damage_cover < 1000000){
													    						        damage_cover = 1000000;
													    						    }
													    						}
													    					}
													    					else if(strncmp(iofficer,"A16",3) == 0)
													    					{
													    						if(f_109_exist=='N')
													    						{
													    						    if (ori_damage_cover < 700000){
													    						        damage_cover = 700000;
													    						    }
													    						}
													    					}else if(strncmp(iofficer,"A09",3) == 0){
													    						if(f_109_exist=='N')
													    						{
													    						    if (ori_damage_cover < 500000)
													    						    {
													    						        damage_cover = 500000;
													    						    }
													    						}
    																		}else if(strncmp(iofficer,"A10",3) == 0){
														    						if(f_109_exist=='N')
														    						{
														    						    if (ori_damage_cover < 500000)
														    						    {
														    						        damage_cover = 500000;
														    						    }
														    						}
														    				}else if(fTaishin=='Y'){
												    					    if(f_109_exist=='N')
												    					    {
												    					        if (damage_cover < 200000)
												    					        {
															    						    damage_cover  = 200000;
															    						}
    					    												}/* end f_109_exist=='N' */
    																	 }else {
												    					    /* �D�s��(245)�O��(265)�~��O�B add by sylvia 106.06.23 (1060614005_C1) */
												    					    /* �_�@�ҰϤ]���i�վ� add by 061476 108.05.30 (1080507001_SC1) */
												    					    if((f245_265 == 'N')&&(fquota_62 == 'N'))
												    					    {
    					        											if(f_109_exist=='N')
														    						{
														    						    if(ori_damage_cover >= 500000)   damage_cover = ori_damage_cover;
														    						    else if(ori_damage_cover < 100000)   damage_cover = 100000;
														    						    else if(ori_damage_cover < 200000)  damage_cover = 200000;
														    						    else {
														    						        damage_cover = ori_damage_cover+100000;
														    							if (damage_cover >= 500000)
														    							    damage_cover  = 500000;
														    						    }
														    						} /* end f_109_exist=='N' */
    					    												}
    																	}
    				    										} /* (ISCAR_SET1(car_typei)) end */
    				    										else
    				    										{
												    				  /* 960402,��L����(���إN���D03,04,19,21,22) ,��ӫO�O�B�C��B����50�U�Υ���O��,��ĳ�O�B�]�w50�U�C*/
												    					/* ���O�O�B<50�U,�אּ��O�B+10�U,�̰�50�U modify by sylvia 106.03.13 (1060302003_C1) */
												    					/* �D �s��(245)�O��(265) �~�ק�O�B add by sylvia 106.06.23 (1060614005_C1) */
												    					/* �_�@�ҰϤ]���i�վ� add by 061476 108.05.30 (1080507001_SC1) */
												    					if ((f245_265 == 'N')&&(fquota_62 == 'N'))
												    					{
											    					    if(f_109_exist=='N')
											    					    {
											    					        if(ori_damage_cover >= 500000)   damage_cover = ori_damage_cover;
											    									else if(ori_damage_cover < 100000)   damage_cover = 100000;
											    					        else if(ori_damage_cover < 200000)  damage_cover = 200000;
											    									else {
											    						    		damage_cover = ori_damage_cover+100000;
											    						    		if (damage_cover >= 500000)
											    						       			damage_cover  = 500000;
											    									}
											    					    }
    																	}
				    												}
																}
			    									}
                        }  /* (sug_flag=='Y') end */
                        else if(fquota_62 == 'Y')
                        {
                            /* 1101209008_SC1_�_�@�Ͻվ��ĳ��O��� (add by 071004 2021.12.30) */
                            /* ��109�I�ؤ��o�վ��ĳ�O�B (1111005003_SC1) */
                            if(f_109_exist=='N')
                            {
                            	if(ISCAR_SET1(car_typei))
                            	{
                            		if(injured_cover31_pre == 2000000 && damage_cover31_pre == 4000000 && damage_cover32_pre == 500000  && deduct31_pre == 0)
                            	        {
        				    										damage_cover  = 600000;
                            	        }
                            	}
                            }
                        }
                    } /* �D���� end  */
                } /* (ori_deduct == 0) end */

                /* �_�G�ҰϨ��d�I��ĳ��O�խק�: add by sylvia 105.09.14 (1050823002_C1)
                   ����: (1) �_�G��(�~�Z���=63*)�B(2)��03,22���� (3)�D����,�D����B�Dcar147�]�w�����ĳq�� <==���ŦX
                        32�I�ثO�B�վ�: �O�B<=20�U ==>  20�U;
                                        �O�B<=30�U ==>  30�U;
                                        �O�B<=40�U ==>  40�U;
                                        �O�B<=50�U ==>  50�U;
                                        �O�B>50�U ==>  ����;    */
                /* ��Hfquota63���N (fquota63�b�e���w���P�_) add by sylvia 105.10.21 */
                if(fquota63 == 'Y')
                {
                    if (ori_damage_cover < 200000)
                        damage_cover = 200000;
                    else if (ori_damage_cover < 300000)
                        damage_cover = 300000;
                    else if (ori_damage_cover < 400000)
                        damage_cover = 400000;
                    else if (ori_damage_cover < 500000)
                    {
                        damage_cover = 500000;
                        strcpy(upd29_cov1,"Y");
                    }
                    else
                        damage_cover = ori_damage_cover;
                }
                /* 30/301�I�طs�W�����A�ۭt�B��ѧP�_31�B32�O�B modify by 061476 (1071203004_SC3) */
                damage_cover32 = damage_cover;
                damage_cover32_ori = ori_damage_cover;
            }
            else if (strcmp(ins_type,"134") == 0){
                f_134_exist = 'Y';
            }else if (strcmp(ins_type,"149") == 0 || strcmp(ins_type,"249") == 0){
                f_149_exist = 'Y';
                damage_cover149 = damage_cover;
            }else if (strcmp(ins_type,"150") == 0){
                f_150_exist = 'Y';
            }else if (strcmp(ins_type,"49") == 0){
                f_49_exist = 'Y';
            }else if (strcmp(ins_type,"24") == 0) {
                f_24_exist = 'Y';
                f_del_24 = 'Y';    /* �t�X�ӫ~����,�n�R��24�I�� (1080311008_SC3) */
                strcpy(fcomp_24,"N");
            }else if (strcmp(ins_type,"71") == 0){
                if (ori_damage_cover > 2500000){
                    ori_damage_cover = 2500000;
                    damage_cover = 2500000;
                }
            }else if (strcmp(ins_type,"11") == 0 || strcmp(ins_type,"211") == 0){
                f_11_exist = 'Y';
                damage_cover11_ori = damage_cover;
            }else if (strcmp(ins_type,"129") == 0){
                f_129_exist = 'Y';
            }else if (strcmp(ins_type,"12") == 0){
                f_12_exist = 'Y';
            }else if (strcmp(ins_type,"28") == 0){ /* 971223,���B�s�t����[���� */
                f_28_exist = 'Y';
            }else if (strcmp(ins_type,"128") == 0){
                f_128_exist = 'Y';
            }else if (strcmp(ins_type,"01") == 0 || strcmp(ins_type,"201") == 0){
                f_01_exist = 'Y';
                f_1_9_exist = 'Y';
            }else if (strcmp(ins_type,"05") == 0 || strcmp(ins_type,"205") == 0){
                f_05_exist = 'Y';
                f_1_9_exist = 'Y';
            }else if (strcmp(ins_type,"125") == 0){
                f_125_exist = 'Y';
                f_1_9_exist = 'Y';
            }else if (strcmp(ins_type,"08") == 0){
                f_08_exist = 'Y';
                f_1_9_exist = 'Y';
            }else if (strcmp(ins_type,"09") == 0 || strcmp(ins_type,"209") == 0){
                f_09_exist = 'Y';
                f_1_9_exist = 'Y';
                if (strstr(tmp_provision,"K;") != NULL)
                {
                	ins09k_flag = 1;
                }
                /*if (ori_deduct != 0)
                {
                	*���ۭt�B�ݥ[V���� add by 061476 (1071226006_SC3) *
                	f_provision_V = 'Y';
                }*/
            }else if (strcmp(ins_type,"126") == 0){
                f_126_exist = 'Y';
                f_1_9_exist = 'Y';
            }else if (strcmp(ins_type,"85") == 0){
                f_85_exist = 'Y';
                f_1_9_exist = 'Y';
                f_del_85 = 'Y';    /* �t�X�ӫ~����,�n�R��85�I�� (1051214006_C4) */
                mdamage_cover_09_sug = damage_cover;
                mdamage_cover_153_sug = injured_cover;
            }else if (strcmp(ins_type,"47") == 0){
                f_47_exist = 'Y';
            }else if (strcmp(ins_type,"147") == 0){
                f_147_exist = 'Y';
            }else if (strcmp(ins_type,"14") == 0){
                f_14_exist = 'Y';
            }else if (strcmp(ins_type,"16") == 0){
                f_16_exist = 'Y';
            }else if (strcmp(ins_type,"17") == 0){
                f_17_exist = 'Y';
            }else if (strcmp(ins_type,"18") == 0){
                f_18_exist = 'Y';
            }else if (strcmp(ins_type,"19") == 0){
                f_19_exist = 'Y';
                if (sug_flag=='Y')
                {
                    /* �վ�19�I�ث�ĳ�O�B (1071116003_SC1) */
                    if (ins1419_chg_flag == 0)
                    {
                    	if((damage_cover >= 3000) && (damage_cover <= 15000))
                    	{
                    		damage_cover = 15000;
						        	}
							        else if((damage_cover > 15000) && (damage_cover <= 24000))
							        {
							        	damage_cover = 24000;
							        }
							        else if((damage_cover > 24000) && (damage_cover <= 30000))
							        {
							        	damage_cover = 30000;
							        }
							        else if((damage_cover > 30000) && (damage_cover <= 45000))
							        {
							        	damage_cover = 45000;
							        }else{ }
	            			}

				            if ((strncmp(iquota, "65",2) == 0)&&(strcmp(imgr,"2") == 0)&&(fBarcode == 'N'))
				            {
				            	if ((strncmp(car_typei,"03",2) == 0) || (strncmp(car_typei,"04",2) == 0) ||
				            	    (strncmp(car_typei,"19",2) == 0) || (strncmp(car_typei,"22",2) == 0))
				            	{
				            		if (damage_cover < 30000) damage_cover = 30000;
				            	}

				            }
                }
            }else if (strcmp(ins_type,"02") == 0){
                f_02_exist = 'Y';
            }else if (strcmp(ins_type,"03") == 0){
                f_03_exist = 'Y';
            }else if (strcmp(ins_type,"27") == 0){
                f_27_exist = 'Y';
                if (fquota_63 == 'Y')
                {  /* �P�\���T�{�A�s�_�O���]�n��ĳ(1080322003_SC1) */
                	if ((sug_flag=='Y')||((sug_flag=='N')&&(f245_265 == 'Y')))
                	{
                		if (damage_cover < 100000) damage_cover = 100000;
                	}
                }
            }else if (strcmp(ins_type,"30") == 0){
                f_30_exist = 'Y';
                /* �����վ��ĳ��O�զX add by 061476 108.11.22 (1081024005_SC1) */
                if ((sug_flag=='Y')&&(strncmp(iofficer,"A04",3) == 0)&&(ISCAR_SET1(car_typei))){
                	if (damage_cover < 10000000) damage_cover = 10000000;
                }

                /* 108.07.01�_�s�v�I����A30�I�ئۭt�B��۽վ� (1080311008_SC3) */
                switch (deduct)
                {
                    case 124:    ori_deduct = 1;   deduct = 1;   break;
                    case 224:    ori_deduct = 2;   deduct = 2;   break;
                    case 324:    ori_deduct = 3;   deduct = 3;   break;
                    case 12455:  ori_deduct = 155; deduct = 155; break;
                    case 22455:  ori_deduct = 255; deduct = 255; break;
                    case 32455:  ori_deduct = 355; deduct = 355; break;
                }
                deduct_30 = deduct;
                strcpy(deduct30,itoa(deduct));
            }else if (strcmp(ins_type,"301") == 0){
                f_301_exist = 'Y';
                /* �����վ��ĳ��O�զX add by 061476 108.11.22 (1081024005_SC1) */
                if ((sug_flag=='Y')&&(strncmp(iofficer,"A04",3) == 0)&&(ISCAR_SET1(car_typei))){
                	if (damage_cover < 10000000)
                	{
                		injured_cover = 10000000;
                		damage_cover = 20000000;
                	}
                }
                deduct_301 = deduct;
                strcpy(deduct30,itoa(deduct));
            }else if (strcmp(ins_type,"10") == 0){
                f_10_exist = 'Y';
            }else if (strcmp(ins_type,"127") == 0){
                f_127_exist = 'Y';
            }else if (strcmp(ins_type,"50") == 0){
                ins50_flag = 1;
            }else if (strcmp(ins_type,"34") == 0){  /* 960612, ���ݪ��I34 */
                f_34_exist = 'Y';
                /* �s��(245)�O��(265)�]�n��ĳ add by sylvia 106.06.23 */
                if ((sug_flag=='Y')||((sug_flag=='N') && (f245_265 == 'Y'))){
                	if (fquota_63 == 'Y')
                	{
                		if (ori_injured_cover < 10000 || ori_death_cover < 100000){
                			injured_cover = 10000;
                			damage_cover1 = injured_cover*2;
                			death_cover   = 100000;
                			damage_cover  = death_cover*2;
                		}
                	}
                	else
                	{
                		if ((strncmp(car_typei,"03",2) == 0)||(strncmp(car_typei,"04",2) == 0)||
		                (strncmp(car_typei,"19",2) == 0) ||(strncmp(car_typei,"21",2) == 0)||
		                (strncmp(car_typei,"22",2) == 0))
		                {
		                	/* 2,500/25,000(�C�@�H���|/���G) => ��ĳ 5,000/50,000(�C�@�H���|/���G) */
		                	if (ori_injured_cover == 2500 && ori_death_cover == 25000){
		                		injured_cover = 5000;
		                		damage_cover1 = injured_cover*2;
		                		death_cover   = 50000;
		                		damage_cover  = death_cover*2;
		                	}
		                }
                	}
                }
            }else if (strcmp(ins_type,"87") == 0){  /* ���ݪ��I87 */
                f_87_exist = 'Y';
                if (sug_flag=='Y')
                {
		            if ((strncmp(car_typei,"03",2) == 0) ||(strncmp(car_typei,"04",2) == 0) ||
		                (strncmp(car_typei,"19",2) == 0) ||(strncmp(car_typei,"21",2) == 0) ||
		                (strncmp(car_typei,"22",2) == 0))
		            {
				        injured_cover = ori_injured_cover ;
				        damage_cover1 = injured_cover *2 ;
				        death_cover   = ori_death_cover ;
				        damage_cover  = death_cover*2 ;
                    }
                }
            }else if (strcmp(ins_type,"66") == 0){
                f_66_exist = 'Y';
            }else if (strcmp(ins_type,"67") == 0){
                f_67_exist = 'Y';
            }else if (strcmp(ins_type,"15") == 0){
                f_15_exist = 'Y';
            }else if (strcmp(ins_type,"29") == 0){
                f_29_exist = 'Y';
                /* �����վ��ĳ��O�զX add by 061476 108.11.22 (1081024005_SC1) */
                if ((sug_flag=='Y')&&(strncmp(iofficer,"A04",3) == 0)&&(ISCAR_SET1(car_typei))){
                	if (damage_cover < 10000000) damage_cover = 10000000;
                }
                deduct_29 = deduct;
            }else if (strcmp(ins_type,"38") == 0){
                f_38_exist = 'Y';
                f_del_38 = 'Y';      /* �t�X�ӫ~����,�n�R��38�I�� (1100119001_SC3) */
            }else if (strcmp(ins_type,"39") == 0){
                f_39_exist = 'Y';
                f_del_39 = 'Y';      /* �t�X�ӫ~����,�n�R��39�I�� (1100119001_SC3) */
                injured_cover39_ori = ori_injured_cover;
                damage_cover39_ori  = ori_damage_cover ;
            }else if (strcmp(ins_type,"62") == 0){
                f_62_exist = 'Y';
                if (atoi(drate_ym)<48){
                  /* 101.11,  12/1�_�O�v�ɷs�W"�O�B�@", �O�v�N��=48�H��  */
                	ori_injured_cover = ori_damage_cover / 7 ;
                	injured_cover     = ori_injured_cover;
                }
            }else if (strcmp(ins_type,"63") == 0){
                f_63_exist = 'Y';
                if (atoi(drate_ym)<48){
                    ori_injured_cover = ori_damage_cover / 7 ;
                	injured_cover     = ori_injured_cover;
                }
            }else if (strcmp(ins_type,"64") == 0){
                f_64_exist = 'Y';
                if (atoi(drate_ym)<48){
                    ori_injured_cover = ori_damage_cover / 7 ;
                	injured_cover     = ori_injured_cover;
                }
            }else if (strcmp(ins_type,"143") == 0){
                f_143_exist = 'Y';
            }else if (strcmp(ins_type,"61") == 0){
                f_61_exist = 'Y';
            }else if (strcmp(ins_type,"65") == 0){
                f_65_exist = 'Y';
            }else if (strcmp(ins_type,"69") == 0){
                f_69_exist = 'Y';
            }else if (strcmp(ins_type,"86") == 0){
                f_86_exist = 'Y';
            }else if (strcmp(ins_type,"98") == 0){
                f_98_exist = 'Y';
                fhi_price = 'N' ; /* 98�I�ؤ��ǤJ�������[�O */
            }else if (strcmp(ins_type,"07") == 0){
                f_07_exist = 'Y';
            }else if ((strcmp(ins_type,"105") == 0)||(strcmp(ins_type,"118") == 0)){
                /* �]��105,118�P�_����@��,�G�g�b�P�@�q */
                /* �s�W 137, 138    add by sylvia 104.06.03 (1040515009_C4)  */
                /* ���� 137, 138  (1100311005_SC9) */
                if (strcmp(ins_type,"105") == 0)
                {
                    f_105_exist = 'Y';
                    mdamage_cover_152_sug = injured_cover; /* 105�������l�d��152���O�B�� (1051214006_C4) */
                    mdamage_cover_05_sug = damage_cover;    /* 105�O�B�d��05���O�B�� (1051214006_C4) */
                }
                else
                {
                    f_118_exist = 'Y';
                    mdamage_cover_152_sug = injured_cover; /* 118�������l�d��152���O�B�� (1051214006_C4) */
                    mdamage_cover_05_sug = damage_cover;    /* 118�O�B�d��05���O�B�� (1051214006_C4) */
                }

                f_1_9_exist = 'Y';

                /* 104.06.03 �s�W137,138 ���P�_ */
                /* 103.10.02 �s�W118���P�_ */
                /*102.11.8 , �w�� �h�~���ӫO105,118�I�ت̡G
                  �Y ������O�O�B �� �������l�O�B�A�B 1�U �� ������O�O�B �� 10�U
                    => �Y �������l�O�B ��1�U�A�h105,118�I�����O�Ϋ�ĳ��O�զX���������l�O�B����
                    => �Y �������l�O�B ��1�U�A�h105,118�I�����O�Ϋ�ĳ��O�զX���������l�O�B�@�ߧ令1�U��
                        �P�ɦb�u�O��q�T��v��ܡG
                          �� �]�����I�O�I���B����10�U�A�G�쨮���I�������l�O�I���B�w���խ�,�Y�����D�Ь��ӫO��

                  �Y ������O�O�B �� �������l�O�B�A�B ������O�O�B �� 1�U
                    => ����105,118�I�ءA���X�{����O�n�O�ѤW�A�P�ɦb�u�O��q�T��v��ܡG
                          �� �]�����I�O�I���B����1�U�A�G�쨮���I�w����,�Y�����D�Ь��ӫO��

                  �Y ������O�O�B �� �������l�O�B�A�h
                    => ����105,118�I�ءA���X�{����O�n�O�ѤW�A�P�ɦb�u�O��q�T��v��ܡG
                          ���]�����I�O�I���B�C�󤣩����l�O�B,�G�쨮���I�w����,�Y�����D�Ь��ӫO��	 */
                f_del_105 = 'N'; f_del_118 = 'N';


                /* ��E���ڭn�̥h�~�O�B���⤵�~���O�B,�D�����I�{�檺�O�B add by sylvia 104.03.17 */
                tpCover_105 = cover_01; /* �Ȧs105,118�O�B */
                tpCover_E = 0;
                if (strstr( tmp_provision, "E;") != NULL) {
                    $select mdamage_cover into $tpCover_E
                       from ply_ins_type_last
                      where ipolicy = $last_ply
                        and iins_type = $ins_type;

                    if (tpCover_E > 0)
		                SetCover_For_Prov_E(tpCover_E);
                }
                /* ----��E����-------------------------------------------------------------------------- */
			         	if (cover_01 >= ori_injured_cover)
			         	{
			         		if (cover_01>=10000 && cover_01<100000)
			         		{
			         			if (ori_injured_cover>10000){
			         				ori_injured_cover = 10000 ;
			         				injured_cover     = 10000 ;
			         				if (strlen(trim(remark1))>10){
			         					strcpy(remark6,"���]�����I�O�I���B����10�U�A�G�쨮���I�������l�O�I���B�w���խ�,�Y�����D�Ь��ӫO��");
			         					strcpy(remark7," ");
			         				}else{
			         					strcpy(remark1,"���]�����I�O�I���B����10�U�A�G�쨮���I�������l�O�I���B�w���խ�,�Y�����D�Ь��ӫO��");
			         					strcpy(remark2," ");
			         				}

			         				/* modify by sylvia 105.02.02 (1041230003_C1) */
			         				$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�]�����I�O�I���B����10�U�A�G�쨮���I�������l�O�I���B�w���խ�,�Y�����D�Ь��ӫO��','1','E54',$iofficer);
			         			}
			         		}
			         		else if (cover_01<10000)
			         		{
			         			/* ����105,118�I�ءA���X�{����O�n�O�ѤW�A�P�ɦb�u�O��q�T��v���*/
			         			if (strcmp(ins_type,"118") == 0)
			         				f_del_118 = 'Y';

			         			if (strcmp(ins_type,"105") == 0)
			         				f_del_105 = 'Y';

			         			if (strlen(trim(remark1))>10){
			         				strcpy(remark6,"���]�����I�O�I���B����1�U�A�G�쨮���I�Ψ���[�I���w����,�Y�����D�Ь��ӫO��");
			         				strcpy(remark7," ");
			         			}else{
			         				strcpy(remark1,"���]�����I�O�I���B����1�U�A�G�쨮���I�Ψ���[�I���w����,�Y�����D�Ь��ӫO��");
			         				strcpy(remark2," ");
			         			}
			         			/* modify by sylvia 105.02.02 (1041230003_C1) */
			         			$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�]�����I�O�I���B����1�U�A�G�쨮���I�Ψ���[�I���w����,�Y�����D�Ь��ӫO��','1','E54',$iofficer);
			         		}
			         	}else{
				         		/* ����105,118�I�ءA���X�{����O�n�O�ѤW�A�P�ɦb�u�O��q�T��v���*/
				         		if (strcmp(ins_type,"118") == 0)
                        	f_del_118 = 'Y';

                        if (strcmp(ins_type,"105") == 0)
                        	f_del_105 = 'Y';

                        if (strlen(trim(remark1))>10){
                        	strcpy(remark6,"���]�����I�O�I���B�C�󤣩����l�O�B,�G�쨮���I�Ψ���[�I���w����,�Y�����D�Ь��ӫO��");
                        	strcpy(remark7," ");
                        }else{
                        	strcpy(remark1,"���]�����I�O�I���B�C�󤣩����l�O�B,�G�쨮���I�Ψ���[�I���w����,�Y�����D�Ь��ӫO��");
                        	strcpy(remark2," ");
                        }
                        /* modify by sylvia 105.02.02 (1041230003_C1) */
                        $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�]�����I�O�I���B�C�󤣩����l�O�B,�G�쨮���I�Ψ���[�I���w����,�Y�����D�Ь��ӫO��','1','E54',$iofficer);
            		}
                cover_01 = tpCover_105 ; /* �٭�105,118�O�B */
                f_del_105 = 'Y';    /* �t�X�ӫ~����,�n�R��105�I�� (1051214006_C4) */
                f_del_118 = 'Y';    /* �t�X�ӫ~����,�n�R��118�I�� (1051214006_C4) */
            }else if (strcmp(ins_type,"106") == 0){
                    f_106_exist = 'Y';
                    f_del_106 = 'Y';    /* �t�X�ӫ~����,�n�R��106�I�� (1051214006_C4) */
                    mdamage_cover_67_sug = damage_cover;
         	    			minjured_cover_67_sug = injured_cover;
         	    			qday_67 = qday;
            }else if (strcmp(ins_type,"107") == 0){
         	    f_107_exist = 'Y';
         	    f_del_107 = 'Y';    /* �t�X�ӫ~����,�n�R��107�I�� (1051214006_C4) */
         	    mdamage_cover_63_sug = damage_cover;
         	    minjured_cover_63_sug = injured_cover;
            }else if (strcmp(ins_type,"108") == 0){
         	    f_108_exist = 'Y';
         	    f_del_108 = 'Y';    /* �t�X�ӫ~����,�n�R��108�I�� (1051214006_C4) */
         	    mdamage_cover_65_sug = damage_cover;
            }else if (strcmp(ins_type,"109") == 0){
         	    f_109_exist = 'Y';
            }else if (strcmp(ins_type,"77") == 0){
         	    f_77_exist = 'Y';
            }else if (strcmp(ins_type,"78") == 0){
         	    f_78_exist = 'Y';
            }else if (strcmp(ins_type,"79") == 0){
         	    f_79_exist = 'Y';
         	    ins7780_chg_flag = 1;
         	    strcpy(ins_type,"55");
         	    f_55_exist = 'Y';
            }else if (strcmp(ins_type,"80") == 0){
         	    f_80_exist = 'Y';
         	    ins7780_chg_flag = 1;
         	    damage_cover56 = damage_cover;
            }else if (strcmp(ins_type,"87") == 0){
         	    f_87_exist = 'Y';
            }else if (strcmp(ins_type,"88") == 0){
         	    f_88_exist = 'Y';
            }else if (strcmp(ins_type,"89") == 0){
         	    f_89_exist = 'Y';
            }else if (strcmp(ins_type,"120") == 0){
         	    f_120_exist = 'Y';
         	    f_1_9_exist = 'Y';
         	    f_del_120 = 'Y';    /* �t�X�ӫ~����,�n�R��120�I�� (1051214006_C4) */
         	    mdamage_cover_09_sug = damage_cover;
         	    deduct_09 = deduct;
            }else if (strcmp(ins_type,"121") == 0){
         	    f_121_exist = 'Y';
         	    f_del_121 = 'Y';    /* �t�X�ӫ~����,�n�R��121�I�� (1051214006_C4) */
         	    mdamage_cover_156_sug = damage_cover;
         	    minjured_cover_156_sug = injured_cover;
         	    qday_156 = qday;
            }else if (strcmp(ins_type,"119") == 0){
         	    f_119_exist = 'Y';
         	    f_del_119 = 'Y';    /* �t�X�ӫ~����,�n�R��119�I�� (1051214006_C4) */
         	    mdamage_cover_155_sug = damage_cover;
         	    minjured_cover_155_sug = injured_cover;
         	    qday_155 = qday;
            }else if (strcmp(ins_type,"122") == 0){
         	    f_122_exist = 'Y';
         	    f_1_9_exist = 'Y';
         	    f_del_122 = 'Y';    /* �t�X�ӫ~����,�n�R��122�I�� (1051214006_C4) */
         	    mdamage_cover_01_sug = damage_cover;
         	    deduct_01 = deduct;
            }else if (strcmp(ins_type,"123") == 0){
         	    f_123_exist = 'Y';
         	    f_del_123 = 'Y';    /* �t�X�ӫ~����,�n�R��123�I�� (1051214006_C4) */
         	    mdamage_cover_154_sug = damage_cover;
         	    minjured_cover_154_sug = injured_cover;
         	    qday_154 = qday;
            }else if (strcmp(ins_type,"131") == 0 || strcmp(ins_type,"331") == 0){
         	    f_131_exist = 'Y';
            }else if (strcmp(ins_type,"132") == 0 || strcmp(ins_type,"332") == 0){
         	    f_132_exist = 'Y';
            }else if (strcmp(ins_type,"110") == 0){
         	    f_110_exist = 'Y';
            }else if (strcmp(ins_type,"111") == 0){
         	    f_111_exist = 'Y';
            }else if (strcmp(ins_type,"112") == 0){
         	    f_112_exist = 'Y';
         	    f_del_112 = 'Y';    /* �t�X�ӫ~����,�n�R��112�I�� (1051214006_C4) */
         	    mdamage_cover_22_sug = damage_cover;
            }else if (strcmp(ins_type,"113") == 0){
         	    f_113_exist = 'Y';
         	    /* �]113�B114�I�اאּ�i���[30�I�ءA���O�d�O�B��30�I�ئۭt�B�P�_
         	       add by 061476 110.06.04 (1100415003_SC6) */
         	    injured_cover31 = injured_cover;
         	    injured_cover31_ori = ori_injured_cover;
            }else if (strcmp(ins_type,"114") == 0){
         	    f_114_exist = 'Y';
         	    /* �]113�B114�I�اאּ�i���[30�I�ءA���O�d�O�B��30�I�ئۭt�B�P�_
         	       add by 061476 110.06.04 (1100415003_SC6) */
         	    damage_cover32 = damage_cover;
         	    damage_cover32_ori = ori_damage_cover;
            }else if (strcmp(ins_type,"115") == 0){
         	    f_115_exist = 'Y';
            }else if (strcmp(ins_type,"117") == 0){
         	    f_117_exist = 'Y';
            }else if (strcmp(ins_type,"124") == 0){
         	    f_124_exist = 'Y';
            }else if (strcmp(ins_type,"152") == 0){
         	    f_152_exist = 'Y';
            }else if (strcmp(ins_type,"153") == 0){
         	    f_153_exist = 'Y';
            }else if (strcmp(ins_type,"154") == 0){
         	    f_154_exist = 'Y';
            }else if (strcmp(ins_type,"155") == 0){
         	    f_155_exist = 'Y';
         	    /* 155�I�ثO�B�d��163�I�بϥ� */
         	    mdamage_cover_163_sug = damage_cover;
         	    minjured_cover_163_sug = injured_cover;
         	    qday_163 = qday;
            }else if (strcmp(ins_type,"156") == 0){
         	    f_156_exist = 'Y';
            }else if (strcmp(ins_type,"161") == 0){
         	    f_161_exist = 'Y';
            }else if (strcmp(ins_type,"162") == 0){
         	    f_162_exist = 'Y';
            }else if (strcmp(ins_type,"163") == 0){
         	    f_163_exist = 'Y';
            }else if (strcmp(ins_type,"164") == 0){
         	    f_164_exist = 'Y';
            }else if (strcmp(ins_type,"165") == 0){
         	    f_165_exist = 'Y';
            }else if (strcmp(ins_type,"181") == 0){
         	    f_181_exist = 'Y';
         	    f_1_9_exist = 'Y';
            }else if (strcmp(ins_type,"198") == 0){
         	    f_198_exist = 'Y';
         	    f_1_9_exist = 'Y';
            }else if (strcmp(ins_type,"238") == 0){
         	    f_238_exist = 'Y';
         	    /*1101209008_SC1_�_�@�Ͻվ��ĳ��O���*/
         	    if(ISCAR_SET1(car_typei))
         	    {
         	    	if(fquota_62 == 'Y')
         	    	{
         	    	    if(ori_injured_cover < 30000 && ori_damage_cover < 150000)
         	    	    {
         	    	    	injured_cover = 30000;
         	    	        damage_cover = 150000;
         	    	    }
         	    	}
         	    }
            }else if (strcmp(ins_type,"255") == 0){
         	    f_255_exist = 'Y';
            }else if (strcmp(ins_type,"302") == 0){
         	    f_302_exist = 'Y';
            }else if (strcmp(ins_type,"176") == 0){
         	    f_176_exist = 'Y';
            }else if (strcmp(ins_type,"177") == 0){
         	    f_177_exist = 'Y';
            }else if (strcmp(ins_type,"178") == 0){
         	    f_178_exist = 'Y';
         	  }else if (strcmp(ins_type,"530") == 0){
         	    f_530_exist = 'Y';
         	    deduct_530 = deduct;
         	  }else if (strcmp(ins_type,"531") == 0){
         	    f_531_exist = 'Y';
         	    injured_cover31 = injured_cover;
         	    injured_cover31_ori = ori_injured_cover;
         	  }else if (strcmp(ins_type,"532") == 0){
         	    f_532_exist = 'Y';
         	    damage_cover32 = damage_cover;
         	    damage_cover32_ori = ori_damage_cover;
         	  }else if (strcmp(ins_type,"555") == 0){
         	    f_555_exist = 'Y';
         	  }else if (strcmp(ins_type,"561") == 0){
         	    f_561_exist = 'Y';
         	  }else if (strcmp(ins_type,"562") == 0){
         	    f_562_exist = 'Y';
         	  }else if (strcmp(ins_type,"563") == 0){
         	    f_563_exist = 'Y';
            }

            /*  �� **************  ������ �h�~����O���I�� Insert_INS_TYPE() ������  ***************  �� */

            /*     �N�h�~����O���I�ءA��"��ĳ��O�զX" �� "��l��O�զX"
                    Insert �� structure INS_TYPE�A1,5,8,9,85,11,31,32�I����b�e�� */
            strcpy(ins_type_ttmp,ins_type);
            strcpy(ins_type_ttmp,trim(ins_type_ttmp));
            dinstype=atoi(ins_type_ttmp);
            if( dinstype==1 || dinstype==5 || dinstype==8 || dinstype==9 ||
                dinstype==85 || dinstype==98 || dinstype==105 || dinstype==11 ||
                dinstype==31 || dinstype==32 || dinstype==77 || dinstype==78 ||
                dinstype==118 || dinstype==120 || dinstype==122 || dinstype==131 ||
                dinstype==132 ||  dinstype==113 || dinstype==114 || dinstype==125 ||
                dinstype==126 || dinstype==129 || dinstype==133 || dinstype==134 ||
                dinstype==149 || dinstype==86 || dinstype==181 || dinstype==198 ||
                dinstype==201 || dinstype==205 || dinstype==209 || dinstype==211 ||
                dinstype==231 || dinstype==232 || dinstype==249 || dinstype==331 ||
                dinstype==332 || dinstype==531 || dinstype==532)
            {
                /*** ins_type=01,11,31,32  should insert in front of the link list **/
                strcpy(ori_ins_type, ins_type);
                strcpy(ori_ins_type,trim(ori_ins_type));
                /*ori_ins_type[2] ='\0';*/

                #ifdef PRINTF_FLAG
                printf("\n6472: insert into ori_iins_type[%s]\n", ori_ins_type );
                #endif

                /*950822,�ѩ� qday �L�k�Ϥ���ĳ�զX�έ��O�զX, �G���ƥ����*/
                qday_bak = qday;

                /* 980310, �s�O�v�W�u, ��������[�ȫ� */
                /* 951127 ,�W��(fSunLi)*/
                /* 951107 ,�ΫH(A23*)  */
                /* 950831 ,�x���Υ�(A21*)�B���p(A11*) ==> ���O�զX�]�n�[�O�[�ȫ� */

                if (! Insert_INS_TYPE(ori_ins_type, ori_injured_cover, ori_death_cover,
                                  ori_damage_cover, ori_deduct, ins_premium,0,
                                  pagent,pcommission,frate,pdiscount,(long)mprem,
                                  qday,mexpense,provision,pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,0))
                {
                    #ifdef PRINTF_FLAG
                    printf("malloc fail in struct INS_TYPE allocation!\n");
                    #endif

                   $CLOSE CUR_5;
                   $FREE CUR_5;
                   memset(err_buf,0,sizeof(err_buf));
                   strcpy(err_buf,"Get302Data()8:");
                   strcat(err_buf,last_ply);
                   strcat(err_buf,"-");
                   strcat(err_buf,ins_type);
                   EWRITE(userid,M_CM_NOT_MALLOC,err_buf);
                   return M_CM_NOT_MALLOC;
                }

                Icurr->qserial=qserial;
                Icurr->qday=qday;

                #ifdef PRINTF_FLAG
                printf("ins_type_ttmp[%s]\n",ins_type_ttmp);
                printf("\ninsert into iins_type_ttmp[%s]\n", ins_type_ttmp );
                #endif

                /* 980310, �s�O�v�W�u, ��������[�ȫ� */
                /* 951127 ,�W��(fSunLi)*/
                /* 951107 ,�ΫH(A23*)  */
                /* 950831 ,�έ�(A09*)  ==> ��ĳ��O�զX�n�[�O�[�ȫ�   */
                /* 950831 ,�x���Υ�(A21*)�B���p(A11*)==> ��ĳ�զX�έ��O�զX���[�O�[�ȫ� */
                /* 950804, ���סB���q  ==> ��ĳ��O�զX�n�[�O�[�ȫ�   */

                if (! Insert_INS_TYPE(ins_type_ttmp, injured_cover, death_cover,
                                      damage_cover, deduct, ins_premium,0,
                                      pagent,pcommission,frate,pdiscount,(long)mprem,qday,mexpense,provision,pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1))
                {
                   #ifdef PRINTF_FLAG
                      printf("malloc fail in struct INS_TYPE allocation!\n");
                   #endif

                   $CLOSE CUR_5;
                   $FREE CUR_5;
                   memset(err_buf,0,sizeof(err_buf));
                   strcpy(err_buf,"Get302Data()8:");
                   strcat(err_buf,last_ply);
                   strcat(err_buf,"-");
                   strcat(err_buf,ins_type);
                   EWRITE(userid,M_CM_NOT_MALLOC,err_buf);
                   return M_CM_NOT_MALLOC;
                }
                Icurr->qserial=qserial;
                Icurr->qday=qday;
            }
            else
            {
                /*  �� �N�h�~����O���I�ءA��"��ĳ��O�զX" �� "��l��O�զX"
                     Insert �� structure INS_TYPE( ���q�� 1,5,8,9,85,11,31,32�I�H�~���I�� )*/
                strcpy(ins_type_ttmp,ins_type);
                strcpy(ins_type_ttmp,trim(ins_type_ttmp));
                /*ins_type_ttmp[2] = '\0';*/

                #ifdef PRINTF_FLAG
                printf("ins_type_ttmp[%s]\n",ins_type_ttmp);
                printf("\ninsert into iins_type_ttmp[%s] ", ins_type_ttmp );
                printf("damage_cover[%d]\n", damage_cover );
                printf("injured_cover[%d]\n", injured_cover );
                #endif


                if (! Insert_INS_TYPE(ins_type_ttmp, injured_cover, death_cover,
                                  damage_cover, deduct, ins_premium,0,
                                  pagent,pcommission,frate,pdiscount,
                                  (long)mprem,qday,mexpense,provision,
                                  pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1))
                {
                    #ifdef PRINTF_FLAG
                    printf("malloc fail in struct INS_TYPE allocation!\n");
                    #endif

                    $CLOSE CUR_5;
                    $FREE CUR_5;
                    memset(err_buf,0,sizeof(err_buf));
                    strcpy(err_buf,"Get302Data()8:");
                    strcat(err_buf,last_ply);
                    strcat(err_buf,"-");
                    strcat(err_buf,ins_type);
                    EWRITE(userid,M_CM_NOT_MALLOC,err_buf);
                    return M_CM_NOT_MALLOC;
                }
                Icurr->qserial=qserial;
                Icurr->qday=qday;

								if(( dinstype==34)||( dinstype==87)||( dinstype==115)){
                    /* 960612, ex. ���ݪ��I34���t�~�B�z  ------------------------  */
		    						/* Insert_PLY_INS_COVER => ��ĳ��O�զX(suggest =1 ) */
                    for( i=1; i<=INS_COVER_NUM; i++)
		    						{
                        if (i==1){
												    strcpy(icover_type_tmp,"001");
												    strcpy(iprem_cover_type_tmp,"001");
												    mcover_tmp = injured_cover;   /* �C�@�H���|���ݪ�   */
												}else if (i==2){
												    strcpy(icover_type_tmp,"002");
												    strcpy(iprem_cover_type_tmp,"001");
												    mcover_tmp = damage_cover1;   /* �C�@�ƬG���|���ݪ�  */
												}else if (i==3){
												    strcpy(icover_type_tmp,"003");
												    strcpy(iprem_cover_type_tmp,"003");
												    mcover_tmp = death_cover;     /* �C�@�H���G���ݪ�   */
												}else if (i==INS_COVER_NUM){
												    strcpy(icover_type_tmp,"004");
												    strcpy(iprem_cover_type_tmp,"003");
												    mcover_tmp = damage_cover;    /* �C�@�ƬG���G���ݪ�  */
                        }
				                #ifdef PRINTF_FLAG
				                printf(" ------- icover_type_tmp = [%s]\n " , icover_type_tmp);
				                printf(" ------- mcover_tmp      = [%ld]\n " , mcover_tmp);
                        #endif
		        						Insert_PLY_INS_COVER(ins_type_ttmp," ", " ",icover_type_tmp,
		                             iprem_cover_type_tmp, mcover_tmp, 0, 0, 0,
		                             0.00, 0, 0, 0, 0.00, 0.00 ,1);
		    						}
                    #ifdef PRINTF_FLAG
		    							printf("\n\n****** struct PLY_INS_COVER(��ĳ��O) ********\n");
		    						#endif

				            /* 960612, ���ݪ��I34 */
				            /*if( insurance_cover_count != 0)	 ply_ins_cover ����� */
                    INS_ptrPlyInsCover1 = IfirstPlyInsCover1;
		    						while(INS_ptrPlyInsCover1)
		    						{
                        #ifdef PRINTF_FLAG
                        printf("---------------------------------------------------------\n");
                        printf("�I�إN��		�Giins_type[%s] \n", INS_ptrPlyInsCover1->iins_type);
                        printf("�O�B����		�Gcover_name[%s] \n", INS_ptrPlyInsCover1->cover_name);
                        printf("�O�B�C�L�W��	�Gprint_name[%s] \n", INS_ptrPlyInsCover1->print_name);
                        printf("�O�B����		�Gicover_type[%s] \n", INS_ptrPlyInsCover1->icover_type);
                        printf("��m�O�O���O�B�����Giprem_cover_type[%s] \n", INS_ptrPlyInsCover1->iprem_cover_type);

                        printf("�O�B			�Gmcover[%ld] \n", INS_ptrPlyInsCover1->mcover);
                        printf("ñ��O�O		�Gmcover_prem[%ld] \n", INS_ptrPlyInsCover1->mcover_prem);
                        printf("����			�Gmdiscount[%ld] \n", INS_ptrPlyInsCover1->mdiscount);
                        printf("�W���O�O		�Gmprem[%ld] \n", INS_ptrPlyInsCover1->mprem);
                        printf("�«O�O			�Gmpure_prem[%f] \n", INS_ptrPlyInsCover1->mpure_prem);

                        printf("�D�A�Ψ���ñ��O�O�Gmcover_prem_n[%ld] \n", INS_ptrPlyInsCover1->mcover_prem_n);
                        printf("�D�A�Ψ�������	�Gmdiscount_n[%ld] \n", INS_ptrPlyInsCover1->mdiscount_n);
                        printf("�D�A�Ψ����W���O�O�Gmprem_n[%ld] \n", INS_ptrPlyInsCover1->mprem_n);
                        printf("�D�A�Ψ����«O�O�Gmpure_prem_n[%f] \n", INS_ptrPlyInsCover1->mpure_prem_n);
                        printf("���[�O�βv		�Gpextra_charge[%f] \n", INS_ptrPlyInsCover1->pextra_charge);
                        printf("---------------------------------------------------------\n");
                        #endif
                        INS_ptrPlyInsCover1= INS_ptrPlyInsCover1->next;
		    						}
                    /* �p��O�O */
								    short_prate_tmp = 1.0 ;
								    mdiscount_tmp   = 0 ;
								    adjust_rate_tmp = 0.0;

                    /********** 100.06.27,�q���N���ĤG���q *****************/
                    /* 1.�����g���N�� ibroker�A��γq���N�� iroute         */
                    /* 2.����¾�ΥN�� icorp                                */
                    /* ps.�M�ץ��O��W�O�����q���N���DA�椧�q���N��      */
                    /*******************************************************/
                    ibroker[0]=' '; ibroker[1]='\0';

                    /********** 100.06.27,�q���N���ĤG���q *****************/
                    /* �����g���N�� ibroker�A��γq���N�� iroute           */
                    /* ���s�W�ǤJ�ѼơA�䤤v_fstart = "Y" , ibroker=" "    */
                    /*(iofficer�u���bv_fstart<>"Y"�Bv_fstart<>"N" �ɤ~�Ψ�)*/
                    /*******************************************************/

                    /* 97.11�J�O�v�ۥѤ�  ,add ibroker */
		    						strcpy(sInstype, "");
		    						/* �t�Xcal_ply_ins_cover()�s�W�Ѽ� qply_period �O��O�� add by sylvia(1030407005_C4)  */
                    rtncode = cal_ply_ins_cover( &dinstype, IfirstPlyInsCover1, car_typei, frate,
                                            &short_prate_tmp, "", fdiscount, "", mdiscount_tmp,
                                            &pdiscount, "",&adjust_rate_tmp,0.0,ibroker,0.0,0.0,0.0,0.0,
                                            "Y",iofficer,iroute, irate_type,iroute_comm,bzfrom,"P",
                                            qply_period,v_sMsg);
                    if(rtncode != M_CM_OK) {
                    		if (rtncode==M_CA_34_1_NOT_FOUND){
		            				/* $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,'34','cal_ply_ins_cover()1','1');  */
		            						strcpy(sInstype,itoa(dinstype));
		            						$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine, $sInstype,'�I��cal_ply_ins_cover()���~1','1','E39',$iofficer);
		            						goto end;
				        				}else if (rtncode==M_CA_34_2_NOT_FOUND){
				            				strcpy(sInstype,itoa(dinstype));
				            				$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine, $sInstype,'�I��cal_ply_ins_cover()���~1','1','E39',$iofficer);
				            				goto end;
				        				}else{
				            				return rtncode;
				        				}
		    						}
								    #ifdef PRINTF_FLAG
								    printf("end of PLY_INS_COVER(��ĳ��O)\n");
								    #endif
                }

                if( strcmp(ins_type,"21")!=0)
                {
                    /** �j��ݼg�J **/
                    /** ���O�զX���O�B **/
                    strcpy(ori_ins_type, ins_type);
                    strcpy(ori_ins_type,trim(ori_ins_type));
                    /*ori_ins_type[2] ='\0';*/

                    #ifdef PRINTF_FLAG
                    printf("\n 6709insert into ori_iins_type[%s] ", ori_ins_type );
                    printf("ori_injured_cover[%d]\n", ori_injured_cover);
                    printf("ori_death_cover[%d]\n", ori_death_cover);
                    printf("ori_damage_cover[%d]\n", ori_damage_cover);
                    #endif

                    if (! Insert_INS_TYPE(ori_ins_type, ori_injured_cover, ori_death_cover,
                                     ori_damage_cover, ori_deduct, ins_premium,0,
                                     pagent,pcommission,frate,pdiscount,(long)mprem,qday,mexpense,provision,pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,0))
                    {
                        #ifdef PRINTF_FLAG
                        printf("malloc fail in struct INS_TYPE allocation!\n");
                        #endif

                        $CLOSE CUR_5;
                        $FREE CUR_5;
                        memset(err_buf,0,sizeof(err_buf));
                        strcpy(err_buf,"Get302Data()8:");
                        strcat(err_buf,last_ply);
                        strcat(err_buf,"-");
                        strcat(err_buf,ins_type);
                        EWRITE(userid,M_CM_NOT_MALLOC,err_buf);
                        return M_CM_NOT_MALLOC;
                    }

                    Icurr->qserial=qserial;
                    Icurr->qday=qday;

                    if(( dinstype==34)||( dinstype==87)||( dinstype==115)){
                        /* 960612, ex. ���ݪ��I34���t�~�B�z  ------------------------  */
												/* Insert_PLY_INS_COVER => ���O�զX(suggest =0 ) */
												for( i=1; i<=INS_COVER_NUM; i++)
												{
									                            if (i==1){
												        strcpy(icover_type_tmp,"001");
													strcpy(iprem_cover_type_tmp,"001");
													mcover_tmp = ori_injured_cover;  /* �C�@�H���|���ݪ�    */
												    }else if (i==2){
													strcpy(icover_type_tmp,"002");
													strcpy(iprem_cover_type_tmp,"001");
													mcover_tmp = ori_damage_cover1;  /* �C�@�ƬG���|���ݪ�  */
												    }else if (i==3){
													strcpy(icover_type_tmp,"003");
													strcpy(iprem_cover_type_tmp,"003");
													mcover_tmp = ori_death_cover;    /* �C�@�H���G���ݪ�    */
												    }else if (i==INS_COVER_NUM){
													strcpy(icover_type_tmp,"004");
													strcpy(iprem_cover_type_tmp,"003");
													mcover_tmp = ori_damage_cover;   /* �C�@�ƬG���G���ݪ�  */
											            }
									                            Insert_PLY_INS_COVER(ins_type_ttmp," ", " ",icover_type_tmp,iprem_cover_type_tmp,
													                 mcover_tmp, 0, 0, 0, 0.00, 0, 0, 0, 0.00, 0.00 ,0);
												}

												#ifdef PRINTF_FLAG
												printf("\n\n****** struct PLY_INS_COVER(���O) ********\n");
												#endif

												INS_ptrPlyInsCover = IfirstPlyInsCover;
												while(INS_ptrPlyInsCover)
												{
									                            #ifdef PRINTF_FLAG
												    	printf("---------------------------------------------------------\n");
												    	printf("�I�إN��		�Giins_type[%s] \n", INS_ptrPlyInsCover->iins_type);
									   			    printf("�O�B����		�Gcover_name[%s] \n", INS_ptrPlyInsCover->cover_name);
									   			    printf("�O�B�C�L�W��	�Gprint_name[%s] \n", INS_ptrPlyInsCover->print_name);
									   			    printf("�O�B����		�Gicover_type[%s] \n", INS_ptrPlyInsCover->icover_type);
									   			    printf("��m�O�O���O�B�����Giprem_cover_type[%s] \n", INS_ptrPlyInsCover->iprem_cover_type);
									   			    printf("�O�B			�Gmcover[%ld] \n", INS_ptrPlyInsCover->mcover);
									   			    printf("ñ��O�O		�Gmcover_prem[%ld] \n", INS_ptrPlyInsCover->mcover_prem);
									   			    printf("����			�Gmdiscount[%ld] \n", INS_ptrPlyInsCover->mdiscount);
									   			    printf("�W���O�O		�Gmprem[%ld] \n", INS_ptrPlyInsCover->mprem);
									   			    printf("�«O�O			�Gmpure_prem[%f] \n", INS_ptrPlyInsCover->mpure_prem);

									   			    printf("�D�A�Ψ���ñ��O�O�Gmcover_prem_n[%ld] \n", INS_ptrPlyInsCover->mcover_prem_n);
									   			    printf("�D�A�Ψ�������	�Gmdiscount_n[%ld] \n", INS_ptrPlyInsCover->mdiscount_n);
									   			    printf("�D�A�Ψ����W���O�O�Gmprem_n[%ld] \n", INS_ptrPlyInsCover->mprem_n);
									                            printf("�D�A�Ψ����«O�O�Gmpure_prem_n[%f] \n", INS_ptrPlyInsCover->mpure_prem_n);
									   			    printf("���[�O�βv		�Gpextra_charge[%f] \n", INS_ptrPlyInsCover->pextra_charge);
									   			    printf("---------------------------------------------------------\n");
												    	#endif

												    	INS_ptrPlyInsCover= INS_ptrPlyInsCover->next;
												}

                        /* �p��O�O */
                        short_prate_tmp = 1.0 ;
                        mdiscount_tmp   = 0 ;
                        adjust_rate_tmp = 0.0;

                        /********** 100.06.27,�q���N���ĤG���q *****************/
                        /* �����g���N�� ibroker�A��γq���N�� iroute           */
                        /* ���s�W�ǤJ�ѼơA�䤤v_fstart = "Y" , ibroker=" "    */
                        /*(iofficer�u���bv_fstart<>"Y"�Bv_fstart<>"N" �ɤ~�Ψ�)*/
                        /*******************************************************/

                        /* �p��O�O *//* 97.11�J�O�v�ۥѤ�  ,add ibroker */
												strcpy(sInstype, "");
										    /* �t�Xcal_ply_ins_cover()�s�W�Ѽ� qply_period �O��O�� add by sylvia(1030407005_C4)  */
									      rtncode = cal_ply_ins_cover(&dinstype, IfirstPlyInsCover, car_typei, frate,
									                                  &short_prate_tmp, "", fdiscount, "", mdiscount_tmp,
									                                  &pdiscount, "",&adjust_rate_tmp,0.0,ibroker,0.0,0.0,0.0,0.0,
									                                  "Y",iofficer,iroute, irate_type,iroute_comm,bzfrom,"P",
									                                  qply_period,v_sMsg);
												if(rtncode != M_CM_OK) {
														if (rtncode==M_CA_34_1_NOT_FOUND){
												        /* $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,'34','cal_ply_ins_cover()2','1'); */
												        strcpy(sInstype, itoa(dinstype));
												        $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$sInstype,'�I��cal_ply_ins_cover()���~2','1','E39',$iofficer);
												        goto end;
												    }else if (rtncode==M_CA_34_2_NOT_FOUND){
												        strcpy(sInstype, itoa(dinstype));
												        $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$sInstype,'�I��cal_ply_ins_cover()���~2','1','E39',$iofficer);
												        goto end;
												    }else{
												        return rtncode;
												    }
												}
										}
								}
            }
            /*  �� **************  ������ �h�~����O���I�� Insert_INS_TYPE() ������  ***************  �� */
        } /*(while)*/
        $CLOSE CUR_5;
        $FREE CUR_5;

      	/********** 100.06.27,�q���N���ĤG���q *****************/
      	/* 1.�����g���N�� ibroker�A��γq���N�� iroute         */
      	/* 2.����¾�ΥN�� icorp                                */
      	/* ps.�M�ץ��O��W�O�����q���N���DA�椧�q���N��      */
      	/*******************************************************/
      	ibroker[0]=' '; ibroker[1]='\0';

	      /* 97.11�J�O�v�ۥѤ�                                         */
	      /*        �g��N�� => �g���N�� => �g���s�եN�� => ���[�O�βv */
	      /*-----------------------------------------------------------*/
	      pextra_charge = pextra_charge131 = pextra_charge125 = 0.00;
	      pbusiness     = 0.00;

      	/* 980310, �O�v�ۥѤ�, ����O��Y���i¾�Υ�j�Ρi���u��j:
        	�Y������v20%(�t)�H�W�A�h�H�����~��(090)(�g��N��(���s)��A)���s��O��F
         	�Y������v�p��20%�A�h�H�~�ȭ�(000)���s��O��C */

      	/*100.06.27,�q���N���ĤG���q iextra_charge �Y=> bzfrom */
      	strcpy(iextra_charge, bzfrom);

	      #ifdef PRINTF_FLAG
	         printf("iextra_charge[%s],tmp_frate2=[%s]\n", iextra_charge,tmp_frate2 );
	      #endif

	      INS_ptr=Ifirst;
	      while(INS_ptr)
	      {
	         #ifdef PRINTF_FLAG
	         printf("oo--ins_type[%s]\n",INS_ptr->ins_type);
	         printf("oo--iroute[%s]\n",iroute);
	         #endif

         	/* ���[�O�βv (110.02.04) */
         	/* get_cm_extra_charge_car()�s�W�@�ӰѼơG�q���N��(iroute) modify by 061476 (1090916003_SC5) */
         	/* �אּ�v�I��Ū�����[�O�βv modify by 061476 (1100201009_SC1) */

	         strcpy(tp_iins_type_tmp,trim(INS_ptr->ins_type));
	       	 tp_ins_type = atoi(tp_iins_type_tmp);
	       	 rc = get_cm_extra_charge_car( iextra_charge, tmp_frate2, &pextra_charge, &pbusiness, qply_period, tp_ins_type, iroute, v_sMsg);
	       	 if( rc != M_CM_OK){
	       	 		sprintf(tMsg,"���[�O�βv�N��(%s)�L���������[�O�βv",iextra_charge);
	       	 		$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$iroute,$tMsg,'1','E11',$iofficer);
       	 	}

	       #ifdef PRINTF_FLAG
	       printf("pextra_charge[%f], pbusiness=[%f]\n", pextra_charge, pbusiness );
	       #endif

       	INS_ptr->pextra_charge    = pextra_charge;
	 			INS_ptr->pbusiness        = pbusiness;

			  /* �������[�O�Y��  add by sylvia 104.11.25 (1021211003_C1) */
			  if ((fhi_price == 'Y') &&
			     ((strcmp(trim(INS_ptr->ins_type),"01") == 0)|| (strcmp(trim(INS_ptr->ins_type),"05") == 0)||
			      (strcmp(trim(INS_ptr->ins_type),"09") == 0)|| (strcmp(trim(INS_ptr->ins_type),"85") == 0)||
			      (strcmp(trim(INS_ptr->ins_type),"105") == 0)|| (strcmp(trim(INS_ptr->ins_type),"118") == 0)||
			      (strcmp(trim(INS_ptr->ins_type),"120") == 0)|| (strcmp(trim(INS_ptr->ins_type),"122") == 0)||
			      (strcmp(trim(INS_ptr->ins_type),"125") == 0)|| (strcmp(trim(INS_ptr->ins_type),"126") == 0)||
			      (strcmp(trim(INS_ptr->ins_type),"07") == 0)|| (strcmp(trim(INS_ptr->ins_type),"10") == 0)||
			      (strcmp(trim(INS_ptr->ins_type),"127") == 0)||(strcmp(trim(INS_ptr->ins_type),"201") == 0)||
			      (strcmp(trim(INS_ptr->ins_type),"205") == 0)||(strcmp(trim(INS_ptr->ins_type),"209") == 0)))
		        {
			        INS_ptr->pcar_price  = hi_car_price;
		        }
		        INS_ptr= INS_ptr->next;
				}

	      #ifdef PRINTF_FLAG
	      printf(" ------- last_ply = [%s]\n " , last_ply);
	      printf(" ------- iplyyear=[%d],iplymonth=[%d]\n ",iplyyear,iplymonth);
	      printf(" ------- f_1_9_exist = [%c]\n " , f_1_9_exist);
	      printf(" ------- car_typei = [%s]\n " , car_typei);
	      printf(" ------- iofficer[0] = [%c]\n " , iofficer[0]);
	      #endif

	      /* 101.06.25 */
	      if (f_provision_D == 1) {
	         if (strlen(trim(remark1))>10){
		  	      strcpy(remark6,"����O�n�O�ѫO�O���]�t�u���w�r�p�H���[���ڡv,�Э��s�ӽЮ֭��l�i���[");
			  	}else{
			  	   strcpy(remark1,"����O�n�O�ѫO�O���]�t�u���w�r�p�H���[���ڡv,�Э��s�ӽЮ֭��l�i���[");
					}
      	}

	      if (f_provision_J == 1) {
	         if (strlen(trim(remark1))>10){
		  	      strcpy(remark6,"����O�n�O�ѫO�O���]�t�u����~�S�w�γ~�ΩT�w�ϥΤH���[���ڡv,�Э��s�ӽЮ֭��l�i���[");
			  	}else{
			  	   strcpy(remark1,"����O�n�O�ѫO�O���]�u����~�S�w�γ~�ΩT�w�ϥΤH���[���ڡv,�Э��s�ӽЮ֭��l�i���[");
					}
	      }

	      /* 104.11.05 ����������w���� */
	      if (f_provision_R == 1) {
	         if (strlen(trim(remark1))>10){
		  	      strcpy(remark6,"�A�ηs�w�F�ʮ��W��������������w�ϥΪ��[����");
			  	}else{
			  	   strcpy(remark1,"�A�ηs�w�F�ʮ��W��������������w�ϥΪ��[����");
					}
	      }

	      #ifdef PRINTF_FLAG
	      INS_ptr=Ifirst;
	      while(INS_ptr)
	      {
	          printf("xx--ins_type[%s]\n",INS_ptr->ins_type);
	          printf("xx--provision[%s]\n",INS_ptr->provision);
	          printf("xx--pcar_price[%f]\n",INS_ptr->pcar_price);
	          printf("xx--sug_iins_type[%d]\n",INS_ptr->sug_iins_type);
	          INS_ptr= INS_ptr->next;
	      }
	      #endif

	      /* �s�W ���ľ��c�r�p�H�ˮ`�I(136) add by sylvia 104.06.02 (1040407003_C6) */
	      /* �s�W �ĤT�H���[�r�p�H�ˮ`(�����D)(166) add by 061476 108.03.14 (1080225007_SC3) */
	      /* �s�W���ΧP�_��窱�p modify by 061476 109.05.04 (1090221006_SC3)*/
	      /* �B�z���q�H���NULL�ȱ��p modify by 061476 109.06.11 (1090221006_SC9) */
	      /* �B�z��窱�pNULL�ȱ��p modify by 061476 110.08.31 (1100820012_SC1) */
	      /* �s�W266�I�� (1110308005_SC3)*/
	      if ((ins56_flag == 1) || (ins136_flag == 1) || (ins166_flag == 1) || (ins266_flag == 1))
	      {
         	stmt[0]='\0';
         	sprintf(stmt, "SELECT %s %s %s %s %s %s %s %s %s %s FROM %s WHERE %s %s %s %s",
                       				" iins_type,iinsurant, ninsurant, ",
                       				" dbirth, ainsurant, ",
                       				" iins_scope, icareer, ",
                       				" mins_amt, mins_premium, ",
                       				" pdiscount, mdiscount, ",
                       				" napplicant, relation_appl, ",
                       				" nbeneficiary, relation_bene, ",
                       				" dbirth, ",
                       				" daily_pay, mr_ins_prem, mr_pure_prem, ",
                       				" nvl(tbenef,''), nvl(abenef_zip,''), nvl(abenef,'') ",
                       				" ca_pa_ply_last ",
                       				" ipolicy = ? ",
                       				" AND mins_amt > 0 AND iins_type in ('56','136','166','266') ",
                       				" AND nvl(fedr_status,'') not in ('1','2','3') ",
                      				 "order by mins_premium desc ");
                       /*" AND (fedr_status NOT IN ('1','2','3') OR nvl(fedr_status,' ') = ' ') AND mins_amt > 0 AND iins_type = '56'");*/
					printf("9041 Trace -- stmt = [%s] \n",  stmt);
         	printf("9042 last_ply[%s]\n",last_ply);
         	$PREPARE CURstm56 FROM $stmt;
         	$DECLARE OPT1_56  CURSOR FOR CURstm56;
         	$OPEN    OPT1_56  USING $last_ply;
         	#ifdef PRINTF_FLAG
            printf("Trace -- stmt = [%s] \n",  stmt);
            printf("last_ply[%s]\n",last_ply);
         	#endif
         	while (1)
         	{
          	$FETCH OPT1_56 INTO $sIns_tmp,      $cIinsurant,    $cNinsurant,
                                $lDbirth,       $cAinsurant,
                                $cIins_scope,   $cIcareer,
                                $lMins_amt,     $lMins_premium,
                                $dPdiscount,    $lMdiscount,
                                $cNapplicant,   $cRelation_appl,
                                $cNbeneficiary, $cRelation_bene,
                                $birth33,
                                $pre_daily_pay, $lMr_ins_prem,  $lMr_pure_prem,
                                $cTbenef,       $cAbenef_zip,   $cAbenef;
            if (NOT_FOUND) break;

            /* Need FIX:���t�Xline:6211�ק�H�ηs�W���B����ĳ�έ�l��O��� */
            /* if (lMins_amt<3000000){
                  lDaily_pay=1000;
               }
               if(lDaily_pay<1000){
                  $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,'56','56�I���|���B�p�� 1000','1');
               }*/

            /* 980416 */
            /* 56�O�B����lMins_amt,�u�� ply_ins_type.mdamage_cover */
            if (! Insert_INS_TYPE_33(cIinsurant, cNinsurant,
                                     lDbirth, cAinsurant,
                                     cIins_scope, cIcareer,
                                     lMins_amt, lMins_premium,
                                     (double)0, 0,
                                     (double)0, 0,
                                     dPdiscount, lMdiscount,
                                     cNapplicant, cRelation_appl,
                                     cNbeneficiary, cRelation_bene,
                                     lDaily_pay, lMr_ins_prem,
                                     lMr_pure_prem,sIns_tmp,
                                     cTbenef,cAbenef_zip,cAbenef,1))
            {
               $CLOSE OPT1_56;
               $FREE  OPT1_56;
               return M_CM_NOT_MALLOC;
            }

            /* 960528 ,56�������i�����]�w => dPdiscount, lMdiscount */
            if (! Insert_INS_TYPE_33(cIinsurant, cNinsurant,
                                     lDbirth, cAinsurant,
                                     cIins_scope, cIcareer,
                                     lMins_amt, lMins_premium,
                                     (double)0, 0,
                                     (double)0, 0,
                                     dPdiscount, lMdiscount,
                                     cNapplicant, cRelation_appl,
                                     cNbeneficiary, cRelation_bene,
                                     ori_lDaily_pay, lMr_ins_prem,
                                     lMr_pure_prem,sIns_tmp,
                                     cTbenef,cAbenef_zip,cAbenef,0))
            {
               $CLOSE OPT1_56;
               $FREE  OPT1_56;
               return M_CM_NOT_MALLOC;
            }
         }
         $CLOSE OPT1_56;
         $FREE  OPT1_56;
      }

      if (ins35_flag == 1)
      {
         stmt[0]='\0';
         sprintf(stmt, "SELECT %s %s %s %s %s %s %s %s %s %s FROM %s WHERE %s %s",
                       " iinsurant, ninsurant, ",
                       " dbirth, ainsurant, ",
                       " iins_scope, icareer, ",
                       " mins_amt, mins_premium, ",
                       " pdiscount, mdiscount, ",
                       " napplicant, relation_appl, ",
                       " nbeneficiary, relation_bene, ",
                       " dbirth, ",
                       " daily_pay, mr_ins_prem, mr_pure_prem, ",
                       " nvl(tbenef,''), nvl(abenef_zip,''), nvl(abenef,'') ",
                       " ca_pa_ply_last ",
                       " ipolicy = ? ",
                       " AND mins_amt > 0 AND iins_type = '35'");
                       /*" AND (fedr_status NOT IN ('1','2','3') OR nvl(fedr_status,' ') = ' ') AND mins_amt > 0 AND iins_type = '35'");*/
         $PREPARE CURstm35 FROM $stmt;
         $DECLARE OPT1_35  CURSOR FOR CURstm35;
         $OPEN    OPT1_35  USING $last_ply;
         #ifdef PRINTF_FLAG
            printf("last_ply[%s]\n",last_ply);
         #endif
         while (1)
         {
            $FETCH OPT1_35 INTO $cIinsurant,    $cNinsurant,
                                $lDbirth,       $cAinsurant,
                                $cIins_scope,   $cIcareer,
                                $lMins_amt,     $lMins_premium,
                                $dPdiscount,    $lMdiscount,
                                $cNapplicant,   $cRelation_appl,
                                $cNbeneficiary, $cRelation_bene,
                                $birth33,
                                $lDaily_pay,    $lMr_ins_prem,  $lMr_pure_prem,
                                $cTbenef,       $cAbenef_zip,   $cAbenef;
            if (NOT_FOUND) break;

            if (! Insert_INS_TYPE_33(cIinsurant, cNinsurant,
                                     lDbirth, cAinsurant,
                                     cIins_scope, cIcareer,
                                     lMins_amt, lMins_premium,
                                     (double)0, 0,
                                     (double)0, 0,
                                     (double)0, 0,
                                     cNapplicant, cRelation_appl,
                                     cNbeneficiary, cRelation_bene,
                                     lDaily_pay, lMr_ins_prem,
                                     lMr_pure_prem,"35",
                                     cTbenef,cAbenef_zip,cAbenef,0))
            {
               $CLOSE OPT1_35;
               $FREE  OPT1_35;
               return M_CM_NOT_MALLOC;
            }
         }
         $CLOSE OPT1_35;
         $FREE  OPT1_35;
      }

      if (ins48_flag == 1)
      {
         stmt[0]='\0';
         sprintf(stmt, "SELECT %s %s %s %s %s %s %s %s %s %s FROM %s WHERE %s %s",
                       " iinsurant, ninsurant, ",
                       " dbirth, ainsurant, ",
                       " iins_scope, icareer, ",
                       " mins_amt, mins_premium, ",
                       " pdiscount, mdiscount, ",
                       " napplicant, relation_appl, ",
                       " nbeneficiary, relation_bene, ",
                       " dbirth, ",
                       " daily_pay, mr_ins_prem, mr_pure_prem, ",
                       " nvl(tbenef,''), nvl(abenef_zip,''), nvl(abenef,'') ",
                       " ca_pa_ply_last ",
                       " ipolicy = ? ",
                       " AND mins_amt > 0 AND iins_type = '48'");
                        /*" AND (fedr_status NOT IN ('1','2','3') OR nvl(fedr_status,' ') = ' ') AND mins_amt > 0 AND iins_type = '48'");*/
         $PREPARE CURstm48 FROM $stmt;
         $DECLARE OPT1_48  CURSOR FOR CURstm48;
         $OPEN    OPT1_48  USING $last_ply;
         #ifdef PRINTF_FLAG
            printf("last_ply[%s]\n",last_ply);
         #endif
         while (1)
         {
            $FETCH OPT1_48 INTO $cIinsurant,       $cNinsurant,
                                $lDbirth,          $cAinsurant,
                                $cIins_scope,      $cIcareer,
                                $lMins_amt,        $lMins_premium,
                                $dPdiscount,       $lMdiscount,
                                $cNapplicant,      $cRelation_appl,
                                $cNbeneficiary,    $cRelation_bene,
                                $birth33,
                                $pre_daily_pay_48, $lMr_ins_prem,  $lMr_pure_prem,
                                $cTbenef,          $cAbenef_zip,   $cAbenef;
            if (NOT_FOUND) break;

            cm_split_ymd_100(cm_from_infdate_100(birth33),yy33,mm33,dd33);
            cm_split_ymd_100(tmp_dply_end_pre,dply_end_yy33,dply_end_mm33,dply_end_dd33);

            #ifdef PRINTF_FLAG
               printf("dply_end_mm33[%s]\n",dply_end_mm33);
               printf("mm33[%s]\n",mm33);
               printf("dply_begin[%ld]\n",dply_begin);
            #endif

            if (atoi(dply_end_mm33) < atoi(mm33))
               age33=atoi(cm_eyear_str(dply_begin))-1-(atoi(yy33)+1911);
            else
               age33=atoi(cm_eyear_str(dply_begin))-(atoi(yy33)+1911);

            if (age33 < 0)  age33 = 0;

            if (strncmp(dply_end_mm33,mm33,2) == 0)
            {
               if (atoi(dd33) > atoi(dply_end_dd33))
               {
                  age33 = age33 - 1;
               }
            }

            #ifdef PRINTF_FLAG
               printf("age33[%d]\n",age33);
            #endif

            /*1101207003_SC2_�ק�48�I�W�U�ͤ�ݿ�J�ά����~���ˮ�*/
            if (((age33 < 18) || (age33 >= 30)) && (cRelation_appl[0] == '3' ))
            {
               /** 30���H�W�l�k���i�[�O **/
               Icurr_33=Ifirst_33;
               while (Icurr_33)
               {
                  if((strcmp(trim(Icurr_33->iins_type),"35")==0) &&
                     (strcmp(Icurr_33->cNinsurant, cIinsurant)==0))
                  {
                     strcpy(Icurr_33->iins_type,"**");
                     break;
                  }
                  Icurr_33=Icurr_33->next;
               }
            }
            else
            {
               /* 981208,*/
               lMins_amt = death_cover_pa_48  ;
               lDaily_pay= injured_cover_pa_48;

               if (! Insert_INS_TYPE_33(cIinsurant, cNinsurant,
                                        lDbirth, cAinsurant,
                                        cIins_scope, cIcareer,
                                        lMins_amt, lMins_premium,
                                        (double)0, 0,
                                        (double)0, 0,
                                        (double)0, 0,
                                        cNapplicant, cRelation_appl,
                                        cNbeneficiary, cRelation_bene,
                                        lDaily_pay, lMr_ins_prem,
                                        lMr_pure_prem,"48",
                                        cTbenef,cAbenef_zip,cAbenef,0))
               {
                  $CLOSE OPT1_48;
                  $FREE  OPT1_48;
                  return M_CM_NOT_MALLOC;
               }
            }
         }
         $CLOSE OPT1_48;
         $FREE  OPT1_48;
      }
      /* �q�ʨ��T�����ث�ĳ176�B177�B178�I�� (1130510009_C13) */
      if ((fBEV == 'Y')&&(!ISMOT(car_typei)))
      {
      	  if ((strncmp(iroute,"JB",2)==0)||(fbz_2131 == 'Y')||(iofficer[0]=='P')||
              ((fBarcode=='Y')&&(!(ISMOT(car_typei)))&&(strncmp(s_fcar_insure,"02",2)==0)) )  /* ��car147�]�w���q��, ���T���B �]�w�T���I����ĳ */
          {
          	/* �ŧ³q���ư�JB�B�O�o�q��21/31�B���ӥ��СBcar147�]�w����ĳ */
          }
          else
          {
          	if ((f_01_exist == 'Y' || f_05_exist == 'Y') && (f_176_exist == 'N'))
          	{
          		CarAgeMonth = 0;
          		CarAgeMonth = (iplyyear-atoi(pro_year))*12 + (iplymonth-qpro_month);
          		if (CarAgeMonth <= 96)
          		{
          			Insert_INS_TYPE("176", 0, 0, damage_cover , 10, 0, 0, 0.00, 0.00, frate, pdiscount, 0, 0, 0," ",pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,1);
          		}
          	}
          	if ((f_01_exist == 'Y' || f_05_exist == 'Y' || f_09_exist == 'Y') && (f_177_exist == 'N'))
          	{
          		Insert_INS_TYPE("177", 0, 0, damage_cover , 10, 0, 0, 0.00, 0.00, frate, pdiscount, 0, 0, 0," ",pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,1);
          	}
          	if ((f_31_exist == 'Y' || f_32_exist == 'Y' || f_149_exist == 'Y') && (f_178_exist == 'N'))
          	{
          		if (f_31_exist == 'Y' || f_32_exist == 'Y')
          			damage_cover178 = damage_cover31 + damage_cover32;
          		else
          			damage_cover178 = damage_cover149;

          		$select nvl(max(mcoverage1),0) into $mcover1_178
          		   from cover_vs_premium
          		  where iins_type ='178'
          		    and icar_type = $car_typei
          		    and mcoverage1 <= $damage_cover178
          		    and drate= (SELECT drate
          		                  FROM ca_rate_date
          		                 WHERE icode  = $frate
          		                   AND itable = 'cover_vs_premium');
          		if (mcover1_178 > 0)
          		{
          			Insert_INS_TYPE("178", mcover1_178, 0, mcover1_178*2 , 10, 0, 0, 0.00, 0.00, frate, pdiscount, 0, 0, 0," ",pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,1);
          		}
          	}
          }
      }

      /* ����31�B32�O�B<= 200/400/50�A�n��ĳ30�I�ضW�B500�U(�\���w�P���л����G�ۭt�B�@�ߵ�1) add by 061476 107.04.18 (1070129008_SC1)*/
      /* 30�I�ؼW�[���ŶZ�A�]���ۭt�B�ﵹ3 (1071203004_SC3) */
      if (strcmp(honda_sug_30,"Y")== 0)
      {
          deduct_30 = 3;
          Insert_INS_TYPE("30", 0, 0, 5000000 , deduct_30, 0, 0, 0.00, 0.00, frate, pdiscount, 0, 0, 0," ",pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,1);
      }

      /* 102.08.26: 05=>105�A�n�t�~�s�W�@��105*/
      /* �O�v�N��>=93 �H�ᨮ������T�J�`�A�@�߬�1 modity by 061476 107.03.26 */
      if ((ins1589_chg_flag == 2)||(ins1589_chg_flag == 3)) {
          if ((atoi(tmp_frate2)) >= 79)
	      			strcpy(funknown_dmg_sug,"1");   /* ��105/04/01�_(�O�v�N��>=79), �J�p85,105,118�ĥηs��) add by sylvia 105.03.16 (1050226003_C3) */
	  			else
	      /* strcpy(funknown_dmg_sug,"3"); */
	      strcpy(funknown_dmg_sug,"1");

          Insert_INS_TYPE("105", minjured_cover105_sug , 0, cover_E_last , 0, 0,0,
		          0.00,0.00,tmp_frate2,pdiscount,0,0,0,provision_E,pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
      }

      /* ����(B*)&�έ�(A09)�����ഫ��A��,���t�~�s�WA���ӫ~*/
      /* ins1589_chg_flag :05 ��118+119*/
      /*  �s�W�ഫ�����ӫO�N A01,A04,A10,A11,A21,A23,A25   add by sylvia 103.10.22 (1031016004_C1) */
      /* �s�W�ഫ������--���q(J*)   modify by sylvia (1040114008_C1) */
      /* �O�v�N��>=93 �H�ᨮ������T�J�`�A�@�߬�1 modity by 061476 107.03.26 */
      if ((ins1589_chg_flag == 5) || (ins1589_chg_flag == 6)){
          if (ins1589_chg_flag == 5)
	  			{
	      		if ((atoi(tmp_frate2)) >= 79)
	          	strcpy(funknown_dmg_sug,"1");   /* ��105/04/01�_(�O�v�N��>=79), �J�p85,105,118�ĥηs��) add by sylvia 105.03.16 (1050226003_C3) */
	      		else
	          	/* strcpy(funknown_dmg_sug,"3"); */
	          	strcpy(funknown_dmg_sug,"1");

       		}
          Insert_INS_TYPE("118", minjured_cover105_sug , 0, cover_E_last , 0, 0,0,
		          0.00,0.00,tmp_frate2,pdiscount,0,0,0,provision_E,pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
      	  Insert_INS_TYPE("119", 600 , 0, 600*3 , 0, 0,0,
		          0.00,0.00,tmp_frate2,pdiscount,0,3,0,provision_E,pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
      }
      if (ins1589_chg_flag == 7) {
            /*strcpy(funknown_dmg_sug,"2");*/   /* ��105/04/01�_(�O�v�N��>=79), �J�p85,105,118�ĥηs��) add by sylvia 105.03.16 (1050226003_C3) */
            strcpy(funknown_dmg_sug,"1");   /* �O�v�N��>=93 �H�ᨮ������T�J�`�A�@�߬�1 modity by 061476 107.03.26 */
            Insert_INS_TYPE("120", minjured_cover105_sug , 0, cover_E_last , deduct, 0,0,
		                      0.00,0.00,tmp_frate2,pdiscount,0,0,0,provision_E,pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
      	    Insert_INS_TYPE("121", 600 , 0, 600*3 , 0, 0,0,
		                      0.00,0.00,tmp_frate2,pdiscount,0,3,0,provision_E,pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
      }
      if (ins1589_chg_flag == 8) {
            strcpy(funknown_dmg_sug,"1");   /* ��105/04/01�_(�O�v�N��>=79), �J�p85,105,118�ĥηs��) add by sylvia 105.03.16 (1050226003_C3) */
            Insert_INS_TYPE("122", minjured_cover105_sug , 0, cover_E_last , deduct, 0,0,
		                      0.00,0.00,tmp_frate2,pdiscount,0,0,0,provision_E,pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
      	   Insert_INS_TYPE("123", 600 , 0, 600*3 , 0, 0,0,
		                      0.00,0.00,tmp_frate2,pdiscount,0,3,0,provision_E,pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
      }
      if (f_del_106 == 'Y')
      {
        Insert_INS_TYPE("67", minjured_cover_67_sug , 0, mdamage_cover_67_sug, 0, 0,0,
                  0.00,0.00,tmp_frate2,pdiscount,0,qday_67,0,' ',pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
        Insert_INS_TYPE("67", minjured_cover_67_sug , 0, mdamage_cover_67_sug, 0, 0,0,
                  0.00,0.00,tmp_frate2,pdiscount,0,qday_67,0,' ',pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,0);
      }
      if (f_del_107 == 'Y')
      {
        Insert_INS_TYPE("63", minjured_cover_63_sug , 0, mdamage_cover_63_sug, 0, 0,0,
                  0.00,0.00,tmp_frate2,pdiscount,0,0,0,' ',pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
        Insert_INS_TYPE("63", minjured_cover_63_sug , 0, mdamage_cover_63_sug, 0, 0,0,
                  0.00,0.00,tmp_frate2,pdiscount,0,0,0,' ',pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,0);
      }
      if (f_del_108 == 'Y')
      {
        Insert_INS_TYPE("65", 0 , 0, mdamage_cover_65_sug, 0, 0,0,
                  0.00,0.00,tmp_frate2,pdiscount,0,0,0,' ',pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
        Insert_INS_TYPE("65", 0 , 0, mdamage_cover_65_sug, 0, 0,0,
                  0.00,0.00,tmp_frate2,pdiscount,0,0,0,' ',pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,0);
      }

      /* �Y�h�~��O05+161+155�A�h�ഫ155->163 add by 061476 107.07.25 (1070625011_SC4) */
      if ((f_05_exist == 'Y') && (f_155_exist == 'Y') && (f_161_exist == 'Y'))
      {
    		Insert_INS_TYPE("163", minjured_cover_163_sug , 0, mdamage_cover_163_sug, 0, 0,0,
		                      0.00,0.00,tmp_frate2,pdiscount,0,qday_163,0,' ',pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
        Insert_INS_TYPE("163", minjured_cover_163_sug , 0, mdamage_cover_163_sug, 0, 0,0,
		                      0.00,0.00,tmp_frate2,pdiscount,0,qday_163,0,' ',pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,0);
				ins163_flag = 1;
      }

      /* 38�B39�I�ذ���A��O�ഫ��238�I��(1�U/5�U) add by 061476 110.03.31 (1100119001_SC3) */
      if ((f_del_38 == 'Y') || (f_del_39 == 'Y'))
      {
    		if (ISMOT(car_typei)) qday_238=30;
    		else qday_238=100;

        if (ISCAR_SET1(car_typei) && (fquota_62 == 'Y'))
        {
            /*1101209008_SC1_�_�@�Ͻվ��ĳ��O���*/
            Insert_INS_TYPE("238",30000,0,150000,0,0,0,0.00,0.00,
		            frate,pdiscount,0,qday_238,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
				}
				else
				{
            Insert_INS_TYPE("238",10000,0,50000,0,0,0,0.00,0.00,
		            frate,pdiscount,0,qday_238,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
				}

				Insert_INS_TYPE("238",10000,0,50000,0,0,0,0.00,0.00,
		              frate,pdiscount,0,qday_238,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,0);
			}

      /* 30�I�ئۭt�B��31/32�O�B�M�w�A���ӫO30�I�ءA31/32�I�ث�ĳ=���O add by 061476 107.12.04 (1071203004_SC3) */
      if (f_30_exist == 'Y')
      {
    		if ((injured_cover31 >= 2000000) && (damage_cover32 >= 500000)){
    			deduct30[0] = '3';
    		}else if ((injured_cover31 >= 700000) && (damage_cover32 >= 200000)){
    			deduct30[0] = '1';
    		}else{
    			deduct30[0] = '2';
    		}
    		deduct_30 = atoi(deduct30);

    		/* �]30�I�ؤ��Ű��D�A�����Ұϰw����O�զX���վ� (1080308004_SC1) */
    		chg_ori_flag = 0;
      }


      /* 301�I�ؤ��30�I�� add by 061476 107.12.04 (1071203004_SC3) */
      if (f_301_exist == 'Y')
      {
    		if ((injured_cover31 >= 2000000) && (damage_cover32 >= 500000)){
    			deduct30[0] = '3';
    		}else if ((injured_cover31 >= 700000) && (damage_cover32 >= 200000)){
    			deduct30[0] = '1';
    		}else{
    			deduct30[0] = '2';
    		}
    		deduct_301 = atoi(deduct30);
      }

      /* �ӫO�ۥΨ���X�I�B���O80�I��, ���אּ56�I��, 56�I�ئ��ݫO�B=80�I�ئ��ݫO�B & ���B�T����10000��(����I)
         add by sylvia 106.09.26 (1060921001_C1) */
      if((ins7780_chg_flag == 1) && (f_80_exist == 'Y'))
      {
        lDbirth = (long)dbirth;
        strcpy(assuredn,trim(assuredn)); /* char(30)*/
        strcpy(assureda,trim(assureda)); /* char(90)*/
        strcpy(ndeputy,trim(ndeputy_assured)); /* char(30)*/
        sLastChinese(assuredn,30);
        sLastChinese(assureda,90);
        sLastChinese(ndeputy,30);

        /* ��ĳ��O�զX */
        Insert_INS_TYPE("56", 0,0,damage_cover56, 0, 0,0,
           0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
        printf("---- 9436 ---- \n");
        if ((assuredf[0]=='1') || (assuredf[0]=='3') || (assuredf[0] == '5')){
             code = Insert_INS_TYPE_33(license,assuredn,lDbirth,assureda,
                                       "3"," ",damage_cover56,0,
                                       (double)0,0,(double)0,0,pdiscount,0,assuredn,"1",
                                       "�k�w�~�ӤH","6",10000,0,(double)0,"56",
                                       itel_appl,apayment_zip,apayment,1);
        }else{
             code = Insert_INS_TYPE_33(" ",ndeputy,lDbirth," ",
                                       "3"," ",damage_cover56,0,
                                       (double)0,0,(double)0,0,pdiscount,0," "," ",
                                       "�k�w�~�ӤH","6",10000,0,(double)0,"56",
                                       itel_appl,apayment_zip,apayment,1);
        }
        ins56_sug_flag = 1;

        /* ���O�զX */
        Insert_INS_TYPE("56", 0,0,damage_cover56, 0, 0,0,
           0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,0);

        if ((assuredf[0]=='1') || (assuredf[0]=='3') || (assuredf[0] == '5')){
             code = Insert_INS_TYPE_33(license,assuredn,lDbirth,assureda,
                                       "3"," ",damage_cover56,0,
                                       (double)0,0,(double)0,0,pdiscount,0,assuredn,"1",
                                       "�k�w�~�ӤH","6",10000,0,(double)0,"56",
                                       itel_appl,apayment_zip,apayment,0);
        }else{
             code = Insert_INS_TYPE_33(" ",ndeputy,lDbirth," ",
                                       "3"," ",damage_cover56,0,
                                       (double)0,0,(double)0,0,pdiscount,0," "," ",
                                       "�k�w�~�ӤH","6",10000,0,(double)0,"56",
                                       itel_appl,apayment_zip,apayment,0);
        }
        ins56_flag = 1;
      }

      /* ������X�I(110-117)���ֶW�L�G�~,����ĳ113-114�I�� add by sylvia 104.05.05 */
      if (f_113_115_sug == 'Y')
      {
      	/* �W�L�G�~���J�p(1041230003_C1)  */
        /* �H�U���A��ĳ modify by sylvia 105.02.02 (1041230003_C1) */
        $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,'','������X�I��O�ɨ��ֶW�L�G�~','1','E52',$iofficer);
      }

      /** 31, 51, 55,56 ... �I�إ��O�A��ĳ�[�O���I��   ***/
      if ((sug_flag == 'Y')||(fquota63 == 'Y')||(f245_265 == 'Y')||(fquota_62 == 'Y'))
      {
        #ifdef PRINTF_FLAG
            printf("issue_12[%s]\n",issue_12);
            printf("iplyyear[%d]\n",atoi(plyyear));
            printf("dmg_flag2[%c]\n",dmg_flag2);
            printf("iofficer[%s]\n",iofficer);
            printf("f_1_9_exist[%c]\n",f_1_9_exist);
            printf("f_10_exist[%c]\n",f_10_exist);
        #endif
        if(ISCAR_SET1(car_typei))
        {
            if ((fquota63 == 'Y')||(f245_265 == 'Y')||(fbz_2131 == 'Y')||
                (fquota_62 == 'Y')||(fkaxx == 'Y')||(fBEV == 'Y')||(fES == 'Y'))
            {
            	/*���A��*/
            }
            else
            {
            	/********************/
            	/** ���ӫO����D�I **/
            	/********************/
                if (f_1_9_exist == 'N')
	        		{

	            /* 100.01.18, ����(A04)��ӸΫH(A23*) */
	            /* 981208, ���p(A11*) ���O�զX �אּ����ĳ*/
	            /* 961128, �x���Υ�(A21*)���O�զX ����ĳ */
	            /* 951127 ,�W�ߨT��(fSunLi=='Y')==> ���֤��~��,�Y�즳��O�����I�̩Ϋ�ĳ��O�����I�̡A���Ƨt�[�ȫ��N�B���O�O�B�����I�K�l�v */
	            /* 951107 ,�ΫH(A23*)          ==> ���֤��~��,�Y�즳��O�����I�̩Ϋ�ĳ��O�����I�̡A���Ƨt�[�ȫ��N�B���O�O�B�����I�K�l�v */
	            /* 950913 ,�έ� A09*           ==> ���֤��~��,�@�߫�ĳ�A�K,�P�ɥ[�O10�I�ؤΥ[�ȫ�(���t���O�զX) */
	            /* 950822 ,�x���Υ��g�P��A21*  ==> ���֤��~��,�@�߫�ĳ�A�K,�P�ɥ[�O10�I�ؤΥ[�ȫ� */
	            /* 950831 ,���p(A11*)�g�P��    ==> ���֤��~��,�@�߫�ĳ����,�P�ɥ[�O10�I�ؤΥ[�ȫ� */
	            /* 102.12.04 ��������ĳ05(�ӫO�ɤ�),����A���ĳ105 */
	            /*if (((strncmp(iofficer,"A09",3) == 0)||
                           (strncmp(iofficer,"A11",3) == 0)||
                           (strncmp(iofficer,"A21",3) == 0)||
                           (strncmp(iofficer,"A23",3) == 0)||*/
                    /* ����03,21,22, ���Ӭ�A11,A23,A04 �אּ��ĳ120+121�I�� modify by sylvia 103.10.22 (1031016004_C1) */
    		    /* �]�ӫ~����, �אּ��ĳ09+156 modify by sylvia 105.12.29 (1051214006_C4) */
    		    /****************************************/
    		    /** �P�ɲŦX�H�U3������̡A��ĳ09�B156 **/
    		    /** (1)03�B21�B22����                  **/
    		    /** (2)A11�BA23�BA04�g��               **/
    		    /** (3)����(�o�Ӧ~��-��O�~��)5�~��    **/
    		    /****************************************/
    		    if(((strncmp(car_typei,"03",2)==0)||(strncmp(car_typei,"22",2)==0)||
    		        (strncmp(car_typei,"21",2)==0)) &&
    		        ((strncmp(iofficer,"A11",3) == 0)|| (strncmp(iofficer,"A23",3) == 0)||
    		        (strncmp(iofficer,"A04",3) == 0)) &&
    		        ((atoi(plyyear) - atoi(issue_12)) <= 4))
    		    {
		        Insert_INS_TYPE("09", 0 , 0, cover_E_last , 0, 0,0,
		                        0.00,0.00,tmp_frate2,pdiscount,0,0,0,provision_E,pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);

		        Insert_INS_TYPE("156", 600 , 0, 1800, 0, 0,0,
		                        0.00,0.00,tmp_frate2,pdiscount,0,3,0,' ',pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);

		        f_1_9_sug = 'Y';  f_09_sug = 'Y' ; f_156_sug = 'Y';
		        strcpy(funknown_dmg_sug,"1");   /* �O�v�N��>=93 �H�ᨮ������T�J�`�A�@�߬�1 modity by 061476 107.03.26 */
		    }
    		    /*************************************************/
    		    /** �P�ɲŦX�H�U2������̡A��ĳ09�B10           **/
    		    /** (1)A11�BA23�BA04�g��B�W��                  **/
    		    /** (2)����(�o�Ӧ~��-��O�~��)5�~��             **/
    		    /** 03�B21���ءA���ӫO15�B64�B69�B143�A�A��ĳ15 **/
    		    /*************************************************/
		    else if (((strncmp(iofficer,"A11",3) == 0)|| (strncmp(iofficer,"A23",3) == 0)||
		              (fSunLi=='Y')||(strncmp(iofficer,"A04",3) == 0))&&
		             ((atoi(plyyear) - atoi(issue_12)) <= 4))
		    {
    		        strcpy(ins_type_ttmp,"09");
    		        f_09_sug = 'Y' ;
    		        f_1_9_sug = 'Y';
    		        qday_bak = 0;

    		        /* 961128, �x���Υ�(A21*)���O�զX ����ĳ */
    		        /* �̳̫�@�ӰѼƥ�0 ��1 => ply_ins_type_302 �~����s�W,��ק� => why? */
    		        /* ���p�θΥ��~�����O�զX����ĳ*/
    		        /* if ((strncmp(iofficer,"A11",3)==0)||(strncmp(iofficer,"A21",3)==0)){*/
    		        /* 981208, A11 ���O�զX �אּ����ĳ
    		        if (strncmp(iofficer,"A11",3)==0){
    		            Insert_INS_TYPE(ins_type_ttmp, 0, 0, cover_E_last, 0,
                                            0,0, 0.00,0.00,frate,pdiscount,0,
                                            qday_bak,0,provision_E,pextra_charge,
                                            pbusiness,0); }  */
                        Insert_INS_TYPE(ins_type_ttmp, 0, 0, cover_E_last , 0, 0,0,
                                        0.00,0.00,frate,pdiscount,0,qday_bak,0,provision_E,
                                        pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
                        /*strcpy(funknown_dmg_sug,"2");*/   /* ��105/04/01�_(�O�v�N��>=79), �J�p85,105,118�ĥηs��) add by sylvia 105.03.16 (1050226003_C3) */
                        strcpy(funknown_dmg_sug,"1");   /* �O�v�N��>=93 �H�ᨮ������T�J�`�A�@�߬�1 modity by 061476 107.03.26 */

                        /* �̳̫�@�ӰѼƥ�1 ��0 */
                        Insert_INS_TYPE("10", 0, 0, 0, 0, 0,0, 0.00,0.00,frate,pdiscount,
                                        0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);

                        f_10_exist = 'Y';
                        /* 981208,     ���p(A11*)���O�զX ����ĳ */
                        /* 961128, �x���Υ�(A21*)���O�զX ����ĳ */
                        /* ���p�θΥ��~�����O�զX����ĳ*/
                        /* 990324,fix, �x���έ� �Υ����O�զX ����ĳ */
                        /* 102.12.04 ��������ĳ05(�ӫO�ɤ�),����A���ĳ105,�ҥH�]�n������ĳ67 */
                        /* 101.06.14 �s�W�N���O�I���ˮ�*/
                        /* 981208,���ĳ�[�ȫ����ĳ�N�B���I */
                        /* 1041222 �s�W143�I�اP�_ add by sylvia 104.12.22 (1041203004_C4) */
                        if((strncmp(car_typei,"03",2)==0) || (strncmp(car_typei,"21",2)==0))
                        {
                            if (f_09_sug=='Y')
                            {
                                if (f_15_exist == 'N')
                                {
                                    if (f_64_exist =='N' && f_69_exist =='N' && f_143_exist =='N')
                                    {
                                        Insert_INS_TYPE("15", 2500,0,2500*15,0,0,0,0.00,0.00
                                			,frate,pdiscount,0,15,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
                                    }
                                }
                            }/*else if (f_05_sug=='Y'){
                                	if (f_63_exist =='N' && f_65_exist =='N'){
                                		Insert_INS_TYPE("67", 2500,0,2500*15,0,0,0,0.00,0.00
                                		,frate,pdiscount,0,15,0," ",pextra_charge, pbusiness,1); }
                            }*/
                        }
                    }
    		    /*****************************************************************/
    		    /** �P�ɲŦX�H�U2�������                                       **/
    		    /** (1)03�B22����                                               **/
    		    /** (2)L�g��                                                    **/
    		    /** ����(�o�Ӧ~��-��O�~��)5�~���A��ĳ09                        **/
    		    /** 5�~(�t)�H�W�A�B���ӫO02�B03�B07�B64�B150�B156�B162�A��ĳ198 **/
    		    /*****************************************************************/
                    else if(((strncmp(car_typei,"03",2)==0)||(strncmp(car_typei,"22",2)==0)) &&
    		             (iofficer[0]=='L'))
    		    {
    		        /* ���M(L*)�̾ڨ��֫�ĳ09�B198�I�� add by 061476 (1080212008_SC1) */
		        if ((atoi(plyyear) - atoi(issue_12)) <= 4)
		        {
		            Insert_INS_TYPE("09", 0, 0, cover_E_last, 0, 0,0,0.00,0.00,
		                	    frate,pdiscount,0,0,0,provision_E,pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);

		            f_1_9_sug = 'Y';  f_09_sug = 'Y' ;
		            strcpy(funknown_dmg_sug,"1");   /* �O�v�N��>=93 �H�ᨮ������T�J�`�A�@�߬�1 modity by 061476 107.03.26 */
		        }
		        else
		        {
		            /* 198�I�إi���[143�I�� modify by 061476 (1100816002_SC3) */
		            if (f_162_exist =='N' && f_02_exist =='N' && f_03_exist =='N' && f_07_exist =='N' &&
		                f_150_exist =='N' && f_156_exist =='N' && f_64_exist =='N')
		            {
		                Insert_INS_TYPE("198", 0, 0, 50000, 0, 0,0,0.00,0.00,
		                	        frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
		                f_198_exist = 'Y';
		                strcpy(funknown_dmg_sug," ");
		            }
		        }
		    }
    		    /***************************************************/
    		    /** �P�ɲŦX�H�U3������̡A��ĳ15                 **/
    		    /** (1)03�B21�B22����                             **/
    		    /** (2)A09�g��                                    **/
    		    /** (3)���ӫO15�B62~64�B66~67�B143�B154~156�B163  **/
    		    /***************************************************/
		    else if ( (strncmp(iofficer,"A09",3) == 0) &&
                              ((strncmp(car_typei,"03",2)==0)||(strncmp(car_typei,"21",2)==0)||(strncmp(car_typei,"22",2)==0)) )
                    {
                    	/* �έ�(A09)�אּ�@�߫�ĳ15�I��(10��) modify by 061476 (1090925005_SC1) */
                    	/* ����A09�έ�15�I��ĳ�ѼƼW�[��30�� (1110120006_SC1) modify by 071004*/
                        if (f_15_exist =='N' && f_62_exist =='N' && f_63_exist =='N' &&
                            f_64_exist =='N' && f_143_exist =='N' && f_67_exist =='N' && f_66_exist =='N' &&
                            f_154_exist =='N' && f_155_exist =='N' && f_156_exist =='N' && f_163_exist =='N')
                        {
                            Insert_INS_TYPE("15", 2500,0,75000,0,0,0,0.00,0.00
                        		    ,frate,pdiscount,0,30,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
                        }
                    }
                }
            	/********************/
            	/** ���ӫO����D�I **/
            	/********************/
                else
                {
                    /* f_1_9_exist == 'Y' */
	            /* 100.01.18, ����(A04)��ӸΫH(A23*) */
	            /* 981208,���p(A11*)���O�զX ����ĳ */
             	    /* 970408, �ɤW �ΫH(A23) */
	            /* 961128, �x���Υ�(A21*)���O�զX ����ĳ */
                    /* 951127 ,�W�ߨT��(fSunLi)*/
                    /* 950831 ,�x���Υ�(A21*)�B���p(A11*) ==> ����@�߫�ĳ�[�O10�I�ؤΥ[�ȫ� */
                    /* 1070808 (1) ���ק�O���ب����I�A�@�ߧP�_�S��15,62,63,64,143,66,67�I�ؤ~��ĳ
                               (2) ���O���A��ĳ15,66,67�I�� modify by 061476 (1070104008_SC1) */
                    /*if ((strncmp(iofficer,"A11",3) == 0)||(strncmp(iofficer,"A21",3) == 0)||(fSunLi=='Y')){*/
                    /* ����(A04)����X�� modify by 061476 108.11.22 (1081024005_SC1) */
                    /* �έ�(A09)��ӸΫH(A23)��ĳ�N�B�� add by 061476 109.03.18 (1090312003_SC1) */
                    /* �έ�(A09)��ĳ��O15�I�إN�B���ѼƬ�10�� modify by 061476 (1090603003_SC1) */
                    /* �έ�(A09)����X�ӡG�W�[���ؤΧאּ�@�߫�ĳ15�I��(10��) modify by 061476 (1090925005_SC1) */
                    /* ���M(L)��ĳ�N���O62/63/64�I�� add by 061476 (1100429001_SC1) */

    		    /***************************************************/
    		    /** �P�ɲŦX�H�U4������̡A��ĳ15                 **/
    		    /** (1)03�B22����                                 **/
    		    /** (2)A04�g��                                    **/
    		    /** (3)���ӫO05��09                               **/
    		    /** (4)���ӫO15�B62~64�B66~67�B143�B154~156�B163  **/
    		    /***************************************************/
                    if (strncmp(iofficer,"A04",3) == 0){
                    	if((strncmp(car_typei,"03",2)==0)||(strncmp(car_typei,"22",2)==0)){
                    	    if(pre_qday==0){/* �h�~�S���[�ȫ��]�n��ĳ */
                    	        if ((f_05_exist == 'Y')||(f_09_exist == 'Y')){
                    		    if (f_15_exist == 'N'){
                    		        if (f_15_exist =='N' && f_62_exist =='N' && f_63_exist =='N' &&
                    			    f_64_exist =='N' && f_143_exist =='N' && f_67_exist =='N' && f_66_exist =='N' &&
                    			    f_154_exist =='N' && f_155_exist =='N' && f_156_exist =='N' && f_163_exist =='N')
                    		        {
                    			    Insert_INS_TYPE("15", 2500,0,75000,0,0,0,0.00,0.00
                    					    ,frate,pdiscount,0,30,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
                    			}
                    		    }
                    		}
                    	    }
                    	}
                    }

    		    /***************************************************/
    		    /** �P�ɲŦX�H�U4������̡A��ĳ15                 **/
    		    /** (1)03�B21�B22����                             **/
    		    /** (2)A09�g��                                    **/
    		    /** (3)���ӫO01��05��09                           **/
    		    /** (4)���ӫO15�B62~64�B66~67�B143�B154~156�B163  **/
    		    /***************************************************/
                    if (strncmp(iofficer,"A09",3) == 0){
                    	if((strncmp(car_typei,"03",2)==0)||(strncmp(car_typei,"21",2)==0)||(strncmp(car_typei,"22",2)==0)){
                    	    if(pre_qday==0){/* �h�~�S���[�ȫ��]�n��ĳ */
                    	        if ((f_01_exist == 'Y')||(f_05_exist == 'Y')||(f_09_exist == 'Y')){
                    		    if (f_15_exist =='N' && f_62_exist =='N' && f_63_exist =='N' &&
                    			f_64_exist =='N' && f_143_exist =='N' && f_67_exist =='N' && f_66_exist =='N' &&
                    			f_154_exist =='N' && f_155_exist =='N' && f_156_exist =='N' && f_163_exist =='N')
                    		    {
                    		    	/*����A09�έ�15�I��ĳ�ѼƼW�[��30�� (1110120006_SC1) modify by 071004*/
                    		        Insert_INS_TYPE("15", 2500,0,75000,0,0,0,0.00,0.00
		                                        ,frate,pdiscount,0,30,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);

                    		    }
                    		}
                    	    }
                    	}
                    }


    		    /***************************************************/
    		    /** �P�ɲŦX�H�U4������̡A��ĳ15                 **/
    		    /** (1)03�B22����                                 **/
    		    /** (2)A21�g��                                    **/
    		    /** (3)���ӫO09                                   **/
    		    /** (4)���ӫO15�B62~64�B66~67�B143�B154~156�B163  **/
    		    /***************************************************/
    		    /*1101208004_SC1_���ӸΥ�A21�վ��ĳ��O���*/
                    if (strncmp(iofficer,"A21",3) == 0){
                    	if((strncmp(car_typei,"03",2)==0)||(strncmp(car_typei,"22",2)==0))
                    	{
                    	    if (f_09_exist == 'Y')
                    	    {
                    		if (f_15_exist =='N' && f_62_exist =='N' && f_63_exist =='N' &&
                    		    f_64_exist =='N' && f_143_exist =='N' && f_67_exist =='N' && f_66_exist =='N' &&
                    		    f_154_exist =='N' && f_155_exist =='N' && f_156_exist =='N' && f_163_exist =='N')
                    		{
                    		    Insert_INS_TYPE("15", 2500,0,75000,0,0,0,0.00,0.00
		                                    ,frate,pdiscount,0,30,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
                    		}
                    	    }
                    	}
                    }


    		    /***************************************************/
    		    /** �P�ɲŦX�H�U3�������                         **/
    		    /** (1)03�B22����                                 **/
    		    /** (2)L�g��                                      **/
    		    /** (3)���ӫO15�B62~64�B66~67�B143�B154~156�B163  **/
    		    /** ���ӫO01�A��ĳ62                              **/
    		    /** ���ӫO05�A��ĳ63                              **/
    		    /** ���ӫO09�A��ĳ64                              **/
    		    /***************************************************/
                    if (iofficer[0]=='L')
                    {
                    	if((strncmp(car_typei,"03",2)==0)||(strncmp(car_typei,"22",2)==0))
                    	{
                    	    if(pre_qday==0){/* �h�~�S���[�ȫ��]�n��ĳ */
                    	        if (f_01_exist == 'Y')
                    	        {
                    		    if (f_15_exist =='N' && f_62_exist =='N' && f_63_exist =='N' &&
                    			f_64_exist =='N' && f_143_exist =='N' && f_67_exist =='N' && f_66_exist =='N' &&
                    			f_154_exist =='N' && f_155_exist =='N' && f_156_exist =='N' && f_163_exist =='N')
                    		    {
                    			Insert_INS_TYPE("62", 2000,0,14000,0,0,0,0.00,0.00
                    					,frate,pdiscount,0,0,0," ",pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,1);
                    		    }
                    		}
                    		else if (f_05_exist == 'Y')
                    		{
                    		    if (f_15_exist =='N' && f_62_exist =='N' && f_63_exist =='N' &&
                    			f_64_exist =='N' && f_143_exist =='N' && f_67_exist =='N' && f_66_exist =='N' &&
                    			f_154_exist =='N' && f_155_exist =='N' && f_156_exist =='N' && f_163_exist =='N')
                    		    {
                    		        Insert_INS_TYPE("63", 2000,0,14000,0,0,0,0.00,0.00
                    				        ,frate,pdiscount,0,0,0," ",pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,1);
                    		    }
                    		}
                    		else if (f_09_exist == 'Y')
                    		{
                    		    if (f_15_exist =='N' && f_62_exist =='N' && f_63_exist =='N' &&
                    			f_64_exist =='N' && f_143_exist =='N' && f_67_exist =='N' && f_66_exist =='N' &&
                    			f_154_exist =='N' && f_155_exist =='N' && f_156_exist =='N' && f_163_exist =='N')
                    		    {
                    		        Insert_INS_TYPE("64", 2000,0,14000,0,0,0,0.00,0.00
                    					,frate,pdiscount,0,0,0," ",pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,1);
                    		    }
                    		}
                    	    }
                    	}
                    }

    		    /********************/
    		    /** A23�g��B�W��  **/
    		    /********************/
                    if ((strncmp(iofficer,"A23",3) == 0)||(fSunLi=='Y'))
                    {

    		        /***************************************************/
    		        /** �P�ɲŦX�H�U2�������                         **/
    		        /** (1)03�B21����                                 **/
    		        /** (2)���ӫO15�B62~64�B66~67�B143�B154~156�B163  **/
    		        /** ���ӫO01�A��ĳ66                              **/
    		        /** ���ӫO05�A��ĳ67                              **/
    		        /** ���ӫO09�A��ĳ15                              **/
    		        /***************************************************/
                    	if((strncmp(car_typei,"03",2)==0) || (strncmp(car_typei,"21",2)==0)) {
                    	    if(pre_qday==0)
			    { /* �h�~�S���[�ȫ��]�n��ĳ */
			        if (f_01_exist == 'Y')
			        {
				    if (f_66_exist == 'N')
				    {
				        /* 101.06.14 �s�W�N���O�I���ˮ�*/
				    	if (f_15_exist =='N' && f_62_exist =='N' && f_63_exist =='N' &&
				    	    f_64_exist =='N' && f_143_exist =='N' && f_67_exist =='N' && f_66_exist =='N' &&
                    			    f_154_exist =='N' && f_155_exist =='N' && f_156_exist =='N' && f_163_exist =='N')
                    			{
				    	    Insert_INS_TYPE("66", 2500,0,37500,0,0,0,0.00,0.00
				    		    	    ,frate,pdiscount,0,15,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
					}
				    }
				}
				else if (f_05_exist == 'Y')
				{
				    if (f_67_exist == 'N')
				    {
				        if (f_15_exist =='N' && f_62_exist =='N' && f_63_exist =='N' &&
				    	    f_64_exist =='N' && f_143_exist =='N' && f_67_exist =='N' && f_66_exist =='N' &&
                    			    f_154_exist =='N' && f_155_exist =='N' && f_156_exist =='N' && f_163_exist =='N')
                    			{
				    	    Insert_INS_TYPE("67", 2500,0,37500,0,0,0,0.00,0.00
				    		    	    ,frate,pdiscount,0,15,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
					}
				    }
				}
				else if (f_09_exist == 'Y')
				{
				    if (f_15_exist == 'N')
				    {
				        /* 1041222 �s�W143�I�اP�_ add by sylvia 104.12.22 (1041203004_C4) */
					if (f_15_exist =='N' && f_62_exist =='N' && f_63_exist =='N' &&
				    	    f_64_exist =='N' && f_143_exist =='N' && f_67_exist =='N' && f_66_exist =='N' &&
                    			    f_154_exist =='N' && f_155_exist =='N' && f_156_exist =='N' && f_163_exist =='N')
                    			{
				    	    Insert_INS_TYPE("15", 2500,0,37500,0,0,0,0.00,0.00
				    		    	    ,frate,pdiscount,0,15,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
					}
				    }
				}
			    }
			}
			/* �έ�(A09)���O���[��ĳ10�I�� modify by 061476 109.03.19 (1090312003_SC1) */

    		        /********************************************/
    		        /** ���ӫO10�A���O�Ϋ�ĳ��O���[�W10�I�� **/
    		        /********************************************/
                        if (f_10_exist == 'N')
                        {
                            Insert_INS_TYPE("10", 0, 0,0, 0, 0,0,
                                            0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
                            Insert_INS_TYPE("10", 0, 0,0, 0, 0,0,
                                            0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,0);
			}
                        #ifdef PRINTF_FLAG
		        printf("�W�� fSunLi=[%c]\n",fSunLi);
		        printf("��ĳ�[�O10�I�ء]��ĳ�ϭ��O�զX�^iofficer=[%s]\n",iofficer);
		        printf("Scan_INS_TYPE(10)=>[%d]\n",Scan_INS_TYPE(10));
		        printf("Scan_INS_TYPE1(10)=>[%d]\n",Scan_INS_TYPE1(10));
		        #endif

		    }
    		    /*********************************/
    		    /** �DA23�g��B�W�ߥ󤧨�L�O�� **/
    		    /*********************************/
		    else
		    {
		    	/**************************/
    		        /** ���ӫO10�A��ĳ10�I�� **/
    		        /**************************/
    		        /* �]10�I�ط|��HCC���ƼW�[�A�G�D���Ӥ@�v������ĳ10�I�� (1120220002_SC3) */
		        if ((f_10_exist == 'N') && (strcmp(imgr,"1") == 0))
		        {
			    Insert_INS_TYPE("10", 0, 0, 0, 0, 0,0,
				            0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
		        }
		        #ifdef PRINTF_FLAG
		        printf("��ĳ�[�O10�I�ء]�ȫ�ĳ��O�զX�^iofficer=[%s]\n",iofficer);
		        printf("Scan_INS_TYPE(10)=>[%d]\n",Scan_INS_TYPE(10));
		        printf("Scan_INS_TYPE1(10)=>[%d]\n",Scan_INS_TYPE1(10));
		        #endif
			/* 950913 ,�έ� A09* �������O�զX����ĳ */
		    }

                } /* f_1_9_exist == 'Y' end */


                /* 961128, �x���Υ�(A21*)���O�զX ����ĳ(�P�έ�A09�P=>�ন��ĳ05) */
                /* 950913, �έ�A09* 09    =>�ন��ĳ05 ,�����t�~insert 09 */
                /* 950908, �x���Υ�A21* 09=>�ন��ĳ05 ,�����t�~insert 09 */
                /*if ((ins1589_chg_flag==1)&&((strncmp(iofficer,"A09",3) == 0)||(strncmp(iofficer,"A21",3) == 0))){*/
                if ((ins1589_chg_flag==1)&& ((strncmp(iofficer,"A09",3) == 0)||(strncmp(iofficer,"A21",3) == 0)))
                {
                    /* �έ� �ഫ�e��09���e���O�B�O�O�~,���������O�զX����ĳ*/
	            /* �B�즳�[�ȫ���, ���O�զX�����t�[�ȫ��]qday�^        */
                    if((strncmp(iofficer,"A09",3) == 0)||(strncmp(iofficer,"A21",3) == 0))
                    {
                        Insert_INS_TYPE("09", 0, 0, cover_E_last , 0, 0,0,
                                  0.00,0.00,frate,pdiscount,0,pre_qday,0,provision_E,pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,0);
                        /*strcpy(funknown_dmg_ori,"2");*/   /* ��105/04/01�_(�O�v�N��>=79), �J�p85,105,118�ĥηs��) add by sylvia 105.03.16 (1050226003_C3) */
                        strcpy(funknown_dmg_ori,"1");    /* �O�v�N��>=93�H�ᨮ������T�J�`�A�@�߬�1 modity by 061476 107.03.26*/

                        Insert_INS_TYPE("09", 0, 0, cover_E_last , 0, 0,0,
                                   0.00,0.00,frate,pdiscount,0,15,0,provision_E,pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
                        /*strcpy(funknown_dmg_sug,"2");*/   /* ��105/04/01�_(�O�v�N��>=79), �J�p85,105,118�ĥηs��) add by sylvia 105.03.16 (1050226003_C3) */
                        strcpy(funknown_dmg_sug,"1");   /* �O�v�N��>=93 �H�ᨮ������T�J�`�A�@�߬�1 modity by 061476 107.03.26 */
		    }
	            /* 981208,���ĳ�[�ȫ����ĳ�N�B���I (09(���O) �ର=> 05 (��ĳ) ,�ҥH���� iins_type ��05  )   */
	            if((strncmp(car_typei,"03",2)==0) || (strncmp(car_typei,"21",2)==0))
	            {
                        if (f_63_exist =='N' && f_65_exist =='N' && f_143_exist =='N')
                        {
			    Insert_INS_TYPE("67", 2500,0,37500,0,0,0,0.00,0.00
				            ,frate,pdiscount,0,15,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
			}
		    }
                    /* �ѩ�s�W(Insert_INS_TYPE(...))��ĳ��O�զX�ɡA�u�| Update �Gori_�T�ӫO�B�Bori_deduct�Bori_premium ,
                       �]���p�e�����[�ȫ��B���O�զX��n�p�����ܥX�[�ȤѼơB�O�ε��A��
                       �s�W���O�զX���[�Jqday ,�Y ==>
                       Insert_INS_TYPE("[�����I]",.....,0,qday,0,0); ==> ���F�p��[�ȫ��O
                       �t�~�����b�s�W��ĳ��O�զX�ɥ[�Jqday ,�Y ==>
                       Insert_INS_TYPE("[�����I]",.....,0,qday,0,1); ==> ���F�����G qday�B mexpense�B mexp_disc ����  */
                    /* Insert_INS_TYPE("09", 0, 0, cover_E_last , 0, 0,0,
                                       0.00,0.00,frate,pdiscount,0,qday,0,provision_E,pextra_charge, pbusiness,1);  */
	        }
            }
        } /* ISCAR_SET1(car_typei)  end  */


        /* 101.10 �D���Ӿ���barcode   */
        if(ISMOT(car_typei))
        {
            if ((fquota63 == 'Y')||(f245_265 == 'Y')||(fbz_2131 == 'Y')||
                (fkaxx == 'Y')||(fBEV == 'Y')||(fES == 'Y')||(f25C01 == 'Y')) {/*���A��*/}
            else
            {
                if (*choice=='1'){
                    if((fBarcode=='Y')&&(strncmp(s_fmot_insure,"02",2)==0)){
              	        /* ��ĳ��O�@�ס@���O�@*/
              	    }else{
              	    	if((strncmp(car_typei,"32",2)==0)||(fMotProj=='Y')) {
              	    		/* 32���ؤ��ǤJbarcode�A�㨮���ѱM��barcode(fMotProj)�᭱�t�~�P�_ */
              	    	}else{
              	    		/* �_�@�Ͼ����u��ĳ56�I�� add by 061476 108.05.31 (1080507001_SC1) */
              	    		if (fquota_62 == 'Y')
              	    		{
              	    			if ((f_49_exist !='Y')&&(ins56_flag != 1)&&(ins166_flag != 1)&&(ins266_flag != 1)&&(f_47_exist !='Y')&&(f_147_exist !='Y'))
              	    			{
              	    				if(((f_31_exist=='Y')||(f_32_exist=='Y')||(f_149_exist=='Y'))&&(f_provision_L == 0))
              	    				{
              	    					/* �אּ�n�O�H��� modify by sylvia 114.06.18  (1140605006_C01) */

              	    					strcpy(applicantn,trim(napplicant)); 	/* char(30)*/
              	    					strcpy(paymenta,trim(apayment)); 			/* char(90)*/
              	    					strcpy(ndeputy_appl2,trim(ndeputy_appl)); /* char(30)*/
              	    					sLastChinese(applicantn,30);
              	    					sLastChinese(paymenta,90);
              	    					sLastChinese(ndeputy_appl2,30);
              	    					lDbirth_appl2 = (long)dbirth_appl;

              	    					Insert_INS_TYPE("56", 0,0,2000000, 0, 0,0,
    				                         0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);

    				                         if ((fapplicant[0]=='1') || (fapplicant[0]=='3') || (fapplicant[0] == '5')){  /*�۵M�H*/
    				                         	code = Insert_INS_TYPE_33(iapplicant,applicantn,lDbirth_appl2,paymenta,
    				                         	       "2"," ",death_cover_56,0,
    				                         	       (double)0,0,(double)0,0,pdiscount,0,applicantn,"1",
    				                         	       "�k�w�~�ӤH","6",1000,0,(double)0,"56",
    				                         	       itel_appl,apayment_zip,apayment,1);
    				                         }else{
    				                         	code = Insert_INS_TYPE_33(" ",ndeputy_appl2,lDbirth_appl2," ",
    				                         	       "2"," ",death_cover_56,0,
    				                         	       (double)0,0,(double)0,0,pdiscount,0," "," ",
    				                         	       "�k�w�~�ӤH","6",1000,0,(double)0,"56",
    				                         	       itel_appl,apayment_zip,apayment,1);
    				                         }
    				                         if (code != SUCCESS) return code;
    				                         ins56_sug_flag = 1;
              	    				}
              	    			}
              	    		}
              	    		else
              	    		{
              	    			if ((f_47_exist =='Y' )|| (f_147_exist =='Y' )){
              	    				if (qply_period == 12){
              	    					if((f_31_exist=='N')&&(f_32_exist=='N')&&(f_149_exist=='N')&&(f_1_9_exist=='N')&&(f_86_exist=='N')&&(f_11_exist=='N')&&(f_provision_L == 0) ){
              	    						Insert_INS_TYPE("31", 2000000, 0,4000000,
              	    						                0, 0,0,0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
              	    						Insert_INS_TYPE("32", 0, 0,200000,
              	    						                0, 0,0,0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
              	    					}
              	    				}
              	    			}else{
              	    				if (comp_flag=='Y')
              	    				{
              	    					if ((f_1_9_exist=='N')&&(f_86_exist=='N')&&(f_11_exist=='N')){
              	    						/* 101.10, �O�_�b�P�@�J�p�~��B���L��  */
              	    						t_count = 0;
              	    						/* $EXECUTE prep_chkChange INTO $t_count USING  $irelative_ply ,$license, $chk_dbirth, $bzfrom ; */
              	    						/* �t�X�O�o�q���X�s,���q���N����H��1�X��� modify by sylvia 106.01.25 (1060111005_C3) */
              	    						/* �ק��ˮ֡G�O�o�q���N���������@�P�A�_�h������j/��� modify by 061476 (1090430005_SC1) */
              	    						/* �W�[�ˮ֡G�޲z�H�ݤ@�P add by 061476 (1090616006_SC1) */
              	    						$EXECUTE prep_chkChange INTO $t_count USING  $irelative_ply, $license, $chk_dbirth, $bzfrom, $ileader ;
              	    						if (t_count==0){
              	    							/* ��������N:�]���P�@�J�p�~��Φ��L��A����ĳ47  */
              	    						}else{
              	    							if ((f_49_exist !='Y')&&(ins56_flag != 1)&&(ins166_flag != 1)&&(ins266_flag != 1))
              	    							{
              	    								if (f_provision_L == 0)
              	    								{  /* ��L���ڤ���ĳ47�I�� modify by 061476 (1080708002_SC3) */
              	    									Insert_INS_TYPE("47", injured_cover_pa_47, death_cover_pa_47 ,damage_cover_pa_47,
								        	        0, 0,0,0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,1);
              	    								}
								        }
								}
							}
						}
					}
              	    		}
		        }
		    }
		}
            }
        } /* if(ISMOT(car_typei)) end */
        else /* �T�� */
        {

            if((fBarcode=='Y')&&(strncmp(s_fcar_insure,"02",2)==0))
            {
                if ((fquota63 == 'Y')||(f245_265 == 'Y')||(fbz_2131 == 'Y')||(fquota_62 == 'Y')||(fkaxx == 'Y')||(fBEV == 'Y')||(fES == 'Y'))
                {
                	/*���A��*/

                }
                else
                {
                    /* ��ĳ��O�@�ס@���O�@*/
								}
            }
            else
            {
                if ((fquota63 == 'Y')||(f245_265 == 'Y')||(fbz_2131 == 'Y')||(fquota_62 == 'Y')||(fkaxx == 'Y')||(fBEV == 'Y')||(fES == 'Y'))
                {
                	/*���A��*/

                }
                else
                {
                    /* 102.01 ,�ŦX�D���ӨT����jbarcode���� "�h�~��O21+50 ��"�A�u��ĳ31 32 */
                    if (fIns21_50 =='N')
                    {
                    	/* �U���D21+50���O�� */
                    	/* 102.08.01 ��ĳ98�I�� */
                    	/* 108.04.24 �]98����A���A��ĳ98�I�� (1080408008_SC3) */
                        if (f_11_exist == 'Y')
		        {
		        	/* ��������ĳ16�I���ĳ19 (1120309003_SC1) */
		        	if(((strncmp(car_typei,"03",2) == 0 )||(strncmp(car_typei,"21",2) == 0 ))&&
		        	    (IsPlyB!='Y')&&(strncmp(iofficer,"A04",3) != 0))
		        	{
		        		#ifdef PRINTF_FLAG
		        		printf("f_19_exist[%c]\n",f_19_exist);
		        		printf("f_14_exist[%c]\n",f_14_exist);
		        		printf("thief_add_flag[%d]\n",thief_add_flag);
		        		#endif
		        		if ((f_19_exist == 'N')&&(f_14_exist == 'N')&&(f_16_exist == 'N'))
		        		{
		        			/* ��L16 */
		        			if (thief_add_flag == 0)
		        			{
		        				Insert_INS_TYPE("16", 2500, 0, 75000, 0, 0,0,
		        				                0.00,0.00,frate,pdiscount,0,30,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
		        			}
		        		}
		        	}

		        	if(((strncmp(car_typei,"03",2) == 0 )||(strncmp(car_typei,"22",2) == 0))&&
		        	    (IsPlyB!='Y')&&(strncmp(iofficer,"A04",3) == 0))
		        	{
		        		if ((f_19_exist == 'N') && (f_16_exist == 'N'))
		        		{
		        			Insert_INS_TYPE("19", 0, 0, 45000, 0, 0,0,
		                            	                0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
		        		}
		        	}

                                /* 102.12.25 :�ק�M�ץ�g�����(���O�M�ץ����Ӥ��|����ܦ�) */
                                if ((strncmp(car_typei,"03",2) == 0) || (strncmp(car_typei,"04",2) == 0) ||
                                    (strncmp(car_typei,"19",2) == 0) || (strncmp(car_typei,"22",2) == 0) )
                                {
		                    if ((strncmp(iquota, "65",2) == 0) && (strcmp(imgr,"2") == 0) && (fBarcode == 'N'))
		                    {
		                        /*�x���ҰϽվ��ĳ��O�զX���e add by 061476 107.06.01 (1070418006_SC1)*/
		                        if ((f_12_exist == 'N') && (f_28_exist == 'N'))
		                        {
		                            /* ��ĳ�I�ءG�겣����ĳ12�I�� �i�f����ĳ28�I��(20�U) */
		                            if (strncmp(s_car_series,"10",2)==0)  /* �겣�� */
		                            {
		                                Insert_INS_TYPE("12", 0, 0, 0, 0, 0,0,
		                                	        0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
		                            }
		                            else
		                            {
		                                tmp_lDamage75 = 0;
		                                if (strstr(tmp_provision,"E;") == NULL)
		                                {
		                                    tmp_lDamage75 = (long)(cover_01*(1.0-pdep_rate_year));
		                                }
		                                else
		                                {
		                                    tmp_lDamage75 = (long)(damage_cover11_ori*(1.0-pdep_rate_year)*(1.0-pdep_rate_year));
		                                }

		                                /* ���קKE17�����~�T���A���P�_�O�_�i�ӫO28�I�� */
		                                /* 28�I�ب��ѵs�D�I���²v�h��@�~ modify by 061476 (1080218008_SC2) */
		                                if (tmp_lDamage75 >= 200000)
		                                {
		                                    Insert_INS_TYPE("28", 0, 0, 200000, 0, 0,0,
		                                	            0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
		                                }
		                                else
		                                {
		                                    Insert_INS_TYPE("12", 0, 0, 0, 0, 0,0,
		                                	            0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
		                                }
		                            }
		                        }

		                        if (f_17_exist == 'N')
		                        {
		                            Insert_INS_TYPE("17", 0, 0, 0, 0, 0,0,
		                            	            0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
		                        }

		                        if ((f_19_exist == 'N') && (f_16_exist == 'N'))
		                        {
		                            /* 19�B16�I�ؤ��o�P�ɩӫO */
		                            /* 03���ءG11�I�ط|��ĳ16�A�G�ư���ĳ19�I�� */
		                            if ((strncmp(car_typei,"04",2) == 0) || (strncmp(car_typei,"19",2) == 0) ||
		                            	(strncmp(car_typei,"22",2) == 0))
		                            {
		                                Insert_INS_TYPE("19", 0, 0, 30000, 0, 0,0,
		                            	                0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
		                            }
		                        }
		                    }
		                    else
		                    {
		                        /* �F�w�󤣫�ĳ 12 �I�� *//* ������ĳ12��28�I�A�t�g�W�h(1120309003_SC1) */
		                        if ((ibig_comp[0] != 'B')&&(IsPlyB != 'Y')&&(strncmp(iofficer,"A04",3) != 0))
		                        {
		                            if ((f_12_exist == 'N')&&(f_28_exist=='N'))
		                            {
		                                Insert_INS_TYPE("12", 0, 0, 0, 0, 0,0,
		                            		        0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
                                            }
                                        }
		                    }
		                }

		                /* �ư����M(L*) modify by 061476 (1080212008_SC1) */
                                /* �D [ �έ�(A09*)�B�x���Υ�(A21*)�B���p(A11*)�B�ΫH(A23*)�B�W��(fSunLi)�B����(A04*) ]      */
                                /* ==> �T�~�s���B�L�ӫO01,05,09�A���ӫO�ѵs�I,�h��ĳ09  */
                                /* ==> Tmnewa �W�h*/
                                if ((strncmp(iofficer,"A09",3) != 0)&&(strncmp(iofficer,"A11",3) != 0)&&
                                    (strncmp(iofficer,"A21",3) != 0)&&(strncmp(iofficer,"A23",3) != 0)&&
                                    (fSunLi!='Y')&&(strncmp(iofficer,"A04",3) != 0)&&(iofficer[0]!='L'))
                                {
                            	    if(ISCAR_SET1(car_typei))
                            	    {
                            	        if (f_1_9_exist!='Y')
                            	        {
                            		    if (((atoi(plyyear) - atoi(issue_12)) <= 2) && (dmg_flag2 == 'N'))
                            		    {
                            		        if (rdmg == 'N')
                            			{
                            			    #ifdef PRINTF_FLAG
                            			    printf("�T�~�s���B�L�ӫO01,05,08,09�A���ӫO�ѵs�I,issue_12=[%s]\n",issue_12);
                            			    #endif
				                    qday_bak = 0;

				                    if ((strncmp(iofficer,"B",1) == 0)||(strncmp(iofficer,"A01",3) == 0)||
				                        (strncmp(iofficer,"A10",3) == 0)||(strncmp(iofficer,"A25",3) == 0))
				                    {
				                        if ((strncmp(car_typei,"03",2) == 0) || (strncmp(car_typei,"21",2) == 0)||
				                            (strncmp(car_typei,"22",2) == 0))
				                        {
				                        	/* �t�X�ӫ~����, �אּ��ĳ09+156 modify by sylvia 105.12.29 (1051214006_C4) */
				                        	Insert_INS_TYPE("09", 0, 0, cover_E_last, 0, 0, 0,
				                        	                0.00,0.00,tmp_frate2,pdiscount,0,0,0,provision_E,pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,1);
				                        	strcpy(funknown_dmg_sug,"1");   /* �O�v�N��>=93 �H�ᨮ������T�J�`�A�@�߬�1 modity by 061476 107.03.26 */

				                        	/* 156�I�ؤ��i���[E���� modify by 061476 (1090514016_SC1) */
				                        	Insert_INS_TYPE("156", 600 , 0, 600*3 , 0, 0,0,
				                        	                0.00,0.00,tmp_frate2,pdiscount,0,3,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);

				                        	f_1_9_sug = 'Y';  f_09_sug = 'Y'; f_156_sug = 'Y';
				                        }
				                        else
				                        {
				                        	/* 04�B19���ث�ĳ09+10 */
				                        	Insert_INS_TYPE("09", 0, 0, cover_E_last, 0, 0, 0,
				                                	        0.00,0.00,frate,pdiscount,0,qday_bak,0,provision_E,pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,1);
				                                strcpy(funknown_dmg_sug,"1");   /* �O�v�N��>=93 �H�ᨮ������T�J�`�A�@�߬�1 modity by 061476 107.03.26 */

				                                f_1_9_sug = 'Y';  f_09_sug = 'Y' ;
				                        }
				                    }
				                    else
				                    {
				                    	if (strcmp(imgr,"1") == 0)
				                    	{
				                    		/* ���ӥ��ĳ09 */
				                    		Insert_INS_TYPE("09", 0, 0, cover_E_last, 0, 0, 0,
				                    		                0.00,0.00,frate,pdiscount,0,qday_bak,0,provision_E,pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,1);
				                    		strcpy(funknown_dmg_sug,"1");   /* �O�v�N��>=93 �H�ᨮ������T�J�`�A�@�߬�1 modity by 061476 107.03.26 */

				                    		f_1_9_sug = 'Y';  f_09_sug = 'Y' ;
				                    	}
				                    	else
				                    	{
				                    		/* �@��� �����I��<=0 �~��ĳ09 */
				                    		$SELECT first 1 nvl(qpoint::INTEGER,-9999)
				                    		   INTO $qpoint_09
				                    		   FROM ca_trade_302
				                    		  WHERE iassured = $license
				                    		    AND itag = $tagnum
				                    		    AND icar_kind = '2'
				                    		    AND iacc_kind = '1'
				                    		    AND dquery >= date($dMinQuery)
				                    		  order by dquery desc;

				                    		if (SQLCODE == SQLNOTFOUND) qpoint_09 = 4;
				                    		if (qpoint_09 == -9999) qpoint_09 = 4;

				                    		if (qpoint_09 <= 0)
				                    		{
				                    			Insert_INS_TYPE("09", 0, 0, cover_E_last, 0, 0, 0,
				                                	                0.00,0.00,frate,pdiscount,0,qday_bak,0,provision_E,pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,1);
				                                	strcpy(funknown_dmg_sug,"1");   /* �O�v�N��>=93 �H�ᨮ������T�J�`�A�@�߬�1 modity by 061476 107.03.26 */

				                                	f_1_9_sug = 'Y';  f_09_sug = 'Y' ;
				                    		}
				                    	}
				                    }

				                    /* �]10�I�ط|��HCC���ƼW�[�A�G�D���Ӥ@�ߨ�����ĳ10�I�� (1120220002_SC3) */
				                    if ((f_10_exist == 'N') && (strcmp(imgr,"1") == 0) && (f_156_sug != 'Y'))
				                    {
				                        Insert_INS_TYPE("10", 0, 0, 0, 0, 0, 0,
				                                	0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
				                    }
				                }
				            }
				        }
			            }
		                }
		            } /* end of if ((f_11_exist == 'Y')) */
                        } /* end of fIns21_50 =='N'*/
                    }
                    /* 100.01.18, ����(A04)��ӸΫH(A23*) */
	            if ( (f_31_exist == 'N') && (f_149_exist == 'N') && (rlia == 'N') )
	            {
	                if ((fquota63 == 'Y')||(f245_265 == 'Y')||(fbz_2131 == 'Y')||(fquota_62 == 'Y')||(fkaxx == 'Y')||(fBEV == 'Y')||(fES == 'Y'))
	                {
	                    /*���A��*/
	                }
                        else
                        {
                    	    /* 101.11 29�I�ئۭt�B���O�����O�B�ŶZ�w�אּ(40,50,70,100)*/
                            /* 101.03.07 ,�Y����O�榳�ӫO29�I�ءA���L�ĤT�H�d���I�A�h��O�N�|��ĳ31�B32�I�ءA
                            �åB��29�I�ئۭt�B���O�����O�B�ŶZ(40,50,80,100)������ĳ31�B32�I�ثO�B���̾�  */
                            if (f_29_exist=='Y')
                            {
                                if (deduct_29 > 0)
                                {
                        	    tmp_injured_cover = deduct_29 * 10000;
	                  	    tmp_mdamage_cover = deduct_29 * 10000 * 2;
	                        }
	                    }
	                    else
	                    {
	                	/* �����հ��O�B (1120309003_SC1) */
	                	if(strncmp(iofficer,"A04",3) == 0)
	                	{
	                	    tmp_injured_cover = 5000000;
	                	}
	                	else
	                	{
	                	    tmp_injured_cover = 2000000;
	                	}

	                	if(ISCAR_SET1(car_typei))
	                	{
	                	    if ((strncmp(iofficer,"A21",3) == 0)||        /* �Υ�(A21*)   */
	                		(strncmp(iofficer,"A11",3) == 0)||        /* ���p(A11*)   */
	                		(strncmp(iofficer,"A23",3) == 0)||        /* �ΫH(A23*)   */
	                		(fSunLi=='Y'))                            /* �W��(fSunLi)*/
	                	    {
	                		/* ���� 03 21 22 ���� �վ�(12��)�O�B*/
		                	if((strncmp(car_typei,"03",2) == 0) ||(strncmp(car_typei,"21",2) == 0) ||
		                	   (strncmp(car_typei,"22",2) == 0))
		                	{
		                	    tmp_mdamage_cover = tmp_injured_cover*12;
			                }
			                else
			                {
			                    tmp_mdamage_cover = tmp_injured_cover*2;
			                }
			            }
			            else if((strncmp(iofficer,"A09",3) == 0)||(strncmp(iofficer,"A04",3) == 0))
			            {
			            	/* �έ�(A09*)�B����(A04*) */
			                tmp_mdamage_cover = tmp_injured_cover*10;
			            }
			            else if(strncmp(trim(iofficer),"L",1) == 0)
			            {
			            	/* ���M  */
			                tmp_mdamage_cover = tmp_injured_cover*2;
			            }
			            else if(fTaishin == 'Y')
			            {
			            	/* �x�s�O�g�N   */
			                tmp_mdamage_cover = tmp_injured_cover*2;
			            }
			            else
			            {
			                if( strncmp(car_typei,"03",2) == 0 )
			                {
			                    tmp_mdamage_cover = tmp_injured_cover*12;
			                }
			                else
			                {
				            tmp_mdamage_cover = tmp_injured_cover*2;
			                }
			            }
		                }
		                else
		                {
		                    /* 960402,��L����(���إN���D03,04,19,21,22) ,��ӫO�O�B�C��B����200/400�U�Υ���O��,��ĳ�O�B�]�w200/400�U�C*/
		                    tmp_mdamage_cover = tmp_injured_cover*2;
		                }
		                /* 981208, ���p(A21*)���O�զX�אּ����ĳ */
		                /* 961128, �x���Υ�(A21*)���O�զX�אּ����ĳ */
		                /* 950824,�̳̫�@�ӰѼƥ�0 ��1 => ply_ins_type_302 �~����s�W,��ק� */
		                /* ���p�θΥ��~�����O�զX����ĳ*/
                            }

                            if (((strncmp(car_typei,"07",2) == 0) || (strncmp(car_typei,"15",2) == 0)) )
                            {
                            	/* 07,15����,��ĳ31,32�I�خ�,�Y���O���ۭt�B<10000,��ĳ��O���ۭt�B�@��=10000
                            	add by sylvia 103.07.08 (1030703003_C1) */
                            	/* 07.15���ب����վ��ĳ��O�զX (1111005003_SC1) */
                            }
                            else
                            {
                            	Insert_INS_TYPE("31", tmp_injured_cover, 0, tmp_mdamage_cover, 0, 0,0,
	                                        0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
                            }
	                }
	            }

                    if ( (f_32_exist == 'N') &&(f_149_exist == 'N') && (rlia == 'N') )
                    {
                        if ((fquota63 == 'Y')||(f245_265 == 'Y')||(fbz_2131 == 'Y')||(fquota_62 == 'Y')||(fkaxx == 'Y')||(fBEV == 'Y')||(fES == 'Y'))
                        {
                            /*���A��*/
                        }
                	else
                	{
                	    /* 101.11 29�I�ئۭt�B���O�����O�B�ŶZ�w�אּ(40,50,70,100)*/
	                    /* 101.03.07 ,�Y����O�榳�ӫO29�I�ءA���L�ĤT�H�d���I�A�h��O�N�|��ĳ31�B32�I�ءA
	                       �åB��29�I�ئۭt�B���O�����O�B�ŶZ(40,50,80,100)������ĳ31�B32�I�ثO�B���̾�
	                       (32�I�ثO�B�Ҭ�20�U)  */
	                    if (f_29_exist=='Y')
	                    {
	                        tmp_mdamage_cover = 200000 ;
	                    }
	                    else
	                    {
	                        /* 961128, �x���Υ�(A21*)���O�զX�אּ����ĳ */
	                        /* 950824,�̳̫�@�ӰѼƥ�0 ��1 => ply_ins_type_302 �~����s�W,��ק� */
	                        /* �έ�(A09*) �u����ĳ��O�զX */
	                        /* ���p�θΥ��~�����O�զX����ĳ*/
	                        /* �����վ��ĳ�O�B(1120309003_SC1) */
	                        if(fTaishin == 'Y')
	                        {
	                            tmp_mdamage_cover = 200000;
	                        }
	                        else if (strncmp(iofficer,"A04",3) == 0)
	                        {
	                            tmp_mdamage_cover = 1000000;
	                        }
	                        else
	                        {
	                            tmp_mdamage_cover = 500000;
	                        }
	                        /* 981208, ���p(A21*)���O�զX�אּ����ĳ */
		            }

			    if (((strncmp(car_typei,"07",2) == 0) || (strncmp(car_typei,"15",2) == 0)))
			    {
			    	/* 07,15����,��ĳ31,32�I�خ�,�Y���O���ۭt�B<10000,��ĳ��O���ۭt�B�@��=10000
			    	add by sylvia 103.07.08 (1030703003_C1) */
			    	/* 07.15���ب����վ��ĳ��O�զX (1111005003_SC1) */
	                    }
		            else
		            {
		            	Insert_INS_TYPE("32", 0, 0, tmp_mdamage_cover, 0, 0,0,
	                                        0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
	                    }
	                }
	            }

           	    /* 102.01 ,�ŦX�D���ӨT����jbarcode���� "�h�~��O21+50 ��"�A�u��ĳ31 32 */
           	    /* 960612, �s�W��ĳ ���ݪ��I34: */
           	    /*         ���Ф���ĳ 34        */
	            if ((strncmp(trim(iofficer),"P",1) != 0)&&(fIns21_50 =='N'))
	            {
	                if ((fquota63 == 'Y')||(fbz_2131 == 'Y')||(fquota_62 == 'Y')||(fkaxx == 'Y')||(fBEV == 'Y')||(fES == 'Y'))
	            	{
	            	    /*���A��*//*�����s�O(1080322003_SC1)*/
	            	}
	            	else if ( (fquota_63 == 'Y') ||
	            	         ((strncmp(iofficer,"A04",3) == 0) && (ISCAR_SET1(car_typei))) )
	            	{
	            	    /* �s�_�ҰϷs�W��ĳ��O�զX add by 061476 (1080322003_SC1) */
	            	    /* �����վ�O�B (1120309003_SC1) */
	            	    if ((f_31_exist == 'Y')||(f_32_exist == 'Y')||(f_149_exist == 'Y'))
	                    {
	            	        if ((f_27_exist == 'N')&&(fquota_63 == 'Y'))
	            		    Insert_INS_TYPE("27", 0,0,100000,0,0,0, 0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);

	            		if (f_34_exist == 'N')
	            		{
	            		    Insert_INS_TYPE("34", 10000, 100000, 200000, 0, 0,0,
	            			            0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);

	            		    for( i=1; i<=INS_COVER_NUM; i++)
	            		    {
	            		        if (i==1)
	            		        {
	            			    strcpy(icover_type_tmp,"001");
	            			    strcpy(iprem_cover_type_tmp,"001");
	            			    mcover_tmp = 10000;     /*�C�@�H���|���ݪ�*/
	            			}
	            			else if (i==2)
	            			{
	            			    strcpy(icover_type_tmp,"002");
	            			    strcpy(iprem_cover_type_tmp,"001");
	            			    mcover_tmp = 20000;    /*�C�@�ƬG���|���ݪ�*/
	            			}
	            			else if (i==3)
	            			{
	            			    strcpy(icover_type_tmp,"003");
	            			    strcpy(iprem_cover_type_tmp,"003");
	            			    mcover_tmp = 100000;   /*�C�@�H���G���ݪ�  */
	            			}
	            			else if (i==INS_COVER_NUM)
	            			{
	            			    strcpy(icover_type_tmp,"004");
	            			    strcpy(iprem_cover_type_tmp,"003");
	            			    mcover_tmp = 200000;    /*�C�@�ƬG���G���ݪ� */
	            			}
	            			Insert_PLY_INS_COVER("34"," ", " ",icover_type_tmp,iprem_cover_type_tmp,
	            				             mcover_tmp, 0, 0, 0, 0.00, 0, 0, 0, 0.00, 0.00 ,1);
	            		    }
	            		}
	            	    }
	            	}
	            	else
	                {
		            if ((f_34_exist == 'N')&&(chg_ori_flag == 0))
		            {
		                /* 31,32�I ���|��ĳ,�ҥH�����ˮ֬O���O�쥻���O31,32*/
		                /* chg_ori_flag �����Ұ��ܧ���O�զX */
		                if(ISCAR_SET1(car_typei))
		                {
		                    /*��ĳ=> �C�H/�C�ƬG ���|=5000/10000  �C�H/�C�ƬG ���G=50000/100000*/
		                    Insert_INS_TYPE("34", 5000, 50000, 100000, 0, 0,0,
		                		    0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
		                		/* Insert_PLY_INS_COVER => ��ĳ�O�զX(suggest =1 ) */
		                    for( i=1; i<=INS_COVER_NUM; i++)
		                    {
		                        if (i==1)
		                        {
		                	    strcpy(icover_type_tmp,"001");
		                	    strcpy(iprem_cover_type_tmp,"001");
		                	    mcover_tmp = 5000;     /*�C�@�H���|���ݪ�*/
		                	}
		                	else if (i==2)
		                	{
		                	    strcpy(icover_type_tmp,"002");
		                	    strcpy(iprem_cover_type_tmp,"001");
		                	    mcover_tmp = 10000;    /*�C�@�ƬG���|���ݪ�*/
		                	}
		                	else if (i==3)
		                	{
		                	    strcpy(icover_type_tmp,"003");
		                	    strcpy(iprem_cover_type_tmp,"003");
		                	    mcover_tmp = 50000;   /*�C�@�H���G���ݪ�  */
		                	}
		                	else if (i==INS_COVER_NUM)
		                	{
		                	    strcpy(icover_type_tmp,"004");
		                	    strcpy(iprem_cover_type_tmp,"003");
		                	    mcover_tmp = 100000;    /*�C�@�ƬG���G���ݪ� */
		                	}
		                	Insert_PLY_INS_COVER("34"," ", " ",icover_type_tmp,iprem_cover_type_tmp,
		                			     mcover_tmp, 0, 0, 0, 0.00, 0, 0, 0, 0.00, 0.00 ,1);
		                    }
		                }
		            }
		        }
	            }/* end of if ((strncmp(trim(iofficer),"P",1) != 0)&&(fIns21_50 =='N')) */

	            no_sug_5556 = 0;
	            if (fquota_62 == 'Y')
	            {
	                /* �_�@�Ϧ��W�B�I�~��ĳ55�B56�I�� add by 061476 (1080507001_SC1) */
	            	if ((f_29_exist == 'N') && (f_30_exist == 'N') && (f_301_exist == 'N') &&
	            	    (f_302_exist == 'N') && (f_149_exist == 'N') )
	            	{
	            	    no_sug_5556 = 1;
	            	}
	            }
	            /* 102.01 ,�ŦX�D���ӨT����jbarcode���� "�h�~��O21+50 ��"�A�u��ĳ31 32 */
	            if ((fIns21_50 =='N')&&(no_sug_5556 == 0))
	            {
                        if ((f_55_exist == 'N' || ins56_flag != 1)&&(f_51_exist == 'N'))
                        {
		            $SELECT a.icar_type,b.qpt,b.fpt
		               INTO $cy_type,$cy_qpt,$cy_fpt
		               FROM policy_last b,ply_relation_last a
		              WHERE a.ipolicy = b.ipolicy
		                AND a.ipolicy = $last_ply ;

                            if ((SQLCODE != SQLNOTFOUND) && (cy_fpt[0] == 'P') && (ISCAR_SET1(cy_type)) )
                            {
                                if (cy_qpt == 0 || fpt[0]!='P')
                                {
                                    cy_qpt = qpassenger ;
                                    qpt = qpassenger ;
                                }

                                if (cy_qpt != 0 && cy_qpt != 1)
                                {
                            	    /* �C�@�ƬG�O�B(man_qty) = ���ݫO�B*(�Ӹ��H��-1 )*/
                            	    /* 980223, �x�s�O�g�N   */
                                    if((fTaishin == 'Y')||
                                      ((f_31_exist == 'Y') && (f_32_exist == 'Y') && (fquota63 == 'Y')))
                                    {
                                        man_qty = (cy_qpt-1) * 1000000;
                                    }
                                    else if((fquota_62 == 'Y') &&
                                            ((f_31_exist == 'Y')||(f_32_exist == 'Y')||(f_149_exist == 'Y')))
                                    {
                                        /* �_�@�Ұϫ�ĳ�C�H200�U add by 061476 108.05.31 (1080507001_SC1) */
                                	man_qty = (cy_qpt-1) * 2000000;
                                    }
                                    else if((strncmp(iofficer,"A04",3) == 0)&&
                                            ((f_31_exist == 'Y')||(f_32_exist == 'Y')||(f_149_exist == 'Y')))
                                    {
                                    	/* �����վ��ĳ�O�B (1081024005_SC1)(1120309003_SC1) */
                                    	man_qty = (cy_qpt-1) * 5000000;
                                    }
                                    else
                                    {
                                	/* �אּ��ĳ�C�H100�U modify by sylvia 106.03.14 (1060302003_C1) */
                                	man_qty = (cy_qpt-1) * 1000000;
                                    }
                                    #ifdef PRINTF_FLAG
                                    printf("man_qty = [%ld]\n",man_qty);
                                    #endif
                                }
                                else
                                {
                            	    $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,'55','�I�ةӸ��H�Ƭ�0��1','1','E14',$iofficer);
                                }

		                /* 960430,�S��55 => ��ĳ 55*/
		                /* �e�榳�ӫO255�A����ĳ55 modify by 071004 (1110308005_SC3)*/
		                /* ���@��(���O115)����ĳ55 (1120316006_SC4) */
		                if ((equip_cmp(inequipment,"115") == False) && f_55_exist == 'N' && f_255_exist == 'N' && f_555_exist == 'N')
		                {
		            	    #ifdef PRINTF_FLAG
				    printf("�S�� 55 => ��ĳ55\n");
				    #endif
                                    /* 100.04.01,55�I�بC�@�ӤH��ˡB�C�@�ӤH����=> �X�֬��C�@�ӤH�ˮ`(death_cover) */
                                    if ( (sug_flag == 'Y') ||
                                       ( (f_31_exist == 'Y') && (f_32_exist == 'Y') && ((fquota63 == 'Y')||(f245_265 == 'Y')))||
                                       ( (f_31_exist == 'Y')||(f_32_exist == 'Y')||(f_149_exist == 'Y')) && (fquota_62 == 'Y') )
                                    {
                                        Insert_INS_TYPE("55", 0, man_qty/(cy_qpt-1), man_qty, 0, 0,0,
	                                                0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
	                            	f_sug_55 = 'Y';
	                            }
                                }

                                /* 960430, �S��56  => ��ĳ 56*/
                                if (ins56_flag != 1 && ins50_flag !=1 && ins166_flag !=1 && ins266_flag !=1)
                                {
                            	    if ( (sug_flag == 'Y') ||
                            	       ((f_31_exist == 'Y') && (f_32_exist == 'Y') && ((fquota63 == 'Y')||(f245_265 == 'Y')))||
                            	       ((f_31_exist == 'Y')||(f_32_exist == 'Y')||(f_149_exist == 'Y')) && (fquota_62 == 'Y') )
                            	    {
                            		#ifdef PRINTF_FLAG
                            		printf("�S�� 56 => ��ĳ56\n");
    					#endif
                                        /* 980416, 56��ĳ�O�B�� 3000000/2000 */
                                        /* �_�G�ϯS�w����,56�O�B��100�U/1000 */
                                        /* �_�@�ϯS�w����,56�O�B��200�U/1000 (1080507001_SC1) */
                                        /* ����(A04*)��ĳ,56�O�B��500�U/2000 (1081024005_SC1)(1120309003_SC1) */
                                        /* �έ�(A09*)��ĳ,56�O�B��300�U/2000 (1120301008_SC1) */
                                        if ((fquota63 == 'Y')||(f245_265 == 'Y'))
                                        {
                                            death_cover_56 = 1000000;
    	                                    lDaily_pay = 1000;
                                        }
                                        else if(fquota_62 == 'Y')
                                        {
                                    	    death_cover_56 = 2000000;
    	                                    lDaily_pay = 1000;
                                        }
                                        else if(strncmp(iofficer,"A04",3) == 0)
                                        {
                                    	    death_cover_56 = 5000000;
    	                                    lDaily_pay = 2000;
                                        }
                                        else if(strncmp(iofficer,"A09",3) == 0)
                                        {
                                    	    death_cover_56 = 3000000;
    	                                    lDaily_pay = 2000;
                                        }
                                        else
                                        {
                                            /* �אּ��ĳ�C�H100�U/���B1000 moidfy by sylvia 106.03.14(1060302003_C1) */
    	                                    death_cover_56 = 1000000;
    	                                    lDaily_pay = 1000;
    	                                }

    	                                /* �אּ�n�O�H��� modify by sylvia 114.06.18  (1140605006_C01) */

    	                  	        		strcpy(applicantn,trim(napplicant)); 	/* char(30)*/
				              	    					strcpy(paymenta,trim(apayment)); 			/* char(90)*/
				              	    					strcpy(ndeputy_appl2,trim(ndeputy_appl)); /* char(30)*/
				              	    					sLastChinese(applicantn,30);
				              	    					sLastChinese(paymenta,90);
				              	    					sLastChinese(ndeputy_appl2,30);


    	                                #ifdef PRINTF_FLAG
    	                                printf("---------------------birth[%s]\n",birth);
    	                                #endif

    		                        /* 980815, �]���s�Wdbirth ,dissue*/
    		                        /* �אּ�n�O�H��� modify by sylvia 114.06.18  (1140605006_C01) */
    		                        lDbirth_appl2 = (long)dbirth_appl;

    		                        #ifdef PRINTF_FLAG
    		                        printf("---------------------lDbirth_appl2[%ld]\n",lDbirth_appl2);
    			               				 #endif

    			                /* 960528 ,56�������i�����]�w =>pdiscount */
    			                /* �אּ�n�O�H��� modify by sylvia 114.06.18  (1140605006_C01) */
    				        			Insert_INS_TYPE("56", 0,0,death_cover_56, 0, 0,0,
    				                         0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);

    		                        /* 960528 ,56�������i�����]�w =>pdiscount */
    		                        if ((fapplicant[0]=='1') || (fapplicant[0]=='3') || (fapplicant[0] == '5'))
    		                        {
    		                            /*�۵M�H*/
    				            code = Insert_INS_TYPE_33(iapplicant,applicantn,lDbirth_appl2,paymenta,
    				                                      "2"," ",death_cover_56,0,
    				                                      (double)0,0,(double)0,0,pdiscount,0,applicantn,"1",
    				                                      "�k�w�~�ӤH","6",lDaily_pay,0,(double)0,"56",
    				                                      itel_appl,apayment_zip,apayment,1);
    				        }
    				        else
    				        {
    				            code = Insert_INS_TYPE_33(" ",ndeputy_appl2,lDbirth_appl2," ",
    				                                      "2"," ",death_cover_56,0,
    				                                      (double)0,0,(double)0,0,pdiscount,0," "," ",
    				                                      "�k�w�~�ӤH","6",lDaily_pay,0,(double)0,"56",
    				                                      itel_appl,apayment_zip,apayment,1);
    				        }
    		                        if (code != SUCCESS) return code;
    		                        ins56_sug_flag = 1;
    			            }
                                }
			    }
		        }
	            }/* end of if ((fIns21_50 =='N')&&(no_sug_5556 == 0)) */

	            /* 980511,98.08 �}�l����j��s�v*/
                    if (f_24_exist == 'N')
                    {
               	        strcpy(fcomp_24,"N");
	            }
	        }/* �T���Dbarcode end */


	        strcpy(iofficer, trim(iofficer));
	        /* ���p(A11)�W�[��ĳ�W�h  add by 061476 (1100330002_SC1)*/
	        if ((strncmp(iofficer,"A11",3) == 0) && (fIns21_50 =='N'))
	        {
	      	    if((f_31_exist =='Y')||(f_32_exist =='Y')||(f_149_exist =='Y'))
	      	    {
	      	        if (f_27_exist =='N')
	      	        {
	      		    Insert_INS_TYPE("27", 0,0,100000,0,0,0, 0.00,0.00,frate,pdiscount,
				             0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
			}
		    }
		    if ((strncmp(car_typei,"03",2) == 0)||(strncmp(car_typei,"22",2) == 0))
		    {
			if (ins56_flag != 1 && ins56_sug_flag != 1 && ins50_flag !=1 && ins166_flag !=1 && ins266_flag !=1)
			{
			    Insert_INS_TYPE("50", injured_cover_pa_50, death_cover_pa_50 ,damage_cover_pa_50,0, 0,0,0.00,0.00,tmp_frate2,
				             0.00,0,0,0," ",pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,1);
			}
		    }
	        }

	        /* ���M(L)�u�w��03�B22���ث�ĳ238 add by 061476 (1100429001_SC1) */
	        if (iofficer[0]=='L')
	        {
	      	    if((strncmp(car_typei,"03",2) == 0)||(strncmp(car_typei,"22",2) == 0))
	      	    {
	      	        if((f_31_exist =='Y')||(f_32_exist =='Y')||(f_149_exist =='Y')||
        		   (f_11_exist =='Y')||(f_1_9_exist =='Y'))
        		{
        		    if ((f_38_exist == 'N')&&(f_39_exist == 'N')&&(f_238_exist == 'N'))
        		    {
        		        Insert_INS_TYPE("238", 10000,0,50000,0,0,0,0.00,0.00
        				        ,frate,pdiscount,0,100,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
        		    }
        		}
	      	    }
	        }

	        if(ISCAR_SET1(car_typei))
	        {
    	            /* �g��A21161�BZ65032101, ����03,04,19,21,22 ,�Y����O29�I��,����ĳ29�I��, �O�B100�U
	               add by sylvia 105.07.01 (1050606008_C1) */
    	            /* �t�X�Υ��g�P�ӫ�ĳ��O�զX�s�W29�I��, �אּ�P�_�q���N��=CAB021* && �g��N����A*�BZ*
    	               modify by sylvia 105.08.03 (1050729007_C1) */
    	            /* if ((strncmp(iroute,"CAB0A21",7) == 0) && ((iofficer[0]=='A') || (iofficer[0]=='Z')))
    	               105.08.04 ౻T�q��, �Ƚw����  mark by sylvia 105.08.04 */
    	            /* �۷J�p11����O��ư_,���ĳ30�I�� modify by sylvia 105.08.17 (1050729007 _C1) */
    	            /* ����(A04*)��ӸΥ���ĳ30�I�� add by 061476 108.05.10 (1080212005_SC1) */
    	            /* �_�@�Ұϫ�ĳ30�I�� add by 061476 108.05.27 (1080507001_SC1) */
    	            /* �ηs(A10*)��ӫ�ĳ30�I�� add by 061476 109.05.13 (1090410009_SC1) */
    	            /* ���M(L*)��ӫ�ĳ30�I�� add by 061476 110.01.04 (1080212008_SC1) */
    	            if ((strncmp(iofficer,"A04",3) == 0)||(fquota_62 == 'Y')||(strncmp(iofficer,"A10",3) == 0)||
    	               (iofficer[0]=='L')||
    	              ((strncmp(iroute,"CAB0A21",7) == 0) && ((iofficer[0]=='A')||(iofficer[0]=='Z'))))
    	            {
    	                /* �����վ��ĳ�I�� (1080625004_SC1)(1081024005_SC1)(1120309003_SC1)  */
    	                if (strncmp(iofficer,"A04",3) == 0)
    	                {
    	                	/*if((f_31_exist =='Y')||(f_32_exist =='Y')||(f_149_exist == 'Y'))*/
    	                	if (f_27_exist =='N')
    	                	{
    	                		Insert_INS_TYPE("27", 0,0,200000,0,0,0, 0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
    	                	}

    	                	if((f_05_exist =='Y')||(f_09_exist =='Y')||(f_09_sug == 'Y'))
    	                	{
    	                		if (f_07_exist =='N')
    	                		{
    	                			Insert_INS_TYPE("07", 0, 0, 0, 0, 0,0, 0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
    	                		}
    	                	}

    	                	if((strncmp(car_typei,"03",2) == 0)||(strncmp(car_typei,"22",2) == 0))
    	                	{
    	                		if (f_05_exist =='Y' && f_161_exist == 'N')
    	                		{
    	                			Insert_INS_TYPE("161", 0, 0, 10000, 0, 0,0,0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
    	                		}


    	                		CarAgeMonth = 0;
    	                		CarAgeMonth = (iplyyear-atoi(pro_year))*12 + (iplymonth-qpro_month);
    	                		if ( (CarAgeMonth < 48)&&(f_12_exist == 'N')&&(f_28_exist == 'N')&&
    	                		    ((f_05_exist == 'Y')||(f_09_exist == 'Y')||(f_11_exist == 'Y')) )
    	                		{
    	                			tmp_lDamage75 = 0;
    	                			if (strstr(tmp_provision,"E;") == NULL)
    	                			{
    	                				tmp_lDamage75 = (long)(cover_01*(1.0-pdep_rate_year));
    	                			}
    	                			else
    	                			{
    	                				tmp_lDamage75 = (long)(damage_cover11_ori*(1.0-pdep_rate_year)*(1.0-pdep_rate_year));
    	                			}

    	                			/* ���קKE17�����~�T���A���P�_�O�_�i�ӫO28�I�� */
    	                			/* 28�I�ب��ѵs�D�I���²v�h��@�~ */
    	                			if (tmp_lDamage75 >= 150000)
    	                			{
    	                				Insert_INS_TYPE("28", 0, 0, 150000, 0, 0,0,0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
    	                				f_sug_28 = 'Y';
    	                			}
    	                		}
    	                	}

    	                	if((strncmp(car_typei,"03",2) == 0)||(strncmp(car_typei,"04",2) == 0)||
    	                	   (strncmp(car_typei,"19",2) == 0)||(strncmp(car_typei,"22",2) == 0))
    	                	{
    	                		if ((f_12_exist == 'N')&&(f_28_exist=='N')&&(f_sug_28=='N'))
    	                		{
    	                			Insert_INS_TYPE("12", 0, 0, 0, 0, 0,0,0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
    	                		}
    	                	}
    	                }

    	                /* �ηs�s�W��ĳ27�I��20�U add by 061476 112.03.06 (1120119004_SC1) */
    	                if (strncmp(iofficer,"A10",3) == 0)
    	                {
    	            	   if ((f_31_exist == 'Y') || (f_32_exist == 'Y')){
    	            	       if (f_27_exist == 'N')
    	            		    Insert_INS_TYPE("27", 0,0,200000,0,0,0, 0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
    	            	   }
    	                }

    	                /* �s�W301�I�� add by sylvia 106.04.17 (1060329005_C4) */
    	                /* �Y31�I�ثO�B1�p��70�U�A30�I�ئۭt�B����2 add by 061476 107.07.16 (1070629004_SC1) */
    	                /* �s�W124�I�� add by 061476 109.05.20(1090514002_SC1) */
    	                /* �s�W302�I�� modify by 071004 (1110308005_SC3)*/
    	                if ((f_29_exist == 'N') && (f_30_exist == 'N') && (f_301_exist == 'N') &&
    	                    (f_302_exist == 'N') && (f_124_exist == 'N') && (f_149_exist == 'N'))
    	                {
    	                    /* if ((f_31_exist =='Y')&&(injured_cover31 < 700000))
    	                    {
    	                        Insert_INS_TYPE("30", 0, 0, 10000000 , 2, 0, 0, 0.00, 0.00, frate, pdiscount, 0, 0, 0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
    	                	f_sug_30 = 'R'; // �]��Y�ۭt�B�S�|�ܦ�1�A�����ۭt�B�S�|��0(�J�p����)�A�]���h�@��R���ۭt�B��2�ϥ�
    	                    }
    	                    else
    	                    {
    	                	Insert_INS_TYPE("30", 0, 0, 10000000 , 1, 0, 0, 0.00, 0.00, frate, pdiscount, 0, 0, 0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
    	                	f_sug_30 = 'Y';
    	                    } */

    	                    if (fquota_62 == 'Y')
    	                    {
    	                        if ((f_31_exist =='Y') && (f_32_exist =='Y'))
    	                	{
    	                	    deduct_30 = 0; damager_cover_30 = 0;
    	                	    if ((injured_cover31 >= 2000000) && (damage_cover32 >= 500000))
    	                	    {
    	                	        deduct_30 = 3;
    	                		damager_cover_30 = 5000000;
    	                	    }
    	                	    else if ((injured_cover31 >= 700000) && (damage_cover32 >= 200000))
    	                	    {
    	                	        deduct_30 = 1;
    	                		damager_cover_30 = 2000000;
    	                	    }
    	                	    else if ((injured_cover31 >= 300000) && (damage_cover32 >= 200000))
    	                	    {
    	                		deduct_30 = 2;
    	                		damager_cover_30 = 2000000;
    	                	    }
    	                	    else
    	                	    {

    	                	    } /* �ӫO30�I�ءA32�I�ثO�B�����j��20�U */

    	                	    if ( deduct_30 != 0 )
    	                	        Insert_INS_TYPE("30", 0, 0, damager_cover_30 , deduct_30, 0, 0, 0.00, 0.00, frate, pdiscount, 0, 0, 0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);

    	                	    if (( deduct_30 == 3 ) && (f_27_exist =='N'))
    	                		Insert_INS_TYPE("27", 0,0,50000,0,0,0, 0.00,0.00,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
    	                	}
    	                    }
    	                    else
    	                    {
    	                        if ((f_31_exist =='Y') && (f_32_exist =='Y'))
    	                	{
    	                	    deduct_30 = 0;
    	                	    if ((injured_cover31 >= 2000000) && (damage_cover32 >= 500000))
    	                	    {
    	                	        deduct_30 = 3;
    	                	    }
    	                	    else if ((injured_cover31 >= 700000) && (damage_cover32 >= 200000))
    	                	    {
    	                		deduct_30 = 1;
    	                	    }
    	                	    else if ((injured_cover31 >= 300000) && (damage_cover32 >= 200000))
    	                	    {
    	                		deduct_30 = 2;
    	                	    }
    	                	    else
    	                	    {

    	                	    } /* �ӫO30�I�ءA32�I�ثO�B�����j��20�U */

    	                	    /* �ηs(A10)�Y���ӫO�Ϋ�ĳ�����I�ۭt�B�n�t���� (1120119004_SC1) */
    	                	    if (strncmp(iofficer,"A10",3) == 0)
    	                	    {
    	                	    	if (( f_55_exist == 'Y' || f_sug_55 == 'Y' ) && (deduct_30 > 0))
    	                	    	{
    	                	    		deduct_30 = deduct_30 * 100 + 55;
    	                	    	}
    	                	    }

    	                	    if ( deduct_30 != 0 )
    	                	        Insert_INS_TYPE("30", 0, 0, 10000000 , deduct_30, 0, 0, 0.00, 0.00, frate, pdiscount, 0, 0, 0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
    	                	}
    	                	else
    	                	{
    	                	    /* �h�~���ӫO31�B32�I�ءA�|��ĳ31�B32�B�O�B�ŦX�����A�]��������ĳ30�I�ؤ���(�P�\���T�{)*/
    	                	    deduct_30 = 3;
    	                	    Insert_INS_TYPE("30", 0, 0, 10000000 , deduct_30, 0, 0, 0.00, 0.00, frate, pdiscount, 0, 0, 0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
    	                	}
    	                    }
    	                }
    	                else
    	                {  /* ���W�B�d���I(29.30.301.149.124�I��) (1080507001_SC1) */
    	            	    if ((fquota_62 == 'Y') && (f_27_exist =='N'))
    	            	    {
    	            	        Insert_INS_TYPE("27", 0,0,50000,0,0,0, 0.00,0.00
			                        ,frate,pdiscount,0,0,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
    	            	    }
    	                }
    	            }
	        } /* end of ISCAR_SET1 */
            } /*end of  �T�� */
        } /* end of sug_flag == 'Y' */

      /* 101.07.11 , �h�~�S�O38�B39�I�ت̡A�Y�u��ĳ��O�զX�v���N�I�O�O�p��3000��(���t50�I��)�A
                     �B55+56�I�ثO�O�p��1300���̡A�h�u��ĳ��O�զX�v���A�s�W38�B39�I��
             ���k�G����ĳ38�B39�A�̫�J�p�X��O�զX�κ�X�O�O�A�A�ˮ֫O�O����A���ŦX�̦A�R��38�B39 */
      /* 101.06.06*/
      /* 102.01 ,�ŦX�D���ӨT����jbarcode���� "�h�~��O21+50 ��"�A�u��ĳ31 32 */
      /* 103.10.02 ����(B*)&�έ�(A09*)����A���ӫ~��,���A��ĳ38,39 add by sylvia */
      /* 103.10.12 ���O�p�{���M�ݫO��(131,132)�ӫ~��,���A��ĳ38,39 add by sylvia */
      /* �s�W����(4A,8A,9A,9B,2A,2B,2C, �Y���إN�X��2�X�����Ʀr��)����ĳ�I�� modify by sylvia 104.02.16(1040202006_C3) */
      /* ���ľ��c�q�~�H����X�O�I(125-136)����ĳ�I�� add by sylvia 104.06.02(1040407003_C6) */
      /* �N�ۥΨ���X�I(cnt_ins77 >0) || (cnt_ins79 >0) A�������I(cnt_ins118 >0) || (cnt_ins120 >0) || (cnt_ins122 >0) ||
                 ���ľ��c�q�~�H���T����X�I|| (cnt_125_136 > 0) �X�֨� cnt_non_sug    modify by sylvia 104.11.26 */
      /* �O�o�q��21/31����ĳ�I�� add by 061476 107.07.27 (1070314007_SC3) */
      /* ���Ф���ĳ238�I�� add by 061476 (1100510001_SC1) */
      /* 1101209008_SC1_�_�@�Ͻվ��ĳ��O��סA�_�@�ϫ�ĳ238*/
      /* �r�V�Z��X�I����ĳ add by sylvia 114.04.24 (1140409004_C01)*/
      if(((fBarcode=='Y')&&(strncmp(s_fcar_insure,"02",2)==0)) ||
         (fIns21_50 =='Y') ||(IsPlyB=='Y') || (cnt_ins131 >0) ||
         (cnt_ins132 >0) ||(car_typei[1] >= 65) ||(cnt_non_sug > 0) ||(fhi_price == 'Y')||
         ((ins1589_chg_flag >= 5) && (ins1589_chg_flag <= 8)) || (cnt_110_117 > 0) || (strncmp(iroute,"JB",2)==0)||
         (fquota63 == 'Y')||(f245_265 == 'Y')||(fbz_2131 == 'Y')||(ISSPC_BRAND(brandi))||(cnt_sprot > 0)||
         (insA_chg_flag > 0)||(ins7780_chg_flag>0)||(chg_ori_flag>0)||
         (fkaxx == 'Y')||(iofficer[0]=='P')||(iofficer[0]=='L')||(fBEV == 'Y')||
         (fES == 'Y')||(f25C01 == 'Y'))
      {
      	/* ��ĳ��O�@�ס@���O�@*/
      	fSug3839 = 'N';
      }else{
        if (fdmg_sug == 'Y')
        {
        	if (ISCAR_SET1(car_typei))
        	{
        	    if((f_31_exist =='Y')||(f_32_exist =='Y')||(f_149_exist =='Y')||
        	       (f_11_exist =='Y')||(f_1_9_exist =='Y'))
        	    {
        	        if ((f_38_exist == 'N')&&(f_39_exist == 'N')&&(f_238_exist == 'N'))
        	        {
        		    if(fquota_62 == 'Y')
        		    {
        		    	/* 1101209008_SC1_�_�@�Ͻվ��ĳ��O���*/
        		        Insert_INS_TYPE("238", 30000,0,150000,0,0,0,0.00,0.00
        				        ,frate,pdiscount,0,100,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
        		    }
        		    else
        		    {
        		        Insert_INS_TYPE("238", 10000,0,50000,0,0,0,0.00,0.00
        				        ,frate,pdiscount,0,100,0," ",pextra_charge, pbusiness,pcar_price,safe_rate,manage_rate,1);
        		    }
        		    printf("sug 238 \n");
        		}
        	    }
        	}
        }
      }
      /* 1080819 ����barcode�㨮���ѱM��,����N��ĳ�j���I add by sylvia (1030806002_C1) */
      /* 101.10 �A�]��tpl barcode, �����㨮���ѱM�� ���A��ĳ 21�I�ءA
                 �B�Y�h�~��21�L47�̡A�~�n��ĳ47�I��                  */
      /* 101.02.22 �[���G
        �b���N�I�������ɥhinsert 21�I�ط|�����D�A�D�ɪ��`�O�O�|�V�c */
      /* 980727, �����M�׷~�ȨS��21,47�A=>��ĳ */
      /*         21�Υ��N�I�O�v�N���p��*/
      /* �������ѱM��,�����ĳ�j���,������(�o�Ӧ~��-��O�_��~��) >= 24�Ӥ� �~���ĳ  (1040625001_C1) */
      if (fMotProj=='Y')
      {
         /* 1041222 TAC�����M��,����>1�~�Y�i��ĳ�j�� add by sylvia 104.12.22.(1041218004_C1) */
         /* printf("8862==iroute=[%s]car_age=[%d]\n",iroute,car_age);
         printf("�����ĳ�j��  ����:car_age = [%d]\n",car_age);  */
         /* if ((strlen(trim(irelative_ply))==0) && (comp_flag=='N') && (car_age >= 24)) */
         /* 1061120010_C1_�����㨮������OBarcode������ĳ�j���I */

         #ifdef PRINTF_FLAG
            printf("trace irelative_ply[%s]\n ",irelative_ply);
            printf("trace comp_flag[%c]\n ",comp_flag);
            printf("trace f_47_exist[%c]\n ",f_47_exist);
         #endif
         /* 47�I�ػP147�I�س����s�b,�~�|��ĳ47�I�� */
         /* 47�I�ؤ��i�P49�I�ئP�ɩӫO add by 061476 (1080116008_SC1) */
         /* �r�˰ӫ~���i�P�ɩӫO add by 061476 (1080319007_SC3) */
         /* ��L���ڤ���ĳ47�I�� modify by 061476 (1080708002_SC3) */
         if ((fdmg_sug == 'Y')&& (f_provision_L == 0))
         {
             if ((comp_flag=='Y')&&(f_47_exist !='Y')&&(f_147_exist !='Y')&&(f_49_exist !='Y')&&(ins56_flag != 1)&&(ins166_flag != 1)&&(ins266_flag != 1)){
                Insert_INS_TYPE("47", injured_cover_pa_47, death_cover_pa_47 ,damage_cover_pa_47,0,0,0,
                                 0.00,0.00,tmp_frate2,0.00,0,0,0," ",pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,1);
             }
         }
      }
   }  /*ply2f==TRUE*/

   /* 950826,��O�J�p�@�ߥ� "M" �p��覡 */
   strcpy(cal_way,"M");

   /**** �j���I ****/
   if (ply1f==TRUE)
   {
      fOtherIns47 = 0; /* 101.10*/
      fOtherIns50 = 0;
      fPreIns47   = 0; /* 101.10*/
      fPreIns31   = 0; /* 102.02*/
      damage_add_flag = 0;
      thief_add_flag = 0;
      qday = 0;
      mexpense = 0;
      mexp_disc = 0;
      pdis_rate = 0;
      cal_pdiscount = 0;
      main_discount = 0;
      pextra_charge = 0.00; /* ���[�O�βv */
      pbusiness     = 0.00; /* �~�޶O�βv */
      pcar_price    = 1.0;  /* �������[�O�Y��  add by sylvia 104.11.25 (1021211003_C1) */
      safe_rate = manage_rate = 0.0; /* T���� �w���κ޲z�[��O�T�� add by sylvia 104.12.02 (104111011_C1)  */
      strcpy(fdiscount,"N");
      strcpy(fcomp_24,"N");
      strcpy(idmg_rate, " ");   /* �|����쵹�w�]�� (1110322010_SC2) */
      strcpy(ibrg_rate, " ");
      dmg_factor = 0;
      brg_factor = 0;

      #ifdef PRINTF_FLAG
      printf("������O�j���ĳ��O47 \n");
      /* ��j�B���p���ťժ�, �H[���P+ID]�d�e��G�Ӥ�,�Y���d����N�I�O��, �N���A��ĳ47�I��
      modify by sylvia 105.07.19 (1050704006_C1) */
      #endif

      /* ��j�P�_�e�q�ʨ��f (1130510009_C13) */
      strcpy(brand_BEV, substring(brandi,7,2));

      /* 102.12.25�Gfix 32���ث�ĳ��O�զX���������B�� ��21+47�����������B�A��32���ث�ĳ��O�զX�ä���ĳ47�I�� */
      /* �]��ĳ��O�զX�Q�@�ߵ����|��ĳ47�A�ҥH ���������B�����|�O���t47���������B�A��32���ؤ��|��ĳ47�I��
         �G���ĳ��O�զX���������B���ӵ�����O�զX���������B�C
         ��: �Y�O�� �h�~�L47, ����31,32�� �A�h32�����٬O���|��ĳ ��47�� */
      if (ISMOT(car_typei))
      {
         if(*choice=='1')
         {
             if(strcmp(car_typei,"35") != 0)
             {
	         /* 101.10 �A�ק�D���Ӿ���barcode����ĳ��O���e  */
	    	 /* 980727, 32���ؤ���ĳ47 */
		 /* ��j => ��ĳ47�I��*/
	         #ifdef PRINTF_FLAG
	         printf("irelative_ply[%s]\n",irelative_ply);
	         printf("iplyyear[%d]\n",iplyyear);
	         printf("iplymonth[%d]\n",iplymonth);
	         #endif
	         /* �L���p�����ˮ֫e��G�Ӥ�O�_���P[����+ID]�����N�I�O��,���N����ĳ
	         modify by sylvia 105.07.19 (1050704006_C1) */
	         if(strlen(trim(irelative_ply))==0)
	         {
	             t_count = 0;
                     $select count(*) into $t_count
	                from wk_policy_302
	               where ipolicy_c = $last_ply;

	             if(strncmp(car_typei,"32",2)==0)
	             {
	                 if (fMotProj=='Y')
	                 {  /* �����㨮���ѱM��*/
	                     if ((fdmg_sug == 'Y') && (t_count == 0))
	                     {
             	                 fOtherIns47 = 1;    /* �������N�I�O��,��ĳ47 */
	              	     }
	                 }
	             }
	             else
	             {
	             	 /* ------ ��j�� �ݭn�t�~�P�_ ------ */
	                 /* JB�q����ĳ��O=���O modify by sylvia 105.06.13 (1050602005_C1) */
	                 /* �O�o�q��21/31��ĳ��O=���O modify by 061476 107.07.27 (1070314007_SC3) */
	                 /* ������O����ĳ�����I�� modify by 061476 109.02.03 (1080730006_SC1)(1091022004_SC1)(1100106005_SC1)(1100302002_SC1)==>�o�������j���I */
	                 /* ����(P*)��ĳ��O=���O modify by 061476 110.01.13 (1091209009_SC1) */
	                 /* ���M(L*)��j����ĳ���N modify by 061476 110.03.08 (1100129011_SC1)*/
	                 /* �q�ʨ�����ĳ�����I�� (1130510009_C13) */
	                 if(((fBarcode=='Y')&&(strncmp(s_fmot_insure,"02",2)==0))||
	                    (strncmp(iroute,"JB",2)== 0)||(strncmp(bzfrom,"21",2) == 0)||(strncmp(bzfrom,"31",2) == 0)||
	                    (strncmp(iroute,"KA02",4) == 0)||(strncmp(iroute,"KA03",4) == 0)||(strncmp(iroute,"KA04",4) == 0)||
	                    (strncmp(iroute,"KA05",4) == 0)||(strncmp(iroute,"KA06",4) == 0)||(iofficer[0]=='P')||(iofficer[0]=='L')||
	                    (strncmp(brand_BEV,"01",2) == 0))
	                 {
	              	     /* ��ĳ��O�@�ס@���O�@*/
	                 }
	              	 else
	              	 {
	              	     if ((fdmg_sug == 'Y') && (t_count == 0))
	                     {
	              	         fOtherIns47 = 1;    /* �������N�I�O��,��ĳ47 */
	              	     }
	                 }
	             }
	         }
	         else
	         {
	             /* chk ���p�����N�I�O�_���P�@�~����,�Y���O,������j,��ĳ47 */

	             /* �O�_��O110-112�I�� ----------------------------------*/
	             /* �Y�ȩӫO110-112�I�إB�W�L2�~����, ������j */
	             age_110 = 0 ;/* ����(�H�s�y�~��p��리) */
	             cnt_110 = 0; /* �ӫO110-113�I�حӼ� */
	             oth_110 = 0; /* �O���I�حӼ� */
	             $EXECUTE prep_110check INTO $age_110, $cnt_110, $oth_110
                        using $irelative_ply ;

	             /* ----------------------------------------------------------- */
                     t_count = 0;
		     /* $EXECUTE prep_chkChange INTO $t_count USING  $irelative_ply ,$license, $chk_dbirth, $bzfrom ; */
		     /* �t�X�O�o�q���X�s,���q���N����H��1�X��� modify by sylvia 106.01.25 (1060111005_C3) */
		     /* �ק��ˮ֡G�O�o�q���N���������@�P�A�_�h������j/��� modify by 061476 (1090430005_SC1) */
		     /* �W�[�ˮ֡G�޲z�H�ݤ@�P add by 061476 (1090616006_SC1) */
		     $EXECUTE prep_chkChange INTO $t_count USING  $irelative_ply, $license, $chk_dbirth, $bzfrom, $ileader ;
		     if (t_count==0)
		     {
		         /* ������j */
		         fmore21=0;  /* �L���N */

		         strcpy(sFullDBName, get_car_full_dbname(irelative_ply));
                         sprintf(buf2,"select count(a.ipolicy) from %s:ply_relation a, %s:policy b, %s:ply_ins_type c \
		                        where a.ipolicy = b.ipolicy and a.ipolicy = c.ipolicy \
		                          and a.ipolicy = '%s' and b.iassured = '%s' \
		                          and a.dply_end between '%s' and '%s' ",
                                 sFullDBName, sFullDBName, sFullDBName, irelative_ply, license, dbegin47, dend47);
                         $PREPARE pre_chkrel FROM $buf2;
		         $EXECUTE pre_chkrel INTO $t_count;


		         /* ------ ��j�� �ݭn�t�~�P�_ ------ */
		         /* ������O����ĳ�����I�� add by 061476 109.02.03 (1080730006_SC1)(1091022004_SC1)(1100106005_SC1)(1100302002_SC1) */
		         /* �q�ʨ�����ĳ�����I�� (1130510009_C13) */
		         if(strncmp(car_typei,"32",2)!=0)
		         {
		             if(((fBarcode=='Y')&&(strncmp(s_fmot_insure,"02",2)==0)) ||
		                 (strncmp(iroute,"JB",2)== 0)||(strncmp(bzfrom,"21",2) == 0)||(strncmp(bzfrom,"31",2) == 0)||
	                         (strncmp(iroute,"KA02",4) == 0)||(strncmp(iroute,"KA03",4) == 0)||(strncmp(iroute,"KA04",4) == 0)||
	                         (strncmp(iroute,"KA05",4) == 0)||(strncmp(iroute,"KA06",4) == 0)||(iofficer[0]=='P')||(iofficer[0]=='L')||
	                         (strncmp(brand_BEV,"01",2) == 0))
	                     {
		              	   /* ��ĳ��O�@�ס@���O�@*/
		             }
		             else
		             {
		                 if ((fdmg_sug == 'Y') && (t_count==0))
	                         {
		              	     fOtherIns47 = 1;
		              	 }
		             }
		         }
		         else
		         {
		             if (fMotProj=='Y')
		             {
		                 /* �����㨮���ѱM��*/
		                 if ((fdmg_sug == 'Y') && (t_count==0))
	                         {
		            	     fOtherIns47 = 1;
		            	 }
		             }
		         }
		     }
		     else
		     {
		         /* ���P�@�~���������N�I */
		         /* �h�~��110-112,���]���ֶW�L2�~,���~���O�զX110-112�����O,���|���ĳ��O113-115 */
		         if((cnt_110 > 0)&&(cnt_110==oth_110)&&(age_110>24))
		         {
		             fmore21=0;  /* �����L���N */
		             fOtherIns47 = 0;    /* ���j���ĳ47�I�� */
		             /* modify by sylvia 105.02.02 (1041230003_C1) */
		             $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,' ','������X�I��O�ɨ��I�W�L�G�~','1','E52',$iofficer);
		         }
		         else
		         {
    		             fmore21=1;  /* �����N */
                             t_count = 0 ;
                             /*$EXECUTE prep_chk01_11 INTO $t_count USING $v_ipolicy;*/ /* chk �h�~�O�_��������ѵs*/
                             /*if (t_count==0){*/
                             /* �h�~��������ѵs�̡A�@�˥i�H��ĳ47�ΰ������A�u�O���ಣ�s��barcode */
    	            	     t_count = 0;
    			     $EXECUTE pre_check_ins INTO $t_count USING $irelative_ply, "47";
    			     if (t_count>0)
    			     {
    			         /* �h�~��47 */
    			         fPreIns47   = 1;
    			         fOtherIns47 = 0;  /*�h�~��47,��O�|�۰ʫ�ĳ47  */
    			     }
    			     else
    			     {
    			         fPreIns47   = 0;
    			         fOtherIns47 = 0;  /*�h�~�L47,������L���N�I�ءA��O�|�b���N�I�O���ĳ47(32���ذ��~),�G���B�j���I����ĳ47  */
    			         $EXECUTE pre_check_ins INTO $t_count USING $irelative_ply, "31";
    			         if (t_count>0)
    			         {
    			             /* �h�~�L47,��31,32 */
    			             fPreIns31 = 1;
    			         }
    			         else
    			         {
    			             /* �s�W149�ˮ� add by sylvia 106.02.16 (1050601006_C4) */
    			             $EXECUTE pre_check_ins INTO $t_count USING $irelative_ply, "149";
    			             if (t_count>0)
    			             {
    			                 /* �h�~�L47,31,32,��149 */
    			                 fPreIns31 = 1;
    			             }
    			         }
    			     }
                         }
		     }
	         }
	     } /*  if(strcmp(car_typei,"35") != 0) end */
         }/*  if(*choice=='1') end */
      }/* if (ISMOT(car_typei)) end */
      else
      {
         /* �T����O�j�� => ��ĳ50+149�I��*/
         /* �ק��j��ĳ�I�سW�h modify by 061476 108.08.21 (1080710001_SC1) */
         if(strlen(trim(irelative_ply))==0)
         {
         	/* �T����O�j�� => ��ĳ50+149�I�� => ���F���s��barcode*/
         	/* �@���*/
         	if(*choice=='1')
         	{
         		/* ------ ��j�� �ݭn�t�~�P�_ ------ */
         		/* JB�q����ĳ��O=���O modify by sylvia 105.06.13 (1050602005_C1) */
         		/* ������O����ĳ�����I�� add by 061476 109.02.03 (1080730006_SC1)(1091022004_SC1)(1100106005_SC1)(1100302002_SC1) */
         		/* �q�ʨ�����ĳ�����I�� (1130510009_C13) */
         		if(((fBarcode=='Y')&&(strncmp(s_fcar_insure,"02",2)==0)) ||
         		   (strncmp(iroute,"JB",2)== 0)||(strncmp(bzfrom,"21",2) == 0)||(strncmp(bzfrom,"31",2) == 0)||
	                   (strncmp(iroute,"KA02",4) == 0)||(strncmp(iroute,"KA03",4) == 0)||(strncmp(iroute,"KA04",4) == 0)||
	                   (strncmp(iroute,"KA05",4) == 0)||(strncmp(iroute,"KA06",4) == 0)||(iofficer[0]=='P')||(iofficer[0]=='L')||
	                   (strncmp(brand_BEV,"01",2) == 0))
	                {
         		    /* ��ĳ��O�@�ס@���O�@*/
         		}
         		else
         		{
         		    t_count = 0;
         		    $Execute preIns50_cartype INTO $t_count Using $car_typei;
         		    if (t_count > 0)
         		    {
         		        /* chk �e���Ӥ�S����L���N�I */
         			t_count = 0;
         			$select count(*) into $t_count
         			   from wk_policy_302_50
         			  where ipolicy_c = $last_ply;

         			if ((fdmg_sug == 'Y') && (t_count == 0))
         			{
         			    fOtherIns50 = 1;
         			    fOtherIns3132 = 1;
         			}
         		    }
	 	         }
	 	}
	 	else
	 	{
	 		/* �q�ʨ���j����ĳ�����I�� (1130510009_C13) */
	 		if (strncmp(brand_BEV,"01",2) == 0)
	 		{
	 			/* ��ĳ��O�@�ס@���O�@*/
	 		}
	 		else
	 		{
	 			/* �O�N��n��ĳ31+32 */
	 			if ((strcmp(car_typei,"03") == 0) ||(strcmp(car_typei,"04") == 0) ||
	 			(strcmp(car_typei,"19") == 0) ||(strcmp(car_typei,"22") == 0))
	 			{
	 				if ((strncmp(bzfrom,"21",2) != 0)&&(strncmp(bzfrom,"31",2) != 0)&&
	 				(iofficer[0]!='P')&&(iofficer[0]!='L'))
	 				{
	 					/* chk �e���Ӥ�S����L���N�I */
	 					t_count = 0;
	 					$select count(*) into $t_count
	 					from wk_policy_302_50
	 					where ipolicy_c = $last_ply;

	 					if ((fdmg_sug == 'Y') && (t_count == 0))
	 					{
	 						fOtherIns3132 = 1;
	 					}
	 				}
	 			}
	 		}


	 	}
	 }
	 else
	 {
	     /* chk ���p�����N�I�O�_���P�@�~�����ΦP�@�O��ID(�D�L��),�Y�䤤���@���ŦX,������j,��ĳ50 */
	     /* �����p�渹���A��ĳ50�B149�I�� mark by 061476 108.08.21 (1080710001_SC1) */
 	 }
      }
     
      /* ����ĳ���N�I */
      if (((fOtherIns47+fOtherIns50)>0) || (fOtherIns3132 > 0)){
         pextra_charge = 0.00;
         pbusiness     = 0.00;
         pcar_price    = 1.0;  /* �������[�O�Y��  add by sylvia 104.11.25 (1021211003_C1) */
         safe_rate = manage_rate = 0.0; /* T���� �w���κ޲z�[��O�T�� add by sylvia 104.12.02 (104111011_C1) */

         /********** 100.06.27,�q���N���ĤG���q *****************/
         /* 1.�����g���N�� ibroker�A��γq���N�� iroute         */
         /* 2.����¾�ΥN�� icorp                                */
         /* ps.�M�ץ��O��W�O�����q���N���DA�椧�q���N��      */
         /*******************************************************/
         ibroker[0]=' '; ibroker[1]='\0';

         strcpy(iextra_charge, bzfrom);

         #ifdef PRINTF_FLAG
         printf("iextra_charge[%s],tmp_frate2=[%s]\n", iextra_charge,tmp_frate2 );
         #endif

         /* ���[�O�βv */
         /* �t�Xget_cm_extra_charge_car()�s�W�G�ӰѼ�:�I�O(int_ins)�B�O��(qply_period)
            modify by sylvia 103.05.21 (1030407005_C4) */
         /* get_cm_extra_charge_car()�s�W�G�ӰѼơG�q���N��(iroute)
            modify by 061476 110.02.04 (1090916003_SC5) */
         rc = get_cm_extra_charge_car( iextra_charge, tmp_frate2, &pextra_charge, &pbusiness, qply_period, tp_iins_type, iroute,  v_sMsg);
         if( rc != M_CM_OK){
         	  sprintf(tMsg,"���[�O�βv�N��(%s)�L���������[�O�βv",iextra_charge);
         	  $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$iroute,$tMsg,'1','E11',$iofficer);
         }

         #ifdef PRINTF_FLAG
         printf("pextra_charge[%f], pbusiness=[%f]\n", pextra_charge, pbusiness );
         #endif
         printf("3!!!!!CarAge()>>>>>cal_way[%s]\n",cal_way);

         code=SetFactor();
         if (code != SUCCESS) return code;

         strcpy(cal_car_id,trim(car_typei));
         int_cal_car_id=atoi(cal_car_id);
         short_prate = 1;

	 /* ��j��ĳ47/50�I�� */
	 if (fOtherIns47==1){
	 	Insert_INS_TYPE("47", injured_cover_pa_47, death_cover_pa_47 ,damage_cover_pa_47,
	 		        0, 0,0,0.00,0.00,tmp_frate2,0.00,0,0,0," ",pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,1);
         }else if (fOtherIns50==1){
         	/* 07.15���س�j����ĳ50�I�� (1111005003_SC1) */
         	if ((strncmp(car_typei,"07",2) != 0) && (strncmp(car_typei,"15",2) != 0))
         	{
         		Insert_INS_TYPE("50", injured_cover_pa_50, death_cover_pa_50 ,damage_cover_pa_50,
                                        0, 0,0,0.00,0.00,tmp_frate2,0.00,0,0,0," ",pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,1);
         	}
         }

         /* ��j��ĳ31+32�I�� */
         if (fOtherIns3132==1)
         {
         	  /* HCC�֫O�ҫ��ظm�G�b������H�U�|���A��HCC�p��
                     1. �e���~�����I�߮ץB�ߴڪ��B��0���߮ץ��
                     2. �e���~�ĤT�H�d���I���߮ץ��
                     3. �e���~���F�d�p�����߮ץ��(����+���d)
                     4. �̦���O��
                     5. ����L�h���~�߮צ���
                     6. �L�h�G�~�O�_�b�s�w��O�L�T���I
                     add by 061476 (1090803002_SC2) */
                  /* HCC�W�[�G��� (1120220002_SC3) */

                  /* ���d */
                  $select first 1 nvl(qpoint::INTEGER,-99999), iquery_num, nvl(qacc_sum_5y::INTEGER,0), nvl(qduty_sum_5y::INTEGER,0)
                     into $qpoint_3132, $iquery_num, $qlia_acc_3132, $qlia_duty_3132
                     from ca_trade_302
                    where iassured = $license
                      and itag = $tagnum
                      and iacc_kind = '2'
                      and icar_kind = '2'
                      and dquery >= date($dMinQuery)
                      order by dquery desc;

                  if (SQLCODE == SQLNOTFOUND)
                  {
                  	qpoint_3132 = 4;
                  	qlia_acc_3132 = 0;
                  	qlia_duty_3132 = 0;
                  }
                  if (qpoint_3132 == -9999)
                  {
                  	qpoint_3132 = 4;
                  }

                  strcpy(lia_class,itoa(qpoint_3132));   /* ���d�ż� */

                  $EXECUTE get_acc_factor
   		      INTO $plia_acc
   		     using '2',$fcar_class,$qpoint_3132,$tmp_frate2;

   		  rfmtdouble(plia_acc,"-&.&&",splia_acc);
   		  splia_acc[5] = '\0';                  /* ���d�Y�� */

   		  psex_age = psex_age2; /* �~�֩ʧO�Y�� */

          /*���� 03,22,04,19����, �B�j��<4��, ���N���d<=4��  �~��ĳ31,32     modify by sylvia 1140612 (1140605006_C01)*/
          printf(" 11671 �������������������� ipolicy = [%s] comp_class = [%s] qpoint_3132=[%d] qlia_acc_21=[%d]\n",last_ply,comp_class,qpoint_3132,qlia_acc_21);
   		if ((qpoint_3132 <= 4) && (qlia_acc_21 < 4))
   		{
   			/* 1140717 �ŧµo�H�㪾�u��ĳ03, 04���� */
   		    if((strncmp(car_typei,"03",2) == 0) ||(strncmp(car_typei,"04",2) == 0))
   		    {
   		  	        Insert_INS_TYPE("31", 2000000, 0, 4000000, 0,
                                  0,0,0.00,0.00,tmp_frate2,0.00,0,0,0," ",pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,1);
                        	Insert_INS_TYPE("32", 0, 0, 200000, 0,
                                  0,0,0.00,0.00,tmp_frate2,0.00,0,0,0," ",pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,1);
       		}
      }

                  /* ���� */
                  strcpy(dfirst_ply_3132," ");
                  $select first 1 nvl(qacc_sum_5y::INTEGER,0),nvl(qduty_sum_5y::INTEGER,0),dfirst_ply,
                          nvl(qdmg_acc_sum_5y::INTEGER,0),nvl(fhave_newa_c_2y::INTEGER,0)
                     into $qdmg_acc_3132, $qdmg_duty_3132, $dfirst_ply_3132,
                          $qdmg_acc_sum_3132, $fhave_newa_3132
                     from ca_trade_302
                    where iassured = $license
                      and itag = $tagnum
                      and iacc_kind = '1'
                      and icar_kind = '2'
                      and dquery >= date($dMinQuery)
                      order by dquery desc;

                  if (SQLCODE == SQLNOTFOUND)
                  {
                  	qdmg_acc_3132 = 0;
                  	qdmg_duty_3132 = 0;
                  	qdmg_acc_sum_3132 = 0;
                  	fhave_newa_3132 = 0;
                  	strcpy(dfirst_ply_3132," ");
                  }

                  qduty_sum_3132 = qdmg_duty_3132 + qlia_duty_3132;
                  ftrade = 'Y';

         } /*end ��j��ĳ31+32�I�� */

         code=Cal_ins_prem_302(INS_ptr,int_cal_car_id,0,dply_end,INS_ptr_33,
                               cover_vs_prem,ca_rate,min_car_factor,
                               car_model_factor,ca_sex_age_factor,
                               ca_car_model,insurance_type,userid);

         if (code != SUCCESS)
	 {
            if(code == M_CA_INS31){
              	$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�I�ثO�O�p����~','1','E15',$iofficer);
              	goto end;
            }else if(code == 4035){ /* M_CA_NCOVER_PREM */
                  $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�I�ثO�B�O�O��Ƥ��s�b','1','E16',$iofficer);
                  goto end;
            }else if(code==M_CA_OVER_75_PERCENT){
                  $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�I�ؤ��O�B�̭�o�Ӥ�_�p��A�H���`���«�A�h�@�~���¬��W��','1','E17',$iofficer);
                  goto end;
            }else if(code==4286){ /* M_CA_NSEX_AGE_FACTOR */
                  $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�~�֩ʧO�Y�Ƥ��s�b','1','E43',$iofficer);
                  goto end;
            }else{
              	memset(err_buf,0,sizeof(err_buf));
              	strcpy(err_buf,"Get302Data()9-2->Cal_ins_premium ERROR:");
              	strcat(err_buf,last_ply);
              	EWRITE(userid,code,err_buf);
              	return code;
            }
	 }
      }
      strcpy(comp_ins,"21");

      $EXECUTE nins INTO $ch_ins USING $comp_ins;

      strcat(pre_ch_ins_grp[0],trim(ch_ins));
      strcat(pre_ch_ins_grp[1],"�@");
      strcat(pre_ch_ins_grp[2],"�@");

      /* ����j���I����O�O:�@���B�ư��W���w���p���JB�Bcar147�B�S�w�g�쵥 */
      /* �j���I�����~���u�f���B�վ�A�@�ߧ�Ūcmn144�]�w modify by 061476 110.01.21 (1100118005_SC3) */
      #ifdef PRINTF_FLAG
      printf("8604-------f_cal_comp=[%c]\n",f_cal_comp);
      #endif

      if (f_cal_comp == 'Y')
      {
            /*if (strcmp(iins_cat,"Z") == 0)*/ /* mark by 061476 (1111019003_SC3) */
            if (ISMOT(car_typei))
            {
                if (qply_period==12)
			strcpy(iyear,"1");
		else
			strcpy(iyear,"2");
            }
            else
                strcpy(iyear,"0");

            /* Ū��cmn144�]�w���o�j���I�����B add by 061476 (1100118005_SC3) */

            /* icheck_busi => 0.�T�w 1.�W�� 2.�X�֩T�w 3.�X�֤W��2�P3���P����O�X���ˮ� */
            /* mservice          	����O            */
            /* mother_busi       	��L�~�ȶO��      */
            #ifdef PRINTF_FLAG
            printf(" ------- icheck_busi => 0.�T�w 1.�W�� 2.�X�֩T�w 3.�X�֤W��2�P3���P����O�X���ˮ� \n ");
            #endif
            mservice = 0;   mother_busi = 0;   mcomp_busi = 0;

            /* �ǤJ�Ѽ�:
            1.	�q���N��    2.	�O�v�O           3.	�~�ȱ���N��     4.	�X�@�j�I�O
            5.	�����I�O    6.	�I��(���I��)     7.	�~��          */

            memset(&o_stcomm, 0x00, sizeof(o_stcomm));
            o_qrec = 0;
            rtncode = cm_get_insure_comm(iroute, irate_type, iroute_comm, "C", iins_cat ,
                                         "21", iyear, &o_qrec, &o_stcomm, " ");

            #ifdef PRINTF_FLAG
            printf("Trace -- iroute = [%s] \n",  iroute);
            printf("Trace -- cm_get_insure_comm()  rtncode = [%ld],o_qrec=[%d] \n", rtncode,o_qrec);
            #endif

            if( rtncode != M_CM_OK )
            {
            	sprintf(tMsg,"���o�~�ȱ�����~:�q��[%s]�O�v�O[%s]�~�ȱ���[%s]�I�O[%s]�~��[%s]�I��[21]",
            	rtrim(iroute),irate_type,iroute_comm,iins_cat,iyear);

            	$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$iroute,$tMsg,'1','E07',$iofficer);
            	return -1000;
            	/*return rtncode;*/
            }
            else if ( o_qrec==0 )
            {
            	/* Ū��cmn144�W�h��ӥX��A�Y���I�O�� C �� X �ɡA�H C �I�O�A��@���A��l�I�O�h�_�C(1031022007_C1:�t�X�T���I��������������)
            	   add by 061476 (1100118005_SC3)*/
            	if ((strcmp(iins_cat,"C") == 0) || (strcmp(iins_cat,"X") == 0)){
            		memset(&o_stcomm, 0x00, sizeof(o_stcomm));
            		o_qrec = 0;
            		rtncode = cm_get_insure_comm(iroute, irate_type, iroute_comm, "C", "C",
            		                             "21", "0", &o_qrec, &o_stcomm, " ");
            		if(rtncode != M_CM_OK)
            		{
            			sprintf(tMsg,"���o�~�ȱ�����~:�q��[%s]�O�v�O[%s]�~�ȱ���[%s]�I�O[%s]�~��[%s]�I��[21]",
            			rtrim(iroute),irate_type,iroute_comm,iins_cat,iyear);

            			$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$iroute,$tMsg,'1','E07',$iofficer);
            			return -1000;
            			/*return rtncode;*/
            		}
            	}

            	if( o_qrec == 0 )
            	{
            		sprintf(tMsg,"���o�~�ȱ�����~:�q��[%s]�O�v�O[%s]�~�ȱ���[%s]�I�O[%s]�~��[%s]�I��[21]",
            		rtrim(iroute),irate_type,iroute_comm,iins_cat,iyear);

            		$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$iroute,$tMsg,'1','E07',$iofficer);
            		return -1000;
            		/*return rtncode;*/
            	}
            }

            strcpy(icheck_busi, o_stcomm.icheck_busi);
            mother_busi = o_stcomm.mother_busi;
            mservice = o_stcomm.mservice;

            if (icheck_busi[0]=='0')
            	mcomp_busi = (long)mother_busi;
            else if ((icheck_busi[0]=='1')||(icheck_busi[0]=='3'))
            {
            	if (icheck_busi[0]=='1'){
            		mcomp_busi = (long)mother_busi ;
            	}else{
            		mcomp_busi = (long)mother_busi + (long)mservice;
            	}
            }
            else if (icheck_busi[0]=='2')
            {
            	mcomp_busi = (long)mother_busi + (long)mservice;
            }

            mcomp_busi_ori = mcomp_busi;

            /* Ū��cmn144 end */

            /* �j���I����: �D�����~��, ���=0; �����~��, �̧C����� �T��73/�����@�~��60/�����G�~��80
            add by sylvia 105.08.19 (1050812001_C1) */
            if (strcmp(irate_type,"C") == 0)
                pre_discont = 0; /* �D�����~�Ȥ���� */

            mprem_21 = premium1; /* �j���I���e�O�O */
            mprem_21_ori = premium1_ori; /* �j���I���e�O�O */
            mbusiness2 = mbus_rule - mcomp_busi_ori;
            premium1_ori -= mcomp_busi_ori;
            premium1 -= mcomp_busi;

      }

      if (!Insert_INS_TYPE("21",injured_cover_comp,death_cover_comp,damage_cover_comp,0,premium1,mprem_21,
                            0.00,0.00,frate,0.00,0,0,0," ",pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,1))
      {
             #ifdef PRINTF_FLAG
             printf("malloc fail in struct INS_TYPE allocation!\n");
             #endif

             $CLOSE CUR_5;
             $FREE CUR_5;
             memset(err_buf,0,sizeof(err_buf));
             strcpy(err_buf,"Get302Data()8:");
             strcat(err_buf,last_ply);
             strcat(err_buf,"-21");
             EWRITE(userid,M_CM_NOT_MALLOC,err_buf);
             return M_CM_NOT_MALLOC;
      }
      Insert_INS_TYPE("21",injured_cover_comp,death_cover_comp,damage_cover_comp,0,premium1_ori,mprem_21_ori,
                               0.00,0.00,frate,0.00,0,0,0," ",pextra_charge,pbusiness,pcar_price,safe_rate,manage_rate,0);

      goto step_11;

      #ifdef PRINTF_FLAG
         printf("3.24 step_8-->ply[%s],ins_type[%s],insprem[%d]\n",last_ply, ins_type,premium1);
      #endif
   }

   #ifdef PRINTF_FLAG
      printf("3.25 broker[%s],iofficer[%s]\n",broker,iofficer);
   #endif

   strcpy(cal_car_id,trim(car_typei));
   int_cal_car_id=atoi(cal_car_id);

   #ifdef PRINTF_FLAG
      printf("3.27 ##### cal_car_id[%s]\n",cal_car_id);
   #endif

   /************************** STEP 9 ***********************************/

   #ifdef PRINTF_FLAG
      printf("3.28 >>>>step9-1\n");
   #endif

   /**** calculate aa, bb2, cc, dd, ee1, ee2, ee3 first ****/

   /***  �B�z�h���u��  *****/
   dmg_align = 0;
   brg_align = 0;
   lia_align = 0;

   dmg_align_1 = 0;
   brg_align_1 = 0;
   lia_align_1 = 0;

   code=SetFactor();
   if (code != SUCCESS) return code;

   #ifdef PRINTF_FLAG
      printf("3.29 >>>>step9-2\n");
   #endif
   /**** get bb11,bb12 ****/
   if ((fcar_class[0]=='1' &&
         strcmp(car_typei,"03")!=0 && strcmp(car_typei,"04")!=0 &&
         strcmp(car_typei,"19")!=0 && strcmp(car_typei,"21")!=0 &&
         strcmp(car_typei,"22")!=0 && (!(ISNEW_CAR1(car_typei)))) ||
        (fcar_class[0]=='2' &&
         strcmp(car_typei,"07")!=0 && strcmp(car_typei,"08")!=0 &&
         strcmp(car_typei,"14")!=0 && strcmp(car_typei,"15")!=0 &&
         (!(ISNEW_CAR2(car_typei)))))
   {
         strncpy(tmp_brand,brandi,6);
         tmp_brand[6]='\0';

         $SELECT pdmg_factor,pbrg_factor
            INTO $bb11,$bb12
            FROM car_model_align
           WHERE ibrand = $tmp_brand
             AND icar_type = $car_typei
             AND drate = (select drate from ca_rate_date
                           where icode = $frate
                             and itable = 'car_model_align');
          if (NOT_FOUND)
          {
             bb11=0;
             bb12=0;
             /*$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$tmp_brand,'�t�P�����[��O�Y�Ƨ䤣��','1','E09',$iofficer);*/
          }
   }
   else
   {
         bb11=0;
         bb12=0;
   }

   #ifdef PRINTF_FLAG
      printf("3.30 >>>>step9-3\n");
      printf("3.30 {step9.0010}:ply1f[%d],ply2f[%d],fany[%d]\n",ply1f,ply2f,fany);
      printf("fcomp_24[%s]\n",fcomp_24);
   #endif
   strcpy(sstpe," ");
   if (ply1f==TRUE || (ply2f==TRUE && fany==1))
   {
      /* �p��C���I�ثO�O */
      smdmg = 'N';
      smlia = 'N';
      smbrg = 'N';
      deduct30_1[0] = '\0';
      deduct30_2[0] = '\0';
      deduct30_3[0] = '\0';
      INS_ptr=Ifirst;
      while(INS_ptr)
      {
         #ifdef PRINTF_FLAG
            printf("INS_ptr->ins_type[%s], INS_ptr->sug_iins_type[%d]\n",INS_ptr->ins_type, INS_ptr->sug_iins_type);
         #endif

         strcpy(sstpe, trim(INS_ptr->ins_type));
         if (ISINS01(sstpe))
         {
            smdmg = 'Y';
         }
         /* �]113�B114�I�إi���[30�I�ءA�G�s�W�����d�D�I modify by 061476 (1100415003_SC6) */
         if ( (strcmp(sstpe,"31") == 0) || (strcmp(sstpe,"32") == 0) || (strcmp(sstpe,"149") == 0) ||
              (strcmp(sstpe,"231") == 0) || (strcmp(sstpe,"232") == 0) || (strcmp(sstpe,"249") == 0) ||
              (strcmp(sstpe,"133") == 0) || (strcmp(sstpe,"134") == 0) || (strcmp(sstpe,"113") == 0) ||
              (strcmp(sstpe,"114") == 0) || (strcmp(sstpe,"531") == 0) || (strcmp(sstpe,"532") == 0))
         {
               smlia = 'Y';
         }
         /* 101.04.30 */
         if ( (strcmp(sstpe,"11") == 0) || (strcmp(sstpe,"211") == 0) || (strcmp(sstpe,"96") == 0) || (strcmp(sstpe,"129") == 0 ) )
         {
               smbrg = 'Y';
         }

         if ( INS_ptr->sug_iins_type == 1)
         {
	    /* �_�G�Ұ�32�I�ثO�B����(40�U-->50�U),�G29�I�ثO�B1���ѭ�20�U������50�U (add by sylvia 105.09.19 (1050823002_C1)  */
	    if ((strcmp(sstpe,"29") == 0) && (strcmp(upd29_cov1,"Y") == 0))
	    {
	    	if (INS_ptr->injured_cover == 200000)
		{
			INS_ptr->injured_cover = 500000;
		}
	    }
         }

         INS_ptr=INS_ptr->next;
      }

      #ifdef PRINTF_FLAG
         printf("smdmg[%c],smlia[%c],smbrg[%c]\n",smdmg,smlia,smbrg);
         printf("deduct30_1[%s],deduct30_2[%s],deduct30_3[%s]\n",deduct30_1,deduct30_2,deduct30_3);
      #endif

      sprintf(stmt, "SELECT %s FROM %s WHERE %s",
                    " imain_ins ",
                    " insurance_type",
                    " iins_type = ? ");
      $PREPARE smiad FROM $stmt;

      strcpy(sstpe," ");
      INS_ptr=Ifirst;
      while(INS_ptr)
      {
         strcpy(sstpe,trim(INS_ptr->ins_type));
         $EXECUTE smiad INTO $simain_ins USING $sstpe;
         if (SQLCODE == SQLNOTFOUND)
         {
           INS_ptr=INS_ptr->next;
           continue;
         }
         strcpy(simain_ins,trim(simain_ins));
         strcpy(sstpe,trim(sstpe));
         if (ISINS01(simain_ins))
         {
            if (smdmg == 'N'){   /* �R���u�����[�I�ӨS���D�I���I�� */
                Delete_INS_TYPE(INS_ptr);
            }
         }
         if ((strcmp(simain_ins,"31") == 0) || (strcmp(simain_ins,"32") == 0) ||
             (strcmp(simain_ins,"231") == 0) || (strcmp(simain_ins,"232") == 0) ||
             (strcmp(simain_ins,"531") == 0) || (strcmp(simain_ins,"532") == 0))
         {

            if (smlia == 'N'){   /* �R���u�����[�I�ӨS���D�I���I�� */
               /* �쥻�u����O51,���M�S����ĳ31,32,���n�O�d�ഫ�᪺55,56
               ex.����@���(iquota[1->4]= 6101,6102),�i��u�O51,�B���|��ĳ31,32 */
            	if ((f_51_exist == 'Y')&&(strcmp(sstpe,"55")==0 || strcmp(sstpe,"56")==0)){

            	   continue; /*�h�~��O51,��O�S�S����ĳ31,32,�����n�O�d�ഫ�᪺55,56 */
            	}else{
                  Delete_INS_TYPE(INS_ptr);

               }
            }
         }
         if ((strcmp(simain_ins,"11") == 0) || (strcmp(simain_ins,"211") == 0) || (strcmp(simain_ins,"96") == 0) || (strcmp(simain_ins,"129") == 0))
         {

            if (smbrg == 'N'){  /* �R���u�����[�I�ӨS���D�I���I�� */

               Delete_INS_TYPE(INS_ptr);
            }
         }

         /* �]38�B39����R�����I�� add by 061476 (1100119001_SC7) */
         if (strcmp(sstpe,"38")==0 || strcmp(sstpe,"39")==0)
         {
               Delete_INS_TYPE(INS_ptr);
         }

         /* 30�I�ئۭt�B�̷�31/32�O�B�M�w (1071203004_SC3) */
         /* if ( INS_ptr->sug_iins_type == 1 && strcmp( sstpe, "30") == 0 ) */
         if (strcmp( sstpe, "30") == 0)
         {
             INS_ptr->deduct = deduct_30;
         }

         /* 301�I�ؤ��30�I�� (1071203004_SC3) */
         if (strcmp(sstpe, "301") == 0 )
         {
             INS_ptr->deduct = deduct_301;
         }

         /* 530�I�ؤ��30�I��  add by sylvia 114.04.24 (1140409004_C01) */
         if (strcmp(sstpe, "530") == 0 )
         {
             INS_ptr->deduct = deduct_530;
         }

         /* 960612, ���ݪ��I34 ,�h�~�L34,��O��ĳ��34 => �p��O�O*/
         if (strcmp(sstpe,"34") == 0){
            if ( (f_34_exist == 'N' && INS_ptr->sug_iins_type == 1)||(chg_ori_flag > 0) )
            {
            	#ifdef PRINTF_FLAG
            	printf("�h�~�L34,��O��ĳ��34\n");
            	printf("�h�~�L34,��O��ĳ��34 ,sstpe=[%s]\n",sstpe);
            	printf("car_typei=[%s]\n",car_typei);
            	printf("frate=[%s]\n",frate);
            	printf("fdiscount=[%s]\n",fdiscount);
            	printf("pdiscount=[%f]\n",pdiscount);
            	printf("v_sMsg=[%s]\n",v_sMsg);
            	#endif


               /* �p��O�O */
               short_prate_tmp = 1.0 ;
               mdiscount_tmp   = 0 ;
               adjust_rate_tmp = 0.0;
               dinstype=atoi(sstpe);

               /********** 100.06.27,�q���N���ĤG���q *****************/
               /* �����g���N�� ibroker�A��γq���N�� iroute           */
               /* ���s�W�ǤJ�ѼơA�䤤v_fstart = "Y" , ibroker=" "    */
               /*(iofficer�u���bv_fstart<>"Y"�Bv_fstart<>"N" �ɤ~�Ψ�)*/
               /*******************************************************/
               /* 97.11�J�O�v�ۥѤ�  ,add ibroker */
               /* �t�Xcal_ply_ins_cover()�s�W�Ѽ� qply_period �O��O�� add by sylvia(1030407005_C4)  */
               rtncode = cal_ply_ins_cover( &dinstype, IfirstPlyInsCover1, car_typei, frate,
                                            &short_prate_tmp, "", fdiscount, "", mdiscount_tmp,
                                            &pdiscount, "",&adjust_rate_tmp,0.0,ibroker,0.0,0.0,0.0,0.0,
                                            "Y",iofficer,iroute, irate_type,iroute_comm,bzfrom,"P",
                                             qply_period,v_sMsg);
               if( rtncode != M_CM_OK)
               {
		            if (rtncode==M_CA_34_1_NOT_FOUND){
		            	$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,'34','�I��cal_ply_ins_cover()���~3','1','E39',$iofficer);
		            	goto end;
		            }else if (rtncode==M_CA_34_2_NOT_FOUND){
		            	$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,'34','�I��cal_ply_ins_cover()���~3','1','E39',$iofficer);
		            	goto end;
		            }else{
		               return rtncode;
		            }
		}

		/* �t�X�����ҰϷs�W���O�զX�ӼW�[ add by 061476 (1080308004_SC1) */
		if ( INS_ptr->sug_iins_type == 0 )
		{
			rtncode = cal_ply_ins_cover( &dinstype, IfirstPlyInsCover, car_typei, frate,
                                            &short_prate_tmp, "", fdiscount, "", mdiscount_tmp,
                                            &pdiscount, "",&adjust_rate_tmp,0.0,ibroker,0.0,0.0,0.0,0.0,
                                            "Y",iofficer,iroute, irate_type,iroute_comm,bzfrom,"P",
                                             qply_period,v_sMsg);

                        if( rtncode != M_CM_OK)
                        {
		            if (rtncode==M_CA_34_1_NOT_FOUND){
		            	$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,'34','�I��cal_ply_ins_cover()���~4','1','E39',$iofficer);
		            	goto end;
		            }else if (rtncode==M_CA_34_2_NOT_FOUND){
		            	$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,'34','�I��cal_ply_ins_cover()���~4','1','E39',$iofficer);
		            	goto end;
		            }else{
		               return rtncode;
		            }
		        }
		}
	    }
         }

         if (strcmp(sstpe,"115") == 0){
            if ( f_115_exist == 'N' && INS_ptr->sug_iins_type == 1 )
            {
            	#ifdef PRINTF_FLAG
            	printf("�h�~�L115,��O��ĳ��115\n");
            	printf("�h�~�L115,��O��ĳ��115 ,sstpe=[%s]\n",sstpe);
            	printf("car_typei=[%s]\n",car_typei);
            	printf("frate=[%s]\n",frate);
            	printf("fdiscount=[%s]\n",fdiscount);
            	printf("pdiscount=[%f]\n",pdiscount);
            	printf("v_sMsg=[%s]\n",v_sMsg);
            	#endif


               /* �p��O�O */
               short_prate_tmp = 1.0 ;
               mdiscount_tmp   = 0 ;
               adjust_rate_tmp = 0.0;
               dinstype=atoi(sstpe);

               /********** 100.06.27,�q���N���ĤG���q *****************/
               /* �����g���N�� ibroker�A��γq���N�� iroute           */
               /* ���s�W�ǤJ�ѼơA�䤤v_fstart = "Y" , ibroker=" "    */
               /*(iofficer�u���bv_fstart<>"Y"�Bv_fstart<>"N" �ɤ~�Ψ�)*/
               /*******************************************************/

               /* 97.11�J�O�v�ۥѤ�  ,add ibroker */
               /* �t�Xcal_ply_ins_cover()�s�W�Ѽ� qply_period �O��O�� add by sylvia(1030407005_C4)  */
               rtncode = cal_ply_ins_cover( &dinstype, IfirstPlyInsCover1, car_typei, frate,
                                            &short_prate_tmp, "", fdiscount, "", mdiscount_tmp,
                                            &pdiscount, "",&adjust_rate_tmp,0.0,ibroker,0.0,0.0,0.0,0.0,
                                            "Y",iofficer,iroute, irate_type,iroute_comm,bzfrom,"P",
                                             qply_period,v_sMsg);
               if( rtncode != M_CM_OK) {
		            if (rtncode==M_CA_34_1_NOT_FOUND){
		            	$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,'115','�I��cal_ply_ins_cover()���~3','1','E39',$iofficer);
		            	goto end;
		            }else if (rtncode==M_CA_34_2_NOT_FOUND){
		            	$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,'115','�I��cal_ply_ins_cover()���~3','1','E39',$iofficer);
		            	goto end;
		            }else{
		               return rtncode;
		            }
	       }
	    }
         }

         #ifdef PRINTF_FLAG
            printf("sstpe[%s],INS_ptr->ins_type[%s]\n",sstpe,INS_ptr->ins_type);
         #endif
         INS_ptr=INS_ptr->next;
      }

      #ifdef PRINTF_FLAG
      printf("==>line 4297 last_ply[%s]\n", last_ply );
      #endif

      if (fcard_class[0] == '2'){
         /***********************    102.11.12 ���N�I�ߴګY�Ƨﲾ�즹�B    *******************/
         /* 9912, ���騮�d�ߴګY�Ƨ�����T��� ca_trade_302 �A�������d���T��h��J�p����ѥ���p��ߴګY�ơA�üg�Jca_no_trade_302 */
         /* ���d���T��G
            (1) �Ӥ���u�O�����I�B�L�T���I���k�H�B�۵M�H�C
                ���ܹL��ᦳ�i��O�۵M�H�Ϊk�H�A�ҥH�W�z�L��B�z��h�B�z�C
            (2) �k�H�L���P�G
                ���ܹL���O�k�H�A���L����ɥ�����J���P�A�ҥH�����p���i�঳�L���C
            (3) �k�H���~�����P�G
                �k�H���~�����P���w�q�O�G��l�O��]�@�w�O�k�H�A�B�νs�n�@�ˡA�ҥH�����p�]���i�঳�L���C
               => �G��(1)���p�n�B�z�L���    	          */
         /* �w��䤣���I�ơB�żƪ̡A����X�ӵ���ƨ��˵��~�A�����H�ߴګY�Ƥ��[�����~��J�p�ӵ���� */
         f_get_ca_trade_sug = 'N';

         #ifdef PRINTF_FLAG
         printf("Trace -- dply_begin = [%ld] \n",  dply_begin);
         printf("Trace -- dTradEnd = [%ld] \n",  dTradEnd);
         #endif

         if (dply_begin <= dTradEnd)
         {    	/* dply_begin:��O��ͮĤ� = ����O������ */
         	printf("Trace -- before get_ca_trade_302() \n");
         	printf("Trace -- last_ply = [%s] \n",  last_ply);

         	/* 102.11.12 �̭��O�զX�B��ĳ��O�զX�������I�A�M�w�n�ǤJ�������I���O�N��(sAcc_kind[0])(sAcc_kind[1]�����d�Y�����O�N��(=2))
                   iacc_kind[0][ 1:����(Ex.01�B08�I��); 3:�������l�榸(Ex.105�B85�I��); 4:�������l���p(Ex.05�B09�I��) ]
                   iacc_kind[1][ �ثe�u���@�ءA�T�w�� '2:���d' ] */
                sAcc_kind[0] = '0';  sAcc_kind[1] = '2';  /* ���d(�@��) */

                if ((f_131_exist == 'Y' ) || (f_132_exist == 'Y' ))
                    sAcc_kind[1] = '5';  /* ���d(�p�{��) */

                if (strcmp(car_typei,"CS")==0)
                    sAcc_kind[1] = '0';  /* �R�q�Τ��d */

                /*** ���O�զX�����I ***/
                /* �Ҧ������I�ߴڬ����אּ�����T�J�`�p�� modify by 061476 107.02.22 (1070212002_SC3)*/

                sAcc_kind[0] = '1';
            CA_TRADE:
               #ifdef PRINTF_FLAG
               printf("trace f_get_ca_trade_sug[%c]\n ",f_get_ca_trade_sug);
               printf("trace sAcc_kind[%s]\n ",sAcc_kind);
               #endif

               ftrade = 'Y'; /* �d���T */
               if (sAcc_kind[1] == '2')
               {  /* �@�����T�Y�� */

   		         rtncode = get_ca_trade_302(assuredf,license,tagnum,sCar_kind,
   		                                    sAcc_kind,dMinQuery,query_num_dmg,
   		                                    query_num_lia,&qdmg_point_renew,
   		                                    &lia_class_renew,&qdmg_acc_sum_renew,
   		                                    &qlia_acc_sum_renew,trade_msg_no_dmg,
   		                                    trade_msg_no_lia,query_num_unknown,
   		                                    &qunknown_point_renew,&qunknown_acc_sum_renew,
   		                                    trade_msg_no_unknown,
   		                                    &qdmg_acc_sum_5y_renew,&qlia_acc_sum_5y_renew,
   		                                    &qduty_sum_5y_renew,&qdmg_acc_sum_5y_pure_renew,
   		                                    &qacc_sum_5y_renew,&fhave_newa_c_2y_renew,dfirst_ply);

   		         if (rtncode != M_CM_OK)
   		         {
   		         	/* [�d���T��]��"�L�ߴګY�Ƹ��" */
   		         	strcpy(s_no_trade_type," ");
   		         	ftrade = 'N';  /*HCC�P�_�O�_�d�����T add by 061476 (1090803002_SC2) */
   		 		rtncode= get_ca_no_trade_302(last_ply,&qdmg_point_renew,
   		 			                     &lia_class_renew,&qunknown_point_renew,s_no_trade_type);

                                #ifdef PRINTF_FLAG
   		 		printf("Trace -- get_ca_no_trade_302 rc = [%ld]\n",  rc);
   		 		printf("Trace -- last_ply               = [%s] \n",  last_ply);
   		 		printf("Trace -- qdmg_point_renew       = [%d] \n",  qdmg_point_renew);
   		 		printf("Trace -- lia_class_renew        = [%d] \n",  lia_class_renew);
   		 		printf("Trace -- s_no_trade_type        = [%s] \n",  s_no_trade_type);
   		 		#endif
   		 		if (rtncode != M_CM_OK)
   		 		{
   		 			if(rtncode == M_NOTRADE_NO_RECORD)
   		 			{
   		 				/* �A�T�{�@���O�_�����d���T��A�Y�O�A�h�A�p��@���ߴګY�� */
   		 			  	#ifdef PRINTF_FLAG
   		 			  	printf("Trace -- before IsNOTrade302Case() \n");
   		 			  	#endif

   		 			  	rtncode = IsNOTrade302Case(sclmdb,car_typei,tagnum,assuredf,last_ply,s_no_trade_type);

   		 			  	if (rtncode == 1 ){
   		 			  		#ifdef PRINTF_FLAG
   		 			  		printf("Trace -- before ca_accident_record_next() \n");
   		 			  		#endif
   		 			  		rtncode = ca_accident_record_next(last_ply,last_dply_bgn,car_typei,pdmg_acc_last,lia_class_last,punknown_acc_last,
                                                                   fedr_class,dExecdate,&qdmg_point_renew,&lia_class_renew,&qunknown_point_renew) ;

                                                        if (rtncode == M_CM_OK){
                                                        	#ifdef PRINTF_FLAG
                                                        	printf("Trace --  ca_accident_record_next() OK \n");
                                                        	printf("Trace -- TEST = [%d] \n",  qdmg_point_renew);
                                                        	printf("Trace -- TEST = [%d] \n",  lia_class_renew);
                                                        	#endif
                                                        	/* ���s�p�⧹�� => �g�Jca_no_trade_302 */
   		 					        if (qdmg_point_renew >= 0 ){
   		 					        	sprintf(s_qdmg_point,"+%03d",qdmg_point_renew); /* +000,+001 ...*/
   		 					        }else{
   		 					                sprintf(s_qdmg_point,"%04d",qdmg_point_renew);  /* -001,-002 ...*/
   		 					        }
   		 					        sprintf(s_lia_class,"%02d",lia_class_renew);        /* 00,01 ...*/

   		 					        if (qunknown_point_renew >= 0 ){
   		 					        	sprintf(s_qunknown_point,"+%03d",qunknown_point_renew); /* +000,+001 ...*/
   		 					        }else{
   		 					        	sprintf(s_qunknown_point,"%04d",qunknown_point_renew);  /* -001,-002 ...*/
   		 					        }

   		 					        $WHENEVER SQLERROR CONTINUE;

   		 					        $INSERT INTO ca_no_trade_302 Values
   		 					        ($last_ply,$dply_begin,$s_lia_class,$s_qdmg_point,$s_no_trade_type,$dExecdate,"system",current,"system",current,s_qunknown_point);

   		 					        #ifdef PRINTF_FLAG
   		 					        printf("Trace -- INSERT INTO ca_no_trade_302 SQLCODE[%d] \n",SQLCODE);
   		 					        #endif
   		 					        $WHENEVER SQLERROR GOTO get302_err;

   		 					        $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$outMsg,'[�d���T��][���d���T��]�Ҭd�L�Y��,�w���s�P�_��[���d���T��]�í���OK','2','E18',$iofficer);
   		 					}else{
   		 						/*�t���:���b[�d���T��]�A�]���b[���d���T��] */
   		 			    	  	        #ifdef PRINTF_FLAG
   		 			    	  	        printf(" Trace ---[�d���T��](ca_trade_302)�B[���d���T��](ca_no_trade_302)�ҵL���\n");
   		 			    	  	        #endif

   		 			    	  	        /*ftrade = 'N';  HCC�P�_�O�_�d�����T add by 061476 (1090803002_SC2) */
   		 			    	  	        /* E19-E26�אּ�n�J�p�A���C�J�ګO���`���� modify by 061476 109.02.18 (1090113006_SC1) */
   		 			    	  	        /* E19-E26����O�J�p add by 061476 108.12.10 (1081118002_SC1) */
   		 			    	  	        if (f_get_ca_trade_sug=='N'){
   		 			    	  	        	$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$outMsg,'�d�L�Y��_X','1','E19',$iofficer);
   		 			    	  	        	/*$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$outMsg,'�d�L�Y��_X','2','E19');
   		 			    	  	        	goto end;*/
   		 			    	  	        }else{
   		 			    	  	        	$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$outMsg,'�d�L�Y��_X(��ĳ)','1','E20',$iofficer);
   		 			    	  	        }
   		 			    	  	}
   		 			    	}else{
   		 			    		/*�t���:���b[�d���T��]�A�]���b[���d���T��] */
   		 			    		#ifdef PRINTF_FLAG
   		 			    		printf(" Trace ---[�d���T��](ca_trade_302)�B[���d���T��](ca_no_trade_302)�ҵL���,�B�O�椣��[���d���T��] \n");
   		 			    		printf("  Trace -- IsNOTrade302Case() = 0 \n");
   		 			    		#endif

   		 			    		/*ftrade = 'N';  HCC�P�_�O�_�d�����T add by 061476 (1090803002_SC2) */
   		 			    		if (f_get_ca_trade_sug=='N'){

   		 			    		    /* add by 071004 (1101112005_SC1_�J�p���~�T��E21�W�[�P�_�T��)*/
   		 			    		    if(qply_period_pre <= 4)
   		 			    		    {
   		 			    		    	$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$outMsg,'�ӫO�u���d�L���T�Y�ơA�Э��s����','1','E21',$iofficer);
   		 			    		    }
   		 			    		    else
   		 			    		    {
   		 			    		    	$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$outMsg,'�d�L�Y��_Y','1','E21',$iofficer);
   		 			    		    }

   		 			    		}else{
   		 			    			$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$outMsg,'�d�L�Y��_Y(��ĳ)','1','E22',$iofficer);
   		 			    		}
   		 			    	}
   		 			}else{
   		 				printf(" Trace ---[���d���T��](ca_no_trade_302)����ơA�������(��)���d�Y�ƪť�\n");
   		 				$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$outMsg,'�����(��)���d�Y�ƪť�','1','E23',$iofficer);
   		 			}
   		 		}
   	                 }
   	       }
   	       else if (sAcc_kind[1] == '5')
   	       {  /* �p�{���M�ݫO�����T�Y�� */
	         	   rtncode = get_ca_trade_taxi(assuredf,license,tagnum,sCar_kind,
		                                    sAcc_kind,dMinQuery,query_num_dmg,
		                                    query_num_lia,&qdmg_point_renew,
		                                    &lia_taxi_renew,&qdmg_acc_sum_renew,
		                                    &qlia_acc_sum_renew,trade_msg_no_dmg,
		                                    trade_msg_no_lia,query_num_unknown,
		                                    &qunknown_point_renew,&qunknown_acc_sum_renew,trade_msg_no_unknown,
   		                                    &qdmg_acc_sum_5y_renew,&qlia_acc_sum_5y_renew,
   		                                    &qduty_sum_5y_renew,&qdmg_acc_sum_5y_pure_renew,
   		                                    &qacc_sum_5y_renew,&fhave_newa_c_2y_renew,dfirst_ply);
		           if (rtncode != M_CM_OK)
		           {
		           	/* [�d���T��]��"�L�ߴګY�Ƹ��" */
		           	strcpy(s_no_trade_type," ");
		           	ftrade = 'N';  /*HCC�P�_�O�_�d�����T add by 061476 (1090803002_SC2) */
		           	rtncode= get_ca_no_trade_taxi(last_ply,&qdmg_point_renew,
   		 			                                &lia_taxi_renew,s_no_trade_type);

                                #ifdef PRINTF_FLAG
   		 		printf("Trace -- get_ca_no_trade_taxi rc = [%ld]\n",  rc);
   		 		printf("Trace -- last_ply               = [%s] \n",  last_ply);
   		 		printf("Trace -- qdmg_point_renew       = [%d] \n",  qdmg_point_renew);
   		 		printf("Trace -- lia_taxi_renew        = [%d] \n",  lia_taxi_renew);
   		 		printf("Trace -- s_no_trade_type        = [%s] \n",  s_no_trade_type);
   		 		#endif
   		 		if (rtncode != M_CM_OK)
   		 		{
   		 			if(rtncode == M_NOTRADE_NO_RECORD)
   		 			{
   		 				/*�t���:���b[�d���T��]�A�]���b[���d���T��] */
   		 			 	#ifdef PRINTF_FLAG
   		 			 	printf(" Trace ---[�d���T��](ca_trade_taxi)�B[���d���T��](ca_no_trade_taxi)�ҵL���,�B�O�椣��[���d���T��] \n");
   		 			 	printf("  Trace -- IsNOTrade302Case() = 0 \n");
   	 				 	#endif

   	 				 	/*ftrade = 'N';  HCC�P�_�O�_�d�����T add by 061476 (1090803002_SC2) */
   	 				 	if (f_get_ca_trade_sug=='N'){
   	 				 		$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$outMsg,'�p�{���d�L�Y��_Y','1','E24',$iofficer);
   	 				 	}else{
   	 				 		$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$outMsg,'�d�L�Y��_Y(��ĳ)','1','E25',$iofficer);
   	 				 	}
   	 				 }else{
   	 				 	printf(" [���d���T��](ca_no_trade_taxi)����ơA�������(��)���d�Y�ƪť�\n");
   	 				 	$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$outMsg,'�p�{�������(��)���d�Y�ƪť�','1','E26',$iofficer);
   	 				 }
   	 			}
   	 		   }
   	 	}
   	 	else
   	 	{
   	 		/* �R�q�Τ��d���T */
   	 	}

   	 	if (f_get_ca_trade_sug=='N')
   	 	{  /* �u����O�զX�����T�T��*/
   	 		#ifdef PRINTF_FLAG
                        printf("Trace -- trade_msg_no = [%s] \n",  trade_msg_no_lia);
	                printf("Trace -- trade_msg_no = [%s] \n",  trade_msg_no_dmg);
	              	#endif
	              	/* [�d���T��]��"���ߴګY�Ƹ��"�A���O�i��X31��A�Ψ���B���d�䤤�@�өΤG�̬ҵL��� */
	              	/* check �O�_�� X31 �� */
	              	if ((strncmp(trade_msg_no_lia,"X31",3)==0)||(strncmp(trade_msg_no_dmg,"X31",3)==0) ||
	              	    (strncmp(trade_msg_no_unknown,"X31",3)==0))
	              	{
	              		strcpy(lia_ac_cnt[2],"31"); /* �Y��X31�A "�e�T�~�d�ߦ���"(lia_ac_cnt3) �� "31"*/
	              		$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$outMsg,'[�d���T��][X31]�A�H����B���d�ߴګY�Ƭ� 0 �p��O�O','2','E27',$iofficer);
	              	}
	        }
	        /** 100.10.20 �G1000728003_C4_�ק�ĤT�H�d���I�[��O�W�h **/
	        /* 107.03.29 �����ĤT�H�d���I�ߴڬ�������0��-1 modity by 061476 (1070314003_SC3)*/
	        if (sAcc_kind[1] == '2')
	        {
	        	if (lia_class_renew  < 1  )
	        	    lia_class_renew  =   1;
	        	else if (lia_class_renew  > 19 )
	        	    lia_class_renew  =  19;
	        }

	        if (qdmg_point_renew < -3 ) qdmg_point_renew = -3;
	        if (qunknown_point_renew < -3 ) qunknown_point_renew = -3;

	        /*** ��ĳ��O�զX�����I ***/
	        /*  �ثe�u���H�U�G�ر��p�ݭn�t�~�I����ĳ��O�զX������Y��
	              1. 05 �� 105 (ins1589_chg_flag=2) (ins1589_chg_flag = 1,3 �ɡA
	                 �G��O�զX�������I��"�P�@���O�Y��"�A�ҥH���ΦA�d)
	              2. �h�~�L����A��ĳ��O�������I (�ثe�u�|����ĳ09�I) 	 */

	        /*�s�W��3�ت��p: 05��118 (ins1589_chg_flag=5) ���O�P��ĳ��O�զX������Y�Ƥ��@��
	              add by sylvia 103.10.02 */
                if ((ins1589_chg_flag==2)||(f_1_9_sug=='Y')||(ins1589_chg_flag==5))
                {

                  if(f_get_ca_trade_sug=='N')
                  {
                  	/* ���x�s���O������*/
                  	qdmg_point_renew_ori   = qdmg_point_renew;
                  	qunknown_point_renew_ori   = qunknown_point_renew;

                  	qdmg_acc_sum_renew_ori = qdmg_acc_sum_renew;
                  	qunknown_acc_sum_renew_ori = qunknown_acc_sum_renew;

                  	strcpy(query_num_dmg_ori, query_num_dmg );
                  	strcpy(query_num_unknown_ori, query_num_unknown );

                        f_get_ca_trade_sug = 'Y';
                        goto CA_TRADE;
                  }else{	/* �����o��ĳ��O������Y�� f_get_ca_trade_sug => Y */
                  	/* �x�s��ĳ��O������*/
                  	qdmg_point_renew_sug   = qdmg_point_renew;
                  	qunknown_point_renew_sug   = qunknown_point_renew;

                  	qdmg_acc_sum_renew_sug = qdmg_acc_sum_renew;
                  	qunknown_acc_sum_renew_sug = qunknown_acc_sum_renew;

                  	strcpy(query_num_dmg_sug, query_num_dmg );
                  	strcpy(query_num_unknown_sug, query_num_unknown );
                  }
                }else{    /* ��l���p���O�զX�B��ĳ��O�զX������Y�ƬۦP */
                	qdmg_point_renew_ori   = qdmg_point_renew;
                	qunknown_point_renew_ori   = qunknown_point_renew;

                	qdmg_acc_sum_renew_ori = qdmg_acc_sum_renew;
                	qunknown_acc_sum_renew_ori = qunknown_acc_sum_renew;

                	strcpy(query_num_dmg_ori, query_num_dmg );
                	strcpy(query_num_unknown_ori, query_num_unknown );

                	qdmg_point_renew_sug   = qdmg_point_renew;
                	qunknown_point_renew_sug   = qunknown_point_renew;

                	qdmg_acc_sum_renew_sug = qdmg_acc_sum_renew;
                	qunknown_acc_sum_renew_sug = qunknown_acc_sum_renew;

                	strcpy(query_num_dmg_sug, query_num_dmg );
                	strcpy(query_num_unknown_sug, query_num_unknown );
               }
         }
         #ifdef PRINTF_FLAG
         printf("Trace -- qdmg_point_renew_ori   = [%d] \n",  qdmg_point_renew_ori);
         printf("Trace -- qdmg_acc_sum_renew_ori = [%d] \n",  qdmg_acc_sum_renew_ori);
         printf("Trace -- qdmg_point_renew_sug   = [%d] \n",  qdmg_point_renew_sug);
         printf("Trace -- qdmg_acc_sum_renew_sug = [%d] \n",  qdmg_acc_sum_renew_sug);
         printf("Trace -- lia_class_renew    = [%d] \n",  lia_class_renew);
         printf("Trace -- qlia_acc_sum_renew = [%d] \n",  qlia_acc_sum_renew    );
         #endif

         /* qdmg_point_renew�G�����I�[��O�I��
	    lia_class_renew �G���d�I�̷s�ż�
	    ����ߴڬ����Y��  =  �����I�[��O�I�� x 0.2
	    ���d�ߴڬ����Y��  =  (���d�I�̷s�ż� - 4 ) / 10
	    lia_taxi_renew:�p�{�����d�I�Y��*/

	 pdmg_acc_ori = qdmg_point_renew_ori * 0.2;
	 pdmg_acc_sug = qdmg_point_renew_sug * 0.2;

	 punknown_acc_ori = qunknown_point_renew_ori * 0.2;
	 punknown_acc_sug = qunknown_point_renew_sug * 0.2;

	 /*plia_acc = (lia_class_renew  - 4 ) / 10.0;*/
	 /* �p�{���M�ݫO��,���d�żƤ��ϥ�, �G�w��4    add by sylvia 103.10.12 */
	 if ((cnt_ins131 >0) || (cnt_ins132 >0))
	 {
	 	plia_acc = lia_taxi_renew;
	 	strcpy(lia_class,"4");
	 }
	 else
	 {
	 	$EXECUTE get_acc_factor
	 	    INTO $plia_acc
	 	   USING '2',$fcar_class,$lia_class_renew,$tmp_frate2;
	 	if (SQLCODE==SQLNOTFOUND){
	 		$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$lia_class_renew,'���d�żƧ䤣������Y��ca_comp_acc_factor','1','E28',$iofficer);
	 	}
	 	strcpy(lia_class,itoa(lia_class_renew));
         }
	 rfmtdouble(pdmg_acc_ori,"-&.&&",spdmg_acc);      spdmg_acc[4]     = '\0';
         rfmtdouble(pdmg_acc_sug,"-&.&&",spdmg_acc_sug);  spdmg_acc_sug[4] = '\0';
         rfmtdouble(plia_acc,"-&.&&",splia_acc);          splia_acc[5] = '\0';

         rfmtdouble(punknown_acc_ori,"-&.&&",spunknown_acc);      spunknown_acc[4]     = '\0';
         rfmtdouble(punknown_acc_sug,"-&.&&",spunknown_acc_sug);  spunknown_acc_sug[4] = '\0';

         /* 102.11.12 �]���馳�h���Y�ơA�G�S�������I���ܡA�N����� (�����d�@�����) */
	 strcpy(iquery_num           ,query_num_lia);
         if (f_1_9_exist=='Y'){
         	strcpy(iquery_num_damage    ,query_num_dmg_ori);
         	strcpy(iquery_num_damage_sug,query_num_dmg_sug);

         	strcpy(iquery_num_unknown    ,query_num_unknown_ori);
         	strcpy(iquery_num_unknown_sug,query_num_unknown_sug);
         }else{
         	strcpy(iquery_num_damage    ," ");
         	strcpy(spdmg_acc," ");
         	strcpy(spunknown_acc,"0.0");
         	strcpy(iquery_num_unknown    ," ");

         	if (f_1_9_sug=='Y'){
         		strcpy(iquery_num_damage_sug,query_num_dmg_sug);
         		strcpy(iquery_num_unknown_sug,query_num_unknown_sug);
         	}else{
         		strcpy(iquery_num_damage_sug," ");
	         	strcpy(spdmg_acc_sug," ");
	         	strcpy(spunknown_acc_sug,"0.0");
	         	strcpy(iquery_num_unknown_sug," ");
	         }
	 }
	 #ifdef PRINTF_FLAG
         printf("spdmg_acc        = [%s]\n", spdmg_acc        );
         printf("spdmg_acc_sug    = [%s]\n", spdmg_acc_sug        );
         printf("splia_acc        = [%s]\n", splia_acc        );
         printf("dmg_ac_cnt[2]    = [%s]\n", dmg_ac_cnt[2]    );
         printf("lia_class        = [%s]\n", lia_class);
         printf("iquery_num       = [%s]\n", iquery_num);
         printf("iquery_num_damage    = [%s]\n", iquery_num_damage);
         printf("iquery_num_damage_sug= [%s]\n", iquery_num_damage_sug);
         printf("Trace1 -- plia_acc = [%f] \n",  plia_acc);
         #endif

      }

      /* �T�~�����d�X�I�G��, 98�I�ؤ��o�ӫO,���e���ˮַ|�]���T�Y�Ƭd�ߦ�m���ʦӵL�k�T���ˮ֨�,
         �ҥH�b�o�̦A�ˮ֤@��, ���]�����[�I�����Y, ���B�D�n�P�_�Ƶ���r,�R���������A��U�����{���C
           add by sylvia 104.09.16 */
      /* 98����אּ09+K 108.04.26 (1080408008_SC3) */
      /* K���ڰ��� 09+K�אּ198 109.11.06 (1091103004_SC1) */
      if ((qlia_acc_sum_renew >=2) && (f_198_exist == 'Y'))
      {
        strcpy(sstpe," ");
        sug_type = 0;
        INS_ptr=Ifirst;
        while(INS_ptr)
        {
            strcpy(sstpe,trim(INS_ptr->ins_type));
            sug_type = INS_ptr->sug_iins_type;
            if (strcmp(sstpe,"198") == 0)
            {
                if (sug_type == 0)
                {
                    if ((strlen(trim(remark1))>10) && (strstr(remark1,"198�I��")==NULL))
                    {
		        sprintf(remark6,"���O����O198�I��,���~��O�ݭ��s�f��,��������O�O�O,�p�����D�Ь��ӫO��");

                    }
                    else
                    {
		        sprintf(remark1,"���O����O198�I��,���~��O�ݭ��s�f��,��������O�O�O,�p�����D�Ь��ӫO��");

		    }
		    /* modify by sylvia 105.02.02 (1041230003_C1) */
                    $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$sstpe,'�O����O198�I��,���~��O�ݭ��s�f��,��������O�O�O,�p�����D�Ь��ӫO��','1','E53',$iofficer);
		}
            }
            INS_ptr=INS_ptr->next;
        }
      }

      /* �ӫO198�I�ءAJB�q���A���d��1��4 ���J�p add by 121219 (1120731006_C03)*/
      if((f_198_exist == 'Y') && (strncmp(iroute, "JB", 2) == 0))
      {
      	strcpy(sFullDBName, get_car_full_dbname(last_ply));
      	sprintf(stmt, " select count(*) from %s:appraisal "
                      " where fdmg_duty IN ('1','4') "
                      " and ipolicy = '%s'; ", sFullDBName, last_ply);

      	$PREPARE chk_fdmg_duty FROM $stmt;
      	$EXECUTE chk_fdmg_duty INTO $cnt_fdmg_duty;

      	if(cnt_fdmg_duty > 0)
      	{
      		sprintf(remark6, "JB�q��,�ӫO198�I��,���~�׫O��F�d���w�Φ��d�X�I�@��,�ݭ��s�f��");
      		$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,$remark6,'1','E53',$iofficer);
      	}
      }

      code=Cal_ins_prem_302(INS_ptr,int_cal_car_id,0,dply_end,INS_ptr_33,cover_vs_prem,ca_rate,
                            min_car_factor,car_model_factor,ca_sex_age_factor,ca_car_model,
                            insurance_type,userid);

      #ifdef PRINTF_FLAG
         printf("3.31 code[%ld]\n",code);
         printf("end Cal_ins_premium\n");
      #endif
      if (code != SUCCESS)
      {
         if(code == M_CA_INS31){
            $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�I�ثO�O�p����~','1','E15',$iofficer);
            goto end;
         }else if(code == 4035){
            $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�I�ثO�B�O�O��Ƥ��s�b','1','E16',$iofficer);
            goto end;
         }else if(code==M_CA_OVER_75_PERCENT){
            $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�I�ؤ��O�B�̭�o�Ӥ�_�p��A�H���`���«�A�h�@�~���¬��W��','1','E17',$iofficer);
            goto end;
         }else if(code==4286){
                  $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�~�֩ʧO�Y�Ƥ��s�b','1','E43',$iofficer);
                  goto end;
         }else{
            memset(err_buf,0,sizeof(err_buf));
            strcpy(err_buf,"Get302Data()9-2->Cal_ins_premium ERROR:");
            strcat(err_buf,last_ply);
            EWRITE(userid,code,err_buf);
            return code;
         }
      }
   }
   else if (ply1f==FALSE && (ply2f==FALSE || (ply2f==TRUE && fany==0)) )
   {
      /* �s���I��  add by 061476 107.04.12 (1061108001_SC7) */
      /* 181�I�حn�d���~�N�X����T add by 061476 (1090527002_SC3) */
      /* �D181�]�n�O�d���~�N�X��T (1110915007_SC1) */
      if(strncmp(tmp_ply,"V7",2) != 0)
      {
      	#ifdef PRINTF_FLAG
      	printf("3.32 {step9.0020}:ply1f[%d],ply2f[%d],fany[%d]\n",ply1f,ply2f,fany);
      	#endif

      	rec_count--;
      	/*t_count = 0;
      	$select count(*) Into $t_count from duplic1  where ipolicy = $last_ply;
      	if ((t_count > 0)&&(strcmp(ins_type,"181") != 0)){
      		$delete from duplic1 where ipolicy = $last_ply;
      		}*/
      	goto end;
      }
   }

   /************************** STEP 10 **********************************  */
   step_11:

      $WHENEVER SQLERROR GOTO get302_err;
      $WHENEVER SQLERROR CONTINUE;

      #ifdef PRINTF_FLAG
         printf("3.37 ca302-3, insert policy_302, ply[%s]\n",last_ply);
         printf("comp_date_begin[%s],comp_date_end[%s]\n",comp_date_begin,comp_date_end);
         printf("3.38 ca302-4, insert ply_ins_type_302, ply[%s]\n",last_ply);
      #endif

      INS_ptr=Ifirst;
      v_prem = 0;
      v_ori_prem =0;
      /*****���N�I��O�I��********/
      ch_ins_grp[0][0] = '\0';
      ch_ins_grp[1][0] = '\0';
      ch_ins_grp[2][0] = '\0';
      old_ins_type[0] = '\0';
      ch_ins_cnt = 0;
      ins_grp_cnt = 0;

      sum_mdiscount = 0;
      sug_ins_type  = 1;
      ins_cnt = 0;
      f_del_dmg = 0;
      prem38_ori = prem39_ori = prem50_ori = prem55_ori = prem56_ori = 0; /* 101.06.06 */
      prem38_sug = prem39_sug = prem50_sug = prem55_sug = prem56_sug =0; /* 101.07.11 */

      while(INS_ptr)
      {
         strcpy(ins_type, trim(INS_ptr->ins_type));
         injured_cover=INS_ptr->injured_cover;
         death_cover=INS_ptr->death_cover;
         damage_cover=INS_ptr->damage_cover;
         deduct=INS_ptr->deduct;
         strcpy(provision ,INS_ptr->provision );
         pcar_price = INS_ptr->pcar_price;
         safe_rate = INS_ptr->safe_rate;
         manage_rate= INS_ptr->manage_rate;

         sprintf(tmp_provision,"%s;",trim(provision)); /* ���� *//*1101125007_SC1_11�I�J�p�X�{�G��P���ڭץ� by 071004*/

         #ifdef PRINTF_FLAG
            printf("Trace -- ins_type = [%s] deduct[%d]\n", ins_type, deduct);
            printf("Trace -- INS_ptr->sug_iins_type[%d]\n", INS_ptr->sug_iins_type);
	    printf("INS_ptr->qcoverage[%ld]\n",INS_ptr->qcoverage);
	    printf("tmp_provision[%s]\n",tmp_provision);
         #endif

         if (INS_ptr->qcoverage>10){
         	qcoverage=1;
         }else{
            qcoverage=INS_ptr->qcoverage;
         }
       	 #ifdef PRINTF_FLAG
	    printf("2--ins_type[%s]\n",ins_type);
	    printf("INS_ptr->qcoverage[%ld]\n",INS_ptr->qcoverage);
	 #endif
         qserial=INS_ptr->qserial;
         sug_ins_type = INS_ptr->sug_iins_type;


         /* �ӫ~���� */
         if ((strcmp(ins_type,"85") == 0)||(strcmp(ins_type,"120") == 0)||
             (strcmp(ins_type,"121") == 0)||(strcmp(ins_type,"105") == 0)||
             (strcmp(ins_type,"118") == 0)||(strcmp(ins_type,"119") == 0)||
             (strcmp(ins_type,"122") == 0)||(strcmp(ins_type,"123") == 0)||
             (strcmp(ins_type,"125") == 0)||(strcmp(ins_type,"126") == 0)||
             (strcmp(ins_type,"112") == 0)||(strcmp(ins_type,"18") == 0)||
             (strcmp(ins_type,"106") == 0)||(strcmp(ins_type,"107") == 0)||
             (strcmp(ins_type,"108") == 0)||(strcmp(ins_type,"80") == 0)||
             (strcmp(ins_type,"152") == 0)||(strcmp(ins_type,"153") == 0)||
             (strcmp(ins_type,"24") == 0))
         {
                INS_ptr=INS_ptr->next;
                continue;
         }
         /* 100.01.10 85�I�إ��q�L�ˮֱ���,������ => ���L�D�I�������I�� */
         if (f_del_dmg == 1){
            $EXECUTE smiad INTO $simain_ins USING $ins_type;
            if (SQLCODE == SQLNOTFOUND)
            {
                INS_ptr=INS_ptr->next;
                continue;
            }else{
                strcpy(simain_ins,trim(simain_ins));
    	        if (ISINS01(simain_ins))
    	        {
    	               INS_ptr=INS_ptr->next;
    	               continue;
    	        }
            }
         }

         /* 960612, ���ݪ��I34 */
         if ((strcmp(ins_type,"34") == 0)||(strcmp(ins_type,"87") == 0)||(strcmp(ins_type,"115") == 0) ){
            INS_ptr->ins_premium     = 0 ;
            INS_ptr->bef_ins_premium = 0 ;
            INS_ptr->mdiscount       = 0 ;
            INS_ptr->mexp_disc       = 0 ;

            if( sug_ins_type == 0 ){ /*���O�զX*/
               IcurrPlyInsCover = IfirstPlyInsCover;

               while( IcurrPlyInsCover)
               {
                  if ((strcmp(trim(IcurrPlyInsCover->iins_type),"34") == 0) ||
                      (strcmp(trim(IcurrPlyInsCover->iins_type),"87") == 0) ||
                      (strcmp(trim(IcurrPlyInsCover->iins_type),"115") == 0))
                  {
                     INS_ptr->ins_premium     += IcurrPlyInsCover->mcover_prem;
                     INS_ptr->bef_ins_premium += IcurrPlyInsCover->mprem;
                     INS_ptr->mdiscount       += IcurrPlyInsCover->mdiscount;
                     mcover_302          = IcurrPlyInsCover->mcover ;
                     mcover_prem_302     = IcurrPlyInsCover->mcover_prem ;
                     mdiscount_302       = IcurrPlyInsCover->mdiscount ;
                     mprem_302           = IcurrPlyInsCover->mprem ;

                     strcpy(icover_type_302,IcurrPlyInsCover->icover_type);

                     if( intopt == 25 ){
                     	/* [del intopt == 25]102.03 �w��5/1�ᤧ 5,6��|���X�椧��O���ơA�ɻ����O�X���ơA�H�Q���H�o��O�� 102.07���i�R��*/
                     	/* ��ӳ����J�p�覡�ɸ�� */
                     }else{
                     	/*  ��O�I�զX => update ply_ins_cover_302 */
                     	sprintf(buf1,"UPDATE %s:ply_ins_cover_302 \
                     	                 SET ori_mcover=?, ori_mcover_prem=?, \
                     	                     ori_mdiscount=?, ori_mprem=? \
                     	               WHERE ipolicy ='%s' AND iins_type='%s' AND icover_type='%s'"
                     	,FDBNAME, last_ply, ins_type,icover_type_302 );

                     	$PREPARE STM_ins_cover_302_0 FROM $buf1;
                     	$EXECUTE STM_ins_cover_302_0 USING $mcover_302,$mcover_prem_302,
                     	$mdiscount_302,$mprem_302;

                     	if (sqlca.sqlerrd[2] == 0 ){
                     		$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�I�ح�O�I�զX�䤣��','2','E29',$iofficer);
                     	}else{
                     		if (SQLCODE!=0) goto get302_err1;
                     	}
                     }
                  }
                  IcurrPlyInsCover = IcurrPlyInsCover->next;
               }
            }else{ /* ��ĳ��O�զX */
               IcurrPlyInsCover1 = IfirstPlyInsCover1;
               IcurrPlyInsCover2 = IfirstPlyInsCover2;
               while( IcurrPlyInsCover1)
               {
                  if ((strcmp(trim(IcurrPlyInsCover1->iins_type),"34") == 0)||
                      (strcmp(trim(IcurrPlyInsCover1->iins_type),"87") == 0) ||
                      (strcmp(trim(IcurrPlyInsCover1->iins_type),"115") == 0))
                  {
                     INS_ptr->ins_premium += IcurrPlyInsCover1->mcover_prem;
                     INS_ptr->bef_ins_premium += IcurrPlyInsCover1->mprem;
                     INS_ptr->mdiscount       += IcurrPlyInsCover1->mdiscount;

                     strcpy(icover_type_302,IcurrPlyInsCover1->icover_type);
                     mcover_302          = IcurrPlyInsCover1->mcover ;
                     mcover_prem_302     = IcurrPlyInsCover1->mcover_prem ;
                     mdiscount_302       = IcurrPlyInsCover1->mdiscount ;
                     mprem_302           = IcurrPlyInsCover1->mprem ;

                     /*  ==> �h�~��O�զX */
                     if ((strcmp(trim(IcurrPlyInsCover2->iins_type),"34") == 0)||
                         (strcmp(trim(IcurrPlyInsCover2->iins_type),"87") == 0))
                     {
                        while( IcurrPlyInsCover2)
                        {
                        	pre_mcover_302      = IcurrPlyInsCover2->mcover ;
	                        pre_mcover_prem_302 = IcurrPlyInsCover2->mcover_prem ;
	                        pre_mdiscount_302   = IcurrPlyInsCover2->mdiscount ;
	                        pre_mprem_302       = IcurrPlyInsCover2->mprem ;

	                        IcurrPlyInsCover2 = IcurrPlyInsCover2->next;
	                        break;
	                }
	             }

	             if( intopt == 25 ){
	             	/* [del intopt == 25]102.03 �w��5/1�ᤧ 5,6��|���X�椧��O���ơA�ɻ����O�X���ơA�H�Q���H�o��O�� 102.07���i�R��*/
	             	/* ��ӳ����J�p�覡�ɸ�� */
	             }else{
	             	/*  ��ĳ��O�զX ==> INSERT INTO ply_ins_cover_302 */
	             	sprintf(buf1,"INSERT INTO %s:%s %s",
			              FDBNAME,"ply_ins_cover_302",
			             " VALUES (?,?,?,?,?,?,?,?,?,?,?,0,0,0,0)");
                        $PREPARE STM_ins_cover_302_1 FROM $buf1;

                        $EXECUTE STM_ins_cover_302_1 USING
			         $last_ply,$ins_type,$icover_type_302,
			         $mcover_302,$mcover_prem_302,$mdiscount_302,$mprem_302,
			         $pre_mcover_302,$pre_mcover_prem_302,$pre_mdiscount_302,$pre_mprem_302 ;
		     }
                  }
                  IcurrPlyInsCover1 = IcurrPlyInsCover1->next;
               }
            }
            #ifdef PRINTF_FLAG
            printf("--sug_ins_type[%d]\n",sug_ins_type);
            printf("�W���O�O INS_ptr->ins_premium[%lf]\n",INS_ptr->ins_premium);
            printf("���� INS_ptr->mdiscount[%ld]\n",INS_ptr->mdiscount);
            #endif
         }

         ins_premium = INS_ptr->ins_premium;
         mprem       = INS_ptr->bef_ins_premium;
         mdiscount   = INS_ptr->mdiscount;
         pdiscount   = INS_ptr->pdiscount;
         qday        = INS_ptr->qday;
         mexpense    = INS_ptr->mexpense;
         mexp_disc   = INS_ptr->mexp_disc;

         strcpy(frate,INS_ptr->frate);

         if (strncmp(ins_type,"**",2) == 0)
         {
             INS_ptr=INS_ptr->next;
             continue;
         }

         if (strcmp(ins_type,"11") == 0 || strcmp(ins_type,"211") == 0)
         {
            /** �M�ץ� 11 �I�ؤ��s�W�� ply_ins_type_302 **/
            #ifdef PRINTF_FLAG
               printf("-- in iins 11 --\n");
            #endif
            /* 102.12.25 A�BB����}�� */
            if (IsPlyB=='Y'){
            	$DECLARE CUR_plychk1_1b CURSOR FOR plychk1_b;
            	$OPEN CUR_plychk1_1b USING $last_ply;
            }else{
            	$DECLARE CUR_plychk1_1 CURSOR FOR plychk1;
            	$OPEN CUR_plychk1_1 USING $last_ply;
            }

            /* plychk1 ��A�BB�����ӬO�@��@ */
            SkipIns = 1; /* �M�ץ������,�ذe�I�ؤ���� */
            iRemark_yn = 0;
            strcpy(sIprmt," ");

            /* �U�L�@���M�צb�o�̧䤣��N��, �ҥH�u�M���D�U�L�@�����M�� modify by sylvia 104.05.24 */
            if ((f_AN_SHIN=='N')&&(f_NO_WORRY=='N'))
                strcpy(note1," ");

            while(1)
            {
            	/* 102.12.25 A�BB����}�� */
            	if (IsPlyB=='Y'){
            		$FETCH CUR_plychk1_1b
            		INTO $Aipolicy, $nproject, $nprocomp, $nproprem, $Biofficer, $BPlyClosed, $iRemark_yn, $sIprmt;
            	}else{
            		$FETCH CUR_plychk1_1
            		INTO $Aipolicy, $nproject, $nprocomp, $nproprem, $Biofficer, $BPlyClosed, $iRemark_yn, $sIprmt;
            	}
            	if (SQLCODE == SQLNOTFOUND){
            		#ifdef PRINTF_FLAG
            		printf("Trace -- last_ply = [%s] \n",  last_ply);
            		printf("Trace �M�ץ� 11 �I�� SQLNOTFOUND-- nproject = [%s] \n",  nproject);
            		#endif
            		SkipIns = 0;
            		iRemark_yn = 0;
            		strcpy(sIprmt," ");
            		/* �U�L�@���M�צb�o�̧䤣��N��, �ҥH�u�M���D�U�L�@�����M�� modify by sylvia 104.05.24 */
            		if ((f_AN_SHIN=='N')&&(f_NO_WORRY=='N'))
            		    strcpy(note1," ");

		        break;
		}

		strcpy(note1,sIprmt);  /* �M�ץN���g�J note1 add by sylvia 104.05.08 */

		#ifdef PRINTF_FLAG
		printf("Aipolicy[%s]\n",Aipolicy);
		printf("nproject[%s]\n",nproject);
		printf("nprocomp[%s]\n",nprocomp);
		printf("Biofficer[%s]\n",Biofficer);
		printf("BPlyClosed[%d]\n",BPlyClosed);
		#endif

		if (BPlyClosed==0){
			if (IsPlyB=='Y'){
				SkipIns = 0; /* 102.12.25 �M�ץ�11�I�حn��ܦb B��  ����skip */
			}else{
				SkipIns = 1;  /*Skip Ins ,�M�ץ����,11�I����� */
			}
			break;
		}else{ /* �M�ר�� */
			strcpy(nproject," ");
			strcpy(note1, " ");

			SkipIns = 0;
			#ifdef PRINTF_FLAG
			printf("trace inequipment[%s]\n ",inequipment);
			printf("trace Aiequip[%s]\n ",Aiequip);
			#endif
			strcpy(inequipment, equip_delete(inequipment,Aiequip)); /* 102.03 */
			break;
		}
	    }
	    /* 102.12.25 A�BB����}�� */
	    if (IsPlyB=='Y'){
	    	$CLOSE CUR_plychk1_1b;
	    	$FREE CUR_plychk1_1b;
	    }else{
	    	$CLOSE CUR_plychk1_1;
	    	$FREE CUR_plychk1_1;
	    }

	    if (SkipIns == 1){
	    	INS_ptr=INS_ptr->next;
	    	continue;
	    }

	    if (f_YF4_ply == 'Y') {
            	/** ��A�榳�t�����ɯũ���M��(�e11) �B����� **/
               INS_ptr=INS_ptr->next;
               continue;
            }
	    if (f_YF6_ply == 'Y'){
            	/** ��A�榳�tDLR50�M��(�e11) �B����� **/
               /* INS_ptr=INS_ptr->next;
               continue; */
            }

	    if (f_UF_ply == 'Y'){
               INS_ptr=INS_ptr->next;
               continue;
            }else if (f_YFB_ply == 'Y') {
               INS_ptr=INS_ptr->next;
               continue;
            }
         }
         /* 950704 */
         else if ((strcmp(ins_type,"55") == 0) || (strcmp(ins_type,"56") == 0))
         {
            if (fProjNoPlyB=='Y'){
               /*970418,�樮�@�ӱM��(�S��B��),��ĳ�έ��O�զX�����*/
               if(strcmp(ins_type,"56") == 0){
                  if (sug_ins_type==1||sug_ins_type==0){
	                  injured_cover= 0;
	                  damage_cover = 0;
	                  deduct       = 0;
	                  ins_premium  = 0;
	                  mprem        = 0;
	                  mdiscount    = 0;
	                  pdiscount    = 0;
	          }
	          if (nproject[0]==' ' || nproject[0]=='\0'){
	          	strcpy(nproject,"�樮�@�ӱM��");
	          }
	       }
            }
         }
         else if (strcmp(ins_type,"01") == 0  || strcmp(ins_type,"05") == 0  ||
                  strcmp(ins_type,"09") == 0  || strcmp(ins_type,"08") == 0  ||
                  strcmp(ins_type,"85") == 0  || strcmp(ins_type,"105")== 0  ||
                  strcmp(ins_type,"118")== 0  || strcmp(ins_type,"120")== 0  ||
                  strcmp(ins_type,"122")== 0  || strcmp(ins_type,"98")== 0   ||
                  strcmp(ins_type,"181")== 0  || strcmp(ins_type,"198")== 0  ||
                  strcmp(ins_type,"201")== 0  || strcmp(ins_type,"205")== 0  ||
                  strcmp(ins_type,"209")== 0  ) /* 102.08.26 �s�W105�I��,�B 05=>105  */
         {
            /* �s�W98�I�� add by sylvia 104.09.16 */
            /* 100.01.10 85�I�طs�W�ˮֱ��� */
            if (strcmp(ins_type,"85") == 0)
            {
                if (f_del_85=='Y'){
                     f_del_dmg = 0;
                     INS_ptr=INS_ptr->next;
                     continue;
                }

                if(ins1589_chg_flag==3)
     	     	{
                    if (sug_ins_type==1){
                    	/* ��85=>105,85����ĳ��O�զX����0 */
                    	injured_cover= 0;
                    	damage_cover = 0;
                    	/*deduct       = 0;*/  /* 85 =>105 ,�G 85 �L��ĳ��O�զX�A�u�����O�զX�A���ۭt�B�������"��ĳ��O�զX" */
                    	ins_premium  = 0;
                    	mprem        = 0;
                    	mdiscount    = 0;
                    	pdiscount    = 0;
                    	qday         = 0;
                    	mexpense     = 0;
                    	mexp_disc    = 0;
                    }
                }
                if(((sug_ins_type==1)&&(ins_premium < injured_cover)&&(ins1589_chg_flag!=3)) ||
         	   ((sug_ins_type==0)&&(ins_premium < ori_injured_cover)))
         	{
         		if (f_del_dmg==0){
         			if (strlen(trim(remark1))>10){
         				sprintf(remark6,"������h�~����O%s�I��,�����~�O�O�C�󤣩����l�O�B,�G�����ѳ���,�Y���ðݽЬ��ӫO��",ins_type);
         				sprintf(remark7," ");
         			}else{
         				sprintf(remark1,"������h�~����O%s�I��,�����~�O�O�C�󤣩����l�O�B,�G�����ѳ���,�Y���ðݽЬ��ӫO��",ins_type);
         				sprintf(remark2," ");
         			}
         			/* modify by sylvia 105.02.02 (1041230003_C1) */
         			$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'����h�~����O���I��,�����~�O�O�C�󤣩����l�O�B,�G�����ѳ���,�Y���ðݽЬ��ӫO��','1','E54',$iofficer);
	               }

	               f_del_dmg = 1;
	               INS_ptr=INS_ptr->next;
	               continue;
               }
            }else if (strcmp(ins_type,"105") == 0){
               /* 102.11.8 */
             	if (f_del_105=='Y'){
	               f_del_dmg = 0;
                  INS_ptr=INS_ptr->next;
             	   continue;
             	}

               /* 105��118+119�I�� add by yslvia 103.10.03 */
               if(ins1589_chg_flag==6)
               {
                  if (sug_ins_type==1){
                  	/* ��105����ĳ��O�զX����0 */
                  	injured_cover= 0;
                  	damage_cover = 0;
                  	/*deduct       = 0;*/
                  	ins_premium  = 0;
                  	mprem        = 0;
                  	mdiscount    = 0;
                  	pdiscount    = 0;
                  	qday         = 0;
                  	mexpense     = 0;
                  	mexp_disc    = 0;
                  }
     	       }
     	    }else if (strcmp(ins_type,"118") == 0){
     	        if (f_del_118=='Y'){
             	    f_del_dmg = 0;
                    INS_ptr=INS_ptr->next;
                    continue;
                }
            }else if (strcmp(ins_type,"119") == 0){
             	if (f_del_119=='Y'){
             	    f_del_dmg = 0;
                    INS_ptr=INS_ptr->next;
                    continue;
                }
            }else if (strcmp(ins_type,"120") == 0){
             	if (f_del_120=='Y'){
             	    f_del_dmg = 0;
                    INS_ptr=INS_ptr->next;
                    continue;
                }
            }else if (strcmp(ins_type,"121") == 0){
             	if (f_del_121=='Y'){
             	    f_del_dmg = 0;
                    INS_ptr=INS_ptr->next;
                    continue;
                }
            }else if (strcmp(ins_type,"122") == 0){
             	if (f_del_122=='Y'){
             	    f_del_dmg = 0;
                    INS_ptr=INS_ptr->next;
                    continue;
                }
            }else if (strcmp(ins_type,"123") == 0){
             	if (f_del_123=='Y'){
             	    f_del_dmg = 0;
                    INS_ptr=INS_ptr->next;
                    continue;
                }
            }else if ((strcmp(ins_type,"198") == 0) && (qlia_acc_sum_renew >=2)){
                    /* add by sylvia 104.09.16 */
                    /* 98=>09+K modify by 061476 */
                    /* 09+K=>198 modify by 061476 */
    	            f_del_dmg = 1;
                    INS_ptr=INS_ptr->next;
                    continue;
     	    }
     	    else if((strcmp(ins_type,"198") == 0) && (strncmp(iroute, "JB", 2) == 0) && (cnt_fdmg_duty > 0)){
     	    	    /* add by 121219 113.09.03 (1120731006_C03) */
     	    	    f_del_dmg = 1;
                    INS_ptr=INS_ptr->next;
                    continue;
            }
     	    else if ((strcmp(ins_type,"05") == 0)||(strcmp(ins_type,"205") == 0))
     	    {
     	        if((ins1589_chg_flag==2)||(ins1589_chg_flag==5)){ /* �s�W05��118 add by sylvia 103.10.03 */
                    if (sug_ins_type==1){     /* ��05����ĳ��O�զX����0 */
                    	injured_cover= 0;
                    	damage_cover = 0;
                    	/*deduct       = 0;*/  /* 05 =>105 ,�G 05 �L��ĳ��O�զX�A�u�����O�զX�A���ۭt�B�������"��ĳ��O�զX" */
                    	ins_premium  = 0;
                    	mprem        = 0;
                    	mdiscount    = 0;
                    	pdiscount    = 0;
                    	qday         = 0;
                    	mexpense     = 0;
                    	mexp_disc    = 0;
                    }else{
                    	/* 102.09.03 add */
                    	if (deduct > 8000){
                    		if (strlen(trim(remark1))>10){
                    			if (ins1589_chg_flag == 2)
                    			    sprintf(remark6,"�����椵�~�Y��H105�I�س���,�]�쨮���I�ۭt�B����8000��,�ӫO�e�����ɨ�");
                    			else
					    sprintf(remark6,"�����椵�~�Y��H118�I�س���,�]�쨮���I�ۭt�B����8000��,�ӫO�e�����ɨ�");

					sprintf(remark7," ");
				}else{
					if (ins1589_chg_flag == 2)
					    sprintf(remark1,"�����椵�~�Y��H105�I�س���,�]�쨮���I�ۭt�B����8000��,�ӫO�e�����ɨ�");
					else
					    sprintf(remark1,"�����椵�~�Y��H118�I�س���,�]�쨮���I�ۭt�B����8000��,�ӫO�e�����ɨ�");

					sprintf(remark2," ");
				}
			}
		    }
     	     	}
     	    }
     	    else if ((strcmp(ins_type,"01") == 0)||(strcmp(ins_type,"201") == 0))
     	    {
     	         /* 01�I����122�I��  add by sylvia  103.10.03 */
                if(ins1589_chg_flag==8)
                {
                	if (sug_ins_type==1){     /* ��01����ĳ��O�զX����0 */
                		injured_cover= 0;
                		damage_cover = 0;
                		/*deduct       = 0;*/
                		ins_premium  = 0;
                		mprem        = 0;
                		mdiscount    = 0;
                		pdiscount    = 0;
                		qday         = 0;
                		mexpense     = 0;
                		mexp_disc    = 0;
                	}
     	     	}
     	    }else if ((strcmp(ins_type,"09") == 0)||(strcmp(ins_type,"209") == 0))
     	    {
     	    	/* 09�I����120�I��  add by sylvia  103.10.03 */
                if(ins1589_chg_flag==7)
                {
                    if (sug_ins_type==1){     /* ��09����ĳ��O�զX����0 */
                        injured_cover= 0;
                        damage_cover = 0;
                        /*deduct       = 0;*/
                        ins_premium  = 0;
                        mprem        = 0;
                        mdiscount    = 0;
                        pdiscount    = 0;
                        qday         = 0;
                        mexpense     = 0;
                        mexp_disc    = 0;
                    }
     	     	}
     	    }
   	    #ifdef PRINTF_FLAG
            printf("in iins [%s]\n",ins_type);
            #endif
            /* 961128, �x���Υ������I��P�έ�ۦP */
         	/* 950913,�έ�    09�|�ন05,�P�ɦA�s�W09,�|���G�������I,�ȫ�ĳ��O�զX�� 0   */
         	/* 950908,�x���Υ�09�|�ন05,�P�ɦA�s�W09,�|���G�������I,��ĳ�έ��O�զX�Ҭ�0*/
            if(ins1589_chg_flag==1){
            	if ((strncmp(iofficer,"A09",3) == 0)||(strncmp(iofficer,"A21",3) == 0)){
            		if(strcmp(ins_type,"09")==0){
            			if (sug_ins_type==1){     /* ��09����ĳ��O�զX����0 */
            				injured_cover= 0;
            				damage_cover = 0;
            				deduct       = 0;
            				ins_premium  = 0;
            				mprem        = 0;
            				mdiscount    = 0;
            				pdiscount    = 0;

            				if (pre_qday==0){  /* �Y�h�~�L�[�ȫh�L���ɥ� */
            					qday         = 0;
            					mexpense     = 0;
            					mexp_disc    = 0;
            				}
            			}
         	   	}
         	   	if(strcmp(ins_type,"05")==0){
         	   		if (sug_ins_type==0){ /* �έ𪺭��O�զX����b09 */
         	   			injured_cover= 0;
         	   			damage_cover = 0;
         	   			deduct       = 0;
         	   			ins_premium  = 0;
         	   			mprem        = 0;
		               }
         	   	}
          	   }
         	}
         }
         #ifdef PRINTF_FLAG
         printf("f_16_exist[%c]\n",f_16_exist);
         printf("f_19_exist[%c]\n",f_19_exist);
         printf("f_14_exist[%c]\n",f_14_exist);
         #endif

         if ((strcmp(ins_type,"19") == 0  || strcmp(ins_type,"16") == 0)&&(sug_ins_type==1))
         {
         	/* 16�B19�I�ؤ��\�P�ɩӫO�A�G���A�N�O�B�k�s mark by 061476 109.05.13 (1090414002_SC1)*/
         	/*if(f_16_exist=='Y'&&f_19_exist=='Y'){
         	    injured_cover= 0;
	            damage_cover = 0;
	            deduct       = 0;
	            ins_premium  = 0;
	            qcoverage    = 0;
	            mprem        = 0;
	            mdiscount    = 0;
	            pdiscount    = 0;
         	}*/
         }else if ((strcmp(ins_type,"15") == 0 )&&(sug_ins_type==1)){
         	/* �x���Υ��B�έ�09�|�ন05,�P�ɦA�s�W09,�Y�즳�[�ȫ�,�����אּ15,���]��ĳ05,�ҥH�n�A��ĳ67 */
         	/* ���b�e�����[15��, �]�����P��insert ��ĳ�έ��O�~���ܫ᭱�o��"�䤣����O�զX"�����~,�ҥH���B�n�b���ĳ��15�I�اאּ0*/
         	if(ins1589_chg_flag==1){
         	 	 if ((strncmp(iofficer,"A09",3) == 0)||(strncmp(iofficer,"A21",3) == 0)){
                     injured_cover= 0;
		               damage_cover = 0;
		               deduct       = 0;
		               ins_premium  = 0;
		               qcoverage    = 0;
		               mprem        = 0;
		               mdiscount    = 0;
		               pdiscount    = 0;
	             }
         	}
         	else if(ins1589_chg_flag==7)
         	{
         		/* 09�I�ا��ĳ120+121,�G�n���15,69,64�I�ت���ĳ��O�զX�M��0,�u�O�d���O�զX
         		   add by sylvia 103.10.03 */
         		/* �ରA���ӫ~��,��15,69,64���i�b��ĳ��O�զX��,���A�R�� modify by sylvia 104.03.09(1040217001_C1) */
         		/* injured_cover= 0;
		           damage_cover = 0;
		           deduct       = 0;
		           ins_premium  = 0;
		           qcoverage    = 0;
		           mprem        = 0;
		           mdiscount    = 0;
		           pdiscount    = 0;  */
         	}
         }
         else if (((strcmp(ins_type,"67") == 0)||(strcmp(ins_type,"65") == 0)||
                  (strcmp(ins_type,"63") == 0)) &&(sug_ins_type==1))
         {
         	/* 05�I�ا��ĳ118+119,�G�n���63,65,67�I�ت���ĳ��O�զX�M��0,�u�O�d���O�զX
         	   add by sylvia 103.10.03 */
         	/* �ରA���ӫ~��,��63,65,67���i�b��ĳ��O�զX��,���A�R�� modify by sylvia 104.03.09(1040217001_C1) */
         	if(ins1589_chg_flag==5){
         		/* injured_cover= 0;
		         damage_cover = 0;
		         deduct       = 0;
		         ins_premium  = 0;
		         qcoverage    = 0;
		         mprem        = 0;
		         mdiscount    = 0;
		         pdiscount    = 0;  */
            }
         }
         else if (((strcmp(ins_type,"106") == 0)||(strcmp(ins_type,"107") == 0)||
                  (strcmp(ins_type,"108") == 0)) &&(sug_ins_type==1))
         {
         	/* 105�I�ا��ĳ118+119,�G�n���106,107,108�I�ت���ĳ��O�զX�M��0,�u�O�d���O�զX
         	add by sylvia 103.10.03 */
         	/* �ରA���ӫ~��,��106,107,108���i�b��ĳ��O�զX��,���A�R�� modify by sylvia 104.03.09(1040217001_C1) */
         	if(ins1589_chg_flag==6){
         		/* injured_cover= 0;
		         damage_cover = 0;
		         deduct       = 0;
		         ins_premium  = 0;
		         qcoverage    = 0;
		         mprem        = 0;
		         mdiscount    = 0;
		         pdiscount    = 0; */
            }
         }
         else if (((strcmp(ins_type,"69") == 0)|| (strcmp(ins_type,"64") == 0)
                  || (strcmp(ins_type,"143") == 0)) && (sug_ins_type==1))
         {
         	/* 09�I�ا��ĳ120+121,�G�n���15,69,64�I�ت���ĳ��O�զX�M��0,�u�O�d���O�զX
         	add by sylvia 103.10.03 */
         	/* �ରA���ӫ~��,��15,69,64���i�b��ĳ��O�զX��,���A�R�� modify by sylvia 104.03.09(1040217001_C1) */
         	/* 1041222 �s�W143�I�اP�_ add by sylvia 104.12.22 (1041203004_C4) */
         	if(ins1589_chg_flag==7){
         		/* injured_cover= 0;
		         damage_cover = 0;
		         deduct       = 0;
		         ins_premium  = 0;
		         qcoverage    = 0;
		         mprem        = 0;
		         mdiscount    = 0;
		         pdiscount    = 0;  */
            }
         }
         else if (((strcmp(ins_type,"66") == 0)||(strcmp(ins_type,"61") == 0)||
                  (strcmp(ins_type,"62") == 0)) &&(sug_ins_type==1))
         {
         	/* 01�I�ا��ĳ122+123,�G�n���66,61,62�I�ت���ĳ��O�զX�M��0,�u�O�d���O�զX
         	add by sylvia 103.10.03 */
         	/* �ରA���ӫ~��,��66,61,62���i�b��ĳ��O�զX��,���A�R�� modify by sylvia 104.03.09(1040217001_C1) */
         	if(ins1589_chg_flag==8){
         		/* injured_cover= 0;
		         damage_cover = 0;
		         deduct       = 0;
		         ins_premium  = 0;
		         qcoverage    = 0;
		         mprem        = 0;
		         mdiscount    = 0;
		         pdiscount    = 0;  */
            }
         }
         if (((strcmp(ins_type,"110") == 0)||(strcmp(ins_type,"111") == 0)||(strcmp(ins_type,"112") == 0)) &&
             ((f_110_112_sug=='N') && (f_110_112_ori=='N') && (f_113_115_sug=='Y')))
         {
         	injured_cover= 0;
         	damage_cover = 0;
         	deduct       = 0;
         	ins_premium  = 0;
         	qcoverage    = 0;
         	mprem        = 0;
         	mdiscount    = 0;
         	pdiscount    = 0;
         }

         if((strcmp(ins_type,"112") == 0) && (insA_chg_flag > 0))
         {
            if (f_del_112=='Y'){
	            f_del_dmg = 0;
                INS_ptr=INS_ptr->next;
             	continue;
            }
         }

         /* 101.04.30, 96�B97�ά������[�I12��28�������O�զX�A�ȯd��ĳ��O�զX */
         if (flgIns96To11=='Y'){
         	 if( ( (strcmp(ins_type,"11") == 0 ) || (strcmp(ins_type,"19") == 0 ) ||
         	     (strcmp(ins_type,"12") == 0 ) || (strcmp(ins_type,"28") == 0 ) ) && (sug_ins_type==0) ){
         	     	injured_cover= 0;
         	     	damage_cover = 0;
         	     	deduct       = 0;
         	     	ins_premium  = 0;
         	     	mprem        = 0;
         	     	mdiscount    = 0;
         	     	pdiscount    = 0;
	         }
	         /* ���i�P�ɩӫO �G16�B17�B18�B19�B20�B22�B13�B76 */
	         if ((strcmp(ins_type,"16") == 0 ) || (strcmp(ins_type,"17") == 0 ) || (strcmp(ins_type,"18") == 0 ) || (strcmp(ins_type,"20") == 0 ) ||
	         	 (strcmp(ins_type,"22") == 0 ) || (strcmp(ins_type,"13") == 0 ) ||(strcmp(ins_type,"76") == 0 ) ){
	         	 INS_ptr=INS_ptr->next;
	         	 continue;
	         }
         }

         /* �Y155�ഫ163�A���N155�I�اR�� add by 061476 107.07.25 (1070625011_SC4) */
         if ((ins163_flag == 1) && (strcmp(ins_type,"155") == 0 )){
             f_del_dmg = 0;
             INS_ptr=INS_ptr->next;
             continue;
         }
         if (strcmp(ins_type,"24") == 0){
         	if (f_del_24=='Y'){
         		f_del_dmg = 0;
         		INS_ptr=INS_ptr->next;
         		continue;
         	}
         }
         /* 38�B39���� (1100119001_SC3) */
         if (strcmp(ins_type,"38") == 0){
         	if (f_del_38=='Y'){
         		f_del_dmg = 0;
         		INS_ptr=INS_ptr->next;
         		continue;
         	}
         }
         if (strcmp(ins_type,"39") == 0){
         	if (f_del_39=='Y'){
         		f_del_dmg = 0;
         		INS_ptr=INS_ptr->next;
         		continue;
         	}
         }

    	 /* 960416, 33�I�ذ���*/
         #ifdef PRINTF_FLAG
         printf("ins_type[%s],v_prem[%ld],ins_premium[%ld]\n",ins_type,v_prem,ins_premium);
         #endif

         /* 101.08.20 �Ȧ�q���ݭn�o�Ǹ�T(2p�q�l��)  */
         /* 101.07.11 ���T�����(ch_ins_grp1,ch_ins_grp2,ch_ins_grp3)�@�����S���γ~�A�����B�z�F */
         ch_ins[0] = '\0';
         find_flag = 0;
         for (chk_count=0 ; chk_count<max_insurance_type ; chk_count++)
         {
            if (strcmp(insurance_type[chk_count].iins_type,ins_type)==0)
            {
               strcpy(ch_ins,   insurance_type[chk_count].nins_abbr);
               find_flag = 1;
               break;
            }
         }

         if (find_flag == 0)
         {
              $EXECUTE nins INTO $ch_ins USING $ins_type;
         }

         if( strcmp(trim(old_ins_type), ins_type) != 0 )
         {
            /* �W�L�T��N����F�A���M�|���� 107.10.25 modify by 061476 (1071016006_SC1) */
            if (ins_grp_cnt<3) {
            	strcat(ch_ins_grp[ins_grp_cnt],trim(ch_ins));
            	ch_ins_cnt ++;
            }

            /*960730, �C��7���I��(�A�h�N�n�X���F)�A�@�T��A���L�������T�����γ~���� */
            if (ins_grp_cnt<3) {
                if (ch_ins_cnt == 7){
                    ins_grp_cnt += 1;
                    ch_ins_cnt =  0;
                }else{
                	strcat(ch_ins_grp[ins_grp_cnt],"�@");
                }
            }
            strcpy(old_ins_type, trim(ins_type) );
         }
         /*******�˱��h�����u�ݫe���O�O***************/
         if (strcmp(ins_type,"21")==0){
             /* mprem=0;   */ /* mark by sylvia 104.04.21 */
             qcoverage=0;  qserial=0;  qday = 0;   mexpense = 0;  mexp_disc = 0;
         }

         /***********�D�e���O�B�O�O***********/
         pre_inj_cover = pre_dea_cover = pre_dam_cover =pre_dedu=pre_prem =0;

         sprintf(buf1,"SELECT %s FROM %s:%s %s",
                      "minjured_cover,mdeath_cover,mdamage_cover,mdeduct,mins_premium,mdiscount",
                      FDBNAME,"ply_ins_type_last",
                      " WHERE ipolicy = ? and iins_type = ?");

         strcpy(ins_type_ttmp,trim(ins_type));

         /*980310,�s�O�v, 14 �I�Q���N�� 19 */
         if (ins1419_chg_flag==1){
            if (strcmp(ins_type,"19") == 0) strcpy(ins_type_ttmp,"14");
         }
         /*990604,  36,37 => 31,32, �ܧ��I�ث�,�h�~�O�O���n��36,37 */
         if (ins3637_chg_flag==1){
             if (strcmp(ins_type,"31") == 0) strcpy(ins_type_ttmp,"36");
             if (strcmp(ins_type,"32") == 0) strcpy(ins_type_ttmp,"37");
         }
         $PREPARE  pre_ins_type  FROM $buf1;
         $EXECUTE  pre_ins_type  INTO $pre_inj_cover,$pre_dea_cover,
                                      $pre_dam_cover,$pre_dedu,$pre_prem,$pre_mdiscount USING $last_ply,$ins_type_ttmp;

         if (SQLCODE == SQLNOTFOUND){
              pre_inj_cover = 0;
              pre_dea_cover = 0;
              pre_dam_cover = 0;
              pre_dedu = 0;
              pre_prem = 0 ;
              pre_mdiscount = 0;
         }

         /* 980416,���o 56�I�إh�~���|���B */
         /* �s�W266�I�� (1110308005_SC3)*/
         if ((strcmp(ins_type_ttmp,"56") == 0)||(strcmp(ins_type_ttmp,"136") == 0)||(strcmp(ins_type_ttmp,"166") == 0)||(strcmp(ins_type_ttmp,"266") == 0))
         {
             pre_daily_pay = 0;
             sprintf(buf1,"SELECT first 1 daily_pay FROM %s:%s %s",
                          FDBNAME,"ca_pa_ply_last",
                          " WHERE ipolicy = ? and iins_type = ? AND daily_pay > 0 ");
             $PREPARE  pre_ca_pa  FROM $buf1;
             $EXECUTE  pre_ca_pa  INTO $pre_daily_pay USING $last_ply,$ins_type_ttmp;
         }

         if (deduct==0) strcpy(ch_deduct,"�L");
         if (ISINS01(ins_type))
         {
             /* 86�I�ت�32���ئ��̨������m���ȯŶZ�]�w�������ۭt�B�A���O����� */
             /* 98�I�ب̼t���N���P�_�겣��(=1)�ζi�f��(=2)�O�A�ðO�����I�ة����ɦۭt�B��줤�A���O���I�ج�"�L�ۭt�B"*/
             if ((strcmp(ins_type,"01")==0)||(strcmp(ins_type,"05")==0)||(strcmp(ins_type,"09")==0)||
                 (strcmp(ins_type,"201")==0)||(strcmp(ins_type,"205")==0)||(strcmp(ins_type,"209")==0)||
                 (strcmp(ins_type,"120")==0)||(strcmp(ins_type,"122")==0)||(strcmp(ins_type,"125")==0)||
                 (strcmp(ins_type,"126")==0) ){
                 sprintf(str_deduct,"%d",deduct);
                 ch_deduct[0]=0;
                 $SELECT prn_deduct
                    INTO $ch_deduct
                    FROM ca_dmg_mdeduct
                   WHERE icar_type = $car_typei
                     AND ideduct   = $str_deduct;
                 if (SQLCODE == SQLNOTFOUND){
                      strcpy(ch_deduct,"�L");
                 }
                 strcpy(ch_deduct,trim(ch_deduct));
            }else if (strcmp(ins_type,"86") == 0){
                if (atoi(frate) >= 74)
                {
                    if (deduct>0)
                        sprintf(ch_deduct,"%d %",deduct);
                    else
                        strcpy(ch_deduct,"�L");
                }
                else
                    strcpy(ch_deduct,"�L");
            }else{
             	 strcpy(ch_deduct,"�L");
            }
         }
         else if (strcmp(ins_type,"11")==0||strcmp(ins_type,"211")==0)
         {
             #ifdef PRINTF_FLAG
             printf("in iins 11\n");
             #endif

	     /* 102.12.25 A�BB����}�� */
             /* 960628 */
             /** ����M�פ��ذe�I�ءA��e���O�O����ܬ� "(�M�ץ�)" **/
             iRemark_yn = 0;
             strcpy(sIprmt, " ");

             /* �U�L�@���M�צb�o�̧䤣��N��, �ҥH�u�M���D�U�L�@�����M�� modify by sylvia 104.05.24 */
             if ((f_AN_SHIN=='N')&&(f_NO_WORRY=='N'))
                strcpy(note1," ");

             if (IsPlyB=='Y'){
                 $EXECUTE plychk1_b
                     INTO $Aipolicy, $nproject, $nprocomp, $nproprem, $Biofficer, $BPlyClosed, $iRemark_yn, $sIprmt
                    USING $last_ply;
             }else{
                 $EXECUTE plychk1
                     INTO $Aipolicy, $nproject, $nprocomp, $nproprem, $Biofficer, $BPlyClosed, $iRemark_yn, $sIprmt
                    USING $last_ply;
         	 }

             if(SQLCODE != SQLNOTFOUND){
                 /* �U�L�@���M�צb�o�̧䤣��N��, �ҥH�u�M���D�U�L�@�����M�� modify by sylvia 104.05.24 */
                 if ((f_AN_SHIN=='N')&&(f_NO_WORRY=='N'))
                        strcpy(note1,sIprmt);  /* �M�ץN���g�J note1 add by sylvia 104.05.08 */

	             if (BPlyClosed==1){
                     pre_prem = -999;
                     strcpy(nproject," ");
                     strcpy(note1, " ");

		     #ifdef PRINTF_FLAG
		     printf("trace inequipment[%s]\n ",inequipment);
                     printf("trace Aiequip[%s]\n ",Aiequip);
                     #endif

                     strcpy(inequipment, equip_delete(inequipment,Aiequip)); /* 102.03 */
                 }
             }
             if ( f_YF4_ply == 'N'){  /* �����ɯũ���� */
                  pre_prem = -999;
             }
             if ( f_YF6_ply == 'N'){  /* DLR50�M�� */
                  pre_prem = -999;
             }
	          if (f_UF_ply == 'N' || f_YFB_ply == 'N')   {
                  pre_prem = -999;
             }
             strcpy(ch_deduct,itoa(deduct));
             strcat(ch_deduct,"%");
         }
         else if (strcmp(ins_type,"129")==0)
         {
             strcpy(ch_deduct,itoa(deduct));
             strcat(ch_deduct,"%");
         }
         else if ((strcmp(ins_type,"55")==0) || (strcmp(ins_type,"56")==0))
         {
            if (fProjNoPlyB=='Y'){
             	 /*970418,�樮�@�ӱM��(�S��B��),��ĳ�έ��O�զX�����*/
                 if(strcmp(ins_type,"56") == 0){
                 	 pre_prem = -999;
	             }
            }
            if ((strcmp(ins_type,"55")==0) ) {
             	 if (sug_ins_type==0){
             	     prem55_ori = ins_premium;
             	 }else if (sug_ins_type==1){
             	 	 prem55_sug = ins_premium;
             	 }
            }else if ((strcmp(ins_type,"56")==0)){
             	 if (sug_ins_type==0){
             	     prem56_ori = ins_premium;
             	 }else if (sug_ins_type==1){
             	 	 prem56_sug = ins_premium;
             	 }
            }
         }else if (strcmp(ins_type,"50")==0){
     	      if (sug_ins_type==0){
     	     	   prem50_ori = ins_premium;
     	      }else if (sug_ins_type==1){
     	         prem50_sug = ins_premium;
     	      }
         }else if (strcmp(ins_type,"38")==0){
     	     if (sug_ins_type==1) {
     	          prem38_sug = ins_premium;
     	     }else if (sug_ins_type==0) {
     	          prem38_ori = ins_premium; /* �s�W��O�J�p��ŦX�D���ϴ��A�Ȥ��ˮ� add by sylvia 106.01.16 (1051124002_C1)  */
     	     }
         }else if (strcmp(ins_type,"39")==0){
     	      if (sug_ins_type==0) {
     	     	   prem39_ori = ins_premium;
     	      }else if (sug_ins_type==1){
     	          prem39_sug = ins_premium;
     	      }
         }else if ((strcmp(ins_type,"71")==0) || (strcmp(ins_type,"72")==0)){
             strcpy(ch_deduct,itoa(deduct));
         }else if (strcmp(ins_type,"08")==0){
             strcpy(ch_deduct,"�̱��ڬ��w");
         }else if ((strcmp(ins_type,"10")==0) || (strcmp(ins_type,"07")==0) ||
                   (strcmp(ins_type,"127")==0)) {  /* 950608 add */
             /* �s�W07,127�I�اP�_,�ñN��r�אּ�e�P����l���I�fmodify by sylvia (1060515001_C1) */
             strcpy(ch_deduct,"�P����l���I");
         }else if ((strcmp(ins_type,"28")==0)||(strcmp(ins_type,"128")==0)){  /* 981002 add */
     	     if (deduct==0){
     	      	 strcpy(ch_deduct,"�L");
     	     }else{
                 strcpy(ch_deduct,itoa(deduct));
                 strcat(ch_deduct,"%");
           }
         }else if ((strcmp(ins_type,"32")==0)||(strcmp(ins_type,"232")==0)||
                   (strcmp(ins_type,"134")==0)||(strcmp(ins_type,"532")==0))
         {
            if (deduct==0){
     	      	 strcpy(ch_deduct,"�L");
     	    }else{
                 strcpy(ch_deduct,itoa(deduct));
            }
         }else if ((strcmp(ins_type,"31")==0)||(strcmp(ins_type,"231")==0)||
                   (strcmp(ins_type,"133")==0)||(strcmp(ins_type,"104")==0)||
                   (strcmp(ins_type,"531")==0)){  /* 102.10.23 add */
              /* �s�W104�I�ت��ۭt�B�P�_  add by sylvia 10.09.25 (bug�ץ�) */
     	      if (deduct==0){
     	      	 strcpy(ch_deduct,"�L");
     	      }else{
                 strcpy(ch_deduct,itoa(deduct));
            }
         }else if ((strcmp(ins_type,"149")==0)||(strcmp(ins_type,"249")==0)){
            /* �s�W149�I��  add by sylvia 106.02.16 (1050601006_C4) */
            if (deduct==0){
     	      	 strcpy(ch_deduct,"�L");
     	    }else{
                 strcpy(ch_deduct,itoa(deduct));
            }
         }else if (strcmp(ins_type,"18")==0){  /* 102.08.09 fix */
     	      if (deduct==0){
     	      	 strcpy(ch_deduct,"�L");
     	      }else{
                 strcpy(deduct_tmp,itoa(deduct));   /* ex. deduct = 5010;5020;6010;6020;7510;7520 ,ex. 10%(�_���B75%)*/
                 strncpy(deduct_tmp1, deduct_tmp     ,2); deduct_tmp1[2]='\0';
                 strncpy(deduct_tmp2, deduct_tmp+(2) ,2); deduct_tmp2[2]='\0';
                 sprintf(ch_deduct,"%s%%�_���B%s%%",deduct_tmp2,deduct_tmp1); /* ch_deduct char(12)�A�ҥH�h���A���~��o�U */
            }

            #ifdef PRINTF_FLAG
            printf("trace deduct_tmp [%s]\n ",deduct_tmp);
            printf("trace deduct_tmp2[%s]\n ",deduct_tmp2);
            printf("trace deduct_tmp1[%s]\n ",deduct_tmp1);
            printf(" ch_deduct       [%s]\n ",ch_deduct);
            #endif

         }else if ((strcmp(ins_type,"131")==0)||(strcmp(ins_type,"132")==0)||(strcmp(ins_type,"331")==0)||(strcmp(ins_type,"332")==0)) {
            sprintf(str_deduct,"%d",deduct);
            ch_deduct[0]=0;
            $SELECT prn_deduct
               INTO $ch_deduct
               FROM ca_dmg_mdeduct
              WHERE icar_type = $car_typei
                AND ideduct   = $str_deduct;
            if (SQLCODE == SQLNOTFOUND)
                  strcpy(ch_deduct,"�L");

            strcpy(ch_deduct,trim(ch_deduct));
         }else if ((strcmp(ins_type,"17")==0)||(strcmp(ins_type,"130")==0)) {
                strcpy(ch_deduct,"�P�ѵs�l���I"); /* add by sylvia (1060515001_C1) */
         }else if (strcmp(ins_type,"24")==0) {
                strcpy(ch_deduct,"�P�ĤT�H�d���I"); /* add by sylvia (1060515001_C1) */
         }else if ((strcmp(ins_type,"113")==0)||(strcmp(ins_type,"114")==0)) {
                /* add by 061476 (1080814008_C1) */
                if (deduct==0){
                	strcpy(ch_deduct,"�L");
                }else{
                	strcpy(ch_deduct,itoa(deduct));
                }
         }else if ((strcmp(ins_type,"176")==0)||(strcmp(ins_type,"177")==0)||(strcmp(ins_type,"178")==0)) {
         	/* �W�[�ۭt�B��� (1130510009_C13) */
         	if (deduct==0){
                	strcpy(ch_deduct,"�L");
                }else{
                	strcpy(ch_deduct,itoa(deduct));
                	strcat(ch_deduct,"%");
                }
         }else{
             strcpy(ch_deduct,"�L");
         }

         if (strlen(trim(ch_deduct)) == 0) strcpy(ch_deduct,"0");

         /* 102.08.08 �ŦX���ЫO�N(�q���N���e�|�X�GCAC1P)�B���w�t���ϥΫ��w���²v�̡A�Y�䨮�l�I�����I�إh�~�L��E�����ڡA�h���[�WE������
            ���l�I�����I�ج��G
            �i�ѵs�I�j(11)�B�i�ѵs�l���I�ҫ�-�ѵs�j(96)�B�i�ѵs�[�_���B�l���I�j(18)�B
            �i�����I�j(01�B05�B08�B09�B85�B105) */
         if ((f_provision_E == 0)&&(f_Honda_dep == 'Y')){
             if (ISINS_PROV_E(ins_type)){
             	if (strlen(trim(provision)) == 0){ /* provision��table�s�� */
             		strcpy(provision,trim(provision));
             		strcat(provision,"E");
             	}else{
             		strcpy(provision,trim(provision));
             		strcat(provision,";E");
             	}
             }
         }

         /* �ŦXZ���ڳW�h��, �۰ʩ�provision�ɤWZ���� add by sylvia 105.03.17 (1050226003_C3) */
         /* cnt_provision_Z == 0 && f_provision_Z == 'N' ==> �LZ����,���۰ʥ[Z����
            cnt_provision_Z == 0 && f_provision_Z == 'Y' ==> �LZ����,���۰ʥ[Z����
            cnt_provision_Z > 0 && f_provision_Z == 'Y' ==> ��Z����
            cnt_provision_Z > 0 && f_provision_Z == 'N' ==> �����D,���Ӥ��|�����زզX */
         /* printf("---- 11362 ipolicy=[%s] cnt_provision_Z=[%d]f_provision_Z=[%c]----- \n",last_ply,cnt_provision_Z,f_provision_Z); */
         if ((cnt_provision_Z == 0) && (f_provision_Z == 'Y'))
         {
            if (ISINS_PROV_Z(ins_type)){
            	if (strlen(trim(provision)) == 0){ /* provision��table�s�� */
             		strcpy(provision,trim(provision));
             		strcat(provision,"Z");
             	}else{
             		strcpy(provision,trim(provision));
             		strcat(provision,";Z");
             	}
            }
         }
         /* �ŦXP���ڳW�h�̡A�۰ʸɤWP���� add by 061476(1071226006_SC3) */
         if ((f_provision_P == 'Y')||(f_sug_P == 'Y'))
         {
         	if (ISINS_PROV_P(ins_type)){
         		if(strstr(tmp_provision,"P;") == NULL)
         		{
         			if (strlen(trim(provision)) == 0){  /* provision��table�s�� */
         				strcpy(provision,trim(provision));
         				strcat(provision,"P");
         			}else{
         				strcpy(provision,trim(provision));
         				strcat(provision,";P");
         			}
         		}
         	}
         }
         /* �ŦXQ���ڳW�h�̡A�۰ʸɤWQ���� add by 061476(1071226006_SC3) */
         if (f_provision_Q == 'Y')
         {
         	if (ISINS_PROV_QM(ins_type)){
         		if(strstr(tmp_provision,"Q;") == NULL)
         		{
         			if (strlen(trim(provision)) == 0){  /* provision��table�s�� */
         				strcpy(provision,trim(provision));
         				strcat(provision,"Q");
         			}else{
         				strcpy(provision,trim(provision));
         				strcat(provision,";Q");
         			}
         		}
         	}
         }
         /* �ŦXM���ڳW�h�̡A�۰ʸɤWM���� add by 061476(1081105005_SC3) */
         if (f_provision_M == 'Y')
         {
         	if (ISINS_PROV_QM(ins_type)){
         		if(strstr(tmp_provision,"M;") == NULL)
         		{
         			if (strlen(trim(provision)) == 0){  /* provision��table�s�� */
         				strcpy(provision,trim(provision));
         				strcat(provision,"M");
         			}else{
         				strcpy(provision,trim(provision));
         				strcat(provision,";M");
         			}
         		}
         	}
         }
         /* �ŦXY���ڳW�h�̡A�۰ʸɤWY���� (1130827011_C03) */
         if (f_provision_Y == 'Y')
         {
         	if (ISINS_PROV_Y(ins_type)){
         		if(strstr(tmp_provision,"Y;") == NULL)
         		{
         			if (strlen(trim(provision)) == 0){  /* provision��table�s�� */
         				strcpy(provision,trim(provision));
         				strcat(provision,"Y");
         			}else{
         				strcpy(provision,trim(provision));
         				strcat(provision,";Y");
         			}
         		}
         	}
         }
         /* 98�I���ഫ09+K �� 09+K��ĳ�I�خɡA�i���[�����[�I�@�֥[�WK���� add by 061476 (1080408008_SC3)*/
         /* K���ڰ���A09+K�אּ198�I�� mark by 061476 (1091103004_SC1)*/
         /*if ((ins98_chg_flag == 1)||(ins09k_flag == 1))
         {
         	if (ISINS_PROV_K(ins_type))
         	{
         		if(strstr(provision,"K") == NULL)
         		{
         			strcpy(provision,trim(provision));
         			strcat(provision,"K");
         		}
         	}
         }*/

         /* �ۥΨ���O�~��108/04~109/03�~���n�۰ʪ��[V���ڡA109/04(�]�t109/04)�H�ᤣ�A�۰ʪ��[V���� */
         /* ��~����O�~��109/03~110/02�~���n�۰ʪ��[V���ڡA110/03(�]�t110/03)�H�ᤣ�A�۰ʪ��[V���� */
         /*1101124014_SC1_��~���b��ĳ��O��צۭt�B���[�WV���� add by 071004 */
         /* �w�L�ɮġA���i�R�� */
         /*if (f_provision_V == 'Y')
         {
             if (strcmp(ins_type,"09")==0 ||(strcmp(ins_type,"209")==0)
             {
                 if(strstr(tmp_provision,"V;") == NULL)
                 {
         	     if (strlen(trim(provision)) == 0){  * provision��table�s�� *
         	         strcpy(provision,trim(provision));
         	         strcat(provision,"V");
         	     }else{
         	         strcpy(provision,trim(provision));
         	         strcat(provision,";V");
         	     }
                 }
             }
         }*/


         #ifdef PRINTF_FLAG
         printf("sug_ins_type[%d] iins_type[%s] \n",sug_ins_type,ins_type);
         #endif
         #ifdef PRINTF_FLAG
         printf("10250  ipolicy=[%s]sug_ins_type [%ld]\n",last_ply,sug_ins_type);
         printf("dom ins_type[%s]\n",ins_type);
         printf(" injured_cover [%ld]\n",injured_cover);
         printf(" death_cover   [%ld]\n",death_cover  );
         printf(" damage_cover  [%ld]\n",damage_cover );
         printf(" deduct        [%ld]\n",deduct       );
         printf(" mprem         [%f]\n", mprem        );
         printf(" ins_premium   [%ld]\n",ins_premium  );
         printf(" qcoverage     [%ld]\n",qcoverage    );
         printf(" pre_inj_cover [%ld]\n",pre_inj_cover);
         printf(" pre_dea_cover [%ld]\n",pre_dea_cover);
         printf(" pre_dam_cover [%ld]\n",pre_dam_cover);
         printf(" pre_dedu      [%ld]\n",pre_dedu     );
         printf(" pre_prem      [%ld]\n",pre_prem     );
         printf(" qserial       [%ld]\n",qserial      );
         printf(" ch_deduct     [%s ]\n",ch_deduct    );
         printf(" linnum        [%ld]\n",linnum       );
         printf(" mdiscount     [%ld]\n",mdiscount    );
         printf(" pre_mdiscount [%ld]\n",pre_mdiscount);
         printf(" provision     [%s]\n" ,provision    );
         #endif
         if( sug_ins_type == 1 )
         {
            if (strcmp(ins_type,"21") != 0)
                 v_prem = v_prem + ins_premium + mdiscount;
            else
                 mdiscount = 0;

            sum_mdiscount += mdiscount;

            #ifdef PRINTF_FLAG
               printf("in sug_ins_type\n");
            #endif

            if( intopt == 25 ){
                 /* [del intopt == 25]102.03 �w��5/1�ᤧ 5,6��|���X�椧��O���ơA�ɻ����O�X���ơA�H�Q���H�o��O�� 102.07���i�R��*/
                 /* ��ӳ����J�p�覡�ɸ�� */
            }else{
            	/*  ��O�楪����ĳ��O  */
            	sprintf(buf1,"INSERT INTO %s:%s %s",
            	             FDBNAME,"ply_ins_type_302(ipolicy, iins_type, minjured_cover, mdeath_cover, mdamage_cover, mdeduct, mprem, mins_premium, qcoverage, pre_inj_cover, pre_dea_cover, pre_dam_cover, pre_deduct, pre_minsprem, qserial, ch_deduct, linnum, mdiscount, pre_mdiscount, qday, mexpense, mexp_disc, drate_ym, ori_inj_cover, ori_dea_cover, ori_dam_cover, ori_deduct, ori_premium, provision,mdrunk_prem,mdrunk_pure_prem,pcar_price,safe_rate,manage_rate,mviolate_prem,mviolate_pure_prem)",
            	             " VALUES (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,0,0,0,0,0,?,?,?,?,?,?,?,?)");
            	$PREPARE STM_ins_302b FROM $buf1;

            	/*  990319, �Υ�60�M��(73)(�R1�e5), �Υ�50�M��(74)(�R1�e4)
            	            �Ĥ@�~11�I�ؤ���ܡA���e����O�զX������ܡ]�Ĥ@�~�۶O�^ */
            	/* 960416,33�I�ذ��� , ���O�d�e����O���,�G��ĳ����O�զX�O�O��0 */
            	/* 950908,�O�O���B���s��,��X���~�T��,�B�ӵ��O������J�p���� ;
            	          ���]��O�����ĳ�ܧ��I��,�ɭP���I�ثO�O���s��,���b����*/

            	/* 960129,���׸U�o�ֱM�ײĤ@�~11�I�ؤ���ܡA���e����O�զX������ܡ]�Ĥ@�~�۶O�^ */
            	/* �x���Υ�(A21*) 09=>05 ,09�O�O���s ,�B���P�ɦL�X 09 �� 05*/
            	/* ������X�I 110-112�]����>2���ĳ113-115, ��110-112�O�B�O�O����0, �B���P�ɦL�X110-115�I�� add by sylvia 104.05.15 */
            	#ifdef PRINTF_FLAG
            	printf(" ------- ins1589_chg_flag = [%d]\n " , ins1589_chg_flag);
            	printf("----- 10230 --ins_premium=[%d]--f_110_112_ori=[%c]f_110_112_sug=[%c] \n",ins_premium,f_110_112_ori,f_110_112_ori);
            	#endif
            	if (ins_premium <= 0){
            		if ((!(f_16_exist=='Y'&&f_19_exist=='Y'))&&(ins1589_chg_flag==0)&&(fProjNoPlyB=='N')&&(f_113_115_sug == 'N'))
            		{       /* �L�����I���ܧ� */
            			$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'��ĳ�I�ثO�O���B���s','1', 'E30',$iofficer);
            		}else{
            			/* �������I���ܧ� */
            			/* 1041222 �s�W143�I�اP�_ add by sylvia 104.12.22 (1041203004_C4) */
            			if(((ins1589_chg_flag==1)&&(((strncmp(iofficer,"A09",3) == 0)||(strncmp(iofficer,"A21",3) == 0))&&(strcmp(ins_type,"09") == 0 || strcmp(ins_type,"15") == 0 || strcmp(ins_type,"209") == 0))) ||
            			    (f_16_exist=='Y'&&f_19_exist=='Y')||(fProjNoPlyB=='Y')||
            			    ((ins1589_chg_flag==2)&&(strcmp(ins_type,"05") == 0 || strcmp(ins_type,"205") == 0))||
            			    ((ins1589_chg_flag==3)&&(strcmp(ins_type,"85") == 0))||
            			    (((ins1589_chg_flag>=5)&&(ins1589_chg_flag<=8))&&
            			    ((strcmp(ins_type,"05")==0)||(strcmp(ins_type,"205")==0)||(strcmp(ins_type,"67")==0)||(strcmp(ins_type,"65")==0)||(strcmp(ins_type,"63")==0)||
            			    (strcmp(ins_type,"105")==0)||(strcmp(ins_type,"106")==0)||(strcmp(ins_type,"107")==0)||(strcmp(ins_type,"108")==0)||
            			    (strcmp(ins_type,"09")==0)||(strcmp(ins_type,"209")==0)||(strcmp(ins_type,"15")==0)||(strcmp(ins_type,"69")==0)||(strcmp(ins_type,"64")==0)||(strcmp(ins_type,"143")==0)||
            			    (strcmp(ins_type,"01")==0)||(strcmp(ins_type,"201")==0)||(strcmp(ins_type,"66")==0)||(strcmp(ins_type,"61")==0)||(strcmp(ins_type,"62")==0)))||
            			    ((f_113_115_sug == 'Y')&&((strcmp(ins_type,"110")==0)||(strcmp(ins_type,"111")==0)||(strcmp(ins_type,"112")==0)))||
            			    (insA_chg_flag > 0))
            			{
            				$EXECUTE STM_ins_302b
            				   USING $last_ply,$ins_type,$injured_cover,
            	                                 $death_cover,$damage_cover,$deduct,$mprem,$ins_premium,
            	                                 $qcoverage,$pre_inj_cover,$pre_dea_cover,$pre_dam_cover,
            	                                 $pre_dedu,$pre_prem,$qserial,$ch_deduct,$linnum,$mdiscount,$pre_mdiscount,
            	                                 $qday,$mexpense,$mexp_disc,$frate,$provision,$mdrunk_prem,$mdrunk_pure_prem,
            	                                 $pcar_price,$safe_rate,$manage_rate,$mviolate_prem,$mviolate_pure_prem;

            				#ifdef PRINTF_FLAG
            				printf("11274: INSERT ply_ins_type_302 SQLCODE[%d]\n",SQLCODE);
            				#endif
            			}else{
            				$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'��ĳ�I�ثO�O���B���s','1','E30',$iofficer);
            			}
            		}
            	}else{
            		$EXECUTE STM_ins_302b
            		   USING $last_ply,$ins_type,$injured_cover,
            		         $death_cover,$damage_cover,$deduct,$mprem,$ins_premium,
            		         $qcoverage,$pre_inj_cover,$pre_dea_cover,$pre_dam_cover,
            		         $pre_dedu,$pre_prem,$qserial,$ch_deduct,$linnum,$mdiscount,$pre_mdiscount,
            		         $qday,$mexpense,$mexp_disc,$frate,$provision,$mdrunk_prem,$mdrunk_pure_prem,
            		         $pcar_price,$safe_rate,$manage_rate,$mviolate_prem,$mviolate_pure_prem;
            		#ifdef PRINTF_FLAG
            		printf("11296:INSERT ply_ins_type_302 SQLCODE[%d]\n",SQLCODE);
            		#endif
            	}
            	#ifdef PRINTF_FLAG
            	printf("11300:Insert ply_ins_type_302-->last_ply[%s]\n",last_ply);
            	#endif
            	if (SQLCODE == -239){
            		$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�I�ئ�����ƭ���','2','E31',$iofficer);
            	}else{
            		if (SQLCODE!=0) goto get302_err1;
            	}
            }
         }
         else
         {
         	if (strcmp(ins_type,"21") != 0){
         		v_ori_prem = v_ori_prem + ins_premium;
         	}
         	#ifdef PRINTF_FLAG
         	printf("in ori iins last_ply[%s] ins_type[%s]\n", last_ply, ins_type);
         	printf("Trace -- injured_cover = [%ld] \n",  injured_cover);
         	printf("Trace -- death_cover = [%ld] \n",  death_cover);
         	printf("Trace -- damage_cover = [%ld] \n",  damage_cover);
         	printf("Trace -- deduct = [%ld] \n",  deduct);
         	printf("Trace -- provision = [%s] \n",  provision);
         	printf("Trace -- pcar_price = [%f] \n",  pcar_price);
         	printf("Trace -- safe_rate = [%f] \n",  safe_rate);
         	printf("Trace -- manage_rate = [%f] \n",  manage_rate);
         	#endif

         	if( intopt == 25 ){
         		/* [del intopt == 25]102.03 �w��5/1�ᤧ 5,6��|���X�椧��O���ơA�ɻ����O�X���ơA�H�Q���H�o��O�� 102.07���i�R��*/
         		/* ��ӳ����J�p�覡�ɸ�� */
         	}else{
         		/*  ��O��k����O�I�զX  */
         		sprintf(buf1,"UPDATE %s:ply_ins_type_302 \
         		                 SET ori_inj_cover=?, ori_dea_cover=?, ori_dam_cover=?, \
         		                     ori_deduct=?, ori_premium=?,provision=?, pcar_price=?, safe_rate=?, manage_rate = ? \
         		               WHERE ipolicy ='%s' AND iins_type='%s'",FDBNAME, last_ply, ins_type );
         		$PREPARE STM_ins_302c FROM $buf1;
         		$EXECUTE STM_ins_302c USING $injured_cover,$death_cover,$damage_cover,
         		                            $deduct,$ins_premium, $provision, $pcar_price, $safe_rate, $manage_rate;
         		#ifdef PRINTF_FLAG
         		printf("10082--UPDATE ply_ins_type_302 SQLCODE[%d]\n",SQLCODE);
         		printf("10083--UPDATE ply_ins_type_302 sqlca.sqlerrd[2][%d]\n",sqlca.sqlerrd[2]);
         		#endif

               if (sqlca.sqlerrd[2] == 0 )
               {
                    $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$ins_type,'�I�ح�O�I�զX�䤣��','2','E29',$iofficer);
               }
               else
               {
                   if (SQLCODE!=0) goto get302_err1;
               }
            }
         }
         #ifdef PRINTF_FLAG
         printf("dom ins_type[%s]\n",ins_type);
         #endif

         ins_cnt++;
         INS_ptr=INS_ptr->next;
      }
      if (ins_cnt==0){ /* 951108�S����������� */
    	   goto end;
      }
      #ifdef PRINTF_FLAG
         printf("ins33_flag =[%d]  ins35_flag =[%d]  ins48_flag =[%d]  ins56_flag =[%d]\n",
             ins33_flag, ins35_flag , ins48_flag, ins56_flag );
         printf("\n\nstruct iins_type_33\n");
      #endif

      if( intopt == 25 ){
         /* [del intopt == 25]102.03 �w��5/1�ᤧ 5,6��|���X�椧��O���ơA�ɻ����O�X���ơA�H�Q���H�o��O�� 102.07���i�R��*/
         /* ��ӳ����J�p�覡�ɸ�� */
      }else{
         INS_ptr_33=Ifirst_33;
         while(INS_ptr_33)
         {
         	#ifdef PRINTF_FLAG
         	printf("iins_type[%s] cIinsurant[%s] cIins_scope[%s] \n lDaily_pay[%d] dPdiscount[%f] lMdiscount[%ld] lMins_premium[%ld]\n",
         	INS_ptr_33->iins_type, INS_ptr_33->cIinsurant,
         	INS_ptr_33->cIins_scope,INS_ptr_33->lDaily_pay,
         	INS_ptr_33->dPdiscount,INS_ptr_33->lMdiscount,
         	INS_ptr_33->lMins_premium);
         	#endif

         	INS_ptr_33= INS_ptr_33->next;
         }

         #ifdef PRINTF_FLAG
         printf("end of struct 33\n");
         #endif

         /*** �ˮ`�I���Ӹ�� ***/
         if (ins35_flag==1)
         {
         	stmt[0]='\0';
         	sprintf(stmt, " INSERT INTO ca_pa_ply_302                            \
	                        (ipolicy,iins_type,iinsurant,ninsurant,dbirth,ainsurant, \
	                         iins_scope,icareer,mins_amt,mins_premium,         \
	                         mdiscount,napplicant,relation_appl,nbeneficiary,  \
	                         relation_bene,daily_pay,mr_ins_prem,mr_pure_prem) \
	                        VALUES                                               \
	                        (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");

	        $PREPARE ins35_1 FROM $stmt;

	        Icurr_33=Ifirst_33;
	        while (Icurr_33)
	        {
	            if( strcmp(trim(Icurr_33->iins_type),"35") != 0 )
	            {
	            	Icurr_33=Icurr_33->next;
	            	continue;
	            }

	            strcpy(cIinsurant     , Icurr_33->cIinsurant);
	            strcpy(cIins_type     , Icurr_33->iins_type);
	            strcpy(cNinsurant     , Icurr_33->cNinsurant);
	            strcpy(cAinsurant     , Icurr_33->cAinsurant);
	            strcpy(cIins_scope    , Icurr_33->cIins_scope);
	            strcpy(cIcareer       , Icurr_33->cIcareer);
	            strcpy(cNapplicant    , Icurr_33->cNapplicant);
	            strcpy(cRelation_appl , Icurr_33->cRelation_appl);
	            strcpy(cNbeneficiary  , Icurr_33->cNbeneficiary);
	            strcpy(cRelation_bene , Icurr_33->cRelation_bene);

	            lMins_amt      = Icurr_33->lMins_amt;
	            lMins_premium  = (long)Icurr_33->lMins_premium;
	            lMdiscount     = Icurr_33->lMdiscount;
	            lDbirth        = Icurr_33->lDbirth;
	            lDaily_pay     = Icurr_33->lDaily_pay;
	            lMr_ins_prem   = Icurr_33->lMr_ins_prem;
	            lMr_pure_prem  = Icurr_33->lMr_pure_prem;

	            $EXECUTE ins35_1
	               USING $last_ply, $cIins_type,
	                     $cIinsurant, $cNinsurant, $lDbirth, $cAinsurant,
	                     $cIins_scope, $cIcareer, $lMins_amt, $lMins_premium,
	                     $lMdiscount,
	                     $cNapplicant, $cRelation_appl, $cNbeneficiary, $cRelation_bene,
	                     $lDaily_pay, $lMr_ins_prem, $lMr_pure_prem;

	            #ifdef PRINTF_FLAG
	            printf("iins 35 insert =[%d] SQLCODE=[%d]\n", sqlca.sqlerrd[2],SQLCODE );
	            #endif

	            Icurr_33=Icurr_33->next;
            }   /* end while */
         }

         if (ins48_flag==1)
         {
	         stmt[0]='\0';
	         sprintf(stmt, " INSERT INTO ca_pa_ply_302                            \
	                          (ipolicy,iins_type,iinsurant,ninsurant,dbirth,ainsurant, \
	                           iins_scope,icareer,mins_amt,mins_premium,         \
	                           mdiscount,napplicant,relation_appl,nbeneficiary,  \
	                           relation_bene,daily_pay,mr_ins_prem,mr_pure_prem,ori_daily_pay,pre_daily_pay )\
	                        VALUES                                               \
	                          (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");

	         $PREPARE ins48_1 FROM $stmt;

	         Icurr_33=Ifirst_33;
	         while (Icurr_33)
	         {
	         	if( strcmp(trim(Icurr_33->iins_type),"48") != 0 )
	         	{
	         		Icurr_33=Icurr_33->next;
	         		continue;
	         	}

	         	strcpy(cIinsurant     , Icurr_33->cIinsurant);
	         	strcpy(cIins_type     , Icurr_33->iins_type);
	         	strcpy(cNinsurant     , Icurr_33->cNinsurant);
	         	strcpy(cAinsurant     , Icurr_33->cAinsurant);
	         	strcpy(cIins_scope    , Icurr_33->cIins_scope);
	         	strcpy(cIcareer       , Icurr_33->cIcareer);
	         	strcpy(cNapplicant    , Icurr_33->cNapplicant);
	         	strcpy(cRelation_appl , Icurr_33->cRelation_appl);
	         	strcpy(cNbeneficiary  , Icurr_33->cNbeneficiary);
	         	strcpy(cRelation_bene , Icurr_33->cRelation_bene);

	         	lMins_amt      = Icurr_33->lMins_amt;
	         	lMins_premium  = (long)Icurr_33->lMins_premium;
	         	lMdiscount     = Icurr_33->lMdiscount;
	         	lDbirth        = Icurr_33->lDbirth;
	         	lDaily_pay     = Icurr_33->lDaily_pay;
	         	lMr_ins_prem   = Icurr_33->lMr_ins_prem;
	         	lMr_pure_prem  = Icurr_33->lMr_pure_prem;

	         	/* �R���r���Y���� ' ', '\f' , '\n' , '\r' ,'\t' , '\v' ���r��*/
	         	/* �H��ֹq�l�ɤ��t���i�C�L�r�� */
	         	strcpy(cNinsurant     , trimx(cNinsurant));
	         	strcpy(cAinsurant     , trimx(cAinsurant));
	         	strcpy(cNbeneficiary  , trimx(cNbeneficiary));

	         	$EXECUTE ins48_1
	         	   USING $last_ply, $cIins_type,
	         	         $cIinsurant, $cNinsurant, $lDbirth, $cAinsurant,
	         	         $cIins_scope, $cIcareer, $lMins_amt, $lMins_premium,
	         	         $lMdiscount,
	         	         $cNapplicant, $cRelation_appl, $cNbeneficiary, $cRelation_bene,
	         	         $lDaily_pay, $lMr_ins_prem, $lMr_pure_prem,$lDaily_pay,$pre_daily_pay_48;

                        #ifdef PRINTF_FLAG
                        printf("iins 48 insert =[%d] SQLCODE=[%d]\n", sqlca.sqlerrd[2],SQLCODE );
                        #endif

                        Icurr_33=Icurr_33->next;
                 }   /* end while */
	      }

	      /* 950704 */
	      if (ins56_flag==1 || ins56_sug_flag==1 || ins136_flag==1 || ins166_flag==1 || ins266_flag==1 )
	      {
	         stmt[0]='\0';
	         sprintf(stmt, " INSERT INTO ca_pa_ply_302                            \
	                          (ipolicy,iins_type,iinsurant,ninsurant,dbirth,ainsurant, \
	                           iins_scope,icareer,mins_amt,mins_premium,         \
	                           mdiscount,napplicant,relation_appl,nbeneficiary,  \
	                           relation_bene,daily_pay,mr_ins_prem,mr_pure_prem,pre_daily_pay, \
	                           tbenef, abenef_zip, abenef )\
	                          VALUES                                               \
	                          (?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?) ");

	         $PREPARE ins56_1 FROM $stmt;

	         Icurr_33=Ifirst_33;
	         while (Icurr_33)
	         {
	              if(( strcmp(trim(Icurr_33->iins_type),"56") != 0 ) &&
	                 ( strcmp(trim(Icurr_33->iins_type),"136") != 0 ) &&
	                 ( strcmp(trim(Icurr_33->iins_type),"166") != 0 ) &&
	                 ( strcmp(trim(Icurr_33->iins_type),"266") != 0 ))
	              {
	              	Icurr_33=Icurr_33->next;
	              	continue;
	              }

	              sug_ins_type = Icurr_33->sug_iins_type;
	              strcpy(cIinsurant     , Icurr_33->cIinsurant);
	              strcpy(cIins_type     , Icurr_33->iins_type);
	              strcpy(cNinsurant     , Icurr_33->cNinsurant);
	              strcpy(cAinsurant     , Icurr_33->cAinsurant);
	              strcpy(cIins_scope    , Icurr_33->cIins_scope);
	              strcpy(cIcareer       , Icurr_33->cIcareer);
	              strcpy(cNapplicant    , Icurr_33->cNapplicant);
	              strcpy(cRelation_appl , Icurr_33->cRelation_appl);
	              strcpy(cNbeneficiary  , Icurr_33->cNbeneficiary);
	              strcpy(cRelation_bene , Icurr_33->cRelation_bene);
	              strcpy(cTbenef        , Icurr_33->cTbenef);
	              strcpy(cAbenef_zip    , Icurr_33->cAbenef_zip);
	              strcpy(cAbenef        , Icurr_33->cAbenef);

	              lMins_amt      = Icurr_33->lMins_amt;
	              lMins_premium  = (long)Icurr_33->lMins_premium;
	              lMdiscount     = Icurr_33->lMdiscount;
	              lDbirth        = Icurr_33->lDbirth;
	              lDaily_pay     = Icurr_33->lDaily_pay;
	              lMr_ins_prem   = Icurr_33->lMr_ins_prem;
	              lMr_pure_prem  = Icurr_33->lMr_pure_prem;

	              /* �R���r���Y���� ' ', '\f' , '\n' , '\r' ,'\t' , '\v' ���r��*/
	              /* �H��ֹq�l�ɤ��t���i�C�L�r�� */
	              strcpy(cNinsurant     , trimx(cNinsurant));
	              strcpy(cAinsurant     , trimx(cAinsurant));
	              strcpy(cNbeneficiary  , trimx(cNbeneficiary));

	              if( sug_ins_type == 1 ){
	                  $EXECUTE ins56_1
	                    USING $last_ply, $cIins_type,
	                          $cIinsurant, $cNinsurant, $lDbirth, $cAinsurant,
	                          $cIins_scope, $cIcareer, $lMins_amt, $lMins_premium,
	                          $lMdiscount,
	                          $cNapplicant, $cRelation_appl, $cNbeneficiary, $cRelation_bene,
	                          $lDaily_pay, $lMr_ins_prem, $lMr_pure_prem,$pre_daily_pay,
	                          $cTbenef, $cAbenef_zip, $cAbenef;

	                  #ifdef PRINTF_FLAG
	                  printf("iins 56 insert =[%d] SQLCODE=[%d]\n", sqlca.sqlerrd[2],SQLCODE );
	                  #endif

	                  if((ins7780_chg_flag == 1) && (f_80_exist == 'Y'))
	                  {
	                  	$update ca_pa_ply_302  set ori_daily_pay = daily_pay
	                  	  where ipolicy = $last_ply and iins_type = '56';
	                  }

	              }else{
	              	  /* 980416, ca_pa_ply_302 ��daily_pay ���Ϥ���ĳ�B���O�B�h�~�A�O�B�B�O�O���Ϥ��n�� ply_ins_type_302 */
	                  /* ���B�O�B�B�O�O���������O�զX */
	                  sprintf(stmt, " UPDATE ca_pa_ply_302 \
			                     SET mins_amt = ? ,mins_premium = ?, ori_daily_pay = ?, \
			                         mr_ins_prem = ? , mr_pure_prem = ? \
			                   WHERE ipolicy ='%s' AND iins_type='%s' AND iinsurant = '%s' AND icareer = '%s' AND iins_scope = '%s' "
			          , last_ply,cIins_type,cIinsurant,cIcareer,cIins_scope );

			          #ifdef PRINTF_FLAG
			          printf("Trace -- stmt = [%s] \n",  stmt);
			          #endif
			          $PREPARE ins56_1_u FROM $stmt;

			          $EXECUTE ins56_1_u
			             USING $lMins_amt,$lMins_premium,$lDaily_pay, $lMr_ins_prem, $lMr_pure_prem ;

			          #ifdef PRINTF_FLAG
			          printf("iins 56 update =[%d] SQLCODE=[%d]\n", sqlca.sqlerrd[2],SQLCODE );
			          #endif
	              }
	              Icurr_33=Icurr_33->next;
	         }/* end while */
	      }

	      while (Ifirst_33 != NULL){ /* free all allocated memory */
	         Icurr_33=Ifirst_33;
	         Ifirst_33=Icurr_33->next;
	         free(Icurr_33);
	      }

	      /* 960612, ���ݪ��I34 */
	      while (IfirstPlyInsCover != NULL)
	      {                                /* free all allocated memory */
	         IcurrPlyInsCover=IfirstPlyInsCover;
	         IfirstPlyInsCover=IcurrPlyInsCover->next;
	         free(IcurrPlyInsCover);
	      }
	      while (IfirstPlyInsCover1 != NULL)
	      {                                /* free all allocated memory */
	         IcurrPlyInsCover1=IfirstPlyInsCover1;
	         IfirstPlyInsCover1=IcurrPlyInsCover1->next;
	         free(IcurrPlyInsCover1);
	      }
	      while (IfirstPlyInsCover2 != NULL)
	      {                                /* free all allocated memory */
	         IcurrPlyInsCover2=IfirstPlyInsCover2;
	         IfirstPlyInsCover2=IcurrPlyInsCover2->next;
	         free(IcurrPlyInsCover2);
	      }

      }/* end of {*/
      /****end of insert ply_ins_type_302  ***/

      /* �]���ӫ~�����ഫ�s�ӫ~���ˮ� add by sylvia 105.12.29 (1051214006_C4) */
      mdamage_0509 = mprem_0509 = 0;
      mdamage_1523 = mprem_1523 = 0;

      $select mdamage_cover, mins_premium
         into $mdamage_0509, $mprem_0509
         from ply_ins_type_302
        where ipolicy = $last_ply
          and iins_type in ('09','05','209','205');
      if (SQLCODE==SQLNOTFOUND)
      {
      	mdamage_0509 = 0; mprem_0509 = 0;
      }
      $select mdamage_cover, mins_premium
         into $mdamage_1523, $mprem_1523
         from ply_ins_type_302
        where ipolicy = $last_ply
          and iins_type in ('152','153');

      if (SQLCODE==SQLNOTFOUND)
      {
        mdamage_1523 = 0; mprem_1523 = 0;
      }

      /* 1.�Y ������O�O�B �� �������l�O�B�A�B 1�U �� ������O�O�B �� 10�U */
      if ((mdamage_0509 > 0) && (mdamage_1523 > 0))
      {
        if ((mdamage_0509 >= mdamage_1523))
        {
            if (((mdamage_0509 >=10000) && (mdamage_0509 < 100000)) && (mdamage_1523 > 10000))
            {
                $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,'152/153','�]�����I�O�I���B����10�U�A�G�쨮���I�������l�O�I���B�w���խ�,�Y�����D�Ь��ӫO��','1','E54',$iofficer);

                if (strlen(trim(remark1))>10){
                	strcpy(remark6,"���]�����I�O�I���B����10�U�A�G�쨮���I�������l�O�I���B�w���խ�,�Y�����D�Ь��ӫO��");
                	strcpy(remark7," ");
                }else{
                	strcpy(remark1,"���]�����I�O�I���B����10�U�A�G�쨮���I�������l�O�I���B�w���խ�,�Y�����D�Ь��ӫO��");
                	strcpy(remark2," ");
                }
            }

            if (mdamage_0509 < 10000)
            {
                $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,'152/153','�]�����I�O�I���B����1�U�A�G�쨮���I�Ψ���[�I���w����,�Y�����D�Ь��ӫO��','1','E54',$iofficer);

                if (strlen(trim(remark1))>10){
                	strcpy(remark6,"���]�����I�O�I���B����1�U�A�G�쨮���I�Ψ���[�I���w����,�Y�����D�Ь��ӫO��");
                	strcpy(remark7," ");
                }else{
                	strcpy(remark1,"���]�����I�O�I���B����1�U�A�G�쨮���I�Ψ���[�I���w����,�Y�����D�Ь��ӫO��");
                	strcpy(remark2," ");
                }
            }
        }
        else
        {
            $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,'152/153','�]�����I�O�I���B�C�󤣩����l�O�B,�G�쨮���I�Ψ���[�I���w����,�Y�����D�Ь��ӫO��','1','E54',$iofficer);

            if (strlen(trim(remark1))>10){
            	strcpy(remark6,"���]�����I�O�I���B�C�󤣩����l�O�B,�G�쨮���I�Ψ���[�I���w����,�Y�����D�Ь��ӫO��");
            	strcpy(remark7," ");
            }else{
            	strcpy(remark1,"���]�����I�O�I���B�C�󤣩����l�O�B,�G�쨮���I�Ψ���[�I���w����,�Y�����D�Ь��ӫO��");
            	strcpy(remark2," ");
            }
        }

        if ((mprem_1523+mprem_0509) < (mdamage_1523))
        {
            if (insA_chg_flag == 1)
            {
                $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,'09+153 ','����h�~����O���I��,�����~�O�O�C�󤣩����l�O�B,�G�����ѳ���,�Y���ðݽЬ��ӫO��','1','E54',$iofficer);

                if (strlen(trim(remark1))>10){
                	strcpy(remark6,"������h�~����O�������l���[����,�����~�O�O�C�󤣩����l�O�B,�G�����ѳ���,�Y���ðݽЬ��ӫO��");
                	strcpy(remark7," ");
                }else{
                	strcpy(remark1,"������h�~����O�������l���[����,�����~�O�O�C�󤣩����l�O�B,�G�����ѳ���,�Y���ðݽЬ��ӫO��");
                	strcpy(remark2," ");
                }
            }
        }
      }

      /* HCC�֫O�ҫ��ظm add by 061476 (1090803002_SC2) */
      /* �ק�HCC�p������ modify by 061476 (1100401005_SC1) */
      /* �ק�E56���O���� modify by 061476 (1111202007_SC1) */
      /* �s�֫O�ҫ��ظm  modify by 061476 (1120220002_SC3) */
      if (assuredf[0]=='1')
      {
        if ((fcard_class[0] == '2' || (fcard_class[0] == '1' && v_prem != 0)) &&
            (strcmp(car_typei,"03")==0 || strcmp(car_typei,"04")==0 || strcmp(car_typei,"22")==0 ||
             strcmp(car_typei,"01")==0 || strcmp(car_typei,"02")==0 || strcmp(car_typei,"32")==0 || strcmp(car_typei,"34")==0))
        {
        	sprintf(stmt_hcc, "INSERT Into sysdb:ca_hcc_302 Values ( "
        	        "?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,'%s',current)",userid);
        	$PREPARE preInsertHcc FROM $stmt_hcc;

        	memset(&ca_hcc_fac, 0, sizeof(ca_hcc_fac));

        	IfirstHccIns = IcurrHccIns = IlastHccIns = NULL;

        	#ifdef PRINTF_FLAG
        	printf("-- trace last_ply[%s]\n "      , last_ply);
        	printf("-- trace iroute[%s]\n "        , iroute);
        	printf("-- trace sex[%s]\n "           , sex);
        	printf("-- trace marriage[%s]\n "      , marriage);
        	printf("-- trace car_typei[%s]\n "     , car_typei);
        	printf("-- trace aassured_zip[%s]\n "  , aassured_zip);
        	#endif
        	/**------------------- �g�J�u�ǤJ�Ѽơv ca_hcc_fac -------------------**/
        	/* --------------------- ������       �g�J�I�ة���     ������ ---------------------- */
        	INS_ptr=Ifirst;
        	while(INS_ptr)
        	{
        		iset = INS_ptr->sug_iins_type;
        		strcpy(s_iins_type, INS_ptr->ins_type);
        		strcpy(s_iins_type, trim(s_iins_type));

        		if ((INS_ptr->sug_iins_type == 0) && (INS_ptr->damage_cover == 0))
        		{
        			INS_ptr=INS_ptr->next;
        			continue;
        		}
        		if ((INS_ptr->sug_iins_type == 1) && (INS_ptr->damage_cover == 0))
        		{
        			INS_ptr=INS_ptr->next;
        			continue;
        		}
        		/*if ((strlen(trim(note1))>0) && (strcmp(s_iins_type,"11") == 0))
        		{
        			INS_ptr=INS_ptr->next;
        			continue;
        		}*/
        		/* �N�R�����I�ؤ��C�J�p�� add by 061476 (1100712004_SC1) */
        		if (strcmp(s_iins_type,"**") == 0)
        		{
        			INS_ptr=INS_ptr->next;
        			continue;
        		}

        		IcurrHccIns = (struct INS_TYPE_HCC *)malloc(sizeof(struct INS_TYPE_HCC));

        		if (IfirstHccIns == NULL)
        		{
        			IfirstHccIns = IcurrHccIns;
        		}
        		else
        		{
        			IlastHccIns->next = IcurrHccIns;
        		}
        		IlastHccIns = IcurrHccIns;
        		IcurrHccIns->next = NULL;

        		IcurrHccIns->iIns_Set = iset;
        		strcpy(IcurrHccIns->sIns_type, s_iins_type);

        		INS_ptr=INS_ptr->next;
        	}
        	/* ------------------ ������       �g�J�I�ة���     ������ ----------------------*/

        	/* ------------------ ������       �g�J��L���        ������ ----------------------*/
        	strcpy(ca_hcc_fac.sNumber, trim(last_ply));
        	strcpy(ca_hcc_fac.sRoute, trim(iroute));
        	strcpy(ca_hcc_fac.sSex, trim(sex));
        	strcpy(ca_hcc_fac.sMarriage, trim(marriage));
        	strcpy(ca_hcc_fac.sCarType, trim(car_typei));
        	strcpy(ca_hcc_fac.sZipCode, trim(aassured_zip));
        	strcpy(ca_hcc_fac.sProdYear, trim(pro_year));
        	strcpy(ca_hcc_fac.sAssuredID, trim(license));
        	strcpy(ca_hcc_fac.sBrandNo, trim(brandi));

        	if (ftrade == 'Y')
        	{
        		strcpy(ca_hcc_fac.sTrade, "Y");
        		strcpy(ca_hcc_fac.sExistPlyDetail, "Y");
        	}
        	else
        	{
        		strcpy(ca_hcc_fac.sTrade, "N");
        		strcpy(ca_hcc_fac.sExistPlyDetail, "N");
        	}

        	ca_hcc_fac.dBirthDate = dbirth;
        	ca_hcc_fac.iPlyPeriod = qply_period;
        	if ((fcard_class[0] == '1') && (v_prem != 0)) /* �j���ĳ���N */
        	{
        		ca_hcc_fac.dPlyBeginDate_C1[0]=dply_begin;
        		rsetnull(CLONGTYPE, (char *)&ca_hcc_fac.dPlyBeginDate_C1[1]);
        		rsetnull(CLONGTYPE, (char *)&ca_hcc_fac.dPlyBeginDate_C2[0]);
        		ca_hcc_fac.dPlyBeginDate_C2[1]=dply_begin;
        		rsetnull(CLONGTYPE, (char *)&ca_hcc_fac.dFirstPlyDate_C1);
        		strcpy(cdfirst_ply,cm_from_infdate_100(dfirst_ply_3132));
        		ldfirst_ply = cm_ymd_cdate(cdfirst_ply);
        		ca_hcc_fac.dFirstPlyDate_C2 = ldfirst_ply;
        		ca_hcc_fac.iDamageAccidentSum5year = qdmg_acc_3132;
        		ca_hcc_fac.iLiaAccidentSum5year = qlia_acc_3132;
        		ca_hcc_fac.iDutyAccidentSum5year = qduty_sum_3132;
        		ca_hcc_fac.iAccidentSum5year = qdmg_acc_sum_3132;
        		strcpy(ca_hcc_fac.fHave_Newa_C_2y, itoa(fhave_newa_3132));
        	}
        	else
        	{
        		rsetnull(CLONGTYPE, (char *)&ca_hcc_fac.dPlyBeginDate_C1[0]);
        		rsetnull(CLONGTYPE, (char *)&ca_hcc_fac.dPlyBeginDate_C1[1]);
        		ca_hcc_fac.dPlyBeginDate_C2[0]=dply_begin;
        		ca_hcc_fac.dPlyBeginDate_C2[1]=dply_begin;
        		rsetnull(CLONGTYPE, (char *)&ca_hcc_fac.dFirstPlyDate_C1);
        		strcpy(cdfirst_ply,cm_from_infdate_100(dfirst_ply));
        		ldfirst_ply = cm_ymd_cdate(cdfirst_ply);
        		ca_hcc_fac.dFirstPlyDate_C2 = ldfirst_ply;
        		ca_hcc_fac.iDamageAccidentSum5year = qdmg_acc_sum_5y_renew;
        		ca_hcc_fac.iLiaAccidentSum5year = qlia_acc_sum_5y_renew;
        		ca_hcc_fac.iDutyAccidentSum5year = qduty_sum_5y_renew;
        		ca_hcc_fac.iAccidentSum5year = qacc_sum_5y_renew;
        		strcpy(ca_hcc_fac.fHave_Newa_C_2y, itoa(fhave_newa_c_2y_renew));
        	}

        	        #ifdef PRINTF_FLAG
        		printf("ca_hcc_fac.sNumber     = [%s]\n", ca_hcc_fac.sNumber);
        		printf("ca_hcc_fac.sRoute      = [%s]\n", ca_hcc_fac.sRoute);
        		printf("ca_hcc_fac.sSex        = [%s]\n", ca_hcc_fac.sSex);
        		printf("ca_hcc_fac.sMarriage   = [%s]\n", ca_hcc_fac.sMarriage);
        		printf("ca_hcc_fac.sCarType    = [%s]\n", ca_hcc_fac.sCarType);
        		printf("ca_hcc_fac.sZipCode    = [%s]\n", ca_hcc_fac.sZipCode);
        		printf("ca_hcc_fac.sProdYear   = [%s]\n", ca_hcc_fac.sProdYear);
        		printf("ca_hcc_fac.sAssuredID  = [%s]\n", ca_hcc_fac.sAssuredID);
        		printf("ca_hcc_fac.sBrandNo    = [%s]\n", ca_hcc_fac.sBrandNo);
        		printf("ftrade                 = [%c]\n", ftrade);
        		printf("ca_hcc_fac.sTrade      = [%s]\n", ca_hcc_fac.sTrade);
        		printf("ca_hcc_fac.dPlyBeginDate_C2[0]  = [%ld]\n", ca_hcc_fac.dPlyBeginDate_C2[0]);
        		printf("ca_hcc_fac.dPlyBeginDate_C2[1]  = [%ld]\n", ca_hcc_fac.dPlyBeginDate_C2[1]);
        		printf("ca_hcc_fac.dBirthDate           = [%f]\n", ca_hcc_fac.dBirthDate);
        		printf("dfirst_ply   = [%s]\n", dfirst_ply);
        		printf("cdfirst_ply  = [%s]\n", cdfirst_ply);
        		printf("ldfirst_ply  = [%d]\n", ldfirst_ply);
        		printf("ca_hcc_fac.dFirstPlyDate_C1  = [%ld]\n", ca_hcc_fac.dFirstPlyDate_C1);
        		printf("ca_hcc_fac.dFirstPlyDate_C2  = [%ld]\n", ca_hcc_fac.dFirstPlyDate_C2);
        		printf("ca_hcc_fac.iDamageAccidentSum5year = [%d]\n", ca_hcc_fac.iDamageAccidentSum5year);
        		printf("ca_hcc_fac.iLiaAccidentSum5year    = [%d]\n", ca_hcc_fac.iLiaAccidentSum5year);
        		printf("ca_hcc_fac.iDutyAccidentSum5year   = [%d]\n", ca_hcc_fac.iDutyAccidentSum5year);
        		printf("ca_hcc_fac.iAccidentSum5year       = [%d]\n", ca_hcc_fac.iAccidentSum5year);
        		printf("ca_hcc_fac.fHave_Newa_C_2y         = [%s]\n", ca_hcc_fac.fHave_Newa_C_2y);
        		#endif

        	/* ------------------ ������       �g�J��L���        ������ ----------------------*/

        	/*------------------------- ��I�s get_ca_hcc_level_cartype() --------------------------*/
        	/*rc = get_ca_hcc_level(&iHccLevel, ca_hcc_fac, &ca_hcc_lvl, v_sMsg);*/
        	rc = get_ca_hcc_level_cartype(&iHccLevel, ca_hcc_fac, &ca_hcc_lvl, v_sMsg);
        	printf("-- trace rc[%ld]\n ", rc);
        	if (rc != M_CM_OK)
        	{
        		printf("-- get_ca_hcc_level_cartype() rc[%d], v_sMsg[%s]\n ", rc, v_sMsg);
        		$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,' ','HCC�p�⦳�~','1','E56',$iofficer);
        		/*goto end;*/
        		/*goto get302_err;*/
        	}

        	/**---------------------- ���o�u�ǥX�Ѽơv ca_hcc_lvl ------------------------**/
        	for (iset = 0; iset < 2; iset++) /*2 �ӧ�O�զX,0�G���O ; 1:��ĳ��O*/
        	{
        		if (iHccLevel[iset] == -1)
        		{
        			printf("����O�զX���B�z\n\n");
        			continue;
        		}

        		#ifdef PRINTF_FLAG
        		printf("ca_hcc_fac.sNumber        = [%s]\n", ca_hcc_fac.sNumber);
        		printf("iset                      = [%d]\n", iset);
        		printf("iHccLevel                 = [%d]\n", iHccLevel[iset]);                                                    /* ���ůż� */
        		printf("qlevel                    = [%d]\n", ca_hcc_lvl.qlevel[iset]);                                            /* ���ůż� */
        		printf("pscore                    = [%f]\n", ca_hcc_lvl.pscore[iset]);                                            /* �`�� */
        		printf("iroute_main               = [%s]\n", ca_hcc_lvl.iroute_main[iset]);                                       /* C01�G�T��, M01�G���� */
        		printf("drate                     = [%d]=>[%s]\n", ca_hcc_lvl.drate[iset], cm_edate_str(ca_hcc_lvl.drate[iset])); /* �O�v�ͮĤ� */
        		printf("i1_sex_marriage_value     = [%s]\n", ca_hcc_lvl.i1_sex_marriage_value[iset]);                             /* �ʧO�αB��( F1:�k,�w�B; F2:�k,���B; M1:�k,�w�B; M2:�k,���B ) */
        		printf("p1_sex_marriage_factor    = [%f]\n", ca_hcc_lvl.p1_sex_marriage_factor[iset]);                            /* �ʧO�αB�ëY�� */
        		printf("q2_age_value              = [%d]\n", ca_hcc_lvl.q2_age_value[iset]);                                      /* �~�� */
        		printf("p2_age_factor             = [%f]\n", ca_hcc_lvl.p2_age_factor[iset]);                                     /* �~�֫Y�� */
        		printf("q3_dmg_acc_sum_5y_value   = [%d]\n", ca_hcc_lvl.q3_dmg_acc_sum_5y_value[iset]);                           /* �e���~�����I�߮ץB�ߴڪ��B��0���߮ץ�� */
        		printf("p3_dmg_acc_sum_5y_factor  = [%f]\n", ca_hcc_lvl.p3_dmg_acc_sum_5y_factor[iset]);                          /* �e���~�����I�߮ץB�ߴڪ��B��0���߮ץ�ƫY�� */
        		printf("q4_lia_acc_sum_5y_value   = [%d]\n", ca_hcc_lvl.q4_lia_acc_sum_5y_value[iset]);                           /* �e���~�ĤT�H�d���I���߮ץ�� */
        		printf("p4_lia_acc_sum_5y_factor  = [%f]\n", ca_hcc_lvl.p4_lia_acc_sum_5y_factor[iset]);                          /* �e���~�ĤT�H�d���I���߮ץ�ƫY�� */
        		printf("q5_duty_acc_sum_5y_value  = [%d]\n", ca_hcc_lvl.q5_duty_acc_sum_5y_value[iset]);                          /* �e���~���F�d���p�����߮ץ�� */
        		printf("p5_duty_acc_sum_5y_factor = [%f]\n", ca_hcc_lvl.p5_duty_acc_sum_5y_factor[iset]);                         /* �e���~���F�d�p�����߮ץ�ƫY�� */
        		printf("q8_car_age_value          = [%d]\n", ca_hcc_lvl.q8_car_age_value[iset]);                                  /* ���� */
        		printf("p8_car_age_factor         = [%f]\n", ca_hcc_lvl.p8_car_age_factor[iset]);                                 /* ���֫Y�� */
        		printf("f10_lia_value             = [%s]\n", ca_hcc_lvl.f10_lia_value[iset]);                                     /* �O�_��O���d�I( N:�_, Y:�O, C:��j ) */
        		printf("p10_lia_factor            = [%f]\n", ca_hcc_lvl.p10_lia_factor[iset]);                                    /* ��O���d�Y�� */
        		printf("f11_brg_value             = [%s]\n", ca_hcc_lvl.f11_brg_value[iset]);                                     /* �O�_��O�ѵs�I( N:�_, Y:�O, C:��j ) */
        		printf("p11_brg_factor            = [%f]\n", ca_hcc_lvl.p11_brg_factor[iset]);                                    /* ��O�ѵs�Y�� */
        		printf("q12_ext_ins_sum_value     = [%d]\n", ca_hcc_lvl.q12_ext_ins_sum_value[iset]);                             /* ���[�I�ƶq */
        		printf("p12_ext_ins_sum_factor    = [%f]\n", ca_hcc_lvl.p12_ext_ins_sum_factor[iset]);                            /* ���[�I�ƶq�Y�� */
        		printf("i13_ply_area_value        = [%s]\n", ca_hcc_lvl.i13_ply_area_value[iset]);                                /* �a�ϥN�X */
        		printf("p13_ply_area_factor       = [%f]\n", ca_hcc_lvl.p13_ply_area_factor[iset]);                               /* �a�ϥN�X�Y�� */
        		printf("i14_cartype_year_value    = [%s]\n", ca_hcc_lvl.i14_cartype_year_value[iset]);                            /* ���ؤΫO�� */
        		printf("p14_cartype_year_factor   = [%f]\n", ca_hcc_lvl.p14_cartype_year_factor[iset]);                           /* ���ؤΫO���Y�� */
        		printf("f15_injure_value          = [%s]\n", ca_hcc_lvl.f15_injure_value[iset]);                                  /* �O�_��O�ˮ`�I(0:�_ 1:�O) */
        		printf("p15_injure_factor         = [%f]\n", ca_hcc_lvl.p15_injure_factor[iset]);                                 /* ��O�ˮ`�I�Y�� */
        		printf("q16_product_sum_value     = [%d]\n", ca_hcc_lvl.q16_product_sum_value[iset]);                             /* ��O�ӫ~�`�� */
        		printf("p16_product_sum_factor    = [%f]\n", ca_hcc_lvl.p16_product_sum_factor[iset]);                            /* �ӫ~�`�ƫY�� */
        		printf("q17_acc_sum_5y_value      = [%d]\n", ca_hcc_lvl.q17_acc_sum_5y_value[iset]);                              /* �L�h5�~�߮ץ�� */
        		printf("p17_acc_sum_5y_factor     = [%f]\n", ca_hcc_lvl.p17_acc_sum_5y_factor[iset]);                             /* �L�h5�~�߮ץ�ƫY�� */
        		printf("f18_have_newa_c_2y_value  = [%s]\n", ca_hcc_lvl.f18_have_newa_c_2y_value[iset]);                          /* �L�h2�~�O�_�b�s�w��O�L�T���I(0:�_ 1:�O) */
        		printf("p18_have_newa_c_2y_factor = [%f]\n", ca_hcc_lvl.p18_have_newa_c_2y_factor[iset]);                         /* �L�h2�~��O�L�s�w�T���I�Y�� */
        		printf("i19_series_value          = [%s]\n", ca_hcc_lvl.i19_series_value[iset]);                                  /* �����ݩ�(0:�겣 1:�i�f) */
        		printf("p19_series_factor         = [%f]\n", ca_hcc_lvl.p19_series_factor[iset]);                                 /* �����ݩʫY�� */
        		printf("q20_ext_ins_notdmg_value  = [%d]\n", ca_hcc_lvl.q20_ext_ins_notdmg_value[iset]);                          /* ��O�D������[�I�Ӽ� */
        		printf("p20_ext_ins_notdmg_factor = [%f]\n", ca_hcc_lvl.p20_ext_ins_notdmg_factor[iset]);                         /* �D������[�I�ӼƫY�� */
        		printf("q21_ext_ins_isdmg_value   = [%d]\n", ca_hcc_lvl.q21_ext_ins_isdmg_value[iset]);                           /* ��O������[�I�Ӽ� */
        		printf("p21_ext_ins_isdmg_factor  = [%f]\n", ca_hcc_lvl.p21_ext_ins_isdmg_factor[iset]);                          /* ������[�I�ӼƫY�� */
        		#endif

        		printf(".....................   �g�JLog�� into ca_hcc_302 ....................\n");

        		$WHENEVER SQLERROR CONTINUE;

        	RETRY_INSERT:

        		$EXECUTE preInsertHcc
			   USING $ca_hcc_fac.sNumber,
			         $iset, $ca_hcc_lvl.iroute_main[iset], $ca_hcc_lvl.drate[iset],
			         $ca_hcc_lvl.i1_sex_marriage_value[iset], $ca_hcc_lvl.p1_sex_marriage_factor[iset],
			         $ca_hcc_lvl.q2_age_value[iset], $ca_hcc_lvl.p2_age_factor[iset],
			         $ca_hcc_lvl.q3_dmg_acc_sum_5y_value[iset], $ca_hcc_lvl.p3_dmg_acc_sum_5y_factor[iset],
			         $ca_hcc_lvl.q4_lia_acc_sum_5y_value[iset], $ca_hcc_lvl.p4_lia_acc_sum_5y_factor[iset],
			         $ca_hcc_lvl.q5_duty_acc_sum_5y_value[iset], $ca_hcc_lvl.p5_duty_acc_sum_5y_factor[iset],
			         $ca_hcc_lvl.q8_car_age_value[iset], $ca_hcc_lvl.p8_car_age_factor[iset],
			         $ca_hcc_lvl.f10_lia_value[iset], $ca_hcc_lvl.p10_lia_factor[iset],
			         $ca_hcc_lvl.f11_brg_value[iset], $ca_hcc_lvl.p11_brg_factor[iset],
			         $ca_hcc_lvl.q12_ext_ins_sum_value[iset], $ca_hcc_lvl.p12_ext_ins_sum_factor[iset],
			         $ca_hcc_lvl.i13_ply_area_value[iset], $ca_hcc_lvl.p13_ply_area_factor[iset],
			         $ca_hcc_lvl.i14_cartype_year_value[iset], $ca_hcc_lvl.p14_cartype_year_factor[iset],
			         $ca_hcc_lvl.f15_injure_value[iset], $ca_hcc_lvl.p15_injure_factor[iset],
			         $ca_hcc_lvl.q16_product_sum_value[iset], $ca_hcc_lvl.p16_product_sum_factor[iset],
			         $ca_hcc_lvl.q17_acc_sum_5y_value[iset], $ca_hcc_lvl.p17_acc_sum_5y_factor[iset],
			         $ca_hcc_lvl.f18_have_newa_c_2y_value[iset], $ca_hcc_lvl.p18_have_newa_c_2y_factor[iset],
			         $ca_hcc_lvl.i19_series_value[iset], $ca_hcc_lvl.p19_series_factor[iset],
			         $ca_hcc_lvl.q20_ext_ins_notdmg_value[iset], $ca_hcc_lvl.p20_ext_ins_notdmg_factor[iset],
			         $ca_hcc_lvl.q21_ext_ins_isdmg_value[iset], $ca_hcc_lvl.p21_ext_ins_isdmg_factor[iset],
			         $ca_hcc_lvl.pscore[iset], $ca_hcc_lvl.qlevel[iset];

			printf("--trace SQLCODE[%d]\n", SQLCODE);
			if (SQLCODE < 0)
			{
				if (SQLCODE == -239)
				{
					printf("-239=> Deleting ....................\n");
					$DELETE FROM sysdb : ca_hcc_302
					  WHERE ipolicy = $ca_hcc_fac.sNumber
					    AND qins_set = $iset
					    AND iroute_main = $ca_hcc_lvl.iroute_main[iset];
					 printf("--trace SQLCODE[%d], sqlca.sqlerrd[2]=[%d]\n", SQLCODE, sqlca.sqlerrd[2]);

					 if (sqlca.sqlerrd[2] == 0)
					 {
					 	printf("�渹[%s]�զX[%d]�q��[%s]�w�s�b�A���� delete �� failed", ca_hcc_fac.sNumber, iset, ca_hcc_lvl.iroute_main[iset]);
					 	$WHENEVER SQLERROR GOTO get302_err;
					 	continue;
					 }
					 else
					 {
					 	printf("Delet success.................\n");
					 	goto RETRY_INSERT;
					 }
				}
				else
				{
					printf("�渹[%s]�զX[%d]�q��[%s]�AInsert ca_hcc_302 Err�GSQLCODE=[%d],sqlca.sqlerrm=[%s],sqlca.sqlerrd[1]",
					       ca_hcc_fac.sNumber, iset, ca_hcc_lvl.iroute_main[iset], SQLCODE, sqlca.sqlerrm, sqlca.sqlerrd[1]);
					/*continue;  */
					goto get302_err;
				}
			}

			/*$WHENEVER SQLERROR GOTO get302_err;*/
			/* ��46-50���ų��C�J�ˮ֡A�è���BA�BPA�q���ư� (1111202007_SC1) */
			/* ������������ (1120220002_SC3) */
			if ((ca_hcc_lvl.qlevel[iset] >= 46) &&
			    (strncmp(iroute,"I",1) != 0) && (strncmp(iroute,"C",1) != 0))
			{
				if (fcard_class[0] == '2')
				{
					strcpy(sFullDBName, get_car_full_dbname(last_ply));
					sprintf(stmt_hcc2, " select count(*) from %s:appraisal "
					        " where (facc_duty IN ('1','4') or fdmg_duty IN ('1','4')) "
					        " and ipolicy = ? ; ",sFullDBName);
					$PREPARE stm_cnthcc FROM $stmt_hcc2;
					$EXECUTE stm_cnthcc INTO $cnt_hcc USING $last_ply;

					if (cnt_hcc > 0)
					{
						if (ca_hcc_lvl.qlevel[iset] == 50)
						{
							$INSERT INTO duplic1 VALUES
							($last_ply,$last_iengine,'','�����I����-�O��F�d���w�Φ��d�X�I�@���C�J�ӫO�����O','1','E56',$iofficer);
						}
						else
						{
							$INSERT INTO duplic1 VALUES
							($last_ply,$last_iengine,'','�������I����-�O��F�d���w�Φ��d�X�I�@���C�J�Ұϭ��O','1','E57',$iofficer);
						}
					}
				}
				if ((fcard_class[0] == '1') && (v_prem != 0))
				{
					v_prem = 0;
					tot_prem = 0;

					$delete from ply_ins_type_302
					  where iins_type != '21'
					    and ipolicy = $last_ply;
				}
			}
			$WHENEVER SQLERROR CONTINUE;
		}
	     /*}end else*/
	}
      }

      #ifdef PRINTF_FLAG
         printf("ENd ply_ins_type_302\n");
      #endif

      /*******���y***********/
      if (assuredf[0] == '3' || assuredf[0] == '4'){
         strcpy(fnation,"2");
      }else{
         strcpy(fnation,"1");
      }
      /**�t�P����**/
      nbrand[0] = '\0';
      #ifdef PRINTF_FLAG
      printf("brandi[%s]\n",brandi);
      #endif

      /* �אּ����<ipro_year ���̤j�~��, �A�䤣��~�� >ipro_year ���̤p�~��
         ��: ��J���s�y�~����2014, �Y�d�L2014�~�������, �h���� <2014����1�� (2013), �A�d����h�� >2014����@��(2015)
         modify by sylvia 104.09.15  (1040714001_C3)
      */

      $SELECT first 1 nbrand INTO $nbrand
         FROM ca_car_model
        WHERE ibrand = $brandi
          AND ipro_year = $pro_year
          AND drate=(select drate from ca_rate_date
                      where itable = 'ca_car_model' and icode = $tmp_frate2 );
      if (NOT_FOUND){
            $SELECT first 1 nbrand INTO $nbrand
               FROM ca_car_model
              WHERE ibrand = $brandi
                AND ipro_year < $pro_year
                AND drate=(select drate from ca_rate_date
                      where itable = 'ca_car_model' and icode = $tmp_frate2 )
              order by ipro_year desc;

            if (NOT_FOUND){
                $SELECT first 1 nbrand INTO $nbrand
                   FROM ca_car_model
                  WHERE ibrand = $brandi
                    AND ipro_year > $pro_year
                    AND drate=(select drate from ca_rate_date
                                 where itable = 'ca_car_model' and icode = $tmp_frate2 )
                  order by ipro_year;

            }
      }

      sLastChinese(nbrand,20);
      sLastChinese(brandn,10);
      #ifdef PRINTF_FLAG
         printf("nbrand[%s]\n",nbrand);
         printf("ibrand[%s]\n",brandi);
         printf("brandn[%s]\n",brandn);
      #endif



      /******�`�O�O********/
      if( strcmp(fcard_class,"1")==0){
         v_ori_prem = 0;  /* v_prem�Btot_prem �i�ण��0�A�]����j�i���ĳ���N�I�A���N�I���`�O�O�n��b�j���I�O�渹�� v_prem�Btot_prem �� */
      }
      else
      {
         /* 101.07.11 , �h�~�S�O38�B39�I�ت̡A�Y�u��ĳ��O�զX�v���N�I�O�O�p��3000��(���t50�I��)�A
                       �B55+56�I�ثO�O�p��1300���̡A�h�u��ĳ��O�զX�v���A�s�W38�B39�I��
                ���k�G����ĳ38�B39�A�̫�J�p�X��O�զX�κ�X�O�O�A�A�ˮ֫O�O����A���ŦX�̦A�R��38�B39 */
         /* 38�B39����A�֫O���A130�B131�]�@�֨��� mark by 061476 110.04.01 (1100119001_SC3) */

        /* �ˮ֥��N�I�O�O<100 ���J�p add by sylvia 106.06.15 (1060608010_C1) */
        if (v_ori_prem < 100)
        {
        	if ((strncmp(iofficer,"N",1) == 0) || (strncmp(iofficer,"W",1) == 0))
        	{ /* �M�ץ󤴵M�n�J�p add by sylvia 106.11.01 (�\��mail �q��)  */}
        	else
        	{
        		sprintf(tMsg,"���O�զX���N�I�O�O[ %d ]<100 ���J�p ",v_ori_prem);
        		$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,' ',$tMsg,'1','E51',$iofficer);
        	}
        }
      }
      tot_prem  =  v_prem ;

      /******���m���ȧאּ�H�������*******/
      rfmtdouble(car_price * 10000,"##,###,###",scar_price);

      /****�Q�O�I�H�[���͡A�p�j****/
      /* �]�q�lñ�p��ݤ�����ư��D�A�������͡B�p�j modity by 061476 107.07.02 (1070620006_SC1)*/
      #ifdef PRINTF_FLAG
         printf("ipolicy[%s],assuredf[%s],sex[%s]\n",last_ply,assuredf,sex);
      #endif
      strcpy(assuredn,trim(assuredn));
      if (ichg_applicant > 0)  strcpy(napplicant,assuredn);    /* �n�O�H�W��           */

      #ifdef PRINTF_FLAG
      printf("assuredn[%s]\n",assuredn);
      printf("Insert policy_302-->last_ply[%s]\n",last_ply);
      printf("dmg_ac_cnt[1] == [%s]\n",dmg_ac_cnt[1]);
      #endif

      /* 980605,Ū��������~��/�q����~������****/
      /* get_route_data(), input=> ( 1:����/�q����~��; 2:����/�q����~��),�g��N��,������~��/�q���N��,���ӳq����~���N��
                         output => ����/�q����~������W��  */
      LHsIbig_Nname[0]=' ';
      LHsIbig_Nname[1]='\0';
      /* ���ӥ�imgr��쬰"1",��L�h�����q�� */
      if (strlen(tmp_big_sales)>2){
         if (imgr[0] != 1){
        	   rc = get_route_data(1, iofficer, iroute, tmp_big_sales, LHsIbig_Nname, v_sMsg);
         }else{
        	   rc = get_route_data(1, iofficer, tmp_big_office, tmp_big_sales, LHsIbig_Nname, v_sMsg);
         }
         if (rc == M_CM_OK) strcpy(LHsIbig_Nname,trimx(LHsIbig_Nname));
      }

      #ifdef PRINTF_FLAG
      printf("ibig_sales[%s]\n",tmp_big_sales);
      printf("LHsIbig_Nname[%s]\n",LHsIbig_Nname);
      printf("BEFORE INSERT \n");
      #endif

      tot_mpay = tot_prem - sum_mdiscount;

      #ifdef PRINTF_FLAG
      printf("sum_mdiscount[%ld]\n",sum_mdiscount);
      printf("main_discount[%f]\n",main_discount);
      #endif

      /* Start Working clm */
      remark3[0] = '\0';
      if (strncmp(fcard_class,"2",1) == 0)
      {
         sprintf(stmt, " EXECUTE procedure %s:sp_ply_service(?) ; ",sclmdb);

         #ifdef PRINTF_FLAG
         printf("clm stmt[%s]\n",stmt);
         #endif

         $PREPARE sclm FROM $stmt;
         $EXECUTE sclm USING $last_ply;

         itp = 0;

         #ifdef PRINTF_FLAG
         printf("begin open clm_cur\n");
         #endif

         $OPEN clm_cur USING $last_ply;
         for(;;)
         {
            $FETCH clm_cur INTO $iseq_tmp,$dclaim_tmp,$dprocess_tmp,$drescue_tmp,$qday_tmp;
            if (SQLCODE == SQLNOTFOUND) break;

            if (itp == 0)
            {
                strcpy(remark3,"�߮פ��   �{���B�z   �D���ϴ�   �N�B���Ѽ�   ");
            }
            itp++;

            strcpy(dclaim_tmp,cm_from_infdate_100(dclaim_tmp));
            strcpy(dclaim_tmp,trim(dclaim_tmp));
            strcpy(dclaim_tmp,splace(dclaim_tmp,9,1));
            strcat(remark3,dclaim_tmp);
            strcat(remark3,"   ");

            strcpy(dprocess_tmp,cm_from_infdate_100(dprocess_tmp));
            strcpy(dprocess_tmp,trim(dprocess_tmp));
            strcpy(dprocess_tmp,splace(dprocess_tmp,9,1));
            strcat(remark3,dprocess_tmp);
            strcat(remark3,"   ");

            strcpy(drescue_tmp,cm_from_infdate_100(drescue_tmp));
            strcpy(drescue_tmp,trim(drescue_tmp));
            strcpy(drescue_tmp,splace(drescue_tmp,9,1));
            strcat(remark3,drescue_tmp);
            strcat(remark3,"   ");

            strcpy(qday_tmp,trim(qday_tmp));
            strcpy(qday_tmp,splace(qday_tmp,10,2));
            strcat(remark3,qday_tmp);
            strcat(remark3,"   ");
         }
         $CLOSE clm_cur;
      }

      /* ���p���O�渹�Y���P����~��, ���[����r������remark5 add by sylvia 105.07.18 (1050517003_C1) */
      /* (1110718002_SC3)�אּ���׬O�_�P����A35�B51���إu�n���p�O�渹���O�� �j�󵥩� �ӳ檺����~��A�B���p�O�渹�D�L�īO��A�N�[������*/
      /* (1110718002_SC3)                    �D35�B51���إu�n���p�O�渹���O�� �j�� �ӳ檺����~��A�B���p�O�渹�D�L�īO��A�N�[������*/
      if (strlen(trim(irelative_ply)) >= 13)
      {
          memset(relply_end,0,sizeof(relply_end)); /* ���p�O������ */

          sum_dmg_cover = 0;
          strcpy(sFullDBName, get_car_full_dbname(irelative_ply));

          if(strcmp(car_typei,"35") == 0 || strcmp(car_typei,"51") == 0)/*�q�ʦۦ樮(35�B51����)*/
          {
              sprintf(buf2,
                      "SELECT dply_end, \
                              nvl((select sum(mdamage_cover) from %s:ply_ins_type b where b.ipolicy = a.ipolicy),0) \
                         FROM %s:ply_relation a, %s:policy b \
                        WHERE a.ipolicy = b.ipolicy \
                          AND a.ipolicy = '%s' and b.iassured = '%s' and a.dply_end >= %d ",
                      sFullDBName, sFullDBName, sFullDBName, irelative_ply, license, lDplyEndEnd);
          }
          else
          {
              sprintf(buf2,
                      "SELECT dply_end, \
                              nvl((select sum(mdamage_cover) from %s:ply_ins_type b where b.ipolicy = a.ipolicy),0) \
                         FROM %s:ply_relation a, %s:policy b \
                        WHERE a.ipolicy = b.ipolicy \
                          AND a.ipolicy = '%s' and b.iassured = '%s' and a.dply_end > %d ",
                      sFullDBName, sFullDBName, sFullDBName, irelative_ply, license, lDplyEndEnd);
          }

          $PREPARE pre_relend FROM $buf2;
          $EXECUTE pre_relend INTO $relply_end, $sum_dmg_cover;

          if ((SQLCODE==SQLNOTFOUND) || (sum_dmg_cover == 0))
              strcpy(remark5," ");
          else
          {
              strcpy(relply_end,cm_from_infdate_100(relply_end));
              if (strcmp(fcard_class,"1") == 0)
                  sprintf(remark5, "���������N�I����鬰 %s ",relply_end);
              else
                  sprintf(remark5, "�������j���I����鬰 %s ",relply_end);
          }
      }

      /* KA03�Y�]�O���B�O��ID����]�Q������j�̡A���H��O�n�O�� add by 061476 109.01.18 (1080730006_SC1) */
      /* KA02�ഫ��KA03�A�B��������O�j�� mark by 061476 109.04.08 (1090305002_SC1) */
      /*if ((strncmp(fcard_class,"1",1) == 0) && (strncmp(iroute,"KA03",4) == 0))
      {
      	t_count = 0;
      	* �t�X�O�o�q���X�s,���q���N����H��1�X��� modify by sylvia 106.01.25 (1060111005_C3) *
      	$EXECUTE prep_chkChange INTO $t_count USING  $irelative_ply ,$license, $chk_dbirth, $bzfrom1 ;
      	if (t_count==0){
      		* ������j *
      		$INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,' ','KA03���i��O�j���I','1','E56');
      	}
      }*/


      /* 101.08.07�ק�: �H����O���Ƭ��D�A�Y�ť�(�L��)�A���cu_customer��� */
      /* 107.05.16 ��������ȪA��P���ɸ�� */
      /***  �B�z�O��]���q�ܡB����Bemail���  ***/

      /*strcpy(tphone_con_cus," ");    strcpy(imovephone_cus," ");     strcpy(iemail_cus," ");
       $EXECUTE cus_id INTO $tphone_con_cus, $imovephone_cus, $iemail_cus USING $license; */
      #ifdef PRINTF_FLAG
         printf(" 1------- tphone_con     = [%s]\n " , tphone_con);
         printf(" 1------- imovephone     = [%s]\n " , imovephone);
         printf(" 1------- iemail         = [%s]\n " , iemail);
      #endif

      if (strlen(trim(tphone_con))==0) strcpy(tphone_con," ");

      if (strlen(trim(imovephone))==0)
      {
        /* �t�X�i�s�W�t�αH�o�wú�O�q��²�T�ݨD�j,�Y�̷s�O��L������X,�����L���,
           ���A�Hcu_customer��ƨ��N */
        /* strcpy(imovephone,imovephone_cus); */
        strcpy(imovephone," ");
      }
      strcpy(tphone_con,trimx(tphone_con));
      strcpy(imovephone,trimx(imovephone));

      strcpy(iemail,trimx(iemail));
      if ((strchr(iemail,'@')==NULL)||(strlen(iemail)<5)){
        strcpy(iemail," "); /* ���A�d�ȪA��P�� */

    	/*   strcpy(iemail_cus,trimx(iemail_cus));
         if ((strchr(iemail_cus,'@')==NULL)||(strlen(iemail_cus)<5)){
        	   strcpy(iemail," ");
         }else{
       	   strcpy(iemail,iemail_cus);
         }*/
      }
      if(strlen(iemail)>2){
         if ((int)(iemail[0])>=128) strcpy(iemail," "); /* �P�_�Ĥ@�Ӧr�O�_������, ���媺 "�@" ��n�|�Qstrchr�~�P�t��"@"�Ÿ� */
      }

      #ifdef PRINTF_FLAG
         printf(" 1------- tphone_con     = [%s]\n " , tphone_con);
         printf(" 1------- imovephone     = [%s]\n " , imovephone);
         printf(" 1------- iemail         = [%s]\n " , iemail);
         printf(" nchi_full[%s]\n",  nchi_full);
      #endif


      /** �ѩ�̷s�żƥѫO�O�d�ߤ��ߨ��o,�P�ɥ�w�������T��ƤU��, �e�@�~�j�ߦ��Ƥ��A��ܡA950612 **/
      /** �Y�ϫO�O�d�ߤ��ߵL�k���o�̷s�żơA�Ѥ��q��k�ۦ�p��A�礣��ܡA950612 **/
      strcpy(lia_ac_cntc," ");
      strcpy(assureda,trimx(assureda));

      /* 990601*/
      if (ins1589_chg_flag == 1 || ins1589_chg_flag == 2 || ins1589_chg_flag == 3){
    	   psex_age_damage = psex_age_damage_ori;
      }

      /*-----102.03 ----------------------------------------------------------------------*/
      /* �i�t�μf�֡j�� car102�ګO���ˮ֡B39�I�ح��O�զX�~�A��l�Ҧb check_policy()��
        �Ecar102�ګO���ˮ֬O�b�J�p������A�Τ@�ˮ�
        �E39�I�ح��O�զX�ȶ��ˮ֦� 102.09�������O��(�j�M "3839check")
        *** barcode��ݰ��~�A�����B���P�_�O�_��barcode�A��J�p������A�Τ@�P�_(car102�ګO���ˮ֫�)
         �s�W����14,21,08, ���ױj��Υ��N(�t�������p���O��), �@�߶��H�u�֫O(�֫O���A=180) add by sylvia 104.01.26*/

      #ifdef PRINTF_FLAG
          printf("trace last_ply[%s]\n ",last_ply);
          printf("trace brandi[%s]\n "  ,brandi);
          printf("trace car_typei[%s]\n ",car_typei);
          printf("trace tagnum[%s]\n ",tagnum);
          printf("trace iofficer[%s]\n ",iofficer);
          printf("trace iroute[%s]\n ",iroute);
          printf("trace license[%s]\n ",license);
          printf("trace assuredf[%s]\n ",assuredf);
          printf("trace issue[%s]\n ",issue);
          printf("trace tmp_dply_begin_pre[%s]\n ",tmp_dply_begin_pre);
          printf("trace tmp_frate2[%s]\n ",tmp_frate2);
          printf("trace ins1589_chg_flag[%d]\n ",ins1589_chg_flag);
      #endif

     /* �������p���O�欰14,21,08����(Cnt142108 > 0),�֫O���A�@����180  */
     if (Cnt142108 == 0)
     {
          if (*fcard_class == '2'){
          	/* 102.12.25 �M�ץ�@�߼f�ֳq�L�A�B���Lú�ڳ� */
          	if (IsPlyB=='Y'){
          		fuw_status_ori = 505;
          		fuw_status_sug = 505;
          	}

          	/* �]���֫O���A40 �n�u��130, �ҥH���O�d130���A...
          	   ��check_policy()������, �Y�֫O���A<>40, �@�ߦ^��130 add by sylvia 104.07.15  */
          	/* �W�[�֫O���A131���130��z modify by 061476 (1080410001_SC1) */
          	/* ����130�B131�֫O���A mark by 061476 (1100119001_SC3) */
          	tmp_status_ori = tmp_status_sug = 0;

          	if ((fuw_status_ori == -1)||(fuw_status_sug == -1)){ /* �u�n���@�դ��b���f���A�A�N�n�i�J check_policy() */
          		rtncode= check_policy( INS_ptr,last_ply,brandi,car_typei,tagnum,iofficer,iroute,license,assuredf,issue,tmp_dply_begin_pre,tmp_frate2,&ins1589_chg_flag,&fuw_status_ori,&fuw_status_sug);
          		if  (rtncode != M_CM_OK){
          			sprintf(ctmp_message,"�i�t�μf�֡j���~(rtncode=%ld)check_policy()",rtncode);
          			$INSERT INTO duplic1 VALUES ($last_ply,$car_typei,$tagnum,ctmp_message,'1','E32',$iofficer);
          		}
          	}

          	/*102.09.06 : chk_flag==1 => 03 04 19 21 22���ءA�h�~��05��,2p�B5p���Lú�ڳ� (barcode��bca3xxlib.ec WriteToEstimate()���B�z, barcode��chk_flag�@�w��0) */
          	if (chk_flag==1){
          		if (fuw_status_ori==500) fuw_status_ori = 505; /* 505�G���ܳq�L�t�μf��,�����Lú�ڳ�(���٬O�n��(�g�J)�@�γ�����) */
          		if (fuw_status_sug==500) fuw_status_sug = 505;
          	}

          	/* �쥻�b�e������D���ڡA���]check_policy���n�ˮ�provision�A�G���즹�Hupdate�覡�B��*/
          	if (f_provision_D == 1) {
          		/*$Update ply_ins_type_302 set provision = replace(trim(provision)||';','D;','') Where ipolicy = $last_ply;*/
          		$Update ply_ins_type_302
          		    set provision = CAST(regex_replace(replace(trim(provision)||';','D;'),';+$','')AS char(20))
          		  where ipolicy = $last_ply;
          	}
          	/* J���ڤ��D���ڿ�z  add by sylvia 105.09.23 (1050801002_C4) */
          	if (f_provision_J == 1) {
          		/*$Update ply_ins_type_302 set provision = replace(trim(provision)||';','J;','') Where ipolicy = $last_ply;*/
          		$Update ply_ins_type_302
          		    set provision = CAST(regex_replace(replace(trim(provision)||';','J;'),';+$','')AS char(20))
          		  where ipolicy = $last_ply;
          	}

          	/* ��T���ڡA���d�LT���ڥ[��O�T�שΤ��ųW�w,�gcheck_policy�ˮ֫�Hupdate�覡,�M��T����*/
          	if (((fuw_status_ori == 140) || (fuw_status_sug == 140)) && (f_provision_T == 0)) {
          		/*$Update ply_ins_type_302 set provision = replace(trim(provision)||';','T;','') Where ipolicy = $last_ply;*/
          		$Update ply_ins_type_302
          		    set provision = CAST(regex_replace(replace(trim(provision)||';','T;'),';+$','')AS char(20))
          		  where ipolicy = $last_ply;
          	}

          	/*if (f_provision_E == 1) {
          		$Update ply_ins_type_302 set provision = ' ' Where ipolicy = $last_ply and provision='E';
          	}*/
          }else{
          	/*  ���O�X��A�j���I������f�ֵ��G�@���� 500(�f�ֳq�L) */
          	fuw_status_ori = 500 ;
          	fuw_status_sug = 500 ;
          }
     }
     else
     {
     	/* �������p���O�欰14,21,08����,�@����180  */
     	fuw_status_ori = 180 ;
     	fuw_status_sug = 180 ;
     }

     /* ��s�������[�O�����[������� add by sylvia 104.11.27 */
     /* �W�[�P�P���ŦX�������[�O�Y�ƪ�, �]�n����S���� (�t�X�e�u152�I�إ[�p���D) add by sylvia 106.06.15 (1060406010_C3) */
      /* if ((f_provision_S == 0) && (fhi_price == 'Y'))
            $Update ply_ins_type_302 set provision = trim(provision)||'S'  Where ipolicy = $last_ply and pcar_price > 1.0;
      else if ((f_provision_S == 1) && (fhi_price == 'N'))
            $Update ply_ins_type_302 set provision = replace(provision,'S','') Where ipolicy = $last_ply and pcar_price = 1.0; */

      if (fhi_price == 'Y')
      {
      	/* �������M��S,�A�Ⱚ�����[�O�Y��>1���ɤWS, �H�קK���ƥ[S������152�I�صL�k����S�����p */
        /*$Update ply_ins_type_302 set provision = replace(trim(provision)||';','S;','') Where ipolicy = $last_ply;*/
        $Update ply_ins_type_302
            set provision = CAST(regex_replace(replace(trim(provision)||';','S;'),';+$','')AS char(20))
          where ipolicy = $last_ply;
        $Update ply_ins_type_302 set provision = 'S' Where ipolicy = $last_ply and pcar_price > 1.0;

      }
      else if ((f_provision_S == 1) && (fhi_price == 'N'))
        $Update ply_ins_type_302
            set provision = CAST(regex_replace(replace(trim(provision)||';','S;'),';+$','')AS char(20))
          where ipolicy = $last_ply and pcar_price = 1.0;
        /*$Update ply_ins_type_302 set provision = replace(trim(provision)||';','S;','') Where ipolicy = $last_ply and pcar_price = 1.0;*/

      /* 98�I�ت��[E���ڻݲM��E���� add by 061476 107.02.12 (1060914009_C3)*/
      /* 98�I���ഫ09+K modify by 061476 108.04.22 (1080408008_SC3)  */
      /* 198�I�ؤ��09+k modify by 061476 (1091103004_SC1) */
      if ((f_provision_E == 1) && (f_198_exist == 'Y'))
      {
      	    /*$Update ply_ins_type_302 set provision = replace(trim(provision)||';','E;','') Where ipolicy = $last_ply AND iins_type = '198';*/
      	    $Update ply_ins_type_302
      	        set provision = CAST(regex_replace(replace(trim(provision)||';','E;'),';+$','')AS char(20))
      	      where ipolicy = $last_ply AND iins_type = '198';
      }
      /* K���ڰ���A�M��K���� add by 061476 (1091103004_SC1) */
      /* �@�ֳB�z09+K��10�I�ت�P���� */
      if (f_provision_K == 1)
      {
      	    /*$Update ply_ins_type_302 set provision = replace(replace(trim(provision)||';','K;',''),'P;','')
      	      Where ipolicy = $last_ply and iins_type in ('198','10');*/
      	    $Update ply_ins_type_302
      	        set provision = CAST(regex_replace(replace(replace(trim(provision)||';','K;',''),'P;',''),';+$','')AS char(20))
      	      where ipolicy = $last_ply and iins_type in ('198','10');
      }

      /* ��O���p��H���ڶO�v�ݲM��H����  add by 061476 108.04.17 (1080403003_SC1) */
      if (f_provision_H == 1)
      {
      	  /*$Update ply_ins_type_302 set provision = replace(trim(provision)||';','H;','') Where ipolicy = $last_ply;*/

      	  /* ���A�M��H���[���� mark by 071004 (1110308005_SC3_�w��q�ӱN�ӻȦ�ݨD�s�W�ӫ~���ˮֳW�h)*/
      	  /*
      	  $Update ply_ins_type_302
      	      set provision = CAST(regex_replace(replace(trim(provision)||';','H;'),';+$','')AS char(20))
      	    where ipolicy = $last_ply;*/
      }

      /* Z���ڰ����ഫ��P���ڡA�M��Z����  add by 061476 108.12.25 (1081105005_SC3) */
      if (f_provision_ZZ == 1)
      {
      	  /*$Update ply_ins_type_302 set provision = replace(trim(provision)||';','Z;','') Where ipolicy = $last_ply;*/
      	  $Update ply_ins_type_302
      	      set provision = CAST(regex_replace(replace(trim(provision)||';','Z;'),';+$','')AS char(20))
      	    where ipolicy = $last_ply;
      }

      #ifdef PRINTF_FLAG
        printf("trace last_ply[%s]fuw_status_ori=[%d]fuw_status_sug=[%d]\n ",last_ply,fuw_status_ori,fuw_status_sug);
      	printf("$last_card        =[%s ]\n",last_card        );
      	printf("$fcard_class      =[%s ]\n",fcard_class      );
      	printf("$irelative_ply    =[%s ]\n",irelative_ply    );
      	printf("$comp_date_begin  =[%s ]\n",comp_date_begin  );
      	printf("$comp_date_end    =[%s ]\n",comp_date_end    );
      	printf("$premium1_ori     =[%ld]\n",premium1_ori     );
      	printf("$last_policy_2    =[%s ]\n",last_policy_2    );
      	printf("$last_policy_3    =[%s ]\n",last_policy_3    );
      	printf("$qply_period      =[%d ]\n",qply_period      );
      	printf("$dply_begin       =[%ld]\n",dply_begin       );
      	printf("$dply_end         =[%ld]\n",dply_end         );
      	printf("$assuredn         =[%s ]\n",assuredn         );
      	printf("$license          =[%s ]\n",license          );
      	printf("$birth            =[%s ]\n",birth            );
      	printf("$sex              =[%s ]\n",sex              );
      	printf("$marriage         =[%s ]\n",marriage         );
      	printf("$user             =[%s ]\n",user             );
      	printf("$benefn           =[%s ]\n",benefn           );
      	printf("$assureda         =[%s ]\n",assureda         );
      	printf("$tel              =[%s ]\n",tel              );
      	printf("$ply_area         =[%s ]\n",ply_area         );
      	printf("$issue_ym         =[%s ]\n",issue_ym         );
      	printf("$pro_year         =[%s ]\n",pro_year         );
      	printf("$brandi           =[%s ]\n",brandi           );
      	printf("$brandn           =[%s ]\n",brandn           );
      	printf("$car_typei        =[%s ]\n",car_typei        );
      	printf("$icar_type_ori    =[%s ]\n",icar_type_ori    );
      	printf("$ichange_note     =[%s ]\n",ichange_note     );
      	printf("$car_typen        =[%s ]\n",car_typen        );
      	printf("$cylinder         =[%f ]\n",cylinder         );
      	printf("$engine           =[%s ]\n",engine           );
      	printf("$body             =[%s ]\n",body             );
      	printf("$tagnum           =[%s ]\n",tagnum           );
      	printf("$scar_price       =[%s ]\n",scar_price       );
      	printf("$dmg_align        =[%d ]\n",dmg_align        );
      	printf("$brg_align        =[%d ]\n",brg_align        );
      	printf("$lia_align        =[%d ]\n",lia_align        );
      	printf("$qpt              =[%f ]\n",qpt              );
      	printf("$fpt              =[%s ]\n",fpt              );
      	printf("$idmg_rate        =[%s ]\n",idmg_rate        );
      	printf("$dmg_factor       =[%f ]\n",dmg_factor       );
      	printf("$ibrg_rate        =[%s ]\n",ibrg_rate        );
      	printf("$brg_factor       =[%f ]\n",brg_factor       );
      	printf("$psex_age         =[%f ]\n",psex_age         );
      	printf("$psex_age1        =[%f ]\n",psex_age1        );
      	printf("$psex_age2        =[%f ]\n",psex_age2        );
      	printf("$psex_age_c       =[%f ]\n",psex_age_c        );
      	printf("$psex_age_damage  =[%f ]\n",psex_age_damage  );
      	printf("$psex_age_damage_ori  =[%f ]\n",psex_age_damage_ori  );
      	printf("$lia_ac_cnt[0]    =[%s ]\n",lia_ac_cnt[0]    );
      	printf("$lia_ac_cnt[1]    =[%s ]\n",lia_ac_cnt[1]    );
      	printf("$lia_ac_cnt[2]    =[%s ]\n",lia_ac_cnt[2]    );
      	printf("$lia_ac_cntc      =[%s ]\n",lia_ac_cntc      );
      	printf("$dmg_ac_cnt[0]    =[%s ]\n",dmg_ac_cnt[0]    );
      	printf("$dmg_ac_cnt[1]    =[%s ]\n",dmg_ac_cnt[1]    );
      	printf("$dmg_ac_cnt[2]    =[%s ]\n",dmg_ac_cnt[2]    );
      	printf("$splia_acc        =[%s ]\n",splia_acc        );
      	printf("$spdmg_acc        =[%s ]\n",spdmg_acc        );
      	printf("$plia_acc_c       =[%s ]\n",plia_acc_c       );
      	printf("$fcar_class       =[%s ]\n",fcar_class       );
      	printf("$dedr_begin       =[%ld ]\n",dedr_begin      );
      	printf("$iofficer         =[%s ]\n",iofficer         );
      	printf("$nname            =[%s ]\n",nname            );
      	printf("$tmp_big_office   =[%s ]\n",tmp_big_office   );
      	printf("$tmp_big_sales    =[%s ]\n",tmp_big_sales    );
      	printf("$ibig_comp        =[%s ]\n",ibig_comp        );
      	printf("$ibig_branch      =[%s ]\n",ibig_branch      );
      	printf("$mbusiness        =[%f ]\n",mbusiness        );
      	printf("$mbusiness2        =[%f ]\n",mbusiness2        );
      	printf("$comp_class       =[%s ]\n",comp_class       );
      	printf("$comp_class_last  =[%s ]\n",comp_class_last  );
      	printf("$ileader          =[%s ]\n",ileader          );
      	printf("$aassured_zip     =[%s ]\n",aassured_zip     );
      	printf("$irel_card        =[%s ]\n",irel_card        );
      	printf("$iquery_num       =[%s ]\n",iquery_num        );
      	printf("$iquery_num_damage=[%s ]\n",iquery_num_damage );
      	printf("$iquota           =[%s ]\n",iquota           );
      	printf("$nchi_full        =[%s ]\n",nchi_full        );
      	printf("$fnation          =[%s ]\n",fnation          );
      	printf("$v_prem           =[%ld]\n",v_prem           );
      	printf("$v_ori_prem       =[%ld]\n",v_ori_prem       );
      	printf("$tot_prem         =[%ld]\n",tot_prem         );
      	printf("$ch_ins_grp[0]    =[%s ]\n",ch_ins_grp[0]    );
      	printf("$ch_ins_grp[1]    =[%s ]\n",ch_ins_grp[1]    );
      	printf("$ch_ins_grp[2]    =[%s ]\n",ch_ins_grp[2]    );
      	printf("$pre_ply1_bgn     =[%ld]\n",pre_ply1_bgn     );
      	printf("$pre_ply1_end     =[%ld]\n",pre_ply1_end     );
      	printf("$pre_prem1        =[%s ]\n",pre_prem1        );
      	printf("$pre_prem2        =[%s ]\n",pre_prem2        );
      	printf("$pre_ply2_bgn     =[%ld]\n",pre_ply2_bgn    );
      	printf("$pre_ply2_end     =[%ld]\n",pre_ply2_end     );
      	printf("$sp_sex_age       =[%s ]\n",sp_sex_age       );
      	printf("$sp_sex_age_dmg   =[%s ]\n",sp_sex_age_dmg   );
      	printf("$sp_lia_acc       =[%s ]\n",sp_lia_acc       );
      	printf("$sp_dmg_acc       =[%s ]\n",sp_dmg_acc       );
      	printf("$note1            =[%s ]\n",note1            );
      	printf("$linnum           =[%d ]\n",linnum           );
      	printf("$nbrand           =[%s ]\n",nbrand           );
      	printf("$remark1          =[%s ]\n",remark1          );
      	printf("$remark2          =[%s ]\n",remark2          );
      	printf("$remark6          =[%s ]\n",remark6          );
      	printf("$remark7          =[%s ]\n",remark7          );
      	printf("$LHsIbig_Nname    =[%s ]\n",LHsIbig_Nname    );
      	printf("$sum_mdiscount    =[%ld]\n",sum_mdiscount    );
      	printf("$tot_mpay         =[%ld]\n",tot_mpay         );
      	printf("$pre_ch_ins_grp[0]=[%s ]\n",pre_ch_ins_grp[0]);
      	printf("$pre_ch_ins_grp[1]=[%s ]\n",pre_ch_ins_grp[1]);
      	printf("$pre_ch_ins_grp[2]=[%s ]\n",pre_ch_ins_grp[2]);
      	printf("$icorps           =[%s ]\n",icorps           );
      	printf("$ncorps           =[%s ]\n",ncorps           );
      	printf("$main_discount    =[%f ]\n",main_discount    );
      	printf("$fcomp_24         =[%s ]\n",fcomp_24         );
      	printf("$remark3          =[%s ]\n",remark3          );
      	printf("$assuredf         =[%s ]\n",assuredf         );
      	printf("$tphone_con       =[%s ]\n",tphone_con       );
      	printf("$imovephone       =[%s ]\n",imovephone       );
      	printf("$iemail           =[%s ]\n",iemail           );
      	printf("$remark4          =[%s ]\n",remark4          );
      	printf("$remark5          =[%s ]\n",remark5          );
      	printf("$nproject         =[%s ]\n",nproject         );
      	printf("$lia_class        =[%s ]\n",lia_class        );
      	printf("$inequipment      =[%s ]\n",inequipment      );
      	printf("$intopt;          =[%d ]\n",intopt           );
      	printf("$napplicant;      =[%s ]\n",napplicant       );
      	printf("$funknown_dmg_ori;      =[%s]\n",funknown_dmg_ori       );
      	printf("$funknown_dmg_sug;      =[%s]\n",funknown_dmg_sug       );
      	printf("$spunknown_acc;      =[%s]\n",spunknown_acc       );
      	printf("$sp_unknown_acc;      =[%s]\n",sp_unknown_acc       );
      	printf("$qunknown_acc_sum_renew_ori;      =[%d]\n",qunknown_acc_sum_renew_ori       );
      	printf("$spunknown_acc_sug;      =[%s]\n",spunknown_acc_sug       );
      	printf("$qunknown_acc_sum_renew_sug;      =[%d]\n",qunknown_acc_sum_renew_sug       );
      	printf("$iquery_num_unknown;      =[%s]\n",iquery_num_unknown       );
      	printf("$iquery_num_unknown_sug;      =[%s]\n",iquery_num_unknown_sug       );
      #endif

      if (strlen(birth)>8){
    	   if(birth[0]=='0'){ /* Ex. 063/01/20*/
    	      strcpy(tmp_sdate,substring(birth,2,8));
    	      strcpy(birth,trim(tmp_sdate));
         }else{
            /* 100�~,ibirth�����ƤF */
            birth[0] = ' ';  birth[1] = '\0';
         }
      }

      /*102.08.26 ,for �s�A����O����P�_ ==> �w��h�~�ӫO�A�������I�A��O�J�p�אּ��ĳ�s�A�������I  */
      issue_ym[0] = ' ';  issue_ym[1] = '\0';
      if (ins1589_chg_flag == 2 || ins1589_chg_flag == 3 || ins1589_chg_flag == 5 ||
          ins1589_chg_flag == 6 || ins1589_chg_flag == 7 || ins1589_chg_flag == 8 ) {
         issue_ym[0] = '1';  /* ���Ѳ��s�ɮ׮ɧP�_�O�_�� 05=>105�� (issue_ym�w�L�ϥ�,�G�ɥ�) */
      }

      /* �]�ӫ~�����ഫ�I�ت����O */
      if (insA_chg_flag > 0)    issue_ym[0] = '1';      /* �����I(A���ӫ~)���� */
      if (ins7780_chg_flag > 0)    issue_ym[0] = '2';   /* ���d�I(�ۥΨ���X�ӫ~)���� */
      if (f_del_24 == 'Y')    	issue_ym[0] = '3';      /* �s�v�I���� */

      strcpy(freason_reject," "); /* 102.01.09 */
      strcpy(remark_reject ," "); /* 102.01.09 */
      if (strlen(iroute_prop)==0) strcpy(iroute_prop ," ");

      if (CntPrmt>0)
      {
         /* �M�ץ�N�g��,���I�n��Ūca_promote_officer */
         $select unique ibig_office into $tmp_big_office
            from ca_promote_officer
           where iofficer_ori = $iofficer;
      }
      if( intopt == 25 ){
         /* [del intopt == 25]102.03 �w��5/1�ᤧ 5,6��|���X�椧��O���ơA�ɻ����O�X���ơA�H�Q���H�o��O�� 102.07���i�R��*/
         /* ��ӳ����J�p�覡�ɸ�� */
         $Update policy_302
             set fuw_status_ori = $fuw_status_ori,fuw_status_sug = $fuw_status_sug,
                 mcomp_prem_sug = $premium1,frenew_type = $frenew_type ,dupdate=current,iupdate=$userid
           WHERE ipolicy = $last_ply;
      }else{

            /* �󥿭n�O�H=�Q�O�I�H���  add by sylvia 104.06.16 (1040528003_C1) */
            if (ichg_applicant > 0)
            {
                strcpy(iapplicant,license);                 /* �n�O�HID             */
                if (strlen(aassured_zip) < 2)
                    strcpy(apayment_zip," ");               /* �n�O�H�l���ϸ�       */
                else
                    strcpy(apayment_zip,aassured_zip);      /* �n�O�H�l���ϸ�       */

                if (strlen(assureda) < 2)
                    strcpy(apayment," ");                   /* �n�O�H�a�}           */
                else
                    strcpy(apayment,assureda);              /* �n�O�H�a�}           */

                strcpy(fapplicant,assuredf);                /* �n�O�H�ʽ�           */

                if ((sex[0] == 1)||(sex[0] == 2))
                    strcpy(fsex_appl,sex);                  /* �n�O�H�ʧO           */
                else
                    strcpy(fsex_appl," ");                  /* �n�O�H�ʧO           */

                dbirth_appl = dbirth;                       /* �n�O�H�ͤ�           */

                if (strlen(tel) < 2)
                    strcpy(itel_appl," ");                  /* �n�O�H�s���q��       */
                else
                    strcpy(itel_appl,tel);                  /* �n�O�H�s���q��       */

                strcpy(ndeputy_appl,ndeputy_assured);       /* �n�O�H���N���H       */
                strcpy(nrelation_appl,"���H");              /* �n�O�H�P�Q�O�I�H���Y */
            }

           /* ���I��O�J�p�������O97�䲼ú�� modify by sylvia 105.01.15 (1050114002_C1) */
           strcpy(inequipment,equip_delete(inequipment,"97"));

           /* ���I��O�J�p�������O98ñ�b�榬�^ modify by sylvia 105.03.14 (1050311001_C1) */
           strcpy(inequipment,equip_delete(inequipment,"98"));

           /* ���I��O�J�p�������O110�F�d���� add by 061476 108.09.16 (1080807010_SC1) */
           strcpy(inequipment,equip_delete(inequipment,"110"));

           /* ���I��O�J�p�������O111���������I�M�סB112�A�������I�M��
                      modify by 061476 107.09.18 (1070829007_SC3�B1070830010_SC3) */
           strcpy(inequipment,equip_delete(inequipment,"111"));
           strcpy(inequipment,equip_delete(inequipment,"112"));

           /* �q����L�ᤣ��O�J�p add by sylvia 105.01.27 (1041001006_C1) */
           if (strlen(dtransfer) > 0)
           {
                /* �]�w�bcar_code.kind = 'RD'���q�� (cnt_RD > 0) ������O�J�p
                   ���]�w�b reject_policy.fins_grp = A ���O�� (cnt_137 > 0) �O�i�H�J�p�� */
                /* ���~�ۼХ�L��礣�J�p add by 061476 110.01.26 (1100118005_SC3) */
                /* �ư��O�o�q����40(���~�ۼФ��ư�) add by 061476 (1120117003_SC1) */
                /* KBTA���ư� => �L��󤣷J�p (1140108010_C02) */
                cnt_137 = cnt_RD = cnt_C = 0;
                $select count(*) into $cnt_RD from car_code where kind = 'RD' and detail = $iroute12;
                $select count(*) into $cnt_137 from reject_policy where fins_grp = 'A' and ipolicy = $last_ply and dexpire is null;
                $select count(*) into $cnt_C from officer where fenterprise = 'Y' and iofficer = $iofficer;
                if (((cnt_RD > 0) && (cnt_137 == 0) && ((strncmp(bzfrom,"40",2) != 0)||(strncmp(iroute,"KBTA",4) == 0))) || (cnt_C > 0))
                {
                    $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,$iofficer,'�L���,��O�אּ���u�ӤH�~��','1','E44',$iofficer);
                }
           }

           /* �����I��a���s�P�_(RBA�t��) add by sylvia 105.02.26 (1050105008_C4) */
           /* �\���q��,  �אּ�e�ʽ�1,2 �B�O�ťժ��X�۰ʥN9, �Y�D�ť�, �P�̷s�O��f modify by sylvia 105.03.08 */
           if (chk518 > 0)
           {
                $select case when b.iassured_cntry = ' ' and b.fassured in ('1','2') then '9'
                             when b.iassured_cntry = '1' then
                                case when (select count(*) from cm_risk_member where itype = '3'
                                              and dcreate <= a.dpolicy
                                              and (dexpire >= a.dpolicy and dexpire <= today)) > 0
                                     then ' ' else b.iassured_cntry end
                             when b.iassured_cntry = '8' then
                                case when (select count(*) from cm_risk_member where itype = '3'
                                              and dcreate > a.dpolicy ) > 0
                                     then ' ' else b.iassured_cntry end
                        else  b.iassured_cntry  end,
                        case when b.iapplicant_cntry = ' ' and b.fapplicant in ('1','2') then '9'
                             when b.iapplicant_cntry = '1' then
                                  case when (select count(*) from cm_risk_member where itype = '3'
                                                and dcreate <= a.dpolicy
                                                and (dexpire >= a.dpolicy and dexpire <= today)) > 0
                                       then ' ' else b.iapplicant_cntry end
                             when b.iapplicant_cntry = '8' then
                                  case when (select count(*) from cm_risk_member where itype = '3'
                                                and dcreate > a.dpolicy ) > 0
                                       then ' ' else b.iapplicant_cntry end
                        else  b.iapplicant_cntry  end
                into $iassured_cntry, $iapplicant_cntry
                from ply_relation_last a, policy_last b
               where a.ipolicy = b.ipolicy
                 and a.ipolicy = $last_ply;
           }

           if (strcmp(fcard_class,"1") == 0)
           {
                strcpy(funknown_dmg_ori," ");
                strcpy(funknown_dmg_sug," ");
           }

           /* �w��q�l���ڧP�_�w�]�ȡA�e��O�� < 09/01/2021�@�ߵ��q�l���ڡA�_�h��ӫe����O add by 061476(1100701001_SC1) */
           /* �q�ʦۦ樮�q�l���ڹw�]�ȡA�e��O�� < 04/01/2022�@�ߵ��q�l���ڡA�_�h��ӫe����O add by 071004 */
           /* �����q�l���� (1111005011_SC3) */
           strcpy(feterms,"0");  /* �����A�@�ߵ�0 */

           /* �H�j�骺�覡�@�ַs�W��policy_302f (��O�q����M��) add by sylvia 105.01.18 (1041001006_C1)  */
           for(fitable = 0; fitable < 2; fitable++)
           {
               if (fitable == 0) strcpy(ntable,"policy_302");
               else strcpy(ntable,"policy_302f");

               if (intopt == 55 )
               {
                    fitable = 2;  /* ���ظg�P���g�Jpolicy_302f */

                    $select nequipment into $inequipment
                       from estimate_fb
                      where ipolicy = $last_ply;
               }

               printf("---12221--fitable=[%d]ntable=[%s]\n",fitable,ntable);
               sprintf(buf1," INSERT INTO %s:%s %s %s",
                              FDBNAME,ntable,
    		             "(ipolicy, ipolicy_1, icard, fcard_class, irelative_ply, dply_bgn_comp, dply_end_comp, comp_prem, last_policy_2, last_policy_3, qply_period, dply_begin, dply_end, \
    		               nassured, ilicense, ibirth, fsex, fmarriage, nuser, nbenef, aassured, itel, iply_area, iissue_ym, ipro_year, ibrand, nbrand_abbr, icar_type, ichange_note, ncar_type, qcylinder,\
    		               iengine, ibody, itag, mcar_price, pdmg_align, pbrg_align, plia_align, qpt, fpt, idmg_rate, dmg_factor, ibrg_rate, brg_factor, psex_age, psex_age_damage, lia_ac_cnt1, lia_ac_cnt2,\
    		               lia_ac_cnt3, lia_ac_cntc, dmg_ac_cnt1, dmg_ac_cnt2, dmg_ac_cnt3, plia_acc, pdmg_acc, plia_acc_c, fcar_class, dedr_begin, iofficer, nname, ibig_office, ibig_sales, ibig_policy, \
    		               ibig_comp, ibig_branch, mbusiness, fcomp_class, fcomp_class_last, ileader, aassured_zip, irel_card, iquery_num, iquery_num_damage, iquota, nchi_full, fnation, v_prem, v_ori_prem,\
    		               tot_prem, ch_ins_grp1, ch_ins_grp2, ch_ins_grp3, pre_dply1_bgn, pre_dply1_end, pre_prem1, pre_prem2, pre_dply2_bgn, pre_dply2_end, pre_sex_age, pre_sex_age_damage, pre_lia_acc, \
    		               pre_dmg_acc, note1, linnum, nbrand, remark1, remark2, remark6, remark7, ibig_nname, mdiscount, tot_mpay, pre_ch_ins_grp1, pre_ch_ins_grp2, pre_ch_ins_grp3, icorps, ncorps, pdiscount,\
    		               fcomp_24, remark3, fassured, tphone_con, imovephone, iemail, remark4, remark5, nproject, lia_class, nequipment, option, dbirth, dissue, iroute, bzfrom, irate_type, iroute_comm, \
    		               iroute_prop, iupdate, dupdate, qdmg_acc_sum, qlia_acc_sum, iapplicant, napplicant, apayment_zip, apayment, fapplicant, fsex_appl, dbirth_appl, itel_appl, ndeputy_appl, nrelation_appl,\
    		               ndeputy_assured, iabn_type, freason_reject, nremark_reject,iestimate_ori, iestimate_sug, itransno_ori, itransno_sug, fuw_status_ori, fuw_status_sug, mcomp_prem_sug, frenew_type,isecond_hand,\
    		               pdmg_acc_sug, qdmg_acc_sum_sug, iquery_num_damage_sug,introducer,icard_main,qdrunk_driving,qpro_month, \
    		               itransno_ori_atm, itransno_sug_atm,itransno_ori_post,itransno_sug_post,mequipment,iassured_cntry,iapplicant_cntry, \
    		               fequipment1, fequipment2, fequipment3, fequipment4, fequipment5, fequipment6, \
    		               fequipment9, nequipment9, funknown_dmg_ori, funknown_dmg_sug, \
    		               punknown_acc_ori, pre_punknown_acc, qunknown_acc_sum_ori, punknown_acc_sug, qunknown_acc_sum_sug, \
    		               iquery_num_unknown_ori, iquery_num_unknown_sug,aemail_eply,psex_age_c,iquery_num_c, \
    		               foccup, noccup, applicant_foccup, applicant_noccup, \
    		               itransno_ori_007, itransno_ori_008, itransno_ori_009, itransno_sug_007, itransno_sug_008, itransno_sug_009, tmobile_appl, aemail_appl, \
    		               tmobile_eply,ireg_no,itransno_ori_013,itransno_sug_013,dfirst_ply,feterms,qviolate,dinstall,isequence,ainstall_zip,ainstall)",
    		             "  VALUES (?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,current,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?, \
    		                        ?,?,?,?,?,?,?, \
    		                        ?,?,?,?,?,?, \
    		                        ?,?,?,?,\
    		                        ?,?,?,?,?,?,?,?,?,?,\
    		                        ?,?,?,?, \
    		                        ?,?,?,?,?,?,?,?, \
    		                        ?,?,?,?,?,?,?, \
    		                        ?,?,?,? ) ");

    		   $PREPARE STM_ply_302 FROM $buf1;
    		   $EXECUTE STM_ply_302
    		      USING $last_ply,"",$last_card,$fcard_class, $irelative_ply,
    		            $comp_date_begin,$comp_date_end,$premium1_ori, $last_policy_2,$last_policy_3,
    		            $qply_period,$dply_begin,$dply_end,$assuredn,$license,
    		            $birth,$sex,$marriage,$user,$benefn,
    		            $assureda,$tel,$ply_area,$issue_ym,$pro_year,
    		            $brandi,$brandn,$car_typei,$ichange_note,$car_typen,
    		            $cylinder,$engine,$body,$tagnum,$scar_price,
    		            $dmg_align,$brg_align,$lia_align,$qpt,$fpt,
    		            $idmg_rate,$dmg_factor,$ibrg_rate,$brg_factor,$psex_age,
    		            $psex_age_damage,$lia_ac_cnt[0],$lia_ac_cnt[1],$lia_ac_cnt[2],$lia_ac_cntc,
    		            $dmg_ac_cnt[0],$dmg_ac_cnt[1],$dmg_ac_cnt[2],$splia_acc,$spdmg_acc,
    		            $plia_acc_c,$fcar_class,$dedr_begin,$iofficer,$nname,
    		            $tmp_big_office,$tmp_big_sales,"",$ibig_comp,$ibig_branch,
    		            $mbusiness2,$comp_class,$comp_class_last,$ileader,$aassured_zip,
    		            $irel_card,$iquery_num,$iquery_num_damage,$iquota,$nchi_full,
    		            $fnation,$v_prem,$v_ori_prem,$tot_prem,$ch_ins_grp[0],
    		            $ch_ins_grp[1],$ch_ins_grp[2],$pre_ply1_bgn,$pre_ply1_end,$pre_prem1,
    		            $pre_prem2,$pre_ply2_bgn,$pre_ply2_end,$sp_sex_age,$sp_sex_age_dmg,
    		            $sp_lia_acc,$sp_dmg_acc,$note1,$linnum,$nbrand,
    		            $remark1,$remark2,$remark6,$remark7,$LHsIbig_Nname,
       		            $sum_mdiscount,$tot_mpay,$pre_ch_ins_grp[0],$pre_ch_ins_grp[1],$pre_ch_ins_grp[2],
       		            $icorps,$ncorps,$main_discount,$fcomp_24,$remark3,
       		            $assuredf,$tphone_con,$imovephone,$iemail,$remark4,
       		            $remark5,$nproject,$lia_class, $inequipment,$intopt,
       		            $dbirth,$dissue,$iroute,$bzfrom,$irate_type,
       		            $iroute_comm,$iroute_prop,$userid,$qdmg_acc_sum_renew_ori,$qlia_acc_sum_renew,
       		            $iapplicant,$napplicant,$apayment_zip,$apayment,$fapplicant,
       		            $fsex_appl,$dbirth_appl,$itel_appl,$ndeputy_appl,$nrelation_appl,
       		            $ndeputy_assured,$abn_type,$freason_reject,$remark_reject,$iestimate_ori,
       		            $iestimate_sug,$itransno_ori,$itransno_sug,$fuw_status_ori,$fuw_status_sug,
       		            $premium1,$frenew_type,$isecond_hand,$spdmg_acc_sug, $qdmg_acc_sum_renew_sug,
       		            $iquery_num_damage_sug,$iintroducer,$icard_main,$qdrunk_driving,$qpro_month,
       		            $itransno_ori_atm,$itransno_sug_atm, $itransno_ori_post, $itransno_sug_post,$mequipment,$iassured_cntry, $iapplicant_cntry,
       		            $fequipment1, $fequipment2, $fequipment3, $fequipment4, $fequipment5, $fequipment6,
       		            $fequipment9, $nequipment9, $funknown_dmg_ori, $funknown_dmg_sug,
       		            $spunknown_acc, $sp_unknown_acc, $qunknown_acc_sum_renew_ori,$spunknown_acc_sug,$qunknown_acc_sum_renew_sug,
       		            $iquery_num_unknown,$iquery_num_unknown_sug,$aemail_eply,$psex_age_c,$iquery_num_c,
       		            $foccup, $noccup,$applicant_foccup, $applicant_noccup,
       		            $itransno_ori_007,$itransno_ori_008,$itransno_ori_009,$itransno_sug_007,$itransno_sug_008,$itransno_sug_009,$tmobile_appl,$aemail_appl,
       		            $tmobile_eply,$ireg_no,$itransno_ori_013,$itransno_sug_013,$dfirst_ply,$feterms,$qviolate,
       		            $dinstall,$isequence,$ainstall_zip,$ainstall;

    		   #ifdef PRINTF_FLAG
    		      printf("INSERT policy_302 SQLCODE[%d]\n",SQLCODE);
    		      printf("--10876--trace last_ply[%s]fuw_status_ori=[%d]fuw_status_sug=[%d]\n ",last_ply,fuw_status_ori,fuw_status_sug);
    		      printf("sqlca.sqlerrd[2]=[%d]\n",sqlca.sqlerrd[2]);
    		      printf("end insert\n");
    		   #endif
    		   if (SQLCODE == -239)
    		   {
    		      $INSERT INTO duplic1 VALUES ($last_ply,$last_iengine,' ','�����O����(policy_302)����','2','E31',$iofficer);
    		   }
    		   else
    		   {

    		      if (SQLCODE!=0) goto get302_err1;
    		   }
    	   }
      }

      $WHENEVER SQLERROR GOTO get302_err1;

   /***************************************************/
   end:
   /***************************** END  **********************************/
      printf("3.42 >>>> ca302 5 end SUCCESS[%d]\n",SUCCESS);
      return SUCCESS;

   get302_err1:
      printf("get302_err1:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
      if(SQLCODE!=0) MsgCode=SQLCODE;
      $WHENEVER SQLERROR CONTINUE;     /* reset error handling */
      memset(err_buf,0,sizeof(err_buf));
      strcpy(err_buf,"get302_err1:");
      strcat(err_buf,last_ply);
      strcat(err_buf,"-");
      strcat(err_buf,sqlca.sqlerrm);
      EWRITE(userid,MsgCode,err_buf);
      return MsgCode;

   get302_err:
      printf("get302_err:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
      rc = SQLCODE;
      memset(err_buf,0,sizeof(err_buf));
      strcpy(err_buf,"get302_err:");
      strcat(err_buf,last_ply);
      strcat(err_buf,"-");
      strcat(err_buf,sqlca.sqlerrm);
      EWRITE(userid,SQLCODE,err_buf);
      $WHENEVER SQLERROR CONTINUE;     /* reset error handling */
      return rc;
}

int sPrepare()
{
     $char   FullDBName[30], stmt_buf[8192];
     $long   mdamage_cover;
     $char   xBranch[3];
     $char   oipolicy[21],oiofficer[11], oiofficer8[2];
     $long   odply_end;
     $char   OfficerStat[100], SelectStat[100], IinsTypeStat[100], SelectEquip[900];
     $char   Aipolicy[21],nequ_name[21],Anequipment[31],nequ_comp[11],fedr_class_A[2];
     $int    nequ_prem = 0;
     int     i, flag_YF, iTmp;
     $date   tmp_dply_begin, tmp_dply_end;
     $char   tmp_ipolicy[21], tmp_nequipment[31], tmp_iresource[3],tmp_iengine[CA_ENGINE_NUM],tmp_ipolicyB[21];
     $char   tmp_iofficer[11], tmp_icar_flag[3];
     $long   count_num, liofficer;
     $long   minjured_cover_51, mdeath_cover_51, mdamage_cover_51;
     $long   mins_premium_51, mpure_prem_51, mprem_51, mpremium;
     $int    qnext_year_B, qnext_year_chk, iCount, iMonth, iDay;
     $char   dply_year_B[5], sSQL[128], fcard_class[2], irelative_ply[21], up_low_flag1[2], up_low_flag2[2];
     $char   Aiofficer[11], oibig_office[10];
     $int    dmg_acc_1st, dmg_acc_2nd, dmg_acc_3rd ;
     int     oflag_dmg;
     char    stmp[900];
  �@ $char   tmp_iply[21];
     $int    oPlyClosed=0,qnext_year_cacu=0,qyear_ES=0;
     $char   iissue_ym_B[7];
     $long   lng_dply_begin_B;
     $long   lng_iissue_ym_B;
     $int    ply_end_day;
     $long   mins_premium_x;
     $int    icar_age,tmp_mamt;
     $char   tmp_iquota14[5]=" ";
     $long   tmp_1101_chk,tmp_1201_chk,tmp_Y63_chk;
     $char   tmp_iofficer_prmt[11], tmp_iquota_prmt[7],tmp_sbus_source[4]; /* �^�k�g��,�~�Z���,�M�ץN�� add by sylvia 103.09.01 */
     $char   tmp_itag[CA_TAG_NUM], tmp_cartype[3], tmp_iassured[15];


     /* ca_promote */
     $char   pro_no[11],iofficer_1[2], ioff_chk[11],tmp_ibig_office[10],tmp_iofficer_B[11],tmp_ibig_comp[2];
     $int    iofficer_len, ioff_ck_bgn, ioff_ck_len, ioff_ck_end;
     $long   mlimit;
     $char   col_buf[51];
     $char   *tmpProj; /* �M�ץN�� */
     $char   stmpProj[4], sFullDB[21];

     $char   sPorj_ieng[21];

     $WHENEVER SQLERROR GOTO errexit;
     $SET LOCK MODE TO WAIT ;

     #ifdef PRINTF_FLAG
     printf(" before branch \n");
     #endif

     if (intopt == 55 )
     {
         $DECLARE sdb_cur55 CURSOR WITH HOLD FOR
           SELECT branch
             INTO $xBranch
             FROM servertbl
            WHERE branch <> 'S1'
              and branch = '00';
         $OPEN sdb_cur55;
     }
     else
     {
         $DECLARE sdb_cur CURSOR WITH HOLD FOR
           SELECT branch
             INTO $xBranch
             FROM servertbl
            WHERE branch <> 'S1';
         $OPEN sdb_cur;
     }
     for(;;)
     {
        if (intopt == 55 )
          $FETCH sdb_cur55;
        else
          $FETCH sdb_cur;

          if (SQLCODE == SQLNOTFOUND) break;

          printf("xBranch[%s]\n",xBranch);
          strcpy(FullDBName,get_full_dbname(xBranch));
          #ifdef PRINTF_FLAG
          printf("----\n");
          #endif

          /* 102.12.25 iinstall(�����M�ץN��)�Τ���A���Ӱ��M�׳Ƶ� */
          stmt_buf[0] = '\0';
          if (intopt == 55 )
          {
            sprintf(stmt_buf,
            "INSERT INTO ply_relation_last( \
                    ipolicy, icard, fcard_class, irelative_ply, ilast_card, ilast_ply, \
                    inext_ply, itmp_policy, itreaty, qply_period, dply_begin, dply_end, \
                    iissue_ym, ipro_year, ibrand, icar_type, mdmg_agent, mdmg_commi, \
                    mdmg_discount, mdmg_prem, mdmg_pure_prem, mlia_agent, mlia_commi, \
                    mlia_discount, mlia_prem, mlia_pure_prem, ibig_comp, ibig_branch, \
                    ibig_office, ibig_sales, iresource, ibroker, iofficer, ileader, icorps, \
                    iarea, icashier,iexaminer, dexamine, ientry, dentry, dpolicy, dply_close, \
                    dapply, fprint, drenew_print, dtransfer, fedr_class, dendorse, ibranch, \
                    iquota, icomp_in, ibranch_in, icomp_at, ibranch_at, mready, mstable, \
                    mcompensation, madjcom_prem, mresearch, minvest, mbus_rule, mbusiness, \
                    mcapital, maintain, fcomp_class, fcomp_class_last, fdiscount, ipay_way, \
                    ibatch_no, icar_flag, transno, seqno, qnext_year, iinstall, iofficer_prmt, \
                    iquota_prmt, ileader_prmt, irate_type, bzfrom, iroute_comm, icomm_obj, \
                    dcreate, qprovision, dtrans_b2b, isecond_hand, icard_main, aemail_eply, tmobile_eply, \
                    ireg_no,feterms ) \
             SELECT ipolicy, icard, fcard_class, irelative_ply, ' ' as ilast_card, ' ' as ilast_ply, \
                    ' ' as inext_ply, ' ' as itmp_policy, ' ' as itreaty, 12 as qply_period, dply_begin, dply_end, \
                    ' ' as iissue_ym, ipro_year, ibrand, icar_type, 0 as mdmg_agent, 0 as mdmg_commi, \
                    0 as mdmg_discount, 0 as mdmg_prem, 0 as mdmg_pure_prem, 0 as mlia_agent, 0 as mlia_commi, \
                    0 as mlia_discount, 0 as mlia_prem, 0 as mlia_pure_prem, ibigcomp as ibig_comp, ' ' as ibig_branch, \
                    ibus_location as ibig_office, ibig_sales, iresource, ' ' as ibroker, iofficer, ileader, ' ' as icorps, \
                    ' ' as iarea, ' ' as icashier, ' ' as iexaminer, '' as dexamine, ' ' as ientry, '' as dentry, '' as dpolicy, '' as dply_close, \
                    '' as dapply, 0 as fprint, '' as drenew_print, '' as dtransfer, ' ' as fedr_class, '' as dendorse, ibranch, \
                    iquota, iupcomp as icomp_in, ibranch as ibranch_in, iupcomp as icomp_at, ibranch as ibranch_at, 0 as mready, 0 as mstable, \
                    0 as mcompensation, 0 as madjcom_prem, 0 as mresearch, 0 as minvest, 0 as mbus_rule, 0 as mbusiness, \
                    0 as mcapital, 0 as maintain, ' ' as fcomp_class, ' ' as fcomp_class_last, ' ' as fdiscount, ' ' as ipay_way, \
                    ' ' as ibatch_no, ' ' as icar_flag, ' ' as transno, ' ' as seqno, 0 as qnext_year, ' ' as iinstall, ' ' as iofficer_prmt, \
                    ' ' as iquota_prmt, ' ' as ileader_prmt, irate_type, bzfrom, iroute_comm, icomm_obj, \
                    '' as dcreate, 0 as qprovision, '' as dtrans_b2b, ' ' as isecond_hand, ' ' as icard_main, aemail_eply, tmobile_eply, \
                    ireg_no, feterms  \
               FROM newa00:estimate_fb a where ipolicy = ? ");
          }
          else
          {
              sprintf(stmt_buf,
              " INSERT INTO ply_relation_last( \
                            ipolicy, icard, fcard_class, irelative_ply, ilast_card, ilast_ply, inext_ply, itmp_policy, itreaty,\
                            qply_period, dply_begin, dply_end, iissue_ym, ipro_year, ibrand, icar_type, mdmg_agent, mdmg_commi, \
                            mdmg_discount, mdmg_prem, mdmg_pure_prem, mlia_agent, mlia_commi, mlia_discount, mlia_prem, mlia_pure_prem, \
                            ibig_comp, ibig_branch, ibig_office, ibig_sales, iresource, ibroker, iofficer, ileader, icorps, iarea, \
                            icashier,iexaminer, dexamine, ientry, dentry, dpolicy, dply_close, dapply, fprint, drenew_print, dtransfer,\
                            fedr_class, dendorse, ibranch, iquota, icomp_in, ibranch_in, icomp_at, ibranch_at, mready, mstable, \
                            mcompensation, madjcom_prem, mresearch, minvest, mbus_rule, mbusiness, mcapital, maintain, fcomp_class,\
                            fcomp_class_last, fdiscount, ipay_way, ibatch_no, icar_flag, transno, seqno, qnext_year, iinstall, \
                            iofficer_prmt, iquota_prmt, ileader_prmt, irate_type, bzfrom, iroute_comm, icomm_obj, dcreate, qprovision, \
                            dtrans_b2b,isecond_hand,icard_main,aemail_eply,tmobile_eply,ireg_no,feterms ) \
                     SELECT ipolicy, icard, \
                            fcard_class, irelative_ply, ilast_card, ilast_ply, inext_ply, itmp_policy, itreaty,\
                            qply_period, dply_begin, dply_end, iissue_ym, ipro_year, ibrand, icar_type, mdmg_agent, mdmg_commi, \
                            mdmg_discount, mdmg_prem, mdmg_pure_prem, mlia_agent, mlia_commi, mlia_discount, mlia_prem, mlia_pure_prem, \
                            ibig_comp, ibig_branch, ibig_office, ibig_sales, iresource, ibroker, iofficer, ileader, icorps, iarea, \
                            icashier,iexaminer, dexamine, ientry, dentry, dpolicy, dply_close, dapply, fprint, drenew_print, dtransfer,\
                            fedr_class, dendorse, ibranch, iquota, icomp_in, ibranch_in, icomp_at, ibranch_at, mready, mstable, \
                            mcompensation, madjcom_prem, mresearch, minvest, mbus_rule, mbusiness, mcapital, maintain, fcomp_class,\
                            fcomp_class_last, fdiscount, ipay_way, ibatch_no, icar_flag, transno, seqno, qnext_year, '0000000000', \
                            iofficer_prmt, iquota_prmt, ileader_prmt, irate_type, bzfrom, iroute_comm, icomm_obj, dcreate, qprovision, \
                            dtrans_b2b,isecond_hand,icard_main,aemail_eply,tmobile_eply,ireg_no,feterms \
                       FROM %s:ply_relation WHERE ipolicy = ? ",FullDBName);
          }

          $PREPARE ins_re FROM $stmt_buf;

          strSearchReplace(stmt_buf,"SELECT ipolicy, icard","SELECT rtrim(ipolicy)||'-B', rtrim(icard)||'-B'");
          $PREPARE ins_reB FROM $stmt_buf; /* 103.12.25 �ΥHInsert ����B��*/

          #ifdef PRINTF_FLAG
          printf("Trace -- stmt_buf = [%s] \n",  stmt_buf);
          printf("====\n");
          #endif

          stmt_buf[0] = '\0';
          /* �s�W�Q(�O)�H��O���O(RBA�t�Ϋظm) add by sylvia 105.02.25 (1050105008_C4) */
          if (intopt == 55 )
          {
            sprintf(stmt_buf,
            "INSERT INTO policy_last ( \
                    ipolicy, icard, ixxcard, fassured, iassured, iassured_ext, nassured, ilicense, ibirth, fsex, fmarriage, \
                    nuser, ibenef, nbenef, aassured, aassured_zip, itel, itel_night, mobil_phone, iemail, apayment, apayment_zip, \
                    iply_area, nbrand_abbr, ncar_abbr, fcar_note, qcylinder, iengine, ibody, itag, mcar_price, nequipment, flimit, \
                    pdmg_align, pbrg_align, plia_align, iabn_type, fpass, ipass, dpass, ffac, dfac, fcut, fcal_way, idmg_rate, \
                    pdmg_factor, ibrg_rate, pbrg_factor, qpt, fpt, psex_age, psex_age_damage, lia_class, plia_acc, dmg_acc_1st, \
                    dmg_acc_2nd, dmg_acc_3rd, pdmg_acc, fhuman, fcomp_24, iext_policy, qpro_month, mkilo_ply, mkilo_edr, irisk, \
                    irelative_ext, iapplicant, napplicant, dbirth, dissue, iextra_charge, gextra_charge, pextra_charge, \
                    iquery_num_damage, iquery_num, introducer, mequipment, survey_num, bound_num, abnormal_num, iroute_prop, \
                    iroute_accept, iroute, qlia_acc_sum, qdmg_acc_sum, fapplicant, fsex_appl, dbirth_appl, itel_appl, ndeputy_appl, \
                    nrelation_appl, ndeputy_assured, iassured_cntry, iapplicant_cntry, \
                    fequipment1, fequipment2, fequipment3, fequipment4, fequipment5, fequipment6, fequipment9, nequipment9 ) \
             SELECT ipolicy, icard, ' ' as ixxcard, fassured, iassured, ' ' as iassured_ext, nassured, ' ' as ilicense, ' ' as ibirth, fsex, fmarriage, \
                    ' ' as nuser, ' ' as ibenef, ' ' as nbenef, assured as aassured, ' ' as aassured_zip, itel, ' ' as itel_night, ' ' as mobil_phone, ' ' as iemail, \
                    aapplicant as apayment, ' ' as apayment_zip, ' ' as iply_area, nbrand_abbr, ' ' AS ncar_abbr, ' ' AS fcar_note, qcylinder, iengine,  \
                    ' ' as ibody, itag, mcar_price, ' ' as nequipment, ' ' as flimit,    0 as pdmg_align, 0 as pbrg_align, 0 as plia_align, ' ' as iabn_type,  \
                    ' ' as fpass, ' ' as ipass, '' as dpass, ' ' as ffac, '' as dfac, 0 as fcut, 'M' as fcal_way, ' ' as idmg_rate, \
                    0 as pdmg1q_factor, ' ' as ibrg_rate, 0 as pbrg_factor, qpt, fpt, 0 as psex_age, 0 as psex_age_damage, 0 as lia_class, 0 as plia_acc,  \
                    0 as dmg_acc_1st,  0 as dmg_acc_2nd, 0 as dmg_acc_3rd, 0 as pdmg_acc, '1' as fhuman, 'N' as fcomp_24, ' ' as iext_policy,  qpro_month, \
                    0 as mkilo_ply, 0 as mkilo_edr, ' ' as irisk,  ' ' as irelative_ext, iapplicant, napplicant, dbirth, dissue, 0 as iextra_charge, \
                    0 as gextra_charge, 0 as pextra_charge, ' ' as iquery_num_damage, ' ' as iquery_num, ' ' as introducer, mequipment, ' ' as survey_num, \
                    ' ' as bound_num, ' ' as abnormal_num, ' ' as iroute_prop, ' ' as iroute_accept, iroute, 0 as qlia_acc_sum, 0 as qdmg_acc_sum, \
                    fapplicant, fsex_appl, '' as dbirth_appl, '' as itel_appl, ' ' as ndeputy_appl, \
                    nrelation_appl, ndeputy_assured, ' ' as iassured_cntry, ' ' as iapplicant_cntry, \
                    '0','0','0','0','0','0','0',' ' \
               FROM newa00:estimate_fb a WHERE ipolicy = ?  ");
          }
          else
          {
            sprintf(stmt_buf,
            " INSERT INTO policy_last ( \
                          ipolicy, icard, ixxcard, fassured, iassured, iassured_ext, nassured, ilicense, ibirth, fsex, fmarriage, \
                          nuser, ibenef, nbenef, aassured, aassured_zip, itel, itel_night, mobil_phone, iemail, apayment, apayment_zip, \
                          iply_area, nbrand_abbr, ncar_abbr, fcar_note, qcylinder, iengine, ibody, itag, mcar_price, nequipment, flimit,\
                          pdmg_align, pbrg_align, plia_align, iabn_type, fpass, ipass, dpass, ffac, dfac, fcut, fcal_way, idmg_rate, \
                          pdmg_factor, ibrg_rate, pbrg_factor, qpt, fpt, psex_age, psex_age_damage, lia_class, plia_acc, dmg_acc_1st, \
                          dmg_acc_2nd, dmg_acc_3rd, pdmg_acc, fhuman, fcomp_24, iext_policy, qpro_month, mkilo_ply, mkilo_edr, irisk, \
                          irelative_ext, iapplicant, napplicant, dbirth, dissue, iextra_charge, gextra_charge, pextra_charge, \
                          iquery_num_damage, iquery_num, introducer, mequipment, survey_num, bound_num, abnormal_num, iroute_prop, \
                          iroute_accept, iroute, qlia_acc_sum, qdmg_acc_sum, fapplicant, fsex_appl, dbirth_appl, itel_appl, ndeputy_appl, \
                          nrelation_appl, ndeputy_assured, iassured_cntry, iapplicant_cntry, \
                          fequipment1, fequipment2, fequipment3, fequipment4, fequipment5, fequipment6, fequipment9, nequipment9, \
                          punknown_acc,iquery_num_unknown,qunknown_acc_sum,foccup,noccup,applicant_foccup,applicant_noccup, \
                          tmobile_appl, aemail_appl, dinstall, isequence, ainstall_zip, ainstall ) \
                   SELECT ipolicy, icard, \
                          ixxcard, fassured, iassured, iassured_ext, nassured, ilicense, ibirth, fsex, fmarriage, \
                          nuser, ibenef, nbenef, aassured, aassured_zip, itel, itel_night, mobil_phone, iemail, apayment, apayment_zip, \
                          iply_area, nbrand_abbr, ncar_abbr, fcar_note, qcylinder, iengine, ibody, itag, mcar_price, nequipment, flimit,\
                          pdmg_align, pbrg_align, plia_align, iabn_type, fpass, ipass, dpass, ffac, dfac, fcut, fcal_way, nvl(idmg_rate,' '), \
                          pdmg_factor, nvl(ibrg_rate,' '), pbrg_factor, qpt, fpt, psex_age, psex_age_damage, lia_class, plia_acc, dmg_acc_1st, \
                          dmg_acc_2nd, dmg_acc_3rd, pdmg_acc, fhuman, fcomp_24, iext_policy, qpro_month, mkilo_ply, mkilo_edr, irisk, \
                          irelative_ext, iapplicant, napplicant, dbirth, dissue, iextra_charge, gextra_charge, pextra_charge, \
                          iquery_num_damage, iquery_num, introducer, mequipment, survey_num, bound_num, abnormal_num, iroute_prop, \
                          iroute_accept, iroute, qlia_acc_sum, qdmg_acc_sum, fapplicant, fsex_appl, dbirth_appl, itel_appl, ndeputy_appl, \
                          nrelation_appl, ndeputy_assured, iassured_cntry, iapplicant_cntry, \
                          fequipment1, fequipment2, fequipment3, fequipment4, fequipment5, fequipment6, fequipment9, nequipment9, \
                          punknown_acc,iquery_num_unknown,qunknown_acc_sum,foccup,noccup,applicant_foccup,applicant_noccup, \
                          tmobile_appl, aemail_appl, dinstall, isequence, ainstall_zip, ainstall \
                     FROM %s:policy WHERE ipolicy = ? ",FullDBName);
          }
          $PREPARE ins_po FROM $stmt_buf;

          strSearchReplace(stmt_buf,"SELECT ipolicy, icard","SELECT rtrim(ipolicy)||'-B', rtrim(icard)||'-B'");
          $PREPARE ins_poB FROM $stmt_buf; /* 103.12.25 �ΥHInsert ����B��*/
          #ifdef PRINTF_FLAG
          printf("Trace -- stmt_buf = [%s] \n",  stmt_buf);
          printf("****\n");
          #endif

          stmt_buf[0] = '\0';
          if (intopt == 55 )
          {
            sprintf(stmt_buf,
            "INSERT INTO ply_ins_type_last ( \
                    ipolicy, iins_type, minjured_cover, mdeath_cover, mdamage_cover, mdeduct, \
                    mins_premium, mpure_prem, qserial, fedr_status, dendorse, dedr_begin, dedr_end, \
                    iendorse, pcommission, mcommission, pagent, magent, pdiscount, mdiscount, \
                    drate_ym, mprem, iproduct, ipaid_base, qday, mexpense, mexp_disc, provision,pcar_price ) \
             SELECT ipolicy, iins_type, minjured_cover, mdeath_cover, mdamage_cover, mdeduct, \
                    mprem as mins_premium, 0 as mpure_prem, 0 as qserial, ' ' as fedr_status, '' as dendorse, '' as dedr_begin, '' as dedr_end, \
                    ' ' as iendorse, 0.0 as pcommission, 0 as mcommission, 0.0 as pagent, 0 as magent, 0.0 as pdiscount, 0 as mdiscount, \
                    ' ' as drate_ym, 0 as mprem, ' ' as iproduct, ' ' as ipaid_base, qday, 0 as mexpense, 0 as mexp_disc, ' ' as provision, 0.0 as pcar_price  \
               FROM newa00:est_ins_type_fb WHERE ipolicy = ?  AND mdamage_cover > 0 ");
          }
          else
          {
            sprintf(stmt_buf,
            " INSERT INTO ply_ins_type_last ( \
                          ipolicy, iins_type, minjured_cover, mdeath_cover, mdamage_cover, mdeduct, \
                          mins_premium, mpure_prem, qserial, fedr_status, dendorse, dedr_begin, dedr_end, \
                          iendorse, pcommission, mcommission, pagent, magent, pdiscount, mdiscount, \
                          drate_ym, mprem, iproduct, ipaid_base, qday, mexpense, mexp_disc, provision,pcar_price)  \
                   SELECT ipolicy, \
                          iins_type, minjured_cover, mdeath_cover, mdamage_cover, mdeduct, \
                          mins_premium, mpure_prem, qserial, fedr_status, dendorse, dedr_begin, dedr_end, \
                          iendorse, pcommission, mcommission, pagent, magent, pdiscount, mdiscount, \
                          drate_ym, mprem, iproduct, ipaid_base, qday, mexpense, mexp_disc, provision,pcar_price \
                     FROM %s:ply_ins_type WHERE ipolicy = ? AND mdamage_cover > 0 ",FullDBName);
          }
          $PREPARE ins_type FROM $stmt_buf;

          strSearchReplace(stmt_buf,"SELECT ipolicy","SELECT rtrim(ipolicy)||'-B'");
          strcat(stmt_buf, " AND iins_type in ('11','211')");
          $PREPARE ins_typeB FROM $stmt_buf; /* 103.12.25 �ΥHInsert ����B��*/

          #ifdef PRINTF_FLAG
          printf("Trace -- stmt_buf = [%s] \n",  stmt_buf);
          printf("!!!!\n");
          #endif

          stmt_buf[0] = '\0';
          if( intopt == 55 )
          {
               sprintf(stmt_buf, "INSERT INTO ca_pa_ply_last \
                                  	(ipolicy, iins_type, iins_scope, mins_amt, daily_pay) \
                                  SELECT ipolicy,iins_type, case when daily_pay >=10000 then '3' else '2' end, \
                                         mdamage_cover, daily_pay \
                                    FROM est_ins_type_fb WHERE ipolicy = ? \
                                     AND iins_type = '56' and mdamage_cover > 0 ");
          }
          else
          {
            sprintf(stmt_buf, "INSERT INTO ca_pa_ply_last SELECT * FROM %s:ca_pa_ply WHERE ipolicy = ? AND mins_amt > 0 ",FullDBName);
          }
          $PREPARE pa_type FROM $stmt_buf;

          /* 960612, ���ݪ��I34,87: */
          stmt_buf[0] = '\0';
          sprintf(stmt_buf, "INSERT INTO ply_ins_cover_last SELECT * FROM %s:ply_ins_cover WHERE ipolicy = ? AND mcover > 0 ",FullDBName);
          $PREPARE ins_cover FROM $stmt_buf;

          /* �r�V��X�I:561�r�� add by sylvia 114.04.24 (1140409004_C01)  */
          stmt_buf[0] = '\0';
          sprintf(stmt_buf, "INSERT INTO ply_ins_assured_302 SELECT * FROM %s:ply_ins_assured WHERE ipolicy = ? and iins_type = '561' ",FullDBName);
          $PREPARE ins_assured FROM $stmt_buf;

          printf("Inserting into _last tables.....\n");

          $BEGIN WORK;

          /* �z�糧����O�J�p�@�~�ŦX����϶����O�� */
          /* AND a.ipolicy in ( select ipolicy from newa00:ca_tmp_no ) */
          count_num = 0;
          stmt_buf[0] = '\0';

          if( intopt == 9 || intopt == 25 || ( intopt == 55 )){ /* �����J�p */
              sprintf( sSQL, " AND a.ipolicy in ( select ipolicy from newa00:ca_tmp_no)");
          }else{
              sprintf( sSQL," ");
          }

          /* 100.03.01,���� �έ�W�b�� */
          /* �����b��O�J�p�϶�, �w�鵲,�����P�ΰh�O���̷s�O���� */
          if (intopt == 55 )
          {
            sprintf(stmt_buf,
                 "SELECT a.ipolicy, a.dply_begin, a.dply_end, ' ' as nequipment, a.iresource, \
                         a.iofficer, ' ' as icar_flag, a.fcard_class, nvl(a.irelative_ply,' '), \
                         round((a.dply_end - a.dissue)/365,0)::integer, a.iengine,iquota[1,4], \
                         0 ,0 ,a.ibus_location,nvl(a.ibigcomp,' '), ' ' as iofficer_prmt, \
                         ' ' as iquota_prmt, (select sbus_source from officer where iofficer = a.iofficer), \
                         0, a.iengine, nvl(a.itag,' '), a.icar_type, a.iassured \
                    FROM newa00:estimate_fb a \
                   WHERE a.dply_end between ? and ? ");

          }
          else
          {
            sprintf(stmt_buf, "SELECT a.ipolicy, a.dply_begin, a.dply_end, b.nequipment, a.iresource, \
                                      a.iofficer, a.icar_flag, a.fcard_class, nvl(a.irelative_ply,' '), round((a.dply_end - b.dissue)/365,0)::integer, \
                                      b.iengine,iquota[1,4],(dpolicy-'11/01/2013'::date),(dpolicy-'12/01/2013'::date),a.ibig_office,nvl(a.ibig_comp,' '), \
                                      a.iofficer_prmt, a.iquota_prmt, (select sbus_source from officer where iofficer = a.iofficer), \
                                      (dpolicy-'11/01/2014'::date), b.iengine, nvl(b.itag,' '), a.icar_type, b.iassured, \
                                      nvl(round((year(dply_end)-year(dinstall))*12+(month(dply_end)-month(dinstall))::INTEGER),0) \
                                 FROM %s:ply_relation a, %s:policy b \
                                WHERE a.dply_end between ? and ? \
                                  AND a.ipolicy = b.ipolicy \
                                  AND a.dply_close is not null \
                                  AND nvl(a.fedr_class,' ') <> '1' %s" ,FullDBName, FullDBName, sSQL );
          }
          #ifdef PRINTF_FLAG
          printf("[%s]\n",stmt_buf);
          #endif

          $PREPARE ins_ply_tmp FROM $stmt_buf;
          $DECLARE ins_ply     CURSOR WITH HOLD FOR ins_ply_tmp;
          $OPEN    ins_ply     USING  $lDplyEndBgn, $lDplyEndEnd;
          while(1)
          {
              $FETCH ins_ply INTO $tmp_ipolicy, $tmp_dply_begin, $tmp_dply_end, $tmp_nequipment, $tmp_iresource,
                                  $tmp_iofficer, $tmp_icar_flag, $fcard_class, $irelative_ply, $qnext_year_cacu,
                                  $tmp_iengine,$tmp_iquota14,$tmp_1101_chk,$tmp_1201_chk,$tmp_ibig_office,$tmp_ibig_comp,
                                  $tmp_iofficer_prmt,$tmp_iquota_prmt,$tmp_sbus_source, $tmp_Y63_chk, $sPorj_ieng,
                                  $tmp_itag, $tmp_cartype, $tmp_iassured, $qyear_ES;

              if (SQLCODE == SQLNOTFOUND) break;

              #ifdef PRINTF_FLAG
              printf("tmp_ipolicy=[%s]irelative_ply[%s] \n", tmp_ipolicy,irelative_ply);
              #endif

              if (fcard_class[0]=='2')
              {
   	          		if (strncmp(tmp_ipolicy+(5),"VW",2)==0)
   	          		{
   	              	/* 951215,�ư������O�T */
   		      				printf("�����O�T�� tmp_ipolicy=[%s]\n",tmp_ipolicy);
   		      				continue ;
   		  					}

					   		  if (strncmp(tmp_ipolicy+(5),"EB",2)==0)
					   		  {
					   		      /* 102.08,�q�ʦۦ樮��X�O�I�ȥi��O�Ĥ@�~�βĤG�~�� */
					   		      if (qnext_year_cacu >= 2)
					   		      {
					   		          printf("�q�ʦۦ樮 tmp_ipolicy=[%s],qnext_year_cacu=[%d]\n",tmp_ipolicy,qnext_year_cacu);
								   			  $INSERT INTO duplic1 VALUES ($tmp_ipolicy,$tmp_iengine,' ','�q�ʦۦ樮��X�O�I�ȥi��O�Ĥ@�~�βĤG�~��','1','E42',$tmp_iofficer);
								   			  continue ;
   		      					}
   		  					}

					   		  if (strncmp(tmp_ipolicy+(5),"ES",2)==0)
					   		  {
					   		      /* �R�q�ΰӫ~�W�L4�~���J�p (1120927002_C05) */
					   		      if (qyear_ES >= 48)
					   		      {
			   			  				$INSERT INTO duplic1 VALUES ($tmp_ipolicy,' ',' ','�R�q�Ϧw�ˤ�j��4�~��O�~���A�Ь��֫O�H��','1','E58',$tmp_iofficer);
			   			  				continue ;
   		      					}
   		  					}

					   		  /* ���N�I�������L���J�p, �j���I�]�n�o�e��O�q����,
					   		     �G�������J�p�üg�Jpolicy_302f��,�~��R��policy_302���
					   		     add by sylvia 105.09.12 (1050531006_C1) */
					   		  $select iassured into $tmp_iassured
					           from cm_personal_deny
					          where iassured = $tmp_iassured
					            and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1]= '1');
					        if (SQLCODE != SQLNOTFOUND)
					        {
											$INSERT INTO duplic1 VALUES ($tmp_ipolicy,$tmp_iengine,' ','�Q�O�H�]�w������O/�d�ߤΧR���Ӹ�2','1','E49',$tmp_iofficer);
											continue ;
									}

                  /* �O��W�����O100�̡A��ӡu�S�w�����I���J�p�v�覡�A���~�N�X���iE48:�S�w�I����O�ݭ��s���w���e���J�p�j
                     �]�n�C�L���n/�Q�O�H��ƪ��ť���O�n�O��,�G���g�Jlast�ɮפ�,�����J�p�@�~��A�R��
                     add by sylvia 105.11.10 (1051027001_C1) */
                  /* ���O100�אּE40���~�N�� modify by 061476 (1100504003_SC1) */
                  if (equip_cmp(tmp_nequipment,"100") == TRUE)
                  {
                      $INSERT INTO duplic1 VALUES ($tmp_ipolicy,$tmp_iengine,' ','���O100�u�D���ި��챾�l���v','1','E40',$tmp_iofficer);
                  }
	      			}

	      			/* 113.3.1 �ĤG���ը��P���J�p */
   	      		if (strncmp(tmp_cartype,"36",2) == 0)
   	      		{
   	      	  		printf("�ĤG���ը��P tmp_ipolicy=[%s],tmp_cartype=[%d]\n",tmp_ipolicy,tmp_cartype);
					   		  $INSERT INTO duplic1 VALUES ($tmp_ipolicy,$tmp_iengine,' ','�ĤG���ը��P���J�p','1','E42',$tmp_iofficer);
					   		  continue ;
   	      		}


	      			if (intopt == 55 )
				      {
				          strcpy(tmp_iassured, trim(tmp_iassured));
								  if (strlen(tmp_iassured) == 0 )
								  {
								      $INSERT INTO duplic1 VALUES ($tmp_ipolicy,$tmp_iengine,' ','�Q�O�I�HID�ť�','1','F55',$tmp_iofficer);
								      continue ;
								  }
				      }

              $WHENEVER SQLERROR CONTINUE;

              #ifdef PRINTF_FLAG
              printf("INSERTING ply_relation_last\n");
              #endif
              $EXECUTE ins_re USING $tmp_ipolicy;

              #ifdef PRINTF_FLAG
              printf("INSERTING policy_last\n");
              #endif
              $EXECUTE ins_po USING $tmp_ipolicy;

              #ifdef PRINTF_FLAG
              printf("INSERTING ply_ins_type_last\n");
              #endif
              $EXECUTE ins_type USING $tmp_ipolicy;

              #ifdef PRINTF_FLAG
              printf("INSERTING ca_pa_ply_last\n");
              #endif
              $EXECUTE pa_type USING $tmp_ipolicy;

              #ifdef PRINTF_FLAG
              printf("INSERTING ply_ins_cover_last\n");
              #endif

              if (intopt == 55 )
              {
                  $insert into  ply_ins_cover_last (ipolicy, iins_type, icover_type, mcover)
                   select ipolicy, iins_type, '001', minjured_cover from est_ins_type_fb
                   where ipolicy = $tmp_ipolicy and iins_type = '34' and mdamage_cover > 0;

                  $insert into  ply_ins_cover_last (ipolicy, iins_type, icover_type, mcover)
                   select ipolicy, iins_type, '002', minjured_cover*2 from est_ins_type_fb
                    where ipolicy = $tmp_ipolicy and iins_type = '34' and mdamage_cover > 0;

                  $insert into  ply_ins_cover_last (ipolicy, iins_type, icover_type, mcover)
                   select ipolicy, iins_type, '003', mdeath_cover from est_ins_type_fb
                    where ipolicy = $tmp_ipolicy and iins_type = '34' and mdamage_cover > 0;

                  $insert into  ply_ins_cover_last (ipolicy, iins_type, icover_type, mcover)
                   select ipolicy, iins_type, '004', mdamage_cover from est_ins_type_fb
                    where ipolicy = $tmp_ipolicy and iins_type = '34' and mdamage_cover > 0;

              }
              else
              {
                  $EXECUTE ins_cover USING $tmp_ipolicy;
              }

							#ifdef PRINTF_FLAG
              printf("INSERTING ply_ins_assured_last\n");
              #endif
              $EXECUTE ins_assured USING $tmp_ipolicy;

              /* �j���I�O��L���P,���J�p��O add by sylvia 105.04.18 (1040901002_C1) */
              strcpy(tmp_itag, trim(tmp_itag));

              if (fcard_class[0]=='1')
              {
                    if ((strlen(tmp_itag) < 4) && (!(ISMOT(tmp_cartype))) &&
                        (strcmp(tmp_cartype,"27") != 0))
                    {
                        tmp_mamt = 0;
                        $select mdamage_cover into $tmp_mamt from ply_ins_type_last where ipolicy = $tmp_ipolicy and iins_type = '21';

                        if (tmp_mamt > 0)
                        {
                            $INSERT INTO duplic1 VALUES ($tmp_ipolicy,$tmp_iengine,' ','�j���I�O��L���P','1','E46',$tmp_iofficer);
   			    								continue ;
   											}
                    }

                    /* ���N�I�������L���J�p, �j���I�]�n�o�e��O�q����,
   		       				�G�������J�p�üg�Jpolicy_302f��,�~��R��policy_302���
   		       				add by sylvia 105.09.12 (1050531006_C1) */
    		    				$select iassured into $tmp_iassured
                       from cm_personal_deny
                      where iassured = $tmp_iassured
                        and (funrenew_ins[1,1] = '1' or funquery_ins[1,1] = '1' or fdelete_ins[1,1]= '1');
                    if (SQLCODE != SQLNOTFOUND)
                    {
                        $INSERT INTO duplic1 VALUES ($tmp_ipolicy,$tmp_iengine,' ','�Q�O�H�]�w������O/�d�ߤΧR���Ӹ�1','1','E49',$tmp_iofficer);
                        continue ;
                    }

						}

				    IS_1stYear_No_PlyB = -1;
				    strcpy(pro_no," "); strcpy(tmp_iofficer_B," ");

            if (fcard_class[0]=='2')
            {

	          		/* 102.12.25 �U�o�ֱM�סB�ΫH2-5�~�ѵs�I�M�פ�"W*"�g��N���ର"H*" */
	              if(tmp_iofficer[0]=='W')
	              {

	              	  if ((strncmp(tmp_iofficer+(7-1),"FWD",3)==0)||(strncmp(tmp_iofficer+(7-1),"ES1",3)==0))
	              	  {
	                      if(strncmp(tmp_iofficer+(7-1),"FWD",3)==0)
	                      {
	                      	  strcpy(ioff_chk,"FWD");
	                      	  strcpy(pro_no,"C17");
	                      	  /*strcpy(tmp_ibig_comp,"B");*/
	                      }
	                      else if (strncmp(tmp_iofficer+(7-1),"ES1",3)==0)
	                      {
	                       	  strcpy(ioff_chk,"ES1");
	                       	  strcpy(pro_no,"Y50");
	                       	  /*strcpy(tmp_ibig_comp,"A");*/
	                      }

	                      /* W�g���ରN�g�� add by sylvia 103.09.01 (1030630002_C1) */
	                      if (strcmp(IsChgNofficer,"Y") == 0)
	                      {
	                          sprintf(stmt_buf, "select unique a.iofficer, a.ibigcomp, b.ibig_office \
	                                               from officer a, ca_promote_officer b \
	                                              where a.iofficer = b.iofficer_ori \
	                                                and b.iofficer_ori[1,1] = 'N' \
	                                                and b.iofficer = '%s' and b.iprmt = '%s' ",
	                                                tmp_iofficer_prmt, pro_no );

		   				  						$PREPARE pre_getoff FROM $stmt_buf;
		   		                  $Execute pre_getoff Into $tmp_iofficer_B,$tmp_ibig_comp,$tmp_ibig_office;

   	                        if (SQLCODE == SQLNOTFOUND)
   	                        {
   	                            $INSERT INTO duplic1 VALUES ($tmp_ipolicy,$tmp_iengine,$tmp_iofficer,'W�ରN�g��N���A��N�g��N�����s�b','1','E33',$tmp_iofficer);
   	                            continue;
   	                        }
   	                        else
   	                        {
	   				      							$Update ply_relation_last
									   					   		Set iofficer      = $tmp_iofficer_B,
									   					      		ibig_comp     = $tmp_ibig_comp,
									   					      		ibig_office   = $tmp_ibig_office,
									   					      		irelative_ply = ' '
									   							Where ipolicy       = $tmp_ipolicy;

	   		              	      	$Update policy_last
	   		              		  				Set iroute = (Select iroute From officer Where iofficer = $tmp_iofficer_B )
	   		              						Where ipolicy = $tmp_ipolicy;
   	              		  		}
	                      }
	                      else
	                      {
	                          /* W�g���ରH�g�� */
   				  								sprintf(stmt_buf, "SELECT iofficer FROM officer \
   					              											WHERE iquota[1,4] = (Select iquota[1,4] From Officer Where iofficer = '%s') \
   					                											AND iofficer[1] = 'H' \
   					                											AND iofficer[7,9] = '%s' \
   					                											AND length(iofficer) = 9  \
   					                											AND sbus_source = '%s'",tmp_iofficer, ioff_chk, pro_no );

   				  								$PREPARE pre_getoff FROM $stmt_buf;
   		                  		$Execute pre_getoff Into $tmp_iofficer_B;

   	                        if (SQLCODE == SQLNOTFOUND)
   	                        {
   	                        		$INSERT INTO duplic1 VALUES ($tmp_ipolicy,$tmp_iengine,$tmp_iofficer,'W�ରH�g��N���A��H�g��N�����s�b','1','E34',$tmp_iofficer);
   	                             continue;
														}
   	                        else
   	                        {
   		    		      						strcpy(tmp_ibig_comp," "); /* H�g��אּ"�D�j�v" */
   				      								$Update ply_relation_last
											   					  Set iofficer      = $tmp_iofficer_B,
											   					      ibig_comp     = $tmp_ibig_comp,
											   					      irelative_ply = ' '
											   					Where ipolicy       = $tmp_ipolicy;

   		              	      		$Update policy_last
   		              		  					Set iroute = (Select iroute From officer Where iofficer = $tmp_iofficer_B )
   		              							Where ipolicy = $tmp_ipolicy;
   	              		  		}
												}
										}
	              } /* tmp_iofficer[0]=='W' end */
	              else if ((tmp_iofficer[0]=='H') && (strcmp(IsChgNofficer,"Y") == 0))
	              {
	                  /* H�g�춷�ରN�g��(�Y�Ӥ��Χ姹����) */
	                  sprintf(stmt_buf, "select unique a.iofficer, a.ibigcomp, b.ibig_office \
                                              from officer a, ca_promote_officer b \
                                              where a.iofficer = b.iofficer_ori and b.iofficer = '%s' \
                                                and b.iprmt = (select sbus_source from officer where iofficer = '%s') \
                                                and a.iofficer[1,1] = 'N' ", tmp_iofficer_prmt, tmp_iofficer );
			  						$PREPARE pre_getoff FROM $stmt_buf;
		          			$Execute pre_getoff Into $tmp_iofficer_B,$tmp_ibig_comp,$tmp_ibig_office;
	                  if (SQLCODE == SQLNOTFOUND)
	                  {
	                      $INSERT INTO duplic1 VALUES ($tmp_ipolicy,$tmp_iengine,$tmp_iofficer,'W�ରN�g��N���A��N�g��N�����s�b','1','E33',$tmp_iofficer);
	                      continue;
	                  }
	                  else
	                  {
									      $Update ply_relation_last
										  			Set iofficer      = $tmp_iofficer_B,
										      			ibig_comp     = $tmp_ibig_comp,
										      			ibig_office   = $tmp_ibig_office,
										      			irelative_ply = ' '
													Where ipolicy       = $tmp_ipolicy;

		              			$Update policy_last
		              	  			Set iroute = (Select iroute From officer Where iofficer = $tmp_iofficer_B )
		              				Where ipolicy = $tmp_ipolicy;
	              	  }
	              }
	              else
	              {
	                    /* �s�W�M��,�Ĥ@�~�LB��,�n�b���q�s�W   memo by sylvia 104.03.12 */
									    /**** 102.12.25 ,
							     	  "�e�@�~�LB��M��"�]�p�U�M�ס^���B�z:�s�W�@������B��A�O��򥻸�ƱqA��ƻs�A�g��N���אּW��M�g��
							     	  �P�_����G���A�榳�M�צ��O�A�B�LB��A�B���Ĥ@�~
						                  �{��H�U�M�׷|�� "�e�@�~�LB��" �����ΡG
						                  Y45�G�ζ�2-6�~�ѵs�I�M��(74)�BY47�G�����Ť�2-6�ѵs�M��(79)�B	Y48�G�ηs2-5�~�ѵs�I�M��(78)�B
						                  Y50�G�ΫH2-5�~�ѵs�I�M��(78)�BY52�G�Ǵ����u�R�@�e�|�v�M��(83)�B	Y53�G�Ǵ����u�R�@�e�|�v�M��II(89)�B
						                  C17�G���ظU�o��(59)			�BC18�G�֪@�M��I(87)
						                  Y62:�ζ��u�����١v�M�� �BY63:DLR�u�����١v�M��

			    						******/
			    						/* step (1):���P�_A����O�A�T�{��M�ץN�� */
			    						if((tmp_iofficer[0] == 'B')&&(equip_cmp(tmp_nequipment,"59") == True))
									    {
									        strcpy(pro_no,"C17");
													IS_1stYear_No_PlyB = 0;

									    }
			    						else if ((tmp_iofficer[0] == 'B')&&(equip_cmp(tmp_nequipment,"87") == True))
									    {
													/* �s�W�֪@�M�� add by sylvia 103.04.17 (1020704005_C3) */
													strcpy(pro_no,"C18");
													IS_1stYear_No_PlyB = 0;  /* �Ĥ@�~�LB�� */

									    }
									    else if ((tmp_iofficer[0] == 'A')&&(equip_cmp(tmp_nequipment,"74") == True))
									    {
			        					if (tmp_Y63_chk < 0)
												{
												    strcpy(pro_no,"Y45");   /* W�g�� */
												}
												else
												{
												    strcpy(pro_no,"Y63");	/* N�g�� DLR�u�����١v�M�� add by sylvia 104.03.10 (1040212008_C1) */
												}
												IS_1stYear_No_PlyB = 0;

			    						}
			    						else if ((tmp_iofficer[0] == 'A')&&(equip_cmp(tmp_nequipment,"78") == True))
									    {
												if (strncmp(tmp_iofficer,"A23",3)==0)
												{
												    strcpy(pro_no,"Y50");
												    IS_1stYear_No_PlyB = 0;
												}
												else if (strncmp(tmp_iofficer,"A10",3)==0)
												{
												    if (tmp_1201_chk<0)
												    {
												        strcpy(pro_no,"Y48"); /* W*�g��*/
												    }
												    else
												    {
												     	strcpy(pro_no,"Y57"); /* H*�g��*/
												    }
												    IS_1stYear_No_PlyB = 0;
												}
											}
			    						else if ((tmp_iofficer[0] == 'A')&&(equip_cmp(tmp_nequipment,"79") == True))
									    {
												strcpy(pro_no,"Y47");
												IS_1stYear_No_PlyB = 0;
									    }
			    						else if ((tmp_iofficer[0] == 'A')&&(equip_cmp(tmp_nequipment,"83") == True))
			    						{
												strcpy(pro_no,"Y52");
												IS_1stYear_No_PlyB = 0;

			    						}
			    						else if ((tmp_iofficer[0] == 'A')&&(equip_cmp(tmp_nequipment,"89") == True))
									    {
												#ifdef PRINTF_FLAG
												printf("-- trace tmp_1101_chk[%ld]\n ",tmp_1101_chk);
												#endif
									     	if (tmp_1101_chk<0)
									     	{
									     	    strcpy(pro_no,"Y53");; /* W*�g��*/
									     	}
									     	else
									     	{
									     	    strcpy(pro_no,"Y58");  /* H*�g��*/
									     	}
												IS_1stYear_No_PlyB = 0;
									    }
			    						else if ((tmp_iofficer[0] == 'A')&&(equip_cmp(tmp_nequipment,"96") == True))
			    						{
												strcpy(pro_no,"Y62");
												IS_1stYear_No_PlyB = 0;   /* �ζ��u�����١v�M�� add by sylvia 104.03.10 (1040212008_C1)*/

			    						}
			    						else if ((tmp_iofficer[0] == 'L')&&(equip_cmp(tmp_nequipment,"114") == True))
									    {
												strcpy(pro_no,"L01");
												IS_1stYear_No_PlyB = 0;   /* ���M�˥ߡu�ѵs�I�R�@�e�|�v�M�� add by sylvia 108.12.16 (1081018008_SC1)*/
									    }

		            			if (IS_1stYear_No_PlyB==0)
		            			{

					                /* step (2): �T�{�T��L������B�� */
					                /* �s�W�֪@�M�׸g��(FS) add by sylvia 103.04.17 (1020704005_C3) */
					                /* ��׸g���ରN�g�� add by sylvia 103.09.01 (1030630002_C1) */
					                /* �s�W�M��Y62(�ζ�������)Y63(DLR������) add by sylvia 104.03.10(1040212008_C1) */
					                /* �s�W�M��L01(���M�W��) add by 061476 108.12.16 (1081018008_SC1) */
					                sprintf(stmt_buf,"SELECT first 1 a.ipolicy FROM %s:policy a, %s:ply_relation b WHERE %s %s %s %s %s %s %s %s %s",
					                FullDBName,FullDBName,
					                " a.ipolicy = b.ipolicy",
					                " AND b.fcard_class = '2' ",
					                " AND (((b.iofficer[1] = 'W' or (b.iofficer[1] = 'H' and b.iofficer[2] not in ('0','1','2')) ) ",
					                " AND  (b.iofficer[7,8] in ('FW','HF','TB','FS') Or b.iofficer[7,9] in ('FWD','EM6','EM5','YJ1','ES1','YFL','YFN'))) ",
					                "       OR (b.iofficer in (select unique iofficer_ori from ca_promote_officer where iofficer_ori[1,1] = 'N' ",
					                "           AND iprmt in ('C17','C18','Y45','Y50','Y48','Y57','Y47','Y52','Y53','Y58','Y62','Y63'))) ",
					                "       OR (b.iofficer[1] = 'L' AND b.iofficer[7] = 'B')) ",
													" AND b.dply_end= ? ",
													" AND a.iengine = ? " );

													#ifdef PRINTF_FLAG
													printf("chk_ply_B[%s]\n", stmt_buf);
													#endif

													$PREPARE chk_ply_B FROM $stmt_buf;
													$EXECUTE chk_ply_B
													   USING $tmp_dply_end,$tmp_iengine;
													#ifdef PRINTF_FLAG
													printf("SQLCODE=[%d]\n",SQLCODE);
													#endif

					                if (SQLCODE == SQLNOTFOUND)
					                {  /* �T�{�L������B�� */

				                    /* step (3): �T�{�e�@�~���Ĥ@�~(�s��) */
				                    icar_age  = (int)(qnext_year_cacu + 0.2 + 0.5);

				                    #ifdef PRINTF_FLAG
				                    printf("Trace -- icar_age = [%d] \n",  icar_age);
				                    #endif
			            					if (qnext_year_cacu <= 1)
			            					{

			                				/* step (4): �M��B��g��N�� */
															$SELECT iofficer_1, lofficer, ioff_chk_bgn, ioff_chk_len, ioff_chk, mlimit
															   INTO $iofficer_1, $iofficer_len, $ioff_ck_bgn, $ioff_ck_len, $ioff_chk, $mlimit
															   FROM ca_promote
															  WHERE iprmt = $pro_no;
															/*
															�ܸg��H��(cmn108)�̥H�U������oB��g��N���G
															�~�Z���(�e�|�X) = �uA��v�g��N�����̷s�~�Z���(�e�|�X)
															�B �g��N��(�Ĥ@�X) = ��W��
															(�� �g��N��(�Ĥ@�X)  = ��H��and �g��N��(�ĤG�X) �D0�B1�B2 )
															�B �g��N��(��x~y�X) = �M�׳]�w���g���ˮ֦r��
															�B �g��N������       = �M�׳]�w���g��N������
															�B �~�Ȩӷ�����       = �M�ץN��
															*/
															/* N�g��i�H��A��g��+�M�ץN����ca_promote_officer�M��Y�i modify by sylvia 103.09.02 (1030630002_C1) */
															if(SQLCODE != SQLNOTFOUND)
															{
															    if ((tmp_iofficer[0]=='B')||(strncmp(pro_no,"Y50",3)==0) )
															    { /* �L���car130�]�w�����ة�Y50�M�ש|���אּH�g��A�G�ݪ������w��H�g�� */

															        iofficer_1[0] = 'H';  iofficer_1[1] = '\0';
															    }

															    /* N�g��ҥ�,����H�g��אּN�g��  modify by sylvia 103.09.02 (1030630002_C1) */
															    if ((strcmp(IsChgNofficer,"Y") == 0) && (strcmp(iofficer_1,"H") == 0))
															    {
																			iofficer_1[0] = 'N';  iofficer_1[1] = '\0';
															    }

															    /* ��A��g����o�̷s�~�Z��� */
															    $Select iquota[1,4] Into $tmp_iquota14
															       From officer Where iofficer = $tmp_iofficer;


															    if (strcmp(iofficer_1,"N") == 0)
															    {/* N�g�쪽���H(A��g��+�M�ץN��)��ca_promote_officer�d�ߧY�i modify by sylvia 103.09.02(1030630002_C1) */
															        sprintf(stmt_buf,"select unique iofficer_ori from ca_promote_officer \
																	     	   where iofficer = '%s' and iprmt='%s' \
																	     	     and iofficer_ori[1,1] = 'N'",tmp_iofficer,pro_no);
															    }
															    else if (strcmp(iofficer_1,"L") == 0)
															    {/* ����˥߱M�ת��g��N�� add by 061476 108.12.19 (1081018008_SC1) */
																		sprintf(stmt_buf, "SELECT iofficer FROM officer \
																			            WHERE iquota[1,4] = '%s' AND iofficer[1] = '%s' \
																			              AND iofficer[%d,%d] = '%s' \
																			              AND length(iofficer) = %d  \
																			              AND sbus_source = '%s'     \
																			              AND iofficer[1,6] = '%s'",
																		tmp_iquota14, iofficer_1, ioff_ck_bgn, (ioff_ck_bgn+ioff_ck_len-1), trim(ioff_chk), iofficer_len, pro_no, tmp_iofficer );
															    }
															    else
															    {
																		sprintf(stmt_buf, "SELECT iofficer FROM officer \
																			            WHERE iquota[1,4] = '%s' AND iofficer[1] = '%s' \
																			              AND iofficer[%d,%d] = '%s' \
																			              AND length(iofficer) = %d  \
																			              AND sbus_source = '%s'",
																		tmp_iquota14, iofficer_1, ioff_ck_bgn, (ioff_ck_bgn+ioff_ck_len-1), trim(ioff_chk), iofficer_len, pro_no );
					    										}

															    $PREPARE pre_getoff FROM $stmt_buf;
															    $DECLARE cur_getoff CURSOR for pre_getoff;
															    $OPEN cur_getoff;
															    $FETCH cur_getoff INTO $tmp_iofficer_B;

															    #ifdef PRINTF_FLAG
															    printf("stmt_buf=[%s] \n", stmt_buf );
															    printf("tmp_iofficer_B=[%s] SQLCODE =[%d]\n", tmp_iofficer_B, SQLCODE );
															    #endif

															    if( (SQLCODE != SQLNOTFOUND)&&(strlen(tmp_iofficer_B)>3) )
															    {

															        /* step (5): �s�W"����B��"�� last��:ply_relation_last�Bpolicy_last�Bply_ins_type_last */
															        #ifdef PRINTF_FLAG
															        printf("INSERTING ply_relation_last(B)\n");
															        #endif

																			$EXECUTE ins_reB USING $tmp_ipolicy;
																			#ifdef PRINTF_FLAG
																			printf("Trace -- SQLCODE = [%d] \n",  SQLCODE);
																			printf("INSERTING policy_last(B)\n");
																			#endif

																			$EXECUTE ins_poB USING $tmp_ipolicy;
																			#ifdef PRINTF_FLAG
																			printf("Trace -- SQLCODE = [%d] \n",  SQLCODE);
																			printf("INSERTING ply_ins_type_last(B)\n");
																			#endif

																			$EXECUTE ins_typeB USING $tmp_ipolicy;
																			#ifdef PRINTF_FLAG
																			printf("Trace -- SQLCODE = [%d] \n",  SQLCODE);
																			#endif

																			strcpy(tmp_ipolicy,trim(tmp_ipolicy));
																			sprintf(tmp_ipolicyB,"%s-B",tmp_ipolicy);
																			#ifdef PRINTF_FLAG
																			printf("Trace -- tmp_ipolicyB = [%s] \n",  tmp_ipolicyB);
																			#endif

					        										/* => ����"����B��"���g��N������A�椧�g��N�� => �����M��B��g��N���ô����� */

																			/* step (6): ��slast��"����B��"���g��N���B���I�N���B�^�k�g��N�� */
																			/*** update ����B�� ���g��N�� ***/

																			/* N�g�쪺���I�N���Τj�v�O�N���O��Ūca_promote_officer��officer �Y�i  modify by sylvia 103.09.02 ---------------*/
																			/* �ζ���B�����I�N�� ���אּ A��g��*/

																			if (tmp_iofficer_B[0] == 'N')
																			{
																			    $select unique a.ibig_office, b.ibigcomp
													   						       into $tmp_ibig_office, $tmp_ibig_comp
													   						       from ca_promote_officer a, officer b
													   						      where a.iofficer_ori = b.iofficer
													   							and a.iofficer_ori = $tmp_iofficer_B
													   							and a.iofficer = $tmp_iofficer
													   							and a.iprmt = $pro_no;
																			}
																			else if (tmp_iofficer_B[0] == 'L')
																			{ /* �s�W�˥߱M�� add by 061476 108.12.16 (1081018008_SC1) */
																			    $select unique ibus_location, ibigcomp
													   					               into $tmp_ibig_office, $tmp_ibig_comp
													   						       from officer
													   						      where iofficer = $tmp_iofficer_B;
																			}
																			else
																			{
																			    if (tmp_iofficer[0]=='A')
																			    {
																			        strcpy(tmp_ibig_office,tmp_iofficer);
																			    }
																			    strcpy(tmp_ibig_comp, " ");  /* H�g��אּ��"�D�j�v"  */

																			}

																			/* ---------------------------------------------------------------------- */

																			$Update ply_relation_last
																          Set iofficer      = $tmp_iofficer_B,
																            	iofficer_prmt = $tmp_iofficer,
																            	ibig_office   = $tmp_ibig_office,
																            	ibig_comp     = $tmp_ibig_comp,
																            	irelative_ply = ' '
																        Where ipolicy       = $tmp_ipolicyB;

						              		        $Update policy_last
						              		            Set iroute = (Select iroute From officer Where iofficer = $tmp_iofficer_B )
						              		          Where ipolicy = $tmp_ipolicyB;

						              		        /* "����B��"���M�����[���� (1140109007_C01) */
						              		        /*$Update ply_ins_type_last
						              		            set provision = ' '
						              		          Where ipolicy = $tmp_ipolicyB;*/

						              		        /* �]B��ۭt�B�@�ߵ�10%�A���e�@�~A��ۭt�B���i�ण�O10% (1081018008_SC1) */
					              		         	$Update ply_ins_type_last
					              		             set mdeduct = 10
					              		           where ipolicy = $tmp_ipolicy
					              		             and iins_type in ('11','211');

		              		         				/* �g���ɨ�l��������᭱�|�A���s�^�� */

		                                 	/* "����B��",�N����A�欰�۶O�B����O11�I�ءA�GB����Ӥ����n�^�kA�����
		                                    ���n�g�J plyAB_chk */
		                                 	iRemark_yn = 0;
		                                 	if (strncmp(pro_no,"C17",3)==0)
		                                 	{   /* ���ظU�o��(59)*/
		                                 		nequ_prem = 2000;
		                                 		strcpy(nequ_name, "���ظU�o��" );
		                                 		iRemark_yn = 0;
		                                 	}
		                                 	else if (strncmp(pro_no,"C18",3)==0)
		                                 	{ /* �֪@�M��I(87) */
		                                 		nequ_prem = 5000;      /* �ˮ�A��O�O��Ǭ����~�ת�A��O�O(������,>=3000;�L�����I��,>=5000,�D�e�@�~��A��O�O,�ȭq�O�O=5000  modify by sylvia 103.04.16 (1020704005_C3) */
		                                 		strcpy(nequ_name, "�֪@" );
		                                 		iRemark_yn = 1;
		                                 	}
		                                 	else if (strncmp(pro_no,"Y45",3)==0)
		                                 	{ /* �ζ�2-6�~�ѵs�I�M��(74) */
		                                 		nequ_prem = 1000;
		                                 		strcpy(nequ_name, "�ζ�2-6�~�ѵs�I" );
		                                 		iRemark_yn = 0;
		                                 	}
		                                 	else if (strncmp(pro_no,"Y47",3)==0)
		                                 	{ /* �����Ť�2-6�ѵs�M��(79) */
		                                 		nequ_prem = 1000;
		                                 		strcpy(nequ_name, "�����Ť�2-6�~�ѵs�I" );
		                                 		iRemark_yn = 0;
		                                 	}
		                                 	else if ((strncmp(pro_no,"Y48",3)==0)||(strncmp(pro_no,"Y57",3)==0))
		                                 	{ /* �ηs2-5�~�ѵs�I�M��(78) */
		                                 		nequ_prem = 1000;
		                                 		strcpy(nequ_name, "�ηs2-5�~�ѵs�I" );
		                                 		iRemark_yn = 0;
		                                 	}
		                                 	else if (strncmp(pro_no,"Y50",3)==0)
		                                 	{ /* �ΫH2-5�~�ѵs�I�M��(78) */
		                                 		nequ_prem = 1000;
		                                 		strcpy(nequ_name, "�ΫH2-5�~�ѵs�I" );
		                                 		iRemark_yn = 0;
		                                 	}
		                                 	else if (strncmp(pro_no,"Y52",3)==0)
		                                 	{ /* �Ǵ����u�R�@�e�|�v�M��(83)  */
		                                 		nequ_prem = 2000;
		                                 		strcpy(nequ_name, "�Ǵ����R�@�e�|�ѵs");
		                                 		iRemark_yn = 0;
		                                 	}
		                                 	else if ((strncmp(pro_no,"Y53",3)==0)||(strncmp(pro_no,"Y58",3)==0))
		                                 	{ /* �Ǵ����u�R�@�e�|�v�M��II(89)*/
		                                 		nequ_prem = 3000;
		                                 		strcpy(nequ_name, "�Ǵ����R�@�e�|�ѵsII");
		                                 		iRemark_yn = 0;
		                                 	}
		                                 	else if (strncmp(pro_no,"Y62",3)==0)
		                                 	{ /* �ζ��u�����M�v�M��(96)*/
		                                 		nequ_prem = 1000;
		                                 		strcpy(nequ_name, "�Τ餭����");
		                                 		iRemark_yn = 0;
		                                 	}
		                                 	else if (strncmp(pro_no,"Y63",3)==0)
		                                 	{ /* DLR�u�����M�v�M��(74)*/
		                                 		nequ_prem = 1000;
		                                 		strcpy(nequ_name, "DLR�R�@�e��");
		                                 		iRemark_yn = 0;
		                                 	}
		                                 	else if (strncmp(pro_no,"L01",3)==0)
		                                 	{ /* ���M�˥ߡu�ѵs�I�R�@�e�|�v */
		                                 		nequ_prem = 3000;
		                                 		strcpy(nequ_name, "���MDLR2-5");
		                                 		iRemark_yn = 0;
		                                 	}
		                                 	strcpy(nequ_comp, " ");
		                                 	oPlyClosed = 0;

		                                 	/* step (7): �g�J plyAB_chk  */
		                                 	$INSERT INTO plyAB_chk
		                                 	 VALUES ($tmp_ipolicy, $tmp_ipolicyB,$tmp_iofficer_B,$nequ_name,$nequ_comp,$nequ_prem, $oPlyClosed, $iRemark_yn, $pro_no);

		                                 	/* �Y�O�����J�p�G�ݱN�s�W������B�� insert ��ca_tmp_no  */
		                                 	if( intopt == 9 || intopt == 25 || intopt == 55)
		                                 	{
		                                     $INSERT INTO newa00:ca_tmp_no VALUES ($tmp_ipolicyB);
		                                 	}

		                                 	IS_1stYear_No_PlyB = 1; /* �аO��"�e�@�~(�Ĥ@�~)�LB��M��"�A�B���oB��g��.... */

					    										}
															    else
															    {
																		 /* �n��ܰT��,�����n�O�d�J�pA����(���X�N���אּ2) (103.06.13�\���q���ק�)  modify by sylvia 103.06.13 */
																		 $INSERT INTO duplic1 VALUES ($tmp_ipolicy,$tmp_iengine,$pro_no,'�e�@�~�LB���A���䤣��i��B��g��N��','2', 'E35',$tmp_iofficer);
																		 continue;
					    										}
															    $CLOSE cur_getoff;
															    $free  cur_getoff;
															}
															else
															{
																/* �n��ܰT��,�����n�O�d�J�pA����(���X�N���אּ2) (103.06.13�\���q���ק�)  modify by sylvia 103.06.13 */
																$INSERT INTO duplic1 VALUES ($tmp_ipolicy,$tmp_iengine,$pro_no,'�e�@�~�LB���A���L���M�׳]�w','2', 'E36',$tmp_iofficer);
																continue;
															}
				    								}
				    								else
												    {
																/* �n��ܰT��,�����n�J�pA���� (103.04.24�\���q���ק�)  modify by sylvia 103.04.25 */
																$INSERT INTO duplic1 VALUES ($tmp_ipolicy,$tmp_iengine,$pro_no,'�e�@�~�LB��A�o�D�Ĥ@�~��','2','E37',$tmp_iofficer);
																continue;
												    }
			        						}
			    						}
								} /* tmp_iofficer[0]=='W' end */
	      		}/* ���N�I end  */

						$WHENEVER SQLERROR GOTO errexit;
            count_num ++;

						if (count_num == 500)
            {
            		$COMMIT WORK;
                $BEGIN WORK;
                count_num = 0;
            }
					}
          $CLOSE ins_ply;
          $FREE  ins_ply;
          $COMMIT WORK;


          /*** �H�U��"�e�@�~��B��"��B��^�kA��B�z" ***/
          /* �u�����s�W�M��, ���ײĤ@�~���LB��, ���q���n�g�@���M�׸��, �H�ѲĤG�~��O�J�p�ϥ�  (memo by sylvia 104.03.12)  */
          if (IS_1stYear_No_PlyB != 1)
          {
	          printf("Processing A�BB policy (�ѵs�I) ....\n");

	          $BEGIN WORK;
	          /* 1010203, �ΫH2-5�~�ѵs�I�M��(ES1)(78)*/
	          /* 1000825, �Υ�2-5�~�ѵs�I�M��(73)(�R1�e4), �ζ�2-6�~�ѵs�I�M��(74)(�R1�e5) */
	          /* 1000825, �ηs2-5�~�ѵs�I�M��(YJ1)(78),�����Ť�2-6�~�ѵs�I�M��(TB)(79)*/
	          /*990319,FWD:���ظU�o��*/
	          /*990319, EM6:�Υ�60�M��(73)(�R1�e5), EM5:�Υ�50�M��(74)(�R1�e4) */
	          /**
	          ES:�ΫH50�BLE30:���MES�BLS:���M��ţ�BUF:�W��50�BYF:50�ǩ_�BDLR50�t�C�BYG�üy50�BYI:YesIdo�t�C
	          SF�BFF:�����ѵs�M��-�A���� �BFW:���׸U�o�� �BDF: �ظs�T�����~�ѵs
	          YCF:�ζ�TWO�O�O, YFL:�ζ�0925�M ,  HF:�s�߮𨮶R�@�e�|
	          YS: �鲣66���� (���O93,�M��Y59) add by sylvia 103.09.03 **/
	          /* �s�WY60(���p10)�BY61(���p20)�M�� add by sylvia 104.03.10 (1040212008_C1) */
	          /* �s�WL01(���M�˥�)�M�� add by 061476 108.12.17 (1081018008_SC1) */
	          #ifdef PRINTF_FLAG
	          printf("�m�ζ�50�ǩ_�n�B�m�ζ�Yes i do�ǩ_�n,�m�ζ��p�աn����SV 555�M�� �����ѵs�I��O��ĳ�I��\n");
	          #endif
	          /* C18�G�֪@�M��I(87)  */
	          sprintf(stmt_buf, " SELECT %s %s %s %s FROM %s:%s %s:%s WHERE %s %s %s %s %s %s %s %s ",
	                            "a.ipolicy, iofficer, iengine, itag, iassured, qnext_year, YEAR(dply_end),a.ibig_office, ",
	                            "a.ibig_office, b.dissue, a.dply_begin,a.iofficer_prmt, a.icard_main, ",
	                            "case when (a.iofficer[1] = 'L' AND a.iofficer[7] = 'B') THEN 'L01' ",
	                            "else nvl((select unique iprmt from ca_promote_officer_P where iofficer_ori = a.iofficer ),' ') end",
	                            FullDBName,"ply_relation a, ",
	                            FullDBName,"policy b ",
	                            "a.ipolicy = b.ipolicy " ,
	                            "AND fcard_class = '2' ",
	                            "AND a.dply_end between ? and ? ",
	                            "AND a.dply_close is not null AND nvl(a.fedr_class,' ') <> '1' ",
	                            "AND (((a.iofficer[1] = 'W' or (a.iofficer[1] = 'H' and a.iofficer[2] not in ('0','1','2')) ) "
	                            "AND (a.iofficer[7,8] in ('LE','LS','UF','YF','YG','YI','RL','SF','FF','FW','DF','HF','BF','NF','TB','FS','YS') "
	                            "  or (a.iofficer[7,10] in ('ES01','YS66')) OR (a.iofficer[8,10] = '555' ) "
	                            "  or (a.iofficer[7,9] in ('GSH','GFH','YCF','YL9','YL5','FWD','EM6','EM5','YJ1','ES1','YFL','YFN') )))",
	                            "  or (a.iofficer in (select iofficer_ori from ca_promote_officer_A where iofficer_ori[1,1] = 'N')) ",
	                            "  or (a.iofficer[1] = 'L' and a.iofficer[7] = 'B')) ",
	                            sSQL );


	          #ifdef PRINTF_FLAG
	          printf("[%s]\n",stmt_buf);
	          #endif

	          $PREPARE PlychkTmp FROM $stmt_buf;
	          $DECLARE PlychkE CURSOR FOR PlychkTmp;
	          $OPEN    PlychkE USING $lDplyEndBgn, $lDplyEndEnd;
	          printf("lDplyEndBgn=[%d]lDplyEndEnd=[%d]\n",lDplyEndBgn,lDplyEndEnd);
	          strcpy(stmpProj," ");
	          for(;;)
	          {
	                $FETCH PlychkE INTO $oipolicy,$oiofficer,$iengine,$itag,$iassured_B,$qnext_year_B,$dply_year_B,$tmp_big_office,
	                                    $oibig_office, $lng_iissue_ym_B, $lng_dply_begin_B, $iofficer_prmt, $icard_main, $stmpProj;

	                if (SQLCODE == SQLNOTFOUND) break;
	                tmpProj = stmpProj;

	                /* 980815, �]���s�Wdbirth ,dissue*/
	                /*960704,�M�ץ���O���~�׼ơA�H(�O�I�ͮĦ~�� - �o�Ӧ~��)/365 �L����i�J�ܾ�� */
	                /*960709�ץ�,�M�ץ���O���~�׼ơA�H qnext_year =(�O�I�ͮĦ~�� - �o�Ӧ~��)/365
	                    ��qnext_year�p�Ʀ�>=0.3�A�h�L����i�J�ܾ�ơA�_�h�˥h�A�Y2��3�J
	                    �Y�p�Ʀ�0.3�~(3.6�Ӥ�)�H�W(�t)�A��i�i�@�~
	                    �G (qnext_year + 0.2) �A�|�ˤ��J�Y�i�A�ӥ|�ˤ��J�h�H+0.5��A�j���ର��Ʊo�� */
	                qnext_year_B    = (int)((lng_dply_begin_B - lng_iissue_ym_B)/365.0 + 0.2 + 0.5); /* �h�~��B��-�o�� */

	                #ifdef PRINTF_FLAG

	                printf("lng_dply_begin_B=[%ld]\n",lng_dply_begin_B);
	                printf("lng_iissue_ym_B =[%ld]\n",lng_iissue_ym_B);
	                printf("qnext_year_B    =[%d ]\n",qnext_year_B);
	                #endif

	                #ifdef PRINTF_FLAG
	                printf("2:oipolicy[%s] iengine=[%s]itag=[%s]\n", oipolicy,iengine,itag);
	                #endif

	                strcpy(iengine, rtrim(iengine));
	                strcpy(itag   , rtrim(itag));
	                liofficer = strlen(trim(oiofficer));

	                OfficerStat[0] = '\0';
	                SelectEquip[0] = '\0';
	                strcpy(IinsTypeStat," AND iins_type in ('11','211')");
	                strcpy(nequ_name, " ");
	                strcpy(nequ_comp, " ");
	                nequ_prem = 1000;
	                Aiequip[0] = '\0';
	                iRemark_yn = 0;
	                /* �t�XN�g��ҥ�,�[�J�M�ץN���P�_  modify by sylvia 103.09.03 */
	                if ((strncmp(oiofficer+(7-1),"YF",2)==0 ) || (strstr(PROJ_YF,tmpProj)))
	                {
	                    /* 50 �ǩ_�t�C */
	                    qnext_year_chk = 5;

	                    if ((((strncmp(oiofficer+(7-1),"YF6",3)==0) ||
	                          (strncmp(oiofficer+(7-1),"YF7",3)==0) ||
	                          (strncmp(oiofficer+(7-1),"YF8",3)==0)) && (liofficer == 9 )) ||
	                        (strstr(tmpProj,"Y30")) || (strstr(tmpProj,"Y31")) ||
	                     (strstr(tmpProj,"Y43")) || (strstr(tmpProj,"Y54")))
	                    {
	                       strcpy(Aiequip, "21");
	                       strcpy(sequip_str,equip_instr("21"));
	                       strcpy(OfficerStat, " AND iofficer[1] in ('A') ");
	                       sprintf(SelectEquip, " AND nequipment[21] in %s ",sequip_str);
	                       strcpy(nequ_name, "DLR50");
	                       strcpy(nequ_comp, "�ζ�");
	                    }
	                    else if (((strncmp(oiofficer+(7-1),"YFB",3)==0) && (liofficer == 9 )) ||
	                              (strstr(tmpProj,"Y40")))
	                    {
	                       strcpy(Aiequip, "69");
	                       strcpy(sequip_str,equip_instr("69"));
	                       strcpy(OfficerStat, " AND iofficer[1] in ('A') ");
	                       sprintf(SelectEquip, " AND nequipment[9] in %s ",sequip_str);
	                       strcpy(nequ_name, "�έ�50(��)");
	                       strcpy(nequ_comp, "�ζ�");
	                    }
	                    else if (((strncmp(oiofficer+(7-1),"YFS",3)==0) && (liofficer == 9 )) ||
	                             (strstr(tmpProj,"Y44")) || (strstr(tmpProj,"Y55")) || (strstr(tmpProj,"Y56")))
	                    {
	                       strcpy(Aiequip, "72");
	                       strcpy(sequip_str,equip_instr("72"));
	                       strcpy(OfficerStat, " AND iofficer[1] in ('A') ");
	                       sprintf(SelectEquip, " AND nequipment[12] in %s ",sequip_str);
	                       strcpy(nequ_name, "DLR60");
	                       strcpy(nequ_comp, "�ζ�");
	                       qnext_year_chk = 6;
	                    }
	                    else if (((strncmp(oiofficer+(7-1),"YFL",3)==0) && (liofficer == 9 )) ||
	                             (strstr(tmpProj,"Y52"))) /* 1020208 */
	                    {
	                       strcpy(Aiequip, "83");
	                       strcpy(sequip_str,equip_instr("83"));
	                       strcpy(OfficerStat, " AND iofficer[1] in ('A') ");
	                       sprintf(SelectEquip, " AND nequipment[23] in %s ",sequip_str);
	                       strcpy(nequ_name, "�Ǵ����R�@�e�|�ѵs");
	                       nequ_prem = 2000;
	                    }
	                    else if (((strncmp(oiofficer+(7-1),"YFN",3)==0) && (liofficer == 9 )) ||
	                             (strstr(tmpProj,"Y53")) || (strstr(tmpProj,"Y58"))) /* 102.12.05 �o�Ӧ~�� >= 2012/04 ��,��II */
	                    {
	                       strcpy(Aiequip, "89");
	                       strcpy(sequip_str,equip_instr("89"));
	                       strcpy(OfficerStat, " AND iofficer[1] in ('A') ");
	                       sprintf(SelectEquip, " AND nequipment[29] in %s ",sequip_str);
	                       strcpy(nequ_name, "�Ǵ����R�@�e�|�ѵsII");
	                       nequ_prem = 3000;
	                    }
	                    else
	                    {
		                   if (liofficer==9 || liofficer==10 ){

		                       strcpy(Aiequip, "21");
		                       strcpy(sequip_str,equip_instr("21"));
		                       strcpy(OfficerStat, " AND iofficer[1] in ('A') ");
		                       sprintf(SelectEquip, " AND nequipment[21] in %s ",sequip_str);
		                       strcpy(nequ_name, " DLR50");
		                       strcpy(nequ_comp, "�ζ�");
		                   }
	                    }
	                }

	                if (((strncmp(oiofficer+(7-1),"YI",2)==0) && (liofficer == 8 )) ||
	                    (strstr(tmpProj,"Y07")))
	                {
	                	strcpy(Aiequip, "22");
	                	qnext_year_chk = 99; /* 102.11.06 �ץͪ��M��*/
	                	strcpy(sequip_str,equip_instr("22"));
	                	strcpy(OfficerStat, " AND iofficer[1] in ('A') ");
	                	sprintf(SelectEquip, " AND nequipment[22] in %s ",sequip_str);
	                	strcpy(nequ_name, "YesIdo");
	                	strcpy(nequ_comp, "�ζ�");
	                }

	                if (((strncmp(oiofficer+(7-1),"YI",2)==0) && (liofficer == 9 )) ||
	                    (strstr(tmpProj,"Y08")) || (strstr(tmpProj,"Y09")) || (strstr(tmpProj,"Y10")))
	                {
	                	 strcpy(Aiequip, "25");
	                	 qnext_year_chk = 99;
	                	 oiofficer8[0] = oiofficer[8];
	                	 oiofficer8[1] = '\0';
	                	 strcpy(sequip_str,equip_instr("25"));
	                	 strcpy(OfficerStat, " AND iofficer[1] in ('A') ");
	                	 sprintf(SelectEquip, " AND nequipment[25] in %s ",sequip_str);
	                	 sprintf(nequ_name, " YesIdo%d", atoi(oiofficer8));
	                	 strcpy(nequ_comp, "�ζ�");
	                }

	                if (((strncmp(oiofficer+(7-1),"ES01",4)==0) && (liofficer == 10 )) ||
	                    (strstr(tmpProj,"Y29")))
	                {
	                	 strcpy(Aiequip, "21");
	                	 qnext_year_chk = 5;
	                	 strcpy(sequip_str,equip_instr("21"));
	                	 strcpy(OfficerStat, " AND iofficer[1] in ('A') ");
	                	 sprintf(SelectEquip, " AND nequipment[21] in %s ",sequip_str);
	                	 strcpy(nequ_name, "�ΫH50" );
	                }

	                if (((strncmp(oiofficer+(7-1),"UF",2)==0) && (liofficer == 8 )) ||
	                    (strstr(tmpProj,"F06")))
	                {
	                	 strcpy(Aiequip, "35");
	                	 qnext_year_chk = 5;
	                	 strcpy(sequip_str,equip_instr("35"));
	                	 strcpy(OfficerStat, " AND iofficer[1] in ('G','F') ");
	                	 sprintf(SelectEquip, " AND nequipment[5] in %s ",sequip_str);
	                	 strcpy(nequ_name, "�W��50" );
	                	 nequ_prem = 2000;
	                }

	                /* 990319, ���ظU�o�ֱM�ײĤ@�~�LB��,��A�榳�M�׵��O */
	                /* 960124, ���׸U�o�ֱM�ײĤ@�~�LB��,��A�榳�M�׵��O */
	                if (((strncmp(oiofficer+(7-1),"FW",2)==0)) ||
	                    (strstr(tmpProj,"C15")) || (strstr(tmpProj,"C17")))
	                {
	                	 strcpy(Aiequip, "59");
	                	 qnext_year_chk = 5;
	                	 strcpy(sequip_str,equip_instr("59"));
	                	 strcpy(OfficerStat, " AND iofficer[1] in ('B') ");
	                	 sprintf(SelectEquip, " AND nequipment[29] in %s ",sequip_str);
	                	 if ((liofficer == 8 )||(strstr(tmpProj,"C15"))){
	                	 	strcpy(nequ_name, "���׸U�o��" );
	                	 }else if (((strncmp(oiofficer+(7-1),"FWD",3)==0)&&(liofficer == 9))||
	                	            (strstr(tmpProj,"C17"))){
	                	 	strcpy(nequ_name, "���ظU�o��" );
	                	 }
	                	 nequ_prem = 2000;
	                }

	                /* 980601,�έ�TWO�O�O ,��1�~:09 or 05�I  ��2~5�~:11�I*/
	                if ((((strncmp(oiofficer+(7-1),"YL9",3)==0)||(strncmp(oiofficer+(7-1),"YL5",3)==0))&& (liofficer == 9 ))||
	                    (strstr(tmpProj,"Y41")))
	                {
	                	strcpy(Aiequip, "70");
	                	qnext_year_chk = 5;
	                	strcpy(sequip_str,equip_instr("70"));
	                	strcpy(OfficerStat, " AND iofficer[1] in ('A') ");
	                	sprintf(SelectEquip, " AND nequipment[10] in %s ",sequip_str);
	                	strcpy(nequ_name, "�έ�TWO�O�O");
	                	nequ_prem = 1000;
	                }
	                /* 990319, �Υ�60�M��(73)(�R1�e5), �Υ�50�M��(74)(�R1�e4) */
	                /* 1000825, �Υ�2-5�~�ѵs�I�M��(73)(�R1�e4), �ζ�2-6�~�ѵs�I�M��(74)(�R1�e5) */
	                /* 1020208 �s�W �C�M �۶� �s��*/
	                if (((strncmp(oiofficer+(7-1),"EM",2)==0) && (liofficer == 9 )) ||
	                    (strstr(tmpProj,"Y45")) || (strstr(tmpProj,"Y46")))
	                {
	                	 if ((oiofficer[8]=='6')||(strstr(tmpProj,"Y45"))){
	                   	     strcpy(Aiequip, "74");
	                         qnext_year_chk = 6;
	                         strcpy(sequip_str,equip_instr("74"));
	                         sprintf(SelectEquip, " AND nequipment[14] in %s ",sequip_str);
	                         if (strncmp(iofficer_prmt,"A21",3)==0){
	                            strcpy(nequ_name, "�ζ�2-6�~�ѵs�I" );
	                         }else if (strncmp(iofficer_prmt,"A02",3)==0){
	                         	strcpy(nequ_name, "�C�M2-6�~�ѵs�I" );
	                         }else if (strncmp(iofficer_prmt,"A01",3)==0){
	                         	strcpy(nequ_name, "�۶�2-6�~�ѵs�I" );
	                         }else if (strncmp(iofficer_prmt,"A25",3)==0){
	                         	strcpy(nequ_name, "�s��2-6�~�ѵs�I" );
	                         }

	                	 }else if ((oiofficer[8]=='5')||(strstr(tmpProj,"Y46"))){
	                   	     strcpy(Aiequip, "73");
	                         qnext_year_chk = 5;
	                         strcpy(sequip_str,equip_instr("73"));
	                         sprintf(SelectEquip, " AND nequipment[13] in %s ",sequip_str);
	                         strcpy(nequ_name, "�Υ�2-5�~�ѵs�I" );
	                	 }
	                     strcpy(OfficerStat, " AND iofficer[1] in ('A') ");
	                     nequ_prem = 1000;
	                     strcpy(nequ_comp, "");
	                }

	                /* 1000825, �ηs2-5�~�ѵs�I�M��(YJ1)(78)*/
	                if (((strncmp(oiofficer+(7-1),"YJ1",3)==0) && (liofficer == 9 )) ||
	                    (strstr(tmpProj,"Y48")) || (strstr(tmpProj,"Y49")) ||
	                    (strstr(tmpProj,"Y57")))
	                {
	               	     strcpy(Aiequip, "78");
	                     qnext_year_chk = 5;
	                     strcpy(sequip_str,equip_instr("78"));
	                     sprintf(SelectEquip, " AND nequipment[18] in %s ",sequip_str);

	                     if (strncmp(iofficer_prmt,"A10",3)==0){
	                         strcpy(nequ_name, "�ηs2-5�~�ѵs�I" );
	                     }else if (strncmp(iofficer_prmt,"A62",3)==0){
	                     	 strcpy(nequ_name, "�ηs�Ť�2-5�~�ѵs�I" );
	                     }
	                     strcpy(OfficerStat, "AND iofficer[1] in ('A')");
	                     nequ_prem = 1000;
	                     strcpy(nequ_comp, "");
	                }
	                /* 1000825, �����Ť�2-6�~�ѵs�I�M��(TB)(79)*/
	                if (((strncmp(oiofficer+(7-1),"TB",3)==0) && (liofficer == 8 )) ||
	                    (strstr(tmpProj,"Y47")))
	                {
	               	     strcpy(Aiequip, "79");
	                     qnext_year_chk = 6;
	                     strcpy(sequip_str,equip_instr("79"));
	                     sprintf(SelectEquip, " AND nequipment[19] in %s ",sequip_str);
	                     strcpy(nequ_name, "�����Ť�2-6�~�ѵs�I" );
	                     strcpy(OfficerStat, " AND iofficer in ('A') ");
	                     nequ_prem = 1000;
	                     strcpy(nequ_comp, "");
	                }

	                /* 1010203, �ΫH2-5�~�ѵs�I�M��(ES1)(78)*/
	                if (((strncmp(oiofficer+(7-1),"ES1",3)==0) && (liofficer == 9 )) ||
	                    (strstr(tmpProj,"Y50")))
	                {
	               	     strcpy(Aiequip, "78");
	                     qnext_year_chk = 5;
	                     strcpy(sequip_str,equip_instr("78"));
	                     sprintf(SelectEquip, " AND nequipment[18] in %s ",sequip_str);

	                     if (strncmp(iofficer_prmt,"A23",3)==0){
	                         strcpy(nequ_name, "�ΫH2-5�~�ѵs�I" );
	                     }
	                     strcpy(OfficerStat, "AND iofficer[1] in ('A')");
	                     nequ_prem = 1000;
	                     strcpy(nequ_comp, "");
	                }

	                /* 1020208 */
	                if (((strncmp(oiofficer+(7-1),"YS66",4)==0) && (liofficer == 10 )) ||
	                    (strstr(tmpProj,"Y51")))
	                {
	               	     strcpy(Aiequip, "81");
	                     qnext_year_chk = 6;
	                     strcpy(sequip_str,equip_instr("81"));
	                     sprintf(SelectEquip, " AND nequipment[21] in %s ",sequip_str);
	                     strcpy(nequ_name, "�ζ�66�j��" );
	                     strcpy(OfficerStat, "AND iofficer[1] in ('A')");
	                     nequ_prem = 1000;
	                     strcpy(nequ_comp, "");
	                }


	                /* �֪@�M��(C18,���O87) add by sylvia 103.04.16 (1020704005_C3) */
	                if (((strncmp(oiofficer+(7-1),"FS",2)==0) && (liofficer == 8 )) ||
	                    (strstr(tmpProj,"C18")))
	                {
	               	     strcpy(Aiequip, "87");
	                     qnext_year_chk = 5;
	                     strcpy(sequip_str,equip_instr("87"));
	                     sprintf(SelectEquip, " AND nequipment[27] in %s ",sequip_str);
	                     strcpy(nequ_name, "�֪@" );
	                     strcpy(OfficerStat, "AND iofficer[1] in ('B')");
	                     nequ_prem = 5000;
	                     strcpy(nequ_comp, "");
	                     iRemark_yn = 1;
	                }

	                /* �鲣66���� (Y59,���O93) add by sylvia 103.09.03 */
	                if (((strncmp(oiofficer+(7-1),"YS",2)==0) && (liofficer != 10 )) ||
	                    (strstr(tmpProj,"Y59")))
	                {
	               	     strcpy(Aiequip, "93");
	                     qnext_year_chk = 6;
	                     strcpy(sequip_str,equip_instr("93"));
	                     sprintf(SelectEquip, " AND nequipment[3] in %s ",sequip_str);
	                     strcpy(nequ_name, "�鲣66����" );
	                     strcpy(OfficerStat, "AND iofficer[1] in ('A')");
	                     nequ_prem = 1000;
	                     strcpy(nequ_comp, "");
	                }

	                /* ���p10 (Y60,���O94) add by sylvia 104.03.10 */
	                if (strstr(tmpProj,"Y60"))
	                {
	                     strcpy(Aiequip, "94");
	                     qnext_year_chk = 1;
	                     strcpy(sequip_str,equip_instr("94"));
	                     sprintf(SelectEquip, " AND nequipment[4] in %s ",sequip_str);
	                     strcpy(nequ_name, " " );
	                     strcpy(OfficerStat, "AND iofficer[1] in ('A')");
	                     nequ_prem = 1000;
	                     strcpy(nequ_comp, "");
	                }

	                /* ���p20 (Y61,���O95) add by sylvia 104.03.10 */
	                if (strstr(tmpProj,"Y61"))
	                {
                             strcpy(Aiequip, "95");
	                     qnext_year_chk = 2;
	                     strcpy(sequip_str,equip_instr("95"));
	                     sprintf(SelectEquip, " AND nequipment[5] in %s ",sequip_str);
	                     strcpy(nequ_name, "���p20" );
	                     strcpy(OfficerStat, "AND iofficer[1] in ('A')");
	                     nequ_prem = 1000;
	                     strcpy(nequ_comp, "");
	                }

	                /* �ζ������� (Y62,���O96) add by sylvia 104.03.10 */
	                if (strstr(tmpProj,"Y62"))
	                {
                             strcpy(Aiequip, "96");
	                     qnext_year_chk = 6;
	                     strcpy(sequip_str,equip_instr("96"));
	                     sprintf(SelectEquip, " AND nequipment[6] in %s ",sequip_str);
	                     strcpy(nequ_name, "�Τ餭����" );
	                     strcpy(OfficerStat, "AND iofficer[1] in ('A')");
	                     nequ_prem = 1000;
	                     strcpy(nequ_comp, "");
	                }

	                /* DLR�R�@�e�� (Y63,���O74) add by sylvia */
	                if (strstr(tmpProj,"Y63"))
	                {
                             strcpy(Aiequip, "74");
	                     qnext_year_chk = 6;
	                     strcpy(sequip_str,equip_instr("74"));
	                     sprintf(SelectEquip, " AND nequipment[14] in %s ",sequip_str);
	                     strcpy(nequ_name, "DLR�R�@�e��" );
	                     strcpy(OfficerStat, "AND iofficer[1] in ('A')");
	                     nequ_prem = 1000;
	                     strcpy(nequ_comp, "");
	                }

	                /* ���M�˥� �ѵs�I�R�@�e�| (L01,���O114) add by 061476 108.12.17 */
	                if (strstr(tmpProj,"L01"))
	                {
                             strcpy(Aiequip, "114");
	                     qnext_year_chk = 5;
	                     strcpy(sequip_str,equip_instr("114"));
	                     sprintf(SelectEquip, " AND nequipment[24] in %s ",sequip_str);
	                     strcpy(nequ_name, "���MDLR2-5" );
	                     strcpy(OfficerStat, "AND iofficer[1] in ('L')");
	                     nequ_prem = 3000;
	                     strcpy(nequ_comp, "");
	                }

	                /* TAC�M�� �ѵs�I�ذe�@�~ (Y64,���O117) add by 061476 */
	                if (strstr(tmpProj,"Y64"))
	                {
                             strcpy(Aiequip, "117");
	                     qnext_year_chk = 1;
	                     strcpy(sequip_str,equip_instr("117"));
	                     sprintf(SelectEquip, " AND nequipment[27] in %s ",sequip_str);
	                     strcpy(nequ_name, "TAC�M��" );
	                     strcpy(OfficerStat, "AND iofficer[1] in ('A')");
	                     nequ_prem = 1000;
	                     strcpy(nequ_comp, "");
	                }


	                /* 960628,�W�L�M�צ~�סA����ĳ��O�F */
	                if( qnext_year_B >= qnext_year_chk -1 )
	                {
	                     #ifdef PRINTF_FLAG
	                     puts("�W�L�M�צ~��");
	                     #endif
	                     oPlyClosed = 1;
	                     nequ_name[0]='\0';
	                }else{
	                     oPlyClosed = 0;
	                }

	                if (iRemark_yn != 1) iRemark_yn = 0;

	                SelectStat[0] = '\0';
	                if ((strlen(iengine)>2))
	                {
	                     sprintf(SelectStat,"AND iengine = '%s' ",iengine);
	                }
	                else if ((strlen(itag)>2))
	                {
	                     sprintf(SelectStat,"AND itag = '%s' ",itag);
	                }

	                flag_YF = 0;

	                /* �HB��Ҹ�icard_main�d��A��O���� modify by sylvia 105.06.13 (1050219003_C1) */
	                strcpy(Aipolicy,"");
	                if (strlen(icard_main) > 6)
	                {
	                    $select ipolicy into $Aipolicy
	                       from card
	                      where icard = $icard_main;
	                }
	                if (SQLCODE == SQLNOTFOUND)
	                    strcpy(Aipolicy,"");
	                else
	                    strcpy(Aipolicy, trim(Aipolicy));

	                /* �ΤW�����M�ױ����A��A�H�K�N11�I�ئ^�kA������ɤ�(ply_ins_type_last)*/
	                /* for( iTmp = 0; iTmp < count_db; iTmp++) */
	                if (strlen(Aipolicy) >= 13)
	                {
	                    strcpy(sFullDB, get_car_full_dbname(Aipolicy));
	                    strcpy(sFullDB, trim(sFullDB));

	                    #ifdef PRINTF_FLAG
	                    puts("----------------------------------------------------------------------");
	                    printf("dply_year_B[%s], OfficerStat[%s], SelectStat[%s], SelectEquip[%s]\n",
	                	   dply_year_B, OfficerStat, SelectStat, SelectEquip);
	                    #endif
	                    strcpy(fedr_class_A," ");
	                    /* 970416, �]�L��ɥi��|�������O�A������O���󮳱�SelectEquip */
	                    sprintf(stmt_buf, "SELECT a.ipolicy,c.nequipment, c.iassured, a.iofficer, \
	                                          a.mdmg_prem+a.mlia_prem, month(a.dply_end)-month(a.dply_begin), \
	                                          day(a.dply_end)-day(a.dply_begin),nvl(a.fedr_class,' ') \
	                                     FROM %s:ply_relation a, %s:policy c \
	                                    WHERE a.ipolicy = c.ipolicy  AND fcard_class = '2' \
	                                      AND a.iresource != 'E' \
	                                      AND YEAR(a.dply_end) = %s %s %s AND MONTH(a.dply_end)=%d and a.ipolicy = '%s' ",
	                    sFullDB, sFullDB, dply_year_B, OfficerStat, SelectStat,iplymonth,Aipolicy);

	                    #ifdef PRINTF_FLAG
	                    printf("stmt_buf[%s]\n", stmt_buf);
	                    #endif

	                    $PREPARE ABcheckTmp1 FROM $stmt_buf;
	                    $DECLARE ABcheck1_cur CURSOR FOR ABcheckTmp1;
	                    $OPEN    ABcheck1_cur;
	                    for(;;)
	                    {
	                         $FETCH ABcheck1_cur INTO $Aipolicy, $Anequipment, $iassured_A, $Aiofficer, $mpremium,
	                                                  $iMonth, $iDay, $fedr_class_A;
	                         if (SQLCODE == SQLNOTFOUND)
	                         {

	                             flag_YF = 0;
	                             break;
	                         }

	                         if (fedr_class_A[0]=='1')
	                         { /* A��w���P */

	                             flag_YF = 3;
	                             break;
	                         }

	                         if (equip_cmp(Anequipment,Aiequip) == False)
	                         { /*�D�L��,�B������A��L���O*/

	                             flag_YF = 3;
	                             break;
	                         }

	                         /** �O��id���P(�L��)�A�hB�椣�^�k�ܦ�A��A�礣�HB��X��O�� */
	                         if( strcmp(iassured_A, iassured_B) != 0 )
	                         {

	                         	if ((strncmp(oiofficer+(7-1),"FW",2)!=0)||
	                         	    ((!(strstr(tmpProj,"C15"))) && (!(strstr(tmpProj,"C17")))))
	                         	{/*  ���׸U�o�֥i�L�� */

		                            flag_YF = 2;

		                            #ifdef PRINTF_FLAG
		                            printf("flag_YF[%d]\n", flag_YF);
		                            #endif

		                            break;
	                                }
	                         }


	                         mins_premium_x = 0; mdamage_cover = 0;

			         						 sprintf(stmt_buf, " SELECT sum( mdamage_cover),sum(mins_premium) "
			           	           								 "   FROM %s:ply_ins_type "
			                           						 "  WHERE ipolicy = '%s' ", sFullDB, Aipolicy);

	                         $PREPARE prep_cover FROM $stmt_buf;
	                         $EXECUTE prep_cover INTO $mdamage_cover,$mins_premium_x;

	                         if( mdamage_cover == 0)
	                         { /* A��O�B==0(�h�O)�A�hB�椣�^�k�ܦ�A��A�礣�HB��X��O�� */

	                             flag_YF = 3;
	                             break;
	                         }

	                         if (qnext_year_B>=1)
	                         {  /* �ĤG�~��O�~���n�ˮ� */
			                         if( mins_premium_x < nequ_prem)
			                         { /* A��O�O���F�̧C�з�(�]�����h�O)�A�hB�椣�^�k�ܦ�A��A�礣�HB��X��O�� */

			                             flag_YF = 3;
			                             break;
			                         }
		                 			 }

	                         /** ���^�k�A�p�⧹����A�R�� **/
	                         /** flag_YF = 1, B�榳���A��, 11�I�ئ^�kA�� **/
	                         /** flag_YF = 0, B��䤣��A��, B�氵��O     **/
	                         /** flag_YF = 2, �L��A���B�z     **/
	                         /** flag_YF = 3, ��L���p,���B�z (�]���H B�氵��O)   **/

	                         $WHENEVER SQLERROR CONTINUE;

	                         sprintf(stmt_buf, " INSERT INTO ply_ins_type_last ( \
	                                               ipolicy, iins_type, minjured_cover, mdeath_cover, mdamage_cover, mdeduct, \
	                                               mins_premium, mpure_prem, qserial, fedr_status, dendorse, dedr_begin, dedr_end, \
	                                               iendorse, pcommission, mcommission, pagent, magent, pdiscount, mdiscount, \
	                                               drate_ym, mprem, iproduct, ipaid_base, qday, mexpense, mexp_disc, provision, pcar_price \
	                                           ) SELECT '%s', %s %s %s %s %s FROM %s:%s WHERE %s %s %s",
	                                           Aipolicy,
	                                           "iins_type, minjured_cover, mdeath_cover, mdamage_cover, mdeduct,",
	                                           "mins_premium, mpure_prem, qserial, fedr_status, dendorse, dedr_begin,",
	                                           "dedr_end, iendorse,",
	                                           "pcommission, mcommission, pagent, magent, pdiscount, mdiscount,",
	                                           "drate_ym, mprem, iproduct, ipaid_base, qday, mexpense, mexp_disc, provision, pcar_price ",
	                                           sFullDB, "ply_ins_type ",
	                                           " ipolicy = ? ",
	                                           " AND mdamage_cover > 0 ",
	                                           IinsTypeStat);
	                         #ifdef PRINTF_FLAG
	                         printf("stmt_buf[%s]\n", stmt_buf);
	                         #endif

													 $PREPARE InsC_cur FROM $stmt_buf;
													 $EXECUTE InsC_cur USING :oipolicy;


	                         /* A�榳�M�פ]��11�I�خɡA�|����-239�A���n�����M�ץ��~��B�z */
													 if ((sqlca.sqlerrd[2] > 0)||(SQLCODE == -239))
													 {

				     									flag_YF = 1;

												      /* 102.12.25 ,B��n�O�H�쥻�O"�g�P��"(car152)�A�אּ�ϥ�A��n�O�H*/
												      $Select iapplicant ,napplicant ,apayment_zip ,apayment ,fapplicant ,fsex_appl ,dbirth_appl ,itel_appl ,ndeputy_appl ,nrelation_appl
																 Into $iapplicant ,$napplicant ,$apayment_zip ,$apayment ,$fapplicant ,$fsex_appl ,$dbirth_appl ,$itel_appl ,$ndeputy_appl ,$nrelation_appl
																 From policy_last
												        Where ipolicy = $Aipolicy;

															$Update policy_last
												         set iapplicant      =  $iapplicant    ,
												             napplicant      =  $napplicant    ,
												             apayment_zip    =  $apayment_zip  ,
												             apayment        =  $apayment      ,
												             fapplicant      =  $fapplicant    ,
												             fsex_appl       =  $fsex_appl     ,
												             dbirth_appl     =  $dbirth_appl   ,
												             itel_appl       =  $itel_appl     ,
												             ndeputy_appl    =  $ndeputy_appl  ,
												             nrelation_appl  =  $nrelation_appl
												       Where ipolicy = $oipolicy;


			                     		/** plyAB_chk ����Ʀb�J�p������A�|�N11�I�اR�� **/
			                     		strcpy(pro_no,tmpProj);
			                     		$INSERT INTO plyAB_chk
			                      	 VALUES ($Aipolicy, $oipolicy,$oiofficer,$nequ_name,$nequ_comp,$nequ_prem, $oPlyClosed, $iRemark_yn, $pro_no);

				             					#ifdef PRINTF_FLAG
			                     			printf("INSERT plyAB_chk Aipolicy[%s],Bipolicy[%s]pro_no=[%s]\n",Aipolicy,oipolicy,pro_no);
			                     		#endif
				 									}

													#ifdef PRINTF_FLAG
	                         printf("flag_YF[%d]\n", flag_YF);
	                         #endif
	                         if (flag_YF != 0 ) break;

	                    }
	                    $CLOSE  ABcheck1_cur;
	                    $CLOSE  prep_cover;
	                    $FREE   prep_cover;

	                    #ifdef PRINTF_FLAG
	                    printf("flag_YF[%d]\n", flag_YF);
	                    #endif


	                    if (flag_YF != 0)
	                    {                        /* �����A�� */
	                        if(flag_YF != 1 || oPlyClosed==1 )
	                        {  /* ���OA��w���P�h�O�B�L�� �� �O�O���F�M�׼зǩαM�פw��� �A�hB�椣����O�� */

	                    	    $Delete From ply_ins_type_last Where ipolicy = $oipolicy;
	                    	    $Delete From policy_last Where ipolicy = $oipolicy;
	                    	    $Delete From ply_relation_last Where ipolicy = $oipolicy;
	                    	    /* break; */
	                        }
	                    }
	                }
	          }

	          $CLOSE PlychkE;
	          $FREE PlychkE;

	          $COMMIT WORK;
					}
     	}
			if( intopt == 55 )
     	{
         $CLOSE sdb_cur55;
         $FREE  sdb_cur55;
     	}
     	else
     	{
         $CLOSE sdb_cur;
         $FREE  sdb_cur;
     	}

			/* ��j��ĳ47�I�سW�h�վ�: (step1) ��X�����j���I���p���ťժ��O��  add by sylvia 105.07.18 (1050704006_C1) */
     	if(( intopt == 9 )||( intopt == 25) || (intopt == 55))
     	{
      	$select a.ipolicy, b.itag, b.iassured, a.dply_end
           from ply_relation_last a, policy_last b
          where a.ipolicy = b.ipolicy
            and a.fcard_class = '1' and nvl(a.irelative_ply,' ') = ' '
            and nvl(a.fedr_class,' ') <> '1'
            and a.icar_type in ('01','02','32','34')
            and a.dply_end between $lDplyEndBgn and $lDplyEndEnd
            and a.ipolicy in (select ipolicy from newa00:ca_tmp_no )
           into temp tp_step1 with no log;
     	}else {
      	$select a.ipolicy, b.itag, b.iassured, a.dply_end
           from ply_relation_last a, policy_last b
          where a.ipolicy = b.ipolicy
            and a.fcard_class = '1' and nvl(a.irelative_ply,' ') = ' '
            and nvl(a.fedr_class,' ') <> '1'
            and a.icar_type in ('01','02','32','34')
            and a.dply_end between $lDplyEndBgn and $lDplyEndEnd
           into temp tp_step1 with no log;
			}

     /* ��j��ĳ47�I�سW�h�վ�: (step1) �H [����+ID] �d�����e��G�Ӥ몺���N�I
        ��:�j���I����鬰1051012 �d�O�_�������b 105/08/01-105/12/31 �P[����+ID] �����N�I�O��
            add by sylvia 105.07.18 (1050704006_C1) */
     $select first 1 add_months(date($lDplyEndBgn),-2),  add_months(date($lDplyEndBgn),3)-1
       into $dbegin47, $dend47
       from car_code;

     $DECLARE sdb_cur47 CURSOR for
       SELECT branch
         INTO $xBranch
         FROM servertbl
        WHERE branch <> 'S1';
     $OPEN sdb_cur47;
     for(;;)
     {
        $FETCH sdb_cur47;
        if (SQLCODE == SQLNOTFOUND) break;

        strcpy(FullDBName,get_full_dbname(xBranch));
        sprintf(stmt_buf, " insert into wk_policy_302 \
                            select a.ipolicy, b.ipolicy, a.dply_end \
                              from tp_step1 a, %s:ply_relation b, %s:policy c \
                             where b.ipolicy = c.ipolicy \
                               and a.itag = c.itag and a.iassured = c.iassured \
                               and b.dply_end between '%s' and '%s' \
                               and b.fcard_class = '2' and nvl(b.fedr_class,' ') <> '1' \
                               and b.iofficer[1,1] not in ('W','N') \
                               and not (b.iofficer[1] = 'L' and b.iofficer[7] = 'B') \
                               and b.icar_type in ('01','02','32','34') \
                               and b.dpolicy is not null \
                               and b.dply_close is not null  ",
                FullDBName, FullDBName, dbegin47, dend47);

         $PREPARE wk_policy FROM $stmt_buf;
         $EXECUTE wk_policy ;
     }
     $CLOSE sdb_cur47;
     $FREE sdb_cur47;

     /* ��j��ĳ50/149�I�سW�h�վ�P47�I�ءA����ӫe���Ӥ���
        add by 061476 108.08.21 (1080710001_SC1) */
     if(( intopt == 9 )||( intopt == 25) || (intopt == 55))
     {
        $select a.ipolicy, b.itag, b.iassured, a.dply_end
           from ply_relation_last a, policy_last b
          where a.ipolicy = b.ipolicy
            and a.fcard_class = '1' and nvl(a.irelative_ply,' ') = ' '
            and nvl(a.fedr_class,' ') <> '1'
            and a.icar_type not in ('01','02','32','34','35')
            and a.dply_end between $lDplyEndBgn and $lDplyEndEnd
            and a.ipolicy in (select ipolicy from newa00:ca_tmp_no )
           into temp tp_step2 with no log;
     }else {
        $select a.ipolicy, b.itag, b.iassured, a.dply_end
           from ply_relation_last a, policy_last b
          where a.ipolicy = b.ipolicy
            and a.fcard_class = '1' and nvl(a.irelative_ply,' ') = ' '
            and nvl(a.fedr_class,' ') <> '1'
            and a.icar_type not in ('01','02','32','34','35')
            and a.dply_end between $lDplyEndBgn and $lDplyEndEnd
           into temp tp_step2 with no log;
     }

     $DECLARE sdb_cur50 CURSOR for
       SELECT branch
         INTO $xBranch
         FROM servertbl
        WHERE branch <> 'S1';
     $OPEN sdb_cur50;
     for(;;)
     {
        $FETCH sdb_cur50;
        if (SQLCODE == SQLNOTFOUND) break;

        strcpy(FullDBName,get_full_dbname(xBranch));
        sprintf(stmt_buf, " insert into wk_policy_302_50 \
                            select a.ipolicy, b.ipolicy, a.dply_end \
                              from tp_step2 a, %s:ply_relation b, %s:policy c \
                             where b.ipolicy = c.ipolicy \
                               and a.itag = c.itag and a.iassured = c.iassured \
                               and b.dply_end between '%s' and '%s' \
                               and b.fcard_class = '2' and nvl(b.fedr_class,' ') <> '1' \
                               and b.iofficer[1,1] not in ('W','N') \
                               and not (b.iofficer[1] = 'L' and b.iofficer[7] = 'B') \
                               and b.icar_type not in ('01','02','32','34','35') \
                               and b.dpolicy is not null \
                               and b.dply_close is not null  ",
                FullDBName, FullDBName, dbegin47, dend47);

         $PREPARE wk_policy FROM $stmt_buf;
         $EXECUTE wk_policy ;
     }
     $CLOSE sdb_cur50;
     $FREE sdb_cur50;

     /* $set explain off; */
     return TRUE;
errexit:
     printf("12669:sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
     $ROLLBACK WORK;
     return SQLCODE;
}

char* splace(cStr,iLen,iDir)
char cStr[100];
int  iLen;
int  iDir;
{
     int  iTmplen;
     int  iSpc,i;
     char cSpc[100];
     char cRtn[100];

     strcpy(cStr,trim(cStr));
     iTmplen = strlen(cStr);
     iSpc = iLen - iTmplen;

     for(i=0;i<iSpc;i++){
         cSpc[i] = ' ';
     }
     cSpc[iSpc] = '\0';

     if (iDir == 1){
         strcpy(cRtn,cStr);
         strcat(cRtn,cSpc);
     }else{
         strcpy(cRtn,cSpc);
         strcat(cRtn,cStr);
     }
     #ifdef PRINTF_FLAG
     printf("cRtn[%s]\n",cRtn);
     #endif
     return cRtn;
}

char *sLastChinese(sStrTmp,iStrLen)
char *sStrTmp;
int  iStrLen;
{
int  iTrueLen;
int  i,x;
     iTrueLen = strlen(rtrim(sStrTmp));

     if (iStrLen > iTrueLen) return sStrTmp;
     sStrTmp[iStrLen] = '\0';

     for(i = 0; i< iStrLen; i++){
         if ((int)(sStrTmp[i]) >= 128){
             x = i;
             i++;
         }
     }
     if ((iStrLen - 1) == x) {
         sStrTmp[x] = '\0';
     }
     return sStrTmp;
}

/* ���ظg�P������ */
int get_fb_data()
{
    char     *bp;
    FILE   *fp;
    int     i,j,k,m,n,qcount,flen,len1,icnt,rc;
    char    filename[200],tmp_str1[20],sApHome[31];
    $double  tmp_price1,tmp_price2,qpt,qcylinder;  /* �Ʈ�q�X�ܤp���I2�� (1080902001_SC3) */
    $int    idrunk,qpro_month,ipro_year;
    $char   fassured[2], fsex[2],fapplicant[2], fsex_appl[2], fpt[2],
            nbrand_abbr[13], ibigcomp[2], ibus_location[11], iresource[2],
            ileader[11], ibranch[3], iquota[7], iupcomp[2], iroute[21],
            irate_type[2], iroute_comm[4], bzfrom[3], icomm_obj[11],fcard_class[2];
    $char   iins_type[7],nequipment[31];
    $int    minjured_cover, mdeath_cover, mdamage_cover, mdeduct, mins_premium,
            qday,daily_pay, tmp_int;
    $WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT ;

    rc = getApHome(sApHome);

    /* ��temp table */
    $create temp table estimate_fb (
        icard           varchar(20) default ' ',    --  1 �d��
        fcard_class     char(1) default ' ',        --  2 �j��/���N�O
        ipolicy         varchar(20) default ' ',    --  3 �O�渹
        dply_begin      date,                       --  4 �O�I�_��
        dply_end        date,                       --  5 �O�I����
        dissue          date,                       --  6 �o�Ӥ�
        ipro_year       int,                        --  7 �s�y�~��
        ibrand          char(8) default ' ',        --  8 �t���N��
        icar_type       char(2) default ' ',        --  9 ����
        iengine         varchar(25) default ' ',    -- 10 ������
        itag            varchar(12) default ' ',    -- 11 ����
        mcar_price      decimal(5,1) ,              -- 12 ����(�U��)
        mequipment      decimal(5,1),               -- 13 �t�ƻ�(�U��)
        iassured        char(12) default ' ',       -- 14 �Q�O�HID
        nassured        varchar(90) default ' ',    -- 15 �Q�O�H�m�W
        dbirth          date,                       -- 16 �Q�O�H�ͤ�
        fmarriage       char(1) default ' ',        -- 17 �B�ê��A
        assured         varchar(120) default ' ',   -- 18 �Q�O�H�p���a�}
        itel            varchar(20) default ' ',    -- 19 �Q�O�H�q��
        ndeputy_assured varchar(50) default ' ',    -- 20 �Q�O�H���N���H
        iapplicant      varchar(12) default ' ',    -- 21 �n�O�HID
        napplicant      varchar(90) default ' ',    -- 22 �n�O�H�m�W
        dbirth_appl     date,                       -- 23 �Q�O�H�ͤ�
        aapplicant      varchar(120) default ' ',   -- 24 �n�O�H�p���a�}
        itel_appl       varchar(20) default ' ',    -- 25 �n�O�H�q��
        ndeputy_appl    varchar(40) default ' ',    -- 26 �n�O�H���N���H
        nrelation_appl  varchar(40) default ' ',    -- 27 �n�O�H�P�Q�O�I�H���Y
        nbig_office     varchar(20) default ' ',    -- 28 ���Ӿ��I
        ibig_sales      varchar(20) default ' ',    -- 29 ������~���N��
        nbig_sales      varchar(20) default ' ',    -- 30 ������~���m�W
        iofficer        char(10)    default ' ',    -- 31 �g��N��
        iquery_num      varchar(20) default ' ',    -- 32 �j���I�d�ߧǸ�
        comp_line       char(5)  default ' ',       -- 33 �j���I�ż�
        qdrunk_driving  int     default 0,          -- 34 �s�r����
        irelative_ply   char(20),                   -- 35 ���p�O�渹
        fassured        char(1) default ' ',        -- 36 �Q�O�H�ʽ�
        fsex            char(1) default ' ',        -- 37 �Q�O�H�ʧO
        fapplicant      char(1) default ' ',        -- 38 �n�O�H�ʽ�
        fsex_appl       char(1) default ' ',        -- 39 �n�O�H�ʧO
        qpt             decimal(4,1),               -- 40 �H��/����
        fpt             char(1),                    -- 41 ���
        qcylinder       decimal(7,2),               -- 42 cc��
        nbrand_abbr     char(12),                   -- 43 nbrand_abbr
        ibigcomp        char(1),                    -- 44 �j�v�O�N
        ibus_location   char(10),                   -- 45 ��~���I
        iresource       char(1),                    -- 46 �~�Ȩӷ�
        ileader         char(10),                   -- 47 �޲z�H
        ibranch         char(2),                    -- 48 ������c
        iquota          char(6),                    -- 49 �~�Z���
        iupcomp         char(1),                    -- 50 �����q
        iroute          varchar(20),                -- 51 �q���N��
        irate_type      char(1),                    -- 52 �O�v�O
        iroute_comm     char(3),                    -- 53 �~�ȱ���
        bzfrom          char(2),                    -- 54 �O�o�q��
        icomm_obj       char(10),                   -- 55 �I����H
        qpro_month      int,                        -- 56 �s�y���
        nequipment      char(30)                    -- 57 ���O
    )with no log;

    $create index estimate_fb_x1 on estimate_fb(ipolicy);
    $create index estimate_fb_x2 on estimate_fb(iengine);
    $create index estimate_fb_x3 on estimate_fb(iassured);
    $create index estimate_fb_x4 on estimate_fb(dply_end);


    $create temp table est_ins_type_fb (
        ipolicy         char(20) default ' ',   -- 1 �O�渹
        iins_type       char(6)  default ' ',   -- 2 �I�إN��
        minjured_cover  int ,                   -- 3 ��˫O�B
	    mdeath_cover    int ,                   -- 4 ���`�O�B
	    mdamage_cover   int ,                   -- 5 �ƬG�O�B
	    mdeduct         int ,                   -- 6 �ۭt�B
	    mprem           int ,                   -- 7 �O�O
	    qday            int ,                   -- 8 ���
	    daily_pay       int                     -- 9 ���B
    )with no log;
    $create index est_ins_type_fb_x1 on est_ins_type_fb(ipolicy);


    /* Ū���ɮ�,�üg�Jtemp temp table  */
    /* --------------------------------------------------------------- */
    /*         �D��                                                    */
    /* --------------------------------------------------------------- */
    sprintf(filename,"%s/dat/car/%s",sApHome,sfile);
    if ((fp=fopen(filename,"r"))==NULL)
    {
       sprintf(err_buf,"%s file open fail ",filename);
       return FALSE;
    }
    flen=1024;
    if ((bp=malloc(flen))==NULL)
    {
       sprintf(err_buf,"System malloc failed !");
       return FALSE;
    }

    icnt = 0;
    for (i=0;(feof(fp)==0);i++)
    {
        memset(bp,0x00,flen);
        fgets(bp,flen,fp);
        if (bp[0]==0x00)
           break;

        qcount = 35; /* �`���� */

        for(j=0;j<qcount;j++)
           memset(sdata[j],0x00,151);

        k=m=n=0;
        for (j=0;j<flen;j++)
        {
            if (bp[j]=='\t' || bp[j]=='\0' || bp[j]=='\n')
            {
                strncpy(sdata[k],bp+(m+n),j-(m+n));
                sdata[k][j-(m+n)]='\0';
                n=0;
                m=j+1;
                k++;
            }
            if (bp[j]=='\n')
                break;
            if (k > qcount-1) break;

        }
        strcpy(sdata[0],sdata[2]);  /* �]���j��P���N�d���ۦP,�B��������ƵL�d��,�G�H�O�渹���N��d�� */
        if (sdata[0][0]=='\0')
        {
                continue;
        }

        rtrim_alldata();
        memset(ibigcomp,0x00,sizeof(ibigcomp));
        memset(ibus_location,0x00,sizeof(ibus_location));
        memset(iresource,0x00,sizeof(iresource));
        memset(ileader,0x00,sizeof(ileader));
        memset(ibranch,0x00,sizeof(ibranch));
        memset(iquota,0x00,sizeof(iquota));
        memset(iupcomp,0x00,sizeof(iupcomp));
        memset(iroute,0x00,sizeof(iroute));
        memset(irate_type,0x00,sizeof(irate_type));
        memset(iroute_comm,0x00,sizeof(iroute_comm));
        memset(bzfrom,0x00,sizeof(bzfrom));
        memset(icomm_obj,0x00,sizeof(icomm_obj));
        strcpy(nequipment,"000000000000000000000000000000");
        tmp_int = qpro_month = 0;

        for (k=0;k<qcount;k++)
        {
            /* �v����z��� */
            if(k == 1)
            {
                if(strcmp(sdata[k],"�j��") == 0)
                    strcpy(fcard_class,"1");
                else
                    strcpy(fcard_class,"2");
            }
            else if ((k == 3)||(k == 4)||(k == 5)||(k == 15)||(k == 22))
            {   /* YYYYMMDD �� MM/DD/YYYY */
                memset(tmp_str1,0x00,20);
                if (strlen(sdata[k]) < 4)
                {
                    strcpy(tmp_str1,"");
                }
                else
                {
                    strncpy(tmp_str1,&sdata[k][4],2);
                    tmp_str1[2]='\0';
                    strcat(tmp_str1,"/");
                    strncat(tmp_str1,&sdata[k][6],2);
                    tmp_str1[5]='\0';
                    strcat(tmp_str1,"/");
                    strncat(tmp_str1,&sdata[k][0],4);
                    tmp_str1[10]='\0';
                }
                strcpy(sdata[k],tmp_str1);
            }
            else if(k == 6)
            {
                memset(tmp_str1,0x00,20);
                strncpy(tmp_str1,&sdata[k][0],4);
                tmp_str1[4]='\0';
                ipro_year = atoi(tmp_str1); /* �s�y�~ */

                if (strlen(sdata[k]) > 4)
                {
                    memset(tmp_str1,0x00,20);
                    strncpy(tmp_str1,&sdata[k][4],2);
                    tmp_str1[2]='\0';
                    qpro_month = atoi(tmp_str1);
                }

            }
            else if(k == 7)
            {   /* �t�� */
                strcpy(tmp_str1, sdata[k]);
                $select first 1 qcylinder, qpassenger, fpt, nbrand_abbr
                   into $qcylinder, $qpt, $fpt, $nbrand_abbr
                   from ca_car_model
                  where ibrand = $sdata[k]
                    and ipro_year <= $sdata[6]
                  order by ipro_year desc;
                 if (SQLCODE == SQLNOTFOUND)
                {
                    $select first 1 qcylinder, qpassenger, fpt, nbrand_abbr
                       into $qcylinder, $qpt, $fpt, $nbrand_abbr
                       from ca_car_model
                      where ibrand = $sdata[k]
                        and ipro_year > $sdata[6]
                      order by ipro_year;
                }
            }
            else if(k == 8)
            {   /* ���� */
                memset(tmp_str1,0x00,20);
                sprintf(tmp_str1,"%02.2s",sdata[k]);
                strcpy(sdata[k],tmp_str1);
            }
            else if(k == 11)
            {
                tmp_price1 = atof(sdata[k]);
                tmp_price1 = tmp_price1/10000; /* ���� */
            }
            else if(k == 12)
            {
                if (strlen(sdata[k]) == 0)
                    tmp_price2 = 0.0;
                else
                {
                    tmp_price2 = atof(sdata[k]);
                    tmp_price2 = tmp_price2/10000; /* �t�ƻ� */
                }
            }
            else if(k == 13)
            {   /* �Q�O�I�H */
                strcpy(tmp_str1,sdata[k]);
                if (tmp_str1[0] >= 65)
                {
                    if ((tmp_str1[1] == 65) || (tmp_str1[1] == 67) || (tmp_str1[1] == 69))
                    {
                        strcpy(fassured,"3");   /* ��~�۵M�H */
                        fsex[0] = '1';  /* �ʧO--�k */
                    }else if((tmp_str1[1] == 66) || (tmp_str1[1] == 68) || (tmp_str1[1] == 70)){
                        strcpy(fassured,"3");   /* ��~�۵M�H */
                        fsex[0] = '2';  /* �ʧO--�k */
                    }else{
                        strcpy(fassured,"1");   /* �۵M�H */
                        fsex[0] = tmp_str1[1];  /* �ʧO */
                    }
                }
                else
                {
                    strcpy(fassured,"2");   /* �k�H */
                    strcpy(fsex," ");
                }
            }
            else if(k == 20)
            {   /* �n�O�I�H */
                strcpy(tmp_str1,sdata[k]);
                if (tmp_str1[0] >= 65)
                {
                    strcpy(fapplicant,"1");   /* �۵M�H */
                    fsex_appl[0] = tmp_str1[1];  /* �ʧO */
                }
                else
                {
                    strcpy(fapplicant,"2");   /* �k�H */
                    strcpy(fsex_appl," ");
                }
            }
            else if(k == 30)
            {   /* �g��N�� */
                $select ibigcomp, ibus_location, fprop, ileader, ibranch,
                        iquota, iupcomp, iroute, irate_type, iroute_comm,
                        (select bzfrom from v_commission_obj where icode = '3'
                            and icomm_obj = a.icomm_obj), icomm_obj
                   into $ibigcomp, $ibus_location, $iresource, $ileader,
                        $ibranch, $iquota, $iupcomp, $iroute, $irate_type,
                        $iroute_comm, $bzfrom, $icomm_obj
                   from officer a
                   where iofficer = $sdata[k];

                /* printf("14761:ibigcomp=[%s]ibus_location=[%s]iresource=[%s]\n",ibigcomp,ibus_location,iresource);
                printf("ileader=[%s]ibranch=[%s]iquota=[%s]\n",ileader,ibranch,iquota);
                printf("iupcomp=[%s]iroute=[%s]irate_type=[%s]\n",iupcomp,iroute,irate_type);
                printf("iroute_comm=[%s]bzfrom=[%s]icomm_obj=[%s]\n",iroute_comm,bzfrom,icomm_obj);  */
            }
            else if(k == 33)
            {
                if (strlen(sdata[k]) == 0)
                    idrunk = 0;
                else
                {
                    idrunk = atoi(sdata[k]); /* �s������ */
                }
            }
            else if(k == 34){
                if (strcmp(sdata[k],"05") == 0)
                    strcpy(nequipment,"000010000000000000000000000000");
                else
                    strcpy(nequipment,"000000000000000000000000000000");
            }
            else
            {
                if (strlen(sdata[k]) == 0)
                    strcpy(sdata[k]," ");
            }
        }
        $INSERT INTO estimate_fb
            VALUES($sdata[0],$fcard_class,$sdata[2],$sdata[3],$sdata[4],
                   $sdata[5],$ipro_year,$sdata[7],$sdata[8],$sdata[9],
                   $sdata[10],$tmp_price1,$tmp_price2,$sdata[13],$sdata[14],
                   $sdata[15],$sdata[16],$sdata[17],$sdata[18],$sdata[19],
                   $sdata[20],$sdata[21],$sdata[22],$sdata[23],$sdata[24],
                   $sdata[25],$sdata[26],$sdata[27],$sdata[28],$sdata[29],
                   $sdata[30],$sdata[31],$sdata[32],$idrunk, " ",
                   $fassured, $fsex, $fapplicant, $fsex_appl, $qpt,
                   $fpt, $qcylinder, $nbrand_abbr,$ibigcomp, $ibus_location,
                   $iresource, $ileader, $ibranch, $iquota, $iupcomp,
                   $iroute, $irate_type, $iroute_comm, $bzfrom, $icomm_obj,
                   $qpro_month, $nequipment );

        icnt++;
    }

    /* �����p�� */
    $select a.ipolicy as ipolicy, b.ipolicy as irelative_ply
       from estimate_fb a, estimate_fb b
      where a.iengine = b.iengine
        and a.itag = b.itag
        and a.iassured = b.iassured
        and a.ipolicy <> b.ipolicy
        and a.fcard_class <> b.fcard_class
       into temp aaa;
    $create index aaa_x1 on aaa(ipolicy);

    $update estimate_fb
        set irelative_ply = (select irelative_ply from aaa where aaa.ipolicy = estimate_fb.ipolicy)
      where ipolicy in (select ipolicy from aaa);

    $drop table aaa;

    /* --------------------------------------------------------------- */
    /*         ������                                                  */
    /* --------------------------------------------------------------- */

    sprintf(filename,"%s/dat/car/%s",sApHome,sfile2);

    if ((fp=fopen(filename,"r"))==NULL)
    {
       sprintf(err_buf,"%s file open fail ",filename);
       return FALSE;
    }
    flen=1024;
    if ((bp=malloc(flen))==NULL)
    {
       sprintf(err_buf,"System malloc failed !");

       return FALSE;
    }

    icnt = 0;
    for (i=0;(feof(fp)==0);i++)
    {
        memset(bp,0x00,flen);
        fgets(bp,flen,fp);
        if (bp[0]==0x00)
           break;
        qcount = 14; /* �`���� */
        for(j=0;j<qcount;j++)
           memset(sdata[j],0x00,150);

        k=m=n=0;
        for (j=0;j<flen;j++)
        {
            if (bp[j]=='\t' || bp[j]=='\0' || bp[j]=='\n')
            {
                strncpy(sdata[k],bp+(m+n),j-(m+n));
                sdata[k][j-(m+n)]='\0';
                n=0;
                m=j+1;
                k++;
            }
            if (bp[j]=='\n')
                break;
            if (k > qcount-1) break;
        }
        if (sdata[0][0]=='\0') continue;

        rtrim_alldata();

        qday = daily_pay = tmp_int = 0;
        mins_premium = atoi(sdata[6]);
        minjured_cover = atoi(sdata[9]);    /* ��� */
        mdeath_cover = atoi(sdata[10]);     /* ���` */
        mdamage_cover =  atoi(sdata[11]);   /* �ƬG */
        mdeduct = atoi(sdata[12]);          /* �ۭt�B */


        if (sdata[8][0]=='\0')
            strcpy(iins_type,sdata[1]);
        else
            strcpy(iins_type,sdata[8]);

        if ((strcmp(iins_type,"56") == 0) || (strcmp(iins_type,"166") == 0) || (strcmp(iins_type,"266") == 0))
        {
            daily_pay = atoi(sdata[13]);    /* ���B */
            qday = 0;
        }
        else
        {
            daily_pay = 0;
            qday = atoi(sdata[13]);         /* �Ѽ� */
        }
        /* printf("sdata[0]=[%s]\n",sdata[0]);
        printf("iins_type[%s]\n",iins_type);
        printf("minjured_cover[%d]\n",minjured_cover);
        printf("mdeath_cover[%d]\n",mdeath_cover);
        printf("mdamage_cover[%d]\n",mdamage_cover);
        printf("mdeduct[%d]\n",mdeduct);
        printf("mins_premium[%d]\n",mins_premium);
        printf("qday[%d]\n",qday);
        printf("daily_pay[%d]\n",daily_pay); */

        /* printf("sdata[0]=[%s] iins_type=[%s]minjured_cover=[%d]mdeath_cover=[%d]mdamage_cover=[%d]\n",sdata[0],iins_type,minjured_cover,mdeath_cover,mdamage_cover);
        printf("mdeduct=[%d] mins_premium=[%d]qday=[%d]daily_pay=[%d]\n",mdeduct,mins_premium,qday,daily_pay); */
        $INSERT INTO est_ins_type_fb
            VALUES($sdata[0], $iins_type, $minjured_cover, $mdeath_cover, $mdamage_cover,
                   $mdeduct, $mins_premium, $qday, $daily_pay);


        icnt++;
    }

     /* printf("---14955  insert into detail_fb ----- \n");
    $insert into detail_fb select * from estimate_fb; *//* ��DEV���ըϥ� */

    return TRUE;


    errexit:
         printf("get_fb_data():sqlerrcode=%d, sqlerrmsg=%s\n",SQLCODE,sqlca.sqlerrm);
         return SQLCODE;
}

rtrim_alldata()
{
    int  x;
    for(x=0;x<6;x++)
    {
       strcpy(sdata[x],rtrim(sdata[x]));
       if (strlen(sdata[x])>20) printf("[%d][%s]\n",strlen(sdata[x]),sdata[x]);
    }
}
