/************************************************/
/*						*/
/*   PROGRAM : ca519q03s.ec                   	*/
/*						*/
/*   DATE    : 2004/06/29			*/
/*						*/
/************************************************/
#include <stdio.h>
#include <string.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "print.h"
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "ca_field.h"
#include <locator.h>
#include "safeclib.h"

extern char RPTDIR[30];

$char BodyFmt[21], TitleFmt[21];
$char FormTp[3];
$int  TotColumn, StartRow, TitleRow, ItemRow, PgLine, Width;

char  SysTm[ N_TM+1];
char  BodyFile[ N_FILE+1];
char  TitleFile[ N_FILE+1];
char  outputf[ N_FILE+1];
char  userid[11];

int  max_count, errCode;
int  tmp_len, rec_count;
int  copies;
int  miy;


/*------------------------------------*/
#define NEXTPAGE   3
#define LINEofPAGE 30

/*** local function **/
   long car519_email();
   long car5193_get_db();


/*** screen variable ***/
   $char  dptbgn[3], dptend[3];
   $char  clsdate[13], clsdate_ED[11];
   $char  ch_clsdate[9], Tqserial[4];
   $int   qserial;

/*** report variable1 ***/
   $char  XIpolicy[PLY_LEN], XDadjust[9];
   $char  XIclaim[CLM_LEN], XFstl[2], YIadjuster[11];
   $int   XIclose_type;
   $long  YMdmg_stl, YMbrg_stl, YMparts_stl, YMlia_stl, YMinj_stl;
   $char  YNassured[13];
   $long  YMdmg_proc, YMlia_proc ;
   $char  ZIins_type[INS_LEN];
   $long  ZMins_proc;
    int   ZIins_type_INT;
   $char  Ipayment[13], Nchi_abv[13], Nchi_full[101];;
   $long  Mpayment;
   $int   Iqserial;

/*** report variable2 ***/
   $char ipolicy[PLY_LEN], iclaim[CLM_LEN], fstl[2];
   $int  iclose_type;
   $char icard[CARD_LEN], ftype[2];

/*** other variable ***/
   $char  DBName[5], DBName3[5];
    int   LoP;
    long  D1, D2, D3, D4;
    long  P11, P12, P13, P14;
    long  P21, P22, P23, P24;
    long  P31, P32, P33, P34;
    long  T11, T12, T13, T14;
    long  T21, T22, T23, T24;
    long  T31, T32, T33, T34;

    $long mdate;
    $char stmt[1024], DBName[5], sFullName[20];
    $char sLocalDB[5], sLocalName[20];
    $char sClsdate[11], eClsdate[11], sQserial[3], sIins_type[5];
    $char sIclaim[21], sFstl[2], sDclose[13], sIadjustment[10];
    $char sIemail[41], sRecipient[41], sSemail[21], sNins_type[41];
    $char sDpay[11], nchi_full[20], nname[15], tphone[16];
    $long lMins_stl, lMins_proc, eDclose, eDpay, lMplace_fee;
    $int  eQserial, eIclose_type, icount=0,count_nassured=0,count_leader=0;
    $char leader_email[41];
    $char ioth_tag[CA_TAG_NUM],ioth_iissue[11],ioth_nassured[21];
    $char ioth_tel[12],driver_nassured[21],driver_tel[12];
    $char ileader[11];
    $char iofficer[11];
    $char nassured[21];
    char prtstr[250], tmp_buf[10];
    $char iassured[11],tphone_ext_con[15];

    DBinfo  *list;
    int     count_db = 0;
    int     i;



/***************************************************************************/
main(argc, argv)
int argc;
char **argv;
{
$char mbuf1[9000];
$loc_t ctxt1;

   int rc;


   strcpy(DBName,"00");


   if (db_select(DBName) == False)
   {
       EWRITE(userid, M_CM_DB_NOTOPEN, " ");
       return M_CM_DB_NOTOPEN;
   }

  rc = car5193_get_db();
  if (rc != SUCCESS)
  return rc;


  rc=car519_email();
   if (rc != M_CM_OK)
   {
       EWRITE(userid, rc, " ");
       return rc;
   }
   printf("[5193]:build ok!\n");


}
/***************************************************************************/
long car519_email()
{

$char mbuf[9000];
$loc_t ctxt;

$char iclaim[21],iadjuster[11],up_admin[11];
$char email[51],up_email[51],nname[20];
$char dclaim[11],nassured[41];
$char chinese_name[15];
$char up_up_email[51];
$char up_up_admin[7];

/* �Ӹ�B�n (nassured,iassured) add by larry 103.02.19 (1030211003_C1) */
$char sFsex[2],sNassured[41],sTphone_ext_con[15];


/* for email */

   $whenever sqlerror goto errexit;

   if (db_select(DBName) == False)
   {
       EWRITE(userid, M_CM_DB_NOTOPEN, " ");
       return M_CM_DB_NOTOPEN;
   }


printf("  *********************car519 email \n");

   for(i=0;i<count_db;i++)
   {

/* �ѵs�I     �X�I��]21  �߮ר��z���25��  */
   sprintf_s(stmt,1024,
        " select a.iclaim,date(a.dclaim),c.nassured,a.iadjuster,c.iassured,c.fsex    \
            from %s:appraisal a,%s:app_ins_type b,%s:adjustment_ply c   \
           where today - date(a.dclaim) = 25    \
             and a.iclaim = b.iclaim            \
             and b.iclaim = c.iclaim            \
             and a.iacc_reason = '21'           \
             and b.iins_type = '11'             \
             and b.dclose_ctype is null ",
             list[i].dbname,list[i].dbname,list[i].dbname);
         printf("stmt[%s]\n",stmt);
        $prepare main_id from $stmt;
        $declare m_cur cursor for main_id;
        $open m_cur;
        for(;;)
        {
        $fetch m_cur
          into $iclaim,$dclaim,$nassured,$iadjuster,$iassured,$sFsex;

            if (SQLCODE == SQLNOTFOUND) break;
            printf("iclaim[%s],iadjuster[%s]\n",iclaim,iadjuster);

           /* �z�ߪ��ݥD�� �βz�� mail */
          $select administrator,email ,chinese_name
             into $up_admin,$email,$chinese_name
             from personal:asempl
            where empl_no = $iadjuster;

           strcpy(email,trim(email));
           strcat(email,"@tmnewa.com.tw");
           strcpy(chinese_name,trim(chinese_name));

          /* �z�ߪ��ݥD�� mail */
          $select email
             into $up_email
             from personal:asempl
            where empl_no = $up_admin
              and job_type >= '3';
           strcpy(up_email,trim(up_email));
           strcat(up_email,"@tmnewa.com.tw");

          /* �Q�O�I�H�q�� */
          $select tphone_ext_con
             into $tphone_ext_con
             from cu_customer
            where ifpce_id = $iassured
              and ifpce_id_ext = ' ';

          if (SQLCODE == SQLNOTFOUND)
          {   strcpy(tphone_ext_con," "); }

    	  /* �Ӹ�B�n (nassured,iassured) add by larry 103.02.19 (1030211003_C1) */
    	  strcpy(sFsex,trim(sFsex));
        if ( (strncmp(sFsex,"1",1) == 0) || (strncmp(sFsex,"2",1) == 0) )
        {
            strcpy(sNassured,substring(nassured,1,2));
	          strcat(sNassured,"�ݢ�");
	          strcpy(tphone_ext_con,trim(tphone_ext_con));
	          if (strlen(tphone_ext_con) != 0)
	          {
	              strcpy(sTphone_ext_con,substring(tphone_ext_con,1,3));
	              strcat(sTphone_ext_con,"XXXX");
	              strcat(sTphone_ext_con,substring(tphone_ext_con,8,7));
	          }
	          else
	          {
	            	strcpy(sTphone_ext_con," ");
	          }
	      }
	      else{
	          strcpy(sNassured,nassured);
	          strcpy(sTphone_ext_con,tphone_ext_con);
	      }


        /* �޲z�H�o�e��Ӹ�� */




        sprintf_s(mbuf,9000,
                 "�@�@���q���z�Ҩ��z���ѵs�I�߮סA�����w���z25��A\n"
                 "�p�G�����T�{���M�^�A�вz�߸g��t�p���O���z�����Ʃy�C</P>\n"
                 "<table align=center border='1'>\n"
                 "<tr><td>�߮׸��X</td><td>���z��</td><td>�O��m�W</td><td>�O��q��</td>\n"
                 "<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></table>\n"
                ,iclaim,
                dclaim,
                sNassured,
                sTphone_ext_con);


            printf("************mbuf[%s]",mbuf);


            ctxt.loc_loctype = LOCMEMORY;
            ctxt.loc_buffer = mbuf;
            ctxt.loc_bufsize =  9000;
            ctxt.loc_size =  strlen(mbuf) + 1;

            mdate = cm_today()+1;

            $INSERT INTO batchemail
            (project_id, mail_date, receiver_email, receiver_name, cc,
             content,    key,       mail_count)
             VALUES
            ("CAR5193",   $mdate,    $email, $chinese_name, $up_email,
             $ctxt,      "Y",       1);


    }
    $CLOSE m_cur;
    $FREE  m_cur;

    /* �ѵs�I     �X�I��]21  �߮ר��z���45��  */

     sprintf_s(stmt,1024,
        " select a.iclaim,date(a.dclaim),c.nassured ,a.iadjuster,c.fsex   \
            from %s:appraisal a,%s:app_ins_type b,%s:adjustment_ply c   \
           where today - date(a.dclaim) = 45    \
             and a.iclaim = b.iclaim            \
             and b.iclaim = c.iclaim            \
             and a.iacc_reason = '21'           \
             and b.iins_type = '11'             \
             and b.dclose_ctype is null ",
             list[i].dbname,list[i].dbname,list[i].dbname);
         printf("stmt[%s]\n",stmt);
        $prepare main_id from $stmt;
        $declare m_cur1 cursor for main_id;
        $open m_cur1;
        for(;;)
        {
        $fetch m_cur1
          into $iclaim,$dclaim,$nassured,$iadjuster,$sFsex;

            if (SQLCODE == SQLNOTFOUND) break;

            printf("iclaim[%s],iadjuster[%s]\n",iclaim,iadjuster);

    	    /* �z�ߪ��ݥD�� �βz�� mail */
          $select administrator,email
             into $up_admin,$email
             from personal:asempl
            where empl_no = $iadjuster;

          /* �z�ߪ��ݥD�� mail */
          $select administrator,email ,chinese_name
             into $up_up_admin,$up_email,$chinese_name
             from personal:asempl
            where empl_no = $up_admin
              and job_type >= '3';

           strcpy(up_email,trim(up_email));
           strcat(up_email,"@tmnewa.com.tw");
           strcpy(chinese_name,trim(chinese_name));

           /* ���ťD�� mail */
          $select email
             into $up_up_email
             from personal:asempl
            where empl_no = $up_up_admin
              and job_type = '5';
    	     if (SQLCODE == SQLNOTFOUND)
    	     {
    	     	  strcpy(up_up_email," ");
    	     }
    	     else{
    	        strcpy(up_up_email,trim(up_up_email));
              strcat(up_up_email,"@tmnewa.com.tw");
           }

            /* �Q�O�I�H�q�� */
          $select tphone_ext_con
             into $tphone_ext_con
             from cu_customer
            where ifpce_id = $iassured
              and ifpce_id_ext = ' ';

          if (SQLCODE == SQLNOTFOUND)
          {   strcpy(tphone_ext_con," "); }

          /* �Ӹ�B�n (nassured,iassured) add by larry 103.02.19 (1030211003_C1) */
    	    strcpy(sFsex,trim(sFsex));
          if ( (strncmp(sFsex,"1",1) == 0) || (strncmp(sFsex,"2",1) == 0) )
          {
              strcpy(sNassured,substring(nassured,1,2));
	            strcat(sNassured,"�ݢ�");
	            strcpy(tphone_ext_con,trim(tphone_ext_con));
	            if (strlen(tphone_ext_con) != 0)
	            {
	                strcpy(sTphone_ext_con,substring(tphone_ext_con,1,3));
	                strcat(sTphone_ext_con,"XXXX");
	                strcat(sTphone_ext_con,substring(tphone_ext_con,8,7));
	            }
	            else
	            {
	            	  strcpy(sTphone_ext_con," ");
	            }
	        }
	        else{
	            strcpy(sNassured,nassured);
	            strcpy(sTphone_ext_con,tphone_ext_con);
	        }


        /* �޲z�H�o�e��Ӹ�� */

          sprintf_s(mbuf,9000,
                 "�@�@���q���z���ݲz�ߨ��z���ѵs�I�߮סA�����w���z45��A\n"
                 "�p�G�����T�{���M�^�A�вz�߸g��t�p���O���z�����Ʃy�C</P>\n"
                 "<table align=center border='1'>\n"
                 "<tr><td>�߮׸��X</td><td>���z��</td><td>�O��m�W</td><td>�O��q��</td>\n"
                 "<tr><td>%s</td><td>%s</td><td>%s</td><td>%s</td></table>\n"
                ,iclaim,
                dclaim,
                sNassured,
                sTphone_ext_con);


            printf("************mbuf[%s]",mbuf);


            ctxt.loc_loctype = LOCMEMORY;
            ctxt.loc_buffer = mbuf;
            ctxt.loc_bufsize =  9000;
            ctxt.loc_size =  strlen(mbuf) + 1;

             mdate = cm_today()+1;

            $INSERT INTO batchemail
            (project_id, mail_date, receiver_email, receiver_name, cc,
             content,    key,       mail_count)
             VALUES
            ("CAR5193",   $mdate,    $up_email, $chinese_name, $up_up_email ,
             $ctxt,      "Y",       1);


    }
    $CLOSE m_cur1;
    $FREE  m_cur1;

    printf("total count[%d]\n",icount);



  } /* end three database */

 return M_CM_OK;

errexit:
  printf("errexit, SQLCODE=[%ld] \n", SQLCODE);
  return SQLCODE;




}


long car5193_get_db()
{
   if (db_select(DBName) == False) {
       EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
       return M_CM_DB_NOTOPEN;
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
      EWRITE(userid, M_CM_NOT_DBLIST, "M_CM_NOT_DBLIST");
      return M_CM_NOT_DBLIST;
   }

   return SUCCESS;

errexit:

   EWRITE(userid,SQLCODE,sqlca.sqlerrm);
   return SQLCODE;
}
