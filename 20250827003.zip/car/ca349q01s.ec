/**********************************************************************/
/*   program id   : ca349q01s.ec                                      */
/*   program name : �O�o�ɮײ��s�����@�~                              */
/*   date written : 09/17/2018                                        */
/**********************************************************************/
#include <stdio.h>
#include "comdata.h"
#include "globdata.h"
#include "commsgs.h"
#include "carmsgs.h"
#include "is_def.h"
$include sqlca;
$include decimal.h;
#include "api_xsrv.h"
#include <string.h>
#include "sql.h"
#include "cmprint.h"
#include "print.h"
#include "sqlfatal.h"
#include <math.h>
#include <decimal.h>
#include "cmnmsgs.h"


$char  DBName[5];
$char  Full_DBName[21];
$char  errMsg[2048];
$char  errMsg1[2048];
$char  stmp[2048];
char   sApHome[50];
long   rtncode;
FILE   *sfp,*fp;
static char  *bp;
static int   recLen=1024;
$char userid[11],stmt_1[2048],stmt_2[1024];
$char stmt_3[1024],stmt_4[1024],stmt_5[1024],stmt_6[1024];
$char stmt_7[1024],stmt_8[1024];
$char iclass[2];
$char txtfile[101];
$char ffname[101];
$char outputf[21];
$char dpolicy_input[21];
int offset;
$int datavalue;
$char getfile[300];
char delimiter;
$char sStmt[2048];
int i,count_db;
long rc;

DBinfo  *list;

long car349_exec();
void car349_rollback_rpt();
char *get_car_full_db(); 

main(argc, argv)
int argc;
char **argv;
{
    long rc;

    batchinit();
    strcpy(DBName        ,isNULLstr(argv[1]));
    strcpy(userid        ,isNULLstr(argv[2]));
    strcpy(iclass        ,isNULLstr(argv[3]));
    strcpy(dpolicy_input ,isNULLstr(argv[4]));    /*ñ���*/
    strcpy(txtfile       ,isNULLstr(argv[5]));    /*�u�@��1*/
    strcpy(ffname        ,isNULLstr(argv[6]));
    strcpy(outputf       ,isNULLstr(argv[7]));

    printf("txtfile[%s]\n",txtfile);

    rc = car349_get_db();
    if (rc != M_CM_OK)
		return rc;

    rtncode = getApHome(sApHome);
    if (rtncode < 0)
    {
        EWRITE(userid, M_CM_READ_CONFIG_ERR, "read Config file error!!");
        return FAIL;
    }



    if(strcmp(iclass,"1")==0)           /*iclass=1�A�O�o�ɮײ��s�����@�~*/
    {
        rc=car349_exec();

        $WHENEVER SQLERROR CONTINUE;

        if (rc != M_CM_OK)
        {
            printf("[���楢��]\n");
            strcpy(stmp,"car349_exec ���楢�� ");
            strcat(stmp,errMsg);
            EWRITE(userid,rc,stmp);
            return rc;
        }

        rc = car349_create_rpt();
        if (rc != M_CM_OK) 
	    return rc;
    }
    else if (strcmp(iclass,"2")==0)     /*iclass=2�A�A�O���X�����u���s�����@�~*/
    {                    
   
        rc=car349_exec2();

        $WHENEVER SQLERROR CONTINUE;

        if (rc != M_CM_OK)
        {
            printf("[���楢��]\n");
            strcpy(stmp,"car349_exec2 ���楢�� ");
            strcat(stmp,errMsg);
            EWRITE(userid,rc,stmp);
            return rc;
        }

        rc = car349_create_rpt2();
        if (rc != M_CM_OK) 
	    return rc;
    }
    else if (strcmp(iclass,"3")==0)     /*iclass=3�A�j��q�l���ҥ��Щ���*/
    {
    	
        rc=car349_exec3();

        $WHENEVER SQLERROR CONTINUE;

        if (rc != M_CM_OK)
        {
            printf("[���楢��]\n");
            strcpy(stmp,"car349_exec3 ���楢�� ");
            strcat(stmp,errMsg);
            EWRITE(userid,rc,stmp);
            return rc;
        }

        rc = car349_create_rpt3();
        if (rc != M_CM_OK) 
	    return rc;
    	
    }
    else if(strcmp(iclass,"4")==0)                               /*iclass=3�A�q�l�O��H�e���ѩ���*/
    {
    	
        rc=car349_exec4();

        $WHENEVER SQLERROR CONTINUE;

        if (rc != M_CM_OK)
        {
            printf("[���楢��]\n");
            strcpy(stmp,"car349_exec4 ���楢�� ");
            strcat(stmp,errMsg);
            EWRITE(userid,rc,stmp);
            return rc;
        }

        rc = car349_create_rpt4();
        if (rc != M_CM_OK) 
	    return rc;
    	
    }
	else if(strcmp(iclass,"5")==0) /* iclass = 5�A�j���I�O�O�ˮְl�ܳ���*/
	{
		rc=car349_exec5();

        $WHENEVER SQLERROR CONTINUE;

        if (rc != M_CM_OK)
        {
            printf("[���楢��]\n");
            strcpy(stmp,"car349_exec5 ���楢�� ");
            strcat(stmp,errMsg);
            EWRITE(userid,rc,stmp);
            return rc;
        }

        rc = car349_create_rpt5();
        if (rc != M_CM_OK) 
	    return rc;
	}
    return SUCCESS;
}
/**************************************************************************************/
long car349_get_db()
{
	$whenever sqlerror goto errexit;

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/******************************************************************************************/
void GetData(data, maxlen, delimiter)
char *data, delimiter;
int maxlen;
{
int fori, pre_offset, cnt=0;

    data[0]='\0';
    pre_offset = offset;

    for (fori=pre_offset; bp[fori]!=0x00&&bp[fori]!=0x0d&&bp[fori]!=0x0a&&bp[fori]!=delimiter; fori++)
    {
        offset++;
        if (cnt < maxlen-1)
        {
            data[cnt]=bp[fori];
            cnt++;
        }
    }

    offset++; /* ���ܤU�@�� */
    if (cnt==0) data[cnt++]=0x20; /* �L��Ƶ��ť� */
    data[cnt]=0x00;
    /*printf("data[%s]\n",data);*/
}

/*********************************************************************************************/

long car349_exec()    /*�O�o�ɮײ��s�����@�~*/
{
	
$char sdata_type[5];            
$char sedr_class[5]; 
$char serrCode[5];  
$char serrReason[50];     
$char serrValue[50];	
$char ipolicy[21];
$char icard[21];	
$char ipolicy2[21];	
$char icard2[21];
$char nassured[120];     	
$char itag[25];         	
$char dply_begin[12];       	
$char iofficer[11];
$char nname[11];  	
$char ileader[11];  
$char chinese_name[11]; 	
$char iquota[7];
$char nbranch[41];
$char ncar_abbr[13];

$char id[11];
$int  icnt;
$char stmt[4096];
$int  ipflag;


    printf("�O�o�ɮײ��s�����@�~\n");
    EXEC SQL WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;


    $CREATE temp TABLE car349_q
    (
   	sdata_type CHAR(10),  	/*��J�ɮ����:��ƫ��A*/
   	ipolicy    CHAR(21), 	/*��J�ɮ����:���s��*/
   	icard      CHAR(21), 	/*��J�ɮ����:�O�I�Ҹ�*/          
   	sedr_class CHAR(10),  	/*��J�ɮ����:���ʽ�*/
   	serrCode   CHAR(10),  	/*��J�ɮ����:���~�N�X*/
   	serrReason CHAR(50), 	/*��J�ɮ����:���~��]*/   
   	serrValue  CHAR(50),  	/*��J�ɮ����:���~��*/
   	ipolicy2   CHAR(20),  	/*�걵:�O�渹*/
   	icard2     CHAR(20),  	/*�걵:�O�d��*/
   	nassured   CHAR(120),  	/*�걵:�Q�O�H�m�W*/
   	itag       CHAR(25),   	/*�걵:����*/
   	dply_begin CHAR(11),     /*�걵:�O��_��*/
   	iofficer   CHAR(10),
   	nname      CHAR(10),  	/*�걵:�g��W��*/
   	ileader    CHAR(10),  
   	chinese_name CHAR(10), 	/*�걵:�޲z�H�W��*/
   	iquota CHAR(6),
   	nbranch CHAR(40), 	/*�걵:�~�Z���W��*/
   	ncar_abbr CHAR(12)      /*�걵:����*/

    )with no log;

    $CREATE temp TABLE car349_q_1
    (
	
   	ipolicy2   CHAR(20),  	/*�걵:�O�渹*/
   	icard2     CHAR(20),  	/*�걵:�O�d��*/
   	nassured   CHAR(120),  	/*�걵:�Q�O�H�m�W*/
   	itag      CHAR(25),   	/*�걵:����*/
   	dply_begin CHAR(11),     /*�걵:�O��_��*/
   	iofficer   CHAR(10),
   	nname      CHAR(10),  	/*�걵:�g��W��*/
   	ileader    CHAR(10),  
   	chinese_name CHAR(10), 	/*�걵:�޲z�H�W��*/
   	iquota CHAR(6),
   	nbranch CHAR(40), 	/*�걵:�~�Z���W��*/
   	ncar_abbr CHAR(12)      /*�걵:����*/

    )with no log;

    ipflag = 0;

    printf("sApHome[%s]\n",sApHome);
    printf("txtfile[%s]\n",txtfile);
    sprintf(getfile,"%s/dat/car/%s",sApHome,txtfile);
    printf("getfile[%s]\n",getfile);

    if ((fp=fopen(getfile,"rt"))==NULL)
    {
        return FAIL;
    }

    if ((bp=malloc(recLen))==NULL)
    {
        printf("System malloc failed  !\n");
        return FAIL;
    }

    /* ���j�Ÿ� */
    delimiter = '|';

    icnt = 0;
    while(fgets(bp,recLen,fp))
    {
       if (feof(fp)) break;
       offset = 0;
       

            /* ��ƨ��o���Ǥ��i�ܰ� */
            GetData(sdata_type,              sizeof(sdata_type),     	delimiter);      /*��ƫ��Asdata_type*/
            GetData(ipolicy,                 sizeof(ipolicy),   	delimiter);      /*���s��ipolicy*/
            GetData(icard,            	     sizeof(icard),            	delimiter);      /*�O�I�Ҹ�icard*/
            GetData(sedr_class,              sizeof(sedr_class),        delimiter);      /*���ʽ�sedr_class*/
            GetData(serrCode,                sizeof(serrCode),          delimiter);      /*���~�N�XserrCode*/
            GetData(serrReason,              sizeof(serrReason),        delimiter);      /*���~��]serrReason*/
            GetData(serrValue,               sizeof(serrValue),  	delimiter);      /*���~��serrValue*/


     
            strcpy(sdata_type, trim(sdata_type));
            strcpy(ipolicy, trim(ipolicy));
            strcpy(icard,trim(icard));
            strcpy(sedr_class,trim(sedr_class));
            strcpy(serrCode, trim(serrCode));
            strcpy(serrReason, trim(serrReason));
            strcpy(serrValue, trim(serrValue));
            
            printf("ipolicy[%s],icard[%s],serrValue[%s]\n",ipolicy,icard,serrValue);
     
            
            $INSERT INTO car349_q (sdata_type,ipolicy,icard,sedr_class,serrCode,serrReason,serrValue)
              VALUES($sdata_type,$ipolicy,$icard,$sedr_class,$serrCode,$serrReason,$serrValue);
              
              
            strcpy(ipolicy2,"");
            for(int i=2;i<=sizeof(ipolicy);i++)  /*�h�����s��(ipolicy)�e2�X=�O�渹(ipolicy2)*/
            {
                  ipolicy2[i-2]=ipolicy[i];
              	
            }
  
            strcpy(icard2,"");
            for(int i=2;i<=sizeof(icard);i++)  /*�h���O�I�Ҹ�(icard)�e2�X=�O�d��(icard2)*/
            {
                  icard2[i-2]=icard[i];
              	
            }

            /*�H�O�渹(ipolicy2)�B�O�d��(icard2) �걵�X�O�渹�B�O�d���B�Q�O�H�m�W�B�����B�O��_���B�g��W�١B�޲z�H�W�١B�~�Z���W��*/
	    sprintf(stmt_1, "INSERT INTO car349_q_1 "
			    "SELECT   a.ipolicy,a.icard,a.nassured,a.itag,to_char(b.dply_begin),b.iofficer,c.nname,b.ileader,d.chinese_name,b.iquota,e.nbranch,f.ncode"
               		    "  FROM   newa00:policy a, newa00:ply_relation b,officer c,personal:asempl d,sa_branch_type e,newa00:car_type f "
               		    " WHERE   a.icard='%s' "
               		    "   AND   a.ipolicy=b.ipolicy AND b.iofficer=c.iofficer"
               		    "   AND   b.ileader=d.empl_no AND b.iquota=e.ibranch AND   b.icar_type=f.icode",icard2);
            $PREPARE pre_ply1 from $stmt_1;
            $EXECUTE pre_ply1;	
            sprintf(stmt_2, "INSERT INTO car349_q_1 "
               		    "SELECT   a.ipolicy,a.icard,a.nassured,a.itag,to_char(b.dply_begin),b.iofficer,c.nname,b.ileader,d.chinese_name,b.iquota,e.nbranch,f.ncode"
               		    "  FROM   newa22:policy a, newa22:ply_relation b,officer c,personal:asempl d,sa_branch_type e,newa22:car_type f "
               		    " WHERE   a.icard='%s' "
               		    "   AND   a.ipolicy=b.ipolicy AND b.iofficer=c.iofficer"
               		    "   AND   b.ileader=d.empl_no AND b.iquota=e.ibranch AND   b.icar_type=f.icode",icard2);
            $PREPARE pre_ply2 from $stmt_2;
            $EXECUTE pre_ply2 ;
            sprintf(stmt_3, "INSERT INTO car349_q_1 "
               		    "SELECT   a.ipolicy,a.icard,a.nassured,a.itag,to_char(b.dply_begin),b.iofficer,c.nname,b.ileader,d.chinese_name,b.iquota,e.nbranch,f.ncode"
               		    "  FROM   newa33:policy a, newa33:ply_relation b,officer c,personal:asempl d,sa_branch_type e,newa33:car_type f "
               		    " WHERE   a.icard='%s' "
               		    "   AND   a.ipolicy=b.ipolicy AND b.iofficer=c.iofficer"
               		    "   AND   b.ileader=d.empl_no AND b.iquota=e.ibranch AND   b.icar_type=f.icode",icard2);
            $PREPARE pre_ply3 from $stmt_3;
            $EXECUTE pre_ply3 ;
            sprintf(stmt_4, "INSERT INTO car349_q_1 "
               		    "SELECT   a.ipolicy,a.icard,a.nassured,a.itag,to_char(b.dply_begin),b.iofficer,c.nname,b.ileader,d.chinese_name,b.iquota,e.nbranch,f.ncode"
               		    "  FROM   newa40:policy a, newa40:ply_relation b,officer c,personal:asempl d,sa_branch_type e,newa40:car_type f "
               		    " WHERE   a.icard='%s' "
               		    "   AND   a.ipolicy=b.ipolicy AND b.iofficer=c.iofficer"
               		    "   AND   b.ileader=d.empl_no AND b.iquota=e.ibranch AND   b.icar_type=f.icode",icard2);
            $PREPARE pre_ply4 from $stmt_4;
            $EXECUTE pre_ply4 ;
            sprintf(stmt_5, "INSERT INTO car349_q_1 "
               		    "SELECT   a.ipolicy,a.icard,a.nassured,a.itag,to_char(b.dply_begin),b.iofficer,c.nname,b.ileader,d.chinese_name,b.iquota,e.nbranch,f.ncode"
               		    "  FROM   newa66:policy a, newa66:ply_relation b,officer c,personal:asempl d,sa_branch_type e,newa66:car_type f "
               		    " WHERE   a.icard='%s' "
               		    "   AND   a.ipolicy=b.ipolicy AND b.iofficer=c.iofficer"
               		    "   AND   b.ileader=d.empl_no AND b.iquota=e.ibranch AND   b.icar_type=f.icode",icard2);
            $PREPARE pre_ply5 from $stmt_5;
            $EXECUTE pre_ply5 ;
            sprintf(stmt_6, "INSERT INTO car349_q_1 "
               		    "SELECT   a.ipolicy,a.icard,a.nassured,a.itag,to_char(b.dply_begin),b.iofficer,c.nname,b.ileader,d.chinese_name,b.iquota,e.nbranch,f.ncode"
               		    "  FROM   newa70:policy a, newa70:ply_relation b,officer c,personal:asempl d,sa_branch_type e,newa70:car_type f "
               		    " WHERE   a.icard='%s' "
               		    "   AND   a.ipolicy=b.ipolicy AND b.iofficer=c.iofficer"
               		    "   AND   b.ileader=d.empl_no AND b.iquota=e.ibranch AND   b.icar_type=f.icode",icard2);
            $PREPARE pre_ply6 from $stmt_6;
            $EXECUTE pre_ply6 ;		
               	
      	    datavalue=0;
      	    $SELECT count(*) INTO $datavalue from car349_q_1;
      		
      		
      	    if(datavalue!=0)
            {
		    strcpy(stmt_7,"SELECT * from car349_q_1");
      		    $PREPARE pre_ply2 from $stmt_7;
		    $DECLARE cur_data CURSOR FOR pre_ply2;
      		    $OPEN cur_data;	
                    $FETCH cur_data INTO $ipolicy2,$icard2,$nassured,$itag,$dply_begin,$iofficer,$nname,$ileader,$chinese_name,$iquota,$nbranch,$ncar_abbr;
                
                    strcpy(ipolicy2,trim(ipolicy2));
                    strcpy(icard2,trim(icard2));
                    strcpy(nassured,trim(nassured));
                    strcpy(itag,trim(itag));
                    strcpy(dply_begin,trim(dply_begin));
                	
                    strcpy(iofficer,trim(iofficer));
                    strcpy(nname,trim(nname));
                    strcpy(ileader,trim(ileader));
                    strcpy(chinese_name,trim(chinese_name));
                    strcpy(iquota,trim(iquota));
                    strcpy(nbranch,trim(nbranch));
                    strcpy(ncar_abbr,trim(ncar_abbr));
                    printf("[%s][%s][%s][%s][%s][%s][%s][%s][%s][%s][%s][%s]\n",ipolicy2,icard2,nassured,itag,dply_begin,iofficer,nname,ileader,chinese_name,iquota,nbranch,ncar_abbr);
                
     	     	    $CLOSE cur_data;
		    $FREE  cur_data;
		    $update car349_q 
			 set ipolicy2=$ipolicy2,icard2=$icard2,nassured=$nassured,itag=$itag,dply_begin=$dply_begin,iofficer=$iofficer,nname=$nname,ileader=$ileader,chinese_name=$chinese_name,iquota=$iquota,nbranch=$nbranch,ncar_abbr=$ncar_abbr
			 where ipolicy=$ipolicy and icard=$icard;
 		    $delete car349_q_1 where ipolicy2=$ipolicy2 and icard2=$icard2;
	    }else{
		    /*�䤣��걵�����*/
		    strcpy(ipolicy2,trim(ipolicy2));
                    strcpy(icard2,trim(icard2));
                    strcpy(nassured," ");
                    strcpy(itag," ");
                    strcpy(dply_begin," ");
                    strcpy(iofficer," ");
                    strcpy(nname," ");
                    strcpy(ileader," ");
                    strcpy(chinese_name," ");
                    strcpy(iquota," ");
                    strcpy(nbranch," ");
                    strcpy(ncar_abbr," ");
                    printf("[%s][%s][%s][%s][%s][%s][%s][%s][%s][%s][%s][%s]\n",ipolicy2,icard2,nassured,itag,dply_begin,iofficer,nname,ileader,chinese_name,iquota,nbranch,ncar_abbr);
		    $update car349_q 
			 set ipolicy2=$ipolicy2,icard2=$icard2,nassured=$nassured,itag=$itag,dply_begin=$dply_begin,iofficer=$iofficer,nname=$nname,ileader=$ileader,chinese_name=$chinese_name,iquota=$iquota,nbranch=$nbranch,ncar_abbr=$ncar_abbr
		    where ipolicy=$ipolicy and icard=$icard;
		
	    }
    }

    fclose(fp);
    return M_CM_OK;

errexit:
    
    printf("sStmt[%s]\n",sStmt);
    strcpy(errMsg1, errMsg);
    sprintf(errMsg,"errMsg: [%s]\n",errMsg1);
    rc = cm_show_sql_err("ca349", "");
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}

/****************************************************************************************************/

long car349_create_rpt()    /*�O�o�ɮ׳���*/
{
  int rc;
  char sfilename[41];
  char stitle[512];
  char sErrmsg[200];
  char stmt[512];

  $WHENEVER SQLERROR GOTO errexit;

	strcpy(sfilename,"���~�T�����Ӫ�[car349]");	
	strcpy(stitle," ");
	strcat(stitle,"���s��\t�O�I�Ҹ�\t���~��\t�O�渹\t�O�d��\t�Q�O�H�m�W\t����\t����\t�O��_��\t�g��W��\t�޲z�H�W��\t�~�Z���W��\t");

     	strcpy(stmt," select ipolicy,icard,serrValue,ipolicy2,icard2,nassured,itag,ncar_abbr,dply_begin,nname,chinese_name,nbranch  from car349_q;");
 
     	rc = unload_file(outputf," ",sfilename,stitle,stmt);

     	if (rc != SUCCESS)
     	{
         	sprintf(errMsg,"��Ʀ걵���ѡA���~�T���G%s", sqlca.sqlerrm);
         	return rc;
     	}

     return M_CM_OK;

  errexit:
    printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    exit(1);
}
/*********************************************************************************************/

long car349_exec2() /*�A�O���X�����u���s�����@�~*/
{
	
    
$char nitem[41];	
$char ipolicy[21];
$char mnt[11];    	
$char iofficer[11];	
$char ileader[11];  
$char chinese_name[11]; 	
$char iquota[7];
$char nbranch[41];


$char id[11];
$int  icnt;
$char stmt[4096];
$int  ipflag;


    printf("�A�O���X�����u���s�����@�~\n");
    EXEC SQL WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;


    $CREATE temp TABLE car349_q
    (
   	nitem	   CHAR(40),  	/*��J�ɮ����:����*/
   	ipolicy    CHAR(21), 	/*��J�ɮ����:�O�渹*/
   	mnt        CHAR(10), 	/*��J�ɮ����:���B*/          
   	iquota 	   CHAR(6),     /*�걵:���N�X*/
   	nbranch    CHAR(40), 	/*�걵:���W��*/
   	ileader    CHAR(10),    /*�걵:�޲z�H���s*/
   	chinese_name CHAR(10), 	/*�걵:�޲z�H�W��*/
   	iofficer   CHAR(10)     /*�걵:�g��N��*/

    )with no log;


    ipflag = 0;

    printf("sApHome[%s]\n",sApHome);
    printf("txtfile[%s]\n",txtfile);
    sprintf(getfile,"%s/dat/car/%s",sApHome,txtfile);
    printf("getfile[%s]\n",getfile);

    if ((fp=fopen(getfile,"rt"))==NULL)
    {
        return FAIL;
    }

    if ((bp=malloc(recLen))==NULL)
    {
        printf("System malloc failed  !\n");
        return FAIL;
    }

    /* ���j�Ÿ� */
    delimiter = '|';

    icnt = 0;
    while(fgets(bp,recLen,fp))
    {
       if (feof(fp)) break;
       offset = 0;
       

            /* ��ƨ��o���Ǥ��i�ܰ� */
       GetData(ipolicy,                 sizeof(ipolicy),   	delimiter);      /*�O�渹*/
       GetData(mnt,            	     sizeof(mnt),            	delimiter);      /*���B*/
       GetData(nitem,                   sizeof(nitem),     	delimiter);      /*����*/
            
       strcpy(nitem, trim(nitem));
       strcpy(ipolicy, trim(ipolicy));
       strcpy(mnt,trim(mnt));
            
       if(strcmp(ipolicy,"")!=0){
            printf("nitem[%s],ipolicy[%s],mnt[%s]\n",nitem,ipolicy,mnt);
            
            $INSERT INTO car349_q (nitem,ipolicy,mnt)
              VALUES($nitem,$ipolicy,$mnt);
            

            /*�H�O�渹�걵�X���N�X�B���W��(���B)�B�޲z�H���s�B�޲z�H�W�١B�g��N��*/
            strcpy(Full_DBName,get_car_full_db(ipolicy));
            printf("FullDataBaseName = %s \n",Full_DBName);
            
            sprintf(stmt_1, "SELECT  a.iquota,(SELECT nbranch FROM sa_branch_type WHERE ibranch = a.iquota[1,4]||'00' AND dexpire IS NULL),  \n"
		            "        a.ileader,(SELECT nname FROM officer WHERE iofficer=a.ileader), \n"
		            "        a.iofficer   \n"
                            "  FROM  %s:ply_relation a  \n" 
                            " WHERE  a.ipolicy='%s' \n",Full_DBName,ipolicy);
            $PREPARE pre_ply1 from $stmt_1;
            $EXECUTE pre_ply1 INTO $iquota,$nbranch,$ileader,$chinese_name,$iofficer;	
            
            if (SQLCODE == SQLNOTFOUND) 
            {
		 strcpy(iquota,"");
		 strcpy(nbranch,"");
		 strcpy(ileader,"");
		 strcpy(chinese_name,"");
		 strcpy(iofficer,"");

            }   

            $UPDATE  car349_q 
                SET  iquota=$iquota,nbranch=$nbranch,ileader=$ileader,chinese_name=$chinese_name,iofficer=$iofficer
              WHERE  ipolicy=$ipolicy;
       }
                 	
      	 
    }

    fclose(fp);
    return M_CM_OK;

errexit:
    
    printf("sStmt[%s]\n",sStmt);
    strcpy(errMsg1, errMsg);
    sprintf(errMsg,"errMsg: [%s]\n",errMsg1);
    rc = cm_show_sql_err("ca349", "");
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}

/****************************************************************************************************/

long car349_create_rpt2()   /*�A�O���X�����u����*/
{
  int rc;
  char sfilename[41];
  char stitle[512];
  char sErrmsg[200];
  char stmt[512];

  $WHENEVER SQLERROR GOTO errexit;

	strcpy(sfilename,"�A�O���X�����u����[car349]");	
	strcpy(stitle," ");
	strcat(stitle,"���N�X\t���W��(���B)\t�O�渹\t���B\t�޲z�H���s\t�޲z�H�W��\t�g��N��\t����\t");

     	strcpy(stmt," select chr(127)||iquota,nbranch,ipolicy,mnt,chr(127)||ileader,chinese_name,chr(127)||iofficer,nitem  from car349_q;");
 
     	rc = unload_file(outputf," ",sfilename,stitle,stmt);

     	if (rc != SUCCESS)
     	{
         	sprintf(errMsg,"��Ʀ걵���ѡA���~�T���G%s", sqlca.sqlerrm);
         	return rc;
     	}

     return M_CM_OK;

  errexit:
    printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    exit(1);
}
/*********************************************************************************************/

long car349_exec3() /*�j��q�l���ҥ��Щ���*/
{
	
    
$char nkind[21],icard[21],icard_17[21],ipolicy[21];	
$char nassured[121],aassured[90],iassured[12],dbirth[12];
$char mobil_phone[21],iemail[51],napplicant[121],apayment[91];
$char iapplicant[12],dbirth_appl[12],tmobile_appl[21],aemail_appl[51];
$char nrelation_appl[41],tmobile_eply[21],aemail_eply[51];
$char nbranch[41],ncode[41],iofficer[11],nofficer[11];	   
$char ileader[11],nleader[11];	
   	



$char id[11];
$int  icnt;
$char stmt[4096];
$int  ipflag;


    printf("�j��q�l���ҥ��Щ���\n");
    EXEC SQL WHENEVER SQLERROR GOTO errexit;
    $SET LOCK MODE TO WAIT;


    $CREATE temp TABLE car349_q
    (
   	nkind	        char(20), /*��J�ɮ����:���O*/
   	icard_17        char(20), /*��J�ɮ����:�O�I�Ҹ�*/  
   	icard           char(20)

    )with no log;


    ipflag = 0;

    printf("sApHome[%s]\n",sApHome);
    printf("txtfile[%s]\n",txtfile);
    sprintf(getfile,"%s/dat/car/%s",sApHome,txtfile);
    printf("getfile[%s]\n",getfile);

    if ((fp=fopen(getfile,"rt"))==NULL)
    {
        return FAIL;
    }

    if ((bp=malloc(recLen))==NULL)
    {
        printf("System malloc failed  !\n");
        return FAIL;
    }

    /* ���j�Ÿ� */
    delimiter = '|';

    icnt = 0;
    while(fgets(bp,recLen,fp))
    {
        if (feof(fp)) break;
        offset = 0;
       
        strcpy(nkind, "");
        strcpy(icard_17, "");
        strcpy(icard, "");

       
        /* ��ƨ��o���Ǥ��i�ܰ� */
        GetData(nkind,               sizeof(nkind),   	delimiter);      /*���O*/
        GetData(icard_17,            sizeof(icard_17),   delimiter);      /*�O�I�Ҹ�*/

            
        strcpy(nkind, trim(nkind));
        strncpy(icard, trim(icard_17)+2,20);
            
        if(strcmp(trim(icard),"")!=0)
        {
            printf("nkind[%s],icard[%s]\n",nkind,icard);
            
            $INSERT INTO car349_q (nkind,icard_17,icard)
              VALUES($nkind,$icard_17,$icard);
              
        }   
                
    }
            


    fclose(fp);
    return M_CM_OK;

errexit:
    
    printf("sStmt[%s]\n",sStmt);
    strcpy(errMsg1, errMsg);
    sprintf(errMsg,"errMsg: [%s]\n",errMsg1);
    rc = cm_show_sql_err("ca349", "");
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}

/****************************************************************************************************/

long car349_create_rpt3()   /*�j��q�l���ҥ��Щ���*/
{
  int rc;
  char sfilename[41];
  char stitle[512];
  char sErrmsg[200];
  char stmt[10240];

  $WHENEVER SQLERROR GOTO errexit;

	strcpy(sfilename,"�j��q�l���ҥ��Щ���[car349]");	
	strcpy(stitle," ");
	strcat(stitle,"���O\t�O�I�Ҹ�\t�Q�O�H�W��\t�Q�O�H�a�}\t�Q�O�HID\t�Q�O�H�X�~���\t�Q�O�H�����\t�Q�O�HEMAIL\t�n�O�H�W��\t�n�O�H�a�}\t�n�O�HID\t�n�O�H�X�~���\t�n�O�H�����\t�n�O�HEMAIL\t�n�Q�O�H���Y\t�q�l���Ҥ����\t�q�l����EMAIL\t�~�Z��줤��\t�ҰϧO\t�g��N��\t�g��W��\t�޲z�H�N��\t�޲z�H�W��\t");

     	strcpy(stmt,"SELECT  d.nkind,d.icard_17,a.nassured ,a.aassured ,a.iassured ,"
                    "        a.dbirth ,a.mobil_phone ,a.iemail ,"
                    "        a.napplicant ,a.apayment ,a.iapplicant ,"
                    "        a.dbirth_appl ,a.tmobile_appl ,"
                    "        a.aemail_appl ,a.nrelation_appl ,"
                    "        b.tmobile_eply ,b.aemail_eply ,"
                    "        (SELECT nbranch FROM sa_branch_type WHERE ibranch = b.iquota) ,"
                    "        (SELECT ncode FROM cu_code_data WHERE icode = c.group2 AND itype = '19') ,"
                    "        ''''||b.iofficer ,"
                    "        (SELECT nname FROM officer WHERE iofficer = b.iofficer) ,"
                    "        ''''||b.ileader ,"
                    "        (SELECT nname FROM officer WHERE iofficer = b.ileader)"
                    "  FROM  newa00:policy a,newa00:ply_relation b,sa_branch_type c, car349_q d"
                    " WHERE  a.ipolicy=b.ipolicy AND b.iquota = c.ibranch "
                    "   AND  d.icard = a.icard "  
                    " UNION "   	
                    "SELECT  d.nkind,d.icard_17,a.nassured ,a.aassured ,a.iassured ,"
                    "        a.dbirth ,a.mobil_phone ,a.iemail ,"
                    "        a.napplicant ,a.apayment ,a.iapplicant ,"
                    "        a.dbirth_appl ,a.tmobile_appl ,"
                    "        a.aemail_appl ,a.nrelation_appl ,"
                    "        b.tmobile_eply ,b.aemail_eply ,"
                    "        (SELECT nbranch FROM sa_branch_type WHERE ibranch = b.iquota) ,"
                    "        (SELECT ncode FROM cu_code_data WHERE icode = c.group2 AND itype = '19') ,"
                    "        ''''||b.iofficer ,"
                    "        (SELECT nname FROM officer WHERE iofficer = b.iofficer) ,"
                    "        ''''||b.ileader ,"
                    "        (SELECT nname FROM officer WHERE iofficer = b.ileader)"
                    "  FROM  newa22:policy a,newa22:ply_relation b,sa_branch_type c, car349_q d"
                    " WHERE  a.ipolicy=b.ipolicy AND b.iquota = c.ibranch "
                    "   AND  d.icard = a.icard "  
                    " UNION "        	
                    "SELECT  d.nkind,d.icard_17,a.nassured ,a.aassured ,a.iassured ,"
                    "        a.dbirth ,a.mobil_phone ,a.iemail ,"
                    "        a.napplicant ,a.apayment ,a.iapplicant ,"
                    "        a.dbirth_appl ,a.tmobile_appl ,"
                    "        a.aemail_appl ,a.nrelation_appl ,"
                    "        b.tmobile_eply ,b.aemail_eply ,"
                    "        (SELECT nbranch FROM sa_branch_type WHERE ibranch = b.iquota) ,"
                    "        (SELECT ncode FROM cu_code_data WHERE icode = c.group2 AND itype = '19') ,"
                    "        ''''||b.iofficer ,"
                    "        (SELECT nname FROM officer WHERE iofficer = b.iofficer) ,"
                    "        ''''||b.ileader ,"
                    "        (SELECT nname FROM officer WHERE iofficer = b.ileader)"
                    "  FROM  newa33:policy a,newa33:ply_relation b,sa_branch_type c, car349_q d"
                    " WHERE  a.ipolicy=b.ipolicy AND b.iquota = c.ibranch "
                    "   AND  d.icard = a.icard "  
                    " UNION "        	
                    "SELECT  d.nkind,d.icard_17,a.nassured ,a.aassured ,a.iassured ,"
                    "        a.dbirth ,a.mobil_phone ,a.iemail ,"
                    "        a.napplicant ,a.apayment ,a.iapplicant ,"
                    "        a.dbirth_appl ,a.tmobile_appl ,"
                    "        a.aemail_appl ,a.nrelation_appl ,"
                    "        b.tmobile_eply ,b.aemail_eply ,"
                    "        (SELECT nbranch FROM sa_branch_type WHERE ibranch = b.iquota) ,"
                    "        (SELECT ncode FROM cu_code_data WHERE icode = c.group2 AND itype = '19') ,"
                    "        ''''||b.iofficer ,"
                    "        (SELECT nname FROM officer WHERE iofficer = b.iofficer) ,"
                    "        ''''||b.ileader ,"
                    "        (SELECT nname FROM officer WHERE iofficer = b.ileader)"
                    "  FROM  newa40:policy a,newa40:ply_relation b,sa_branch_type c, car349_q d"
                    " WHERE  a.ipolicy=b.ipolicy AND b.iquota = c.ibranch "
                    "   AND  d.icard = a.icard "  
                    " UNION "        	
                    "SELECT  d.nkind,d.icard_17,a.nassured ,a.aassured ,a.iassured ,"
                    "        a.dbirth ,a.mobil_phone ,a.iemail ,"
                    "        a.napplicant ,a.apayment ,a.iapplicant ,"
                    "        a.dbirth_appl ,a.tmobile_appl ,"
                    "        a.aemail_appl ,a.nrelation_appl ,"
                    "        b.tmobile_eply ,b.aemail_eply ,"
                    "        (SELECT nbranch FROM sa_branch_type WHERE ibranch = b.iquota) ,"
                    "        (SELECT ncode FROM cu_code_data WHERE icode = c.group2 AND itype = '19') ,"
                    "        ''''||b.iofficer ,"
                    "        (SELECT nname FROM officer WHERE iofficer = b.iofficer) ,"
                    "        ''''||b.ileader ,"
                    "        (SELECT nname FROM officer WHERE iofficer = b.ileader)"
                    "  FROM  newa66:policy a,newa66:ply_relation b,sa_branch_type c, car349_q d"
                    " WHERE  a.ipolicy=b.ipolicy AND b.iquota = c.ibranch "
                    "   AND  d.icard = a.icard "  
                    " UNION "    
                    "SELECT  d.nkind,d.icard_17,a.nassured ,a.aassured ,a.iassured ,"
                    "        a.dbirth ,a.mobil_phone ,a.iemail ,"
                    "        a.napplicant ,a.apayment ,a.iapplicant ,"
                    "        a.dbirth_appl ,a.tmobile_appl ,"
                    "        a.aemail_appl ,a.nrelation_appl ,"
                    "        b.tmobile_eply ,b.aemail_eply ,"
                    "        (SELECT nbranch FROM sa_branch_type WHERE ibranch = b.iquota) ,"
                    "        (SELECT ncode FROM cu_code_data WHERE icode = c.group2 AND itype = '19') ,"
                    "        ''''||b.iofficer ,"
                    "        (SELECT nname FROM officer WHERE iofficer = b.iofficer) ,"
                    "        ''''||b.ileader ,"
                    "        (SELECT nname FROM officer WHERE iofficer = b.ileader)"
                    "  FROM  newa70:policy a,newa70:ply_relation b,sa_branch_type c, car349_q d"
                    " WHERE  a.ipolicy=b.ipolicy AND b.iquota = c.ibranch "
                    "   AND  d.icard = a.icard "    	);
     	
     	            
	
 
     	rc = unload_file(outputf," ",sfilename,stitle,stmt);

     	if (rc != SUCCESS)
     	{
         	sprintf(errMsg,"��Ʀ걵���ѡA���~�T���G%s", sqlca.sqlerrm);
         	return rc;
     	}

     return M_CM_OK;

  errexit:
    printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    exit(1);
}
/*********************************************************************************************/

long car349_exec4() /*�q�l�O��H�e���ѩ���*/ /*��W���G�̷s�O��Ȥ�s����T*/
{
	$char ipolicy[21];	
	$int  icnt,ipflag;
	
	printf("�̷s�O��Ȥ�s����T\n");
	EXEC SQL WHENEVER SQLERROR GOTO errexit;
	$SET LOCK MODE TO WAIT;
	
	$CREATE temp TABLE car349_q
	(
	    ipolicy    char(20)  /*��J�ɮ����G�O�渹*/
	)with no log;
	
	ipflag = 0;
	
	printf("sApHome[%s]\n",sApHome);
	printf("txtfile[%s]\n",txtfile);
	sprintf(getfile,"%s/dat/car/%s",sApHome,txtfile);
	printf("getfile[%s]\n",getfile);
	
	if ((fp=fopen(getfile,"rt"))==NULL)
	{
		return FAIL;
	}
	
	if ((bp=malloc(recLen))==NULL)
	{
		printf("System malloc failed  !\n");
		return FAIL;
	}
	
	/* ���j�Ÿ� */
	delimiter = '|';
	
	icnt = 0;
	while(fgets(bp,recLen,fp))
	{
		if (feof(fp)) break;
		offset = 0;
		
		strcpy(ipolicy, "");
		GetData(ipolicy,sizeof(ipolicy),delimiter);
		strcpy(ipolicy, trim(ipolicy));
		
		if(strcmp(ipolicy,"")!=0){
			$INSERT INTO car349_q (ipolicy) VALUES($ipolicy);
		} 
	}
	
	fclose(fp);
	return M_CM_OK;

errexit:
    strcpy(errMsg1, errMsg);
    sprintf(errMsg,"errMsg: [%s]\n",errMsg1);
    rc = cm_show_sql_err("ca349", "");
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}

/****************************************************************************************************/

long car349_create_rpt4()   /*�q�l�O��H�e���ѩ���*/ /*��W���G�̷s�O��Ȥ�s����T*/
{
	int rc;
	char sfilename[41];
	char stitle[512];
	char sErrmsg[200];
	char stmt[10240];
	
	$WHENEVER SQLERROR GOTO errexit;

	strcpy(sfilename,"�̷s�O��Ȥ��p����T[car349]");	
	strcpy(stitle," ");
	strcat(stitle,"�O�渹\t�O�I�Ҹ�\t�Q�O�H�m�W\t�Q�O�H�q��(��)\t�Q�O�H�q��(�])\t�Q�O�H���\t�Q�O�HE-MAIL\t�Q�O�H���}\t�n�O�H�m�W\t�n�O�H�q��\t�n�O�H���\t�n�O�HE-MAIL\t�n�O�H���}\t�H�o��E-MAIL\t�H�o�����\t�~�Z���W��\t�޲z�H\t�޲z�H�W��\t");

     	strcpy(stmt,"SELECT a.ipolicy, a.icard, a.nassured, a.itel, a.itel_night, a.mobil_phone, a.iemail,"
                    "       a.aassured, a.napplicant, a.itel_appl, a.tmobile_appl, a.aemail_appl, a.apayment, b.aemail_eply, b.tmobile_eply, "
                    "       (SELECT nbranch FROM sa_branch_type WHERE ibranch = b.iquota), "
                    "       b.ileader, c.nname "
                    "  FROM newa00:policy a, newa00:ply_relation b, officer c, car349_q d "
                    " WHERE a.ipolicy = b.ipolicy AND a.ipolicy = d.ipolicy "
                    "   AND b.ileader = c.iofficer "  
                    " UNION "   	
                    "SELECT a.ipolicy, a.icard, a.nassured, a.itel, a.itel_night, a.mobil_phone, a.iemail,"
                    "       a.aassured, a.napplicant, a.itel_appl, a.tmobile_appl, a.aemail_appl, a.apayment, b.aemail_eply, b.tmobile_eply, "
                    "       (SELECT nbranch FROM sa_branch_type WHERE ibranch = b.iquota), "
                    "       b.ileader, c.nname "
                    "  FROM newa22:policy a, newa22:ply_relation b, officer c, car349_q d "
                    " WHERE a.ipolicy = b.ipolicy AND a.ipolicy = d.ipolicy "
                    "   AND b.ileader = c.iofficer "
                    " UNION "  
                    "SELECT a.ipolicy, a.icard, a.nassured, a.itel, a.itel_night, a.mobil_phone, a.iemail,"
                    "       a.aassured, a.napplicant, a.itel_appl, a.tmobile_appl, a.aemail_appl, a.apayment, b.aemail_eply, b.tmobile_eply, "
                    "       (SELECT nbranch FROM sa_branch_type WHERE ibranch = b.iquota), "
                    "       b.ileader, c.nname "
                    "  FROM newa33:policy a, newa33:ply_relation b, officer c, car349_q d "
                    " WHERE a.ipolicy = b.ipolicy AND a.ipolicy = d.ipolicy "
                    "   AND b.ileader = c.iofficer " 
                    " UNION "        	
                    "SELECT a.ipolicy, a.icard, a.nassured, a.itel, a.itel_night, a.mobil_phone, a.iemail,"
                    "       a.aassured, a.napplicant, a.itel_appl, a.tmobile_appl, a.aemail_appl, a.apayment, b.aemail_eply, b.tmobile_eply, "
                    "       (SELECT nbranch FROM sa_branch_type WHERE ibranch = b.iquota), "
                    "       b.ileader, c.nname "
                    "  FROM newa40:policy a, newa40:ply_relation b, officer c, car349_q d "
                    " WHERE a.ipolicy = b.ipolicy AND a.ipolicy = d.ipolicy "
                    "   AND b.ileader = c.iofficer " 
                    " UNION "        	
                    "SELECT a.ipolicy, a.icard, a.nassured, a.itel, a.itel_night, a.mobil_phone, a.iemail,"
                    "       a.aassured, a.napplicant, a.itel_appl, a.tmobile_appl, a.aemail_appl, a.apayment, b.aemail_eply, b.tmobile_eply, "
                    "       (SELECT nbranch FROM sa_branch_type WHERE ibranch = b.iquota), "
                    "       b.ileader, c.nname "
                    "  FROM newa66:policy a, newa66:ply_relation b, officer c, car349_q d "
                    " WHERE a.ipolicy = b.ipolicy AND a.ipolicy = d.ipolicy "
                    "   AND b.ileader = c.iofficer "  
                    " UNION "    
                    "SELECT a.ipolicy, a.icard, a.nassured, a.itel, a.itel_night, a.mobil_phone, a.iemail,"
                    "       a.aassured, a.napplicant, a.itel_appl, a.tmobile_appl, a.aemail_appl, a.apayment, b.aemail_eply, b.tmobile_eply, "
                    "       (SELECT nbranch FROM sa_branch_type WHERE ibranch = b.iquota), "
                    "       b.ileader, c.nname "
                    "  FROM newa70:policy a, newa70:ply_relation b, officer c, car349_q d "
                    " WHERE a.ipolicy = b.ipolicy AND a.ipolicy = d.ipolicy "
                    "   AND b.ileader = c.iofficer ");

     	rc = unload_file(outputf," ",sfilename,stitle,stmt);

     	if (rc != SUCCESS)
     	{
         	sprintf(errMsg,"��Ʀ걵���ѡA���~�T���G%s", sqlca.sqlerrm);
         	return rc;
     	}

     return M_CM_OK;

  errexit:
    printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    exit(1);
}
/****************************************************************************************************/
long car349_exec5()   /*�j���I�O�O�ˮְl�ܳ���*/
{
	$char icard[21], itag[21], iengine[31];
	int car_tag_option = 0;
	printf("�j���I�O�O�ˮְl�ܳ���\n");
	$WHENEVER SQLERROR GOTO errexit;
	
	strcpy(dpolicy_input, trim(dpolicy_input));
	
	
	if(strcmp(dpolicy_input, "") == 0)
	{
		$CREATE temp TABLE car349_q
		(
			icard   char(20) /*�Y�Lñ���A�N�O��O�I�Ҹ� */
		)with no log;
		
		car_tag_option = 0;
	}
	else
	{
		$CREATE temp TABLE car349_q
		(
			itag    char(20), /* ���M�N�ਮ�P+������ */
			iengine char(25)
		)with no log;
		
		$CREATE temp TABLE car349_temp /* �ݭn�@���@����J��@����X */
		(
			icard         char(20),
			nassured      varchar(120),
			iassured      char(12),
			dpolicy       DATE,
			iengine       char(25),
			itag          char(12),
			fcomp_class   char(2),
			icar_type     char(2),
			dbirth        DATE,
			mins_premium  INTEGER,
			mdamage_cover INTEGER,
			nleader       char(10),
			ileader       char(10),
			nbranch       char(40)
		)with no log;
		
		strcpy(dpolicy_input, cm_to_infdate(dpolicy_input));
		car_tag_option = 1;
	}
	
	printf("sApHome[%s]\n",sApHome);
	printf("txtfile[%s]\n",txtfile);
	sprintf(getfile,"%s/dat/car/%s",sApHome,txtfile);
	printf("getfile[%s]\n",getfile);
	
	if ((fp=fopen(getfile,"rt"))==NULL)
	{
		return FAIL;
	}
	
	if ((bp=malloc(recLen))==NULL)
	{
		printf("System malloc failed  !\n");
		return FAIL;
	}
	
	delimiter = '|';
	
	while(fgets(bp,recLen,fp))
	{
		if (feof(fp)) break;
		offset = 0;
		
		if(car_tag_option == 0)
		{
			strcpy(icard, "");
			GetData(icard,sizeof(icard),delimiter);
			strcpy(icard, trim(icard));
			if(strcmp(icard,"")!=0)
			{
				$INSERT INTO car349_q (icard) VALUES($icard);
			}
		}
		else
		{
			strcpy(itag, "");
			strcpy(iengine, "");
			GetData(itag,sizeof(itag),delimiter);
			GetData(iengine,sizeof(iengine),delimiter);
			strcpy(itag, trim(itag));
			strcpy(iengine, trim(iengine));
			if(strcmp(itag,"") != 0 || strcmp(iengine, "") != 0)
			{
				$INSERT INTO car349_q (itag, iengine) VALUES($itag, $iengine);
			}
		}
	}
	
	fclose(fp);
	return M_CM_OK;

errexit:
    strcpy(errMsg1, errMsg);
    sprintf(errMsg,"errMsg: [%s]\n",errMsg1);
    rc = cm_show_sql_err("ca349", "");
    $WHENEVER SQLERROR CONTINUE;
    $ROLLBACK WORK;
    $SET LOCK MODE TO NOT WAIT;
    return rc;
}
/****************************************************************************************************/
long car349_create_rpt5()   /*�j���I�O�O�ˮְl�ܳ���*/
{
	int rc, card_tag_option = 0, k = 0;
	char sfilename[41];
	char stitle[512];
	char sErrmsg[200];
	char stmt[10240];
	$char stmt2[2048], stmt3[10240], stmt4[512];
	$char icard_temp[21], itag_temp[21], iengine_temp[31];
	
	$WHENEVER SQLERROR GOTO errexit;
	
	if(strcmp(dpolicy_input, "") == 0)
	{
		card_tag_option = 0;
	}
	else
	{
		card_tag_option = 1;
	}
	
	strcpy(sfilename, "�j���I�O�O�ˮְl�ܳ���[car349]");	
	strcpy(stitle, " ");
	strcat(stitle, "�O�I�Ҹ�\t�Q�O�I�H�W��\t�Τ@�s��\tñ���\t�������X\t���P���X\t�j��ż�\t����\t�Q�O�I�H�ͤ�\t�O�O\t�O��O�B\t�޲z�H�W��\t�޲z�H�N��\t���W��\t");
	
	if(card_tag_option == 0)
	{
		sprintf_s(stmt, sizeof stmt, 
		          "SELECT a.icard, a.nassured, a.iassured, b.dpolicy, a.iengine, a.itag, "
				  " b.fcomp_class, b.icar_type, a.dbirth, (SELECT CAST(sum(mins_premium) AS INTEGER) FROM ply_ins_type WHERE ipolicy = a.ipolicy), "
				  " (SELECT CAST(sum(mdamage_cover) AS INTEGER) FROM ply_ins_type WHERE ipolicy = a.ipolicy), (SELECT nname FROM officer WHERE iofficer = b.ileader), "
				  " b.ileader, (SELECT nbranch FROM sa_branch_type WHERE ibranch = b.iquota) "
				  "  FROM policy a, ply_relation b, car349_q c "
				  " WHERE a.ipolicy = b.ipolicy "
				  "   AND b.fcard_class = '1' "
				  "   AND a.icard = c.icard "
				  " UNION "
				  " SELECT a.icard, a.nassured, a.iassured, b.dpolicy, a.iengine, a.itag, "
				  " b.fcomp_class, b.icar_type, a.dbirth, (SELECT CAST(sum(mins_premium) AS INTEGER) FROM newa22:ply_ins_type WHERE ipolicy = a.ipolicy), "
				  " (SELECT CAST(sum(mdamage_cover) AS INTEGER) FROM newa22:ply_ins_type WHERE ipolicy = a.ipolicy), (SELECT nname FROM officer WHERE iofficer = b.ileader), "
				  " b.ileader, (SELECT nbranch FROM sa_branch_type WHERE ibranch = b.iquota) "
				  "  FROM newa22:policy a, newa22:ply_relation b, car349_q c "
				  " WHERE a.ipolicy = b.ipolicy "
				  "   AND b.fcard_class = '1' "
				  "   AND a.icard = c.icard "
				  " UNION "
				  " SELECT a.icard, a.nassured, a.iassured, b.dpolicy, a.iengine, a.itag, "
				  " b.fcomp_class, b.icar_type, a.dbirth, (SELECT CAST(sum(mins_premium) AS INTEGER) FROM newa33:ply_ins_type WHERE ipolicy = a.ipolicy), "
				  " (SELECT CAST(sum(mdamage_cover) AS INTEGER) FROM newa33:ply_ins_type WHERE ipolicy = a.ipolicy), (SELECT nname FROM officer WHERE iofficer = b.ileader), "
				  " b.ileader, (SELECT nbranch FROM sa_branch_type WHERE ibranch = b.iquota) "
				  "  FROM newa33:policy a, newa33:ply_relation b, car349_q c "
				  " WHERE a.ipolicy = b.ipolicy "
				  "   AND b.fcard_class = '1' "
				  "   AND a.icard = c.icard "
				  " UNION "
				  " SELECT a.icard, a.nassured, a.iassured, b.dpolicy, a.iengine, a.itag, "
				  " b.fcomp_class, b.icar_type, a.dbirth, (SELECT CAST(sum(mins_premium) AS INTEGER) FROM newa40:ply_ins_type WHERE ipolicy = a.ipolicy), "
				  " (SELECT CAST(sum(mdamage_cover) AS INTEGER) FROM newa40:ply_ins_type WHERE ipolicy = a.ipolicy), (SELECT nname FROM officer WHERE iofficer = b.ileader), "
				  " b.ileader, (SELECT nbranch FROM sa_branch_type WHERE ibranch = b.iquota) "
				  "  FROM newa40:policy a, newa40:ply_relation b, car349_q c "
				  " WHERE a.ipolicy = b.ipolicy "
				  "   AND b.fcard_class = '1' "
				  "   AND a.icard = c.icard "
				  " UNION "
				  " SELECT a.icard, a.nassured, a.iassured, b.dpolicy, a.iengine, a.itag, "
				  " b.fcomp_class, b.icar_type, a.dbirth, (SELECT CAST(sum(mins_premium) AS INTEGER) FROM newa66:ply_ins_type WHERE ipolicy = a.ipolicy), "
				  " (SELECT CAST(sum(mdamage_cover) AS INTEGER) FROM newa66:ply_ins_type WHERE ipolicy = a.ipolicy), (SELECT nname FROM officer WHERE iofficer = b.ileader), "
				  " b.ileader, (SELECT nbranch FROM sa_branch_type WHERE ibranch = b.iquota) "
				  "  FROM newa66:policy a, newa66:ply_relation b, car349_q c "
				  " WHERE a.ipolicy = b.ipolicy "
				  "   AND b.fcard_class = '1' "
				  "   AND a.icard = c.icard "
				  " UNION "
				  " SELECT a.icard, a.nassured, a.iassured, b.dpolicy, a.iengine, a.itag, "
				  " b.fcomp_class, b.icar_type, a.dbirth, (SELECT CAST(sum(mins_premium) AS INTEGER) FROM newa70:ply_ins_type WHERE ipolicy = a.ipolicy), "
				  " (SELECT CAST(sum(mdamage_cover) AS INTEGER) FROM newa70:ply_ins_type WHERE ipolicy = a.ipolicy), (SELECT nname FROM officer WHERE iofficer = b.ileader), "
				  " b.ileader, (SELECT nbranch FROM sa_branch_type WHERE ibranch = b.iquota) "
				  "  FROM newa70:policy a, newa70:ply_relation b, car349_q c "
				  " WHERE a.ipolicy = b.ipolicy "
				  "   AND b.fcard_class = '1' "
				  "   AND a.icard = c.icard ");
		
		rc = unload_file(outputf," ",sfilename,stitle,stmt);
		
		if (rc != SUCCESS)
     	{
         	sprintf(errMsg,"��Ʀ걵���ѡA���~�T���G%s", sqlca.sqlerrm);
         	return rc;
     	}
		
	}
	else
	{
		sprintf_s(stmt2, sizeof stmt2, "SELECT itag, iengine FROM car349_q");
		$PREPARE pre_q5 FROM $stmt2;
		$DECLARE cur_q5 CURSOR FOR pre_q5;
		$OPEN cur_q5;
		
		while(1)
		{
			$FETCH cur_q5 INTO $itag_temp, $iengine_temp;
			
			if(SQLCODE == SQLNOTFOUND) break;
			
			strcpy(itag_temp, trim(itag_temp));
			strcpy(iengine_temp, trim(iengine_temp));
			
			printf("itag_temp = [%s], iengine_temp = [%s]\n", itag_temp, iengine_temp);
			
			if(strcmp(itag_temp, "") == 0 && strcmp(iengine_temp, "") != 0) /* �p�G����������X�A���S�񨮵P*/
			{
				sprintf_s(stmt4, sizeof stmt4, " AND a.iengine = '%s' ", iengine_temp);
			}
			else
			{
				sprintf_s(stmt4, sizeof stmt4, " AND a.itag = '%s' ", itag_temp);
			}
			
			for(k=0; k<count_db; k++)
			{
				sprintf_s(stmt3, sizeof stmt3,
					  "INSERT INTO car349_temp "
					  " SELECT a.icard, a.nassured, a.iassured, b.dpolicy, a.iengine, a.itag, "
					  " b.fcomp_class, b.icar_type, a.dbirth, (SELECT sum(mins_premium) FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy), "
					  " (SELECT sum(mdamage_cover) FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy), (SELECT nname FROM officer WHERE iofficer = b.ileader), "
					  " b.ileader, (SELECT nbranch FROM sa_branch_type WHERE ibranch = b.iquota) "
					  "  FROM %s:policy a, %s:ply_relation b "
					  " WHERE a.ipolicy = b.ipolicy "
					  "   AND b.fcard_class = '1' "
					  "   AND b.dpolicy BETWEEN '%s' AND today "
					  "  %s  ",
					  list[k].dbname, list[k].dbname, list[k].dbname, list[k].dbname, dpolicy_input, stmt4);
					  
				printf("stmt3 = [%s]\n", stmt3);
				
				$PREPARE pre_q5_2 FROM $stmt3;
				$EXECUTE pre_q5_2;
				$FREE pre_q5_2;
				
			}
			
		}
		
		$CLOSE cur_q5;
		$FREE  cur_q5;
		
		sprintf_s(stmt, sizeof stmt, "SELECT * FROM car349_temp ");
		
		rc = unload_file(outputf," ", sfilename, stitle, stmt);
		
		if (rc != SUCCESS)
     	{
         	sprintf(errMsg,"��Ʀ걵���ѡA���~�T���G%s", sqlca.sqlerrm);
         	return rc;
     	}
		
		$DROP TABLE car349_temp;
	}
	
	return M_CM_OK;
	
errexit:
    printf("SQLCODE=[%ld] sqlerrm=[%s]\n", SQLCODE, sqlca.sqlerrm);
    EWRITE(userid, SQLCODE, sqlca.sqlerrm);
    exit(1);
}
/****************************************************************************************************/
char *get_car_full_db(sIpolicy)
char *sIpolicy;
{
  char sTmpScomp[BRANCH_ID], sTmpcomp[BRANCH_ID];
  char sTmp_db_name[21];

  sTmp_db_name[0]='\0';
  if (*sIpolicy != '\0' && *sIpolicy !=' ')
  {
     sTmp_db_name[0]='\0';
     strncpy(sTmpScomp, sIpolicy+2, 1); sTmpScomp[1]='\0';
     strcpy(sTmpcomp, get_upcomp(sTmpScomp, USE_SHORT_BRANCH_ID,
            USE_BRANCH_ID));
     strcpy(sTmp_db_name, get_full_dbname(sTmpcomp));
  }
  return sTmp_db_name;
}