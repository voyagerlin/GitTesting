/****************************************************
 *   Program ID: ca409q01s.ec
 *   ����      : ���妸�C�L
 *               ca_rpt_endorse in ca_rpt_endorse.ec
 *
 ****************************************************/
#include <stdio.h>
#include <string.h>
#include <math.h>
#include "api_xsrv.h"
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include <malloc.h>
#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"
#include "safeclib.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"

#define TRUE    1
#define FALSE   0

#define _MSG860731
#define _M860731

#define _E_EDR_TII  /* �O�o��ñ�� */

$char DBName[5], outputf[21], userid[11];
$char g_sFormTp[3];
 char  FormTp[3];
 int   max_count=0;
$long g_nIendorse,g_nIendorse_eedr;
$int PgLine;
char ptr[2];
$date  Today;
$char sIpolicy[21];
$char   cIpolicy[21];
$char sIendorseBgn[ENDORSE_NUM], sIendorseEnd[ENDORSE_NUM];
$char stmt_buf[1024];
$char iForm_Tp[2], filename[101], sMsg[512], aphome[40];
char data_source[2] = "";
DBinfo  *list;
int    count_db;

extern char g_sFile[33];
$char  sFullDBName[40],v_sMsg[256]="";
$char g_sFedr_class[2], g_sIedr_field[9], opt_feedr[2], iMB[2],g_fmask_yn[2], feedr_show[2];
$long g_lMedrdmg_prem, g_lMedrlia_prem;
extern int iedr_row; /* �@�i��檺���,��ca_rpt_endorse��MAX_ROW+TOTAL_LINE+MAX_EDR_ROW�[�` */
long ca_rpt_pa_edr();
char fmask[2],fFreeForm[2]="";
$char kpid[12]="";
/*************************************************************************/
main(argc, argv)
int argc;
char **argv;
{
  int   fStat,i,fGet_kpid_ok;
  long  rc, rtncode;
  $int  iCount=0;
  $char sUserid[11], FullGetName[301], sdelimiter[2];

  batchinit();

  strcpy(DBName,       isNULLstr(argv[1]));
  strcpy(userid,       isNULLstr(argv[2]));
  strcpy(sUserid,      userid);         
  strcpy(sIendorseBgn, isNULLstr(argv[3]));
  strcpy(sIendorseEnd, isNULLstr(argv[4]));

  if(*sIendorseEnd == ' ' || *sIendorseEnd == '\0')
    strcpy(sIendorseEnd, sIendorseBgn);
  if(*sIendorseBgn == '*')
     strcpy(sIendorseBgn,"                ");
  if(*sIendorseEnd == '*')
    strcpy(sIendorseEnd, "~~~~~~~~~~~~~~~~");   

  strcpy(ptr,          isNULLstr(argv[5]));
  strcpy(data_source,  isNULLstr(argv[6]));   /* i:��J��渹�_�W, f:����r����J�ɦW, u:���C�L���G���e3�X, 
                                                 g:��ﴣ�Ѥ��-�C�L���G���H��, x:�q�l���Ƶ{���� */
  strcpy(filename,     isNULLstr(argv[7]));   /* i:��J��渹�_�W=" ", f:����r����J�ɦW, u:���C�L���G���e3�X,
                                                 g:��ﴣ�Ѥ��-�C�L���G���H�� */
  strcpy(opt_feedr,    isNULLstr(argv[8]));   /* �q�l���ﶵ */
  strcpy(iMB,          isNULLstr(argv[9]));   /* M��ʰ���(Manual)�AA�Ƶ{������(Auto) */ 
  strcpy(fmask,        isNULLstr(argv[10]));  /* 1:�Ӹ�B�n, 0:���B    */ 
  strcpy(fFreeForm,    isNULLstr(argv[11]));  /* 1:FreeForm 0:��FORM */ 
  strcpy(kpid,         isNULLstr(argv[12]));  /* kpid for FreeForm   */ 
  
  strcpy(outputf,      isNULLstr(argv[13]));

  # ifdef _M860731    
       printf("{car409_build.001}:before:bgn[%s],end[%s]\n",sIendorseBgn,sIendorseEnd);
  # endif
  printf("DBName[%s]\n"      , DBName);
  printf("userid[%s]\n"      , userid);
  printf("sUserid[%s]\n"     , sUserid);
  printf("sIendorseBgn[%s]\n", sIendorseBgn);
  printf("sIendorseEnd[%s]\n", sIendorseEnd);
  printf("ptr[%s]\n"         , ptr);
  printf("data_source[%s]\n" , data_source);
  printf("filename[%s]\n"    , filename);
  printf("opt_feedr[%s]\n"   , opt_feedr);
  printf("iMB[%s]\n"         , iMB);
  printf("fmask[%s]\n"       , fmask);
  printf("1 fFreeForm[%s]\n" , fFreeForm);
  printf("kpid=[%s] \n"      , kpid ); 
  printf("outputf[%s]\n"     , outputf);

  $WHENEVER SQLERROR GOTO errexit;

   rc=0;  rtncode=0;  fStat=0;
   strcpy(v_sMsg,""); 
   strcpy(feedr_show, opt_feedr); /*��ܦbcmn545�u�O�_�q�l�O��v���G�w�]�P�u���s�q�l���v�ﶵ */

   if(db_select(DBName) == False) 
   {
       rtncode = M_CM_DB_NOTOPEN;
       strcpy( v_sMsg, cm_get_errmsg(rtncode));
       goto errexit;
   }

   strcpy(g_fmask_yn, "Y");
   if (fmask[0]=='0')
   {
       strcpy(g_fmask_yn, "N");
   }
   
   if ((ptr[0]=='1') && (fFreeForm[0]=='1'))
   {  
       printf("--trace kpid 1 =[%s]\n",kpid);

       /* car409 �Ƶ{ (car409.sh)�A�LClient�ݬG�L�k��kpid�� */
       if (strlen(trim(kpid))==0)
       {
            
            /*$BEGIN WORK;*/ /* ���� kpid, �קK���~�]Rollback�ɭP kpid ����ϥΨӼg�Jtable */ 

            i = 0;
       RETRY:

            rtncode = cm_get_serial_num("CM", "FREEFORM","0","00",cm_cdate_str_100(cm_today()), kpid);
            if (rtncode != 0) 
            {
                if (rtncode == 1 || rtncode == 2)
                {
                    rtncode = M_CM_DB_NOTOPEN;
                    strcpy( v_sMsg, "[kpid�������~]");
                    strcat( v_sMsg, cm_get_errmsg(rtncode));
                    goto errexit; 
                }

                printf("--trace cm_get_serial_num i=[%d]\n",i);
                    
                i++;
                if (i > 3) 
                { 
                    if (rtncode == 3)
                    {
                        strcpy( v_sMsg, "[kpid�������~]"); 
                        rtncode = M_CMN_NAUTONUMBERING; 
                        strcat( v_sMsg, cm_get_errmsg(rtncode));
                    }
                    else
                    {
                        sprintf_s(v_sMsg, sizeof v_sMsg, "[kpid�������~]rtncode=[%ld] = ",rtncode); 
                    }    
                    goto errexit;  
                }

                sleep(1);
                goto  RETRY;
            }            

            /*$COMMIT WORK;*/
        }  
        
        printf("--trace kpid 2 =[%s]\n",kpid);        

        /* INSERT cm_freeform     ����Ǹ�    �I�O       �M�L�O    �C�L�O(0:�C�L 1:�w��) �����O(F:���� P:�ɦL) �Ӹ�����(Y/N)  ���C�L�Ƶ�(������) �C�L����O(������) �O�榬�ڥ��ƥ�  �O��O    �C�L���ڧO   �L�����N��  �{���W��   ����H��   ����ɶ�  �����ɶ� */
        $INSERT INTO cm_freeform (kpid   , iins_cat, formid     , fprint        ,fformal            , fhide       ,fnote         ,fbranch        ,fpolicy ,fcondition, iprinter,ipgid   ,iupdate  ,tstime  ,tetime)
                          VALUES ($kpid  , 'C'     , 'CARPLY001', '0'           ,'F'                , $g_fmask_yn ,' '           ,' '            ,' '     , ' '      , ' '     ,'car409',$sUserid ,current ,current);

   }   


   fStat = getApHome(aphome);
   if (fStat<0) 
   {
       rtncode = M_CM_READ_CONFIG_ERR;
       sprintf_s(v_sMsg, sizeof v_sMsg, "%s:%s",cm_get_errmsg(rtncode),aphome);
       goto errexit;      
   }

   if( data_source[0] == 'f') /* ��r�ɦW */
   {
   	   $EXECUTE IMMEDIATE "DROP TABLE IF EXISTS t409a"; 
       $CREATE temp TABLE t409a
       ( iendorse                   char(20) /* ��� */
       ) with no log;
 
       sprintf_s(FullGetName, sizeof FullGetName, "%s/dat/car/%s", aphome, filename);

       strcpy( sdelimiter,  "\t");
       if ((fStat=load_command1( FullGetName, outputf, "t409a", sdelimiter)) != SUCCESS)
       {
           rtncode = 0;
           sprintf_s(v_sMsg, sizeof v_sMsg, "Loading File[%s] Fail fStat[%d]\n", FullGetName, fStat);           
           goto errexit;
       }
   }

   if ( (list=get_db_list(&count_db,DBName)) == (char*)0 )
   {
        rtncode = M_CM_NOT_DBLIST;
        strcpy( v_sMsg, cm_get_errmsg(M_CM_NOT_DBLIST));
        goto errexit;   
   }


   strcpy(ptr,trim(ptr));

   if (ptr[0]=='1')  /* �L��� */
   {                     

        printf("before car409_build\n"); strcpy(v_sMsg," ");
        rtncode = car409_build(sIendorseBgn, sIendorseEnd, sUserid,v_sMsg);
        printf("car409_build rtncode[%ld]\n",rtncode);
        
        if (rtncode != M_CM_OK)
        {
            /*
            if (rtncode > 0)  *�bcar409_build() �w�g���g�J cm_freeform_dtl 199 ���A�F *
            {
                sprintf_s(v_sMsg, sizeof v_sMsg,"�C�L�����\�Э��աG%s", cm_get_errmsg(rtncode));
            }*/            
            goto errexit;
        }

        if (fFreeForm[0]=='1')
        {
            /*
            * UPDATE cm_freeform.tetime *
            $UPDATE cm_freeform SET tetime = current WHERE kpid = $kpid;
    
            *strcpy(outputf , outputf_ori);
            EWRITE(sUserid, 0, "FreeForm �榡�Ц� cmn545 �˵�");*
            $DELETE FROM gb_schedulelog WHERE kpid = $outputf;
            */
        }
        else
        {
            if((rtncode=save_form_info(F_FREE,"CA",409,sUserid,iForm_Tp,g_nIendorse*72,outputf))<0)
            {
                EWRITE(sUserid, rtncode,"save_form_info failed");
                exit (1);
            }            
        }
        
   }
   /*   
   else if (strcmp(ptr,"2")==0) * �L�ˮ`�I��� * *�w����*
   {
        printf("car409_build_pa\n");
        rtncode=car409_build_pa();

        if (rtncode == M_CA_NREL_PLY)
        {
             EWRITE(sUserid, rtncode, "�䤣�즹�O�渹!");
             *return rtncode;*
             exit (1);
        }
        else if (rtncode == M_CM_NOT_FOUND)
        {
             EWRITE(sUserid, rtncode, "�нT�{���L�ӫO�ˮ`�I!");
             *return rtncode;*
             exit (1);
        }
        else if (rtncode != M_CM_OK)
        {
             EWRITE(sUserid, rtncode, "�C�L�����\�Э��դ@��!");
             *return rtncode;*
             exit (1);
        }

        printf("Begin save_form_info \n");
        if (rtncode=(save_form_info(F_FREE,"CA",409,sUserid,iForm_Tp,max_count,outputf))<0)
        {
             EWRITE(sUserid,rtncode,"save_form_info failed");
             exit (1);
        }     
   }*/
   else if (ptr[0]=='3')  /* car9809141 �L�l�H���� */
   {
        rtncode = car409_build_mail_label();
        if (rtncode == M_CM_NOT_FOUND)
        {
             strcpy(v_sMsg, "��Ƨ䤣��!");
             goto errexit;
             /*EWRITE(sUserid, rtncode, "��Ƨ䤣��!");
             return rtncode;
             exit (1);*/
        }
        else if (rtncode != M_CM_OK)
        {
             
             goto errexit;            
             /*
             EWRITE(sUserid, rtncode, "�C�L����!");
             return rtncode;
             exit (1);
             */
        }
        if (rtncode=(save_form_info(F_FREE,"CA",409,sUserid,iForm_Tp,max_count,outputf))<0)
        {
             EWRITE(sUserid,rtncode,"save_form_info failed");
             exit (1);
        }     
   }


   # ifdef _M860731
       printf("{car409_build.002}:after:bgn[%s],end[%s]\n",sIendorseBgn,sIendorseEnd);
   # endif

   printf("before exit main\n");
   /*return;*/
   exit(0);

errexit:

   printf("{car409_build} rtncode = [%ld]\n",rtncode);
   printf("{car409_build} v_sMsg  = [%s]\n",v_sMsg);
   printf("{car409_build} SQLCODE = [%ld],sqlerrm=[%s]\n",SQLCODE, sqlca.sqlerrm);

   if ((rtncode==-239)&& (strlen(v_sMsg)>0))
   {
       rtncode = 0;
       printf("{car409_build} v_sMsg  = [%s]\n",v_sMsg);
   }


   if (SQLCODE < 0) /* sql runtime error*/
   {       
       sprintf_s(v_sMsg, sizeof v_sMsg,"SQL ERROR�GSQLCODE=[%ld]�Asqlerrm=[%s]", SQLCODE, sqlca.sqlerrm);  

   }
   else if (rtncode < 0)
   {
       sprintf_s(v_sMsg, sizeof v_sMsg,"SQL ERROR�G(rtncode=[%ld])", rtncode);
   }

   if (strlen(v_sMsg)==0)
   {
      if (rtncode > 0)
      {
          if (rtncode==M_CM_NOT_FOUND)
          {
             strcpy( v_sMsg, "�L����ƥi�C�L�F�Y���q�l���B�w���s�Τw�H�e�A�h�L�k�A�C�L");
          }
          else
          {
             strcpy( v_sMsg, cm_get_errmsg(rtncode));
          }
      }

      if (strlen(v_sMsg)==0)
      {
          strcpy(v_sMsg, "�C�L���楢�ѡA�Э���");
      }             
   }

   
   if ((ptr[0]=='1') && (fFreeForm[0]=='1'))
   {   
              
       $WHENEVER SQLERROR CONTINUE;

       /* 1130412,feply���� opt_feedr �ﶵ��ܡA�D�n���ѭ��欰�u�q�l���v�ɡA���i�H�אּ�ϥίȥ�(��)�L�X�A���Y�O���欰�ȥ��A�h�u�i�L�X�ȥ� */
       /*  car409_build() �g�J�� cm_freeform �i��|�Q rollback�A�G�n�A���g�J�@���A�Y����(-239)�|CONTINUE  */
       /* INSERT cm_freeform     ����Ǹ�    �I�O       �M�L�O    �C�L�O(0:�C�L 1:�w��) �����O(F:���� P:�ɦL) �Ӹ�����(Y/N)  ���C�L�Ƶ�(������) �C�L����O(������) �O�榬�ڥ��ƥ�  �O��O    �C�L���ڧO   �L�����N��  �{���W��   ����H��   ����ɶ�  �����ɶ� 
       $INSERT INTO cm_freeform (kpid   , iins_cat, formid     , fprint        ,fformal            , fhide       ,fnote         ,fbranch        , fversion    ,fpolicy ,fcondition, iprinter,ipgid   ,iupdate  ,tstime  ,tetime)
                         VALUES ($kpid  , 'C'     , 'CARPLY001', '0'           ,'F'                , $g_fmask_yn ,' '           ,' '            , ' '         ,' '     , ' '      , ' '     ,'car409',$sUserid ,current ,current);
       */        
       /*$INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint ) VALUES ($kpid,'C',' ',' ',' ',$opt_feedr,'199',' ',' ','0',$v_sMsg,$sUserid,current);*/
       $INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint, fversion ) VALUES ($kpid,'C',' ',' ',' ',$feedr_show,'199',' ',' ','0',$v_sMsg,$sUserid,current,' ');
       
       $DELETE FROM gb_schedulelog WHERE kpid = $outputf;
       /*EWRITE(sUserid, 0, "FreeForm �榡�Ц� cmn545 �˵�");*/       
   }
   else
   {
       printf("rtncode = [%ld]\n",rtncode);
       printf("v_sMsg  = [%s]\n",v_sMsg);     
       EWRITE(sUserid, rtncode, v_sMsg);   
   }  

   exit (1);
} /* main */ 


/*************************************************************************/
long car409_build(p_sIendorseBgn, p_sIendorseEnd, sUserid,p_sMsg)
$char *p_sIendorseBgn, *p_sIendorseEnd, *sUserid,*p_sMsg;
{ 
   FILE   *report, *edr_file;
   $char stmt[4024], sFormFile[21], sOutFile[21], sIendorse[ENDORSE_NUM], sTmpBuf[254];
   $char sql[501], stmt1[2048], v_sMsg[256];
   $char ipolicy[21];
   $char swhere1[512],swhere1_1[512];
   char  FullLogName[50], LogName[30];
   long  lMprem_total, rc, iPgLine;
   short fHasData;
   int   i,ch;
   $char   sFullDBName[40], iassured[11];
   $char   edrFullName[64];
   $long iCount;
   $char sline[100];
   $int  iline; 
   $char buffer[256];
   int  insert_line;
   $long iline_bgn, iline_end;
   $char icomp_in[3],npassword[11],aemail_eply[51],nfile[51],tmobile_eply[21];
   $char dply_end[11],dply_begin[11],s_dpolicy_yr[5],s_dendorse_yr[5],iapplicant[11];  
   $char siserno[3],nedr_rkm[401],fdata[2],iendorse_ti[21];
   $char feedr[2],s_iofficer[11],s_ileader[11],s_icard[21];
   $int  iserno,fspeed=0,fnequipment_05=0;	
   $char sNplyidx1[256], sNplyidx2[1001], sNplyidx3[5001]; /* �q�l�O���ˮ���� */
   $char v_sMsg_tmp[1024];   

   $WHENEVER SQLERROR GOTO errexit;

   iPgLine = 0;
   g_nIendorse = 0;  
   g_nIendorse_eedr = 0;
   fHasData = FALSE;
   fnequipment_05 = 0;


   rc = 0; 

   if (fFreeForm[0]=='0')
   {  
      sprintf_s(LogName, sizeof LogName, "car409_err_%s.txt", outputf);
      sprintf_s(FullLogName, sizeof FullLogName,"%s/rptftp/%s", aphome, LogName);

      if ((report=fopen( FullLogName,"w"))==NULL)
      {
          sprintf_s(v_sMsg, sizeof v_sMsg, "Cannot open log file: %s\n", FullLogName);
          printf("%s", v_sMsg);
          EWRITE(sUserid, rc, M_CM_OPEN_FILE_FAIL);
          return M_CM_OPEN_FILE_FAIL;
      } 

      $SELECT nForm_File,iform_tp
         INTO $sFormFile,$iForm_Tp
         FROM Form
        WHERE ksys_grp = "CA" AND kPgmID = 409
          AND iform_tp = '1';

      strcpy(sFormFile, rtrim(sFormFile));
      sprintf_s(sOutFile, sizeof sOutFile, "%s.tx", outputf);

      rgu_init_report(sFormFile, sOutFile);
   }   
   
   $BEGIN WORK; 


   /* �q�l��沣�s����G (�Ƶ{���涷�P�ɲŦX1~4�A�Y����ʰ��涷�P�ɲŦX1~5)
      (1)�Y�O�欰�q�l�O�楲�����w���s���A
      (2)�Ŀ�q�l���
      (3)�|�����s�q�l���
      (4)���ӫO��̫�@�i���
      (5)�e���W��J������ */

   strcpy( swhere1, " ");
   strcpy( swhere1_1, " ");
   strcpy(sNplyidx1," "); strcpy(sNplyidx2," "); strcpy(sNplyidx3," ");

   if( opt_feedr[0] == '1') /* �q�l��� */
   {
        /* (2)�Ŀ�q�l���
           (3)�|�����s�q�l��� */
        /* ���A100�|�����s�q�l���PDF�A�i���s���sca_e_edr,cm_e_policy����� */

        /*1090525012_SC2 �O�o���߹q�l�O��{�ҤΦs�ҧ@�~���x�ظm*/
        
        strcpy( swhere1, " and exists(select 1 from edr_relation b where b.iendorse = a.iendorse and b.feedr = '1' and b.fcard_class = '2' ) "
                         " and not exists (select 1 from cm_e_policy c where c.ipolicy = a.ipolicy and c.iendorse = a.iendorse and iins_cat = 'C' and c.fstatus > 100 and c.ftype = '2') " ); 

        strcpy( swhere1_1, " and exists(select 1 from edr_relation b where b.iendorse = a.iendorse and b.feedr = '1' and b.fcard_class = '2' ) "
                           " and not exists (select 1 from cm_e_policy c where c.iendorse = a.iendorse and iins_cat = 'C' and c.fstatus > 100 and c.ftype = '2') " ); 


        $EXECUTE IMMEDIATE "DROP TABLE IF EXISTS t409b";
        $CREATE temp TABLE t409b
        ( ipolicy   char(20),
          iendorse  char(20), /* ��� */
          nplyidx1  varchar(255)   default ' ',
          nplyidx2  lvarchar(1000) default ' ',
          nplyidx3  lvarchar(5000) default ' '
        );
  
   }
   
   stmt[0] = '\0';
   if( data_source[0] == 'i')  /* ��J��渹�_�W */
   {
       for (i=0;i<count_db;i++)
       {
           if( opt_feedr[0] == '1') /* �q�l��� */
           {
                /* (2)�Ŀ�q�l���
                  (3)�|�����s�q�l��� */
                /* ���A100�|�����s�q�l���PDF�A�i���s���sca_e_edr,cm_e_policy����� */

                /*1090525012_SC2 �O�o���߹q�l�O��{�ҤΦs�ҧ@�~���x�ظm
                sprintf_s(swhere1, sizeof swhere1, " and exists(select 1 from %s:edr_relation b where b.iendorse = a.iendorse and b.feedr = '1' ) "
                                  " and not exists (select 1 from cm_e_policy c where c.ipolicy = b.ipolicy and c.iendorse = b.iendorse and iins_cat = 'C' and c.fstatus >100 and c.ftype = '2') ", list[i].dbname ); 
                */                  
                sprintf_s(swhere1, sizeof swhere1, " AND b.feedr = '1' "
                                  " AND not exists (select 1 from cm_e_policy c where c.ipolicy = b.ipolicy and c.iendorse = b.iendorse and iins_cat = 'C' and c.fstatus >100 and c.ftype = '2') ");
           }
           else
           {
                strcpy( swhere1, " ");
           }     

           sprintf_s(sql, sizeof sql, " SELECT a.iendorse "
                         "   FROM %s:endorsement a, %s:edr_relation b "
                         "  WHERE a.iendorse = b.iendorse AND ( (a.iendorse BETWEEN '%s' AND '%s') or (a.iendorse matches '%s' and a.iendorse matches '%s')) "
                         "    AND a.iendorse not like '%%CVP%%' "
                         "  %s \n ", 
                      	    list[i].dbname, list[i].dbname, p_sIendorseBgn, p_sIendorseEnd, p_sIendorseBgn, p_sIendorseEnd, swhere1);
           if( i!=count_db-1) strcat( sql, " union ");
           strcat( stmt, sql); 
       }
   }
   else if( data_source[0] == 'f')  /* ��J��渹�X��J�ɮצW�� */
   {
       sprintf_s(stmt, sizeof stmt, " SELECT a.iendorse FROM t409a a where 1=1 %s ", swhere1_1);
   }    
   else if( data_source[0] == 'u')  /* ���C�L���G���e3�X */
   {
       sprintf_s(stmt, sizeof stmt, " SELECT a.iendorse FROM edr_relation a"
                      "  WHERE a.iendorse like '%s%%' "
                      "    AND a.dendorse is null "
                      "    AND a.iendorse not like '%%CVP%%' %s ", trim(filename), swhere1);
   }                   
   else if( data_source[0] == 'g') /* ��ﴣ�Ѥ��-�C�L���G���H�� */
   {
       sprintf_s(stmt, sizeof stmt, " SELECT a.iendorse FROM edr_relation a"
                      "  WHERE a.iedr_examiner like '%s' "
                      "    AND a.fedr_print = '1' "
                      "    AND a.iendorse not like '%%CVP%%' %s ", trim(filename), swhere1);
   }                   
   else if( data_source[0] == 'x') /* A�Ƶ{������(Auto), data_source��x */ /*108.03.13 fix: �W�[ a.dcreate ���� */
   {   	
        
       sprintf_s(stmt, sizeof stmt, " SELECT a.iendorse FROM edr_relation a "
                    "  where a.iendorse not like '%%CVP%%' "
                    "    and a.dcreate >= today- 15 "
                    "    and a.feedr = '1' "
                    "    and not exists (select 1 from cm_e_policy c where c.ipolicy = a.ipolicy and c.iendorse = a.iendorse and iins_cat = 'C' and c.fstatus >100 and c.ftype = '2') ");
        
   }     

   printf("stmt[%s]\n", stmt);
   strcpy(v_sMsg,"");

   $PREPARE prep1 FROM $stmt;
   $DECLARE a409_cur CURSOR FOR prep1;
   $FREE prep1;
   printf("--trace FREE prep1\n");   
      
   $OPEN a409_cur;
   while(1)
   {
     $FETCH a409_cur INTO $sIendorse;
     if(SQLCODE == SQLNOTFOUND) break;

     printf("{car409_build.003} iendorse[%s],p_sIendorseBgn[%s],p_sIendorseEnd[%s]\n", 
                                sIendorse,p_sIendorseBgn,p_sIendorseEnd);
     

     strcpy(ipolicy, " "); strcpy(feedr, " "); strcpy(s_iofficer, " "); strcpy(s_ileader, " "); strcpy(s_icard, " ");
     strcpy(sFullDBName, get_car_full_db(sIendorse));
     strcpy(sFullDBName, trim(sFullDBName));
     fnequipment_05 = 0; /* �O�_���U�L�@����� */
     
     sprintf_s(stmt1, sizeof stmt1, 
                     "select a.ipolicy, CASE WHEN a.feedr ='1' THEN a.feedr ELSE '0' END, "
                     "       a.iofficer, a.ileader, CASE WHEN a.fcard_class ='1' THEN a.icard ELSE ' ' END ,"
                     "       CASE WHEN b.nequipment[5] = '1' AND a.iofficer[1]='B' AND (  "
                     "                   ( ( "
                     "                    EXISTS(SELECT 1 FROM %s:edr_ins_type WHERE iendorse = a.iendorse AND iins_type = '17' AND iedr_type in ('05','04')) AND "
                     "                    EXISTS(SELECT 1 FROM %s:edr_ins_type WHERE iendorse = a.iendorse AND iins_type = '19' AND iedr_type in ('05','04')) "
                     "                    ) OR ( "
                     "                    EXISTS(SELECT 1 FROM %s:edr_ins_type WHERE iendorse = a.iendorse AND iins_type = '17' AND iedr_type in ('02')) AND "
                     "                    EXISTS(SELECT 1 FROM %s:edr_ins_type WHERE iendorse = a.iendorse AND iins_type = '19' AND iedr_type in ('02')) "
                     "                    ) "
                     "                   ) AND "
                     "                    (NOT EXISTS(SELECT 1 FROM %s:edr_ins_type WHERE iendorse = a.iendorse AND iins_type NOT IN ('17','19')) ) "
                     "                 ) THEN 1 "
                     "            WHEN b.nequipment[5] = '1' AND a.iofficer[1]='J' AND "
                     "                 ( EXISTS(SELECT 1 FROM %s:edr_ins_type WHERE iendorse = a.iendorse AND iins_type = '17' AND iedr_type in ('05','04','02')) ) AND "
                     "                 ( NOT EXISTS(SELECT 1 FROM %s:edr_ins_type WHERE iendorse = a.iendorse AND iins_type <> '17') ) "
                     "                 THEN 1 "
                     "       ELSE 0 END "
                     "  from %s:edr_relation a, %s:endorsement b "
                     " where a.iendorse = b.iendorse and a.iendorse = '%s' " , 
                     sFullDBName,sFullDBName,sFullDBName,sFullDBName,sFullDBName,sFullDBName,sFullDBName,sFullDBName,sFullDBName, sIendorse);    
     printf("stmt1[%s]\n", stmt1);                
     $PREPARE prepfeedr FROM $stmt1;     
     $EXECUTE prepfeedr INTO $ipolicy, $feedr, $s_iofficer, $s_ileader, $s_icard, $fnequipment_05;
     
     /*
     sprintf_s(stmt1, sizeof stmt1, "select ipolicy, CASE WHEN feedr ='1' THEN feedr ELSE '0' END, "
                     "       iofficer, ileader, CASE WHEN fcard_class ='1' THEN icard ELSE ' ' END "
                     "  from %s:edr_relation"
                     " where iendorse = '%s'" , sFullDBName, sIendorse);
     $EXECUTE prepfeedr INTO $ipolicy, $feedr, $s_iofficer, $s_ileader, $s_icard;
     */       
     if(SQLCODE == SQLNOTFOUND)
     {
        sprintf_s(v_sMsg, sizeof v_sMsg, "�䤣����[%s](��Ʈw=[%s])!", sIendorse,sFullDBName);
        if (fFreeForm[0]=='1')
        {            
            printf(" stmt1[%s]\n", stmt1);
            printf(" v_sMsg[%s]\n", v_sMsg);
            
            /* �{��G1.���ק�欰�q�l�ίȥ��A�@�߳��i�H�bcar409�L�X�ȥ�
                   2. �Y��欰�q�l�G(1)�Y�bcar409�e�����Ŀ�u���s�q�l���v,�٬O�|�b�e���e�{��椺�e�A�åi�L�X�ȥ����A�����|�g�J cm_e_policy�A�i�J�ݲ��s�B�H�e�q�l��檬�A�C
                                 (2)�Y�bcar409�e���L�Ŀ�u���s�q�l���v,�٬O�|�b�e���e�{��椺�e�A�åi�L�X�ȥ����A�����|�g�J cm_e_policy�A
                                 (3)�u�n�O�q�l���A���O�b cm_e_policy �L�ӧ���ơA�άO�ӧ��b cm_e_policy ���A <=100 �ɡA�@�߷|�b���3�Icar409�Ƶ{���椤
                                    �g�J cm_e_policy�A�i�J�ݲ��s�B�H�e�q�l��檬�A�C

               �]���n�קאּ�G���ק�欰�q�l�ίȥ��AFreeForm����]�n�@�߳��i�H�bcar409�L�X�ȥ��A�]�N�O�bcmn545�n�i�H�e�{��椺�e�æC�L�X�C
               �ҥH==> �g�J cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint ) �ɡA"�O�_�q�l(feply)" ���n�@�ߩ� "0:�ȥ�"  
               (�H�U�g�J cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint ) ���{���X�W�h��P)
            */

            /*$INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint ) VALUES($kpid,'C',$ipolicy,$sIendorse,$s_icard,$feedr,'199',$s_iofficer,$s_ileader,'0',$sTmpBuf,$sUserid,current);*/
            $INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint, fversion ) VALUES($kpid,'C',$ipolicy,$sIendorse,$s_icard,$feedr_show,'199',$s_iofficer,$s_ileader,'0',$v_sMsg,$sUserid,current,' ');
        }
        else
        {    
            fprintf( report, "%s\n", v_sMsg);     
        }
        $FREE prepfeedr;
        continue;  
     } 
     $FREE prepfeedr;

     if (fFreeForm[0]=='1') /*1130412�G�[�ˮ�*/
     {
        if ((opt_feedr[0]=='1') && (feedr[0]=='0')) /* ���Ŀ�u���s�q�l���v�A�����欰�ȥ�=> �������*/
        {
            sprintf_s(v_sMsg, sizeof v_sMsg, "���[%s]���榡�쬰�ȥ��A���i���L�q�l���", sIendorse);
            $INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint, fversion ) VALUES($kpid,'C',$ipolicy,$sIendorse,$s_icard,$feedr_show,'199',$s_iofficer,$s_ileader,'0',$v_sMsg,$sUserid,current,' ');
            continue;
        }          
     }

     /*     
     $select ipolicy, feedr
        into $ipolicy, $feedr
        from edr_relation
       where iendorse = $sIendorse;
     */
     printf("ipolicy[%s], feedr[%s],fnequipment_05[%d]\n", ipolicy, feedr,fnequipment_05);

     /*1120927002_C02 �R�q�ΰӫ~�}�o*/
     if (strncmp(ipolicy+5,"ES",2)==0)     
     {
        if (fFreeForm[0]=='0')
        {
            sprintf_s(v_sMsg, sizeof v_sMsg, "�u�R�q�κ�X�O�I�v���[%s]�ȥi�ϥ� FreeForm �覡�C�L", sIendorse);
            fprintf( report, "%s\n", v_sMsg);     
            continue;             
        }
     }

     /* 1061108001_SC6_�t�X�s�еo�i���ߨt�λݨD���Ѭ����t�Υ\�� */
     iCount = 0;       
     strcpy(sFullDBName, get_car_full_db(ipolicy));
     sprintf_s(stmt1, sizeof stmt1, "select count(*) FROM %s:ply_ins_type"
                     " where ipolicy = '%s'"
                     "   and iins_type in ('157','158','159','160','171','172')" , sFullDBName, ipolicy);
     printf("stmt1[%s]\n", stmt1);
     $PREPARE prep157 FROM $stmt1;
     $EXECUTE prep157 INTO $iCount;
     $FREE prep157;     
     if (iCount > 0)
     {	
        sprintf_s(v_sMsg, sizeof v_sMsg, "���[%s]�u157/158/159 �I �� 171/172 �I�v���i�L�s�ȥ����ιq�l���(���榡)", sIendorse);
        if (fFreeForm[0]=='1')
        {
            printf(" v_sMsg[%s]\n", v_sMsg);            
            $INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint, fversion ) VALUES($kpid,'C',$ipolicy,$sIendorse,$s_icard,$feedr_show,'199',$s_iofficer,$s_ileader,'0',$v_sMsg,$sUserid,current,' ');
        }
        else
        {    
            fprintf( report, "%s\n", v_sMsg);     
        }
        continue;     	
     }   

     rc = chk_iendorse_status( sIendorse, v_sMsg);
     printf("rc[%d]\n", rc);

     if(rc != M_CM_OK)
     {
         if (fFreeForm[0]=='1')
         {
             printf("chk_iendorse_status v_sMsg[%s]\n", v_sMsg);
             /*$INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint ) VALUES($kpid,'C',$ipolicy,$sIendorse,$s_icard,$feedr,'199',$s_iofficer,$s_ileader,'0',$v_sMsg,$sUserid,current);*/
             $INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint, fversion ) VALUES($kpid,'C',$ipolicy,$sIendorse,$s_icard,$feedr_show,'199',$s_iofficer,$s_ileader,'0',$v_sMsg,$sUserid,current,' ');
         }
         else
         {    
            fprintf( report, "%s\n", v_sMsg);
         }        
         continue;
     }

     /*
     rc = chk_edr_dmg( ipolicy, sIendorse, v_sMsg);
     if(rc != M_CM_OK)
     {
         fprintf( report, "%s\n", v_sMsg);
         continue;
     }
     

     $select count(*)
        into $iCount
        from edr_relation a, edr_ins_type b
       where a.iendorse = b.iendorse
         and a.iendorse = $sIendorse
         and b.iedr_type = '05'
         and ((drate_ym::integer<=87 and nvl(dendorse,today)>'01/08/2018') or (drate_ym::integer=88 and nvl(dendorse,today)>'12/31/2017'))
         and iabn_type not in ('S','Y');

     if( iCount != 0)
     {
         sprintf_s(sTmpBuf, sizeof sTmpBuf, "���[%s]�O�v��87�A���I��20180108,�O�v88�A���I���20171231", sIendorse);
         fprintf( report, "%s\n", sTmpBuf);
         continue;
     }
     */

     sFullDBName[0] = '\0';
     strcpy(sFullDBName, get_car_full_db(sIendorse));

     printf("feedr[%s]\n", feedr);

     if( opt_feedr[0] == '1') /* �q�l��� */
     {
         if (fnequipment_05==0)
         {
            /* 1130313013_C01 �L�q�l�O��O���B�u���h�O�v�Ρu���P�v�A���i�۰ʲ��s�q�l�O��(fdata = P) */
            iCount = 0;
            $SELECT Count(*) INTO $iCount 
               FROM cm_e_policy                   
              WHERE ipolicy  = $ipolicy
                AND ftype = '2'
                AND fdata = 'P'
                AND fstatus >= 500 ;            
            if (iCount==0) /*�L�q�l�O��O�� */
            {                            
                $SELECT Count(*) INTO $iCount 
                   FROM ply_ins_type
                  WHERE ipolicy = $ipolicy
                    AND mdamage_cover > 0;                                
                if (iCount == 0) /* ���h�O */
                {
                    sprintf_s(v_sMsg, sizeof v_sMsg, "��渹[%s]���O��[%s]�S���q�l�O�椧�ǰe�O���A�B�̷s�O�檬�A�����P�ξ��h�O�A���i�C�L�q�l���", sIendorse, ipolicy);
                    if (fFreeForm[0]=='1')
                    {                        
                        $INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint, fversion ) VALUES($kpid,'C',$ipolicy,$sIendorse,$s_icard,$feedr_show,'199',$s_iofficer,$s_ileader,'0',$v_sMsg,$sUserid,current,' ');
                    }
                    else
                    {    
                        fprintf( report, "%s\n", v_sMsg);
                    } 
                    continue;
                }
            }
            

            /* (1)�Y�O�欰�q�l�O�楲�����w���s���A */

            iCount = 0;
            sprintf_s(stmt1, sizeof stmt1, "select count(*) FROM %s:ori_ply_relation"
                            " WHERE ipolicy = '%s' and feply in ('1','2') " , sFullDBName, ipolicy);
            printf("stmt1[%s]\n", stmt1);
            $PREPARE prepA1 FROM $stmt1;
            $EXECUTE prepA1 INTO $iCount;
            $FREE prepA1;
    /*
            $select count(*)
                into $iCount
                from ori_ply_relation
            where ipolicy = $ipolicy and feply in ('1','2');
    */         
            if( iCount != 0)
            {
                
                $select count(*)
                    into $iCount
                    from cm_e_policy a
                where a.ipolicy = $ipolicy
                    and a.iendorse = ' ';

                if( iCount == 0)
                {                 
                    sprintf_s(v_sMsg, sizeof v_sMsg, "���[%s]���O��[%s]���q�l�O�楲�����w���s���A", sIendorse, ipolicy);
                    if (fFreeForm[0]=='1')
                    {
                        /*$INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint ) VALUES($kpid,'C',$ipolicy,$sIendorse,$s_icard,$feedr,'199',$s_iofficer,$s_ileader,'0',$sTmpBuf,$sUserid,current);*/
                        $INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint, fversion ) VALUES($kpid,'C',$ipolicy,$sIendorse,$s_icard,$feedr_show,'199',$s_iofficer,$s_ileader,'0',$v_sMsg,$sUserid,current,' ');
                    }
                    else
                    {    
                        fprintf( report, "%s\n", v_sMsg);
                    } 
                    continue;
                }
            }
         }
         /* (4)���ӫO��̫�@�i��� */
         iCount = 0;
         sprintf_s(stmt1, sizeof stmt1,"select count(*) FROM %s:edr_relation"
                        " WHERE ipolicy = '%s' " 
                        "   AND dcreate > (select dcreate from %s:edr_relation where iendorse = '%s' ) "
                        "   AND iendorse not like '%%CVP%%'", 
                        sFullDBName, ipolicy,sFullDBName,sIendorse);
         printf("stmt1[%s]\n", stmt1);
         $PREPARE prepA2 FROM $stmt1;
         $EXECUTE prepA2 INTO $iCount;
         $FREE prepA2;
/*
         $select count(*)
            into $iCount
            from edr_relation
           where ipolicy = $ipolicy
             and dcreate > (select dcreate from edr_relation where iendorse = $sIendorse and iendorse not like '%CVP%' );
*/             
         if( iCount != 0)
         {
             /* �D�̫�@�i���,�R�������sPDF����� */
             $delete from cm_e_policy where ipolicy = $ipolicy and iendorse = $sIendorse and fstatus = 100; 
             $delete from ca_e_edr where iendorse = $sIendorse;

             sprintf_s(v_sMsg, sizeof v_sMsg, "���[%s]���q�l���A�������ӫO��[%s]�̫�@�i���", sIendorse, ipolicy);
           
             if (fFreeForm[0]=='1')
             {
                 /*$INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint ) VALUES($kpid,'C',$ipolicy,$sIendorse,$s_icard,$feedr,'199',$s_iofficer,$s_ileader,'0',$sTmpBuf,$sUserid,current);*/
                 $INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint, fversion ) VALUES($kpid,'C',$ipolicy,$sIendorse,$s_icard,$feedr_show,'199',$s_iofficer,$s_ileader,'0',$v_sMsg,$sUserid,current,' ');
             }
             else
             {    
                 fprintf( report, "%s\n", v_sMsg);     
             }             
             continue;
         }
     }


     sprintf_s(stmt1, sizeof stmt1, "SELECT iassured FROM %s:endorsement"
                     " WHERE iendorse = '%s'" , sFullDBName, sIendorse);
     printf("stmt1[%s]\n", stmt1);
     $PREPARE prepA FROM $stmt1;
     $EXECUTE prepA INTO $iassured;
     $FREE prepA;

     iCount = 0;
     $select count(*)
       into $iCount
       from cu_code_data
      where itype = 'CK'
        and icode = $sUserid;

     if( iCount == 0)
     {
        rc = chk_personal_deny( iassured, v_sMsg);
        if( rc != M_CM_OK)
        {
             if (fFreeForm[0]=='1')
             {
                 /*$INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint ) VALUES($kpid,'C',$ipolicy,$sIendorse,$s_icard,$feedr,'199',$s_iofficer,$s_ileader,'0',$v_sMsg,$sUserid,current);*/
                 $INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint, fversion ) VALUES($kpid,'C',$ipolicy,$sIendorse,$s_icard,$feedr_show,'199',$s_iofficer,$s_ileader,'0',$v_sMsg,$sUserid,current,' ');
             }
             else
             {    
                 fprintf( report, "��渹[%s],���~��][%s]\n", sIendorse, v_sMsg);
             }             
             continue;
        }
     }

     fHasData = TRUE;
     strcpy(sNplyidx1," "); strcpy(sNplyidx2," "); strcpy(sNplyidx3," "); strcpy(v_sMsg_tmp," ");

     if (fFreeForm[0] == '1')
     {
        rc = ca_freeform_endorse(sIendorse, &lMprem_total, opt_feedr, fmask, kpid);
        if(rc != M_CM_OK)
        {
            sprintf_s(v_sMsg, sizeof v_sMsg, "���[%s]�C�L�o�Ϳ��~(ca_freeform_endorse()�Grc=[%d],sqlerrm=[%s])", sIendorse, rc, sqlca.sqlerrm);
            /*$INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint ) VALUES($kpid,'C',$ipolicy,$sIendorse,$s_icard,$feedr,'199',$s_iofficer,$s_ileader,'0',$sTmpBuf,$sUserid,current);*/
            $INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint, fversion ) VALUES($kpid,'C',$ipolicy,$sIendorse,$s_icard,$feedr_show,'199',$s_iofficer,$s_ileader,'0',$v_sMsg,$sUserid,current,' ');
            continue;
        }

        if( opt_feedr[0] == '1' && feedr[0] == '1') /* �q�l��椺�e�n�[�W�u�̷s�O��v��� */
        {                        /*(sIpolicy, freprint, sIkind, iPrintList, iprint, PrintDlist, ProtectData, ipolicyB_type, freeform_kpid, iserl, feply, fprov, formid, ipgid, freceipt, v_nplyidx1, v_nplyidx2, v_nplyidx3, iendorse, v_sErrMsg)*/ 
            rc = ca_freeform_policy(ipolicy, " ", "0", "1", sUserid, "1", fmask, "0" ,kpid, " ", "1", "Y", " ", " ", "Y", sNplyidx1, sNplyidx2, sNplyidx3, sIendorse , v_sMsg_tmp);
                                   


            if (rc != M_CM_OK)
            {                 
                sprintf_s(v_sMsg, sizeof v_sMsg, "���[%s]�C�L�o�Ϳ��~(ca_freeform_policy()�Grc=[%d],errmsg=[%s])", sIendorse, rc, cm_get_errmsg(rc));
                $DELETE FROM ca_freeform WHERE kpid= $kpid And inumber = $sIendorse;
                $INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint, fversion ) VALUES($kpid,'C',$ipolicy,$sIendorse,$s_icard,$feedr_show,'199',$s_iofficer,$s_ileader,'0',$v_sMsg,$sUserid,current,' ');            
                continue;
            }            
        }   

        if(rc == M_CM_OK)
        {
            /*$INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint ) VALUES($kpid,'C',$ipolicy,$sIendorse,$s_icard,$feedr,'100',$s_iofficer,$s_ileader,'0',' ',$sUserid,current);*/
            $INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint, fversion ) VALUES($kpid,'C',$ipolicy,$sIendorse,$s_icard,$feedr_show,'100',$s_iofficer,$s_ileader,'0',' ',$sUserid,current,' ');
        }       

     }
     else
     {
        rc = ca_rpt_endorse(sIendorse, &lMprem_total, fmask);
        if(rc != M_CM_OK){
            sprintf_s(v_sMsg, sizeof v_sMsg, "���[%s] �C�L�����D(ca_rpt_endorse)", sIendorse);
            fprintf( report, "%s\n", v_sMsg);
            continue;
        }
        /*
        if (lMprem_total != 0) {
            * *** ���ڦC�L *** *
            rc = car401_body_receipt(sIendorse);
            if (rc!= M_CM_OK){
                sprintf_s(sTmpBuf, sizeof sTmpBuf, "���[%s] ���ڦC�L�����D", sIendorse);
                fprintf( report, "%s\n", sTmpBuf);
                continue;
            }
        }
        */

        rc = data_report(&iPgLine);
        if(rc != M_CM_OK){
            sprintf_s(v_sMsg, sizeof v_sMsg, "���[%s] �C�L�����D(data_report)", sIendorse);
            fprintf( report, "%s\n", v_sMsg);
            continue;
        }
     
        printf("------>debug8 sUserid[%s]\n", sUserid); 

        printf("B--------------------- iPgLine[%ld]\n",iPgLine);

        rc = drop_temp_table();
        if(rc != M_CM_OK){
            sprintf_s(v_sMsg, sizeof v_sMsg, "���[%s] �Ȧs��drop�����D", sIendorse);
            fprintf( report, "%s\n", v_sMsg);
            continue;
        }
     }

     printf("------>debug9 sUserid[%s]\n", sUserid); 

     /* 1001003001_C1 ���r�y����CVP�A�L�����(edr_relation.dendorse)�A�C�L����~�g�J�����(�浧�C�L) */
     sprintf_s(stmt1, sizeof stmt1, "UPDATE %s:edr_relation"
                     "   SET dendorse = today, fprint = '1'"
                     " WHERE iendorse = '%s'"
                     "   AND dendorse is null"
                     "   AND dedr_close is null"
                     "   AND iendorse not like '%%CVP%%'", sFullDBName, sIendorse);
     printf("stmt1[%s]\n", stmt1);
     $PREPARE prep2 FROM $stmt1;
     $EXECUTE prep2;
     $Free prep2;

     sprintf_s(stmt1, sizeof stmt1, "UPDATE %s:edr_relation"
                     "   SET fedr_print = '2' "
                     " WHERE iendorse = '%s'"
                     "   AND fedr_print = '1' " , sFullDBName, sIendorse);
     printf("stmt1[%s]\n", stmt1);
     $PREPARE prep4 FROM $stmt1;
     $EXECUTE prep4;
     $Free prep4;

     if( opt_feedr[0] == '1' && feedr[0] == '1') /* �q�l���, ���A100�|�����s�q�l���PDF�A�i���s���sca_e_edr,cm_e_policy����� */
     {
         if (fnequipment_05==0) /*�ư�(�������L)�U�L�@����*/
         {
            $insert into t409b values ($ipolicy,$sIendorse,$sNplyidx1,$sNplyidx2,$sNplyidx3);
            g_nIendorse_eedr++;
         }
     }

     g_nIendorse++;     /* �w�L���i�ƥ[�@ */
   }
   $CLOSE a409_cur; 
   $FREE  a409_cur; 

   if(fHasData == FALSE)
   {    
        strcpy(ipolicy," "); strcpy(sIendorse," "); 

        if (strlen(v_sMsg)==0 )
        {
            strcpy(v_sMsg, "�L����ƥi�C�L�C");            
        }
        else
        {
            trim_tail_white(v_sMsg);
            strcat(v_sMsg, "�G�L����ƥi�C�L�C");
        }
        printf("111\n");
        printf("p_sIendorseBgn[%s]\n", p_sIendorseBgn);
        printf("p_sIendorseEnd[%s]\n", p_sIendorseEnd);
        printf("data_source[%s]\n", data_source);
        if((opt_feedr[0]=='1') && ( data_source[0] == 'i') && (strlen(p_sIendorseBgn)==13) && (strncmp(p_sIendorseBgn, p_sIendorseEnd,13)==0))
        {
            printf("222\n");
            strcpy(sFullDBName, get_car_full_db(p_sIendorseBgn));
            strcpy(sFullDBName, trim(sFullDBName));            
            
            sprintf_s(stmt1, sizeof stmt1, "SELECT ipolicy,iendorse FROM %s:edr_relation"
                            " WHERE iendorse = '%s'"
                            "   AND feedr = '0' " , sFullDBName, p_sIendorseBgn);
            printf("stmt1[%s]\n", stmt1);
            $PREPARE prepNG FROM $stmt1;
            $EXECUTE prepNG Into $ipolicy,$sIendorse;
            $Free prepNG;
            printf("ipolicy[%s]sIendorse[%s]\n", ipolicy,sIendorse);
            if (strlen(ipolicy)>3)
            {
                sprintf_s(sTmpBuf, sizeof sTmpBuf, "���[%s]���榡�쬰�ȥ��A���i���L�q�l���C",trim(sIendorse));   
                trim_tail_white(sTmpBuf);
                strcat(v_sMsg, sTmpBuf);  
                printf("v_sMsg22[%s]\n", v_sMsg);              
                
                strcpy(feedr_show,"0");
            }            
        }

        rc = M_CM_NOT_FOUND;  

        if (fFreeForm[0]=='0')        
        {   
            /*       
            rc = M_CM_NOT_FOUND;            
            EWRITE(sUserid, rc, "�L����ƥi�C�L");*/
            EWRITE(sUserid, rc, v_sMsg); 

            /*fclose(report);        
            $ROLLBACK WORK;*/
            /*exit(1);*/

            goto errexit;
        }
        else
        {
            /* �� fHasData == FALSE�A���e���ˮ֥i��w���g�J���~ 199 */
            iCount = 0;  
            $SELECT count(*) Into $iCount  FROM cm_freeform_dtl WHERE kpid = $kpid AND iendorse <> '' and fstatus = 199;
            /*$INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint ) VALUES($kpid,'C',' ',' ',' ',$opt_feedr,'199',' ',' ','0','�L����ƥi�C�L',$sUserid,current);*/
            /*$INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint ) VALUES($kpid,'C',' ',' ',' ','0','199',' ',' ','0','�L����ƥi�C�L',$sUserid,current);*/
            if (iCount ==0 )
            {
                $INSERT INTO cm_freeform_dtl (kpid, iins_cat, ipolicy, iendorse, icard, feply, fstatus, iofficer, ileader, iserl, nnote, iprint, dprint, fversion ) VALUES($kpid,'C',$ipolicy,$sIendorse,' ',$feedr_show,'199',' ',' ','0',$v_sMsg ,$sUserid,current,' ');
            }
        }
   }
   else
   {
        printf("--trace x fFreeForm=[%s]\n",fFreeForm);
        
        if (fFreeForm[0] == '0')
        {
            fclose(report);        
            rgu_finish_report();
            rc=rptftpinsert( sUserid,"car409",LogName);
            printf("rptftpinsert rc[%d]\n", rc);
            if (rc!=0)
            {
                sprintf_s(v_sMsg, sizeof v_sMsg,"%s�g�Jrptftplist���~\r\n", LogName);
                EWRITE(sUserid, rc, v_sMsg);
            }
        }

        printf("--trace g_nIendorse_eedr=[%ld]\n",g_nIendorse_eedr);
        
        if( opt_feedr[0] == '1') /* �q�l��� */
        {
            if (g_nIendorse_eedr > 0)
            {    
                /* ���A100�|�����s�q�l���PDF�A�i���s���sca_e_edr,cm_e_policy����� */            
                $delete from cm_e_policy
                    where exists (select 1 from t409b b where cm_e_policy.ipolicy = b.ipolicy and cm_e_policy.iendorse = b.iendorse)
                    and iendorse!=''
                    and fstatus = 100;

                if(fFreeForm[0] != '1')
                {
                    fclose(edr_file);                  
                    $delete from ca_e_edr where exists (select 1 from t409b where iendorse = ca_e_edr.iendorse);
                
                    $EXECUTE IMMEDIATE "DROP TABLE IF EXISTS aaa";
                    $select * from ca_e_edr where 1=0 into temp aaa;

                    /* �N���ͪ���r�ɧ����J�q�l���table�A���ѵ�car_eply���͹q�l��� */
                    sprintf_s(edrFullName, sizeof edrFullName,"%s/batchfile/%s", aphome, sOutFile);
                    printf("edrFullName[%s]\n", edrFullName);
                    if ((edr_file=fopen( edrFullName,"r"))==NULL)
                    {
                        if (fFreeForm[0]=='1')
                        {     
                            printf("--trace fopen Error[%s]\n",edrFullName);               
                        }
                        else
                        {
                            EWRITE(sUserid, rc, M_CM_OPEN_FILE_FAIL);               
                        }  
                        fclose(edr_file);
                        sprintf_s(v_sMsg, sizeof v_sMsg, "Cannot open log file: %s\n", edrFullName);
                        printf("%s", v_sMsg);

                        return M_CM_OPEN_FILE_FAIL;
                    }

                    iline=0;
                    printf("iedr_row[%d]\n", iedr_row);
                    
                    insert_line=i=0;
                    while ( (ch=fgetc(edr_file)) != EOF) {
                        printf("%c", ch);
                        if(ch=='\"') /* ���޸� */
                        {
                            insert_line++;
                            if( insert_line%2==0)
                            {
                                buffer[i]=0;
                                printf("buffer[%s]\n", buffer);
                                iline++;
                                if (fFreeForm[0] == '1')
                                {
                                    $insert into aaa values($kpid,$iline,$buffer);
                                }
                                else
                                {
                                    $insert into aaa values($outputf,$iline,$buffer);
                                }   
                                buffer[0]=0;
                                insert_line=i=0;
                            }
                            continue;
                        }
                        else
                        {
                            if( insert_line%2==1)
                            {
                                buffer[i]=ch;
                                i++;
                                continue;
                            }
                            else continue;
                        }
                    }

                    $declare cur1 cursor for
                        select a.iline, a.itext, a.itext[63,65]||a.itext[68,77]
                        from aaa a
                        WHERE a.itext LIKE '%17%��%��%' ORDER BY a.iline;

                    $open cur1;
                    for(;;)
                    {
                        $fetch cur1 into $iline, $buffer, $sIendorse;
                        if(SQLCODE == SQLNOTFOUND) break;

                        $select min(iline)-7
                            into $iline_end
                            from aaa where iline>$iline and itext LIKE '%17%��%��%';

                        iline_bgn = iline-7+1;
                        printf("%d, %d\n", iline_bgn, iline_end);
                        if (risnull(SQLINT, &iline_end) == 1)
                        {
                            $update aaa
                                set iendorse = $sIendorse
                                where iline >= $iline_bgn;
                        }
                        else
                        {
                            $update aaa
                                set iendorse = $sIendorse
                                where iline between $iline_bgn and $iline_end;
                        }
                    }
                    $CLOSE cur1;
                    $FREE  cur1;

                
                    $insert into ca_e_edr
                        select * from aaa;
                }

                strcpy(sNplyidx1," "); strcpy(sNplyidx2," "); strcpy(sNplyidx3," "); strcpy(v_sMsg_tmp," ");

                $declare cur2 cursor for
                    select ipolicy, iendorse, nplyidx1, nplyidx2, nplyidx3
                    from t409b;
                $open cur2;
                for(;;)
                {
                    $fetch cur2 into $ipolicy, $sIendorse,$sNplyidx1,$sNplyidx2,$sNplyidx3;
                    if(SQLCODE == SQLNOTFOUND) break;

                    printf("-- trace xxxxx ipolicy[%s]\n ",ipolicy);
                    printf("-- trace xxxxx sIendorse[%s]\n ",sIendorse);
                        

                    /* 1080417001_SC2 �s�W�q�l�O��H²�T�覡�o�e */           
                    /* 1070125001-SC6-�j��T���d���I�q�l���O�I�һ{�ҥ��x�Χ�O�t�ζ}�o(���) 
                        => �ק�u�q�l��椧�K�X�v�W�h�����Q�O�I�HID�� (�쬰�n�O�HID�᤭�X) */ 
                    /*                                                                    right(rtrim(b.iapplicant),5) */ 
                    strcpy(dply_end," "); strcpy(dply_begin," ");
                    strcpy(s_dpolicy_yr," "); strcpy(s_dendorse_yr," ");

                    printf("-- trace xxxxx sFullDBName[%s]\n ",sFullDBName);
                    sprintf_s(stmt1, sizeof stmt1, "select a.ipolicy, a.icomp_in, b.iassured, a.aemail_eply, c.dply_end,a.tmobile_eply, c.dply_begin ,"
                                    "   year(c.dpolicy),year(a.dendorse),b.iapplicant"
                                    "  from %s:edr_relation a, %s:endorsement b ,%s:ply_relation c"
                                    " where a.iendorse = b.iendorse and a.ipolicy = c.ipolicy"
                                    " and a.iendorse = '%s'",sFullDBName,sFullDBName,sFullDBName, sIendorse);
                    printf("stmt1[%s]\n", stmt1);
                    $PREPARE prepE11 FROM $stmt1;
                    $EXECUTE prepE11 into 
                        $ipolicy, $icomp_in, $iassured, $aemail_eply, $dply_end, $tmobile_eply , $dply_begin ,
                        $s_dpolicy_yr,$s_dendorse_yr,$iapplicant;
                    $Free prepE11;
/*
                    $select a.ipolicy, a.icomp_in, b.iassured, a.aemail_eply, c.dply_end,a.tmobile_eply, c.dply_begin ,
                            year(c.dpolicy),year(a.dendorse),b.iapplicant
                        into $ipolicy, $icomp_in, $iassured, $aemail_eply, $dply_end, $tmobile_eply , $dply_begin ,
                            $s_dpolicy_yr,$s_dendorse_yr,$iapplicant
                        from edr_relation a, endorsement b ,ply_relation c
                        where a.iendorse = b.iendorse and a.ipolicy = c.ipolicy
                        and a.iendorse = $sIendorse;
*/                        
                    printf("\n-- trace SQLCODE[%d]\n\n ",SQLCODE);
                    strcpy(npassword, trim(iassured));

                    printf("-- trace xxxxx ipolicy[%s]\n ",ipolicy);
                    printf("-- trace xxxxx icomp_in[%s]\n ",icomp_in);
                    printf("-- trace xxxxx npassword[%s]\n ",npassword);
                    printf("-- trace xxxxx aemail_eply[%s]\n ",aemail_eply);
                    printf("-- trace xxxxx tmobile_eply[%s]\n ",tmobile_eply);
                    printf("-- trace xxxxx s_dpolicy_yr[%s]\n ",s_dpolicy_yr);
                    printf("-- trace xxxxx s_dendorse_yr[%s]\n ",s_dendorse_yr);
                    printf("-- trace xxxxx iapplicant[%s]\n ",iapplicant);

                    /* 1090525012_SC2 �O�o���߹q�l�O��{�ҤΦs�ҧ@�~���x�ظm*/
                    /* �Y�O�������x���L����άO�O�欰�ȥ��ɡA�O�o���x�L�q�l�O��A�O�o�W�w�@�w�n���q�l�O��~�i�H�W�ǧ��*/
                    /* �G�����P�_�O��O�_�s�b�O�o���x�A�H�M�w�ǰe(�g�J�q�l�O������(cm_e_policy))���y��ƺ����z��쬰P(�O��)��E(���)*/           
                    iCount =0 ;
                    $SELECT Count(*) INTO $iCount 
                    FROM cm_e_policy
                    WHERE ipolicy = $ipolicy
                        AND iendorse = $sIendorse;
                    printf("-- trace xxxxx iCount[%d]\n ",iCount);    
                    if( iCount == 0)
                    {
                        $select nvl(max(iserno),0)+1
                            into $iserno
                            from cm_e_policy
                            where ipolicy = $ipolicy;

                        sprintf_s(siserno, sizeof siserno, "%02d", iserno);

                        #ifdef _E_EDR_TII
                                
                            if ( strncmp( ipolicy+(6-1),"V7",2)==0 )  
                            {
                                fspeed = 2; /* �ֳt�� */
                            }
                            else
                            {
                                fspeed = 1; /* �@��� */
                            }
                            
                            iCount = 0;
                            $SELECT Count(*) INTO $iCount 
                            FROM cm_e_policy                   
                            WHERE ipolicy  = $ipolicy
                                AND ftype = '2'
                                AND fdata = 'P'
                                AND fstatus >= 500 ;
                            if (iCount > 0)            /* ���O��A�ǧ�� */
                            {

                                printf("-- trace xxxxx dply_end2 [%s]\n ",dply_end);
                                /*if (risnull(SQLCHAR, iserno) == 1) */

                                /* ��� nfile =
                                ��E��+�O�I���q�N�X+�O��N�X+��_��+��渹+��_��+ñ��~��+��_��+�O�渹
                                = ��E17CAR��+ ��渹�X+��_��+ñ��~��+��_��+�O�渹 )

                                ftype= 1:�x��,2:�O�o����  ; fspeed= 1:�@���,2:�ֳt��
                                fprocess= A:�s�W,U:�л\,D:�R��
                                fdata= P:�O��,E:���,Z:���(�LPDF��)
                                */
                                strcpy( fdata, "E");
                                strcpy( iendorse_ti, trim(sIendorse));
                                printf("--trace iendorse_ti[%s]\n",iendorse_ti);
                                sprintf_s(nfile, sizeof nfile, "E17CAR_%s_%s_%s", iendorse_ti, s_dendorse_yr, trim(ipolicy));
                                printf("--trace nfile[%s]\n",nfile);
                                /*
                                �b�q�l�����(ca_e_edr)�|�A�qca_e_edr�^����57~63�椧��Ѹ�T�g�J(Update)�q�l�O������(cm_e_policy)
                                ������椺�e���z(nedr_rkm)�����A�Y���e���׶W�L400�A�h�I��400�A�Y������Ÿ��h��������!��
                                */
                                strcpy(nedr_rkm,"�S���[��");
                                
                                strcpy(sNplyidx1," "); strcpy(sNplyidx2," "); strcpy(sNplyidx3," "); /* ���榡,���T����ť� */
                                
                            }
                            else /* �L�O��A�ǫO��A�����n���渹(cm_e_policy.iendorse)�A�H���s�y�q�l���pdf�z(=�̷s�O��+���) */
                            {
                                /* �O�� nfile = ��P��+ �O�I���q�N�X + �O��N�X+��_��+�O�渹 +��_��+ñ��~�� 
                                    = ��P17CAR��+ �O�渹 +��_��+ ñ��~��
                                */
                                
                                strcpy( fdata, "P");
                                strcpy( iendorse_ti, " ");
                                sprintf_s(nfile, sizeof nfile, "P17CAR_%s_%s", trim(ipolicy), s_dpolicy_yr);
                                strcpy(nedr_rkm," ");
                                
                                /* �O��榡,���T���n��ȡA�� ca_freeform_policy() ���o */
                                /*strcpy(sNplyidx1," "); strcpy(sNplyidx2," "); strcpy(sNplyidx3," ");*/ 

                                /*
                                �b�q�l�����(ca_e_edr)�|�A�qca_e_edr�^����57~63�椧��Ѹ�T�g�J(Update)�q�l�O������(cm_e_policy)
                                ������椺�e���z(nedr_rkm)�����A�Y���e���׶W�L400�A�h�I��400�A�Y������Ÿ��h��������!��
                                */
                                strcpy(nedr_rkm," ");
                                
                                /* 1091208007_SC1 �󥿧��W�ǫO�o���W�h */
                                /*�p�G�P�@���O�榳"�h�������O��"�|�o�� -239( ftype+nfile ����)�A���ɥu�ǳ̫�@��*/
                                
                                /* �R���|���ǰe�O�o(fstatus < 500)��"�O������"���(�קK ftype+nfile ����)�A�H�̫�C�L���(�Y���i���)���D*/
                                $delete FROM cm_e_policy                   
                                WHERE ipolicy  = $ipolicy
                                    AND iendorse <> ' '
                                    AND ftype = '2'
                                    AND fdata = 'P'
                                    AND fstatus < 500 ; 
                            }

                            printf("-- trace insert ipolicy[%s]\n ",ipolicy);
                            printf("-- trace insert sIendorse[%s]\n ",sIendorse);
                            printf("-- trace insert siserno[%s]\n ",siserno);
                            printf("-- trace insert fspeed[%d]\n ",fspeed);
                            printf("-- trace insert iendorse_ti[%s]\n ",iendorse_ti);
                            printf("-- trace insert fdata[%s]\n ",fdata);
                            printf("-- trace insert icomp_in[%s]\n ",icomp_in);
                            printf("-- trace insert iassured[%s]\n ",iassured);
                            printf("-- trace insert npassword[%s]\n ",npassword);
                            printf("-- trace insert aemail_eply[%s]\n ",aemail_eply);
                            printf("-- trace insert tmobile_eply[%s]\n ",tmobile_eply);
                            printf("-- trace insert nfile[%s]\n ",nfile);
                            printf("-- trace insert dply_begin[%s]\n ",dply_begin);
                            printf("-- trace insert dply_end[%s]\n ",dply_end);
                            printf("-- trace insert iapplicant[%s]\n ",iapplicant);
                            printf("-- trace insert nedr_rkm[%s]\n ",nedr_rkm);
                            printf("-- trace insert userid[%s]\n ",userid);
                            printf("-- trace insert kpid[%s]\n ",kpid);


                            $WHENEVER SQLERROR CONTINUE;
                            
                            /* ���Gcm_e_policy�� nedridx1(����˯����)�Bnedridx2(���O�I�O)�Bnedridx3(��鷺�e) �b car_eedrt.exe ���o,�G���B��ť� */
                            $INSERT INTO cm_e_policy(iins_cat, ipolicy, iendorse, iserno, ftype, fspeed, iins_kind_ply, 
                                                    iendorse_ti, fprocess, fdata, ibranch_code, icustomer, npassword, 
                                                    nemai_send, tsms_mobile, nfile, dbgn, dend, fstatus,
                                                    iapplicant, iassured, nedr_rkm, ientry, dentry, iupdate, dupdate,nplyidx1,nplyidx2,nplyidx3,nedridx1,nedridx2,nedridx3,ifreeform)
                                            VALUES ( 'C', $ipolicy, $sIendorse, $siserno, '2', $fspeed, 'C2',
                                                    $iendorse_ti, 'A', $fdata, $icomp_in, $iassured, $npassword,
                                                    $aemail_eply, $tmobile_eply, $nfile, $dply_begin, $dply_end, 100,
                                                    $iapplicant, $iassured, $nedr_rkm, $userid, CURRENT, $userid, CURRENT, $sNplyidx1,$sNplyidx2, $sNplyidx3,' ',' ',' ',$kpid);

                            if (SQLCODE== -239)
                            {
                                rc = 0;
                                sprintf_s(v_sMsg, sizeof v_sMsg, "�q�l�O��[%s]�w���s���|���ǰe�O�o�A�L�k���s�q�l���[%s]\n", ipolicy, sIendorse);
                                goto errexit;

                            }
                            else if (sqlca.sqlerrd[2] == 0)
                            {
                                goto errexit;
                                
                            }
                            $WHENEVER SQLERROR GOTO errexit;  
                        #else        
                            $select count(*)
                                into $iCount
                                from cm_e_policy
                                where ipolicy = $ipolicy
                                and iendorse = $sIendorse;
                                printf("-- trace xxxxx iCount[%d]\n ",iCount);    
                            if( iCount == 0)
                            {
                                printf("-- trace xxxxx dply_end2 [%s]\n ",dply_end);
                                /*if (risnull(SQLCHAR, iserno) == 1) */                    
                                sprintf_s(nfile, sizeof nfile, "%s%s", trim(sIendorse), siserno);

                                $INSERT INTO cm_e_policy(iins_cat,ipolicy,iendorse,iserno,ibranch_code,icustomer,npassword,nemai_send,tsms_mobile,nfile,dend,fstatus,ientry,dentry,iupdate,dupdate)
                                    VALUES ('C',$ipolicy,$sIendorse,$siserno,$icomp_in,$iassured,$npassword,$aemail_eply,$tmobile_eply,$nfile,$dply_end,100,$userid,CURRENT,$userid,CURRENT);
                            }
                        #endif
                    }
                }
                $CLOSE cur2;
                $FREE  cur2;    
            }   
        }
   }

   if (fFreeForm[0]=='1')
   {
       /* UPDATE cm_freeform.tetime */
       $UPDATE cm_freeform SET tetime = current WHERE kpid = $kpid;

       /*strcpy(outputf , outputf_ori);
       EWRITE(sUserid, 0, "FreeForm �榡�Ц� cmn545 �˵�");*/           
       $DELETE FROM gb_schedulelog WHERE kpid = $outputf;

       $COMMIT WORK;  

       /*
       if(fHasData == FALSE)
       {           
           return M_CM_NOT_FOUND;
       }
       else
       { */       
           return M_CM_OK;  /* fHasData�b�e���w�g�P�_�L, car409_build() ���^��M_CM_OK */
       /*}*/
   }
   else
   {
       $COMMIT WORK;
       return M_CM_OK;
   }

errexit:

   if (SQLCODE < 0) rc = SQLCODE;

   printf("{car409_build} SQLCODE=[%d],sqlerrm=[%s]",SQLCODE, sqlca.sqlerrm);
   printf("{car409_build}      rc=[%d], v_sMsg=[%s]", rc,v_sMsg);
   strcpy(p_sMsg, v_sMsg);
   $WHENEVER SQLERROR CONTINUE;
   $ROLLBACK WORK;
   if (fFreeForm[0]=='0')
   {
      /*EWRITE(sUserid, SQLCODE, sqlca.sqlerrm);*/
       fclose(report);
   }

   return rc;

} /* car409_build */
/*************************************************************************/

/**** �C�L�ˮ`�I��� ****/                                                              
static long car409_build_pa()
{
    int     rc, res, i;
    char    OutFile[20], tmpcmd[40], hostname[20];                                      
    char    tmpOutFile[51];                                                             
    $char   FormFile[21];                                                               
    $int    ibatch_no ,id;                                                              
    char    aphome[40];                                                                 
    $char   stmt[4024];
    $char   sql[501];
    long    iCount;

    $char   ymd_Today[12];                                                              
                                                                                        
    if (db_select(DBName) == False)                                                     
        return M_CM_DB_NOTOPEN;                                                         
                                                                                        
    $WHENEVER SQLERROR GOTO errexit;                                                    
    $SET LOCK MODE TO WAIT;                                                             
    printf("%%%%%%%%%%%%%%%%%%%%%%sIendorseBgn[%s]\n",sIendorseBgn);
    strcpy(ymd_Today, cm_cdate_str(Today));

    $SELECT kPgNum_Line, nForm_File,iform_tp
       INTO $PgLine, $FormFile,$iForm_Tp
       FROM Form                                                                        
      WHERE ksys_grp = "CA"                                                             
        AND kPgmID   = 409
        AND iform_tp = '2';
    if (SQLCODE==SQLNOTFOUND)                                                           
    {                                                                                   
        return M_CM_NOT_FOUND;                                                          
    }                                                                                   
                                                                                        
    strcpy(FormFile , rtrim(FormFile));                                                 
    sprintf_s(OutFile, sizeof OutFile , "%s.tx",outputf);                                                 
                                                                                        
    printf("FormFile[%s],OutFile[%s]\n",FormFile,OutFile);                              

    rgu_init_report(FormFile,OutFile);

    printf(" *************ptr[%s]*****************\n",ptr);
    printf(" *************IendorseBgn[%s]*****************\n",sIendorseBgn);

    stmt[0] = '\0';
    if( data_source[0] == 'i')  /* ��J��渹�_�W */
    {
        for (i=0;i<count_db;i++)
        {
            sprintf_s(sql, sizeof sql, " SELECT ipolicy "
                          "   FROM %s:edr_relation "
                          "  WHERE (iendorse BETWEEN '%s' AND '%s')"
                          "     or (iendorse matches '%s' and"
                          "         iendorse matches '%s') \n ", 
                      	    list[i].dbname, sIendorseBgn, sIendorseEnd, sIendorseBgn, sIendorseEnd);
            if( i!=count_db-1) strcat( sql, " union ");
            strcat( stmt, sql); 
        }
    }
    else if( data_source[0] == 'f')  /* ��J��渹�X��J�ɮצW�� */
        sprintf_s(stmt, sizeof stmt, " SELECT iendorse FROM t409a; ");
    else if( data_source[0] == 'u')  /* ���C�L���G���e3�X */
       sprintf_s(stmt, sizeof stmt, " SELECT iendorse FROM edr_relation "
                      "  WHERE iendorse like '%s%%' "
                      "    AND dendorse is null "
                      "    AND iendorse not like '%%CVP%%'", trim(filename));
   else  /* ��ﴣ�Ѥ��-�C�L���G���H�� */
       sprintf_s(stmt, sizeof stmt, " SELECT iendorse FROM edr_relation "
                      "  WHERE iedr_examiner like '%s' "
                      "    AND fedr_print = '1' "
                      "    AND iendorse not like '%%CVP%%'", trim(filename));

    printf("stmt[%s]\n", stmt);

    iCount=0;
    EXEC SQL PREPARE Acursor  FROM :stmt;
    EXEC SQL DECLARE Acursor5 CURSOR FOR Acursor;
    EXEC SQL FREE Acursor;
    EXEC SQL OPEN Acursor5;
    for(;;)
    {
        EXEC SQL FETCH Acursor5 INTO :sIpolicy;
        if (SQLCODE==SQLNOTFOUND) break;

        iCount++;
        printf("DBNAME[%s]\n",DBName);
        printf("SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);
        printf("stmt_buf[%s]\n",stmt_buf);
        printf("********************sIpolicy[%s]\n",sIpolicy);
        strcpy(cIpolicy, trim(sIpolicy));
    
        printf("begin ca_rpt_pa_edr \n");
        rc = ca_rpt_pa_edr(cIpolicy);
        printf("rc[%d]\n",rc);
        printf("end   ca_rpt_pa_edr \n");
        if (rc != M_CM_OK) return rc;
    }
    EXEC SQL CLOSE Acursor5;
    EXEC SQL FREE  Acursor5;
                                                                                        
    if( iCount == 0)
        return M_CM_NOT_FOUND;
    rgu_finish_report();                                                                
                                                                                        
    return M_CM_OK;                                                                     
                                                                                        
errexit:                                                                                
    printf("SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);                      
    return SQLCODE;                                                                     
}
/****************************************************************************END*/      

/**** �C�L�l�H���� ****/                                                              
static long car409_build_mail_label()
{
    int     rc, res, i;
    char    OutFile[20], tmpcmd[40], hostname[20];                                      
    char    tmpOutFile[51];                                                             
    $char   FormFile[21];                                                               
    $int    ibatch_no ,id;                                                              
    char    aphome[40];                                                                 
    $char   stmt[4024];
    $char   sql[501], sFullDBName[40];
    $char   nassured[131], fsex[2], aassured[91], aassured_zip[CA_ZIP], icard[26];
    $char   iendorse[21], ipolicy[21], sTmp[41];
    long    iCount;

    $char   ymd_Today[12];                                                              
                                                                                        
    if (db_select(DBName) == False)                                                     
        return M_CM_DB_NOTOPEN;                                                         
                                                                                        
    $WHENEVER SQLERROR GOTO errexit;                                                    
    $SET LOCK MODE TO WAIT;                                                             
    printf("$$$$$$$$$$$$$$$$$$$$$$sIendorseBgn[%s]\n",sIendorseBgn);
    strcpy(ymd_Today, cm_cdate_str(Today));

    $SELECT kPgNum_Line, nForm_File,iform_tp
       INTO $PgLine, $FormFile,$iForm_Tp
       FROM Form                                                                        
      WHERE ksys_grp = "CA"                                                             
        AND kPgmID   = 409
        AND iform_tp = '3';
    if (SQLCODE==SQLNOTFOUND)                                                           
    {                                                                                   
        return M_CM_NOT_FOUND;                                                          
    }                                                                                   
                                                                                        
    strcpy(FormFile , rtrim(FormFile));                                                 
    sprintf_s(OutFile, sizeof OutFile , "%s.tx",outputf);                                                 
                                                                                        
    printf("FormFile[%s],OutFile[%s]\n",FormFile,OutFile);                              

    rgu_init_report(FormFile,OutFile);

    printf(" *************ptr[%s]*****************\n",ptr);
    printf(" *************IendorseBgn[%s]*****************\n",sIendorseBgn);

    stmt[0] = '\0';
    if( data_source[0] == 'i')  /* ��J��渹�_�W */
    {
        for (i=0;i<count_db;i++)
        {
            sprintf_s(sql, sizeof sql, " SELECT iendorse "
                          "   FROM %s:edr_relation "
                          "  WHERE (iendorse BETWEEN '%s' AND '%s')"
                          "     or (iendorse matches '%s' and"
                          "         iendorse matches '%s') \n ", 
                      	    list[i].dbname, sIendorseBgn, sIendorseEnd, sIendorseBgn, sIendorseEnd);
            if( i!=count_db-1) strcat( sql, " union ");
            strcat( stmt, sql); 
        }
    }
    else if( data_source[0] == 'f')  /* ��J��渹�X��J�ɮצW�� */
        sprintf_s(stmt, sizeof stmt, " SELECT iendorse FROM t409a; ");
    else if( data_source[0] == 'u')  /* ���C�L���G���e3�X */
       sprintf_s(stmt, sizeof stmt, " SELECT iendorse FROM edr_relation "
                      "  WHERE iendorse like '%s%%' "
                      "    AND dendorse is null "
                      "    AND iendorse not like '%%CVP%%'", trim(filename));
    else  /* ��ﴣ�Ѥ��-�C�L���G���H�� */
       sprintf_s(stmt, sizeof stmt, " SELECT iendorse FROM edr_relation "
                      "  WHERE iedr_examiner like '%s' "
                      "    AND fedr_print = '1' "
                      "    AND iendorse not like '%%CVP%%'", trim(filename));


    printf("stmt[%s]\n", stmt);

    iCount = 0;
    $PREPARE prep2  FROM $stmt;
    $DECLARE curs2 CURSOR FOR prep2;
    $OPEN curs2;
    for(;;)
    {
        $FETCH curs2 INTO $iendorse;
        if (SQLCODE==SQLNOTFOUND) break;
        printf("--------------------iendorse[%s]\n",iendorse);
        sFullDBName[0] = '\0';
        strcpy(sFullDBName, get_car_full_db( iendorse));

        sprintf_s(stmt, sizeof stmt, "SELECT nassured, fsex, aassured, aassured_zip, '17'||icard "
                       "  FROM %s:endorsement a, %s:edr_relation b"
                       " WHERE a.iendorse = b.iendorse AND a.iendorse = '%s'", sFullDBName, sFullDBName, iendorse);
        printf("stmt[%s]\n", stmt);
        $PREPARE prep3 FROM $stmt;
        $EXECUTE prep3 INTO $nassured, $fsex, $aassured, $aassured_zip, $icard;
        $FREE prep3;
    
        strcpy( nassured, trim( nassured));
        /*1130129008_C02 �վ�C�L���t�����ͤp�j�A�אּ�u�g�v*/
        if( fsex[0] == '1' || fsex[0] == '2')
        {
            strcat( nassured, " �g");
        }
        /*    
        if( fsex[0] == '1')
            strcat( nassured, " ����");
        else if( fsex[0] == '2')
            strcat( nassured, " �p�j");
        */
        rgu_put_body_string( 1, nassured, 1);
        rgu_put_body_string( 1, aassured_zip,1);
        rgu_put_body_string( 1, aassured,1);
        sprintf_s(sTmp, sizeof sTmp, "�O�I�Ҹ��G%s", icard);
        rgu_put_body_string( 1, sTmp,1);
        sprintf_s(sTmp, sizeof sTmp, "��渹�X�G%s", iendorse);
        rgu_put_body_string( 1, sTmp,1);
        iCount++;
        if( iCount%3==0) /* �C�T����ƿ�X�@�� */
            rgu_put_body(1);
    }
    $CLOSE curs2;
    $FREE  curs2;
    if( iCount%3!=0) /* �̫᥼���T����ƭn�ɪť� */
    {
        for(i=1;i<=iCount%3;i++) 
        {
            rgu_put_body_string( 1, "",1);
            rgu_put_body_string( 1, "",1);
            rgu_put_body_string( 1, "",1);
            rgu_put_body_string( 1, "",1);
            rgu_put_body_string( 1, "",1);
        }
        rgu_put_body(1);
    }
                                                                                        
    if( iCount == 0)
        return M_CM_NOT_FOUND;
    rgu_finish_report();
                                                                                        
    return M_CM_OK;                                                                     
                                                                                        
errexit:                                                                                
    printf("SQLCODE=[%ld], sqlerrm=[%s]\n",SQLCODE,sqlca.sqlerrm);                      
    return SQLCODE;                                                                     
}
/****************************************************************************END*/      
