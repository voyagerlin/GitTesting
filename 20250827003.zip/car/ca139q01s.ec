/**********************************************************************/
/*   program id   : ca139q01s.ec                                      */
/*   program name : ������O�g��N�����~�N���I�ܧ���Ӫ�      	      */
/*   date written : 2022/12/23 by 061476                              */
/**********************************************************************/

#include <stdio.h>
#include <stdlib.h>
#include <decimal.h>
$include sqlca;
$include datetime.h;
$include sqltypes.h;
#include "sql.h"
#include "decimal.h"
#include "sqlfatal.h"
#include "comdata.h"
#include "commsgs.h"
#include "is_def.h"
#include "api_xsrv.h"
#include "cmprint.h"
#include "print.h"
#include "globdata.h"
#include "safeclib.h"

$char iclass[3], ibig_sales[11], ori_iofficer[11], new_iofficer[11], 
      plybgn[6], plyend[6];
int   count_db; 
char  outputf[21];
$char userid[11];
$char DBName[05];
$char msgbuf[128];

DBinfo *list;
/*----------------------------------------------------------------------------*/
main(argc, argv)
int argc;
char **argv;
{
 	int rc;

	batchinit();
	strcpy(DBName,         isNULLstr(argv[1]));
	strcpy(userid,         isNULLstr(argv[2]));
	strcpy(iclass,         isNULLstr(argv[3]));
	strcpy(ibig_sales,     isNULLstr(argv[4]));
	strcpy(ori_iofficer,   isNULLstr(argv[5]));
	strcpy(new_iofficer,   isNULLstr(argv[6]));
	strcpy(plybgn,         isNULLstr(argv[7])); 
	strcpy(plyend,         isNULLstr(argv[8]));
	strcpy(outputf,        isNULLstr(argv[9]));
	       
	rc = car139_get_db();
	if (rc != M_CM_OK)
		return rc;

	rc = car139_build();
	if (rc != M_CM_OK) 
		return rc;
}
/*----------------------------------------------------------------------------*/
long car139_get_db()
{
	$whenever sqlerror goto errexit;

	if (db_select(DBName) == FALSE) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}
/*----------------------------------------------------------------------------*/
long car139_build()
{
 int rc;
 char sfilename[256],stitle[2048],stmt1[6000];

 	
	$WHENEVER SQLERROR GOTO errexit;

	strcpy(sfilename,"������O�g��N�����~�N���I�ܧ���Ӫ�[car139]");	
	sprintf_s(stitle, sizeof stitle, "���O\t�g��/�~�N�N��\t��g��N��/���I\t�s�g��N��/���I\t");
	strcat(stitle, "�J�p�_�l�~��\t�J�p�פ�~��\t�s�W�H��\t�s�W���\t�󥿤H��\t�󥿤��\t");
	sprintf_s(stmt1, sizeof stmt1, "SELECT iclass, chr(127)||ibig_sales, chr(127)||ori_iofficer, chr(127)||new_iofficer,   \n"
	              "       plybgn_yymm, plyend_yymm,  \n"
	              "       nvl((SELECT nname FROM officer a WHERE a.iofficer = icreator),''), dcreate,  \n"
	              "       nvl((SELECT nname FROM officer a WHERE a.iofficer = iupdate),''), dupdate  \n"
		      "  FROM ca_change_office   \n"
		      " WHERE iclass   matches '%s'      AND ibig_sales matches '%s'   \n"
		      "   AND ori_iofficer matches '%s'  AND new_iofficer matches '%s' \n"
		      "   AND plybgn_yymm matches '%s'   AND plyend_yymm matches '%s' \n"
		      " ORDER BY 1,2,3,4,5,6;   \n",iclass,ibig_sales,ori_iofficer,new_iofficer,plybgn,plyend);

	rc = unload_file(outputf," ",sfilename,stitle,stmt1);
	
	if (rc != SUCCESS) 
	{
	    sprintf_s(msgbuf, sizeof msgbuf, " %s �ɮ׵L�k���� ",sfilename);
	    EWRITE(userid, rc , msgbuf);
	    return rc;
	}
	
	return M_CM_OK;

errexit:
	sqlfatal();
	EWRITE(userid, SQLCODE, sqlca.sqlerrm);
	return SQLCODE;   
   
}
/*----------------------------------------------------------------------------*/