/*********************************************
 * Copyright (C) 1995 Intellisys Corporation
 * Program : car9998.ec ���N���M
 * Revised : Johnny Kuo 12/01/1997
 ********************************************/

#include <stdio.h>
#include "api_xsrv.h"
#include "sqlfatal.h"
$include sqlca;
$include datetime.h;
#include "sql.h"

#include "comdata.h"
#include "globdata.h"
#include "cmprint.h"
#include "is_def.h"
#include "print.h"

#include "carmsgs.h"
#include "commsgs.h"
#include "cmnmsgs.h"
#include "car_common.h"
#include <math.h>
#include "safeclib.h"

#define TRUE    1
#define FALSE   0
/* standard data declaration */
/* end of standard data */

/* private data */
/* end of private data */

$char localdb[5],Taipei_FullName[20],data_yyyymm[7];
int  i=0, flag_err=0;
/* end of standard defined data */

$char userid[USER_ID], iquota[7];
char expdate[6];
char bgndate[10],enddate[10];
char prtfile[80],outputf[80],outputf1[80];
char option[2];
char errmsg[200];
$char  stmp[1024],stmp1[1024],stmp2[1024];
$char  stmp_ins1[1024],stmp_ins2[1024],stmp_ins3[1024],stmp_ins4[1024];

$char    iassured[13],dbirth_yy[5],fsex[2],fmarriage[2];
$char    ibrand[9],ibrand_new[9],icar_type[3],iengine[CA_ENGINE_NUM],itag[CA_TAG_NUM];
$char    iissue_yy[5],iissue_mm[3];
$char    iacc_license[11],facc_sex[2],facc_marri[2],facc_rel[2];
$char    iacc_reason[3],ply_iassured[13],ply_ibirth_yy[5],ply_fsex[2],ply_fmarriage[2];
$long    qinjure1=0,qdeath1=0,dappraisal=0;
$char    ilicense[11];
$char    iins_type[INSURANCE_TYPE],drate_ym[5],fstl[2],flast[2],provision[21],n_provision[21];
$char    drate_yyyymm[7];
$char    iins_ply[INSURANCE_TYPE],n_iins_ply[INSURANCE_TYPE];
$long    mdamage_cover=0,minjure_cover=0,mdeath_cover=0, mdamage_cover31=0, mdamage_cover_over=0;
char     iclaim_tmp1[2],iclaim_tmp2[7],iclaim_no[13];
$char    iclaim_br[3];
char     dclaim_c[9],dclaim_yy[3],dclaim_mm[3],dclaim_dd[3];
char     iclose_br[3],iclose_tmp1[2],iclose_tmp2[7],iclose_no[13];
char     dclose_c[9],dclose_yy[3],dclose_mm[3],dclose_dd[3];
$char    ipolicy_br[3];
char     dply_begin_c[11],dply_begin_yy[5],dply_begin_mm[3],dply_begin_dd[3];
char     dply_end_c[11],dply_end_yy[5],dply_end_mm[3],dply_end_dd[3];
long     begin_yy_l=0,begin_mm_l=0,end_yy_l=0,end_mm_l=0,qperiod=0;
char     qperiod_c[3],qcylinder_c[6];
$char    iacc_birth_yy[5];
char     qinjure1_c[4],qdeath1_c[4];
char     mdamage_cover_c[9],mpremium_c[9];
long     qpeople=0;
char     qpeople_c[4];
char     mins_app_c[9],mins_comp_c[9],mins_stl_c[9],mins_proc_c[9];
char     dentry_c[11],dentry_yy[5],dentry_mm[3],dentry_dd[3];
$char    dvp_code[3],stmt_buf[1024],cmdbuf[100];
$int     ipdmg_align, iplia_align,ipbrg_align;
long     app_subtot=0,comp_subtot=0,stl_subtot=0,prem_subtot=0;
long     app_tot_31=0,comp_tot_31=0,stl_tot_31=0,prem_tot_31=0;
long     stl_total=0;
char     app_subtot_c[9],comp_subtot_c[9],stl_subtot_c[9],prem_subtot_c[7];
char     app_tot_31_c[9],comp_tot_31_c[9],stl_tot_31_c[9],prem_tot_31_c[7];
char     stl_total_c[13];
$char    iacc_align[3],fpart[2],dvp_code1[3],dvp_code2[3];
$char    n_dvp_code1[3],n_dvp_code2[3];
$char    flimit[2],ipro_year[5],fpt[2],qpt_tmp[6];
$char    pdmg_align[5],plia_align[5],mdeduct_c[10];
$long    mdeduct=0;
char     ipolicy_no[13],ipolicy_no2[5];
long     qinjure_tot=0,qdeath_tot=0;
$char    drate[11],drate_c[11];
char     drate_yy[5],drate_mm[3],drate_dd[3];
$char    errFile[120], buf[1024];
short    fError=0, fRowError, fexist_31,fexist_131,fexist_231,fexist_331;
char     dclaim_yyyy[5],daccident_yyyy[5];
$long    bgndate_l=0,enddate_l=0,dwritten_l=0;
$char    dclaim[17],daccident[14];
long     claim_yy_l=0;
char     daccident_mm[3],daccident_dd[3];
$long    dclose=0,dentry=0,dgroup=0;
$long    dply_begin=0,dply_end=0,qcylinder=0;
$double  qpt=0,Maxminvalue=0;
$char    iclaim[CLAIM_NUM],ipolicy[POLICY_NUM_1],icard[CARD_NUM];
$int     iclose_type=0;
$long    qinjure2=0, qdeath2=0, qlia2=0, qinjure31=0, qdeath31=0, qinjure99=0, qdeath99=0;
$long    qbreak31=0,qbreak99=0;
$long    mins_comp=0, mins_app=0, mins_stl=0, mins_proc=0, mins_app31=0, mins_stl31=0;
$long    mins_proc31=0, mins_app99=0, mins_stl99=0, mins_proc99=0;
$long    mins_dedu=0,mins_dedu1=0;
$char    fclose_A[2];
$char    frule[2],fcal_way[3];
$char    istl_flag[2],Maxmin[5];
$char    iproduct[13];
char     ttday_yy[5],ttday_mm[3],ttday_dd[3];
char     ttday[20];
$char    dentry_yyyy[5];
$double  pdmg_acc,plia_acc;
$char    fcar_class[3], acc_tmp[5];
$char    n_istl_flag[2], tmp_iins_24[2], x_drate_ym[3];
$long    mins_app_29=0, mins_app_24=0, mins_app_30=0, mins_app_35=0, mins_app_55=0, mins_app_26=0;
$int     fexist_29=0, fexist_24=0, fexist_30=0, fexist_35=0, fexist_55=0, fexist_26=0;
$char    iclaim_12[3],ck_fassured[2],ck_fsex[2];
$int     drate_int=0;
$char    ibroker[11], iofficer[11], fbusiness[2],ibroker_top[11],bzfrom[3];

$long    count=0,prem_total=0,count1=0;
char     prtstr[379];
int      res=0, check_31=0;
$char    aphome[40],stmt[5120];
$long    Today=0;
FILE *fptr, *fptr_err;

$char	fsingle_acc[2],adjustment[7];
$char	ifacnum[11],n_ifacnum[11];

$char n_chk_157[2],chk_157[2];
$char dissue[11];
$char icar_type_ori[3];
char dply_begin_yyyy[5];
/*******************NEW DATA********************/
/*** new stl_ins_type ***/
$char n_iclaim[CLAIM_NUM], n_iins_type[INSURANCE_TYPE];
$char n_drate_ym[5],n_fstl[2],n_flast[2];
$int  n_iclose_type=0,n_qlia2=0;
$long n_mins_comp=0, n_mins_stl=0, n_mins_proc=0;
$long p_mins_stl=0;
$long n_mins_dedu=0;

/*** new settlement ***/
$char n_ipolicy[POLICY_NUM_1];
$long n_dclose=0,n_dgroup=0;

/*** new adjustment_ply ***/
$long n_dply_begin=0,n_qcylinder=0;
$char n_iissue_yy[5],n_iissue_mm[3],n_ibrand[9],n_icar_type[3], n_iengine[CA_ENGINE_NUM], n_itag[CA_TAG_NUM];
$char n_iacc_align[3],n_flimit[2], n_ipro_year[5];
$int  n_ipdmg_align=0, n_iplia_align=0, n_ipbrg_align=0;
$char n_iassured[13],n_ply_ibirth_yy[5],n_fsex[2],n_fmarriage[2];
$char n_dissue[11];

/*** new appraisal ***/
$char n_dclaim[17],n_iacc_license[11],n_iacc_birth_yy[5],n_facc_sex[2],
      n_facc_marri[2],n_iacc_reason[3],n_daccident[14],n_fpart[2],
      n_facc_rel[2];

/*** new policy ***/
$char n_fpt[2];
$double n_qpt=0;

long  p_msettle=0;
int   p_flag_close=0;

$char ipolicy_a[21], iclaim_a[21];
char companyid[3];
int rtn=0;
$char  company_flag,iclaim_flag;
char  COMPANY_P[3];
char  COMPANY_F[3];

$char n_iassured_match[13],iassured_match[13];
$char n_fassured[2],fassured[2];

$char iins_type_class[2];
$char provision_t[21],pro_tmp[21];
$int pro_cnt = 0;

$int f_1070101_1 = 0,f_1070101 = 0;
$char chk_cover_31[2];
$int in_cover31 = 0;

/*�s�W���*/
$char qpro_month_c[3];
$char icar_type_ori[3];
$char n_facc_duty[2],n_fdmg_duty[2]; 
$char facc_duty[2],fdmg_duty[2];

$long new_dply_begin=0;
$long n_mdeduct=0;
$char n_provision[21];
$long n_qpro_month=0,qpro_month=0;

$long n_iself_duty=0,n_ioth_duty=0,n_ianoth_duty=0;
$long iself_duty=0,ioth_duty=0,ianoth_duty=0;
$char iself_duty_c[4],ioth_duty_c[4],ianoth_duty_c[4];

$char iendorse_tmp[21];
$double mcar_price=0.0,psex_age_lia=0.0,psex_age_dmg=0.0;
$double n_mcar_price=0,n_plia_acc=0,n_pdmg_acc=0,n_psex_age_lia=0,n_psex_age_dmg=0;

$long mcover_ori=0;
$int chk_division=0,chk_division2=0;
$long mins_stl_pro = 0,mins_stl_tmp = 0;
$long mins_app_tmp = 0,mins_app_pro = 0;
$long pdepreciate_year = 0,pdepreciate_year_tot = 0;

$char provision_tmp[21];

$long n_minjure_cover=0, n_mdeath_cover=0, n_mdamage_cover=0;

$int n_chk_provision = 0,chk_provision=0;
$int n_iprovision_P=0,n_iprovision_Q=0,n_iprovision_Z=0,n_iprovision_M=0;
$int iprovision_P=0,iprovision_Q=0,iprovision_Z=0,iprovision_M=0;
$char pdepreciate_year_tmp[4],pdepreciate_year_tmp2[5];
$int pdepreciate_year_tot_tmp=0;
$char iins_main[INSURANCE_TYPE];

$char ioth_cartype[3];

$double mcar_price_ori=0,p_mcar_price=0,qpassenger=0;
$char icar_series[3];
$char mcar_price_tmp[4];

$long mdamage_cover_prov=0;
$char iins_type_main[3],iins_type_dtl[3],iins_type_develop[3],iins_type_rule[3];

$long ply_dpolicy=0;
$char ply_dpolicy_c[11];
$char  dpolicy_yy[5],dpolicy_mm[3],dpolicy_dd[3];
$char sex_age_tmp[4];

$int chk_iendorse = 0;

$char dissue_pro_tmp[11],dpro[11];
char dissue_100[11],dpro_100[11];
long ldissue = 0,ldpro = 0;

char v_sMsg[120];
$char fins_grp[2],iri_ins[INSURANCE_TYPE];

$int f_1060101=0,f_1090101=0,f_1120501=0,f_1060101_dacc=0,n_f_1060101_dacc = 0,n_cnt_L = 0,cnt_L = 0;
$char fcar_kind[2],n_icomp_card[21],icomp_card[21];
$char irelative_ply[21];

$char nequipment[31],n_nequipment[31];

$int fcontract_err = 0;
$char fcar_class_pd[2];
long iins_mult=0;
char iin_mult_c[3];
$char fcar_class_p[3],fkind[2];

$char sDbirth[11], sDply_begin[11];
$double age = 0.0,psex_age_chk = 0.0;
$int chk_plia = 0;
$long dbirth=0,n_dbirth=0;

int   count_db,k; 

$char DBName[05];
$char msgbuf[128];
DBinfo *list;
char    sApHome[30];
int rtncode=0,rc=0;
char    filename[30];
FILE    *fp;
char  file_catalog[200];
$char filename1[200];
$char ply_DB[21];

$char iproduct_tmp[3];
$long mprem_10 = 0,mprem_11 = 0,mprem_12 = 0,mprem_13 = 0,mprem_28 = 0;

/* �g�Jca_dev_clm */
$char  t_idata[2],t_istl[2],t_ipolicy[21],t_iclaim[21],t_icompany[3],t_iclm_br[3],t_iclm[13],t_dclaim[9],t_dgroup[9],t_icompany_ply[3],t_iply_br[3],t_iply[13];
$char  t_dply_begin_ym[7],t_iobjno[5],t_iissue_ym[7],t_ipro_ym[7],t_ibrand[9],t_icar_type_ori[3],t_icar_type[3],t_icar_type_no[3];
$char  t_iengine[26],t_itag[13],t_fpt[2],t_iacc_license[11],t_iacc_birth_y[5],t_facc_sex[2],t_facc_marri[2],t_iacc_reason[3],t_fduty[2];
$char  t_iassured[11],t_dbirth_y[5],t_fsex[2],t_fmarriage[2],t_daccident[9],t_dvp_code1[3],t_dvp_code2[3],t_fpart[2],t_ipdmg_align[2],t_ipbrg_align[2],t_iplia_align[2];
$char  t_iins_type_ori[7],t_iins_type[7],t_iins_main[7],t_iins_type_main[2],t_iins_type_dtl[3],t_iins_type_develop[5],t_iins_type_rule[3],t_iins_type_class[3],t_frule[3],t_ubi_data[9];
$char  t_fmdeduct[2],t_fstl[2],t_iproduct[13],t_drate_ym[7],t_dentry[9],t_bzfrom[3],t_dpolicy_ym[7],t_dsend[9];
$char  t_fsingle_acc[2],t_adjustment[7],t_ifacnum[11];

$long  t_iclose_type=0,t_qcylinder=0,t_qpt=0,t_qlia1=0,t_qlia2=0,t_qlia3=0,t_padjust_rate=0,t_p_mcar_price=0,t_pdepreciate_year=0,t_mcover=0,t_iins_mult=0;
$long  t_mdeduct=0,t_qpeople=0,t_iself_duty=0,t_ioth_duty=0,t_ianoth_duty=0,t_mins_app=0,t_mdeduct_clm=0,t_mins_stl=0,t_mins_proc=0;
$double t_pins_acc=0,t_psex_age=0;

long car9998_get_db();
long car9998_build();
long car9998_final();
/************************************************************************/
main(argc,argv)
int argc;
char **argv;
{
	int rtncode,rc;
	strcpy(DBName, isNULLstr(argv[1]));
	strcpy(userid, isNULLstr(argv[2]));
	strcpy(expdate,isNULLstr(argv[3]));
	strcpy(outputf,isNULLstr(argv[4]));
	printf("DBName[%s],userid[%s],expdate[%s],outputf[%s] \n",DBName,userid,expdate,outputf);
	rc = car9998_get_db();
	if (rc != M_CM_OK)
	{
		printf("error on car9998_get_db \n");
		EWRITE(userid, rc, errmsg);
		return rc;
	}
	rc = car9998_build();
	if ( rc != SUCCESS ) {
		printf("error on car9998_build \n");
		EWRITE(userid, rc, errmsg);
		return rc;
	}
	rc = car9998_final();
	if ( rc != SUCCESS ) {
		printf("error on car9998_final \n");
		EWRITE(userid, rc, errmsg);
		return rc;
	}
}

long car9998_get_db()
{
	$whenever sqlerror goto errexit1;

	if (db_select(DBName) == DBName) {
		EWRITE(userid, M_CM_DB_NOTOPEN, "M_CM_DB_NOTOPEN");
		return M_CM_DB_NOTOPEN;
	}
	
	rc = getApHome(sApHome);
	if (rc < 0) {
		strcpy(msgbuf,"read Config file error!!-->getApHome\n");
		EWRITE(userid,rc,msgbuf);
	 	return rc;
	}

	if ((list = get_db_list (&count_db, DBName)) == (char *) 0) {
		if (EWRITE(userid, M_CM_NOT_DBLIST) == TRUE)
			return M_CM_NOT_DBLIST;
	}	
	return M_CM_OK;

errexit1:
	sqlfatal();
	EWRITE(userid,SQLCODE,sqlca.sqlerrm);
	return SQLCODE;
}

/************************************************************************/
long car9998_build()
{
	$char   remotedb[5];
	char   bgn_yy[5],bgn_mm[5],end_mm[3];
	long   endyy=0,endmm=0;
	$int   stlcnt_a=0;
	$char  product_kind[3];
	
	filename[0]    = '\0';
	file_catalog[0] = '\0';
	sprintf_s(filename, sizeof filename,"%s/rptftp/", sApHome);
	sprintf_s(filename1, sizeof filename1,"AUTOZ17_%d.txt",atoi(expdate)+191100);
	strcpy(file_catalog, trim(filename));
	strcat(file_catalog, trim(filename1));

	if ((fptr=fopen(file_catalog,"w")) == NULL)
	{
		sprintf_s(errmsg, sizeof errmsg,"Cannot open print file: %s",outputf);
		return M_CM_OPEN_FILE_FAIL;
	}
	
	/* *** open error log file *** */
	res = getApHome(aphome);
	sprintf_s(errFile, sizeof errFile,"%s.%s.error",outputf,DBName);
	printf("errFile[%s]\n",errFile);
	if ((fptr_err=fopen(errFile,"w")) == NULL)
	{
		sprintf_s(errmsg, sizeof errmsg,"Cannot open print file: %s",errFile);
		return M_CM_OPEN_FILE_FAIL;
	}
	
	printf(">>>expdate=%s\n",expdate);
	strncpy(bgn_yy,&expdate[0],3); bgn_yy[3]='\0';
	strncpy(bgn_mm,&expdate[3],2); bgn_mm[2]='\0';
	if (strncmp(bgn_mm, "12",2) == 0)
	{
		endyy=atoi(bgn_yy)+1;
		endmm=1;
	}
	else
	{
		endyy=atoi(bgn_yy);
		endmm=atoi(bgn_mm)+1;
	}
	rfmtlong(endmm,"&&",end_mm);
	
	sprintf_s(bgndate, sizeof bgndate,"%s/%s/%s",bgn_yy,"01"  ,"01");
	sprintf_s(enddate, sizeof enddate,"%ld/%s/%s",endyy,end_mm,"01");
	sprintf_s(data_yyyymm, sizeof data_yyyymm,"%s%s",itoa(atoi(bgn_yy)+1911),bgn_mm);
	
	printf(">>>bgndate=[%s] enddate=[%s]\n",bgndate,enddate);
	
	EXEC SQL WHENEVER SQLERROR GOTO errexit;
	
	rtn = getCompanyId(companyid); /* ���q�N�X */
	printf("*** companyid[%s]\n",companyid);
	
	bgndate_l=cm_ymd_cdate(bgndate);
	enddate_l=cm_ymd_cdate(enddate);
	
	/* field 43 312-321 ��ƻs�e��� */
	strcpy(ttday , cm_get_sysd());
	strncpy(ttday_yy,&ttday[0],4); ttday_yy[4] = '\0';
	strncpy(ttday_mm,&ttday[5],2); ttday_mm[2] = '\0';
	strncpy(ttday_dd,&ttday[8],2); ttday_dd[2] = '\0';

	stl_total = 0;
	count = 0;
		
	for(k=0;k<count_db;k++)
	{
		printf("count_db[%d] \n",k);
		sprintf_s(stmt, sizeof stmt,"DELETE FROM %s:ca_dev_clm WHERE data_yyyymm = '%s' AND idata = 'Z'",list[k].dbname,data_yyyymm);
		$PREPARE DE_ca_dev_clm FROM $stmt;
		$EXECUTE DE_ca_dev_clm;
		
		printf("prepare appraisal and app_ins_type \n");
		/***** prepare cursor for select appraisal and app_ins_type *****/
		/***** ���N�I�B�i�X�I����j�p��έp���餧�Ҧ��߮�           *****/
		/* 0991115001�]�����F�������X�֭p�� */
		/* 1.���a�ϥN����42�u�x�����v�A�h�վ㬰41�u�x�����v */
		/* 2.���a�ϥN����63�u�x�n���v�A�h�վ㬰62�u�x�n���v */
		/* 3.���a�ϥN����65�u�������v�A�h�վ㬰64�u�������v */
		/*b.minjure_cover, b.mdeath_cover,\
		        b.mdamage_cover, b.mdeduct, */
		sprintf_s(stmt_buf, sizeof stmt_buf,
		"SELECT a.iclaim, a.ipolicy, a.dclaim,\
		        a.iacc_license, YEAR(a.dacc_birth),\
		        a.facc_sex, a.facc_marri, a.iacc_reason, a.daccident, \
		        a.fpart, b.iins_type, (b.mins_app+b.mproc_app), \
		        b.fclose, DECODE(a.iacc_area,'42','41','63','62','65','64',a.iacc_area), \
		        (select iins_ply from insurance_type \
		        where iins_type = b.iins_type),a.facc_rel,a.ifacnum, \
		        case when ipolicy[6,7] = 'V7' then 'Y' else 'N' end , \
		        facc_duty,fdmg_duty,CASE WHEN date(a.daccident) >= '01/01/2017' THEN 1 ELSE 0 END \
		   FROM %s:appraisal a , %s:app_ins_type b \
		  WHERE a.iclaim = b.iclaim \
		    AND a.iclaim[6] <> 'W' \
		    AND a.iclaim[6] <> 'B' \
		    AND b.iins_type NOT IN (SELECT iins_type FROM insurance_type WHERE iins_ply in ('101','102','103','104','145','146','148','166','266','171','172','173','174','175')) \
		    AND DATE(a.daccident) < ? \
		  ORDER BY a.iclaim,b.iins_type",list[k].dbname,list[k].dbname);
		EXEC SQL PREPARE CUR_STMT3 FROM :stmt_buf;
		EXEC SQL DECLARE scur_app CURSOR FOR CUR_STMT3;
	     /********** car908 ����u���X�I��
	                AND DATE(a.dclaim) < ? \
	                AND b.dappraisal < ? \
	     **********/
	
		/***** prepare cursor for select app_ins_type_hist *****/
		sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT First 1 dappraisal, mins_app + mproc_app \
		                    FROM %s:app_ins_type_hist \
		                   WHERE iclaim = ? AND iins_type = ? \
		                     AND dappraisal < ? \
		                   ORDER BY dappraisal DESC",list[k].dbname);
		EXEC SQL PREPARE CUR_HIST FROM :stmt_buf;
		
		printf("prepare settlement and stl_ins_type \n");
		/***** prepare cursor for select settlement and stl_ins_type *****/
		sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT b.iins_type, a.fstl, b.iclose_type, \
		                         b.qlia, \
		                         b.mins_stl, b.mins_proc, \
		                         b.flast, b.mins_dedu, a.istl_flag, \
		                         nvl(a.iself_duty,0),nvl(a.ioth_duty,0),nvl(a.ianoth_duty,0) \
		                    FROM %s:settlement a , %s:stl_ins_type b \
		                   WHERE a.iclaim = b.iclaim \
		                     AND a.fstl = b.fstl \
		                     AND a.iclose_type = b.iclose_type \
		                     AND a.iclaim = ? \
		                     AND b.iins_type = ? \
		                     AND b.dgroup < ? ",list[k].dbname,list[k].dbname);
		$PREPARE CUR_STMT1 FROM $stmt_buf;
		$DECLARE scur_stl CURSOR FOR CUR_STMT1;
	
		printf("prepare adjustment_ply\n");
		/***** prepare cursor for select adjustment_ply *****/
		/* 0991115001�]�����F�������X�֭p�� */
		/* 1.���a�ϥN����42�u�x�����v�A�h�վ㬰41�u�x�����v */
		/* 2.���a�ϥN����63�u�x�n���v�A�h�վ㬰62�u�x�n���v */
		/* 3.���a�ϥN����65�u�������v�A�h�վ㬰64�u�������v */
		sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT dply_begin,YEAR(dissue),MONTH(dissue),ibrand,icar_type, \
		                         qcylinder,iengine,itag,flimit, \
		                         pdmg_align,plia_align,ipro_year,pbrg_align,\
		                         DECODE(iply_area,'42','41','63','62','65','64',iply_area),\
		                         qpro_month,iassured,YEAR(dbirth),fsex,fmarriage,dissue,dbirth \
		                    FROM %s:adjustment_ply \
		                   WHERE iclaim = ?",list[k].dbname);
		$PREPARE CUR_STMT2 FROM $stmt_buf;
	
		printf("prepare policy\n");
		/***** prepare cursor for select policy *****/
		sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT qpt,fpt \
		                    FROM %s:policy \
		                   WHERE ipolicy=? ",list[k].dbname);
		$PREPARE CUR_STMT6 FROM $stmt_buf;
		
		sprintf_s(stmt_buf, sizeof stmt_buf,
		" SELECT drate_ym,provision    \
		    FROM %s:ply_ins_type      \
		   WHERE ipolicy = ?       \
		     AND iins_type = ? ",list[k].dbname);
		$PREPARE Cur_id FROM $stmt_buf;
		
		/***** prepare cursor for select ca_car_model *****/
		/* 1000530002�t�P�����N���H�ഫ�t�P�����N�����e */
		sprintf_s(stmt, sizeof stmt, "SELECT ibrand_new "
		              "  FROM ca_car_model "
		              " WHERE ibrand = ? "
		              "   AND ibrand_new != ' ' "
		              " ORDER BY drate DESC;");
		$PREPARE pr_ibrand FROM $stmt;
		$DECLARE cur_ibrand CURSOR FOR pr_ibrand;
		printf("stmt[%s]\n", stmt);
		
		sprintf_s(stmt, sizeof stmt,"SELECT fins_grp,iri_ins,fkind \
	                    FROM insurance_type \
	                   WHERE iins_type = ? ");
		$PREPARE CUR_INSGRP FROM $stmt;
		
		sprintf_s(stmt, sizeof stmt,"SELECT dpolicy,case when dpolicy >= '01/01/2017' then 1 else 0 end, \
		                     case when dpolicy >= '01/01/2020' then 1 else 0 end, \
		                     case when dpolicy >= '05/01/2023' then 1 else 0 end \
		                     FROM %s:ply_relation WHERE ipolicy = ? ",list[k].dbname);
		$PREPARE ply_data FROM $stmt;
	
		count1 = 0;
		iclaim[0] = '\0';
		mins_app_29 = 0;
		fexist_29 = FALSE;
		mins_app_24 = 0;
		fexist_24 = FALSE;
		mins_app_30 = 0;
		fexist_30 = FALSE;
		fexist_31 = FALSE;
		fexist_131= FALSE;
		fexist_231= FALSE;
		fexist_331= FALSE;
		fexist_35 = FALSE;
		fexist_55 = FALSE;
		fexist_26 = FALSE;
		mins_app99 = 0;
		mins_app31 = 0;
		in_cover31 = 0;
		minjure_cover = mdeath_cover = mdamage_cover =0;
		/*******
		$OPEN scur_app USING $enddate_l, $enddate_l, $enddate_l;
		*******/
		$OPEN scur_app USING $enddate_l;
		while(1)
		{
			$FETCH scur_app INTO $n_iclaim, $n_ipolicy, $n_dclaim,
			                     $n_iacc_license, $n_iacc_birth_yy,
			                     $n_facc_sex, $n_facc_marri, $n_iacc_reason,
			                     $n_daccident, $n_fpart,
			                     $n_iins_type, $mins_app, $fclose_A,
			                     $n_dvp_code1, $n_iins_ply, $n_facc_rel,$n_ifacnum,$n_chk_157,$n_facc_duty,$n_fdmg_duty,$n_f_1060101_dacc;
			
			if (SQLCODE == SQLNOTFOUND) break;
			printf("n_iclaim[%s]n_iins_type[%s]n_iins_ply[%s]\n", n_iclaim, n_iins_type, n_iins_ply);
			
			/***** �w�����v�ɵL��ƫh���e *****/
			$EXECUTE CUR_HIST INTO $dappraisal,$mins_app
			USING $n_iclaim,$n_iins_type,$enddate_l;
			if (SQLCODE==SQLNOTFOUND)
			continue;
			
			/** �ˮ`�I�̶ˮ`�I�έp�e,���I�簣 950721**/
			if (strcmp(trim(n_iins_ply),"33")==0  ||
			    strcmp(trim(n_iins_ply),"47")==0  ||
			    strcmp(trim(n_iins_ply),"48")==0  ||
			    strcmp(trim(n_iins_ply),"56")==0  ||
			    strcmp(trim(n_iins_ply),"50")==0  ||
			    strcmp(trim(n_iins_ply),"80")==0  ||
			    strcmp(trim(n_iins_ply),"89")==0  ||
			    strcmp(trim(n_iins_ply),"136")==0 ||
			    strcmp(trim(n_iins_ply),"147")==0 ||
			    strcmp(trim(n_iins_ply),"166")==0 ||
			    strcmp(trim(n_iins_ply),"266")==0 ||
			    strcmp(trim(n_iins_ply),"171")==0 ||
			    strcmp(trim(n_iins_ply),"172")==0 ||
			    strcmp(trim(n_iins_ply),"173")==0 ||
			    strcmp(trim(n_iins_ply),"174")==0 ||
			    strcmp(trim(n_iins_ply),"175")==0 )
			continue;
			
			/** why ? �אּ���e�O�o 950721
			�]���w���̤֬O10��,���B����0
			if ( mins_app == 0 )
			mins_app = 10;
			**/
			if ( mins_app == 0 ) continue;
			
			/** �d��adjustment_ply�ɬO�_�s�b **/
			$EXECUTE CUR_STMT2
			    INTO $n_dply_begin, $n_iissue_yy, $n_iissue_mm,
			         $n_ibrand, $n_icar_type,
			         $n_qcylinder, $n_iengine, $n_itag, $n_flimit,
			         $n_ipdmg_align, $n_iplia_align, $n_ipro_year,
			         $n_ipbrg_align, $n_dvp_code2,
			         $n_qpro_month,
			         $n_iassured,$n_ply_ibirth_yy, $n_fsex, $n_fmarriage,$n_dissue,$n_dbirth
			   using $n_iclaim;
	
	          sprintf_s(pdmg_align, sizeof pdmg_align, "%d", ipdmg_align);
	          sprintf_s(plia_align, sizeof plia_align, "%d", iplia_align);
			
			if (SQLCODE == SQLNOTFOUND)
			{
				continue;
			}
	          
			/*�O��򥻸��*/
			chk_iendorse = 0;
			iendorse_tmp[0] = '\0';
			strcpy(iendorse_tmp,getPolicyBakData(n_iclaim));
			strcpy(iendorse_tmp,trim(iendorse_tmp));
			printf("--iendorse_tmp[%s] \n",iendorse_tmp);
			if (strlen(iendorse_tmp) == 0)
			{
				chk_iendorse = 0;
				sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT qpt,fpt,mcar_price,nvl(b.plia_acc,0),nvl(b.pdmg_acc,0),b.psex_age,c.psex_age,iassured,fassured, \
				                         NVL(irelative_ply,''), \
				                         (SELECT count(*) FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy AND provision matches '*L*'), \
				                         nequipment \
			                        FROM %s:ply_relation a,%s:policy b,%s:ply_ins_type c  \
			                       WHERE a.ipolicy = b.ipolicy \
			                         AND a.ipolicy = c.ipolicy \
				                     AND a.ipolicy = ? \
				                     AND c.iins_type = ? ",list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname);
				$PREPARE CUR_STMT_ply FROM $stmt_buf;
				$EXECUTE CUR_STMT_ply INTO $n_qpt,$n_fpt,$n_mcar_price,$n_plia_acc,$n_pdmg_acc,$n_psex_age_lia,$n_psex_age_dmg,$n_iassured_match,$n_fassured,$irelative_ply,$n_cnt_L,$n_nequipment
				                      using $n_ipolicy,$n_iins_ply;
				if (SQLCODE == SQLNOTFOUND) 
				{	
					v_sMsg[0] = '\0';
					rc = insert_ca_log("car9998","A",n_iclaim,n_dgroup,"�O���Ƨ䤣��",userid,v_sMsg);
				}
			}	
			else 
			{
				chk_iendorse = 1;
				sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT qpt,fpt,mcar_price,nvl(b.plia_acc,0),nvl(b.pdmg_acc,0),b.psex_age,c.psex_age,iassured,fassured, \
				                         NVL(irelative_ply,''), \
				                         (SELECT count(*) FROM %s:ply_ins_type_bak WHERE ipolicy = a.ipolicy AND provision matches '*L*'), \
				                         nequipment \
				                    FROM %s:ply_relation_bak a,%s:policy_bak b,%s:ply_ins_type_bak c \
				                   WHERE b.ipolicy = a.ipolicy \
				                     AND c.ipolicy = a.ipolicy \
				                     AND b.iendorse = a.iendorse \
				                     AND c.iendorse = a.iendorse \
				                     AND a.iendorse = ? \
				                     AND c.iins_type = ? ",list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname);
				$PREPARE CUR_STMT_ply_bak FROM $stmt_buf;
				$EXECUTE CUR_STMT_ply_bak INTO $n_qpt,$n_fpt,$n_mcar_price,$n_plia_acc,$n_pdmg_acc,$n_psex_age_lia,$n_psex_age_dmg,$n_iassured_match,$n_fassured,$irelative_ply,$n_cnt_L,$n_nequipment
				                         using $iendorse_tmp,$n_iins_ply;
				if (SQLCODE == SQLNOTFOUND) 
				{
					sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT qpt,fpt,mcar_price,b.plia_acc,b.pdmg_acc,b.psex_age,c.psex_age,iassured,fassured, \
				                         NVL(irelative_ply,''), \
				                         (SELECT count(*) FROM %s:ply_ins_type WHERE ipolicy = a.ipolicy AND provision matches '*L*') \
			                        FROM %s:ply_relation a,%s:policy b,%s:ply_ins_type c  \
			                       WHERE a.ipolicy = b.ipolicy \
			                         AND a.ipolicy = c.ipolicy \
				                     AND a.ipolicy = ? \
				                     AND c.iins_type = ? ",list[k].dbname,list[k].dbname,list[k].dbname,list[k].dbname);
				   $PREPARE CUR_STMT_ply FROM $stmt_buf;
				   $EXECUTE CUR_STMT_ply INTO $n_qpt,$n_fpt,$n_mcar_price,$n_plia_acc,$n_pdmg_acc,$n_psex_age_lia,$n_psex_age_dmg,$n_iassured_match,$n_fassured,$irelative_ply,$n_cnt_L
				                        using $n_ipolicy,$n_iins_ply;
					if (SQLCODE == SQLNOTFOUND) 
					{	
						v_sMsg[0] = '\0';
						rc = insert_ca_log("car9998","A",n_iclaim,n_dgroup,"�O���Ƨ䤣��",userid,v_sMsg);
					}
				}
			}
			printf("--604 n_qpt[%f],n_fpt[%s],n_mcar_price[%f],n_plia_acc[%f],n_pdmg_acc[%f],n_psex_age_lia[%f],n_psex_age_dmg[%f] \n",n_qpt,n_fpt,n_mcar_price,n_plia_acc,n_pdmg_acc,n_psex_age_lia,n_psex_age_dmg);
			printf("chk_iendorse[%d]\n",chk_iendorse);
			
			if (strcmp(trim(irelative_ply),"")==0)
				strcpy(n_icomp_card,"");
			else 
			{
				sprintf_s(stmt_buf, sizeof stmt_buf,"SELECT NVL(icard,'') FROM %s:ply_relation WHERE ipolicy = '%s'",list[k].dbname,irelative_ply);
				$PREPARE comp_card FROM $stmt_buf;
				$EXECUTE comp_card INTO $n_icomp_card;	
			}
			
			if (strcmp(trim(n_iassured_match),trim(n_iassured)) !=0)
			{
				rc = insert_ca_log("car9998","A",iclaim,n_dgroup,"�Q�O�I�H����",userid,v_sMsg);
				continue;
			}
				
			new_dply_begin = 0;
			n_mdeduct = 0;
			n_minjure_cover = n_mdeath_cover = n_mdamage_cover =0;
			/*minjure_cover = death_cover = mdamage_cover =0;*/
			strcpy(n_provision," ");
			
			rc = getPlyInsHistData(n_iclaim, n_iins_type, &n_mdeduct, &n_provision, &n_minjure_cover, &n_mdeath_cover, &n_mdamage_cover, &new_dply_begin);
			if( rc != M_CM_OK) 
			{
				v_sMsg[0] = '\0';
				rc = insert_ca_log("car9998","A",iclaim,n_dgroup,"�z�߾��v��Ƨ䤣��",userid,v_sMsg);
			}
			printf("\n rc[%d] n_iclaim[%s], n_iins_type[%s], n_mdeduct[%d], n_provision[%s] \n\n",
			       rc,n_iclaim, n_iins_type, n_mdeduct, n_provision);
			printf("\n n_minjure_cover[%d], n_mdeath_cover[%d], n_mdamage_cover[%d], new_dply_begin[%d] \n\n",
			       n_minjure_cover, n_mdeath_cover, n_mdamage_cover, new_dply_begin);
			       
			printf("--n_iins_type[%s]--\n",n_iins_type);
			printf("--iins_type[%s]--\n",iins_type);
		        
			n_mins_stl = 0;
			n_mins_proc = 0;
			n_mins_dedu = 0;
			n_qlia2 = 0;
			n_fstl[0] = '\0';
			n_iclose_type = 0;
			n_flast[0] = '\0';
			p_msettle = 0;
			p_flag_close = 0;
	
			/***** �d�߭p��ѤΩ����� *****/
			stlcnt_a = 0;
			$OPEN scur_stl USING $n_iclaim, $n_iins_type, $enddate_l;
			while(1)
			{
				$FETCH scur_stl INTO $n_iins_type, $n_fstl, $n_iclose_type,
				                     $n_qlia2,
				                     $n_mins_stl, $n_mins_proc,
				                     $n_flast, $n_mins_dedu, $n_istl_flag,
				                     $n_iself_duty,$n_ioth_duty,$n_ianoth_duty;
						
				if (SQLCODE == SQLNOTFOUND) 
				{
					n_iself_duty = 0;
					n_ioth_duty = 0;
					n_ianoth_duty = 0;
					break;
				}
				stlcnt_a++;
				
				if (n_flast[0] == '1')
				{
					p_flag_close=1;
					break;
				}
				/*** �w�M���B ***/
				if (n_fstl[0] == '1')
					p_msettle += (n_mins_stl + n_mins_proc);
				else if (n_fstl[0] == '2')
					p_msettle -= (n_mins_stl - n_mins_proc);
			}
			$CLOSE scur_stl;
			
			/***** �w�M�h���L���e *****/
			if (p_flag_close == 1)	continue;
	
			if (stlcnt_a == 0)
			{		
				if (strcmp(trim(n_iins_ply),"24")==0)
				{
					if( strcmp(trim(n_iacc_reason),"11") == 0 )
						strcpy(n_iacc_reason,"12");
				}
			}
	
			$EXECUTE Cur_id
			    INTO $n_drate_ym, $n_provision
			    using $n_ipolicy,$n_iins_ply;
			printf("iins_type[%s]iins_ply[%s] ==> drate_ym[%s] \n",n_iins_type,n_iins_ply, n_drate_ym);
			printf(" ==== drate_ym[%s]\n", n_drate_ym );
			printf(" ==== n_provision[%s]\n", n_provision );
			/*** �D���M���B ***/
			mins_app = mins_app - p_msettle;
	
			/*  �w�����B���o��0,�̤�10����,�ҥH�]��10
			  if (mins_app < 0)
	              mins_app = 10;
				�w�����B�p��0�����٭n�e*/
			if (mins_app < 0) continue;
	
			/** �C�L�X�p, �Ĥ@�����~ **/
			if (strcmp(n_iclaim, iclaim)!=0)
			{
				if (count1!=0)
				{
	  				if(fexist_31)
					{
						rc = getPlyInsHistData(iclaim, "31", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
						get_data("31");
						if(fError)
						{
							printf("<fError>\n");
						}
						else
						{
							if(fRowError)
							{
								sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim,  iclose_type);
								fprintf(fptr_err, "<31>:%s\n", buf);
							}
							else
							{
								count++;
								fprintf(fptr, "%s\n", prtstr);
							}
						}
					}
	
					fRowError = FALSE;
					
					if(fexist_231)
					{
						rc = getPlyInsHistData(iclaim, "231", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
						get_data("231");
						if(fError)
						{
							printf("<fError>\n");
						}
						else
						{
							if(fRowError)
							{
								sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim,  iclose_type);
								fprintf(fptr_err, "<231>:%s\n", buf);
							}
							else
							{
								count++;
								fprintf(fptr, "%s\n", prtstr);
							}
						}
					}
	
					fRowError = FALSE;
	
	  				if(fexist_131)
					{
						rc = getPlyInsHistData(iclaim, "131", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
						get_data("131");
						printf("--131--\n");
						if(fError)
						{
							printf("<fError>\n");
						}
						else
						{
							if(fRowError)
							{
								sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim,  iclose_type);
								fprintf(fptr_err, "<131>:%s\n", buf);
							}
							else
							{
							count++;
							fprintf(fptr, "%s\n", prtstr);
							}
						}
					}
	
					fRowError = FALSE;
					
					if(fexist_331)
					{
						rc = getPlyInsHistData(iclaim, "331", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
						get_data("331");
						printf("--331--\n");
						if(fError)
						{
							printf("<fError>\n");
						}
						else
						{
							if(fRowError)
							{
								sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim,  iclose_type);
								fprintf(fptr_err, "<331>:%s\n", buf);
							}
							else
							{
							count++;
							fprintf(fptr, "%s\n", prtstr);
							}
						}
					}
	
					fRowError = FALSE;
	
	  				if (fexist_29)
					{
						rc = getPlyInsHistData(iclaim, "29", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
						get_data("29");
						printf("--29--\n");
						if(fError)
						{
							printf("<fError>\n");
						}
						else
						{
							if(fRowError)
							{
								sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim,  iclose_type);
								fprintf(fptr_err, "<29>:%s\n", buf);
							}
							else
							{
								count++;
								fprintf(fptr, "%s\n", prtstr);
							}
						}
					}
					mins_app_29 = 0;
					fexist_29 = FALSE;
					fRowError = FALSE;
					
					if (fexist_24)
					{
						rc = getPlyInsHistData(iclaim, "24", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
						get_data("24");
						printf("--24--\n");
						if(fError)
						{
							printf("<fError>\n");
						}
						else
						{
							if(fRowError)
							{
								sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim,  iclose_type);
								fprintf(fptr_err, "<24>:%s\n", buf);
							}
							else
							{
								count++;
								fprintf(fptr, "%s\n", prtstr);
							}
						}
					}
					mins_app_24 = 0;
					fexist_24 = FALSE;
					fRowError = FALSE;
										
					if (fexist_26)
					{
						rc = getPlyInsHistData(iclaim, "26", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
						get_data("26");
						printf("--26--\n");
						if(fError)
						{
							printf("<fError>\n");
						}
						else
						{
							if(fRowError)
							{
								sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim,  iclose_type);
								fprintf(fptr_err, "<26>:%s\n", buf);
							}
							else
							{
								count++;
								fprintf(fptr, "%s\n", prtstr);
							}
						}
					}
					mins_app_26 = 0;
					fexist_26 = FALSE;
					fRowError = FALSE;	
				
					if (fexist_30)
					{
						rc = getPlyInsHistData(iclaim, "30", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
						get_data("30");
						printf("--30--\n");
						if(fError)
						{
							printf("<fError>\n");
						}
						else
						{
							if(fRowError)
							{
								sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim,  iclose_type);
								fprintf(fptr_err, "<30>:%s\n", buf);
							}
							else
							{
								count++;
								fprintf(fptr, "%s\n", prtstr);
							}
						}
					}
					mins_app_30 = 0;
					fexist_30 = FALSE;
					fRowError = FALSE;
					
					if (fexist_35)
					{
						rc = getPlyInsHistData(iclaim, "35", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
						get_data("35");
						printf("--35--\n");
						if(fError)
						{
							printf("<fError>\n");
						}
						else
						{
							if(fRowError)
							{
								sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim,  iclose_type);
								fprintf(fptr_err, "<35>:%s\n", buf);
							}
							else
							{
								count++;
								fprintf(fptr, "%s\n", prtstr);
							}
						}
					}
					mins_app_35 = 0;
					fexist_35 = FALSE;
					fRowError = FALSE;
					
					if (fexist_55)
					{
						rc = getPlyInsHistData(iclaim, "55", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
						get_data("55");
						printf("--55--\n");
						if(fError)
						{
							printf("<fError>\n");
						}
						else
						{
							if(fRowError)
							{
								sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim,  iclose_type);
								fprintf(fptr_err, "<55>:%s\n", buf);
							}
							else
							{
								count++;
								fprintf(fptr, "%s\n", prtstr);
							}
						}
					}
					mins_app_55 = 0;
					fexist_55 = FALSE;
					fRowError = FALSE;
					
					get_data("99");
					if(fError)
					{
						printf("<fError>\n");
					}
					else
					{
						if(fRowError)
						{
							sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim,  iclose_type);
							fprintf(fptr_err, "<99>:%s\n", buf);
						}
						else
						{
							count++;
							fprintf(fptr, "%s\n", prtstr);
						}
					}
	
					qinjure31 = qdeath31 = mins_app31 = mins_proc31 = 0;
					qinjure99 = qdeath99 = mins_app99 = mins_proc99 = 0;
					mins_stl31 = mins_stl99 = 0;
					mdamage_cover = mdamage_cover31 = 0;
					fexist_31 = FALSE;
					fexist_131 = FALSE;
					fexist_231 = FALSE;
					fexist_331 = FALSE;
					count1=0;
					in_cover31 = 0;
					
					app_subtot=comp_subtot=stl_subtot=prem_subtot=0;
					app_tot_31=comp_tot_31=stl_tot_31=prem_tot_31=0;
					qinjure_tot=qdeath_tot=qinjure31=qdeath31=0;
				}
			}
	
			/** �٭�s��� **/
			/*stl_ins_type*/
			strcpy(iclaim, n_iclaim);
			iclose_type= n_iclose_type;
			strcpy(iins_type, trim(n_iins_type));
			strcpy(iins_ply, n_iins_ply);
			strcpy(drate_ym, n_drate_ym);
			printf("1st drate_ym[%s]\n",drate_ym);
			strcpy(provision, n_provision);
			qlia2 =n_qlia2;
			mins_comp=n_mins_comp;
			mins_stl = 0;
			mins_proc = 0;
			mins_dedu=n_mins_dedu;
			strcpy (fstl ,n_fstl );
			strcpy (flast ,n_flast);
			
			/*settlement*/
			strcpy(ipolicy, n_ipolicy);
			dclose=n_dclose;
			dgroup=n_dgroup;
			strcpy(istl_flag, n_istl_flag);
			strcpy(chk_157, n_chk_157);
			iself_duty = n_iself_duty;
			ioth_duty = n_ioth_duty;
			ianoth_duty = n_ianoth_duty;
			
			/*adjustment_ply*/
			dply_begin=n_dply_begin;
			qcylinder =n_qcylinder;
			strcpy(iissue_yy , n_iissue_yy);
			strcpy(iissue_mm , n_iissue_mm);
			strcpy(ibrand    , n_ibrand);
			strcpy(icar_type , n_icar_type);
			strcpy(iengine   , n_iengine);
			strcpy(itag      , n_itag);
			strcpy(flimit    , n_flimit);
			strcpy(ipro_year , n_ipro_year);
			ipdmg_align=n_ipdmg_align;
			iplia_align=n_iplia_align;
			ipbrg_align=n_ipbrg_align;
			qpro_month=n_qpro_month;
			strcpy(dvp_code2,n_dvp_code2);
			strcpy(iassured  , n_iassured);
	        strcpy(dbirth_yy , n_ply_ibirth_yy);
	        strcpy(fsex      , n_fsex);
	        strcpy(fmarriage , n_fmarriage);
			strcpy(dissue , n_dissue);
			dbirth = n_dbirth;
			
			/*appraisal*/
			strcpy(dclaim      , n_dclaim);
			strcpy(iacc_license, n_iacc_license);
			strcpy(iacc_birth_yy  , n_iacc_birth_yy);
			strcpy(facc_sex    , n_facc_sex);
			strcpy(facc_marri  , n_facc_marri);
			strcpy(iacc_reason , n_iacc_reason);
			strcpy(daccident   , n_daccident);
			strcpy(fpart       , n_fpart);
			strcpy(dvp_code1,n_dvp_code1);
			strcpy(facc_rel    , n_facc_rel);
			strcpy(ifacnum     , n_ifacnum);
			strcpy(facc_duty     , n_facc_duty);
			strcpy(fdmg_duty     , n_fdmg_duty);
			f_1060101_dacc = n_f_1060101_dacc;
			
			/*policy*/
			strcpy(fpt, n_fpt);
			qpt=n_qpt;
			mcar_price = n_mcar_price;
			plia_acc = n_plia_acc;
			pdmg_acc = n_pdmg_acc;
			psex_age_lia = n_psex_age_lia;
			psex_age_dmg = n_psex_age_dmg;
			
			strcpy(iassured_match, n_iassured_match);
			strcpy(fassured,  n_fassured);
			strcpy(icomp_card,  trim(n_icomp_card));
			cnt_L = n_cnt_L;
			strcpy(nequipment, trim(n_nequipment));
			/** �٭�s��� **/
			
			/*** yyyy/mm/dd --> mm/dd/yyyy ***/
			strncpy(daccident_yyyy,&daccident[0],4);
			daccident_yyyy[4] = '\0';
			strncpy(daccident_mm,&daccident[5],2);
			daccident_mm[2] = '\0';
			strncpy(daccident_dd,&daccident[8],2);
			daccident_dd[2] = '\0';
			
			strcpy(provision,trim(n_provision));
			
			minjure_cover = n_minjure_cover; 
			mdeath_cover = n_mdeath_cover;
			mdamage_cover = n_mdamage_cover;
			
			/*�ۭt�B&���[����*/
			mdeduct = n_mdeduct;
			
			iprovision_P = 0;
			iprovision_Q = 0;
			iprovision_M = 0;
			iprovision_Z = 0;
			chk_provision = 0;
			chk_division = 0;
	
			printf("--[%s]--\n",iins_type);
			fRowError = FALSE;              /* This record has no error yet */
	
			count1++;
			if(strcmp(trim(iins_type), "93") == 0 || strcmp(iins_type, "94") == 0 ||
			   strcmp(trim(iins_type), "95") == 0)
			{
				fexist_31 = TRUE;			
				printf("--provision[%s]\n",provision);
			}
			
			if(strcmp(trim(iins_type), "193") == 0 || strcmp(iins_type, "194") == 0 ||
			   strcmp(trim(iins_type), "195") == 0)
			{
				fexist_231 = TRUE;			
				printf("--provision[%s]\n",provision);
			}
			
			if(strcmp(trim(iins_type), "131A") == 0 || strcmp(iins_type, "131B") == 0 ||
			   strcmp(trim(iins_type), "131C") == 0)
				fexist_131 = TRUE;
			
			if(strcmp(trim(iins_type), "331A") == 0 || strcmp(iins_type, "331B") == 0 ||
			   strcmp(trim(iins_type), "331C") == 0)
				fexist_331 = TRUE;
			
			if ((strcmp(trim(iins_type),"9A") == 0) ||
			    (strcmp(trim(iins_type),"9B") == 0) ||
			    (strcmp(trim(iins_type),"9C") == 0) ||
			    (strcmp(trim(iins_type),"9D") == 0))
			{
				mins_app_29 += mins_app;
				fexist_29 = TRUE;
				continue;
			}
			else if ((strcmp(trim(iins_type),"4A") == 0) ||
			         (strcmp(trim(iins_type),"4B") == 0) ||
			         (strcmp(trim(iins_type),"4C") == 0) ||
			         (strcmp(trim(iins_type),"4D") == 0))
			{
				mins_app_24 += mins_app;
				fexist_24 = TRUE;
				continue;
			}
			else if ((strcmp(trim(iins_type),"0A") == 0) ||
			         (strcmp(trim(iins_type),"0B") == 0) ||
			         (strcmp(trim(iins_type),"0C") == 0) ||
			         (strcmp(trim(iins_type),"0D") == 0) ||
			         (strcmp(trim(iins_type),"0E") == 0))
			{
				mins_app_30 += mins_app;
				fexist_30 = TRUE;
				continue;
			}
			else if ((strcmp(trim(iins_type),"5A") == 0) ||
			         (strcmp(trim(iins_type),"5B") == 0) ||
			         (strcmp(trim(iins_type),"5C") == 0) ||
			         (strcmp(trim(iins_type),"5D") == 0))
			{
				mins_app_35 += mins_app;
				fexist_35 = TRUE;
				continue;
			}
			else if ((strcmp(trim(iins_type),"55A") == 0) ||
			         (strcmp(trim(iins_type),"55B") == 0) ||
			         (strcmp(trim(iins_type),"55C") == 0))
			{
				mins_app_55 += mins_app;
				fexist_55 = TRUE;
				continue;
			}
			else if((strcmp(iins_type,"26A") == 0) ||
			        (strcmp(iins_type,"26B") == 0) ||
			        (strcmp(iins_type,"26C") == 0) ||
			        (strcmp(iins_type,"26D") == 0) )
			{
				mins_app_26 += mins_app;
				fexist_26 = TRUE;
				continue;
			}
			else
			{
				chk_division=0;
				get_data(iins_type);
			}
			count++;
			
			if(fError)
			{
				printf("<fError>\n");
			}
			else
			{
				if(fRowError)
				{
					sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim, iclose_type);
					fprintf(fptr_err, "[%s]:%s\n", iins_type,buf);
				}
				else
				{
					fprintf(fptr, "%s\n", prtstr);
				}
			}
			
			
			chk_division2 = 0;
			printf("--1210  chk_division[%d],iins_type[%s] \n ",chk_division,iins_type);
			if(chk_division > 0)
			{
				chk_division2 = 1;
				strcpy(iins_main,iins_type);
				if (iprovision_P > 0) 
				{
					get_data("P"); 
					count++;
				}
				else if (iprovision_Q > 0)
				{
					get_data("Q");
					count++;
				}
				else if (iprovision_M > 0)
				{
					get_data("M");
					count++;
				}
				else if (iprovision_Z > 0)
				{
					get_data("Z");
					count++;	
				}
				chk_division2 = 0;
				chk_division = 0;
				
				if(fError)
				{
					printf ("<fError>\n");
				}
				else
				{
					if(fRowError)
					{
						printf("<<<<<<<<fRowError >>>>>>>>>>>\n");
						sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim, iclose_type);
						fprintf(fptr_err, "[%s]:%s\n", iins_type,buf);
					}
					else
					{
						fprintf(fptr, "%s\n", prtstr);
					}
				}
			}
		}
		$CLOSE scur_app;
		$FREE  scur_app;
	
		printf("BEFORE GET_DATA():31\n");
		fRowError = FALSE;
		if(fexist_31)
		{
			rc = getPlyInsHistData(iclaim, "31", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
			if( rc != M_CM_OK) 
			{
				v_sMsg[0] = '\0';
				rc = insert_ca_log("car9998","A",iclaim,dgroup,"�z�߾��v��Ƨ䤣��",userid,v_sMsg);
			}
			get_data("31");
			if(fError)
			{
				printf("<fError>\n");
			}
			else
			{
				if(fRowError)
				{
					sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim, iclose_type);
					fprintf(fptr_err, "[31]:%s\n", buf);
				}
				else
				{
					count++;
					printf ("aaaaaaaaaa[%s]\n",prtstr);
					fprintf(fptr, "%s\n", prtstr);
				}
			}
		}
		
		if(fexist_231)
		{
			rc = getPlyInsHistData(iclaim, "231", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
			if( rc != M_CM_OK) 
			{
				v_sMsg[0] = '\0';
				rc = insert_ca_log("car9998","A",iclaim,dgroup,"�z�߾��v��Ƨ䤣��",userid,v_sMsg);
			}
			get_data("231");
			if(fError)
			{
				printf("<fError>\n");
			}
			else
			{
				if(fRowError)
				{
					sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim, iclose_type);
					fprintf(fptr_err, "[231]:%s\n", buf);
				}
				else
				{
					count++;
					printf ("aaaaaaaaaa[%s]\n",prtstr);
					fprintf(fptr, "%s\n", prtstr);
				}
			}
		}
	
		if(fexist_131)
		{
			rc = getPlyInsHistData(iclaim, "131", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
			if( rc != M_CM_OK) 
			{
				v_sMsg[0] = '\0';
				rc = insert_ca_log("car9998","A",iclaim,dgroup,"�z�߾��v��Ƨ䤣��",userid,v_sMsg);
			}
			get_data("131");
			if(fError)
			{
				printf("<fError>\n");
			}
			else
			{
				if(fRowError)
				{
					sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim, iclose_type);
					fprintf(fptr_err, "[131]:%s\n", buf);
				}
				else
				{
					count++;
					fprintf(fptr, "%s\n", prtstr);
				}
			}
		}
		
		if(fexist_331)
		{
			rc = getPlyInsHistData(iclaim, "331", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
			if( rc != M_CM_OK) 
			{
				v_sMsg[0] = '\0';
				rc = insert_ca_log("car9998","A",iclaim,dgroup,"�z�߾��v��Ƨ䤣��",userid,v_sMsg);
			}
			get_data("331");
			if(fError)
			{
				printf("<fError>\n");
			}
			else
			{
				if(fRowError)
				{
					sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim, iclose_type);
					fprintf(fptr_err, "[331]:%s\n", buf);
				}
				else
				{
					count++;
					fprintf(fptr, "%s\n", prtstr);
				}
			}
		}
		
		if(fexist_26)
		{
			rc = getPlyInsHistData(iclaim, "26", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
			if( rc != M_CM_OK) 
			{
				v_sMsg[0] = '\0';
				rc = insert_ca_log("car9998","A",iclaim,dgroup,"�z�߾��v��Ƨ䤣��",userid,v_sMsg);
			}
			get_data("26");
			if(fError)
			{
				printf("<fError>\n");
			}
			else
			{
				if(fRowError)
				{
					sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim, iclose_type);
					fprintf(fptr_err, "[26]:%s\n", buf);
				}
				else
				{
					count++;
					fprintf(fptr, "%s\n", prtstr);
				}
			}
		}
	
		if(fexist_29)
		{
			rc = getPlyInsHistData(iclaim, "29", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
			if( rc != M_CM_OK) 
			{
				v_sMsg[0] = '\0';
				rc = insert_ca_log("car9998","A",iclaim,dgroup,"�z�߾��v��Ƨ䤣��",userid,v_sMsg);
			}
			get_data("29");
			if(fError)
			{
				printf("<fError>\n");
			}
			else
			{
				if(fRowError)
				{
					sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim, iclose_type);
					fprintf(fptr_err, "[29]:%s\n", buf);
				}
				else
				{
					count++;
					fprintf(fptr, "%s\n", prtstr);
				}
			}
		}
		
		if(fexist_24)
		{
			rc = getPlyInsHistData(iclaim, "24", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
			if( rc != M_CM_OK) 
			{
				v_sMsg[0] = '\0';
				rc = insert_ca_log("car9998","A",iclaim,dgroup,"�z�߾��v��Ƨ䤣��",userid,v_sMsg);
			}
			get_data("24");
			if(fError)
			{
				printf("<fError>\n");
			}
			else
			{
				if(fRowError)
				{
					sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim, iclose_type);
					fprintf(fptr_err, "[24]:%s\n", buf);
				}
				else
				{
					count++;
					fprintf(fptr, "%s\n", prtstr);
				}
			}
		}
		
		if(fexist_30)
		{
			rc = getPlyInsHistData(iclaim, "30", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
			if( rc != M_CM_OK) 
			{
				v_sMsg[0] = '\0';
				rc = insert_ca_log("car9998","A",iclaim,dgroup,"�z�߾��v��Ƨ䤣��",userid,v_sMsg);
			}
			get_data("30");
			if(fError)
			{
				printf("<fError>\n");
			}
			else
			{
				if(fRowError)
				{
					sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim, iclose_type);
					fprintf(fptr_err, "[30]:%s\n", buf);
				}
				else
				{
					count++;
					fprintf(fptr, "%s\n", prtstr);
				}
			}
		}
		
		if(fexist_35)
		{
			rc = getPlyInsHistData(iclaim, "35", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
			if( rc != M_CM_OK) 
			{
				v_sMsg[0] = '\0';
				rc = insert_ca_log("car9998","A",iclaim,dgroup,"�z�߾��v��Ƨ䤣��",userid,v_sMsg);
			}
			get_data("35");
			if(fError)
			{
				printf("<fError>\n");
			}
			else
			{
				if(fRowError)
				{
					sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim, iclose_type);
					fprintf(fptr_err, "[35]:%s\n", buf);
				}
				else
				{
					count++;
					fprintf(fptr, "%s\n", prtstr);
				}
			}
		}
		
		if(fexist_55)
		{
			rc = getPlyInsHistData(iclaim, "55", &mdeduct, &provision, &minjure_cover, &mdeath_cover, &mdamage_cover, &new_dply_begin);
			if( rc != M_CM_OK) 
			{
				v_sMsg[0] = '\0';
				rc = insert_ca_log("car9998","A",iclaim,dgroup,"�z�߾��v��Ƨ䤣��",userid,v_sMsg);
			}
			get_data("55");
			if(fError)
			{
				printf("<fError>\n");
			}
			else
			{
				if(fRowError)
				{
					sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim, iclose_type);
					fprintf(fptr_err, "[55]:%s\n", buf);
				}
				else
				{
					count++;
					fprintf(fptr, "%s\n", prtstr);
				}
			}
		}
		
		printf("BEFORE GET_DATA():99\n");
		if (count1>0)
		{
			fRowError = FALSE;
			get_data("99");
			if(fError)
			{
				printf("<fError>\n");
			}
			else
			{
				if(fRowError)
				{
					sprintf_s(buf, sizeof buf, "<ply.%s,clm.%s,cls_type.%d>\n",ipolicy, iclaim, iclose_type);
					fprintf(fptr_err, "[31]:%s\n", buf);
				}
				else
				{
					count++;
					fprintf(fptr, "%s\n", prtstr);
				}
			}
		}
	}
	fclose(fptr);
	
	printf("--1525 count[%d] \n",count);
	rfmtlong(stl_total,"&&&&&&&&&&&&",stl_total_c);
	res = getApHome(aphome);
	if (res<0)
	{
		printf("In sigalrmcatcher func==>read config file error!!\n");
		exit(1);
	}

	if(count==0)
		fprintf(fptr_err,"%s\n","�L���!!");
	else
	{
		printf("--1540 count[%d] \n",count);
        /* �s����� */
        $SELECT iquota INTO $iquota FROM officer WHERE iofficer=$userid;

		rtoday(&Today);     /* get today's datetime */

		strcpy(Taipei_FullName,get_full_dbname("00"));
		$WHENEVER SQLERROR GOTO errexit;
		
		sprintf_s(stmt, sizeof stmt,"DELETE FROM %s:ca_develop \
		               WHERE iclass='9998' AND ibranch=? AND data_yyyymm=? ",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus1 FROM $stmt;
		$EXECUTE insert_cus1 using $DBName,$data_yyyymm;

		sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_develop \
		                (iquota,data_yyyymm,iclass,dsend,ibranch, \
                         product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
						VALUES(?,?,'9998',?,?,'10','C',?,0,0,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus10 FROM $stmt;
		$EXECUTE insert_cus10
			USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_10;
			
		sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_develop \
		                (iquota,data_yyyymm,iclass,dsend,ibranch, \
                         product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
						VALUES(?,?,'9998',?,?,'11','C',?,0,0,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus11 FROM $stmt;
		$EXECUTE insert_cus11
			USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_11;
			
		sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_develop \
		                (iquota,data_yyyymm,iclass,dsend,ibranch, \
                         product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
						VALUES(?,?,'9998',?,?,'12','C',?,0,0,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus12 FROM $stmt;
		$EXECUTE insert_cus12
			USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_12;
			
		sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_develop \
		                (iquota,data_yyyymm,iclass,dsend,ibranch, \
                         product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
						VALUES(?,?,'9998',?,?,'13','C',?,0,0,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus13 FROM $stmt;
		$EXECUTE insert_cus13
			USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_13;
			
		sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_develop \
		                (iquota,data_yyyymm,iclass,dsend,ibranch, \
                         product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
						VALUES(?,?,'9998',?,?,'28','C',?,0,0,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus28 FROM $stmt;
		$EXECUTE insert_cus28
			USING $iquota,$data_yyyymm,$Today,$DBName,$mprem_28;
			
		sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_develop \
		                (iquota,data_yyyymm,iclass,dsend,ibranch, \
                         product_kind,iins_class,mprem,qcnt,pure_mprem,mdrunk_pure_prem) \
						VALUES(?,?,'9998',?,?,'99','C',?,?,0,0)",Taipei_FullName);
		printf("stmt[%s]\n",stmt);
		$PREPARE insert_cus2 FROM $stmt;
		$EXECUTE insert_cus2
			USING $iquota,$data_yyyymm,$Today,$DBName,$prem_total,$count;		
	}
	return SUCCESS;

errexit:
	printf("SOLCODE=[%d]errstr[%s]\n",SQLCODE,sqlca.sqlerrm);
	sprintf_s(errmsg, sizeof errmsg,"SOLCODE=%d sqlca.sqlerrm=%s",SQLCODE,sqlca.sqlerrm);
	fprintf(fptr_err,"%s\n",errmsg);
	return SQLCODE;
}

/************************************************************************/
get_data(sIns_type)
$char *sIns_type;
{
	long instype_i=0;
	$char ibrand6[7];
	$int cnt=0,cnt2=0;
	short check31,check131,check231,check331;
	
	sprintf_s(stmt, sizeof stmt,"SELECT fcar_class FROM car_type \
	                WHERE fclass = '1' AND icode = ? ");
	$PREPARE CUR_CARCLASS FROM $stmt;
	
	f_1060101 = f_1090101 = f_1120501 = 0;
	$EXECUTE ply_data INTO $ply_dpolicy,$f_1060101,$f_1090101,$f_1120501 using $ipolicy;
	strcpy(ply_DB, get_car_full_db(ipolicy));
	
	if(strcmp(sIns_type, "31") == 0 || strcmp(sIns_type, "93") == 0 ||
	   strcmp(sIns_type, "94") == 0 || strcmp(sIns_type, "95") == 0)
	{
		check31 = TRUE;
	}
	else if(strcmp(sIns_type, "231") == 0 || strcmp(sIns_type, "193") == 0 ||
	        strcmp(sIns_type, "194") == 0 || strcmp(sIns_type, "195") == 0)
	{
		check231 = TRUE;
	}
	else if(strcmp(sIns_type, "131") == 0  || strcmp(sIns_type, "131A") == 0 ||
	        strcmp(sIns_type, "131B") == 0 || strcmp(sIns_type, "131C") == 0)
	{
		check131 = TRUE;
	}
	else if(strcmp(sIns_type, "331") == 0  || strcmp(sIns_type, "331A") == 0 ||
	        strcmp(sIns_type, "331B") == 0 || strcmp(sIns_type, "331C") == 0)
	{
		check331 = TRUE;
	}
	
	if (strcmp(sIns_type, "P") != 0 && strcmp(sIns_type, "Q") != 0 && 
	    strcmp(sIns_type, "M") != 0 && strcmp(sIns_type, "Z") != 0)
	{
		$EXECUTE CUR_INSGRP INTO $fins_grp,$iri_ins,$fkind USING $sIns_type;
		strcpy(iins_main,sIns_type);
		strcpy(t_iins_type_ori,sIns_type);
	}
	else 
	{
		$EXECUTE CUR_INSGRP INTO $fins_grp,$iri_ins,$fkind USING $iins_main;
		strcpy(t_iins_type_ori,sIns_type);
	}
	
	if (strncmp(sIns_type,"99",2) == 0)
	{
		/*if(check31) 
		{
			$SELECT iins_ply into $iins_ply FROM insurance_type WHERE iins_type = '31';
			strcpy(iins_ply,trim(iins_ply));
		}
		else if(check131) 
		{
			$SELECT iins_ply into $iins_ply FROM insurance_type WHERE iins_type = '131';
			strcpy(iins_ply,trim(iins_ply));
		}*/
		strcpy(iins_ply,"00");
	}	
	else
	{
		$SELECT iins_ply into $iins_ply FROM insurance_type WHERE iins_type = $sIns_type;
		strcpy(iins_ply,trim(iins_ply));
		strcpy(t_iins_type_ori,iins_ply);
		if (strcmp(sIns_type, "P") != 0 && strcmp(sIns_type, "Q") != 0 && 
		    strcmp(sIns_type, "M") != 0 && strcmp(sIns_type, "Z") != 0)
		{
			strcpy(t_iins_type_ori,sIns_type);
		}
	}
	
	chk_provision = 0;
	
	strcpy(provision_tmp,trim(provision));
	strcat(provision_tmp,";");
	strcpy(provision_tmp,trim(provision_tmp));
	
	if ((strstr(provision_tmp,"P;") != NULL) && (strstr(provision_tmp,"K;") == NULL) &&
	   (strcmp(iins_ply,"01")  == 0   || strcmp(iins_ply,"05")  == 0  || 
	    strcmp(iins_ply,"09")  == 0   || strcmp(iins_ply,"11")  == 0  ||
	    strcmp(iins_ply,"201")  == 0  || strcmp(iins_ply,"205")  == 0 || 
	    strcmp(iins_ply,"209")  == 0  || strcmp(iins_ply,"211")  == 0))
	{	iprovision_P = 1; chk_provision++;}
	if ((strstr(provision_tmp,"Q;") != NULL) &&
	   (strcmp(iins_ply,"01") == 0  || strcmp(iins_ply,"05") == 0  ||
		strcmp(iins_ply,"09") == 0  || strcmp(iins_ply,"11") == 0  ||
		strcmp(iins_ply,"201") == 0 || strcmp(iins_ply,"205") == 0 ||
		strcmp(iins_ply,"209") == 0 || strcmp(iins_ply,"211") == 0))
	{	iprovision_Q = 1; chk_provision++;}
	if ((strstr(provision_tmp,"M;") != NULL) &&
	   (strcmp(iins_ply,"01") == 0  || strcmp(iins_ply,"05") == 0  ||
		strcmp(iins_ply,"09") == 0  || strcmp(iins_ply,"11") == 0  || strcmp(iins_ply,"181") == 0 ||
		strcmp(iins_ply,"201") == 0 || strcmp(iins_ply,"205") == 0 ||
		strcmp(iins_ply,"209") == 0 || strcmp(iins_ply,"211") == 0 ))
	{	iprovision_M = 1; chk_provision++;}
	if ((strstr(provision_tmp,"Z;") != NULL) &&
	   (strcmp(iins_ply,"01") == 0  || strcmp(iins_ply,"05") == 0  ||
		strcmp(iins_ply,"09") == 0  || strcmp(iins_ply,"11") == 0  ||
		strcmp(iins_ply,"201") == 0 || strcmp(iins_ply,"205") == 0 ||
		strcmp(iins_ply,"209") == 0 || strcmp(iins_ply,"211") == 0))
	{	iprovision_Z = 1; chk_provision++;}
	
	printf("GET_DATA():sIns_type:[%s],iclaim:[%s],ipolicy:[%s],fstl:[%s],",
	                   sIns_type, iclaim, ipolicy, fstl);
	printf("ipolicy:[%s],iclose_type:[%d],drate_ym[%s],provision[%s]\n",
	        ipolicy,iclose_type, drate_ym,provision);
	
	if (strcmp(sIns_type, "31") == 0  || strcmp(sIns_type, "93") == 0  ||
	    strcmp(sIns_type, "94") == 0  || strcmp(sIns_type, "95") == 0  ||
	    strcmp(sIns_type, "231") == 0 || strcmp(sIns_type, "193") == 0 ||
	    strcmp(sIns_type, "194") == 0 || strcmp(sIns_type, "195") == 0)
	{
	    printf("only 31,93,94,95:GET_DATA():sIns_type:[%s],iclaim:[%s],",
	           sIns_type, iclaim);
	    printf("ipolicy:[%s],fstl:[%s],iclose_type:[%d],qlia2[%ld]\n",
	           ipolicy, fstl, iclose_type, qlia2);
	}
	
	/*���oibroker�g�ٸs��*/
	sprintf_s(stmt, sizeof stmt,"SELECT ibroker,iofficer,bzfrom \
		            FROM %s:ply_relation WHERE ipolicy = '%s' ",ply_DB,ipolicy);
	$PREPARE ply_relat_data FROM $stmt;
	$EXECUTE ply_relat_data INTO $ibroker,$iofficer,$bzfrom;
	
	/* �q��II�|��bzfrom, �Y�S�����O�¸�ƥ���, �ҥH����FUNCTION�� */
	if (bzfrom[0] == '\0' || bzfrom[0] == '' || bzfrom[0] == ' ')
	{
		printf("iofficer[%s]\n", iofficer);
		if (cm_get_bzfrom(iofficer, fbusiness,ibroker_top,bzfrom)== M_CMN_NBROKER_AGENT)
			strcpy(bzfrom,"00");
	}
	
	company_flag=ipolicy[7];
	printf(" company_flag[%c]\n",company_flag);
	strcpy(COMPANY_P,companyid);
	strcpy(COMPANY_F,companyid);
	
	if(strcmp( companyid,"17")==0)
	{
	    if(company_flag > 65 )
	    {
	        $select ipolicy_a
	           into $ipolicy_a
	           from conv_ipolicy
	          where ipolicy_n = $ipolicy;
	
	        strcpy(COMPANY_P,"16");
	
	        printf(" ****************** CAR_COMPANY_E[%s]\n",COMPANY_P);
	    }
	    else
	    {
	        strcpy(ipolicy_a, ipolicy);
	        printf(" ****************** COMPANY_P[%s]\n",COMPANY_P);
	    }

	    iclaim_flag=iclaim[6];
	    printf(" iclaim_flag[%c]\n",iclaim_flag);
	
	    if(iclaim_flag > 65 )
	    {
	        $select distinct iclaim_a
	           into $iclaim_a
	           from conv_iclaim
	          where iclaim_n = $iclaim;
	
	        strcpy(COMPANY_F,"16");
	    }
	    else
	    {
	        strcpy(iclaim_a, iclaim);
	        printf(" ****************** COMPANY_E[%s]\n",COMPANY_F);
	    }
	}
	else
	{
	    strcpy(ipolicy_a, ipolicy);
	    strcpy(iclaim_a, iclaim);
	}
	
	/* field 1 �߮שʽ�N�� */
	strcpy(prtstr, "1");
	strcpy(t_istl, "1");
	
	/* field 2  2-17 �߮ר��z���X */
	strcat(prtstr, "17");
	strcpy(t_icompany,"17");
	
	iclaim_12[0]='\0';
	strncpy(iclaim_12, iclaim_a, 2 );
	iclaim_12[2]='\0';

	if( strcmp(trim(iclaim_12),"0A")==0)
	{
	    strcpy(iclaim_12,"00");
	}
	else if( strcmp(trim(iclaim_12),"2A")==0)
	{
	    strcpy(iclaim_12,"22");
	}
	else if( strcmp(trim(iclaim_12),"3A")==0)
	{
	    strcpy(iclaim_12,"33");
	}
	else if( strcmp(trim(iclaim_12),"4A")==0)
	{
	    strcpy(iclaim_12,"40");
	}
	else if( strcmp(trim(iclaim_12),"6A")==0)
	{
	    strcpy(iclaim_12,"66");
	}
	else if( strcmp(trim(iclaim_12),"7A")==0)
	{
	    strcpy(iclaim_12,"70");
	}
	else
	{
	    strncpy(iclaim_12,iclaim_a,2);
	}
	strcat(prtstr, iclaim_12);
	strncpy(t_iclm_br,iclaim_a,2);
	if( strcmp(COMPANY_F,"16") == 0 )
	{
	    strncat(prtstr, (*iclaim_a=='\0') ? "            " : iclaim_a+2,12);
	    strcpy(t_iclm, (*iclaim_a=='\0') ? " " : iclaim_a+2);
	    t_iclm[12] = '\0';
	}
	else
	{
	    strncat(prtstr, (*iclaim_a=='\0') ? "            " : iclaim_a,12);
	    strcpy(t_iclm, (*iclaim_a=='\0') ? " " : iclaim_a);
	    t_iclm[12] = '\0';
	}
	prtstr[17]='\0';

    /* field 3  18-25 �߮ר��z��� */
    strncpy(dclaim_yyyy, dclaim, 4); dclaim_yyyy[4] = '\0';
    {
        int dclaim_yy_l;
        dclaim_yy_l = atoi(dclaim_yyyy) - 1911;
        rfmtlong(dclaim_yy_l, "&&", dclaim_yy);
    }
    strncpy(dclaim_mm, &dclaim[5], 2); dclaim_mm[2] = '\0';
    strncpy(dclaim_dd, &dclaim[8], 2); dclaim_dd[2] = '\0';
    strcat(prtstr,(*dclaim_yyyy=='\0') ? "0000" : dclaim_yyyy);
    strcat(prtstr,(*dclaim_mm=='\0') ? "00" : dclaim_mm);
    strcat(prtstr,(*dclaim_dd=='\0') ? "00" : dclaim_dd);
	strcpy(t_dclaim,(*dclaim_yyyy=='\0') ? "0000" : dclaim_yyyy);
	strcat(t_dclaim,(*dclaim_mm=='\0') ? "00" : dclaim_mm);
	strcat(t_dclaim,(*dclaim_dd=='\0') ? "00" : dclaim_dd);
	
	/* field 4 26-41 �߮׸��X */
	strcat(prtstr, "17" );
	strcat(prtstr, iclaim_12);
	
	if( strcmp(COMPANY_F,"16") == 0 )
	{
	    strncat(prtstr, (*iclaim_a=='\0') ? "            " : iclaim_a+2,12);
	}
	else
	{
	    strncat(prtstr, (*iclaim_a=='\0') ? "            " : iclaim_a,12);
	}
	
	prtstr[41]='\0';
	/* field 5 42-43 �ߥI/�l�v���� */
	strcat(prtstr, "00");
	t_iclose_type = 0;
	
	/* field 6 44-51 ���פ�� */
	/**** ���M�ߴڵ��פ����000000*/
	strcat(prtstr,"00000000");
	strcpy(t_dgroup,"00000000");

	/* field 7 52-67 �O�渹�X */
	strcat(prtstr, "17");
	strcpy(t_icompany_ply,"17");
	strncpy(ipolicy_br, ipolicy_a, 2); ipolicy_br[2]='\0';
	strcat(prtstr,(*ipolicy_br=='\0') ? "00" : ipolicy_br);
	strncpy(ipolicy_no, &ipolicy_a[3], 12); ipolicy_no[12] = '\0';
	strcat(prtstr,(*ipolicy_no=='\0') ? "            " : ipolicy_no);
	strcpy(t_iply_br,(*ipolicy_br=='\0') ? "00" : ipolicy_br);
	strcpy(t_iply,(*ipolicy_no=='\0') ? " " : ipolicy_no);
	prtstr[67]='\0';
	
	/* field 8 68-73 �}�l�ͮĦ~�� */
	strcpy(dply_begin_c, cm_cdate_str_100(dply_begin));
	cm_split_ymd_100(dply_begin_c,dply_begin_yy,dply_begin_mm,dply_begin_dd);
	{
		strcpy(dply_begin_yyyy,itoa(atoi(dply_begin_yy)+1911));
		strcat(prtstr,(*dply_begin_yyyy=='\0') ? "0000" : dply_begin_yyyy);
		strcpy(t_dply_begin_ym,(*dply_begin_yyyy=='\0') ? "0000" : dply_begin_yyyy);
	}
	strcat(prtstr,(*dply_begin_mm=='\0') ? "00" : dply_begin_mm);
	strcat(t_dply_begin_ym,(*dply_begin_mm=='\0') ? "00" : dply_begin_mm);
	prtstr[73]='\0';
	
	/* field 9 74-77 �O��Ъ��s�� */
	strncpy(ipolicy_no2, &ipolicy_a[13], 4); ipolicy_no2[4] = '\0';
	if (strncmp(chk_157,"Y",1) == 0)
	{
		strcat(prtstr, "0000");
		strcpy(t_iobjno,"0000");
	}
	else if (ipolicy_no2[0]==' ' || ipolicy_no2[0]=='\0' || (strcmp(COMPANY_P,"16")==0) )
	{
	    strcat(prtstr, "0001");
	    strcpy(t_iobjno,"0001");
	}
	else
	{
	    strcat(prtstr, ipolicy_no2);
	    strcpy(t_iobjno,ipolicy_no2);
	}
	prtstr[77]='\0';

	if (strncmp(chk_157,"Y",1) == 0)
	{
		strcat(prtstr,"000000");   /*�o�Ӧ~��*/
		strcat(prtstr,"000000");   /*�s�y�~��*/
		strcat(prtstr,"00000000"); /*�t�P�����N��*/
		strcat(prtstr,"00");       /*���������N��*/
		strcat(prtstr,"00");       /*�����������O�N��*/
		strcpy(t_iissue_ym,"000000");
		strcpy(t_ipro_ym,"000000");
		strcpy(t_ibrand,"00000000");
		strcpy(t_icar_type_ori,"00");
		strcpy(t_icar_type,"00");
		strcpy(t_icar_type_no,"00");
	}
	else
	{
	    /* field 10 78-83 ��l�o�Ӧ~�� */
		/* *** check iissue *** */
		if (iissue_yy[0]=='\0') 
		{
			strcat(prtstr,"0000");
			strcpy(t_iissue_ym,"0000");
		}
		else
		{
		    rfmtlong(atoi(iissue_yy),"&&&&",iissue_yy);
		    strcat(prtstr, iissue_yy);
		    strcpy(t_iissue_ym,iissue_yy);
		}
		
		if (iissue_mm[0]=='\0')
		{
			strcat(prtstr,"00");
			strcat(t_iissue_ym,"00");
		}
		else
		{
		    rfmtlong(atoi(iissue_mm),"&&",iissue_mm);
		    strcat(prtstr, iissue_mm);
		    strcat(t_iissue_ym,iissue_mm);
		}

		/* field 11 84-87 �s�y�~�� */
		strcat(prtstr,(ipro_year[0] == '\0') ? "0000" : ipro_year);
		strcpy(t_ipro_ym,(ipro_year[0] == '\0') ? "0000" : ipro_year);	   
		if (qpro_month <= 0) qpro_month = 1; 
		rfmtlong(qpro_month,"&&",qpro_month_c);
		strcat(prtstr,(qpro_month_c[0] == '\0') ? "00" : qpro_month_c);
		strcat(t_ipro_ym,(qpro_month_c[0] == '\0') ? "01" : qpro_month_c);
	    
		/* 1000530002�t�P�����N���H�ഫ�t�P�����N�����e */
		ibrand_new[0]='\0';
		$OPEN cur_ibrand USING $ibrand;
		$FETCH cur_ibrand INTO $ibrand_new;
		if (ibrand_new[0]!='\0') strcpy(ibrand, ibrand_new);
		$CLOSE cur_ibrand;
		printf("ibrand[%s]ibrand_new[%s]\n", ibrand, ibrand_new);
		
		/* �O�o�������t�P�����e6�X */
		strncpy(ibrand6, ibrand, 6);
		ibrand6[6]='\0';
		$SELECT COUNT(*)
		   INTO $cnt
		   FROM cu_code_data
		  WHERE itype='B9'
		    AND icode=$ibrand6;
		if (cnt>0)
		{
			/* 2010�X�� */
	        sprintf_s(stmp, sizeof stmp,"SELECT count(*) \
	        	            FROM %s:ori_ply_relation \
	        	           WHERE ipolicy = '%s' \
	        	             AND dpolicy>='01/01/2010' ",ply_DB,ipolicy);
        	$PREPARE ply_cnt_brand FROM $stmp;
			$EXECUTE ply_cnt_brand INTO $cnt;
		    if (cnt>0) ibrand[4]=ibrand[5]='0';
		}
		
		/* 107/01/01 ��X�� */
	    sprintf_s(stmp, sizeof stmp,"SELECT count(*) \
        	            FROM %s:ori_ply_relation \
        	           WHERE ipolicy = '%s' \
        	             AND dpolicy>='01/01/2018' ",ply_DB,ipolicy);
    	$PREPARE ply_cnt_brand2 FROM $stmp;
		$EXECUTE ply_cnt_brand2 INTO $cnt2;
		if (cnt2 > 0) f_1070101 = 1;
		else f_1070101 = 0;
		
		/* field 12 88-95 �t�P�����N�� */
		if(ibrand[0] == '\0' || ibrand[0] == ' ')
		    strcat(prtstr, "00000000");
		else
		    strcat(prtstr,ibrand);
		strcpy(t_ibrand,ibrand);
		
	    /* field 13 96-97   ���������N�� */
	    /*201502�s�W�C�Ө��إN���A���إN���^�k*/
	    strcpy(icar_type_ori,trim(icar_type));
		strcpy(icar_type,TRANS_CAR_TYPE(icar_type));
		strcpy(t_icar_type_ori,icar_type_ori);
		strcpy(t_icar_type,icar_type);
		if (strcmp(trim(icar_type),"51") == 0) strcat(prtstr,"34");
		else strcat(prtstr, (*icar_type=='\0') ? "00" : icar_type);
		printf("icar_type_ori[%s] \n",icar_type_ori);
		/*|  �����ۥ�| 01|
		  |  ������~| 02|
		  |�@��p�{��| 03|
		  |�h���p�{��| 04|*/
		 /*�Ȯɩʶǰe-����ݧ���s�W���*/
		printf("--�����������O�N��\n");
		if (f_1090101 > 0)
		{
			if(strcmp(icar_type,"01") == 0 || strcmp(icar_type,"02") == 0 || strcmp(icar_type,"32") == 0 || strcmp(icar_type,"34") == 0 || strcmp(icar_type,"35") == 0)
			{
				if (cnt_L > 0) 
				{
					strcat(prtstr,"02");
					strcpy(t_icar_type_no,"02");
				}
	        	else 
	        	{
	        		strcat(prtstr,"01");
	        		strcpy(t_icar_type_no,"01");
	        	}	
			}
			else if(strcmp(icar_type,"07") == 0 || strcmp(icar_type,"15") == 0)
			{
				if(strcmp(trim(icomp_card),"")==0)
				{
					strcat(prtstr,"03");
					strcpy(t_icar_type_no,"03");
				}
				else
				{
					$SELECT FIRST 1 nvl(fkind,'')
		        	   INTO $fcar_kind
		        	   FROM ca_taxi_type
		        	  WHERE icard = $icomp_card
		        	  ORDER BY dupdate DESC;
		        	if (SQLCODE == SQLNOTFOUND) strcpy(fcar_kind,"N");
		        	
					if(strcmp(fcar_kind,"Y") == 0) 
					{
						strcat(prtstr,"04");
						strcpy(t_icar_type_no,"04");
					}
		        	else 
		        	{
		        		strcat(prtstr,"03");
		        		strcpy(t_icar_type_no,"03");
		        	}
		        }
			}
			else if (strcmp(icar_type,"11") == 0 && equip_cmp(nequipment,"115") == TRUE) /* 1120316006_SC3_�O�o-���N�I���e�{�s�W���@�������������O�N��05�ή��s�X��t�ηs�W���@�����O */
			{
				strcat(prtstr,"05");
				strcpy(t_icar_type_no,"05");
			}
			else 
			{
				strcat(prtstr,"00");
				strcpy(t_icar_type_no,"00");
			}
		}
		else 
		{
			strcat(prtstr,"00");
			strcpy(t_icar_type_no,"00");
		}
	}	
	
	/* 102-106  �Ʈ�q */
	rfmtlong(qcylinder,"&&&&&",qcylinder_c);
	strcat(prtstr,qcylinder_c);
	t_qcylinder = qcylinder;

	/* 107-131 ����/�������X */
	strcat(prtstr,(*iengine=='\0') ? "                         " : iengine);
	strcpy(t_iengine,(*iengine=='\0') ? "                         " : iengine);

    /* 132-143 �P�Ӹ��X */
    strcat(prtstr,(*itag=='\0') ? "            " : itag);
    strcpy(t_itag,(*itag=='\0') ? "            " : itag);

    /* 144-148 �������� */
    if (strncmp(chk_157,"Y",1) == 0)
    {
    	strcat(prtstr,"0000 ");
    	t_qpt = 0;
    	strcpy(t_fpt," ");
    }
    else
    {
	    if(risnull(3,&qpt)==1)
	    {
	        qpt=0;
	    }
	    sprintf_s(qpt_tmp, sizeof qpt_tmp,"%05.1f",qpt); qpt_tmp[5]='\0';
	    strncat(prtstr,&qpt_tmp[0],3);
	    strncat(prtstr,&qpt_tmp[4],1);
	    strcat(prtstr,(fpt[0]=='\0') ? "0" : fpt);
	    strcpy(t_fpt,(fpt[0]=='\0') ? "0" : fpt);
	    t_qpt = qpt *10;
	}

    /* 149-158 �r�p�H��� */
    strcat(prtstr,(*iacc_license=='\0') ? "          " : iacc_license);
    strcpy(t_iacc_license,(*iacc_license=='\0') ? "          " : iacc_license);

    /* 159-162 �r�p�H�X�ͦ~�� */
    if (iacc_birth_yy[0]=='\0') 
    {
    	strcat(prtstr,"0000");
    	strcpy(t_iacc_birth_y,"0000");
    }
    else
    {
        rfmtlong(atoi(iacc_birth_yy),"&&&&",iacc_birth_yy);
        strcat(prtstr, iacc_birth_yy);
        strcpy(t_iacc_birth_y,iacc_birth_yy);
    }

    /* 163 �r�p�H�ʧO */
    strcat(prtstr,(facc_sex[0]== '\0') ? "1" :facc_sex);
    strncpy(t_facc_sex,(facc_sex[0]== '\0') ? "1" :facc_sex, 1);

    /* 164 �r�p�H�B�çO */
    strncat(prtstr,facc_marri[0]== '\0' ? "1" :facc_marri,1);
    strncpy(t_facc_marri,(facc_marri[0]== '\0') ? "1" :facc_marri, 1);
    prtstr[164]='\0';

    /* 165-166 �X�I��]�N�� */
	$SELECT first 1 b.icar_type
       INTO $ioth_cartype
       FROM ca_clm_victim_data a,ca_property b
      WHERE a.iclaim = b.iverify
        AND a.ivictim = b.ivictim
        AND a.fvictim_car IN ('D','E','H')
        AND a.fdrive = '1'
        AND a.iclaim = (SELECT iverify 
                          FROM ca_ver_relation 
                         WHERE iclaim = $iclaim);
                        
    if (SQLCODE==SQLNOTFOUND)
    {
		sprintf_s(stmp, sizeof stmp,"SELECT first 1 ioth_cartype \
        	            FROM %s:stl_oth_dtl \
        	           WHERE iclaim = '%s' \
        	             AND fstl = '1' ORDER BY iclose_type DESC; ",ply_DB,iclaim);
    	$PREPARE stl_oth_dtl_ioth_cartype FROM $stmp;
		$EXECUTE stl_oth_dtl_ioth_cartype INTO $ioth_cartype;
		if (SQLCODE==SQLNOTFOUND)
    		strcpy(ioth_cartype,"");
	}
	strcpy(ioth_cartype,trim(ioth_cartype));
	
	/*
	���郞�I���B�����B����-�r�p�H�L��  01
	���郞�I���B�����B����-�r�p�H�s�r  02
	���磌�I���B�����B����-�r�p�H�L��  03
	���磌�I���B�����B����-�r�p�H�s�r  04
	������訮�N�O���郞�A�_�h�������άO��@�ƬG(98)�]��O���磌
	*/
	printf("--iacc_reason[%s],f_1060101_dacc[%d] \n",iacc_reason,f_1060101_dacc);
	strcpy(iacc_reason,trim(iacc_reason));
	if (f_1060101_dacc > 0)
	{
	    if(strcmp(iacc_reason,"11") == 0)
	    {
	    	if (strcmp(ioth_cartype,"98") != 0 || strcmp(ioth_cartype,"") != 0)
	    		strcpy(iacc_reason,"01");
	    	else 
	    		strcpy(iacc_reason,"03");
	    }
	    else if(strcmp(iacc_reason,"12") == 0 )
	    {
	    	if (strcmp(ioth_cartype,"98") != 0 || strcmp(ioth_cartype,"") != 0)
	    		strcpy(iacc_reason,"02");
	    	else 
	    		strcpy(iacc_reason,"04");	
	    }
	    
	    if( strcmp(sIns_type,"24") == 0 )
	    {
	    	if (strcmp(ioth_cartype,"98") != 0 || strcmp(ioth_cartype,"") != 0)
	    		strcpy(iacc_reason,"02");
	    	else 
	    		strcpy(iacc_reason,"04");	
	    }
	}
	else 
	{
		/*Do nothing*/	
	}
    strncat(prtstr,iacc_reason[0]== '\0' ? "99" :iacc_reason,2);
    strncpy(t_iacc_reason,iacc_reason[0]== '\0' ? "99" :iacc_reason,2);
    prtstr[166]='\0';
    
    /* 167 �F�Ƴd���N�� */
    if(strncmp(fins_grp,"2",1) == 0)  /*���d*/
    {
    	strncat(prtstr,facc_duty[0]== '\0' ? "0" :facc_duty,1);
    	strncpy(t_fduty,facc_duty[0]== '\0' ? "0" :facc_duty,1);
    }
    else if(strncmp(fins_grp,"1",1) == 0)   /*����t��*/
    {
    	strncat(prtstr,fdmg_duty[0]== '\0' ? "0" :fdmg_duty,1);
    	strncpy(t_fduty,fdmg_duty[0]== '\0' ? "0" :fdmg_duty,1);
    }
    else if (strcmp(sIns_type, "99") == 0)
    {
    	strcat(prtstr,"0");
    	strcpy(t_fduty,"0");
    }
    else 
    {
    	strcat(prtstr,"0");
    	strcpy(t_fduty,"0");
	}
    prtstr[167]='\0';

    /* 168-183 �Q�O�I�H��� */
    strcpy(ply_iassured,iassured);
	strcpy(ply_ibirth_yy,dbirth_yy);
	strcpy(ply_fsex,fsex);
	strcpy(ply_fmarriage,fmarriage);
	printf("ply_iassured[%s]\n",ply_iassured);
	printf("ply_ibirth_yy[%s]\n",ply_ibirth_yy);
	printf("ply_fsex[%s]\n",ply_fsex);
	printf("ply_fmarriage[%s]\n",ply_fmarriage);
	
    if (strcmp(trim(ply_iassured),"AAAAAAAAAA")==0)
    {
		strncat(prtstr, ply_iassured, 10);
		strcat(prtstr,"0000");
		strcat(prtstr,"0");
		strcat(prtstr,"0");
		strcpy(t_iassured,ply_iassured);
		strcpy(t_dbirth_y,"0000");
		strcpy(t_fsex,"0");
		strcpy(t_fmarriage,"0");
    }
    else if ((isdigit(ply_iassured[0]) == 0) && (isalpha(ply_iassured[0]) != 0) && (strlen(trim(ply_iassured))== 10))    /*** �Y�����Ҹ��X�Ĥ@�X���^��r�B���׬�10==>�۵M�H ***/
    {
		if (ply_ibirth_yy[0]=='\0')
		{
			sprintf_s(stmp, sizeof stmp,"SELECT YEAR(dbirth),fsex,fmarriage \
			                FROM %s:policy \
			               WHERE ipolicy = '%s'; ",ply_DB,ipolicy);
			$PREPARE ply_birth_sex_marr FROM $stmp;
			$EXECUTE ply_birth_sex_marr INTO $ply_ibirth_yy, $ply_fsex,$ply_fmarriage;
		}
		strncat(prtstr, ply_iassured, 10);
		strcpy(t_iassured,ply_iassured);
		
		if (ply_ibirth_yy[0]=='\0') strcat(prtstr,"0000");
		else
		{
		      rfmtlong(atoi(ply_ibirth_yy),"&&&&",ply_ibirth_yy);
		      strcat(prtstr, ply_ibirth_yy);
		      strcpy(t_dbirth_y,ply_ibirth_yy);
		}
		
		if((ply_fsex[0]=='\0') || (strlen(ply_fsex)<=0))
		{
			strcat(prtstr,"0");
			strcpy(t_fsex,"0");
		}
		else
		{
			strcat(prtstr,ply_fsex);
			strcpy(t_fsex,ply_fsex);
		}
		
		if((ply_fmarriage[0]=='\0') || (strlen(ply_fmarriage)<=0))
		{
			strcat(prtstr,"0");
			strcpy(t_fmarriage,"0");
		}
		else
		{
			strcat(prtstr,ply_fmarriage);
			strcpy(t_fmarriage,ply_fmarriage);
		}
    }
    else if ((isdigit(ply_iassured[0]) != 0) && (isalpha(ply_iassured[0]) == 0) && (strlen(trim(ply_iassured)) == 8))
    {
		strncat(prtstr, ply_iassured, 10);
		strcat(prtstr,"0000");
		strcat(prtstr,"0");
		strcat(prtstr,"0");
		strcpy(t_iassured,ply_iassured);
		strcpy(t_dbirth_y,"0000");
		strcpy(t_fsex,"0");
		strcpy(t_fmarriage,"0");
    }
    else
    {
		strncat(prtstr, "AAAAAAAAAA", 10);
		printf("test3\n");
		strcat(prtstr,"0000");
		strcat(prtstr,"0");
		strcat(prtstr,"0");
		strcpy(t_iassured," ");
		strcpy(t_dbirth_y,"0000");
		strcpy(t_fsex,"0");
		strcpy(t_fmarriage,"0");
    }

    /* field 21.1 179-181 �ĤT�H�d���I�ˤ`�H�� */
	if(strcmp(sIns_type, "99") != 0 && strcmp(sIns_type, "31") != 0  && strcmp(sIns_type, "131") != 0 &&
	                                   strcmp(sIns_type, "231") != 0 && strcmp(sIns_type, "331") != 0)
	{
		/*�O�B���HIST���U���O�B  getPlyInsHistData*/
		/*$SELECT (mins_app+mproc_app)
	       INTO $mins_app
	       FROM app_ins_type
	      WHERE iclaim = $iclaim AND iins_type = $sIns_type;*/
	}
	
	if (strcmp(trim(sIns_type),"29") == 0)
	{
		qlia2 = 0;
	}
	if (strcmp(trim(sIns_type),"24") == 0)
	{
		qlia2 = 0;
	}
	
	if(strcmp(trim(sIns_type),"93") == 0  || strcmp(trim(sIns_type),"131A") == 0 || 
	   strcmp(trim(sIns_type),"193") == 0 || strcmp(trim(sIns_type),"331A") == 0)
	{
		if(qlia2 > 0)
		{
			rfmtlong(qlia2,"&&&",buf);
			strcat(prtstr, buf);
			qinjure31 += qlia2;
			t_qlia1 = qlia2;
		}
		else if(mins_stl <= minjure_cover)
		{
			strcat(prtstr, "001"); qinjure31++;
			t_qlia1 = 1;
		}
		else
		{
			strcat(prtstr, "002"); qinjure31 += 2;
			t_qlia1 = 2;
		}
	}
	else if(strcmp(sIns_type, "31")==0  || strcmp(sIns_type, "131")==0 ||
	        strcmp(sIns_type, "231")==0 || strcmp(sIns_type, "331")==0 || strcmp(sIns_type, "99")==0)
	{
		rfmtlong(qinjure31,"&&&",buf);
		strcat(prtstr, buf);
		t_qlia1 = qinjure31;
	}
	else
	{
		if(strncmp(fins_grp,"2",1) == 0)
		{
			strcat(prtstr, "000");
			t_qlia1 = 0;
		}
		else
		{
			if(strcmp(fkind,"A") ==0 || strcmp(fkind,"B") ==0 || strcmp(fkind,"C") ==0 ||
			   strcmp(fkind,"E") ==0 || strcmp(fkind,"F") ==0 || strcmp(fkind,"5") ==0)
			{
				rfmtlong(qlia2,"&&&",buf);
		    	strcat(prtstr, buf);
		    	t_qlia1 = qlia2;
		    }
		    else 
		    {
		    	strcat(prtstr, "000");
		    	t_qlia1 = 0;
		    }
		}
	}
	
	/* field 21.2 182-184 */
	if(strcmp(sIns_type, "94") == 0  || strcmp(trim(sIns_type),"131B") == 0 || 
	   strcmp(sIns_type, "194") == 0 || strcmp(trim(sIns_type),"331B") == 0)
	{
		if(qlia2 > 0)
		{
			rfmtlong(qlia2,"&&&",buf);
			strcat(prtstr, buf);
			qdeath31 += qlia2;
			t_qlia2 = qlia2;
		}
		else if(mins_stl <= mdeath_cover)
		{
			strcat(prtstr, "001"); qdeath31++;
			t_qlia2 = 1;
		}
		else
		{
			strcat(prtstr, "002"); qdeath31 += 2;
			t_qlia2 = 2;
		}
	}
	else if(strcmp(sIns_type, "31")==0  || strcmp(sIns_type, "131")==0 ||
	        strcmp(sIns_type, "231")==0 || strcmp(sIns_type, "331")==0 || strcmp(sIns_type, "99")==0)
	{
		rfmtlong(qdeath31,"&&&",buf);
		strcat(prtstr, buf);
		t_qlia2 = qdeath31;
	}
	else
	{
		if(strncmp(fins_grp,"2",1) == 0)
		{
			strcat(prtstr, "000");
			t_qlia2 = 0;
		}
		else
		{
			if(strcmp(fkind,"A") ==0 || strcmp(fkind,"B") ==0 || strcmp(fkind,"C") ==0 ||
			   strcmp(fkind,"E") ==0 || strcmp(fkind,"F") ==0 || strcmp(fkind,"5") ==0)
			{
				rfmtlong(qlia2,"&&&",buf);
		    	strcat(prtstr, buf);
		    	t_qlia2 = qlia2;
		    }
		    else 
		    {
		    	strcat(prtstr, "000");
		    	t_qlia2 = 0;
		    }
		}
	}
	
	 /* field 21.3 185-187 */
	if(strcmp(sIns_type, "95") == 0  || strcmp(trim(sIns_type),"131C") == 0 || 
	   strcmp(sIns_type, "195") == 0 || strcmp(trim(sIns_type),"331C") == 0)
	{
		if(qlia2 > 0)
		{
			rfmtlong(qlia2,"&&&",buf);
			strcat(prtstr, buf);
			qbreak31 += qlia2;
			t_qlia3 = qlia2;
		}
		else if(mins_stl <= mdeath_cover)
		{
			strcat(prtstr, "001"); qbreak31++;
			t_qlia3 = 1;
		}
		else
		{
			strcat(prtstr, "002"); qbreak31 += 2;
			t_qlia3 = 2;
		}
	}
	else if(strcmp(sIns_type, "31")==0  || strcmp(sIns_type, "131")==0 ||
	        strcmp(sIns_type, "231")==0 || strcmp(sIns_type, "331")==0 || strcmp(sIns_type, "99")==0)
	{
		rfmtlong(qbreak31,"&&&",buf);
		strcat(prtstr, buf);
		t_qlia3 = qlia2;
	}
	else
	{
		if(strncmp(fins_grp,"2",1) == 0)
		{
			strcat(prtstr, "000");
			t_qlia3 = 0;
		}
		else
		{
			if(strcmp(fkind,"A") ==0 || strcmp(fkind,"B") ==0 || strcmp(fkind,"C") ==0 ||
			   strcmp(fkind,"E") ==0 || strcmp(fkind,"F") ==0 || strcmp(fkind,"5") ==0)
			{
				rfmtlong(qlia2,"&&&",buf);
		    	strcat(prtstr, buf);
		    	t_qlia3 = qlia2;
		    }
		    else 
		    {
		    	strcat(prtstr, "000");
		    	t_qlia3 = 0;
		    }
		}
	}

	/* 193-200 �X�I��� */
	strcat(prtstr,(*daccident_yyyy=='\0') ? "0000" : daccident_yyyy);
	strcat(prtstr,(*daccident_mm=='\0') ? "00" : daccident_mm);
	strcat(prtstr,(*daccident_dd=='\0') ? "00" : daccident_dd);
	strcpy(t_daccident,(*daccident_yyyy=='\0') ? "0000" : daccident_yyyy);
	strcat(t_daccident,(*daccident_mm=='\0') ? "00" : daccident_mm);
	strcat(t_daccident,(*daccident_dd=='\0') ? "00" : daccident_dd);

	if( strlen(trim(dvp_code1)) == 0 )
		strcpy( dvp_code1, dvp_code2 );

	/* 201-202 �X�I�a�ϥN�� */
	strcat(prtstr,(*dvp_code1=='\0') ? "01" : dvp_code1);
	strcpy(t_dvp_code1,(*dvp_code1=='\0') ? "01" : dvp_code1);
	
	/* 203-204 �ӫO�a�ϥN�� */
	strcat(prtstr,(*dvp_code2=='\0') ? "01" : dvp_code2);
	strcpy(t_dvp_code2,(*dvp_code2=='\0') ? "01" : dvp_code2);
	
	/* 205 �����l�N�� */
	flag_err = FALSE;
	if (fpart[0]=='2')
		strcpy (fpart, "1");
	if (fpart[0]== '3')
		strcpy (fpart, "1");
	else
		strcpy (fpart, "2");
	
	flag_err = (*fpart=='1' || *fpart=='2') ? FALSE : TRUE;
	if(flag_err)
	{
		fRowError=TRUE;
		sprintf_s(buf, sizeof buf, "(fpart:[%s])", fpart);
		strcat(prtstr, buf);        /** ??? **/
		strcpy(t_fpart,buf);
	}
	else
	{
		strcat(prtstr,fpart);
		strcpy(t_fpart,fpart);
	}

	/* 206-208 �h�����u�ݥN�� */
	if(strncmp(fins_grp,"1",1) == 0 && strcmp(iri_ins,"11") != 0)
	{
		if(ipdmg_align == 10)
		{
			strcat(prtstr, "2");
			strcpy(t_ipdmg_align,"2");
		}
		else if(ipdmg_align == 5)
		{
			strcat(prtstr, "1");
			strcpy(t_ipdmg_align,"1");
		}
		else
		{
			ipdmg_align = 0;
			strcat(prtstr, "0");
			strcpy(t_ipdmg_align,"0");
		}
	}
	else
	{
		strcat(prtstr, "0");
		strcpy(t_ipdmg_align,"0");
	}
	
	if(strcmp(iri_ins, "11") == 0)
	{
	 	if(ipbrg_align == 10) 
	 	{
	 		strcat(prtstr, "2");
	 		strcpy(t_ipbrg_align,"2");
	 	}
		else if(ipbrg_align == 5) 
		{
			strcat(prtstr, "1");
			strcpy(t_ipbrg_align,"1");
		}
		else 
		{  
			ipbrg_align = 0;  
			strcat(prtstr, "0"); 
			strcpy(t_ipbrg_align,"0");
		}
	}
	else
	{
		strcat(prtstr, "0");
		strcpy(t_ipbrg_align,"0");
	}
	
	if(strncmp(fins_grp,"2",1) == 0)
	{
		if(iplia_align == 10) 
		{
			strcat(prtstr, "2");
			strcpy(t_iplia_align,"2");
		}
		else if(iplia_align == 5 ) 
		{
			strcat(prtstr, "1");
			strcpy(t_iplia_align,"1");
		}
		else
		{
			iplia_align = 0; 
			strcat(prtstr, "0");
			strcpy(t_iplia_align,"0");
		}
	}
	else
	{
		strcat(prtstr, "0");
		strcpy(t_iplia_align,"0");
	}
	
	/** �ۭt�B���e���A�]�ݧP�_�ѵs�I **/
	/*���ݧ��¡A�᭱�Ϊ��� ñ��~�׬�2016�~(�t)�H�e�G�ж�"000" */
    fcontract_err = 0;
    if (f_1060101 > 0)
	{
	    if (strncmp(fins_grp,"1",1) == 0)
		{
			$SELECT pdepreciate::int
			   INTO $pdepreciate_year
			   FROM depreciation_rate a
	          WHERE drate = (SELECT drate 
	                           FROM ca_rate_date 
	                          WHERE icode = $drate_ym
	                            AND itable = 'depreciation_rate')
	            AND fcar_class = (SELECT CASE WHEN icar_grp = '1' THEN '3' ELSE fcar_class END
	                                FROM car_type
	                               WHERE fclass = '1' 
	                                 AND icode = $icar_type_ori)
	            AND qperiod_end  = '12';
	         
	         pdepreciate_year_tot = pdepreciate_year;
	         t_pdepreciate_year = pdepreciate_year_tot;
	         printf("pdepreciate_year[%d] pdepreciate_year_tot[%d]\n",pdepreciate_year,pdepreciate_year_tot);
			 rfmtlong(pdepreciate_year,"&&&", pdepreciate_year_tmp);
			 strcpy(pdepreciate_year_tmp2,"+");
			 strcat(pdepreciate_year_tmp2,pdepreciate_year_tmp);
			 $EXECUTE CUR_CARCLASS INTO $fcar_class_pd USING $icar_type_ori;
			 strcpy(fcar_class_pd,trim(fcar_class_pd));
			 if ((pdepreciate_year != 25) && fcar_class_pd[0] == '1') fcontract_err = 1;
			 else if ((pdepreciate_year != 30) && fcar_class_pd[0] == '2') fcontract_err = 1; 
		}
		else if ((strcmp(trim(iins_main), "01")==0  || strcmp(trim(iins_main), "05")==0  ||
			      strcmp(trim(iins_main), "09")==0  || strcmp(trim(iins_main), "08")==0  ||
			      strcmp(trim(iins_main), "11")==0  ||
			      strcmp(trim(iins_main), "201")==0 || strcmp(trim(iins_main), "205")==0 ||
			      strcmp(trim(iins_main), "209")==0 || strcmp(trim(iins_main), "211")==0) && 
			     (strcmp(trim(sIns_type), "P")==0))
		{
			$SELECT pdepreciate::int
			   INTO $pdepreciate_year
			   FROM depreciation_rate a
			  WHERE drate = (SELECT drate 
			                   FROM ca_rate_date 
			                  WHERE icode = $drate_ym
	                            AND itable = 'depreciation_rate')
	            AND fcar_class   = '6'
	            AND qperiod_end  = '12';
	        printf("pdepreciate_year[%d] pdepreciate_year_tot[%d]\n",pdepreciate_year,pdepreciate_year_tot);
	    	/*pdepreciate_year_tot -= pdepreciate_year;*/
	    	t_pdepreciate_year = 0 - (pdepreciate_year_tot - pdepreciate_year);
			rfmtlong((pdepreciate_year_tot - pdepreciate_year),"&&&", pdepreciate_year_tmp);
			strcpy(pdepreciate_year_tmp2,"-");
			strcat(pdepreciate_year_tmp2,pdepreciate_year_tmp);
		}
		else if ((strcmp(trim(iins_main), "01")==0  || strcmp(trim(iins_main), "05")==0  ||
			      strcmp(trim(iins_main), "09")==0  || strcmp(trim(iins_main), "08")==0  ||
			      strcmp(trim(iins_main), "11")==0  ||
			      strcmp(trim(iins_main), "201")==0 || strcmp(trim(iins_main), "205")==0 ||
			      strcmp(trim(iins_main), "209")==0 || strcmp(trim(iins_main), "211")==0) &&
			     (strcmp(trim(sIns_type), "Q")==0))
		{
			$SELECT pdepreciate::int
			   INTO $pdepreciate_year
			   FROM depreciation_rate a
			  WHERE drate = (SELECT drate 
			                   FROM ca_rate_date 
			                  WHERE icode = $drate_ym
	                            AND itable = 'depreciation_rate')
	            AND fcar_class   = '7'
	            AND qperiod_end  = '12';
			/*pdepreciate_year_tot -= pdepreciate_year;*/
			t_pdepreciate_year = 0 - (pdepreciate_year_tot - pdepreciate_year);
			rfmtlong((pdepreciate_year_tot - pdepreciate_year),"&&&", pdepreciate_year_tmp);
			strcpy(pdepreciate_year_tmp2,"-");
			strcat(pdepreciate_year_tmp2,pdepreciate_year_tmp);
		}
		else if ((strcmp(trim(iins_main), "01")==0  || strcmp(trim(iins_main), "05")==0  ||
			      strcmp(trim(iins_main), "09")==0  || strcmp(trim(iins_main), "08")==0  ||
			      strcmp(trim(iins_main), "11")==0  || strcmp(trim(iins_main), "181")==0 ||
			      strcmp(trim(iins_main), "201")==0 || strcmp(trim(iins_main), "205")==0 ||
			      strcmp(trim(iins_main), "209")==0 || strcmp(trim(iins_main), "211")==0) &&
			     (strcmp(trim(sIns_type), "M")==0))
		{
			$SELECT pdepreciate::int
			   INTO $pdepreciate_year
			   FROM depreciation_rate a
			  WHERE drate = (SELECT drate 
			                   FROM ca_rate_date 
			                  WHERE icode = $drate_ym
	                            AND itable = 'depreciation_rate')
	            AND fcar_class   = '8'
	            AND qperiod_end  = '12';
			/*pdepreciate_year_tot -= pdepreciate_year;*/
			t_pdepreciate_year = 0 - (pdepreciate_year_tot - pdepreciate_year);
			rfmtlong((pdepreciate_year_tot - pdepreciate_year),"&&&", pdepreciate_year_tmp);
			strcpy(pdepreciate_year_tmp2,"-");
			strcat(pdepreciate_year_tmp2,pdepreciate_year_tmp);
		}
		else if ((strcmp(trim(iins_main), "01")==0  || strcmp(trim(iins_main), "05")==0  ||
			      strcmp(trim(iins_main), "09")==0  || strcmp(trim(iins_main), "08")==0  ||
			      strcmp(trim(iins_main), "11")==0  ||
			      strcmp(trim(iins_main), "201")==0 || strcmp(trim(iins_main), "205")==0 ||
			      strcmp(trim(iins_main), "209")==0 || strcmp(trim(iins_main), "211")==0) &&
			     (strcmp(trim(sIns_type), "Z")==0))
		{
			$SELECT pdepreciate::int
			   INTO $pdepreciate_year
			   FROM depreciation_rate a
			  WHERE drate = (SELECT drate 
			                   FROM ca_rate_date 
			                  WHERE icode = $drate_ym
	                            AND itable = 'depreciation_rate')
	            AND fcar_class   = '4'
	            AND qperiod_end  = '12';
			/*pdepreciate_year_tot -= pdepreciate_year;*/
			t_pdepreciate_year = 0 - (pdepreciate_year_tot - pdepreciate_year);
	        rfmtlong((pdepreciate_year_tot - pdepreciate_year),"&&&", pdepreciate_year_tmp);
			strcpy(pdepreciate_year_tmp2,"-");
			strcat(pdepreciate_year_tmp2,pdepreciate_year_tmp);
		}
		else 
		{
			strcpy(pdepreciate_year_tmp2,"+000");
			t_pdepreciate_year = 0;
		}
	}
	else 
	{
		strcpy(pdepreciate_year_tmp2,"+000");
		t_pdepreciate_year = 0;
	}
		
     /* 209-217 �O�I���������B�N�� */
	/*���郞�I�����q�P�o�i���ߥN�����P*/
	printf("sIns_type[%s] \n",sIns_type);
	iins_type_main[0] = '\0';
	iins_type_dtl[0] = '\0';
	iins_type_develop[0] = '\0';
	iins_type_rule[0] = '\0';
	strcpy(t_iins_type,sIns_type);
	if (strcmp(sIns_type, "P") != 0 && strcmp(sIns_type, "Q") != 0 && 
	    strcmp(sIns_type, "M") != 0 && strcmp(sIns_type, "Z") != 0)
	{
		strcpy(t_iins_main,iins_ply);
	}
	else 
	{
		strcpy(t_iins_main,iins_main);
	}
	
	if (strcmp(sIns_type,"99") == 0)
	{
		strcpy(iins_type_main,"0");
		strcpy(iins_type_dtl,"00");
		strcpy(iins_type_develop,"99");
		strcpy(iins_type_rule,"00");
	}
	else if ((strcmp(sIns_type,"P") == 0) || (strcmp(sIns_type,"Q") == 0) || (strcmp(sIns_type,"M") == 0) || (strcmp(sIns_type,"Z") == 0) )
	{
		$SELECT a.iins_type_main,a.iins_type_dtl,a.iins_type_develop,a.iins_type_rule,
		        nvl((SELECT fcal_way FROM insurance_type WHERE iins_type = a.iins_type),'')
		   INTO $iins_type_main,$iins_type_dtl,$iins_type_develop,$iins_type_rule,$fcal_way
		   FROM insurance_type_develop a
		  WHERE iins_type = $sIns_type;
		    
		if (SQLCODE == SQLNOTFOUND) 
		{
			strcpy(iins_type_main,"0");
			strcpy(iins_type_dtl,"00");
			strcpy(iins_type_develop,iins_ply);
			strcpy(iins_type_rule,"00");
		}	
	}
	else 
	{
		$SELECT a.iins_type_main,a.iins_type_dtl,a.iins_type_develop,a.iins_type_rule,
		        nvl((SELECT fcal_way FROM insurance_type WHERE iins_type = a.iins_type),'')
		   INTO $iins_type_main,$iins_type_dtl,$iins_type_develop,$iins_type_rule,$fcal_way
		   FROM insurance_type_develop a
		  WHERE iins_type = (SELECT iins_ply FROM insurance_type WHERE iins_type = $sIns_type);
		    
		if (SQLCODE == SQLNOTFOUND) 
		{
			strcpy(iins_type_main,"0");
			strcpy(iins_type_dtl,"00");
			strcpy(iins_type_develop,iins_ply);
			strcpy(iins_type_rule,"00");
		}
	}

	strcpy(iins_type_main,trim(iins_type_main));
	strcpy(iins_type_dtl,trim(iins_type_dtl));
	strcpy(iins_type_develop,trim(iins_type_develop));
	strcpy(iins_type_rule,trim(iins_type_rule));
	
	if (iins_type_rule[0] == '1') strcpy(frule,"Y");
	else if (iins_type_rule[0] == '2') strcpy(frule,"N");
	
	/*�O�v��I�~����ɳW�h*/
	if (fcal_way[0] == '1')
	{
		sprintf_s(stmt, sizeof stmt,"SELECT to_char(drate, '%%Y%%m') drate_code FROM ca_rate_date \
						WHERE itable = 'ca_rate' AND icode = ? ");
	}
	else
	{
		sprintf_s(stmt, sizeof stmt,"SELECT to_char(drate, '%%Y%%m') drate_code FROM ca_rate_date \
						WHERE itable = 'cover_vs_premium' AND icode = ? ");
	}
	$PREPARE CUR_DRATE FROM $stmt;

	if (f_1060101 > 0)
	{
		if(strcmp(sIns_type,"11")==0)
		{
			if( mdeduct == 0 && f_1090101 == 0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"98");
				strcpy(iins_type_develop , "14");
				strcpy(iins_type_rule , "20");
				strcpy(frule,"N");
			}
			else if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
			{
				if (f_1120501 > 0) {}
				else  strcpy(iins_type_develop , "14");
				
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"98");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			else if(fcontract_err == 1)
			{
				if (f_1120501 > 0) {}
				else  strcpy(iins_type_develop , "14");
				
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"98");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			
			if( fcar_class[0] == '1' )
				strcpy(iproduct,"112100201011");
			else
				strcpy(iproduct,"122110201011");
		}
		
		if(strcmp(sIns_type,"211")==0)
		{
			if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"98");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			else if(fcontract_err == 1)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"98");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
		}
		
		if (strcmp(sIns_type, "01") == 0)
		{
			if ((mdeduct == 0 || mdeduct > 20000) && f_1090101 == 0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_develop,"08");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			/*else if (mdeduct > 30000 && f_1090101 > 0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_develop,"08");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}*/
			else if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
			{
				if (f_1120501 > 0) {}
				else  strcpy(iins_type_develop , "08");
				
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			else if(fcontract_err == 1)
			{
				if (f_1120501 > 0) {}
				else  strcpy(iins_type_develop , "08");
				
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
		}
		
		if (strcmp(sIns_type, "201") == 0)
		{
			if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			else if(fcontract_err == 1)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
		}
		
		if (strcmp(sIns_type, "05") == 0)
		{
			if ((mdeduct == 0 || mdeduct > 20000) && f_1090101 == 0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_develop,"08");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			else if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
			{
				if (f_1120501 > 0) {}
				else  strcpy(iins_type_develop , "08");
				
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			else if(fcontract_err == 1)
			{
				if (f_1120501 > 0) {}
				else  strcpy(iins_type_develop , "08");
				
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
		}
		
		if (strcmp(sIns_type, "205") == 0)
		{
			if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			else if(fcontract_err == 1)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
		}
		
		if (strcmp(sIns_type,"09")==0)
		{
			if (mdeduct != 0 && f_1090101 == 0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_develop,"08");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			if ((strcmp(icar_type,"03") != 0) && (strcmp(icar_type,"21") != 0) &&
			    (strcmp(icar_type,"22") != 0) && (strcmp(icar_type,"04") != 0) &&
			    (strcmp(icar_type,"19") != 0))
			{
				if (f_1120501 > 0) {}
				else  strcpy(iins_type_develop , "08");
				
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			/*if (strstr(trim(provision),"K") != NULL)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_develop , "08");
				strcpy(iins_type_rule , "20");
				strcpy(frule,"N");
			}*/
			
			if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
			{
				if (f_1120501 > 0) {}
				else  strcpy(iins_type_develop , "08");
				
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			
			if(fcontract_err == 1)
			{
				if (f_1120501 > 0) {}
				else  strcpy(iins_type_develop , "08");
				
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
		}
		
		if (strcmp(sIns_type,"209")==0)
		{
			if ((strcmp(icar_type,"03") != 0) && (strcmp(icar_type,"21") != 0) &&
			    (strcmp(icar_type,"22") != 0) && (strcmp(icar_type,"04") != 0) &&
			    (strcmp(icar_type,"19") != 0))
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}

			if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			
			if(fcontract_err == 1)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
		}
		
		if (strcmp(sIns_type,"31") == 0 || strcmp(sIns_type,"93") == 0 || strcmp(sIns_type,"94") == 0 || strcmp(sIns_type,"95") == 0)
		{
			if ((strstr(trim(provision),"T") != NULL) && fcar_class[0] == '2')
			{
				if(mdamage_cover == 2 * minjure_cover)
					strcpy(iproduct,"121130351211");
				else 
					strcpy(iproduct,"121130461211");
			}
			if (f_1090101 == 0)
			{
				if(mdeduct > 0)
				{
					strcpy(iins_type_main,"Z");
					strcpy(iins_type_dtl,"99");
					strcpy(iins_type_rule , "20");
					strcpy(frule, "N");
				}
				
				if (minjure_cover > 10000000)
				{
					strcpy(iins_type_main,"Z");
					strcpy(iins_type_dtl,"99");
					strcpy(iins_type_develop , "31");
					strcpy(iins_type_rule , "20");
					strcpy(frule, "N");
				}
				
				if (mdamage_cover == 2 * minjure_cover)
				{


				}
				else 
				{
					strcpy(iins_type_main,"Z");
					strcpy(iins_type_dtl,"99");
					strcpy(iins_type_develop , "31");
					strcpy(iins_type_rule , "20");
					strcpy(frule, "N");	
				}
			}
		}
		
		printf("--3016 mdeduct[%d],f_1090101[%d]",mdeduct,f_1090101);
		if (strcmp(sIns_type,"32") == 0)
		{
			if(mdeduct > 0 && f_1090101 == 0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"99");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			if ((strstr(trim(provision),"T") != NULL) && fcar_class[0] == '2')
			{
				strcpy(iproduct,"121130361211");
			}
		}
		 /*** 55���O�B�������D���ӫ~ ***/
		if (strncmp(sIns_type,"55",2)==0)
		{
			if ((strcmp(icar_type,"03") != 0 && strcmp(icar_type,"04") != 0 &&
			     strcmp(icar_type,"05") != 0 && strcmp(icar_type,"06") != 0 &&
			     strcmp(icar_type,"11") != 0 && strcmp(icar_type,"12") != 0 &&
			     strcmp(icar_type,"18") != 0 && strcmp(icar_type,"19") != 0 &&
			     strcmp(icar_type,"20") != 0 && strcmp(icar_type,"21") != 0 &&
			     strcmp(icar_type,"22") != 0 && strcmp(icar_type,"31") != 0 ))
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"91");
				strcpy(iins_type_develop, "51");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
		}
		if (strcmp(iins_ply,"131") == 0 || strcmp(iins_ply,"132") == 0 || strcmp(iins_ply,"24") == 0 ||
			strcmp(iins_ply,"26") == 0  || strcmp(iins_ply,"31") == 0  || strcmp(iins_ply,"32") == 0 ||
			strcmp(iins_ply,"41") == 0  || strcmp(iins_ply,"42") == 0 )
		{
			chk_plia = 0;
			if ((fassured[0]=='1' || fassured[0]=='3' || fassured[0]=='5') && atoi(drate_ym) < 99)
			{
				/* 231�B232�B331�B332 132�O�v��~���A���C�J */
				/* ���d */
				strcpy( sDbirth,     cm_cdate_str_100(dbirth));
				strcpy( sDply_begin, cm_cdate_str_100(dply_begin));
				rc = get_age( sDbirth, sDply_begin, &age, v_sMsg);
				
				/* 99�O�v��]�w���ʧO�~�֫Y�Ƥ~�P���|���ۦP�A�Y���e�X���涷�Φ��@�����
				if (atoi(drate_ym) < 99) 
					rc = get_sex_age_factor( "2", &age, fsex, "99", &psex_age_chk, v_sMsg);
				else 
					rc = get_sex_age_factor( "2", &age, fsex, drate_ym, &psex_age_chk, v_sMsg);
				if (psex_age_lia != psex_age_chk) chk_plia = 1;
				*/
				
				rc = get_sex_age_factor( "2", &age, fsex, "99", &psex_age_chk, v_sMsg);
				if (psex_age_lia != psex_age_chk) chk_plia = 1;
			}
			else chk_plia = 0;
			printf("--3066 age[%f],fsex[%s],chk_plia[%d],drate_ym[%s],psex_age_lia[%f],psex_age_chk[%f] \n",age,fsex,chk_plia,drate_ym,psex_age_lia,psex_age_chk);
			
			if (chk_plia > 0)
			{
				/*���w��31/32 131/132���ݦ~�֫Y��*/
				if (strcmp(iins_ply,"31") == 0  || strcmp(iins_ply,"32") == 0)
				{
					strcpy(iins_type_main,"Z");
					strcpy(iins_type_dtl,"99");
					strcpy(iins_type_rule , "20"); 
					strcpy(frule, "N");
				}
				/*else 
				{
					strcpy(iins_type_main,"E");
					strcpy(iins_type_dtl,"44");
					strcpy(iins_type_rule , "20");
					strcpy(frule, "N");
				}*/
			}
		}
	}
	else 
	{
		$SELECT iins_type_rule,frule
		   INTO $iins_type_develop,$frule
		   FROM insurance_type
		  WHERE iins_type = (SELECT iins_ply FROM insurance_type WHERE iins_type = $sIns_type);
		  
		if(strcmp(sIns_type,"11")==0)
		{
			if ( mdeduct==0 && f_1090101 == 0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"98");
				strcpy(iins_type_develop , "21");
				strcpy(iins_type_rule , "20");
				strcpy(frule,"N");
			}
			else if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"98");
				strcpy(iins_type_develop , "21");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			else if(fcontract_err == 1)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"98");
				strcpy(iins_type_develop , "21");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			
			if( fcar_class[0] == '1' )
				strcpy(iproduct,"112100201011");
			else
				strcpy(iproduct,"122110201011");
		}
		
		if (strcmp(sIns_type, "01") == 0)
		{
			if ((mdeduct == 0 || mdeduct > 20000) && f_1090101 == 0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_develop,"15");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			else if (mdeduct > 30000 && f_1090101 > 0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_develop,"15");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			else if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_develop,"15");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			else if(fcontract_err == 1)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_develop,"15");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
		}
		
		if (strcmp(sIns_type,"05") == 0)
		{
			if (mdeduct == 0 || mdeduct > 20000)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_develop,"15");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			else if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_develop,"15");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			else if(fcontract_err == 1)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_develop,"15");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
		}
		
		if (strcmp(sIns_type,"09")==0)
		{
			if (mdeduct != 0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_develop,"15");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
				/* �ӫ~�N�X�P09�ۦP */
			}
			if ((strcmp(icar_type,"03") != 0) && (strcmp(icar_type,"21") != 0) &&
			    (strcmp(icar_type,"22") != 0) && (strcmp(icar_type,"04") != 0) &&
			    (strcmp(icar_type,"19") != 0))
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_develop,"15");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			if (strstr(trim(provision),"K") != NULL)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_develop , "15");
				strcpy(iins_type_rule , "20");
				strcpy(frule,"N");
			}
			
			if(strcmp(icar_type_ori,"2A")==0 || strcmp(icar_type_ori,"2B")==0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_develop,"15");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			
			if(fcontract_err == 1)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"97");
				strcpy(iins_type_develop,"15");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
		}
		
		if (strcmp(sIns_type,"31") == 0 || strcmp(sIns_type,"93") == 0 || strcmp(sIns_type,"94") == 0 || strcmp(sIns_type,"95") == 0)
		{
			if(mdeduct > 0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"99");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			else if (mdamage_cover == 2 * minjure_cover)
			{
				if ((strstr(trim(provision),"T") != NULL) && fcar_class[0] == '2')
				{
					strcpy(iins_type_main,"Z");
					strcpy(iins_type_dtl,"99");
					strcpy(iins_type_develop , "31");
					strcpy(iins_type_rule , "20");
					strcpy(frule, "N");
				}
			}
			else
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"99");
				strcpy(iins_type_develop , "31");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");	
			}
		}
		
		if (strcmp(sIns_type,"32") == 0)
		{
			if(mdeduct > 0)
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"99");
				strcpy(iins_type_rule , "32");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			else if ((strstr(trim(provision),"T") != NULL) && fcar_class[0] == '2')
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"99");
				strcpy(iins_type_develop , "32");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
		}
		 /*** 55���O�B�������D���ӫ~ ***/
		if (strncmp(sIns_type,"55",2)==0)
		{
			if ((mdamage_cover > 6000000) || (mdeath_cover == minjure_cover))
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"91");
				strcpy(iins_type_develop, "62");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
			else if ((strcmp(icar_type,"03") != 0 && strcmp(icar_type,"04") != 0 &&
			          strcmp(icar_type,"05") != 0 && strcmp(icar_type,"06") != 0 &&
			          strcmp(icar_type,"11") != 0 && strcmp(icar_type,"12") != 0 &&
			          strcmp(icar_type,"18") != 0 && strcmp(icar_type,"19") != 0 &&
			          strcmp(icar_type,"20") != 0 && strcmp(icar_type,"21") != 0 &&
			          strcmp(icar_type,"22") != 0 && strcmp(icar_type,"31") != 0 ))
			{
				strcpy(iins_type_main,"Z");
				strcpy(iins_type_dtl,"91");
				strcpy(iins_type_develop, "62");
				strcpy(iins_type_rule , "20");
				strcpy(frule, "N");
			}
		}
		
		if (strcmp(iins_ply,"131") == 0 || strcmp(iins_ply,"132") == 0 || strcmp(iins_ply,"24") == 0 ||
			strcmp(iins_ply,"26") == 0  || strcmp(iins_ply,"31") == 0  || strcmp(iins_ply,"32") == 0 ||
			strcmp(iins_ply,"41") == 0  || strcmp(iins_ply,"42") == 0 )
		{
			chk_plia = 0;
			if ((fassured[0]=='1' || fassured[0]=='3' || fassured[0]=='5') && atoi(drate_ym) < 99)  /*** �۵M�H ***/
			{
				/* ���d */
				strcpy( sDbirth,     cm_cdate_str_100(dbirth));
				strcpy( sDply_begin, cm_cdate_str_100(dply_begin));
				rc = get_age( sDbirth, sDply_begin, &age, v_sMsg);
				/*99�O�v��]�w���ʧO�~�֫Y�Ƥ~�P���|���ۦP�A�Y���e�X���涷�Φ��@�����
				if (atoi(drate_ym) < 99) 
					rc = get_sex_age_factor( "2", &age, fsex, "99", &psex_age_chk, v_sMsg);
				else 
					rc = get_sex_age_factor( "2", &age, fsex, drate_ym, &psex_age_chk, v_sMsg);
				
				if (psex_age_lia != psex_age_chk) chk_plia = 1;*/
				rc = get_sex_age_factor( "2", &age, fsex, "99", &psex_age_chk, v_sMsg);
				if (psex_age_lia != psex_age_chk) chk_plia = 1;
			}
			else chk_plia = 0;
			
			if (chk_plia > 0)
			{
				/*���w��31/32*/
				if (strcmp(iins_ply,"31") == 0  || strcmp(iins_ply,"32") == 0)
				{
					strcpy(iins_type_main,"Z");
					strcpy(iins_type_dtl,"99");
					strcpy(iins_type_rule , "20"); 
					strcpy(frule, "N");
				}
				/*else 
				{
					strcpy(iins_type_main,"E");
					strcpy(iins_type_dtl,"44");
					strcpy(iins_type_rule , "20");
					strcpy(frule, "N");
				}*/
			}
		}
		
		if ((strcmp(sIns_type,"P") == 0) || (strcmp(sIns_type,"Q") == 0) || (strcmp(sIns_type,"M") == 0) || (strcmp(sIns_type,"Z") == 0))
		{
			strcpy(iins_type_main,"Z");
			strcpy(iins_type_dtl,"91");
			if (strncmp(fins_grp,"1",1) == 0 && strcmp(trim(iri_ins),"11") != 0)
			{
				strcpy(iins_type_develop, "16");
			}
			else if (strcmp(trim(iri_ins),"11") == 0)
			{
				strcpy(iins_type_develop, "22");
			}
			strcpy(iins_type_rule , "20");
			strcpy(frule, "N");
		}
	}
		/*** 55���O�B�������D���ӫ~ end ***/
	/* 209-217 �O�I�����N�� */
	printf("iins_type_develop[%s] sIns_type[%s] provision[%s] drate_ym[%s] fcal_way[%s] fcar_class[%s]\n",
	        iins_type_develop,    sIns_type,    provision,    drate_ym,    fcal_way,    fcar_class);
	
	if (strcmp(sIns_type,"99") == 0)
	{
		strcpy(iins_type_main,"0");
		strcpy(iins_type_dtl,"00");
		strcpy(iins_type_develop,"99");
		strcpy(iins_type_rule,"00");
	}
	
	/*�O�I�����N��*/
	strcat(prtstr,iins_type_main);
	strcpy(t_iins_type_main,trim(iins_type_main));
	prtstr[209]='\0';
	strcat(prtstr,iins_type_dtl);
	strcpy(t_iins_type_dtl,trim(iins_type_dtl));
	prtstr[211]='\0';
	strcat(prtstr,iins_type_develop);
	strcpy(t_iins_type_develop,iins_type_develop);
	prtstr[213]='\0';
	if (f_1060101 > 0)
	{
		strcat(prtstr,iins_type_rule);
		strcpy(t_iins_type_rule,trim(iins_type_rule));
	}
	else 
	{
		strcat(prtstr,"  ");
		strcpy(t_iins_type_rule," ");
	}
	prtstr[215]='\0';

	printf("--prtstr[%s] \n",prtstr);
	/* 216-217 ���I�I�O�N�� */
	if ((strncmp(sIns_type,"93",2) == 0) ||
	    (strncmp(sIns_type,"94",2) == 0) ||
	    (strncmp(sIns_type,"95",2) == 0))
	{
	 	strcat(prtstr,(*sIns_type=='\0') ? "00" : sIns_type);
	 	strcpy(t_iins_type_class,(*sIns_type=='\0') ? "00" : sIns_type);
	}
	else if ((strncmp(sIns_type,"193",3) == 0) ||
	         (strncmp(sIns_type,"194",3) == 0) ||
	         (strncmp(sIns_type,"195",3) == 0))
	{
	 	if (strncmp(sIns_type,"193",3) == 0)
		{
		 	strcat(prtstr,"93");
			strcpy(t_iins_type_class,"93");
		}
		else if (strncmp(sIns_type,"194",3) == 0)
		{
		 	strcat(prtstr,"94");
			strcpy(t_iins_type_class,"94");
		}
		else if (strncmp(sIns_type,"195",3) == 0)
		{
		 	strcat(prtstr,"95");
			strcpy(t_iins_type_class,"95");
		}
	}
	else if ((strncmp(sIns_type,"31",2) == 0 || strncmp(sIns_type,"231",3) == 0) && (strstr(trim(provision),"T") == NULL))
	{
		strcat(prtstr,"99");
		strcpy(t_iins_type_class,"99");
	}
	else if ((strncmp(sIns_type,"31",2) == 0 || strncmp(sIns_type,"231",3) == 0) && (strstr(trim(provision),"T") != NULL) && fcar_class[0] == '1')
	{
		strcat(prtstr,"99");
		strcpy(t_iins_type_class,"99");
	}
	else if ((strncmp(sIns_type,"31",2) == 0 || strncmp(sIns_type,"231",3) == 0) && (strstr(trim(provision),"T") != NULL) && fcar_class[0] == '2')
	{
		strcat(prtstr,"99");
		strcpy(t_iins_type_class,"99");
	}
	else if ((strcmp(iins_type_rule,"31")==0) && sIns_type[2]=='A')
	{
		strcat(prtstr,"93");  /* 1000817 sophie: 31��˭n��93 */
		strcpy(t_iins_type_class,"93");
	}
	else if (strcmp(sIns_type,"131A") == 0)
	{
		strcat(prtstr,"93");
		strcpy(t_iins_type_class,"93");
	}
	else if (strcmp(sIns_type,"131B") == 0)
	{
		strcat(prtstr,"94");
		strcpy(t_iins_type_class,"94");
	}
	else if (strcmp(sIns_type,"131C") == 0)
	{
		strcat(prtstr,"95");
		strcpy(t_iins_type_class,"95");
	}
	else if (strcmp(sIns_type,"331A") == 0)
	{
		strcat(prtstr,"93");
		strcpy(t_iins_type_class,"93");
	}
	else if (strcmp(sIns_type,"331B") == 0)
	{
		strcat(prtstr,"94");
		strcpy(t_iins_type_class,"94");
	}
	else if (strcmp(sIns_type,"331C") == 0)
	{
		strcat(prtstr,"95");
		strcpy(t_iins_type_class,"95");
	}
	else if (strcmp(sIns_type,"131") == 0 || strcmp(sIns_type,"331") == 0)
	{
		strcat(prtstr,"99");
		strcpy(t_iins_type_class,"99");
	}
	else
	{
		strcat(prtstr,"00");
		strcpy(t_iins_type_class,"00");
	}
	prtstr[217]='\0';
	
	/* 218 �O�_���W���O�v */
	strcat(prtstr,frule);
	strcpy(t_frule,frule);
  	prtstr[218]='\0';

	/*�[�˳]�ƫ�W�L���P���椧�T��*/  
 	strcpy(icar_series," ");
 	strcpy(mcar_price_tmp," ");
 	qpassenger=0;
 	mcar_price_ori=0;
	p_mcar_price = 0.0;
 	
	printf("ibrand[%s],ipro_year[%s],drate_ym[%s],mcar_price[%f],mcar_price_ori[%f],qpassenger[%f],icar_series[%s] \n",ibrand,ipro_year,drate_ym,mcar_price,mcar_price_ori,qpassenger,icar_series);
	
	if (strncmp(chk_157,"Y",1) == 0)
	{
		strcat(prtstr,"+000");
		t_p_mcar_price = 0;
	}
	else if(strcmp(sIns_type,"38") == 0 || strcmp(sIns_type,"39") == 0 || strcmp(sIns_type,"238") == 0)
	{
		strcat(prtstr,"+000");
		t_p_mcar_price = 0;
	}
	else
	{	
		rc = get_ca_car_model(ibrand,ipro_year,drate_ym,&mcar_price_ori,&qpassenger,&icar_series);
		if (strncmp(fins_grp,"1",1) == 0)
		{
			if (mcar_price_ori == 0)
			{
				mcar_price_ori = mcar_price;
				strcat(prtstr,"+000");
				t_p_mcar_price = 0;
			}
			else 
			{
				p_mcar_price = (mcar_price - mcar_price_ori) / mcar_price_ori;
				if((p_mcar_price*100) > 999)
				{
					strcat(prtstr,"+999");
					t_p_mcar_price = 999;
				}
				else if ((p_mcar_price*100) < -999)
				{
					strcat(prtstr,"-999");
					t_p_mcar_price = 999;
				}
				else 
				{
					rfmtdouble((p_mcar_price*100),"&&&", mcar_price_tmp);
					if (p_mcar_price < 0) strcat(prtstr,"-");
					else strcat(prtstr,"+");
					strcat(prtstr,mcar_price_tmp);
					t_p_mcar_price = p_mcar_price*100;
				}
			}
		}
		else 
		{
			strcat(prtstr,"+000");
			t_p_mcar_price = 0;
		}
	}
	printf("p_mcar_price[%f] mcar_price_tmp[%s]\n",p_mcar_price,mcar_price_tmp);
	
	/* field 30 211-213 �Q�O�I�H�����Y�� */
	if  (strncmp(fins_grp,"1",1) == 0)
	{
		if (strcmp(trim(sIns_type), "38")==0 || strcmp(trim(sIns_type), "39")==0 ||
		    strcmp(trim(sIns_type), "86")==0 || strcmp(trim(sIns_type), "98")==0 || 
		    strcmp(trim(sIns_type), "238")==0)  /*���ϥΨ�Y�ƭp��*/
		{
			pdmg_acc = 0;
			strcat(prtstr,"+000");
			t_pins_acc = 0;
		}
		else 
		{
			if( pdmg_acc < 0 )
			{
				strcat(prtstr,"-");
				rfmtdouble((pdmg_acc*100),"&&&", acc_tmp);
				strcat(prtstr,acc_tmp);
				t_pins_acc = pdmg_acc;
			}
			else
			{
				strcat(prtstr,"+");
				if( pdmg_acc > 0 )
				{
					rfmtdouble((pdmg_acc*100),"&&&", acc_tmp);
					strcat(prtstr,acc_tmp);
					t_pins_acc = pdmg_acc;
				}
				else
				{
					strcat(prtstr,"000");
					t_pins_acc = 0;
				}
			}
		}
	}
	else if ( strcmp(sIns_type, "131")==0  ||
	          strcmp(sIns_type, "131A")==0 ||
	          strcmp(sIns_type, "131B")==0 ||
	          strcmp(sIns_type, "131C")==0 ||
	          strcmp(sIns_type, "132")==0  ||
	          strcmp(sIns_type, "331")==0  ||
	          strcmp(sIns_type, "331A")==0 ||
	          strcmp(sIns_type, "331B")==0 ||
	          strcmp(sIns_type, "331C")==0 ||
	          strcmp(sIns_type, "332")==0)
	{
		if( plia_acc < 0 )
		{
			strcat(prtstr,"-");
			rfmtdouble((plia_acc*100),"&&&", acc_tmp);
			strcat(prtstr,acc_tmp);
			t_pins_acc = plia_acc;
		}
		else
		{
			strcat(prtstr,"+");
			if( plia_acc > 0 )
			{
				rfmtdouble((plia_acc*100),"&&&", acc_tmp);
				strcat(prtstr,acc_tmp);
				t_pins_acc = plia_acc;
			}
			else
			{
				strcat(prtstr,"000");
				t_pins_acc = 0;
			}
		}
	}
    else if( strcmp(sIns_type, "31")==0  ||
             strcmp(sIns_type, "32")==0  ||
             strcmp(sIns_type, "93")==0  ||
             strcmp(sIns_type, "94")==0  ||
             strcmp(sIns_type, "95")==0  ||
             strcmp(sIns_type, "231")==0 ||
             strcmp(sIns_type, "232")==0 ||
             strcmp(sIns_type, "193")==0 ||
             strcmp(sIns_type, "194")==0 ||
             strcmp(sIns_type, "195")==0
           )
	{
		if( plia_acc < 0 )
		{
			if (strcmp(trim(iins_type_develop), "31")==0 || strcmp(trim(iins_type_develop), "32")==0)
		    {
				$SELECT ncode
				   INTO $Maxmin
				   FROM cu_code_data
				  WHERE itype='T5'
				    AND icode='2';
				Maxminvalue=atof(Maxmin);
				if (plia_acc <  Maxminvalue)
				{
					plia_acc=Maxminvalue;
				}
		    }
		    strcat(prtstr,"-");
		    rfmtdouble((plia_acc*100),"&&&", acc_tmp);
		    strcat(prtstr,acc_tmp);
		    t_pins_acc = plia_acc;
		}
		else
		{
		    strcat(prtstr,"+");
		    if( plia_acc > 0 )
		    {
				if (strcmp(trim(iins_type_develop), "31")==0 || strcmp(trim(iins_type_develop), "32")==0)
				{
					$SELECT ncode
					   INTO $Maxmin
					   FROM cu_code_data
					  WHERE itype='T5'
					    AND icode='1';
					Maxminvalue=atof(Maxmin);
					if (plia_acc >  Maxminvalue)
					{
						plia_acc=Maxminvalue;
					}
				}
				rfmtdouble((plia_acc*100),"&&&", acc_tmp);
				strcat(prtstr,acc_tmp);
				t_pins_acc = plia_acc;
			}
			else
			{
				strcat(prtstr,"000");
				t_pins_acc = 0;
			}
		}
    }
    else if (strncmp(fins_grp,"2",1) == 0) 
    {
    	if( plia_acc < 0 )
		{
			strcat(prtstr,"-");
			rfmtdouble((plia_acc*100),"&&&", acc_tmp);
			strcat(prtstr,acc_tmp);
			t_pins_acc = plia_acc;
		}
		else
		{
			strcat(prtstr,"+");
			if( plia_acc > 0 )
			{
				rfmtdouble((plia_acc*100),"&&&", acc_tmp);
				strcat(prtstr,acc_tmp);
				t_pins_acc = plia_acc;
			}
			else
			{
				strcat(prtstr,"000");
				t_pins_acc = 0;
			}
		}
    }
    else
    {
    	strcat(prtstr, "+000");
    	t_pins_acc = 0;
	}

	/*�Q�O�I�H�~�֩ʧO�Y��*/
	printf("--�Q�O�I�H�~�֩ʧO�Y��\n");
	printf("psex_age_dmg[%f],psex_age_lia[%f] \n",psex_age_dmg,psex_age_lia);
	
	sex_age_tmp[0] = '\0';
	sex_age_tmp[0] = '\0';
	if (strcmp(trim(iri_ins),"11") == 0)
	{
		strcat(prtstr,"+000");
		t_psex_age = 0;
	}
	else
	{ 
		if (strcmp(fassured, "1") == 0 || strcmp(fassured, "3") == 0 || strcmp(fassured, "5") == 0)
		{
			if ( strncmp(fins_grp,"1",1) == 0 )
			{
				if( psex_age_dmg < 0 )
				{
					strcat(prtstr,"-");
					rfmtdouble((psex_age_dmg*100),"&&&", sex_age_tmp);
					strcat(prtstr,sex_age_tmp);
					t_psex_age = psex_age_dmg;
				}
				else
				{
					strcat(prtstr,"+");
					if( psex_age_dmg > 0 )
					{
						rfmtdouble((psex_age_dmg*100),"&&&", sex_age_tmp);
						strcat(prtstr,sex_age_tmp);
						t_psex_age = psex_age_dmg;
					}
					else 
					{
						strcat(prtstr,"000");
						t_psex_age = 0;
					}
				}
			}
			else if( strncmp(fins_grp,"2",1) == 0 )
			{
				if (strcmp(iins_ply,"131") == 0 || strcmp(iins_ply,"132") == 0 || strcmp(iins_ply,"24") == 0 ||
					strcmp(iins_ply,"26") == 0  || strcmp(iins_ply,"31") == 0  || strcmp(iins_ply,"32") == 0 ||
					strcmp(iins_ply,"41") == 0  || strcmp(iins_ply,"42") == 0  ||
					strcmp(iins_ply,"231") == 0 || strcmp(iins_ply,"232") == 0 ||
					strcmp(iins_ply,"331") == 0 || strcmp(iins_ply,"332") == 0)
				{
					if( psex_age_lia < 0 )
					{
						strcat(prtstr,"-");
						rfmtdouble((psex_age_lia*100),"&&&", sex_age_tmp);
						strcat(prtstr,sex_age_tmp);
						t_psex_age = psex_age_lia;
					}
					else
					{
						strcat(prtstr,"+");
						if( psex_age_lia > 0 )
						{
							rfmtdouble((psex_age_lia*100),"&&&", sex_age_tmp);
							strcat(prtstr,sex_age_tmp);
							t_psex_age = psex_age_lia;
						}
						else
						{
							strcat(prtstr,"000");
							t_psex_age = 0;
						}
					}
				}
				else 
				{
					strcat(prtstr,"+000");
					t_psex_age = 0;
				}
			}
			else 
			{
				strcat(prtstr,"+000");
				t_psex_age = 0;
			}
		}
		else
		{
			strcat(prtstr,"+000");
			t_psex_age = 0;
		}
	}

	/*���²v-�����I*/
	strcat(prtstr,pdepreciate_year_tmp2);
	
	/*UBI�ӫ~�O�v�]�l*/
	/*UBI�u���@�i�O��S���X�I-�������_*/
	strcat(prtstr, "00000000");
	strcpy(t_ubi_data,"00000000");

    /* field 31 214-223 �O�I���B */
    /* �O�B�n�����-�����±��ڦA������A�p�G�ߥI���B�W�L����ڭp��O�B�N�n����ߥI���B*/
    /* ���]09�I��+P�B�쭫��100�U�A����«O�B��75�U�A���[P����85�U�A���ߥI80�U�A�h09�I�ؽߥI�W���u�ର75�U ��l��P���ڸɤW5�U*/
    /* �t�z�ߦ������ߥI���D-���]�Ĥ@���ߥI70�U�A�ĤG���ߥI80�U�A�Ĥ@�����z�ߪ��B��09�I��70�U�A�ĤG���ߥI�ɫh�� 09�I��5�U�AP����5�U*/
    printf("iprovision_P[%d] \n",iprovision_P);
    if (iprovision_P > 0 || iprovision_Q > 0 || iprovision_M > 0 || iprovision_Z > 0)
    {
	    printf("qpro_month[%d] ipro_year[%s]\n",qpro_month,ipro_year);
		sprintf_s(dpro, sizeof dpro,"%s/01/%s",itoa(qpro_month),ipro_year);
		strcpy(dpro,trim(dpro));
		strcpy(dissue_100,cm_from_infdate_100(dissue));
		strcpy(dpro_100,cm_from_infdate_100(dpro));
		printf("dissue_100[%s] dpro_100[%s]\n",dissue_100,dpro_100);
		ldissue = cm_ymd_cdate(dissue_100);
		ldpro = cm_ymd_cdate(dpro_100);
		printf("ldissue[%d] ldpro[%d]\n",ldissue,ldpro);
		
	    if (strcmp(trim(icar_series),"10") ==0)
		{
			if(DiffMonth(ldissue,ldpro)>3)
				strcpy(dissue_pro_tmp,dpro);
			else 
				strcpy(dissue_pro_tmp,dissue);
		}
		else 
		{
			if(DiffMonth(ldissue,ldpro)>6)
				strcpy(dissue_pro_tmp,dpro);
			else 
				strcpy(dissue_pro_tmp,dissue);
		}
		
		/*���[���±��ګ�O�B-����E���ڳ]�w  �{E���ڤ��e*/
	    /*rc = get_dmg_cover(iins_main,provision,dissue_pro,drate_ym,icar_type_ori,mcar_price,mcover_ori);*/
	    /*����«O�B*/
	    rc = get_dmg_cover(iins_main," ",dissue_pro_tmp,drate_ym,icar_type_ori,mcar_price,dply_begin,&mcover_ori);
	    printf("--3781  mcover_ori[%d] \n",mcover_ori);
    }
    else  
    	mcover_ori = mdamage_cover;
   
	printf("mcover_ori[%d]\n",mcover_ori);
   
    strcat(prtstr,"+");
	if(strcmp(sIns_type, "131A")==0 || strcmp(sIns_type, "131B")==0 || strcmp(sIns_type, "131C")==0)
    {
		rfmtlong(minjure_cover,"&&&&&&&&&",buf);
		strcat(prtstr, buf);
		mdamage_cover31 = mdamage_cover;
		t_mcover = minjure_cover;
    }
    else if(strcmp(sIns_type, "154A")==0 || strcmp(sIns_type, "155A")==0 || strcmp(sIns_type, "156A")==0 || strcmp(sIns_type, "163A")==0)
    {
		rfmtlong(3000,"&&&&&&&&&",buf);
		strcat(prtstr, buf);
		t_mcover = 3000;
    }
	else
    {
		instype_i = atoi(sIns_type);
		switch(instype_i)
		{
			case 99:
				strcat(prtstr,"000000000");
				t_mcover = 0;
				break;
			case 31: case 131: case 231: case 331:
				rfmtlong(mdamage_cover31,"&&&&&&&&&",buf);
				strcat(prtstr, buf);
				t_mcover = mdamage_cover31;
				break;
			case 93: case 94: case 95: case 193: case 194: case 195:
				rfmtlong(minjure_cover,"&&&&&&&&&",buf);
				strcat(prtstr, buf);
				mdamage_cover31 = mdamage_cover;
				t_mcover = minjure_cover;
				break;
			default:
				if(iprovision_P > 0 || iprovision_Q > 0 || iprovision_M > 0 || iprovision_Z > 0)
				{
					/*  01/05/09/11  �����I�A�����[���� �z�ߪ��B>����«O�B �n��C */
					printf("chk_provision[%d],chk_division[%d] \n ",chk_provision,chk_division);
					if (chk_division2 > 0)
					{
						mdamage_cover_over = mdamage_cover_prov;		
					}
					else if (mins_app > mcover_ori && chk_provision > 0)
					/*mins_stl > mcover_ori_tmp && chk_provision > 0 && *fstl != '2'*/
					{
						mdamage_cover_over =  mcover_ori;
						mdamage_cover_prov = mdamage_cover - mcover_ori;
					}
					else 
					{
						if (mdamage_cover > 999999999)
							mdamage_cover_over = 999999999;
						else
							mdamage_cover_over = mdamage_cover;
					}
				}
				else 
				{
					if (mdamage_cover > 999999999)
						mdamage_cover_over = 999999999;
					else
						mdamage_cover_over = mdamage_cover;
				}
				rfmtlong(mdamage_cover_over,"&&&&&&&&&",mdamage_cover_c);
				strcat(prtstr, mdamage_cover_c);
				t_mcover = mdamage_cover_over;
				printf("mins_stl[%d] mcover_ori[%d] mdamage_cover[%d] mdamage_cover_over[%d] mdamage_cover_prov[%d]\n",mins_stl,mcover_ori,mdamage_cover,mdamage_cover_over,mdamage_cover_prov);
				break;
		}
	}
    
    /*�O�٭���*/
	printf("--�O�٭���\n");
	if (strcmp(trim(sIns_type), "31")==0 || strcmp(trim(sIns_type), "93")==0 || strcmp(trim(sIns_type), "94")==0 || strcmp(trim(sIns_type), "95")==0) /*�ƬG�O�B/��˫O�B*/
	{
		iins_mult = mdamage_cover/minjure_cover;
	}
	else if (strcmp(trim(sIns_type), "231")==0 || strcmp(trim(sIns_type), "193")==0 || strcmp(trim(sIns_type), "194")==0 || strcmp(trim(sIns_type), "195")==0) /*�ƬG�O�B/��˫O�B*/
	{
		iins_mult = mdamage_cover/minjure_cover;
	}
	else if (strcmp(trim(sIns_type), "109")==0)  /*(�ƬG�O�B-��˫O�B)/��˫O�B*/
	{
		iins_mult = (mdamage_cover-minjure_cover)/minjure_cover;
	}
	else if (strncmp(trim(sIns_type), "301",3)==0)  /*2��*/
	{
		iins_mult = 2;
	}
	else if (strncmp(trim(sIns_type), "302",3)==0)  /*2��*/
	{
		iins_mult = 2;
	}
	else if (strncmp(trim(sIns_type), "131",3)==0 || strncmp(trim(sIns_type), "331",3)==0)  /*�ƬG�O�B/��˫O�B*/
	{
		iins_mult = mdamage_cover/minjure_cover;
	}
	else if (strncmp(trim(sIns_type), "124",3)==0)  /*2�� */
	{
		iins_mult = 2;
	}
	else if (strncmp(trim(sIns_type), "34",2)==0)  /*1�� */
	{
		iins_mult = 1;
	}
	else if (strncmp(fins_grp,"1",1) != 0)
	{
		iins_mult = mdamage_cover/mdeath_cover;
	}
	else
		iins_mult = 0;
		
	if (iins_mult > 99)
	{
		strcat(prtstr,"+99");
		t_iins_mult = 99;
	} 
	else 
	{
		rfmtlong(iins_mult,"&&",iin_mult_c);
		strcat(prtstr,"+");
		strcat(prtstr,iin_mult_c);
		t_iins_mult = iins_mult;
	}

	/* field 32 224-234 �ۭt�B */
	if(strcmp(sIns_type, "71")==0 || strcmp(sIns_type, "72")==0)
    {
		strcat(prtstr,"1"); /*�s�x��*/
		strcpy(t_fmdeduct,"1");
		mdeduct = 10000;
    }
    else if(strcmp(sIns_type, "11")==0 || strcmp(sIns_type, "211")==0)
    {
		if( mdeduct == 0 )
		{
		    strcat(prtstr,"5");
		    strcpy(t_fmdeduct,"5");
		}
		else
		{
		    strcat(prtstr,"3");
		    strcpy(t_fmdeduct,"3");
		}
    }
    else if(strcmp(sIns_type, "08")==0)
    {
        if( mdeduct == 8 ) /*��L*/
        {
        	strcat(prtstr,"4");
        	strcpy(t_fmdeduct,"4");
        	mdeduct = 0;
        }
        else 
        {
        	strcat(prtstr,"5");
        	strcpy(t_fmdeduct,"5");
        }
    }
	else if(strcmp(sIns_type, "01")==0  || strcmp(sIns_type, "05")==0 || 
	        strcmp(sIns_type, "201")==0 || strcmp(sIns_type, "205")==0)
    {
        if( mdeduct == 0 )
        {
            strcat(prtstr,"5"); /*�L�ۭt�B*/
            strcpy(t_fmdeduct,"5");
        }
        else if( mdeduct < 10 )
        {
            strcat(prtstr,"2"); /*�N��*/
            strcpy(t_fmdeduct,"2");
        }
        else
        {
            strcat(prtstr,"1"); /*�s�x��*/
            strcpy(t_fmdeduct,"1");
        }
    }
    else if(strcmp(sIns_type, "31")==0  || strcmp(sIns_type, "32")==0  ||
            strcmp(sIns_type, "93")==0  || strcmp(sIns_type, "94")==0  ||
            strcmp(sIns_type, "95")==0  ||
            strcmp(sIns_type, "231")==0 || strcmp(sIns_type, "232")==0 ||
            strcmp(sIns_type, "193")==0 || strcmp(sIns_type, "194")==0 ||
            strcmp(sIns_type, "195")==0)
    {
        if( mdeduct == 0 )
        {
            strcat(prtstr,"5"); /*�L�ۭt�B*/
            strcpy(t_fmdeduct,"5");
        }
        else
        {
            strcat(prtstr,"1"); /*�s�x��*/
            strcpy(t_fmdeduct,"1");
        }
    }
    else if(strcmp(sIns_type, "131")==0  || strcmp(sIns_type, "131A")==0 ||
	        strcmp(sIns_type, "131B")==0 || strcmp(sIns_type, "131C")==0 ||
	        strcmp(sIns_type, "132")==0  ||
	        strcmp(sIns_type, "331")==0  || strcmp(sIns_type, "331A")==0 ||
	        strcmp(sIns_type, "331B")==0 || strcmp(sIns_type, "331C")==0 ||
	        strcmp(sIns_type, "332")==0)
    {
        strcat(prtstr,"2"); /*�䥦*/
        strcpy(t_fmdeduct,"2");
    }
    else if(strcmp(sIns_type, "09")==0 || strcmp(sIns_type, "209")==0)
    {
        if( mdeduct == 0 )
        {
            strcat(prtstr,"5"); /*�L�ۭt�B*/
            strcpy(t_fmdeduct,"5");
        }
        else
        {
            strcat(prtstr,"1"); /*�s�x��*/
            strcpy(t_fmdeduct,"1");
        }
    }
	else if (strcmp(sIns_type,"18") == 0)
	{
		strcat(prtstr,"3");	/*�ʤ���*/
		strcpy(t_fmdeduct,"3");
		if (mdeduct == 5010 || mdeduct == 6010 || mdeduct == 7510)
			mdeduct = 10;
		else if (mdeduct == 6020 || mdeduct == 7520)
			mdeduct = 20;
	}
    else if (strcmp(sIns_type,"86")==0 || strcmp(sIns_type,"96")==0 || strcmp(sIns_type,"98")==0)
    {
         strcat(prtstr,"5");
         strcpy(t_fmdeduct,"5");
         mdeduct = 0;
    }
    else if(strcmp(sIns_type, "28")==0)
    {
        if( mdeduct == 0 )
        {
            strcat(prtstr,"5");
            strcpy(t_fmdeduct,"5");
        }
        else
        {
            strcat(prtstr,"3");
            strcpy(t_fmdeduct,"3");
        }
    }
    else if(strcmp(sIns_type, "129")==0)
    {
        if( mdeduct == 0 )
        {
            strcat(prtstr,"5");
            strcpy(t_fmdeduct,"5");
        }
        else
        {
            strcat(prtstr,"3");
            strcpy(t_fmdeduct,"3");
        }
    }
    else if(strcmp(sIns_type, "122")==0)
    {
        if( mdeduct == 0 )
        {
            strcat(prtstr,"5"); /*�L�ۭt�B*/
            strcpy(t_fmdeduct,"5");
        }
        else if( mdeduct < 10 )
        {
            strcat(prtstr,"2"); /*�N��*/
            strcpy(t_fmdeduct,"2");
        }
        else
        {
            strcat(prtstr,"1"); /*�s�x��*/
            strcpy(t_fmdeduct,"1");
        }
    }
    else if(strcmp(trim(sIns_type), "113")==0 )
	{
		if( mdeduct == 0 )
		{
			strcat(prtstr,"5"); /*�L�ۭt�B*/
			strcpy(t_fmdeduct,"5");
		}
		else
		{
			strcat(prtstr,"1"); /*�s�x��*/
			strcpy(t_fmdeduct,"1");
		}
	}	
	else if(strcmp(trim(sIns_type), "128")==0 )
	{
		if( mdeduct == 0 )
		{
			strcat(prtstr,"5"); /*�L�ۭt�B*/
			strcpy(t_fmdeduct,"5");
		}
		else
		{
			strcat(prtstr,"3"); /*�ʤ���*/
			strcpy(t_fmdeduct,"3");
		}
	}
	else if(strcmp(trim(sIns_type), "149")==0 || strcmp(trim(sIns_type), "249")==0)
	{
		if( mdeduct == 0 )
		{
			strcat(prtstr,"5"); /*�L�ۭt�B*/
			strcpy(t_fmdeduct,"5");
		}
		else
		{
			strcat(prtstr,"1"); /*�s�x��*/
			strcpy(t_fmdeduct,"1");
		}
	}
	else if(strcmp(sIns_type, "176")==0 || strcmp(sIns_type, "177")==0 || strcmp(sIns_type, "178")==0)
    {
		if( mdeduct == 0 )
		{
		    strcat(prtstr,"5");
		    strcpy(t_fmdeduct,"5");
		}
		else
		{
		    strcat(prtstr,"3");
		    strcpy(t_fmdeduct,"3");
		}
    }
    else if (strcmp(sIns_type,"99")==0)
    {
    	strcat(prtstr,"0");
    	strcpy(t_fmdeduct,"0");
    }
    else
    {
    	strcat(prtstr,"5");
    	strcpy(t_fmdeduct,"5");
    }
	
	if (f_1060101 > 0)
	{
		if((strcmp(trim(iins_type_develop),"13") == 0) ||
		   (strcmp(trim(iins_type_develop),"35") == 0) ||
		   (strcmp(trim(iins_type_develop),"54") == 0) ||
		   (strcmp(trim(iins_type_develop),"62") == 0) ||
		   (strcmp(trim(iins_type_develop),"33") == 0) ||
		   (strcmp(trim(iins_type_develop),"04") == 0) && 
		   (strcmp(trim(iins_type),"28")  != 0 && strcmp(trim(iins_type),"128") != 0 &&
		    strcmp(trim(iins_type),"113") != 0 && strcmp(trim(iins_type),"149") != 0 && strcmp(trim(iins_type),"249") != 0 &&
		    strcmp(trim(iins_type),"176") != 0 && strcmp(trim(iins_type),"177") != 0 && strcmp(trim(iins_type),"178") != 0))
			mdeduct = 0;
	}
	else
	{
		if((strcmp(iins_type_develop,"22") == 0) || (strcmp(iins_type_develop,"61") == 0) ||
	       (strcmp(iins_type_develop,"62") == 0) || (strcmp(iins_type_develop,"16") == 0) )
			mdeduct = 0;
	}

	if(strcmp(sIns_type, "99") == 0)
	{
		strcat(prtstr,"0000000");
		t_mdeduct = 0;
	}
	else
	{
		printf("mdeduct[%d]\n",mdeduct);
		rfmtlong(mdeduct ,"&&&&&&&",mdeduct_c);
		strcat(prtstr,mdeduct_c);
		t_mdeduct = mdeduct;
	}
	printf("mdeduct_c[%d]\n",mdeduct_c);

	/* field 33 232-234 ��ڲz�ߤH�� */
	if(strcmp(iins_type_rule,"34") == 0 || strcmp(iins_type_rule,"61") == 0){
		qpeople = 0;
		rfmtlong(qpeople, "&&&", buf);
		strcat(prtstr, buf);
	}
	else if(strcmp(sIns_type,"93") == 0  || strcmp(sIns_type,"131A") == 0 || 
	        strcmp(sIns_type,"193") == 0 || strcmp(sIns_type,"331A") == 0)
	{
		qpeople = qinjure31;
		qinjure99 += qinjure31;
		rfmtlong(qpeople, "&&&", buf);
		strcat(prtstr, buf);
	}
	else if(strcmp(sIns_type,"94") == 0  || strcmp(sIns_type,"131B") == 0 || 
	        strcmp(sIns_type,"194") == 0 || strcmp(sIns_type,"331B") == 0)
	{
		qpeople = qdeath31;
		qdeath99 += qdeath31;
		rfmtlong(qpeople, "&&&", buf);
		strcat(prtstr, buf);
	}
	else if(strcmp(sIns_type,"95") == 0  || strcmp(sIns_type,"131C") == 0 || 
	        strcmp(sIns_type,"195") == 0 || strcmp(sIns_type,"331C") == 0)
	{
		qpeople = qbreak31;
		qbreak99 += qbreak31;
		rfmtlong(qpeople, "&&&", buf);
		strcat(prtstr, buf);
	}
	else if((strcmp(sIns_type,"31") == 0 || strcmp(sIns_type,"231") == 0) && (strstr(trim(provision),"T") != NULL) && fcar_class[0] == '2')
	{
		qpeople = qinjure31+qdeath31+qbreak31;
		rfmtlong(qpeople, "&&&", buf);
		strcat(prtstr, buf);
	}
	else if((strcmp(sIns_type,"31") == 0 || strcmp(sIns_type,"231") == 0) && (strstr(trim(provision),"T") != NULL) && fcar_class[0] == '1')
	{
		qpeople = qinjure31+qdeath31+qbreak31;
		if(qpeople > 0)
		{
			qpeople = 1;
		}
		else
		{
			qpeople = 0;
		}
		rfmtlong(qpeople, "&&&", buf);
		strcat(prtstr, buf);
	}
	else if((strcmp(sIns_type,"31") == 0 || strcmp(sIns_type,"231") == 0) && (strstr(trim(provision),"T") == NULL))
	{
		qpeople = qinjure31+qdeath31+qbreak31;
		if(qpeople > 0)
		{
			qpeople = 1;
		}
		else
		{
			qpeople = 0;
		}
		rfmtlong(qpeople, "&&&", buf);
		strcat(prtstr, buf);
	}
	else if(strcmp(sIns_type,"131") == 0 || strcmp(sIns_type,"331") == 0)
	{
		qpeople = qinjure31+qdeath31+qbreak31;
		if(qpeople > 0)
		{
			qpeople = 1;
		}
		else
		{
			qpeople = 0;
		}
		rfmtlong(qpeople, "&&&", buf);
		strcat(prtstr, buf);
	}
	else if(strcmp(sIns_type, "99") == 0)
	{
		qpeople = 0;
		rfmtlong(qpeople, "&&&", buf);
		strcat(prtstr, buf);
	}
	else
	{
		qinjure99 += qinjure2; qdeath99 += qdeath2;
		qpeople = qinjure2+qdeath2;
		rfmtlong(qpeople, "&&&", buf);
		strcat(prtstr, buf);
	}
	
	/*�F�Ƴd���ʤ���  ���d/����*/
	printf("bef facc_duty[%s],fdmg_duty[%s],iself_duty[%d] ioth_duty[%d] ianoth_duty[%d] \n",facc_duty,fdmg_duty,iself_duty,ioth_duty,ianoth_duty);
	if(strncmp(fins_grp,"2",1) == 0)  /*���d*/
	{
		if (facc_duty[0] == '1')
		{
			if ((iself_duty + ioth_duty + ianoth_duty) == 0)
			{
				iself_duty = 100;
				ioth_duty = 0;
				ianoth_duty = 0;
			}
			else if ((iself_duty + ioth_duty + ianoth_duty) > 0 && (iself_duty + ioth_duty + ianoth_duty) < 100)
			{
				iself_duty = 100;
				ioth_duty = 0;
				ianoth_duty = 0;
			}
			else if ((iself_duty + ioth_duty + ianoth_duty) > 100)
			{
				iself_duty = 100;
				ioth_duty = 0;
				ianoth_duty = 0;
			}
			else if ((iself_duty == 0) && ( ioth_duty == 100 ))
			{
				iself_duty = 100;
				ioth_duty = 0;
				ianoth_duty = 0;
			}     
		}
		
		if (facc_duty[0] == '3')
		{
			if ((iself_duty + ioth_duty + ianoth_duty) == 0)
			{
				iself_duty = 100;
				ioth_duty = 0;
				ianoth_duty = 0;
			}
			else if ((iself_duty + ioth_duty + ianoth_duty) > 0 && (iself_duty + ioth_duty + ianoth_duty) < 100)
			{
				iself_duty = 100;
				ioth_duty = 0;
				ianoth_duty = 0;
			}
			else if ((iself_duty + ioth_duty + ianoth_duty) > 100)
			{
				iself_duty = 100;
				ioth_duty = 0;
				ianoth_duty = 0;
			}
		}
		
		if (facc_duty[0] == '2')
		{
			if(iself_duty > 0)
			{
				iself_duty = 0;
				ioth_duty = 100;
				ianoth_duty = 0;
			}
			else if ((iself_duty + ioth_duty + ianoth_duty) == 0)
			{
				iself_duty = 0;
				ioth_duty = 100;
				ianoth_duty = 0;
			}
			else if ((iself_duty + ioth_duty + ianoth_duty) > 0 && (iself_duty + ioth_duty + ianoth_duty) < 100)
			{
				iself_duty = 0;
				ioth_duty = 100;
				ianoth_duty = 0;
			}
			else if((iself_duty + ioth_duty + ianoth_duty) > 100)
			{
				iself_duty = 0;
				ioth_duty = 100;
				ianoth_duty = 0;
			}
		}
	}
	else if(strncmp(fins_grp,"1",1) == 0)   /*����t��*/
	{
		if (fdmg_duty[0] == '1')
		{
			if ((iself_duty + ioth_duty + ianoth_duty) == 0)
			{
				iself_duty = 100;
				ioth_duty = 0;
				ianoth_duty = 0;
			}
			else if ((iself_duty + ioth_duty + ianoth_duty) > 0 && (iself_duty + ioth_duty + ianoth_duty) < 100)
			{
				iself_duty = 100;
				ioth_duty = 0;
				ianoth_duty = 0;
			}
			else if ((iself_duty + ioth_duty + ianoth_duty) > 100)
			{
				iself_duty = 100;
				ioth_duty = 0;
				ianoth_duty = 0;
			}
			else if ((iself_duty == 0) && ( ioth_duty == 100 ))
			{
				iself_duty = 100;
				ioth_duty = 0;
				ianoth_duty = 0;
			}     
		}
		
		if (fdmg_duty[0] == '3')
		{
			if ((iself_duty + ioth_duty + ianoth_duty) == 0)
			{
				iself_duty = 100;
				ioth_duty = 0;
				ianoth_duty = 0;
			}
			else if ((iself_duty + ioth_duty + ianoth_duty) > 0 && (iself_duty + ioth_duty + ianoth_duty) < 100)
			{
				iself_duty = 100;
				ioth_duty = 0;
				ianoth_duty = 0;
			}
			else if ((iself_duty + ioth_duty + ianoth_duty) > 100)
			{
				iself_duty = 100;
				ioth_duty = 0;
				ianoth_duty = 0;
			}
		}
		
		if (fdmg_duty[0] == '2')
		{
			if(iself_duty > 0)
			{
				ioth_duty = 100;
				iself_duty = 0;
				ianoth_duty = 0;
			}
			else if ((iself_duty + ioth_duty + ianoth_duty) == 0)
			{
				iself_duty = 0;
				ioth_duty = 100;
				ianoth_duty = 0;
			}
			else if ((iself_duty + ioth_duty + ianoth_duty) > 0 && (iself_duty + ioth_duty + ianoth_duty) < 100)
			{
				iself_duty = 0;
				ioth_duty = 100;
				ianoth_duty = 0;
			}
			else if((iself_duty + ioth_duty + ianoth_duty) > 100)
			{
				iself_duty = 0;
				ioth_duty = 100;
				ianoth_duty = 0;
			}
		}
	}
	else 
		iself_duty = ioth_duty = ianoth_duty = 0;

	if( strcmp(ioth_cartype,"98")==0 && ioth_duty > 0)
	{
         ioth_duty = 0;
         ianoth_duty = 100 - iself_duty;
	}
	printf("aft iself_duty[%d] ioth_duty[%d] ianoth_duty[%d] \n",iself_duty,ioth_duty,ianoth_duty);
	
	/* 267-269 �����F�Ƴd���ʤ��� */
	iself_duty_c[0]='\0';
	rfmtlong(iself_duty,"&&&",iself_duty_c);
	strcat(prtstr, iself_duty_c);
	t_iself_duty = iself_duty;
	prtstr[269] = '\0';
	/* 270-272 ��訮�F�Ƴd���ʤ��� */
	ioth_duty_c[0]='\0';
	rfmtlong(ioth_duty,"&&&",ioth_duty_c);
	strcat(prtstr, ioth_duty_c);
	t_ioth_duty = ioth_duty;
	prtstr[272] = '\0';
	/* 273-275 ��L���F�Ƴd���ʤ��� */
	ianoth_duty_c[0]='\0';
	rfmtlong(ianoth_duty,"&&&",ianoth_duty_c);
	strcat(prtstr, ianoth_duty_c);
	t_ianoth_duty = ianoth_duty;
	prtstr[275] = '\0';

	/* 276-284 �w�����B==>���{�������M���B } */
	strcat(prtstr,"+");
	if(strcmp(sIns_type, "31") == 0 || strcmp(sIns_type, "131") == 0 || strcmp(sIns_type, "231") == 0 || strcmp(sIns_type, "331") == 0) /*�z�ߨõL31�B131�I��==>�����93,94,95,131A,131B,131C�I��*/
	{
		rfmtlong(mins_app31, "&&&&&&&&", buf);
		strcat(prtstr, buf);
		t_mins_app = mins_app31;
	}
	else if(strcmp(sIns_type, "99") == 0)
	{
		rfmtlong(mins_app99, "&&&&&&&&", buf);
		strcat(prtstr, buf);
		t_mins_app = mins_app99;
	}
	else if(strcmp(sIns_type, "93") == 0   || strcmp(sIns_type, "94") == 0   || strcmp(sIns_type, "95") == 0   ||
	        strcmp(sIns_type, "131A") == 0 || strcmp(sIns_type, "131B") == 0 || strcmp(sIns_type, "131C") == 0 ||
	        strcmp(sIns_type, "193") == 0  || strcmp(sIns_type, "194") == 0  || strcmp(sIns_type, "195") == 0  ||
	        strcmp(sIns_type, "331A") == 0 || strcmp(sIns_type, "331B") == 0 || strcmp(sIns_type, "331C") == 0 )
	{
		rfmtlong(mins_app, "&&&&&&&&", buf);
		strcat(prtstr, buf);
		mins_app99 += mins_app;
		mins_app31 += mins_app;
		prem_total += mins_app;
		t_mins_app = mins_app;
	}
	else if (strcmp(trim(sIns_type),"29") == 0)
	{
		rfmtlong(mins_app_29, "&&&&&&&&", buf);
		strcat(prtstr, buf);
		mins_app99 += mins_app_29;
		prem_total += mins_app_29;
		t_mins_app = mins_app_29;
	}
	else if (strcmp(trim(sIns_type),"24") == 0)
	{
		rfmtlong(mins_app_24, "&&&&&&&&", buf);
		strcat(prtstr, buf);
		mins_app99 += mins_app_24;
		prem_total += mins_app_24;
		t_mins_app = mins_app_24;
	}
	else if (strcmp(trim(sIns_type),"30") == 0)
	{
		rfmtlong(mins_app_30, "&&&&&&&&", buf);
		strcat(prtstr, buf);
		mins_app99 += mins_app_30;
		prem_total += mins_app_30;
		t_mins_app = mins_app_30;
	}
	else if (strcmp(trim(sIns_type),"35") == 0)
	{
		rfmtlong(mins_app_35, "&&&&&&&&", buf);
		strcat(prtstr, buf);
		mins_app99 += mins_app_35;
		prem_total += mins_app_35;
		t_mins_app = mins_app_35;
	}
	else if (strcmp(trim(sIns_type),"55") == 0)
	{
		rfmtlong(mins_app_55, "&&&&&&&&", buf);
		strcat(prtstr, buf);
		mins_app99 += mins_app_55;
		prem_total += mins_app_55;
		t_mins_app = mins_app_55;
	}
	else if (strcmp(trim(sIns_type),"26") == 0)
	{
		rfmtlong(mins_app_26, "&&&&&&&&", buf);
		strcat(prtstr, buf);
		mins_app99 += mins_app_26;
		prem_total += mins_app_26;
		t_mins_app = mins_app_26;
	}
	else
	{
		printf("--4025  chk_division[%d],chk_division2[%d] mins_app[%d] mcover_ori[%d]\n",chk_division,chk_division2,mins_app,mcover_ori);
		if(iprovision_P > 0 || iprovision_Q > 0 || iprovision_M > 0 || iprovision_Z > 0)
		{
			/*  01/05/09/11  �����I�A�����[���� �z�ߪ��B>����«O�B �n��C */
			if (chk_division2 > 0)
			{
				mins_app_tmp = mins_app_pro;
				rfmtlong(mins_app_tmp, "&&&&&&&&", buf);
			}
			else if (mins_app > mcover_ori && chk_provision > 0)
			{
				mins_app_pro = 	mins_app - mcover_ori;
				mins_app_tmp = mcover_ori;
				rfmtlong(mins_app_tmp, "&&&&&&&&", buf);
				chk_division++;
			}
			else 
			{
				rfmtlong(mins_app, "&&&&&&&&", buf);
				mins_app_tmp = mins_app;
			}
			printf("mins_app_tmp[%d],mins_app_pro[%d],chk_division[%d]\n",mins_app_tmp,mins_app_pro,chk_division);
		}
		else 
		{
			rfmtlong(mins_app, "&&&&&&&&", buf);
			mins_app_tmp = mins_app;
		}
		strcat(prtstr, buf);
		mins_app99 += mins_app_tmp;
		prem_total += mins_app_tmp;
		t_mins_app = mins_app_tmp;
		/*rfmtlong(mins_app, "&&&&&&&&", buf);
		strcat(prtstr, buf);
		mins_app99 += mins_app;
		prem_total += mins_app;*/
	}

	/* 292-300 �z�ߦۭt�B */
	strcat(prtstr,"0000000");
	t_mdeduct_clm = 0;

	/* 292-300 ��ڲz�ߪ��B */
	strcat(prtstr,"+");
	strcat(prtstr, "00000000");
	t_mins_stl = 0;

	/* 301-308 �z�߶O�� */
	strcat(prtstr,"+");
	strcat(prtstr, "0000000");
	t_mins_proc = 0;

	/* 309 �ߥI�N�� */
    strcat(prtstr,"0");
    strcpy(t_fstl,"0");

	/* 310-321 �ӫ~�N�X  */
	if ((!strcmp(trim(icar_type),"01")) ||
	    (!strcmp(trim(icar_type),"02")) ||
	    (!strcmp(trim(icar_type),"32")) ||
	    (!strcmp(trim(icar_type),"34")) ||
	    (!strcmp(trim(icar_type),"35")))
	      strcpy(fcar_class,"3");
	else
	{
		$EXECUTE CUR_CARCLASS INTO $fcar_class
		                     using $icar_type;
		if (SQLCODE == SQLNOTFOUND) strcpy(fcar_class,"1");
	}
	
	if (strcmp(trim(sIns_type),"99") == 0)
		strcpy(iproduct,"000000000000");
	else
	if ((strcmp(trim(sIns_type),"93") == 0) ||
	    (strcmp(trim(sIns_type),"94") == 0) ||
	    (strcmp(trim(sIns_type),"95") == 0))
	{
		 $SELECT iproduct
		    INTO $iproduct
		    FROM cm_product_code
		   WHERE iins_class = 'C'
		     AND icode2 = ' '
		     AND iins_type = '31'
		     AND icode1 = $fcar_class;
	}
	else if((strcmp(trim(sIns_type),"131A") == 0) ||
	        (strcmp(trim(sIns_type),"131B") == 0) ||
	        (strcmp(trim(sIns_type),"131C") == 0))
	{
		$SELECT iproduct
		   INTO $iproduct
		   FROM cm_product_code
		  WHERE iins_class = 'C'
		    AND icode2 = ' '
		    AND iins_type = '131'
		    AND icode1 = $fcar_class;
	}
	else if((strcmp(trim(sIns_type),"193") == 0) ||
	        (strcmp(trim(sIns_type),"194") == 0) ||
	        (strcmp(trim(sIns_type),"195") == 0))
	{
		$SELECT iproduct
		   INTO $iproduct
		   FROM cm_product_code
		  WHERE iins_class = 'C'
		    AND icode2 = ' '
		    AND iins_type = '231'
		    AND icode1 = $fcar_class;
	}
	else if((strcmp(trim(sIns_type),"331A") == 0) ||
	        (strcmp(trim(sIns_type),"331B") == 0) ||
	        (strcmp(trim(sIns_type),"331C") == 0))
	{
		$SELECT iproduct
		   INTO $iproduct
		   FROM cm_product_code
		  WHERE iins_class = 'C'
		    AND icode2 = ' '
		    AND iins_type = '331'
		    AND icode1 = $fcar_class;
	}
	else{
		$SELECT iproduct
		   INTO $iproduct
		   FROM cm_product_code
		  WHERE iins_class = 'C'
		    AND icode2 = ' '
		    AND iins_type = (SELECT iins_ply FROM insurance_type WHERE iins_type = trim($sIns_type))
		    AND icode1 = $fcar_class;
	}
	if (SQLCODE == SQLNOTFOUND) strcpy(iproduct,"000000000000");
	
	if (strcmp(sIns_type,"P") == 0 || strcmp(sIns_type,"Q") == 0 || strcmp(sIns_type,"M") == 0 || strcmp(sIns_type,"Z") == 0)
	{
		printf("get iprovision product \n");
		$EXECUTE CUR_CARCLASS INTO $fcar_class_p using $icar_type;
		printf("*******iproduct--sIns_type[%s],iins_main[%s],fcar_class_p[%s] \n",sIns_type,iins_main,fcar_class_p);
		
		if((strcmp(sIns_type,"F") == 0) || (strcmp(sIns_type,"G") == 0) || (strcmp(sIns_type,"T") == 0))
		{
			
		}
		else
		{
			if(((strcmp(sIns_type,"L") == 0)  || (strcmp(sIns_type,"R") == 0)) &&
			   ((strcmp(icar_type,"01") == 0) || (strcmp(icar_type,"02") == 0) || 
			    (strcmp(icar_type,"32") == 0) || (strcmp(icar_type,"34") == 0) || (strcmp(icar_type,"35") == 0)))
			strcpy(fcar_class_p,"3");
			
			$SELECT iproduct 
			   INTO $iproduct
			   FROM ca_provision_product
			  WHERE iprovision = $sIns_type
			    AND iins_type = $iins_main
			    AND fclass = $fcar_class_p;
			printf("SQLCODE[%d] iproduct[%s] \n",SQLCODE,iproduct);
			if (SQLCODE == SQLNOTFOUND)
			{
				if(strcmp(sIns_type,"J") == 0)
				{
					$SELECT iproduct 
					   INTO $iproduct
				       FROM ca_provision_product
				      WHERE iprovision = $iins_type
				        AND iins_type = $iins_main
				        and fclass = '0'
				        AND icar_type = $icar_type_ori;
				}
				else
				{
					$SELECT iproduct 
					   INTO $iproduct
				       FROM ca_provision_product
				      WHERE iprovision = $iins_type
				        AND iins_type = $iins_main
				        and fclass = '0'
				        AND icar_type = $icar_type;	
			    }
			    printf("SQLCODE[%d] iproduct[%s] \n",SQLCODE,iproduct);
				if (SQLCODE == SQLNOTFOUND)
					strcpy(iproduct,"000000000000");
				else
				{
					strcpy(iproduct,trim(iproduct));
					strcat(iproduct,"11");
				}
			}
			else
			{
				strcpy(iproduct,trim(iproduct));
				strcat(iproduct,"11");
			}
		}
	}
	printf("iproduct[%s] \n",iproduct);
	
	strcat(prtstr,iproduct);
	strcpy(t_iproduct,iproduct);
	strncpy(iproduct_tmp,t_iproduct+3,2);
	iproduct_tmp[2] = '\0';
	printf("iproduct_tmp[%s] \n",iproduct_tmp);
	if(strcmp(sIns_type, "31") == 0 || strcmp(sIns_type, "131") == 0 || strcmp(sIns_type, "231") == 0 || strcmp(sIns_type, "331") == 0)
	{

	}
	else if(strcmp(sIns_type, "99") == 0)
	{

	}
	else 
	{	
		if (strcmp(iproduct_tmp,"10") == 0) 
		{
			mprem_10 = mprem_10+t_mins_app;
		}
		else if (strcmp(iproduct_tmp,"11") == 0) 
		{
			mprem_11 = mprem_11+t_mins_app;
		}
		else if (strcmp(iproduct_tmp,"12") == 0) 
		{
			mprem_12 = mprem_12+t_mins_app;
		}
		else if (strcmp(iproduct_tmp,"13") == 0) 
		{
			mprem_13 = mprem_13+t_mins_app;
		}
		else if (strcmp(iproduct_tmp,"28") == 0) 
		{
			mprem_28 = mprem_28+t_mins_app;
		}
	}
	printf("iins_type[%s]\n",iins_type);
	printf("mprem_10[%d]\n",mprem_10);
	printf("mprem_11[%d]\n",mprem_11);
	printf("mprem_12[%d]\n",mprem_12);
	printf("mprem_13[%d]\n",mprem_13);
	printf("mprem_28[%d]\n",mprem_28);
	
	/* 322-327 �O�v��I�~�� */
	strcpy( drate_ym, trim(drate_ym));
	if (isdigit(drate_ym[0])==0)
		drate_int = 0;
	else if (drate_ym[1] != '\0' && isdigit(drate_ym[1])==0)
		drate_int = 0;
	else
		drate_int = atoi(drate_ym);

	if (drate_int >= 15)
	{
		if (strcmp(iins_type,"55")==0)
		{
		    if (minjure_cover > 400000 || minjure_cover < 20000)
		        strcpy(drate_yyyymm,"200610");
		    else if (minjure_cover == 20000 || minjure_cover == 40000 ||
		             minjure_cover == 60000 || minjure_cover == 80000 ||
		             minjure_cover == 100000 || minjure_cover == 200000 ||
		             minjure_cover == 300000 || minjure_cover == 400000)
		    {
		         if (mdamage_cover == (minjure_cover * 5))
		             strcpy(drate_yyyymm,"200601");
		         else
		             strcpy(drate_yyyymm,"200610");
		    }
		    else
		        strcpy(drate_yyyymm,"200610");
		
			if ((mdeath_cover > 6000000) ||
				(mdeath_cover == minjure_cover))
			{
				strcpy(drate_yyyymm,"200607");
			}
		}
		else if (strcmp(iins_type,"26")==0 ||
			strcmp(iins_type,"71")==0 || strcmp(iins_type,"72")==0)
			strcpy(drate_yyyymm,"200601");
		else if (strcmp(iins_type,"41")==0 || strcmp(iins_type,"42")==0 ||
			strcmp(iins_type,"81")==0 || strcmp(iins_type,"82")==0)
			strcpy(drate_yyyymm,"200511");
		else if (strcmp(iins_type,"51")==0 && strcmp(drate_ym,"16")==0)
			strcpy(drate_yyyymm,"200107");
		else if (atoi(drate_ym) <= 15)
			strcpy(drate_yyyymm,"200107");
		else
		{
			$EXECUTE CUR_DRATE
			INTO $drate_yyyymm
			USING $drate_ym;
			if (SQLCODE==SQLNOTFOUND) strcpy(drate_yyyymm,"200107");
		}
	}
	else
	{
		if( drate_ym[1] == 'a' )
			strcpy( drate_ym, "5");

		if( drate_ym[0] == 'a' )
			strcpy( drate_ym, "11");
		
		if( drate_ym[1] == 'b' )
			strcpy( drate_ym, "11");
		
		if ((strcmp(sIns_type,"31")==0) || (strcmp(sIns_type,"131")==0) || (strcmp(sIns_type,"99")==0))
		{
			printf("drate_ym[%s]\n",drate_ym);
		}
		else
		if((strcmp(sIns_type,"01")==0) || (strcmp(sIns_type,"02")==0) ||
		   (strcmp(sIns_type,"03")==0) || (strcmp(sIns_type,"04")==0) ||
		   (strcmp(sIns_type,"05")==0 && mdeduct != 0) ||
		   (strcmp(sIns_type,"11")==0) ||
		   (strcmp(sIns_type,"12")==0) || (strcmp(sIns_type,"13")==0) ||
		   (strcmp(sIns_type,"24")==0) ||
		   (strcmp(sIns_type,"32")==0) || (strcmp(sIns_type,"132")==0) ||
		   (strcmp(sIns_type,"51")==0) || (strcmp(sIns_type,"81")==0))
		{
			printf ("32 drate_ym[%s]\n",drate_ym);
			$SELECT drate INTO $drate
			   FROM ca_rate_date
			  WHERE icode = $drate_ym
			    AND itable='ca_rate';
			if (SQLCODE == SQLNOTFOUND)
			{
			    $EXECUTE Cur_id
			        INTO $x_drate_ym, $provision
			       USING $ipolicy,$sIns_type;
			
			    $SELECT drate INTO $drate
			       FROM ca_rate_date
			      WHERE icode = $x_drate_ym
			        AND itable='ca_rate';
			    if( SQLCODE == SQLNOTFOUND)
			        drate[0] = '\0';
			}
			
			if(strcmp(drate,"04/01/2002")==0)
			{  strcpy(drate,"07/01/2001");  }
			
			if(*drate == '\0')
			{
				fRowError = TRUE;
				printf("debug c\n");
				sprintf_s(prtstr, sizeof prtstr, "field35:[drate error]-icar_type[%s],ins_type[%s])",icar_type, sIns_type);
			}
			else
			{
			 	strcpy(drate_c,cm_from_infdate_100(drate));
				cm_split_ymd_100(drate_c,drate_yy,drate_mm,drate_dd);
				sprintf_s(drate_yyyymm, sizeof drate_yyyymm,"%s%s",itoa(atoi(drate_yy)+1911),drate_mm);
			}
		}
		else if(strcmp(sIns_type,"93")==0 || strcmp(sIns_type,"94")==0 ||
		        strcmp(sIns_type,"95")==0 || strcmp(sIns_type,"29")==0 ||
		        strcmp(sIns_type,"24")==0 || strcmp(sIns_type,"30")==0 ||
		        strcmp(sIns_type,"131A")==0 || strcmp(sIns_type,"131B")==0 || strcmp(sIns_type,"131C")==0)
		{
			printf ("29 drate_ym[%s]\n",drate_ym);
			$SELECT drate INTO $drate
			   FROM ca_rate_date
			  WHERE icode=$drate_ym
			    AND itable='cover_vs_premium';
			if (SQLCODE == SQLNOTFOUND)
			{
				drate[0]='\0';printf("--NOT FOUND--\n");
			}
			
			if(strcmp(drate,"04/01/2002")==0)
			{  strcpy(drate,"07/01/2001");  }
			
			if(strcmp(drate,"03/01/2004")==0)
			{  strcpy(drate,"07/01/2001");  }
			
			
			if (*drate == '\0')
			{
			 	fRowError = TRUE;
				sprintf_s(prtstr, sizeof prtstr, "field35:(cover_vs_premium.car_type[%s],ins_type[%s])",icar_type, sIns_type);
			}
			else
			{
				strcpy(drate_c,cm_from_infdate_100(drate));
				cm_split_ymd_100(drate_c,drate_yy,drate_mm,drate_dd);
				sprintf_s(drate_yyyymm, sizeof drate_yyyymm,"%s%s",itoa(atoi(drate_yy)+1911),drate_mm);
			}
		}
		else if((strcmp(trim(sIns_type),"09")== 0) ||
		        (strcmp(trim(sIns_type),"05")== 0 && mdeduct == 0))
			strcpy(drate_yyyymm,"199903");
		else if((strcmp(trim(sIns_type),"47")== 0))
			strcpy(drate_yyyymm,"200008");
		else if (strcmp(trim(sIns_type),"55")==0 || strcmp(trim(sIns_type),"26")==0 ||
			     strcmp(trim(sIns_type),"71")==0 || strcmp(trim(sIns_type),"72")==0 )
			strcpy(drate_yyyymm,"200601");
		else if (strcmp(trim(sIns_type),"41")==0 || strcmp(trim(sIns_type),"42")==0 ||
		         strcmp(trim(sIns_type),"81")==0 || strcmp(trim(sIns_type),"82")==0 )
			strcpy(drate_yyyymm,"200511");
		else
		{
			strcpy(drate_yyyymm,"199607");
		}
	}
	strcat(prtstr,drate_yyyymm);
	strcpy(t_drate_ym,drate_yyyymm);

	/* 328-335 �ߥI��� */
	strcpy(dentry_c,cm_cdate_str_100(dgroup));
	cm_split_ymd_100(dentry_c,dentry_yy,dentry_mm,dentry_dd);
	strcpy(dentry_yyyy,itoa(atoi(dentry_yy)+1911));
	strcat(prtstr,(*dentry_yy=='\0') ? "0000" : dentry_yyyy);
	strcat(prtstr,(*dentry_mm=='\0') ? "00" : dentry_mm);
	strcat(prtstr,(*dentry_dd=='\0') ? "00" : dentry_dd);
	strcpy(t_dentry,(*dentry_yyyy=='\0') ? "0000" : dentry_yyyy);
	strcat(t_dentry,(*dentry_mm=='\0') ? "00" : dentry_mm);
	strcat(t_dentry,(*dentry_dd=='\0') ? "00" : dentry_dd);

	printf("LEN--281[%d]\n",strlen(prtstr));

	/* 336-337 �q���O�N��*/
	strcat(prtstr,bzfrom);
	strcpy(t_bzfrom,bzfrom);
	prtstr[337] = '\0';
	
	/* 338-343 ñ��~��*/
	strcpy(ply_dpolicy_c, cm_cdate_str_100(ply_dpolicy));
	cm_split_ymd_100(ply_dpolicy_c, dpolicy_yy, dpolicy_mm, dpolicy_dd);
	
	if (dpolicy_yy[0] == '\0') 
	{
		strcat(prtstr,"0000");
		strcpy(t_dpolicy_ym,"0000");
	}
	else 
	{
		strcat(prtstr,itoa(1911+(atoi(dpolicy_yy))));
		strcpy(t_dpolicy_ym,itoa(1911+(atoi(dpolicy_yy))));
	}
	if (dpolicy_mm[0] == '\0') 
	{
		strcat(prtstr,"00");
		strcat(t_dpolicy_ym,"00");
	}
	else
	{
		strcat(prtstr,dpolicy_mm);
		strcat(t_dpolicy_ym,dpolicy_mm);
	}
	prtstr[343] = '\0';

	/* 344-351 ��ƻs�e��� */
    strcat(prtstr,ttday_yy);
    strcat(prtstr,ttday_mm);
    strcat(prtstr,ttday_dd);
    strcpy(t_dsend,ttday_yy);
	strcat(t_dsend,ttday_mm);
	strcat(t_dsend,ttday_dd);

	/* 352 ��@�����ۦ�I���ƬG�έp�N�X */
	$SELECT fsingle_acc
	   INTO $fsingle_acc
       FROM ca_verify
      WHERE iverify = (SELECT iverify FROM ca_ver_relation WHERE iclaim = $iclaim );

	if(SQLCODE == SQLNOTFOUND)
	{
		strcpy(fsingle_acc,"0");
	}
	strcat(prtstr,(*fsingle_acc=='\0') ? "0" : fsingle_acc);
	strcpy(t_fsingle_acc,(*fsingle_acc=='\0') ? "0" : fsingle_acc);

	/* 353-358  �z�߸g��H���N�X */
	$SELECT adjustment
	   INTO $adjustment
       FROM ca_clm_process
 	  WHERE iclaim = $iclaim;
	if(SQLCODE == SQLNOTFOUND)
	{
		strcpy(adjustment,"000000");
	}
	strcat(prtstr,(*adjustment=='\0') ? "000000" : adjustment);
	strcpy(t_adjustment,(*adjustment=='\0') ? "000000" : adjustment);

	/* 359-368 �ײz�t��Q�Ʒ~�Τ@�s���έt�d�H�����Ҧr�� */
	if (strlen(trim(ifacnum)) == 0)
	{
		strcat(prtstr,"0000000000");
		strcpy(t_ifacnum,"0000000000");
	}
	else
	{
		strcat(prtstr,ifacnum);
		strcpy(t_ifacnum,ifacnum);
	}
	
	/* 369-378 ���{�� */
	if (atoi(data_yyyymm) >= 202101)
	{
		strcat(prtstr,"0000000000");
	}
	prtstr[378] = '\0';
	printf("prtstr[%s]\n",prtstr);

	printf("data_yyyymm[%s],t_istl[%s],ipolicy[%s],iclaim[%s],t_icompany[%s],t_iclm_br[%s],t_iclm[%s],t_dclaim[%s] \n",
	        data_yyyymm,t_istl,ipolicy,iclaim,t_icompany,t_iclm_br,t_iclm,t_dclaim);
	printf("t_iclose_type[%d],t_dgroup[%s],t_icompany_ply[%s],t_iply_br[%s],t_iply,[%s],t_dply_begin_ym[%s],t_iobjno[%s] \n",
	        t_iclose_type,t_dgroup,t_icompany_ply,t_iply_br,t_iply,t_dply_begin_ym,t_iobjno);
	printf("t_iissue_ym[%s],t_ipro_ym[%s],t_ibrand[%s],t_icar_type_ori[%s],t_icar_type[%s],t_icar_type_no[%s],t_qcylinder[%d] \n",
	        t_iissue_ym,t_ipro_ym,t_ibrand,t_icar_type_ori,t_icar_type,t_icar_type_no,t_qcylinder);
	printf("t_iengine[%s],t_itag[%s],t_qpt[%d],t_fpt[%s],t_iacc_license[%s],t_iacc_birth_y[%s],t_facc_sex[%s],t_facc_marri[%s] \n",
	        t_iengine,t_itag,t_qpt,t_fpt,t_iacc_license,t_iacc_birth_y,t_facc_sex,t_facc_marri);
	printf("t_iacc_reason[%s],t_fduty[%s],t_iassured[%s],t_dbirth_y[%s],t_fsex[%s],t_fmarriage[%s],t_qlia1[%d],t_qlia2[%d],t_qlia3[%d] \n",
	        t_iacc_reason,t_fduty,t_iassured,t_dbirth_y,t_fsex,t_fmarriage,t_qlia1,t_qlia2,t_qlia3);
	printf("t_daccident[%s],t_dvp_code1[%s],t_dvp_code2[%s],t_fpart[%s],t_ipdmg_align[%s],t_ipbrg_align[%s],t_iplia_align[%s] \n",
	        t_daccident,t_dvp_code1,t_dvp_code2,t_fpart,t_ipdmg_align,t_ipbrg_align,t_iplia_align);
	printf("t_iins_type_ori[%s],t_iins_type[%s],t_iins_main[%s],t_iins_type_main[%s],t_iins_type_dtl[%s],t_iins_type_dev[%s] \n",
	        t_iins_type_ori,t_iins_type,t_iins_main,t_iins_type_main,t_iins_type_dtl,t_iins_type_develop);
	printf("t_iins_type_rule[%s],t_iins_type_class[%s],t_frule[%s],t_p_mcar_price[%d],t_pins_acc[%f],t_psex_age[%f] \n",
	        t_iins_type_rule,t_iins_type_class,t_frule,t_p_mcar_price,t_pins_acc,t_psex_age);
	printf("t_pdepreciate_year[%d],t_ubi_data[%s],t_mcover[%d],t_iins_mult[%d],t_fmdeduct[%s],t_mdeduct[%d],t_qpeople[%d] \n",
	        t_pdepreciate_year,t_ubi_data,t_mcover,t_iins_mult,t_fmdeduct,t_mdeduct,t_qpeople);
	printf("t_iself_duty[%d],t_ioth_duty[%d],t_ianoth_duty[%d],t_mins_app[%d],t_mdeduct_clm[%d],t_mins_stl[%d],t_mins_proc[%d] \n",
	        t_iself_duty,t_ioth_duty,t_ianoth_duty,t_mins_app,t_mdeduct_clm,t_mins_stl,t_mins_proc);
	printf("t_fstl[%s],t_iproduct[%s],t_drate_ym[%s],t_dentry[%s],t_bzfrom[%s],t_dpolicy_ym[%s],t_dsend[%s],t_fsingle_acc[%s] \n",
	        t_fstl,t_iproduct,t_drate_ym,t_dentry,t_bzfrom,t_dpolicy_ym,t_dsend,t_fsingle_acc);
	printf("t_adjustment[%s],t_ifacnum[%s] \n",
	        t_adjustment,t_ifacnum);

	if (strcmp(trim(sIns_type),"99") == 0)
	{
		/* �[�`���g�J */
	}
	else if (strcmp(trim(sIns_type),"99") != 0 && strcmp(trim(t_iins_type_class),"99") == 0)
	{
		/* �[�`���g�J */
	}
	else 
	{	
		printf("IN ca_dev_clm");
		/* �d�s��� */
		sprintf_s(stmt, sizeof stmt,"INSERT INTO %s:ca_dev_clm \
		                     (data_yyyymm,idata,istl,ipolicy,iclaim,icompany,iclm_br,iclm,dclaim, \
	                          iclose_type,dgroup,icompany_ply,iply_br,iply,dply_begin_ym,iobjno, \
	                          iissue_ym,ipro_ym,ibrand,icar_type_ori,icar_type,icar_type_no,qcylinder, \
	                          iengine,itag,qpt,fpt,iacc_license,iacc_birth_y,facc_sex,facc_marri, \
	                          iacc_reason,fduty,iassured,dbirth_y,fsex,fmarriage,qlia1,qlia2,qlia3, \
	                          daccident,dvp_code1,dvp_code2,fpart,ipdmg_align,ipbrg_align,iplia_align, \
	                          iins_type_ori,iins_type,iins_main,iins_type_main,iins_type_dtl,iins_type_dev, \
	                          iins_type_rule,iins_type_class,frule,p_mcar_price,pins_acc,psex_age, \
	                          pdepreciate_year,ubi_data,mcover,iins_mult,fmdeduct,mdeduct,qpeople, \
	                          iself_duty,ioth_duty,ianoth_duty,mins_app,mdeduct_clm,mins_stl,mins_proc, \
	                          fstl,iproduct,drate_ym,dentry,bzfrom,dpolicy_ym,dsend,fsingle_acc, \
	                          adjustment,ifacnum) \
		              VALUES(?,'Z',?,?,?,?,?,?,?, \
		                     ?,?,?,?,?,?,?, \
		                     ?,?,?,?,?,?,?, \
		                     ?,?,?,?,?,?,?,?, \
		                     ?,?,?,?,?,?,?,?,?, \
		                     ?,?,?,?,?,?,?, \
		                     ?,?,?,?,?,?, \
		                     ?,?,?,?,?,?, \
		                     ?,?,?,?,?,?,?, \
		                     ?,?,?,?,?,?,?, \
		                     ?,?,?,?,?,?,?,?, \
		                     ?,?)",ply_DB);
		$PREPARE insert_clm FROM $stmt;
		$EXECUTE insert_clm using $data_yyyymm,$t_istl,$ipolicy,$iclaim,$t_icompany,$t_iclm_br,$t_iclm,$t_dclaim,
		                          $t_iclose_type,$t_dgroup,$t_icompany_ply,$t_iply_br,$t_iply,$t_dply_begin_ym,$t_iobjno,
		                          $t_iissue_ym,$t_ipro_ym,$t_ibrand,$t_icar_type_ori,$t_icar_type,$t_icar_type_no,$t_qcylinder,
		                          $t_iengine,$t_itag,$t_qpt,$t_fpt,$t_iacc_license,$t_iacc_birth_y,$t_facc_sex,$t_facc_marri,
		                          $t_iacc_reason,$t_fduty,$t_iassured,$t_dbirth_y,$t_fsex,$t_fmarriage,$t_qlia1,$t_qlia2,$t_qlia3,
		                          $t_daccident,$t_dvp_code1,$t_dvp_code2,$t_fpart,$t_ipdmg_align,$t_ipbrg_align,$t_iplia_align,
		                          $t_iins_type_ori,$t_iins_type,$t_iins_main,$t_iins_type_main,$t_iins_type_dtl,$t_iins_type_develop,
		                          $t_iins_type_rule,$t_iins_type_class,$t_frule,$t_p_mcar_price,$t_pins_acc,$t_psex_age,
		                          $t_pdepreciate_year,$t_ubi_data,$t_mcover,$t_iins_mult,$t_fmdeduct,$t_mdeduct,$t_qpeople,
		                          $t_iself_duty,$t_ioth_duty,$t_ianoth_duty,$t_mins_app,$t_mdeduct_clm,$t_mins_stl,$t_mins_proc,
		                          $t_fstl,$t_iproduct,$t_drate_ym,$t_dentry,$t_bzfrom,$t_dpolicy_ym,$t_dsend,$t_fsingle_acc,
		                          $t_adjustment,$t_ifacnum;
	}
	
    return;

errexit:
  printf("SOLCODE[%d] sqlca.sqlerrm[%s]\n",SQLCODE,sqlca.sqlerrm);
  sprintf_s(errmsg, sizeof errmsg,"SOLCODE[%d] sqlca.sqlerrm[%s]",SQLCODE,sqlca.sqlerrm);
  return SQLCODE;
}

long car9998_final()
{
	char sTmpMsg[2048];
	$char sfilename[81],stitle[1024],stmt[2048];
	$char DBName1[5];
	$double mprem=0, pure_mprem=0, qcnt=0;
	$char product_kind[3];
    
	$WHENEVER SQLERROR GOTO errexit;
	
	strcpy(DBName1,"00");
	if (db_select(DBName1) == False)  return M_CM_DB_NOTOPEN;

	$SELECT sum(mprem), sum(qcnt)
	   INTO $mprem, $qcnt
	   FROM ca_develop
	  WHERE iclass = '9998' AND product_kind = '99'
	    AND data_yyyymm  = $data_yyyymm;
	printf("mprem[%.0lf],qcnt[%.0lf]",mprem,qcnt);
	
	sprintf_s(sTmpMsg, sizeof sTmpMsg, "%s%s\n", "���ɧ���:", file_catalog);
	sprintf_s(sTmpMsg, sizeof sTmpMsg, "%s�w�����B=[%.0lf] ����=[%.0lf]\n",sTmpMsg, mprem, qcnt);
	printf("file_catalog[%s] \n",file_catalog);
	printf("sTmpMsg[%s] \n",sTmpMsg);
	/*29�I���p�p����*/
	sprintf_s(stmt, sizeof stmt,"SELECT product_kind, sum(mprem), sum(qcnt) \
	                               FROM ca_develop \
	                              WHERE iclass = '9998' AND product_kind <> '99' AND data_yyyymm = '%s' \
	                              GROUP BY product_kind order by 1",data_yyyymm);
	$PREPARE pre_29_kind1 FROM $stmt;
	$DECLARE cur_29_kind2 CURSOR FOR pre_29_kind1;
	$OPEN cur_29_kind2;
	while (1)
	{
		$FETCH cur_29_kind2 INTO $product_kind ,$mprem, $qcnt;
		if (SQLCODE == SQLNOTFOUND) break;
		sprintf_s(sTmpMsg, sizeof sTmpMsg, "%s�I��=[%s] �O�O=[%.0lf] ����=[%.0lf]\n",sTmpMsg, product_kind, mprem, qcnt);
	}

	EWRITE(userid, M_CM_OK, sTmpMsg);
	exit(SUCCESS);
	isfinish(rtncode);

errexit:
   sqlfatal();
   EWRITE(userid, SQLCODE, sqlca.sqlerrm);
   return SQLCODE;
}

/**********************************************************************/
chk_date(s)
char *s;
{
  int y=-1, m=-1, d=-1;
  char cy[4], cm[3], cd[3];

  if(strlen(s) == 5){                   /* yy/mm */
    strncpy(cy, s, 2); cy[2]='\0';
    y = atoi(cy);
    if(y<1 || y>150) return 0;
    strncpy(cm, s+3, 2); cm[2]='\0';
    m = atoi(cm);
    return (m>=1 && m<=12) ? 1 : 0;
  }else if(strlen(s) == 8){             /* yy/mm/dd */
    strncpy(cy, s, 2); cy[2]='\0';
    y = atoi(cy);
    if(y < 1 || y > 150) return 0;
    strncpy(cm, s+3, 2); cm[2]='\0';
    m = atoi(cm);
    if(m < 1 || m > 12) return 0;
    strncpy(cd, s+6, 2); cd[2]='\0';
    d = atoi(cd);
    return (d >= 1 && d <= 31) ? 1 : 0;
  }else if(strlen(s) == 4){             /* yymm */
    strncpy(cy, s, 2); cy[2] = '\0';
    y = atoi(cy);
    if(y < 1 || y > 150) return 0;
    strncpy(cm, s+2, 2); cm[2] = '\0';
    m = atoi(cm);
    return (m >= 1 && m <= 12) ? 1 : 0;
  }else if(strlen(s) == 6){             /* yymmdd */
    strncpy(cy, s, 2); cy[2] = '\0';
    y = atoi(cy);
    if(y < 1 || y > 150) return 0;
    strncpy(cm, s+2, 2); cm[2] = '\0';
    m = atoi(cm);
    if(m < 1 || m > 12) return 0;
    strncpy(cd, s+4, 2); cd[2] = '\0';
    d = atoi(cd);
    return (d >= 1 && d <= 31) ? 1 : 0;
  }else
    return 0;
}

/**********************************************************************/
chk_year(s)
char *s;
{
  char sDate[11], sYear[5];
  int y, iYear, iBirthYear;

  strcpy(sDate, cm_cdate_str_100(cm_today()));
  strncpy(sYear, sDate, 2); sYear[2] = '\0';
  iBirthYear = atoi(s);
  iYear = atoi(sYear);
  if(iYear - iBirthYear >= 18)
  {
    iBirthYear -= 20;
    sprintf_s(s, sizeof s, "%d", iBirthYear);
  }
}
/*************************************************************/
